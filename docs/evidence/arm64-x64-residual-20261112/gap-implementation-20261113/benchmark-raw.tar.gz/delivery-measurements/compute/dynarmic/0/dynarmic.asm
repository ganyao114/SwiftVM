00007ec68bfce69b  nop [rax+rax*1], eax
00007ec68bfce6a0  mov rax, [r15+0xF8]
00007ec68bfce6a7  lea r14, [rax-0x1E0]
00007ec68bfce6ae  mov [r15+0xF8], r14
00007ec68bfce6b5  lea rax, [r14+0x1D0]
00007ec68bfce6bc  mov r12, [r15+0xA0]
00007ec68bfce6c3  mov r11, [r15+0x98]
00007ec68bfce6ca  mov [r13+rax*1], r12
00007ec68bfce6cf  lea rax, [r14+0x1D8]
00007ec68bfce6d6  mov [r13+rax*1], r11
00007ec68bfce6db  mov eax, 0x420AA0
00007ec68bfce6e0  movups xmm1, [r13+rax*1]
00007ec68bfce6e6  mov eax, 0x420A30
00007ec68bfce6eb  movups xmm15, [r13+rax*1]
00007ec68bfce6f1  mov eax, 0x420AC0
00007ec68bfce6f6  movups xmm14, [r13+rax*1]
00007ec68bfce6fc  mov eax, 0x420A60
00007ec68bfce701  movups xmm13, [r13+rax*1]
00007ec68bfce707  mov qword ptr [r15+0x98], 0x430CD0
00007ec68bfce712  mov eax, 0x420AD0
00007ec68bfce717  movups xmm12, [r13+rax*1]
00007ec68bfce71d  mov eax, 0x430CD0
00007ec68bfce722  movups [r13+rax*1], xmm1
00007ec68bfce728  mov eax, 0x430CE0
00007ec68bfce72d  movups [r13+rax*1], xmm15
00007ec68bfce733  mov eax, 0x430CF0
00007ec68bfce738  movups [r13+rax*1], xmm14
00007ec68bfce73e  mov eax, 0x430D00
00007ec68bfce743  movups [r13+rax*1], xmm13
00007ec68bfce749  mov eax, 0x420A20
00007ec68bfce74e  movups xmm14, [r13+rax*1]
00007ec68bfce754  mov eax, 0x420A10
00007ec68bfce759  movups xmm13, [r13+rax*1]
00007ec68bfce75f  mov eax, 0x430DD0
00007ec68bfce764  movups [r13+rax*1], xmm1
00007ec68bfce76a  mov eax, 0x430DE0
00007ec68bfce76f  movups [r13+rax*1], xmm15
00007ec68bfce775  mov eax, 0x430D10
00007ec68bfce77a  movups [r13+rax*1], xmm12
00007ec68bfce780  mov eax, 0x430D20
00007ec68bfce785  movups [r13+rax*1], xmm14
00007ec68bfce78b  mov eax, 0x420A00
00007ec68bfce790  movups xmm1, [r13+rax*1]
00007ec68bfce796  mov eax, 0x420A70
00007ec68bfce79b  movups xmm15, [r13+rax*1]
00007ec68bfce7a1  mov eax, 0x430D30
00007ec68bfce7a6  movups [r13+rax*1], xmm13
00007ec68bfce7ac  mov eax, 0x430D40
00007ec68bfce7b1  movups [r13+rax*1], xmm1
00007ec68bfce7b7  mov eax, 0x420A80
00007ec68bfce7bc  movups xmm1, [r13+rax*1]
00007ec68bfce7c2  mov eax, 0x420A50
00007ec68bfce7c7  movups xmm14, [r13+rax*1]
00007ec68bfce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007ec68bfce7d5  mov eax, 0x430D50
00007ec68bfce7da  movups [r13+rax*1], xmm15
00007ec68bfce7e0  mov eax, 0x430D60
00007ec68bfce7e5  movups [r13+rax*1], xmm1
00007ec68bfce7eb  mov eax, 0x420AF0
00007ec68bfce7f0  movups xmm1, [r13+rax*1]
00007ec68bfce7f6  mov eax, 0x420B00
00007ec68bfce7fb  movups xmm15, [r13+rax*1]
00007ec68bfce801  movaps [r15+0x150], xmm15
00007ec68bfce809  mov qword ptr [r15+0xA0], 0x3E8
00007ec68bfce814  mov eax, 0x430D70
00007ec68bfce819  movups [r13+rax*1], xmm14
00007ec68bfce81f  mov eax, 0x430D80
00007ec68bfce824  movups [r13+rax*1], xmm1
00007ec68bfce82a  mov eax, 0x420AE0
00007ec68bfce82f  movups xmm1, [r13+rax*1]
00007ec68bfce835  mov eax, 0x420A90
00007ec68bfce83a  movups xmm14, [r13+rax*1]
00007ec68bfce840  movaps [r15+0x140], xmm14
00007ec68bfce848  lea rax, [r14+0x180]
00007ec68bfce84f  movq xmm13, qword ptr [r15+0x200]
00007ec68bfce858  movq xmm12, qword ptr [r15+0x1F0]
00007ec68bfce861  movq r12, xmm13
00007ec68bfce866  movq r11, xmm12
00007ec68bfce86b  mov [r13+rax*1], r12
00007ec68bfce870  lea rax, [r14+0x188]
00007ec68bfce877  mov [r13+rax*1], r11
00007ec68bfce87c  mov eax, 0x430D90
00007ec68bfce881  movups [r13+rax*1], xmm15
00007ec68bfce887  mov eax, 0x430DA0
00007ec68bfce88c  movups [r13+rax*1], xmm1
00007ec68bfce892  mov eax, 0x420AB0
00007ec68bfce897  movups xmm1, [r13+rax*1]
00007ec68bfce89d  mov eax, 0x420B18
00007ec68bfce8a2  mov r12, [r13+rax*1]
00007ec68bfce8a7  movq xmm15, r12
00007ec68bfce8ac  mov qword ptr [r15+0x40], 0x420B20
00007ec68bfce8b4  mov eax, 0x430DB0
00007ec68bfce8b9  movups [r13+rax*1], xmm14
00007ec68bfce8bf  mov eax, 0x430DC0
00007ec68bfce8c4  movups [r13+rax*1], xmm1
00007ec68bfce8ca  mov eax, 0x420B80
00007ec68bfce8cf  movups xmm1, [r13+rax*1]
00007ec68bfce8d5  movq rax, xmm15
00007ec68bfce8da  mov r12d, 0x430DF0
00007ec68bfce8e0  mov [r13+r12*1], rax
00007ec68bfce8e5  mov eax, 0x420B60
00007ec68bfce8ea  movups xmm15, [r13+rax*1]
00007ec68bfce8f0  mov eax, 0x420B70
00007ec68bfce8f5  movups xmm14, [r13+rax*1]
00007ec68bfce8fb  lea rax, [r14+0x160]
00007ec68bfce902  movups [r13+rax*1], xmm1
00007ec68bfce908  lea rax, [r14+0x190]
00007ec68bfce90f  movq xmm1, qword ptr [r15+0x1E0]
00007ec68bfce918  movq xmm13, qword ptr [r15+0x1D0]
00007ec68bfce921  movq r12, xmm1
00007ec68bfce926  movq r11, xmm13
00007ec68bfce92b  mov [r13+rax*1], r12
00007ec68bfce930  lea rax, [r14+0x198]
00007ec68bfce937  mov [r13+rax*1], r11
00007ec68bfce93c  lea rax, [r14+0x140]
00007ec68bfce943  movups [r13+rax*1], xmm15
00007ec68bfce949  lea rax, [r14+0x150]
00007ec68bfce950  movups [r13+rax*1], xmm14
00007ec68bfce956  mov eax, 0x420B20
00007ec68bfce95b  movups xmm1, [r13+rax*1]
00007ec68bfce961  mov eax, 0x420B30
00007ec68bfce966  movups xmm15, [r13+rax*1]
00007ec68bfce96c  movaps [r15+0x120], xmm15
00007ec68bfce974  lea rax, [r14+0x1A0]
00007ec68bfce97b  movq xmm14, qword ptr [r15+0x1C0]
00007ec68bfce984  movq xmm13, qword ptr [r15+0x1B0]
00007ec68bfce98d  movq r12, xmm14
00007ec68bfce992  movq r11, xmm13
00007ec68bfce997  mov [r13+rax*1], r12
00007ec68bfce99c  lea rax, [r14+0x1A8]
00007ec68bfce9a3  mov [r13+rax*1], r11
00007ec68bfce9a8  lea rax, [r14+0x1B0]
00007ec68bfce9af  movq xmm14, qword ptr [r15+0x1A0]
00007ec68bfce9b8  movq xmm13, qword ptr [r15+0x190]
00007ec68bfce9c1  movq r12, xmm14
00007ec68bfce9c6  movq r11, xmm13
00007ec68bfce9cb  mov [r13+rax*1], r12
00007ec68bfce9d0  lea rax, [r14+0x1B8]
00007ec68bfce9d7  mov [r13+rax*1], r11
00007ec68bfce9dc  lea rax, [r14+0x100]
00007ec68bfce9e3  movups [r13+rax*1], xmm1
00007ec68bfce9e9  lea rax, [r14+0x110]
00007ec68bfce9f0  movups [r13+rax*1], xmm15
00007ec68bfce9f6  mov eax, 0x420B40
00007ec68bfce9fb  movups xmm1, [r13+rax*1]
00007ec68bfcea01  mov eax, 0x420B50
00007ec68bfcea06  movups xmm15, [r13+rax*1]
00007ec68bfcea0c  movaps [r15+0x110], xmm1
00007ec68bfcea14  movaps [r15+0x130], xmm15
00007ec68bfcea1c  lea rax, [r14+0x1C0]
00007ec68bfcea23  mov r12, [r15+0xE8]
00007ec68bfcea2a  mov r11, [r15+0xF0]
00007ec68bfcea31  mov [r13+rax*1], r12
00007ec68bfcea36  lea rax, [r14+0x1C8]
00007ec68bfcea3d  mov [r13+rax*1], r11
00007ec68bfcea42  mov eax, 0x430DF8
00007ec68bfcea47  mov r12d, 0x421DF8D3
00007ec68bfcea4d  mov [r13+rax*1], r12d
00007ec68bfcea52  lea rax, [r14+0x120]
00007ec68bfcea59  movups [r13+rax*1], xmm1
00007ec68bfcea5f  lea rax, [r14+0x130]
00007ec68bfcea66  movups [r13+rax*1], xmm15
00007ec68bfcea6c  lea rax, [r14+0x100]
00007ec68bfcea73  mov [r15], rax
00007ec68bfcea76  mov qword ptr [r15+0x08], 0x430CD0
00007ec68bfcea7e  mov qword ptr [r15+0x10], 0x12C
00007ec68bfcea86  mov qword ptr [r15+0xF0], 0x410284
00007ec68bfcea91  mov r14d, [r15+0x320]
00007ec68bfcea98  mov eax, 0x410284
00007ec68bfcea9d  mov rcx, 0x7EC68BFD07C0
00007ec68bfceaa7  mov [r15+r14*8+0x328], rax
00007ec68bfceaaf  mov [r15+r14*8+0x368], rcx
00007ec68bfceab7  add r14d, 0x01
00007ec68bfceabb  and r14d, 0x07
00007ec68bfceabf  mov [r15+0x320], r14d
00007ec68bfceac6  cmp dword ptr [r15+0x318], 0x00
00007ec68bfceace  jz 0x00007EC68BFCED70
00007ec68bfcead4  nop [rax+rax*1], ax
00007ec68bfceadd  nop [rax+rax*1], eax
00007ec68bfceae5  mov eax, 0x410728
00007ec68bfceaea  mov [r15+0x100], rax
00007ec68bfceaf1  jmp 0x00007EC68BDFE110
00007ec68bfceaf6  int3
00007ec68bfceaf7  call 0x00007EC68BE0BC20
00007ec68bfceafc  jmp 0x00007EC68BFCE6CF
00007ec68bfceb01  call 0x00007EC68BE0A9A0
00007ec68bfceb06  jmp 0x00007EC68BFCE6DB
00007ec68bfceb0b  call 0x00007EC68BDFF430
00007ec68bfceb10  jmp 0x00007EC68BFCE6E6
00007ec68bfceb15  call 0x00007EC68BE0E760
00007ec68bfceb1a  jmp 0x00007EC68BFCE6F1
00007ec68bfceb1f  call 0x00007EC68BE0D4E0
00007ec68bfceb24  jmp 0x00007EC68BFCE6FC
00007ec68bfceb29  call 0x00007EC68BE0C260
00007ec68bfceb2e  jmp 0x00007EC68BFCE707
00007ec68bfceb33  call 0x00007EC68BE0AFE0
00007ec68bfceb38  jmp 0x00007EC68BFCE71D
00007ec68bfceb3d  call 0x00007EC68BDFF540
00007ec68bfceb42  jmp 0x00007EC68BFCE728
00007ec68bfceb47  call 0x00007EC68BE0E880
00007ec68bfceb4c  jmp 0x00007EC68BFCE733
00007ec68bfceb51  call 0x00007EC68BE0D600
00007ec68bfceb56  jmp 0x00007EC68BFCE73E
00007ec68bfceb5b  call 0x00007EC68BE0C380
00007ec68bfceb60  jmp 0x00007EC68BFCE749
00007ec68bfceb65  call 0x00007EC68BE0D4E0
00007ec68bfceb6a  jmp 0x00007EC68BFCE754
00007ec68bfceb6f  call 0x00007EC68BE0C260
00007ec68bfceb74  jmp 0x00007EC68BFCE75F
00007ec68bfceb79  call 0x00007EC68BDFF540
00007ec68bfceb7e  jmp 0x00007EC68BFCE76A
00007ec68bfceb83  call 0x00007EC68BE0E880
00007ec68bfceb88  jmp 0x00007EC68BFCE775
00007ec68bfceb8d  call 0x00007EC68BE0B100
00007ec68bfceb92  jmp 0x00007EC68BFCE780
00007ec68bfceb97  call 0x00007EC68BE0D600
00007ec68bfceb9c  jmp 0x00007EC68BFCE78B
00007ec68bfceba1  call 0x00007EC68BDFF430
00007ec68bfceba6  jmp 0x00007EC68BFCE796
00007ec68bfcebab  call 0x00007EC68BE0E760
00007ec68bfcebb0  jmp 0x00007EC68BFCE7A1
00007ec68bfcebb5  call 0x00007EC68BE0C380
00007ec68bfcebba  jmp 0x00007EC68BFCE7AC
00007ec68bfcebbf  call 0x00007EC68BDFF540
00007ec68bfcebc4  jmp 0x00007EC68BFCE7B7
00007ec68bfcebc9  call 0x00007EC68BDFF430
00007ec68bfcebce  jmp 0x00007EC68BFCE7C2
00007ec68bfcebd3  call 0x00007EC68BE0D4E0
00007ec68bfcebd8  jmp 0x00007EC68BFCE7CD
00007ec68bfcebdd  call 0x00007EC68BE0E880
00007ec68bfcebe2  jmp 0x00007EC68BFCE7E0
00007ec68bfcebe7  call 0x00007EC68BDFF540
00007ec68bfcebec  jmp 0x00007EC68BFCE7EB
00007ec68bfcebf1  call 0x00007EC68BDFF430
00007ec68bfcebf6  jmp 0x00007EC68BFCE7F6
00007ec68bfcebfb  call 0x00007EC68BE0E760
00007ec68bfcec00  jmp 0x00007EC68BFCE801
00007ec68bfcec05  call 0x00007EC68BE0D600
00007ec68bfcec0a  jmp 0x00007EC68BFCE81F
00007ec68bfcec0f  call 0x00007EC68BDFF540
00007ec68bfcec14  jmp 0x00007EC68BFCE82A
00007ec68bfcec19  call 0x00007EC68BDFF430
00007ec68bfcec1e  jmp 0x00007EC68BFCE835
00007ec68bfcec23  call 0x00007EC68BE0D4E0
00007ec68bfcec28  jmp 0x00007EC68BFCE840
00007ec68bfcec2d  call 0x00007EC68BE0BC20
00007ec68bfcec32  jmp 0x00007EC68BFCE870
00007ec68bfcec37  call 0x00007EC68BE0A9A0
00007ec68bfcec3c  jmp 0x00007EC68BFCE87C
00007ec68bfcec41  call 0x00007EC68BE0E880
00007ec68bfcec46  jmp 0x00007EC68BFCE887
00007ec68bfcec4b  call 0x00007EC68BDFF540
00007ec68bfcec50  jmp 0x00007EC68BFCE892
00007ec68bfcec55  call 0x00007EC68BDFF430
00007ec68bfcec5a  jmp 0x00007EC68BFCE89D
00007ec68bfcec5f  call 0x00007EC68BE0B720
00007ec68bfcec64  jmp 0x00007EC68BFCE8A7
00007ec68bfcec69  call 0x00007EC68BE0D600
00007ec68bfcec6e  jmp 0x00007EC68BFCE8BF
00007ec68bfcec73  call 0x00007EC68BDFF540
00007ec68bfcec78  jmp 0x00007EC68BFCE8CA
00007ec68bfcec7d  call 0x00007EC68BDFF430
00007ec68bfcec82  jmp 0x00007EC68BFCE8D5
00007ec68bfcec87  call 0x00007EC68BEB4CB0
00007ec68bfcec8c  jmp 0x00007EC68BFCE8E5
00007ec68bfcec91  call 0x00007EC68BE0E760
00007ec68bfcec96  jmp 0x00007EC68BFCE8F0
00007ec68bfcec9b  call 0x00007EC68BE0D4E0
00007ec68bfceca0  jmp 0x00007EC68BFCE8FB
00007ec68bfceca5  call 0x00007EC68BDFF540
00007ec68bfcecaa  jmp 0x00007EC68BFCE908
00007ec68bfcecaf  call 0x00007EC68BE0BC20
00007ec68bfcecb4  jmp 0x00007EC68BFCE930
00007ec68bfcecb9  call 0x00007EC68BE0A9A0
00007ec68bfcecbe  jmp 0x00007EC68BFCE93C
00007ec68bfcecc3  call 0x00007EC68BE0E880
00007ec68bfcecc8  jmp 0x00007EC68BFCE949
00007ec68bfceccd  call 0x00007EC68BE0D600
00007ec68bfcecd2  jmp 0x00007EC68BFCE956
00007ec68bfcecd7  call 0x00007EC68BDFF430
00007ec68bfcecdc  jmp 0x00007EC68BFCE961
00007ec68bfcece1  call 0x00007EC68BE0E760
00007ec68bfcece6  jmp 0x00007EC68BFCE96C
00007ec68bfceceb  call 0x00007EC68BE0BC20
00007ec68bfcecf0  jmp 0x00007EC68BFCE99C
00007ec68bfcecf5  call 0x00007EC68BE0A9A0
00007ec68bfcecfa  jmp 0x00007EC68BFCE9A8
00007ec68bfcecff  call 0x00007EC68BE0BC20
00007ec68bfced04  jmp 0x00007EC68BFCE9D0
00007ec68bfced09  call 0x00007EC68BE0A9A0
00007ec68bfced0e  jmp 0x00007EC68BFCE9DC
00007ec68bfced13  call 0x00007EC68BDFF540
00007ec68bfced18  jmp 0x00007EC68BFCE9E9
00007ec68bfced1d  call 0x00007EC68BE0E880
00007ec68bfced22  jmp 0x00007EC68BFCE9F6
00007ec68bfced27  call 0x00007EC68BDFF430
00007ec68bfced2c  jmp 0x00007EC68BFCEA01
00007ec68bfced31  call 0x00007EC68BE0E760
00007ec68bfced36  jmp 0x00007EC68BFCEA0C
00007ec68bfced3b  call 0x00007EC68BE0BC20
00007ec68bfced40  jmp 0x00007EC68BFCEA36
00007ec68bfced45  call 0x00007EC68BE0A9A0
00007ec68bfced4a  jmp 0x00007EC68BFCEA42
00007ec68bfced4f  call 0x00007EC68BE0BAE0
00007ec68bfced54  jmp 0x00007EC68BFCEA52
00007ec68bfced59  call 0x00007EC68BDFF540
00007ec68bfced5e  jmp 0x00007EC68BFCEA5F
00007ec68bfced63  call 0x00007EC68BE0E880
00007ec68bfced68  jmp 0x00007EC68BFCEA6C
00007ec68bfced6d  int3
00007ec68bfced6e  nop
00007ec68bfced70  mov rax, [r15]
00007ec68bfced73  lea r14, [rax+0x20]
00007ec68bfced77  mov r12, [r13+r14*1]
00007ec68bfced7c  mov r14, [r15+0x10]
00007ec68bfced80  lea r11, [r12+r14*1]
00007ec68bfced84  mov [r15+0x40], r11
00007ec68bfced88  lea r12, [rax+0x20]
00007ec68bfced8c  mov [r13+r12*1], r11
00007ec68bfced91  test r14, r14
00007ec68bfced94  setz r14b
00007ec68bfced98  movzx r14, r14b
00007ec68bfced9c  mov [rsp+0x414], r14b
00007ec68bfceda4  cmp byte ptr [rsp+0x414], 0x00
00007ec68bfcedac  jz 0x00007EC68BFCEDDE
00007ec68bfcedae  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcedb6  mov eax, 0x4109A0
00007ec68bfcedbb  mov [r15+0x100], rax
00007ec68bfcedc2  jz 0x00007EC68BDFE0A0
00007ec68bfcedc8  nop [rax+rax*1], eax
00007ec68bfcedcd  mov eax, 0x4109A0
00007ec68bfcedd2  mov [r15+0x100], rax
00007ec68bfcedd9  jmp 0x00007EC68BDFE110
00007ec68bfcedde  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcede6  jz 0x00007EC68BFCEE30
00007ec68bfcedec  nop [rax+rax*1], ax
00007ec68bfcedf5  nop [rax+rax*1], eax
00007ec68bfcedfd  mov eax, 0x410738
00007ec68bfcee02  mov [r15+0x100], rax
00007ec68bfcee09  jmp 0x00007EC68BDFE110
00007ec68bfcee0e  int3
00007ec68bfcee0f  call 0x00007EC68BEE27E0
00007ec68bfcee14  jmp 0x00007EC68BFCED7C
00007ec68bfcee19  call 0x00007EC68BEC0860
00007ec68bfcee1e  jmp 0x00007EC68BFCED91
00007ec68bfcee23  int3
00007ec68bfcee24  nop [rax+rax*1], ax
00007ec68bfcee2d  nop [rax], eax
00007ec68bfcee30  mov rax, [r15+0xF8]
00007ec68bfcee37  lea r14, [rax-0x150]
00007ec68bfcee3e  mov [r15+0xF8], r14
00007ec68bfcee45  mov rax, [r15]
00007ec68bfcee48  lea r12, [rax+0x68]
00007ec68bfcee4c  mov r11, [r13+r12*1]
00007ec68bfcee51  mov [r15+0x88], r11
00007ec68bfcee58  lea r12, [rax+0x28]
00007ec68bfcee5c  mov [r15+0x40], r12
00007ec68bfcee60  mov [r15+0x48], r14
00007ec68bfcee64  mov qword ptr [r15+0x50], 0x420B90
00007ec68bfcee6c  lea rax, [r14+0x100]
00007ec68bfcee73  mov r12, [r15+0xE8]
00007ec68bfcee7a  mov r11, [r15+0xD8]
00007ec68bfcee81  mov [r13+rax*1], r12
00007ec68bfcee86  lea rax, [r14+0x108]
00007ec68bfcee8d  mov [r13+rax*1], r11
00007ec68bfcee92  lea rax, [r14+0x110]
00007ec68bfcee99  mov r12, [r15+0xD0]
00007ec68bfceea0  mov r11, [r15+0xC8]
00007ec68bfceea7  mov [r13+rax*1], r12
00007ec68bfceeac  lea rax, [r14+0x118]
00007ec68bfceeb3  mov [r13+rax*1], r11
00007ec68bfceeb8  lea rax, [r14+0x120]
00007ec68bfceebf  mov r12, [r15+0xC0]
00007ec68bfceec6  mov r11, [r15+0xB8]
00007ec68bfceecd  mov [r13+rax*1], r12
00007ec68bfceed2  lea rax, [r14+0x128]
00007ec68bfceed9  mov [r13+rax*1], r11
00007ec68bfceede  lea rax, [r14+0x130]
00007ec68bfceee5  mov r12, [r15+0xB0]
00007ec68bfceeec  mov r11, [r15+0xA8]
00007ec68bfceef3  mov [r13+rax*1], r12
00007ec68bfceef8  lea rax, [r14+0x138]
00007ec68bfceeff  mov [r13+rax*1], r11
00007ec68bfcef04  lea rax, [r14+0x140]
00007ec68bfcef0b  mov r12, [r15+0xA0]
00007ec68bfcef12  mov r11, [r15+0x98]
00007ec68bfcef19  mov [r13+rax*1], r12
00007ec68bfcef1e  lea rax, [r14+0x148]
00007ec68bfcef25  mov [r13+rax*1], r11
00007ec68bfcef2a  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcef32  jz 0x00007EC68BFCEFD0
00007ec68bfcef38  nop [rax+rax*1], ax
00007ec68bfcef41  nop [rax+rax*1], eax
00007ec68bfcef49  mov eax, 0x410770
00007ec68bfcef4e  mov [r15+0x100], rax
00007ec68bfcef55  jmp 0x00007EC68BDFE110
00007ec68bfcef5a  int3
00007ec68bfcef5b  call 0x00007EC68BEC0370
00007ec68bfcef60  jmp 0x00007EC68BFCEE51
00007ec68bfcef65  call 0x00007EC68BE0BC20
00007ec68bfcef6a  jmp 0x00007EC68BFCEE86
00007ec68bfcef6f  call 0x00007EC68BE0A9A0
00007ec68bfcef74  jmp 0x00007EC68BFCEE92
00007ec68bfcef79  call 0x00007EC68BE0BC20
00007ec68bfcef7e  jmp 0x00007EC68BFCEEAC
00007ec68bfcef83  call 0x00007EC68BE0A9A0
00007ec68bfcef88  jmp 0x00007EC68BFCEEB8
00007ec68bfcef8d  call 0x00007EC68BE0BC20
00007ec68bfcef92  jmp 0x00007EC68BFCEED2
00007ec68bfcef97  call 0x00007EC68BE0A9A0
00007ec68bfcef9c  jmp 0x00007EC68BFCEEDE
00007ec68bfcefa1  call 0x00007EC68BE0BC20
00007ec68bfcefa6  jmp 0x00007EC68BFCEEF8
00007ec68bfcefab  call 0x00007EC68BE0A9A0
00007ec68bfcefb0  jmp 0x00007EC68BFCEF04
00007ec68bfcefb5  call 0x00007EC68BE0BC20
00007ec68bfcefba  jmp 0x00007EC68BFCEF1E
00007ec68bfcefbf  call 0x00007EC68BE0A9A0
00007ec68bfcefc4  jmp 0x00007EC68BFCEF2A
00007ec68bfcefc9  int3
00007ec68bfcefca  nop [rax+rax*1], ax
00007ec68bfcefd0  mov rax, [r15+0x08]
00007ec68bfcefd4  movzx r14d, byte ptr [r13+rax*1]
00007ec68bfcefda  movzx r14d, r14b
00007ec68bfcefde  mov [rsp+0x10], r14d
00007ec68bfcefe3  mov r14d, r14d
00007ec68bfcefe6  mov [r15+0x58], r14
00007ec68bfcefea  lea r14, [rax+0x01]
00007ec68bfcefee  mov [r15+0x08], r14
00007ec68bfceff2  mov rax, [r15+0x88]
00007ec68bfceff9  lea r14, [rax+0x01]
00007ec68bfceffd  mov r12, [r15]
00007ec68bfcf000  lea r11, [r12+0x68]
00007ec68bfcf005  mov [r13+r11*1], r14
00007ec68bfcf00a  lea r14, [r12+rax*1]
00007ec68bfcf00e  mov [r15+0x60], r14
00007ec68bfcf012  lea rax, [r14+0x28]
00007ec68bfcf016  mov r11d, [rsp+0x10]
00007ec68bfcf01b  movzx r14d, r11b
00007ec68bfcf01f  mov [r13+rax*1], r14b
00007ec68bfcf024  lea rax, [r12+0x68]
00007ec68bfcf029  mov r14, [r13+rax*1]
00007ec68bfcf02e  mov [r15+0x88], r14
00007ec68bfcf035  xor eax, eax
00007ec68bfcf037  mov r12d, 0x40
00007ec68bfcf03d  cmp r14, r12
00007ec68bfcf040  cmc
00007ec68bfcf041  lahf
00007ec68bfcf042  seto al
00007ec68bfcf045  mov [r15+0x108], eax
00007ec68bfcf04c  mov eax, [r15+0x108]
00007ec68bfcf053  sahf
00007ec68bfcf054  jnz 0x00007EC68BFCF086
00007ec68bfcf056  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcf05e  jz 0x00007EC68BFCF170
00007ec68bfcf064  nop [rax+rax*1], ax
00007ec68bfcf06d  nop [rax+rax*1], eax
00007ec68bfcf075  mov eax, 0x410790
00007ec68bfcf07a  mov [r15+0x100], rax
00007ec68bfcf081  jmp 0x00007EC68BDFE110
00007ec68bfcf086  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcf08e  jz 0x00007EC68BFCF0E0
00007ec68bfcf094  nop [rax+rax*1], ax
00007ec68bfcf09d  nop [rax+rax*1], eax
00007ec68bfcf0a5  mov eax, 0x410768
00007ec68bfcf0aa  mov [r15+0x100], rax
00007ec68bfcf0b1  jmp 0x00007EC68BDFE110
00007ec68bfcf0b6  int3
00007ec68bfcf0b7  call 0x00007EC68BE0D860
00007ec68bfcf0bc  jmp 0x00007EC68BFCEFDA
00007ec68bfcf0c1  call 0x00007EC68BEB36E0
00007ec68bfcf0c6  jmp 0x00007EC68BFCF00A
00007ec68bfcf0cb  call 0x00007EC68BE0DD60
00007ec68bfcf0d0  jmp 0x00007EC68BFCF024
00007ec68bfcf0d5  call 0x00007EC68BE0DC20
00007ec68bfcf0da  jmp 0x00007EC68BFCF02E
00007ec68bfcf0df  int3
00007ec68bfcf0e0  mov rax, [r15+0x10]
00007ec68bfcf0e4  lea r14, [rax-0x01]
00007ec68bfcf0e8  mov [r15+0x10], r14
00007ec68bfcf0ec  test r14, r14
00007ec68bfcf0ef  setz r14b
00007ec68bfcf0f3  movzx r14, r14b
00007ec68bfcf0f7  mov [rsp+0x414], r14b
00007ec68bfcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007ec68bfcf107  jz 0x00007EC68BFCF139
00007ec68bfcf109  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcf111  jz 0x00007EC68BFD0670
00007ec68bfcf117  nop [rax+rax*1], ax
00007ec68bfcf120  nop [rax+rax*1], eax
00007ec68bfcf128  mov eax, 0x410988
00007ec68bfcf12d  mov [r15+0x100], rax
00007ec68bfcf134  jmp 0x00007EC68BDFE110
00007ec68bfcf139  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcf141  jz 0x00007EC68BFCEFD0
00007ec68bfcf147  nop [rax+rax*1], ax
00007ec68bfcf150  nop [rax+rax*1], eax
00007ec68bfcf158  mov eax, 0x410770
00007ec68bfcf15d  mov [r15+0x100], rax
00007ec68bfcf164  jmp 0x00007EC68BDFE110
00007ec68bfcf169  int3
00007ec68bfcf16a  int3
00007ec68bfcf16b  nop [rax+rax*1], eax
00007ec68bfcf170  mov rax, [r15+0x40]
00007ec68bfcf174  movzx r14d, byte ptr [r13+rax*1]
00007ec68bfcf17a  movaps xmm1, [r15+0x110]
00007ec68bfcf182  pinsrb xmm1, r14d, 0x00
00007ec68bfcf189  lea r14, [rax+0x01]
00007ec68bfcf18d  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf193  movaps xmm15, [r15+0x120]
00007ec68bfcf19b  pinsrb xmm15, r12d, 0x00
00007ec68bfcf1a2  lea r14, [rax+0x02]
00007ec68bfcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf1ac  movaps xmm14, [r15+0x130]
00007ec68bfcf1b4  pinsrb xmm14, r12d, 0x00
00007ec68bfcf1bb  lea r14, [rax+0x03]
00007ec68bfcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf1c5  movaps xmm13, [r15+0x140]
00007ec68bfcf1cd  pinsrb xmm13, r12d, 0x00
00007ec68bfcf1d4  lea r14, [rax+0x04]
00007ec68bfcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf1de  pinsrb xmm1, r12d, 0x01
00007ec68bfcf1e5  lea r14, [rax+0x05]
00007ec68bfcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf1ef  pinsrb xmm15, r12d, 0x01
00007ec68bfcf1f6  lea r14, [rax+0x06]
00007ec68bfcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf200  pinsrb xmm14, r12d, 0x01
00007ec68bfcf207  lea r14, [rax+0x07]
00007ec68bfcf20b  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf211  pinsrb xmm13, r12d, 0x01
00007ec68bfcf218  lea r14, [rax+0x08]
00007ec68bfcf21c  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf222  pinsrb xmm1, r12d, 0x02
00007ec68bfcf229  lea r14, [rax+0x09]
00007ec68bfcf22d  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf233  pinsrb xmm15, r12d, 0x02
00007ec68bfcf23a  lea r14, [rax+0x0A]
00007ec68bfcf23e  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf244  pinsrb xmm14, r12d, 0x02
00007ec68bfcf24b  lea r14, [rax+0x0B]
00007ec68bfcf24f  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf255  pinsrb xmm13, r12d, 0x02
00007ec68bfcf25c  lea r14, [rax+0x0C]
00007ec68bfcf260  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf266  pinsrb xmm1, r12d, 0x03
00007ec68bfcf26d  lea r14, [rax+0x0D]
00007ec68bfcf271  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf277  pinsrb xmm15, r12d, 0x03
00007ec68bfcf27e  lea r14, [rax+0x0E]
00007ec68bfcf282  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf288  pinsrb xmm14, r12d, 0x03
00007ec68bfcf28f  lea r14, [rax+0x0F]
00007ec68bfcf293  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf299  pinsrb xmm13, r12d, 0x03
00007ec68bfcf2a0  lea r14, [rax+0x10]
00007ec68bfcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf2aa  pinsrb xmm1, r12d, 0x04
00007ec68bfcf2b1  lea r14, [rax+0x11]
00007ec68bfcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf2bb  pinsrb xmm15, r12d, 0x04
00007ec68bfcf2c2  lea r14, [rax+0x12]
00007ec68bfcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf2cc  pinsrb xmm14, r12d, 0x04
00007ec68bfcf2d3  lea r14, [rax+0x13]
00007ec68bfcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf2dd  pinsrb xmm13, r12d, 0x04
00007ec68bfcf2e4  lea r14, [rax+0x14]
00007ec68bfcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf2ee  pinsrb xmm1, r12d, 0x05
00007ec68bfcf2f5  lea r14, [rax+0x15]
00007ec68bfcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf2ff  pinsrb xmm15, r12d, 0x05
00007ec68bfcf306  lea r14, [rax+0x16]
00007ec68bfcf30a  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf310  pinsrb xmm14, r12d, 0x05
00007ec68bfcf317  lea r14, [rax+0x17]
00007ec68bfcf31b  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf321  pinsrb xmm13, r12d, 0x05
00007ec68bfcf328  lea r14, [rax+0x18]
00007ec68bfcf32c  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf332  pinsrb xmm1, r12d, 0x06
00007ec68bfcf339  lea r14, [rax+0x19]
00007ec68bfcf33d  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf343  pinsrb xmm15, r12d, 0x06
00007ec68bfcf34a  lea r14, [rax+0x1A]
00007ec68bfcf34e  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf354  pinsrb xmm14, r12d, 0x06
00007ec68bfcf35b  lea r14, [rax+0x1B]
00007ec68bfcf35f  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf365  pinsrb xmm13, r12d, 0x06
00007ec68bfcf36c  lea r14, [rax+0x1C]
00007ec68bfcf370  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf376  pinsrb xmm1, r12d, 0x07
00007ec68bfcf37d  lea r14, [rax+0x1D]
00007ec68bfcf381  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf387  pinsrb xmm15, r12d, 0x07
00007ec68bfcf38e  lea r14, [rax+0x1E]
00007ec68bfcf392  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf398  pinsrb xmm14, r12d, 0x07
00007ec68bfcf39f  lea r14, [rax+0x1F]
00007ec68bfcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf3a9  pinsrb xmm13, r12d, 0x07
00007ec68bfcf3b0  lea r14, [rax+0x20]
00007ec68bfcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf3ba  pinsrb xmm1, r12d, 0x08
00007ec68bfcf3c1  lea r14, [rax+0x21]
00007ec68bfcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf3cb  pinsrb xmm15, r12d, 0x08
00007ec68bfcf3d2  lea r14, [rax+0x22]
00007ec68bfcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf3dc  pinsrb xmm14, r12d, 0x08
00007ec68bfcf3e3  lea r14, [rax+0x23]
00007ec68bfcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf3ed  pinsrb xmm13, r12d, 0x08
00007ec68bfcf3f4  lea r14, [rax+0x24]
00007ec68bfcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf3fe  pinsrb xmm1, r12d, 0x09
00007ec68bfcf405  lea r14, [rax+0x25]
00007ec68bfcf409  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf40f  pinsrb xmm15, r12d, 0x09
00007ec68bfcf416  lea r14, [rax+0x26]
00007ec68bfcf41a  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf420  pinsrb xmm14, r12d, 0x09
00007ec68bfcf427  lea r14, [rax+0x27]
00007ec68bfcf42b  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf431  pinsrb xmm13, r12d, 0x09
00007ec68bfcf438  lea r14, [rax+0x28]
00007ec68bfcf43c  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf442  pinsrb xmm1, r12d, 0x0A
00007ec68bfcf449  lea r14, [rax+0x29]
00007ec68bfcf44d  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf453  pinsrb xmm15, r12d, 0x0A
00007ec68bfcf45a  lea r14, [rax+0x2A]
00007ec68bfcf45e  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf464  pinsrb xmm14, r12d, 0x0A
00007ec68bfcf46b  lea r14, [rax+0x2B]
00007ec68bfcf46f  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf475  pinsrb xmm13, r12d, 0x0A
00007ec68bfcf47c  lea r14, [rax+0x2C]
00007ec68bfcf480  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf486  pinsrb xmm1, r12d, 0x0B
00007ec68bfcf48d  lea r14, [rax+0x2D]
00007ec68bfcf491  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf497  pinsrb xmm15, r12d, 0x0B
00007ec68bfcf49e  lea r14, [rax+0x2E]
00007ec68bfcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf4a8  pinsrb xmm14, r12d, 0x0B
00007ec68bfcf4af  lea r14, [rax+0x2F]
00007ec68bfcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf4b9  pinsrb xmm13, r12d, 0x0B
00007ec68bfcf4c0  lea r14, [rax+0x30]
00007ec68bfcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf4ca  pinsrb xmm1, r12d, 0x0C
00007ec68bfcf4d1  lea r14, [rax+0x31]
00007ec68bfcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf4db  pinsrb xmm15, r12d, 0x0C
00007ec68bfcf4e2  lea r14, [rax+0x32]
00007ec68bfcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf4ec  pinsrb xmm14, r12d, 0x0C
00007ec68bfcf4f3  lea r14, [rax+0x33]
00007ec68bfcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf4fd  pinsrb xmm13, r12d, 0x0C
00007ec68bfcf504  lea r14, [rax+0x34]
00007ec68bfcf508  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf50e  pinsrb xmm1, r12d, 0x0D
00007ec68bfcf515  lea r14, [rax+0x35]
00007ec68bfcf519  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf51f  pinsrb xmm15, r12d, 0x0D
00007ec68bfcf526  lea r14, [rax+0x36]
00007ec68bfcf52a  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf530  pinsrb xmm14, r12d, 0x0D
00007ec68bfcf537  lea r14, [rax+0x37]
00007ec68bfcf53b  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf541  pinsrb xmm13, r12d, 0x0D
00007ec68bfcf548  lea r14, [rax+0x38]
00007ec68bfcf54c  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf552  pinsrb xmm1, r12d, 0x0E
00007ec68bfcf559  lea r14, [rax+0x39]
00007ec68bfcf55d  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf563  pinsrb xmm15, r12d, 0x0E
00007ec68bfcf56a  lea r14, [rax+0x3A]
00007ec68bfcf56e  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf574  pinsrb xmm14, r12d, 0x0E
00007ec68bfcf57b  lea r14, [rax+0x3B]
00007ec68bfcf57f  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf585  pinsrb xmm13, r12d, 0x0E
00007ec68bfcf58c  lea r14, [rax+0x3C]
00007ec68bfcf590  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf596  pinsrb xmm1, r12d, 0x0F
00007ec68bfcf59d  movaps [r15+0x110], xmm1
00007ec68bfcf5a5  lea r14, [rax+0x3D]
00007ec68bfcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf5af  pinsrb xmm15, r12d, 0x0F
00007ec68bfcf5b6  movaps [r15+0x120], xmm15
00007ec68bfcf5be  lea r14, [rax+0x3E]
00007ec68bfcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007ec68bfcf5c8  pinsrb xmm14, r12d, 0x0F
00007ec68bfcf5cf  movaps [r15+0x130], xmm14
00007ec68bfcf5d7  lea r14, [rax+0x3F]
00007ec68bfcf5db  movzx eax, byte ptr [r13+r14*1]
00007ec68bfcf5e1  pinsrb xmm13, eax, 0x0F
00007ec68bfcf5e8  movaps [r15+0x140], xmm13
00007ec68bfcf5f0  movq xmm1, qword ptr [r15+0x120]
00007ec68bfcf5f9  pmovzxbw xmm1, xmm1
00007ec68bfcf5fe  psllw xmm1, 0x00
00007ec68bfcf603  movaps [r15+0x150], xmm1
00007ec68bfcf60b  movq xmm1, qword ptr [r15+0x130]
00007ec68bfcf614  pmovzxbw xmm1, xmm1
00007ec68bfcf619  psllw xmm1, 0x00
00007ec68bfcf61e  movaps [r15+0x160], xmm1
00007ec68bfcf626  movq xmm1, qword ptr [r15+0x110]
00007ec68bfcf62f  pmovzxbw xmm1, xmm1
00007ec68bfcf634  psllw xmm1, 0x00
00007ec68bfcf639  movaps [r15+0x170], xmm1
00007ec68bfcf641  movaps xmm15, [r15+0x110]
00007ec68bfcf649  pextrq rax, xmm15, 0x01
00007ec68bfcf650  movq xmm15, rax
00007ec68bfcf655  pmovzxbw xmm15, xmm15
00007ec68bfcf65b  psllw xmm15, 0x00
00007ec68bfcf661  movaps [r15+0x180], xmm15
00007ec68bfcf669  movaps xmm14, [r15+0x120]
00007ec68bfcf671  pextrq rax, xmm14, 0x01
00007ec68bfcf678  movq xmm14, rax
00007ec68bfcf67d  pmovzxbw xmm14, xmm14
00007ec68bfcf683  psllw xmm14, 0x00
00007ec68bfcf689  movaps [r15+0x210], xmm14
00007ec68bfcf691  movaps xmm13, [r15+0x130]
00007ec68bfcf699  pextrq rax, xmm13, 0x01
00007ec68bfcf6a0  movq xmm13, rax
00007ec68bfcf6a5  pmovzxbw xmm13, xmm13
00007ec68bfcf6ab  psllw xmm13, 0x00
00007ec68bfcf6b1  movaps [r15+0x220], xmm13
00007ec68bfcf6b9  movq xmm12, qword ptr [r15+0x140]
00007ec68bfcf6c2  pmovzxbw xmm12, xmm12
00007ec68bfcf6c8  psllw xmm12, 0x00
00007ec68bfcf6ce  movaps [r15+0x250], xmm12
00007ec68bfcf6d6  movaps xmm12, [r15+0x140]
00007ec68bfcf6de  pextrq rax, xmm12, 0x01
00007ec68bfcf6e5  movq xmm12, rax
00007ec68bfcf6ea  pmovzxbw xmm12, xmm12
00007ec68bfcf6f0  psllw xmm12, 0x00
00007ec68bfcf6f6  movaps [r15+0x110], xmm12
00007ec68bfcf6fe  movq xmm11, qword ptr [r15+0x150]
00007ec68bfcf707  pmovzxwd xmm11, xmm11
00007ec68bfcf70d  pslld xmm11, 0x10
00007ec68bfcf713  movq xmm10, qword ptr [r15+0x160]
00007ec68bfcf71c  pmovzxwd xmm10, xmm10
00007ec68bfcf722  pslld xmm10, 0x08
00007ec68bfcf728  pextrq rax, xmm1, 0x01
00007ec68bfcf72f  movq xmm1, rax
00007ec68bfcf734  pmovzxwd xmm1, xmm1
00007ec68bfcf739  pslld xmm1, 0x00
00007ec68bfcf73e  movaps [r15+0x260], xmm1
00007ec68bfcf746  pextrq rax, xmm15, 0x01
00007ec68bfcf74d  movq xmm15, rax
00007ec68bfcf752  pmovzxwd xmm15, xmm15
00007ec68bfcf758  pslld xmm15, 0x00
00007ec68bfcf75e  movaps [r15+0x270], xmm15
00007ec68bfcf766  movq xmm9, qword ptr [r15+0x170]
00007ec68bfcf76f  pmovzxwd xmm9, xmm9
00007ec68bfcf775  pslld xmm9, 0x00
00007ec68bfcf77b  pextrq rax, xmm14, 0x01
00007ec68bfcf782  movq xmm14, rax
00007ec68bfcf787  pmovzxwd xmm14, xmm14
00007ec68bfcf78d  pslld xmm14, 0x10
00007ec68bfcf793  movaps [r15+0x280], xmm14
00007ec68bfcf79b  movq xmm8, qword ptr [r15+0x180]
00007ec68bfcf7a4  pmovzxwd xmm8, xmm8
00007ec68bfcf7aa  pslld xmm8, 0x00
00007ec68bfcf7b0  movq xmm7, qword ptr [r15+0x210]
00007ec68bfcf7b9  pmovzxwd xmm7, xmm7
00007ec68bfcf7be  pslld xmm7, 0x10
00007ec68bfcf7c3  movaps xmm6, [r15+0x150]
00007ec68bfcf7cb  pextrq rax, xmm6, 0x01
00007ec68bfcf7d2  movq xmm6, rax
00007ec68bfcf7d7  pmovzxwd xmm6, xmm6
00007ec68bfcf7dc  pslld xmm6, 0x10
00007ec68bfcf7e1  por xmm11, xmm10
00007ec68bfcf7e6  movaps [r15+0x230], xmm11
00007ec68bfcf7ee  pextrq rax, xmm13, 0x01
00007ec68bfcf7f5  movq xmm13, rax
00007ec68bfcf7fa  pmovzxwd xmm13, xmm13
00007ec68bfcf800  pslld xmm13, 0x08
00007ec68bfcf806  movaps [r15+0x240], xmm13
00007ec68bfcf80e  movq xmm10, qword ptr [r15+0x220]
00007ec68bfcf817  pmovzxwd xmm10, xmm10
00007ec68bfcf81d  pslld xmm10, 0x08
00007ec68bfcf823  movaps xmm5, [r15+0x160]
00007ec68bfcf82b  pextrq rax, xmm5, 0x01
00007ec68bfcf832  movq xmm5, rax
00007ec68bfcf837  pmovzxwd xmm5, xmm5
00007ec68bfcf83c  pslld xmm5, 0x08
00007ec68bfcf841  pslld xmm9, 0x18
00007ec68bfcf847  pslld xmm15, 0x18
00007ec68bfcf84d  pslld xmm8, 0x18
00007ec68bfcf853  movq xmm4, qword ptr [r15+0x250]
00007ec68bfcf85c  pmovzxwd xmm4, xmm4
00007ec68bfcf861  pslld xmm4, 0x00
00007ec68bfcf866  por xmm14, xmm13
00007ec68bfcf86b  por xmm7, xmm10
00007ec68bfcf870  movaps [r15+0x210], xmm7
00007ec68bfcf878  pslld xmm1, 0x18
00007ec68bfcf87d  movaps [r15+0x220], xmm1
00007ec68bfcf885  por xmm6, xmm5
00007ec68bfcf889  por xmm11, xmm9
00007ec68bfcf88e  movaps [r15+0x160], xmm11
00007ec68bfcf896  pextrq rax, xmm12, 0x01
00007ec68bfcf89d  movq xmm13, rax
00007ec68bfcf8a2  pmovzxwd xmm13, xmm13
00007ec68bfcf8a8  pslld xmm13, 0x00
00007ec68bfcf8ae  movaps [r15+0x170], xmm13
00007ec68bfcf8b6  movq xmm12, qword ptr [r15+0x110]
00007ec68bfcf8bf  pmovzxwd xmm12, xmm12
00007ec68bfcf8c5  pslld xmm12, 0x00
00007ec68bfcf8cb  por xmm14, xmm15
00007ec68bfcf8d0  por xmm7, xmm8
00007ec68bfcf8d5  movaps xmm15, [r15+0x250]
00007ec68bfcf8dd  pextrq rax, xmm15, 0x01
00007ec68bfcf8e4  movq xmm15, rax
00007ec68bfcf8e9  pmovzxwd xmm15, xmm15
00007ec68bfcf8ef  pslld xmm15, 0x00
00007ec68bfcf8f5  movaps [r15+0x180], xmm15
00007ec68bfcf8fd  por xmm6, xmm1
00007ec68bfcf901  movaps [r15+0x150], xmm6
00007ec68bfcf909  por xmm11, xmm4
00007ec68bfcf90e  movaps [r15+0x140], xmm11
00007ec68bfcf916  por xmm7, xmm12
00007ec68bfcf91b  movaps [r15+0x110], xmm7
00007ec68bfcf923  por xmm14, xmm13
00007ec68bfcf928  movaps [r15+0x120], xmm14
00007ec68bfcf930  por xmm6, xmm15
00007ec68bfcf935  movaps [r15+0x130], xmm6
00007ec68bfcf93d  mov rax, [r15+0xF8]
00007ec68bfcf944  lea r14, [rax+0x20]
00007ec68bfcf948  movups [r13+r14*1], xmm7
00007ec68bfcf94e  lea r14, [rax+0x30]
00007ec68bfcf952  movups [r13+r14*1], xmm14
00007ec68bfcf958  movups [r13+rax*1], xmm11
00007ec68bfcf95e  lea r14, [rax+0x10]
00007ec68bfcf962  movups [r13+r14*1], xmm6
00007ec68bfcf968  mov r14d, [r13+rax*1]
00007ec68bfcf96d  mov rax, [r15+0x48]
00007ec68bfcf971  mov [r15+0x68], rax
00007ec68bfcf975  mov qword ptr [r15+0x58], 0x04
00007ec68bfcf97d  lea r12, [rax+0x04]
00007ec68bfcf981  mov r11d, [r13+r12*1]
00007ec68bfcf986  mov [rsp+0x10], r11d
00007ec68bfcf98b  mov r11d, r11d
00007ec68bfcf98e  mov [r15+0x70], r11
00007ec68bfcf992  lea r12, [rax+0x38]
00007ec68bfcf996  mov r11d, [r13+r12*1]
00007ec68bfcf99b  lea r12, [rax+0x24]
00007ec68bfcf99f  mov r10d, [r13+r12*1]
00007ec68bfcf9a4  mov [rsp+0x20], r10d
00007ec68bfcf9a9  mov r10d, r10d
00007ec68bfcf9ac  mov [r15+0x90], r10
00007ec68bfcf9b3  mov [rsp+0x30], rax
00007ec68bfcf9b8  xor eax, eax
00007ec68bfcf9ba  mov r12d, 0x04
00007ec68bfcf9c0  mov r10d, 0xC0
00007ec68bfcf9c6  cmp r12, r10
00007ec68bfcf9c9  cmc
00007ec68bfcf9ca  lahf
00007ec68bfcf9cb  seto al
00007ec68bfcf9ce  mov [r15+0x108], eax
00007ec68bfcf9d5  mov eax, [rsp+0x10]
00007ec68bfcf9d9  mov r12d, [rsp+0x10]
00007ec68bfcf9de  shrd eax, r12d, 0x07
00007ec68bfcf9e3  mov [rsp+0x10], r11d
00007ec68bfcf9e8  mov r10d, [rsp+0x10]
00007ec68bfcf9ed  shrd r11d, r10d, 0x11
00007ec68bfcf9f2  mov r9d, [rsp+0x20]
00007ec68bfcf9f7  lea r8d, [r9d+r14d*1]
00007ec68bfcf9fc  rorx r14d, r12d, 0x12
00007ec68bfcfa02  xor eax, r14d
00007ec68bfcfa05  rorx r14d, r10d, 0x13
00007ec68bfcfa0b  xor r11d, r14d
00007ec68bfcfa0e  mov [rsp+0x10], r11d
00007ec68bfcfa13  mov r11d, r11d
00007ec68bfcfa16  mov [r15+0x88], r11
00007ec68bfcfa1d  mov [rsp+0x20], r12d
00007ec68bfcfa22  shr r12d, 0x03
00007ec68bfcfa26  xor eax, r12d
00007ec68bfcfa29  mov [rsp+0x40], eax
00007ec68bfcfa2d  mov eax, eax
00007ec68bfcfa2f  mov [r15+0x80], rax
00007ec68bfcfa36  shr r10d, 0x0A
00007ec68bfcfa3a  mov eax, [rsp+0x10]
00007ec68bfcfa3e  xor eax, r10d
00007ec68bfcfa41  mov [rsp+0x10], eax
00007ec68bfcfa45  mov eax, eax
00007ec68bfcfa47  mov [r15+0x78], rax
00007ec68bfcfa4b  mov eax, [rsp+0x40]
00007ec68bfcfa4f  lea r14d, [r8d+eax*1]
00007ec68bfcfa54  mov eax, [rsp+0x10]
00007ec68bfcfa58  lea r12d, [r14d+eax*1]
00007ec68bfcfa5d  mov rax, [rsp+0x30]
00007ec68bfcfa62  lea r14, [rax+0x40]
00007ec68bfcfa66  mov [r13+r14*1], r12d
00007ec68bfcfa6b  mov eax, [rsp+0x20]
00007ec68bfcfa6f  mov eax, eax
00007ec68bfcfa71  mov [r15+0x60], rax
00007ec68bfcfa75  mov eax, [r15+0x108]
00007ec68bfcfa7c  sahf
00007ec68bfcfa7d  jnz 0x00007EC68BFCFAAF
00007ec68bfcfa7f  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcfa87  jz 0x00007EC68BFCFF70
00007ec68bfcfa8d  nop [rax+rax*1], ax
00007ec68bfcfa96  nop [rax+rax*1], eax
00007ec68bfcfa9e  mov eax, 0x41088C
00007ec68bfcfaa3  mov [r15+0x100], rax
00007ec68bfcfaaa  jmp 0x00007EC68BDFE110
00007ec68bfcfaaf  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcfab7  jz 0x00007EC68BFCFDC0
00007ec68bfcfabd  nop [rax+rax*1], ax
00007ec68bfcfac6  nop [rax+rax*1], eax
00007ec68bfcface  mov eax, 0x410844
00007ec68bfcfad3  mov [r15+0x100], rax
00007ec68bfcfada  jmp 0x00007EC68BDFE110
00007ec68bfcfadf  int3
00007ec68bfcfae0  call 0x00007EC68BE0D860
00007ec68bfcfae5  jmp 0x00007EC68BFCF17A
00007ec68bfcfaea  call 0x00007EC68BEE2420
00007ec68bfcfaef  jmp 0x00007EC68BFCF193
00007ec68bfcfaf4  call 0x00007EC68BEE2420
00007ec68bfcfaf9  jmp 0x00007EC68BFCF1AC
00007ec68bfcfafe  call 0x00007EC68BEE2420
00007ec68bfcfb03  jmp 0x00007EC68BFCF1C5
00007ec68bfcfb08  call 0x00007EC68BEE2420
00007ec68bfcfb0d  jmp 0x00007EC68BFCF1DE
00007ec68bfcfb12  call 0x00007EC68BEE2420
00007ec68bfcfb17  jmp 0x00007EC68BFCF1EF
00007ec68bfcfb1c  call 0x00007EC68BEE2420
00007ec68bfcfb21  jmp 0x00007EC68BFCF200
00007ec68bfcfb26  call 0x00007EC68BEE2420
00007ec68bfcfb2b  jmp 0x00007EC68BFCF211
00007ec68bfcfb30  call 0x00007EC68BEE2420
00007ec68bfcfb35  jmp 0x00007EC68BFCF222
00007ec68bfcfb3a  call 0x00007EC68BEE2420
00007ec68bfcfb3f  jmp 0x00007EC68BFCF233
00007ec68bfcfb44  call 0x00007EC68BEE2420
00007ec68bfcfb49  jmp 0x00007EC68BFCF244
00007ec68bfcfb4e  call 0x00007EC68BEE2420
00007ec68bfcfb53  jmp 0x00007EC68BFCF255
00007ec68bfcfb58  call 0x00007EC68BEE2420
00007ec68bfcfb5d  jmp 0x00007EC68BFCF266
00007ec68bfcfb62  call 0x00007EC68BEE2420
00007ec68bfcfb67  jmp 0x00007EC68BFCF277
00007ec68bfcfb6c  call 0x00007EC68BEE2420
00007ec68bfcfb71  jmp 0x00007EC68BFCF288
00007ec68bfcfb76  call 0x00007EC68BEE2420
00007ec68bfcfb7b  jmp 0x00007EC68BFCF299
00007ec68bfcfb80  call 0x00007EC68BEE2420
00007ec68bfcfb85  jmp 0x00007EC68BFCF2AA
00007ec68bfcfb8a  call 0x00007EC68BEE2420
00007ec68bfcfb8f  jmp 0x00007EC68BFCF2BB
00007ec68bfcfb94  call 0x00007EC68BEE2420
00007ec68bfcfb99  jmp 0x00007EC68BFCF2CC
00007ec68bfcfb9e  call 0x00007EC68BEE2420
00007ec68bfcfba3  jmp 0x00007EC68BFCF2DD
00007ec68bfcfba8  call 0x00007EC68BEE2420
00007ec68bfcfbad  jmp 0x00007EC68BFCF2EE
00007ec68bfcfbb2  call 0x00007EC68BEE2420
00007ec68bfcfbb7  jmp 0x00007EC68BFCF2FF
00007ec68bfcfbbc  call 0x00007EC68BEE2420
00007ec68bfcfbc1  jmp 0x00007EC68BFCF310
00007ec68bfcfbc6  call 0x00007EC68BEE2420
00007ec68bfcfbcb  jmp 0x00007EC68BFCF321
00007ec68bfcfbd0  call 0x00007EC68BEE2420
00007ec68bfcfbd5  jmp 0x00007EC68BFCF332
00007ec68bfcfbda  call 0x00007EC68BEE2420
00007ec68bfcfbdf  jmp 0x00007EC68BFCF343
00007ec68bfcfbe4  call 0x00007EC68BEE2420
00007ec68bfcfbe9  jmp 0x00007EC68BFCF354
00007ec68bfcfbee  call 0x00007EC68BEE2420
00007ec68bfcfbf3  jmp 0x00007EC68BFCF365
00007ec68bfcfbf8  call 0x00007EC68BEE2420
00007ec68bfcfbfd  jmp 0x00007EC68BFCF376
00007ec68bfcfc02  call 0x00007EC68BEE2420
00007ec68bfcfc07  jmp 0x00007EC68BFCF387
00007ec68bfcfc0c  call 0x00007EC68BEE2420
00007ec68bfcfc11  jmp 0x00007EC68BFCF398
00007ec68bfcfc16  call 0x00007EC68BEE2420
00007ec68bfcfc1b  jmp 0x00007EC68BFCF3A9
00007ec68bfcfc20  call 0x00007EC68BEE2420
00007ec68bfcfc25  jmp 0x00007EC68BFCF3BA
00007ec68bfcfc2a  call 0x00007EC68BEE2420
00007ec68bfcfc2f  jmp 0x00007EC68BFCF3CB
00007ec68bfcfc34  call 0x00007EC68BEE2420
00007ec68bfcfc39  jmp 0x00007EC68BFCF3DC
00007ec68bfcfc3e  call 0x00007EC68BEE2420
00007ec68bfcfc43  jmp 0x00007EC68BFCF3ED
00007ec68bfcfc48  call 0x00007EC68BEE2420
00007ec68bfcfc4d  jmp 0x00007EC68BFCF3FE
00007ec68bfcfc52  call 0x00007EC68BEE2420
00007ec68bfcfc57  jmp 0x00007EC68BFCF40F
00007ec68bfcfc5c  call 0x00007EC68BEE2420
00007ec68bfcfc61  jmp 0x00007EC68BFCF420
00007ec68bfcfc66  call 0x00007EC68BEE2420
00007ec68bfcfc6b  jmp 0x00007EC68BFCF431
00007ec68bfcfc70  call 0x00007EC68BEE2420
00007ec68bfcfc75  jmp 0x00007EC68BFCF442
00007ec68bfcfc7a  call 0x00007EC68BEE2420
00007ec68bfcfc7f  jmp 0x00007EC68BFCF453
00007ec68bfcfc84  call 0x00007EC68BEE2420
00007ec68bfcfc89  jmp 0x00007EC68BFCF464
00007ec68bfcfc8e  call 0x00007EC68BEE2420
00007ec68bfcfc93  jmp 0x00007EC68BFCF475
00007ec68bfcfc98  call 0x00007EC68BEE2420
00007ec68bfcfc9d  jmp 0x00007EC68BFCF486
00007ec68bfcfca2  call 0x00007EC68BEE2420
00007ec68bfcfca7  jmp 0x00007EC68BFCF497
00007ec68bfcfcac  call 0x00007EC68BEE2420
00007ec68bfcfcb1  jmp 0x00007EC68BFCF4A8
00007ec68bfcfcb6  call 0x00007EC68BEE2420
00007ec68bfcfcbb  jmp 0x00007EC68BFCF4B9
00007ec68bfcfcc0  call 0x00007EC68BEE2420
00007ec68bfcfcc5  jmp 0x00007EC68BFCF4CA
00007ec68bfcfcca  call 0x00007EC68BEE2420
00007ec68bfcfccf  jmp 0x00007EC68BFCF4DB
00007ec68bfcfcd4  call 0x00007EC68BEE2420
00007ec68bfcfcd9  jmp 0x00007EC68BFCF4EC
00007ec68bfcfcde  call 0x00007EC68BEE2420
00007ec68bfcfce3  jmp 0x00007EC68BFCF4FD
00007ec68bfcfce8  call 0x00007EC68BEE2420
00007ec68bfcfced  jmp 0x00007EC68BFCF50E
00007ec68bfcfcf2  call 0x00007EC68BEE2420
00007ec68bfcfcf7  jmp 0x00007EC68BFCF51F
00007ec68bfcfcfc  call 0x00007EC68BEE2420
00007ec68bfcfd01  jmp 0x00007EC68BFCF530
00007ec68bfcfd06  call 0x00007EC68BEE2420
00007ec68bfcfd0b  jmp 0x00007EC68BFCF541
00007ec68bfcfd10  call 0x00007EC68BEE2420
00007ec68bfcfd15  jmp 0x00007EC68BFCF552
00007ec68bfcfd1a  call 0x00007EC68BEE2420
00007ec68bfcfd1f  jmp 0x00007EC68BFCF563
00007ec68bfcfd24  call 0x00007EC68BEE2420
00007ec68bfcfd29  jmp 0x00007EC68BFCF574
00007ec68bfcfd2e  call 0x00007EC68BEE2420
00007ec68bfcfd33  jmp 0x00007EC68BFCF585
00007ec68bfcfd38  call 0x00007EC68BEE2420
00007ec68bfcfd3d  jmp 0x00007EC68BFCF596
00007ec68bfcfd42  call 0x00007EC68BEE2420
00007ec68bfcfd47  jmp 0x00007EC68BFCF5AF
00007ec68bfcfd4c  call 0x00007EC68BEE2420
00007ec68bfcfd51  jmp 0x00007EC68BFCF5C8
00007ec68bfcfd56  call 0x00007EC68BED5610
00007ec68bfcfd5b  jmp 0x00007EC68BFCF5E1
00007ec68bfcfd60  call 0x00007EC68BEDC580
00007ec68bfcfd65  jmp 0x00007EC68BFCF94E
00007ec68bfcfd6a  call 0x00007EC68BEE46C0
00007ec68bfcfd6f  jmp 0x00007EC68BFCF958
00007ec68bfcfd74  call 0x00007EC68BE09E90
00007ec68bfcfd79  jmp 0x00007EC68BFCF95E
00007ec68bfcfd7e  call 0x00007EC68BEDB310
00007ec68bfcfd83  jmp 0x00007EC68BFCF968
00007ec68bfcfd88  call 0x00007EC68BE0DAE0
00007ec68bfcfd8d  jmp 0x00007EC68BFCF96D
00007ec68bfcfd92  call 0x00007EC68BEC0230
00007ec68bfcfd97  jmp 0x00007EC68BFCF986
00007ec68bfcfd9c  call 0x00007EC68BEC0230
00007ec68bfcfda1  jmp 0x00007EC68BFCF99B
00007ec68bfcfda6  call 0x00007EC68BEBEFC0
00007ec68bfcfdab  jmp 0x00007EC68BFCF9A4
00007ec68bfcfdb0  call 0x00007EC68BEE2BA0
00007ec68bfcfdb5  jmp 0x00007EC68BFCFA6B
00007ec68bfcfdba  int3
00007ec68bfcfdbb  nop [rax+rax*1], eax
00007ec68bfcfdc0  mov rax, [r15+0x48]
00007ec68bfcfdc4  mov r14, [r15+0x58]
00007ec68bfcfdc8  lea r12, [rax+r14*1]
00007ec68bfcfdcc  mov [r15+0x68], r12
00007ec68bfcfdd0  lea rax, [r14+0x04]
00007ec68bfcfdd4  mov [r15+0x58], rax
00007ec68bfcfdd8  lea r14, [r12+0x04]
00007ec68bfcfddd  mov r11d, [r13+r14*1]
00007ec68bfcfde2  mov [rsp+0x10], r11d
00007ec68bfcfde7  mov r11d, r11d
00007ec68bfcfdea  mov [r15+0x70], r11
00007ec68bfcfdee  lea r14, [r12+0x38]
00007ec68bfcfdf3  mov r11d, [r13+r14*1]
00007ec68bfcfdf8  lea r14, [r12+0x24]
00007ec68bfcfdfd  mov r10d, [r13+r14*1]
00007ec68bfcfe02  mov [rsp+0x20], r10d
00007ec68bfcfe07  mov r10d, r10d
00007ec68bfcfe0a  mov [r15+0x90], r10
00007ec68bfcfe11  mov [rsp+0x30], rax
00007ec68bfcfe16  xor eax, eax
00007ec68bfcfe18  mov r14, [rsp+0x30]
00007ec68bfcfe1d  mov r10d, 0xC0
00007ec68bfcfe23  cmp r14, r10
00007ec68bfcfe26  cmc
00007ec68bfcfe27  lahf
00007ec68bfcfe28  seto al
00007ec68bfcfe2b  mov [r15+0x108], eax
00007ec68bfcfe32  mov eax, [rsp+0x10]
00007ec68bfcfe36  mov r14d, [rsp+0x10]
00007ec68bfcfe3b  shrd eax, r14d, 0x07
00007ec68bfcfe40  mov [rsp+0x10], r11d
00007ec68bfcfe45  mov r10d, [rsp+0x10]
00007ec68bfcfe4a  shrd r11d, r10d, 0x11
00007ec68bfcfe4f  mov r9d, [r15+0x60]
00007ec68bfcfe53  mov r8d, [rsp+0x20]
00007ec68bfcfe58  lea ebp, [r8d+r9d*1]
00007ec68bfcfe5d  rorx r9d, r14d, 0x12
00007ec68bfcfe63  xor eax, r9d
00007ec68bfcfe66  rorx r9d, r10d, 0x13
00007ec68bfcfe6c  xor r11d, r9d
00007ec68bfcfe6f  mov [rsp+0x10], r11d
00007ec68bfcfe74  mov r11d, r11d
00007ec68bfcfe77  mov [r15+0x88], r11
00007ec68bfcfe7e  mov [rsp+0x20], r14d
00007ec68bfcfe83  shr r14d, 0x03
00007ec68bfcfe87  xor eax, r14d
00007ec68bfcfe8a  mov [rsp+0x30], eax
00007ec68bfcfe8e  mov eax, eax
00007ec68bfcfe90  mov [r15+0x80], rax
00007ec68bfcfe97  shr r10d, 0x0A
00007ec68bfcfe9b  mov eax, [rsp+0x10]
00007ec68bfcfe9f  xor eax, r10d
00007ec68bfcfea2  mov [rsp+0x10], eax
00007ec68bfcfea6  mov eax, eax
00007ec68bfcfea8  mov [r15+0x78], rax
00007ec68bfcfeac  mov eax, [rsp+0x30]
00007ec68bfcfeb0  lea r14d, [ebp+eax*1]
00007ec68bfcfeb6  mov eax, [rsp+0x10]
00007ec68bfcfeba  lea r11d, [r14d+eax*1]
00007ec68bfcfebf  lea rax, [r12+0x40]
00007ec68bfcfec4  mov [r13+rax*1], r11d
00007ec68bfcfec9  mov eax, [rsp+0x20]
00007ec68bfcfecd  mov eax, eax
00007ec68bfcfecf  mov [r15+0x60], rax
00007ec68bfcfed3  mov eax, [r15+0x108]
00007ec68bfcfeda  sahf
00007ec68bfcfedb  jnz 0x00007EC68BFCFF0D
00007ec68bfcfedd  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcfee5  jz 0x00007EC68BFCFF70
00007ec68bfcfeeb  nop [rax+rax*1], ax
00007ec68bfcfef4  nop [rax+rax*1], eax
00007ec68bfcfefc  mov eax, 0x41088C
00007ec68bfcff01  mov [r15+0x100], rax
00007ec68bfcff08  jmp 0x00007EC68BDFE110
00007ec68bfcff0d  cmp dword ptr [r15+0x318], 0x00
00007ec68bfcff15  jz 0x00007EC68BFCFDC0
00007ec68bfcff1b  nop [rax+rax*1], ax
00007ec68bfcff24  nop [rax+rax*1], eax
00007ec68bfcff2c  mov eax, 0x410844
00007ec68bfcff31  mov [r15+0x100], rax
00007ec68bfcff38  jmp 0x00007EC68BDFE110
00007ec68bfcff3d  int3
00007ec68bfcff3e  call 0x00007EC68BEE1430
00007ec68bfcff43  jmp 0x00007EC68BFCFDE2
00007ec68bfcff48  call 0x00007EC68BEE1430
00007ec68bfcff4d  jmp 0x00007EC68BFCFDF8
00007ec68bfcff52  call 0x00007EC68BEE01C0
00007ec68bfcff57  jmp 0x00007EC68BFCFE02
00007ec68bfcff5c  call 0x00007EC68BE0A860
00007ec68bfcff61  jmp 0x00007EC68BFCFEC9
00007ec68bfcff66  int3
00007ec68bfcff67  nop [rax+rax*1], ax
00007ec68bfcff70  mov rax, [r15]
00007ec68bfcff73  mov r14d, [r13+rax*1]
00007ec68bfcff78  lea r12, [rax+0x04]
00007ec68bfcff7c  mov r11d, [r13+r12*1]
00007ec68bfcff81  mov [rsp+0x10], r14d
00007ec68bfcff86  mov r14d, r14d
00007ec68bfcff89  mov [r15+0x78], r14
00007ec68bfcff8d  mov [rsp+0x20], r11d
00007ec68bfcff92  mov r11d, r11d
00007ec68bfcff95  mov [r15+0x80], r11
00007ec68bfcff9c  lea r14, [rax+0x08]
00007ec68bfcffa0  mov r12d, [r13+r14*1]
00007ec68bfcffa5  lea r14, [rax+0x0C]
00007ec68bfcffa9  mov r11d, [r13+r14*1]
00007ec68bfcffae  mov [rsp+0x30], r12d
00007ec68bfcffb3  mov r12d, r12d
00007ec68bfcffb6  mov [r15+0x70], r12
00007ec68bfcffba  mov [rsp+0x40], r11d
00007ec68bfcffbf  mov r11d, r11d
00007ec68bfcffc2  mov [r15+0x68], r11
00007ec68bfcffc6  lea r14, [rax+0x18]
00007ec68bfcffca  mov r12d, [r13+r14*1]
00007ec68bfcffcf  lea r14, [rax+0x1C]
00007ec68bfcffd3  mov r11d, [r13+r14*1]
00007ec68bfcffd8  mov [rsp+0x50], r12d
00007ec68bfcffdd  mov r12d, r12d
00007ec68bfcffe0  mov [r15+0x58], r12
00007ec68bfcffe4  mov [rsp+0x60], r11d
00007ec68bfcffe9  mov r11d, r11d
00007ec68bfcffec  mov [r15+0x60], r11
00007ec68bfcfff0  lea r14, [rax+0x10]
00007ec68bfcfff4  mov r12d, [r13+r14*1]
00007ec68bfcfff9  lea r14, [rax+0x14]
00007ec68bfcfffd  mov eax, [r13+r14*1]
00007ec68bfd0002  mov [rsp+0x70], r12d
00007ec68bfd0007  mov r12d, r12d
00007ec68bfd000a  mov [r15+0x18], r12
00007ec68bfd000e  mov [rsp+0x80], eax
00007ec68bfd0015  mov eax, eax
00007ec68bfd0017  mov [r15+0x90], rax
00007ec68bfd001e  mov eax, [rsp+0x70]
00007ec68bfd0022  mov eax, eax
00007ec68bfd0024  mov [r15+0x30], rax
00007ec68bfd0028  mov eax, [rsp+0x50]
00007ec68bfd002c  mov eax, eax
00007ec68bfd002e  mov [r15+0xA0], rax
00007ec68bfd0035  mov eax, [rsp+0x30]
00007ec68bfd0039  mov eax, eax
00007ec68bfd003b  mov [r15+0x28], rax
00007ec68bfd003f  mov eax, [rsp+0x20]
00007ec68bfd0043  mov eax, eax
00007ec68bfd0045  mov [r15+0x98], rax
00007ec68bfd004c  mov eax, [rsp+0x10]
00007ec68bfd0050  mov eax, eax
00007ec68bfd0052  mov [r15+0x38], rax
00007ec68bfd0056  mov eax, [rsp+0x70]
00007ec68bfd005a  mov r14d, [rsp+0x70]
00007ec68bfd005f  shrd eax, r14d, 0x06
00007ec68bfd0064  mov [rsp+0x70], r14d
00007ec68bfd0069  mov r12d, [rsp+0x80]
00007ec68bfd0071  and r14d, r12d
00007ec68bfd0074  mov r11d, [rsp+0x10]
00007ec68bfd0079  mov r10d, [rsp+0x10]
00007ec68bfd007e  shrd r11d, r10d, 0x02
00007ec68bfd0083  mov [rsp+0x10], r12d
00007ec68bfd0088  mov r12d, r12d
00007ec68bfd008b  mov [r15+0x20], r12
00007ec68bfd008f  mov r12, [r15+0x50]
00007ec68bfd0093  mov r9d, [r13+r12*1]
00007ec68bfd0098  mov r12d, [rsp+0x50]
00007ec68bfd009d  mov r8d, [rsp+0x70]
00007ec68bfd00a2  andn ebp, r8d, r12d
00007ec68bfd00a7  mov edi, [rsp+0x60]
00007ec68bfd00ab  lea esi, [r14d+edi*1]
00007ec68bfd00b0  rorx r14d, r8d, 0x0B
00007ec68bfd00b6  xor eax, r14d
00007ec68bfd00b9  rorx r14d, r10d, 0x0D
00007ec68bfd00bf  xor r11d, r14d
00007ec68bfd00c2  lea edi, [esi+ebp*1]
00007ec68bfd00c6  mov r14, [r15+0x48]
00007ec68bfd00ca  mov ebp, [r13+r14*1]
00007ec68bfd00cf  mov r14d, [rsp+0x30]
00007ec68bfd00d4  mov esi, [rsp+0x20]
00007ec68bfd00d8  and r14d, esi
00007ec68bfd00db  mov [rsp+0x20], r14d
00007ec68bfd00e0  mov r14d, r14d
00007ec68bfd00e3  mov [r15+0xD8], r14
00007ec68bfd00ea  lea r14d, [edi+r9d*1]
00007ec68bfd00ef  mov r9d, [rsp+0x30]
00007ec68bfd00f4  xor r9d, esi
00007ec68bfd00f7  rorx edi, r8d, 0x19
00007ec68bfd00fd  xor eax, edi
00007ec68bfd00ff  and r9d, r10d
00007ec68bfd0102  rorx edi, r10d, 0x16
00007ec68bfd0108  xor r11d, edi
00007ec68bfd010b  mov [rsp+0x30], r11d
00007ec68bfd0110  mov r11d, r11d
00007ec68bfd0113  mov [r15+0xD0], r11
00007ec68bfd011a  lea r11d, [r14d+ebp*1]
00007ec68bfd011f  mov r10d, [rsp+0x20]
00007ec68bfd0124  xor r9d, r10d
00007ec68bfd0127  lea r14d, [r11d+eax*1]
00007ec68bfd012c  mov qword ptr [r15+0x88], 0x04
00007ec68bfd0137  mov eax, [rsp+0x30]
00007ec68bfd013b  lea r11d, [r9d+eax*1]
00007ec68bfd0140  mov eax, [rsp+0x40]
00007ec68bfd0144  lea r10d, [r14d+eax*1]
00007ec68bfd0149  mov r10d, r10d
00007ec68bfd014c  mov [r15+0xB8], r10
00007ec68bfd0153  xor eax, eax
00007ec68bfd0155  mov r10d, 0x04
00007ec68bfd015b  mov r9d, 0x100
00007ec68bfd0161  cmp r10, r9
00007ec68bfd0164  cmc
00007ec68bfd0165  lahf
00007ec68bfd0166  seto al
00007ec68bfd0169  mov [r15+0x108], eax
00007ec68bfd0170  lea eax, [r11d+r14d*1]
00007ec68bfd0175  mov eax, eax
00007ec68bfd0177  mov [r15+0xA8], rax
00007ec68bfd017e  mov r12d, r12d
00007ec68bfd0181  mov [r15+0xB0], r12
00007ec68bfd0188  mov eax, [rsp+0x10]
00007ec68bfd018c  mov eax, eax
00007ec68bfd018e  mov [r15+0xC0], rax
00007ec68bfd0195  mov r8d, r8d
00007ec68bfd0198  mov [r15+0xC8], r8
00007ec68bfd019f  mov eax, [r15+0x108]
00007ec68bfd01a6  sahf
00007ec68bfd01a7  jnz 0x00007EC68BFD01D9
00007ec68bfd01a9  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd01b1  jz 0x00007EC68BFD04A0
00007ec68bfd01b7  nop [rax+rax*1], ax
00007ec68bfd01c0  nop [rax+rax*1], eax
00007ec68bfd01c8  mov eax, 0x41094C
00007ec68bfd01cd  mov [r15+0x100], rax
00007ec68bfd01d4  jmp 0x00007EC68BDFE110
00007ec68bfd01d9  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd01e1  jz 0x00007EC68BFD0270
00007ec68bfd01e7  nop [rax+rax*1], ax
00007ec68bfd01f0  nop [rax+rax*1], eax
00007ec68bfd01f8  mov eax, 0x4108C0
00007ec68bfd01fd  mov [r15+0x100], rax
00007ec68bfd0204  jmp 0x00007EC68BDFE110
00007ec68bfd0209  int3
00007ec68bfd020a  call 0x00007EC68BE0DAE0
00007ec68bfd020f  jmp 0x00007EC68BFCFF78
00007ec68bfd0214  call 0x00007EC68BEC0230
00007ec68bfd0219  jmp 0x00007EC68BFCFF81
00007ec68bfd021e  call 0x00007EC68BEE26A0
00007ec68bfd0223  jmp 0x00007EC68BFCFFA5
00007ec68bfd0228  call 0x00007EC68BEE1430
00007ec68bfd022d  jmp 0x00007EC68BFCFFAE
00007ec68bfd0232  call 0x00007EC68BEE26A0
00007ec68bfd0237  jmp 0x00007EC68BFCFFCF
00007ec68bfd023c  call 0x00007EC68BEE1430
00007ec68bfd0241  jmp 0x00007EC68BFCFFD8
00007ec68bfd0246  call 0x00007EC68BEE26A0
00007ec68bfd024b  jmp 0x00007EC68BFCFFF9
00007ec68bfd0250  call 0x00007EC68BED5890
00007ec68bfd0255  jmp 0x00007EC68BFD0002
00007ec68bfd025a  call 0x00007EC68BEBDD50
00007ec68bfd025f  jmp 0x00007EC68BFD0098
00007ec68bfd0264  call 0x00007EC68BEDA580
00007ec68bfd0269  jmp 0x00007EC68BFD00CF
00007ec68bfd026e  int3
00007ec68bfd026f  nop
00007ec68bfd0270  mov eax, [r15+0xB8]
00007ec68bfd0277  mov [rsp+0x10], eax
00007ec68bfd027b  mov eax, eax
00007ec68bfd027d  mov [r15+0x30], rax
00007ec68bfd0281  mov eax, [r15+0xC0]
00007ec68bfd0288  mov [rsp+0x20], eax
00007ec68bfd028c  mov eax, eax
00007ec68bfd028e  mov [r15+0xA0], rax
00007ec68bfd0295  mov eax, [r15+0x28]
00007ec68bfd0299  mov r14d, [r15+0x98]
00007ec68bfd02a0  mov [rsp+0x30], r14d
00007ec68bfd02a5  mov r14d, r14d
00007ec68bfd02a8  mov [r15+0x28], r14
00007ec68bfd02ac  mov r14d, [r15+0x38]
00007ec68bfd02b0  mov [rsp+0x40], r14d
00007ec68bfd02b5  mov r14d, r14d
00007ec68bfd02b8  mov [r15+0x98], r14
00007ec68bfd02bf  mov r14d, [r15+0xA8]
00007ec68bfd02c6  mov [rsp+0x50], r14d
00007ec68bfd02cb  mov r14d, r14d
00007ec68bfd02ce  mov [r15+0x38], r14
00007ec68bfd02d2  mov r14d, [rsp+0x10]
00007ec68bfd02d7  mov r12d, [rsp+0x10]
00007ec68bfd02dc  shrd r14d, r12d, 0x06
00007ec68bfd02e1  mov r11d, [r15+0xC8]
00007ec68bfd02e8  mov [rsp+0x10], r12d
00007ec68bfd02ed  and r12d, r11d
00007ec68bfd02f0  mov r10d, [rsp+0x50]
00007ec68bfd02f5  mov r9d, [rsp+0x50]
00007ec68bfd02fa  shrd r10d, r9d, 0x02
00007ec68bfd02ff  mov [rsp+0x50], r11d
00007ec68bfd0304  mov r11d, r11d
00007ec68bfd0307  mov [r15+0x20], r11
00007ec68bfd030b  mov r11, [r15+0x88]
00007ec68bfd0312  mov r8, [r15+0x50]
00007ec68bfd0316  lea rbp, [r8+r11*1]
00007ec68bfd031a  mov r8d, [r13+rbp*1]
00007ec68bfd031f  mov ebp, [rsp+0x20]
00007ec68bfd0323  mov edi, [rsp+0x10]
00007ec68bfd0327  andn esi, edi, ebp
00007ec68bfd032c  mov edx, [r15+0xB0]
00007ec68bfd0333  lea ecx, [r12d+edx*1]
00007ec68bfd0338  rorx r12d, edi, 0x0B
00007ec68bfd033e  xor r14d, r12d
00007ec68bfd0341  rorx r12d, r9d, 0x0D
00007ec68bfd0347  xor r10d, r12d
00007ec68bfd034a  lea r12d, [ecx+esi*1]
00007ec68bfd034f  mov rsi, [r15+0x48]
00007ec68bfd0353  lea rdx, [rsi+r11*1]
00007ec68bfd0357  mov esi, [r13+rdx*1]
00007ec68bfd035c  mov edx, [rsp+0x30]
00007ec68bfd0360  mov ecx, [rsp+0x40]
00007ec68bfd0364  and edx, ecx
00007ec68bfd0366  mov [rsp+0x10], edx
00007ec68bfd036a  mov edx, edx
00007ec68bfd036c  mov [r15+0xD8], rdx
00007ec68bfd0373  lea edx, [r12d+r8d*1]
00007ec68bfd0378  mov r12d, [rsp+0x30]
00007ec68bfd037d  xor r12d, ecx
00007ec68bfd0380  rorx r8d, edi, 0x19
00007ec68bfd0386  xor r14d, r8d
00007ec68bfd0389  and r12d, r9d
00007ec68bfd038c  rorx r8d, r9d, 0x16
00007ec68bfd0392  xor r10d, r8d
00007ec68bfd0395  mov [rsp+0x20], r10d
00007ec68bfd039a  mov r10d, r10d
00007ec68bfd039d  mov [r15+0xD0], r10
00007ec68bfd03a4  lea r10d, [edx+esi*1]
00007ec68bfd03a9  mov r9d, [rsp+0x10]
00007ec68bfd03ae  xor r12d, r9d
00007ec68bfd03b1  lea r9d, [r10d+r14d*1]
00007ec68bfd03b6  lea r14, [r11+0x04]
00007ec68bfd03ba  mov [r15+0x88], r14
00007ec68bfd03c1  mov r11d, [rsp+0x20]
00007ec68bfd03c6  lea r10d, [r12d+r11d*1]
00007ec68bfd03cb  lea r11d, [r9d+eax*1]
00007ec68bfd03d0  mov r11d, r11d
00007ec68bfd03d3  mov [r15+0xB8], r11
00007ec68bfd03da  xor eax, eax
00007ec68bfd03dc  mov r12d, 0x100
00007ec68bfd03e2  cmp r14, r12
00007ec68bfd03e5  cmc
00007ec68bfd03e6  lahf
00007ec68bfd03e7  seto al
00007ec68bfd03ea  mov [r15+0x108], eax
00007ec68bfd03f1  lea eax, [r10d+r9d*1]
00007ec68bfd03f6  mov eax, eax
00007ec68bfd03f8  mov [r15+0xA8], rax
00007ec68bfd03ff  mov ebp, ebp
00007ec68bfd0401  mov [r15+0xB0], rbp
00007ec68bfd0408  mov eax, [rsp+0x50]
00007ec68bfd040c  mov eax, eax
00007ec68bfd040e  mov [r15+0xC0], rax
00007ec68bfd0415  mov edi, edi
00007ec68bfd0417  mov [r15+0xC8], rdi
00007ec68bfd041e  mov eax, [r15+0x108]
00007ec68bfd0425  sahf
00007ec68bfd0426  jnz 0x00007EC68BFD0458
00007ec68bfd0428  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0430  jz 0x00007EC68BFD04A0
00007ec68bfd0436  nop [rax+rax*1], ax
00007ec68bfd043f  nop [rax+rax*1], eax
00007ec68bfd0447  mov eax, 0x41094C
00007ec68bfd044c  mov [r15+0x100], rax
00007ec68bfd0453  jmp 0x00007EC68BDFE110
00007ec68bfd0458  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0460  jz 0x00007EC68BFD0270
00007ec68bfd0466  nop [rax+rax*1], ax
00007ec68bfd046f  nop [rax+rax*1], eax
00007ec68bfd0477  mov eax, 0x4108C0
00007ec68bfd047c  mov [r15+0x100], rax
00007ec68bfd0483  jmp 0x00007EC68BDFE110
00007ec68bfd0488  int3
00007ec68bfd0489  call 0x00007EC68BE49010
00007ec68bfd048e  jmp 0x00007EC68BFD031F
00007ec68bfd0493  call 0x00007EC68BE25930
00007ec68bfd0498  jmp 0x00007EC68BFD035C
00007ec68bfd049d  int3
00007ec68bfd049e  nop
00007ec68bfd04a0  mov eax, [r15+0x98]
00007ec68bfd04a7  mov r14d, [r15+0x70]
00007ec68bfd04ab  lea r12d, [eax+r14d*1]
00007ec68bfd04b0  mov eax, [r15+0x28]
00007ec68bfd04b4  mov r14d, [r15+0x68]
00007ec68bfd04b8  lea r11d, [eax+r14d*1]
00007ec68bfd04bd  mov qword ptr [r15+0x88], 0x00
00007ec68bfd04c8  mov eax, [r15+0xA8]
00007ec68bfd04cf  mov r14d, [r15+0x78]
00007ec68bfd04d3  lea r10d, [eax+r14d*1]
00007ec68bfd04d8  mov [rsp+0x10], r10d
00007ec68bfd04dd  mov r10d, r10d
00007ec68bfd04e0  mov [r15+0x78], r10
00007ec68bfd04e4  mov eax, [r15+0x38]
00007ec68bfd04e8  mov r14d, [r15+0x80]
00007ec68bfd04ef  lea r10d, [eax+r14d*1]
00007ec68bfd04f4  mov [rsp+0x20], r10d
00007ec68bfd04f9  mov r10d, r10d
00007ec68bfd04fc  mov [r15+0x80], r10
00007ec68bfd0503  mov rax, [r15]
00007ec68bfd0506  lea r14, [rax+0x08]
00007ec68bfd050a  mov [r13+r14*1], r12d
00007ec68bfd050f  lea r14, [rax+0x0C]
00007ec68bfd0513  mov [r13+r14*1], r11d
00007ec68bfd0518  mov r14d, [r15+0xB8]
00007ec68bfd051f  mov r12d, [r15+0x18]
00007ec68bfd0523  lea r11d, [r14d+r12d*1]
00007ec68bfd0528  mov [rsp+0x30], r11d
00007ec68bfd052d  mov r11d, r11d
00007ec68bfd0530  mov [r15+0x68], r11
00007ec68bfd0534  mov r14d, [r15+0x30]
00007ec68bfd0538  mov r12d, [r15+0x90]
00007ec68bfd053f  lea r11d, [r14d+r12d*1]
00007ec68bfd0544  mov [rsp+0x40], r11d
00007ec68bfd0549  mov r11d, r11d
00007ec68bfd054c  mov [r15+0x70], r11
00007ec68bfd0550  mov r14d, [r15+0x20]
00007ec68bfd0554  mov r12d, [r15+0x58]
00007ec68bfd0558  lea r11d, [r14d+r12d*1]
00007ec68bfd055d  mov [rsp+0x50], r11d
00007ec68bfd0562  mov r11d, r11d
00007ec68bfd0565  mov [r15+0x58], r11
00007ec68bfd0569  mov r14d, [r15+0xA0]
00007ec68bfd0570  mov r12d, [r15+0x60]
00007ec68bfd0574  lea r11d, [r14d+r12d*1]
00007ec68bfd0579  mov [rsp+0x60], r11d
00007ec68bfd057e  mov r11d, r11d
00007ec68bfd0581  mov [r15+0x60], r11
00007ec68bfd0585  mov r14d, [rsp+0x10]
00007ec68bfd058a  mov [r13+rax*1], r14d
00007ec68bfd058f  lea r14, [rax+0x04]
00007ec68bfd0593  mov r12d, [rsp+0x20]
00007ec68bfd0598  mov [r13+r14*1], r12d
00007ec68bfd059d  lea r14, [rax+0x10]
00007ec68bfd05a1  mov r12d, [rsp+0x30]
00007ec68bfd05a6  mov [r13+r14*1], r12d
00007ec68bfd05ab  lea r14, [rax+0x14]
00007ec68bfd05af  mov r12d, [rsp+0x40]
00007ec68bfd05b4  mov [r13+r14*1], r12d
00007ec68bfd05b9  lea r14, [rax+0x18]
00007ec68bfd05bd  mov r12d, [rsp+0x50]
00007ec68bfd05c2  mov [r13+r14*1], r12d
00007ec68bfd05c7  lea r14, [rax+0x1C]
00007ec68bfd05cb  mov r12d, [rsp+0x60]
00007ec68bfd05d0  mov [r13+r14*1], r12d
00007ec68bfd05d5  lea r14, [rax+0x68]
00007ec68bfd05d9  xor eax, eax
00007ec68bfd05db  mov [r13+r14*1], rax
00007ec68bfd05e0  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd05e8  jz 0x00007EC68BFCF0E0
00007ec68bfd05ee  nop [rax+rax*1], ax
00007ec68bfd05f7  nop [rax+rax*1], eax
00007ec68bfd05ff  mov eax, 0x410768
00007ec68bfd0604  mov [r15+0x100], rax
00007ec68bfd060b  jmp 0x00007EC68BDFE110
00007ec68bfd0610  int3
00007ec68bfd0611  call 0x00007EC68BEE2BA0
00007ec68bfd0616  jmp 0x00007EC68BFD050F
00007ec68bfd061b  call 0x00007EC68BEE1920
00007ec68bfd0620  jmp 0x00007EC68BFD0518
00007ec68bfd0625  call 0x00007EC68BE0DFE0
00007ec68bfd062a  jmp 0x00007EC68BFD058F
00007ec68bfd062f  call 0x00007EC68BEE2BA0
00007ec68bfd0634  jmp 0x00007EC68BFD059D
00007ec68bfd0639  call 0x00007EC68BEE2BA0
00007ec68bfd063e  jmp 0x00007EC68BFD05AB
00007ec68bfd0643  call 0x00007EC68BEE2BA0
00007ec68bfd0648  jmp 0x00007EC68BFD05B9
00007ec68bfd064d  call 0x00007EC68BEE2BA0
00007ec68bfd0652  jmp 0x00007EC68BFD05C7
00007ec68bfd0657  call 0x00007EC68BEE2BA0
00007ec68bfd065c  jmp 0x00007EC68BFD05D5
00007ec68bfd0661  call 0x00007EC68BED5EB0
00007ec68bfd0666  jmp 0x00007EC68BFD05E0
00007ec68bfd066b  int3
00007ec68bfd066c  nop [rax], eax
00007ec68bfd0670  mov rax, [r15+0xF8]
00007ec68bfd0677  lea r14, [rax+0x140]
00007ec68bfd067e  mov r12, [r13+r14*1]
00007ec68bfd0683  lea r14, [rax+0x148]
00007ec68bfd068a  mov r11, [r13+r14*1]
00007ec68bfd068f  mov [r15+0xA0], r12
00007ec68bfd0696  mov [r15+0x98], r11
00007ec68bfd069d  lea r14, [rax+0x130]
00007ec68bfd06a4  mov r12, [r13+r14*1]
00007ec68bfd06a9  lea r14, [rax+0x138]
00007ec68bfd06b0  mov r11, [r13+r14*1]
00007ec68bfd06b5  mov [r15+0xB0], r12
00007ec68bfd06bc  mov [r15+0xA8], r11
00007ec68bfd06c3  lea r14, [rax+0x120]
00007ec68bfd06ca  mov r12, [r13+r14*1]
00007ec68bfd06cf  lea r14, [rax+0x128]
00007ec68bfd06d6  mov r11, [r13+r14*1]
00007ec68bfd06db  mov [r15+0xC0], r12
00007ec68bfd06e2  mov [r15+0xB8], r11
00007ec68bfd06e9  lea r14, [rax+0x110]
00007ec68bfd06f0  mov r12, [r13+r14*1]
00007ec68bfd06f5  lea r14, [rax+0x118]
00007ec68bfd06fc  mov r11, [r13+r14*1]
00007ec68bfd0701  mov [r15+0xD0], r12
00007ec68bfd0708  mov [r15+0xC8], r11
00007ec68bfd070f  lea r14, [rax+0x100]
00007ec68bfd0716  mov r12, [r13+r14*1]
00007ec68bfd071b  lea r14, [rax+0x108]
00007ec68bfd0722  mov r11, [r13+r14*1]
00007ec68bfd0727  mov [r15+0xE8], r12
00007ec68bfd072e  mov [r15+0xD8], r11
00007ec68bfd0735  lea r14, [rax+0x150]
00007ec68bfd073c  mov [r15+0xF8], r14
00007ec68bfd0743  mov rax, [r15+0xF0]
00007ec68bfd074a  mov [r15+0x100], rax
00007ec68bfd0751  jmp 0x00007EC68BFCE5C0
00007ec68bfd0756  int3
00007ec68bfd0757  call 0x00007EC68BEE27E0
00007ec68bfd075c  jmp 0x00007EC68BFD0683
00007ec68bfd0761  call 0x00007EC68BEE1570
00007ec68bfd0766  jmp 0x00007EC68BFD068F
00007ec68bfd076b  call 0x00007EC68BEE27E0
00007ec68bfd0770  jmp 0x00007EC68BFD06A9
00007ec68bfd0775  call 0x00007EC68BEE1570
00007ec68bfd077a  jmp 0x00007EC68BFD06B5
00007ec68bfd077f  call 0x00007EC68BEE27E0
00007ec68bfd0784  jmp 0x00007EC68BFD06CF
00007ec68bfd0789  call 0x00007EC68BEE1570
00007ec68bfd078e  jmp 0x00007EC68BFD06DB
00007ec68bfd0793  call 0x00007EC68BEE27E0
00007ec68bfd0798  jmp 0x00007EC68BFD06F5
00007ec68bfd079d  call 0x00007EC68BEE1570
00007ec68bfd07a2  jmp 0x00007EC68BFD0701
00007ec68bfd07a7  call 0x00007EC68BEE27E0
00007ec68bfd07ac  jmp 0x00007EC68BFD071B
00007ec68bfd07b1  call 0x00007EC68BEE1570
00007ec68bfd07b6  jmp 0x00007EC68BFD0727
00007ec68bfd07bb  int3
00007ec68bfd07bc  nop [rax], eax
00007ec68bfd07c0  mov eax, [r15+0xA0]
00007ec68bfd07c7  mov [rsp+0x10], eax
00007ec68bfd07cb  xor eax, eax
00007ec68bfd07cd  mov r14d, [rsp+0x10]
00007ec68bfd07d2  sub r14d, 0x01
00007ec68bfd07d6  cmc
00007ec68bfd07d7  lahf
00007ec68bfd07d8  seto al
00007ec68bfd07db  mov [r15+0x108], eax
00007ec68bfd07e2  mov r14d, r14d
00007ec68bfd07e5  mov [r15+0xA0], r14
00007ec68bfd07ec  mov eax, [r15+0x108]
00007ec68bfd07f3  sahf
00007ec68bfd07f4  jnz 0x00007EC68BFD0826
00007ec68bfd07f6  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd07fe  jz 0x00007EC68BFD0900
00007ec68bfd0804  nop [rax+rax*1], ax
00007ec68bfd080d  nop [rax+rax*1], eax
00007ec68bfd0815  mov eax, 0x41028C
00007ec68bfd081a  mov [r15+0x100], rax
00007ec68bfd0821  jmp 0x00007EC68BDFE110
00007ec68bfd0826  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd082e  jz 0x00007EC68BFD0860
00007ec68bfd0834  nop [rax+rax*1], ax
00007ec68bfd083d  nop [rax+rax*1], eax
00007ec68bfd0845  mov eax, 0x410274
00007ec68bfd084a  mov [r15+0x100], rax
00007ec68bfd0851  jmp 0x00007EC68BDFE110
00007ec68bfd0856  int3
00007ec68bfd0857  int3
00007ec68bfd0858  nop [rax+rax*1], eax
00007ec68bfd0860  mov rax, [r15+0xF8]
00007ec68bfd0867  lea r14, [rax+0x100]
00007ec68bfd086e  mov [r15], r14
00007ec68bfd0871  mov rax, [r15+0x98]
00007ec68bfd0878  mov [r15+0x08], rax
00007ec68bfd087c  mov qword ptr [r15+0x10], 0x12C
00007ec68bfd0884  mov qword ptr [r15+0xF0], 0x410284
00007ec68bfd088f  mov r14d, [r15+0x320]
00007ec68bfd0896  mov eax, 0x410284
00007ec68bfd089b  mov rcx, 0x7EC68BFD07C0
00007ec68bfd08a5  mov [r15+r14*8+0x328], rax
00007ec68bfd08ad  mov [r15+r14*8+0x368], rcx
00007ec68bfd08b5  add r14d, 0x01
00007ec68bfd08b9  and r14d, 0x07
00007ec68bfd08bd  mov [r15+0x320], r14d
00007ec68bfd08c4  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd08cc  jz 0x00007EC68BFCED70
00007ec68bfd08d2  nop [rax+rax*1], ax
00007ec68bfd08db  nop [rax+rax*1], eax
00007ec68bfd08e3  mov eax, 0x410728
00007ec68bfd08e8  mov [r15+0x100], rax
00007ec68bfd08ef  jmp 0x00007EC68BDFE110
00007ec68bfd08f4  int3
00007ec68bfd08f5  int3
00007ec68bfd08f6  nop [rax+rax*1], ax
00007ec68bfd08ff  nop
00007ec68bfd0900  mov rax, [r15+0xF8]
00007ec68bfd0907  lea r14, [rax+0x120]
00007ec68bfd090e  mov r12, [r13+r14*1]
00007ec68bfd0913  mov [r15+0x98], r12
00007ec68bfd091a  mov qword ptr [r15+0x40], 0x80
00007ec68bfd0922  lea r14, [rax+0x100]
00007ec68bfd0929  mov [r15], r14
00007ec68bfd092c  lea r14, [rax+0x17C]
00007ec68bfd0933  mov [r15+0x08], r14
00007ec68bfd0937  mov qword ptr [r15+0x10], 0x01
00007ec68bfd093f  lea r14, [rax+0x17C]
00007ec68bfd0946  mov eax, 0x80
00007ec68bfd094b  mov [r13+r14*1], al
00007ec68bfd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007ec68bfd095b  mov r14d, [r15+0x320]
00007ec68bfd0962  mov eax, 0x4102A8
00007ec68bfd0967  mov rcx, 0x7EC68BFD09E0
00007ec68bfd0971  mov [r15+r14*8+0x328], rax
00007ec68bfd0979  mov [r15+r14*8+0x368], rcx
00007ec68bfd0981  add r14d, 0x01
00007ec68bfd0985  and r14d, 0x07
00007ec68bfd0989  mov [r15+0x320], r14d
00007ec68bfd0990  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0998  jz 0x00007EC68BFCED70
00007ec68bfd099e  nop [rax+rax*1], ax
00007ec68bfd09a7  nop [rax+rax*1], eax
00007ec68bfd09af  mov eax, 0x410728
00007ec68bfd09b4  mov [r15+0x100], rax
00007ec68bfd09bb  jmp 0x00007EC68BDFE110
00007ec68bfd09c0  int3
00007ec68bfd09c1  call 0x00007EC68BEE27E0
00007ec68bfd09c6  jmp 0x00007EC68BFD0913
00007ec68bfd09cb  call 0x00007EC68BED5AF0
00007ec68bfd09d0  jmp 0x00007EC68BFD0950
00007ec68bfd09d5  int3
00007ec68bfd09d6  nop [rax+rax*1], ax
00007ec68bfd09df  nop
00007ec68bfd09e0  mov rax, [r15+0xF8]
00007ec68bfd09e7  lea r14, [rax+0x168]
00007ec68bfd09ee  mov r12, [r13+r14*1]
00007ec68bfd09f3  mov [r15+0x40], r12
00007ec68bfd09f7  lea r14, [rax+0x178]
00007ec68bfd09fe  xor eax, eax
00007ec68bfd0a00  mov [r13+r14*1], al
00007ec68bfd0a05  xor eax, eax
00007ec68bfd0a07  mov r14d, 0x38
00007ec68bfd0a0d  cmp r12, r14
00007ec68bfd0a10  cmc
00007ec68bfd0a11  lahf
00007ec68bfd0a12  seto al
00007ec68bfd0a15  mov [r15+0x108], eax
00007ec68bfd0a1c  mov eax, [r15+0x108]
00007ec68bfd0a23  sahf
00007ec68bfd0a24  jz 0x00007EC68BFD0A56
00007ec68bfd0a26  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0a2e  jz 0x00007EC68BFD0AA0
00007ec68bfd0a34  nop [rax+rax*1], ax
00007ec68bfd0a3d  nop [rax+rax*1], eax
00007ec68bfd0a45  mov eax, 0x4102B8
00007ec68bfd0a4a  mov [r15+0x100], rax
00007ec68bfd0a51  jmp 0x00007EC68BDFE110
00007ec68bfd0a56  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0a5e  jz 0x00007EC68BFD0BF0
00007ec68bfd0a64  nop [rax+rax*1], ax
00007ec68bfd0a6d  nop [rax+rax*1], eax
00007ec68bfd0a75  mov eax, 0x4102D4
00007ec68bfd0a7a  mov [r15+0x100], rax
00007ec68bfd0a81  jmp 0x00007EC68BDFE110
00007ec68bfd0a86  int3
00007ec68bfd0a87  call 0x00007EC68BEE27E0
00007ec68bfd0a8c  jmp 0x00007EC68BFD09F3
00007ec68bfd0a91  call 0x00007EC68BED5AF0
00007ec68bfd0a96  jmp 0x00007EC68BFD0A05
00007ec68bfd0a9b  int3
00007ec68bfd0a9c  nop [rax], eax
00007ec68bfd0aa0  mov rax, [r15+0xF8]
00007ec68bfd0aa7  lea r14, [rax+0x100]
00007ec68bfd0aae  mov [r15], r14
00007ec68bfd0ab1  lea r14, [rax+0x178]
00007ec68bfd0ab8  mov [r15+0x08], r14
00007ec68bfd0abc  mov qword ptr [r15+0x10], 0x01
00007ec68bfd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007ec68bfd0acf  mov r14d, [r15+0x320]
00007ec68bfd0ad6  mov eax, 0x4102C8
00007ec68bfd0adb  mov rcx, 0x7EC68BFD0B40
00007ec68bfd0ae5  mov [r15+r14*8+0x328], rax
00007ec68bfd0aed  mov [r15+r14*8+0x368], rcx
00007ec68bfd0af5  add r14d, 0x01
00007ec68bfd0af9  and r14d, 0x07
00007ec68bfd0afd  mov [r15+0x320], r14d
00007ec68bfd0b04  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0b0c  jz 0x00007EC68BFCED70
00007ec68bfd0b12  nop [rax+rax*1], ax
00007ec68bfd0b1b  nop [rax+rax*1], eax
00007ec68bfd0b23  mov eax, 0x410728
00007ec68bfd0b28  mov [r15+0x100], rax
00007ec68bfd0b2f  jmp 0x00007EC68BDFE110
00007ec68bfd0b34  int3
00007ec68bfd0b35  int3
00007ec68bfd0b36  nop [rax+rax*1], ax
00007ec68bfd0b3f  nop
00007ec68bfd0b40  mov rax, [r15+0xF8]
00007ec68bfd0b47  lea r14, [rax+0x168]
00007ec68bfd0b4e  mov rax, [r13+r14*1]
00007ec68bfd0b53  mov [r15+0x40], rax
00007ec68bfd0b57  mov [rsp+0x10], rax
00007ec68bfd0b5c  xor eax, eax
00007ec68bfd0b5e  mov r14, [rsp+0x10]
00007ec68bfd0b63  mov r12d, 0x38
00007ec68bfd0b69  cmp r14, r12
00007ec68bfd0b6c  cmc
00007ec68bfd0b6d  lahf
00007ec68bfd0b6e  seto al
00007ec68bfd0b71  mov [r15+0x108], eax
00007ec68bfd0b78  mov eax, [r15+0x108]
00007ec68bfd0b7f  sahf
00007ec68bfd0b80  jnz 0x00007EC68BFD0BB2
00007ec68bfd0b82  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0b8a  jz 0x00007EC68BFD0BF0
00007ec68bfd0b90  nop [rax+rax*1], ax
00007ec68bfd0b99  nop [rax+rax*1], eax
00007ec68bfd0ba1  mov eax, 0x4102D4
00007ec68bfd0ba6  mov [r15+0x100], rax
00007ec68bfd0bad  jmp 0x00007EC68BDFE110
00007ec68bfd0bb2  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0bba  jz 0x00007EC68BFD0AA0
00007ec68bfd0bc0  nop [rax+rax*1], ax
00007ec68bfd0bc9  nop [rax+rax*1], eax
00007ec68bfd0bd1  mov eax, 0x4102B8
00007ec68bfd0bd6  mov [r15+0x100], rax
00007ec68bfd0bdd  jmp 0x00007EC68BDFE110
00007ec68bfd0be2  int3
00007ec68bfd0be3  call 0x00007EC68BED59C0
00007ec68bfd0be8  jmp 0x00007EC68BFD0B53
00007ec68bfd0bed  int3
00007ec68bfd0bee  nop
00007ec68bfd0bf0  mov rax, [r15+0x98]
00007ec68bfd0bf7  rorx r14, rax, 0x3D
00007ec68bfd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007ec68bfd0c01  mov rax, [r15+0xF8]
00007ec68bfd0c08  lea r12, [rax+0x100]
00007ec68bfd0c0f  mov [r15], r12
00007ec68bfd0c12  lea r12, [rax+0x170]
00007ec68bfd0c19  mov [r15+0x08], r12
00007ec68bfd0c1d  mov qword ptr [r15+0x10], 0x08
00007ec68bfd0c25  bswap r14
00007ec68bfd0c28  mov [r15+0x40], r14
00007ec68bfd0c2c  lea r12, [rax+0x170]
00007ec68bfd0c33  mov [r13+r12*1], r14
00007ec68bfd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007ec68bfd0c43  mov r14d, [r15+0x320]
00007ec68bfd0c4a  mov eax, 0x4102F0
00007ec68bfd0c4f  mov rcx, 0x7EC68BFD0CC0
00007ec68bfd0c59  mov [r15+r14*8+0x328], rax
00007ec68bfd0c61  mov [r15+r14*8+0x368], rcx
00007ec68bfd0c69  add r14d, 0x01
00007ec68bfd0c6d  and r14d, 0x07
00007ec68bfd0c71  mov [r15+0x320], r14d
00007ec68bfd0c78  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0c80  jz 0x00007EC68BFCED70
00007ec68bfd0c86  nop [rax+rax*1], ax
00007ec68bfd0c8f  nop [rax+rax*1], eax
00007ec68bfd0c97  mov eax, 0x410728
00007ec68bfd0c9c  mov [r15+0x100], rax
00007ec68bfd0ca3  jmp 0x00007EC68BDFE110
00007ec68bfd0ca8  int3
00007ec68bfd0ca9  call 0x00007EC68BEC3FE0
00007ec68bfd0cae  jmp 0x00007EC68BFD0C38
00007ec68bfd0cb3  int3
00007ec68bfd0cb4  nop [rax+rax*1], ax
00007ec68bfd0cbd  nop [rax], eax
00007ec68bfd0cc0  mov rax, [r15+0xF8]
00007ec68bfd0cc7  lea r14, [rax+0x100]
00007ec68bfd0cce  mov r12d, [r13+r14*1]
00007ec68bfd0cd3  lea r14, [rax+0x104]
00007ec68bfd0cda  mov r11d, [r13+r14*1]
00007ec68bfd0cdf  mov qword ptr [r15+0x48], 0x430C90
00007ec68bfd0ce7  lea r14, [rax+0x108]
00007ec68bfd0cee  mov r10d, [r13+r14*1]
00007ec68bfd0cf3  lea r14, [rax+0x10C]
00007ec68bfd0cfa  mov r9d, [r13+r14*1]
00007ec68bfd0cff  bswap r12d
00007ec68bfd0d02  bswap r11d
00007ec68bfd0d05  mov qword ptr [r15+0xA0], 0x00
00007ec68bfd0d10  mov r14d, 0x430C90
00007ec68bfd0d16  mov [r13+r14*1], r12d
00007ec68bfd0d1b  mov r14d, 0x430C94
00007ec68bfd0d21  mov [r13+r14*1], r11d
00007ec68bfd0d26  bswap r10d
00007ec68bfd0d29  lea r14, [rax+0x110]
00007ec68bfd0d30  mov r12d, [r13+r14*1]
00007ec68bfd0d35  bswap r9d
00007ec68bfd0d38  lea r14, [rax+0x114]
00007ec68bfd0d3f  mov r11d, [r13+r14*1]
00007ec68bfd0d44  mov qword ptr [r15+0x98], 0x430DFC
00007ec68bfd0d4f  mov r14d, 0x430C98
00007ec68bfd0d55  mov [r13+r14*1], r10d
00007ec68bfd0d5a  mov r14d, 0x430C9C
00007ec68bfd0d60  mov [r13+r14*1], r9d
00007ec68bfd0d65  bswap r12d
00007ec68bfd0d68  lea r14, [rax+0x118]
00007ec68bfd0d6f  mov r10d, [r13+r14*1]
00007ec68bfd0d74  bswap r11d
00007ec68bfd0d77  mov [rsp+0x10], r11d
00007ec68bfd0d7c  mov r11d, r11d
00007ec68bfd0d7f  mov [r15+0x58], r11
00007ec68bfd0d83  lea r14, [rax+0x11C]
00007ec68bfd0d8a  mov eax, [r13+r14*1]
00007ec68bfd0d8f  mov [rsp+0x20], eax
00007ec68bfd0d93  mov eax, eax
00007ec68bfd0d95  mov [r15+0x60], rax
00007ec68bfd0d99  mov eax, 0x430CA0
00007ec68bfd0d9e  mov [r13+rax*1], r12d
00007ec68bfd0da3  mov eax, 0x430CA4
00007ec68bfd0da8  mov r14d, [rsp+0x10]
00007ec68bfd0dad  mov [r13+rax*1], r14d
00007ec68bfd0db2  bswap r10d
00007ec68bfd0db5  mov [rsp+0x10], r10d
00007ec68bfd0dba  mov r10d, r10d
00007ec68bfd0dbd  mov [r15+0x40], r10
00007ec68bfd0dc1  mov eax, [rsp+0x20]
00007ec68bfd0dc5  bswap eax
00007ec68bfd0dc7  mov [rsp+0x20], eax
00007ec68bfd0dcb  mov eax, eax
00007ec68bfd0dcd  mov [r15+0x50], rax
00007ec68bfd0dd1  mov eax, 0x430CA8
00007ec68bfd0dd6  mov r14d, [rsp+0x10]
00007ec68bfd0ddb  mov [r13+rax*1], r14d
00007ec68bfd0de0  mov eax, 0x430CAC
00007ec68bfd0de5  mov r14d, [rsp+0x20]
00007ec68bfd0dea  mov [r13+rax*1], r14d
00007ec68bfd0def  mov eax, [r15+0xA0]
00007ec68bfd0df6  lea r14d, [eax+0x11]
00007ec68bfd0dfb  mov r14d, r14d
00007ec68bfd0dfe  mov [r15], r14
00007ec68bfd0e01  mov qword ptr [r15+0xF0], 0x41035C
00007ec68bfd0e0c  mov r14d, [r15+0x320]
00007ec68bfd0e13  mov eax, 0x41035C
00007ec68bfd0e18  mov rcx, 0x7EC68BFD0F90
00007ec68bfd0e22  mov [r15+r14*8+0x328], rax
00007ec68bfd0e2a  mov [r15+r14*8+0x368], rcx
00007ec68bfd0e32  add r14d, 0x01
00007ec68bfd0e36  and r14d, 0x07
00007ec68bfd0e3a  mov [r15+0x320], r14d
00007ec68bfd0e41  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0e49  jz 0x00007EC68BFD0F20
00007ec68bfd0e4f  nop [rax+rax*1], ax
00007ec68bfd0e58  nop [rax+rax*1], eax
00007ec68bfd0e60  mov eax, 0x4109A4
00007ec68bfd0e65  mov [r15+0x100], rax
00007ec68bfd0e6c  jmp 0x00007EC68BDFE110
00007ec68bfd0e71  int3
00007ec68bfd0e72  call 0x00007EC68BEE26A0
00007ec68bfd0e77  jmp 0x00007EC68BFD0CD3
00007ec68bfd0e7c  call 0x00007EC68BEE1430
00007ec68bfd0e81  jmp 0x00007EC68BFD0CDF
00007ec68bfd0e86  call 0x00007EC68BEE01C0
00007ec68bfd0e8b  jmp 0x00007EC68BFD0CF3
00007ec68bfd0e90  call 0x00007EC68BEDEF50
00007ec68bfd0e95  jmp 0x00007EC68BFD0CFF
00007ec68bfd0e9a  call 0x00007EC68BEE2BA0
00007ec68bfd0e9f  jmp 0x00007EC68BFD0D1B
00007ec68bfd0ea4  call 0x00007EC68BEE1920
00007ec68bfd0ea9  jmp 0x00007EC68BFD0D26
00007ec68bfd0eae  call 0x00007EC68BEE26A0
00007ec68bfd0eb3  jmp 0x00007EC68BFD0D35
00007ec68bfd0eb8  call 0x00007EC68BEE1430
00007ec68bfd0ebd  jmp 0x00007EC68BFD0D44
00007ec68bfd0ec2  call 0x00007EC68BEE06B0
00007ec68bfd0ec7  jmp 0x00007EC68BFD0D5A
00007ec68bfd0ecc  call 0x00007EC68BEDF440
00007ec68bfd0ed1  jmp 0x00007EC68BFD0D65
00007ec68bfd0ed6  call 0x00007EC68BEE01C0
00007ec68bfd0edb  jmp 0x00007EC68BFD0D74
00007ec68bfd0ee0  call 0x00007EC68BED5890
00007ec68bfd0ee5  jmp 0x00007EC68BFD0D8F
00007ec68bfd0eea  call 0x00007EC68BE0BAE0
00007ec68bfd0eef  jmp 0x00007EC68BFD0DA3
00007ec68bfd0ef4  call 0x00007EC68BE0DFE0
00007ec68bfd0ef9  jmp 0x00007EC68BFD0DB2
00007ec68bfd0efe  call 0x00007EC68BE0DFE0
00007ec68bfd0f03  jmp 0x00007EC68BFD0DE0
00007ec68bfd0f08  call 0x00007EC68BE0DFE0
00007ec68bfd0f0d  jmp 0x00007EC68BFD0DEF
00007ec68bfd0f12  int3
00007ec68bfd0f13  nop [rax+rax*1], ax
00007ec68bfd0f1c  nop [rax], eax
00007ec68bfd0f20  mov eax, [r15]
00007ec68bfd0f23  mov [rsp+0x10], eax
00007ec68bfd0f27  shr eax, 0x10
00007ec68bfd0f2a  mov r14d, [rsp+0x10]
00007ec68bfd0f2f  xor r14d, eax
00007ec68bfd0f32  imul r14d, r14d, 0x7FEB352D
00007ec68bfd0f39  mov eax, 0x846CA68B
00007ec68bfd0f3e  mov eax, eax
00007ec68bfd0f40  mov [r15+0x48], rax
00007ec68bfd0f44  mov [rsp+0x10], r14d
00007ec68bfd0f49  shr r14d, 0x0F
00007ec68bfd0f4d  mov eax, [rsp+0x10]
00007ec68bfd0f51  xor eax, r14d
00007ec68bfd0f54  imul eax, eax, 0x846CA68B
00007ec68bfd0f5a  mov [rsp+0x10], eax
00007ec68bfd0f5e  mov eax, eax
00007ec68bfd0f60  mov [r15+0x40], rax
00007ec68bfd0f64  mov eax, [rsp+0x10]
00007ec68bfd0f68  shr eax, 0x10
00007ec68bfd0f6b  mov r14d, [rsp+0x10]
00007ec68bfd0f70  xor r14d, eax
00007ec68bfd0f73  mov r14d, r14d
00007ec68bfd0f76  mov [r15], r14
00007ec68bfd0f79  mov rax, [r15+0xF0]
00007ec68bfd0f80  mov [r15+0x100], rax
00007ec68bfd0f87  jmp 0x00007EC68BFCE5C0
00007ec68bfd0f8c  int3
00007ec68bfd0f8d  int3
00007ec68bfd0f8e  nop
00007ec68bfd0f90  mov rax, [r15+0xA0]
00007ec68bfd0f97  mov [rsp+0x10], rax
00007ec68bfd0f9c  shl rax, 0x02
00007ec68bfd0fa0  mov r14, [r15+0x98]
00007ec68bfd0fa7  lea r12, [r14+rax*1]
00007ec68bfd0fab  mov eax, [r15]
00007ec68bfd0fae  mov [r13+r12*1], eax
00007ec68bfd0fb3  mov rax, [rsp+0x10]
00007ec68bfd0fb8  lea r14, [rax+0x01]
00007ec68bfd0fbc  mov [r15+0xA0], r14
00007ec68bfd0fc3  xor eax, eax
00007ec68bfd0fc5  mov r12d, 0x400
00007ec68bfd0fcb  cmp r14, r12
00007ec68bfd0fce  cmc
00007ec68bfd0fcf  lahf
00007ec68bfd0fd0  seto al
00007ec68bfd0fd3  mov [r15+0x108], eax
00007ec68bfd0fda  mov eax, [r15+0x108]
00007ec68bfd0fe1  sahf
00007ec68bfd0fe2  jnz 0x00007EC68BFD1014
00007ec68bfd0fe4  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd0fec  jz 0x00007EC68BFD10E0
00007ec68bfd0ff2  nop [rax+rax*1], ax
00007ec68bfd0ffb  nop [rax+rax*1], eax
00007ec68bfd1003  mov eax, 0x41036C
00007ec68bfd1008  mov [r15+0x100], rax
00007ec68bfd100f  jmp 0x00007EC68BDFE110
00007ec68bfd1014  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd101c  jz 0x00007EC68BFD1050
00007ec68bfd1022  nop [rax+rax*1], ax
00007ec68bfd102b  nop [rax+rax*1], eax
00007ec68bfd1033  mov eax, 0x410354
00007ec68bfd1038  mov [r15+0x100], rax
00007ec68bfd103f  jmp 0x00007EC68BDFE110
00007ec68bfd1044  int3
00007ec68bfd1045  call 0x00007EC68BEB4B70
00007ec68bfd104a  jmp 0x00007EC68BFD0FB3
00007ec68bfd104f  int3
00007ec68bfd1050  mov eax, [r15+0xA0]
00007ec68bfd1057  lea r14d, [eax+0x11]
00007ec68bfd105c  mov r14d, r14d
00007ec68bfd105f  mov [r15], r14
00007ec68bfd1062  mov qword ptr [r15+0xF0], 0x41035C
00007ec68bfd106d  mov r14d, [r15+0x320]
00007ec68bfd1074  mov eax, 0x41035C
00007ec68bfd1079  mov rcx, 0x7EC68BFD0F90
00007ec68bfd1083  mov [r15+r14*8+0x328], rax
00007ec68bfd108b  mov [r15+r14*8+0x368], rcx
00007ec68bfd1093  add r14d, 0x01
00007ec68bfd1097  and r14d, 0x07
00007ec68bfd109b  mov [r15+0x320], r14d
00007ec68bfd10a2  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd10aa  jz 0x00007EC68BFD0F20
00007ec68bfd10b0  nop [rax+rax*1], ax
00007ec68bfd10b9  nop [rax+rax*1], eax
00007ec68bfd10c1  mov eax, 0x4109A4
00007ec68bfd10c6  mov [r15+0x100], rax
00007ec68bfd10cd  jmp 0x00007EC68BDFE110
00007ec68bfd10d2  int3
00007ec68bfd10d3  int3
00007ec68bfd10d4  nop [rax+rax*1], ax
00007ec68bfd10dd  nop [rax], eax
00007ec68bfd10e0  mov qword ptr [r15+0x40], 0x01
00007ec68bfd10e8  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd10f0  jz 0x00007EC68BFD1120
00007ec68bfd10f6  nop [rax+rax*1], ax
00007ec68bfd10ff  nop [rax+rax*1], eax
00007ec68bfd1107  mov eax, 0x410388
00007ec68bfd110c  mov [r15+0x100], rax
00007ec68bfd1113  jmp 0x00007EC68BDFE110
00007ec68bfd1118  int3
00007ec68bfd1119  int3
00007ec68bfd111a  nop [rax+rax*1], ax
00007ec68bfd1120  mov rax, [r15+0x40]
00007ec68bfd1124  mov [rsp+0x10], rax
00007ec68bfd1129  shl rax, 0x02
00007ec68bfd112d  mov r14, [r15+0x98]
00007ec68bfd1134  lea r12, [r14+rax*1]
00007ec68bfd1138  mov eax, [r13+r12*1]
00007ec68bfd113d  mov [rsp+0x20], eax
00007ec68bfd1141  mov eax, eax
00007ec68bfd1143  mov [r15+0x48], rax
00007ec68bfd1147  mov rax, [rsp+0x10]
00007ec68bfd114c  mov [r15+0x50], rax
00007ec68bfd1150  mov eax, [r15+0x50]
00007ec68bfd1154  lea r12d, [eax-0x01]
00007ec68bfd1159  mov r12d, r12d
00007ec68bfd115c  mov [r15+0x58], r12
00007ec68bfd1160  mov rax, [r15+0x58]
00007ec68bfd1164  mov r12d, eax
00007ec68bfd1167  mov r12d, r12d
00007ec68bfd116a  shl r12, 0x02
00007ec68bfd116e  lea rax, [r14+r12*1]
00007ec68bfd1172  mov r14d, [r13+rax*1]
00007ec68bfd1177  mov [rsp+0x10], r14d
00007ec68bfd117c  mov r14d, r14d
00007ec68bfd117f  mov [r15+0x60], r14
00007ec68bfd1183  xor eax, eax
00007ec68bfd1185  mov r14d, [rsp+0x10]
00007ec68bfd118a  mov r12d, [rsp+0x20]
00007ec68bfd118f  cmp r14d, r12d
00007ec68bfd1192  cmc
00007ec68bfd1193  lahf
00007ec68bfd1194  seto al
00007ec68bfd1197  mov [r15+0x108], eax
00007ec68bfd119e  mov eax, [r15+0x108]
00007ec68bfd11a5  sahf
00007ec68bfd11a6  cmc
00007ec68bfd11a7  jbe 0x00007EC68BFD11D9
00007ec68bfd11a9  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd11b1  jz 0x00007EC68BFD1220
00007ec68bfd11b7  nop [rax+rax*1], ax
00007ec68bfd11c0  nop [rax+rax*1], eax
00007ec68bfd11c8  mov eax, 0x4103A0
00007ec68bfd11cd  mov [r15+0x100], rax
00007ec68bfd11d4  jmp 0x00007EC68BDFE110
00007ec68bfd11d9  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd11e1  jz 0x00007EC68BFD14C0
00007ec68bfd11e7  nop [rax+rax*1], ax
00007ec68bfd11f0  nop [rax+rax*1], eax
00007ec68bfd11f8  mov eax, 0x410378
00007ec68bfd11fd  mov [r15+0x100], rax
00007ec68bfd1204  jmp 0x00007EC68BDFE110
00007ec68bfd1209  int3
00007ec68bfd120a  call 0x00007EC68BEB4690
00007ec68bfd120f  jmp 0x00007EC68BFD113D
00007ec68bfd1214  call 0x00007EC68BE0DAE0
00007ec68bfd1219  jmp 0x00007EC68BFD1177
00007ec68bfd121e  int3
00007ec68bfd121f  nop
00007ec68bfd1220  mov rax, [r15+0x50]
00007ec68bfd1224  mov [rsp+0x10], rax
00007ec68bfd1229  shl rax, 0x02
00007ec68bfd122d  mov r14, [r15+0x98]
00007ec68bfd1234  lea r12, [r14+rax*1]
00007ec68bfd1238  mov eax, [r15+0x60]
00007ec68bfd123c  mov [r13+r12*1], eax
00007ec68bfd1241  mov rax, [rsp+0x10]
00007ec68bfd1246  lea r14, [rax-0x01]
00007ec68bfd124a  mov [r15+0x50], r14
00007ec68bfd124e  mov rax, [r15+0x58]
00007ec68bfd1252  test rax, rax
00007ec68bfd1255  setz al
00007ec68bfd1258  movzx rax, al
00007ec68bfd125c  mov [rsp+0x414], al
00007ec68bfd1263  cmp byte ptr [rsp+0x414], 0x00
00007ec68bfd126b  jz 0x00007EC68BFD129D
00007ec68bfd126d  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd1275  jz 0x00007EC68BFD12E0
00007ec68bfd127b  nop [rax+rax*1], ax
00007ec68bfd1284  nop [rax+rax*1], eax
00007ec68bfd128c  mov eax, 0x4103AC
00007ec68bfd1291  mov [r15+0x100], rax
00007ec68bfd1298  jmp 0x00007EC68BDFE110
00007ec68bfd129d  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd12a5  jz 0x00007EC68BFD13E0
00007ec68bfd12ab  nop [rax+rax*1], ax
00007ec68bfd12b4  nop [rax+rax*1], eax
00007ec68bfd12bc  mov eax, 0x410390
00007ec68bfd12c1  mov [r15+0x100], rax
00007ec68bfd12c8  jmp 0x00007EC68BDFE110
00007ec68bfd12cd  int3
00007ec68bfd12ce  call 0x00007EC68BEB4B70
00007ec68bfd12d3  jmp 0x00007EC68BFD1241
00007ec68bfd12d8  int3
00007ec68bfd12d9  nop [rax], eax
00007ec68bfd12e0  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd12e8  jz 0x00007EC68BFD1320
00007ec68bfd12ee  nop [rax+rax*1], ax
00007ec68bfd12f7  nop [rax+rax*1], eax
00007ec68bfd12ff  mov eax, 0x410374
00007ec68bfd1304  mov [r15+0x100], rax
00007ec68bfd130b  jmp 0x00007EC68BDFE110
00007ec68bfd1310  int3
00007ec68bfd1311  int3
00007ec68bfd1312  nop [rax+rax*1], ax
00007ec68bfd131b  nop [rax+rax*1], eax
00007ec68bfd1320  mov qword ptr [r15+0x50], 0x00
00007ec68bfd1328  mov rax, [r15+0x40]
00007ec68bfd132c  lea r14, [rax+0x01]
00007ec68bfd1330  mov [r15+0x40], r14
00007ec68bfd1334  mov rax, [r15+0x98]
00007ec68bfd133b  mov r12d, [r15+0x48]
00007ec68bfd133f  mov [r13+rax*1], r12d
00007ec68bfd1344  xor eax, eax
00007ec68bfd1346  mov r12d, 0x400
00007ec68bfd134c  cmp r14, r12
00007ec68bfd134f  cmc
00007ec68bfd1350  lahf
00007ec68bfd1351  seto al
00007ec68bfd1354  mov [r15+0x108], eax
00007ec68bfd135b  mov eax, [r15+0x108]
00007ec68bfd1362  sahf
00007ec68bfd1363  jz 0x00007EC68BFD1395
00007ec68bfd1365  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd136d  jz 0x00007EC68BFD1120
00007ec68bfd1373  nop [rax+rax*1], ax
00007ec68bfd137c  nop [rax+rax*1], eax
00007ec68bfd1384  mov eax, 0x410388
00007ec68bfd1389  mov [r15+0x100], rax
00007ec68bfd1390  jmp 0x00007EC68BDFE110
00007ec68bfd1395  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd139d  jz 0x00007EC68BFD1580
00007ec68bfd13a3  nop [rax+rax*1], ax
00007ec68bfd13ac  nop [rax+rax*1], eax
00007ec68bfd13b4  mov eax, 0x4103B0
00007ec68bfd13b9  mov [r15+0x100], rax
00007ec68bfd13c0  jmp 0x00007EC68BDFE110
00007ec68bfd13c5  int3
00007ec68bfd13c6  call 0x00007EC68BE0BAE0
00007ec68bfd13cb  jmp 0x00007EC68BFD1344
00007ec68bfd13d0  int3
00007ec68bfd13d1  nop [rax+rax*1], ax
00007ec68bfd13da  nop [rax+rax*1], ax
00007ec68bfd13e0  mov eax, [r15+0x50]
00007ec68bfd13e4  lea r14d, [eax-0x01]
00007ec68bfd13e9  mov r14d, r14d
00007ec68bfd13ec  mov [r15+0x58], r14
00007ec68bfd13f0  mov rax, [r15+0x58]
00007ec68bfd13f4  mov r14d, eax
00007ec68bfd13f7  mov r14d, r14d
00007ec68bfd13fa  shl r14, 0x02
00007ec68bfd13fe  mov rax, [r15+0x98]
00007ec68bfd1405  lea r12, [rax+r14*1]
00007ec68bfd1409  mov eax, [r13+r12*1]
00007ec68bfd140e  mov [rsp+0x10], eax
00007ec68bfd1412  mov eax, eax
00007ec68bfd1414  mov [r15+0x60], rax
00007ec68bfd1418  mov eax, [r15+0x48]
00007ec68bfd141c  mov [rsp+0x20], eax
00007ec68bfd1420  xor eax, eax
00007ec68bfd1422  mov r14d, [rsp+0x10]
00007ec68bfd1427  mov r12d, [rsp+0x20]
00007ec68bfd142c  cmp r14d, r12d
00007ec68bfd142f  cmc
00007ec68bfd1430  lahf
00007ec68bfd1431  seto al
00007ec68bfd1434  mov [r15+0x108], eax
00007ec68bfd143b  mov eax, [r15+0x108]
00007ec68bfd1442  sahf
00007ec68bfd1443  cmc
00007ec68bfd1444  jbe 0x00007EC68BFD1476
00007ec68bfd1446  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd144e  jz 0x00007EC68BFD1220
00007ec68bfd1454  nop [rax+rax*1], ax
00007ec68bfd145d  nop [rax+rax*1], eax
00007ec68bfd1465  mov eax, 0x4103A0
00007ec68bfd146a  mov [r15+0x100], rax
00007ec68bfd1471  jmp 0x00007EC68BDFE110
00007ec68bfd1476  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd147e  jz 0x00007EC68BFD14C0
00007ec68bfd1484  nop [rax+rax*1], ax
00007ec68bfd148d  nop [rax+rax*1], eax
00007ec68bfd1495  mov eax, 0x410378
00007ec68bfd149a  mov [r15+0x100], rax
00007ec68bfd14a1  jmp 0x00007EC68BDFE110
00007ec68bfd14a6  int3
00007ec68bfd14a7  call 0x00007EC68BEB4690
00007ec68bfd14ac  jmp 0x00007EC68BFD140E
00007ec68bfd14b1  int3
00007ec68bfd14b2  nop [rax+rax*1], ax
00007ec68bfd14bb  nop [rax+rax*1], eax
00007ec68bfd14c0  mov rax, [r15+0x40]
00007ec68bfd14c4  lea r14, [rax+0x01]
00007ec68bfd14c8  mov [r15+0x40], r14
00007ec68bfd14cc  mov rax, [r15+0x50]
00007ec68bfd14d0  mov r12d, eax
00007ec68bfd14d3  mov r12d, r12d
00007ec68bfd14d6  shl r12, 0x02
00007ec68bfd14da  mov rax, [r15+0x98]
00007ec68bfd14e1  lea r11, [rax+r12*1]
00007ec68bfd14e5  mov eax, [r15+0x48]
00007ec68bfd14e9  mov [r13+r11*1], eax
00007ec68bfd14ee  xor eax, eax
00007ec68bfd14f0  mov r12d, 0x400
00007ec68bfd14f6  cmp r14, r12
00007ec68bfd14f9  cmc
00007ec68bfd14fa  lahf
00007ec68bfd14fb  seto al
00007ec68bfd14fe  mov [r15+0x108], eax
00007ec68bfd1505  mov eax, [r15+0x108]
00007ec68bfd150c  sahf
00007ec68bfd150d  jz 0x00007EC68BFD153F
00007ec68bfd150f  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd1517  jz 0x00007EC68BFD1120
00007ec68bfd151d  nop [rax+rax*1], ax
00007ec68bfd1526  nop [rax+rax*1], eax
00007ec68bfd152e  mov eax, 0x410388
00007ec68bfd1533  mov [r15+0x100], rax
00007ec68bfd153a  jmp 0x00007EC68BDFE110
00007ec68bfd153f  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd1547  jz 0x00007EC68BFD1580
00007ec68bfd154d  nop [rax+rax*1], ax
00007ec68bfd1556  nop [rax+rax*1], eax
00007ec68bfd155e  mov eax, 0x4103B0
00007ec68bfd1563  mov [r15+0x100], rax
00007ec68bfd156a  jmp 0x00007EC68BDFE110
00007ec68bfd156f  int3
00007ec68bfd1570  call 0x00007EC68BEA4270
00007ec68bfd1575  jmp 0x00007EC68BFD14EE
00007ec68bfd157a  int3
00007ec68bfd157b  nop [rax+rax*1], eax
00007ec68bfd1580  mov qword ptr [r15+0x40], 0x430000
00007ec68bfd1588  mov eax, 0x430CB0
00007ec68bfd158d  mov r14, [r13+rax*1]
00007ec68bfd1592  mov rax, [r15+0x98]
00007ec68bfd1599  mov r12d, [r13+rax*1]
00007ec68bfd159e  lea r11, [rax+0x04]
00007ec68bfd15a2  mov eax, [r13+r11*1]
00007ec68bfd15a7  mov r12d, r12d
00007ec68bfd15aa  mov [r15+0x68], r12
00007ec68bfd15ae  mov eax, eax
00007ec68bfd15b0  mov [r15+0x60], rax
00007ec68bfd15b4  mov rax, [r15+0x68]
00007ec68bfd15b8  mov [r15+0x68], rax
00007ec68bfd15bc  mov qword ptr [r15+0x58], 0x02
00007ec68bfd15c4  mov [rsp+0x10], rax
00007ec68bfd15c9  xor eax, eax
00007ec68bfd15cb  mov r12d, 0x02
00007ec68bfd15d1  mov r11d, 0x400
00007ec68bfd15d7  cmp r12, r11
00007ec68bfd15da  cmc
00007ec68bfd15db  lahf
00007ec68bfd15dc  seto al
00007ec68bfd15df  mov [r15+0x108], eax
00007ec68bfd15e6  mov rax, [r15+0x60]
00007ec68bfd15ea  mov r12d, 0x02
00007ec68bfd15f0  imul rax, r12
00007ec68bfd15f4  mov [r15+0x50], rax
00007ec68bfd15f8  mov rax, [rsp+0x10]
00007ec68bfd15fd  lea r12, [rax+r14*1]
00007ec68bfd1601  mov [r15+0x48], r12
00007ec68bfd1605  mov eax, [r15+0x108]
00007ec68bfd160c  sahf
00007ec68bfd160d  jnz 0x00007EC68BFD163F
00007ec68bfd160f  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd1617  jz 0x00007EC68BFD17B0
00007ec68bfd161d  nop [rax+rax*1], ax
00007ec68bfd1626  nop [rax+rax*1], eax
00007ec68bfd162e  mov eax, 0x4103E0
00007ec68bfd1633  mov [r15+0x100], rax
00007ec68bfd163a  jmp 0x00007EC68BDFE110
00007ec68bfd163f  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd1647  jz 0x00007EC68BFD1690
00007ec68bfd164d  nop [rax+rax*1], ax
00007ec68bfd1656  nop [rax+rax*1], eax
00007ec68bfd165e  mov eax, 0x4103C0
00007ec68bfd1663  mov [r15+0x100], rax
00007ec68bfd166a  jmp 0x00007EC68BDFE110
00007ec68bfd166f  int3
00007ec68bfd1670  call 0x00007EC68BE0DC20
00007ec68bfd1675  jmp 0x00007EC68BFD1592
00007ec68bfd167a  call 0x00007EC68BE0B5E0
00007ec68bfd167f  jmp 0x00007EC68BFD159E
00007ec68bfd1684  call 0x00007EC68BEA3D90
00007ec68bfd1689  jmp 0x00007EC68BFD15A7
00007ec68bfd168e  int3
00007ec68bfd168f  nop
00007ec68bfd1690  mov rax, [r15+0x98]
00007ec68bfd1697  mov r14, [r15+0x58]
00007ec68bfd169b  mov [rsp+0x10], r14
00007ec68bfd16a0  shl r14, 0x02
00007ec68bfd16a4  lea r12, [rax+r14*1]
00007ec68bfd16a8  mov eax, [r13+r12*1]
00007ec68bfd16ad  lea r14, [r12+0x04]
00007ec68bfd16b2  mov r12d, [r13+r14*1]
00007ec68bfd16b7  mov eax, eax
00007ec68bfd16b9  mov [r15+0x68], rax
00007ec68bfd16bd  mov r12d, r12d
00007ec68bfd16c0  mov [r15+0x60], r12
00007ec68bfd16c4  mov rax, [r15+0x68]
00007ec68bfd16c8  mov [rsp+0x20], rax
00007ec68bfd16cd  mov r14, [rsp+0x10]
00007ec68bfd16d2  imul rax, r14
00007ec68bfd16d6  mov r12, [rsp+0x20]
00007ec68bfd16db  lea r11, [r12+rax*1]
00007ec68bfd16df  mov [r15+0x68], r11
00007ec68bfd16e3  lea rax, [r14+0x02]
00007ec68bfd16e7  mov [r15+0x58], rax
00007ec68bfd16eb  mov [rsp+0x10], rax
00007ec68bfd16f0  xor eax, eax
00007ec68bfd16f2  mov r14, [rsp+0x10]
00007ec68bfd16f7  mov r12d, 0x400
00007ec68bfd16fd  cmp r14, r12
00007ec68bfd1700  cmc
00007ec68bfd1701  lahf
00007ec68bfd1702  seto al
00007ec68bfd1705  mov [r15+0x108], eax
00007ec68bfd170c  mov rax, [r15+0x50]
00007ec68bfd1710  mov r12, [r15+0x60]
00007ec68bfd1714  imul r14, r12
00007ec68bfd1718  lea r12, [rax+r14*1]
00007ec68bfd171c  mov [r15+0x50], r12
00007ec68bfd1720  mov rax, [r15+0x48]
00007ec68bfd1724  lea r14, [r11+rax*1]
00007ec68bfd1728  mov [r15+0x48], r14
00007ec68bfd172c  mov eax, [r15+0x108]
00007ec68bfd1733  sahf
00007ec68bfd1734  jnz 0x00007EC68BFD1766
00007ec68bfd1736  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd173e  jz 0x00007EC68BFD17B0
00007ec68bfd1744  nop [rax+rax*1], ax
00007ec68bfd174d  nop [rax+rax*1], eax
00007ec68bfd1755  mov eax, 0x4103E0
00007ec68bfd175a  mov [r15+0x100], rax
00007ec68bfd1761  jmp 0x00007EC68BDFE110
00007ec68bfd1766  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd176e  jz 0x00007EC68BFD1690
00007ec68bfd1774  nop [rax+rax*1], ax
00007ec68bfd177d  nop [rax+rax*1], eax
00007ec68bfd1785  mov eax, 0x4103C0
00007ec68bfd178a  mov [r15+0x100], rax
00007ec68bfd1791  jmp 0x00007EC68BDFE110
00007ec68bfd1796  int3
00007ec68bfd1797  call 0x00007EC68BEB4690
00007ec68bfd179c  jmp 0x00007EC68BFD16AD
00007ec68bfd17a1  call 0x00007EC68BEE26A0
00007ec68bfd17a6  jmp 0x00007EC68BFD16B7
00007ec68bfd17ab  int3
00007ec68bfd17ac  nop [rax], eax
00007ec68bfd17b0  mov qword ptr [r15+0x98], 0x00
00007ec68bfd17bb  mov rax, [r15+0x50]
00007ec68bfd17bf  mov r14, [r15+0x48]
00007ec68bfd17c3  lea r12, [rax+r14*1]
00007ec68bfd17c7  mov [r15+0x48], r12
00007ec68bfd17cb  mov rax, [r15+0x40]
00007ec68bfd17cf  lea r14, [rax+0xCB0]
00007ec68bfd17d6  mov [r13+r14*1], r12
00007ec68bfd17db  mov qword ptr [r15], 0x01
00007ec68bfd17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007ec68bfd17ed  mov r14d, [r15+0x320]
00007ec68bfd17f4  mov eax, 0x4103F8
00007ec68bfd17f9  mov rcx, 0x7EC68BFD1860
00007ec68bfd1803  mov [r15+r14*8+0x328], rax
00007ec68bfd180b  mov [r15+r14*8+0x368], rcx
00007ec68bfd1813  add r14d, 0x01
00007ec68bfd1817  and r14d, 0x07
00007ec68bfd181b  mov [r15+0x320], r14d
00007ec68bfd1822  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd182a  jz 0x00007EC68BFD0F20
00007ec68bfd1830  nop [rax+rax*1], ax
00007ec68bfd1839  nop [rax+rax*1], eax
00007ec68bfd1841  mov eax, 0x4109A4
00007ec68bfd1846  mov [r15+0x100], rax
00007ec68bfd184d  jmp 0x00007EC68BDFE110
00007ec68bfd1852  int3
00007ec68bfd1853  call 0x00007EC68BEE2CE0
00007ec68bfd1858  jmp 0x00007EC68BFD17DB
00007ec68bfd185d  int3
00007ec68bfd185e  nop
00007ec68bfd1860  mov eax, [r15+0x98]
00007ec68bfd1867  lea r14d, [eax+0x01]
00007ec68bfd186c  mov [rsp+0x10], r14d
00007ec68bfd1871  mov r14d, r14d
00007ec68bfd1874  mov [r15+0x98], r14
00007ec68bfd187b  xor eax, eax
00007ec68bfd187d  mov r14d, [rsp+0x10]
00007ec68bfd1882  cmp r14d, 0x10000
00007ec68bfd1889  cmc
00007ec68bfd188a  lahf
00007ec68bfd188b  seto al
00007ec68bfd188e  mov [r15+0x108], eax
00007ec68bfd1895  mov eax, [r15+0x108]
00007ec68bfd189c  sahf
00007ec68bfd189d  jnz 0x00007EC68BFD18CF
00007ec68bfd189f  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd18a7  jz 0x00007EC68BFD19A0
00007ec68bfd18ad  nop [rax+rax*1], ax
00007ec68bfd18b6  nop [rax+rax*1], eax
00007ec68bfd18be  mov eax, 0x410404
00007ec68bfd18c3  mov [r15+0x100], rax
00007ec68bfd18ca  jmp 0x00007EC68BDFE110
00007ec68bfd18cf  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd18d7  jz 0x00007EC68BFD1910
00007ec68bfd18dd  nop [rax+rax*1], ax
00007ec68bfd18e6  nop [rax+rax*1], eax
00007ec68bfd18ee  mov eax, 0x4103F0
00007ec68bfd18f3  mov [r15+0x100], rax
00007ec68bfd18fa  jmp 0x00007EC68BDFE110
00007ec68bfd18ff  int3
00007ec68bfd1900  int3
00007ec68bfd1901  nop [rax+rax*1], ax
00007ec68bfd190a  nop [rax+rax*1], ax
00007ec68bfd1910  mov eax, [r15]
00007ec68bfd1913  mov r14d, [r15+0x98]
00007ec68bfd191a  lea r12d, [eax+r14d*1]
00007ec68bfd191f  mov r12d, r12d
00007ec68bfd1922  mov [r15], r12
00007ec68bfd1925  mov qword ptr [r15+0xF0], 0x4103F8
00007ec68bfd1930  mov r14d, [r15+0x320]
00007ec68bfd1937  mov eax, 0x4103F8
00007ec68bfd193c  mov rcx, 0x7EC68BFD1860
00007ec68bfd1946  mov [r15+r14*8+0x328], rax
00007ec68bfd194e  mov [r15+r14*8+0x368], rcx
00007ec68bfd1956  add r14d, 0x01
00007ec68bfd195a  and r14d, 0x07
00007ec68bfd195e  mov [r15+0x320], r14d
00007ec68bfd1965  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd196d  jz 0x00007EC68BFD0F20
00007ec68bfd1973  nop [rax+rax*1], ax
00007ec68bfd197c  nop [rax+rax*1], eax
00007ec68bfd1984  mov eax, 0x4109A4
00007ec68bfd1989  mov [r15+0x100], rax
00007ec68bfd1990  jmp 0x00007EC68BDFE110
00007ec68bfd1995  int3
00007ec68bfd1996  int3
00007ec68bfd1997  nop [rax+rax*1], ax
00007ec68bfd19a0  vmovaps xmm1, [0x00007EC68BBFE010]
00007ec68bfd19a8  movq xmm1, xmm1
00007ec68bfd19ac  movaps [r15+0x110], xmm1
00007ec68bfd19b4  mov eax, 0x420B10
00007ec68bfd19b9  mov r14, [r13+rax*1]
00007ec68bfd19be  movq xmm1, r14
00007ec68bfd19c3  movaps [r15+0x120], xmm1
00007ec68bfd19cb  vmovaps xmm1, [0x00007EC68BBFE020]
00007ec68bfd19d3  movq xmm1, xmm1
00007ec68bfd19d7  movaps [r15+0x140], xmm1
00007ec68bfd19df  vmovaps xmm1, [0x00007EC68BBFE030]
00007ec68bfd19e7  vpbroadcastq xmm1, xmm1
00007ec68bfd19ec  movaps [r15+0x150], xmm1
00007ec68bfd19f4  mov qword ptr [r15+0x40], 0x02
00007ec68bfd19fc  vmovaps xmm15, [0x00007EC68BBFE040]
00007ec68bfd1a04  movq xmm15, xmm15
00007ec68bfd1a09  movaps [r15+0x160], xmm15
00007ec68bfd1a11  vmovaps xmm15, [0x00007EC68BBFE050]
00007ec68bfd1a19  vpbroadcastq xmm15, xmm15
00007ec68bfd1a1e  movaps [r15+0x130], xmm15
00007ec68bfd1a26  mov rax, [r15+0x40]
00007ec68bfd1a2a  vmovq xmm14, rax
00007ec68bfd1a2f  vpbroadcastq xmm14, xmm14
00007ec68bfd1a34  movaps [r15+0x170], xmm14
00007ec68bfd1a3c  mov eax, 0x420A40
00007ec68bfd1a41  movups xmm13, [r13+rax*1]
00007ec68bfd1a47  mov qword ptr [r15+0x40], 0x431E00
00007ec68bfd1a4f  mov eax, [r15]
00007ec68bfd1a52  mov r14d, 0x430CB8
00007ec68bfd1a58  mov [r13+r14*1], eax
00007ec68bfd1a5d  mov qword ptr [r15+0x50], 0x432000
00007ec68bfd1a65  vpmovqd xmm12, xmm13
00007ec68bfd1a6b  pxor xmm11, xmm11
00007ec68bfd1a70  punpcklqdq xmm12, xmm11
00007ec68bfd1a75  movaps [r15+0x210], xmm12
00007ec68bfd1a7d  movq xmm12, qword ptr [r15+0x140]
00007ec68bfd1a86  movq xmm11, qword ptr [r15+0x120]
00007ec68bfd1a8f  psubd xmm12, xmm11
00007ec68bfd1a94  movq xmm12, xmm12
00007ec68bfd1a99  paddq xmm13, xmm14
00007ec68bfd1a9e  movaps [r15+0x180], xmm13
00007ec68bfd1aa6  movq xmm14, qword ptr [r15+0x160]
00007ec68bfd1aaf  paddd xmm11, xmm14
00007ec68bfd1ab4  movq xmm11, xmm11
00007ec68bfd1ab9  movq xmm11, xmm11
00007ec68bfd1abe  movaps [r15+0x120], xmm11
00007ec68bfd1ac6  pmovzxdq xmm12, xmm12
00007ec68bfd1acc  psllq xmm12, 0x00
00007ec68bfd1ad2  movq xmm14, qword ptr [r15+0x210]
00007ec68bfd1adb  movq xmm13, qword ptr [r15+0x110]
00007ec68bfd1ae4  paddd xmm14, xmm13
00007ec68bfd1ae9  movq xmm14, xmm14
00007ec68bfd1aee  vcvtuqq2pd xmm12, xmm12
00007ec68bfd1af4  pmovzxdq xmm14, xmm14
00007ec68bfd1afa  psllq xmm14, 0x00
00007ec68bfd1b00  vcvtuqq2pd xmm14, xmm14
00007ec68bfd1b06  movaps xmm13, xmm12
00007ec68bfd1b0a  mulpd xmm13, xmm1
00007ec68bfd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007ec68bfd1b15  ptest xmm11, xmm11
00007ec68bfd1b1b  jnz 0x00007EC68BFD1C0F
00007ec68bfd1b21  movaps [r15+0x220], xmm13
00007ec68bfd1b29  mov eax, 0x432000
00007ec68bfd1b2e  movups [r13+rax*1], xmm13
00007ec68bfd1b34  movaps xmm1, xmm14
00007ec68bfd1b38  mulpd xmm1, xmm15
00007ec68bfd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007ec68bfd1b42  ptest xmm13, xmm13
00007ec68bfd1b48  jnz 0x00007EC68BFD1D5C
00007ec68bfd1b4e  movaps [r15+0x210], xmm1
00007ec68bfd1b56  mov eax, 0x431E00
00007ec68bfd1b5b  movups [r13+rax*1], xmm1
00007ec68bfd1b61  mov qword ptr [r15+0x48], 0x10
00007ec68bfd1b69  xor eax, eax
00007ec68bfd1b6b  mov r14d, 0x10
00007ec68bfd1b71  mov r12d, 0x200
00007ec68bfd1b77  cmp r14, r12
00007ec68bfd1b7a  cmc
00007ec68bfd1b7b  lahf
00007ec68bfd1b7c  seto al
00007ec68bfd1b7f  mov [r15+0x108], eax
00007ec68bfd1b86  mov eax, [r15+0x108]
00007ec68bfd1b8d  sahf
00007ec68bfd1b8e  jnz 0x00007EC68BFD1BC0
00007ec68bfd1b90  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd1b98  jz 0x00007EC68BFD2300
00007ec68bfd1b9e  nop [rax+rax*1], ax
00007ec68bfd1ba7  nop [rax+rax*1], eax
00007ec68bfd1baf  mov eax, 0x410490
00007ec68bfd1bb4  mov [r15+0x100], rax
00007ec68bfd1bbb  jmp 0x00007EC68BDFE110
00007ec68bfd1bc0  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd1bc8  jz 0x00007EC68BFD1EB0
00007ec68bfd1bce  nop [rax+rax*1], ax
00007ec68bfd1bd7  nop [rax+rax*1], eax
00007ec68bfd1bdf  mov eax, 0x410450
00007ec68bfd1be4  mov [r15+0x100], rax
00007ec68bfd1beb  jmp 0x00007EC68BDFE110
00007ec68bfd1bf0  int3
00007ec68bfd1bf1  call 0x00007EC68BE0DC20
00007ec68bfd1bf6  jmp 0x00007EC68BFD19BE
00007ec68bfd1bfb  call 0x00007EC68BE0C260
00007ec68bfd1c00  jmp 0x00007EC68BFD1A47
00007ec68bfd1c05  call 0x00007EC68BED5D70
00007ec68bfd1c0a  jmp 0x00007EC68BFD1A5D
00007ec68bfd1c0f  sub rsp, 0x08
00007ec68bfd1c13  push rax
00007ec68bfd1c14  push rcx
00007ec68bfd1c15  push rdx
00007ec68bfd1c16  push rdi
00007ec68bfd1c17  push rsi
00007ec68bfd1c18  push r8
00007ec68bfd1c1a  push r9
00007ec68bfd1c1c  push r10
00007ec68bfd1c1e  push r11
00007ec68bfd1c20  sub rsp, 0xF0
00007ec68bfd1c27  vmovaps [rsp], xmm0
00007ec68bfd1c2c  vmovaps [rsp+0x10], xmm1
00007ec68bfd1c32  vmovaps [rsp+0x20], xmm2
00007ec68bfd1c38  vmovaps [rsp+0x30], xmm3
00007ec68bfd1c3e  vmovaps [rsp+0x40], xmm4
00007ec68bfd1c44  vmovaps [rsp+0x50], xmm5
00007ec68bfd1c4a  vmovaps [rsp+0x60], xmm6
00007ec68bfd1c50  vmovaps [rsp+0x70], xmm7
00007ec68bfd1c56  vmovaps [rsp+0x80], xmm8
00007ec68bfd1c5f  vmovaps [rsp+0x90], xmm9
00007ec68bfd1c68  vmovaps [rsp+0xA0], xmm10
00007ec68bfd1c71  vmovaps [rsp+0xB0], xmm11
00007ec68bfd1c7a  vmovaps [rsp+0xC0], xmm12
00007ec68bfd1c83  vmovaps [rsp+0xD0], xmm14
00007ec68bfd1c8c  vmovaps [rsp+0xE0], xmm15
00007ec68bfd1c95  sub rsp, 0x30
00007ec68bfd1c99  movaps [rsp], xmm13
00007ec68bfd1c9e  movaps [rsp+0x10], xmm12
00007ec68bfd1ca4  movaps [rsp+0x20], xmm1
00007ec68bfd1ca9  lea rdi, [rsp]
00007ec68bfd1cad  mov esi, 0x00
00007ec68bfd1cb2  mov rax, 0x57D97DADF530
00007ec68bfd1cbc  call rax
00007ec68bfd1cbe  movaps xmm13, [rsp]
00007ec68bfd1cc3  add rsp, 0x30
00007ec68bfd1cc7  vmovaps xmm0, [rsp]
00007ec68bfd1ccc  vmovaps xmm1, [rsp+0x10]
00007ec68bfd1cd2  vmovaps xmm2, [rsp+0x20]
00007ec68bfd1cd8  vmovaps xmm3, [rsp+0x30]
00007ec68bfd1cde  vmovaps xmm4, [rsp+0x40]
00007ec68bfd1ce4  vmovaps xmm5, [rsp+0x50]
00007ec68bfd1cea  vmovaps xmm6, [rsp+0x60]
00007ec68bfd1cf0  vmovaps xmm7, [rsp+0x70]
00007ec68bfd1cf6  vmovaps xmm8, [rsp+0x80]
00007ec68bfd1cff  vmovaps xmm9, [rsp+0x90]
00007ec68bfd1d08  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd1d11  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd1d1a  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd1d23  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd1d2c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd1d35  add rsp, 0xF0
00007ec68bfd1d3c  pop r11
00007ec68bfd1d3e  pop r10
00007ec68bfd1d40  pop r9
00007ec68bfd1d42  pop r8
00007ec68bfd1d44  pop rsi
00007ec68bfd1d45  pop rdi
00007ec68bfd1d46  pop rdx
00007ec68bfd1d47  pop rcx
00007ec68bfd1d48  pop rax
00007ec68bfd1d49  add rsp, 0x08
00007ec68bfd1d4d  jmp 0x00007EC68BFD1B21
00007ec68bfd1d52  call 0x00007EC68BE0C380
00007ec68bfd1d57  jmp 0x00007EC68BFD1B34
00007ec68bfd1d5c  sub rsp, 0x08
00007ec68bfd1d60  push rax
00007ec68bfd1d61  push rcx
00007ec68bfd1d62  push rdx
00007ec68bfd1d63  push rdi
00007ec68bfd1d64  push rsi
00007ec68bfd1d65  push r8
00007ec68bfd1d67  push r9
00007ec68bfd1d69  push r10
00007ec68bfd1d6b  push r11
00007ec68bfd1d6d  sub rsp, 0xF0
00007ec68bfd1d74  vmovaps [rsp], xmm0
00007ec68bfd1d79  vmovaps [rsp+0x10], xmm2
00007ec68bfd1d7f  vmovaps [rsp+0x20], xmm3
00007ec68bfd1d85  vmovaps [rsp+0x30], xmm4
00007ec68bfd1d8b  vmovaps [rsp+0x40], xmm5
00007ec68bfd1d91  vmovaps [rsp+0x50], xmm6
00007ec68bfd1d97  vmovaps [rsp+0x60], xmm7
00007ec68bfd1d9d  vmovaps [rsp+0x70], xmm8
00007ec68bfd1da3  vmovaps [rsp+0x80], xmm9
00007ec68bfd1dac  vmovaps [rsp+0x90], xmm10
00007ec68bfd1db5  vmovaps [rsp+0xA0], xmm11
00007ec68bfd1dbe  vmovaps [rsp+0xB0], xmm12
00007ec68bfd1dc7  vmovaps [rsp+0xC0], xmm13
00007ec68bfd1dd0  vmovaps [rsp+0xD0], xmm14
00007ec68bfd1dd9  vmovaps [rsp+0xE0], xmm15
00007ec68bfd1de2  sub rsp, 0x30
00007ec68bfd1de6  movaps [rsp], xmm1
00007ec68bfd1dea  movaps [rsp+0x10], xmm14
00007ec68bfd1df0  movaps [rsp+0x20], xmm15
00007ec68bfd1df6  lea rdi, [rsp]
00007ec68bfd1dfa  mov esi, 0x00
00007ec68bfd1dff  mov rax, 0x57D97DADF530
00007ec68bfd1e09  call rax
00007ec68bfd1e0b  movaps xmm1, [rsp]
00007ec68bfd1e0f  add rsp, 0x30
00007ec68bfd1e13  vmovaps xmm0, [rsp]
00007ec68bfd1e18  vmovaps xmm2, [rsp+0x10]
00007ec68bfd1e1e  vmovaps xmm3, [rsp+0x20]
00007ec68bfd1e24  vmovaps xmm4, [rsp+0x30]
00007ec68bfd1e2a  vmovaps xmm5, [rsp+0x40]
00007ec68bfd1e30  vmovaps xmm6, [rsp+0x50]
00007ec68bfd1e36  vmovaps xmm7, [rsp+0x60]
00007ec68bfd1e3c  vmovaps xmm8, [rsp+0x70]
00007ec68bfd1e42  vmovaps xmm9, [rsp+0x80]
00007ec68bfd1e4b  vmovaps xmm10, [rsp+0x90]
00007ec68bfd1e54  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd1e5d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd1e66  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd1e6f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd1e78  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd1e81  add rsp, 0xF0
00007ec68bfd1e88  pop r11
00007ec68bfd1e8a  pop r10
00007ec68bfd1e8c  pop r9
00007ec68bfd1e8e  pop r8
00007ec68bfd1e90  pop rsi
00007ec68bfd1e91  pop rdi
00007ec68bfd1e92  pop rdx
00007ec68bfd1e93  pop rcx
00007ec68bfd1e94  pop rax
00007ec68bfd1e95  add rsp, 0x08
00007ec68bfd1e99  jmp 0x00007EC68BFD1B4E
00007ec68bfd1e9e  call 0x00007EC68BDFF540
00007ec68bfd1ea3  jmp 0x00007EC68BFD1B61
00007ec68bfd1ea8  int3
00007ec68bfd1ea9  nop [rax], eax
00007ec68bfd1eb0  movaps xmm1, [r15+0x180]
00007ec68bfd1eb8  vpmovqd xmm15, xmm1
00007ec68bfd1ebe  pxor xmm14, xmm14
00007ec68bfd1ec3  punpcklqdq xmm15, xmm14
00007ec68bfd1ec8  movaps [r15+0x210], xmm15
00007ec68bfd1ed0  movq xmm15, qword ptr [r15+0x140]
00007ec68bfd1ed9  movq xmm14, qword ptr [r15+0x120]
00007ec68bfd1ee2  psubd xmm15, xmm14
00007ec68bfd1ee7  movq xmm15, xmm15
00007ec68bfd1eec  movaps xmm13, [r15+0x170]
00007ec68bfd1ef4  paddq xmm1, xmm13
00007ec68bfd1ef9  movaps [r15+0x180], xmm1
00007ec68bfd1f01  movq xmm1, qword ptr [r15+0x160]
00007ec68bfd1f0a  paddd xmm14, xmm1
00007ec68bfd1f0f  movq xmm14, xmm14
00007ec68bfd1f14  movq xmm14, xmm14
00007ec68bfd1f19  movaps [r15+0x120], xmm14
00007ec68bfd1f21  pmovzxdq xmm15, xmm15
00007ec68bfd1f27  psllq xmm15, 0x00
00007ec68bfd1f2d  movq xmm1, qword ptr [r15+0x210]
00007ec68bfd1f36  movq xmm14, qword ptr [r15+0x110]
00007ec68bfd1f3f  paddd xmm1, xmm14
00007ec68bfd1f44  movq xmm1, xmm1
00007ec68bfd1f48  vcvtuqq2pd xmm15, xmm15
00007ec68bfd1f4e  pmovzxdq xmm1, xmm1
00007ec68bfd1f53  psllq xmm1, 0x00
00007ec68bfd1f58  vcvtuqq2pd xmm1, xmm1
00007ec68bfd1f5e  movaps xmm14, [r15+0x150]
00007ec68bfd1f66  movaps xmm13, xmm15
00007ec68bfd1f6a  mulpd xmm13, xmm14
00007ec68bfd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007ec68bfd1f75  ptest xmm12, xmm12
00007ec68bfd1f7b  jnz 0x00007EC68BFD205E
00007ec68bfd1f81  movaps [r15+0x220], xmm13
00007ec68bfd1f89  mov rax, [r15+0x48]
00007ec68bfd1f8d  mov r14, [r15+0x50]
00007ec68bfd1f91  lea r12, [r14+rax*1]
00007ec68bfd1f95  movups [r13+r12*1], xmm13
00007ec68bfd1f9b  movaps xmm15, [r15+0x130]
00007ec68bfd1fa3  movaps xmm14, xmm1
00007ec68bfd1fa7  mulpd xmm14, xmm15
00007ec68bfd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007ec68bfd1fb2  ptest xmm13, xmm13
00007ec68bfd1fb8  jnz 0x00007EC68BFD21AC
00007ec68bfd1fbe  movaps [r15+0x210], xmm14
00007ec68bfd1fc6  mov r14, [r15+0x40]
00007ec68bfd1fca  lea r12, [r14+rax*1]
00007ec68bfd1fce  movups [r13+r12*1], xmm14
00007ec68bfd1fd4  lea r14, [rax+0x10]
00007ec68bfd1fd8  mov [r15+0x48], r14
00007ec68bfd1fdc  xor eax, eax
00007ec68bfd1fde  mov r12d, 0x200
00007ec68bfd1fe4  cmp r14, r12
00007ec68bfd1fe7  cmc
00007ec68bfd1fe8  lahf
00007ec68bfd1fe9  seto al
00007ec68bfd1fec  mov [r15+0x108], eax
00007ec68bfd1ff3  mov eax, [r15+0x108]
00007ec68bfd1ffa  sahf
00007ec68bfd1ffb  jnz 0x00007EC68BFD202D
00007ec68bfd1ffd  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd2005  jz 0x00007EC68BFD2300
00007ec68bfd200b  nop [rax+rax*1], ax
00007ec68bfd2014  nop [rax+rax*1], eax
00007ec68bfd201c  mov eax, 0x410490
00007ec68bfd2021  mov [r15+0x100], rax
00007ec68bfd2028  jmp 0x00007EC68BDFE110
00007ec68bfd202d  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd2035  jz 0x00007EC68BFD1EB0
00007ec68bfd203b  nop [rax+rax*1], ax
00007ec68bfd2044  nop [rax+rax*1], eax
00007ec68bfd204c  mov eax, 0x410450
00007ec68bfd2051  mov [r15+0x100], rax
00007ec68bfd2058  jmp 0x00007EC68BDFE110
00007ec68bfd205d  int3
00007ec68bfd205e  sub rsp, 0x08
00007ec68bfd2062  push rax
00007ec68bfd2063  push rcx
00007ec68bfd2064  push rdx
00007ec68bfd2065  push rdi
00007ec68bfd2066  push rsi
00007ec68bfd2067  push r8
00007ec68bfd2069  push r9
00007ec68bfd206b  push r10
00007ec68bfd206d  push r11
00007ec68bfd206f  sub rsp, 0xF0
00007ec68bfd2076  vmovaps [rsp], xmm0
00007ec68bfd207b  vmovaps [rsp+0x10], xmm1
00007ec68bfd2081  vmovaps [rsp+0x20], xmm2
00007ec68bfd2087  vmovaps [rsp+0x30], xmm3
00007ec68bfd208d  vmovaps [rsp+0x40], xmm4
00007ec68bfd2093  vmovaps [rsp+0x50], xmm5
00007ec68bfd2099  vmovaps [rsp+0x60], xmm6
00007ec68bfd209f  vmovaps [rsp+0x70], xmm7
00007ec68bfd20a5  vmovaps [rsp+0x80], xmm8
00007ec68bfd20ae  vmovaps [rsp+0x90], xmm9
00007ec68bfd20b7  vmovaps [rsp+0xA0], xmm10
00007ec68bfd20c0  vmovaps [rsp+0xB0], xmm11
00007ec68bfd20c9  vmovaps [rsp+0xC0], xmm12
00007ec68bfd20d2  vmovaps [rsp+0xD0], xmm14
00007ec68bfd20db  vmovaps [rsp+0xE0], xmm15
00007ec68bfd20e4  sub rsp, 0x30
00007ec68bfd20e8  movaps [rsp], xmm13
00007ec68bfd20ed  movaps [rsp+0x10], xmm15
00007ec68bfd20f3  movaps [rsp+0x20], xmm14
00007ec68bfd20f9  lea rdi, [rsp]
00007ec68bfd20fd  mov esi, 0x00
00007ec68bfd2102  mov rax, 0x57D97DADF530
00007ec68bfd210c  call rax
00007ec68bfd210e  movaps xmm13, [rsp]
00007ec68bfd2113  add rsp, 0x30
00007ec68bfd2117  vmovaps xmm0, [rsp]
00007ec68bfd211c  vmovaps xmm1, [rsp+0x10]
00007ec68bfd2122  vmovaps xmm2, [rsp+0x20]
00007ec68bfd2128  vmovaps xmm3, [rsp+0x30]
00007ec68bfd212e  vmovaps xmm4, [rsp+0x40]
00007ec68bfd2134  vmovaps xmm5, [rsp+0x50]
00007ec68bfd213a  vmovaps xmm6, [rsp+0x60]
00007ec68bfd2140  vmovaps xmm7, [rsp+0x70]
00007ec68bfd2146  vmovaps xmm8, [rsp+0x80]
00007ec68bfd214f  vmovaps xmm9, [rsp+0x90]
00007ec68bfd2158  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd2161  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd216a  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd2173  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd217c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd2185  add rsp, 0xF0
00007ec68bfd218c  pop r11
00007ec68bfd218e  pop r10
00007ec68bfd2190  pop r9
00007ec68bfd2192  pop r8
00007ec68bfd2194  pop rsi
00007ec68bfd2195  pop rdi
00007ec68bfd2196  pop rdx
00007ec68bfd2197  pop rcx
00007ec68bfd2198  pop rax
00007ec68bfd2199  add rsp, 0x08
00007ec68bfd219d  jmp 0x00007EC68BFD1F81
00007ec68bfd21a2  call 0x00007EC68BEC2240
00007ec68bfd21a7  jmp 0x00007EC68BFD1F9B
00007ec68bfd21ac  sub rsp, 0x08
00007ec68bfd21b0  push rax
00007ec68bfd21b1  push rcx
00007ec68bfd21b2  push rdx
00007ec68bfd21b3  push rdi
00007ec68bfd21b4  push rsi
00007ec68bfd21b5  push r8
00007ec68bfd21b7  push r9
00007ec68bfd21b9  push r10
00007ec68bfd21bb  push r11
00007ec68bfd21bd  sub rsp, 0xF0
00007ec68bfd21c4  vmovaps [rsp], xmm0
00007ec68bfd21c9  vmovaps [rsp+0x10], xmm1
00007ec68bfd21cf  vmovaps [rsp+0x20], xmm2
00007ec68bfd21d5  vmovaps [rsp+0x30], xmm3
00007ec68bfd21db  vmovaps [rsp+0x40], xmm4
00007ec68bfd21e1  vmovaps [rsp+0x50], xmm5
00007ec68bfd21e7  vmovaps [rsp+0x60], xmm6
00007ec68bfd21ed  vmovaps [rsp+0x70], xmm7
00007ec68bfd21f3  vmovaps [rsp+0x80], xmm8
00007ec68bfd21fc  vmovaps [rsp+0x90], xmm9
00007ec68bfd2205  vmovaps [rsp+0xA0], xmm10
00007ec68bfd220e  vmovaps [rsp+0xB0], xmm11
00007ec68bfd2217  vmovaps [rsp+0xC0], xmm12
00007ec68bfd2220  vmovaps [rsp+0xD0], xmm13
00007ec68bfd2229  vmovaps [rsp+0xE0], xmm15
00007ec68bfd2232  sub rsp, 0x30
00007ec68bfd2236  movaps [rsp], xmm14
00007ec68bfd223b  movaps [rsp+0x10], xmm1
00007ec68bfd2240  movaps [rsp+0x20], xmm15
00007ec68bfd2246  lea rdi, [rsp]
00007ec68bfd224a  mov esi, 0x00
00007ec68bfd224f  mov rax, 0x57D97DADF530
00007ec68bfd2259  call rax
00007ec68bfd225b  movaps xmm14, [rsp]
00007ec68bfd2260  add rsp, 0x30
00007ec68bfd2264  vmovaps xmm0, [rsp]
00007ec68bfd2269  vmovaps xmm1, [rsp+0x10]
00007ec68bfd226f  vmovaps xmm2, [rsp+0x20]
00007ec68bfd2275  vmovaps xmm3, [rsp+0x30]
00007ec68bfd227b  vmovaps xmm4, [rsp+0x40]
00007ec68bfd2281  vmovaps xmm5, [rsp+0x50]
00007ec68bfd2287  vmovaps xmm6, [rsp+0x60]
00007ec68bfd228d  vmovaps xmm7, [rsp+0x70]
00007ec68bfd2293  vmovaps xmm8, [rsp+0x80]
00007ec68bfd229c  vmovaps xmm9, [rsp+0x90]
00007ec68bfd22a5  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd22ae  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd22b7  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd22c0  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd22c9  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd22d2  add rsp, 0xF0
00007ec68bfd22d9  pop r11
00007ec68bfd22db  pop r10
00007ec68bfd22dd  pop r9
00007ec68bfd22df  pop r8
00007ec68bfd22e1  pop rsi
00007ec68bfd22e2  pop rdi
00007ec68bfd22e3  pop rdx
00007ec68bfd22e4  pop rcx
00007ec68bfd22e5  pop rax
00007ec68bfd22e6  add rsp, 0x08
00007ec68bfd22ea  jmp 0x00007EC68BFD1FBE
00007ec68bfd22ef  call 0x00007EC68BEC34C0
00007ec68bfd22f4  jmp 0x00007EC68BFD1FD4
00007ec68bfd22f9  int3
00007ec68bfd22fa  nop [rax+rax*1], ax
00007ec68bfd2300  mov rax, [r15+0x50]
00007ec68bfd2304  lea r14, [rax+0x80]
00007ec68bfd230b  movups xmm1, [r13+r14*1]
00007ec68bfd2311  lea r14, [rax+0x90]
00007ec68bfd2318  movups xmm15, [r13+r14*1]
00007ec68bfd231e  vxorps xmm14, xmm14, xmm14
00007ec68bfd2323  vpbroadcastq xmm14, xmm14
00007ec68bfd2328  lea r14, [rax+0x40]
00007ec68bfd232c  movups xmm13, [r13+r14*1]
00007ec68bfd2332  lea r14, [rax+0x50]
00007ec68bfd2336  movups xmm12, [r13+r14*1]
00007ec68bfd233c  mov qword ptr [r15+0x48], 0x00
00007ec68bfd2344  movups xmm11, [r13+rax*1]
00007ec68bfd234a  lea r14, [rax+0x10]
00007ec68bfd234e  movups xmm10, [r13+r14*1]
00007ec68bfd2354  mov r14, [r15+0xF8]
00007ec68bfd235b  lea r12, [r14+0xE0]
00007ec68bfd2362  movups [r13+r12*1], xmm15
00007ec68bfd2368  lea r12, [r14+0xF0]
00007ec68bfd236f  movups [r13+r12*1], xmm1
00007ec68bfd2375  lea r12, [rax+0xC0]
00007ec68bfd237c  movups xmm1, [r13+r12*1]
00007ec68bfd2382  lea r12, [rax+0xD0]
00007ec68bfd2389  movups xmm15, [r13+r12*1]
00007ec68bfd238f  lea r12, [rax+0x140]
00007ec68bfd2396  movups xmm9, [r13+r12*1]
00007ec68bfd239c  lea r12, [rax+0x150]
00007ec68bfd23a3  movups xmm8, [r13+r12*1]
00007ec68bfd23a9  lea r12, [rax+0x180]
00007ec68bfd23b0  movups xmm7, [r13+r12*1]
00007ec68bfd23b6  lea r12, [rax+0x190]
00007ec68bfd23bd  movups xmm6, [r13+r12*1]
00007ec68bfd23c3  lea r12, [r14+0xC0]
00007ec68bfd23ca  movups [r13+r12*1], xmm15
00007ec68bfd23d0  lea r12, [r14+0xD0]
00007ec68bfd23d7  movups [r13+r12*1], xmm1
00007ec68bfd23dd  lea r12, [rax+0x100]
00007ec68bfd23e4  movups xmm1, [r13+r12*1]
00007ec68bfd23ea  lea r12, [rax+0x110]
00007ec68bfd23f1  movups xmm15, [r13+r12*1]
00007ec68bfd23f7  lea r12, [rax+0x1C0]
00007ec68bfd23fe  movups xmm5, [r13+r12*1]
00007ec68bfd2404  lea r12, [rax+0x1D0]
00007ec68bfd240b  movups xmm4, [r13+r12*1]
00007ec68bfd2411  lea r12, [rax+0x20]
00007ec68bfd2415  movups xmm3, [r13+r12*1]
00007ec68bfd241b  lea r12, [rax+0x30]
00007ec68bfd241f  movups xmm2, [r13+r12*1]
00007ec68bfd2425  movaps [r15+0x1F0], xmm2
00007ec68bfd242d  lea r12, [r14+0x20]
00007ec68bfd2431  movups [r13+r12*1], xmm1
00007ec68bfd2437  lea r12, [r14+0x30]
00007ec68bfd243b  movups [r13+r12*1], xmm12
00007ec68bfd2441  lea r12, [rax+0x60]
00007ec68bfd2445  movups xmm1, [r13+r12*1]
00007ec68bfd244b  lea r12, [rax+0x70]
00007ec68bfd244f  movups xmm12, [r13+r12*1]
00007ec68bfd2455  lea r12, [r14+0x60]
00007ec68bfd2459  movups [r13+r12*1], xmm11
00007ec68bfd245f  lea r12, [r14+0x70]
00007ec68bfd2463  movups [r13+r12*1], xmm5
00007ec68bfd2469  lea r12, [rax+0xE0]
00007ec68bfd2470  movups xmm11, [r13+r12*1]
00007ec68bfd2476  lea r12, [rax+0xF0]
00007ec68bfd247d  movups xmm5, [r13+r12*1]
00007ec68bfd2483  lea r12, [rax+0x120]
00007ec68bfd248a  vmovaps [rsp+0x10], xmm1
00007ec68bfd2490  movups xmm1, [r13+r12*1]
00007ec68bfd2496  lea r12, [rax+0x130]
00007ec68bfd249d  vmovaps [rsp+0x20], xmm1
00007ec68bfd24a3  movups xmm1, [r13+r12*1]
00007ec68bfd24a9  lea r12, [r14+0xA0]
00007ec68bfd24b0  movups [r13+r12*1], xmm12
00007ec68bfd24b6  lea r12, [r14+0xB0]
00007ec68bfd24bd  vmovaps xmm12, [rsp+0x10]
00007ec68bfd24c3  movups [r13+r12*1], xmm12
00007ec68bfd24c9  lea r12, [rax+0xA0]
00007ec68bfd24d0  movups xmm12, [r13+r12*1]
00007ec68bfd24d6  lea r12, [rax+0xB0]
00007ec68bfd24dd  vmovaps [rsp+0x10], xmm1
00007ec68bfd24e3  movups xmm1, [r13+r12*1]
00007ec68bfd24e9  lea r12, [rax+0x160]
00007ec68bfd24f0  vmovaps [rsp+0x30], xmm1
00007ec68bfd24f6  movups xmm1, [r13+r12*1]
00007ec68bfd24fc  lea r12, [rax+0x170]
00007ec68bfd2503  vmovaps [rsp+0x40], xmm1
00007ec68bfd2509  movups xmm1, [r13+r12*1]
00007ec68bfd250f  movaps [r15+0x2B0], xmm1
00007ec68bfd2517  lea r12, [rax+0x1A0]
00007ec68bfd251e  vmovaps [rsp+0x50], xmm1
00007ec68bfd2524  movups xmm1, [r13+r12*1]
00007ec68bfd252a  lea r12, [rax+0x1B0]
00007ec68bfd2531  vmovaps [rsp+0x60], xmm1
00007ec68bfd2537  movups xmm1, [r13+r12*1]
00007ec68bfd253d  vmovaps [rsp+0x70], xmm1
00007ec68bfd2543  vmovaps xmm1, [rsp+0x60]
00007ec68bfd2549  movaps [r15+0x290], xmm1
00007ec68bfd2551  vmovaps [rsp+0x60], xmm1
00007ec68bfd2557  vmovaps xmm1, [rsp+0x70]
00007ec68bfd255d  movaps [r15+0x1E0], xmm1
00007ec68bfd2565  lea r12, [r14+0x80]
00007ec68bfd256c  vmovaps [rsp+0x70], xmm1
00007ec68bfd2572  vmovaps xmm1, [rsp+0x30]
00007ec68bfd2578  movups [r13+r12*1], xmm1
00007ec68bfd257e  lea r12, [r14+0x90]
00007ec68bfd2585  movups [r13+r12*1], xmm12
00007ec68bfd258b  lea r12, [rax+0x1E0]
00007ec68bfd2592  movups xmm1, [r13+r12*1]
00007ec68bfd2598  lea r12, [rax+0x1F0]
00007ec68bfd259f  movups xmm12, [r13+r12*1]
00007ec68bfd25a5  mov qword ptr [r15+0x50], 0x432200
00007ec68bfd25ad  lea rax, [r14+0x40]
00007ec68bfd25b1  vmovaps [rsp+0x30], xmm1
00007ec68bfd25b7  vmovaps xmm1, [rsp+0x40]
00007ec68bfd25bd  movups [r13+rax*1], xmm1
00007ec68bfd25c3  lea rax, [r14+0x50]
00007ec68bfd25c7  movups [r13+rax*1], xmm10
00007ec68bfd25cd  movups [r13+r14*1], xmm12
00007ec68bfd25d3  lea rax, [r14+0x10]
00007ec68bfd25d7  vmovaps xmm1, [rsp+0x30]
00007ec68bfd25dd  movups [r13+rax*1], xmm1
00007ec68bfd25e3  mov rax, [r15+0x40]
00007ec68bfd25e7  vmovaps [rsp+0x30], xmm3
00007ec68bfd25ed  vmovaps xmm1, [rsp+0x30]
00007ec68bfd25f3  por xmm3, xmm1
00007ec68bfd25f7  vmovaps [rsp+0x30], xmm6
00007ec68bfd25fd  vmovaps xmm12, [rsp+0x30]
00007ec68bfd2603  por xmm6, xmm12
00007ec68bfd2608  lea r12, [rax+0x30]
00007ec68bfd260c  mov r11, [r13+r12*1]
00007ec68bfd2611  lea r12, [rax+0x38]
00007ec68bfd2615  mov r10, [r13+r12*1]
00007ec68bfd261a  movq xmm12, r11
00007ec68bfd261f  movq xmm10, r10
00007ec68bfd2624  movq xmm12, xmm12
00007ec68bfd2629  vmovaps [rsp+0x30], xmm12
00007ec68bfd262f  movq xmm12, xmm12
00007ec68bfd2634  movaps [r15+0x130], xmm12
00007ec68bfd263c  movq xmm10, xmm10
00007ec68bfd2641  vmovaps [rsp+0x40], xmm10
00007ec68bfd2647  movq xmm10, xmm10
00007ec68bfd264c  movaps [r15+0x280], xmm10
00007ec68bfd2654  vmovaps [rsp+0x80], xmm9
00007ec68bfd265d  vmovaps xmm12, [rsp+0x80]
00007ec68bfd2666  por xmm9, xmm12
00007ec68bfd266b  lea r12, [rax+0x20]
00007ec68bfd266f  mov r11, [r13+r12*1]
00007ec68bfd2674  lea r12, [rax+0x28]
00007ec68bfd2678  mov r10, [r13+r12*1]
00007ec68bfd267d  movq xmm12, r11
00007ec68bfd2682  movq xmm10, r10
00007ec68bfd2687  movq xmm12, xmm12
00007ec68bfd268c  vmovaps [rsp+0x80], xmm12
00007ec68bfd2695  movq xmm12, xmm12
00007ec68bfd269a  movaps [r15+0x150], xmm12
00007ec68bfd26a2  movq xmm10, xmm10
00007ec68bfd26a7  vmovaps [rsp+0x90], xmm10
00007ec68bfd26b0  movq xmm10, xmm10
00007ec68bfd26b5  movaps [r15+0x140], xmm10
00007ec68bfd26bd  lea r12, [rax+0x10]
00007ec68bfd26c1  mov r11, [r13+r12*1]
00007ec68bfd26c6  lea r12, [rax+0x18]
00007ec68bfd26ca  mov r10, [r13+r12*1]
00007ec68bfd26cf  movq xmm12, r11
00007ec68bfd26d4  movq xmm10, r10
00007ec68bfd26d9  movq xmm12, xmm12
00007ec68bfd26de  vmovaps [rsp+0xA0], xmm12
00007ec68bfd26e7  movq xmm12, xmm12
00007ec68bfd26ec  movaps [r15+0x170], xmm12
00007ec68bfd26f4  movq xmm10, xmm10
00007ec68bfd26f9  vmovaps [rsp+0xB0], xmm10
00007ec68bfd2702  movq xmm10, xmm10
00007ec68bfd2707  movaps [r15+0x160], xmm10
00007ec68bfd270f  mov r12, [r13+rax*1]
00007ec68bfd2714  vmovq xmm12, r12
00007ec68bfd2719  vpbroadcastq xmm12, xmm12
00007ec68bfd271e  lea r12, [rax+0x08]
00007ec68bfd2722  mov rax, [r13+r12*1]
00007ec68bfd2727  movq xmm10, rax
00007ec68bfd272c  movaps [r15+0x230], xmm10
00007ec68bfd2734  lea rax, [r14+0x50]
00007ec68bfd2738  movups xmm10, [r13+rax*1]
00007ec68bfd273e  lea rax, [r14+0x60]
00007ec68bfd2742  vmovaps [rsp+0xC0], xmm1
00007ec68bfd274b  movups xmm1, [r13+rax*1]
00007ec68bfd2751  lea rax, [r14+0x30]
00007ec68bfd2755  vmovaps [rsp+0xD0], xmm1
00007ec68bfd275e  movups xmm1, [r13+rax*1]
00007ec68bfd2764  mov qword ptr [r15+0x60], 0x432200
00007ec68bfd276c  mov qword ptr [r15+0x58], 0x40
00007ec68bfd2774  vmovaps [rsp+0xE0], xmm1
00007ec68bfd277d  vmovaps [rsp+0xF0], xmm15
00007ec68bfd2786  vmovaps xmm15, [rsp+0xC0]
00007ec68bfd278f  vmovaps [rsp+0xC0], xmm14
00007ec68bfd2798  movaps xmm1, xmm12
00007ec68bfd279c  mulpd xmm1, xmm15
00007ec68bfd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007ec68bfd27a6  ptest xmm14, xmm14
00007ec68bfd27ac  jnz 0x00007EC68BFD3863
00007ec68bfd27b2  movq xmm15, qword ptr [r15+0x230]
00007ec68bfd27bb  vmovaps [rsp+0x100], xmm15
00007ec68bfd27c4  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd27ca  vmovaps [rsp+0x110], xmm1
00007ec68bfd27d3  vmovaps xmm1, [rsp+0xE0]
00007ec68bfd27dc  vmovaps [rsp+0xE0], xmm13
00007ec68bfd27e5  movaps xmm14, xmm1
00007ec68bfd27e9  mulpd xmm14, xmm15
00007ec68bfd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007ec68bfd27f4  ptest xmm13, xmm13
00007ec68bfd27fa  jnz 0x00007EC68BFD39A5
00007ec68bfd2800  vxorps xmm1, xmm1, xmm1
00007ec68bfd2804  vpbroadcastq xmm1, xmm1
00007ec68bfd2809  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd2812  vmovaps [rsp+0xD0], xmm1
00007ec68bfd281b  movaps xmm15, xmm12
00007ec68bfd281f  mulpd xmm15, xmm13
00007ec68bfd2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007ec68bfd282a  ptest xmm1, xmm1
00007ec68bfd282f  jnz 0x00007EC68BFD3AE8
00007ec68bfd2835  movaps xmm1, xmm12
00007ec68bfd2839  mulpd xmm1, xmm10
00007ec68bfd283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007ec68bfd2843  ptest xmm13, xmm13
00007ec68bfd2849  jnz 0x00007EC68BFD3C2C
00007ec68bfd284f  movaps xmm13, xmm12
00007ec68bfd2853  mulpd xmm13, xmm2
00007ec68bfd2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007ec68bfd285e  ptest xmm10, xmm10
00007ec68bfd2864  jnz 0x00007EC68BFD3D6E
00007ec68bfd286a  vmovaps [rsp+0x120], xmm7
00007ec68bfd2873  vmovaps xmm12, [rsp+0x120]
00007ec68bfd287c  por xmm7, xmm12
00007ec68bfd2881  vmovaps xmm12, [rsp+0xE0]
00007ec68bfd288a  vmovaps xmm10, [rsp+0xE0]
00007ec68bfd2893  por xmm12, xmm10
00007ec68bfd2898  vmovaps xmm2, [rsp+0x100]
00007ec68bfd28a1  vpermilpd xmm2, xmm2, 0x00
00007ec68bfd28a7  vmovaps [rsp+0xE0], xmm1
00007ec68bfd28b0  vmovaps [rsp+0x120], xmm15
00007ec68bfd28b9  movaps xmm1, xmm10
00007ec68bfd28bd  mulpd xmm1, xmm2
00007ec68bfd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007ec68bfd28c6  ptest xmm15, xmm15
00007ec68bfd28cc  jnz 0x00007EC68BFD3EB1
00007ec68bfd28d2  xor eax, eax
00007ec68bfd28d4  mov r12d, 0x40
00007ec68bfd28da  mov r11d, 0x200
00007ec68bfd28e0  cmp r12, r11
00007ec68bfd28e3  cmc
00007ec68bfd28e4  lahf
00007ec68bfd28e5  seto al
00007ec68bfd28e8  mov [r15+0x108], eax
00007ec68bfd28ef  vmovaps xmm10, [rsp+0x110]
00007ec68bfd28f8  vmovaps xmm2, [rsp+0xD0]
00007ec68bfd2901  vmovaps [rsp+0xD0], xmm1
00007ec68bfd290a  movaps xmm15, xmm10
00007ec68bfd290e  addpd xmm15, xmm2
00007ec68bfd2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007ec68bfd2919  ptest xmm1, xmm1
00007ec68bfd291e  jnz 0x00007EC68BFD3FF2
00007ec68bfd2924  vmovaps xmm10, [rsp+0x120]
00007ec68bfd292d  vmovaps [rsp+0x110], xmm15
00007ec68bfd2936  vmovaps xmm15, [rsp+0xC0]
00007ec68bfd293f  vmovaps [rsp+0xC0], xmm14
00007ec68bfd2948  movaps xmm1, xmm10
00007ec68bfd294c  addpd xmm1, xmm15
00007ec68bfd2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007ec68bfd2956  ptest xmm14, xmm14
00007ec68bfd295c  jnz 0x00007EC68BFD4135
00007ec68bfd2962  vmovaps xmm10, [rsp+0xE0]
00007ec68bfd296b  vmovaps [rsp+0xE0], xmm1
00007ec68bfd2974  movaps xmm14, xmm10
00007ec68bfd2978  addpd xmm14, xmm15
00007ec68bfd297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007ec68bfd2983  ptest xmm1, xmm1
00007ec68bfd2988  jnz 0x00007EC68BFD4277
00007ec68bfd298e  vmovaps xmm1, [rsp+0x10]
00007ec68bfd2994  vmovaps xmm15, [rsp+0x10]
00007ec68bfd299a  por xmm1, xmm15
00007ec68bfd299f  vmovaps xmm15, [rsp+0x20]
00007ec68bfd29a5  vmovaps xmm10, [rsp+0x20]
00007ec68bfd29ab  por xmm15, xmm10
00007ec68bfd29b0  vmovaps [rsp+0x10], xmm5
00007ec68bfd29b6  vmovaps xmm10, [rsp+0x10]
00007ec68bfd29bc  por xmm5, xmm10
00007ec68bfd29c1  vmovaps [rsp+0x10], xmm11
00007ec68bfd29c7  vmovaps xmm10, [rsp+0x10]
00007ec68bfd29cd  por xmm11, xmm10
00007ec68bfd29d2  vmovaps [rsp+0x10], xmm4
00007ec68bfd29d8  vmovaps xmm10, [rsp+0x10]
00007ec68bfd29de  por xmm4, xmm10
00007ec68bfd29e3  vmovaps [rsp+0x10], xmm8
00007ec68bfd29e9  vmovaps xmm10, [rsp+0x10]
00007ec68bfd29ef  por xmm8, xmm10
00007ec68bfd29f4  vmovaps xmm10, [rsp+0xF0]
00007ec68bfd29fd  vmovaps [rsp+0x10], xmm1
00007ec68bfd2a03  vmovaps xmm1, [rsp+0xF0]
00007ec68bfd2a0c  por xmm10, xmm1
00007ec68bfd2a11  lea rax, [r14+0xA0]
00007ec68bfd2a18  movups xmm1, [r13+rax*1]
00007ec68bfd2a1e  lea rax, [r14+0xB0]
00007ec68bfd2a25  vmovaps [rsp+0x20], xmm1
00007ec68bfd2a2b  movups xmm1, [r13+rax*1]
00007ec68bfd2a31  vmovaps [rsp+0xF0], xmm1
00007ec68bfd2a3a  vmovaps [rsp+0x120], xmm15
00007ec68bfd2a43  movaps xmm1, xmm13
00007ec68bfd2a47  addpd xmm1, xmm2
00007ec68bfd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007ec68bfd2a50  ptest xmm15, xmm15
00007ec68bfd2a56  jnz 0x00007EC68BFD43CF
00007ec68bfd2a5c  lea rax, [r14+0xF0]
00007ec68bfd2a63  movups xmm15, [r13+rax*1]
00007ec68bfd2a69  vmovaps xmm2, [rsp+0xE0]
00007ec68bfd2a72  vmovaps [rsp+0xE0], xmm1
00007ec68bfd2a7b  vmovaps xmm1, [rsp+0xD0]
00007ec68bfd2a84  vmovaps [rsp+0xD0], xmm15
00007ec68bfd2a8d  movaps xmm13, xmm2
00007ec68bfd2a91  addpd xmm13, xmm1
00007ec68bfd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007ec68bfd2a9c  ptest xmm15, xmm15
00007ec68bfd2aa2  jnz 0x00007EC68BFD451A
00007ec68bfd2aa8  vmovaps xmm15, [rsp+0xC0]
00007ec68bfd2ab1  movaps xmm1, xmm14
00007ec68bfd2ab5  addpd xmm1, xmm15
00007ec68bfd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007ec68bfd2abf  ptest xmm2, xmm2
00007ec68bfd2ac4  jnz 0x00007EC68BFD465C
00007ec68bfd2aca  vmovaps xmm15, [rsp+0x100]
00007ec68bfd2ad3  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd2ad9  vmovaps xmm2, [rsp+0xF0]
00007ec68bfd2ae2  vmovaps [rsp+0xC0], xmm1
00007ec68bfd2aeb  movaps xmm14, xmm2
00007ec68bfd2aef  mulpd xmm14, xmm15
00007ec68bfd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007ec68bfd2afa  ptest xmm1, xmm1
00007ec68bfd2aff  jnz 0x00007EC68BFD479E
00007ec68bfd2b05  vmovaps xmm1, [rsp+0xA0]
00007ec68bfd2b0e  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd2b14  vmovaps xmm2, [rsp+0xD0]
00007ec68bfd2b1d  vmovaps [rsp+0xD0], xmm14
00007ec68bfd2b26  movaps xmm15, xmm2
00007ec68bfd2b2a  mulpd xmm15, xmm1
00007ec68bfd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007ec68bfd2b35  ptest xmm14, xmm14
00007ec68bfd2b3b  jnz 0x00007EC68BFD48E1
00007ec68bfd2b41  lea rax, [r14+0xE0]
00007ec68bfd2b48  movups xmm1, [r13+rax*1]
00007ec68bfd2b4e  vmovaps xmm14, [rsp+0x100]
00007ec68bfd2b57  vpermilpd xmm14, xmm14, 0x00
00007ec68bfd2b5d  vmovaps [rsp+0xF0], xmm1
00007ec68bfd2b66  vmovaps xmm1, [rsp+0x20]
00007ec68bfd2b6c  vmovaps [rsp+0x20], xmm15
00007ec68bfd2b72  movaps xmm2, xmm1
00007ec68bfd2b75  mulpd xmm2, xmm14
00007ec68bfd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007ec68bfd2b7f  ptest xmm15, xmm15
00007ec68bfd2b85  jnz 0x00007EC68BFD4A2D
00007ec68bfd2b8b  vmovaps [rsp+0x100], xmm10
00007ec68bfd2b94  vmovaps xmm1, [rsp+0x100]
00007ec68bfd2b9d  por xmm10, xmm1
00007ec68bfd2ba2  movaps [r15+0x300], xmm10
00007ec68bfd2baa  vmovaps [rsp+0x100], xmm8
00007ec68bfd2bb3  vmovaps xmm1, [rsp+0x100]
00007ec68bfd2bbc  por xmm8, xmm1
00007ec68bfd2bc1  movaps [r15+0x190], xmm8
00007ec68bfd2bc9  vmovaps xmm1, [rsp+0xA0]
00007ec68bfd2bd2  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd2bd8  vmovaps xmm14, [rsp+0xF0]
00007ec68bfd2be1  vmovaps [rsp+0xF0], xmm13
00007ec68bfd2bea  movaps xmm15, xmm14
00007ec68bfd2bee  mulpd xmm15, xmm1
00007ec68bfd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007ec68bfd2bf9  ptest xmm13, xmm13
00007ec68bfd2bff  jnz 0x00007EC68BFD4B6E
00007ec68bfd2c05  lea rax, [r14+0x90]
00007ec68bfd2c0c  movups xmm1, [r13+rax*1]
00007ec68bfd2c12  vmovaps [rsp+0x100], xmm4
00007ec68bfd2c1b  vmovaps xmm14, [rsp+0x100]
00007ec68bfd2c24  por xmm4, xmm14
00007ec68bfd2c29  movaps [r15+0x1C0], xmm4
00007ec68bfd2c31  vmovaps [rsp+0x100], xmm11
00007ec68bfd2c3a  vmovaps xmm14, [rsp+0x100]
00007ec68bfd2c43  por xmm11, xmm14
00007ec68bfd2c48  movaps [r15+0x200], xmm11
00007ec68bfd2c50  vmovaps [rsp+0x100], xmm5
00007ec68bfd2c59  vmovaps xmm14, [rsp+0x100]
00007ec68bfd2c62  por xmm5, xmm14
00007ec68bfd2c67  movaps [r15+0x2D0], xmm5
00007ec68bfd2c6f  vmovaps xmm14, [rsp+0x120]
00007ec68bfd2c78  vmovaps xmm13, [rsp+0x120]
00007ec68bfd2c81  por xmm14, xmm13
00007ec68bfd2c86  movaps [r15+0x2E0], xmm14
00007ec68bfd2c8e  vmovaps [rsp+0x100], xmm1
00007ec68bfd2c97  vmovaps xmm1, [rsp+0x110]
00007ec68bfd2ca0  vmovaps [rsp+0x110], xmm15
00007ec68bfd2ca9  vmovaps xmm15, [rsp+0xD0]
00007ec68bfd2cb2  vmovaps [rsp+0xD0], xmm14
00007ec68bfd2cbb  movaps xmm13, xmm1
00007ec68bfd2cbf  addpd xmm13, xmm15
00007ec68bfd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007ec68bfd2cca  ptest xmm14, xmm14
00007ec68bfd2cd0  jnz 0x00007EC68BFD4CBB
00007ec68bfd2cd6  vmovaps xmm1, [rsp+0xA0]
00007ec68bfd2cdf  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd2ce5  vmovaps xmm14, [rsp+0x100]
00007ec68bfd2cee  vmovaps [rsp+0x100], xmm13
00007ec68bfd2cf7  movaps xmm15, xmm14
00007ec68bfd2cfb  mulpd xmm15, xmm1
00007ec68bfd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007ec68bfd2d06  ptest xmm13, xmm13
00007ec68bfd2d0c  jnz 0x00007EC68BFD4DFE
00007ec68bfd2d12  lea rax, [r14+0x80]
00007ec68bfd2d19  movups xmm1, [r13+rax*1]
00007ec68bfd2d1f  vmovaps xmm13, [rsp+0xE0]
00007ec68bfd2d28  vmovaps [rsp+0xE0], xmm1
00007ec68bfd2d31  movaps xmm14, xmm13
00007ec68bfd2d35  addpd xmm14, xmm2
00007ec68bfd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007ec68bfd2d40  ptest xmm1, xmm1
00007ec68bfd2d45  jnz 0x00007EC68BFD4F4B
00007ec68bfd2d4b  vmovaps xmm13, [rsp+0xF0]
00007ec68bfd2d54  vmovaps xmm2, [rsp+0x20]
00007ec68bfd2d5a  vmovaps [rsp+0x20], xmm15
00007ec68bfd2d60  movaps xmm1, xmm13
00007ec68bfd2d64  addpd xmm1, xmm2
00007ec68bfd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007ec68bfd2d6d  ptest xmm15, xmm15
00007ec68bfd2d73  jnz 0x00007EC68BFD508E
00007ec68bfd2d79  vmovaps xmm15, [rsp+0x10]
00007ec68bfd2d7f  vmovaps xmm13, [rsp+0x10]
00007ec68bfd2d85  por xmm15, xmm13
00007ec68bfd2d8a  movaps [r15+0x2F0], xmm15
00007ec68bfd2d92  vmovaps xmm13, [rsp+0xA0]
00007ec68bfd2d9b  vpermilpd xmm13, xmm13, 0x00
00007ec68bfd2da1  vmovaps [rsp+0x10], xmm1
00007ec68bfd2da7  vmovaps xmm1, [rsp+0xE0]
00007ec68bfd2db0  vmovaps [rsp+0xA0], xmm15
00007ec68bfd2db9  movaps xmm2, xmm1
00007ec68bfd2dbc  mulpd xmm2, xmm13
00007ec68bfd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007ec68bfd2dc6  ptest xmm15, xmm15
00007ec68bfd2dcc  jnz 0x00007EC68BFD51CF
00007ec68bfd2dd2  lea rax, [r14+0xD0]
00007ec68bfd2dd9  movups xmm1, [r13+rax*1]
00007ec68bfd2ddf  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd2de8  vmovaps [rsp+0xC0], xmm1
00007ec68bfd2df1  vmovaps xmm1, [rsp+0x110]
00007ec68bfd2dfa  vmovaps [rsp+0xE0], xmm14
00007ec68bfd2e03  movaps xmm15, xmm13
00007ec68bfd2e07  addpd xmm15, xmm1
00007ec68bfd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007ec68bfd2e12  ptest xmm14, xmm14
00007ec68bfd2e18  jnz 0x00007EC68BFD531A
00007ec68bfd2e1e  vmovaps xmm1, [rsp+0xB0]
00007ec68bfd2e27  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd2e2d  movaps xmm14, xmm11
00007ec68bfd2e31  mulpd xmm14, xmm1
00007ec68bfd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007ec68bfd2e3c  ptest xmm13, xmm13
00007ec68bfd2e42  jnz 0x00007EC68BFD545D
00007ec68bfd2e48  movaps [r15+0x260], xmm14
00007ec68bfd2e50  vxorps xmm1, xmm1, xmm1
00007ec68bfd2e54  vpbroadcastq xmm1, xmm1
00007ec68bfd2e59  movaps [r15+0x1B0], xmm1
00007ec68bfd2e61  vmovaps xmm1, [rsp+0xB0]
00007ec68bfd2e6a  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd2e70  vmovaps xmm11, [rsp+0xC0]
00007ec68bfd2e79  vmovaps [rsp+0xC0], xmm15
00007ec68bfd2e82  movaps xmm13, xmm11
00007ec68bfd2e86  mulpd xmm13, xmm1
00007ec68bfd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007ec68bfd2e91  ptest xmm15, xmm15
00007ec68bfd2e97  jnz 0x00007EC68BFD55A0
00007ec68bfd2e9d  lea rax, [r14+0xC0]
00007ec68bfd2ea4  movups xmm1, [r13+rax*1]
00007ec68bfd2eaa  vmovaps xmm11, [rsp+0x100]
00007ec68bfd2eb3  vmovaps [rsp+0xF0], xmm1
00007ec68bfd2ebc  vmovaps xmm1, [rsp+0x20]
00007ec68bfd2ec2  vmovaps [rsp+0x20], xmm14
00007ec68bfd2ec8  movaps xmm15, xmm11
00007ec68bfd2ecc  addpd xmm15, xmm1
00007ec68bfd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007ec68bfd2ed7  ptest xmm14, xmm14
00007ec68bfd2edd  jnz 0x00007EC68BFD56ED
00007ec68bfd2ee3  vmovaps [rsp+0x100], xmm9
00007ec68bfd2eec  vmovaps xmm1, [rsp+0x100]
00007ec68bfd2ef5  por xmm9, xmm1
00007ec68bfd2efa  movaps [r15+0x270], xmm9
00007ec68bfd2f02  vmovaps [rsp+0x100], xmm6
00007ec68bfd2f0b  vmovaps xmm1, [rsp+0x100]
00007ec68bfd2f14  por xmm6, xmm1
00007ec68bfd2f18  movaps [r15+0x1A0], xmm6
00007ec68bfd2f20  vmovaps xmm14, [rsp+0xB0]
00007ec68bfd2f29  vpermilpd xmm14, xmm14, 0x00
00007ec68bfd2f2f  vmovaps xmm6, [rsp+0xF0]
00007ec68bfd2f38  vmovaps [rsp+0xF0], xmm1
00007ec68bfd2f41  movaps xmm11, xmm6
00007ec68bfd2f45  mulpd xmm11, xmm14
00007ec68bfd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007ec68bfd2f50  ptest xmm1, xmm1
00007ec68bfd2f55  jnz 0x00007EC68BFD5830
00007ec68bfd2f5b  lea rax, [r14+0x20]
00007ec68bfd2f5f  movups xmm1, [r13+rax*1]
00007ec68bfd2f65  movaps [r15+0x110], xmm1
00007ec68bfd2f6d  vmovaps xmm6, [rsp+0xE0]
00007ec68bfd2f76  vmovaps [rsp+0xE0], xmm1
00007ec68bfd2f7f  movaps xmm14, xmm6
00007ec68bfd2f83  addpd xmm14, xmm2
00007ec68bfd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007ec68bfd2f8e  ptest xmm1, xmm1
00007ec68bfd2f93  jnz 0x00007EC68BFD597D
00007ec68bfd2f99  vmovaps xmm1, [rsp+0xB0]
00007ec68bfd2fa2  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd2fa8  movaps xmm6, xmm5
00007ec68bfd2fab  mulpd xmm6, xmm1
00007ec68bfd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007ec68bfd2fb4  ptest xmm2, xmm2
00007ec68bfd2fb9  jnz 0x00007EC68BFD5ABF
00007ec68bfd2fbf  vmovaps xmm5, [rsp+0x10]
00007ec68bfd2fc5  movaps xmm1, xmm5
00007ec68bfd2fc8  addpd xmm1, xmm13
00007ec68bfd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007ec68bfd2fd2  ptest xmm2, xmm2
00007ec68bfd2fd7  jnz 0x00007EC68BFD5BFF
00007ec68bfd2fdd  vmovaps xmm13, [rsp+0x80]
00007ec68bfd2fe6  vpermilpd xmm13, xmm13, 0x00
00007ec68bfd2fec  vmovaps xmm2, [rsp+0xE0]
00007ec68bfd2ff5  vmovaps [rsp+0x10], xmm1
00007ec68bfd2ffb  movaps xmm5, xmm2
00007ec68bfd2ffe  mulpd xmm5, xmm13
00007ec68bfd3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007ec68bfd3008  ptest xmm1, xmm1
00007ec68bfd300d  jnz 0x00007EC68BFD5D40
00007ec68bfd3013  vmovaps xmm1, [rsp+0x80]
00007ec68bfd301c  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd3022  movaps xmm13, xmm10
00007ec68bfd3026  mulpd xmm13, xmm1
00007ec68bfd302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007ec68bfd3031  ptest xmm2, xmm2
00007ec68bfd3036  jnz 0x00007EC68BFD5E81
00007ec68bfd303c  vmovaps xmm10, [rsp+0x20]
00007ec68bfd3042  movaps xmm1, xmm15
00007ec68bfd3046  addpd xmm1, xmm10
00007ec68bfd304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007ec68bfd3050  ptest xmm2, xmm2
00007ec68bfd3055  jnz 0x00007EC68BFD5FC4
00007ec68bfd305b  vmovaps xmm10, [rsp+0xC0]
00007ec68bfd3064  movaps xmm15, xmm10
00007ec68bfd3068  addpd xmm15, xmm11
00007ec68bfd306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007ec68bfd3073  ptest xmm2, xmm2
00007ec68bfd3078  jnz 0x00007EC68BFD6106
00007ec68bfd307e  vmovaps xmm11, [rsp+0x80]
00007ec68bfd3087  vpermilpd xmm11, xmm11, 0x00
00007ec68bfd308d  vmovaps xmm2, [rsp+0xD0]
00007ec68bfd3096  vmovaps [rsp+0x20], xmm1
00007ec68bfd309c  movaps xmm10, xmm2
00007ec68bfd30a0  mulpd xmm10, xmm11
00007ec68bfd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007ec68bfd30ab  ptest xmm1, xmm1
00007ec68bfd30b0  jnz 0x00007EC68BFD624A
00007ec68bfd30b6  vmovaps xmm1, [rsp+0x80]
00007ec68bfd30bf  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd30c5  vmovaps xmm2, [rsp+0xA0]
00007ec68bfd30ce  vmovaps [rsp+0x80], xmm15
00007ec68bfd30d7  movaps xmm11, xmm2
00007ec68bfd30db  mulpd xmm11, xmm1
00007ec68bfd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007ec68bfd30e6  ptest xmm15, xmm15
00007ec68bfd30ec  jnz 0x00007EC68BFD638D
00007ec68bfd30f2  movaps xmm1, xmm14
00007ec68bfd30f6  addpd xmm1, xmm6
00007ec68bfd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007ec68bfd30ff  ptest xmm15, xmm15
00007ec68bfd3105  jnz 0x00007EC68BFD64CF
00007ec68bfd310b  vmovaps xmm14, [rsp+0x10]
00007ec68bfd3111  movaps xmm15, xmm14
00007ec68bfd3115  addpd xmm15, xmm5
00007ec68bfd311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007ec68bfd3120  ptest xmm6, xmm6
00007ec68bfd3125  jnz 0x00007EC68BFD6610
00007ec68bfd312b  vmovaps xmm14, [rsp+0x90]
00007ec68bfd3134  vpermilpd xmm14, xmm14, 0x00
00007ec68bfd313a  movaps xmm6, xmm9
00007ec68bfd313e  mulpd xmm6, xmm14
00007ec68bfd3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007ec68bfd3148  ptest xmm5, xmm5
00007ec68bfd314d  jnz 0x00007EC68BFD6753
00007ec68bfd3153  vmovaps xmm9, [rsp+0x80]
00007ec68bfd315c  movaps xmm14, xmm9
00007ec68bfd3160  addpd xmm14, xmm13
00007ec68bfd3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007ec68bfd316b  ptest xmm5, xmm5
00007ec68bfd3170  jnz 0x00007EC68BFD6895
00007ec68bfd3176  vmovaps xmm9, [rsp+0x20]
00007ec68bfd317c  movaps xmm13, xmm9
00007ec68bfd3180  addpd xmm13, xmm10
00007ec68bfd3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007ec68bfd318b  ptest xmm5, xmm5
00007ec68bfd3190  jnz 0x00007EC68BFD69D9
00007ec68bfd3196  vmovaps [rsp+0x10], xmm12
00007ec68bfd319c  vmovaps xmm10, [rsp+0x10]
00007ec68bfd31a2  por xmm12, xmm10
00007ec68bfd31a7  movaps [r15+0x250], xmm12
00007ec68bfd31af  vmovaps [rsp+0x10], xmm7
00007ec68bfd31b5  vmovaps xmm12, [rsp+0x10]
00007ec68bfd31bb  por xmm7, xmm12
00007ec68bfd31c0  movaps [r15+0x2A0], xmm7
00007ec68bfd31c8  vmovaps [rsp+0x10], xmm3
00007ec68bfd31ce  vmovaps xmm12, [rsp+0x10]
00007ec68bfd31d4  por xmm3, xmm12
00007ec68bfd31d9  movaps [r15+0x1D0], xmm3
00007ec68bfd31e1  lea rax, [r14+0x40]
00007ec68bfd31e5  movups xmm12, [r13+rax*1]
00007ec68bfd31eb  movaps [r15+0x2C0], xmm12
00007ec68bfd31f3  vmovaps xmm10, [rsp+0x90]
00007ec68bfd31fc  vpermilpd xmm10, xmm10, 0x00
00007ec68bfd3202  movaps xmm9, xmm8
00007ec68bfd3206  mulpd xmm9, xmm10
00007ec68bfd320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007ec68bfd3211  ptest xmm5, xmm5
00007ec68bfd3216  jnz 0x00007EC68BFD6B27
00007ec68bfd321c  movaps xmm10, xmm1
00007ec68bfd3220  addpd xmm10, xmm11
00007ec68bfd3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007ec68bfd322b  ptest xmm8, xmm8
00007ec68bfd3231  jnz 0x00007EC68BFD6C6B
00007ec68bfd3237  movaps xmm1, xmm15
00007ec68bfd323b  addpd xmm1, xmm6
00007ec68bfd323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007ec68bfd3244  ptest xmm11, xmm11
00007ec68bfd324a  jnz 0x00007EC68BFD6DAE
00007ec68bfd3250  vmovaps xmm15, [rsp+0x90]
00007ec68bfd3259  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd325f  movaps xmm11, xmm12
00007ec68bfd3263  mulpd xmm11, xmm15
00007ec68bfd3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007ec68bfd326e  ptest xmm8, xmm8
00007ec68bfd3274  jnz 0x00007EC68BFD6EEF
00007ec68bfd327a  vmovaps xmm15, [rsp+0x90]
00007ec68bfd3283  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd3289  vmovaps xmm8, [rsp+0x50]
00007ec68bfd328f  movaps xmm12, xmm8
00007ec68bfd3293  mulpd xmm12, xmm15
00007ec68bfd3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007ec68bfd329e  ptest xmm6, xmm6
00007ec68bfd32a3  jnz 0x00007EC68BFD7033
00007ec68bfd32a9  vmovaps xmm15, [rsp+0x30]
00007ec68bfd32af  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd32b5  movaps xmm8, xmm7
00007ec68bfd32b9  mulpd xmm8, xmm15
00007ec68bfd32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007ec68bfd32c4  ptest xmm6, xmm6
00007ec68bfd32c9  jnz 0x00007EC68BFD7177
00007ec68bfd32cf  movaps xmm15, xmm14
00007ec68bfd32d3  addpd xmm15, xmm9
00007ec68bfd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007ec68bfd32de  ptest xmm7, xmm7
00007ec68bfd32e3  jnz 0x00007EC68BFD72BA
00007ec68bfd32e9  vmovaps xmm14, [rsp+0x30]
00007ec68bfd32ef  vpermilpd xmm14, xmm14, 0x00
00007ec68bfd32f5  vmovaps xmm7, [rsp+0xF0]
00007ec68bfd32fe  movaps xmm9, xmm7
00007ec68bfd3302  mulpd xmm9, xmm14
00007ec68bfd3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007ec68bfd330d  ptest xmm6, xmm6
00007ec68bfd3312  jnz 0x00007EC68BFD73FE
00007ec68bfd3318  movaps xmm14, xmm13
00007ec68bfd331c  addpd xmm14, xmm11
00007ec68bfd3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007ec68bfd3327  ptest xmm7, xmm7
00007ec68bfd332c  jnz 0x00007EC68BFD7541
00007ec68bfd3332  vmovaps xmm13, [rsp+0x30]
00007ec68bfd3338  vpermilpd xmm13, xmm13, 0x00
00007ec68bfd333e  vmovaps xmm7, [rsp+0x60]
00007ec68bfd3344  movaps xmm11, xmm7
00007ec68bfd3348  mulpd xmm11, xmm13
00007ec68bfd334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007ec68bfd3353  ptest xmm6, xmm6
00007ec68bfd3358  jnz 0x00007EC68BFD7685
00007ec68bfd335e  movaps xmm13, xmm10
00007ec68bfd3362  addpd xmm13, xmm12
00007ec68bfd3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007ec68bfd336d  ptest xmm7, xmm7
00007ec68bfd3372  jnz 0x00007EC68BFD77C8
00007ec68bfd3378  vmovaps xmm12, [rsp+0x30]
00007ec68bfd337e  vpermilpd xmm12, xmm12, 0x00
00007ec68bfd3384  vmovaps xmm7, [rsp+0x70]
00007ec68bfd338a  movaps xmm10, xmm7
00007ec68bfd338e  mulpd xmm10, xmm12
00007ec68bfd3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007ec68bfd3399  ptest xmm6, xmm6
00007ec68bfd339e  jnz 0x00007EC68BFD790C
00007ec68bfd33a4  movaps xmm12, xmm1
00007ec68bfd33a8  addpd xmm12, xmm8
00007ec68bfd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007ec68bfd33b3  ptest xmm7, xmm7
00007ec68bfd33b8  jnz 0x00007EC68BFD7A4F
00007ec68bfd33be  lea rax, [r14+0x70]
00007ec68bfd33c2  movups xmm1, [r13+rax*1]
00007ec68bfd33c8  movaps [r15+0x240], xmm1
00007ec68bfd33d0  movaps xmm8, xmm15
00007ec68bfd33d4  addpd xmm8, xmm9
00007ec68bfd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007ec68bfd33df  ptest xmm7, xmm7
00007ec68bfd33e4  jnz 0x00007EC68BFD7B9C
00007ec68bfd33ea  movaps [r15+0x170], xmm8
00007ec68bfd33f2  vmovaps xmm15, [rsp+0x40]
00007ec68bfd33f8  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd33fe  movaps xmm9, xmm1
00007ec68bfd3402  mulpd xmm9, xmm15
00007ec68bfd3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007ec68bfd340d  ptest xmm7, xmm7
00007ec68bfd3412  jnz 0x00007EC68BFD7CE0
00007ec68bfd3418  vmovaps xmm1, [rsp+0x40]
00007ec68bfd341e  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd3424  movaps xmm15, xmm4
00007ec68bfd3428  mulpd xmm15, xmm1
00007ec68bfd342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007ec68bfd3433  ptest xmm7, xmm7
00007ec68bfd3438  jnz 0x00007EC68BFD7E23
00007ec68bfd343e  movaps [r15+0x180], xmm15
00007ec68bfd3446  movaps xmm1, xmm14
00007ec68bfd344a  addpd xmm1, xmm11
00007ec68bfd344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007ec68bfd3454  ptest xmm7, xmm7
00007ec68bfd3459  jnz 0x00007EC68BFD7F65
00007ec68bfd345f  movaps [r15+0x210], xmm1
00007ec68bfd3467  movups xmm14, [r13+r14*1]
00007ec68bfd346d  lea rax, [r14+0x10]
00007ec68bfd3471  movups xmm11, [r13+rax*1]
00007ec68bfd3477  movaps [r15+0x230], xmm11
00007ec68bfd347f  movaps xmm7, xmm13
00007ec68bfd3483  addpd xmm7, xmm10
00007ec68bfd3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007ec68bfd348d  ptest xmm6, xmm6
00007ec68bfd3492  jnz 0x00007EC68BFD80BB
00007ec68bfd3498  movaps [r15+0x130], xmm7
00007ec68bfd34a0  vmovaps xmm13, [rsp+0x40]
00007ec68bfd34a6  vpermilpd xmm13, xmm13, 0x00
00007ec68bfd34ac  movaps xmm10, xmm11
00007ec68bfd34b0  mulpd xmm10, xmm13
00007ec68bfd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007ec68bfd34bb  ptest xmm6, xmm6
00007ec68bfd34c0  jnz 0x00007EC68BFD81FD
00007ec68bfd34c6  movaps [r15+0x220], xmm10
00007ec68bfd34ce  vmovaps xmm13, [rsp+0x40]
00007ec68bfd34d4  vpermilpd xmm13, xmm13, 0x00
00007ec68bfd34da  movaps xmm11, xmm14
00007ec68bfd34de  mulpd xmm11, xmm13
00007ec68bfd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007ec68bfd34e9  ptest xmm6, xmm6
00007ec68bfd34ee  jnz 0x00007EC68BFD8341
00007ec68bfd34f4  movaps xmm14, xmm12
00007ec68bfd34f8  addpd xmm14, xmm9
00007ec68bfd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007ec68bfd3503  ptest xmm13, xmm13
00007ec68bfd3509  jnz 0x00007EC68BFD8485
00007ec68bfd350f  movaps [r15+0x140], xmm14
00007ec68bfd3517  movaps xmm13, xmm8
00007ec68bfd351b  addpd xmm13, xmm15
00007ec68bfd3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007ec68bfd3526  ptest xmm12, xmm12
00007ec68bfd352c  jnz 0x00007EC68BFD85C9
00007ec68bfd3532  movaps [r15+0x150], xmm13
00007ec68bfd353a  movaps xmm15, xmm1
00007ec68bfd353e  addpd xmm15, xmm10
00007ec68bfd3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007ec68bfd3549  ptest xmm12, xmm12
00007ec68bfd354f  jnz 0x00007EC68BFD870D
00007ec68bfd3555  movaps [r15+0x160], xmm15
00007ec68bfd355d  movaps xmm1, xmm7
00007ec68bfd3560  addpd xmm1, xmm11
00007ec68bfd3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007ec68bfd356a  ptest xmm12, xmm12
00007ec68bfd3570  jnz 0x00007EC68BFD8850
00007ec68bfd3576  movaps [r15+0x120], xmm1
00007ec68bfd357e  mov eax, 0x432200
00007ec68bfd3583  movups [r13+rax*1], xmm14
00007ec68bfd3589  mov eax, 0x432210
00007ec68bfd358e  movups [r13+rax*1], xmm13
00007ec68bfd3594  mov eax, 0x432220
00007ec68bfd3599  movups [r13+rax*1], xmm15
00007ec68bfd359f  mov eax, 0x432230
00007ec68bfd35a4  movups [r13+rax*1], xmm1
00007ec68bfd35aa  mov eax, [r15+0x108]
00007ec68bfd35b1  sahf
00007ec68bfd35b2  jnz 0x00007EC68BFD35E4
00007ec68bfd35b4  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd35bc  jz 0x00007EC68BFDEAE0
00007ec68bfd35c2  nop [rax+rax*1], ax
00007ec68bfd35cb  nop [rax+rax*1], eax
00007ec68bfd35d3  mov eax, 0x4106D0
00007ec68bfd35d8  mov [r15+0x100], rax
00007ec68bfd35df  jmp 0x00007EC68BDFE110
00007ec68bfd35e4  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd35ec  jz 0x00007EC68BFD89C0
00007ec68bfd35f2  nop [rax+rax*1], ax
00007ec68bfd35fb  nop [rax+rax*1], eax
00007ec68bfd3603  mov eax, 0x410504
00007ec68bfd3608  mov [r15+0x100], rax
00007ec68bfd360f  jmp 0x00007EC68BDFE110
00007ec68bfd3614  int3
00007ec68bfd3615  call 0x00007EC68BED64F0
00007ec68bfd361a  jmp 0x00007EC68BFD2311
00007ec68bfd361f  call 0x00007EC68BEE5820
00007ec68bfd3624  jmp 0x00007EC68BFD231E
00007ec68bfd3629  call 0x00007EC68BEE3320
00007ec68bfd362e  jmp 0x00007EC68BFD2332
00007ec68bfd3633  call 0x00007EC68BEE20A0
00007ec68bfd3638  jmp 0x00007EC68BFD233C
00007ec68bfd363d  call 0x00007EC68BE09D70
00007ec68bfd3642  jmp 0x00007EC68BFD234A
00007ec68bfd3647  call 0x00007EC68BEDFBC0
00007ec68bfd364c  jmp 0x00007EC68BFD2354
00007ec68bfd3651  call 0x00007EC68BEC4740
00007ec68bfd3656  jmp 0x00007EC68BFD2368
00007ec68bfd365b  call 0x00007EC68BEB5400
00007ec68bfd3660  jmp 0x00007EC68BFD2375
00007ec68bfd3665  call 0x00007EC68BEB52F0
00007ec68bfd366a  jmp 0x00007EC68BFD2382
00007ec68bfd366f  call 0x00007EC68BEC4620
00007ec68bfd3674  jmp 0x00007EC68BFD238F
00007ec68bfd3679  call 0x00007EC68BEBD750
00007ec68bfd367e  jmp 0x00007EC68BFD239C
00007ec68bfd3683  call 0x00007EC68BEBC4E0
00007ec68bfd3688  jmp 0x00007EC68BFD23A9
00007ec68bfd368d  call 0x00007EC68BEBB270
00007ec68bfd3692  jmp 0x00007EC68BFD23B6
00007ec68bfd3697  call 0x00007EC68BEBA000
00007ec68bfd369c  jmp 0x00007EC68BFD23C3
00007ec68bfd36a1  call 0x00007EC68BEC4740
00007ec68bfd36a6  jmp 0x00007EC68BFD23D0
00007ec68bfd36ab  call 0x00007EC68BEB5400
00007ec68bfd36b0  jmp 0x00007EC68BFD23DD
00007ec68bfd36b5  call 0x00007EC68BEB52F0
00007ec68bfd36ba  jmp 0x00007EC68BFD23EA
00007ec68bfd36bf  call 0x00007EC68BEC4620
00007ec68bfd36c4  jmp 0x00007EC68BFD23F7
00007ec68bfd36c9  call 0x00007EC68BEB8D90
00007ec68bfd36ce  jmp 0x00007EC68BFD2404
00007ec68bfd36d3  call 0x00007EC68BEB8A20
00007ec68bfd36d8  jmp 0x00007EC68BFD2411
00007ec68bfd36dd  call 0x00007EC68BEB77B0
00007ec68bfd36e2  jmp 0x00007EC68BFD241B
00007ec68bfd36e7  call 0x00007EC68BEB6550
00007ec68bfd36ec  jmp 0x00007EC68BFD2425
00007ec68bfd36f1  call 0x00007EC68BEB5400
00007ec68bfd36f6  jmp 0x00007EC68BFD2437
00007ec68bfd36fb  call 0x00007EC68BEC0FC0
00007ec68bfd3700  jmp 0x00007EC68BFD2441
00007ec68bfd3705  call 0x00007EC68BEB52F0
00007ec68bfd370a  jmp 0x00007EC68BFD244B
00007ec68bfd370f  call 0x00007EC68BEC0EA0
00007ec68bfd3714  jmp 0x00007EC68BFD2455
00007ec68bfd3719  call 0x00007EC68BEBFD50
00007ec68bfd371e  jmp 0x00007EC68BFD245F
00007ec68bfd3723  call 0x00007EC68BEB8EA0
00007ec68bfd3728  jmp 0x00007EC68BFD2469
00007ec68bfd372d  call 0x00007EC68BEBFC30
00007ec68bfd3732  jmp 0x00007EC68BFD2476
00007ec68bfd3737  call 0x00007EC68BEB8D90
00007ec68bfd373c  jmp 0x00007EC68BFD2483
00007ec68bfd3741  call 0x00007EC68BEB52F0
00007ec68bfd3746  jmp 0x00007EC68BFD2496
00007ec68bfd374b  call 0x00007EC68BEB52F0
00007ec68bfd3750  jmp 0x00007EC68BFD24A9
00007ec68bfd3755  call 0x00007EC68BEC0FC0
00007ec68bfd375a  jmp 0x00007EC68BFD24B6
00007ec68bfd375f  call 0x00007EC68BEC0FC0
00007ec68bfd3764  jmp 0x00007EC68BFD24C9
00007ec68bfd3769  call 0x00007EC68BEC0EA0
00007ec68bfd376e  jmp 0x00007EC68BFD24D6
00007ec68bfd3773  call 0x00007EC68BEB52F0
00007ec68bfd3778  jmp 0x00007EC68BFD24E9
00007ec68bfd377d  call 0x00007EC68BEB52F0
00007ec68bfd3782  jmp 0x00007EC68BFD24FC
00007ec68bfd3787  call 0x00007EC68BEB52F0
00007ec68bfd378c  jmp 0x00007EC68BFD250F
00007ec68bfd3791  call 0x00007EC68BEB52F0
00007ec68bfd3796  jmp 0x00007EC68BFD252A
00007ec68bfd379b  call 0x00007EC68BEB52F0
00007ec68bfd37a0  jmp 0x00007EC68BFD253D
00007ec68bfd37a5  call 0x00007EC68BEB5400
00007ec68bfd37aa  jmp 0x00007EC68BFD257E
00007ec68bfd37af  call 0x00007EC68BEC0FC0
00007ec68bfd37b4  jmp 0x00007EC68BFD258B
00007ec68bfd37b9  call 0x00007EC68BEB52F0
00007ec68bfd37be  jmp 0x00007EC68BFD2598
00007ec68bfd37c3  call 0x00007EC68BEC0EA0
00007ec68bfd37c8  jmp 0x00007EC68BFD25A5
00007ec68bfd37cd  call 0x00007EC68BDFF540
00007ec68bfd37d2  jmp 0x00007EC68BFD25C3
00007ec68bfd37d7  call 0x00007EC68BE08C20
00007ec68bfd37dc  jmp 0x00007EC68BFD25CD
00007ec68bfd37e1  call 0x00007EC68BEE21C0
00007ec68bfd37e6  jmp 0x00007EC68BFD25D3
00007ec68bfd37eb  call 0x00007EC68BDFF540
00007ec68bfd37f0  jmp 0x00007EC68BFD25E3
00007ec68bfd37f5  call 0x00007EC68BEC0370
00007ec68bfd37fa  jmp 0x00007EC68BFD2611
00007ec68bfd37ff  call 0x00007EC68BEBF100
00007ec68bfd3804  jmp 0x00007EC68BFD261A
00007ec68bfd3809  call 0x00007EC68BEC0370
00007ec68bfd380e  jmp 0x00007EC68BFD2674
00007ec68bfd3813  call 0x00007EC68BEBF100
00007ec68bfd3818  jmp 0x00007EC68BFD267D
00007ec68bfd381d  call 0x00007EC68BEC0370
00007ec68bfd3822  jmp 0x00007EC68BFD26C6
00007ec68bfd3827  call 0x00007EC68BEBF100
00007ec68bfd382c  jmp 0x00007EC68BFD26CF
00007ec68bfd3831  call 0x00007EC68BE0B720
00007ec68bfd3836  jmp 0x00007EC68BFD2714
00007ec68bfd383b  call 0x00007EC68BEB47C0
00007ec68bfd3840  jmp 0x00007EC68BFD2727
00007ec68bfd3845  call 0x00007EC68BE08B00
00007ec68bfd384a  jmp 0x00007EC68BFD273E
00007ec68bfd384f  call 0x00007EC68BDFF430
00007ec68bfd3854  jmp 0x00007EC68BFD2751
00007ec68bfd3859  call 0x00007EC68BDFF430
00007ec68bfd385e  jmp 0x00007EC68BFD2764
00007ec68bfd3863  sub rsp, 0x08
00007ec68bfd3867  push rax
00007ec68bfd3868  push rcx
00007ec68bfd3869  push rdx
00007ec68bfd386a  push rdi
00007ec68bfd386b  push rsi
00007ec68bfd386c  push r8
00007ec68bfd386e  push r9
00007ec68bfd3870  push r10
00007ec68bfd3872  push r11
00007ec68bfd3874  sub rsp, 0xF0
00007ec68bfd387b  vmovaps [rsp], xmm0
00007ec68bfd3880  vmovaps [rsp+0x10], xmm2
00007ec68bfd3886  vmovaps [rsp+0x20], xmm3
00007ec68bfd388c  vmovaps [rsp+0x30], xmm4
00007ec68bfd3892  vmovaps [rsp+0x40], xmm5
00007ec68bfd3898  vmovaps [rsp+0x50], xmm6
00007ec68bfd389e  vmovaps [rsp+0x60], xmm7
00007ec68bfd38a4  vmovaps [rsp+0x70], xmm8
00007ec68bfd38aa  vmovaps [rsp+0x80], xmm9
00007ec68bfd38b3  vmovaps [rsp+0x90], xmm10
00007ec68bfd38bc  vmovaps [rsp+0xA0], xmm11
00007ec68bfd38c5  vmovaps [rsp+0xB0], xmm12
00007ec68bfd38ce  vmovaps [rsp+0xC0], xmm13
00007ec68bfd38d7  vmovaps [rsp+0xD0], xmm14
00007ec68bfd38e0  vmovaps [rsp+0xE0], xmm15
00007ec68bfd38e9  sub rsp, 0x30
00007ec68bfd38ed  movaps [rsp], xmm1
00007ec68bfd38f1  movaps [rsp+0x10], xmm12
00007ec68bfd38f7  movaps [rsp+0x20], xmm15
00007ec68bfd38fd  lea rdi, [rsp]
00007ec68bfd3901  mov esi, 0x00
00007ec68bfd3906  mov rax, 0x57D97DADF530
00007ec68bfd3910  call rax
00007ec68bfd3912  movaps xmm1, [rsp]
00007ec68bfd3916  add rsp, 0x30
00007ec68bfd391a  vmovaps xmm0, [rsp]
00007ec68bfd391f  vmovaps xmm2, [rsp+0x10]
00007ec68bfd3925  vmovaps xmm3, [rsp+0x20]
00007ec68bfd392b  vmovaps xmm4, [rsp+0x30]
00007ec68bfd3931  vmovaps xmm5, [rsp+0x40]
00007ec68bfd3937  vmovaps xmm6, [rsp+0x50]
00007ec68bfd393d  vmovaps xmm7, [rsp+0x60]
00007ec68bfd3943  vmovaps xmm8, [rsp+0x70]
00007ec68bfd3949  vmovaps xmm9, [rsp+0x80]
00007ec68bfd3952  vmovaps xmm10, [rsp+0x90]
00007ec68bfd395b  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd3964  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd396d  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd3976  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd397f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd3988  add rsp, 0xF0
00007ec68bfd398f  pop r11
00007ec68bfd3991  pop r10
00007ec68bfd3993  pop r9
00007ec68bfd3995  pop r8
00007ec68bfd3997  pop rsi
00007ec68bfd3998  pop rdi
00007ec68bfd3999  pop rdx
00007ec68bfd399a  pop rcx
00007ec68bfd399b  pop rax
00007ec68bfd399c  add rsp, 0x08
00007ec68bfd39a0  jmp 0x00007EC68BFD27B2
00007ec68bfd39a5  sub rsp, 0x08
00007ec68bfd39a9  push rax
00007ec68bfd39aa  push rcx
00007ec68bfd39ab  push rdx
00007ec68bfd39ac  push rdi
00007ec68bfd39ad  push rsi
00007ec68bfd39ae  push r8
00007ec68bfd39b0  push r9
00007ec68bfd39b2  push r10
00007ec68bfd39b4  push r11
00007ec68bfd39b6  sub rsp, 0xF0
00007ec68bfd39bd  vmovaps [rsp], xmm0
00007ec68bfd39c2  vmovaps [rsp+0x10], xmm1
00007ec68bfd39c8  vmovaps [rsp+0x20], xmm2
00007ec68bfd39ce  vmovaps [rsp+0x30], xmm3
00007ec68bfd39d4  vmovaps [rsp+0x40], xmm4
00007ec68bfd39da  vmovaps [rsp+0x50], xmm5
00007ec68bfd39e0  vmovaps [rsp+0x60], xmm6
00007ec68bfd39e6  vmovaps [rsp+0x70], xmm7
00007ec68bfd39ec  vmovaps [rsp+0x80], xmm8
00007ec68bfd39f5  vmovaps [rsp+0x90], xmm9
00007ec68bfd39fe  vmovaps [rsp+0xA0], xmm10
00007ec68bfd3a07  vmovaps [rsp+0xB0], xmm11
00007ec68bfd3a10  vmovaps [rsp+0xC0], xmm12
00007ec68bfd3a19  vmovaps [rsp+0xD0], xmm13
00007ec68bfd3a22  vmovaps [rsp+0xE0], xmm15
00007ec68bfd3a2b  sub rsp, 0x30
00007ec68bfd3a2f  movaps [rsp], xmm14
00007ec68bfd3a34  movaps [rsp+0x10], xmm1
00007ec68bfd3a39  movaps [rsp+0x20], xmm15
00007ec68bfd3a3f  lea rdi, [rsp]
00007ec68bfd3a43  mov esi, 0x00
00007ec68bfd3a48  mov rax, 0x57D97DADF530
00007ec68bfd3a52  call rax
00007ec68bfd3a54  movaps xmm14, [rsp]
00007ec68bfd3a59  add rsp, 0x30
00007ec68bfd3a5d  vmovaps xmm0, [rsp]
00007ec68bfd3a62  vmovaps xmm1, [rsp+0x10]
00007ec68bfd3a68  vmovaps xmm2, [rsp+0x20]
00007ec68bfd3a6e  vmovaps xmm3, [rsp+0x30]
00007ec68bfd3a74  vmovaps xmm4, [rsp+0x40]
00007ec68bfd3a7a  vmovaps xmm5, [rsp+0x50]
00007ec68bfd3a80  vmovaps xmm6, [rsp+0x60]
00007ec68bfd3a86  vmovaps xmm7, [rsp+0x70]
00007ec68bfd3a8c  vmovaps xmm8, [rsp+0x80]
00007ec68bfd3a95  vmovaps xmm9, [rsp+0x90]
00007ec68bfd3a9e  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd3aa7  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd3ab0  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd3ab9  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd3ac2  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd3acb  add rsp, 0xF0
00007ec68bfd3ad2  pop r11
00007ec68bfd3ad4  pop r10
00007ec68bfd3ad6  pop r9
00007ec68bfd3ad8  pop r8
00007ec68bfd3ada  pop rsi
00007ec68bfd3adb  pop rdi
00007ec68bfd3adc  pop rdx
00007ec68bfd3add  pop rcx
00007ec68bfd3ade  pop rax
00007ec68bfd3adf  add rsp, 0x08
00007ec68bfd3ae3  jmp 0x00007EC68BFD2800
00007ec68bfd3ae8  sub rsp, 0x08
00007ec68bfd3aec  push rax
00007ec68bfd3aed  push rcx
00007ec68bfd3aee  push rdx
00007ec68bfd3aef  push rdi
00007ec68bfd3af0  push rsi
00007ec68bfd3af1  push r8
00007ec68bfd3af3  push r9
00007ec68bfd3af5  push r10
00007ec68bfd3af7  push r11
00007ec68bfd3af9  sub rsp, 0xF0
00007ec68bfd3b00  vmovaps [rsp], xmm0
00007ec68bfd3b05  vmovaps [rsp+0x10], xmm1
00007ec68bfd3b0b  vmovaps [rsp+0x20], xmm2
00007ec68bfd3b11  vmovaps [rsp+0x30], xmm3
00007ec68bfd3b17  vmovaps [rsp+0x40], xmm4
00007ec68bfd3b1d  vmovaps [rsp+0x50], xmm5
00007ec68bfd3b23  vmovaps [rsp+0x60], xmm6
00007ec68bfd3b29  vmovaps [rsp+0x70], xmm7
00007ec68bfd3b2f  vmovaps [rsp+0x80], xmm8
00007ec68bfd3b38  vmovaps [rsp+0x90], xmm9
00007ec68bfd3b41  vmovaps [rsp+0xA0], xmm10
00007ec68bfd3b4a  vmovaps [rsp+0xB0], xmm11
00007ec68bfd3b53  vmovaps [rsp+0xC0], xmm12
00007ec68bfd3b5c  vmovaps [rsp+0xD0], xmm13
00007ec68bfd3b65  vmovaps [rsp+0xE0], xmm14
00007ec68bfd3b6e  sub rsp, 0x30
00007ec68bfd3b72  movaps [rsp], xmm15
00007ec68bfd3b77  movaps [rsp+0x10], xmm12
00007ec68bfd3b7d  movaps [rsp+0x20], xmm13
00007ec68bfd3b83  lea rdi, [rsp]
00007ec68bfd3b87  mov esi, 0x00
00007ec68bfd3b8c  mov rax, 0x57D97DADF530
00007ec68bfd3b96  call rax
00007ec68bfd3b98  movaps xmm15, [rsp]
00007ec68bfd3b9d  add rsp, 0x30
00007ec68bfd3ba1  vmovaps xmm0, [rsp]
00007ec68bfd3ba6  vmovaps xmm1, [rsp+0x10]
00007ec68bfd3bac  vmovaps xmm2, [rsp+0x20]
00007ec68bfd3bb2  vmovaps xmm3, [rsp+0x30]
00007ec68bfd3bb8  vmovaps xmm4, [rsp+0x40]
00007ec68bfd3bbe  vmovaps xmm5, [rsp+0x50]
00007ec68bfd3bc4  vmovaps xmm6, [rsp+0x60]
00007ec68bfd3bca  vmovaps xmm7, [rsp+0x70]
00007ec68bfd3bd0  vmovaps xmm8, [rsp+0x80]
00007ec68bfd3bd9  vmovaps xmm9, [rsp+0x90]
00007ec68bfd3be2  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd3beb  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd3bf4  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd3bfd  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd3c06  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd3c0f  add rsp, 0xF0
00007ec68bfd3c16  pop r11
00007ec68bfd3c18  pop r10
00007ec68bfd3c1a  pop r9
00007ec68bfd3c1c  pop r8
00007ec68bfd3c1e  pop rsi
00007ec68bfd3c1f  pop rdi
00007ec68bfd3c20  pop rdx
00007ec68bfd3c21  pop rcx
00007ec68bfd3c22  pop rax
00007ec68bfd3c23  add rsp, 0x08
00007ec68bfd3c27  jmp 0x00007EC68BFD2835
00007ec68bfd3c2c  sub rsp, 0x08
00007ec68bfd3c30  push rax
00007ec68bfd3c31  push rcx
00007ec68bfd3c32  push rdx
00007ec68bfd3c33  push rdi
00007ec68bfd3c34  push rsi
00007ec68bfd3c35  push r8
00007ec68bfd3c37  push r9
00007ec68bfd3c39  push r10
00007ec68bfd3c3b  push r11
00007ec68bfd3c3d  sub rsp, 0xF0
00007ec68bfd3c44  vmovaps [rsp], xmm0
00007ec68bfd3c49  vmovaps [rsp+0x10], xmm2
00007ec68bfd3c4f  vmovaps [rsp+0x20], xmm3
00007ec68bfd3c55  vmovaps [rsp+0x30], xmm4
00007ec68bfd3c5b  vmovaps [rsp+0x40], xmm5
00007ec68bfd3c61  vmovaps [rsp+0x50], xmm6
00007ec68bfd3c67  vmovaps [rsp+0x60], xmm7
00007ec68bfd3c6d  vmovaps [rsp+0x70], xmm8
00007ec68bfd3c73  vmovaps [rsp+0x80], xmm9
00007ec68bfd3c7c  vmovaps [rsp+0x90], xmm10
00007ec68bfd3c85  vmovaps [rsp+0xA0], xmm11
00007ec68bfd3c8e  vmovaps [rsp+0xB0], xmm12
00007ec68bfd3c97  vmovaps [rsp+0xC0], xmm13
00007ec68bfd3ca0  vmovaps [rsp+0xD0], xmm14
00007ec68bfd3ca9  vmovaps [rsp+0xE0], xmm15
00007ec68bfd3cb2  sub rsp, 0x30
00007ec68bfd3cb6  movaps [rsp], xmm1
00007ec68bfd3cba  movaps [rsp+0x10], xmm12
00007ec68bfd3cc0  movaps [rsp+0x20], xmm10
00007ec68bfd3cc6  lea rdi, [rsp]
00007ec68bfd3cca  mov esi, 0x00
00007ec68bfd3ccf  mov rax, 0x57D97DADF530
00007ec68bfd3cd9  call rax
00007ec68bfd3cdb  movaps xmm1, [rsp]
00007ec68bfd3cdf  add rsp, 0x30
00007ec68bfd3ce3  vmovaps xmm0, [rsp]
00007ec68bfd3ce8  vmovaps xmm2, [rsp+0x10]
00007ec68bfd3cee  vmovaps xmm3, [rsp+0x20]
00007ec68bfd3cf4  vmovaps xmm4, [rsp+0x30]
00007ec68bfd3cfa  vmovaps xmm5, [rsp+0x40]
00007ec68bfd3d00  vmovaps xmm6, [rsp+0x50]
00007ec68bfd3d06  vmovaps xmm7, [rsp+0x60]
00007ec68bfd3d0c  vmovaps xmm8, [rsp+0x70]
00007ec68bfd3d12  vmovaps xmm9, [rsp+0x80]
00007ec68bfd3d1b  vmovaps xmm10, [rsp+0x90]
00007ec68bfd3d24  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd3d2d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd3d36  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd3d3f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd3d48  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd3d51  add rsp, 0xF0
00007ec68bfd3d58  pop r11
00007ec68bfd3d5a  pop r10
00007ec68bfd3d5c  pop r9
00007ec68bfd3d5e  pop r8
00007ec68bfd3d60  pop rsi
00007ec68bfd3d61  pop rdi
00007ec68bfd3d62  pop rdx
00007ec68bfd3d63  pop rcx
00007ec68bfd3d64  pop rax
00007ec68bfd3d65  add rsp, 0x08
00007ec68bfd3d69  jmp 0x00007EC68BFD284F
00007ec68bfd3d6e  sub rsp, 0x08
00007ec68bfd3d72  push rax
00007ec68bfd3d73  push rcx
00007ec68bfd3d74  push rdx
00007ec68bfd3d75  push rdi
00007ec68bfd3d76  push rsi
00007ec68bfd3d77  push r8
00007ec68bfd3d79  push r9
00007ec68bfd3d7b  push r10
00007ec68bfd3d7d  push r11
00007ec68bfd3d7f  sub rsp, 0xF0
00007ec68bfd3d86  vmovaps [rsp], xmm0
00007ec68bfd3d8b  vmovaps [rsp+0x10], xmm1
00007ec68bfd3d91  vmovaps [rsp+0x20], xmm2
00007ec68bfd3d97  vmovaps [rsp+0x30], xmm3
00007ec68bfd3d9d  vmovaps [rsp+0x40], xmm4
00007ec68bfd3da3  vmovaps [rsp+0x50], xmm5
00007ec68bfd3da9  vmovaps [rsp+0x60], xmm6
00007ec68bfd3daf  vmovaps [rsp+0x70], xmm7
00007ec68bfd3db5  vmovaps [rsp+0x80], xmm8
00007ec68bfd3dbe  vmovaps [rsp+0x90], xmm9
00007ec68bfd3dc7  vmovaps [rsp+0xA0], xmm10
00007ec68bfd3dd0  vmovaps [rsp+0xB0], xmm11
00007ec68bfd3dd9  vmovaps [rsp+0xC0], xmm12
00007ec68bfd3de2  vmovaps [rsp+0xD0], xmm14
00007ec68bfd3deb  vmovaps [rsp+0xE0], xmm15
00007ec68bfd3df4  sub rsp, 0x30
00007ec68bfd3df8  movaps [rsp], xmm13
00007ec68bfd3dfd  movaps [rsp+0x10], xmm12
00007ec68bfd3e03  movaps [rsp+0x20], xmm2
00007ec68bfd3e08  lea rdi, [rsp]
00007ec68bfd3e0c  mov esi, 0x00
00007ec68bfd3e11  mov rax, 0x57D97DADF530
00007ec68bfd3e1b  call rax
00007ec68bfd3e1d  movaps xmm13, [rsp]
00007ec68bfd3e22  add rsp, 0x30
00007ec68bfd3e26  vmovaps xmm0, [rsp]
00007ec68bfd3e2b  vmovaps xmm1, [rsp+0x10]
00007ec68bfd3e31  vmovaps xmm2, [rsp+0x20]
00007ec68bfd3e37  vmovaps xmm3, [rsp+0x30]
00007ec68bfd3e3d  vmovaps xmm4, [rsp+0x40]
00007ec68bfd3e43  vmovaps xmm5, [rsp+0x50]
00007ec68bfd3e49  vmovaps xmm6, [rsp+0x60]
00007ec68bfd3e4f  vmovaps xmm7, [rsp+0x70]
00007ec68bfd3e55  vmovaps xmm8, [rsp+0x80]
00007ec68bfd3e5e  vmovaps xmm9, [rsp+0x90]
00007ec68bfd3e67  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd3e70  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd3e79  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd3e82  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd3e8b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd3e94  add rsp, 0xF0
00007ec68bfd3e9b  pop r11
00007ec68bfd3e9d  pop r10
00007ec68bfd3e9f  pop r9
00007ec68bfd3ea1  pop r8
00007ec68bfd3ea3  pop rsi
00007ec68bfd3ea4  pop rdi
00007ec68bfd3ea5  pop rdx
00007ec68bfd3ea6  pop rcx
00007ec68bfd3ea7  pop rax
00007ec68bfd3ea8  add rsp, 0x08
00007ec68bfd3eac  jmp 0x00007EC68BFD286A
00007ec68bfd3eb1  sub rsp, 0x08
00007ec68bfd3eb5  push rax
00007ec68bfd3eb6  push rcx
00007ec68bfd3eb7  push rdx
00007ec68bfd3eb8  push rdi
00007ec68bfd3eb9  push rsi
00007ec68bfd3eba  push r8
00007ec68bfd3ebc  push r9
00007ec68bfd3ebe  push r10
00007ec68bfd3ec0  push r11
00007ec68bfd3ec2  sub rsp, 0xF0
00007ec68bfd3ec9  vmovaps [rsp], xmm0
00007ec68bfd3ece  vmovaps [rsp+0x10], xmm2
00007ec68bfd3ed4  vmovaps [rsp+0x20], xmm3
00007ec68bfd3eda  vmovaps [rsp+0x30], xmm4
00007ec68bfd3ee0  vmovaps [rsp+0x40], xmm5
00007ec68bfd3ee6  vmovaps [rsp+0x50], xmm6
00007ec68bfd3eec  vmovaps [rsp+0x60], xmm7
00007ec68bfd3ef2  vmovaps [rsp+0x70], xmm8
00007ec68bfd3ef8  vmovaps [rsp+0x80], xmm9
00007ec68bfd3f01  vmovaps [rsp+0x90], xmm10
00007ec68bfd3f0a  vmovaps [rsp+0xA0], xmm11
00007ec68bfd3f13  vmovaps [rsp+0xB0], xmm12
00007ec68bfd3f1c  vmovaps [rsp+0xC0], xmm13
00007ec68bfd3f25  vmovaps [rsp+0xD0], xmm14
00007ec68bfd3f2e  vmovaps [rsp+0xE0], xmm15
00007ec68bfd3f37  sub rsp, 0x30
00007ec68bfd3f3b  movaps [rsp], xmm1
00007ec68bfd3f3f  movaps [rsp+0x10], xmm10
00007ec68bfd3f45  movaps [rsp+0x20], xmm2
00007ec68bfd3f4a  lea rdi, [rsp]
00007ec68bfd3f4e  mov esi, 0x00
00007ec68bfd3f53  mov rax, 0x57D97DADF530
00007ec68bfd3f5d  call rax
00007ec68bfd3f5f  movaps xmm1, [rsp]
00007ec68bfd3f63  add rsp, 0x30
00007ec68bfd3f67  vmovaps xmm0, [rsp]
00007ec68bfd3f6c  vmovaps xmm2, [rsp+0x10]
00007ec68bfd3f72  vmovaps xmm3, [rsp+0x20]
00007ec68bfd3f78  vmovaps xmm4, [rsp+0x30]
00007ec68bfd3f7e  vmovaps xmm5, [rsp+0x40]
00007ec68bfd3f84  vmovaps xmm6, [rsp+0x50]
00007ec68bfd3f8a  vmovaps xmm7, [rsp+0x60]
00007ec68bfd3f90  vmovaps xmm8, [rsp+0x70]
00007ec68bfd3f96  vmovaps xmm9, [rsp+0x80]
00007ec68bfd3f9f  vmovaps xmm10, [rsp+0x90]
00007ec68bfd3fa8  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd3fb1  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd3fba  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd3fc3  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd3fcc  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd3fd5  add rsp, 0xF0
00007ec68bfd3fdc  pop r11
00007ec68bfd3fde  pop r10
00007ec68bfd3fe0  pop r9
00007ec68bfd3fe2  pop r8
00007ec68bfd3fe4  pop rsi
00007ec68bfd3fe5  pop rdi
00007ec68bfd3fe6  pop rdx
00007ec68bfd3fe7  pop rcx
00007ec68bfd3fe8  pop rax
00007ec68bfd3fe9  add rsp, 0x08
00007ec68bfd3fed  jmp 0x00007EC68BFD28D2
00007ec68bfd3ff2  sub rsp, 0x08
00007ec68bfd3ff6  push rax
00007ec68bfd3ff7  push rcx
00007ec68bfd3ff8  push rdx
00007ec68bfd3ff9  push rdi
00007ec68bfd3ffa  push rsi
00007ec68bfd3ffb  push r8
00007ec68bfd3ffd  push r9
00007ec68bfd3fff  push r10
00007ec68bfd4001  push r11
00007ec68bfd4003  sub rsp, 0xF0
00007ec68bfd400a  vmovaps [rsp], xmm0
00007ec68bfd400f  vmovaps [rsp+0x10], xmm1
00007ec68bfd4015  vmovaps [rsp+0x20], xmm2
00007ec68bfd401b  vmovaps [rsp+0x30], xmm3
00007ec68bfd4021  vmovaps [rsp+0x40], xmm4
00007ec68bfd4027  vmovaps [rsp+0x50], xmm5
00007ec68bfd402d  vmovaps [rsp+0x60], xmm6
00007ec68bfd4033  vmovaps [rsp+0x70], xmm7
00007ec68bfd4039  vmovaps [rsp+0x80], xmm8
00007ec68bfd4042  vmovaps [rsp+0x90], xmm9
00007ec68bfd404b  vmovaps [rsp+0xA0], xmm10
00007ec68bfd4054  vmovaps [rsp+0xB0], xmm11
00007ec68bfd405d  vmovaps [rsp+0xC0], xmm12
00007ec68bfd4066  vmovaps [rsp+0xD0], xmm13
00007ec68bfd406f  vmovaps [rsp+0xE0], xmm14
00007ec68bfd4078  sub rsp, 0x30
00007ec68bfd407c  movaps [rsp], xmm15
00007ec68bfd4081  movaps [rsp+0x10], xmm10
00007ec68bfd4087  movaps [rsp+0x20], xmm2
00007ec68bfd408c  lea rdi, [rsp]
00007ec68bfd4090  mov esi, 0x00
00007ec68bfd4095  mov rax, 0x57D97DADF530
00007ec68bfd409f  call rax
00007ec68bfd40a1  movaps xmm15, [rsp]
00007ec68bfd40a6  add rsp, 0x30
00007ec68bfd40aa  vmovaps xmm0, [rsp]
00007ec68bfd40af  vmovaps xmm1, [rsp+0x10]
00007ec68bfd40b5  vmovaps xmm2, [rsp+0x20]
00007ec68bfd40bb  vmovaps xmm3, [rsp+0x30]
00007ec68bfd40c1  vmovaps xmm4, [rsp+0x40]
00007ec68bfd40c7  vmovaps xmm5, [rsp+0x50]
00007ec68bfd40cd  vmovaps xmm6, [rsp+0x60]
00007ec68bfd40d3  vmovaps xmm7, [rsp+0x70]
00007ec68bfd40d9  vmovaps xmm8, [rsp+0x80]
00007ec68bfd40e2  vmovaps xmm9, [rsp+0x90]
00007ec68bfd40eb  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd40f4  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd40fd  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd4106  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd410f  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd4118  add rsp, 0xF0
00007ec68bfd411f  pop r11
00007ec68bfd4121  pop r10
00007ec68bfd4123  pop r9
00007ec68bfd4125  pop r8
00007ec68bfd4127  pop rsi
00007ec68bfd4128  pop rdi
00007ec68bfd4129  pop rdx
00007ec68bfd412a  pop rcx
00007ec68bfd412b  pop rax
00007ec68bfd412c  add rsp, 0x08
00007ec68bfd4130  jmp 0x00007EC68BFD2924
00007ec68bfd4135  sub rsp, 0x08
00007ec68bfd4139  push rax
00007ec68bfd413a  push rcx
00007ec68bfd413b  push rdx
00007ec68bfd413c  push rdi
00007ec68bfd413d  push rsi
00007ec68bfd413e  push r8
00007ec68bfd4140  push r9
00007ec68bfd4142  push r10
00007ec68bfd4144  push r11
00007ec68bfd4146  sub rsp, 0xF0
00007ec68bfd414d  vmovaps [rsp], xmm0
00007ec68bfd4152  vmovaps [rsp+0x10], xmm2
00007ec68bfd4158  vmovaps [rsp+0x20], xmm3
00007ec68bfd415e  vmovaps [rsp+0x30], xmm4
00007ec68bfd4164  vmovaps [rsp+0x40], xmm5
00007ec68bfd416a  vmovaps [rsp+0x50], xmm6
00007ec68bfd4170  vmovaps [rsp+0x60], xmm7
00007ec68bfd4176  vmovaps [rsp+0x70], xmm8
00007ec68bfd417c  vmovaps [rsp+0x80], xmm9
00007ec68bfd4185  vmovaps [rsp+0x90], xmm10
00007ec68bfd418e  vmovaps [rsp+0xA0], xmm11
00007ec68bfd4197  vmovaps [rsp+0xB0], xmm12
00007ec68bfd41a0  vmovaps [rsp+0xC0], xmm13
00007ec68bfd41a9  vmovaps [rsp+0xD0], xmm14
00007ec68bfd41b2  vmovaps [rsp+0xE0], xmm15
00007ec68bfd41bb  sub rsp, 0x30
00007ec68bfd41bf  movaps [rsp], xmm1
00007ec68bfd41c3  movaps [rsp+0x10], xmm10
00007ec68bfd41c9  movaps [rsp+0x20], xmm15
00007ec68bfd41cf  lea rdi, [rsp]
00007ec68bfd41d3  mov esi, 0x00
00007ec68bfd41d8  mov rax, 0x57D97DADF530
00007ec68bfd41e2  call rax
00007ec68bfd41e4  movaps xmm1, [rsp]
00007ec68bfd41e8  add rsp, 0x30
00007ec68bfd41ec  vmovaps xmm0, [rsp]
00007ec68bfd41f1  vmovaps xmm2, [rsp+0x10]
00007ec68bfd41f7  vmovaps xmm3, [rsp+0x20]
00007ec68bfd41fd  vmovaps xmm4, [rsp+0x30]
00007ec68bfd4203  vmovaps xmm5, [rsp+0x40]
00007ec68bfd4209  vmovaps xmm6, [rsp+0x50]
00007ec68bfd420f  vmovaps xmm7, [rsp+0x60]
00007ec68bfd4215  vmovaps xmm8, [rsp+0x70]
00007ec68bfd421b  vmovaps xmm9, [rsp+0x80]
00007ec68bfd4224  vmovaps xmm10, [rsp+0x90]
00007ec68bfd422d  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd4236  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd423f  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd4248  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd4251  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd425a  add rsp, 0xF0
00007ec68bfd4261  pop r11
00007ec68bfd4263  pop r10
00007ec68bfd4265  pop r9
00007ec68bfd4267  pop r8
00007ec68bfd4269  pop rsi
00007ec68bfd426a  pop rdi
00007ec68bfd426b  pop rdx
00007ec68bfd426c  pop rcx
00007ec68bfd426d  pop rax
00007ec68bfd426e  add rsp, 0x08
00007ec68bfd4272  jmp 0x00007EC68BFD2962
00007ec68bfd4277  sub rsp, 0x08
00007ec68bfd427b  push rax
00007ec68bfd427c  push rcx
00007ec68bfd427d  push rdx
00007ec68bfd427e  push rdi
00007ec68bfd427f  push rsi
00007ec68bfd4280  push r8
00007ec68bfd4282  push r9
00007ec68bfd4284  push r10
00007ec68bfd4286  push r11
00007ec68bfd4288  sub rsp, 0xF0
00007ec68bfd428f  vmovaps [rsp], xmm0
00007ec68bfd4294  vmovaps [rsp+0x10], xmm1
00007ec68bfd429a  vmovaps [rsp+0x20], xmm2
00007ec68bfd42a0  vmovaps [rsp+0x30], xmm3
00007ec68bfd42a6  vmovaps [rsp+0x40], xmm4
00007ec68bfd42ac  vmovaps [rsp+0x50], xmm5
00007ec68bfd42b2  vmovaps [rsp+0x60], xmm6
00007ec68bfd42b8  vmovaps [rsp+0x70], xmm7
00007ec68bfd42be  vmovaps [rsp+0x80], xmm8
00007ec68bfd42c7  vmovaps [rsp+0x90], xmm9
00007ec68bfd42d0  vmovaps [rsp+0xA0], xmm10
00007ec68bfd42d9  vmovaps [rsp+0xB0], xmm11
00007ec68bfd42e2  vmovaps [rsp+0xC0], xmm12
00007ec68bfd42eb  vmovaps [rsp+0xD0], xmm13
00007ec68bfd42f4  vmovaps [rsp+0xE0], xmm15
00007ec68bfd42fd  sub rsp, 0x30
00007ec68bfd4301  movaps [rsp], xmm14
00007ec68bfd4306  movaps [rsp+0x10], xmm10
00007ec68bfd430c  movaps [rsp+0x20], xmm15
00007ec68bfd4312  lea rdi, [rsp]
00007ec68bfd4316  mov esi, 0x00
00007ec68bfd431b  mov rax, 0x57D97DADF530
00007ec68bfd4325  call rax
00007ec68bfd4327  movaps xmm14, [rsp]
00007ec68bfd432c  add rsp, 0x30
00007ec68bfd4330  vmovaps xmm0, [rsp]
00007ec68bfd4335  vmovaps xmm1, [rsp+0x10]
00007ec68bfd433b  vmovaps xmm2, [rsp+0x20]
00007ec68bfd4341  vmovaps xmm3, [rsp+0x30]
00007ec68bfd4347  vmovaps xmm4, [rsp+0x40]
00007ec68bfd434d  vmovaps xmm5, [rsp+0x50]
00007ec68bfd4353  vmovaps xmm6, [rsp+0x60]
00007ec68bfd4359  vmovaps xmm7, [rsp+0x70]
00007ec68bfd435f  vmovaps xmm8, [rsp+0x80]
00007ec68bfd4368  vmovaps xmm9, [rsp+0x90]
00007ec68bfd4371  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd437a  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd4383  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd438c  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd4395  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd439e  add rsp, 0xF0
00007ec68bfd43a5  pop r11
00007ec68bfd43a7  pop r10
00007ec68bfd43a9  pop r9
00007ec68bfd43ab  pop r8
00007ec68bfd43ad  pop rsi
00007ec68bfd43ae  pop rdi
00007ec68bfd43af  pop rdx
00007ec68bfd43b0  pop rcx
00007ec68bfd43b1  pop rax
00007ec68bfd43b2  add rsp, 0x08
00007ec68bfd43b6  jmp 0x00007EC68BFD298E
00007ec68bfd43bb  call 0x00007EC68BDFF430
00007ec68bfd43c0  jmp 0x00007EC68BFD2A1E
00007ec68bfd43c5  call 0x00007EC68BDFF430
00007ec68bfd43ca  jmp 0x00007EC68BFD2A31
00007ec68bfd43cf  sub rsp, 0x08
00007ec68bfd43d3  push rax
00007ec68bfd43d4  push rcx
00007ec68bfd43d5  push rdx
00007ec68bfd43d6  push rdi
00007ec68bfd43d7  push rsi
00007ec68bfd43d8  push r8
00007ec68bfd43da  push r9
00007ec68bfd43dc  push r10
00007ec68bfd43de  push r11
00007ec68bfd43e0  sub rsp, 0xF0
00007ec68bfd43e7  vmovaps [rsp], xmm0
00007ec68bfd43ec  vmovaps [rsp+0x10], xmm2
00007ec68bfd43f2  vmovaps [rsp+0x20], xmm3
00007ec68bfd43f8  vmovaps [rsp+0x30], xmm4
00007ec68bfd43fe  vmovaps [rsp+0x40], xmm5
00007ec68bfd4404  vmovaps [rsp+0x50], xmm6
00007ec68bfd440a  vmovaps [rsp+0x60], xmm7
00007ec68bfd4410  vmovaps [rsp+0x70], xmm8
00007ec68bfd4416  vmovaps [rsp+0x80], xmm9
00007ec68bfd441f  vmovaps [rsp+0x90], xmm10
00007ec68bfd4428  vmovaps [rsp+0xA0], xmm11
00007ec68bfd4431  vmovaps [rsp+0xB0], xmm12
00007ec68bfd443a  vmovaps [rsp+0xC0], xmm13
00007ec68bfd4443  vmovaps [rsp+0xD0], xmm14
00007ec68bfd444c  vmovaps [rsp+0xE0], xmm15
00007ec68bfd4455  sub rsp, 0x30
00007ec68bfd4459  movaps [rsp], xmm1
00007ec68bfd445d  movaps [rsp+0x10], xmm13
00007ec68bfd4463  movaps [rsp+0x20], xmm2
00007ec68bfd4468  lea rdi, [rsp]
00007ec68bfd446c  mov esi, 0x00
00007ec68bfd4471  mov rax, 0x57D97DADF530
00007ec68bfd447b  call rax
00007ec68bfd447d  movaps xmm1, [rsp]
00007ec68bfd4481  add rsp, 0x30
00007ec68bfd4485  vmovaps xmm0, [rsp]
00007ec68bfd448a  vmovaps xmm2, [rsp+0x10]
00007ec68bfd4490  vmovaps xmm3, [rsp+0x20]
00007ec68bfd4496  vmovaps xmm4, [rsp+0x30]
00007ec68bfd449c  vmovaps xmm5, [rsp+0x40]
00007ec68bfd44a2  vmovaps xmm6, [rsp+0x50]
00007ec68bfd44a8  vmovaps xmm7, [rsp+0x60]
00007ec68bfd44ae  vmovaps xmm8, [rsp+0x70]
00007ec68bfd44b4  vmovaps xmm9, [rsp+0x80]
00007ec68bfd44bd  vmovaps xmm10, [rsp+0x90]
00007ec68bfd44c6  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd44cf  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd44d8  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd44e1  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd44ea  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd44f3  add rsp, 0xF0
00007ec68bfd44fa  pop r11
00007ec68bfd44fc  pop r10
00007ec68bfd44fe  pop r9
00007ec68bfd4500  pop r8
00007ec68bfd4502  pop rsi
00007ec68bfd4503  pop rdi
00007ec68bfd4504  pop rdx
00007ec68bfd4505  pop rcx
00007ec68bfd4506  pop rax
00007ec68bfd4507  add rsp, 0x08
00007ec68bfd450b  jmp 0x00007EC68BFD2A5C
00007ec68bfd4510  call 0x00007EC68BE0E760
00007ec68bfd4515  jmp 0x00007EC68BFD2A69
00007ec68bfd451a  sub rsp, 0x08
00007ec68bfd451e  push rax
00007ec68bfd451f  push rcx
00007ec68bfd4520  push rdx
00007ec68bfd4521  push rdi
00007ec68bfd4522  push rsi
00007ec68bfd4523  push r8
00007ec68bfd4525  push r9
00007ec68bfd4527  push r10
00007ec68bfd4529  push r11
00007ec68bfd452b  sub rsp, 0xF0
00007ec68bfd4532  vmovaps [rsp], xmm0
00007ec68bfd4537  vmovaps [rsp+0x10], xmm1
00007ec68bfd453d  vmovaps [rsp+0x20], xmm2
00007ec68bfd4543  vmovaps [rsp+0x30], xmm3
00007ec68bfd4549  vmovaps [rsp+0x40], xmm4
00007ec68bfd454f  vmovaps [rsp+0x50], xmm5
00007ec68bfd4555  vmovaps [rsp+0x60], xmm6
00007ec68bfd455b  vmovaps [rsp+0x70], xmm7
00007ec68bfd4561  vmovaps [rsp+0x80], xmm8
00007ec68bfd456a  vmovaps [rsp+0x90], xmm9
00007ec68bfd4573  vmovaps [rsp+0xA0], xmm10
00007ec68bfd457c  vmovaps [rsp+0xB0], xmm11
00007ec68bfd4585  vmovaps [rsp+0xC0], xmm12
00007ec68bfd458e  vmovaps [rsp+0xD0], xmm14
00007ec68bfd4597  vmovaps [rsp+0xE0], xmm15
00007ec68bfd45a0  sub rsp, 0x30
00007ec68bfd45a4  movaps [rsp], xmm13
00007ec68bfd45a9  movaps [rsp+0x10], xmm2
00007ec68bfd45ae  movaps [rsp+0x20], xmm1
00007ec68bfd45b3  lea rdi, [rsp]
00007ec68bfd45b7  mov esi, 0x00
00007ec68bfd45bc  mov rax, 0x57D97DADF530
00007ec68bfd45c6  call rax
00007ec68bfd45c8  movaps xmm13, [rsp]
00007ec68bfd45cd  add rsp, 0x30
00007ec68bfd45d1  vmovaps xmm0, [rsp]
00007ec68bfd45d6  vmovaps xmm1, [rsp+0x10]
00007ec68bfd45dc  vmovaps xmm2, [rsp+0x20]
00007ec68bfd45e2  vmovaps xmm3, [rsp+0x30]
00007ec68bfd45e8  vmovaps xmm4, [rsp+0x40]
00007ec68bfd45ee  vmovaps xmm5, [rsp+0x50]
00007ec68bfd45f4  vmovaps xmm6, [rsp+0x60]
00007ec68bfd45fa  vmovaps xmm7, [rsp+0x70]
00007ec68bfd4600  vmovaps xmm8, [rsp+0x80]
00007ec68bfd4609  vmovaps xmm9, [rsp+0x90]
00007ec68bfd4612  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd461b  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd4624  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd462d  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd4636  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd463f  add rsp, 0xF0
00007ec68bfd4646  pop r11
00007ec68bfd4648  pop r10
00007ec68bfd464a  pop r9
00007ec68bfd464c  pop r8
00007ec68bfd464e  pop rsi
00007ec68bfd464f  pop rdi
00007ec68bfd4650  pop rdx
00007ec68bfd4651  pop rcx
00007ec68bfd4652  pop rax
00007ec68bfd4653  add rsp, 0x08
00007ec68bfd4657  jmp 0x00007EC68BFD2AA8
00007ec68bfd465c  sub rsp, 0x08
00007ec68bfd4660  push rax
00007ec68bfd4661  push rcx
00007ec68bfd4662  push rdx
00007ec68bfd4663  push rdi
00007ec68bfd4664  push rsi
00007ec68bfd4665  push r8
00007ec68bfd4667  push r9
00007ec68bfd4669  push r10
00007ec68bfd466b  push r11
00007ec68bfd466d  sub rsp, 0xF0
00007ec68bfd4674  vmovaps [rsp], xmm0
00007ec68bfd4679  vmovaps [rsp+0x10], xmm2
00007ec68bfd467f  vmovaps [rsp+0x20], xmm3
00007ec68bfd4685  vmovaps [rsp+0x30], xmm4
00007ec68bfd468b  vmovaps [rsp+0x40], xmm5
00007ec68bfd4691  vmovaps [rsp+0x50], xmm6
00007ec68bfd4697  vmovaps [rsp+0x60], xmm7
00007ec68bfd469d  vmovaps [rsp+0x70], xmm8
00007ec68bfd46a3  vmovaps [rsp+0x80], xmm9
00007ec68bfd46ac  vmovaps [rsp+0x90], xmm10
00007ec68bfd46b5  vmovaps [rsp+0xA0], xmm11
00007ec68bfd46be  vmovaps [rsp+0xB0], xmm12
00007ec68bfd46c7  vmovaps [rsp+0xC0], xmm13
00007ec68bfd46d0  vmovaps [rsp+0xD0], xmm14
00007ec68bfd46d9  vmovaps [rsp+0xE0], xmm15
00007ec68bfd46e2  sub rsp, 0x30
00007ec68bfd46e6  movaps [rsp], xmm1
00007ec68bfd46ea  movaps [rsp+0x10], xmm14
00007ec68bfd46f0  movaps [rsp+0x20], xmm15
00007ec68bfd46f6  lea rdi, [rsp]
00007ec68bfd46fa  mov esi, 0x00
00007ec68bfd46ff  mov rax, 0x57D97DADF530
00007ec68bfd4709  call rax
00007ec68bfd470b  movaps xmm1, [rsp]
00007ec68bfd470f  add rsp, 0x30
00007ec68bfd4713  vmovaps xmm0, [rsp]
00007ec68bfd4718  vmovaps xmm2, [rsp+0x10]
00007ec68bfd471e  vmovaps xmm3, [rsp+0x20]
00007ec68bfd4724  vmovaps xmm4, [rsp+0x30]
00007ec68bfd472a  vmovaps xmm5, [rsp+0x40]
00007ec68bfd4730  vmovaps xmm6, [rsp+0x50]
00007ec68bfd4736  vmovaps xmm7, [rsp+0x60]
00007ec68bfd473c  vmovaps xmm8, [rsp+0x70]
00007ec68bfd4742  vmovaps xmm9, [rsp+0x80]
00007ec68bfd474b  vmovaps xmm10, [rsp+0x90]
00007ec68bfd4754  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd475d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd4766  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd476f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd4778  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd4781  add rsp, 0xF0
00007ec68bfd4788  pop r11
00007ec68bfd478a  pop r10
00007ec68bfd478c  pop r9
00007ec68bfd478e  pop r8
00007ec68bfd4790  pop rsi
00007ec68bfd4791  pop rdi
00007ec68bfd4792  pop rdx
00007ec68bfd4793  pop rcx
00007ec68bfd4794  pop rax
00007ec68bfd4795  add rsp, 0x08
00007ec68bfd4799  jmp 0x00007EC68BFD2ACA
00007ec68bfd479e  sub rsp, 0x08
00007ec68bfd47a2  push rax
00007ec68bfd47a3  push rcx
00007ec68bfd47a4  push rdx
00007ec68bfd47a5  push rdi
00007ec68bfd47a6  push rsi
00007ec68bfd47a7  push r8
00007ec68bfd47a9  push r9
00007ec68bfd47ab  push r10
00007ec68bfd47ad  push r11
00007ec68bfd47af  sub rsp, 0xF0
00007ec68bfd47b6  vmovaps [rsp], xmm0
00007ec68bfd47bb  vmovaps [rsp+0x10], xmm1
00007ec68bfd47c1  vmovaps [rsp+0x20], xmm2
00007ec68bfd47c7  vmovaps [rsp+0x30], xmm3
00007ec68bfd47cd  vmovaps [rsp+0x40], xmm4
00007ec68bfd47d3  vmovaps [rsp+0x50], xmm5
00007ec68bfd47d9  vmovaps [rsp+0x60], xmm6
00007ec68bfd47df  vmovaps [rsp+0x70], xmm7
00007ec68bfd47e5  vmovaps [rsp+0x80], xmm8
00007ec68bfd47ee  vmovaps [rsp+0x90], xmm9
00007ec68bfd47f7  vmovaps [rsp+0xA0], xmm10
00007ec68bfd4800  vmovaps [rsp+0xB0], xmm11
00007ec68bfd4809  vmovaps [rsp+0xC0], xmm12
00007ec68bfd4812  vmovaps [rsp+0xD0], xmm13
00007ec68bfd481b  vmovaps [rsp+0xE0], xmm15
00007ec68bfd4824  sub rsp, 0x30
00007ec68bfd4828  movaps [rsp], xmm14
00007ec68bfd482d  movaps [rsp+0x10], xmm2
00007ec68bfd4832  movaps [rsp+0x20], xmm15
00007ec68bfd4838  lea rdi, [rsp]
00007ec68bfd483c  mov esi, 0x00
00007ec68bfd4841  mov rax, 0x57D97DADF530
00007ec68bfd484b  call rax
00007ec68bfd484d  movaps xmm14, [rsp]
00007ec68bfd4852  add rsp, 0x30
00007ec68bfd4856  vmovaps xmm0, [rsp]
00007ec68bfd485b  vmovaps xmm1, [rsp+0x10]
00007ec68bfd4861  vmovaps xmm2, [rsp+0x20]
00007ec68bfd4867  vmovaps xmm3, [rsp+0x30]
00007ec68bfd486d  vmovaps xmm4, [rsp+0x40]
00007ec68bfd4873  vmovaps xmm5, [rsp+0x50]
00007ec68bfd4879  vmovaps xmm6, [rsp+0x60]
00007ec68bfd487f  vmovaps xmm7, [rsp+0x70]
00007ec68bfd4885  vmovaps xmm8, [rsp+0x80]
00007ec68bfd488e  vmovaps xmm9, [rsp+0x90]
00007ec68bfd4897  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd48a0  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd48a9  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd48b2  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd48bb  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd48c4  add rsp, 0xF0
00007ec68bfd48cb  pop r11
00007ec68bfd48cd  pop r10
00007ec68bfd48cf  pop r9
00007ec68bfd48d1  pop r8
00007ec68bfd48d3  pop rsi
00007ec68bfd48d4  pop rdi
00007ec68bfd48d5  pop rdx
00007ec68bfd48d6  pop rcx
00007ec68bfd48d7  pop rax
00007ec68bfd48d8  add rsp, 0x08
00007ec68bfd48dc  jmp 0x00007EC68BFD2B05
00007ec68bfd48e1  sub rsp, 0x08
00007ec68bfd48e5  push rax
00007ec68bfd48e6  push rcx
00007ec68bfd48e7  push rdx
00007ec68bfd48e8  push rdi
00007ec68bfd48e9  push rsi
00007ec68bfd48ea  push r8
00007ec68bfd48ec  push r9
00007ec68bfd48ee  push r10
00007ec68bfd48f0  push r11
00007ec68bfd48f2  sub rsp, 0xF0
00007ec68bfd48f9  vmovaps [rsp], xmm0
00007ec68bfd48fe  vmovaps [rsp+0x10], xmm1
00007ec68bfd4904  vmovaps [rsp+0x20], xmm2
00007ec68bfd490a  vmovaps [rsp+0x30], xmm3
00007ec68bfd4910  vmovaps [rsp+0x40], xmm4
00007ec68bfd4916  vmovaps [rsp+0x50], xmm5
00007ec68bfd491c  vmovaps [rsp+0x60], xmm6
00007ec68bfd4922  vmovaps [rsp+0x70], xmm7
00007ec68bfd4928  vmovaps [rsp+0x80], xmm8
00007ec68bfd4931  vmovaps [rsp+0x90], xmm9
00007ec68bfd493a  vmovaps [rsp+0xA0], xmm10
00007ec68bfd4943  vmovaps [rsp+0xB0], xmm11
00007ec68bfd494c  vmovaps [rsp+0xC0], xmm12
00007ec68bfd4955  vmovaps [rsp+0xD0], xmm13
00007ec68bfd495e  vmovaps [rsp+0xE0], xmm14
00007ec68bfd4967  sub rsp, 0x30
00007ec68bfd496b  movaps [rsp], xmm15
00007ec68bfd4970  movaps [rsp+0x10], xmm2
00007ec68bfd4975  movaps [rsp+0x20], xmm1
00007ec68bfd497a  lea rdi, [rsp]
00007ec68bfd497e  mov esi, 0x00
00007ec68bfd4983  mov rax, 0x57D97DADF530
00007ec68bfd498d  call rax
00007ec68bfd498f  movaps xmm15, [rsp]
00007ec68bfd4994  add rsp, 0x30
00007ec68bfd4998  vmovaps xmm0, [rsp]
00007ec68bfd499d  vmovaps xmm1, [rsp+0x10]
00007ec68bfd49a3  vmovaps xmm2, [rsp+0x20]
00007ec68bfd49a9  vmovaps xmm3, [rsp+0x30]
00007ec68bfd49af  vmovaps xmm4, [rsp+0x40]
00007ec68bfd49b5  vmovaps xmm5, [rsp+0x50]
00007ec68bfd49bb  vmovaps xmm6, [rsp+0x60]
00007ec68bfd49c1  vmovaps xmm7, [rsp+0x70]
00007ec68bfd49c7  vmovaps xmm8, [rsp+0x80]
00007ec68bfd49d0  vmovaps xmm9, [rsp+0x90]
00007ec68bfd49d9  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd49e2  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd49eb  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd49f4  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd49fd  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd4a06  add rsp, 0xF0
00007ec68bfd4a0d  pop r11
00007ec68bfd4a0f  pop r10
00007ec68bfd4a11  pop r9
00007ec68bfd4a13  pop r8
00007ec68bfd4a15  pop rsi
00007ec68bfd4a16  pop rdi
00007ec68bfd4a17  pop rdx
00007ec68bfd4a18  pop rcx
00007ec68bfd4a19  pop rax
00007ec68bfd4a1a  add rsp, 0x08
00007ec68bfd4a1e  jmp 0x00007EC68BFD2B41
00007ec68bfd4a23  call 0x00007EC68BDFF430
00007ec68bfd4a28  jmp 0x00007EC68BFD2B4E
00007ec68bfd4a2d  sub rsp, 0x08
00007ec68bfd4a31  push rax
00007ec68bfd4a32  push rcx
00007ec68bfd4a33  push rdx
00007ec68bfd4a34  push rdi
00007ec68bfd4a35  push rsi
00007ec68bfd4a36  push r8
00007ec68bfd4a38  push r9
00007ec68bfd4a3a  push r10
00007ec68bfd4a3c  push r11
00007ec68bfd4a3e  sub rsp, 0xF0
00007ec68bfd4a45  vmovaps [rsp], xmm0
00007ec68bfd4a4a  vmovaps [rsp+0x10], xmm1
00007ec68bfd4a50  vmovaps [rsp+0x20], xmm3
00007ec68bfd4a56  vmovaps [rsp+0x30], xmm4
00007ec68bfd4a5c  vmovaps [rsp+0x40], xmm5
00007ec68bfd4a62  vmovaps [rsp+0x50], xmm6
00007ec68bfd4a68  vmovaps [rsp+0x60], xmm7
00007ec68bfd4a6e  vmovaps [rsp+0x70], xmm8
00007ec68bfd4a74  vmovaps [rsp+0x80], xmm9
00007ec68bfd4a7d  vmovaps [rsp+0x90], xmm10
00007ec68bfd4a86  vmovaps [rsp+0xA0], xmm11
00007ec68bfd4a8f  vmovaps [rsp+0xB0], xmm12
00007ec68bfd4a98  vmovaps [rsp+0xC0], xmm13
00007ec68bfd4aa1  vmovaps [rsp+0xD0], xmm14
00007ec68bfd4aaa  vmovaps [rsp+0xE0], xmm15
00007ec68bfd4ab3  sub rsp, 0x30
00007ec68bfd4ab7  movaps [rsp], xmm2
00007ec68bfd4abb  movaps [rsp+0x10], xmm1
00007ec68bfd4ac0  movaps [rsp+0x20], xmm14
00007ec68bfd4ac6  lea rdi, [rsp]
00007ec68bfd4aca  mov esi, 0x00
00007ec68bfd4acf  mov rax, 0x57D97DADF530
00007ec68bfd4ad9  call rax
00007ec68bfd4adb  movaps xmm2, [rsp]
00007ec68bfd4adf  add rsp, 0x30
00007ec68bfd4ae3  vmovaps xmm0, [rsp]
00007ec68bfd4ae8  vmovaps xmm1, [rsp+0x10]
00007ec68bfd4aee  vmovaps xmm3, [rsp+0x20]
00007ec68bfd4af4  vmovaps xmm4, [rsp+0x30]
00007ec68bfd4afa  vmovaps xmm5, [rsp+0x40]
00007ec68bfd4b00  vmovaps xmm6, [rsp+0x50]
00007ec68bfd4b06  vmovaps xmm7, [rsp+0x60]
00007ec68bfd4b0c  vmovaps xmm8, [rsp+0x70]
00007ec68bfd4b12  vmovaps xmm9, [rsp+0x80]
00007ec68bfd4b1b  vmovaps xmm10, [rsp+0x90]
00007ec68bfd4b24  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd4b2d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd4b36  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd4b3f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd4b48  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd4b51  add rsp, 0xF0
00007ec68bfd4b58  pop r11
00007ec68bfd4b5a  pop r10
00007ec68bfd4b5c  pop r9
00007ec68bfd4b5e  pop r8
00007ec68bfd4b60  pop rsi
00007ec68bfd4b61  pop rdi
00007ec68bfd4b62  pop rdx
00007ec68bfd4b63  pop rcx
00007ec68bfd4b64  pop rax
00007ec68bfd4b65  add rsp, 0x08
00007ec68bfd4b69  jmp 0x00007EC68BFD2B8B
00007ec68bfd4b6e  sub rsp, 0x08
00007ec68bfd4b72  push rax
00007ec68bfd4b73  push rcx
00007ec68bfd4b74  push rdx
00007ec68bfd4b75  push rdi
00007ec68bfd4b76  push rsi
00007ec68bfd4b77  push r8
00007ec68bfd4b79  push r9
00007ec68bfd4b7b  push r10
00007ec68bfd4b7d  push r11
00007ec68bfd4b7f  sub rsp, 0xF0
00007ec68bfd4b86  vmovaps [rsp], xmm0
00007ec68bfd4b8b  vmovaps [rsp+0x10], xmm1
00007ec68bfd4b91  vmovaps [rsp+0x20], xmm2
00007ec68bfd4b97  vmovaps [rsp+0x30], xmm3
00007ec68bfd4b9d  vmovaps [rsp+0x40], xmm4
00007ec68bfd4ba3  vmovaps [rsp+0x50], xmm5
00007ec68bfd4ba9  vmovaps [rsp+0x60], xmm6
00007ec68bfd4baf  vmovaps [rsp+0x70], xmm7
00007ec68bfd4bb5  vmovaps [rsp+0x80], xmm8
00007ec68bfd4bbe  vmovaps [rsp+0x90], xmm9
00007ec68bfd4bc7  vmovaps [rsp+0xA0], xmm10
00007ec68bfd4bd0  vmovaps [rsp+0xB0], xmm11
00007ec68bfd4bd9  vmovaps [rsp+0xC0], xmm12
00007ec68bfd4be2  vmovaps [rsp+0xD0], xmm13
00007ec68bfd4beb  vmovaps [rsp+0xE0], xmm14
00007ec68bfd4bf4  sub rsp, 0x30
00007ec68bfd4bf8  movaps [rsp], xmm15
00007ec68bfd4bfd  movaps [rsp+0x10], xmm14
00007ec68bfd4c03  movaps [rsp+0x20], xmm1
00007ec68bfd4c08  lea rdi, [rsp]
00007ec68bfd4c0c  mov esi, 0x00
00007ec68bfd4c11  mov rax, 0x57D97DADF530
00007ec68bfd4c1b  call rax
00007ec68bfd4c1d  movaps xmm15, [rsp]
00007ec68bfd4c22  add rsp, 0x30
00007ec68bfd4c26  vmovaps xmm0, [rsp]
00007ec68bfd4c2b  vmovaps xmm1, [rsp+0x10]
00007ec68bfd4c31  vmovaps xmm2, [rsp+0x20]
00007ec68bfd4c37  vmovaps xmm3, [rsp+0x30]
00007ec68bfd4c3d  vmovaps xmm4, [rsp+0x40]
00007ec68bfd4c43  vmovaps xmm5, [rsp+0x50]
00007ec68bfd4c49  vmovaps xmm6, [rsp+0x60]
00007ec68bfd4c4f  vmovaps xmm7, [rsp+0x70]
00007ec68bfd4c55  vmovaps xmm8, [rsp+0x80]
00007ec68bfd4c5e  vmovaps xmm9, [rsp+0x90]
00007ec68bfd4c67  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd4c70  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd4c79  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd4c82  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd4c8b  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd4c94  add rsp, 0xF0
00007ec68bfd4c9b  pop r11
00007ec68bfd4c9d  pop r10
00007ec68bfd4c9f  pop r9
00007ec68bfd4ca1  pop r8
00007ec68bfd4ca3  pop rsi
00007ec68bfd4ca4  pop rdi
00007ec68bfd4ca5  pop rdx
00007ec68bfd4ca6  pop rcx
00007ec68bfd4ca7  pop rax
00007ec68bfd4ca8  add rsp, 0x08
00007ec68bfd4cac  jmp 0x00007EC68BFD2C05
00007ec68bfd4cb1  call 0x00007EC68BDFF430
00007ec68bfd4cb6  jmp 0x00007EC68BFD2C12
00007ec68bfd4cbb  sub rsp, 0x08
00007ec68bfd4cbf  push rax
00007ec68bfd4cc0  push rcx
00007ec68bfd4cc1  push rdx
00007ec68bfd4cc2  push rdi
00007ec68bfd4cc3  push rsi
00007ec68bfd4cc4  push r8
00007ec68bfd4cc6  push r9
00007ec68bfd4cc8  push r10
00007ec68bfd4cca  push r11
00007ec68bfd4ccc  sub rsp, 0xF0
00007ec68bfd4cd3  vmovaps [rsp], xmm0
00007ec68bfd4cd8  vmovaps [rsp+0x10], xmm1
00007ec68bfd4cde  vmovaps [rsp+0x20], xmm2
00007ec68bfd4ce4  vmovaps [rsp+0x30], xmm3
00007ec68bfd4cea  vmovaps [rsp+0x40], xmm4
00007ec68bfd4cf0  vmovaps [rsp+0x50], xmm5
00007ec68bfd4cf6  vmovaps [rsp+0x60], xmm6
00007ec68bfd4cfc  vmovaps [rsp+0x70], xmm7
00007ec68bfd4d02  vmovaps [rsp+0x80], xmm8
00007ec68bfd4d0b  vmovaps [rsp+0x90], xmm9
00007ec68bfd4d14  vmovaps [rsp+0xA0], xmm10
00007ec68bfd4d1d  vmovaps [rsp+0xB0], xmm11
00007ec68bfd4d26  vmovaps [rsp+0xC0], xmm12
00007ec68bfd4d2f  vmovaps [rsp+0xD0], xmm14
00007ec68bfd4d38  vmovaps [rsp+0xE0], xmm15
00007ec68bfd4d41  sub rsp, 0x30
00007ec68bfd4d45  movaps [rsp], xmm13
00007ec68bfd4d4a  movaps [rsp+0x10], xmm1
00007ec68bfd4d4f  movaps [rsp+0x20], xmm15
00007ec68bfd4d55  lea rdi, [rsp]
00007ec68bfd4d59  mov esi, 0x00
00007ec68bfd4d5e  mov rax, 0x57D97DADF530
00007ec68bfd4d68  call rax
00007ec68bfd4d6a  movaps xmm13, [rsp]
00007ec68bfd4d6f  add rsp, 0x30
00007ec68bfd4d73  vmovaps xmm0, [rsp]
00007ec68bfd4d78  vmovaps xmm1, [rsp+0x10]
00007ec68bfd4d7e  vmovaps xmm2, [rsp+0x20]
00007ec68bfd4d84  vmovaps xmm3, [rsp+0x30]
00007ec68bfd4d8a  vmovaps xmm4, [rsp+0x40]
00007ec68bfd4d90  vmovaps xmm5, [rsp+0x50]
00007ec68bfd4d96  vmovaps xmm6, [rsp+0x60]
00007ec68bfd4d9c  vmovaps xmm7, [rsp+0x70]
00007ec68bfd4da2  vmovaps xmm8, [rsp+0x80]
00007ec68bfd4dab  vmovaps xmm9, [rsp+0x90]
00007ec68bfd4db4  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd4dbd  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd4dc6  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd4dcf  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd4dd8  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd4de1  add rsp, 0xF0
00007ec68bfd4de8  pop r11
00007ec68bfd4dea  pop r10
00007ec68bfd4dec  pop r9
00007ec68bfd4dee  pop r8
00007ec68bfd4df0  pop rsi
00007ec68bfd4df1  pop rdi
00007ec68bfd4df2  pop rdx
00007ec68bfd4df3  pop rcx
00007ec68bfd4df4  pop rax
00007ec68bfd4df5  add rsp, 0x08
00007ec68bfd4df9  jmp 0x00007EC68BFD2CD6
00007ec68bfd4dfe  sub rsp, 0x08
00007ec68bfd4e02  push rax
00007ec68bfd4e03  push rcx
00007ec68bfd4e04  push rdx
00007ec68bfd4e05  push rdi
00007ec68bfd4e06  push rsi
00007ec68bfd4e07  push r8
00007ec68bfd4e09  push r9
00007ec68bfd4e0b  push r10
00007ec68bfd4e0d  push r11
00007ec68bfd4e0f  sub rsp, 0xF0
00007ec68bfd4e16  vmovaps [rsp], xmm0
00007ec68bfd4e1b  vmovaps [rsp+0x10], xmm1
00007ec68bfd4e21  vmovaps [rsp+0x20], xmm2
00007ec68bfd4e27  vmovaps [rsp+0x30], xmm3
00007ec68bfd4e2d  vmovaps [rsp+0x40], xmm4
00007ec68bfd4e33  vmovaps [rsp+0x50], xmm5
00007ec68bfd4e39  vmovaps [rsp+0x60], xmm6
00007ec68bfd4e3f  vmovaps [rsp+0x70], xmm7
00007ec68bfd4e45  vmovaps [rsp+0x80], xmm8
00007ec68bfd4e4e  vmovaps [rsp+0x90], xmm9
00007ec68bfd4e57  vmovaps [rsp+0xA0], xmm10
00007ec68bfd4e60  vmovaps [rsp+0xB0], xmm11
00007ec68bfd4e69  vmovaps [rsp+0xC0], xmm12
00007ec68bfd4e72  vmovaps [rsp+0xD0], xmm13
00007ec68bfd4e7b  vmovaps [rsp+0xE0], xmm14
00007ec68bfd4e84  sub rsp, 0x30
00007ec68bfd4e88  movaps [rsp], xmm15
00007ec68bfd4e8d  movaps [rsp+0x10], xmm14
00007ec68bfd4e93  movaps [rsp+0x20], xmm1
00007ec68bfd4e98  lea rdi, [rsp]
00007ec68bfd4e9c  mov esi, 0x00
00007ec68bfd4ea1  mov rax, 0x57D97DADF530
00007ec68bfd4eab  call rax
00007ec68bfd4ead  movaps xmm15, [rsp]
00007ec68bfd4eb2  add rsp, 0x30
00007ec68bfd4eb6  vmovaps xmm0, [rsp]
00007ec68bfd4ebb  vmovaps xmm1, [rsp+0x10]
00007ec68bfd4ec1  vmovaps xmm2, [rsp+0x20]
00007ec68bfd4ec7  vmovaps xmm3, [rsp+0x30]
00007ec68bfd4ecd  vmovaps xmm4, [rsp+0x40]
00007ec68bfd4ed3  vmovaps xmm5, [rsp+0x50]
00007ec68bfd4ed9  vmovaps xmm6, [rsp+0x60]
00007ec68bfd4edf  vmovaps xmm7, [rsp+0x70]
00007ec68bfd4ee5  vmovaps xmm8, [rsp+0x80]
00007ec68bfd4eee  vmovaps xmm9, [rsp+0x90]
00007ec68bfd4ef7  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd4f00  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd4f09  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd4f12  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd4f1b  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd4f24  add rsp, 0xF0
00007ec68bfd4f2b  pop r11
00007ec68bfd4f2d  pop r10
00007ec68bfd4f2f  pop r9
00007ec68bfd4f31  pop r8
00007ec68bfd4f33  pop rsi
00007ec68bfd4f34  pop rdi
00007ec68bfd4f35  pop rdx
00007ec68bfd4f36  pop rcx
00007ec68bfd4f37  pop rax
00007ec68bfd4f38  add rsp, 0x08
00007ec68bfd4f3c  jmp 0x00007EC68BFD2D12
00007ec68bfd4f41  call 0x00007EC68BDFF430
00007ec68bfd4f46  jmp 0x00007EC68BFD2D1F
00007ec68bfd4f4b  sub rsp, 0x08
00007ec68bfd4f4f  push rax
00007ec68bfd4f50  push rcx
00007ec68bfd4f51  push rdx
00007ec68bfd4f52  push rdi
00007ec68bfd4f53  push rsi
00007ec68bfd4f54  push r8
00007ec68bfd4f56  push r9
00007ec68bfd4f58  push r10
00007ec68bfd4f5a  push r11
00007ec68bfd4f5c  sub rsp, 0xF0
00007ec68bfd4f63  vmovaps [rsp], xmm0
00007ec68bfd4f68  vmovaps [rsp+0x10], xmm1
00007ec68bfd4f6e  vmovaps [rsp+0x20], xmm2
00007ec68bfd4f74  vmovaps [rsp+0x30], xmm3
00007ec68bfd4f7a  vmovaps [rsp+0x40], xmm4
00007ec68bfd4f80  vmovaps [rsp+0x50], xmm5
00007ec68bfd4f86  vmovaps [rsp+0x60], xmm6
00007ec68bfd4f8c  vmovaps [rsp+0x70], xmm7
00007ec68bfd4f92  vmovaps [rsp+0x80], xmm8
00007ec68bfd4f9b  vmovaps [rsp+0x90], xmm9
00007ec68bfd4fa4  vmovaps [rsp+0xA0], xmm10
00007ec68bfd4fad  vmovaps [rsp+0xB0], xmm11
00007ec68bfd4fb6  vmovaps [rsp+0xC0], xmm12
00007ec68bfd4fbf  vmovaps [rsp+0xD0], xmm13
00007ec68bfd4fc8  vmovaps [rsp+0xE0], xmm15
00007ec68bfd4fd1  sub rsp, 0x30
00007ec68bfd4fd5  movaps [rsp], xmm14
00007ec68bfd4fda  movaps [rsp+0x10], xmm13
00007ec68bfd4fe0  movaps [rsp+0x20], xmm2
00007ec68bfd4fe5  lea rdi, [rsp]
00007ec68bfd4fe9  mov esi, 0x00
00007ec68bfd4fee  mov rax, 0x57D97DADF530
00007ec68bfd4ff8  call rax
00007ec68bfd4ffa  movaps xmm14, [rsp]
00007ec68bfd4fff  add rsp, 0x30
00007ec68bfd5003  vmovaps xmm0, [rsp]
00007ec68bfd5008  vmovaps xmm1, [rsp+0x10]
00007ec68bfd500e  vmovaps xmm2, [rsp+0x20]
00007ec68bfd5014  vmovaps xmm3, [rsp+0x30]
00007ec68bfd501a  vmovaps xmm4, [rsp+0x40]
00007ec68bfd5020  vmovaps xmm5, [rsp+0x50]
00007ec68bfd5026  vmovaps xmm6, [rsp+0x60]
00007ec68bfd502c  vmovaps xmm7, [rsp+0x70]
00007ec68bfd5032  vmovaps xmm8, [rsp+0x80]
00007ec68bfd503b  vmovaps xmm9, [rsp+0x90]
00007ec68bfd5044  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd504d  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd5056  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd505f  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd5068  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd5071  add rsp, 0xF0
00007ec68bfd5078  pop r11
00007ec68bfd507a  pop r10
00007ec68bfd507c  pop r9
00007ec68bfd507e  pop r8
00007ec68bfd5080  pop rsi
00007ec68bfd5081  pop rdi
00007ec68bfd5082  pop rdx
00007ec68bfd5083  pop rcx
00007ec68bfd5084  pop rax
00007ec68bfd5085  add rsp, 0x08
00007ec68bfd5089  jmp 0x00007EC68BFD2D4B
00007ec68bfd508e  sub rsp, 0x08
00007ec68bfd5092  push rax
00007ec68bfd5093  push rcx
00007ec68bfd5094  push rdx
00007ec68bfd5095  push rdi
00007ec68bfd5096  push rsi
00007ec68bfd5097  push r8
00007ec68bfd5099  push r9
00007ec68bfd509b  push r10
00007ec68bfd509d  push r11
00007ec68bfd509f  sub rsp, 0xF0
00007ec68bfd50a6  vmovaps [rsp], xmm0
00007ec68bfd50ab  vmovaps [rsp+0x10], xmm2
00007ec68bfd50b1  vmovaps [rsp+0x20], xmm3
00007ec68bfd50b7  vmovaps [rsp+0x30], xmm4
00007ec68bfd50bd  vmovaps [rsp+0x40], xmm5
00007ec68bfd50c3  vmovaps [rsp+0x50], xmm6
00007ec68bfd50c9  vmovaps [rsp+0x60], xmm7
00007ec68bfd50cf  vmovaps [rsp+0x70], xmm8
00007ec68bfd50d5  vmovaps [rsp+0x80], xmm9
00007ec68bfd50de  vmovaps [rsp+0x90], xmm10
00007ec68bfd50e7  vmovaps [rsp+0xA0], xmm11
00007ec68bfd50f0  vmovaps [rsp+0xB0], xmm12
00007ec68bfd50f9  vmovaps [rsp+0xC0], xmm13
00007ec68bfd5102  vmovaps [rsp+0xD0], xmm14
00007ec68bfd510b  vmovaps [rsp+0xE0], xmm15
00007ec68bfd5114  sub rsp, 0x30
00007ec68bfd5118  movaps [rsp], xmm1
00007ec68bfd511c  movaps [rsp+0x10], xmm13
00007ec68bfd5122  movaps [rsp+0x20], xmm2
00007ec68bfd5127  lea rdi, [rsp]
00007ec68bfd512b  mov esi, 0x00
00007ec68bfd5130  mov rax, 0x57D97DADF530
00007ec68bfd513a  call rax
00007ec68bfd513c  movaps xmm1, [rsp]
00007ec68bfd5140  add rsp, 0x30
00007ec68bfd5144  vmovaps xmm0, [rsp]
00007ec68bfd5149  vmovaps xmm2, [rsp+0x10]
00007ec68bfd514f  vmovaps xmm3, [rsp+0x20]
00007ec68bfd5155  vmovaps xmm4, [rsp+0x30]
00007ec68bfd515b  vmovaps xmm5, [rsp+0x40]
00007ec68bfd5161  vmovaps xmm6, [rsp+0x50]
00007ec68bfd5167  vmovaps xmm7, [rsp+0x60]
00007ec68bfd516d  vmovaps xmm8, [rsp+0x70]
00007ec68bfd5173  vmovaps xmm9, [rsp+0x80]
00007ec68bfd517c  vmovaps xmm10, [rsp+0x90]
00007ec68bfd5185  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd518e  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd5197  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd51a0  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd51a9  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd51b2  add rsp, 0xF0
00007ec68bfd51b9  pop r11
00007ec68bfd51bb  pop r10
00007ec68bfd51bd  pop r9
00007ec68bfd51bf  pop r8
00007ec68bfd51c1  pop rsi
00007ec68bfd51c2  pop rdi
00007ec68bfd51c3  pop rdx
00007ec68bfd51c4  pop rcx
00007ec68bfd51c5  pop rax
00007ec68bfd51c6  add rsp, 0x08
00007ec68bfd51ca  jmp 0x00007EC68BFD2D79
00007ec68bfd51cf  sub rsp, 0x08
00007ec68bfd51d3  push rax
00007ec68bfd51d4  push rcx
00007ec68bfd51d5  push rdx
00007ec68bfd51d6  push rdi
00007ec68bfd51d7  push rsi
00007ec68bfd51d8  push r8
00007ec68bfd51da  push r9
00007ec68bfd51dc  push r10
00007ec68bfd51de  push r11
00007ec68bfd51e0  sub rsp, 0xF0
00007ec68bfd51e7  vmovaps [rsp], xmm0
00007ec68bfd51ec  vmovaps [rsp+0x10], xmm1
00007ec68bfd51f2  vmovaps [rsp+0x20], xmm3
00007ec68bfd51f8  vmovaps [rsp+0x30], xmm4
00007ec68bfd51fe  vmovaps [rsp+0x40], xmm5
00007ec68bfd5204  vmovaps [rsp+0x50], xmm6
00007ec68bfd520a  vmovaps [rsp+0x60], xmm7
00007ec68bfd5210  vmovaps [rsp+0x70], xmm8
00007ec68bfd5216  vmovaps [rsp+0x80], xmm9
00007ec68bfd521f  vmovaps [rsp+0x90], xmm10
00007ec68bfd5228  vmovaps [rsp+0xA0], xmm11
00007ec68bfd5231  vmovaps [rsp+0xB0], xmm12
00007ec68bfd523a  vmovaps [rsp+0xC0], xmm13
00007ec68bfd5243  vmovaps [rsp+0xD0], xmm14
00007ec68bfd524c  vmovaps [rsp+0xE0], xmm15
00007ec68bfd5255  sub rsp, 0x30
00007ec68bfd5259  movaps [rsp], xmm2
00007ec68bfd525d  movaps [rsp+0x10], xmm1
00007ec68bfd5262  movaps [rsp+0x20], xmm13
00007ec68bfd5268  lea rdi, [rsp]
00007ec68bfd526c  mov esi, 0x00
00007ec68bfd5271  mov rax, 0x57D97DADF530
00007ec68bfd527b  call rax
00007ec68bfd527d  movaps xmm2, [rsp]
00007ec68bfd5281  add rsp, 0x30
00007ec68bfd5285  vmovaps xmm0, [rsp]
00007ec68bfd528a  vmovaps xmm1, [rsp+0x10]
00007ec68bfd5290  vmovaps xmm3, [rsp+0x20]
00007ec68bfd5296  vmovaps xmm4, [rsp+0x30]
00007ec68bfd529c  vmovaps xmm5, [rsp+0x40]
00007ec68bfd52a2  vmovaps xmm6, [rsp+0x50]
00007ec68bfd52a8  vmovaps xmm7, [rsp+0x60]
00007ec68bfd52ae  vmovaps xmm8, [rsp+0x70]
00007ec68bfd52b4  vmovaps xmm9, [rsp+0x80]
00007ec68bfd52bd  vmovaps xmm10, [rsp+0x90]
00007ec68bfd52c6  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd52cf  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd52d8  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd52e1  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd52ea  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd52f3  add rsp, 0xF0
00007ec68bfd52fa  pop r11
00007ec68bfd52fc  pop r10
00007ec68bfd52fe  pop r9
00007ec68bfd5300  pop r8
00007ec68bfd5302  pop rsi
00007ec68bfd5303  pop rdi
00007ec68bfd5304  pop rdx
00007ec68bfd5305  pop rcx
00007ec68bfd5306  pop rax
00007ec68bfd5307  add rsp, 0x08
00007ec68bfd530b  jmp 0x00007EC68BFD2DD2
00007ec68bfd5310  call 0x00007EC68BDFF430
00007ec68bfd5315  jmp 0x00007EC68BFD2DDF
00007ec68bfd531a  sub rsp, 0x08
00007ec68bfd531e  push rax
00007ec68bfd531f  push rcx
00007ec68bfd5320  push rdx
00007ec68bfd5321  push rdi
00007ec68bfd5322  push rsi
00007ec68bfd5323  push r8
00007ec68bfd5325  push r9
00007ec68bfd5327  push r10
00007ec68bfd5329  push r11
00007ec68bfd532b  sub rsp, 0xF0
00007ec68bfd5332  vmovaps [rsp], xmm0
00007ec68bfd5337  vmovaps [rsp+0x10], xmm1
00007ec68bfd533d  vmovaps [rsp+0x20], xmm2
00007ec68bfd5343  vmovaps [rsp+0x30], xmm3
00007ec68bfd5349  vmovaps [rsp+0x40], xmm4
00007ec68bfd534f  vmovaps [rsp+0x50], xmm5
00007ec68bfd5355  vmovaps [rsp+0x60], xmm6
00007ec68bfd535b  vmovaps [rsp+0x70], xmm7
00007ec68bfd5361  vmovaps [rsp+0x80], xmm8
00007ec68bfd536a  vmovaps [rsp+0x90], xmm9
00007ec68bfd5373  vmovaps [rsp+0xA0], xmm10
00007ec68bfd537c  vmovaps [rsp+0xB0], xmm11
00007ec68bfd5385  vmovaps [rsp+0xC0], xmm12
00007ec68bfd538e  vmovaps [rsp+0xD0], xmm13
00007ec68bfd5397  vmovaps [rsp+0xE0], xmm14
00007ec68bfd53a0  sub rsp, 0x30
00007ec68bfd53a4  movaps [rsp], xmm15
00007ec68bfd53a9  movaps [rsp+0x10], xmm13
00007ec68bfd53af  movaps [rsp+0x20], xmm1
00007ec68bfd53b4  lea rdi, [rsp]
00007ec68bfd53b8  mov esi, 0x00
00007ec68bfd53bd  mov rax, 0x57D97DADF530
00007ec68bfd53c7  call rax
00007ec68bfd53c9  movaps xmm15, [rsp]
00007ec68bfd53ce  add rsp, 0x30
00007ec68bfd53d2  vmovaps xmm0, [rsp]
00007ec68bfd53d7  vmovaps xmm1, [rsp+0x10]
00007ec68bfd53dd  vmovaps xmm2, [rsp+0x20]
00007ec68bfd53e3  vmovaps xmm3, [rsp+0x30]
00007ec68bfd53e9  vmovaps xmm4, [rsp+0x40]
00007ec68bfd53ef  vmovaps xmm5, [rsp+0x50]
00007ec68bfd53f5  vmovaps xmm6, [rsp+0x60]
00007ec68bfd53fb  vmovaps xmm7, [rsp+0x70]
00007ec68bfd5401  vmovaps xmm8, [rsp+0x80]
00007ec68bfd540a  vmovaps xmm9, [rsp+0x90]
00007ec68bfd5413  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd541c  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd5425  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd542e  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd5437  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd5440  add rsp, 0xF0
00007ec68bfd5447  pop r11
00007ec68bfd5449  pop r10
00007ec68bfd544b  pop r9
00007ec68bfd544d  pop r8
00007ec68bfd544f  pop rsi
00007ec68bfd5450  pop rdi
00007ec68bfd5451  pop rdx
00007ec68bfd5452  pop rcx
00007ec68bfd5453  pop rax
00007ec68bfd5454  add rsp, 0x08
00007ec68bfd5458  jmp 0x00007EC68BFD2E1E
00007ec68bfd545d  sub rsp, 0x08
00007ec68bfd5461  push rax
00007ec68bfd5462  push rcx
00007ec68bfd5463  push rdx
00007ec68bfd5464  push rdi
00007ec68bfd5465  push rsi
00007ec68bfd5466  push r8
00007ec68bfd5468  push r9
00007ec68bfd546a  push r10
00007ec68bfd546c  push r11
00007ec68bfd546e  sub rsp, 0xF0
00007ec68bfd5475  vmovaps [rsp], xmm0
00007ec68bfd547a  vmovaps [rsp+0x10], xmm1
00007ec68bfd5480  vmovaps [rsp+0x20], xmm2
00007ec68bfd5486  vmovaps [rsp+0x30], xmm3
00007ec68bfd548c  vmovaps [rsp+0x40], xmm4
00007ec68bfd5492  vmovaps [rsp+0x50], xmm5
00007ec68bfd5498  vmovaps [rsp+0x60], xmm6
00007ec68bfd549e  vmovaps [rsp+0x70], xmm7
00007ec68bfd54a4  vmovaps [rsp+0x80], xmm8
00007ec68bfd54ad  vmovaps [rsp+0x90], xmm9
00007ec68bfd54b6  vmovaps [rsp+0xA0], xmm10
00007ec68bfd54bf  vmovaps [rsp+0xB0], xmm11
00007ec68bfd54c8  vmovaps [rsp+0xC0], xmm12
00007ec68bfd54d1  vmovaps [rsp+0xD0], xmm13
00007ec68bfd54da  vmovaps [rsp+0xE0], xmm15
00007ec68bfd54e3  sub rsp, 0x30
00007ec68bfd54e7  movaps [rsp], xmm14
00007ec68bfd54ec  movaps [rsp+0x10], xmm11
00007ec68bfd54f2  movaps [rsp+0x20], xmm1
00007ec68bfd54f7  lea rdi, [rsp]
00007ec68bfd54fb  mov esi, 0x00
00007ec68bfd5500  mov rax, 0x57D97DADF530
00007ec68bfd550a  call rax
00007ec68bfd550c  movaps xmm14, [rsp]
00007ec68bfd5511  add rsp, 0x30
00007ec68bfd5515  vmovaps xmm0, [rsp]
00007ec68bfd551a  vmovaps xmm1, [rsp+0x10]
00007ec68bfd5520  vmovaps xmm2, [rsp+0x20]
00007ec68bfd5526  vmovaps xmm3, [rsp+0x30]
00007ec68bfd552c  vmovaps xmm4, [rsp+0x40]
00007ec68bfd5532  vmovaps xmm5, [rsp+0x50]
00007ec68bfd5538  vmovaps xmm6, [rsp+0x60]
00007ec68bfd553e  vmovaps xmm7, [rsp+0x70]
00007ec68bfd5544  vmovaps xmm8, [rsp+0x80]
00007ec68bfd554d  vmovaps xmm9, [rsp+0x90]
00007ec68bfd5556  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd555f  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd5568  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd5571  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd557a  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd5583  add rsp, 0xF0
00007ec68bfd558a  pop r11
00007ec68bfd558c  pop r10
00007ec68bfd558e  pop r9
00007ec68bfd5590  pop r8
00007ec68bfd5592  pop rsi
00007ec68bfd5593  pop rdi
00007ec68bfd5594  pop rdx
00007ec68bfd5595  pop rcx
00007ec68bfd5596  pop rax
00007ec68bfd5597  add rsp, 0x08
00007ec68bfd559b  jmp 0x00007EC68BFD2E48
00007ec68bfd55a0  sub rsp, 0x08
00007ec68bfd55a4  push rax
00007ec68bfd55a5  push rcx
00007ec68bfd55a6  push rdx
00007ec68bfd55a7  push rdi
00007ec68bfd55a8  push rsi
00007ec68bfd55a9  push r8
00007ec68bfd55ab  push r9
00007ec68bfd55ad  push r10
00007ec68bfd55af  push r11
00007ec68bfd55b1  sub rsp, 0xF0
00007ec68bfd55b8  vmovaps [rsp], xmm0
00007ec68bfd55bd  vmovaps [rsp+0x10], xmm1
00007ec68bfd55c3  vmovaps [rsp+0x20], xmm2
00007ec68bfd55c9  vmovaps [rsp+0x30], xmm3
00007ec68bfd55cf  vmovaps [rsp+0x40], xmm4
00007ec68bfd55d5  vmovaps [rsp+0x50], xmm5
00007ec68bfd55db  vmovaps [rsp+0x60], xmm6
00007ec68bfd55e1  vmovaps [rsp+0x70], xmm7
00007ec68bfd55e7  vmovaps [rsp+0x80], xmm8
00007ec68bfd55f0  vmovaps [rsp+0x90], xmm9
00007ec68bfd55f9  vmovaps [rsp+0xA0], xmm10
00007ec68bfd5602  vmovaps [rsp+0xB0], xmm11
00007ec68bfd560b  vmovaps [rsp+0xC0], xmm12
00007ec68bfd5614  vmovaps [rsp+0xD0], xmm14
00007ec68bfd561d  vmovaps [rsp+0xE0], xmm15
00007ec68bfd5626  sub rsp, 0x30
00007ec68bfd562a  movaps [rsp], xmm13
00007ec68bfd562f  movaps [rsp+0x10], xmm11
00007ec68bfd5635  movaps [rsp+0x20], xmm1
00007ec68bfd563a  lea rdi, [rsp]
00007ec68bfd563e  mov esi, 0x00
00007ec68bfd5643  mov rax, 0x57D97DADF530
00007ec68bfd564d  call rax
00007ec68bfd564f  movaps xmm13, [rsp]
00007ec68bfd5654  add rsp, 0x30
00007ec68bfd5658  vmovaps xmm0, [rsp]
00007ec68bfd565d  vmovaps xmm1, [rsp+0x10]
00007ec68bfd5663  vmovaps xmm2, [rsp+0x20]
00007ec68bfd5669  vmovaps xmm3, [rsp+0x30]
00007ec68bfd566f  vmovaps xmm4, [rsp+0x40]
00007ec68bfd5675  vmovaps xmm5, [rsp+0x50]
00007ec68bfd567b  vmovaps xmm6, [rsp+0x60]
00007ec68bfd5681  vmovaps xmm7, [rsp+0x70]
00007ec68bfd5687  vmovaps xmm8, [rsp+0x80]
00007ec68bfd5690  vmovaps xmm9, [rsp+0x90]
00007ec68bfd5699  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd56a2  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd56ab  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd56b4  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd56bd  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd56c6  add rsp, 0xF0
00007ec68bfd56cd  pop r11
00007ec68bfd56cf  pop r10
00007ec68bfd56d1  pop r9
00007ec68bfd56d3  pop r8
00007ec68bfd56d5  pop rsi
00007ec68bfd56d6  pop rdi
00007ec68bfd56d7  pop rdx
00007ec68bfd56d8  pop rcx
00007ec68bfd56d9  pop rax
00007ec68bfd56da  add rsp, 0x08
00007ec68bfd56de  jmp 0x00007EC68BFD2E9D
00007ec68bfd56e3  call 0x00007EC68BDFF430
00007ec68bfd56e8  jmp 0x00007EC68BFD2EAA
00007ec68bfd56ed  sub rsp, 0x08
00007ec68bfd56f1  push rax
00007ec68bfd56f2  push rcx
00007ec68bfd56f3  push rdx
00007ec68bfd56f4  push rdi
00007ec68bfd56f5  push rsi
00007ec68bfd56f6  push r8
00007ec68bfd56f8  push r9
00007ec68bfd56fa  push r10
00007ec68bfd56fc  push r11
00007ec68bfd56fe  sub rsp, 0xF0
00007ec68bfd5705  vmovaps [rsp], xmm0
00007ec68bfd570a  vmovaps [rsp+0x10], xmm1
00007ec68bfd5710  vmovaps [rsp+0x20], xmm2
00007ec68bfd5716  vmovaps [rsp+0x30], xmm3
00007ec68bfd571c  vmovaps [rsp+0x40], xmm4
00007ec68bfd5722  vmovaps [rsp+0x50], xmm5
00007ec68bfd5728  vmovaps [rsp+0x60], xmm6
00007ec68bfd572e  vmovaps [rsp+0x70], xmm7
00007ec68bfd5734  vmovaps [rsp+0x80], xmm8
00007ec68bfd573d  vmovaps [rsp+0x90], xmm9
00007ec68bfd5746  vmovaps [rsp+0xA0], xmm10
00007ec68bfd574f  vmovaps [rsp+0xB0], xmm11
00007ec68bfd5758  vmovaps [rsp+0xC0], xmm12
00007ec68bfd5761  vmovaps [rsp+0xD0], xmm13
00007ec68bfd576a  vmovaps [rsp+0xE0], xmm14
00007ec68bfd5773  sub rsp, 0x30
00007ec68bfd5777  movaps [rsp], xmm15
00007ec68bfd577c  movaps [rsp+0x10], xmm11
00007ec68bfd5782  movaps [rsp+0x20], xmm1
00007ec68bfd5787  lea rdi, [rsp]
00007ec68bfd578b  mov esi, 0x00
00007ec68bfd5790  mov rax, 0x57D97DADF530
00007ec68bfd579a  call rax
00007ec68bfd579c  movaps xmm15, [rsp]
00007ec68bfd57a1  add rsp, 0x30
00007ec68bfd57a5  vmovaps xmm0, [rsp]
00007ec68bfd57aa  vmovaps xmm1, [rsp+0x10]
00007ec68bfd57b0  vmovaps xmm2, [rsp+0x20]
00007ec68bfd57b6  vmovaps xmm3, [rsp+0x30]
00007ec68bfd57bc  vmovaps xmm4, [rsp+0x40]
00007ec68bfd57c2  vmovaps xmm5, [rsp+0x50]
00007ec68bfd57c8  vmovaps xmm6, [rsp+0x60]
00007ec68bfd57ce  vmovaps xmm7, [rsp+0x70]
00007ec68bfd57d4  vmovaps xmm8, [rsp+0x80]
00007ec68bfd57dd  vmovaps xmm9, [rsp+0x90]
00007ec68bfd57e6  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd57ef  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd57f8  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd5801  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd580a  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd5813  add rsp, 0xF0
00007ec68bfd581a  pop r11
00007ec68bfd581c  pop r10
00007ec68bfd581e  pop r9
00007ec68bfd5820  pop r8
00007ec68bfd5822  pop rsi
00007ec68bfd5823  pop rdi
00007ec68bfd5824  pop rdx
00007ec68bfd5825  pop rcx
00007ec68bfd5826  pop rax
00007ec68bfd5827  add rsp, 0x08
00007ec68bfd582b  jmp 0x00007EC68BFD2EE3
00007ec68bfd5830  sub rsp, 0x08
00007ec68bfd5834  push rax
00007ec68bfd5835  push rcx
00007ec68bfd5836  push rdx
00007ec68bfd5837  push rdi
00007ec68bfd5838  push rsi
00007ec68bfd5839  push r8
00007ec68bfd583b  push r9
00007ec68bfd583d  push r10
00007ec68bfd583f  push r11
00007ec68bfd5841  sub rsp, 0xF0
00007ec68bfd5848  vmovaps [rsp], xmm0
00007ec68bfd584d  vmovaps [rsp+0x10], xmm1
00007ec68bfd5853  vmovaps [rsp+0x20], xmm2
00007ec68bfd5859  vmovaps [rsp+0x30], xmm3
00007ec68bfd585f  vmovaps [rsp+0x40], xmm4
00007ec68bfd5865  vmovaps [rsp+0x50], xmm5
00007ec68bfd586b  vmovaps [rsp+0x60], xmm6
00007ec68bfd5871  vmovaps [rsp+0x70], xmm7
00007ec68bfd5877  vmovaps [rsp+0x80], xmm8
00007ec68bfd5880  vmovaps [rsp+0x90], xmm9
00007ec68bfd5889  vmovaps [rsp+0xA0], xmm10
00007ec68bfd5892  vmovaps [rsp+0xB0], xmm12
00007ec68bfd589b  vmovaps [rsp+0xC0], xmm13
00007ec68bfd58a4  vmovaps [rsp+0xD0], xmm14
00007ec68bfd58ad  vmovaps [rsp+0xE0], xmm15
00007ec68bfd58b6  sub rsp, 0x30
00007ec68bfd58ba  movaps [rsp], xmm11
00007ec68bfd58bf  movaps [rsp+0x10], xmm6
00007ec68bfd58c4  movaps [rsp+0x20], xmm14
00007ec68bfd58ca  lea rdi, [rsp]
00007ec68bfd58ce  mov esi, 0x00
00007ec68bfd58d3  mov rax, 0x57D97DADF530
00007ec68bfd58dd  call rax
00007ec68bfd58df  movaps xmm11, [rsp]
00007ec68bfd58e4  add rsp, 0x30
00007ec68bfd58e8  vmovaps xmm0, [rsp]
00007ec68bfd58ed  vmovaps xmm1, [rsp+0x10]
00007ec68bfd58f3  vmovaps xmm2, [rsp+0x20]
00007ec68bfd58f9  vmovaps xmm3, [rsp+0x30]
00007ec68bfd58ff  vmovaps xmm4, [rsp+0x40]
00007ec68bfd5905  vmovaps xmm5, [rsp+0x50]
00007ec68bfd590b  vmovaps xmm6, [rsp+0x60]
00007ec68bfd5911  vmovaps xmm7, [rsp+0x70]
00007ec68bfd5917  vmovaps xmm8, [rsp+0x80]
00007ec68bfd5920  vmovaps xmm9, [rsp+0x90]
00007ec68bfd5929  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd5932  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd593b  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd5944  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd594d  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd5956  add rsp, 0xF0
00007ec68bfd595d  pop r11
00007ec68bfd595f  pop r10
00007ec68bfd5961  pop r9
00007ec68bfd5963  pop r8
00007ec68bfd5965  pop rsi
00007ec68bfd5966  pop rdi
00007ec68bfd5967  pop rdx
00007ec68bfd5968  pop rcx
00007ec68bfd5969  pop rax
00007ec68bfd596a  add rsp, 0x08
00007ec68bfd596e  jmp 0x00007EC68BFD2F5B
00007ec68bfd5973  call 0x00007EC68BDFF430
00007ec68bfd5978  jmp 0x00007EC68BFD2F65
00007ec68bfd597d  sub rsp, 0x08
00007ec68bfd5981  push rax
00007ec68bfd5982  push rcx
00007ec68bfd5983  push rdx
00007ec68bfd5984  push rdi
00007ec68bfd5985  push rsi
00007ec68bfd5986  push r8
00007ec68bfd5988  push r9
00007ec68bfd598a  push r10
00007ec68bfd598c  push r11
00007ec68bfd598e  sub rsp, 0xF0
00007ec68bfd5995  vmovaps [rsp], xmm0
00007ec68bfd599a  vmovaps [rsp+0x10], xmm1
00007ec68bfd59a0  vmovaps [rsp+0x20], xmm2
00007ec68bfd59a6  vmovaps [rsp+0x30], xmm3
00007ec68bfd59ac  vmovaps [rsp+0x40], xmm4
00007ec68bfd59b2  vmovaps [rsp+0x50], xmm5
00007ec68bfd59b8  vmovaps [rsp+0x60], xmm6
00007ec68bfd59be  vmovaps [rsp+0x70], xmm7
00007ec68bfd59c4  vmovaps [rsp+0x80], xmm8
00007ec68bfd59cd  vmovaps [rsp+0x90], xmm9
00007ec68bfd59d6  vmovaps [rsp+0xA0], xmm10
00007ec68bfd59df  vmovaps [rsp+0xB0], xmm11
00007ec68bfd59e8  vmovaps [rsp+0xC0], xmm12
00007ec68bfd59f1  vmovaps [rsp+0xD0], xmm13
00007ec68bfd59fa  vmovaps [rsp+0xE0], xmm15
00007ec68bfd5a03  sub rsp, 0x30
00007ec68bfd5a07  movaps [rsp], xmm14
00007ec68bfd5a0c  movaps [rsp+0x10], xmm6
00007ec68bfd5a11  movaps [rsp+0x20], xmm2
00007ec68bfd5a16  lea rdi, [rsp]
00007ec68bfd5a1a  mov esi, 0x00
00007ec68bfd5a1f  mov rax, 0x57D97DADF530
00007ec68bfd5a29  call rax
00007ec68bfd5a2b  movaps xmm14, [rsp]
00007ec68bfd5a30  add rsp, 0x30
00007ec68bfd5a34  vmovaps xmm0, [rsp]
00007ec68bfd5a39  vmovaps xmm1, [rsp+0x10]
00007ec68bfd5a3f  vmovaps xmm2, [rsp+0x20]
00007ec68bfd5a45  vmovaps xmm3, [rsp+0x30]
00007ec68bfd5a4b  vmovaps xmm4, [rsp+0x40]
00007ec68bfd5a51  vmovaps xmm5, [rsp+0x50]
00007ec68bfd5a57  vmovaps xmm6, [rsp+0x60]
00007ec68bfd5a5d  vmovaps xmm7, [rsp+0x70]
00007ec68bfd5a63  vmovaps xmm8, [rsp+0x80]
00007ec68bfd5a6c  vmovaps xmm9, [rsp+0x90]
00007ec68bfd5a75  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd5a7e  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd5a87  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd5a90  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd5a99  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd5aa2  add rsp, 0xF0
00007ec68bfd5aa9  pop r11
00007ec68bfd5aab  pop r10
00007ec68bfd5aad  pop r9
00007ec68bfd5aaf  pop r8
00007ec68bfd5ab1  pop rsi
00007ec68bfd5ab2  pop rdi
00007ec68bfd5ab3  pop rdx
00007ec68bfd5ab4  pop rcx
00007ec68bfd5ab5  pop rax
00007ec68bfd5ab6  add rsp, 0x08
00007ec68bfd5aba  jmp 0x00007EC68BFD2F99
00007ec68bfd5abf  sub rsp, 0x08
00007ec68bfd5ac3  push rax
00007ec68bfd5ac4  push rcx
00007ec68bfd5ac5  push rdx
00007ec68bfd5ac6  push rdi
00007ec68bfd5ac7  push rsi
00007ec68bfd5ac8  push r8
00007ec68bfd5aca  push r9
00007ec68bfd5acc  push r10
00007ec68bfd5ace  push r11
00007ec68bfd5ad0  sub rsp, 0xF0
00007ec68bfd5ad7  vmovaps [rsp], xmm0
00007ec68bfd5adc  vmovaps [rsp+0x10], xmm1
00007ec68bfd5ae2  vmovaps [rsp+0x20], xmm2
00007ec68bfd5ae8  vmovaps [rsp+0x30], xmm3
00007ec68bfd5aee  vmovaps [rsp+0x40], xmm4
00007ec68bfd5af4  vmovaps [rsp+0x50], xmm5
00007ec68bfd5afa  vmovaps [rsp+0x60], xmm7
00007ec68bfd5b00  vmovaps [rsp+0x70], xmm8
00007ec68bfd5b06  vmovaps [rsp+0x80], xmm9
00007ec68bfd5b0f  vmovaps [rsp+0x90], xmm10
00007ec68bfd5b18  vmovaps [rsp+0xA0], xmm11
00007ec68bfd5b21  vmovaps [rsp+0xB0], xmm12
00007ec68bfd5b2a  vmovaps [rsp+0xC0], xmm13
00007ec68bfd5b33  vmovaps [rsp+0xD0], xmm14
00007ec68bfd5b3c  vmovaps [rsp+0xE0], xmm15
00007ec68bfd5b45  sub rsp, 0x30
00007ec68bfd5b49  movaps [rsp], xmm6
00007ec68bfd5b4d  movaps [rsp+0x10], xmm5
00007ec68bfd5b52  movaps [rsp+0x20], xmm1
00007ec68bfd5b57  lea rdi, [rsp]
00007ec68bfd5b5b  mov esi, 0x00
00007ec68bfd5b60  mov rax, 0x57D97DADF530
00007ec68bfd5b6a  call rax
00007ec68bfd5b6c  movaps xmm6, [rsp]
00007ec68bfd5b70  add rsp, 0x30
00007ec68bfd5b74  vmovaps xmm0, [rsp]
00007ec68bfd5b79  vmovaps xmm1, [rsp+0x10]
00007ec68bfd5b7f  vmovaps xmm2, [rsp+0x20]
00007ec68bfd5b85  vmovaps xmm3, [rsp+0x30]
00007ec68bfd5b8b  vmovaps xmm4, [rsp+0x40]
00007ec68bfd5b91  vmovaps xmm5, [rsp+0x50]
00007ec68bfd5b97  vmovaps xmm7, [rsp+0x60]
00007ec68bfd5b9d  vmovaps xmm8, [rsp+0x70]
00007ec68bfd5ba3  vmovaps xmm9, [rsp+0x80]
00007ec68bfd5bac  vmovaps xmm10, [rsp+0x90]
00007ec68bfd5bb5  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd5bbe  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd5bc7  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd5bd0  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd5bd9  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd5be2  add rsp, 0xF0
00007ec68bfd5be9  pop r11
00007ec68bfd5beb  pop r10
00007ec68bfd5bed  pop r9
00007ec68bfd5bef  pop r8
00007ec68bfd5bf1  pop rsi
00007ec68bfd5bf2  pop rdi
00007ec68bfd5bf3  pop rdx
00007ec68bfd5bf4  pop rcx
00007ec68bfd5bf5  pop rax
00007ec68bfd5bf6  add rsp, 0x08
00007ec68bfd5bfa  jmp 0x00007EC68BFD2FBF
00007ec68bfd5bff  sub rsp, 0x08
00007ec68bfd5c03  push rax
00007ec68bfd5c04  push rcx
00007ec68bfd5c05  push rdx
00007ec68bfd5c06  push rdi
00007ec68bfd5c07  push rsi
00007ec68bfd5c08  push r8
00007ec68bfd5c0a  push r9
00007ec68bfd5c0c  push r10
00007ec68bfd5c0e  push r11
00007ec68bfd5c10  sub rsp, 0xF0
00007ec68bfd5c17  vmovaps [rsp], xmm0
00007ec68bfd5c1c  vmovaps [rsp+0x10], xmm2
00007ec68bfd5c22  vmovaps [rsp+0x20], xmm3
00007ec68bfd5c28  vmovaps [rsp+0x30], xmm4
00007ec68bfd5c2e  vmovaps [rsp+0x40], xmm5
00007ec68bfd5c34  vmovaps [rsp+0x50], xmm6
00007ec68bfd5c3a  vmovaps [rsp+0x60], xmm7
00007ec68bfd5c40  vmovaps [rsp+0x70], xmm8
00007ec68bfd5c46  vmovaps [rsp+0x80], xmm9
00007ec68bfd5c4f  vmovaps [rsp+0x90], xmm10
00007ec68bfd5c58  vmovaps [rsp+0xA0], xmm11
00007ec68bfd5c61  vmovaps [rsp+0xB0], xmm12
00007ec68bfd5c6a  vmovaps [rsp+0xC0], xmm13
00007ec68bfd5c73  vmovaps [rsp+0xD0], xmm14
00007ec68bfd5c7c  vmovaps [rsp+0xE0], xmm15
00007ec68bfd5c85  sub rsp, 0x30
00007ec68bfd5c89  movaps [rsp], xmm1
00007ec68bfd5c8d  movaps [rsp+0x10], xmm5
00007ec68bfd5c92  movaps [rsp+0x20], xmm13
00007ec68bfd5c98  lea rdi, [rsp]
00007ec68bfd5c9c  mov esi, 0x00
00007ec68bfd5ca1  mov rax, 0x57D97DADF530
00007ec68bfd5cab  call rax
00007ec68bfd5cad  movaps xmm1, [rsp]
00007ec68bfd5cb1  add rsp, 0x30
00007ec68bfd5cb5  vmovaps xmm0, [rsp]
00007ec68bfd5cba  vmovaps xmm2, [rsp+0x10]
00007ec68bfd5cc0  vmovaps xmm3, [rsp+0x20]
00007ec68bfd5cc6  vmovaps xmm4, [rsp+0x30]
00007ec68bfd5ccc  vmovaps xmm5, [rsp+0x40]
00007ec68bfd5cd2  vmovaps xmm6, [rsp+0x50]
00007ec68bfd5cd8  vmovaps xmm7, [rsp+0x60]
00007ec68bfd5cde  vmovaps xmm8, [rsp+0x70]
00007ec68bfd5ce4  vmovaps xmm9, [rsp+0x80]
00007ec68bfd5ced  vmovaps xmm10, [rsp+0x90]
00007ec68bfd5cf6  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd5cff  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd5d08  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd5d11  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd5d1a  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd5d23  add rsp, 0xF0
00007ec68bfd5d2a  pop r11
00007ec68bfd5d2c  pop r10
00007ec68bfd5d2e  pop r9
00007ec68bfd5d30  pop r8
00007ec68bfd5d32  pop rsi
00007ec68bfd5d33  pop rdi
00007ec68bfd5d34  pop rdx
00007ec68bfd5d35  pop rcx
00007ec68bfd5d36  pop rax
00007ec68bfd5d37  add rsp, 0x08
00007ec68bfd5d3b  jmp 0x00007EC68BFD2FDD
00007ec68bfd5d40  sub rsp, 0x08
00007ec68bfd5d44  push rax
00007ec68bfd5d45  push rcx
00007ec68bfd5d46  push rdx
00007ec68bfd5d47  push rdi
00007ec68bfd5d48  push rsi
00007ec68bfd5d49  push r8
00007ec68bfd5d4b  push r9
00007ec68bfd5d4d  push r10
00007ec68bfd5d4f  push r11
00007ec68bfd5d51  sub rsp, 0xF0
00007ec68bfd5d58  vmovaps [rsp], xmm0
00007ec68bfd5d5d  vmovaps [rsp+0x10], xmm1
00007ec68bfd5d63  vmovaps [rsp+0x20], xmm2
00007ec68bfd5d69  vmovaps [rsp+0x30], xmm3
00007ec68bfd5d6f  vmovaps [rsp+0x40], xmm4
00007ec68bfd5d75  vmovaps [rsp+0x50], xmm6
00007ec68bfd5d7b  vmovaps [rsp+0x60], xmm7
00007ec68bfd5d81  vmovaps [rsp+0x70], xmm8
00007ec68bfd5d87  vmovaps [rsp+0x80], xmm9
00007ec68bfd5d90  vmovaps [rsp+0x90], xmm10
00007ec68bfd5d99  vmovaps [rsp+0xA0], xmm11
00007ec68bfd5da2  vmovaps [rsp+0xB0], xmm12
00007ec68bfd5dab  vmovaps [rsp+0xC0], xmm13
00007ec68bfd5db4  vmovaps [rsp+0xD0], xmm14
00007ec68bfd5dbd  vmovaps [rsp+0xE0], xmm15
00007ec68bfd5dc6  sub rsp, 0x30
00007ec68bfd5dca  movaps [rsp], xmm5
00007ec68bfd5dce  movaps [rsp+0x10], xmm2
00007ec68bfd5dd3  movaps [rsp+0x20], xmm13
00007ec68bfd5dd9  lea rdi, [rsp]
00007ec68bfd5ddd  mov esi, 0x00
00007ec68bfd5de2  mov rax, 0x57D97DADF530
00007ec68bfd5dec  call rax
00007ec68bfd5dee  movaps xmm5, [rsp]
00007ec68bfd5df2  add rsp, 0x30
00007ec68bfd5df6  vmovaps xmm0, [rsp]
00007ec68bfd5dfb  vmovaps xmm1, [rsp+0x10]
00007ec68bfd5e01  vmovaps xmm2, [rsp+0x20]
00007ec68bfd5e07  vmovaps xmm3, [rsp+0x30]
00007ec68bfd5e0d  vmovaps xmm4, [rsp+0x40]
00007ec68bfd5e13  vmovaps xmm6, [rsp+0x50]
00007ec68bfd5e19  vmovaps xmm7, [rsp+0x60]
00007ec68bfd5e1f  vmovaps xmm8, [rsp+0x70]
00007ec68bfd5e25  vmovaps xmm9, [rsp+0x80]
00007ec68bfd5e2e  vmovaps xmm10, [rsp+0x90]
00007ec68bfd5e37  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd5e40  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd5e49  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd5e52  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd5e5b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd5e64  add rsp, 0xF0
00007ec68bfd5e6b  pop r11
00007ec68bfd5e6d  pop r10
00007ec68bfd5e6f  pop r9
00007ec68bfd5e71  pop r8
00007ec68bfd5e73  pop rsi
00007ec68bfd5e74  pop rdi
00007ec68bfd5e75  pop rdx
00007ec68bfd5e76  pop rcx
00007ec68bfd5e77  pop rax
00007ec68bfd5e78  add rsp, 0x08
00007ec68bfd5e7c  jmp 0x00007EC68BFD3013
00007ec68bfd5e81  sub rsp, 0x08
00007ec68bfd5e85  push rax
00007ec68bfd5e86  push rcx
00007ec68bfd5e87  push rdx
00007ec68bfd5e88  push rdi
00007ec68bfd5e89  push rsi
00007ec68bfd5e8a  push r8
00007ec68bfd5e8c  push r9
00007ec68bfd5e8e  push r10
00007ec68bfd5e90  push r11
00007ec68bfd5e92  sub rsp, 0xF0
00007ec68bfd5e99  vmovaps [rsp], xmm0
00007ec68bfd5e9e  vmovaps [rsp+0x10], xmm1
00007ec68bfd5ea4  vmovaps [rsp+0x20], xmm2
00007ec68bfd5eaa  vmovaps [rsp+0x30], xmm3
00007ec68bfd5eb0  vmovaps [rsp+0x40], xmm4
00007ec68bfd5eb6  vmovaps [rsp+0x50], xmm5
00007ec68bfd5ebc  vmovaps [rsp+0x60], xmm6
00007ec68bfd5ec2  vmovaps [rsp+0x70], xmm7
00007ec68bfd5ec8  vmovaps [rsp+0x80], xmm8
00007ec68bfd5ed1  vmovaps [rsp+0x90], xmm9
00007ec68bfd5eda  vmovaps [rsp+0xA0], xmm10
00007ec68bfd5ee3  vmovaps [rsp+0xB0], xmm11
00007ec68bfd5eec  vmovaps [rsp+0xC0], xmm12
00007ec68bfd5ef5  vmovaps [rsp+0xD0], xmm14
00007ec68bfd5efe  vmovaps [rsp+0xE0], xmm15
00007ec68bfd5f07  sub rsp, 0x30
00007ec68bfd5f0b  movaps [rsp], xmm13
00007ec68bfd5f10  movaps [rsp+0x10], xmm10
00007ec68bfd5f16  movaps [rsp+0x20], xmm1
00007ec68bfd5f1b  lea rdi, [rsp]
00007ec68bfd5f1f  mov esi, 0x00
00007ec68bfd5f24  mov rax, 0x57D97DADF530
00007ec68bfd5f2e  call rax
00007ec68bfd5f30  movaps xmm13, [rsp]
00007ec68bfd5f35  add rsp, 0x30
00007ec68bfd5f39  vmovaps xmm0, [rsp]
00007ec68bfd5f3e  vmovaps xmm1, [rsp+0x10]
00007ec68bfd5f44  vmovaps xmm2, [rsp+0x20]
00007ec68bfd5f4a  vmovaps xmm3, [rsp+0x30]
00007ec68bfd5f50  vmovaps xmm4, [rsp+0x40]
00007ec68bfd5f56  vmovaps xmm5, [rsp+0x50]
00007ec68bfd5f5c  vmovaps xmm6, [rsp+0x60]
00007ec68bfd5f62  vmovaps xmm7, [rsp+0x70]
00007ec68bfd5f68  vmovaps xmm8, [rsp+0x80]
00007ec68bfd5f71  vmovaps xmm9, [rsp+0x90]
00007ec68bfd5f7a  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd5f83  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd5f8c  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd5f95  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd5f9e  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd5fa7  add rsp, 0xF0
00007ec68bfd5fae  pop r11
00007ec68bfd5fb0  pop r10
00007ec68bfd5fb2  pop r9
00007ec68bfd5fb4  pop r8
00007ec68bfd5fb6  pop rsi
00007ec68bfd5fb7  pop rdi
00007ec68bfd5fb8  pop rdx
00007ec68bfd5fb9  pop rcx
00007ec68bfd5fba  pop rax
00007ec68bfd5fbb  add rsp, 0x08
00007ec68bfd5fbf  jmp 0x00007EC68BFD303C
00007ec68bfd5fc4  sub rsp, 0x08
00007ec68bfd5fc8  push rax
00007ec68bfd5fc9  push rcx
00007ec68bfd5fca  push rdx
00007ec68bfd5fcb  push rdi
00007ec68bfd5fcc  push rsi
00007ec68bfd5fcd  push r8
00007ec68bfd5fcf  push r9
00007ec68bfd5fd1  push r10
00007ec68bfd5fd3  push r11
00007ec68bfd5fd5  sub rsp, 0xF0
00007ec68bfd5fdc  vmovaps [rsp], xmm0
00007ec68bfd5fe1  vmovaps [rsp+0x10], xmm2
00007ec68bfd5fe7  vmovaps [rsp+0x20], xmm3
00007ec68bfd5fed  vmovaps [rsp+0x30], xmm4
00007ec68bfd5ff3  vmovaps [rsp+0x40], xmm5
00007ec68bfd5ff9  vmovaps [rsp+0x50], xmm6
00007ec68bfd5fff  vmovaps [rsp+0x60], xmm7
00007ec68bfd6005  vmovaps [rsp+0x70], xmm8
00007ec68bfd600b  vmovaps [rsp+0x80], xmm9
00007ec68bfd6014  vmovaps [rsp+0x90], xmm10
00007ec68bfd601d  vmovaps [rsp+0xA0], xmm11
00007ec68bfd6026  vmovaps [rsp+0xB0], xmm12
00007ec68bfd602f  vmovaps [rsp+0xC0], xmm13
00007ec68bfd6038  vmovaps [rsp+0xD0], xmm14
00007ec68bfd6041  vmovaps [rsp+0xE0], xmm15
00007ec68bfd604a  sub rsp, 0x30
00007ec68bfd604e  movaps [rsp], xmm1
00007ec68bfd6052  movaps [rsp+0x10], xmm15
00007ec68bfd6058  movaps [rsp+0x20], xmm10
00007ec68bfd605e  lea rdi, [rsp]
00007ec68bfd6062  mov esi, 0x00
00007ec68bfd6067  mov rax, 0x57D97DADF530
00007ec68bfd6071  call rax
00007ec68bfd6073  movaps xmm1, [rsp]
00007ec68bfd6077  add rsp, 0x30
00007ec68bfd607b  vmovaps xmm0, [rsp]
00007ec68bfd6080  vmovaps xmm2, [rsp+0x10]
00007ec68bfd6086  vmovaps xmm3, [rsp+0x20]
00007ec68bfd608c  vmovaps xmm4, [rsp+0x30]
00007ec68bfd6092  vmovaps xmm5, [rsp+0x40]
00007ec68bfd6098  vmovaps xmm6, [rsp+0x50]
00007ec68bfd609e  vmovaps xmm7, [rsp+0x60]
00007ec68bfd60a4  vmovaps xmm8, [rsp+0x70]
00007ec68bfd60aa  vmovaps xmm9, [rsp+0x80]
00007ec68bfd60b3  vmovaps xmm10, [rsp+0x90]
00007ec68bfd60bc  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd60c5  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd60ce  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd60d7  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd60e0  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd60e9  add rsp, 0xF0
00007ec68bfd60f0  pop r11
00007ec68bfd60f2  pop r10
00007ec68bfd60f4  pop r9
00007ec68bfd60f6  pop r8
00007ec68bfd60f8  pop rsi
00007ec68bfd60f9  pop rdi
00007ec68bfd60fa  pop rdx
00007ec68bfd60fb  pop rcx
00007ec68bfd60fc  pop rax
00007ec68bfd60fd  add rsp, 0x08
00007ec68bfd6101  jmp 0x00007EC68BFD305B
00007ec68bfd6106  sub rsp, 0x08
00007ec68bfd610a  push rax
00007ec68bfd610b  push rcx
00007ec68bfd610c  push rdx
00007ec68bfd610d  push rdi
00007ec68bfd610e  push rsi
00007ec68bfd610f  push r8
00007ec68bfd6111  push r9
00007ec68bfd6113  push r10
00007ec68bfd6115  push r11
00007ec68bfd6117  sub rsp, 0xF0
00007ec68bfd611e  vmovaps [rsp], xmm0
00007ec68bfd6123  vmovaps [rsp+0x10], xmm1
00007ec68bfd6129  vmovaps [rsp+0x20], xmm2
00007ec68bfd612f  vmovaps [rsp+0x30], xmm3
00007ec68bfd6135  vmovaps [rsp+0x40], xmm4
00007ec68bfd613b  vmovaps [rsp+0x50], xmm5
00007ec68bfd6141  vmovaps [rsp+0x60], xmm6
00007ec68bfd6147  vmovaps [rsp+0x70], xmm7
00007ec68bfd614d  vmovaps [rsp+0x80], xmm8
00007ec68bfd6156  vmovaps [rsp+0x90], xmm9
00007ec68bfd615f  vmovaps [rsp+0xA0], xmm10
00007ec68bfd6168  vmovaps [rsp+0xB0], xmm11
00007ec68bfd6171  vmovaps [rsp+0xC0], xmm12
00007ec68bfd617a  vmovaps [rsp+0xD0], xmm13
00007ec68bfd6183  vmovaps [rsp+0xE0], xmm14
00007ec68bfd618c  sub rsp, 0x30
00007ec68bfd6190  movaps [rsp], xmm15
00007ec68bfd6195  movaps [rsp+0x10], xmm10
00007ec68bfd619b  movaps [rsp+0x20], xmm11
00007ec68bfd61a1  lea rdi, [rsp]
00007ec68bfd61a5  mov esi, 0x00
00007ec68bfd61aa  mov rax, 0x57D97DADF530
00007ec68bfd61b4  call rax
00007ec68bfd61b6  movaps xmm15, [rsp]
00007ec68bfd61bb  add rsp, 0x30
00007ec68bfd61bf  vmovaps xmm0, [rsp]
00007ec68bfd61c4  vmovaps xmm1, [rsp+0x10]
00007ec68bfd61ca  vmovaps xmm2, [rsp+0x20]
00007ec68bfd61d0  vmovaps xmm3, [rsp+0x30]
00007ec68bfd61d6  vmovaps xmm4, [rsp+0x40]
00007ec68bfd61dc  vmovaps xmm5, [rsp+0x50]
00007ec68bfd61e2  vmovaps xmm6, [rsp+0x60]
00007ec68bfd61e8  vmovaps xmm7, [rsp+0x70]
00007ec68bfd61ee  vmovaps xmm8, [rsp+0x80]
00007ec68bfd61f7  vmovaps xmm9, [rsp+0x90]
00007ec68bfd6200  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd6209  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd6212  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd621b  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd6224  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd622d  add rsp, 0xF0
00007ec68bfd6234  pop r11
00007ec68bfd6236  pop r10
00007ec68bfd6238  pop r9
00007ec68bfd623a  pop r8
00007ec68bfd623c  pop rsi
00007ec68bfd623d  pop rdi
00007ec68bfd623e  pop rdx
00007ec68bfd623f  pop rcx
00007ec68bfd6240  pop rax
00007ec68bfd6241  add rsp, 0x08
00007ec68bfd6245  jmp 0x00007EC68BFD307E
00007ec68bfd624a  sub rsp, 0x08
00007ec68bfd624e  push rax
00007ec68bfd624f  push rcx
00007ec68bfd6250  push rdx
00007ec68bfd6251  push rdi
00007ec68bfd6252  push rsi
00007ec68bfd6253  push r8
00007ec68bfd6255  push r9
00007ec68bfd6257  push r10
00007ec68bfd6259  push r11
00007ec68bfd625b  sub rsp, 0xF0
00007ec68bfd6262  vmovaps [rsp], xmm0
00007ec68bfd6267  vmovaps [rsp+0x10], xmm1
00007ec68bfd626d  vmovaps [rsp+0x20], xmm2
00007ec68bfd6273  vmovaps [rsp+0x30], xmm3
00007ec68bfd6279  vmovaps [rsp+0x40], xmm4
00007ec68bfd627f  vmovaps [rsp+0x50], xmm5
00007ec68bfd6285  vmovaps [rsp+0x60], xmm6
00007ec68bfd628b  vmovaps [rsp+0x70], xmm7
00007ec68bfd6291  vmovaps [rsp+0x80], xmm8
00007ec68bfd629a  vmovaps [rsp+0x90], xmm9
00007ec68bfd62a3  vmovaps [rsp+0xA0], xmm11
00007ec68bfd62ac  vmovaps [rsp+0xB0], xmm12
00007ec68bfd62b5  vmovaps [rsp+0xC0], xmm13
00007ec68bfd62be  vmovaps [rsp+0xD0], xmm14
00007ec68bfd62c7  vmovaps [rsp+0xE0], xmm15
00007ec68bfd62d0  sub rsp, 0x30
00007ec68bfd62d4  movaps [rsp], xmm10
00007ec68bfd62d9  movaps [rsp+0x10], xmm2
00007ec68bfd62de  movaps [rsp+0x20], xmm11
00007ec68bfd62e4  lea rdi, [rsp]
00007ec68bfd62e8  mov esi, 0x00
00007ec68bfd62ed  mov rax, 0x57D97DADF530
00007ec68bfd62f7  call rax
00007ec68bfd62f9  movaps xmm10, [rsp]
00007ec68bfd62fe  add rsp, 0x30
00007ec68bfd6302  vmovaps xmm0, [rsp]
00007ec68bfd6307  vmovaps xmm1, [rsp+0x10]
00007ec68bfd630d  vmovaps xmm2, [rsp+0x20]
00007ec68bfd6313  vmovaps xmm3, [rsp+0x30]
00007ec68bfd6319  vmovaps xmm4, [rsp+0x40]
00007ec68bfd631f  vmovaps xmm5, [rsp+0x50]
00007ec68bfd6325  vmovaps xmm6, [rsp+0x60]
00007ec68bfd632b  vmovaps xmm7, [rsp+0x70]
00007ec68bfd6331  vmovaps xmm8, [rsp+0x80]
00007ec68bfd633a  vmovaps xmm9, [rsp+0x90]
00007ec68bfd6343  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd634c  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd6355  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd635e  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd6367  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd6370  add rsp, 0xF0
00007ec68bfd6377  pop r11
00007ec68bfd6379  pop r10
00007ec68bfd637b  pop r9
00007ec68bfd637d  pop r8
00007ec68bfd637f  pop rsi
00007ec68bfd6380  pop rdi
00007ec68bfd6381  pop rdx
00007ec68bfd6382  pop rcx
00007ec68bfd6383  pop rax
00007ec68bfd6384  add rsp, 0x08
00007ec68bfd6388  jmp 0x00007EC68BFD30B6
00007ec68bfd638d  sub rsp, 0x08
00007ec68bfd6391  push rax
00007ec68bfd6392  push rcx
00007ec68bfd6393  push rdx
00007ec68bfd6394  push rdi
00007ec68bfd6395  push rsi
00007ec68bfd6396  push r8
00007ec68bfd6398  push r9
00007ec68bfd639a  push r10
00007ec68bfd639c  push r11
00007ec68bfd639e  sub rsp, 0xF0
00007ec68bfd63a5  vmovaps [rsp], xmm0
00007ec68bfd63aa  vmovaps [rsp+0x10], xmm1
00007ec68bfd63b0  vmovaps [rsp+0x20], xmm2
00007ec68bfd63b6  vmovaps [rsp+0x30], xmm3
00007ec68bfd63bc  vmovaps [rsp+0x40], xmm4
00007ec68bfd63c2  vmovaps [rsp+0x50], xmm5
00007ec68bfd63c8  vmovaps [rsp+0x60], xmm6
00007ec68bfd63ce  vmovaps [rsp+0x70], xmm7
00007ec68bfd63d4  vmovaps [rsp+0x80], xmm8
00007ec68bfd63dd  vmovaps [rsp+0x90], xmm9
00007ec68bfd63e6  vmovaps [rsp+0xA0], xmm10
00007ec68bfd63ef  vmovaps [rsp+0xB0], xmm12
00007ec68bfd63f8  vmovaps [rsp+0xC0], xmm13
00007ec68bfd6401  vmovaps [rsp+0xD0], xmm14
00007ec68bfd640a  vmovaps [rsp+0xE0], xmm15
00007ec68bfd6413  sub rsp, 0x30
00007ec68bfd6417  movaps [rsp], xmm11
00007ec68bfd641c  movaps [rsp+0x10], xmm2
00007ec68bfd6421  movaps [rsp+0x20], xmm1
00007ec68bfd6426  lea rdi, [rsp]
00007ec68bfd642a  mov esi, 0x00
00007ec68bfd642f  mov rax, 0x57D97DADF530
00007ec68bfd6439  call rax
00007ec68bfd643b  movaps xmm11, [rsp]
00007ec68bfd6440  add rsp, 0x30
00007ec68bfd6444  vmovaps xmm0, [rsp]
00007ec68bfd6449  vmovaps xmm1, [rsp+0x10]
00007ec68bfd644f  vmovaps xmm2, [rsp+0x20]
00007ec68bfd6455  vmovaps xmm3, [rsp+0x30]
00007ec68bfd645b  vmovaps xmm4, [rsp+0x40]
00007ec68bfd6461  vmovaps xmm5, [rsp+0x50]
00007ec68bfd6467  vmovaps xmm6, [rsp+0x60]
00007ec68bfd646d  vmovaps xmm7, [rsp+0x70]
00007ec68bfd6473  vmovaps xmm8, [rsp+0x80]
00007ec68bfd647c  vmovaps xmm9, [rsp+0x90]
00007ec68bfd6485  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd648e  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd6497  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd64a0  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd64a9  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd64b2  add rsp, 0xF0
00007ec68bfd64b9  pop r11
00007ec68bfd64bb  pop r10
00007ec68bfd64bd  pop r9
00007ec68bfd64bf  pop r8
00007ec68bfd64c1  pop rsi
00007ec68bfd64c2  pop rdi
00007ec68bfd64c3  pop rdx
00007ec68bfd64c4  pop rcx
00007ec68bfd64c5  pop rax
00007ec68bfd64c6  add rsp, 0x08
00007ec68bfd64ca  jmp 0x00007EC68BFD30F2
00007ec68bfd64cf  sub rsp, 0x08
00007ec68bfd64d3  push rax
00007ec68bfd64d4  push rcx
00007ec68bfd64d5  push rdx
00007ec68bfd64d6  push rdi
00007ec68bfd64d7  push rsi
00007ec68bfd64d8  push r8
00007ec68bfd64da  push r9
00007ec68bfd64dc  push r10
00007ec68bfd64de  push r11
00007ec68bfd64e0  sub rsp, 0xF0
00007ec68bfd64e7  vmovaps [rsp], xmm0
00007ec68bfd64ec  vmovaps [rsp+0x10], xmm2
00007ec68bfd64f2  vmovaps [rsp+0x20], xmm3
00007ec68bfd64f8  vmovaps [rsp+0x30], xmm4
00007ec68bfd64fe  vmovaps [rsp+0x40], xmm5
00007ec68bfd6504  vmovaps [rsp+0x50], xmm6
00007ec68bfd650a  vmovaps [rsp+0x60], xmm7
00007ec68bfd6510  vmovaps [rsp+0x70], xmm8
00007ec68bfd6516  vmovaps [rsp+0x80], xmm9
00007ec68bfd651f  vmovaps [rsp+0x90], xmm10
00007ec68bfd6528  vmovaps [rsp+0xA0], xmm11
00007ec68bfd6531  vmovaps [rsp+0xB0], xmm12
00007ec68bfd653a  vmovaps [rsp+0xC0], xmm13
00007ec68bfd6543  vmovaps [rsp+0xD0], xmm14
00007ec68bfd654c  vmovaps [rsp+0xE0], xmm15
00007ec68bfd6555  sub rsp, 0x30
00007ec68bfd6559  movaps [rsp], xmm1
00007ec68bfd655d  movaps [rsp+0x10], xmm14
00007ec68bfd6563  movaps [rsp+0x20], xmm6
00007ec68bfd6568  lea rdi, [rsp]
00007ec68bfd656c  mov esi, 0x00
00007ec68bfd6571  mov rax, 0x57D97DADF530
00007ec68bfd657b  call rax
00007ec68bfd657d  movaps xmm1, [rsp]
00007ec68bfd6581  add rsp, 0x30
00007ec68bfd6585  vmovaps xmm0, [rsp]
00007ec68bfd658a  vmovaps xmm2, [rsp+0x10]
00007ec68bfd6590  vmovaps xmm3, [rsp+0x20]
00007ec68bfd6596  vmovaps xmm4, [rsp+0x30]
00007ec68bfd659c  vmovaps xmm5, [rsp+0x40]
00007ec68bfd65a2  vmovaps xmm6, [rsp+0x50]
00007ec68bfd65a8  vmovaps xmm7, [rsp+0x60]
00007ec68bfd65ae  vmovaps xmm8, [rsp+0x70]
00007ec68bfd65b4  vmovaps xmm9, [rsp+0x80]
00007ec68bfd65bd  vmovaps xmm10, [rsp+0x90]
00007ec68bfd65c6  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd65cf  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd65d8  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd65e1  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd65ea  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd65f3  add rsp, 0xF0
00007ec68bfd65fa  pop r11
00007ec68bfd65fc  pop r10
00007ec68bfd65fe  pop r9
00007ec68bfd6600  pop r8
00007ec68bfd6602  pop rsi
00007ec68bfd6603  pop rdi
00007ec68bfd6604  pop rdx
00007ec68bfd6605  pop rcx
00007ec68bfd6606  pop rax
00007ec68bfd6607  add rsp, 0x08
00007ec68bfd660b  jmp 0x00007EC68BFD310B
00007ec68bfd6610  sub rsp, 0x08
00007ec68bfd6614  push rax
00007ec68bfd6615  push rcx
00007ec68bfd6616  push rdx
00007ec68bfd6617  push rdi
00007ec68bfd6618  push rsi
00007ec68bfd6619  push r8
00007ec68bfd661b  push r9
00007ec68bfd661d  push r10
00007ec68bfd661f  push r11
00007ec68bfd6621  sub rsp, 0xF0
00007ec68bfd6628  vmovaps [rsp], xmm0
00007ec68bfd662d  vmovaps [rsp+0x10], xmm1
00007ec68bfd6633  vmovaps [rsp+0x20], xmm2
00007ec68bfd6639  vmovaps [rsp+0x30], xmm3
00007ec68bfd663f  vmovaps [rsp+0x40], xmm4
00007ec68bfd6645  vmovaps [rsp+0x50], xmm5
00007ec68bfd664b  vmovaps [rsp+0x60], xmm6
00007ec68bfd6651  vmovaps [rsp+0x70], xmm7
00007ec68bfd6657  vmovaps [rsp+0x80], xmm8
00007ec68bfd6660  vmovaps [rsp+0x90], xmm9
00007ec68bfd6669  vmovaps [rsp+0xA0], xmm10
00007ec68bfd6672  vmovaps [rsp+0xB0], xmm11
00007ec68bfd667b  vmovaps [rsp+0xC0], xmm12
00007ec68bfd6684  vmovaps [rsp+0xD0], xmm13
00007ec68bfd668d  vmovaps [rsp+0xE0], xmm14
00007ec68bfd6696  sub rsp, 0x30
00007ec68bfd669a  movaps [rsp], xmm15
00007ec68bfd669f  movaps [rsp+0x10], xmm14
00007ec68bfd66a5  movaps [rsp+0x20], xmm5
00007ec68bfd66aa  lea rdi, [rsp]
00007ec68bfd66ae  mov esi, 0x00
00007ec68bfd66b3  mov rax, 0x57D97DADF530
00007ec68bfd66bd  call rax
00007ec68bfd66bf  movaps xmm15, [rsp]
00007ec68bfd66c4  add rsp, 0x30
00007ec68bfd66c8  vmovaps xmm0, [rsp]
00007ec68bfd66cd  vmovaps xmm1, [rsp+0x10]
00007ec68bfd66d3  vmovaps xmm2, [rsp+0x20]
00007ec68bfd66d9  vmovaps xmm3, [rsp+0x30]
00007ec68bfd66df  vmovaps xmm4, [rsp+0x40]
00007ec68bfd66e5  vmovaps xmm5, [rsp+0x50]
00007ec68bfd66eb  vmovaps xmm6, [rsp+0x60]
00007ec68bfd66f1  vmovaps xmm7, [rsp+0x70]
00007ec68bfd66f7  vmovaps xmm8, [rsp+0x80]
00007ec68bfd6700  vmovaps xmm9, [rsp+0x90]
00007ec68bfd6709  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd6712  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd671b  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd6724  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd672d  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd6736  add rsp, 0xF0
00007ec68bfd673d  pop r11
00007ec68bfd673f  pop r10
00007ec68bfd6741  pop r9
00007ec68bfd6743  pop r8
00007ec68bfd6745  pop rsi
00007ec68bfd6746  pop rdi
00007ec68bfd6747  pop rdx
00007ec68bfd6748  pop rcx
00007ec68bfd6749  pop rax
00007ec68bfd674a  add rsp, 0x08
00007ec68bfd674e  jmp 0x00007EC68BFD312B
00007ec68bfd6753  sub rsp, 0x08
00007ec68bfd6757  push rax
00007ec68bfd6758  push rcx
00007ec68bfd6759  push rdx
00007ec68bfd675a  push rdi
00007ec68bfd675b  push rsi
00007ec68bfd675c  push r8
00007ec68bfd675e  push r9
00007ec68bfd6760  push r10
00007ec68bfd6762  push r11
00007ec68bfd6764  sub rsp, 0xF0
00007ec68bfd676b  vmovaps [rsp], xmm0
00007ec68bfd6770  vmovaps [rsp+0x10], xmm1
00007ec68bfd6776  vmovaps [rsp+0x20], xmm2
00007ec68bfd677c  vmovaps [rsp+0x30], xmm3
00007ec68bfd6782  vmovaps [rsp+0x40], xmm4
00007ec68bfd6788  vmovaps [rsp+0x50], xmm5
00007ec68bfd678e  vmovaps [rsp+0x60], xmm7
00007ec68bfd6794  vmovaps [rsp+0x70], xmm8
00007ec68bfd679a  vmovaps [rsp+0x80], xmm9
00007ec68bfd67a3  vmovaps [rsp+0x90], xmm10
00007ec68bfd67ac  vmovaps [rsp+0xA0], xmm11
00007ec68bfd67b5  vmovaps [rsp+0xB0], xmm12
00007ec68bfd67be  vmovaps [rsp+0xC0], xmm13
00007ec68bfd67c7  vmovaps [rsp+0xD0], xmm14
00007ec68bfd67d0  vmovaps [rsp+0xE0], xmm15
00007ec68bfd67d9  sub rsp, 0x30
00007ec68bfd67dd  movaps [rsp], xmm6
00007ec68bfd67e1  movaps [rsp+0x10], xmm9
00007ec68bfd67e7  movaps [rsp+0x20], xmm14
00007ec68bfd67ed  lea rdi, [rsp]
00007ec68bfd67f1  mov esi, 0x00
00007ec68bfd67f6  mov rax, 0x57D97DADF530
00007ec68bfd6800  call rax
00007ec68bfd6802  movaps xmm6, [rsp]
00007ec68bfd6806  add rsp, 0x30
00007ec68bfd680a  vmovaps xmm0, [rsp]
00007ec68bfd680f  vmovaps xmm1, [rsp+0x10]
00007ec68bfd6815  vmovaps xmm2, [rsp+0x20]
00007ec68bfd681b  vmovaps xmm3, [rsp+0x30]
00007ec68bfd6821  vmovaps xmm4, [rsp+0x40]
00007ec68bfd6827  vmovaps xmm5, [rsp+0x50]
00007ec68bfd682d  vmovaps xmm7, [rsp+0x60]
00007ec68bfd6833  vmovaps xmm8, [rsp+0x70]
00007ec68bfd6839  vmovaps xmm9, [rsp+0x80]
00007ec68bfd6842  vmovaps xmm10, [rsp+0x90]
00007ec68bfd684b  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd6854  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd685d  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd6866  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd686f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd6878  add rsp, 0xF0
00007ec68bfd687f  pop r11
00007ec68bfd6881  pop r10
00007ec68bfd6883  pop r9
00007ec68bfd6885  pop r8
00007ec68bfd6887  pop rsi
00007ec68bfd6888  pop rdi
00007ec68bfd6889  pop rdx
00007ec68bfd688a  pop rcx
00007ec68bfd688b  pop rax
00007ec68bfd688c  add rsp, 0x08
00007ec68bfd6890  jmp 0x00007EC68BFD3153
00007ec68bfd6895  sub rsp, 0x08
00007ec68bfd6899  push rax
00007ec68bfd689a  push rcx
00007ec68bfd689b  push rdx
00007ec68bfd689c  push rdi
00007ec68bfd689d  push rsi
00007ec68bfd689e  push r8
00007ec68bfd68a0  push r9
00007ec68bfd68a2  push r10
00007ec68bfd68a4  push r11
00007ec68bfd68a6  sub rsp, 0xF0
00007ec68bfd68ad  vmovaps [rsp], xmm0
00007ec68bfd68b2  vmovaps [rsp+0x10], xmm1
00007ec68bfd68b8  vmovaps [rsp+0x20], xmm2
00007ec68bfd68be  vmovaps [rsp+0x30], xmm3
00007ec68bfd68c4  vmovaps [rsp+0x40], xmm4
00007ec68bfd68ca  vmovaps [rsp+0x50], xmm5
00007ec68bfd68d0  vmovaps [rsp+0x60], xmm6
00007ec68bfd68d6  vmovaps [rsp+0x70], xmm7
00007ec68bfd68dc  vmovaps [rsp+0x80], xmm8
00007ec68bfd68e5  vmovaps [rsp+0x90], xmm9
00007ec68bfd68ee  vmovaps [rsp+0xA0], xmm10
00007ec68bfd68f7  vmovaps [rsp+0xB0], xmm11
00007ec68bfd6900  vmovaps [rsp+0xC0], xmm12
00007ec68bfd6909  vmovaps [rsp+0xD0], xmm13
00007ec68bfd6912  vmovaps [rsp+0xE0], xmm15
00007ec68bfd691b  sub rsp, 0x30
00007ec68bfd691f  movaps [rsp], xmm14
00007ec68bfd6924  movaps [rsp+0x10], xmm9
00007ec68bfd692a  movaps [rsp+0x20], xmm13
00007ec68bfd6930  lea rdi, [rsp]
00007ec68bfd6934  mov esi, 0x00
00007ec68bfd6939  mov rax, 0x57D97DADF530
00007ec68bfd6943  call rax
00007ec68bfd6945  movaps xmm14, [rsp]
00007ec68bfd694a  add rsp, 0x30
00007ec68bfd694e  vmovaps xmm0, [rsp]
00007ec68bfd6953  vmovaps xmm1, [rsp+0x10]
00007ec68bfd6959  vmovaps xmm2, [rsp+0x20]
00007ec68bfd695f  vmovaps xmm3, [rsp+0x30]
00007ec68bfd6965  vmovaps xmm4, [rsp+0x40]
00007ec68bfd696b  vmovaps xmm5, [rsp+0x50]
00007ec68bfd6971  vmovaps xmm6, [rsp+0x60]
00007ec68bfd6977  vmovaps xmm7, [rsp+0x70]
00007ec68bfd697d  vmovaps xmm8, [rsp+0x80]
00007ec68bfd6986  vmovaps xmm9, [rsp+0x90]
00007ec68bfd698f  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd6998  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd69a1  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd69aa  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd69b3  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd69bc  add rsp, 0xF0
00007ec68bfd69c3  pop r11
00007ec68bfd69c5  pop r10
00007ec68bfd69c7  pop r9
00007ec68bfd69c9  pop r8
00007ec68bfd69cb  pop rsi
00007ec68bfd69cc  pop rdi
00007ec68bfd69cd  pop rdx
00007ec68bfd69ce  pop rcx
00007ec68bfd69cf  pop rax
00007ec68bfd69d0  add rsp, 0x08
00007ec68bfd69d4  jmp 0x00007EC68BFD3176
00007ec68bfd69d9  sub rsp, 0x08
00007ec68bfd69dd  push rax
00007ec68bfd69de  push rcx
00007ec68bfd69df  push rdx
00007ec68bfd69e0  push rdi
00007ec68bfd69e1  push rsi
00007ec68bfd69e2  push r8
00007ec68bfd69e4  push r9
00007ec68bfd69e6  push r10
00007ec68bfd69e8  push r11
00007ec68bfd69ea  sub rsp, 0xF0
00007ec68bfd69f1  vmovaps [rsp], xmm0
00007ec68bfd69f6  vmovaps [rsp+0x10], xmm1
00007ec68bfd69fc  vmovaps [rsp+0x20], xmm2
00007ec68bfd6a02  vmovaps [rsp+0x30], xmm3
00007ec68bfd6a08  vmovaps [rsp+0x40], xmm4
00007ec68bfd6a0e  vmovaps [rsp+0x50], xmm5
00007ec68bfd6a14  vmovaps [rsp+0x60], xmm6
00007ec68bfd6a1a  vmovaps [rsp+0x70], xmm7
00007ec68bfd6a20  vmovaps [rsp+0x80], xmm8
00007ec68bfd6a29  vmovaps [rsp+0x90], xmm9
00007ec68bfd6a32  vmovaps [rsp+0xA0], xmm10
00007ec68bfd6a3b  vmovaps [rsp+0xB0], xmm11
00007ec68bfd6a44  vmovaps [rsp+0xC0], xmm12
00007ec68bfd6a4d  vmovaps [rsp+0xD0], xmm14
00007ec68bfd6a56  vmovaps [rsp+0xE0], xmm15
00007ec68bfd6a5f  sub rsp, 0x30
00007ec68bfd6a63  movaps [rsp], xmm13
00007ec68bfd6a68  movaps [rsp+0x10], xmm9
00007ec68bfd6a6e  movaps [rsp+0x20], xmm10
00007ec68bfd6a74  lea rdi, [rsp]
00007ec68bfd6a78  mov esi, 0x00
00007ec68bfd6a7d  mov rax, 0x57D97DADF530
00007ec68bfd6a87  call rax
00007ec68bfd6a89  movaps xmm13, [rsp]
00007ec68bfd6a8e  add rsp, 0x30
00007ec68bfd6a92  vmovaps xmm0, [rsp]
00007ec68bfd6a97  vmovaps xmm1, [rsp+0x10]
00007ec68bfd6a9d  vmovaps xmm2, [rsp+0x20]
00007ec68bfd6aa3  vmovaps xmm3, [rsp+0x30]
00007ec68bfd6aa9  vmovaps xmm4, [rsp+0x40]
00007ec68bfd6aaf  vmovaps xmm5, [rsp+0x50]
00007ec68bfd6ab5  vmovaps xmm6, [rsp+0x60]
00007ec68bfd6abb  vmovaps xmm7, [rsp+0x70]
00007ec68bfd6ac1  vmovaps xmm8, [rsp+0x80]
00007ec68bfd6aca  vmovaps xmm9, [rsp+0x90]
00007ec68bfd6ad3  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd6adc  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd6ae5  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd6aee  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd6af7  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd6b00  add rsp, 0xF0
00007ec68bfd6b07  pop r11
00007ec68bfd6b09  pop r10
00007ec68bfd6b0b  pop r9
00007ec68bfd6b0d  pop r8
00007ec68bfd6b0f  pop rsi
00007ec68bfd6b10  pop rdi
00007ec68bfd6b11  pop rdx
00007ec68bfd6b12  pop rcx
00007ec68bfd6b13  pop rax
00007ec68bfd6b14  add rsp, 0x08
00007ec68bfd6b18  jmp 0x00007EC68BFD3196
00007ec68bfd6b1d  call 0x00007EC68BE0AFE0
00007ec68bfd6b22  jmp 0x00007EC68BFD31EB
00007ec68bfd6b27  sub rsp, 0x08
00007ec68bfd6b2b  push rax
00007ec68bfd6b2c  push rcx
00007ec68bfd6b2d  push rdx
00007ec68bfd6b2e  push rdi
00007ec68bfd6b2f  push rsi
00007ec68bfd6b30  push r8
00007ec68bfd6b32  push r9
00007ec68bfd6b34  push r10
00007ec68bfd6b36  push r11
00007ec68bfd6b38  sub rsp, 0xF0
00007ec68bfd6b3f  vmovaps [rsp], xmm0
00007ec68bfd6b44  vmovaps [rsp+0x10], xmm1
00007ec68bfd6b4a  vmovaps [rsp+0x20], xmm2
00007ec68bfd6b50  vmovaps [rsp+0x30], xmm3
00007ec68bfd6b56  vmovaps [rsp+0x40], xmm4
00007ec68bfd6b5c  vmovaps [rsp+0x50], xmm5
00007ec68bfd6b62  vmovaps [rsp+0x60], xmm6
00007ec68bfd6b68  vmovaps [rsp+0x70], xmm7
00007ec68bfd6b6e  vmovaps [rsp+0x80], xmm8
00007ec68bfd6b77  vmovaps [rsp+0x90], xmm10
00007ec68bfd6b80  vmovaps [rsp+0xA0], xmm11
00007ec68bfd6b89  vmovaps [rsp+0xB0], xmm12
00007ec68bfd6b92  vmovaps [rsp+0xC0], xmm13
00007ec68bfd6b9b  vmovaps [rsp+0xD0], xmm14
00007ec68bfd6ba4  vmovaps [rsp+0xE0], xmm15
00007ec68bfd6bad  sub rsp, 0x30
00007ec68bfd6bb1  movaps [rsp], xmm9
00007ec68bfd6bb6  movaps [rsp+0x10], xmm8
00007ec68bfd6bbc  movaps [rsp+0x20], xmm10
00007ec68bfd6bc2  lea rdi, [rsp]
00007ec68bfd6bc6  mov esi, 0x00
00007ec68bfd6bcb  mov rax, 0x57D97DADF530
00007ec68bfd6bd5  call rax
00007ec68bfd6bd7  movaps xmm9, [rsp]
00007ec68bfd6bdc  add rsp, 0x30
00007ec68bfd6be0  vmovaps xmm0, [rsp]
00007ec68bfd6be5  vmovaps xmm1, [rsp+0x10]
00007ec68bfd6beb  vmovaps xmm2, [rsp+0x20]
00007ec68bfd6bf1  vmovaps xmm3, [rsp+0x30]
00007ec68bfd6bf7  vmovaps xmm4, [rsp+0x40]
00007ec68bfd6bfd  vmovaps xmm5, [rsp+0x50]
00007ec68bfd6c03  vmovaps xmm6, [rsp+0x60]
00007ec68bfd6c09  vmovaps xmm7, [rsp+0x70]
00007ec68bfd6c0f  vmovaps xmm8, [rsp+0x80]
00007ec68bfd6c18  vmovaps xmm10, [rsp+0x90]
00007ec68bfd6c21  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd6c2a  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd6c33  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd6c3c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd6c45  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd6c4e  add rsp, 0xF0
00007ec68bfd6c55  pop r11
00007ec68bfd6c57  pop r10
00007ec68bfd6c59  pop r9
00007ec68bfd6c5b  pop r8
00007ec68bfd6c5d  pop rsi
00007ec68bfd6c5e  pop rdi
00007ec68bfd6c5f  pop rdx
00007ec68bfd6c60  pop rcx
00007ec68bfd6c61  pop rax
00007ec68bfd6c62  add rsp, 0x08
00007ec68bfd6c66  jmp 0x00007EC68BFD321C
00007ec68bfd6c6b  sub rsp, 0x08
00007ec68bfd6c6f  push rax
00007ec68bfd6c70  push rcx
00007ec68bfd6c71  push rdx
00007ec68bfd6c72  push rdi
00007ec68bfd6c73  push rsi
00007ec68bfd6c74  push r8
00007ec68bfd6c76  push r9
00007ec68bfd6c78  push r10
00007ec68bfd6c7a  push r11
00007ec68bfd6c7c  sub rsp, 0xF0
00007ec68bfd6c83  vmovaps [rsp], xmm0
00007ec68bfd6c88  vmovaps [rsp+0x10], xmm1
00007ec68bfd6c8e  vmovaps [rsp+0x20], xmm2
00007ec68bfd6c94  vmovaps [rsp+0x30], xmm3
00007ec68bfd6c9a  vmovaps [rsp+0x40], xmm4
00007ec68bfd6ca0  vmovaps [rsp+0x50], xmm5
00007ec68bfd6ca6  vmovaps [rsp+0x60], xmm6
00007ec68bfd6cac  vmovaps [rsp+0x70], xmm7
00007ec68bfd6cb2  vmovaps [rsp+0x80], xmm8
00007ec68bfd6cbb  vmovaps [rsp+0x90], xmm9
00007ec68bfd6cc4  vmovaps [rsp+0xA0], xmm11
00007ec68bfd6ccd  vmovaps [rsp+0xB0], xmm12
00007ec68bfd6cd6  vmovaps [rsp+0xC0], xmm13
00007ec68bfd6cdf  vmovaps [rsp+0xD0], xmm14
00007ec68bfd6ce8  vmovaps [rsp+0xE0], xmm15
00007ec68bfd6cf1  sub rsp, 0x30
00007ec68bfd6cf5  movaps [rsp], xmm10
00007ec68bfd6cfa  movaps [rsp+0x10], xmm1
00007ec68bfd6cff  movaps [rsp+0x20], xmm11
00007ec68bfd6d05  lea rdi, [rsp]
00007ec68bfd6d09  mov esi, 0x00
00007ec68bfd6d0e  mov rax, 0x57D97DADF530
00007ec68bfd6d18  call rax
00007ec68bfd6d1a  movaps xmm10, [rsp]
00007ec68bfd6d1f  add rsp, 0x30
00007ec68bfd6d23  vmovaps xmm0, [rsp]
00007ec68bfd6d28  vmovaps xmm1, [rsp+0x10]
00007ec68bfd6d2e  vmovaps xmm2, [rsp+0x20]
00007ec68bfd6d34  vmovaps xmm3, [rsp+0x30]
00007ec68bfd6d3a  vmovaps xmm4, [rsp+0x40]
00007ec68bfd6d40  vmovaps xmm5, [rsp+0x50]
00007ec68bfd6d46  vmovaps xmm6, [rsp+0x60]
00007ec68bfd6d4c  vmovaps xmm7, [rsp+0x70]
00007ec68bfd6d52  vmovaps xmm8, [rsp+0x80]
00007ec68bfd6d5b  vmovaps xmm9, [rsp+0x90]
00007ec68bfd6d64  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd6d6d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd6d76  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd6d7f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd6d88  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd6d91  add rsp, 0xF0
00007ec68bfd6d98  pop r11
00007ec68bfd6d9a  pop r10
00007ec68bfd6d9c  pop r9
00007ec68bfd6d9e  pop r8
00007ec68bfd6da0  pop rsi
00007ec68bfd6da1  pop rdi
00007ec68bfd6da2  pop rdx
00007ec68bfd6da3  pop rcx
00007ec68bfd6da4  pop rax
00007ec68bfd6da5  add rsp, 0x08
00007ec68bfd6da9  jmp 0x00007EC68BFD3237
00007ec68bfd6dae  sub rsp, 0x08
00007ec68bfd6db2  push rax
00007ec68bfd6db3  push rcx
00007ec68bfd6db4  push rdx
00007ec68bfd6db5  push rdi
00007ec68bfd6db6  push rsi
00007ec68bfd6db7  push r8
00007ec68bfd6db9  push r9
00007ec68bfd6dbb  push r10
00007ec68bfd6dbd  push r11
00007ec68bfd6dbf  sub rsp, 0xF0
00007ec68bfd6dc6  vmovaps [rsp], xmm0
00007ec68bfd6dcb  vmovaps [rsp+0x10], xmm2
00007ec68bfd6dd1  vmovaps [rsp+0x20], xmm3
00007ec68bfd6dd7  vmovaps [rsp+0x30], xmm4
00007ec68bfd6ddd  vmovaps [rsp+0x40], xmm5
00007ec68bfd6de3  vmovaps [rsp+0x50], xmm6
00007ec68bfd6de9  vmovaps [rsp+0x60], xmm7
00007ec68bfd6def  vmovaps [rsp+0x70], xmm8
00007ec68bfd6df5  vmovaps [rsp+0x80], xmm9
00007ec68bfd6dfe  vmovaps [rsp+0x90], xmm10
00007ec68bfd6e07  vmovaps [rsp+0xA0], xmm11
00007ec68bfd6e10  vmovaps [rsp+0xB0], xmm12
00007ec68bfd6e19  vmovaps [rsp+0xC0], xmm13
00007ec68bfd6e22  vmovaps [rsp+0xD0], xmm14
00007ec68bfd6e2b  vmovaps [rsp+0xE0], xmm15
00007ec68bfd6e34  sub rsp, 0x30
00007ec68bfd6e38  movaps [rsp], xmm1
00007ec68bfd6e3c  movaps [rsp+0x10], xmm15
00007ec68bfd6e42  movaps [rsp+0x20], xmm6
00007ec68bfd6e47  lea rdi, [rsp]
00007ec68bfd6e4b  mov esi, 0x00
00007ec68bfd6e50  mov rax, 0x57D97DADF530
00007ec68bfd6e5a  call rax
00007ec68bfd6e5c  movaps xmm1, [rsp]
00007ec68bfd6e60  add rsp, 0x30
00007ec68bfd6e64  vmovaps xmm0, [rsp]
00007ec68bfd6e69  vmovaps xmm2, [rsp+0x10]
00007ec68bfd6e6f  vmovaps xmm3, [rsp+0x20]
00007ec68bfd6e75  vmovaps xmm4, [rsp+0x30]
00007ec68bfd6e7b  vmovaps xmm5, [rsp+0x40]
00007ec68bfd6e81  vmovaps xmm6, [rsp+0x50]
00007ec68bfd6e87  vmovaps xmm7, [rsp+0x60]
00007ec68bfd6e8d  vmovaps xmm8, [rsp+0x70]
00007ec68bfd6e93  vmovaps xmm9, [rsp+0x80]
00007ec68bfd6e9c  vmovaps xmm10, [rsp+0x90]
00007ec68bfd6ea5  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd6eae  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd6eb7  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd6ec0  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd6ec9  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd6ed2  add rsp, 0xF0
00007ec68bfd6ed9  pop r11
00007ec68bfd6edb  pop r10
00007ec68bfd6edd  pop r9
00007ec68bfd6edf  pop r8
00007ec68bfd6ee1  pop rsi
00007ec68bfd6ee2  pop rdi
00007ec68bfd6ee3  pop rdx
00007ec68bfd6ee4  pop rcx
00007ec68bfd6ee5  pop rax
00007ec68bfd6ee6  add rsp, 0x08
00007ec68bfd6eea  jmp 0x00007EC68BFD3250
00007ec68bfd6eef  sub rsp, 0x08
00007ec68bfd6ef3  push rax
00007ec68bfd6ef4  push rcx
00007ec68bfd6ef5  push rdx
00007ec68bfd6ef6  push rdi
00007ec68bfd6ef7  push rsi
00007ec68bfd6ef8  push r8
00007ec68bfd6efa  push r9
00007ec68bfd6efc  push r10
00007ec68bfd6efe  push r11
00007ec68bfd6f00  sub rsp, 0xF0
00007ec68bfd6f07  vmovaps [rsp], xmm0
00007ec68bfd6f0c  vmovaps [rsp+0x10], xmm1
00007ec68bfd6f12  vmovaps [rsp+0x20], xmm2
00007ec68bfd6f18  vmovaps [rsp+0x30], xmm3
00007ec68bfd6f1e  vmovaps [rsp+0x40], xmm4
00007ec68bfd6f24  vmovaps [rsp+0x50], xmm5
00007ec68bfd6f2a  vmovaps [rsp+0x60], xmm6
00007ec68bfd6f30  vmovaps [rsp+0x70], xmm7
00007ec68bfd6f36  vmovaps [rsp+0x80], xmm8
00007ec68bfd6f3f  vmovaps [rsp+0x90], xmm9
00007ec68bfd6f48  vmovaps [rsp+0xA0], xmm10
00007ec68bfd6f51  vmovaps [rsp+0xB0], xmm12
00007ec68bfd6f5a  vmovaps [rsp+0xC0], xmm13
00007ec68bfd6f63  vmovaps [rsp+0xD0], xmm14
00007ec68bfd6f6c  vmovaps [rsp+0xE0], xmm15
00007ec68bfd6f75  sub rsp, 0x30
00007ec68bfd6f79  movaps [rsp], xmm11
00007ec68bfd6f7e  movaps [rsp+0x10], xmm12
00007ec68bfd6f84  movaps [rsp+0x20], xmm15
00007ec68bfd6f8a  lea rdi, [rsp]
00007ec68bfd6f8e  mov esi, 0x00
00007ec68bfd6f93  mov rax, 0x57D97DADF530
00007ec68bfd6f9d  call rax
00007ec68bfd6f9f  movaps xmm11, [rsp]
00007ec68bfd6fa4  add rsp, 0x30
00007ec68bfd6fa8  vmovaps xmm0, [rsp]
00007ec68bfd6fad  vmovaps xmm1, [rsp+0x10]
00007ec68bfd6fb3  vmovaps xmm2, [rsp+0x20]
00007ec68bfd6fb9  vmovaps xmm3, [rsp+0x30]
00007ec68bfd6fbf  vmovaps xmm4, [rsp+0x40]
00007ec68bfd6fc5  vmovaps xmm5, [rsp+0x50]
00007ec68bfd6fcb  vmovaps xmm6, [rsp+0x60]
00007ec68bfd6fd1  vmovaps xmm7, [rsp+0x70]
00007ec68bfd6fd7  vmovaps xmm8, [rsp+0x80]
00007ec68bfd6fe0  vmovaps xmm9, [rsp+0x90]
00007ec68bfd6fe9  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd6ff2  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd6ffb  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd7004  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd700d  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd7016  add rsp, 0xF0
00007ec68bfd701d  pop r11
00007ec68bfd701f  pop r10
00007ec68bfd7021  pop r9
00007ec68bfd7023  pop r8
00007ec68bfd7025  pop rsi
00007ec68bfd7026  pop rdi
00007ec68bfd7027  pop rdx
00007ec68bfd7028  pop rcx
00007ec68bfd7029  pop rax
00007ec68bfd702a  add rsp, 0x08
00007ec68bfd702e  jmp 0x00007EC68BFD327A
00007ec68bfd7033  sub rsp, 0x08
00007ec68bfd7037  push rax
00007ec68bfd7038  push rcx
00007ec68bfd7039  push rdx
00007ec68bfd703a  push rdi
00007ec68bfd703b  push rsi
00007ec68bfd703c  push r8
00007ec68bfd703e  push r9
00007ec68bfd7040  push r10
00007ec68bfd7042  push r11
00007ec68bfd7044  sub rsp, 0xF0
00007ec68bfd704b  vmovaps [rsp], xmm0
00007ec68bfd7050  vmovaps [rsp+0x10], xmm1
00007ec68bfd7056  vmovaps [rsp+0x20], xmm2
00007ec68bfd705c  vmovaps [rsp+0x30], xmm3
00007ec68bfd7062  vmovaps [rsp+0x40], xmm4
00007ec68bfd7068  vmovaps [rsp+0x50], xmm5
00007ec68bfd706e  vmovaps [rsp+0x60], xmm6
00007ec68bfd7074  vmovaps [rsp+0x70], xmm7
00007ec68bfd707a  vmovaps [rsp+0x80], xmm8
00007ec68bfd7083  vmovaps [rsp+0x90], xmm9
00007ec68bfd708c  vmovaps [rsp+0xA0], xmm10
00007ec68bfd7095  vmovaps [rsp+0xB0], xmm11
00007ec68bfd709e  vmovaps [rsp+0xC0], xmm13
00007ec68bfd70a7  vmovaps [rsp+0xD0], xmm14
00007ec68bfd70b0  vmovaps [rsp+0xE0], xmm15
00007ec68bfd70b9  sub rsp, 0x30
00007ec68bfd70bd  movaps [rsp], xmm12
00007ec68bfd70c2  movaps [rsp+0x10], xmm8
00007ec68bfd70c8  movaps [rsp+0x20], xmm15
00007ec68bfd70ce  lea rdi, [rsp]
00007ec68bfd70d2  mov esi, 0x00
00007ec68bfd70d7  mov rax, 0x57D97DADF530
00007ec68bfd70e1  call rax
00007ec68bfd70e3  movaps xmm12, [rsp]
00007ec68bfd70e8  add rsp, 0x30
00007ec68bfd70ec  vmovaps xmm0, [rsp]
00007ec68bfd70f1  vmovaps xmm1, [rsp+0x10]
00007ec68bfd70f7  vmovaps xmm2, [rsp+0x20]
00007ec68bfd70fd  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7103  vmovaps xmm4, [rsp+0x40]
00007ec68bfd7109  vmovaps xmm5, [rsp+0x50]
00007ec68bfd710f  vmovaps xmm6, [rsp+0x60]
00007ec68bfd7115  vmovaps xmm7, [rsp+0x70]
00007ec68bfd711b  vmovaps xmm8, [rsp+0x80]
00007ec68bfd7124  vmovaps xmm9, [rsp+0x90]
00007ec68bfd712d  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd7136  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd713f  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd7148  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd7151  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd715a  add rsp, 0xF0
00007ec68bfd7161  pop r11
00007ec68bfd7163  pop r10
00007ec68bfd7165  pop r9
00007ec68bfd7167  pop r8
00007ec68bfd7169  pop rsi
00007ec68bfd716a  pop rdi
00007ec68bfd716b  pop rdx
00007ec68bfd716c  pop rcx
00007ec68bfd716d  pop rax
00007ec68bfd716e  add rsp, 0x08
00007ec68bfd7172  jmp 0x00007EC68BFD32A9
00007ec68bfd7177  sub rsp, 0x08
00007ec68bfd717b  push rax
00007ec68bfd717c  push rcx
00007ec68bfd717d  push rdx
00007ec68bfd717e  push rdi
00007ec68bfd717f  push rsi
00007ec68bfd7180  push r8
00007ec68bfd7182  push r9
00007ec68bfd7184  push r10
00007ec68bfd7186  push r11
00007ec68bfd7188  sub rsp, 0xF0
00007ec68bfd718f  vmovaps [rsp], xmm0
00007ec68bfd7194  vmovaps [rsp+0x10], xmm1
00007ec68bfd719a  vmovaps [rsp+0x20], xmm2
00007ec68bfd71a0  vmovaps [rsp+0x30], xmm3
00007ec68bfd71a6  vmovaps [rsp+0x40], xmm4
00007ec68bfd71ac  vmovaps [rsp+0x50], xmm5
00007ec68bfd71b2  vmovaps [rsp+0x60], xmm6
00007ec68bfd71b8  vmovaps [rsp+0x70], xmm7
00007ec68bfd71be  vmovaps [rsp+0x80], xmm9
00007ec68bfd71c7  vmovaps [rsp+0x90], xmm10
00007ec68bfd71d0  vmovaps [rsp+0xA0], xmm11
00007ec68bfd71d9  vmovaps [rsp+0xB0], xmm12
00007ec68bfd71e2  vmovaps [rsp+0xC0], xmm13
00007ec68bfd71eb  vmovaps [rsp+0xD0], xmm14
00007ec68bfd71f4  vmovaps [rsp+0xE0], xmm15
00007ec68bfd71fd  sub rsp, 0x30
00007ec68bfd7201  movaps [rsp], xmm8
00007ec68bfd7206  movaps [rsp+0x10], xmm7
00007ec68bfd720b  movaps [rsp+0x20], xmm15
00007ec68bfd7211  lea rdi, [rsp]
00007ec68bfd7215  mov esi, 0x00
00007ec68bfd721a  mov rax, 0x57D97DADF530
00007ec68bfd7224  call rax
00007ec68bfd7226  movaps xmm8, [rsp]
00007ec68bfd722b  add rsp, 0x30
00007ec68bfd722f  vmovaps xmm0, [rsp]
00007ec68bfd7234  vmovaps xmm1, [rsp+0x10]
00007ec68bfd723a  vmovaps xmm2, [rsp+0x20]
00007ec68bfd7240  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7246  vmovaps xmm4, [rsp+0x40]
00007ec68bfd724c  vmovaps xmm5, [rsp+0x50]
00007ec68bfd7252  vmovaps xmm6, [rsp+0x60]
00007ec68bfd7258  vmovaps xmm7, [rsp+0x70]
00007ec68bfd725e  vmovaps xmm9, [rsp+0x80]
00007ec68bfd7267  vmovaps xmm10, [rsp+0x90]
00007ec68bfd7270  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd7279  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd7282  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd728b  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd7294  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd729d  add rsp, 0xF0
00007ec68bfd72a4  pop r11
00007ec68bfd72a6  pop r10
00007ec68bfd72a8  pop r9
00007ec68bfd72aa  pop r8
00007ec68bfd72ac  pop rsi
00007ec68bfd72ad  pop rdi
00007ec68bfd72ae  pop rdx
00007ec68bfd72af  pop rcx
00007ec68bfd72b0  pop rax
00007ec68bfd72b1  add rsp, 0x08
00007ec68bfd72b5  jmp 0x00007EC68BFD32CF
00007ec68bfd72ba  sub rsp, 0x08
00007ec68bfd72be  push rax
00007ec68bfd72bf  push rcx
00007ec68bfd72c0  push rdx
00007ec68bfd72c1  push rdi
00007ec68bfd72c2  push rsi
00007ec68bfd72c3  push r8
00007ec68bfd72c5  push r9
00007ec68bfd72c7  push r10
00007ec68bfd72c9  push r11
00007ec68bfd72cb  sub rsp, 0xF0
00007ec68bfd72d2  vmovaps [rsp], xmm0
00007ec68bfd72d7  vmovaps [rsp+0x10], xmm1
00007ec68bfd72dd  vmovaps [rsp+0x20], xmm2
00007ec68bfd72e3  vmovaps [rsp+0x30], xmm3
00007ec68bfd72e9  vmovaps [rsp+0x40], xmm4
00007ec68bfd72ef  vmovaps [rsp+0x50], xmm5
00007ec68bfd72f5  vmovaps [rsp+0x60], xmm6
00007ec68bfd72fb  vmovaps [rsp+0x70], xmm7
00007ec68bfd7301  vmovaps [rsp+0x80], xmm8
00007ec68bfd730a  vmovaps [rsp+0x90], xmm9
00007ec68bfd7313  vmovaps [rsp+0xA0], xmm10
00007ec68bfd731c  vmovaps [rsp+0xB0], xmm11
00007ec68bfd7325  vmovaps [rsp+0xC0], xmm12
00007ec68bfd732e  vmovaps [rsp+0xD0], xmm13
00007ec68bfd7337  vmovaps [rsp+0xE0], xmm14
00007ec68bfd7340  sub rsp, 0x30
00007ec68bfd7344  movaps [rsp], xmm15
00007ec68bfd7349  movaps [rsp+0x10], xmm14
00007ec68bfd734f  movaps [rsp+0x20], xmm9
00007ec68bfd7355  lea rdi, [rsp]
00007ec68bfd7359  mov esi, 0x00
00007ec68bfd735e  mov rax, 0x57D97DADF530
00007ec68bfd7368  call rax
00007ec68bfd736a  movaps xmm15, [rsp]
00007ec68bfd736f  add rsp, 0x30
00007ec68bfd7373  vmovaps xmm0, [rsp]
00007ec68bfd7378  vmovaps xmm1, [rsp+0x10]
00007ec68bfd737e  vmovaps xmm2, [rsp+0x20]
00007ec68bfd7384  vmovaps xmm3, [rsp+0x30]
00007ec68bfd738a  vmovaps xmm4, [rsp+0x40]
00007ec68bfd7390  vmovaps xmm5, [rsp+0x50]
00007ec68bfd7396  vmovaps xmm6, [rsp+0x60]
00007ec68bfd739c  vmovaps xmm7, [rsp+0x70]
00007ec68bfd73a2  vmovaps xmm8, [rsp+0x80]
00007ec68bfd73ab  vmovaps xmm9, [rsp+0x90]
00007ec68bfd73b4  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd73bd  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd73c6  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd73cf  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd73d8  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd73e1  add rsp, 0xF0
00007ec68bfd73e8  pop r11
00007ec68bfd73ea  pop r10
00007ec68bfd73ec  pop r9
00007ec68bfd73ee  pop r8
00007ec68bfd73f0  pop rsi
00007ec68bfd73f1  pop rdi
00007ec68bfd73f2  pop rdx
00007ec68bfd73f3  pop rcx
00007ec68bfd73f4  pop rax
00007ec68bfd73f5  add rsp, 0x08
00007ec68bfd73f9  jmp 0x00007EC68BFD32E9
00007ec68bfd73fe  sub rsp, 0x08
00007ec68bfd7402  push rax
00007ec68bfd7403  push rcx
00007ec68bfd7404  push rdx
00007ec68bfd7405  push rdi
00007ec68bfd7406  push rsi
00007ec68bfd7407  push r8
00007ec68bfd7409  push r9
00007ec68bfd740b  push r10
00007ec68bfd740d  push r11
00007ec68bfd740f  sub rsp, 0xF0
00007ec68bfd7416  vmovaps [rsp], xmm0
00007ec68bfd741b  vmovaps [rsp+0x10], xmm1
00007ec68bfd7421  vmovaps [rsp+0x20], xmm2
00007ec68bfd7427  vmovaps [rsp+0x30], xmm3
00007ec68bfd742d  vmovaps [rsp+0x40], xmm4
00007ec68bfd7433  vmovaps [rsp+0x50], xmm5
00007ec68bfd7439  vmovaps [rsp+0x60], xmm6
00007ec68bfd743f  vmovaps [rsp+0x70], xmm7
00007ec68bfd7445  vmovaps [rsp+0x80], xmm8
00007ec68bfd744e  vmovaps [rsp+0x90], xmm10
00007ec68bfd7457  vmovaps [rsp+0xA0], xmm11
00007ec68bfd7460  vmovaps [rsp+0xB0], xmm12
00007ec68bfd7469  vmovaps [rsp+0xC0], xmm13
00007ec68bfd7472  vmovaps [rsp+0xD0], xmm14
00007ec68bfd747b  vmovaps [rsp+0xE0], xmm15
00007ec68bfd7484  sub rsp, 0x30
00007ec68bfd7488  movaps [rsp], xmm9
00007ec68bfd748d  movaps [rsp+0x10], xmm7
00007ec68bfd7492  movaps [rsp+0x20], xmm14
00007ec68bfd7498  lea rdi, [rsp]
00007ec68bfd749c  mov esi, 0x00
00007ec68bfd74a1  mov rax, 0x57D97DADF530
00007ec68bfd74ab  call rax
00007ec68bfd74ad  movaps xmm9, [rsp]
00007ec68bfd74b2  add rsp, 0x30
00007ec68bfd74b6  vmovaps xmm0, [rsp]
00007ec68bfd74bb  vmovaps xmm1, [rsp+0x10]
00007ec68bfd74c1  vmovaps xmm2, [rsp+0x20]
00007ec68bfd74c7  vmovaps xmm3, [rsp+0x30]
00007ec68bfd74cd  vmovaps xmm4, [rsp+0x40]
00007ec68bfd74d3  vmovaps xmm5, [rsp+0x50]
00007ec68bfd74d9  vmovaps xmm6, [rsp+0x60]
00007ec68bfd74df  vmovaps xmm7, [rsp+0x70]
00007ec68bfd74e5  vmovaps xmm8, [rsp+0x80]
00007ec68bfd74ee  vmovaps xmm10, [rsp+0x90]
00007ec68bfd74f7  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd7500  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd7509  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd7512  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd751b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd7524  add rsp, 0xF0
00007ec68bfd752b  pop r11
00007ec68bfd752d  pop r10
00007ec68bfd752f  pop r9
00007ec68bfd7531  pop r8
00007ec68bfd7533  pop rsi
00007ec68bfd7534  pop rdi
00007ec68bfd7535  pop rdx
00007ec68bfd7536  pop rcx
00007ec68bfd7537  pop rax
00007ec68bfd7538  add rsp, 0x08
00007ec68bfd753c  jmp 0x00007EC68BFD3318
00007ec68bfd7541  sub rsp, 0x08
00007ec68bfd7545  push rax
00007ec68bfd7546  push rcx
00007ec68bfd7547  push rdx
00007ec68bfd7548  push rdi
00007ec68bfd7549  push rsi
00007ec68bfd754a  push r8
00007ec68bfd754c  push r9
00007ec68bfd754e  push r10
00007ec68bfd7550  push r11
00007ec68bfd7552  sub rsp, 0xF0
00007ec68bfd7559  vmovaps [rsp], xmm0
00007ec68bfd755e  vmovaps [rsp+0x10], xmm1
00007ec68bfd7564  vmovaps [rsp+0x20], xmm2
00007ec68bfd756a  vmovaps [rsp+0x30], xmm3
00007ec68bfd7570  vmovaps [rsp+0x40], xmm4
00007ec68bfd7576  vmovaps [rsp+0x50], xmm5
00007ec68bfd757c  vmovaps [rsp+0x60], xmm6
00007ec68bfd7582  vmovaps [rsp+0x70], xmm7
00007ec68bfd7588  vmovaps [rsp+0x80], xmm8
00007ec68bfd7591  vmovaps [rsp+0x90], xmm9
00007ec68bfd759a  vmovaps [rsp+0xA0], xmm10
00007ec68bfd75a3  vmovaps [rsp+0xB0], xmm11
00007ec68bfd75ac  vmovaps [rsp+0xC0], xmm12
00007ec68bfd75b5  vmovaps [rsp+0xD0], xmm13
00007ec68bfd75be  vmovaps [rsp+0xE0], xmm15
00007ec68bfd75c7  sub rsp, 0x30
00007ec68bfd75cb  movaps [rsp], xmm14
00007ec68bfd75d0  movaps [rsp+0x10], xmm13
00007ec68bfd75d6  movaps [rsp+0x20], xmm11
00007ec68bfd75dc  lea rdi, [rsp]
00007ec68bfd75e0  mov esi, 0x00
00007ec68bfd75e5  mov rax, 0x57D97DADF530
00007ec68bfd75ef  call rax
00007ec68bfd75f1  movaps xmm14, [rsp]
00007ec68bfd75f6  add rsp, 0x30
00007ec68bfd75fa  vmovaps xmm0, [rsp]
00007ec68bfd75ff  vmovaps xmm1, [rsp+0x10]
00007ec68bfd7605  vmovaps xmm2, [rsp+0x20]
00007ec68bfd760b  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7611  vmovaps xmm4, [rsp+0x40]
00007ec68bfd7617  vmovaps xmm5, [rsp+0x50]
00007ec68bfd761d  vmovaps xmm6, [rsp+0x60]
00007ec68bfd7623  vmovaps xmm7, [rsp+0x70]
00007ec68bfd7629  vmovaps xmm8, [rsp+0x80]
00007ec68bfd7632  vmovaps xmm9, [rsp+0x90]
00007ec68bfd763b  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd7644  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd764d  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd7656  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd765f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd7668  add rsp, 0xF0
00007ec68bfd766f  pop r11
00007ec68bfd7671  pop r10
00007ec68bfd7673  pop r9
00007ec68bfd7675  pop r8
00007ec68bfd7677  pop rsi
00007ec68bfd7678  pop rdi
00007ec68bfd7679  pop rdx
00007ec68bfd767a  pop rcx
00007ec68bfd767b  pop rax
00007ec68bfd767c  add rsp, 0x08
00007ec68bfd7680  jmp 0x00007EC68BFD3332
00007ec68bfd7685  sub rsp, 0x08
00007ec68bfd7689  push rax
00007ec68bfd768a  push rcx
00007ec68bfd768b  push rdx
00007ec68bfd768c  push rdi
00007ec68bfd768d  push rsi
00007ec68bfd768e  push r8
00007ec68bfd7690  push r9
00007ec68bfd7692  push r10
00007ec68bfd7694  push r11
00007ec68bfd7696  sub rsp, 0xF0
00007ec68bfd769d  vmovaps [rsp], xmm0
00007ec68bfd76a2  vmovaps [rsp+0x10], xmm1
00007ec68bfd76a8  vmovaps [rsp+0x20], xmm2
00007ec68bfd76ae  vmovaps [rsp+0x30], xmm3
00007ec68bfd76b4  vmovaps [rsp+0x40], xmm4
00007ec68bfd76ba  vmovaps [rsp+0x50], xmm5
00007ec68bfd76c0  vmovaps [rsp+0x60], xmm6
00007ec68bfd76c6  vmovaps [rsp+0x70], xmm7
00007ec68bfd76cc  vmovaps [rsp+0x80], xmm8
00007ec68bfd76d5  vmovaps [rsp+0x90], xmm9
00007ec68bfd76de  vmovaps [rsp+0xA0], xmm10
00007ec68bfd76e7  vmovaps [rsp+0xB0], xmm12
00007ec68bfd76f0  vmovaps [rsp+0xC0], xmm13
00007ec68bfd76f9  vmovaps [rsp+0xD0], xmm14
00007ec68bfd7702  vmovaps [rsp+0xE0], xmm15
00007ec68bfd770b  sub rsp, 0x30
00007ec68bfd770f  movaps [rsp], xmm11
00007ec68bfd7714  movaps [rsp+0x10], xmm7
00007ec68bfd7719  movaps [rsp+0x20], xmm13
00007ec68bfd771f  lea rdi, [rsp]
00007ec68bfd7723  mov esi, 0x00
00007ec68bfd7728  mov rax, 0x57D97DADF530
00007ec68bfd7732  call rax
00007ec68bfd7734  movaps xmm11, [rsp]
00007ec68bfd7739  add rsp, 0x30
00007ec68bfd773d  vmovaps xmm0, [rsp]
00007ec68bfd7742  vmovaps xmm1, [rsp+0x10]
00007ec68bfd7748  vmovaps xmm2, [rsp+0x20]
00007ec68bfd774e  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7754  vmovaps xmm4, [rsp+0x40]
00007ec68bfd775a  vmovaps xmm5, [rsp+0x50]
00007ec68bfd7760  vmovaps xmm6, [rsp+0x60]
00007ec68bfd7766  vmovaps xmm7, [rsp+0x70]
00007ec68bfd776c  vmovaps xmm8, [rsp+0x80]
00007ec68bfd7775  vmovaps xmm9, [rsp+0x90]
00007ec68bfd777e  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd7787  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd7790  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd7799  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd77a2  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd77ab  add rsp, 0xF0
00007ec68bfd77b2  pop r11
00007ec68bfd77b4  pop r10
00007ec68bfd77b6  pop r9
00007ec68bfd77b8  pop r8
00007ec68bfd77ba  pop rsi
00007ec68bfd77bb  pop rdi
00007ec68bfd77bc  pop rdx
00007ec68bfd77bd  pop rcx
00007ec68bfd77be  pop rax
00007ec68bfd77bf  add rsp, 0x08
00007ec68bfd77c3  jmp 0x00007EC68BFD335E
00007ec68bfd77c8  sub rsp, 0x08
00007ec68bfd77cc  push rax
00007ec68bfd77cd  push rcx
00007ec68bfd77ce  push rdx
00007ec68bfd77cf  push rdi
00007ec68bfd77d0  push rsi
00007ec68bfd77d1  push r8
00007ec68bfd77d3  push r9
00007ec68bfd77d5  push r10
00007ec68bfd77d7  push r11
00007ec68bfd77d9  sub rsp, 0xF0
00007ec68bfd77e0  vmovaps [rsp], xmm0
00007ec68bfd77e5  vmovaps [rsp+0x10], xmm1
00007ec68bfd77eb  vmovaps [rsp+0x20], xmm2
00007ec68bfd77f1  vmovaps [rsp+0x30], xmm3
00007ec68bfd77f7  vmovaps [rsp+0x40], xmm4
00007ec68bfd77fd  vmovaps [rsp+0x50], xmm5
00007ec68bfd7803  vmovaps [rsp+0x60], xmm6
00007ec68bfd7809  vmovaps [rsp+0x70], xmm7
00007ec68bfd780f  vmovaps [rsp+0x80], xmm8
00007ec68bfd7818  vmovaps [rsp+0x90], xmm9
00007ec68bfd7821  vmovaps [rsp+0xA0], xmm10
00007ec68bfd782a  vmovaps [rsp+0xB0], xmm11
00007ec68bfd7833  vmovaps [rsp+0xC0], xmm12
00007ec68bfd783c  vmovaps [rsp+0xD0], xmm14
00007ec68bfd7845  vmovaps [rsp+0xE0], xmm15
00007ec68bfd784e  sub rsp, 0x30
00007ec68bfd7852  movaps [rsp], xmm13
00007ec68bfd7857  movaps [rsp+0x10], xmm10
00007ec68bfd785d  movaps [rsp+0x20], xmm12
00007ec68bfd7863  lea rdi, [rsp]
00007ec68bfd7867  mov esi, 0x00
00007ec68bfd786c  mov rax, 0x57D97DADF530
00007ec68bfd7876  call rax
00007ec68bfd7878  movaps xmm13, [rsp]
00007ec68bfd787d  add rsp, 0x30
00007ec68bfd7881  vmovaps xmm0, [rsp]
00007ec68bfd7886  vmovaps xmm1, [rsp+0x10]
00007ec68bfd788c  vmovaps xmm2, [rsp+0x20]
00007ec68bfd7892  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7898  vmovaps xmm4, [rsp+0x40]
00007ec68bfd789e  vmovaps xmm5, [rsp+0x50]
00007ec68bfd78a4  vmovaps xmm6, [rsp+0x60]
00007ec68bfd78aa  vmovaps xmm7, [rsp+0x70]
00007ec68bfd78b0  vmovaps xmm8, [rsp+0x80]
00007ec68bfd78b9  vmovaps xmm9, [rsp+0x90]
00007ec68bfd78c2  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd78cb  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd78d4  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd78dd  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd78e6  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd78ef  add rsp, 0xF0
00007ec68bfd78f6  pop r11
00007ec68bfd78f8  pop r10
00007ec68bfd78fa  pop r9
00007ec68bfd78fc  pop r8
00007ec68bfd78fe  pop rsi
00007ec68bfd78ff  pop rdi
00007ec68bfd7900  pop rdx
00007ec68bfd7901  pop rcx
00007ec68bfd7902  pop rax
00007ec68bfd7903  add rsp, 0x08
00007ec68bfd7907  jmp 0x00007EC68BFD3378
00007ec68bfd790c  sub rsp, 0x08
00007ec68bfd7910  push rax
00007ec68bfd7911  push rcx
00007ec68bfd7912  push rdx
00007ec68bfd7913  push rdi
00007ec68bfd7914  push rsi
00007ec68bfd7915  push r8
00007ec68bfd7917  push r9
00007ec68bfd7919  push r10
00007ec68bfd791b  push r11
00007ec68bfd791d  sub rsp, 0xF0
00007ec68bfd7924  vmovaps [rsp], xmm0
00007ec68bfd7929  vmovaps [rsp+0x10], xmm1
00007ec68bfd792f  vmovaps [rsp+0x20], xmm2
00007ec68bfd7935  vmovaps [rsp+0x30], xmm3
00007ec68bfd793b  vmovaps [rsp+0x40], xmm4
00007ec68bfd7941  vmovaps [rsp+0x50], xmm5
00007ec68bfd7947  vmovaps [rsp+0x60], xmm6
00007ec68bfd794d  vmovaps [rsp+0x70], xmm7
00007ec68bfd7953  vmovaps [rsp+0x80], xmm8
00007ec68bfd795c  vmovaps [rsp+0x90], xmm9
00007ec68bfd7965  vmovaps [rsp+0xA0], xmm11
00007ec68bfd796e  vmovaps [rsp+0xB0], xmm12
00007ec68bfd7977  vmovaps [rsp+0xC0], xmm13
00007ec68bfd7980  vmovaps [rsp+0xD0], xmm14
00007ec68bfd7989  vmovaps [rsp+0xE0], xmm15
00007ec68bfd7992  sub rsp, 0x30
00007ec68bfd7996  movaps [rsp], xmm10
00007ec68bfd799b  movaps [rsp+0x10], xmm7
00007ec68bfd79a0  movaps [rsp+0x20], xmm12
00007ec68bfd79a6  lea rdi, [rsp]
00007ec68bfd79aa  mov esi, 0x00
00007ec68bfd79af  mov rax, 0x57D97DADF530
00007ec68bfd79b9  call rax
00007ec68bfd79bb  movaps xmm10, [rsp]
00007ec68bfd79c0  add rsp, 0x30
00007ec68bfd79c4  vmovaps xmm0, [rsp]
00007ec68bfd79c9  vmovaps xmm1, [rsp+0x10]
00007ec68bfd79cf  vmovaps xmm2, [rsp+0x20]
00007ec68bfd79d5  vmovaps xmm3, [rsp+0x30]
00007ec68bfd79db  vmovaps xmm4, [rsp+0x40]
00007ec68bfd79e1  vmovaps xmm5, [rsp+0x50]
00007ec68bfd79e7  vmovaps xmm6, [rsp+0x60]
00007ec68bfd79ed  vmovaps xmm7, [rsp+0x70]
00007ec68bfd79f3  vmovaps xmm8, [rsp+0x80]
00007ec68bfd79fc  vmovaps xmm9, [rsp+0x90]
00007ec68bfd7a05  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd7a0e  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd7a17  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd7a20  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd7a29  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd7a32  add rsp, 0xF0
00007ec68bfd7a39  pop r11
00007ec68bfd7a3b  pop r10
00007ec68bfd7a3d  pop r9
00007ec68bfd7a3f  pop r8
00007ec68bfd7a41  pop rsi
00007ec68bfd7a42  pop rdi
00007ec68bfd7a43  pop rdx
00007ec68bfd7a44  pop rcx
00007ec68bfd7a45  pop rax
00007ec68bfd7a46  add rsp, 0x08
00007ec68bfd7a4a  jmp 0x00007EC68BFD33A4
00007ec68bfd7a4f  sub rsp, 0x08
00007ec68bfd7a53  push rax
00007ec68bfd7a54  push rcx
00007ec68bfd7a55  push rdx
00007ec68bfd7a56  push rdi
00007ec68bfd7a57  push rsi
00007ec68bfd7a58  push r8
00007ec68bfd7a5a  push r9
00007ec68bfd7a5c  push r10
00007ec68bfd7a5e  push r11
00007ec68bfd7a60  sub rsp, 0xF0
00007ec68bfd7a67  vmovaps [rsp], xmm0
00007ec68bfd7a6c  vmovaps [rsp+0x10], xmm1
00007ec68bfd7a72  vmovaps [rsp+0x20], xmm2
00007ec68bfd7a78  vmovaps [rsp+0x30], xmm3
00007ec68bfd7a7e  vmovaps [rsp+0x40], xmm4
00007ec68bfd7a84  vmovaps [rsp+0x50], xmm5
00007ec68bfd7a8a  vmovaps [rsp+0x60], xmm6
00007ec68bfd7a90  vmovaps [rsp+0x70], xmm7
00007ec68bfd7a96  vmovaps [rsp+0x80], xmm8
00007ec68bfd7a9f  vmovaps [rsp+0x90], xmm9
00007ec68bfd7aa8  vmovaps [rsp+0xA0], xmm10
00007ec68bfd7ab1  vmovaps [rsp+0xB0], xmm11
00007ec68bfd7aba  vmovaps [rsp+0xC0], xmm13
00007ec68bfd7ac3  vmovaps [rsp+0xD0], xmm14
00007ec68bfd7acc  vmovaps [rsp+0xE0], xmm15
00007ec68bfd7ad5  sub rsp, 0x30
00007ec68bfd7ad9  movaps [rsp], xmm12
00007ec68bfd7ade  movaps [rsp+0x10], xmm1
00007ec68bfd7ae3  movaps [rsp+0x20], xmm8
00007ec68bfd7ae9  lea rdi, [rsp]
00007ec68bfd7aed  mov esi, 0x00
00007ec68bfd7af2  mov rax, 0x57D97DADF530
00007ec68bfd7afc  call rax
00007ec68bfd7afe  movaps xmm12, [rsp]
00007ec68bfd7b03  add rsp, 0x30
00007ec68bfd7b07  vmovaps xmm0, [rsp]
00007ec68bfd7b0c  vmovaps xmm1, [rsp+0x10]
00007ec68bfd7b12  vmovaps xmm2, [rsp+0x20]
00007ec68bfd7b18  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7b1e  vmovaps xmm4, [rsp+0x40]
00007ec68bfd7b24  vmovaps xmm5, [rsp+0x50]
00007ec68bfd7b2a  vmovaps xmm6, [rsp+0x60]
00007ec68bfd7b30  vmovaps xmm7, [rsp+0x70]
00007ec68bfd7b36  vmovaps xmm8, [rsp+0x80]
00007ec68bfd7b3f  vmovaps xmm9, [rsp+0x90]
00007ec68bfd7b48  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd7b51  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd7b5a  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd7b63  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd7b6c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd7b75  add rsp, 0xF0
00007ec68bfd7b7c  pop r11
00007ec68bfd7b7e  pop r10
00007ec68bfd7b80  pop r9
00007ec68bfd7b82  pop r8
00007ec68bfd7b84  pop rsi
00007ec68bfd7b85  pop rdi
00007ec68bfd7b86  pop rdx
00007ec68bfd7b87  pop rcx
00007ec68bfd7b88  pop rax
00007ec68bfd7b89  add rsp, 0x08
00007ec68bfd7b8d  jmp 0x00007EC68BFD33BE
00007ec68bfd7b92  call 0x00007EC68BDFF430
00007ec68bfd7b97  jmp 0x00007EC68BFD33C8
00007ec68bfd7b9c  sub rsp, 0x08
00007ec68bfd7ba0  push rax
00007ec68bfd7ba1  push rcx
00007ec68bfd7ba2  push rdx
00007ec68bfd7ba3  push rdi
00007ec68bfd7ba4  push rsi
00007ec68bfd7ba5  push r8
00007ec68bfd7ba7  push r9
00007ec68bfd7ba9  push r10
00007ec68bfd7bab  push r11
00007ec68bfd7bad  sub rsp, 0xF0
00007ec68bfd7bb4  vmovaps [rsp], xmm0
00007ec68bfd7bb9  vmovaps [rsp+0x10], xmm1
00007ec68bfd7bbf  vmovaps [rsp+0x20], xmm2
00007ec68bfd7bc5  vmovaps [rsp+0x30], xmm3
00007ec68bfd7bcb  vmovaps [rsp+0x40], xmm4
00007ec68bfd7bd1  vmovaps [rsp+0x50], xmm5
00007ec68bfd7bd7  vmovaps [rsp+0x60], xmm6
00007ec68bfd7bdd  vmovaps [rsp+0x70], xmm7
00007ec68bfd7be3  vmovaps [rsp+0x80], xmm9
00007ec68bfd7bec  vmovaps [rsp+0x90], xmm10
00007ec68bfd7bf5  vmovaps [rsp+0xA0], xmm11
00007ec68bfd7bfe  vmovaps [rsp+0xB0], xmm12
00007ec68bfd7c07  vmovaps [rsp+0xC0], xmm13
00007ec68bfd7c10  vmovaps [rsp+0xD0], xmm14
00007ec68bfd7c19  vmovaps [rsp+0xE0], xmm15
00007ec68bfd7c22  sub rsp, 0x30
00007ec68bfd7c26  movaps [rsp], xmm8
00007ec68bfd7c2b  movaps [rsp+0x10], xmm15
00007ec68bfd7c31  movaps [rsp+0x20], xmm9
00007ec68bfd7c37  lea rdi, [rsp]
00007ec68bfd7c3b  mov esi, 0x00
00007ec68bfd7c40  mov rax, 0x57D97DADF530
00007ec68bfd7c4a  call rax
00007ec68bfd7c4c  movaps xmm8, [rsp]
00007ec68bfd7c51  add rsp, 0x30
00007ec68bfd7c55  vmovaps xmm0, [rsp]
00007ec68bfd7c5a  vmovaps xmm1, [rsp+0x10]
00007ec68bfd7c60  vmovaps xmm2, [rsp+0x20]
00007ec68bfd7c66  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7c6c  vmovaps xmm4, [rsp+0x40]
00007ec68bfd7c72  vmovaps xmm5, [rsp+0x50]
00007ec68bfd7c78  vmovaps xmm6, [rsp+0x60]
00007ec68bfd7c7e  vmovaps xmm7, [rsp+0x70]
00007ec68bfd7c84  vmovaps xmm9, [rsp+0x80]
00007ec68bfd7c8d  vmovaps xmm10, [rsp+0x90]
00007ec68bfd7c96  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd7c9f  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd7ca8  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd7cb1  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd7cba  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd7cc3  add rsp, 0xF0
00007ec68bfd7cca  pop r11
00007ec68bfd7ccc  pop r10
00007ec68bfd7cce  pop r9
00007ec68bfd7cd0  pop r8
00007ec68bfd7cd2  pop rsi
00007ec68bfd7cd3  pop rdi
00007ec68bfd7cd4  pop rdx
00007ec68bfd7cd5  pop rcx
00007ec68bfd7cd6  pop rax
00007ec68bfd7cd7  add rsp, 0x08
00007ec68bfd7cdb  jmp 0x00007EC68BFD33EA
00007ec68bfd7ce0  sub rsp, 0x08
00007ec68bfd7ce4  push rax
00007ec68bfd7ce5  push rcx
00007ec68bfd7ce6  push rdx
00007ec68bfd7ce7  push rdi
00007ec68bfd7ce8  push rsi
00007ec68bfd7ce9  push r8
00007ec68bfd7ceb  push r9
00007ec68bfd7ced  push r10
00007ec68bfd7cef  push r11
00007ec68bfd7cf1  sub rsp, 0xF0
00007ec68bfd7cf8  vmovaps [rsp], xmm0
00007ec68bfd7cfd  vmovaps [rsp+0x10], xmm1
00007ec68bfd7d03  vmovaps [rsp+0x20], xmm2
00007ec68bfd7d09  vmovaps [rsp+0x30], xmm3
00007ec68bfd7d0f  vmovaps [rsp+0x40], xmm4
00007ec68bfd7d15  vmovaps [rsp+0x50], xmm5
00007ec68bfd7d1b  vmovaps [rsp+0x60], xmm6
00007ec68bfd7d21  vmovaps [rsp+0x70], xmm7
00007ec68bfd7d27  vmovaps [rsp+0x80], xmm8
00007ec68bfd7d30  vmovaps [rsp+0x90], xmm10
00007ec68bfd7d39  vmovaps [rsp+0xA0], xmm11
00007ec68bfd7d42  vmovaps [rsp+0xB0], xmm12
00007ec68bfd7d4b  vmovaps [rsp+0xC0], xmm13
00007ec68bfd7d54  vmovaps [rsp+0xD0], xmm14
00007ec68bfd7d5d  vmovaps [rsp+0xE0], xmm15
00007ec68bfd7d66  sub rsp, 0x30
00007ec68bfd7d6a  movaps [rsp], xmm9
00007ec68bfd7d6f  movaps [rsp+0x10], xmm1
00007ec68bfd7d74  movaps [rsp+0x20], xmm15
00007ec68bfd7d7a  lea rdi, [rsp]
00007ec68bfd7d7e  mov esi, 0x00
00007ec68bfd7d83  mov rax, 0x57D97DADF530
00007ec68bfd7d8d  call rax
00007ec68bfd7d8f  movaps xmm9, [rsp]
00007ec68bfd7d94  add rsp, 0x30
00007ec68bfd7d98  vmovaps xmm0, [rsp]
00007ec68bfd7d9d  vmovaps xmm1, [rsp+0x10]
00007ec68bfd7da3  vmovaps xmm2, [rsp+0x20]
00007ec68bfd7da9  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7daf  vmovaps xmm4, [rsp+0x40]
00007ec68bfd7db5  vmovaps xmm5, [rsp+0x50]
00007ec68bfd7dbb  vmovaps xmm6, [rsp+0x60]
00007ec68bfd7dc1  vmovaps xmm7, [rsp+0x70]
00007ec68bfd7dc7  vmovaps xmm8, [rsp+0x80]
00007ec68bfd7dd0  vmovaps xmm10, [rsp+0x90]
00007ec68bfd7dd9  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd7de2  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd7deb  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd7df4  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd7dfd  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd7e06  add rsp, 0xF0
00007ec68bfd7e0d  pop r11
00007ec68bfd7e0f  pop r10
00007ec68bfd7e11  pop r9
00007ec68bfd7e13  pop r8
00007ec68bfd7e15  pop rsi
00007ec68bfd7e16  pop rdi
00007ec68bfd7e17  pop rdx
00007ec68bfd7e18  pop rcx
00007ec68bfd7e19  pop rax
00007ec68bfd7e1a  add rsp, 0x08
00007ec68bfd7e1e  jmp 0x00007EC68BFD3418
00007ec68bfd7e23  sub rsp, 0x08
00007ec68bfd7e27  push rax
00007ec68bfd7e28  push rcx
00007ec68bfd7e29  push rdx
00007ec68bfd7e2a  push rdi
00007ec68bfd7e2b  push rsi
00007ec68bfd7e2c  push r8
00007ec68bfd7e2e  push r9
00007ec68bfd7e30  push r10
00007ec68bfd7e32  push r11
00007ec68bfd7e34  sub rsp, 0xF0
00007ec68bfd7e3b  vmovaps [rsp], xmm0
00007ec68bfd7e40  vmovaps [rsp+0x10], xmm1
00007ec68bfd7e46  vmovaps [rsp+0x20], xmm2
00007ec68bfd7e4c  vmovaps [rsp+0x30], xmm3
00007ec68bfd7e52  vmovaps [rsp+0x40], xmm4
00007ec68bfd7e58  vmovaps [rsp+0x50], xmm5
00007ec68bfd7e5e  vmovaps [rsp+0x60], xmm6
00007ec68bfd7e64  vmovaps [rsp+0x70], xmm7
00007ec68bfd7e6a  vmovaps [rsp+0x80], xmm8
00007ec68bfd7e73  vmovaps [rsp+0x90], xmm9
00007ec68bfd7e7c  vmovaps [rsp+0xA0], xmm10
00007ec68bfd7e85  vmovaps [rsp+0xB0], xmm11
00007ec68bfd7e8e  vmovaps [rsp+0xC0], xmm12
00007ec68bfd7e97  vmovaps [rsp+0xD0], xmm13
00007ec68bfd7ea0  vmovaps [rsp+0xE0], xmm14
00007ec68bfd7ea9  sub rsp, 0x30
00007ec68bfd7ead  movaps [rsp], xmm15
00007ec68bfd7eb2  movaps [rsp+0x10], xmm4
00007ec68bfd7eb7  movaps [rsp+0x20], xmm1
00007ec68bfd7ebc  lea rdi, [rsp]
00007ec68bfd7ec0  mov esi, 0x00
00007ec68bfd7ec5  mov rax, 0x57D97DADF530
00007ec68bfd7ecf  call rax
00007ec68bfd7ed1  movaps xmm15, [rsp]
00007ec68bfd7ed6  add rsp, 0x30
00007ec68bfd7eda  vmovaps xmm0, [rsp]
00007ec68bfd7edf  vmovaps xmm1, [rsp+0x10]
00007ec68bfd7ee5  vmovaps xmm2, [rsp+0x20]
00007ec68bfd7eeb  vmovaps xmm3, [rsp+0x30]
00007ec68bfd7ef1  vmovaps xmm4, [rsp+0x40]
00007ec68bfd7ef7  vmovaps xmm5, [rsp+0x50]
00007ec68bfd7efd  vmovaps xmm6, [rsp+0x60]
00007ec68bfd7f03  vmovaps xmm7, [rsp+0x70]
00007ec68bfd7f09  vmovaps xmm8, [rsp+0x80]
00007ec68bfd7f12  vmovaps xmm9, [rsp+0x90]
00007ec68bfd7f1b  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd7f24  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd7f2d  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd7f36  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd7f3f  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd7f48  add rsp, 0xF0
00007ec68bfd7f4f  pop r11
00007ec68bfd7f51  pop r10
00007ec68bfd7f53  pop r9
00007ec68bfd7f55  pop r8
00007ec68bfd7f57  pop rsi
00007ec68bfd7f58  pop rdi
00007ec68bfd7f59  pop rdx
00007ec68bfd7f5a  pop rcx
00007ec68bfd7f5b  pop rax
00007ec68bfd7f5c  add rsp, 0x08
00007ec68bfd7f60  jmp 0x00007EC68BFD343E
00007ec68bfd7f65  sub rsp, 0x08
00007ec68bfd7f69  push rax
00007ec68bfd7f6a  push rcx
00007ec68bfd7f6b  push rdx
00007ec68bfd7f6c  push rdi
00007ec68bfd7f6d  push rsi
00007ec68bfd7f6e  push r8
00007ec68bfd7f70  push r9
00007ec68bfd7f72  push r10
00007ec68bfd7f74  push r11
00007ec68bfd7f76  sub rsp, 0xF0
00007ec68bfd7f7d  vmovaps [rsp], xmm0
00007ec68bfd7f82  vmovaps [rsp+0x10], xmm2
00007ec68bfd7f88  vmovaps [rsp+0x20], xmm3
00007ec68bfd7f8e  vmovaps [rsp+0x30], xmm4
00007ec68bfd7f94  vmovaps [rsp+0x40], xmm5
00007ec68bfd7f9a  vmovaps [rsp+0x50], xmm6
00007ec68bfd7fa0  vmovaps [rsp+0x60], xmm7
00007ec68bfd7fa6  vmovaps [rsp+0x70], xmm8
00007ec68bfd7fac  vmovaps [rsp+0x80], xmm9
00007ec68bfd7fb5  vmovaps [rsp+0x90], xmm10
00007ec68bfd7fbe  vmovaps [rsp+0xA0], xmm11
00007ec68bfd7fc7  vmovaps [rsp+0xB0], xmm12
00007ec68bfd7fd0  vmovaps [rsp+0xC0], xmm13
00007ec68bfd7fd9  vmovaps [rsp+0xD0], xmm14
00007ec68bfd7fe2  vmovaps [rsp+0xE0], xmm15
00007ec68bfd7feb  sub rsp, 0x30
00007ec68bfd7fef  movaps [rsp], xmm1
00007ec68bfd7ff3  movaps [rsp+0x10], xmm14
00007ec68bfd7ff9  movaps [rsp+0x20], xmm11
00007ec68bfd7fff  lea rdi, [rsp]
00007ec68bfd8003  mov esi, 0x00
00007ec68bfd8008  mov rax, 0x57D97DADF530
00007ec68bfd8012  call rax
00007ec68bfd8014  movaps xmm1, [rsp]
00007ec68bfd8018  add rsp, 0x30
00007ec68bfd801c  vmovaps xmm0, [rsp]
00007ec68bfd8021  vmovaps xmm2, [rsp+0x10]
00007ec68bfd8027  vmovaps xmm3, [rsp+0x20]
00007ec68bfd802d  vmovaps xmm4, [rsp+0x30]
00007ec68bfd8033  vmovaps xmm5, [rsp+0x40]
00007ec68bfd8039  vmovaps xmm6, [rsp+0x50]
00007ec68bfd803f  vmovaps xmm7, [rsp+0x60]
00007ec68bfd8045  vmovaps xmm8, [rsp+0x70]
00007ec68bfd804b  vmovaps xmm9, [rsp+0x80]
00007ec68bfd8054  vmovaps xmm10, [rsp+0x90]
00007ec68bfd805d  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd8066  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd806f  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd8078  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd8081  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd808a  add rsp, 0xF0
00007ec68bfd8091  pop r11
00007ec68bfd8093  pop r10
00007ec68bfd8095  pop r9
00007ec68bfd8097  pop r8
00007ec68bfd8099  pop rsi
00007ec68bfd809a  pop rdi
00007ec68bfd809b  pop rdx
00007ec68bfd809c  pop rcx
00007ec68bfd809d  pop rax
00007ec68bfd809e  add rsp, 0x08
00007ec68bfd80a2  jmp 0x00007EC68BFD345F
00007ec68bfd80a7  call 0x00007EC68BEE45A0
00007ec68bfd80ac  jmp 0x00007EC68BFD346D
00007ec68bfd80b1  call 0x00007EC68BE09D70
00007ec68bfd80b6  jmp 0x00007EC68BFD3477
00007ec68bfd80bb  sub rsp, 0x08
00007ec68bfd80bf  push rax
00007ec68bfd80c0  push rcx
00007ec68bfd80c1  push rdx
00007ec68bfd80c2  push rdi
00007ec68bfd80c3  push rsi
00007ec68bfd80c4  push r8
00007ec68bfd80c6  push r9
00007ec68bfd80c8  push r10
00007ec68bfd80ca  push r11
00007ec68bfd80cc  sub rsp, 0xF0
00007ec68bfd80d3  vmovaps [rsp], xmm0
00007ec68bfd80d8  vmovaps [rsp+0x10], xmm1
00007ec68bfd80de  vmovaps [rsp+0x20], xmm2
00007ec68bfd80e4  vmovaps [rsp+0x30], xmm3
00007ec68bfd80ea  vmovaps [rsp+0x40], xmm4
00007ec68bfd80f0  vmovaps [rsp+0x50], xmm5
00007ec68bfd80f6  vmovaps [rsp+0x60], xmm6
00007ec68bfd80fc  vmovaps [rsp+0x70], xmm8
00007ec68bfd8102  vmovaps [rsp+0x80], xmm9
00007ec68bfd810b  vmovaps [rsp+0x90], xmm10
00007ec68bfd8114  vmovaps [rsp+0xA0], xmm11
00007ec68bfd811d  vmovaps [rsp+0xB0], xmm12
00007ec68bfd8126  vmovaps [rsp+0xC0], xmm13
00007ec68bfd812f  vmovaps [rsp+0xD0], xmm14
00007ec68bfd8138  vmovaps [rsp+0xE0], xmm15
00007ec68bfd8141  sub rsp, 0x30
00007ec68bfd8145  movaps [rsp], xmm7
00007ec68bfd8149  movaps [rsp+0x10], xmm13
00007ec68bfd814f  movaps [rsp+0x20], xmm10
00007ec68bfd8155  lea rdi, [rsp]
00007ec68bfd8159  mov esi, 0x00
00007ec68bfd815e  mov rax, 0x57D97DADF530
00007ec68bfd8168  call rax
00007ec68bfd816a  movaps xmm7, [rsp]
00007ec68bfd816e  add rsp, 0x30
00007ec68bfd8172  vmovaps xmm0, [rsp]
00007ec68bfd8177  vmovaps xmm1, [rsp+0x10]
00007ec68bfd817d  vmovaps xmm2, [rsp+0x20]
00007ec68bfd8183  vmovaps xmm3, [rsp+0x30]
00007ec68bfd8189  vmovaps xmm4, [rsp+0x40]
00007ec68bfd818f  vmovaps xmm5, [rsp+0x50]
00007ec68bfd8195  vmovaps xmm6, [rsp+0x60]
00007ec68bfd819b  vmovaps xmm8, [rsp+0x70]
00007ec68bfd81a1  vmovaps xmm9, [rsp+0x80]
00007ec68bfd81aa  vmovaps xmm10, [rsp+0x90]
00007ec68bfd81b3  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd81bc  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd81c5  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd81ce  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd81d7  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd81e0  add rsp, 0xF0
00007ec68bfd81e7  pop r11
00007ec68bfd81e9  pop r10
00007ec68bfd81eb  pop r9
00007ec68bfd81ed  pop r8
00007ec68bfd81ef  pop rsi
00007ec68bfd81f0  pop rdi
00007ec68bfd81f1  pop rdx
00007ec68bfd81f2  pop rcx
00007ec68bfd81f3  pop rax
00007ec68bfd81f4  add rsp, 0x08
00007ec68bfd81f8  jmp 0x00007EC68BFD3498
00007ec68bfd81fd  sub rsp, 0x08
00007ec68bfd8201  push rax
00007ec68bfd8202  push rcx
00007ec68bfd8203  push rdx
00007ec68bfd8204  push rdi
00007ec68bfd8205  push rsi
00007ec68bfd8206  push r8
00007ec68bfd8208  push r9
00007ec68bfd820a  push r10
00007ec68bfd820c  push r11
00007ec68bfd820e  sub rsp, 0xF0
00007ec68bfd8215  vmovaps [rsp], xmm0
00007ec68bfd821a  vmovaps [rsp+0x10], xmm1
00007ec68bfd8220  vmovaps [rsp+0x20], xmm2
00007ec68bfd8226  vmovaps [rsp+0x30], xmm3
00007ec68bfd822c  vmovaps [rsp+0x40], xmm4
00007ec68bfd8232  vmovaps [rsp+0x50], xmm5
00007ec68bfd8238  vmovaps [rsp+0x60], xmm6
00007ec68bfd823e  vmovaps [rsp+0x70], xmm7
00007ec68bfd8244  vmovaps [rsp+0x80], xmm8
00007ec68bfd824d  vmovaps [rsp+0x90], xmm9
00007ec68bfd8256  vmovaps [rsp+0xA0], xmm11
00007ec68bfd825f  vmovaps [rsp+0xB0], xmm12
00007ec68bfd8268  vmovaps [rsp+0xC0], xmm13
00007ec68bfd8271  vmovaps [rsp+0xD0], xmm14
00007ec68bfd827a  vmovaps [rsp+0xE0], xmm15
00007ec68bfd8283  sub rsp, 0x30
00007ec68bfd8287  movaps [rsp], xmm10
00007ec68bfd828c  movaps [rsp+0x10], xmm11
00007ec68bfd8292  movaps [rsp+0x20], xmm13
00007ec68bfd8298  lea rdi, [rsp]
00007ec68bfd829c  mov esi, 0x00
00007ec68bfd82a1  mov rax, 0x57D97DADF530
00007ec68bfd82ab  call rax
00007ec68bfd82ad  movaps xmm10, [rsp]
00007ec68bfd82b2  add rsp, 0x30
00007ec68bfd82b6  vmovaps xmm0, [rsp]
00007ec68bfd82bb  vmovaps xmm1, [rsp+0x10]
00007ec68bfd82c1  vmovaps xmm2, [rsp+0x20]
00007ec68bfd82c7  vmovaps xmm3, [rsp+0x30]
00007ec68bfd82cd  vmovaps xmm4, [rsp+0x40]
00007ec68bfd82d3  vmovaps xmm5, [rsp+0x50]
00007ec68bfd82d9  vmovaps xmm6, [rsp+0x60]
00007ec68bfd82df  vmovaps xmm7, [rsp+0x70]
00007ec68bfd82e5  vmovaps xmm8, [rsp+0x80]
00007ec68bfd82ee  vmovaps xmm9, [rsp+0x90]
00007ec68bfd82f7  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd8300  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd8309  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd8312  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd831b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd8324  add rsp, 0xF0
00007ec68bfd832b  pop r11
00007ec68bfd832d  pop r10
00007ec68bfd832f  pop r9
00007ec68bfd8331  pop r8
00007ec68bfd8333  pop rsi
00007ec68bfd8334  pop rdi
00007ec68bfd8335  pop rdx
00007ec68bfd8336  pop rcx
00007ec68bfd8337  pop rax
00007ec68bfd8338  add rsp, 0x08
00007ec68bfd833c  jmp 0x00007EC68BFD34C6
00007ec68bfd8341  sub rsp, 0x08
00007ec68bfd8345  push rax
00007ec68bfd8346  push rcx
00007ec68bfd8347  push rdx
00007ec68bfd8348  push rdi
00007ec68bfd8349  push rsi
00007ec68bfd834a  push r8
00007ec68bfd834c  push r9
00007ec68bfd834e  push r10
00007ec68bfd8350  push r11
00007ec68bfd8352  sub rsp, 0xF0
00007ec68bfd8359  vmovaps [rsp], xmm0
00007ec68bfd835e  vmovaps [rsp+0x10], xmm1
00007ec68bfd8364  vmovaps [rsp+0x20], xmm2
00007ec68bfd836a  vmovaps [rsp+0x30], xmm3
00007ec68bfd8370  vmovaps [rsp+0x40], xmm4
00007ec68bfd8376  vmovaps [rsp+0x50], xmm5
00007ec68bfd837c  vmovaps [rsp+0x60], xmm6
00007ec68bfd8382  vmovaps [rsp+0x70], xmm7
00007ec68bfd8388  vmovaps [rsp+0x80], xmm8
00007ec68bfd8391  vmovaps [rsp+0x90], xmm9
00007ec68bfd839a  vmovaps [rsp+0xA0], xmm10
00007ec68bfd83a3  vmovaps [rsp+0xB0], xmm12
00007ec68bfd83ac  vmovaps [rsp+0xC0], xmm13
00007ec68bfd83b5  vmovaps [rsp+0xD0], xmm14
00007ec68bfd83be  vmovaps [rsp+0xE0], xmm15
00007ec68bfd83c7  sub rsp, 0x30
00007ec68bfd83cb  movaps [rsp], xmm11
00007ec68bfd83d0  movaps [rsp+0x10], xmm14
00007ec68bfd83d6  movaps [rsp+0x20], xmm13
00007ec68bfd83dc  lea rdi, [rsp]
00007ec68bfd83e0  mov esi, 0x00
00007ec68bfd83e5  mov rax, 0x57D97DADF530
00007ec68bfd83ef  call rax
00007ec68bfd83f1  movaps xmm11, [rsp]
00007ec68bfd83f6  add rsp, 0x30
00007ec68bfd83fa  vmovaps xmm0, [rsp]
00007ec68bfd83ff  vmovaps xmm1, [rsp+0x10]
00007ec68bfd8405  vmovaps xmm2, [rsp+0x20]
00007ec68bfd840b  vmovaps xmm3, [rsp+0x30]
00007ec68bfd8411  vmovaps xmm4, [rsp+0x40]
00007ec68bfd8417  vmovaps xmm5, [rsp+0x50]
00007ec68bfd841d  vmovaps xmm6, [rsp+0x60]
00007ec68bfd8423  vmovaps xmm7, [rsp+0x70]
00007ec68bfd8429  vmovaps xmm8, [rsp+0x80]
00007ec68bfd8432  vmovaps xmm9, [rsp+0x90]
00007ec68bfd843b  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd8444  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd844d  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd8456  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd845f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd8468  add rsp, 0xF0
00007ec68bfd846f  pop r11
00007ec68bfd8471  pop r10
00007ec68bfd8473  pop r9
00007ec68bfd8475  pop r8
00007ec68bfd8477  pop rsi
00007ec68bfd8478  pop rdi
00007ec68bfd8479  pop rdx
00007ec68bfd847a  pop rcx
00007ec68bfd847b  pop rax
00007ec68bfd847c  add rsp, 0x08
00007ec68bfd8480  jmp 0x00007EC68BFD34F4
00007ec68bfd8485  sub rsp, 0x08
00007ec68bfd8489  push rax
00007ec68bfd848a  push rcx
00007ec68bfd848b  push rdx
00007ec68bfd848c  push rdi
00007ec68bfd848d  push rsi
00007ec68bfd848e  push r8
00007ec68bfd8490  push r9
00007ec68bfd8492  push r10
00007ec68bfd8494  push r11
00007ec68bfd8496  sub rsp, 0xF0
00007ec68bfd849d  vmovaps [rsp], xmm0
00007ec68bfd84a2  vmovaps [rsp+0x10], xmm1
00007ec68bfd84a8  vmovaps [rsp+0x20], xmm2
00007ec68bfd84ae  vmovaps [rsp+0x30], xmm3
00007ec68bfd84b4  vmovaps [rsp+0x40], xmm4
00007ec68bfd84ba  vmovaps [rsp+0x50], xmm5
00007ec68bfd84c0  vmovaps [rsp+0x60], xmm6
00007ec68bfd84c6  vmovaps [rsp+0x70], xmm7
00007ec68bfd84cc  vmovaps [rsp+0x80], xmm8
00007ec68bfd84d5  vmovaps [rsp+0x90], xmm9
00007ec68bfd84de  vmovaps [rsp+0xA0], xmm10
00007ec68bfd84e7  vmovaps [rsp+0xB0], xmm11
00007ec68bfd84f0  vmovaps [rsp+0xC0], xmm12
00007ec68bfd84f9  vmovaps [rsp+0xD0], xmm13
00007ec68bfd8502  vmovaps [rsp+0xE0], xmm15
00007ec68bfd850b  sub rsp, 0x30
00007ec68bfd850f  movaps [rsp], xmm14
00007ec68bfd8514  movaps [rsp+0x10], xmm12
00007ec68bfd851a  movaps [rsp+0x20], xmm9
00007ec68bfd8520  lea rdi, [rsp]
00007ec68bfd8524  mov esi, 0x00
00007ec68bfd8529  mov rax, 0x57D97DADF530
00007ec68bfd8533  call rax
00007ec68bfd8535  movaps xmm14, [rsp]
00007ec68bfd853a  add rsp, 0x30
00007ec68bfd853e  vmovaps xmm0, [rsp]
00007ec68bfd8543  vmovaps xmm1, [rsp+0x10]
00007ec68bfd8549  vmovaps xmm2, [rsp+0x20]
00007ec68bfd854f  vmovaps xmm3, [rsp+0x30]
00007ec68bfd8555  vmovaps xmm4, [rsp+0x40]
00007ec68bfd855b  vmovaps xmm5, [rsp+0x50]
00007ec68bfd8561  vmovaps xmm6, [rsp+0x60]
00007ec68bfd8567  vmovaps xmm7, [rsp+0x70]
00007ec68bfd856d  vmovaps xmm8, [rsp+0x80]
00007ec68bfd8576  vmovaps xmm9, [rsp+0x90]
00007ec68bfd857f  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd8588  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd8591  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd859a  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd85a3  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd85ac  add rsp, 0xF0
00007ec68bfd85b3  pop r11
00007ec68bfd85b5  pop r10
00007ec68bfd85b7  pop r9
00007ec68bfd85b9  pop r8
00007ec68bfd85bb  pop rsi
00007ec68bfd85bc  pop rdi
00007ec68bfd85bd  pop rdx
00007ec68bfd85be  pop rcx
00007ec68bfd85bf  pop rax
00007ec68bfd85c0  add rsp, 0x08
00007ec68bfd85c4  jmp 0x00007EC68BFD350F
00007ec68bfd85c9  sub rsp, 0x08
00007ec68bfd85cd  push rax
00007ec68bfd85ce  push rcx
00007ec68bfd85cf  push rdx
00007ec68bfd85d0  push rdi
00007ec68bfd85d1  push rsi
00007ec68bfd85d2  push r8
00007ec68bfd85d4  push r9
00007ec68bfd85d6  push r10
00007ec68bfd85d8  push r11
00007ec68bfd85da  sub rsp, 0xF0
00007ec68bfd85e1  vmovaps [rsp], xmm0
00007ec68bfd85e6  vmovaps [rsp+0x10], xmm1
00007ec68bfd85ec  vmovaps [rsp+0x20], xmm2
00007ec68bfd85f2  vmovaps [rsp+0x30], xmm3
00007ec68bfd85f8  vmovaps [rsp+0x40], xmm4
00007ec68bfd85fe  vmovaps [rsp+0x50], xmm5
00007ec68bfd8604  vmovaps [rsp+0x60], xmm6
00007ec68bfd860a  vmovaps [rsp+0x70], xmm7
00007ec68bfd8610  vmovaps [rsp+0x80], xmm8
00007ec68bfd8619  vmovaps [rsp+0x90], xmm9
00007ec68bfd8622  vmovaps [rsp+0xA0], xmm10
00007ec68bfd862b  vmovaps [rsp+0xB0], xmm11
00007ec68bfd8634  vmovaps [rsp+0xC0], xmm12
00007ec68bfd863d  vmovaps [rsp+0xD0], xmm14
00007ec68bfd8646  vmovaps [rsp+0xE0], xmm15
00007ec68bfd864f  sub rsp, 0x30
00007ec68bfd8653  movaps [rsp], xmm13
00007ec68bfd8658  movaps [rsp+0x10], xmm8
00007ec68bfd865e  movaps [rsp+0x20], xmm15
00007ec68bfd8664  lea rdi, [rsp]
00007ec68bfd8668  mov esi, 0x00
00007ec68bfd866d  mov rax, 0x57D97DADF530
00007ec68bfd8677  call rax
00007ec68bfd8679  movaps xmm13, [rsp]
00007ec68bfd867e  add rsp, 0x30
00007ec68bfd8682  vmovaps xmm0, [rsp]
00007ec68bfd8687  vmovaps xmm1, [rsp+0x10]
00007ec68bfd868d  vmovaps xmm2, [rsp+0x20]
00007ec68bfd8693  vmovaps xmm3, [rsp+0x30]
00007ec68bfd8699  vmovaps xmm4, [rsp+0x40]
00007ec68bfd869f  vmovaps xmm5, [rsp+0x50]
00007ec68bfd86a5  vmovaps xmm6, [rsp+0x60]
00007ec68bfd86ab  vmovaps xmm7, [rsp+0x70]
00007ec68bfd86b1  vmovaps xmm8, [rsp+0x80]
00007ec68bfd86ba  vmovaps xmm9, [rsp+0x90]
00007ec68bfd86c3  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd86cc  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd86d5  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd86de  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd86e7  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd86f0  add rsp, 0xF0
00007ec68bfd86f7  pop r11
00007ec68bfd86f9  pop r10
00007ec68bfd86fb  pop r9
00007ec68bfd86fd  pop r8
00007ec68bfd86ff  pop rsi
00007ec68bfd8700  pop rdi
00007ec68bfd8701  pop rdx
00007ec68bfd8702  pop rcx
00007ec68bfd8703  pop rax
00007ec68bfd8704  add rsp, 0x08
00007ec68bfd8708  jmp 0x00007EC68BFD3532
00007ec68bfd870d  sub rsp, 0x08
00007ec68bfd8711  push rax
00007ec68bfd8712  push rcx
00007ec68bfd8713  push rdx
00007ec68bfd8714  push rdi
00007ec68bfd8715  push rsi
00007ec68bfd8716  push r8
00007ec68bfd8718  push r9
00007ec68bfd871a  push r10
00007ec68bfd871c  push r11
00007ec68bfd871e  sub rsp, 0xF0
00007ec68bfd8725  vmovaps [rsp], xmm0
00007ec68bfd872a  vmovaps [rsp+0x10], xmm1
00007ec68bfd8730  vmovaps [rsp+0x20], xmm2
00007ec68bfd8736  vmovaps [rsp+0x30], xmm3
00007ec68bfd873c  vmovaps [rsp+0x40], xmm4
00007ec68bfd8742  vmovaps [rsp+0x50], xmm5
00007ec68bfd8748  vmovaps [rsp+0x60], xmm6
00007ec68bfd874e  vmovaps [rsp+0x70], xmm7
00007ec68bfd8754  vmovaps [rsp+0x80], xmm8
00007ec68bfd875d  vmovaps [rsp+0x90], xmm9
00007ec68bfd8766  vmovaps [rsp+0xA0], xmm10
00007ec68bfd876f  vmovaps [rsp+0xB0], xmm11
00007ec68bfd8778  vmovaps [rsp+0xC0], xmm12
00007ec68bfd8781  vmovaps [rsp+0xD0], xmm13
00007ec68bfd878a  vmovaps [rsp+0xE0], xmm14
00007ec68bfd8793  sub rsp, 0x30
00007ec68bfd8797  movaps [rsp], xmm15
00007ec68bfd879c  movaps [rsp+0x10], xmm1
00007ec68bfd87a1  movaps [rsp+0x20], xmm10
00007ec68bfd87a7  lea rdi, [rsp]
00007ec68bfd87ab  mov esi, 0x00
00007ec68bfd87b0  mov rax, 0x57D97DADF530
00007ec68bfd87ba  call rax
00007ec68bfd87bc  movaps xmm15, [rsp]
00007ec68bfd87c1  add rsp, 0x30
00007ec68bfd87c5  vmovaps xmm0, [rsp]
00007ec68bfd87ca  vmovaps xmm1, [rsp+0x10]
00007ec68bfd87d0  vmovaps xmm2, [rsp+0x20]
00007ec68bfd87d6  vmovaps xmm3, [rsp+0x30]
00007ec68bfd87dc  vmovaps xmm4, [rsp+0x40]
00007ec68bfd87e2  vmovaps xmm5, [rsp+0x50]
00007ec68bfd87e8  vmovaps xmm6, [rsp+0x60]
00007ec68bfd87ee  vmovaps xmm7, [rsp+0x70]
00007ec68bfd87f4  vmovaps xmm8, [rsp+0x80]
00007ec68bfd87fd  vmovaps xmm9, [rsp+0x90]
00007ec68bfd8806  vmovaps xmm10, [rsp+0xA0]
00007ec68bfd880f  vmovaps xmm11, [rsp+0xB0]
00007ec68bfd8818  vmovaps xmm12, [rsp+0xC0]
00007ec68bfd8821  vmovaps xmm13, [rsp+0xD0]
00007ec68bfd882a  vmovaps xmm14, [rsp+0xE0]
00007ec68bfd8833  add rsp, 0xF0
00007ec68bfd883a  pop r11
00007ec68bfd883c  pop r10
00007ec68bfd883e  pop r9
00007ec68bfd8840  pop r8
00007ec68bfd8842  pop rsi
00007ec68bfd8843  pop rdi
00007ec68bfd8844  pop rdx
00007ec68bfd8845  pop rcx
00007ec68bfd8846  pop rax
00007ec68bfd8847  add rsp, 0x08
00007ec68bfd884b  jmp 0x00007EC68BFD3555
00007ec68bfd8850  sub rsp, 0x08
00007ec68bfd8854  push rax
00007ec68bfd8855  push rcx
00007ec68bfd8856  push rdx
00007ec68bfd8857  push rdi
00007ec68bfd8858  push rsi
00007ec68bfd8859  push r8
00007ec68bfd885b  push r9
00007ec68bfd885d  push r10
00007ec68bfd885f  push r11
00007ec68bfd8861  sub rsp, 0xF0
00007ec68bfd8868  vmovaps [rsp], xmm0
00007ec68bfd886d  vmovaps [rsp+0x10], xmm2
00007ec68bfd8873  vmovaps [rsp+0x20], xmm3
00007ec68bfd8879  vmovaps [rsp+0x30], xmm4
00007ec68bfd887f  vmovaps [rsp+0x40], xmm5
00007ec68bfd8885  vmovaps [rsp+0x50], xmm6
00007ec68bfd888b  vmovaps [rsp+0x60], xmm7
00007ec68bfd8891  vmovaps [rsp+0x70], xmm8
00007ec68bfd8897  vmovaps [rsp+0x80], xmm9
00007ec68bfd88a0  vmovaps [rsp+0x90], xmm10
00007ec68bfd88a9  vmovaps [rsp+0xA0], xmm11
00007ec68bfd88b2  vmovaps [rsp+0xB0], xmm12
00007ec68bfd88bb  vmovaps [rsp+0xC0], xmm13
00007ec68bfd88c4  vmovaps [rsp+0xD0], xmm14
00007ec68bfd88cd  vmovaps [rsp+0xE0], xmm15
00007ec68bfd88d6  sub rsp, 0x30
00007ec68bfd88da  movaps [rsp], xmm1
00007ec68bfd88de  movaps [rsp+0x10], xmm7
00007ec68bfd88e3  movaps [rsp+0x20], xmm11
00007ec68bfd88e9  lea rdi, [rsp]
00007ec68bfd88ed  mov esi, 0x00
00007ec68bfd88f2  mov rax, 0x57D97DADF530
00007ec68bfd88fc  call rax
00007ec68bfd88fe  movaps xmm1, [rsp]
00007ec68bfd8902  add rsp, 0x30
00007ec68bfd8906  vmovaps xmm0, [rsp]
00007ec68bfd890b  vmovaps xmm2, [rsp+0x10]
00007ec68bfd8911  vmovaps xmm3, [rsp+0x20]
00007ec68bfd8917  vmovaps xmm4, [rsp+0x30]
00007ec68bfd891d  vmovaps xmm5, [rsp+0x40]
00007ec68bfd8923  vmovaps xmm6, [rsp+0x50]
00007ec68bfd8929  vmovaps xmm7, [rsp+0x60]
00007ec68bfd892f  vmovaps xmm8, [rsp+0x70]
00007ec68bfd8935  vmovaps xmm9, [rsp+0x80]
00007ec68bfd893e  vmovaps xmm10, [rsp+0x90]
00007ec68bfd8947  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd8950  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd8959  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd8962  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd896b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd8974  add rsp, 0xF0
00007ec68bfd897b  pop r11
00007ec68bfd897d  pop r10
00007ec68bfd897f  pop r9
00007ec68bfd8981  pop r8
00007ec68bfd8983  pop rsi
00007ec68bfd8984  pop rdi
00007ec68bfd8985  pop rdx
00007ec68bfd8986  pop rcx
00007ec68bfd8987  pop rax
00007ec68bfd8988  add rsp, 0x08
00007ec68bfd898c  jmp 0x00007EC68BFD3576
00007ec68bfd8991  call 0x00007EC68BE0D600
00007ec68bfd8996  jmp 0x00007EC68BFD3589
00007ec68bfd899b  call 0x00007EC68BE0C380
00007ec68bfd89a0  jmp 0x00007EC68BFD3594
00007ec68bfd89a5  call 0x00007EC68BE0E880
00007ec68bfd89aa  jmp 0x00007EC68BFD359F
00007ec68bfd89af  call 0x00007EC68BDFF540
00007ec68bfd89b4  jmp 0x00007EC68BFD35AA
00007ec68bfd89b9  int3
00007ec68bfd89ba  nop [rax+rax*1], ax
00007ec68bfd89c0  mov rax, [r15+0x40]
00007ec68bfd89c4  mov r14, [r15+0x58]
00007ec68bfd89c8  lea r12, [rax+r14*1]
00007ec68bfd89cc  movaps xmm1, [r15+0x1D0]
00007ec68bfd89d4  vmovaps [rsp+0x10], xmm1
00007ec68bfd89da  vmovaps xmm15, [rsp+0x10]
00007ec68bfd89e0  por xmm1, xmm15
00007ec68bfd89e5  movaps xmm14, [r15+0x1A0]
00007ec68bfd89ed  vmovaps [rsp+0x10], xmm14
00007ec68bfd89f3  vmovaps xmm13, [rsp+0x10]
00007ec68bfd89f9  por xmm14, xmm13
00007ec68bfd89fe  lea rax, [r12+0x30]
00007ec68bfd8a03  mov r11, [r13+rax*1]
00007ec68bfd8a08  lea rax, [r12+0x38]
00007ec68bfd8a0d  mov r10, [r13+rax*1]
00007ec68bfd8a12  movq xmm13, r11
00007ec68bfd8a17  movq xmm12, r10
00007ec68bfd8a1c  movq xmm13, xmm13
00007ec68bfd8a21  vmovaps [rsp+0x10], xmm13
00007ec68bfd8a27  movq xmm13, xmm13
00007ec68bfd8a2c  movaps [r15+0x130], xmm13
00007ec68bfd8a34  movq xmm12, xmm12
00007ec68bfd8a39  vmovaps [rsp+0x20], xmm12
00007ec68bfd8a3f  movq xmm12, xmm12
00007ec68bfd8a44  movaps [r15+0x280], xmm12
00007ec68bfd8a4c  movaps xmm13, [r15+0x270]
00007ec68bfd8a54  vmovaps [rsp+0x30], xmm13
00007ec68bfd8a5a  vmovaps xmm12, [rsp+0x30]
00007ec68bfd8a60  por xmm13, xmm12
00007ec68bfd8a65  lea rax, [r12+0x20]
00007ec68bfd8a6a  mov r11, [r13+rax*1]
00007ec68bfd8a6f  lea rax, [r12+0x28]
00007ec68bfd8a74  mov r10, [r13+rax*1]
00007ec68bfd8a79  movq xmm12, r11
00007ec68bfd8a7e  movq xmm11, r10
00007ec68bfd8a83  movq xmm12, xmm12
00007ec68bfd8a88  vmovaps [rsp+0x30], xmm12
00007ec68bfd8a8e  movq xmm12, xmm12
00007ec68bfd8a93  movaps [r15+0x150], xmm12
00007ec68bfd8a9b  movq xmm11, xmm11
00007ec68bfd8aa0  vmovaps [rsp+0x40], xmm11
00007ec68bfd8aa6  movq xmm11, xmm11
00007ec68bfd8aab  movaps [r15+0x140], xmm11
00007ec68bfd8ab3  lea rax, [r12+0x10]
00007ec68bfd8ab8  mov r11, [r13+rax*1]
00007ec68bfd8abd  lea rax, [r12+0x18]
00007ec68bfd8ac2  mov r10, [r13+rax*1]
00007ec68bfd8ac7  movq xmm12, r11
00007ec68bfd8acc  movq xmm11, r10
00007ec68bfd8ad1  movq xmm12, xmm12
00007ec68bfd8ad6  vmovaps [rsp+0x50], xmm12
00007ec68bfd8adc  movq xmm12, xmm12
00007ec68bfd8ae1  movaps [r15+0x170], xmm12
00007ec68bfd8ae9  movq xmm11, xmm11
00007ec68bfd8aee  vmovaps [rsp+0x60], xmm11
00007ec68bfd8af4  movq xmm11, xmm11
00007ec68bfd8af9  movaps [r15+0x160], xmm11
00007ec68bfd8b01  mov rax, [r13+r12*1]
00007ec68bfd8b06  vmovq xmm12, rax
00007ec68bfd8b0b  vpbroadcastq xmm12, xmm12
00007ec68bfd8b10  lea rax, [r12+0x08]
00007ec68bfd8b15  mov r12, [r13+rax*1]
00007ec68bfd8b1a  movq xmm11, r12
00007ec68bfd8b1f  movaps [r15+0x230], xmm11
00007ec68bfd8b27  mov rax, [r15+0xF8]
00007ec68bfd8b2e  lea r12, [rax+0x50]
00007ec68bfd8b32  movups xmm11, [r13+r12*1]
00007ec68bfd8b38  lea r12, [rax+0x60]
00007ec68bfd8b3c  movups xmm10, [r13+r12*1]
00007ec68bfd8b42  lea r12, [rax+0x30]
00007ec68bfd8b46  movups xmm9, [r13+r12*1]
00007ec68bfd8b4c  mov r12, [r15+0x50]
00007ec68bfd8b50  lea r11, [r12+r14*1]
00007ec68bfd8b54  mov [r15+0x60], r11
00007ec68bfd8b58  lea r12, [r14+0x40]
00007ec68bfd8b5c  mov [r15+0x58], r12
00007ec68bfd8b60  movaps xmm8, xmm12
00007ec68bfd8b64  mulpd xmm8, xmm15
00007ec68bfd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007ec68bfd8b6f  ptest xmm7, xmm7
00007ec68bfd8b74  jnz 0x00007EC68BFD9997
00007ec68bfd8b7a  movq xmm15, qword ptr [r15+0x230]
00007ec68bfd8b83  vmovaps [rsp+0x70], xmm15
00007ec68bfd8b89  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd8b8f  movaps xmm7, xmm9
00007ec68bfd8b93  mulpd xmm7, xmm15
00007ec68bfd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007ec68bfd8b9d  ptest xmm6, xmm6
00007ec68bfd8ba2  jnz 0x00007EC68BFD9ADB
00007ec68bfd8ba8  vxorps xmm15, xmm15, xmm15
00007ec68bfd8bad  vpbroadcastq xmm15, xmm15
00007ec68bfd8bb2  movaps xmm9, xmm12
00007ec68bfd8bb6  mulpd xmm9, xmm10
00007ec68bfd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007ec68bfd8bc1  ptest xmm6, xmm6
00007ec68bfd8bc6  jnz 0x00007EC68BFD9C1D
00007ec68bfd8bcc  movaps xmm10, xmm12
00007ec68bfd8bd0  mulpd xmm10, xmm11
00007ec68bfd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007ec68bfd8bdb  ptest xmm6, xmm6
00007ec68bfd8be0  jnz 0x00007EC68BFD9D61
00007ec68bfd8be6  movaps xmm11, [r15+0x1F0]
00007ec68bfd8bee  movaps xmm6, xmm12
00007ec68bfd8bf2  mulpd xmm6, xmm11
00007ec68bfd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007ec68bfd8bfc  ptest xmm5, xmm5
00007ec68bfd8c01  jnz 0x00007EC68BFD9EA5
00007ec68bfd8c07  movaps xmm12, [r15+0x2A0]
00007ec68bfd8c0f  vmovaps [rsp+0x80], xmm12
00007ec68bfd8c18  vmovaps xmm11, [rsp+0x80]
00007ec68bfd8c21  por xmm12, xmm11
00007ec68bfd8c26  movaps xmm11, [r15+0x250]
00007ec68bfd8c2e  vmovaps [rsp+0x80], xmm11
00007ec68bfd8c37  vmovaps xmm5, [rsp+0x80]
00007ec68bfd8c40  por xmm11, xmm5
00007ec68bfd8c45  vmovaps xmm4, [rsp+0x70]
00007ec68bfd8c4b  vpermilpd xmm4, xmm4, 0x00
00007ec68bfd8c51  movaps xmm3, xmm5
00007ec68bfd8c54  mulpd xmm3, xmm4
00007ec68bfd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007ec68bfd8c5d  ptest xmm2, xmm2
00007ec68bfd8c62  jnz 0x00007EC68BFD9FE7
00007ec68bfd8c68  mov [rsp+0x80], rax
00007ec68bfd8c70  xor eax, eax
00007ec68bfd8c72  mov r14d, 0x200
00007ec68bfd8c78  cmp r12, r14
00007ec68bfd8c7b  cmc
00007ec68bfd8c7c  lahf
00007ec68bfd8c7d  seto al
00007ec68bfd8c80  mov [r15+0x108], eax
00007ec68bfd8c87  movaps xmm5, xmm8
00007ec68bfd8c8b  addpd xmm5, xmm15
00007ec68bfd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007ec68bfd8c95  ptest xmm4, xmm4
00007ec68bfd8c9a  jnz 0x00007EC68BFDA127
00007ec68bfd8ca0  movaps xmm8, [r15+0x1B0]
00007ec68bfd8ca8  movaps xmm4, xmm9
00007ec68bfd8cac  addpd xmm4, xmm8
00007ec68bfd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007ec68bfd8cb6  ptest xmm2, xmm2
00007ec68bfd8cbb  jnz 0x00007EC68BFDA269
00007ec68bfd8cc1  movaps xmm9, xmm10
00007ec68bfd8cc5  addpd xmm9, xmm8
00007ec68bfd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007ec68bfd8cd0  ptest xmm2, xmm2
00007ec68bfd8cd5  jnz 0x00007EC68BFDA3AB
00007ec68bfd8cdb  movaps xmm10, [r15+0x2F0]
00007ec68bfd8ce3  vmovaps [rsp+0x90], xmm10
00007ec68bfd8cec  vmovaps xmm8, [rsp+0x90]
00007ec68bfd8cf5  por xmm10, xmm8
00007ec68bfd8cfa  movaps xmm8, [r15+0x2E0]
00007ec68bfd8d02  vmovaps [rsp+0x90], xmm8
00007ec68bfd8d0b  vmovaps xmm2, [rsp+0x90]
00007ec68bfd8d14  por xmm8, xmm2
00007ec68bfd8d19  movaps xmm2, [r15+0x2D0]
00007ec68bfd8d21  vmovaps [rsp+0x90], xmm2
00007ec68bfd8d2a  vmovaps [rsp+0xA0], xmm1
00007ec68bfd8d33  vmovaps xmm1, [rsp+0x90]
00007ec68bfd8d3c  por xmm2, xmm1
00007ec68bfd8d40  movaps xmm1, [r15+0x200]
00007ec68bfd8d48  vmovaps [rsp+0x90], xmm1
00007ec68bfd8d51  vmovaps [rsp+0xB0], xmm15
00007ec68bfd8d5a  vmovaps xmm15, [rsp+0x90]
00007ec68bfd8d63  por xmm1, xmm15
00007ec68bfd8d68  movaps xmm15, [r15+0x1C0]
00007ec68bfd8d70  vmovaps [rsp+0x90], xmm15
00007ec68bfd8d79  vmovaps [rsp+0xC0], xmm1
00007ec68bfd8d82  vmovaps xmm1, [rsp+0x90]
00007ec68bfd8d8b  por xmm15, xmm1
00007ec68bfd8d90  movaps xmm1, [r15+0x190]
00007ec68bfd8d98  vmovaps [rsp+0x90], xmm1
00007ec68bfd8da1  vmovaps [rsp+0xD0], xmm15
00007ec68bfd8daa  vmovaps xmm15, [rsp+0x90]
00007ec68bfd8db3  por xmm1, xmm15
00007ec68bfd8db8  movaps xmm15, [r15+0x300]
00007ec68bfd8dc0  vmovaps [rsp+0x90], xmm15
00007ec68bfd8dc9  vmovaps [rsp+0xE0], xmm1
00007ec68bfd8dd2  vmovaps xmm1, [rsp+0x90]
00007ec68bfd8ddb  por xmm15, xmm1
00007ec68bfd8de0  mov rax, [rsp+0x80]
00007ec68bfd8de8  lea r14, [rax+0xA0]
00007ec68bfd8def  movups xmm1, [r13+r14*1]
00007ec68bfd8df5  lea r14, [rax+0xB0]
00007ec68bfd8dfc  vmovaps [rsp+0x80], xmm1
00007ec68bfd8e05  movups xmm1, [r13+r14*1]
00007ec68bfd8e0b  vmovaps [rsp+0x90], xmm1
00007ec68bfd8e14  vmovaps [rsp+0xF0], xmm15
00007ec68bfd8e1d  vmovaps xmm15, [rsp+0xB0]
00007ec68bfd8e26  vmovaps [rsp+0xB0], xmm14
00007ec68bfd8e2f  movaps xmm1, xmm6
00007ec68bfd8e32  addpd xmm1, xmm15
00007ec68bfd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007ec68bfd8e3c  ptest xmm14, xmm14
00007ec68bfd8e42  jnz 0x00007EC68BFDA503
00007ec68bfd8e48  lea r14, [rax+0xF0]
00007ec68bfd8e4f  movups xmm15, [r13+r14*1]
00007ec68bfd8e55  movaps xmm14, xmm4
00007ec68bfd8e59  addpd xmm14, xmm3
00007ec68bfd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007ec68bfd8e64  ptest xmm6, xmm6
00007ec68bfd8e69  jnz 0x00007EC68BFDA64E
00007ec68bfd8e6f  movaps xmm6, xmm9
00007ec68bfd8e73  addpd xmm6, xmm7
00007ec68bfd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007ec68bfd8e7c  ptest xmm4, xmm4
00007ec68bfd8e81  jnz 0x00007EC68BFDA790
00007ec68bfd8e87  vmovaps xmm9, [rsp+0x70]
00007ec68bfd8e8d  vpermilpd xmm9, xmm9, 0x00
00007ec68bfd8e93  vmovaps xmm4, [rsp+0x90]
00007ec68bfd8e9c  movaps xmm7, xmm4
00007ec68bfd8e9f  mulpd xmm7, xmm9
00007ec68bfd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007ec68bfd8ea9  ptest xmm3, xmm3
00007ec68bfd8eae  jnz 0x00007EC68BFDA8D1
00007ec68bfd8eb4  vmovaps xmm9, [rsp+0x50]
00007ec68bfd8eba  vpermilpd xmm9, xmm9, 0x00
00007ec68bfd8ec0  movaps xmm4, xmm15
00007ec68bfd8ec4  mulpd xmm4, xmm9
00007ec68bfd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007ec68bfd8ece  ptest xmm3, xmm3
00007ec68bfd8ed3  jnz 0x00007EC68BFDAA12
00007ec68bfd8ed9  lea r14, [rax+0xE0]
00007ec68bfd8ee0  movups xmm15, [r13+r14*1]
00007ec68bfd8ee6  vmovaps xmm9, [rsp+0x70]
00007ec68bfd8eec  vpermilpd xmm9, xmm9, 0x00
00007ec68bfd8ef2  vmovaps [rsp+0x70], xmm1
00007ec68bfd8ef8  vmovaps xmm1, [rsp+0x80]
00007ec68bfd8f01  vmovaps [rsp+0x80], xmm15
00007ec68bfd8f0a  movaps xmm3, xmm1
00007ec68bfd8f0d  mulpd xmm3, xmm9
00007ec68bfd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007ec68bfd8f17  ptest xmm15, xmm15
00007ec68bfd8f1d  jnz 0x00007EC68BFDAB5E
00007ec68bfd8f23  vmovaps xmm1, [rsp+0xF0]
00007ec68bfd8f2c  vmovaps xmm15, [rsp+0xF0]
00007ec68bfd8f35  por xmm1, xmm15
00007ec68bfd8f3a  movaps [r15+0x300], xmm1
00007ec68bfd8f42  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd8f4b  vmovaps xmm9, [rsp+0xE0]
00007ec68bfd8f54  por xmm15, xmm9
00007ec68bfd8f59  movaps [r15+0x190], xmm15
00007ec68bfd8f61  vmovaps xmm9, [rsp+0x50]
00007ec68bfd8f67  vpermilpd xmm9, xmm9, 0x00
00007ec68bfd8f6d  vmovaps [rsp+0x90], xmm1
00007ec68bfd8f76  vmovaps [rsp+0xE0], xmm15
00007ec68bfd8f7f  vmovaps xmm15, [rsp+0x80]
00007ec68bfd8f88  vmovaps [rsp+0x80], xmm14
00007ec68bfd8f91  movaps xmm1, xmm15
00007ec68bfd8f95  mulpd xmm1, xmm9
00007ec68bfd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007ec68bfd8f9f  ptest xmm14, xmm14
00007ec68bfd8fa5  jnz 0x00007EC68BFDAC9F
00007ec68bfd8fab  lea r14, [rax+0x90]
00007ec68bfd8fb2  movups xmm15, [r13+r14*1]
00007ec68bfd8fb8  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd8fc1  vmovaps xmm9, [rsp+0xD0]
00007ec68bfd8fca  por xmm14, xmm9
00007ec68bfd8fcf  movaps [r15+0x1C0], xmm14
00007ec68bfd8fd7  vmovaps xmm9, [rsp+0xC0]
00007ec68bfd8fe0  vmovaps [rsp+0xD0], xmm1
00007ec68bfd8fe9  vmovaps xmm1, [rsp+0xC0]
00007ec68bfd8ff2  por xmm9, xmm1
00007ec68bfd8ff7  movaps [r15+0x200], xmm9
00007ec68bfd8fff  vmovaps [rsp+0xC0], xmm2
00007ec68bfd9008  vmovaps xmm1, [rsp+0xC0]
00007ec68bfd9011  por xmm2, xmm1
00007ec68bfd9015  movaps [r15+0x2D0], xmm2
00007ec68bfd901d  vmovaps [rsp+0xC0], xmm8
00007ec68bfd9026  vmovaps xmm1, [rsp+0xC0]
00007ec68bfd902f  por xmm8, xmm1
00007ec68bfd9034  movaps [r15+0x2E0], xmm8
00007ec68bfd903c  vmovaps [rsp+0xC0], xmm15
00007ec68bfd9045  movaps xmm1, xmm5
00007ec68bfd9048  addpd xmm1, xmm7
00007ec68bfd904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007ec68bfd9051  ptest xmm15, xmm15
00007ec68bfd9057  jnz 0x00007EC68BFDADEB
00007ec68bfd905d  vmovaps xmm15, [rsp+0x50]
00007ec68bfd9063  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd9069  vmovaps xmm5, [rsp+0xC0]
00007ec68bfd9072  vmovaps [rsp+0xC0], xmm1
00007ec68bfd907b  movaps xmm7, xmm5
00007ec68bfd907e  mulpd xmm7, xmm15
00007ec68bfd9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007ec68bfd9088  ptest xmm1, xmm1
00007ec68bfd908d  jnz 0x00007EC68BFDAF2B
00007ec68bfd9093  lea r14, [rax+0x80]
00007ec68bfd909a  movups xmm1, [r13+r14*1]
00007ec68bfd90a0  vmovaps xmm5, [rsp+0x70]
00007ec68bfd90a6  vmovaps [rsp+0x70], xmm1
00007ec68bfd90ac  movaps xmm15, xmm5
00007ec68bfd90b0  addpd xmm15, xmm3
00007ec68bfd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007ec68bfd90bb  ptest xmm1, xmm1
00007ec68bfd90c0  jnz 0x00007EC68BFDB076
00007ec68bfd90c6  vmovaps xmm5, [rsp+0x80]
00007ec68bfd90cf  movaps xmm1, xmm5
00007ec68bfd90d2  addpd xmm1, xmm4
00007ec68bfd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007ec68bfd90db  ptest xmm3, xmm3
00007ec68bfd90e0  jnz 0x00007EC68BFDB1B8
00007ec68bfd90e6  vmovaps [rsp+0x80], xmm10
00007ec68bfd90ef  vmovaps xmm5, [rsp+0x80]
00007ec68bfd90f8  por xmm10, xmm5
00007ec68bfd90fd  movaps [r15+0x2F0], xmm10
00007ec68bfd9105  vmovaps xmm5, [rsp+0x50]
00007ec68bfd910b  vpermilpd xmm5, xmm5, 0x00
00007ec68bfd9111  vmovaps xmm3, [rsp+0x70]
00007ec68bfd9117  vmovaps [rsp+0x50], xmm1
00007ec68bfd911d  movaps xmm4, xmm3
00007ec68bfd9120  mulpd xmm4, xmm5
00007ec68bfd9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007ec68bfd9129  ptest xmm1, xmm1
00007ec68bfd912e  jnz 0x00007EC68BFDB2F8
00007ec68bfd9134  lea r14, [rax+0xD0]
00007ec68bfd913b  movups xmm1, [r13+r14*1]
00007ec68bfd9141  vmovaps xmm3, [rsp+0xD0]
00007ec68bfd914a  vmovaps [rsp+0x70], xmm1
00007ec68bfd9150  movaps xmm5, xmm6
00007ec68bfd9153  addpd xmm5, xmm3
00007ec68bfd9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007ec68bfd915c  ptest xmm1, xmm1
00007ec68bfd9161  jnz 0x00007EC68BFDB442
00007ec68bfd9167  vmovaps xmm1, [rsp+0x60]
00007ec68bfd916d  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd9173  movaps xmm6, xmm9
00007ec68bfd9177  mulpd xmm6, xmm1
00007ec68bfd917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007ec68bfd9180  ptest xmm3, xmm3
00007ec68bfd9185  jnz 0x00007EC68BFDB582
00007ec68bfd918b  movaps [r15+0x260], xmm6
00007ec68bfd9193  vxorps xmm1, xmm1, xmm1
00007ec68bfd9197  vpbroadcastq xmm1, xmm1
00007ec68bfd919c  movaps [r15+0x1B0], xmm1
00007ec68bfd91a4  vmovaps xmm1, [rsp+0x60]
00007ec68bfd91aa  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd91b0  vmovaps xmm3, [rsp+0x70]
00007ec68bfd91b6  vmovaps [rsp+0x70], xmm15
00007ec68bfd91bc  movaps xmm9, xmm3
00007ec68bfd91c0  mulpd xmm9, xmm1
00007ec68bfd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007ec68bfd91cb  ptest xmm15, xmm15
00007ec68bfd91d1  jnz 0x00007EC68BFDB6C3
00007ec68bfd91d7  lea r14, [rax+0xC0]
00007ec68bfd91de  movups xmm1, [r13+r14*1]
00007ec68bfd91e4  vmovaps xmm3, [rsp+0xC0]
00007ec68bfd91ed  vmovaps [rsp+0x80], xmm1
00007ec68bfd91f6  movaps xmm15, xmm3
00007ec68bfd91fa  addpd xmm15, xmm7
00007ec68bfd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007ec68bfd9205  ptest xmm1, xmm1
00007ec68bfd920a  jnz 0x00007EC68BFDB80F
00007ec68bfd9210  vmovaps [rsp+0xC0], xmm13
00007ec68bfd9219  vmovaps xmm1, [rsp+0xC0]
00007ec68bfd9222  por xmm13, xmm1
00007ec68bfd9227  movaps [r15+0x270], xmm13
00007ec68bfd922f  vmovaps xmm1, [rsp+0xB0]
00007ec68bfd9238  vmovaps xmm7, [rsp+0xB0]
00007ec68bfd9241  por xmm1, xmm7
00007ec68bfd9245  movaps [r15+0x1A0], xmm1
00007ec68bfd924d  vmovaps xmm1, [rsp+0x60]
00007ec68bfd9253  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd9259  vmovaps [rsp+0xB0], xmm1
00007ec68bfd9262  vmovaps xmm1, [rsp+0x80]
00007ec68bfd926b  vmovaps [rsp+0x80], xmm15
00007ec68bfd9274  vmovaps xmm15, [rsp+0xB0]
00007ec68bfd927d  vmovaps [rsp+0xB0], xmm14
00007ec68bfd9286  movaps xmm3, xmm1
00007ec68bfd9289  mulpd xmm3, xmm15
00007ec68bfd928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007ec68bfd9293  ptest xmm14, xmm14
00007ec68bfd9299  jnz 0x00007EC68BFDB951
00007ec68bfd929f  lea r14, [rax+0x20]
00007ec68bfd92a3  movups xmm1, [r13+r14*1]
00007ec68bfd92a9  movaps [r15+0x110], xmm1
00007ec68bfd92b1  vmovaps xmm14, [rsp+0x70]
00007ec68bfd92b7  vmovaps [rsp+0x70], xmm1
00007ec68bfd92bd  movaps xmm15, xmm14
00007ec68bfd92c1  addpd xmm15, xmm4
00007ec68bfd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007ec68bfd92cc  ptest xmm1, xmm1
00007ec68bfd92d1  jnz 0x00007EC68BFDBA9C
00007ec68bfd92d7  vmovaps xmm1, [rsp+0x60]
00007ec68bfd92dd  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd92e3  movaps xmm14, xmm2
00007ec68bfd92e7  mulpd xmm14, xmm1
00007ec68bfd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007ec68bfd92f2  ptest xmm4, xmm4
00007ec68bfd92f7  jnz 0x00007EC68BFDBBDF
00007ec68bfd92fd  vmovaps xmm4, [rsp+0x50]
00007ec68bfd9303  movaps xmm1, xmm4
00007ec68bfd9306  addpd xmm1, xmm9
00007ec68bfd930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007ec68bfd9310  ptest xmm2, xmm2
00007ec68bfd9315  jnz 0x00007EC68BFDBD21
00007ec68bfd931b  vmovaps xmm9, [rsp+0x30]
00007ec68bfd9321  vpermilpd xmm9, xmm9, 0x00
00007ec68bfd9327  vmovaps xmm2, [rsp+0x70]
00007ec68bfd932d  vmovaps [rsp+0x50], xmm1
00007ec68bfd9333  movaps xmm4, xmm2
00007ec68bfd9336  mulpd xmm4, xmm9
00007ec68bfd933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007ec68bfd9340  ptest xmm1, xmm1
00007ec68bfd9345  jnz 0x00007EC68BFDBE62
00007ec68bfd934b  vmovaps xmm1, [rsp+0x30]
00007ec68bfd9351  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd9357  vmovaps xmm2, [rsp+0x90]
00007ec68bfd9360  vmovaps [rsp+0x60], xmm15
00007ec68bfd9366  movaps xmm9, xmm2
00007ec68bfd936a  mulpd xmm9, xmm1
00007ec68bfd936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007ec68bfd9375  ptest xmm15, xmm15
00007ec68bfd937b  jnz 0x00007EC68BFDBFA3
00007ec68bfd9381  vmovaps xmm15, [rsp+0x80]
00007ec68bfd938a  movaps xmm1, xmm15
00007ec68bfd938e  addpd xmm1, xmm6
00007ec68bfd9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007ec68bfd9397  ptest xmm2, xmm2
00007ec68bfd939c  jnz 0x00007EC68BFDC0E5
00007ec68bfd93a2  movaps xmm15, xmm5
00007ec68bfd93a6  addpd xmm15, xmm3
00007ec68bfd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007ec68bfd93b1  ptest xmm6, xmm6
00007ec68bfd93b6  jnz 0x00007EC68BFDC226
00007ec68bfd93bc  vmovaps xmm6, [rsp+0x30]
00007ec68bfd93c2  vpermilpd xmm6, xmm6, 0x00
00007ec68bfd93c8  movaps xmm5, xmm8
00007ec68bfd93cc  mulpd xmm5, xmm6
00007ec68bfd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007ec68bfd93d5  ptest xmm3, xmm3
00007ec68bfd93da  jnz 0x00007EC68BFDC368
00007ec68bfd93e0  vmovaps xmm8, [rsp+0x30]
00007ec68bfd93e6  vpermilpd xmm8, xmm8, 0x00
00007ec68bfd93ec  movaps xmm6, xmm10
00007ec68bfd93f0  mulpd xmm6, xmm8
00007ec68bfd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007ec68bfd93fa  ptest xmm3, xmm3
00007ec68bfd93ff  jnz 0x00007EC68BFDC4A9
00007ec68bfd9405  vmovaps xmm8, [rsp+0x60]
00007ec68bfd940b  movaps xmm10, xmm8
00007ec68bfd940f  addpd xmm10, xmm14
00007ec68bfd9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007ec68bfd941a  ptest xmm3, xmm3
00007ec68bfd941f  jnz 0x00007EC68BFDC5EB
00007ec68bfd9425  vmovaps xmm8, [rsp+0x50]
00007ec68bfd942b  movaps xmm14, xmm8
00007ec68bfd942f  addpd xmm14, xmm4
00007ec68bfd9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007ec68bfd943a  ptest xmm3, xmm3
00007ec68bfd943f  jnz 0x00007EC68BFDC72F
00007ec68bfd9445  vmovaps xmm8, [rsp+0x40]
00007ec68bfd944b  vpermilpd xmm8, xmm8, 0x00
00007ec68bfd9451  movaps xmm4, xmm13
00007ec68bfd9455  mulpd xmm4, xmm8
00007ec68bfd945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007ec68bfd945f  ptest xmm3, xmm3
00007ec68bfd9464  jnz 0x00007EC68BFDC872
00007ec68bfd946a  movaps xmm13, xmm15
00007ec68bfd946e  addpd xmm13, xmm9
00007ec68bfd9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007ec68bfd9479  ptest xmm8, xmm8
00007ec68bfd947f  jnz 0x00007EC68BFDC9B4
00007ec68bfd9485  movaps xmm15, xmm1
00007ec68bfd9489  addpd xmm15, xmm5
00007ec68bfd948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007ec68bfd9494  ptest xmm9, xmm9
00007ec68bfd949a  jnz 0x00007EC68BFDCAF8
00007ec68bfd94a0  vmovaps [rsp+0x30], xmm11
00007ec68bfd94a6  vmovaps xmm1, [rsp+0x30]
00007ec68bfd94ac  por xmm11, xmm1
00007ec68bfd94b1  movaps [r15+0x250], xmm11
00007ec68bfd94b9  vmovaps [rsp+0x30], xmm12
00007ec68bfd94bf  vmovaps xmm1, [rsp+0x30]
00007ec68bfd94c5  por xmm12, xmm1
00007ec68bfd94ca  movaps [r15+0x2A0], xmm12
00007ec68bfd94d2  vmovaps xmm1, [rsp+0xA0]
00007ec68bfd94db  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd94e4  por xmm1, xmm11
00007ec68bfd94e9  movaps [r15+0x1D0], xmm1
00007ec68bfd94f1  lea r14, [rax+0x40]
00007ec68bfd94f5  movups xmm1, [r13+r14*1]
00007ec68bfd94fb  movaps [r15+0x2C0], xmm1
00007ec68bfd9503  vmovaps xmm11, [rsp+0x40]
00007ec68bfd9509  vpermilpd xmm11, xmm11, 0x00
00007ec68bfd950f  vmovaps xmm8, [rsp+0xE0]
00007ec68bfd9518  movaps xmm9, xmm8
00007ec68bfd951c  mulpd xmm9, xmm11
00007ec68bfd9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007ec68bfd9527  ptest xmm5, xmm5
00007ec68bfd952c  jnz 0x00007EC68BFDCC44
00007ec68bfd9532  movaps xmm11, xmm10
00007ec68bfd9536  addpd xmm11, xmm6
00007ec68bfd953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007ec68bfd9541  ptest xmm8, xmm8
00007ec68bfd9547  jnz 0x00007EC68BFDCD88
00007ec68bfd954d  movaps xmm10, xmm14
00007ec68bfd9551  addpd xmm10, xmm4
00007ec68bfd9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007ec68bfd955c  ptest xmm8, xmm8
00007ec68bfd9562  jnz 0x00007EC68BFDCECB
00007ec68bfd9568  vmovaps xmm14, [rsp+0x40]
00007ec68bfd956e  vpermilpd xmm14, xmm14, 0x00
00007ec68bfd9574  movaps xmm8, xmm1
00007ec68bfd9578  mulpd xmm8, xmm14
00007ec68bfd957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007ec68bfd9583  ptest xmm6, xmm6
00007ec68bfd9588  jnz 0x00007EC68BFDD00E
00007ec68bfd958e  movaps xmm1, [r15+0x2B0]
00007ec68bfd9596  vmovaps xmm14, [rsp+0x40]
00007ec68bfd959c  vpermilpd xmm14, xmm14, 0x00
00007ec68bfd95a2  movaps xmm6, xmm1
00007ec68bfd95a5  mulpd xmm6, xmm14
00007ec68bfd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007ec68bfd95af  ptest xmm5, xmm5
00007ec68bfd95b4  jnz 0x00007EC68BFDD151
00007ec68bfd95ba  vmovaps xmm1, [rsp+0x10]
00007ec68bfd95c0  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd95c6  movaps xmm14, xmm12
00007ec68bfd95ca  mulpd xmm14, xmm1
00007ec68bfd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007ec68bfd95d5  ptest xmm5, xmm5
00007ec68bfd95da  jnz 0x00007EC68BFDD292
00007ec68bfd95e0  movaps xmm1, xmm13
00007ec68bfd95e4  addpd xmm1, xmm9
00007ec68bfd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007ec68bfd95ee  ptest xmm12, xmm12
00007ec68bfd95f4  jnz 0x00007EC68BFDD3D5
00007ec68bfd95fa  vmovaps xmm13, [rsp+0x10]
00007ec68bfd9600  vpermilpd xmm13, xmm13, 0x00
00007ec68bfd9606  movaps xmm12, xmm7
00007ec68bfd960a  mulpd xmm12, xmm13
00007ec68bfd960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007ec68bfd9615  ptest xmm9, xmm9
00007ec68bfd961b  jnz 0x00007EC68BFDD517
00007ec68bfd9621  movaps xmm13, xmm15
00007ec68bfd9625  addpd xmm13, xmm8
00007ec68bfd962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007ec68bfd9630  ptest xmm9, xmm9
00007ec68bfd9636  jnz 0x00007EC68BFDD65A
00007ec68bfd963c  movaps xmm15, [r15+0x290]
00007ec68bfd9644  vmovaps xmm9, [rsp+0x10]
00007ec68bfd964a  vpermilpd xmm9, xmm9, 0x00
00007ec68bfd9650  movaps xmm8, xmm15
00007ec68bfd9654  mulpd xmm8, xmm9
00007ec68bfd9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007ec68bfd965f  ptest xmm7, xmm7
00007ec68bfd9664  jnz 0x00007EC68BFDD79E
00007ec68bfd966a  movaps xmm15, xmm11
00007ec68bfd966e  addpd xmm15, xmm6
00007ec68bfd9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007ec68bfd9679  ptest xmm9, xmm9
00007ec68bfd967f  jnz 0x00007EC68BFDD8E2
00007ec68bfd9685  movaps xmm11, [r15+0x1E0]
00007ec68bfd968d  vmovaps xmm9, [rsp+0x10]
00007ec68bfd9693  vpermilpd xmm9, xmm9, 0x00
00007ec68bfd9699  movaps xmm7, xmm11
00007ec68bfd969d  mulpd xmm7, xmm9
00007ec68bfd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007ec68bfd96a7  ptest xmm6, xmm6
00007ec68bfd96ac  jnz 0x00007EC68BFDDA25
00007ec68bfd96b2  movaps xmm11, xmm10
00007ec68bfd96b6  addpd xmm11, xmm14
00007ec68bfd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007ec68bfd96c1  ptest xmm9, xmm9
00007ec68bfd96c7  jnz 0x00007EC68BFDDB67
00007ec68bfd96cd  lea r14, [rax+0x70]
00007ec68bfd96d1  movups xmm14, [r13+r14*1]
00007ec68bfd96d7  movaps [r15+0x240], xmm14
00007ec68bfd96df  movaps xmm10, xmm1
00007ec68bfd96e3  addpd xmm10, xmm12
00007ec68bfd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007ec68bfd96ee  ptest xmm9, xmm9
00007ec68bfd96f4  jnz 0x00007EC68BFDDCB5
00007ec68bfd96fa  movaps [r15+0x170], xmm10
00007ec68bfd9702  vmovaps xmm1, [rsp+0x20]
00007ec68bfd9708  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd970e  movaps xmm12, xmm14
00007ec68bfd9712  mulpd xmm12, xmm1
00007ec68bfd9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007ec68bfd971d  ptest xmm9, xmm9
00007ec68bfd9723  jnz 0x00007EC68BFDDDF8
00007ec68bfd9729  vmovaps xmm1, [rsp+0x20]
00007ec68bfd972f  vpermilpd xmm1, xmm1, 0x00
00007ec68bfd9735  vmovaps xmm9, [rsp+0xB0]
00007ec68bfd973e  movaps xmm14, xmm9
00007ec68bfd9742  mulpd xmm14, xmm1
00007ec68bfd9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007ec68bfd974d  ptest xmm6, xmm6
00007ec68bfd9752  jnz 0x00007EC68BFDDF3B
00007ec68bfd9758  movaps [r15+0x180], xmm14
00007ec68bfd9760  movaps xmm1, xmm13
00007ec68bfd9764  addpd xmm1, xmm8
00007ec68bfd9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007ec68bfd976e  ptest xmm9, xmm9
00007ec68bfd9774  jnz 0x00007EC68BFDE07E
00007ec68bfd977a  movaps [r15+0x210], xmm1
00007ec68bfd9782  movups xmm13, [r13+rax*1]
00007ec68bfd9788  lea r14, [rax+0x10]
00007ec68bfd978c  movups xmm9, [r13+r14*1]
00007ec68bfd9792  movaps [r15+0x230], xmm9
00007ec68bfd979a  movaps xmm8, xmm15
00007ec68bfd979e  addpd xmm8, xmm7
00007ec68bfd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007ec68bfd97a9  ptest xmm6, xmm6
00007ec68bfd97ae  jnz 0x00007EC68BFDE1D4
00007ec68bfd97b4  movaps [r15+0x130], xmm8
00007ec68bfd97bc  vmovaps xmm15, [rsp+0x20]
00007ec68bfd97c2  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd97c8  movaps xmm7, xmm9
00007ec68bfd97cc  mulpd xmm7, xmm15
00007ec68bfd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007ec68bfd97d6  ptest xmm6, xmm6
00007ec68bfd97db  jnz 0x00007EC68BFDE317
00007ec68bfd97e1  movaps [r15+0x220], xmm7
00007ec68bfd97e9  vmovaps xmm15, [rsp+0x20]
00007ec68bfd97ef  vpermilpd xmm15, xmm15, 0x00
00007ec68bfd97f5  movaps xmm9, xmm13
00007ec68bfd97f9  mulpd xmm9, xmm15
00007ec68bfd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007ec68bfd9804  ptest xmm6, xmm6
00007ec68bfd9809  jnz 0x00007EC68BFDE459
00007ec68bfd980f  movaps xmm15, xmm11
00007ec68bfd9813  addpd xmm15, xmm12
00007ec68bfd9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007ec68bfd981e  ptest xmm13, xmm13
00007ec68bfd9824  jnz 0x00007EC68BFDE59D
00007ec68bfd982a  movaps [r15+0x140], xmm15
00007ec68bfd9832  movaps xmm13, xmm10
00007ec68bfd9836  addpd xmm13, xmm14
00007ec68bfd983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007ec68bfd9841  ptest xmm12, xmm12
00007ec68bfd9847  jnz 0x00007EC68BFDE6E1
00007ec68bfd984d  movaps [r15+0x150], xmm13
00007ec68bfd9855  movaps xmm14, xmm1
00007ec68bfd9859  addpd xmm14, xmm7
00007ec68bfd985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007ec68bfd9864  ptest xmm12, xmm12
00007ec68bfd986a  jnz 0x00007EC68BFDE825
00007ec68bfd9870  movaps [r15+0x160], xmm14
00007ec68bfd9878  movaps xmm1, xmm8
00007ec68bfd987c  addpd xmm1, xmm9
00007ec68bfd9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007ec68bfd9886  ptest xmm12, xmm12
00007ec68bfd988c  jnz 0x00007EC68BFDE967
00007ec68bfd9892  movaps [r15+0x120], xmm1
00007ec68bfd989a  movups [r13+r11*1], xmm15
00007ec68bfd98a0  lea rax, [r11+0x10]
00007ec68bfd98a4  movups [r13+rax*1], xmm13
00007ec68bfd98aa  lea rax, [r11+0x20]
00007ec68bfd98ae  movups [r13+rax*1], xmm14
00007ec68bfd98b4  lea rax, [r11+0x30]
00007ec68bfd98b8  movups [r13+rax*1], xmm1
00007ec68bfd98be  mov eax, [r15+0x108]
00007ec68bfd98c5  sahf
00007ec68bfd98c6  jnz 0x00007EC68BFD98F8
00007ec68bfd98c8  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd98d0  jz 0x00007EC68BFDEAE0
00007ec68bfd98d6  nop [rax+rax*1], ax
00007ec68bfd98df  nop [rax+rax*1], eax
00007ec68bfd98e7  mov eax, 0x4106D0
00007ec68bfd98ec  mov [r15+0x100], rax
00007ec68bfd98f3  jmp 0x00007EC68BDFE110
00007ec68bfd98f8  cmp dword ptr [r15+0x318], 0x00
00007ec68bfd9900  jz 0x00007EC68BFD89C0
00007ec68bfd9906  nop [rax+rax*1], ax
00007ec68bfd990f  nop [rax+rax*1], eax
00007ec68bfd9917  mov eax, 0x410504
00007ec68bfd991c  mov [r15+0x100], rax
00007ec68bfd9923  jmp 0x00007EC68BDFE110
00007ec68bfd9928  int3
00007ec68bfd9929  call 0x00007EC68BE0A4B0
00007ec68bfd992e  jmp 0x00007EC68BFD8A08
00007ec68bfd9933  call 0x00007EC68BE09240
00007ec68bfd9938  jmp 0x00007EC68BFD8A12
00007ec68bfd993d  call 0x00007EC68BE0A4B0
00007ec68bfd9942  jmp 0x00007EC68BFD8A6F
00007ec68bfd9947  call 0x00007EC68BE09240
00007ec68bfd994c  jmp 0x00007EC68BFD8A79
00007ec68bfd9951  call 0x00007EC68BE0A4B0
00007ec68bfd9956  jmp 0x00007EC68BFD8ABD
00007ec68bfd995b  call 0x00007EC68BE09240
00007ec68bfd9960  jmp 0x00007EC68BFD8AC7
00007ec68bfd9965  call 0x00007EC68BEB47C0
00007ec68bfd996a  jmp 0x00007EC68BFD8B06
00007ec68bfd996f  call 0x00007EC68BE0B720
00007ec68bfd9974  jmp 0x00007EC68BFD8B1A
00007ec68bfd9979  call 0x00007EC68BEBFC30
00007ec68bfd997e  jmp 0x00007EC68BFD8B38
00007ec68bfd9983  call 0x00007EC68BEBE9C0
00007ec68bfd9988  jmp 0x00007EC68BFD8B42
00007ec68bfd998d  call 0x00007EC68BEBD750
00007ec68bfd9992  jmp 0x00007EC68BFD8B4C
00007ec68bfd9997  sub rsp, 0x08
00007ec68bfd999b  push rax
00007ec68bfd999c  push rcx
00007ec68bfd999d  push rdx
00007ec68bfd999e  push rdi
00007ec68bfd999f  push rsi
00007ec68bfd99a0  push r8
00007ec68bfd99a2  push r9
00007ec68bfd99a4  push r10
00007ec68bfd99a6  push r11
00007ec68bfd99a8  sub rsp, 0xF0
00007ec68bfd99af  vmovaps [rsp], xmm0
00007ec68bfd99b4  vmovaps [rsp+0x10], xmm1
00007ec68bfd99ba  vmovaps [rsp+0x20], xmm2
00007ec68bfd99c0  vmovaps [rsp+0x30], xmm3
00007ec68bfd99c6  vmovaps [rsp+0x40], xmm4
00007ec68bfd99cc  vmovaps [rsp+0x50], xmm5
00007ec68bfd99d2  vmovaps [rsp+0x60], xmm6
00007ec68bfd99d8  vmovaps [rsp+0x70], xmm7
00007ec68bfd99de  vmovaps [rsp+0x80], xmm9
00007ec68bfd99e7  vmovaps [rsp+0x90], xmm10
00007ec68bfd99f0  vmovaps [rsp+0xA0], xmm11
00007ec68bfd99f9  vmovaps [rsp+0xB0], xmm12
00007ec68bfd9a02  vmovaps [rsp+0xC0], xmm13
00007ec68bfd9a0b  vmovaps [rsp+0xD0], xmm14
00007ec68bfd9a14  vmovaps [rsp+0xE0], xmm15
00007ec68bfd9a1d  sub rsp, 0x30
00007ec68bfd9a21  movaps [rsp], xmm8
00007ec68bfd9a26  movaps [rsp+0x10], xmm12
00007ec68bfd9a2c  movaps [rsp+0x20], xmm15
00007ec68bfd9a32  lea rdi, [rsp]
00007ec68bfd9a36  mov esi, 0x00
00007ec68bfd9a3b  mov rax, 0x57D97DADF530
00007ec68bfd9a45  call rax
00007ec68bfd9a47  movaps xmm8, [rsp]
00007ec68bfd9a4c  add rsp, 0x30
00007ec68bfd9a50  vmovaps xmm0, [rsp]
00007ec68bfd9a55  vmovaps xmm1, [rsp+0x10]
00007ec68bfd9a5b  vmovaps xmm2, [rsp+0x20]
00007ec68bfd9a61  vmovaps xmm3, [rsp+0x30]
00007ec68bfd9a67  vmovaps xmm4, [rsp+0x40]
00007ec68bfd9a6d  vmovaps xmm5, [rsp+0x50]
00007ec68bfd9a73  vmovaps xmm6, [rsp+0x60]
00007ec68bfd9a79  vmovaps xmm7, [rsp+0x70]
00007ec68bfd9a7f  vmovaps xmm9, [rsp+0x80]
00007ec68bfd9a88  vmovaps xmm10, [rsp+0x90]
00007ec68bfd9a91  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd9a9a  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd9aa3  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd9aac  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd9ab5  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd9abe  add rsp, 0xF0
00007ec68bfd9ac5  pop r11
00007ec68bfd9ac7  pop r10
00007ec68bfd9ac9  pop r9
00007ec68bfd9acb  pop r8
00007ec68bfd9acd  pop rsi
00007ec68bfd9ace  pop rdi
00007ec68bfd9acf  pop rdx
00007ec68bfd9ad0  pop rcx
00007ec68bfd9ad1  pop rax
00007ec68bfd9ad2  add rsp, 0x08
00007ec68bfd9ad6  jmp 0x00007EC68BFD8B7A
00007ec68bfd9adb  sub rsp, 0x08
00007ec68bfd9adf  push rax
00007ec68bfd9ae0  push rcx
00007ec68bfd9ae1  push rdx
00007ec68bfd9ae2  push rdi
00007ec68bfd9ae3  push rsi
00007ec68bfd9ae4  push r8
00007ec68bfd9ae6  push r9
00007ec68bfd9ae8  push r10
00007ec68bfd9aea  push r11
00007ec68bfd9aec  sub rsp, 0xF0
00007ec68bfd9af3  vmovaps [rsp], xmm0
00007ec68bfd9af8  vmovaps [rsp+0x10], xmm1
00007ec68bfd9afe  vmovaps [rsp+0x20], xmm2
00007ec68bfd9b04  vmovaps [rsp+0x30], xmm3
00007ec68bfd9b0a  vmovaps [rsp+0x40], xmm4
00007ec68bfd9b10  vmovaps [rsp+0x50], xmm5
00007ec68bfd9b16  vmovaps [rsp+0x60], xmm6
00007ec68bfd9b1c  vmovaps [rsp+0x70], xmm8
00007ec68bfd9b22  vmovaps [rsp+0x80], xmm9
00007ec68bfd9b2b  vmovaps [rsp+0x90], xmm10
00007ec68bfd9b34  vmovaps [rsp+0xA0], xmm11
00007ec68bfd9b3d  vmovaps [rsp+0xB0], xmm12
00007ec68bfd9b46  vmovaps [rsp+0xC0], xmm13
00007ec68bfd9b4f  vmovaps [rsp+0xD0], xmm14
00007ec68bfd9b58  vmovaps [rsp+0xE0], xmm15
00007ec68bfd9b61  sub rsp, 0x30
00007ec68bfd9b65  movaps [rsp], xmm7
00007ec68bfd9b69  movaps [rsp+0x10], xmm9
00007ec68bfd9b6f  movaps [rsp+0x20], xmm15
00007ec68bfd9b75  lea rdi, [rsp]
00007ec68bfd9b79  mov esi, 0x00
00007ec68bfd9b7e  mov rax, 0x57D97DADF530
00007ec68bfd9b88  call rax
00007ec68bfd9b8a  movaps xmm7, [rsp]
00007ec68bfd9b8e  add rsp, 0x30
00007ec68bfd9b92  vmovaps xmm0, [rsp]
00007ec68bfd9b97  vmovaps xmm1, [rsp+0x10]
00007ec68bfd9b9d  vmovaps xmm2, [rsp+0x20]
00007ec68bfd9ba3  vmovaps xmm3, [rsp+0x30]
00007ec68bfd9ba9  vmovaps xmm4, [rsp+0x40]
00007ec68bfd9baf  vmovaps xmm5, [rsp+0x50]
00007ec68bfd9bb5  vmovaps xmm6, [rsp+0x60]
00007ec68bfd9bbb  vmovaps xmm8, [rsp+0x70]
00007ec68bfd9bc1  vmovaps xmm9, [rsp+0x80]
00007ec68bfd9bca  vmovaps xmm10, [rsp+0x90]
00007ec68bfd9bd3  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd9bdc  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd9be5  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd9bee  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd9bf7  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd9c00  add rsp, 0xF0
00007ec68bfd9c07  pop r11
00007ec68bfd9c09  pop r10
00007ec68bfd9c0b  pop r9
00007ec68bfd9c0d  pop r8
00007ec68bfd9c0f  pop rsi
00007ec68bfd9c10  pop rdi
00007ec68bfd9c11  pop rdx
00007ec68bfd9c12  pop rcx
00007ec68bfd9c13  pop rax
00007ec68bfd9c14  add rsp, 0x08
00007ec68bfd9c18  jmp 0x00007EC68BFD8BA8
00007ec68bfd9c1d  sub rsp, 0x08
00007ec68bfd9c21  push rax
00007ec68bfd9c22  push rcx
00007ec68bfd9c23  push rdx
00007ec68bfd9c24  push rdi
00007ec68bfd9c25  push rsi
00007ec68bfd9c26  push r8
00007ec68bfd9c28  push r9
00007ec68bfd9c2a  push r10
00007ec68bfd9c2c  push r11
00007ec68bfd9c2e  sub rsp, 0xF0
00007ec68bfd9c35  vmovaps [rsp], xmm0
00007ec68bfd9c3a  vmovaps [rsp+0x10], xmm1
00007ec68bfd9c40  vmovaps [rsp+0x20], xmm2
00007ec68bfd9c46  vmovaps [rsp+0x30], xmm3
00007ec68bfd9c4c  vmovaps [rsp+0x40], xmm4
00007ec68bfd9c52  vmovaps [rsp+0x50], xmm5
00007ec68bfd9c58  vmovaps [rsp+0x60], xmm6
00007ec68bfd9c5e  vmovaps [rsp+0x70], xmm7
00007ec68bfd9c64  vmovaps [rsp+0x80], xmm8
00007ec68bfd9c6d  vmovaps [rsp+0x90], xmm10
00007ec68bfd9c76  vmovaps [rsp+0xA0], xmm11
00007ec68bfd9c7f  vmovaps [rsp+0xB0], xmm12
00007ec68bfd9c88  vmovaps [rsp+0xC0], xmm13
00007ec68bfd9c91  vmovaps [rsp+0xD0], xmm14
00007ec68bfd9c9a  vmovaps [rsp+0xE0], xmm15
00007ec68bfd9ca3  sub rsp, 0x30
00007ec68bfd9ca7  movaps [rsp], xmm9
00007ec68bfd9cac  movaps [rsp+0x10], xmm12
00007ec68bfd9cb2  movaps [rsp+0x20], xmm10
00007ec68bfd9cb8  lea rdi, [rsp]
00007ec68bfd9cbc  mov esi, 0x00
00007ec68bfd9cc1  mov rax, 0x57D97DADF530
00007ec68bfd9ccb  call rax
00007ec68bfd9ccd  movaps xmm9, [rsp]
00007ec68bfd9cd2  add rsp, 0x30
00007ec68bfd9cd6  vmovaps xmm0, [rsp]
00007ec68bfd9cdb  vmovaps xmm1, [rsp+0x10]
00007ec68bfd9ce1  vmovaps xmm2, [rsp+0x20]
00007ec68bfd9ce7  vmovaps xmm3, [rsp+0x30]
00007ec68bfd9ced  vmovaps xmm4, [rsp+0x40]
00007ec68bfd9cf3  vmovaps xmm5, [rsp+0x50]
00007ec68bfd9cf9  vmovaps xmm6, [rsp+0x60]
00007ec68bfd9cff  vmovaps xmm7, [rsp+0x70]
00007ec68bfd9d05  vmovaps xmm8, [rsp+0x80]
00007ec68bfd9d0e  vmovaps xmm10, [rsp+0x90]
00007ec68bfd9d17  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd9d20  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd9d29  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd9d32  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd9d3b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd9d44  add rsp, 0xF0
00007ec68bfd9d4b  pop r11
00007ec68bfd9d4d  pop r10
00007ec68bfd9d4f  pop r9
00007ec68bfd9d51  pop r8
00007ec68bfd9d53  pop rsi
00007ec68bfd9d54  pop rdi
00007ec68bfd9d55  pop rdx
00007ec68bfd9d56  pop rcx
00007ec68bfd9d57  pop rax
00007ec68bfd9d58  add rsp, 0x08
00007ec68bfd9d5c  jmp 0x00007EC68BFD8BCC
00007ec68bfd9d61  sub rsp, 0x08
00007ec68bfd9d65  push rax
00007ec68bfd9d66  push rcx
00007ec68bfd9d67  push rdx
00007ec68bfd9d68  push rdi
00007ec68bfd9d69  push rsi
00007ec68bfd9d6a  push r8
00007ec68bfd9d6c  push r9
00007ec68bfd9d6e  push r10
00007ec68bfd9d70  push r11
00007ec68bfd9d72  sub rsp, 0xF0
00007ec68bfd9d79  vmovaps [rsp], xmm0
00007ec68bfd9d7e  vmovaps [rsp+0x10], xmm1
00007ec68bfd9d84  vmovaps [rsp+0x20], xmm2
00007ec68bfd9d8a  vmovaps [rsp+0x30], xmm3
00007ec68bfd9d90  vmovaps [rsp+0x40], xmm4
00007ec68bfd9d96  vmovaps [rsp+0x50], xmm5
00007ec68bfd9d9c  vmovaps [rsp+0x60], xmm6
00007ec68bfd9da2  vmovaps [rsp+0x70], xmm7
00007ec68bfd9da8  vmovaps [rsp+0x80], xmm8
00007ec68bfd9db1  vmovaps [rsp+0x90], xmm9
00007ec68bfd9dba  vmovaps [rsp+0xA0], xmm11
00007ec68bfd9dc3  vmovaps [rsp+0xB0], xmm12
00007ec68bfd9dcc  vmovaps [rsp+0xC0], xmm13
00007ec68bfd9dd5  vmovaps [rsp+0xD0], xmm14
00007ec68bfd9dde  vmovaps [rsp+0xE0], xmm15
00007ec68bfd9de7  sub rsp, 0x30
00007ec68bfd9deb  movaps [rsp], xmm10
00007ec68bfd9df0  movaps [rsp+0x10], xmm12
00007ec68bfd9df6  movaps [rsp+0x20], xmm11
00007ec68bfd9dfc  lea rdi, [rsp]
00007ec68bfd9e00  mov esi, 0x00
00007ec68bfd9e05  mov rax, 0x57D97DADF530
00007ec68bfd9e0f  call rax
00007ec68bfd9e11  movaps xmm10, [rsp]
00007ec68bfd9e16  add rsp, 0x30
00007ec68bfd9e1a  vmovaps xmm0, [rsp]
00007ec68bfd9e1f  vmovaps xmm1, [rsp+0x10]
00007ec68bfd9e25  vmovaps xmm2, [rsp+0x20]
00007ec68bfd9e2b  vmovaps xmm3, [rsp+0x30]
00007ec68bfd9e31  vmovaps xmm4, [rsp+0x40]
00007ec68bfd9e37  vmovaps xmm5, [rsp+0x50]
00007ec68bfd9e3d  vmovaps xmm6, [rsp+0x60]
00007ec68bfd9e43  vmovaps xmm7, [rsp+0x70]
00007ec68bfd9e49  vmovaps xmm8, [rsp+0x80]
00007ec68bfd9e52  vmovaps xmm9, [rsp+0x90]
00007ec68bfd9e5b  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd9e64  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd9e6d  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd9e76  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd9e7f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd9e88  add rsp, 0xF0
00007ec68bfd9e8f  pop r11
00007ec68bfd9e91  pop r10
00007ec68bfd9e93  pop r9
00007ec68bfd9e95  pop r8
00007ec68bfd9e97  pop rsi
00007ec68bfd9e98  pop rdi
00007ec68bfd9e99  pop rdx
00007ec68bfd9e9a  pop rcx
00007ec68bfd9e9b  pop rax
00007ec68bfd9e9c  add rsp, 0x08
00007ec68bfd9ea0  jmp 0x00007EC68BFD8BE6
00007ec68bfd9ea5  sub rsp, 0x08
00007ec68bfd9ea9  push rax
00007ec68bfd9eaa  push rcx
00007ec68bfd9eab  push rdx
00007ec68bfd9eac  push rdi
00007ec68bfd9ead  push rsi
00007ec68bfd9eae  push r8
00007ec68bfd9eb0  push r9
00007ec68bfd9eb2  push r10
00007ec68bfd9eb4  push r11
00007ec68bfd9eb6  sub rsp, 0xF0
00007ec68bfd9ebd  vmovaps [rsp], xmm0
00007ec68bfd9ec2  vmovaps [rsp+0x10], xmm1
00007ec68bfd9ec8  vmovaps [rsp+0x20], xmm2
00007ec68bfd9ece  vmovaps [rsp+0x30], xmm3
00007ec68bfd9ed4  vmovaps [rsp+0x40], xmm4
00007ec68bfd9eda  vmovaps [rsp+0x50], xmm5
00007ec68bfd9ee0  vmovaps [rsp+0x60], xmm7
00007ec68bfd9ee6  vmovaps [rsp+0x70], xmm8
00007ec68bfd9eec  vmovaps [rsp+0x80], xmm9
00007ec68bfd9ef5  vmovaps [rsp+0x90], xmm10
00007ec68bfd9efe  vmovaps [rsp+0xA0], xmm11
00007ec68bfd9f07  vmovaps [rsp+0xB0], xmm12
00007ec68bfd9f10  vmovaps [rsp+0xC0], xmm13
00007ec68bfd9f19  vmovaps [rsp+0xD0], xmm14
00007ec68bfd9f22  vmovaps [rsp+0xE0], xmm15
00007ec68bfd9f2b  sub rsp, 0x30
00007ec68bfd9f2f  movaps [rsp], xmm6
00007ec68bfd9f33  movaps [rsp+0x10], xmm12
00007ec68bfd9f39  movaps [rsp+0x20], xmm11
00007ec68bfd9f3f  lea rdi, [rsp]
00007ec68bfd9f43  mov esi, 0x00
00007ec68bfd9f48  mov rax, 0x57D97DADF530
00007ec68bfd9f52  call rax
00007ec68bfd9f54  movaps xmm6, [rsp]
00007ec68bfd9f58  add rsp, 0x30
00007ec68bfd9f5c  vmovaps xmm0, [rsp]
00007ec68bfd9f61  vmovaps xmm1, [rsp+0x10]
00007ec68bfd9f67  vmovaps xmm2, [rsp+0x20]
00007ec68bfd9f6d  vmovaps xmm3, [rsp+0x30]
00007ec68bfd9f73  vmovaps xmm4, [rsp+0x40]
00007ec68bfd9f79  vmovaps xmm5, [rsp+0x50]
00007ec68bfd9f7f  vmovaps xmm7, [rsp+0x60]
00007ec68bfd9f85  vmovaps xmm8, [rsp+0x70]
00007ec68bfd9f8b  vmovaps xmm9, [rsp+0x80]
00007ec68bfd9f94  vmovaps xmm10, [rsp+0x90]
00007ec68bfd9f9d  vmovaps xmm11, [rsp+0xA0]
00007ec68bfd9fa6  vmovaps xmm12, [rsp+0xB0]
00007ec68bfd9faf  vmovaps xmm13, [rsp+0xC0]
00007ec68bfd9fb8  vmovaps xmm14, [rsp+0xD0]
00007ec68bfd9fc1  vmovaps xmm15, [rsp+0xE0]
00007ec68bfd9fca  add rsp, 0xF0
00007ec68bfd9fd1  pop r11
00007ec68bfd9fd3  pop r10
00007ec68bfd9fd5  pop r9
00007ec68bfd9fd7  pop r8
00007ec68bfd9fd9  pop rsi
00007ec68bfd9fda  pop rdi
00007ec68bfd9fdb  pop rdx
00007ec68bfd9fdc  pop rcx
00007ec68bfd9fdd  pop rax
00007ec68bfd9fde  add rsp, 0x08
00007ec68bfd9fe2  jmp 0x00007EC68BFD8C07
00007ec68bfd9fe7  sub rsp, 0x08
00007ec68bfd9feb  push rax
00007ec68bfd9fec  push rcx
00007ec68bfd9fed  push rdx
00007ec68bfd9fee  push rdi
00007ec68bfd9fef  push rsi
00007ec68bfd9ff0  push r8
00007ec68bfd9ff2  push r9
00007ec68bfd9ff4  push r10
00007ec68bfd9ff6  push r11
00007ec68bfd9ff8  sub rsp, 0xF0
00007ec68bfd9fff  vmovaps [rsp], xmm0
00007ec68bfda004  vmovaps [rsp+0x10], xmm1
00007ec68bfda00a  vmovaps [rsp+0x20], xmm2
00007ec68bfda010  vmovaps [rsp+0x30], xmm4
00007ec68bfda016  vmovaps [rsp+0x40], xmm5
00007ec68bfda01c  vmovaps [rsp+0x50], xmm6
00007ec68bfda022  vmovaps [rsp+0x60], xmm7
00007ec68bfda028  vmovaps [rsp+0x70], xmm8
00007ec68bfda02e  vmovaps [rsp+0x80], xmm9
00007ec68bfda037  vmovaps [rsp+0x90], xmm10
00007ec68bfda040  vmovaps [rsp+0xA0], xmm11
00007ec68bfda049  vmovaps [rsp+0xB0], xmm12
00007ec68bfda052  vmovaps [rsp+0xC0], xmm13
00007ec68bfda05b  vmovaps [rsp+0xD0], xmm14
00007ec68bfda064  vmovaps [rsp+0xE0], xmm15
00007ec68bfda06d  sub rsp, 0x30
00007ec68bfda071  movaps [rsp], xmm3
00007ec68bfda075  movaps [rsp+0x10], xmm5
00007ec68bfda07a  movaps [rsp+0x20], xmm4
00007ec68bfda07f  lea rdi, [rsp]
00007ec68bfda083  mov esi, 0x00
00007ec68bfda088  mov rax, 0x57D97DADF530
00007ec68bfda092  call rax
00007ec68bfda094  movaps xmm3, [rsp]
00007ec68bfda098  add rsp, 0x30
00007ec68bfda09c  vmovaps xmm0, [rsp]
00007ec68bfda0a1  vmovaps xmm1, [rsp+0x10]
00007ec68bfda0a7  vmovaps xmm2, [rsp+0x20]
00007ec68bfda0ad  vmovaps xmm4, [rsp+0x30]
00007ec68bfda0b3  vmovaps xmm5, [rsp+0x40]
00007ec68bfda0b9  vmovaps xmm6, [rsp+0x50]
00007ec68bfda0bf  vmovaps xmm7, [rsp+0x60]
00007ec68bfda0c5  vmovaps xmm8, [rsp+0x70]
00007ec68bfda0cb  vmovaps xmm9, [rsp+0x80]
00007ec68bfda0d4  vmovaps xmm10, [rsp+0x90]
00007ec68bfda0dd  vmovaps xmm11, [rsp+0xA0]
00007ec68bfda0e6  vmovaps xmm12, [rsp+0xB0]
00007ec68bfda0ef  vmovaps xmm13, [rsp+0xC0]
00007ec68bfda0f8  vmovaps xmm14, [rsp+0xD0]
00007ec68bfda101  vmovaps xmm15, [rsp+0xE0]
00007ec68bfda10a  add rsp, 0xF0
00007ec68bfda111  pop r11
00007ec68bfda113  pop r10
00007ec68bfda115  pop r9
00007ec68bfda117  pop r8
00007ec68bfda119  pop rsi
00007ec68bfda11a  pop rdi
00007ec68bfda11b  pop rdx
00007ec68bfda11c  pop rcx
00007ec68bfda11d  pop rax
00007ec68bfda11e  add rsp, 0x08
00007ec68bfda122  jmp 0x00007EC68BFD8C68
00007ec68bfda127  sub rsp, 0x08
00007ec68bfda12b  push rax
00007ec68bfda12c  push rcx
00007ec68bfda12d  push rdx
00007ec68bfda12e  push rdi
00007ec68bfda12f  push rsi
00007ec68bfda130  push r8
00007ec68bfda132  push r9
00007ec68bfda134  push r10
00007ec68bfda136  push r11
00007ec68bfda138  sub rsp, 0xF0
00007ec68bfda13f  vmovaps [rsp], xmm0
00007ec68bfda144  vmovaps [rsp+0x10], xmm1
00007ec68bfda14a  vmovaps [rsp+0x20], xmm2
00007ec68bfda150  vmovaps [rsp+0x30], xmm3
00007ec68bfda156  vmovaps [rsp+0x40], xmm4
00007ec68bfda15c  vmovaps [rsp+0x50], xmm6
00007ec68bfda162  vmovaps [rsp+0x60], xmm7
00007ec68bfda168  vmovaps [rsp+0x70], xmm8
00007ec68bfda16e  vmovaps [rsp+0x80], xmm9
00007ec68bfda177  vmovaps [rsp+0x90], xmm10
00007ec68bfda180  vmovaps [rsp+0xA0], xmm11
00007ec68bfda189  vmovaps [rsp+0xB0], xmm12
00007ec68bfda192  vmovaps [rsp+0xC0], xmm13
00007ec68bfda19b  vmovaps [rsp+0xD0], xmm14
00007ec68bfda1a4  vmovaps [rsp+0xE0], xmm15
00007ec68bfda1ad  sub rsp, 0x30
00007ec68bfda1b1  movaps [rsp], xmm5
00007ec68bfda1b5  movaps [rsp+0x10], xmm8
00007ec68bfda1bb  movaps [rsp+0x20], xmm15
00007ec68bfda1c1  lea rdi, [rsp]
00007ec68bfda1c5  mov esi, 0x00
00007ec68bfda1ca  mov rax, 0x57D97DADF530
00007ec68bfda1d4  call rax
00007ec68bfda1d6  movaps xmm5, [rsp]
00007ec68bfda1da  add rsp, 0x30
00007ec68bfda1de  vmovaps xmm0, [rsp]
00007ec68bfda1e3  vmovaps xmm1, [rsp+0x10]
00007ec68bfda1e9  vmovaps xmm2, [rsp+0x20]
00007ec68bfda1ef  vmovaps xmm3, [rsp+0x30]
00007ec68bfda1f5  vmovaps xmm4, [rsp+0x40]
00007ec68bfda1fb  vmovaps xmm6, [rsp+0x50]
00007ec68bfda201  vmovaps xmm7, [rsp+0x60]
00007ec68bfda207  vmovaps xmm8, [rsp+0x70]
00007ec68bfda20d  vmovaps xmm9, [rsp+0x80]
00007ec68bfda216  vmovaps xmm10, [rsp+0x90]
00007ec68bfda21f  vmovaps xmm11, [rsp+0xA0]
00007ec68bfda228  vmovaps xmm12, [rsp+0xB0]
00007ec68bfda231  vmovaps xmm13, [rsp+0xC0]
00007ec68bfda23a  vmovaps xmm14, [rsp+0xD0]
00007ec68bfda243  vmovaps xmm15, [rsp+0xE0]
00007ec68bfda24c  add rsp, 0xF0
00007ec68bfda253  pop r11
00007ec68bfda255  pop r10
00007ec68bfda257  pop r9
00007ec68bfda259  pop r8
00007ec68bfda25b  pop rsi
00007ec68bfda25c  pop rdi
00007ec68bfda25d  pop rdx
00007ec68bfda25e  pop rcx
00007ec68bfda25f  pop rax
00007ec68bfda260  add rsp, 0x08
00007ec68bfda264  jmp 0x00007EC68BFD8CA0
00007ec68bfda269  sub rsp, 0x08
00007ec68bfda26d  push rax
00007ec68bfda26e  push rcx
00007ec68bfda26f  push rdx
00007ec68bfda270  push rdi
00007ec68bfda271  push rsi
00007ec68bfda272  push r8
00007ec68bfda274  push r9
00007ec68bfda276  push r10
00007ec68bfda278  push r11
00007ec68bfda27a  sub rsp, 0xF0
00007ec68bfda281  vmovaps [rsp], xmm0
00007ec68bfda286  vmovaps [rsp+0x10], xmm1
00007ec68bfda28c  vmovaps [rsp+0x20], xmm2
00007ec68bfda292  vmovaps [rsp+0x30], xmm3
00007ec68bfda298  vmovaps [rsp+0x40], xmm5
00007ec68bfda29e  vmovaps [rsp+0x50], xmm6
00007ec68bfda2a4  vmovaps [rsp+0x60], xmm7
00007ec68bfda2aa  vmovaps [rsp+0x70], xmm8
00007ec68bfda2b0  vmovaps [rsp+0x80], xmm9
00007ec68bfda2b9  vmovaps [rsp+0x90], xmm10
00007ec68bfda2c2  vmovaps [rsp+0xA0], xmm11
00007ec68bfda2cb  vmovaps [rsp+0xB0], xmm12
00007ec68bfda2d4  vmovaps [rsp+0xC0], xmm13
00007ec68bfda2dd  vmovaps [rsp+0xD0], xmm14
00007ec68bfda2e6  vmovaps [rsp+0xE0], xmm15
00007ec68bfda2ef  sub rsp, 0x30
00007ec68bfda2f3  movaps [rsp], xmm4
00007ec68bfda2f7  movaps [rsp+0x10], xmm9
00007ec68bfda2fd  movaps [rsp+0x20], xmm8
00007ec68bfda303  lea rdi, [rsp]
00007ec68bfda307  mov esi, 0x00
00007ec68bfda30c  mov rax, 0x57D97DADF530
00007ec68bfda316  call rax
00007ec68bfda318  movaps xmm4, [rsp]
00007ec68bfda31c  add rsp, 0x30
00007ec68bfda320  vmovaps xmm0, [rsp]
00007ec68bfda325  vmovaps xmm1, [rsp+0x10]
00007ec68bfda32b  vmovaps xmm2, [rsp+0x20]
00007ec68bfda331  vmovaps xmm3, [rsp+0x30]
00007ec68bfda337  vmovaps xmm5, [rsp+0x40]
00007ec68bfda33d  vmovaps xmm6, [rsp+0x50]
00007ec68bfda343  vmovaps xmm7, [rsp+0x60]
00007ec68bfda349  vmovaps xmm8, [rsp+0x70]
00007ec68bfda34f  vmovaps xmm9, [rsp+0x80]
00007ec68bfda358  vmovaps xmm10, [rsp+0x90]
00007ec68bfda361  vmovaps xmm11, [rsp+0xA0]
00007ec68bfda36a  vmovaps xmm12, [rsp+0xB0]
00007ec68bfda373  vmovaps xmm13, [rsp+0xC0]
00007ec68bfda37c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfda385  vmovaps xmm15, [rsp+0xE0]
00007ec68bfda38e  add rsp, 0xF0
00007ec68bfda395  pop r11
00007ec68bfda397  pop r10
00007ec68bfda399  pop r9
00007ec68bfda39b  pop r8
00007ec68bfda39d  pop rsi
00007ec68bfda39e  pop rdi
00007ec68bfda39f  pop rdx
00007ec68bfda3a0  pop rcx
00007ec68bfda3a1  pop rax
00007ec68bfda3a2  add rsp, 0x08
00007ec68bfda3a6  jmp 0x00007EC68BFD8CC1
00007ec68bfda3ab  sub rsp, 0x08
00007ec68bfda3af  push rax
00007ec68bfda3b0  push rcx
00007ec68bfda3b1  push rdx
00007ec68bfda3b2  push rdi
00007ec68bfda3b3  push rsi
00007ec68bfda3b4  push r8
00007ec68bfda3b6  push r9
00007ec68bfda3b8  push r10
00007ec68bfda3ba  push r11
00007ec68bfda3bc  sub rsp, 0xF0
00007ec68bfda3c3  vmovaps [rsp], xmm0
00007ec68bfda3c8  vmovaps [rsp+0x10], xmm1
00007ec68bfda3ce  vmovaps [rsp+0x20], xmm2
00007ec68bfda3d4  vmovaps [rsp+0x30], xmm3
00007ec68bfda3da  vmovaps [rsp+0x40], xmm4
00007ec68bfda3e0  vmovaps [rsp+0x50], xmm5
00007ec68bfda3e6  vmovaps [rsp+0x60], xmm6
00007ec68bfda3ec  vmovaps [rsp+0x70], xmm7
00007ec68bfda3f2  vmovaps [rsp+0x80], xmm8
00007ec68bfda3fb  vmovaps [rsp+0x90], xmm10
00007ec68bfda404  vmovaps [rsp+0xA0], xmm11
00007ec68bfda40d  vmovaps [rsp+0xB0], xmm12
00007ec68bfda416  vmovaps [rsp+0xC0], xmm13
00007ec68bfda41f  vmovaps [rsp+0xD0], xmm14
00007ec68bfda428  vmovaps [rsp+0xE0], xmm15
00007ec68bfda431  sub rsp, 0x30
00007ec68bfda435  movaps [rsp], xmm9
00007ec68bfda43a  movaps [rsp+0x10], xmm10
00007ec68bfda440  movaps [rsp+0x20], xmm8
00007ec68bfda446  lea rdi, [rsp]
00007ec68bfda44a  mov esi, 0x00
00007ec68bfda44f  mov rax, 0x57D97DADF530
00007ec68bfda459  call rax
00007ec68bfda45b  movaps xmm9, [rsp]
00007ec68bfda460  add rsp, 0x30
00007ec68bfda464  vmovaps xmm0, [rsp]
00007ec68bfda469  vmovaps xmm1, [rsp+0x10]
00007ec68bfda46f  vmovaps xmm2, [rsp+0x20]
00007ec68bfda475  vmovaps xmm3, [rsp+0x30]
00007ec68bfda47b  vmovaps xmm4, [rsp+0x40]
00007ec68bfda481  vmovaps xmm5, [rsp+0x50]
00007ec68bfda487  vmovaps xmm6, [rsp+0x60]
00007ec68bfda48d  vmovaps xmm7, [rsp+0x70]
00007ec68bfda493  vmovaps xmm8, [rsp+0x80]
00007ec68bfda49c  vmovaps xmm10, [rsp+0x90]
00007ec68bfda4a5  vmovaps xmm11, [rsp+0xA0]
00007ec68bfda4ae  vmovaps xmm12, [rsp+0xB0]
00007ec68bfda4b7  vmovaps xmm13, [rsp+0xC0]
00007ec68bfda4c0  vmovaps xmm14, [rsp+0xD0]
00007ec68bfda4c9  vmovaps xmm15, [rsp+0xE0]
00007ec68bfda4d2  add rsp, 0xF0
00007ec68bfda4d9  pop r11
00007ec68bfda4db  pop r10
00007ec68bfda4dd  pop r9
00007ec68bfda4df  pop r8
00007ec68bfda4e1  pop rsi
00007ec68bfda4e2  pop rdi
00007ec68bfda4e3  pop rdx
00007ec68bfda4e4  pop rcx
00007ec68bfda4e5  pop rax
00007ec68bfda4e6  add rsp, 0x08
00007ec68bfda4ea  jmp 0x00007EC68BFD8CDB
00007ec68bfda4ef  call 0x00007EC68BED64F0
00007ec68bfda4f4  jmp 0x00007EC68BFD8DF5
00007ec68bfda4f9  call 0x00007EC68BED64F0
00007ec68bfda4fe  jmp 0x00007EC68BFD8E0B
00007ec68bfda503  sub rsp, 0x08
00007ec68bfda507  push rax
00007ec68bfda508  push rcx
00007ec68bfda509  push rdx
00007ec68bfda50a  push rdi
00007ec68bfda50b  push rsi
00007ec68bfda50c  push r8
00007ec68bfda50e  push r9
00007ec68bfda510  push r10
00007ec68bfda512  push r11
00007ec68bfda514  sub rsp, 0xF0
00007ec68bfda51b  vmovaps [rsp], xmm0
00007ec68bfda520  vmovaps [rsp+0x10], xmm2
00007ec68bfda526  vmovaps [rsp+0x20], xmm3
00007ec68bfda52c  vmovaps [rsp+0x30], xmm4
00007ec68bfda532  vmovaps [rsp+0x40], xmm5
00007ec68bfda538  vmovaps [rsp+0x50], xmm6
00007ec68bfda53e  vmovaps [rsp+0x60], xmm7
00007ec68bfda544  vmovaps [rsp+0x70], xmm8
00007ec68bfda54a  vmovaps [rsp+0x80], xmm9
00007ec68bfda553  vmovaps [rsp+0x90], xmm10
00007ec68bfda55c  vmovaps [rsp+0xA0], xmm11
00007ec68bfda565  vmovaps [rsp+0xB0], xmm12
00007ec68bfda56e  vmovaps [rsp+0xC0], xmm13
00007ec68bfda577  vmovaps [rsp+0xD0], xmm14
00007ec68bfda580  vmovaps [rsp+0xE0], xmm15
00007ec68bfda589  sub rsp, 0x30
00007ec68bfda58d  movaps [rsp], xmm1
00007ec68bfda591  movaps [rsp+0x10], xmm6
00007ec68bfda596  movaps [rsp+0x20], xmm15
00007ec68bfda59c  lea rdi, [rsp]
00007ec68bfda5a0  mov esi, 0x00
00007ec68bfda5a5  mov rax, 0x57D97DADF530
00007ec68bfda5af  call rax
00007ec68bfda5b1  movaps xmm1, [rsp]
00007ec68bfda5b5  add rsp, 0x30
00007ec68bfda5b9  vmovaps xmm0, [rsp]
00007ec68bfda5be  vmovaps xmm2, [rsp+0x10]
00007ec68bfda5c4  vmovaps xmm3, [rsp+0x20]
00007ec68bfda5ca  vmovaps xmm4, [rsp+0x30]
00007ec68bfda5d0  vmovaps xmm5, [rsp+0x40]
00007ec68bfda5d6  vmovaps xmm6, [rsp+0x50]
00007ec68bfda5dc  vmovaps xmm7, [rsp+0x60]
00007ec68bfda5e2  vmovaps xmm8, [rsp+0x70]
00007ec68bfda5e8  vmovaps xmm9, [rsp+0x80]
00007ec68bfda5f1  vmovaps xmm10, [rsp+0x90]
00007ec68bfda5fa  vmovaps xmm11, [rsp+0xA0]
00007ec68bfda603  vmovaps xmm12, [rsp+0xB0]
00007ec68bfda60c  vmovaps xmm13, [rsp+0xC0]
00007ec68bfda615  vmovaps xmm14, [rsp+0xD0]
00007ec68bfda61e  vmovaps xmm15, [rsp+0xE0]
00007ec68bfda627  add rsp, 0xF0
00007ec68bfda62e  pop r11
00007ec68bfda630  pop r10
00007ec68bfda632  pop r9
00007ec68bfda634  pop r8
00007ec68bfda636  pop rsi
00007ec68bfda637  pop rdi
00007ec68bfda638  pop rdx
00007ec68bfda639  pop rcx
00007ec68bfda63a  pop rax
00007ec68bfda63b  add rsp, 0x08
00007ec68bfda63f  jmp 0x00007EC68BFD8E48
00007ec68bfda644  call 0x00007EC68BEE5820
00007ec68bfda649  jmp 0x00007EC68BFD8E55
00007ec68bfda64e  sub rsp, 0x08
00007ec68bfda652  push rax
00007ec68bfda653  push rcx
00007ec68bfda654  push rdx
00007ec68bfda655  push rdi
00007ec68bfda656  push rsi
00007ec68bfda657  push r8
00007ec68bfda659  push r9
00007ec68bfda65b  push r10
00007ec68bfda65d  push r11
00007ec68bfda65f  sub rsp, 0xF0
00007ec68bfda666  vmovaps [rsp], xmm0
00007ec68bfda66b  vmovaps [rsp+0x10], xmm1
00007ec68bfda671  vmovaps [rsp+0x20], xmm2
00007ec68bfda677  vmovaps [rsp+0x30], xmm3
00007ec68bfda67d  vmovaps [rsp+0x40], xmm4
00007ec68bfda683  vmovaps [rsp+0x50], xmm5
00007ec68bfda689  vmovaps [rsp+0x60], xmm6
00007ec68bfda68f  vmovaps [rsp+0x70], xmm7
00007ec68bfda695  vmovaps [rsp+0x80], xmm8
00007ec68bfda69e  vmovaps [rsp+0x90], xmm9
00007ec68bfda6a7  vmovaps [rsp+0xA0], xmm10
00007ec68bfda6b0  vmovaps [rsp+0xB0], xmm11
00007ec68bfda6b9  vmovaps [rsp+0xC0], xmm12
00007ec68bfda6c2  vmovaps [rsp+0xD0], xmm13
00007ec68bfda6cb  vmovaps [rsp+0xE0], xmm15
00007ec68bfda6d4  sub rsp, 0x30
00007ec68bfda6d8  movaps [rsp], xmm14
00007ec68bfda6dd  movaps [rsp+0x10], xmm4
00007ec68bfda6e2  movaps [rsp+0x20], xmm3
00007ec68bfda6e7  lea rdi, [rsp]
00007ec68bfda6eb  mov esi, 0x00
00007ec68bfda6f0  mov rax, 0x57D97DADF530
00007ec68bfda6fa  call rax
00007ec68bfda6fc  movaps xmm14, [rsp]
00007ec68bfda701  add rsp, 0x30
00007ec68bfda705  vmovaps xmm0, [rsp]
00007ec68bfda70a  vmovaps xmm1, [rsp+0x10]
00007ec68bfda710  vmovaps xmm2, [rsp+0x20]
00007ec68bfda716  vmovaps xmm3, [rsp+0x30]
00007ec68bfda71c  vmovaps xmm4, [rsp+0x40]
00007ec68bfda722  vmovaps xmm5, [rsp+0x50]
00007ec68bfda728  vmovaps xmm6, [rsp+0x60]
00007ec68bfda72e  vmovaps xmm7, [rsp+0x70]
00007ec68bfda734  vmovaps xmm8, [rsp+0x80]
00007ec68bfda73d  vmovaps xmm9, [rsp+0x90]
00007ec68bfda746  vmovaps xmm10, [rsp+0xA0]
00007ec68bfda74f  vmovaps xmm11, [rsp+0xB0]
00007ec68bfda758  vmovaps xmm12, [rsp+0xC0]
00007ec68bfda761  vmovaps xmm13, [rsp+0xD0]
00007ec68bfda76a  vmovaps xmm15, [rsp+0xE0]
00007ec68bfda773  add rsp, 0xF0
00007ec68bfda77a  pop r11
00007ec68bfda77c  pop r10
00007ec68bfda77e  pop r9
00007ec68bfda780  pop r8
00007ec68bfda782  pop rsi
00007ec68bfda783  pop rdi
00007ec68bfda784  pop rdx
00007ec68bfda785  pop rcx
00007ec68bfda786  pop rax
00007ec68bfda787  add rsp, 0x08
00007ec68bfda78b  jmp 0x00007EC68BFD8E6F
00007ec68bfda790  sub rsp, 0x08
00007ec68bfda794  push rax
00007ec68bfda795  push rcx
00007ec68bfda796  push rdx
00007ec68bfda797  push rdi
00007ec68bfda798  push rsi
00007ec68bfda799  push r8
00007ec68bfda79b  push r9
00007ec68bfda79d  push r10
00007ec68bfda79f  push r11
00007ec68bfda7a1  sub rsp, 0xF0
00007ec68bfda7a8  vmovaps [rsp], xmm0
00007ec68bfda7ad  vmovaps [rsp+0x10], xmm1
00007ec68bfda7b3  vmovaps [rsp+0x20], xmm2
00007ec68bfda7b9  vmovaps [rsp+0x30], xmm3
00007ec68bfda7bf  vmovaps [rsp+0x40], xmm4
00007ec68bfda7c5  vmovaps [rsp+0x50], xmm5
00007ec68bfda7cb  vmovaps [rsp+0x60], xmm7
00007ec68bfda7d1  vmovaps [rsp+0x70], xmm8
00007ec68bfda7d7  vmovaps [rsp+0x80], xmm9
00007ec68bfda7e0  vmovaps [rsp+0x90], xmm10
00007ec68bfda7e9  vmovaps [rsp+0xA0], xmm11
00007ec68bfda7f2  vmovaps [rsp+0xB0], xmm12
00007ec68bfda7fb  vmovaps [rsp+0xC0], xmm13
00007ec68bfda804  vmovaps [rsp+0xD0], xmm14
00007ec68bfda80d  vmovaps [rsp+0xE0], xmm15
00007ec68bfda816  sub rsp, 0x30
00007ec68bfda81a  movaps [rsp], xmm6
00007ec68bfda81e  movaps [rsp+0x10], xmm9
00007ec68bfda824  movaps [rsp+0x20], xmm7
00007ec68bfda829  lea rdi, [rsp]
00007ec68bfda82d  mov esi, 0x00
00007ec68bfda832  mov rax, 0x57D97DADF530
00007ec68bfda83c  call rax
00007ec68bfda83e  movaps xmm6, [rsp]
00007ec68bfda842  add rsp, 0x30
00007ec68bfda846  vmovaps xmm0, [rsp]
00007ec68bfda84b  vmovaps xmm1, [rsp+0x10]
00007ec68bfda851  vmovaps xmm2, [rsp+0x20]
00007ec68bfda857  vmovaps xmm3, [rsp+0x30]
00007ec68bfda85d  vmovaps xmm4, [rsp+0x40]
00007ec68bfda863  vmovaps xmm5, [rsp+0x50]
00007ec68bfda869  vmovaps xmm7, [rsp+0x60]
00007ec68bfda86f  vmovaps xmm8, [rsp+0x70]
00007ec68bfda875  vmovaps xmm9, [rsp+0x80]
00007ec68bfda87e  vmovaps xmm10, [rsp+0x90]
00007ec68bfda887  vmovaps xmm11, [rsp+0xA0]
00007ec68bfda890  vmovaps xmm12, [rsp+0xB0]
00007ec68bfda899  vmovaps xmm13, [rsp+0xC0]
00007ec68bfda8a2  vmovaps xmm14, [rsp+0xD0]
00007ec68bfda8ab  vmovaps xmm15, [rsp+0xE0]
00007ec68bfda8b4  add rsp, 0xF0
00007ec68bfda8bb  pop r11
00007ec68bfda8bd  pop r10
00007ec68bfda8bf  pop r9
00007ec68bfda8c1  pop r8
00007ec68bfda8c3  pop rsi
00007ec68bfda8c4  pop rdi
00007ec68bfda8c5  pop rdx
00007ec68bfda8c6  pop rcx
00007ec68bfda8c7  pop rax
00007ec68bfda8c8  add rsp, 0x08
00007ec68bfda8cc  jmp 0x00007EC68BFD8E87
00007ec68bfda8d1  sub rsp, 0x08
00007ec68bfda8d5  push rax
00007ec68bfda8d6  push rcx
00007ec68bfda8d7  push rdx
00007ec68bfda8d8  push rdi
00007ec68bfda8d9  push rsi
00007ec68bfda8da  push r8
00007ec68bfda8dc  push r9
00007ec68bfda8de  push r10
00007ec68bfda8e0  push r11
00007ec68bfda8e2  sub rsp, 0xF0
00007ec68bfda8e9  vmovaps [rsp], xmm0
00007ec68bfda8ee  vmovaps [rsp+0x10], xmm1
00007ec68bfda8f4  vmovaps [rsp+0x20], xmm2
00007ec68bfda8fa  vmovaps [rsp+0x30], xmm3
00007ec68bfda900  vmovaps [rsp+0x40], xmm4
00007ec68bfda906  vmovaps [rsp+0x50], xmm5
00007ec68bfda90c  vmovaps [rsp+0x60], xmm6
00007ec68bfda912  vmovaps [rsp+0x70], xmm8
00007ec68bfda918  vmovaps [rsp+0x80], xmm9
00007ec68bfda921  vmovaps [rsp+0x90], xmm10
00007ec68bfda92a  vmovaps [rsp+0xA0], xmm11
00007ec68bfda933  vmovaps [rsp+0xB0], xmm12
00007ec68bfda93c  vmovaps [rsp+0xC0], xmm13
00007ec68bfda945  vmovaps [rsp+0xD0], xmm14
00007ec68bfda94e  vmovaps [rsp+0xE0], xmm15
00007ec68bfda957  sub rsp, 0x30
00007ec68bfda95b  movaps [rsp], xmm7
00007ec68bfda95f  movaps [rsp+0x10], xmm4
00007ec68bfda964  movaps [rsp+0x20], xmm9
00007ec68bfda96a  lea rdi, [rsp]
00007ec68bfda96e  mov esi, 0x00
00007ec68bfda973  mov rax, 0x57D97DADF530
00007ec68bfda97d  call rax
00007ec68bfda97f  movaps xmm7, [rsp]
00007ec68bfda983  add rsp, 0x30
00007ec68bfda987  vmovaps xmm0, [rsp]
00007ec68bfda98c  vmovaps xmm1, [rsp+0x10]
00007ec68bfda992  vmovaps xmm2, [rsp+0x20]
00007ec68bfda998  vmovaps xmm3, [rsp+0x30]
00007ec68bfda99e  vmovaps xmm4, [rsp+0x40]
00007ec68bfda9a4  vmovaps xmm5, [rsp+0x50]
00007ec68bfda9aa  vmovaps xmm6, [rsp+0x60]
00007ec68bfda9b0  vmovaps xmm8, [rsp+0x70]
00007ec68bfda9b6  vmovaps xmm9, [rsp+0x80]
00007ec68bfda9bf  vmovaps xmm10, [rsp+0x90]
00007ec68bfda9c8  vmovaps xmm11, [rsp+0xA0]
00007ec68bfda9d1  vmovaps xmm12, [rsp+0xB0]
00007ec68bfda9da  vmovaps xmm13, [rsp+0xC0]
00007ec68bfda9e3  vmovaps xmm14, [rsp+0xD0]
00007ec68bfda9ec  vmovaps xmm15, [rsp+0xE0]
00007ec68bfda9f5  add rsp, 0xF0
00007ec68bfda9fc  pop r11
00007ec68bfda9fe  pop r10
00007ec68bfdaa00  pop r9
00007ec68bfdaa02  pop r8
00007ec68bfdaa04  pop rsi
00007ec68bfdaa05  pop rdi
00007ec68bfdaa06  pop rdx
00007ec68bfdaa07  pop rcx
00007ec68bfdaa08  pop rax
00007ec68bfdaa09  add rsp, 0x08
00007ec68bfdaa0d  jmp 0x00007EC68BFD8EB4
00007ec68bfdaa12  sub rsp, 0x08
00007ec68bfdaa16  push rax
00007ec68bfdaa17  push rcx
00007ec68bfdaa18  push rdx
00007ec68bfdaa19  push rdi
00007ec68bfdaa1a  push rsi
00007ec68bfdaa1b  push r8
00007ec68bfdaa1d  push r9
00007ec68bfdaa1f  push r10
00007ec68bfdaa21  push r11
00007ec68bfdaa23  sub rsp, 0xF0
00007ec68bfdaa2a  vmovaps [rsp], xmm0
00007ec68bfdaa2f  vmovaps [rsp+0x10], xmm1
00007ec68bfdaa35  vmovaps [rsp+0x20], xmm2
00007ec68bfdaa3b  vmovaps [rsp+0x30], xmm3
00007ec68bfdaa41  vmovaps [rsp+0x40], xmm5
00007ec68bfdaa47  vmovaps [rsp+0x50], xmm6
00007ec68bfdaa4d  vmovaps [rsp+0x60], xmm7
00007ec68bfdaa53  vmovaps [rsp+0x70], xmm8
00007ec68bfdaa59  vmovaps [rsp+0x80], xmm9
00007ec68bfdaa62  vmovaps [rsp+0x90], xmm10
00007ec68bfdaa6b  vmovaps [rsp+0xA0], xmm11
00007ec68bfdaa74  vmovaps [rsp+0xB0], xmm12
00007ec68bfdaa7d  vmovaps [rsp+0xC0], xmm13
00007ec68bfdaa86  vmovaps [rsp+0xD0], xmm14
00007ec68bfdaa8f  vmovaps [rsp+0xE0], xmm15
00007ec68bfdaa98  sub rsp, 0x30
00007ec68bfdaa9c  movaps [rsp], xmm4
00007ec68bfdaaa0  movaps [rsp+0x10], xmm15
00007ec68bfdaaa6  movaps [rsp+0x20], xmm9
00007ec68bfdaaac  lea rdi, [rsp]
00007ec68bfdaab0  mov esi, 0x00
00007ec68bfdaab5  mov rax, 0x57D97DADF530
00007ec68bfdaabf  call rax
00007ec68bfdaac1  movaps xmm4, [rsp]
00007ec68bfdaac5  add rsp, 0x30
00007ec68bfdaac9  vmovaps xmm0, [rsp]
00007ec68bfdaace  vmovaps xmm1, [rsp+0x10]
00007ec68bfdaad4  vmovaps xmm2, [rsp+0x20]
00007ec68bfdaada  vmovaps xmm3, [rsp+0x30]
00007ec68bfdaae0  vmovaps xmm5, [rsp+0x40]
00007ec68bfdaae6  vmovaps xmm6, [rsp+0x50]
00007ec68bfdaaec  vmovaps xmm7, [rsp+0x60]
00007ec68bfdaaf2  vmovaps xmm8, [rsp+0x70]
00007ec68bfdaaf8  vmovaps xmm9, [rsp+0x80]
00007ec68bfdab01  vmovaps xmm10, [rsp+0x90]
00007ec68bfdab0a  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdab13  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdab1c  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdab25  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdab2e  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdab37  add rsp, 0xF0
00007ec68bfdab3e  pop r11
00007ec68bfdab40  pop r10
00007ec68bfdab42  pop r9
00007ec68bfdab44  pop r8
00007ec68bfdab46  pop rsi
00007ec68bfdab47  pop rdi
00007ec68bfdab48  pop rdx
00007ec68bfdab49  pop rcx
00007ec68bfdab4a  pop rax
00007ec68bfdab4b  add rsp, 0x08
00007ec68bfdab4f  jmp 0x00007EC68BFD8ED9
00007ec68bfdab54  call 0x00007EC68BEE5820
00007ec68bfdab59  jmp 0x00007EC68BFD8EE6
00007ec68bfdab5e  sub rsp, 0x08
00007ec68bfdab62  push rax
00007ec68bfdab63  push rcx
00007ec68bfdab64  push rdx
00007ec68bfdab65  push rdi
00007ec68bfdab66  push rsi
00007ec68bfdab67  push r8
00007ec68bfdab69  push r9
00007ec68bfdab6b  push r10
00007ec68bfdab6d  push r11
00007ec68bfdab6f  sub rsp, 0xF0
00007ec68bfdab76  vmovaps [rsp], xmm0
00007ec68bfdab7b  vmovaps [rsp+0x10], xmm1
00007ec68bfdab81  vmovaps [rsp+0x20], xmm2
00007ec68bfdab87  vmovaps [rsp+0x30], xmm4
00007ec68bfdab8d  vmovaps [rsp+0x40], xmm5
00007ec68bfdab93  vmovaps [rsp+0x50], xmm6
00007ec68bfdab99  vmovaps [rsp+0x60], xmm7
00007ec68bfdab9f  vmovaps [rsp+0x70], xmm8
00007ec68bfdaba5  vmovaps [rsp+0x80], xmm9
00007ec68bfdabae  vmovaps [rsp+0x90], xmm10
00007ec68bfdabb7  vmovaps [rsp+0xA0], xmm11
00007ec68bfdabc0  vmovaps [rsp+0xB0], xmm12
00007ec68bfdabc9  vmovaps [rsp+0xC0], xmm13
00007ec68bfdabd2  vmovaps [rsp+0xD0], xmm14
00007ec68bfdabdb  vmovaps [rsp+0xE0], xmm15
00007ec68bfdabe4  sub rsp, 0x30
00007ec68bfdabe8  movaps [rsp], xmm3
00007ec68bfdabec  movaps [rsp+0x10], xmm1
00007ec68bfdabf1  movaps [rsp+0x20], xmm9
00007ec68bfdabf7  lea rdi, [rsp]
00007ec68bfdabfb  mov esi, 0x00
00007ec68bfdac00  mov rax, 0x57D97DADF530
00007ec68bfdac0a  call rax
00007ec68bfdac0c  movaps xmm3, [rsp]
00007ec68bfdac10  add rsp, 0x30
00007ec68bfdac14  vmovaps xmm0, [rsp]
00007ec68bfdac19  vmovaps xmm1, [rsp+0x10]
00007ec68bfdac1f  vmovaps xmm2, [rsp+0x20]
00007ec68bfdac25  vmovaps xmm4, [rsp+0x30]
00007ec68bfdac2b  vmovaps xmm5, [rsp+0x40]
00007ec68bfdac31  vmovaps xmm6, [rsp+0x50]
00007ec68bfdac37  vmovaps xmm7, [rsp+0x60]
00007ec68bfdac3d  vmovaps xmm8, [rsp+0x70]
00007ec68bfdac43  vmovaps xmm9, [rsp+0x80]
00007ec68bfdac4c  vmovaps xmm10, [rsp+0x90]
00007ec68bfdac55  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdac5e  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdac67  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdac70  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdac79  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdac82  add rsp, 0xF0
00007ec68bfdac89  pop r11
00007ec68bfdac8b  pop r10
00007ec68bfdac8d  pop r9
00007ec68bfdac8f  pop r8
00007ec68bfdac91  pop rsi
00007ec68bfdac92  pop rdi
00007ec68bfdac93  pop rdx
00007ec68bfdac94  pop rcx
00007ec68bfdac95  pop rax
00007ec68bfdac96  add rsp, 0x08
00007ec68bfdac9a  jmp 0x00007EC68BFD8F23
00007ec68bfdac9f  sub rsp, 0x08
00007ec68bfdaca3  push rax
00007ec68bfdaca4  push rcx
00007ec68bfdaca5  push rdx
00007ec68bfdaca6  push rdi
00007ec68bfdaca7  push rsi
00007ec68bfdaca8  push r8
00007ec68bfdacaa  push r9
00007ec68bfdacac  push r10
00007ec68bfdacae  push r11
00007ec68bfdacb0  sub rsp, 0xF0
00007ec68bfdacb7  vmovaps [rsp], xmm0
00007ec68bfdacbc  vmovaps [rsp+0x10], xmm2
00007ec68bfdacc2  vmovaps [rsp+0x20], xmm3
00007ec68bfdacc8  vmovaps [rsp+0x30], xmm4
00007ec68bfdacce  vmovaps [rsp+0x40], xmm5
00007ec68bfdacd4  vmovaps [rsp+0x50], xmm6
00007ec68bfdacda  vmovaps [rsp+0x60], xmm7
00007ec68bfdace0  vmovaps [rsp+0x70], xmm8
00007ec68bfdace6  vmovaps [rsp+0x80], xmm9
00007ec68bfdacef  vmovaps [rsp+0x90], xmm10
00007ec68bfdacf8  vmovaps [rsp+0xA0], xmm11
00007ec68bfdad01  vmovaps [rsp+0xB0], xmm12
00007ec68bfdad0a  vmovaps [rsp+0xC0], xmm13
00007ec68bfdad13  vmovaps [rsp+0xD0], xmm14
00007ec68bfdad1c  vmovaps [rsp+0xE0], xmm15
00007ec68bfdad25  sub rsp, 0x30
00007ec68bfdad29  movaps [rsp], xmm1
00007ec68bfdad2d  movaps [rsp+0x10], xmm15
00007ec68bfdad33  movaps [rsp+0x20], xmm9
00007ec68bfdad39  lea rdi, [rsp]
00007ec68bfdad3d  mov esi, 0x00
00007ec68bfdad42  mov rax, 0x57D97DADF530
00007ec68bfdad4c  call rax
00007ec68bfdad4e  movaps xmm1, [rsp]
00007ec68bfdad52  add rsp, 0x30
00007ec68bfdad56  vmovaps xmm0, [rsp]
00007ec68bfdad5b  vmovaps xmm2, [rsp+0x10]
00007ec68bfdad61  vmovaps xmm3, [rsp+0x20]
00007ec68bfdad67  vmovaps xmm4, [rsp+0x30]
00007ec68bfdad6d  vmovaps xmm5, [rsp+0x40]
00007ec68bfdad73  vmovaps xmm6, [rsp+0x50]
00007ec68bfdad79  vmovaps xmm7, [rsp+0x60]
00007ec68bfdad7f  vmovaps xmm8, [rsp+0x70]
00007ec68bfdad85  vmovaps xmm9, [rsp+0x80]
00007ec68bfdad8e  vmovaps xmm10, [rsp+0x90]
00007ec68bfdad97  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdada0  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdada9  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdadb2  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdadbb  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdadc4  add rsp, 0xF0
00007ec68bfdadcb  pop r11
00007ec68bfdadcd  pop r10
00007ec68bfdadcf  pop r9
00007ec68bfdadd1  pop r8
00007ec68bfdadd3  pop rsi
00007ec68bfdadd4  pop rdi
00007ec68bfdadd5  pop rdx
00007ec68bfdadd6  pop rcx
00007ec68bfdadd7  pop rax
00007ec68bfdadd8  add rsp, 0x08
00007ec68bfdaddc  jmp 0x00007EC68BFD8FAB
00007ec68bfdade1  call 0x00007EC68BEE5820
00007ec68bfdade6  jmp 0x00007EC68BFD8FB8
00007ec68bfdadeb  sub rsp, 0x08
00007ec68bfdadef  push rax
00007ec68bfdadf0  push rcx
00007ec68bfdadf1  push rdx
00007ec68bfdadf2  push rdi
00007ec68bfdadf3  push rsi
00007ec68bfdadf4  push r8
00007ec68bfdadf6  push r9
00007ec68bfdadf8  push r10
00007ec68bfdadfa  push r11
00007ec68bfdadfc  sub rsp, 0xF0
00007ec68bfdae03  vmovaps [rsp], xmm0
00007ec68bfdae08  vmovaps [rsp+0x10], xmm2
00007ec68bfdae0e  vmovaps [rsp+0x20], xmm3
00007ec68bfdae14  vmovaps [rsp+0x30], xmm4
00007ec68bfdae1a  vmovaps [rsp+0x40], xmm5
00007ec68bfdae20  vmovaps [rsp+0x50], xmm6
00007ec68bfdae26  vmovaps [rsp+0x60], xmm7
00007ec68bfdae2c  vmovaps [rsp+0x70], xmm8
00007ec68bfdae32  vmovaps [rsp+0x80], xmm9
00007ec68bfdae3b  vmovaps [rsp+0x90], xmm10
00007ec68bfdae44  vmovaps [rsp+0xA0], xmm11
00007ec68bfdae4d  vmovaps [rsp+0xB0], xmm12
00007ec68bfdae56  vmovaps [rsp+0xC0], xmm13
00007ec68bfdae5f  vmovaps [rsp+0xD0], xmm14
00007ec68bfdae68  vmovaps [rsp+0xE0], xmm15
00007ec68bfdae71  sub rsp, 0x30
00007ec68bfdae75  movaps [rsp], xmm1
00007ec68bfdae79  movaps [rsp+0x10], xmm5
00007ec68bfdae7e  movaps [rsp+0x20], xmm7
00007ec68bfdae83  lea rdi, [rsp]
00007ec68bfdae87  mov esi, 0x00
00007ec68bfdae8c  mov rax, 0x57D97DADF530
00007ec68bfdae96  call rax
00007ec68bfdae98  movaps xmm1, [rsp]
00007ec68bfdae9c  add rsp, 0x30
00007ec68bfdaea0  vmovaps xmm0, [rsp]
00007ec68bfdaea5  vmovaps xmm2, [rsp+0x10]
00007ec68bfdaeab  vmovaps xmm3, [rsp+0x20]
00007ec68bfdaeb1  vmovaps xmm4, [rsp+0x30]
00007ec68bfdaeb7  vmovaps xmm5, [rsp+0x40]
00007ec68bfdaebd  vmovaps xmm6, [rsp+0x50]
00007ec68bfdaec3  vmovaps xmm7, [rsp+0x60]
00007ec68bfdaec9  vmovaps xmm8, [rsp+0x70]
00007ec68bfdaecf  vmovaps xmm9, [rsp+0x80]
00007ec68bfdaed8  vmovaps xmm10, [rsp+0x90]
00007ec68bfdaee1  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdaeea  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdaef3  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdaefc  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdaf05  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdaf0e  add rsp, 0xF0
00007ec68bfdaf15  pop r11
00007ec68bfdaf17  pop r10
00007ec68bfdaf19  pop r9
00007ec68bfdaf1b  pop r8
00007ec68bfdaf1d  pop rsi
00007ec68bfdaf1e  pop rdi
00007ec68bfdaf1f  pop rdx
00007ec68bfdaf20  pop rcx
00007ec68bfdaf21  pop rax
00007ec68bfdaf22  add rsp, 0x08
00007ec68bfdaf26  jmp 0x00007EC68BFD905D
00007ec68bfdaf2b  sub rsp, 0x08
00007ec68bfdaf2f  push rax
00007ec68bfdaf30  push rcx
00007ec68bfdaf31  push rdx
00007ec68bfdaf32  push rdi
00007ec68bfdaf33  push rsi
00007ec68bfdaf34  push r8
00007ec68bfdaf36  push r9
00007ec68bfdaf38  push r10
00007ec68bfdaf3a  push r11
00007ec68bfdaf3c  sub rsp, 0xF0
00007ec68bfdaf43  vmovaps [rsp], xmm0
00007ec68bfdaf48  vmovaps [rsp+0x10], xmm1
00007ec68bfdaf4e  vmovaps [rsp+0x20], xmm2
00007ec68bfdaf54  vmovaps [rsp+0x30], xmm3
00007ec68bfdaf5a  vmovaps [rsp+0x40], xmm4
00007ec68bfdaf60  vmovaps [rsp+0x50], xmm5
00007ec68bfdaf66  vmovaps [rsp+0x60], xmm6
00007ec68bfdaf6c  vmovaps [rsp+0x70], xmm8
00007ec68bfdaf72  vmovaps [rsp+0x80], xmm9
00007ec68bfdaf7b  vmovaps [rsp+0x90], xmm10
00007ec68bfdaf84  vmovaps [rsp+0xA0], xmm11
00007ec68bfdaf8d  vmovaps [rsp+0xB0], xmm12
00007ec68bfdaf96  vmovaps [rsp+0xC0], xmm13
00007ec68bfdaf9f  vmovaps [rsp+0xD0], xmm14
00007ec68bfdafa8  vmovaps [rsp+0xE0], xmm15
00007ec68bfdafb1  sub rsp, 0x30
00007ec68bfdafb5  movaps [rsp], xmm7
00007ec68bfdafb9  movaps [rsp+0x10], xmm5
00007ec68bfdafbe  movaps [rsp+0x20], xmm15
00007ec68bfdafc4  lea rdi, [rsp]
00007ec68bfdafc8  mov esi, 0x00
00007ec68bfdafcd  mov rax, 0x57D97DADF530
00007ec68bfdafd7  call rax
00007ec68bfdafd9  movaps xmm7, [rsp]
00007ec68bfdafdd  add rsp, 0x30
00007ec68bfdafe1  vmovaps xmm0, [rsp]
00007ec68bfdafe6  vmovaps xmm1, [rsp+0x10]
00007ec68bfdafec  vmovaps xmm2, [rsp+0x20]
00007ec68bfdaff2  vmovaps xmm3, [rsp+0x30]
00007ec68bfdaff8  vmovaps xmm4, [rsp+0x40]
00007ec68bfdaffe  vmovaps xmm5, [rsp+0x50]
00007ec68bfdb004  vmovaps xmm6, [rsp+0x60]
00007ec68bfdb00a  vmovaps xmm8, [rsp+0x70]
00007ec68bfdb010  vmovaps xmm9, [rsp+0x80]
00007ec68bfdb019  vmovaps xmm10, [rsp+0x90]
00007ec68bfdb022  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdb02b  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdb034  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdb03d  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdb046  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdb04f  add rsp, 0xF0
00007ec68bfdb056  pop r11
00007ec68bfdb058  pop r10
00007ec68bfdb05a  pop r9
00007ec68bfdb05c  pop r8
00007ec68bfdb05e  pop rsi
00007ec68bfdb05f  pop rdi
00007ec68bfdb060  pop rdx
00007ec68bfdb061  pop rcx
00007ec68bfdb062  pop rax
00007ec68bfdb063  add rsp, 0x08
00007ec68bfdb067  jmp 0x00007EC68BFD9093
00007ec68bfdb06c  call 0x00007EC68BED64F0
00007ec68bfdb071  jmp 0x00007EC68BFD90A0
00007ec68bfdb076  sub rsp, 0x08
00007ec68bfdb07a  push rax
00007ec68bfdb07b  push rcx
00007ec68bfdb07c  push rdx
00007ec68bfdb07d  push rdi
00007ec68bfdb07e  push rsi
00007ec68bfdb07f  push r8
00007ec68bfdb081  push r9
00007ec68bfdb083  push r10
00007ec68bfdb085  push r11
00007ec68bfdb087  sub rsp, 0xF0
00007ec68bfdb08e  vmovaps [rsp], xmm0
00007ec68bfdb093  vmovaps [rsp+0x10], xmm1
00007ec68bfdb099  vmovaps [rsp+0x20], xmm2
00007ec68bfdb09f  vmovaps [rsp+0x30], xmm3
00007ec68bfdb0a5  vmovaps [rsp+0x40], xmm4
00007ec68bfdb0ab  vmovaps [rsp+0x50], xmm5
00007ec68bfdb0b1  vmovaps [rsp+0x60], xmm6
00007ec68bfdb0b7  vmovaps [rsp+0x70], xmm7
00007ec68bfdb0bd  vmovaps [rsp+0x80], xmm8
00007ec68bfdb0c6  vmovaps [rsp+0x90], xmm9
00007ec68bfdb0cf  vmovaps [rsp+0xA0], xmm10
00007ec68bfdb0d8  vmovaps [rsp+0xB0], xmm11
00007ec68bfdb0e1  vmovaps [rsp+0xC0], xmm12
00007ec68bfdb0ea  vmovaps [rsp+0xD0], xmm13
00007ec68bfdb0f3  vmovaps [rsp+0xE0], xmm14
00007ec68bfdb0fc  sub rsp, 0x30
00007ec68bfdb100  movaps [rsp], xmm15
00007ec68bfdb105  movaps [rsp+0x10], xmm5
00007ec68bfdb10a  movaps [rsp+0x20], xmm3
00007ec68bfdb10f  lea rdi, [rsp]
00007ec68bfdb113  mov esi, 0x00
00007ec68bfdb118  mov rax, 0x57D97DADF530
00007ec68bfdb122  call rax
00007ec68bfdb124  movaps xmm15, [rsp]
00007ec68bfdb129  add rsp, 0x30
00007ec68bfdb12d  vmovaps xmm0, [rsp]
00007ec68bfdb132  vmovaps xmm1, [rsp+0x10]
00007ec68bfdb138  vmovaps xmm2, [rsp+0x20]
00007ec68bfdb13e  vmovaps xmm3, [rsp+0x30]
00007ec68bfdb144  vmovaps xmm4, [rsp+0x40]
00007ec68bfdb14a  vmovaps xmm5, [rsp+0x50]
00007ec68bfdb150  vmovaps xmm6, [rsp+0x60]
00007ec68bfdb156  vmovaps xmm7, [rsp+0x70]
00007ec68bfdb15c  vmovaps xmm8, [rsp+0x80]
00007ec68bfdb165  vmovaps xmm9, [rsp+0x90]
00007ec68bfdb16e  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdb177  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdb180  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdb189  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdb192  vmovaps xmm14, [rsp+0xE0]
00007ec68bfdb19b  add rsp, 0xF0
00007ec68bfdb1a2  pop r11
00007ec68bfdb1a4  pop r10
00007ec68bfdb1a6  pop r9
00007ec68bfdb1a8  pop r8
00007ec68bfdb1aa  pop rsi
00007ec68bfdb1ab  pop rdi
00007ec68bfdb1ac  pop rdx
00007ec68bfdb1ad  pop rcx
00007ec68bfdb1ae  pop rax
00007ec68bfdb1af  add rsp, 0x08
00007ec68bfdb1b3  jmp 0x00007EC68BFD90C6
00007ec68bfdb1b8  sub rsp, 0x08
00007ec68bfdb1bc  push rax
00007ec68bfdb1bd  push rcx
00007ec68bfdb1be  push rdx
00007ec68bfdb1bf  push rdi
00007ec68bfdb1c0  push rsi
00007ec68bfdb1c1  push r8
00007ec68bfdb1c3  push r9
00007ec68bfdb1c5  push r10
00007ec68bfdb1c7  push r11
00007ec68bfdb1c9  sub rsp, 0xF0
00007ec68bfdb1d0  vmovaps [rsp], xmm0
00007ec68bfdb1d5  vmovaps [rsp+0x10], xmm2
00007ec68bfdb1db  vmovaps [rsp+0x20], xmm3
00007ec68bfdb1e1  vmovaps [rsp+0x30], xmm4
00007ec68bfdb1e7  vmovaps [rsp+0x40], xmm5
00007ec68bfdb1ed  vmovaps [rsp+0x50], xmm6
00007ec68bfdb1f3  vmovaps [rsp+0x60], xmm7
00007ec68bfdb1f9  vmovaps [rsp+0x70], xmm8
00007ec68bfdb1ff  vmovaps [rsp+0x80], xmm9
00007ec68bfdb208  vmovaps [rsp+0x90], xmm10
00007ec68bfdb211  vmovaps [rsp+0xA0], xmm11
00007ec68bfdb21a  vmovaps [rsp+0xB0], xmm12
00007ec68bfdb223  vmovaps [rsp+0xC0], xmm13
00007ec68bfdb22c  vmovaps [rsp+0xD0], xmm14
00007ec68bfdb235  vmovaps [rsp+0xE0], xmm15
00007ec68bfdb23e  sub rsp, 0x30
00007ec68bfdb242  movaps [rsp], xmm1
00007ec68bfdb246  movaps [rsp+0x10], xmm5
00007ec68bfdb24b  movaps [rsp+0x20], xmm4
00007ec68bfdb250  lea rdi, [rsp]
00007ec68bfdb254  mov esi, 0x00
00007ec68bfdb259  mov rax, 0x57D97DADF530
00007ec68bfdb263  call rax
00007ec68bfdb265  movaps xmm1, [rsp]
00007ec68bfdb269  add rsp, 0x30
00007ec68bfdb26d  vmovaps xmm0, [rsp]
00007ec68bfdb272  vmovaps xmm2, [rsp+0x10]
00007ec68bfdb278  vmovaps xmm3, [rsp+0x20]
00007ec68bfdb27e  vmovaps xmm4, [rsp+0x30]
00007ec68bfdb284  vmovaps xmm5, [rsp+0x40]
00007ec68bfdb28a  vmovaps xmm6, [rsp+0x50]
00007ec68bfdb290  vmovaps xmm7, [rsp+0x60]
00007ec68bfdb296  vmovaps xmm8, [rsp+0x70]
00007ec68bfdb29c  vmovaps xmm9, [rsp+0x80]
00007ec68bfdb2a5  vmovaps xmm10, [rsp+0x90]
00007ec68bfdb2ae  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdb2b7  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdb2c0  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdb2c9  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdb2d2  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdb2db  add rsp, 0xF0
00007ec68bfdb2e2  pop r11
00007ec68bfdb2e4  pop r10
00007ec68bfdb2e6  pop r9
00007ec68bfdb2e8  pop r8
00007ec68bfdb2ea  pop rsi
00007ec68bfdb2eb  pop rdi
00007ec68bfdb2ec  pop rdx
00007ec68bfdb2ed  pop rcx
00007ec68bfdb2ee  pop rax
00007ec68bfdb2ef  add rsp, 0x08
00007ec68bfdb2f3  jmp 0x00007EC68BFD90E6
00007ec68bfdb2f8  sub rsp, 0x08
00007ec68bfdb2fc  push rax
00007ec68bfdb2fd  push rcx
00007ec68bfdb2fe  push rdx
00007ec68bfdb2ff  push rdi
00007ec68bfdb300  push rsi
00007ec68bfdb301  push r8
00007ec68bfdb303  push r9
00007ec68bfdb305  push r10
00007ec68bfdb307  push r11
00007ec68bfdb309  sub rsp, 0xF0
00007ec68bfdb310  vmovaps [rsp], xmm0
00007ec68bfdb315  vmovaps [rsp+0x10], xmm1
00007ec68bfdb31b  vmovaps [rsp+0x20], xmm2
00007ec68bfdb321  vmovaps [rsp+0x30], xmm3
00007ec68bfdb327  vmovaps [rsp+0x40], xmm5
00007ec68bfdb32d  vmovaps [rsp+0x50], xmm6
00007ec68bfdb333  vmovaps [rsp+0x60], xmm7
00007ec68bfdb339  vmovaps [rsp+0x70], xmm8
00007ec68bfdb33f  vmovaps [rsp+0x80], xmm9
00007ec68bfdb348  vmovaps [rsp+0x90], xmm10
00007ec68bfdb351  vmovaps [rsp+0xA0], xmm11
00007ec68bfdb35a  vmovaps [rsp+0xB0], xmm12
00007ec68bfdb363  vmovaps [rsp+0xC0], xmm13
00007ec68bfdb36c  vmovaps [rsp+0xD0], xmm14
00007ec68bfdb375  vmovaps [rsp+0xE0], xmm15
00007ec68bfdb37e  sub rsp, 0x30
00007ec68bfdb382  movaps [rsp], xmm4
00007ec68bfdb386  movaps [rsp+0x10], xmm3
00007ec68bfdb38b  movaps [rsp+0x20], xmm5
00007ec68bfdb390  lea rdi, [rsp]
00007ec68bfdb394  mov esi, 0x00
00007ec68bfdb399  mov rax, 0x57D97DADF530
00007ec68bfdb3a3  call rax
00007ec68bfdb3a5  movaps xmm4, [rsp]
00007ec68bfdb3a9  add rsp, 0x30
00007ec68bfdb3ad  vmovaps xmm0, [rsp]
00007ec68bfdb3b2  vmovaps xmm1, [rsp+0x10]
00007ec68bfdb3b8  vmovaps xmm2, [rsp+0x20]
00007ec68bfdb3be  vmovaps xmm3, [rsp+0x30]
00007ec68bfdb3c4  vmovaps xmm5, [rsp+0x40]
00007ec68bfdb3ca  vmovaps xmm6, [rsp+0x50]
00007ec68bfdb3d0  vmovaps xmm7, [rsp+0x60]
00007ec68bfdb3d6  vmovaps xmm8, [rsp+0x70]
00007ec68bfdb3dc  vmovaps xmm9, [rsp+0x80]
00007ec68bfdb3e5  vmovaps xmm10, [rsp+0x90]
00007ec68bfdb3ee  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdb3f7  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdb400  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdb409  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdb412  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdb41b  add rsp, 0xF0
00007ec68bfdb422  pop r11
00007ec68bfdb424  pop r10
00007ec68bfdb426  pop r9
00007ec68bfdb428  pop r8
00007ec68bfdb42a  pop rsi
00007ec68bfdb42b  pop rdi
00007ec68bfdb42c  pop rdx
00007ec68bfdb42d  pop rcx
00007ec68bfdb42e  pop rax
00007ec68bfdb42f  add rsp, 0x08
00007ec68bfdb433  jmp 0x00007EC68BFD9134
00007ec68bfdb438  call 0x00007EC68BED64F0
00007ec68bfdb43d  jmp 0x00007EC68BFD9141
00007ec68bfdb442  sub rsp, 0x08
00007ec68bfdb446  push rax
00007ec68bfdb447  push rcx
00007ec68bfdb448  push rdx
00007ec68bfdb449  push rdi
00007ec68bfdb44a  push rsi
00007ec68bfdb44b  push r8
00007ec68bfdb44d  push r9
00007ec68bfdb44f  push r10
00007ec68bfdb451  push r11
00007ec68bfdb453  sub rsp, 0xF0
00007ec68bfdb45a  vmovaps [rsp], xmm0
00007ec68bfdb45f  vmovaps [rsp+0x10], xmm1
00007ec68bfdb465  vmovaps [rsp+0x20], xmm2
00007ec68bfdb46b  vmovaps [rsp+0x30], xmm3
00007ec68bfdb471  vmovaps [rsp+0x40], xmm4
00007ec68bfdb477  vmovaps [rsp+0x50], xmm6
00007ec68bfdb47d  vmovaps [rsp+0x60], xmm7
00007ec68bfdb483  vmovaps [rsp+0x70], xmm8
00007ec68bfdb489  vmovaps [rsp+0x80], xmm9
00007ec68bfdb492  vmovaps [rsp+0x90], xmm10
00007ec68bfdb49b  vmovaps [rsp+0xA0], xmm11
00007ec68bfdb4a4  vmovaps [rsp+0xB0], xmm12
00007ec68bfdb4ad  vmovaps [rsp+0xC0], xmm13
00007ec68bfdb4b6  vmovaps [rsp+0xD0], xmm14
00007ec68bfdb4bf  vmovaps [rsp+0xE0], xmm15
00007ec68bfdb4c8  sub rsp, 0x30
00007ec68bfdb4cc  movaps [rsp], xmm5
00007ec68bfdb4d0  movaps [rsp+0x10], xmm6
00007ec68bfdb4d5  movaps [rsp+0x20], xmm3
00007ec68bfdb4da  lea rdi, [rsp]
00007ec68bfdb4de  mov esi, 0x00
00007ec68bfdb4e3  mov rax, 0x57D97DADF530
00007ec68bfdb4ed  call rax
00007ec68bfdb4ef  movaps xmm5, [rsp]
00007ec68bfdb4f3  add rsp, 0x30
00007ec68bfdb4f7  vmovaps xmm0, [rsp]
00007ec68bfdb4fc  vmovaps xmm1, [rsp+0x10]
00007ec68bfdb502  vmovaps xmm2, [rsp+0x20]
00007ec68bfdb508  vmovaps xmm3, [rsp+0x30]
00007ec68bfdb50e  vmovaps xmm4, [rsp+0x40]
00007ec68bfdb514  vmovaps xmm6, [rsp+0x50]
00007ec68bfdb51a  vmovaps xmm7, [rsp+0x60]
00007ec68bfdb520  vmovaps xmm8, [rsp+0x70]
00007ec68bfdb526  vmovaps xmm9, [rsp+0x80]
00007ec68bfdb52f  vmovaps xmm10, [rsp+0x90]
00007ec68bfdb538  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdb541  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdb54a  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdb553  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdb55c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdb565  add rsp, 0xF0
00007ec68bfdb56c  pop r11
00007ec68bfdb56e  pop r10
00007ec68bfdb570  pop r9
00007ec68bfdb572  pop r8
00007ec68bfdb574  pop rsi
00007ec68bfdb575  pop rdi
00007ec68bfdb576  pop rdx
00007ec68bfdb577  pop rcx
00007ec68bfdb578  pop rax
00007ec68bfdb579  add rsp, 0x08
00007ec68bfdb57d  jmp 0x00007EC68BFD9167
00007ec68bfdb582  sub rsp, 0x08
00007ec68bfdb586  push rax
00007ec68bfdb587  push rcx
00007ec68bfdb588  push rdx
00007ec68bfdb589  push rdi
00007ec68bfdb58a  push rsi
00007ec68bfdb58b  push r8
00007ec68bfdb58d  push r9
00007ec68bfdb58f  push r10
00007ec68bfdb591  push r11
00007ec68bfdb593  sub rsp, 0xF0
00007ec68bfdb59a  vmovaps [rsp], xmm0
00007ec68bfdb59f  vmovaps [rsp+0x10], xmm1
00007ec68bfdb5a5  vmovaps [rsp+0x20], xmm2
00007ec68bfdb5ab  vmovaps [rsp+0x30], xmm3
00007ec68bfdb5b1  vmovaps [rsp+0x40], xmm4
00007ec68bfdb5b7  vmovaps [rsp+0x50], xmm5
00007ec68bfdb5bd  vmovaps [rsp+0x60], xmm7
00007ec68bfdb5c3  vmovaps [rsp+0x70], xmm8
00007ec68bfdb5c9  vmovaps [rsp+0x80], xmm9
00007ec68bfdb5d2  vmovaps [rsp+0x90], xmm10
00007ec68bfdb5db  vmovaps [rsp+0xA0], xmm11
00007ec68bfdb5e4  vmovaps [rsp+0xB0], xmm12
00007ec68bfdb5ed  vmovaps [rsp+0xC0], xmm13
00007ec68bfdb5f6  vmovaps [rsp+0xD0], xmm14
00007ec68bfdb5ff  vmovaps [rsp+0xE0], xmm15
00007ec68bfdb608  sub rsp, 0x30
00007ec68bfdb60c  movaps [rsp], xmm6
00007ec68bfdb610  movaps [rsp+0x10], xmm9
00007ec68bfdb616  movaps [rsp+0x20], xmm1
00007ec68bfdb61b  lea rdi, [rsp]
00007ec68bfdb61f  mov esi, 0x00
00007ec68bfdb624  mov rax, 0x57D97DADF530
00007ec68bfdb62e  call rax
00007ec68bfdb630  movaps xmm6, [rsp]
00007ec68bfdb634  add rsp, 0x30
00007ec68bfdb638  vmovaps xmm0, [rsp]
00007ec68bfdb63d  vmovaps xmm1, [rsp+0x10]
00007ec68bfdb643  vmovaps xmm2, [rsp+0x20]
00007ec68bfdb649  vmovaps xmm3, [rsp+0x30]
00007ec68bfdb64f  vmovaps xmm4, [rsp+0x40]
00007ec68bfdb655  vmovaps xmm5, [rsp+0x50]
00007ec68bfdb65b  vmovaps xmm7, [rsp+0x60]
00007ec68bfdb661  vmovaps xmm8, [rsp+0x70]
00007ec68bfdb667  vmovaps xmm9, [rsp+0x80]
00007ec68bfdb670  vmovaps xmm10, [rsp+0x90]
00007ec68bfdb679  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdb682  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdb68b  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdb694  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdb69d  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdb6a6  add rsp, 0xF0
00007ec68bfdb6ad  pop r11
00007ec68bfdb6af  pop r10
00007ec68bfdb6b1  pop r9
00007ec68bfdb6b3  pop r8
00007ec68bfdb6b5  pop rsi
00007ec68bfdb6b6  pop rdi
00007ec68bfdb6b7  pop rdx
00007ec68bfdb6b8  pop rcx
00007ec68bfdb6b9  pop rax
00007ec68bfdb6ba  add rsp, 0x08
00007ec68bfdb6be  jmp 0x00007EC68BFD918B
00007ec68bfdb6c3  sub rsp, 0x08
00007ec68bfdb6c7  push rax
00007ec68bfdb6c8  push rcx
00007ec68bfdb6c9  push rdx
00007ec68bfdb6ca  push rdi
00007ec68bfdb6cb  push rsi
00007ec68bfdb6cc  push r8
00007ec68bfdb6ce  push r9
00007ec68bfdb6d0  push r10
00007ec68bfdb6d2  push r11
00007ec68bfdb6d4  sub rsp, 0xF0
00007ec68bfdb6db  vmovaps [rsp], xmm0
00007ec68bfdb6e0  vmovaps [rsp+0x10], xmm1
00007ec68bfdb6e6  vmovaps [rsp+0x20], xmm2
00007ec68bfdb6ec  vmovaps [rsp+0x30], xmm3
00007ec68bfdb6f2  vmovaps [rsp+0x40], xmm4
00007ec68bfdb6f8  vmovaps [rsp+0x50], xmm5
00007ec68bfdb6fe  vmovaps [rsp+0x60], xmm6
00007ec68bfdb704  vmovaps [rsp+0x70], xmm7
00007ec68bfdb70a  vmovaps [rsp+0x80], xmm8
00007ec68bfdb713  vmovaps [rsp+0x90], xmm10
00007ec68bfdb71c  vmovaps [rsp+0xA0], xmm11
00007ec68bfdb725  vmovaps [rsp+0xB0], xmm12
00007ec68bfdb72e  vmovaps [rsp+0xC0], xmm13
00007ec68bfdb737  vmovaps [rsp+0xD0], xmm14
00007ec68bfdb740  vmovaps [rsp+0xE0], xmm15
00007ec68bfdb749  sub rsp, 0x30
00007ec68bfdb74d  movaps [rsp], xmm9
00007ec68bfdb752  movaps [rsp+0x10], xmm3
00007ec68bfdb757  movaps [rsp+0x20], xmm1
00007ec68bfdb75c  lea rdi, [rsp]
00007ec68bfdb760  mov esi, 0x00
00007ec68bfdb765  mov rax, 0x57D97DADF530
00007ec68bfdb76f  call rax
00007ec68bfdb771  movaps xmm9, [rsp]
00007ec68bfdb776  add rsp, 0x30
00007ec68bfdb77a  vmovaps xmm0, [rsp]
00007ec68bfdb77f  vmovaps xmm1, [rsp+0x10]
00007ec68bfdb785  vmovaps xmm2, [rsp+0x20]
00007ec68bfdb78b  vmovaps xmm3, [rsp+0x30]
00007ec68bfdb791  vmovaps xmm4, [rsp+0x40]
00007ec68bfdb797  vmovaps xmm5, [rsp+0x50]
00007ec68bfdb79d  vmovaps xmm6, [rsp+0x60]
00007ec68bfdb7a3  vmovaps xmm7, [rsp+0x70]
00007ec68bfdb7a9  vmovaps xmm8, [rsp+0x80]
00007ec68bfdb7b2  vmovaps xmm10, [rsp+0x90]
00007ec68bfdb7bb  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdb7c4  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdb7cd  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdb7d6  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdb7df  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdb7e8  add rsp, 0xF0
00007ec68bfdb7ef  pop r11
00007ec68bfdb7f1  pop r10
00007ec68bfdb7f3  pop r9
00007ec68bfdb7f5  pop r8
00007ec68bfdb7f7  pop rsi
00007ec68bfdb7f8  pop rdi
00007ec68bfdb7f9  pop rdx
00007ec68bfdb7fa  pop rcx
00007ec68bfdb7fb  pop rax
00007ec68bfdb7fc  add rsp, 0x08
00007ec68bfdb800  jmp 0x00007EC68BFD91D7
00007ec68bfdb805  call 0x00007EC68BED64F0
00007ec68bfdb80a  jmp 0x00007EC68BFD91E4
00007ec68bfdb80f  sub rsp, 0x08
00007ec68bfdb813  push rax
00007ec68bfdb814  push rcx
00007ec68bfdb815  push rdx
00007ec68bfdb816  push rdi
00007ec68bfdb817  push rsi
00007ec68bfdb818  push r8
00007ec68bfdb81a  push r9
00007ec68bfdb81c  push r10
00007ec68bfdb81e  push r11
00007ec68bfdb820  sub rsp, 0xF0
00007ec68bfdb827  vmovaps [rsp], xmm0
00007ec68bfdb82c  vmovaps [rsp+0x10], xmm1
00007ec68bfdb832  vmovaps [rsp+0x20], xmm2
00007ec68bfdb838  vmovaps [rsp+0x30], xmm3
00007ec68bfdb83e  vmovaps [rsp+0x40], xmm4
00007ec68bfdb844  vmovaps [rsp+0x50], xmm5
00007ec68bfdb84a  vmovaps [rsp+0x60], xmm6
00007ec68bfdb850  vmovaps [rsp+0x70], xmm7
00007ec68bfdb856  vmovaps [rsp+0x80], xmm8
00007ec68bfdb85f  vmovaps [rsp+0x90], xmm9
00007ec68bfdb868  vmovaps [rsp+0xA0], xmm10
00007ec68bfdb871  vmovaps [rsp+0xB0], xmm11
00007ec68bfdb87a  vmovaps [rsp+0xC0], xmm12
00007ec68bfdb883  vmovaps [rsp+0xD0], xmm13
00007ec68bfdb88c  vmovaps [rsp+0xE0], xmm14
00007ec68bfdb895  sub rsp, 0x30
00007ec68bfdb899  movaps [rsp], xmm15
00007ec68bfdb89e  movaps [rsp+0x10], xmm3
00007ec68bfdb8a3  movaps [rsp+0x20], xmm7
00007ec68bfdb8a8  lea rdi, [rsp]
00007ec68bfdb8ac  mov esi, 0x00
00007ec68bfdb8b1  mov rax, 0x57D97DADF530
00007ec68bfdb8bb  call rax
00007ec68bfdb8bd  movaps xmm15, [rsp]
00007ec68bfdb8c2  add rsp, 0x30
00007ec68bfdb8c6  vmovaps xmm0, [rsp]
00007ec68bfdb8cb  vmovaps xmm1, [rsp+0x10]
00007ec68bfdb8d1  vmovaps xmm2, [rsp+0x20]
00007ec68bfdb8d7  vmovaps xmm3, [rsp+0x30]
00007ec68bfdb8dd  vmovaps xmm4, [rsp+0x40]
00007ec68bfdb8e3  vmovaps xmm5, [rsp+0x50]
00007ec68bfdb8e9  vmovaps xmm6, [rsp+0x60]
00007ec68bfdb8ef  vmovaps xmm7, [rsp+0x70]
00007ec68bfdb8f5  vmovaps xmm8, [rsp+0x80]
00007ec68bfdb8fe  vmovaps xmm9, [rsp+0x90]
00007ec68bfdb907  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdb910  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdb919  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdb922  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdb92b  vmovaps xmm14, [rsp+0xE0]
00007ec68bfdb934  add rsp, 0xF0
00007ec68bfdb93b  pop r11
00007ec68bfdb93d  pop r10
00007ec68bfdb93f  pop r9
00007ec68bfdb941  pop r8
00007ec68bfdb943  pop rsi
00007ec68bfdb944  pop rdi
00007ec68bfdb945  pop rdx
00007ec68bfdb946  pop rcx
00007ec68bfdb947  pop rax
00007ec68bfdb948  add rsp, 0x08
00007ec68bfdb94c  jmp 0x00007EC68BFD9210
00007ec68bfdb951  sub rsp, 0x08
00007ec68bfdb955  push rax
00007ec68bfdb956  push rcx
00007ec68bfdb957  push rdx
00007ec68bfdb958  push rdi
00007ec68bfdb959  push rsi
00007ec68bfdb95a  push r8
00007ec68bfdb95c  push r9
00007ec68bfdb95e  push r10
00007ec68bfdb960  push r11
00007ec68bfdb962  sub rsp, 0xF0
00007ec68bfdb969  vmovaps [rsp], xmm0
00007ec68bfdb96e  vmovaps [rsp+0x10], xmm1
00007ec68bfdb974  vmovaps [rsp+0x20], xmm2
00007ec68bfdb97a  vmovaps [rsp+0x30], xmm4
00007ec68bfdb980  vmovaps [rsp+0x40], xmm5
00007ec68bfdb986  vmovaps [rsp+0x50], xmm6
00007ec68bfdb98c  vmovaps [rsp+0x60], xmm7
00007ec68bfdb992  vmovaps [rsp+0x70], xmm8
00007ec68bfdb998  vmovaps [rsp+0x80], xmm9
00007ec68bfdb9a1  vmovaps [rsp+0x90], xmm10
00007ec68bfdb9aa  vmovaps [rsp+0xA0], xmm11
00007ec68bfdb9b3  vmovaps [rsp+0xB0], xmm12
00007ec68bfdb9bc  vmovaps [rsp+0xC0], xmm13
00007ec68bfdb9c5  vmovaps [rsp+0xD0], xmm14
00007ec68bfdb9ce  vmovaps [rsp+0xE0], xmm15
00007ec68bfdb9d7  sub rsp, 0x30
00007ec68bfdb9db  movaps [rsp], xmm3
00007ec68bfdb9df  movaps [rsp+0x10], xmm1
00007ec68bfdb9e4  movaps [rsp+0x20], xmm15
00007ec68bfdb9ea  lea rdi, [rsp]
00007ec68bfdb9ee  mov esi, 0x00
00007ec68bfdb9f3  mov rax, 0x57D97DADF530
00007ec68bfdb9fd  call rax
00007ec68bfdb9ff  movaps xmm3, [rsp]
00007ec68bfdba03  add rsp, 0x30
00007ec68bfdba07  vmovaps xmm0, [rsp]
00007ec68bfdba0c  vmovaps xmm1, [rsp+0x10]
00007ec68bfdba12  vmovaps xmm2, [rsp+0x20]
00007ec68bfdba18  vmovaps xmm4, [rsp+0x30]
00007ec68bfdba1e  vmovaps xmm5, [rsp+0x40]
00007ec68bfdba24  vmovaps xmm6, [rsp+0x50]
00007ec68bfdba2a  vmovaps xmm7, [rsp+0x60]
00007ec68bfdba30  vmovaps xmm8, [rsp+0x70]
00007ec68bfdba36  vmovaps xmm9, [rsp+0x80]
00007ec68bfdba3f  vmovaps xmm10, [rsp+0x90]
00007ec68bfdba48  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdba51  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdba5a  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdba63  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdba6c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdba75  add rsp, 0xF0
00007ec68bfdba7c  pop r11
00007ec68bfdba7e  pop r10
00007ec68bfdba80  pop r9
00007ec68bfdba82  pop r8
00007ec68bfdba84  pop rsi
00007ec68bfdba85  pop rdi
00007ec68bfdba86  pop rdx
00007ec68bfdba87  pop rcx
00007ec68bfdba88  pop rax
00007ec68bfdba89  add rsp, 0x08
00007ec68bfdba8d  jmp 0x00007EC68BFD929F
00007ec68bfdba92  call 0x00007EC68BED64F0
00007ec68bfdba97  jmp 0x00007EC68BFD92A9
00007ec68bfdba9c  sub rsp, 0x08
00007ec68bfdbaa0  push rax
00007ec68bfdbaa1  push rcx
00007ec68bfdbaa2  push rdx
00007ec68bfdbaa3  push rdi
00007ec68bfdbaa4  push rsi
00007ec68bfdbaa5  push r8
00007ec68bfdbaa7  push r9
00007ec68bfdbaa9  push r10
00007ec68bfdbaab  push r11
00007ec68bfdbaad  sub rsp, 0xF0
00007ec68bfdbab4  vmovaps [rsp], xmm0
00007ec68bfdbab9  vmovaps [rsp+0x10], xmm1
00007ec68bfdbabf  vmovaps [rsp+0x20], xmm2
00007ec68bfdbac5  vmovaps [rsp+0x30], xmm3
00007ec68bfdbacb  vmovaps [rsp+0x40], xmm4
00007ec68bfdbad1  vmovaps [rsp+0x50], xmm5
00007ec68bfdbad7  vmovaps [rsp+0x60], xmm6
00007ec68bfdbadd  vmovaps [rsp+0x70], xmm7
00007ec68bfdbae3  vmovaps [rsp+0x80], xmm8
00007ec68bfdbaec  vmovaps [rsp+0x90], xmm9
00007ec68bfdbaf5  vmovaps [rsp+0xA0], xmm10
00007ec68bfdbafe  vmovaps [rsp+0xB0], xmm11
00007ec68bfdbb07  vmovaps [rsp+0xC0], xmm12
00007ec68bfdbb10  vmovaps [rsp+0xD0], xmm13
00007ec68bfdbb19  vmovaps [rsp+0xE0], xmm14
00007ec68bfdbb22  sub rsp, 0x30
00007ec68bfdbb26  movaps [rsp], xmm15
00007ec68bfdbb2b  movaps [rsp+0x10], xmm14
00007ec68bfdbb31  movaps [rsp+0x20], xmm4
00007ec68bfdbb36  lea rdi, [rsp]
00007ec68bfdbb3a  mov esi, 0x00
00007ec68bfdbb3f  mov rax, 0x57D97DADF530
00007ec68bfdbb49  call rax
00007ec68bfdbb4b  movaps xmm15, [rsp]
00007ec68bfdbb50  add rsp, 0x30
00007ec68bfdbb54  vmovaps xmm0, [rsp]
00007ec68bfdbb59  vmovaps xmm1, [rsp+0x10]
00007ec68bfdbb5f  vmovaps xmm2, [rsp+0x20]
00007ec68bfdbb65  vmovaps xmm3, [rsp+0x30]
00007ec68bfdbb6b  vmovaps xmm4, [rsp+0x40]
00007ec68bfdbb71  vmovaps xmm5, [rsp+0x50]
00007ec68bfdbb77  vmovaps xmm6, [rsp+0x60]
00007ec68bfdbb7d  vmovaps xmm7, [rsp+0x70]
00007ec68bfdbb83  vmovaps xmm8, [rsp+0x80]
00007ec68bfdbb8c  vmovaps xmm9, [rsp+0x90]
00007ec68bfdbb95  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdbb9e  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdbba7  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdbbb0  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdbbb9  vmovaps xmm14, [rsp+0xE0]
00007ec68bfdbbc2  add rsp, 0xF0
00007ec68bfdbbc9  pop r11
00007ec68bfdbbcb  pop r10
00007ec68bfdbbcd  pop r9
00007ec68bfdbbcf  pop r8
00007ec68bfdbbd1  pop rsi
00007ec68bfdbbd2  pop rdi
00007ec68bfdbbd3  pop rdx
00007ec68bfdbbd4  pop rcx
00007ec68bfdbbd5  pop rax
00007ec68bfdbbd6  add rsp, 0x08
00007ec68bfdbbda  jmp 0x00007EC68BFD92D7
00007ec68bfdbbdf  sub rsp, 0x08
00007ec68bfdbbe3  push rax
00007ec68bfdbbe4  push rcx
00007ec68bfdbbe5  push rdx
00007ec68bfdbbe6  push rdi
00007ec68bfdbbe7  push rsi
00007ec68bfdbbe8  push r8
00007ec68bfdbbea  push r9
00007ec68bfdbbec  push r10
00007ec68bfdbbee  push r11
00007ec68bfdbbf0  sub rsp, 0xF0
00007ec68bfdbbf7  vmovaps [rsp], xmm0
00007ec68bfdbbfc  vmovaps [rsp+0x10], xmm1
00007ec68bfdbc02  vmovaps [rsp+0x20], xmm2
00007ec68bfdbc08  vmovaps [rsp+0x30], xmm3
00007ec68bfdbc0e  vmovaps [rsp+0x40], xmm4
00007ec68bfdbc14  vmovaps [rsp+0x50], xmm5
00007ec68bfdbc1a  vmovaps [rsp+0x60], xmm6
00007ec68bfdbc20  vmovaps [rsp+0x70], xmm7
00007ec68bfdbc26  vmovaps [rsp+0x80], xmm8
00007ec68bfdbc2f  vmovaps [rsp+0x90], xmm9
00007ec68bfdbc38  vmovaps [rsp+0xA0], xmm10
00007ec68bfdbc41  vmovaps [rsp+0xB0], xmm11
00007ec68bfdbc4a  vmovaps [rsp+0xC0], xmm12
00007ec68bfdbc53  vmovaps [rsp+0xD0], xmm13
00007ec68bfdbc5c  vmovaps [rsp+0xE0], xmm15
00007ec68bfdbc65  sub rsp, 0x30
00007ec68bfdbc69  movaps [rsp], xmm14
00007ec68bfdbc6e  movaps [rsp+0x10], xmm2
00007ec68bfdbc73  movaps [rsp+0x20], xmm1
00007ec68bfdbc78  lea rdi, [rsp]
00007ec68bfdbc7c  mov esi, 0x00
00007ec68bfdbc81  mov rax, 0x57D97DADF530
00007ec68bfdbc8b  call rax
00007ec68bfdbc8d  movaps xmm14, [rsp]
00007ec68bfdbc92  add rsp, 0x30
00007ec68bfdbc96  vmovaps xmm0, [rsp]
00007ec68bfdbc9b  vmovaps xmm1, [rsp+0x10]
00007ec68bfdbca1  vmovaps xmm2, [rsp+0x20]
00007ec68bfdbca7  vmovaps xmm3, [rsp+0x30]
00007ec68bfdbcad  vmovaps xmm4, [rsp+0x40]
00007ec68bfdbcb3  vmovaps xmm5, [rsp+0x50]
00007ec68bfdbcb9  vmovaps xmm6, [rsp+0x60]
00007ec68bfdbcbf  vmovaps xmm7, [rsp+0x70]
00007ec68bfdbcc5  vmovaps xmm8, [rsp+0x80]
00007ec68bfdbcce  vmovaps xmm9, [rsp+0x90]
00007ec68bfdbcd7  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdbce0  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdbce9  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdbcf2  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdbcfb  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdbd04  add rsp, 0xF0
00007ec68bfdbd0b  pop r11
00007ec68bfdbd0d  pop r10
00007ec68bfdbd0f  pop r9
00007ec68bfdbd11  pop r8
00007ec68bfdbd13  pop rsi
00007ec68bfdbd14  pop rdi
00007ec68bfdbd15  pop rdx
00007ec68bfdbd16  pop rcx
00007ec68bfdbd17  pop rax
00007ec68bfdbd18  add rsp, 0x08
00007ec68bfdbd1c  jmp 0x00007EC68BFD92FD
00007ec68bfdbd21  sub rsp, 0x08
00007ec68bfdbd25  push rax
00007ec68bfdbd26  push rcx
00007ec68bfdbd27  push rdx
00007ec68bfdbd28  push rdi
00007ec68bfdbd29  push rsi
00007ec68bfdbd2a  push r8
00007ec68bfdbd2c  push r9
00007ec68bfdbd2e  push r10
00007ec68bfdbd30  push r11
00007ec68bfdbd32  sub rsp, 0xF0
00007ec68bfdbd39  vmovaps [rsp], xmm0
00007ec68bfdbd3e  vmovaps [rsp+0x10], xmm2
00007ec68bfdbd44  vmovaps [rsp+0x20], xmm3
00007ec68bfdbd4a  vmovaps [rsp+0x30], xmm4
00007ec68bfdbd50  vmovaps [rsp+0x40], xmm5
00007ec68bfdbd56  vmovaps [rsp+0x50], xmm6
00007ec68bfdbd5c  vmovaps [rsp+0x60], xmm7
00007ec68bfdbd62  vmovaps [rsp+0x70], xmm8
00007ec68bfdbd68  vmovaps [rsp+0x80], xmm9
00007ec68bfdbd71  vmovaps [rsp+0x90], xmm10
00007ec68bfdbd7a  vmovaps [rsp+0xA0], xmm11
00007ec68bfdbd83  vmovaps [rsp+0xB0], xmm12
00007ec68bfdbd8c  vmovaps [rsp+0xC0], xmm13
00007ec68bfdbd95  vmovaps [rsp+0xD0], xmm14
00007ec68bfdbd9e  vmovaps [rsp+0xE0], xmm15
00007ec68bfdbda7  sub rsp, 0x30
00007ec68bfdbdab  movaps [rsp], xmm1
00007ec68bfdbdaf  movaps [rsp+0x10], xmm4
00007ec68bfdbdb4  movaps [rsp+0x20], xmm9
00007ec68bfdbdba  lea rdi, [rsp]
00007ec68bfdbdbe  mov esi, 0x00
00007ec68bfdbdc3  mov rax, 0x57D97DADF530
00007ec68bfdbdcd  call rax
00007ec68bfdbdcf  movaps xmm1, [rsp]
00007ec68bfdbdd3  add rsp, 0x30
00007ec68bfdbdd7  vmovaps xmm0, [rsp]
00007ec68bfdbddc  vmovaps xmm2, [rsp+0x10]
00007ec68bfdbde2  vmovaps xmm3, [rsp+0x20]
00007ec68bfdbde8  vmovaps xmm4, [rsp+0x30]
00007ec68bfdbdee  vmovaps xmm5, [rsp+0x40]
00007ec68bfdbdf4  vmovaps xmm6, [rsp+0x50]
00007ec68bfdbdfa  vmovaps xmm7, [rsp+0x60]
00007ec68bfdbe00  vmovaps xmm8, [rsp+0x70]
00007ec68bfdbe06  vmovaps xmm9, [rsp+0x80]
00007ec68bfdbe0f  vmovaps xmm10, [rsp+0x90]
00007ec68bfdbe18  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdbe21  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdbe2a  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdbe33  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdbe3c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdbe45  add rsp, 0xF0
00007ec68bfdbe4c  pop r11
00007ec68bfdbe4e  pop r10
00007ec68bfdbe50  pop r9
00007ec68bfdbe52  pop r8
00007ec68bfdbe54  pop rsi
00007ec68bfdbe55  pop rdi
00007ec68bfdbe56  pop rdx
00007ec68bfdbe57  pop rcx
00007ec68bfdbe58  pop rax
00007ec68bfdbe59  add rsp, 0x08
00007ec68bfdbe5d  jmp 0x00007EC68BFD931B
00007ec68bfdbe62  sub rsp, 0x08
00007ec68bfdbe66  push rax
00007ec68bfdbe67  push rcx
00007ec68bfdbe68  push rdx
00007ec68bfdbe69  push rdi
00007ec68bfdbe6a  push rsi
00007ec68bfdbe6b  push r8
00007ec68bfdbe6d  push r9
00007ec68bfdbe6f  push r10
00007ec68bfdbe71  push r11
00007ec68bfdbe73  sub rsp, 0xF0
00007ec68bfdbe7a  vmovaps [rsp], xmm0
00007ec68bfdbe7f  vmovaps [rsp+0x10], xmm1
00007ec68bfdbe85  vmovaps [rsp+0x20], xmm2
00007ec68bfdbe8b  vmovaps [rsp+0x30], xmm3
00007ec68bfdbe91  vmovaps [rsp+0x40], xmm5
00007ec68bfdbe97  vmovaps [rsp+0x50], xmm6
00007ec68bfdbe9d  vmovaps [rsp+0x60], xmm7
00007ec68bfdbea3  vmovaps [rsp+0x70], xmm8
00007ec68bfdbea9  vmovaps [rsp+0x80], xmm9
00007ec68bfdbeb2  vmovaps [rsp+0x90], xmm10
00007ec68bfdbebb  vmovaps [rsp+0xA0], xmm11
00007ec68bfdbec4  vmovaps [rsp+0xB0], xmm12
00007ec68bfdbecd  vmovaps [rsp+0xC0], xmm13
00007ec68bfdbed6  vmovaps [rsp+0xD0], xmm14
00007ec68bfdbedf  vmovaps [rsp+0xE0], xmm15
00007ec68bfdbee8  sub rsp, 0x30
00007ec68bfdbeec  movaps [rsp], xmm4
00007ec68bfdbef0  movaps [rsp+0x10], xmm2
00007ec68bfdbef5  movaps [rsp+0x20], xmm9
00007ec68bfdbefb  lea rdi, [rsp]
00007ec68bfdbeff  mov esi, 0x00
00007ec68bfdbf04  mov rax, 0x57D97DADF530
00007ec68bfdbf0e  call rax
00007ec68bfdbf10  movaps xmm4, [rsp]
00007ec68bfdbf14  add rsp, 0x30
00007ec68bfdbf18  vmovaps xmm0, [rsp]
00007ec68bfdbf1d  vmovaps xmm1, [rsp+0x10]
00007ec68bfdbf23  vmovaps xmm2, [rsp+0x20]
00007ec68bfdbf29  vmovaps xmm3, [rsp+0x30]
00007ec68bfdbf2f  vmovaps xmm5, [rsp+0x40]
00007ec68bfdbf35  vmovaps xmm6, [rsp+0x50]
00007ec68bfdbf3b  vmovaps xmm7, [rsp+0x60]
00007ec68bfdbf41  vmovaps xmm8, [rsp+0x70]
00007ec68bfdbf47  vmovaps xmm9, [rsp+0x80]
00007ec68bfdbf50  vmovaps xmm10, [rsp+0x90]
00007ec68bfdbf59  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdbf62  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdbf6b  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdbf74  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdbf7d  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdbf86  add rsp, 0xF0
00007ec68bfdbf8d  pop r11
00007ec68bfdbf8f  pop r10
00007ec68bfdbf91  pop r9
00007ec68bfdbf93  pop r8
00007ec68bfdbf95  pop rsi
00007ec68bfdbf96  pop rdi
00007ec68bfdbf97  pop rdx
00007ec68bfdbf98  pop rcx
00007ec68bfdbf99  pop rax
00007ec68bfdbf9a  add rsp, 0x08
00007ec68bfdbf9e  jmp 0x00007EC68BFD934B
00007ec68bfdbfa3  sub rsp, 0x08
00007ec68bfdbfa7  push rax
00007ec68bfdbfa8  push rcx
00007ec68bfdbfa9  push rdx
00007ec68bfdbfaa  push rdi
00007ec68bfdbfab  push rsi
00007ec68bfdbfac  push r8
00007ec68bfdbfae  push r9
00007ec68bfdbfb0  push r10
00007ec68bfdbfb2  push r11
00007ec68bfdbfb4  sub rsp, 0xF0
00007ec68bfdbfbb  vmovaps [rsp], xmm0
00007ec68bfdbfc0  vmovaps [rsp+0x10], xmm1
00007ec68bfdbfc6  vmovaps [rsp+0x20], xmm2
00007ec68bfdbfcc  vmovaps [rsp+0x30], xmm3
00007ec68bfdbfd2  vmovaps [rsp+0x40], xmm4
00007ec68bfdbfd8  vmovaps [rsp+0x50], xmm5
00007ec68bfdbfde  vmovaps [rsp+0x60], xmm6
00007ec68bfdbfe4  vmovaps [rsp+0x70], xmm7
00007ec68bfdbfea  vmovaps [rsp+0x80], xmm8
00007ec68bfdbff3  vmovaps [rsp+0x90], xmm10
00007ec68bfdbffc  vmovaps [rsp+0xA0], xmm11
00007ec68bfdc005  vmovaps [rsp+0xB0], xmm12
00007ec68bfdc00e  vmovaps [rsp+0xC0], xmm13
00007ec68bfdc017  vmovaps [rsp+0xD0], xmm14
00007ec68bfdc020  vmovaps [rsp+0xE0], xmm15
00007ec68bfdc029  sub rsp, 0x30
00007ec68bfdc02d  movaps [rsp], xmm9
00007ec68bfdc032  movaps [rsp+0x10], xmm2
00007ec68bfdc037  movaps [rsp+0x20], xmm1
00007ec68bfdc03c  lea rdi, [rsp]
00007ec68bfdc040  mov esi, 0x00
00007ec68bfdc045  mov rax, 0x57D97DADF530
00007ec68bfdc04f  call rax
00007ec68bfdc051  movaps xmm9, [rsp]
00007ec68bfdc056  add rsp, 0x30
00007ec68bfdc05a  vmovaps xmm0, [rsp]
00007ec68bfdc05f  vmovaps xmm1, [rsp+0x10]
00007ec68bfdc065  vmovaps xmm2, [rsp+0x20]
00007ec68bfdc06b  vmovaps xmm3, [rsp+0x30]
00007ec68bfdc071  vmovaps xmm4, [rsp+0x40]
00007ec68bfdc077  vmovaps xmm5, [rsp+0x50]
00007ec68bfdc07d  vmovaps xmm6, [rsp+0x60]
00007ec68bfdc083  vmovaps xmm7, [rsp+0x70]
00007ec68bfdc089  vmovaps xmm8, [rsp+0x80]
00007ec68bfdc092  vmovaps xmm10, [rsp+0x90]
00007ec68bfdc09b  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdc0a4  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdc0ad  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdc0b6  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdc0bf  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdc0c8  add rsp, 0xF0
00007ec68bfdc0cf  pop r11
00007ec68bfdc0d1  pop r10
00007ec68bfdc0d3  pop r9
00007ec68bfdc0d5  pop r8
00007ec68bfdc0d7  pop rsi
00007ec68bfdc0d8  pop rdi
00007ec68bfdc0d9  pop rdx
00007ec68bfdc0da  pop rcx
00007ec68bfdc0db  pop rax
00007ec68bfdc0dc  add rsp, 0x08
00007ec68bfdc0e0  jmp 0x00007EC68BFD9381
00007ec68bfdc0e5  sub rsp, 0x08
00007ec68bfdc0e9  push rax
00007ec68bfdc0ea  push rcx
00007ec68bfdc0eb  push rdx
00007ec68bfdc0ec  push rdi
00007ec68bfdc0ed  push rsi
00007ec68bfdc0ee  push r8
00007ec68bfdc0f0  push r9
00007ec68bfdc0f2  push r10
00007ec68bfdc0f4  push r11
00007ec68bfdc0f6  sub rsp, 0xF0
00007ec68bfdc0fd  vmovaps [rsp], xmm0
00007ec68bfdc102  vmovaps [rsp+0x10], xmm2
00007ec68bfdc108  vmovaps [rsp+0x20], xmm3
00007ec68bfdc10e  vmovaps [rsp+0x30], xmm4
00007ec68bfdc114  vmovaps [rsp+0x40], xmm5
00007ec68bfdc11a  vmovaps [rsp+0x50], xmm6
00007ec68bfdc120  vmovaps [rsp+0x60], xmm7
00007ec68bfdc126  vmovaps [rsp+0x70], xmm8
00007ec68bfdc12c  vmovaps [rsp+0x80], xmm9
00007ec68bfdc135  vmovaps [rsp+0x90], xmm10
00007ec68bfdc13e  vmovaps [rsp+0xA0], xmm11
00007ec68bfdc147  vmovaps [rsp+0xB0], xmm12
00007ec68bfdc150  vmovaps [rsp+0xC0], xmm13
00007ec68bfdc159  vmovaps [rsp+0xD0], xmm14
00007ec68bfdc162  vmovaps [rsp+0xE0], xmm15
00007ec68bfdc16b  sub rsp, 0x30
00007ec68bfdc16f  movaps [rsp], xmm1
00007ec68bfdc173  movaps [rsp+0x10], xmm15
00007ec68bfdc179  movaps [rsp+0x20], xmm6
00007ec68bfdc17e  lea rdi, [rsp]
00007ec68bfdc182  mov esi, 0x00
00007ec68bfdc187  mov rax, 0x57D97DADF530
00007ec68bfdc191  call rax
00007ec68bfdc193  movaps xmm1, [rsp]
00007ec68bfdc197  add rsp, 0x30
00007ec68bfdc19b  vmovaps xmm0, [rsp]
00007ec68bfdc1a0  vmovaps xmm2, [rsp+0x10]
00007ec68bfdc1a6  vmovaps xmm3, [rsp+0x20]
00007ec68bfdc1ac  vmovaps xmm4, [rsp+0x30]
00007ec68bfdc1b2  vmovaps xmm5, [rsp+0x40]
00007ec68bfdc1b8  vmovaps xmm6, [rsp+0x50]
00007ec68bfdc1be  vmovaps xmm7, [rsp+0x60]
00007ec68bfdc1c4  vmovaps xmm8, [rsp+0x70]
00007ec68bfdc1ca  vmovaps xmm9, [rsp+0x80]
00007ec68bfdc1d3  vmovaps xmm10, [rsp+0x90]
00007ec68bfdc1dc  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdc1e5  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdc1ee  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdc1f7  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdc200  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdc209  add rsp, 0xF0
00007ec68bfdc210  pop r11
00007ec68bfdc212  pop r10
00007ec68bfdc214  pop r9
00007ec68bfdc216  pop r8
00007ec68bfdc218  pop rsi
00007ec68bfdc219  pop rdi
00007ec68bfdc21a  pop rdx
00007ec68bfdc21b  pop rcx
00007ec68bfdc21c  pop rax
00007ec68bfdc21d  add rsp, 0x08
00007ec68bfdc221  jmp 0x00007EC68BFD93A2
00007ec68bfdc226  sub rsp, 0x08
00007ec68bfdc22a  push rax
00007ec68bfdc22b  push rcx
00007ec68bfdc22c  push rdx
00007ec68bfdc22d  push rdi
00007ec68bfdc22e  push rsi
00007ec68bfdc22f  push r8
00007ec68bfdc231  push r9
00007ec68bfdc233  push r10
00007ec68bfdc235  push r11
00007ec68bfdc237  sub rsp, 0xF0
00007ec68bfdc23e  vmovaps [rsp], xmm0
00007ec68bfdc243  vmovaps [rsp+0x10], xmm1
00007ec68bfdc249  vmovaps [rsp+0x20], xmm2
00007ec68bfdc24f  vmovaps [rsp+0x30], xmm3
00007ec68bfdc255  vmovaps [rsp+0x40], xmm4
00007ec68bfdc25b  vmovaps [rsp+0x50], xmm5
00007ec68bfdc261  vmovaps [rsp+0x60], xmm6
00007ec68bfdc267  vmovaps [rsp+0x70], xmm7
00007ec68bfdc26d  vmovaps [rsp+0x80], xmm8
00007ec68bfdc276  vmovaps [rsp+0x90], xmm9
00007ec68bfdc27f  vmovaps [rsp+0xA0], xmm10
00007ec68bfdc288  vmovaps [rsp+0xB0], xmm11
00007ec68bfdc291  vmovaps [rsp+0xC0], xmm12
00007ec68bfdc29a  vmovaps [rsp+0xD0], xmm13
00007ec68bfdc2a3  vmovaps [rsp+0xE0], xmm14
00007ec68bfdc2ac  sub rsp, 0x30
00007ec68bfdc2b0  movaps [rsp], xmm15
00007ec68bfdc2b5  movaps [rsp+0x10], xmm5
00007ec68bfdc2ba  movaps [rsp+0x20], xmm3
00007ec68bfdc2bf  lea rdi, [rsp]
00007ec68bfdc2c3  mov esi, 0x00
00007ec68bfdc2c8  mov rax, 0x57D97DADF530
00007ec68bfdc2d2  call rax
00007ec68bfdc2d4  movaps xmm15, [rsp]
00007ec68bfdc2d9  add rsp, 0x30
00007ec68bfdc2dd  vmovaps xmm0, [rsp]
00007ec68bfdc2e2  vmovaps xmm1, [rsp+0x10]
00007ec68bfdc2e8  vmovaps xmm2, [rsp+0x20]
00007ec68bfdc2ee  vmovaps xmm3, [rsp+0x30]
00007ec68bfdc2f4  vmovaps xmm4, [rsp+0x40]
00007ec68bfdc2fa  vmovaps xmm5, [rsp+0x50]
00007ec68bfdc300  vmovaps xmm6, [rsp+0x60]
00007ec68bfdc306  vmovaps xmm7, [rsp+0x70]
00007ec68bfdc30c  vmovaps xmm8, [rsp+0x80]
00007ec68bfdc315  vmovaps xmm9, [rsp+0x90]
00007ec68bfdc31e  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdc327  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdc330  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdc339  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdc342  vmovaps xmm14, [rsp+0xE0]
00007ec68bfdc34b  add rsp, 0xF0
00007ec68bfdc352  pop r11
00007ec68bfdc354  pop r10
00007ec68bfdc356  pop r9
00007ec68bfdc358  pop r8
00007ec68bfdc35a  pop rsi
00007ec68bfdc35b  pop rdi
00007ec68bfdc35c  pop rdx
00007ec68bfdc35d  pop rcx
00007ec68bfdc35e  pop rax
00007ec68bfdc35f  add rsp, 0x08
00007ec68bfdc363  jmp 0x00007EC68BFD93BC
00007ec68bfdc368  sub rsp, 0x08
00007ec68bfdc36c  push rax
00007ec68bfdc36d  push rcx
00007ec68bfdc36e  push rdx
00007ec68bfdc36f  push rdi
00007ec68bfdc370  push rsi
00007ec68bfdc371  push r8
00007ec68bfdc373  push r9
00007ec68bfdc375  push r10
00007ec68bfdc377  push r11
00007ec68bfdc379  sub rsp, 0xF0
00007ec68bfdc380  vmovaps [rsp], xmm0
00007ec68bfdc385  vmovaps [rsp+0x10], xmm1
00007ec68bfdc38b  vmovaps [rsp+0x20], xmm2
00007ec68bfdc391  vmovaps [rsp+0x30], xmm3
00007ec68bfdc397  vmovaps [rsp+0x40], xmm4
00007ec68bfdc39d  vmovaps [rsp+0x50], xmm6
00007ec68bfdc3a3  vmovaps [rsp+0x60], xmm7
00007ec68bfdc3a9  vmovaps [rsp+0x70], xmm8
00007ec68bfdc3af  vmovaps [rsp+0x80], xmm9
00007ec68bfdc3b8  vmovaps [rsp+0x90], xmm10
00007ec68bfdc3c1  vmovaps [rsp+0xA0], xmm11
00007ec68bfdc3ca  vmovaps [rsp+0xB0], xmm12
00007ec68bfdc3d3  vmovaps [rsp+0xC0], xmm13
00007ec68bfdc3dc  vmovaps [rsp+0xD0], xmm14
00007ec68bfdc3e5  vmovaps [rsp+0xE0], xmm15
00007ec68bfdc3ee  sub rsp, 0x30
00007ec68bfdc3f2  movaps [rsp], xmm5
00007ec68bfdc3f6  movaps [rsp+0x10], xmm8
00007ec68bfdc3fc  movaps [rsp+0x20], xmm6
00007ec68bfdc401  lea rdi, [rsp]
00007ec68bfdc405  mov esi, 0x00
00007ec68bfdc40a  mov rax, 0x57D97DADF530
00007ec68bfdc414  call rax
00007ec68bfdc416  movaps xmm5, [rsp]
00007ec68bfdc41a  add rsp, 0x30
00007ec68bfdc41e  vmovaps xmm0, [rsp]
00007ec68bfdc423  vmovaps xmm1, [rsp+0x10]
00007ec68bfdc429  vmovaps xmm2, [rsp+0x20]
00007ec68bfdc42f  vmovaps xmm3, [rsp+0x30]
00007ec68bfdc435  vmovaps xmm4, [rsp+0x40]
00007ec68bfdc43b  vmovaps xmm6, [rsp+0x50]
00007ec68bfdc441  vmovaps xmm7, [rsp+0x60]
00007ec68bfdc447  vmovaps xmm8, [rsp+0x70]
00007ec68bfdc44d  vmovaps xmm9, [rsp+0x80]
00007ec68bfdc456  vmovaps xmm10, [rsp+0x90]
00007ec68bfdc45f  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdc468  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdc471  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdc47a  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdc483  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdc48c  add rsp, 0xF0
00007ec68bfdc493  pop r11
00007ec68bfdc495  pop r10
00007ec68bfdc497  pop r9
00007ec68bfdc499  pop r8
00007ec68bfdc49b  pop rsi
00007ec68bfdc49c  pop rdi
00007ec68bfdc49d  pop rdx
00007ec68bfdc49e  pop rcx
00007ec68bfdc49f  pop rax
00007ec68bfdc4a0  add rsp, 0x08
00007ec68bfdc4a4  jmp 0x00007EC68BFD93E0
00007ec68bfdc4a9  sub rsp, 0x08
00007ec68bfdc4ad  push rax
00007ec68bfdc4ae  push rcx
00007ec68bfdc4af  push rdx
00007ec68bfdc4b0  push rdi
00007ec68bfdc4b1  push rsi
00007ec68bfdc4b2  push r8
00007ec68bfdc4b4  push r9
00007ec68bfdc4b6  push r10
00007ec68bfdc4b8  push r11
00007ec68bfdc4ba  sub rsp, 0xF0
00007ec68bfdc4c1  vmovaps [rsp], xmm0
00007ec68bfdc4c6  vmovaps [rsp+0x10], xmm1
00007ec68bfdc4cc  vmovaps [rsp+0x20], xmm2
00007ec68bfdc4d2  vmovaps [rsp+0x30], xmm3
00007ec68bfdc4d8  vmovaps [rsp+0x40], xmm4
00007ec68bfdc4de  vmovaps [rsp+0x50], xmm5
00007ec68bfdc4e4  vmovaps [rsp+0x60], xmm7
00007ec68bfdc4ea  vmovaps [rsp+0x70], xmm8
00007ec68bfdc4f0  vmovaps [rsp+0x80], xmm9
00007ec68bfdc4f9  vmovaps [rsp+0x90], xmm10
00007ec68bfdc502  vmovaps [rsp+0xA0], xmm11
00007ec68bfdc50b  vmovaps [rsp+0xB0], xmm12
00007ec68bfdc514  vmovaps [rsp+0xC0], xmm13
00007ec68bfdc51d  vmovaps [rsp+0xD0], xmm14
00007ec68bfdc526  vmovaps [rsp+0xE0], xmm15
00007ec68bfdc52f  sub rsp, 0x30
00007ec68bfdc533  movaps [rsp], xmm6
00007ec68bfdc537  movaps [rsp+0x10], xmm10
00007ec68bfdc53d  movaps [rsp+0x20], xmm8
00007ec68bfdc543  lea rdi, [rsp]
00007ec68bfdc547  mov esi, 0x00
00007ec68bfdc54c  mov rax, 0x57D97DADF530
00007ec68bfdc556  call rax
00007ec68bfdc558  movaps xmm6, [rsp]
00007ec68bfdc55c  add rsp, 0x30
00007ec68bfdc560  vmovaps xmm0, [rsp]
00007ec68bfdc565  vmovaps xmm1, [rsp+0x10]
00007ec68bfdc56b  vmovaps xmm2, [rsp+0x20]
00007ec68bfdc571  vmovaps xmm3, [rsp+0x30]
00007ec68bfdc577  vmovaps xmm4, [rsp+0x40]
00007ec68bfdc57d  vmovaps xmm5, [rsp+0x50]
00007ec68bfdc583  vmovaps xmm7, [rsp+0x60]
00007ec68bfdc589  vmovaps xmm8, [rsp+0x70]
00007ec68bfdc58f  vmovaps xmm9, [rsp+0x80]
00007ec68bfdc598  vmovaps xmm10, [rsp+0x90]
00007ec68bfdc5a1  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdc5aa  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdc5b3  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdc5bc  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdc5c5  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdc5ce  add rsp, 0xF0
00007ec68bfdc5d5  pop r11
00007ec68bfdc5d7  pop r10
00007ec68bfdc5d9  pop r9
00007ec68bfdc5db  pop r8
00007ec68bfdc5dd  pop rsi
00007ec68bfdc5de  pop rdi
00007ec68bfdc5df  pop rdx
00007ec68bfdc5e0  pop rcx
00007ec68bfdc5e1  pop rax
00007ec68bfdc5e2  add rsp, 0x08
00007ec68bfdc5e6  jmp 0x00007EC68BFD9405
00007ec68bfdc5eb  sub rsp, 0x08
00007ec68bfdc5ef  push rax
00007ec68bfdc5f0  push rcx
00007ec68bfdc5f1  push rdx
00007ec68bfdc5f2  push rdi
00007ec68bfdc5f3  push rsi
00007ec68bfdc5f4  push r8
00007ec68bfdc5f6  push r9
00007ec68bfdc5f8  push r10
00007ec68bfdc5fa  push r11
00007ec68bfdc5fc  sub rsp, 0xF0
00007ec68bfdc603  vmovaps [rsp], xmm0
00007ec68bfdc608  vmovaps [rsp+0x10], xmm1
00007ec68bfdc60e  vmovaps [rsp+0x20], xmm2
00007ec68bfdc614  vmovaps [rsp+0x30], xmm3
00007ec68bfdc61a  vmovaps [rsp+0x40], xmm4
00007ec68bfdc620  vmovaps [rsp+0x50], xmm5
00007ec68bfdc626  vmovaps [rsp+0x60], xmm6
00007ec68bfdc62c  vmovaps [rsp+0x70], xmm7
00007ec68bfdc632  vmovaps [rsp+0x80], xmm8
00007ec68bfdc63b  vmovaps [rsp+0x90], xmm9
00007ec68bfdc644  vmovaps [rsp+0xA0], xmm11
00007ec68bfdc64d  vmovaps [rsp+0xB0], xmm12
00007ec68bfdc656  vmovaps [rsp+0xC0], xmm13
00007ec68bfdc65f  vmovaps [rsp+0xD0], xmm14
00007ec68bfdc668  vmovaps [rsp+0xE0], xmm15
00007ec68bfdc671  sub rsp, 0x30
00007ec68bfdc675  movaps [rsp], xmm10
00007ec68bfdc67a  movaps [rsp+0x10], xmm8
00007ec68bfdc680  movaps [rsp+0x20], xmm14
00007ec68bfdc686  lea rdi, [rsp]
00007ec68bfdc68a  mov esi, 0x00
00007ec68bfdc68f  mov rax, 0x57D97DADF530
00007ec68bfdc699  call rax
00007ec68bfdc69b  movaps xmm10, [rsp]
00007ec68bfdc6a0  add rsp, 0x30
00007ec68bfdc6a4  vmovaps xmm0, [rsp]
00007ec68bfdc6a9  vmovaps xmm1, [rsp+0x10]
00007ec68bfdc6af  vmovaps xmm2, [rsp+0x20]
00007ec68bfdc6b5  vmovaps xmm3, [rsp+0x30]
00007ec68bfdc6bb  vmovaps xmm4, [rsp+0x40]
00007ec68bfdc6c1  vmovaps xmm5, [rsp+0x50]
00007ec68bfdc6c7  vmovaps xmm6, [rsp+0x60]
00007ec68bfdc6cd  vmovaps xmm7, [rsp+0x70]
00007ec68bfdc6d3  vmovaps xmm8, [rsp+0x80]
00007ec68bfdc6dc  vmovaps xmm9, [rsp+0x90]
00007ec68bfdc6e5  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdc6ee  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdc6f7  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdc700  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdc709  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdc712  add rsp, 0xF0
00007ec68bfdc719  pop r11
00007ec68bfdc71b  pop r10
00007ec68bfdc71d  pop r9
00007ec68bfdc71f  pop r8
00007ec68bfdc721  pop rsi
00007ec68bfdc722  pop rdi
00007ec68bfdc723  pop rdx
00007ec68bfdc724  pop rcx
00007ec68bfdc725  pop rax
00007ec68bfdc726  add rsp, 0x08
00007ec68bfdc72a  jmp 0x00007EC68BFD9425
00007ec68bfdc72f  sub rsp, 0x08
00007ec68bfdc733  push rax
00007ec68bfdc734  push rcx
00007ec68bfdc735  push rdx
00007ec68bfdc736  push rdi
00007ec68bfdc737  push rsi
00007ec68bfdc738  push r8
00007ec68bfdc73a  push r9
00007ec68bfdc73c  push r10
00007ec68bfdc73e  push r11
00007ec68bfdc740  sub rsp, 0xF0
00007ec68bfdc747  vmovaps [rsp], xmm0
00007ec68bfdc74c  vmovaps [rsp+0x10], xmm1
00007ec68bfdc752  vmovaps [rsp+0x20], xmm2
00007ec68bfdc758  vmovaps [rsp+0x30], xmm3
00007ec68bfdc75e  vmovaps [rsp+0x40], xmm4
00007ec68bfdc764  vmovaps [rsp+0x50], xmm5
00007ec68bfdc76a  vmovaps [rsp+0x60], xmm6
00007ec68bfdc770  vmovaps [rsp+0x70], xmm7
00007ec68bfdc776  vmovaps [rsp+0x80], xmm8
00007ec68bfdc77f  vmovaps [rsp+0x90], xmm9
00007ec68bfdc788  vmovaps [rsp+0xA0], xmm10
00007ec68bfdc791  vmovaps [rsp+0xB0], xmm11
00007ec68bfdc79a  vmovaps [rsp+0xC0], xmm12
00007ec68bfdc7a3  vmovaps [rsp+0xD0], xmm13
00007ec68bfdc7ac  vmovaps [rsp+0xE0], xmm15
00007ec68bfdc7b5  sub rsp, 0x30
00007ec68bfdc7b9  movaps [rsp], xmm14
00007ec68bfdc7be  movaps [rsp+0x10], xmm8
00007ec68bfdc7c4  movaps [rsp+0x20], xmm4
00007ec68bfdc7c9  lea rdi, [rsp]
00007ec68bfdc7cd  mov esi, 0x00
00007ec68bfdc7d2  mov rax, 0x57D97DADF530
00007ec68bfdc7dc  call rax
00007ec68bfdc7de  movaps xmm14, [rsp]
00007ec68bfdc7e3  add rsp, 0x30
00007ec68bfdc7e7  vmovaps xmm0, [rsp]
00007ec68bfdc7ec  vmovaps xmm1, [rsp+0x10]
00007ec68bfdc7f2  vmovaps xmm2, [rsp+0x20]
00007ec68bfdc7f8  vmovaps xmm3, [rsp+0x30]
00007ec68bfdc7fe  vmovaps xmm4, [rsp+0x40]
00007ec68bfdc804  vmovaps xmm5, [rsp+0x50]
00007ec68bfdc80a  vmovaps xmm6, [rsp+0x60]
00007ec68bfdc810  vmovaps xmm7, [rsp+0x70]
00007ec68bfdc816  vmovaps xmm8, [rsp+0x80]
00007ec68bfdc81f  vmovaps xmm9, [rsp+0x90]
00007ec68bfdc828  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdc831  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdc83a  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdc843  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdc84c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdc855  add rsp, 0xF0
00007ec68bfdc85c  pop r11
00007ec68bfdc85e  pop r10
00007ec68bfdc860  pop r9
00007ec68bfdc862  pop r8
00007ec68bfdc864  pop rsi
00007ec68bfdc865  pop rdi
00007ec68bfdc866  pop rdx
00007ec68bfdc867  pop rcx
00007ec68bfdc868  pop rax
00007ec68bfdc869  add rsp, 0x08
00007ec68bfdc86d  jmp 0x00007EC68BFD9445
00007ec68bfdc872  sub rsp, 0x08
00007ec68bfdc876  push rax
00007ec68bfdc877  push rcx
00007ec68bfdc878  push rdx
00007ec68bfdc879  push rdi
00007ec68bfdc87a  push rsi
00007ec68bfdc87b  push r8
00007ec68bfdc87d  push r9
00007ec68bfdc87f  push r10
00007ec68bfdc881  push r11
00007ec68bfdc883  sub rsp, 0xF0
00007ec68bfdc88a  vmovaps [rsp], xmm0
00007ec68bfdc88f  vmovaps [rsp+0x10], xmm1
00007ec68bfdc895  vmovaps [rsp+0x20], xmm2
00007ec68bfdc89b  vmovaps [rsp+0x30], xmm3
00007ec68bfdc8a1  vmovaps [rsp+0x40], xmm5
00007ec68bfdc8a7  vmovaps [rsp+0x50], xmm6
00007ec68bfdc8ad  vmovaps [rsp+0x60], xmm7
00007ec68bfdc8b3  vmovaps [rsp+0x70], xmm8
00007ec68bfdc8b9  vmovaps [rsp+0x80], xmm9
00007ec68bfdc8c2  vmovaps [rsp+0x90], xmm10
00007ec68bfdc8cb  vmovaps [rsp+0xA0], xmm11
00007ec68bfdc8d4  vmovaps [rsp+0xB0], xmm12
00007ec68bfdc8dd  vmovaps [rsp+0xC0], xmm13
00007ec68bfdc8e6  vmovaps [rsp+0xD0], xmm14
00007ec68bfdc8ef  vmovaps [rsp+0xE0], xmm15
00007ec68bfdc8f8  sub rsp, 0x30
00007ec68bfdc8fc  movaps [rsp], xmm4
00007ec68bfdc900  movaps [rsp+0x10], xmm13
00007ec68bfdc906  movaps [rsp+0x20], xmm8
00007ec68bfdc90c  lea rdi, [rsp]
00007ec68bfdc910  mov esi, 0x00
00007ec68bfdc915  mov rax, 0x57D97DADF530
00007ec68bfdc91f  call rax
00007ec68bfdc921  movaps xmm4, [rsp]
00007ec68bfdc925  add rsp, 0x30
00007ec68bfdc929  vmovaps xmm0, [rsp]
00007ec68bfdc92e  vmovaps xmm1, [rsp+0x10]
00007ec68bfdc934  vmovaps xmm2, [rsp+0x20]
00007ec68bfdc93a  vmovaps xmm3, [rsp+0x30]
00007ec68bfdc940  vmovaps xmm5, [rsp+0x40]
00007ec68bfdc946  vmovaps xmm6, [rsp+0x50]
00007ec68bfdc94c  vmovaps xmm7, [rsp+0x60]
00007ec68bfdc952  vmovaps xmm8, [rsp+0x70]
00007ec68bfdc958  vmovaps xmm9, [rsp+0x80]
00007ec68bfdc961  vmovaps xmm10, [rsp+0x90]
00007ec68bfdc96a  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdc973  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdc97c  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdc985  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdc98e  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdc997  add rsp, 0xF0
00007ec68bfdc99e  pop r11
00007ec68bfdc9a0  pop r10
00007ec68bfdc9a2  pop r9
00007ec68bfdc9a4  pop r8
00007ec68bfdc9a6  pop rsi
00007ec68bfdc9a7  pop rdi
00007ec68bfdc9a8  pop rdx
00007ec68bfdc9a9  pop rcx
00007ec68bfdc9aa  pop rax
00007ec68bfdc9ab  add rsp, 0x08
00007ec68bfdc9af  jmp 0x00007EC68BFD946A
00007ec68bfdc9b4  sub rsp, 0x08
00007ec68bfdc9b8  push rax
00007ec68bfdc9b9  push rcx
00007ec68bfdc9ba  push rdx
00007ec68bfdc9bb  push rdi
00007ec68bfdc9bc  push rsi
00007ec68bfdc9bd  push r8
00007ec68bfdc9bf  push r9
00007ec68bfdc9c1  push r10
00007ec68bfdc9c3  push r11
00007ec68bfdc9c5  sub rsp, 0xF0
00007ec68bfdc9cc  vmovaps [rsp], xmm0
00007ec68bfdc9d1  vmovaps [rsp+0x10], xmm1
00007ec68bfdc9d7  vmovaps [rsp+0x20], xmm2
00007ec68bfdc9dd  vmovaps [rsp+0x30], xmm3
00007ec68bfdc9e3  vmovaps [rsp+0x40], xmm4
00007ec68bfdc9e9  vmovaps [rsp+0x50], xmm5
00007ec68bfdc9ef  vmovaps [rsp+0x60], xmm6
00007ec68bfdc9f5  vmovaps [rsp+0x70], xmm7
00007ec68bfdc9fb  vmovaps [rsp+0x80], xmm8
00007ec68bfdca04  vmovaps [rsp+0x90], xmm9
00007ec68bfdca0d  vmovaps [rsp+0xA0], xmm10
00007ec68bfdca16  vmovaps [rsp+0xB0], xmm11
00007ec68bfdca1f  vmovaps [rsp+0xC0], xmm12
00007ec68bfdca28  vmovaps [rsp+0xD0], xmm14
00007ec68bfdca31  vmovaps [rsp+0xE0], xmm15
00007ec68bfdca3a  sub rsp, 0x30
00007ec68bfdca3e  movaps [rsp], xmm13
00007ec68bfdca43  movaps [rsp+0x10], xmm15
00007ec68bfdca49  movaps [rsp+0x20], xmm9
00007ec68bfdca4f  lea rdi, [rsp]
00007ec68bfdca53  mov esi, 0x00
00007ec68bfdca58  mov rax, 0x57D97DADF530
00007ec68bfdca62  call rax
00007ec68bfdca64  movaps xmm13, [rsp]
00007ec68bfdca69  add rsp, 0x30
00007ec68bfdca6d  vmovaps xmm0, [rsp]
00007ec68bfdca72  vmovaps xmm1, [rsp+0x10]
00007ec68bfdca78  vmovaps xmm2, [rsp+0x20]
00007ec68bfdca7e  vmovaps xmm3, [rsp+0x30]
00007ec68bfdca84  vmovaps xmm4, [rsp+0x40]
00007ec68bfdca8a  vmovaps xmm5, [rsp+0x50]
00007ec68bfdca90  vmovaps xmm6, [rsp+0x60]
00007ec68bfdca96  vmovaps xmm7, [rsp+0x70]
00007ec68bfdca9c  vmovaps xmm8, [rsp+0x80]
00007ec68bfdcaa5  vmovaps xmm9, [rsp+0x90]
00007ec68bfdcaae  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdcab7  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdcac0  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdcac9  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdcad2  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdcadb  add rsp, 0xF0
00007ec68bfdcae2  pop r11
00007ec68bfdcae4  pop r10
00007ec68bfdcae6  pop r9
00007ec68bfdcae8  pop r8
00007ec68bfdcaea  pop rsi
00007ec68bfdcaeb  pop rdi
00007ec68bfdcaec  pop rdx
00007ec68bfdcaed  pop rcx
00007ec68bfdcaee  pop rax
00007ec68bfdcaef  add rsp, 0x08
00007ec68bfdcaf3  jmp 0x00007EC68BFD9485
00007ec68bfdcaf8  sub rsp, 0x08
00007ec68bfdcafc  push rax
00007ec68bfdcafd  push rcx
00007ec68bfdcafe  push rdx
00007ec68bfdcaff  push rdi
00007ec68bfdcb00  push rsi
00007ec68bfdcb01  push r8
00007ec68bfdcb03  push r9
00007ec68bfdcb05  push r10
00007ec68bfdcb07  push r11
00007ec68bfdcb09  sub rsp, 0xF0
00007ec68bfdcb10  vmovaps [rsp], xmm0
00007ec68bfdcb15  vmovaps [rsp+0x10], xmm1
00007ec68bfdcb1b  vmovaps [rsp+0x20], xmm2
00007ec68bfdcb21  vmovaps [rsp+0x30], xmm3
00007ec68bfdcb27  vmovaps [rsp+0x40], xmm4
00007ec68bfdcb2d  vmovaps [rsp+0x50], xmm5
00007ec68bfdcb33  vmovaps [rsp+0x60], xmm6
00007ec68bfdcb39  vmovaps [rsp+0x70], xmm7
00007ec68bfdcb3f  vmovaps [rsp+0x80], xmm8
00007ec68bfdcb48  vmovaps [rsp+0x90], xmm9
00007ec68bfdcb51  vmovaps [rsp+0xA0], xmm10
00007ec68bfdcb5a  vmovaps [rsp+0xB0], xmm11
00007ec68bfdcb63  vmovaps [rsp+0xC0], xmm12
00007ec68bfdcb6c  vmovaps [rsp+0xD0], xmm13
00007ec68bfdcb75  vmovaps [rsp+0xE0], xmm14
00007ec68bfdcb7e  sub rsp, 0x30
00007ec68bfdcb82  movaps [rsp], xmm15
00007ec68bfdcb87  movaps [rsp+0x10], xmm1
00007ec68bfdcb8c  movaps [rsp+0x20], xmm5
00007ec68bfdcb91  lea rdi, [rsp]
00007ec68bfdcb95  mov esi, 0x00
00007ec68bfdcb9a  mov rax, 0x57D97DADF530
00007ec68bfdcba4  call rax
00007ec68bfdcba6  movaps xmm15, [rsp]
00007ec68bfdcbab  add rsp, 0x30
00007ec68bfdcbaf  vmovaps xmm0, [rsp]
00007ec68bfdcbb4  vmovaps xmm1, [rsp+0x10]
00007ec68bfdcbba  vmovaps xmm2, [rsp+0x20]
00007ec68bfdcbc0  vmovaps xmm3, [rsp+0x30]
00007ec68bfdcbc6  vmovaps xmm4, [rsp+0x40]
00007ec68bfdcbcc  vmovaps xmm5, [rsp+0x50]
00007ec68bfdcbd2  vmovaps xmm6, [rsp+0x60]
00007ec68bfdcbd8  vmovaps xmm7, [rsp+0x70]
00007ec68bfdcbde  vmovaps xmm8, [rsp+0x80]
00007ec68bfdcbe7  vmovaps xmm9, [rsp+0x90]
00007ec68bfdcbf0  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdcbf9  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdcc02  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdcc0b  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdcc14  vmovaps xmm14, [rsp+0xE0]
00007ec68bfdcc1d  add rsp, 0xF0
00007ec68bfdcc24  pop r11
00007ec68bfdcc26  pop r10
00007ec68bfdcc28  pop r9
00007ec68bfdcc2a  pop r8
00007ec68bfdcc2c  pop rsi
00007ec68bfdcc2d  pop rdi
00007ec68bfdcc2e  pop rdx
00007ec68bfdcc2f  pop rcx
00007ec68bfdcc30  pop rax
00007ec68bfdcc31  add rsp, 0x08
00007ec68bfdcc35  jmp 0x00007EC68BFD94A0
00007ec68bfdcc3a  call 0x00007EC68BED64F0
00007ec68bfdcc3f  jmp 0x00007EC68BFD94FB
00007ec68bfdcc44  sub rsp, 0x08
00007ec68bfdcc48  push rax
00007ec68bfdcc49  push rcx
00007ec68bfdcc4a  push rdx
00007ec68bfdcc4b  push rdi
00007ec68bfdcc4c  push rsi
00007ec68bfdcc4d  push r8
00007ec68bfdcc4f  push r9
00007ec68bfdcc51  push r10
00007ec68bfdcc53  push r11
00007ec68bfdcc55  sub rsp, 0xF0
00007ec68bfdcc5c  vmovaps [rsp], xmm0
00007ec68bfdcc61  vmovaps [rsp+0x10], xmm1
00007ec68bfdcc67  vmovaps [rsp+0x20], xmm2
00007ec68bfdcc6d  vmovaps [rsp+0x30], xmm3
00007ec68bfdcc73  vmovaps [rsp+0x40], xmm4
00007ec68bfdcc79  vmovaps [rsp+0x50], xmm5
00007ec68bfdcc7f  vmovaps [rsp+0x60], xmm6
00007ec68bfdcc85  vmovaps [rsp+0x70], xmm7
00007ec68bfdcc8b  vmovaps [rsp+0x80], xmm8
00007ec68bfdcc94  vmovaps [rsp+0x90], xmm10
00007ec68bfdcc9d  vmovaps [rsp+0xA0], xmm11
00007ec68bfdcca6  vmovaps [rsp+0xB0], xmm12
00007ec68bfdccaf  vmovaps [rsp+0xC0], xmm13
00007ec68bfdccb8  vmovaps [rsp+0xD0], xmm14
00007ec68bfdccc1  vmovaps [rsp+0xE0], xmm15
00007ec68bfdccca  sub rsp, 0x30
00007ec68bfdccce  movaps [rsp], xmm9
00007ec68bfdccd3  movaps [rsp+0x10], xmm8
00007ec68bfdccd9  movaps [rsp+0x20], xmm11
00007ec68bfdccdf  lea rdi, [rsp]
00007ec68bfdcce3  mov esi, 0x00
00007ec68bfdcce8  mov rax, 0x57D97DADF530
00007ec68bfdccf2  call rax
00007ec68bfdccf4  movaps xmm9, [rsp]
00007ec68bfdccf9  add rsp, 0x30
00007ec68bfdccfd  vmovaps xmm0, [rsp]
00007ec68bfdcd02  vmovaps xmm1, [rsp+0x10]
00007ec68bfdcd08  vmovaps xmm2, [rsp+0x20]
00007ec68bfdcd0e  vmovaps xmm3, [rsp+0x30]
00007ec68bfdcd14  vmovaps xmm4, [rsp+0x40]
00007ec68bfdcd1a  vmovaps xmm5, [rsp+0x50]
00007ec68bfdcd20  vmovaps xmm6, [rsp+0x60]
00007ec68bfdcd26  vmovaps xmm7, [rsp+0x70]
00007ec68bfdcd2c  vmovaps xmm8, [rsp+0x80]
00007ec68bfdcd35  vmovaps xmm10, [rsp+0x90]
00007ec68bfdcd3e  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdcd47  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdcd50  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdcd59  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdcd62  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdcd6b  add rsp, 0xF0
00007ec68bfdcd72  pop r11
00007ec68bfdcd74  pop r10
00007ec68bfdcd76  pop r9
00007ec68bfdcd78  pop r8
00007ec68bfdcd7a  pop rsi
00007ec68bfdcd7b  pop rdi
00007ec68bfdcd7c  pop rdx
00007ec68bfdcd7d  pop rcx
00007ec68bfdcd7e  pop rax
00007ec68bfdcd7f  add rsp, 0x08
00007ec68bfdcd83  jmp 0x00007EC68BFD9532
00007ec68bfdcd88  sub rsp, 0x08
00007ec68bfdcd8c  push rax
00007ec68bfdcd8d  push rcx
00007ec68bfdcd8e  push rdx
00007ec68bfdcd8f  push rdi
00007ec68bfdcd90  push rsi
00007ec68bfdcd91  push r8
00007ec68bfdcd93  push r9
00007ec68bfdcd95  push r10
00007ec68bfdcd97  push r11
00007ec68bfdcd99  sub rsp, 0xF0
00007ec68bfdcda0  vmovaps [rsp], xmm0
00007ec68bfdcda5  vmovaps [rsp+0x10], xmm1
00007ec68bfdcdab  vmovaps [rsp+0x20], xmm2
00007ec68bfdcdb1  vmovaps [rsp+0x30], xmm3
00007ec68bfdcdb7  vmovaps [rsp+0x40], xmm4
00007ec68bfdcdbd  vmovaps [rsp+0x50], xmm5
00007ec68bfdcdc3  vmovaps [rsp+0x60], xmm6
00007ec68bfdcdc9  vmovaps [rsp+0x70], xmm7
00007ec68bfdcdcf  vmovaps [rsp+0x80], xmm8
00007ec68bfdcdd8  vmovaps [rsp+0x90], xmm9
00007ec68bfdcde1  vmovaps [rsp+0xA0], xmm10
00007ec68bfdcdea  vmovaps [rsp+0xB0], xmm12
00007ec68bfdcdf3  vmovaps [rsp+0xC0], xmm13
00007ec68bfdcdfc  vmovaps [rsp+0xD0], xmm14
00007ec68bfdce05  vmovaps [rsp+0xE0], xmm15
00007ec68bfdce0e  sub rsp, 0x30
00007ec68bfdce12  movaps [rsp], xmm11
00007ec68bfdce17  movaps [rsp+0x10], xmm10
00007ec68bfdce1d  movaps [rsp+0x20], xmm6
00007ec68bfdce22  lea rdi, [rsp]
00007ec68bfdce26  mov esi, 0x00
00007ec68bfdce2b  mov rax, 0x57D97DADF530
00007ec68bfdce35  call rax
00007ec68bfdce37  movaps xmm11, [rsp]
00007ec68bfdce3c  add rsp, 0x30
00007ec68bfdce40  vmovaps xmm0, [rsp]
00007ec68bfdce45  vmovaps xmm1, [rsp+0x10]
00007ec68bfdce4b  vmovaps xmm2, [rsp+0x20]
00007ec68bfdce51  vmovaps xmm3, [rsp+0x30]
00007ec68bfdce57  vmovaps xmm4, [rsp+0x40]
00007ec68bfdce5d  vmovaps xmm5, [rsp+0x50]
00007ec68bfdce63  vmovaps xmm6, [rsp+0x60]
00007ec68bfdce69  vmovaps xmm7, [rsp+0x70]
00007ec68bfdce6f  vmovaps xmm8, [rsp+0x80]
00007ec68bfdce78  vmovaps xmm9, [rsp+0x90]
00007ec68bfdce81  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdce8a  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdce93  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdce9c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdcea5  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdceae  add rsp, 0xF0
00007ec68bfdceb5  pop r11
00007ec68bfdceb7  pop r10
00007ec68bfdceb9  pop r9
00007ec68bfdcebb  pop r8
00007ec68bfdcebd  pop rsi
00007ec68bfdcebe  pop rdi
00007ec68bfdcebf  pop rdx
00007ec68bfdcec0  pop rcx
00007ec68bfdcec1  pop rax
00007ec68bfdcec2  add rsp, 0x08
00007ec68bfdcec6  jmp 0x00007EC68BFD954D
00007ec68bfdcecb  sub rsp, 0x08
00007ec68bfdcecf  push rax
00007ec68bfdced0  push rcx
00007ec68bfdced1  push rdx
00007ec68bfdced2  push rdi
00007ec68bfdced3  push rsi
00007ec68bfdced4  push r8
00007ec68bfdced6  push r9
00007ec68bfdced8  push r10
00007ec68bfdceda  push r11
00007ec68bfdcedc  sub rsp, 0xF0
00007ec68bfdcee3  vmovaps [rsp], xmm0
00007ec68bfdcee8  vmovaps [rsp+0x10], xmm1
00007ec68bfdceee  vmovaps [rsp+0x20], xmm2
00007ec68bfdcef4  vmovaps [rsp+0x30], xmm3
00007ec68bfdcefa  vmovaps [rsp+0x40], xmm4
00007ec68bfdcf00  vmovaps [rsp+0x50], xmm5
00007ec68bfdcf06  vmovaps [rsp+0x60], xmm6
00007ec68bfdcf0c  vmovaps [rsp+0x70], xmm7
00007ec68bfdcf12  vmovaps [rsp+0x80], xmm8
00007ec68bfdcf1b  vmovaps [rsp+0x90], xmm9
00007ec68bfdcf24  vmovaps [rsp+0xA0], xmm11
00007ec68bfdcf2d  vmovaps [rsp+0xB0], xmm12
00007ec68bfdcf36  vmovaps [rsp+0xC0], xmm13
00007ec68bfdcf3f  vmovaps [rsp+0xD0], xmm14
00007ec68bfdcf48  vmovaps [rsp+0xE0], xmm15
00007ec68bfdcf51  sub rsp, 0x30
00007ec68bfdcf55  movaps [rsp], xmm10
00007ec68bfdcf5a  movaps [rsp+0x10], xmm14
00007ec68bfdcf60  movaps [rsp+0x20], xmm4
00007ec68bfdcf65  lea rdi, [rsp]
00007ec68bfdcf69  mov esi, 0x00
00007ec68bfdcf6e  mov rax, 0x57D97DADF530
00007ec68bfdcf78  call rax
00007ec68bfdcf7a  movaps xmm10, [rsp]
00007ec68bfdcf7f  add rsp, 0x30
00007ec68bfdcf83  vmovaps xmm0, [rsp]
00007ec68bfdcf88  vmovaps xmm1, [rsp+0x10]
00007ec68bfdcf8e  vmovaps xmm2, [rsp+0x20]
00007ec68bfdcf94  vmovaps xmm3, [rsp+0x30]
00007ec68bfdcf9a  vmovaps xmm4, [rsp+0x40]
00007ec68bfdcfa0  vmovaps xmm5, [rsp+0x50]
00007ec68bfdcfa6  vmovaps xmm6, [rsp+0x60]
00007ec68bfdcfac  vmovaps xmm7, [rsp+0x70]
00007ec68bfdcfb2  vmovaps xmm8, [rsp+0x80]
00007ec68bfdcfbb  vmovaps xmm9, [rsp+0x90]
00007ec68bfdcfc4  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdcfcd  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdcfd6  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdcfdf  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdcfe8  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdcff1  add rsp, 0xF0
00007ec68bfdcff8  pop r11
00007ec68bfdcffa  pop r10
00007ec68bfdcffc  pop r9
00007ec68bfdcffe  pop r8
00007ec68bfdd000  pop rsi
00007ec68bfdd001  pop rdi
00007ec68bfdd002  pop rdx
00007ec68bfdd003  pop rcx
00007ec68bfdd004  pop rax
00007ec68bfdd005  add rsp, 0x08
00007ec68bfdd009  jmp 0x00007EC68BFD9568
00007ec68bfdd00e  sub rsp, 0x08
00007ec68bfdd012  push rax
00007ec68bfdd013  push rcx
00007ec68bfdd014  push rdx
00007ec68bfdd015  push rdi
00007ec68bfdd016  push rsi
00007ec68bfdd017  push r8
00007ec68bfdd019  push r9
00007ec68bfdd01b  push r10
00007ec68bfdd01d  push r11
00007ec68bfdd01f  sub rsp, 0xF0
00007ec68bfdd026  vmovaps [rsp], xmm0
00007ec68bfdd02b  vmovaps [rsp+0x10], xmm1
00007ec68bfdd031  vmovaps [rsp+0x20], xmm2
00007ec68bfdd037  vmovaps [rsp+0x30], xmm3
00007ec68bfdd03d  vmovaps [rsp+0x40], xmm4
00007ec68bfdd043  vmovaps [rsp+0x50], xmm5
00007ec68bfdd049  vmovaps [rsp+0x60], xmm6
00007ec68bfdd04f  vmovaps [rsp+0x70], xmm7
00007ec68bfdd055  vmovaps [rsp+0x80], xmm9
00007ec68bfdd05e  vmovaps [rsp+0x90], xmm10
00007ec68bfdd067  vmovaps [rsp+0xA0], xmm11
00007ec68bfdd070  vmovaps [rsp+0xB0], xmm12
00007ec68bfdd079  vmovaps [rsp+0xC0], xmm13
00007ec68bfdd082  vmovaps [rsp+0xD0], xmm14
00007ec68bfdd08b  vmovaps [rsp+0xE0], xmm15
00007ec68bfdd094  sub rsp, 0x30
00007ec68bfdd098  movaps [rsp], xmm8
00007ec68bfdd09d  movaps [rsp+0x10], xmm1
00007ec68bfdd0a2  movaps [rsp+0x20], xmm14
00007ec68bfdd0a8  lea rdi, [rsp]
00007ec68bfdd0ac  mov esi, 0x00
00007ec68bfdd0b1  mov rax, 0x57D97DADF530
00007ec68bfdd0bb  call rax
00007ec68bfdd0bd  movaps xmm8, [rsp]
00007ec68bfdd0c2  add rsp, 0x30
00007ec68bfdd0c6  vmovaps xmm0, [rsp]
00007ec68bfdd0cb  vmovaps xmm1, [rsp+0x10]
00007ec68bfdd0d1  vmovaps xmm2, [rsp+0x20]
00007ec68bfdd0d7  vmovaps xmm3, [rsp+0x30]
00007ec68bfdd0dd  vmovaps xmm4, [rsp+0x40]
00007ec68bfdd0e3  vmovaps xmm5, [rsp+0x50]
00007ec68bfdd0e9  vmovaps xmm6, [rsp+0x60]
00007ec68bfdd0ef  vmovaps xmm7, [rsp+0x70]
00007ec68bfdd0f5  vmovaps xmm9, [rsp+0x80]
00007ec68bfdd0fe  vmovaps xmm10, [rsp+0x90]
00007ec68bfdd107  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdd110  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdd119  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdd122  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdd12b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdd134  add rsp, 0xF0
00007ec68bfdd13b  pop r11
00007ec68bfdd13d  pop r10
00007ec68bfdd13f  pop r9
00007ec68bfdd141  pop r8
00007ec68bfdd143  pop rsi
00007ec68bfdd144  pop rdi
00007ec68bfdd145  pop rdx
00007ec68bfdd146  pop rcx
00007ec68bfdd147  pop rax
00007ec68bfdd148  add rsp, 0x08
00007ec68bfdd14c  jmp 0x00007EC68BFD958E
00007ec68bfdd151  sub rsp, 0x08
00007ec68bfdd155  push rax
00007ec68bfdd156  push rcx
00007ec68bfdd157  push rdx
00007ec68bfdd158  push rdi
00007ec68bfdd159  push rsi
00007ec68bfdd15a  push r8
00007ec68bfdd15c  push r9
00007ec68bfdd15e  push r10
00007ec68bfdd160  push r11
00007ec68bfdd162  sub rsp, 0xF0
00007ec68bfdd169  vmovaps [rsp], xmm0
00007ec68bfdd16e  vmovaps [rsp+0x10], xmm1
00007ec68bfdd174  vmovaps [rsp+0x20], xmm2
00007ec68bfdd17a  vmovaps [rsp+0x30], xmm3
00007ec68bfdd180  vmovaps [rsp+0x40], xmm4
00007ec68bfdd186  vmovaps [rsp+0x50], xmm5
00007ec68bfdd18c  vmovaps [rsp+0x60], xmm7
00007ec68bfdd192  vmovaps [rsp+0x70], xmm8
00007ec68bfdd198  vmovaps [rsp+0x80], xmm9
00007ec68bfdd1a1  vmovaps [rsp+0x90], xmm10
00007ec68bfdd1aa  vmovaps [rsp+0xA0], xmm11
00007ec68bfdd1b3  vmovaps [rsp+0xB0], xmm12
00007ec68bfdd1bc  vmovaps [rsp+0xC0], xmm13
00007ec68bfdd1c5  vmovaps [rsp+0xD0], xmm14
00007ec68bfdd1ce  vmovaps [rsp+0xE0], xmm15
00007ec68bfdd1d7  sub rsp, 0x30
00007ec68bfdd1db  movaps [rsp], xmm6
00007ec68bfdd1df  movaps [rsp+0x10], xmm1
00007ec68bfdd1e4  movaps [rsp+0x20], xmm14
00007ec68bfdd1ea  lea rdi, [rsp]
00007ec68bfdd1ee  mov esi, 0x00
00007ec68bfdd1f3  mov rax, 0x57D97DADF530
00007ec68bfdd1fd  call rax
00007ec68bfdd1ff  movaps xmm6, [rsp]
00007ec68bfdd203  add rsp, 0x30
00007ec68bfdd207  vmovaps xmm0, [rsp]
00007ec68bfdd20c  vmovaps xmm1, [rsp+0x10]
00007ec68bfdd212  vmovaps xmm2, [rsp+0x20]
00007ec68bfdd218  vmovaps xmm3, [rsp+0x30]
00007ec68bfdd21e  vmovaps xmm4, [rsp+0x40]
00007ec68bfdd224  vmovaps xmm5, [rsp+0x50]
00007ec68bfdd22a  vmovaps xmm7, [rsp+0x60]
00007ec68bfdd230  vmovaps xmm8, [rsp+0x70]
00007ec68bfdd236  vmovaps xmm9, [rsp+0x80]
00007ec68bfdd23f  vmovaps xmm10, [rsp+0x90]
00007ec68bfdd248  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdd251  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdd25a  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdd263  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdd26c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdd275  add rsp, 0xF0
00007ec68bfdd27c  pop r11
00007ec68bfdd27e  pop r10
00007ec68bfdd280  pop r9
00007ec68bfdd282  pop r8
00007ec68bfdd284  pop rsi
00007ec68bfdd285  pop rdi
00007ec68bfdd286  pop rdx
00007ec68bfdd287  pop rcx
00007ec68bfdd288  pop rax
00007ec68bfdd289  add rsp, 0x08
00007ec68bfdd28d  jmp 0x00007EC68BFD95BA
00007ec68bfdd292  sub rsp, 0x08
00007ec68bfdd296  push rax
00007ec68bfdd297  push rcx
00007ec68bfdd298  push rdx
00007ec68bfdd299  push rdi
00007ec68bfdd29a  push rsi
00007ec68bfdd29b  push r8
00007ec68bfdd29d  push r9
00007ec68bfdd29f  push r10
00007ec68bfdd2a1  push r11
00007ec68bfdd2a3  sub rsp, 0xF0
00007ec68bfdd2aa  vmovaps [rsp], xmm0
00007ec68bfdd2af  vmovaps [rsp+0x10], xmm1
00007ec68bfdd2b5  vmovaps [rsp+0x20], xmm2
00007ec68bfdd2bb  vmovaps [rsp+0x30], xmm3
00007ec68bfdd2c1  vmovaps [rsp+0x40], xmm4
00007ec68bfdd2c7  vmovaps [rsp+0x50], xmm5
00007ec68bfdd2cd  vmovaps [rsp+0x60], xmm6
00007ec68bfdd2d3  vmovaps [rsp+0x70], xmm7
00007ec68bfdd2d9  vmovaps [rsp+0x80], xmm8
00007ec68bfdd2e2  vmovaps [rsp+0x90], xmm9
00007ec68bfdd2eb  vmovaps [rsp+0xA0], xmm10
00007ec68bfdd2f4  vmovaps [rsp+0xB0], xmm11
00007ec68bfdd2fd  vmovaps [rsp+0xC0], xmm12
00007ec68bfdd306  vmovaps [rsp+0xD0], xmm13
00007ec68bfdd30f  vmovaps [rsp+0xE0], xmm15
00007ec68bfdd318  sub rsp, 0x30
00007ec68bfdd31c  movaps [rsp], xmm14
00007ec68bfdd321  movaps [rsp+0x10], xmm12
00007ec68bfdd327  movaps [rsp+0x20], xmm1
00007ec68bfdd32c  lea rdi, [rsp]
00007ec68bfdd330  mov esi, 0x00
00007ec68bfdd335  mov rax, 0x57D97DADF530
00007ec68bfdd33f  call rax
00007ec68bfdd341  movaps xmm14, [rsp]
00007ec68bfdd346  add rsp, 0x30
00007ec68bfdd34a  vmovaps xmm0, [rsp]
00007ec68bfdd34f  vmovaps xmm1, [rsp+0x10]
00007ec68bfdd355  vmovaps xmm2, [rsp+0x20]
00007ec68bfdd35b  vmovaps xmm3, [rsp+0x30]
00007ec68bfdd361  vmovaps xmm4, [rsp+0x40]
00007ec68bfdd367  vmovaps xmm5, [rsp+0x50]
00007ec68bfdd36d  vmovaps xmm6, [rsp+0x60]
00007ec68bfdd373  vmovaps xmm7, [rsp+0x70]
00007ec68bfdd379  vmovaps xmm8, [rsp+0x80]
00007ec68bfdd382  vmovaps xmm9, [rsp+0x90]
00007ec68bfdd38b  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdd394  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdd39d  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdd3a6  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdd3af  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdd3b8  add rsp, 0xF0
00007ec68bfdd3bf  pop r11
00007ec68bfdd3c1  pop r10
00007ec68bfdd3c3  pop r9
00007ec68bfdd3c5  pop r8
00007ec68bfdd3c7  pop rsi
00007ec68bfdd3c8  pop rdi
00007ec68bfdd3c9  pop rdx
00007ec68bfdd3ca  pop rcx
00007ec68bfdd3cb  pop rax
00007ec68bfdd3cc  add rsp, 0x08
00007ec68bfdd3d0  jmp 0x00007EC68BFD95E0
00007ec68bfdd3d5  sub rsp, 0x08
00007ec68bfdd3d9  push rax
00007ec68bfdd3da  push rcx
00007ec68bfdd3db  push rdx
00007ec68bfdd3dc  push rdi
00007ec68bfdd3dd  push rsi
00007ec68bfdd3de  push r8
00007ec68bfdd3e0  push r9
00007ec68bfdd3e2  push r10
00007ec68bfdd3e4  push r11
00007ec68bfdd3e6  sub rsp, 0xF0
00007ec68bfdd3ed  vmovaps [rsp], xmm0
00007ec68bfdd3f2  vmovaps [rsp+0x10], xmm2
00007ec68bfdd3f8  vmovaps [rsp+0x20], xmm3
00007ec68bfdd3fe  vmovaps [rsp+0x30], xmm4
00007ec68bfdd404  vmovaps [rsp+0x40], xmm5
00007ec68bfdd40a  vmovaps [rsp+0x50], xmm6
00007ec68bfdd410  vmovaps [rsp+0x60], xmm7
00007ec68bfdd416  vmovaps [rsp+0x70], xmm8
00007ec68bfdd41c  vmovaps [rsp+0x80], xmm9
00007ec68bfdd425  vmovaps [rsp+0x90], xmm10
00007ec68bfdd42e  vmovaps [rsp+0xA0], xmm11
00007ec68bfdd437  vmovaps [rsp+0xB0], xmm12
00007ec68bfdd440  vmovaps [rsp+0xC0], xmm13
00007ec68bfdd449  vmovaps [rsp+0xD0], xmm14
00007ec68bfdd452  vmovaps [rsp+0xE0], xmm15
00007ec68bfdd45b  sub rsp, 0x30
00007ec68bfdd45f  movaps [rsp], xmm1
00007ec68bfdd463  movaps [rsp+0x10], xmm13
00007ec68bfdd469  movaps [rsp+0x20], xmm9
00007ec68bfdd46f  lea rdi, [rsp]
00007ec68bfdd473  mov esi, 0x00
00007ec68bfdd478  mov rax, 0x57D97DADF530
00007ec68bfdd482  call rax
00007ec68bfdd484  movaps xmm1, [rsp]
00007ec68bfdd488  add rsp, 0x30
00007ec68bfdd48c  vmovaps xmm0, [rsp]
00007ec68bfdd491  vmovaps xmm2, [rsp+0x10]
00007ec68bfdd497  vmovaps xmm3, [rsp+0x20]
00007ec68bfdd49d  vmovaps xmm4, [rsp+0x30]
00007ec68bfdd4a3  vmovaps xmm5, [rsp+0x40]
00007ec68bfdd4a9  vmovaps xmm6, [rsp+0x50]
00007ec68bfdd4af  vmovaps xmm7, [rsp+0x60]
00007ec68bfdd4b5  vmovaps xmm8, [rsp+0x70]
00007ec68bfdd4bb  vmovaps xmm9, [rsp+0x80]
00007ec68bfdd4c4  vmovaps xmm10, [rsp+0x90]
00007ec68bfdd4cd  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdd4d6  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdd4df  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdd4e8  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdd4f1  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdd4fa  add rsp, 0xF0
00007ec68bfdd501  pop r11
00007ec68bfdd503  pop r10
00007ec68bfdd505  pop r9
00007ec68bfdd507  pop r8
00007ec68bfdd509  pop rsi
00007ec68bfdd50a  pop rdi
00007ec68bfdd50b  pop rdx
00007ec68bfdd50c  pop rcx
00007ec68bfdd50d  pop rax
00007ec68bfdd50e  add rsp, 0x08
00007ec68bfdd512  jmp 0x00007EC68BFD95FA
00007ec68bfdd517  sub rsp, 0x08
00007ec68bfdd51b  push rax
00007ec68bfdd51c  push rcx
00007ec68bfdd51d  push rdx
00007ec68bfdd51e  push rdi
00007ec68bfdd51f  push rsi
00007ec68bfdd520  push r8
00007ec68bfdd522  push r9
00007ec68bfdd524  push r10
00007ec68bfdd526  push r11
00007ec68bfdd528  sub rsp, 0xF0
00007ec68bfdd52f  vmovaps [rsp], xmm0
00007ec68bfdd534  vmovaps [rsp+0x10], xmm1
00007ec68bfdd53a  vmovaps [rsp+0x20], xmm2
00007ec68bfdd540  vmovaps [rsp+0x30], xmm3
00007ec68bfdd546  vmovaps [rsp+0x40], xmm4
00007ec68bfdd54c  vmovaps [rsp+0x50], xmm5
00007ec68bfdd552  vmovaps [rsp+0x60], xmm6
00007ec68bfdd558  vmovaps [rsp+0x70], xmm7
00007ec68bfdd55e  vmovaps [rsp+0x80], xmm8
00007ec68bfdd567  vmovaps [rsp+0x90], xmm9
00007ec68bfdd570  vmovaps [rsp+0xA0], xmm10
00007ec68bfdd579  vmovaps [rsp+0xB0], xmm11
00007ec68bfdd582  vmovaps [rsp+0xC0], xmm13
00007ec68bfdd58b  vmovaps [rsp+0xD0], xmm14
00007ec68bfdd594  vmovaps [rsp+0xE0], xmm15
00007ec68bfdd59d  sub rsp, 0x30
00007ec68bfdd5a1  movaps [rsp], xmm12
00007ec68bfdd5a6  movaps [rsp+0x10], xmm7
00007ec68bfdd5ab  movaps [rsp+0x20], xmm13
00007ec68bfdd5b1  lea rdi, [rsp]
00007ec68bfdd5b5  mov esi, 0x00
00007ec68bfdd5ba  mov rax, 0x57D97DADF530
00007ec68bfdd5c4  call rax
00007ec68bfdd5c6  movaps xmm12, [rsp]
00007ec68bfdd5cb  add rsp, 0x30
00007ec68bfdd5cf  vmovaps xmm0, [rsp]
00007ec68bfdd5d4  vmovaps xmm1, [rsp+0x10]
00007ec68bfdd5da  vmovaps xmm2, [rsp+0x20]
00007ec68bfdd5e0  vmovaps xmm3, [rsp+0x30]
00007ec68bfdd5e6  vmovaps xmm4, [rsp+0x40]
00007ec68bfdd5ec  vmovaps xmm5, [rsp+0x50]
00007ec68bfdd5f2  vmovaps xmm6, [rsp+0x60]
00007ec68bfdd5f8  vmovaps xmm7, [rsp+0x70]
00007ec68bfdd5fe  vmovaps xmm8, [rsp+0x80]
00007ec68bfdd607  vmovaps xmm9, [rsp+0x90]
00007ec68bfdd610  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdd619  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdd622  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdd62b  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdd634  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdd63d  add rsp, 0xF0
00007ec68bfdd644  pop r11
00007ec68bfdd646  pop r10
00007ec68bfdd648  pop r9
00007ec68bfdd64a  pop r8
00007ec68bfdd64c  pop rsi
00007ec68bfdd64d  pop rdi
00007ec68bfdd64e  pop rdx
00007ec68bfdd64f  pop rcx
00007ec68bfdd650  pop rax
00007ec68bfdd651  add rsp, 0x08
00007ec68bfdd655  jmp 0x00007EC68BFD9621
00007ec68bfdd65a  sub rsp, 0x08
00007ec68bfdd65e  push rax
00007ec68bfdd65f  push rcx
00007ec68bfdd660  push rdx
00007ec68bfdd661  push rdi
00007ec68bfdd662  push rsi
00007ec68bfdd663  push r8
00007ec68bfdd665  push r9
00007ec68bfdd667  push r10
00007ec68bfdd669  push r11
00007ec68bfdd66b  sub rsp, 0xF0
00007ec68bfdd672  vmovaps [rsp], xmm0
00007ec68bfdd677  vmovaps [rsp+0x10], xmm1
00007ec68bfdd67d  vmovaps [rsp+0x20], xmm2
00007ec68bfdd683  vmovaps [rsp+0x30], xmm3
00007ec68bfdd689  vmovaps [rsp+0x40], xmm4
00007ec68bfdd68f  vmovaps [rsp+0x50], xmm5
00007ec68bfdd695  vmovaps [rsp+0x60], xmm6
00007ec68bfdd69b  vmovaps [rsp+0x70], xmm7
00007ec68bfdd6a1  vmovaps [rsp+0x80], xmm8
00007ec68bfdd6aa  vmovaps [rsp+0x90], xmm9
00007ec68bfdd6b3  vmovaps [rsp+0xA0], xmm10
00007ec68bfdd6bc  vmovaps [rsp+0xB0], xmm11
00007ec68bfdd6c5  vmovaps [rsp+0xC0], xmm12
00007ec68bfdd6ce  vmovaps [rsp+0xD0], xmm14
00007ec68bfdd6d7  vmovaps [rsp+0xE0], xmm15
00007ec68bfdd6e0  sub rsp, 0x30
00007ec68bfdd6e4  movaps [rsp], xmm13
00007ec68bfdd6e9  movaps [rsp+0x10], xmm15
00007ec68bfdd6ef  movaps [rsp+0x20], xmm8
00007ec68bfdd6f5  lea rdi, [rsp]
00007ec68bfdd6f9  mov esi, 0x00
00007ec68bfdd6fe  mov rax, 0x57D97DADF530
00007ec68bfdd708  call rax
00007ec68bfdd70a  movaps xmm13, [rsp]
00007ec68bfdd70f  add rsp, 0x30
00007ec68bfdd713  vmovaps xmm0, [rsp]
00007ec68bfdd718  vmovaps xmm1, [rsp+0x10]
00007ec68bfdd71e  vmovaps xmm2, [rsp+0x20]
00007ec68bfdd724  vmovaps xmm3, [rsp+0x30]
00007ec68bfdd72a  vmovaps xmm4, [rsp+0x40]
00007ec68bfdd730  vmovaps xmm5, [rsp+0x50]
00007ec68bfdd736  vmovaps xmm6, [rsp+0x60]
00007ec68bfdd73c  vmovaps xmm7, [rsp+0x70]
00007ec68bfdd742  vmovaps xmm8, [rsp+0x80]
00007ec68bfdd74b  vmovaps xmm9, [rsp+0x90]
00007ec68bfdd754  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdd75d  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdd766  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdd76f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdd778  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdd781  add rsp, 0xF0
00007ec68bfdd788  pop r11
00007ec68bfdd78a  pop r10
00007ec68bfdd78c  pop r9
00007ec68bfdd78e  pop r8
00007ec68bfdd790  pop rsi
00007ec68bfdd791  pop rdi
00007ec68bfdd792  pop rdx
00007ec68bfdd793  pop rcx
00007ec68bfdd794  pop rax
00007ec68bfdd795  add rsp, 0x08
00007ec68bfdd799  jmp 0x00007EC68BFD963C
00007ec68bfdd79e  sub rsp, 0x08
00007ec68bfdd7a2  push rax
00007ec68bfdd7a3  push rcx
00007ec68bfdd7a4  push rdx
00007ec68bfdd7a5  push rdi
00007ec68bfdd7a6  push rsi
00007ec68bfdd7a7  push r8
00007ec68bfdd7a9  push r9
00007ec68bfdd7ab  push r10
00007ec68bfdd7ad  push r11
00007ec68bfdd7af  sub rsp, 0xF0
00007ec68bfdd7b6  vmovaps [rsp], xmm0
00007ec68bfdd7bb  vmovaps [rsp+0x10], xmm1
00007ec68bfdd7c1  vmovaps [rsp+0x20], xmm2
00007ec68bfdd7c7  vmovaps [rsp+0x30], xmm3
00007ec68bfdd7cd  vmovaps [rsp+0x40], xmm4
00007ec68bfdd7d3  vmovaps [rsp+0x50], xmm5
00007ec68bfdd7d9  vmovaps [rsp+0x60], xmm6
00007ec68bfdd7df  vmovaps [rsp+0x70], xmm7
00007ec68bfdd7e5  vmovaps [rsp+0x80], xmm9
00007ec68bfdd7ee  vmovaps [rsp+0x90], xmm10
00007ec68bfdd7f7  vmovaps [rsp+0xA0], xmm11
00007ec68bfdd800  vmovaps [rsp+0xB0], xmm12
00007ec68bfdd809  vmovaps [rsp+0xC0], xmm13
00007ec68bfdd812  vmovaps [rsp+0xD0], xmm14
00007ec68bfdd81b  vmovaps [rsp+0xE0], xmm15
00007ec68bfdd824  sub rsp, 0x30
00007ec68bfdd828  movaps [rsp], xmm8
00007ec68bfdd82d  movaps [rsp+0x10], xmm15
00007ec68bfdd833  movaps [rsp+0x20], xmm9
00007ec68bfdd839  lea rdi, [rsp]
00007ec68bfdd83d  mov esi, 0x00
00007ec68bfdd842  mov rax, 0x57D97DADF530
00007ec68bfdd84c  call rax
00007ec68bfdd84e  movaps xmm8, [rsp]
00007ec68bfdd853  add rsp, 0x30
00007ec68bfdd857  vmovaps xmm0, [rsp]
00007ec68bfdd85c  vmovaps xmm1, [rsp+0x10]
00007ec68bfdd862  vmovaps xmm2, [rsp+0x20]
00007ec68bfdd868  vmovaps xmm3, [rsp+0x30]
00007ec68bfdd86e  vmovaps xmm4, [rsp+0x40]
00007ec68bfdd874  vmovaps xmm5, [rsp+0x50]
00007ec68bfdd87a  vmovaps xmm6, [rsp+0x60]
00007ec68bfdd880  vmovaps xmm7, [rsp+0x70]
00007ec68bfdd886  vmovaps xmm9, [rsp+0x80]
00007ec68bfdd88f  vmovaps xmm10, [rsp+0x90]
00007ec68bfdd898  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdd8a1  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdd8aa  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdd8b3  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdd8bc  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdd8c5  add rsp, 0xF0
00007ec68bfdd8cc  pop r11
00007ec68bfdd8ce  pop r10
00007ec68bfdd8d0  pop r9
00007ec68bfdd8d2  pop r8
00007ec68bfdd8d4  pop rsi
00007ec68bfdd8d5  pop rdi
00007ec68bfdd8d6  pop rdx
00007ec68bfdd8d7  pop rcx
00007ec68bfdd8d8  pop rax
00007ec68bfdd8d9  add rsp, 0x08
00007ec68bfdd8dd  jmp 0x00007EC68BFD966A
00007ec68bfdd8e2  sub rsp, 0x08
00007ec68bfdd8e6  push rax
00007ec68bfdd8e7  push rcx
00007ec68bfdd8e8  push rdx
00007ec68bfdd8e9  push rdi
00007ec68bfdd8ea  push rsi
00007ec68bfdd8eb  push r8
00007ec68bfdd8ed  push r9
00007ec68bfdd8ef  push r10
00007ec68bfdd8f1  push r11
00007ec68bfdd8f3  sub rsp, 0xF0
00007ec68bfdd8fa  vmovaps [rsp], xmm0
00007ec68bfdd8ff  vmovaps [rsp+0x10], xmm1
00007ec68bfdd905  vmovaps [rsp+0x20], xmm2
00007ec68bfdd90b  vmovaps [rsp+0x30], xmm3
00007ec68bfdd911  vmovaps [rsp+0x40], xmm4
00007ec68bfdd917  vmovaps [rsp+0x50], xmm5
00007ec68bfdd91d  vmovaps [rsp+0x60], xmm6
00007ec68bfdd923  vmovaps [rsp+0x70], xmm7
00007ec68bfdd929  vmovaps [rsp+0x80], xmm8
00007ec68bfdd932  vmovaps [rsp+0x90], xmm9
00007ec68bfdd93b  vmovaps [rsp+0xA0], xmm10
00007ec68bfdd944  vmovaps [rsp+0xB0], xmm11
00007ec68bfdd94d  vmovaps [rsp+0xC0], xmm12
00007ec68bfdd956  vmovaps [rsp+0xD0], xmm13
00007ec68bfdd95f  vmovaps [rsp+0xE0], xmm14
00007ec68bfdd968  sub rsp, 0x30
00007ec68bfdd96c  movaps [rsp], xmm15
00007ec68bfdd971  movaps [rsp+0x10], xmm11
00007ec68bfdd977  movaps [rsp+0x20], xmm6
00007ec68bfdd97c  lea rdi, [rsp]
00007ec68bfdd980  mov esi, 0x00
00007ec68bfdd985  mov rax, 0x57D97DADF530
00007ec68bfdd98f  call rax
00007ec68bfdd991  movaps xmm15, [rsp]
00007ec68bfdd996  add rsp, 0x30
00007ec68bfdd99a  vmovaps xmm0, [rsp]
00007ec68bfdd99f  vmovaps xmm1, [rsp+0x10]
00007ec68bfdd9a5  vmovaps xmm2, [rsp+0x20]
00007ec68bfdd9ab  vmovaps xmm3, [rsp+0x30]
00007ec68bfdd9b1  vmovaps xmm4, [rsp+0x40]
00007ec68bfdd9b7  vmovaps xmm5, [rsp+0x50]
00007ec68bfdd9bd  vmovaps xmm6, [rsp+0x60]
00007ec68bfdd9c3  vmovaps xmm7, [rsp+0x70]
00007ec68bfdd9c9  vmovaps xmm8, [rsp+0x80]
00007ec68bfdd9d2  vmovaps xmm9, [rsp+0x90]
00007ec68bfdd9db  vmovaps xmm10, [rsp+0xA0]
00007ec68bfdd9e4  vmovaps xmm11, [rsp+0xB0]
00007ec68bfdd9ed  vmovaps xmm12, [rsp+0xC0]
00007ec68bfdd9f6  vmovaps xmm13, [rsp+0xD0]
00007ec68bfdd9ff  vmovaps xmm14, [rsp+0xE0]
00007ec68bfdda08  add rsp, 0xF0
00007ec68bfdda0f  pop r11
00007ec68bfdda11  pop r10
00007ec68bfdda13  pop r9
00007ec68bfdda15  pop r8
00007ec68bfdda17  pop rsi
00007ec68bfdda18  pop rdi
00007ec68bfdda19  pop rdx
00007ec68bfdda1a  pop rcx
00007ec68bfdda1b  pop rax
00007ec68bfdda1c  add rsp, 0x08
00007ec68bfdda20  jmp 0x00007EC68BFD9685
00007ec68bfdda25  sub rsp, 0x08
00007ec68bfdda29  push rax
00007ec68bfdda2a  push rcx
00007ec68bfdda2b  push rdx
00007ec68bfdda2c  push rdi
00007ec68bfdda2d  push rsi
00007ec68bfdda2e  push r8
00007ec68bfdda30  push r9
00007ec68bfdda32  push r10
00007ec68bfdda34  push r11
00007ec68bfdda36  sub rsp, 0xF0
00007ec68bfdda3d  vmovaps [rsp], xmm0
00007ec68bfdda42  vmovaps [rsp+0x10], xmm1
00007ec68bfdda48  vmovaps [rsp+0x20], xmm2
00007ec68bfdda4e  vmovaps [rsp+0x30], xmm3
00007ec68bfdda54  vmovaps [rsp+0x40], xmm4
00007ec68bfdda5a  vmovaps [rsp+0x50], xmm5
00007ec68bfdda60  vmovaps [rsp+0x60], xmm6
00007ec68bfdda66  vmovaps [rsp+0x70], xmm8
00007ec68bfdda6c  vmovaps [rsp+0x80], xmm9
00007ec68bfdda75  vmovaps [rsp+0x90], xmm10
00007ec68bfdda7e  vmovaps [rsp+0xA0], xmm11
00007ec68bfdda87  vmovaps [rsp+0xB0], xmm12
00007ec68bfdda90  vmovaps [rsp+0xC0], xmm13
00007ec68bfdda99  vmovaps [rsp+0xD0], xmm14
00007ec68bfddaa2  vmovaps [rsp+0xE0], xmm15
00007ec68bfddaab  sub rsp, 0x30
00007ec68bfddaaf  movaps [rsp], xmm7
00007ec68bfddab3  movaps [rsp+0x10], xmm11
00007ec68bfddab9  movaps [rsp+0x20], xmm9
00007ec68bfddabf  lea rdi, [rsp]
00007ec68bfddac3  mov esi, 0x00
00007ec68bfddac8  mov rax, 0x57D97DADF530
00007ec68bfddad2  call rax
00007ec68bfddad4  movaps xmm7, [rsp]
00007ec68bfddad8  add rsp, 0x30
00007ec68bfddadc  vmovaps xmm0, [rsp]
00007ec68bfddae1  vmovaps xmm1, [rsp+0x10]
00007ec68bfddae7  vmovaps xmm2, [rsp+0x20]
00007ec68bfddaed  vmovaps xmm3, [rsp+0x30]
00007ec68bfddaf3  vmovaps xmm4, [rsp+0x40]
00007ec68bfddaf9  vmovaps xmm5, [rsp+0x50]
00007ec68bfddaff  vmovaps xmm6, [rsp+0x60]
00007ec68bfddb05  vmovaps xmm8, [rsp+0x70]
00007ec68bfddb0b  vmovaps xmm9, [rsp+0x80]
00007ec68bfddb14  vmovaps xmm10, [rsp+0x90]
00007ec68bfddb1d  vmovaps xmm11, [rsp+0xA0]
00007ec68bfddb26  vmovaps xmm12, [rsp+0xB0]
00007ec68bfddb2f  vmovaps xmm13, [rsp+0xC0]
00007ec68bfddb38  vmovaps xmm14, [rsp+0xD0]
00007ec68bfddb41  vmovaps xmm15, [rsp+0xE0]
00007ec68bfddb4a  add rsp, 0xF0
00007ec68bfddb51  pop r11
00007ec68bfddb53  pop r10
00007ec68bfddb55  pop r9
00007ec68bfddb57  pop r8
00007ec68bfddb59  pop rsi
00007ec68bfddb5a  pop rdi
00007ec68bfddb5b  pop rdx
00007ec68bfddb5c  pop rcx
00007ec68bfddb5d  pop rax
00007ec68bfddb5e  add rsp, 0x08
00007ec68bfddb62  jmp 0x00007EC68BFD96B2
00007ec68bfddb67  sub rsp, 0x08
00007ec68bfddb6b  push rax
00007ec68bfddb6c  push rcx
00007ec68bfddb6d  push rdx
00007ec68bfddb6e  push rdi
00007ec68bfddb6f  push rsi
00007ec68bfddb70  push r8
00007ec68bfddb72  push r9
00007ec68bfddb74  push r10
00007ec68bfddb76  push r11
00007ec68bfddb78  sub rsp, 0xF0
00007ec68bfddb7f  vmovaps [rsp], xmm0
00007ec68bfddb84  vmovaps [rsp+0x10], xmm1
00007ec68bfddb8a  vmovaps [rsp+0x20], xmm2
00007ec68bfddb90  vmovaps [rsp+0x30], xmm3
00007ec68bfddb96  vmovaps [rsp+0x40], xmm4
00007ec68bfddb9c  vmovaps [rsp+0x50], xmm5
00007ec68bfddba2  vmovaps [rsp+0x60], xmm6
00007ec68bfddba8  vmovaps [rsp+0x70], xmm7
00007ec68bfddbae  vmovaps [rsp+0x80], xmm8
00007ec68bfddbb7  vmovaps [rsp+0x90], xmm9
00007ec68bfddbc0  vmovaps [rsp+0xA0], xmm10
00007ec68bfddbc9  vmovaps [rsp+0xB0], xmm12
00007ec68bfddbd2  vmovaps [rsp+0xC0], xmm13
00007ec68bfddbdb  vmovaps [rsp+0xD0], xmm14
00007ec68bfddbe4  vmovaps [rsp+0xE0], xmm15
00007ec68bfddbed  sub rsp, 0x30
00007ec68bfddbf1  movaps [rsp], xmm11
00007ec68bfddbf6  movaps [rsp+0x10], xmm10
00007ec68bfddbfc  movaps [rsp+0x20], xmm14
00007ec68bfddc02  lea rdi, [rsp]
00007ec68bfddc06  mov esi, 0x00
00007ec68bfddc0b  mov rax, 0x57D97DADF530
00007ec68bfddc15  call rax
00007ec68bfddc17  movaps xmm11, [rsp]
00007ec68bfddc1c  add rsp, 0x30
00007ec68bfddc20  vmovaps xmm0, [rsp]
00007ec68bfddc25  vmovaps xmm1, [rsp+0x10]
00007ec68bfddc2b  vmovaps xmm2, [rsp+0x20]
00007ec68bfddc31  vmovaps xmm3, [rsp+0x30]
00007ec68bfddc37  vmovaps xmm4, [rsp+0x40]
00007ec68bfddc3d  vmovaps xmm5, [rsp+0x50]
00007ec68bfddc43  vmovaps xmm6, [rsp+0x60]
00007ec68bfddc49  vmovaps xmm7, [rsp+0x70]
00007ec68bfddc4f  vmovaps xmm8, [rsp+0x80]
00007ec68bfddc58  vmovaps xmm9, [rsp+0x90]
00007ec68bfddc61  vmovaps xmm10, [rsp+0xA0]
00007ec68bfddc6a  vmovaps xmm12, [rsp+0xB0]
00007ec68bfddc73  vmovaps xmm13, [rsp+0xC0]
00007ec68bfddc7c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfddc85  vmovaps xmm15, [rsp+0xE0]
00007ec68bfddc8e  add rsp, 0xF0
00007ec68bfddc95  pop r11
00007ec68bfddc97  pop r10
00007ec68bfddc99  pop r9
00007ec68bfddc9b  pop r8
00007ec68bfddc9d  pop rsi
00007ec68bfddc9e  pop rdi
00007ec68bfddc9f  pop rdx
00007ec68bfddca0  pop rcx
00007ec68bfddca1  pop rax
00007ec68bfddca2  add rsp, 0x08
00007ec68bfddca6  jmp 0x00007EC68BFD96CD
00007ec68bfddcab  call 0x00007EC68BEE45A0
00007ec68bfddcb0  jmp 0x00007EC68BFD96D7
00007ec68bfddcb5  sub rsp, 0x08
00007ec68bfddcb9  push rax
00007ec68bfddcba  push rcx
00007ec68bfddcbb  push rdx
00007ec68bfddcbc  push rdi
00007ec68bfddcbd  push rsi
00007ec68bfddcbe  push r8
00007ec68bfddcc0  push r9
00007ec68bfddcc2  push r10
00007ec68bfddcc4  push r11
00007ec68bfddcc6  sub rsp, 0xF0
00007ec68bfddccd  vmovaps [rsp], xmm0
00007ec68bfddcd2  vmovaps [rsp+0x10], xmm1
00007ec68bfddcd8  vmovaps [rsp+0x20], xmm2
00007ec68bfddcde  vmovaps [rsp+0x30], xmm3
00007ec68bfddce4  vmovaps [rsp+0x40], xmm4
00007ec68bfddcea  vmovaps [rsp+0x50], xmm5
00007ec68bfddcf0  vmovaps [rsp+0x60], xmm6
00007ec68bfddcf6  vmovaps [rsp+0x70], xmm7
00007ec68bfddcfc  vmovaps [rsp+0x80], xmm8
00007ec68bfddd05  vmovaps [rsp+0x90], xmm9
00007ec68bfddd0e  vmovaps [rsp+0xA0], xmm11
00007ec68bfddd17  vmovaps [rsp+0xB0], xmm12
00007ec68bfddd20  vmovaps [rsp+0xC0], xmm13
00007ec68bfddd29  vmovaps [rsp+0xD0], xmm14
00007ec68bfddd32  vmovaps [rsp+0xE0], xmm15
00007ec68bfddd3b  sub rsp, 0x30
00007ec68bfddd3f  movaps [rsp], xmm10
00007ec68bfddd44  movaps [rsp+0x10], xmm1
00007ec68bfddd49  movaps [rsp+0x20], xmm12
00007ec68bfddd4f  lea rdi, [rsp]
00007ec68bfddd53  mov esi, 0x00
00007ec68bfddd58  mov rax, 0x57D97DADF530
00007ec68bfddd62  call rax
00007ec68bfddd64  movaps xmm10, [rsp]
00007ec68bfddd69  add rsp, 0x30
00007ec68bfddd6d  vmovaps xmm0, [rsp]
00007ec68bfddd72  vmovaps xmm1, [rsp+0x10]
00007ec68bfddd78  vmovaps xmm2, [rsp+0x20]
00007ec68bfddd7e  vmovaps xmm3, [rsp+0x30]
00007ec68bfddd84  vmovaps xmm4, [rsp+0x40]
00007ec68bfddd8a  vmovaps xmm5, [rsp+0x50]
00007ec68bfddd90  vmovaps xmm6, [rsp+0x60]
00007ec68bfddd96  vmovaps xmm7, [rsp+0x70]
00007ec68bfddd9c  vmovaps xmm8, [rsp+0x80]
00007ec68bfddda5  vmovaps xmm9, [rsp+0x90]
00007ec68bfdddae  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdddb7  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdddc0  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdddc9  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdddd2  vmovaps xmm15, [rsp+0xE0]
00007ec68bfddddb  add rsp, 0xF0
00007ec68bfddde2  pop r11
00007ec68bfddde4  pop r10
00007ec68bfddde6  pop r9
00007ec68bfddde8  pop r8
00007ec68bfdddea  pop rsi
00007ec68bfdddeb  pop rdi
00007ec68bfdddec  pop rdx
00007ec68bfddded  pop rcx
00007ec68bfdddee  pop rax
00007ec68bfdddef  add rsp, 0x08
00007ec68bfdddf3  jmp 0x00007EC68BFD96FA
00007ec68bfdddf8  sub rsp, 0x08
00007ec68bfdddfc  push rax
00007ec68bfdddfd  push rcx
00007ec68bfdddfe  push rdx
00007ec68bfdddff  push rdi
00007ec68bfdde00  push rsi
00007ec68bfdde01  push r8
00007ec68bfdde03  push r9
00007ec68bfdde05  push r10
00007ec68bfdde07  push r11
00007ec68bfdde09  sub rsp, 0xF0
00007ec68bfdde10  vmovaps [rsp], xmm0
00007ec68bfdde15  vmovaps [rsp+0x10], xmm1
00007ec68bfdde1b  vmovaps [rsp+0x20], xmm2
00007ec68bfdde21  vmovaps [rsp+0x30], xmm3
00007ec68bfdde27  vmovaps [rsp+0x40], xmm4
00007ec68bfdde2d  vmovaps [rsp+0x50], xmm5
00007ec68bfdde33  vmovaps [rsp+0x60], xmm6
00007ec68bfdde39  vmovaps [rsp+0x70], xmm7
00007ec68bfdde3f  vmovaps [rsp+0x80], xmm8
00007ec68bfdde48  vmovaps [rsp+0x90], xmm9
00007ec68bfdde51  vmovaps [rsp+0xA0], xmm10
00007ec68bfdde5a  vmovaps [rsp+0xB0], xmm11
00007ec68bfdde63  vmovaps [rsp+0xC0], xmm13
00007ec68bfdde6c  vmovaps [rsp+0xD0], xmm14
00007ec68bfdde75  vmovaps [rsp+0xE0], xmm15
00007ec68bfdde7e  sub rsp, 0x30
00007ec68bfdde82  movaps [rsp], xmm12
00007ec68bfdde87  movaps [rsp+0x10], xmm14
00007ec68bfdde8d  movaps [rsp+0x20], xmm1
00007ec68bfdde92  lea rdi, [rsp]
00007ec68bfdde96  mov esi, 0x00
00007ec68bfdde9b  mov rax, 0x57D97DADF530
00007ec68bfddea5  call rax
00007ec68bfddea7  movaps xmm12, [rsp]
00007ec68bfddeac  add rsp, 0x30
00007ec68bfddeb0  vmovaps xmm0, [rsp]
00007ec68bfddeb5  vmovaps xmm1, [rsp+0x10]
00007ec68bfddebb  vmovaps xmm2, [rsp+0x20]
00007ec68bfddec1  vmovaps xmm3, [rsp+0x30]
00007ec68bfddec7  vmovaps xmm4, [rsp+0x40]
00007ec68bfddecd  vmovaps xmm5, [rsp+0x50]
00007ec68bfdded3  vmovaps xmm6, [rsp+0x60]
00007ec68bfdded9  vmovaps xmm7, [rsp+0x70]
00007ec68bfddedf  vmovaps xmm8, [rsp+0x80]
00007ec68bfddee8  vmovaps xmm9, [rsp+0x90]
00007ec68bfddef1  vmovaps xmm10, [rsp+0xA0]
00007ec68bfddefa  vmovaps xmm11, [rsp+0xB0]
00007ec68bfddf03  vmovaps xmm13, [rsp+0xC0]
00007ec68bfddf0c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfddf15  vmovaps xmm15, [rsp+0xE0]
00007ec68bfddf1e  add rsp, 0xF0
00007ec68bfddf25  pop r11
00007ec68bfddf27  pop r10
00007ec68bfddf29  pop r9
00007ec68bfddf2b  pop r8
00007ec68bfddf2d  pop rsi
00007ec68bfddf2e  pop rdi
00007ec68bfddf2f  pop rdx
00007ec68bfddf30  pop rcx
00007ec68bfddf31  pop rax
00007ec68bfddf32  add rsp, 0x08
00007ec68bfddf36  jmp 0x00007EC68BFD9729
00007ec68bfddf3b  sub rsp, 0x08
00007ec68bfddf3f  push rax
00007ec68bfddf40  push rcx
00007ec68bfddf41  push rdx
00007ec68bfddf42  push rdi
00007ec68bfddf43  push rsi
00007ec68bfddf44  push r8
00007ec68bfddf46  push r9
00007ec68bfddf48  push r10
00007ec68bfddf4a  push r11
00007ec68bfddf4c  sub rsp, 0xF0
00007ec68bfddf53  vmovaps [rsp], xmm0
00007ec68bfddf58  vmovaps [rsp+0x10], xmm1
00007ec68bfddf5e  vmovaps [rsp+0x20], xmm2
00007ec68bfddf64  vmovaps [rsp+0x30], xmm3
00007ec68bfddf6a  vmovaps [rsp+0x40], xmm4
00007ec68bfddf70  vmovaps [rsp+0x50], xmm5
00007ec68bfddf76  vmovaps [rsp+0x60], xmm6
00007ec68bfddf7c  vmovaps [rsp+0x70], xmm7
00007ec68bfddf82  vmovaps [rsp+0x80], xmm8
00007ec68bfddf8b  vmovaps [rsp+0x90], xmm9
00007ec68bfddf94  vmovaps [rsp+0xA0], xmm10
00007ec68bfddf9d  vmovaps [rsp+0xB0], xmm11
00007ec68bfddfa6  vmovaps [rsp+0xC0], xmm12
00007ec68bfddfaf  vmovaps [rsp+0xD0], xmm13
00007ec68bfddfb8  vmovaps [rsp+0xE0], xmm15
00007ec68bfddfc1  sub rsp, 0x30
00007ec68bfddfc5  movaps [rsp], xmm14
00007ec68bfddfca  movaps [rsp+0x10], xmm9
00007ec68bfddfd0  movaps [rsp+0x20], xmm1
00007ec68bfddfd5  lea rdi, [rsp]
00007ec68bfddfd9  mov esi, 0x00
00007ec68bfddfde  mov rax, 0x57D97DADF530
00007ec68bfddfe8  call rax
00007ec68bfddfea  movaps xmm14, [rsp]
00007ec68bfddfef  add rsp, 0x30
00007ec68bfddff3  vmovaps xmm0, [rsp]
00007ec68bfddff8  vmovaps xmm1, [rsp+0x10]
00007ec68bfddffe  vmovaps xmm2, [rsp+0x20]
00007ec68bfde004  vmovaps xmm3, [rsp+0x30]
00007ec68bfde00a  vmovaps xmm4, [rsp+0x40]
00007ec68bfde010  vmovaps xmm5, [rsp+0x50]
00007ec68bfde016  vmovaps xmm6, [rsp+0x60]
00007ec68bfde01c  vmovaps xmm7, [rsp+0x70]
00007ec68bfde022  vmovaps xmm8, [rsp+0x80]
00007ec68bfde02b  vmovaps xmm9, [rsp+0x90]
00007ec68bfde034  vmovaps xmm10, [rsp+0xA0]
00007ec68bfde03d  vmovaps xmm11, [rsp+0xB0]
00007ec68bfde046  vmovaps xmm12, [rsp+0xC0]
00007ec68bfde04f  vmovaps xmm13, [rsp+0xD0]
00007ec68bfde058  vmovaps xmm15, [rsp+0xE0]
00007ec68bfde061  add rsp, 0xF0
00007ec68bfde068  pop r11
00007ec68bfde06a  pop r10
00007ec68bfde06c  pop r9
00007ec68bfde06e  pop r8
00007ec68bfde070  pop rsi
00007ec68bfde071  pop rdi
00007ec68bfde072  pop rdx
00007ec68bfde073  pop rcx
00007ec68bfde074  pop rax
00007ec68bfde075  add rsp, 0x08
00007ec68bfde079  jmp 0x00007EC68BFD9758
00007ec68bfde07e  sub rsp, 0x08
00007ec68bfde082  push rax
00007ec68bfde083  push rcx
00007ec68bfde084  push rdx
00007ec68bfde085  push rdi
00007ec68bfde086  push rsi
00007ec68bfde087  push r8
00007ec68bfde089  push r9
00007ec68bfde08b  push r10
00007ec68bfde08d  push r11
00007ec68bfde08f  sub rsp, 0xF0
00007ec68bfde096  vmovaps [rsp], xmm0
00007ec68bfde09b  vmovaps [rsp+0x10], xmm2
00007ec68bfde0a1  vmovaps [rsp+0x20], xmm3
00007ec68bfde0a7  vmovaps [rsp+0x30], xmm4
00007ec68bfde0ad  vmovaps [rsp+0x40], xmm5
00007ec68bfde0b3  vmovaps [rsp+0x50], xmm6
00007ec68bfde0b9  vmovaps [rsp+0x60], xmm7
00007ec68bfde0bf  vmovaps [rsp+0x70], xmm8
00007ec68bfde0c5  vmovaps [rsp+0x80], xmm9
00007ec68bfde0ce  vmovaps [rsp+0x90], xmm10
00007ec68bfde0d7  vmovaps [rsp+0xA0], xmm11
00007ec68bfde0e0  vmovaps [rsp+0xB0], xmm12
00007ec68bfde0e9  vmovaps [rsp+0xC0], xmm13
00007ec68bfde0f2  vmovaps [rsp+0xD0], xmm14
00007ec68bfde0fb  vmovaps [rsp+0xE0], xmm15
00007ec68bfde104  sub rsp, 0x30
00007ec68bfde108  movaps [rsp], xmm1
00007ec68bfde10c  movaps [rsp+0x10], xmm13
00007ec68bfde112  movaps [rsp+0x20], xmm8
00007ec68bfde118  lea rdi, [rsp]
00007ec68bfde11c  mov esi, 0x00
00007ec68bfde121  mov rax, 0x57D97DADF530
00007ec68bfde12b  call rax
00007ec68bfde12d  movaps xmm1, [rsp]
00007ec68bfde131  add rsp, 0x30
00007ec68bfde135  vmovaps xmm0, [rsp]
00007ec68bfde13a  vmovaps xmm2, [rsp+0x10]
00007ec68bfde140  vmovaps xmm3, [rsp+0x20]
00007ec68bfde146  vmovaps xmm4, [rsp+0x30]
00007ec68bfde14c  vmovaps xmm5, [rsp+0x40]
00007ec68bfde152  vmovaps xmm6, [rsp+0x50]
00007ec68bfde158  vmovaps xmm7, [rsp+0x60]
00007ec68bfde15e  vmovaps xmm8, [rsp+0x70]
00007ec68bfde164  vmovaps xmm9, [rsp+0x80]
00007ec68bfde16d  vmovaps xmm10, [rsp+0x90]
00007ec68bfde176  vmovaps xmm11, [rsp+0xA0]
00007ec68bfde17f  vmovaps xmm12, [rsp+0xB0]
00007ec68bfde188  vmovaps xmm13, [rsp+0xC0]
00007ec68bfde191  vmovaps xmm14, [rsp+0xD0]
00007ec68bfde19a  vmovaps xmm15, [rsp+0xE0]
00007ec68bfde1a3  add rsp, 0xF0
00007ec68bfde1aa  pop r11
00007ec68bfde1ac  pop r10
00007ec68bfde1ae  pop r9
00007ec68bfde1b0  pop r8
00007ec68bfde1b2  pop rsi
00007ec68bfde1b3  pop rdi
00007ec68bfde1b4  pop rdx
00007ec68bfde1b5  pop rcx
00007ec68bfde1b6  pop rax
00007ec68bfde1b7  add rsp, 0x08
00007ec68bfde1bb  jmp 0x00007EC68BFD977A
00007ec68bfde1c0  call 0x00007EC68BE0C260
00007ec68bfde1c5  jmp 0x00007EC68BFD9788
00007ec68bfde1ca  call 0x00007EC68BEDE950
00007ec68bfde1cf  jmp 0x00007EC68BFD9792
00007ec68bfde1d4  sub rsp, 0x08
00007ec68bfde1d8  push rax
00007ec68bfde1d9  push rcx
00007ec68bfde1da  push rdx
00007ec68bfde1db  push rdi
00007ec68bfde1dc  push rsi
00007ec68bfde1dd  push r8
00007ec68bfde1df  push r9
00007ec68bfde1e1  push r10
00007ec68bfde1e3  push r11
00007ec68bfde1e5  sub rsp, 0xF0
00007ec68bfde1ec  vmovaps [rsp], xmm0
00007ec68bfde1f1  vmovaps [rsp+0x10], xmm1
00007ec68bfde1f7  vmovaps [rsp+0x20], xmm2
00007ec68bfde1fd  vmovaps [rsp+0x30], xmm3
00007ec68bfde203  vmovaps [rsp+0x40], xmm4
00007ec68bfde209  vmovaps [rsp+0x50], xmm5
00007ec68bfde20f  vmovaps [rsp+0x60], xmm6
00007ec68bfde215  vmovaps [rsp+0x70], xmm7
00007ec68bfde21b  vmovaps [rsp+0x80], xmm9
00007ec68bfde224  vmovaps [rsp+0x90], xmm10
00007ec68bfde22d  vmovaps [rsp+0xA0], xmm11
00007ec68bfde236  vmovaps [rsp+0xB0], xmm12
00007ec68bfde23f  vmovaps [rsp+0xC0], xmm13
00007ec68bfde248  vmovaps [rsp+0xD0], xmm14
00007ec68bfde251  vmovaps [rsp+0xE0], xmm15
00007ec68bfde25a  sub rsp, 0x30
00007ec68bfde25e  movaps [rsp], xmm8
00007ec68bfde263  movaps [rsp+0x10], xmm15
00007ec68bfde269  movaps [rsp+0x20], xmm7
00007ec68bfde26e  lea rdi, [rsp]
00007ec68bfde272  mov esi, 0x00
00007ec68bfde277  mov rax, 0x57D97DADF530
00007ec68bfde281  call rax
00007ec68bfde283  movaps xmm8, [rsp]
00007ec68bfde288  add rsp, 0x30
00007ec68bfde28c  vmovaps xmm0, [rsp]
00007ec68bfde291  vmovaps xmm1, [rsp+0x10]
00007ec68bfde297  vmovaps xmm2, [rsp+0x20]
00007ec68bfde29d  vmovaps xmm3, [rsp+0x30]
00007ec68bfde2a3  vmovaps xmm4, [rsp+0x40]
00007ec68bfde2a9  vmovaps xmm5, [rsp+0x50]
00007ec68bfde2af  vmovaps xmm6, [rsp+0x60]
00007ec68bfde2b5  vmovaps xmm7, [rsp+0x70]
00007ec68bfde2bb  vmovaps xmm9, [rsp+0x80]
00007ec68bfde2c4  vmovaps xmm10, [rsp+0x90]
00007ec68bfde2cd  vmovaps xmm11, [rsp+0xA0]
00007ec68bfde2d6  vmovaps xmm12, [rsp+0xB0]
00007ec68bfde2df  vmovaps xmm13, [rsp+0xC0]
00007ec68bfde2e8  vmovaps xmm14, [rsp+0xD0]
00007ec68bfde2f1  vmovaps xmm15, [rsp+0xE0]
00007ec68bfde2fa  add rsp, 0xF0
00007ec68bfde301  pop r11
00007ec68bfde303  pop r10
00007ec68bfde305  pop r9
00007ec68bfde307  pop r8
00007ec68bfde309  pop rsi
00007ec68bfde30a  pop rdi
00007ec68bfde30b  pop rdx
00007ec68bfde30c  pop rcx
00007ec68bfde30d  pop rax
00007ec68bfde30e  add rsp, 0x08
00007ec68bfde312  jmp 0x00007EC68BFD97B4
00007ec68bfde317  sub rsp, 0x08
00007ec68bfde31b  push rax
00007ec68bfde31c  push rcx
00007ec68bfde31d  push rdx
00007ec68bfde31e  push rdi
00007ec68bfde31f  push rsi
00007ec68bfde320  push r8
00007ec68bfde322  push r9
00007ec68bfde324  push r10
00007ec68bfde326  push r11
00007ec68bfde328  sub rsp, 0xF0
00007ec68bfde32f  vmovaps [rsp], xmm0
00007ec68bfde334  vmovaps [rsp+0x10], xmm1
00007ec68bfde33a  vmovaps [rsp+0x20], xmm2
00007ec68bfde340  vmovaps [rsp+0x30], xmm3
00007ec68bfde346  vmovaps [rsp+0x40], xmm4
00007ec68bfde34c  vmovaps [rsp+0x50], xmm5
00007ec68bfde352  vmovaps [rsp+0x60], xmm6
00007ec68bfde358  vmovaps [rsp+0x70], xmm8
00007ec68bfde35e  vmovaps [rsp+0x80], xmm9
00007ec68bfde367  vmovaps [rsp+0x90], xmm10
00007ec68bfde370  vmovaps [rsp+0xA0], xmm11
00007ec68bfde379  vmovaps [rsp+0xB0], xmm12
00007ec68bfde382  vmovaps [rsp+0xC0], xmm13
00007ec68bfde38b  vmovaps [rsp+0xD0], xmm14
00007ec68bfde394  vmovaps [rsp+0xE0], xmm15
00007ec68bfde39d  sub rsp, 0x30
00007ec68bfde3a1  movaps [rsp], xmm7
00007ec68bfde3a5  movaps [rsp+0x10], xmm9
00007ec68bfde3ab  movaps [rsp+0x20], xmm15
00007ec68bfde3b1  lea rdi, [rsp]
00007ec68bfde3b5  mov esi, 0x00
00007ec68bfde3ba  mov rax, 0x57D97DADF530
00007ec68bfde3c4  call rax
00007ec68bfde3c6  movaps xmm7, [rsp]
00007ec68bfde3ca  add rsp, 0x30
00007ec68bfde3ce  vmovaps xmm0, [rsp]
00007ec68bfde3d3  vmovaps xmm1, [rsp+0x10]
00007ec68bfde3d9  vmovaps xmm2, [rsp+0x20]
00007ec68bfde3df  vmovaps xmm3, [rsp+0x30]
00007ec68bfde3e5  vmovaps xmm4, [rsp+0x40]
00007ec68bfde3eb  vmovaps xmm5, [rsp+0x50]
00007ec68bfde3f1  vmovaps xmm6, [rsp+0x60]
00007ec68bfde3f7  vmovaps xmm8, [rsp+0x70]
00007ec68bfde3fd  vmovaps xmm9, [rsp+0x80]
00007ec68bfde406  vmovaps xmm10, [rsp+0x90]
00007ec68bfde40f  vmovaps xmm11, [rsp+0xA0]
00007ec68bfde418  vmovaps xmm12, [rsp+0xB0]
00007ec68bfde421  vmovaps xmm13, [rsp+0xC0]
00007ec68bfde42a  vmovaps xmm14, [rsp+0xD0]
00007ec68bfde433  vmovaps xmm15, [rsp+0xE0]
00007ec68bfde43c  add rsp, 0xF0
00007ec68bfde443  pop r11
00007ec68bfde445  pop r10
00007ec68bfde447  pop r9
00007ec68bfde449  pop r8
00007ec68bfde44b  pop rsi
00007ec68bfde44c  pop rdi
00007ec68bfde44d  pop rdx
00007ec68bfde44e  pop rcx
00007ec68bfde44f  pop rax
00007ec68bfde450  add rsp, 0x08
00007ec68bfde454  jmp 0x00007EC68BFD97E1
00007ec68bfde459  sub rsp, 0x08
00007ec68bfde45d  push rax
00007ec68bfde45e  push rcx
00007ec68bfde45f  push rdx
00007ec68bfde460  push rdi
00007ec68bfde461  push rsi
00007ec68bfde462  push r8
00007ec68bfde464  push r9
00007ec68bfde466  push r10
00007ec68bfde468  push r11
00007ec68bfde46a  sub rsp, 0xF0
00007ec68bfde471  vmovaps [rsp], xmm0
00007ec68bfde476  vmovaps [rsp+0x10], xmm1
00007ec68bfde47c  vmovaps [rsp+0x20], xmm2
00007ec68bfde482  vmovaps [rsp+0x30], xmm3
00007ec68bfde488  vmovaps [rsp+0x40], xmm4
00007ec68bfde48e  vmovaps [rsp+0x50], xmm5
00007ec68bfde494  vmovaps [rsp+0x60], xmm6
00007ec68bfde49a  vmovaps [rsp+0x70], xmm7
00007ec68bfde4a0  vmovaps [rsp+0x80], xmm8
00007ec68bfde4a9  vmovaps [rsp+0x90], xmm10
00007ec68bfde4b2  vmovaps [rsp+0xA0], xmm11
00007ec68bfde4bb  vmovaps [rsp+0xB0], xmm12
00007ec68bfde4c4  vmovaps [rsp+0xC0], xmm13
00007ec68bfde4cd  vmovaps [rsp+0xD0], xmm14
00007ec68bfde4d6  vmovaps [rsp+0xE0], xmm15
00007ec68bfde4df  sub rsp, 0x30
00007ec68bfde4e3  movaps [rsp], xmm9
00007ec68bfde4e8  movaps [rsp+0x10], xmm13
00007ec68bfde4ee  movaps [rsp+0x20], xmm15
00007ec68bfde4f4  lea rdi, [rsp]
00007ec68bfde4f8  mov esi, 0x00
00007ec68bfde4fd  mov rax, 0x57D97DADF530
00007ec68bfde507  call rax
00007ec68bfde509  movaps xmm9, [rsp]
00007ec68bfde50e  add rsp, 0x30
00007ec68bfde512  vmovaps xmm0, [rsp]
00007ec68bfde517  vmovaps xmm1, [rsp+0x10]
00007ec68bfde51d  vmovaps xmm2, [rsp+0x20]
00007ec68bfde523  vmovaps xmm3, [rsp+0x30]
00007ec68bfde529  vmovaps xmm4, [rsp+0x40]
00007ec68bfde52f  vmovaps xmm5, [rsp+0x50]
00007ec68bfde535  vmovaps xmm6, [rsp+0x60]
00007ec68bfde53b  vmovaps xmm7, [rsp+0x70]
00007ec68bfde541  vmovaps xmm8, [rsp+0x80]
00007ec68bfde54a  vmovaps xmm10, [rsp+0x90]
00007ec68bfde553  vmovaps xmm11, [rsp+0xA0]
00007ec68bfde55c  vmovaps xmm12, [rsp+0xB0]
00007ec68bfde565  vmovaps xmm13, [rsp+0xC0]
00007ec68bfde56e  vmovaps xmm14, [rsp+0xD0]
00007ec68bfde577  vmovaps xmm15, [rsp+0xE0]
00007ec68bfde580  add rsp, 0xF0
00007ec68bfde587  pop r11
00007ec68bfde589  pop r10
00007ec68bfde58b  pop r9
00007ec68bfde58d  pop r8
00007ec68bfde58f  pop rsi
00007ec68bfde590  pop rdi
00007ec68bfde591  pop rdx
00007ec68bfde592  pop rcx
00007ec68bfde593  pop rax
00007ec68bfde594  add rsp, 0x08
00007ec68bfde598  jmp 0x00007EC68BFD980F
00007ec68bfde59d  sub rsp, 0x08
00007ec68bfde5a1  push rax
00007ec68bfde5a2  push rcx
00007ec68bfde5a3  push rdx
00007ec68bfde5a4  push rdi
00007ec68bfde5a5  push rsi
00007ec68bfde5a6  push r8
00007ec68bfde5a8  push r9
00007ec68bfde5aa  push r10
00007ec68bfde5ac  push r11
00007ec68bfde5ae  sub rsp, 0xF0
00007ec68bfde5b5  vmovaps [rsp], xmm0
00007ec68bfde5ba  vmovaps [rsp+0x10], xmm1
00007ec68bfde5c0  vmovaps [rsp+0x20], xmm2
00007ec68bfde5c6  vmovaps [rsp+0x30], xmm3
00007ec68bfde5cc  vmovaps [rsp+0x40], xmm4
00007ec68bfde5d2  vmovaps [rsp+0x50], xmm5
00007ec68bfde5d8  vmovaps [rsp+0x60], xmm6
00007ec68bfde5de  vmovaps [rsp+0x70], xmm7
00007ec68bfde5e4  vmovaps [rsp+0x80], xmm8
00007ec68bfde5ed  vmovaps [rsp+0x90], xmm9
00007ec68bfde5f6  vmovaps [rsp+0xA0], xmm10
00007ec68bfde5ff  vmovaps [rsp+0xB0], xmm11
00007ec68bfde608  vmovaps [rsp+0xC0], xmm12
00007ec68bfde611  vmovaps [rsp+0xD0], xmm13
00007ec68bfde61a  vmovaps [rsp+0xE0], xmm14
00007ec68bfde623  sub rsp, 0x30
00007ec68bfde627  movaps [rsp], xmm15
00007ec68bfde62c  movaps [rsp+0x10], xmm11
00007ec68bfde632  movaps [rsp+0x20], xmm12
00007ec68bfde638  lea rdi, [rsp]
00007ec68bfde63c  mov esi, 0x00
00007ec68bfde641  mov rax, 0x57D97DADF530
00007ec68bfde64b  call rax
00007ec68bfde64d  movaps xmm15, [rsp]
00007ec68bfde652  add rsp, 0x30
00007ec68bfde656  vmovaps xmm0, [rsp]
00007ec68bfde65b  vmovaps xmm1, [rsp+0x10]
00007ec68bfde661  vmovaps xmm2, [rsp+0x20]
00007ec68bfde667  vmovaps xmm3, [rsp+0x30]
00007ec68bfde66d  vmovaps xmm4, [rsp+0x40]
00007ec68bfde673  vmovaps xmm5, [rsp+0x50]
00007ec68bfde679  vmovaps xmm6, [rsp+0x60]
00007ec68bfde67f  vmovaps xmm7, [rsp+0x70]
00007ec68bfde685  vmovaps xmm8, [rsp+0x80]
00007ec68bfde68e  vmovaps xmm9, [rsp+0x90]
00007ec68bfde697  vmovaps xmm10, [rsp+0xA0]
00007ec68bfde6a0  vmovaps xmm11, [rsp+0xB0]
00007ec68bfde6a9  vmovaps xmm12, [rsp+0xC0]
00007ec68bfde6b2  vmovaps xmm13, [rsp+0xD0]
00007ec68bfde6bb  vmovaps xmm14, [rsp+0xE0]
00007ec68bfde6c4  add rsp, 0xF0
00007ec68bfde6cb  pop r11
00007ec68bfde6cd  pop r10
00007ec68bfde6cf  pop r9
00007ec68bfde6d1  pop r8
00007ec68bfde6d3  pop rsi
00007ec68bfde6d4  pop rdi
00007ec68bfde6d5  pop rdx
00007ec68bfde6d6  pop rcx
00007ec68bfde6d7  pop rax
00007ec68bfde6d8  add rsp, 0x08
00007ec68bfde6dc  jmp 0x00007EC68BFD982A
00007ec68bfde6e1  sub rsp, 0x08
00007ec68bfde6e5  push rax
00007ec68bfde6e6  push rcx
00007ec68bfde6e7  push rdx
00007ec68bfde6e8  push rdi
00007ec68bfde6e9  push rsi
00007ec68bfde6ea  push r8
00007ec68bfde6ec  push r9
00007ec68bfde6ee  push r10
00007ec68bfde6f0  push r11
00007ec68bfde6f2  sub rsp, 0xF0
00007ec68bfde6f9  vmovaps [rsp], xmm0
00007ec68bfde6fe  vmovaps [rsp+0x10], xmm1
00007ec68bfde704  vmovaps [rsp+0x20], xmm2
00007ec68bfde70a  vmovaps [rsp+0x30], xmm3
00007ec68bfde710  vmovaps [rsp+0x40], xmm4
00007ec68bfde716  vmovaps [rsp+0x50], xmm5
00007ec68bfde71c  vmovaps [rsp+0x60], xmm6
00007ec68bfde722  vmovaps [rsp+0x70], xmm7
00007ec68bfde728  vmovaps [rsp+0x80], xmm8
00007ec68bfde731  vmovaps [rsp+0x90], xmm9
00007ec68bfde73a  vmovaps [rsp+0xA0], xmm10
00007ec68bfde743  vmovaps [rsp+0xB0], xmm11
00007ec68bfde74c  vmovaps [rsp+0xC0], xmm12
00007ec68bfde755  vmovaps [rsp+0xD0], xmm14
00007ec68bfde75e  vmovaps [rsp+0xE0], xmm15
00007ec68bfde767  sub rsp, 0x30
00007ec68bfde76b  movaps [rsp], xmm13
00007ec68bfde770  movaps [rsp+0x10], xmm10
00007ec68bfde776  movaps [rsp+0x20], xmm14
00007ec68bfde77c  lea rdi, [rsp]
00007ec68bfde780  mov esi, 0x00
00007ec68bfde785  mov rax, 0x57D97DADF530
00007ec68bfde78f  call rax
00007ec68bfde791  movaps xmm13, [rsp]
00007ec68bfde796  add rsp, 0x30
00007ec68bfde79a  vmovaps xmm0, [rsp]
00007ec68bfde79f  vmovaps xmm1, [rsp+0x10]
00007ec68bfde7a5  vmovaps xmm2, [rsp+0x20]
00007ec68bfde7ab  vmovaps xmm3, [rsp+0x30]
00007ec68bfde7b1  vmovaps xmm4, [rsp+0x40]
00007ec68bfde7b7  vmovaps xmm5, [rsp+0x50]
00007ec68bfde7bd  vmovaps xmm6, [rsp+0x60]
00007ec68bfde7c3  vmovaps xmm7, [rsp+0x70]
00007ec68bfde7c9  vmovaps xmm8, [rsp+0x80]
00007ec68bfde7d2  vmovaps xmm9, [rsp+0x90]
00007ec68bfde7db  vmovaps xmm10, [rsp+0xA0]
00007ec68bfde7e4  vmovaps xmm11, [rsp+0xB0]
00007ec68bfde7ed  vmovaps xmm12, [rsp+0xC0]
00007ec68bfde7f6  vmovaps xmm14, [rsp+0xD0]
00007ec68bfde7ff  vmovaps xmm15, [rsp+0xE0]
00007ec68bfde808  add rsp, 0xF0
00007ec68bfde80f  pop r11
00007ec68bfde811  pop r10
00007ec68bfde813  pop r9
00007ec68bfde815  pop r8
00007ec68bfde817  pop rsi
00007ec68bfde818  pop rdi
00007ec68bfde819  pop rdx
00007ec68bfde81a  pop rcx
00007ec68bfde81b  pop rax
00007ec68bfde81c  add rsp, 0x08
00007ec68bfde820  jmp 0x00007EC68BFD984D
00007ec68bfde825  sub rsp, 0x08
00007ec68bfde829  push rax
00007ec68bfde82a  push rcx
00007ec68bfde82b  push rdx
00007ec68bfde82c  push rdi
00007ec68bfde82d  push rsi
00007ec68bfde82e  push r8
00007ec68bfde830  push r9
00007ec68bfde832  push r10
00007ec68bfde834  push r11
00007ec68bfde836  sub rsp, 0xF0
00007ec68bfde83d  vmovaps [rsp], xmm0
00007ec68bfde842  vmovaps [rsp+0x10], xmm1
00007ec68bfde848  vmovaps [rsp+0x20], xmm2
00007ec68bfde84e  vmovaps [rsp+0x30], xmm3
00007ec68bfde854  vmovaps [rsp+0x40], xmm4
00007ec68bfde85a  vmovaps [rsp+0x50], xmm5
00007ec68bfde860  vmovaps [rsp+0x60], xmm6
00007ec68bfde866  vmovaps [rsp+0x70], xmm7
00007ec68bfde86c  vmovaps [rsp+0x80], xmm8
00007ec68bfde875  vmovaps [rsp+0x90], xmm9
00007ec68bfde87e  vmovaps [rsp+0xA0], xmm10
00007ec68bfde887  vmovaps [rsp+0xB0], xmm11
00007ec68bfde890  vmovaps [rsp+0xC0], xmm12
00007ec68bfde899  vmovaps [rsp+0xD0], xmm13
00007ec68bfde8a2  vmovaps [rsp+0xE0], xmm15
00007ec68bfde8ab  sub rsp, 0x30
00007ec68bfde8af  movaps [rsp], xmm14
00007ec68bfde8b4  movaps [rsp+0x10], xmm1
00007ec68bfde8b9  movaps [rsp+0x20], xmm7
00007ec68bfde8be  lea rdi, [rsp]
00007ec68bfde8c2  mov esi, 0x00
00007ec68bfde8c7  mov rax, 0x57D97DADF530
00007ec68bfde8d1  call rax
00007ec68bfde8d3  movaps xmm14, [rsp]
00007ec68bfde8d8  add rsp, 0x30
00007ec68bfde8dc  vmovaps xmm0, [rsp]
00007ec68bfde8e1  vmovaps xmm1, [rsp+0x10]
00007ec68bfde8e7  vmovaps xmm2, [rsp+0x20]
00007ec68bfde8ed  vmovaps xmm3, [rsp+0x30]
00007ec68bfde8f3  vmovaps xmm4, [rsp+0x40]
00007ec68bfde8f9  vmovaps xmm5, [rsp+0x50]
00007ec68bfde8ff  vmovaps xmm6, [rsp+0x60]
00007ec68bfde905  vmovaps xmm7, [rsp+0x70]
00007ec68bfde90b  vmovaps xmm8, [rsp+0x80]
00007ec68bfde914  vmovaps xmm9, [rsp+0x90]
00007ec68bfde91d  vmovaps xmm10, [rsp+0xA0]
00007ec68bfde926  vmovaps xmm11, [rsp+0xB0]
00007ec68bfde92f  vmovaps xmm12, [rsp+0xC0]
00007ec68bfde938  vmovaps xmm13, [rsp+0xD0]
00007ec68bfde941  vmovaps xmm15, [rsp+0xE0]
00007ec68bfde94a  add rsp, 0xF0
00007ec68bfde951  pop r11
00007ec68bfde953  pop r10
00007ec68bfde955  pop r9
00007ec68bfde957  pop r8
00007ec68bfde959  pop rsi
00007ec68bfde95a  pop rdi
00007ec68bfde95b  pop rdx
00007ec68bfde95c  pop rcx
00007ec68bfde95d  pop rax
00007ec68bfde95e  add rsp, 0x08
00007ec68bfde962  jmp 0x00007EC68BFD9870
00007ec68bfde967  sub rsp, 0x08
00007ec68bfde96b  push rax
00007ec68bfde96c  push rcx
00007ec68bfde96d  push rdx
00007ec68bfde96e  push rdi
00007ec68bfde96f  push rsi
00007ec68bfde970  push r8
00007ec68bfde972  push r9
00007ec68bfde974  push r10
00007ec68bfde976  push r11
00007ec68bfde978  sub rsp, 0xF0
00007ec68bfde97f  vmovaps [rsp], xmm0
00007ec68bfde984  vmovaps [rsp+0x10], xmm2
00007ec68bfde98a  vmovaps [rsp+0x20], xmm3
00007ec68bfde990  vmovaps [rsp+0x30], xmm4
00007ec68bfde996  vmovaps [rsp+0x40], xmm5
00007ec68bfde99c  vmovaps [rsp+0x50], xmm6
00007ec68bfde9a2  vmovaps [rsp+0x60], xmm7
00007ec68bfde9a8  vmovaps [rsp+0x70], xmm8
00007ec68bfde9ae  vmovaps [rsp+0x80], xmm9
00007ec68bfde9b7  vmovaps [rsp+0x90], xmm10
00007ec68bfde9c0  vmovaps [rsp+0xA0], xmm11
00007ec68bfde9c9  vmovaps [rsp+0xB0], xmm12
00007ec68bfde9d2  vmovaps [rsp+0xC0], xmm13
00007ec68bfde9db  vmovaps [rsp+0xD0], xmm14
00007ec68bfde9e4  vmovaps [rsp+0xE0], xmm15
00007ec68bfde9ed  sub rsp, 0x30
00007ec68bfde9f1  movaps [rsp], xmm1
00007ec68bfde9f5  movaps [rsp+0x10], xmm8
00007ec68bfde9fb  movaps [rsp+0x20], xmm9
00007ec68bfdea01  lea rdi, [rsp]
00007ec68bfdea05  mov esi, 0x00
00007ec68bfdea0a  mov rax, 0x57D97DADF530
00007ec68bfdea14  call rax
00007ec68bfdea16  movaps xmm1, [rsp]
00007ec68bfdea1a  add rsp, 0x30
00007ec68bfdea1e  vmovaps xmm0, [rsp]
00007ec68bfdea23  vmovaps xmm2, [rsp+0x10]
00007ec68bfdea29  vmovaps xmm3, [rsp+0x20]
00007ec68bfdea2f  vmovaps xmm4, [rsp+0x30]
00007ec68bfdea35  vmovaps xmm5, [rsp+0x40]
00007ec68bfdea3b  vmovaps xmm6, [rsp+0x50]
00007ec68bfdea41  vmovaps xmm7, [rsp+0x60]
00007ec68bfdea47  vmovaps xmm8, [rsp+0x70]
00007ec68bfdea4d  vmovaps xmm9, [rsp+0x80]
00007ec68bfdea56  vmovaps xmm10, [rsp+0x90]
00007ec68bfdea5f  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdea68  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdea71  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdea7a  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdea83  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdea8c  add rsp, 0xF0
00007ec68bfdea93  pop r11
00007ec68bfdea95  pop r10
00007ec68bfdea97  pop r9
00007ec68bfdea99  pop r8
00007ec68bfdea9b  pop rsi
00007ec68bfdea9c  pop rdi
00007ec68bfdea9d  pop rdx
00007ec68bfdea9e  pop rcx
00007ec68bfdea9f  pop rax
00007ec68bfdeaa0  add rsp, 0x08
00007ec68bfdeaa4  jmp 0x00007EC68BFD9892
00007ec68bfdeaa9  call 0x00007EC68BEB3E40
00007ec68bfdeaae  jmp 0x00007EC68BFD98A0
00007ec68bfdeab3  call 0x00007EC68BE0C380
00007ec68bfdeab8  jmp 0x00007EC68BFD98AA
00007ec68bfdeabd  call 0x00007EC68BE0D600
00007ec68bfdeac2  jmp 0x00007EC68BFD98B4
00007ec68bfdeac7  call 0x00007EC68BDFF540
00007ec68bfdeacc  jmp 0x00007EC68BFD98BE
00007ec68bfdead1  int3
00007ec68bfdead2  nop [rax+rax*1], ax
00007ec68bfdeadb  nop [rax+rax*1], eax
00007ec68bfdeae0  mov eax, [r15+0x48]
00007ec68bfdeae4  lea r14d, [eax+0x01]
00007ec68bfdeae9  mov [rsp+0x10], r14d
00007ec68bfdeaee  mov r14d, r14d
00007ec68bfdeaf1  mov [r15+0x48], r14
00007ec68bfdeaf5  xor eax, eax
00007ec68bfdeaf7  mov r14d, [rsp+0x10]
00007ec68bfdeafc  cmp r14d, 0x1F4
00007ec68bfdeb03  cmc
00007ec68bfdeb04  lahf
00007ec68bfdeb05  seto al
00007ec68bfdeb08  mov [r15+0x108], eax
00007ec68bfdeb0f  mov eax, [r15+0x108]
00007ec68bfdeb16  sahf
00007ec68bfdeb17  jnz 0x00007EC68BFDEB49
00007ec68bfdeb19  cmp dword ptr [r15+0x318], 0x00
00007ec68bfdeb21  jz 0x00007EC68BFE4C90
00007ec68bfdeb27  nop [rax+rax*1], ax
00007ec68bfdeb30  nop [rax+rax*1], eax
00007ec68bfdeb38  mov eax, 0x4106DC
00007ec68bfdeb3d  mov [r15+0x100], rax
00007ec68bfdeb44  jmp 0x00007EC68BDFE110
00007ec68bfdeb49  cmp dword ptr [r15+0x318], 0x00
00007ec68bfdeb51  jz 0x00007EC68BFDEB80
00007ec68bfdeb57  nop [rax+rax*1], ax
00007ec68bfdeb60  nop [rax+rax*1], eax
00007ec68bfdeb68  mov eax, 0x410500
00007ec68bfdeb6d  mov [r15+0x100], rax
00007ec68bfdeb74  jmp 0x00007EC68BDFE110
00007ec68bfdeb79  int3
00007ec68bfdeb7a  int3
00007ec68bfdeb7b  nop [rax+rax*1], eax
00007ec68bfdeb80  mov rax, [r15+0x40]
00007ec68bfdeb84  movaps xmm1, [r15+0x1D0]
00007ec68bfdeb8c  vmovaps [rsp+0x10], xmm1
00007ec68bfdeb92  vmovaps xmm15, [rsp+0x10]
00007ec68bfdeb98  por xmm1, xmm15
00007ec68bfdeb9d  movaps xmm14, [r15+0x1A0]
00007ec68bfdeba5  vmovaps [rsp+0x10], xmm14
00007ec68bfdebab  vmovaps xmm13, [rsp+0x10]
00007ec68bfdebb1  por xmm14, xmm13
00007ec68bfdebb6  lea r14, [rax+0x30]
00007ec68bfdebba  mov r12, [r13+r14*1]
00007ec68bfdebbf  lea r14, [rax+0x38]
00007ec68bfdebc3  mov r11, [r13+r14*1]
00007ec68bfdebc8  movq xmm13, r12
00007ec68bfdebcd  movq xmm12, r11
00007ec68bfdebd2  movq xmm13, xmm13
00007ec68bfdebd7  vmovaps [rsp+0x10], xmm13
00007ec68bfdebdd  movq xmm13, xmm13
00007ec68bfdebe2  movaps [r15+0x130], xmm13
00007ec68bfdebea  movq xmm12, xmm12
00007ec68bfdebef  vmovaps [rsp+0x20], xmm12
00007ec68bfdebf5  movq xmm12, xmm12
00007ec68bfdebfa  movaps [r15+0x280], xmm12
00007ec68bfdec02  movaps xmm13, [r15+0x270]
00007ec68bfdec0a  vmovaps [rsp+0x30], xmm13
00007ec68bfdec10  vmovaps xmm12, [rsp+0x30]
00007ec68bfdec16  por xmm13, xmm12
00007ec68bfdec1b  lea r14, [rax+0x20]
00007ec68bfdec1f  mov r12, [r13+r14*1]
00007ec68bfdec24  lea r14, [rax+0x28]
00007ec68bfdec28  mov r11, [r13+r14*1]
00007ec68bfdec2d  movq xmm12, r12
00007ec68bfdec32  movq xmm11, r11
00007ec68bfdec37  movq xmm12, xmm12
00007ec68bfdec3c  vmovaps [rsp+0x30], xmm12
00007ec68bfdec42  movq xmm12, xmm12
00007ec68bfdec47  movaps [r15+0x150], xmm12
00007ec68bfdec4f  movq xmm11, xmm11
00007ec68bfdec54  vmovaps [rsp+0x40], xmm11
00007ec68bfdec5a  movq xmm11, xmm11
00007ec68bfdec5f  movaps [r15+0x140], xmm11
00007ec68bfdec67  lea r14, [rax+0x10]
00007ec68bfdec6b  mov r12, [r13+r14*1]
00007ec68bfdec70  lea r14, [rax+0x18]
00007ec68bfdec74  mov r11, [r13+r14*1]
00007ec68bfdec79  movq xmm12, r12
00007ec68bfdec7e  movq xmm11, r11
00007ec68bfdec83  movq xmm12, xmm12
00007ec68bfdec88  vmovaps [rsp+0x50], xmm12
00007ec68bfdec8e  movq xmm12, xmm12
00007ec68bfdec93  movaps [r15+0x170], xmm12
00007ec68bfdec9b  movq xmm11, xmm11
00007ec68bfdeca0  vmovaps [rsp+0x60], xmm11
00007ec68bfdeca6  movq xmm11, xmm11
00007ec68bfdecab  movaps [r15+0x160], xmm11
00007ec68bfdecb3  mov r14, [r13+rax*1]
00007ec68bfdecb8  vmovq xmm12, r14
00007ec68bfdecbd  vpbroadcastq xmm12, xmm12
00007ec68bfdecc2  lea r14, [rax+0x08]
00007ec68bfdecc6  mov rax, [r13+r14*1]
00007ec68bfdeccb  movq xmm11, rax
00007ec68bfdecd0  movaps [r15+0x230], xmm11
00007ec68bfdecd8  mov rax, [r15+0xF8]
00007ec68bfdecdf  lea r14, [rax+0x50]
00007ec68bfdece3  movups xmm11, [r13+r14*1]
00007ec68bfdece9  lea r14, [rax+0x60]
00007ec68bfdeced  movups xmm10, [r13+r14*1]
00007ec68bfdecf3  lea r14, [rax+0x30]
00007ec68bfdecf7  movups xmm9, [r13+r14*1]
00007ec68bfdecfd  mov r14, [r15+0x50]
00007ec68bfded01  mov [r15+0x60], r14
00007ec68bfded05  mov qword ptr [r15+0x58], 0x40
00007ec68bfded0d  movaps xmm8, xmm12
00007ec68bfded11  mulpd xmm8, xmm15
00007ec68bfded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007ec68bfded1c  ptest xmm7, xmm7
00007ec68bfded21  jnz 0x00007EC68BFDFB4A
00007ec68bfded27  movq xmm15, qword ptr [r15+0x230]
00007ec68bfded30  vmovaps [rsp+0x70], xmm15
00007ec68bfded36  vpermilpd xmm15, xmm15, 0x00
00007ec68bfded3c  movaps xmm7, xmm9
00007ec68bfded40  mulpd xmm7, xmm15
00007ec68bfded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007ec68bfded4a  ptest xmm6, xmm6
00007ec68bfded4f  jnz 0x00007EC68BFDFC8E
00007ec68bfded55  vxorps xmm15, xmm15, xmm15
00007ec68bfded5a  vpbroadcastq xmm15, xmm15
00007ec68bfded5f  movaps xmm9, xmm12
00007ec68bfded63  mulpd xmm9, xmm10
00007ec68bfded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007ec68bfded6e  ptest xmm6, xmm6
00007ec68bfded73  jnz 0x00007EC68BFDFDD0
00007ec68bfded79  movaps xmm10, xmm12
00007ec68bfded7d  mulpd xmm10, xmm11
00007ec68bfded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007ec68bfded88  ptest xmm6, xmm6
00007ec68bfded8d  jnz 0x00007EC68BFDFF14
00007ec68bfded93  movaps xmm11, [r15+0x1F0]
00007ec68bfded9b  movaps xmm6, xmm12
00007ec68bfded9f  mulpd xmm6, xmm11
00007ec68bfdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007ec68bfdeda9  ptest xmm5, xmm5
00007ec68bfdedae  jnz 0x00007EC68BFE0058
00007ec68bfdedb4  movaps xmm12, [r15+0x2A0]
00007ec68bfdedbc  vmovaps [rsp+0x80], xmm12
00007ec68bfdedc5  vmovaps xmm11, [rsp+0x80]
00007ec68bfdedce  por xmm12, xmm11
00007ec68bfdedd3  movaps xmm11, [r15+0x250]
00007ec68bfdeddb  vmovaps [rsp+0x80], xmm11
00007ec68bfdede4  vmovaps xmm5, [rsp+0x80]
00007ec68bfdeded  por xmm11, xmm5
00007ec68bfdedf2  vmovaps xmm4, [rsp+0x70]
00007ec68bfdedf8  vpermilpd xmm4, xmm4, 0x00
00007ec68bfdedfe  movaps xmm3, xmm5
00007ec68bfdee01  mulpd xmm3, xmm4
00007ec68bfdee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007ec68bfdee0a  ptest xmm2, xmm2
00007ec68bfdee0f  jnz 0x00007EC68BFE019A
00007ec68bfdee15  mov [rsp+0x80], rax
00007ec68bfdee1d  xor eax, eax
00007ec68bfdee1f  mov r12d, 0x40
00007ec68bfdee25  mov r11d, 0x200
00007ec68bfdee2b  cmp r12, r11
00007ec68bfdee2e  cmc
00007ec68bfdee2f  lahf
00007ec68bfdee30  seto al
00007ec68bfdee33  mov [r15+0x108], eax
00007ec68bfdee3a  movaps xmm5, xmm8
00007ec68bfdee3e  addpd xmm5, xmm15
00007ec68bfdee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007ec68bfdee48  ptest xmm4, xmm4
00007ec68bfdee4d  jnz 0x00007EC68BFE02DA
00007ec68bfdee53  movaps xmm8, [r15+0x1B0]
00007ec68bfdee5b  movaps xmm4, xmm9
00007ec68bfdee5f  addpd xmm4, xmm8
00007ec68bfdee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007ec68bfdee69  ptest xmm2, xmm2
00007ec68bfdee6e  jnz 0x00007EC68BFE041C
00007ec68bfdee74  movaps xmm9, xmm10
00007ec68bfdee78  addpd xmm9, xmm8
00007ec68bfdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007ec68bfdee83  ptest xmm2, xmm2
00007ec68bfdee88  jnz 0x00007EC68BFE055E
00007ec68bfdee8e  movaps xmm10, [r15+0x2F0]
00007ec68bfdee96  vmovaps [rsp+0x90], xmm10
00007ec68bfdee9f  vmovaps xmm8, [rsp+0x90]
00007ec68bfdeea8  por xmm10, xmm8
00007ec68bfdeead  movaps xmm8, [r15+0x2E0]
00007ec68bfdeeb5  vmovaps [rsp+0x90], xmm8
00007ec68bfdeebe  vmovaps xmm2, [rsp+0x90]
00007ec68bfdeec7  por xmm8, xmm2
00007ec68bfdeecc  movaps xmm2, [r15+0x2D0]
00007ec68bfdeed4  vmovaps [rsp+0x90], xmm2
00007ec68bfdeedd  vmovaps [rsp+0xA0], xmm1
00007ec68bfdeee6  vmovaps xmm1, [rsp+0x90]
00007ec68bfdeeef  por xmm2, xmm1
00007ec68bfdeef3  movaps xmm1, [r15+0x200]
00007ec68bfdeefb  vmovaps [rsp+0x90], xmm1
00007ec68bfdef04  vmovaps [rsp+0xB0], xmm15
00007ec68bfdef0d  vmovaps xmm15, [rsp+0x90]
00007ec68bfdef16  por xmm1, xmm15
00007ec68bfdef1b  movaps xmm15, [r15+0x1C0]
00007ec68bfdef23  vmovaps [rsp+0x90], xmm15
00007ec68bfdef2c  vmovaps [rsp+0xC0], xmm1
00007ec68bfdef35  vmovaps xmm1, [rsp+0x90]
00007ec68bfdef3e  por xmm15, xmm1
00007ec68bfdef43  movaps xmm1, [r15+0x190]
00007ec68bfdef4b  vmovaps [rsp+0x90], xmm1
00007ec68bfdef54  vmovaps [rsp+0xD0], xmm15
00007ec68bfdef5d  vmovaps xmm15, [rsp+0x90]
00007ec68bfdef66  por xmm1, xmm15
00007ec68bfdef6b  movaps xmm15, [r15+0x300]
00007ec68bfdef73  vmovaps [rsp+0x90], xmm15
00007ec68bfdef7c  vmovaps [rsp+0xE0], xmm1
00007ec68bfdef85  vmovaps xmm1, [rsp+0x90]
00007ec68bfdef8e  por xmm15, xmm1
00007ec68bfdef93  mov rax, [rsp+0x80]
00007ec68bfdef9b  lea r12, [rax+0xA0]
00007ec68bfdefa2  movups xmm1, [r13+r12*1]
00007ec68bfdefa8  lea r12, [rax+0xB0]
00007ec68bfdefaf  vmovaps [rsp+0x80], xmm1
00007ec68bfdefb8  movups xmm1, [r13+r12*1]
00007ec68bfdefbe  vmovaps [rsp+0x90], xmm1
00007ec68bfdefc7  vmovaps [rsp+0xF0], xmm15
00007ec68bfdefd0  vmovaps xmm15, [rsp+0xB0]
00007ec68bfdefd9  vmovaps [rsp+0xB0], xmm14
00007ec68bfdefe2  movaps xmm1, xmm6
00007ec68bfdefe5  addpd xmm1, xmm15
00007ec68bfdefea  vcmppd xmm14, xmm1, xmm1, 0x03
00007ec68bfdefef  ptest xmm14, xmm14
00007ec68bfdeff5  jnz 0x00007EC68BFE06B6
00007ec68bfdeffb  lea r12, [rax+0xF0]
00007ec68bfdf002  movups xmm15, [r13+r12*1]
00007ec68bfdf008  movaps xmm14, xmm4
00007ec68bfdf00c  addpd xmm14, xmm3
00007ec68bfdf011  vcmppd xmm6, xmm14, xmm14, 0x03
00007ec68bfdf017  ptest xmm6, xmm6
00007ec68bfdf01c  jnz 0x00007EC68BFE0801
00007ec68bfdf022  movaps xmm6, xmm9
00007ec68bfdf026  addpd xmm6, xmm7
00007ec68bfdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007ec68bfdf02f  ptest xmm4, xmm4
00007ec68bfdf034  jnz 0x00007EC68BFE0943
00007ec68bfdf03a  vmovaps xmm9, [rsp+0x70]
00007ec68bfdf040  vpermilpd xmm9, xmm9, 0x00
00007ec68bfdf046  vmovaps xmm4, [rsp+0x90]
00007ec68bfdf04f  movaps xmm7, xmm4
00007ec68bfdf052  mulpd xmm7, xmm9
00007ec68bfdf057  vcmppd xmm3, xmm7, xmm7, 0x03
00007ec68bfdf05c  ptest xmm3, xmm3
00007ec68bfdf061  jnz 0x00007EC68BFE0A84
00007ec68bfdf067  vmovaps xmm9, [rsp+0x50]
00007ec68bfdf06d  vpermilpd xmm9, xmm9, 0x00
00007ec68bfdf073  movaps xmm4, xmm15
00007ec68bfdf077  mulpd xmm4, xmm9
00007ec68bfdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007ec68bfdf081  ptest xmm3, xmm3
00007ec68bfdf086  jnz 0x00007EC68BFE0BC5
00007ec68bfdf08c  lea r12, [rax+0xE0]
00007ec68bfdf093  movups xmm15, [r13+r12*1]
00007ec68bfdf099  vmovaps xmm9, [rsp+0x70]
00007ec68bfdf09f  vpermilpd xmm9, xmm9, 0x00
00007ec68bfdf0a5  vmovaps [rsp+0x70], xmm1
00007ec68bfdf0ab  vmovaps xmm1, [rsp+0x80]
00007ec68bfdf0b4  vmovaps [rsp+0x80], xmm15
00007ec68bfdf0bd  movaps xmm3, xmm1
00007ec68bfdf0c0  mulpd xmm3, xmm9
00007ec68bfdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007ec68bfdf0ca  ptest xmm15, xmm15
00007ec68bfdf0d0  jnz 0x00007EC68BFE0D11
00007ec68bfdf0d6  vmovaps xmm1, [rsp+0xF0]
00007ec68bfdf0df  vmovaps xmm15, [rsp+0xF0]
00007ec68bfdf0e8  por xmm1, xmm15
00007ec68bfdf0ed  movaps [r15+0x300], xmm1
00007ec68bfdf0f5  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdf0fe  vmovaps xmm9, [rsp+0xE0]
00007ec68bfdf107  por xmm15, xmm9
00007ec68bfdf10c  movaps [r15+0x190], xmm15
00007ec68bfdf114  vmovaps xmm9, [rsp+0x50]
00007ec68bfdf11a  vpermilpd xmm9, xmm9, 0x00
00007ec68bfdf120  vmovaps [rsp+0x90], xmm1
00007ec68bfdf129  vmovaps [rsp+0xE0], xmm15
00007ec68bfdf132  vmovaps xmm15, [rsp+0x80]
00007ec68bfdf13b  vmovaps [rsp+0x80], xmm14
00007ec68bfdf144  movaps xmm1, xmm15
00007ec68bfdf148  mulpd xmm1, xmm9
00007ec68bfdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007ec68bfdf152  ptest xmm14, xmm14
00007ec68bfdf158  jnz 0x00007EC68BFE0E52
00007ec68bfdf15e  lea r12, [rax+0x90]
00007ec68bfdf165  movups xmm15, [r13+r12*1]
00007ec68bfdf16b  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdf174  vmovaps xmm9, [rsp+0xD0]
00007ec68bfdf17d  por xmm14, xmm9
00007ec68bfdf182  movaps [r15+0x1C0], xmm14
00007ec68bfdf18a  vmovaps xmm9, [rsp+0xC0]
00007ec68bfdf193  vmovaps [rsp+0xD0], xmm1
00007ec68bfdf19c  vmovaps xmm1, [rsp+0xC0]
00007ec68bfdf1a5  por xmm9, xmm1
00007ec68bfdf1aa  movaps [r15+0x200], xmm9
00007ec68bfdf1b2  vmovaps [rsp+0xC0], xmm2
00007ec68bfdf1bb  vmovaps xmm1, [rsp+0xC0]
00007ec68bfdf1c4  por xmm2, xmm1
00007ec68bfdf1c8  movaps [r15+0x2D0], xmm2
00007ec68bfdf1d0  vmovaps [rsp+0xC0], xmm8
00007ec68bfdf1d9  vmovaps xmm1, [rsp+0xC0]
00007ec68bfdf1e2  por xmm8, xmm1
00007ec68bfdf1e7  movaps [r15+0x2E0], xmm8
00007ec68bfdf1ef  vmovaps [rsp+0xC0], xmm15
00007ec68bfdf1f8  movaps xmm1, xmm5
00007ec68bfdf1fb  addpd xmm1, xmm7
00007ec68bfdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007ec68bfdf204  ptest xmm15, xmm15
00007ec68bfdf20a  jnz 0x00007EC68BFE0F9E
00007ec68bfdf210  vmovaps xmm15, [rsp+0x50]
00007ec68bfdf216  vpermilpd xmm15, xmm15, 0x00
00007ec68bfdf21c  vmovaps xmm5, [rsp+0xC0]
00007ec68bfdf225  vmovaps [rsp+0xC0], xmm1
00007ec68bfdf22e  movaps xmm7, xmm5
00007ec68bfdf231  mulpd xmm7, xmm15
00007ec68bfdf236  vcmppd xmm1, xmm7, xmm7, 0x03
00007ec68bfdf23b  ptest xmm1, xmm1
00007ec68bfdf240  jnz 0x00007EC68BFE10DE
00007ec68bfdf246  lea r12, [rax+0x80]
00007ec68bfdf24d  movups xmm1, [r13+r12*1]
00007ec68bfdf253  vmovaps xmm5, [rsp+0x70]
00007ec68bfdf259  vmovaps [rsp+0x70], xmm1
00007ec68bfdf25f  movaps xmm15, xmm5
00007ec68bfdf263  addpd xmm15, xmm3
00007ec68bfdf268  vcmppd xmm1, xmm15, xmm15, 0x03
00007ec68bfdf26e  ptest xmm1, xmm1
00007ec68bfdf273  jnz 0x00007EC68BFE1229
00007ec68bfdf279  vmovaps xmm5, [rsp+0x80]
00007ec68bfdf282  movaps xmm1, xmm5
00007ec68bfdf285  addpd xmm1, xmm4
00007ec68bfdf289  vcmppd xmm3, xmm1, xmm1, 0x03
00007ec68bfdf28e  ptest xmm3, xmm3
00007ec68bfdf293  jnz 0x00007EC68BFE136B
00007ec68bfdf299  vmovaps [rsp+0x80], xmm10
00007ec68bfdf2a2  vmovaps xmm5, [rsp+0x80]
00007ec68bfdf2ab  por xmm10, xmm5
00007ec68bfdf2b0  movaps [r15+0x2F0], xmm10
00007ec68bfdf2b8  vmovaps xmm5, [rsp+0x50]
00007ec68bfdf2be  vpermilpd xmm5, xmm5, 0x00
00007ec68bfdf2c4  vmovaps xmm3, [rsp+0x70]
00007ec68bfdf2ca  vmovaps [rsp+0x50], xmm1
00007ec68bfdf2d0  movaps xmm4, xmm3
00007ec68bfdf2d3  mulpd xmm4, xmm5
00007ec68bfdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007ec68bfdf2dc  ptest xmm1, xmm1
00007ec68bfdf2e1  jnz 0x00007EC68BFE14AB
00007ec68bfdf2e7  lea r12, [rax+0xD0]
00007ec68bfdf2ee  movups xmm1, [r13+r12*1]
00007ec68bfdf2f4  vmovaps xmm3, [rsp+0xD0]
00007ec68bfdf2fd  vmovaps [rsp+0x70], xmm1
00007ec68bfdf303  movaps xmm5, xmm6
00007ec68bfdf306  addpd xmm5, xmm3
00007ec68bfdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007ec68bfdf30f  ptest xmm1, xmm1
00007ec68bfdf314  jnz 0x00007EC68BFE15F5
00007ec68bfdf31a  vmovaps xmm1, [rsp+0x60]
00007ec68bfdf320  vpermilpd xmm1, xmm1, 0x00
00007ec68bfdf326  movaps xmm6, xmm9
00007ec68bfdf32a  mulpd xmm6, xmm1
00007ec68bfdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007ec68bfdf333  ptest xmm3, xmm3
00007ec68bfdf338  jnz 0x00007EC68BFE1735
00007ec68bfdf33e  movaps [r15+0x260], xmm6
00007ec68bfdf346  vxorps xmm1, xmm1, xmm1
00007ec68bfdf34a  vpbroadcastq xmm1, xmm1
00007ec68bfdf34f  movaps [r15+0x1B0], xmm1
00007ec68bfdf357  vmovaps xmm1, [rsp+0x60]
00007ec68bfdf35d  vpermilpd xmm1, xmm1, 0x00
00007ec68bfdf363  vmovaps xmm3, [rsp+0x70]
00007ec68bfdf369  vmovaps [rsp+0x70], xmm15
00007ec68bfdf36f  movaps xmm9, xmm3
00007ec68bfdf373  mulpd xmm9, xmm1
00007ec68bfdf378  vcmppd xmm15, xmm9, xmm9, 0x03
00007ec68bfdf37e  ptest xmm15, xmm15
00007ec68bfdf384  jnz 0x00007EC68BFE1876
00007ec68bfdf38a  lea r12, [rax+0xC0]
00007ec68bfdf391  movups xmm1, [r13+r12*1]
00007ec68bfdf397  vmovaps xmm3, [rsp+0xC0]
00007ec68bfdf3a0  vmovaps [rsp+0x80], xmm1
00007ec68bfdf3a9  movaps xmm15, xmm3
00007ec68bfdf3ad  addpd xmm15, xmm7
00007ec68bfdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007ec68bfdf3b8  ptest xmm1, xmm1
00007ec68bfdf3bd  jnz 0x00007EC68BFE19C2
00007ec68bfdf3c3  vmovaps [rsp+0xC0], xmm13
00007ec68bfdf3cc  vmovaps xmm1, [rsp+0xC0]
00007ec68bfdf3d5  por xmm13, xmm1
00007ec68bfdf3da  movaps [r15+0x270], xmm13
00007ec68bfdf3e2  vmovaps xmm1, [rsp+0xB0]
00007ec68bfdf3eb  vmovaps xmm7, [rsp+0xB0]
00007ec68bfdf3f4  por xmm1, xmm7
00007ec68bfdf3f8  movaps [r15+0x1A0], xmm1
00007ec68bfdf400  vmovaps xmm1, [rsp+0x60]
00007ec68bfdf406  vpermilpd xmm1, xmm1, 0x00
00007ec68bfdf40c  vmovaps [rsp+0xB0], xmm1
00007ec68bfdf415  vmovaps xmm1, [rsp+0x80]
00007ec68bfdf41e  vmovaps [rsp+0x80], xmm15
00007ec68bfdf427  vmovaps xmm15, [rsp+0xB0]
00007ec68bfdf430  vmovaps [rsp+0xB0], xmm14
00007ec68bfdf439  movaps xmm3, xmm1
00007ec68bfdf43c  mulpd xmm3, xmm15
00007ec68bfdf441  vcmppd xmm14, xmm3, xmm3, 0x03
00007ec68bfdf446  ptest xmm14, xmm14
00007ec68bfdf44c  jnz 0x00007EC68BFE1B04
00007ec68bfdf452  lea r12, [rax+0x20]
00007ec68bfdf456  movups xmm1, [r13+r12*1]
00007ec68bfdf45c  movaps [r15+0x110], xmm1
00007ec68bfdf464  vmovaps xmm14, [rsp+0x70]
00007ec68bfdf46a  vmovaps [rsp+0x70], xmm1
00007ec68bfdf470  movaps xmm15, xmm14
00007ec68bfdf474  addpd xmm15, xmm4
00007ec68bfdf479  vcmppd xmm1, xmm15, xmm15, 0x03
00007ec68bfdf47f  ptest xmm1, xmm1
00007ec68bfdf484  jnz 0x00007EC68BFE1C4F
00007ec68bfdf48a  vmovaps xmm1, [rsp+0x60]
00007ec68bfdf490  vpermilpd xmm1, xmm1, 0x00
00007ec68bfdf496  movaps xmm14, xmm2
00007ec68bfdf49a  mulpd xmm14, xmm1
00007ec68bfdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007ec68bfdf4a5  ptest xmm4, xmm4
00007ec68bfdf4aa  jnz 0x00007EC68BFE1D92
00007ec68bfdf4b0  vmovaps xmm4, [rsp+0x50]
00007ec68bfdf4b6  movaps xmm1, xmm4
00007ec68bfdf4b9  addpd xmm1, xmm9
00007ec68bfdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007ec68bfdf4c3  ptest xmm2, xmm2
00007ec68bfdf4c8  jnz 0x00007EC68BFE1ED4
00007ec68bfdf4ce  vmovaps xmm9, [rsp+0x30]
00007ec68bfdf4d4  vpermilpd xmm9, xmm9, 0x00
00007ec68bfdf4da  vmovaps xmm2, [rsp+0x70]
00007ec68bfdf4e0  vmovaps [rsp+0x50], xmm1
00007ec68bfdf4e6  movaps xmm4, xmm2
00007ec68bfdf4e9  mulpd xmm4, xmm9
00007ec68bfdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007ec68bfdf4f3  ptest xmm1, xmm1
00007ec68bfdf4f8  jnz 0x00007EC68BFE2015
00007ec68bfdf4fe  vmovaps xmm1, [rsp+0x30]
00007ec68bfdf504  vpermilpd xmm1, xmm1, 0x00
00007ec68bfdf50a  vmovaps xmm2, [rsp+0x90]
00007ec68bfdf513  vmovaps [rsp+0x60], xmm15
00007ec68bfdf519  movaps xmm9, xmm2
00007ec68bfdf51d  mulpd xmm9, xmm1
00007ec68bfdf522  vcmppd xmm15, xmm9, xmm9, 0x03
00007ec68bfdf528  ptest xmm15, xmm15
00007ec68bfdf52e  jnz 0x00007EC68BFE2156
00007ec68bfdf534  vmovaps xmm15, [rsp+0x80]
00007ec68bfdf53d  movaps xmm1, xmm15
00007ec68bfdf541  addpd xmm1, xmm6
00007ec68bfdf545  vcmppd xmm2, xmm1, xmm1, 0x03
00007ec68bfdf54a  ptest xmm2, xmm2
00007ec68bfdf54f  jnz 0x00007EC68BFE2298
00007ec68bfdf555  movaps xmm15, xmm5
00007ec68bfdf559  addpd xmm15, xmm3
00007ec68bfdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007ec68bfdf564  ptest xmm6, xmm6
00007ec68bfdf569  jnz 0x00007EC68BFE23D9
00007ec68bfdf56f  vmovaps xmm6, [rsp+0x30]
00007ec68bfdf575  vpermilpd xmm6, xmm6, 0x00
00007ec68bfdf57b  movaps xmm5, xmm8
00007ec68bfdf57f  mulpd xmm5, xmm6
00007ec68bfdf583  vcmppd xmm3, xmm5, xmm5, 0x03
00007ec68bfdf588  ptest xmm3, xmm3
00007ec68bfdf58d  jnz 0x00007EC68BFE251B
00007ec68bfdf593  vmovaps xmm8, [rsp+0x30]
00007ec68bfdf599  vpermilpd xmm8, xmm8, 0x00
00007ec68bfdf59f  movaps xmm6, xmm10
00007ec68bfdf5a3  mulpd xmm6, xmm8
00007ec68bfdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007ec68bfdf5ad  ptest xmm3, xmm3
00007ec68bfdf5b2  jnz 0x00007EC68BFE265C
00007ec68bfdf5b8  vmovaps xmm8, [rsp+0x60]
00007ec68bfdf5be  movaps xmm10, xmm8
00007ec68bfdf5c2  addpd xmm10, xmm14
00007ec68bfdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007ec68bfdf5cd  ptest xmm3, xmm3
00007ec68bfdf5d2  jnz 0x00007EC68BFE279E
00007ec68bfdf5d8  vmovaps xmm8, [rsp+0x50]
00007ec68bfdf5de  movaps xmm14, xmm8
00007ec68bfdf5e2  addpd xmm14, xmm4
00007ec68bfdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007ec68bfdf5ed  ptest xmm3, xmm3
00007ec68bfdf5f2  jnz 0x00007EC68BFE28E2
00007ec68bfdf5f8  vmovaps xmm8, [rsp+0x40]
00007ec68bfdf5fe  vpermilpd xmm8, xmm8, 0x00
00007ec68bfdf604  movaps xmm4, xmm13
00007ec68bfdf608  mulpd xmm4, xmm8
00007ec68bfdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007ec68bfdf612  ptest xmm3, xmm3
00007ec68bfdf617  jnz 0x00007EC68BFE2A25
00007ec68bfdf61d  movaps xmm13, xmm15
00007ec68bfdf621  addpd xmm13, xmm9
00007ec68bfdf626  vcmppd xmm8, xmm13, xmm13, 0x03
00007ec68bfdf62c  ptest xmm8, xmm8
00007ec68bfdf632  jnz 0x00007EC68BFE2B67
00007ec68bfdf638  movaps xmm15, xmm1
00007ec68bfdf63c  addpd xmm15, xmm5
00007ec68bfdf641  vcmppd xmm9, xmm15, xmm15, 0x03
00007ec68bfdf647  ptest xmm9, xmm9
00007ec68bfdf64d  jnz 0x00007EC68BFE2CAB
00007ec68bfdf653  vmovaps [rsp+0x30], xmm11
00007ec68bfdf659  vmovaps xmm1, [rsp+0x30]
00007ec68bfdf65f  por xmm11, xmm1
00007ec68bfdf664  movaps [r15+0x250], xmm11
00007ec68bfdf66c  vmovaps [rsp+0x30], xmm12
00007ec68bfdf672  vmovaps xmm1, [rsp+0x30]
00007ec68bfdf678  por xmm12, xmm1
00007ec68bfdf67d  movaps [r15+0x2A0], xmm12
00007ec68bfdf685  vmovaps xmm1, [rsp+0xA0]
00007ec68bfdf68e  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdf697  por xmm1, xmm11
00007ec68bfdf69c  movaps [r15+0x1D0], xmm1
00007ec68bfdf6a4  lea r12, [rax+0x40]
00007ec68bfdf6a8  movups xmm1, [r13+r12*1]
00007ec68bfdf6ae  movaps [r15+0x2C0], xmm1
00007ec68bfdf6b6  vmovaps xmm11, [rsp+0x40]
00007ec68bfdf6bc  vpermilpd xmm11, xmm11, 0x00
00007ec68bfdf6c2  vmovaps xmm8, [rsp+0xE0]
00007ec68bfdf6cb  movaps xmm9, xmm8
00007ec68bfdf6cf  mulpd xmm9, xmm11
00007ec68bfdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007ec68bfdf6da  ptest xmm5, xmm5
00007ec68bfdf6df  jnz 0x00007EC68BFE2DF7
00007ec68bfdf6e5  movaps xmm11, xmm10
00007ec68bfdf6e9  addpd xmm11, xmm6
00007ec68bfdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007ec68bfdf6f4  ptest xmm8, xmm8
00007ec68bfdf6fa  jnz 0x00007EC68BFE2F3B
00007ec68bfdf700  movaps xmm10, xmm14
00007ec68bfdf704  addpd xmm10, xmm4
00007ec68bfdf709  vcmppd xmm8, xmm10, xmm10, 0x03
00007ec68bfdf70f  ptest xmm8, xmm8
00007ec68bfdf715  jnz 0x00007EC68BFE307E
00007ec68bfdf71b  vmovaps xmm14, [rsp+0x40]
00007ec68bfdf721  vpermilpd xmm14, xmm14, 0x00
00007ec68bfdf727  movaps xmm8, xmm1
00007ec68bfdf72b  mulpd xmm8, xmm14
00007ec68bfdf730  vcmppd xmm6, xmm8, xmm8, 0x03
00007ec68bfdf736  ptest xmm6, xmm6
00007ec68bfdf73b  jnz 0x00007EC68BFE31C1
00007ec68bfdf741  movaps xmm1, [r15+0x2B0]
00007ec68bfdf749  vmovaps xmm14, [rsp+0x40]
00007ec68bfdf74f  vpermilpd xmm14, xmm14, 0x00
00007ec68bfdf755  movaps xmm6, xmm1
00007ec68bfdf758  mulpd xmm6, xmm14
00007ec68bfdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007ec68bfdf762  ptest xmm5, xmm5
00007ec68bfdf767  jnz 0x00007EC68BFE3304
00007ec68bfdf76d  vmovaps xmm1, [rsp+0x10]
00007ec68bfdf773  vpermilpd xmm1, xmm1, 0x00
00007ec68bfdf779  movaps xmm14, xmm12
00007ec68bfdf77d  mulpd xmm14, xmm1
00007ec68bfdf782  vcmppd xmm5, xmm14, xmm14, 0x03
00007ec68bfdf788  ptest xmm5, xmm5
00007ec68bfdf78d  jnz 0x00007EC68BFE3445
00007ec68bfdf793  movaps xmm1, xmm13
00007ec68bfdf797  addpd xmm1, xmm9
00007ec68bfdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007ec68bfdf7a1  ptest xmm12, xmm12
00007ec68bfdf7a7  jnz 0x00007EC68BFE3588
00007ec68bfdf7ad  vmovaps xmm13, [rsp+0x10]
00007ec68bfdf7b3  vpermilpd xmm13, xmm13, 0x00
00007ec68bfdf7b9  movaps xmm12, xmm7
00007ec68bfdf7bd  mulpd xmm12, xmm13
00007ec68bfdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007ec68bfdf7c8  ptest xmm9, xmm9
00007ec68bfdf7ce  jnz 0x00007EC68BFE36CA
00007ec68bfdf7d4  movaps xmm13, xmm15
00007ec68bfdf7d8  addpd xmm13, xmm8
00007ec68bfdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007ec68bfdf7e3  ptest xmm9, xmm9
00007ec68bfdf7e9  jnz 0x00007EC68BFE380D
00007ec68bfdf7ef  movaps xmm15, [r15+0x290]
00007ec68bfdf7f7  vmovaps xmm9, [rsp+0x10]
00007ec68bfdf7fd  vpermilpd xmm9, xmm9, 0x00
00007ec68bfdf803  movaps xmm8, xmm15
00007ec68bfdf807  mulpd xmm8, xmm9
00007ec68bfdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007ec68bfdf812  ptest xmm7, xmm7
00007ec68bfdf817  jnz 0x00007EC68BFE3951
00007ec68bfdf81d  movaps xmm15, xmm11
00007ec68bfdf821  addpd xmm15, xmm6
00007ec68bfdf826  vcmppd xmm9, xmm15, xmm15, 0x03
00007ec68bfdf82c  ptest xmm9, xmm9
00007ec68bfdf832  jnz 0x00007EC68BFE3A95
00007ec68bfdf838  movaps xmm11, [r15+0x1E0]
00007ec68bfdf840  vmovaps xmm9, [rsp+0x10]
00007ec68bfdf846  vpermilpd xmm9, xmm9, 0x00
00007ec68bfdf84c  movaps xmm7, xmm11
00007ec68bfdf850  mulpd xmm7, xmm9
00007ec68bfdf855  vcmppd xmm6, xmm7, xmm7, 0x03
00007ec68bfdf85a  ptest xmm6, xmm6
00007ec68bfdf85f  jnz 0x00007EC68BFE3BD8
00007ec68bfdf865  movaps xmm11, xmm10
00007ec68bfdf869  addpd xmm11, xmm14
00007ec68bfdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007ec68bfdf874  ptest xmm9, xmm9
00007ec68bfdf87a  jnz 0x00007EC68BFE3D1A
00007ec68bfdf880  lea r12, [rax+0x70]
00007ec68bfdf884  movups xmm14, [r13+r12*1]
00007ec68bfdf88a  movaps [r15+0x240], xmm14
00007ec68bfdf892  movaps xmm10, xmm1
00007ec68bfdf896  addpd xmm10, xmm12
00007ec68bfdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007ec68bfdf8a1  ptest xmm9, xmm9
00007ec68bfdf8a7  jnz 0x00007EC68BFE3E68
00007ec68bfdf8ad  movaps [r15+0x170], xmm10
00007ec68bfdf8b5  vmovaps xmm1, [rsp+0x20]
00007ec68bfdf8bb  vpermilpd xmm1, xmm1, 0x00
00007ec68bfdf8c1  movaps xmm12, xmm14
00007ec68bfdf8c5  mulpd xmm12, xmm1
00007ec68bfdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007ec68bfdf8d0  ptest xmm9, xmm9
00007ec68bfdf8d6  jnz 0x00007EC68BFE3FAB
00007ec68bfdf8dc  vmovaps xmm1, [rsp+0x20]
00007ec68bfdf8e2  vpermilpd xmm1, xmm1, 0x00
00007ec68bfdf8e8  vmovaps xmm9, [rsp+0xB0]
00007ec68bfdf8f1  movaps xmm14, xmm9
00007ec68bfdf8f5  mulpd xmm14, xmm1
00007ec68bfdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007ec68bfdf900  ptest xmm6, xmm6
00007ec68bfdf905  jnz 0x00007EC68BFE40EE
00007ec68bfdf90b  movaps [r15+0x180], xmm14
00007ec68bfdf913  movaps xmm1, xmm13
00007ec68bfdf917  addpd xmm1, xmm8
00007ec68bfdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007ec68bfdf921  ptest xmm9, xmm9
00007ec68bfdf927  jnz 0x00007EC68BFE4231
00007ec68bfdf92d  movaps [r15+0x210], xmm1
00007ec68bfdf935  movups xmm13, [r13+rax*1]
00007ec68bfdf93b  lea r12, [rax+0x10]
00007ec68bfdf93f  movups xmm9, [r13+r12*1]
00007ec68bfdf945  movaps [r15+0x230], xmm9
00007ec68bfdf94d  movaps xmm8, xmm15
00007ec68bfdf951  addpd xmm8, xmm7
00007ec68bfdf956  vcmppd xmm6, xmm8, xmm8, 0x03
00007ec68bfdf95c  ptest xmm6, xmm6
00007ec68bfdf961  jnz 0x00007EC68BFE4387
00007ec68bfdf967  movaps [r15+0x130], xmm8
00007ec68bfdf96f  vmovaps xmm15, [rsp+0x20]
00007ec68bfdf975  vpermilpd xmm15, xmm15, 0x00
00007ec68bfdf97b  movaps xmm7, xmm9
00007ec68bfdf97f  mulpd xmm7, xmm15
00007ec68bfdf984  vcmppd xmm6, xmm7, xmm7, 0x03
00007ec68bfdf989  ptest xmm6, xmm6
00007ec68bfdf98e  jnz 0x00007EC68BFE44CA
00007ec68bfdf994  movaps [r15+0x220], xmm7
00007ec68bfdf99c  vmovaps xmm15, [rsp+0x20]
00007ec68bfdf9a2  vpermilpd xmm15, xmm15, 0x00
00007ec68bfdf9a8  movaps xmm9, xmm13
00007ec68bfdf9ac  mulpd xmm9, xmm15
00007ec68bfdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007ec68bfdf9b7  ptest xmm6, xmm6
00007ec68bfdf9bc  jnz 0x00007EC68BFE460C
00007ec68bfdf9c2  movaps xmm15, xmm11
00007ec68bfdf9c6  addpd xmm15, xmm12
00007ec68bfdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007ec68bfdf9d1  ptest xmm13, xmm13
00007ec68bfdf9d7  jnz 0x00007EC68BFE4750
00007ec68bfdf9dd  movaps [r15+0x140], xmm15
00007ec68bfdf9e5  movaps xmm13, xmm10
00007ec68bfdf9e9  addpd xmm13, xmm14
00007ec68bfdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007ec68bfdf9f4  ptest xmm12, xmm12
00007ec68bfdf9fa  jnz 0x00007EC68BFE4894
00007ec68bfdfa00  movaps [r15+0x150], xmm13
00007ec68bfdfa08  movaps xmm14, xmm1
00007ec68bfdfa0c  addpd xmm14, xmm7
00007ec68bfdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007ec68bfdfa17  ptest xmm12, xmm12
00007ec68bfdfa1d  jnz 0x00007EC68BFE49D8
00007ec68bfdfa23  movaps [r15+0x160], xmm14
00007ec68bfdfa2b  movaps xmm1, xmm8
00007ec68bfdfa2f  addpd xmm1, xmm9
00007ec68bfdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007ec68bfdfa39  ptest xmm12, xmm12
00007ec68bfdfa3f  jnz 0x00007EC68BFE4B1A
00007ec68bfdfa45  movaps [r15+0x120], xmm1
00007ec68bfdfa4d  movups [r13+r14*1], xmm15
00007ec68bfdfa53  lea rax, [r14+0x10]
00007ec68bfdfa57  movups [r13+rax*1], xmm13
00007ec68bfdfa5d  lea rax, [r14+0x20]
00007ec68bfdfa61  movups [r13+rax*1], xmm14
00007ec68bfdfa67  lea rax, [r14+0x30]
00007ec68bfdfa6b  movups [r13+rax*1], xmm1
00007ec68bfdfa71  mov eax, [r15+0x108]
00007ec68bfdfa78  sahf
00007ec68bfdfa79  jnz 0x00007EC68BFDFAAB
00007ec68bfdfa7b  cmp dword ptr [r15+0x318], 0x00
00007ec68bfdfa83  jz 0x00007EC68BFDEAE0
00007ec68bfdfa89  nop [rax+rax*1], ax
00007ec68bfdfa92  nop [rax+rax*1], eax
00007ec68bfdfa9a  mov eax, 0x4106D0
00007ec68bfdfa9f  mov [r15+0x100], rax
00007ec68bfdfaa6  jmp 0x00007EC68BDFE110
00007ec68bfdfaab  cmp dword ptr [r15+0x318], 0x00
00007ec68bfdfab3  jz 0x00007EC68BFD89C0
00007ec68bfdfab9  nop [rax+rax*1], ax
00007ec68bfdfac2  nop [rax+rax*1], eax
00007ec68bfdfaca  mov eax, 0x410504
00007ec68bfdfacf  mov [r15+0x100], rax
00007ec68bfdfad6  jmp 0x00007EC68BDFE110
00007ec68bfdfadb  int3
00007ec68bfdfadc  call 0x00007EC68BEE27E0
00007ec68bfdfae1  jmp 0x00007EC68BFDEBBF
00007ec68bfdfae6  call 0x00007EC68BEE1570
00007ec68bfdfaeb  jmp 0x00007EC68BFDEBC8
00007ec68bfdfaf0  call 0x00007EC68BEE27E0
00007ec68bfdfaf5  jmp 0x00007EC68BFDEC24
00007ec68bfdfafa  call 0x00007EC68BEE1570
00007ec68bfdfaff  jmp 0x00007EC68BFDEC2D
00007ec68bfdfb04  call 0x00007EC68BEE27E0
00007ec68bfdfb09  jmp 0x00007EC68BFDEC70
00007ec68bfdfb0e  call 0x00007EC68BEE1570
00007ec68bfdfb13  jmp 0x00007EC68BFDEC79
00007ec68bfdfb18  call 0x00007EC68BE0DC20
00007ec68bfdfb1d  jmp 0x00007EC68BFDECB8
00007ec68bfdfb22  call 0x00007EC68BED59C0
00007ec68bfdfb27  jmp 0x00007EC68BFDECCB
00007ec68bfdfb2c  call 0x00007EC68BEE0E30
00007ec68bfdfb31  jmp 0x00007EC68BFDECE9
00007ec68bfdfb36  call 0x00007EC68BEDFBC0
00007ec68bfdfb3b  jmp 0x00007EC68BFDECF3
00007ec68bfdfb40  call 0x00007EC68BEDE950
00007ec68bfdfb45  jmp 0x00007EC68BFDECFD
00007ec68bfdfb4a  sub rsp, 0x08
00007ec68bfdfb4e  push rax
00007ec68bfdfb4f  push rcx
00007ec68bfdfb50  push rdx
00007ec68bfdfb51  push rdi
00007ec68bfdfb52  push rsi
00007ec68bfdfb53  push r8
00007ec68bfdfb55  push r9
00007ec68bfdfb57  push r10
00007ec68bfdfb59  push r11
00007ec68bfdfb5b  sub rsp, 0xF0
00007ec68bfdfb62  vmovaps [rsp], xmm0
00007ec68bfdfb67  vmovaps [rsp+0x10], xmm1
00007ec68bfdfb6d  vmovaps [rsp+0x20], xmm2
00007ec68bfdfb73  vmovaps [rsp+0x30], xmm3
00007ec68bfdfb79  vmovaps [rsp+0x40], xmm4
00007ec68bfdfb7f  vmovaps [rsp+0x50], xmm5
00007ec68bfdfb85  vmovaps [rsp+0x60], xmm6
00007ec68bfdfb8b  vmovaps [rsp+0x70], xmm7
00007ec68bfdfb91  vmovaps [rsp+0x80], xmm9
00007ec68bfdfb9a  vmovaps [rsp+0x90], xmm10
00007ec68bfdfba3  vmovaps [rsp+0xA0], xmm11
00007ec68bfdfbac  vmovaps [rsp+0xB0], xmm12
00007ec68bfdfbb5  vmovaps [rsp+0xC0], xmm13
00007ec68bfdfbbe  vmovaps [rsp+0xD0], xmm14
00007ec68bfdfbc7  vmovaps [rsp+0xE0], xmm15
00007ec68bfdfbd0  sub rsp, 0x30
00007ec68bfdfbd4  movaps [rsp], xmm8
00007ec68bfdfbd9  movaps [rsp+0x10], xmm12
00007ec68bfdfbdf  movaps [rsp+0x20], xmm15
00007ec68bfdfbe5  lea rdi, [rsp]
00007ec68bfdfbe9  mov esi, 0x00
00007ec68bfdfbee  mov rax, 0x57D97DADF530
00007ec68bfdfbf8  call rax
00007ec68bfdfbfa  movaps xmm8, [rsp]
00007ec68bfdfbff  add rsp, 0x30
00007ec68bfdfc03  vmovaps xmm0, [rsp]
00007ec68bfdfc08  vmovaps xmm1, [rsp+0x10]
00007ec68bfdfc0e  vmovaps xmm2, [rsp+0x20]
00007ec68bfdfc14  vmovaps xmm3, [rsp+0x30]
00007ec68bfdfc1a  vmovaps xmm4, [rsp+0x40]
00007ec68bfdfc20  vmovaps xmm5, [rsp+0x50]
00007ec68bfdfc26  vmovaps xmm6, [rsp+0x60]
00007ec68bfdfc2c  vmovaps xmm7, [rsp+0x70]
00007ec68bfdfc32  vmovaps xmm9, [rsp+0x80]
00007ec68bfdfc3b  vmovaps xmm10, [rsp+0x90]
00007ec68bfdfc44  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdfc4d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdfc56  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdfc5f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdfc68  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdfc71  add rsp, 0xF0
00007ec68bfdfc78  pop r11
00007ec68bfdfc7a  pop r10
00007ec68bfdfc7c  pop r9
00007ec68bfdfc7e  pop r8
00007ec68bfdfc80  pop rsi
00007ec68bfdfc81  pop rdi
00007ec68bfdfc82  pop rdx
00007ec68bfdfc83  pop rcx
00007ec68bfdfc84  pop rax
00007ec68bfdfc85  add rsp, 0x08
00007ec68bfdfc89  jmp 0x00007EC68BFDED27
00007ec68bfdfc8e  sub rsp, 0x08
00007ec68bfdfc92  push rax
00007ec68bfdfc93  push rcx
00007ec68bfdfc94  push rdx
00007ec68bfdfc95  push rdi
00007ec68bfdfc96  push rsi
00007ec68bfdfc97  push r8
00007ec68bfdfc99  push r9
00007ec68bfdfc9b  push r10
00007ec68bfdfc9d  push r11
00007ec68bfdfc9f  sub rsp, 0xF0
00007ec68bfdfca6  vmovaps [rsp], xmm0
00007ec68bfdfcab  vmovaps [rsp+0x10], xmm1
00007ec68bfdfcb1  vmovaps [rsp+0x20], xmm2
00007ec68bfdfcb7  vmovaps [rsp+0x30], xmm3
00007ec68bfdfcbd  vmovaps [rsp+0x40], xmm4
00007ec68bfdfcc3  vmovaps [rsp+0x50], xmm5
00007ec68bfdfcc9  vmovaps [rsp+0x60], xmm6
00007ec68bfdfccf  vmovaps [rsp+0x70], xmm8
00007ec68bfdfcd5  vmovaps [rsp+0x80], xmm9
00007ec68bfdfcde  vmovaps [rsp+0x90], xmm10
00007ec68bfdfce7  vmovaps [rsp+0xA0], xmm11
00007ec68bfdfcf0  vmovaps [rsp+0xB0], xmm12
00007ec68bfdfcf9  vmovaps [rsp+0xC0], xmm13
00007ec68bfdfd02  vmovaps [rsp+0xD0], xmm14
00007ec68bfdfd0b  vmovaps [rsp+0xE0], xmm15
00007ec68bfdfd14  sub rsp, 0x30
00007ec68bfdfd18  movaps [rsp], xmm7
00007ec68bfdfd1c  movaps [rsp+0x10], xmm9
00007ec68bfdfd22  movaps [rsp+0x20], xmm15
00007ec68bfdfd28  lea rdi, [rsp]
00007ec68bfdfd2c  mov esi, 0x00
00007ec68bfdfd31  mov rax, 0x57D97DADF530
00007ec68bfdfd3b  call rax
00007ec68bfdfd3d  movaps xmm7, [rsp]
00007ec68bfdfd41  add rsp, 0x30
00007ec68bfdfd45  vmovaps xmm0, [rsp]
00007ec68bfdfd4a  vmovaps xmm1, [rsp+0x10]
00007ec68bfdfd50  vmovaps xmm2, [rsp+0x20]
00007ec68bfdfd56  vmovaps xmm3, [rsp+0x30]
00007ec68bfdfd5c  vmovaps xmm4, [rsp+0x40]
00007ec68bfdfd62  vmovaps xmm5, [rsp+0x50]
00007ec68bfdfd68  vmovaps xmm6, [rsp+0x60]
00007ec68bfdfd6e  vmovaps xmm8, [rsp+0x70]
00007ec68bfdfd74  vmovaps xmm9, [rsp+0x80]
00007ec68bfdfd7d  vmovaps xmm10, [rsp+0x90]
00007ec68bfdfd86  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdfd8f  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdfd98  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdfda1  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdfdaa  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdfdb3  add rsp, 0xF0
00007ec68bfdfdba  pop r11
00007ec68bfdfdbc  pop r10
00007ec68bfdfdbe  pop r9
00007ec68bfdfdc0  pop r8
00007ec68bfdfdc2  pop rsi
00007ec68bfdfdc3  pop rdi
00007ec68bfdfdc4  pop rdx
00007ec68bfdfdc5  pop rcx
00007ec68bfdfdc6  pop rax
00007ec68bfdfdc7  add rsp, 0x08
00007ec68bfdfdcb  jmp 0x00007EC68BFDED55
00007ec68bfdfdd0  sub rsp, 0x08
00007ec68bfdfdd4  push rax
00007ec68bfdfdd5  push rcx
00007ec68bfdfdd6  push rdx
00007ec68bfdfdd7  push rdi
00007ec68bfdfdd8  push rsi
00007ec68bfdfdd9  push r8
00007ec68bfdfddb  push r9
00007ec68bfdfddd  push r10
00007ec68bfdfddf  push r11
00007ec68bfdfde1  sub rsp, 0xF0
00007ec68bfdfde8  vmovaps [rsp], xmm0
00007ec68bfdfded  vmovaps [rsp+0x10], xmm1
00007ec68bfdfdf3  vmovaps [rsp+0x20], xmm2
00007ec68bfdfdf9  vmovaps [rsp+0x30], xmm3
00007ec68bfdfdff  vmovaps [rsp+0x40], xmm4
00007ec68bfdfe05  vmovaps [rsp+0x50], xmm5
00007ec68bfdfe0b  vmovaps [rsp+0x60], xmm6
00007ec68bfdfe11  vmovaps [rsp+0x70], xmm7
00007ec68bfdfe17  vmovaps [rsp+0x80], xmm8
00007ec68bfdfe20  vmovaps [rsp+0x90], xmm10
00007ec68bfdfe29  vmovaps [rsp+0xA0], xmm11
00007ec68bfdfe32  vmovaps [rsp+0xB0], xmm12
00007ec68bfdfe3b  vmovaps [rsp+0xC0], xmm13
00007ec68bfdfe44  vmovaps [rsp+0xD0], xmm14
00007ec68bfdfe4d  vmovaps [rsp+0xE0], xmm15
00007ec68bfdfe56  sub rsp, 0x30
00007ec68bfdfe5a  movaps [rsp], xmm9
00007ec68bfdfe5f  movaps [rsp+0x10], xmm12
00007ec68bfdfe65  movaps [rsp+0x20], xmm10
00007ec68bfdfe6b  lea rdi, [rsp]
00007ec68bfdfe6f  mov esi, 0x00
00007ec68bfdfe74  mov rax, 0x57D97DADF530
00007ec68bfdfe7e  call rax
00007ec68bfdfe80  movaps xmm9, [rsp]
00007ec68bfdfe85  add rsp, 0x30
00007ec68bfdfe89  vmovaps xmm0, [rsp]
00007ec68bfdfe8e  vmovaps xmm1, [rsp+0x10]
00007ec68bfdfe94  vmovaps xmm2, [rsp+0x20]
00007ec68bfdfe9a  vmovaps xmm3, [rsp+0x30]
00007ec68bfdfea0  vmovaps xmm4, [rsp+0x40]
00007ec68bfdfea6  vmovaps xmm5, [rsp+0x50]
00007ec68bfdfeac  vmovaps xmm6, [rsp+0x60]
00007ec68bfdfeb2  vmovaps xmm7, [rsp+0x70]
00007ec68bfdfeb8  vmovaps xmm8, [rsp+0x80]
00007ec68bfdfec1  vmovaps xmm10, [rsp+0x90]
00007ec68bfdfeca  vmovaps xmm11, [rsp+0xA0]
00007ec68bfdfed3  vmovaps xmm12, [rsp+0xB0]
00007ec68bfdfedc  vmovaps xmm13, [rsp+0xC0]
00007ec68bfdfee5  vmovaps xmm14, [rsp+0xD0]
00007ec68bfdfeee  vmovaps xmm15, [rsp+0xE0]
00007ec68bfdfef7  add rsp, 0xF0
00007ec68bfdfefe  pop r11
00007ec68bfdff00  pop r10
00007ec68bfdff02  pop r9
00007ec68bfdff04  pop r8
00007ec68bfdff06  pop rsi
00007ec68bfdff07  pop rdi
00007ec68bfdff08  pop rdx
00007ec68bfdff09  pop rcx
00007ec68bfdff0a  pop rax
00007ec68bfdff0b  add rsp, 0x08
00007ec68bfdff0f  jmp 0x00007EC68BFDED79
00007ec68bfdff14  sub rsp, 0x08
00007ec68bfdff18  push rax
00007ec68bfdff19  push rcx
00007ec68bfdff1a  push rdx
00007ec68bfdff1b  push rdi
00007ec68bfdff1c  push rsi
00007ec68bfdff1d  push r8
00007ec68bfdff1f  push r9
00007ec68bfdff21  push r10
00007ec68bfdff23  push r11
00007ec68bfdff25  sub rsp, 0xF0
00007ec68bfdff2c  vmovaps [rsp], xmm0
00007ec68bfdff31  vmovaps [rsp+0x10], xmm1
00007ec68bfdff37  vmovaps [rsp+0x20], xmm2
00007ec68bfdff3d  vmovaps [rsp+0x30], xmm3
00007ec68bfdff43  vmovaps [rsp+0x40], xmm4
00007ec68bfdff49  vmovaps [rsp+0x50], xmm5
00007ec68bfdff4f  vmovaps [rsp+0x60], xmm6
00007ec68bfdff55  vmovaps [rsp+0x70], xmm7
00007ec68bfdff5b  vmovaps [rsp+0x80], xmm8
00007ec68bfdff64  vmovaps [rsp+0x90], xmm9
00007ec68bfdff6d  vmovaps [rsp+0xA0], xmm11
00007ec68bfdff76  vmovaps [rsp+0xB0], xmm12
00007ec68bfdff7f  vmovaps [rsp+0xC0], xmm13
00007ec68bfdff88  vmovaps [rsp+0xD0], xmm14
00007ec68bfdff91  vmovaps [rsp+0xE0], xmm15
00007ec68bfdff9a  sub rsp, 0x30
00007ec68bfdff9e  movaps [rsp], xmm10
00007ec68bfdffa3  movaps [rsp+0x10], xmm12
00007ec68bfdffa9  movaps [rsp+0x20], xmm11
00007ec68bfdffaf  lea rdi, [rsp]
00007ec68bfdffb3  mov esi, 0x00
00007ec68bfdffb8  mov rax, 0x57D97DADF530
00007ec68bfdffc2  call rax
00007ec68bfdffc4  movaps xmm10, [rsp]
00007ec68bfdffc9  add rsp, 0x30
00007ec68bfdffcd  vmovaps xmm0, [rsp]
00007ec68bfdffd2  vmovaps xmm1, [rsp+0x10]
00007ec68bfdffd8  vmovaps xmm2, [rsp+0x20]
00007ec68bfdffde  vmovaps xmm3, [rsp+0x30]
00007ec68bfdffe4  vmovaps xmm4, [rsp+0x40]
00007ec68bfdffea  vmovaps xmm5, [rsp+0x50]
00007ec68bfdfff0  vmovaps xmm6, [rsp+0x60]
00007ec68bfdfff6  vmovaps xmm7, [rsp+0x70]
00007ec68bfdfffc  vmovaps xmm8, [rsp+0x80]
00007ec68bfe0005  vmovaps xmm9, [rsp+0x90]
00007ec68bfe000e  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0017  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe0020  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe0029  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe0032  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe003b  add rsp, 0xF0
00007ec68bfe0042  pop r11
00007ec68bfe0044  pop r10
00007ec68bfe0046  pop r9
00007ec68bfe0048  pop r8
00007ec68bfe004a  pop rsi
00007ec68bfe004b  pop rdi
00007ec68bfe004c  pop rdx
00007ec68bfe004d  pop rcx
00007ec68bfe004e  pop rax
00007ec68bfe004f  add rsp, 0x08
00007ec68bfe0053  jmp 0x00007EC68BFDED93
00007ec68bfe0058  sub rsp, 0x08
00007ec68bfe005c  push rax
00007ec68bfe005d  push rcx
00007ec68bfe005e  push rdx
00007ec68bfe005f  push rdi
00007ec68bfe0060  push rsi
00007ec68bfe0061  push r8
00007ec68bfe0063  push r9
00007ec68bfe0065  push r10
00007ec68bfe0067  push r11
00007ec68bfe0069  sub rsp, 0xF0
00007ec68bfe0070  vmovaps [rsp], xmm0
00007ec68bfe0075  vmovaps [rsp+0x10], xmm1
00007ec68bfe007b  vmovaps [rsp+0x20], xmm2
00007ec68bfe0081  vmovaps [rsp+0x30], xmm3
00007ec68bfe0087  vmovaps [rsp+0x40], xmm4
00007ec68bfe008d  vmovaps [rsp+0x50], xmm5
00007ec68bfe0093  vmovaps [rsp+0x60], xmm7
00007ec68bfe0099  vmovaps [rsp+0x70], xmm8
00007ec68bfe009f  vmovaps [rsp+0x80], xmm9
00007ec68bfe00a8  vmovaps [rsp+0x90], xmm10
00007ec68bfe00b1  vmovaps [rsp+0xA0], xmm11
00007ec68bfe00ba  vmovaps [rsp+0xB0], xmm12
00007ec68bfe00c3  vmovaps [rsp+0xC0], xmm13
00007ec68bfe00cc  vmovaps [rsp+0xD0], xmm14
00007ec68bfe00d5  vmovaps [rsp+0xE0], xmm15
00007ec68bfe00de  sub rsp, 0x30
00007ec68bfe00e2  movaps [rsp], xmm6
00007ec68bfe00e6  movaps [rsp+0x10], xmm12
00007ec68bfe00ec  movaps [rsp+0x20], xmm11
00007ec68bfe00f2  lea rdi, [rsp]
00007ec68bfe00f6  mov esi, 0x00
00007ec68bfe00fb  mov rax, 0x57D97DADF530
00007ec68bfe0105  call rax
00007ec68bfe0107  movaps xmm6, [rsp]
00007ec68bfe010b  add rsp, 0x30
00007ec68bfe010f  vmovaps xmm0, [rsp]
00007ec68bfe0114  vmovaps xmm1, [rsp+0x10]
00007ec68bfe011a  vmovaps xmm2, [rsp+0x20]
00007ec68bfe0120  vmovaps xmm3, [rsp+0x30]
00007ec68bfe0126  vmovaps xmm4, [rsp+0x40]
00007ec68bfe012c  vmovaps xmm5, [rsp+0x50]
00007ec68bfe0132  vmovaps xmm7, [rsp+0x60]
00007ec68bfe0138  vmovaps xmm8, [rsp+0x70]
00007ec68bfe013e  vmovaps xmm9, [rsp+0x80]
00007ec68bfe0147  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0150  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0159  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe0162  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe016b  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe0174  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe017d  add rsp, 0xF0
00007ec68bfe0184  pop r11
00007ec68bfe0186  pop r10
00007ec68bfe0188  pop r9
00007ec68bfe018a  pop r8
00007ec68bfe018c  pop rsi
00007ec68bfe018d  pop rdi
00007ec68bfe018e  pop rdx
00007ec68bfe018f  pop rcx
00007ec68bfe0190  pop rax
00007ec68bfe0191  add rsp, 0x08
00007ec68bfe0195  jmp 0x00007EC68BFDEDB4
00007ec68bfe019a  sub rsp, 0x08
00007ec68bfe019e  push rax
00007ec68bfe019f  push rcx
00007ec68bfe01a0  push rdx
00007ec68bfe01a1  push rdi
00007ec68bfe01a2  push rsi
00007ec68bfe01a3  push r8
00007ec68bfe01a5  push r9
00007ec68bfe01a7  push r10
00007ec68bfe01a9  push r11
00007ec68bfe01ab  sub rsp, 0xF0
00007ec68bfe01b2  vmovaps [rsp], xmm0
00007ec68bfe01b7  vmovaps [rsp+0x10], xmm1
00007ec68bfe01bd  vmovaps [rsp+0x20], xmm2
00007ec68bfe01c3  vmovaps [rsp+0x30], xmm4
00007ec68bfe01c9  vmovaps [rsp+0x40], xmm5
00007ec68bfe01cf  vmovaps [rsp+0x50], xmm6
00007ec68bfe01d5  vmovaps [rsp+0x60], xmm7
00007ec68bfe01db  vmovaps [rsp+0x70], xmm8
00007ec68bfe01e1  vmovaps [rsp+0x80], xmm9
00007ec68bfe01ea  vmovaps [rsp+0x90], xmm10
00007ec68bfe01f3  vmovaps [rsp+0xA0], xmm11
00007ec68bfe01fc  vmovaps [rsp+0xB0], xmm12
00007ec68bfe0205  vmovaps [rsp+0xC0], xmm13
00007ec68bfe020e  vmovaps [rsp+0xD0], xmm14
00007ec68bfe0217  vmovaps [rsp+0xE0], xmm15
00007ec68bfe0220  sub rsp, 0x30
00007ec68bfe0224  movaps [rsp], xmm3
00007ec68bfe0228  movaps [rsp+0x10], xmm5
00007ec68bfe022d  movaps [rsp+0x20], xmm4
00007ec68bfe0232  lea rdi, [rsp]
00007ec68bfe0236  mov esi, 0x00
00007ec68bfe023b  mov rax, 0x57D97DADF530
00007ec68bfe0245  call rax
00007ec68bfe0247  movaps xmm3, [rsp]
00007ec68bfe024b  add rsp, 0x30
00007ec68bfe024f  vmovaps xmm0, [rsp]
00007ec68bfe0254  vmovaps xmm1, [rsp+0x10]
00007ec68bfe025a  vmovaps xmm2, [rsp+0x20]
00007ec68bfe0260  vmovaps xmm4, [rsp+0x30]
00007ec68bfe0266  vmovaps xmm5, [rsp+0x40]
00007ec68bfe026c  vmovaps xmm6, [rsp+0x50]
00007ec68bfe0272  vmovaps xmm7, [rsp+0x60]
00007ec68bfe0278  vmovaps xmm8, [rsp+0x70]
00007ec68bfe027e  vmovaps xmm9, [rsp+0x80]
00007ec68bfe0287  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0290  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0299  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe02a2  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe02ab  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe02b4  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe02bd  add rsp, 0xF0
00007ec68bfe02c4  pop r11
00007ec68bfe02c6  pop r10
00007ec68bfe02c8  pop r9
00007ec68bfe02ca  pop r8
00007ec68bfe02cc  pop rsi
00007ec68bfe02cd  pop rdi
00007ec68bfe02ce  pop rdx
00007ec68bfe02cf  pop rcx
00007ec68bfe02d0  pop rax
00007ec68bfe02d1  add rsp, 0x08
00007ec68bfe02d5  jmp 0x00007EC68BFDEE15
00007ec68bfe02da  sub rsp, 0x08
00007ec68bfe02de  push rax
00007ec68bfe02df  push rcx
00007ec68bfe02e0  push rdx
00007ec68bfe02e1  push rdi
00007ec68bfe02e2  push rsi
00007ec68bfe02e3  push r8
00007ec68bfe02e5  push r9
00007ec68bfe02e7  push r10
00007ec68bfe02e9  push r11
00007ec68bfe02eb  sub rsp, 0xF0
00007ec68bfe02f2  vmovaps [rsp], xmm0
00007ec68bfe02f7  vmovaps [rsp+0x10], xmm1
00007ec68bfe02fd  vmovaps [rsp+0x20], xmm2
00007ec68bfe0303  vmovaps [rsp+0x30], xmm3
00007ec68bfe0309  vmovaps [rsp+0x40], xmm4
00007ec68bfe030f  vmovaps [rsp+0x50], xmm6
00007ec68bfe0315  vmovaps [rsp+0x60], xmm7
00007ec68bfe031b  vmovaps [rsp+0x70], xmm8
00007ec68bfe0321  vmovaps [rsp+0x80], xmm9
00007ec68bfe032a  vmovaps [rsp+0x90], xmm10
00007ec68bfe0333  vmovaps [rsp+0xA0], xmm11
00007ec68bfe033c  vmovaps [rsp+0xB0], xmm12
00007ec68bfe0345  vmovaps [rsp+0xC0], xmm13
00007ec68bfe034e  vmovaps [rsp+0xD0], xmm14
00007ec68bfe0357  vmovaps [rsp+0xE0], xmm15
00007ec68bfe0360  sub rsp, 0x30
00007ec68bfe0364  movaps [rsp], xmm5
00007ec68bfe0368  movaps [rsp+0x10], xmm8
00007ec68bfe036e  movaps [rsp+0x20], xmm15
00007ec68bfe0374  lea rdi, [rsp]
00007ec68bfe0378  mov esi, 0x00
00007ec68bfe037d  mov rax, 0x57D97DADF530
00007ec68bfe0387  call rax
00007ec68bfe0389  movaps xmm5, [rsp]
00007ec68bfe038d  add rsp, 0x30
00007ec68bfe0391  vmovaps xmm0, [rsp]
00007ec68bfe0396  vmovaps xmm1, [rsp+0x10]
00007ec68bfe039c  vmovaps xmm2, [rsp+0x20]
00007ec68bfe03a2  vmovaps xmm3, [rsp+0x30]
00007ec68bfe03a8  vmovaps xmm4, [rsp+0x40]
00007ec68bfe03ae  vmovaps xmm6, [rsp+0x50]
00007ec68bfe03b4  vmovaps xmm7, [rsp+0x60]
00007ec68bfe03ba  vmovaps xmm8, [rsp+0x70]
00007ec68bfe03c0  vmovaps xmm9, [rsp+0x80]
00007ec68bfe03c9  vmovaps xmm10, [rsp+0x90]
00007ec68bfe03d2  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe03db  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe03e4  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe03ed  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe03f6  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe03ff  add rsp, 0xF0
00007ec68bfe0406  pop r11
00007ec68bfe0408  pop r10
00007ec68bfe040a  pop r9
00007ec68bfe040c  pop r8
00007ec68bfe040e  pop rsi
00007ec68bfe040f  pop rdi
00007ec68bfe0410  pop rdx
00007ec68bfe0411  pop rcx
00007ec68bfe0412  pop rax
00007ec68bfe0413  add rsp, 0x08
00007ec68bfe0417  jmp 0x00007EC68BFDEE53
00007ec68bfe041c  sub rsp, 0x08
00007ec68bfe0420  push rax
00007ec68bfe0421  push rcx
00007ec68bfe0422  push rdx
00007ec68bfe0423  push rdi
00007ec68bfe0424  push rsi
00007ec68bfe0425  push r8
00007ec68bfe0427  push r9
00007ec68bfe0429  push r10
00007ec68bfe042b  push r11
00007ec68bfe042d  sub rsp, 0xF0
00007ec68bfe0434  vmovaps [rsp], xmm0
00007ec68bfe0439  vmovaps [rsp+0x10], xmm1
00007ec68bfe043f  vmovaps [rsp+0x20], xmm2
00007ec68bfe0445  vmovaps [rsp+0x30], xmm3
00007ec68bfe044b  vmovaps [rsp+0x40], xmm5
00007ec68bfe0451  vmovaps [rsp+0x50], xmm6
00007ec68bfe0457  vmovaps [rsp+0x60], xmm7
00007ec68bfe045d  vmovaps [rsp+0x70], xmm8
00007ec68bfe0463  vmovaps [rsp+0x80], xmm9
00007ec68bfe046c  vmovaps [rsp+0x90], xmm10
00007ec68bfe0475  vmovaps [rsp+0xA0], xmm11
00007ec68bfe047e  vmovaps [rsp+0xB0], xmm12
00007ec68bfe0487  vmovaps [rsp+0xC0], xmm13
00007ec68bfe0490  vmovaps [rsp+0xD0], xmm14
00007ec68bfe0499  vmovaps [rsp+0xE0], xmm15
00007ec68bfe04a2  sub rsp, 0x30
00007ec68bfe04a6  movaps [rsp], xmm4
00007ec68bfe04aa  movaps [rsp+0x10], xmm9
00007ec68bfe04b0  movaps [rsp+0x20], xmm8
00007ec68bfe04b6  lea rdi, [rsp]
00007ec68bfe04ba  mov esi, 0x00
00007ec68bfe04bf  mov rax, 0x57D97DADF530
00007ec68bfe04c9  call rax
00007ec68bfe04cb  movaps xmm4, [rsp]
00007ec68bfe04cf  add rsp, 0x30
00007ec68bfe04d3  vmovaps xmm0, [rsp]
00007ec68bfe04d8  vmovaps xmm1, [rsp+0x10]
00007ec68bfe04de  vmovaps xmm2, [rsp+0x20]
00007ec68bfe04e4  vmovaps xmm3, [rsp+0x30]
00007ec68bfe04ea  vmovaps xmm5, [rsp+0x40]
00007ec68bfe04f0  vmovaps xmm6, [rsp+0x50]
00007ec68bfe04f6  vmovaps xmm7, [rsp+0x60]
00007ec68bfe04fc  vmovaps xmm8, [rsp+0x70]
00007ec68bfe0502  vmovaps xmm9, [rsp+0x80]
00007ec68bfe050b  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0514  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe051d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe0526  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe052f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe0538  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe0541  add rsp, 0xF0
00007ec68bfe0548  pop r11
00007ec68bfe054a  pop r10
00007ec68bfe054c  pop r9
00007ec68bfe054e  pop r8
00007ec68bfe0550  pop rsi
00007ec68bfe0551  pop rdi
00007ec68bfe0552  pop rdx
00007ec68bfe0553  pop rcx
00007ec68bfe0554  pop rax
00007ec68bfe0555  add rsp, 0x08
00007ec68bfe0559  jmp 0x00007EC68BFDEE74
00007ec68bfe055e  sub rsp, 0x08
00007ec68bfe0562  push rax
00007ec68bfe0563  push rcx
00007ec68bfe0564  push rdx
00007ec68bfe0565  push rdi
00007ec68bfe0566  push rsi
00007ec68bfe0567  push r8
00007ec68bfe0569  push r9
00007ec68bfe056b  push r10
00007ec68bfe056d  push r11
00007ec68bfe056f  sub rsp, 0xF0
00007ec68bfe0576  vmovaps [rsp], xmm0
00007ec68bfe057b  vmovaps [rsp+0x10], xmm1
00007ec68bfe0581  vmovaps [rsp+0x20], xmm2
00007ec68bfe0587  vmovaps [rsp+0x30], xmm3
00007ec68bfe058d  vmovaps [rsp+0x40], xmm4
00007ec68bfe0593  vmovaps [rsp+0x50], xmm5
00007ec68bfe0599  vmovaps [rsp+0x60], xmm6
00007ec68bfe059f  vmovaps [rsp+0x70], xmm7
00007ec68bfe05a5  vmovaps [rsp+0x80], xmm8
00007ec68bfe05ae  vmovaps [rsp+0x90], xmm10
00007ec68bfe05b7  vmovaps [rsp+0xA0], xmm11
00007ec68bfe05c0  vmovaps [rsp+0xB0], xmm12
00007ec68bfe05c9  vmovaps [rsp+0xC0], xmm13
00007ec68bfe05d2  vmovaps [rsp+0xD0], xmm14
00007ec68bfe05db  vmovaps [rsp+0xE0], xmm15
00007ec68bfe05e4  sub rsp, 0x30
00007ec68bfe05e8  movaps [rsp], xmm9
00007ec68bfe05ed  movaps [rsp+0x10], xmm10
00007ec68bfe05f3  movaps [rsp+0x20], xmm8
00007ec68bfe05f9  lea rdi, [rsp]
00007ec68bfe05fd  mov esi, 0x00
00007ec68bfe0602  mov rax, 0x57D97DADF530
00007ec68bfe060c  call rax
00007ec68bfe060e  movaps xmm9, [rsp]
00007ec68bfe0613  add rsp, 0x30
00007ec68bfe0617  vmovaps xmm0, [rsp]
00007ec68bfe061c  vmovaps xmm1, [rsp+0x10]
00007ec68bfe0622  vmovaps xmm2, [rsp+0x20]
00007ec68bfe0628  vmovaps xmm3, [rsp+0x30]
00007ec68bfe062e  vmovaps xmm4, [rsp+0x40]
00007ec68bfe0634  vmovaps xmm5, [rsp+0x50]
00007ec68bfe063a  vmovaps xmm6, [rsp+0x60]
00007ec68bfe0640  vmovaps xmm7, [rsp+0x70]
00007ec68bfe0646  vmovaps xmm8, [rsp+0x80]
00007ec68bfe064f  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0658  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0661  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe066a  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe0673  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe067c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe0685  add rsp, 0xF0
00007ec68bfe068c  pop r11
00007ec68bfe068e  pop r10
00007ec68bfe0690  pop r9
00007ec68bfe0692  pop r8
00007ec68bfe0694  pop rsi
00007ec68bfe0695  pop rdi
00007ec68bfe0696  pop rdx
00007ec68bfe0697  pop rcx
00007ec68bfe0698  pop rax
00007ec68bfe0699  add rsp, 0x08
00007ec68bfe069d  jmp 0x00007EC68BFDEE8E
00007ec68bfe06a2  call 0x00007EC68BEB52F0
00007ec68bfe06a7  jmp 0x00007EC68BFDEFA8
00007ec68bfe06ac  call 0x00007EC68BEB52F0
00007ec68bfe06b1  jmp 0x00007EC68BFDEFBE
00007ec68bfe06b6  sub rsp, 0x08
00007ec68bfe06ba  push rax
00007ec68bfe06bb  push rcx
00007ec68bfe06bc  push rdx
00007ec68bfe06bd  push rdi
00007ec68bfe06be  push rsi
00007ec68bfe06bf  push r8
00007ec68bfe06c1  push r9
00007ec68bfe06c3  push r10
00007ec68bfe06c5  push r11
00007ec68bfe06c7  sub rsp, 0xF0
00007ec68bfe06ce  vmovaps [rsp], xmm0
00007ec68bfe06d3  vmovaps [rsp+0x10], xmm2
00007ec68bfe06d9  vmovaps [rsp+0x20], xmm3
00007ec68bfe06df  vmovaps [rsp+0x30], xmm4
00007ec68bfe06e5  vmovaps [rsp+0x40], xmm5
00007ec68bfe06eb  vmovaps [rsp+0x50], xmm6
00007ec68bfe06f1  vmovaps [rsp+0x60], xmm7
00007ec68bfe06f7  vmovaps [rsp+0x70], xmm8
00007ec68bfe06fd  vmovaps [rsp+0x80], xmm9
00007ec68bfe0706  vmovaps [rsp+0x90], xmm10
00007ec68bfe070f  vmovaps [rsp+0xA0], xmm11
00007ec68bfe0718  vmovaps [rsp+0xB0], xmm12
00007ec68bfe0721  vmovaps [rsp+0xC0], xmm13
00007ec68bfe072a  vmovaps [rsp+0xD0], xmm14
00007ec68bfe0733  vmovaps [rsp+0xE0], xmm15
00007ec68bfe073c  sub rsp, 0x30
00007ec68bfe0740  movaps [rsp], xmm1
00007ec68bfe0744  movaps [rsp+0x10], xmm6
00007ec68bfe0749  movaps [rsp+0x20], xmm15
00007ec68bfe074f  lea rdi, [rsp]
00007ec68bfe0753  mov esi, 0x00
00007ec68bfe0758  mov rax, 0x57D97DADF530
00007ec68bfe0762  call rax
00007ec68bfe0764  movaps xmm1, [rsp]
00007ec68bfe0768  add rsp, 0x30
00007ec68bfe076c  vmovaps xmm0, [rsp]
00007ec68bfe0771  vmovaps xmm2, [rsp+0x10]
00007ec68bfe0777  vmovaps xmm3, [rsp+0x20]
00007ec68bfe077d  vmovaps xmm4, [rsp+0x30]
00007ec68bfe0783  vmovaps xmm5, [rsp+0x40]
00007ec68bfe0789  vmovaps xmm6, [rsp+0x50]
00007ec68bfe078f  vmovaps xmm7, [rsp+0x60]
00007ec68bfe0795  vmovaps xmm8, [rsp+0x70]
00007ec68bfe079b  vmovaps xmm9, [rsp+0x80]
00007ec68bfe07a4  vmovaps xmm10, [rsp+0x90]
00007ec68bfe07ad  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe07b6  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe07bf  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe07c8  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe07d1  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe07da  add rsp, 0xF0
00007ec68bfe07e1  pop r11
00007ec68bfe07e3  pop r10
00007ec68bfe07e5  pop r9
00007ec68bfe07e7  pop r8
00007ec68bfe07e9  pop rsi
00007ec68bfe07ea  pop rdi
00007ec68bfe07eb  pop rdx
00007ec68bfe07ec  pop rcx
00007ec68bfe07ed  pop rax
00007ec68bfe07ee  add rsp, 0x08
00007ec68bfe07f2  jmp 0x00007EC68BFDEFFB
00007ec68bfe07f7  call 0x00007EC68BEC4620
00007ec68bfe07fc  jmp 0x00007EC68BFDF008
00007ec68bfe0801  sub rsp, 0x08
00007ec68bfe0805  push rax
00007ec68bfe0806  push rcx
00007ec68bfe0807  push rdx
00007ec68bfe0808  push rdi
00007ec68bfe0809  push rsi
00007ec68bfe080a  push r8
00007ec68bfe080c  push r9
00007ec68bfe080e  push r10
00007ec68bfe0810  push r11
00007ec68bfe0812  sub rsp, 0xF0
00007ec68bfe0819  vmovaps [rsp], xmm0
00007ec68bfe081e  vmovaps [rsp+0x10], xmm1
00007ec68bfe0824  vmovaps [rsp+0x20], xmm2
00007ec68bfe082a  vmovaps [rsp+0x30], xmm3
00007ec68bfe0830  vmovaps [rsp+0x40], xmm4
00007ec68bfe0836  vmovaps [rsp+0x50], xmm5
00007ec68bfe083c  vmovaps [rsp+0x60], xmm6
00007ec68bfe0842  vmovaps [rsp+0x70], xmm7
00007ec68bfe0848  vmovaps [rsp+0x80], xmm8
00007ec68bfe0851  vmovaps [rsp+0x90], xmm9
00007ec68bfe085a  vmovaps [rsp+0xA0], xmm10
00007ec68bfe0863  vmovaps [rsp+0xB0], xmm11
00007ec68bfe086c  vmovaps [rsp+0xC0], xmm12
00007ec68bfe0875  vmovaps [rsp+0xD0], xmm13
00007ec68bfe087e  vmovaps [rsp+0xE0], xmm15
00007ec68bfe0887  sub rsp, 0x30
00007ec68bfe088b  movaps [rsp], xmm14
00007ec68bfe0890  movaps [rsp+0x10], xmm4
00007ec68bfe0895  movaps [rsp+0x20], xmm3
00007ec68bfe089a  lea rdi, [rsp]
00007ec68bfe089e  mov esi, 0x00
00007ec68bfe08a3  mov rax, 0x57D97DADF530
00007ec68bfe08ad  call rax
00007ec68bfe08af  movaps xmm14, [rsp]
00007ec68bfe08b4  add rsp, 0x30
00007ec68bfe08b8  vmovaps xmm0, [rsp]
00007ec68bfe08bd  vmovaps xmm1, [rsp+0x10]
00007ec68bfe08c3  vmovaps xmm2, [rsp+0x20]
00007ec68bfe08c9  vmovaps xmm3, [rsp+0x30]
00007ec68bfe08cf  vmovaps xmm4, [rsp+0x40]
00007ec68bfe08d5  vmovaps xmm5, [rsp+0x50]
00007ec68bfe08db  vmovaps xmm6, [rsp+0x60]
00007ec68bfe08e1  vmovaps xmm7, [rsp+0x70]
00007ec68bfe08e7  vmovaps xmm8, [rsp+0x80]
00007ec68bfe08f0  vmovaps xmm9, [rsp+0x90]
00007ec68bfe08f9  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe0902  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe090b  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe0914  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe091d  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe0926  add rsp, 0xF0
00007ec68bfe092d  pop r11
00007ec68bfe092f  pop r10
00007ec68bfe0931  pop r9
00007ec68bfe0933  pop r8
00007ec68bfe0935  pop rsi
00007ec68bfe0936  pop rdi
00007ec68bfe0937  pop rdx
00007ec68bfe0938  pop rcx
00007ec68bfe0939  pop rax
00007ec68bfe093a  add rsp, 0x08
00007ec68bfe093e  jmp 0x00007EC68BFDF022
00007ec68bfe0943  sub rsp, 0x08
00007ec68bfe0947  push rax
00007ec68bfe0948  push rcx
00007ec68bfe0949  push rdx
00007ec68bfe094a  push rdi
00007ec68bfe094b  push rsi
00007ec68bfe094c  push r8
00007ec68bfe094e  push r9
00007ec68bfe0950  push r10
00007ec68bfe0952  push r11
00007ec68bfe0954  sub rsp, 0xF0
00007ec68bfe095b  vmovaps [rsp], xmm0
00007ec68bfe0960  vmovaps [rsp+0x10], xmm1
00007ec68bfe0966  vmovaps [rsp+0x20], xmm2
00007ec68bfe096c  vmovaps [rsp+0x30], xmm3
00007ec68bfe0972  vmovaps [rsp+0x40], xmm4
00007ec68bfe0978  vmovaps [rsp+0x50], xmm5
00007ec68bfe097e  vmovaps [rsp+0x60], xmm7
00007ec68bfe0984  vmovaps [rsp+0x70], xmm8
00007ec68bfe098a  vmovaps [rsp+0x80], xmm9
00007ec68bfe0993  vmovaps [rsp+0x90], xmm10
00007ec68bfe099c  vmovaps [rsp+0xA0], xmm11
00007ec68bfe09a5  vmovaps [rsp+0xB0], xmm12
00007ec68bfe09ae  vmovaps [rsp+0xC0], xmm13
00007ec68bfe09b7  vmovaps [rsp+0xD0], xmm14
00007ec68bfe09c0  vmovaps [rsp+0xE0], xmm15
00007ec68bfe09c9  sub rsp, 0x30
00007ec68bfe09cd  movaps [rsp], xmm6
00007ec68bfe09d1  movaps [rsp+0x10], xmm9
00007ec68bfe09d7  movaps [rsp+0x20], xmm7
00007ec68bfe09dc  lea rdi, [rsp]
00007ec68bfe09e0  mov esi, 0x00
00007ec68bfe09e5  mov rax, 0x57D97DADF530
00007ec68bfe09ef  call rax
00007ec68bfe09f1  movaps xmm6, [rsp]
00007ec68bfe09f5  add rsp, 0x30
00007ec68bfe09f9  vmovaps xmm0, [rsp]
00007ec68bfe09fe  vmovaps xmm1, [rsp+0x10]
00007ec68bfe0a04  vmovaps xmm2, [rsp+0x20]
00007ec68bfe0a0a  vmovaps xmm3, [rsp+0x30]
00007ec68bfe0a10  vmovaps xmm4, [rsp+0x40]
00007ec68bfe0a16  vmovaps xmm5, [rsp+0x50]
00007ec68bfe0a1c  vmovaps xmm7, [rsp+0x60]
00007ec68bfe0a22  vmovaps xmm8, [rsp+0x70]
00007ec68bfe0a28  vmovaps xmm9, [rsp+0x80]
00007ec68bfe0a31  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0a3a  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0a43  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe0a4c  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe0a55  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe0a5e  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe0a67  add rsp, 0xF0
00007ec68bfe0a6e  pop r11
00007ec68bfe0a70  pop r10
00007ec68bfe0a72  pop r9
00007ec68bfe0a74  pop r8
00007ec68bfe0a76  pop rsi
00007ec68bfe0a77  pop rdi
00007ec68bfe0a78  pop rdx
00007ec68bfe0a79  pop rcx
00007ec68bfe0a7a  pop rax
00007ec68bfe0a7b  add rsp, 0x08
00007ec68bfe0a7f  jmp 0x00007EC68BFDF03A
00007ec68bfe0a84  sub rsp, 0x08
00007ec68bfe0a88  push rax
00007ec68bfe0a89  push rcx
00007ec68bfe0a8a  push rdx
00007ec68bfe0a8b  push rdi
00007ec68bfe0a8c  push rsi
00007ec68bfe0a8d  push r8
00007ec68bfe0a8f  push r9
00007ec68bfe0a91  push r10
00007ec68bfe0a93  push r11
00007ec68bfe0a95  sub rsp, 0xF0
00007ec68bfe0a9c  vmovaps [rsp], xmm0
00007ec68bfe0aa1  vmovaps [rsp+0x10], xmm1
00007ec68bfe0aa7  vmovaps [rsp+0x20], xmm2
00007ec68bfe0aad  vmovaps [rsp+0x30], xmm3
00007ec68bfe0ab3  vmovaps [rsp+0x40], xmm4
00007ec68bfe0ab9  vmovaps [rsp+0x50], xmm5
00007ec68bfe0abf  vmovaps [rsp+0x60], xmm6
00007ec68bfe0ac5  vmovaps [rsp+0x70], xmm8
00007ec68bfe0acb  vmovaps [rsp+0x80], xmm9
00007ec68bfe0ad4  vmovaps [rsp+0x90], xmm10
00007ec68bfe0add  vmovaps [rsp+0xA0], xmm11
00007ec68bfe0ae6  vmovaps [rsp+0xB0], xmm12
00007ec68bfe0aef  vmovaps [rsp+0xC0], xmm13
00007ec68bfe0af8  vmovaps [rsp+0xD0], xmm14
00007ec68bfe0b01  vmovaps [rsp+0xE0], xmm15
00007ec68bfe0b0a  sub rsp, 0x30
00007ec68bfe0b0e  movaps [rsp], xmm7
00007ec68bfe0b12  movaps [rsp+0x10], xmm4
00007ec68bfe0b17  movaps [rsp+0x20], xmm9
00007ec68bfe0b1d  lea rdi, [rsp]
00007ec68bfe0b21  mov esi, 0x00
00007ec68bfe0b26  mov rax, 0x57D97DADF530
00007ec68bfe0b30  call rax
00007ec68bfe0b32  movaps xmm7, [rsp]
00007ec68bfe0b36  add rsp, 0x30
00007ec68bfe0b3a  vmovaps xmm0, [rsp]
00007ec68bfe0b3f  vmovaps xmm1, [rsp+0x10]
00007ec68bfe0b45  vmovaps xmm2, [rsp+0x20]
00007ec68bfe0b4b  vmovaps xmm3, [rsp+0x30]
00007ec68bfe0b51  vmovaps xmm4, [rsp+0x40]
00007ec68bfe0b57  vmovaps xmm5, [rsp+0x50]
00007ec68bfe0b5d  vmovaps xmm6, [rsp+0x60]
00007ec68bfe0b63  vmovaps xmm8, [rsp+0x70]
00007ec68bfe0b69  vmovaps xmm9, [rsp+0x80]
00007ec68bfe0b72  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0b7b  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0b84  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe0b8d  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe0b96  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe0b9f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe0ba8  add rsp, 0xF0
00007ec68bfe0baf  pop r11
00007ec68bfe0bb1  pop r10
00007ec68bfe0bb3  pop r9
00007ec68bfe0bb5  pop r8
00007ec68bfe0bb7  pop rsi
00007ec68bfe0bb8  pop rdi
00007ec68bfe0bb9  pop rdx
00007ec68bfe0bba  pop rcx
00007ec68bfe0bbb  pop rax
00007ec68bfe0bbc  add rsp, 0x08
00007ec68bfe0bc0  jmp 0x00007EC68BFDF067
00007ec68bfe0bc5  sub rsp, 0x08
00007ec68bfe0bc9  push rax
00007ec68bfe0bca  push rcx
00007ec68bfe0bcb  push rdx
00007ec68bfe0bcc  push rdi
00007ec68bfe0bcd  push rsi
00007ec68bfe0bce  push r8
00007ec68bfe0bd0  push r9
00007ec68bfe0bd2  push r10
00007ec68bfe0bd4  push r11
00007ec68bfe0bd6  sub rsp, 0xF0
00007ec68bfe0bdd  vmovaps [rsp], xmm0
00007ec68bfe0be2  vmovaps [rsp+0x10], xmm1
00007ec68bfe0be8  vmovaps [rsp+0x20], xmm2
00007ec68bfe0bee  vmovaps [rsp+0x30], xmm3
00007ec68bfe0bf4  vmovaps [rsp+0x40], xmm5
00007ec68bfe0bfa  vmovaps [rsp+0x50], xmm6
00007ec68bfe0c00  vmovaps [rsp+0x60], xmm7
00007ec68bfe0c06  vmovaps [rsp+0x70], xmm8
00007ec68bfe0c0c  vmovaps [rsp+0x80], xmm9
00007ec68bfe0c15  vmovaps [rsp+0x90], xmm10
00007ec68bfe0c1e  vmovaps [rsp+0xA0], xmm11
00007ec68bfe0c27  vmovaps [rsp+0xB0], xmm12
00007ec68bfe0c30  vmovaps [rsp+0xC0], xmm13
00007ec68bfe0c39  vmovaps [rsp+0xD0], xmm14
00007ec68bfe0c42  vmovaps [rsp+0xE0], xmm15
00007ec68bfe0c4b  sub rsp, 0x30
00007ec68bfe0c4f  movaps [rsp], xmm4
00007ec68bfe0c53  movaps [rsp+0x10], xmm15
00007ec68bfe0c59  movaps [rsp+0x20], xmm9
00007ec68bfe0c5f  lea rdi, [rsp]
00007ec68bfe0c63  mov esi, 0x00
00007ec68bfe0c68  mov rax, 0x57D97DADF530
00007ec68bfe0c72  call rax
00007ec68bfe0c74  movaps xmm4, [rsp]
00007ec68bfe0c78  add rsp, 0x30
00007ec68bfe0c7c  vmovaps xmm0, [rsp]
00007ec68bfe0c81  vmovaps xmm1, [rsp+0x10]
00007ec68bfe0c87  vmovaps xmm2, [rsp+0x20]
00007ec68bfe0c8d  vmovaps xmm3, [rsp+0x30]
00007ec68bfe0c93  vmovaps xmm5, [rsp+0x40]
00007ec68bfe0c99  vmovaps xmm6, [rsp+0x50]
00007ec68bfe0c9f  vmovaps xmm7, [rsp+0x60]
00007ec68bfe0ca5  vmovaps xmm8, [rsp+0x70]
00007ec68bfe0cab  vmovaps xmm9, [rsp+0x80]
00007ec68bfe0cb4  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0cbd  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0cc6  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe0ccf  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe0cd8  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe0ce1  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe0cea  add rsp, 0xF0
00007ec68bfe0cf1  pop r11
00007ec68bfe0cf3  pop r10
00007ec68bfe0cf5  pop r9
00007ec68bfe0cf7  pop r8
00007ec68bfe0cf9  pop rsi
00007ec68bfe0cfa  pop rdi
00007ec68bfe0cfb  pop rdx
00007ec68bfe0cfc  pop rcx
00007ec68bfe0cfd  pop rax
00007ec68bfe0cfe  add rsp, 0x08
00007ec68bfe0d02  jmp 0x00007EC68BFDF08C
00007ec68bfe0d07  call 0x00007EC68BEC4620
00007ec68bfe0d0c  jmp 0x00007EC68BFDF099
00007ec68bfe0d11  sub rsp, 0x08
00007ec68bfe0d15  push rax
00007ec68bfe0d16  push rcx
00007ec68bfe0d17  push rdx
00007ec68bfe0d18  push rdi
00007ec68bfe0d19  push rsi
00007ec68bfe0d1a  push r8
00007ec68bfe0d1c  push r9
00007ec68bfe0d1e  push r10
00007ec68bfe0d20  push r11
00007ec68bfe0d22  sub rsp, 0xF0
00007ec68bfe0d29  vmovaps [rsp], xmm0
00007ec68bfe0d2e  vmovaps [rsp+0x10], xmm1
00007ec68bfe0d34  vmovaps [rsp+0x20], xmm2
00007ec68bfe0d3a  vmovaps [rsp+0x30], xmm4
00007ec68bfe0d40  vmovaps [rsp+0x40], xmm5
00007ec68bfe0d46  vmovaps [rsp+0x50], xmm6
00007ec68bfe0d4c  vmovaps [rsp+0x60], xmm7
00007ec68bfe0d52  vmovaps [rsp+0x70], xmm8
00007ec68bfe0d58  vmovaps [rsp+0x80], xmm9
00007ec68bfe0d61  vmovaps [rsp+0x90], xmm10
00007ec68bfe0d6a  vmovaps [rsp+0xA0], xmm11
00007ec68bfe0d73  vmovaps [rsp+0xB0], xmm12
00007ec68bfe0d7c  vmovaps [rsp+0xC0], xmm13
00007ec68bfe0d85  vmovaps [rsp+0xD0], xmm14
00007ec68bfe0d8e  vmovaps [rsp+0xE0], xmm15
00007ec68bfe0d97  sub rsp, 0x30
00007ec68bfe0d9b  movaps [rsp], xmm3
00007ec68bfe0d9f  movaps [rsp+0x10], xmm1
00007ec68bfe0da4  movaps [rsp+0x20], xmm9
00007ec68bfe0daa  lea rdi, [rsp]
00007ec68bfe0dae  mov esi, 0x00
00007ec68bfe0db3  mov rax, 0x57D97DADF530
00007ec68bfe0dbd  call rax
00007ec68bfe0dbf  movaps xmm3, [rsp]
00007ec68bfe0dc3  add rsp, 0x30
00007ec68bfe0dc7  vmovaps xmm0, [rsp]
00007ec68bfe0dcc  vmovaps xmm1, [rsp+0x10]
00007ec68bfe0dd2  vmovaps xmm2, [rsp+0x20]
00007ec68bfe0dd8  vmovaps xmm4, [rsp+0x30]
00007ec68bfe0dde  vmovaps xmm5, [rsp+0x40]
00007ec68bfe0de4  vmovaps xmm6, [rsp+0x50]
00007ec68bfe0dea  vmovaps xmm7, [rsp+0x60]
00007ec68bfe0df0  vmovaps xmm8, [rsp+0x70]
00007ec68bfe0df6  vmovaps xmm9, [rsp+0x80]
00007ec68bfe0dff  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0e08  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0e11  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe0e1a  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe0e23  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe0e2c  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe0e35  add rsp, 0xF0
00007ec68bfe0e3c  pop r11
00007ec68bfe0e3e  pop r10
00007ec68bfe0e40  pop r9
00007ec68bfe0e42  pop r8
00007ec68bfe0e44  pop rsi
00007ec68bfe0e45  pop rdi
00007ec68bfe0e46  pop rdx
00007ec68bfe0e47  pop rcx
00007ec68bfe0e48  pop rax
00007ec68bfe0e49  add rsp, 0x08
00007ec68bfe0e4d  jmp 0x00007EC68BFDF0D6
00007ec68bfe0e52  sub rsp, 0x08
00007ec68bfe0e56  push rax
00007ec68bfe0e57  push rcx
00007ec68bfe0e58  push rdx
00007ec68bfe0e59  push rdi
00007ec68bfe0e5a  push rsi
00007ec68bfe0e5b  push r8
00007ec68bfe0e5d  push r9
00007ec68bfe0e5f  push r10
00007ec68bfe0e61  push r11
00007ec68bfe0e63  sub rsp, 0xF0
00007ec68bfe0e6a  vmovaps [rsp], xmm0
00007ec68bfe0e6f  vmovaps [rsp+0x10], xmm2
00007ec68bfe0e75  vmovaps [rsp+0x20], xmm3
00007ec68bfe0e7b  vmovaps [rsp+0x30], xmm4
00007ec68bfe0e81  vmovaps [rsp+0x40], xmm5
00007ec68bfe0e87  vmovaps [rsp+0x50], xmm6
00007ec68bfe0e8d  vmovaps [rsp+0x60], xmm7
00007ec68bfe0e93  vmovaps [rsp+0x70], xmm8
00007ec68bfe0e99  vmovaps [rsp+0x80], xmm9
00007ec68bfe0ea2  vmovaps [rsp+0x90], xmm10
00007ec68bfe0eab  vmovaps [rsp+0xA0], xmm11
00007ec68bfe0eb4  vmovaps [rsp+0xB0], xmm12
00007ec68bfe0ebd  vmovaps [rsp+0xC0], xmm13
00007ec68bfe0ec6  vmovaps [rsp+0xD0], xmm14
00007ec68bfe0ecf  vmovaps [rsp+0xE0], xmm15
00007ec68bfe0ed8  sub rsp, 0x30
00007ec68bfe0edc  movaps [rsp], xmm1
00007ec68bfe0ee0  movaps [rsp+0x10], xmm15
00007ec68bfe0ee6  movaps [rsp+0x20], xmm9
00007ec68bfe0eec  lea rdi, [rsp]
00007ec68bfe0ef0  mov esi, 0x00
00007ec68bfe0ef5  mov rax, 0x57D97DADF530
00007ec68bfe0eff  call rax
00007ec68bfe0f01  movaps xmm1, [rsp]
00007ec68bfe0f05  add rsp, 0x30
00007ec68bfe0f09  vmovaps xmm0, [rsp]
00007ec68bfe0f0e  vmovaps xmm2, [rsp+0x10]
00007ec68bfe0f14  vmovaps xmm3, [rsp+0x20]
00007ec68bfe0f1a  vmovaps xmm4, [rsp+0x30]
00007ec68bfe0f20  vmovaps xmm5, [rsp+0x40]
00007ec68bfe0f26  vmovaps xmm6, [rsp+0x50]
00007ec68bfe0f2c  vmovaps xmm7, [rsp+0x60]
00007ec68bfe0f32  vmovaps xmm8, [rsp+0x70]
00007ec68bfe0f38  vmovaps xmm9, [rsp+0x80]
00007ec68bfe0f41  vmovaps xmm10, [rsp+0x90]
00007ec68bfe0f4a  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe0f53  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe0f5c  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe0f65  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe0f6e  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe0f77  add rsp, 0xF0
00007ec68bfe0f7e  pop r11
00007ec68bfe0f80  pop r10
00007ec68bfe0f82  pop r9
00007ec68bfe0f84  pop r8
00007ec68bfe0f86  pop rsi
00007ec68bfe0f87  pop rdi
00007ec68bfe0f88  pop rdx
00007ec68bfe0f89  pop rcx
00007ec68bfe0f8a  pop rax
00007ec68bfe0f8b  add rsp, 0x08
00007ec68bfe0f8f  jmp 0x00007EC68BFDF15E
00007ec68bfe0f94  call 0x00007EC68BEC4620
00007ec68bfe0f99  jmp 0x00007EC68BFDF16B
00007ec68bfe0f9e  sub rsp, 0x08
00007ec68bfe0fa2  push rax
00007ec68bfe0fa3  push rcx
00007ec68bfe0fa4  push rdx
00007ec68bfe0fa5  push rdi
00007ec68bfe0fa6  push rsi
00007ec68bfe0fa7  push r8
00007ec68bfe0fa9  push r9
00007ec68bfe0fab  push r10
00007ec68bfe0fad  push r11
00007ec68bfe0faf  sub rsp, 0xF0
00007ec68bfe0fb6  vmovaps [rsp], xmm0
00007ec68bfe0fbb  vmovaps [rsp+0x10], xmm2
00007ec68bfe0fc1  vmovaps [rsp+0x20], xmm3
00007ec68bfe0fc7  vmovaps [rsp+0x30], xmm4
00007ec68bfe0fcd  vmovaps [rsp+0x40], xmm5
00007ec68bfe0fd3  vmovaps [rsp+0x50], xmm6
00007ec68bfe0fd9  vmovaps [rsp+0x60], xmm7
00007ec68bfe0fdf  vmovaps [rsp+0x70], xmm8
00007ec68bfe0fe5  vmovaps [rsp+0x80], xmm9
00007ec68bfe0fee  vmovaps [rsp+0x90], xmm10
00007ec68bfe0ff7  vmovaps [rsp+0xA0], xmm11
00007ec68bfe1000  vmovaps [rsp+0xB0], xmm12
00007ec68bfe1009  vmovaps [rsp+0xC0], xmm13
00007ec68bfe1012  vmovaps [rsp+0xD0], xmm14
00007ec68bfe101b  vmovaps [rsp+0xE0], xmm15
00007ec68bfe1024  sub rsp, 0x30
00007ec68bfe1028  movaps [rsp], xmm1
00007ec68bfe102c  movaps [rsp+0x10], xmm5
00007ec68bfe1031  movaps [rsp+0x20], xmm7
00007ec68bfe1036  lea rdi, [rsp]
00007ec68bfe103a  mov esi, 0x00
00007ec68bfe103f  mov rax, 0x57D97DADF530
00007ec68bfe1049  call rax
00007ec68bfe104b  movaps xmm1, [rsp]
00007ec68bfe104f  add rsp, 0x30
00007ec68bfe1053  vmovaps xmm0, [rsp]
00007ec68bfe1058  vmovaps xmm2, [rsp+0x10]
00007ec68bfe105e  vmovaps xmm3, [rsp+0x20]
00007ec68bfe1064  vmovaps xmm4, [rsp+0x30]
00007ec68bfe106a  vmovaps xmm5, [rsp+0x40]
00007ec68bfe1070  vmovaps xmm6, [rsp+0x50]
00007ec68bfe1076  vmovaps xmm7, [rsp+0x60]
00007ec68bfe107c  vmovaps xmm8, [rsp+0x70]
00007ec68bfe1082  vmovaps xmm9, [rsp+0x80]
00007ec68bfe108b  vmovaps xmm10, [rsp+0x90]
00007ec68bfe1094  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe109d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe10a6  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe10af  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe10b8  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe10c1  add rsp, 0xF0
00007ec68bfe10c8  pop r11
00007ec68bfe10ca  pop r10
00007ec68bfe10cc  pop r9
00007ec68bfe10ce  pop r8
00007ec68bfe10d0  pop rsi
00007ec68bfe10d1  pop rdi
00007ec68bfe10d2  pop rdx
00007ec68bfe10d3  pop rcx
00007ec68bfe10d4  pop rax
00007ec68bfe10d5  add rsp, 0x08
00007ec68bfe10d9  jmp 0x00007EC68BFDF210
00007ec68bfe10de  sub rsp, 0x08
00007ec68bfe10e2  push rax
00007ec68bfe10e3  push rcx
00007ec68bfe10e4  push rdx
00007ec68bfe10e5  push rdi
00007ec68bfe10e6  push rsi
00007ec68bfe10e7  push r8
00007ec68bfe10e9  push r9
00007ec68bfe10eb  push r10
00007ec68bfe10ed  push r11
00007ec68bfe10ef  sub rsp, 0xF0
00007ec68bfe10f6  vmovaps [rsp], xmm0
00007ec68bfe10fb  vmovaps [rsp+0x10], xmm1
00007ec68bfe1101  vmovaps [rsp+0x20], xmm2
00007ec68bfe1107  vmovaps [rsp+0x30], xmm3
00007ec68bfe110d  vmovaps [rsp+0x40], xmm4
00007ec68bfe1113  vmovaps [rsp+0x50], xmm5
00007ec68bfe1119  vmovaps [rsp+0x60], xmm6
00007ec68bfe111f  vmovaps [rsp+0x70], xmm8
00007ec68bfe1125  vmovaps [rsp+0x80], xmm9
00007ec68bfe112e  vmovaps [rsp+0x90], xmm10
00007ec68bfe1137  vmovaps [rsp+0xA0], xmm11
00007ec68bfe1140  vmovaps [rsp+0xB0], xmm12
00007ec68bfe1149  vmovaps [rsp+0xC0], xmm13
00007ec68bfe1152  vmovaps [rsp+0xD0], xmm14
00007ec68bfe115b  vmovaps [rsp+0xE0], xmm15
00007ec68bfe1164  sub rsp, 0x30
00007ec68bfe1168  movaps [rsp], xmm7
00007ec68bfe116c  movaps [rsp+0x10], xmm5
00007ec68bfe1171  movaps [rsp+0x20], xmm15
00007ec68bfe1177  lea rdi, [rsp]
00007ec68bfe117b  mov esi, 0x00
00007ec68bfe1180  mov rax, 0x57D97DADF530
00007ec68bfe118a  call rax
00007ec68bfe118c  movaps xmm7, [rsp]
00007ec68bfe1190  add rsp, 0x30
00007ec68bfe1194  vmovaps xmm0, [rsp]
00007ec68bfe1199  vmovaps xmm1, [rsp+0x10]
00007ec68bfe119f  vmovaps xmm2, [rsp+0x20]
00007ec68bfe11a5  vmovaps xmm3, [rsp+0x30]
00007ec68bfe11ab  vmovaps xmm4, [rsp+0x40]
00007ec68bfe11b1  vmovaps xmm5, [rsp+0x50]
00007ec68bfe11b7  vmovaps xmm6, [rsp+0x60]
00007ec68bfe11bd  vmovaps xmm8, [rsp+0x70]
00007ec68bfe11c3  vmovaps xmm9, [rsp+0x80]
00007ec68bfe11cc  vmovaps xmm10, [rsp+0x90]
00007ec68bfe11d5  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe11de  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe11e7  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe11f0  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe11f9  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe1202  add rsp, 0xF0
00007ec68bfe1209  pop r11
00007ec68bfe120b  pop r10
00007ec68bfe120d  pop r9
00007ec68bfe120f  pop r8
00007ec68bfe1211  pop rsi
00007ec68bfe1212  pop rdi
00007ec68bfe1213  pop rdx
00007ec68bfe1214  pop rcx
00007ec68bfe1215  pop rax
00007ec68bfe1216  add rsp, 0x08
00007ec68bfe121a  jmp 0x00007EC68BFDF246
00007ec68bfe121f  call 0x00007EC68BEB52F0
00007ec68bfe1224  jmp 0x00007EC68BFDF253
00007ec68bfe1229  sub rsp, 0x08
00007ec68bfe122d  push rax
00007ec68bfe122e  push rcx
00007ec68bfe122f  push rdx
00007ec68bfe1230  push rdi
00007ec68bfe1231  push rsi
00007ec68bfe1232  push r8
00007ec68bfe1234  push r9
00007ec68bfe1236  push r10
00007ec68bfe1238  push r11
00007ec68bfe123a  sub rsp, 0xF0
00007ec68bfe1241  vmovaps [rsp], xmm0
00007ec68bfe1246  vmovaps [rsp+0x10], xmm1
00007ec68bfe124c  vmovaps [rsp+0x20], xmm2
00007ec68bfe1252  vmovaps [rsp+0x30], xmm3
00007ec68bfe1258  vmovaps [rsp+0x40], xmm4
00007ec68bfe125e  vmovaps [rsp+0x50], xmm5
00007ec68bfe1264  vmovaps [rsp+0x60], xmm6
00007ec68bfe126a  vmovaps [rsp+0x70], xmm7
00007ec68bfe1270  vmovaps [rsp+0x80], xmm8
00007ec68bfe1279  vmovaps [rsp+0x90], xmm9
00007ec68bfe1282  vmovaps [rsp+0xA0], xmm10
00007ec68bfe128b  vmovaps [rsp+0xB0], xmm11
00007ec68bfe1294  vmovaps [rsp+0xC0], xmm12
00007ec68bfe129d  vmovaps [rsp+0xD0], xmm13
00007ec68bfe12a6  vmovaps [rsp+0xE0], xmm14
00007ec68bfe12af  sub rsp, 0x30
00007ec68bfe12b3  movaps [rsp], xmm15
00007ec68bfe12b8  movaps [rsp+0x10], xmm5
00007ec68bfe12bd  movaps [rsp+0x20], xmm3
00007ec68bfe12c2  lea rdi, [rsp]
00007ec68bfe12c6  mov esi, 0x00
00007ec68bfe12cb  mov rax, 0x57D97DADF530
00007ec68bfe12d5  call rax
00007ec68bfe12d7  movaps xmm15, [rsp]
00007ec68bfe12dc  add rsp, 0x30
00007ec68bfe12e0  vmovaps xmm0, [rsp]
00007ec68bfe12e5  vmovaps xmm1, [rsp+0x10]
00007ec68bfe12eb  vmovaps xmm2, [rsp+0x20]
00007ec68bfe12f1  vmovaps xmm3, [rsp+0x30]
00007ec68bfe12f7  vmovaps xmm4, [rsp+0x40]
00007ec68bfe12fd  vmovaps xmm5, [rsp+0x50]
00007ec68bfe1303  vmovaps xmm6, [rsp+0x60]
00007ec68bfe1309  vmovaps xmm7, [rsp+0x70]
00007ec68bfe130f  vmovaps xmm8, [rsp+0x80]
00007ec68bfe1318  vmovaps xmm9, [rsp+0x90]
00007ec68bfe1321  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe132a  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe1333  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe133c  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe1345  vmovaps xmm14, [rsp+0xE0]
00007ec68bfe134e  add rsp, 0xF0
00007ec68bfe1355  pop r11
00007ec68bfe1357  pop r10
00007ec68bfe1359  pop r9
00007ec68bfe135b  pop r8
00007ec68bfe135d  pop rsi
00007ec68bfe135e  pop rdi
00007ec68bfe135f  pop rdx
00007ec68bfe1360  pop rcx
00007ec68bfe1361  pop rax
00007ec68bfe1362  add rsp, 0x08
00007ec68bfe1366  jmp 0x00007EC68BFDF279
00007ec68bfe136b  sub rsp, 0x08
00007ec68bfe136f  push rax
00007ec68bfe1370  push rcx
00007ec68bfe1371  push rdx
00007ec68bfe1372  push rdi
00007ec68bfe1373  push rsi
00007ec68bfe1374  push r8
00007ec68bfe1376  push r9
00007ec68bfe1378  push r10
00007ec68bfe137a  push r11
00007ec68bfe137c  sub rsp, 0xF0
00007ec68bfe1383  vmovaps [rsp], xmm0
00007ec68bfe1388  vmovaps [rsp+0x10], xmm2
00007ec68bfe138e  vmovaps [rsp+0x20], xmm3
00007ec68bfe1394  vmovaps [rsp+0x30], xmm4
00007ec68bfe139a  vmovaps [rsp+0x40], xmm5
00007ec68bfe13a0  vmovaps [rsp+0x50], xmm6
00007ec68bfe13a6  vmovaps [rsp+0x60], xmm7
00007ec68bfe13ac  vmovaps [rsp+0x70], xmm8
00007ec68bfe13b2  vmovaps [rsp+0x80], xmm9
00007ec68bfe13bb  vmovaps [rsp+0x90], xmm10
00007ec68bfe13c4  vmovaps [rsp+0xA0], xmm11
00007ec68bfe13cd  vmovaps [rsp+0xB0], xmm12
00007ec68bfe13d6  vmovaps [rsp+0xC0], xmm13
00007ec68bfe13df  vmovaps [rsp+0xD0], xmm14
00007ec68bfe13e8  vmovaps [rsp+0xE0], xmm15
00007ec68bfe13f1  sub rsp, 0x30
00007ec68bfe13f5  movaps [rsp], xmm1
00007ec68bfe13f9  movaps [rsp+0x10], xmm5
00007ec68bfe13fe  movaps [rsp+0x20], xmm4
00007ec68bfe1403  lea rdi, [rsp]
00007ec68bfe1407  mov esi, 0x00
00007ec68bfe140c  mov rax, 0x57D97DADF530
00007ec68bfe1416  call rax
00007ec68bfe1418  movaps xmm1, [rsp]
00007ec68bfe141c  add rsp, 0x30
00007ec68bfe1420  vmovaps xmm0, [rsp]
00007ec68bfe1425  vmovaps xmm2, [rsp+0x10]
00007ec68bfe142b  vmovaps xmm3, [rsp+0x20]
00007ec68bfe1431  vmovaps xmm4, [rsp+0x30]
00007ec68bfe1437  vmovaps xmm5, [rsp+0x40]
00007ec68bfe143d  vmovaps xmm6, [rsp+0x50]
00007ec68bfe1443  vmovaps xmm7, [rsp+0x60]
00007ec68bfe1449  vmovaps xmm8, [rsp+0x70]
00007ec68bfe144f  vmovaps xmm9, [rsp+0x80]
00007ec68bfe1458  vmovaps xmm10, [rsp+0x90]
00007ec68bfe1461  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe146a  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe1473  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe147c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe1485  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe148e  add rsp, 0xF0
00007ec68bfe1495  pop r11
00007ec68bfe1497  pop r10
00007ec68bfe1499  pop r9
00007ec68bfe149b  pop r8
00007ec68bfe149d  pop rsi
00007ec68bfe149e  pop rdi
00007ec68bfe149f  pop rdx
00007ec68bfe14a0  pop rcx
00007ec68bfe14a1  pop rax
00007ec68bfe14a2  add rsp, 0x08
00007ec68bfe14a6  jmp 0x00007EC68BFDF299
00007ec68bfe14ab  sub rsp, 0x08
00007ec68bfe14af  push rax
00007ec68bfe14b0  push rcx
00007ec68bfe14b1  push rdx
00007ec68bfe14b2  push rdi
00007ec68bfe14b3  push rsi
00007ec68bfe14b4  push r8
00007ec68bfe14b6  push r9
00007ec68bfe14b8  push r10
00007ec68bfe14ba  push r11
00007ec68bfe14bc  sub rsp, 0xF0
00007ec68bfe14c3  vmovaps [rsp], xmm0
00007ec68bfe14c8  vmovaps [rsp+0x10], xmm1
00007ec68bfe14ce  vmovaps [rsp+0x20], xmm2
00007ec68bfe14d4  vmovaps [rsp+0x30], xmm3
00007ec68bfe14da  vmovaps [rsp+0x40], xmm5
00007ec68bfe14e0  vmovaps [rsp+0x50], xmm6
00007ec68bfe14e6  vmovaps [rsp+0x60], xmm7
00007ec68bfe14ec  vmovaps [rsp+0x70], xmm8
00007ec68bfe14f2  vmovaps [rsp+0x80], xmm9
00007ec68bfe14fb  vmovaps [rsp+0x90], xmm10
00007ec68bfe1504  vmovaps [rsp+0xA0], xmm11
00007ec68bfe150d  vmovaps [rsp+0xB0], xmm12
00007ec68bfe1516  vmovaps [rsp+0xC0], xmm13
00007ec68bfe151f  vmovaps [rsp+0xD0], xmm14
00007ec68bfe1528  vmovaps [rsp+0xE0], xmm15
00007ec68bfe1531  sub rsp, 0x30
00007ec68bfe1535  movaps [rsp], xmm4
00007ec68bfe1539  movaps [rsp+0x10], xmm3
00007ec68bfe153e  movaps [rsp+0x20], xmm5
00007ec68bfe1543  lea rdi, [rsp]
00007ec68bfe1547  mov esi, 0x00
00007ec68bfe154c  mov rax, 0x57D97DADF530
00007ec68bfe1556  call rax
00007ec68bfe1558  movaps xmm4, [rsp]
00007ec68bfe155c  add rsp, 0x30
00007ec68bfe1560  vmovaps xmm0, [rsp]
00007ec68bfe1565  vmovaps xmm1, [rsp+0x10]
00007ec68bfe156b  vmovaps xmm2, [rsp+0x20]
00007ec68bfe1571  vmovaps xmm3, [rsp+0x30]
00007ec68bfe1577  vmovaps xmm5, [rsp+0x40]
00007ec68bfe157d  vmovaps xmm6, [rsp+0x50]
00007ec68bfe1583  vmovaps xmm7, [rsp+0x60]
00007ec68bfe1589  vmovaps xmm8, [rsp+0x70]
00007ec68bfe158f  vmovaps xmm9, [rsp+0x80]
00007ec68bfe1598  vmovaps xmm10, [rsp+0x90]
00007ec68bfe15a1  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe15aa  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe15b3  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe15bc  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe15c5  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe15ce  add rsp, 0xF0
00007ec68bfe15d5  pop r11
00007ec68bfe15d7  pop r10
00007ec68bfe15d9  pop r9
00007ec68bfe15db  pop r8
00007ec68bfe15dd  pop rsi
00007ec68bfe15de  pop rdi
00007ec68bfe15df  pop rdx
00007ec68bfe15e0  pop rcx
00007ec68bfe15e1  pop rax
00007ec68bfe15e2  add rsp, 0x08
00007ec68bfe15e6  jmp 0x00007EC68BFDF2E7
00007ec68bfe15eb  call 0x00007EC68BEB52F0
00007ec68bfe15f0  jmp 0x00007EC68BFDF2F4
00007ec68bfe15f5  sub rsp, 0x08
00007ec68bfe15f9  push rax
00007ec68bfe15fa  push rcx
00007ec68bfe15fb  push rdx
00007ec68bfe15fc  push rdi
00007ec68bfe15fd  push rsi
00007ec68bfe15fe  push r8
00007ec68bfe1600  push r9
00007ec68bfe1602  push r10
00007ec68bfe1604  push r11
00007ec68bfe1606  sub rsp, 0xF0
00007ec68bfe160d  vmovaps [rsp], xmm0
00007ec68bfe1612  vmovaps [rsp+0x10], xmm1
00007ec68bfe1618  vmovaps [rsp+0x20], xmm2
00007ec68bfe161e  vmovaps [rsp+0x30], xmm3
00007ec68bfe1624  vmovaps [rsp+0x40], xmm4
00007ec68bfe162a  vmovaps [rsp+0x50], xmm6
00007ec68bfe1630  vmovaps [rsp+0x60], xmm7
00007ec68bfe1636  vmovaps [rsp+0x70], xmm8
00007ec68bfe163c  vmovaps [rsp+0x80], xmm9
00007ec68bfe1645  vmovaps [rsp+0x90], xmm10
00007ec68bfe164e  vmovaps [rsp+0xA0], xmm11
00007ec68bfe1657  vmovaps [rsp+0xB0], xmm12
00007ec68bfe1660  vmovaps [rsp+0xC0], xmm13
00007ec68bfe1669  vmovaps [rsp+0xD0], xmm14
00007ec68bfe1672  vmovaps [rsp+0xE0], xmm15
00007ec68bfe167b  sub rsp, 0x30
00007ec68bfe167f  movaps [rsp], xmm5
00007ec68bfe1683  movaps [rsp+0x10], xmm6
00007ec68bfe1688  movaps [rsp+0x20], xmm3
00007ec68bfe168d  lea rdi, [rsp]
00007ec68bfe1691  mov esi, 0x00
00007ec68bfe1696  mov rax, 0x57D97DADF530
00007ec68bfe16a0  call rax
00007ec68bfe16a2  movaps xmm5, [rsp]
00007ec68bfe16a6  add rsp, 0x30
00007ec68bfe16aa  vmovaps xmm0, [rsp]
00007ec68bfe16af  vmovaps xmm1, [rsp+0x10]
00007ec68bfe16b5  vmovaps xmm2, [rsp+0x20]
00007ec68bfe16bb  vmovaps xmm3, [rsp+0x30]
00007ec68bfe16c1  vmovaps xmm4, [rsp+0x40]
00007ec68bfe16c7  vmovaps xmm6, [rsp+0x50]
00007ec68bfe16cd  vmovaps xmm7, [rsp+0x60]
00007ec68bfe16d3  vmovaps xmm8, [rsp+0x70]
00007ec68bfe16d9  vmovaps xmm9, [rsp+0x80]
00007ec68bfe16e2  vmovaps xmm10, [rsp+0x90]
00007ec68bfe16eb  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe16f4  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe16fd  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe1706  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe170f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe1718  add rsp, 0xF0
00007ec68bfe171f  pop r11
00007ec68bfe1721  pop r10
00007ec68bfe1723  pop r9
00007ec68bfe1725  pop r8
00007ec68bfe1727  pop rsi
00007ec68bfe1728  pop rdi
00007ec68bfe1729  pop rdx
00007ec68bfe172a  pop rcx
00007ec68bfe172b  pop rax
00007ec68bfe172c  add rsp, 0x08
00007ec68bfe1730  jmp 0x00007EC68BFDF31A
00007ec68bfe1735  sub rsp, 0x08
00007ec68bfe1739  push rax
00007ec68bfe173a  push rcx
00007ec68bfe173b  push rdx
00007ec68bfe173c  push rdi
00007ec68bfe173d  push rsi
00007ec68bfe173e  push r8
00007ec68bfe1740  push r9
00007ec68bfe1742  push r10
00007ec68bfe1744  push r11
00007ec68bfe1746  sub rsp, 0xF0
00007ec68bfe174d  vmovaps [rsp], xmm0
00007ec68bfe1752  vmovaps [rsp+0x10], xmm1
00007ec68bfe1758  vmovaps [rsp+0x20], xmm2
00007ec68bfe175e  vmovaps [rsp+0x30], xmm3
00007ec68bfe1764  vmovaps [rsp+0x40], xmm4
00007ec68bfe176a  vmovaps [rsp+0x50], xmm5
00007ec68bfe1770  vmovaps [rsp+0x60], xmm7
00007ec68bfe1776  vmovaps [rsp+0x70], xmm8
00007ec68bfe177c  vmovaps [rsp+0x80], xmm9
00007ec68bfe1785  vmovaps [rsp+0x90], xmm10
00007ec68bfe178e  vmovaps [rsp+0xA0], xmm11
00007ec68bfe1797  vmovaps [rsp+0xB0], xmm12
00007ec68bfe17a0  vmovaps [rsp+0xC0], xmm13
00007ec68bfe17a9  vmovaps [rsp+0xD0], xmm14
00007ec68bfe17b2  vmovaps [rsp+0xE0], xmm15
00007ec68bfe17bb  sub rsp, 0x30
00007ec68bfe17bf  movaps [rsp], xmm6
00007ec68bfe17c3  movaps [rsp+0x10], xmm9
00007ec68bfe17c9  movaps [rsp+0x20], xmm1
00007ec68bfe17ce  lea rdi, [rsp]
00007ec68bfe17d2  mov esi, 0x00
00007ec68bfe17d7  mov rax, 0x57D97DADF530
00007ec68bfe17e1  call rax
00007ec68bfe17e3  movaps xmm6, [rsp]
00007ec68bfe17e7  add rsp, 0x30
00007ec68bfe17eb  vmovaps xmm0, [rsp]
00007ec68bfe17f0  vmovaps xmm1, [rsp+0x10]
00007ec68bfe17f6  vmovaps xmm2, [rsp+0x20]
00007ec68bfe17fc  vmovaps xmm3, [rsp+0x30]
00007ec68bfe1802  vmovaps xmm4, [rsp+0x40]
00007ec68bfe1808  vmovaps xmm5, [rsp+0x50]
00007ec68bfe180e  vmovaps xmm7, [rsp+0x60]
00007ec68bfe1814  vmovaps xmm8, [rsp+0x70]
00007ec68bfe181a  vmovaps xmm9, [rsp+0x80]
00007ec68bfe1823  vmovaps xmm10, [rsp+0x90]
00007ec68bfe182c  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe1835  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe183e  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe1847  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe1850  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe1859  add rsp, 0xF0
00007ec68bfe1860  pop r11
00007ec68bfe1862  pop r10
00007ec68bfe1864  pop r9
00007ec68bfe1866  pop r8
00007ec68bfe1868  pop rsi
00007ec68bfe1869  pop rdi
00007ec68bfe186a  pop rdx
00007ec68bfe186b  pop rcx
00007ec68bfe186c  pop rax
00007ec68bfe186d  add rsp, 0x08
00007ec68bfe1871  jmp 0x00007EC68BFDF33E
00007ec68bfe1876  sub rsp, 0x08
00007ec68bfe187a  push rax
00007ec68bfe187b  push rcx
00007ec68bfe187c  push rdx
00007ec68bfe187d  push rdi
00007ec68bfe187e  push rsi
00007ec68bfe187f  push r8
00007ec68bfe1881  push r9
00007ec68bfe1883  push r10
00007ec68bfe1885  push r11
00007ec68bfe1887  sub rsp, 0xF0
00007ec68bfe188e  vmovaps [rsp], xmm0
00007ec68bfe1893  vmovaps [rsp+0x10], xmm1
00007ec68bfe1899  vmovaps [rsp+0x20], xmm2
00007ec68bfe189f  vmovaps [rsp+0x30], xmm3
00007ec68bfe18a5  vmovaps [rsp+0x40], xmm4
00007ec68bfe18ab  vmovaps [rsp+0x50], xmm5
00007ec68bfe18b1  vmovaps [rsp+0x60], xmm6
00007ec68bfe18b7  vmovaps [rsp+0x70], xmm7
00007ec68bfe18bd  vmovaps [rsp+0x80], xmm8
00007ec68bfe18c6  vmovaps [rsp+0x90], xmm10
00007ec68bfe18cf  vmovaps [rsp+0xA0], xmm11
00007ec68bfe18d8  vmovaps [rsp+0xB0], xmm12
00007ec68bfe18e1  vmovaps [rsp+0xC0], xmm13
00007ec68bfe18ea  vmovaps [rsp+0xD0], xmm14
00007ec68bfe18f3  vmovaps [rsp+0xE0], xmm15
00007ec68bfe18fc  sub rsp, 0x30
00007ec68bfe1900  movaps [rsp], xmm9
00007ec68bfe1905  movaps [rsp+0x10], xmm3
00007ec68bfe190a  movaps [rsp+0x20], xmm1
00007ec68bfe190f  lea rdi, [rsp]
00007ec68bfe1913  mov esi, 0x00
00007ec68bfe1918  mov rax, 0x57D97DADF530
00007ec68bfe1922  call rax
00007ec68bfe1924  movaps xmm9, [rsp]
00007ec68bfe1929  add rsp, 0x30
00007ec68bfe192d  vmovaps xmm0, [rsp]
00007ec68bfe1932  vmovaps xmm1, [rsp+0x10]
00007ec68bfe1938  vmovaps xmm2, [rsp+0x20]
00007ec68bfe193e  vmovaps xmm3, [rsp+0x30]
00007ec68bfe1944  vmovaps xmm4, [rsp+0x40]
00007ec68bfe194a  vmovaps xmm5, [rsp+0x50]
00007ec68bfe1950  vmovaps xmm6, [rsp+0x60]
00007ec68bfe1956  vmovaps xmm7, [rsp+0x70]
00007ec68bfe195c  vmovaps xmm8, [rsp+0x80]
00007ec68bfe1965  vmovaps xmm10, [rsp+0x90]
00007ec68bfe196e  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe1977  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe1980  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe1989  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe1992  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe199b  add rsp, 0xF0
00007ec68bfe19a2  pop r11
00007ec68bfe19a4  pop r10
00007ec68bfe19a6  pop r9
00007ec68bfe19a8  pop r8
00007ec68bfe19aa  pop rsi
00007ec68bfe19ab  pop rdi
00007ec68bfe19ac  pop rdx
00007ec68bfe19ad  pop rcx
00007ec68bfe19ae  pop rax
00007ec68bfe19af  add rsp, 0x08
00007ec68bfe19b3  jmp 0x00007EC68BFDF38A
00007ec68bfe19b8  call 0x00007EC68BEB52F0
00007ec68bfe19bd  jmp 0x00007EC68BFDF397
00007ec68bfe19c2  sub rsp, 0x08
00007ec68bfe19c6  push rax
00007ec68bfe19c7  push rcx
00007ec68bfe19c8  push rdx
00007ec68bfe19c9  push rdi
00007ec68bfe19ca  push rsi
00007ec68bfe19cb  push r8
00007ec68bfe19cd  push r9
00007ec68bfe19cf  push r10
00007ec68bfe19d1  push r11
00007ec68bfe19d3  sub rsp, 0xF0
00007ec68bfe19da  vmovaps [rsp], xmm0
00007ec68bfe19df  vmovaps [rsp+0x10], xmm1
00007ec68bfe19e5  vmovaps [rsp+0x20], xmm2
00007ec68bfe19eb  vmovaps [rsp+0x30], xmm3
00007ec68bfe19f1  vmovaps [rsp+0x40], xmm4
00007ec68bfe19f7  vmovaps [rsp+0x50], xmm5
00007ec68bfe19fd  vmovaps [rsp+0x60], xmm6
00007ec68bfe1a03  vmovaps [rsp+0x70], xmm7
00007ec68bfe1a09  vmovaps [rsp+0x80], xmm8
00007ec68bfe1a12  vmovaps [rsp+0x90], xmm9
00007ec68bfe1a1b  vmovaps [rsp+0xA0], xmm10
00007ec68bfe1a24  vmovaps [rsp+0xB0], xmm11
00007ec68bfe1a2d  vmovaps [rsp+0xC0], xmm12
00007ec68bfe1a36  vmovaps [rsp+0xD0], xmm13
00007ec68bfe1a3f  vmovaps [rsp+0xE0], xmm14
00007ec68bfe1a48  sub rsp, 0x30
00007ec68bfe1a4c  movaps [rsp], xmm15
00007ec68bfe1a51  movaps [rsp+0x10], xmm3
00007ec68bfe1a56  movaps [rsp+0x20], xmm7
00007ec68bfe1a5b  lea rdi, [rsp]
00007ec68bfe1a5f  mov esi, 0x00
00007ec68bfe1a64  mov rax, 0x57D97DADF530
00007ec68bfe1a6e  call rax
00007ec68bfe1a70  movaps xmm15, [rsp]
00007ec68bfe1a75  add rsp, 0x30
00007ec68bfe1a79  vmovaps xmm0, [rsp]
00007ec68bfe1a7e  vmovaps xmm1, [rsp+0x10]
00007ec68bfe1a84  vmovaps xmm2, [rsp+0x20]
00007ec68bfe1a8a  vmovaps xmm3, [rsp+0x30]
00007ec68bfe1a90  vmovaps xmm4, [rsp+0x40]
00007ec68bfe1a96  vmovaps xmm5, [rsp+0x50]
00007ec68bfe1a9c  vmovaps xmm6, [rsp+0x60]
00007ec68bfe1aa2  vmovaps xmm7, [rsp+0x70]
00007ec68bfe1aa8  vmovaps xmm8, [rsp+0x80]
00007ec68bfe1ab1  vmovaps xmm9, [rsp+0x90]
00007ec68bfe1aba  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe1ac3  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe1acc  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe1ad5  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe1ade  vmovaps xmm14, [rsp+0xE0]
00007ec68bfe1ae7  add rsp, 0xF0
00007ec68bfe1aee  pop r11
00007ec68bfe1af0  pop r10
00007ec68bfe1af2  pop r9
00007ec68bfe1af4  pop r8
00007ec68bfe1af6  pop rsi
00007ec68bfe1af7  pop rdi
00007ec68bfe1af8  pop rdx
00007ec68bfe1af9  pop rcx
00007ec68bfe1afa  pop rax
00007ec68bfe1afb  add rsp, 0x08
00007ec68bfe1aff  jmp 0x00007EC68BFDF3C3
00007ec68bfe1b04  sub rsp, 0x08
00007ec68bfe1b08  push rax
00007ec68bfe1b09  push rcx
00007ec68bfe1b0a  push rdx
00007ec68bfe1b0b  push rdi
00007ec68bfe1b0c  push rsi
00007ec68bfe1b0d  push r8
00007ec68bfe1b0f  push r9
00007ec68bfe1b11  push r10
00007ec68bfe1b13  push r11
00007ec68bfe1b15  sub rsp, 0xF0
00007ec68bfe1b1c  vmovaps [rsp], xmm0
00007ec68bfe1b21  vmovaps [rsp+0x10], xmm1
00007ec68bfe1b27  vmovaps [rsp+0x20], xmm2
00007ec68bfe1b2d  vmovaps [rsp+0x30], xmm4
00007ec68bfe1b33  vmovaps [rsp+0x40], xmm5
00007ec68bfe1b39  vmovaps [rsp+0x50], xmm6
00007ec68bfe1b3f  vmovaps [rsp+0x60], xmm7
00007ec68bfe1b45  vmovaps [rsp+0x70], xmm8
00007ec68bfe1b4b  vmovaps [rsp+0x80], xmm9
00007ec68bfe1b54  vmovaps [rsp+0x90], xmm10
00007ec68bfe1b5d  vmovaps [rsp+0xA0], xmm11
00007ec68bfe1b66  vmovaps [rsp+0xB0], xmm12
00007ec68bfe1b6f  vmovaps [rsp+0xC0], xmm13
00007ec68bfe1b78  vmovaps [rsp+0xD0], xmm14
00007ec68bfe1b81  vmovaps [rsp+0xE0], xmm15
00007ec68bfe1b8a  sub rsp, 0x30
00007ec68bfe1b8e  movaps [rsp], xmm3
00007ec68bfe1b92  movaps [rsp+0x10], xmm1
00007ec68bfe1b97  movaps [rsp+0x20], xmm15
00007ec68bfe1b9d  lea rdi, [rsp]
00007ec68bfe1ba1  mov esi, 0x00
00007ec68bfe1ba6  mov rax, 0x57D97DADF530
00007ec68bfe1bb0  call rax
00007ec68bfe1bb2  movaps xmm3, [rsp]
00007ec68bfe1bb6  add rsp, 0x30
00007ec68bfe1bba  vmovaps xmm0, [rsp]
00007ec68bfe1bbf  vmovaps xmm1, [rsp+0x10]
00007ec68bfe1bc5  vmovaps xmm2, [rsp+0x20]
00007ec68bfe1bcb  vmovaps xmm4, [rsp+0x30]
00007ec68bfe1bd1  vmovaps xmm5, [rsp+0x40]
00007ec68bfe1bd7  vmovaps xmm6, [rsp+0x50]
00007ec68bfe1bdd  vmovaps xmm7, [rsp+0x60]
00007ec68bfe1be3  vmovaps xmm8, [rsp+0x70]
00007ec68bfe1be9  vmovaps xmm9, [rsp+0x80]
00007ec68bfe1bf2  vmovaps xmm10, [rsp+0x90]
00007ec68bfe1bfb  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe1c04  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe1c0d  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe1c16  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe1c1f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe1c28  add rsp, 0xF0
00007ec68bfe1c2f  pop r11
00007ec68bfe1c31  pop r10
00007ec68bfe1c33  pop r9
00007ec68bfe1c35  pop r8
00007ec68bfe1c37  pop rsi
00007ec68bfe1c38  pop rdi
00007ec68bfe1c39  pop rdx
00007ec68bfe1c3a  pop rcx
00007ec68bfe1c3b  pop rax
00007ec68bfe1c3c  add rsp, 0x08
00007ec68bfe1c40  jmp 0x00007EC68BFDF452
00007ec68bfe1c45  call 0x00007EC68BEB52F0
00007ec68bfe1c4a  jmp 0x00007EC68BFDF45C
00007ec68bfe1c4f  sub rsp, 0x08
00007ec68bfe1c53  push rax
00007ec68bfe1c54  push rcx
00007ec68bfe1c55  push rdx
00007ec68bfe1c56  push rdi
00007ec68bfe1c57  push rsi
00007ec68bfe1c58  push r8
00007ec68bfe1c5a  push r9
00007ec68bfe1c5c  push r10
00007ec68bfe1c5e  push r11
00007ec68bfe1c60  sub rsp, 0xF0
00007ec68bfe1c67  vmovaps [rsp], xmm0
00007ec68bfe1c6c  vmovaps [rsp+0x10], xmm1
00007ec68bfe1c72  vmovaps [rsp+0x20], xmm2
00007ec68bfe1c78  vmovaps [rsp+0x30], xmm3
00007ec68bfe1c7e  vmovaps [rsp+0x40], xmm4
00007ec68bfe1c84  vmovaps [rsp+0x50], xmm5
00007ec68bfe1c8a  vmovaps [rsp+0x60], xmm6
00007ec68bfe1c90  vmovaps [rsp+0x70], xmm7
00007ec68bfe1c96  vmovaps [rsp+0x80], xmm8
00007ec68bfe1c9f  vmovaps [rsp+0x90], xmm9
00007ec68bfe1ca8  vmovaps [rsp+0xA0], xmm10
00007ec68bfe1cb1  vmovaps [rsp+0xB0], xmm11
00007ec68bfe1cba  vmovaps [rsp+0xC0], xmm12
00007ec68bfe1cc3  vmovaps [rsp+0xD0], xmm13
00007ec68bfe1ccc  vmovaps [rsp+0xE0], xmm14
00007ec68bfe1cd5  sub rsp, 0x30
00007ec68bfe1cd9  movaps [rsp], xmm15
00007ec68bfe1cde  movaps [rsp+0x10], xmm14
00007ec68bfe1ce4  movaps [rsp+0x20], xmm4
00007ec68bfe1ce9  lea rdi, [rsp]
00007ec68bfe1ced  mov esi, 0x00
00007ec68bfe1cf2  mov rax, 0x57D97DADF530
00007ec68bfe1cfc  call rax
00007ec68bfe1cfe  movaps xmm15, [rsp]
00007ec68bfe1d03  add rsp, 0x30
00007ec68bfe1d07  vmovaps xmm0, [rsp]
00007ec68bfe1d0c  vmovaps xmm1, [rsp+0x10]
00007ec68bfe1d12  vmovaps xmm2, [rsp+0x20]
00007ec68bfe1d18  vmovaps xmm3, [rsp+0x30]
00007ec68bfe1d1e  vmovaps xmm4, [rsp+0x40]
00007ec68bfe1d24  vmovaps xmm5, [rsp+0x50]
00007ec68bfe1d2a  vmovaps xmm6, [rsp+0x60]
00007ec68bfe1d30  vmovaps xmm7, [rsp+0x70]
00007ec68bfe1d36  vmovaps xmm8, [rsp+0x80]
00007ec68bfe1d3f  vmovaps xmm9, [rsp+0x90]
00007ec68bfe1d48  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe1d51  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe1d5a  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe1d63  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe1d6c  vmovaps xmm14, [rsp+0xE0]
00007ec68bfe1d75  add rsp, 0xF0
00007ec68bfe1d7c  pop r11
00007ec68bfe1d7e  pop r10
00007ec68bfe1d80  pop r9
00007ec68bfe1d82  pop r8
00007ec68bfe1d84  pop rsi
00007ec68bfe1d85  pop rdi
00007ec68bfe1d86  pop rdx
00007ec68bfe1d87  pop rcx
00007ec68bfe1d88  pop rax
00007ec68bfe1d89  add rsp, 0x08
00007ec68bfe1d8d  jmp 0x00007EC68BFDF48A
00007ec68bfe1d92  sub rsp, 0x08
00007ec68bfe1d96  push rax
00007ec68bfe1d97  push rcx
00007ec68bfe1d98  push rdx
00007ec68bfe1d99  push rdi
00007ec68bfe1d9a  push rsi
00007ec68bfe1d9b  push r8
00007ec68bfe1d9d  push r9
00007ec68bfe1d9f  push r10
00007ec68bfe1da1  push r11
00007ec68bfe1da3  sub rsp, 0xF0
00007ec68bfe1daa  vmovaps [rsp], xmm0
00007ec68bfe1daf  vmovaps [rsp+0x10], xmm1
00007ec68bfe1db5  vmovaps [rsp+0x20], xmm2
00007ec68bfe1dbb  vmovaps [rsp+0x30], xmm3
00007ec68bfe1dc1  vmovaps [rsp+0x40], xmm4
00007ec68bfe1dc7  vmovaps [rsp+0x50], xmm5
00007ec68bfe1dcd  vmovaps [rsp+0x60], xmm6
00007ec68bfe1dd3  vmovaps [rsp+0x70], xmm7
00007ec68bfe1dd9  vmovaps [rsp+0x80], xmm8
00007ec68bfe1de2  vmovaps [rsp+0x90], xmm9
00007ec68bfe1deb  vmovaps [rsp+0xA0], xmm10
00007ec68bfe1df4  vmovaps [rsp+0xB0], xmm11
00007ec68bfe1dfd  vmovaps [rsp+0xC0], xmm12
00007ec68bfe1e06  vmovaps [rsp+0xD0], xmm13
00007ec68bfe1e0f  vmovaps [rsp+0xE0], xmm15
00007ec68bfe1e18  sub rsp, 0x30
00007ec68bfe1e1c  movaps [rsp], xmm14
00007ec68bfe1e21  movaps [rsp+0x10], xmm2
00007ec68bfe1e26  movaps [rsp+0x20], xmm1
00007ec68bfe1e2b  lea rdi, [rsp]
00007ec68bfe1e2f  mov esi, 0x00
00007ec68bfe1e34  mov rax, 0x57D97DADF530
00007ec68bfe1e3e  call rax
00007ec68bfe1e40  movaps xmm14, [rsp]
00007ec68bfe1e45  add rsp, 0x30
00007ec68bfe1e49  vmovaps xmm0, [rsp]
00007ec68bfe1e4e  vmovaps xmm1, [rsp+0x10]
00007ec68bfe1e54  vmovaps xmm2, [rsp+0x20]
00007ec68bfe1e5a  vmovaps xmm3, [rsp+0x30]
00007ec68bfe1e60  vmovaps xmm4, [rsp+0x40]
00007ec68bfe1e66  vmovaps xmm5, [rsp+0x50]
00007ec68bfe1e6c  vmovaps xmm6, [rsp+0x60]
00007ec68bfe1e72  vmovaps xmm7, [rsp+0x70]
00007ec68bfe1e78  vmovaps xmm8, [rsp+0x80]
00007ec68bfe1e81  vmovaps xmm9, [rsp+0x90]
00007ec68bfe1e8a  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe1e93  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe1e9c  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe1ea5  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe1eae  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe1eb7  add rsp, 0xF0
00007ec68bfe1ebe  pop r11
00007ec68bfe1ec0  pop r10
00007ec68bfe1ec2  pop r9
00007ec68bfe1ec4  pop r8
00007ec68bfe1ec6  pop rsi
00007ec68bfe1ec7  pop rdi
00007ec68bfe1ec8  pop rdx
00007ec68bfe1ec9  pop rcx
00007ec68bfe1eca  pop rax
00007ec68bfe1ecb  add rsp, 0x08
00007ec68bfe1ecf  jmp 0x00007EC68BFDF4B0
00007ec68bfe1ed4  sub rsp, 0x08
00007ec68bfe1ed8  push rax
00007ec68bfe1ed9  push rcx
00007ec68bfe1eda  push rdx
00007ec68bfe1edb  push rdi
00007ec68bfe1edc  push rsi
00007ec68bfe1edd  push r8
00007ec68bfe1edf  push r9
00007ec68bfe1ee1  push r10
00007ec68bfe1ee3  push r11
00007ec68bfe1ee5  sub rsp, 0xF0
00007ec68bfe1eec  vmovaps [rsp], xmm0
00007ec68bfe1ef1  vmovaps [rsp+0x10], xmm2
00007ec68bfe1ef7  vmovaps [rsp+0x20], xmm3
00007ec68bfe1efd  vmovaps [rsp+0x30], xmm4
00007ec68bfe1f03  vmovaps [rsp+0x40], xmm5
00007ec68bfe1f09  vmovaps [rsp+0x50], xmm6
00007ec68bfe1f0f  vmovaps [rsp+0x60], xmm7
00007ec68bfe1f15  vmovaps [rsp+0x70], xmm8
00007ec68bfe1f1b  vmovaps [rsp+0x80], xmm9
00007ec68bfe1f24  vmovaps [rsp+0x90], xmm10
00007ec68bfe1f2d  vmovaps [rsp+0xA0], xmm11
00007ec68bfe1f36  vmovaps [rsp+0xB0], xmm12
00007ec68bfe1f3f  vmovaps [rsp+0xC0], xmm13
00007ec68bfe1f48  vmovaps [rsp+0xD0], xmm14
00007ec68bfe1f51  vmovaps [rsp+0xE0], xmm15
00007ec68bfe1f5a  sub rsp, 0x30
00007ec68bfe1f5e  movaps [rsp], xmm1
00007ec68bfe1f62  movaps [rsp+0x10], xmm4
00007ec68bfe1f67  movaps [rsp+0x20], xmm9
00007ec68bfe1f6d  lea rdi, [rsp]
00007ec68bfe1f71  mov esi, 0x00
00007ec68bfe1f76  mov rax, 0x57D97DADF530
00007ec68bfe1f80  call rax
00007ec68bfe1f82  movaps xmm1, [rsp]
00007ec68bfe1f86  add rsp, 0x30
00007ec68bfe1f8a  vmovaps xmm0, [rsp]
00007ec68bfe1f8f  vmovaps xmm2, [rsp+0x10]
00007ec68bfe1f95  vmovaps xmm3, [rsp+0x20]
00007ec68bfe1f9b  vmovaps xmm4, [rsp+0x30]
00007ec68bfe1fa1  vmovaps xmm5, [rsp+0x40]
00007ec68bfe1fa7  vmovaps xmm6, [rsp+0x50]
00007ec68bfe1fad  vmovaps xmm7, [rsp+0x60]
00007ec68bfe1fb3  vmovaps xmm8, [rsp+0x70]
00007ec68bfe1fb9  vmovaps xmm9, [rsp+0x80]
00007ec68bfe1fc2  vmovaps xmm10, [rsp+0x90]
00007ec68bfe1fcb  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe1fd4  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe1fdd  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe1fe6  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe1fef  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe1ff8  add rsp, 0xF0
00007ec68bfe1fff  pop r11
00007ec68bfe2001  pop r10
00007ec68bfe2003  pop r9
00007ec68bfe2005  pop r8
00007ec68bfe2007  pop rsi
00007ec68bfe2008  pop rdi
00007ec68bfe2009  pop rdx
00007ec68bfe200a  pop rcx
00007ec68bfe200b  pop rax
00007ec68bfe200c  add rsp, 0x08
00007ec68bfe2010  jmp 0x00007EC68BFDF4CE
00007ec68bfe2015  sub rsp, 0x08
00007ec68bfe2019  push rax
00007ec68bfe201a  push rcx
00007ec68bfe201b  push rdx
00007ec68bfe201c  push rdi
00007ec68bfe201d  push rsi
00007ec68bfe201e  push r8
00007ec68bfe2020  push r9
00007ec68bfe2022  push r10
00007ec68bfe2024  push r11
00007ec68bfe2026  sub rsp, 0xF0
00007ec68bfe202d  vmovaps [rsp], xmm0
00007ec68bfe2032  vmovaps [rsp+0x10], xmm1
00007ec68bfe2038  vmovaps [rsp+0x20], xmm2
00007ec68bfe203e  vmovaps [rsp+0x30], xmm3
00007ec68bfe2044  vmovaps [rsp+0x40], xmm5
00007ec68bfe204a  vmovaps [rsp+0x50], xmm6
00007ec68bfe2050  vmovaps [rsp+0x60], xmm7
00007ec68bfe2056  vmovaps [rsp+0x70], xmm8
00007ec68bfe205c  vmovaps [rsp+0x80], xmm9
00007ec68bfe2065  vmovaps [rsp+0x90], xmm10
00007ec68bfe206e  vmovaps [rsp+0xA0], xmm11
00007ec68bfe2077  vmovaps [rsp+0xB0], xmm12
00007ec68bfe2080  vmovaps [rsp+0xC0], xmm13
00007ec68bfe2089  vmovaps [rsp+0xD0], xmm14
00007ec68bfe2092  vmovaps [rsp+0xE0], xmm15
00007ec68bfe209b  sub rsp, 0x30
00007ec68bfe209f  movaps [rsp], xmm4
00007ec68bfe20a3  movaps [rsp+0x10], xmm2
00007ec68bfe20a8  movaps [rsp+0x20], xmm9
00007ec68bfe20ae  lea rdi, [rsp]
00007ec68bfe20b2  mov esi, 0x00
00007ec68bfe20b7  mov rax, 0x57D97DADF530
00007ec68bfe20c1  call rax
00007ec68bfe20c3  movaps xmm4, [rsp]
00007ec68bfe20c7  add rsp, 0x30
00007ec68bfe20cb  vmovaps xmm0, [rsp]
00007ec68bfe20d0  vmovaps xmm1, [rsp+0x10]
00007ec68bfe20d6  vmovaps xmm2, [rsp+0x20]
00007ec68bfe20dc  vmovaps xmm3, [rsp+0x30]
00007ec68bfe20e2  vmovaps xmm5, [rsp+0x40]
00007ec68bfe20e8  vmovaps xmm6, [rsp+0x50]
00007ec68bfe20ee  vmovaps xmm7, [rsp+0x60]
00007ec68bfe20f4  vmovaps xmm8, [rsp+0x70]
00007ec68bfe20fa  vmovaps xmm9, [rsp+0x80]
00007ec68bfe2103  vmovaps xmm10, [rsp+0x90]
00007ec68bfe210c  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe2115  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe211e  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe2127  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe2130  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe2139  add rsp, 0xF0
00007ec68bfe2140  pop r11
00007ec68bfe2142  pop r10
00007ec68bfe2144  pop r9
00007ec68bfe2146  pop r8
00007ec68bfe2148  pop rsi
00007ec68bfe2149  pop rdi
00007ec68bfe214a  pop rdx
00007ec68bfe214b  pop rcx
00007ec68bfe214c  pop rax
00007ec68bfe214d  add rsp, 0x08
00007ec68bfe2151  jmp 0x00007EC68BFDF4FE
00007ec68bfe2156  sub rsp, 0x08
00007ec68bfe215a  push rax
00007ec68bfe215b  push rcx
00007ec68bfe215c  push rdx
00007ec68bfe215d  push rdi
00007ec68bfe215e  push rsi
00007ec68bfe215f  push r8
00007ec68bfe2161  push r9
00007ec68bfe2163  push r10
00007ec68bfe2165  push r11
00007ec68bfe2167  sub rsp, 0xF0
00007ec68bfe216e  vmovaps [rsp], xmm0
00007ec68bfe2173  vmovaps [rsp+0x10], xmm1
00007ec68bfe2179  vmovaps [rsp+0x20], xmm2
00007ec68bfe217f  vmovaps [rsp+0x30], xmm3
00007ec68bfe2185  vmovaps [rsp+0x40], xmm4
00007ec68bfe218b  vmovaps [rsp+0x50], xmm5
00007ec68bfe2191  vmovaps [rsp+0x60], xmm6
00007ec68bfe2197  vmovaps [rsp+0x70], xmm7
00007ec68bfe219d  vmovaps [rsp+0x80], xmm8
00007ec68bfe21a6  vmovaps [rsp+0x90], xmm10
00007ec68bfe21af  vmovaps [rsp+0xA0], xmm11
00007ec68bfe21b8  vmovaps [rsp+0xB0], xmm12
00007ec68bfe21c1  vmovaps [rsp+0xC0], xmm13
00007ec68bfe21ca  vmovaps [rsp+0xD0], xmm14
00007ec68bfe21d3  vmovaps [rsp+0xE0], xmm15
00007ec68bfe21dc  sub rsp, 0x30
00007ec68bfe21e0  movaps [rsp], xmm9
00007ec68bfe21e5  movaps [rsp+0x10], xmm2
00007ec68bfe21ea  movaps [rsp+0x20], xmm1
00007ec68bfe21ef  lea rdi, [rsp]
00007ec68bfe21f3  mov esi, 0x00
00007ec68bfe21f8  mov rax, 0x57D97DADF530
00007ec68bfe2202  call rax
00007ec68bfe2204  movaps xmm9, [rsp]
00007ec68bfe2209  add rsp, 0x30
00007ec68bfe220d  vmovaps xmm0, [rsp]
00007ec68bfe2212  vmovaps xmm1, [rsp+0x10]
00007ec68bfe2218  vmovaps xmm2, [rsp+0x20]
00007ec68bfe221e  vmovaps xmm3, [rsp+0x30]
00007ec68bfe2224  vmovaps xmm4, [rsp+0x40]
00007ec68bfe222a  vmovaps xmm5, [rsp+0x50]
00007ec68bfe2230  vmovaps xmm6, [rsp+0x60]
00007ec68bfe2236  vmovaps xmm7, [rsp+0x70]
00007ec68bfe223c  vmovaps xmm8, [rsp+0x80]
00007ec68bfe2245  vmovaps xmm10, [rsp+0x90]
00007ec68bfe224e  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe2257  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe2260  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe2269  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe2272  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe227b  add rsp, 0xF0
00007ec68bfe2282  pop r11
00007ec68bfe2284  pop r10
00007ec68bfe2286  pop r9
00007ec68bfe2288  pop r8
00007ec68bfe228a  pop rsi
00007ec68bfe228b  pop rdi
00007ec68bfe228c  pop rdx
00007ec68bfe228d  pop rcx
00007ec68bfe228e  pop rax
00007ec68bfe228f  add rsp, 0x08
00007ec68bfe2293  jmp 0x00007EC68BFDF534
00007ec68bfe2298  sub rsp, 0x08
00007ec68bfe229c  push rax
00007ec68bfe229d  push rcx
00007ec68bfe229e  push rdx
00007ec68bfe229f  push rdi
00007ec68bfe22a0  push rsi
00007ec68bfe22a1  push r8
00007ec68bfe22a3  push r9
00007ec68bfe22a5  push r10
00007ec68bfe22a7  push r11
00007ec68bfe22a9  sub rsp, 0xF0
00007ec68bfe22b0  vmovaps [rsp], xmm0
00007ec68bfe22b5  vmovaps [rsp+0x10], xmm2
00007ec68bfe22bb  vmovaps [rsp+0x20], xmm3
00007ec68bfe22c1  vmovaps [rsp+0x30], xmm4
00007ec68bfe22c7  vmovaps [rsp+0x40], xmm5
00007ec68bfe22cd  vmovaps [rsp+0x50], xmm6
00007ec68bfe22d3  vmovaps [rsp+0x60], xmm7
00007ec68bfe22d9  vmovaps [rsp+0x70], xmm8
00007ec68bfe22df  vmovaps [rsp+0x80], xmm9
00007ec68bfe22e8  vmovaps [rsp+0x90], xmm10
00007ec68bfe22f1  vmovaps [rsp+0xA0], xmm11
00007ec68bfe22fa  vmovaps [rsp+0xB0], xmm12
00007ec68bfe2303  vmovaps [rsp+0xC0], xmm13
00007ec68bfe230c  vmovaps [rsp+0xD0], xmm14
00007ec68bfe2315  vmovaps [rsp+0xE0], xmm15
00007ec68bfe231e  sub rsp, 0x30
00007ec68bfe2322  movaps [rsp], xmm1
00007ec68bfe2326  movaps [rsp+0x10], xmm15
00007ec68bfe232c  movaps [rsp+0x20], xmm6
00007ec68bfe2331  lea rdi, [rsp]
00007ec68bfe2335  mov esi, 0x00
00007ec68bfe233a  mov rax, 0x57D97DADF530
00007ec68bfe2344  call rax
00007ec68bfe2346  movaps xmm1, [rsp]
00007ec68bfe234a  add rsp, 0x30
00007ec68bfe234e  vmovaps xmm0, [rsp]
00007ec68bfe2353  vmovaps xmm2, [rsp+0x10]
00007ec68bfe2359  vmovaps xmm3, [rsp+0x20]
00007ec68bfe235f  vmovaps xmm4, [rsp+0x30]
00007ec68bfe2365  vmovaps xmm5, [rsp+0x40]
00007ec68bfe236b  vmovaps xmm6, [rsp+0x50]
00007ec68bfe2371  vmovaps xmm7, [rsp+0x60]
00007ec68bfe2377  vmovaps xmm8, [rsp+0x70]
00007ec68bfe237d  vmovaps xmm9, [rsp+0x80]
00007ec68bfe2386  vmovaps xmm10, [rsp+0x90]
00007ec68bfe238f  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe2398  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe23a1  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe23aa  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe23b3  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe23bc  add rsp, 0xF0
00007ec68bfe23c3  pop r11
00007ec68bfe23c5  pop r10
00007ec68bfe23c7  pop r9
00007ec68bfe23c9  pop r8
00007ec68bfe23cb  pop rsi
00007ec68bfe23cc  pop rdi
00007ec68bfe23cd  pop rdx
00007ec68bfe23ce  pop rcx
00007ec68bfe23cf  pop rax
00007ec68bfe23d0  add rsp, 0x08
00007ec68bfe23d4  jmp 0x00007EC68BFDF555
00007ec68bfe23d9  sub rsp, 0x08
00007ec68bfe23dd  push rax
00007ec68bfe23de  push rcx
00007ec68bfe23df  push rdx
00007ec68bfe23e0  push rdi
00007ec68bfe23e1  push rsi
00007ec68bfe23e2  push r8
00007ec68bfe23e4  push r9
00007ec68bfe23e6  push r10
00007ec68bfe23e8  push r11
00007ec68bfe23ea  sub rsp, 0xF0
00007ec68bfe23f1  vmovaps [rsp], xmm0
00007ec68bfe23f6  vmovaps [rsp+0x10], xmm1
00007ec68bfe23fc  vmovaps [rsp+0x20], xmm2
00007ec68bfe2402  vmovaps [rsp+0x30], xmm3
00007ec68bfe2408  vmovaps [rsp+0x40], xmm4
00007ec68bfe240e  vmovaps [rsp+0x50], xmm5
00007ec68bfe2414  vmovaps [rsp+0x60], xmm6
00007ec68bfe241a  vmovaps [rsp+0x70], xmm7
00007ec68bfe2420  vmovaps [rsp+0x80], xmm8
00007ec68bfe2429  vmovaps [rsp+0x90], xmm9
00007ec68bfe2432  vmovaps [rsp+0xA0], xmm10
00007ec68bfe243b  vmovaps [rsp+0xB0], xmm11
00007ec68bfe2444  vmovaps [rsp+0xC0], xmm12
00007ec68bfe244d  vmovaps [rsp+0xD0], xmm13
00007ec68bfe2456  vmovaps [rsp+0xE0], xmm14
00007ec68bfe245f  sub rsp, 0x30
00007ec68bfe2463  movaps [rsp], xmm15
00007ec68bfe2468  movaps [rsp+0x10], xmm5
00007ec68bfe246d  movaps [rsp+0x20], xmm3
00007ec68bfe2472  lea rdi, [rsp]
00007ec68bfe2476  mov esi, 0x00
00007ec68bfe247b  mov rax, 0x57D97DADF530
00007ec68bfe2485  call rax
00007ec68bfe2487  movaps xmm15, [rsp]
00007ec68bfe248c  add rsp, 0x30
00007ec68bfe2490  vmovaps xmm0, [rsp]
00007ec68bfe2495  vmovaps xmm1, [rsp+0x10]
00007ec68bfe249b  vmovaps xmm2, [rsp+0x20]
00007ec68bfe24a1  vmovaps xmm3, [rsp+0x30]
00007ec68bfe24a7  vmovaps xmm4, [rsp+0x40]
00007ec68bfe24ad  vmovaps xmm5, [rsp+0x50]
00007ec68bfe24b3  vmovaps xmm6, [rsp+0x60]
00007ec68bfe24b9  vmovaps xmm7, [rsp+0x70]
00007ec68bfe24bf  vmovaps xmm8, [rsp+0x80]
00007ec68bfe24c8  vmovaps xmm9, [rsp+0x90]
00007ec68bfe24d1  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe24da  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe24e3  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe24ec  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe24f5  vmovaps xmm14, [rsp+0xE0]
00007ec68bfe24fe  add rsp, 0xF0
00007ec68bfe2505  pop r11
00007ec68bfe2507  pop r10
00007ec68bfe2509  pop r9
00007ec68bfe250b  pop r8
00007ec68bfe250d  pop rsi
00007ec68bfe250e  pop rdi
00007ec68bfe250f  pop rdx
00007ec68bfe2510  pop rcx
00007ec68bfe2511  pop rax
00007ec68bfe2512  add rsp, 0x08
00007ec68bfe2516  jmp 0x00007EC68BFDF56F
00007ec68bfe251b  sub rsp, 0x08
00007ec68bfe251f  push rax
00007ec68bfe2520  push rcx
00007ec68bfe2521  push rdx
00007ec68bfe2522  push rdi
00007ec68bfe2523  push rsi
00007ec68bfe2524  push r8
00007ec68bfe2526  push r9
00007ec68bfe2528  push r10
00007ec68bfe252a  push r11
00007ec68bfe252c  sub rsp, 0xF0
00007ec68bfe2533  vmovaps [rsp], xmm0
00007ec68bfe2538  vmovaps [rsp+0x10], xmm1
00007ec68bfe253e  vmovaps [rsp+0x20], xmm2
00007ec68bfe2544  vmovaps [rsp+0x30], xmm3
00007ec68bfe254a  vmovaps [rsp+0x40], xmm4
00007ec68bfe2550  vmovaps [rsp+0x50], xmm6
00007ec68bfe2556  vmovaps [rsp+0x60], xmm7
00007ec68bfe255c  vmovaps [rsp+0x70], xmm8
00007ec68bfe2562  vmovaps [rsp+0x80], xmm9
00007ec68bfe256b  vmovaps [rsp+0x90], xmm10
00007ec68bfe2574  vmovaps [rsp+0xA0], xmm11
00007ec68bfe257d  vmovaps [rsp+0xB0], xmm12
00007ec68bfe2586  vmovaps [rsp+0xC0], xmm13
00007ec68bfe258f  vmovaps [rsp+0xD0], xmm14
00007ec68bfe2598  vmovaps [rsp+0xE0], xmm15
00007ec68bfe25a1  sub rsp, 0x30
00007ec68bfe25a5  movaps [rsp], xmm5
00007ec68bfe25a9  movaps [rsp+0x10], xmm8
00007ec68bfe25af  movaps [rsp+0x20], xmm6
00007ec68bfe25b4  lea rdi, [rsp]
00007ec68bfe25b8  mov esi, 0x00
00007ec68bfe25bd  mov rax, 0x57D97DADF530
00007ec68bfe25c7  call rax
00007ec68bfe25c9  movaps xmm5, [rsp]
00007ec68bfe25cd  add rsp, 0x30
00007ec68bfe25d1  vmovaps xmm0, [rsp]
00007ec68bfe25d6  vmovaps xmm1, [rsp+0x10]
00007ec68bfe25dc  vmovaps xmm2, [rsp+0x20]
00007ec68bfe25e2  vmovaps xmm3, [rsp+0x30]
00007ec68bfe25e8  vmovaps xmm4, [rsp+0x40]
00007ec68bfe25ee  vmovaps xmm6, [rsp+0x50]
00007ec68bfe25f4  vmovaps xmm7, [rsp+0x60]
00007ec68bfe25fa  vmovaps xmm8, [rsp+0x70]
00007ec68bfe2600  vmovaps xmm9, [rsp+0x80]
00007ec68bfe2609  vmovaps xmm10, [rsp+0x90]
00007ec68bfe2612  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe261b  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe2624  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe262d  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe2636  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe263f  add rsp, 0xF0
00007ec68bfe2646  pop r11
00007ec68bfe2648  pop r10
00007ec68bfe264a  pop r9
00007ec68bfe264c  pop r8
00007ec68bfe264e  pop rsi
00007ec68bfe264f  pop rdi
00007ec68bfe2650  pop rdx
00007ec68bfe2651  pop rcx
00007ec68bfe2652  pop rax
00007ec68bfe2653  add rsp, 0x08
00007ec68bfe2657  jmp 0x00007EC68BFDF593
00007ec68bfe265c  sub rsp, 0x08
00007ec68bfe2660  push rax
00007ec68bfe2661  push rcx
00007ec68bfe2662  push rdx
00007ec68bfe2663  push rdi
00007ec68bfe2664  push rsi
00007ec68bfe2665  push r8
00007ec68bfe2667  push r9
00007ec68bfe2669  push r10
00007ec68bfe266b  push r11
00007ec68bfe266d  sub rsp, 0xF0
00007ec68bfe2674  vmovaps [rsp], xmm0
00007ec68bfe2679  vmovaps [rsp+0x10], xmm1
00007ec68bfe267f  vmovaps [rsp+0x20], xmm2
00007ec68bfe2685  vmovaps [rsp+0x30], xmm3
00007ec68bfe268b  vmovaps [rsp+0x40], xmm4
00007ec68bfe2691  vmovaps [rsp+0x50], xmm5
00007ec68bfe2697  vmovaps [rsp+0x60], xmm7
00007ec68bfe269d  vmovaps [rsp+0x70], xmm8
00007ec68bfe26a3  vmovaps [rsp+0x80], xmm9
00007ec68bfe26ac  vmovaps [rsp+0x90], xmm10
00007ec68bfe26b5  vmovaps [rsp+0xA0], xmm11
00007ec68bfe26be  vmovaps [rsp+0xB0], xmm12
00007ec68bfe26c7  vmovaps [rsp+0xC0], xmm13
00007ec68bfe26d0  vmovaps [rsp+0xD0], xmm14
00007ec68bfe26d9  vmovaps [rsp+0xE0], xmm15
00007ec68bfe26e2  sub rsp, 0x30
00007ec68bfe26e6  movaps [rsp], xmm6
00007ec68bfe26ea  movaps [rsp+0x10], xmm10
00007ec68bfe26f0  movaps [rsp+0x20], xmm8
00007ec68bfe26f6  lea rdi, [rsp]
00007ec68bfe26fa  mov esi, 0x00
00007ec68bfe26ff  mov rax, 0x57D97DADF530
00007ec68bfe2709  call rax
00007ec68bfe270b  movaps xmm6, [rsp]
00007ec68bfe270f  add rsp, 0x30
00007ec68bfe2713  vmovaps xmm0, [rsp]
00007ec68bfe2718  vmovaps xmm1, [rsp+0x10]
00007ec68bfe271e  vmovaps xmm2, [rsp+0x20]
00007ec68bfe2724  vmovaps xmm3, [rsp+0x30]
00007ec68bfe272a  vmovaps xmm4, [rsp+0x40]
00007ec68bfe2730  vmovaps xmm5, [rsp+0x50]
00007ec68bfe2736  vmovaps xmm7, [rsp+0x60]
00007ec68bfe273c  vmovaps xmm8, [rsp+0x70]
00007ec68bfe2742  vmovaps xmm9, [rsp+0x80]
00007ec68bfe274b  vmovaps xmm10, [rsp+0x90]
00007ec68bfe2754  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe275d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe2766  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe276f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe2778  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe2781  add rsp, 0xF0
00007ec68bfe2788  pop r11
00007ec68bfe278a  pop r10
00007ec68bfe278c  pop r9
00007ec68bfe278e  pop r8
00007ec68bfe2790  pop rsi
00007ec68bfe2791  pop rdi
00007ec68bfe2792  pop rdx
00007ec68bfe2793  pop rcx
00007ec68bfe2794  pop rax
00007ec68bfe2795  add rsp, 0x08
00007ec68bfe2799  jmp 0x00007EC68BFDF5B8
00007ec68bfe279e  sub rsp, 0x08
00007ec68bfe27a2  push rax
00007ec68bfe27a3  push rcx
00007ec68bfe27a4  push rdx
00007ec68bfe27a5  push rdi
00007ec68bfe27a6  push rsi
00007ec68bfe27a7  push r8
00007ec68bfe27a9  push r9
00007ec68bfe27ab  push r10
00007ec68bfe27ad  push r11
00007ec68bfe27af  sub rsp, 0xF0
00007ec68bfe27b6  vmovaps [rsp], xmm0
00007ec68bfe27bb  vmovaps [rsp+0x10], xmm1
00007ec68bfe27c1  vmovaps [rsp+0x20], xmm2
00007ec68bfe27c7  vmovaps [rsp+0x30], xmm3
00007ec68bfe27cd  vmovaps [rsp+0x40], xmm4
00007ec68bfe27d3  vmovaps [rsp+0x50], xmm5
00007ec68bfe27d9  vmovaps [rsp+0x60], xmm6
00007ec68bfe27df  vmovaps [rsp+0x70], xmm7
00007ec68bfe27e5  vmovaps [rsp+0x80], xmm8
00007ec68bfe27ee  vmovaps [rsp+0x90], xmm9
00007ec68bfe27f7  vmovaps [rsp+0xA0], xmm11
00007ec68bfe2800  vmovaps [rsp+0xB0], xmm12
00007ec68bfe2809  vmovaps [rsp+0xC0], xmm13
00007ec68bfe2812  vmovaps [rsp+0xD0], xmm14
00007ec68bfe281b  vmovaps [rsp+0xE0], xmm15
00007ec68bfe2824  sub rsp, 0x30
00007ec68bfe2828  movaps [rsp], xmm10
00007ec68bfe282d  movaps [rsp+0x10], xmm8
00007ec68bfe2833  movaps [rsp+0x20], xmm14
00007ec68bfe2839  lea rdi, [rsp]
00007ec68bfe283d  mov esi, 0x00
00007ec68bfe2842  mov rax, 0x57D97DADF530
00007ec68bfe284c  call rax
00007ec68bfe284e  movaps xmm10, [rsp]
00007ec68bfe2853  add rsp, 0x30
00007ec68bfe2857  vmovaps xmm0, [rsp]
00007ec68bfe285c  vmovaps xmm1, [rsp+0x10]
00007ec68bfe2862  vmovaps xmm2, [rsp+0x20]
00007ec68bfe2868  vmovaps xmm3, [rsp+0x30]
00007ec68bfe286e  vmovaps xmm4, [rsp+0x40]
00007ec68bfe2874  vmovaps xmm5, [rsp+0x50]
00007ec68bfe287a  vmovaps xmm6, [rsp+0x60]
00007ec68bfe2880  vmovaps xmm7, [rsp+0x70]
00007ec68bfe2886  vmovaps xmm8, [rsp+0x80]
00007ec68bfe288f  vmovaps xmm9, [rsp+0x90]
00007ec68bfe2898  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe28a1  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe28aa  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe28b3  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe28bc  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe28c5  add rsp, 0xF0
00007ec68bfe28cc  pop r11
00007ec68bfe28ce  pop r10
00007ec68bfe28d0  pop r9
00007ec68bfe28d2  pop r8
00007ec68bfe28d4  pop rsi
00007ec68bfe28d5  pop rdi
00007ec68bfe28d6  pop rdx
00007ec68bfe28d7  pop rcx
00007ec68bfe28d8  pop rax
00007ec68bfe28d9  add rsp, 0x08
00007ec68bfe28dd  jmp 0x00007EC68BFDF5D8
00007ec68bfe28e2  sub rsp, 0x08
00007ec68bfe28e6  push rax
00007ec68bfe28e7  push rcx
00007ec68bfe28e8  push rdx
00007ec68bfe28e9  push rdi
00007ec68bfe28ea  push rsi
00007ec68bfe28eb  push r8
00007ec68bfe28ed  push r9
00007ec68bfe28ef  push r10
00007ec68bfe28f1  push r11
00007ec68bfe28f3  sub rsp, 0xF0
00007ec68bfe28fa  vmovaps [rsp], xmm0
00007ec68bfe28ff  vmovaps [rsp+0x10], xmm1
00007ec68bfe2905  vmovaps [rsp+0x20], xmm2
00007ec68bfe290b  vmovaps [rsp+0x30], xmm3
00007ec68bfe2911  vmovaps [rsp+0x40], xmm4
00007ec68bfe2917  vmovaps [rsp+0x50], xmm5
00007ec68bfe291d  vmovaps [rsp+0x60], xmm6
00007ec68bfe2923  vmovaps [rsp+0x70], xmm7
00007ec68bfe2929  vmovaps [rsp+0x80], xmm8
00007ec68bfe2932  vmovaps [rsp+0x90], xmm9
00007ec68bfe293b  vmovaps [rsp+0xA0], xmm10
00007ec68bfe2944  vmovaps [rsp+0xB0], xmm11
00007ec68bfe294d  vmovaps [rsp+0xC0], xmm12
00007ec68bfe2956  vmovaps [rsp+0xD0], xmm13
00007ec68bfe295f  vmovaps [rsp+0xE0], xmm15
00007ec68bfe2968  sub rsp, 0x30
00007ec68bfe296c  movaps [rsp], xmm14
00007ec68bfe2971  movaps [rsp+0x10], xmm8
00007ec68bfe2977  movaps [rsp+0x20], xmm4
00007ec68bfe297c  lea rdi, [rsp]
00007ec68bfe2980  mov esi, 0x00
00007ec68bfe2985  mov rax, 0x57D97DADF530
00007ec68bfe298f  call rax
00007ec68bfe2991  movaps xmm14, [rsp]
00007ec68bfe2996  add rsp, 0x30
00007ec68bfe299a  vmovaps xmm0, [rsp]
00007ec68bfe299f  vmovaps xmm1, [rsp+0x10]
00007ec68bfe29a5  vmovaps xmm2, [rsp+0x20]
00007ec68bfe29ab  vmovaps xmm3, [rsp+0x30]
00007ec68bfe29b1  vmovaps xmm4, [rsp+0x40]
00007ec68bfe29b7  vmovaps xmm5, [rsp+0x50]
00007ec68bfe29bd  vmovaps xmm6, [rsp+0x60]
00007ec68bfe29c3  vmovaps xmm7, [rsp+0x70]
00007ec68bfe29c9  vmovaps xmm8, [rsp+0x80]
00007ec68bfe29d2  vmovaps xmm9, [rsp+0x90]
00007ec68bfe29db  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe29e4  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe29ed  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe29f6  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe29ff  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe2a08  add rsp, 0xF0
00007ec68bfe2a0f  pop r11
00007ec68bfe2a11  pop r10
00007ec68bfe2a13  pop r9
00007ec68bfe2a15  pop r8
00007ec68bfe2a17  pop rsi
00007ec68bfe2a18  pop rdi
00007ec68bfe2a19  pop rdx
00007ec68bfe2a1a  pop rcx
00007ec68bfe2a1b  pop rax
00007ec68bfe2a1c  add rsp, 0x08
00007ec68bfe2a20  jmp 0x00007EC68BFDF5F8
00007ec68bfe2a25  sub rsp, 0x08
00007ec68bfe2a29  push rax
00007ec68bfe2a2a  push rcx
00007ec68bfe2a2b  push rdx
00007ec68bfe2a2c  push rdi
00007ec68bfe2a2d  push rsi
00007ec68bfe2a2e  push r8
00007ec68bfe2a30  push r9
00007ec68bfe2a32  push r10
00007ec68bfe2a34  push r11
00007ec68bfe2a36  sub rsp, 0xF0
00007ec68bfe2a3d  vmovaps [rsp], xmm0
00007ec68bfe2a42  vmovaps [rsp+0x10], xmm1
00007ec68bfe2a48  vmovaps [rsp+0x20], xmm2
00007ec68bfe2a4e  vmovaps [rsp+0x30], xmm3
00007ec68bfe2a54  vmovaps [rsp+0x40], xmm5
00007ec68bfe2a5a  vmovaps [rsp+0x50], xmm6
00007ec68bfe2a60  vmovaps [rsp+0x60], xmm7
00007ec68bfe2a66  vmovaps [rsp+0x70], xmm8
00007ec68bfe2a6c  vmovaps [rsp+0x80], xmm9
00007ec68bfe2a75  vmovaps [rsp+0x90], xmm10
00007ec68bfe2a7e  vmovaps [rsp+0xA0], xmm11
00007ec68bfe2a87  vmovaps [rsp+0xB0], xmm12
00007ec68bfe2a90  vmovaps [rsp+0xC0], xmm13
00007ec68bfe2a99  vmovaps [rsp+0xD0], xmm14
00007ec68bfe2aa2  vmovaps [rsp+0xE0], xmm15
00007ec68bfe2aab  sub rsp, 0x30
00007ec68bfe2aaf  movaps [rsp], xmm4
00007ec68bfe2ab3  movaps [rsp+0x10], xmm13
00007ec68bfe2ab9  movaps [rsp+0x20], xmm8
00007ec68bfe2abf  lea rdi, [rsp]
00007ec68bfe2ac3  mov esi, 0x00
00007ec68bfe2ac8  mov rax, 0x57D97DADF530
00007ec68bfe2ad2  call rax
00007ec68bfe2ad4  movaps xmm4, [rsp]
00007ec68bfe2ad8  add rsp, 0x30
00007ec68bfe2adc  vmovaps xmm0, [rsp]
00007ec68bfe2ae1  vmovaps xmm1, [rsp+0x10]
00007ec68bfe2ae7  vmovaps xmm2, [rsp+0x20]
00007ec68bfe2aed  vmovaps xmm3, [rsp+0x30]
00007ec68bfe2af3  vmovaps xmm5, [rsp+0x40]
00007ec68bfe2af9  vmovaps xmm6, [rsp+0x50]
00007ec68bfe2aff  vmovaps xmm7, [rsp+0x60]
00007ec68bfe2b05  vmovaps xmm8, [rsp+0x70]
00007ec68bfe2b0b  vmovaps xmm9, [rsp+0x80]
00007ec68bfe2b14  vmovaps xmm10, [rsp+0x90]
00007ec68bfe2b1d  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe2b26  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe2b2f  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe2b38  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe2b41  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe2b4a  add rsp, 0xF0
00007ec68bfe2b51  pop r11
00007ec68bfe2b53  pop r10
00007ec68bfe2b55  pop r9
00007ec68bfe2b57  pop r8
00007ec68bfe2b59  pop rsi
00007ec68bfe2b5a  pop rdi
00007ec68bfe2b5b  pop rdx
00007ec68bfe2b5c  pop rcx
00007ec68bfe2b5d  pop rax
00007ec68bfe2b5e  add rsp, 0x08
00007ec68bfe2b62  jmp 0x00007EC68BFDF61D
00007ec68bfe2b67  sub rsp, 0x08
00007ec68bfe2b6b  push rax
00007ec68bfe2b6c  push rcx
00007ec68bfe2b6d  push rdx
00007ec68bfe2b6e  push rdi
00007ec68bfe2b6f  push rsi
00007ec68bfe2b70  push r8
00007ec68bfe2b72  push r9
00007ec68bfe2b74  push r10
00007ec68bfe2b76  push r11
00007ec68bfe2b78  sub rsp, 0xF0
00007ec68bfe2b7f  vmovaps [rsp], xmm0
00007ec68bfe2b84  vmovaps [rsp+0x10], xmm1
00007ec68bfe2b8a  vmovaps [rsp+0x20], xmm2
00007ec68bfe2b90  vmovaps [rsp+0x30], xmm3
00007ec68bfe2b96  vmovaps [rsp+0x40], xmm4
00007ec68bfe2b9c  vmovaps [rsp+0x50], xmm5
00007ec68bfe2ba2  vmovaps [rsp+0x60], xmm6
00007ec68bfe2ba8  vmovaps [rsp+0x70], xmm7
00007ec68bfe2bae  vmovaps [rsp+0x80], xmm8
00007ec68bfe2bb7  vmovaps [rsp+0x90], xmm9
00007ec68bfe2bc0  vmovaps [rsp+0xA0], xmm10
00007ec68bfe2bc9  vmovaps [rsp+0xB0], xmm11
00007ec68bfe2bd2  vmovaps [rsp+0xC0], xmm12
00007ec68bfe2bdb  vmovaps [rsp+0xD0], xmm14
00007ec68bfe2be4  vmovaps [rsp+0xE0], xmm15
00007ec68bfe2bed  sub rsp, 0x30
00007ec68bfe2bf1  movaps [rsp], xmm13
00007ec68bfe2bf6  movaps [rsp+0x10], xmm15
00007ec68bfe2bfc  movaps [rsp+0x20], xmm9
00007ec68bfe2c02  lea rdi, [rsp]
00007ec68bfe2c06  mov esi, 0x00
00007ec68bfe2c0b  mov rax, 0x57D97DADF530
00007ec68bfe2c15  call rax
00007ec68bfe2c17  movaps xmm13, [rsp]
00007ec68bfe2c1c  add rsp, 0x30
00007ec68bfe2c20  vmovaps xmm0, [rsp]
00007ec68bfe2c25  vmovaps xmm1, [rsp+0x10]
00007ec68bfe2c2b  vmovaps xmm2, [rsp+0x20]
00007ec68bfe2c31  vmovaps xmm3, [rsp+0x30]
00007ec68bfe2c37  vmovaps xmm4, [rsp+0x40]
00007ec68bfe2c3d  vmovaps xmm5, [rsp+0x50]
00007ec68bfe2c43  vmovaps xmm6, [rsp+0x60]
00007ec68bfe2c49  vmovaps xmm7, [rsp+0x70]
00007ec68bfe2c4f  vmovaps xmm8, [rsp+0x80]
00007ec68bfe2c58  vmovaps xmm9, [rsp+0x90]
00007ec68bfe2c61  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe2c6a  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe2c73  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe2c7c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe2c85  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe2c8e  add rsp, 0xF0
00007ec68bfe2c95  pop r11
00007ec68bfe2c97  pop r10
00007ec68bfe2c99  pop r9
00007ec68bfe2c9b  pop r8
00007ec68bfe2c9d  pop rsi
00007ec68bfe2c9e  pop rdi
00007ec68bfe2c9f  pop rdx
00007ec68bfe2ca0  pop rcx
00007ec68bfe2ca1  pop rax
00007ec68bfe2ca2  add rsp, 0x08
00007ec68bfe2ca6  jmp 0x00007EC68BFDF638
00007ec68bfe2cab  sub rsp, 0x08
00007ec68bfe2caf  push rax
00007ec68bfe2cb0  push rcx
00007ec68bfe2cb1  push rdx
00007ec68bfe2cb2  push rdi
00007ec68bfe2cb3  push rsi
00007ec68bfe2cb4  push r8
00007ec68bfe2cb6  push r9
00007ec68bfe2cb8  push r10
00007ec68bfe2cba  push r11
00007ec68bfe2cbc  sub rsp, 0xF0
00007ec68bfe2cc3  vmovaps [rsp], xmm0
00007ec68bfe2cc8  vmovaps [rsp+0x10], xmm1
00007ec68bfe2cce  vmovaps [rsp+0x20], xmm2
00007ec68bfe2cd4  vmovaps [rsp+0x30], xmm3
00007ec68bfe2cda  vmovaps [rsp+0x40], xmm4
00007ec68bfe2ce0  vmovaps [rsp+0x50], xmm5
00007ec68bfe2ce6  vmovaps [rsp+0x60], xmm6
00007ec68bfe2cec  vmovaps [rsp+0x70], xmm7
00007ec68bfe2cf2  vmovaps [rsp+0x80], xmm8
00007ec68bfe2cfb  vmovaps [rsp+0x90], xmm9
00007ec68bfe2d04  vmovaps [rsp+0xA0], xmm10
00007ec68bfe2d0d  vmovaps [rsp+0xB0], xmm11
00007ec68bfe2d16  vmovaps [rsp+0xC0], xmm12
00007ec68bfe2d1f  vmovaps [rsp+0xD0], xmm13
00007ec68bfe2d28  vmovaps [rsp+0xE0], xmm14
00007ec68bfe2d31  sub rsp, 0x30
00007ec68bfe2d35  movaps [rsp], xmm15
00007ec68bfe2d3a  movaps [rsp+0x10], xmm1
00007ec68bfe2d3f  movaps [rsp+0x20], xmm5
00007ec68bfe2d44  lea rdi, [rsp]
00007ec68bfe2d48  mov esi, 0x00
00007ec68bfe2d4d  mov rax, 0x57D97DADF530
00007ec68bfe2d57  call rax
00007ec68bfe2d59  movaps xmm15, [rsp]
00007ec68bfe2d5e  add rsp, 0x30
00007ec68bfe2d62  vmovaps xmm0, [rsp]
00007ec68bfe2d67  vmovaps xmm1, [rsp+0x10]
00007ec68bfe2d6d  vmovaps xmm2, [rsp+0x20]
00007ec68bfe2d73  vmovaps xmm3, [rsp+0x30]
00007ec68bfe2d79  vmovaps xmm4, [rsp+0x40]
00007ec68bfe2d7f  vmovaps xmm5, [rsp+0x50]
00007ec68bfe2d85  vmovaps xmm6, [rsp+0x60]
00007ec68bfe2d8b  vmovaps xmm7, [rsp+0x70]
00007ec68bfe2d91  vmovaps xmm8, [rsp+0x80]
00007ec68bfe2d9a  vmovaps xmm9, [rsp+0x90]
00007ec68bfe2da3  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe2dac  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe2db5  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe2dbe  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe2dc7  vmovaps xmm14, [rsp+0xE0]
00007ec68bfe2dd0  add rsp, 0xF0
00007ec68bfe2dd7  pop r11
00007ec68bfe2dd9  pop r10
00007ec68bfe2ddb  pop r9
00007ec68bfe2ddd  pop r8
00007ec68bfe2ddf  pop rsi
00007ec68bfe2de0  pop rdi
00007ec68bfe2de1  pop rdx
00007ec68bfe2de2  pop rcx
00007ec68bfe2de3  pop rax
00007ec68bfe2de4  add rsp, 0x08
00007ec68bfe2de8  jmp 0x00007EC68BFDF653
00007ec68bfe2ded  call 0x00007EC68BEB52F0
00007ec68bfe2df2  jmp 0x00007EC68BFDF6AE
00007ec68bfe2df7  sub rsp, 0x08
00007ec68bfe2dfb  push rax
00007ec68bfe2dfc  push rcx
00007ec68bfe2dfd  push rdx
00007ec68bfe2dfe  push rdi
00007ec68bfe2dff  push rsi
00007ec68bfe2e00  push r8
00007ec68bfe2e02  push r9
00007ec68bfe2e04  push r10
00007ec68bfe2e06  push r11
00007ec68bfe2e08  sub rsp, 0xF0
00007ec68bfe2e0f  vmovaps [rsp], xmm0
00007ec68bfe2e14  vmovaps [rsp+0x10], xmm1
00007ec68bfe2e1a  vmovaps [rsp+0x20], xmm2
00007ec68bfe2e20  vmovaps [rsp+0x30], xmm3
00007ec68bfe2e26  vmovaps [rsp+0x40], xmm4
00007ec68bfe2e2c  vmovaps [rsp+0x50], xmm5
00007ec68bfe2e32  vmovaps [rsp+0x60], xmm6
00007ec68bfe2e38  vmovaps [rsp+0x70], xmm7
00007ec68bfe2e3e  vmovaps [rsp+0x80], xmm8
00007ec68bfe2e47  vmovaps [rsp+0x90], xmm10
00007ec68bfe2e50  vmovaps [rsp+0xA0], xmm11
00007ec68bfe2e59  vmovaps [rsp+0xB0], xmm12
00007ec68bfe2e62  vmovaps [rsp+0xC0], xmm13
00007ec68bfe2e6b  vmovaps [rsp+0xD0], xmm14
00007ec68bfe2e74  vmovaps [rsp+0xE0], xmm15
00007ec68bfe2e7d  sub rsp, 0x30
00007ec68bfe2e81  movaps [rsp], xmm9
00007ec68bfe2e86  movaps [rsp+0x10], xmm8
00007ec68bfe2e8c  movaps [rsp+0x20], xmm11
00007ec68bfe2e92  lea rdi, [rsp]
00007ec68bfe2e96  mov esi, 0x00
00007ec68bfe2e9b  mov rax, 0x57D97DADF530
00007ec68bfe2ea5  call rax
00007ec68bfe2ea7  movaps xmm9, [rsp]
00007ec68bfe2eac  add rsp, 0x30
00007ec68bfe2eb0  vmovaps xmm0, [rsp]
00007ec68bfe2eb5  vmovaps xmm1, [rsp+0x10]
00007ec68bfe2ebb  vmovaps xmm2, [rsp+0x20]
00007ec68bfe2ec1  vmovaps xmm3, [rsp+0x30]
00007ec68bfe2ec7  vmovaps xmm4, [rsp+0x40]
00007ec68bfe2ecd  vmovaps xmm5, [rsp+0x50]
00007ec68bfe2ed3  vmovaps xmm6, [rsp+0x60]
00007ec68bfe2ed9  vmovaps xmm7, [rsp+0x70]
00007ec68bfe2edf  vmovaps xmm8, [rsp+0x80]
00007ec68bfe2ee8  vmovaps xmm10, [rsp+0x90]
00007ec68bfe2ef1  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe2efa  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe2f03  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe2f0c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe2f15  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe2f1e  add rsp, 0xF0
00007ec68bfe2f25  pop r11
00007ec68bfe2f27  pop r10
00007ec68bfe2f29  pop r9
00007ec68bfe2f2b  pop r8
00007ec68bfe2f2d  pop rsi
00007ec68bfe2f2e  pop rdi
00007ec68bfe2f2f  pop rdx
00007ec68bfe2f30  pop rcx
00007ec68bfe2f31  pop rax
00007ec68bfe2f32  add rsp, 0x08
00007ec68bfe2f36  jmp 0x00007EC68BFDF6E5
00007ec68bfe2f3b  sub rsp, 0x08
00007ec68bfe2f3f  push rax
00007ec68bfe2f40  push rcx
00007ec68bfe2f41  push rdx
00007ec68bfe2f42  push rdi
00007ec68bfe2f43  push rsi
00007ec68bfe2f44  push r8
00007ec68bfe2f46  push r9
00007ec68bfe2f48  push r10
00007ec68bfe2f4a  push r11
00007ec68bfe2f4c  sub rsp, 0xF0
00007ec68bfe2f53  vmovaps [rsp], xmm0
00007ec68bfe2f58  vmovaps [rsp+0x10], xmm1
00007ec68bfe2f5e  vmovaps [rsp+0x20], xmm2
00007ec68bfe2f64  vmovaps [rsp+0x30], xmm3
00007ec68bfe2f6a  vmovaps [rsp+0x40], xmm4
00007ec68bfe2f70  vmovaps [rsp+0x50], xmm5
00007ec68bfe2f76  vmovaps [rsp+0x60], xmm6
00007ec68bfe2f7c  vmovaps [rsp+0x70], xmm7
00007ec68bfe2f82  vmovaps [rsp+0x80], xmm8
00007ec68bfe2f8b  vmovaps [rsp+0x90], xmm9
00007ec68bfe2f94  vmovaps [rsp+0xA0], xmm10
00007ec68bfe2f9d  vmovaps [rsp+0xB0], xmm12
00007ec68bfe2fa6  vmovaps [rsp+0xC0], xmm13
00007ec68bfe2faf  vmovaps [rsp+0xD0], xmm14
00007ec68bfe2fb8  vmovaps [rsp+0xE0], xmm15
00007ec68bfe2fc1  sub rsp, 0x30
00007ec68bfe2fc5  movaps [rsp], xmm11
00007ec68bfe2fca  movaps [rsp+0x10], xmm10
00007ec68bfe2fd0  movaps [rsp+0x20], xmm6
00007ec68bfe2fd5  lea rdi, [rsp]
00007ec68bfe2fd9  mov esi, 0x00
00007ec68bfe2fde  mov rax, 0x57D97DADF530
00007ec68bfe2fe8  call rax
00007ec68bfe2fea  movaps xmm11, [rsp]
00007ec68bfe2fef  add rsp, 0x30
00007ec68bfe2ff3  vmovaps xmm0, [rsp]
00007ec68bfe2ff8  vmovaps xmm1, [rsp+0x10]
00007ec68bfe2ffe  vmovaps xmm2, [rsp+0x20]
00007ec68bfe3004  vmovaps xmm3, [rsp+0x30]
00007ec68bfe300a  vmovaps xmm4, [rsp+0x40]
00007ec68bfe3010  vmovaps xmm5, [rsp+0x50]
00007ec68bfe3016  vmovaps xmm6, [rsp+0x60]
00007ec68bfe301c  vmovaps xmm7, [rsp+0x70]
00007ec68bfe3022  vmovaps xmm8, [rsp+0x80]
00007ec68bfe302b  vmovaps xmm9, [rsp+0x90]
00007ec68bfe3034  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe303d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe3046  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe304f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe3058  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe3061  add rsp, 0xF0
00007ec68bfe3068  pop r11
00007ec68bfe306a  pop r10
00007ec68bfe306c  pop r9
00007ec68bfe306e  pop r8
00007ec68bfe3070  pop rsi
00007ec68bfe3071  pop rdi
00007ec68bfe3072  pop rdx
00007ec68bfe3073  pop rcx
00007ec68bfe3074  pop rax
00007ec68bfe3075  add rsp, 0x08
00007ec68bfe3079  jmp 0x00007EC68BFDF700
00007ec68bfe307e  sub rsp, 0x08
00007ec68bfe3082  push rax
00007ec68bfe3083  push rcx
00007ec68bfe3084  push rdx
00007ec68bfe3085  push rdi
00007ec68bfe3086  push rsi
00007ec68bfe3087  push r8
00007ec68bfe3089  push r9
00007ec68bfe308b  push r10
00007ec68bfe308d  push r11
00007ec68bfe308f  sub rsp, 0xF0
00007ec68bfe3096  vmovaps [rsp], xmm0
00007ec68bfe309b  vmovaps [rsp+0x10], xmm1
00007ec68bfe30a1  vmovaps [rsp+0x20], xmm2
00007ec68bfe30a7  vmovaps [rsp+0x30], xmm3
00007ec68bfe30ad  vmovaps [rsp+0x40], xmm4
00007ec68bfe30b3  vmovaps [rsp+0x50], xmm5
00007ec68bfe30b9  vmovaps [rsp+0x60], xmm6
00007ec68bfe30bf  vmovaps [rsp+0x70], xmm7
00007ec68bfe30c5  vmovaps [rsp+0x80], xmm8
00007ec68bfe30ce  vmovaps [rsp+0x90], xmm9
00007ec68bfe30d7  vmovaps [rsp+0xA0], xmm11
00007ec68bfe30e0  vmovaps [rsp+0xB0], xmm12
00007ec68bfe30e9  vmovaps [rsp+0xC0], xmm13
00007ec68bfe30f2  vmovaps [rsp+0xD0], xmm14
00007ec68bfe30fb  vmovaps [rsp+0xE0], xmm15
00007ec68bfe3104  sub rsp, 0x30
00007ec68bfe3108  movaps [rsp], xmm10
00007ec68bfe310d  movaps [rsp+0x10], xmm14
00007ec68bfe3113  movaps [rsp+0x20], xmm4
00007ec68bfe3118  lea rdi, [rsp]
00007ec68bfe311c  mov esi, 0x00
00007ec68bfe3121  mov rax, 0x57D97DADF530
00007ec68bfe312b  call rax
00007ec68bfe312d  movaps xmm10, [rsp]
00007ec68bfe3132  add rsp, 0x30
00007ec68bfe3136  vmovaps xmm0, [rsp]
00007ec68bfe313b  vmovaps xmm1, [rsp+0x10]
00007ec68bfe3141  vmovaps xmm2, [rsp+0x20]
00007ec68bfe3147  vmovaps xmm3, [rsp+0x30]
00007ec68bfe314d  vmovaps xmm4, [rsp+0x40]
00007ec68bfe3153  vmovaps xmm5, [rsp+0x50]
00007ec68bfe3159  vmovaps xmm6, [rsp+0x60]
00007ec68bfe315f  vmovaps xmm7, [rsp+0x70]
00007ec68bfe3165  vmovaps xmm8, [rsp+0x80]
00007ec68bfe316e  vmovaps xmm9, [rsp+0x90]
00007ec68bfe3177  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe3180  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe3189  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe3192  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe319b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe31a4  add rsp, 0xF0
00007ec68bfe31ab  pop r11
00007ec68bfe31ad  pop r10
00007ec68bfe31af  pop r9
00007ec68bfe31b1  pop r8
00007ec68bfe31b3  pop rsi
00007ec68bfe31b4  pop rdi
00007ec68bfe31b5  pop rdx
00007ec68bfe31b6  pop rcx
00007ec68bfe31b7  pop rax
00007ec68bfe31b8  add rsp, 0x08
00007ec68bfe31bc  jmp 0x00007EC68BFDF71B
00007ec68bfe31c1  sub rsp, 0x08
00007ec68bfe31c5  push rax
00007ec68bfe31c6  push rcx
00007ec68bfe31c7  push rdx
00007ec68bfe31c8  push rdi
00007ec68bfe31c9  push rsi
00007ec68bfe31ca  push r8
00007ec68bfe31cc  push r9
00007ec68bfe31ce  push r10
00007ec68bfe31d0  push r11
00007ec68bfe31d2  sub rsp, 0xF0
00007ec68bfe31d9  vmovaps [rsp], xmm0
00007ec68bfe31de  vmovaps [rsp+0x10], xmm1
00007ec68bfe31e4  vmovaps [rsp+0x20], xmm2
00007ec68bfe31ea  vmovaps [rsp+0x30], xmm3
00007ec68bfe31f0  vmovaps [rsp+0x40], xmm4
00007ec68bfe31f6  vmovaps [rsp+0x50], xmm5
00007ec68bfe31fc  vmovaps [rsp+0x60], xmm6
00007ec68bfe3202  vmovaps [rsp+0x70], xmm7
00007ec68bfe3208  vmovaps [rsp+0x80], xmm9
00007ec68bfe3211  vmovaps [rsp+0x90], xmm10
00007ec68bfe321a  vmovaps [rsp+0xA0], xmm11
00007ec68bfe3223  vmovaps [rsp+0xB0], xmm12
00007ec68bfe322c  vmovaps [rsp+0xC0], xmm13
00007ec68bfe3235  vmovaps [rsp+0xD0], xmm14
00007ec68bfe323e  vmovaps [rsp+0xE0], xmm15
00007ec68bfe3247  sub rsp, 0x30
00007ec68bfe324b  movaps [rsp], xmm8
00007ec68bfe3250  movaps [rsp+0x10], xmm1
00007ec68bfe3255  movaps [rsp+0x20], xmm14
00007ec68bfe325b  lea rdi, [rsp]
00007ec68bfe325f  mov esi, 0x00
00007ec68bfe3264  mov rax, 0x57D97DADF530
00007ec68bfe326e  call rax
00007ec68bfe3270  movaps xmm8, [rsp]
00007ec68bfe3275  add rsp, 0x30
00007ec68bfe3279  vmovaps xmm0, [rsp]
00007ec68bfe327e  vmovaps xmm1, [rsp+0x10]
00007ec68bfe3284  vmovaps xmm2, [rsp+0x20]
00007ec68bfe328a  vmovaps xmm3, [rsp+0x30]
00007ec68bfe3290  vmovaps xmm4, [rsp+0x40]
00007ec68bfe3296  vmovaps xmm5, [rsp+0x50]
00007ec68bfe329c  vmovaps xmm6, [rsp+0x60]
00007ec68bfe32a2  vmovaps xmm7, [rsp+0x70]
00007ec68bfe32a8  vmovaps xmm9, [rsp+0x80]
00007ec68bfe32b1  vmovaps xmm10, [rsp+0x90]
00007ec68bfe32ba  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe32c3  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe32cc  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe32d5  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe32de  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe32e7  add rsp, 0xF0
00007ec68bfe32ee  pop r11
00007ec68bfe32f0  pop r10
00007ec68bfe32f2  pop r9
00007ec68bfe32f4  pop r8
00007ec68bfe32f6  pop rsi
00007ec68bfe32f7  pop rdi
00007ec68bfe32f8  pop rdx
00007ec68bfe32f9  pop rcx
00007ec68bfe32fa  pop rax
00007ec68bfe32fb  add rsp, 0x08
00007ec68bfe32ff  jmp 0x00007EC68BFDF741
00007ec68bfe3304  sub rsp, 0x08
00007ec68bfe3308  push rax
00007ec68bfe3309  push rcx
00007ec68bfe330a  push rdx
00007ec68bfe330b  push rdi
00007ec68bfe330c  push rsi
00007ec68bfe330d  push r8
00007ec68bfe330f  push r9
00007ec68bfe3311  push r10
00007ec68bfe3313  push r11
00007ec68bfe3315  sub rsp, 0xF0
00007ec68bfe331c  vmovaps [rsp], xmm0
00007ec68bfe3321  vmovaps [rsp+0x10], xmm1
00007ec68bfe3327  vmovaps [rsp+0x20], xmm2
00007ec68bfe332d  vmovaps [rsp+0x30], xmm3
00007ec68bfe3333  vmovaps [rsp+0x40], xmm4
00007ec68bfe3339  vmovaps [rsp+0x50], xmm5
00007ec68bfe333f  vmovaps [rsp+0x60], xmm7
00007ec68bfe3345  vmovaps [rsp+0x70], xmm8
00007ec68bfe334b  vmovaps [rsp+0x80], xmm9
00007ec68bfe3354  vmovaps [rsp+0x90], xmm10
00007ec68bfe335d  vmovaps [rsp+0xA0], xmm11
00007ec68bfe3366  vmovaps [rsp+0xB0], xmm12
00007ec68bfe336f  vmovaps [rsp+0xC0], xmm13
00007ec68bfe3378  vmovaps [rsp+0xD0], xmm14
00007ec68bfe3381  vmovaps [rsp+0xE0], xmm15
00007ec68bfe338a  sub rsp, 0x30
00007ec68bfe338e  movaps [rsp], xmm6
00007ec68bfe3392  movaps [rsp+0x10], xmm1
00007ec68bfe3397  movaps [rsp+0x20], xmm14
00007ec68bfe339d  lea rdi, [rsp]
00007ec68bfe33a1  mov esi, 0x00
00007ec68bfe33a6  mov rax, 0x57D97DADF530
00007ec68bfe33b0  call rax
00007ec68bfe33b2  movaps xmm6, [rsp]
00007ec68bfe33b6  add rsp, 0x30
00007ec68bfe33ba  vmovaps xmm0, [rsp]
00007ec68bfe33bf  vmovaps xmm1, [rsp+0x10]
00007ec68bfe33c5  vmovaps xmm2, [rsp+0x20]
00007ec68bfe33cb  vmovaps xmm3, [rsp+0x30]
00007ec68bfe33d1  vmovaps xmm4, [rsp+0x40]
00007ec68bfe33d7  vmovaps xmm5, [rsp+0x50]
00007ec68bfe33dd  vmovaps xmm7, [rsp+0x60]
00007ec68bfe33e3  vmovaps xmm8, [rsp+0x70]
00007ec68bfe33e9  vmovaps xmm9, [rsp+0x80]
00007ec68bfe33f2  vmovaps xmm10, [rsp+0x90]
00007ec68bfe33fb  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe3404  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe340d  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe3416  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe341f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe3428  add rsp, 0xF0
00007ec68bfe342f  pop r11
00007ec68bfe3431  pop r10
00007ec68bfe3433  pop r9
00007ec68bfe3435  pop r8
00007ec68bfe3437  pop rsi
00007ec68bfe3438  pop rdi
00007ec68bfe3439  pop rdx
00007ec68bfe343a  pop rcx
00007ec68bfe343b  pop rax
00007ec68bfe343c  add rsp, 0x08
00007ec68bfe3440  jmp 0x00007EC68BFDF76D
00007ec68bfe3445  sub rsp, 0x08
00007ec68bfe3449  push rax
00007ec68bfe344a  push rcx
00007ec68bfe344b  push rdx
00007ec68bfe344c  push rdi
00007ec68bfe344d  push rsi
00007ec68bfe344e  push r8
00007ec68bfe3450  push r9
00007ec68bfe3452  push r10
00007ec68bfe3454  push r11
00007ec68bfe3456  sub rsp, 0xF0
00007ec68bfe345d  vmovaps [rsp], xmm0
00007ec68bfe3462  vmovaps [rsp+0x10], xmm1
00007ec68bfe3468  vmovaps [rsp+0x20], xmm2
00007ec68bfe346e  vmovaps [rsp+0x30], xmm3
00007ec68bfe3474  vmovaps [rsp+0x40], xmm4
00007ec68bfe347a  vmovaps [rsp+0x50], xmm5
00007ec68bfe3480  vmovaps [rsp+0x60], xmm6
00007ec68bfe3486  vmovaps [rsp+0x70], xmm7
00007ec68bfe348c  vmovaps [rsp+0x80], xmm8
00007ec68bfe3495  vmovaps [rsp+0x90], xmm9
00007ec68bfe349e  vmovaps [rsp+0xA0], xmm10
00007ec68bfe34a7  vmovaps [rsp+0xB0], xmm11
00007ec68bfe34b0  vmovaps [rsp+0xC0], xmm12
00007ec68bfe34b9  vmovaps [rsp+0xD0], xmm13
00007ec68bfe34c2  vmovaps [rsp+0xE0], xmm15
00007ec68bfe34cb  sub rsp, 0x30
00007ec68bfe34cf  movaps [rsp], xmm14
00007ec68bfe34d4  movaps [rsp+0x10], xmm12
00007ec68bfe34da  movaps [rsp+0x20], xmm1
00007ec68bfe34df  lea rdi, [rsp]
00007ec68bfe34e3  mov esi, 0x00
00007ec68bfe34e8  mov rax, 0x57D97DADF530
00007ec68bfe34f2  call rax
00007ec68bfe34f4  movaps xmm14, [rsp]
00007ec68bfe34f9  add rsp, 0x30
00007ec68bfe34fd  vmovaps xmm0, [rsp]
00007ec68bfe3502  vmovaps xmm1, [rsp+0x10]
00007ec68bfe3508  vmovaps xmm2, [rsp+0x20]
00007ec68bfe350e  vmovaps xmm3, [rsp+0x30]
00007ec68bfe3514  vmovaps xmm4, [rsp+0x40]
00007ec68bfe351a  vmovaps xmm5, [rsp+0x50]
00007ec68bfe3520  vmovaps xmm6, [rsp+0x60]
00007ec68bfe3526  vmovaps xmm7, [rsp+0x70]
00007ec68bfe352c  vmovaps xmm8, [rsp+0x80]
00007ec68bfe3535  vmovaps xmm9, [rsp+0x90]
00007ec68bfe353e  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe3547  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe3550  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe3559  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe3562  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe356b  add rsp, 0xF0
00007ec68bfe3572  pop r11
00007ec68bfe3574  pop r10
00007ec68bfe3576  pop r9
00007ec68bfe3578  pop r8
00007ec68bfe357a  pop rsi
00007ec68bfe357b  pop rdi
00007ec68bfe357c  pop rdx
00007ec68bfe357d  pop rcx
00007ec68bfe357e  pop rax
00007ec68bfe357f  add rsp, 0x08
00007ec68bfe3583  jmp 0x00007EC68BFDF793
00007ec68bfe3588  sub rsp, 0x08
00007ec68bfe358c  push rax
00007ec68bfe358d  push rcx
00007ec68bfe358e  push rdx
00007ec68bfe358f  push rdi
00007ec68bfe3590  push rsi
00007ec68bfe3591  push r8
00007ec68bfe3593  push r9
00007ec68bfe3595  push r10
00007ec68bfe3597  push r11
00007ec68bfe3599  sub rsp, 0xF0
00007ec68bfe35a0  vmovaps [rsp], xmm0
00007ec68bfe35a5  vmovaps [rsp+0x10], xmm2
00007ec68bfe35ab  vmovaps [rsp+0x20], xmm3
00007ec68bfe35b1  vmovaps [rsp+0x30], xmm4
00007ec68bfe35b7  vmovaps [rsp+0x40], xmm5
00007ec68bfe35bd  vmovaps [rsp+0x50], xmm6
00007ec68bfe35c3  vmovaps [rsp+0x60], xmm7
00007ec68bfe35c9  vmovaps [rsp+0x70], xmm8
00007ec68bfe35cf  vmovaps [rsp+0x80], xmm9
00007ec68bfe35d8  vmovaps [rsp+0x90], xmm10
00007ec68bfe35e1  vmovaps [rsp+0xA0], xmm11
00007ec68bfe35ea  vmovaps [rsp+0xB0], xmm12
00007ec68bfe35f3  vmovaps [rsp+0xC0], xmm13
00007ec68bfe35fc  vmovaps [rsp+0xD0], xmm14
00007ec68bfe3605  vmovaps [rsp+0xE0], xmm15
00007ec68bfe360e  sub rsp, 0x30
00007ec68bfe3612  movaps [rsp], xmm1
00007ec68bfe3616  movaps [rsp+0x10], xmm13
00007ec68bfe361c  movaps [rsp+0x20], xmm9
00007ec68bfe3622  lea rdi, [rsp]
00007ec68bfe3626  mov esi, 0x00
00007ec68bfe362b  mov rax, 0x57D97DADF530
00007ec68bfe3635  call rax
00007ec68bfe3637  movaps xmm1, [rsp]
00007ec68bfe363b  add rsp, 0x30
00007ec68bfe363f  vmovaps xmm0, [rsp]
00007ec68bfe3644  vmovaps xmm2, [rsp+0x10]
00007ec68bfe364a  vmovaps xmm3, [rsp+0x20]
00007ec68bfe3650  vmovaps xmm4, [rsp+0x30]
00007ec68bfe3656  vmovaps xmm5, [rsp+0x40]
00007ec68bfe365c  vmovaps xmm6, [rsp+0x50]
00007ec68bfe3662  vmovaps xmm7, [rsp+0x60]
00007ec68bfe3668  vmovaps xmm8, [rsp+0x70]
00007ec68bfe366e  vmovaps xmm9, [rsp+0x80]
00007ec68bfe3677  vmovaps xmm10, [rsp+0x90]
00007ec68bfe3680  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe3689  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe3692  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe369b  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe36a4  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe36ad  add rsp, 0xF0
00007ec68bfe36b4  pop r11
00007ec68bfe36b6  pop r10
00007ec68bfe36b8  pop r9
00007ec68bfe36ba  pop r8
00007ec68bfe36bc  pop rsi
00007ec68bfe36bd  pop rdi
00007ec68bfe36be  pop rdx
00007ec68bfe36bf  pop rcx
00007ec68bfe36c0  pop rax
00007ec68bfe36c1  add rsp, 0x08
00007ec68bfe36c5  jmp 0x00007EC68BFDF7AD
00007ec68bfe36ca  sub rsp, 0x08
00007ec68bfe36ce  push rax
00007ec68bfe36cf  push rcx
00007ec68bfe36d0  push rdx
00007ec68bfe36d1  push rdi
00007ec68bfe36d2  push rsi
00007ec68bfe36d3  push r8
00007ec68bfe36d5  push r9
00007ec68bfe36d7  push r10
00007ec68bfe36d9  push r11
00007ec68bfe36db  sub rsp, 0xF0
00007ec68bfe36e2  vmovaps [rsp], xmm0
00007ec68bfe36e7  vmovaps [rsp+0x10], xmm1
00007ec68bfe36ed  vmovaps [rsp+0x20], xmm2
00007ec68bfe36f3  vmovaps [rsp+0x30], xmm3
00007ec68bfe36f9  vmovaps [rsp+0x40], xmm4
00007ec68bfe36ff  vmovaps [rsp+0x50], xmm5
00007ec68bfe3705  vmovaps [rsp+0x60], xmm6
00007ec68bfe370b  vmovaps [rsp+0x70], xmm7
00007ec68bfe3711  vmovaps [rsp+0x80], xmm8
00007ec68bfe371a  vmovaps [rsp+0x90], xmm9
00007ec68bfe3723  vmovaps [rsp+0xA0], xmm10
00007ec68bfe372c  vmovaps [rsp+0xB0], xmm11
00007ec68bfe3735  vmovaps [rsp+0xC0], xmm13
00007ec68bfe373e  vmovaps [rsp+0xD0], xmm14
00007ec68bfe3747  vmovaps [rsp+0xE0], xmm15
00007ec68bfe3750  sub rsp, 0x30
00007ec68bfe3754  movaps [rsp], xmm12
00007ec68bfe3759  movaps [rsp+0x10], xmm7
00007ec68bfe375e  movaps [rsp+0x20], xmm13
00007ec68bfe3764  lea rdi, [rsp]
00007ec68bfe3768  mov esi, 0x00
00007ec68bfe376d  mov rax, 0x57D97DADF530
00007ec68bfe3777  call rax
00007ec68bfe3779  movaps xmm12, [rsp]
00007ec68bfe377e  add rsp, 0x30
00007ec68bfe3782  vmovaps xmm0, [rsp]
00007ec68bfe3787  vmovaps xmm1, [rsp+0x10]
00007ec68bfe378d  vmovaps xmm2, [rsp+0x20]
00007ec68bfe3793  vmovaps xmm3, [rsp+0x30]
00007ec68bfe3799  vmovaps xmm4, [rsp+0x40]
00007ec68bfe379f  vmovaps xmm5, [rsp+0x50]
00007ec68bfe37a5  vmovaps xmm6, [rsp+0x60]
00007ec68bfe37ab  vmovaps xmm7, [rsp+0x70]
00007ec68bfe37b1  vmovaps xmm8, [rsp+0x80]
00007ec68bfe37ba  vmovaps xmm9, [rsp+0x90]
00007ec68bfe37c3  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe37cc  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe37d5  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe37de  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe37e7  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe37f0  add rsp, 0xF0
00007ec68bfe37f7  pop r11
00007ec68bfe37f9  pop r10
00007ec68bfe37fb  pop r9
00007ec68bfe37fd  pop r8
00007ec68bfe37ff  pop rsi
00007ec68bfe3800  pop rdi
00007ec68bfe3801  pop rdx
00007ec68bfe3802  pop rcx
00007ec68bfe3803  pop rax
00007ec68bfe3804  add rsp, 0x08
00007ec68bfe3808  jmp 0x00007EC68BFDF7D4
00007ec68bfe380d  sub rsp, 0x08
00007ec68bfe3811  push rax
00007ec68bfe3812  push rcx
00007ec68bfe3813  push rdx
00007ec68bfe3814  push rdi
00007ec68bfe3815  push rsi
00007ec68bfe3816  push r8
00007ec68bfe3818  push r9
00007ec68bfe381a  push r10
00007ec68bfe381c  push r11
00007ec68bfe381e  sub rsp, 0xF0
00007ec68bfe3825  vmovaps [rsp], xmm0
00007ec68bfe382a  vmovaps [rsp+0x10], xmm1
00007ec68bfe3830  vmovaps [rsp+0x20], xmm2
00007ec68bfe3836  vmovaps [rsp+0x30], xmm3
00007ec68bfe383c  vmovaps [rsp+0x40], xmm4
00007ec68bfe3842  vmovaps [rsp+0x50], xmm5
00007ec68bfe3848  vmovaps [rsp+0x60], xmm6
00007ec68bfe384e  vmovaps [rsp+0x70], xmm7
00007ec68bfe3854  vmovaps [rsp+0x80], xmm8
00007ec68bfe385d  vmovaps [rsp+0x90], xmm9
00007ec68bfe3866  vmovaps [rsp+0xA0], xmm10
00007ec68bfe386f  vmovaps [rsp+0xB0], xmm11
00007ec68bfe3878  vmovaps [rsp+0xC0], xmm12
00007ec68bfe3881  vmovaps [rsp+0xD0], xmm14
00007ec68bfe388a  vmovaps [rsp+0xE0], xmm15
00007ec68bfe3893  sub rsp, 0x30
00007ec68bfe3897  movaps [rsp], xmm13
00007ec68bfe389c  movaps [rsp+0x10], xmm15
00007ec68bfe38a2  movaps [rsp+0x20], xmm8
00007ec68bfe38a8  lea rdi, [rsp]
00007ec68bfe38ac  mov esi, 0x00
00007ec68bfe38b1  mov rax, 0x57D97DADF530
00007ec68bfe38bb  call rax
00007ec68bfe38bd  movaps xmm13, [rsp]
00007ec68bfe38c2  add rsp, 0x30
00007ec68bfe38c6  vmovaps xmm0, [rsp]
00007ec68bfe38cb  vmovaps xmm1, [rsp+0x10]
00007ec68bfe38d1  vmovaps xmm2, [rsp+0x20]
00007ec68bfe38d7  vmovaps xmm3, [rsp+0x30]
00007ec68bfe38dd  vmovaps xmm4, [rsp+0x40]
00007ec68bfe38e3  vmovaps xmm5, [rsp+0x50]
00007ec68bfe38e9  vmovaps xmm6, [rsp+0x60]
00007ec68bfe38ef  vmovaps xmm7, [rsp+0x70]
00007ec68bfe38f5  vmovaps xmm8, [rsp+0x80]
00007ec68bfe38fe  vmovaps xmm9, [rsp+0x90]
00007ec68bfe3907  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe3910  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe3919  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe3922  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe392b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe3934  add rsp, 0xF0
00007ec68bfe393b  pop r11
00007ec68bfe393d  pop r10
00007ec68bfe393f  pop r9
00007ec68bfe3941  pop r8
00007ec68bfe3943  pop rsi
00007ec68bfe3944  pop rdi
00007ec68bfe3945  pop rdx
00007ec68bfe3946  pop rcx
00007ec68bfe3947  pop rax
00007ec68bfe3948  add rsp, 0x08
00007ec68bfe394c  jmp 0x00007EC68BFDF7EF
00007ec68bfe3951  sub rsp, 0x08
00007ec68bfe3955  push rax
00007ec68bfe3956  push rcx
00007ec68bfe3957  push rdx
00007ec68bfe3958  push rdi
00007ec68bfe3959  push rsi
00007ec68bfe395a  push r8
00007ec68bfe395c  push r9
00007ec68bfe395e  push r10
00007ec68bfe3960  push r11
00007ec68bfe3962  sub rsp, 0xF0
00007ec68bfe3969  vmovaps [rsp], xmm0
00007ec68bfe396e  vmovaps [rsp+0x10], xmm1
00007ec68bfe3974  vmovaps [rsp+0x20], xmm2
00007ec68bfe397a  vmovaps [rsp+0x30], xmm3
00007ec68bfe3980  vmovaps [rsp+0x40], xmm4
00007ec68bfe3986  vmovaps [rsp+0x50], xmm5
00007ec68bfe398c  vmovaps [rsp+0x60], xmm6
00007ec68bfe3992  vmovaps [rsp+0x70], xmm7
00007ec68bfe3998  vmovaps [rsp+0x80], xmm9
00007ec68bfe39a1  vmovaps [rsp+0x90], xmm10
00007ec68bfe39aa  vmovaps [rsp+0xA0], xmm11
00007ec68bfe39b3  vmovaps [rsp+0xB0], xmm12
00007ec68bfe39bc  vmovaps [rsp+0xC0], xmm13
00007ec68bfe39c5  vmovaps [rsp+0xD0], xmm14
00007ec68bfe39ce  vmovaps [rsp+0xE0], xmm15
00007ec68bfe39d7  sub rsp, 0x30
00007ec68bfe39db  movaps [rsp], xmm8
00007ec68bfe39e0  movaps [rsp+0x10], xmm15
00007ec68bfe39e6  movaps [rsp+0x20], xmm9
00007ec68bfe39ec  lea rdi, [rsp]
00007ec68bfe39f0  mov esi, 0x00
00007ec68bfe39f5  mov rax, 0x57D97DADF530
00007ec68bfe39ff  call rax
00007ec68bfe3a01  movaps xmm8, [rsp]
00007ec68bfe3a06  add rsp, 0x30
00007ec68bfe3a0a  vmovaps xmm0, [rsp]
00007ec68bfe3a0f  vmovaps xmm1, [rsp+0x10]
00007ec68bfe3a15  vmovaps xmm2, [rsp+0x20]
00007ec68bfe3a1b  vmovaps xmm3, [rsp+0x30]
00007ec68bfe3a21  vmovaps xmm4, [rsp+0x40]
00007ec68bfe3a27  vmovaps xmm5, [rsp+0x50]
00007ec68bfe3a2d  vmovaps xmm6, [rsp+0x60]
00007ec68bfe3a33  vmovaps xmm7, [rsp+0x70]
00007ec68bfe3a39  vmovaps xmm9, [rsp+0x80]
00007ec68bfe3a42  vmovaps xmm10, [rsp+0x90]
00007ec68bfe3a4b  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe3a54  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe3a5d  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe3a66  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe3a6f  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe3a78  add rsp, 0xF0
00007ec68bfe3a7f  pop r11
00007ec68bfe3a81  pop r10
00007ec68bfe3a83  pop r9
00007ec68bfe3a85  pop r8
00007ec68bfe3a87  pop rsi
00007ec68bfe3a88  pop rdi
00007ec68bfe3a89  pop rdx
00007ec68bfe3a8a  pop rcx
00007ec68bfe3a8b  pop rax
00007ec68bfe3a8c  add rsp, 0x08
00007ec68bfe3a90  jmp 0x00007EC68BFDF81D
00007ec68bfe3a95  sub rsp, 0x08
00007ec68bfe3a99  push rax
00007ec68bfe3a9a  push rcx
00007ec68bfe3a9b  push rdx
00007ec68bfe3a9c  push rdi
00007ec68bfe3a9d  push rsi
00007ec68bfe3a9e  push r8
00007ec68bfe3aa0  push r9
00007ec68bfe3aa2  push r10
00007ec68bfe3aa4  push r11
00007ec68bfe3aa6  sub rsp, 0xF0
00007ec68bfe3aad  vmovaps [rsp], xmm0
00007ec68bfe3ab2  vmovaps [rsp+0x10], xmm1
00007ec68bfe3ab8  vmovaps [rsp+0x20], xmm2
00007ec68bfe3abe  vmovaps [rsp+0x30], xmm3
00007ec68bfe3ac4  vmovaps [rsp+0x40], xmm4
00007ec68bfe3aca  vmovaps [rsp+0x50], xmm5
00007ec68bfe3ad0  vmovaps [rsp+0x60], xmm6
00007ec68bfe3ad6  vmovaps [rsp+0x70], xmm7
00007ec68bfe3adc  vmovaps [rsp+0x80], xmm8
00007ec68bfe3ae5  vmovaps [rsp+0x90], xmm9
00007ec68bfe3aee  vmovaps [rsp+0xA0], xmm10
00007ec68bfe3af7  vmovaps [rsp+0xB0], xmm11
00007ec68bfe3b00  vmovaps [rsp+0xC0], xmm12
00007ec68bfe3b09  vmovaps [rsp+0xD0], xmm13
00007ec68bfe3b12  vmovaps [rsp+0xE0], xmm14
00007ec68bfe3b1b  sub rsp, 0x30
00007ec68bfe3b1f  movaps [rsp], xmm15
00007ec68bfe3b24  movaps [rsp+0x10], xmm11
00007ec68bfe3b2a  movaps [rsp+0x20], xmm6
00007ec68bfe3b2f  lea rdi, [rsp]
00007ec68bfe3b33  mov esi, 0x00
00007ec68bfe3b38  mov rax, 0x57D97DADF530
00007ec68bfe3b42  call rax
00007ec68bfe3b44  movaps xmm15, [rsp]
00007ec68bfe3b49  add rsp, 0x30
00007ec68bfe3b4d  vmovaps xmm0, [rsp]
00007ec68bfe3b52  vmovaps xmm1, [rsp+0x10]
00007ec68bfe3b58  vmovaps xmm2, [rsp+0x20]
00007ec68bfe3b5e  vmovaps xmm3, [rsp+0x30]
00007ec68bfe3b64  vmovaps xmm4, [rsp+0x40]
00007ec68bfe3b6a  vmovaps xmm5, [rsp+0x50]
00007ec68bfe3b70  vmovaps xmm6, [rsp+0x60]
00007ec68bfe3b76  vmovaps xmm7, [rsp+0x70]
00007ec68bfe3b7c  vmovaps xmm8, [rsp+0x80]
00007ec68bfe3b85  vmovaps xmm9, [rsp+0x90]
00007ec68bfe3b8e  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe3b97  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe3ba0  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe3ba9  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe3bb2  vmovaps xmm14, [rsp+0xE0]
00007ec68bfe3bbb  add rsp, 0xF0
00007ec68bfe3bc2  pop r11
00007ec68bfe3bc4  pop r10
00007ec68bfe3bc6  pop r9
00007ec68bfe3bc8  pop r8
00007ec68bfe3bca  pop rsi
00007ec68bfe3bcb  pop rdi
00007ec68bfe3bcc  pop rdx
00007ec68bfe3bcd  pop rcx
00007ec68bfe3bce  pop rax
00007ec68bfe3bcf  add rsp, 0x08
00007ec68bfe3bd3  jmp 0x00007EC68BFDF838
00007ec68bfe3bd8  sub rsp, 0x08
00007ec68bfe3bdc  push rax
00007ec68bfe3bdd  push rcx
00007ec68bfe3bde  push rdx
00007ec68bfe3bdf  push rdi
00007ec68bfe3be0  push rsi
00007ec68bfe3be1  push r8
00007ec68bfe3be3  push r9
00007ec68bfe3be5  push r10
00007ec68bfe3be7  push r11
00007ec68bfe3be9  sub rsp, 0xF0
00007ec68bfe3bf0  vmovaps [rsp], xmm0
00007ec68bfe3bf5  vmovaps [rsp+0x10], xmm1
00007ec68bfe3bfb  vmovaps [rsp+0x20], xmm2
00007ec68bfe3c01  vmovaps [rsp+0x30], xmm3
00007ec68bfe3c07  vmovaps [rsp+0x40], xmm4
00007ec68bfe3c0d  vmovaps [rsp+0x50], xmm5
00007ec68bfe3c13  vmovaps [rsp+0x60], xmm6
00007ec68bfe3c19  vmovaps [rsp+0x70], xmm8
00007ec68bfe3c1f  vmovaps [rsp+0x80], xmm9
00007ec68bfe3c28  vmovaps [rsp+0x90], xmm10
00007ec68bfe3c31  vmovaps [rsp+0xA0], xmm11
00007ec68bfe3c3a  vmovaps [rsp+0xB0], xmm12
00007ec68bfe3c43  vmovaps [rsp+0xC0], xmm13
00007ec68bfe3c4c  vmovaps [rsp+0xD0], xmm14
00007ec68bfe3c55  vmovaps [rsp+0xE0], xmm15
00007ec68bfe3c5e  sub rsp, 0x30
00007ec68bfe3c62  movaps [rsp], xmm7
00007ec68bfe3c66  movaps [rsp+0x10], xmm11
00007ec68bfe3c6c  movaps [rsp+0x20], xmm9
00007ec68bfe3c72  lea rdi, [rsp]
00007ec68bfe3c76  mov esi, 0x00
00007ec68bfe3c7b  mov rax, 0x57D97DADF530
00007ec68bfe3c85  call rax
00007ec68bfe3c87  movaps xmm7, [rsp]
00007ec68bfe3c8b  add rsp, 0x30
00007ec68bfe3c8f  vmovaps xmm0, [rsp]
00007ec68bfe3c94  vmovaps xmm1, [rsp+0x10]
00007ec68bfe3c9a  vmovaps xmm2, [rsp+0x20]
00007ec68bfe3ca0  vmovaps xmm3, [rsp+0x30]
00007ec68bfe3ca6  vmovaps xmm4, [rsp+0x40]
00007ec68bfe3cac  vmovaps xmm5, [rsp+0x50]
00007ec68bfe3cb2  vmovaps xmm6, [rsp+0x60]
00007ec68bfe3cb8  vmovaps xmm8, [rsp+0x70]
00007ec68bfe3cbe  vmovaps xmm9, [rsp+0x80]
00007ec68bfe3cc7  vmovaps xmm10, [rsp+0x90]
00007ec68bfe3cd0  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe3cd9  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe3ce2  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe3ceb  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe3cf4  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe3cfd  add rsp, 0xF0
00007ec68bfe3d04  pop r11
00007ec68bfe3d06  pop r10
00007ec68bfe3d08  pop r9
00007ec68bfe3d0a  pop r8
00007ec68bfe3d0c  pop rsi
00007ec68bfe3d0d  pop rdi
00007ec68bfe3d0e  pop rdx
00007ec68bfe3d0f  pop rcx
00007ec68bfe3d10  pop rax
00007ec68bfe3d11  add rsp, 0x08
00007ec68bfe3d15  jmp 0x00007EC68BFDF865
00007ec68bfe3d1a  sub rsp, 0x08
00007ec68bfe3d1e  push rax
00007ec68bfe3d1f  push rcx
00007ec68bfe3d20  push rdx
00007ec68bfe3d21  push rdi
00007ec68bfe3d22  push rsi
00007ec68bfe3d23  push r8
00007ec68bfe3d25  push r9
00007ec68bfe3d27  push r10
00007ec68bfe3d29  push r11
00007ec68bfe3d2b  sub rsp, 0xF0
00007ec68bfe3d32  vmovaps [rsp], xmm0
00007ec68bfe3d37  vmovaps [rsp+0x10], xmm1
00007ec68bfe3d3d  vmovaps [rsp+0x20], xmm2
00007ec68bfe3d43  vmovaps [rsp+0x30], xmm3
00007ec68bfe3d49  vmovaps [rsp+0x40], xmm4
00007ec68bfe3d4f  vmovaps [rsp+0x50], xmm5
00007ec68bfe3d55  vmovaps [rsp+0x60], xmm6
00007ec68bfe3d5b  vmovaps [rsp+0x70], xmm7
00007ec68bfe3d61  vmovaps [rsp+0x80], xmm8
00007ec68bfe3d6a  vmovaps [rsp+0x90], xmm9
00007ec68bfe3d73  vmovaps [rsp+0xA0], xmm10
00007ec68bfe3d7c  vmovaps [rsp+0xB0], xmm12
00007ec68bfe3d85  vmovaps [rsp+0xC0], xmm13
00007ec68bfe3d8e  vmovaps [rsp+0xD0], xmm14
00007ec68bfe3d97  vmovaps [rsp+0xE0], xmm15
00007ec68bfe3da0  sub rsp, 0x30
00007ec68bfe3da4  movaps [rsp], xmm11
00007ec68bfe3da9  movaps [rsp+0x10], xmm10
00007ec68bfe3daf  movaps [rsp+0x20], xmm14
00007ec68bfe3db5  lea rdi, [rsp]
00007ec68bfe3db9  mov esi, 0x00
00007ec68bfe3dbe  mov rax, 0x57D97DADF530
00007ec68bfe3dc8  call rax
00007ec68bfe3dca  movaps xmm11, [rsp]
00007ec68bfe3dcf  add rsp, 0x30
00007ec68bfe3dd3  vmovaps xmm0, [rsp]
00007ec68bfe3dd8  vmovaps xmm1, [rsp+0x10]
00007ec68bfe3dde  vmovaps xmm2, [rsp+0x20]
00007ec68bfe3de4  vmovaps xmm3, [rsp+0x30]
00007ec68bfe3dea  vmovaps xmm4, [rsp+0x40]
00007ec68bfe3df0  vmovaps xmm5, [rsp+0x50]
00007ec68bfe3df6  vmovaps xmm6, [rsp+0x60]
00007ec68bfe3dfc  vmovaps xmm7, [rsp+0x70]
00007ec68bfe3e02  vmovaps xmm8, [rsp+0x80]
00007ec68bfe3e0b  vmovaps xmm9, [rsp+0x90]
00007ec68bfe3e14  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe3e1d  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe3e26  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe3e2f  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe3e38  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe3e41  add rsp, 0xF0
00007ec68bfe3e48  pop r11
00007ec68bfe3e4a  pop r10
00007ec68bfe3e4c  pop r9
00007ec68bfe3e4e  pop r8
00007ec68bfe3e50  pop rsi
00007ec68bfe3e51  pop rdi
00007ec68bfe3e52  pop rdx
00007ec68bfe3e53  pop rcx
00007ec68bfe3e54  pop rax
00007ec68bfe3e55  add rsp, 0x08
00007ec68bfe3e59  jmp 0x00007EC68BFDF880
00007ec68bfe3e5e  call 0x00007EC68BEC33A0
00007ec68bfe3e63  jmp 0x00007EC68BFDF88A
00007ec68bfe3e68  sub rsp, 0x08
00007ec68bfe3e6c  push rax
00007ec68bfe3e6d  push rcx
00007ec68bfe3e6e  push rdx
00007ec68bfe3e6f  push rdi
00007ec68bfe3e70  push rsi
00007ec68bfe3e71  push r8
00007ec68bfe3e73  push r9
00007ec68bfe3e75  push r10
00007ec68bfe3e77  push r11
00007ec68bfe3e79  sub rsp, 0xF0
00007ec68bfe3e80  vmovaps [rsp], xmm0
00007ec68bfe3e85  vmovaps [rsp+0x10], xmm1
00007ec68bfe3e8b  vmovaps [rsp+0x20], xmm2
00007ec68bfe3e91  vmovaps [rsp+0x30], xmm3
00007ec68bfe3e97  vmovaps [rsp+0x40], xmm4
00007ec68bfe3e9d  vmovaps [rsp+0x50], xmm5
00007ec68bfe3ea3  vmovaps [rsp+0x60], xmm6
00007ec68bfe3ea9  vmovaps [rsp+0x70], xmm7
00007ec68bfe3eaf  vmovaps [rsp+0x80], xmm8
00007ec68bfe3eb8  vmovaps [rsp+0x90], xmm9
00007ec68bfe3ec1  vmovaps [rsp+0xA0], xmm11
00007ec68bfe3eca  vmovaps [rsp+0xB0], xmm12
00007ec68bfe3ed3  vmovaps [rsp+0xC0], xmm13
00007ec68bfe3edc  vmovaps [rsp+0xD0], xmm14
00007ec68bfe3ee5  vmovaps [rsp+0xE0], xmm15
00007ec68bfe3eee  sub rsp, 0x30
00007ec68bfe3ef2  movaps [rsp], xmm10
00007ec68bfe3ef7  movaps [rsp+0x10], xmm1
00007ec68bfe3efc  movaps [rsp+0x20], xmm12
00007ec68bfe3f02  lea rdi, [rsp]
00007ec68bfe3f06  mov esi, 0x00
00007ec68bfe3f0b  mov rax, 0x57D97DADF530
00007ec68bfe3f15  call rax
00007ec68bfe3f17  movaps xmm10, [rsp]
00007ec68bfe3f1c  add rsp, 0x30
00007ec68bfe3f20  vmovaps xmm0, [rsp]
00007ec68bfe3f25  vmovaps xmm1, [rsp+0x10]
00007ec68bfe3f2b  vmovaps xmm2, [rsp+0x20]
00007ec68bfe3f31  vmovaps xmm3, [rsp+0x30]
00007ec68bfe3f37  vmovaps xmm4, [rsp+0x40]
00007ec68bfe3f3d  vmovaps xmm5, [rsp+0x50]
00007ec68bfe3f43  vmovaps xmm6, [rsp+0x60]
00007ec68bfe3f49  vmovaps xmm7, [rsp+0x70]
00007ec68bfe3f4f  vmovaps xmm8, [rsp+0x80]
00007ec68bfe3f58  vmovaps xmm9, [rsp+0x90]
00007ec68bfe3f61  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe3f6a  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe3f73  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe3f7c  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe3f85  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe3f8e  add rsp, 0xF0
00007ec68bfe3f95  pop r11
00007ec68bfe3f97  pop r10
00007ec68bfe3f99  pop r9
00007ec68bfe3f9b  pop r8
00007ec68bfe3f9d  pop rsi
00007ec68bfe3f9e  pop rdi
00007ec68bfe3f9f  pop rdx
00007ec68bfe3fa0  pop rcx
00007ec68bfe3fa1  pop rax
00007ec68bfe3fa2  add rsp, 0x08
00007ec68bfe3fa6  jmp 0x00007EC68BFDF8AD
00007ec68bfe3fab  sub rsp, 0x08
00007ec68bfe3faf  push rax
00007ec68bfe3fb0  push rcx
00007ec68bfe3fb1  push rdx
00007ec68bfe3fb2  push rdi
00007ec68bfe3fb3  push rsi
00007ec68bfe3fb4  push r8
00007ec68bfe3fb6  push r9
00007ec68bfe3fb8  push r10
00007ec68bfe3fba  push r11
00007ec68bfe3fbc  sub rsp, 0xF0
00007ec68bfe3fc3  vmovaps [rsp], xmm0
00007ec68bfe3fc8  vmovaps [rsp+0x10], xmm1
00007ec68bfe3fce  vmovaps [rsp+0x20], xmm2
00007ec68bfe3fd4  vmovaps [rsp+0x30], xmm3
00007ec68bfe3fda  vmovaps [rsp+0x40], xmm4
00007ec68bfe3fe0  vmovaps [rsp+0x50], xmm5
00007ec68bfe3fe6  vmovaps [rsp+0x60], xmm6
00007ec68bfe3fec  vmovaps [rsp+0x70], xmm7
00007ec68bfe3ff2  vmovaps [rsp+0x80], xmm8
00007ec68bfe3ffb  vmovaps [rsp+0x90], xmm9
00007ec68bfe4004  vmovaps [rsp+0xA0], xmm10
00007ec68bfe400d  vmovaps [rsp+0xB0], xmm11
00007ec68bfe4016  vmovaps [rsp+0xC0], xmm13
00007ec68bfe401f  vmovaps [rsp+0xD0], xmm14
00007ec68bfe4028  vmovaps [rsp+0xE0], xmm15
00007ec68bfe4031  sub rsp, 0x30
00007ec68bfe4035  movaps [rsp], xmm12
00007ec68bfe403a  movaps [rsp+0x10], xmm14
00007ec68bfe4040  movaps [rsp+0x20], xmm1
00007ec68bfe4045  lea rdi, [rsp]
00007ec68bfe4049  mov esi, 0x00
00007ec68bfe404e  mov rax, 0x57D97DADF530
00007ec68bfe4058  call rax
00007ec68bfe405a  movaps xmm12, [rsp]
00007ec68bfe405f  add rsp, 0x30
00007ec68bfe4063  vmovaps xmm0, [rsp]
00007ec68bfe4068  vmovaps xmm1, [rsp+0x10]
00007ec68bfe406e  vmovaps xmm2, [rsp+0x20]
00007ec68bfe4074  vmovaps xmm3, [rsp+0x30]
00007ec68bfe407a  vmovaps xmm4, [rsp+0x40]
00007ec68bfe4080  vmovaps xmm5, [rsp+0x50]
00007ec68bfe4086  vmovaps xmm6, [rsp+0x60]
00007ec68bfe408c  vmovaps xmm7, [rsp+0x70]
00007ec68bfe4092  vmovaps xmm8, [rsp+0x80]
00007ec68bfe409b  vmovaps xmm9, [rsp+0x90]
00007ec68bfe40a4  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe40ad  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe40b6  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe40bf  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe40c8  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe40d1  add rsp, 0xF0
00007ec68bfe40d8  pop r11
00007ec68bfe40da  pop r10
00007ec68bfe40dc  pop r9
00007ec68bfe40de  pop r8
00007ec68bfe40e0  pop rsi
00007ec68bfe40e1  pop rdi
00007ec68bfe40e2  pop rdx
00007ec68bfe40e3  pop rcx
00007ec68bfe40e4  pop rax
00007ec68bfe40e5  add rsp, 0x08
00007ec68bfe40e9  jmp 0x00007EC68BFDF8DC
00007ec68bfe40ee  sub rsp, 0x08
00007ec68bfe40f2  push rax
00007ec68bfe40f3  push rcx
00007ec68bfe40f4  push rdx
00007ec68bfe40f5  push rdi
00007ec68bfe40f6  push rsi
00007ec68bfe40f7  push r8
00007ec68bfe40f9  push r9
00007ec68bfe40fb  push r10
00007ec68bfe40fd  push r11
00007ec68bfe40ff  sub rsp, 0xF0
00007ec68bfe4106  vmovaps [rsp], xmm0
00007ec68bfe410b  vmovaps [rsp+0x10], xmm1
00007ec68bfe4111  vmovaps [rsp+0x20], xmm2
00007ec68bfe4117  vmovaps [rsp+0x30], xmm3
00007ec68bfe411d  vmovaps [rsp+0x40], xmm4
00007ec68bfe4123  vmovaps [rsp+0x50], xmm5
00007ec68bfe4129  vmovaps [rsp+0x60], xmm6
00007ec68bfe412f  vmovaps [rsp+0x70], xmm7
00007ec68bfe4135  vmovaps [rsp+0x80], xmm8
00007ec68bfe413e  vmovaps [rsp+0x90], xmm9
00007ec68bfe4147  vmovaps [rsp+0xA0], xmm10
00007ec68bfe4150  vmovaps [rsp+0xB0], xmm11
00007ec68bfe4159  vmovaps [rsp+0xC0], xmm12
00007ec68bfe4162  vmovaps [rsp+0xD0], xmm13
00007ec68bfe416b  vmovaps [rsp+0xE0], xmm15
00007ec68bfe4174  sub rsp, 0x30
00007ec68bfe4178  movaps [rsp], xmm14
00007ec68bfe417d  movaps [rsp+0x10], xmm9
00007ec68bfe4183  movaps [rsp+0x20], xmm1
00007ec68bfe4188  lea rdi, [rsp]
00007ec68bfe418c  mov esi, 0x00
00007ec68bfe4191  mov rax, 0x57D97DADF530
00007ec68bfe419b  call rax
00007ec68bfe419d  movaps xmm14, [rsp]
00007ec68bfe41a2  add rsp, 0x30
00007ec68bfe41a6  vmovaps xmm0, [rsp]
00007ec68bfe41ab  vmovaps xmm1, [rsp+0x10]
00007ec68bfe41b1  vmovaps xmm2, [rsp+0x20]
00007ec68bfe41b7  vmovaps xmm3, [rsp+0x30]
00007ec68bfe41bd  vmovaps xmm4, [rsp+0x40]
00007ec68bfe41c3  vmovaps xmm5, [rsp+0x50]
00007ec68bfe41c9  vmovaps xmm6, [rsp+0x60]
00007ec68bfe41cf  vmovaps xmm7, [rsp+0x70]
00007ec68bfe41d5  vmovaps xmm8, [rsp+0x80]
00007ec68bfe41de  vmovaps xmm9, [rsp+0x90]
00007ec68bfe41e7  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe41f0  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe41f9  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe4202  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe420b  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe4214  add rsp, 0xF0
00007ec68bfe421b  pop r11
00007ec68bfe421d  pop r10
00007ec68bfe421f  pop r9
00007ec68bfe4221  pop r8
00007ec68bfe4223  pop rsi
00007ec68bfe4224  pop rdi
00007ec68bfe4225  pop rdx
00007ec68bfe4226  pop rcx
00007ec68bfe4227  pop rax
00007ec68bfe4228  add rsp, 0x08
00007ec68bfe422c  jmp 0x00007EC68BFDF90B
00007ec68bfe4231  sub rsp, 0x08
00007ec68bfe4235  push rax
00007ec68bfe4236  push rcx
00007ec68bfe4237  push rdx
00007ec68bfe4238  push rdi
00007ec68bfe4239  push rsi
00007ec68bfe423a  push r8
00007ec68bfe423c  push r9
00007ec68bfe423e  push r10
00007ec68bfe4240  push r11
00007ec68bfe4242  sub rsp, 0xF0
00007ec68bfe4249  vmovaps [rsp], xmm0
00007ec68bfe424e  vmovaps [rsp+0x10], xmm2
00007ec68bfe4254  vmovaps [rsp+0x20], xmm3
00007ec68bfe425a  vmovaps [rsp+0x30], xmm4
00007ec68bfe4260  vmovaps [rsp+0x40], xmm5
00007ec68bfe4266  vmovaps [rsp+0x50], xmm6
00007ec68bfe426c  vmovaps [rsp+0x60], xmm7
00007ec68bfe4272  vmovaps [rsp+0x70], xmm8
00007ec68bfe4278  vmovaps [rsp+0x80], xmm9
00007ec68bfe4281  vmovaps [rsp+0x90], xmm10
00007ec68bfe428a  vmovaps [rsp+0xA0], xmm11
00007ec68bfe4293  vmovaps [rsp+0xB0], xmm12
00007ec68bfe429c  vmovaps [rsp+0xC0], xmm13
00007ec68bfe42a5  vmovaps [rsp+0xD0], xmm14
00007ec68bfe42ae  vmovaps [rsp+0xE0], xmm15
00007ec68bfe42b7  sub rsp, 0x30
00007ec68bfe42bb  movaps [rsp], xmm1
00007ec68bfe42bf  movaps [rsp+0x10], xmm13
00007ec68bfe42c5  movaps [rsp+0x20], xmm8
00007ec68bfe42cb  lea rdi, [rsp]
00007ec68bfe42cf  mov esi, 0x00
00007ec68bfe42d4  mov rax, 0x57D97DADF530
00007ec68bfe42de  call rax
00007ec68bfe42e0  movaps xmm1, [rsp]
00007ec68bfe42e4  add rsp, 0x30
00007ec68bfe42e8  vmovaps xmm0, [rsp]
00007ec68bfe42ed  vmovaps xmm2, [rsp+0x10]
00007ec68bfe42f3  vmovaps xmm3, [rsp+0x20]
00007ec68bfe42f9  vmovaps xmm4, [rsp+0x30]
00007ec68bfe42ff  vmovaps xmm5, [rsp+0x40]
00007ec68bfe4305  vmovaps xmm6, [rsp+0x50]
00007ec68bfe430b  vmovaps xmm7, [rsp+0x60]
00007ec68bfe4311  vmovaps xmm8, [rsp+0x70]
00007ec68bfe4317  vmovaps xmm9, [rsp+0x80]
00007ec68bfe4320  vmovaps xmm10, [rsp+0x90]
00007ec68bfe4329  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe4332  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe433b  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe4344  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe434d  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe4356  add rsp, 0xF0
00007ec68bfe435d  pop r11
00007ec68bfe435f  pop r10
00007ec68bfe4361  pop r9
00007ec68bfe4363  pop r8
00007ec68bfe4365  pop rsi
00007ec68bfe4366  pop rdi
00007ec68bfe4367  pop rdx
00007ec68bfe4368  pop rcx
00007ec68bfe4369  pop rax
00007ec68bfe436a  add rsp, 0x08
00007ec68bfe436e  jmp 0x00007EC68BFDF92D
00007ec68bfe4373  call 0x00007EC68BE0C260
00007ec68bfe4378  jmp 0x00007EC68BFDF93B
00007ec68bfe437d  call 0x00007EC68BEBD750
00007ec68bfe4382  jmp 0x00007EC68BFDF945
00007ec68bfe4387  sub rsp, 0x08
00007ec68bfe438b  push rax
00007ec68bfe438c  push rcx
00007ec68bfe438d  push rdx
00007ec68bfe438e  push rdi
00007ec68bfe438f  push rsi
00007ec68bfe4390  push r8
00007ec68bfe4392  push r9
00007ec68bfe4394  push r10
00007ec68bfe4396  push r11
00007ec68bfe4398  sub rsp, 0xF0
00007ec68bfe439f  vmovaps [rsp], xmm0
00007ec68bfe43a4  vmovaps [rsp+0x10], xmm1
00007ec68bfe43aa  vmovaps [rsp+0x20], xmm2
00007ec68bfe43b0  vmovaps [rsp+0x30], xmm3
00007ec68bfe43b6  vmovaps [rsp+0x40], xmm4
00007ec68bfe43bc  vmovaps [rsp+0x50], xmm5
00007ec68bfe43c2  vmovaps [rsp+0x60], xmm6
00007ec68bfe43c8  vmovaps [rsp+0x70], xmm7
00007ec68bfe43ce  vmovaps [rsp+0x80], xmm9
00007ec68bfe43d7  vmovaps [rsp+0x90], xmm10
00007ec68bfe43e0  vmovaps [rsp+0xA0], xmm11
00007ec68bfe43e9  vmovaps [rsp+0xB0], xmm12
00007ec68bfe43f2  vmovaps [rsp+0xC0], xmm13
00007ec68bfe43fb  vmovaps [rsp+0xD0], xmm14
00007ec68bfe4404  vmovaps [rsp+0xE0], xmm15
00007ec68bfe440d  sub rsp, 0x30
00007ec68bfe4411  movaps [rsp], xmm8
00007ec68bfe4416  movaps [rsp+0x10], xmm15
00007ec68bfe441c  movaps [rsp+0x20], xmm7
00007ec68bfe4421  lea rdi, [rsp]
00007ec68bfe4425  mov esi, 0x00
00007ec68bfe442a  mov rax, 0x57D97DADF530
00007ec68bfe4434  call rax
00007ec68bfe4436  movaps xmm8, [rsp]
00007ec68bfe443b  add rsp, 0x30
00007ec68bfe443f  vmovaps xmm0, [rsp]
00007ec68bfe4444  vmovaps xmm1, [rsp+0x10]
00007ec68bfe444a  vmovaps xmm2, [rsp+0x20]
00007ec68bfe4450  vmovaps xmm3, [rsp+0x30]
00007ec68bfe4456  vmovaps xmm4, [rsp+0x40]
00007ec68bfe445c  vmovaps xmm5, [rsp+0x50]
00007ec68bfe4462  vmovaps xmm6, [rsp+0x60]
00007ec68bfe4468  vmovaps xmm7, [rsp+0x70]
00007ec68bfe446e  vmovaps xmm9, [rsp+0x80]
00007ec68bfe4477  vmovaps xmm10, [rsp+0x90]
00007ec68bfe4480  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe4489  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe4492  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe449b  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe44a4  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe44ad  add rsp, 0xF0
00007ec68bfe44b4  pop r11
00007ec68bfe44b6  pop r10
00007ec68bfe44b8  pop r9
00007ec68bfe44ba  pop r8
00007ec68bfe44bc  pop rsi
00007ec68bfe44bd  pop rdi
00007ec68bfe44be  pop rdx
00007ec68bfe44bf  pop rcx
00007ec68bfe44c0  pop rax
00007ec68bfe44c1  add rsp, 0x08
00007ec68bfe44c5  jmp 0x00007EC68BFDF967
00007ec68bfe44ca  sub rsp, 0x08
00007ec68bfe44ce  push rax
00007ec68bfe44cf  push rcx
00007ec68bfe44d0  push rdx
00007ec68bfe44d1  push rdi
00007ec68bfe44d2  push rsi
00007ec68bfe44d3  push r8
00007ec68bfe44d5  push r9
00007ec68bfe44d7  push r10
00007ec68bfe44d9  push r11
00007ec68bfe44db  sub rsp, 0xF0
00007ec68bfe44e2  vmovaps [rsp], xmm0
00007ec68bfe44e7  vmovaps [rsp+0x10], xmm1
00007ec68bfe44ed  vmovaps [rsp+0x20], xmm2
00007ec68bfe44f3  vmovaps [rsp+0x30], xmm3
00007ec68bfe44f9  vmovaps [rsp+0x40], xmm4
00007ec68bfe44ff  vmovaps [rsp+0x50], xmm5
00007ec68bfe4505  vmovaps [rsp+0x60], xmm6
00007ec68bfe450b  vmovaps [rsp+0x70], xmm8
00007ec68bfe4511  vmovaps [rsp+0x80], xmm9
00007ec68bfe451a  vmovaps [rsp+0x90], xmm10
00007ec68bfe4523  vmovaps [rsp+0xA0], xmm11
00007ec68bfe452c  vmovaps [rsp+0xB0], xmm12
00007ec68bfe4535  vmovaps [rsp+0xC0], xmm13
00007ec68bfe453e  vmovaps [rsp+0xD0], xmm14
00007ec68bfe4547  vmovaps [rsp+0xE0], xmm15
00007ec68bfe4550  sub rsp, 0x30
00007ec68bfe4554  movaps [rsp], xmm7
00007ec68bfe4558  movaps [rsp+0x10], xmm9
00007ec68bfe455e  movaps [rsp+0x20], xmm15
00007ec68bfe4564  lea rdi, [rsp]
00007ec68bfe4568  mov esi, 0x00
00007ec68bfe456d  mov rax, 0x57D97DADF530
00007ec68bfe4577  call rax
00007ec68bfe4579  movaps xmm7, [rsp]
00007ec68bfe457d  add rsp, 0x30
00007ec68bfe4581  vmovaps xmm0, [rsp]
00007ec68bfe4586  vmovaps xmm1, [rsp+0x10]
00007ec68bfe458c  vmovaps xmm2, [rsp+0x20]
00007ec68bfe4592  vmovaps xmm3, [rsp+0x30]
00007ec68bfe4598  vmovaps xmm4, [rsp+0x40]
00007ec68bfe459e  vmovaps xmm5, [rsp+0x50]
00007ec68bfe45a4  vmovaps xmm6, [rsp+0x60]
00007ec68bfe45aa  vmovaps xmm8, [rsp+0x70]
00007ec68bfe45b0  vmovaps xmm9, [rsp+0x80]
00007ec68bfe45b9  vmovaps xmm10, [rsp+0x90]
00007ec68bfe45c2  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe45cb  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe45d4  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe45dd  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe45e6  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe45ef  add rsp, 0xF0
00007ec68bfe45f6  pop r11
00007ec68bfe45f8  pop r10
00007ec68bfe45fa  pop r9
00007ec68bfe45fc  pop r8
00007ec68bfe45fe  pop rsi
00007ec68bfe45ff  pop rdi
00007ec68bfe4600  pop rdx
00007ec68bfe4601  pop rcx
00007ec68bfe4602  pop rax
00007ec68bfe4603  add rsp, 0x08
00007ec68bfe4607  jmp 0x00007EC68BFDF994
00007ec68bfe460c  sub rsp, 0x08
00007ec68bfe4610  push rax
00007ec68bfe4611  push rcx
00007ec68bfe4612  push rdx
00007ec68bfe4613  push rdi
00007ec68bfe4614  push rsi
00007ec68bfe4615  push r8
00007ec68bfe4617  push r9
00007ec68bfe4619  push r10
00007ec68bfe461b  push r11
00007ec68bfe461d  sub rsp, 0xF0
00007ec68bfe4624  vmovaps [rsp], xmm0
00007ec68bfe4629  vmovaps [rsp+0x10], xmm1
00007ec68bfe462f  vmovaps [rsp+0x20], xmm2
00007ec68bfe4635  vmovaps [rsp+0x30], xmm3
00007ec68bfe463b  vmovaps [rsp+0x40], xmm4
00007ec68bfe4641  vmovaps [rsp+0x50], xmm5
00007ec68bfe4647  vmovaps [rsp+0x60], xmm6
00007ec68bfe464d  vmovaps [rsp+0x70], xmm7
00007ec68bfe4653  vmovaps [rsp+0x80], xmm8
00007ec68bfe465c  vmovaps [rsp+0x90], xmm10
00007ec68bfe4665  vmovaps [rsp+0xA0], xmm11
00007ec68bfe466e  vmovaps [rsp+0xB0], xmm12
00007ec68bfe4677  vmovaps [rsp+0xC0], xmm13
00007ec68bfe4680  vmovaps [rsp+0xD0], xmm14
00007ec68bfe4689  vmovaps [rsp+0xE0], xmm15
00007ec68bfe4692  sub rsp, 0x30
00007ec68bfe4696  movaps [rsp], xmm9
00007ec68bfe469b  movaps [rsp+0x10], xmm13
00007ec68bfe46a1  movaps [rsp+0x20], xmm15
00007ec68bfe46a7  lea rdi, [rsp]
00007ec68bfe46ab  mov esi, 0x00
00007ec68bfe46b0  mov rax, 0x57D97DADF530
00007ec68bfe46ba  call rax
00007ec68bfe46bc  movaps xmm9, [rsp]
00007ec68bfe46c1  add rsp, 0x30
00007ec68bfe46c5  vmovaps xmm0, [rsp]
00007ec68bfe46ca  vmovaps xmm1, [rsp+0x10]
00007ec68bfe46d0  vmovaps xmm2, [rsp+0x20]
00007ec68bfe46d6  vmovaps xmm3, [rsp+0x30]
00007ec68bfe46dc  vmovaps xmm4, [rsp+0x40]
00007ec68bfe46e2  vmovaps xmm5, [rsp+0x50]
00007ec68bfe46e8  vmovaps xmm6, [rsp+0x60]
00007ec68bfe46ee  vmovaps xmm7, [rsp+0x70]
00007ec68bfe46f4  vmovaps xmm8, [rsp+0x80]
00007ec68bfe46fd  vmovaps xmm10, [rsp+0x90]
00007ec68bfe4706  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe470f  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe4718  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe4721  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe472a  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe4733  add rsp, 0xF0
00007ec68bfe473a  pop r11
00007ec68bfe473c  pop r10
00007ec68bfe473e  pop r9
00007ec68bfe4740  pop r8
00007ec68bfe4742  pop rsi
00007ec68bfe4743  pop rdi
00007ec68bfe4744  pop rdx
00007ec68bfe4745  pop rcx
00007ec68bfe4746  pop rax
00007ec68bfe4747  add rsp, 0x08
00007ec68bfe474b  jmp 0x00007EC68BFDF9C2
00007ec68bfe4750  sub rsp, 0x08
00007ec68bfe4754  push rax
00007ec68bfe4755  push rcx
00007ec68bfe4756  push rdx
00007ec68bfe4757  push rdi
00007ec68bfe4758  push rsi
00007ec68bfe4759  push r8
00007ec68bfe475b  push r9
00007ec68bfe475d  push r10
00007ec68bfe475f  push r11
00007ec68bfe4761  sub rsp, 0xF0
00007ec68bfe4768  vmovaps [rsp], xmm0
00007ec68bfe476d  vmovaps [rsp+0x10], xmm1
00007ec68bfe4773  vmovaps [rsp+0x20], xmm2
00007ec68bfe4779  vmovaps [rsp+0x30], xmm3
00007ec68bfe477f  vmovaps [rsp+0x40], xmm4
00007ec68bfe4785  vmovaps [rsp+0x50], xmm5
00007ec68bfe478b  vmovaps [rsp+0x60], xmm6
00007ec68bfe4791  vmovaps [rsp+0x70], xmm7
00007ec68bfe4797  vmovaps [rsp+0x80], xmm8
00007ec68bfe47a0  vmovaps [rsp+0x90], xmm9
00007ec68bfe47a9  vmovaps [rsp+0xA0], xmm10
00007ec68bfe47b2  vmovaps [rsp+0xB0], xmm11
00007ec68bfe47bb  vmovaps [rsp+0xC0], xmm12
00007ec68bfe47c4  vmovaps [rsp+0xD0], xmm13
00007ec68bfe47cd  vmovaps [rsp+0xE0], xmm14
00007ec68bfe47d6  sub rsp, 0x30
00007ec68bfe47da  movaps [rsp], xmm15
00007ec68bfe47df  movaps [rsp+0x10], xmm11
00007ec68bfe47e5  movaps [rsp+0x20], xmm12
00007ec68bfe47eb  lea rdi, [rsp]
00007ec68bfe47ef  mov esi, 0x00
00007ec68bfe47f4  mov rax, 0x57D97DADF530
00007ec68bfe47fe  call rax
00007ec68bfe4800  movaps xmm15, [rsp]
00007ec68bfe4805  add rsp, 0x30
00007ec68bfe4809  vmovaps xmm0, [rsp]
00007ec68bfe480e  vmovaps xmm1, [rsp+0x10]
00007ec68bfe4814  vmovaps xmm2, [rsp+0x20]
00007ec68bfe481a  vmovaps xmm3, [rsp+0x30]
00007ec68bfe4820  vmovaps xmm4, [rsp+0x40]
00007ec68bfe4826  vmovaps xmm5, [rsp+0x50]
00007ec68bfe482c  vmovaps xmm6, [rsp+0x60]
00007ec68bfe4832  vmovaps xmm7, [rsp+0x70]
00007ec68bfe4838  vmovaps xmm8, [rsp+0x80]
00007ec68bfe4841  vmovaps xmm9, [rsp+0x90]
00007ec68bfe484a  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe4853  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe485c  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe4865  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe486e  vmovaps xmm14, [rsp+0xE0]
00007ec68bfe4877  add rsp, 0xF0
00007ec68bfe487e  pop r11
00007ec68bfe4880  pop r10
00007ec68bfe4882  pop r9
00007ec68bfe4884  pop r8
00007ec68bfe4886  pop rsi
00007ec68bfe4887  pop rdi
00007ec68bfe4888  pop rdx
00007ec68bfe4889  pop rcx
00007ec68bfe488a  pop rax
00007ec68bfe488b  add rsp, 0x08
00007ec68bfe488f  jmp 0x00007EC68BFDF9DD
00007ec68bfe4894  sub rsp, 0x08
00007ec68bfe4898  push rax
00007ec68bfe4899  push rcx
00007ec68bfe489a  push rdx
00007ec68bfe489b  push rdi
00007ec68bfe489c  push rsi
00007ec68bfe489d  push r8
00007ec68bfe489f  push r9
00007ec68bfe48a1  push r10
00007ec68bfe48a3  push r11
00007ec68bfe48a5  sub rsp, 0xF0
00007ec68bfe48ac  vmovaps [rsp], xmm0
00007ec68bfe48b1  vmovaps [rsp+0x10], xmm1
00007ec68bfe48b7  vmovaps [rsp+0x20], xmm2
00007ec68bfe48bd  vmovaps [rsp+0x30], xmm3
00007ec68bfe48c3  vmovaps [rsp+0x40], xmm4
00007ec68bfe48c9  vmovaps [rsp+0x50], xmm5
00007ec68bfe48cf  vmovaps [rsp+0x60], xmm6
00007ec68bfe48d5  vmovaps [rsp+0x70], xmm7
00007ec68bfe48db  vmovaps [rsp+0x80], xmm8
00007ec68bfe48e4  vmovaps [rsp+0x90], xmm9
00007ec68bfe48ed  vmovaps [rsp+0xA0], xmm10
00007ec68bfe48f6  vmovaps [rsp+0xB0], xmm11
00007ec68bfe48ff  vmovaps [rsp+0xC0], xmm12
00007ec68bfe4908  vmovaps [rsp+0xD0], xmm14
00007ec68bfe4911  vmovaps [rsp+0xE0], xmm15
00007ec68bfe491a  sub rsp, 0x30
00007ec68bfe491e  movaps [rsp], xmm13
00007ec68bfe4923  movaps [rsp+0x10], xmm10
00007ec68bfe4929  movaps [rsp+0x20], xmm14
00007ec68bfe492f  lea rdi, [rsp]
00007ec68bfe4933  mov esi, 0x00
00007ec68bfe4938  mov rax, 0x57D97DADF530
00007ec68bfe4942  call rax
00007ec68bfe4944  movaps xmm13, [rsp]
00007ec68bfe4949  add rsp, 0x30
00007ec68bfe494d  vmovaps xmm0, [rsp]
00007ec68bfe4952  vmovaps xmm1, [rsp+0x10]
00007ec68bfe4958  vmovaps xmm2, [rsp+0x20]
00007ec68bfe495e  vmovaps xmm3, [rsp+0x30]
00007ec68bfe4964  vmovaps xmm4, [rsp+0x40]
00007ec68bfe496a  vmovaps xmm5, [rsp+0x50]
00007ec68bfe4970  vmovaps xmm6, [rsp+0x60]
00007ec68bfe4976  vmovaps xmm7, [rsp+0x70]
00007ec68bfe497c  vmovaps xmm8, [rsp+0x80]
00007ec68bfe4985  vmovaps xmm9, [rsp+0x90]
00007ec68bfe498e  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe4997  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe49a0  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe49a9  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe49b2  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe49bb  add rsp, 0xF0
00007ec68bfe49c2  pop r11
00007ec68bfe49c4  pop r10
00007ec68bfe49c6  pop r9
00007ec68bfe49c8  pop r8
00007ec68bfe49ca  pop rsi
00007ec68bfe49cb  pop rdi
00007ec68bfe49cc  pop rdx
00007ec68bfe49cd  pop rcx
00007ec68bfe49ce  pop rax
00007ec68bfe49cf  add rsp, 0x08
00007ec68bfe49d3  jmp 0x00007EC68BFDFA00
00007ec68bfe49d8  sub rsp, 0x08
00007ec68bfe49dc  push rax
00007ec68bfe49dd  push rcx
00007ec68bfe49de  push rdx
00007ec68bfe49df  push rdi
00007ec68bfe49e0  push rsi
00007ec68bfe49e1  push r8
00007ec68bfe49e3  push r9
00007ec68bfe49e5  push r10
00007ec68bfe49e7  push r11
00007ec68bfe49e9  sub rsp, 0xF0
00007ec68bfe49f0  vmovaps [rsp], xmm0
00007ec68bfe49f5  vmovaps [rsp+0x10], xmm1
00007ec68bfe49fb  vmovaps [rsp+0x20], xmm2
00007ec68bfe4a01  vmovaps [rsp+0x30], xmm3
00007ec68bfe4a07  vmovaps [rsp+0x40], xmm4
00007ec68bfe4a0d  vmovaps [rsp+0x50], xmm5
00007ec68bfe4a13  vmovaps [rsp+0x60], xmm6
00007ec68bfe4a19  vmovaps [rsp+0x70], xmm7
00007ec68bfe4a1f  vmovaps [rsp+0x80], xmm8
00007ec68bfe4a28  vmovaps [rsp+0x90], xmm9
00007ec68bfe4a31  vmovaps [rsp+0xA0], xmm10
00007ec68bfe4a3a  vmovaps [rsp+0xB0], xmm11
00007ec68bfe4a43  vmovaps [rsp+0xC0], xmm12
00007ec68bfe4a4c  vmovaps [rsp+0xD0], xmm13
00007ec68bfe4a55  vmovaps [rsp+0xE0], xmm15
00007ec68bfe4a5e  sub rsp, 0x30
00007ec68bfe4a62  movaps [rsp], xmm14
00007ec68bfe4a67  movaps [rsp+0x10], xmm1
00007ec68bfe4a6c  movaps [rsp+0x20], xmm7
00007ec68bfe4a71  lea rdi, [rsp]
00007ec68bfe4a75  mov esi, 0x00
00007ec68bfe4a7a  mov rax, 0x57D97DADF530
00007ec68bfe4a84  call rax
00007ec68bfe4a86  movaps xmm14, [rsp]
00007ec68bfe4a8b  add rsp, 0x30
00007ec68bfe4a8f  vmovaps xmm0, [rsp]
00007ec68bfe4a94  vmovaps xmm1, [rsp+0x10]
00007ec68bfe4a9a  vmovaps xmm2, [rsp+0x20]
00007ec68bfe4aa0  vmovaps xmm3, [rsp+0x30]
00007ec68bfe4aa6  vmovaps xmm4, [rsp+0x40]
00007ec68bfe4aac  vmovaps xmm5, [rsp+0x50]
00007ec68bfe4ab2  vmovaps xmm6, [rsp+0x60]
00007ec68bfe4ab8  vmovaps xmm7, [rsp+0x70]
00007ec68bfe4abe  vmovaps xmm8, [rsp+0x80]
00007ec68bfe4ac7  vmovaps xmm9, [rsp+0x90]
00007ec68bfe4ad0  vmovaps xmm10, [rsp+0xA0]
00007ec68bfe4ad9  vmovaps xmm11, [rsp+0xB0]
00007ec68bfe4ae2  vmovaps xmm12, [rsp+0xC0]
00007ec68bfe4aeb  vmovaps xmm13, [rsp+0xD0]
00007ec68bfe4af4  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe4afd  add rsp, 0xF0
00007ec68bfe4b04  pop r11
00007ec68bfe4b06  pop r10
00007ec68bfe4b08  pop r9
00007ec68bfe4b0a  pop r8
00007ec68bfe4b0c  pop rsi
00007ec68bfe4b0d  pop rdi
00007ec68bfe4b0e  pop rdx
00007ec68bfe4b0f  pop rcx
00007ec68bfe4b10  pop rax
00007ec68bfe4b11  add rsp, 0x08
00007ec68bfe4b15  jmp 0x00007EC68BFDFA23
00007ec68bfe4b1a  sub rsp, 0x08
00007ec68bfe4b1e  push rax
00007ec68bfe4b1f  push rcx
00007ec68bfe4b20  push rdx
00007ec68bfe4b21  push rdi
00007ec68bfe4b22  push rsi
00007ec68bfe4b23  push r8
00007ec68bfe4b25  push r9
00007ec68bfe4b27  push r10
00007ec68bfe4b29  push r11
00007ec68bfe4b2b  sub rsp, 0xF0
00007ec68bfe4b32  vmovaps [rsp], xmm0
00007ec68bfe4b37  vmovaps [rsp+0x10], xmm2
00007ec68bfe4b3d  vmovaps [rsp+0x20], xmm3
00007ec68bfe4b43  vmovaps [rsp+0x30], xmm4
00007ec68bfe4b49  vmovaps [rsp+0x40], xmm5
00007ec68bfe4b4f  vmovaps [rsp+0x50], xmm6
00007ec68bfe4b55  vmovaps [rsp+0x60], xmm7
00007ec68bfe4b5b  vmovaps [rsp+0x70], xmm8
00007ec68bfe4b61  vmovaps [rsp+0x80], xmm9
00007ec68bfe4b6a  vmovaps [rsp+0x90], xmm10
00007ec68bfe4b73  vmovaps [rsp+0xA0], xmm11
00007ec68bfe4b7c  vmovaps [rsp+0xB0], xmm12
00007ec68bfe4b85  vmovaps [rsp+0xC0], xmm13
00007ec68bfe4b8e  vmovaps [rsp+0xD0], xmm14
00007ec68bfe4b97  vmovaps [rsp+0xE0], xmm15
00007ec68bfe4ba0  sub rsp, 0x30
00007ec68bfe4ba4  movaps [rsp], xmm1
00007ec68bfe4ba8  movaps [rsp+0x10], xmm8
00007ec68bfe4bae  movaps [rsp+0x20], xmm9
00007ec68bfe4bb4  lea rdi, [rsp]
00007ec68bfe4bb8  mov esi, 0x00
00007ec68bfe4bbd  mov rax, 0x57D97DADF530
00007ec68bfe4bc7  call rax
00007ec68bfe4bc9  movaps xmm1, [rsp]
00007ec68bfe4bcd  add rsp, 0x30
00007ec68bfe4bd1  vmovaps xmm0, [rsp]
00007ec68bfe4bd6  vmovaps xmm2, [rsp+0x10]
00007ec68bfe4bdc  vmovaps xmm3, [rsp+0x20]
00007ec68bfe4be2  vmovaps xmm4, [rsp+0x30]
00007ec68bfe4be8  vmovaps xmm5, [rsp+0x40]
00007ec68bfe4bee  vmovaps xmm6, [rsp+0x50]
00007ec68bfe4bf4  vmovaps xmm7, [rsp+0x60]
00007ec68bfe4bfa  vmovaps xmm8, [rsp+0x70]
00007ec68bfe4c00  vmovaps xmm9, [rsp+0x80]
00007ec68bfe4c09  vmovaps xmm10, [rsp+0x90]
00007ec68bfe4c12  vmovaps xmm11, [rsp+0xA0]
00007ec68bfe4c1b  vmovaps xmm12, [rsp+0xB0]
00007ec68bfe4c24  vmovaps xmm13, [rsp+0xC0]
00007ec68bfe4c2d  vmovaps xmm14, [rsp+0xD0]
00007ec68bfe4c36  vmovaps xmm15, [rsp+0xE0]
00007ec68bfe4c3f  add rsp, 0xF0
00007ec68bfe4c46  pop r11
00007ec68bfe4c48  pop r10
00007ec68bfe4c4a  pop r9
00007ec68bfe4c4c  pop r8
00007ec68bfe4c4e  pop rsi
00007ec68bfe4c4f  pop rdi
00007ec68bfe4c50  pop rdx
00007ec68bfe4c51  pop rcx
00007ec68bfe4c52  pop rax
00007ec68bfe4c53  add rsp, 0x08
00007ec68bfe4c57  jmp 0x00007EC68BFDFA45
00007ec68bfe4c5c  call 0x00007EC68BEE5940
00007ec68bfe4c61  jmp 0x00007EC68BFDFA53
00007ec68bfe4c66  call 0x00007EC68BE0C380
00007ec68bfe4c6b  jmp 0x00007EC68BFDFA5D
00007ec68bfe4c70  call 0x00007EC68BE0D600
00007ec68bfe4c75  jmp 0x00007EC68BFDFA67
00007ec68bfe4c7a  call 0x00007EC68BDFF540
00007ec68bfe4c7f  jmp 0x00007EC68BFDFA71
00007ec68bfe4c84  int3
00007ec68bfe4c85  nop [rax+rax*1], ax
00007ec68bfe4c8e  nop
00007ec68bfe4c90  mov qword ptr [r15+0x40], 0x430000
00007ec68bfe4c98  mov eax, 0x430CC0
00007ec68bfe4c9d  mov r14, [r13+rax*1]
00007ec68bfe4ca2  movq xmm1, r14
00007ec68bfe4ca7  mov rax, [r15+0x50]
00007ec68bfe4cab  movups xmm15, [r13+rax*1]
00007ec68bfe4cb1  movaps [r15+0x120], xmm15
00007ec68bfe4cb9  mov qword ptr [r15+0x48], 0x10
00007ec68bfe4cc1  xor eax, eax
00007ec68bfe4cc3  mov r14d, 0x10
00007ec68bfe4cc9  mov r12d, 0x200
00007ec68bfe4ccf  cmp r14, r12
00007ec68bfe4cd2  cmc
00007ec68bfe4cd3  lahf
00007ec68bfe4cd4  seto al
00007ec68bfe4cd7  mov [r15+0x108], eax
00007ec68bfe4cde  pextrq rax, xmm15, 0x01
00007ec68bfe4ce5  movq xmm14, rax
00007ec68bfe4cea  movaps [r15+0x130], xmm14
00007ec68bfe4cf2  movq rax, xmm1
00007ec68bfe4cf7  movq r14, xmm15
00007ec68bfe4cfc  vmovq xmm1, rax
00007ec68bfe4d01  vmovq xmm15, r14
00007ec68bfe4d06  movaps xmm13, xmm1
00007ec68bfe4d0a  addsd xmm13, xmm15
00007ec68bfe4d0f  ucomisd xmm13, xmm13
00007ec68bfe4d14  jp 0x00007EC68BFE4DD3
00007ec68bfe4d1a  movq xmm13, xmm13
00007ec68bfe4d1f  movq rax, xmm13
00007ec68bfe4d24  movq r14, xmm14
00007ec68bfe4d29  vmovq xmm1, rax
00007ec68bfe4d2e  vmovq xmm15, r14
00007ec68bfe4d33  movaps xmm14, xmm1
00007ec68bfe4d37  addsd xmm14, xmm15
00007ec68bfe4d3c  ucomisd xmm14, xmm14
00007ec68bfe4d41  jp 0x00007EC68BFE4E1B
00007ec68bfe4d47  movq xmm14, xmm14
00007ec68bfe4d4c  movaps [r15+0x110], xmm14
00007ec68bfe4d54  mov eax, [r15+0x108]
00007ec68bfe4d5b  sahf
00007ec68bfe4d5c  jnz 0x00007EC68BFE4D8E
00007ec68bfe4d5e  cmp dword ptr [r15+0x318], 0x00
00007ec68bfe4d66  jz 0x00007EC68BFE5030
00007ec68bfe4d6c  nop [rax+rax*1], ax
00007ec68bfe4d75  nop [rax+rax*1], eax
00007ec68bfe4d7d  mov eax, 0x410704
00007ec68bfe4d82  mov [r15+0x100], rax
00007ec68bfe4d89  jmp 0x00007EC68BDFE110
00007ec68bfe4d8e  cmp dword ptr [r15+0x318], 0x00
00007ec68bfe4d96  jz 0x00007EC68BFE4E70
00007ec68bfe4d9c  nop [rax+rax*1], ax
00007ec68bfe4da5  nop [rax+rax*1], eax
00007ec68bfe4dad  mov eax, 0x4106E8
00007ec68bfe4db2  mov [r15+0x100], rax
00007ec68bfe4db9  jmp 0x00007EC68BDFE110
00007ec68bfe4dbe  int3
00007ec68bfe4dbf  call 0x00007EC68BE0DC20
00007ec68bfe4dc4  jmp 0x00007EC68BFE4CA2
00007ec68bfe4dc9  call 0x00007EC68BE0E760
00007ec68bfe4dce  jmp 0x00007EC68BFE4CB1
00007ec68bfe4dd3  ucomisd xmm1, xmm15
00007ec68bfe4dd8  jp 0x00007EC68BFE4DE7
00007ec68bfe4dda  movaps xmm13, [0x00007EC68BBFE060]
00007ec68bfe4de2  jmp 0x00007EC68BFE4D1A
00007ec68bfe4de7  vxorps xmm0, xmm1, xmm15
00007ec68bfe4dec  pextrw eax, xmm0, 0x03
00007ec68bfe4df1  and eax, 0x7FF8
00007ec68bfe4df6  cmp eax, 0x08
00007ec68bfe4df9  jnz 0x00007EC68BFE4D1A
00007ec68bfe4dff  movq rax, xmm15
00007ec68bfe4e04  shl rax, 0x0D
00007ec68bfe4e08  jbe 0x00007EC68BFE4D1A
00007ec68bfe4e0e  vorps xmm13, xmm15, [0x00007EC68BBFE070]
00007ec68bfe4e16  jmp 0x00007EC68BFE4D1A
00007ec68bfe4e1b  ucomisd xmm1, xmm15
00007ec68bfe4e20  jp 0x00007EC68BFE4E2F
00007ec68bfe4e22  movaps xmm14, [0x00007EC68BBFE060]
00007ec68bfe4e2a  jmp 0x00007EC68BFE4D47
00007ec68bfe4e2f  vxorps xmm0, xmm1, xmm15
00007ec68bfe4e34  pextrw eax, xmm0, 0x03
00007ec68bfe4e39  and eax, 0x7FF8
00007ec68bfe4e3e  cmp eax, 0x08
00007ec68bfe4e41  jnz 0x00007EC68BFE4D47
00007ec68bfe4e47  movq rax, xmm15
00007ec68bfe4e4c  shl rax, 0x0D
00007ec68bfe4e50  jbe 0x00007EC68BFE4D47
00007ec68bfe4e56  vorps xmm14, xmm15, [0x00007EC68BBFE070]
00007ec68bfe4e5e  jmp 0x00007EC68BFE4D47
00007ec68bfe4e63  int3
00007ec68bfe4e64  nop [rax+rax*1], ax
00007ec68bfe4e6d  nop [rax], eax
00007ec68bfe4e70  mov rax, [r15+0x48]
00007ec68bfe4e74  mov r14, [r15+0x50]
00007ec68bfe4e78  lea r12, [r14+rax*1]
00007ec68bfe4e7c  movups xmm1, [r13+r12*1]
00007ec68bfe4e82  movaps [r15+0x120], xmm1
00007ec68bfe4e8a  lea r14, [rax+0x10]
00007ec68bfe4e8e  mov [r15+0x48], r14
00007ec68bfe4e92  xor eax, eax
00007ec68bfe4e94  mov r12d, 0x200
00007ec68bfe4e9a  cmp r14, r12
00007ec68bfe4e9d  cmc
00007ec68bfe4e9e  lahf
00007ec68bfe4e9f  seto al
00007ec68bfe4ea2  mov [r15+0x108], eax
00007ec68bfe4ea9  pextrq rax, xmm1, 0x01
00007ec68bfe4eb0  movq xmm15, rax
00007ec68bfe4eb5  movaps [r15+0x130], xmm15
00007ec68bfe4ebd  movaps xmm14, [r15+0x110]
00007ec68bfe4ec5  movq rax, xmm14
00007ec68bfe4eca  movq r14, xmm1
00007ec68bfe4ecf  vmovq xmm1, rax
00007ec68bfe4ed4  vmovq xmm14, r14
00007ec68bfe4ed9  movaps xmm13, xmm1
00007ec68bfe4edd  addsd xmm13, xmm14
00007ec68bfe4ee2  ucomisd xmm13, xmm13
00007ec68bfe4ee7  jp 0x00007EC68BFE4F9C
00007ec68bfe4eed  movq xmm13, xmm13
00007ec68bfe4ef2  movq rax, xmm13
00007ec68bfe4ef7  movq r14, xmm15
00007ec68bfe4efc  vmovq xmm1, rax
00007ec68bfe4f01  vmovq xmm15, r14
00007ec68bfe4f06  movaps xmm14, xmm1
00007ec68bfe4f0a  addsd xmm14, xmm15
00007ec68bfe4f0f  ucomisd xmm14, xmm14
00007ec68bfe4f14  jp 0x00007EC68BFE4FE4
00007ec68bfe4f1a  movq xmm14, xmm14
00007ec68bfe4f1f  movaps [r15+0x110], xmm14
00007ec68bfe4f27  mov eax, [r15+0x108]
00007ec68bfe4f2e  sahf
00007ec68bfe4f2f  jnz 0x00007EC68BFE4F61
00007ec68bfe4f31  cmp dword ptr [r15+0x318], 0x00
00007ec68bfe4f39  jz 0x00007EC68BFE5030
00007ec68bfe4f3f  nop [rax+rax*1], ax
00007ec68bfe4f48  nop [rax+rax*1], eax
00007ec68bfe4f50  mov eax, 0x410704
00007ec68bfe4f55  mov [r15+0x100], rax
00007ec68bfe4f5c  jmp 0x00007EC68BDFE110
00007ec68bfe4f61  cmp dword ptr [r15+0x318], 0x00
00007ec68bfe4f69  jz 0x00007EC68BFE4E70
00007ec68bfe4f6f  nop [rax+rax*1], ax
00007ec68bfe4f78  nop [rax+rax*1], eax
00007ec68bfe4f80  mov eax, 0x4106E8
00007ec68bfe4f85  mov [r15+0x100], rax
00007ec68bfe4f8c  jmp 0x00007EC68BDFE110
00007ec68bfe4f91  int3
00007ec68bfe4f92  call 0x00007EC68BEB52F0
00007ec68bfe4f97  jmp 0x00007EC68BFE4E82
00007ec68bfe4f9c  ucomisd xmm1, xmm14
00007ec68bfe4fa1  jp 0x00007EC68BFE4FB0
00007ec68bfe4fa3  movaps xmm13, [0x00007EC68BBFE060]
00007ec68bfe4fab  jmp 0x00007EC68BFE4EED
00007ec68bfe4fb0  vxorps xmm0, xmm1, xmm14
00007ec68bfe4fb5  pextrw eax, xmm0, 0x03
00007ec68bfe4fba  and eax, 0x7FF8
00007ec68bfe4fbf  cmp eax, 0x08
00007ec68bfe4fc2  jnz 0x00007EC68BFE4EED
00007ec68bfe4fc8  movq rax, xmm14
00007ec68bfe4fcd  shl rax, 0x0D
00007ec68bfe4fd1  jbe 0x00007EC68BFE4EED
00007ec68bfe4fd7  vorps xmm13, xmm14, [0x00007EC68BBFE070]
00007ec68bfe4fdf  jmp 0x00007EC68BFE4EED
00007ec68bfe4fe4  ucomisd xmm1, xmm15
00007ec68bfe4fe9  jp 0x00007EC68BFE4FF8
00007ec68bfe4feb  movaps xmm14, [0x00007EC68BBFE060]
00007ec68bfe4ff3  jmp 0x00007EC68BFE4F1A
00007ec68bfe4ff8  vxorps xmm0, xmm1, xmm15
00007ec68bfe4ffd  pextrw eax, xmm0, 0x03
00007ec68bfe5002  and eax, 0x7FF8
00007ec68bfe5007  cmp eax, 0x08
00007ec68bfe500a  jnz 0x00007EC68BFE4F1A
00007ec68bfe5010  movq rax, xmm15
00007ec68bfe5015  shl rax, 0x0D
00007ec68bfe5019  jbe 0x00007EC68BFE4F1A
00007ec68bfe501f  vorps xmm14, xmm15, [0x00007EC68BBFE070]
00007ec68bfe5027  jmp 0x00007EC68BFE4F1A
00007ec68bfe502c  int3
00007ec68bfe502d  nop [rax], eax
00007ec68bfe5030  mov rax, [r15+0xF8]
00007ec68bfe5037  lea r14, [rax+0x1D0]
00007ec68bfe503e  mov r12, [r13+r14*1]
00007ec68bfe5043  lea r14, [rax+0x1D8]
00007ec68bfe504a  mov r11, [r13+r14*1]
00007ec68bfe504f  mov [r15+0xA0], r12
00007ec68bfe5056  mov [r15+0x98], r11
00007ec68bfe505d  mov r14, [r15+0x40]
00007ec68bfe5061  lea r12, [r14+0xCC0]
00007ec68bfe5068  movaps xmm1, [r15+0x110]
00007ec68bfe5070  movq r14, xmm1
00007ec68bfe5075  mov [r13+r12*1], r14
00007ec68bfe507a  lea r14, [rax+0x1C0]
00007ec68bfe5081  mov r12, [r13+r14*1]
00007ec68bfe5086  lea r14, [rax+0x1C8]
00007ec68bfe508d  mov r11, [r13+r14*1]
00007ec68bfe5092  mov [r15+0xE8], r12
00007ec68bfe5099  mov [r15+0xF0], r11
00007ec68bfe50a0  lea r14, [rax+0x1B0]
00007ec68bfe50a7  mov r12, [r13+r14*1]
00007ec68bfe50ac  lea r14, [rax+0x1B8]
00007ec68bfe50b3  mov r10, [r13+r14*1]
00007ec68bfe50b8  movq xmm1, r12
00007ec68bfe50bd  movq xmm15, r10
00007ec68bfe50c2  movq xmm1, xmm1
00007ec68bfe50c6  movq xmm1, xmm1
00007ec68bfe50ca  movaps [r15+0x1A0], xmm1
00007ec68bfe50d2  movq xmm15, xmm15
00007ec68bfe50d7  movq xmm15, xmm15
00007ec68bfe50dc  movaps [r15+0x190], xmm15
00007ec68bfe50e4  lea r14, [rax+0x1A0]
00007ec68bfe50eb  mov r12, [r13+r14*1]
00007ec68bfe50f0  lea r14, [rax+0x1A8]
00007ec68bfe50f7  mov r10, [r13+r14*1]
00007ec68bfe50fc  movq xmm1, r12
00007ec68bfe5101  movq xmm15, r10
00007ec68bfe5106  movq xmm1, xmm1
00007ec68bfe510a  movq xmm1, xmm1
00007ec68bfe510e  movaps [r15+0x1C0], xmm1
00007ec68bfe5116  movq xmm15, xmm15
00007ec68bfe511b  movq xmm15, xmm15
00007ec68bfe5120  movaps [r15+0x1B0], xmm15
00007ec68bfe5128  lea r14, [rax+0x190]
00007ec68bfe512f  mov r12, [r13+r14*1]
00007ec68bfe5134  lea r14, [rax+0x198]
00007ec68bfe513b  mov r10, [r13+r14*1]
00007ec68bfe5140  movq xmm1, r12
00007ec68bfe5145  movq xmm15, r10
00007ec68bfe514a  movq xmm1, xmm1
00007ec68bfe514e  movq xmm1, xmm1
00007ec68bfe5152  movaps [r15+0x1E0], xmm1
00007ec68bfe515a  movq xmm15, xmm15
00007ec68bfe515f  movq xmm15, xmm15
00007ec68bfe5164  movaps [r15+0x1D0], xmm15
00007ec68bfe516c  lea r14, [rax+0x180]
00007ec68bfe5173  mov r12, [r13+r14*1]
00007ec68bfe5178  lea r14, [rax+0x188]
00007ec68bfe517f  mov r10, [r13+r14*1]
00007ec68bfe5184  movq xmm1, r12
00007ec68bfe5189  movq xmm15, r10
00007ec68bfe518e  movq xmm1, xmm1
00007ec68bfe5192  movq xmm1, xmm1
00007ec68bfe5196  movaps [r15+0x200], xmm1
00007ec68bfe519e  movq xmm15, xmm15
00007ec68bfe51a3  movq xmm15, xmm15
00007ec68bfe51a8  movaps [r15+0x1F0], xmm15
00007ec68bfe51b0  lea r14, [rax+0x1E0]
00007ec68bfe51b7  mov [r15+0xF8], r14
00007ec68bfe51be  mov [r15+0x100], r11
00007ec68bfe51c5  jmp 0x00007EC68BFCE5C0
00007ec68bfe51ca  int3
00007ec68bfe51cb  call 0x00007EC68BEE27E0
00007ec68bfe51d0  jmp 0x00007EC68BFE5043
00007ec68bfe51d5  call 0x00007EC68BEE1570
00007ec68bfe51da  jmp 0x00007EC68BFE504F
00007ec68bfe51df  call 0x00007EC68BEC3FE0
00007ec68bfe51e4  jmp 0x00007EC68BFE507A
00007ec68bfe51e9  call 0x00007EC68BEE27E0
00007ec68bfe51ee  jmp 0x00007EC68BFE5086
00007ec68bfe51f3  call 0x00007EC68BEE1570
00007ec68bfe51f8  jmp 0x00007EC68BFE5092
00007ec68bfe51fd  call 0x00007EC68BEE27E0
00007ec68bfe5202  jmp 0x00007EC68BFE50AC
00007ec68bfe5207  call 0x00007EC68BEE0300
00007ec68bfe520c  jmp 0x00007EC68BFE50B8
00007ec68bfe5211  call 0x00007EC68BEE27E0
00007ec68bfe5216  jmp 0x00007EC68BFE50F0
00007ec68bfe521b  call 0x00007EC68BEE0300
00007ec68bfe5220  jmp 0x00007EC68BFE50FC
00007ec68bfe5225  call 0x00007EC68BEE27E0
00007ec68bfe522a  jmp 0x00007EC68BFE5134
00007ec68bfe522f  call 0x00007EC68BEE0300
00007ec68bfe5234  jmp 0x00007EC68BFE5140
00007ec68bfe5239  call 0x00007EC68BEE27E0
00007ec68bfe523e  jmp 0x00007EC68BFE5178
00007ec68bfe5243  call 0x00007EC68BEE0300
00007ec68bfe5248  jmp 0x00007EC68BFE5184
00007ec68bfe524d  int3
00007ec68bfe524e  nop
00007ec68bfe5250  mov qword ptr [r15+0x100], 0x04
00007ec68bfe525b  mov esi, 0x00
00007ec68bfe5260  mov edx, 0x09
00007ec68bfe5265  mov rdi, 0x7FFFFD15E510
00007ec68bfe526f  mov rax, 0x57D97D972970
00007ec68bfe5279  call rax
00007ec68bfe527b  cmp dword ptr [r15+0x318], 0x00
00007ec68bfe5283  jnz 0x00007EC68BDFE110
00007ec68bfe5289  jmp 0x00007EC68BDFE0A0
00007ec68bfe528e  int3
00007ec68bfe528f  int3
