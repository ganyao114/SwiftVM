00007dd8609ce69b  nop [rax+rax*1], eax
00007dd8609ce6a0  mov rax, [r15+0xF8]
00007dd8609ce6a7  lea r14, [rax-0x1E0]
00007dd8609ce6ae  mov [r15+0xF8], r14
00007dd8609ce6b5  lea rax, [r14+0x1D0]
00007dd8609ce6bc  mov r12, [r15+0xA0]
00007dd8609ce6c3  mov r11, [r15+0x98]
00007dd8609ce6ca  mov [r13+rax*1], r12
00007dd8609ce6cf  lea rax, [r14+0x1D8]
00007dd8609ce6d6  mov [r13+rax*1], r11
00007dd8609ce6db  mov eax, 0x420AA0
00007dd8609ce6e0  movups xmm1, [r13+rax*1]
00007dd8609ce6e6  mov eax, 0x420A30
00007dd8609ce6eb  movups xmm15, [r13+rax*1]
00007dd8609ce6f1  mov eax, 0x420AC0
00007dd8609ce6f6  movups xmm14, [r13+rax*1]
00007dd8609ce6fc  mov eax, 0x420A60
00007dd8609ce701  movups xmm13, [r13+rax*1]
00007dd8609ce707  mov qword ptr [r15+0x98], 0x430CD0
00007dd8609ce712  mov eax, 0x420AD0
00007dd8609ce717  movups xmm12, [r13+rax*1]
00007dd8609ce71d  mov eax, 0x430CD0
00007dd8609ce722  movups [r13+rax*1], xmm1
00007dd8609ce728  mov eax, 0x430CE0
00007dd8609ce72d  movups [r13+rax*1], xmm15
00007dd8609ce733  mov eax, 0x430CF0
00007dd8609ce738  movups [r13+rax*1], xmm14
00007dd8609ce73e  mov eax, 0x430D00
00007dd8609ce743  movups [r13+rax*1], xmm13
00007dd8609ce749  mov eax, 0x420A20
00007dd8609ce74e  movups xmm14, [r13+rax*1]
00007dd8609ce754  mov eax, 0x420A10
00007dd8609ce759  movups xmm13, [r13+rax*1]
00007dd8609ce75f  mov eax, 0x430DD0
00007dd8609ce764  movups [r13+rax*1], xmm1
00007dd8609ce76a  mov eax, 0x430DE0
00007dd8609ce76f  movups [r13+rax*1], xmm15
00007dd8609ce775  mov eax, 0x430D10
00007dd8609ce77a  movups [r13+rax*1], xmm12
00007dd8609ce780  mov eax, 0x430D20
00007dd8609ce785  movups [r13+rax*1], xmm14
00007dd8609ce78b  mov eax, 0x420A00
00007dd8609ce790  movups xmm1, [r13+rax*1]
00007dd8609ce796  mov eax, 0x420A70
00007dd8609ce79b  movups xmm15, [r13+rax*1]
00007dd8609ce7a1  mov eax, 0x430D30
00007dd8609ce7a6  movups [r13+rax*1], xmm13
00007dd8609ce7ac  mov eax, 0x430D40
00007dd8609ce7b1  movups [r13+rax*1], xmm1
00007dd8609ce7b7  mov eax, 0x420A80
00007dd8609ce7bc  movups xmm1, [r13+rax*1]
00007dd8609ce7c2  mov eax, 0x420A50
00007dd8609ce7c7  movups xmm14, [r13+rax*1]
00007dd8609ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007dd8609ce7d5  mov eax, 0x430D50
00007dd8609ce7da  movups [r13+rax*1], xmm15
00007dd8609ce7e0  mov eax, 0x430D60
00007dd8609ce7e5  movups [r13+rax*1], xmm1
00007dd8609ce7eb  mov eax, 0x420AF0
00007dd8609ce7f0  movups xmm1, [r13+rax*1]
00007dd8609ce7f6  mov eax, 0x420B00
00007dd8609ce7fb  movups xmm15, [r13+rax*1]
00007dd8609ce801  movaps [r15+0x150], xmm15
00007dd8609ce809  mov qword ptr [r15+0xA0], 0x3E8
00007dd8609ce814  mov eax, 0x430D70
00007dd8609ce819  movups [r13+rax*1], xmm14
00007dd8609ce81f  mov eax, 0x430D80
00007dd8609ce824  movups [r13+rax*1], xmm1
00007dd8609ce82a  mov eax, 0x420AE0
00007dd8609ce82f  movups xmm1, [r13+rax*1]
00007dd8609ce835  mov eax, 0x420A90
00007dd8609ce83a  movups xmm14, [r13+rax*1]
00007dd8609ce840  movaps [r15+0x140], xmm14
00007dd8609ce848  lea rax, [r14+0x180]
00007dd8609ce84f  movq xmm13, qword ptr [r15+0x200]
00007dd8609ce858  movq xmm12, qword ptr [r15+0x1F0]
00007dd8609ce861  movq r12, xmm13
00007dd8609ce866  movq r11, xmm12
00007dd8609ce86b  mov [r13+rax*1], r12
00007dd8609ce870  lea rax, [r14+0x188]
00007dd8609ce877  mov [r13+rax*1], r11
00007dd8609ce87c  mov eax, 0x430D90
00007dd8609ce881  movups [r13+rax*1], xmm15
00007dd8609ce887  mov eax, 0x430DA0
00007dd8609ce88c  movups [r13+rax*1], xmm1
00007dd8609ce892  mov eax, 0x420AB0
00007dd8609ce897  movups xmm1, [r13+rax*1]
00007dd8609ce89d  mov eax, 0x420B18
00007dd8609ce8a2  mov r12, [r13+rax*1]
00007dd8609ce8a7  movq xmm15, r12
00007dd8609ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007dd8609ce8b4  mov eax, 0x430DB0
00007dd8609ce8b9  movups [r13+rax*1], xmm14
00007dd8609ce8bf  mov eax, 0x430DC0
00007dd8609ce8c4  movups [r13+rax*1], xmm1
00007dd8609ce8ca  mov eax, 0x420B80
00007dd8609ce8cf  movups xmm1, [r13+rax*1]
00007dd8609ce8d5  movq rax, xmm15
00007dd8609ce8da  mov r12d, 0x430DF0
00007dd8609ce8e0  mov [r13+r12*1], rax
00007dd8609ce8e5  mov eax, 0x420B60
00007dd8609ce8ea  movups xmm15, [r13+rax*1]
00007dd8609ce8f0  mov eax, 0x420B70
00007dd8609ce8f5  movups xmm14, [r13+rax*1]
00007dd8609ce8fb  lea rax, [r14+0x160]
00007dd8609ce902  movups [r13+rax*1], xmm1
00007dd8609ce908  lea rax, [r14+0x190]
00007dd8609ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007dd8609ce918  movq xmm13, qword ptr [r15+0x1D0]
00007dd8609ce921  movq r12, xmm1
00007dd8609ce926  movq r11, xmm13
00007dd8609ce92b  mov [r13+rax*1], r12
00007dd8609ce930  lea rax, [r14+0x198]
00007dd8609ce937  mov [r13+rax*1], r11
00007dd8609ce93c  lea rax, [r14+0x140]
00007dd8609ce943  movups [r13+rax*1], xmm15
00007dd8609ce949  lea rax, [r14+0x150]
00007dd8609ce950  movups [r13+rax*1], xmm14
00007dd8609ce956  mov eax, 0x420B20
00007dd8609ce95b  movups xmm1, [r13+rax*1]
00007dd8609ce961  mov eax, 0x420B30
00007dd8609ce966  movups xmm15, [r13+rax*1]
00007dd8609ce96c  movaps [r15+0x120], xmm15
00007dd8609ce974  lea rax, [r14+0x1A0]
00007dd8609ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007dd8609ce984  movq xmm13, qword ptr [r15+0x1B0]
00007dd8609ce98d  movq r12, xmm14
00007dd8609ce992  movq r11, xmm13
00007dd8609ce997  mov [r13+rax*1], r12
00007dd8609ce99c  lea rax, [r14+0x1A8]
00007dd8609ce9a3  mov [r13+rax*1], r11
00007dd8609ce9a8  lea rax, [r14+0x1B0]
00007dd8609ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007dd8609ce9b8  movq xmm13, qword ptr [r15+0x190]
00007dd8609ce9c1  movq r12, xmm14
00007dd8609ce9c6  movq r11, xmm13
00007dd8609ce9cb  mov [r13+rax*1], r12
00007dd8609ce9d0  lea rax, [r14+0x1B8]
00007dd8609ce9d7  mov [r13+rax*1], r11
00007dd8609ce9dc  lea rax, [r14+0x100]
00007dd8609ce9e3  movups [r13+rax*1], xmm1
00007dd8609ce9e9  lea rax, [r14+0x110]
00007dd8609ce9f0  movups [r13+rax*1], xmm15
00007dd8609ce9f6  mov eax, 0x420B40
00007dd8609ce9fb  movups xmm1, [r13+rax*1]
00007dd8609cea01  mov eax, 0x420B50
00007dd8609cea06  movups xmm15, [r13+rax*1]
00007dd8609cea0c  movaps [r15+0x110], xmm1
00007dd8609cea14  movaps [r15+0x130], xmm15
00007dd8609cea1c  lea rax, [r14+0x1C0]
00007dd8609cea23  mov r12, [r15+0xE8]
00007dd8609cea2a  mov r11, [r15+0xF0]
00007dd8609cea31  mov [r13+rax*1], r12
00007dd8609cea36  lea rax, [r14+0x1C8]
00007dd8609cea3d  mov [r13+rax*1], r11
00007dd8609cea42  mov eax, 0x430DF8
00007dd8609cea47  mov r12d, 0x421DF8D3
00007dd8609cea4d  mov [r13+rax*1], r12d
00007dd8609cea52  lea rax, [r14+0x120]
00007dd8609cea59  movups [r13+rax*1], xmm1
00007dd8609cea5f  lea rax, [r14+0x130]
00007dd8609cea66  movups [r13+rax*1], xmm15
00007dd8609cea6c  lea rax, [r14+0x100]
00007dd8609cea73  mov [r15], rax
00007dd8609cea76  mov qword ptr [r15+0x08], 0x430CD0
00007dd8609cea7e  mov qword ptr [r15+0x10], 0x12C
00007dd8609cea86  mov qword ptr [r15+0xF0], 0x410284
00007dd8609cea91  mov r14d, [r15+0x320]
00007dd8609cea98  mov eax, 0x410284
00007dd8609cea9d  mov rcx, 0x7DD8609D07C0
00007dd8609ceaa7  mov [r15+r14*8+0x328], rax
00007dd8609ceaaf  mov [r15+r14*8+0x368], rcx
00007dd8609ceab7  add r14d, 0x01
00007dd8609ceabb  and r14d, 0x07
00007dd8609ceabf  mov [r15+0x320], r14d
00007dd8609ceac6  cmp dword ptr [r15+0x318], 0x00
00007dd8609ceace  jz 0x00007DD8609CED70
00007dd8609cead4  nop [rax+rax*1], ax
00007dd8609ceadd  nop [rax+rax*1], eax
00007dd8609ceae5  mov eax, 0x410728
00007dd8609ceaea  mov [r15+0x100], rax
00007dd8609ceaf1  jmp 0x00007DD8607FE110
00007dd8609ceaf6  int3
00007dd8609ceaf7  call 0x00007DD86080BC20
00007dd8609ceafc  jmp 0x00007DD8609CE6CF
00007dd8609ceb01  call 0x00007DD86080A9A0
00007dd8609ceb06  jmp 0x00007DD8609CE6DB
00007dd8609ceb0b  call 0x00007DD8607FF430
00007dd8609ceb10  jmp 0x00007DD8609CE6E6
00007dd8609ceb15  call 0x00007DD86080E760
00007dd8609ceb1a  jmp 0x00007DD8609CE6F1
00007dd8609ceb1f  call 0x00007DD86080D4E0
00007dd8609ceb24  jmp 0x00007DD8609CE6FC
00007dd8609ceb29  call 0x00007DD86080C260
00007dd8609ceb2e  jmp 0x00007DD8609CE707
00007dd8609ceb33  call 0x00007DD86080AFE0
00007dd8609ceb38  jmp 0x00007DD8609CE71D
00007dd8609ceb3d  call 0x00007DD8607FF540
00007dd8609ceb42  jmp 0x00007DD8609CE728
00007dd8609ceb47  call 0x00007DD86080E880
00007dd8609ceb4c  jmp 0x00007DD8609CE733
00007dd8609ceb51  call 0x00007DD86080D600
00007dd8609ceb56  jmp 0x00007DD8609CE73E
00007dd8609ceb5b  call 0x00007DD86080C380
00007dd8609ceb60  jmp 0x00007DD8609CE749
00007dd8609ceb65  call 0x00007DD86080D4E0
00007dd8609ceb6a  jmp 0x00007DD8609CE754
00007dd8609ceb6f  call 0x00007DD86080C260
00007dd8609ceb74  jmp 0x00007DD8609CE75F
00007dd8609ceb79  call 0x00007DD8607FF540
00007dd8609ceb7e  jmp 0x00007DD8609CE76A
00007dd8609ceb83  call 0x00007DD86080E880
00007dd8609ceb88  jmp 0x00007DD8609CE775
00007dd8609ceb8d  call 0x00007DD86080B100
00007dd8609ceb92  jmp 0x00007DD8609CE780
00007dd8609ceb97  call 0x00007DD86080D600
00007dd8609ceb9c  jmp 0x00007DD8609CE78B
00007dd8609ceba1  call 0x00007DD8607FF430
00007dd8609ceba6  jmp 0x00007DD8609CE796
00007dd8609cebab  call 0x00007DD86080E760
00007dd8609cebb0  jmp 0x00007DD8609CE7A1
00007dd8609cebb5  call 0x00007DD86080C380
00007dd8609cebba  jmp 0x00007DD8609CE7AC
00007dd8609cebbf  call 0x00007DD8607FF540
00007dd8609cebc4  jmp 0x00007DD8609CE7B7
00007dd8609cebc9  call 0x00007DD8607FF430
00007dd8609cebce  jmp 0x00007DD8609CE7C2
00007dd8609cebd3  call 0x00007DD86080D4E0
00007dd8609cebd8  jmp 0x00007DD8609CE7CD
00007dd8609cebdd  call 0x00007DD86080E880
00007dd8609cebe2  jmp 0x00007DD8609CE7E0
00007dd8609cebe7  call 0x00007DD8607FF540
00007dd8609cebec  jmp 0x00007DD8609CE7EB
00007dd8609cebf1  call 0x00007DD8607FF430
00007dd8609cebf6  jmp 0x00007DD8609CE7F6
00007dd8609cebfb  call 0x00007DD86080E760
00007dd8609cec00  jmp 0x00007DD8609CE801
00007dd8609cec05  call 0x00007DD86080D600
00007dd8609cec0a  jmp 0x00007DD8609CE81F
00007dd8609cec0f  call 0x00007DD8607FF540
00007dd8609cec14  jmp 0x00007DD8609CE82A
00007dd8609cec19  call 0x00007DD8607FF430
00007dd8609cec1e  jmp 0x00007DD8609CE835
00007dd8609cec23  call 0x00007DD86080D4E0
00007dd8609cec28  jmp 0x00007DD8609CE840
00007dd8609cec2d  call 0x00007DD86080BC20
00007dd8609cec32  jmp 0x00007DD8609CE870
00007dd8609cec37  call 0x00007DD86080A9A0
00007dd8609cec3c  jmp 0x00007DD8609CE87C
00007dd8609cec41  call 0x00007DD86080E880
00007dd8609cec46  jmp 0x00007DD8609CE887
00007dd8609cec4b  call 0x00007DD8607FF540
00007dd8609cec50  jmp 0x00007DD8609CE892
00007dd8609cec55  call 0x00007DD8607FF430
00007dd8609cec5a  jmp 0x00007DD8609CE89D
00007dd8609cec5f  call 0x00007DD86080B720
00007dd8609cec64  jmp 0x00007DD8609CE8A7
00007dd8609cec69  call 0x00007DD86080D600
00007dd8609cec6e  jmp 0x00007DD8609CE8BF
00007dd8609cec73  call 0x00007DD8607FF540
00007dd8609cec78  jmp 0x00007DD8609CE8CA
00007dd8609cec7d  call 0x00007DD8607FF430
00007dd8609cec82  jmp 0x00007DD8609CE8D5
00007dd8609cec87  call 0x00007DD8608B4CB0
00007dd8609cec8c  jmp 0x00007DD8609CE8E5
00007dd8609cec91  call 0x00007DD86080E760
00007dd8609cec96  jmp 0x00007DD8609CE8F0
00007dd8609cec9b  call 0x00007DD86080D4E0
00007dd8609ceca0  jmp 0x00007DD8609CE8FB
00007dd8609ceca5  call 0x00007DD8607FF540
00007dd8609cecaa  jmp 0x00007DD8609CE908
00007dd8609cecaf  call 0x00007DD86080BC20
00007dd8609cecb4  jmp 0x00007DD8609CE930
00007dd8609cecb9  call 0x00007DD86080A9A0
00007dd8609cecbe  jmp 0x00007DD8609CE93C
00007dd8609cecc3  call 0x00007DD86080E880
00007dd8609cecc8  jmp 0x00007DD8609CE949
00007dd8609ceccd  call 0x00007DD86080D600
00007dd8609cecd2  jmp 0x00007DD8609CE956
00007dd8609cecd7  call 0x00007DD8607FF430
00007dd8609cecdc  jmp 0x00007DD8609CE961
00007dd8609cece1  call 0x00007DD86080E760
00007dd8609cece6  jmp 0x00007DD8609CE96C
00007dd8609ceceb  call 0x00007DD86080BC20
00007dd8609cecf0  jmp 0x00007DD8609CE99C
00007dd8609cecf5  call 0x00007DD86080A9A0
00007dd8609cecfa  jmp 0x00007DD8609CE9A8
00007dd8609cecff  call 0x00007DD86080BC20
00007dd8609ced04  jmp 0x00007DD8609CE9D0
00007dd8609ced09  call 0x00007DD86080A9A0
00007dd8609ced0e  jmp 0x00007DD8609CE9DC
00007dd8609ced13  call 0x00007DD8607FF540
00007dd8609ced18  jmp 0x00007DD8609CE9E9
00007dd8609ced1d  call 0x00007DD86080E880
00007dd8609ced22  jmp 0x00007DD8609CE9F6
00007dd8609ced27  call 0x00007DD8607FF430
00007dd8609ced2c  jmp 0x00007DD8609CEA01
00007dd8609ced31  call 0x00007DD86080E760
00007dd8609ced36  jmp 0x00007DD8609CEA0C
00007dd8609ced3b  call 0x00007DD86080BC20
00007dd8609ced40  jmp 0x00007DD8609CEA36
00007dd8609ced45  call 0x00007DD86080A9A0
00007dd8609ced4a  jmp 0x00007DD8609CEA42
00007dd8609ced4f  call 0x00007DD86080BAE0
00007dd8609ced54  jmp 0x00007DD8609CEA52
00007dd8609ced59  call 0x00007DD8607FF540
00007dd8609ced5e  jmp 0x00007DD8609CEA5F
00007dd8609ced63  call 0x00007DD86080E880
00007dd8609ced68  jmp 0x00007DD8609CEA6C
00007dd8609ced6d  int3
00007dd8609ced6e  nop
00007dd8609ced70  mov rax, [r15]
00007dd8609ced73  lea r14, [rax+0x20]
00007dd8609ced77  mov r12, [r13+r14*1]
00007dd8609ced7c  mov r14, [r15+0x10]
00007dd8609ced80  lea r11, [r12+r14*1]
00007dd8609ced84  mov [r15+0x40], r11
00007dd8609ced88  lea r12, [rax+0x20]
00007dd8609ced8c  mov [r13+r12*1], r11
00007dd8609ced91  test r14, r14
00007dd8609ced94  setz r14b
00007dd8609ced98  movzx r14, r14b
00007dd8609ced9c  mov [rsp+0x414], r14b
00007dd8609ceda4  cmp byte ptr [rsp+0x414], 0x00
00007dd8609cedac  jz 0x00007DD8609CEDDE
00007dd8609cedae  cmp dword ptr [r15+0x318], 0x00
00007dd8609cedb6  mov eax, 0x4109A0
00007dd8609cedbb  mov [r15+0x100], rax
00007dd8609cedc2  jz 0x00007DD8607FE0A0
00007dd8609cedc8  nop [rax+rax*1], eax
00007dd8609cedcd  mov eax, 0x4109A0
00007dd8609cedd2  mov [r15+0x100], rax
00007dd8609cedd9  jmp 0x00007DD8607FE110
00007dd8609cedde  cmp dword ptr [r15+0x318], 0x00
00007dd8609cede6  jz 0x00007DD8609CEE30
00007dd8609cedec  nop [rax+rax*1], ax
00007dd8609cedf5  nop [rax+rax*1], eax
00007dd8609cedfd  mov eax, 0x410738
00007dd8609cee02  mov [r15+0x100], rax
00007dd8609cee09  jmp 0x00007DD8607FE110
00007dd8609cee0e  int3
00007dd8609cee0f  call 0x00007DD8608E27E0
00007dd8609cee14  jmp 0x00007DD8609CED7C
00007dd8609cee19  call 0x00007DD8608C0860
00007dd8609cee1e  jmp 0x00007DD8609CED91
00007dd8609cee23  int3
00007dd8609cee24  nop [rax+rax*1], ax
00007dd8609cee2d  nop [rax], eax
00007dd8609cee30  mov rax, [r15+0xF8]
00007dd8609cee37  lea r14, [rax-0x150]
00007dd8609cee3e  mov [r15+0xF8], r14
00007dd8609cee45  mov rax, [r15]
00007dd8609cee48  lea r12, [rax+0x68]
00007dd8609cee4c  mov r11, [r13+r12*1]
00007dd8609cee51  mov [r15+0x88], r11
00007dd8609cee58  lea r12, [rax+0x28]
00007dd8609cee5c  mov [r15+0x40], r12
00007dd8609cee60  mov [r15+0x48], r14
00007dd8609cee64  mov qword ptr [r15+0x50], 0x420B90
00007dd8609cee6c  lea rax, [r14+0x100]
00007dd8609cee73  mov r12, [r15+0xE8]
00007dd8609cee7a  mov r11, [r15+0xD8]
00007dd8609cee81  mov [r13+rax*1], r12
00007dd8609cee86  lea rax, [r14+0x108]
00007dd8609cee8d  mov [r13+rax*1], r11
00007dd8609cee92  lea rax, [r14+0x110]
00007dd8609cee99  mov r12, [r15+0xD0]
00007dd8609ceea0  mov r11, [r15+0xC8]
00007dd8609ceea7  mov [r13+rax*1], r12
00007dd8609ceeac  lea rax, [r14+0x118]
00007dd8609ceeb3  mov [r13+rax*1], r11
00007dd8609ceeb8  lea rax, [r14+0x120]
00007dd8609ceebf  mov r12, [r15+0xC0]
00007dd8609ceec6  mov r11, [r15+0xB8]
00007dd8609ceecd  mov [r13+rax*1], r12
00007dd8609ceed2  lea rax, [r14+0x128]
00007dd8609ceed9  mov [r13+rax*1], r11
00007dd8609ceede  lea rax, [r14+0x130]
00007dd8609ceee5  mov r12, [r15+0xB0]
00007dd8609ceeec  mov r11, [r15+0xA8]
00007dd8609ceef3  mov [r13+rax*1], r12
00007dd8609ceef8  lea rax, [r14+0x138]
00007dd8609ceeff  mov [r13+rax*1], r11
00007dd8609cef04  lea rax, [r14+0x140]
00007dd8609cef0b  mov r12, [r15+0xA0]
00007dd8609cef12  mov r11, [r15+0x98]
00007dd8609cef19  mov [r13+rax*1], r12
00007dd8609cef1e  lea rax, [r14+0x148]
00007dd8609cef25  mov [r13+rax*1], r11
00007dd8609cef2a  cmp dword ptr [r15+0x318], 0x00
00007dd8609cef32  jz 0x00007DD8609CEFD0
00007dd8609cef38  nop [rax+rax*1], ax
00007dd8609cef41  nop [rax+rax*1], eax
00007dd8609cef49  mov eax, 0x410770
00007dd8609cef4e  mov [r15+0x100], rax
00007dd8609cef55  jmp 0x00007DD8607FE110
00007dd8609cef5a  int3
00007dd8609cef5b  call 0x00007DD8608C0370
00007dd8609cef60  jmp 0x00007DD8609CEE51
00007dd8609cef65  call 0x00007DD86080BC20
00007dd8609cef6a  jmp 0x00007DD8609CEE86
00007dd8609cef6f  call 0x00007DD86080A9A0
00007dd8609cef74  jmp 0x00007DD8609CEE92
00007dd8609cef79  call 0x00007DD86080BC20
00007dd8609cef7e  jmp 0x00007DD8609CEEAC
00007dd8609cef83  call 0x00007DD86080A9A0
00007dd8609cef88  jmp 0x00007DD8609CEEB8
00007dd8609cef8d  call 0x00007DD86080BC20
00007dd8609cef92  jmp 0x00007DD8609CEED2
00007dd8609cef97  call 0x00007DD86080A9A0
00007dd8609cef9c  jmp 0x00007DD8609CEEDE
00007dd8609cefa1  call 0x00007DD86080BC20
00007dd8609cefa6  jmp 0x00007DD8609CEEF8
00007dd8609cefab  call 0x00007DD86080A9A0
00007dd8609cefb0  jmp 0x00007DD8609CEF04
00007dd8609cefb5  call 0x00007DD86080BC20
00007dd8609cefba  jmp 0x00007DD8609CEF1E
00007dd8609cefbf  call 0x00007DD86080A9A0
00007dd8609cefc4  jmp 0x00007DD8609CEF2A
00007dd8609cefc9  int3
00007dd8609cefca  nop [rax+rax*1], ax
00007dd8609cefd0  mov rax, [r15+0x08]
00007dd8609cefd4  movzx r14d, byte ptr [r13+rax*1]
00007dd8609cefda  movzx r14d, r14b
00007dd8609cefde  mov [rsp+0x10], r14d
00007dd8609cefe3  mov r14d, r14d
00007dd8609cefe6  mov [r15+0x58], r14
00007dd8609cefea  lea r14, [rax+0x01]
00007dd8609cefee  mov [r15+0x08], r14
00007dd8609ceff2  mov rax, [r15+0x88]
00007dd8609ceff9  lea r14, [rax+0x01]
00007dd8609ceffd  mov r12, [r15]
00007dd8609cf000  lea r11, [r12+0x68]
00007dd8609cf005  mov [r13+r11*1], r14
00007dd8609cf00a  lea r14, [r12+rax*1]
00007dd8609cf00e  mov [r15+0x60], r14
00007dd8609cf012  lea rax, [r14+0x28]
00007dd8609cf016  mov r11d, [rsp+0x10]
00007dd8609cf01b  movzx r14d, r11b
00007dd8609cf01f  mov [r13+rax*1], r14b
00007dd8609cf024  lea rax, [r12+0x68]
00007dd8609cf029  mov r14, [r13+rax*1]
00007dd8609cf02e  mov [r15+0x88], r14
00007dd8609cf035  xor eax, eax
00007dd8609cf037  mov r12d, 0x40
00007dd8609cf03d  cmp r14, r12
00007dd8609cf040  cmc
00007dd8609cf041  lahf
00007dd8609cf042  seto al
00007dd8609cf045  mov [r15+0x108], eax
00007dd8609cf04c  mov eax, [r15+0x108]
00007dd8609cf053  sahf
00007dd8609cf054  jnz 0x00007DD8609CF086
00007dd8609cf056  cmp dword ptr [r15+0x318], 0x00
00007dd8609cf05e  jz 0x00007DD8609CF170
00007dd8609cf064  nop [rax+rax*1], ax
00007dd8609cf06d  nop [rax+rax*1], eax
00007dd8609cf075  mov eax, 0x410790
00007dd8609cf07a  mov [r15+0x100], rax
00007dd8609cf081  jmp 0x00007DD8607FE110
00007dd8609cf086  cmp dword ptr [r15+0x318], 0x00
00007dd8609cf08e  jz 0x00007DD8609CF0E0
00007dd8609cf094  nop [rax+rax*1], ax
00007dd8609cf09d  nop [rax+rax*1], eax
00007dd8609cf0a5  mov eax, 0x410768
00007dd8609cf0aa  mov [r15+0x100], rax
00007dd8609cf0b1  jmp 0x00007DD8607FE110
00007dd8609cf0b6  int3
00007dd8609cf0b7  call 0x00007DD86080D860
00007dd8609cf0bc  jmp 0x00007DD8609CEFDA
00007dd8609cf0c1  call 0x00007DD8608B36E0
00007dd8609cf0c6  jmp 0x00007DD8609CF00A
00007dd8609cf0cb  call 0x00007DD86080DD60
00007dd8609cf0d0  jmp 0x00007DD8609CF024
00007dd8609cf0d5  call 0x00007DD86080DC20
00007dd8609cf0da  jmp 0x00007DD8609CF02E
00007dd8609cf0df  int3
00007dd8609cf0e0  mov rax, [r15+0x10]
00007dd8609cf0e4  lea r14, [rax-0x01]
00007dd8609cf0e8  mov [r15+0x10], r14
00007dd8609cf0ec  test r14, r14
00007dd8609cf0ef  setz r14b
00007dd8609cf0f3  movzx r14, r14b
00007dd8609cf0f7  mov [rsp+0x414], r14b
00007dd8609cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007dd8609cf107  jz 0x00007DD8609CF139
00007dd8609cf109  cmp dword ptr [r15+0x318], 0x00
00007dd8609cf111  jz 0x00007DD8609D0670
00007dd8609cf117  nop [rax+rax*1], ax
00007dd8609cf120  nop [rax+rax*1], eax
00007dd8609cf128  mov eax, 0x410988
00007dd8609cf12d  mov [r15+0x100], rax
00007dd8609cf134  jmp 0x00007DD8607FE110
00007dd8609cf139  cmp dword ptr [r15+0x318], 0x00
00007dd8609cf141  jz 0x00007DD8609CEFD0
00007dd8609cf147  nop [rax+rax*1], ax
00007dd8609cf150  nop [rax+rax*1], eax
00007dd8609cf158  mov eax, 0x410770
00007dd8609cf15d  mov [r15+0x100], rax
00007dd8609cf164  jmp 0x00007DD8607FE110
00007dd8609cf169  int3
00007dd8609cf16a  int3
00007dd8609cf16b  nop [rax+rax*1], eax
00007dd8609cf170  mov rax, [r15+0x40]
00007dd8609cf174  movzx r14d, byte ptr [r13+rax*1]
00007dd8609cf17a  movaps xmm1, [r15+0x110]
00007dd8609cf182  pinsrb xmm1, r14d, 0x00
00007dd8609cf189  lea r14, [rax+0x01]
00007dd8609cf18d  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf193  movaps xmm15, [r15+0x120]
00007dd8609cf19b  pinsrb xmm15, r12d, 0x00
00007dd8609cf1a2  lea r14, [rax+0x02]
00007dd8609cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf1ac  movaps xmm14, [r15+0x130]
00007dd8609cf1b4  pinsrb xmm14, r12d, 0x00
00007dd8609cf1bb  lea r14, [rax+0x03]
00007dd8609cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf1c5  movaps xmm13, [r15+0x140]
00007dd8609cf1cd  pinsrb xmm13, r12d, 0x00
00007dd8609cf1d4  lea r14, [rax+0x04]
00007dd8609cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf1de  pinsrb xmm1, r12d, 0x01
00007dd8609cf1e5  lea r14, [rax+0x05]
00007dd8609cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf1ef  pinsrb xmm15, r12d, 0x01
00007dd8609cf1f6  lea r14, [rax+0x06]
00007dd8609cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf200  pinsrb xmm14, r12d, 0x01
00007dd8609cf207  lea r14, [rax+0x07]
00007dd8609cf20b  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf211  pinsrb xmm13, r12d, 0x01
00007dd8609cf218  lea r14, [rax+0x08]
00007dd8609cf21c  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf222  pinsrb xmm1, r12d, 0x02
00007dd8609cf229  lea r14, [rax+0x09]
00007dd8609cf22d  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf233  pinsrb xmm15, r12d, 0x02
00007dd8609cf23a  lea r14, [rax+0x0A]
00007dd8609cf23e  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf244  pinsrb xmm14, r12d, 0x02
00007dd8609cf24b  lea r14, [rax+0x0B]
00007dd8609cf24f  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf255  pinsrb xmm13, r12d, 0x02
00007dd8609cf25c  lea r14, [rax+0x0C]
00007dd8609cf260  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf266  pinsrb xmm1, r12d, 0x03
00007dd8609cf26d  lea r14, [rax+0x0D]
00007dd8609cf271  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf277  pinsrb xmm15, r12d, 0x03
00007dd8609cf27e  lea r14, [rax+0x0E]
00007dd8609cf282  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf288  pinsrb xmm14, r12d, 0x03
00007dd8609cf28f  lea r14, [rax+0x0F]
00007dd8609cf293  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf299  pinsrb xmm13, r12d, 0x03
00007dd8609cf2a0  lea r14, [rax+0x10]
00007dd8609cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf2aa  pinsrb xmm1, r12d, 0x04
00007dd8609cf2b1  lea r14, [rax+0x11]
00007dd8609cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf2bb  pinsrb xmm15, r12d, 0x04
00007dd8609cf2c2  lea r14, [rax+0x12]
00007dd8609cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf2cc  pinsrb xmm14, r12d, 0x04
00007dd8609cf2d3  lea r14, [rax+0x13]
00007dd8609cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf2dd  pinsrb xmm13, r12d, 0x04
00007dd8609cf2e4  lea r14, [rax+0x14]
00007dd8609cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf2ee  pinsrb xmm1, r12d, 0x05
00007dd8609cf2f5  lea r14, [rax+0x15]
00007dd8609cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf2ff  pinsrb xmm15, r12d, 0x05
00007dd8609cf306  lea r14, [rax+0x16]
00007dd8609cf30a  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf310  pinsrb xmm14, r12d, 0x05
00007dd8609cf317  lea r14, [rax+0x17]
00007dd8609cf31b  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf321  pinsrb xmm13, r12d, 0x05
00007dd8609cf328  lea r14, [rax+0x18]
00007dd8609cf32c  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf332  pinsrb xmm1, r12d, 0x06
00007dd8609cf339  lea r14, [rax+0x19]
00007dd8609cf33d  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf343  pinsrb xmm15, r12d, 0x06
00007dd8609cf34a  lea r14, [rax+0x1A]
00007dd8609cf34e  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf354  pinsrb xmm14, r12d, 0x06
00007dd8609cf35b  lea r14, [rax+0x1B]
00007dd8609cf35f  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf365  pinsrb xmm13, r12d, 0x06
00007dd8609cf36c  lea r14, [rax+0x1C]
00007dd8609cf370  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf376  pinsrb xmm1, r12d, 0x07
00007dd8609cf37d  lea r14, [rax+0x1D]
00007dd8609cf381  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf387  pinsrb xmm15, r12d, 0x07
00007dd8609cf38e  lea r14, [rax+0x1E]
00007dd8609cf392  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf398  pinsrb xmm14, r12d, 0x07
00007dd8609cf39f  lea r14, [rax+0x1F]
00007dd8609cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf3a9  pinsrb xmm13, r12d, 0x07
00007dd8609cf3b0  lea r14, [rax+0x20]
00007dd8609cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf3ba  pinsrb xmm1, r12d, 0x08
00007dd8609cf3c1  lea r14, [rax+0x21]
00007dd8609cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf3cb  pinsrb xmm15, r12d, 0x08
00007dd8609cf3d2  lea r14, [rax+0x22]
00007dd8609cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf3dc  pinsrb xmm14, r12d, 0x08
00007dd8609cf3e3  lea r14, [rax+0x23]
00007dd8609cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf3ed  pinsrb xmm13, r12d, 0x08
00007dd8609cf3f4  lea r14, [rax+0x24]
00007dd8609cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf3fe  pinsrb xmm1, r12d, 0x09
00007dd8609cf405  lea r14, [rax+0x25]
00007dd8609cf409  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf40f  pinsrb xmm15, r12d, 0x09
00007dd8609cf416  lea r14, [rax+0x26]
00007dd8609cf41a  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf420  pinsrb xmm14, r12d, 0x09
00007dd8609cf427  lea r14, [rax+0x27]
00007dd8609cf42b  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf431  pinsrb xmm13, r12d, 0x09
00007dd8609cf438  lea r14, [rax+0x28]
00007dd8609cf43c  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf442  pinsrb xmm1, r12d, 0x0A
00007dd8609cf449  lea r14, [rax+0x29]
00007dd8609cf44d  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf453  pinsrb xmm15, r12d, 0x0A
00007dd8609cf45a  lea r14, [rax+0x2A]
00007dd8609cf45e  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf464  pinsrb xmm14, r12d, 0x0A
00007dd8609cf46b  lea r14, [rax+0x2B]
00007dd8609cf46f  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf475  pinsrb xmm13, r12d, 0x0A
00007dd8609cf47c  lea r14, [rax+0x2C]
00007dd8609cf480  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf486  pinsrb xmm1, r12d, 0x0B
00007dd8609cf48d  lea r14, [rax+0x2D]
00007dd8609cf491  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf497  pinsrb xmm15, r12d, 0x0B
00007dd8609cf49e  lea r14, [rax+0x2E]
00007dd8609cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf4a8  pinsrb xmm14, r12d, 0x0B
00007dd8609cf4af  lea r14, [rax+0x2F]
00007dd8609cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf4b9  pinsrb xmm13, r12d, 0x0B
00007dd8609cf4c0  lea r14, [rax+0x30]
00007dd8609cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf4ca  pinsrb xmm1, r12d, 0x0C
00007dd8609cf4d1  lea r14, [rax+0x31]
00007dd8609cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf4db  pinsrb xmm15, r12d, 0x0C
00007dd8609cf4e2  lea r14, [rax+0x32]
00007dd8609cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf4ec  pinsrb xmm14, r12d, 0x0C
00007dd8609cf4f3  lea r14, [rax+0x33]
00007dd8609cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf4fd  pinsrb xmm13, r12d, 0x0C
00007dd8609cf504  lea r14, [rax+0x34]
00007dd8609cf508  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf50e  pinsrb xmm1, r12d, 0x0D
00007dd8609cf515  lea r14, [rax+0x35]
00007dd8609cf519  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf51f  pinsrb xmm15, r12d, 0x0D
00007dd8609cf526  lea r14, [rax+0x36]
00007dd8609cf52a  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf530  pinsrb xmm14, r12d, 0x0D
00007dd8609cf537  lea r14, [rax+0x37]
00007dd8609cf53b  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf541  pinsrb xmm13, r12d, 0x0D
00007dd8609cf548  lea r14, [rax+0x38]
00007dd8609cf54c  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf552  pinsrb xmm1, r12d, 0x0E
00007dd8609cf559  lea r14, [rax+0x39]
00007dd8609cf55d  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf563  pinsrb xmm15, r12d, 0x0E
00007dd8609cf56a  lea r14, [rax+0x3A]
00007dd8609cf56e  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf574  pinsrb xmm14, r12d, 0x0E
00007dd8609cf57b  lea r14, [rax+0x3B]
00007dd8609cf57f  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf585  pinsrb xmm13, r12d, 0x0E
00007dd8609cf58c  lea r14, [rax+0x3C]
00007dd8609cf590  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf596  pinsrb xmm1, r12d, 0x0F
00007dd8609cf59d  movaps [r15+0x110], xmm1
00007dd8609cf5a5  lea r14, [rax+0x3D]
00007dd8609cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf5af  pinsrb xmm15, r12d, 0x0F
00007dd8609cf5b6  movaps [r15+0x120], xmm15
00007dd8609cf5be  lea r14, [rax+0x3E]
00007dd8609cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007dd8609cf5c8  pinsrb xmm14, r12d, 0x0F
00007dd8609cf5cf  movaps [r15+0x130], xmm14
00007dd8609cf5d7  lea r14, [rax+0x3F]
00007dd8609cf5db  movzx eax, byte ptr [r13+r14*1]
00007dd8609cf5e1  pinsrb xmm13, eax, 0x0F
00007dd8609cf5e8  movaps [r15+0x140], xmm13
00007dd8609cf5f0  movq xmm1, qword ptr [r15+0x120]
00007dd8609cf5f9  pmovzxbw xmm1, xmm1
00007dd8609cf5fe  psllw xmm1, 0x00
00007dd8609cf603  movaps [r15+0x150], xmm1
00007dd8609cf60b  movq xmm1, qword ptr [r15+0x130]
00007dd8609cf614  pmovzxbw xmm1, xmm1
00007dd8609cf619  psllw xmm1, 0x00
00007dd8609cf61e  movaps [r15+0x160], xmm1
00007dd8609cf626  movq xmm1, qword ptr [r15+0x110]
00007dd8609cf62f  pmovzxbw xmm1, xmm1
00007dd8609cf634  psllw xmm1, 0x00
00007dd8609cf639  movaps [r15+0x170], xmm1
00007dd8609cf641  movaps xmm15, [r15+0x110]
00007dd8609cf649  pextrq rax, xmm15, 0x01
00007dd8609cf650  movq xmm15, rax
00007dd8609cf655  pmovzxbw xmm15, xmm15
00007dd8609cf65b  psllw xmm15, 0x00
00007dd8609cf661  movaps [r15+0x180], xmm15
00007dd8609cf669  movaps xmm14, [r15+0x120]
00007dd8609cf671  pextrq rax, xmm14, 0x01
00007dd8609cf678  movq xmm14, rax
00007dd8609cf67d  pmovzxbw xmm14, xmm14
00007dd8609cf683  psllw xmm14, 0x00
00007dd8609cf689  movaps [r15+0x210], xmm14
00007dd8609cf691  movaps xmm13, [r15+0x130]
00007dd8609cf699  pextrq rax, xmm13, 0x01
00007dd8609cf6a0  movq xmm13, rax
00007dd8609cf6a5  pmovzxbw xmm13, xmm13
00007dd8609cf6ab  psllw xmm13, 0x00
00007dd8609cf6b1  movaps [r15+0x220], xmm13
00007dd8609cf6b9  movq xmm12, qword ptr [r15+0x140]
00007dd8609cf6c2  pmovzxbw xmm12, xmm12
00007dd8609cf6c8  psllw xmm12, 0x00
00007dd8609cf6ce  movaps [r15+0x250], xmm12
00007dd8609cf6d6  movaps xmm12, [r15+0x140]
00007dd8609cf6de  pextrq rax, xmm12, 0x01
00007dd8609cf6e5  movq xmm12, rax
00007dd8609cf6ea  pmovzxbw xmm12, xmm12
00007dd8609cf6f0  psllw xmm12, 0x00
00007dd8609cf6f6  movaps [r15+0x110], xmm12
00007dd8609cf6fe  movq xmm11, qword ptr [r15+0x150]
00007dd8609cf707  pmovzxwd xmm11, xmm11
00007dd8609cf70d  pslld xmm11, 0x10
00007dd8609cf713  movq xmm10, qword ptr [r15+0x160]
00007dd8609cf71c  pmovzxwd xmm10, xmm10
00007dd8609cf722  pslld xmm10, 0x08
00007dd8609cf728  pextrq rax, xmm1, 0x01
00007dd8609cf72f  movq xmm1, rax
00007dd8609cf734  pmovzxwd xmm1, xmm1
00007dd8609cf739  pslld xmm1, 0x00
00007dd8609cf73e  movaps [r15+0x260], xmm1
00007dd8609cf746  pextrq rax, xmm15, 0x01
00007dd8609cf74d  movq xmm15, rax
00007dd8609cf752  pmovzxwd xmm15, xmm15
00007dd8609cf758  pslld xmm15, 0x00
00007dd8609cf75e  movaps [r15+0x270], xmm15
00007dd8609cf766  movq xmm9, qword ptr [r15+0x170]
00007dd8609cf76f  pmovzxwd xmm9, xmm9
00007dd8609cf775  pslld xmm9, 0x00
00007dd8609cf77b  pextrq rax, xmm14, 0x01
00007dd8609cf782  movq xmm14, rax
00007dd8609cf787  pmovzxwd xmm14, xmm14
00007dd8609cf78d  pslld xmm14, 0x10
00007dd8609cf793  movaps [r15+0x280], xmm14
00007dd8609cf79b  movq xmm8, qword ptr [r15+0x180]
00007dd8609cf7a4  pmovzxwd xmm8, xmm8
00007dd8609cf7aa  pslld xmm8, 0x00
00007dd8609cf7b0  movq xmm7, qword ptr [r15+0x210]
00007dd8609cf7b9  pmovzxwd xmm7, xmm7
00007dd8609cf7be  pslld xmm7, 0x10
00007dd8609cf7c3  movaps xmm6, [r15+0x150]
00007dd8609cf7cb  pextrq rax, xmm6, 0x01
00007dd8609cf7d2  movq xmm6, rax
00007dd8609cf7d7  pmovzxwd xmm6, xmm6
00007dd8609cf7dc  pslld xmm6, 0x10
00007dd8609cf7e1  por xmm11, xmm10
00007dd8609cf7e6  movaps [r15+0x230], xmm11
00007dd8609cf7ee  pextrq rax, xmm13, 0x01
00007dd8609cf7f5  movq xmm13, rax
00007dd8609cf7fa  pmovzxwd xmm13, xmm13
00007dd8609cf800  pslld xmm13, 0x08
00007dd8609cf806  movaps [r15+0x240], xmm13
00007dd8609cf80e  movq xmm10, qword ptr [r15+0x220]
00007dd8609cf817  pmovzxwd xmm10, xmm10
00007dd8609cf81d  pslld xmm10, 0x08
00007dd8609cf823  movaps xmm5, [r15+0x160]
00007dd8609cf82b  pextrq rax, xmm5, 0x01
00007dd8609cf832  movq xmm5, rax
00007dd8609cf837  pmovzxwd xmm5, xmm5
00007dd8609cf83c  pslld xmm5, 0x08
00007dd8609cf841  pslld xmm9, 0x18
00007dd8609cf847  pslld xmm15, 0x18
00007dd8609cf84d  pslld xmm8, 0x18
00007dd8609cf853  movq xmm4, qword ptr [r15+0x250]
00007dd8609cf85c  pmovzxwd xmm4, xmm4
00007dd8609cf861  pslld xmm4, 0x00
00007dd8609cf866  por xmm14, xmm13
00007dd8609cf86b  por xmm7, xmm10
00007dd8609cf870  movaps [r15+0x210], xmm7
00007dd8609cf878  pslld xmm1, 0x18
00007dd8609cf87d  movaps [r15+0x220], xmm1
00007dd8609cf885  por xmm6, xmm5
00007dd8609cf889  por xmm11, xmm9
00007dd8609cf88e  movaps [r15+0x160], xmm11
00007dd8609cf896  pextrq rax, xmm12, 0x01
00007dd8609cf89d  movq xmm13, rax
00007dd8609cf8a2  pmovzxwd xmm13, xmm13
00007dd8609cf8a8  pslld xmm13, 0x00
00007dd8609cf8ae  movaps [r15+0x170], xmm13
00007dd8609cf8b6  movq xmm12, qword ptr [r15+0x110]
00007dd8609cf8bf  pmovzxwd xmm12, xmm12
00007dd8609cf8c5  pslld xmm12, 0x00
00007dd8609cf8cb  por xmm14, xmm15
00007dd8609cf8d0  por xmm7, xmm8
00007dd8609cf8d5  movaps xmm15, [r15+0x250]
00007dd8609cf8dd  pextrq rax, xmm15, 0x01
00007dd8609cf8e4  movq xmm15, rax
00007dd8609cf8e9  pmovzxwd xmm15, xmm15
00007dd8609cf8ef  pslld xmm15, 0x00
00007dd8609cf8f5  movaps [r15+0x180], xmm15
00007dd8609cf8fd  por xmm6, xmm1
00007dd8609cf901  movaps [r15+0x150], xmm6
00007dd8609cf909  por xmm11, xmm4
00007dd8609cf90e  movaps [r15+0x140], xmm11
00007dd8609cf916  por xmm7, xmm12
00007dd8609cf91b  movaps [r15+0x110], xmm7
00007dd8609cf923  por xmm14, xmm13
00007dd8609cf928  movaps [r15+0x120], xmm14
00007dd8609cf930  por xmm6, xmm15
00007dd8609cf935  movaps [r15+0x130], xmm6
00007dd8609cf93d  mov rax, [r15+0xF8]
00007dd8609cf944  lea r14, [rax+0x20]
00007dd8609cf948  movups [r13+r14*1], xmm7
00007dd8609cf94e  lea r14, [rax+0x30]
00007dd8609cf952  movups [r13+r14*1], xmm14
00007dd8609cf958  movups [r13+rax*1], xmm11
00007dd8609cf95e  lea r14, [rax+0x10]
00007dd8609cf962  movups [r13+r14*1], xmm6
00007dd8609cf968  mov r14d, [r13+rax*1]
00007dd8609cf96d  mov rax, [r15+0x48]
00007dd8609cf971  mov [r15+0x68], rax
00007dd8609cf975  mov qword ptr [r15+0x58], 0x04
00007dd8609cf97d  lea r12, [rax+0x04]
00007dd8609cf981  mov r11d, [r13+r12*1]
00007dd8609cf986  mov [rsp+0x10], r11d
00007dd8609cf98b  mov r11d, r11d
00007dd8609cf98e  mov [r15+0x70], r11
00007dd8609cf992  lea r12, [rax+0x38]
00007dd8609cf996  mov r11d, [r13+r12*1]
00007dd8609cf99b  lea r12, [rax+0x24]
00007dd8609cf99f  mov r10d, [r13+r12*1]
00007dd8609cf9a4  mov [rsp+0x20], r10d
00007dd8609cf9a9  mov r10d, r10d
00007dd8609cf9ac  mov [r15+0x90], r10
00007dd8609cf9b3  mov [rsp+0x30], rax
00007dd8609cf9b8  xor eax, eax
00007dd8609cf9ba  mov r12d, 0x04
00007dd8609cf9c0  mov r10d, 0xC0
00007dd8609cf9c6  cmp r12, r10
00007dd8609cf9c9  cmc
00007dd8609cf9ca  lahf
00007dd8609cf9cb  seto al
00007dd8609cf9ce  mov [r15+0x108], eax
00007dd8609cf9d5  mov eax, [rsp+0x10]
00007dd8609cf9d9  mov r12d, [rsp+0x10]
00007dd8609cf9de  shrd eax, r12d, 0x07
00007dd8609cf9e3  mov [rsp+0x10], r11d
00007dd8609cf9e8  mov r10d, [rsp+0x10]
00007dd8609cf9ed  shrd r11d, r10d, 0x11
00007dd8609cf9f2  mov r9d, [rsp+0x20]
00007dd8609cf9f7  lea r8d, [r9d+r14d*1]
00007dd8609cf9fc  rorx r14d, r12d, 0x12
00007dd8609cfa02  xor eax, r14d
00007dd8609cfa05  rorx r14d, r10d, 0x13
00007dd8609cfa0b  xor r11d, r14d
00007dd8609cfa0e  mov [rsp+0x10], r11d
00007dd8609cfa13  mov r11d, r11d
00007dd8609cfa16  mov [r15+0x88], r11
00007dd8609cfa1d  mov [rsp+0x20], r12d
00007dd8609cfa22  shr r12d, 0x03
00007dd8609cfa26  xor eax, r12d
00007dd8609cfa29  mov [rsp+0x40], eax
00007dd8609cfa2d  mov eax, eax
00007dd8609cfa2f  mov [r15+0x80], rax
00007dd8609cfa36  shr r10d, 0x0A
00007dd8609cfa3a  mov eax, [rsp+0x10]
00007dd8609cfa3e  xor eax, r10d
00007dd8609cfa41  mov [rsp+0x10], eax
00007dd8609cfa45  mov eax, eax
00007dd8609cfa47  mov [r15+0x78], rax
00007dd8609cfa4b  mov eax, [rsp+0x40]
00007dd8609cfa4f  lea r14d, [r8d+eax*1]
00007dd8609cfa54  mov eax, [rsp+0x10]
00007dd8609cfa58  lea r12d, [r14d+eax*1]
00007dd8609cfa5d  mov rax, [rsp+0x30]
00007dd8609cfa62  lea r14, [rax+0x40]
00007dd8609cfa66  mov [r13+r14*1], r12d
00007dd8609cfa6b  mov eax, [rsp+0x20]
00007dd8609cfa6f  mov eax, eax
00007dd8609cfa71  mov [r15+0x60], rax
00007dd8609cfa75  mov eax, [r15+0x108]
00007dd8609cfa7c  sahf
00007dd8609cfa7d  jnz 0x00007DD8609CFAAF
00007dd8609cfa7f  cmp dword ptr [r15+0x318], 0x00
00007dd8609cfa87  jz 0x00007DD8609CFF70
00007dd8609cfa8d  nop [rax+rax*1], ax
00007dd8609cfa96  nop [rax+rax*1], eax
00007dd8609cfa9e  mov eax, 0x41088C
00007dd8609cfaa3  mov [r15+0x100], rax
00007dd8609cfaaa  jmp 0x00007DD8607FE110
00007dd8609cfaaf  cmp dword ptr [r15+0x318], 0x00
00007dd8609cfab7  jz 0x00007DD8609CFDC0
00007dd8609cfabd  nop [rax+rax*1], ax
00007dd8609cfac6  nop [rax+rax*1], eax
00007dd8609cface  mov eax, 0x410844
00007dd8609cfad3  mov [r15+0x100], rax
00007dd8609cfada  jmp 0x00007DD8607FE110
00007dd8609cfadf  int3
00007dd8609cfae0  call 0x00007DD86080D860
00007dd8609cfae5  jmp 0x00007DD8609CF17A
00007dd8609cfaea  call 0x00007DD8608E2420
00007dd8609cfaef  jmp 0x00007DD8609CF193
00007dd8609cfaf4  call 0x00007DD8608E2420
00007dd8609cfaf9  jmp 0x00007DD8609CF1AC
00007dd8609cfafe  call 0x00007DD8608E2420
00007dd8609cfb03  jmp 0x00007DD8609CF1C5
00007dd8609cfb08  call 0x00007DD8608E2420
00007dd8609cfb0d  jmp 0x00007DD8609CF1DE
00007dd8609cfb12  call 0x00007DD8608E2420
00007dd8609cfb17  jmp 0x00007DD8609CF1EF
00007dd8609cfb1c  call 0x00007DD8608E2420
00007dd8609cfb21  jmp 0x00007DD8609CF200
00007dd8609cfb26  call 0x00007DD8608E2420
00007dd8609cfb2b  jmp 0x00007DD8609CF211
00007dd8609cfb30  call 0x00007DD8608E2420
00007dd8609cfb35  jmp 0x00007DD8609CF222
00007dd8609cfb3a  call 0x00007DD8608E2420
00007dd8609cfb3f  jmp 0x00007DD8609CF233
00007dd8609cfb44  call 0x00007DD8608E2420
00007dd8609cfb49  jmp 0x00007DD8609CF244
00007dd8609cfb4e  call 0x00007DD8608E2420
00007dd8609cfb53  jmp 0x00007DD8609CF255
00007dd8609cfb58  call 0x00007DD8608E2420
00007dd8609cfb5d  jmp 0x00007DD8609CF266
00007dd8609cfb62  call 0x00007DD8608E2420
00007dd8609cfb67  jmp 0x00007DD8609CF277
00007dd8609cfb6c  call 0x00007DD8608E2420
00007dd8609cfb71  jmp 0x00007DD8609CF288
00007dd8609cfb76  call 0x00007DD8608E2420
00007dd8609cfb7b  jmp 0x00007DD8609CF299
00007dd8609cfb80  call 0x00007DD8608E2420
00007dd8609cfb85  jmp 0x00007DD8609CF2AA
00007dd8609cfb8a  call 0x00007DD8608E2420
00007dd8609cfb8f  jmp 0x00007DD8609CF2BB
00007dd8609cfb94  call 0x00007DD8608E2420
00007dd8609cfb99  jmp 0x00007DD8609CF2CC
00007dd8609cfb9e  call 0x00007DD8608E2420
00007dd8609cfba3  jmp 0x00007DD8609CF2DD
00007dd8609cfba8  call 0x00007DD8608E2420
00007dd8609cfbad  jmp 0x00007DD8609CF2EE
00007dd8609cfbb2  call 0x00007DD8608E2420
00007dd8609cfbb7  jmp 0x00007DD8609CF2FF
00007dd8609cfbbc  call 0x00007DD8608E2420
00007dd8609cfbc1  jmp 0x00007DD8609CF310
00007dd8609cfbc6  call 0x00007DD8608E2420
00007dd8609cfbcb  jmp 0x00007DD8609CF321
00007dd8609cfbd0  call 0x00007DD8608E2420
00007dd8609cfbd5  jmp 0x00007DD8609CF332
00007dd8609cfbda  call 0x00007DD8608E2420
00007dd8609cfbdf  jmp 0x00007DD8609CF343
00007dd8609cfbe4  call 0x00007DD8608E2420
00007dd8609cfbe9  jmp 0x00007DD8609CF354
00007dd8609cfbee  call 0x00007DD8608E2420
00007dd8609cfbf3  jmp 0x00007DD8609CF365
00007dd8609cfbf8  call 0x00007DD8608E2420
00007dd8609cfbfd  jmp 0x00007DD8609CF376
00007dd8609cfc02  call 0x00007DD8608E2420
00007dd8609cfc07  jmp 0x00007DD8609CF387
00007dd8609cfc0c  call 0x00007DD8608E2420
00007dd8609cfc11  jmp 0x00007DD8609CF398
00007dd8609cfc16  call 0x00007DD8608E2420
00007dd8609cfc1b  jmp 0x00007DD8609CF3A9
00007dd8609cfc20  call 0x00007DD8608E2420
00007dd8609cfc25  jmp 0x00007DD8609CF3BA
00007dd8609cfc2a  call 0x00007DD8608E2420
00007dd8609cfc2f  jmp 0x00007DD8609CF3CB
00007dd8609cfc34  call 0x00007DD8608E2420
00007dd8609cfc39  jmp 0x00007DD8609CF3DC
00007dd8609cfc3e  call 0x00007DD8608E2420
00007dd8609cfc43  jmp 0x00007DD8609CF3ED
00007dd8609cfc48  call 0x00007DD8608E2420
00007dd8609cfc4d  jmp 0x00007DD8609CF3FE
00007dd8609cfc52  call 0x00007DD8608E2420
00007dd8609cfc57  jmp 0x00007DD8609CF40F
00007dd8609cfc5c  call 0x00007DD8608E2420
00007dd8609cfc61  jmp 0x00007DD8609CF420
00007dd8609cfc66  call 0x00007DD8608E2420
00007dd8609cfc6b  jmp 0x00007DD8609CF431
00007dd8609cfc70  call 0x00007DD8608E2420
00007dd8609cfc75  jmp 0x00007DD8609CF442
00007dd8609cfc7a  call 0x00007DD8608E2420
00007dd8609cfc7f  jmp 0x00007DD8609CF453
00007dd8609cfc84  call 0x00007DD8608E2420
00007dd8609cfc89  jmp 0x00007DD8609CF464
00007dd8609cfc8e  call 0x00007DD8608E2420
00007dd8609cfc93  jmp 0x00007DD8609CF475
00007dd8609cfc98  call 0x00007DD8608E2420
00007dd8609cfc9d  jmp 0x00007DD8609CF486
00007dd8609cfca2  call 0x00007DD8608E2420
00007dd8609cfca7  jmp 0x00007DD8609CF497
00007dd8609cfcac  call 0x00007DD8608E2420
00007dd8609cfcb1  jmp 0x00007DD8609CF4A8
00007dd8609cfcb6  call 0x00007DD8608E2420
00007dd8609cfcbb  jmp 0x00007DD8609CF4B9
00007dd8609cfcc0  call 0x00007DD8608E2420
00007dd8609cfcc5  jmp 0x00007DD8609CF4CA
00007dd8609cfcca  call 0x00007DD8608E2420
00007dd8609cfccf  jmp 0x00007DD8609CF4DB
00007dd8609cfcd4  call 0x00007DD8608E2420
00007dd8609cfcd9  jmp 0x00007DD8609CF4EC
00007dd8609cfcde  call 0x00007DD8608E2420
00007dd8609cfce3  jmp 0x00007DD8609CF4FD
00007dd8609cfce8  call 0x00007DD8608E2420
00007dd8609cfced  jmp 0x00007DD8609CF50E
00007dd8609cfcf2  call 0x00007DD8608E2420
00007dd8609cfcf7  jmp 0x00007DD8609CF51F
00007dd8609cfcfc  call 0x00007DD8608E2420
00007dd8609cfd01  jmp 0x00007DD8609CF530
00007dd8609cfd06  call 0x00007DD8608E2420
00007dd8609cfd0b  jmp 0x00007DD8609CF541
00007dd8609cfd10  call 0x00007DD8608E2420
00007dd8609cfd15  jmp 0x00007DD8609CF552
00007dd8609cfd1a  call 0x00007DD8608E2420
00007dd8609cfd1f  jmp 0x00007DD8609CF563
00007dd8609cfd24  call 0x00007DD8608E2420
00007dd8609cfd29  jmp 0x00007DD8609CF574
00007dd8609cfd2e  call 0x00007DD8608E2420
00007dd8609cfd33  jmp 0x00007DD8609CF585
00007dd8609cfd38  call 0x00007DD8608E2420
00007dd8609cfd3d  jmp 0x00007DD8609CF596
00007dd8609cfd42  call 0x00007DD8608E2420
00007dd8609cfd47  jmp 0x00007DD8609CF5AF
00007dd8609cfd4c  call 0x00007DD8608E2420
00007dd8609cfd51  jmp 0x00007DD8609CF5C8
00007dd8609cfd56  call 0x00007DD8608D5610
00007dd8609cfd5b  jmp 0x00007DD8609CF5E1
00007dd8609cfd60  call 0x00007DD8608DC580
00007dd8609cfd65  jmp 0x00007DD8609CF94E
00007dd8609cfd6a  call 0x00007DD8608E46C0
00007dd8609cfd6f  jmp 0x00007DD8609CF958
00007dd8609cfd74  call 0x00007DD860809E90
00007dd8609cfd79  jmp 0x00007DD8609CF95E
00007dd8609cfd7e  call 0x00007DD8608DB310
00007dd8609cfd83  jmp 0x00007DD8609CF968
00007dd8609cfd88  call 0x00007DD86080DAE0
00007dd8609cfd8d  jmp 0x00007DD8609CF96D
00007dd8609cfd92  call 0x00007DD8608C0230
00007dd8609cfd97  jmp 0x00007DD8609CF986
00007dd8609cfd9c  call 0x00007DD8608C0230
00007dd8609cfda1  jmp 0x00007DD8609CF99B
00007dd8609cfda6  call 0x00007DD8608BEFC0
00007dd8609cfdab  jmp 0x00007DD8609CF9A4
00007dd8609cfdb0  call 0x00007DD8608E2BA0
00007dd8609cfdb5  jmp 0x00007DD8609CFA6B
00007dd8609cfdba  int3
00007dd8609cfdbb  nop [rax+rax*1], eax
00007dd8609cfdc0  mov rax, [r15+0x48]
00007dd8609cfdc4  mov r14, [r15+0x58]
00007dd8609cfdc8  lea r12, [rax+r14*1]
00007dd8609cfdcc  mov [r15+0x68], r12
00007dd8609cfdd0  lea rax, [r14+0x04]
00007dd8609cfdd4  mov [r15+0x58], rax
00007dd8609cfdd8  lea r14, [r12+0x04]
00007dd8609cfddd  mov r11d, [r13+r14*1]
00007dd8609cfde2  mov [rsp+0x10], r11d
00007dd8609cfde7  mov r11d, r11d
00007dd8609cfdea  mov [r15+0x70], r11
00007dd8609cfdee  lea r14, [r12+0x38]
00007dd8609cfdf3  mov r11d, [r13+r14*1]
00007dd8609cfdf8  lea r14, [r12+0x24]
00007dd8609cfdfd  mov r10d, [r13+r14*1]
00007dd8609cfe02  mov [rsp+0x20], r10d
00007dd8609cfe07  mov r10d, r10d
00007dd8609cfe0a  mov [r15+0x90], r10
00007dd8609cfe11  mov [rsp+0x30], rax
00007dd8609cfe16  xor eax, eax
00007dd8609cfe18  mov r14, [rsp+0x30]
00007dd8609cfe1d  mov r10d, 0xC0
00007dd8609cfe23  cmp r14, r10
00007dd8609cfe26  cmc
00007dd8609cfe27  lahf
00007dd8609cfe28  seto al
00007dd8609cfe2b  mov [r15+0x108], eax
00007dd8609cfe32  mov eax, [rsp+0x10]
00007dd8609cfe36  mov r14d, [rsp+0x10]
00007dd8609cfe3b  shrd eax, r14d, 0x07
00007dd8609cfe40  mov [rsp+0x10], r11d
00007dd8609cfe45  mov r10d, [rsp+0x10]
00007dd8609cfe4a  shrd r11d, r10d, 0x11
00007dd8609cfe4f  mov r9d, [r15+0x60]
00007dd8609cfe53  mov r8d, [rsp+0x20]
00007dd8609cfe58  lea ebp, [r8d+r9d*1]
00007dd8609cfe5d  rorx r9d, r14d, 0x12
00007dd8609cfe63  xor eax, r9d
00007dd8609cfe66  rorx r9d, r10d, 0x13
00007dd8609cfe6c  xor r11d, r9d
00007dd8609cfe6f  mov [rsp+0x10], r11d
00007dd8609cfe74  mov r11d, r11d
00007dd8609cfe77  mov [r15+0x88], r11
00007dd8609cfe7e  mov [rsp+0x20], r14d
00007dd8609cfe83  shr r14d, 0x03
00007dd8609cfe87  xor eax, r14d
00007dd8609cfe8a  mov [rsp+0x30], eax
00007dd8609cfe8e  mov eax, eax
00007dd8609cfe90  mov [r15+0x80], rax
00007dd8609cfe97  shr r10d, 0x0A
00007dd8609cfe9b  mov eax, [rsp+0x10]
00007dd8609cfe9f  xor eax, r10d
00007dd8609cfea2  mov [rsp+0x10], eax
00007dd8609cfea6  mov eax, eax
00007dd8609cfea8  mov [r15+0x78], rax
00007dd8609cfeac  mov eax, [rsp+0x30]
00007dd8609cfeb0  lea r14d, [ebp+eax*1]
00007dd8609cfeb6  mov eax, [rsp+0x10]
00007dd8609cfeba  lea r11d, [r14d+eax*1]
00007dd8609cfebf  lea rax, [r12+0x40]
00007dd8609cfec4  mov [r13+rax*1], r11d
00007dd8609cfec9  mov eax, [rsp+0x20]
00007dd8609cfecd  mov eax, eax
00007dd8609cfecf  mov [r15+0x60], rax
00007dd8609cfed3  mov eax, [r15+0x108]
00007dd8609cfeda  sahf
00007dd8609cfedb  jnz 0x00007DD8609CFF0D
00007dd8609cfedd  cmp dword ptr [r15+0x318], 0x00
00007dd8609cfee5  jz 0x00007DD8609CFF70
00007dd8609cfeeb  nop [rax+rax*1], ax
00007dd8609cfef4  nop [rax+rax*1], eax
00007dd8609cfefc  mov eax, 0x41088C
00007dd8609cff01  mov [r15+0x100], rax
00007dd8609cff08  jmp 0x00007DD8607FE110
00007dd8609cff0d  cmp dword ptr [r15+0x318], 0x00
00007dd8609cff15  jz 0x00007DD8609CFDC0
00007dd8609cff1b  nop [rax+rax*1], ax
00007dd8609cff24  nop [rax+rax*1], eax
00007dd8609cff2c  mov eax, 0x410844
00007dd8609cff31  mov [r15+0x100], rax
00007dd8609cff38  jmp 0x00007DD8607FE110
00007dd8609cff3d  int3
00007dd8609cff3e  call 0x00007DD8608E1430
00007dd8609cff43  jmp 0x00007DD8609CFDE2
00007dd8609cff48  call 0x00007DD8608E1430
00007dd8609cff4d  jmp 0x00007DD8609CFDF8
00007dd8609cff52  call 0x00007DD8608E01C0
00007dd8609cff57  jmp 0x00007DD8609CFE02
00007dd8609cff5c  call 0x00007DD86080A860
00007dd8609cff61  jmp 0x00007DD8609CFEC9
00007dd8609cff66  int3
00007dd8609cff67  nop [rax+rax*1], ax
00007dd8609cff70  mov rax, [r15]
00007dd8609cff73  mov r14d, [r13+rax*1]
00007dd8609cff78  lea r12, [rax+0x04]
00007dd8609cff7c  mov r11d, [r13+r12*1]
00007dd8609cff81  mov [rsp+0x10], r14d
00007dd8609cff86  mov r14d, r14d
00007dd8609cff89  mov [r15+0x78], r14
00007dd8609cff8d  mov [rsp+0x20], r11d
00007dd8609cff92  mov r11d, r11d
00007dd8609cff95  mov [r15+0x80], r11
00007dd8609cff9c  lea r14, [rax+0x08]
00007dd8609cffa0  mov r12d, [r13+r14*1]
00007dd8609cffa5  lea r14, [rax+0x0C]
00007dd8609cffa9  mov r11d, [r13+r14*1]
00007dd8609cffae  mov [rsp+0x30], r12d
00007dd8609cffb3  mov r12d, r12d
00007dd8609cffb6  mov [r15+0x70], r12
00007dd8609cffba  mov [rsp+0x40], r11d
00007dd8609cffbf  mov r11d, r11d
00007dd8609cffc2  mov [r15+0x68], r11
00007dd8609cffc6  lea r14, [rax+0x18]
00007dd8609cffca  mov r12d, [r13+r14*1]
00007dd8609cffcf  lea r14, [rax+0x1C]
00007dd8609cffd3  mov r11d, [r13+r14*1]
00007dd8609cffd8  mov [rsp+0x50], r12d
00007dd8609cffdd  mov r12d, r12d
00007dd8609cffe0  mov [r15+0x58], r12
00007dd8609cffe4  mov [rsp+0x60], r11d
00007dd8609cffe9  mov r11d, r11d
00007dd8609cffec  mov [r15+0x60], r11
00007dd8609cfff0  lea r14, [rax+0x10]
00007dd8609cfff4  mov r12d, [r13+r14*1]
00007dd8609cfff9  lea r14, [rax+0x14]
00007dd8609cfffd  mov eax, [r13+r14*1]
00007dd8609d0002  mov [rsp+0x70], r12d
00007dd8609d0007  mov r12d, r12d
00007dd8609d000a  mov [r15+0x18], r12
00007dd8609d000e  mov [rsp+0x80], eax
00007dd8609d0015  mov eax, eax
00007dd8609d0017  mov [r15+0x90], rax
00007dd8609d001e  mov eax, [rsp+0x70]
00007dd8609d0022  mov eax, eax
00007dd8609d0024  mov [r15+0x30], rax
00007dd8609d0028  mov eax, [rsp+0x50]
00007dd8609d002c  mov eax, eax
00007dd8609d002e  mov [r15+0xA0], rax
00007dd8609d0035  mov eax, [rsp+0x30]
00007dd8609d0039  mov eax, eax
00007dd8609d003b  mov [r15+0x28], rax
00007dd8609d003f  mov eax, [rsp+0x20]
00007dd8609d0043  mov eax, eax
00007dd8609d0045  mov [r15+0x98], rax
00007dd8609d004c  mov eax, [rsp+0x10]
00007dd8609d0050  mov eax, eax
00007dd8609d0052  mov [r15+0x38], rax
00007dd8609d0056  mov eax, [rsp+0x70]
00007dd8609d005a  mov r14d, [rsp+0x70]
00007dd8609d005f  shrd eax, r14d, 0x06
00007dd8609d0064  mov [rsp+0x70], r14d
00007dd8609d0069  mov r12d, [rsp+0x80]
00007dd8609d0071  and r14d, r12d
00007dd8609d0074  mov r11d, [rsp+0x10]
00007dd8609d0079  mov r10d, [rsp+0x10]
00007dd8609d007e  shrd r11d, r10d, 0x02
00007dd8609d0083  mov [rsp+0x10], r12d
00007dd8609d0088  mov r12d, r12d
00007dd8609d008b  mov [r15+0x20], r12
00007dd8609d008f  mov r12, [r15+0x50]
00007dd8609d0093  mov r9d, [r13+r12*1]
00007dd8609d0098  mov r12d, [rsp+0x50]
00007dd8609d009d  mov r8d, [rsp+0x70]
00007dd8609d00a2  andn ebp, r8d, r12d
00007dd8609d00a7  mov edi, [rsp+0x60]
00007dd8609d00ab  lea esi, [r14d+edi*1]
00007dd8609d00b0  rorx r14d, r8d, 0x0B
00007dd8609d00b6  xor eax, r14d
00007dd8609d00b9  rorx r14d, r10d, 0x0D
00007dd8609d00bf  xor r11d, r14d
00007dd8609d00c2  lea edi, [esi+ebp*1]
00007dd8609d00c6  mov r14, [r15+0x48]
00007dd8609d00ca  mov ebp, [r13+r14*1]
00007dd8609d00cf  mov r14d, [rsp+0x30]
00007dd8609d00d4  mov esi, [rsp+0x20]
00007dd8609d00d8  and r14d, esi
00007dd8609d00db  mov [rsp+0x20], r14d
00007dd8609d00e0  mov r14d, r14d
00007dd8609d00e3  mov [r15+0xD8], r14
00007dd8609d00ea  lea r14d, [edi+r9d*1]
00007dd8609d00ef  mov r9d, [rsp+0x30]
00007dd8609d00f4  xor r9d, esi
00007dd8609d00f7  rorx edi, r8d, 0x19
00007dd8609d00fd  xor eax, edi
00007dd8609d00ff  and r9d, r10d
00007dd8609d0102  rorx edi, r10d, 0x16
00007dd8609d0108  xor r11d, edi
00007dd8609d010b  mov [rsp+0x30], r11d
00007dd8609d0110  mov r11d, r11d
00007dd8609d0113  mov [r15+0xD0], r11
00007dd8609d011a  lea r11d, [r14d+ebp*1]
00007dd8609d011f  mov r10d, [rsp+0x20]
00007dd8609d0124  xor r9d, r10d
00007dd8609d0127  lea r14d, [r11d+eax*1]
00007dd8609d012c  mov qword ptr [r15+0x88], 0x04
00007dd8609d0137  mov eax, [rsp+0x30]
00007dd8609d013b  lea r11d, [r9d+eax*1]
00007dd8609d0140  mov eax, [rsp+0x40]
00007dd8609d0144  lea r10d, [r14d+eax*1]
00007dd8609d0149  mov r10d, r10d
00007dd8609d014c  mov [r15+0xB8], r10
00007dd8609d0153  xor eax, eax
00007dd8609d0155  mov r10d, 0x04
00007dd8609d015b  mov r9d, 0x100
00007dd8609d0161  cmp r10, r9
00007dd8609d0164  cmc
00007dd8609d0165  lahf
00007dd8609d0166  seto al
00007dd8609d0169  mov [r15+0x108], eax
00007dd8609d0170  lea eax, [r11d+r14d*1]
00007dd8609d0175  mov eax, eax
00007dd8609d0177  mov [r15+0xA8], rax
00007dd8609d017e  mov r12d, r12d
00007dd8609d0181  mov [r15+0xB0], r12
00007dd8609d0188  mov eax, [rsp+0x10]
00007dd8609d018c  mov eax, eax
00007dd8609d018e  mov [r15+0xC0], rax
00007dd8609d0195  mov r8d, r8d
00007dd8609d0198  mov [r15+0xC8], r8
00007dd8609d019f  mov eax, [r15+0x108]
00007dd8609d01a6  sahf
00007dd8609d01a7  jnz 0x00007DD8609D01D9
00007dd8609d01a9  cmp dword ptr [r15+0x318], 0x00
00007dd8609d01b1  jz 0x00007DD8609D04A0
00007dd8609d01b7  nop [rax+rax*1], ax
00007dd8609d01c0  nop [rax+rax*1], eax
00007dd8609d01c8  mov eax, 0x41094C
00007dd8609d01cd  mov [r15+0x100], rax
00007dd8609d01d4  jmp 0x00007DD8607FE110
00007dd8609d01d9  cmp dword ptr [r15+0x318], 0x00
00007dd8609d01e1  jz 0x00007DD8609D0270
00007dd8609d01e7  nop [rax+rax*1], ax
00007dd8609d01f0  nop [rax+rax*1], eax
00007dd8609d01f8  mov eax, 0x4108C0
00007dd8609d01fd  mov [r15+0x100], rax
00007dd8609d0204  jmp 0x00007DD8607FE110
00007dd8609d0209  int3
00007dd8609d020a  call 0x00007DD86080DAE0
00007dd8609d020f  jmp 0x00007DD8609CFF78
00007dd8609d0214  call 0x00007DD8608C0230
00007dd8609d0219  jmp 0x00007DD8609CFF81
00007dd8609d021e  call 0x00007DD8608E26A0
00007dd8609d0223  jmp 0x00007DD8609CFFA5
00007dd8609d0228  call 0x00007DD8608E1430
00007dd8609d022d  jmp 0x00007DD8609CFFAE
00007dd8609d0232  call 0x00007DD8608E26A0
00007dd8609d0237  jmp 0x00007DD8609CFFCF
00007dd8609d023c  call 0x00007DD8608E1430
00007dd8609d0241  jmp 0x00007DD8609CFFD8
00007dd8609d0246  call 0x00007DD8608E26A0
00007dd8609d024b  jmp 0x00007DD8609CFFF9
00007dd8609d0250  call 0x00007DD8608D5890
00007dd8609d0255  jmp 0x00007DD8609D0002
00007dd8609d025a  call 0x00007DD8608BDD50
00007dd8609d025f  jmp 0x00007DD8609D0098
00007dd8609d0264  call 0x00007DD8608DA580
00007dd8609d0269  jmp 0x00007DD8609D00CF
00007dd8609d026e  int3
00007dd8609d026f  nop
00007dd8609d0270  mov eax, [r15+0xB8]
00007dd8609d0277  mov [rsp+0x10], eax
00007dd8609d027b  mov eax, eax
00007dd8609d027d  mov [r15+0x30], rax
00007dd8609d0281  mov eax, [r15+0xC0]
00007dd8609d0288  mov [rsp+0x20], eax
00007dd8609d028c  mov eax, eax
00007dd8609d028e  mov [r15+0xA0], rax
00007dd8609d0295  mov eax, [r15+0x28]
00007dd8609d0299  mov r14d, [r15+0x98]
00007dd8609d02a0  mov [rsp+0x30], r14d
00007dd8609d02a5  mov r14d, r14d
00007dd8609d02a8  mov [r15+0x28], r14
00007dd8609d02ac  mov r14d, [r15+0x38]
00007dd8609d02b0  mov [rsp+0x40], r14d
00007dd8609d02b5  mov r14d, r14d
00007dd8609d02b8  mov [r15+0x98], r14
00007dd8609d02bf  mov r14d, [r15+0xA8]
00007dd8609d02c6  mov [rsp+0x50], r14d
00007dd8609d02cb  mov r14d, r14d
00007dd8609d02ce  mov [r15+0x38], r14
00007dd8609d02d2  mov r14d, [rsp+0x10]
00007dd8609d02d7  mov r12d, [rsp+0x10]
00007dd8609d02dc  shrd r14d, r12d, 0x06
00007dd8609d02e1  mov r11d, [r15+0xC8]
00007dd8609d02e8  mov [rsp+0x10], r12d
00007dd8609d02ed  and r12d, r11d
00007dd8609d02f0  mov r10d, [rsp+0x50]
00007dd8609d02f5  mov r9d, [rsp+0x50]
00007dd8609d02fa  shrd r10d, r9d, 0x02
00007dd8609d02ff  mov [rsp+0x50], r11d
00007dd8609d0304  mov r11d, r11d
00007dd8609d0307  mov [r15+0x20], r11
00007dd8609d030b  mov r11, [r15+0x88]
00007dd8609d0312  mov r8, [r15+0x50]
00007dd8609d0316  lea rbp, [r8+r11*1]
00007dd8609d031a  mov r8d, [r13+rbp*1]
00007dd8609d031f  mov ebp, [rsp+0x20]
00007dd8609d0323  mov edi, [rsp+0x10]
00007dd8609d0327  andn esi, edi, ebp
00007dd8609d032c  mov edx, [r15+0xB0]
00007dd8609d0333  lea ecx, [r12d+edx*1]
00007dd8609d0338  rorx r12d, edi, 0x0B
00007dd8609d033e  xor r14d, r12d
00007dd8609d0341  rorx r12d, r9d, 0x0D
00007dd8609d0347  xor r10d, r12d
00007dd8609d034a  lea r12d, [ecx+esi*1]
00007dd8609d034f  mov rsi, [r15+0x48]
00007dd8609d0353  lea rdx, [rsi+r11*1]
00007dd8609d0357  mov esi, [r13+rdx*1]
00007dd8609d035c  mov edx, [rsp+0x30]
00007dd8609d0360  mov ecx, [rsp+0x40]
00007dd8609d0364  and edx, ecx
00007dd8609d0366  mov [rsp+0x10], edx
00007dd8609d036a  mov edx, edx
00007dd8609d036c  mov [r15+0xD8], rdx
00007dd8609d0373  lea edx, [r12d+r8d*1]
00007dd8609d0378  mov r12d, [rsp+0x30]
00007dd8609d037d  xor r12d, ecx
00007dd8609d0380  rorx r8d, edi, 0x19
00007dd8609d0386  xor r14d, r8d
00007dd8609d0389  and r12d, r9d
00007dd8609d038c  rorx r8d, r9d, 0x16
00007dd8609d0392  xor r10d, r8d
00007dd8609d0395  mov [rsp+0x20], r10d
00007dd8609d039a  mov r10d, r10d
00007dd8609d039d  mov [r15+0xD0], r10
00007dd8609d03a4  lea r10d, [edx+esi*1]
00007dd8609d03a9  mov r9d, [rsp+0x10]
00007dd8609d03ae  xor r12d, r9d
00007dd8609d03b1  lea r9d, [r10d+r14d*1]
00007dd8609d03b6  lea r14, [r11+0x04]
00007dd8609d03ba  mov [r15+0x88], r14
00007dd8609d03c1  mov r11d, [rsp+0x20]
00007dd8609d03c6  lea r10d, [r12d+r11d*1]
00007dd8609d03cb  lea r11d, [r9d+eax*1]
00007dd8609d03d0  mov r11d, r11d
00007dd8609d03d3  mov [r15+0xB8], r11
00007dd8609d03da  xor eax, eax
00007dd8609d03dc  mov r12d, 0x100
00007dd8609d03e2  cmp r14, r12
00007dd8609d03e5  cmc
00007dd8609d03e6  lahf
00007dd8609d03e7  seto al
00007dd8609d03ea  mov [r15+0x108], eax
00007dd8609d03f1  lea eax, [r10d+r9d*1]
00007dd8609d03f6  mov eax, eax
00007dd8609d03f8  mov [r15+0xA8], rax
00007dd8609d03ff  mov ebp, ebp
00007dd8609d0401  mov [r15+0xB0], rbp
00007dd8609d0408  mov eax, [rsp+0x50]
00007dd8609d040c  mov eax, eax
00007dd8609d040e  mov [r15+0xC0], rax
00007dd8609d0415  mov edi, edi
00007dd8609d0417  mov [r15+0xC8], rdi
00007dd8609d041e  mov eax, [r15+0x108]
00007dd8609d0425  sahf
00007dd8609d0426  jnz 0x00007DD8609D0458
00007dd8609d0428  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0430  jz 0x00007DD8609D04A0
00007dd8609d0436  nop [rax+rax*1], ax
00007dd8609d043f  nop [rax+rax*1], eax
00007dd8609d0447  mov eax, 0x41094C
00007dd8609d044c  mov [r15+0x100], rax
00007dd8609d0453  jmp 0x00007DD8607FE110
00007dd8609d0458  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0460  jz 0x00007DD8609D0270
00007dd8609d0466  nop [rax+rax*1], ax
00007dd8609d046f  nop [rax+rax*1], eax
00007dd8609d0477  mov eax, 0x4108C0
00007dd8609d047c  mov [r15+0x100], rax
00007dd8609d0483  jmp 0x00007DD8607FE110
00007dd8609d0488  int3
00007dd8609d0489  call 0x00007DD860849010
00007dd8609d048e  jmp 0x00007DD8609D031F
00007dd8609d0493  call 0x00007DD860825930
00007dd8609d0498  jmp 0x00007DD8609D035C
00007dd8609d049d  int3
00007dd8609d049e  nop
00007dd8609d04a0  mov eax, [r15+0x98]
00007dd8609d04a7  mov r14d, [r15+0x70]
00007dd8609d04ab  lea r12d, [eax+r14d*1]
00007dd8609d04b0  mov eax, [r15+0x28]
00007dd8609d04b4  mov r14d, [r15+0x68]
00007dd8609d04b8  lea r11d, [eax+r14d*1]
00007dd8609d04bd  mov qword ptr [r15+0x88], 0x00
00007dd8609d04c8  mov eax, [r15+0xA8]
00007dd8609d04cf  mov r14d, [r15+0x78]
00007dd8609d04d3  lea r10d, [eax+r14d*1]
00007dd8609d04d8  mov [rsp+0x10], r10d
00007dd8609d04dd  mov r10d, r10d
00007dd8609d04e0  mov [r15+0x78], r10
00007dd8609d04e4  mov eax, [r15+0x38]
00007dd8609d04e8  mov r14d, [r15+0x80]
00007dd8609d04ef  lea r10d, [eax+r14d*1]
00007dd8609d04f4  mov [rsp+0x20], r10d
00007dd8609d04f9  mov r10d, r10d
00007dd8609d04fc  mov [r15+0x80], r10
00007dd8609d0503  mov rax, [r15]
00007dd8609d0506  lea r14, [rax+0x08]
00007dd8609d050a  mov [r13+r14*1], r12d
00007dd8609d050f  lea r14, [rax+0x0C]
00007dd8609d0513  mov [r13+r14*1], r11d
00007dd8609d0518  mov r14d, [r15+0xB8]
00007dd8609d051f  mov r12d, [r15+0x18]
00007dd8609d0523  lea r11d, [r14d+r12d*1]
00007dd8609d0528  mov [rsp+0x30], r11d
00007dd8609d052d  mov r11d, r11d
00007dd8609d0530  mov [r15+0x68], r11
00007dd8609d0534  mov r14d, [r15+0x30]
00007dd8609d0538  mov r12d, [r15+0x90]
00007dd8609d053f  lea r11d, [r14d+r12d*1]
00007dd8609d0544  mov [rsp+0x40], r11d
00007dd8609d0549  mov r11d, r11d
00007dd8609d054c  mov [r15+0x70], r11
00007dd8609d0550  mov r14d, [r15+0x20]
00007dd8609d0554  mov r12d, [r15+0x58]
00007dd8609d0558  lea r11d, [r14d+r12d*1]
00007dd8609d055d  mov [rsp+0x50], r11d
00007dd8609d0562  mov r11d, r11d
00007dd8609d0565  mov [r15+0x58], r11
00007dd8609d0569  mov r14d, [r15+0xA0]
00007dd8609d0570  mov r12d, [r15+0x60]
00007dd8609d0574  lea r11d, [r14d+r12d*1]
00007dd8609d0579  mov [rsp+0x60], r11d
00007dd8609d057e  mov r11d, r11d
00007dd8609d0581  mov [r15+0x60], r11
00007dd8609d0585  mov r14d, [rsp+0x10]
00007dd8609d058a  mov [r13+rax*1], r14d
00007dd8609d058f  lea r14, [rax+0x04]
00007dd8609d0593  mov r12d, [rsp+0x20]
00007dd8609d0598  mov [r13+r14*1], r12d
00007dd8609d059d  lea r14, [rax+0x10]
00007dd8609d05a1  mov r12d, [rsp+0x30]
00007dd8609d05a6  mov [r13+r14*1], r12d
00007dd8609d05ab  lea r14, [rax+0x14]
00007dd8609d05af  mov r12d, [rsp+0x40]
00007dd8609d05b4  mov [r13+r14*1], r12d
00007dd8609d05b9  lea r14, [rax+0x18]
00007dd8609d05bd  mov r12d, [rsp+0x50]
00007dd8609d05c2  mov [r13+r14*1], r12d
00007dd8609d05c7  lea r14, [rax+0x1C]
00007dd8609d05cb  mov r12d, [rsp+0x60]
00007dd8609d05d0  mov [r13+r14*1], r12d
00007dd8609d05d5  lea r14, [rax+0x68]
00007dd8609d05d9  xor eax, eax
00007dd8609d05db  mov [r13+r14*1], rax
00007dd8609d05e0  cmp dword ptr [r15+0x318], 0x00
00007dd8609d05e8  jz 0x00007DD8609CF0E0
00007dd8609d05ee  nop [rax+rax*1], ax
00007dd8609d05f7  nop [rax+rax*1], eax
00007dd8609d05ff  mov eax, 0x410768
00007dd8609d0604  mov [r15+0x100], rax
00007dd8609d060b  jmp 0x00007DD8607FE110
00007dd8609d0610  int3
00007dd8609d0611  call 0x00007DD8608E2BA0
00007dd8609d0616  jmp 0x00007DD8609D050F
00007dd8609d061b  call 0x00007DD8608E1920
00007dd8609d0620  jmp 0x00007DD8609D0518
00007dd8609d0625  call 0x00007DD86080DFE0
00007dd8609d062a  jmp 0x00007DD8609D058F
00007dd8609d062f  call 0x00007DD8608E2BA0
00007dd8609d0634  jmp 0x00007DD8609D059D
00007dd8609d0639  call 0x00007DD8608E2BA0
00007dd8609d063e  jmp 0x00007DD8609D05AB
00007dd8609d0643  call 0x00007DD8608E2BA0
00007dd8609d0648  jmp 0x00007DD8609D05B9
00007dd8609d064d  call 0x00007DD8608E2BA0
00007dd8609d0652  jmp 0x00007DD8609D05C7
00007dd8609d0657  call 0x00007DD8608E2BA0
00007dd8609d065c  jmp 0x00007DD8609D05D5
00007dd8609d0661  call 0x00007DD8608D5EB0
00007dd8609d0666  jmp 0x00007DD8609D05E0
00007dd8609d066b  int3
00007dd8609d066c  nop [rax], eax
00007dd8609d0670  mov rax, [r15+0xF8]
00007dd8609d0677  lea r14, [rax+0x140]
00007dd8609d067e  mov r12, [r13+r14*1]
00007dd8609d0683  lea r14, [rax+0x148]
00007dd8609d068a  mov r11, [r13+r14*1]
00007dd8609d068f  mov [r15+0xA0], r12
00007dd8609d0696  mov [r15+0x98], r11
00007dd8609d069d  lea r14, [rax+0x130]
00007dd8609d06a4  mov r12, [r13+r14*1]
00007dd8609d06a9  lea r14, [rax+0x138]
00007dd8609d06b0  mov r11, [r13+r14*1]
00007dd8609d06b5  mov [r15+0xB0], r12
00007dd8609d06bc  mov [r15+0xA8], r11
00007dd8609d06c3  lea r14, [rax+0x120]
00007dd8609d06ca  mov r12, [r13+r14*1]
00007dd8609d06cf  lea r14, [rax+0x128]
00007dd8609d06d6  mov r11, [r13+r14*1]
00007dd8609d06db  mov [r15+0xC0], r12
00007dd8609d06e2  mov [r15+0xB8], r11
00007dd8609d06e9  lea r14, [rax+0x110]
00007dd8609d06f0  mov r12, [r13+r14*1]
00007dd8609d06f5  lea r14, [rax+0x118]
00007dd8609d06fc  mov r11, [r13+r14*1]
00007dd8609d0701  mov [r15+0xD0], r12
00007dd8609d0708  mov [r15+0xC8], r11
00007dd8609d070f  lea r14, [rax+0x100]
00007dd8609d0716  mov r12, [r13+r14*1]
00007dd8609d071b  lea r14, [rax+0x108]
00007dd8609d0722  mov r11, [r13+r14*1]
00007dd8609d0727  mov [r15+0xE8], r12
00007dd8609d072e  mov [r15+0xD8], r11
00007dd8609d0735  lea r14, [rax+0x150]
00007dd8609d073c  mov [r15+0xF8], r14
00007dd8609d0743  mov rax, [r15+0xF0]
00007dd8609d074a  mov [r15+0x100], rax
00007dd8609d0751  jmp 0x00007DD8609CE5C0
00007dd8609d0756  int3
00007dd8609d0757  call 0x00007DD8608E27E0
00007dd8609d075c  jmp 0x00007DD8609D0683
00007dd8609d0761  call 0x00007DD8608E1570
00007dd8609d0766  jmp 0x00007DD8609D068F
00007dd8609d076b  call 0x00007DD8608E27E0
00007dd8609d0770  jmp 0x00007DD8609D06A9
00007dd8609d0775  call 0x00007DD8608E1570
00007dd8609d077a  jmp 0x00007DD8609D06B5
00007dd8609d077f  call 0x00007DD8608E27E0
00007dd8609d0784  jmp 0x00007DD8609D06CF
00007dd8609d0789  call 0x00007DD8608E1570
00007dd8609d078e  jmp 0x00007DD8609D06DB
00007dd8609d0793  call 0x00007DD8608E27E0
00007dd8609d0798  jmp 0x00007DD8609D06F5
00007dd8609d079d  call 0x00007DD8608E1570
00007dd8609d07a2  jmp 0x00007DD8609D0701
00007dd8609d07a7  call 0x00007DD8608E27E0
00007dd8609d07ac  jmp 0x00007DD8609D071B
00007dd8609d07b1  call 0x00007DD8608E1570
00007dd8609d07b6  jmp 0x00007DD8609D0727
00007dd8609d07bb  int3
00007dd8609d07bc  nop [rax], eax
00007dd8609d07c0  mov eax, [r15+0xA0]
00007dd8609d07c7  mov [rsp+0x10], eax
00007dd8609d07cb  xor eax, eax
00007dd8609d07cd  mov r14d, [rsp+0x10]
00007dd8609d07d2  sub r14d, 0x01
00007dd8609d07d6  cmc
00007dd8609d07d7  lahf
00007dd8609d07d8  seto al
00007dd8609d07db  mov [r15+0x108], eax
00007dd8609d07e2  mov r14d, r14d
00007dd8609d07e5  mov [r15+0xA0], r14
00007dd8609d07ec  mov eax, [r15+0x108]
00007dd8609d07f3  sahf
00007dd8609d07f4  jnz 0x00007DD8609D0826
00007dd8609d07f6  cmp dword ptr [r15+0x318], 0x00
00007dd8609d07fe  jz 0x00007DD8609D0900
00007dd8609d0804  nop [rax+rax*1], ax
00007dd8609d080d  nop [rax+rax*1], eax
00007dd8609d0815  mov eax, 0x41028C
00007dd8609d081a  mov [r15+0x100], rax
00007dd8609d0821  jmp 0x00007DD8607FE110
00007dd8609d0826  cmp dword ptr [r15+0x318], 0x00
00007dd8609d082e  jz 0x00007DD8609D0860
00007dd8609d0834  nop [rax+rax*1], ax
00007dd8609d083d  nop [rax+rax*1], eax
00007dd8609d0845  mov eax, 0x410274
00007dd8609d084a  mov [r15+0x100], rax
00007dd8609d0851  jmp 0x00007DD8607FE110
00007dd8609d0856  int3
00007dd8609d0857  int3
00007dd8609d0858  nop [rax+rax*1], eax
00007dd8609d0860  mov rax, [r15+0xF8]
00007dd8609d0867  lea r14, [rax+0x100]
00007dd8609d086e  mov [r15], r14
00007dd8609d0871  mov rax, [r15+0x98]
00007dd8609d0878  mov [r15+0x08], rax
00007dd8609d087c  mov qword ptr [r15+0x10], 0x12C
00007dd8609d0884  mov qword ptr [r15+0xF0], 0x410284
00007dd8609d088f  mov r14d, [r15+0x320]
00007dd8609d0896  mov eax, 0x410284
00007dd8609d089b  mov rcx, 0x7DD8609D07C0
00007dd8609d08a5  mov [r15+r14*8+0x328], rax
00007dd8609d08ad  mov [r15+r14*8+0x368], rcx
00007dd8609d08b5  add r14d, 0x01
00007dd8609d08b9  and r14d, 0x07
00007dd8609d08bd  mov [r15+0x320], r14d
00007dd8609d08c4  cmp dword ptr [r15+0x318], 0x00
00007dd8609d08cc  jz 0x00007DD8609CED70
00007dd8609d08d2  nop [rax+rax*1], ax
00007dd8609d08db  nop [rax+rax*1], eax
00007dd8609d08e3  mov eax, 0x410728
00007dd8609d08e8  mov [r15+0x100], rax
00007dd8609d08ef  jmp 0x00007DD8607FE110
00007dd8609d08f4  int3
00007dd8609d08f5  int3
00007dd8609d08f6  nop [rax+rax*1], ax
00007dd8609d08ff  nop
00007dd8609d0900  mov rax, [r15+0xF8]
00007dd8609d0907  lea r14, [rax+0x120]
00007dd8609d090e  mov r12, [r13+r14*1]
00007dd8609d0913  mov [r15+0x98], r12
00007dd8609d091a  mov qword ptr [r15+0x40], 0x80
00007dd8609d0922  lea r14, [rax+0x100]
00007dd8609d0929  mov [r15], r14
00007dd8609d092c  lea r14, [rax+0x17C]
00007dd8609d0933  mov [r15+0x08], r14
00007dd8609d0937  mov qword ptr [r15+0x10], 0x01
00007dd8609d093f  lea r14, [rax+0x17C]
00007dd8609d0946  mov eax, 0x80
00007dd8609d094b  mov [r13+r14*1], al
00007dd8609d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007dd8609d095b  mov r14d, [r15+0x320]
00007dd8609d0962  mov eax, 0x4102A8
00007dd8609d0967  mov rcx, 0x7DD8609D09E0
00007dd8609d0971  mov [r15+r14*8+0x328], rax
00007dd8609d0979  mov [r15+r14*8+0x368], rcx
00007dd8609d0981  add r14d, 0x01
00007dd8609d0985  and r14d, 0x07
00007dd8609d0989  mov [r15+0x320], r14d
00007dd8609d0990  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0998  jz 0x00007DD8609CED70
00007dd8609d099e  nop [rax+rax*1], ax
00007dd8609d09a7  nop [rax+rax*1], eax
00007dd8609d09af  mov eax, 0x410728
00007dd8609d09b4  mov [r15+0x100], rax
00007dd8609d09bb  jmp 0x00007DD8607FE110
00007dd8609d09c0  int3
00007dd8609d09c1  call 0x00007DD8608E27E0
00007dd8609d09c6  jmp 0x00007DD8609D0913
00007dd8609d09cb  call 0x00007DD8608D5AF0
00007dd8609d09d0  jmp 0x00007DD8609D0950
00007dd8609d09d5  int3
00007dd8609d09d6  nop [rax+rax*1], ax
00007dd8609d09df  nop
00007dd8609d09e0  mov rax, [r15+0xF8]
00007dd8609d09e7  lea r14, [rax+0x168]
00007dd8609d09ee  mov r12, [r13+r14*1]
00007dd8609d09f3  mov [r15+0x40], r12
00007dd8609d09f7  lea r14, [rax+0x178]
00007dd8609d09fe  xor eax, eax
00007dd8609d0a00  mov [r13+r14*1], al
00007dd8609d0a05  xor eax, eax
00007dd8609d0a07  mov r14d, 0x38
00007dd8609d0a0d  cmp r12, r14
00007dd8609d0a10  cmc
00007dd8609d0a11  lahf
00007dd8609d0a12  seto al
00007dd8609d0a15  mov [r15+0x108], eax
00007dd8609d0a1c  mov eax, [r15+0x108]
00007dd8609d0a23  sahf
00007dd8609d0a24  jz 0x00007DD8609D0A56
00007dd8609d0a26  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0a2e  jz 0x00007DD8609D0AA0
00007dd8609d0a34  nop [rax+rax*1], ax
00007dd8609d0a3d  nop [rax+rax*1], eax
00007dd8609d0a45  mov eax, 0x4102B8
00007dd8609d0a4a  mov [r15+0x100], rax
00007dd8609d0a51  jmp 0x00007DD8607FE110
00007dd8609d0a56  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0a5e  jz 0x00007DD8609D0BF0
00007dd8609d0a64  nop [rax+rax*1], ax
00007dd8609d0a6d  nop [rax+rax*1], eax
00007dd8609d0a75  mov eax, 0x4102D4
00007dd8609d0a7a  mov [r15+0x100], rax
00007dd8609d0a81  jmp 0x00007DD8607FE110
00007dd8609d0a86  int3
00007dd8609d0a87  call 0x00007DD8608E27E0
00007dd8609d0a8c  jmp 0x00007DD8609D09F3
00007dd8609d0a91  call 0x00007DD8608D5AF0
00007dd8609d0a96  jmp 0x00007DD8609D0A05
00007dd8609d0a9b  int3
00007dd8609d0a9c  nop [rax], eax
00007dd8609d0aa0  mov rax, [r15+0xF8]
00007dd8609d0aa7  lea r14, [rax+0x100]
00007dd8609d0aae  mov [r15], r14
00007dd8609d0ab1  lea r14, [rax+0x178]
00007dd8609d0ab8  mov [r15+0x08], r14
00007dd8609d0abc  mov qword ptr [r15+0x10], 0x01
00007dd8609d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007dd8609d0acf  mov r14d, [r15+0x320]
00007dd8609d0ad6  mov eax, 0x4102C8
00007dd8609d0adb  mov rcx, 0x7DD8609D0B40
00007dd8609d0ae5  mov [r15+r14*8+0x328], rax
00007dd8609d0aed  mov [r15+r14*8+0x368], rcx
00007dd8609d0af5  add r14d, 0x01
00007dd8609d0af9  and r14d, 0x07
00007dd8609d0afd  mov [r15+0x320], r14d
00007dd8609d0b04  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0b0c  jz 0x00007DD8609CED70
00007dd8609d0b12  nop [rax+rax*1], ax
00007dd8609d0b1b  nop [rax+rax*1], eax
00007dd8609d0b23  mov eax, 0x410728
00007dd8609d0b28  mov [r15+0x100], rax
00007dd8609d0b2f  jmp 0x00007DD8607FE110
00007dd8609d0b34  int3
00007dd8609d0b35  int3
00007dd8609d0b36  nop [rax+rax*1], ax
00007dd8609d0b3f  nop
00007dd8609d0b40  mov rax, [r15+0xF8]
00007dd8609d0b47  lea r14, [rax+0x168]
00007dd8609d0b4e  mov rax, [r13+r14*1]
00007dd8609d0b53  mov [r15+0x40], rax
00007dd8609d0b57  mov [rsp+0x10], rax
00007dd8609d0b5c  xor eax, eax
00007dd8609d0b5e  mov r14, [rsp+0x10]
00007dd8609d0b63  mov r12d, 0x38
00007dd8609d0b69  cmp r14, r12
00007dd8609d0b6c  cmc
00007dd8609d0b6d  lahf
00007dd8609d0b6e  seto al
00007dd8609d0b71  mov [r15+0x108], eax
00007dd8609d0b78  mov eax, [r15+0x108]
00007dd8609d0b7f  sahf
00007dd8609d0b80  jnz 0x00007DD8609D0BB2
00007dd8609d0b82  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0b8a  jz 0x00007DD8609D0BF0
00007dd8609d0b90  nop [rax+rax*1], ax
00007dd8609d0b99  nop [rax+rax*1], eax
00007dd8609d0ba1  mov eax, 0x4102D4
00007dd8609d0ba6  mov [r15+0x100], rax
00007dd8609d0bad  jmp 0x00007DD8607FE110
00007dd8609d0bb2  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0bba  jz 0x00007DD8609D0AA0
00007dd8609d0bc0  nop [rax+rax*1], ax
00007dd8609d0bc9  nop [rax+rax*1], eax
00007dd8609d0bd1  mov eax, 0x4102B8
00007dd8609d0bd6  mov [r15+0x100], rax
00007dd8609d0bdd  jmp 0x00007DD8607FE110
00007dd8609d0be2  int3
00007dd8609d0be3  call 0x00007DD8608D59C0
00007dd8609d0be8  jmp 0x00007DD8609D0B53
00007dd8609d0bed  int3
00007dd8609d0bee  nop
00007dd8609d0bf0  mov rax, [r15+0x98]
00007dd8609d0bf7  rorx r14, rax, 0x3D
00007dd8609d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007dd8609d0c01  mov rax, [r15+0xF8]
00007dd8609d0c08  lea r12, [rax+0x100]
00007dd8609d0c0f  mov [r15], r12
00007dd8609d0c12  lea r12, [rax+0x170]
00007dd8609d0c19  mov [r15+0x08], r12
00007dd8609d0c1d  mov qword ptr [r15+0x10], 0x08
00007dd8609d0c25  bswap r14
00007dd8609d0c28  mov [r15+0x40], r14
00007dd8609d0c2c  lea r12, [rax+0x170]
00007dd8609d0c33  mov [r13+r12*1], r14
00007dd8609d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007dd8609d0c43  mov r14d, [r15+0x320]
00007dd8609d0c4a  mov eax, 0x4102F0
00007dd8609d0c4f  mov rcx, 0x7DD8609D0CC0
00007dd8609d0c59  mov [r15+r14*8+0x328], rax
00007dd8609d0c61  mov [r15+r14*8+0x368], rcx
00007dd8609d0c69  add r14d, 0x01
00007dd8609d0c6d  and r14d, 0x07
00007dd8609d0c71  mov [r15+0x320], r14d
00007dd8609d0c78  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0c80  jz 0x00007DD8609CED70
00007dd8609d0c86  nop [rax+rax*1], ax
00007dd8609d0c8f  nop [rax+rax*1], eax
00007dd8609d0c97  mov eax, 0x410728
00007dd8609d0c9c  mov [r15+0x100], rax
00007dd8609d0ca3  jmp 0x00007DD8607FE110
00007dd8609d0ca8  int3
00007dd8609d0ca9  call 0x00007DD8608C3FE0
00007dd8609d0cae  jmp 0x00007DD8609D0C38
00007dd8609d0cb3  int3
00007dd8609d0cb4  nop [rax+rax*1], ax
00007dd8609d0cbd  nop [rax], eax
00007dd8609d0cc0  mov rax, [r15+0xF8]
00007dd8609d0cc7  lea r14, [rax+0x100]
00007dd8609d0cce  mov r12d, [r13+r14*1]
00007dd8609d0cd3  lea r14, [rax+0x104]
00007dd8609d0cda  mov r11d, [r13+r14*1]
00007dd8609d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007dd8609d0ce7  lea r14, [rax+0x108]
00007dd8609d0cee  mov r10d, [r13+r14*1]
00007dd8609d0cf3  lea r14, [rax+0x10C]
00007dd8609d0cfa  mov r9d, [r13+r14*1]
00007dd8609d0cff  bswap r12d
00007dd8609d0d02  bswap r11d
00007dd8609d0d05  mov qword ptr [r15+0xA0], 0x00
00007dd8609d0d10  mov r14d, 0x430C90
00007dd8609d0d16  mov [r13+r14*1], r12d
00007dd8609d0d1b  mov r14d, 0x430C94
00007dd8609d0d21  mov [r13+r14*1], r11d
00007dd8609d0d26  bswap r10d
00007dd8609d0d29  lea r14, [rax+0x110]
00007dd8609d0d30  mov r12d, [r13+r14*1]
00007dd8609d0d35  bswap r9d
00007dd8609d0d38  lea r14, [rax+0x114]
00007dd8609d0d3f  mov r11d, [r13+r14*1]
00007dd8609d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007dd8609d0d4f  mov r14d, 0x430C98
00007dd8609d0d55  mov [r13+r14*1], r10d
00007dd8609d0d5a  mov r14d, 0x430C9C
00007dd8609d0d60  mov [r13+r14*1], r9d
00007dd8609d0d65  bswap r12d
00007dd8609d0d68  lea r14, [rax+0x118]
00007dd8609d0d6f  mov r10d, [r13+r14*1]
00007dd8609d0d74  bswap r11d
00007dd8609d0d77  mov [rsp+0x10], r11d
00007dd8609d0d7c  mov r11d, r11d
00007dd8609d0d7f  mov [r15+0x58], r11
00007dd8609d0d83  lea r14, [rax+0x11C]
00007dd8609d0d8a  mov eax, [r13+r14*1]
00007dd8609d0d8f  mov [rsp+0x20], eax
00007dd8609d0d93  mov eax, eax
00007dd8609d0d95  mov [r15+0x60], rax
00007dd8609d0d99  mov eax, 0x430CA0
00007dd8609d0d9e  mov [r13+rax*1], r12d
00007dd8609d0da3  mov eax, 0x430CA4
00007dd8609d0da8  mov r14d, [rsp+0x10]
00007dd8609d0dad  mov [r13+rax*1], r14d
00007dd8609d0db2  bswap r10d
00007dd8609d0db5  mov [rsp+0x10], r10d
00007dd8609d0dba  mov r10d, r10d
00007dd8609d0dbd  mov [r15+0x40], r10
00007dd8609d0dc1  mov eax, [rsp+0x20]
00007dd8609d0dc5  bswap eax
00007dd8609d0dc7  mov [rsp+0x20], eax
00007dd8609d0dcb  mov eax, eax
00007dd8609d0dcd  mov [r15+0x50], rax
00007dd8609d0dd1  mov eax, 0x430CA8
00007dd8609d0dd6  mov r14d, [rsp+0x10]
00007dd8609d0ddb  mov [r13+rax*1], r14d
00007dd8609d0de0  mov eax, 0x430CAC
00007dd8609d0de5  mov r14d, [rsp+0x20]
00007dd8609d0dea  mov [r13+rax*1], r14d
00007dd8609d0def  mov eax, [r15+0xA0]
00007dd8609d0df6  lea r14d, [eax+0x11]
00007dd8609d0dfb  mov r14d, r14d
00007dd8609d0dfe  mov [r15], r14
00007dd8609d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007dd8609d0e0c  mov r14d, [r15+0x320]
00007dd8609d0e13  mov eax, 0x41035C
00007dd8609d0e18  mov rcx, 0x7DD8609D0F90
00007dd8609d0e22  mov [r15+r14*8+0x328], rax
00007dd8609d0e2a  mov [r15+r14*8+0x368], rcx
00007dd8609d0e32  add r14d, 0x01
00007dd8609d0e36  and r14d, 0x07
00007dd8609d0e3a  mov [r15+0x320], r14d
00007dd8609d0e41  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0e49  jz 0x00007DD8609D0F20
00007dd8609d0e4f  nop [rax+rax*1], ax
00007dd8609d0e58  nop [rax+rax*1], eax
00007dd8609d0e60  mov eax, 0x4109A4
00007dd8609d0e65  mov [r15+0x100], rax
00007dd8609d0e6c  jmp 0x00007DD8607FE110
00007dd8609d0e71  int3
00007dd8609d0e72  call 0x00007DD8608E26A0
00007dd8609d0e77  jmp 0x00007DD8609D0CD3
00007dd8609d0e7c  call 0x00007DD8608E1430
00007dd8609d0e81  jmp 0x00007DD8609D0CDF
00007dd8609d0e86  call 0x00007DD8608E01C0
00007dd8609d0e8b  jmp 0x00007DD8609D0CF3
00007dd8609d0e90  call 0x00007DD8608DEF50
00007dd8609d0e95  jmp 0x00007DD8609D0CFF
00007dd8609d0e9a  call 0x00007DD8608E2BA0
00007dd8609d0e9f  jmp 0x00007DD8609D0D1B
00007dd8609d0ea4  call 0x00007DD8608E1920
00007dd8609d0ea9  jmp 0x00007DD8609D0D26
00007dd8609d0eae  call 0x00007DD8608E26A0
00007dd8609d0eb3  jmp 0x00007DD8609D0D35
00007dd8609d0eb8  call 0x00007DD8608E1430
00007dd8609d0ebd  jmp 0x00007DD8609D0D44
00007dd8609d0ec2  call 0x00007DD8608E06B0
00007dd8609d0ec7  jmp 0x00007DD8609D0D5A
00007dd8609d0ecc  call 0x00007DD8608DF440
00007dd8609d0ed1  jmp 0x00007DD8609D0D65
00007dd8609d0ed6  call 0x00007DD8608E01C0
00007dd8609d0edb  jmp 0x00007DD8609D0D74
00007dd8609d0ee0  call 0x00007DD8608D5890
00007dd8609d0ee5  jmp 0x00007DD8609D0D8F
00007dd8609d0eea  call 0x00007DD86080BAE0
00007dd8609d0eef  jmp 0x00007DD8609D0DA3
00007dd8609d0ef4  call 0x00007DD86080DFE0
00007dd8609d0ef9  jmp 0x00007DD8609D0DB2
00007dd8609d0efe  call 0x00007DD86080DFE0
00007dd8609d0f03  jmp 0x00007DD8609D0DE0
00007dd8609d0f08  call 0x00007DD86080DFE0
00007dd8609d0f0d  jmp 0x00007DD8609D0DEF
00007dd8609d0f12  int3
00007dd8609d0f13  nop [rax+rax*1], ax
00007dd8609d0f1c  nop [rax], eax
00007dd8609d0f20  mov eax, [r15]
00007dd8609d0f23  mov [rsp+0x10], eax
00007dd8609d0f27  shr eax, 0x10
00007dd8609d0f2a  mov r14d, [rsp+0x10]
00007dd8609d0f2f  xor r14d, eax
00007dd8609d0f32  imul r14d, r14d, 0x7FEB352D
00007dd8609d0f39  mov eax, 0x846CA68B
00007dd8609d0f3e  mov eax, eax
00007dd8609d0f40  mov [r15+0x48], rax
00007dd8609d0f44  mov [rsp+0x10], r14d
00007dd8609d0f49  shr r14d, 0x0F
00007dd8609d0f4d  mov eax, [rsp+0x10]
00007dd8609d0f51  xor eax, r14d
00007dd8609d0f54  imul eax, eax, 0x846CA68B
00007dd8609d0f5a  mov [rsp+0x10], eax
00007dd8609d0f5e  mov eax, eax
00007dd8609d0f60  mov [r15+0x40], rax
00007dd8609d0f64  mov eax, [rsp+0x10]
00007dd8609d0f68  shr eax, 0x10
00007dd8609d0f6b  mov r14d, [rsp+0x10]
00007dd8609d0f70  xor r14d, eax
00007dd8609d0f73  mov r14d, r14d
00007dd8609d0f76  mov [r15], r14
00007dd8609d0f79  mov rax, [r15+0xF0]
00007dd8609d0f80  mov [r15+0x100], rax
00007dd8609d0f87  jmp 0x00007DD8609CE5C0
00007dd8609d0f8c  int3
00007dd8609d0f8d  int3
00007dd8609d0f8e  nop
00007dd8609d0f90  mov rax, [r15+0xA0]
00007dd8609d0f97  mov [rsp+0x10], rax
00007dd8609d0f9c  shl rax, 0x02
00007dd8609d0fa0  mov r14, [r15+0x98]
00007dd8609d0fa7  lea r12, [r14+rax*1]
00007dd8609d0fab  mov eax, [r15]
00007dd8609d0fae  mov [r13+r12*1], eax
00007dd8609d0fb3  mov rax, [rsp+0x10]
00007dd8609d0fb8  lea r14, [rax+0x01]
00007dd8609d0fbc  mov [r15+0xA0], r14
00007dd8609d0fc3  xor eax, eax
00007dd8609d0fc5  mov r12d, 0x400
00007dd8609d0fcb  cmp r14, r12
00007dd8609d0fce  cmc
00007dd8609d0fcf  lahf
00007dd8609d0fd0  seto al
00007dd8609d0fd3  mov [r15+0x108], eax
00007dd8609d0fda  mov eax, [r15+0x108]
00007dd8609d0fe1  sahf
00007dd8609d0fe2  jnz 0x00007DD8609D1014
00007dd8609d0fe4  cmp dword ptr [r15+0x318], 0x00
00007dd8609d0fec  jz 0x00007DD8609D10E0
00007dd8609d0ff2  nop [rax+rax*1], ax
00007dd8609d0ffb  nop [rax+rax*1], eax
00007dd8609d1003  mov eax, 0x41036C
00007dd8609d1008  mov [r15+0x100], rax
00007dd8609d100f  jmp 0x00007DD8607FE110
00007dd8609d1014  cmp dword ptr [r15+0x318], 0x00
00007dd8609d101c  jz 0x00007DD8609D1050
00007dd8609d1022  nop [rax+rax*1], ax
00007dd8609d102b  nop [rax+rax*1], eax
00007dd8609d1033  mov eax, 0x410354
00007dd8609d1038  mov [r15+0x100], rax
00007dd8609d103f  jmp 0x00007DD8607FE110
00007dd8609d1044  int3
00007dd8609d1045  call 0x00007DD8608B4B70
00007dd8609d104a  jmp 0x00007DD8609D0FB3
00007dd8609d104f  int3
00007dd8609d1050  mov eax, [r15+0xA0]
00007dd8609d1057  lea r14d, [eax+0x11]
00007dd8609d105c  mov r14d, r14d
00007dd8609d105f  mov [r15], r14
00007dd8609d1062  mov qword ptr [r15+0xF0], 0x41035C
00007dd8609d106d  mov r14d, [r15+0x320]
00007dd8609d1074  mov eax, 0x41035C
00007dd8609d1079  mov rcx, 0x7DD8609D0F90
00007dd8609d1083  mov [r15+r14*8+0x328], rax
00007dd8609d108b  mov [r15+r14*8+0x368], rcx
00007dd8609d1093  add r14d, 0x01
00007dd8609d1097  and r14d, 0x07
00007dd8609d109b  mov [r15+0x320], r14d
00007dd8609d10a2  cmp dword ptr [r15+0x318], 0x00
00007dd8609d10aa  jz 0x00007DD8609D0F20
00007dd8609d10b0  nop [rax+rax*1], ax
00007dd8609d10b9  nop [rax+rax*1], eax
00007dd8609d10c1  mov eax, 0x4109A4
00007dd8609d10c6  mov [r15+0x100], rax
00007dd8609d10cd  jmp 0x00007DD8607FE110
00007dd8609d10d2  int3
00007dd8609d10d3  int3
00007dd8609d10d4  nop [rax+rax*1], ax
00007dd8609d10dd  nop [rax], eax
00007dd8609d10e0  mov qword ptr [r15+0x40], 0x01
00007dd8609d10e8  cmp dword ptr [r15+0x318], 0x00
00007dd8609d10f0  jz 0x00007DD8609D1120
00007dd8609d10f6  nop [rax+rax*1], ax
00007dd8609d10ff  nop [rax+rax*1], eax
00007dd8609d1107  mov eax, 0x410388
00007dd8609d110c  mov [r15+0x100], rax
00007dd8609d1113  jmp 0x00007DD8607FE110
00007dd8609d1118  int3
00007dd8609d1119  int3
00007dd8609d111a  nop [rax+rax*1], ax
00007dd8609d1120  mov rax, [r15+0x40]
00007dd8609d1124  mov [rsp+0x10], rax
00007dd8609d1129  shl rax, 0x02
00007dd8609d112d  mov r14, [r15+0x98]
00007dd8609d1134  lea r12, [r14+rax*1]
00007dd8609d1138  mov eax, [r13+r12*1]
00007dd8609d113d  mov [rsp+0x20], eax
00007dd8609d1141  mov eax, eax
00007dd8609d1143  mov [r15+0x48], rax
00007dd8609d1147  mov rax, [rsp+0x10]
00007dd8609d114c  mov [r15+0x50], rax
00007dd8609d1150  mov eax, [r15+0x50]
00007dd8609d1154  lea r12d, [eax-0x01]
00007dd8609d1159  mov r12d, r12d
00007dd8609d115c  mov [r15+0x58], r12
00007dd8609d1160  mov rax, [r15+0x58]
00007dd8609d1164  mov r12d, eax
00007dd8609d1167  mov r12d, r12d
00007dd8609d116a  shl r12, 0x02
00007dd8609d116e  lea rax, [r14+r12*1]
00007dd8609d1172  mov r14d, [r13+rax*1]
00007dd8609d1177  mov [rsp+0x10], r14d
00007dd8609d117c  mov r14d, r14d
00007dd8609d117f  mov [r15+0x60], r14
00007dd8609d1183  xor eax, eax
00007dd8609d1185  mov r14d, [rsp+0x10]
00007dd8609d118a  mov r12d, [rsp+0x20]
00007dd8609d118f  cmp r14d, r12d
00007dd8609d1192  cmc
00007dd8609d1193  lahf
00007dd8609d1194  seto al
00007dd8609d1197  mov [r15+0x108], eax
00007dd8609d119e  mov eax, [r15+0x108]
00007dd8609d11a5  sahf
00007dd8609d11a6  cmc
00007dd8609d11a7  jbe 0x00007DD8609D11D9
00007dd8609d11a9  cmp dword ptr [r15+0x318], 0x00
00007dd8609d11b1  jz 0x00007DD8609D1220
00007dd8609d11b7  nop [rax+rax*1], ax
00007dd8609d11c0  nop [rax+rax*1], eax
00007dd8609d11c8  mov eax, 0x4103A0
00007dd8609d11cd  mov [r15+0x100], rax
00007dd8609d11d4  jmp 0x00007DD8607FE110
00007dd8609d11d9  cmp dword ptr [r15+0x318], 0x00
00007dd8609d11e1  jz 0x00007DD8609D14C0
00007dd8609d11e7  nop [rax+rax*1], ax
00007dd8609d11f0  nop [rax+rax*1], eax
00007dd8609d11f8  mov eax, 0x410378
00007dd8609d11fd  mov [r15+0x100], rax
00007dd8609d1204  jmp 0x00007DD8607FE110
00007dd8609d1209  int3
00007dd8609d120a  call 0x00007DD8608B4690
00007dd8609d120f  jmp 0x00007DD8609D113D
00007dd8609d1214  call 0x00007DD86080DAE0
00007dd8609d1219  jmp 0x00007DD8609D1177
00007dd8609d121e  int3
00007dd8609d121f  nop
00007dd8609d1220  mov rax, [r15+0x50]
00007dd8609d1224  mov [rsp+0x10], rax
00007dd8609d1229  shl rax, 0x02
00007dd8609d122d  mov r14, [r15+0x98]
00007dd8609d1234  lea r12, [r14+rax*1]
00007dd8609d1238  mov eax, [r15+0x60]
00007dd8609d123c  mov [r13+r12*1], eax
00007dd8609d1241  mov rax, [rsp+0x10]
00007dd8609d1246  lea r14, [rax-0x01]
00007dd8609d124a  mov [r15+0x50], r14
00007dd8609d124e  mov rax, [r15+0x58]
00007dd8609d1252  test rax, rax
00007dd8609d1255  setz al
00007dd8609d1258  movzx rax, al
00007dd8609d125c  mov [rsp+0x414], al
00007dd8609d1263  cmp byte ptr [rsp+0x414], 0x00
00007dd8609d126b  jz 0x00007DD8609D129D
00007dd8609d126d  cmp dword ptr [r15+0x318], 0x00
00007dd8609d1275  jz 0x00007DD8609D12E0
00007dd8609d127b  nop [rax+rax*1], ax
00007dd8609d1284  nop [rax+rax*1], eax
00007dd8609d128c  mov eax, 0x4103AC
00007dd8609d1291  mov [r15+0x100], rax
00007dd8609d1298  jmp 0x00007DD8607FE110
00007dd8609d129d  cmp dword ptr [r15+0x318], 0x00
00007dd8609d12a5  jz 0x00007DD8609D13E0
00007dd8609d12ab  nop [rax+rax*1], ax
00007dd8609d12b4  nop [rax+rax*1], eax
00007dd8609d12bc  mov eax, 0x410390
00007dd8609d12c1  mov [r15+0x100], rax
00007dd8609d12c8  jmp 0x00007DD8607FE110
00007dd8609d12cd  int3
00007dd8609d12ce  call 0x00007DD8608B4B70
00007dd8609d12d3  jmp 0x00007DD8609D1241
00007dd8609d12d8  int3
00007dd8609d12d9  nop [rax], eax
00007dd8609d12e0  cmp dword ptr [r15+0x318], 0x00
00007dd8609d12e8  jz 0x00007DD8609D1320
00007dd8609d12ee  nop [rax+rax*1], ax
00007dd8609d12f7  nop [rax+rax*1], eax
00007dd8609d12ff  mov eax, 0x410374
00007dd8609d1304  mov [r15+0x100], rax
00007dd8609d130b  jmp 0x00007DD8607FE110
00007dd8609d1310  int3
00007dd8609d1311  int3
00007dd8609d1312  nop [rax+rax*1], ax
00007dd8609d131b  nop [rax+rax*1], eax
00007dd8609d1320  mov qword ptr [r15+0x50], 0x00
00007dd8609d1328  mov rax, [r15+0x40]
00007dd8609d132c  lea r14, [rax+0x01]
00007dd8609d1330  mov [r15+0x40], r14
00007dd8609d1334  mov rax, [r15+0x98]
00007dd8609d133b  mov r12d, [r15+0x48]
00007dd8609d133f  mov [r13+rax*1], r12d
00007dd8609d1344  xor eax, eax
00007dd8609d1346  mov r12d, 0x400
00007dd8609d134c  cmp r14, r12
00007dd8609d134f  cmc
00007dd8609d1350  lahf
00007dd8609d1351  seto al
00007dd8609d1354  mov [r15+0x108], eax
00007dd8609d135b  mov eax, [r15+0x108]
00007dd8609d1362  sahf
00007dd8609d1363  jz 0x00007DD8609D1395
00007dd8609d1365  cmp dword ptr [r15+0x318], 0x00
00007dd8609d136d  jz 0x00007DD8609D1120
00007dd8609d1373  nop [rax+rax*1], ax
00007dd8609d137c  nop [rax+rax*1], eax
00007dd8609d1384  mov eax, 0x410388
00007dd8609d1389  mov [r15+0x100], rax
00007dd8609d1390  jmp 0x00007DD8607FE110
00007dd8609d1395  cmp dword ptr [r15+0x318], 0x00
00007dd8609d139d  jz 0x00007DD8609D1580
00007dd8609d13a3  nop [rax+rax*1], ax
00007dd8609d13ac  nop [rax+rax*1], eax
00007dd8609d13b4  mov eax, 0x4103B0
00007dd8609d13b9  mov [r15+0x100], rax
00007dd8609d13c0  jmp 0x00007DD8607FE110
00007dd8609d13c5  int3
00007dd8609d13c6  call 0x00007DD86080BAE0
00007dd8609d13cb  jmp 0x00007DD8609D1344
00007dd8609d13d0  int3
00007dd8609d13d1  nop [rax+rax*1], ax
00007dd8609d13da  nop [rax+rax*1], ax
00007dd8609d13e0  mov eax, [r15+0x50]
00007dd8609d13e4  lea r14d, [eax-0x01]
00007dd8609d13e9  mov r14d, r14d
00007dd8609d13ec  mov [r15+0x58], r14
00007dd8609d13f0  mov rax, [r15+0x58]
00007dd8609d13f4  mov r14d, eax
00007dd8609d13f7  mov r14d, r14d
00007dd8609d13fa  shl r14, 0x02
00007dd8609d13fe  mov rax, [r15+0x98]
00007dd8609d1405  lea r12, [rax+r14*1]
00007dd8609d1409  mov eax, [r13+r12*1]
00007dd8609d140e  mov [rsp+0x10], eax
00007dd8609d1412  mov eax, eax
00007dd8609d1414  mov [r15+0x60], rax
00007dd8609d1418  mov eax, [r15+0x48]
00007dd8609d141c  mov [rsp+0x20], eax
00007dd8609d1420  xor eax, eax
00007dd8609d1422  mov r14d, [rsp+0x10]
00007dd8609d1427  mov r12d, [rsp+0x20]
00007dd8609d142c  cmp r14d, r12d
00007dd8609d142f  cmc
00007dd8609d1430  lahf
00007dd8609d1431  seto al
00007dd8609d1434  mov [r15+0x108], eax
00007dd8609d143b  mov eax, [r15+0x108]
00007dd8609d1442  sahf
00007dd8609d1443  cmc
00007dd8609d1444  jbe 0x00007DD8609D1476
00007dd8609d1446  cmp dword ptr [r15+0x318], 0x00
00007dd8609d144e  jz 0x00007DD8609D1220
00007dd8609d1454  nop [rax+rax*1], ax
00007dd8609d145d  nop [rax+rax*1], eax
00007dd8609d1465  mov eax, 0x4103A0
00007dd8609d146a  mov [r15+0x100], rax
00007dd8609d1471  jmp 0x00007DD8607FE110
00007dd8609d1476  cmp dword ptr [r15+0x318], 0x00
00007dd8609d147e  jz 0x00007DD8609D14C0
00007dd8609d1484  nop [rax+rax*1], ax
00007dd8609d148d  nop [rax+rax*1], eax
00007dd8609d1495  mov eax, 0x410378
00007dd8609d149a  mov [r15+0x100], rax
00007dd8609d14a1  jmp 0x00007DD8607FE110
00007dd8609d14a6  int3
00007dd8609d14a7  call 0x00007DD8608B4690
00007dd8609d14ac  jmp 0x00007DD8609D140E
00007dd8609d14b1  int3
00007dd8609d14b2  nop [rax+rax*1], ax
00007dd8609d14bb  nop [rax+rax*1], eax
00007dd8609d14c0  mov rax, [r15+0x40]
00007dd8609d14c4  lea r14, [rax+0x01]
00007dd8609d14c8  mov [r15+0x40], r14
00007dd8609d14cc  mov rax, [r15+0x50]
00007dd8609d14d0  mov r12d, eax
00007dd8609d14d3  mov r12d, r12d
00007dd8609d14d6  shl r12, 0x02
00007dd8609d14da  mov rax, [r15+0x98]
00007dd8609d14e1  lea r11, [rax+r12*1]
00007dd8609d14e5  mov eax, [r15+0x48]
00007dd8609d14e9  mov [r13+r11*1], eax
00007dd8609d14ee  xor eax, eax
00007dd8609d14f0  mov r12d, 0x400
00007dd8609d14f6  cmp r14, r12
00007dd8609d14f9  cmc
00007dd8609d14fa  lahf
00007dd8609d14fb  seto al
00007dd8609d14fe  mov [r15+0x108], eax
00007dd8609d1505  mov eax, [r15+0x108]
00007dd8609d150c  sahf
00007dd8609d150d  jz 0x00007DD8609D153F
00007dd8609d150f  cmp dword ptr [r15+0x318], 0x00
00007dd8609d1517  jz 0x00007DD8609D1120
00007dd8609d151d  nop [rax+rax*1], ax
00007dd8609d1526  nop [rax+rax*1], eax
00007dd8609d152e  mov eax, 0x410388
00007dd8609d1533  mov [r15+0x100], rax
00007dd8609d153a  jmp 0x00007DD8607FE110
00007dd8609d153f  cmp dword ptr [r15+0x318], 0x00
00007dd8609d1547  jz 0x00007DD8609D1580
00007dd8609d154d  nop [rax+rax*1], ax
00007dd8609d1556  nop [rax+rax*1], eax
00007dd8609d155e  mov eax, 0x4103B0
00007dd8609d1563  mov [r15+0x100], rax
00007dd8609d156a  jmp 0x00007DD8607FE110
00007dd8609d156f  int3
00007dd8609d1570  call 0x00007DD8608A4270
00007dd8609d1575  jmp 0x00007DD8609D14EE
00007dd8609d157a  int3
00007dd8609d157b  nop [rax+rax*1], eax
00007dd8609d1580  mov qword ptr [r15+0x40], 0x430000
00007dd8609d1588  mov eax, 0x430CB0
00007dd8609d158d  mov r14, [r13+rax*1]
00007dd8609d1592  mov rax, [r15+0x98]
00007dd8609d1599  mov r12d, [r13+rax*1]
00007dd8609d159e  lea r11, [rax+0x04]
00007dd8609d15a2  mov eax, [r13+r11*1]
00007dd8609d15a7  mov r12d, r12d
00007dd8609d15aa  mov [r15+0x68], r12
00007dd8609d15ae  mov eax, eax
00007dd8609d15b0  mov [r15+0x60], rax
00007dd8609d15b4  mov rax, [r15+0x68]
00007dd8609d15b8  mov [r15+0x68], rax
00007dd8609d15bc  mov qword ptr [r15+0x58], 0x02
00007dd8609d15c4  mov [rsp+0x10], rax
00007dd8609d15c9  xor eax, eax
00007dd8609d15cb  mov r12d, 0x02
00007dd8609d15d1  mov r11d, 0x400
00007dd8609d15d7  cmp r12, r11
00007dd8609d15da  cmc
00007dd8609d15db  lahf
00007dd8609d15dc  seto al
00007dd8609d15df  mov [r15+0x108], eax
00007dd8609d15e6  mov rax, [r15+0x60]
00007dd8609d15ea  mov r12d, 0x02
00007dd8609d15f0  imul rax, r12
00007dd8609d15f4  mov [r15+0x50], rax
00007dd8609d15f8  mov rax, [rsp+0x10]
00007dd8609d15fd  lea r12, [rax+r14*1]
00007dd8609d1601  mov [r15+0x48], r12
00007dd8609d1605  mov eax, [r15+0x108]
00007dd8609d160c  sahf
00007dd8609d160d  jnz 0x00007DD8609D163F
00007dd8609d160f  cmp dword ptr [r15+0x318], 0x00
00007dd8609d1617  jz 0x00007DD8609D17B0
00007dd8609d161d  nop [rax+rax*1], ax
00007dd8609d1626  nop [rax+rax*1], eax
00007dd8609d162e  mov eax, 0x4103E0
00007dd8609d1633  mov [r15+0x100], rax
00007dd8609d163a  jmp 0x00007DD8607FE110
00007dd8609d163f  cmp dword ptr [r15+0x318], 0x00
00007dd8609d1647  jz 0x00007DD8609D1690
00007dd8609d164d  nop [rax+rax*1], ax
00007dd8609d1656  nop [rax+rax*1], eax
00007dd8609d165e  mov eax, 0x4103C0
00007dd8609d1663  mov [r15+0x100], rax
00007dd8609d166a  jmp 0x00007DD8607FE110
00007dd8609d166f  int3
00007dd8609d1670  call 0x00007DD86080DC20
00007dd8609d1675  jmp 0x00007DD8609D1592
00007dd8609d167a  call 0x00007DD86080B5E0
00007dd8609d167f  jmp 0x00007DD8609D159E
00007dd8609d1684  call 0x00007DD8608A3D90
00007dd8609d1689  jmp 0x00007DD8609D15A7
00007dd8609d168e  int3
00007dd8609d168f  nop
00007dd8609d1690  mov rax, [r15+0x98]
00007dd8609d1697  mov r14, [r15+0x58]
00007dd8609d169b  mov [rsp+0x10], r14
00007dd8609d16a0  shl r14, 0x02
00007dd8609d16a4  lea r12, [rax+r14*1]
00007dd8609d16a8  mov eax, [r13+r12*1]
00007dd8609d16ad  lea r14, [r12+0x04]
00007dd8609d16b2  mov r12d, [r13+r14*1]
00007dd8609d16b7  mov eax, eax
00007dd8609d16b9  mov [r15+0x68], rax
00007dd8609d16bd  mov r12d, r12d
00007dd8609d16c0  mov [r15+0x60], r12
00007dd8609d16c4  mov rax, [r15+0x68]
00007dd8609d16c8  mov [rsp+0x20], rax
00007dd8609d16cd  mov r14, [rsp+0x10]
00007dd8609d16d2  imul rax, r14
00007dd8609d16d6  mov r12, [rsp+0x20]
00007dd8609d16db  lea r11, [r12+rax*1]
00007dd8609d16df  mov [r15+0x68], r11
00007dd8609d16e3  lea rax, [r14+0x02]
00007dd8609d16e7  mov [r15+0x58], rax
00007dd8609d16eb  mov [rsp+0x10], rax
00007dd8609d16f0  xor eax, eax
00007dd8609d16f2  mov r14, [rsp+0x10]
00007dd8609d16f7  mov r12d, 0x400
00007dd8609d16fd  cmp r14, r12
00007dd8609d1700  cmc
00007dd8609d1701  lahf
00007dd8609d1702  seto al
00007dd8609d1705  mov [r15+0x108], eax
00007dd8609d170c  mov rax, [r15+0x50]
00007dd8609d1710  mov r12, [r15+0x60]
00007dd8609d1714  imul r14, r12
00007dd8609d1718  lea r12, [rax+r14*1]
00007dd8609d171c  mov [r15+0x50], r12
00007dd8609d1720  mov rax, [r15+0x48]
00007dd8609d1724  lea r14, [r11+rax*1]
00007dd8609d1728  mov [r15+0x48], r14
00007dd8609d172c  mov eax, [r15+0x108]
00007dd8609d1733  sahf
00007dd8609d1734  jnz 0x00007DD8609D1766
00007dd8609d1736  cmp dword ptr [r15+0x318], 0x00
00007dd8609d173e  jz 0x00007DD8609D17B0
00007dd8609d1744  nop [rax+rax*1], ax
00007dd8609d174d  nop [rax+rax*1], eax
00007dd8609d1755  mov eax, 0x4103E0
00007dd8609d175a  mov [r15+0x100], rax
00007dd8609d1761  jmp 0x00007DD8607FE110
00007dd8609d1766  cmp dword ptr [r15+0x318], 0x00
00007dd8609d176e  jz 0x00007DD8609D1690
00007dd8609d1774  nop [rax+rax*1], ax
00007dd8609d177d  nop [rax+rax*1], eax
00007dd8609d1785  mov eax, 0x4103C0
00007dd8609d178a  mov [r15+0x100], rax
00007dd8609d1791  jmp 0x00007DD8607FE110
00007dd8609d1796  int3
00007dd8609d1797  call 0x00007DD8608B4690
00007dd8609d179c  jmp 0x00007DD8609D16AD
00007dd8609d17a1  call 0x00007DD8608E26A0
00007dd8609d17a6  jmp 0x00007DD8609D16B7
00007dd8609d17ab  int3
00007dd8609d17ac  nop [rax], eax
00007dd8609d17b0  mov qword ptr [r15+0x98], 0x00
00007dd8609d17bb  mov rax, [r15+0x50]
00007dd8609d17bf  mov r14, [r15+0x48]
00007dd8609d17c3  lea r12, [rax+r14*1]
00007dd8609d17c7  mov [r15+0x48], r12
00007dd8609d17cb  mov rax, [r15+0x40]
00007dd8609d17cf  lea r14, [rax+0xCB0]
00007dd8609d17d6  mov [r13+r14*1], r12
00007dd8609d17db  mov qword ptr [r15], 0x01
00007dd8609d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007dd8609d17ed  mov r14d, [r15+0x320]
00007dd8609d17f4  mov eax, 0x4103F8
00007dd8609d17f9  mov rcx, 0x7DD8609D1860
00007dd8609d1803  mov [r15+r14*8+0x328], rax
00007dd8609d180b  mov [r15+r14*8+0x368], rcx
00007dd8609d1813  add r14d, 0x01
00007dd8609d1817  and r14d, 0x07
00007dd8609d181b  mov [r15+0x320], r14d
00007dd8609d1822  cmp dword ptr [r15+0x318], 0x00
00007dd8609d182a  jz 0x00007DD8609D0F20
00007dd8609d1830  nop [rax+rax*1], ax
00007dd8609d1839  nop [rax+rax*1], eax
00007dd8609d1841  mov eax, 0x4109A4
00007dd8609d1846  mov [r15+0x100], rax
00007dd8609d184d  jmp 0x00007DD8607FE110
00007dd8609d1852  int3
00007dd8609d1853  call 0x00007DD8608E2CE0
00007dd8609d1858  jmp 0x00007DD8609D17DB
00007dd8609d185d  int3
00007dd8609d185e  nop
00007dd8609d1860  mov eax, [r15+0x98]
00007dd8609d1867  lea r14d, [eax+0x01]
00007dd8609d186c  mov [rsp+0x10], r14d
00007dd8609d1871  mov r14d, r14d
00007dd8609d1874  mov [r15+0x98], r14
00007dd8609d187b  xor eax, eax
00007dd8609d187d  mov r14d, [rsp+0x10]
00007dd8609d1882  cmp r14d, 0x10000
00007dd8609d1889  cmc
00007dd8609d188a  lahf
00007dd8609d188b  seto al
00007dd8609d188e  mov [r15+0x108], eax
00007dd8609d1895  mov eax, [r15+0x108]
00007dd8609d189c  sahf
00007dd8609d189d  jnz 0x00007DD8609D18CF
00007dd8609d189f  cmp dword ptr [r15+0x318], 0x00
00007dd8609d18a7  jz 0x00007DD8609D19A0
00007dd8609d18ad  nop [rax+rax*1], ax
00007dd8609d18b6  nop [rax+rax*1], eax
00007dd8609d18be  mov eax, 0x410404
00007dd8609d18c3  mov [r15+0x100], rax
00007dd8609d18ca  jmp 0x00007DD8607FE110
00007dd8609d18cf  cmp dword ptr [r15+0x318], 0x00
00007dd8609d18d7  jz 0x00007DD8609D1910
00007dd8609d18dd  nop [rax+rax*1], ax
00007dd8609d18e6  nop [rax+rax*1], eax
00007dd8609d18ee  mov eax, 0x4103F0
00007dd8609d18f3  mov [r15+0x100], rax
00007dd8609d18fa  jmp 0x00007DD8607FE110
00007dd8609d18ff  int3
00007dd8609d1900  int3
00007dd8609d1901  nop [rax+rax*1], ax
00007dd8609d190a  nop [rax+rax*1], ax
00007dd8609d1910  mov eax, [r15]
00007dd8609d1913  mov r14d, [r15+0x98]
00007dd8609d191a  lea r12d, [eax+r14d*1]
00007dd8609d191f  mov r12d, r12d
00007dd8609d1922  mov [r15], r12
00007dd8609d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007dd8609d1930  mov r14d, [r15+0x320]
00007dd8609d1937  mov eax, 0x4103F8
00007dd8609d193c  mov rcx, 0x7DD8609D1860
00007dd8609d1946  mov [r15+r14*8+0x328], rax
00007dd8609d194e  mov [r15+r14*8+0x368], rcx
00007dd8609d1956  add r14d, 0x01
00007dd8609d195a  and r14d, 0x07
00007dd8609d195e  mov [r15+0x320], r14d
00007dd8609d1965  cmp dword ptr [r15+0x318], 0x00
00007dd8609d196d  jz 0x00007DD8609D0F20
00007dd8609d1973  nop [rax+rax*1], ax
00007dd8609d197c  nop [rax+rax*1], eax
00007dd8609d1984  mov eax, 0x4109A4
00007dd8609d1989  mov [r15+0x100], rax
00007dd8609d1990  jmp 0x00007DD8607FE110
00007dd8609d1995  int3
00007dd8609d1996  int3
00007dd8609d1997  nop [rax+rax*1], ax
00007dd8609d19a0  vmovaps xmm1, [0x00007DD8605FE010]
00007dd8609d19a8  movq xmm1, xmm1
00007dd8609d19ac  movaps [r15+0x110], xmm1
00007dd8609d19b4  mov eax, 0x420B10
00007dd8609d19b9  mov r14, [r13+rax*1]
00007dd8609d19be  movq xmm1, r14
00007dd8609d19c3  movaps [r15+0x120], xmm1
00007dd8609d19cb  vmovaps xmm1, [0x00007DD8605FE020]
00007dd8609d19d3  movq xmm1, xmm1
00007dd8609d19d7  movaps [r15+0x140], xmm1
00007dd8609d19df  vmovaps xmm1, [0x00007DD8605FE030]
00007dd8609d19e7  vpbroadcastq xmm1, xmm1
00007dd8609d19ec  movaps [r15+0x150], xmm1
00007dd8609d19f4  mov qword ptr [r15+0x40], 0x02
00007dd8609d19fc  vmovaps xmm15, [0x00007DD8605FE040]
00007dd8609d1a04  movq xmm15, xmm15
00007dd8609d1a09  movaps [r15+0x160], xmm15
00007dd8609d1a11  vmovaps xmm15, [0x00007DD8605FE050]
00007dd8609d1a19  vpbroadcastq xmm15, xmm15
00007dd8609d1a1e  movaps [r15+0x130], xmm15
00007dd8609d1a26  mov rax, [r15+0x40]
00007dd8609d1a2a  vmovq xmm14, rax
00007dd8609d1a2f  vpbroadcastq xmm14, xmm14
00007dd8609d1a34  movaps [r15+0x170], xmm14
00007dd8609d1a3c  mov eax, 0x420A40
00007dd8609d1a41  movups xmm13, [r13+rax*1]
00007dd8609d1a47  mov qword ptr [r15+0x40], 0x431E00
00007dd8609d1a4f  mov eax, [r15]
00007dd8609d1a52  mov r14d, 0x430CB8
00007dd8609d1a58  mov [r13+r14*1], eax
00007dd8609d1a5d  mov qword ptr [r15+0x50], 0x432000
00007dd8609d1a65  vpmovqd xmm12, xmm13
00007dd8609d1a6b  pxor xmm11, xmm11
00007dd8609d1a70  punpcklqdq xmm12, xmm11
00007dd8609d1a75  movaps [r15+0x210], xmm12
00007dd8609d1a7d  movq xmm12, qword ptr [r15+0x140]
00007dd8609d1a86  movq xmm11, qword ptr [r15+0x120]
00007dd8609d1a8f  psubd xmm12, xmm11
00007dd8609d1a94  movq xmm12, xmm12
00007dd8609d1a99  paddq xmm13, xmm14
00007dd8609d1a9e  movaps [r15+0x180], xmm13
00007dd8609d1aa6  movq xmm14, qword ptr [r15+0x160]
00007dd8609d1aaf  paddd xmm11, xmm14
00007dd8609d1ab4  movq xmm11, xmm11
00007dd8609d1ab9  movq xmm11, xmm11
00007dd8609d1abe  movaps [r15+0x120], xmm11
00007dd8609d1ac6  pmovzxdq xmm12, xmm12
00007dd8609d1acc  psllq xmm12, 0x00
00007dd8609d1ad2  movq xmm14, qword ptr [r15+0x210]
00007dd8609d1adb  movq xmm13, qword ptr [r15+0x110]
00007dd8609d1ae4  paddd xmm14, xmm13
00007dd8609d1ae9  movq xmm14, xmm14
00007dd8609d1aee  vcvtuqq2pd xmm12, xmm12
00007dd8609d1af4  pmovzxdq xmm14, xmm14
00007dd8609d1afa  psllq xmm14, 0x00
00007dd8609d1b00  vcvtuqq2pd xmm14, xmm14
00007dd8609d1b06  movaps xmm13, xmm12
00007dd8609d1b0a  mulpd xmm13, xmm1
00007dd8609d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007dd8609d1b15  ptest xmm11, xmm11
00007dd8609d1b1b  jnz 0x00007DD8609D1C0F
00007dd8609d1b21  movaps [r15+0x220], xmm13
00007dd8609d1b29  mov eax, 0x432000
00007dd8609d1b2e  movups [r13+rax*1], xmm13
00007dd8609d1b34  movaps xmm1, xmm14
00007dd8609d1b38  mulpd xmm1, xmm15
00007dd8609d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007dd8609d1b42  ptest xmm13, xmm13
00007dd8609d1b48  jnz 0x00007DD8609D1D5C
00007dd8609d1b4e  movaps [r15+0x210], xmm1
00007dd8609d1b56  mov eax, 0x431E00
00007dd8609d1b5b  movups [r13+rax*1], xmm1
00007dd8609d1b61  mov qword ptr [r15+0x48], 0x10
00007dd8609d1b69  xor eax, eax
00007dd8609d1b6b  mov r14d, 0x10
00007dd8609d1b71  mov r12d, 0x200
00007dd8609d1b77  cmp r14, r12
00007dd8609d1b7a  cmc
00007dd8609d1b7b  lahf
00007dd8609d1b7c  seto al
00007dd8609d1b7f  mov [r15+0x108], eax
00007dd8609d1b86  mov eax, [r15+0x108]
00007dd8609d1b8d  sahf
00007dd8609d1b8e  jnz 0x00007DD8609D1BC0
00007dd8609d1b90  cmp dword ptr [r15+0x318], 0x00
00007dd8609d1b98  jz 0x00007DD8609D2300
00007dd8609d1b9e  nop [rax+rax*1], ax
00007dd8609d1ba7  nop [rax+rax*1], eax
00007dd8609d1baf  mov eax, 0x410490
00007dd8609d1bb4  mov [r15+0x100], rax
00007dd8609d1bbb  jmp 0x00007DD8607FE110
00007dd8609d1bc0  cmp dword ptr [r15+0x318], 0x00
00007dd8609d1bc8  jz 0x00007DD8609D1EB0
00007dd8609d1bce  nop [rax+rax*1], ax
00007dd8609d1bd7  nop [rax+rax*1], eax
00007dd8609d1bdf  mov eax, 0x410450
00007dd8609d1be4  mov [r15+0x100], rax
00007dd8609d1beb  jmp 0x00007DD8607FE110
00007dd8609d1bf0  int3
00007dd8609d1bf1  call 0x00007DD86080DC20
00007dd8609d1bf6  jmp 0x00007DD8609D19BE
00007dd8609d1bfb  call 0x00007DD86080C260
00007dd8609d1c00  jmp 0x00007DD8609D1A47
00007dd8609d1c05  call 0x00007DD8608D5D70
00007dd8609d1c0a  jmp 0x00007DD8609D1A5D
00007dd8609d1c0f  sub rsp, 0x08
00007dd8609d1c13  push rax
00007dd8609d1c14  push rcx
00007dd8609d1c15  push rdx
00007dd8609d1c16  push rdi
00007dd8609d1c17  push rsi
00007dd8609d1c18  push r8
00007dd8609d1c1a  push r9
00007dd8609d1c1c  push r10
00007dd8609d1c1e  push r11
00007dd8609d1c20  sub rsp, 0xF0
00007dd8609d1c27  vmovaps [rsp], xmm0
00007dd8609d1c2c  vmovaps [rsp+0x10], xmm1
00007dd8609d1c32  vmovaps [rsp+0x20], xmm2
00007dd8609d1c38  vmovaps [rsp+0x30], xmm3
00007dd8609d1c3e  vmovaps [rsp+0x40], xmm4
00007dd8609d1c44  vmovaps [rsp+0x50], xmm5
00007dd8609d1c4a  vmovaps [rsp+0x60], xmm6
00007dd8609d1c50  vmovaps [rsp+0x70], xmm7
00007dd8609d1c56  vmovaps [rsp+0x80], xmm8
00007dd8609d1c5f  vmovaps [rsp+0x90], xmm9
00007dd8609d1c68  vmovaps [rsp+0xA0], xmm10
00007dd8609d1c71  vmovaps [rsp+0xB0], xmm11
00007dd8609d1c7a  vmovaps [rsp+0xC0], xmm12
00007dd8609d1c83  vmovaps [rsp+0xD0], xmm14
00007dd8609d1c8c  vmovaps [rsp+0xE0], xmm15
00007dd8609d1c95  sub rsp, 0x30
00007dd8609d1c99  movaps [rsp], xmm13
00007dd8609d1c9e  movaps [rsp+0x10], xmm12
00007dd8609d1ca4  movaps [rsp+0x20], xmm1
00007dd8609d1ca9  lea rdi, [rsp]
00007dd8609d1cad  mov esi, 0x00
00007dd8609d1cb2  mov rax, 0x629C9CFA9530
00007dd8609d1cbc  call rax
00007dd8609d1cbe  movaps xmm13, [rsp]
00007dd8609d1cc3  add rsp, 0x30
00007dd8609d1cc7  vmovaps xmm0, [rsp]
00007dd8609d1ccc  vmovaps xmm1, [rsp+0x10]
00007dd8609d1cd2  vmovaps xmm2, [rsp+0x20]
00007dd8609d1cd8  vmovaps xmm3, [rsp+0x30]
00007dd8609d1cde  vmovaps xmm4, [rsp+0x40]
00007dd8609d1ce4  vmovaps xmm5, [rsp+0x50]
00007dd8609d1cea  vmovaps xmm6, [rsp+0x60]
00007dd8609d1cf0  vmovaps xmm7, [rsp+0x70]
00007dd8609d1cf6  vmovaps xmm8, [rsp+0x80]
00007dd8609d1cff  vmovaps xmm9, [rsp+0x90]
00007dd8609d1d08  vmovaps xmm10, [rsp+0xA0]
00007dd8609d1d11  vmovaps xmm11, [rsp+0xB0]
00007dd8609d1d1a  vmovaps xmm12, [rsp+0xC0]
00007dd8609d1d23  vmovaps xmm14, [rsp+0xD0]
00007dd8609d1d2c  vmovaps xmm15, [rsp+0xE0]
00007dd8609d1d35  add rsp, 0xF0
00007dd8609d1d3c  pop r11
00007dd8609d1d3e  pop r10
00007dd8609d1d40  pop r9
00007dd8609d1d42  pop r8
00007dd8609d1d44  pop rsi
00007dd8609d1d45  pop rdi
00007dd8609d1d46  pop rdx
00007dd8609d1d47  pop rcx
00007dd8609d1d48  pop rax
00007dd8609d1d49  add rsp, 0x08
00007dd8609d1d4d  jmp 0x00007DD8609D1B21
00007dd8609d1d52  call 0x00007DD86080C380
00007dd8609d1d57  jmp 0x00007DD8609D1B34
00007dd8609d1d5c  sub rsp, 0x08
00007dd8609d1d60  push rax
00007dd8609d1d61  push rcx
00007dd8609d1d62  push rdx
00007dd8609d1d63  push rdi
00007dd8609d1d64  push rsi
00007dd8609d1d65  push r8
00007dd8609d1d67  push r9
00007dd8609d1d69  push r10
00007dd8609d1d6b  push r11
00007dd8609d1d6d  sub rsp, 0xF0
00007dd8609d1d74  vmovaps [rsp], xmm0
00007dd8609d1d79  vmovaps [rsp+0x10], xmm2
00007dd8609d1d7f  vmovaps [rsp+0x20], xmm3
00007dd8609d1d85  vmovaps [rsp+0x30], xmm4
00007dd8609d1d8b  vmovaps [rsp+0x40], xmm5
00007dd8609d1d91  vmovaps [rsp+0x50], xmm6
00007dd8609d1d97  vmovaps [rsp+0x60], xmm7
00007dd8609d1d9d  vmovaps [rsp+0x70], xmm8
00007dd8609d1da3  vmovaps [rsp+0x80], xmm9
00007dd8609d1dac  vmovaps [rsp+0x90], xmm10
00007dd8609d1db5  vmovaps [rsp+0xA0], xmm11
00007dd8609d1dbe  vmovaps [rsp+0xB0], xmm12
00007dd8609d1dc7  vmovaps [rsp+0xC0], xmm13
00007dd8609d1dd0  vmovaps [rsp+0xD0], xmm14
00007dd8609d1dd9  vmovaps [rsp+0xE0], xmm15
00007dd8609d1de2  sub rsp, 0x30
00007dd8609d1de6  movaps [rsp], xmm1
00007dd8609d1dea  movaps [rsp+0x10], xmm14
00007dd8609d1df0  movaps [rsp+0x20], xmm15
00007dd8609d1df6  lea rdi, [rsp]
00007dd8609d1dfa  mov esi, 0x00
00007dd8609d1dff  mov rax, 0x629C9CFA9530
00007dd8609d1e09  call rax
00007dd8609d1e0b  movaps xmm1, [rsp]
00007dd8609d1e0f  add rsp, 0x30
00007dd8609d1e13  vmovaps xmm0, [rsp]
00007dd8609d1e18  vmovaps xmm2, [rsp+0x10]
00007dd8609d1e1e  vmovaps xmm3, [rsp+0x20]
00007dd8609d1e24  vmovaps xmm4, [rsp+0x30]
00007dd8609d1e2a  vmovaps xmm5, [rsp+0x40]
00007dd8609d1e30  vmovaps xmm6, [rsp+0x50]
00007dd8609d1e36  vmovaps xmm7, [rsp+0x60]
00007dd8609d1e3c  vmovaps xmm8, [rsp+0x70]
00007dd8609d1e42  vmovaps xmm9, [rsp+0x80]
00007dd8609d1e4b  vmovaps xmm10, [rsp+0x90]
00007dd8609d1e54  vmovaps xmm11, [rsp+0xA0]
00007dd8609d1e5d  vmovaps xmm12, [rsp+0xB0]
00007dd8609d1e66  vmovaps xmm13, [rsp+0xC0]
00007dd8609d1e6f  vmovaps xmm14, [rsp+0xD0]
00007dd8609d1e78  vmovaps xmm15, [rsp+0xE0]
00007dd8609d1e81  add rsp, 0xF0
00007dd8609d1e88  pop r11
00007dd8609d1e8a  pop r10
00007dd8609d1e8c  pop r9
00007dd8609d1e8e  pop r8
00007dd8609d1e90  pop rsi
00007dd8609d1e91  pop rdi
00007dd8609d1e92  pop rdx
00007dd8609d1e93  pop rcx
00007dd8609d1e94  pop rax
00007dd8609d1e95  add rsp, 0x08
00007dd8609d1e99  jmp 0x00007DD8609D1B4E
00007dd8609d1e9e  call 0x00007DD8607FF540
00007dd8609d1ea3  jmp 0x00007DD8609D1B61
00007dd8609d1ea8  int3
00007dd8609d1ea9  nop [rax], eax
00007dd8609d1eb0  movaps xmm1, [r15+0x180]
00007dd8609d1eb8  vpmovqd xmm15, xmm1
00007dd8609d1ebe  pxor xmm14, xmm14
00007dd8609d1ec3  punpcklqdq xmm15, xmm14
00007dd8609d1ec8  movaps [r15+0x210], xmm15
00007dd8609d1ed0  movq xmm15, qword ptr [r15+0x140]
00007dd8609d1ed9  movq xmm14, qword ptr [r15+0x120]
00007dd8609d1ee2  psubd xmm15, xmm14
00007dd8609d1ee7  movq xmm15, xmm15
00007dd8609d1eec  movaps xmm13, [r15+0x170]
00007dd8609d1ef4  paddq xmm1, xmm13
00007dd8609d1ef9  movaps [r15+0x180], xmm1
00007dd8609d1f01  movq xmm1, qword ptr [r15+0x160]
00007dd8609d1f0a  paddd xmm14, xmm1
00007dd8609d1f0f  movq xmm14, xmm14
00007dd8609d1f14  movq xmm14, xmm14
00007dd8609d1f19  movaps [r15+0x120], xmm14
00007dd8609d1f21  pmovzxdq xmm15, xmm15
00007dd8609d1f27  psllq xmm15, 0x00
00007dd8609d1f2d  movq xmm1, qword ptr [r15+0x210]
00007dd8609d1f36  movq xmm14, qword ptr [r15+0x110]
00007dd8609d1f3f  paddd xmm1, xmm14
00007dd8609d1f44  movq xmm1, xmm1
00007dd8609d1f48  vcvtuqq2pd xmm15, xmm15
00007dd8609d1f4e  pmovzxdq xmm1, xmm1
00007dd8609d1f53  psllq xmm1, 0x00
00007dd8609d1f58  vcvtuqq2pd xmm1, xmm1
00007dd8609d1f5e  movaps xmm14, [r15+0x150]
00007dd8609d1f66  movaps xmm13, xmm15
00007dd8609d1f6a  mulpd xmm13, xmm14
00007dd8609d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd8609d1f75  ptest xmm12, xmm12
00007dd8609d1f7b  jnz 0x00007DD8609D205E
00007dd8609d1f81  movaps [r15+0x220], xmm13
00007dd8609d1f89  mov rax, [r15+0x48]
00007dd8609d1f8d  mov r14, [r15+0x50]
00007dd8609d1f91  lea r12, [r14+rax*1]
00007dd8609d1f95  movups [r13+r12*1], xmm13
00007dd8609d1f9b  movaps xmm15, [r15+0x130]
00007dd8609d1fa3  movaps xmm14, xmm1
00007dd8609d1fa7  mulpd xmm14, xmm15
00007dd8609d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd8609d1fb2  ptest xmm13, xmm13
00007dd8609d1fb8  jnz 0x00007DD8609D21AC
00007dd8609d1fbe  movaps [r15+0x210], xmm14
00007dd8609d1fc6  mov r14, [r15+0x40]
00007dd8609d1fca  lea r12, [r14+rax*1]
00007dd8609d1fce  movups [r13+r12*1], xmm14
00007dd8609d1fd4  lea r14, [rax+0x10]
00007dd8609d1fd8  mov [r15+0x48], r14
00007dd8609d1fdc  xor eax, eax
00007dd8609d1fde  mov r12d, 0x200
00007dd8609d1fe4  cmp r14, r12
00007dd8609d1fe7  cmc
00007dd8609d1fe8  lahf
00007dd8609d1fe9  seto al
00007dd8609d1fec  mov [r15+0x108], eax
00007dd8609d1ff3  mov eax, [r15+0x108]
00007dd8609d1ffa  sahf
00007dd8609d1ffb  jnz 0x00007DD8609D202D
00007dd8609d1ffd  cmp dword ptr [r15+0x318], 0x00
00007dd8609d2005  jz 0x00007DD8609D2300
00007dd8609d200b  nop [rax+rax*1], ax
00007dd8609d2014  nop [rax+rax*1], eax
00007dd8609d201c  mov eax, 0x410490
00007dd8609d2021  mov [r15+0x100], rax
00007dd8609d2028  jmp 0x00007DD8607FE110
00007dd8609d202d  cmp dword ptr [r15+0x318], 0x00
00007dd8609d2035  jz 0x00007DD8609D1EB0
00007dd8609d203b  nop [rax+rax*1], ax
00007dd8609d2044  nop [rax+rax*1], eax
00007dd8609d204c  mov eax, 0x410450
00007dd8609d2051  mov [r15+0x100], rax
00007dd8609d2058  jmp 0x00007DD8607FE110
00007dd8609d205d  int3
00007dd8609d205e  sub rsp, 0x08
00007dd8609d2062  push rax
00007dd8609d2063  push rcx
00007dd8609d2064  push rdx
00007dd8609d2065  push rdi
00007dd8609d2066  push rsi
00007dd8609d2067  push r8
00007dd8609d2069  push r9
00007dd8609d206b  push r10
00007dd8609d206d  push r11
00007dd8609d206f  sub rsp, 0xF0
00007dd8609d2076  vmovaps [rsp], xmm0
00007dd8609d207b  vmovaps [rsp+0x10], xmm1
00007dd8609d2081  vmovaps [rsp+0x20], xmm2
00007dd8609d2087  vmovaps [rsp+0x30], xmm3
00007dd8609d208d  vmovaps [rsp+0x40], xmm4
00007dd8609d2093  vmovaps [rsp+0x50], xmm5
00007dd8609d2099  vmovaps [rsp+0x60], xmm6
00007dd8609d209f  vmovaps [rsp+0x70], xmm7
00007dd8609d20a5  vmovaps [rsp+0x80], xmm8
00007dd8609d20ae  vmovaps [rsp+0x90], xmm9
00007dd8609d20b7  vmovaps [rsp+0xA0], xmm10
00007dd8609d20c0  vmovaps [rsp+0xB0], xmm11
00007dd8609d20c9  vmovaps [rsp+0xC0], xmm12
00007dd8609d20d2  vmovaps [rsp+0xD0], xmm14
00007dd8609d20db  vmovaps [rsp+0xE0], xmm15
00007dd8609d20e4  sub rsp, 0x30
00007dd8609d20e8  movaps [rsp], xmm13
00007dd8609d20ed  movaps [rsp+0x10], xmm15
00007dd8609d20f3  movaps [rsp+0x20], xmm14
00007dd8609d20f9  lea rdi, [rsp]
00007dd8609d20fd  mov esi, 0x00
00007dd8609d2102  mov rax, 0x629C9CFA9530
00007dd8609d210c  call rax
00007dd8609d210e  movaps xmm13, [rsp]
00007dd8609d2113  add rsp, 0x30
00007dd8609d2117  vmovaps xmm0, [rsp]
00007dd8609d211c  vmovaps xmm1, [rsp+0x10]
00007dd8609d2122  vmovaps xmm2, [rsp+0x20]
00007dd8609d2128  vmovaps xmm3, [rsp+0x30]
00007dd8609d212e  vmovaps xmm4, [rsp+0x40]
00007dd8609d2134  vmovaps xmm5, [rsp+0x50]
00007dd8609d213a  vmovaps xmm6, [rsp+0x60]
00007dd8609d2140  vmovaps xmm7, [rsp+0x70]
00007dd8609d2146  vmovaps xmm8, [rsp+0x80]
00007dd8609d214f  vmovaps xmm9, [rsp+0x90]
00007dd8609d2158  vmovaps xmm10, [rsp+0xA0]
00007dd8609d2161  vmovaps xmm11, [rsp+0xB0]
00007dd8609d216a  vmovaps xmm12, [rsp+0xC0]
00007dd8609d2173  vmovaps xmm14, [rsp+0xD0]
00007dd8609d217c  vmovaps xmm15, [rsp+0xE0]
00007dd8609d2185  add rsp, 0xF0
00007dd8609d218c  pop r11
00007dd8609d218e  pop r10
00007dd8609d2190  pop r9
00007dd8609d2192  pop r8
00007dd8609d2194  pop rsi
00007dd8609d2195  pop rdi
00007dd8609d2196  pop rdx
00007dd8609d2197  pop rcx
00007dd8609d2198  pop rax
00007dd8609d2199  add rsp, 0x08
00007dd8609d219d  jmp 0x00007DD8609D1F81
00007dd8609d21a2  call 0x00007DD8608C2240
00007dd8609d21a7  jmp 0x00007DD8609D1F9B
00007dd8609d21ac  sub rsp, 0x08
00007dd8609d21b0  push rax
00007dd8609d21b1  push rcx
00007dd8609d21b2  push rdx
00007dd8609d21b3  push rdi
00007dd8609d21b4  push rsi
00007dd8609d21b5  push r8
00007dd8609d21b7  push r9
00007dd8609d21b9  push r10
00007dd8609d21bb  push r11
00007dd8609d21bd  sub rsp, 0xF0
00007dd8609d21c4  vmovaps [rsp], xmm0
00007dd8609d21c9  vmovaps [rsp+0x10], xmm1
00007dd8609d21cf  vmovaps [rsp+0x20], xmm2
00007dd8609d21d5  vmovaps [rsp+0x30], xmm3
00007dd8609d21db  vmovaps [rsp+0x40], xmm4
00007dd8609d21e1  vmovaps [rsp+0x50], xmm5
00007dd8609d21e7  vmovaps [rsp+0x60], xmm6
00007dd8609d21ed  vmovaps [rsp+0x70], xmm7
00007dd8609d21f3  vmovaps [rsp+0x80], xmm8
00007dd8609d21fc  vmovaps [rsp+0x90], xmm9
00007dd8609d2205  vmovaps [rsp+0xA0], xmm10
00007dd8609d220e  vmovaps [rsp+0xB0], xmm11
00007dd8609d2217  vmovaps [rsp+0xC0], xmm12
00007dd8609d2220  vmovaps [rsp+0xD0], xmm13
00007dd8609d2229  vmovaps [rsp+0xE0], xmm15
00007dd8609d2232  sub rsp, 0x30
00007dd8609d2236  movaps [rsp], xmm14
00007dd8609d223b  movaps [rsp+0x10], xmm1
00007dd8609d2240  movaps [rsp+0x20], xmm15
00007dd8609d2246  lea rdi, [rsp]
00007dd8609d224a  mov esi, 0x00
00007dd8609d224f  mov rax, 0x629C9CFA9530
00007dd8609d2259  call rax
00007dd8609d225b  movaps xmm14, [rsp]
00007dd8609d2260  add rsp, 0x30
00007dd8609d2264  vmovaps xmm0, [rsp]
00007dd8609d2269  vmovaps xmm1, [rsp+0x10]
00007dd8609d226f  vmovaps xmm2, [rsp+0x20]
00007dd8609d2275  vmovaps xmm3, [rsp+0x30]
00007dd8609d227b  vmovaps xmm4, [rsp+0x40]
00007dd8609d2281  vmovaps xmm5, [rsp+0x50]
00007dd8609d2287  vmovaps xmm6, [rsp+0x60]
00007dd8609d228d  vmovaps xmm7, [rsp+0x70]
00007dd8609d2293  vmovaps xmm8, [rsp+0x80]
00007dd8609d229c  vmovaps xmm9, [rsp+0x90]
00007dd8609d22a5  vmovaps xmm10, [rsp+0xA0]
00007dd8609d22ae  vmovaps xmm11, [rsp+0xB0]
00007dd8609d22b7  vmovaps xmm12, [rsp+0xC0]
00007dd8609d22c0  vmovaps xmm13, [rsp+0xD0]
00007dd8609d22c9  vmovaps xmm15, [rsp+0xE0]
00007dd8609d22d2  add rsp, 0xF0
00007dd8609d22d9  pop r11
00007dd8609d22db  pop r10
00007dd8609d22dd  pop r9
00007dd8609d22df  pop r8
00007dd8609d22e1  pop rsi
00007dd8609d22e2  pop rdi
00007dd8609d22e3  pop rdx
00007dd8609d22e4  pop rcx
00007dd8609d22e5  pop rax
00007dd8609d22e6  add rsp, 0x08
00007dd8609d22ea  jmp 0x00007DD8609D1FBE
00007dd8609d22ef  call 0x00007DD8608C34C0
00007dd8609d22f4  jmp 0x00007DD8609D1FD4
00007dd8609d22f9  int3
00007dd8609d22fa  nop [rax+rax*1], ax
00007dd8609d2300  mov rax, [r15+0x50]
00007dd8609d2304  lea r14, [rax+0x80]
00007dd8609d230b  movups xmm1, [r13+r14*1]
00007dd8609d2311  lea r14, [rax+0x90]
00007dd8609d2318  movups xmm15, [r13+r14*1]
00007dd8609d231e  vxorps xmm14, xmm14, xmm14
00007dd8609d2323  vpbroadcastq xmm14, xmm14
00007dd8609d2328  lea r14, [rax+0x40]
00007dd8609d232c  movups xmm13, [r13+r14*1]
00007dd8609d2332  lea r14, [rax+0x50]
00007dd8609d2336  movups xmm12, [r13+r14*1]
00007dd8609d233c  mov qword ptr [r15+0x48], 0x00
00007dd8609d2344  movups xmm11, [r13+rax*1]
00007dd8609d234a  lea r14, [rax+0x10]
00007dd8609d234e  movups xmm10, [r13+r14*1]
00007dd8609d2354  mov r14, [r15+0xF8]
00007dd8609d235b  lea r12, [r14+0xE0]
00007dd8609d2362  movups [r13+r12*1], xmm15
00007dd8609d2368  lea r12, [r14+0xF0]
00007dd8609d236f  movups [r13+r12*1], xmm1
00007dd8609d2375  lea r12, [rax+0xC0]
00007dd8609d237c  movups xmm1, [r13+r12*1]
00007dd8609d2382  lea r12, [rax+0xD0]
00007dd8609d2389  movups xmm15, [r13+r12*1]
00007dd8609d238f  lea r12, [rax+0x140]
00007dd8609d2396  movups xmm9, [r13+r12*1]
00007dd8609d239c  lea r12, [rax+0x150]
00007dd8609d23a3  movups xmm8, [r13+r12*1]
00007dd8609d23a9  lea r12, [rax+0x180]
00007dd8609d23b0  movups xmm7, [r13+r12*1]
00007dd8609d23b6  lea r12, [rax+0x190]
00007dd8609d23bd  movups xmm6, [r13+r12*1]
00007dd8609d23c3  lea r12, [r14+0xC0]
00007dd8609d23ca  movups [r13+r12*1], xmm15
00007dd8609d23d0  lea r12, [r14+0xD0]
00007dd8609d23d7  movups [r13+r12*1], xmm1
00007dd8609d23dd  lea r12, [rax+0x100]
00007dd8609d23e4  movups xmm1, [r13+r12*1]
00007dd8609d23ea  lea r12, [rax+0x110]
00007dd8609d23f1  movups xmm15, [r13+r12*1]
00007dd8609d23f7  lea r12, [rax+0x1C0]
00007dd8609d23fe  movups xmm5, [r13+r12*1]
00007dd8609d2404  lea r12, [rax+0x1D0]
00007dd8609d240b  movups xmm4, [r13+r12*1]
00007dd8609d2411  lea r12, [rax+0x20]
00007dd8609d2415  movups xmm3, [r13+r12*1]
00007dd8609d241b  lea r12, [rax+0x30]
00007dd8609d241f  movups xmm2, [r13+r12*1]
00007dd8609d2425  movaps [r15+0x1F0], xmm2
00007dd8609d242d  lea r12, [r14+0x20]
00007dd8609d2431  movups [r13+r12*1], xmm1
00007dd8609d2437  lea r12, [r14+0x30]
00007dd8609d243b  movups [r13+r12*1], xmm12
00007dd8609d2441  lea r12, [rax+0x60]
00007dd8609d2445  movups xmm1, [r13+r12*1]
00007dd8609d244b  lea r12, [rax+0x70]
00007dd8609d244f  movups xmm12, [r13+r12*1]
00007dd8609d2455  lea r12, [r14+0x60]
00007dd8609d2459  movups [r13+r12*1], xmm11
00007dd8609d245f  lea r12, [r14+0x70]
00007dd8609d2463  movups [r13+r12*1], xmm5
00007dd8609d2469  lea r12, [rax+0xE0]
00007dd8609d2470  movups xmm11, [r13+r12*1]
00007dd8609d2476  lea r12, [rax+0xF0]
00007dd8609d247d  movups xmm5, [r13+r12*1]
00007dd8609d2483  lea r12, [rax+0x120]
00007dd8609d248a  vmovaps [rsp+0x10], xmm1
00007dd8609d2490  movups xmm1, [r13+r12*1]
00007dd8609d2496  lea r12, [rax+0x130]
00007dd8609d249d  vmovaps [rsp+0x20], xmm1
00007dd8609d24a3  movups xmm1, [r13+r12*1]
00007dd8609d24a9  lea r12, [r14+0xA0]
00007dd8609d24b0  movups [r13+r12*1], xmm12
00007dd8609d24b6  lea r12, [r14+0xB0]
00007dd8609d24bd  vmovaps xmm12, [rsp+0x10]
00007dd8609d24c3  movups [r13+r12*1], xmm12
00007dd8609d24c9  lea r12, [rax+0xA0]
00007dd8609d24d0  movups xmm12, [r13+r12*1]
00007dd8609d24d6  lea r12, [rax+0xB0]
00007dd8609d24dd  vmovaps [rsp+0x10], xmm1
00007dd8609d24e3  movups xmm1, [r13+r12*1]
00007dd8609d24e9  lea r12, [rax+0x160]
00007dd8609d24f0  vmovaps [rsp+0x30], xmm1
00007dd8609d24f6  movups xmm1, [r13+r12*1]
00007dd8609d24fc  lea r12, [rax+0x170]
00007dd8609d2503  vmovaps [rsp+0x40], xmm1
00007dd8609d2509  movups xmm1, [r13+r12*1]
00007dd8609d250f  movaps [r15+0x2B0], xmm1
00007dd8609d2517  lea r12, [rax+0x1A0]
00007dd8609d251e  vmovaps [rsp+0x50], xmm1
00007dd8609d2524  movups xmm1, [r13+r12*1]
00007dd8609d252a  lea r12, [rax+0x1B0]
00007dd8609d2531  vmovaps [rsp+0x60], xmm1
00007dd8609d2537  movups xmm1, [r13+r12*1]
00007dd8609d253d  vmovaps [rsp+0x70], xmm1
00007dd8609d2543  vmovaps xmm1, [rsp+0x60]
00007dd8609d2549  movaps [r15+0x290], xmm1
00007dd8609d2551  vmovaps [rsp+0x60], xmm1
00007dd8609d2557  vmovaps xmm1, [rsp+0x70]
00007dd8609d255d  movaps [r15+0x1E0], xmm1
00007dd8609d2565  lea r12, [r14+0x80]
00007dd8609d256c  vmovaps [rsp+0x70], xmm1
00007dd8609d2572  vmovaps xmm1, [rsp+0x30]
00007dd8609d2578  movups [r13+r12*1], xmm1
00007dd8609d257e  lea r12, [r14+0x90]
00007dd8609d2585  movups [r13+r12*1], xmm12
00007dd8609d258b  lea r12, [rax+0x1E0]
00007dd8609d2592  movups xmm1, [r13+r12*1]
00007dd8609d2598  lea r12, [rax+0x1F0]
00007dd8609d259f  movups xmm12, [r13+r12*1]
00007dd8609d25a5  mov qword ptr [r15+0x50], 0x432200
00007dd8609d25ad  lea rax, [r14+0x40]
00007dd8609d25b1  vmovaps [rsp+0x30], xmm1
00007dd8609d25b7  vmovaps xmm1, [rsp+0x40]
00007dd8609d25bd  movups [r13+rax*1], xmm1
00007dd8609d25c3  lea rax, [r14+0x50]
00007dd8609d25c7  movups [r13+rax*1], xmm10
00007dd8609d25cd  movups [r13+r14*1], xmm12
00007dd8609d25d3  lea rax, [r14+0x10]
00007dd8609d25d7  vmovaps xmm1, [rsp+0x30]
00007dd8609d25dd  movups [r13+rax*1], xmm1
00007dd8609d25e3  mov rax, [r15+0x40]
00007dd8609d25e7  vmovaps [rsp+0x30], xmm3
00007dd8609d25ed  vmovaps xmm1, [rsp+0x30]
00007dd8609d25f3  por xmm3, xmm1
00007dd8609d25f7  vmovaps [rsp+0x30], xmm6
00007dd8609d25fd  vmovaps xmm12, [rsp+0x30]
00007dd8609d2603  por xmm6, xmm12
00007dd8609d2608  lea r12, [rax+0x30]
00007dd8609d260c  mov r11, [r13+r12*1]
00007dd8609d2611  lea r12, [rax+0x38]
00007dd8609d2615  mov r10, [r13+r12*1]
00007dd8609d261a  movq xmm12, r11
00007dd8609d261f  movq xmm10, r10
00007dd8609d2624  movq xmm12, xmm12
00007dd8609d2629  vmovaps [rsp+0x30], xmm12
00007dd8609d262f  movq xmm12, xmm12
00007dd8609d2634  movaps [r15+0x130], xmm12
00007dd8609d263c  movq xmm10, xmm10
00007dd8609d2641  vmovaps [rsp+0x40], xmm10
00007dd8609d2647  movq xmm10, xmm10
00007dd8609d264c  movaps [r15+0x280], xmm10
00007dd8609d2654  vmovaps [rsp+0x80], xmm9
00007dd8609d265d  vmovaps xmm12, [rsp+0x80]
00007dd8609d2666  por xmm9, xmm12
00007dd8609d266b  lea r12, [rax+0x20]
00007dd8609d266f  mov r11, [r13+r12*1]
00007dd8609d2674  lea r12, [rax+0x28]
00007dd8609d2678  mov r10, [r13+r12*1]
00007dd8609d267d  movq xmm12, r11
00007dd8609d2682  movq xmm10, r10
00007dd8609d2687  movq xmm12, xmm12
00007dd8609d268c  vmovaps [rsp+0x80], xmm12
00007dd8609d2695  movq xmm12, xmm12
00007dd8609d269a  movaps [r15+0x150], xmm12
00007dd8609d26a2  movq xmm10, xmm10
00007dd8609d26a7  vmovaps [rsp+0x90], xmm10
00007dd8609d26b0  movq xmm10, xmm10
00007dd8609d26b5  movaps [r15+0x140], xmm10
00007dd8609d26bd  lea r12, [rax+0x10]
00007dd8609d26c1  mov r11, [r13+r12*1]
00007dd8609d26c6  lea r12, [rax+0x18]
00007dd8609d26ca  mov r10, [r13+r12*1]
00007dd8609d26cf  movq xmm12, r11
00007dd8609d26d4  movq xmm10, r10
00007dd8609d26d9  movq xmm12, xmm12
00007dd8609d26de  vmovaps [rsp+0xA0], xmm12
00007dd8609d26e7  movq xmm12, xmm12
00007dd8609d26ec  movaps [r15+0x170], xmm12
00007dd8609d26f4  movq xmm10, xmm10
00007dd8609d26f9  vmovaps [rsp+0xB0], xmm10
00007dd8609d2702  movq xmm10, xmm10
00007dd8609d2707  movaps [r15+0x160], xmm10
00007dd8609d270f  mov r12, [r13+rax*1]
00007dd8609d2714  vmovq xmm12, r12
00007dd8609d2719  vpbroadcastq xmm12, xmm12
00007dd8609d271e  lea r12, [rax+0x08]
00007dd8609d2722  mov rax, [r13+r12*1]
00007dd8609d2727  movq xmm10, rax
00007dd8609d272c  movaps [r15+0x230], xmm10
00007dd8609d2734  lea rax, [r14+0x50]
00007dd8609d2738  movups xmm10, [r13+rax*1]
00007dd8609d273e  lea rax, [r14+0x60]
00007dd8609d2742  vmovaps [rsp+0xC0], xmm1
00007dd8609d274b  movups xmm1, [r13+rax*1]
00007dd8609d2751  lea rax, [r14+0x30]
00007dd8609d2755  vmovaps [rsp+0xD0], xmm1
00007dd8609d275e  movups xmm1, [r13+rax*1]
00007dd8609d2764  mov qword ptr [r15+0x60], 0x432200
00007dd8609d276c  mov qword ptr [r15+0x58], 0x40
00007dd8609d2774  vmovaps [rsp+0xE0], xmm1
00007dd8609d277d  vmovaps [rsp+0xF0], xmm15
00007dd8609d2786  vmovaps xmm15, [rsp+0xC0]
00007dd8609d278f  vmovaps [rsp+0xC0], xmm14
00007dd8609d2798  movaps xmm1, xmm12
00007dd8609d279c  mulpd xmm1, xmm15
00007dd8609d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8609d27a6  ptest xmm14, xmm14
00007dd8609d27ac  jnz 0x00007DD8609D3863
00007dd8609d27b2  movq xmm15, qword ptr [r15+0x230]
00007dd8609d27bb  vmovaps [rsp+0x100], xmm15
00007dd8609d27c4  vpermilpd xmm15, xmm15, 0x00
00007dd8609d27ca  vmovaps [rsp+0x110], xmm1
00007dd8609d27d3  vmovaps xmm1, [rsp+0xE0]
00007dd8609d27dc  vmovaps [rsp+0xE0], xmm13
00007dd8609d27e5  movaps xmm14, xmm1
00007dd8609d27e9  mulpd xmm14, xmm15
00007dd8609d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd8609d27f4  ptest xmm13, xmm13
00007dd8609d27fa  jnz 0x00007DD8609D39A5
00007dd8609d2800  vxorps xmm1, xmm1, xmm1
00007dd8609d2804  vpbroadcastq xmm1, xmm1
00007dd8609d2809  vmovaps xmm13, [rsp+0xD0]
00007dd8609d2812  vmovaps [rsp+0xD0], xmm1
00007dd8609d281b  movaps xmm15, xmm12
00007dd8609d281f  mulpd xmm15, xmm13
00007dd8609d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8609d282a  ptest xmm1, xmm1
00007dd8609d282f  jnz 0x00007DD8609D3AE8
00007dd8609d2835  movaps xmm1, xmm12
00007dd8609d2839  mulpd xmm1, xmm10
00007dd8609d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007dd8609d2843  ptest xmm13, xmm13
00007dd8609d2849  jnz 0x00007DD8609D3C2C
00007dd8609d284f  movaps xmm13, xmm12
00007dd8609d2853  mulpd xmm13, xmm2
00007dd8609d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007dd8609d285e  ptest xmm10, xmm10
00007dd8609d2864  jnz 0x00007DD8609D3D6E
00007dd8609d286a  vmovaps [rsp+0x120], xmm7
00007dd8609d2873  vmovaps xmm12, [rsp+0x120]
00007dd8609d287c  por xmm7, xmm12
00007dd8609d2881  vmovaps xmm12, [rsp+0xE0]
00007dd8609d288a  vmovaps xmm10, [rsp+0xE0]
00007dd8609d2893  por xmm12, xmm10
00007dd8609d2898  vmovaps xmm2, [rsp+0x100]
00007dd8609d28a1  vpermilpd xmm2, xmm2, 0x00
00007dd8609d28a7  vmovaps [rsp+0xE0], xmm1
00007dd8609d28b0  vmovaps [rsp+0x120], xmm15
00007dd8609d28b9  movaps xmm1, xmm10
00007dd8609d28bd  mulpd xmm1, xmm2
00007dd8609d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8609d28c6  ptest xmm15, xmm15
00007dd8609d28cc  jnz 0x00007DD8609D3EB1
00007dd8609d28d2  xor eax, eax
00007dd8609d28d4  mov r12d, 0x40
00007dd8609d28da  mov r11d, 0x200
00007dd8609d28e0  cmp r12, r11
00007dd8609d28e3  cmc
00007dd8609d28e4  lahf
00007dd8609d28e5  seto al
00007dd8609d28e8  mov [r15+0x108], eax
00007dd8609d28ef  vmovaps xmm10, [rsp+0x110]
00007dd8609d28f8  vmovaps xmm2, [rsp+0xD0]
00007dd8609d2901  vmovaps [rsp+0xD0], xmm1
00007dd8609d290a  movaps xmm15, xmm10
00007dd8609d290e  addpd xmm15, xmm2
00007dd8609d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8609d2919  ptest xmm1, xmm1
00007dd8609d291e  jnz 0x00007DD8609D3FF2
00007dd8609d2924  vmovaps xmm10, [rsp+0x120]
00007dd8609d292d  vmovaps [rsp+0x110], xmm15
00007dd8609d2936  vmovaps xmm15, [rsp+0xC0]
00007dd8609d293f  vmovaps [rsp+0xC0], xmm14
00007dd8609d2948  movaps xmm1, xmm10
00007dd8609d294c  addpd xmm1, xmm15
00007dd8609d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8609d2956  ptest xmm14, xmm14
00007dd8609d295c  jnz 0x00007DD8609D4135
00007dd8609d2962  vmovaps xmm10, [rsp+0xE0]
00007dd8609d296b  vmovaps [rsp+0xE0], xmm1
00007dd8609d2974  movaps xmm14, xmm10
00007dd8609d2978  addpd xmm14, xmm15
00007dd8609d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd8609d2983  ptest xmm1, xmm1
00007dd8609d2988  jnz 0x00007DD8609D4277
00007dd8609d298e  vmovaps xmm1, [rsp+0x10]
00007dd8609d2994  vmovaps xmm15, [rsp+0x10]
00007dd8609d299a  por xmm1, xmm15
00007dd8609d299f  vmovaps xmm15, [rsp+0x20]
00007dd8609d29a5  vmovaps xmm10, [rsp+0x20]
00007dd8609d29ab  por xmm15, xmm10
00007dd8609d29b0  vmovaps [rsp+0x10], xmm5
00007dd8609d29b6  vmovaps xmm10, [rsp+0x10]
00007dd8609d29bc  por xmm5, xmm10
00007dd8609d29c1  vmovaps [rsp+0x10], xmm11
00007dd8609d29c7  vmovaps xmm10, [rsp+0x10]
00007dd8609d29cd  por xmm11, xmm10
00007dd8609d29d2  vmovaps [rsp+0x10], xmm4
00007dd8609d29d8  vmovaps xmm10, [rsp+0x10]
00007dd8609d29de  por xmm4, xmm10
00007dd8609d29e3  vmovaps [rsp+0x10], xmm8
00007dd8609d29e9  vmovaps xmm10, [rsp+0x10]
00007dd8609d29ef  por xmm8, xmm10
00007dd8609d29f4  vmovaps xmm10, [rsp+0xF0]
00007dd8609d29fd  vmovaps [rsp+0x10], xmm1
00007dd8609d2a03  vmovaps xmm1, [rsp+0xF0]
00007dd8609d2a0c  por xmm10, xmm1
00007dd8609d2a11  lea rax, [r14+0xA0]
00007dd8609d2a18  movups xmm1, [r13+rax*1]
00007dd8609d2a1e  lea rax, [r14+0xB0]
00007dd8609d2a25  vmovaps [rsp+0x20], xmm1
00007dd8609d2a2b  movups xmm1, [r13+rax*1]
00007dd8609d2a31  vmovaps [rsp+0xF0], xmm1
00007dd8609d2a3a  vmovaps [rsp+0x120], xmm15
00007dd8609d2a43  movaps xmm1, xmm13
00007dd8609d2a47  addpd xmm1, xmm2
00007dd8609d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8609d2a50  ptest xmm15, xmm15
00007dd8609d2a56  jnz 0x00007DD8609D43CF
00007dd8609d2a5c  lea rax, [r14+0xF0]
00007dd8609d2a63  movups xmm15, [r13+rax*1]
00007dd8609d2a69  vmovaps xmm2, [rsp+0xE0]
00007dd8609d2a72  vmovaps [rsp+0xE0], xmm1
00007dd8609d2a7b  vmovaps xmm1, [rsp+0xD0]
00007dd8609d2a84  vmovaps [rsp+0xD0], xmm15
00007dd8609d2a8d  movaps xmm13, xmm2
00007dd8609d2a91  addpd xmm13, xmm1
00007dd8609d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007dd8609d2a9c  ptest xmm15, xmm15
00007dd8609d2aa2  jnz 0x00007DD8609D451A
00007dd8609d2aa8  vmovaps xmm15, [rsp+0xC0]
00007dd8609d2ab1  movaps xmm1, xmm14
00007dd8609d2ab5  addpd xmm1, xmm15
00007dd8609d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8609d2abf  ptest xmm2, xmm2
00007dd8609d2ac4  jnz 0x00007DD8609D465C
00007dd8609d2aca  vmovaps xmm15, [rsp+0x100]
00007dd8609d2ad3  vpermilpd xmm15, xmm15, 0x00
00007dd8609d2ad9  vmovaps xmm2, [rsp+0xF0]
00007dd8609d2ae2  vmovaps [rsp+0xC0], xmm1
00007dd8609d2aeb  movaps xmm14, xmm2
00007dd8609d2aef  mulpd xmm14, xmm15
00007dd8609d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd8609d2afa  ptest xmm1, xmm1
00007dd8609d2aff  jnz 0x00007DD8609D479E
00007dd8609d2b05  vmovaps xmm1, [rsp+0xA0]
00007dd8609d2b0e  vpermilpd xmm1, xmm1, 0x00
00007dd8609d2b14  vmovaps xmm2, [rsp+0xD0]
00007dd8609d2b1d  vmovaps [rsp+0xD0], xmm14
00007dd8609d2b26  movaps xmm15, xmm2
00007dd8609d2b2a  mulpd xmm15, xmm1
00007dd8609d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd8609d2b35  ptest xmm14, xmm14
00007dd8609d2b3b  jnz 0x00007DD8609D48E1
00007dd8609d2b41  lea rax, [r14+0xE0]
00007dd8609d2b48  movups xmm1, [r13+rax*1]
00007dd8609d2b4e  vmovaps xmm14, [rsp+0x100]
00007dd8609d2b57  vpermilpd xmm14, xmm14, 0x00
00007dd8609d2b5d  vmovaps [rsp+0xF0], xmm1
00007dd8609d2b66  vmovaps xmm1, [rsp+0x20]
00007dd8609d2b6c  vmovaps [rsp+0x20], xmm15
00007dd8609d2b72  movaps xmm2, xmm1
00007dd8609d2b75  mulpd xmm2, xmm14
00007dd8609d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007dd8609d2b7f  ptest xmm15, xmm15
00007dd8609d2b85  jnz 0x00007DD8609D4A2D
00007dd8609d2b8b  vmovaps [rsp+0x100], xmm10
00007dd8609d2b94  vmovaps xmm1, [rsp+0x100]
00007dd8609d2b9d  por xmm10, xmm1
00007dd8609d2ba2  movaps [r15+0x300], xmm10
00007dd8609d2baa  vmovaps [rsp+0x100], xmm8
00007dd8609d2bb3  vmovaps xmm1, [rsp+0x100]
00007dd8609d2bbc  por xmm8, xmm1
00007dd8609d2bc1  movaps [r15+0x190], xmm8
00007dd8609d2bc9  vmovaps xmm1, [rsp+0xA0]
00007dd8609d2bd2  vpermilpd xmm1, xmm1, 0x00
00007dd8609d2bd8  vmovaps xmm14, [rsp+0xF0]
00007dd8609d2be1  vmovaps [rsp+0xF0], xmm13
00007dd8609d2bea  movaps xmm15, xmm14
00007dd8609d2bee  mulpd xmm15, xmm1
00007dd8609d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd8609d2bf9  ptest xmm13, xmm13
00007dd8609d2bff  jnz 0x00007DD8609D4B6E
00007dd8609d2c05  lea rax, [r14+0x90]
00007dd8609d2c0c  movups xmm1, [r13+rax*1]
00007dd8609d2c12  vmovaps [rsp+0x100], xmm4
00007dd8609d2c1b  vmovaps xmm14, [rsp+0x100]
00007dd8609d2c24  por xmm4, xmm14
00007dd8609d2c29  movaps [r15+0x1C0], xmm4
00007dd8609d2c31  vmovaps [rsp+0x100], xmm11
00007dd8609d2c3a  vmovaps xmm14, [rsp+0x100]
00007dd8609d2c43  por xmm11, xmm14
00007dd8609d2c48  movaps [r15+0x200], xmm11
00007dd8609d2c50  vmovaps [rsp+0x100], xmm5
00007dd8609d2c59  vmovaps xmm14, [rsp+0x100]
00007dd8609d2c62  por xmm5, xmm14
00007dd8609d2c67  movaps [r15+0x2D0], xmm5
00007dd8609d2c6f  vmovaps xmm14, [rsp+0x120]
00007dd8609d2c78  vmovaps xmm13, [rsp+0x120]
00007dd8609d2c81  por xmm14, xmm13
00007dd8609d2c86  movaps [r15+0x2E0], xmm14
00007dd8609d2c8e  vmovaps [rsp+0x100], xmm1
00007dd8609d2c97  vmovaps xmm1, [rsp+0x110]
00007dd8609d2ca0  vmovaps [rsp+0x110], xmm15
00007dd8609d2ca9  vmovaps xmm15, [rsp+0xD0]
00007dd8609d2cb2  vmovaps [rsp+0xD0], xmm14
00007dd8609d2cbb  movaps xmm13, xmm1
00007dd8609d2cbf  addpd xmm13, xmm15
00007dd8609d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007dd8609d2cca  ptest xmm14, xmm14
00007dd8609d2cd0  jnz 0x00007DD8609D4CBB
00007dd8609d2cd6  vmovaps xmm1, [rsp+0xA0]
00007dd8609d2cdf  vpermilpd xmm1, xmm1, 0x00
00007dd8609d2ce5  vmovaps xmm14, [rsp+0x100]
00007dd8609d2cee  vmovaps [rsp+0x100], xmm13
00007dd8609d2cf7  movaps xmm15, xmm14
00007dd8609d2cfb  mulpd xmm15, xmm1
00007dd8609d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd8609d2d06  ptest xmm13, xmm13
00007dd8609d2d0c  jnz 0x00007DD8609D4DFE
00007dd8609d2d12  lea rax, [r14+0x80]
00007dd8609d2d19  movups xmm1, [r13+rax*1]
00007dd8609d2d1f  vmovaps xmm13, [rsp+0xE0]
00007dd8609d2d28  vmovaps [rsp+0xE0], xmm1
00007dd8609d2d31  movaps xmm14, xmm13
00007dd8609d2d35  addpd xmm14, xmm2
00007dd8609d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd8609d2d40  ptest xmm1, xmm1
00007dd8609d2d45  jnz 0x00007DD8609D4F4B
00007dd8609d2d4b  vmovaps xmm13, [rsp+0xF0]
00007dd8609d2d54  vmovaps xmm2, [rsp+0x20]
00007dd8609d2d5a  vmovaps [rsp+0x20], xmm15
00007dd8609d2d60  movaps xmm1, xmm13
00007dd8609d2d64  addpd xmm1, xmm2
00007dd8609d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8609d2d6d  ptest xmm15, xmm15
00007dd8609d2d73  jnz 0x00007DD8609D508E
00007dd8609d2d79  vmovaps xmm15, [rsp+0x10]
00007dd8609d2d7f  vmovaps xmm13, [rsp+0x10]
00007dd8609d2d85  por xmm15, xmm13
00007dd8609d2d8a  movaps [r15+0x2F0], xmm15
00007dd8609d2d92  vmovaps xmm13, [rsp+0xA0]
00007dd8609d2d9b  vpermilpd xmm13, xmm13, 0x00
00007dd8609d2da1  vmovaps [rsp+0x10], xmm1
00007dd8609d2da7  vmovaps xmm1, [rsp+0xE0]
00007dd8609d2db0  vmovaps [rsp+0xA0], xmm15
00007dd8609d2db9  movaps xmm2, xmm1
00007dd8609d2dbc  mulpd xmm2, xmm13
00007dd8609d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007dd8609d2dc6  ptest xmm15, xmm15
00007dd8609d2dcc  jnz 0x00007DD8609D51CF
00007dd8609d2dd2  lea rax, [r14+0xD0]
00007dd8609d2dd9  movups xmm1, [r13+rax*1]
00007dd8609d2ddf  vmovaps xmm13, [rsp+0xC0]
00007dd8609d2de8  vmovaps [rsp+0xC0], xmm1
00007dd8609d2df1  vmovaps xmm1, [rsp+0x110]
00007dd8609d2dfa  vmovaps [rsp+0xE0], xmm14
00007dd8609d2e03  movaps xmm15, xmm13
00007dd8609d2e07  addpd xmm15, xmm1
00007dd8609d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd8609d2e12  ptest xmm14, xmm14
00007dd8609d2e18  jnz 0x00007DD8609D531A
00007dd8609d2e1e  vmovaps xmm1, [rsp+0xB0]
00007dd8609d2e27  vpermilpd xmm1, xmm1, 0x00
00007dd8609d2e2d  movaps xmm14, xmm11
00007dd8609d2e31  mulpd xmm14, xmm1
00007dd8609d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd8609d2e3c  ptest xmm13, xmm13
00007dd8609d2e42  jnz 0x00007DD8609D545D
00007dd8609d2e48  movaps [r15+0x260], xmm14
00007dd8609d2e50  vxorps xmm1, xmm1, xmm1
00007dd8609d2e54  vpbroadcastq xmm1, xmm1
00007dd8609d2e59  movaps [r15+0x1B0], xmm1
00007dd8609d2e61  vmovaps xmm1, [rsp+0xB0]
00007dd8609d2e6a  vpermilpd xmm1, xmm1, 0x00
00007dd8609d2e70  vmovaps xmm11, [rsp+0xC0]
00007dd8609d2e79  vmovaps [rsp+0xC0], xmm15
00007dd8609d2e82  movaps xmm13, xmm11
00007dd8609d2e86  mulpd xmm13, xmm1
00007dd8609d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007dd8609d2e91  ptest xmm15, xmm15
00007dd8609d2e97  jnz 0x00007DD8609D55A0
00007dd8609d2e9d  lea rax, [r14+0xC0]
00007dd8609d2ea4  movups xmm1, [r13+rax*1]
00007dd8609d2eaa  vmovaps xmm11, [rsp+0x100]
00007dd8609d2eb3  vmovaps [rsp+0xF0], xmm1
00007dd8609d2ebc  vmovaps xmm1, [rsp+0x20]
00007dd8609d2ec2  vmovaps [rsp+0x20], xmm14
00007dd8609d2ec8  movaps xmm15, xmm11
00007dd8609d2ecc  addpd xmm15, xmm1
00007dd8609d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007dd8609d2ed7  ptest xmm14, xmm14
00007dd8609d2edd  jnz 0x00007DD8609D56ED
00007dd8609d2ee3  vmovaps [rsp+0x100], xmm9
00007dd8609d2eec  vmovaps xmm1, [rsp+0x100]
00007dd8609d2ef5  por xmm9, xmm1
00007dd8609d2efa  movaps [r15+0x270], xmm9
00007dd8609d2f02  vmovaps [rsp+0x100], xmm6
00007dd8609d2f0b  vmovaps xmm1, [rsp+0x100]
00007dd8609d2f14  por xmm6, xmm1
00007dd8609d2f18  movaps [r15+0x1A0], xmm6
00007dd8609d2f20  vmovaps xmm14, [rsp+0xB0]
00007dd8609d2f29  vpermilpd xmm14, xmm14, 0x00
00007dd8609d2f2f  vmovaps xmm6, [rsp+0xF0]
00007dd8609d2f38  vmovaps [rsp+0xF0], xmm1
00007dd8609d2f41  movaps xmm11, xmm6
00007dd8609d2f45  mulpd xmm11, xmm14
00007dd8609d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007dd8609d2f50  ptest xmm1, xmm1
00007dd8609d2f55  jnz 0x00007DD8609D5830
00007dd8609d2f5b  lea rax, [r14+0x20]
00007dd8609d2f5f  movups xmm1, [r13+rax*1]
00007dd8609d2f65  movaps [r15+0x110], xmm1
00007dd8609d2f6d  vmovaps xmm6, [rsp+0xE0]
00007dd8609d2f76  vmovaps [rsp+0xE0], xmm1
00007dd8609d2f7f  movaps xmm14, xmm6
00007dd8609d2f83  addpd xmm14, xmm2
00007dd8609d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007dd8609d2f8e  ptest xmm1, xmm1
00007dd8609d2f93  jnz 0x00007DD8609D597D
00007dd8609d2f99  vmovaps xmm1, [rsp+0xB0]
00007dd8609d2fa2  vpermilpd xmm1, xmm1, 0x00
00007dd8609d2fa8  movaps xmm6, xmm5
00007dd8609d2fab  mulpd xmm6, xmm1
00007dd8609d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007dd8609d2fb4  ptest xmm2, xmm2
00007dd8609d2fb9  jnz 0x00007DD8609D5ABF
00007dd8609d2fbf  vmovaps xmm5, [rsp+0x10]
00007dd8609d2fc5  movaps xmm1, xmm5
00007dd8609d2fc8  addpd xmm1, xmm13
00007dd8609d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8609d2fd2  ptest xmm2, xmm2
00007dd8609d2fd7  jnz 0x00007DD8609D5BFF
00007dd8609d2fdd  vmovaps xmm13, [rsp+0x80]
00007dd8609d2fe6  vpermilpd xmm13, xmm13, 0x00
00007dd8609d2fec  vmovaps xmm2, [rsp+0xE0]
00007dd8609d2ff5  vmovaps [rsp+0x10], xmm1
00007dd8609d2ffb  movaps xmm5, xmm2
00007dd8609d2ffe  mulpd xmm5, xmm13
00007dd8609d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd8609d3008  ptest xmm1, xmm1
00007dd8609d300d  jnz 0x00007DD8609D5D40
00007dd8609d3013  vmovaps xmm1, [rsp+0x80]
00007dd8609d301c  vpermilpd xmm1, xmm1, 0x00
00007dd8609d3022  movaps xmm13, xmm10
00007dd8609d3026  mulpd xmm13, xmm1
00007dd8609d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007dd8609d3031  ptest xmm2, xmm2
00007dd8609d3036  jnz 0x00007DD8609D5E81
00007dd8609d303c  vmovaps xmm10, [rsp+0x20]
00007dd8609d3042  movaps xmm1, xmm15
00007dd8609d3046  addpd xmm1, xmm10
00007dd8609d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8609d3050  ptest xmm2, xmm2
00007dd8609d3055  jnz 0x00007DD8609D5FC4
00007dd8609d305b  vmovaps xmm10, [rsp+0xC0]
00007dd8609d3064  movaps xmm15, xmm10
00007dd8609d3068  addpd xmm15, xmm11
00007dd8609d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007dd8609d3073  ptest xmm2, xmm2
00007dd8609d3078  jnz 0x00007DD8609D6106
00007dd8609d307e  vmovaps xmm11, [rsp+0x80]
00007dd8609d3087  vpermilpd xmm11, xmm11, 0x00
00007dd8609d308d  vmovaps xmm2, [rsp+0xD0]
00007dd8609d3096  vmovaps [rsp+0x20], xmm1
00007dd8609d309c  movaps xmm10, xmm2
00007dd8609d30a0  mulpd xmm10, xmm11
00007dd8609d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007dd8609d30ab  ptest xmm1, xmm1
00007dd8609d30b0  jnz 0x00007DD8609D624A
00007dd8609d30b6  vmovaps xmm1, [rsp+0x80]
00007dd8609d30bf  vpermilpd xmm1, xmm1, 0x00
00007dd8609d30c5  vmovaps xmm2, [rsp+0xA0]
00007dd8609d30ce  vmovaps [rsp+0x80], xmm15
00007dd8609d30d7  movaps xmm11, xmm2
00007dd8609d30db  mulpd xmm11, xmm1
00007dd8609d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007dd8609d30e6  ptest xmm15, xmm15
00007dd8609d30ec  jnz 0x00007DD8609D638D
00007dd8609d30f2  movaps xmm1, xmm14
00007dd8609d30f6  addpd xmm1, xmm6
00007dd8609d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8609d30ff  ptest xmm15, xmm15
00007dd8609d3105  jnz 0x00007DD8609D64CF
00007dd8609d310b  vmovaps xmm14, [rsp+0x10]
00007dd8609d3111  movaps xmm15, xmm14
00007dd8609d3115  addpd xmm15, xmm5
00007dd8609d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007dd8609d3120  ptest xmm6, xmm6
00007dd8609d3125  jnz 0x00007DD8609D6610
00007dd8609d312b  vmovaps xmm14, [rsp+0x90]
00007dd8609d3134  vpermilpd xmm14, xmm14, 0x00
00007dd8609d313a  movaps xmm6, xmm9
00007dd8609d313e  mulpd xmm6, xmm14
00007dd8609d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8609d3148  ptest xmm5, xmm5
00007dd8609d314d  jnz 0x00007DD8609D6753
00007dd8609d3153  vmovaps xmm9, [rsp+0x80]
00007dd8609d315c  movaps xmm14, xmm9
00007dd8609d3160  addpd xmm14, xmm13
00007dd8609d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007dd8609d316b  ptest xmm5, xmm5
00007dd8609d3170  jnz 0x00007DD8609D6895
00007dd8609d3176  vmovaps xmm9, [rsp+0x20]
00007dd8609d317c  movaps xmm13, xmm9
00007dd8609d3180  addpd xmm13, xmm10
00007dd8609d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007dd8609d318b  ptest xmm5, xmm5
00007dd8609d3190  jnz 0x00007DD8609D69D9
00007dd8609d3196  vmovaps [rsp+0x10], xmm12
00007dd8609d319c  vmovaps xmm10, [rsp+0x10]
00007dd8609d31a2  por xmm12, xmm10
00007dd8609d31a7  movaps [r15+0x250], xmm12
00007dd8609d31af  vmovaps [rsp+0x10], xmm7
00007dd8609d31b5  vmovaps xmm12, [rsp+0x10]
00007dd8609d31bb  por xmm7, xmm12
00007dd8609d31c0  movaps [r15+0x2A0], xmm7
00007dd8609d31c8  vmovaps [rsp+0x10], xmm3
00007dd8609d31ce  vmovaps xmm12, [rsp+0x10]
00007dd8609d31d4  por xmm3, xmm12
00007dd8609d31d9  movaps [r15+0x1D0], xmm3
00007dd8609d31e1  lea rax, [r14+0x40]
00007dd8609d31e5  movups xmm12, [r13+rax*1]
00007dd8609d31eb  movaps [r15+0x2C0], xmm12
00007dd8609d31f3  vmovaps xmm10, [rsp+0x90]
00007dd8609d31fc  vpermilpd xmm10, xmm10, 0x00
00007dd8609d3202  movaps xmm9, xmm8
00007dd8609d3206  mulpd xmm9, xmm10
00007dd8609d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd8609d3211  ptest xmm5, xmm5
00007dd8609d3216  jnz 0x00007DD8609D6B27
00007dd8609d321c  movaps xmm10, xmm1
00007dd8609d3220  addpd xmm10, xmm11
00007dd8609d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd8609d322b  ptest xmm8, xmm8
00007dd8609d3231  jnz 0x00007DD8609D6C6B
00007dd8609d3237  movaps xmm1, xmm15
00007dd8609d323b  addpd xmm1, xmm6
00007dd8609d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007dd8609d3244  ptest xmm11, xmm11
00007dd8609d324a  jnz 0x00007DD8609D6DAE
00007dd8609d3250  vmovaps xmm15, [rsp+0x90]
00007dd8609d3259  vpermilpd xmm15, xmm15, 0x00
00007dd8609d325f  movaps xmm11, xmm12
00007dd8609d3263  mulpd xmm11, xmm15
00007dd8609d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd8609d326e  ptest xmm8, xmm8
00007dd8609d3274  jnz 0x00007DD8609D6EEF
00007dd8609d327a  vmovaps xmm15, [rsp+0x90]
00007dd8609d3283  vpermilpd xmm15, xmm15, 0x00
00007dd8609d3289  vmovaps xmm8, [rsp+0x50]
00007dd8609d328f  movaps xmm12, xmm8
00007dd8609d3293  mulpd xmm12, xmm15
00007dd8609d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007dd8609d329e  ptest xmm6, xmm6
00007dd8609d32a3  jnz 0x00007DD8609D7033
00007dd8609d32a9  vmovaps xmm15, [rsp+0x30]
00007dd8609d32af  vpermilpd xmm15, xmm15, 0x00
00007dd8609d32b5  movaps xmm8, xmm7
00007dd8609d32b9  mulpd xmm8, xmm15
00007dd8609d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8609d32c4  ptest xmm6, xmm6
00007dd8609d32c9  jnz 0x00007DD8609D7177
00007dd8609d32cf  movaps xmm15, xmm14
00007dd8609d32d3  addpd xmm15, xmm9
00007dd8609d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007dd8609d32de  ptest xmm7, xmm7
00007dd8609d32e3  jnz 0x00007DD8609D72BA
00007dd8609d32e9  vmovaps xmm14, [rsp+0x30]
00007dd8609d32ef  vpermilpd xmm14, xmm14, 0x00
00007dd8609d32f5  vmovaps xmm7, [rsp+0xF0]
00007dd8609d32fe  movaps xmm9, xmm7
00007dd8609d3302  mulpd xmm9, xmm14
00007dd8609d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8609d330d  ptest xmm6, xmm6
00007dd8609d3312  jnz 0x00007DD8609D73FE
00007dd8609d3318  movaps xmm14, xmm13
00007dd8609d331c  addpd xmm14, xmm11
00007dd8609d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007dd8609d3327  ptest xmm7, xmm7
00007dd8609d332c  jnz 0x00007DD8609D7541
00007dd8609d3332  vmovaps xmm13, [rsp+0x30]
00007dd8609d3338  vpermilpd xmm13, xmm13, 0x00
00007dd8609d333e  vmovaps xmm7, [rsp+0x60]
00007dd8609d3344  movaps xmm11, xmm7
00007dd8609d3348  mulpd xmm11, xmm13
00007dd8609d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007dd8609d3353  ptest xmm6, xmm6
00007dd8609d3358  jnz 0x00007DD8609D7685
00007dd8609d335e  movaps xmm13, xmm10
00007dd8609d3362  addpd xmm13, xmm12
00007dd8609d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007dd8609d336d  ptest xmm7, xmm7
00007dd8609d3372  jnz 0x00007DD8609D77C8
00007dd8609d3378  vmovaps xmm12, [rsp+0x30]
00007dd8609d337e  vpermilpd xmm12, xmm12, 0x00
00007dd8609d3384  vmovaps xmm7, [rsp+0x70]
00007dd8609d338a  movaps xmm10, xmm7
00007dd8609d338e  mulpd xmm10, xmm12
00007dd8609d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd8609d3399  ptest xmm6, xmm6
00007dd8609d339e  jnz 0x00007DD8609D790C
00007dd8609d33a4  movaps xmm12, xmm1
00007dd8609d33a8  addpd xmm12, xmm8
00007dd8609d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007dd8609d33b3  ptest xmm7, xmm7
00007dd8609d33b8  jnz 0x00007DD8609D7A4F
00007dd8609d33be  lea rax, [r14+0x70]
00007dd8609d33c2  movups xmm1, [r13+rax*1]
00007dd8609d33c8  movaps [r15+0x240], xmm1
00007dd8609d33d0  movaps xmm8, xmm15
00007dd8609d33d4  addpd xmm8, xmm9
00007dd8609d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8609d33df  ptest xmm7, xmm7
00007dd8609d33e4  jnz 0x00007DD8609D7B9C
00007dd8609d33ea  movaps [r15+0x170], xmm8
00007dd8609d33f2  vmovaps xmm15, [rsp+0x40]
00007dd8609d33f8  vpermilpd xmm15, xmm15, 0x00
00007dd8609d33fe  movaps xmm9, xmm1
00007dd8609d3402  mulpd xmm9, xmm15
00007dd8609d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007dd8609d340d  ptest xmm7, xmm7
00007dd8609d3412  jnz 0x00007DD8609D7CE0
00007dd8609d3418  vmovaps xmm1, [rsp+0x40]
00007dd8609d341e  vpermilpd xmm1, xmm1, 0x00
00007dd8609d3424  movaps xmm15, xmm4
00007dd8609d3428  mulpd xmm15, xmm1
00007dd8609d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007dd8609d3433  ptest xmm7, xmm7
00007dd8609d3438  jnz 0x00007DD8609D7E23
00007dd8609d343e  movaps [r15+0x180], xmm15
00007dd8609d3446  movaps xmm1, xmm14
00007dd8609d344a  addpd xmm1, xmm11
00007dd8609d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007dd8609d3454  ptest xmm7, xmm7
00007dd8609d3459  jnz 0x00007DD8609D7F65
00007dd8609d345f  movaps [r15+0x210], xmm1
00007dd8609d3467  movups xmm14, [r13+r14*1]
00007dd8609d346d  lea rax, [r14+0x10]
00007dd8609d3471  movups xmm11, [r13+rax*1]
00007dd8609d3477  movaps [r15+0x230], xmm11
00007dd8609d347f  movaps xmm7, xmm13
00007dd8609d3483  addpd xmm7, xmm10
00007dd8609d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8609d348d  ptest xmm6, xmm6
00007dd8609d3492  jnz 0x00007DD8609D80BB
00007dd8609d3498  movaps [r15+0x130], xmm7
00007dd8609d34a0  vmovaps xmm13, [rsp+0x40]
00007dd8609d34a6  vpermilpd xmm13, xmm13, 0x00
00007dd8609d34ac  movaps xmm10, xmm11
00007dd8609d34b0  mulpd xmm10, xmm13
00007dd8609d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd8609d34bb  ptest xmm6, xmm6
00007dd8609d34c0  jnz 0x00007DD8609D81FD
00007dd8609d34c6  movaps [r15+0x220], xmm10
00007dd8609d34ce  vmovaps xmm13, [rsp+0x40]
00007dd8609d34d4  vpermilpd xmm13, xmm13, 0x00
00007dd8609d34da  movaps xmm11, xmm14
00007dd8609d34de  mulpd xmm11, xmm13
00007dd8609d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007dd8609d34e9  ptest xmm6, xmm6
00007dd8609d34ee  jnz 0x00007DD8609D8341
00007dd8609d34f4  movaps xmm14, xmm12
00007dd8609d34f8  addpd xmm14, xmm9
00007dd8609d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007dd8609d3503  ptest xmm13, xmm13
00007dd8609d3509  jnz 0x00007DD8609D8485
00007dd8609d350f  movaps [r15+0x140], xmm14
00007dd8609d3517  movaps xmm13, xmm8
00007dd8609d351b  addpd xmm13, xmm15
00007dd8609d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd8609d3526  ptest xmm12, xmm12
00007dd8609d352c  jnz 0x00007DD8609D85C9
00007dd8609d3532  movaps [r15+0x150], xmm13
00007dd8609d353a  movaps xmm15, xmm1
00007dd8609d353e  addpd xmm15, xmm10
00007dd8609d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007dd8609d3549  ptest xmm12, xmm12
00007dd8609d354f  jnz 0x00007DD8609D870D
00007dd8609d3555  movaps [r15+0x160], xmm15
00007dd8609d355d  movaps xmm1, xmm7
00007dd8609d3560  addpd xmm1, xmm11
00007dd8609d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8609d356a  ptest xmm12, xmm12
00007dd8609d3570  jnz 0x00007DD8609D8850
00007dd8609d3576  movaps [r15+0x120], xmm1
00007dd8609d357e  mov eax, 0x432200
00007dd8609d3583  movups [r13+rax*1], xmm14
00007dd8609d3589  mov eax, 0x432210
00007dd8609d358e  movups [r13+rax*1], xmm13
00007dd8609d3594  mov eax, 0x432220
00007dd8609d3599  movups [r13+rax*1], xmm15
00007dd8609d359f  mov eax, 0x432230
00007dd8609d35a4  movups [r13+rax*1], xmm1
00007dd8609d35aa  mov eax, [r15+0x108]
00007dd8609d35b1  sahf
00007dd8609d35b2  jnz 0x00007DD8609D35E4
00007dd8609d35b4  cmp dword ptr [r15+0x318], 0x00
00007dd8609d35bc  jz 0x00007DD8609DEAE0
00007dd8609d35c2  nop [rax+rax*1], ax
00007dd8609d35cb  nop [rax+rax*1], eax
00007dd8609d35d3  mov eax, 0x4106D0
00007dd8609d35d8  mov [r15+0x100], rax
00007dd8609d35df  jmp 0x00007DD8607FE110
00007dd8609d35e4  cmp dword ptr [r15+0x318], 0x00
00007dd8609d35ec  jz 0x00007DD8609D89C0
00007dd8609d35f2  nop [rax+rax*1], ax
00007dd8609d35fb  nop [rax+rax*1], eax
00007dd8609d3603  mov eax, 0x410504
00007dd8609d3608  mov [r15+0x100], rax
00007dd8609d360f  jmp 0x00007DD8607FE110
00007dd8609d3614  int3
00007dd8609d3615  call 0x00007DD8608D64F0
00007dd8609d361a  jmp 0x00007DD8609D2311
00007dd8609d361f  call 0x00007DD8608E5820
00007dd8609d3624  jmp 0x00007DD8609D231E
00007dd8609d3629  call 0x00007DD8608E3320
00007dd8609d362e  jmp 0x00007DD8609D2332
00007dd8609d3633  call 0x00007DD8608E20A0
00007dd8609d3638  jmp 0x00007DD8609D233C
00007dd8609d363d  call 0x00007DD860809D70
00007dd8609d3642  jmp 0x00007DD8609D234A
00007dd8609d3647  call 0x00007DD8608DFBC0
00007dd8609d364c  jmp 0x00007DD8609D2354
00007dd8609d3651  call 0x00007DD8608C4740
00007dd8609d3656  jmp 0x00007DD8609D2368
00007dd8609d365b  call 0x00007DD8608B5400
00007dd8609d3660  jmp 0x00007DD8609D2375
00007dd8609d3665  call 0x00007DD8608B52F0
00007dd8609d366a  jmp 0x00007DD8609D2382
00007dd8609d366f  call 0x00007DD8608C4620
00007dd8609d3674  jmp 0x00007DD8609D238F
00007dd8609d3679  call 0x00007DD8608BD750
00007dd8609d367e  jmp 0x00007DD8609D239C
00007dd8609d3683  call 0x00007DD8608BC4E0
00007dd8609d3688  jmp 0x00007DD8609D23A9
00007dd8609d368d  call 0x00007DD8608BB270
00007dd8609d3692  jmp 0x00007DD8609D23B6
00007dd8609d3697  call 0x00007DD8608BA000
00007dd8609d369c  jmp 0x00007DD8609D23C3
00007dd8609d36a1  call 0x00007DD8608C4740
00007dd8609d36a6  jmp 0x00007DD8609D23D0
00007dd8609d36ab  call 0x00007DD8608B5400
00007dd8609d36b0  jmp 0x00007DD8609D23DD
00007dd8609d36b5  call 0x00007DD8608B52F0
00007dd8609d36ba  jmp 0x00007DD8609D23EA
00007dd8609d36bf  call 0x00007DD8608C4620
00007dd8609d36c4  jmp 0x00007DD8609D23F7
00007dd8609d36c9  call 0x00007DD8608B8D90
00007dd8609d36ce  jmp 0x00007DD8609D2404
00007dd8609d36d3  call 0x00007DD8608B8A20
00007dd8609d36d8  jmp 0x00007DD8609D2411
00007dd8609d36dd  call 0x00007DD8608B77B0
00007dd8609d36e2  jmp 0x00007DD8609D241B
00007dd8609d36e7  call 0x00007DD8608B6550
00007dd8609d36ec  jmp 0x00007DD8609D2425
00007dd8609d36f1  call 0x00007DD8608B5400
00007dd8609d36f6  jmp 0x00007DD8609D2437
00007dd8609d36fb  call 0x00007DD8608C0FC0
00007dd8609d3700  jmp 0x00007DD8609D2441
00007dd8609d3705  call 0x00007DD8608B52F0
00007dd8609d370a  jmp 0x00007DD8609D244B
00007dd8609d370f  call 0x00007DD8608C0EA0
00007dd8609d3714  jmp 0x00007DD8609D2455
00007dd8609d3719  call 0x00007DD8608BFD50
00007dd8609d371e  jmp 0x00007DD8609D245F
00007dd8609d3723  call 0x00007DD8608B8EA0
00007dd8609d3728  jmp 0x00007DD8609D2469
00007dd8609d372d  call 0x00007DD8608BFC30
00007dd8609d3732  jmp 0x00007DD8609D2476
00007dd8609d3737  call 0x00007DD8608B8D90
00007dd8609d373c  jmp 0x00007DD8609D2483
00007dd8609d3741  call 0x00007DD8608B52F0
00007dd8609d3746  jmp 0x00007DD8609D2496
00007dd8609d374b  call 0x00007DD8608B52F0
00007dd8609d3750  jmp 0x00007DD8609D24A9
00007dd8609d3755  call 0x00007DD8608C0FC0
00007dd8609d375a  jmp 0x00007DD8609D24B6
00007dd8609d375f  call 0x00007DD8608C0FC0
00007dd8609d3764  jmp 0x00007DD8609D24C9
00007dd8609d3769  call 0x00007DD8608C0EA0
00007dd8609d376e  jmp 0x00007DD8609D24D6
00007dd8609d3773  call 0x00007DD8608B52F0
00007dd8609d3778  jmp 0x00007DD8609D24E9
00007dd8609d377d  call 0x00007DD8608B52F0
00007dd8609d3782  jmp 0x00007DD8609D24FC
00007dd8609d3787  call 0x00007DD8608B52F0
00007dd8609d378c  jmp 0x00007DD8609D250F
00007dd8609d3791  call 0x00007DD8608B52F0
00007dd8609d3796  jmp 0x00007DD8609D252A
00007dd8609d379b  call 0x00007DD8608B52F0
00007dd8609d37a0  jmp 0x00007DD8609D253D
00007dd8609d37a5  call 0x00007DD8608B5400
00007dd8609d37aa  jmp 0x00007DD8609D257E
00007dd8609d37af  call 0x00007DD8608C0FC0
00007dd8609d37b4  jmp 0x00007DD8609D258B
00007dd8609d37b9  call 0x00007DD8608B52F0
00007dd8609d37be  jmp 0x00007DD8609D2598
00007dd8609d37c3  call 0x00007DD8608C0EA0
00007dd8609d37c8  jmp 0x00007DD8609D25A5
00007dd8609d37cd  call 0x00007DD8607FF540
00007dd8609d37d2  jmp 0x00007DD8609D25C3
00007dd8609d37d7  call 0x00007DD860808C20
00007dd8609d37dc  jmp 0x00007DD8609D25CD
00007dd8609d37e1  call 0x00007DD8608E21C0
00007dd8609d37e6  jmp 0x00007DD8609D25D3
00007dd8609d37eb  call 0x00007DD8607FF540
00007dd8609d37f0  jmp 0x00007DD8609D25E3
00007dd8609d37f5  call 0x00007DD8608C0370
00007dd8609d37fa  jmp 0x00007DD8609D2611
00007dd8609d37ff  call 0x00007DD8608BF100
00007dd8609d3804  jmp 0x00007DD8609D261A
00007dd8609d3809  call 0x00007DD8608C0370
00007dd8609d380e  jmp 0x00007DD8609D2674
00007dd8609d3813  call 0x00007DD8608BF100
00007dd8609d3818  jmp 0x00007DD8609D267D
00007dd8609d381d  call 0x00007DD8608C0370
00007dd8609d3822  jmp 0x00007DD8609D26C6
00007dd8609d3827  call 0x00007DD8608BF100
00007dd8609d382c  jmp 0x00007DD8609D26CF
00007dd8609d3831  call 0x00007DD86080B720
00007dd8609d3836  jmp 0x00007DD8609D2714
00007dd8609d383b  call 0x00007DD8608B47C0
00007dd8609d3840  jmp 0x00007DD8609D2727
00007dd8609d3845  call 0x00007DD860808B00
00007dd8609d384a  jmp 0x00007DD8609D273E
00007dd8609d384f  call 0x00007DD8607FF430
00007dd8609d3854  jmp 0x00007DD8609D2751
00007dd8609d3859  call 0x00007DD8607FF430
00007dd8609d385e  jmp 0x00007DD8609D2764
00007dd8609d3863  sub rsp, 0x08
00007dd8609d3867  push rax
00007dd8609d3868  push rcx
00007dd8609d3869  push rdx
00007dd8609d386a  push rdi
00007dd8609d386b  push rsi
00007dd8609d386c  push r8
00007dd8609d386e  push r9
00007dd8609d3870  push r10
00007dd8609d3872  push r11
00007dd8609d3874  sub rsp, 0xF0
00007dd8609d387b  vmovaps [rsp], xmm0
00007dd8609d3880  vmovaps [rsp+0x10], xmm2
00007dd8609d3886  vmovaps [rsp+0x20], xmm3
00007dd8609d388c  vmovaps [rsp+0x30], xmm4
00007dd8609d3892  vmovaps [rsp+0x40], xmm5
00007dd8609d3898  vmovaps [rsp+0x50], xmm6
00007dd8609d389e  vmovaps [rsp+0x60], xmm7
00007dd8609d38a4  vmovaps [rsp+0x70], xmm8
00007dd8609d38aa  vmovaps [rsp+0x80], xmm9
00007dd8609d38b3  vmovaps [rsp+0x90], xmm10
00007dd8609d38bc  vmovaps [rsp+0xA0], xmm11
00007dd8609d38c5  vmovaps [rsp+0xB0], xmm12
00007dd8609d38ce  vmovaps [rsp+0xC0], xmm13
00007dd8609d38d7  vmovaps [rsp+0xD0], xmm14
00007dd8609d38e0  vmovaps [rsp+0xE0], xmm15
00007dd8609d38e9  sub rsp, 0x30
00007dd8609d38ed  movaps [rsp], xmm1
00007dd8609d38f1  movaps [rsp+0x10], xmm12
00007dd8609d38f7  movaps [rsp+0x20], xmm15
00007dd8609d38fd  lea rdi, [rsp]
00007dd8609d3901  mov esi, 0x00
00007dd8609d3906  mov rax, 0x629C9CFA9530
00007dd8609d3910  call rax
00007dd8609d3912  movaps xmm1, [rsp]
00007dd8609d3916  add rsp, 0x30
00007dd8609d391a  vmovaps xmm0, [rsp]
00007dd8609d391f  vmovaps xmm2, [rsp+0x10]
00007dd8609d3925  vmovaps xmm3, [rsp+0x20]
00007dd8609d392b  vmovaps xmm4, [rsp+0x30]
00007dd8609d3931  vmovaps xmm5, [rsp+0x40]
00007dd8609d3937  vmovaps xmm6, [rsp+0x50]
00007dd8609d393d  vmovaps xmm7, [rsp+0x60]
00007dd8609d3943  vmovaps xmm8, [rsp+0x70]
00007dd8609d3949  vmovaps xmm9, [rsp+0x80]
00007dd8609d3952  vmovaps xmm10, [rsp+0x90]
00007dd8609d395b  vmovaps xmm11, [rsp+0xA0]
00007dd8609d3964  vmovaps xmm12, [rsp+0xB0]
00007dd8609d396d  vmovaps xmm13, [rsp+0xC0]
00007dd8609d3976  vmovaps xmm14, [rsp+0xD0]
00007dd8609d397f  vmovaps xmm15, [rsp+0xE0]
00007dd8609d3988  add rsp, 0xF0
00007dd8609d398f  pop r11
00007dd8609d3991  pop r10
00007dd8609d3993  pop r9
00007dd8609d3995  pop r8
00007dd8609d3997  pop rsi
00007dd8609d3998  pop rdi
00007dd8609d3999  pop rdx
00007dd8609d399a  pop rcx
00007dd8609d399b  pop rax
00007dd8609d399c  add rsp, 0x08
00007dd8609d39a0  jmp 0x00007DD8609D27B2
00007dd8609d39a5  sub rsp, 0x08
00007dd8609d39a9  push rax
00007dd8609d39aa  push rcx
00007dd8609d39ab  push rdx
00007dd8609d39ac  push rdi
00007dd8609d39ad  push rsi
00007dd8609d39ae  push r8
00007dd8609d39b0  push r9
00007dd8609d39b2  push r10
00007dd8609d39b4  push r11
00007dd8609d39b6  sub rsp, 0xF0
00007dd8609d39bd  vmovaps [rsp], xmm0
00007dd8609d39c2  vmovaps [rsp+0x10], xmm1
00007dd8609d39c8  vmovaps [rsp+0x20], xmm2
00007dd8609d39ce  vmovaps [rsp+0x30], xmm3
00007dd8609d39d4  vmovaps [rsp+0x40], xmm4
00007dd8609d39da  vmovaps [rsp+0x50], xmm5
00007dd8609d39e0  vmovaps [rsp+0x60], xmm6
00007dd8609d39e6  vmovaps [rsp+0x70], xmm7
00007dd8609d39ec  vmovaps [rsp+0x80], xmm8
00007dd8609d39f5  vmovaps [rsp+0x90], xmm9
00007dd8609d39fe  vmovaps [rsp+0xA0], xmm10
00007dd8609d3a07  vmovaps [rsp+0xB0], xmm11
00007dd8609d3a10  vmovaps [rsp+0xC0], xmm12
00007dd8609d3a19  vmovaps [rsp+0xD0], xmm13
00007dd8609d3a22  vmovaps [rsp+0xE0], xmm15
00007dd8609d3a2b  sub rsp, 0x30
00007dd8609d3a2f  movaps [rsp], xmm14
00007dd8609d3a34  movaps [rsp+0x10], xmm1
00007dd8609d3a39  movaps [rsp+0x20], xmm15
00007dd8609d3a3f  lea rdi, [rsp]
00007dd8609d3a43  mov esi, 0x00
00007dd8609d3a48  mov rax, 0x629C9CFA9530
00007dd8609d3a52  call rax
00007dd8609d3a54  movaps xmm14, [rsp]
00007dd8609d3a59  add rsp, 0x30
00007dd8609d3a5d  vmovaps xmm0, [rsp]
00007dd8609d3a62  vmovaps xmm1, [rsp+0x10]
00007dd8609d3a68  vmovaps xmm2, [rsp+0x20]
00007dd8609d3a6e  vmovaps xmm3, [rsp+0x30]
00007dd8609d3a74  vmovaps xmm4, [rsp+0x40]
00007dd8609d3a7a  vmovaps xmm5, [rsp+0x50]
00007dd8609d3a80  vmovaps xmm6, [rsp+0x60]
00007dd8609d3a86  vmovaps xmm7, [rsp+0x70]
00007dd8609d3a8c  vmovaps xmm8, [rsp+0x80]
00007dd8609d3a95  vmovaps xmm9, [rsp+0x90]
00007dd8609d3a9e  vmovaps xmm10, [rsp+0xA0]
00007dd8609d3aa7  vmovaps xmm11, [rsp+0xB0]
00007dd8609d3ab0  vmovaps xmm12, [rsp+0xC0]
00007dd8609d3ab9  vmovaps xmm13, [rsp+0xD0]
00007dd8609d3ac2  vmovaps xmm15, [rsp+0xE0]
00007dd8609d3acb  add rsp, 0xF0
00007dd8609d3ad2  pop r11
00007dd8609d3ad4  pop r10
00007dd8609d3ad6  pop r9
00007dd8609d3ad8  pop r8
00007dd8609d3ada  pop rsi
00007dd8609d3adb  pop rdi
00007dd8609d3adc  pop rdx
00007dd8609d3add  pop rcx
00007dd8609d3ade  pop rax
00007dd8609d3adf  add rsp, 0x08
00007dd8609d3ae3  jmp 0x00007DD8609D2800
00007dd8609d3ae8  sub rsp, 0x08
00007dd8609d3aec  push rax
00007dd8609d3aed  push rcx
00007dd8609d3aee  push rdx
00007dd8609d3aef  push rdi
00007dd8609d3af0  push rsi
00007dd8609d3af1  push r8
00007dd8609d3af3  push r9
00007dd8609d3af5  push r10
00007dd8609d3af7  push r11
00007dd8609d3af9  sub rsp, 0xF0
00007dd8609d3b00  vmovaps [rsp], xmm0
00007dd8609d3b05  vmovaps [rsp+0x10], xmm1
00007dd8609d3b0b  vmovaps [rsp+0x20], xmm2
00007dd8609d3b11  vmovaps [rsp+0x30], xmm3
00007dd8609d3b17  vmovaps [rsp+0x40], xmm4
00007dd8609d3b1d  vmovaps [rsp+0x50], xmm5
00007dd8609d3b23  vmovaps [rsp+0x60], xmm6
00007dd8609d3b29  vmovaps [rsp+0x70], xmm7
00007dd8609d3b2f  vmovaps [rsp+0x80], xmm8
00007dd8609d3b38  vmovaps [rsp+0x90], xmm9
00007dd8609d3b41  vmovaps [rsp+0xA0], xmm10
00007dd8609d3b4a  vmovaps [rsp+0xB0], xmm11
00007dd8609d3b53  vmovaps [rsp+0xC0], xmm12
00007dd8609d3b5c  vmovaps [rsp+0xD0], xmm13
00007dd8609d3b65  vmovaps [rsp+0xE0], xmm14
00007dd8609d3b6e  sub rsp, 0x30
00007dd8609d3b72  movaps [rsp], xmm15
00007dd8609d3b77  movaps [rsp+0x10], xmm12
00007dd8609d3b7d  movaps [rsp+0x20], xmm13
00007dd8609d3b83  lea rdi, [rsp]
00007dd8609d3b87  mov esi, 0x00
00007dd8609d3b8c  mov rax, 0x629C9CFA9530
00007dd8609d3b96  call rax
00007dd8609d3b98  movaps xmm15, [rsp]
00007dd8609d3b9d  add rsp, 0x30
00007dd8609d3ba1  vmovaps xmm0, [rsp]
00007dd8609d3ba6  vmovaps xmm1, [rsp+0x10]
00007dd8609d3bac  vmovaps xmm2, [rsp+0x20]
00007dd8609d3bb2  vmovaps xmm3, [rsp+0x30]
00007dd8609d3bb8  vmovaps xmm4, [rsp+0x40]
00007dd8609d3bbe  vmovaps xmm5, [rsp+0x50]
00007dd8609d3bc4  vmovaps xmm6, [rsp+0x60]
00007dd8609d3bca  vmovaps xmm7, [rsp+0x70]
00007dd8609d3bd0  vmovaps xmm8, [rsp+0x80]
00007dd8609d3bd9  vmovaps xmm9, [rsp+0x90]
00007dd8609d3be2  vmovaps xmm10, [rsp+0xA0]
00007dd8609d3beb  vmovaps xmm11, [rsp+0xB0]
00007dd8609d3bf4  vmovaps xmm12, [rsp+0xC0]
00007dd8609d3bfd  vmovaps xmm13, [rsp+0xD0]
00007dd8609d3c06  vmovaps xmm14, [rsp+0xE0]
00007dd8609d3c0f  add rsp, 0xF0
00007dd8609d3c16  pop r11
00007dd8609d3c18  pop r10
00007dd8609d3c1a  pop r9
00007dd8609d3c1c  pop r8
00007dd8609d3c1e  pop rsi
00007dd8609d3c1f  pop rdi
00007dd8609d3c20  pop rdx
00007dd8609d3c21  pop rcx
00007dd8609d3c22  pop rax
00007dd8609d3c23  add rsp, 0x08
00007dd8609d3c27  jmp 0x00007DD8609D2835
00007dd8609d3c2c  sub rsp, 0x08
00007dd8609d3c30  push rax
00007dd8609d3c31  push rcx
00007dd8609d3c32  push rdx
00007dd8609d3c33  push rdi
00007dd8609d3c34  push rsi
00007dd8609d3c35  push r8
00007dd8609d3c37  push r9
00007dd8609d3c39  push r10
00007dd8609d3c3b  push r11
00007dd8609d3c3d  sub rsp, 0xF0
00007dd8609d3c44  vmovaps [rsp], xmm0
00007dd8609d3c49  vmovaps [rsp+0x10], xmm2
00007dd8609d3c4f  vmovaps [rsp+0x20], xmm3
00007dd8609d3c55  vmovaps [rsp+0x30], xmm4
00007dd8609d3c5b  vmovaps [rsp+0x40], xmm5
00007dd8609d3c61  vmovaps [rsp+0x50], xmm6
00007dd8609d3c67  vmovaps [rsp+0x60], xmm7
00007dd8609d3c6d  vmovaps [rsp+0x70], xmm8
00007dd8609d3c73  vmovaps [rsp+0x80], xmm9
00007dd8609d3c7c  vmovaps [rsp+0x90], xmm10
00007dd8609d3c85  vmovaps [rsp+0xA0], xmm11
00007dd8609d3c8e  vmovaps [rsp+0xB0], xmm12
00007dd8609d3c97  vmovaps [rsp+0xC0], xmm13
00007dd8609d3ca0  vmovaps [rsp+0xD0], xmm14
00007dd8609d3ca9  vmovaps [rsp+0xE0], xmm15
00007dd8609d3cb2  sub rsp, 0x30
00007dd8609d3cb6  movaps [rsp], xmm1
00007dd8609d3cba  movaps [rsp+0x10], xmm12
00007dd8609d3cc0  movaps [rsp+0x20], xmm10
00007dd8609d3cc6  lea rdi, [rsp]
00007dd8609d3cca  mov esi, 0x00
00007dd8609d3ccf  mov rax, 0x629C9CFA9530
00007dd8609d3cd9  call rax
00007dd8609d3cdb  movaps xmm1, [rsp]
00007dd8609d3cdf  add rsp, 0x30
00007dd8609d3ce3  vmovaps xmm0, [rsp]
00007dd8609d3ce8  vmovaps xmm2, [rsp+0x10]
00007dd8609d3cee  vmovaps xmm3, [rsp+0x20]
00007dd8609d3cf4  vmovaps xmm4, [rsp+0x30]
00007dd8609d3cfa  vmovaps xmm5, [rsp+0x40]
00007dd8609d3d00  vmovaps xmm6, [rsp+0x50]
00007dd8609d3d06  vmovaps xmm7, [rsp+0x60]
00007dd8609d3d0c  vmovaps xmm8, [rsp+0x70]
00007dd8609d3d12  vmovaps xmm9, [rsp+0x80]
00007dd8609d3d1b  vmovaps xmm10, [rsp+0x90]
00007dd8609d3d24  vmovaps xmm11, [rsp+0xA0]
00007dd8609d3d2d  vmovaps xmm12, [rsp+0xB0]
00007dd8609d3d36  vmovaps xmm13, [rsp+0xC0]
00007dd8609d3d3f  vmovaps xmm14, [rsp+0xD0]
00007dd8609d3d48  vmovaps xmm15, [rsp+0xE0]
00007dd8609d3d51  add rsp, 0xF0
00007dd8609d3d58  pop r11
00007dd8609d3d5a  pop r10
00007dd8609d3d5c  pop r9
00007dd8609d3d5e  pop r8
00007dd8609d3d60  pop rsi
00007dd8609d3d61  pop rdi
00007dd8609d3d62  pop rdx
00007dd8609d3d63  pop rcx
00007dd8609d3d64  pop rax
00007dd8609d3d65  add rsp, 0x08
00007dd8609d3d69  jmp 0x00007DD8609D284F
00007dd8609d3d6e  sub rsp, 0x08
00007dd8609d3d72  push rax
00007dd8609d3d73  push rcx
00007dd8609d3d74  push rdx
00007dd8609d3d75  push rdi
00007dd8609d3d76  push rsi
00007dd8609d3d77  push r8
00007dd8609d3d79  push r9
00007dd8609d3d7b  push r10
00007dd8609d3d7d  push r11
00007dd8609d3d7f  sub rsp, 0xF0
00007dd8609d3d86  vmovaps [rsp], xmm0
00007dd8609d3d8b  vmovaps [rsp+0x10], xmm1
00007dd8609d3d91  vmovaps [rsp+0x20], xmm2
00007dd8609d3d97  vmovaps [rsp+0x30], xmm3
00007dd8609d3d9d  vmovaps [rsp+0x40], xmm4
00007dd8609d3da3  vmovaps [rsp+0x50], xmm5
00007dd8609d3da9  vmovaps [rsp+0x60], xmm6
00007dd8609d3daf  vmovaps [rsp+0x70], xmm7
00007dd8609d3db5  vmovaps [rsp+0x80], xmm8
00007dd8609d3dbe  vmovaps [rsp+0x90], xmm9
00007dd8609d3dc7  vmovaps [rsp+0xA0], xmm10
00007dd8609d3dd0  vmovaps [rsp+0xB0], xmm11
00007dd8609d3dd9  vmovaps [rsp+0xC0], xmm12
00007dd8609d3de2  vmovaps [rsp+0xD0], xmm14
00007dd8609d3deb  vmovaps [rsp+0xE0], xmm15
00007dd8609d3df4  sub rsp, 0x30
00007dd8609d3df8  movaps [rsp], xmm13
00007dd8609d3dfd  movaps [rsp+0x10], xmm12
00007dd8609d3e03  movaps [rsp+0x20], xmm2
00007dd8609d3e08  lea rdi, [rsp]
00007dd8609d3e0c  mov esi, 0x00
00007dd8609d3e11  mov rax, 0x629C9CFA9530
00007dd8609d3e1b  call rax
00007dd8609d3e1d  movaps xmm13, [rsp]
00007dd8609d3e22  add rsp, 0x30
00007dd8609d3e26  vmovaps xmm0, [rsp]
00007dd8609d3e2b  vmovaps xmm1, [rsp+0x10]
00007dd8609d3e31  vmovaps xmm2, [rsp+0x20]
00007dd8609d3e37  vmovaps xmm3, [rsp+0x30]
00007dd8609d3e3d  vmovaps xmm4, [rsp+0x40]
00007dd8609d3e43  vmovaps xmm5, [rsp+0x50]
00007dd8609d3e49  vmovaps xmm6, [rsp+0x60]
00007dd8609d3e4f  vmovaps xmm7, [rsp+0x70]
00007dd8609d3e55  vmovaps xmm8, [rsp+0x80]
00007dd8609d3e5e  vmovaps xmm9, [rsp+0x90]
00007dd8609d3e67  vmovaps xmm10, [rsp+0xA0]
00007dd8609d3e70  vmovaps xmm11, [rsp+0xB0]
00007dd8609d3e79  vmovaps xmm12, [rsp+0xC0]
00007dd8609d3e82  vmovaps xmm14, [rsp+0xD0]
00007dd8609d3e8b  vmovaps xmm15, [rsp+0xE0]
00007dd8609d3e94  add rsp, 0xF0
00007dd8609d3e9b  pop r11
00007dd8609d3e9d  pop r10
00007dd8609d3e9f  pop r9
00007dd8609d3ea1  pop r8
00007dd8609d3ea3  pop rsi
00007dd8609d3ea4  pop rdi
00007dd8609d3ea5  pop rdx
00007dd8609d3ea6  pop rcx
00007dd8609d3ea7  pop rax
00007dd8609d3ea8  add rsp, 0x08
00007dd8609d3eac  jmp 0x00007DD8609D286A
00007dd8609d3eb1  sub rsp, 0x08
00007dd8609d3eb5  push rax
00007dd8609d3eb6  push rcx
00007dd8609d3eb7  push rdx
00007dd8609d3eb8  push rdi
00007dd8609d3eb9  push rsi
00007dd8609d3eba  push r8
00007dd8609d3ebc  push r9
00007dd8609d3ebe  push r10
00007dd8609d3ec0  push r11
00007dd8609d3ec2  sub rsp, 0xF0
00007dd8609d3ec9  vmovaps [rsp], xmm0
00007dd8609d3ece  vmovaps [rsp+0x10], xmm2
00007dd8609d3ed4  vmovaps [rsp+0x20], xmm3
00007dd8609d3eda  vmovaps [rsp+0x30], xmm4
00007dd8609d3ee0  vmovaps [rsp+0x40], xmm5
00007dd8609d3ee6  vmovaps [rsp+0x50], xmm6
00007dd8609d3eec  vmovaps [rsp+0x60], xmm7
00007dd8609d3ef2  vmovaps [rsp+0x70], xmm8
00007dd8609d3ef8  vmovaps [rsp+0x80], xmm9
00007dd8609d3f01  vmovaps [rsp+0x90], xmm10
00007dd8609d3f0a  vmovaps [rsp+0xA0], xmm11
00007dd8609d3f13  vmovaps [rsp+0xB0], xmm12
00007dd8609d3f1c  vmovaps [rsp+0xC0], xmm13
00007dd8609d3f25  vmovaps [rsp+0xD0], xmm14
00007dd8609d3f2e  vmovaps [rsp+0xE0], xmm15
00007dd8609d3f37  sub rsp, 0x30
00007dd8609d3f3b  movaps [rsp], xmm1
00007dd8609d3f3f  movaps [rsp+0x10], xmm10
00007dd8609d3f45  movaps [rsp+0x20], xmm2
00007dd8609d3f4a  lea rdi, [rsp]
00007dd8609d3f4e  mov esi, 0x00
00007dd8609d3f53  mov rax, 0x629C9CFA9530
00007dd8609d3f5d  call rax
00007dd8609d3f5f  movaps xmm1, [rsp]
00007dd8609d3f63  add rsp, 0x30
00007dd8609d3f67  vmovaps xmm0, [rsp]
00007dd8609d3f6c  vmovaps xmm2, [rsp+0x10]
00007dd8609d3f72  vmovaps xmm3, [rsp+0x20]
00007dd8609d3f78  vmovaps xmm4, [rsp+0x30]
00007dd8609d3f7e  vmovaps xmm5, [rsp+0x40]
00007dd8609d3f84  vmovaps xmm6, [rsp+0x50]
00007dd8609d3f8a  vmovaps xmm7, [rsp+0x60]
00007dd8609d3f90  vmovaps xmm8, [rsp+0x70]
00007dd8609d3f96  vmovaps xmm9, [rsp+0x80]
00007dd8609d3f9f  vmovaps xmm10, [rsp+0x90]
00007dd8609d3fa8  vmovaps xmm11, [rsp+0xA0]
00007dd8609d3fb1  vmovaps xmm12, [rsp+0xB0]
00007dd8609d3fba  vmovaps xmm13, [rsp+0xC0]
00007dd8609d3fc3  vmovaps xmm14, [rsp+0xD0]
00007dd8609d3fcc  vmovaps xmm15, [rsp+0xE0]
00007dd8609d3fd5  add rsp, 0xF0
00007dd8609d3fdc  pop r11
00007dd8609d3fde  pop r10
00007dd8609d3fe0  pop r9
00007dd8609d3fe2  pop r8
00007dd8609d3fe4  pop rsi
00007dd8609d3fe5  pop rdi
00007dd8609d3fe6  pop rdx
00007dd8609d3fe7  pop rcx
00007dd8609d3fe8  pop rax
00007dd8609d3fe9  add rsp, 0x08
00007dd8609d3fed  jmp 0x00007DD8609D28D2
00007dd8609d3ff2  sub rsp, 0x08
00007dd8609d3ff6  push rax
00007dd8609d3ff7  push rcx
00007dd8609d3ff8  push rdx
00007dd8609d3ff9  push rdi
00007dd8609d3ffa  push rsi
00007dd8609d3ffb  push r8
00007dd8609d3ffd  push r9
00007dd8609d3fff  push r10
00007dd8609d4001  push r11
00007dd8609d4003  sub rsp, 0xF0
00007dd8609d400a  vmovaps [rsp], xmm0
00007dd8609d400f  vmovaps [rsp+0x10], xmm1
00007dd8609d4015  vmovaps [rsp+0x20], xmm2
00007dd8609d401b  vmovaps [rsp+0x30], xmm3
00007dd8609d4021  vmovaps [rsp+0x40], xmm4
00007dd8609d4027  vmovaps [rsp+0x50], xmm5
00007dd8609d402d  vmovaps [rsp+0x60], xmm6
00007dd8609d4033  vmovaps [rsp+0x70], xmm7
00007dd8609d4039  vmovaps [rsp+0x80], xmm8
00007dd8609d4042  vmovaps [rsp+0x90], xmm9
00007dd8609d404b  vmovaps [rsp+0xA0], xmm10
00007dd8609d4054  vmovaps [rsp+0xB0], xmm11
00007dd8609d405d  vmovaps [rsp+0xC0], xmm12
00007dd8609d4066  vmovaps [rsp+0xD0], xmm13
00007dd8609d406f  vmovaps [rsp+0xE0], xmm14
00007dd8609d4078  sub rsp, 0x30
00007dd8609d407c  movaps [rsp], xmm15
00007dd8609d4081  movaps [rsp+0x10], xmm10
00007dd8609d4087  movaps [rsp+0x20], xmm2
00007dd8609d408c  lea rdi, [rsp]
00007dd8609d4090  mov esi, 0x00
00007dd8609d4095  mov rax, 0x629C9CFA9530
00007dd8609d409f  call rax
00007dd8609d40a1  movaps xmm15, [rsp]
00007dd8609d40a6  add rsp, 0x30
00007dd8609d40aa  vmovaps xmm0, [rsp]
00007dd8609d40af  vmovaps xmm1, [rsp+0x10]
00007dd8609d40b5  vmovaps xmm2, [rsp+0x20]
00007dd8609d40bb  vmovaps xmm3, [rsp+0x30]
00007dd8609d40c1  vmovaps xmm4, [rsp+0x40]
00007dd8609d40c7  vmovaps xmm5, [rsp+0x50]
00007dd8609d40cd  vmovaps xmm6, [rsp+0x60]
00007dd8609d40d3  vmovaps xmm7, [rsp+0x70]
00007dd8609d40d9  vmovaps xmm8, [rsp+0x80]
00007dd8609d40e2  vmovaps xmm9, [rsp+0x90]
00007dd8609d40eb  vmovaps xmm10, [rsp+0xA0]
00007dd8609d40f4  vmovaps xmm11, [rsp+0xB0]
00007dd8609d40fd  vmovaps xmm12, [rsp+0xC0]
00007dd8609d4106  vmovaps xmm13, [rsp+0xD0]
00007dd8609d410f  vmovaps xmm14, [rsp+0xE0]
00007dd8609d4118  add rsp, 0xF0
00007dd8609d411f  pop r11
00007dd8609d4121  pop r10
00007dd8609d4123  pop r9
00007dd8609d4125  pop r8
00007dd8609d4127  pop rsi
00007dd8609d4128  pop rdi
00007dd8609d4129  pop rdx
00007dd8609d412a  pop rcx
00007dd8609d412b  pop rax
00007dd8609d412c  add rsp, 0x08
00007dd8609d4130  jmp 0x00007DD8609D2924
00007dd8609d4135  sub rsp, 0x08
00007dd8609d4139  push rax
00007dd8609d413a  push rcx
00007dd8609d413b  push rdx
00007dd8609d413c  push rdi
00007dd8609d413d  push rsi
00007dd8609d413e  push r8
00007dd8609d4140  push r9
00007dd8609d4142  push r10
00007dd8609d4144  push r11
00007dd8609d4146  sub rsp, 0xF0
00007dd8609d414d  vmovaps [rsp], xmm0
00007dd8609d4152  vmovaps [rsp+0x10], xmm2
00007dd8609d4158  vmovaps [rsp+0x20], xmm3
00007dd8609d415e  vmovaps [rsp+0x30], xmm4
00007dd8609d4164  vmovaps [rsp+0x40], xmm5
00007dd8609d416a  vmovaps [rsp+0x50], xmm6
00007dd8609d4170  vmovaps [rsp+0x60], xmm7
00007dd8609d4176  vmovaps [rsp+0x70], xmm8
00007dd8609d417c  vmovaps [rsp+0x80], xmm9
00007dd8609d4185  vmovaps [rsp+0x90], xmm10
00007dd8609d418e  vmovaps [rsp+0xA0], xmm11
00007dd8609d4197  vmovaps [rsp+0xB0], xmm12
00007dd8609d41a0  vmovaps [rsp+0xC0], xmm13
00007dd8609d41a9  vmovaps [rsp+0xD0], xmm14
00007dd8609d41b2  vmovaps [rsp+0xE0], xmm15
00007dd8609d41bb  sub rsp, 0x30
00007dd8609d41bf  movaps [rsp], xmm1
00007dd8609d41c3  movaps [rsp+0x10], xmm10
00007dd8609d41c9  movaps [rsp+0x20], xmm15
00007dd8609d41cf  lea rdi, [rsp]
00007dd8609d41d3  mov esi, 0x00
00007dd8609d41d8  mov rax, 0x629C9CFA9530
00007dd8609d41e2  call rax
00007dd8609d41e4  movaps xmm1, [rsp]
00007dd8609d41e8  add rsp, 0x30
00007dd8609d41ec  vmovaps xmm0, [rsp]
00007dd8609d41f1  vmovaps xmm2, [rsp+0x10]
00007dd8609d41f7  vmovaps xmm3, [rsp+0x20]
00007dd8609d41fd  vmovaps xmm4, [rsp+0x30]
00007dd8609d4203  vmovaps xmm5, [rsp+0x40]
00007dd8609d4209  vmovaps xmm6, [rsp+0x50]
00007dd8609d420f  vmovaps xmm7, [rsp+0x60]
00007dd8609d4215  vmovaps xmm8, [rsp+0x70]
00007dd8609d421b  vmovaps xmm9, [rsp+0x80]
00007dd8609d4224  vmovaps xmm10, [rsp+0x90]
00007dd8609d422d  vmovaps xmm11, [rsp+0xA0]
00007dd8609d4236  vmovaps xmm12, [rsp+0xB0]
00007dd8609d423f  vmovaps xmm13, [rsp+0xC0]
00007dd8609d4248  vmovaps xmm14, [rsp+0xD0]
00007dd8609d4251  vmovaps xmm15, [rsp+0xE0]
00007dd8609d425a  add rsp, 0xF0
00007dd8609d4261  pop r11
00007dd8609d4263  pop r10
00007dd8609d4265  pop r9
00007dd8609d4267  pop r8
00007dd8609d4269  pop rsi
00007dd8609d426a  pop rdi
00007dd8609d426b  pop rdx
00007dd8609d426c  pop rcx
00007dd8609d426d  pop rax
00007dd8609d426e  add rsp, 0x08
00007dd8609d4272  jmp 0x00007DD8609D2962
00007dd8609d4277  sub rsp, 0x08
00007dd8609d427b  push rax
00007dd8609d427c  push rcx
00007dd8609d427d  push rdx
00007dd8609d427e  push rdi
00007dd8609d427f  push rsi
00007dd8609d4280  push r8
00007dd8609d4282  push r9
00007dd8609d4284  push r10
00007dd8609d4286  push r11
00007dd8609d4288  sub rsp, 0xF0
00007dd8609d428f  vmovaps [rsp], xmm0
00007dd8609d4294  vmovaps [rsp+0x10], xmm1
00007dd8609d429a  vmovaps [rsp+0x20], xmm2
00007dd8609d42a0  vmovaps [rsp+0x30], xmm3
00007dd8609d42a6  vmovaps [rsp+0x40], xmm4
00007dd8609d42ac  vmovaps [rsp+0x50], xmm5
00007dd8609d42b2  vmovaps [rsp+0x60], xmm6
00007dd8609d42b8  vmovaps [rsp+0x70], xmm7
00007dd8609d42be  vmovaps [rsp+0x80], xmm8
00007dd8609d42c7  vmovaps [rsp+0x90], xmm9
00007dd8609d42d0  vmovaps [rsp+0xA0], xmm10
00007dd8609d42d9  vmovaps [rsp+0xB0], xmm11
00007dd8609d42e2  vmovaps [rsp+0xC0], xmm12
00007dd8609d42eb  vmovaps [rsp+0xD0], xmm13
00007dd8609d42f4  vmovaps [rsp+0xE0], xmm15
00007dd8609d42fd  sub rsp, 0x30
00007dd8609d4301  movaps [rsp], xmm14
00007dd8609d4306  movaps [rsp+0x10], xmm10
00007dd8609d430c  movaps [rsp+0x20], xmm15
00007dd8609d4312  lea rdi, [rsp]
00007dd8609d4316  mov esi, 0x00
00007dd8609d431b  mov rax, 0x629C9CFA9530
00007dd8609d4325  call rax
00007dd8609d4327  movaps xmm14, [rsp]
00007dd8609d432c  add rsp, 0x30
00007dd8609d4330  vmovaps xmm0, [rsp]
00007dd8609d4335  vmovaps xmm1, [rsp+0x10]
00007dd8609d433b  vmovaps xmm2, [rsp+0x20]
00007dd8609d4341  vmovaps xmm3, [rsp+0x30]
00007dd8609d4347  vmovaps xmm4, [rsp+0x40]
00007dd8609d434d  vmovaps xmm5, [rsp+0x50]
00007dd8609d4353  vmovaps xmm6, [rsp+0x60]
00007dd8609d4359  vmovaps xmm7, [rsp+0x70]
00007dd8609d435f  vmovaps xmm8, [rsp+0x80]
00007dd8609d4368  vmovaps xmm9, [rsp+0x90]
00007dd8609d4371  vmovaps xmm10, [rsp+0xA0]
00007dd8609d437a  vmovaps xmm11, [rsp+0xB0]
00007dd8609d4383  vmovaps xmm12, [rsp+0xC0]
00007dd8609d438c  vmovaps xmm13, [rsp+0xD0]
00007dd8609d4395  vmovaps xmm15, [rsp+0xE0]
00007dd8609d439e  add rsp, 0xF0
00007dd8609d43a5  pop r11
00007dd8609d43a7  pop r10
00007dd8609d43a9  pop r9
00007dd8609d43ab  pop r8
00007dd8609d43ad  pop rsi
00007dd8609d43ae  pop rdi
00007dd8609d43af  pop rdx
00007dd8609d43b0  pop rcx
00007dd8609d43b1  pop rax
00007dd8609d43b2  add rsp, 0x08
00007dd8609d43b6  jmp 0x00007DD8609D298E
00007dd8609d43bb  call 0x00007DD8607FF430
00007dd8609d43c0  jmp 0x00007DD8609D2A1E
00007dd8609d43c5  call 0x00007DD8607FF430
00007dd8609d43ca  jmp 0x00007DD8609D2A31
00007dd8609d43cf  sub rsp, 0x08
00007dd8609d43d3  push rax
00007dd8609d43d4  push rcx
00007dd8609d43d5  push rdx
00007dd8609d43d6  push rdi
00007dd8609d43d7  push rsi
00007dd8609d43d8  push r8
00007dd8609d43da  push r9
00007dd8609d43dc  push r10
00007dd8609d43de  push r11
00007dd8609d43e0  sub rsp, 0xF0
00007dd8609d43e7  vmovaps [rsp], xmm0
00007dd8609d43ec  vmovaps [rsp+0x10], xmm2
00007dd8609d43f2  vmovaps [rsp+0x20], xmm3
00007dd8609d43f8  vmovaps [rsp+0x30], xmm4
00007dd8609d43fe  vmovaps [rsp+0x40], xmm5
00007dd8609d4404  vmovaps [rsp+0x50], xmm6
00007dd8609d440a  vmovaps [rsp+0x60], xmm7
00007dd8609d4410  vmovaps [rsp+0x70], xmm8
00007dd8609d4416  vmovaps [rsp+0x80], xmm9
00007dd8609d441f  vmovaps [rsp+0x90], xmm10
00007dd8609d4428  vmovaps [rsp+0xA0], xmm11
00007dd8609d4431  vmovaps [rsp+0xB0], xmm12
00007dd8609d443a  vmovaps [rsp+0xC0], xmm13
00007dd8609d4443  vmovaps [rsp+0xD0], xmm14
00007dd8609d444c  vmovaps [rsp+0xE0], xmm15
00007dd8609d4455  sub rsp, 0x30
00007dd8609d4459  movaps [rsp], xmm1
00007dd8609d445d  movaps [rsp+0x10], xmm13
00007dd8609d4463  movaps [rsp+0x20], xmm2
00007dd8609d4468  lea rdi, [rsp]
00007dd8609d446c  mov esi, 0x00
00007dd8609d4471  mov rax, 0x629C9CFA9530
00007dd8609d447b  call rax
00007dd8609d447d  movaps xmm1, [rsp]
00007dd8609d4481  add rsp, 0x30
00007dd8609d4485  vmovaps xmm0, [rsp]
00007dd8609d448a  vmovaps xmm2, [rsp+0x10]
00007dd8609d4490  vmovaps xmm3, [rsp+0x20]
00007dd8609d4496  vmovaps xmm4, [rsp+0x30]
00007dd8609d449c  vmovaps xmm5, [rsp+0x40]
00007dd8609d44a2  vmovaps xmm6, [rsp+0x50]
00007dd8609d44a8  vmovaps xmm7, [rsp+0x60]
00007dd8609d44ae  vmovaps xmm8, [rsp+0x70]
00007dd8609d44b4  vmovaps xmm9, [rsp+0x80]
00007dd8609d44bd  vmovaps xmm10, [rsp+0x90]
00007dd8609d44c6  vmovaps xmm11, [rsp+0xA0]
00007dd8609d44cf  vmovaps xmm12, [rsp+0xB0]
00007dd8609d44d8  vmovaps xmm13, [rsp+0xC0]
00007dd8609d44e1  vmovaps xmm14, [rsp+0xD0]
00007dd8609d44ea  vmovaps xmm15, [rsp+0xE0]
00007dd8609d44f3  add rsp, 0xF0
00007dd8609d44fa  pop r11
00007dd8609d44fc  pop r10
00007dd8609d44fe  pop r9
00007dd8609d4500  pop r8
00007dd8609d4502  pop rsi
00007dd8609d4503  pop rdi
00007dd8609d4504  pop rdx
00007dd8609d4505  pop rcx
00007dd8609d4506  pop rax
00007dd8609d4507  add rsp, 0x08
00007dd8609d450b  jmp 0x00007DD8609D2A5C
00007dd8609d4510  call 0x00007DD86080E760
00007dd8609d4515  jmp 0x00007DD8609D2A69
00007dd8609d451a  sub rsp, 0x08
00007dd8609d451e  push rax
00007dd8609d451f  push rcx
00007dd8609d4520  push rdx
00007dd8609d4521  push rdi
00007dd8609d4522  push rsi
00007dd8609d4523  push r8
00007dd8609d4525  push r9
00007dd8609d4527  push r10
00007dd8609d4529  push r11
00007dd8609d452b  sub rsp, 0xF0
00007dd8609d4532  vmovaps [rsp], xmm0
00007dd8609d4537  vmovaps [rsp+0x10], xmm1
00007dd8609d453d  vmovaps [rsp+0x20], xmm2
00007dd8609d4543  vmovaps [rsp+0x30], xmm3
00007dd8609d4549  vmovaps [rsp+0x40], xmm4
00007dd8609d454f  vmovaps [rsp+0x50], xmm5
00007dd8609d4555  vmovaps [rsp+0x60], xmm6
00007dd8609d455b  vmovaps [rsp+0x70], xmm7
00007dd8609d4561  vmovaps [rsp+0x80], xmm8
00007dd8609d456a  vmovaps [rsp+0x90], xmm9
00007dd8609d4573  vmovaps [rsp+0xA0], xmm10
00007dd8609d457c  vmovaps [rsp+0xB0], xmm11
00007dd8609d4585  vmovaps [rsp+0xC0], xmm12
00007dd8609d458e  vmovaps [rsp+0xD0], xmm14
00007dd8609d4597  vmovaps [rsp+0xE0], xmm15
00007dd8609d45a0  sub rsp, 0x30
00007dd8609d45a4  movaps [rsp], xmm13
00007dd8609d45a9  movaps [rsp+0x10], xmm2
00007dd8609d45ae  movaps [rsp+0x20], xmm1
00007dd8609d45b3  lea rdi, [rsp]
00007dd8609d45b7  mov esi, 0x00
00007dd8609d45bc  mov rax, 0x629C9CFA9530
00007dd8609d45c6  call rax
00007dd8609d45c8  movaps xmm13, [rsp]
00007dd8609d45cd  add rsp, 0x30
00007dd8609d45d1  vmovaps xmm0, [rsp]
00007dd8609d45d6  vmovaps xmm1, [rsp+0x10]
00007dd8609d45dc  vmovaps xmm2, [rsp+0x20]
00007dd8609d45e2  vmovaps xmm3, [rsp+0x30]
00007dd8609d45e8  vmovaps xmm4, [rsp+0x40]
00007dd8609d45ee  vmovaps xmm5, [rsp+0x50]
00007dd8609d45f4  vmovaps xmm6, [rsp+0x60]
00007dd8609d45fa  vmovaps xmm7, [rsp+0x70]
00007dd8609d4600  vmovaps xmm8, [rsp+0x80]
00007dd8609d4609  vmovaps xmm9, [rsp+0x90]
00007dd8609d4612  vmovaps xmm10, [rsp+0xA0]
00007dd8609d461b  vmovaps xmm11, [rsp+0xB0]
00007dd8609d4624  vmovaps xmm12, [rsp+0xC0]
00007dd8609d462d  vmovaps xmm14, [rsp+0xD0]
00007dd8609d4636  vmovaps xmm15, [rsp+0xE0]
00007dd8609d463f  add rsp, 0xF0
00007dd8609d4646  pop r11
00007dd8609d4648  pop r10
00007dd8609d464a  pop r9
00007dd8609d464c  pop r8
00007dd8609d464e  pop rsi
00007dd8609d464f  pop rdi
00007dd8609d4650  pop rdx
00007dd8609d4651  pop rcx
00007dd8609d4652  pop rax
00007dd8609d4653  add rsp, 0x08
00007dd8609d4657  jmp 0x00007DD8609D2AA8
00007dd8609d465c  sub rsp, 0x08
00007dd8609d4660  push rax
00007dd8609d4661  push rcx
00007dd8609d4662  push rdx
00007dd8609d4663  push rdi
00007dd8609d4664  push rsi
00007dd8609d4665  push r8
00007dd8609d4667  push r9
00007dd8609d4669  push r10
00007dd8609d466b  push r11
00007dd8609d466d  sub rsp, 0xF0
00007dd8609d4674  vmovaps [rsp], xmm0
00007dd8609d4679  vmovaps [rsp+0x10], xmm2
00007dd8609d467f  vmovaps [rsp+0x20], xmm3
00007dd8609d4685  vmovaps [rsp+0x30], xmm4
00007dd8609d468b  vmovaps [rsp+0x40], xmm5
00007dd8609d4691  vmovaps [rsp+0x50], xmm6
00007dd8609d4697  vmovaps [rsp+0x60], xmm7
00007dd8609d469d  vmovaps [rsp+0x70], xmm8
00007dd8609d46a3  vmovaps [rsp+0x80], xmm9
00007dd8609d46ac  vmovaps [rsp+0x90], xmm10
00007dd8609d46b5  vmovaps [rsp+0xA0], xmm11
00007dd8609d46be  vmovaps [rsp+0xB0], xmm12
00007dd8609d46c7  vmovaps [rsp+0xC0], xmm13
00007dd8609d46d0  vmovaps [rsp+0xD0], xmm14
00007dd8609d46d9  vmovaps [rsp+0xE0], xmm15
00007dd8609d46e2  sub rsp, 0x30
00007dd8609d46e6  movaps [rsp], xmm1
00007dd8609d46ea  movaps [rsp+0x10], xmm14
00007dd8609d46f0  movaps [rsp+0x20], xmm15
00007dd8609d46f6  lea rdi, [rsp]
00007dd8609d46fa  mov esi, 0x00
00007dd8609d46ff  mov rax, 0x629C9CFA9530
00007dd8609d4709  call rax
00007dd8609d470b  movaps xmm1, [rsp]
00007dd8609d470f  add rsp, 0x30
00007dd8609d4713  vmovaps xmm0, [rsp]
00007dd8609d4718  vmovaps xmm2, [rsp+0x10]
00007dd8609d471e  vmovaps xmm3, [rsp+0x20]
00007dd8609d4724  vmovaps xmm4, [rsp+0x30]
00007dd8609d472a  vmovaps xmm5, [rsp+0x40]
00007dd8609d4730  vmovaps xmm6, [rsp+0x50]
00007dd8609d4736  vmovaps xmm7, [rsp+0x60]
00007dd8609d473c  vmovaps xmm8, [rsp+0x70]
00007dd8609d4742  vmovaps xmm9, [rsp+0x80]
00007dd8609d474b  vmovaps xmm10, [rsp+0x90]
00007dd8609d4754  vmovaps xmm11, [rsp+0xA0]
00007dd8609d475d  vmovaps xmm12, [rsp+0xB0]
00007dd8609d4766  vmovaps xmm13, [rsp+0xC0]
00007dd8609d476f  vmovaps xmm14, [rsp+0xD0]
00007dd8609d4778  vmovaps xmm15, [rsp+0xE0]
00007dd8609d4781  add rsp, 0xF0
00007dd8609d4788  pop r11
00007dd8609d478a  pop r10
00007dd8609d478c  pop r9
00007dd8609d478e  pop r8
00007dd8609d4790  pop rsi
00007dd8609d4791  pop rdi
00007dd8609d4792  pop rdx
00007dd8609d4793  pop rcx
00007dd8609d4794  pop rax
00007dd8609d4795  add rsp, 0x08
00007dd8609d4799  jmp 0x00007DD8609D2ACA
00007dd8609d479e  sub rsp, 0x08
00007dd8609d47a2  push rax
00007dd8609d47a3  push rcx
00007dd8609d47a4  push rdx
00007dd8609d47a5  push rdi
00007dd8609d47a6  push rsi
00007dd8609d47a7  push r8
00007dd8609d47a9  push r9
00007dd8609d47ab  push r10
00007dd8609d47ad  push r11
00007dd8609d47af  sub rsp, 0xF0
00007dd8609d47b6  vmovaps [rsp], xmm0
00007dd8609d47bb  vmovaps [rsp+0x10], xmm1
00007dd8609d47c1  vmovaps [rsp+0x20], xmm2
00007dd8609d47c7  vmovaps [rsp+0x30], xmm3
00007dd8609d47cd  vmovaps [rsp+0x40], xmm4
00007dd8609d47d3  vmovaps [rsp+0x50], xmm5
00007dd8609d47d9  vmovaps [rsp+0x60], xmm6
00007dd8609d47df  vmovaps [rsp+0x70], xmm7
00007dd8609d47e5  vmovaps [rsp+0x80], xmm8
00007dd8609d47ee  vmovaps [rsp+0x90], xmm9
00007dd8609d47f7  vmovaps [rsp+0xA0], xmm10
00007dd8609d4800  vmovaps [rsp+0xB0], xmm11
00007dd8609d4809  vmovaps [rsp+0xC0], xmm12
00007dd8609d4812  vmovaps [rsp+0xD0], xmm13
00007dd8609d481b  vmovaps [rsp+0xE0], xmm15
00007dd8609d4824  sub rsp, 0x30
00007dd8609d4828  movaps [rsp], xmm14
00007dd8609d482d  movaps [rsp+0x10], xmm2
00007dd8609d4832  movaps [rsp+0x20], xmm15
00007dd8609d4838  lea rdi, [rsp]
00007dd8609d483c  mov esi, 0x00
00007dd8609d4841  mov rax, 0x629C9CFA9530
00007dd8609d484b  call rax
00007dd8609d484d  movaps xmm14, [rsp]
00007dd8609d4852  add rsp, 0x30
00007dd8609d4856  vmovaps xmm0, [rsp]
00007dd8609d485b  vmovaps xmm1, [rsp+0x10]
00007dd8609d4861  vmovaps xmm2, [rsp+0x20]
00007dd8609d4867  vmovaps xmm3, [rsp+0x30]
00007dd8609d486d  vmovaps xmm4, [rsp+0x40]
00007dd8609d4873  vmovaps xmm5, [rsp+0x50]
00007dd8609d4879  vmovaps xmm6, [rsp+0x60]
00007dd8609d487f  vmovaps xmm7, [rsp+0x70]
00007dd8609d4885  vmovaps xmm8, [rsp+0x80]
00007dd8609d488e  vmovaps xmm9, [rsp+0x90]
00007dd8609d4897  vmovaps xmm10, [rsp+0xA0]
00007dd8609d48a0  vmovaps xmm11, [rsp+0xB0]
00007dd8609d48a9  vmovaps xmm12, [rsp+0xC0]
00007dd8609d48b2  vmovaps xmm13, [rsp+0xD0]
00007dd8609d48bb  vmovaps xmm15, [rsp+0xE0]
00007dd8609d48c4  add rsp, 0xF0
00007dd8609d48cb  pop r11
00007dd8609d48cd  pop r10
00007dd8609d48cf  pop r9
00007dd8609d48d1  pop r8
00007dd8609d48d3  pop rsi
00007dd8609d48d4  pop rdi
00007dd8609d48d5  pop rdx
00007dd8609d48d6  pop rcx
00007dd8609d48d7  pop rax
00007dd8609d48d8  add rsp, 0x08
00007dd8609d48dc  jmp 0x00007DD8609D2B05
00007dd8609d48e1  sub rsp, 0x08
00007dd8609d48e5  push rax
00007dd8609d48e6  push rcx
00007dd8609d48e7  push rdx
00007dd8609d48e8  push rdi
00007dd8609d48e9  push rsi
00007dd8609d48ea  push r8
00007dd8609d48ec  push r9
00007dd8609d48ee  push r10
00007dd8609d48f0  push r11
00007dd8609d48f2  sub rsp, 0xF0
00007dd8609d48f9  vmovaps [rsp], xmm0
00007dd8609d48fe  vmovaps [rsp+0x10], xmm1
00007dd8609d4904  vmovaps [rsp+0x20], xmm2
00007dd8609d490a  vmovaps [rsp+0x30], xmm3
00007dd8609d4910  vmovaps [rsp+0x40], xmm4
00007dd8609d4916  vmovaps [rsp+0x50], xmm5
00007dd8609d491c  vmovaps [rsp+0x60], xmm6
00007dd8609d4922  vmovaps [rsp+0x70], xmm7
00007dd8609d4928  vmovaps [rsp+0x80], xmm8
00007dd8609d4931  vmovaps [rsp+0x90], xmm9
00007dd8609d493a  vmovaps [rsp+0xA0], xmm10
00007dd8609d4943  vmovaps [rsp+0xB0], xmm11
00007dd8609d494c  vmovaps [rsp+0xC0], xmm12
00007dd8609d4955  vmovaps [rsp+0xD0], xmm13
00007dd8609d495e  vmovaps [rsp+0xE0], xmm14
00007dd8609d4967  sub rsp, 0x30
00007dd8609d496b  movaps [rsp], xmm15
00007dd8609d4970  movaps [rsp+0x10], xmm2
00007dd8609d4975  movaps [rsp+0x20], xmm1
00007dd8609d497a  lea rdi, [rsp]
00007dd8609d497e  mov esi, 0x00
00007dd8609d4983  mov rax, 0x629C9CFA9530
00007dd8609d498d  call rax
00007dd8609d498f  movaps xmm15, [rsp]
00007dd8609d4994  add rsp, 0x30
00007dd8609d4998  vmovaps xmm0, [rsp]
00007dd8609d499d  vmovaps xmm1, [rsp+0x10]
00007dd8609d49a3  vmovaps xmm2, [rsp+0x20]
00007dd8609d49a9  vmovaps xmm3, [rsp+0x30]
00007dd8609d49af  vmovaps xmm4, [rsp+0x40]
00007dd8609d49b5  vmovaps xmm5, [rsp+0x50]
00007dd8609d49bb  vmovaps xmm6, [rsp+0x60]
00007dd8609d49c1  vmovaps xmm7, [rsp+0x70]
00007dd8609d49c7  vmovaps xmm8, [rsp+0x80]
00007dd8609d49d0  vmovaps xmm9, [rsp+0x90]
00007dd8609d49d9  vmovaps xmm10, [rsp+0xA0]
00007dd8609d49e2  vmovaps xmm11, [rsp+0xB0]
00007dd8609d49eb  vmovaps xmm12, [rsp+0xC0]
00007dd8609d49f4  vmovaps xmm13, [rsp+0xD0]
00007dd8609d49fd  vmovaps xmm14, [rsp+0xE0]
00007dd8609d4a06  add rsp, 0xF0
00007dd8609d4a0d  pop r11
00007dd8609d4a0f  pop r10
00007dd8609d4a11  pop r9
00007dd8609d4a13  pop r8
00007dd8609d4a15  pop rsi
00007dd8609d4a16  pop rdi
00007dd8609d4a17  pop rdx
00007dd8609d4a18  pop rcx
00007dd8609d4a19  pop rax
00007dd8609d4a1a  add rsp, 0x08
00007dd8609d4a1e  jmp 0x00007DD8609D2B41
00007dd8609d4a23  call 0x00007DD8607FF430
00007dd8609d4a28  jmp 0x00007DD8609D2B4E
00007dd8609d4a2d  sub rsp, 0x08
00007dd8609d4a31  push rax
00007dd8609d4a32  push rcx
00007dd8609d4a33  push rdx
00007dd8609d4a34  push rdi
00007dd8609d4a35  push rsi
00007dd8609d4a36  push r8
00007dd8609d4a38  push r9
00007dd8609d4a3a  push r10
00007dd8609d4a3c  push r11
00007dd8609d4a3e  sub rsp, 0xF0
00007dd8609d4a45  vmovaps [rsp], xmm0
00007dd8609d4a4a  vmovaps [rsp+0x10], xmm1
00007dd8609d4a50  vmovaps [rsp+0x20], xmm3
00007dd8609d4a56  vmovaps [rsp+0x30], xmm4
00007dd8609d4a5c  vmovaps [rsp+0x40], xmm5
00007dd8609d4a62  vmovaps [rsp+0x50], xmm6
00007dd8609d4a68  vmovaps [rsp+0x60], xmm7
00007dd8609d4a6e  vmovaps [rsp+0x70], xmm8
00007dd8609d4a74  vmovaps [rsp+0x80], xmm9
00007dd8609d4a7d  vmovaps [rsp+0x90], xmm10
00007dd8609d4a86  vmovaps [rsp+0xA0], xmm11
00007dd8609d4a8f  vmovaps [rsp+0xB0], xmm12
00007dd8609d4a98  vmovaps [rsp+0xC0], xmm13
00007dd8609d4aa1  vmovaps [rsp+0xD0], xmm14
00007dd8609d4aaa  vmovaps [rsp+0xE0], xmm15
00007dd8609d4ab3  sub rsp, 0x30
00007dd8609d4ab7  movaps [rsp], xmm2
00007dd8609d4abb  movaps [rsp+0x10], xmm1
00007dd8609d4ac0  movaps [rsp+0x20], xmm14
00007dd8609d4ac6  lea rdi, [rsp]
00007dd8609d4aca  mov esi, 0x00
00007dd8609d4acf  mov rax, 0x629C9CFA9530
00007dd8609d4ad9  call rax
00007dd8609d4adb  movaps xmm2, [rsp]
00007dd8609d4adf  add rsp, 0x30
00007dd8609d4ae3  vmovaps xmm0, [rsp]
00007dd8609d4ae8  vmovaps xmm1, [rsp+0x10]
00007dd8609d4aee  vmovaps xmm3, [rsp+0x20]
00007dd8609d4af4  vmovaps xmm4, [rsp+0x30]
00007dd8609d4afa  vmovaps xmm5, [rsp+0x40]
00007dd8609d4b00  vmovaps xmm6, [rsp+0x50]
00007dd8609d4b06  vmovaps xmm7, [rsp+0x60]
00007dd8609d4b0c  vmovaps xmm8, [rsp+0x70]
00007dd8609d4b12  vmovaps xmm9, [rsp+0x80]
00007dd8609d4b1b  vmovaps xmm10, [rsp+0x90]
00007dd8609d4b24  vmovaps xmm11, [rsp+0xA0]
00007dd8609d4b2d  vmovaps xmm12, [rsp+0xB0]
00007dd8609d4b36  vmovaps xmm13, [rsp+0xC0]
00007dd8609d4b3f  vmovaps xmm14, [rsp+0xD0]
00007dd8609d4b48  vmovaps xmm15, [rsp+0xE0]
00007dd8609d4b51  add rsp, 0xF0
00007dd8609d4b58  pop r11
00007dd8609d4b5a  pop r10
00007dd8609d4b5c  pop r9
00007dd8609d4b5e  pop r8
00007dd8609d4b60  pop rsi
00007dd8609d4b61  pop rdi
00007dd8609d4b62  pop rdx
00007dd8609d4b63  pop rcx
00007dd8609d4b64  pop rax
00007dd8609d4b65  add rsp, 0x08
00007dd8609d4b69  jmp 0x00007DD8609D2B8B
00007dd8609d4b6e  sub rsp, 0x08
00007dd8609d4b72  push rax
00007dd8609d4b73  push rcx
00007dd8609d4b74  push rdx
00007dd8609d4b75  push rdi
00007dd8609d4b76  push rsi
00007dd8609d4b77  push r8
00007dd8609d4b79  push r9
00007dd8609d4b7b  push r10
00007dd8609d4b7d  push r11
00007dd8609d4b7f  sub rsp, 0xF0
00007dd8609d4b86  vmovaps [rsp], xmm0
00007dd8609d4b8b  vmovaps [rsp+0x10], xmm1
00007dd8609d4b91  vmovaps [rsp+0x20], xmm2
00007dd8609d4b97  vmovaps [rsp+0x30], xmm3
00007dd8609d4b9d  vmovaps [rsp+0x40], xmm4
00007dd8609d4ba3  vmovaps [rsp+0x50], xmm5
00007dd8609d4ba9  vmovaps [rsp+0x60], xmm6
00007dd8609d4baf  vmovaps [rsp+0x70], xmm7
00007dd8609d4bb5  vmovaps [rsp+0x80], xmm8
00007dd8609d4bbe  vmovaps [rsp+0x90], xmm9
00007dd8609d4bc7  vmovaps [rsp+0xA0], xmm10
00007dd8609d4bd0  vmovaps [rsp+0xB0], xmm11
00007dd8609d4bd9  vmovaps [rsp+0xC0], xmm12
00007dd8609d4be2  vmovaps [rsp+0xD0], xmm13
00007dd8609d4beb  vmovaps [rsp+0xE0], xmm14
00007dd8609d4bf4  sub rsp, 0x30
00007dd8609d4bf8  movaps [rsp], xmm15
00007dd8609d4bfd  movaps [rsp+0x10], xmm14
00007dd8609d4c03  movaps [rsp+0x20], xmm1
00007dd8609d4c08  lea rdi, [rsp]
00007dd8609d4c0c  mov esi, 0x00
00007dd8609d4c11  mov rax, 0x629C9CFA9530
00007dd8609d4c1b  call rax
00007dd8609d4c1d  movaps xmm15, [rsp]
00007dd8609d4c22  add rsp, 0x30
00007dd8609d4c26  vmovaps xmm0, [rsp]
00007dd8609d4c2b  vmovaps xmm1, [rsp+0x10]
00007dd8609d4c31  vmovaps xmm2, [rsp+0x20]
00007dd8609d4c37  vmovaps xmm3, [rsp+0x30]
00007dd8609d4c3d  vmovaps xmm4, [rsp+0x40]
00007dd8609d4c43  vmovaps xmm5, [rsp+0x50]
00007dd8609d4c49  vmovaps xmm6, [rsp+0x60]
00007dd8609d4c4f  vmovaps xmm7, [rsp+0x70]
00007dd8609d4c55  vmovaps xmm8, [rsp+0x80]
00007dd8609d4c5e  vmovaps xmm9, [rsp+0x90]
00007dd8609d4c67  vmovaps xmm10, [rsp+0xA0]
00007dd8609d4c70  vmovaps xmm11, [rsp+0xB0]
00007dd8609d4c79  vmovaps xmm12, [rsp+0xC0]
00007dd8609d4c82  vmovaps xmm13, [rsp+0xD0]
00007dd8609d4c8b  vmovaps xmm14, [rsp+0xE0]
00007dd8609d4c94  add rsp, 0xF0
00007dd8609d4c9b  pop r11
00007dd8609d4c9d  pop r10
00007dd8609d4c9f  pop r9
00007dd8609d4ca1  pop r8
00007dd8609d4ca3  pop rsi
00007dd8609d4ca4  pop rdi
00007dd8609d4ca5  pop rdx
00007dd8609d4ca6  pop rcx
00007dd8609d4ca7  pop rax
00007dd8609d4ca8  add rsp, 0x08
00007dd8609d4cac  jmp 0x00007DD8609D2C05
00007dd8609d4cb1  call 0x00007DD8607FF430
00007dd8609d4cb6  jmp 0x00007DD8609D2C12
00007dd8609d4cbb  sub rsp, 0x08
00007dd8609d4cbf  push rax
00007dd8609d4cc0  push rcx
00007dd8609d4cc1  push rdx
00007dd8609d4cc2  push rdi
00007dd8609d4cc3  push rsi
00007dd8609d4cc4  push r8
00007dd8609d4cc6  push r9
00007dd8609d4cc8  push r10
00007dd8609d4cca  push r11
00007dd8609d4ccc  sub rsp, 0xF0
00007dd8609d4cd3  vmovaps [rsp], xmm0
00007dd8609d4cd8  vmovaps [rsp+0x10], xmm1
00007dd8609d4cde  vmovaps [rsp+0x20], xmm2
00007dd8609d4ce4  vmovaps [rsp+0x30], xmm3
00007dd8609d4cea  vmovaps [rsp+0x40], xmm4
00007dd8609d4cf0  vmovaps [rsp+0x50], xmm5
00007dd8609d4cf6  vmovaps [rsp+0x60], xmm6
00007dd8609d4cfc  vmovaps [rsp+0x70], xmm7
00007dd8609d4d02  vmovaps [rsp+0x80], xmm8
00007dd8609d4d0b  vmovaps [rsp+0x90], xmm9
00007dd8609d4d14  vmovaps [rsp+0xA0], xmm10
00007dd8609d4d1d  vmovaps [rsp+0xB0], xmm11
00007dd8609d4d26  vmovaps [rsp+0xC0], xmm12
00007dd8609d4d2f  vmovaps [rsp+0xD0], xmm14
00007dd8609d4d38  vmovaps [rsp+0xE0], xmm15
00007dd8609d4d41  sub rsp, 0x30
00007dd8609d4d45  movaps [rsp], xmm13
00007dd8609d4d4a  movaps [rsp+0x10], xmm1
00007dd8609d4d4f  movaps [rsp+0x20], xmm15
00007dd8609d4d55  lea rdi, [rsp]
00007dd8609d4d59  mov esi, 0x00
00007dd8609d4d5e  mov rax, 0x629C9CFA9530
00007dd8609d4d68  call rax
00007dd8609d4d6a  movaps xmm13, [rsp]
00007dd8609d4d6f  add rsp, 0x30
00007dd8609d4d73  vmovaps xmm0, [rsp]
00007dd8609d4d78  vmovaps xmm1, [rsp+0x10]
00007dd8609d4d7e  vmovaps xmm2, [rsp+0x20]
00007dd8609d4d84  vmovaps xmm3, [rsp+0x30]
00007dd8609d4d8a  vmovaps xmm4, [rsp+0x40]
00007dd8609d4d90  vmovaps xmm5, [rsp+0x50]
00007dd8609d4d96  vmovaps xmm6, [rsp+0x60]
00007dd8609d4d9c  vmovaps xmm7, [rsp+0x70]
00007dd8609d4da2  vmovaps xmm8, [rsp+0x80]
00007dd8609d4dab  vmovaps xmm9, [rsp+0x90]
00007dd8609d4db4  vmovaps xmm10, [rsp+0xA0]
00007dd8609d4dbd  vmovaps xmm11, [rsp+0xB0]
00007dd8609d4dc6  vmovaps xmm12, [rsp+0xC0]
00007dd8609d4dcf  vmovaps xmm14, [rsp+0xD0]
00007dd8609d4dd8  vmovaps xmm15, [rsp+0xE0]
00007dd8609d4de1  add rsp, 0xF0
00007dd8609d4de8  pop r11
00007dd8609d4dea  pop r10
00007dd8609d4dec  pop r9
00007dd8609d4dee  pop r8
00007dd8609d4df0  pop rsi
00007dd8609d4df1  pop rdi
00007dd8609d4df2  pop rdx
00007dd8609d4df3  pop rcx
00007dd8609d4df4  pop rax
00007dd8609d4df5  add rsp, 0x08
00007dd8609d4df9  jmp 0x00007DD8609D2CD6
00007dd8609d4dfe  sub rsp, 0x08
00007dd8609d4e02  push rax
00007dd8609d4e03  push rcx
00007dd8609d4e04  push rdx
00007dd8609d4e05  push rdi
00007dd8609d4e06  push rsi
00007dd8609d4e07  push r8
00007dd8609d4e09  push r9
00007dd8609d4e0b  push r10
00007dd8609d4e0d  push r11
00007dd8609d4e0f  sub rsp, 0xF0
00007dd8609d4e16  vmovaps [rsp], xmm0
00007dd8609d4e1b  vmovaps [rsp+0x10], xmm1
00007dd8609d4e21  vmovaps [rsp+0x20], xmm2
00007dd8609d4e27  vmovaps [rsp+0x30], xmm3
00007dd8609d4e2d  vmovaps [rsp+0x40], xmm4
00007dd8609d4e33  vmovaps [rsp+0x50], xmm5
00007dd8609d4e39  vmovaps [rsp+0x60], xmm6
00007dd8609d4e3f  vmovaps [rsp+0x70], xmm7
00007dd8609d4e45  vmovaps [rsp+0x80], xmm8
00007dd8609d4e4e  vmovaps [rsp+0x90], xmm9
00007dd8609d4e57  vmovaps [rsp+0xA0], xmm10
00007dd8609d4e60  vmovaps [rsp+0xB0], xmm11
00007dd8609d4e69  vmovaps [rsp+0xC0], xmm12
00007dd8609d4e72  vmovaps [rsp+0xD0], xmm13
00007dd8609d4e7b  vmovaps [rsp+0xE0], xmm14
00007dd8609d4e84  sub rsp, 0x30
00007dd8609d4e88  movaps [rsp], xmm15
00007dd8609d4e8d  movaps [rsp+0x10], xmm14
00007dd8609d4e93  movaps [rsp+0x20], xmm1
00007dd8609d4e98  lea rdi, [rsp]
00007dd8609d4e9c  mov esi, 0x00
00007dd8609d4ea1  mov rax, 0x629C9CFA9530
00007dd8609d4eab  call rax
00007dd8609d4ead  movaps xmm15, [rsp]
00007dd8609d4eb2  add rsp, 0x30
00007dd8609d4eb6  vmovaps xmm0, [rsp]
00007dd8609d4ebb  vmovaps xmm1, [rsp+0x10]
00007dd8609d4ec1  vmovaps xmm2, [rsp+0x20]
00007dd8609d4ec7  vmovaps xmm3, [rsp+0x30]
00007dd8609d4ecd  vmovaps xmm4, [rsp+0x40]
00007dd8609d4ed3  vmovaps xmm5, [rsp+0x50]
00007dd8609d4ed9  vmovaps xmm6, [rsp+0x60]
00007dd8609d4edf  vmovaps xmm7, [rsp+0x70]
00007dd8609d4ee5  vmovaps xmm8, [rsp+0x80]
00007dd8609d4eee  vmovaps xmm9, [rsp+0x90]
00007dd8609d4ef7  vmovaps xmm10, [rsp+0xA0]
00007dd8609d4f00  vmovaps xmm11, [rsp+0xB0]
00007dd8609d4f09  vmovaps xmm12, [rsp+0xC0]
00007dd8609d4f12  vmovaps xmm13, [rsp+0xD0]
00007dd8609d4f1b  vmovaps xmm14, [rsp+0xE0]
00007dd8609d4f24  add rsp, 0xF0
00007dd8609d4f2b  pop r11
00007dd8609d4f2d  pop r10
00007dd8609d4f2f  pop r9
00007dd8609d4f31  pop r8
00007dd8609d4f33  pop rsi
00007dd8609d4f34  pop rdi
00007dd8609d4f35  pop rdx
00007dd8609d4f36  pop rcx
00007dd8609d4f37  pop rax
00007dd8609d4f38  add rsp, 0x08
00007dd8609d4f3c  jmp 0x00007DD8609D2D12
00007dd8609d4f41  call 0x00007DD8607FF430
00007dd8609d4f46  jmp 0x00007DD8609D2D1F
00007dd8609d4f4b  sub rsp, 0x08
00007dd8609d4f4f  push rax
00007dd8609d4f50  push rcx
00007dd8609d4f51  push rdx
00007dd8609d4f52  push rdi
00007dd8609d4f53  push rsi
00007dd8609d4f54  push r8
00007dd8609d4f56  push r9
00007dd8609d4f58  push r10
00007dd8609d4f5a  push r11
00007dd8609d4f5c  sub rsp, 0xF0
00007dd8609d4f63  vmovaps [rsp], xmm0
00007dd8609d4f68  vmovaps [rsp+0x10], xmm1
00007dd8609d4f6e  vmovaps [rsp+0x20], xmm2
00007dd8609d4f74  vmovaps [rsp+0x30], xmm3
00007dd8609d4f7a  vmovaps [rsp+0x40], xmm4
00007dd8609d4f80  vmovaps [rsp+0x50], xmm5
00007dd8609d4f86  vmovaps [rsp+0x60], xmm6
00007dd8609d4f8c  vmovaps [rsp+0x70], xmm7
00007dd8609d4f92  vmovaps [rsp+0x80], xmm8
00007dd8609d4f9b  vmovaps [rsp+0x90], xmm9
00007dd8609d4fa4  vmovaps [rsp+0xA0], xmm10
00007dd8609d4fad  vmovaps [rsp+0xB0], xmm11
00007dd8609d4fb6  vmovaps [rsp+0xC0], xmm12
00007dd8609d4fbf  vmovaps [rsp+0xD0], xmm13
00007dd8609d4fc8  vmovaps [rsp+0xE0], xmm15
00007dd8609d4fd1  sub rsp, 0x30
00007dd8609d4fd5  movaps [rsp], xmm14
00007dd8609d4fda  movaps [rsp+0x10], xmm13
00007dd8609d4fe0  movaps [rsp+0x20], xmm2
00007dd8609d4fe5  lea rdi, [rsp]
00007dd8609d4fe9  mov esi, 0x00
00007dd8609d4fee  mov rax, 0x629C9CFA9530
00007dd8609d4ff8  call rax
00007dd8609d4ffa  movaps xmm14, [rsp]
00007dd8609d4fff  add rsp, 0x30
00007dd8609d5003  vmovaps xmm0, [rsp]
00007dd8609d5008  vmovaps xmm1, [rsp+0x10]
00007dd8609d500e  vmovaps xmm2, [rsp+0x20]
00007dd8609d5014  vmovaps xmm3, [rsp+0x30]
00007dd8609d501a  vmovaps xmm4, [rsp+0x40]
00007dd8609d5020  vmovaps xmm5, [rsp+0x50]
00007dd8609d5026  vmovaps xmm6, [rsp+0x60]
00007dd8609d502c  vmovaps xmm7, [rsp+0x70]
00007dd8609d5032  vmovaps xmm8, [rsp+0x80]
00007dd8609d503b  vmovaps xmm9, [rsp+0x90]
00007dd8609d5044  vmovaps xmm10, [rsp+0xA0]
00007dd8609d504d  vmovaps xmm11, [rsp+0xB0]
00007dd8609d5056  vmovaps xmm12, [rsp+0xC0]
00007dd8609d505f  vmovaps xmm13, [rsp+0xD0]
00007dd8609d5068  vmovaps xmm15, [rsp+0xE0]
00007dd8609d5071  add rsp, 0xF0
00007dd8609d5078  pop r11
00007dd8609d507a  pop r10
00007dd8609d507c  pop r9
00007dd8609d507e  pop r8
00007dd8609d5080  pop rsi
00007dd8609d5081  pop rdi
00007dd8609d5082  pop rdx
00007dd8609d5083  pop rcx
00007dd8609d5084  pop rax
00007dd8609d5085  add rsp, 0x08
00007dd8609d5089  jmp 0x00007DD8609D2D4B
00007dd8609d508e  sub rsp, 0x08
00007dd8609d5092  push rax
00007dd8609d5093  push rcx
00007dd8609d5094  push rdx
00007dd8609d5095  push rdi
00007dd8609d5096  push rsi
00007dd8609d5097  push r8
00007dd8609d5099  push r9
00007dd8609d509b  push r10
00007dd8609d509d  push r11
00007dd8609d509f  sub rsp, 0xF0
00007dd8609d50a6  vmovaps [rsp], xmm0
00007dd8609d50ab  vmovaps [rsp+0x10], xmm2
00007dd8609d50b1  vmovaps [rsp+0x20], xmm3
00007dd8609d50b7  vmovaps [rsp+0x30], xmm4
00007dd8609d50bd  vmovaps [rsp+0x40], xmm5
00007dd8609d50c3  vmovaps [rsp+0x50], xmm6
00007dd8609d50c9  vmovaps [rsp+0x60], xmm7
00007dd8609d50cf  vmovaps [rsp+0x70], xmm8
00007dd8609d50d5  vmovaps [rsp+0x80], xmm9
00007dd8609d50de  vmovaps [rsp+0x90], xmm10
00007dd8609d50e7  vmovaps [rsp+0xA0], xmm11
00007dd8609d50f0  vmovaps [rsp+0xB0], xmm12
00007dd8609d50f9  vmovaps [rsp+0xC0], xmm13
00007dd8609d5102  vmovaps [rsp+0xD0], xmm14
00007dd8609d510b  vmovaps [rsp+0xE0], xmm15
00007dd8609d5114  sub rsp, 0x30
00007dd8609d5118  movaps [rsp], xmm1
00007dd8609d511c  movaps [rsp+0x10], xmm13
00007dd8609d5122  movaps [rsp+0x20], xmm2
00007dd8609d5127  lea rdi, [rsp]
00007dd8609d512b  mov esi, 0x00
00007dd8609d5130  mov rax, 0x629C9CFA9530
00007dd8609d513a  call rax
00007dd8609d513c  movaps xmm1, [rsp]
00007dd8609d5140  add rsp, 0x30
00007dd8609d5144  vmovaps xmm0, [rsp]
00007dd8609d5149  vmovaps xmm2, [rsp+0x10]
00007dd8609d514f  vmovaps xmm3, [rsp+0x20]
00007dd8609d5155  vmovaps xmm4, [rsp+0x30]
00007dd8609d515b  vmovaps xmm5, [rsp+0x40]
00007dd8609d5161  vmovaps xmm6, [rsp+0x50]
00007dd8609d5167  vmovaps xmm7, [rsp+0x60]
00007dd8609d516d  vmovaps xmm8, [rsp+0x70]
00007dd8609d5173  vmovaps xmm9, [rsp+0x80]
00007dd8609d517c  vmovaps xmm10, [rsp+0x90]
00007dd8609d5185  vmovaps xmm11, [rsp+0xA0]
00007dd8609d518e  vmovaps xmm12, [rsp+0xB0]
00007dd8609d5197  vmovaps xmm13, [rsp+0xC0]
00007dd8609d51a0  vmovaps xmm14, [rsp+0xD0]
00007dd8609d51a9  vmovaps xmm15, [rsp+0xE0]
00007dd8609d51b2  add rsp, 0xF0
00007dd8609d51b9  pop r11
00007dd8609d51bb  pop r10
00007dd8609d51bd  pop r9
00007dd8609d51bf  pop r8
00007dd8609d51c1  pop rsi
00007dd8609d51c2  pop rdi
00007dd8609d51c3  pop rdx
00007dd8609d51c4  pop rcx
00007dd8609d51c5  pop rax
00007dd8609d51c6  add rsp, 0x08
00007dd8609d51ca  jmp 0x00007DD8609D2D79
00007dd8609d51cf  sub rsp, 0x08
00007dd8609d51d3  push rax
00007dd8609d51d4  push rcx
00007dd8609d51d5  push rdx
00007dd8609d51d6  push rdi
00007dd8609d51d7  push rsi
00007dd8609d51d8  push r8
00007dd8609d51da  push r9
00007dd8609d51dc  push r10
00007dd8609d51de  push r11
00007dd8609d51e0  sub rsp, 0xF0
00007dd8609d51e7  vmovaps [rsp], xmm0
00007dd8609d51ec  vmovaps [rsp+0x10], xmm1
00007dd8609d51f2  vmovaps [rsp+0x20], xmm3
00007dd8609d51f8  vmovaps [rsp+0x30], xmm4
00007dd8609d51fe  vmovaps [rsp+0x40], xmm5
00007dd8609d5204  vmovaps [rsp+0x50], xmm6
00007dd8609d520a  vmovaps [rsp+0x60], xmm7
00007dd8609d5210  vmovaps [rsp+0x70], xmm8
00007dd8609d5216  vmovaps [rsp+0x80], xmm9
00007dd8609d521f  vmovaps [rsp+0x90], xmm10
00007dd8609d5228  vmovaps [rsp+0xA0], xmm11
00007dd8609d5231  vmovaps [rsp+0xB0], xmm12
00007dd8609d523a  vmovaps [rsp+0xC0], xmm13
00007dd8609d5243  vmovaps [rsp+0xD0], xmm14
00007dd8609d524c  vmovaps [rsp+0xE0], xmm15
00007dd8609d5255  sub rsp, 0x30
00007dd8609d5259  movaps [rsp], xmm2
00007dd8609d525d  movaps [rsp+0x10], xmm1
00007dd8609d5262  movaps [rsp+0x20], xmm13
00007dd8609d5268  lea rdi, [rsp]
00007dd8609d526c  mov esi, 0x00
00007dd8609d5271  mov rax, 0x629C9CFA9530
00007dd8609d527b  call rax
00007dd8609d527d  movaps xmm2, [rsp]
00007dd8609d5281  add rsp, 0x30
00007dd8609d5285  vmovaps xmm0, [rsp]
00007dd8609d528a  vmovaps xmm1, [rsp+0x10]
00007dd8609d5290  vmovaps xmm3, [rsp+0x20]
00007dd8609d5296  vmovaps xmm4, [rsp+0x30]
00007dd8609d529c  vmovaps xmm5, [rsp+0x40]
00007dd8609d52a2  vmovaps xmm6, [rsp+0x50]
00007dd8609d52a8  vmovaps xmm7, [rsp+0x60]
00007dd8609d52ae  vmovaps xmm8, [rsp+0x70]
00007dd8609d52b4  vmovaps xmm9, [rsp+0x80]
00007dd8609d52bd  vmovaps xmm10, [rsp+0x90]
00007dd8609d52c6  vmovaps xmm11, [rsp+0xA0]
00007dd8609d52cf  vmovaps xmm12, [rsp+0xB0]
00007dd8609d52d8  vmovaps xmm13, [rsp+0xC0]
00007dd8609d52e1  vmovaps xmm14, [rsp+0xD0]
00007dd8609d52ea  vmovaps xmm15, [rsp+0xE0]
00007dd8609d52f3  add rsp, 0xF0
00007dd8609d52fa  pop r11
00007dd8609d52fc  pop r10
00007dd8609d52fe  pop r9
00007dd8609d5300  pop r8
00007dd8609d5302  pop rsi
00007dd8609d5303  pop rdi
00007dd8609d5304  pop rdx
00007dd8609d5305  pop rcx
00007dd8609d5306  pop rax
00007dd8609d5307  add rsp, 0x08
00007dd8609d530b  jmp 0x00007DD8609D2DD2
00007dd8609d5310  call 0x00007DD8607FF430
00007dd8609d5315  jmp 0x00007DD8609D2DDF
00007dd8609d531a  sub rsp, 0x08
00007dd8609d531e  push rax
00007dd8609d531f  push rcx
00007dd8609d5320  push rdx
00007dd8609d5321  push rdi
00007dd8609d5322  push rsi
00007dd8609d5323  push r8
00007dd8609d5325  push r9
00007dd8609d5327  push r10
00007dd8609d5329  push r11
00007dd8609d532b  sub rsp, 0xF0
00007dd8609d5332  vmovaps [rsp], xmm0
00007dd8609d5337  vmovaps [rsp+0x10], xmm1
00007dd8609d533d  vmovaps [rsp+0x20], xmm2
00007dd8609d5343  vmovaps [rsp+0x30], xmm3
00007dd8609d5349  vmovaps [rsp+0x40], xmm4
00007dd8609d534f  vmovaps [rsp+0x50], xmm5
00007dd8609d5355  vmovaps [rsp+0x60], xmm6
00007dd8609d535b  vmovaps [rsp+0x70], xmm7
00007dd8609d5361  vmovaps [rsp+0x80], xmm8
00007dd8609d536a  vmovaps [rsp+0x90], xmm9
00007dd8609d5373  vmovaps [rsp+0xA0], xmm10
00007dd8609d537c  vmovaps [rsp+0xB0], xmm11
00007dd8609d5385  vmovaps [rsp+0xC0], xmm12
00007dd8609d538e  vmovaps [rsp+0xD0], xmm13
00007dd8609d5397  vmovaps [rsp+0xE0], xmm14
00007dd8609d53a0  sub rsp, 0x30
00007dd8609d53a4  movaps [rsp], xmm15
00007dd8609d53a9  movaps [rsp+0x10], xmm13
00007dd8609d53af  movaps [rsp+0x20], xmm1
00007dd8609d53b4  lea rdi, [rsp]
00007dd8609d53b8  mov esi, 0x00
00007dd8609d53bd  mov rax, 0x629C9CFA9530
00007dd8609d53c7  call rax
00007dd8609d53c9  movaps xmm15, [rsp]
00007dd8609d53ce  add rsp, 0x30
00007dd8609d53d2  vmovaps xmm0, [rsp]
00007dd8609d53d7  vmovaps xmm1, [rsp+0x10]
00007dd8609d53dd  vmovaps xmm2, [rsp+0x20]
00007dd8609d53e3  vmovaps xmm3, [rsp+0x30]
00007dd8609d53e9  vmovaps xmm4, [rsp+0x40]
00007dd8609d53ef  vmovaps xmm5, [rsp+0x50]
00007dd8609d53f5  vmovaps xmm6, [rsp+0x60]
00007dd8609d53fb  vmovaps xmm7, [rsp+0x70]
00007dd8609d5401  vmovaps xmm8, [rsp+0x80]
00007dd8609d540a  vmovaps xmm9, [rsp+0x90]
00007dd8609d5413  vmovaps xmm10, [rsp+0xA0]
00007dd8609d541c  vmovaps xmm11, [rsp+0xB0]
00007dd8609d5425  vmovaps xmm12, [rsp+0xC0]
00007dd8609d542e  vmovaps xmm13, [rsp+0xD0]
00007dd8609d5437  vmovaps xmm14, [rsp+0xE0]
00007dd8609d5440  add rsp, 0xF0
00007dd8609d5447  pop r11
00007dd8609d5449  pop r10
00007dd8609d544b  pop r9
00007dd8609d544d  pop r8
00007dd8609d544f  pop rsi
00007dd8609d5450  pop rdi
00007dd8609d5451  pop rdx
00007dd8609d5452  pop rcx
00007dd8609d5453  pop rax
00007dd8609d5454  add rsp, 0x08
00007dd8609d5458  jmp 0x00007DD8609D2E1E
00007dd8609d545d  sub rsp, 0x08
00007dd8609d5461  push rax
00007dd8609d5462  push rcx
00007dd8609d5463  push rdx
00007dd8609d5464  push rdi
00007dd8609d5465  push rsi
00007dd8609d5466  push r8
00007dd8609d5468  push r9
00007dd8609d546a  push r10
00007dd8609d546c  push r11
00007dd8609d546e  sub rsp, 0xF0
00007dd8609d5475  vmovaps [rsp], xmm0
00007dd8609d547a  vmovaps [rsp+0x10], xmm1
00007dd8609d5480  vmovaps [rsp+0x20], xmm2
00007dd8609d5486  vmovaps [rsp+0x30], xmm3
00007dd8609d548c  vmovaps [rsp+0x40], xmm4
00007dd8609d5492  vmovaps [rsp+0x50], xmm5
00007dd8609d5498  vmovaps [rsp+0x60], xmm6
00007dd8609d549e  vmovaps [rsp+0x70], xmm7
00007dd8609d54a4  vmovaps [rsp+0x80], xmm8
00007dd8609d54ad  vmovaps [rsp+0x90], xmm9
00007dd8609d54b6  vmovaps [rsp+0xA0], xmm10
00007dd8609d54bf  vmovaps [rsp+0xB0], xmm11
00007dd8609d54c8  vmovaps [rsp+0xC0], xmm12
00007dd8609d54d1  vmovaps [rsp+0xD0], xmm13
00007dd8609d54da  vmovaps [rsp+0xE0], xmm15
00007dd8609d54e3  sub rsp, 0x30
00007dd8609d54e7  movaps [rsp], xmm14
00007dd8609d54ec  movaps [rsp+0x10], xmm11
00007dd8609d54f2  movaps [rsp+0x20], xmm1
00007dd8609d54f7  lea rdi, [rsp]
00007dd8609d54fb  mov esi, 0x00
00007dd8609d5500  mov rax, 0x629C9CFA9530
00007dd8609d550a  call rax
00007dd8609d550c  movaps xmm14, [rsp]
00007dd8609d5511  add rsp, 0x30
00007dd8609d5515  vmovaps xmm0, [rsp]
00007dd8609d551a  vmovaps xmm1, [rsp+0x10]
00007dd8609d5520  vmovaps xmm2, [rsp+0x20]
00007dd8609d5526  vmovaps xmm3, [rsp+0x30]
00007dd8609d552c  vmovaps xmm4, [rsp+0x40]
00007dd8609d5532  vmovaps xmm5, [rsp+0x50]
00007dd8609d5538  vmovaps xmm6, [rsp+0x60]
00007dd8609d553e  vmovaps xmm7, [rsp+0x70]
00007dd8609d5544  vmovaps xmm8, [rsp+0x80]
00007dd8609d554d  vmovaps xmm9, [rsp+0x90]
00007dd8609d5556  vmovaps xmm10, [rsp+0xA0]
00007dd8609d555f  vmovaps xmm11, [rsp+0xB0]
00007dd8609d5568  vmovaps xmm12, [rsp+0xC0]
00007dd8609d5571  vmovaps xmm13, [rsp+0xD0]
00007dd8609d557a  vmovaps xmm15, [rsp+0xE0]
00007dd8609d5583  add rsp, 0xF0
00007dd8609d558a  pop r11
00007dd8609d558c  pop r10
00007dd8609d558e  pop r9
00007dd8609d5590  pop r8
00007dd8609d5592  pop rsi
00007dd8609d5593  pop rdi
00007dd8609d5594  pop rdx
00007dd8609d5595  pop rcx
00007dd8609d5596  pop rax
00007dd8609d5597  add rsp, 0x08
00007dd8609d559b  jmp 0x00007DD8609D2E48
00007dd8609d55a0  sub rsp, 0x08
00007dd8609d55a4  push rax
00007dd8609d55a5  push rcx
00007dd8609d55a6  push rdx
00007dd8609d55a7  push rdi
00007dd8609d55a8  push rsi
00007dd8609d55a9  push r8
00007dd8609d55ab  push r9
00007dd8609d55ad  push r10
00007dd8609d55af  push r11
00007dd8609d55b1  sub rsp, 0xF0
00007dd8609d55b8  vmovaps [rsp], xmm0
00007dd8609d55bd  vmovaps [rsp+0x10], xmm1
00007dd8609d55c3  vmovaps [rsp+0x20], xmm2
00007dd8609d55c9  vmovaps [rsp+0x30], xmm3
00007dd8609d55cf  vmovaps [rsp+0x40], xmm4
00007dd8609d55d5  vmovaps [rsp+0x50], xmm5
00007dd8609d55db  vmovaps [rsp+0x60], xmm6
00007dd8609d55e1  vmovaps [rsp+0x70], xmm7
00007dd8609d55e7  vmovaps [rsp+0x80], xmm8
00007dd8609d55f0  vmovaps [rsp+0x90], xmm9
00007dd8609d55f9  vmovaps [rsp+0xA0], xmm10
00007dd8609d5602  vmovaps [rsp+0xB0], xmm11
00007dd8609d560b  vmovaps [rsp+0xC0], xmm12
00007dd8609d5614  vmovaps [rsp+0xD0], xmm14
00007dd8609d561d  vmovaps [rsp+0xE0], xmm15
00007dd8609d5626  sub rsp, 0x30
00007dd8609d562a  movaps [rsp], xmm13
00007dd8609d562f  movaps [rsp+0x10], xmm11
00007dd8609d5635  movaps [rsp+0x20], xmm1
00007dd8609d563a  lea rdi, [rsp]
00007dd8609d563e  mov esi, 0x00
00007dd8609d5643  mov rax, 0x629C9CFA9530
00007dd8609d564d  call rax
00007dd8609d564f  movaps xmm13, [rsp]
00007dd8609d5654  add rsp, 0x30
00007dd8609d5658  vmovaps xmm0, [rsp]
00007dd8609d565d  vmovaps xmm1, [rsp+0x10]
00007dd8609d5663  vmovaps xmm2, [rsp+0x20]
00007dd8609d5669  vmovaps xmm3, [rsp+0x30]
00007dd8609d566f  vmovaps xmm4, [rsp+0x40]
00007dd8609d5675  vmovaps xmm5, [rsp+0x50]
00007dd8609d567b  vmovaps xmm6, [rsp+0x60]
00007dd8609d5681  vmovaps xmm7, [rsp+0x70]
00007dd8609d5687  vmovaps xmm8, [rsp+0x80]
00007dd8609d5690  vmovaps xmm9, [rsp+0x90]
00007dd8609d5699  vmovaps xmm10, [rsp+0xA0]
00007dd8609d56a2  vmovaps xmm11, [rsp+0xB0]
00007dd8609d56ab  vmovaps xmm12, [rsp+0xC0]
00007dd8609d56b4  vmovaps xmm14, [rsp+0xD0]
00007dd8609d56bd  vmovaps xmm15, [rsp+0xE0]
00007dd8609d56c6  add rsp, 0xF0
00007dd8609d56cd  pop r11
00007dd8609d56cf  pop r10
00007dd8609d56d1  pop r9
00007dd8609d56d3  pop r8
00007dd8609d56d5  pop rsi
00007dd8609d56d6  pop rdi
00007dd8609d56d7  pop rdx
00007dd8609d56d8  pop rcx
00007dd8609d56d9  pop rax
00007dd8609d56da  add rsp, 0x08
00007dd8609d56de  jmp 0x00007DD8609D2E9D
00007dd8609d56e3  call 0x00007DD8607FF430
00007dd8609d56e8  jmp 0x00007DD8609D2EAA
00007dd8609d56ed  sub rsp, 0x08
00007dd8609d56f1  push rax
00007dd8609d56f2  push rcx
00007dd8609d56f3  push rdx
00007dd8609d56f4  push rdi
00007dd8609d56f5  push rsi
00007dd8609d56f6  push r8
00007dd8609d56f8  push r9
00007dd8609d56fa  push r10
00007dd8609d56fc  push r11
00007dd8609d56fe  sub rsp, 0xF0
00007dd8609d5705  vmovaps [rsp], xmm0
00007dd8609d570a  vmovaps [rsp+0x10], xmm1
00007dd8609d5710  vmovaps [rsp+0x20], xmm2
00007dd8609d5716  vmovaps [rsp+0x30], xmm3
00007dd8609d571c  vmovaps [rsp+0x40], xmm4
00007dd8609d5722  vmovaps [rsp+0x50], xmm5
00007dd8609d5728  vmovaps [rsp+0x60], xmm6
00007dd8609d572e  vmovaps [rsp+0x70], xmm7
00007dd8609d5734  vmovaps [rsp+0x80], xmm8
00007dd8609d573d  vmovaps [rsp+0x90], xmm9
00007dd8609d5746  vmovaps [rsp+0xA0], xmm10
00007dd8609d574f  vmovaps [rsp+0xB0], xmm11
00007dd8609d5758  vmovaps [rsp+0xC0], xmm12
00007dd8609d5761  vmovaps [rsp+0xD0], xmm13
00007dd8609d576a  vmovaps [rsp+0xE0], xmm14
00007dd8609d5773  sub rsp, 0x30
00007dd8609d5777  movaps [rsp], xmm15
00007dd8609d577c  movaps [rsp+0x10], xmm11
00007dd8609d5782  movaps [rsp+0x20], xmm1
00007dd8609d5787  lea rdi, [rsp]
00007dd8609d578b  mov esi, 0x00
00007dd8609d5790  mov rax, 0x629C9CFA9530
00007dd8609d579a  call rax
00007dd8609d579c  movaps xmm15, [rsp]
00007dd8609d57a1  add rsp, 0x30
00007dd8609d57a5  vmovaps xmm0, [rsp]
00007dd8609d57aa  vmovaps xmm1, [rsp+0x10]
00007dd8609d57b0  vmovaps xmm2, [rsp+0x20]
00007dd8609d57b6  vmovaps xmm3, [rsp+0x30]
00007dd8609d57bc  vmovaps xmm4, [rsp+0x40]
00007dd8609d57c2  vmovaps xmm5, [rsp+0x50]
00007dd8609d57c8  vmovaps xmm6, [rsp+0x60]
00007dd8609d57ce  vmovaps xmm7, [rsp+0x70]
00007dd8609d57d4  vmovaps xmm8, [rsp+0x80]
00007dd8609d57dd  vmovaps xmm9, [rsp+0x90]
00007dd8609d57e6  vmovaps xmm10, [rsp+0xA0]
00007dd8609d57ef  vmovaps xmm11, [rsp+0xB0]
00007dd8609d57f8  vmovaps xmm12, [rsp+0xC0]
00007dd8609d5801  vmovaps xmm13, [rsp+0xD0]
00007dd8609d580a  vmovaps xmm14, [rsp+0xE0]
00007dd8609d5813  add rsp, 0xF0
00007dd8609d581a  pop r11
00007dd8609d581c  pop r10
00007dd8609d581e  pop r9
00007dd8609d5820  pop r8
00007dd8609d5822  pop rsi
00007dd8609d5823  pop rdi
00007dd8609d5824  pop rdx
00007dd8609d5825  pop rcx
00007dd8609d5826  pop rax
00007dd8609d5827  add rsp, 0x08
00007dd8609d582b  jmp 0x00007DD8609D2EE3
00007dd8609d5830  sub rsp, 0x08
00007dd8609d5834  push rax
00007dd8609d5835  push rcx
00007dd8609d5836  push rdx
00007dd8609d5837  push rdi
00007dd8609d5838  push rsi
00007dd8609d5839  push r8
00007dd8609d583b  push r9
00007dd8609d583d  push r10
00007dd8609d583f  push r11
00007dd8609d5841  sub rsp, 0xF0
00007dd8609d5848  vmovaps [rsp], xmm0
00007dd8609d584d  vmovaps [rsp+0x10], xmm1
00007dd8609d5853  vmovaps [rsp+0x20], xmm2
00007dd8609d5859  vmovaps [rsp+0x30], xmm3
00007dd8609d585f  vmovaps [rsp+0x40], xmm4
00007dd8609d5865  vmovaps [rsp+0x50], xmm5
00007dd8609d586b  vmovaps [rsp+0x60], xmm6
00007dd8609d5871  vmovaps [rsp+0x70], xmm7
00007dd8609d5877  vmovaps [rsp+0x80], xmm8
00007dd8609d5880  vmovaps [rsp+0x90], xmm9
00007dd8609d5889  vmovaps [rsp+0xA0], xmm10
00007dd8609d5892  vmovaps [rsp+0xB0], xmm12
00007dd8609d589b  vmovaps [rsp+0xC0], xmm13
00007dd8609d58a4  vmovaps [rsp+0xD0], xmm14
00007dd8609d58ad  vmovaps [rsp+0xE0], xmm15
00007dd8609d58b6  sub rsp, 0x30
00007dd8609d58ba  movaps [rsp], xmm11
00007dd8609d58bf  movaps [rsp+0x10], xmm6
00007dd8609d58c4  movaps [rsp+0x20], xmm14
00007dd8609d58ca  lea rdi, [rsp]
00007dd8609d58ce  mov esi, 0x00
00007dd8609d58d3  mov rax, 0x629C9CFA9530
00007dd8609d58dd  call rax
00007dd8609d58df  movaps xmm11, [rsp]
00007dd8609d58e4  add rsp, 0x30
00007dd8609d58e8  vmovaps xmm0, [rsp]
00007dd8609d58ed  vmovaps xmm1, [rsp+0x10]
00007dd8609d58f3  vmovaps xmm2, [rsp+0x20]
00007dd8609d58f9  vmovaps xmm3, [rsp+0x30]
00007dd8609d58ff  vmovaps xmm4, [rsp+0x40]
00007dd8609d5905  vmovaps xmm5, [rsp+0x50]
00007dd8609d590b  vmovaps xmm6, [rsp+0x60]
00007dd8609d5911  vmovaps xmm7, [rsp+0x70]
00007dd8609d5917  vmovaps xmm8, [rsp+0x80]
00007dd8609d5920  vmovaps xmm9, [rsp+0x90]
00007dd8609d5929  vmovaps xmm10, [rsp+0xA0]
00007dd8609d5932  vmovaps xmm12, [rsp+0xB0]
00007dd8609d593b  vmovaps xmm13, [rsp+0xC0]
00007dd8609d5944  vmovaps xmm14, [rsp+0xD0]
00007dd8609d594d  vmovaps xmm15, [rsp+0xE0]
00007dd8609d5956  add rsp, 0xF0
00007dd8609d595d  pop r11
00007dd8609d595f  pop r10
00007dd8609d5961  pop r9
00007dd8609d5963  pop r8
00007dd8609d5965  pop rsi
00007dd8609d5966  pop rdi
00007dd8609d5967  pop rdx
00007dd8609d5968  pop rcx
00007dd8609d5969  pop rax
00007dd8609d596a  add rsp, 0x08
00007dd8609d596e  jmp 0x00007DD8609D2F5B
00007dd8609d5973  call 0x00007DD8607FF430
00007dd8609d5978  jmp 0x00007DD8609D2F65
00007dd8609d597d  sub rsp, 0x08
00007dd8609d5981  push rax
00007dd8609d5982  push rcx
00007dd8609d5983  push rdx
00007dd8609d5984  push rdi
00007dd8609d5985  push rsi
00007dd8609d5986  push r8
00007dd8609d5988  push r9
00007dd8609d598a  push r10
00007dd8609d598c  push r11
00007dd8609d598e  sub rsp, 0xF0
00007dd8609d5995  vmovaps [rsp], xmm0
00007dd8609d599a  vmovaps [rsp+0x10], xmm1
00007dd8609d59a0  vmovaps [rsp+0x20], xmm2
00007dd8609d59a6  vmovaps [rsp+0x30], xmm3
00007dd8609d59ac  vmovaps [rsp+0x40], xmm4
00007dd8609d59b2  vmovaps [rsp+0x50], xmm5
00007dd8609d59b8  vmovaps [rsp+0x60], xmm6
00007dd8609d59be  vmovaps [rsp+0x70], xmm7
00007dd8609d59c4  vmovaps [rsp+0x80], xmm8
00007dd8609d59cd  vmovaps [rsp+0x90], xmm9
00007dd8609d59d6  vmovaps [rsp+0xA0], xmm10
00007dd8609d59df  vmovaps [rsp+0xB0], xmm11
00007dd8609d59e8  vmovaps [rsp+0xC0], xmm12
00007dd8609d59f1  vmovaps [rsp+0xD0], xmm13
00007dd8609d59fa  vmovaps [rsp+0xE0], xmm15
00007dd8609d5a03  sub rsp, 0x30
00007dd8609d5a07  movaps [rsp], xmm14
00007dd8609d5a0c  movaps [rsp+0x10], xmm6
00007dd8609d5a11  movaps [rsp+0x20], xmm2
00007dd8609d5a16  lea rdi, [rsp]
00007dd8609d5a1a  mov esi, 0x00
00007dd8609d5a1f  mov rax, 0x629C9CFA9530
00007dd8609d5a29  call rax
00007dd8609d5a2b  movaps xmm14, [rsp]
00007dd8609d5a30  add rsp, 0x30
00007dd8609d5a34  vmovaps xmm0, [rsp]
00007dd8609d5a39  vmovaps xmm1, [rsp+0x10]
00007dd8609d5a3f  vmovaps xmm2, [rsp+0x20]
00007dd8609d5a45  vmovaps xmm3, [rsp+0x30]
00007dd8609d5a4b  vmovaps xmm4, [rsp+0x40]
00007dd8609d5a51  vmovaps xmm5, [rsp+0x50]
00007dd8609d5a57  vmovaps xmm6, [rsp+0x60]
00007dd8609d5a5d  vmovaps xmm7, [rsp+0x70]
00007dd8609d5a63  vmovaps xmm8, [rsp+0x80]
00007dd8609d5a6c  vmovaps xmm9, [rsp+0x90]
00007dd8609d5a75  vmovaps xmm10, [rsp+0xA0]
00007dd8609d5a7e  vmovaps xmm11, [rsp+0xB0]
00007dd8609d5a87  vmovaps xmm12, [rsp+0xC0]
00007dd8609d5a90  vmovaps xmm13, [rsp+0xD0]
00007dd8609d5a99  vmovaps xmm15, [rsp+0xE0]
00007dd8609d5aa2  add rsp, 0xF0
00007dd8609d5aa9  pop r11
00007dd8609d5aab  pop r10
00007dd8609d5aad  pop r9
00007dd8609d5aaf  pop r8
00007dd8609d5ab1  pop rsi
00007dd8609d5ab2  pop rdi
00007dd8609d5ab3  pop rdx
00007dd8609d5ab4  pop rcx
00007dd8609d5ab5  pop rax
00007dd8609d5ab6  add rsp, 0x08
00007dd8609d5aba  jmp 0x00007DD8609D2F99
00007dd8609d5abf  sub rsp, 0x08
00007dd8609d5ac3  push rax
00007dd8609d5ac4  push rcx
00007dd8609d5ac5  push rdx
00007dd8609d5ac6  push rdi
00007dd8609d5ac7  push rsi
00007dd8609d5ac8  push r8
00007dd8609d5aca  push r9
00007dd8609d5acc  push r10
00007dd8609d5ace  push r11
00007dd8609d5ad0  sub rsp, 0xF0
00007dd8609d5ad7  vmovaps [rsp], xmm0
00007dd8609d5adc  vmovaps [rsp+0x10], xmm1
00007dd8609d5ae2  vmovaps [rsp+0x20], xmm2
00007dd8609d5ae8  vmovaps [rsp+0x30], xmm3
00007dd8609d5aee  vmovaps [rsp+0x40], xmm4
00007dd8609d5af4  vmovaps [rsp+0x50], xmm5
00007dd8609d5afa  vmovaps [rsp+0x60], xmm7
00007dd8609d5b00  vmovaps [rsp+0x70], xmm8
00007dd8609d5b06  vmovaps [rsp+0x80], xmm9
00007dd8609d5b0f  vmovaps [rsp+0x90], xmm10
00007dd8609d5b18  vmovaps [rsp+0xA0], xmm11
00007dd8609d5b21  vmovaps [rsp+0xB0], xmm12
00007dd8609d5b2a  vmovaps [rsp+0xC0], xmm13
00007dd8609d5b33  vmovaps [rsp+0xD0], xmm14
00007dd8609d5b3c  vmovaps [rsp+0xE0], xmm15
00007dd8609d5b45  sub rsp, 0x30
00007dd8609d5b49  movaps [rsp], xmm6
00007dd8609d5b4d  movaps [rsp+0x10], xmm5
00007dd8609d5b52  movaps [rsp+0x20], xmm1
00007dd8609d5b57  lea rdi, [rsp]
00007dd8609d5b5b  mov esi, 0x00
00007dd8609d5b60  mov rax, 0x629C9CFA9530
00007dd8609d5b6a  call rax
00007dd8609d5b6c  movaps xmm6, [rsp]
00007dd8609d5b70  add rsp, 0x30
00007dd8609d5b74  vmovaps xmm0, [rsp]
00007dd8609d5b79  vmovaps xmm1, [rsp+0x10]
00007dd8609d5b7f  vmovaps xmm2, [rsp+0x20]
00007dd8609d5b85  vmovaps xmm3, [rsp+0x30]
00007dd8609d5b8b  vmovaps xmm4, [rsp+0x40]
00007dd8609d5b91  vmovaps xmm5, [rsp+0x50]
00007dd8609d5b97  vmovaps xmm7, [rsp+0x60]
00007dd8609d5b9d  vmovaps xmm8, [rsp+0x70]
00007dd8609d5ba3  vmovaps xmm9, [rsp+0x80]
00007dd8609d5bac  vmovaps xmm10, [rsp+0x90]
00007dd8609d5bb5  vmovaps xmm11, [rsp+0xA0]
00007dd8609d5bbe  vmovaps xmm12, [rsp+0xB0]
00007dd8609d5bc7  vmovaps xmm13, [rsp+0xC0]
00007dd8609d5bd0  vmovaps xmm14, [rsp+0xD0]
00007dd8609d5bd9  vmovaps xmm15, [rsp+0xE0]
00007dd8609d5be2  add rsp, 0xF0
00007dd8609d5be9  pop r11
00007dd8609d5beb  pop r10
00007dd8609d5bed  pop r9
00007dd8609d5bef  pop r8
00007dd8609d5bf1  pop rsi
00007dd8609d5bf2  pop rdi
00007dd8609d5bf3  pop rdx
00007dd8609d5bf4  pop rcx
00007dd8609d5bf5  pop rax
00007dd8609d5bf6  add rsp, 0x08
00007dd8609d5bfa  jmp 0x00007DD8609D2FBF
00007dd8609d5bff  sub rsp, 0x08
00007dd8609d5c03  push rax
00007dd8609d5c04  push rcx
00007dd8609d5c05  push rdx
00007dd8609d5c06  push rdi
00007dd8609d5c07  push rsi
00007dd8609d5c08  push r8
00007dd8609d5c0a  push r9
00007dd8609d5c0c  push r10
00007dd8609d5c0e  push r11
00007dd8609d5c10  sub rsp, 0xF0
00007dd8609d5c17  vmovaps [rsp], xmm0
00007dd8609d5c1c  vmovaps [rsp+0x10], xmm2
00007dd8609d5c22  vmovaps [rsp+0x20], xmm3
00007dd8609d5c28  vmovaps [rsp+0x30], xmm4
00007dd8609d5c2e  vmovaps [rsp+0x40], xmm5
00007dd8609d5c34  vmovaps [rsp+0x50], xmm6
00007dd8609d5c3a  vmovaps [rsp+0x60], xmm7
00007dd8609d5c40  vmovaps [rsp+0x70], xmm8
00007dd8609d5c46  vmovaps [rsp+0x80], xmm9
00007dd8609d5c4f  vmovaps [rsp+0x90], xmm10
00007dd8609d5c58  vmovaps [rsp+0xA0], xmm11
00007dd8609d5c61  vmovaps [rsp+0xB0], xmm12
00007dd8609d5c6a  vmovaps [rsp+0xC0], xmm13
00007dd8609d5c73  vmovaps [rsp+0xD0], xmm14
00007dd8609d5c7c  vmovaps [rsp+0xE0], xmm15
00007dd8609d5c85  sub rsp, 0x30
00007dd8609d5c89  movaps [rsp], xmm1
00007dd8609d5c8d  movaps [rsp+0x10], xmm5
00007dd8609d5c92  movaps [rsp+0x20], xmm13
00007dd8609d5c98  lea rdi, [rsp]
00007dd8609d5c9c  mov esi, 0x00
00007dd8609d5ca1  mov rax, 0x629C9CFA9530
00007dd8609d5cab  call rax
00007dd8609d5cad  movaps xmm1, [rsp]
00007dd8609d5cb1  add rsp, 0x30
00007dd8609d5cb5  vmovaps xmm0, [rsp]
00007dd8609d5cba  vmovaps xmm2, [rsp+0x10]
00007dd8609d5cc0  vmovaps xmm3, [rsp+0x20]
00007dd8609d5cc6  vmovaps xmm4, [rsp+0x30]
00007dd8609d5ccc  vmovaps xmm5, [rsp+0x40]
00007dd8609d5cd2  vmovaps xmm6, [rsp+0x50]
00007dd8609d5cd8  vmovaps xmm7, [rsp+0x60]
00007dd8609d5cde  vmovaps xmm8, [rsp+0x70]
00007dd8609d5ce4  vmovaps xmm9, [rsp+0x80]
00007dd8609d5ced  vmovaps xmm10, [rsp+0x90]
00007dd8609d5cf6  vmovaps xmm11, [rsp+0xA0]
00007dd8609d5cff  vmovaps xmm12, [rsp+0xB0]
00007dd8609d5d08  vmovaps xmm13, [rsp+0xC0]
00007dd8609d5d11  vmovaps xmm14, [rsp+0xD0]
00007dd8609d5d1a  vmovaps xmm15, [rsp+0xE0]
00007dd8609d5d23  add rsp, 0xF0
00007dd8609d5d2a  pop r11
00007dd8609d5d2c  pop r10
00007dd8609d5d2e  pop r9
00007dd8609d5d30  pop r8
00007dd8609d5d32  pop rsi
00007dd8609d5d33  pop rdi
00007dd8609d5d34  pop rdx
00007dd8609d5d35  pop rcx
00007dd8609d5d36  pop rax
00007dd8609d5d37  add rsp, 0x08
00007dd8609d5d3b  jmp 0x00007DD8609D2FDD
00007dd8609d5d40  sub rsp, 0x08
00007dd8609d5d44  push rax
00007dd8609d5d45  push rcx
00007dd8609d5d46  push rdx
00007dd8609d5d47  push rdi
00007dd8609d5d48  push rsi
00007dd8609d5d49  push r8
00007dd8609d5d4b  push r9
00007dd8609d5d4d  push r10
00007dd8609d5d4f  push r11
00007dd8609d5d51  sub rsp, 0xF0
00007dd8609d5d58  vmovaps [rsp], xmm0
00007dd8609d5d5d  vmovaps [rsp+0x10], xmm1
00007dd8609d5d63  vmovaps [rsp+0x20], xmm2
00007dd8609d5d69  vmovaps [rsp+0x30], xmm3
00007dd8609d5d6f  vmovaps [rsp+0x40], xmm4
00007dd8609d5d75  vmovaps [rsp+0x50], xmm6
00007dd8609d5d7b  vmovaps [rsp+0x60], xmm7
00007dd8609d5d81  vmovaps [rsp+0x70], xmm8
00007dd8609d5d87  vmovaps [rsp+0x80], xmm9
00007dd8609d5d90  vmovaps [rsp+0x90], xmm10
00007dd8609d5d99  vmovaps [rsp+0xA0], xmm11
00007dd8609d5da2  vmovaps [rsp+0xB0], xmm12
00007dd8609d5dab  vmovaps [rsp+0xC0], xmm13
00007dd8609d5db4  vmovaps [rsp+0xD0], xmm14
00007dd8609d5dbd  vmovaps [rsp+0xE0], xmm15
00007dd8609d5dc6  sub rsp, 0x30
00007dd8609d5dca  movaps [rsp], xmm5
00007dd8609d5dce  movaps [rsp+0x10], xmm2
00007dd8609d5dd3  movaps [rsp+0x20], xmm13
00007dd8609d5dd9  lea rdi, [rsp]
00007dd8609d5ddd  mov esi, 0x00
00007dd8609d5de2  mov rax, 0x629C9CFA9530
00007dd8609d5dec  call rax
00007dd8609d5dee  movaps xmm5, [rsp]
00007dd8609d5df2  add rsp, 0x30
00007dd8609d5df6  vmovaps xmm0, [rsp]
00007dd8609d5dfb  vmovaps xmm1, [rsp+0x10]
00007dd8609d5e01  vmovaps xmm2, [rsp+0x20]
00007dd8609d5e07  vmovaps xmm3, [rsp+0x30]
00007dd8609d5e0d  vmovaps xmm4, [rsp+0x40]
00007dd8609d5e13  vmovaps xmm6, [rsp+0x50]
00007dd8609d5e19  vmovaps xmm7, [rsp+0x60]
00007dd8609d5e1f  vmovaps xmm8, [rsp+0x70]
00007dd8609d5e25  vmovaps xmm9, [rsp+0x80]
00007dd8609d5e2e  vmovaps xmm10, [rsp+0x90]
00007dd8609d5e37  vmovaps xmm11, [rsp+0xA0]
00007dd8609d5e40  vmovaps xmm12, [rsp+0xB0]
00007dd8609d5e49  vmovaps xmm13, [rsp+0xC0]
00007dd8609d5e52  vmovaps xmm14, [rsp+0xD0]
00007dd8609d5e5b  vmovaps xmm15, [rsp+0xE0]
00007dd8609d5e64  add rsp, 0xF0
00007dd8609d5e6b  pop r11
00007dd8609d5e6d  pop r10
00007dd8609d5e6f  pop r9
00007dd8609d5e71  pop r8
00007dd8609d5e73  pop rsi
00007dd8609d5e74  pop rdi
00007dd8609d5e75  pop rdx
00007dd8609d5e76  pop rcx
00007dd8609d5e77  pop rax
00007dd8609d5e78  add rsp, 0x08
00007dd8609d5e7c  jmp 0x00007DD8609D3013
00007dd8609d5e81  sub rsp, 0x08
00007dd8609d5e85  push rax
00007dd8609d5e86  push rcx
00007dd8609d5e87  push rdx
00007dd8609d5e88  push rdi
00007dd8609d5e89  push rsi
00007dd8609d5e8a  push r8
00007dd8609d5e8c  push r9
00007dd8609d5e8e  push r10
00007dd8609d5e90  push r11
00007dd8609d5e92  sub rsp, 0xF0
00007dd8609d5e99  vmovaps [rsp], xmm0
00007dd8609d5e9e  vmovaps [rsp+0x10], xmm1
00007dd8609d5ea4  vmovaps [rsp+0x20], xmm2
00007dd8609d5eaa  vmovaps [rsp+0x30], xmm3
00007dd8609d5eb0  vmovaps [rsp+0x40], xmm4
00007dd8609d5eb6  vmovaps [rsp+0x50], xmm5
00007dd8609d5ebc  vmovaps [rsp+0x60], xmm6
00007dd8609d5ec2  vmovaps [rsp+0x70], xmm7
00007dd8609d5ec8  vmovaps [rsp+0x80], xmm8
00007dd8609d5ed1  vmovaps [rsp+0x90], xmm9
00007dd8609d5eda  vmovaps [rsp+0xA0], xmm10
00007dd8609d5ee3  vmovaps [rsp+0xB0], xmm11
00007dd8609d5eec  vmovaps [rsp+0xC0], xmm12
00007dd8609d5ef5  vmovaps [rsp+0xD0], xmm14
00007dd8609d5efe  vmovaps [rsp+0xE0], xmm15
00007dd8609d5f07  sub rsp, 0x30
00007dd8609d5f0b  movaps [rsp], xmm13
00007dd8609d5f10  movaps [rsp+0x10], xmm10
00007dd8609d5f16  movaps [rsp+0x20], xmm1
00007dd8609d5f1b  lea rdi, [rsp]
00007dd8609d5f1f  mov esi, 0x00
00007dd8609d5f24  mov rax, 0x629C9CFA9530
00007dd8609d5f2e  call rax
00007dd8609d5f30  movaps xmm13, [rsp]
00007dd8609d5f35  add rsp, 0x30
00007dd8609d5f39  vmovaps xmm0, [rsp]
00007dd8609d5f3e  vmovaps xmm1, [rsp+0x10]
00007dd8609d5f44  vmovaps xmm2, [rsp+0x20]
00007dd8609d5f4a  vmovaps xmm3, [rsp+0x30]
00007dd8609d5f50  vmovaps xmm4, [rsp+0x40]
00007dd8609d5f56  vmovaps xmm5, [rsp+0x50]
00007dd8609d5f5c  vmovaps xmm6, [rsp+0x60]
00007dd8609d5f62  vmovaps xmm7, [rsp+0x70]
00007dd8609d5f68  vmovaps xmm8, [rsp+0x80]
00007dd8609d5f71  vmovaps xmm9, [rsp+0x90]
00007dd8609d5f7a  vmovaps xmm10, [rsp+0xA0]
00007dd8609d5f83  vmovaps xmm11, [rsp+0xB0]
00007dd8609d5f8c  vmovaps xmm12, [rsp+0xC0]
00007dd8609d5f95  vmovaps xmm14, [rsp+0xD0]
00007dd8609d5f9e  vmovaps xmm15, [rsp+0xE0]
00007dd8609d5fa7  add rsp, 0xF0
00007dd8609d5fae  pop r11
00007dd8609d5fb0  pop r10
00007dd8609d5fb2  pop r9
00007dd8609d5fb4  pop r8
00007dd8609d5fb6  pop rsi
00007dd8609d5fb7  pop rdi
00007dd8609d5fb8  pop rdx
00007dd8609d5fb9  pop rcx
00007dd8609d5fba  pop rax
00007dd8609d5fbb  add rsp, 0x08
00007dd8609d5fbf  jmp 0x00007DD8609D303C
00007dd8609d5fc4  sub rsp, 0x08
00007dd8609d5fc8  push rax
00007dd8609d5fc9  push rcx
00007dd8609d5fca  push rdx
00007dd8609d5fcb  push rdi
00007dd8609d5fcc  push rsi
00007dd8609d5fcd  push r8
00007dd8609d5fcf  push r9
00007dd8609d5fd1  push r10
00007dd8609d5fd3  push r11
00007dd8609d5fd5  sub rsp, 0xF0
00007dd8609d5fdc  vmovaps [rsp], xmm0
00007dd8609d5fe1  vmovaps [rsp+0x10], xmm2
00007dd8609d5fe7  vmovaps [rsp+0x20], xmm3
00007dd8609d5fed  vmovaps [rsp+0x30], xmm4
00007dd8609d5ff3  vmovaps [rsp+0x40], xmm5
00007dd8609d5ff9  vmovaps [rsp+0x50], xmm6
00007dd8609d5fff  vmovaps [rsp+0x60], xmm7
00007dd8609d6005  vmovaps [rsp+0x70], xmm8
00007dd8609d600b  vmovaps [rsp+0x80], xmm9
00007dd8609d6014  vmovaps [rsp+0x90], xmm10
00007dd8609d601d  vmovaps [rsp+0xA0], xmm11
00007dd8609d6026  vmovaps [rsp+0xB0], xmm12
00007dd8609d602f  vmovaps [rsp+0xC0], xmm13
00007dd8609d6038  vmovaps [rsp+0xD0], xmm14
00007dd8609d6041  vmovaps [rsp+0xE0], xmm15
00007dd8609d604a  sub rsp, 0x30
00007dd8609d604e  movaps [rsp], xmm1
00007dd8609d6052  movaps [rsp+0x10], xmm15
00007dd8609d6058  movaps [rsp+0x20], xmm10
00007dd8609d605e  lea rdi, [rsp]
00007dd8609d6062  mov esi, 0x00
00007dd8609d6067  mov rax, 0x629C9CFA9530
00007dd8609d6071  call rax
00007dd8609d6073  movaps xmm1, [rsp]
00007dd8609d6077  add rsp, 0x30
00007dd8609d607b  vmovaps xmm0, [rsp]
00007dd8609d6080  vmovaps xmm2, [rsp+0x10]
00007dd8609d6086  vmovaps xmm3, [rsp+0x20]
00007dd8609d608c  vmovaps xmm4, [rsp+0x30]
00007dd8609d6092  vmovaps xmm5, [rsp+0x40]
00007dd8609d6098  vmovaps xmm6, [rsp+0x50]
00007dd8609d609e  vmovaps xmm7, [rsp+0x60]
00007dd8609d60a4  vmovaps xmm8, [rsp+0x70]
00007dd8609d60aa  vmovaps xmm9, [rsp+0x80]
00007dd8609d60b3  vmovaps xmm10, [rsp+0x90]
00007dd8609d60bc  vmovaps xmm11, [rsp+0xA0]
00007dd8609d60c5  vmovaps xmm12, [rsp+0xB0]
00007dd8609d60ce  vmovaps xmm13, [rsp+0xC0]
00007dd8609d60d7  vmovaps xmm14, [rsp+0xD0]
00007dd8609d60e0  vmovaps xmm15, [rsp+0xE0]
00007dd8609d60e9  add rsp, 0xF0
00007dd8609d60f0  pop r11
00007dd8609d60f2  pop r10
00007dd8609d60f4  pop r9
00007dd8609d60f6  pop r8
00007dd8609d60f8  pop rsi
00007dd8609d60f9  pop rdi
00007dd8609d60fa  pop rdx
00007dd8609d60fb  pop rcx
00007dd8609d60fc  pop rax
00007dd8609d60fd  add rsp, 0x08
00007dd8609d6101  jmp 0x00007DD8609D305B
00007dd8609d6106  sub rsp, 0x08
00007dd8609d610a  push rax
00007dd8609d610b  push rcx
00007dd8609d610c  push rdx
00007dd8609d610d  push rdi
00007dd8609d610e  push rsi
00007dd8609d610f  push r8
00007dd8609d6111  push r9
00007dd8609d6113  push r10
00007dd8609d6115  push r11
00007dd8609d6117  sub rsp, 0xF0
00007dd8609d611e  vmovaps [rsp], xmm0
00007dd8609d6123  vmovaps [rsp+0x10], xmm1
00007dd8609d6129  vmovaps [rsp+0x20], xmm2
00007dd8609d612f  vmovaps [rsp+0x30], xmm3
00007dd8609d6135  vmovaps [rsp+0x40], xmm4
00007dd8609d613b  vmovaps [rsp+0x50], xmm5
00007dd8609d6141  vmovaps [rsp+0x60], xmm6
00007dd8609d6147  vmovaps [rsp+0x70], xmm7
00007dd8609d614d  vmovaps [rsp+0x80], xmm8
00007dd8609d6156  vmovaps [rsp+0x90], xmm9
00007dd8609d615f  vmovaps [rsp+0xA0], xmm10
00007dd8609d6168  vmovaps [rsp+0xB0], xmm11
00007dd8609d6171  vmovaps [rsp+0xC0], xmm12
00007dd8609d617a  vmovaps [rsp+0xD0], xmm13
00007dd8609d6183  vmovaps [rsp+0xE0], xmm14
00007dd8609d618c  sub rsp, 0x30
00007dd8609d6190  movaps [rsp], xmm15
00007dd8609d6195  movaps [rsp+0x10], xmm10
00007dd8609d619b  movaps [rsp+0x20], xmm11
00007dd8609d61a1  lea rdi, [rsp]
00007dd8609d61a5  mov esi, 0x00
00007dd8609d61aa  mov rax, 0x629C9CFA9530
00007dd8609d61b4  call rax
00007dd8609d61b6  movaps xmm15, [rsp]
00007dd8609d61bb  add rsp, 0x30
00007dd8609d61bf  vmovaps xmm0, [rsp]
00007dd8609d61c4  vmovaps xmm1, [rsp+0x10]
00007dd8609d61ca  vmovaps xmm2, [rsp+0x20]
00007dd8609d61d0  vmovaps xmm3, [rsp+0x30]
00007dd8609d61d6  vmovaps xmm4, [rsp+0x40]
00007dd8609d61dc  vmovaps xmm5, [rsp+0x50]
00007dd8609d61e2  vmovaps xmm6, [rsp+0x60]
00007dd8609d61e8  vmovaps xmm7, [rsp+0x70]
00007dd8609d61ee  vmovaps xmm8, [rsp+0x80]
00007dd8609d61f7  vmovaps xmm9, [rsp+0x90]
00007dd8609d6200  vmovaps xmm10, [rsp+0xA0]
00007dd8609d6209  vmovaps xmm11, [rsp+0xB0]
00007dd8609d6212  vmovaps xmm12, [rsp+0xC0]
00007dd8609d621b  vmovaps xmm13, [rsp+0xD0]
00007dd8609d6224  vmovaps xmm14, [rsp+0xE0]
00007dd8609d622d  add rsp, 0xF0
00007dd8609d6234  pop r11
00007dd8609d6236  pop r10
00007dd8609d6238  pop r9
00007dd8609d623a  pop r8
00007dd8609d623c  pop rsi
00007dd8609d623d  pop rdi
00007dd8609d623e  pop rdx
00007dd8609d623f  pop rcx
00007dd8609d6240  pop rax
00007dd8609d6241  add rsp, 0x08
00007dd8609d6245  jmp 0x00007DD8609D307E
00007dd8609d624a  sub rsp, 0x08
00007dd8609d624e  push rax
00007dd8609d624f  push rcx
00007dd8609d6250  push rdx
00007dd8609d6251  push rdi
00007dd8609d6252  push rsi
00007dd8609d6253  push r8
00007dd8609d6255  push r9
00007dd8609d6257  push r10
00007dd8609d6259  push r11
00007dd8609d625b  sub rsp, 0xF0
00007dd8609d6262  vmovaps [rsp], xmm0
00007dd8609d6267  vmovaps [rsp+0x10], xmm1
00007dd8609d626d  vmovaps [rsp+0x20], xmm2
00007dd8609d6273  vmovaps [rsp+0x30], xmm3
00007dd8609d6279  vmovaps [rsp+0x40], xmm4
00007dd8609d627f  vmovaps [rsp+0x50], xmm5
00007dd8609d6285  vmovaps [rsp+0x60], xmm6
00007dd8609d628b  vmovaps [rsp+0x70], xmm7
00007dd8609d6291  vmovaps [rsp+0x80], xmm8
00007dd8609d629a  vmovaps [rsp+0x90], xmm9
00007dd8609d62a3  vmovaps [rsp+0xA0], xmm11
00007dd8609d62ac  vmovaps [rsp+0xB0], xmm12
00007dd8609d62b5  vmovaps [rsp+0xC0], xmm13
00007dd8609d62be  vmovaps [rsp+0xD0], xmm14
00007dd8609d62c7  vmovaps [rsp+0xE0], xmm15
00007dd8609d62d0  sub rsp, 0x30
00007dd8609d62d4  movaps [rsp], xmm10
00007dd8609d62d9  movaps [rsp+0x10], xmm2
00007dd8609d62de  movaps [rsp+0x20], xmm11
00007dd8609d62e4  lea rdi, [rsp]
00007dd8609d62e8  mov esi, 0x00
00007dd8609d62ed  mov rax, 0x629C9CFA9530
00007dd8609d62f7  call rax
00007dd8609d62f9  movaps xmm10, [rsp]
00007dd8609d62fe  add rsp, 0x30
00007dd8609d6302  vmovaps xmm0, [rsp]
00007dd8609d6307  vmovaps xmm1, [rsp+0x10]
00007dd8609d630d  vmovaps xmm2, [rsp+0x20]
00007dd8609d6313  vmovaps xmm3, [rsp+0x30]
00007dd8609d6319  vmovaps xmm4, [rsp+0x40]
00007dd8609d631f  vmovaps xmm5, [rsp+0x50]
00007dd8609d6325  vmovaps xmm6, [rsp+0x60]
00007dd8609d632b  vmovaps xmm7, [rsp+0x70]
00007dd8609d6331  vmovaps xmm8, [rsp+0x80]
00007dd8609d633a  vmovaps xmm9, [rsp+0x90]
00007dd8609d6343  vmovaps xmm11, [rsp+0xA0]
00007dd8609d634c  vmovaps xmm12, [rsp+0xB0]
00007dd8609d6355  vmovaps xmm13, [rsp+0xC0]
00007dd8609d635e  vmovaps xmm14, [rsp+0xD0]
00007dd8609d6367  vmovaps xmm15, [rsp+0xE0]
00007dd8609d6370  add rsp, 0xF0
00007dd8609d6377  pop r11
00007dd8609d6379  pop r10
00007dd8609d637b  pop r9
00007dd8609d637d  pop r8
00007dd8609d637f  pop rsi
00007dd8609d6380  pop rdi
00007dd8609d6381  pop rdx
00007dd8609d6382  pop rcx
00007dd8609d6383  pop rax
00007dd8609d6384  add rsp, 0x08
00007dd8609d6388  jmp 0x00007DD8609D30B6
00007dd8609d638d  sub rsp, 0x08
00007dd8609d6391  push rax
00007dd8609d6392  push rcx
00007dd8609d6393  push rdx
00007dd8609d6394  push rdi
00007dd8609d6395  push rsi
00007dd8609d6396  push r8
00007dd8609d6398  push r9
00007dd8609d639a  push r10
00007dd8609d639c  push r11
00007dd8609d639e  sub rsp, 0xF0
00007dd8609d63a5  vmovaps [rsp], xmm0
00007dd8609d63aa  vmovaps [rsp+0x10], xmm1
00007dd8609d63b0  vmovaps [rsp+0x20], xmm2
00007dd8609d63b6  vmovaps [rsp+0x30], xmm3
00007dd8609d63bc  vmovaps [rsp+0x40], xmm4
00007dd8609d63c2  vmovaps [rsp+0x50], xmm5
00007dd8609d63c8  vmovaps [rsp+0x60], xmm6
00007dd8609d63ce  vmovaps [rsp+0x70], xmm7
00007dd8609d63d4  vmovaps [rsp+0x80], xmm8
00007dd8609d63dd  vmovaps [rsp+0x90], xmm9
00007dd8609d63e6  vmovaps [rsp+0xA0], xmm10
00007dd8609d63ef  vmovaps [rsp+0xB0], xmm12
00007dd8609d63f8  vmovaps [rsp+0xC0], xmm13
00007dd8609d6401  vmovaps [rsp+0xD0], xmm14
00007dd8609d640a  vmovaps [rsp+0xE0], xmm15
00007dd8609d6413  sub rsp, 0x30
00007dd8609d6417  movaps [rsp], xmm11
00007dd8609d641c  movaps [rsp+0x10], xmm2
00007dd8609d6421  movaps [rsp+0x20], xmm1
00007dd8609d6426  lea rdi, [rsp]
00007dd8609d642a  mov esi, 0x00
00007dd8609d642f  mov rax, 0x629C9CFA9530
00007dd8609d6439  call rax
00007dd8609d643b  movaps xmm11, [rsp]
00007dd8609d6440  add rsp, 0x30
00007dd8609d6444  vmovaps xmm0, [rsp]
00007dd8609d6449  vmovaps xmm1, [rsp+0x10]
00007dd8609d644f  vmovaps xmm2, [rsp+0x20]
00007dd8609d6455  vmovaps xmm3, [rsp+0x30]
00007dd8609d645b  vmovaps xmm4, [rsp+0x40]
00007dd8609d6461  vmovaps xmm5, [rsp+0x50]
00007dd8609d6467  vmovaps xmm6, [rsp+0x60]
00007dd8609d646d  vmovaps xmm7, [rsp+0x70]
00007dd8609d6473  vmovaps xmm8, [rsp+0x80]
00007dd8609d647c  vmovaps xmm9, [rsp+0x90]
00007dd8609d6485  vmovaps xmm10, [rsp+0xA0]
00007dd8609d648e  vmovaps xmm12, [rsp+0xB0]
00007dd8609d6497  vmovaps xmm13, [rsp+0xC0]
00007dd8609d64a0  vmovaps xmm14, [rsp+0xD0]
00007dd8609d64a9  vmovaps xmm15, [rsp+0xE0]
00007dd8609d64b2  add rsp, 0xF0
00007dd8609d64b9  pop r11
00007dd8609d64bb  pop r10
00007dd8609d64bd  pop r9
00007dd8609d64bf  pop r8
00007dd8609d64c1  pop rsi
00007dd8609d64c2  pop rdi
00007dd8609d64c3  pop rdx
00007dd8609d64c4  pop rcx
00007dd8609d64c5  pop rax
00007dd8609d64c6  add rsp, 0x08
00007dd8609d64ca  jmp 0x00007DD8609D30F2
00007dd8609d64cf  sub rsp, 0x08
00007dd8609d64d3  push rax
00007dd8609d64d4  push rcx
00007dd8609d64d5  push rdx
00007dd8609d64d6  push rdi
00007dd8609d64d7  push rsi
00007dd8609d64d8  push r8
00007dd8609d64da  push r9
00007dd8609d64dc  push r10
00007dd8609d64de  push r11
00007dd8609d64e0  sub rsp, 0xF0
00007dd8609d64e7  vmovaps [rsp], xmm0
00007dd8609d64ec  vmovaps [rsp+0x10], xmm2
00007dd8609d64f2  vmovaps [rsp+0x20], xmm3
00007dd8609d64f8  vmovaps [rsp+0x30], xmm4
00007dd8609d64fe  vmovaps [rsp+0x40], xmm5
00007dd8609d6504  vmovaps [rsp+0x50], xmm6
00007dd8609d650a  vmovaps [rsp+0x60], xmm7
00007dd8609d6510  vmovaps [rsp+0x70], xmm8
00007dd8609d6516  vmovaps [rsp+0x80], xmm9
00007dd8609d651f  vmovaps [rsp+0x90], xmm10
00007dd8609d6528  vmovaps [rsp+0xA0], xmm11
00007dd8609d6531  vmovaps [rsp+0xB0], xmm12
00007dd8609d653a  vmovaps [rsp+0xC0], xmm13
00007dd8609d6543  vmovaps [rsp+0xD0], xmm14
00007dd8609d654c  vmovaps [rsp+0xE0], xmm15
00007dd8609d6555  sub rsp, 0x30
00007dd8609d6559  movaps [rsp], xmm1
00007dd8609d655d  movaps [rsp+0x10], xmm14
00007dd8609d6563  movaps [rsp+0x20], xmm6
00007dd8609d6568  lea rdi, [rsp]
00007dd8609d656c  mov esi, 0x00
00007dd8609d6571  mov rax, 0x629C9CFA9530
00007dd8609d657b  call rax
00007dd8609d657d  movaps xmm1, [rsp]
00007dd8609d6581  add rsp, 0x30
00007dd8609d6585  vmovaps xmm0, [rsp]
00007dd8609d658a  vmovaps xmm2, [rsp+0x10]
00007dd8609d6590  vmovaps xmm3, [rsp+0x20]
00007dd8609d6596  vmovaps xmm4, [rsp+0x30]
00007dd8609d659c  vmovaps xmm5, [rsp+0x40]
00007dd8609d65a2  vmovaps xmm6, [rsp+0x50]
00007dd8609d65a8  vmovaps xmm7, [rsp+0x60]
00007dd8609d65ae  vmovaps xmm8, [rsp+0x70]
00007dd8609d65b4  vmovaps xmm9, [rsp+0x80]
00007dd8609d65bd  vmovaps xmm10, [rsp+0x90]
00007dd8609d65c6  vmovaps xmm11, [rsp+0xA0]
00007dd8609d65cf  vmovaps xmm12, [rsp+0xB0]
00007dd8609d65d8  vmovaps xmm13, [rsp+0xC0]
00007dd8609d65e1  vmovaps xmm14, [rsp+0xD0]
00007dd8609d65ea  vmovaps xmm15, [rsp+0xE0]
00007dd8609d65f3  add rsp, 0xF0
00007dd8609d65fa  pop r11
00007dd8609d65fc  pop r10
00007dd8609d65fe  pop r9
00007dd8609d6600  pop r8
00007dd8609d6602  pop rsi
00007dd8609d6603  pop rdi
00007dd8609d6604  pop rdx
00007dd8609d6605  pop rcx
00007dd8609d6606  pop rax
00007dd8609d6607  add rsp, 0x08
00007dd8609d660b  jmp 0x00007DD8609D310B
00007dd8609d6610  sub rsp, 0x08
00007dd8609d6614  push rax
00007dd8609d6615  push rcx
00007dd8609d6616  push rdx
00007dd8609d6617  push rdi
00007dd8609d6618  push rsi
00007dd8609d6619  push r8
00007dd8609d661b  push r9
00007dd8609d661d  push r10
00007dd8609d661f  push r11
00007dd8609d6621  sub rsp, 0xF0
00007dd8609d6628  vmovaps [rsp], xmm0
00007dd8609d662d  vmovaps [rsp+0x10], xmm1
00007dd8609d6633  vmovaps [rsp+0x20], xmm2
00007dd8609d6639  vmovaps [rsp+0x30], xmm3
00007dd8609d663f  vmovaps [rsp+0x40], xmm4
00007dd8609d6645  vmovaps [rsp+0x50], xmm5
00007dd8609d664b  vmovaps [rsp+0x60], xmm6
00007dd8609d6651  vmovaps [rsp+0x70], xmm7
00007dd8609d6657  vmovaps [rsp+0x80], xmm8
00007dd8609d6660  vmovaps [rsp+0x90], xmm9
00007dd8609d6669  vmovaps [rsp+0xA0], xmm10
00007dd8609d6672  vmovaps [rsp+0xB0], xmm11
00007dd8609d667b  vmovaps [rsp+0xC0], xmm12
00007dd8609d6684  vmovaps [rsp+0xD0], xmm13
00007dd8609d668d  vmovaps [rsp+0xE0], xmm14
00007dd8609d6696  sub rsp, 0x30
00007dd8609d669a  movaps [rsp], xmm15
00007dd8609d669f  movaps [rsp+0x10], xmm14
00007dd8609d66a5  movaps [rsp+0x20], xmm5
00007dd8609d66aa  lea rdi, [rsp]
00007dd8609d66ae  mov esi, 0x00
00007dd8609d66b3  mov rax, 0x629C9CFA9530
00007dd8609d66bd  call rax
00007dd8609d66bf  movaps xmm15, [rsp]
00007dd8609d66c4  add rsp, 0x30
00007dd8609d66c8  vmovaps xmm0, [rsp]
00007dd8609d66cd  vmovaps xmm1, [rsp+0x10]
00007dd8609d66d3  vmovaps xmm2, [rsp+0x20]
00007dd8609d66d9  vmovaps xmm3, [rsp+0x30]
00007dd8609d66df  vmovaps xmm4, [rsp+0x40]
00007dd8609d66e5  vmovaps xmm5, [rsp+0x50]
00007dd8609d66eb  vmovaps xmm6, [rsp+0x60]
00007dd8609d66f1  vmovaps xmm7, [rsp+0x70]
00007dd8609d66f7  vmovaps xmm8, [rsp+0x80]
00007dd8609d6700  vmovaps xmm9, [rsp+0x90]
00007dd8609d6709  vmovaps xmm10, [rsp+0xA0]
00007dd8609d6712  vmovaps xmm11, [rsp+0xB0]
00007dd8609d671b  vmovaps xmm12, [rsp+0xC0]
00007dd8609d6724  vmovaps xmm13, [rsp+0xD0]
00007dd8609d672d  vmovaps xmm14, [rsp+0xE0]
00007dd8609d6736  add rsp, 0xF0
00007dd8609d673d  pop r11
00007dd8609d673f  pop r10
00007dd8609d6741  pop r9
00007dd8609d6743  pop r8
00007dd8609d6745  pop rsi
00007dd8609d6746  pop rdi
00007dd8609d6747  pop rdx
00007dd8609d6748  pop rcx
00007dd8609d6749  pop rax
00007dd8609d674a  add rsp, 0x08
00007dd8609d674e  jmp 0x00007DD8609D312B
00007dd8609d6753  sub rsp, 0x08
00007dd8609d6757  push rax
00007dd8609d6758  push rcx
00007dd8609d6759  push rdx
00007dd8609d675a  push rdi
00007dd8609d675b  push rsi
00007dd8609d675c  push r8
00007dd8609d675e  push r9
00007dd8609d6760  push r10
00007dd8609d6762  push r11
00007dd8609d6764  sub rsp, 0xF0
00007dd8609d676b  vmovaps [rsp], xmm0
00007dd8609d6770  vmovaps [rsp+0x10], xmm1
00007dd8609d6776  vmovaps [rsp+0x20], xmm2
00007dd8609d677c  vmovaps [rsp+0x30], xmm3
00007dd8609d6782  vmovaps [rsp+0x40], xmm4
00007dd8609d6788  vmovaps [rsp+0x50], xmm5
00007dd8609d678e  vmovaps [rsp+0x60], xmm7
00007dd8609d6794  vmovaps [rsp+0x70], xmm8
00007dd8609d679a  vmovaps [rsp+0x80], xmm9
00007dd8609d67a3  vmovaps [rsp+0x90], xmm10
00007dd8609d67ac  vmovaps [rsp+0xA0], xmm11
00007dd8609d67b5  vmovaps [rsp+0xB0], xmm12
00007dd8609d67be  vmovaps [rsp+0xC0], xmm13
00007dd8609d67c7  vmovaps [rsp+0xD0], xmm14
00007dd8609d67d0  vmovaps [rsp+0xE0], xmm15
00007dd8609d67d9  sub rsp, 0x30
00007dd8609d67dd  movaps [rsp], xmm6
00007dd8609d67e1  movaps [rsp+0x10], xmm9
00007dd8609d67e7  movaps [rsp+0x20], xmm14
00007dd8609d67ed  lea rdi, [rsp]
00007dd8609d67f1  mov esi, 0x00
00007dd8609d67f6  mov rax, 0x629C9CFA9530
00007dd8609d6800  call rax
00007dd8609d6802  movaps xmm6, [rsp]
00007dd8609d6806  add rsp, 0x30
00007dd8609d680a  vmovaps xmm0, [rsp]
00007dd8609d680f  vmovaps xmm1, [rsp+0x10]
00007dd8609d6815  vmovaps xmm2, [rsp+0x20]
00007dd8609d681b  vmovaps xmm3, [rsp+0x30]
00007dd8609d6821  vmovaps xmm4, [rsp+0x40]
00007dd8609d6827  vmovaps xmm5, [rsp+0x50]
00007dd8609d682d  vmovaps xmm7, [rsp+0x60]
00007dd8609d6833  vmovaps xmm8, [rsp+0x70]
00007dd8609d6839  vmovaps xmm9, [rsp+0x80]
00007dd8609d6842  vmovaps xmm10, [rsp+0x90]
00007dd8609d684b  vmovaps xmm11, [rsp+0xA0]
00007dd8609d6854  vmovaps xmm12, [rsp+0xB0]
00007dd8609d685d  vmovaps xmm13, [rsp+0xC0]
00007dd8609d6866  vmovaps xmm14, [rsp+0xD0]
00007dd8609d686f  vmovaps xmm15, [rsp+0xE0]
00007dd8609d6878  add rsp, 0xF0
00007dd8609d687f  pop r11
00007dd8609d6881  pop r10
00007dd8609d6883  pop r9
00007dd8609d6885  pop r8
00007dd8609d6887  pop rsi
00007dd8609d6888  pop rdi
00007dd8609d6889  pop rdx
00007dd8609d688a  pop rcx
00007dd8609d688b  pop rax
00007dd8609d688c  add rsp, 0x08
00007dd8609d6890  jmp 0x00007DD8609D3153
00007dd8609d6895  sub rsp, 0x08
00007dd8609d6899  push rax
00007dd8609d689a  push rcx
00007dd8609d689b  push rdx
00007dd8609d689c  push rdi
00007dd8609d689d  push rsi
00007dd8609d689e  push r8
00007dd8609d68a0  push r9
00007dd8609d68a2  push r10
00007dd8609d68a4  push r11
00007dd8609d68a6  sub rsp, 0xF0
00007dd8609d68ad  vmovaps [rsp], xmm0
00007dd8609d68b2  vmovaps [rsp+0x10], xmm1
00007dd8609d68b8  vmovaps [rsp+0x20], xmm2
00007dd8609d68be  vmovaps [rsp+0x30], xmm3
00007dd8609d68c4  vmovaps [rsp+0x40], xmm4
00007dd8609d68ca  vmovaps [rsp+0x50], xmm5
00007dd8609d68d0  vmovaps [rsp+0x60], xmm6
00007dd8609d68d6  vmovaps [rsp+0x70], xmm7
00007dd8609d68dc  vmovaps [rsp+0x80], xmm8
00007dd8609d68e5  vmovaps [rsp+0x90], xmm9
00007dd8609d68ee  vmovaps [rsp+0xA0], xmm10
00007dd8609d68f7  vmovaps [rsp+0xB0], xmm11
00007dd8609d6900  vmovaps [rsp+0xC0], xmm12
00007dd8609d6909  vmovaps [rsp+0xD0], xmm13
00007dd8609d6912  vmovaps [rsp+0xE0], xmm15
00007dd8609d691b  sub rsp, 0x30
00007dd8609d691f  movaps [rsp], xmm14
00007dd8609d6924  movaps [rsp+0x10], xmm9
00007dd8609d692a  movaps [rsp+0x20], xmm13
00007dd8609d6930  lea rdi, [rsp]
00007dd8609d6934  mov esi, 0x00
00007dd8609d6939  mov rax, 0x629C9CFA9530
00007dd8609d6943  call rax
00007dd8609d6945  movaps xmm14, [rsp]
00007dd8609d694a  add rsp, 0x30
00007dd8609d694e  vmovaps xmm0, [rsp]
00007dd8609d6953  vmovaps xmm1, [rsp+0x10]
00007dd8609d6959  vmovaps xmm2, [rsp+0x20]
00007dd8609d695f  vmovaps xmm3, [rsp+0x30]
00007dd8609d6965  vmovaps xmm4, [rsp+0x40]
00007dd8609d696b  vmovaps xmm5, [rsp+0x50]
00007dd8609d6971  vmovaps xmm6, [rsp+0x60]
00007dd8609d6977  vmovaps xmm7, [rsp+0x70]
00007dd8609d697d  vmovaps xmm8, [rsp+0x80]
00007dd8609d6986  vmovaps xmm9, [rsp+0x90]
00007dd8609d698f  vmovaps xmm10, [rsp+0xA0]
00007dd8609d6998  vmovaps xmm11, [rsp+0xB0]
00007dd8609d69a1  vmovaps xmm12, [rsp+0xC0]
00007dd8609d69aa  vmovaps xmm13, [rsp+0xD0]
00007dd8609d69b3  vmovaps xmm15, [rsp+0xE0]
00007dd8609d69bc  add rsp, 0xF0
00007dd8609d69c3  pop r11
00007dd8609d69c5  pop r10
00007dd8609d69c7  pop r9
00007dd8609d69c9  pop r8
00007dd8609d69cb  pop rsi
00007dd8609d69cc  pop rdi
00007dd8609d69cd  pop rdx
00007dd8609d69ce  pop rcx
00007dd8609d69cf  pop rax
00007dd8609d69d0  add rsp, 0x08
00007dd8609d69d4  jmp 0x00007DD8609D3176
00007dd8609d69d9  sub rsp, 0x08
00007dd8609d69dd  push rax
00007dd8609d69de  push rcx
00007dd8609d69df  push rdx
00007dd8609d69e0  push rdi
00007dd8609d69e1  push rsi
00007dd8609d69e2  push r8
00007dd8609d69e4  push r9
00007dd8609d69e6  push r10
00007dd8609d69e8  push r11
00007dd8609d69ea  sub rsp, 0xF0
00007dd8609d69f1  vmovaps [rsp], xmm0
00007dd8609d69f6  vmovaps [rsp+0x10], xmm1
00007dd8609d69fc  vmovaps [rsp+0x20], xmm2
00007dd8609d6a02  vmovaps [rsp+0x30], xmm3
00007dd8609d6a08  vmovaps [rsp+0x40], xmm4
00007dd8609d6a0e  vmovaps [rsp+0x50], xmm5
00007dd8609d6a14  vmovaps [rsp+0x60], xmm6
00007dd8609d6a1a  vmovaps [rsp+0x70], xmm7
00007dd8609d6a20  vmovaps [rsp+0x80], xmm8
00007dd8609d6a29  vmovaps [rsp+0x90], xmm9
00007dd8609d6a32  vmovaps [rsp+0xA0], xmm10
00007dd8609d6a3b  vmovaps [rsp+0xB0], xmm11
00007dd8609d6a44  vmovaps [rsp+0xC0], xmm12
00007dd8609d6a4d  vmovaps [rsp+0xD0], xmm14
00007dd8609d6a56  vmovaps [rsp+0xE0], xmm15
00007dd8609d6a5f  sub rsp, 0x30
00007dd8609d6a63  movaps [rsp], xmm13
00007dd8609d6a68  movaps [rsp+0x10], xmm9
00007dd8609d6a6e  movaps [rsp+0x20], xmm10
00007dd8609d6a74  lea rdi, [rsp]
00007dd8609d6a78  mov esi, 0x00
00007dd8609d6a7d  mov rax, 0x629C9CFA9530
00007dd8609d6a87  call rax
00007dd8609d6a89  movaps xmm13, [rsp]
00007dd8609d6a8e  add rsp, 0x30
00007dd8609d6a92  vmovaps xmm0, [rsp]
00007dd8609d6a97  vmovaps xmm1, [rsp+0x10]
00007dd8609d6a9d  vmovaps xmm2, [rsp+0x20]
00007dd8609d6aa3  vmovaps xmm3, [rsp+0x30]
00007dd8609d6aa9  vmovaps xmm4, [rsp+0x40]
00007dd8609d6aaf  vmovaps xmm5, [rsp+0x50]
00007dd8609d6ab5  vmovaps xmm6, [rsp+0x60]
00007dd8609d6abb  vmovaps xmm7, [rsp+0x70]
00007dd8609d6ac1  vmovaps xmm8, [rsp+0x80]
00007dd8609d6aca  vmovaps xmm9, [rsp+0x90]
00007dd8609d6ad3  vmovaps xmm10, [rsp+0xA0]
00007dd8609d6adc  vmovaps xmm11, [rsp+0xB0]
00007dd8609d6ae5  vmovaps xmm12, [rsp+0xC0]
00007dd8609d6aee  vmovaps xmm14, [rsp+0xD0]
00007dd8609d6af7  vmovaps xmm15, [rsp+0xE0]
00007dd8609d6b00  add rsp, 0xF0
00007dd8609d6b07  pop r11
00007dd8609d6b09  pop r10
00007dd8609d6b0b  pop r9
00007dd8609d6b0d  pop r8
00007dd8609d6b0f  pop rsi
00007dd8609d6b10  pop rdi
00007dd8609d6b11  pop rdx
00007dd8609d6b12  pop rcx
00007dd8609d6b13  pop rax
00007dd8609d6b14  add rsp, 0x08
00007dd8609d6b18  jmp 0x00007DD8609D3196
00007dd8609d6b1d  call 0x00007DD86080AFE0
00007dd8609d6b22  jmp 0x00007DD8609D31EB
00007dd8609d6b27  sub rsp, 0x08
00007dd8609d6b2b  push rax
00007dd8609d6b2c  push rcx
00007dd8609d6b2d  push rdx
00007dd8609d6b2e  push rdi
00007dd8609d6b2f  push rsi
00007dd8609d6b30  push r8
00007dd8609d6b32  push r9
00007dd8609d6b34  push r10
00007dd8609d6b36  push r11
00007dd8609d6b38  sub rsp, 0xF0
00007dd8609d6b3f  vmovaps [rsp], xmm0
00007dd8609d6b44  vmovaps [rsp+0x10], xmm1
00007dd8609d6b4a  vmovaps [rsp+0x20], xmm2
00007dd8609d6b50  vmovaps [rsp+0x30], xmm3
00007dd8609d6b56  vmovaps [rsp+0x40], xmm4
00007dd8609d6b5c  vmovaps [rsp+0x50], xmm5
00007dd8609d6b62  vmovaps [rsp+0x60], xmm6
00007dd8609d6b68  vmovaps [rsp+0x70], xmm7
00007dd8609d6b6e  vmovaps [rsp+0x80], xmm8
00007dd8609d6b77  vmovaps [rsp+0x90], xmm10
00007dd8609d6b80  vmovaps [rsp+0xA0], xmm11
00007dd8609d6b89  vmovaps [rsp+0xB0], xmm12
00007dd8609d6b92  vmovaps [rsp+0xC0], xmm13
00007dd8609d6b9b  vmovaps [rsp+0xD0], xmm14
00007dd8609d6ba4  vmovaps [rsp+0xE0], xmm15
00007dd8609d6bad  sub rsp, 0x30
00007dd8609d6bb1  movaps [rsp], xmm9
00007dd8609d6bb6  movaps [rsp+0x10], xmm8
00007dd8609d6bbc  movaps [rsp+0x20], xmm10
00007dd8609d6bc2  lea rdi, [rsp]
00007dd8609d6bc6  mov esi, 0x00
00007dd8609d6bcb  mov rax, 0x629C9CFA9530
00007dd8609d6bd5  call rax
00007dd8609d6bd7  movaps xmm9, [rsp]
00007dd8609d6bdc  add rsp, 0x30
00007dd8609d6be0  vmovaps xmm0, [rsp]
00007dd8609d6be5  vmovaps xmm1, [rsp+0x10]
00007dd8609d6beb  vmovaps xmm2, [rsp+0x20]
00007dd8609d6bf1  vmovaps xmm3, [rsp+0x30]
00007dd8609d6bf7  vmovaps xmm4, [rsp+0x40]
00007dd8609d6bfd  vmovaps xmm5, [rsp+0x50]
00007dd8609d6c03  vmovaps xmm6, [rsp+0x60]
00007dd8609d6c09  vmovaps xmm7, [rsp+0x70]
00007dd8609d6c0f  vmovaps xmm8, [rsp+0x80]
00007dd8609d6c18  vmovaps xmm10, [rsp+0x90]
00007dd8609d6c21  vmovaps xmm11, [rsp+0xA0]
00007dd8609d6c2a  vmovaps xmm12, [rsp+0xB0]
00007dd8609d6c33  vmovaps xmm13, [rsp+0xC0]
00007dd8609d6c3c  vmovaps xmm14, [rsp+0xD0]
00007dd8609d6c45  vmovaps xmm15, [rsp+0xE0]
00007dd8609d6c4e  add rsp, 0xF0
00007dd8609d6c55  pop r11
00007dd8609d6c57  pop r10
00007dd8609d6c59  pop r9
00007dd8609d6c5b  pop r8
00007dd8609d6c5d  pop rsi
00007dd8609d6c5e  pop rdi
00007dd8609d6c5f  pop rdx
00007dd8609d6c60  pop rcx
00007dd8609d6c61  pop rax
00007dd8609d6c62  add rsp, 0x08
00007dd8609d6c66  jmp 0x00007DD8609D321C
00007dd8609d6c6b  sub rsp, 0x08
00007dd8609d6c6f  push rax
00007dd8609d6c70  push rcx
00007dd8609d6c71  push rdx
00007dd8609d6c72  push rdi
00007dd8609d6c73  push rsi
00007dd8609d6c74  push r8
00007dd8609d6c76  push r9
00007dd8609d6c78  push r10
00007dd8609d6c7a  push r11
00007dd8609d6c7c  sub rsp, 0xF0
00007dd8609d6c83  vmovaps [rsp], xmm0
00007dd8609d6c88  vmovaps [rsp+0x10], xmm1
00007dd8609d6c8e  vmovaps [rsp+0x20], xmm2
00007dd8609d6c94  vmovaps [rsp+0x30], xmm3
00007dd8609d6c9a  vmovaps [rsp+0x40], xmm4
00007dd8609d6ca0  vmovaps [rsp+0x50], xmm5
00007dd8609d6ca6  vmovaps [rsp+0x60], xmm6
00007dd8609d6cac  vmovaps [rsp+0x70], xmm7
00007dd8609d6cb2  vmovaps [rsp+0x80], xmm8
00007dd8609d6cbb  vmovaps [rsp+0x90], xmm9
00007dd8609d6cc4  vmovaps [rsp+0xA0], xmm11
00007dd8609d6ccd  vmovaps [rsp+0xB0], xmm12
00007dd8609d6cd6  vmovaps [rsp+0xC0], xmm13
00007dd8609d6cdf  vmovaps [rsp+0xD0], xmm14
00007dd8609d6ce8  vmovaps [rsp+0xE0], xmm15
00007dd8609d6cf1  sub rsp, 0x30
00007dd8609d6cf5  movaps [rsp], xmm10
00007dd8609d6cfa  movaps [rsp+0x10], xmm1
00007dd8609d6cff  movaps [rsp+0x20], xmm11
00007dd8609d6d05  lea rdi, [rsp]
00007dd8609d6d09  mov esi, 0x00
00007dd8609d6d0e  mov rax, 0x629C9CFA9530
00007dd8609d6d18  call rax
00007dd8609d6d1a  movaps xmm10, [rsp]
00007dd8609d6d1f  add rsp, 0x30
00007dd8609d6d23  vmovaps xmm0, [rsp]
00007dd8609d6d28  vmovaps xmm1, [rsp+0x10]
00007dd8609d6d2e  vmovaps xmm2, [rsp+0x20]
00007dd8609d6d34  vmovaps xmm3, [rsp+0x30]
00007dd8609d6d3a  vmovaps xmm4, [rsp+0x40]
00007dd8609d6d40  vmovaps xmm5, [rsp+0x50]
00007dd8609d6d46  vmovaps xmm6, [rsp+0x60]
00007dd8609d6d4c  vmovaps xmm7, [rsp+0x70]
00007dd8609d6d52  vmovaps xmm8, [rsp+0x80]
00007dd8609d6d5b  vmovaps xmm9, [rsp+0x90]
00007dd8609d6d64  vmovaps xmm11, [rsp+0xA0]
00007dd8609d6d6d  vmovaps xmm12, [rsp+0xB0]
00007dd8609d6d76  vmovaps xmm13, [rsp+0xC0]
00007dd8609d6d7f  vmovaps xmm14, [rsp+0xD0]
00007dd8609d6d88  vmovaps xmm15, [rsp+0xE0]
00007dd8609d6d91  add rsp, 0xF0
00007dd8609d6d98  pop r11
00007dd8609d6d9a  pop r10
00007dd8609d6d9c  pop r9
00007dd8609d6d9e  pop r8
00007dd8609d6da0  pop rsi
00007dd8609d6da1  pop rdi
00007dd8609d6da2  pop rdx
00007dd8609d6da3  pop rcx
00007dd8609d6da4  pop rax
00007dd8609d6da5  add rsp, 0x08
00007dd8609d6da9  jmp 0x00007DD8609D3237
00007dd8609d6dae  sub rsp, 0x08
00007dd8609d6db2  push rax
00007dd8609d6db3  push rcx
00007dd8609d6db4  push rdx
00007dd8609d6db5  push rdi
00007dd8609d6db6  push rsi
00007dd8609d6db7  push r8
00007dd8609d6db9  push r9
00007dd8609d6dbb  push r10
00007dd8609d6dbd  push r11
00007dd8609d6dbf  sub rsp, 0xF0
00007dd8609d6dc6  vmovaps [rsp], xmm0
00007dd8609d6dcb  vmovaps [rsp+0x10], xmm2
00007dd8609d6dd1  vmovaps [rsp+0x20], xmm3
00007dd8609d6dd7  vmovaps [rsp+0x30], xmm4
00007dd8609d6ddd  vmovaps [rsp+0x40], xmm5
00007dd8609d6de3  vmovaps [rsp+0x50], xmm6
00007dd8609d6de9  vmovaps [rsp+0x60], xmm7
00007dd8609d6def  vmovaps [rsp+0x70], xmm8
00007dd8609d6df5  vmovaps [rsp+0x80], xmm9
00007dd8609d6dfe  vmovaps [rsp+0x90], xmm10
00007dd8609d6e07  vmovaps [rsp+0xA0], xmm11
00007dd8609d6e10  vmovaps [rsp+0xB0], xmm12
00007dd8609d6e19  vmovaps [rsp+0xC0], xmm13
00007dd8609d6e22  vmovaps [rsp+0xD0], xmm14
00007dd8609d6e2b  vmovaps [rsp+0xE0], xmm15
00007dd8609d6e34  sub rsp, 0x30
00007dd8609d6e38  movaps [rsp], xmm1
00007dd8609d6e3c  movaps [rsp+0x10], xmm15
00007dd8609d6e42  movaps [rsp+0x20], xmm6
00007dd8609d6e47  lea rdi, [rsp]
00007dd8609d6e4b  mov esi, 0x00
00007dd8609d6e50  mov rax, 0x629C9CFA9530
00007dd8609d6e5a  call rax
00007dd8609d6e5c  movaps xmm1, [rsp]
00007dd8609d6e60  add rsp, 0x30
00007dd8609d6e64  vmovaps xmm0, [rsp]
00007dd8609d6e69  vmovaps xmm2, [rsp+0x10]
00007dd8609d6e6f  vmovaps xmm3, [rsp+0x20]
00007dd8609d6e75  vmovaps xmm4, [rsp+0x30]
00007dd8609d6e7b  vmovaps xmm5, [rsp+0x40]
00007dd8609d6e81  vmovaps xmm6, [rsp+0x50]
00007dd8609d6e87  vmovaps xmm7, [rsp+0x60]
00007dd8609d6e8d  vmovaps xmm8, [rsp+0x70]
00007dd8609d6e93  vmovaps xmm9, [rsp+0x80]
00007dd8609d6e9c  vmovaps xmm10, [rsp+0x90]
00007dd8609d6ea5  vmovaps xmm11, [rsp+0xA0]
00007dd8609d6eae  vmovaps xmm12, [rsp+0xB0]
00007dd8609d6eb7  vmovaps xmm13, [rsp+0xC0]
00007dd8609d6ec0  vmovaps xmm14, [rsp+0xD0]
00007dd8609d6ec9  vmovaps xmm15, [rsp+0xE0]
00007dd8609d6ed2  add rsp, 0xF0
00007dd8609d6ed9  pop r11
00007dd8609d6edb  pop r10
00007dd8609d6edd  pop r9
00007dd8609d6edf  pop r8
00007dd8609d6ee1  pop rsi
00007dd8609d6ee2  pop rdi
00007dd8609d6ee3  pop rdx
00007dd8609d6ee4  pop rcx
00007dd8609d6ee5  pop rax
00007dd8609d6ee6  add rsp, 0x08
00007dd8609d6eea  jmp 0x00007DD8609D3250
00007dd8609d6eef  sub rsp, 0x08
00007dd8609d6ef3  push rax
00007dd8609d6ef4  push rcx
00007dd8609d6ef5  push rdx
00007dd8609d6ef6  push rdi
00007dd8609d6ef7  push rsi
00007dd8609d6ef8  push r8
00007dd8609d6efa  push r9
00007dd8609d6efc  push r10
00007dd8609d6efe  push r11
00007dd8609d6f00  sub rsp, 0xF0
00007dd8609d6f07  vmovaps [rsp], xmm0
00007dd8609d6f0c  vmovaps [rsp+0x10], xmm1
00007dd8609d6f12  vmovaps [rsp+0x20], xmm2
00007dd8609d6f18  vmovaps [rsp+0x30], xmm3
00007dd8609d6f1e  vmovaps [rsp+0x40], xmm4
00007dd8609d6f24  vmovaps [rsp+0x50], xmm5
00007dd8609d6f2a  vmovaps [rsp+0x60], xmm6
00007dd8609d6f30  vmovaps [rsp+0x70], xmm7
00007dd8609d6f36  vmovaps [rsp+0x80], xmm8
00007dd8609d6f3f  vmovaps [rsp+0x90], xmm9
00007dd8609d6f48  vmovaps [rsp+0xA0], xmm10
00007dd8609d6f51  vmovaps [rsp+0xB0], xmm12
00007dd8609d6f5a  vmovaps [rsp+0xC0], xmm13
00007dd8609d6f63  vmovaps [rsp+0xD0], xmm14
00007dd8609d6f6c  vmovaps [rsp+0xE0], xmm15
00007dd8609d6f75  sub rsp, 0x30
00007dd8609d6f79  movaps [rsp], xmm11
00007dd8609d6f7e  movaps [rsp+0x10], xmm12
00007dd8609d6f84  movaps [rsp+0x20], xmm15
00007dd8609d6f8a  lea rdi, [rsp]
00007dd8609d6f8e  mov esi, 0x00
00007dd8609d6f93  mov rax, 0x629C9CFA9530
00007dd8609d6f9d  call rax
00007dd8609d6f9f  movaps xmm11, [rsp]
00007dd8609d6fa4  add rsp, 0x30
00007dd8609d6fa8  vmovaps xmm0, [rsp]
00007dd8609d6fad  vmovaps xmm1, [rsp+0x10]
00007dd8609d6fb3  vmovaps xmm2, [rsp+0x20]
00007dd8609d6fb9  vmovaps xmm3, [rsp+0x30]
00007dd8609d6fbf  vmovaps xmm4, [rsp+0x40]
00007dd8609d6fc5  vmovaps xmm5, [rsp+0x50]
00007dd8609d6fcb  vmovaps xmm6, [rsp+0x60]
00007dd8609d6fd1  vmovaps xmm7, [rsp+0x70]
00007dd8609d6fd7  vmovaps xmm8, [rsp+0x80]
00007dd8609d6fe0  vmovaps xmm9, [rsp+0x90]
00007dd8609d6fe9  vmovaps xmm10, [rsp+0xA0]
00007dd8609d6ff2  vmovaps xmm12, [rsp+0xB0]
00007dd8609d6ffb  vmovaps xmm13, [rsp+0xC0]
00007dd8609d7004  vmovaps xmm14, [rsp+0xD0]
00007dd8609d700d  vmovaps xmm15, [rsp+0xE0]
00007dd8609d7016  add rsp, 0xF0
00007dd8609d701d  pop r11
00007dd8609d701f  pop r10
00007dd8609d7021  pop r9
00007dd8609d7023  pop r8
00007dd8609d7025  pop rsi
00007dd8609d7026  pop rdi
00007dd8609d7027  pop rdx
00007dd8609d7028  pop rcx
00007dd8609d7029  pop rax
00007dd8609d702a  add rsp, 0x08
00007dd8609d702e  jmp 0x00007DD8609D327A
00007dd8609d7033  sub rsp, 0x08
00007dd8609d7037  push rax
00007dd8609d7038  push rcx
00007dd8609d7039  push rdx
00007dd8609d703a  push rdi
00007dd8609d703b  push rsi
00007dd8609d703c  push r8
00007dd8609d703e  push r9
00007dd8609d7040  push r10
00007dd8609d7042  push r11
00007dd8609d7044  sub rsp, 0xF0
00007dd8609d704b  vmovaps [rsp], xmm0
00007dd8609d7050  vmovaps [rsp+0x10], xmm1
00007dd8609d7056  vmovaps [rsp+0x20], xmm2
00007dd8609d705c  vmovaps [rsp+0x30], xmm3
00007dd8609d7062  vmovaps [rsp+0x40], xmm4
00007dd8609d7068  vmovaps [rsp+0x50], xmm5
00007dd8609d706e  vmovaps [rsp+0x60], xmm6
00007dd8609d7074  vmovaps [rsp+0x70], xmm7
00007dd8609d707a  vmovaps [rsp+0x80], xmm8
00007dd8609d7083  vmovaps [rsp+0x90], xmm9
00007dd8609d708c  vmovaps [rsp+0xA0], xmm10
00007dd8609d7095  vmovaps [rsp+0xB0], xmm11
00007dd8609d709e  vmovaps [rsp+0xC0], xmm13
00007dd8609d70a7  vmovaps [rsp+0xD0], xmm14
00007dd8609d70b0  vmovaps [rsp+0xE0], xmm15
00007dd8609d70b9  sub rsp, 0x30
00007dd8609d70bd  movaps [rsp], xmm12
00007dd8609d70c2  movaps [rsp+0x10], xmm8
00007dd8609d70c8  movaps [rsp+0x20], xmm15
00007dd8609d70ce  lea rdi, [rsp]
00007dd8609d70d2  mov esi, 0x00
00007dd8609d70d7  mov rax, 0x629C9CFA9530
00007dd8609d70e1  call rax
00007dd8609d70e3  movaps xmm12, [rsp]
00007dd8609d70e8  add rsp, 0x30
00007dd8609d70ec  vmovaps xmm0, [rsp]
00007dd8609d70f1  vmovaps xmm1, [rsp+0x10]
00007dd8609d70f7  vmovaps xmm2, [rsp+0x20]
00007dd8609d70fd  vmovaps xmm3, [rsp+0x30]
00007dd8609d7103  vmovaps xmm4, [rsp+0x40]
00007dd8609d7109  vmovaps xmm5, [rsp+0x50]
00007dd8609d710f  vmovaps xmm6, [rsp+0x60]
00007dd8609d7115  vmovaps xmm7, [rsp+0x70]
00007dd8609d711b  vmovaps xmm8, [rsp+0x80]
00007dd8609d7124  vmovaps xmm9, [rsp+0x90]
00007dd8609d712d  vmovaps xmm10, [rsp+0xA0]
00007dd8609d7136  vmovaps xmm11, [rsp+0xB0]
00007dd8609d713f  vmovaps xmm13, [rsp+0xC0]
00007dd8609d7148  vmovaps xmm14, [rsp+0xD0]
00007dd8609d7151  vmovaps xmm15, [rsp+0xE0]
00007dd8609d715a  add rsp, 0xF0
00007dd8609d7161  pop r11
00007dd8609d7163  pop r10
00007dd8609d7165  pop r9
00007dd8609d7167  pop r8
00007dd8609d7169  pop rsi
00007dd8609d716a  pop rdi
00007dd8609d716b  pop rdx
00007dd8609d716c  pop rcx
00007dd8609d716d  pop rax
00007dd8609d716e  add rsp, 0x08
00007dd8609d7172  jmp 0x00007DD8609D32A9
00007dd8609d7177  sub rsp, 0x08
00007dd8609d717b  push rax
00007dd8609d717c  push rcx
00007dd8609d717d  push rdx
00007dd8609d717e  push rdi
00007dd8609d717f  push rsi
00007dd8609d7180  push r8
00007dd8609d7182  push r9
00007dd8609d7184  push r10
00007dd8609d7186  push r11
00007dd8609d7188  sub rsp, 0xF0
00007dd8609d718f  vmovaps [rsp], xmm0
00007dd8609d7194  vmovaps [rsp+0x10], xmm1
00007dd8609d719a  vmovaps [rsp+0x20], xmm2
00007dd8609d71a0  vmovaps [rsp+0x30], xmm3
00007dd8609d71a6  vmovaps [rsp+0x40], xmm4
00007dd8609d71ac  vmovaps [rsp+0x50], xmm5
00007dd8609d71b2  vmovaps [rsp+0x60], xmm6
00007dd8609d71b8  vmovaps [rsp+0x70], xmm7
00007dd8609d71be  vmovaps [rsp+0x80], xmm9
00007dd8609d71c7  vmovaps [rsp+0x90], xmm10
00007dd8609d71d0  vmovaps [rsp+0xA0], xmm11
00007dd8609d71d9  vmovaps [rsp+0xB0], xmm12
00007dd8609d71e2  vmovaps [rsp+0xC0], xmm13
00007dd8609d71eb  vmovaps [rsp+0xD0], xmm14
00007dd8609d71f4  vmovaps [rsp+0xE0], xmm15
00007dd8609d71fd  sub rsp, 0x30
00007dd8609d7201  movaps [rsp], xmm8
00007dd8609d7206  movaps [rsp+0x10], xmm7
00007dd8609d720b  movaps [rsp+0x20], xmm15
00007dd8609d7211  lea rdi, [rsp]
00007dd8609d7215  mov esi, 0x00
00007dd8609d721a  mov rax, 0x629C9CFA9530
00007dd8609d7224  call rax
00007dd8609d7226  movaps xmm8, [rsp]
00007dd8609d722b  add rsp, 0x30
00007dd8609d722f  vmovaps xmm0, [rsp]
00007dd8609d7234  vmovaps xmm1, [rsp+0x10]
00007dd8609d723a  vmovaps xmm2, [rsp+0x20]
00007dd8609d7240  vmovaps xmm3, [rsp+0x30]
00007dd8609d7246  vmovaps xmm4, [rsp+0x40]
00007dd8609d724c  vmovaps xmm5, [rsp+0x50]
00007dd8609d7252  vmovaps xmm6, [rsp+0x60]
00007dd8609d7258  vmovaps xmm7, [rsp+0x70]
00007dd8609d725e  vmovaps xmm9, [rsp+0x80]
00007dd8609d7267  vmovaps xmm10, [rsp+0x90]
00007dd8609d7270  vmovaps xmm11, [rsp+0xA0]
00007dd8609d7279  vmovaps xmm12, [rsp+0xB0]
00007dd8609d7282  vmovaps xmm13, [rsp+0xC0]
00007dd8609d728b  vmovaps xmm14, [rsp+0xD0]
00007dd8609d7294  vmovaps xmm15, [rsp+0xE0]
00007dd8609d729d  add rsp, 0xF0
00007dd8609d72a4  pop r11
00007dd8609d72a6  pop r10
00007dd8609d72a8  pop r9
00007dd8609d72aa  pop r8
00007dd8609d72ac  pop rsi
00007dd8609d72ad  pop rdi
00007dd8609d72ae  pop rdx
00007dd8609d72af  pop rcx
00007dd8609d72b0  pop rax
00007dd8609d72b1  add rsp, 0x08
00007dd8609d72b5  jmp 0x00007DD8609D32CF
00007dd8609d72ba  sub rsp, 0x08
00007dd8609d72be  push rax
00007dd8609d72bf  push rcx
00007dd8609d72c0  push rdx
00007dd8609d72c1  push rdi
00007dd8609d72c2  push rsi
00007dd8609d72c3  push r8
00007dd8609d72c5  push r9
00007dd8609d72c7  push r10
00007dd8609d72c9  push r11
00007dd8609d72cb  sub rsp, 0xF0
00007dd8609d72d2  vmovaps [rsp], xmm0
00007dd8609d72d7  vmovaps [rsp+0x10], xmm1
00007dd8609d72dd  vmovaps [rsp+0x20], xmm2
00007dd8609d72e3  vmovaps [rsp+0x30], xmm3
00007dd8609d72e9  vmovaps [rsp+0x40], xmm4
00007dd8609d72ef  vmovaps [rsp+0x50], xmm5
00007dd8609d72f5  vmovaps [rsp+0x60], xmm6
00007dd8609d72fb  vmovaps [rsp+0x70], xmm7
00007dd8609d7301  vmovaps [rsp+0x80], xmm8
00007dd8609d730a  vmovaps [rsp+0x90], xmm9
00007dd8609d7313  vmovaps [rsp+0xA0], xmm10
00007dd8609d731c  vmovaps [rsp+0xB0], xmm11
00007dd8609d7325  vmovaps [rsp+0xC0], xmm12
00007dd8609d732e  vmovaps [rsp+0xD0], xmm13
00007dd8609d7337  vmovaps [rsp+0xE0], xmm14
00007dd8609d7340  sub rsp, 0x30
00007dd8609d7344  movaps [rsp], xmm15
00007dd8609d7349  movaps [rsp+0x10], xmm14
00007dd8609d734f  movaps [rsp+0x20], xmm9
00007dd8609d7355  lea rdi, [rsp]
00007dd8609d7359  mov esi, 0x00
00007dd8609d735e  mov rax, 0x629C9CFA9530
00007dd8609d7368  call rax
00007dd8609d736a  movaps xmm15, [rsp]
00007dd8609d736f  add rsp, 0x30
00007dd8609d7373  vmovaps xmm0, [rsp]
00007dd8609d7378  vmovaps xmm1, [rsp+0x10]
00007dd8609d737e  vmovaps xmm2, [rsp+0x20]
00007dd8609d7384  vmovaps xmm3, [rsp+0x30]
00007dd8609d738a  vmovaps xmm4, [rsp+0x40]
00007dd8609d7390  vmovaps xmm5, [rsp+0x50]
00007dd8609d7396  vmovaps xmm6, [rsp+0x60]
00007dd8609d739c  vmovaps xmm7, [rsp+0x70]
00007dd8609d73a2  vmovaps xmm8, [rsp+0x80]
00007dd8609d73ab  vmovaps xmm9, [rsp+0x90]
00007dd8609d73b4  vmovaps xmm10, [rsp+0xA0]
00007dd8609d73bd  vmovaps xmm11, [rsp+0xB0]
00007dd8609d73c6  vmovaps xmm12, [rsp+0xC0]
00007dd8609d73cf  vmovaps xmm13, [rsp+0xD0]
00007dd8609d73d8  vmovaps xmm14, [rsp+0xE0]
00007dd8609d73e1  add rsp, 0xF0
00007dd8609d73e8  pop r11
00007dd8609d73ea  pop r10
00007dd8609d73ec  pop r9
00007dd8609d73ee  pop r8
00007dd8609d73f0  pop rsi
00007dd8609d73f1  pop rdi
00007dd8609d73f2  pop rdx
00007dd8609d73f3  pop rcx
00007dd8609d73f4  pop rax
00007dd8609d73f5  add rsp, 0x08
00007dd8609d73f9  jmp 0x00007DD8609D32E9
00007dd8609d73fe  sub rsp, 0x08
00007dd8609d7402  push rax
00007dd8609d7403  push rcx
00007dd8609d7404  push rdx
00007dd8609d7405  push rdi
00007dd8609d7406  push rsi
00007dd8609d7407  push r8
00007dd8609d7409  push r9
00007dd8609d740b  push r10
00007dd8609d740d  push r11
00007dd8609d740f  sub rsp, 0xF0
00007dd8609d7416  vmovaps [rsp], xmm0
00007dd8609d741b  vmovaps [rsp+0x10], xmm1
00007dd8609d7421  vmovaps [rsp+0x20], xmm2
00007dd8609d7427  vmovaps [rsp+0x30], xmm3
00007dd8609d742d  vmovaps [rsp+0x40], xmm4
00007dd8609d7433  vmovaps [rsp+0x50], xmm5
00007dd8609d7439  vmovaps [rsp+0x60], xmm6
00007dd8609d743f  vmovaps [rsp+0x70], xmm7
00007dd8609d7445  vmovaps [rsp+0x80], xmm8
00007dd8609d744e  vmovaps [rsp+0x90], xmm10
00007dd8609d7457  vmovaps [rsp+0xA0], xmm11
00007dd8609d7460  vmovaps [rsp+0xB0], xmm12
00007dd8609d7469  vmovaps [rsp+0xC0], xmm13
00007dd8609d7472  vmovaps [rsp+0xD0], xmm14
00007dd8609d747b  vmovaps [rsp+0xE0], xmm15
00007dd8609d7484  sub rsp, 0x30
00007dd8609d7488  movaps [rsp], xmm9
00007dd8609d748d  movaps [rsp+0x10], xmm7
00007dd8609d7492  movaps [rsp+0x20], xmm14
00007dd8609d7498  lea rdi, [rsp]
00007dd8609d749c  mov esi, 0x00
00007dd8609d74a1  mov rax, 0x629C9CFA9530
00007dd8609d74ab  call rax
00007dd8609d74ad  movaps xmm9, [rsp]
00007dd8609d74b2  add rsp, 0x30
00007dd8609d74b6  vmovaps xmm0, [rsp]
00007dd8609d74bb  vmovaps xmm1, [rsp+0x10]
00007dd8609d74c1  vmovaps xmm2, [rsp+0x20]
00007dd8609d74c7  vmovaps xmm3, [rsp+0x30]
00007dd8609d74cd  vmovaps xmm4, [rsp+0x40]
00007dd8609d74d3  vmovaps xmm5, [rsp+0x50]
00007dd8609d74d9  vmovaps xmm6, [rsp+0x60]
00007dd8609d74df  vmovaps xmm7, [rsp+0x70]
00007dd8609d74e5  vmovaps xmm8, [rsp+0x80]
00007dd8609d74ee  vmovaps xmm10, [rsp+0x90]
00007dd8609d74f7  vmovaps xmm11, [rsp+0xA0]
00007dd8609d7500  vmovaps xmm12, [rsp+0xB0]
00007dd8609d7509  vmovaps xmm13, [rsp+0xC0]
00007dd8609d7512  vmovaps xmm14, [rsp+0xD0]
00007dd8609d751b  vmovaps xmm15, [rsp+0xE0]
00007dd8609d7524  add rsp, 0xF0
00007dd8609d752b  pop r11
00007dd8609d752d  pop r10
00007dd8609d752f  pop r9
00007dd8609d7531  pop r8
00007dd8609d7533  pop rsi
00007dd8609d7534  pop rdi
00007dd8609d7535  pop rdx
00007dd8609d7536  pop rcx
00007dd8609d7537  pop rax
00007dd8609d7538  add rsp, 0x08
00007dd8609d753c  jmp 0x00007DD8609D3318
00007dd8609d7541  sub rsp, 0x08
00007dd8609d7545  push rax
00007dd8609d7546  push rcx
00007dd8609d7547  push rdx
00007dd8609d7548  push rdi
00007dd8609d7549  push rsi
00007dd8609d754a  push r8
00007dd8609d754c  push r9
00007dd8609d754e  push r10
00007dd8609d7550  push r11
00007dd8609d7552  sub rsp, 0xF0
00007dd8609d7559  vmovaps [rsp], xmm0
00007dd8609d755e  vmovaps [rsp+0x10], xmm1
00007dd8609d7564  vmovaps [rsp+0x20], xmm2
00007dd8609d756a  vmovaps [rsp+0x30], xmm3
00007dd8609d7570  vmovaps [rsp+0x40], xmm4
00007dd8609d7576  vmovaps [rsp+0x50], xmm5
00007dd8609d757c  vmovaps [rsp+0x60], xmm6
00007dd8609d7582  vmovaps [rsp+0x70], xmm7
00007dd8609d7588  vmovaps [rsp+0x80], xmm8
00007dd8609d7591  vmovaps [rsp+0x90], xmm9
00007dd8609d759a  vmovaps [rsp+0xA0], xmm10
00007dd8609d75a3  vmovaps [rsp+0xB0], xmm11
00007dd8609d75ac  vmovaps [rsp+0xC0], xmm12
00007dd8609d75b5  vmovaps [rsp+0xD0], xmm13
00007dd8609d75be  vmovaps [rsp+0xE0], xmm15
00007dd8609d75c7  sub rsp, 0x30
00007dd8609d75cb  movaps [rsp], xmm14
00007dd8609d75d0  movaps [rsp+0x10], xmm13
00007dd8609d75d6  movaps [rsp+0x20], xmm11
00007dd8609d75dc  lea rdi, [rsp]
00007dd8609d75e0  mov esi, 0x00
00007dd8609d75e5  mov rax, 0x629C9CFA9530
00007dd8609d75ef  call rax
00007dd8609d75f1  movaps xmm14, [rsp]
00007dd8609d75f6  add rsp, 0x30
00007dd8609d75fa  vmovaps xmm0, [rsp]
00007dd8609d75ff  vmovaps xmm1, [rsp+0x10]
00007dd8609d7605  vmovaps xmm2, [rsp+0x20]
00007dd8609d760b  vmovaps xmm3, [rsp+0x30]
00007dd8609d7611  vmovaps xmm4, [rsp+0x40]
00007dd8609d7617  vmovaps xmm5, [rsp+0x50]
00007dd8609d761d  vmovaps xmm6, [rsp+0x60]
00007dd8609d7623  vmovaps xmm7, [rsp+0x70]
00007dd8609d7629  vmovaps xmm8, [rsp+0x80]
00007dd8609d7632  vmovaps xmm9, [rsp+0x90]
00007dd8609d763b  vmovaps xmm10, [rsp+0xA0]
00007dd8609d7644  vmovaps xmm11, [rsp+0xB0]
00007dd8609d764d  vmovaps xmm12, [rsp+0xC0]
00007dd8609d7656  vmovaps xmm13, [rsp+0xD0]
00007dd8609d765f  vmovaps xmm15, [rsp+0xE0]
00007dd8609d7668  add rsp, 0xF0
00007dd8609d766f  pop r11
00007dd8609d7671  pop r10
00007dd8609d7673  pop r9
00007dd8609d7675  pop r8
00007dd8609d7677  pop rsi
00007dd8609d7678  pop rdi
00007dd8609d7679  pop rdx
00007dd8609d767a  pop rcx
00007dd8609d767b  pop rax
00007dd8609d767c  add rsp, 0x08
00007dd8609d7680  jmp 0x00007DD8609D3332
00007dd8609d7685  sub rsp, 0x08
00007dd8609d7689  push rax
00007dd8609d768a  push rcx
00007dd8609d768b  push rdx
00007dd8609d768c  push rdi
00007dd8609d768d  push rsi
00007dd8609d768e  push r8
00007dd8609d7690  push r9
00007dd8609d7692  push r10
00007dd8609d7694  push r11
00007dd8609d7696  sub rsp, 0xF0
00007dd8609d769d  vmovaps [rsp], xmm0
00007dd8609d76a2  vmovaps [rsp+0x10], xmm1
00007dd8609d76a8  vmovaps [rsp+0x20], xmm2
00007dd8609d76ae  vmovaps [rsp+0x30], xmm3
00007dd8609d76b4  vmovaps [rsp+0x40], xmm4
00007dd8609d76ba  vmovaps [rsp+0x50], xmm5
00007dd8609d76c0  vmovaps [rsp+0x60], xmm6
00007dd8609d76c6  vmovaps [rsp+0x70], xmm7
00007dd8609d76cc  vmovaps [rsp+0x80], xmm8
00007dd8609d76d5  vmovaps [rsp+0x90], xmm9
00007dd8609d76de  vmovaps [rsp+0xA0], xmm10
00007dd8609d76e7  vmovaps [rsp+0xB0], xmm12
00007dd8609d76f0  vmovaps [rsp+0xC0], xmm13
00007dd8609d76f9  vmovaps [rsp+0xD0], xmm14
00007dd8609d7702  vmovaps [rsp+0xE0], xmm15
00007dd8609d770b  sub rsp, 0x30
00007dd8609d770f  movaps [rsp], xmm11
00007dd8609d7714  movaps [rsp+0x10], xmm7
00007dd8609d7719  movaps [rsp+0x20], xmm13
00007dd8609d771f  lea rdi, [rsp]
00007dd8609d7723  mov esi, 0x00
00007dd8609d7728  mov rax, 0x629C9CFA9530
00007dd8609d7732  call rax
00007dd8609d7734  movaps xmm11, [rsp]
00007dd8609d7739  add rsp, 0x30
00007dd8609d773d  vmovaps xmm0, [rsp]
00007dd8609d7742  vmovaps xmm1, [rsp+0x10]
00007dd8609d7748  vmovaps xmm2, [rsp+0x20]
00007dd8609d774e  vmovaps xmm3, [rsp+0x30]
00007dd8609d7754  vmovaps xmm4, [rsp+0x40]
00007dd8609d775a  vmovaps xmm5, [rsp+0x50]
00007dd8609d7760  vmovaps xmm6, [rsp+0x60]
00007dd8609d7766  vmovaps xmm7, [rsp+0x70]
00007dd8609d776c  vmovaps xmm8, [rsp+0x80]
00007dd8609d7775  vmovaps xmm9, [rsp+0x90]
00007dd8609d777e  vmovaps xmm10, [rsp+0xA0]
00007dd8609d7787  vmovaps xmm12, [rsp+0xB0]
00007dd8609d7790  vmovaps xmm13, [rsp+0xC0]
00007dd8609d7799  vmovaps xmm14, [rsp+0xD0]
00007dd8609d77a2  vmovaps xmm15, [rsp+0xE0]
00007dd8609d77ab  add rsp, 0xF0
00007dd8609d77b2  pop r11
00007dd8609d77b4  pop r10
00007dd8609d77b6  pop r9
00007dd8609d77b8  pop r8
00007dd8609d77ba  pop rsi
00007dd8609d77bb  pop rdi
00007dd8609d77bc  pop rdx
00007dd8609d77bd  pop rcx
00007dd8609d77be  pop rax
00007dd8609d77bf  add rsp, 0x08
00007dd8609d77c3  jmp 0x00007DD8609D335E
00007dd8609d77c8  sub rsp, 0x08
00007dd8609d77cc  push rax
00007dd8609d77cd  push rcx
00007dd8609d77ce  push rdx
00007dd8609d77cf  push rdi
00007dd8609d77d0  push rsi
00007dd8609d77d1  push r8
00007dd8609d77d3  push r9
00007dd8609d77d5  push r10
00007dd8609d77d7  push r11
00007dd8609d77d9  sub rsp, 0xF0
00007dd8609d77e0  vmovaps [rsp], xmm0
00007dd8609d77e5  vmovaps [rsp+0x10], xmm1
00007dd8609d77eb  vmovaps [rsp+0x20], xmm2
00007dd8609d77f1  vmovaps [rsp+0x30], xmm3
00007dd8609d77f7  vmovaps [rsp+0x40], xmm4
00007dd8609d77fd  vmovaps [rsp+0x50], xmm5
00007dd8609d7803  vmovaps [rsp+0x60], xmm6
00007dd8609d7809  vmovaps [rsp+0x70], xmm7
00007dd8609d780f  vmovaps [rsp+0x80], xmm8
00007dd8609d7818  vmovaps [rsp+0x90], xmm9
00007dd8609d7821  vmovaps [rsp+0xA0], xmm10
00007dd8609d782a  vmovaps [rsp+0xB0], xmm11
00007dd8609d7833  vmovaps [rsp+0xC0], xmm12
00007dd8609d783c  vmovaps [rsp+0xD0], xmm14
00007dd8609d7845  vmovaps [rsp+0xE0], xmm15
00007dd8609d784e  sub rsp, 0x30
00007dd8609d7852  movaps [rsp], xmm13
00007dd8609d7857  movaps [rsp+0x10], xmm10
00007dd8609d785d  movaps [rsp+0x20], xmm12
00007dd8609d7863  lea rdi, [rsp]
00007dd8609d7867  mov esi, 0x00
00007dd8609d786c  mov rax, 0x629C9CFA9530
00007dd8609d7876  call rax
00007dd8609d7878  movaps xmm13, [rsp]
00007dd8609d787d  add rsp, 0x30
00007dd8609d7881  vmovaps xmm0, [rsp]
00007dd8609d7886  vmovaps xmm1, [rsp+0x10]
00007dd8609d788c  vmovaps xmm2, [rsp+0x20]
00007dd8609d7892  vmovaps xmm3, [rsp+0x30]
00007dd8609d7898  vmovaps xmm4, [rsp+0x40]
00007dd8609d789e  vmovaps xmm5, [rsp+0x50]
00007dd8609d78a4  vmovaps xmm6, [rsp+0x60]
00007dd8609d78aa  vmovaps xmm7, [rsp+0x70]
00007dd8609d78b0  vmovaps xmm8, [rsp+0x80]
00007dd8609d78b9  vmovaps xmm9, [rsp+0x90]
00007dd8609d78c2  vmovaps xmm10, [rsp+0xA0]
00007dd8609d78cb  vmovaps xmm11, [rsp+0xB0]
00007dd8609d78d4  vmovaps xmm12, [rsp+0xC0]
00007dd8609d78dd  vmovaps xmm14, [rsp+0xD0]
00007dd8609d78e6  vmovaps xmm15, [rsp+0xE0]
00007dd8609d78ef  add rsp, 0xF0
00007dd8609d78f6  pop r11
00007dd8609d78f8  pop r10
00007dd8609d78fa  pop r9
00007dd8609d78fc  pop r8
00007dd8609d78fe  pop rsi
00007dd8609d78ff  pop rdi
00007dd8609d7900  pop rdx
00007dd8609d7901  pop rcx
00007dd8609d7902  pop rax
00007dd8609d7903  add rsp, 0x08
00007dd8609d7907  jmp 0x00007DD8609D3378
00007dd8609d790c  sub rsp, 0x08
00007dd8609d7910  push rax
00007dd8609d7911  push rcx
00007dd8609d7912  push rdx
00007dd8609d7913  push rdi
00007dd8609d7914  push rsi
00007dd8609d7915  push r8
00007dd8609d7917  push r9
00007dd8609d7919  push r10
00007dd8609d791b  push r11
00007dd8609d791d  sub rsp, 0xF0
00007dd8609d7924  vmovaps [rsp], xmm0
00007dd8609d7929  vmovaps [rsp+0x10], xmm1
00007dd8609d792f  vmovaps [rsp+0x20], xmm2
00007dd8609d7935  vmovaps [rsp+0x30], xmm3
00007dd8609d793b  vmovaps [rsp+0x40], xmm4
00007dd8609d7941  vmovaps [rsp+0x50], xmm5
00007dd8609d7947  vmovaps [rsp+0x60], xmm6
00007dd8609d794d  vmovaps [rsp+0x70], xmm7
00007dd8609d7953  vmovaps [rsp+0x80], xmm8
00007dd8609d795c  vmovaps [rsp+0x90], xmm9
00007dd8609d7965  vmovaps [rsp+0xA0], xmm11
00007dd8609d796e  vmovaps [rsp+0xB0], xmm12
00007dd8609d7977  vmovaps [rsp+0xC0], xmm13
00007dd8609d7980  vmovaps [rsp+0xD0], xmm14
00007dd8609d7989  vmovaps [rsp+0xE0], xmm15
00007dd8609d7992  sub rsp, 0x30
00007dd8609d7996  movaps [rsp], xmm10
00007dd8609d799b  movaps [rsp+0x10], xmm7
00007dd8609d79a0  movaps [rsp+0x20], xmm12
00007dd8609d79a6  lea rdi, [rsp]
00007dd8609d79aa  mov esi, 0x00
00007dd8609d79af  mov rax, 0x629C9CFA9530
00007dd8609d79b9  call rax
00007dd8609d79bb  movaps xmm10, [rsp]
00007dd8609d79c0  add rsp, 0x30
00007dd8609d79c4  vmovaps xmm0, [rsp]
00007dd8609d79c9  vmovaps xmm1, [rsp+0x10]
00007dd8609d79cf  vmovaps xmm2, [rsp+0x20]
00007dd8609d79d5  vmovaps xmm3, [rsp+0x30]
00007dd8609d79db  vmovaps xmm4, [rsp+0x40]
00007dd8609d79e1  vmovaps xmm5, [rsp+0x50]
00007dd8609d79e7  vmovaps xmm6, [rsp+0x60]
00007dd8609d79ed  vmovaps xmm7, [rsp+0x70]
00007dd8609d79f3  vmovaps xmm8, [rsp+0x80]
00007dd8609d79fc  vmovaps xmm9, [rsp+0x90]
00007dd8609d7a05  vmovaps xmm11, [rsp+0xA0]
00007dd8609d7a0e  vmovaps xmm12, [rsp+0xB0]
00007dd8609d7a17  vmovaps xmm13, [rsp+0xC0]
00007dd8609d7a20  vmovaps xmm14, [rsp+0xD0]
00007dd8609d7a29  vmovaps xmm15, [rsp+0xE0]
00007dd8609d7a32  add rsp, 0xF0
00007dd8609d7a39  pop r11
00007dd8609d7a3b  pop r10
00007dd8609d7a3d  pop r9
00007dd8609d7a3f  pop r8
00007dd8609d7a41  pop rsi
00007dd8609d7a42  pop rdi
00007dd8609d7a43  pop rdx
00007dd8609d7a44  pop rcx
00007dd8609d7a45  pop rax
00007dd8609d7a46  add rsp, 0x08
00007dd8609d7a4a  jmp 0x00007DD8609D33A4
00007dd8609d7a4f  sub rsp, 0x08
00007dd8609d7a53  push rax
00007dd8609d7a54  push rcx
00007dd8609d7a55  push rdx
00007dd8609d7a56  push rdi
00007dd8609d7a57  push rsi
00007dd8609d7a58  push r8
00007dd8609d7a5a  push r9
00007dd8609d7a5c  push r10
00007dd8609d7a5e  push r11
00007dd8609d7a60  sub rsp, 0xF0
00007dd8609d7a67  vmovaps [rsp], xmm0
00007dd8609d7a6c  vmovaps [rsp+0x10], xmm1
00007dd8609d7a72  vmovaps [rsp+0x20], xmm2
00007dd8609d7a78  vmovaps [rsp+0x30], xmm3
00007dd8609d7a7e  vmovaps [rsp+0x40], xmm4
00007dd8609d7a84  vmovaps [rsp+0x50], xmm5
00007dd8609d7a8a  vmovaps [rsp+0x60], xmm6
00007dd8609d7a90  vmovaps [rsp+0x70], xmm7
00007dd8609d7a96  vmovaps [rsp+0x80], xmm8
00007dd8609d7a9f  vmovaps [rsp+0x90], xmm9
00007dd8609d7aa8  vmovaps [rsp+0xA0], xmm10
00007dd8609d7ab1  vmovaps [rsp+0xB0], xmm11
00007dd8609d7aba  vmovaps [rsp+0xC0], xmm13
00007dd8609d7ac3  vmovaps [rsp+0xD0], xmm14
00007dd8609d7acc  vmovaps [rsp+0xE0], xmm15
00007dd8609d7ad5  sub rsp, 0x30
00007dd8609d7ad9  movaps [rsp], xmm12
00007dd8609d7ade  movaps [rsp+0x10], xmm1
00007dd8609d7ae3  movaps [rsp+0x20], xmm8
00007dd8609d7ae9  lea rdi, [rsp]
00007dd8609d7aed  mov esi, 0x00
00007dd8609d7af2  mov rax, 0x629C9CFA9530
00007dd8609d7afc  call rax
00007dd8609d7afe  movaps xmm12, [rsp]
00007dd8609d7b03  add rsp, 0x30
00007dd8609d7b07  vmovaps xmm0, [rsp]
00007dd8609d7b0c  vmovaps xmm1, [rsp+0x10]
00007dd8609d7b12  vmovaps xmm2, [rsp+0x20]
00007dd8609d7b18  vmovaps xmm3, [rsp+0x30]
00007dd8609d7b1e  vmovaps xmm4, [rsp+0x40]
00007dd8609d7b24  vmovaps xmm5, [rsp+0x50]
00007dd8609d7b2a  vmovaps xmm6, [rsp+0x60]
00007dd8609d7b30  vmovaps xmm7, [rsp+0x70]
00007dd8609d7b36  vmovaps xmm8, [rsp+0x80]
00007dd8609d7b3f  vmovaps xmm9, [rsp+0x90]
00007dd8609d7b48  vmovaps xmm10, [rsp+0xA0]
00007dd8609d7b51  vmovaps xmm11, [rsp+0xB0]
00007dd8609d7b5a  vmovaps xmm13, [rsp+0xC0]
00007dd8609d7b63  vmovaps xmm14, [rsp+0xD0]
00007dd8609d7b6c  vmovaps xmm15, [rsp+0xE0]
00007dd8609d7b75  add rsp, 0xF0
00007dd8609d7b7c  pop r11
00007dd8609d7b7e  pop r10
00007dd8609d7b80  pop r9
00007dd8609d7b82  pop r8
00007dd8609d7b84  pop rsi
00007dd8609d7b85  pop rdi
00007dd8609d7b86  pop rdx
00007dd8609d7b87  pop rcx
00007dd8609d7b88  pop rax
00007dd8609d7b89  add rsp, 0x08
00007dd8609d7b8d  jmp 0x00007DD8609D33BE
00007dd8609d7b92  call 0x00007DD8607FF430
00007dd8609d7b97  jmp 0x00007DD8609D33C8
00007dd8609d7b9c  sub rsp, 0x08
00007dd8609d7ba0  push rax
00007dd8609d7ba1  push rcx
00007dd8609d7ba2  push rdx
00007dd8609d7ba3  push rdi
00007dd8609d7ba4  push rsi
00007dd8609d7ba5  push r8
00007dd8609d7ba7  push r9
00007dd8609d7ba9  push r10
00007dd8609d7bab  push r11
00007dd8609d7bad  sub rsp, 0xF0
00007dd8609d7bb4  vmovaps [rsp], xmm0
00007dd8609d7bb9  vmovaps [rsp+0x10], xmm1
00007dd8609d7bbf  vmovaps [rsp+0x20], xmm2
00007dd8609d7bc5  vmovaps [rsp+0x30], xmm3
00007dd8609d7bcb  vmovaps [rsp+0x40], xmm4
00007dd8609d7bd1  vmovaps [rsp+0x50], xmm5
00007dd8609d7bd7  vmovaps [rsp+0x60], xmm6
00007dd8609d7bdd  vmovaps [rsp+0x70], xmm7
00007dd8609d7be3  vmovaps [rsp+0x80], xmm9
00007dd8609d7bec  vmovaps [rsp+0x90], xmm10
00007dd8609d7bf5  vmovaps [rsp+0xA0], xmm11
00007dd8609d7bfe  vmovaps [rsp+0xB0], xmm12
00007dd8609d7c07  vmovaps [rsp+0xC0], xmm13
00007dd8609d7c10  vmovaps [rsp+0xD0], xmm14
00007dd8609d7c19  vmovaps [rsp+0xE0], xmm15
00007dd8609d7c22  sub rsp, 0x30
00007dd8609d7c26  movaps [rsp], xmm8
00007dd8609d7c2b  movaps [rsp+0x10], xmm15
00007dd8609d7c31  movaps [rsp+0x20], xmm9
00007dd8609d7c37  lea rdi, [rsp]
00007dd8609d7c3b  mov esi, 0x00
00007dd8609d7c40  mov rax, 0x629C9CFA9530
00007dd8609d7c4a  call rax
00007dd8609d7c4c  movaps xmm8, [rsp]
00007dd8609d7c51  add rsp, 0x30
00007dd8609d7c55  vmovaps xmm0, [rsp]
00007dd8609d7c5a  vmovaps xmm1, [rsp+0x10]
00007dd8609d7c60  vmovaps xmm2, [rsp+0x20]
00007dd8609d7c66  vmovaps xmm3, [rsp+0x30]
00007dd8609d7c6c  vmovaps xmm4, [rsp+0x40]
00007dd8609d7c72  vmovaps xmm5, [rsp+0x50]
00007dd8609d7c78  vmovaps xmm6, [rsp+0x60]
00007dd8609d7c7e  vmovaps xmm7, [rsp+0x70]
00007dd8609d7c84  vmovaps xmm9, [rsp+0x80]
00007dd8609d7c8d  vmovaps xmm10, [rsp+0x90]
00007dd8609d7c96  vmovaps xmm11, [rsp+0xA0]
00007dd8609d7c9f  vmovaps xmm12, [rsp+0xB0]
00007dd8609d7ca8  vmovaps xmm13, [rsp+0xC0]
00007dd8609d7cb1  vmovaps xmm14, [rsp+0xD0]
00007dd8609d7cba  vmovaps xmm15, [rsp+0xE0]
00007dd8609d7cc3  add rsp, 0xF0
00007dd8609d7cca  pop r11
00007dd8609d7ccc  pop r10
00007dd8609d7cce  pop r9
00007dd8609d7cd0  pop r8
00007dd8609d7cd2  pop rsi
00007dd8609d7cd3  pop rdi
00007dd8609d7cd4  pop rdx
00007dd8609d7cd5  pop rcx
00007dd8609d7cd6  pop rax
00007dd8609d7cd7  add rsp, 0x08
00007dd8609d7cdb  jmp 0x00007DD8609D33EA
00007dd8609d7ce0  sub rsp, 0x08
00007dd8609d7ce4  push rax
00007dd8609d7ce5  push rcx
00007dd8609d7ce6  push rdx
00007dd8609d7ce7  push rdi
00007dd8609d7ce8  push rsi
00007dd8609d7ce9  push r8
00007dd8609d7ceb  push r9
00007dd8609d7ced  push r10
00007dd8609d7cef  push r11
00007dd8609d7cf1  sub rsp, 0xF0
00007dd8609d7cf8  vmovaps [rsp], xmm0
00007dd8609d7cfd  vmovaps [rsp+0x10], xmm1
00007dd8609d7d03  vmovaps [rsp+0x20], xmm2
00007dd8609d7d09  vmovaps [rsp+0x30], xmm3
00007dd8609d7d0f  vmovaps [rsp+0x40], xmm4
00007dd8609d7d15  vmovaps [rsp+0x50], xmm5
00007dd8609d7d1b  vmovaps [rsp+0x60], xmm6
00007dd8609d7d21  vmovaps [rsp+0x70], xmm7
00007dd8609d7d27  vmovaps [rsp+0x80], xmm8
00007dd8609d7d30  vmovaps [rsp+0x90], xmm10
00007dd8609d7d39  vmovaps [rsp+0xA0], xmm11
00007dd8609d7d42  vmovaps [rsp+0xB0], xmm12
00007dd8609d7d4b  vmovaps [rsp+0xC0], xmm13
00007dd8609d7d54  vmovaps [rsp+0xD0], xmm14
00007dd8609d7d5d  vmovaps [rsp+0xE0], xmm15
00007dd8609d7d66  sub rsp, 0x30
00007dd8609d7d6a  movaps [rsp], xmm9
00007dd8609d7d6f  movaps [rsp+0x10], xmm1
00007dd8609d7d74  movaps [rsp+0x20], xmm15
00007dd8609d7d7a  lea rdi, [rsp]
00007dd8609d7d7e  mov esi, 0x00
00007dd8609d7d83  mov rax, 0x629C9CFA9530
00007dd8609d7d8d  call rax
00007dd8609d7d8f  movaps xmm9, [rsp]
00007dd8609d7d94  add rsp, 0x30
00007dd8609d7d98  vmovaps xmm0, [rsp]
00007dd8609d7d9d  vmovaps xmm1, [rsp+0x10]
00007dd8609d7da3  vmovaps xmm2, [rsp+0x20]
00007dd8609d7da9  vmovaps xmm3, [rsp+0x30]
00007dd8609d7daf  vmovaps xmm4, [rsp+0x40]
00007dd8609d7db5  vmovaps xmm5, [rsp+0x50]
00007dd8609d7dbb  vmovaps xmm6, [rsp+0x60]
00007dd8609d7dc1  vmovaps xmm7, [rsp+0x70]
00007dd8609d7dc7  vmovaps xmm8, [rsp+0x80]
00007dd8609d7dd0  vmovaps xmm10, [rsp+0x90]
00007dd8609d7dd9  vmovaps xmm11, [rsp+0xA0]
00007dd8609d7de2  vmovaps xmm12, [rsp+0xB0]
00007dd8609d7deb  vmovaps xmm13, [rsp+0xC0]
00007dd8609d7df4  vmovaps xmm14, [rsp+0xD0]
00007dd8609d7dfd  vmovaps xmm15, [rsp+0xE0]
00007dd8609d7e06  add rsp, 0xF0
00007dd8609d7e0d  pop r11
00007dd8609d7e0f  pop r10
00007dd8609d7e11  pop r9
00007dd8609d7e13  pop r8
00007dd8609d7e15  pop rsi
00007dd8609d7e16  pop rdi
00007dd8609d7e17  pop rdx
00007dd8609d7e18  pop rcx
00007dd8609d7e19  pop rax
00007dd8609d7e1a  add rsp, 0x08
00007dd8609d7e1e  jmp 0x00007DD8609D3418
00007dd8609d7e23  sub rsp, 0x08
00007dd8609d7e27  push rax
00007dd8609d7e28  push rcx
00007dd8609d7e29  push rdx
00007dd8609d7e2a  push rdi
00007dd8609d7e2b  push rsi
00007dd8609d7e2c  push r8
00007dd8609d7e2e  push r9
00007dd8609d7e30  push r10
00007dd8609d7e32  push r11
00007dd8609d7e34  sub rsp, 0xF0
00007dd8609d7e3b  vmovaps [rsp], xmm0
00007dd8609d7e40  vmovaps [rsp+0x10], xmm1
00007dd8609d7e46  vmovaps [rsp+0x20], xmm2
00007dd8609d7e4c  vmovaps [rsp+0x30], xmm3
00007dd8609d7e52  vmovaps [rsp+0x40], xmm4
00007dd8609d7e58  vmovaps [rsp+0x50], xmm5
00007dd8609d7e5e  vmovaps [rsp+0x60], xmm6
00007dd8609d7e64  vmovaps [rsp+0x70], xmm7
00007dd8609d7e6a  vmovaps [rsp+0x80], xmm8
00007dd8609d7e73  vmovaps [rsp+0x90], xmm9
00007dd8609d7e7c  vmovaps [rsp+0xA0], xmm10
00007dd8609d7e85  vmovaps [rsp+0xB0], xmm11
00007dd8609d7e8e  vmovaps [rsp+0xC0], xmm12
00007dd8609d7e97  vmovaps [rsp+0xD0], xmm13
00007dd8609d7ea0  vmovaps [rsp+0xE0], xmm14
00007dd8609d7ea9  sub rsp, 0x30
00007dd8609d7ead  movaps [rsp], xmm15
00007dd8609d7eb2  movaps [rsp+0x10], xmm4
00007dd8609d7eb7  movaps [rsp+0x20], xmm1
00007dd8609d7ebc  lea rdi, [rsp]
00007dd8609d7ec0  mov esi, 0x00
00007dd8609d7ec5  mov rax, 0x629C9CFA9530
00007dd8609d7ecf  call rax
00007dd8609d7ed1  movaps xmm15, [rsp]
00007dd8609d7ed6  add rsp, 0x30
00007dd8609d7eda  vmovaps xmm0, [rsp]
00007dd8609d7edf  vmovaps xmm1, [rsp+0x10]
00007dd8609d7ee5  vmovaps xmm2, [rsp+0x20]
00007dd8609d7eeb  vmovaps xmm3, [rsp+0x30]
00007dd8609d7ef1  vmovaps xmm4, [rsp+0x40]
00007dd8609d7ef7  vmovaps xmm5, [rsp+0x50]
00007dd8609d7efd  vmovaps xmm6, [rsp+0x60]
00007dd8609d7f03  vmovaps xmm7, [rsp+0x70]
00007dd8609d7f09  vmovaps xmm8, [rsp+0x80]
00007dd8609d7f12  vmovaps xmm9, [rsp+0x90]
00007dd8609d7f1b  vmovaps xmm10, [rsp+0xA0]
00007dd8609d7f24  vmovaps xmm11, [rsp+0xB0]
00007dd8609d7f2d  vmovaps xmm12, [rsp+0xC0]
00007dd8609d7f36  vmovaps xmm13, [rsp+0xD0]
00007dd8609d7f3f  vmovaps xmm14, [rsp+0xE0]
00007dd8609d7f48  add rsp, 0xF0
00007dd8609d7f4f  pop r11
00007dd8609d7f51  pop r10
00007dd8609d7f53  pop r9
00007dd8609d7f55  pop r8
00007dd8609d7f57  pop rsi
00007dd8609d7f58  pop rdi
00007dd8609d7f59  pop rdx
00007dd8609d7f5a  pop rcx
00007dd8609d7f5b  pop rax
00007dd8609d7f5c  add rsp, 0x08
00007dd8609d7f60  jmp 0x00007DD8609D343E
00007dd8609d7f65  sub rsp, 0x08
00007dd8609d7f69  push rax
00007dd8609d7f6a  push rcx
00007dd8609d7f6b  push rdx
00007dd8609d7f6c  push rdi
00007dd8609d7f6d  push rsi
00007dd8609d7f6e  push r8
00007dd8609d7f70  push r9
00007dd8609d7f72  push r10
00007dd8609d7f74  push r11
00007dd8609d7f76  sub rsp, 0xF0
00007dd8609d7f7d  vmovaps [rsp], xmm0
00007dd8609d7f82  vmovaps [rsp+0x10], xmm2
00007dd8609d7f88  vmovaps [rsp+0x20], xmm3
00007dd8609d7f8e  vmovaps [rsp+0x30], xmm4
00007dd8609d7f94  vmovaps [rsp+0x40], xmm5
00007dd8609d7f9a  vmovaps [rsp+0x50], xmm6
00007dd8609d7fa0  vmovaps [rsp+0x60], xmm7
00007dd8609d7fa6  vmovaps [rsp+0x70], xmm8
00007dd8609d7fac  vmovaps [rsp+0x80], xmm9
00007dd8609d7fb5  vmovaps [rsp+0x90], xmm10
00007dd8609d7fbe  vmovaps [rsp+0xA0], xmm11
00007dd8609d7fc7  vmovaps [rsp+0xB0], xmm12
00007dd8609d7fd0  vmovaps [rsp+0xC0], xmm13
00007dd8609d7fd9  vmovaps [rsp+0xD0], xmm14
00007dd8609d7fe2  vmovaps [rsp+0xE0], xmm15
00007dd8609d7feb  sub rsp, 0x30
00007dd8609d7fef  movaps [rsp], xmm1
00007dd8609d7ff3  movaps [rsp+0x10], xmm14
00007dd8609d7ff9  movaps [rsp+0x20], xmm11
00007dd8609d7fff  lea rdi, [rsp]
00007dd8609d8003  mov esi, 0x00
00007dd8609d8008  mov rax, 0x629C9CFA9530
00007dd8609d8012  call rax
00007dd8609d8014  movaps xmm1, [rsp]
00007dd8609d8018  add rsp, 0x30
00007dd8609d801c  vmovaps xmm0, [rsp]
00007dd8609d8021  vmovaps xmm2, [rsp+0x10]
00007dd8609d8027  vmovaps xmm3, [rsp+0x20]
00007dd8609d802d  vmovaps xmm4, [rsp+0x30]
00007dd8609d8033  vmovaps xmm5, [rsp+0x40]
00007dd8609d8039  vmovaps xmm6, [rsp+0x50]
00007dd8609d803f  vmovaps xmm7, [rsp+0x60]
00007dd8609d8045  vmovaps xmm8, [rsp+0x70]
00007dd8609d804b  vmovaps xmm9, [rsp+0x80]
00007dd8609d8054  vmovaps xmm10, [rsp+0x90]
00007dd8609d805d  vmovaps xmm11, [rsp+0xA0]
00007dd8609d8066  vmovaps xmm12, [rsp+0xB0]
00007dd8609d806f  vmovaps xmm13, [rsp+0xC0]
00007dd8609d8078  vmovaps xmm14, [rsp+0xD0]
00007dd8609d8081  vmovaps xmm15, [rsp+0xE0]
00007dd8609d808a  add rsp, 0xF0
00007dd8609d8091  pop r11
00007dd8609d8093  pop r10
00007dd8609d8095  pop r9
00007dd8609d8097  pop r8
00007dd8609d8099  pop rsi
00007dd8609d809a  pop rdi
00007dd8609d809b  pop rdx
00007dd8609d809c  pop rcx
00007dd8609d809d  pop rax
00007dd8609d809e  add rsp, 0x08
00007dd8609d80a2  jmp 0x00007DD8609D345F
00007dd8609d80a7  call 0x00007DD8608E45A0
00007dd8609d80ac  jmp 0x00007DD8609D346D
00007dd8609d80b1  call 0x00007DD860809D70
00007dd8609d80b6  jmp 0x00007DD8609D3477
00007dd8609d80bb  sub rsp, 0x08
00007dd8609d80bf  push rax
00007dd8609d80c0  push rcx
00007dd8609d80c1  push rdx
00007dd8609d80c2  push rdi
00007dd8609d80c3  push rsi
00007dd8609d80c4  push r8
00007dd8609d80c6  push r9
00007dd8609d80c8  push r10
00007dd8609d80ca  push r11
00007dd8609d80cc  sub rsp, 0xF0
00007dd8609d80d3  vmovaps [rsp], xmm0
00007dd8609d80d8  vmovaps [rsp+0x10], xmm1
00007dd8609d80de  vmovaps [rsp+0x20], xmm2
00007dd8609d80e4  vmovaps [rsp+0x30], xmm3
00007dd8609d80ea  vmovaps [rsp+0x40], xmm4
00007dd8609d80f0  vmovaps [rsp+0x50], xmm5
00007dd8609d80f6  vmovaps [rsp+0x60], xmm6
00007dd8609d80fc  vmovaps [rsp+0x70], xmm8
00007dd8609d8102  vmovaps [rsp+0x80], xmm9
00007dd8609d810b  vmovaps [rsp+0x90], xmm10
00007dd8609d8114  vmovaps [rsp+0xA0], xmm11
00007dd8609d811d  vmovaps [rsp+0xB0], xmm12
00007dd8609d8126  vmovaps [rsp+0xC0], xmm13
00007dd8609d812f  vmovaps [rsp+0xD0], xmm14
00007dd8609d8138  vmovaps [rsp+0xE0], xmm15
00007dd8609d8141  sub rsp, 0x30
00007dd8609d8145  movaps [rsp], xmm7
00007dd8609d8149  movaps [rsp+0x10], xmm13
00007dd8609d814f  movaps [rsp+0x20], xmm10
00007dd8609d8155  lea rdi, [rsp]
00007dd8609d8159  mov esi, 0x00
00007dd8609d815e  mov rax, 0x629C9CFA9530
00007dd8609d8168  call rax
00007dd8609d816a  movaps xmm7, [rsp]
00007dd8609d816e  add rsp, 0x30
00007dd8609d8172  vmovaps xmm0, [rsp]
00007dd8609d8177  vmovaps xmm1, [rsp+0x10]
00007dd8609d817d  vmovaps xmm2, [rsp+0x20]
00007dd8609d8183  vmovaps xmm3, [rsp+0x30]
00007dd8609d8189  vmovaps xmm4, [rsp+0x40]
00007dd8609d818f  vmovaps xmm5, [rsp+0x50]
00007dd8609d8195  vmovaps xmm6, [rsp+0x60]
00007dd8609d819b  vmovaps xmm8, [rsp+0x70]
00007dd8609d81a1  vmovaps xmm9, [rsp+0x80]
00007dd8609d81aa  vmovaps xmm10, [rsp+0x90]
00007dd8609d81b3  vmovaps xmm11, [rsp+0xA0]
00007dd8609d81bc  vmovaps xmm12, [rsp+0xB0]
00007dd8609d81c5  vmovaps xmm13, [rsp+0xC0]
00007dd8609d81ce  vmovaps xmm14, [rsp+0xD0]
00007dd8609d81d7  vmovaps xmm15, [rsp+0xE0]
00007dd8609d81e0  add rsp, 0xF0
00007dd8609d81e7  pop r11
00007dd8609d81e9  pop r10
00007dd8609d81eb  pop r9
00007dd8609d81ed  pop r8
00007dd8609d81ef  pop rsi
00007dd8609d81f0  pop rdi
00007dd8609d81f1  pop rdx
00007dd8609d81f2  pop rcx
00007dd8609d81f3  pop rax
00007dd8609d81f4  add rsp, 0x08
00007dd8609d81f8  jmp 0x00007DD8609D3498
00007dd8609d81fd  sub rsp, 0x08
00007dd8609d8201  push rax
00007dd8609d8202  push rcx
00007dd8609d8203  push rdx
00007dd8609d8204  push rdi
00007dd8609d8205  push rsi
00007dd8609d8206  push r8
00007dd8609d8208  push r9
00007dd8609d820a  push r10
00007dd8609d820c  push r11
00007dd8609d820e  sub rsp, 0xF0
00007dd8609d8215  vmovaps [rsp], xmm0
00007dd8609d821a  vmovaps [rsp+0x10], xmm1
00007dd8609d8220  vmovaps [rsp+0x20], xmm2
00007dd8609d8226  vmovaps [rsp+0x30], xmm3
00007dd8609d822c  vmovaps [rsp+0x40], xmm4
00007dd8609d8232  vmovaps [rsp+0x50], xmm5
00007dd8609d8238  vmovaps [rsp+0x60], xmm6
00007dd8609d823e  vmovaps [rsp+0x70], xmm7
00007dd8609d8244  vmovaps [rsp+0x80], xmm8
00007dd8609d824d  vmovaps [rsp+0x90], xmm9
00007dd8609d8256  vmovaps [rsp+0xA0], xmm11
00007dd8609d825f  vmovaps [rsp+0xB0], xmm12
00007dd8609d8268  vmovaps [rsp+0xC0], xmm13
00007dd8609d8271  vmovaps [rsp+0xD0], xmm14
00007dd8609d827a  vmovaps [rsp+0xE0], xmm15
00007dd8609d8283  sub rsp, 0x30
00007dd8609d8287  movaps [rsp], xmm10
00007dd8609d828c  movaps [rsp+0x10], xmm11
00007dd8609d8292  movaps [rsp+0x20], xmm13
00007dd8609d8298  lea rdi, [rsp]
00007dd8609d829c  mov esi, 0x00
00007dd8609d82a1  mov rax, 0x629C9CFA9530
00007dd8609d82ab  call rax
00007dd8609d82ad  movaps xmm10, [rsp]
00007dd8609d82b2  add rsp, 0x30
00007dd8609d82b6  vmovaps xmm0, [rsp]
00007dd8609d82bb  vmovaps xmm1, [rsp+0x10]
00007dd8609d82c1  vmovaps xmm2, [rsp+0x20]
00007dd8609d82c7  vmovaps xmm3, [rsp+0x30]
00007dd8609d82cd  vmovaps xmm4, [rsp+0x40]
00007dd8609d82d3  vmovaps xmm5, [rsp+0x50]
00007dd8609d82d9  vmovaps xmm6, [rsp+0x60]
00007dd8609d82df  vmovaps xmm7, [rsp+0x70]
00007dd8609d82e5  vmovaps xmm8, [rsp+0x80]
00007dd8609d82ee  vmovaps xmm9, [rsp+0x90]
00007dd8609d82f7  vmovaps xmm11, [rsp+0xA0]
00007dd8609d8300  vmovaps xmm12, [rsp+0xB0]
00007dd8609d8309  vmovaps xmm13, [rsp+0xC0]
00007dd8609d8312  vmovaps xmm14, [rsp+0xD0]
00007dd8609d831b  vmovaps xmm15, [rsp+0xE0]
00007dd8609d8324  add rsp, 0xF0
00007dd8609d832b  pop r11
00007dd8609d832d  pop r10
00007dd8609d832f  pop r9
00007dd8609d8331  pop r8
00007dd8609d8333  pop rsi
00007dd8609d8334  pop rdi
00007dd8609d8335  pop rdx
00007dd8609d8336  pop rcx
00007dd8609d8337  pop rax
00007dd8609d8338  add rsp, 0x08
00007dd8609d833c  jmp 0x00007DD8609D34C6
00007dd8609d8341  sub rsp, 0x08
00007dd8609d8345  push rax
00007dd8609d8346  push rcx
00007dd8609d8347  push rdx
00007dd8609d8348  push rdi
00007dd8609d8349  push rsi
00007dd8609d834a  push r8
00007dd8609d834c  push r9
00007dd8609d834e  push r10
00007dd8609d8350  push r11
00007dd8609d8352  sub rsp, 0xF0
00007dd8609d8359  vmovaps [rsp], xmm0
00007dd8609d835e  vmovaps [rsp+0x10], xmm1
00007dd8609d8364  vmovaps [rsp+0x20], xmm2
00007dd8609d836a  vmovaps [rsp+0x30], xmm3
00007dd8609d8370  vmovaps [rsp+0x40], xmm4
00007dd8609d8376  vmovaps [rsp+0x50], xmm5
00007dd8609d837c  vmovaps [rsp+0x60], xmm6
00007dd8609d8382  vmovaps [rsp+0x70], xmm7
00007dd8609d8388  vmovaps [rsp+0x80], xmm8
00007dd8609d8391  vmovaps [rsp+0x90], xmm9
00007dd8609d839a  vmovaps [rsp+0xA0], xmm10
00007dd8609d83a3  vmovaps [rsp+0xB0], xmm12
00007dd8609d83ac  vmovaps [rsp+0xC0], xmm13
00007dd8609d83b5  vmovaps [rsp+0xD0], xmm14
00007dd8609d83be  vmovaps [rsp+0xE0], xmm15
00007dd8609d83c7  sub rsp, 0x30
00007dd8609d83cb  movaps [rsp], xmm11
00007dd8609d83d0  movaps [rsp+0x10], xmm14
00007dd8609d83d6  movaps [rsp+0x20], xmm13
00007dd8609d83dc  lea rdi, [rsp]
00007dd8609d83e0  mov esi, 0x00
00007dd8609d83e5  mov rax, 0x629C9CFA9530
00007dd8609d83ef  call rax
00007dd8609d83f1  movaps xmm11, [rsp]
00007dd8609d83f6  add rsp, 0x30
00007dd8609d83fa  vmovaps xmm0, [rsp]
00007dd8609d83ff  vmovaps xmm1, [rsp+0x10]
00007dd8609d8405  vmovaps xmm2, [rsp+0x20]
00007dd8609d840b  vmovaps xmm3, [rsp+0x30]
00007dd8609d8411  vmovaps xmm4, [rsp+0x40]
00007dd8609d8417  vmovaps xmm5, [rsp+0x50]
00007dd8609d841d  vmovaps xmm6, [rsp+0x60]
00007dd8609d8423  vmovaps xmm7, [rsp+0x70]
00007dd8609d8429  vmovaps xmm8, [rsp+0x80]
00007dd8609d8432  vmovaps xmm9, [rsp+0x90]
00007dd8609d843b  vmovaps xmm10, [rsp+0xA0]
00007dd8609d8444  vmovaps xmm12, [rsp+0xB0]
00007dd8609d844d  vmovaps xmm13, [rsp+0xC0]
00007dd8609d8456  vmovaps xmm14, [rsp+0xD0]
00007dd8609d845f  vmovaps xmm15, [rsp+0xE0]
00007dd8609d8468  add rsp, 0xF0
00007dd8609d846f  pop r11
00007dd8609d8471  pop r10
00007dd8609d8473  pop r9
00007dd8609d8475  pop r8
00007dd8609d8477  pop rsi
00007dd8609d8478  pop rdi
00007dd8609d8479  pop rdx
00007dd8609d847a  pop rcx
00007dd8609d847b  pop rax
00007dd8609d847c  add rsp, 0x08
00007dd8609d8480  jmp 0x00007DD8609D34F4
00007dd8609d8485  sub rsp, 0x08
00007dd8609d8489  push rax
00007dd8609d848a  push rcx
00007dd8609d848b  push rdx
00007dd8609d848c  push rdi
00007dd8609d848d  push rsi
00007dd8609d848e  push r8
00007dd8609d8490  push r9
00007dd8609d8492  push r10
00007dd8609d8494  push r11
00007dd8609d8496  sub rsp, 0xF0
00007dd8609d849d  vmovaps [rsp], xmm0
00007dd8609d84a2  vmovaps [rsp+0x10], xmm1
00007dd8609d84a8  vmovaps [rsp+0x20], xmm2
00007dd8609d84ae  vmovaps [rsp+0x30], xmm3
00007dd8609d84b4  vmovaps [rsp+0x40], xmm4
00007dd8609d84ba  vmovaps [rsp+0x50], xmm5
00007dd8609d84c0  vmovaps [rsp+0x60], xmm6
00007dd8609d84c6  vmovaps [rsp+0x70], xmm7
00007dd8609d84cc  vmovaps [rsp+0x80], xmm8
00007dd8609d84d5  vmovaps [rsp+0x90], xmm9
00007dd8609d84de  vmovaps [rsp+0xA0], xmm10
00007dd8609d84e7  vmovaps [rsp+0xB0], xmm11
00007dd8609d84f0  vmovaps [rsp+0xC0], xmm12
00007dd8609d84f9  vmovaps [rsp+0xD0], xmm13
00007dd8609d8502  vmovaps [rsp+0xE0], xmm15
00007dd8609d850b  sub rsp, 0x30
00007dd8609d850f  movaps [rsp], xmm14
00007dd8609d8514  movaps [rsp+0x10], xmm12
00007dd8609d851a  movaps [rsp+0x20], xmm9
00007dd8609d8520  lea rdi, [rsp]
00007dd8609d8524  mov esi, 0x00
00007dd8609d8529  mov rax, 0x629C9CFA9530
00007dd8609d8533  call rax
00007dd8609d8535  movaps xmm14, [rsp]
00007dd8609d853a  add rsp, 0x30
00007dd8609d853e  vmovaps xmm0, [rsp]
00007dd8609d8543  vmovaps xmm1, [rsp+0x10]
00007dd8609d8549  vmovaps xmm2, [rsp+0x20]
00007dd8609d854f  vmovaps xmm3, [rsp+0x30]
00007dd8609d8555  vmovaps xmm4, [rsp+0x40]
00007dd8609d855b  vmovaps xmm5, [rsp+0x50]
00007dd8609d8561  vmovaps xmm6, [rsp+0x60]
00007dd8609d8567  vmovaps xmm7, [rsp+0x70]
00007dd8609d856d  vmovaps xmm8, [rsp+0x80]
00007dd8609d8576  vmovaps xmm9, [rsp+0x90]
00007dd8609d857f  vmovaps xmm10, [rsp+0xA0]
00007dd8609d8588  vmovaps xmm11, [rsp+0xB0]
00007dd8609d8591  vmovaps xmm12, [rsp+0xC0]
00007dd8609d859a  vmovaps xmm13, [rsp+0xD0]
00007dd8609d85a3  vmovaps xmm15, [rsp+0xE0]
00007dd8609d85ac  add rsp, 0xF0
00007dd8609d85b3  pop r11
00007dd8609d85b5  pop r10
00007dd8609d85b7  pop r9
00007dd8609d85b9  pop r8
00007dd8609d85bb  pop rsi
00007dd8609d85bc  pop rdi
00007dd8609d85bd  pop rdx
00007dd8609d85be  pop rcx
00007dd8609d85bf  pop rax
00007dd8609d85c0  add rsp, 0x08
00007dd8609d85c4  jmp 0x00007DD8609D350F
00007dd8609d85c9  sub rsp, 0x08
00007dd8609d85cd  push rax
00007dd8609d85ce  push rcx
00007dd8609d85cf  push rdx
00007dd8609d85d0  push rdi
00007dd8609d85d1  push rsi
00007dd8609d85d2  push r8
00007dd8609d85d4  push r9
00007dd8609d85d6  push r10
00007dd8609d85d8  push r11
00007dd8609d85da  sub rsp, 0xF0
00007dd8609d85e1  vmovaps [rsp], xmm0
00007dd8609d85e6  vmovaps [rsp+0x10], xmm1
00007dd8609d85ec  vmovaps [rsp+0x20], xmm2
00007dd8609d85f2  vmovaps [rsp+0x30], xmm3
00007dd8609d85f8  vmovaps [rsp+0x40], xmm4
00007dd8609d85fe  vmovaps [rsp+0x50], xmm5
00007dd8609d8604  vmovaps [rsp+0x60], xmm6
00007dd8609d860a  vmovaps [rsp+0x70], xmm7
00007dd8609d8610  vmovaps [rsp+0x80], xmm8
00007dd8609d8619  vmovaps [rsp+0x90], xmm9
00007dd8609d8622  vmovaps [rsp+0xA0], xmm10
00007dd8609d862b  vmovaps [rsp+0xB0], xmm11
00007dd8609d8634  vmovaps [rsp+0xC0], xmm12
00007dd8609d863d  vmovaps [rsp+0xD0], xmm14
00007dd8609d8646  vmovaps [rsp+0xE0], xmm15
00007dd8609d864f  sub rsp, 0x30
00007dd8609d8653  movaps [rsp], xmm13
00007dd8609d8658  movaps [rsp+0x10], xmm8
00007dd8609d865e  movaps [rsp+0x20], xmm15
00007dd8609d8664  lea rdi, [rsp]
00007dd8609d8668  mov esi, 0x00
00007dd8609d866d  mov rax, 0x629C9CFA9530
00007dd8609d8677  call rax
00007dd8609d8679  movaps xmm13, [rsp]
00007dd8609d867e  add rsp, 0x30
00007dd8609d8682  vmovaps xmm0, [rsp]
00007dd8609d8687  vmovaps xmm1, [rsp+0x10]
00007dd8609d868d  vmovaps xmm2, [rsp+0x20]
00007dd8609d8693  vmovaps xmm3, [rsp+0x30]
00007dd8609d8699  vmovaps xmm4, [rsp+0x40]
00007dd8609d869f  vmovaps xmm5, [rsp+0x50]
00007dd8609d86a5  vmovaps xmm6, [rsp+0x60]
00007dd8609d86ab  vmovaps xmm7, [rsp+0x70]
00007dd8609d86b1  vmovaps xmm8, [rsp+0x80]
00007dd8609d86ba  vmovaps xmm9, [rsp+0x90]
00007dd8609d86c3  vmovaps xmm10, [rsp+0xA0]
00007dd8609d86cc  vmovaps xmm11, [rsp+0xB0]
00007dd8609d86d5  vmovaps xmm12, [rsp+0xC0]
00007dd8609d86de  vmovaps xmm14, [rsp+0xD0]
00007dd8609d86e7  vmovaps xmm15, [rsp+0xE0]
00007dd8609d86f0  add rsp, 0xF0
00007dd8609d86f7  pop r11
00007dd8609d86f9  pop r10
00007dd8609d86fb  pop r9
00007dd8609d86fd  pop r8
00007dd8609d86ff  pop rsi
00007dd8609d8700  pop rdi
00007dd8609d8701  pop rdx
00007dd8609d8702  pop rcx
00007dd8609d8703  pop rax
00007dd8609d8704  add rsp, 0x08
00007dd8609d8708  jmp 0x00007DD8609D3532
00007dd8609d870d  sub rsp, 0x08
00007dd8609d8711  push rax
00007dd8609d8712  push rcx
00007dd8609d8713  push rdx
00007dd8609d8714  push rdi
00007dd8609d8715  push rsi
00007dd8609d8716  push r8
00007dd8609d8718  push r9
00007dd8609d871a  push r10
00007dd8609d871c  push r11
00007dd8609d871e  sub rsp, 0xF0
00007dd8609d8725  vmovaps [rsp], xmm0
00007dd8609d872a  vmovaps [rsp+0x10], xmm1
00007dd8609d8730  vmovaps [rsp+0x20], xmm2
00007dd8609d8736  vmovaps [rsp+0x30], xmm3
00007dd8609d873c  vmovaps [rsp+0x40], xmm4
00007dd8609d8742  vmovaps [rsp+0x50], xmm5
00007dd8609d8748  vmovaps [rsp+0x60], xmm6
00007dd8609d874e  vmovaps [rsp+0x70], xmm7
00007dd8609d8754  vmovaps [rsp+0x80], xmm8
00007dd8609d875d  vmovaps [rsp+0x90], xmm9
00007dd8609d8766  vmovaps [rsp+0xA0], xmm10
00007dd8609d876f  vmovaps [rsp+0xB0], xmm11
00007dd8609d8778  vmovaps [rsp+0xC0], xmm12
00007dd8609d8781  vmovaps [rsp+0xD0], xmm13
00007dd8609d878a  vmovaps [rsp+0xE0], xmm14
00007dd8609d8793  sub rsp, 0x30
00007dd8609d8797  movaps [rsp], xmm15
00007dd8609d879c  movaps [rsp+0x10], xmm1
00007dd8609d87a1  movaps [rsp+0x20], xmm10
00007dd8609d87a7  lea rdi, [rsp]
00007dd8609d87ab  mov esi, 0x00
00007dd8609d87b0  mov rax, 0x629C9CFA9530
00007dd8609d87ba  call rax
00007dd8609d87bc  movaps xmm15, [rsp]
00007dd8609d87c1  add rsp, 0x30
00007dd8609d87c5  vmovaps xmm0, [rsp]
00007dd8609d87ca  vmovaps xmm1, [rsp+0x10]
00007dd8609d87d0  vmovaps xmm2, [rsp+0x20]
00007dd8609d87d6  vmovaps xmm3, [rsp+0x30]
00007dd8609d87dc  vmovaps xmm4, [rsp+0x40]
00007dd8609d87e2  vmovaps xmm5, [rsp+0x50]
00007dd8609d87e8  vmovaps xmm6, [rsp+0x60]
00007dd8609d87ee  vmovaps xmm7, [rsp+0x70]
00007dd8609d87f4  vmovaps xmm8, [rsp+0x80]
00007dd8609d87fd  vmovaps xmm9, [rsp+0x90]
00007dd8609d8806  vmovaps xmm10, [rsp+0xA0]
00007dd8609d880f  vmovaps xmm11, [rsp+0xB0]
00007dd8609d8818  vmovaps xmm12, [rsp+0xC0]
00007dd8609d8821  vmovaps xmm13, [rsp+0xD0]
00007dd8609d882a  vmovaps xmm14, [rsp+0xE0]
00007dd8609d8833  add rsp, 0xF0
00007dd8609d883a  pop r11
00007dd8609d883c  pop r10
00007dd8609d883e  pop r9
00007dd8609d8840  pop r8
00007dd8609d8842  pop rsi
00007dd8609d8843  pop rdi
00007dd8609d8844  pop rdx
00007dd8609d8845  pop rcx
00007dd8609d8846  pop rax
00007dd8609d8847  add rsp, 0x08
00007dd8609d884b  jmp 0x00007DD8609D3555
00007dd8609d8850  sub rsp, 0x08
00007dd8609d8854  push rax
00007dd8609d8855  push rcx
00007dd8609d8856  push rdx
00007dd8609d8857  push rdi
00007dd8609d8858  push rsi
00007dd8609d8859  push r8
00007dd8609d885b  push r9
00007dd8609d885d  push r10
00007dd8609d885f  push r11
00007dd8609d8861  sub rsp, 0xF0
00007dd8609d8868  vmovaps [rsp], xmm0
00007dd8609d886d  vmovaps [rsp+0x10], xmm2
00007dd8609d8873  vmovaps [rsp+0x20], xmm3
00007dd8609d8879  vmovaps [rsp+0x30], xmm4
00007dd8609d887f  vmovaps [rsp+0x40], xmm5
00007dd8609d8885  vmovaps [rsp+0x50], xmm6
00007dd8609d888b  vmovaps [rsp+0x60], xmm7
00007dd8609d8891  vmovaps [rsp+0x70], xmm8
00007dd8609d8897  vmovaps [rsp+0x80], xmm9
00007dd8609d88a0  vmovaps [rsp+0x90], xmm10
00007dd8609d88a9  vmovaps [rsp+0xA0], xmm11
00007dd8609d88b2  vmovaps [rsp+0xB0], xmm12
00007dd8609d88bb  vmovaps [rsp+0xC0], xmm13
00007dd8609d88c4  vmovaps [rsp+0xD0], xmm14
00007dd8609d88cd  vmovaps [rsp+0xE0], xmm15
00007dd8609d88d6  sub rsp, 0x30
00007dd8609d88da  movaps [rsp], xmm1
00007dd8609d88de  movaps [rsp+0x10], xmm7
00007dd8609d88e3  movaps [rsp+0x20], xmm11
00007dd8609d88e9  lea rdi, [rsp]
00007dd8609d88ed  mov esi, 0x00
00007dd8609d88f2  mov rax, 0x629C9CFA9530
00007dd8609d88fc  call rax
00007dd8609d88fe  movaps xmm1, [rsp]
00007dd8609d8902  add rsp, 0x30
00007dd8609d8906  vmovaps xmm0, [rsp]
00007dd8609d890b  vmovaps xmm2, [rsp+0x10]
00007dd8609d8911  vmovaps xmm3, [rsp+0x20]
00007dd8609d8917  vmovaps xmm4, [rsp+0x30]
00007dd8609d891d  vmovaps xmm5, [rsp+0x40]
00007dd8609d8923  vmovaps xmm6, [rsp+0x50]
00007dd8609d8929  vmovaps xmm7, [rsp+0x60]
00007dd8609d892f  vmovaps xmm8, [rsp+0x70]
00007dd8609d8935  vmovaps xmm9, [rsp+0x80]
00007dd8609d893e  vmovaps xmm10, [rsp+0x90]
00007dd8609d8947  vmovaps xmm11, [rsp+0xA0]
00007dd8609d8950  vmovaps xmm12, [rsp+0xB0]
00007dd8609d8959  vmovaps xmm13, [rsp+0xC0]
00007dd8609d8962  vmovaps xmm14, [rsp+0xD0]
00007dd8609d896b  vmovaps xmm15, [rsp+0xE0]
00007dd8609d8974  add rsp, 0xF0
00007dd8609d897b  pop r11
00007dd8609d897d  pop r10
00007dd8609d897f  pop r9
00007dd8609d8981  pop r8
00007dd8609d8983  pop rsi
00007dd8609d8984  pop rdi
00007dd8609d8985  pop rdx
00007dd8609d8986  pop rcx
00007dd8609d8987  pop rax
00007dd8609d8988  add rsp, 0x08
00007dd8609d898c  jmp 0x00007DD8609D3576
00007dd8609d8991  call 0x00007DD86080D600
00007dd8609d8996  jmp 0x00007DD8609D3589
00007dd8609d899b  call 0x00007DD86080C380
00007dd8609d89a0  jmp 0x00007DD8609D3594
00007dd8609d89a5  call 0x00007DD86080E880
00007dd8609d89aa  jmp 0x00007DD8609D359F
00007dd8609d89af  call 0x00007DD8607FF540
00007dd8609d89b4  jmp 0x00007DD8609D35AA
00007dd8609d89b9  int3
00007dd8609d89ba  nop [rax+rax*1], ax
00007dd8609d89c0  mov rax, [r15+0x40]
00007dd8609d89c4  mov r14, [r15+0x58]
00007dd8609d89c8  lea r12, [rax+r14*1]
00007dd8609d89cc  movaps xmm1, [r15+0x1D0]
00007dd8609d89d4  vmovaps [rsp+0x10], xmm1
00007dd8609d89da  vmovaps xmm15, [rsp+0x10]
00007dd8609d89e0  por xmm1, xmm15
00007dd8609d89e5  movaps xmm14, [r15+0x1A0]
00007dd8609d89ed  vmovaps [rsp+0x10], xmm14
00007dd8609d89f3  vmovaps xmm13, [rsp+0x10]
00007dd8609d89f9  por xmm14, xmm13
00007dd8609d89fe  lea rax, [r12+0x30]
00007dd8609d8a03  mov r11, [r13+rax*1]
00007dd8609d8a08  lea rax, [r12+0x38]
00007dd8609d8a0d  mov r10, [r13+rax*1]
00007dd8609d8a12  movq xmm13, r11
00007dd8609d8a17  movq xmm12, r10
00007dd8609d8a1c  movq xmm13, xmm13
00007dd8609d8a21  vmovaps [rsp+0x10], xmm13
00007dd8609d8a27  movq xmm13, xmm13
00007dd8609d8a2c  movaps [r15+0x130], xmm13
00007dd8609d8a34  movq xmm12, xmm12
00007dd8609d8a39  vmovaps [rsp+0x20], xmm12
00007dd8609d8a3f  movq xmm12, xmm12
00007dd8609d8a44  movaps [r15+0x280], xmm12
00007dd8609d8a4c  movaps xmm13, [r15+0x270]
00007dd8609d8a54  vmovaps [rsp+0x30], xmm13
00007dd8609d8a5a  vmovaps xmm12, [rsp+0x30]
00007dd8609d8a60  por xmm13, xmm12
00007dd8609d8a65  lea rax, [r12+0x20]
00007dd8609d8a6a  mov r11, [r13+rax*1]
00007dd8609d8a6f  lea rax, [r12+0x28]
00007dd8609d8a74  mov r10, [r13+rax*1]
00007dd8609d8a79  movq xmm12, r11
00007dd8609d8a7e  movq xmm11, r10
00007dd8609d8a83  movq xmm12, xmm12
00007dd8609d8a88  vmovaps [rsp+0x30], xmm12
00007dd8609d8a8e  movq xmm12, xmm12
00007dd8609d8a93  movaps [r15+0x150], xmm12
00007dd8609d8a9b  movq xmm11, xmm11
00007dd8609d8aa0  vmovaps [rsp+0x40], xmm11
00007dd8609d8aa6  movq xmm11, xmm11
00007dd8609d8aab  movaps [r15+0x140], xmm11
00007dd8609d8ab3  lea rax, [r12+0x10]
00007dd8609d8ab8  mov r11, [r13+rax*1]
00007dd8609d8abd  lea rax, [r12+0x18]
00007dd8609d8ac2  mov r10, [r13+rax*1]
00007dd8609d8ac7  movq xmm12, r11
00007dd8609d8acc  movq xmm11, r10
00007dd8609d8ad1  movq xmm12, xmm12
00007dd8609d8ad6  vmovaps [rsp+0x50], xmm12
00007dd8609d8adc  movq xmm12, xmm12
00007dd8609d8ae1  movaps [r15+0x170], xmm12
00007dd8609d8ae9  movq xmm11, xmm11
00007dd8609d8aee  vmovaps [rsp+0x60], xmm11
00007dd8609d8af4  movq xmm11, xmm11
00007dd8609d8af9  movaps [r15+0x160], xmm11
00007dd8609d8b01  mov rax, [r13+r12*1]
00007dd8609d8b06  vmovq xmm12, rax
00007dd8609d8b0b  vpbroadcastq xmm12, xmm12
00007dd8609d8b10  lea rax, [r12+0x08]
00007dd8609d8b15  mov r12, [r13+rax*1]
00007dd8609d8b1a  movq xmm11, r12
00007dd8609d8b1f  movaps [r15+0x230], xmm11
00007dd8609d8b27  mov rax, [r15+0xF8]
00007dd8609d8b2e  lea r12, [rax+0x50]
00007dd8609d8b32  movups xmm11, [r13+r12*1]
00007dd8609d8b38  lea r12, [rax+0x60]
00007dd8609d8b3c  movups xmm10, [r13+r12*1]
00007dd8609d8b42  lea r12, [rax+0x30]
00007dd8609d8b46  movups xmm9, [r13+r12*1]
00007dd8609d8b4c  mov r12, [r15+0x50]
00007dd8609d8b50  lea r11, [r12+r14*1]
00007dd8609d8b54  mov [r15+0x60], r11
00007dd8609d8b58  lea r12, [r14+0x40]
00007dd8609d8b5c  mov [r15+0x58], r12
00007dd8609d8b60  movaps xmm8, xmm12
00007dd8609d8b64  mulpd xmm8, xmm15
00007dd8609d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8609d8b6f  ptest xmm7, xmm7
00007dd8609d8b74  jnz 0x00007DD8609D9997
00007dd8609d8b7a  movq xmm15, qword ptr [r15+0x230]
00007dd8609d8b83  vmovaps [rsp+0x70], xmm15
00007dd8609d8b89  vpermilpd xmm15, xmm15, 0x00
00007dd8609d8b8f  movaps xmm7, xmm9
00007dd8609d8b93  mulpd xmm7, xmm15
00007dd8609d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8609d8b9d  ptest xmm6, xmm6
00007dd8609d8ba2  jnz 0x00007DD8609D9ADB
00007dd8609d8ba8  vxorps xmm15, xmm15, xmm15
00007dd8609d8bad  vpbroadcastq xmm15, xmm15
00007dd8609d8bb2  movaps xmm9, xmm12
00007dd8609d8bb6  mulpd xmm9, xmm10
00007dd8609d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8609d8bc1  ptest xmm6, xmm6
00007dd8609d8bc6  jnz 0x00007DD8609D9C1D
00007dd8609d8bcc  movaps xmm10, xmm12
00007dd8609d8bd0  mulpd xmm10, xmm11
00007dd8609d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd8609d8bdb  ptest xmm6, xmm6
00007dd8609d8be0  jnz 0x00007DD8609D9D61
00007dd8609d8be6  movaps xmm11, [r15+0x1F0]
00007dd8609d8bee  movaps xmm6, xmm12
00007dd8609d8bf2  mulpd xmm6, xmm11
00007dd8609d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8609d8bfc  ptest xmm5, xmm5
00007dd8609d8c01  jnz 0x00007DD8609D9EA5
00007dd8609d8c07  movaps xmm12, [r15+0x2A0]
00007dd8609d8c0f  vmovaps [rsp+0x80], xmm12
00007dd8609d8c18  vmovaps xmm11, [rsp+0x80]
00007dd8609d8c21  por xmm12, xmm11
00007dd8609d8c26  movaps xmm11, [r15+0x250]
00007dd8609d8c2e  vmovaps [rsp+0x80], xmm11
00007dd8609d8c37  vmovaps xmm5, [rsp+0x80]
00007dd8609d8c40  por xmm11, xmm5
00007dd8609d8c45  vmovaps xmm4, [rsp+0x70]
00007dd8609d8c4b  vpermilpd xmm4, xmm4, 0x00
00007dd8609d8c51  movaps xmm3, xmm5
00007dd8609d8c54  mulpd xmm3, xmm4
00007dd8609d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007dd8609d8c5d  ptest xmm2, xmm2
00007dd8609d8c62  jnz 0x00007DD8609D9FE7
00007dd8609d8c68  mov [rsp+0x80], rax
00007dd8609d8c70  xor eax, eax
00007dd8609d8c72  mov r14d, 0x200
00007dd8609d8c78  cmp r12, r14
00007dd8609d8c7b  cmc
00007dd8609d8c7c  lahf
00007dd8609d8c7d  seto al
00007dd8609d8c80  mov [r15+0x108], eax
00007dd8609d8c87  movaps xmm5, xmm8
00007dd8609d8c8b  addpd xmm5, xmm15
00007dd8609d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007dd8609d8c95  ptest xmm4, xmm4
00007dd8609d8c9a  jnz 0x00007DD8609DA127
00007dd8609d8ca0  movaps xmm8, [r15+0x1B0]
00007dd8609d8ca8  movaps xmm4, xmm9
00007dd8609d8cac  addpd xmm4, xmm8
00007dd8609d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007dd8609d8cb6  ptest xmm2, xmm2
00007dd8609d8cbb  jnz 0x00007DD8609DA269
00007dd8609d8cc1  movaps xmm9, xmm10
00007dd8609d8cc5  addpd xmm9, xmm8
00007dd8609d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007dd8609d8cd0  ptest xmm2, xmm2
00007dd8609d8cd5  jnz 0x00007DD8609DA3AB
00007dd8609d8cdb  movaps xmm10, [r15+0x2F0]
00007dd8609d8ce3  vmovaps [rsp+0x90], xmm10
00007dd8609d8cec  vmovaps xmm8, [rsp+0x90]
00007dd8609d8cf5  por xmm10, xmm8
00007dd8609d8cfa  movaps xmm8, [r15+0x2E0]
00007dd8609d8d02  vmovaps [rsp+0x90], xmm8
00007dd8609d8d0b  vmovaps xmm2, [rsp+0x90]
00007dd8609d8d14  por xmm8, xmm2
00007dd8609d8d19  movaps xmm2, [r15+0x2D0]
00007dd8609d8d21  vmovaps [rsp+0x90], xmm2
00007dd8609d8d2a  vmovaps [rsp+0xA0], xmm1
00007dd8609d8d33  vmovaps xmm1, [rsp+0x90]
00007dd8609d8d3c  por xmm2, xmm1
00007dd8609d8d40  movaps xmm1, [r15+0x200]
00007dd8609d8d48  vmovaps [rsp+0x90], xmm1
00007dd8609d8d51  vmovaps [rsp+0xB0], xmm15
00007dd8609d8d5a  vmovaps xmm15, [rsp+0x90]
00007dd8609d8d63  por xmm1, xmm15
00007dd8609d8d68  movaps xmm15, [r15+0x1C0]
00007dd8609d8d70  vmovaps [rsp+0x90], xmm15
00007dd8609d8d79  vmovaps [rsp+0xC0], xmm1
00007dd8609d8d82  vmovaps xmm1, [rsp+0x90]
00007dd8609d8d8b  por xmm15, xmm1
00007dd8609d8d90  movaps xmm1, [r15+0x190]
00007dd8609d8d98  vmovaps [rsp+0x90], xmm1
00007dd8609d8da1  vmovaps [rsp+0xD0], xmm15
00007dd8609d8daa  vmovaps xmm15, [rsp+0x90]
00007dd8609d8db3  por xmm1, xmm15
00007dd8609d8db8  movaps xmm15, [r15+0x300]
00007dd8609d8dc0  vmovaps [rsp+0x90], xmm15
00007dd8609d8dc9  vmovaps [rsp+0xE0], xmm1
00007dd8609d8dd2  vmovaps xmm1, [rsp+0x90]
00007dd8609d8ddb  por xmm15, xmm1
00007dd8609d8de0  mov rax, [rsp+0x80]
00007dd8609d8de8  lea r14, [rax+0xA0]
00007dd8609d8def  movups xmm1, [r13+r14*1]
00007dd8609d8df5  lea r14, [rax+0xB0]
00007dd8609d8dfc  vmovaps [rsp+0x80], xmm1
00007dd8609d8e05  movups xmm1, [r13+r14*1]
00007dd8609d8e0b  vmovaps [rsp+0x90], xmm1
00007dd8609d8e14  vmovaps [rsp+0xF0], xmm15
00007dd8609d8e1d  vmovaps xmm15, [rsp+0xB0]
00007dd8609d8e26  vmovaps [rsp+0xB0], xmm14
00007dd8609d8e2f  movaps xmm1, xmm6
00007dd8609d8e32  addpd xmm1, xmm15
00007dd8609d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8609d8e3c  ptest xmm14, xmm14
00007dd8609d8e42  jnz 0x00007DD8609DA503
00007dd8609d8e48  lea r14, [rax+0xF0]
00007dd8609d8e4f  movups xmm15, [r13+r14*1]
00007dd8609d8e55  movaps xmm14, xmm4
00007dd8609d8e59  addpd xmm14, xmm3
00007dd8609d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8609d8e64  ptest xmm6, xmm6
00007dd8609d8e69  jnz 0x00007DD8609DA64E
00007dd8609d8e6f  movaps xmm6, xmm9
00007dd8609d8e73  addpd xmm6, xmm7
00007dd8609d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007dd8609d8e7c  ptest xmm4, xmm4
00007dd8609d8e81  jnz 0x00007DD8609DA790
00007dd8609d8e87  vmovaps xmm9, [rsp+0x70]
00007dd8609d8e8d  vpermilpd xmm9, xmm9, 0x00
00007dd8609d8e93  vmovaps xmm4, [rsp+0x90]
00007dd8609d8e9c  movaps xmm7, xmm4
00007dd8609d8e9f  mulpd xmm7, xmm9
00007dd8609d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007dd8609d8ea9  ptest xmm3, xmm3
00007dd8609d8eae  jnz 0x00007DD8609DA8D1
00007dd8609d8eb4  vmovaps xmm9, [rsp+0x50]
00007dd8609d8eba  vpermilpd xmm9, xmm9, 0x00
00007dd8609d8ec0  movaps xmm4, xmm15
00007dd8609d8ec4  mulpd xmm4, xmm9
00007dd8609d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd8609d8ece  ptest xmm3, xmm3
00007dd8609d8ed3  jnz 0x00007DD8609DAA12
00007dd8609d8ed9  lea r14, [rax+0xE0]
00007dd8609d8ee0  movups xmm15, [r13+r14*1]
00007dd8609d8ee6  vmovaps xmm9, [rsp+0x70]
00007dd8609d8eec  vpermilpd xmm9, xmm9, 0x00
00007dd8609d8ef2  vmovaps [rsp+0x70], xmm1
00007dd8609d8ef8  vmovaps xmm1, [rsp+0x80]
00007dd8609d8f01  vmovaps [rsp+0x80], xmm15
00007dd8609d8f0a  movaps xmm3, xmm1
00007dd8609d8f0d  mulpd xmm3, xmm9
00007dd8609d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007dd8609d8f17  ptest xmm15, xmm15
00007dd8609d8f1d  jnz 0x00007DD8609DAB5E
00007dd8609d8f23  vmovaps xmm1, [rsp+0xF0]
00007dd8609d8f2c  vmovaps xmm15, [rsp+0xF0]
00007dd8609d8f35  por xmm1, xmm15
00007dd8609d8f3a  movaps [r15+0x300], xmm1
00007dd8609d8f42  vmovaps xmm15, [rsp+0xE0]
00007dd8609d8f4b  vmovaps xmm9, [rsp+0xE0]
00007dd8609d8f54  por xmm15, xmm9
00007dd8609d8f59  movaps [r15+0x190], xmm15
00007dd8609d8f61  vmovaps xmm9, [rsp+0x50]
00007dd8609d8f67  vpermilpd xmm9, xmm9, 0x00
00007dd8609d8f6d  vmovaps [rsp+0x90], xmm1
00007dd8609d8f76  vmovaps [rsp+0xE0], xmm15
00007dd8609d8f7f  vmovaps xmm15, [rsp+0x80]
00007dd8609d8f88  vmovaps [rsp+0x80], xmm14
00007dd8609d8f91  movaps xmm1, xmm15
00007dd8609d8f95  mulpd xmm1, xmm9
00007dd8609d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8609d8f9f  ptest xmm14, xmm14
00007dd8609d8fa5  jnz 0x00007DD8609DAC9F
00007dd8609d8fab  lea r14, [rax+0x90]
00007dd8609d8fb2  movups xmm15, [r13+r14*1]
00007dd8609d8fb8  vmovaps xmm14, [rsp+0xD0]
00007dd8609d8fc1  vmovaps xmm9, [rsp+0xD0]
00007dd8609d8fca  por xmm14, xmm9
00007dd8609d8fcf  movaps [r15+0x1C0], xmm14
00007dd8609d8fd7  vmovaps xmm9, [rsp+0xC0]
00007dd8609d8fe0  vmovaps [rsp+0xD0], xmm1
00007dd8609d8fe9  vmovaps xmm1, [rsp+0xC0]
00007dd8609d8ff2  por xmm9, xmm1
00007dd8609d8ff7  movaps [r15+0x200], xmm9
00007dd8609d8fff  vmovaps [rsp+0xC0], xmm2
00007dd8609d9008  vmovaps xmm1, [rsp+0xC0]
00007dd8609d9011  por xmm2, xmm1
00007dd8609d9015  movaps [r15+0x2D0], xmm2
00007dd8609d901d  vmovaps [rsp+0xC0], xmm8
00007dd8609d9026  vmovaps xmm1, [rsp+0xC0]
00007dd8609d902f  por xmm8, xmm1
00007dd8609d9034  movaps [r15+0x2E0], xmm8
00007dd8609d903c  vmovaps [rsp+0xC0], xmm15
00007dd8609d9045  movaps xmm1, xmm5
00007dd8609d9048  addpd xmm1, xmm7
00007dd8609d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8609d9051  ptest xmm15, xmm15
00007dd8609d9057  jnz 0x00007DD8609DADEB
00007dd8609d905d  vmovaps xmm15, [rsp+0x50]
00007dd8609d9063  vpermilpd xmm15, xmm15, 0x00
00007dd8609d9069  vmovaps xmm5, [rsp+0xC0]
00007dd8609d9072  vmovaps [rsp+0xC0], xmm1
00007dd8609d907b  movaps xmm7, xmm5
00007dd8609d907e  mulpd xmm7, xmm15
00007dd8609d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007dd8609d9088  ptest xmm1, xmm1
00007dd8609d908d  jnz 0x00007DD8609DAF2B
00007dd8609d9093  lea r14, [rax+0x80]
00007dd8609d909a  movups xmm1, [r13+r14*1]
00007dd8609d90a0  vmovaps xmm5, [rsp+0x70]
00007dd8609d90a6  vmovaps [rsp+0x70], xmm1
00007dd8609d90ac  movaps xmm15, xmm5
00007dd8609d90b0  addpd xmm15, xmm3
00007dd8609d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8609d90bb  ptest xmm1, xmm1
00007dd8609d90c0  jnz 0x00007DD8609DB076
00007dd8609d90c6  vmovaps xmm5, [rsp+0x80]
00007dd8609d90cf  movaps xmm1, xmm5
00007dd8609d90d2  addpd xmm1, xmm4
00007dd8609d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007dd8609d90db  ptest xmm3, xmm3
00007dd8609d90e0  jnz 0x00007DD8609DB1B8
00007dd8609d90e6  vmovaps [rsp+0x80], xmm10
00007dd8609d90ef  vmovaps xmm5, [rsp+0x80]
00007dd8609d90f8  por xmm10, xmm5
00007dd8609d90fd  movaps [r15+0x2F0], xmm10
00007dd8609d9105  vmovaps xmm5, [rsp+0x50]
00007dd8609d910b  vpermilpd xmm5, xmm5, 0x00
00007dd8609d9111  vmovaps xmm3, [rsp+0x70]
00007dd8609d9117  vmovaps [rsp+0x50], xmm1
00007dd8609d911d  movaps xmm4, xmm3
00007dd8609d9120  mulpd xmm4, xmm5
00007dd8609d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd8609d9129  ptest xmm1, xmm1
00007dd8609d912e  jnz 0x00007DD8609DB2F8
00007dd8609d9134  lea r14, [rax+0xD0]
00007dd8609d913b  movups xmm1, [r13+r14*1]
00007dd8609d9141  vmovaps xmm3, [rsp+0xD0]
00007dd8609d914a  vmovaps [rsp+0x70], xmm1
00007dd8609d9150  movaps xmm5, xmm6
00007dd8609d9153  addpd xmm5, xmm3
00007dd8609d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd8609d915c  ptest xmm1, xmm1
00007dd8609d9161  jnz 0x00007DD8609DB442
00007dd8609d9167  vmovaps xmm1, [rsp+0x60]
00007dd8609d916d  vpermilpd xmm1, xmm1, 0x00
00007dd8609d9173  movaps xmm6, xmm9
00007dd8609d9177  mulpd xmm6, xmm1
00007dd8609d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd8609d9180  ptest xmm3, xmm3
00007dd8609d9185  jnz 0x00007DD8609DB582
00007dd8609d918b  movaps [r15+0x260], xmm6
00007dd8609d9193  vxorps xmm1, xmm1, xmm1
00007dd8609d9197  vpbroadcastq xmm1, xmm1
00007dd8609d919c  movaps [r15+0x1B0], xmm1
00007dd8609d91a4  vmovaps xmm1, [rsp+0x60]
00007dd8609d91aa  vpermilpd xmm1, xmm1, 0x00
00007dd8609d91b0  vmovaps xmm3, [rsp+0x70]
00007dd8609d91b6  vmovaps [rsp+0x70], xmm15
00007dd8609d91bc  movaps xmm9, xmm3
00007dd8609d91c0  mulpd xmm9, xmm1
00007dd8609d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd8609d91cb  ptest xmm15, xmm15
00007dd8609d91d1  jnz 0x00007DD8609DB6C3
00007dd8609d91d7  lea r14, [rax+0xC0]
00007dd8609d91de  movups xmm1, [r13+r14*1]
00007dd8609d91e4  vmovaps xmm3, [rsp+0xC0]
00007dd8609d91ed  vmovaps [rsp+0x80], xmm1
00007dd8609d91f6  movaps xmm15, xmm3
00007dd8609d91fa  addpd xmm15, xmm7
00007dd8609d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8609d9205  ptest xmm1, xmm1
00007dd8609d920a  jnz 0x00007DD8609DB80F
00007dd8609d9210  vmovaps [rsp+0xC0], xmm13
00007dd8609d9219  vmovaps xmm1, [rsp+0xC0]
00007dd8609d9222  por xmm13, xmm1
00007dd8609d9227  movaps [r15+0x270], xmm13
00007dd8609d922f  vmovaps xmm1, [rsp+0xB0]
00007dd8609d9238  vmovaps xmm7, [rsp+0xB0]
00007dd8609d9241  por xmm1, xmm7
00007dd8609d9245  movaps [r15+0x1A0], xmm1
00007dd8609d924d  vmovaps xmm1, [rsp+0x60]
00007dd8609d9253  vpermilpd xmm1, xmm1, 0x00
00007dd8609d9259  vmovaps [rsp+0xB0], xmm1
00007dd8609d9262  vmovaps xmm1, [rsp+0x80]
00007dd8609d926b  vmovaps [rsp+0x80], xmm15
00007dd8609d9274  vmovaps xmm15, [rsp+0xB0]
00007dd8609d927d  vmovaps [rsp+0xB0], xmm14
00007dd8609d9286  movaps xmm3, xmm1
00007dd8609d9289  mulpd xmm3, xmm15
00007dd8609d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007dd8609d9293  ptest xmm14, xmm14
00007dd8609d9299  jnz 0x00007DD8609DB951
00007dd8609d929f  lea r14, [rax+0x20]
00007dd8609d92a3  movups xmm1, [r13+r14*1]
00007dd8609d92a9  movaps [r15+0x110], xmm1
00007dd8609d92b1  vmovaps xmm14, [rsp+0x70]
00007dd8609d92b7  vmovaps [rsp+0x70], xmm1
00007dd8609d92bd  movaps xmm15, xmm14
00007dd8609d92c1  addpd xmm15, xmm4
00007dd8609d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8609d92cc  ptest xmm1, xmm1
00007dd8609d92d1  jnz 0x00007DD8609DBA9C
00007dd8609d92d7  vmovaps xmm1, [rsp+0x60]
00007dd8609d92dd  vpermilpd xmm1, xmm1, 0x00
00007dd8609d92e3  movaps xmm14, xmm2
00007dd8609d92e7  mulpd xmm14, xmm1
00007dd8609d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007dd8609d92f2  ptest xmm4, xmm4
00007dd8609d92f7  jnz 0x00007DD8609DBBDF
00007dd8609d92fd  vmovaps xmm4, [rsp+0x50]
00007dd8609d9303  movaps xmm1, xmm4
00007dd8609d9306  addpd xmm1, xmm9
00007dd8609d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8609d9310  ptest xmm2, xmm2
00007dd8609d9315  jnz 0x00007DD8609DBD21
00007dd8609d931b  vmovaps xmm9, [rsp+0x30]
00007dd8609d9321  vpermilpd xmm9, xmm9, 0x00
00007dd8609d9327  vmovaps xmm2, [rsp+0x70]
00007dd8609d932d  vmovaps [rsp+0x50], xmm1
00007dd8609d9333  movaps xmm4, xmm2
00007dd8609d9336  mulpd xmm4, xmm9
00007dd8609d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd8609d9340  ptest xmm1, xmm1
00007dd8609d9345  jnz 0x00007DD8609DBE62
00007dd8609d934b  vmovaps xmm1, [rsp+0x30]
00007dd8609d9351  vpermilpd xmm1, xmm1, 0x00
00007dd8609d9357  vmovaps xmm2, [rsp+0x90]
00007dd8609d9360  vmovaps [rsp+0x60], xmm15
00007dd8609d9366  movaps xmm9, xmm2
00007dd8609d936a  mulpd xmm9, xmm1
00007dd8609d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd8609d9375  ptest xmm15, xmm15
00007dd8609d937b  jnz 0x00007DD8609DBFA3
00007dd8609d9381  vmovaps xmm15, [rsp+0x80]
00007dd8609d938a  movaps xmm1, xmm15
00007dd8609d938e  addpd xmm1, xmm6
00007dd8609d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8609d9397  ptest xmm2, xmm2
00007dd8609d939c  jnz 0x00007DD8609DC0E5
00007dd8609d93a2  movaps xmm15, xmm5
00007dd8609d93a6  addpd xmm15, xmm3
00007dd8609d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007dd8609d93b1  ptest xmm6, xmm6
00007dd8609d93b6  jnz 0x00007DD8609DC226
00007dd8609d93bc  vmovaps xmm6, [rsp+0x30]
00007dd8609d93c2  vpermilpd xmm6, xmm6, 0x00
00007dd8609d93c8  movaps xmm5, xmm8
00007dd8609d93cc  mulpd xmm5, xmm6
00007dd8609d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007dd8609d93d5  ptest xmm3, xmm3
00007dd8609d93da  jnz 0x00007DD8609DC368
00007dd8609d93e0  vmovaps xmm8, [rsp+0x30]
00007dd8609d93e6  vpermilpd xmm8, xmm8, 0x00
00007dd8609d93ec  movaps xmm6, xmm10
00007dd8609d93f0  mulpd xmm6, xmm8
00007dd8609d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd8609d93fa  ptest xmm3, xmm3
00007dd8609d93ff  jnz 0x00007DD8609DC4A9
00007dd8609d9405  vmovaps xmm8, [rsp+0x60]
00007dd8609d940b  movaps xmm10, xmm8
00007dd8609d940f  addpd xmm10, xmm14
00007dd8609d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007dd8609d941a  ptest xmm3, xmm3
00007dd8609d941f  jnz 0x00007DD8609DC5EB
00007dd8609d9425  vmovaps xmm8, [rsp+0x50]
00007dd8609d942b  movaps xmm14, xmm8
00007dd8609d942f  addpd xmm14, xmm4
00007dd8609d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007dd8609d943a  ptest xmm3, xmm3
00007dd8609d943f  jnz 0x00007DD8609DC72F
00007dd8609d9445  vmovaps xmm8, [rsp+0x40]
00007dd8609d944b  vpermilpd xmm8, xmm8, 0x00
00007dd8609d9451  movaps xmm4, xmm13
00007dd8609d9455  mulpd xmm4, xmm8
00007dd8609d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd8609d945f  ptest xmm3, xmm3
00007dd8609d9464  jnz 0x00007DD8609DC872
00007dd8609d946a  movaps xmm13, xmm15
00007dd8609d946e  addpd xmm13, xmm9
00007dd8609d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007dd8609d9479  ptest xmm8, xmm8
00007dd8609d947f  jnz 0x00007DD8609DC9B4
00007dd8609d9485  movaps xmm15, xmm1
00007dd8609d9489  addpd xmm15, xmm5
00007dd8609d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8609d9494  ptest xmm9, xmm9
00007dd8609d949a  jnz 0x00007DD8609DCAF8
00007dd8609d94a0  vmovaps [rsp+0x30], xmm11
00007dd8609d94a6  vmovaps xmm1, [rsp+0x30]
00007dd8609d94ac  por xmm11, xmm1
00007dd8609d94b1  movaps [r15+0x250], xmm11
00007dd8609d94b9  vmovaps [rsp+0x30], xmm12
00007dd8609d94bf  vmovaps xmm1, [rsp+0x30]
00007dd8609d94c5  por xmm12, xmm1
00007dd8609d94ca  movaps [r15+0x2A0], xmm12
00007dd8609d94d2  vmovaps xmm1, [rsp+0xA0]
00007dd8609d94db  vmovaps xmm11, [rsp+0xA0]
00007dd8609d94e4  por xmm1, xmm11
00007dd8609d94e9  movaps [r15+0x1D0], xmm1
00007dd8609d94f1  lea r14, [rax+0x40]
00007dd8609d94f5  movups xmm1, [r13+r14*1]
00007dd8609d94fb  movaps [r15+0x2C0], xmm1
00007dd8609d9503  vmovaps xmm11, [rsp+0x40]
00007dd8609d9509  vpermilpd xmm11, xmm11, 0x00
00007dd8609d950f  vmovaps xmm8, [rsp+0xE0]
00007dd8609d9518  movaps xmm9, xmm8
00007dd8609d951c  mulpd xmm9, xmm11
00007dd8609d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd8609d9527  ptest xmm5, xmm5
00007dd8609d952c  jnz 0x00007DD8609DCC44
00007dd8609d9532  movaps xmm11, xmm10
00007dd8609d9536  addpd xmm11, xmm6
00007dd8609d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd8609d9541  ptest xmm8, xmm8
00007dd8609d9547  jnz 0x00007DD8609DCD88
00007dd8609d954d  movaps xmm10, xmm14
00007dd8609d9551  addpd xmm10, xmm4
00007dd8609d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd8609d955c  ptest xmm8, xmm8
00007dd8609d9562  jnz 0x00007DD8609DCECB
00007dd8609d9568  vmovaps xmm14, [rsp+0x40]
00007dd8609d956e  vpermilpd xmm14, xmm14, 0x00
00007dd8609d9574  movaps xmm8, xmm1
00007dd8609d9578  mulpd xmm8, xmm14
00007dd8609d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8609d9583  ptest xmm6, xmm6
00007dd8609d9588  jnz 0x00007DD8609DD00E
00007dd8609d958e  movaps xmm1, [r15+0x2B0]
00007dd8609d9596  vmovaps xmm14, [rsp+0x40]
00007dd8609d959c  vpermilpd xmm14, xmm14, 0x00
00007dd8609d95a2  movaps xmm6, xmm1
00007dd8609d95a5  mulpd xmm6, xmm14
00007dd8609d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8609d95af  ptest xmm5, xmm5
00007dd8609d95b4  jnz 0x00007DD8609DD151
00007dd8609d95ba  vmovaps xmm1, [rsp+0x10]
00007dd8609d95c0  vpermilpd xmm1, xmm1, 0x00
00007dd8609d95c6  movaps xmm14, xmm12
00007dd8609d95ca  mulpd xmm14, xmm1
00007dd8609d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007dd8609d95d5  ptest xmm5, xmm5
00007dd8609d95da  jnz 0x00007DD8609DD292
00007dd8609d95e0  movaps xmm1, xmm13
00007dd8609d95e4  addpd xmm1, xmm9
00007dd8609d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8609d95ee  ptest xmm12, xmm12
00007dd8609d95f4  jnz 0x00007DD8609DD3D5
00007dd8609d95fa  vmovaps xmm13, [rsp+0x10]
00007dd8609d9600  vpermilpd xmm13, xmm13, 0x00
00007dd8609d9606  movaps xmm12, xmm7
00007dd8609d960a  mulpd xmm12, xmm13
00007dd8609d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8609d9615  ptest xmm9, xmm9
00007dd8609d961b  jnz 0x00007DD8609DD517
00007dd8609d9621  movaps xmm13, xmm15
00007dd8609d9625  addpd xmm13, xmm8
00007dd8609d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007dd8609d9630  ptest xmm9, xmm9
00007dd8609d9636  jnz 0x00007DD8609DD65A
00007dd8609d963c  movaps xmm15, [r15+0x290]
00007dd8609d9644  vmovaps xmm9, [rsp+0x10]
00007dd8609d964a  vpermilpd xmm9, xmm9, 0x00
00007dd8609d9650  movaps xmm8, xmm15
00007dd8609d9654  mulpd xmm8, xmm9
00007dd8609d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8609d965f  ptest xmm7, xmm7
00007dd8609d9664  jnz 0x00007DD8609DD79E
00007dd8609d966a  movaps xmm15, xmm11
00007dd8609d966e  addpd xmm15, xmm6
00007dd8609d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8609d9679  ptest xmm9, xmm9
00007dd8609d967f  jnz 0x00007DD8609DD8E2
00007dd8609d9685  movaps xmm11, [r15+0x1E0]
00007dd8609d968d  vmovaps xmm9, [rsp+0x10]
00007dd8609d9693  vpermilpd xmm9, xmm9, 0x00
00007dd8609d9699  movaps xmm7, xmm11
00007dd8609d969d  mulpd xmm7, xmm9
00007dd8609d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8609d96a7  ptest xmm6, xmm6
00007dd8609d96ac  jnz 0x00007DD8609DDA25
00007dd8609d96b2  movaps xmm11, xmm10
00007dd8609d96b6  addpd xmm11, xmm14
00007dd8609d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007dd8609d96c1  ptest xmm9, xmm9
00007dd8609d96c7  jnz 0x00007DD8609DDB67
00007dd8609d96cd  lea r14, [rax+0x70]
00007dd8609d96d1  movups xmm14, [r13+r14*1]
00007dd8609d96d7  movaps [r15+0x240], xmm14
00007dd8609d96df  movaps xmm10, xmm1
00007dd8609d96e3  addpd xmm10, xmm12
00007dd8609d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007dd8609d96ee  ptest xmm9, xmm9
00007dd8609d96f4  jnz 0x00007DD8609DDCB5
00007dd8609d96fa  movaps [r15+0x170], xmm10
00007dd8609d9702  vmovaps xmm1, [rsp+0x20]
00007dd8609d9708  vpermilpd xmm1, xmm1, 0x00
00007dd8609d970e  movaps xmm12, xmm14
00007dd8609d9712  mulpd xmm12, xmm1
00007dd8609d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8609d971d  ptest xmm9, xmm9
00007dd8609d9723  jnz 0x00007DD8609DDDF8
00007dd8609d9729  vmovaps xmm1, [rsp+0x20]
00007dd8609d972f  vpermilpd xmm1, xmm1, 0x00
00007dd8609d9735  vmovaps xmm9, [rsp+0xB0]
00007dd8609d973e  movaps xmm14, xmm9
00007dd8609d9742  mulpd xmm14, xmm1
00007dd8609d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8609d974d  ptest xmm6, xmm6
00007dd8609d9752  jnz 0x00007DD8609DDF3B
00007dd8609d9758  movaps [r15+0x180], xmm14
00007dd8609d9760  movaps xmm1, xmm13
00007dd8609d9764  addpd xmm1, xmm8
00007dd8609d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007dd8609d976e  ptest xmm9, xmm9
00007dd8609d9774  jnz 0x00007DD8609DE07E
00007dd8609d977a  movaps [r15+0x210], xmm1
00007dd8609d9782  movups xmm13, [r13+rax*1]
00007dd8609d9788  lea r14, [rax+0x10]
00007dd8609d978c  movups xmm9, [r13+r14*1]
00007dd8609d9792  movaps [r15+0x230], xmm9
00007dd8609d979a  movaps xmm8, xmm15
00007dd8609d979e  addpd xmm8, xmm7
00007dd8609d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8609d97a9  ptest xmm6, xmm6
00007dd8609d97ae  jnz 0x00007DD8609DE1D4
00007dd8609d97b4  movaps [r15+0x130], xmm8
00007dd8609d97bc  vmovaps xmm15, [rsp+0x20]
00007dd8609d97c2  vpermilpd xmm15, xmm15, 0x00
00007dd8609d97c8  movaps xmm7, xmm9
00007dd8609d97cc  mulpd xmm7, xmm15
00007dd8609d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8609d97d6  ptest xmm6, xmm6
00007dd8609d97db  jnz 0x00007DD8609DE317
00007dd8609d97e1  movaps [r15+0x220], xmm7
00007dd8609d97e9  vmovaps xmm15, [rsp+0x20]
00007dd8609d97ef  vpermilpd xmm15, xmm15, 0x00
00007dd8609d97f5  movaps xmm9, xmm13
00007dd8609d97f9  mulpd xmm9, xmm15
00007dd8609d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8609d9804  ptest xmm6, xmm6
00007dd8609d9809  jnz 0x00007DD8609DE459
00007dd8609d980f  movaps xmm15, xmm11
00007dd8609d9813  addpd xmm15, xmm12
00007dd8609d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd8609d981e  ptest xmm13, xmm13
00007dd8609d9824  jnz 0x00007DD8609DE59D
00007dd8609d982a  movaps [r15+0x140], xmm15
00007dd8609d9832  movaps xmm13, xmm10
00007dd8609d9836  addpd xmm13, xmm14
00007dd8609d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd8609d9841  ptest xmm12, xmm12
00007dd8609d9847  jnz 0x00007DD8609DE6E1
00007dd8609d984d  movaps [r15+0x150], xmm13
00007dd8609d9855  movaps xmm14, xmm1
00007dd8609d9859  addpd xmm14, xmm7
00007dd8609d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007dd8609d9864  ptest xmm12, xmm12
00007dd8609d986a  jnz 0x00007DD8609DE825
00007dd8609d9870  movaps [r15+0x160], xmm14
00007dd8609d9878  movaps xmm1, xmm8
00007dd8609d987c  addpd xmm1, xmm9
00007dd8609d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8609d9886  ptest xmm12, xmm12
00007dd8609d988c  jnz 0x00007DD8609DE967
00007dd8609d9892  movaps [r15+0x120], xmm1
00007dd8609d989a  movups [r13+r11*1], xmm15
00007dd8609d98a0  lea rax, [r11+0x10]
00007dd8609d98a4  movups [r13+rax*1], xmm13
00007dd8609d98aa  lea rax, [r11+0x20]
00007dd8609d98ae  movups [r13+rax*1], xmm14
00007dd8609d98b4  lea rax, [r11+0x30]
00007dd8609d98b8  movups [r13+rax*1], xmm1
00007dd8609d98be  mov eax, [r15+0x108]
00007dd8609d98c5  sahf
00007dd8609d98c6  jnz 0x00007DD8609D98F8
00007dd8609d98c8  cmp dword ptr [r15+0x318], 0x00
00007dd8609d98d0  jz 0x00007DD8609DEAE0
00007dd8609d98d6  nop [rax+rax*1], ax
00007dd8609d98df  nop [rax+rax*1], eax
00007dd8609d98e7  mov eax, 0x4106D0
00007dd8609d98ec  mov [r15+0x100], rax
00007dd8609d98f3  jmp 0x00007DD8607FE110
00007dd8609d98f8  cmp dword ptr [r15+0x318], 0x00
00007dd8609d9900  jz 0x00007DD8609D89C0
00007dd8609d9906  nop [rax+rax*1], ax
00007dd8609d990f  nop [rax+rax*1], eax
00007dd8609d9917  mov eax, 0x410504
00007dd8609d991c  mov [r15+0x100], rax
00007dd8609d9923  jmp 0x00007DD8607FE110
00007dd8609d9928  int3
00007dd8609d9929  call 0x00007DD86080A4B0
00007dd8609d992e  jmp 0x00007DD8609D8A08
00007dd8609d9933  call 0x00007DD860809240
00007dd8609d9938  jmp 0x00007DD8609D8A12
00007dd8609d993d  call 0x00007DD86080A4B0
00007dd8609d9942  jmp 0x00007DD8609D8A6F
00007dd8609d9947  call 0x00007DD860809240
00007dd8609d994c  jmp 0x00007DD8609D8A79
00007dd8609d9951  call 0x00007DD86080A4B0
00007dd8609d9956  jmp 0x00007DD8609D8ABD
00007dd8609d995b  call 0x00007DD860809240
00007dd8609d9960  jmp 0x00007DD8609D8AC7
00007dd8609d9965  call 0x00007DD8608B47C0
00007dd8609d996a  jmp 0x00007DD8609D8B06
00007dd8609d996f  call 0x00007DD86080B720
00007dd8609d9974  jmp 0x00007DD8609D8B1A
00007dd8609d9979  call 0x00007DD8608BFC30
00007dd8609d997e  jmp 0x00007DD8609D8B38
00007dd8609d9983  call 0x00007DD8608BE9C0
00007dd8609d9988  jmp 0x00007DD8609D8B42
00007dd8609d998d  call 0x00007DD8608BD750
00007dd8609d9992  jmp 0x00007DD8609D8B4C
00007dd8609d9997  sub rsp, 0x08
00007dd8609d999b  push rax
00007dd8609d999c  push rcx
00007dd8609d999d  push rdx
00007dd8609d999e  push rdi
00007dd8609d999f  push rsi
00007dd8609d99a0  push r8
00007dd8609d99a2  push r9
00007dd8609d99a4  push r10
00007dd8609d99a6  push r11
00007dd8609d99a8  sub rsp, 0xF0
00007dd8609d99af  vmovaps [rsp], xmm0
00007dd8609d99b4  vmovaps [rsp+0x10], xmm1
00007dd8609d99ba  vmovaps [rsp+0x20], xmm2
00007dd8609d99c0  vmovaps [rsp+0x30], xmm3
00007dd8609d99c6  vmovaps [rsp+0x40], xmm4
00007dd8609d99cc  vmovaps [rsp+0x50], xmm5
00007dd8609d99d2  vmovaps [rsp+0x60], xmm6
00007dd8609d99d8  vmovaps [rsp+0x70], xmm7
00007dd8609d99de  vmovaps [rsp+0x80], xmm9
00007dd8609d99e7  vmovaps [rsp+0x90], xmm10
00007dd8609d99f0  vmovaps [rsp+0xA0], xmm11
00007dd8609d99f9  vmovaps [rsp+0xB0], xmm12
00007dd8609d9a02  vmovaps [rsp+0xC0], xmm13
00007dd8609d9a0b  vmovaps [rsp+0xD0], xmm14
00007dd8609d9a14  vmovaps [rsp+0xE0], xmm15
00007dd8609d9a1d  sub rsp, 0x30
00007dd8609d9a21  movaps [rsp], xmm8
00007dd8609d9a26  movaps [rsp+0x10], xmm12
00007dd8609d9a2c  movaps [rsp+0x20], xmm15
00007dd8609d9a32  lea rdi, [rsp]
00007dd8609d9a36  mov esi, 0x00
00007dd8609d9a3b  mov rax, 0x629C9CFA9530
00007dd8609d9a45  call rax
00007dd8609d9a47  movaps xmm8, [rsp]
00007dd8609d9a4c  add rsp, 0x30
00007dd8609d9a50  vmovaps xmm0, [rsp]
00007dd8609d9a55  vmovaps xmm1, [rsp+0x10]
00007dd8609d9a5b  vmovaps xmm2, [rsp+0x20]
00007dd8609d9a61  vmovaps xmm3, [rsp+0x30]
00007dd8609d9a67  vmovaps xmm4, [rsp+0x40]
00007dd8609d9a6d  vmovaps xmm5, [rsp+0x50]
00007dd8609d9a73  vmovaps xmm6, [rsp+0x60]
00007dd8609d9a79  vmovaps xmm7, [rsp+0x70]
00007dd8609d9a7f  vmovaps xmm9, [rsp+0x80]
00007dd8609d9a88  vmovaps xmm10, [rsp+0x90]
00007dd8609d9a91  vmovaps xmm11, [rsp+0xA0]
00007dd8609d9a9a  vmovaps xmm12, [rsp+0xB0]
00007dd8609d9aa3  vmovaps xmm13, [rsp+0xC0]
00007dd8609d9aac  vmovaps xmm14, [rsp+0xD0]
00007dd8609d9ab5  vmovaps xmm15, [rsp+0xE0]
00007dd8609d9abe  add rsp, 0xF0
00007dd8609d9ac5  pop r11
00007dd8609d9ac7  pop r10
00007dd8609d9ac9  pop r9
00007dd8609d9acb  pop r8
00007dd8609d9acd  pop rsi
00007dd8609d9ace  pop rdi
00007dd8609d9acf  pop rdx
00007dd8609d9ad0  pop rcx
00007dd8609d9ad1  pop rax
00007dd8609d9ad2  add rsp, 0x08
00007dd8609d9ad6  jmp 0x00007DD8609D8B7A
00007dd8609d9adb  sub rsp, 0x08
00007dd8609d9adf  push rax
00007dd8609d9ae0  push rcx
00007dd8609d9ae1  push rdx
00007dd8609d9ae2  push rdi
00007dd8609d9ae3  push rsi
00007dd8609d9ae4  push r8
00007dd8609d9ae6  push r9
00007dd8609d9ae8  push r10
00007dd8609d9aea  push r11
00007dd8609d9aec  sub rsp, 0xF0
00007dd8609d9af3  vmovaps [rsp], xmm0
00007dd8609d9af8  vmovaps [rsp+0x10], xmm1
00007dd8609d9afe  vmovaps [rsp+0x20], xmm2
00007dd8609d9b04  vmovaps [rsp+0x30], xmm3
00007dd8609d9b0a  vmovaps [rsp+0x40], xmm4
00007dd8609d9b10  vmovaps [rsp+0x50], xmm5
00007dd8609d9b16  vmovaps [rsp+0x60], xmm6
00007dd8609d9b1c  vmovaps [rsp+0x70], xmm8
00007dd8609d9b22  vmovaps [rsp+0x80], xmm9
00007dd8609d9b2b  vmovaps [rsp+0x90], xmm10
00007dd8609d9b34  vmovaps [rsp+0xA0], xmm11
00007dd8609d9b3d  vmovaps [rsp+0xB0], xmm12
00007dd8609d9b46  vmovaps [rsp+0xC0], xmm13
00007dd8609d9b4f  vmovaps [rsp+0xD0], xmm14
00007dd8609d9b58  vmovaps [rsp+0xE0], xmm15
00007dd8609d9b61  sub rsp, 0x30
00007dd8609d9b65  movaps [rsp], xmm7
00007dd8609d9b69  movaps [rsp+0x10], xmm9
00007dd8609d9b6f  movaps [rsp+0x20], xmm15
00007dd8609d9b75  lea rdi, [rsp]
00007dd8609d9b79  mov esi, 0x00
00007dd8609d9b7e  mov rax, 0x629C9CFA9530
00007dd8609d9b88  call rax
00007dd8609d9b8a  movaps xmm7, [rsp]
00007dd8609d9b8e  add rsp, 0x30
00007dd8609d9b92  vmovaps xmm0, [rsp]
00007dd8609d9b97  vmovaps xmm1, [rsp+0x10]
00007dd8609d9b9d  vmovaps xmm2, [rsp+0x20]
00007dd8609d9ba3  vmovaps xmm3, [rsp+0x30]
00007dd8609d9ba9  vmovaps xmm4, [rsp+0x40]
00007dd8609d9baf  vmovaps xmm5, [rsp+0x50]
00007dd8609d9bb5  vmovaps xmm6, [rsp+0x60]
00007dd8609d9bbb  vmovaps xmm8, [rsp+0x70]
00007dd8609d9bc1  vmovaps xmm9, [rsp+0x80]
00007dd8609d9bca  vmovaps xmm10, [rsp+0x90]
00007dd8609d9bd3  vmovaps xmm11, [rsp+0xA0]
00007dd8609d9bdc  vmovaps xmm12, [rsp+0xB0]
00007dd8609d9be5  vmovaps xmm13, [rsp+0xC0]
00007dd8609d9bee  vmovaps xmm14, [rsp+0xD0]
00007dd8609d9bf7  vmovaps xmm15, [rsp+0xE0]
00007dd8609d9c00  add rsp, 0xF0
00007dd8609d9c07  pop r11
00007dd8609d9c09  pop r10
00007dd8609d9c0b  pop r9
00007dd8609d9c0d  pop r8
00007dd8609d9c0f  pop rsi
00007dd8609d9c10  pop rdi
00007dd8609d9c11  pop rdx
00007dd8609d9c12  pop rcx
00007dd8609d9c13  pop rax
00007dd8609d9c14  add rsp, 0x08
00007dd8609d9c18  jmp 0x00007DD8609D8BA8
00007dd8609d9c1d  sub rsp, 0x08
00007dd8609d9c21  push rax
00007dd8609d9c22  push rcx
00007dd8609d9c23  push rdx
00007dd8609d9c24  push rdi
00007dd8609d9c25  push rsi
00007dd8609d9c26  push r8
00007dd8609d9c28  push r9
00007dd8609d9c2a  push r10
00007dd8609d9c2c  push r11
00007dd8609d9c2e  sub rsp, 0xF0
00007dd8609d9c35  vmovaps [rsp], xmm0
00007dd8609d9c3a  vmovaps [rsp+0x10], xmm1
00007dd8609d9c40  vmovaps [rsp+0x20], xmm2
00007dd8609d9c46  vmovaps [rsp+0x30], xmm3
00007dd8609d9c4c  vmovaps [rsp+0x40], xmm4
00007dd8609d9c52  vmovaps [rsp+0x50], xmm5
00007dd8609d9c58  vmovaps [rsp+0x60], xmm6
00007dd8609d9c5e  vmovaps [rsp+0x70], xmm7
00007dd8609d9c64  vmovaps [rsp+0x80], xmm8
00007dd8609d9c6d  vmovaps [rsp+0x90], xmm10
00007dd8609d9c76  vmovaps [rsp+0xA0], xmm11
00007dd8609d9c7f  vmovaps [rsp+0xB0], xmm12
00007dd8609d9c88  vmovaps [rsp+0xC0], xmm13
00007dd8609d9c91  vmovaps [rsp+0xD0], xmm14
00007dd8609d9c9a  vmovaps [rsp+0xE0], xmm15
00007dd8609d9ca3  sub rsp, 0x30
00007dd8609d9ca7  movaps [rsp], xmm9
00007dd8609d9cac  movaps [rsp+0x10], xmm12
00007dd8609d9cb2  movaps [rsp+0x20], xmm10
00007dd8609d9cb8  lea rdi, [rsp]
00007dd8609d9cbc  mov esi, 0x00
00007dd8609d9cc1  mov rax, 0x629C9CFA9530
00007dd8609d9ccb  call rax
00007dd8609d9ccd  movaps xmm9, [rsp]
00007dd8609d9cd2  add rsp, 0x30
00007dd8609d9cd6  vmovaps xmm0, [rsp]
00007dd8609d9cdb  vmovaps xmm1, [rsp+0x10]
00007dd8609d9ce1  vmovaps xmm2, [rsp+0x20]
00007dd8609d9ce7  vmovaps xmm3, [rsp+0x30]
00007dd8609d9ced  vmovaps xmm4, [rsp+0x40]
00007dd8609d9cf3  vmovaps xmm5, [rsp+0x50]
00007dd8609d9cf9  vmovaps xmm6, [rsp+0x60]
00007dd8609d9cff  vmovaps xmm7, [rsp+0x70]
00007dd8609d9d05  vmovaps xmm8, [rsp+0x80]
00007dd8609d9d0e  vmovaps xmm10, [rsp+0x90]
00007dd8609d9d17  vmovaps xmm11, [rsp+0xA0]
00007dd8609d9d20  vmovaps xmm12, [rsp+0xB0]
00007dd8609d9d29  vmovaps xmm13, [rsp+0xC0]
00007dd8609d9d32  vmovaps xmm14, [rsp+0xD0]
00007dd8609d9d3b  vmovaps xmm15, [rsp+0xE0]
00007dd8609d9d44  add rsp, 0xF0
00007dd8609d9d4b  pop r11
00007dd8609d9d4d  pop r10
00007dd8609d9d4f  pop r9
00007dd8609d9d51  pop r8
00007dd8609d9d53  pop rsi
00007dd8609d9d54  pop rdi
00007dd8609d9d55  pop rdx
00007dd8609d9d56  pop rcx
00007dd8609d9d57  pop rax
00007dd8609d9d58  add rsp, 0x08
00007dd8609d9d5c  jmp 0x00007DD8609D8BCC
00007dd8609d9d61  sub rsp, 0x08
00007dd8609d9d65  push rax
00007dd8609d9d66  push rcx
00007dd8609d9d67  push rdx
00007dd8609d9d68  push rdi
00007dd8609d9d69  push rsi
00007dd8609d9d6a  push r8
00007dd8609d9d6c  push r9
00007dd8609d9d6e  push r10
00007dd8609d9d70  push r11
00007dd8609d9d72  sub rsp, 0xF0
00007dd8609d9d79  vmovaps [rsp], xmm0
00007dd8609d9d7e  vmovaps [rsp+0x10], xmm1
00007dd8609d9d84  vmovaps [rsp+0x20], xmm2
00007dd8609d9d8a  vmovaps [rsp+0x30], xmm3
00007dd8609d9d90  vmovaps [rsp+0x40], xmm4
00007dd8609d9d96  vmovaps [rsp+0x50], xmm5
00007dd8609d9d9c  vmovaps [rsp+0x60], xmm6
00007dd8609d9da2  vmovaps [rsp+0x70], xmm7
00007dd8609d9da8  vmovaps [rsp+0x80], xmm8
00007dd8609d9db1  vmovaps [rsp+0x90], xmm9
00007dd8609d9dba  vmovaps [rsp+0xA0], xmm11
00007dd8609d9dc3  vmovaps [rsp+0xB0], xmm12
00007dd8609d9dcc  vmovaps [rsp+0xC0], xmm13
00007dd8609d9dd5  vmovaps [rsp+0xD0], xmm14
00007dd8609d9dde  vmovaps [rsp+0xE0], xmm15
00007dd8609d9de7  sub rsp, 0x30
00007dd8609d9deb  movaps [rsp], xmm10
00007dd8609d9df0  movaps [rsp+0x10], xmm12
00007dd8609d9df6  movaps [rsp+0x20], xmm11
00007dd8609d9dfc  lea rdi, [rsp]
00007dd8609d9e00  mov esi, 0x00
00007dd8609d9e05  mov rax, 0x629C9CFA9530
00007dd8609d9e0f  call rax
00007dd8609d9e11  movaps xmm10, [rsp]
00007dd8609d9e16  add rsp, 0x30
00007dd8609d9e1a  vmovaps xmm0, [rsp]
00007dd8609d9e1f  vmovaps xmm1, [rsp+0x10]
00007dd8609d9e25  vmovaps xmm2, [rsp+0x20]
00007dd8609d9e2b  vmovaps xmm3, [rsp+0x30]
00007dd8609d9e31  vmovaps xmm4, [rsp+0x40]
00007dd8609d9e37  vmovaps xmm5, [rsp+0x50]
00007dd8609d9e3d  vmovaps xmm6, [rsp+0x60]
00007dd8609d9e43  vmovaps xmm7, [rsp+0x70]
00007dd8609d9e49  vmovaps xmm8, [rsp+0x80]
00007dd8609d9e52  vmovaps xmm9, [rsp+0x90]
00007dd8609d9e5b  vmovaps xmm11, [rsp+0xA0]
00007dd8609d9e64  vmovaps xmm12, [rsp+0xB0]
00007dd8609d9e6d  vmovaps xmm13, [rsp+0xC0]
00007dd8609d9e76  vmovaps xmm14, [rsp+0xD0]
00007dd8609d9e7f  vmovaps xmm15, [rsp+0xE0]
00007dd8609d9e88  add rsp, 0xF0
00007dd8609d9e8f  pop r11
00007dd8609d9e91  pop r10
00007dd8609d9e93  pop r9
00007dd8609d9e95  pop r8
00007dd8609d9e97  pop rsi
00007dd8609d9e98  pop rdi
00007dd8609d9e99  pop rdx
00007dd8609d9e9a  pop rcx
00007dd8609d9e9b  pop rax
00007dd8609d9e9c  add rsp, 0x08
00007dd8609d9ea0  jmp 0x00007DD8609D8BE6
00007dd8609d9ea5  sub rsp, 0x08
00007dd8609d9ea9  push rax
00007dd8609d9eaa  push rcx
00007dd8609d9eab  push rdx
00007dd8609d9eac  push rdi
00007dd8609d9ead  push rsi
00007dd8609d9eae  push r8
00007dd8609d9eb0  push r9
00007dd8609d9eb2  push r10
00007dd8609d9eb4  push r11
00007dd8609d9eb6  sub rsp, 0xF0
00007dd8609d9ebd  vmovaps [rsp], xmm0
00007dd8609d9ec2  vmovaps [rsp+0x10], xmm1
00007dd8609d9ec8  vmovaps [rsp+0x20], xmm2
00007dd8609d9ece  vmovaps [rsp+0x30], xmm3
00007dd8609d9ed4  vmovaps [rsp+0x40], xmm4
00007dd8609d9eda  vmovaps [rsp+0x50], xmm5
00007dd8609d9ee0  vmovaps [rsp+0x60], xmm7
00007dd8609d9ee6  vmovaps [rsp+0x70], xmm8
00007dd8609d9eec  vmovaps [rsp+0x80], xmm9
00007dd8609d9ef5  vmovaps [rsp+0x90], xmm10
00007dd8609d9efe  vmovaps [rsp+0xA0], xmm11
00007dd8609d9f07  vmovaps [rsp+0xB0], xmm12
00007dd8609d9f10  vmovaps [rsp+0xC0], xmm13
00007dd8609d9f19  vmovaps [rsp+0xD0], xmm14
00007dd8609d9f22  vmovaps [rsp+0xE0], xmm15
00007dd8609d9f2b  sub rsp, 0x30
00007dd8609d9f2f  movaps [rsp], xmm6
00007dd8609d9f33  movaps [rsp+0x10], xmm12
00007dd8609d9f39  movaps [rsp+0x20], xmm11
00007dd8609d9f3f  lea rdi, [rsp]
00007dd8609d9f43  mov esi, 0x00
00007dd8609d9f48  mov rax, 0x629C9CFA9530
00007dd8609d9f52  call rax
00007dd8609d9f54  movaps xmm6, [rsp]
00007dd8609d9f58  add rsp, 0x30
00007dd8609d9f5c  vmovaps xmm0, [rsp]
00007dd8609d9f61  vmovaps xmm1, [rsp+0x10]
00007dd8609d9f67  vmovaps xmm2, [rsp+0x20]
00007dd8609d9f6d  vmovaps xmm3, [rsp+0x30]
00007dd8609d9f73  vmovaps xmm4, [rsp+0x40]
00007dd8609d9f79  vmovaps xmm5, [rsp+0x50]
00007dd8609d9f7f  vmovaps xmm7, [rsp+0x60]
00007dd8609d9f85  vmovaps xmm8, [rsp+0x70]
00007dd8609d9f8b  vmovaps xmm9, [rsp+0x80]
00007dd8609d9f94  vmovaps xmm10, [rsp+0x90]
00007dd8609d9f9d  vmovaps xmm11, [rsp+0xA0]
00007dd8609d9fa6  vmovaps xmm12, [rsp+0xB0]
00007dd8609d9faf  vmovaps xmm13, [rsp+0xC0]
00007dd8609d9fb8  vmovaps xmm14, [rsp+0xD0]
00007dd8609d9fc1  vmovaps xmm15, [rsp+0xE0]
00007dd8609d9fca  add rsp, 0xF0
00007dd8609d9fd1  pop r11
00007dd8609d9fd3  pop r10
00007dd8609d9fd5  pop r9
00007dd8609d9fd7  pop r8
00007dd8609d9fd9  pop rsi
00007dd8609d9fda  pop rdi
00007dd8609d9fdb  pop rdx
00007dd8609d9fdc  pop rcx
00007dd8609d9fdd  pop rax
00007dd8609d9fde  add rsp, 0x08
00007dd8609d9fe2  jmp 0x00007DD8609D8C07
00007dd8609d9fe7  sub rsp, 0x08
00007dd8609d9feb  push rax
00007dd8609d9fec  push rcx
00007dd8609d9fed  push rdx
00007dd8609d9fee  push rdi
00007dd8609d9fef  push rsi
00007dd8609d9ff0  push r8
00007dd8609d9ff2  push r9
00007dd8609d9ff4  push r10
00007dd8609d9ff6  push r11
00007dd8609d9ff8  sub rsp, 0xF0
00007dd8609d9fff  vmovaps [rsp], xmm0
00007dd8609da004  vmovaps [rsp+0x10], xmm1
00007dd8609da00a  vmovaps [rsp+0x20], xmm2
00007dd8609da010  vmovaps [rsp+0x30], xmm4
00007dd8609da016  vmovaps [rsp+0x40], xmm5
00007dd8609da01c  vmovaps [rsp+0x50], xmm6
00007dd8609da022  vmovaps [rsp+0x60], xmm7
00007dd8609da028  vmovaps [rsp+0x70], xmm8
00007dd8609da02e  vmovaps [rsp+0x80], xmm9
00007dd8609da037  vmovaps [rsp+0x90], xmm10
00007dd8609da040  vmovaps [rsp+0xA0], xmm11
00007dd8609da049  vmovaps [rsp+0xB0], xmm12
00007dd8609da052  vmovaps [rsp+0xC0], xmm13
00007dd8609da05b  vmovaps [rsp+0xD0], xmm14
00007dd8609da064  vmovaps [rsp+0xE0], xmm15
00007dd8609da06d  sub rsp, 0x30
00007dd8609da071  movaps [rsp], xmm3
00007dd8609da075  movaps [rsp+0x10], xmm5
00007dd8609da07a  movaps [rsp+0x20], xmm4
00007dd8609da07f  lea rdi, [rsp]
00007dd8609da083  mov esi, 0x00
00007dd8609da088  mov rax, 0x629C9CFA9530
00007dd8609da092  call rax
00007dd8609da094  movaps xmm3, [rsp]
00007dd8609da098  add rsp, 0x30
00007dd8609da09c  vmovaps xmm0, [rsp]
00007dd8609da0a1  vmovaps xmm1, [rsp+0x10]
00007dd8609da0a7  vmovaps xmm2, [rsp+0x20]
00007dd8609da0ad  vmovaps xmm4, [rsp+0x30]
00007dd8609da0b3  vmovaps xmm5, [rsp+0x40]
00007dd8609da0b9  vmovaps xmm6, [rsp+0x50]
00007dd8609da0bf  vmovaps xmm7, [rsp+0x60]
00007dd8609da0c5  vmovaps xmm8, [rsp+0x70]
00007dd8609da0cb  vmovaps xmm9, [rsp+0x80]
00007dd8609da0d4  vmovaps xmm10, [rsp+0x90]
00007dd8609da0dd  vmovaps xmm11, [rsp+0xA0]
00007dd8609da0e6  vmovaps xmm12, [rsp+0xB0]
00007dd8609da0ef  vmovaps xmm13, [rsp+0xC0]
00007dd8609da0f8  vmovaps xmm14, [rsp+0xD0]
00007dd8609da101  vmovaps xmm15, [rsp+0xE0]
00007dd8609da10a  add rsp, 0xF0
00007dd8609da111  pop r11
00007dd8609da113  pop r10
00007dd8609da115  pop r9
00007dd8609da117  pop r8
00007dd8609da119  pop rsi
00007dd8609da11a  pop rdi
00007dd8609da11b  pop rdx
00007dd8609da11c  pop rcx
00007dd8609da11d  pop rax
00007dd8609da11e  add rsp, 0x08
00007dd8609da122  jmp 0x00007DD8609D8C68
00007dd8609da127  sub rsp, 0x08
00007dd8609da12b  push rax
00007dd8609da12c  push rcx
00007dd8609da12d  push rdx
00007dd8609da12e  push rdi
00007dd8609da12f  push rsi
00007dd8609da130  push r8
00007dd8609da132  push r9
00007dd8609da134  push r10
00007dd8609da136  push r11
00007dd8609da138  sub rsp, 0xF0
00007dd8609da13f  vmovaps [rsp], xmm0
00007dd8609da144  vmovaps [rsp+0x10], xmm1
00007dd8609da14a  vmovaps [rsp+0x20], xmm2
00007dd8609da150  vmovaps [rsp+0x30], xmm3
00007dd8609da156  vmovaps [rsp+0x40], xmm4
00007dd8609da15c  vmovaps [rsp+0x50], xmm6
00007dd8609da162  vmovaps [rsp+0x60], xmm7
00007dd8609da168  vmovaps [rsp+0x70], xmm8
00007dd8609da16e  vmovaps [rsp+0x80], xmm9
00007dd8609da177  vmovaps [rsp+0x90], xmm10
00007dd8609da180  vmovaps [rsp+0xA0], xmm11
00007dd8609da189  vmovaps [rsp+0xB0], xmm12
00007dd8609da192  vmovaps [rsp+0xC0], xmm13
00007dd8609da19b  vmovaps [rsp+0xD0], xmm14
00007dd8609da1a4  vmovaps [rsp+0xE0], xmm15
00007dd8609da1ad  sub rsp, 0x30
00007dd8609da1b1  movaps [rsp], xmm5
00007dd8609da1b5  movaps [rsp+0x10], xmm8
00007dd8609da1bb  movaps [rsp+0x20], xmm15
00007dd8609da1c1  lea rdi, [rsp]
00007dd8609da1c5  mov esi, 0x00
00007dd8609da1ca  mov rax, 0x629C9CFA9530
00007dd8609da1d4  call rax
00007dd8609da1d6  movaps xmm5, [rsp]
00007dd8609da1da  add rsp, 0x30
00007dd8609da1de  vmovaps xmm0, [rsp]
00007dd8609da1e3  vmovaps xmm1, [rsp+0x10]
00007dd8609da1e9  vmovaps xmm2, [rsp+0x20]
00007dd8609da1ef  vmovaps xmm3, [rsp+0x30]
00007dd8609da1f5  vmovaps xmm4, [rsp+0x40]
00007dd8609da1fb  vmovaps xmm6, [rsp+0x50]
00007dd8609da201  vmovaps xmm7, [rsp+0x60]
00007dd8609da207  vmovaps xmm8, [rsp+0x70]
00007dd8609da20d  vmovaps xmm9, [rsp+0x80]
00007dd8609da216  vmovaps xmm10, [rsp+0x90]
00007dd8609da21f  vmovaps xmm11, [rsp+0xA0]
00007dd8609da228  vmovaps xmm12, [rsp+0xB0]
00007dd8609da231  vmovaps xmm13, [rsp+0xC0]
00007dd8609da23a  vmovaps xmm14, [rsp+0xD0]
00007dd8609da243  vmovaps xmm15, [rsp+0xE0]
00007dd8609da24c  add rsp, 0xF0
00007dd8609da253  pop r11
00007dd8609da255  pop r10
00007dd8609da257  pop r9
00007dd8609da259  pop r8
00007dd8609da25b  pop rsi
00007dd8609da25c  pop rdi
00007dd8609da25d  pop rdx
00007dd8609da25e  pop rcx
00007dd8609da25f  pop rax
00007dd8609da260  add rsp, 0x08
00007dd8609da264  jmp 0x00007DD8609D8CA0
00007dd8609da269  sub rsp, 0x08
00007dd8609da26d  push rax
00007dd8609da26e  push rcx
00007dd8609da26f  push rdx
00007dd8609da270  push rdi
00007dd8609da271  push rsi
00007dd8609da272  push r8
00007dd8609da274  push r9
00007dd8609da276  push r10
00007dd8609da278  push r11
00007dd8609da27a  sub rsp, 0xF0
00007dd8609da281  vmovaps [rsp], xmm0
00007dd8609da286  vmovaps [rsp+0x10], xmm1
00007dd8609da28c  vmovaps [rsp+0x20], xmm2
00007dd8609da292  vmovaps [rsp+0x30], xmm3
00007dd8609da298  vmovaps [rsp+0x40], xmm5
00007dd8609da29e  vmovaps [rsp+0x50], xmm6
00007dd8609da2a4  vmovaps [rsp+0x60], xmm7
00007dd8609da2aa  vmovaps [rsp+0x70], xmm8
00007dd8609da2b0  vmovaps [rsp+0x80], xmm9
00007dd8609da2b9  vmovaps [rsp+0x90], xmm10
00007dd8609da2c2  vmovaps [rsp+0xA0], xmm11
00007dd8609da2cb  vmovaps [rsp+0xB0], xmm12
00007dd8609da2d4  vmovaps [rsp+0xC0], xmm13
00007dd8609da2dd  vmovaps [rsp+0xD0], xmm14
00007dd8609da2e6  vmovaps [rsp+0xE0], xmm15
00007dd8609da2ef  sub rsp, 0x30
00007dd8609da2f3  movaps [rsp], xmm4
00007dd8609da2f7  movaps [rsp+0x10], xmm9
00007dd8609da2fd  movaps [rsp+0x20], xmm8
00007dd8609da303  lea rdi, [rsp]
00007dd8609da307  mov esi, 0x00
00007dd8609da30c  mov rax, 0x629C9CFA9530
00007dd8609da316  call rax
00007dd8609da318  movaps xmm4, [rsp]
00007dd8609da31c  add rsp, 0x30
00007dd8609da320  vmovaps xmm0, [rsp]
00007dd8609da325  vmovaps xmm1, [rsp+0x10]
00007dd8609da32b  vmovaps xmm2, [rsp+0x20]
00007dd8609da331  vmovaps xmm3, [rsp+0x30]
00007dd8609da337  vmovaps xmm5, [rsp+0x40]
00007dd8609da33d  vmovaps xmm6, [rsp+0x50]
00007dd8609da343  vmovaps xmm7, [rsp+0x60]
00007dd8609da349  vmovaps xmm8, [rsp+0x70]
00007dd8609da34f  vmovaps xmm9, [rsp+0x80]
00007dd8609da358  vmovaps xmm10, [rsp+0x90]
00007dd8609da361  vmovaps xmm11, [rsp+0xA0]
00007dd8609da36a  vmovaps xmm12, [rsp+0xB0]
00007dd8609da373  vmovaps xmm13, [rsp+0xC0]
00007dd8609da37c  vmovaps xmm14, [rsp+0xD0]
00007dd8609da385  vmovaps xmm15, [rsp+0xE0]
00007dd8609da38e  add rsp, 0xF0
00007dd8609da395  pop r11
00007dd8609da397  pop r10
00007dd8609da399  pop r9
00007dd8609da39b  pop r8
00007dd8609da39d  pop rsi
00007dd8609da39e  pop rdi
00007dd8609da39f  pop rdx
00007dd8609da3a0  pop rcx
00007dd8609da3a1  pop rax
00007dd8609da3a2  add rsp, 0x08
00007dd8609da3a6  jmp 0x00007DD8609D8CC1
00007dd8609da3ab  sub rsp, 0x08
00007dd8609da3af  push rax
00007dd8609da3b0  push rcx
00007dd8609da3b1  push rdx
00007dd8609da3b2  push rdi
00007dd8609da3b3  push rsi
00007dd8609da3b4  push r8
00007dd8609da3b6  push r9
00007dd8609da3b8  push r10
00007dd8609da3ba  push r11
00007dd8609da3bc  sub rsp, 0xF0
00007dd8609da3c3  vmovaps [rsp], xmm0
00007dd8609da3c8  vmovaps [rsp+0x10], xmm1
00007dd8609da3ce  vmovaps [rsp+0x20], xmm2
00007dd8609da3d4  vmovaps [rsp+0x30], xmm3
00007dd8609da3da  vmovaps [rsp+0x40], xmm4
00007dd8609da3e0  vmovaps [rsp+0x50], xmm5
00007dd8609da3e6  vmovaps [rsp+0x60], xmm6
00007dd8609da3ec  vmovaps [rsp+0x70], xmm7
00007dd8609da3f2  vmovaps [rsp+0x80], xmm8
00007dd8609da3fb  vmovaps [rsp+0x90], xmm10
00007dd8609da404  vmovaps [rsp+0xA0], xmm11
00007dd8609da40d  vmovaps [rsp+0xB0], xmm12
00007dd8609da416  vmovaps [rsp+0xC0], xmm13
00007dd8609da41f  vmovaps [rsp+0xD0], xmm14
00007dd8609da428  vmovaps [rsp+0xE0], xmm15
00007dd8609da431  sub rsp, 0x30
00007dd8609da435  movaps [rsp], xmm9
00007dd8609da43a  movaps [rsp+0x10], xmm10
00007dd8609da440  movaps [rsp+0x20], xmm8
00007dd8609da446  lea rdi, [rsp]
00007dd8609da44a  mov esi, 0x00
00007dd8609da44f  mov rax, 0x629C9CFA9530
00007dd8609da459  call rax
00007dd8609da45b  movaps xmm9, [rsp]
00007dd8609da460  add rsp, 0x30
00007dd8609da464  vmovaps xmm0, [rsp]
00007dd8609da469  vmovaps xmm1, [rsp+0x10]
00007dd8609da46f  vmovaps xmm2, [rsp+0x20]
00007dd8609da475  vmovaps xmm3, [rsp+0x30]
00007dd8609da47b  vmovaps xmm4, [rsp+0x40]
00007dd8609da481  vmovaps xmm5, [rsp+0x50]
00007dd8609da487  vmovaps xmm6, [rsp+0x60]
00007dd8609da48d  vmovaps xmm7, [rsp+0x70]
00007dd8609da493  vmovaps xmm8, [rsp+0x80]
00007dd8609da49c  vmovaps xmm10, [rsp+0x90]
00007dd8609da4a5  vmovaps xmm11, [rsp+0xA0]
00007dd8609da4ae  vmovaps xmm12, [rsp+0xB0]
00007dd8609da4b7  vmovaps xmm13, [rsp+0xC0]
00007dd8609da4c0  vmovaps xmm14, [rsp+0xD0]
00007dd8609da4c9  vmovaps xmm15, [rsp+0xE0]
00007dd8609da4d2  add rsp, 0xF0
00007dd8609da4d9  pop r11
00007dd8609da4db  pop r10
00007dd8609da4dd  pop r9
00007dd8609da4df  pop r8
00007dd8609da4e1  pop rsi
00007dd8609da4e2  pop rdi
00007dd8609da4e3  pop rdx
00007dd8609da4e4  pop rcx
00007dd8609da4e5  pop rax
00007dd8609da4e6  add rsp, 0x08
00007dd8609da4ea  jmp 0x00007DD8609D8CDB
00007dd8609da4ef  call 0x00007DD8608D64F0
00007dd8609da4f4  jmp 0x00007DD8609D8DF5
00007dd8609da4f9  call 0x00007DD8608D64F0
00007dd8609da4fe  jmp 0x00007DD8609D8E0B
00007dd8609da503  sub rsp, 0x08
00007dd8609da507  push rax
00007dd8609da508  push rcx
00007dd8609da509  push rdx
00007dd8609da50a  push rdi
00007dd8609da50b  push rsi
00007dd8609da50c  push r8
00007dd8609da50e  push r9
00007dd8609da510  push r10
00007dd8609da512  push r11
00007dd8609da514  sub rsp, 0xF0
00007dd8609da51b  vmovaps [rsp], xmm0
00007dd8609da520  vmovaps [rsp+0x10], xmm2
00007dd8609da526  vmovaps [rsp+0x20], xmm3
00007dd8609da52c  vmovaps [rsp+0x30], xmm4
00007dd8609da532  vmovaps [rsp+0x40], xmm5
00007dd8609da538  vmovaps [rsp+0x50], xmm6
00007dd8609da53e  vmovaps [rsp+0x60], xmm7
00007dd8609da544  vmovaps [rsp+0x70], xmm8
00007dd8609da54a  vmovaps [rsp+0x80], xmm9
00007dd8609da553  vmovaps [rsp+0x90], xmm10
00007dd8609da55c  vmovaps [rsp+0xA0], xmm11
00007dd8609da565  vmovaps [rsp+0xB0], xmm12
00007dd8609da56e  vmovaps [rsp+0xC0], xmm13
00007dd8609da577  vmovaps [rsp+0xD0], xmm14
00007dd8609da580  vmovaps [rsp+0xE0], xmm15
00007dd8609da589  sub rsp, 0x30
00007dd8609da58d  movaps [rsp], xmm1
00007dd8609da591  movaps [rsp+0x10], xmm6
00007dd8609da596  movaps [rsp+0x20], xmm15
00007dd8609da59c  lea rdi, [rsp]
00007dd8609da5a0  mov esi, 0x00
00007dd8609da5a5  mov rax, 0x629C9CFA9530
00007dd8609da5af  call rax
00007dd8609da5b1  movaps xmm1, [rsp]
00007dd8609da5b5  add rsp, 0x30
00007dd8609da5b9  vmovaps xmm0, [rsp]
00007dd8609da5be  vmovaps xmm2, [rsp+0x10]
00007dd8609da5c4  vmovaps xmm3, [rsp+0x20]
00007dd8609da5ca  vmovaps xmm4, [rsp+0x30]
00007dd8609da5d0  vmovaps xmm5, [rsp+0x40]
00007dd8609da5d6  vmovaps xmm6, [rsp+0x50]
00007dd8609da5dc  vmovaps xmm7, [rsp+0x60]
00007dd8609da5e2  vmovaps xmm8, [rsp+0x70]
00007dd8609da5e8  vmovaps xmm9, [rsp+0x80]
00007dd8609da5f1  vmovaps xmm10, [rsp+0x90]
00007dd8609da5fa  vmovaps xmm11, [rsp+0xA0]
00007dd8609da603  vmovaps xmm12, [rsp+0xB0]
00007dd8609da60c  vmovaps xmm13, [rsp+0xC0]
00007dd8609da615  vmovaps xmm14, [rsp+0xD0]
00007dd8609da61e  vmovaps xmm15, [rsp+0xE0]
00007dd8609da627  add rsp, 0xF0
00007dd8609da62e  pop r11
00007dd8609da630  pop r10
00007dd8609da632  pop r9
00007dd8609da634  pop r8
00007dd8609da636  pop rsi
00007dd8609da637  pop rdi
00007dd8609da638  pop rdx
00007dd8609da639  pop rcx
00007dd8609da63a  pop rax
00007dd8609da63b  add rsp, 0x08
00007dd8609da63f  jmp 0x00007DD8609D8E48
00007dd8609da644  call 0x00007DD8608E5820
00007dd8609da649  jmp 0x00007DD8609D8E55
00007dd8609da64e  sub rsp, 0x08
00007dd8609da652  push rax
00007dd8609da653  push rcx
00007dd8609da654  push rdx
00007dd8609da655  push rdi
00007dd8609da656  push rsi
00007dd8609da657  push r8
00007dd8609da659  push r9
00007dd8609da65b  push r10
00007dd8609da65d  push r11
00007dd8609da65f  sub rsp, 0xF0
00007dd8609da666  vmovaps [rsp], xmm0
00007dd8609da66b  vmovaps [rsp+0x10], xmm1
00007dd8609da671  vmovaps [rsp+0x20], xmm2
00007dd8609da677  vmovaps [rsp+0x30], xmm3
00007dd8609da67d  vmovaps [rsp+0x40], xmm4
00007dd8609da683  vmovaps [rsp+0x50], xmm5
00007dd8609da689  vmovaps [rsp+0x60], xmm6
00007dd8609da68f  vmovaps [rsp+0x70], xmm7
00007dd8609da695  vmovaps [rsp+0x80], xmm8
00007dd8609da69e  vmovaps [rsp+0x90], xmm9
00007dd8609da6a7  vmovaps [rsp+0xA0], xmm10
00007dd8609da6b0  vmovaps [rsp+0xB0], xmm11
00007dd8609da6b9  vmovaps [rsp+0xC0], xmm12
00007dd8609da6c2  vmovaps [rsp+0xD0], xmm13
00007dd8609da6cb  vmovaps [rsp+0xE0], xmm15
00007dd8609da6d4  sub rsp, 0x30
00007dd8609da6d8  movaps [rsp], xmm14
00007dd8609da6dd  movaps [rsp+0x10], xmm4
00007dd8609da6e2  movaps [rsp+0x20], xmm3
00007dd8609da6e7  lea rdi, [rsp]
00007dd8609da6eb  mov esi, 0x00
00007dd8609da6f0  mov rax, 0x629C9CFA9530
00007dd8609da6fa  call rax
00007dd8609da6fc  movaps xmm14, [rsp]
00007dd8609da701  add rsp, 0x30
00007dd8609da705  vmovaps xmm0, [rsp]
00007dd8609da70a  vmovaps xmm1, [rsp+0x10]
00007dd8609da710  vmovaps xmm2, [rsp+0x20]
00007dd8609da716  vmovaps xmm3, [rsp+0x30]
00007dd8609da71c  vmovaps xmm4, [rsp+0x40]
00007dd8609da722  vmovaps xmm5, [rsp+0x50]
00007dd8609da728  vmovaps xmm6, [rsp+0x60]
00007dd8609da72e  vmovaps xmm7, [rsp+0x70]
00007dd8609da734  vmovaps xmm8, [rsp+0x80]
00007dd8609da73d  vmovaps xmm9, [rsp+0x90]
00007dd8609da746  vmovaps xmm10, [rsp+0xA0]
00007dd8609da74f  vmovaps xmm11, [rsp+0xB0]
00007dd8609da758  vmovaps xmm12, [rsp+0xC0]
00007dd8609da761  vmovaps xmm13, [rsp+0xD0]
00007dd8609da76a  vmovaps xmm15, [rsp+0xE0]
00007dd8609da773  add rsp, 0xF0
00007dd8609da77a  pop r11
00007dd8609da77c  pop r10
00007dd8609da77e  pop r9
00007dd8609da780  pop r8
00007dd8609da782  pop rsi
00007dd8609da783  pop rdi
00007dd8609da784  pop rdx
00007dd8609da785  pop rcx
00007dd8609da786  pop rax
00007dd8609da787  add rsp, 0x08
00007dd8609da78b  jmp 0x00007DD8609D8E6F
00007dd8609da790  sub rsp, 0x08
00007dd8609da794  push rax
00007dd8609da795  push rcx
00007dd8609da796  push rdx
00007dd8609da797  push rdi
00007dd8609da798  push rsi
00007dd8609da799  push r8
00007dd8609da79b  push r9
00007dd8609da79d  push r10
00007dd8609da79f  push r11
00007dd8609da7a1  sub rsp, 0xF0
00007dd8609da7a8  vmovaps [rsp], xmm0
00007dd8609da7ad  vmovaps [rsp+0x10], xmm1
00007dd8609da7b3  vmovaps [rsp+0x20], xmm2
00007dd8609da7b9  vmovaps [rsp+0x30], xmm3
00007dd8609da7bf  vmovaps [rsp+0x40], xmm4
00007dd8609da7c5  vmovaps [rsp+0x50], xmm5
00007dd8609da7cb  vmovaps [rsp+0x60], xmm7
00007dd8609da7d1  vmovaps [rsp+0x70], xmm8
00007dd8609da7d7  vmovaps [rsp+0x80], xmm9
00007dd8609da7e0  vmovaps [rsp+0x90], xmm10
00007dd8609da7e9  vmovaps [rsp+0xA0], xmm11
00007dd8609da7f2  vmovaps [rsp+0xB0], xmm12
00007dd8609da7fb  vmovaps [rsp+0xC0], xmm13
00007dd8609da804  vmovaps [rsp+0xD0], xmm14
00007dd8609da80d  vmovaps [rsp+0xE0], xmm15
00007dd8609da816  sub rsp, 0x30
00007dd8609da81a  movaps [rsp], xmm6
00007dd8609da81e  movaps [rsp+0x10], xmm9
00007dd8609da824  movaps [rsp+0x20], xmm7
00007dd8609da829  lea rdi, [rsp]
00007dd8609da82d  mov esi, 0x00
00007dd8609da832  mov rax, 0x629C9CFA9530
00007dd8609da83c  call rax
00007dd8609da83e  movaps xmm6, [rsp]
00007dd8609da842  add rsp, 0x30
00007dd8609da846  vmovaps xmm0, [rsp]
00007dd8609da84b  vmovaps xmm1, [rsp+0x10]
00007dd8609da851  vmovaps xmm2, [rsp+0x20]
00007dd8609da857  vmovaps xmm3, [rsp+0x30]
00007dd8609da85d  vmovaps xmm4, [rsp+0x40]
00007dd8609da863  vmovaps xmm5, [rsp+0x50]
00007dd8609da869  vmovaps xmm7, [rsp+0x60]
00007dd8609da86f  vmovaps xmm8, [rsp+0x70]
00007dd8609da875  vmovaps xmm9, [rsp+0x80]
00007dd8609da87e  vmovaps xmm10, [rsp+0x90]
00007dd8609da887  vmovaps xmm11, [rsp+0xA0]
00007dd8609da890  vmovaps xmm12, [rsp+0xB0]
00007dd8609da899  vmovaps xmm13, [rsp+0xC0]
00007dd8609da8a2  vmovaps xmm14, [rsp+0xD0]
00007dd8609da8ab  vmovaps xmm15, [rsp+0xE0]
00007dd8609da8b4  add rsp, 0xF0
00007dd8609da8bb  pop r11
00007dd8609da8bd  pop r10
00007dd8609da8bf  pop r9
00007dd8609da8c1  pop r8
00007dd8609da8c3  pop rsi
00007dd8609da8c4  pop rdi
00007dd8609da8c5  pop rdx
00007dd8609da8c6  pop rcx
00007dd8609da8c7  pop rax
00007dd8609da8c8  add rsp, 0x08
00007dd8609da8cc  jmp 0x00007DD8609D8E87
00007dd8609da8d1  sub rsp, 0x08
00007dd8609da8d5  push rax
00007dd8609da8d6  push rcx
00007dd8609da8d7  push rdx
00007dd8609da8d8  push rdi
00007dd8609da8d9  push rsi
00007dd8609da8da  push r8
00007dd8609da8dc  push r9
00007dd8609da8de  push r10
00007dd8609da8e0  push r11
00007dd8609da8e2  sub rsp, 0xF0
00007dd8609da8e9  vmovaps [rsp], xmm0
00007dd8609da8ee  vmovaps [rsp+0x10], xmm1
00007dd8609da8f4  vmovaps [rsp+0x20], xmm2
00007dd8609da8fa  vmovaps [rsp+0x30], xmm3
00007dd8609da900  vmovaps [rsp+0x40], xmm4
00007dd8609da906  vmovaps [rsp+0x50], xmm5
00007dd8609da90c  vmovaps [rsp+0x60], xmm6
00007dd8609da912  vmovaps [rsp+0x70], xmm8
00007dd8609da918  vmovaps [rsp+0x80], xmm9
00007dd8609da921  vmovaps [rsp+0x90], xmm10
00007dd8609da92a  vmovaps [rsp+0xA0], xmm11
00007dd8609da933  vmovaps [rsp+0xB0], xmm12
00007dd8609da93c  vmovaps [rsp+0xC0], xmm13
00007dd8609da945  vmovaps [rsp+0xD0], xmm14
00007dd8609da94e  vmovaps [rsp+0xE0], xmm15
00007dd8609da957  sub rsp, 0x30
00007dd8609da95b  movaps [rsp], xmm7
00007dd8609da95f  movaps [rsp+0x10], xmm4
00007dd8609da964  movaps [rsp+0x20], xmm9
00007dd8609da96a  lea rdi, [rsp]
00007dd8609da96e  mov esi, 0x00
00007dd8609da973  mov rax, 0x629C9CFA9530
00007dd8609da97d  call rax
00007dd8609da97f  movaps xmm7, [rsp]
00007dd8609da983  add rsp, 0x30
00007dd8609da987  vmovaps xmm0, [rsp]
00007dd8609da98c  vmovaps xmm1, [rsp+0x10]
00007dd8609da992  vmovaps xmm2, [rsp+0x20]
00007dd8609da998  vmovaps xmm3, [rsp+0x30]
00007dd8609da99e  vmovaps xmm4, [rsp+0x40]
00007dd8609da9a4  vmovaps xmm5, [rsp+0x50]
00007dd8609da9aa  vmovaps xmm6, [rsp+0x60]
00007dd8609da9b0  vmovaps xmm8, [rsp+0x70]
00007dd8609da9b6  vmovaps xmm9, [rsp+0x80]
00007dd8609da9bf  vmovaps xmm10, [rsp+0x90]
00007dd8609da9c8  vmovaps xmm11, [rsp+0xA0]
00007dd8609da9d1  vmovaps xmm12, [rsp+0xB0]
00007dd8609da9da  vmovaps xmm13, [rsp+0xC0]
00007dd8609da9e3  vmovaps xmm14, [rsp+0xD0]
00007dd8609da9ec  vmovaps xmm15, [rsp+0xE0]
00007dd8609da9f5  add rsp, 0xF0
00007dd8609da9fc  pop r11
00007dd8609da9fe  pop r10
00007dd8609daa00  pop r9
00007dd8609daa02  pop r8
00007dd8609daa04  pop rsi
00007dd8609daa05  pop rdi
00007dd8609daa06  pop rdx
00007dd8609daa07  pop rcx
00007dd8609daa08  pop rax
00007dd8609daa09  add rsp, 0x08
00007dd8609daa0d  jmp 0x00007DD8609D8EB4
00007dd8609daa12  sub rsp, 0x08
00007dd8609daa16  push rax
00007dd8609daa17  push rcx
00007dd8609daa18  push rdx
00007dd8609daa19  push rdi
00007dd8609daa1a  push rsi
00007dd8609daa1b  push r8
00007dd8609daa1d  push r9
00007dd8609daa1f  push r10
00007dd8609daa21  push r11
00007dd8609daa23  sub rsp, 0xF0
00007dd8609daa2a  vmovaps [rsp], xmm0
00007dd8609daa2f  vmovaps [rsp+0x10], xmm1
00007dd8609daa35  vmovaps [rsp+0x20], xmm2
00007dd8609daa3b  vmovaps [rsp+0x30], xmm3
00007dd8609daa41  vmovaps [rsp+0x40], xmm5
00007dd8609daa47  vmovaps [rsp+0x50], xmm6
00007dd8609daa4d  vmovaps [rsp+0x60], xmm7
00007dd8609daa53  vmovaps [rsp+0x70], xmm8
00007dd8609daa59  vmovaps [rsp+0x80], xmm9
00007dd8609daa62  vmovaps [rsp+0x90], xmm10
00007dd8609daa6b  vmovaps [rsp+0xA0], xmm11
00007dd8609daa74  vmovaps [rsp+0xB0], xmm12
00007dd8609daa7d  vmovaps [rsp+0xC0], xmm13
00007dd8609daa86  vmovaps [rsp+0xD0], xmm14
00007dd8609daa8f  vmovaps [rsp+0xE0], xmm15
00007dd8609daa98  sub rsp, 0x30
00007dd8609daa9c  movaps [rsp], xmm4
00007dd8609daaa0  movaps [rsp+0x10], xmm15
00007dd8609daaa6  movaps [rsp+0x20], xmm9
00007dd8609daaac  lea rdi, [rsp]
00007dd8609daab0  mov esi, 0x00
00007dd8609daab5  mov rax, 0x629C9CFA9530
00007dd8609daabf  call rax
00007dd8609daac1  movaps xmm4, [rsp]
00007dd8609daac5  add rsp, 0x30
00007dd8609daac9  vmovaps xmm0, [rsp]
00007dd8609daace  vmovaps xmm1, [rsp+0x10]
00007dd8609daad4  vmovaps xmm2, [rsp+0x20]
00007dd8609daada  vmovaps xmm3, [rsp+0x30]
00007dd8609daae0  vmovaps xmm5, [rsp+0x40]
00007dd8609daae6  vmovaps xmm6, [rsp+0x50]
00007dd8609daaec  vmovaps xmm7, [rsp+0x60]
00007dd8609daaf2  vmovaps xmm8, [rsp+0x70]
00007dd8609daaf8  vmovaps xmm9, [rsp+0x80]
00007dd8609dab01  vmovaps xmm10, [rsp+0x90]
00007dd8609dab0a  vmovaps xmm11, [rsp+0xA0]
00007dd8609dab13  vmovaps xmm12, [rsp+0xB0]
00007dd8609dab1c  vmovaps xmm13, [rsp+0xC0]
00007dd8609dab25  vmovaps xmm14, [rsp+0xD0]
00007dd8609dab2e  vmovaps xmm15, [rsp+0xE0]
00007dd8609dab37  add rsp, 0xF0
00007dd8609dab3e  pop r11
00007dd8609dab40  pop r10
00007dd8609dab42  pop r9
00007dd8609dab44  pop r8
00007dd8609dab46  pop rsi
00007dd8609dab47  pop rdi
00007dd8609dab48  pop rdx
00007dd8609dab49  pop rcx
00007dd8609dab4a  pop rax
00007dd8609dab4b  add rsp, 0x08
00007dd8609dab4f  jmp 0x00007DD8609D8ED9
00007dd8609dab54  call 0x00007DD8608E5820
00007dd8609dab59  jmp 0x00007DD8609D8EE6
00007dd8609dab5e  sub rsp, 0x08
00007dd8609dab62  push rax
00007dd8609dab63  push rcx
00007dd8609dab64  push rdx
00007dd8609dab65  push rdi
00007dd8609dab66  push rsi
00007dd8609dab67  push r8
00007dd8609dab69  push r9
00007dd8609dab6b  push r10
00007dd8609dab6d  push r11
00007dd8609dab6f  sub rsp, 0xF0
00007dd8609dab76  vmovaps [rsp], xmm0
00007dd8609dab7b  vmovaps [rsp+0x10], xmm1
00007dd8609dab81  vmovaps [rsp+0x20], xmm2
00007dd8609dab87  vmovaps [rsp+0x30], xmm4
00007dd8609dab8d  vmovaps [rsp+0x40], xmm5
00007dd8609dab93  vmovaps [rsp+0x50], xmm6
00007dd8609dab99  vmovaps [rsp+0x60], xmm7
00007dd8609dab9f  vmovaps [rsp+0x70], xmm8
00007dd8609daba5  vmovaps [rsp+0x80], xmm9
00007dd8609dabae  vmovaps [rsp+0x90], xmm10
00007dd8609dabb7  vmovaps [rsp+0xA0], xmm11
00007dd8609dabc0  vmovaps [rsp+0xB0], xmm12
00007dd8609dabc9  vmovaps [rsp+0xC0], xmm13
00007dd8609dabd2  vmovaps [rsp+0xD0], xmm14
00007dd8609dabdb  vmovaps [rsp+0xE0], xmm15
00007dd8609dabe4  sub rsp, 0x30
00007dd8609dabe8  movaps [rsp], xmm3
00007dd8609dabec  movaps [rsp+0x10], xmm1
00007dd8609dabf1  movaps [rsp+0x20], xmm9
00007dd8609dabf7  lea rdi, [rsp]
00007dd8609dabfb  mov esi, 0x00
00007dd8609dac00  mov rax, 0x629C9CFA9530
00007dd8609dac0a  call rax
00007dd8609dac0c  movaps xmm3, [rsp]
00007dd8609dac10  add rsp, 0x30
00007dd8609dac14  vmovaps xmm0, [rsp]
00007dd8609dac19  vmovaps xmm1, [rsp+0x10]
00007dd8609dac1f  vmovaps xmm2, [rsp+0x20]
00007dd8609dac25  vmovaps xmm4, [rsp+0x30]
00007dd8609dac2b  vmovaps xmm5, [rsp+0x40]
00007dd8609dac31  vmovaps xmm6, [rsp+0x50]
00007dd8609dac37  vmovaps xmm7, [rsp+0x60]
00007dd8609dac3d  vmovaps xmm8, [rsp+0x70]
00007dd8609dac43  vmovaps xmm9, [rsp+0x80]
00007dd8609dac4c  vmovaps xmm10, [rsp+0x90]
00007dd8609dac55  vmovaps xmm11, [rsp+0xA0]
00007dd8609dac5e  vmovaps xmm12, [rsp+0xB0]
00007dd8609dac67  vmovaps xmm13, [rsp+0xC0]
00007dd8609dac70  vmovaps xmm14, [rsp+0xD0]
00007dd8609dac79  vmovaps xmm15, [rsp+0xE0]
00007dd8609dac82  add rsp, 0xF0
00007dd8609dac89  pop r11
00007dd8609dac8b  pop r10
00007dd8609dac8d  pop r9
00007dd8609dac8f  pop r8
00007dd8609dac91  pop rsi
00007dd8609dac92  pop rdi
00007dd8609dac93  pop rdx
00007dd8609dac94  pop rcx
00007dd8609dac95  pop rax
00007dd8609dac96  add rsp, 0x08
00007dd8609dac9a  jmp 0x00007DD8609D8F23
00007dd8609dac9f  sub rsp, 0x08
00007dd8609daca3  push rax
00007dd8609daca4  push rcx
00007dd8609daca5  push rdx
00007dd8609daca6  push rdi
00007dd8609daca7  push rsi
00007dd8609daca8  push r8
00007dd8609dacaa  push r9
00007dd8609dacac  push r10
00007dd8609dacae  push r11
00007dd8609dacb0  sub rsp, 0xF0
00007dd8609dacb7  vmovaps [rsp], xmm0
00007dd8609dacbc  vmovaps [rsp+0x10], xmm2
00007dd8609dacc2  vmovaps [rsp+0x20], xmm3
00007dd8609dacc8  vmovaps [rsp+0x30], xmm4
00007dd8609dacce  vmovaps [rsp+0x40], xmm5
00007dd8609dacd4  vmovaps [rsp+0x50], xmm6
00007dd8609dacda  vmovaps [rsp+0x60], xmm7
00007dd8609dace0  vmovaps [rsp+0x70], xmm8
00007dd8609dace6  vmovaps [rsp+0x80], xmm9
00007dd8609dacef  vmovaps [rsp+0x90], xmm10
00007dd8609dacf8  vmovaps [rsp+0xA0], xmm11
00007dd8609dad01  vmovaps [rsp+0xB0], xmm12
00007dd8609dad0a  vmovaps [rsp+0xC0], xmm13
00007dd8609dad13  vmovaps [rsp+0xD0], xmm14
00007dd8609dad1c  vmovaps [rsp+0xE0], xmm15
00007dd8609dad25  sub rsp, 0x30
00007dd8609dad29  movaps [rsp], xmm1
00007dd8609dad2d  movaps [rsp+0x10], xmm15
00007dd8609dad33  movaps [rsp+0x20], xmm9
00007dd8609dad39  lea rdi, [rsp]
00007dd8609dad3d  mov esi, 0x00
00007dd8609dad42  mov rax, 0x629C9CFA9530
00007dd8609dad4c  call rax
00007dd8609dad4e  movaps xmm1, [rsp]
00007dd8609dad52  add rsp, 0x30
00007dd8609dad56  vmovaps xmm0, [rsp]
00007dd8609dad5b  vmovaps xmm2, [rsp+0x10]
00007dd8609dad61  vmovaps xmm3, [rsp+0x20]
00007dd8609dad67  vmovaps xmm4, [rsp+0x30]
00007dd8609dad6d  vmovaps xmm5, [rsp+0x40]
00007dd8609dad73  vmovaps xmm6, [rsp+0x50]
00007dd8609dad79  vmovaps xmm7, [rsp+0x60]
00007dd8609dad7f  vmovaps xmm8, [rsp+0x70]
00007dd8609dad85  vmovaps xmm9, [rsp+0x80]
00007dd8609dad8e  vmovaps xmm10, [rsp+0x90]
00007dd8609dad97  vmovaps xmm11, [rsp+0xA0]
00007dd8609dada0  vmovaps xmm12, [rsp+0xB0]
00007dd8609dada9  vmovaps xmm13, [rsp+0xC0]
00007dd8609dadb2  vmovaps xmm14, [rsp+0xD0]
00007dd8609dadbb  vmovaps xmm15, [rsp+0xE0]
00007dd8609dadc4  add rsp, 0xF0
00007dd8609dadcb  pop r11
00007dd8609dadcd  pop r10
00007dd8609dadcf  pop r9
00007dd8609dadd1  pop r8
00007dd8609dadd3  pop rsi
00007dd8609dadd4  pop rdi
00007dd8609dadd5  pop rdx
00007dd8609dadd6  pop rcx
00007dd8609dadd7  pop rax
00007dd8609dadd8  add rsp, 0x08
00007dd8609daddc  jmp 0x00007DD8609D8FAB
00007dd8609dade1  call 0x00007DD8608E5820
00007dd8609dade6  jmp 0x00007DD8609D8FB8
00007dd8609dadeb  sub rsp, 0x08
00007dd8609dadef  push rax
00007dd8609dadf0  push rcx
00007dd8609dadf1  push rdx
00007dd8609dadf2  push rdi
00007dd8609dadf3  push rsi
00007dd8609dadf4  push r8
00007dd8609dadf6  push r9
00007dd8609dadf8  push r10
00007dd8609dadfa  push r11
00007dd8609dadfc  sub rsp, 0xF0
00007dd8609dae03  vmovaps [rsp], xmm0
00007dd8609dae08  vmovaps [rsp+0x10], xmm2
00007dd8609dae0e  vmovaps [rsp+0x20], xmm3
00007dd8609dae14  vmovaps [rsp+0x30], xmm4
00007dd8609dae1a  vmovaps [rsp+0x40], xmm5
00007dd8609dae20  vmovaps [rsp+0x50], xmm6
00007dd8609dae26  vmovaps [rsp+0x60], xmm7
00007dd8609dae2c  vmovaps [rsp+0x70], xmm8
00007dd8609dae32  vmovaps [rsp+0x80], xmm9
00007dd8609dae3b  vmovaps [rsp+0x90], xmm10
00007dd8609dae44  vmovaps [rsp+0xA0], xmm11
00007dd8609dae4d  vmovaps [rsp+0xB0], xmm12
00007dd8609dae56  vmovaps [rsp+0xC0], xmm13
00007dd8609dae5f  vmovaps [rsp+0xD0], xmm14
00007dd8609dae68  vmovaps [rsp+0xE0], xmm15
00007dd8609dae71  sub rsp, 0x30
00007dd8609dae75  movaps [rsp], xmm1
00007dd8609dae79  movaps [rsp+0x10], xmm5
00007dd8609dae7e  movaps [rsp+0x20], xmm7
00007dd8609dae83  lea rdi, [rsp]
00007dd8609dae87  mov esi, 0x00
00007dd8609dae8c  mov rax, 0x629C9CFA9530
00007dd8609dae96  call rax
00007dd8609dae98  movaps xmm1, [rsp]
00007dd8609dae9c  add rsp, 0x30
00007dd8609daea0  vmovaps xmm0, [rsp]
00007dd8609daea5  vmovaps xmm2, [rsp+0x10]
00007dd8609daeab  vmovaps xmm3, [rsp+0x20]
00007dd8609daeb1  vmovaps xmm4, [rsp+0x30]
00007dd8609daeb7  vmovaps xmm5, [rsp+0x40]
00007dd8609daebd  vmovaps xmm6, [rsp+0x50]
00007dd8609daec3  vmovaps xmm7, [rsp+0x60]
00007dd8609daec9  vmovaps xmm8, [rsp+0x70]
00007dd8609daecf  vmovaps xmm9, [rsp+0x80]
00007dd8609daed8  vmovaps xmm10, [rsp+0x90]
00007dd8609daee1  vmovaps xmm11, [rsp+0xA0]
00007dd8609daeea  vmovaps xmm12, [rsp+0xB0]
00007dd8609daef3  vmovaps xmm13, [rsp+0xC0]
00007dd8609daefc  vmovaps xmm14, [rsp+0xD0]
00007dd8609daf05  vmovaps xmm15, [rsp+0xE0]
00007dd8609daf0e  add rsp, 0xF0
00007dd8609daf15  pop r11
00007dd8609daf17  pop r10
00007dd8609daf19  pop r9
00007dd8609daf1b  pop r8
00007dd8609daf1d  pop rsi
00007dd8609daf1e  pop rdi
00007dd8609daf1f  pop rdx
00007dd8609daf20  pop rcx
00007dd8609daf21  pop rax
00007dd8609daf22  add rsp, 0x08
00007dd8609daf26  jmp 0x00007DD8609D905D
00007dd8609daf2b  sub rsp, 0x08
00007dd8609daf2f  push rax
00007dd8609daf30  push rcx
00007dd8609daf31  push rdx
00007dd8609daf32  push rdi
00007dd8609daf33  push rsi
00007dd8609daf34  push r8
00007dd8609daf36  push r9
00007dd8609daf38  push r10
00007dd8609daf3a  push r11
00007dd8609daf3c  sub rsp, 0xF0
00007dd8609daf43  vmovaps [rsp], xmm0
00007dd8609daf48  vmovaps [rsp+0x10], xmm1
00007dd8609daf4e  vmovaps [rsp+0x20], xmm2
00007dd8609daf54  vmovaps [rsp+0x30], xmm3
00007dd8609daf5a  vmovaps [rsp+0x40], xmm4
00007dd8609daf60  vmovaps [rsp+0x50], xmm5
00007dd8609daf66  vmovaps [rsp+0x60], xmm6
00007dd8609daf6c  vmovaps [rsp+0x70], xmm8
00007dd8609daf72  vmovaps [rsp+0x80], xmm9
00007dd8609daf7b  vmovaps [rsp+0x90], xmm10
00007dd8609daf84  vmovaps [rsp+0xA0], xmm11
00007dd8609daf8d  vmovaps [rsp+0xB0], xmm12
00007dd8609daf96  vmovaps [rsp+0xC0], xmm13
00007dd8609daf9f  vmovaps [rsp+0xD0], xmm14
00007dd8609dafa8  vmovaps [rsp+0xE0], xmm15
00007dd8609dafb1  sub rsp, 0x30
00007dd8609dafb5  movaps [rsp], xmm7
00007dd8609dafb9  movaps [rsp+0x10], xmm5
00007dd8609dafbe  movaps [rsp+0x20], xmm15
00007dd8609dafc4  lea rdi, [rsp]
00007dd8609dafc8  mov esi, 0x00
00007dd8609dafcd  mov rax, 0x629C9CFA9530
00007dd8609dafd7  call rax
00007dd8609dafd9  movaps xmm7, [rsp]
00007dd8609dafdd  add rsp, 0x30
00007dd8609dafe1  vmovaps xmm0, [rsp]
00007dd8609dafe6  vmovaps xmm1, [rsp+0x10]
00007dd8609dafec  vmovaps xmm2, [rsp+0x20]
00007dd8609daff2  vmovaps xmm3, [rsp+0x30]
00007dd8609daff8  vmovaps xmm4, [rsp+0x40]
00007dd8609daffe  vmovaps xmm5, [rsp+0x50]
00007dd8609db004  vmovaps xmm6, [rsp+0x60]
00007dd8609db00a  vmovaps xmm8, [rsp+0x70]
00007dd8609db010  vmovaps xmm9, [rsp+0x80]
00007dd8609db019  vmovaps xmm10, [rsp+0x90]
00007dd8609db022  vmovaps xmm11, [rsp+0xA0]
00007dd8609db02b  vmovaps xmm12, [rsp+0xB0]
00007dd8609db034  vmovaps xmm13, [rsp+0xC0]
00007dd8609db03d  vmovaps xmm14, [rsp+0xD0]
00007dd8609db046  vmovaps xmm15, [rsp+0xE0]
00007dd8609db04f  add rsp, 0xF0
00007dd8609db056  pop r11
00007dd8609db058  pop r10
00007dd8609db05a  pop r9
00007dd8609db05c  pop r8
00007dd8609db05e  pop rsi
00007dd8609db05f  pop rdi
00007dd8609db060  pop rdx
00007dd8609db061  pop rcx
00007dd8609db062  pop rax
00007dd8609db063  add rsp, 0x08
00007dd8609db067  jmp 0x00007DD8609D9093
00007dd8609db06c  call 0x00007DD8608D64F0
00007dd8609db071  jmp 0x00007DD8609D90A0
00007dd8609db076  sub rsp, 0x08
00007dd8609db07a  push rax
00007dd8609db07b  push rcx
00007dd8609db07c  push rdx
00007dd8609db07d  push rdi
00007dd8609db07e  push rsi
00007dd8609db07f  push r8
00007dd8609db081  push r9
00007dd8609db083  push r10
00007dd8609db085  push r11
00007dd8609db087  sub rsp, 0xF0
00007dd8609db08e  vmovaps [rsp], xmm0
00007dd8609db093  vmovaps [rsp+0x10], xmm1
00007dd8609db099  vmovaps [rsp+0x20], xmm2
00007dd8609db09f  vmovaps [rsp+0x30], xmm3
00007dd8609db0a5  vmovaps [rsp+0x40], xmm4
00007dd8609db0ab  vmovaps [rsp+0x50], xmm5
00007dd8609db0b1  vmovaps [rsp+0x60], xmm6
00007dd8609db0b7  vmovaps [rsp+0x70], xmm7
00007dd8609db0bd  vmovaps [rsp+0x80], xmm8
00007dd8609db0c6  vmovaps [rsp+0x90], xmm9
00007dd8609db0cf  vmovaps [rsp+0xA0], xmm10
00007dd8609db0d8  vmovaps [rsp+0xB0], xmm11
00007dd8609db0e1  vmovaps [rsp+0xC0], xmm12
00007dd8609db0ea  vmovaps [rsp+0xD0], xmm13
00007dd8609db0f3  vmovaps [rsp+0xE0], xmm14
00007dd8609db0fc  sub rsp, 0x30
00007dd8609db100  movaps [rsp], xmm15
00007dd8609db105  movaps [rsp+0x10], xmm5
00007dd8609db10a  movaps [rsp+0x20], xmm3
00007dd8609db10f  lea rdi, [rsp]
00007dd8609db113  mov esi, 0x00
00007dd8609db118  mov rax, 0x629C9CFA9530
00007dd8609db122  call rax
00007dd8609db124  movaps xmm15, [rsp]
00007dd8609db129  add rsp, 0x30
00007dd8609db12d  vmovaps xmm0, [rsp]
00007dd8609db132  vmovaps xmm1, [rsp+0x10]
00007dd8609db138  vmovaps xmm2, [rsp+0x20]
00007dd8609db13e  vmovaps xmm3, [rsp+0x30]
00007dd8609db144  vmovaps xmm4, [rsp+0x40]
00007dd8609db14a  vmovaps xmm5, [rsp+0x50]
00007dd8609db150  vmovaps xmm6, [rsp+0x60]
00007dd8609db156  vmovaps xmm7, [rsp+0x70]
00007dd8609db15c  vmovaps xmm8, [rsp+0x80]
00007dd8609db165  vmovaps xmm9, [rsp+0x90]
00007dd8609db16e  vmovaps xmm10, [rsp+0xA0]
00007dd8609db177  vmovaps xmm11, [rsp+0xB0]
00007dd8609db180  vmovaps xmm12, [rsp+0xC0]
00007dd8609db189  vmovaps xmm13, [rsp+0xD0]
00007dd8609db192  vmovaps xmm14, [rsp+0xE0]
00007dd8609db19b  add rsp, 0xF0
00007dd8609db1a2  pop r11
00007dd8609db1a4  pop r10
00007dd8609db1a6  pop r9
00007dd8609db1a8  pop r8
00007dd8609db1aa  pop rsi
00007dd8609db1ab  pop rdi
00007dd8609db1ac  pop rdx
00007dd8609db1ad  pop rcx
00007dd8609db1ae  pop rax
00007dd8609db1af  add rsp, 0x08
00007dd8609db1b3  jmp 0x00007DD8609D90C6
00007dd8609db1b8  sub rsp, 0x08
00007dd8609db1bc  push rax
00007dd8609db1bd  push rcx
00007dd8609db1be  push rdx
00007dd8609db1bf  push rdi
00007dd8609db1c0  push rsi
00007dd8609db1c1  push r8
00007dd8609db1c3  push r9
00007dd8609db1c5  push r10
00007dd8609db1c7  push r11
00007dd8609db1c9  sub rsp, 0xF0
00007dd8609db1d0  vmovaps [rsp], xmm0
00007dd8609db1d5  vmovaps [rsp+0x10], xmm2
00007dd8609db1db  vmovaps [rsp+0x20], xmm3
00007dd8609db1e1  vmovaps [rsp+0x30], xmm4
00007dd8609db1e7  vmovaps [rsp+0x40], xmm5
00007dd8609db1ed  vmovaps [rsp+0x50], xmm6
00007dd8609db1f3  vmovaps [rsp+0x60], xmm7
00007dd8609db1f9  vmovaps [rsp+0x70], xmm8
00007dd8609db1ff  vmovaps [rsp+0x80], xmm9
00007dd8609db208  vmovaps [rsp+0x90], xmm10
00007dd8609db211  vmovaps [rsp+0xA0], xmm11
00007dd8609db21a  vmovaps [rsp+0xB0], xmm12
00007dd8609db223  vmovaps [rsp+0xC0], xmm13
00007dd8609db22c  vmovaps [rsp+0xD0], xmm14
00007dd8609db235  vmovaps [rsp+0xE0], xmm15
00007dd8609db23e  sub rsp, 0x30
00007dd8609db242  movaps [rsp], xmm1
00007dd8609db246  movaps [rsp+0x10], xmm5
00007dd8609db24b  movaps [rsp+0x20], xmm4
00007dd8609db250  lea rdi, [rsp]
00007dd8609db254  mov esi, 0x00
00007dd8609db259  mov rax, 0x629C9CFA9530
00007dd8609db263  call rax
00007dd8609db265  movaps xmm1, [rsp]
00007dd8609db269  add rsp, 0x30
00007dd8609db26d  vmovaps xmm0, [rsp]
00007dd8609db272  vmovaps xmm2, [rsp+0x10]
00007dd8609db278  vmovaps xmm3, [rsp+0x20]
00007dd8609db27e  vmovaps xmm4, [rsp+0x30]
00007dd8609db284  vmovaps xmm5, [rsp+0x40]
00007dd8609db28a  vmovaps xmm6, [rsp+0x50]
00007dd8609db290  vmovaps xmm7, [rsp+0x60]
00007dd8609db296  vmovaps xmm8, [rsp+0x70]
00007dd8609db29c  vmovaps xmm9, [rsp+0x80]
00007dd8609db2a5  vmovaps xmm10, [rsp+0x90]
00007dd8609db2ae  vmovaps xmm11, [rsp+0xA0]
00007dd8609db2b7  vmovaps xmm12, [rsp+0xB0]
00007dd8609db2c0  vmovaps xmm13, [rsp+0xC0]
00007dd8609db2c9  vmovaps xmm14, [rsp+0xD0]
00007dd8609db2d2  vmovaps xmm15, [rsp+0xE0]
00007dd8609db2db  add rsp, 0xF0
00007dd8609db2e2  pop r11
00007dd8609db2e4  pop r10
00007dd8609db2e6  pop r9
00007dd8609db2e8  pop r8
00007dd8609db2ea  pop rsi
00007dd8609db2eb  pop rdi
00007dd8609db2ec  pop rdx
00007dd8609db2ed  pop rcx
00007dd8609db2ee  pop rax
00007dd8609db2ef  add rsp, 0x08
00007dd8609db2f3  jmp 0x00007DD8609D90E6
00007dd8609db2f8  sub rsp, 0x08
00007dd8609db2fc  push rax
00007dd8609db2fd  push rcx
00007dd8609db2fe  push rdx
00007dd8609db2ff  push rdi
00007dd8609db300  push rsi
00007dd8609db301  push r8
00007dd8609db303  push r9
00007dd8609db305  push r10
00007dd8609db307  push r11
00007dd8609db309  sub rsp, 0xF0
00007dd8609db310  vmovaps [rsp], xmm0
00007dd8609db315  vmovaps [rsp+0x10], xmm1
00007dd8609db31b  vmovaps [rsp+0x20], xmm2
00007dd8609db321  vmovaps [rsp+0x30], xmm3
00007dd8609db327  vmovaps [rsp+0x40], xmm5
00007dd8609db32d  vmovaps [rsp+0x50], xmm6
00007dd8609db333  vmovaps [rsp+0x60], xmm7
00007dd8609db339  vmovaps [rsp+0x70], xmm8
00007dd8609db33f  vmovaps [rsp+0x80], xmm9
00007dd8609db348  vmovaps [rsp+0x90], xmm10
00007dd8609db351  vmovaps [rsp+0xA0], xmm11
00007dd8609db35a  vmovaps [rsp+0xB0], xmm12
00007dd8609db363  vmovaps [rsp+0xC0], xmm13
00007dd8609db36c  vmovaps [rsp+0xD0], xmm14
00007dd8609db375  vmovaps [rsp+0xE0], xmm15
00007dd8609db37e  sub rsp, 0x30
00007dd8609db382  movaps [rsp], xmm4
00007dd8609db386  movaps [rsp+0x10], xmm3
00007dd8609db38b  movaps [rsp+0x20], xmm5
00007dd8609db390  lea rdi, [rsp]
00007dd8609db394  mov esi, 0x00
00007dd8609db399  mov rax, 0x629C9CFA9530
00007dd8609db3a3  call rax
00007dd8609db3a5  movaps xmm4, [rsp]
00007dd8609db3a9  add rsp, 0x30
00007dd8609db3ad  vmovaps xmm0, [rsp]
00007dd8609db3b2  vmovaps xmm1, [rsp+0x10]
00007dd8609db3b8  vmovaps xmm2, [rsp+0x20]
00007dd8609db3be  vmovaps xmm3, [rsp+0x30]
00007dd8609db3c4  vmovaps xmm5, [rsp+0x40]
00007dd8609db3ca  vmovaps xmm6, [rsp+0x50]
00007dd8609db3d0  vmovaps xmm7, [rsp+0x60]
00007dd8609db3d6  vmovaps xmm8, [rsp+0x70]
00007dd8609db3dc  vmovaps xmm9, [rsp+0x80]
00007dd8609db3e5  vmovaps xmm10, [rsp+0x90]
00007dd8609db3ee  vmovaps xmm11, [rsp+0xA0]
00007dd8609db3f7  vmovaps xmm12, [rsp+0xB0]
00007dd8609db400  vmovaps xmm13, [rsp+0xC0]
00007dd8609db409  vmovaps xmm14, [rsp+0xD0]
00007dd8609db412  vmovaps xmm15, [rsp+0xE0]
00007dd8609db41b  add rsp, 0xF0
00007dd8609db422  pop r11
00007dd8609db424  pop r10
00007dd8609db426  pop r9
00007dd8609db428  pop r8
00007dd8609db42a  pop rsi
00007dd8609db42b  pop rdi
00007dd8609db42c  pop rdx
00007dd8609db42d  pop rcx
00007dd8609db42e  pop rax
00007dd8609db42f  add rsp, 0x08
00007dd8609db433  jmp 0x00007DD8609D9134
00007dd8609db438  call 0x00007DD8608D64F0
00007dd8609db43d  jmp 0x00007DD8609D9141
00007dd8609db442  sub rsp, 0x08
00007dd8609db446  push rax
00007dd8609db447  push rcx
00007dd8609db448  push rdx
00007dd8609db449  push rdi
00007dd8609db44a  push rsi
00007dd8609db44b  push r8
00007dd8609db44d  push r9
00007dd8609db44f  push r10
00007dd8609db451  push r11
00007dd8609db453  sub rsp, 0xF0
00007dd8609db45a  vmovaps [rsp], xmm0
00007dd8609db45f  vmovaps [rsp+0x10], xmm1
00007dd8609db465  vmovaps [rsp+0x20], xmm2
00007dd8609db46b  vmovaps [rsp+0x30], xmm3
00007dd8609db471  vmovaps [rsp+0x40], xmm4
00007dd8609db477  vmovaps [rsp+0x50], xmm6
00007dd8609db47d  vmovaps [rsp+0x60], xmm7
00007dd8609db483  vmovaps [rsp+0x70], xmm8
00007dd8609db489  vmovaps [rsp+0x80], xmm9
00007dd8609db492  vmovaps [rsp+0x90], xmm10
00007dd8609db49b  vmovaps [rsp+0xA0], xmm11
00007dd8609db4a4  vmovaps [rsp+0xB0], xmm12
00007dd8609db4ad  vmovaps [rsp+0xC0], xmm13
00007dd8609db4b6  vmovaps [rsp+0xD0], xmm14
00007dd8609db4bf  vmovaps [rsp+0xE0], xmm15
00007dd8609db4c8  sub rsp, 0x30
00007dd8609db4cc  movaps [rsp], xmm5
00007dd8609db4d0  movaps [rsp+0x10], xmm6
00007dd8609db4d5  movaps [rsp+0x20], xmm3
00007dd8609db4da  lea rdi, [rsp]
00007dd8609db4de  mov esi, 0x00
00007dd8609db4e3  mov rax, 0x629C9CFA9530
00007dd8609db4ed  call rax
00007dd8609db4ef  movaps xmm5, [rsp]
00007dd8609db4f3  add rsp, 0x30
00007dd8609db4f7  vmovaps xmm0, [rsp]
00007dd8609db4fc  vmovaps xmm1, [rsp+0x10]
00007dd8609db502  vmovaps xmm2, [rsp+0x20]
00007dd8609db508  vmovaps xmm3, [rsp+0x30]
00007dd8609db50e  vmovaps xmm4, [rsp+0x40]
00007dd8609db514  vmovaps xmm6, [rsp+0x50]
00007dd8609db51a  vmovaps xmm7, [rsp+0x60]
00007dd8609db520  vmovaps xmm8, [rsp+0x70]
00007dd8609db526  vmovaps xmm9, [rsp+0x80]
00007dd8609db52f  vmovaps xmm10, [rsp+0x90]
00007dd8609db538  vmovaps xmm11, [rsp+0xA0]
00007dd8609db541  vmovaps xmm12, [rsp+0xB0]
00007dd8609db54a  vmovaps xmm13, [rsp+0xC0]
00007dd8609db553  vmovaps xmm14, [rsp+0xD0]
00007dd8609db55c  vmovaps xmm15, [rsp+0xE0]
00007dd8609db565  add rsp, 0xF0
00007dd8609db56c  pop r11
00007dd8609db56e  pop r10
00007dd8609db570  pop r9
00007dd8609db572  pop r8
00007dd8609db574  pop rsi
00007dd8609db575  pop rdi
00007dd8609db576  pop rdx
00007dd8609db577  pop rcx
00007dd8609db578  pop rax
00007dd8609db579  add rsp, 0x08
00007dd8609db57d  jmp 0x00007DD8609D9167
00007dd8609db582  sub rsp, 0x08
00007dd8609db586  push rax
00007dd8609db587  push rcx
00007dd8609db588  push rdx
00007dd8609db589  push rdi
00007dd8609db58a  push rsi
00007dd8609db58b  push r8
00007dd8609db58d  push r9
00007dd8609db58f  push r10
00007dd8609db591  push r11
00007dd8609db593  sub rsp, 0xF0
00007dd8609db59a  vmovaps [rsp], xmm0
00007dd8609db59f  vmovaps [rsp+0x10], xmm1
00007dd8609db5a5  vmovaps [rsp+0x20], xmm2
00007dd8609db5ab  vmovaps [rsp+0x30], xmm3
00007dd8609db5b1  vmovaps [rsp+0x40], xmm4
00007dd8609db5b7  vmovaps [rsp+0x50], xmm5
00007dd8609db5bd  vmovaps [rsp+0x60], xmm7
00007dd8609db5c3  vmovaps [rsp+0x70], xmm8
00007dd8609db5c9  vmovaps [rsp+0x80], xmm9
00007dd8609db5d2  vmovaps [rsp+0x90], xmm10
00007dd8609db5db  vmovaps [rsp+0xA0], xmm11
00007dd8609db5e4  vmovaps [rsp+0xB0], xmm12
00007dd8609db5ed  vmovaps [rsp+0xC0], xmm13
00007dd8609db5f6  vmovaps [rsp+0xD0], xmm14
00007dd8609db5ff  vmovaps [rsp+0xE0], xmm15
00007dd8609db608  sub rsp, 0x30
00007dd8609db60c  movaps [rsp], xmm6
00007dd8609db610  movaps [rsp+0x10], xmm9
00007dd8609db616  movaps [rsp+0x20], xmm1
00007dd8609db61b  lea rdi, [rsp]
00007dd8609db61f  mov esi, 0x00
00007dd8609db624  mov rax, 0x629C9CFA9530
00007dd8609db62e  call rax
00007dd8609db630  movaps xmm6, [rsp]
00007dd8609db634  add rsp, 0x30
00007dd8609db638  vmovaps xmm0, [rsp]
00007dd8609db63d  vmovaps xmm1, [rsp+0x10]
00007dd8609db643  vmovaps xmm2, [rsp+0x20]
00007dd8609db649  vmovaps xmm3, [rsp+0x30]
00007dd8609db64f  vmovaps xmm4, [rsp+0x40]
00007dd8609db655  vmovaps xmm5, [rsp+0x50]
00007dd8609db65b  vmovaps xmm7, [rsp+0x60]
00007dd8609db661  vmovaps xmm8, [rsp+0x70]
00007dd8609db667  vmovaps xmm9, [rsp+0x80]
00007dd8609db670  vmovaps xmm10, [rsp+0x90]
00007dd8609db679  vmovaps xmm11, [rsp+0xA0]
00007dd8609db682  vmovaps xmm12, [rsp+0xB0]
00007dd8609db68b  vmovaps xmm13, [rsp+0xC0]
00007dd8609db694  vmovaps xmm14, [rsp+0xD0]
00007dd8609db69d  vmovaps xmm15, [rsp+0xE0]
00007dd8609db6a6  add rsp, 0xF0
00007dd8609db6ad  pop r11
00007dd8609db6af  pop r10
00007dd8609db6b1  pop r9
00007dd8609db6b3  pop r8
00007dd8609db6b5  pop rsi
00007dd8609db6b6  pop rdi
00007dd8609db6b7  pop rdx
00007dd8609db6b8  pop rcx
00007dd8609db6b9  pop rax
00007dd8609db6ba  add rsp, 0x08
00007dd8609db6be  jmp 0x00007DD8609D918B
00007dd8609db6c3  sub rsp, 0x08
00007dd8609db6c7  push rax
00007dd8609db6c8  push rcx
00007dd8609db6c9  push rdx
00007dd8609db6ca  push rdi
00007dd8609db6cb  push rsi
00007dd8609db6cc  push r8
00007dd8609db6ce  push r9
00007dd8609db6d0  push r10
00007dd8609db6d2  push r11
00007dd8609db6d4  sub rsp, 0xF0
00007dd8609db6db  vmovaps [rsp], xmm0
00007dd8609db6e0  vmovaps [rsp+0x10], xmm1
00007dd8609db6e6  vmovaps [rsp+0x20], xmm2
00007dd8609db6ec  vmovaps [rsp+0x30], xmm3
00007dd8609db6f2  vmovaps [rsp+0x40], xmm4
00007dd8609db6f8  vmovaps [rsp+0x50], xmm5
00007dd8609db6fe  vmovaps [rsp+0x60], xmm6
00007dd8609db704  vmovaps [rsp+0x70], xmm7
00007dd8609db70a  vmovaps [rsp+0x80], xmm8
00007dd8609db713  vmovaps [rsp+0x90], xmm10
00007dd8609db71c  vmovaps [rsp+0xA0], xmm11
00007dd8609db725  vmovaps [rsp+0xB0], xmm12
00007dd8609db72e  vmovaps [rsp+0xC0], xmm13
00007dd8609db737  vmovaps [rsp+0xD0], xmm14
00007dd8609db740  vmovaps [rsp+0xE0], xmm15
00007dd8609db749  sub rsp, 0x30
00007dd8609db74d  movaps [rsp], xmm9
00007dd8609db752  movaps [rsp+0x10], xmm3
00007dd8609db757  movaps [rsp+0x20], xmm1
00007dd8609db75c  lea rdi, [rsp]
00007dd8609db760  mov esi, 0x00
00007dd8609db765  mov rax, 0x629C9CFA9530
00007dd8609db76f  call rax
00007dd8609db771  movaps xmm9, [rsp]
00007dd8609db776  add rsp, 0x30
00007dd8609db77a  vmovaps xmm0, [rsp]
00007dd8609db77f  vmovaps xmm1, [rsp+0x10]
00007dd8609db785  vmovaps xmm2, [rsp+0x20]
00007dd8609db78b  vmovaps xmm3, [rsp+0x30]
00007dd8609db791  vmovaps xmm4, [rsp+0x40]
00007dd8609db797  vmovaps xmm5, [rsp+0x50]
00007dd8609db79d  vmovaps xmm6, [rsp+0x60]
00007dd8609db7a3  vmovaps xmm7, [rsp+0x70]
00007dd8609db7a9  vmovaps xmm8, [rsp+0x80]
00007dd8609db7b2  vmovaps xmm10, [rsp+0x90]
00007dd8609db7bb  vmovaps xmm11, [rsp+0xA0]
00007dd8609db7c4  vmovaps xmm12, [rsp+0xB0]
00007dd8609db7cd  vmovaps xmm13, [rsp+0xC0]
00007dd8609db7d6  vmovaps xmm14, [rsp+0xD0]
00007dd8609db7df  vmovaps xmm15, [rsp+0xE0]
00007dd8609db7e8  add rsp, 0xF0
00007dd8609db7ef  pop r11
00007dd8609db7f1  pop r10
00007dd8609db7f3  pop r9
00007dd8609db7f5  pop r8
00007dd8609db7f7  pop rsi
00007dd8609db7f8  pop rdi
00007dd8609db7f9  pop rdx
00007dd8609db7fa  pop rcx
00007dd8609db7fb  pop rax
00007dd8609db7fc  add rsp, 0x08
00007dd8609db800  jmp 0x00007DD8609D91D7
00007dd8609db805  call 0x00007DD8608D64F0
00007dd8609db80a  jmp 0x00007DD8609D91E4
00007dd8609db80f  sub rsp, 0x08
00007dd8609db813  push rax
00007dd8609db814  push rcx
00007dd8609db815  push rdx
00007dd8609db816  push rdi
00007dd8609db817  push rsi
00007dd8609db818  push r8
00007dd8609db81a  push r9
00007dd8609db81c  push r10
00007dd8609db81e  push r11
00007dd8609db820  sub rsp, 0xF0
00007dd8609db827  vmovaps [rsp], xmm0
00007dd8609db82c  vmovaps [rsp+0x10], xmm1
00007dd8609db832  vmovaps [rsp+0x20], xmm2
00007dd8609db838  vmovaps [rsp+0x30], xmm3
00007dd8609db83e  vmovaps [rsp+0x40], xmm4
00007dd8609db844  vmovaps [rsp+0x50], xmm5
00007dd8609db84a  vmovaps [rsp+0x60], xmm6
00007dd8609db850  vmovaps [rsp+0x70], xmm7
00007dd8609db856  vmovaps [rsp+0x80], xmm8
00007dd8609db85f  vmovaps [rsp+0x90], xmm9
00007dd8609db868  vmovaps [rsp+0xA0], xmm10
00007dd8609db871  vmovaps [rsp+0xB0], xmm11
00007dd8609db87a  vmovaps [rsp+0xC0], xmm12
00007dd8609db883  vmovaps [rsp+0xD0], xmm13
00007dd8609db88c  vmovaps [rsp+0xE0], xmm14
00007dd8609db895  sub rsp, 0x30
00007dd8609db899  movaps [rsp], xmm15
00007dd8609db89e  movaps [rsp+0x10], xmm3
00007dd8609db8a3  movaps [rsp+0x20], xmm7
00007dd8609db8a8  lea rdi, [rsp]
00007dd8609db8ac  mov esi, 0x00
00007dd8609db8b1  mov rax, 0x629C9CFA9530
00007dd8609db8bb  call rax
00007dd8609db8bd  movaps xmm15, [rsp]
00007dd8609db8c2  add rsp, 0x30
00007dd8609db8c6  vmovaps xmm0, [rsp]
00007dd8609db8cb  vmovaps xmm1, [rsp+0x10]
00007dd8609db8d1  vmovaps xmm2, [rsp+0x20]
00007dd8609db8d7  vmovaps xmm3, [rsp+0x30]
00007dd8609db8dd  vmovaps xmm4, [rsp+0x40]
00007dd8609db8e3  vmovaps xmm5, [rsp+0x50]
00007dd8609db8e9  vmovaps xmm6, [rsp+0x60]
00007dd8609db8ef  vmovaps xmm7, [rsp+0x70]
00007dd8609db8f5  vmovaps xmm8, [rsp+0x80]
00007dd8609db8fe  vmovaps xmm9, [rsp+0x90]
00007dd8609db907  vmovaps xmm10, [rsp+0xA0]
00007dd8609db910  vmovaps xmm11, [rsp+0xB0]
00007dd8609db919  vmovaps xmm12, [rsp+0xC0]
00007dd8609db922  vmovaps xmm13, [rsp+0xD0]
00007dd8609db92b  vmovaps xmm14, [rsp+0xE0]
00007dd8609db934  add rsp, 0xF0
00007dd8609db93b  pop r11
00007dd8609db93d  pop r10
00007dd8609db93f  pop r9
00007dd8609db941  pop r8
00007dd8609db943  pop rsi
00007dd8609db944  pop rdi
00007dd8609db945  pop rdx
00007dd8609db946  pop rcx
00007dd8609db947  pop rax
00007dd8609db948  add rsp, 0x08
00007dd8609db94c  jmp 0x00007DD8609D9210
00007dd8609db951  sub rsp, 0x08
00007dd8609db955  push rax
00007dd8609db956  push rcx
00007dd8609db957  push rdx
00007dd8609db958  push rdi
00007dd8609db959  push rsi
00007dd8609db95a  push r8
00007dd8609db95c  push r9
00007dd8609db95e  push r10
00007dd8609db960  push r11
00007dd8609db962  sub rsp, 0xF0
00007dd8609db969  vmovaps [rsp], xmm0
00007dd8609db96e  vmovaps [rsp+0x10], xmm1
00007dd8609db974  vmovaps [rsp+0x20], xmm2
00007dd8609db97a  vmovaps [rsp+0x30], xmm4
00007dd8609db980  vmovaps [rsp+0x40], xmm5
00007dd8609db986  vmovaps [rsp+0x50], xmm6
00007dd8609db98c  vmovaps [rsp+0x60], xmm7
00007dd8609db992  vmovaps [rsp+0x70], xmm8
00007dd8609db998  vmovaps [rsp+0x80], xmm9
00007dd8609db9a1  vmovaps [rsp+0x90], xmm10
00007dd8609db9aa  vmovaps [rsp+0xA0], xmm11
00007dd8609db9b3  vmovaps [rsp+0xB0], xmm12
00007dd8609db9bc  vmovaps [rsp+0xC0], xmm13
00007dd8609db9c5  vmovaps [rsp+0xD0], xmm14
00007dd8609db9ce  vmovaps [rsp+0xE0], xmm15
00007dd8609db9d7  sub rsp, 0x30
00007dd8609db9db  movaps [rsp], xmm3
00007dd8609db9df  movaps [rsp+0x10], xmm1
00007dd8609db9e4  movaps [rsp+0x20], xmm15
00007dd8609db9ea  lea rdi, [rsp]
00007dd8609db9ee  mov esi, 0x00
00007dd8609db9f3  mov rax, 0x629C9CFA9530
00007dd8609db9fd  call rax
00007dd8609db9ff  movaps xmm3, [rsp]
00007dd8609dba03  add rsp, 0x30
00007dd8609dba07  vmovaps xmm0, [rsp]
00007dd8609dba0c  vmovaps xmm1, [rsp+0x10]
00007dd8609dba12  vmovaps xmm2, [rsp+0x20]
00007dd8609dba18  vmovaps xmm4, [rsp+0x30]
00007dd8609dba1e  vmovaps xmm5, [rsp+0x40]
00007dd8609dba24  vmovaps xmm6, [rsp+0x50]
00007dd8609dba2a  vmovaps xmm7, [rsp+0x60]
00007dd8609dba30  vmovaps xmm8, [rsp+0x70]
00007dd8609dba36  vmovaps xmm9, [rsp+0x80]
00007dd8609dba3f  vmovaps xmm10, [rsp+0x90]
00007dd8609dba48  vmovaps xmm11, [rsp+0xA0]
00007dd8609dba51  vmovaps xmm12, [rsp+0xB0]
00007dd8609dba5a  vmovaps xmm13, [rsp+0xC0]
00007dd8609dba63  vmovaps xmm14, [rsp+0xD0]
00007dd8609dba6c  vmovaps xmm15, [rsp+0xE0]
00007dd8609dba75  add rsp, 0xF0
00007dd8609dba7c  pop r11
00007dd8609dba7e  pop r10
00007dd8609dba80  pop r9
00007dd8609dba82  pop r8
00007dd8609dba84  pop rsi
00007dd8609dba85  pop rdi
00007dd8609dba86  pop rdx
00007dd8609dba87  pop rcx
00007dd8609dba88  pop rax
00007dd8609dba89  add rsp, 0x08
00007dd8609dba8d  jmp 0x00007DD8609D929F
00007dd8609dba92  call 0x00007DD8608D64F0
00007dd8609dba97  jmp 0x00007DD8609D92A9
00007dd8609dba9c  sub rsp, 0x08
00007dd8609dbaa0  push rax
00007dd8609dbaa1  push rcx
00007dd8609dbaa2  push rdx
00007dd8609dbaa3  push rdi
00007dd8609dbaa4  push rsi
00007dd8609dbaa5  push r8
00007dd8609dbaa7  push r9
00007dd8609dbaa9  push r10
00007dd8609dbaab  push r11
00007dd8609dbaad  sub rsp, 0xF0
00007dd8609dbab4  vmovaps [rsp], xmm0
00007dd8609dbab9  vmovaps [rsp+0x10], xmm1
00007dd8609dbabf  vmovaps [rsp+0x20], xmm2
00007dd8609dbac5  vmovaps [rsp+0x30], xmm3
00007dd8609dbacb  vmovaps [rsp+0x40], xmm4
00007dd8609dbad1  vmovaps [rsp+0x50], xmm5
00007dd8609dbad7  vmovaps [rsp+0x60], xmm6
00007dd8609dbadd  vmovaps [rsp+0x70], xmm7
00007dd8609dbae3  vmovaps [rsp+0x80], xmm8
00007dd8609dbaec  vmovaps [rsp+0x90], xmm9
00007dd8609dbaf5  vmovaps [rsp+0xA0], xmm10
00007dd8609dbafe  vmovaps [rsp+0xB0], xmm11
00007dd8609dbb07  vmovaps [rsp+0xC0], xmm12
00007dd8609dbb10  vmovaps [rsp+0xD0], xmm13
00007dd8609dbb19  vmovaps [rsp+0xE0], xmm14
00007dd8609dbb22  sub rsp, 0x30
00007dd8609dbb26  movaps [rsp], xmm15
00007dd8609dbb2b  movaps [rsp+0x10], xmm14
00007dd8609dbb31  movaps [rsp+0x20], xmm4
00007dd8609dbb36  lea rdi, [rsp]
00007dd8609dbb3a  mov esi, 0x00
00007dd8609dbb3f  mov rax, 0x629C9CFA9530
00007dd8609dbb49  call rax
00007dd8609dbb4b  movaps xmm15, [rsp]
00007dd8609dbb50  add rsp, 0x30
00007dd8609dbb54  vmovaps xmm0, [rsp]
00007dd8609dbb59  vmovaps xmm1, [rsp+0x10]
00007dd8609dbb5f  vmovaps xmm2, [rsp+0x20]
00007dd8609dbb65  vmovaps xmm3, [rsp+0x30]
00007dd8609dbb6b  vmovaps xmm4, [rsp+0x40]
00007dd8609dbb71  vmovaps xmm5, [rsp+0x50]
00007dd8609dbb77  vmovaps xmm6, [rsp+0x60]
00007dd8609dbb7d  vmovaps xmm7, [rsp+0x70]
00007dd8609dbb83  vmovaps xmm8, [rsp+0x80]
00007dd8609dbb8c  vmovaps xmm9, [rsp+0x90]
00007dd8609dbb95  vmovaps xmm10, [rsp+0xA0]
00007dd8609dbb9e  vmovaps xmm11, [rsp+0xB0]
00007dd8609dbba7  vmovaps xmm12, [rsp+0xC0]
00007dd8609dbbb0  vmovaps xmm13, [rsp+0xD0]
00007dd8609dbbb9  vmovaps xmm14, [rsp+0xE0]
00007dd8609dbbc2  add rsp, 0xF0
00007dd8609dbbc9  pop r11
00007dd8609dbbcb  pop r10
00007dd8609dbbcd  pop r9
00007dd8609dbbcf  pop r8
00007dd8609dbbd1  pop rsi
00007dd8609dbbd2  pop rdi
00007dd8609dbbd3  pop rdx
00007dd8609dbbd4  pop rcx
00007dd8609dbbd5  pop rax
00007dd8609dbbd6  add rsp, 0x08
00007dd8609dbbda  jmp 0x00007DD8609D92D7
00007dd8609dbbdf  sub rsp, 0x08
00007dd8609dbbe3  push rax
00007dd8609dbbe4  push rcx
00007dd8609dbbe5  push rdx
00007dd8609dbbe6  push rdi
00007dd8609dbbe7  push rsi
00007dd8609dbbe8  push r8
00007dd8609dbbea  push r9
00007dd8609dbbec  push r10
00007dd8609dbbee  push r11
00007dd8609dbbf0  sub rsp, 0xF0
00007dd8609dbbf7  vmovaps [rsp], xmm0
00007dd8609dbbfc  vmovaps [rsp+0x10], xmm1
00007dd8609dbc02  vmovaps [rsp+0x20], xmm2
00007dd8609dbc08  vmovaps [rsp+0x30], xmm3
00007dd8609dbc0e  vmovaps [rsp+0x40], xmm4
00007dd8609dbc14  vmovaps [rsp+0x50], xmm5
00007dd8609dbc1a  vmovaps [rsp+0x60], xmm6
00007dd8609dbc20  vmovaps [rsp+0x70], xmm7
00007dd8609dbc26  vmovaps [rsp+0x80], xmm8
00007dd8609dbc2f  vmovaps [rsp+0x90], xmm9
00007dd8609dbc38  vmovaps [rsp+0xA0], xmm10
00007dd8609dbc41  vmovaps [rsp+0xB0], xmm11
00007dd8609dbc4a  vmovaps [rsp+0xC0], xmm12
00007dd8609dbc53  vmovaps [rsp+0xD0], xmm13
00007dd8609dbc5c  vmovaps [rsp+0xE0], xmm15
00007dd8609dbc65  sub rsp, 0x30
00007dd8609dbc69  movaps [rsp], xmm14
00007dd8609dbc6e  movaps [rsp+0x10], xmm2
00007dd8609dbc73  movaps [rsp+0x20], xmm1
00007dd8609dbc78  lea rdi, [rsp]
00007dd8609dbc7c  mov esi, 0x00
00007dd8609dbc81  mov rax, 0x629C9CFA9530
00007dd8609dbc8b  call rax
00007dd8609dbc8d  movaps xmm14, [rsp]
00007dd8609dbc92  add rsp, 0x30
00007dd8609dbc96  vmovaps xmm0, [rsp]
00007dd8609dbc9b  vmovaps xmm1, [rsp+0x10]
00007dd8609dbca1  vmovaps xmm2, [rsp+0x20]
00007dd8609dbca7  vmovaps xmm3, [rsp+0x30]
00007dd8609dbcad  vmovaps xmm4, [rsp+0x40]
00007dd8609dbcb3  vmovaps xmm5, [rsp+0x50]
00007dd8609dbcb9  vmovaps xmm6, [rsp+0x60]
00007dd8609dbcbf  vmovaps xmm7, [rsp+0x70]
00007dd8609dbcc5  vmovaps xmm8, [rsp+0x80]
00007dd8609dbcce  vmovaps xmm9, [rsp+0x90]
00007dd8609dbcd7  vmovaps xmm10, [rsp+0xA0]
00007dd8609dbce0  vmovaps xmm11, [rsp+0xB0]
00007dd8609dbce9  vmovaps xmm12, [rsp+0xC0]
00007dd8609dbcf2  vmovaps xmm13, [rsp+0xD0]
00007dd8609dbcfb  vmovaps xmm15, [rsp+0xE0]
00007dd8609dbd04  add rsp, 0xF0
00007dd8609dbd0b  pop r11
00007dd8609dbd0d  pop r10
00007dd8609dbd0f  pop r9
00007dd8609dbd11  pop r8
00007dd8609dbd13  pop rsi
00007dd8609dbd14  pop rdi
00007dd8609dbd15  pop rdx
00007dd8609dbd16  pop rcx
00007dd8609dbd17  pop rax
00007dd8609dbd18  add rsp, 0x08
00007dd8609dbd1c  jmp 0x00007DD8609D92FD
00007dd8609dbd21  sub rsp, 0x08
00007dd8609dbd25  push rax
00007dd8609dbd26  push rcx
00007dd8609dbd27  push rdx
00007dd8609dbd28  push rdi
00007dd8609dbd29  push rsi
00007dd8609dbd2a  push r8
00007dd8609dbd2c  push r9
00007dd8609dbd2e  push r10
00007dd8609dbd30  push r11
00007dd8609dbd32  sub rsp, 0xF0
00007dd8609dbd39  vmovaps [rsp], xmm0
00007dd8609dbd3e  vmovaps [rsp+0x10], xmm2
00007dd8609dbd44  vmovaps [rsp+0x20], xmm3
00007dd8609dbd4a  vmovaps [rsp+0x30], xmm4
00007dd8609dbd50  vmovaps [rsp+0x40], xmm5
00007dd8609dbd56  vmovaps [rsp+0x50], xmm6
00007dd8609dbd5c  vmovaps [rsp+0x60], xmm7
00007dd8609dbd62  vmovaps [rsp+0x70], xmm8
00007dd8609dbd68  vmovaps [rsp+0x80], xmm9
00007dd8609dbd71  vmovaps [rsp+0x90], xmm10
00007dd8609dbd7a  vmovaps [rsp+0xA0], xmm11
00007dd8609dbd83  vmovaps [rsp+0xB0], xmm12
00007dd8609dbd8c  vmovaps [rsp+0xC0], xmm13
00007dd8609dbd95  vmovaps [rsp+0xD0], xmm14
00007dd8609dbd9e  vmovaps [rsp+0xE0], xmm15
00007dd8609dbda7  sub rsp, 0x30
00007dd8609dbdab  movaps [rsp], xmm1
00007dd8609dbdaf  movaps [rsp+0x10], xmm4
00007dd8609dbdb4  movaps [rsp+0x20], xmm9
00007dd8609dbdba  lea rdi, [rsp]
00007dd8609dbdbe  mov esi, 0x00
00007dd8609dbdc3  mov rax, 0x629C9CFA9530
00007dd8609dbdcd  call rax
00007dd8609dbdcf  movaps xmm1, [rsp]
00007dd8609dbdd3  add rsp, 0x30
00007dd8609dbdd7  vmovaps xmm0, [rsp]
00007dd8609dbddc  vmovaps xmm2, [rsp+0x10]
00007dd8609dbde2  vmovaps xmm3, [rsp+0x20]
00007dd8609dbde8  vmovaps xmm4, [rsp+0x30]
00007dd8609dbdee  vmovaps xmm5, [rsp+0x40]
00007dd8609dbdf4  vmovaps xmm6, [rsp+0x50]
00007dd8609dbdfa  vmovaps xmm7, [rsp+0x60]
00007dd8609dbe00  vmovaps xmm8, [rsp+0x70]
00007dd8609dbe06  vmovaps xmm9, [rsp+0x80]
00007dd8609dbe0f  vmovaps xmm10, [rsp+0x90]
00007dd8609dbe18  vmovaps xmm11, [rsp+0xA0]
00007dd8609dbe21  vmovaps xmm12, [rsp+0xB0]
00007dd8609dbe2a  vmovaps xmm13, [rsp+0xC0]
00007dd8609dbe33  vmovaps xmm14, [rsp+0xD0]
00007dd8609dbe3c  vmovaps xmm15, [rsp+0xE0]
00007dd8609dbe45  add rsp, 0xF0
00007dd8609dbe4c  pop r11
00007dd8609dbe4e  pop r10
00007dd8609dbe50  pop r9
00007dd8609dbe52  pop r8
00007dd8609dbe54  pop rsi
00007dd8609dbe55  pop rdi
00007dd8609dbe56  pop rdx
00007dd8609dbe57  pop rcx
00007dd8609dbe58  pop rax
00007dd8609dbe59  add rsp, 0x08
00007dd8609dbe5d  jmp 0x00007DD8609D931B
00007dd8609dbe62  sub rsp, 0x08
00007dd8609dbe66  push rax
00007dd8609dbe67  push rcx
00007dd8609dbe68  push rdx
00007dd8609dbe69  push rdi
00007dd8609dbe6a  push rsi
00007dd8609dbe6b  push r8
00007dd8609dbe6d  push r9
00007dd8609dbe6f  push r10
00007dd8609dbe71  push r11
00007dd8609dbe73  sub rsp, 0xF0
00007dd8609dbe7a  vmovaps [rsp], xmm0
00007dd8609dbe7f  vmovaps [rsp+0x10], xmm1
00007dd8609dbe85  vmovaps [rsp+0x20], xmm2
00007dd8609dbe8b  vmovaps [rsp+0x30], xmm3
00007dd8609dbe91  vmovaps [rsp+0x40], xmm5
00007dd8609dbe97  vmovaps [rsp+0x50], xmm6
00007dd8609dbe9d  vmovaps [rsp+0x60], xmm7
00007dd8609dbea3  vmovaps [rsp+0x70], xmm8
00007dd8609dbea9  vmovaps [rsp+0x80], xmm9
00007dd8609dbeb2  vmovaps [rsp+0x90], xmm10
00007dd8609dbebb  vmovaps [rsp+0xA0], xmm11
00007dd8609dbec4  vmovaps [rsp+0xB0], xmm12
00007dd8609dbecd  vmovaps [rsp+0xC0], xmm13
00007dd8609dbed6  vmovaps [rsp+0xD0], xmm14
00007dd8609dbedf  vmovaps [rsp+0xE0], xmm15
00007dd8609dbee8  sub rsp, 0x30
00007dd8609dbeec  movaps [rsp], xmm4
00007dd8609dbef0  movaps [rsp+0x10], xmm2
00007dd8609dbef5  movaps [rsp+0x20], xmm9
00007dd8609dbefb  lea rdi, [rsp]
00007dd8609dbeff  mov esi, 0x00
00007dd8609dbf04  mov rax, 0x629C9CFA9530
00007dd8609dbf0e  call rax
00007dd8609dbf10  movaps xmm4, [rsp]
00007dd8609dbf14  add rsp, 0x30
00007dd8609dbf18  vmovaps xmm0, [rsp]
00007dd8609dbf1d  vmovaps xmm1, [rsp+0x10]
00007dd8609dbf23  vmovaps xmm2, [rsp+0x20]
00007dd8609dbf29  vmovaps xmm3, [rsp+0x30]
00007dd8609dbf2f  vmovaps xmm5, [rsp+0x40]
00007dd8609dbf35  vmovaps xmm6, [rsp+0x50]
00007dd8609dbf3b  vmovaps xmm7, [rsp+0x60]
00007dd8609dbf41  vmovaps xmm8, [rsp+0x70]
00007dd8609dbf47  vmovaps xmm9, [rsp+0x80]
00007dd8609dbf50  vmovaps xmm10, [rsp+0x90]
00007dd8609dbf59  vmovaps xmm11, [rsp+0xA0]
00007dd8609dbf62  vmovaps xmm12, [rsp+0xB0]
00007dd8609dbf6b  vmovaps xmm13, [rsp+0xC0]
00007dd8609dbf74  vmovaps xmm14, [rsp+0xD0]
00007dd8609dbf7d  vmovaps xmm15, [rsp+0xE0]
00007dd8609dbf86  add rsp, 0xF0
00007dd8609dbf8d  pop r11
00007dd8609dbf8f  pop r10
00007dd8609dbf91  pop r9
00007dd8609dbf93  pop r8
00007dd8609dbf95  pop rsi
00007dd8609dbf96  pop rdi
00007dd8609dbf97  pop rdx
00007dd8609dbf98  pop rcx
00007dd8609dbf99  pop rax
00007dd8609dbf9a  add rsp, 0x08
00007dd8609dbf9e  jmp 0x00007DD8609D934B
00007dd8609dbfa3  sub rsp, 0x08
00007dd8609dbfa7  push rax
00007dd8609dbfa8  push rcx
00007dd8609dbfa9  push rdx
00007dd8609dbfaa  push rdi
00007dd8609dbfab  push rsi
00007dd8609dbfac  push r8
00007dd8609dbfae  push r9
00007dd8609dbfb0  push r10
00007dd8609dbfb2  push r11
00007dd8609dbfb4  sub rsp, 0xF0
00007dd8609dbfbb  vmovaps [rsp], xmm0
00007dd8609dbfc0  vmovaps [rsp+0x10], xmm1
00007dd8609dbfc6  vmovaps [rsp+0x20], xmm2
00007dd8609dbfcc  vmovaps [rsp+0x30], xmm3
00007dd8609dbfd2  vmovaps [rsp+0x40], xmm4
00007dd8609dbfd8  vmovaps [rsp+0x50], xmm5
00007dd8609dbfde  vmovaps [rsp+0x60], xmm6
00007dd8609dbfe4  vmovaps [rsp+0x70], xmm7
00007dd8609dbfea  vmovaps [rsp+0x80], xmm8
00007dd8609dbff3  vmovaps [rsp+0x90], xmm10
00007dd8609dbffc  vmovaps [rsp+0xA0], xmm11
00007dd8609dc005  vmovaps [rsp+0xB0], xmm12
00007dd8609dc00e  vmovaps [rsp+0xC0], xmm13
00007dd8609dc017  vmovaps [rsp+0xD0], xmm14
00007dd8609dc020  vmovaps [rsp+0xE0], xmm15
00007dd8609dc029  sub rsp, 0x30
00007dd8609dc02d  movaps [rsp], xmm9
00007dd8609dc032  movaps [rsp+0x10], xmm2
00007dd8609dc037  movaps [rsp+0x20], xmm1
00007dd8609dc03c  lea rdi, [rsp]
00007dd8609dc040  mov esi, 0x00
00007dd8609dc045  mov rax, 0x629C9CFA9530
00007dd8609dc04f  call rax
00007dd8609dc051  movaps xmm9, [rsp]
00007dd8609dc056  add rsp, 0x30
00007dd8609dc05a  vmovaps xmm0, [rsp]
00007dd8609dc05f  vmovaps xmm1, [rsp+0x10]
00007dd8609dc065  vmovaps xmm2, [rsp+0x20]
00007dd8609dc06b  vmovaps xmm3, [rsp+0x30]
00007dd8609dc071  vmovaps xmm4, [rsp+0x40]
00007dd8609dc077  vmovaps xmm5, [rsp+0x50]
00007dd8609dc07d  vmovaps xmm6, [rsp+0x60]
00007dd8609dc083  vmovaps xmm7, [rsp+0x70]
00007dd8609dc089  vmovaps xmm8, [rsp+0x80]
00007dd8609dc092  vmovaps xmm10, [rsp+0x90]
00007dd8609dc09b  vmovaps xmm11, [rsp+0xA0]
00007dd8609dc0a4  vmovaps xmm12, [rsp+0xB0]
00007dd8609dc0ad  vmovaps xmm13, [rsp+0xC0]
00007dd8609dc0b6  vmovaps xmm14, [rsp+0xD0]
00007dd8609dc0bf  vmovaps xmm15, [rsp+0xE0]
00007dd8609dc0c8  add rsp, 0xF0
00007dd8609dc0cf  pop r11
00007dd8609dc0d1  pop r10
00007dd8609dc0d3  pop r9
00007dd8609dc0d5  pop r8
00007dd8609dc0d7  pop rsi
00007dd8609dc0d8  pop rdi
00007dd8609dc0d9  pop rdx
00007dd8609dc0da  pop rcx
00007dd8609dc0db  pop rax
00007dd8609dc0dc  add rsp, 0x08
00007dd8609dc0e0  jmp 0x00007DD8609D9381
00007dd8609dc0e5  sub rsp, 0x08
00007dd8609dc0e9  push rax
00007dd8609dc0ea  push rcx
00007dd8609dc0eb  push rdx
00007dd8609dc0ec  push rdi
00007dd8609dc0ed  push rsi
00007dd8609dc0ee  push r8
00007dd8609dc0f0  push r9
00007dd8609dc0f2  push r10
00007dd8609dc0f4  push r11
00007dd8609dc0f6  sub rsp, 0xF0
00007dd8609dc0fd  vmovaps [rsp], xmm0
00007dd8609dc102  vmovaps [rsp+0x10], xmm2
00007dd8609dc108  vmovaps [rsp+0x20], xmm3
00007dd8609dc10e  vmovaps [rsp+0x30], xmm4
00007dd8609dc114  vmovaps [rsp+0x40], xmm5
00007dd8609dc11a  vmovaps [rsp+0x50], xmm6
00007dd8609dc120  vmovaps [rsp+0x60], xmm7
00007dd8609dc126  vmovaps [rsp+0x70], xmm8
00007dd8609dc12c  vmovaps [rsp+0x80], xmm9
00007dd8609dc135  vmovaps [rsp+0x90], xmm10
00007dd8609dc13e  vmovaps [rsp+0xA0], xmm11
00007dd8609dc147  vmovaps [rsp+0xB0], xmm12
00007dd8609dc150  vmovaps [rsp+0xC0], xmm13
00007dd8609dc159  vmovaps [rsp+0xD0], xmm14
00007dd8609dc162  vmovaps [rsp+0xE0], xmm15
00007dd8609dc16b  sub rsp, 0x30
00007dd8609dc16f  movaps [rsp], xmm1
00007dd8609dc173  movaps [rsp+0x10], xmm15
00007dd8609dc179  movaps [rsp+0x20], xmm6
00007dd8609dc17e  lea rdi, [rsp]
00007dd8609dc182  mov esi, 0x00
00007dd8609dc187  mov rax, 0x629C9CFA9530
00007dd8609dc191  call rax
00007dd8609dc193  movaps xmm1, [rsp]
00007dd8609dc197  add rsp, 0x30
00007dd8609dc19b  vmovaps xmm0, [rsp]
00007dd8609dc1a0  vmovaps xmm2, [rsp+0x10]
00007dd8609dc1a6  vmovaps xmm3, [rsp+0x20]
00007dd8609dc1ac  vmovaps xmm4, [rsp+0x30]
00007dd8609dc1b2  vmovaps xmm5, [rsp+0x40]
00007dd8609dc1b8  vmovaps xmm6, [rsp+0x50]
00007dd8609dc1be  vmovaps xmm7, [rsp+0x60]
00007dd8609dc1c4  vmovaps xmm8, [rsp+0x70]
00007dd8609dc1ca  vmovaps xmm9, [rsp+0x80]
00007dd8609dc1d3  vmovaps xmm10, [rsp+0x90]
00007dd8609dc1dc  vmovaps xmm11, [rsp+0xA0]
00007dd8609dc1e5  vmovaps xmm12, [rsp+0xB0]
00007dd8609dc1ee  vmovaps xmm13, [rsp+0xC0]
00007dd8609dc1f7  vmovaps xmm14, [rsp+0xD0]
00007dd8609dc200  vmovaps xmm15, [rsp+0xE0]
00007dd8609dc209  add rsp, 0xF0
00007dd8609dc210  pop r11
00007dd8609dc212  pop r10
00007dd8609dc214  pop r9
00007dd8609dc216  pop r8
00007dd8609dc218  pop rsi
00007dd8609dc219  pop rdi
00007dd8609dc21a  pop rdx
00007dd8609dc21b  pop rcx
00007dd8609dc21c  pop rax
00007dd8609dc21d  add rsp, 0x08
00007dd8609dc221  jmp 0x00007DD8609D93A2
00007dd8609dc226  sub rsp, 0x08
00007dd8609dc22a  push rax
00007dd8609dc22b  push rcx
00007dd8609dc22c  push rdx
00007dd8609dc22d  push rdi
00007dd8609dc22e  push rsi
00007dd8609dc22f  push r8
00007dd8609dc231  push r9
00007dd8609dc233  push r10
00007dd8609dc235  push r11
00007dd8609dc237  sub rsp, 0xF0
00007dd8609dc23e  vmovaps [rsp], xmm0
00007dd8609dc243  vmovaps [rsp+0x10], xmm1
00007dd8609dc249  vmovaps [rsp+0x20], xmm2
00007dd8609dc24f  vmovaps [rsp+0x30], xmm3
00007dd8609dc255  vmovaps [rsp+0x40], xmm4
00007dd8609dc25b  vmovaps [rsp+0x50], xmm5
00007dd8609dc261  vmovaps [rsp+0x60], xmm6
00007dd8609dc267  vmovaps [rsp+0x70], xmm7
00007dd8609dc26d  vmovaps [rsp+0x80], xmm8
00007dd8609dc276  vmovaps [rsp+0x90], xmm9
00007dd8609dc27f  vmovaps [rsp+0xA0], xmm10
00007dd8609dc288  vmovaps [rsp+0xB0], xmm11
00007dd8609dc291  vmovaps [rsp+0xC0], xmm12
00007dd8609dc29a  vmovaps [rsp+0xD0], xmm13
00007dd8609dc2a3  vmovaps [rsp+0xE0], xmm14
00007dd8609dc2ac  sub rsp, 0x30
00007dd8609dc2b0  movaps [rsp], xmm15
00007dd8609dc2b5  movaps [rsp+0x10], xmm5
00007dd8609dc2ba  movaps [rsp+0x20], xmm3
00007dd8609dc2bf  lea rdi, [rsp]
00007dd8609dc2c3  mov esi, 0x00
00007dd8609dc2c8  mov rax, 0x629C9CFA9530
00007dd8609dc2d2  call rax
00007dd8609dc2d4  movaps xmm15, [rsp]
00007dd8609dc2d9  add rsp, 0x30
00007dd8609dc2dd  vmovaps xmm0, [rsp]
00007dd8609dc2e2  vmovaps xmm1, [rsp+0x10]
00007dd8609dc2e8  vmovaps xmm2, [rsp+0x20]
00007dd8609dc2ee  vmovaps xmm3, [rsp+0x30]
00007dd8609dc2f4  vmovaps xmm4, [rsp+0x40]
00007dd8609dc2fa  vmovaps xmm5, [rsp+0x50]
00007dd8609dc300  vmovaps xmm6, [rsp+0x60]
00007dd8609dc306  vmovaps xmm7, [rsp+0x70]
00007dd8609dc30c  vmovaps xmm8, [rsp+0x80]
00007dd8609dc315  vmovaps xmm9, [rsp+0x90]
00007dd8609dc31e  vmovaps xmm10, [rsp+0xA0]
00007dd8609dc327  vmovaps xmm11, [rsp+0xB0]
00007dd8609dc330  vmovaps xmm12, [rsp+0xC0]
00007dd8609dc339  vmovaps xmm13, [rsp+0xD0]
00007dd8609dc342  vmovaps xmm14, [rsp+0xE0]
00007dd8609dc34b  add rsp, 0xF0
00007dd8609dc352  pop r11
00007dd8609dc354  pop r10
00007dd8609dc356  pop r9
00007dd8609dc358  pop r8
00007dd8609dc35a  pop rsi
00007dd8609dc35b  pop rdi
00007dd8609dc35c  pop rdx
00007dd8609dc35d  pop rcx
00007dd8609dc35e  pop rax
00007dd8609dc35f  add rsp, 0x08
00007dd8609dc363  jmp 0x00007DD8609D93BC
00007dd8609dc368  sub rsp, 0x08
00007dd8609dc36c  push rax
00007dd8609dc36d  push rcx
00007dd8609dc36e  push rdx
00007dd8609dc36f  push rdi
00007dd8609dc370  push rsi
00007dd8609dc371  push r8
00007dd8609dc373  push r9
00007dd8609dc375  push r10
00007dd8609dc377  push r11
00007dd8609dc379  sub rsp, 0xF0
00007dd8609dc380  vmovaps [rsp], xmm0
00007dd8609dc385  vmovaps [rsp+0x10], xmm1
00007dd8609dc38b  vmovaps [rsp+0x20], xmm2
00007dd8609dc391  vmovaps [rsp+0x30], xmm3
00007dd8609dc397  vmovaps [rsp+0x40], xmm4
00007dd8609dc39d  vmovaps [rsp+0x50], xmm6
00007dd8609dc3a3  vmovaps [rsp+0x60], xmm7
00007dd8609dc3a9  vmovaps [rsp+0x70], xmm8
00007dd8609dc3af  vmovaps [rsp+0x80], xmm9
00007dd8609dc3b8  vmovaps [rsp+0x90], xmm10
00007dd8609dc3c1  vmovaps [rsp+0xA0], xmm11
00007dd8609dc3ca  vmovaps [rsp+0xB0], xmm12
00007dd8609dc3d3  vmovaps [rsp+0xC0], xmm13
00007dd8609dc3dc  vmovaps [rsp+0xD0], xmm14
00007dd8609dc3e5  vmovaps [rsp+0xE0], xmm15
00007dd8609dc3ee  sub rsp, 0x30
00007dd8609dc3f2  movaps [rsp], xmm5
00007dd8609dc3f6  movaps [rsp+0x10], xmm8
00007dd8609dc3fc  movaps [rsp+0x20], xmm6
00007dd8609dc401  lea rdi, [rsp]
00007dd8609dc405  mov esi, 0x00
00007dd8609dc40a  mov rax, 0x629C9CFA9530
00007dd8609dc414  call rax
00007dd8609dc416  movaps xmm5, [rsp]
00007dd8609dc41a  add rsp, 0x30
00007dd8609dc41e  vmovaps xmm0, [rsp]
00007dd8609dc423  vmovaps xmm1, [rsp+0x10]
00007dd8609dc429  vmovaps xmm2, [rsp+0x20]
00007dd8609dc42f  vmovaps xmm3, [rsp+0x30]
00007dd8609dc435  vmovaps xmm4, [rsp+0x40]
00007dd8609dc43b  vmovaps xmm6, [rsp+0x50]
00007dd8609dc441  vmovaps xmm7, [rsp+0x60]
00007dd8609dc447  vmovaps xmm8, [rsp+0x70]
00007dd8609dc44d  vmovaps xmm9, [rsp+0x80]
00007dd8609dc456  vmovaps xmm10, [rsp+0x90]
00007dd8609dc45f  vmovaps xmm11, [rsp+0xA0]
00007dd8609dc468  vmovaps xmm12, [rsp+0xB0]
00007dd8609dc471  vmovaps xmm13, [rsp+0xC0]
00007dd8609dc47a  vmovaps xmm14, [rsp+0xD0]
00007dd8609dc483  vmovaps xmm15, [rsp+0xE0]
00007dd8609dc48c  add rsp, 0xF0
00007dd8609dc493  pop r11
00007dd8609dc495  pop r10
00007dd8609dc497  pop r9
00007dd8609dc499  pop r8
00007dd8609dc49b  pop rsi
00007dd8609dc49c  pop rdi
00007dd8609dc49d  pop rdx
00007dd8609dc49e  pop rcx
00007dd8609dc49f  pop rax
00007dd8609dc4a0  add rsp, 0x08
00007dd8609dc4a4  jmp 0x00007DD8609D93E0
00007dd8609dc4a9  sub rsp, 0x08
00007dd8609dc4ad  push rax
00007dd8609dc4ae  push rcx
00007dd8609dc4af  push rdx
00007dd8609dc4b0  push rdi
00007dd8609dc4b1  push rsi
00007dd8609dc4b2  push r8
00007dd8609dc4b4  push r9
00007dd8609dc4b6  push r10
00007dd8609dc4b8  push r11
00007dd8609dc4ba  sub rsp, 0xF0
00007dd8609dc4c1  vmovaps [rsp], xmm0
00007dd8609dc4c6  vmovaps [rsp+0x10], xmm1
00007dd8609dc4cc  vmovaps [rsp+0x20], xmm2
00007dd8609dc4d2  vmovaps [rsp+0x30], xmm3
00007dd8609dc4d8  vmovaps [rsp+0x40], xmm4
00007dd8609dc4de  vmovaps [rsp+0x50], xmm5
00007dd8609dc4e4  vmovaps [rsp+0x60], xmm7
00007dd8609dc4ea  vmovaps [rsp+0x70], xmm8
00007dd8609dc4f0  vmovaps [rsp+0x80], xmm9
00007dd8609dc4f9  vmovaps [rsp+0x90], xmm10
00007dd8609dc502  vmovaps [rsp+0xA0], xmm11
00007dd8609dc50b  vmovaps [rsp+0xB0], xmm12
00007dd8609dc514  vmovaps [rsp+0xC0], xmm13
00007dd8609dc51d  vmovaps [rsp+0xD0], xmm14
00007dd8609dc526  vmovaps [rsp+0xE0], xmm15
00007dd8609dc52f  sub rsp, 0x30
00007dd8609dc533  movaps [rsp], xmm6
00007dd8609dc537  movaps [rsp+0x10], xmm10
00007dd8609dc53d  movaps [rsp+0x20], xmm8
00007dd8609dc543  lea rdi, [rsp]
00007dd8609dc547  mov esi, 0x00
00007dd8609dc54c  mov rax, 0x629C9CFA9530
00007dd8609dc556  call rax
00007dd8609dc558  movaps xmm6, [rsp]
00007dd8609dc55c  add rsp, 0x30
00007dd8609dc560  vmovaps xmm0, [rsp]
00007dd8609dc565  vmovaps xmm1, [rsp+0x10]
00007dd8609dc56b  vmovaps xmm2, [rsp+0x20]
00007dd8609dc571  vmovaps xmm3, [rsp+0x30]
00007dd8609dc577  vmovaps xmm4, [rsp+0x40]
00007dd8609dc57d  vmovaps xmm5, [rsp+0x50]
00007dd8609dc583  vmovaps xmm7, [rsp+0x60]
00007dd8609dc589  vmovaps xmm8, [rsp+0x70]
00007dd8609dc58f  vmovaps xmm9, [rsp+0x80]
00007dd8609dc598  vmovaps xmm10, [rsp+0x90]
00007dd8609dc5a1  vmovaps xmm11, [rsp+0xA0]
00007dd8609dc5aa  vmovaps xmm12, [rsp+0xB0]
00007dd8609dc5b3  vmovaps xmm13, [rsp+0xC0]
00007dd8609dc5bc  vmovaps xmm14, [rsp+0xD0]
00007dd8609dc5c5  vmovaps xmm15, [rsp+0xE0]
00007dd8609dc5ce  add rsp, 0xF0
00007dd8609dc5d5  pop r11
00007dd8609dc5d7  pop r10
00007dd8609dc5d9  pop r9
00007dd8609dc5db  pop r8
00007dd8609dc5dd  pop rsi
00007dd8609dc5de  pop rdi
00007dd8609dc5df  pop rdx
00007dd8609dc5e0  pop rcx
00007dd8609dc5e1  pop rax
00007dd8609dc5e2  add rsp, 0x08
00007dd8609dc5e6  jmp 0x00007DD8609D9405
00007dd8609dc5eb  sub rsp, 0x08
00007dd8609dc5ef  push rax
00007dd8609dc5f0  push rcx
00007dd8609dc5f1  push rdx
00007dd8609dc5f2  push rdi
00007dd8609dc5f3  push rsi
00007dd8609dc5f4  push r8
00007dd8609dc5f6  push r9
00007dd8609dc5f8  push r10
00007dd8609dc5fa  push r11
00007dd8609dc5fc  sub rsp, 0xF0
00007dd8609dc603  vmovaps [rsp], xmm0
00007dd8609dc608  vmovaps [rsp+0x10], xmm1
00007dd8609dc60e  vmovaps [rsp+0x20], xmm2
00007dd8609dc614  vmovaps [rsp+0x30], xmm3
00007dd8609dc61a  vmovaps [rsp+0x40], xmm4
00007dd8609dc620  vmovaps [rsp+0x50], xmm5
00007dd8609dc626  vmovaps [rsp+0x60], xmm6
00007dd8609dc62c  vmovaps [rsp+0x70], xmm7
00007dd8609dc632  vmovaps [rsp+0x80], xmm8
00007dd8609dc63b  vmovaps [rsp+0x90], xmm9
00007dd8609dc644  vmovaps [rsp+0xA0], xmm11
00007dd8609dc64d  vmovaps [rsp+0xB0], xmm12
00007dd8609dc656  vmovaps [rsp+0xC0], xmm13
00007dd8609dc65f  vmovaps [rsp+0xD0], xmm14
00007dd8609dc668  vmovaps [rsp+0xE0], xmm15
00007dd8609dc671  sub rsp, 0x30
00007dd8609dc675  movaps [rsp], xmm10
00007dd8609dc67a  movaps [rsp+0x10], xmm8
00007dd8609dc680  movaps [rsp+0x20], xmm14
00007dd8609dc686  lea rdi, [rsp]
00007dd8609dc68a  mov esi, 0x00
00007dd8609dc68f  mov rax, 0x629C9CFA9530
00007dd8609dc699  call rax
00007dd8609dc69b  movaps xmm10, [rsp]
00007dd8609dc6a0  add rsp, 0x30
00007dd8609dc6a4  vmovaps xmm0, [rsp]
00007dd8609dc6a9  vmovaps xmm1, [rsp+0x10]
00007dd8609dc6af  vmovaps xmm2, [rsp+0x20]
00007dd8609dc6b5  vmovaps xmm3, [rsp+0x30]
00007dd8609dc6bb  vmovaps xmm4, [rsp+0x40]
00007dd8609dc6c1  vmovaps xmm5, [rsp+0x50]
00007dd8609dc6c7  vmovaps xmm6, [rsp+0x60]
00007dd8609dc6cd  vmovaps xmm7, [rsp+0x70]
00007dd8609dc6d3  vmovaps xmm8, [rsp+0x80]
00007dd8609dc6dc  vmovaps xmm9, [rsp+0x90]
00007dd8609dc6e5  vmovaps xmm11, [rsp+0xA0]
00007dd8609dc6ee  vmovaps xmm12, [rsp+0xB0]
00007dd8609dc6f7  vmovaps xmm13, [rsp+0xC0]
00007dd8609dc700  vmovaps xmm14, [rsp+0xD0]
00007dd8609dc709  vmovaps xmm15, [rsp+0xE0]
00007dd8609dc712  add rsp, 0xF0
00007dd8609dc719  pop r11
00007dd8609dc71b  pop r10
00007dd8609dc71d  pop r9
00007dd8609dc71f  pop r8
00007dd8609dc721  pop rsi
00007dd8609dc722  pop rdi
00007dd8609dc723  pop rdx
00007dd8609dc724  pop rcx
00007dd8609dc725  pop rax
00007dd8609dc726  add rsp, 0x08
00007dd8609dc72a  jmp 0x00007DD8609D9425
00007dd8609dc72f  sub rsp, 0x08
00007dd8609dc733  push rax
00007dd8609dc734  push rcx
00007dd8609dc735  push rdx
00007dd8609dc736  push rdi
00007dd8609dc737  push rsi
00007dd8609dc738  push r8
00007dd8609dc73a  push r9
00007dd8609dc73c  push r10
00007dd8609dc73e  push r11
00007dd8609dc740  sub rsp, 0xF0
00007dd8609dc747  vmovaps [rsp], xmm0
00007dd8609dc74c  vmovaps [rsp+0x10], xmm1
00007dd8609dc752  vmovaps [rsp+0x20], xmm2
00007dd8609dc758  vmovaps [rsp+0x30], xmm3
00007dd8609dc75e  vmovaps [rsp+0x40], xmm4
00007dd8609dc764  vmovaps [rsp+0x50], xmm5
00007dd8609dc76a  vmovaps [rsp+0x60], xmm6
00007dd8609dc770  vmovaps [rsp+0x70], xmm7
00007dd8609dc776  vmovaps [rsp+0x80], xmm8
00007dd8609dc77f  vmovaps [rsp+0x90], xmm9
00007dd8609dc788  vmovaps [rsp+0xA0], xmm10
00007dd8609dc791  vmovaps [rsp+0xB0], xmm11
00007dd8609dc79a  vmovaps [rsp+0xC0], xmm12
00007dd8609dc7a3  vmovaps [rsp+0xD0], xmm13
00007dd8609dc7ac  vmovaps [rsp+0xE0], xmm15
00007dd8609dc7b5  sub rsp, 0x30
00007dd8609dc7b9  movaps [rsp], xmm14
00007dd8609dc7be  movaps [rsp+0x10], xmm8
00007dd8609dc7c4  movaps [rsp+0x20], xmm4
00007dd8609dc7c9  lea rdi, [rsp]
00007dd8609dc7cd  mov esi, 0x00
00007dd8609dc7d2  mov rax, 0x629C9CFA9530
00007dd8609dc7dc  call rax
00007dd8609dc7de  movaps xmm14, [rsp]
00007dd8609dc7e3  add rsp, 0x30
00007dd8609dc7e7  vmovaps xmm0, [rsp]
00007dd8609dc7ec  vmovaps xmm1, [rsp+0x10]
00007dd8609dc7f2  vmovaps xmm2, [rsp+0x20]
00007dd8609dc7f8  vmovaps xmm3, [rsp+0x30]
00007dd8609dc7fe  vmovaps xmm4, [rsp+0x40]
00007dd8609dc804  vmovaps xmm5, [rsp+0x50]
00007dd8609dc80a  vmovaps xmm6, [rsp+0x60]
00007dd8609dc810  vmovaps xmm7, [rsp+0x70]
00007dd8609dc816  vmovaps xmm8, [rsp+0x80]
00007dd8609dc81f  vmovaps xmm9, [rsp+0x90]
00007dd8609dc828  vmovaps xmm10, [rsp+0xA0]
00007dd8609dc831  vmovaps xmm11, [rsp+0xB0]
00007dd8609dc83a  vmovaps xmm12, [rsp+0xC0]
00007dd8609dc843  vmovaps xmm13, [rsp+0xD0]
00007dd8609dc84c  vmovaps xmm15, [rsp+0xE0]
00007dd8609dc855  add rsp, 0xF0
00007dd8609dc85c  pop r11
00007dd8609dc85e  pop r10
00007dd8609dc860  pop r9
00007dd8609dc862  pop r8
00007dd8609dc864  pop rsi
00007dd8609dc865  pop rdi
00007dd8609dc866  pop rdx
00007dd8609dc867  pop rcx
00007dd8609dc868  pop rax
00007dd8609dc869  add rsp, 0x08
00007dd8609dc86d  jmp 0x00007DD8609D9445
00007dd8609dc872  sub rsp, 0x08
00007dd8609dc876  push rax
00007dd8609dc877  push rcx
00007dd8609dc878  push rdx
00007dd8609dc879  push rdi
00007dd8609dc87a  push rsi
00007dd8609dc87b  push r8
00007dd8609dc87d  push r9
00007dd8609dc87f  push r10
00007dd8609dc881  push r11
00007dd8609dc883  sub rsp, 0xF0
00007dd8609dc88a  vmovaps [rsp], xmm0
00007dd8609dc88f  vmovaps [rsp+0x10], xmm1
00007dd8609dc895  vmovaps [rsp+0x20], xmm2
00007dd8609dc89b  vmovaps [rsp+0x30], xmm3
00007dd8609dc8a1  vmovaps [rsp+0x40], xmm5
00007dd8609dc8a7  vmovaps [rsp+0x50], xmm6
00007dd8609dc8ad  vmovaps [rsp+0x60], xmm7
00007dd8609dc8b3  vmovaps [rsp+0x70], xmm8
00007dd8609dc8b9  vmovaps [rsp+0x80], xmm9
00007dd8609dc8c2  vmovaps [rsp+0x90], xmm10
00007dd8609dc8cb  vmovaps [rsp+0xA0], xmm11
00007dd8609dc8d4  vmovaps [rsp+0xB0], xmm12
00007dd8609dc8dd  vmovaps [rsp+0xC0], xmm13
00007dd8609dc8e6  vmovaps [rsp+0xD0], xmm14
00007dd8609dc8ef  vmovaps [rsp+0xE0], xmm15
00007dd8609dc8f8  sub rsp, 0x30
00007dd8609dc8fc  movaps [rsp], xmm4
00007dd8609dc900  movaps [rsp+0x10], xmm13
00007dd8609dc906  movaps [rsp+0x20], xmm8
00007dd8609dc90c  lea rdi, [rsp]
00007dd8609dc910  mov esi, 0x00
00007dd8609dc915  mov rax, 0x629C9CFA9530
00007dd8609dc91f  call rax
00007dd8609dc921  movaps xmm4, [rsp]
00007dd8609dc925  add rsp, 0x30
00007dd8609dc929  vmovaps xmm0, [rsp]
00007dd8609dc92e  vmovaps xmm1, [rsp+0x10]
00007dd8609dc934  vmovaps xmm2, [rsp+0x20]
00007dd8609dc93a  vmovaps xmm3, [rsp+0x30]
00007dd8609dc940  vmovaps xmm5, [rsp+0x40]
00007dd8609dc946  vmovaps xmm6, [rsp+0x50]
00007dd8609dc94c  vmovaps xmm7, [rsp+0x60]
00007dd8609dc952  vmovaps xmm8, [rsp+0x70]
00007dd8609dc958  vmovaps xmm9, [rsp+0x80]
00007dd8609dc961  vmovaps xmm10, [rsp+0x90]
00007dd8609dc96a  vmovaps xmm11, [rsp+0xA0]
00007dd8609dc973  vmovaps xmm12, [rsp+0xB0]
00007dd8609dc97c  vmovaps xmm13, [rsp+0xC0]
00007dd8609dc985  vmovaps xmm14, [rsp+0xD0]
00007dd8609dc98e  vmovaps xmm15, [rsp+0xE0]
00007dd8609dc997  add rsp, 0xF0
00007dd8609dc99e  pop r11
00007dd8609dc9a0  pop r10
00007dd8609dc9a2  pop r9
00007dd8609dc9a4  pop r8
00007dd8609dc9a6  pop rsi
00007dd8609dc9a7  pop rdi
00007dd8609dc9a8  pop rdx
00007dd8609dc9a9  pop rcx
00007dd8609dc9aa  pop rax
00007dd8609dc9ab  add rsp, 0x08
00007dd8609dc9af  jmp 0x00007DD8609D946A
00007dd8609dc9b4  sub rsp, 0x08
00007dd8609dc9b8  push rax
00007dd8609dc9b9  push rcx
00007dd8609dc9ba  push rdx
00007dd8609dc9bb  push rdi
00007dd8609dc9bc  push rsi
00007dd8609dc9bd  push r8
00007dd8609dc9bf  push r9
00007dd8609dc9c1  push r10
00007dd8609dc9c3  push r11
00007dd8609dc9c5  sub rsp, 0xF0
00007dd8609dc9cc  vmovaps [rsp], xmm0
00007dd8609dc9d1  vmovaps [rsp+0x10], xmm1
00007dd8609dc9d7  vmovaps [rsp+0x20], xmm2
00007dd8609dc9dd  vmovaps [rsp+0x30], xmm3
00007dd8609dc9e3  vmovaps [rsp+0x40], xmm4
00007dd8609dc9e9  vmovaps [rsp+0x50], xmm5
00007dd8609dc9ef  vmovaps [rsp+0x60], xmm6
00007dd8609dc9f5  vmovaps [rsp+0x70], xmm7
00007dd8609dc9fb  vmovaps [rsp+0x80], xmm8
00007dd8609dca04  vmovaps [rsp+0x90], xmm9
00007dd8609dca0d  vmovaps [rsp+0xA0], xmm10
00007dd8609dca16  vmovaps [rsp+0xB0], xmm11
00007dd8609dca1f  vmovaps [rsp+0xC0], xmm12
00007dd8609dca28  vmovaps [rsp+0xD0], xmm14
00007dd8609dca31  vmovaps [rsp+0xE0], xmm15
00007dd8609dca3a  sub rsp, 0x30
00007dd8609dca3e  movaps [rsp], xmm13
00007dd8609dca43  movaps [rsp+0x10], xmm15
00007dd8609dca49  movaps [rsp+0x20], xmm9
00007dd8609dca4f  lea rdi, [rsp]
00007dd8609dca53  mov esi, 0x00
00007dd8609dca58  mov rax, 0x629C9CFA9530
00007dd8609dca62  call rax
00007dd8609dca64  movaps xmm13, [rsp]
00007dd8609dca69  add rsp, 0x30
00007dd8609dca6d  vmovaps xmm0, [rsp]
00007dd8609dca72  vmovaps xmm1, [rsp+0x10]
00007dd8609dca78  vmovaps xmm2, [rsp+0x20]
00007dd8609dca7e  vmovaps xmm3, [rsp+0x30]
00007dd8609dca84  vmovaps xmm4, [rsp+0x40]
00007dd8609dca8a  vmovaps xmm5, [rsp+0x50]
00007dd8609dca90  vmovaps xmm6, [rsp+0x60]
00007dd8609dca96  vmovaps xmm7, [rsp+0x70]
00007dd8609dca9c  vmovaps xmm8, [rsp+0x80]
00007dd8609dcaa5  vmovaps xmm9, [rsp+0x90]
00007dd8609dcaae  vmovaps xmm10, [rsp+0xA0]
00007dd8609dcab7  vmovaps xmm11, [rsp+0xB0]
00007dd8609dcac0  vmovaps xmm12, [rsp+0xC0]
00007dd8609dcac9  vmovaps xmm14, [rsp+0xD0]
00007dd8609dcad2  vmovaps xmm15, [rsp+0xE0]
00007dd8609dcadb  add rsp, 0xF0
00007dd8609dcae2  pop r11
00007dd8609dcae4  pop r10
00007dd8609dcae6  pop r9
00007dd8609dcae8  pop r8
00007dd8609dcaea  pop rsi
00007dd8609dcaeb  pop rdi
00007dd8609dcaec  pop rdx
00007dd8609dcaed  pop rcx
00007dd8609dcaee  pop rax
00007dd8609dcaef  add rsp, 0x08
00007dd8609dcaf3  jmp 0x00007DD8609D9485
00007dd8609dcaf8  sub rsp, 0x08
00007dd8609dcafc  push rax
00007dd8609dcafd  push rcx
00007dd8609dcafe  push rdx
00007dd8609dcaff  push rdi
00007dd8609dcb00  push rsi
00007dd8609dcb01  push r8
00007dd8609dcb03  push r9
00007dd8609dcb05  push r10
00007dd8609dcb07  push r11
00007dd8609dcb09  sub rsp, 0xF0
00007dd8609dcb10  vmovaps [rsp], xmm0
00007dd8609dcb15  vmovaps [rsp+0x10], xmm1
00007dd8609dcb1b  vmovaps [rsp+0x20], xmm2
00007dd8609dcb21  vmovaps [rsp+0x30], xmm3
00007dd8609dcb27  vmovaps [rsp+0x40], xmm4
00007dd8609dcb2d  vmovaps [rsp+0x50], xmm5
00007dd8609dcb33  vmovaps [rsp+0x60], xmm6
00007dd8609dcb39  vmovaps [rsp+0x70], xmm7
00007dd8609dcb3f  vmovaps [rsp+0x80], xmm8
00007dd8609dcb48  vmovaps [rsp+0x90], xmm9
00007dd8609dcb51  vmovaps [rsp+0xA0], xmm10
00007dd8609dcb5a  vmovaps [rsp+0xB0], xmm11
00007dd8609dcb63  vmovaps [rsp+0xC0], xmm12
00007dd8609dcb6c  vmovaps [rsp+0xD0], xmm13
00007dd8609dcb75  vmovaps [rsp+0xE0], xmm14
00007dd8609dcb7e  sub rsp, 0x30
00007dd8609dcb82  movaps [rsp], xmm15
00007dd8609dcb87  movaps [rsp+0x10], xmm1
00007dd8609dcb8c  movaps [rsp+0x20], xmm5
00007dd8609dcb91  lea rdi, [rsp]
00007dd8609dcb95  mov esi, 0x00
00007dd8609dcb9a  mov rax, 0x629C9CFA9530
00007dd8609dcba4  call rax
00007dd8609dcba6  movaps xmm15, [rsp]
00007dd8609dcbab  add rsp, 0x30
00007dd8609dcbaf  vmovaps xmm0, [rsp]
00007dd8609dcbb4  vmovaps xmm1, [rsp+0x10]
00007dd8609dcbba  vmovaps xmm2, [rsp+0x20]
00007dd8609dcbc0  vmovaps xmm3, [rsp+0x30]
00007dd8609dcbc6  vmovaps xmm4, [rsp+0x40]
00007dd8609dcbcc  vmovaps xmm5, [rsp+0x50]
00007dd8609dcbd2  vmovaps xmm6, [rsp+0x60]
00007dd8609dcbd8  vmovaps xmm7, [rsp+0x70]
00007dd8609dcbde  vmovaps xmm8, [rsp+0x80]
00007dd8609dcbe7  vmovaps xmm9, [rsp+0x90]
00007dd8609dcbf0  vmovaps xmm10, [rsp+0xA0]
00007dd8609dcbf9  vmovaps xmm11, [rsp+0xB0]
00007dd8609dcc02  vmovaps xmm12, [rsp+0xC0]
00007dd8609dcc0b  vmovaps xmm13, [rsp+0xD0]
00007dd8609dcc14  vmovaps xmm14, [rsp+0xE0]
00007dd8609dcc1d  add rsp, 0xF0
00007dd8609dcc24  pop r11
00007dd8609dcc26  pop r10
00007dd8609dcc28  pop r9
00007dd8609dcc2a  pop r8
00007dd8609dcc2c  pop rsi
00007dd8609dcc2d  pop rdi
00007dd8609dcc2e  pop rdx
00007dd8609dcc2f  pop rcx
00007dd8609dcc30  pop rax
00007dd8609dcc31  add rsp, 0x08
00007dd8609dcc35  jmp 0x00007DD8609D94A0
00007dd8609dcc3a  call 0x00007DD8608D64F0
00007dd8609dcc3f  jmp 0x00007DD8609D94FB
00007dd8609dcc44  sub rsp, 0x08
00007dd8609dcc48  push rax
00007dd8609dcc49  push rcx
00007dd8609dcc4a  push rdx
00007dd8609dcc4b  push rdi
00007dd8609dcc4c  push rsi
00007dd8609dcc4d  push r8
00007dd8609dcc4f  push r9
00007dd8609dcc51  push r10
00007dd8609dcc53  push r11
00007dd8609dcc55  sub rsp, 0xF0
00007dd8609dcc5c  vmovaps [rsp], xmm0
00007dd8609dcc61  vmovaps [rsp+0x10], xmm1
00007dd8609dcc67  vmovaps [rsp+0x20], xmm2
00007dd8609dcc6d  vmovaps [rsp+0x30], xmm3
00007dd8609dcc73  vmovaps [rsp+0x40], xmm4
00007dd8609dcc79  vmovaps [rsp+0x50], xmm5
00007dd8609dcc7f  vmovaps [rsp+0x60], xmm6
00007dd8609dcc85  vmovaps [rsp+0x70], xmm7
00007dd8609dcc8b  vmovaps [rsp+0x80], xmm8
00007dd8609dcc94  vmovaps [rsp+0x90], xmm10
00007dd8609dcc9d  vmovaps [rsp+0xA0], xmm11
00007dd8609dcca6  vmovaps [rsp+0xB0], xmm12
00007dd8609dccaf  vmovaps [rsp+0xC0], xmm13
00007dd8609dccb8  vmovaps [rsp+0xD0], xmm14
00007dd8609dccc1  vmovaps [rsp+0xE0], xmm15
00007dd8609dccca  sub rsp, 0x30
00007dd8609dccce  movaps [rsp], xmm9
00007dd8609dccd3  movaps [rsp+0x10], xmm8
00007dd8609dccd9  movaps [rsp+0x20], xmm11
00007dd8609dccdf  lea rdi, [rsp]
00007dd8609dcce3  mov esi, 0x00
00007dd8609dcce8  mov rax, 0x629C9CFA9530
00007dd8609dccf2  call rax
00007dd8609dccf4  movaps xmm9, [rsp]
00007dd8609dccf9  add rsp, 0x30
00007dd8609dccfd  vmovaps xmm0, [rsp]
00007dd8609dcd02  vmovaps xmm1, [rsp+0x10]
00007dd8609dcd08  vmovaps xmm2, [rsp+0x20]
00007dd8609dcd0e  vmovaps xmm3, [rsp+0x30]
00007dd8609dcd14  vmovaps xmm4, [rsp+0x40]
00007dd8609dcd1a  vmovaps xmm5, [rsp+0x50]
00007dd8609dcd20  vmovaps xmm6, [rsp+0x60]
00007dd8609dcd26  vmovaps xmm7, [rsp+0x70]
00007dd8609dcd2c  vmovaps xmm8, [rsp+0x80]
00007dd8609dcd35  vmovaps xmm10, [rsp+0x90]
00007dd8609dcd3e  vmovaps xmm11, [rsp+0xA0]
00007dd8609dcd47  vmovaps xmm12, [rsp+0xB0]
00007dd8609dcd50  vmovaps xmm13, [rsp+0xC0]
00007dd8609dcd59  vmovaps xmm14, [rsp+0xD0]
00007dd8609dcd62  vmovaps xmm15, [rsp+0xE0]
00007dd8609dcd6b  add rsp, 0xF0
00007dd8609dcd72  pop r11
00007dd8609dcd74  pop r10
00007dd8609dcd76  pop r9
00007dd8609dcd78  pop r8
00007dd8609dcd7a  pop rsi
00007dd8609dcd7b  pop rdi
00007dd8609dcd7c  pop rdx
00007dd8609dcd7d  pop rcx
00007dd8609dcd7e  pop rax
00007dd8609dcd7f  add rsp, 0x08
00007dd8609dcd83  jmp 0x00007DD8609D9532
00007dd8609dcd88  sub rsp, 0x08
00007dd8609dcd8c  push rax
00007dd8609dcd8d  push rcx
00007dd8609dcd8e  push rdx
00007dd8609dcd8f  push rdi
00007dd8609dcd90  push rsi
00007dd8609dcd91  push r8
00007dd8609dcd93  push r9
00007dd8609dcd95  push r10
00007dd8609dcd97  push r11
00007dd8609dcd99  sub rsp, 0xF0
00007dd8609dcda0  vmovaps [rsp], xmm0
00007dd8609dcda5  vmovaps [rsp+0x10], xmm1
00007dd8609dcdab  vmovaps [rsp+0x20], xmm2
00007dd8609dcdb1  vmovaps [rsp+0x30], xmm3
00007dd8609dcdb7  vmovaps [rsp+0x40], xmm4
00007dd8609dcdbd  vmovaps [rsp+0x50], xmm5
00007dd8609dcdc3  vmovaps [rsp+0x60], xmm6
00007dd8609dcdc9  vmovaps [rsp+0x70], xmm7
00007dd8609dcdcf  vmovaps [rsp+0x80], xmm8
00007dd8609dcdd8  vmovaps [rsp+0x90], xmm9
00007dd8609dcde1  vmovaps [rsp+0xA0], xmm10
00007dd8609dcdea  vmovaps [rsp+0xB0], xmm12
00007dd8609dcdf3  vmovaps [rsp+0xC0], xmm13
00007dd8609dcdfc  vmovaps [rsp+0xD0], xmm14
00007dd8609dce05  vmovaps [rsp+0xE0], xmm15
00007dd8609dce0e  sub rsp, 0x30
00007dd8609dce12  movaps [rsp], xmm11
00007dd8609dce17  movaps [rsp+0x10], xmm10
00007dd8609dce1d  movaps [rsp+0x20], xmm6
00007dd8609dce22  lea rdi, [rsp]
00007dd8609dce26  mov esi, 0x00
00007dd8609dce2b  mov rax, 0x629C9CFA9530
00007dd8609dce35  call rax
00007dd8609dce37  movaps xmm11, [rsp]
00007dd8609dce3c  add rsp, 0x30
00007dd8609dce40  vmovaps xmm0, [rsp]
00007dd8609dce45  vmovaps xmm1, [rsp+0x10]
00007dd8609dce4b  vmovaps xmm2, [rsp+0x20]
00007dd8609dce51  vmovaps xmm3, [rsp+0x30]
00007dd8609dce57  vmovaps xmm4, [rsp+0x40]
00007dd8609dce5d  vmovaps xmm5, [rsp+0x50]
00007dd8609dce63  vmovaps xmm6, [rsp+0x60]
00007dd8609dce69  vmovaps xmm7, [rsp+0x70]
00007dd8609dce6f  vmovaps xmm8, [rsp+0x80]
00007dd8609dce78  vmovaps xmm9, [rsp+0x90]
00007dd8609dce81  vmovaps xmm10, [rsp+0xA0]
00007dd8609dce8a  vmovaps xmm12, [rsp+0xB0]
00007dd8609dce93  vmovaps xmm13, [rsp+0xC0]
00007dd8609dce9c  vmovaps xmm14, [rsp+0xD0]
00007dd8609dcea5  vmovaps xmm15, [rsp+0xE0]
00007dd8609dceae  add rsp, 0xF0
00007dd8609dceb5  pop r11
00007dd8609dceb7  pop r10
00007dd8609dceb9  pop r9
00007dd8609dcebb  pop r8
00007dd8609dcebd  pop rsi
00007dd8609dcebe  pop rdi
00007dd8609dcebf  pop rdx
00007dd8609dcec0  pop rcx
00007dd8609dcec1  pop rax
00007dd8609dcec2  add rsp, 0x08
00007dd8609dcec6  jmp 0x00007DD8609D954D
00007dd8609dcecb  sub rsp, 0x08
00007dd8609dcecf  push rax
00007dd8609dced0  push rcx
00007dd8609dced1  push rdx
00007dd8609dced2  push rdi
00007dd8609dced3  push rsi
00007dd8609dced4  push r8
00007dd8609dced6  push r9
00007dd8609dced8  push r10
00007dd8609dceda  push r11
00007dd8609dcedc  sub rsp, 0xF0
00007dd8609dcee3  vmovaps [rsp], xmm0
00007dd8609dcee8  vmovaps [rsp+0x10], xmm1
00007dd8609dceee  vmovaps [rsp+0x20], xmm2
00007dd8609dcef4  vmovaps [rsp+0x30], xmm3
00007dd8609dcefa  vmovaps [rsp+0x40], xmm4
00007dd8609dcf00  vmovaps [rsp+0x50], xmm5
00007dd8609dcf06  vmovaps [rsp+0x60], xmm6
00007dd8609dcf0c  vmovaps [rsp+0x70], xmm7
00007dd8609dcf12  vmovaps [rsp+0x80], xmm8
00007dd8609dcf1b  vmovaps [rsp+0x90], xmm9
00007dd8609dcf24  vmovaps [rsp+0xA0], xmm11
00007dd8609dcf2d  vmovaps [rsp+0xB0], xmm12
00007dd8609dcf36  vmovaps [rsp+0xC0], xmm13
00007dd8609dcf3f  vmovaps [rsp+0xD0], xmm14
00007dd8609dcf48  vmovaps [rsp+0xE0], xmm15
00007dd8609dcf51  sub rsp, 0x30
00007dd8609dcf55  movaps [rsp], xmm10
00007dd8609dcf5a  movaps [rsp+0x10], xmm14
00007dd8609dcf60  movaps [rsp+0x20], xmm4
00007dd8609dcf65  lea rdi, [rsp]
00007dd8609dcf69  mov esi, 0x00
00007dd8609dcf6e  mov rax, 0x629C9CFA9530
00007dd8609dcf78  call rax
00007dd8609dcf7a  movaps xmm10, [rsp]
00007dd8609dcf7f  add rsp, 0x30
00007dd8609dcf83  vmovaps xmm0, [rsp]
00007dd8609dcf88  vmovaps xmm1, [rsp+0x10]
00007dd8609dcf8e  vmovaps xmm2, [rsp+0x20]
00007dd8609dcf94  vmovaps xmm3, [rsp+0x30]
00007dd8609dcf9a  vmovaps xmm4, [rsp+0x40]
00007dd8609dcfa0  vmovaps xmm5, [rsp+0x50]
00007dd8609dcfa6  vmovaps xmm6, [rsp+0x60]
00007dd8609dcfac  vmovaps xmm7, [rsp+0x70]
00007dd8609dcfb2  vmovaps xmm8, [rsp+0x80]
00007dd8609dcfbb  vmovaps xmm9, [rsp+0x90]
00007dd8609dcfc4  vmovaps xmm11, [rsp+0xA0]
00007dd8609dcfcd  vmovaps xmm12, [rsp+0xB0]
00007dd8609dcfd6  vmovaps xmm13, [rsp+0xC0]
00007dd8609dcfdf  vmovaps xmm14, [rsp+0xD0]
00007dd8609dcfe8  vmovaps xmm15, [rsp+0xE0]
00007dd8609dcff1  add rsp, 0xF0
00007dd8609dcff8  pop r11
00007dd8609dcffa  pop r10
00007dd8609dcffc  pop r9
00007dd8609dcffe  pop r8
00007dd8609dd000  pop rsi
00007dd8609dd001  pop rdi
00007dd8609dd002  pop rdx
00007dd8609dd003  pop rcx
00007dd8609dd004  pop rax
00007dd8609dd005  add rsp, 0x08
00007dd8609dd009  jmp 0x00007DD8609D9568
00007dd8609dd00e  sub rsp, 0x08
00007dd8609dd012  push rax
00007dd8609dd013  push rcx
00007dd8609dd014  push rdx
00007dd8609dd015  push rdi
00007dd8609dd016  push rsi
00007dd8609dd017  push r8
00007dd8609dd019  push r9
00007dd8609dd01b  push r10
00007dd8609dd01d  push r11
00007dd8609dd01f  sub rsp, 0xF0
00007dd8609dd026  vmovaps [rsp], xmm0
00007dd8609dd02b  vmovaps [rsp+0x10], xmm1
00007dd8609dd031  vmovaps [rsp+0x20], xmm2
00007dd8609dd037  vmovaps [rsp+0x30], xmm3
00007dd8609dd03d  vmovaps [rsp+0x40], xmm4
00007dd8609dd043  vmovaps [rsp+0x50], xmm5
00007dd8609dd049  vmovaps [rsp+0x60], xmm6
00007dd8609dd04f  vmovaps [rsp+0x70], xmm7
00007dd8609dd055  vmovaps [rsp+0x80], xmm9
00007dd8609dd05e  vmovaps [rsp+0x90], xmm10
00007dd8609dd067  vmovaps [rsp+0xA0], xmm11
00007dd8609dd070  vmovaps [rsp+0xB0], xmm12
00007dd8609dd079  vmovaps [rsp+0xC0], xmm13
00007dd8609dd082  vmovaps [rsp+0xD0], xmm14
00007dd8609dd08b  vmovaps [rsp+0xE0], xmm15
00007dd8609dd094  sub rsp, 0x30
00007dd8609dd098  movaps [rsp], xmm8
00007dd8609dd09d  movaps [rsp+0x10], xmm1
00007dd8609dd0a2  movaps [rsp+0x20], xmm14
00007dd8609dd0a8  lea rdi, [rsp]
00007dd8609dd0ac  mov esi, 0x00
00007dd8609dd0b1  mov rax, 0x629C9CFA9530
00007dd8609dd0bb  call rax
00007dd8609dd0bd  movaps xmm8, [rsp]
00007dd8609dd0c2  add rsp, 0x30
00007dd8609dd0c6  vmovaps xmm0, [rsp]
00007dd8609dd0cb  vmovaps xmm1, [rsp+0x10]
00007dd8609dd0d1  vmovaps xmm2, [rsp+0x20]
00007dd8609dd0d7  vmovaps xmm3, [rsp+0x30]
00007dd8609dd0dd  vmovaps xmm4, [rsp+0x40]
00007dd8609dd0e3  vmovaps xmm5, [rsp+0x50]
00007dd8609dd0e9  vmovaps xmm6, [rsp+0x60]
00007dd8609dd0ef  vmovaps xmm7, [rsp+0x70]
00007dd8609dd0f5  vmovaps xmm9, [rsp+0x80]
00007dd8609dd0fe  vmovaps xmm10, [rsp+0x90]
00007dd8609dd107  vmovaps xmm11, [rsp+0xA0]
00007dd8609dd110  vmovaps xmm12, [rsp+0xB0]
00007dd8609dd119  vmovaps xmm13, [rsp+0xC0]
00007dd8609dd122  vmovaps xmm14, [rsp+0xD0]
00007dd8609dd12b  vmovaps xmm15, [rsp+0xE0]
00007dd8609dd134  add rsp, 0xF0
00007dd8609dd13b  pop r11
00007dd8609dd13d  pop r10
00007dd8609dd13f  pop r9
00007dd8609dd141  pop r8
00007dd8609dd143  pop rsi
00007dd8609dd144  pop rdi
00007dd8609dd145  pop rdx
00007dd8609dd146  pop rcx
00007dd8609dd147  pop rax
00007dd8609dd148  add rsp, 0x08
00007dd8609dd14c  jmp 0x00007DD8609D958E
00007dd8609dd151  sub rsp, 0x08
00007dd8609dd155  push rax
00007dd8609dd156  push rcx
00007dd8609dd157  push rdx
00007dd8609dd158  push rdi
00007dd8609dd159  push rsi
00007dd8609dd15a  push r8
00007dd8609dd15c  push r9
00007dd8609dd15e  push r10
00007dd8609dd160  push r11
00007dd8609dd162  sub rsp, 0xF0
00007dd8609dd169  vmovaps [rsp], xmm0
00007dd8609dd16e  vmovaps [rsp+0x10], xmm1
00007dd8609dd174  vmovaps [rsp+0x20], xmm2
00007dd8609dd17a  vmovaps [rsp+0x30], xmm3
00007dd8609dd180  vmovaps [rsp+0x40], xmm4
00007dd8609dd186  vmovaps [rsp+0x50], xmm5
00007dd8609dd18c  vmovaps [rsp+0x60], xmm7
00007dd8609dd192  vmovaps [rsp+0x70], xmm8
00007dd8609dd198  vmovaps [rsp+0x80], xmm9
00007dd8609dd1a1  vmovaps [rsp+0x90], xmm10
00007dd8609dd1aa  vmovaps [rsp+0xA0], xmm11
00007dd8609dd1b3  vmovaps [rsp+0xB0], xmm12
00007dd8609dd1bc  vmovaps [rsp+0xC0], xmm13
00007dd8609dd1c5  vmovaps [rsp+0xD0], xmm14
00007dd8609dd1ce  vmovaps [rsp+0xE0], xmm15
00007dd8609dd1d7  sub rsp, 0x30
00007dd8609dd1db  movaps [rsp], xmm6
00007dd8609dd1df  movaps [rsp+0x10], xmm1
00007dd8609dd1e4  movaps [rsp+0x20], xmm14
00007dd8609dd1ea  lea rdi, [rsp]
00007dd8609dd1ee  mov esi, 0x00
00007dd8609dd1f3  mov rax, 0x629C9CFA9530
00007dd8609dd1fd  call rax
00007dd8609dd1ff  movaps xmm6, [rsp]
00007dd8609dd203  add rsp, 0x30
00007dd8609dd207  vmovaps xmm0, [rsp]
00007dd8609dd20c  vmovaps xmm1, [rsp+0x10]
00007dd8609dd212  vmovaps xmm2, [rsp+0x20]
00007dd8609dd218  vmovaps xmm3, [rsp+0x30]
00007dd8609dd21e  vmovaps xmm4, [rsp+0x40]
00007dd8609dd224  vmovaps xmm5, [rsp+0x50]
00007dd8609dd22a  vmovaps xmm7, [rsp+0x60]
00007dd8609dd230  vmovaps xmm8, [rsp+0x70]
00007dd8609dd236  vmovaps xmm9, [rsp+0x80]
00007dd8609dd23f  vmovaps xmm10, [rsp+0x90]
00007dd8609dd248  vmovaps xmm11, [rsp+0xA0]
00007dd8609dd251  vmovaps xmm12, [rsp+0xB0]
00007dd8609dd25a  vmovaps xmm13, [rsp+0xC0]
00007dd8609dd263  vmovaps xmm14, [rsp+0xD0]
00007dd8609dd26c  vmovaps xmm15, [rsp+0xE0]
00007dd8609dd275  add rsp, 0xF0
00007dd8609dd27c  pop r11
00007dd8609dd27e  pop r10
00007dd8609dd280  pop r9
00007dd8609dd282  pop r8
00007dd8609dd284  pop rsi
00007dd8609dd285  pop rdi
00007dd8609dd286  pop rdx
00007dd8609dd287  pop rcx
00007dd8609dd288  pop rax
00007dd8609dd289  add rsp, 0x08
00007dd8609dd28d  jmp 0x00007DD8609D95BA
00007dd8609dd292  sub rsp, 0x08
00007dd8609dd296  push rax
00007dd8609dd297  push rcx
00007dd8609dd298  push rdx
00007dd8609dd299  push rdi
00007dd8609dd29a  push rsi
00007dd8609dd29b  push r8
00007dd8609dd29d  push r9
00007dd8609dd29f  push r10
00007dd8609dd2a1  push r11
00007dd8609dd2a3  sub rsp, 0xF0
00007dd8609dd2aa  vmovaps [rsp], xmm0
00007dd8609dd2af  vmovaps [rsp+0x10], xmm1
00007dd8609dd2b5  vmovaps [rsp+0x20], xmm2
00007dd8609dd2bb  vmovaps [rsp+0x30], xmm3
00007dd8609dd2c1  vmovaps [rsp+0x40], xmm4
00007dd8609dd2c7  vmovaps [rsp+0x50], xmm5
00007dd8609dd2cd  vmovaps [rsp+0x60], xmm6
00007dd8609dd2d3  vmovaps [rsp+0x70], xmm7
00007dd8609dd2d9  vmovaps [rsp+0x80], xmm8
00007dd8609dd2e2  vmovaps [rsp+0x90], xmm9
00007dd8609dd2eb  vmovaps [rsp+0xA0], xmm10
00007dd8609dd2f4  vmovaps [rsp+0xB0], xmm11
00007dd8609dd2fd  vmovaps [rsp+0xC0], xmm12
00007dd8609dd306  vmovaps [rsp+0xD0], xmm13
00007dd8609dd30f  vmovaps [rsp+0xE0], xmm15
00007dd8609dd318  sub rsp, 0x30
00007dd8609dd31c  movaps [rsp], xmm14
00007dd8609dd321  movaps [rsp+0x10], xmm12
00007dd8609dd327  movaps [rsp+0x20], xmm1
00007dd8609dd32c  lea rdi, [rsp]
00007dd8609dd330  mov esi, 0x00
00007dd8609dd335  mov rax, 0x629C9CFA9530
00007dd8609dd33f  call rax
00007dd8609dd341  movaps xmm14, [rsp]
00007dd8609dd346  add rsp, 0x30
00007dd8609dd34a  vmovaps xmm0, [rsp]
00007dd8609dd34f  vmovaps xmm1, [rsp+0x10]
00007dd8609dd355  vmovaps xmm2, [rsp+0x20]
00007dd8609dd35b  vmovaps xmm3, [rsp+0x30]
00007dd8609dd361  vmovaps xmm4, [rsp+0x40]
00007dd8609dd367  vmovaps xmm5, [rsp+0x50]
00007dd8609dd36d  vmovaps xmm6, [rsp+0x60]
00007dd8609dd373  vmovaps xmm7, [rsp+0x70]
00007dd8609dd379  vmovaps xmm8, [rsp+0x80]
00007dd8609dd382  vmovaps xmm9, [rsp+0x90]
00007dd8609dd38b  vmovaps xmm10, [rsp+0xA0]
00007dd8609dd394  vmovaps xmm11, [rsp+0xB0]
00007dd8609dd39d  vmovaps xmm12, [rsp+0xC0]
00007dd8609dd3a6  vmovaps xmm13, [rsp+0xD0]
00007dd8609dd3af  vmovaps xmm15, [rsp+0xE0]
00007dd8609dd3b8  add rsp, 0xF0
00007dd8609dd3bf  pop r11
00007dd8609dd3c1  pop r10
00007dd8609dd3c3  pop r9
00007dd8609dd3c5  pop r8
00007dd8609dd3c7  pop rsi
00007dd8609dd3c8  pop rdi
00007dd8609dd3c9  pop rdx
00007dd8609dd3ca  pop rcx
00007dd8609dd3cb  pop rax
00007dd8609dd3cc  add rsp, 0x08
00007dd8609dd3d0  jmp 0x00007DD8609D95E0
00007dd8609dd3d5  sub rsp, 0x08
00007dd8609dd3d9  push rax
00007dd8609dd3da  push rcx
00007dd8609dd3db  push rdx
00007dd8609dd3dc  push rdi
00007dd8609dd3dd  push rsi
00007dd8609dd3de  push r8
00007dd8609dd3e0  push r9
00007dd8609dd3e2  push r10
00007dd8609dd3e4  push r11
00007dd8609dd3e6  sub rsp, 0xF0
00007dd8609dd3ed  vmovaps [rsp], xmm0
00007dd8609dd3f2  vmovaps [rsp+0x10], xmm2
00007dd8609dd3f8  vmovaps [rsp+0x20], xmm3
00007dd8609dd3fe  vmovaps [rsp+0x30], xmm4
00007dd8609dd404  vmovaps [rsp+0x40], xmm5
00007dd8609dd40a  vmovaps [rsp+0x50], xmm6
00007dd8609dd410  vmovaps [rsp+0x60], xmm7
00007dd8609dd416  vmovaps [rsp+0x70], xmm8
00007dd8609dd41c  vmovaps [rsp+0x80], xmm9
00007dd8609dd425  vmovaps [rsp+0x90], xmm10
00007dd8609dd42e  vmovaps [rsp+0xA0], xmm11
00007dd8609dd437  vmovaps [rsp+0xB0], xmm12
00007dd8609dd440  vmovaps [rsp+0xC0], xmm13
00007dd8609dd449  vmovaps [rsp+0xD0], xmm14
00007dd8609dd452  vmovaps [rsp+0xE0], xmm15
00007dd8609dd45b  sub rsp, 0x30
00007dd8609dd45f  movaps [rsp], xmm1
00007dd8609dd463  movaps [rsp+0x10], xmm13
00007dd8609dd469  movaps [rsp+0x20], xmm9
00007dd8609dd46f  lea rdi, [rsp]
00007dd8609dd473  mov esi, 0x00
00007dd8609dd478  mov rax, 0x629C9CFA9530
00007dd8609dd482  call rax
00007dd8609dd484  movaps xmm1, [rsp]
00007dd8609dd488  add rsp, 0x30
00007dd8609dd48c  vmovaps xmm0, [rsp]
00007dd8609dd491  vmovaps xmm2, [rsp+0x10]
00007dd8609dd497  vmovaps xmm3, [rsp+0x20]
00007dd8609dd49d  vmovaps xmm4, [rsp+0x30]
00007dd8609dd4a3  vmovaps xmm5, [rsp+0x40]
00007dd8609dd4a9  vmovaps xmm6, [rsp+0x50]
00007dd8609dd4af  vmovaps xmm7, [rsp+0x60]
00007dd8609dd4b5  vmovaps xmm8, [rsp+0x70]
00007dd8609dd4bb  vmovaps xmm9, [rsp+0x80]
00007dd8609dd4c4  vmovaps xmm10, [rsp+0x90]
00007dd8609dd4cd  vmovaps xmm11, [rsp+0xA0]
00007dd8609dd4d6  vmovaps xmm12, [rsp+0xB0]
00007dd8609dd4df  vmovaps xmm13, [rsp+0xC0]
00007dd8609dd4e8  vmovaps xmm14, [rsp+0xD0]
00007dd8609dd4f1  vmovaps xmm15, [rsp+0xE0]
00007dd8609dd4fa  add rsp, 0xF0
00007dd8609dd501  pop r11
00007dd8609dd503  pop r10
00007dd8609dd505  pop r9
00007dd8609dd507  pop r8
00007dd8609dd509  pop rsi
00007dd8609dd50a  pop rdi
00007dd8609dd50b  pop rdx
00007dd8609dd50c  pop rcx
00007dd8609dd50d  pop rax
00007dd8609dd50e  add rsp, 0x08
00007dd8609dd512  jmp 0x00007DD8609D95FA
00007dd8609dd517  sub rsp, 0x08
00007dd8609dd51b  push rax
00007dd8609dd51c  push rcx
00007dd8609dd51d  push rdx
00007dd8609dd51e  push rdi
00007dd8609dd51f  push rsi
00007dd8609dd520  push r8
00007dd8609dd522  push r9
00007dd8609dd524  push r10
00007dd8609dd526  push r11
00007dd8609dd528  sub rsp, 0xF0
00007dd8609dd52f  vmovaps [rsp], xmm0
00007dd8609dd534  vmovaps [rsp+0x10], xmm1
00007dd8609dd53a  vmovaps [rsp+0x20], xmm2
00007dd8609dd540  vmovaps [rsp+0x30], xmm3
00007dd8609dd546  vmovaps [rsp+0x40], xmm4
00007dd8609dd54c  vmovaps [rsp+0x50], xmm5
00007dd8609dd552  vmovaps [rsp+0x60], xmm6
00007dd8609dd558  vmovaps [rsp+0x70], xmm7
00007dd8609dd55e  vmovaps [rsp+0x80], xmm8
00007dd8609dd567  vmovaps [rsp+0x90], xmm9
00007dd8609dd570  vmovaps [rsp+0xA0], xmm10
00007dd8609dd579  vmovaps [rsp+0xB0], xmm11
00007dd8609dd582  vmovaps [rsp+0xC0], xmm13
00007dd8609dd58b  vmovaps [rsp+0xD0], xmm14
00007dd8609dd594  vmovaps [rsp+0xE0], xmm15
00007dd8609dd59d  sub rsp, 0x30
00007dd8609dd5a1  movaps [rsp], xmm12
00007dd8609dd5a6  movaps [rsp+0x10], xmm7
00007dd8609dd5ab  movaps [rsp+0x20], xmm13
00007dd8609dd5b1  lea rdi, [rsp]
00007dd8609dd5b5  mov esi, 0x00
00007dd8609dd5ba  mov rax, 0x629C9CFA9530
00007dd8609dd5c4  call rax
00007dd8609dd5c6  movaps xmm12, [rsp]
00007dd8609dd5cb  add rsp, 0x30
00007dd8609dd5cf  vmovaps xmm0, [rsp]
00007dd8609dd5d4  vmovaps xmm1, [rsp+0x10]
00007dd8609dd5da  vmovaps xmm2, [rsp+0x20]
00007dd8609dd5e0  vmovaps xmm3, [rsp+0x30]
00007dd8609dd5e6  vmovaps xmm4, [rsp+0x40]
00007dd8609dd5ec  vmovaps xmm5, [rsp+0x50]
00007dd8609dd5f2  vmovaps xmm6, [rsp+0x60]
00007dd8609dd5f8  vmovaps xmm7, [rsp+0x70]
00007dd8609dd5fe  vmovaps xmm8, [rsp+0x80]
00007dd8609dd607  vmovaps xmm9, [rsp+0x90]
00007dd8609dd610  vmovaps xmm10, [rsp+0xA0]
00007dd8609dd619  vmovaps xmm11, [rsp+0xB0]
00007dd8609dd622  vmovaps xmm13, [rsp+0xC0]
00007dd8609dd62b  vmovaps xmm14, [rsp+0xD0]
00007dd8609dd634  vmovaps xmm15, [rsp+0xE0]
00007dd8609dd63d  add rsp, 0xF0
00007dd8609dd644  pop r11
00007dd8609dd646  pop r10
00007dd8609dd648  pop r9
00007dd8609dd64a  pop r8
00007dd8609dd64c  pop rsi
00007dd8609dd64d  pop rdi
00007dd8609dd64e  pop rdx
00007dd8609dd64f  pop rcx
00007dd8609dd650  pop rax
00007dd8609dd651  add rsp, 0x08
00007dd8609dd655  jmp 0x00007DD8609D9621
00007dd8609dd65a  sub rsp, 0x08
00007dd8609dd65e  push rax
00007dd8609dd65f  push rcx
00007dd8609dd660  push rdx
00007dd8609dd661  push rdi
00007dd8609dd662  push rsi
00007dd8609dd663  push r8
00007dd8609dd665  push r9
00007dd8609dd667  push r10
00007dd8609dd669  push r11
00007dd8609dd66b  sub rsp, 0xF0
00007dd8609dd672  vmovaps [rsp], xmm0
00007dd8609dd677  vmovaps [rsp+0x10], xmm1
00007dd8609dd67d  vmovaps [rsp+0x20], xmm2
00007dd8609dd683  vmovaps [rsp+0x30], xmm3
00007dd8609dd689  vmovaps [rsp+0x40], xmm4
00007dd8609dd68f  vmovaps [rsp+0x50], xmm5
00007dd8609dd695  vmovaps [rsp+0x60], xmm6
00007dd8609dd69b  vmovaps [rsp+0x70], xmm7
00007dd8609dd6a1  vmovaps [rsp+0x80], xmm8
00007dd8609dd6aa  vmovaps [rsp+0x90], xmm9
00007dd8609dd6b3  vmovaps [rsp+0xA0], xmm10
00007dd8609dd6bc  vmovaps [rsp+0xB0], xmm11
00007dd8609dd6c5  vmovaps [rsp+0xC0], xmm12
00007dd8609dd6ce  vmovaps [rsp+0xD0], xmm14
00007dd8609dd6d7  vmovaps [rsp+0xE0], xmm15
00007dd8609dd6e0  sub rsp, 0x30
00007dd8609dd6e4  movaps [rsp], xmm13
00007dd8609dd6e9  movaps [rsp+0x10], xmm15
00007dd8609dd6ef  movaps [rsp+0x20], xmm8
00007dd8609dd6f5  lea rdi, [rsp]
00007dd8609dd6f9  mov esi, 0x00
00007dd8609dd6fe  mov rax, 0x629C9CFA9530
00007dd8609dd708  call rax
00007dd8609dd70a  movaps xmm13, [rsp]
00007dd8609dd70f  add rsp, 0x30
00007dd8609dd713  vmovaps xmm0, [rsp]
00007dd8609dd718  vmovaps xmm1, [rsp+0x10]
00007dd8609dd71e  vmovaps xmm2, [rsp+0x20]
00007dd8609dd724  vmovaps xmm3, [rsp+0x30]
00007dd8609dd72a  vmovaps xmm4, [rsp+0x40]
00007dd8609dd730  vmovaps xmm5, [rsp+0x50]
00007dd8609dd736  vmovaps xmm6, [rsp+0x60]
00007dd8609dd73c  vmovaps xmm7, [rsp+0x70]
00007dd8609dd742  vmovaps xmm8, [rsp+0x80]
00007dd8609dd74b  vmovaps xmm9, [rsp+0x90]
00007dd8609dd754  vmovaps xmm10, [rsp+0xA0]
00007dd8609dd75d  vmovaps xmm11, [rsp+0xB0]
00007dd8609dd766  vmovaps xmm12, [rsp+0xC0]
00007dd8609dd76f  vmovaps xmm14, [rsp+0xD0]
00007dd8609dd778  vmovaps xmm15, [rsp+0xE0]
00007dd8609dd781  add rsp, 0xF0
00007dd8609dd788  pop r11
00007dd8609dd78a  pop r10
00007dd8609dd78c  pop r9
00007dd8609dd78e  pop r8
00007dd8609dd790  pop rsi
00007dd8609dd791  pop rdi
00007dd8609dd792  pop rdx
00007dd8609dd793  pop rcx
00007dd8609dd794  pop rax
00007dd8609dd795  add rsp, 0x08
00007dd8609dd799  jmp 0x00007DD8609D963C
00007dd8609dd79e  sub rsp, 0x08
00007dd8609dd7a2  push rax
00007dd8609dd7a3  push rcx
00007dd8609dd7a4  push rdx
00007dd8609dd7a5  push rdi
00007dd8609dd7a6  push rsi
00007dd8609dd7a7  push r8
00007dd8609dd7a9  push r9
00007dd8609dd7ab  push r10
00007dd8609dd7ad  push r11
00007dd8609dd7af  sub rsp, 0xF0
00007dd8609dd7b6  vmovaps [rsp], xmm0
00007dd8609dd7bb  vmovaps [rsp+0x10], xmm1
00007dd8609dd7c1  vmovaps [rsp+0x20], xmm2
00007dd8609dd7c7  vmovaps [rsp+0x30], xmm3
00007dd8609dd7cd  vmovaps [rsp+0x40], xmm4
00007dd8609dd7d3  vmovaps [rsp+0x50], xmm5
00007dd8609dd7d9  vmovaps [rsp+0x60], xmm6
00007dd8609dd7df  vmovaps [rsp+0x70], xmm7
00007dd8609dd7e5  vmovaps [rsp+0x80], xmm9
00007dd8609dd7ee  vmovaps [rsp+0x90], xmm10
00007dd8609dd7f7  vmovaps [rsp+0xA0], xmm11
00007dd8609dd800  vmovaps [rsp+0xB0], xmm12
00007dd8609dd809  vmovaps [rsp+0xC0], xmm13
00007dd8609dd812  vmovaps [rsp+0xD0], xmm14
00007dd8609dd81b  vmovaps [rsp+0xE0], xmm15
00007dd8609dd824  sub rsp, 0x30
00007dd8609dd828  movaps [rsp], xmm8
00007dd8609dd82d  movaps [rsp+0x10], xmm15
00007dd8609dd833  movaps [rsp+0x20], xmm9
00007dd8609dd839  lea rdi, [rsp]
00007dd8609dd83d  mov esi, 0x00
00007dd8609dd842  mov rax, 0x629C9CFA9530
00007dd8609dd84c  call rax
00007dd8609dd84e  movaps xmm8, [rsp]
00007dd8609dd853  add rsp, 0x30
00007dd8609dd857  vmovaps xmm0, [rsp]
00007dd8609dd85c  vmovaps xmm1, [rsp+0x10]
00007dd8609dd862  vmovaps xmm2, [rsp+0x20]
00007dd8609dd868  vmovaps xmm3, [rsp+0x30]
00007dd8609dd86e  vmovaps xmm4, [rsp+0x40]
00007dd8609dd874  vmovaps xmm5, [rsp+0x50]
00007dd8609dd87a  vmovaps xmm6, [rsp+0x60]
00007dd8609dd880  vmovaps xmm7, [rsp+0x70]
00007dd8609dd886  vmovaps xmm9, [rsp+0x80]
00007dd8609dd88f  vmovaps xmm10, [rsp+0x90]
00007dd8609dd898  vmovaps xmm11, [rsp+0xA0]
00007dd8609dd8a1  vmovaps xmm12, [rsp+0xB0]
00007dd8609dd8aa  vmovaps xmm13, [rsp+0xC0]
00007dd8609dd8b3  vmovaps xmm14, [rsp+0xD0]
00007dd8609dd8bc  vmovaps xmm15, [rsp+0xE0]
00007dd8609dd8c5  add rsp, 0xF0
00007dd8609dd8cc  pop r11
00007dd8609dd8ce  pop r10
00007dd8609dd8d0  pop r9
00007dd8609dd8d2  pop r8
00007dd8609dd8d4  pop rsi
00007dd8609dd8d5  pop rdi
00007dd8609dd8d6  pop rdx
00007dd8609dd8d7  pop rcx
00007dd8609dd8d8  pop rax
00007dd8609dd8d9  add rsp, 0x08
00007dd8609dd8dd  jmp 0x00007DD8609D966A
00007dd8609dd8e2  sub rsp, 0x08
00007dd8609dd8e6  push rax
00007dd8609dd8e7  push rcx
00007dd8609dd8e8  push rdx
00007dd8609dd8e9  push rdi
00007dd8609dd8ea  push rsi
00007dd8609dd8eb  push r8
00007dd8609dd8ed  push r9
00007dd8609dd8ef  push r10
00007dd8609dd8f1  push r11
00007dd8609dd8f3  sub rsp, 0xF0
00007dd8609dd8fa  vmovaps [rsp], xmm0
00007dd8609dd8ff  vmovaps [rsp+0x10], xmm1
00007dd8609dd905  vmovaps [rsp+0x20], xmm2
00007dd8609dd90b  vmovaps [rsp+0x30], xmm3
00007dd8609dd911  vmovaps [rsp+0x40], xmm4
00007dd8609dd917  vmovaps [rsp+0x50], xmm5
00007dd8609dd91d  vmovaps [rsp+0x60], xmm6
00007dd8609dd923  vmovaps [rsp+0x70], xmm7
00007dd8609dd929  vmovaps [rsp+0x80], xmm8
00007dd8609dd932  vmovaps [rsp+0x90], xmm9
00007dd8609dd93b  vmovaps [rsp+0xA0], xmm10
00007dd8609dd944  vmovaps [rsp+0xB0], xmm11
00007dd8609dd94d  vmovaps [rsp+0xC0], xmm12
00007dd8609dd956  vmovaps [rsp+0xD0], xmm13
00007dd8609dd95f  vmovaps [rsp+0xE0], xmm14
00007dd8609dd968  sub rsp, 0x30
00007dd8609dd96c  movaps [rsp], xmm15
00007dd8609dd971  movaps [rsp+0x10], xmm11
00007dd8609dd977  movaps [rsp+0x20], xmm6
00007dd8609dd97c  lea rdi, [rsp]
00007dd8609dd980  mov esi, 0x00
00007dd8609dd985  mov rax, 0x629C9CFA9530
00007dd8609dd98f  call rax
00007dd8609dd991  movaps xmm15, [rsp]
00007dd8609dd996  add rsp, 0x30
00007dd8609dd99a  vmovaps xmm0, [rsp]
00007dd8609dd99f  vmovaps xmm1, [rsp+0x10]
00007dd8609dd9a5  vmovaps xmm2, [rsp+0x20]
00007dd8609dd9ab  vmovaps xmm3, [rsp+0x30]
00007dd8609dd9b1  vmovaps xmm4, [rsp+0x40]
00007dd8609dd9b7  vmovaps xmm5, [rsp+0x50]
00007dd8609dd9bd  vmovaps xmm6, [rsp+0x60]
00007dd8609dd9c3  vmovaps xmm7, [rsp+0x70]
00007dd8609dd9c9  vmovaps xmm8, [rsp+0x80]
00007dd8609dd9d2  vmovaps xmm9, [rsp+0x90]
00007dd8609dd9db  vmovaps xmm10, [rsp+0xA0]
00007dd8609dd9e4  vmovaps xmm11, [rsp+0xB0]
00007dd8609dd9ed  vmovaps xmm12, [rsp+0xC0]
00007dd8609dd9f6  vmovaps xmm13, [rsp+0xD0]
00007dd8609dd9ff  vmovaps xmm14, [rsp+0xE0]
00007dd8609dda08  add rsp, 0xF0
00007dd8609dda0f  pop r11
00007dd8609dda11  pop r10
00007dd8609dda13  pop r9
00007dd8609dda15  pop r8
00007dd8609dda17  pop rsi
00007dd8609dda18  pop rdi
00007dd8609dda19  pop rdx
00007dd8609dda1a  pop rcx
00007dd8609dda1b  pop rax
00007dd8609dda1c  add rsp, 0x08
00007dd8609dda20  jmp 0x00007DD8609D9685
00007dd8609dda25  sub rsp, 0x08
00007dd8609dda29  push rax
00007dd8609dda2a  push rcx
00007dd8609dda2b  push rdx
00007dd8609dda2c  push rdi
00007dd8609dda2d  push rsi
00007dd8609dda2e  push r8
00007dd8609dda30  push r9
00007dd8609dda32  push r10
00007dd8609dda34  push r11
00007dd8609dda36  sub rsp, 0xF0
00007dd8609dda3d  vmovaps [rsp], xmm0
00007dd8609dda42  vmovaps [rsp+0x10], xmm1
00007dd8609dda48  vmovaps [rsp+0x20], xmm2
00007dd8609dda4e  vmovaps [rsp+0x30], xmm3
00007dd8609dda54  vmovaps [rsp+0x40], xmm4
00007dd8609dda5a  vmovaps [rsp+0x50], xmm5
00007dd8609dda60  vmovaps [rsp+0x60], xmm6
00007dd8609dda66  vmovaps [rsp+0x70], xmm8
00007dd8609dda6c  vmovaps [rsp+0x80], xmm9
00007dd8609dda75  vmovaps [rsp+0x90], xmm10
00007dd8609dda7e  vmovaps [rsp+0xA0], xmm11
00007dd8609dda87  vmovaps [rsp+0xB0], xmm12
00007dd8609dda90  vmovaps [rsp+0xC0], xmm13
00007dd8609dda99  vmovaps [rsp+0xD0], xmm14
00007dd8609ddaa2  vmovaps [rsp+0xE0], xmm15
00007dd8609ddaab  sub rsp, 0x30
00007dd8609ddaaf  movaps [rsp], xmm7
00007dd8609ddab3  movaps [rsp+0x10], xmm11
00007dd8609ddab9  movaps [rsp+0x20], xmm9
00007dd8609ddabf  lea rdi, [rsp]
00007dd8609ddac3  mov esi, 0x00
00007dd8609ddac8  mov rax, 0x629C9CFA9530
00007dd8609ddad2  call rax
00007dd8609ddad4  movaps xmm7, [rsp]
00007dd8609ddad8  add rsp, 0x30
00007dd8609ddadc  vmovaps xmm0, [rsp]
00007dd8609ddae1  vmovaps xmm1, [rsp+0x10]
00007dd8609ddae7  vmovaps xmm2, [rsp+0x20]
00007dd8609ddaed  vmovaps xmm3, [rsp+0x30]
00007dd8609ddaf3  vmovaps xmm4, [rsp+0x40]
00007dd8609ddaf9  vmovaps xmm5, [rsp+0x50]
00007dd8609ddaff  vmovaps xmm6, [rsp+0x60]
00007dd8609ddb05  vmovaps xmm8, [rsp+0x70]
00007dd8609ddb0b  vmovaps xmm9, [rsp+0x80]
00007dd8609ddb14  vmovaps xmm10, [rsp+0x90]
00007dd8609ddb1d  vmovaps xmm11, [rsp+0xA0]
00007dd8609ddb26  vmovaps xmm12, [rsp+0xB0]
00007dd8609ddb2f  vmovaps xmm13, [rsp+0xC0]
00007dd8609ddb38  vmovaps xmm14, [rsp+0xD0]
00007dd8609ddb41  vmovaps xmm15, [rsp+0xE0]
00007dd8609ddb4a  add rsp, 0xF0
00007dd8609ddb51  pop r11
00007dd8609ddb53  pop r10
00007dd8609ddb55  pop r9
00007dd8609ddb57  pop r8
00007dd8609ddb59  pop rsi
00007dd8609ddb5a  pop rdi
00007dd8609ddb5b  pop rdx
00007dd8609ddb5c  pop rcx
00007dd8609ddb5d  pop rax
00007dd8609ddb5e  add rsp, 0x08
00007dd8609ddb62  jmp 0x00007DD8609D96B2
00007dd8609ddb67  sub rsp, 0x08
00007dd8609ddb6b  push rax
00007dd8609ddb6c  push rcx
00007dd8609ddb6d  push rdx
00007dd8609ddb6e  push rdi
00007dd8609ddb6f  push rsi
00007dd8609ddb70  push r8
00007dd8609ddb72  push r9
00007dd8609ddb74  push r10
00007dd8609ddb76  push r11
00007dd8609ddb78  sub rsp, 0xF0
00007dd8609ddb7f  vmovaps [rsp], xmm0
00007dd8609ddb84  vmovaps [rsp+0x10], xmm1
00007dd8609ddb8a  vmovaps [rsp+0x20], xmm2
00007dd8609ddb90  vmovaps [rsp+0x30], xmm3
00007dd8609ddb96  vmovaps [rsp+0x40], xmm4
00007dd8609ddb9c  vmovaps [rsp+0x50], xmm5
00007dd8609ddba2  vmovaps [rsp+0x60], xmm6
00007dd8609ddba8  vmovaps [rsp+0x70], xmm7
00007dd8609ddbae  vmovaps [rsp+0x80], xmm8
00007dd8609ddbb7  vmovaps [rsp+0x90], xmm9
00007dd8609ddbc0  vmovaps [rsp+0xA0], xmm10
00007dd8609ddbc9  vmovaps [rsp+0xB0], xmm12
00007dd8609ddbd2  vmovaps [rsp+0xC0], xmm13
00007dd8609ddbdb  vmovaps [rsp+0xD0], xmm14
00007dd8609ddbe4  vmovaps [rsp+0xE0], xmm15
00007dd8609ddbed  sub rsp, 0x30
00007dd8609ddbf1  movaps [rsp], xmm11
00007dd8609ddbf6  movaps [rsp+0x10], xmm10
00007dd8609ddbfc  movaps [rsp+0x20], xmm14
00007dd8609ddc02  lea rdi, [rsp]
00007dd8609ddc06  mov esi, 0x00
00007dd8609ddc0b  mov rax, 0x629C9CFA9530
00007dd8609ddc15  call rax
00007dd8609ddc17  movaps xmm11, [rsp]
00007dd8609ddc1c  add rsp, 0x30
00007dd8609ddc20  vmovaps xmm0, [rsp]
00007dd8609ddc25  vmovaps xmm1, [rsp+0x10]
00007dd8609ddc2b  vmovaps xmm2, [rsp+0x20]
00007dd8609ddc31  vmovaps xmm3, [rsp+0x30]
00007dd8609ddc37  vmovaps xmm4, [rsp+0x40]
00007dd8609ddc3d  vmovaps xmm5, [rsp+0x50]
00007dd8609ddc43  vmovaps xmm6, [rsp+0x60]
00007dd8609ddc49  vmovaps xmm7, [rsp+0x70]
00007dd8609ddc4f  vmovaps xmm8, [rsp+0x80]
00007dd8609ddc58  vmovaps xmm9, [rsp+0x90]
00007dd8609ddc61  vmovaps xmm10, [rsp+0xA0]
00007dd8609ddc6a  vmovaps xmm12, [rsp+0xB0]
00007dd8609ddc73  vmovaps xmm13, [rsp+0xC0]
00007dd8609ddc7c  vmovaps xmm14, [rsp+0xD0]
00007dd8609ddc85  vmovaps xmm15, [rsp+0xE0]
00007dd8609ddc8e  add rsp, 0xF0
00007dd8609ddc95  pop r11
00007dd8609ddc97  pop r10
00007dd8609ddc99  pop r9
00007dd8609ddc9b  pop r8
00007dd8609ddc9d  pop rsi
00007dd8609ddc9e  pop rdi
00007dd8609ddc9f  pop rdx
00007dd8609ddca0  pop rcx
00007dd8609ddca1  pop rax
00007dd8609ddca2  add rsp, 0x08
00007dd8609ddca6  jmp 0x00007DD8609D96CD
00007dd8609ddcab  call 0x00007DD8608E45A0
00007dd8609ddcb0  jmp 0x00007DD8609D96D7
00007dd8609ddcb5  sub rsp, 0x08
00007dd8609ddcb9  push rax
00007dd8609ddcba  push rcx
00007dd8609ddcbb  push rdx
00007dd8609ddcbc  push rdi
00007dd8609ddcbd  push rsi
00007dd8609ddcbe  push r8
00007dd8609ddcc0  push r9
00007dd8609ddcc2  push r10
00007dd8609ddcc4  push r11
00007dd8609ddcc6  sub rsp, 0xF0
00007dd8609ddccd  vmovaps [rsp], xmm0
00007dd8609ddcd2  vmovaps [rsp+0x10], xmm1
00007dd8609ddcd8  vmovaps [rsp+0x20], xmm2
00007dd8609ddcde  vmovaps [rsp+0x30], xmm3
00007dd8609ddce4  vmovaps [rsp+0x40], xmm4
00007dd8609ddcea  vmovaps [rsp+0x50], xmm5
00007dd8609ddcf0  vmovaps [rsp+0x60], xmm6
00007dd8609ddcf6  vmovaps [rsp+0x70], xmm7
00007dd8609ddcfc  vmovaps [rsp+0x80], xmm8
00007dd8609ddd05  vmovaps [rsp+0x90], xmm9
00007dd8609ddd0e  vmovaps [rsp+0xA0], xmm11
00007dd8609ddd17  vmovaps [rsp+0xB0], xmm12
00007dd8609ddd20  vmovaps [rsp+0xC0], xmm13
00007dd8609ddd29  vmovaps [rsp+0xD0], xmm14
00007dd8609ddd32  vmovaps [rsp+0xE0], xmm15
00007dd8609ddd3b  sub rsp, 0x30
00007dd8609ddd3f  movaps [rsp], xmm10
00007dd8609ddd44  movaps [rsp+0x10], xmm1
00007dd8609ddd49  movaps [rsp+0x20], xmm12
00007dd8609ddd4f  lea rdi, [rsp]
00007dd8609ddd53  mov esi, 0x00
00007dd8609ddd58  mov rax, 0x629C9CFA9530
00007dd8609ddd62  call rax
00007dd8609ddd64  movaps xmm10, [rsp]
00007dd8609ddd69  add rsp, 0x30
00007dd8609ddd6d  vmovaps xmm0, [rsp]
00007dd8609ddd72  vmovaps xmm1, [rsp+0x10]
00007dd8609ddd78  vmovaps xmm2, [rsp+0x20]
00007dd8609ddd7e  vmovaps xmm3, [rsp+0x30]
00007dd8609ddd84  vmovaps xmm4, [rsp+0x40]
00007dd8609ddd8a  vmovaps xmm5, [rsp+0x50]
00007dd8609ddd90  vmovaps xmm6, [rsp+0x60]
00007dd8609ddd96  vmovaps xmm7, [rsp+0x70]
00007dd8609ddd9c  vmovaps xmm8, [rsp+0x80]
00007dd8609ddda5  vmovaps xmm9, [rsp+0x90]
00007dd8609dddae  vmovaps xmm11, [rsp+0xA0]
00007dd8609dddb7  vmovaps xmm12, [rsp+0xB0]
00007dd8609dddc0  vmovaps xmm13, [rsp+0xC0]
00007dd8609dddc9  vmovaps xmm14, [rsp+0xD0]
00007dd8609dddd2  vmovaps xmm15, [rsp+0xE0]
00007dd8609ddddb  add rsp, 0xF0
00007dd8609ddde2  pop r11
00007dd8609ddde4  pop r10
00007dd8609ddde6  pop r9
00007dd8609ddde8  pop r8
00007dd8609dddea  pop rsi
00007dd8609dddeb  pop rdi
00007dd8609dddec  pop rdx
00007dd8609ddded  pop rcx
00007dd8609dddee  pop rax
00007dd8609dddef  add rsp, 0x08
00007dd8609dddf3  jmp 0x00007DD8609D96FA
00007dd8609dddf8  sub rsp, 0x08
00007dd8609dddfc  push rax
00007dd8609dddfd  push rcx
00007dd8609dddfe  push rdx
00007dd8609dddff  push rdi
00007dd8609dde00  push rsi
00007dd8609dde01  push r8
00007dd8609dde03  push r9
00007dd8609dde05  push r10
00007dd8609dde07  push r11
00007dd8609dde09  sub rsp, 0xF0
00007dd8609dde10  vmovaps [rsp], xmm0
00007dd8609dde15  vmovaps [rsp+0x10], xmm1
00007dd8609dde1b  vmovaps [rsp+0x20], xmm2
00007dd8609dde21  vmovaps [rsp+0x30], xmm3
00007dd8609dde27  vmovaps [rsp+0x40], xmm4
00007dd8609dde2d  vmovaps [rsp+0x50], xmm5
00007dd8609dde33  vmovaps [rsp+0x60], xmm6
00007dd8609dde39  vmovaps [rsp+0x70], xmm7
00007dd8609dde3f  vmovaps [rsp+0x80], xmm8
00007dd8609dde48  vmovaps [rsp+0x90], xmm9
00007dd8609dde51  vmovaps [rsp+0xA0], xmm10
00007dd8609dde5a  vmovaps [rsp+0xB0], xmm11
00007dd8609dde63  vmovaps [rsp+0xC0], xmm13
00007dd8609dde6c  vmovaps [rsp+0xD0], xmm14
00007dd8609dde75  vmovaps [rsp+0xE0], xmm15
00007dd8609dde7e  sub rsp, 0x30
00007dd8609dde82  movaps [rsp], xmm12
00007dd8609dde87  movaps [rsp+0x10], xmm14
00007dd8609dde8d  movaps [rsp+0x20], xmm1
00007dd8609dde92  lea rdi, [rsp]
00007dd8609dde96  mov esi, 0x00
00007dd8609dde9b  mov rax, 0x629C9CFA9530
00007dd8609ddea5  call rax
00007dd8609ddea7  movaps xmm12, [rsp]
00007dd8609ddeac  add rsp, 0x30
00007dd8609ddeb0  vmovaps xmm0, [rsp]
00007dd8609ddeb5  vmovaps xmm1, [rsp+0x10]
00007dd8609ddebb  vmovaps xmm2, [rsp+0x20]
00007dd8609ddec1  vmovaps xmm3, [rsp+0x30]
00007dd8609ddec7  vmovaps xmm4, [rsp+0x40]
00007dd8609ddecd  vmovaps xmm5, [rsp+0x50]
00007dd8609dded3  vmovaps xmm6, [rsp+0x60]
00007dd8609dded9  vmovaps xmm7, [rsp+0x70]
00007dd8609ddedf  vmovaps xmm8, [rsp+0x80]
00007dd8609ddee8  vmovaps xmm9, [rsp+0x90]
00007dd8609ddef1  vmovaps xmm10, [rsp+0xA0]
00007dd8609ddefa  vmovaps xmm11, [rsp+0xB0]
00007dd8609ddf03  vmovaps xmm13, [rsp+0xC0]
00007dd8609ddf0c  vmovaps xmm14, [rsp+0xD0]
00007dd8609ddf15  vmovaps xmm15, [rsp+0xE0]
00007dd8609ddf1e  add rsp, 0xF0
00007dd8609ddf25  pop r11
00007dd8609ddf27  pop r10
00007dd8609ddf29  pop r9
00007dd8609ddf2b  pop r8
00007dd8609ddf2d  pop rsi
00007dd8609ddf2e  pop rdi
00007dd8609ddf2f  pop rdx
00007dd8609ddf30  pop rcx
00007dd8609ddf31  pop rax
00007dd8609ddf32  add rsp, 0x08
00007dd8609ddf36  jmp 0x00007DD8609D9729
00007dd8609ddf3b  sub rsp, 0x08
00007dd8609ddf3f  push rax
00007dd8609ddf40  push rcx
00007dd8609ddf41  push rdx
00007dd8609ddf42  push rdi
00007dd8609ddf43  push rsi
00007dd8609ddf44  push r8
00007dd8609ddf46  push r9
00007dd8609ddf48  push r10
00007dd8609ddf4a  push r11
00007dd8609ddf4c  sub rsp, 0xF0
00007dd8609ddf53  vmovaps [rsp], xmm0
00007dd8609ddf58  vmovaps [rsp+0x10], xmm1
00007dd8609ddf5e  vmovaps [rsp+0x20], xmm2
00007dd8609ddf64  vmovaps [rsp+0x30], xmm3
00007dd8609ddf6a  vmovaps [rsp+0x40], xmm4
00007dd8609ddf70  vmovaps [rsp+0x50], xmm5
00007dd8609ddf76  vmovaps [rsp+0x60], xmm6
00007dd8609ddf7c  vmovaps [rsp+0x70], xmm7
00007dd8609ddf82  vmovaps [rsp+0x80], xmm8
00007dd8609ddf8b  vmovaps [rsp+0x90], xmm9
00007dd8609ddf94  vmovaps [rsp+0xA0], xmm10
00007dd8609ddf9d  vmovaps [rsp+0xB0], xmm11
00007dd8609ddfa6  vmovaps [rsp+0xC0], xmm12
00007dd8609ddfaf  vmovaps [rsp+0xD0], xmm13
00007dd8609ddfb8  vmovaps [rsp+0xE0], xmm15
00007dd8609ddfc1  sub rsp, 0x30
00007dd8609ddfc5  movaps [rsp], xmm14
00007dd8609ddfca  movaps [rsp+0x10], xmm9
00007dd8609ddfd0  movaps [rsp+0x20], xmm1
00007dd8609ddfd5  lea rdi, [rsp]
00007dd8609ddfd9  mov esi, 0x00
00007dd8609ddfde  mov rax, 0x629C9CFA9530
00007dd8609ddfe8  call rax
00007dd8609ddfea  movaps xmm14, [rsp]
00007dd8609ddfef  add rsp, 0x30
00007dd8609ddff3  vmovaps xmm0, [rsp]
00007dd8609ddff8  vmovaps xmm1, [rsp+0x10]
00007dd8609ddffe  vmovaps xmm2, [rsp+0x20]
00007dd8609de004  vmovaps xmm3, [rsp+0x30]
00007dd8609de00a  vmovaps xmm4, [rsp+0x40]
00007dd8609de010  vmovaps xmm5, [rsp+0x50]
00007dd8609de016  vmovaps xmm6, [rsp+0x60]
00007dd8609de01c  vmovaps xmm7, [rsp+0x70]
00007dd8609de022  vmovaps xmm8, [rsp+0x80]
00007dd8609de02b  vmovaps xmm9, [rsp+0x90]
00007dd8609de034  vmovaps xmm10, [rsp+0xA0]
00007dd8609de03d  vmovaps xmm11, [rsp+0xB0]
00007dd8609de046  vmovaps xmm12, [rsp+0xC0]
00007dd8609de04f  vmovaps xmm13, [rsp+0xD0]
00007dd8609de058  vmovaps xmm15, [rsp+0xE0]
00007dd8609de061  add rsp, 0xF0
00007dd8609de068  pop r11
00007dd8609de06a  pop r10
00007dd8609de06c  pop r9
00007dd8609de06e  pop r8
00007dd8609de070  pop rsi
00007dd8609de071  pop rdi
00007dd8609de072  pop rdx
00007dd8609de073  pop rcx
00007dd8609de074  pop rax
00007dd8609de075  add rsp, 0x08
00007dd8609de079  jmp 0x00007DD8609D9758
00007dd8609de07e  sub rsp, 0x08
00007dd8609de082  push rax
00007dd8609de083  push rcx
00007dd8609de084  push rdx
00007dd8609de085  push rdi
00007dd8609de086  push rsi
00007dd8609de087  push r8
00007dd8609de089  push r9
00007dd8609de08b  push r10
00007dd8609de08d  push r11
00007dd8609de08f  sub rsp, 0xF0
00007dd8609de096  vmovaps [rsp], xmm0
00007dd8609de09b  vmovaps [rsp+0x10], xmm2
00007dd8609de0a1  vmovaps [rsp+0x20], xmm3
00007dd8609de0a7  vmovaps [rsp+0x30], xmm4
00007dd8609de0ad  vmovaps [rsp+0x40], xmm5
00007dd8609de0b3  vmovaps [rsp+0x50], xmm6
00007dd8609de0b9  vmovaps [rsp+0x60], xmm7
00007dd8609de0bf  vmovaps [rsp+0x70], xmm8
00007dd8609de0c5  vmovaps [rsp+0x80], xmm9
00007dd8609de0ce  vmovaps [rsp+0x90], xmm10
00007dd8609de0d7  vmovaps [rsp+0xA0], xmm11
00007dd8609de0e0  vmovaps [rsp+0xB0], xmm12
00007dd8609de0e9  vmovaps [rsp+0xC0], xmm13
00007dd8609de0f2  vmovaps [rsp+0xD0], xmm14
00007dd8609de0fb  vmovaps [rsp+0xE0], xmm15
00007dd8609de104  sub rsp, 0x30
00007dd8609de108  movaps [rsp], xmm1
00007dd8609de10c  movaps [rsp+0x10], xmm13
00007dd8609de112  movaps [rsp+0x20], xmm8
00007dd8609de118  lea rdi, [rsp]
00007dd8609de11c  mov esi, 0x00
00007dd8609de121  mov rax, 0x629C9CFA9530
00007dd8609de12b  call rax
00007dd8609de12d  movaps xmm1, [rsp]
00007dd8609de131  add rsp, 0x30
00007dd8609de135  vmovaps xmm0, [rsp]
00007dd8609de13a  vmovaps xmm2, [rsp+0x10]
00007dd8609de140  vmovaps xmm3, [rsp+0x20]
00007dd8609de146  vmovaps xmm4, [rsp+0x30]
00007dd8609de14c  vmovaps xmm5, [rsp+0x40]
00007dd8609de152  vmovaps xmm6, [rsp+0x50]
00007dd8609de158  vmovaps xmm7, [rsp+0x60]
00007dd8609de15e  vmovaps xmm8, [rsp+0x70]
00007dd8609de164  vmovaps xmm9, [rsp+0x80]
00007dd8609de16d  vmovaps xmm10, [rsp+0x90]
00007dd8609de176  vmovaps xmm11, [rsp+0xA0]
00007dd8609de17f  vmovaps xmm12, [rsp+0xB0]
00007dd8609de188  vmovaps xmm13, [rsp+0xC0]
00007dd8609de191  vmovaps xmm14, [rsp+0xD0]
00007dd8609de19a  vmovaps xmm15, [rsp+0xE0]
00007dd8609de1a3  add rsp, 0xF0
00007dd8609de1aa  pop r11
00007dd8609de1ac  pop r10
00007dd8609de1ae  pop r9
00007dd8609de1b0  pop r8
00007dd8609de1b2  pop rsi
00007dd8609de1b3  pop rdi
00007dd8609de1b4  pop rdx
00007dd8609de1b5  pop rcx
00007dd8609de1b6  pop rax
00007dd8609de1b7  add rsp, 0x08
00007dd8609de1bb  jmp 0x00007DD8609D977A
00007dd8609de1c0  call 0x00007DD86080C260
00007dd8609de1c5  jmp 0x00007DD8609D9788
00007dd8609de1ca  call 0x00007DD8608DE950
00007dd8609de1cf  jmp 0x00007DD8609D9792
00007dd8609de1d4  sub rsp, 0x08
00007dd8609de1d8  push rax
00007dd8609de1d9  push rcx
00007dd8609de1da  push rdx
00007dd8609de1db  push rdi
00007dd8609de1dc  push rsi
00007dd8609de1dd  push r8
00007dd8609de1df  push r9
00007dd8609de1e1  push r10
00007dd8609de1e3  push r11
00007dd8609de1e5  sub rsp, 0xF0
00007dd8609de1ec  vmovaps [rsp], xmm0
00007dd8609de1f1  vmovaps [rsp+0x10], xmm1
00007dd8609de1f7  vmovaps [rsp+0x20], xmm2
00007dd8609de1fd  vmovaps [rsp+0x30], xmm3
00007dd8609de203  vmovaps [rsp+0x40], xmm4
00007dd8609de209  vmovaps [rsp+0x50], xmm5
00007dd8609de20f  vmovaps [rsp+0x60], xmm6
00007dd8609de215  vmovaps [rsp+0x70], xmm7
00007dd8609de21b  vmovaps [rsp+0x80], xmm9
00007dd8609de224  vmovaps [rsp+0x90], xmm10
00007dd8609de22d  vmovaps [rsp+0xA0], xmm11
00007dd8609de236  vmovaps [rsp+0xB0], xmm12
00007dd8609de23f  vmovaps [rsp+0xC0], xmm13
00007dd8609de248  vmovaps [rsp+0xD0], xmm14
00007dd8609de251  vmovaps [rsp+0xE0], xmm15
00007dd8609de25a  sub rsp, 0x30
00007dd8609de25e  movaps [rsp], xmm8
00007dd8609de263  movaps [rsp+0x10], xmm15
00007dd8609de269  movaps [rsp+0x20], xmm7
00007dd8609de26e  lea rdi, [rsp]
00007dd8609de272  mov esi, 0x00
00007dd8609de277  mov rax, 0x629C9CFA9530
00007dd8609de281  call rax
00007dd8609de283  movaps xmm8, [rsp]
00007dd8609de288  add rsp, 0x30
00007dd8609de28c  vmovaps xmm0, [rsp]
00007dd8609de291  vmovaps xmm1, [rsp+0x10]
00007dd8609de297  vmovaps xmm2, [rsp+0x20]
00007dd8609de29d  vmovaps xmm3, [rsp+0x30]
00007dd8609de2a3  vmovaps xmm4, [rsp+0x40]
00007dd8609de2a9  vmovaps xmm5, [rsp+0x50]
00007dd8609de2af  vmovaps xmm6, [rsp+0x60]
00007dd8609de2b5  vmovaps xmm7, [rsp+0x70]
00007dd8609de2bb  vmovaps xmm9, [rsp+0x80]
00007dd8609de2c4  vmovaps xmm10, [rsp+0x90]
00007dd8609de2cd  vmovaps xmm11, [rsp+0xA0]
00007dd8609de2d6  vmovaps xmm12, [rsp+0xB0]
00007dd8609de2df  vmovaps xmm13, [rsp+0xC0]
00007dd8609de2e8  vmovaps xmm14, [rsp+0xD0]
00007dd8609de2f1  vmovaps xmm15, [rsp+0xE0]
00007dd8609de2fa  add rsp, 0xF0
00007dd8609de301  pop r11
00007dd8609de303  pop r10
00007dd8609de305  pop r9
00007dd8609de307  pop r8
00007dd8609de309  pop rsi
00007dd8609de30a  pop rdi
00007dd8609de30b  pop rdx
00007dd8609de30c  pop rcx
00007dd8609de30d  pop rax
00007dd8609de30e  add rsp, 0x08
00007dd8609de312  jmp 0x00007DD8609D97B4
00007dd8609de317  sub rsp, 0x08
00007dd8609de31b  push rax
00007dd8609de31c  push rcx
00007dd8609de31d  push rdx
00007dd8609de31e  push rdi
00007dd8609de31f  push rsi
00007dd8609de320  push r8
00007dd8609de322  push r9
00007dd8609de324  push r10
00007dd8609de326  push r11
00007dd8609de328  sub rsp, 0xF0
00007dd8609de32f  vmovaps [rsp], xmm0
00007dd8609de334  vmovaps [rsp+0x10], xmm1
00007dd8609de33a  vmovaps [rsp+0x20], xmm2
00007dd8609de340  vmovaps [rsp+0x30], xmm3
00007dd8609de346  vmovaps [rsp+0x40], xmm4
00007dd8609de34c  vmovaps [rsp+0x50], xmm5
00007dd8609de352  vmovaps [rsp+0x60], xmm6
00007dd8609de358  vmovaps [rsp+0x70], xmm8
00007dd8609de35e  vmovaps [rsp+0x80], xmm9
00007dd8609de367  vmovaps [rsp+0x90], xmm10
00007dd8609de370  vmovaps [rsp+0xA0], xmm11
00007dd8609de379  vmovaps [rsp+0xB0], xmm12
00007dd8609de382  vmovaps [rsp+0xC0], xmm13
00007dd8609de38b  vmovaps [rsp+0xD0], xmm14
00007dd8609de394  vmovaps [rsp+0xE0], xmm15
00007dd8609de39d  sub rsp, 0x30
00007dd8609de3a1  movaps [rsp], xmm7
00007dd8609de3a5  movaps [rsp+0x10], xmm9
00007dd8609de3ab  movaps [rsp+0x20], xmm15
00007dd8609de3b1  lea rdi, [rsp]
00007dd8609de3b5  mov esi, 0x00
00007dd8609de3ba  mov rax, 0x629C9CFA9530
00007dd8609de3c4  call rax
00007dd8609de3c6  movaps xmm7, [rsp]
00007dd8609de3ca  add rsp, 0x30
00007dd8609de3ce  vmovaps xmm0, [rsp]
00007dd8609de3d3  vmovaps xmm1, [rsp+0x10]
00007dd8609de3d9  vmovaps xmm2, [rsp+0x20]
00007dd8609de3df  vmovaps xmm3, [rsp+0x30]
00007dd8609de3e5  vmovaps xmm4, [rsp+0x40]
00007dd8609de3eb  vmovaps xmm5, [rsp+0x50]
00007dd8609de3f1  vmovaps xmm6, [rsp+0x60]
00007dd8609de3f7  vmovaps xmm8, [rsp+0x70]
00007dd8609de3fd  vmovaps xmm9, [rsp+0x80]
00007dd8609de406  vmovaps xmm10, [rsp+0x90]
00007dd8609de40f  vmovaps xmm11, [rsp+0xA0]
00007dd8609de418  vmovaps xmm12, [rsp+0xB0]
00007dd8609de421  vmovaps xmm13, [rsp+0xC0]
00007dd8609de42a  vmovaps xmm14, [rsp+0xD0]
00007dd8609de433  vmovaps xmm15, [rsp+0xE0]
00007dd8609de43c  add rsp, 0xF0
00007dd8609de443  pop r11
00007dd8609de445  pop r10
00007dd8609de447  pop r9
00007dd8609de449  pop r8
00007dd8609de44b  pop rsi
00007dd8609de44c  pop rdi
00007dd8609de44d  pop rdx
00007dd8609de44e  pop rcx
00007dd8609de44f  pop rax
00007dd8609de450  add rsp, 0x08
00007dd8609de454  jmp 0x00007DD8609D97E1
00007dd8609de459  sub rsp, 0x08
00007dd8609de45d  push rax
00007dd8609de45e  push rcx
00007dd8609de45f  push rdx
00007dd8609de460  push rdi
00007dd8609de461  push rsi
00007dd8609de462  push r8
00007dd8609de464  push r9
00007dd8609de466  push r10
00007dd8609de468  push r11
00007dd8609de46a  sub rsp, 0xF0
00007dd8609de471  vmovaps [rsp], xmm0
00007dd8609de476  vmovaps [rsp+0x10], xmm1
00007dd8609de47c  vmovaps [rsp+0x20], xmm2
00007dd8609de482  vmovaps [rsp+0x30], xmm3
00007dd8609de488  vmovaps [rsp+0x40], xmm4
00007dd8609de48e  vmovaps [rsp+0x50], xmm5
00007dd8609de494  vmovaps [rsp+0x60], xmm6
00007dd8609de49a  vmovaps [rsp+0x70], xmm7
00007dd8609de4a0  vmovaps [rsp+0x80], xmm8
00007dd8609de4a9  vmovaps [rsp+0x90], xmm10
00007dd8609de4b2  vmovaps [rsp+0xA0], xmm11
00007dd8609de4bb  vmovaps [rsp+0xB0], xmm12
00007dd8609de4c4  vmovaps [rsp+0xC0], xmm13
00007dd8609de4cd  vmovaps [rsp+0xD0], xmm14
00007dd8609de4d6  vmovaps [rsp+0xE0], xmm15
00007dd8609de4df  sub rsp, 0x30
00007dd8609de4e3  movaps [rsp], xmm9
00007dd8609de4e8  movaps [rsp+0x10], xmm13
00007dd8609de4ee  movaps [rsp+0x20], xmm15
00007dd8609de4f4  lea rdi, [rsp]
00007dd8609de4f8  mov esi, 0x00
00007dd8609de4fd  mov rax, 0x629C9CFA9530
00007dd8609de507  call rax
00007dd8609de509  movaps xmm9, [rsp]
00007dd8609de50e  add rsp, 0x30
00007dd8609de512  vmovaps xmm0, [rsp]
00007dd8609de517  vmovaps xmm1, [rsp+0x10]
00007dd8609de51d  vmovaps xmm2, [rsp+0x20]
00007dd8609de523  vmovaps xmm3, [rsp+0x30]
00007dd8609de529  vmovaps xmm4, [rsp+0x40]
00007dd8609de52f  vmovaps xmm5, [rsp+0x50]
00007dd8609de535  vmovaps xmm6, [rsp+0x60]
00007dd8609de53b  vmovaps xmm7, [rsp+0x70]
00007dd8609de541  vmovaps xmm8, [rsp+0x80]
00007dd8609de54a  vmovaps xmm10, [rsp+0x90]
00007dd8609de553  vmovaps xmm11, [rsp+0xA0]
00007dd8609de55c  vmovaps xmm12, [rsp+0xB0]
00007dd8609de565  vmovaps xmm13, [rsp+0xC0]
00007dd8609de56e  vmovaps xmm14, [rsp+0xD0]
00007dd8609de577  vmovaps xmm15, [rsp+0xE0]
00007dd8609de580  add rsp, 0xF0
00007dd8609de587  pop r11
00007dd8609de589  pop r10
00007dd8609de58b  pop r9
00007dd8609de58d  pop r8
00007dd8609de58f  pop rsi
00007dd8609de590  pop rdi
00007dd8609de591  pop rdx
00007dd8609de592  pop rcx
00007dd8609de593  pop rax
00007dd8609de594  add rsp, 0x08
00007dd8609de598  jmp 0x00007DD8609D980F
00007dd8609de59d  sub rsp, 0x08
00007dd8609de5a1  push rax
00007dd8609de5a2  push rcx
00007dd8609de5a3  push rdx
00007dd8609de5a4  push rdi
00007dd8609de5a5  push rsi
00007dd8609de5a6  push r8
00007dd8609de5a8  push r9
00007dd8609de5aa  push r10
00007dd8609de5ac  push r11
00007dd8609de5ae  sub rsp, 0xF0
00007dd8609de5b5  vmovaps [rsp], xmm0
00007dd8609de5ba  vmovaps [rsp+0x10], xmm1
00007dd8609de5c0  vmovaps [rsp+0x20], xmm2
00007dd8609de5c6  vmovaps [rsp+0x30], xmm3
00007dd8609de5cc  vmovaps [rsp+0x40], xmm4
00007dd8609de5d2  vmovaps [rsp+0x50], xmm5
00007dd8609de5d8  vmovaps [rsp+0x60], xmm6
00007dd8609de5de  vmovaps [rsp+0x70], xmm7
00007dd8609de5e4  vmovaps [rsp+0x80], xmm8
00007dd8609de5ed  vmovaps [rsp+0x90], xmm9
00007dd8609de5f6  vmovaps [rsp+0xA0], xmm10
00007dd8609de5ff  vmovaps [rsp+0xB0], xmm11
00007dd8609de608  vmovaps [rsp+0xC0], xmm12
00007dd8609de611  vmovaps [rsp+0xD0], xmm13
00007dd8609de61a  vmovaps [rsp+0xE0], xmm14
00007dd8609de623  sub rsp, 0x30
00007dd8609de627  movaps [rsp], xmm15
00007dd8609de62c  movaps [rsp+0x10], xmm11
00007dd8609de632  movaps [rsp+0x20], xmm12
00007dd8609de638  lea rdi, [rsp]
00007dd8609de63c  mov esi, 0x00
00007dd8609de641  mov rax, 0x629C9CFA9530
00007dd8609de64b  call rax
00007dd8609de64d  movaps xmm15, [rsp]
00007dd8609de652  add rsp, 0x30
00007dd8609de656  vmovaps xmm0, [rsp]
00007dd8609de65b  vmovaps xmm1, [rsp+0x10]
00007dd8609de661  vmovaps xmm2, [rsp+0x20]
00007dd8609de667  vmovaps xmm3, [rsp+0x30]
00007dd8609de66d  vmovaps xmm4, [rsp+0x40]
00007dd8609de673  vmovaps xmm5, [rsp+0x50]
00007dd8609de679  vmovaps xmm6, [rsp+0x60]
00007dd8609de67f  vmovaps xmm7, [rsp+0x70]
00007dd8609de685  vmovaps xmm8, [rsp+0x80]
00007dd8609de68e  vmovaps xmm9, [rsp+0x90]
00007dd8609de697  vmovaps xmm10, [rsp+0xA0]
00007dd8609de6a0  vmovaps xmm11, [rsp+0xB0]
00007dd8609de6a9  vmovaps xmm12, [rsp+0xC0]
00007dd8609de6b2  vmovaps xmm13, [rsp+0xD0]
00007dd8609de6bb  vmovaps xmm14, [rsp+0xE0]
00007dd8609de6c4  add rsp, 0xF0
00007dd8609de6cb  pop r11
00007dd8609de6cd  pop r10
00007dd8609de6cf  pop r9
00007dd8609de6d1  pop r8
00007dd8609de6d3  pop rsi
00007dd8609de6d4  pop rdi
00007dd8609de6d5  pop rdx
00007dd8609de6d6  pop rcx
00007dd8609de6d7  pop rax
00007dd8609de6d8  add rsp, 0x08
00007dd8609de6dc  jmp 0x00007DD8609D982A
00007dd8609de6e1  sub rsp, 0x08
00007dd8609de6e5  push rax
00007dd8609de6e6  push rcx
00007dd8609de6e7  push rdx
00007dd8609de6e8  push rdi
00007dd8609de6e9  push rsi
00007dd8609de6ea  push r8
00007dd8609de6ec  push r9
00007dd8609de6ee  push r10
00007dd8609de6f0  push r11
00007dd8609de6f2  sub rsp, 0xF0
00007dd8609de6f9  vmovaps [rsp], xmm0
00007dd8609de6fe  vmovaps [rsp+0x10], xmm1
00007dd8609de704  vmovaps [rsp+0x20], xmm2
00007dd8609de70a  vmovaps [rsp+0x30], xmm3
00007dd8609de710  vmovaps [rsp+0x40], xmm4
00007dd8609de716  vmovaps [rsp+0x50], xmm5
00007dd8609de71c  vmovaps [rsp+0x60], xmm6
00007dd8609de722  vmovaps [rsp+0x70], xmm7
00007dd8609de728  vmovaps [rsp+0x80], xmm8
00007dd8609de731  vmovaps [rsp+0x90], xmm9
00007dd8609de73a  vmovaps [rsp+0xA0], xmm10
00007dd8609de743  vmovaps [rsp+0xB0], xmm11
00007dd8609de74c  vmovaps [rsp+0xC0], xmm12
00007dd8609de755  vmovaps [rsp+0xD0], xmm14
00007dd8609de75e  vmovaps [rsp+0xE0], xmm15
00007dd8609de767  sub rsp, 0x30
00007dd8609de76b  movaps [rsp], xmm13
00007dd8609de770  movaps [rsp+0x10], xmm10
00007dd8609de776  movaps [rsp+0x20], xmm14
00007dd8609de77c  lea rdi, [rsp]
00007dd8609de780  mov esi, 0x00
00007dd8609de785  mov rax, 0x629C9CFA9530
00007dd8609de78f  call rax
00007dd8609de791  movaps xmm13, [rsp]
00007dd8609de796  add rsp, 0x30
00007dd8609de79a  vmovaps xmm0, [rsp]
00007dd8609de79f  vmovaps xmm1, [rsp+0x10]
00007dd8609de7a5  vmovaps xmm2, [rsp+0x20]
00007dd8609de7ab  vmovaps xmm3, [rsp+0x30]
00007dd8609de7b1  vmovaps xmm4, [rsp+0x40]
00007dd8609de7b7  vmovaps xmm5, [rsp+0x50]
00007dd8609de7bd  vmovaps xmm6, [rsp+0x60]
00007dd8609de7c3  vmovaps xmm7, [rsp+0x70]
00007dd8609de7c9  vmovaps xmm8, [rsp+0x80]
00007dd8609de7d2  vmovaps xmm9, [rsp+0x90]
00007dd8609de7db  vmovaps xmm10, [rsp+0xA0]
00007dd8609de7e4  vmovaps xmm11, [rsp+0xB0]
00007dd8609de7ed  vmovaps xmm12, [rsp+0xC0]
00007dd8609de7f6  vmovaps xmm14, [rsp+0xD0]
00007dd8609de7ff  vmovaps xmm15, [rsp+0xE0]
00007dd8609de808  add rsp, 0xF0
00007dd8609de80f  pop r11
00007dd8609de811  pop r10
00007dd8609de813  pop r9
00007dd8609de815  pop r8
00007dd8609de817  pop rsi
00007dd8609de818  pop rdi
00007dd8609de819  pop rdx
00007dd8609de81a  pop rcx
00007dd8609de81b  pop rax
00007dd8609de81c  add rsp, 0x08
00007dd8609de820  jmp 0x00007DD8609D984D
00007dd8609de825  sub rsp, 0x08
00007dd8609de829  push rax
00007dd8609de82a  push rcx
00007dd8609de82b  push rdx
00007dd8609de82c  push rdi
00007dd8609de82d  push rsi
00007dd8609de82e  push r8
00007dd8609de830  push r9
00007dd8609de832  push r10
00007dd8609de834  push r11
00007dd8609de836  sub rsp, 0xF0
00007dd8609de83d  vmovaps [rsp], xmm0
00007dd8609de842  vmovaps [rsp+0x10], xmm1
00007dd8609de848  vmovaps [rsp+0x20], xmm2
00007dd8609de84e  vmovaps [rsp+0x30], xmm3
00007dd8609de854  vmovaps [rsp+0x40], xmm4
00007dd8609de85a  vmovaps [rsp+0x50], xmm5
00007dd8609de860  vmovaps [rsp+0x60], xmm6
00007dd8609de866  vmovaps [rsp+0x70], xmm7
00007dd8609de86c  vmovaps [rsp+0x80], xmm8
00007dd8609de875  vmovaps [rsp+0x90], xmm9
00007dd8609de87e  vmovaps [rsp+0xA0], xmm10
00007dd8609de887  vmovaps [rsp+0xB0], xmm11
00007dd8609de890  vmovaps [rsp+0xC0], xmm12
00007dd8609de899  vmovaps [rsp+0xD0], xmm13
00007dd8609de8a2  vmovaps [rsp+0xE0], xmm15
00007dd8609de8ab  sub rsp, 0x30
00007dd8609de8af  movaps [rsp], xmm14
00007dd8609de8b4  movaps [rsp+0x10], xmm1
00007dd8609de8b9  movaps [rsp+0x20], xmm7
00007dd8609de8be  lea rdi, [rsp]
00007dd8609de8c2  mov esi, 0x00
00007dd8609de8c7  mov rax, 0x629C9CFA9530
00007dd8609de8d1  call rax
00007dd8609de8d3  movaps xmm14, [rsp]
00007dd8609de8d8  add rsp, 0x30
00007dd8609de8dc  vmovaps xmm0, [rsp]
00007dd8609de8e1  vmovaps xmm1, [rsp+0x10]
00007dd8609de8e7  vmovaps xmm2, [rsp+0x20]
00007dd8609de8ed  vmovaps xmm3, [rsp+0x30]
00007dd8609de8f3  vmovaps xmm4, [rsp+0x40]
00007dd8609de8f9  vmovaps xmm5, [rsp+0x50]
00007dd8609de8ff  vmovaps xmm6, [rsp+0x60]
00007dd8609de905  vmovaps xmm7, [rsp+0x70]
00007dd8609de90b  vmovaps xmm8, [rsp+0x80]
00007dd8609de914  vmovaps xmm9, [rsp+0x90]
00007dd8609de91d  vmovaps xmm10, [rsp+0xA0]
00007dd8609de926  vmovaps xmm11, [rsp+0xB0]
00007dd8609de92f  vmovaps xmm12, [rsp+0xC0]
00007dd8609de938  vmovaps xmm13, [rsp+0xD0]
00007dd8609de941  vmovaps xmm15, [rsp+0xE0]
00007dd8609de94a  add rsp, 0xF0
00007dd8609de951  pop r11
00007dd8609de953  pop r10
00007dd8609de955  pop r9
00007dd8609de957  pop r8
00007dd8609de959  pop rsi
00007dd8609de95a  pop rdi
00007dd8609de95b  pop rdx
00007dd8609de95c  pop rcx
00007dd8609de95d  pop rax
00007dd8609de95e  add rsp, 0x08
00007dd8609de962  jmp 0x00007DD8609D9870
00007dd8609de967  sub rsp, 0x08
00007dd8609de96b  push rax
00007dd8609de96c  push rcx
00007dd8609de96d  push rdx
00007dd8609de96e  push rdi
00007dd8609de96f  push rsi
00007dd8609de970  push r8
00007dd8609de972  push r9
00007dd8609de974  push r10
00007dd8609de976  push r11
00007dd8609de978  sub rsp, 0xF0
00007dd8609de97f  vmovaps [rsp], xmm0
00007dd8609de984  vmovaps [rsp+0x10], xmm2
00007dd8609de98a  vmovaps [rsp+0x20], xmm3
00007dd8609de990  vmovaps [rsp+0x30], xmm4
00007dd8609de996  vmovaps [rsp+0x40], xmm5
00007dd8609de99c  vmovaps [rsp+0x50], xmm6
00007dd8609de9a2  vmovaps [rsp+0x60], xmm7
00007dd8609de9a8  vmovaps [rsp+0x70], xmm8
00007dd8609de9ae  vmovaps [rsp+0x80], xmm9
00007dd8609de9b7  vmovaps [rsp+0x90], xmm10
00007dd8609de9c0  vmovaps [rsp+0xA0], xmm11
00007dd8609de9c9  vmovaps [rsp+0xB0], xmm12
00007dd8609de9d2  vmovaps [rsp+0xC0], xmm13
00007dd8609de9db  vmovaps [rsp+0xD0], xmm14
00007dd8609de9e4  vmovaps [rsp+0xE0], xmm15
00007dd8609de9ed  sub rsp, 0x30
00007dd8609de9f1  movaps [rsp], xmm1
00007dd8609de9f5  movaps [rsp+0x10], xmm8
00007dd8609de9fb  movaps [rsp+0x20], xmm9
00007dd8609dea01  lea rdi, [rsp]
00007dd8609dea05  mov esi, 0x00
00007dd8609dea0a  mov rax, 0x629C9CFA9530
00007dd8609dea14  call rax
00007dd8609dea16  movaps xmm1, [rsp]
00007dd8609dea1a  add rsp, 0x30
00007dd8609dea1e  vmovaps xmm0, [rsp]
00007dd8609dea23  vmovaps xmm2, [rsp+0x10]
00007dd8609dea29  vmovaps xmm3, [rsp+0x20]
00007dd8609dea2f  vmovaps xmm4, [rsp+0x30]
00007dd8609dea35  vmovaps xmm5, [rsp+0x40]
00007dd8609dea3b  vmovaps xmm6, [rsp+0x50]
00007dd8609dea41  vmovaps xmm7, [rsp+0x60]
00007dd8609dea47  vmovaps xmm8, [rsp+0x70]
00007dd8609dea4d  vmovaps xmm9, [rsp+0x80]
00007dd8609dea56  vmovaps xmm10, [rsp+0x90]
00007dd8609dea5f  vmovaps xmm11, [rsp+0xA0]
00007dd8609dea68  vmovaps xmm12, [rsp+0xB0]
00007dd8609dea71  vmovaps xmm13, [rsp+0xC0]
00007dd8609dea7a  vmovaps xmm14, [rsp+0xD0]
00007dd8609dea83  vmovaps xmm15, [rsp+0xE0]
00007dd8609dea8c  add rsp, 0xF0
00007dd8609dea93  pop r11
00007dd8609dea95  pop r10
00007dd8609dea97  pop r9
00007dd8609dea99  pop r8
00007dd8609dea9b  pop rsi
00007dd8609dea9c  pop rdi
00007dd8609dea9d  pop rdx
00007dd8609dea9e  pop rcx
00007dd8609dea9f  pop rax
00007dd8609deaa0  add rsp, 0x08
00007dd8609deaa4  jmp 0x00007DD8609D9892
00007dd8609deaa9  call 0x00007DD8608B3E40
00007dd8609deaae  jmp 0x00007DD8609D98A0
00007dd8609deab3  call 0x00007DD86080C380
00007dd8609deab8  jmp 0x00007DD8609D98AA
00007dd8609deabd  call 0x00007DD86080D600
00007dd8609deac2  jmp 0x00007DD8609D98B4
00007dd8609deac7  call 0x00007DD8607FF540
00007dd8609deacc  jmp 0x00007DD8609D98BE
00007dd8609dead1  int3
00007dd8609dead2  nop [rax+rax*1], ax
00007dd8609deadb  nop [rax+rax*1], eax
00007dd8609deae0  mov eax, [r15+0x48]
00007dd8609deae4  lea r14d, [eax+0x01]
00007dd8609deae9  mov [rsp+0x10], r14d
00007dd8609deaee  mov r14d, r14d
00007dd8609deaf1  mov [r15+0x48], r14
00007dd8609deaf5  xor eax, eax
00007dd8609deaf7  mov r14d, [rsp+0x10]
00007dd8609deafc  cmp r14d, 0x1F4
00007dd8609deb03  cmc
00007dd8609deb04  lahf
00007dd8609deb05  seto al
00007dd8609deb08  mov [r15+0x108], eax
00007dd8609deb0f  mov eax, [r15+0x108]
00007dd8609deb16  sahf
00007dd8609deb17  jnz 0x00007DD8609DEB49
00007dd8609deb19  cmp dword ptr [r15+0x318], 0x00
00007dd8609deb21  jz 0x00007DD8609E4C90
00007dd8609deb27  nop [rax+rax*1], ax
00007dd8609deb30  nop [rax+rax*1], eax
00007dd8609deb38  mov eax, 0x4106DC
00007dd8609deb3d  mov [r15+0x100], rax
00007dd8609deb44  jmp 0x00007DD8607FE110
00007dd8609deb49  cmp dword ptr [r15+0x318], 0x00
00007dd8609deb51  jz 0x00007DD8609DEB80
00007dd8609deb57  nop [rax+rax*1], ax
00007dd8609deb60  nop [rax+rax*1], eax
00007dd8609deb68  mov eax, 0x410500
00007dd8609deb6d  mov [r15+0x100], rax
00007dd8609deb74  jmp 0x00007DD8607FE110
00007dd8609deb79  int3
00007dd8609deb7a  int3
00007dd8609deb7b  nop [rax+rax*1], eax
00007dd8609deb80  mov rax, [r15+0x40]
00007dd8609deb84  movaps xmm1, [r15+0x1D0]
00007dd8609deb8c  vmovaps [rsp+0x10], xmm1
00007dd8609deb92  vmovaps xmm15, [rsp+0x10]
00007dd8609deb98  por xmm1, xmm15
00007dd8609deb9d  movaps xmm14, [r15+0x1A0]
00007dd8609deba5  vmovaps [rsp+0x10], xmm14
00007dd8609debab  vmovaps xmm13, [rsp+0x10]
00007dd8609debb1  por xmm14, xmm13
00007dd8609debb6  lea r14, [rax+0x30]
00007dd8609debba  mov r12, [r13+r14*1]
00007dd8609debbf  lea r14, [rax+0x38]
00007dd8609debc3  mov r11, [r13+r14*1]
00007dd8609debc8  movq xmm13, r12
00007dd8609debcd  movq xmm12, r11
00007dd8609debd2  movq xmm13, xmm13
00007dd8609debd7  vmovaps [rsp+0x10], xmm13
00007dd8609debdd  movq xmm13, xmm13
00007dd8609debe2  movaps [r15+0x130], xmm13
00007dd8609debea  movq xmm12, xmm12
00007dd8609debef  vmovaps [rsp+0x20], xmm12
00007dd8609debf5  movq xmm12, xmm12
00007dd8609debfa  movaps [r15+0x280], xmm12
00007dd8609dec02  movaps xmm13, [r15+0x270]
00007dd8609dec0a  vmovaps [rsp+0x30], xmm13
00007dd8609dec10  vmovaps xmm12, [rsp+0x30]
00007dd8609dec16  por xmm13, xmm12
00007dd8609dec1b  lea r14, [rax+0x20]
00007dd8609dec1f  mov r12, [r13+r14*1]
00007dd8609dec24  lea r14, [rax+0x28]
00007dd8609dec28  mov r11, [r13+r14*1]
00007dd8609dec2d  movq xmm12, r12
00007dd8609dec32  movq xmm11, r11
00007dd8609dec37  movq xmm12, xmm12
00007dd8609dec3c  vmovaps [rsp+0x30], xmm12
00007dd8609dec42  movq xmm12, xmm12
00007dd8609dec47  movaps [r15+0x150], xmm12
00007dd8609dec4f  movq xmm11, xmm11
00007dd8609dec54  vmovaps [rsp+0x40], xmm11
00007dd8609dec5a  movq xmm11, xmm11
00007dd8609dec5f  movaps [r15+0x140], xmm11
00007dd8609dec67  lea r14, [rax+0x10]
00007dd8609dec6b  mov r12, [r13+r14*1]
00007dd8609dec70  lea r14, [rax+0x18]
00007dd8609dec74  mov r11, [r13+r14*1]
00007dd8609dec79  movq xmm12, r12
00007dd8609dec7e  movq xmm11, r11
00007dd8609dec83  movq xmm12, xmm12
00007dd8609dec88  vmovaps [rsp+0x50], xmm12
00007dd8609dec8e  movq xmm12, xmm12
00007dd8609dec93  movaps [r15+0x170], xmm12
00007dd8609dec9b  movq xmm11, xmm11
00007dd8609deca0  vmovaps [rsp+0x60], xmm11
00007dd8609deca6  movq xmm11, xmm11
00007dd8609decab  movaps [r15+0x160], xmm11
00007dd8609decb3  mov r14, [r13+rax*1]
00007dd8609decb8  vmovq xmm12, r14
00007dd8609decbd  vpbroadcastq xmm12, xmm12
00007dd8609decc2  lea r14, [rax+0x08]
00007dd8609decc6  mov rax, [r13+r14*1]
00007dd8609deccb  movq xmm11, rax
00007dd8609decd0  movaps [r15+0x230], xmm11
00007dd8609decd8  mov rax, [r15+0xF8]
00007dd8609decdf  lea r14, [rax+0x50]
00007dd8609dece3  movups xmm11, [r13+r14*1]
00007dd8609dece9  lea r14, [rax+0x60]
00007dd8609deced  movups xmm10, [r13+r14*1]
00007dd8609decf3  lea r14, [rax+0x30]
00007dd8609decf7  movups xmm9, [r13+r14*1]
00007dd8609decfd  mov r14, [r15+0x50]
00007dd8609ded01  mov [r15+0x60], r14
00007dd8609ded05  mov qword ptr [r15+0x58], 0x40
00007dd8609ded0d  movaps xmm8, xmm12
00007dd8609ded11  mulpd xmm8, xmm15
00007dd8609ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8609ded1c  ptest xmm7, xmm7
00007dd8609ded21  jnz 0x00007DD8609DFB4A
00007dd8609ded27  movq xmm15, qword ptr [r15+0x230]
00007dd8609ded30  vmovaps [rsp+0x70], xmm15
00007dd8609ded36  vpermilpd xmm15, xmm15, 0x00
00007dd8609ded3c  movaps xmm7, xmm9
00007dd8609ded40  mulpd xmm7, xmm15
00007dd8609ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8609ded4a  ptest xmm6, xmm6
00007dd8609ded4f  jnz 0x00007DD8609DFC8E
00007dd8609ded55  vxorps xmm15, xmm15, xmm15
00007dd8609ded5a  vpbroadcastq xmm15, xmm15
00007dd8609ded5f  movaps xmm9, xmm12
00007dd8609ded63  mulpd xmm9, xmm10
00007dd8609ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8609ded6e  ptest xmm6, xmm6
00007dd8609ded73  jnz 0x00007DD8609DFDD0
00007dd8609ded79  movaps xmm10, xmm12
00007dd8609ded7d  mulpd xmm10, xmm11
00007dd8609ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007dd8609ded88  ptest xmm6, xmm6
00007dd8609ded8d  jnz 0x00007DD8609DFF14
00007dd8609ded93  movaps xmm11, [r15+0x1F0]
00007dd8609ded9b  movaps xmm6, xmm12
00007dd8609ded9f  mulpd xmm6, xmm11
00007dd8609deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8609deda9  ptest xmm5, xmm5
00007dd8609dedae  jnz 0x00007DD8609E0058
00007dd8609dedb4  movaps xmm12, [r15+0x2A0]
00007dd8609dedbc  vmovaps [rsp+0x80], xmm12
00007dd8609dedc5  vmovaps xmm11, [rsp+0x80]
00007dd8609dedce  por xmm12, xmm11
00007dd8609dedd3  movaps xmm11, [r15+0x250]
00007dd8609deddb  vmovaps [rsp+0x80], xmm11
00007dd8609dede4  vmovaps xmm5, [rsp+0x80]
00007dd8609deded  por xmm11, xmm5
00007dd8609dedf2  vmovaps xmm4, [rsp+0x70]
00007dd8609dedf8  vpermilpd xmm4, xmm4, 0x00
00007dd8609dedfe  movaps xmm3, xmm5
00007dd8609dee01  mulpd xmm3, xmm4
00007dd8609dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007dd8609dee0a  ptest xmm2, xmm2
00007dd8609dee0f  jnz 0x00007DD8609E019A
00007dd8609dee15  mov [rsp+0x80], rax
00007dd8609dee1d  xor eax, eax
00007dd8609dee1f  mov r12d, 0x40
00007dd8609dee25  mov r11d, 0x200
00007dd8609dee2b  cmp r12, r11
00007dd8609dee2e  cmc
00007dd8609dee2f  lahf
00007dd8609dee30  seto al
00007dd8609dee33  mov [r15+0x108], eax
00007dd8609dee3a  movaps xmm5, xmm8
00007dd8609dee3e  addpd xmm5, xmm15
00007dd8609dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007dd8609dee48  ptest xmm4, xmm4
00007dd8609dee4d  jnz 0x00007DD8609E02DA
00007dd8609dee53  movaps xmm8, [r15+0x1B0]
00007dd8609dee5b  movaps xmm4, xmm9
00007dd8609dee5f  addpd xmm4, xmm8
00007dd8609dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007dd8609dee69  ptest xmm2, xmm2
00007dd8609dee6e  jnz 0x00007DD8609E041C
00007dd8609dee74  movaps xmm9, xmm10
00007dd8609dee78  addpd xmm9, xmm8
00007dd8609dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007dd8609dee83  ptest xmm2, xmm2
00007dd8609dee88  jnz 0x00007DD8609E055E
00007dd8609dee8e  movaps xmm10, [r15+0x2F0]
00007dd8609dee96  vmovaps [rsp+0x90], xmm10
00007dd8609dee9f  vmovaps xmm8, [rsp+0x90]
00007dd8609deea8  por xmm10, xmm8
00007dd8609deead  movaps xmm8, [r15+0x2E0]
00007dd8609deeb5  vmovaps [rsp+0x90], xmm8
00007dd8609deebe  vmovaps xmm2, [rsp+0x90]
00007dd8609deec7  por xmm8, xmm2
00007dd8609deecc  movaps xmm2, [r15+0x2D0]
00007dd8609deed4  vmovaps [rsp+0x90], xmm2
00007dd8609deedd  vmovaps [rsp+0xA0], xmm1
00007dd8609deee6  vmovaps xmm1, [rsp+0x90]
00007dd8609deeef  por xmm2, xmm1
00007dd8609deef3  movaps xmm1, [r15+0x200]
00007dd8609deefb  vmovaps [rsp+0x90], xmm1
00007dd8609def04  vmovaps [rsp+0xB0], xmm15
00007dd8609def0d  vmovaps xmm15, [rsp+0x90]
00007dd8609def16  por xmm1, xmm15
00007dd8609def1b  movaps xmm15, [r15+0x1C0]
00007dd8609def23  vmovaps [rsp+0x90], xmm15
00007dd8609def2c  vmovaps [rsp+0xC0], xmm1
00007dd8609def35  vmovaps xmm1, [rsp+0x90]
00007dd8609def3e  por xmm15, xmm1
00007dd8609def43  movaps xmm1, [r15+0x190]
00007dd8609def4b  vmovaps [rsp+0x90], xmm1
00007dd8609def54  vmovaps [rsp+0xD0], xmm15
00007dd8609def5d  vmovaps xmm15, [rsp+0x90]
00007dd8609def66  por xmm1, xmm15
00007dd8609def6b  movaps xmm15, [r15+0x300]
00007dd8609def73  vmovaps [rsp+0x90], xmm15
00007dd8609def7c  vmovaps [rsp+0xE0], xmm1
00007dd8609def85  vmovaps xmm1, [rsp+0x90]
00007dd8609def8e  por xmm15, xmm1
00007dd8609def93  mov rax, [rsp+0x80]
00007dd8609def9b  lea r12, [rax+0xA0]
00007dd8609defa2  movups xmm1, [r13+r12*1]
00007dd8609defa8  lea r12, [rax+0xB0]
00007dd8609defaf  vmovaps [rsp+0x80], xmm1
00007dd8609defb8  movups xmm1, [r13+r12*1]
00007dd8609defbe  vmovaps [rsp+0x90], xmm1
00007dd8609defc7  vmovaps [rsp+0xF0], xmm15
00007dd8609defd0  vmovaps xmm15, [rsp+0xB0]
00007dd8609defd9  vmovaps [rsp+0xB0], xmm14
00007dd8609defe2  movaps xmm1, xmm6
00007dd8609defe5  addpd xmm1, xmm15
00007dd8609defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8609defef  ptest xmm14, xmm14
00007dd8609deff5  jnz 0x00007DD8609E06B6
00007dd8609deffb  lea r12, [rax+0xF0]
00007dd8609df002  movups xmm15, [r13+r12*1]
00007dd8609df008  movaps xmm14, xmm4
00007dd8609df00c  addpd xmm14, xmm3
00007dd8609df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8609df017  ptest xmm6, xmm6
00007dd8609df01c  jnz 0x00007DD8609E0801
00007dd8609df022  movaps xmm6, xmm9
00007dd8609df026  addpd xmm6, xmm7
00007dd8609df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007dd8609df02f  ptest xmm4, xmm4
00007dd8609df034  jnz 0x00007DD8609E0943
00007dd8609df03a  vmovaps xmm9, [rsp+0x70]
00007dd8609df040  vpermilpd xmm9, xmm9, 0x00
00007dd8609df046  vmovaps xmm4, [rsp+0x90]
00007dd8609df04f  movaps xmm7, xmm4
00007dd8609df052  mulpd xmm7, xmm9
00007dd8609df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007dd8609df05c  ptest xmm3, xmm3
00007dd8609df061  jnz 0x00007DD8609E0A84
00007dd8609df067  vmovaps xmm9, [rsp+0x50]
00007dd8609df06d  vpermilpd xmm9, xmm9, 0x00
00007dd8609df073  movaps xmm4, xmm15
00007dd8609df077  mulpd xmm4, xmm9
00007dd8609df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd8609df081  ptest xmm3, xmm3
00007dd8609df086  jnz 0x00007DD8609E0BC5
00007dd8609df08c  lea r12, [rax+0xE0]
00007dd8609df093  movups xmm15, [r13+r12*1]
00007dd8609df099  vmovaps xmm9, [rsp+0x70]
00007dd8609df09f  vpermilpd xmm9, xmm9, 0x00
00007dd8609df0a5  vmovaps [rsp+0x70], xmm1
00007dd8609df0ab  vmovaps xmm1, [rsp+0x80]
00007dd8609df0b4  vmovaps [rsp+0x80], xmm15
00007dd8609df0bd  movaps xmm3, xmm1
00007dd8609df0c0  mulpd xmm3, xmm9
00007dd8609df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007dd8609df0ca  ptest xmm15, xmm15
00007dd8609df0d0  jnz 0x00007DD8609E0D11
00007dd8609df0d6  vmovaps xmm1, [rsp+0xF0]
00007dd8609df0df  vmovaps xmm15, [rsp+0xF0]
00007dd8609df0e8  por xmm1, xmm15
00007dd8609df0ed  movaps [r15+0x300], xmm1
00007dd8609df0f5  vmovaps xmm15, [rsp+0xE0]
00007dd8609df0fe  vmovaps xmm9, [rsp+0xE0]
00007dd8609df107  por xmm15, xmm9
00007dd8609df10c  movaps [r15+0x190], xmm15
00007dd8609df114  vmovaps xmm9, [rsp+0x50]
00007dd8609df11a  vpermilpd xmm9, xmm9, 0x00
00007dd8609df120  vmovaps [rsp+0x90], xmm1
00007dd8609df129  vmovaps [rsp+0xE0], xmm15
00007dd8609df132  vmovaps xmm15, [rsp+0x80]
00007dd8609df13b  vmovaps [rsp+0x80], xmm14
00007dd8609df144  movaps xmm1, xmm15
00007dd8609df148  mulpd xmm1, xmm9
00007dd8609df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007dd8609df152  ptest xmm14, xmm14
00007dd8609df158  jnz 0x00007DD8609E0E52
00007dd8609df15e  lea r12, [rax+0x90]
00007dd8609df165  movups xmm15, [r13+r12*1]
00007dd8609df16b  vmovaps xmm14, [rsp+0xD0]
00007dd8609df174  vmovaps xmm9, [rsp+0xD0]
00007dd8609df17d  por xmm14, xmm9
00007dd8609df182  movaps [r15+0x1C0], xmm14
00007dd8609df18a  vmovaps xmm9, [rsp+0xC0]
00007dd8609df193  vmovaps [rsp+0xD0], xmm1
00007dd8609df19c  vmovaps xmm1, [rsp+0xC0]
00007dd8609df1a5  por xmm9, xmm1
00007dd8609df1aa  movaps [r15+0x200], xmm9
00007dd8609df1b2  vmovaps [rsp+0xC0], xmm2
00007dd8609df1bb  vmovaps xmm1, [rsp+0xC0]
00007dd8609df1c4  por xmm2, xmm1
00007dd8609df1c8  movaps [r15+0x2D0], xmm2
00007dd8609df1d0  vmovaps [rsp+0xC0], xmm8
00007dd8609df1d9  vmovaps xmm1, [rsp+0xC0]
00007dd8609df1e2  por xmm8, xmm1
00007dd8609df1e7  movaps [r15+0x2E0], xmm8
00007dd8609df1ef  vmovaps [rsp+0xC0], xmm15
00007dd8609df1f8  movaps xmm1, xmm5
00007dd8609df1fb  addpd xmm1, xmm7
00007dd8609df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007dd8609df204  ptest xmm15, xmm15
00007dd8609df20a  jnz 0x00007DD8609E0F9E
00007dd8609df210  vmovaps xmm15, [rsp+0x50]
00007dd8609df216  vpermilpd xmm15, xmm15, 0x00
00007dd8609df21c  vmovaps xmm5, [rsp+0xC0]
00007dd8609df225  vmovaps [rsp+0xC0], xmm1
00007dd8609df22e  movaps xmm7, xmm5
00007dd8609df231  mulpd xmm7, xmm15
00007dd8609df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007dd8609df23b  ptest xmm1, xmm1
00007dd8609df240  jnz 0x00007DD8609E10DE
00007dd8609df246  lea r12, [rax+0x80]
00007dd8609df24d  movups xmm1, [r13+r12*1]
00007dd8609df253  vmovaps xmm5, [rsp+0x70]
00007dd8609df259  vmovaps [rsp+0x70], xmm1
00007dd8609df25f  movaps xmm15, xmm5
00007dd8609df263  addpd xmm15, xmm3
00007dd8609df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8609df26e  ptest xmm1, xmm1
00007dd8609df273  jnz 0x00007DD8609E1229
00007dd8609df279  vmovaps xmm5, [rsp+0x80]
00007dd8609df282  movaps xmm1, xmm5
00007dd8609df285  addpd xmm1, xmm4
00007dd8609df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007dd8609df28e  ptest xmm3, xmm3
00007dd8609df293  jnz 0x00007DD8609E136B
00007dd8609df299  vmovaps [rsp+0x80], xmm10
00007dd8609df2a2  vmovaps xmm5, [rsp+0x80]
00007dd8609df2ab  por xmm10, xmm5
00007dd8609df2b0  movaps [r15+0x2F0], xmm10
00007dd8609df2b8  vmovaps xmm5, [rsp+0x50]
00007dd8609df2be  vpermilpd xmm5, xmm5, 0x00
00007dd8609df2c4  vmovaps xmm3, [rsp+0x70]
00007dd8609df2ca  vmovaps [rsp+0x50], xmm1
00007dd8609df2d0  movaps xmm4, xmm3
00007dd8609df2d3  mulpd xmm4, xmm5
00007dd8609df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd8609df2dc  ptest xmm1, xmm1
00007dd8609df2e1  jnz 0x00007DD8609E14AB
00007dd8609df2e7  lea r12, [rax+0xD0]
00007dd8609df2ee  movups xmm1, [r13+r12*1]
00007dd8609df2f4  vmovaps xmm3, [rsp+0xD0]
00007dd8609df2fd  vmovaps [rsp+0x70], xmm1
00007dd8609df303  movaps xmm5, xmm6
00007dd8609df306  addpd xmm5, xmm3
00007dd8609df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007dd8609df30f  ptest xmm1, xmm1
00007dd8609df314  jnz 0x00007DD8609E15F5
00007dd8609df31a  vmovaps xmm1, [rsp+0x60]
00007dd8609df320  vpermilpd xmm1, xmm1, 0x00
00007dd8609df326  movaps xmm6, xmm9
00007dd8609df32a  mulpd xmm6, xmm1
00007dd8609df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd8609df333  ptest xmm3, xmm3
00007dd8609df338  jnz 0x00007DD8609E1735
00007dd8609df33e  movaps [r15+0x260], xmm6
00007dd8609df346  vxorps xmm1, xmm1, xmm1
00007dd8609df34a  vpbroadcastq xmm1, xmm1
00007dd8609df34f  movaps [r15+0x1B0], xmm1
00007dd8609df357  vmovaps xmm1, [rsp+0x60]
00007dd8609df35d  vpermilpd xmm1, xmm1, 0x00
00007dd8609df363  vmovaps xmm3, [rsp+0x70]
00007dd8609df369  vmovaps [rsp+0x70], xmm15
00007dd8609df36f  movaps xmm9, xmm3
00007dd8609df373  mulpd xmm9, xmm1
00007dd8609df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd8609df37e  ptest xmm15, xmm15
00007dd8609df384  jnz 0x00007DD8609E1876
00007dd8609df38a  lea r12, [rax+0xC0]
00007dd8609df391  movups xmm1, [r13+r12*1]
00007dd8609df397  vmovaps xmm3, [rsp+0xC0]
00007dd8609df3a0  vmovaps [rsp+0x80], xmm1
00007dd8609df3a9  movaps xmm15, xmm3
00007dd8609df3ad  addpd xmm15, xmm7
00007dd8609df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8609df3b8  ptest xmm1, xmm1
00007dd8609df3bd  jnz 0x00007DD8609E19C2
00007dd8609df3c3  vmovaps [rsp+0xC0], xmm13
00007dd8609df3cc  vmovaps xmm1, [rsp+0xC0]
00007dd8609df3d5  por xmm13, xmm1
00007dd8609df3da  movaps [r15+0x270], xmm13
00007dd8609df3e2  vmovaps xmm1, [rsp+0xB0]
00007dd8609df3eb  vmovaps xmm7, [rsp+0xB0]
00007dd8609df3f4  por xmm1, xmm7
00007dd8609df3f8  movaps [r15+0x1A0], xmm1
00007dd8609df400  vmovaps xmm1, [rsp+0x60]
00007dd8609df406  vpermilpd xmm1, xmm1, 0x00
00007dd8609df40c  vmovaps [rsp+0xB0], xmm1
00007dd8609df415  vmovaps xmm1, [rsp+0x80]
00007dd8609df41e  vmovaps [rsp+0x80], xmm15
00007dd8609df427  vmovaps xmm15, [rsp+0xB0]
00007dd8609df430  vmovaps [rsp+0xB0], xmm14
00007dd8609df439  movaps xmm3, xmm1
00007dd8609df43c  mulpd xmm3, xmm15
00007dd8609df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007dd8609df446  ptest xmm14, xmm14
00007dd8609df44c  jnz 0x00007DD8609E1B04
00007dd8609df452  lea r12, [rax+0x20]
00007dd8609df456  movups xmm1, [r13+r12*1]
00007dd8609df45c  movaps [r15+0x110], xmm1
00007dd8609df464  vmovaps xmm14, [rsp+0x70]
00007dd8609df46a  vmovaps [rsp+0x70], xmm1
00007dd8609df470  movaps xmm15, xmm14
00007dd8609df474  addpd xmm15, xmm4
00007dd8609df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007dd8609df47f  ptest xmm1, xmm1
00007dd8609df484  jnz 0x00007DD8609E1C4F
00007dd8609df48a  vmovaps xmm1, [rsp+0x60]
00007dd8609df490  vpermilpd xmm1, xmm1, 0x00
00007dd8609df496  movaps xmm14, xmm2
00007dd8609df49a  mulpd xmm14, xmm1
00007dd8609df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007dd8609df4a5  ptest xmm4, xmm4
00007dd8609df4aa  jnz 0x00007DD8609E1D92
00007dd8609df4b0  vmovaps xmm4, [rsp+0x50]
00007dd8609df4b6  movaps xmm1, xmm4
00007dd8609df4b9  addpd xmm1, xmm9
00007dd8609df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8609df4c3  ptest xmm2, xmm2
00007dd8609df4c8  jnz 0x00007DD8609E1ED4
00007dd8609df4ce  vmovaps xmm9, [rsp+0x30]
00007dd8609df4d4  vpermilpd xmm9, xmm9, 0x00
00007dd8609df4da  vmovaps xmm2, [rsp+0x70]
00007dd8609df4e0  vmovaps [rsp+0x50], xmm1
00007dd8609df4e6  movaps xmm4, xmm2
00007dd8609df4e9  mulpd xmm4, xmm9
00007dd8609df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007dd8609df4f3  ptest xmm1, xmm1
00007dd8609df4f8  jnz 0x00007DD8609E2015
00007dd8609df4fe  vmovaps xmm1, [rsp+0x30]
00007dd8609df504  vpermilpd xmm1, xmm1, 0x00
00007dd8609df50a  vmovaps xmm2, [rsp+0x90]
00007dd8609df513  vmovaps [rsp+0x60], xmm15
00007dd8609df519  movaps xmm9, xmm2
00007dd8609df51d  mulpd xmm9, xmm1
00007dd8609df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007dd8609df528  ptest xmm15, xmm15
00007dd8609df52e  jnz 0x00007DD8609E2156
00007dd8609df534  vmovaps xmm15, [rsp+0x80]
00007dd8609df53d  movaps xmm1, xmm15
00007dd8609df541  addpd xmm1, xmm6
00007dd8609df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007dd8609df54a  ptest xmm2, xmm2
00007dd8609df54f  jnz 0x00007DD8609E2298
00007dd8609df555  movaps xmm15, xmm5
00007dd8609df559  addpd xmm15, xmm3
00007dd8609df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007dd8609df564  ptest xmm6, xmm6
00007dd8609df569  jnz 0x00007DD8609E23D9
00007dd8609df56f  vmovaps xmm6, [rsp+0x30]
00007dd8609df575  vpermilpd xmm6, xmm6, 0x00
00007dd8609df57b  movaps xmm5, xmm8
00007dd8609df57f  mulpd xmm5, xmm6
00007dd8609df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007dd8609df588  ptest xmm3, xmm3
00007dd8609df58d  jnz 0x00007DD8609E251B
00007dd8609df593  vmovaps xmm8, [rsp+0x30]
00007dd8609df599  vpermilpd xmm8, xmm8, 0x00
00007dd8609df59f  movaps xmm6, xmm10
00007dd8609df5a3  mulpd xmm6, xmm8
00007dd8609df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007dd8609df5ad  ptest xmm3, xmm3
00007dd8609df5b2  jnz 0x00007DD8609E265C
00007dd8609df5b8  vmovaps xmm8, [rsp+0x60]
00007dd8609df5be  movaps xmm10, xmm8
00007dd8609df5c2  addpd xmm10, xmm14
00007dd8609df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007dd8609df5cd  ptest xmm3, xmm3
00007dd8609df5d2  jnz 0x00007DD8609E279E
00007dd8609df5d8  vmovaps xmm8, [rsp+0x50]
00007dd8609df5de  movaps xmm14, xmm8
00007dd8609df5e2  addpd xmm14, xmm4
00007dd8609df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007dd8609df5ed  ptest xmm3, xmm3
00007dd8609df5f2  jnz 0x00007DD8609E28E2
00007dd8609df5f8  vmovaps xmm8, [rsp+0x40]
00007dd8609df5fe  vpermilpd xmm8, xmm8, 0x00
00007dd8609df604  movaps xmm4, xmm13
00007dd8609df608  mulpd xmm4, xmm8
00007dd8609df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007dd8609df612  ptest xmm3, xmm3
00007dd8609df617  jnz 0x00007DD8609E2A25
00007dd8609df61d  movaps xmm13, xmm15
00007dd8609df621  addpd xmm13, xmm9
00007dd8609df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007dd8609df62c  ptest xmm8, xmm8
00007dd8609df632  jnz 0x00007DD8609E2B67
00007dd8609df638  movaps xmm15, xmm1
00007dd8609df63c  addpd xmm15, xmm5
00007dd8609df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8609df647  ptest xmm9, xmm9
00007dd8609df64d  jnz 0x00007DD8609E2CAB
00007dd8609df653  vmovaps [rsp+0x30], xmm11
00007dd8609df659  vmovaps xmm1, [rsp+0x30]
00007dd8609df65f  por xmm11, xmm1
00007dd8609df664  movaps [r15+0x250], xmm11
00007dd8609df66c  vmovaps [rsp+0x30], xmm12
00007dd8609df672  vmovaps xmm1, [rsp+0x30]
00007dd8609df678  por xmm12, xmm1
00007dd8609df67d  movaps [r15+0x2A0], xmm12
00007dd8609df685  vmovaps xmm1, [rsp+0xA0]
00007dd8609df68e  vmovaps xmm11, [rsp+0xA0]
00007dd8609df697  por xmm1, xmm11
00007dd8609df69c  movaps [r15+0x1D0], xmm1
00007dd8609df6a4  lea r12, [rax+0x40]
00007dd8609df6a8  movups xmm1, [r13+r12*1]
00007dd8609df6ae  movaps [r15+0x2C0], xmm1
00007dd8609df6b6  vmovaps xmm11, [rsp+0x40]
00007dd8609df6bc  vpermilpd xmm11, xmm11, 0x00
00007dd8609df6c2  vmovaps xmm8, [rsp+0xE0]
00007dd8609df6cb  movaps xmm9, xmm8
00007dd8609df6cf  mulpd xmm9, xmm11
00007dd8609df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007dd8609df6da  ptest xmm5, xmm5
00007dd8609df6df  jnz 0x00007DD8609E2DF7
00007dd8609df6e5  movaps xmm11, xmm10
00007dd8609df6e9  addpd xmm11, xmm6
00007dd8609df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007dd8609df6f4  ptest xmm8, xmm8
00007dd8609df6fa  jnz 0x00007DD8609E2F3B
00007dd8609df700  movaps xmm10, xmm14
00007dd8609df704  addpd xmm10, xmm4
00007dd8609df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007dd8609df70f  ptest xmm8, xmm8
00007dd8609df715  jnz 0x00007DD8609E307E
00007dd8609df71b  vmovaps xmm14, [rsp+0x40]
00007dd8609df721  vpermilpd xmm14, xmm14, 0x00
00007dd8609df727  movaps xmm8, xmm1
00007dd8609df72b  mulpd xmm8, xmm14
00007dd8609df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8609df736  ptest xmm6, xmm6
00007dd8609df73b  jnz 0x00007DD8609E31C1
00007dd8609df741  movaps xmm1, [r15+0x2B0]
00007dd8609df749  vmovaps xmm14, [rsp+0x40]
00007dd8609df74f  vpermilpd xmm14, xmm14, 0x00
00007dd8609df755  movaps xmm6, xmm1
00007dd8609df758  mulpd xmm6, xmm14
00007dd8609df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007dd8609df762  ptest xmm5, xmm5
00007dd8609df767  jnz 0x00007DD8609E3304
00007dd8609df76d  vmovaps xmm1, [rsp+0x10]
00007dd8609df773  vpermilpd xmm1, xmm1, 0x00
00007dd8609df779  movaps xmm14, xmm12
00007dd8609df77d  mulpd xmm14, xmm1
00007dd8609df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007dd8609df788  ptest xmm5, xmm5
00007dd8609df78d  jnz 0x00007DD8609E3445
00007dd8609df793  movaps xmm1, xmm13
00007dd8609df797  addpd xmm1, xmm9
00007dd8609df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8609df7a1  ptest xmm12, xmm12
00007dd8609df7a7  jnz 0x00007DD8609E3588
00007dd8609df7ad  vmovaps xmm13, [rsp+0x10]
00007dd8609df7b3  vpermilpd xmm13, xmm13, 0x00
00007dd8609df7b9  movaps xmm12, xmm7
00007dd8609df7bd  mulpd xmm12, xmm13
00007dd8609df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8609df7c8  ptest xmm9, xmm9
00007dd8609df7ce  jnz 0x00007DD8609E36CA
00007dd8609df7d4  movaps xmm13, xmm15
00007dd8609df7d8  addpd xmm13, xmm8
00007dd8609df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007dd8609df7e3  ptest xmm9, xmm9
00007dd8609df7e9  jnz 0x00007DD8609E380D
00007dd8609df7ef  movaps xmm15, [r15+0x290]
00007dd8609df7f7  vmovaps xmm9, [rsp+0x10]
00007dd8609df7fd  vpermilpd xmm9, xmm9, 0x00
00007dd8609df803  movaps xmm8, xmm15
00007dd8609df807  mulpd xmm8, xmm9
00007dd8609df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007dd8609df812  ptest xmm7, xmm7
00007dd8609df817  jnz 0x00007DD8609E3951
00007dd8609df81d  movaps xmm15, xmm11
00007dd8609df821  addpd xmm15, xmm6
00007dd8609df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007dd8609df82c  ptest xmm9, xmm9
00007dd8609df832  jnz 0x00007DD8609E3A95
00007dd8609df838  movaps xmm11, [r15+0x1E0]
00007dd8609df840  vmovaps xmm9, [rsp+0x10]
00007dd8609df846  vpermilpd xmm9, xmm9, 0x00
00007dd8609df84c  movaps xmm7, xmm11
00007dd8609df850  mulpd xmm7, xmm9
00007dd8609df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8609df85a  ptest xmm6, xmm6
00007dd8609df85f  jnz 0x00007DD8609E3BD8
00007dd8609df865  movaps xmm11, xmm10
00007dd8609df869  addpd xmm11, xmm14
00007dd8609df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007dd8609df874  ptest xmm9, xmm9
00007dd8609df87a  jnz 0x00007DD8609E3D1A
00007dd8609df880  lea r12, [rax+0x70]
00007dd8609df884  movups xmm14, [r13+r12*1]
00007dd8609df88a  movaps [r15+0x240], xmm14
00007dd8609df892  movaps xmm10, xmm1
00007dd8609df896  addpd xmm10, xmm12
00007dd8609df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007dd8609df8a1  ptest xmm9, xmm9
00007dd8609df8a7  jnz 0x00007DD8609E3E68
00007dd8609df8ad  movaps [r15+0x170], xmm10
00007dd8609df8b5  vmovaps xmm1, [rsp+0x20]
00007dd8609df8bb  vpermilpd xmm1, xmm1, 0x00
00007dd8609df8c1  movaps xmm12, xmm14
00007dd8609df8c5  mulpd xmm12, xmm1
00007dd8609df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007dd8609df8d0  ptest xmm9, xmm9
00007dd8609df8d6  jnz 0x00007DD8609E3FAB
00007dd8609df8dc  vmovaps xmm1, [rsp+0x20]
00007dd8609df8e2  vpermilpd xmm1, xmm1, 0x00
00007dd8609df8e8  vmovaps xmm9, [rsp+0xB0]
00007dd8609df8f1  movaps xmm14, xmm9
00007dd8609df8f5  mulpd xmm14, xmm1
00007dd8609df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007dd8609df900  ptest xmm6, xmm6
00007dd8609df905  jnz 0x00007DD8609E40EE
00007dd8609df90b  movaps [r15+0x180], xmm14
00007dd8609df913  movaps xmm1, xmm13
00007dd8609df917  addpd xmm1, xmm8
00007dd8609df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007dd8609df921  ptest xmm9, xmm9
00007dd8609df927  jnz 0x00007DD8609E4231
00007dd8609df92d  movaps [r15+0x210], xmm1
00007dd8609df935  movups xmm13, [r13+rax*1]
00007dd8609df93b  lea r12, [rax+0x10]
00007dd8609df93f  movups xmm9, [r13+r12*1]
00007dd8609df945  movaps [r15+0x230], xmm9
00007dd8609df94d  movaps xmm8, xmm15
00007dd8609df951  addpd xmm8, xmm7
00007dd8609df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007dd8609df95c  ptest xmm6, xmm6
00007dd8609df961  jnz 0x00007DD8609E4387
00007dd8609df967  movaps [r15+0x130], xmm8
00007dd8609df96f  vmovaps xmm15, [rsp+0x20]
00007dd8609df975  vpermilpd xmm15, xmm15, 0x00
00007dd8609df97b  movaps xmm7, xmm9
00007dd8609df97f  mulpd xmm7, xmm15
00007dd8609df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007dd8609df989  ptest xmm6, xmm6
00007dd8609df98e  jnz 0x00007DD8609E44CA
00007dd8609df994  movaps [r15+0x220], xmm7
00007dd8609df99c  vmovaps xmm15, [rsp+0x20]
00007dd8609df9a2  vpermilpd xmm15, xmm15, 0x00
00007dd8609df9a8  movaps xmm9, xmm13
00007dd8609df9ac  mulpd xmm9, xmm15
00007dd8609df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007dd8609df9b7  ptest xmm6, xmm6
00007dd8609df9bc  jnz 0x00007DD8609E460C
00007dd8609df9c2  movaps xmm15, xmm11
00007dd8609df9c6  addpd xmm15, xmm12
00007dd8609df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007dd8609df9d1  ptest xmm13, xmm13
00007dd8609df9d7  jnz 0x00007DD8609E4750
00007dd8609df9dd  movaps [r15+0x140], xmm15
00007dd8609df9e5  movaps xmm13, xmm10
00007dd8609df9e9  addpd xmm13, xmm14
00007dd8609df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007dd8609df9f4  ptest xmm12, xmm12
00007dd8609df9fa  jnz 0x00007DD8609E4894
00007dd8609dfa00  movaps [r15+0x150], xmm13
00007dd8609dfa08  movaps xmm14, xmm1
00007dd8609dfa0c  addpd xmm14, xmm7
00007dd8609dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007dd8609dfa17  ptest xmm12, xmm12
00007dd8609dfa1d  jnz 0x00007DD8609E49D8
00007dd8609dfa23  movaps [r15+0x160], xmm14
00007dd8609dfa2b  movaps xmm1, xmm8
00007dd8609dfa2f  addpd xmm1, xmm9
00007dd8609dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007dd8609dfa39  ptest xmm12, xmm12
00007dd8609dfa3f  jnz 0x00007DD8609E4B1A
00007dd8609dfa45  movaps [r15+0x120], xmm1
00007dd8609dfa4d  movups [r13+r14*1], xmm15
00007dd8609dfa53  lea rax, [r14+0x10]
00007dd8609dfa57  movups [r13+rax*1], xmm13
00007dd8609dfa5d  lea rax, [r14+0x20]
00007dd8609dfa61  movups [r13+rax*1], xmm14
00007dd8609dfa67  lea rax, [r14+0x30]
00007dd8609dfa6b  movups [r13+rax*1], xmm1
00007dd8609dfa71  mov eax, [r15+0x108]
00007dd8609dfa78  sahf
00007dd8609dfa79  jnz 0x00007DD8609DFAAB
00007dd8609dfa7b  cmp dword ptr [r15+0x318], 0x00
00007dd8609dfa83  jz 0x00007DD8609DEAE0
00007dd8609dfa89  nop [rax+rax*1], ax
00007dd8609dfa92  nop [rax+rax*1], eax
00007dd8609dfa9a  mov eax, 0x4106D0
00007dd8609dfa9f  mov [r15+0x100], rax
00007dd8609dfaa6  jmp 0x00007DD8607FE110
00007dd8609dfaab  cmp dword ptr [r15+0x318], 0x00
00007dd8609dfab3  jz 0x00007DD8609D89C0
00007dd8609dfab9  nop [rax+rax*1], ax
00007dd8609dfac2  nop [rax+rax*1], eax
00007dd8609dfaca  mov eax, 0x410504
00007dd8609dfacf  mov [r15+0x100], rax
00007dd8609dfad6  jmp 0x00007DD8607FE110
00007dd8609dfadb  int3
00007dd8609dfadc  call 0x00007DD8608E27E0
00007dd8609dfae1  jmp 0x00007DD8609DEBBF
00007dd8609dfae6  call 0x00007DD8608E1570
00007dd8609dfaeb  jmp 0x00007DD8609DEBC8
00007dd8609dfaf0  call 0x00007DD8608E27E0
00007dd8609dfaf5  jmp 0x00007DD8609DEC24
00007dd8609dfafa  call 0x00007DD8608E1570
00007dd8609dfaff  jmp 0x00007DD8609DEC2D
00007dd8609dfb04  call 0x00007DD8608E27E0
00007dd8609dfb09  jmp 0x00007DD8609DEC70
00007dd8609dfb0e  call 0x00007DD8608E1570
00007dd8609dfb13  jmp 0x00007DD8609DEC79
00007dd8609dfb18  call 0x00007DD86080DC20
00007dd8609dfb1d  jmp 0x00007DD8609DECB8
00007dd8609dfb22  call 0x00007DD8608D59C0
00007dd8609dfb27  jmp 0x00007DD8609DECCB
00007dd8609dfb2c  call 0x00007DD8608E0E30
00007dd8609dfb31  jmp 0x00007DD8609DECE9
00007dd8609dfb36  call 0x00007DD8608DFBC0
00007dd8609dfb3b  jmp 0x00007DD8609DECF3
00007dd8609dfb40  call 0x00007DD8608DE950
00007dd8609dfb45  jmp 0x00007DD8609DECFD
00007dd8609dfb4a  sub rsp, 0x08
00007dd8609dfb4e  push rax
00007dd8609dfb4f  push rcx
00007dd8609dfb50  push rdx
00007dd8609dfb51  push rdi
00007dd8609dfb52  push rsi
00007dd8609dfb53  push r8
00007dd8609dfb55  push r9
00007dd8609dfb57  push r10
00007dd8609dfb59  push r11
00007dd8609dfb5b  sub rsp, 0xF0
00007dd8609dfb62  vmovaps [rsp], xmm0
00007dd8609dfb67  vmovaps [rsp+0x10], xmm1
00007dd8609dfb6d  vmovaps [rsp+0x20], xmm2
00007dd8609dfb73  vmovaps [rsp+0x30], xmm3
00007dd8609dfb79  vmovaps [rsp+0x40], xmm4
00007dd8609dfb7f  vmovaps [rsp+0x50], xmm5
00007dd8609dfb85  vmovaps [rsp+0x60], xmm6
00007dd8609dfb8b  vmovaps [rsp+0x70], xmm7
00007dd8609dfb91  vmovaps [rsp+0x80], xmm9
00007dd8609dfb9a  vmovaps [rsp+0x90], xmm10
00007dd8609dfba3  vmovaps [rsp+0xA0], xmm11
00007dd8609dfbac  vmovaps [rsp+0xB0], xmm12
00007dd8609dfbb5  vmovaps [rsp+0xC0], xmm13
00007dd8609dfbbe  vmovaps [rsp+0xD0], xmm14
00007dd8609dfbc7  vmovaps [rsp+0xE0], xmm15
00007dd8609dfbd0  sub rsp, 0x30
00007dd8609dfbd4  movaps [rsp], xmm8
00007dd8609dfbd9  movaps [rsp+0x10], xmm12
00007dd8609dfbdf  movaps [rsp+0x20], xmm15
00007dd8609dfbe5  lea rdi, [rsp]
00007dd8609dfbe9  mov esi, 0x00
00007dd8609dfbee  mov rax, 0x629C9CFA9530
00007dd8609dfbf8  call rax
00007dd8609dfbfa  movaps xmm8, [rsp]
00007dd8609dfbff  add rsp, 0x30
00007dd8609dfc03  vmovaps xmm0, [rsp]
00007dd8609dfc08  vmovaps xmm1, [rsp+0x10]
00007dd8609dfc0e  vmovaps xmm2, [rsp+0x20]
00007dd8609dfc14  vmovaps xmm3, [rsp+0x30]
00007dd8609dfc1a  vmovaps xmm4, [rsp+0x40]
00007dd8609dfc20  vmovaps xmm5, [rsp+0x50]
00007dd8609dfc26  vmovaps xmm6, [rsp+0x60]
00007dd8609dfc2c  vmovaps xmm7, [rsp+0x70]
00007dd8609dfc32  vmovaps xmm9, [rsp+0x80]
00007dd8609dfc3b  vmovaps xmm10, [rsp+0x90]
00007dd8609dfc44  vmovaps xmm11, [rsp+0xA0]
00007dd8609dfc4d  vmovaps xmm12, [rsp+0xB0]
00007dd8609dfc56  vmovaps xmm13, [rsp+0xC0]
00007dd8609dfc5f  vmovaps xmm14, [rsp+0xD0]
00007dd8609dfc68  vmovaps xmm15, [rsp+0xE0]
00007dd8609dfc71  add rsp, 0xF0
00007dd8609dfc78  pop r11
00007dd8609dfc7a  pop r10
00007dd8609dfc7c  pop r9
00007dd8609dfc7e  pop r8
00007dd8609dfc80  pop rsi
00007dd8609dfc81  pop rdi
00007dd8609dfc82  pop rdx
00007dd8609dfc83  pop rcx
00007dd8609dfc84  pop rax
00007dd8609dfc85  add rsp, 0x08
00007dd8609dfc89  jmp 0x00007DD8609DED27
00007dd8609dfc8e  sub rsp, 0x08
00007dd8609dfc92  push rax
00007dd8609dfc93  push rcx
00007dd8609dfc94  push rdx
00007dd8609dfc95  push rdi
00007dd8609dfc96  push rsi
00007dd8609dfc97  push r8
00007dd8609dfc99  push r9
00007dd8609dfc9b  push r10
00007dd8609dfc9d  push r11
00007dd8609dfc9f  sub rsp, 0xF0
00007dd8609dfca6  vmovaps [rsp], xmm0
00007dd8609dfcab  vmovaps [rsp+0x10], xmm1
00007dd8609dfcb1  vmovaps [rsp+0x20], xmm2
00007dd8609dfcb7  vmovaps [rsp+0x30], xmm3
00007dd8609dfcbd  vmovaps [rsp+0x40], xmm4
00007dd8609dfcc3  vmovaps [rsp+0x50], xmm5
00007dd8609dfcc9  vmovaps [rsp+0x60], xmm6
00007dd8609dfccf  vmovaps [rsp+0x70], xmm8
00007dd8609dfcd5  vmovaps [rsp+0x80], xmm9
00007dd8609dfcde  vmovaps [rsp+0x90], xmm10
00007dd8609dfce7  vmovaps [rsp+0xA0], xmm11
00007dd8609dfcf0  vmovaps [rsp+0xB0], xmm12
00007dd8609dfcf9  vmovaps [rsp+0xC0], xmm13
00007dd8609dfd02  vmovaps [rsp+0xD0], xmm14
00007dd8609dfd0b  vmovaps [rsp+0xE0], xmm15
00007dd8609dfd14  sub rsp, 0x30
00007dd8609dfd18  movaps [rsp], xmm7
00007dd8609dfd1c  movaps [rsp+0x10], xmm9
00007dd8609dfd22  movaps [rsp+0x20], xmm15
00007dd8609dfd28  lea rdi, [rsp]
00007dd8609dfd2c  mov esi, 0x00
00007dd8609dfd31  mov rax, 0x629C9CFA9530
00007dd8609dfd3b  call rax
00007dd8609dfd3d  movaps xmm7, [rsp]
00007dd8609dfd41  add rsp, 0x30
00007dd8609dfd45  vmovaps xmm0, [rsp]
00007dd8609dfd4a  vmovaps xmm1, [rsp+0x10]
00007dd8609dfd50  vmovaps xmm2, [rsp+0x20]
00007dd8609dfd56  vmovaps xmm3, [rsp+0x30]
00007dd8609dfd5c  vmovaps xmm4, [rsp+0x40]
00007dd8609dfd62  vmovaps xmm5, [rsp+0x50]
00007dd8609dfd68  vmovaps xmm6, [rsp+0x60]
00007dd8609dfd6e  vmovaps xmm8, [rsp+0x70]
00007dd8609dfd74  vmovaps xmm9, [rsp+0x80]
00007dd8609dfd7d  vmovaps xmm10, [rsp+0x90]
00007dd8609dfd86  vmovaps xmm11, [rsp+0xA0]
00007dd8609dfd8f  vmovaps xmm12, [rsp+0xB0]
00007dd8609dfd98  vmovaps xmm13, [rsp+0xC0]
00007dd8609dfda1  vmovaps xmm14, [rsp+0xD0]
00007dd8609dfdaa  vmovaps xmm15, [rsp+0xE0]
00007dd8609dfdb3  add rsp, 0xF0
00007dd8609dfdba  pop r11
00007dd8609dfdbc  pop r10
00007dd8609dfdbe  pop r9
00007dd8609dfdc0  pop r8
00007dd8609dfdc2  pop rsi
00007dd8609dfdc3  pop rdi
00007dd8609dfdc4  pop rdx
00007dd8609dfdc5  pop rcx
00007dd8609dfdc6  pop rax
00007dd8609dfdc7  add rsp, 0x08
00007dd8609dfdcb  jmp 0x00007DD8609DED55
00007dd8609dfdd0  sub rsp, 0x08
00007dd8609dfdd4  push rax
00007dd8609dfdd5  push rcx
00007dd8609dfdd6  push rdx
00007dd8609dfdd7  push rdi
00007dd8609dfdd8  push rsi
00007dd8609dfdd9  push r8
00007dd8609dfddb  push r9
00007dd8609dfddd  push r10
00007dd8609dfddf  push r11
00007dd8609dfde1  sub rsp, 0xF0
00007dd8609dfde8  vmovaps [rsp], xmm0
00007dd8609dfded  vmovaps [rsp+0x10], xmm1
00007dd8609dfdf3  vmovaps [rsp+0x20], xmm2
00007dd8609dfdf9  vmovaps [rsp+0x30], xmm3
00007dd8609dfdff  vmovaps [rsp+0x40], xmm4
00007dd8609dfe05  vmovaps [rsp+0x50], xmm5
00007dd8609dfe0b  vmovaps [rsp+0x60], xmm6
00007dd8609dfe11  vmovaps [rsp+0x70], xmm7
00007dd8609dfe17  vmovaps [rsp+0x80], xmm8
00007dd8609dfe20  vmovaps [rsp+0x90], xmm10
00007dd8609dfe29  vmovaps [rsp+0xA0], xmm11
00007dd8609dfe32  vmovaps [rsp+0xB0], xmm12
00007dd8609dfe3b  vmovaps [rsp+0xC0], xmm13
00007dd8609dfe44  vmovaps [rsp+0xD0], xmm14
00007dd8609dfe4d  vmovaps [rsp+0xE0], xmm15
00007dd8609dfe56  sub rsp, 0x30
00007dd8609dfe5a  movaps [rsp], xmm9
00007dd8609dfe5f  movaps [rsp+0x10], xmm12
00007dd8609dfe65  movaps [rsp+0x20], xmm10
00007dd8609dfe6b  lea rdi, [rsp]
00007dd8609dfe6f  mov esi, 0x00
00007dd8609dfe74  mov rax, 0x629C9CFA9530
00007dd8609dfe7e  call rax
00007dd8609dfe80  movaps xmm9, [rsp]
00007dd8609dfe85  add rsp, 0x30
00007dd8609dfe89  vmovaps xmm0, [rsp]
00007dd8609dfe8e  vmovaps xmm1, [rsp+0x10]
00007dd8609dfe94  vmovaps xmm2, [rsp+0x20]
00007dd8609dfe9a  vmovaps xmm3, [rsp+0x30]
00007dd8609dfea0  vmovaps xmm4, [rsp+0x40]
00007dd8609dfea6  vmovaps xmm5, [rsp+0x50]
00007dd8609dfeac  vmovaps xmm6, [rsp+0x60]
00007dd8609dfeb2  vmovaps xmm7, [rsp+0x70]
00007dd8609dfeb8  vmovaps xmm8, [rsp+0x80]
00007dd8609dfec1  vmovaps xmm10, [rsp+0x90]
00007dd8609dfeca  vmovaps xmm11, [rsp+0xA0]
00007dd8609dfed3  vmovaps xmm12, [rsp+0xB0]
00007dd8609dfedc  vmovaps xmm13, [rsp+0xC0]
00007dd8609dfee5  vmovaps xmm14, [rsp+0xD0]
00007dd8609dfeee  vmovaps xmm15, [rsp+0xE0]
00007dd8609dfef7  add rsp, 0xF0
00007dd8609dfefe  pop r11
00007dd8609dff00  pop r10
00007dd8609dff02  pop r9
00007dd8609dff04  pop r8
00007dd8609dff06  pop rsi
00007dd8609dff07  pop rdi
00007dd8609dff08  pop rdx
00007dd8609dff09  pop rcx
00007dd8609dff0a  pop rax
00007dd8609dff0b  add rsp, 0x08
00007dd8609dff0f  jmp 0x00007DD8609DED79
00007dd8609dff14  sub rsp, 0x08
00007dd8609dff18  push rax
00007dd8609dff19  push rcx
00007dd8609dff1a  push rdx
00007dd8609dff1b  push rdi
00007dd8609dff1c  push rsi
00007dd8609dff1d  push r8
00007dd8609dff1f  push r9
00007dd8609dff21  push r10
00007dd8609dff23  push r11
00007dd8609dff25  sub rsp, 0xF0
00007dd8609dff2c  vmovaps [rsp], xmm0
00007dd8609dff31  vmovaps [rsp+0x10], xmm1
00007dd8609dff37  vmovaps [rsp+0x20], xmm2
00007dd8609dff3d  vmovaps [rsp+0x30], xmm3
00007dd8609dff43  vmovaps [rsp+0x40], xmm4
00007dd8609dff49  vmovaps [rsp+0x50], xmm5
00007dd8609dff4f  vmovaps [rsp+0x60], xmm6
00007dd8609dff55  vmovaps [rsp+0x70], xmm7
00007dd8609dff5b  vmovaps [rsp+0x80], xmm8
00007dd8609dff64  vmovaps [rsp+0x90], xmm9
00007dd8609dff6d  vmovaps [rsp+0xA0], xmm11
00007dd8609dff76  vmovaps [rsp+0xB0], xmm12
00007dd8609dff7f  vmovaps [rsp+0xC0], xmm13
00007dd8609dff88  vmovaps [rsp+0xD0], xmm14
00007dd8609dff91  vmovaps [rsp+0xE0], xmm15
00007dd8609dff9a  sub rsp, 0x30
00007dd8609dff9e  movaps [rsp], xmm10
00007dd8609dffa3  movaps [rsp+0x10], xmm12
00007dd8609dffa9  movaps [rsp+0x20], xmm11
00007dd8609dffaf  lea rdi, [rsp]
00007dd8609dffb3  mov esi, 0x00
00007dd8609dffb8  mov rax, 0x629C9CFA9530
00007dd8609dffc2  call rax
00007dd8609dffc4  movaps xmm10, [rsp]
00007dd8609dffc9  add rsp, 0x30
00007dd8609dffcd  vmovaps xmm0, [rsp]
00007dd8609dffd2  vmovaps xmm1, [rsp+0x10]
00007dd8609dffd8  vmovaps xmm2, [rsp+0x20]
00007dd8609dffde  vmovaps xmm3, [rsp+0x30]
00007dd8609dffe4  vmovaps xmm4, [rsp+0x40]
00007dd8609dffea  vmovaps xmm5, [rsp+0x50]
00007dd8609dfff0  vmovaps xmm6, [rsp+0x60]
00007dd8609dfff6  vmovaps xmm7, [rsp+0x70]
00007dd8609dfffc  vmovaps xmm8, [rsp+0x80]
00007dd8609e0005  vmovaps xmm9, [rsp+0x90]
00007dd8609e000e  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0017  vmovaps xmm12, [rsp+0xB0]
00007dd8609e0020  vmovaps xmm13, [rsp+0xC0]
00007dd8609e0029  vmovaps xmm14, [rsp+0xD0]
00007dd8609e0032  vmovaps xmm15, [rsp+0xE0]
00007dd8609e003b  add rsp, 0xF0
00007dd8609e0042  pop r11
00007dd8609e0044  pop r10
00007dd8609e0046  pop r9
00007dd8609e0048  pop r8
00007dd8609e004a  pop rsi
00007dd8609e004b  pop rdi
00007dd8609e004c  pop rdx
00007dd8609e004d  pop rcx
00007dd8609e004e  pop rax
00007dd8609e004f  add rsp, 0x08
00007dd8609e0053  jmp 0x00007DD8609DED93
00007dd8609e0058  sub rsp, 0x08
00007dd8609e005c  push rax
00007dd8609e005d  push rcx
00007dd8609e005e  push rdx
00007dd8609e005f  push rdi
00007dd8609e0060  push rsi
00007dd8609e0061  push r8
00007dd8609e0063  push r9
00007dd8609e0065  push r10
00007dd8609e0067  push r11
00007dd8609e0069  sub rsp, 0xF0
00007dd8609e0070  vmovaps [rsp], xmm0
00007dd8609e0075  vmovaps [rsp+0x10], xmm1
00007dd8609e007b  vmovaps [rsp+0x20], xmm2
00007dd8609e0081  vmovaps [rsp+0x30], xmm3
00007dd8609e0087  vmovaps [rsp+0x40], xmm4
00007dd8609e008d  vmovaps [rsp+0x50], xmm5
00007dd8609e0093  vmovaps [rsp+0x60], xmm7
00007dd8609e0099  vmovaps [rsp+0x70], xmm8
00007dd8609e009f  vmovaps [rsp+0x80], xmm9
00007dd8609e00a8  vmovaps [rsp+0x90], xmm10
00007dd8609e00b1  vmovaps [rsp+0xA0], xmm11
00007dd8609e00ba  vmovaps [rsp+0xB0], xmm12
00007dd8609e00c3  vmovaps [rsp+0xC0], xmm13
00007dd8609e00cc  vmovaps [rsp+0xD0], xmm14
00007dd8609e00d5  vmovaps [rsp+0xE0], xmm15
00007dd8609e00de  sub rsp, 0x30
00007dd8609e00e2  movaps [rsp], xmm6
00007dd8609e00e6  movaps [rsp+0x10], xmm12
00007dd8609e00ec  movaps [rsp+0x20], xmm11
00007dd8609e00f2  lea rdi, [rsp]
00007dd8609e00f6  mov esi, 0x00
00007dd8609e00fb  mov rax, 0x629C9CFA9530
00007dd8609e0105  call rax
00007dd8609e0107  movaps xmm6, [rsp]
00007dd8609e010b  add rsp, 0x30
00007dd8609e010f  vmovaps xmm0, [rsp]
00007dd8609e0114  vmovaps xmm1, [rsp+0x10]
00007dd8609e011a  vmovaps xmm2, [rsp+0x20]
00007dd8609e0120  vmovaps xmm3, [rsp+0x30]
00007dd8609e0126  vmovaps xmm4, [rsp+0x40]
00007dd8609e012c  vmovaps xmm5, [rsp+0x50]
00007dd8609e0132  vmovaps xmm7, [rsp+0x60]
00007dd8609e0138  vmovaps xmm8, [rsp+0x70]
00007dd8609e013e  vmovaps xmm9, [rsp+0x80]
00007dd8609e0147  vmovaps xmm10, [rsp+0x90]
00007dd8609e0150  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0159  vmovaps xmm12, [rsp+0xB0]
00007dd8609e0162  vmovaps xmm13, [rsp+0xC0]
00007dd8609e016b  vmovaps xmm14, [rsp+0xD0]
00007dd8609e0174  vmovaps xmm15, [rsp+0xE0]
00007dd8609e017d  add rsp, 0xF0
00007dd8609e0184  pop r11
00007dd8609e0186  pop r10
00007dd8609e0188  pop r9
00007dd8609e018a  pop r8
00007dd8609e018c  pop rsi
00007dd8609e018d  pop rdi
00007dd8609e018e  pop rdx
00007dd8609e018f  pop rcx
00007dd8609e0190  pop rax
00007dd8609e0191  add rsp, 0x08
00007dd8609e0195  jmp 0x00007DD8609DEDB4
00007dd8609e019a  sub rsp, 0x08
00007dd8609e019e  push rax
00007dd8609e019f  push rcx
00007dd8609e01a0  push rdx
00007dd8609e01a1  push rdi
00007dd8609e01a2  push rsi
00007dd8609e01a3  push r8
00007dd8609e01a5  push r9
00007dd8609e01a7  push r10
00007dd8609e01a9  push r11
00007dd8609e01ab  sub rsp, 0xF0
00007dd8609e01b2  vmovaps [rsp], xmm0
00007dd8609e01b7  vmovaps [rsp+0x10], xmm1
00007dd8609e01bd  vmovaps [rsp+0x20], xmm2
00007dd8609e01c3  vmovaps [rsp+0x30], xmm4
00007dd8609e01c9  vmovaps [rsp+0x40], xmm5
00007dd8609e01cf  vmovaps [rsp+0x50], xmm6
00007dd8609e01d5  vmovaps [rsp+0x60], xmm7
00007dd8609e01db  vmovaps [rsp+0x70], xmm8
00007dd8609e01e1  vmovaps [rsp+0x80], xmm9
00007dd8609e01ea  vmovaps [rsp+0x90], xmm10
00007dd8609e01f3  vmovaps [rsp+0xA0], xmm11
00007dd8609e01fc  vmovaps [rsp+0xB0], xmm12
00007dd8609e0205  vmovaps [rsp+0xC0], xmm13
00007dd8609e020e  vmovaps [rsp+0xD0], xmm14
00007dd8609e0217  vmovaps [rsp+0xE0], xmm15
00007dd8609e0220  sub rsp, 0x30
00007dd8609e0224  movaps [rsp], xmm3
00007dd8609e0228  movaps [rsp+0x10], xmm5
00007dd8609e022d  movaps [rsp+0x20], xmm4
00007dd8609e0232  lea rdi, [rsp]
00007dd8609e0236  mov esi, 0x00
00007dd8609e023b  mov rax, 0x629C9CFA9530
00007dd8609e0245  call rax
00007dd8609e0247  movaps xmm3, [rsp]
00007dd8609e024b  add rsp, 0x30
00007dd8609e024f  vmovaps xmm0, [rsp]
00007dd8609e0254  vmovaps xmm1, [rsp+0x10]
00007dd8609e025a  vmovaps xmm2, [rsp+0x20]
00007dd8609e0260  vmovaps xmm4, [rsp+0x30]
00007dd8609e0266  vmovaps xmm5, [rsp+0x40]
00007dd8609e026c  vmovaps xmm6, [rsp+0x50]
00007dd8609e0272  vmovaps xmm7, [rsp+0x60]
00007dd8609e0278  vmovaps xmm8, [rsp+0x70]
00007dd8609e027e  vmovaps xmm9, [rsp+0x80]
00007dd8609e0287  vmovaps xmm10, [rsp+0x90]
00007dd8609e0290  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0299  vmovaps xmm12, [rsp+0xB0]
00007dd8609e02a2  vmovaps xmm13, [rsp+0xC0]
00007dd8609e02ab  vmovaps xmm14, [rsp+0xD0]
00007dd8609e02b4  vmovaps xmm15, [rsp+0xE0]
00007dd8609e02bd  add rsp, 0xF0
00007dd8609e02c4  pop r11
00007dd8609e02c6  pop r10
00007dd8609e02c8  pop r9
00007dd8609e02ca  pop r8
00007dd8609e02cc  pop rsi
00007dd8609e02cd  pop rdi
00007dd8609e02ce  pop rdx
00007dd8609e02cf  pop rcx
00007dd8609e02d0  pop rax
00007dd8609e02d1  add rsp, 0x08
00007dd8609e02d5  jmp 0x00007DD8609DEE15
00007dd8609e02da  sub rsp, 0x08
00007dd8609e02de  push rax
00007dd8609e02df  push rcx
00007dd8609e02e0  push rdx
00007dd8609e02e1  push rdi
00007dd8609e02e2  push rsi
00007dd8609e02e3  push r8
00007dd8609e02e5  push r9
00007dd8609e02e7  push r10
00007dd8609e02e9  push r11
00007dd8609e02eb  sub rsp, 0xF0
00007dd8609e02f2  vmovaps [rsp], xmm0
00007dd8609e02f7  vmovaps [rsp+0x10], xmm1
00007dd8609e02fd  vmovaps [rsp+0x20], xmm2
00007dd8609e0303  vmovaps [rsp+0x30], xmm3
00007dd8609e0309  vmovaps [rsp+0x40], xmm4
00007dd8609e030f  vmovaps [rsp+0x50], xmm6
00007dd8609e0315  vmovaps [rsp+0x60], xmm7
00007dd8609e031b  vmovaps [rsp+0x70], xmm8
00007dd8609e0321  vmovaps [rsp+0x80], xmm9
00007dd8609e032a  vmovaps [rsp+0x90], xmm10
00007dd8609e0333  vmovaps [rsp+0xA0], xmm11
00007dd8609e033c  vmovaps [rsp+0xB0], xmm12
00007dd8609e0345  vmovaps [rsp+0xC0], xmm13
00007dd8609e034e  vmovaps [rsp+0xD0], xmm14
00007dd8609e0357  vmovaps [rsp+0xE0], xmm15
00007dd8609e0360  sub rsp, 0x30
00007dd8609e0364  movaps [rsp], xmm5
00007dd8609e0368  movaps [rsp+0x10], xmm8
00007dd8609e036e  movaps [rsp+0x20], xmm15
00007dd8609e0374  lea rdi, [rsp]
00007dd8609e0378  mov esi, 0x00
00007dd8609e037d  mov rax, 0x629C9CFA9530
00007dd8609e0387  call rax
00007dd8609e0389  movaps xmm5, [rsp]
00007dd8609e038d  add rsp, 0x30
00007dd8609e0391  vmovaps xmm0, [rsp]
00007dd8609e0396  vmovaps xmm1, [rsp+0x10]
00007dd8609e039c  vmovaps xmm2, [rsp+0x20]
00007dd8609e03a2  vmovaps xmm3, [rsp+0x30]
00007dd8609e03a8  vmovaps xmm4, [rsp+0x40]
00007dd8609e03ae  vmovaps xmm6, [rsp+0x50]
00007dd8609e03b4  vmovaps xmm7, [rsp+0x60]
00007dd8609e03ba  vmovaps xmm8, [rsp+0x70]
00007dd8609e03c0  vmovaps xmm9, [rsp+0x80]
00007dd8609e03c9  vmovaps xmm10, [rsp+0x90]
00007dd8609e03d2  vmovaps xmm11, [rsp+0xA0]
00007dd8609e03db  vmovaps xmm12, [rsp+0xB0]
00007dd8609e03e4  vmovaps xmm13, [rsp+0xC0]
00007dd8609e03ed  vmovaps xmm14, [rsp+0xD0]
00007dd8609e03f6  vmovaps xmm15, [rsp+0xE0]
00007dd8609e03ff  add rsp, 0xF0
00007dd8609e0406  pop r11
00007dd8609e0408  pop r10
00007dd8609e040a  pop r9
00007dd8609e040c  pop r8
00007dd8609e040e  pop rsi
00007dd8609e040f  pop rdi
00007dd8609e0410  pop rdx
00007dd8609e0411  pop rcx
00007dd8609e0412  pop rax
00007dd8609e0413  add rsp, 0x08
00007dd8609e0417  jmp 0x00007DD8609DEE53
00007dd8609e041c  sub rsp, 0x08
00007dd8609e0420  push rax
00007dd8609e0421  push rcx
00007dd8609e0422  push rdx
00007dd8609e0423  push rdi
00007dd8609e0424  push rsi
00007dd8609e0425  push r8
00007dd8609e0427  push r9
00007dd8609e0429  push r10
00007dd8609e042b  push r11
00007dd8609e042d  sub rsp, 0xF0
00007dd8609e0434  vmovaps [rsp], xmm0
00007dd8609e0439  vmovaps [rsp+0x10], xmm1
00007dd8609e043f  vmovaps [rsp+0x20], xmm2
00007dd8609e0445  vmovaps [rsp+0x30], xmm3
00007dd8609e044b  vmovaps [rsp+0x40], xmm5
00007dd8609e0451  vmovaps [rsp+0x50], xmm6
00007dd8609e0457  vmovaps [rsp+0x60], xmm7
00007dd8609e045d  vmovaps [rsp+0x70], xmm8
00007dd8609e0463  vmovaps [rsp+0x80], xmm9
00007dd8609e046c  vmovaps [rsp+0x90], xmm10
00007dd8609e0475  vmovaps [rsp+0xA0], xmm11
00007dd8609e047e  vmovaps [rsp+0xB0], xmm12
00007dd8609e0487  vmovaps [rsp+0xC0], xmm13
00007dd8609e0490  vmovaps [rsp+0xD0], xmm14
00007dd8609e0499  vmovaps [rsp+0xE0], xmm15
00007dd8609e04a2  sub rsp, 0x30
00007dd8609e04a6  movaps [rsp], xmm4
00007dd8609e04aa  movaps [rsp+0x10], xmm9
00007dd8609e04b0  movaps [rsp+0x20], xmm8
00007dd8609e04b6  lea rdi, [rsp]
00007dd8609e04ba  mov esi, 0x00
00007dd8609e04bf  mov rax, 0x629C9CFA9530
00007dd8609e04c9  call rax
00007dd8609e04cb  movaps xmm4, [rsp]
00007dd8609e04cf  add rsp, 0x30
00007dd8609e04d3  vmovaps xmm0, [rsp]
00007dd8609e04d8  vmovaps xmm1, [rsp+0x10]
00007dd8609e04de  vmovaps xmm2, [rsp+0x20]
00007dd8609e04e4  vmovaps xmm3, [rsp+0x30]
00007dd8609e04ea  vmovaps xmm5, [rsp+0x40]
00007dd8609e04f0  vmovaps xmm6, [rsp+0x50]
00007dd8609e04f6  vmovaps xmm7, [rsp+0x60]
00007dd8609e04fc  vmovaps xmm8, [rsp+0x70]
00007dd8609e0502  vmovaps xmm9, [rsp+0x80]
00007dd8609e050b  vmovaps xmm10, [rsp+0x90]
00007dd8609e0514  vmovaps xmm11, [rsp+0xA0]
00007dd8609e051d  vmovaps xmm12, [rsp+0xB0]
00007dd8609e0526  vmovaps xmm13, [rsp+0xC0]
00007dd8609e052f  vmovaps xmm14, [rsp+0xD0]
00007dd8609e0538  vmovaps xmm15, [rsp+0xE0]
00007dd8609e0541  add rsp, 0xF0
00007dd8609e0548  pop r11
00007dd8609e054a  pop r10
00007dd8609e054c  pop r9
00007dd8609e054e  pop r8
00007dd8609e0550  pop rsi
00007dd8609e0551  pop rdi
00007dd8609e0552  pop rdx
00007dd8609e0553  pop rcx
00007dd8609e0554  pop rax
00007dd8609e0555  add rsp, 0x08
00007dd8609e0559  jmp 0x00007DD8609DEE74
00007dd8609e055e  sub rsp, 0x08
00007dd8609e0562  push rax
00007dd8609e0563  push rcx
00007dd8609e0564  push rdx
00007dd8609e0565  push rdi
00007dd8609e0566  push rsi
00007dd8609e0567  push r8
00007dd8609e0569  push r9
00007dd8609e056b  push r10
00007dd8609e056d  push r11
00007dd8609e056f  sub rsp, 0xF0
00007dd8609e0576  vmovaps [rsp], xmm0
00007dd8609e057b  vmovaps [rsp+0x10], xmm1
00007dd8609e0581  vmovaps [rsp+0x20], xmm2
00007dd8609e0587  vmovaps [rsp+0x30], xmm3
00007dd8609e058d  vmovaps [rsp+0x40], xmm4
00007dd8609e0593  vmovaps [rsp+0x50], xmm5
00007dd8609e0599  vmovaps [rsp+0x60], xmm6
00007dd8609e059f  vmovaps [rsp+0x70], xmm7
00007dd8609e05a5  vmovaps [rsp+0x80], xmm8
00007dd8609e05ae  vmovaps [rsp+0x90], xmm10
00007dd8609e05b7  vmovaps [rsp+0xA0], xmm11
00007dd8609e05c0  vmovaps [rsp+0xB0], xmm12
00007dd8609e05c9  vmovaps [rsp+0xC0], xmm13
00007dd8609e05d2  vmovaps [rsp+0xD0], xmm14
00007dd8609e05db  vmovaps [rsp+0xE0], xmm15
00007dd8609e05e4  sub rsp, 0x30
00007dd8609e05e8  movaps [rsp], xmm9
00007dd8609e05ed  movaps [rsp+0x10], xmm10
00007dd8609e05f3  movaps [rsp+0x20], xmm8
00007dd8609e05f9  lea rdi, [rsp]
00007dd8609e05fd  mov esi, 0x00
00007dd8609e0602  mov rax, 0x629C9CFA9530
00007dd8609e060c  call rax
00007dd8609e060e  movaps xmm9, [rsp]
00007dd8609e0613  add rsp, 0x30
00007dd8609e0617  vmovaps xmm0, [rsp]
00007dd8609e061c  vmovaps xmm1, [rsp+0x10]
00007dd8609e0622  vmovaps xmm2, [rsp+0x20]
00007dd8609e0628  vmovaps xmm3, [rsp+0x30]
00007dd8609e062e  vmovaps xmm4, [rsp+0x40]
00007dd8609e0634  vmovaps xmm5, [rsp+0x50]
00007dd8609e063a  vmovaps xmm6, [rsp+0x60]
00007dd8609e0640  vmovaps xmm7, [rsp+0x70]
00007dd8609e0646  vmovaps xmm8, [rsp+0x80]
00007dd8609e064f  vmovaps xmm10, [rsp+0x90]
00007dd8609e0658  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0661  vmovaps xmm12, [rsp+0xB0]
00007dd8609e066a  vmovaps xmm13, [rsp+0xC0]
00007dd8609e0673  vmovaps xmm14, [rsp+0xD0]
00007dd8609e067c  vmovaps xmm15, [rsp+0xE0]
00007dd8609e0685  add rsp, 0xF0
00007dd8609e068c  pop r11
00007dd8609e068e  pop r10
00007dd8609e0690  pop r9
00007dd8609e0692  pop r8
00007dd8609e0694  pop rsi
00007dd8609e0695  pop rdi
00007dd8609e0696  pop rdx
00007dd8609e0697  pop rcx
00007dd8609e0698  pop rax
00007dd8609e0699  add rsp, 0x08
00007dd8609e069d  jmp 0x00007DD8609DEE8E
00007dd8609e06a2  call 0x00007DD8608B52F0
00007dd8609e06a7  jmp 0x00007DD8609DEFA8
00007dd8609e06ac  call 0x00007DD8608B52F0
00007dd8609e06b1  jmp 0x00007DD8609DEFBE
00007dd8609e06b6  sub rsp, 0x08
00007dd8609e06ba  push rax
00007dd8609e06bb  push rcx
00007dd8609e06bc  push rdx
00007dd8609e06bd  push rdi
00007dd8609e06be  push rsi
00007dd8609e06bf  push r8
00007dd8609e06c1  push r9
00007dd8609e06c3  push r10
00007dd8609e06c5  push r11
00007dd8609e06c7  sub rsp, 0xF0
00007dd8609e06ce  vmovaps [rsp], xmm0
00007dd8609e06d3  vmovaps [rsp+0x10], xmm2
00007dd8609e06d9  vmovaps [rsp+0x20], xmm3
00007dd8609e06df  vmovaps [rsp+0x30], xmm4
00007dd8609e06e5  vmovaps [rsp+0x40], xmm5
00007dd8609e06eb  vmovaps [rsp+0x50], xmm6
00007dd8609e06f1  vmovaps [rsp+0x60], xmm7
00007dd8609e06f7  vmovaps [rsp+0x70], xmm8
00007dd8609e06fd  vmovaps [rsp+0x80], xmm9
00007dd8609e0706  vmovaps [rsp+0x90], xmm10
00007dd8609e070f  vmovaps [rsp+0xA0], xmm11
00007dd8609e0718  vmovaps [rsp+0xB0], xmm12
00007dd8609e0721  vmovaps [rsp+0xC0], xmm13
00007dd8609e072a  vmovaps [rsp+0xD0], xmm14
00007dd8609e0733  vmovaps [rsp+0xE0], xmm15
00007dd8609e073c  sub rsp, 0x30
00007dd8609e0740  movaps [rsp], xmm1
00007dd8609e0744  movaps [rsp+0x10], xmm6
00007dd8609e0749  movaps [rsp+0x20], xmm15
00007dd8609e074f  lea rdi, [rsp]
00007dd8609e0753  mov esi, 0x00
00007dd8609e0758  mov rax, 0x629C9CFA9530
00007dd8609e0762  call rax
00007dd8609e0764  movaps xmm1, [rsp]
00007dd8609e0768  add rsp, 0x30
00007dd8609e076c  vmovaps xmm0, [rsp]
00007dd8609e0771  vmovaps xmm2, [rsp+0x10]
00007dd8609e0777  vmovaps xmm3, [rsp+0x20]
00007dd8609e077d  vmovaps xmm4, [rsp+0x30]
00007dd8609e0783  vmovaps xmm5, [rsp+0x40]
00007dd8609e0789  vmovaps xmm6, [rsp+0x50]
00007dd8609e078f  vmovaps xmm7, [rsp+0x60]
00007dd8609e0795  vmovaps xmm8, [rsp+0x70]
00007dd8609e079b  vmovaps xmm9, [rsp+0x80]
00007dd8609e07a4  vmovaps xmm10, [rsp+0x90]
00007dd8609e07ad  vmovaps xmm11, [rsp+0xA0]
00007dd8609e07b6  vmovaps xmm12, [rsp+0xB0]
00007dd8609e07bf  vmovaps xmm13, [rsp+0xC0]
00007dd8609e07c8  vmovaps xmm14, [rsp+0xD0]
00007dd8609e07d1  vmovaps xmm15, [rsp+0xE0]
00007dd8609e07da  add rsp, 0xF0
00007dd8609e07e1  pop r11
00007dd8609e07e3  pop r10
00007dd8609e07e5  pop r9
00007dd8609e07e7  pop r8
00007dd8609e07e9  pop rsi
00007dd8609e07ea  pop rdi
00007dd8609e07eb  pop rdx
00007dd8609e07ec  pop rcx
00007dd8609e07ed  pop rax
00007dd8609e07ee  add rsp, 0x08
00007dd8609e07f2  jmp 0x00007DD8609DEFFB
00007dd8609e07f7  call 0x00007DD8608C4620
00007dd8609e07fc  jmp 0x00007DD8609DF008
00007dd8609e0801  sub rsp, 0x08
00007dd8609e0805  push rax
00007dd8609e0806  push rcx
00007dd8609e0807  push rdx
00007dd8609e0808  push rdi
00007dd8609e0809  push rsi
00007dd8609e080a  push r8
00007dd8609e080c  push r9
00007dd8609e080e  push r10
00007dd8609e0810  push r11
00007dd8609e0812  sub rsp, 0xF0
00007dd8609e0819  vmovaps [rsp], xmm0
00007dd8609e081e  vmovaps [rsp+0x10], xmm1
00007dd8609e0824  vmovaps [rsp+0x20], xmm2
00007dd8609e082a  vmovaps [rsp+0x30], xmm3
00007dd8609e0830  vmovaps [rsp+0x40], xmm4
00007dd8609e0836  vmovaps [rsp+0x50], xmm5
00007dd8609e083c  vmovaps [rsp+0x60], xmm6
00007dd8609e0842  vmovaps [rsp+0x70], xmm7
00007dd8609e0848  vmovaps [rsp+0x80], xmm8
00007dd8609e0851  vmovaps [rsp+0x90], xmm9
00007dd8609e085a  vmovaps [rsp+0xA0], xmm10
00007dd8609e0863  vmovaps [rsp+0xB0], xmm11
00007dd8609e086c  vmovaps [rsp+0xC0], xmm12
00007dd8609e0875  vmovaps [rsp+0xD0], xmm13
00007dd8609e087e  vmovaps [rsp+0xE0], xmm15
00007dd8609e0887  sub rsp, 0x30
00007dd8609e088b  movaps [rsp], xmm14
00007dd8609e0890  movaps [rsp+0x10], xmm4
00007dd8609e0895  movaps [rsp+0x20], xmm3
00007dd8609e089a  lea rdi, [rsp]
00007dd8609e089e  mov esi, 0x00
00007dd8609e08a3  mov rax, 0x629C9CFA9530
00007dd8609e08ad  call rax
00007dd8609e08af  movaps xmm14, [rsp]
00007dd8609e08b4  add rsp, 0x30
00007dd8609e08b8  vmovaps xmm0, [rsp]
00007dd8609e08bd  vmovaps xmm1, [rsp+0x10]
00007dd8609e08c3  vmovaps xmm2, [rsp+0x20]
00007dd8609e08c9  vmovaps xmm3, [rsp+0x30]
00007dd8609e08cf  vmovaps xmm4, [rsp+0x40]
00007dd8609e08d5  vmovaps xmm5, [rsp+0x50]
00007dd8609e08db  vmovaps xmm6, [rsp+0x60]
00007dd8609e08e1  vmovaps xmm7, [rsp+0x70]
00007dd8609e08e7  vmovaps xmm8, [rsp+0x80]
00007dd8609e08f0  vmovaps xmm9, [rsp+0x90]
00007dd8609e08f9  vmovaps xmm10, [rsp+0xA0]
00007dd8609e0902  vmovaps xmm11, [rsp+0xB0]
00007dd8609e090b  vmovaps xmm12, [rsp+0xC0]
00007dd8609e0914  vmovaps xmm13, [rsp+0xD0]
00007dd8609e091d  vmovaps xmm15, [rsp+0xE0]
00007dd8609e0926  add rsp, 0xF0
00007dd8609e092d  pop r11
00007dd8609e092f  pop r10
00007dd8609e0931  pop r9
00007dd8609e0933  pop r8
00007dd8609e0935  pop rsi
00007dd8609e0936  pop rdi
00007dd8609e0937  pop rdx
00007dd8609e0938  pop rcx
00007dd8609e0939  pop rax
00007dd8609e093a  add rsp, 0x08
00007dd8609e093e  jmp 0x00007DD8609DF022
00007dd8609e0943  sub rsp, 0x08
00007dd8609e0947  push rax
00007dd8609e0948  push rcx
00007dd8609e0949  push rdx
00007dd8609e094a  push rdi
00007dd8609e094b  push rsi
00007dd8609e094c  push r8
00007dd8609e094e  push r9
00007dd8609e0950  push r10
00007dd8609e0952  push r11
00007dd8609e0954  sub rsp, 0xF0
00007dd8609e095b  vmovaps [rsp], xmm0
00007dd8609e0960  vmovaps [rsp+0x10], xmm1
00007dd8609e0966  vmovaps [rsp+0x20], xmm2
00007dd8609e096c  vmovaps [rsp+0x30], xmm3
00007dd8609e0972  vmovaps [rsp+0x40], xmm4
00007dd8609e0978  vmovaps [rsp+0x50], xmm5
00007dd8609e097e  vmovaps [rsp+0x60], xmm7
00007dd8609e0984  vmovaps [rsp+0x70], xmm8
00007dd8609e098a  vmovaps [rsp+0x80], xmm9
00007dd8609e0993  vmovaps [rsp+0x90], xmm10
00007dd8609e099c  vmovaps [rsp+0xA0], xmm11
00007dd8609e09a5  vmovaps [rsp+0xB0], xmm12
00007dd8609e09ae  vmovaps [rsp+0xC0], xmm13
00007dd8609e09b7  vmovaps [rsp+0xD0], xmm14
00007dd8609e09c0  vmovaps [rsp+0xE0], xmm15
00007dd8609e09c9  sub rsp, 0x30
00007dd8609e09cd  movaps [rsp], xmm6
00007dd8609e09d1  movaps [rsp+0x10], xmm9
00007dd8609e09d7  movaps [rsp+0x20], xmm7
00007dd8609e09dc  lea rdi, [rsp]
00007dd8609e09e0  mov esi, 0x00
00007dd8609e09e5  mov rax, 0x629C9CFA9530
00007dd8609e09ef  call rax
00007dd8609e09f1  movaps xmm6, [rsp]
00007dd8609e09f5  add rsp, 0x30
00007dd8609e09f9  vmovaps xmm0, [rsp]
00007dd8609e09fe  vmovaps xmm1, [rsp+0x10]
00007dd8609e0a04  vmovaps xmm2, [rsp+0x20]
00007dd8609e0a0a  vmovaps xmm3, [rsp+0x30]
00007dd8609e0a10  vmovaps xmm4, [rsp+0x40]
00007dd8609e0a16  vmovaps xmm5, [rsp+0x50]
00007dd8609e0a1c  vmovaps xmm7, [rsp+0x60]
00007dd8609e0a22  vmovaps xmm8, [rsp+0x70]
00007dd8609e0a28  vmovaps xmm9, [rsp+0x80]
00007dd8609e0a31  vmovaps xmm10, [rsp+0x90]
00007dd8609e0a3a  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0a43  vmovaps xmm12, [rsp+0xB0]
00007dd8609e0a4c  vmovaps xmm13, [rsp+0xC0]
00007dd8609e0a55  vmovaps xmm14, [rsp+0xD0]
00007dd8609e0a5e  vmovaps xmm15, [rsp+0xE0]
00007dd8609e0a67  add rsp, 0xF0
00007dd8609e0a6e  pop r11
00007dd8609e0a70  pop r10
00007dd8609e0a72  pop r9
00007dd8609e0a74  pop r8
00007dd8609e0a76  pop rsi
00007dd8609e0a77  pop rdi
00007dd8609e0a78  pop rdx
00007dd8609e0a79  pop rcx
00007dd8609e0a7a  pop rax
00007dd8609e0a7b  add rsp, 0x08
00007dd8609e0a7f  jmp 0x00007DD8609DF03A
00007dd8609e0a84  sub rsp, 0x08
00007dd8609e0a88  push rax
00007dd8609e0a89  push rcx
00007dd8609e0a8a  push rdx
00007dd8609e0a8b  push rdi
00007dd8609e0a8c  push rsi
00007dd8609e0a8d  push r8
00007dd8609e0a8f  push r9
00007dd8609e0a91  push r10
00007dd8609e0a93  push r11
00007dd8609e0a95  sub rsp, 0xF0
00007dd8609e0a9c  vmovaps [rsp], xmm0
00007dd8609e0aa1  vmovaps [rsp+0x10], xmm1
00007dd8609e0aa7  vmovaps [rsp+0x20], xmm2
00007dd8609e0aad  vmovaps [rsp+0x30], xmm3
00007dd8609e0ab3  vmovaps [rsp+0x40], xmm4
00007dd8609e0ab9  vmovaps [rsp+0x50], xmm5
00007dd8609e0abf  vmovaps [rsp+0x60], xmm6
00007dd8609e0ac5  vmovaps [rsp+0x70], xmm8
00007dd8609e0acb  vmovaps [rsp+0x80], xmm9
00007dd8609e0ad4  vmovaps [rsp+0x90], xmm10
00007dd8609e0add  vmovaps [rsp+0xA0], xmm11
00007dd8609e0ae6  vmovaps [rsp+0xB0], xmm12
00007dd8609e0aef  vmovaps [rsp+0xC0], xmm13
00007dd8609e0af8  vmovaps [rsp+0xD0], xmm14
00007dd8609e0b01  vmovaps [rsp+0xE0], xmm15
00007dd8609e0b0a  sub rsp, 0x30
00007dd8609e0b0e  movaps [rsp], xmm7
00007dd8609e0b12  movaps [rsp+0x10], xmm4
00007dd8609e0b17  movaps [rsp+0x20], xmm9
00007dd8609e0b1d  lea rdi, [rsp]
00007dd8609e0b21  mov esi, 0x00
00007dd8609e0b26  mov rax, 0x629C9CFA9530
00007dd8609e0b30  call rax
00007dd8609e0b32  movaps xmm7, [rsp]
00007dd8609e0b36  add rsp, 0x30
00007dd8609e0b3a  vmovaps xmm0, [rsp]
00007dd8609e0b3f  vmovaps xmm1, [rsp+0x10]
00007dd8609e0b45  vmovaps xmm2, [rsp+0x20]
00007dd8609e0b4b  vmovaps xmm3, [rsp+0x30]
00007dd8609e0b51  vmovaps xmm4, [rsp+0x40]
00007dd8609e0b57  vmovaps xmm5, [rsp+0x50]
00007dd8609e0b5d  vmovaps xmm6, [rsp+0x60]
00007dd8609e0b63  vmovaps xmm8, [rsp+0x70]
00007dd8609e0b69  vmovaps xmm9, [rsp+0x80]
00007dd8609e0b72  vmovaps xmm10, [rsp+0x90]
00007dd8609e0b7b  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0b84  vmovaps xmm12, [rsp+0xB0]
00007dd8609e0b8d  vmovaps xmm13, [rsp+0xC0]
00007dd8609e0b96  vmovaps xmm14, [rsp+0xD0]
00007dd8609e0b9f  vmovaps xmm15, [rsp+0xE0]
00007dd8609e0ba8  add rsp, 0xF0
00007dd8609e0baf  pop r11
00007dd8609e0bb1  pop r10
00007dd8609e0bb3  pop r9
00007dd8609e0bb5  pop r8
00007dd8609e0bb7  pop rsi
00007dd8609e0bb8  pop rdi
00007dd8609e0bb9  pop rdx
00007dd8609e0bba  pop rcx
00007dd8609e0bbb  pop rax
00007dd8609e0bbc  add rsp, 0x08
00007dd8609e0bc0  jmp 0x00007DD8609DF067
00007dd8609e0bc5  sub rsp, 0x08
00007dd8609e0bc9  push rax
00007dd8609e0bca  push rcx
00007dd8609e0bcb  push rdx
00007dd8609e0bcc  push rdi
00007dd8609e0bcd  push rsi
00007dd8609e0bce  push r8
00007dd8609e0bd0  push r9
00007dd8609e0bd2  push r10
00007dd8609e0bd4  push r11
00007dd8609e0bd6  sub rsp, 0xF0
00007dd8609e0bdd  vmovaps [rsp], xmm0
00007dd8609e0be2  vmovaps [rsp+0x10], xmm1
00007dd8609e0be8  vmovaps [rsp+0x20], xmm2
00007dd8609e0bee  vmovaps [rsp+0x30], xmm3
00007dd8609e0bf4  vmovaps [rsp+0x40], xmm5
00007dd8609e0bfa  vmovaps [rsp+0x50], xmm6
00007dd8609e0c00  vmovaps [rsp+0x60], xmm7
00007dd8609e0c06  vmovaps [rsp+0x70], xmm8
00007dd8609e0c0c  vmovaps [rsp+0x80], xmm9
00007dd8609e0c15  vmovaps [rsp+0x90], xmm10
00007dd8609e0c1e  vmovaps [rsp+0xA0], xmm11
00007dd8609e0c27  vmovaps [rsp+0xB0], xmm12
00007dd8609e0c30  vmovaps [rsp+0xC0], xmm13
00007dd8609e0c39  vmovaps [rsp+0xD0], xmm14
00007dd8609e0c42  vmovaps [rsp+0xE0], xmm15
00007dd8609e0c4b  sub rsp, 0x30
00007dd8609e0c4f  movaps [rsp], xmm4
00007dd8609e0c53  movaps [rsp+0x10], xmm15
00007dd8609e0c59  movaps [rsp+0x20], xmm9
00007dd8609e0c5f  lea rdi, [rsp]
00007dd8609e0c63  mov esi, 0x00
00007dd8609e0c68  mov rax, 0x629C9CFA9530
00007dd8609e0c72  call rax
00007dd8609e0c74  movaps xmm4, [rsp]
00007dd8609e0c78  add rsp, 0x30
00007dd8609e0c7c  vmovaps xmm0, [rsp]
00007dd8609e0c81  vmovaps xmm1, [rsp+0x10]
00007dd8609e0c87  vmovaps xmm2, [rsp+0x20]
00007dd8609e0c8d  vmovaps xmm3, [rsp+0x30]
00007dd8609e0c93  vmovaps xmm5, [rsp+0x40]
00007dd8609e0c99  vmovaps xmm6, [rsp+0x50]
00007dd8609e0c9f  vmovaps xmm7, [rsp+0x60]
00007dd8609e0ca5  vmovaps xmm8, [rsp+0x70]
00007dd8609e0cab  vmovaps xmm9, [rsp+0x80]
00007dd8609e0cb4  vmovaps xmm10, [rsp+0x90]
00007dd8609e0cbd  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0cc6  vmovaps xmm12, [rsp+0xB0]
00007dd8609e0ccf  vmovaps xmm13, [rsp+0xC0]
00007dd8609e0cd8  vmovaps xmm14, [rsp+0xD0]
00007dd8609e0ce1  vmovaps xmm15, [rsp+0xE0]
00007dd8609e0cea  add rsp, 0xF0
00007dd8609e0cf1  pop r11
00007dd8609e0cf3  pop r10
00007dd8609e0cf5  pop r9
00007dd8609e0cf7  pop r8
00007dd8609e0cf9  pop rsi
00007dd8609e0cfa  pop rdi
00007dd8609e0cfb  pop rdx
00007dd8609e0cfc  pop rcx
00007dd8609e0cfd  pop rax
00007dd8609e0cfe  add rsp, 0x08
00007dd8609e0d02  jmp 0x00007DD8609DF08C
00007dd8609e0d07  call 0x00007DD8608C4620
00007dd8609e0d0c  jmp 0x00007DD8609DF099
00007dd8609e0d11  sub rsp, 0x08
00007dd8609e0d15  push rax
00007dd8609e0d16  push rcx
00007dd8609e0d17  push rdx
00007dd8609e0d18  push rdi
00007dd8609e0d19  push rsi
00007dd8609e0d1a  push r8
00007dd8609e0d1c  push r9
00007dd8609e0d1e  push r10
00007dd8609e0d20  push r11
00007dd8609e0d22  sub rsp, 0xF0
00007dd8609e0d29  vmovaps [rsp], xmm0
00007dd8609e0d2e  vmovaps [rsp+0x10], xmm1
00007dd8609e0d34  vmovaps [rsp+0x20], xmm2
00007dd8609e0d3a  vmovaps [rsp+0x30], xmm4
00007dd8609e0d40  vmovaps [rsp+0x40], xmm5
00007dd8609e0d46  vmovaps [rsp+0x50], xmm6
00007dd8609e0d4c  vmovaps [rsp+0x60], xmm7
00007dd8609e0d52  vmovaps [rsp+0x70], xmm8
00007dd8609e0d58  vmovaps [rsp+0x80], xmm9
00007dd8609e0d61  vmovaps [rsp+0x90], xmm10
00007dd8609e0d6a  vmovaps [rsp+0xA0], xmm11
00007dd8609e0d73  vmovaps [rsp+0xB0], xmm12
00007dd8609e0d7c  vmovaps [rsp+0xC0], xmm13
00007dd8609e0d85  vmovaps [rsp+0xD0], xmm14
00007dd8609e0d8e  vmovaps [rsp+0xE0], xmm15
00007dd8609e0d97  sub rsp, 0x30
00007dd8609e0d9b  movaps [rsp], xmm3
00007dd8609e0d9f  movaps [rsp+0x10], xmm1
00007dd8609e0da4  movaps [rsp+0x20], xmm9
00007dd8609e0daa  lea rdi, [rsp]
00007dd8609e0dae  mov esi, 0x00
00007dd8609e0db3  mov rax, 0x629C9CFA9530
00007dd8609e0dbd  call rax
00007dd8609e0dbf  movaps xmm3, [rsp]
00007dd8609e0dc3  add rsp, 0x30
00007dd8609e0dc7  vmovaps xmm0, [rsp]
00007dd8609e0dcc  vmovaps xmm1, [rsp+0x10]
00007dd8609e0dd2  vmovaps xmm2, [rsp+0x20]
00007dd8609e0dd8  vmovaps xmm4, [rsp+0x30]
00007dd8609e0dde  vmovaps xmm5, [rsp+0x40]
00007dd8609e0de4  vmovaps xmm6, [rsp+0x50]
00007dd8609e0dea  vmovaps xmm7, [rsp+0x60]
00007dd8609e0df0  vmovaps xmm8, [rsp+0x70]
00007dd8609e0df6  vmovaps xmm9, [rsp+0x80]
00007dd8609e0dff  vmovaps xmm10, [rsp+0x90]
00007dd8609e0e08  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0e11  vmovaps xmm12, [rsp+0xB0]
00007dd8609e0e1a  vmovaps xmm13, [rsp+0xC0]
00007dd8609e0e23  vmovaps xmm14, [rsp+0xD0]
00007dd8609e0e2c  vmovaps xmm15, [rsp+0xE0]
00007dd8609e0e35  add rsp, 0xF0
00007dd8609e0e3c  pop r11
00007dd8609e0e3e  pop r10
00007dd8609e0e40  pop r9
00007dd8609e0e42  pop r8
00007dd8609e0e44  pop rsi
00007dd8609e0e45  pop rdi
00007dd8609e0e46  pop rdx
00007dd8609e0e47  pop rcx
00007dd8609e0e48  pop rax
00007dd8609e0e49  add rsp, 0x08
00007dd8609e0e4d  jmp 0x00007DD8609DF0D6
00007dd8609e0e52  sub rsp, 0x08
00007dd8609e0e56  push rax
00007dd8609e0e57  push rcx
00007dd8609e0e58  push rdx
00007dd8609e0e59  push rdi
00007dd8609e0e5a  push rsi
00007dd8609e0e5b  push r8
00007dd8609e0e5d  push r9
00007dd8609e0e5f  push r10
00007dd8609e0e61  push r11
00007dd8609e0e63  sub rsp, 0xF0
00007dd8609e0e6a  vmovaps [rsp], xmm0
00007dd8609e0e6f  vmovaps [rsp+0x10], xmm2
00007dd8609e0e75  vmovaps [rsp+0x20], xmm3
00007dd8609e0e7b  vmovaps [rsp+0x30], xmm4
00007dd8609e0e81  vmovaps [rsp+0x40], xmm5
00007dd8609e0e87  vmovaps [rsp+0x50], xmm6
00007dd8609e0e8d  vmovaps [rsp+0x60], xmm7
00007dd8609e0e93  vmovaps [rsp+0x70], xmm8
00007dd8609e0e99  vmovaps [rsp+0x80], xmm9
00007dd8609e0ea2  vmovaps [rsp+0x90], xmm10
00007dd8609e0eab  vmovaps [rsp+0xA0], xmm11
00007dd8609e0eb4  vmovaps [rsp+0xB0], xmm12
00007dd8609e0ebd  vmovaps [rsp+0xC0], xmm13
00007dd8609e0ec6  vmovaps [rsp+0xD0], xmm14
00007dd8609e0ecf  vmovaps [rsp+0xE0], xmm15
00007dd8609e0ed8  sub rsp, 0x30
00007dd8609e0edc  movaps [rsp], xmm1
00007dd8609e0ee0  movaps [rsp+0x10], xmm15
00007dd8609e0ee6  movaps [rsp+0x20], xmm9
00007dd8609e0eec  lea rdi, [rsp]
00007dd8609e0ef0  mov esi, 0x00
00007dd8609e0ef5  mov rax, 0x629C9CFA9530
00007dd8609e0eff  call rax
00007dd8609e0f01  movaps xmm1, [rsp]
00007dd8609e0f05  add rsp, 0x30
00007dd8609e0f09  vmovaps xmm0, [rsp]
00007dd8609e0f0e  vmovaps xmm2, [rsp+0x10]
00007dd8609e0f14  vmovaps xmm3, [rsp+0x20]
00007dd8609e0f1a  vmovaps xmm4, [rsp+0x30]
00007dd8609e0f20  vmovaps xmm5, [rsp+0x40]
00007dd8609e0f26  vmovaps xmm6, [rsp+0x50]
00007dd8609e0f2c  vmovaps xmm7, [rsp+0x60]
00007dd8609e0f32  vmovaps xmm8, [rsp+0x70]
00007dd8609e0f38  vmovaps xmm9, [rsp+0x80]
00007dd8609e0f41  vmovaps xmm10, [rsp+0x90]
00007dd8609e0f4a  vmovaps xmm11, [rsp+0xA0]
00007dd8609e0f53  vmovaps xmm12, [rsp+0xB0]
00007dd8609e0f5c  vmovaps xmm13, [rsp+0xC0]
00007dd8609e0f65  vmovaps xmm14, [rsp+0xD0]
00007dd8609e0f6e  vmovaps xmm15, [rsp+0xE0]
00007dd8609e0f77  add rsp, 0xF0
00007dd8609e0f7e  pop r11
00007dd8609e0f80  pop r10
00007dd8609e0f82  pop r9
00007dd8609e0f84  pop r8
00007dd8609e0f86  pop rsi
00007dd8609e0f87  pop rdi
00007dd8609e0f88  pop rdx
00007dd8609e0f89  pop rcx
00007dd8609e0f8a  pop rax
00007dd8609e0f8b  add rsp, 0x08
00007dd8609e0f8f  jmp 0x00007DD8609DF15E
00007dd8609e0f94  call 0x00007DD8608C4620
00007dd8609e0f99  jmp 0x00007DD8609DF16B
00007dd8609e0f9e  sub rsp, 0x08
00007dd8609e0fa2  push rax
00007dd8609e0fa3  push rcx
00007dd8609e0fa4  push rdx
00007dd8609e0fa5  push rdi
00007dd8609e0fa6  push rsi
00007dd8609e0fa7  push r8
00007dd8609e0fa9  push r9
00007dd8609e0fab  push r10
00007dd8609e0fad  push r11
00007dd8609e0faf  sub rsp, 0xF0
00007dd8609e0fb6  vmovaps [rsp], xmm0
00007dd8609e0fbb  vmovaps [rsp+0x10], xmm2
00007dd8609e0fc1  vmovaps [rsp+0x20], xmm3
00007dd8609e0fc7  vmovaps [rsp+0x30], xmm4
00007dd8609e0fcd  vmovaps [rsp+0x40], xmm5
00007dd8609e0fd3  vmovaps [rsp+0x50], xmm6
00007dd8609e0fd9  vmovaps [rsp+0x60], xmm7
00007dd8609e0fdf  vmovaps [rsp+0x70], xmm8
00007dd8609e0fe5  vmovaps [rsp+0x80], xmm9
00007dd8609e0fee  vmovaps [rsp+0x90], xmm10
00007dd8609e0ff7  vmovaps [rsp+0xA0], xmm11
00007dd8609e1000  vmovaps [rsp+0xB0], xmm12
00007dd8609e1009  vmovaps [rsp+0xC0], xmm13
00007dd8609e1012  vmovaps [rsp+0xD0], xmm14
00007dd8609e101b  vmovaps [rsp+0xE0], xmm15
00007dd8609e1024  sub rsp, 0x30
00007dd8609e1028  movaps [rsp], xmm1
00007dd8609e102c  movaps [rsp+0x10], xmm5
00007dd8609e1031  movaps [rsp+0x20], xmm7
00007dd8609e1036  lea rdi, [rsp]
00007dd8609e103a  mov esi, 0x00
00007dd8609e103f  mov rax, 0x629C9CFA9530
00007dd8609e1049  call rax
00007dd8609e104b  movaps xmm1, [rsp]
00007dd8609e104f  add rsp, 0x30
00007dd8609e1053  vmovaps xmm0, [rsp]
00007dd8609e1058  vmovaps xmm2, [rsp+0x10]
00007dd8609e105e  vmovaps xmm3, [rsp+0x20]
00007dd8609e1064  vmovaps xmm4, [rsp+0x30]
00007dd8609e106a  vmovaps xmm5, [rsp+0x40]
00007dd8609e1070  vmovaps xmm6, [rsp+0x50]
00007dd8609e1076  vmovaps xmm7, [rsp+0x60]
00007dd8609e107c  vmovaps xmm8, [rsp+0x70]
00007dd8609e1082  vmovaps xmm9, [rsp+0x80]
00007dd8609e108b  vmovaps xmm10, [rsp+0x90]
00007dd8609e1094  vmovaps xmm11, [rsp+0xA0]
00007dd8609e109d  vmovaps xmm12, [rsp+0xB0]
00007dd8609e10a6  vmovaps xmm13, [rsp+0xC0]
00007dd8609e10af  vmovaps xmm14, [rsp+0xD0]
00007dd8609e10b8  vmovaps xmm15, [rsp+0xE0]
00007dd8609e10c1  add rsp, 0xF0
00007dd8609e10c8  pop r11
00007dd8609e10ca  pop r10
00007dd8609e10cc  pop r9
00007dd8609e10ce  pop r8
00007dd8609e10d0  pop rsi
00007dd8609e10d1  pop rdi
00007dd8609e10d2  pop rdx
00007dd8609e10d3  pop rcx
00007dd8609e10d4  pop rax
00007dd8609e10d5  add rsp, 0x08
00007dd8609e10d9  jmp 0x00007DD8609DF210
00007dd8609e10de  sub rsp, 0x08
00007dd8609e10e2  push rax
00007dd8609e10e3  push rcx
00007dd8609e10e4  push rdx
00007dd8609e10e5  push rdi
00007dd8609e10e6  push rsi
00007dd8609e10e7  push r8
00007dd8609e10e9  push r9
00007dd8609e10eb  push r10
00007dd8609e10ed  push r11
00007dd8609e10ef  sub rsp, 0xF0
00007dd8609e10f6  vmovaps [rsp], xmm0
00007dd8609e10fb  vmovaps [rsp+0x10], xmm1
00007dd8609e1101  vmovaps [rsp+0x20], xmm2
00007dd8609e1107  vmovaps [rsp+0x30], xmm3
00007dd8609e110d  vmovaps [rsp+0x40], xmm4
00007dd8609e1113  vmovaps [rsp+0x50], xmm5
00007dd8609e1119  vmovaps [rsp+0x60], xmm6
00007dd8609e111f  vmovaps [rsp+0x70], xmm8
00007dd8609e1125  vmovaps [rsp+0x80], xmm9
00007dd8609e112e  vmovaps [rsp+0x90], xmm10
00007dd8609e1137  vmovaps [rsp+0xA0], xmm11
00007dd8609e1140  vmovaps [rsp+0xB0], xmm12
00007dd8609e1149  vmovaps [rsp+0xC0], xmm13
00007dd8609e1152  vmovaps [rsp+0xD0], xmm14
00007dd8609e115b  vmovaps [rsp+0xE0], xmm15
00007dd8609e1164  sub rsp, 0x30
00007dd8609e1168  movaps [rsp], xmm7
00007dd8609e116c  movaps [rsp+0x10], xmm5
00007dd8609e1171  movaps [rsp+0x20], xmm15
00007dd8609e1177  lea rdi, [rsp]
00007dd8609e117b  mov esi, 0x00
00007dd8609e1180  mov rax, 0x629C9CFA9530
00007dd8609e118a  call rax
00007dd8609e118c  movaps xmm7, [rsp]
00007dd8609e1190  add rsp, 0x30
00007dd8609e1194  vmovaps xmm0, [rsp]
00007dd8609e1199  vmovaps xmm1, [rsp+0x10]
00007dd8609e119f  vmovaps xmm2, [rsp+0x20]
00007dd8609e11a5  vmovaps xmm3, [rsp+0x30]
00007dd8609e11ab  vmovaps xmm4, [rsp+0x40]
00007dd8609e11b1  vmovaps xmm5, [rsp+0x50]
00007dd8609e11b7  vmovaps xmm6, [rsp+0x60]
00007dd8609e11bd  vmovaps xmm8, [rsp+0x70]
00007dd8609e11c3  vmovaps xmm9, [rsp+0x80]
00007dd8609e11cc  vmovaps xmm10, [rsp+0x90]
00007dd8609e11d5  vmovaps xmm11, [rsp+0xA0]
00007dd8609e11de  vmovaps xmm12, [rsp+0xB0]
00007dd8609e11e7  vmovaps xmm13, [rsp+0xC0]
00007dd8609e11f0  vmovaps xmm14, [rsp+0xD0]
00007dd8609e11f9  vmovaps xmm15, [rsp+0xE0]
00007dd8609e1202  add rsp, 0xF0
00007dd8609e1209  pop r11
00007dd8609e120b  pop r10
00007dd8609e120d  pop r9
00007dd8609e120f  pop r8
00007dd8609e1211  pop rsi
00007dd8609e1212  pop rdi
00007dd8609e1213  pop rdx
00007dd8609e1214  pop rcx
00007dd8609e1215  pop rax
00007dd8609e1216  add rsp, 0x08
00007dd8609e121a  jmp 0x00007DD8609DF246
00007dd8609e121f  call 0x00007DD8608B52F0
00007dd8609e1224  jmp 0x00007DD8609DF253
00007dd8609e1229  sub rsp, 0x08
00007dd8609e122d  push rax
00007dd8609e122e  push rcx
00007dd8609e122f  push rdx
00007dd8609e1230  push rdi
00007dd8609e1231  push rsi
00007dd8609e1232  push r8
00007dd8609e1234  push r9
00007dd8609e1236  push r10
00007dd8609e1238  push r11
00007dd8609e123a  sub rsp, 0xF0
00007dd8609e1241  vmovaps [rsp], xmm0
00007dd8609e1246  vmovaps [rsp+0x10], xmm1
00007dd8609e124c  vmovaps [rsp+0x20], xmm2
00007dd8609e1252  vmovaps [rsp+0x30], xmm3
00007dd8609e1258  vmovaps [rsp+0x40], xmm4
00007dd8609e125e  vmovaps [rsp+0x50], xmm5
00007dd8609e1264  vmovaps [rsp+0x60], xmm6
00007dd8609e126a  vmovaps [rsp+0x70], xmm7
00007dd8609e1270  vmovaps [rsp+0x80], xmm8
00007dd8609e1279  vmovaps [rsp+0x90], xmm9
00007dd8609e1282  vmovaps [rsp+0xA0], xmm10
00007dd8609e128b  vmovaps [rsp+0xB0], xmm11
00007dd8609e1294  vmovaps [rsp+0xC0], xmm12
00007dd8609e129d  vmovaps [rsp+0xD0], xmm13
00007dd8609e12a6  vmovaps [rsp+0xE0], xmm14
00007dd8609e12af  sub rsp, 0x30
00007dd8609e12b3  movaps [rsp], xmm15
00007dd8609e12b8  movaps [rsp+0x10], xmm5
00007dd8609e12bd  movaps [rsp+0x20], xmm3
00007dd8609e12c2  lea rdi, [rsp]
00007dd8609e12c6  mov esi, 0x00
00007dd8609e12cb  mov rax, 0x629C9CFA9530
00007dd8609e12d5  call rax
00007dd8609e12d7  movaps xmm15, [rsp]
00007dd8609e12dc  add rsp, 0x30
00007dd8609e12e0  vmovaps xmm0, [rsp]
00007dd8609e12e5  vmovaps xmm1, [rsp+0x10]
00007dd8609e12eb  vmovaps xmm2, [rsp+0x20]
00007dd8609e12f1  vmovaps xmm3, [rsp+0x30]
00007dd8609e12f7  vmovaps xmm4, [rsp+0x40]
00007dd8609e12fd  vmovaps xmm5, [rsp+0x50]
00007dd8609e1303  vmovaps xmm6, [rsp+0x60]
00007dd8609e1309  vmovaps xmm7, [rsp+0x70]
00007dd8609e130f  vmovaps xmm8, [rsp+0x80]
00007dd8609e1318  vmovaps xmm9, [rsp+0x90]
00007dd8609e1321  vmovaps xmm10, [rsp+0xA0]
00007dd8609e132a  vmovaps xmm11, [rsp+0xB0]
00007dd8609e1333  vmovaps xmm12, [rsp+0xC0]
00007dd8609e133c  vmovaps xmm13, [rsp+0xD0]
00007dd8609e1345  vmovaps xmm14, [rsp+0xE0]
00007dd8609e134e  add rsp, 0xF0
00007dd8609e1355  pop r11
00007dd8609e1357  pop r10
00007dd8609e1359  pop r9
00007dd8609e135b  pop r8
00007dd8609e135d  pop rsi
00007dd8609e135e  pop rdi
00007dd8609e135f  pop rdx
00007dd8609e1360  pop rcx
00007dd8609e1361  pop rax
00007dd8609e1362  add rsp, 0x08
00007dd8609e1366  jmp 0x00007DD8609DF279
00007dd8609e136b  sub rsp, 0x08
00007dd8609e136f  push rax
00007dd8609e1370  push rcx
00007dd8609e1371  push rdx
00007dd8609e1372  push rdi
00007dd8609e1373  push rsi
00007dd8609e1374  push r8
00007dd8609e1376  push r9
00007dd8609e1378  push r10
00007dd8609e137a  push r11
00007dd8609e137c  sub rsp, 0xF0
00007dd8609e1383  vmovaps [rsp], xmm0
00007dd8609e1388  vmovaps [rsp+0x10], xmm2
00007dd8609e138e  vmovaps [rsp+0x20], xmm3
00007dd8609e1394  vmovaps [rsp+0x30], xmm4
00007dd8609e139a  vmovaps [rsp+0x40], xmm5
00007dd8609e13a0  vmovaps [rsp+0x50], xmm6
00007dd8609e13a6  vmovaps [rsp+0x60], xmm7
00007dd8609e13ac  vmovaps [rsp+0x70], xmm8
00007dd8609e13b2  vmovaps [rsp+0x80], xmm9
00007dd8609e13bb  vmovaps [rsp+0x90], xmm10
00007dd8609e13c4  vmovaps [rsp+0xA0], xmm11
00007dd8609e13cd  vmovaps [rsp+0xB0], xmm12
00007dd8609e13d6  vmovaps [rsp+0xC0], xmm13
00007dd8609e13df  vmovaps [rsp+0xD0], xmm14
00007dd8609e13e8  vmovaps [rsp+0xE0], xmm15
00007dd8609e13f1  sub rsp, 0x30
00007dd8609e13f5  movaps [rsp], xmm1
00007dd8609e13f9  movaps [rsp+0x10], xmm5
00007dd8609e13fe  movaps [rsp+0x20], xmm4
00007dd8609e1403  lea rdi, [rsp]
00007dd8609e1407  mov esi, 0x00
00007dd8609e140c  mov rax, 0x629C9CFA9530
00007dd8609e1416  call rax
00007dd8609e1418  movaps xmm1, [rsp]
00007dd8609e141c  add rsp, 0x30
00007dd8609e1420  vmovaps xmm0, [rsp]
00007dd8609e1425  vmovaps xmm2, [rsp+0x10]
00007dd8609e142b  vmovaps xmm3, [rsp+0x20]
00007dd8609e1431  vmovaps xmm4, [rsp+0x30]
00007dd8609e1437  vmovaps xmm5, [rsp+0x40]
00007dd8609e143d  vmovaps xmm6, [rsp+0x50]
00007dd8609e1443  vmovaps xmm7, [rsp+0x60]
00007dd8609e1449  vmovaps xmm8, [rsp+0x70]
00007dd8609e144f  vmovaps xmm9, [rsp+0x80]
00007dd8609e1458  vmovaps xmm10, [rsp+0x90]
00007dd8609e1461  vmovaps xmm11, [rsp+0xA0]
00007dd8609e146a  vmovaps xmm12, [rsp+0xB0]
00007dd8609e1473  vmovaps xmm13, [rsp+0xC0]
00007dd8609e147c  vmovaps xmm14, [rsp+0xD0]
00007dd8609e1485  vmovaps xmm15, [rsp+0xE0]
00007dd8609e148e  add rsp, 0xF0
00007dd8609e1495  pop r11
00007dd8609e1497  pop r10
00007dd8609e1499  pop r9
00007dd8609e149b  pop r8
00007dd8609e149d  pop rsi
00007dd8609e149e  pop rdi
00007dd8609e149f  pop rdx
00007dd8609e14a0  pop rcx
00007dd8609e14a1  pop rax
00007dd8609e14a2  add rsp, 0x08
00007dd8609e14a6  jmp 0x00007DD8609DF299
00007dd8609e14ab  sub rsp, 0x08
00007dd8609e14af  push rax
00007dd8609e14b0  push rcx
00007dd8609e14b1  push rdx
00007dd8609e14b2  push rdi
00007dd8609e14b3  push rsi
00007dd8609e14b4  push r8
00007dd8609e14b6  push r9
00007dd8609e14b8  push r10
00007dd8609e14ba  push r11
00007dd8609e14bc  sub rsp, 0xF0
00007dd8609e14c3  vmovaps [rsp], xmm0
00007dd8609e14c8  vmovaps [rsp+0x10], xmm1
00007dd8609e14ce  vmovaps [rsp+0x20], xmm2
00007dd8609e14d4  vmovaps [rsp+0x30], xmm3
00007dd8609e14da  vmovaps [rsp+0x40], xmm5
00007dd8609e14e0  vmovaps [rsp+0x50], xmm6
00007dd8609e14e6  vmovaps [rsp+0x60], xmm7
00007dd8609e14ec  vmovaps [rsp+0x70], xmm8
00007dd8609e14f2  vmovaps [rsp+0x80], xmm9
00007dd8609e14fb  vmovaps [rsp+0x90], xmm10
00007dd8609e1504  vmovaps [rsp+0xA0], xmm11
00007dd8609e150d  vmovaps [rsp+0xB0], xmm12
00007dd8609e1516  vmovaps [rsp+0xC0], xmm13
00007dd8609e151f  vmovaps [rsp+0xD0], xmm14
00007dd8609e1528  vmovaps [rsp+0xE0], xmm15
00007dd8609e1531  sub rsp, 0x30
00007dd8609e1535  movaps [rsp], xmm4
00007dd8609e1539  movaps [rsp+0x10], xmm3
00007dd8609e153e  movaps [rsp+0x20], xmm5
00007dd8609e1543  lea rdi, [rsp]
00007dd8609e1547  mov esi, 0x00
00007dd8609e154c  mov rax, 0x629C9CFA9530
00007dd8609e1556  call rax
00007dd8609e1558  movaps xmm4, [rsp]
00007dd8609e155c  add rsp, 0x30
00007dd8609e1560  vmovaps xmm0, [rsp]
00007dd8609e1565  vmovaps xmm1, [rsp+0x10]
00007dd8609e156b  vmovaps xmm2, [rsp+0x20]
00007dd8609e1571  vmovaps xmm3, [rsp+0x30]
00007dd8609e1577  vmovaps xmm5, [rsp+0x40]
00007dd8609e157d  vmovaps xmm6, [rsp+0x50]
00007dd8609e1583  vmovaps xmm7, [rsp+0x60]
00007dd8609e1589  vmovaps xmm8, [rsp+0x70]
00007dd8609e158f  vmovaps xmm9, [rsp+0x80]
00007dd8609e1598  vmovaps xmm10, [rsp+0x90]
00007dd8609e15a1  vmovaps xmm11, [rsp+0xA0]
00007dd8609e15aa  vmovaps xmm12, [rsp+0xB0]
00007dd8609e15b3  vmovaps xmm13, [rsp+0xC0]
00007dd8609e15bc  vmovaps xmm14, [rsp+0xD0]
00007dd8609e15c5  vmovaps xmm15, [rsp+0xE0]
00007dd8609e15ce  add rsp, 0xF0
00007dd8609e15d5  pop r11
00007dd8609e15d7  pop r10
00007dd8609e15d9  pop r9
00007dd8609e15db  pop r8
00007dd8609e15dd  pop rsi
00007dd8609e15de  pop rdi
00007dd8609e15df  pop rdx
00007dd8609e15e0  pop rcx
00007dd8609e15e1  pop rax
00007dd8609e15e2  add rsp, 0x08
00007dd8609e15e6  jmp 0x00007DD8609DF2E7
00007dd8609e15eb  call 0x00007DD8608B52F0
00007dd8609e15f0  jmp 0x00007DD8609DF2F4
00007dd8609e15f5  sub rsp, 0x08
00007dd8609e15f9  push rax
00007dd8609e15fa  push rcx
00007dd8609e15fb  push rdx
00007dd8609e15fc  push rdi
00007dd8609e15fd  push rsi
00007dd8609e15fe  push r8
00007dd8609e1600  push r9
00007dd8609e1602  push r10
00007dd8609e1604  push r11
00007dd8609e1606  sub rsp, 0xF0
00007dd8609e160d  vmovaps [rsp], xmm0
00007dd8609e1612  vmovaps [rsp+0x10], xmm1
00007dd8609e1618  vmovaps [rsp+0x20], xmm2
00007dd8609e161e  vmovaps [rsp+0x30], xmm3
00007dd8609e1624  vmovaps [rsp+0x40], xmm4
00007dd8609e162a  vmovaps [rsp+0x50], xmm6
00007dd8609e1630  vmovaps [rsp+0x60], xmm7
00007dd8609e1636  vmovaps [rsp+0x70], xmm8
00007dd8609e163c  vmovaps [rsp+0x80], xmm9
00007dd8609e1645  vmovaps [rsp+0x90], xmm10
00007dd8609e164e  vmovaps [rsp+0xA0], xmm11
00007dd8609e1657  vmovaps [rsp+0xB0], xmm12
00007dd8609e1660  vmovaps [rsp+0xC0], xmm13
00007dd8609e1669  vmovaps [rsp+0xD0], xmm14
00007dd8609e1672  vmovaps [rsp+0xE0], xmm15
00007dd8609e167b  sub rsp, 0x30
00007dd8609e167f  movaps [rsp], xmm5
00007dd8609e1683  movaps [rsp+0x10], xmm6
00007dd8609e1688  movaps [rsp+0x20], xmm3
00007dd8609e168d  lea rdi, [rsp]
00007dd8609e1691  mov esi, 0x00
00007dd8609e1696  mov rax, 0x629C9CFA9530
00007dd8609e16a0  call rax
00007dd8609e16a2  movaps xmm5, [rsp]
00007dd8609e16a6  add rsp, 0x30
00007dd8609e16aa  vmovaps xmm0, [rsp]
00007dd8609e16af  vmovaps xmm1, [rsp+0x10]
00007dd8609e16b5  vmovaps xmm2, [rsp+0x20]
00007dd8609e16bb  vmovaps xmm3, [rsp+0x30]
00007dd8609e16c1  vmovaps xmm4, [rsp+0x40]
00007dd8609e16c7  vmovaps xmm6, [rsp+0x50]
00007dd8609e16cd  vmovaps xmm7, [rsp+0x60]
00007dd8609e16d3  vmovaps xmm8, [rsp+0x70]
00007dd8609e16d9  vmovaps xmm9, [rsp+0x80]
00007dd8609e16e2  vmovaps xmm10, [rsp+0x90]
00007dd8609e16eb  vmovaps xmm11, [rsp+0xA0]
00007dd8609e16f4  vmovaps xmm12, [rsp+0xB0]
00007dd8609e16fd  vmovaps xmm13, [rsp+0xC0]
00007dd8609e1706  vmovaps xmm14, [rsp+0xD0]
00007dd8609e170f  vmovaps xmm15, [rsp+0xE0]
00007dd8609e1718  add rsp, 0xF0
00007dd8609e171f  pop r11
00007dd8609e1721  pop r10
00007dd8609e1723  pop r9
00007dd8609e1725  pop r8
00007dd8609e1727  pop rsi
00007dd8609e1728  pop rdi
00007dd8609e1729  pop rdx
00007dd8609e172a  pop rcx
00007dd8609e172b  pop rax
00007dd8609e172c  add rsp, 0x08
00007dd8609e1730  jmp 0x00007DD8609DF31A
00007dd8609e1735  sub rsp, 0x08
00007dd8609e1739  push rax
00007dd8609e173a  push rcx
00007dd8609e173b  push rdx
00007dd8609e173c  push rdi
00007dd8609e173d  push rsi
00007dd8609e173e  push r8
00007dd8609e1740  push r9
00007dd8609e1742  push r10
00007dd8609e1744  push r11
00007dd8609e1746  sub rsp, 0xF0
00007dd8609e174d  vmovaps [rsp], xmm0
00007dd8609e1752  vmovaps [rsp+0x10], xmm1
00007dd8609e1758  vmovaps [rsp+0x20], xmm2
00007dd8609e175e  vmovaps [rsp+0x30], xmm3
00007dd8609e1764  vmovaps [rsp+0x40], xmm4
00007dd8609e176a  vmovaps [rsp+0x50], xmm5
00007dd8609e1770  vmovaps [rsp+0x60], xmm7
00007dd8609e1776  vmovaps [rsp+0x70], xmm8
00007dd8609e177c  vmovaps [rsp+0x80], xmm9
00007dd8609e1785  vmovaps [rsp+0x90], xmm10
00007dd8609e178e  vmovaps [rsp+0xA0], xmm11
00007dd8609e1797  vmovaps [rsp+0xB0], xmm12
00007dd8609e17a0  vmovaps [rsp+0xC0], xmm13
00007dd8609e17a9  vmovaps [rsp+0xD0], xmm14
00007dd8609e17b2  vmovaps [rsp+0xE0], xmm15
00007dd8609e17bb  sub rsp, 0x30
00007dd8609e17bf  movaps [rsp], xmm6
00007dd8609e17c3  movaps [rsp+0x10], xmm9
00007dd8609e17c9  movaps [rsp+0x20], xmm1
00007dd8609e17ce  lea rdi, [rsp]
00007dd8609e17d2  mov esi, 0x00
00007dd8609e17d7  mov rax, 0x629C9CFA9530
00007dd8609e17e1  call rax
00007dd8609e17e3  movaps xmm6, [rsp]
00007dd8609e17e7  add rsp, 0x30
00007dd8609e17eb  vmovaps xmm0, [rsp]
00007dd8609e17f0  vmovaps xmm1, [rsp+0x10]
00007dd8609e17f6  vmovaps xmm2, [rsp+0x20]
00007dd8609e17fc  vmovaps xmm3, [rsp+0x30]
00007dd8609e1802  vmovaps xmm4, [rsp+0x40]
00007dd8609e1808  vmovaps xmm5, [rsp+0x50]
00007dd8609e180e  vmovaps xmm7, [rsp+0x60]
00007dd8609e1814  vmovaps xmm8, [rsp+0x70]
00007dd8609e181a  vmovaps xmm9, [rsp+0x80]
00007dd8609e1823  vmovaps xmm10, [rsp+0x90]
00007dd8609e182c  vmovaps xmm11, [rsp+0xA0]
00007dd8609e1835  vmovaps xmm12, [rsp+0xB0]
00007dd8609e183e  vmovaps xmm13, [rsp+0xC0]
00007dd8609e1847  vmovaps xmm14, [rsp+0xD0]
00007dd8609e1850  vmovaps xmm15, [rsp+0xE0]
00007dd8609e1859  add rsp, 0xF0
00007dd8609e1860  pop r11
00007dd8609e1862  pop r10
00007dd8609e1864  pop r9
00007dd8609e1866  pop r8
00007dd8609e1868  pop rsi
00007dd8609e1869  pop rdi
00007dd8609e186a  pop rdx
00007dd8609e186b  pop rcx
00007dd8609e186c  pop rax
00007dd8609e186d  add rsp, 0x08
00007dd8609e1871  jmp 0x00007DD8609DF33E
00007dd8609e1876  sub rsp, 0x08
00007dd8609e187a  push rax
00007dd8609e187b  push rcx
00007dd8609e187c  push rdx
00007dd8609e187d  push rdi
00007dd8609e187e  push rsi
00007dd8609e187f  push r8
00007dd8609e1881  push r9
00007dd8609e1883  push r10
00007dd8609e1885  push r11
00007dd8609e1887  sub rsp, 0xF0
00007dd8609e188e  vmovaps [rsp], xmm0
00007dd8609e1893  vmovaps [rsp+0x10], xmm1
00007dd8609e1899  vmovaps [rsp+0x20], xmm2
00007dd8609e189f  vmovaps [rsp+0x30], xmm3
00007dd8609e18a5  vmovaps [rsp+0x40], xmm4
00007dd8609e18ab  vmovaps [rsp+0x50], xmm5
00007dd8609e18b1  vmovaps [rsp+0x60], xmm6
00007dd8609e18b7  vmovaps [rsp+0x70], xmm7
00007dd8609e18bd  vmovaps [rsp+0x80], xmm8
00007dd8609e18c6  vmovaps [rsp+0x90], xmm10
00007dd8609e18cf  vmovaps [rsp+0xA0], xmm11
00007dd8609e18d8  vmovaps [rsp+0xB0], xmm12
00007dd8609e18e1  vmovaps [rsp+0xC0], xmm13
00007dd8609e18ea  vmovaps [rsp+0xD0], xmm14
00007dd8609e18f3  vmovaps [rsp+0xE0], xmm15
00007dd8609e18fc  sub rsp, 0x30
00007dd8609e1900  movaps [rsp], xmm9
00007dd8609e1905  movaps [rsp+0x10], xmm3
00007dd8609e190a  movaps [rsp+0x20], xmm1
00007dd8609e190f  lea rdi, [rsp]
00007dd8609e1913  mov esi, 0x00
00007dd8609e1918  mov rax, 0x629C9CFA9530
00007dd8609e1922  call rax
00007dd8609e1924  movaps xmm9, [rsp]
00007dd8609e1929  add rsp, 0x30
00007dd8609e192d  vmovaps xmm0, [rsp]
00007dd8609e1932  vmovaps xmm1, [rsp+0x10]
00007dd8609e1938  vmovaps xmm2, [rsp+0x20]
00007dd8609e193e  vmovaps xmm3, [rsp+0x30]
00007dd8609e1944  vmovaps xmm4, [rsp+0x40]
00007dd8609e194a  vmovaps xmm5, [rsp+0x50]
00007dd8609e1950  vmovaps xmm6, [rsp+0x60]
00007dd8609e1956  vmovaps xmm7, [rsp+0x70]
00007dd8609e195c  vmovaps xmm8, [rsp+0x80]
00007dd8609e1965  vmovaps xmm10, [rsp+0x90]
00007dd8609e196e  vmovaps xmm11, [rsp+0xA0]
00007dd8609e1977  vmovaps xmm12, [rsp+0xB0]
00007dd8609e1980  vmovaps xmm13, [rsp+0xC0]
00007dd8609e1989  vmovaps xmm14, [rsp+0xD0]
00007dd8609e1992  vmovaps xmm15, [rsp+0xE0]
00007dd8609e199b  add rsp, 0xF0
00007dd8609e19a2  pop r11
00007dd8609e19a4  pop r10
00007dd8609e19a6  pop r9
00007dd8609e19a8  pop r8
00007dd8609e19aa  pop rsi
00007dd8609e19ab  pop rdi
00007dd8609e19ac  pop rdx
00007dd8609e19ad  pop rcx
00007dd8609e19ae  pop rax
00007dd8609e19af  add rsp, 0x08
00007dd8609e19b3  jmp 0x00007DD8609DF38A
00007dd8609e19b8  call 0x00007DD8608B52F0
00007dd8609e19bd  jmp 0x00007DD8609DF397
00007dd8609e19c2  sub rsp, 0x08
00007dd8609e19c6  push rax
00007dd8609e19c7  push rcx
00007dd8609e19c8  push rdx
00007dd8609e19c9  push rdi
00007dd8609e19ca  push rsi
00007dd8609e19cb  push r8
00007dd8609e19cd  push r9
00007dd8609e19cf  push r10
00007dd8609e19d1  push r11
00007dd8609e19d3  sub rsp, 0xF0
00007dd8609e19da  vmovaps [rsp], xmm0
00007dd8609e19df  vmovaps [rsp+0x10], xmm1
00007dd8609e19e5  vmovaps [rsp+0x20], xmm2
00007dd8609e19eb  vmovaps [rsp+0x30], xmm3
00007dd8609e19f1  vmovaps [rsp+0x40], xmm4
00007dd8609e19f7  vmovaps [rsp+0x50], xmm5
00007dd8609e19fd  vmovaps [rsp+0x60], xmm6
00007dd8609e1a03  vmovaps [rsp+0x70], xmm7
00007dd8609e1a09  vmovaps [rsp+0x80], xmm8
00007dd8609e1a12  vmovaps [rsp+0x90], xmm9
00007dd8609e1a1b  vmovaps [rsp+0xA0], xmm10
00007dd8609e1a24  vmovaps [rsp+0xB0], xmm11
00007dd8609e1a2d  vmovaps [rsp+0xC0], xmm12
00007dd8609e1a36  vmovaps [rsp+0xD0], xmm13
00007dd8609e1a3f  vmovaps [rsp+0xE0], xmm14
00007dd8609e1a48  sub rsp, 0x30
00007dd8609e1a4c  movaps [rsp], xmm15
00007dd8609e1a51  movaps [rsp+0x10], xmm3
00007dd8609e1a56  movaps [rsp+0x20], xmm7
00007dd8609e1a5b  lea rdi, [rsp]
00007dd8609e1a5f  mov esi, 0x00
00007dd8609e1a64  mov rax, 0x629C9CFA9530
00007dd8609e1a6e  call rax
00007dd8609e1a70  movaps xmm15, [rsp]
00007dd8609e1a75  add rsp, 0x30
00007dd8609e1a79  vmovaps xmm0, [rsp]
00007dd8609e1a7e  vmovaps xmm1, [rsp+0x10]
00007dd8609e1a84  vmovaps xmm2, [rsp+0x20]
00007dd8609e1a8a  vmovaps xmm3, [rsp+0x30]
00007dd8609e1a90  vmovaps xmm4, [rsp+0x40]
00007dd8609e1a96  vmovaps xmm5, [rsp+0x50]
00007dd8609e1a9c  vmovaps xmm6, [rsp+0x60]
00007dd8609e1aa2  vmovaps xmm7, [rsp+0x70]
00007dd8609e1aa8  vmovaps xmm8, [rsp+0x80]
00007dd8609e1ab1  vmovaps xmm9, [rsp+0x90]
00007dd8609e1aba  vmovaps xmm10, [rsp+0xA0]
00007dd8609e1ac3  vmovaps xmm11, [rsp+0xB0]
00007dd8609e1acc  vmovaps xmm12, [rsp+0xC0]
00007dd8609e1ad5  vmovaps xmm13, [rsp+0xD0]
00007dd8609e1ade  vmovaps xmm14, [rsp+0xE0]
00007dd8609e1ae7  add rsp, 0xF0
00007dd8609e1aee  pop r11
00007dd8609e1af0  pop r10
00007dd8609e1af2  pop r9
00007dd8609e1af4  pop r8
00007dd8609e1af6  pop rsi
00007dd8609e1af7  pop rdi
00007dd8609e1af8  pop rdx
00007dd8609e1af9  pop rcx
00007dd8609e1afa  pop rax
00007dd8609e1afb  add rsp, 0x08
00007dd8609e1aff  jmp 0x00007DD8609DF3C3
00007dd8609e1b04  sub rsp, 0x08
00007dd8609e1b08  push rax
00007dd8609e1b09  push rcx
00007dd8609e1b0a  push rdx
00007dd8609e1b0b  push rdi
00007dd8609e1b0c  push rsi
00007dd8609e1b0d  push r8
00007dd8609e1b0f  push r9
00007dd8609e1b11  push r10
00007dd8609e1b13  push r11
00007dd8609e1b15  sub rsp, 0xF0
00007dd8609e1b1c  vmovaps [rsp], xmm0
00007dd8609e1b21  vmovaps [rsp+0x10], xmm1
00007dd8609e1b27  vmovaps [rsp+0x20], xmm2
00007dd8609e1b2d  vmovaps [rsp+0x30], xmm4
00007dd8609e1b33  vmovaps [rsp+0x40], xmm5
00007dd8609e1b39  vmovaps [rsp+0x50], xmm6
00007dd8609e1b3f  vmovaps [rsp+0x60], xmm7
00007dd8609e1b45  vmovaps [rsp+0x70], xmm8
00007dd8609e1b4b  vmovaps [rsp+0x80], xmm9
00007dd8609e1b54  vmovaps [rsp+0x90], xmm10
00007dd8609e1b5d  vmovaps [rsp+0xA0], xmm11
00007dd8609e1b66  vmovaps [rsp+0xB0], xmm12
00007dd8609e1b6f  vmovaps [rsp+0xC0], xmm13
00007dd8609e1b78  vmovaps [rsp+0xD0], xmm14
00007dd8609e1b81  vmovaps [rsp+0xE0], xmm15
00007dd8609e1b8a  sub rsp, 0x30
00007dd8609e1b8e  movaps [rsp], xmm3
00007dd8609e1b92  movaps [rsp+0x10], xmm1
00007dd8609e1b97  movaps [rsp+0x20], xmm15
00007dd8609e1b9d  lea rdi, [rsp]
00007dd8609e1ba1  mov esi, 0x00
00007dd8609e1ba6  mov rax, 0x629C9CFA9530
00007dd8609e1bb0  call rax
00007dd8609e1bb2  movaps xmm3, [rsp]
00007dd8609e1bb6  add rsp, 0x30
00007dd8609e1bba  vmovaps xmm0, [rsp]
00007dd8609e1bbf  vmovaps xmm1, [rsp+0x10]
00007dd8609e1bc5  vmovaps xmm2, [rsp+0x20]
00007dd8609e1bcb  vmovaps xmm4, [rsp+0x30]
00007dd8609e1bd1  vmovaps xmm5, [rsp+0x40]
00007dd8609e1bd7  vmovaps xmm6, [rsp+0x50]
00007dd8609e1bdd  vmovaps xmm7, [rsp+0x60]
00007dd8609e1be3  vmovaps xmm8, [rsp+0x70]
00007dd8609e1be9  vmovaps xmm9, [rsp+0x80]
00007dd8609e1bf2  vmovaps xmm10, [rsp+0x90]
00007dd8609e1bfb  vmovaps xmm11, [rsp+0xA0]
00007dd8609e1c04  vmovaps xmm12, [rsp+0xB0]
00007dd8609e1c0d  vmovaps xmm13, [rsp+0xC0]
00007dd8609e1c16  vmovaps xmm14, [rsp+0xD0]
00007dd8609e1c1f  vmovaps xmm15, [rsp+0xE0]
00007dd8609e1c28  add rsp, 0xF0
00007dd8609e1c2f  pop r11
00007dd8609e1c31  pop r10
00007dd8609e1c33  pop r9
00007dd8609e1c35  pop r8
00007dd8609e1c37  pop rsi
00007dd8609e1c38  pop rdi
00007dd8609e1c39  pop rdx
00007dd8609e1c3a  pop rcx
00007dd8609e1c3b  pop rax
00007dd8609e1c3c  add rsp, 0x08
00007dd8609e1c40  jmp 0x00007DD8609DF452
00007dd8609e1c45  call 0x00007DD8608B52F0
00007dd8609e1c4a  jmp 0x00007DD8609DF45C
00007dd8609e1c4f  sub rsp, 0x08
00007dd8609e1c53  push rax
00007dd8609e1c54  push rcx
00007dd8609e1c55  push rdx
00007dd8609e1c56  push rdi
00007dd8609e1c57  push rsi
00007dd8609e1c58  push r8
00007dd8609e1c5a  push r9
00007dd8609e1c5c  push r10
00007dd8609e1c5e  push r11
00007dd8609e1c60  sub rsp, 0xF0
00007dd8609e1c67  vmovaps [rsp], xmm0
00007dd8609e1c6c  vmovaps [rsp+0x10], xmm1
00007dd8609e1c72  vmovaps [rsp+0x20], xmm2
00007dd8609e1c78  vmovaps [rsp+0x30], xmm3
00007dd8609e1c7e  vmovaps [rsp+0x40], xmm4
00007dd8609e1c84  vmovaps [rsp+0x50], xmm5
00007dd8609e1c8a  vmovaps [rsp+0x60], xmm6
00007dd8609e1c90  vmovaps [rsp+0x70], xmm7
00007dd8609e1c96  vmovaps [rsp+0x80], xmm8
00007dd8609e1c9f  vmovaps [rsp+0x90], xmm9
00007dd8609e1ca8  vmovaps [rsp+0xA0], xmm10
00007dd8609e1cb1  vmovaps [rsp+0xB0], xmm11
00007dd8609e1cba  vmovaps [rsp+0xC0], xmm12
00007dd8609e1cc3  vmovaps [rsp+0xD0], xmm13
00007dd8609e1ccc  vmovaps [rsp+0xE0], xmm14
00007dd8609e1cd5  sub rsp, 0x30
00007dd8609e1cd9  movaps [rsp], xmm15
00007dd8609e1cde  movaps [rsp+0x10], xmm14
00007dd8609e1ce4  movaps [rsp+0x20], xmm4
00007dd8609e1ce9  lea rdi, [rsp]
00007dd8609e1ced  mov esi, 0x00
00007dd8609e1cf2  mov rax, 0x629C9CFA9530
00007dd8609e1cfc  call rax
00007dd8609e1cfe  movaps xmm15, [rsp]
00007dd8609e1d03  add rsp, 0x30
00007dd8609e1d07  vmovaps xmm0, [rsp]
00007dd8609e1d0c  vmovaps xmm1, [rsp+0x10]
00007dd8609e1d12  vmovaps xmm2, [rsp+0x20]
00007dd8609e1d18  vmovaps xmm3, [rsp+0x30]
00007dd8609e1d1e  vmovaps xmm4, [rsp+0x40]
00007dd8609e1d24  vmovaps xmm5, [rsp+0x50]
00007dd8609e1d2a  vmovaps xmm6, [rsp+0x60]
00007dd8609e1d30  vmovaps xmm7, [rsp+0x70]
00007dd8609e1d36  vmovaps xmm8, [rsp+0x80]
00007dd8609e1d3f  vmovaps xmm9, [rsp+0x90]
00007dd8609e1d48  vmovaps xmm10, [rsp+0xA0]
00007dd8609e1d51  vmovaps xmm11, [rsp+0xB0]
00007dd8609e1d5a  vmovaps xmm12, [rsp+0xC0]
00007dd8609e1d63  vmovaps xmm13, [rsp+0xD0]
00007dd8609e1d6c  vmovaps xmm14, [rsp+0xE0]
00007dd8609e1d75  add rsp, 0xF0
00007dd8609e1d7c  pop r11
00007dd8609e1d7e  pop r10
00007dd8609e1d80  pop r9
00007dd8609e1d82  pop r8
00007dd8609e1d84  pop rsi
00007dd8609e1d85  pop rdi
00007dd8609e1d86  pop rdx
00007dd8609e1d87  pop rcx
00007dd8609e1d88  pop rax
00007dd8609e1d89  add rsp, 0x08
00007dd8609e1d8d  jmp 0x00007DD8609DF48A
00007dd8609e1d92  sub rsp, 0x08
00007dd8609e1d96  push rax
00007dd8609e1d97  push rcx
00007dd8609e1d98  push rdx
00007dd8609e1d99  push rdi
00007dd8609e1d9a  push rsi
00007dd8609e1d9b  push r8
00007dd8609e1d9d  push r9
00007dd8609e1d9f  push r10
00007dd8609e1da1  push r11
00007dd8609e1da3  sub rsp, 0xF0
00007dd8609e1daa  vmovaps [rsp], xmm0
00007dd8609e1daf  vmovaps [rsp+0x10], xmm1
00007dd8609e1db5  vmovaps [rsp+0x20], xmm2
00007dd8609e1dbb  vmovaps [rsp+0x30], xmm3
00007dd8609e1dc1  vmovaps [rsp+0x40], xmm4
00007dd8609e1dc7  vmovaps [rsp+0x50], xmm5
00007dd8609e1dcd  vmovaps [rsp+0x60], xmm6
00007dd8609e1dd3  vmovaps [rsp+0x70], xmm7
00007dd8609e1dd9  vmovaps [rsp+0x80], xmm8
00007dd8609e1de2  vmovaps [rsp+0x90], xmm9
00007dd8609e1deb  vmovaps [rsp+0xA0], xmm10
00007dd8609e1df4  vmovaps [rsp+0xB0], xmm11
00007dd8609e1dfd  vmovaps [rsp+0xC0], xmm12
00007dd8609e1e06  vmovaps [rsp+0xD0], xmm13
00007dd8609e1e0f  vmovaps [rsp+0xE0], xmm15
00007dd8609e1e18  sub rsp, 0x30
00007dd8609e1e1c  movaps [rsp], xmm14
00007dd8609e1e21  movaps [rsp+0x10], xmm2
00007dd8609e1e26  movaps [rsp+0x20], xmm1
00007dd8609e1e2b  lea rdi, [rsp]
00007dd8609e1e2f  mov esi, 0x00
00007dd8609e1e34  mov rax, 0x629C9CFA9530
00007dd8609e1e3e  call rax
00007dd8609e1e40  movaps xmm14, [rsp]
00007dd8609e1e45  add rsp, 0x30
00007dd8609e1e49  vmovaps xmm0, [rsp]
00007dd8609e1e4e  vmovaps xmm1, [rsp+0x10]
00007dd8609e1e54  vmovaps xmm2, [rsp+0x20]
00007dd8609e1e5a  vmovaps xmm3, [rsp+0x30]
00007dd8609e1e60  vmovaps xmm4, [rsp+0x40]
00007dd8609e1e66  vmovaps xmm5, [rsp+0x50]
00007dd8609e1e6c  vmovaps xmm6, [rsp+0x60]
00007dd8609e1e72  vmovaps xmm7, [rsp+0x70]
00007dd8609e1e78  vmovaps xmm8, [rsp+0x80]
00007dd8609e1e81  vmovaps xmm9, [rsp+0x90]
00007dd8609e1e8a  vmovaps xmm10, [rsp+0xA0]
00007dd8609e1e93  vmovaps xmm11, [rsp+0xB0]
00007dd8609e1e9c  vmovaps xmm12, [rsp+0xC0]
00007dd8609e1ea5  vmovaps xmm13, [rsp+0xD0]
00007dd8609e1eae  vmovaps xmm15, [rsp+0xE0]
00007dd8609e1eb7  add rsp, 0xF0
00007dd8609e1ebe  pop r11
00007dd8609e1ec0  pop r10
00007dd8609e1ec2  pop r9
00007dd8609e1ec4  pop r8
00007dd8609e1ec6  pop rsi
00007dd8609e1ec7  pop rdi
00007dd8609e1ec8  pop rdx
00007dd8609e1ec9  pop rcx
00007dd8609e1eca  pop rax
00007dd8609e1ecb  add rsp, 0x08
00007dd8609e1ecf  jmp 0x00007DD8609DF4B0
00007dd8609e1ed4  sub rsp, 0x08
00007dd8609e1ed8  push rax
00007dd8609e1ed9  push rcx
00007dd8609e1eda  push rdx
00007dd8609e1edb  push rdi
00007dd8609e1edc  push rsi
00007dd8609e1edd  push r8
00007dd8609e1edf  push r9
00007dd8609e1ee1  push r10
00007dd8609e1ee3  push r11
00007dd8609e1ee5  sub rsp, 0xF0
00007dd8609e1eec  vmovaps [rsp], xmm0
00007dd8609e1ef1  vmovaps [rsp+0x10], xmm2
00007dd8609e1ef7  vmovaps [rsp+0x20], xmm3
00007dd8609e1efd  vmovaps [rsp+0x30], xmm4
00007dd8609e1f03  vmovaps [rsp+0x40], xmm5
00007dd8609e1f09  vmovaps [rsp+0x50], xmm6
00007dd8609e1f0f  vmovaps [rsp+0x60], xmm7
00007dd8609e1f15  vmovaps [rsp+0x70], xmm8
00007dd8609e1f1b  vmovaps [rsp+0x80], xmm9
00007dd8609e1f24  vmovaps [rsp+0x90], xmm10
00007dd8609e1f2d  vmovaps [rsp+0xA0], xmm11
00007dd8609e1f36  vmovaps [rsp+0xB0], xmm12
00007dd8609e1f3f  vmovaps [rsp+0xC0], xmm13
00007dd8609e1f48  vmovaps [rsp+0xD0], xmm14
00007dd8609e1f51  vmovaps [rsp+0xE0], xmm15
00007dd8609e1f5a  sub rsp, 0x30
00007dd8609e1f5e  movaps [rsp], xmm1
00007dd8609e1f62  movaps [rsp+0x10], xmm4
00007dd8609e1f67  movaps [rsp+0x20], xmm9
00007dd8609e1f6d  lea rdi, [rsp]
00007dd8609e1f71  mov esi, 0x00
00007dd8609e1f76  mov rax, 0x629C9CFA9530
00007dd8609e1f80  call rax
00007dd8609e1f82  movaps xmm1, [rsp]
00007dd8609e1f86  add rsp, 0x30
00007dd8609e1f8a  vmovaps xmm0, [rsp]
00007dd8609e1f8f  vmovaps xmm2, [rsp+0x10]
00007dd8609e1f95  vmovaps xmm3, [rsp+0x20]
00007dd8609e1f9b  vmovaps xmm4, [rsp+0x30]
00007dd8609e1fa1  vmovaps xmm5, [rsp+0x40]
00007dd8609e1fa7  vmovaps xmm6, [rsp+0x50]
00007dd8609e1fad  vmovaps xmm7, [rsp+0x60]
00007dd8609e1fb3  vmovaps xmm8, [rsp+0x70]
00007dd8609e1fb9  vmovaps xmm9, [rsp+0x80]
00007dd8609e1fc2  vmovaps xmm10, [rsp+0x90]
00007dd8609e1fcb  vmovaps xmm11, [rsp+0xA0]
00007dd8609e1fd4  vmovaps xmm12, [rsp+0xB0]
00007dd8609e1fdd  vmovaps xmm13, [rsp+0xC0]
00007dd8609e1fe6  vmovaps xmm14, [rsp+0xD0]
00007dd8609e1fef  vmovaps xmm15, [rsp+0xE0]
00007dd8609e1ff8  add rsp, 0xF0
00007dd8609e1fff  pop r11
00007dd8609e2001  pop r10
00007dd8609e2003  pop r9
00007dd8609e2005  pop r8
00007dd8609e2007  pop rsi
00007dd8609e2008  pop rdi
00007dd8609e2009  pop rdx
00007dd8609e200a  pop rcx
00007dd8609e200b  pop rax
00007dd8609e200c  add rsp, 0x08
00007dd8609e2010  jmp 0x00007DD8609DF4CE
00007dd8609e2015  sub rsp, 0x08
00007dd8609e2019  push rax
00007dd8609e201a  push rcx
00007dd8609e201b  push rdx
00007dd8609e201c  push rdi
00007dd8609e201d  push rsi
00007dd8609e201e  push r8
00007dd8609e2020  push r9
00007dd8609e2022  push r10
00007dd8609e2024  push r11
00007dd8609e2026  sub rsp, 0xF0
00007dd8609e202d  vmovaps [rsp], xmm0
00007dd8609e2032  vmovaps [rsp+0x10], xmm1
00007dd8609e2038  vmovaps [rsp+0x20], xmm2
00007dd8609e203e  vmovaps [rsp+0x30], xmm3
00007dd8609e2044  vmovaps [rsp+0x40], xmm5
00007dd8609e204a  vmovaps [rsp+0x50], xmm6
00007dd8609e2050  vmovaps [rsp+0x60], xmm7
00007dd8609e2056  vmovaps [rsp+0x70], xmm8
00007dd8609e205c  vmovaps [rsp+0x80], xmm9
00007dd8609e2065  vmovaps [rsp+0x90], xmm10
00007dd8609e206e  vmovaps [rsp+0xA0], xmm11
00007dd8609e2077  vmovaps [rsp+0xB0], xmm12
00007dd8609e2080  vmovaps [rsp+0xC0], xmm13
00007dd8609e2089  vmovaps [rsp+0xD0], xmm14
00007dd8609e2092  vmovaps [rsp+0xE0], xmm15
00007dd8609e209b  sub rsp, 0x30
00007dd8609e209f  movaps [rsp], xmm4
00007dd8609e20a3  movaps [rsp+0x10], xmm2
00007dd8609e20a8  movaps [rsp+0x20], xmm9
00007dd8609e20ae  lea rdi, [rsp]
00007dd8609e20b2  mov esi, 0x00
00007dd8609e20b7  mov rax, 0x629C9CFA9530
00007dd8609e20c1  call rax
00007dd8609e20c3  movaps xmm4, [rsp]
00007dd8609e20c7  add rsp, 0x30
00007dd8609e20cb  vmovaps xmm0, [rsp]
00007dd8609e20d0  vmovaps xmm1, [rsp+0x10]
00007dd8609e20d6  vmovaps xmm2, [rsp+0x20]
00007dd8609e20dc  vmovaps xmm3, [rsp+0x30]
00007dd8609e20e2  vmovaps xmm5, [rsp+0x40]
00007dd8609e20e8  vmovaps xmm6, [rsp+0x50]
00007dd8609e20ee  vmovaps xmm7, [rsp+0x60]
00007dd8609e20f4  vmovaps xmm8, [rsp+0x70]
00007dd8609e20fa  vmovaps xmm9, [rsp+0x80]
00007dd8609e2103  vmovaps xmm10, [rsp+0x90]
00007dd8609e210c  vmovaps xmm11, [rsp+0xA0]
00007dd8609e2115  vmovaps xmm12, [rsp+0xB0]
00007dd8609e211e  vmovaps xmm13, [rsp+0xC0]
00007dd8609e2127  vmovaps xmm14, [rsp+0xD0]
00007dd8609e2130  vmovaps xmm15, [rsp+0xE0]
00007dd8609e2139  add rsp, 0xF0
00007dd8609e2140  pop r11
00007dd8609e2142  pop r10
00007dd8609e2144  pop r9
00007dd8609e2146  pop r8
00007dd8609e2148  pop rsi
00007dd8609e2149  pop rdi
00007dd8609e214a  pop rdx
00007dd8609e214b  pop rcx
00007dd8609e214c  pop rax
00007dd8609e214d  add rsp, 0x08
00007dd8609e2151  jmp 0x00007DD8609DF4FE
00007dd8609e2156  sub rsp, 0x08
00007dd8609e215a  push rax
00007dd8609e215b  push rcx
00007dd8609e215c  push rdx
00007dd8609e215d  push rdi
00007dd8609e215e  push rsi
00007dd8609e215f  push r8
00007dd8609e2161  push r9
00007dd8609e2163  push r10
00007dd8609e2165  push r11
00007dd8609e2167  sub rsp, 0xF0
00007dd8609e216e  vmovaps [rsp], xmm0
00007dd8609e2173  vmovaps [rsp+0x10], xmm1
00007dd8609e2179  vmovaps [rsp+0x20], xmm2
00007dd8609e217f  vmovaps [rsp+0x30], xmm3
00007dd8609e2185  vmovaps [rsp+0x40], xmm4
00007dd8609e218b  vmovaps [rsp+0x50], xmm5
00007dd8609e2191  vmovaps [rsp+0x60], xmm6
00007dd8609e2197  vmovaps [rsp+0x70], xmm7
00007dd8609e219d  vmovaps [rsp+0x80], xmm8
00007dd8609e21a6  vmovaps [rsp+0x90], xmm10
00007dd8609e21af  vmovaps [rsp+0xA0], xmm11
00007dd8609e21b8  vmovaps [rsp+0xB0], xmm12
00007dd8609e21c1  vmovaps [rsp+0xC0], xmm13
00007dd8609e21ca  vmovaps [rsp+0xD0], xmm14
00007dd8609e21d3  vmovaps [rsp+0xE0], xmm15
00007dd8609e21dc  sub rsp, 0x30
00007dd8609e21e0  movaps [rsp], xmm9
00007dd8609e21e5  movaps [rsp+0x10], xmm2
00007dd8609e21ea  movaps [rsp+0x20], xmm1
00007dd8609e21ef  lea rdi, [rsp]
00007dd8609e21f3  mov esi, 0x00
00007dd8609e21f8  mov rax, 0x629C9CFA9530
00007dd8609e2202  call rax
00007dd8609e2204  movaps xmm9, [rsp]
00007dd8609e2209  add rsp, 0x30
00007dd8609e220d  vmovaps xmm0, [rsp]
00007dd8609e2212  vmovaps xmm1, [rsp+0x10]
00007dd8609e2218  vmovaps xmm2, [rsp+0x20]
00007dd8609e221e  vmovaps xmm3, [rsp+0x30]
00007dd8609e2224  vmovaps xmm4, [rsp+0x40]
00007dd8609e222a  vmovaps xmm5, [rsp+0x50]
00007dd8609e2230  vmovaps xmm6, [rsp+0x60]
00007dd8609e2236  vmovaps xmm7, [rsp+0x70]
00007dd8609e223c  vmovaps xmm8, [rsp+0x80]
00007dd8609e2245  vmovaps xmm10, [rsp+0x90]
00007dd8609e224e  vmovaps xmm11, [rsp+0xA0]
00007dd8609e2257  vmovaps xmm12, [rsp+0xB0]
00007dd8609e2260  vmovaps xmm13, [rsp+0xC0]
00007dd8609e2269  vmovaps xmm14, [rsp+0xD0]
00007dd8609e2272  vmovaps xmm15, [rsp+0xE0]
00007dd8609e227b  add rsp, 0xF0
00007dd8609e2282  pop r11
00007dd8609e2284  pop r10
00007dd8609e2286  pop r9
00007dd8609e2288  pop r8
00007dd8609e228a  pop rsi
00007dd8609e228b  pop rdi
00007dd8609e228c  pop rdx
00007dd8609e228d  pop rcx
00007dd8609e228e  pop rax
00007dd8609e228f  add rsp, 0x08
00007dd8609e2293  jmp 0x00007DD8609DF534
00007dd8609e2298  sub rsp, 0x08
00007dd8609e229c  push rax
00007dd8609e229d  push rcx
00007dd8609e229e  push rdx
00007dd8609e229f  push rdi
00007dd8609e22a0  push rsi
00007dd8609e22a1  push r8
00007dd8609e22a3  push r9
00007dd8609e22a5  push r10
00007dd8609e22a7  push r11
00007dd8609e22a9  sub rsp, 0xF0
00007dd8609e22b0  vmovaps [rsp], xmm0
00007dd8609e22b5  vmovaps [rsp+0x10], xmm2
00007dd8609e22bb  vmovaps [rsp+0x20], xmm3
00007dd8609e22c1  vmovaps [rsp+0x30], xmm4
00007dd8609e22c7  vmovaps [rsp+0x40], xmm5
00007dd8609e22cd  vmovaps [rsp+0x50], xmm6
00007dd8609e22d3  vmovaps [rsp+0x60], xmm7
00007dd8609e22d9  vmovaps [rsp+0x70], xmm8
00007dd8609e22df  vmovaps [rsp+0x80], xmm9
00007dd8609e22e8  vmovaps [rsp+0x90], xmm10
00007dd8609e22f1  vmovaps [rsp+0xA0], xmm11
00007dd8609e22fa  vmovaps [rsp+0xB0], xmm12
00007dd8609e2303  vmovaps [rsp+0xC0], xmm13
00007dd8609e230c  vmovaps [rsp+0xD0], xmm14
00007dd8609e2315  vmovaps [rsp+0xE0], xmm15
00007dd8609e231e  sub rsp, 0x30
00007dd8609e2322  movaps [rsp], xmm1
00007dd8609e2326  movaps [rsp+0x10], xmm15
00007dd8609e232c  movaps [rsp+0x20], xmm6
00007dd8609e2331  lea rdi, [rsp]
00007dd8609e2335  mov esi, 0x00
00007dd8609e233a  mov rax, 0x629C9CFA9530
00007dd8609e2344  call rax
00007dd8609e2346  movaps xmm1, [rsp]
00007dd8609e234a  add rsp, 0x30
00007dd8609e234e  vmovaps xmm0, [rsp]
00007dd8609e2353  vmovaps xmm2, [rsp+0x10]
00007dd8609e2359  vmovaps xmm3, [rsp+0x20]
00007dd8609e235f  vmovaps xmm4, [rsp+0x30]
00007dd8609e2365  vmovaps xmm5, [rsp+0x40]
00007dd8609e236b  vmovaps xmm6, [rsp+0x50]
00007dd8609e2371  vmovaps xmm7, [rsp+0x60]
00007dd8609e2377  vmovaps xmm8, [rsp+0x70]
00007dd8609e237d  vmovaps xmm9, [rsp+0x80]
00007dd8609e2386  vmovaps xmm10, [rsp+0x90]
00007dd8609e238f  vmovaps xmm11, [rsp+0xA0]
00007dd8609e2398  vmovaps xmm12, [rsp+0xB0]
00007dd8609e23a1  vmovaps xmm13, [rsp+0xC0]
00007dd8609e23aa  vmovaps xmm14, [rsp+0xD0]
00007dd8609e23b3  vmovaps xmm15, [rsp+0xE0]
00007dd8609e23bc  add rsp, 0xF0
00007dd8609e23c3  pop r11
00007dd8609e23c5  pop r10
00007dd8609e23c7  pop r9
00007dd8609e23c9  pop r8
00007dd8609e23cb  pop rsi
00007dd8609e23cc  pop rdi
00007dd8609e23cd  pop rdx
00007dd8609e23ce  pop rcx
00007dd8609e23cf  pop rax
00007dd8609e23d0  add rsp, 0x08
00007dd8609e23d4  jmp 0x00007DD8609DF555
00007dd8609e23d9  sub rsp, 0x08
00007dd8609e23dd  push rax
00007dd8609e23de  push rcx
00007dd8609e23df  push rdx
00007dd8609e23e0  push rdi
00007dd8609e23e1  push rsi
00007dd8609e23e2  push r8
00007dd8609e23e4  push r9
00007dd8609e23e6  push r10
00007dd8609e23e8  push r11
00007dd8609e23ea  sub rsp, 0xF0
00007dd8609e23f1  vmovaps [rsp], xmm0
00007dd8609e23f6  vmovaps [rsp+0x10], xmm1
00007dd8609e23fc  vmovaps [rsp+0x20], xmm2
00007dd8609e2402  vmovaps [rsp+0x30], xmm3
00007dd8609e2408  vmovaps [rsp+0x40], xmm4
00007dd8609e240e  vmovaps [rsp+0x50], xmm5
00007dd8609e2414  vmovaps [rsp+0x60], xmm6
00007dd8609e241a  vmovaps [rsp+0x70], xmm7
00007dd8609e2420  vmovaps [rsp+0x80], xmm8
00007dd8609e2429  vmovaps [rsp+0x90], xmm9
00007dd8609e2432  vmovaps [rsp+0xA0], xmm10
00007dd8609e243b  vmovaps [rsp+0xB0], xmm11
00007dd8609e2444  vmovaps [rsp+0xC0], xmm12
00007dd8609e244d  vmovaps [rsp+0xD0], xmm13
00007dd8609e2456  vmovaps [rsp+0xE0], xmm14
00007dd8609e245f  sub rsp, 0x30
00007dd8609e2463  movaps [rsp], xmm15
00007dd8609e2468  movaps [rsp+0x10], xmm5
00007dd8609e246d  movaps [rsp+0x20], xmm3
00007dd8609e2472  lea rdi, [rsp]
00007dd8609e2476  mov esi, 0x00
00007dd8609e247b  mov rax, 0x629C9CFA9530
00007dd8609e2485  call rax
00007dd8609e2487  movaps xmm15, [rsp]
00007dd8609e248c  add rsp, 0x30
00007dd8609e2490  vmovaps xmm0, [rsp]
00007dd8609e2495  vmovaps xmm1, [rsp+0x10]
00007dd8609e249b  vmovaps xmm2, [rsp+0x20]
00007dd8609e24a1  vmovaps xmm3, [rsp+0x30]
00007dd8609e24a7  vmovaps xmm4, [rsp+0x40]
00007dd8609e24ad  vmovaps xmm5, [rsp+0x50]
00007dd8609e24b3  vmovaps xmm6, [rsp+0x60]
00007dd8609e24b9  vmovaps xmm7, [rsp+0x70]
00007dd8609e24bf  vmovaps xmm8, [rsp+0x80]
00007dd8609e24c8  vmovaps xmm9, [rsp+0x90]
00007dd8609e24d1  vmovaps xmm10, [rsp+0xA0]
00007dd8609e24da  vmovaps xmm11, [rsp+0xB0]
00007dd8609e24e3  vmovaps xmm12, [rsp+0xC0]
00007dd8609e24ec  vmovaps xmm13, [rsp+0xD0]
00007dd8609e24f5  vmovaps xmm14, [rsp+0xE0]
00007dd8609e24fe  add rsp, 0xF0
00007dd8609e2505  pop r11
00007dd8609e2507  pop r10
00007dd8609e2509  pop r9
00007dd8609e250b  pop r8
00007dd8609e250d  pop rsi
00007dd8609e250e  pop rdi
00007dd8609e250f  pop rdx
00007dd8609e2510  pop rcx
00007dd8609e2511  pop rax
00007dd8609e2512  add rsp, 0x08
00007dd8609e2516  jmp 0x00007DD8609DF56F
00007dd8609e251b  sub rsp, 0x08
00007dd8609e251f  push rax
00007dd8609e2520  push rcx
00007dd8609e2521  push rdx
00007dd8609e2522  push rdi
00007dd8609e2523  push rsi
00007dd8609e2524  push r8
00007dd8609e2526  push r9
00007dd8609e2528  push r10
00007dd8609e252a  push r11
00007dd8609e252c  sub rsp, 0xF0
00007dd8609e2533  vmovaps [rsp], xmm0
00007dd8609e2538  vmovaps [rsp+0x10], xmm1
00007dd8609e253e  vmovaps [rsp+0x20], xmm2
00007dd8609e2544  vmovaps [rsp+0x30], xmm3
00007dd8609e254a  vmovaps [rsp+0x40], xmm4
00007dd8609e2550  vmovaps [rsp+0x50], xmm6
00007dd8609e2556  vmovaps [rsp+0x60], xmm7
00007dd8609e255c  vmovaps [rsp+0x70], xmm8
00007dd8609e2562  vmovaps [rsp+0x80], xmm9
00007dd8609e256b  vmovaps [rsp+0x90], xmm10
00007dd8609e2574  vmovaps [rsp+0xA0], xmm11
00007dd8609e257d  vmovaps [rsp+0xB0], xmm12
00007dd8609e2586  vmovaps [rsp+0xC0], xmm13
00007dd8609e258f  vmovaps [rsp+0xD0], xmm14
00007dd8609e2598  vmovaps [rsp+0xE0], xmm15
00007dd8609e25a1  sub rsp, 0x30
00007dd8609e25a5  movaps [rsp], xmm5
00007dd8609e25a9  movaps [rsp+0x10], xmm8
00007dd8609e25af  movaps [rsp+0x20], xmm6
00007dd8609e25b4  lea rdi, [rsp]
00007dd8609e25b8  mov esi, 0x00
00007dd8609e25bd  mov rax, 0x629C9CFA9530
00007dd8609e25c7  call rax
00007dd8609e25c9  movaps xmm5, [rsp]
00007dd8609e25cd  add rsp, 0x30
00007dd8609e25d1  vmovaps xmm0, [rsp]
00007dd8609e25d6  vmovaps xmm1, [rsp+0x10]
00007dd8609e25dc  vmovaps xmm2, [rsp+0x20]
00007dd8609e25e2  vmovaps xmm3, [rsp+0x30]
00007dd8609e25e8  vmovaps xmm4, [rsp+0x40]
00007dd8609e25ee  vmovaps xmm6, [rsp+0x50]
00007dd8609e25f4  vmovaps xmm7, [rsp+0x60]
00007dd8609e25fa  vmovaps xmm8, [rsp+0x70]
00007dd8609e2600  vmovaps xmm9, [rsp+0x80]
00007dd8609e2609  vmovaps xmm10, [rsp+0x90]
00007dd8609e2612  vmovaps xmm11, [rsp+0xA0]
00007dd8609e261b  vmovaps xmm12, [rsp+0xB0]
00007dd8609e2624  vmovaps xmm13, [rsp+0xC0]
00007dd8609e262d  vmovaps xmm14, [rsp+0xD0]
00007dd8609e2636  vmovaps xmm15, [rsp+0xE0]
00007dd8609e263f  add rsp, 0xF0
00007dd8609e2646  pop r11
00007dd8609e2648  pop r10
00007dd8609e264a  pop r9
00007dd8609e264c  pop r8
00007dd8609e264e  pop rsi
00007dd8609e264f  pop rdi
00007dd8609e2650  pop rdx
00007dd8609e2651  pop rcx
00007dd8609e2652  pop rax
00007dd8609e2653  add rsp, 0x08
00007dd8609e2657  jmp 0x00007DD8609DF593
00007dd8609e265c  sub rsp, 0x08
00007dd8609e2660  push rax
00007dd8609e2661  push rcx
00007dd8609e2662  push rdx
00007dd8609e2663  push rdi
00007dd8609e2664  push rsi
00007dd8609e2665  push r8
00007dd8609e2667  push r9
00007dd8609e2669  push r10
00007dd8609e266b  push r11
00007dd8609e266d  sub rsp, 0xF0
00007dd8609e2674  vmovaps [rsp], xmm0
00007dd8609e2679  vmovaps [rsp+0x10], xmm1
00007dd8609e267f  vmovaps [rsp+0x20], xmm2
00007dd8609e2685  vmovaps [rsp+0x30], xmm3
00007dd8609e268b  vmovaps [rsp+0x40], xmm4
00007dd8609e2691  vmovaps [rsp+0x50], xmm5
00007dd8609e2697  vmovaps [rsp+0x60], xmm7
00007dd8609e269d  vmovaps [rsp+0x70], xmm8
00007dd8609e26a3  vmovaps [rsp+0x80], xmm9
00007dd8609e26ac  vmovaps [rsp+0x90], xmm10
00007dd8609e26b5  vmovaps [rsp+0xA0], xmm11
00007dd8609e26be  vmovaps [rsp+0xB0], xmm12
00007dd8609e26c7  vmovaps [rsp+0xC0], xmm13
00007dd8609e26d0  vmovaps [rsp+0xD0], xmm14
00007dd8609e26d9  vmovaps [rsp+0xE0], xmm15
00007dd8609e26e2  sub rsp, 0x30
00007dd8609e26e6  movaps [rsp], xmm6
00007dd8609e26ea  movaps [rsp+0x10], xmm10
00007dd8609e26f0  movaps [rsp+0x20], xmm8
00007dd8609e26f6  lea rdi, [rsp]
00007dd8609e26fa  mov esi, 0x00
00007dd8609e26ff  mov rax, 0x629C9CFA9530
00007dd8609e2709  call rax
00007dd8609e270b  movaps xmm6, [rsp]
00007dd8609e270f  add rsp, 0x30
00007dd8609e2713  vmovaps xmm0, [rsp]
00007dd8609e2718  vmovaps xmm1, [rsp+0x10]
00007dd8609e271e  vmovaps xmm2, [rsp+0x20]
00007dd8609e2724  vmovaps xmm3, [rsp+0x30]
00007dd8609e272a  vmovaps xmm4, [rsp+0x40]
00007dd8609e2730  vmovaps xmm5, [rsp+0x50]
00007dd8609e2736  vmovaps xmm7, [rsp+0x60]
00007dd8609e273c  vmovaps xmm8, [rsp+0x70]
00007dd8609e2742  vmovaps xmm9, [rsp+0x80]
00007dd8609e274b  vmovaps xmm10, [rsp+0x90]
00007dd8609e2754  vmovaps xmm11, [rsp+0xA0]
00007dd8609e275d  vmovaps xmm12, [rsp+0xB0]
00007dd8609e2766  vmovaps xmm13, [rsp+0xC0]
00007dd8609e276f  vmovaps xmm14, [rsp+0xD0]
00007dd8609e2778  vmovaps xmm15, [rsp+0xE0]
00007dd8609e2781  add rsp, 0xF0
00007dd8609e2788  pop r11
00007dd8609e278a  pop r10
00007dd8609e278c  pop r9
00007dd8609e278e  pop r8
00007dd8609e2790  pop rsi
00007dd8609e2791  pop rdi
00007dd8609e2792  pop rdx
00007dd8609e2793  pop rcx
00007dd8609e2794  pop rax
00007dd8609e2795  add rsp, 0x08
00007dd8609e2799  jmp 0x00007DD8609DF5B8
00007dd8609e279e  sub rsp, 0x08
00007dd8609e27a2  push rax
00007dd8609e27a3  push rcx
00007dd8609e27a4  push rdx
00007dd8609e27a5  push rdi
00007dd8609e27a6  push rsi
00007dd8609e27a7  push r8
00007dd8609e27a9  push r9
00007dd8609e27ab  push r10
00007dd8609e27ad  push r11
00007dd8609e27af  sub rsp, 0xF0
00007dd8609e27b6  vmovaps [rsp], xmm0
00007dd8609e27bb  vmovaps [rsp+0x10], xmm1
00007dd8609e27c1  vmovaps [rsp+0x20], xmm2
00007dd8609e27c7  vmovaps [rsp+0x30], xmm3
00007dd8609e27cd  vmovaps [rsp+0x40], xmm4
00007dd8609e27d3  vmovaps [rsp+0x50], xmm5
00007dd8609e27d9  vmovaps [rsp+0x60], xmm6
00007dd8609e27df  vmovaps [rsp+0x70], xmm7
00007dd8609e27e5  vmovaps [rsp+0x80], xmm8
00007dd8609e27ee  vmovaps [rsp+0x90], xmm9
00007dd8609e27f7  vmovaps [rsp+0xA0], xmm11
00007dd8609e2800  vmovaps [rsp+0xB0], xmm12
00007dd8609e2809  vmovaps [rsp+0xC0], xmm13
00007dd8609e2812  vmovaps [rsp+0xD0], xmm14
00007dd8609e281b  vmovaps [rsp+0xE0], xmm15
00007dd8609e2824  sub rsp, 0x30
00007dd8609e2828  movaps [rsp], xmm10
00007dd8609e282d  movaps [rsp+0x10], xmm8
00007dd8609e2833  movaps [rsp+0x20], xmm14
00007dd8609e2839  lea rdi, [rsp]
00007dd8609e283d  mov esi, 0x00
00007dd8609e2842  mov rax, 0x629C9CFA9530
00007dd8609e284c  call rax
00007dd8609e284e  movaps xmm10, [rsp]
00007dd8609e2853  add rsp, 0x30
00007dd8609e2857  vmovaps xmm0, [rsp]
00007dd8609e285c  vmovaps xmm1, [rsp+0x10]
00007dd8609e2862  vmovaps xmm2, [rsp+0x20]
00007dd8609e2868  vmovaps xmm3, [rsp+0x30]
00007dd8609e286e  vmovaps xmm4, [rsp+0x40]
00007dd8609e2874  vmovaps xmm5, [rsp+0x50]
00007dd8609e287a  vmovaps xmm6, [rsp+0x60]
00007dd8609e2880  vmovaps xmm7, [rsp+0x70]
00007dd8609e2886  vmovaps xmm8, [rsp+0x80]
00007dd8609e288f  vmovaps xmm9, [rsp+0x90]
00007dd8609e2898  vmovaps xmm11, [rsp+0xA0]
00007dd8609e28a1  vmovaps xmm12, [rsp+0xB0]
00007dd8609e28aa  vmovaps xmm13, [rsp+0xC0]
00007dd8609e28b3  vmovaps xmm14, [rsp+0xD0]
00007dd8609e28bc  vmovaps xmm15, [rsp+0xE0]
00007dd8609e28c5  add rsp, 0xF0
00007dd8609e28cc  pop r11
00007dd8609e28ce  pop r10
00007dd8609e28d0  pop r9
00007dd8609e28d2  pop r8
00007dd8609e28d4  pop rsi
00007dd8609e28d5  pop rdi
00007dd8609e28d6  pop rdx
00007dd8609e28d7  pop rcx
00007dd8609e28d8  pop rax
00007dd8609e28d9  add rsp, 0x08
00007dd8609e28dd  jmp 0x00007DD8609DF5D8
00007dd8609e28e2  sub rsp, 0x08
00007dd8609e28e6  push rax
00007dd8609e28e7  push rcx
00007dd8609e28e8  push rdx
00007dd8609e28e9  push rdi
00007dd8609e28ea  push rsi
00007dd8609e28eb  push r8
00007dd8609e28ed  push r9
00007dd8609e28ef  push r10
00007dd8609e28f1  push r11
00007dd8609e28f3  sub rsp, 0xF0
00007dd8609e28fa  vmovaps [rsp], xmm0
00007dd8609e28ff  vmovaps [rsp+0x10], xmm1
00007dd8609e2905  vmovaps [rsp+0x20], xmm2
00007dd8609e290b  vmovaps [rsp+0x30], xmm3
00007dd8609e2911  vmovaps [rsp+0x40], xmm4
00007dd8609e2917  vmovaps [rsp+0x50], xmm5
00007dd8609e291d  vmovaps [rsp+0x60], xmm6
00007dd8609e2923  vmovaps [rsp+0x70], xmm7
00007dd8609e2929  vmovaps [rsp+0x80], xmm8
00007dd8609e2932  vmovaps [rsp+0x90], xmm9
00007dd8609e293b  vmovaps [rsp+0xA0], xmm10
00007dd8609e2944  vmovaps [rsp+0xB0], xmm11
00007dd8609e294d  vmovaps [rsp+0xC0], xmm12
00007dd8609e2956  vmovaps [rsp+0xD0], xmm13
00007dd8609e295f  vmovaps [rsp+0xE0], xmm15
00007dd8609e2968  sub rsp, 0x30
00007dd8609e296c  movaps [rsp], xmm14
00007dd8609e2971  movaps [rsp+0x10], xmm8
00007dd8609e2977  movaps [rsp+0x20], xmm4
00007dd8609e297c  lea rdi, [rsp]
00007dd8609e2980  mov esi, 0x00
00007dd8609e2985  mov rax, 0x629C9CFA9530
00007dd8609e298f  call rax
00007dd8609e2991  movaps xmm14, [rsp]
00007dd8609e2996  add rsp, 0x30
00007dd8609e299a  vmovaps xmm0, [rsp]
00007dd8609e299f  vmovaps xmm1, [rsp+0x10]
00007dd8609e29a5  vmovaps xmm2, [rsp+0x20]
00007dd8609e29ab  vmovaps xmm3, [rsp+0x30]
00007dd8609e29b1  vmovaps xmm4, [rsp+0x40]
00007dd8609e29b7  vmovaps xmm5, [rsp+0x50]
00007dd8609e29bd  vmovaps xmm6, [rsp+0x60]
00007dd8609e29c3  vmovaps xmm7, [rsp+0x70]
00007dd8609e29c9  vmovaps xmm8, [rsp+0x80]
00007dd8609e29d2  vmovaps xmm9, [rsp+0x90]
00007dd8609e29db  vmovaps xmm10, [rsp+0xA0]
00007dd8609e29e4  vmovaps xmm11, [rsp+0xB0]
00007dd8609e29ed  vmovaps xmm12, [rsp+0xC0]
00007dd8609e29f6  vmovaps xmm13, [rsp+0xD0]
00007dd8609e29ff  vmovaps xmm15, [rsp+0xE0]
00007dd8609e2a08  add rsp, 0xF0
00007dd8609e2a0f  pop r11
00007dd8609e2a11  pop r10
00007dd8609e2a13  pop r9
00007dd8609e2a15  pop r8
00007dd8609e2a17  pop rsi
00007dd8609e2a18  pop rdi
00007dd8609e2a19  pop rdx
00007dd8609e2a1a  pop rcx
00007dd8609e2a1b  pop rax
00007dd8609e2a1c  add rsp, 0x08
00007dd8609e2a20  jmp 0x00007DD8609DF5F8
00007dd8609e2a25  sub rsp, 0x08
00007dd8609e2a29  push rax
00007dd8609e2a2a  push rcx
00007dd8609e2a2b  push rdx
00007dd8609e2a2c  push rdi
00007dd8609e2a2d  push rsi
00007dd8609e2a2e  push r8
00007dd8609e2a30  push r9
00007dd8609e2a32  push r10
00007dd8609e2a34  push r11
00007dd8609e2a36  sub rsp, 0xF0
00007dd8609e2a3d  vmovaps [rsp], xmm0
00007dd8609e2a42  vmovaps [rsp+0x10], xmm1
00007dd8609e2a48  vmovaps [rsp+0x20], xmm2
00007dd8609e2a4e  vmovaps [rsp+0x30], xmm3
00007dd8609e2a54  vmovaps [rsp+0x40], xmm5
00007dd8609e2a5a  vmovaps [rsp+0x50], xmm6
00007dd8609e2a60  vmovaps [rsp+0x60], xmm7
00007dd8609e2a66  vmovaps [rsp+0x70], xmm8
00007dd8609e2a6c  vmovaps [rsp+0x80], xmm9
00007dd8609e2a75  vmovaps [rsp+0x90], xmm10
00007dd8609e2a7e  vmovaps [rsp+0xA0], xmm11
00007dd8609e2a87  vmovaps [rsp+0xB0], xmm12
00007dd8609e2a90  vmovaps [rsp+0xC0], xmm13
00007dd8609e2a99  vmovaps [rsp+0xD0], xmm14
00007dd8609e2aa2  vmovaps [rsp+0xE0], xmm15
00007dd8609e2aab  sub rsp, 0x30
00007dd8609e2aaf  movaps [rsp], xmm4
00007dd8609e2ab3  movaps [rsp+0x10], xmm13
00007dd8609e2ab9  movaps [rsp+0x20], xmm8
00007dd8609e2abf  lea rdi, [rsp]
00007dd8609e2ac3  mov esi, 0x00
00007dd8609e2ac8  mov rax, 0x629C9CFA9530
00007dd8609e2ad2  call rax
00007dd8609e2ad4  movaps xmm4, [rsp]
00007dd8609e2ad8  add rsp, 0x30
00007dd8609e2adc  vmovaps xmm0, [rsp]
00007dd8609e2ae1  vmovaps xmm1, [rsp+0x10]
00007dd8609e2ae7  vmovaps xmm2, [rsp+0x20]
00007dd8609e2aed  vmovaps xmm3, [rsp+0x30]
00007dd8609e2af3  vmovaps xmm5, [rsp+0x40]
00007dd8609e2af9  vmovaps xmm6, [rsp+0x50]
00007dd8609e2aff  vmovaps xmm7, [rsp+0x60]
00007dd8609e2b05  vmovaps xmm8, [rsp+0x70]
00007dd8609e2b0b  vmovaps xmm9, [rsp+0x80]
00007dd8609e2b14  vmovaps xmm10, [rsp+0x90]
00007dd8609e2b1d  vmovaps xmm11, [rsp+0xA0]
00007dd8609e2b26  vmovaps xmm12, [rsp+0xB0]
00007dd8609e2b2f  vmovaps xmm13, [rsp+0xC0]
00007dd8609e2b38  vmovaps xmm14, [rsp+0xD0]
00007dd8609e2b41  vmovaps xmm15, [rsp+0xE0]
00007dd8609e2b4a  add rsp, 0xF0
00007dd8609e2b51  pop r11
00007dd8609e2b53  pop r10
00007dd8609e2b55  pop r9
00007dd8609e2b57  pop r8
00007dd8609e2b59  pop rsi
00007dd8609e2b5a  pop rdi
00007dd8609e2b5b  pop rdx
00007dd8609e2b5c  pop rcx
00007dd8609e2b5d  pop rax
00007dd8609e2b5e  add rsp, 0x08
00007dd8609e2b62  jmp 0x00007DD8609DF61D
00007dd8609e2b67  sub rsp, 0x08
00007dd8609e2b6b  push rax
00007dd8609e2b6c  push rcx
00007dd8609e2b6d  push rdx
00007dd8609e2b6e  push rdi
00007dd8609e2b6f  push rsi
00007dd8609e2b70  push r8
00007dd8609e2b72  push r9
00007dd8609e2b74  push r10
00007dd8609e2b76  push r11
00007dd8609e2b78  sub rsp, 0xF0
00007dd8609e2b7f  vmovaps [rsp], xmm0
00007dd8609e2b84  vmovaps [rsp+0x10], xmm1
00007dd8609e2b8a  vmovaps [rsp+0x20], xmm2
00007dd8609e2b90  vmovaps [rsp+0x30], xmm3
00007dd8609e2b96  vmovaps [rsp+0x40], xmm4
00007dd8609e2b9c  vmovaps [rsp+0x50], xmm5
00007dd8609e2ba2  vmovaps [rsp+0x60], xmm6
00007dd8609e2ba8  vmovaps [rsp+0x70], xmm7
00007dd8609e2bae  vmovaps [rsp+0x80], xmm8
00007dd8609e2bb7  vmovaps [rsp+0x90], xmm9
00007dd8609e2bc0  vmovaps [rsp+0xA0], xmm10
00007dd8609e2bc9  vmovaps [rsp+0xB0], xmm11
00007dd8609e2bd2  vmovaps [rsp+0xC0], xmm12
00007dd8609e2bdb  vmovaps [rsp+0xD0], xmm14
00007dd8609e2be4  vmovaps [rsp+0xE0], xmm15
00007dd8609e2bed  sub rsp, 0x30
00007dd8609e2bf1  movaps [rsp], xmm13
00007dd8609e2bf6  movaps [rsp+0x10], xmm15
00007dd8609e2bfc  movaps [rsp+0x20], xmm9
00007dd8609e2c02  lea rdi, [rsp]
00007dd8609e2c06  mov esi, 0x00
00007dd8609e2c0b  mov rax, 0x629C9CFA9530
00007dd8609e2c15  call rax
00007dd8609e2c17  movaps xmm13, [rsp]
00007dd8609e2c1c  add rsp, 0x30
00007dd8609e2c20  vmovaps xmm0, [rsp]
00007dd8609e2c25  vmovaps xmm1, [rsp+0x10]
00007dd8609e2c2b  vmovaps xmm2, [rsp+0x20]
00007dd8609e2c31  vmovaps xmm3, [rsp+0x30]
00007dd8609e2c37  vmovaps xmm4, [rsp+0x40]
00007dd8609e2c3d  vmovaps xmm5, [rsp+0x50]
00007dd8609e2c43  vmovaps xmm6, [rsp+0x60]
00007dd8609e2c49  vmovaps xmm7, [rsp+0x70]
00007dd8609e2c4f  vmovaps xmm8, [rsp+0x80]
00007dd8609e2c58  vmovaps xmm9, [rsp+0x90]
00007dd8609e2c61  vmovaps xmm10, [rsp+0xA0]
00007dd8609e2c6a  vmovaps xmm11, [rsp+0xB0]
00007dd8609e2c73  vmovaps xmm12, [rsp+0xC0]
00007dd8609e2c7c  vmovaps xmm14, [rsp+0xD0]
00007dd8609e2c85  vmovaps xmm15, [rsp+0xE0]
00007dd8609e2c8e  add rsp, 0xF0
00007dd8609e2c95  pop r11
00007dd8609e2c97  pop r10
00007dd8609e2c99  pop r9
00007dd8609e2c9b  pop r8
00007dd8609e2c9d  pop rsi
00007dd8609e2c9e  pop rdi
00007dd8609e2c9f  pop rdx
00007dd8609e2ca0  pop rcx
00007dd8609e2ca1  pop rax
00007dd8609e2ca2  add rsp, 0x08
00007dd8609e2ca6  jmp 0x00007DD8609DF638
00007dd8609e2cab  sub rsp, 0x08
00007dd8609e2caf  push rax
00007dd8609e2cb0  push rcx
00007dd8609e2cb1  push rdx
00007dd8609e2cb2  push rdi
00007dd8609e2cb3  push rsi
00007dd8609e2cb4  push r8
00007dd8609e2cb6  push r9
00007dd8609e2cb8  push r10
00007dd8609e2cba  push r11
00007dd8609e2cbc  sub rsp, 0xF0
00007dd8609e2cc3  vmovaps [rsp], xmm0
00007dd8609e2cc8  vmovaps [rsp+0x10], xmm1
00007dd8609e2cce  vmovaps [rsp+0x20], xmm2
00007dd8609e2cd4  vmovaps [rsp+0x30], xmm3
00007dd8609e2cda  vmovaps [rsp+0x40], xmm4
00007dd8609e2ce0  vmovaps [rsp+0x50], xmm5
00007dd8609e2ce6  vmovaps [rsp+0x60], xmm6
00007dd8609e2cec  vmovaps [rsp+0x70], xmm7
00007dd8609e2cf2  vmovaps [rsp+0x80], xmm8
00007dd8609e2cfb  vmovaps [rsp+0x90], xmm9
00007dd8609e2d04  vmovaps [rsp+0xA0], xmm10
00007dd8609e2d0d  vmovaps [rsp+0xB0], xmm11
00007dd8609e2d16  vmovaps [rsp+0xC0], xmm12
00007dd8609e2d1f  vmovaps [rsp+0xD0], xmm13
00007dd8609e2d28  vmovaps [rsp+0xE0], xmm14
00007dd8609e2d31  sub rsp, 0x30
00007dd8609e2d35  movaps [rsp], xmm15
00007dd8609e2d3a  movaps [rsp+0x10], xmm1
00007dd8609e2d3f  movaps [rsp+0x20], xmm5
00007dd8609e2d44  lea rdi, [rsp]
00007dd8609e2d48  mov esi, 0x00
00007dd8609e2d4d  mov rax, 0x629C9CFA9530
00007dd8609e2d57  call rax
00007dd8609e2d59  movaps xmm15, [rsp]
00007dd8609e2d5e  add rsp, 0x30
00007dd8609e2d62  vmovaps xmm0, [rsp]
00007dd8609e2d67  vmovaps xmm1, [rsp+0x10]
00007dd8609e2d6d  vmovaps xmm2, [rsp+0x20]
00007dd8609e2d73  vmovaps xmm3, [rsp+0x30]
00007dd8609e2d79  vmovaps xmm4, [rsp+0x40]
00007dd8609e2d7f  vmovaps xmm5, [rsp+0x50]
00007dd8609e2d85  vmovaps xmm6, [rsp+0x60]
00007dd8609e2d8b  vmovaps xmm7, [rsp+0x70]
00007dd8609e2d91  vmovaps xmm8, [rsp+0x80]
00007dd8609e2d9a  vmovaps xmm9, [rsp+0x90]
00007dd8609e2da3  vmovaps xmm10, [rsp+0xA0]
00007dd8609e2dac  vmovaps xmm11, [rsp+0xB0]
00007dd8609e2db5  vmovaps xmm12, [rsp+0xC0]
00007dd8609e2dbe  vmovaps xmm13, [rsp+0xD0]
00007dd8609e2dc7  vmovaps xmm14, [rsp+0xE0]
00007dd8609e2dd0  add rsp, 0xF0
00007dd8609e2dd7  pop r11
00007dd8609e2dd9  pop r10
00007dd8609e2ddb  pop r9
00007dd8609e2ddd  pop r8
00007dd8609e2ddf  pop rsi
00007dd8609e2de0  pop rdi
00007dd8609e2de1  pop rdx
00007dd8609e2de2  pop rcx
00007dd8609e2de3  pop rax
00007dd8609e2de4  add rsp, 0x08
00007dd8609e2de8  jmp 0x00007DD8609DF653
00007dd8609e2ded  call 0x00007DD8608B52F0
00007dd8609e2df2  jmp 0x00007DD8609DF6AE
00007dd8609e2df7  sub rsp, 0x08
00007dd8609e2dfb  push rax
00007dd8609e2dfc  push rcx
00007dd8609e2dfd  push rdx
00007dd8609e2dfe  push rdi
00007dd8609e2dff  push rsi
00007dd8609e2e00  push r8
00007dd8609e2e02  push r9
00007dd8609e2e04  push r10
00007dd8609e2e06  push r11
00007dd8609e2e08  sub rsp, 0xF0
00007dd8609e2e0f  vmovaps [rsp], xmm0
00007dd8609e2e14  vmovaps [rsp+0x10], xmm1
00007dd8609e2e1a  vmovaps [rsp+0x20], xmm2
00007dd8609e2e20  vmovaps [rsp+0x30], xmm3
00007dd8609e2e26  vmovaps [rsp+0x40], xmm4
00007dd8609e2e2c  vmovaps [rsp+0x50], xmm5
00007dd8609e2e32  vmovaps [rsp+0x60], xmm6
00007dd8609e2e38  vmovaps [rsp+0x70], xmm7
00007dd8609e2e3e  vmovaps [rsp+0x80], xmm8
00007dd8609e2e47  vmovaps [rsp+0x90], xmm10
00007dd8609e2e50  vmovaps [rsp+0xA0], xmm11
00007dd8609e2e59  vmovaps [rsp+0xB0], xmm12
00007dd8609e2e62  vmovaps [rsp+0xC0], xmm13
00007dd8609e2e6b  vmovaps [rsp+0xD0], xmm14
00007dd8609e2e74  vmovaps [rsp+0xE0], xmm15
00007dd8609e2e7d  sub rsp, 0x30
00007dd8609e2e81  movaps [rsp], xmm9
00007dd8609e2e86  movaps [rsp+0x10], xmm8
00007dd8609e2e8c  movaps [rsp+0x20], xmm11
00007dd8609e2e92  lea rdi, [rsp]
00007dd8609e2e96  mov esi, 0x00
00007dd8609e2e9b  mov rax, 0x629C9CFA9530
00007dd8609e2ea5  call rax
00007dd8609e2ea7  movaps xmm9, [rsp]
00007dd8609e2eac  add rsp, 0x30
00007dd8609e2eb0  vmovaps xmm0, [rsp]
00007dd8609e2eb5  vmovaps xmm1, [rsp+0x10]
00007dd8609e2ebb  vmovaps xmm2, [rsp+0x20]
00007dd8609e2ec1  vmovaps xmm3, [rsp+0x30]
00007dd8609e2ec7  vmovaps xmm4, [rsp+0x40]
00007dd8609e2ecd  vmovaps xmm5, [rsp+0x50]
00007dd8609e2ed3  vmovaps xmm6, [rsp+0x60]
00007dd8609e2ed9  vmovaps xmm7, [rsp+0x70]
00007dd8609e2edf  vmovaps xmm8, [rsp+0x80]
00007dd8609e2ee8  vmovaps xmm10, [rsp+0x90]
00007dd8609e2ef1  vmovaps xmm11, [rsp+0xA0]
00007dd8609e2efa  vmovaps xmm12, [rsp+0xB0]
00007dd8609e2f03  vmovaps xmm13, [rsp+0xC0]
00007dd8609e2f0c  vmovaps xmm14, [rsp+0xD0]
00007dd8609e2f15  vmovaps xmm15, [rsp+0xE0]
00007dd8609e2f1e  add rsp, 0xF0
00007dd8609e2f25  pop r11
00007dd8609e2f27  pop r10
00007dd8609e2f29  pop r9
00007dd8609e2f2b  pop r8
00007dd8609e2f2d  pop rsi
00007dd8609e2f2e  pop rdi
00007dd8609e2f2f  pop rdx
00007dd8609e2f30  pop rcx
00007dd8609e2f31  pop rax
00007dd8609e2f32  add rsp, 0x08
00007dd8609e2f36  jmp 0x00007DD8609DF6E5
00007dd8609e2f3b  sub rsp, 0x08
00007dd8609e2f3f  push rax
00007dd8609e2f40  push rcx
00007dd8609e2f41  push rdx
00007dd8609e2f42  push rdi
00007dd8609e2f43  push rsi
00007dd8609e2f44  push r8
00007dd8609e2f46  push r9
00007dd8609e2f48  push r10
00007dd8609e2f4a  push r11
00007dd8609e2f4c  sub rsp, 0xF0
00007dd8609e2f53  vmovaps [rsp], xmm0
00007dd8609e2f58  vmovaps [rsp+0x10], xmm1
00007dd8609e2f5e  vmovaps [rsp+0x20], xmm2
00007dd8609e2f64  vmovaps [rsp+0x30], xmm3
00007dd8609e2f6a  vmovaps [rsp+0x40], xmm4
00007dd8609e2f70  vmovaps [rsp+0x50], xmm5
00007dd8609e2f76  vmovaps [rsp+0x60], xmm6
00007dd8609e2f7c  vmovaps [rsp+0x70], xmm7
00007dd8609e2f82  vmovaps [rsp+0x80], xmm8
00007dd8609e2f8b  vmovaps [rsp+0x90], xmm9
00007dd8609e2f94  vmovaps [rsp+0xA0], xmm10
00007dd8609e2f9d  vmovaps [rsp+0xB0], xmm12
00007dd8609e2fa6  vmovaps [rsp+0xC0], xmm13
00007dd8609e2faf  vmovaps [rsp+0xD0], xmm14
00007dd8609e2fb8  vmovaps [rsp+0xE0], xmm15
00007dd8609e2fc1  sub rsp, 0x30
00007dd8609e2fc5  movaps [rsp], xmm11
00007dd8609e2fca  movaps [rsp+0x10], xmm10
00007dd8609e2fd0  movaps [rsp+0x20], xmm6
00007dd8609e2fd5  lea rdi, [rsp]
00007dd8609e2fd9  mov esi, 0x00
00007dd8609e2fde  mov rax, 0x629C9CFA9530
00007dd8609e2fe8  call rax
00007dd8609e2fea  movaps xmm11, [rsp]
00007dd8609e2fef  add rsp, 0x30
00007dd8609e2ff3  vmovaps xmm0, [rsp]
00007dd8609e2ff8  vmovaps xmm1, [rsp+0x10]
00007dd8609e2ffe  vmovaps xmm2, [rsp+0x20]
00007dd8609e3004  vmovaps xmm3, [rsp+0x30]
00007dd8609e300a  vmovaps xmm4, [rsp+0x40]
00007dd8609e3010  vmovaps xmm5, [rsp+0x50]
00007dd8609e3016  vmovaps xmm6, [rsp+0x60]
00007dd8609e301c  vmovaps xmm7, [rsp+0x70]
00007dd8609e3022  vmovaps xmm8, [rsp+0x80]
00007dd8609e302b  vmovaps xmm9, [rsp+0x90]
00007dd8609e3034  vmovaps xmm10, [rsp+0xA0]
00007dd8609e303d  vmovaps xmm12, [rsp+0xB0]
00007dd8609e3046  vmovaps xmm13, [rsp+0xC0]
00007dd8609e304f  vmovaps xmm14, [rsp+0xD0]
00007dd8609e3058  vmovaps xmm15, [rsp+0xE0]
00007dd8609e3061  add rsp, 0xF0
00007dd8609e3068  pop r11
00007dd8609e306a  pop r10
00007dd8609e306c  pop r9
00007dd8609e306e  pop r8
00007dd8609e3070  pop rsi
00007dd8609e3071  pop rdi
00007dd8609e3072  pop rdx
00007dd8609e3073  pop rcx
00007dd8609e3074  pop rax
00007dd8609e3075  add rsp, 0x08
00007dd8609e3079  jmp 0x00007DD8609DF700
00007dd8609e307e  sub rsp, 0x08
00007dd8609e3082  push rax
00007dd8609e3083  push rcx
00007dd8609e3084  push rdx
00007dd8609e3085  push rdi
00007dd8609e3086  push rsi
00007dd8609e3087  push r8
00007dd8609e3089  push r9
00007dd8609e308b  push r10
00007dd8609e308d  push r11
00007dd8609e308f  sub rsp, 0xF0
00007dd8609e3096  vmovaps [rsp], xmm0
00007dd8609e309b  vmovaps [rsp+0x10], xmm1
00007dd8609e30a1  vmovaps [rsp+0x20], xmm2
00007dd8609e30a7  vmovaps [rsp+0x30], xmm3
00007dd8609e30ad  vmovaps [rsp+0x40], xmm4
00007dd8609e30b3  vmovaps [rsp+0x50], xmm5
00007dd8609e30b9  vmovaps [rsp+0x60], xmm6
00007dd8609e30bf  vmovaps [rsp+0x70], xmm7
00007dd8609e30c5  vmovaps [rsp+0x80], xmm8
00007dd8609e30ce  vmovaps [rsp+0x90], xmm9
00007dd8609e30d7  vmovaps [rsp+0xA0], xmm11
00007dd8609e30e0  vmovaps [rsp+0xB0], xmm12
00007dd8609e30e9  vmovaps [rsp+0xC0], xmm13
00007dd8609e30f2  vmovaps [rsp+0xD0], xmm14
00007dd8609e30fb  vmovaps [rsp+0xE0], xmm15
00007dd8609e3104  sub rsp, 0x30
00007dd8609e3108  movaps [rsp], xmm10
00007dd8609e310d  movaps [rsp+0x10], xmm14
00007dd8609e3113  movaps [rsp+0x20], xmm4
00007dd8609e3118  lea rdi, [rsp]
00007dd8609e311c  mov esi, 0x00
00007dd8609e3121  mov rax, 0x629C9CFA9530
00007dd8609e312b  call rax
00007dd8609e312d  movaps xmm10, [rsp]
00007dd8609e3132  add rsp, 0x30
00007dd8609e3136  vmovaps xmm0, [rsp]
00007dd8609e313b  vmovaps xmm1, [rsp+0x10]
00007dd8609e3141  vmovaps xmm2, [rsp+0x20]
00007dd8609e3147  vmovaps xmm3, [rsp+0x30]
00007dd8609e314d  vmovaps xmm4, [rsp+0x40]
00007dd8609e3153  vmovaps xmm5, [rsp+0x50]
00007dd8609e3159  vmovaps xmm6, [rsp+0x60]
00007dd8609e315f  vmovaps xmm7, [rsp+0x70]
00007dd8609e3165  vmovaps xmm8, [rsp+0x80]
00007dd8609e316e  vmovaps xmm9, [rsp+0x90]
00007dd8609e3177  vmovaps xmm11, [rsp+0xA0]
00007dd8609e3180  vmovaps xmm12, [rsp+0xB0]
00007dd8609e3189  vmovaps xmm13, [rsp+0xC0]
00007dd8609e3192  vmovaps xmm14, [rsp+0xD0]
00007dd8609e319b  vmovaps xmm15, [rsp+0xE0]
00007dd8609e31a4  add rsp, 0xF0
00007dd8609e31ab  pop r11
00007dd8609e31ad  pop r10
00007dd8609e31af  pop r9
00007dd8609e31b1  pop r8
00007dd8609e31b3  pop rsi
00007dd8609e31b4  pop rdi
00007dd8609e31b5  pop rdx
00007dd8609e31b6  pop rcx
00007dd8609e31b7  pop rax
00007dd8609e31b8  add rsp, 0x08
00007dd8609e31bc  jmp 0x00007DD8609DF71B
00007dd8609e31c1  sub rsp, 0x08
00007dd8609e31c5  push rax
00007dd8609e31c6  push rcx
00007dd8609e31c7  push rdx
00007dd8609e31c8  push rdi
00007dd8609e31c9  push rsi
00007dd8609e31ca  push r8
00007dd8609e31cc  push r9
00007dd8609e31ce  push r10
00007dd8609e31d0  push r11
00007dd8609e31d2  sub rsp, 0xF0
00007dd8609e31d9  vmovaps [rsp], xmm0
00007dd8609e31de  vmovaps [rsp+0x10], xmm1
00007dd8609e31e4  vmovaps [rsp+0x20], xmm2
00007dd8609e31ea  vmovaps [rsp+0x30], xmm3
00007dd8609e31f0  vmovaps [rsp+0x40], xmm4
00007dd8609e31f6  vmovaps [rsp+0x50], xmm5
00007dd8609e31fc  vmovaps [rsp+0x60], xmm6
00007dd8609e3202  vmovaps [rsp+0x70], xmm7
00007dd8609e3208  vmovaps [rsp+0x80], xmm9
00007dd8609e3211  vmovaps [rsp+0x90], xmm10
00007dd8609e321a  vmovaps [rsp+0xA0], xmm11
00007dd8609e3223  vmovaps [rsp+0xB0], xmm12
00007dd8609e322c  vmovaps [rsp+0xC0], xmm13
00007dd8609e3235  vmovaps [rsp+0xD0], xmm14
00007dd8609e323e  vmovaps [rsp+0xE0], xmm15
00007dd8609e3247  sub rsp, 0x30
00007dd8609e324b  movaps [rsp], xmm8
00007dd8609e3250  movaps [rsp+0x10], xmm1
00007dd8609e3255  movaps [rsp+0x20], xmm14
00007dd8609e325b  lea rdi, [rsp]
00007dd8609e325f  mov esi, 0x00
00007dd8609e3264  mov rax, 0x629C9CFA9530
00007dd8609e326e  call rax
00007dd8609e3270  movaps xmm8, [rsp]
00007dd8609e3275  add rsp, 0x30
00007dd8609e3279  vmovaps xmm0, [rsp]
00007dd8609e327e  vmovaps xmm1, [rsp+0x10]
00007dd8609e3284  vmovaps xmm2, [rsp+0x20]
00007dd8609e328a  vmovaps xmm3, [rsp+0x30]
00007dd8609e3290  vmovaps xmm4, [rsp+0x40]
00007dd8609e3296  vmovaps xmm5, [rsp+0x50]
00007dd8609e329c  vmovaps xmm6, [rsp+0x60]
00007dd8609e32a2  vmovaps xmm7, [rsp+0x70]
00007dd8609e32a8  vmovaps xmm9, [rsp+0x80]
00007dd8609e32b1  vmovaps xmm10, [rsp+0x90]
00007dd8609e32ba  vmovaps xmm11, [rsp+0xA0]
00007dd8609e32c3  vmovaps xmm12, [rsp+0xB0]
00007dd8609e32cc  vmovaps xmm13, [rsp+0xC0]
00007dd8609e32d5  vmovaps xmm14, [rsp+0xD0]
00007dd8609e32de  vmovaps xmm15, [rsp+0xE0]
00007dd8609e32e7  add rsp, 0xF0
00007dd8609e32ee  pop r11
00007dd8609e32f0  pop r10
00007dd8609e32f2  pop r9
00007dd8609e32f4  pop r8
00007dd8609e32f6  pop rsi
00007dd8609e32f7  pop rdi
00007dd8609e32f8  pop rdx
00007dd8609e32f9  pop rcx
00007dd8609e32fa  pop rax
00007dd8609e32fb  add rsp, 0x08
00007dd8609e32ff  jmp 0x00007DD8609DF741
00007dd8609e3304  sub rsp, 0x08
00007dd8609e3308  push rax
00007dd8609e3309  push rcx
00007dd8609e330a  push rdx
00007dd8609e330b  push rdi
00007dd8609e330c  push rsi
00007dd8609e330d  push r8
00007dd8609e330f  push r9
00007dd8609e3311  push r10
00007dd8609e3313  push r11
00007dd8609e3315  sub rsp, 0xF0
00007dd8609e331c  vmovaps [rsp], xmm0
00007dd8609e3321  vmovaps [rsp+0x10], xmm1
00007dd8609e3327  vmovaps [rsp+0x20], xmm2
00007dd8609e332d  vmovaps [rsp+0x30], xmm3
00007dd8609e3333  vmovaps [rsp+0x40], xmm4
00007dd8609e3339  vmovaps [rsp+0x50], xmm5
00007dd8609e333f  vmovaps [rsp+0x60], xmm7
00007dd8609e3345  vmovaps [rsp+0x70], xmm8
00007dd8609e334b  vmovaps [rsp+0x80], xmm9
00007dd8609e3354  vmovaps [rsp+0x90], xmm10
00007dd8609e335d  vmovaps [rsp+0xA0], xmm11
00007dd8609e3366  vmovaps [rsp+0xB0], xmm12
00007dd8609e336f  vmovaps [rsp+0xC0], xmm13
00007dd8609e3378  vmovaps [rsp+0xD0], xmm14
00007dd8609e3381  vmovaps [rsp+0xE0], xmm15
00007dd8609e338a  sub rsp, 0x30
00007dd8609e338e  movaps [rsp], xmm6
00007dd8609e3392  movaps [rsp+0x10], xmm1
00007dd8609e3397  movaps [rsp+0x20], xmm14
00007dd8609e339d  lea rdi, [rsp]
00007dd8609e33a1  mov esi, 0x00
00007dd8609e33a6  mov rax, 0x629C9CFA9530
00007dd8609e33b0  call rax
00007dd8609e33b2  movaps xmm6, [rsp]
00007dd8609e33b6  add rsp, 0x30
00007dd8609e33ba  vmovaps xmm0, [rsp]
00007dd8609e33bf  vmovaps xmm1, [rsp+0x10]
00007dd8609e33c5  vmovaps xmm2, [rsp+0x20]
00007dd8609e33cb  vmovaps xmm3, [rsp+0x30]
00007dd8609e33d1  vmovaps xmm4, [rsp+0x40]
00007dd8609e33d7  vmovaps xmm5, [rsp+0x50]
00007dd8609e33dd  vmovaps xmm7, [rsp+0x60]
00007dd8609e33e3  vmovaps xmm8, [rsp+0x70]
00007dd8609e33e9  vmovaps xmm9, [rsp+0x80]
00007dd8609e33f2  vmovaps xmm10, [rsp+0x90]
00007dd8609e33fb  vmovaps xmm11, [rsp+0xA0]
00007dd8609e3404  vmovaps xmm12, [rsp+0xB0]
00007dd8609e340d  vmovaps xmm13, [rsp+0xC0]
00007dd8609e3416  vmovaps xmm14, [rsp+0xD0]
00007dd8609e341f  vmovaps xmm15, [rsp+0xE0]
00007dd8609e3428  add rsp, 0xF0
00007dd8609e342f  pop r11
00007dd8609e3431  pop r10
00007dd8609e3433  pop r9
00007dd8609e3435  pop r8
00007dd8609e3437  pop rsi
00007dd8609e3438  pop rdi
00007dd8609e3439  pop rdx
00007dd8609e343a  pop rcx
00007dd8609e343b  pop rax
00007dd8609e343c  add rsp, 0x08
00007dd8609e3440  jmp 0x00007DD8609DF76D
00007dd8609e3445  sub rsp, 0x08
00007dd8609e3449  push rax
00007dd8609e344a  push rcx
00007dd8609e344b  push rdx
00007dd8609e344c  push rdi
00007dd8609e344d  push rsi
00007dd8609e344e  push r8
00007dd8609e3450  push r9
00007dd8609e3452  push r10
00007dd8609e3454  push r11
00007dd8609e3456  sub rsp, 0xF0
00007dd8609e345d  vmovaps [rsp], xmm0
00007dd8609e3462  vmovaps [rsp+0x10], xmm1
00007dd8609e3468  vmovaps [rsp+0x20], xmm2
00007dd8609e346e  vmovaps [rsp+0x30], xmm3
00007dd8609e3474  vmovaps [rsp+0x40], xmm4
00007dd8609e347a  vmovaps [rsp+0x50], xmm5
00007dd8609e3480  vmovaps [rsp+0x60], xmm6
00007dd8609e3486  vmovaps [rsp+0x70], xmm7
00007dd8609e348c  vmovaps [rsp+0x80], xmm8
00007dd8609e3495  vmovaps [rsp+0x90], xmm9
00007dd8609e349e  vmovaps [rsp+0xA0], xmm10
00007dd8609e34a7  vmovaps [rsp+0xB0], xmm11
00007dd8609e34b0  vmovaps [rsp+0xC0], xmm12
00007dd8609e34b9  vmovaps [rsp+0xD0], xmm13
00007dd8609e34c2  vmovaps [rsp+0xE0], xmm15
00007dd8609e34cb  sub rsp, 0x30
00007dd8609e34cf  movaps [rsp], xmm14
00007dd8609e34d4  movaps [rsp+0x10], xmm12
00007dd8609e34da  movaps [rsp+0x20], xmm1
00007dd8609e34df  lea rdi, [rsp]
00007dd8609e34e3  mov esi, 0x00
00007dd8609e34e8  mov rax, 0x629C9CFA9530
00007dd8609e34f2  call rax
00007dd8609e34f4  movaps xmm14, [rsp]
00007dd8609e34f9  add rsp, 0x30
00007dd8609e34fd  vmovaps xmm0, [rsp]
00007dd8609e3502  vmovaps xmm1, [rsp+0x10]
00007dd8609e3508  vmovaps xmm2, [rsp+0x20]
00007dd8609e350e  vmovaps xmm3, [rsp+0x30]
00007dd8609e3514  vmovaps xmm4, [rsp+0x40]
00007dd8609e351a  vmovaps xmm5, [rsp+0x50]
00007dd8609e3520  vmovaps xmm6, [rsp+0x60]
00007dd8609e3526  vmovaps xmm7, [rsp+0x70]
00007dd8609e352c  vmovaps xmm8, [rsp+0x80]
00007dd8609e3535  vmovaps xmm9, [rsp+0x90]
00007dd8609e353e  vmovaps xmm10, [rsp+0xA0]
00007dd8609e3547  vmovaps xmm11, [rsp+0xB0]
00007dd8609e3550  vmovaps xmm12, [rsp+0xC0]
00007dd8609e3559  vmovaps xmm13, [rsp+0xD0]
00007dd8609e3562  vmovaps xmm15, [rsp+0xE0]
00007dd8609e356b  add rsp, 0xF0
00007dd8609e3572  pop r11
00007dd8609e3574  pop r10
00007dd8609e3576  pop r9
00007dd8609e3578  pop r8
00007dd8609e357a  pop rsi
00007dd8609e357b  pop rdi
00007dd8609e357c  pop rdx
00007dd8609e357d  pop rcx
00007dd8609e357e  pop rax
00007dd8609e357f  add rsp, 0x08
00007dd8609e3583  jmp 0x00007DD8609DF793
00007dd8609e3588  sub rsp, 0x08
00007dd8609e358c  push rax
00007dd8609e358d  push rcx
00007dd8609e358e  push rdx
00007dd8609e358f  push rdi
00007dd8609e3590  push rsi
00007dd8609e3591  push r8
00007dd8609e3593  push r9
00007dd8609e3595  push r10
00007dd8609e3597  push r11
00007dd8609e3599  sub rsp, 0xF0
00007dd8609e35a0  vmovaps [rsp], xmm0
00007dd8609e35a5  vmovaps [rsp+0x10], xmm2
00007dd8609e35ab  vmovaps [rsp+0x20], xmm3
00007dd8609e35b1  vmovaps [rsp+0x30], xmm4
00007dd8609e35b7  vmovaps [rsp+0x40], xmm5
00007dd8609e35bd  vmovaps [rsp+0x50], xmm6
00007dd8609e35c3  vmovaps [rsp+0x60], xmm7
00007dd8609e35c9  vmovaps [rsp+0x70], xmm8
00007dd8609e35cf  vmovaps [rsp+0x80], xmm9
00007dd8609e35d8  vmovaps [rsp+0x90], xmm10
00007dd8609e35e1  vmovaps [rsp+0xA0], xmm11
00007dd8609e35ea  vmovaps [rsp+0xB0], xmm12
00007dd8609e35f3  vmovaps [rsp+0xC0], xmm13
00007dd8609e35fc  vmovaps [rsp+0xD0], xmm14
00007dd8609e3605  vmovaps [rsp+0xE0], xmm15
00007dd8609e360e  sub rsp, 0x30
00007dd8609e3612  movaps [rsp], xmm1
00007dd8609e3616  movaps [rsp+0x10], xmm13
00007dd8609e361c  movaps [rsp+0x20], xmm9
00007dd8609e3622  lea rdi, [rsp]
00007dd8609e3626  mov esi, 0x00
00007dd8609e362b  mov rax, 0x629C9CFA9530
00007dd8609e3635  call rax
00007dd8609e3637  movaps xmm1, [rsp]
00007dd8609e363b  add rsp, 0x30
00007dd8609e363f  vmovaps xmm0, [rsp]
00007dd8609e3644  vmovaps xmm2, [rsp+0x10]
00007dd8609e364a  vmovaps xmm3, [rsp+0x20]
00007dd8609e3650  vmovaps xmm4, [rsp+0x30]
00007dd8609e3656  vmovaps xmm5, [rsp+0x40]
00007dd8609e365c  vmovaps xmm6, [rsp+0x50]
00007dd8609e3662  vmovaps xmm7, [rsp+0x60]
00007dd8609e3668  vmovaps xmm8, [rsp+0x70]
00007dd8609e366e  vmovaps xmm9, [rsp+0x80]
00007dd8609e3677  vmovaps xmm10, [rsp+0x90]
00007dd8609e3680  vmovaps xmm11, [rsp+0xA0]
00007dd8609e3689  vmovaps xmm12, [rsp+0xB0]
00007dd8609e3692  vmovaps xmm13, [rsp+0xC0]
00007dd8609e369b  vmovaps xmm14, [rsp+0xD0]
00007dd8609e36a4  vmovaps xmm15, [rsp+0xE0]
00007dd8609e36ad  add rsp, 0xF0
00007dd8609e36b4  pop r11
00007dd8609e36b6  pop r10
00007dd8609e36b8  pop r9
00007dd8609e36ba  pop r8
00007dd8609e36bc  pop rsi
00007dd8609e36bd  pop rdi
00007dd8609e36be  pop rdx
00007dd8609e36bf  pop rcx
00007dd8609e36c0  pop rax
00007dd8609e36c1  add rsp, 0x08
00007dd8609e36c5  jmp 0x00007DD8609DF7AD
00007dd8609e36ca  sub rsp, 0x08
00007dd8609e36ce  push rax
00007dd8609e36cf  push rcx
00007dd8609e36d0  push rdx
00007dd8609e36d1  push rdi
00007dd8609e36d2  push rsi
00007dd8609e36d3  push r8
00007dd8609e36d5  push r9
00007dd8609e36d7  push r10
00007dd8609e36d9  push r11
00007dd8609e36db  sub rsp, 0xF0
00007dd8609e36e2  vmovaps [rsp], xmm0
00007dd8609e36e7  vmovaps [rsp+0x10], xmm1
00007dd8609e36ed  vmovaps [rsp+0x20], xmm2
00007dd8609e36f3  vmovaps [rsp+0x30], xmm3
00007dd8609e36f9  vmovaps [rsp+0x40], xmm4
00007dd8609e36ff  vmovaps [rsp+0x50], xmm5
00007dd8609e3705  vmovaps [rsp+0x60], xmm6
00007dd8609e370b  vmovaps [rsp+0x70], xmm7
00007dd8609e3711  vmovaps [rsp+0x80], xmm8
00007dd8609e371a  vmovaps [rsp+0x90], xmm9
00007dd8609e3723  vmovaps [rsp+0xA0], xmm10
00007dd8609e372c  vmovaps [rsp+0xB0], xmm11
00007dd8609e3735  vmovaps [rsp+0xC0], xmm13
00007dd8609e373e  vmovaps [rsp+0xD0], xmm14
00007dd8609e3747  vmovaps [rsp+0xE0], xmm15
00007dd8609e3750  sub rsp, 0x30
00007dd8609e3754  movaps [rsp], xmm12
00007dd8609e3759  movaps [rsp+0x10], xmm7
00007dd8609e375e  movaps [rsp+0x20], xmm13
00007dd8609e3764  lea rdi, [rsp]
00007dd8609e3768  mov esi, 0x00
00007dd8609e376d  mov rax, 0x629C9CFA9530
00007dd8609e3777  call rax
00007dd8609e3779  movaps xmm12, [rsp]
00007dd8609e377e  add rsp, 0x30
00007dd8609e3782  vmovaps xmm0, [rsp]
00007dd8609e3787  vmovaps xmm1, [rsp+0x10]
00007dd8609e378d  vmovaps xmm2, [rsp+0x20]
00007dd8609e3793  vmovaps xmm3, [rsp+0x30]
00007dd8609e3799  vmovaps xmm4, [rsp+0x40]
00007dd8609e379f  vmovaps xmm5, [rsp+0x50]
00007dd8609e37a5  vmovaps xmm6, [rsp+0x60]
00007dd8609e37ab  vmovaps xmm7, [rsp+0x70]
00007dd8609e37b1  vmovaps xmm8, [rsp+0x80]
00007dd8609e37ba  vmovaps xmm9, [rsp+0x90]
00007dd8609e37c3  vmovaps xmm10, [rsp+0xA0]
00007dd8609e37cc  vmovaps xmm11, [rsp+0xB0]
00007dd8609e37d5  vmovaps xmm13, [rsp+0xC0]
00007dd8609e37de  vmovaps xmm14, [rsp+0xD0]
00007dd8609e37e7  vmovaps xmm15, [rsp+0xE0]
00007dd8609e37f0  add rsp, 0xF0
00007dd8609e37f7  pop r11
00007dd8609e37f9  pop r10
00007dd8609e37fb  pop r9
00007dd8609e37fd  pop r8
00007dd8609e37ff  pop rsi
00007dd8609e3800  pop rdi
00007dd8609e3801  pop rdx
00007dd8609e3802  pop rcx
00007dd8609e3803  pop rax
00007dd8609e3804  add rsp, 0x08
00007dd8609e3808  jmp 0x00007DD8609DF7D4
00007dd8609e380d  sub rsp, 0x08
00007dd8609e3811  push rax
00007dd8609e3812  push rcx
00007dd8609e3813  push rdx
00007dd8609e3814  push rdi
00007dd8609e3815  push rsi
00007dd8609e3816  push r8
00007dd8609e3818  push r9
00007dd8609e381a  push r10
00007dd8609e381c  push r11
00007dd8609e381e  sub rsp, 0xF0
00007dd8609e3825  vmovaps [rsp], xmm0
00007dd8609e382a  vmovaps [rsp+0x10], xmm1
00007dd8609e3830  vmovaps [rsp+0x20], xmm2
00007dd8609e3836  vmovaps [rsp+0x30], xmm3
00007dd8609e383c  vmovaps [rsp+0x40], xmm4
00007dd8609e3842  vmovaps [rsp+0x50], xmm5
00007dd8609e3848  vmovaps [rsp+0x60], xmm6
00007dd8609e384e  vmovaps [rsp+0x70], xmm7
00007dd8609e3854  vmovaps [rsp+0x80], xmm8
00007dd8609e385d  vmovaps [rsp+0x90], xmm9
00007dd8609e3866  vmovaps [rsp+0xA0], xmm10
00007dd8609e386f  vmovaps [rsp+0xB0], xmm11
00007dd8609e3878  vmovaps [rsp+0xC0], xmm12
00007dd8609e3881  vmovaps [rsp+0xD0], xmm14
00007dd8609e388a  vmovaps [rsp+0xE0], xmm15
00007dd8609e3893  sub rsp, 0x30
00007dd8609e3897  movaps [rsp], xmm13
00007dd8609e389c  movaps [rsp+0x10], xmm15
00007dd8609e38a2  movaps [rsp+0x20], xmm8
00007dd8609e38a8  lea rdi, [rsp]
00007dd8609e38ac  mov esi, 0x00
00007dd8609e38b1  mov rax, 0x629C9CFA9530
00007dd8609e38bb  call rax
00007dd8609e38bd  movaps xmm13, [rsp]
00007dd8609e38c2  add rsp, 0x30
00007dd8609e38c6  vmovaps xmm0, [rsp]
00007dd8609e38cb  vmovaps xmm1, [rsp+0x10]
00007dd8609e38d1  vmovaps xmm2, [rsp+0x20]
00007dd8609e38d7  vmovaps xmm3, [rsp+0x30]
00007dd8609e38dd  vmovaps xmm4, [rsp+0x40]
00007dd8609e38e3  vmovaps xmm5, [rsp+0x50]
00007dd8609e38e9  vmovaps xmm6, [rsp+0x60]
00007dd8609e38ef  vmovaps xmm7, [rsp+0x70]
00007dd8609e38f5  vmovaps xmm8, [rsp+0x80]
00007dd8609e38fe  vmovaps xmm9, [rsp+0x90]
00007dd8609e3907  vmovaps xmm10, [rsp+0xA0]
00007dd8609e3910  vmovaps xmm11, [rsp+0xB0]
00007dd8609e3919  vmovaps xmm12, [rsp+0xC0]
00007dd8609e3922  vmovaps xmm14, [rsp+0xD0]
00007dd8609e392b  vmovaps xmm15, [rsp+0xE0]
00007dd8609e3934  add rsp, 0xF0
00007dd8609e393b  pop r11
00007dd8609e393d  pop r10
00007dd8609e393f  pop r9
00007dd8609e3941  pop r8
00007dd8609e3943  pop rsi
00007dd8609e3944  pop rdi
00007dd8609e3945  pop rdx
00007dd8609e3946  pop rcx
00007dd8609e3947  pop rax
00007dd8609e3948  add rsp, 0x08
00007dd8609e394c  jmp 0x00007DD8609DF7EF
00007dd8609e3951  sub rsp, 0x08
00007dd8609e3955  push rax
00007dd8609e3956  push rcx
00007dd8609e3957  push rdx
00007dd8609e3958  push rdi
00007dd8609e3959  push rsi
00007dd8609e395a  push r8
00007dd8609e395c  push r9
00007dd8609e395e  push r10
00007dd8609e3960  push r11
00007dd8609e3962  sub rsp, 0xF0
00007dd8609e3969  vmovaps [rsp], xmm0
00007dd8609e396e  vmovaps [rsp+0x10], xmm1
00007dd8609e3974  vmovaps [rsp+0x20], xmm2
00007dd8609e397a  vmovaps [rsp+0x30], xmm3
00007dd8609e3980  vmovaps [rsp+0x40], xmm4
00007dd8609e3986  vmovaps [rsp+0x50], xmm5
00007dd8609e398c  vmovaps [rsp+0x60], xmm6
00007dd8609e3992  vmovaps [rsp+0x70], xmm7
00007dd8609e3998  vmovaps [rsp+0x80], xmm9
00007dd8609e39a1  vmovaps [rsp+0x90], xmm10
00007dd8609e39aa  vmovaps [rsp+0xA0], xmm11
00007dd8609e39b3  vmovaps [rsp+0xB0], xmm12
00007dd8609e39bc  vmovaps [rsp+0xC0], xmm13
00007dd8609e39c5  vmovaps [rsp+0xD0], xmm14
00007dd8609e39ce  vmovaps [rsp+0xE0], xmm15
00007dd8609e39d7  sub rsp, 0x30
00007dd8609e39db  movaps [rsp], xmm8
00007dd8609e39e0  movaps [rsp+0x10], xmm15
00007dd8609e39e6  movaps [rsp+0x20], xmm9
00007dd8609e39ec  lea rdi, [rsp]
00007dd8609e39f0  mov esi, 0x00
00007dd8609e39f5  mov rax, 0x629C9CFA9530
00007dd8609e39ff  call rax
00007dd8609e3a01  movaps xmm8, [rsp]
00007dd8609e3a06  add rsp, 0x30
00007dd8609e3a0a  vmovaps xmm0, [rsp]
00007dd8609e3a0f  vmovaps xmm1, [rsp+0x10]
00007dd8609e3a15  vmovaps xmm2, [rsp+0x20]
00007dd8609e3a1b  vmovaps xmm3, [rsp+0x30]
00007dd8609e3a21  vmovaps xmm4, [rsp+0x40]
00007dd8609e3a27  vmovaps xmm5, [rsp+0x50]
00007dd8609e3a2d  vmovaps xmm6, [rsp+0x60]
00007dd8609e3a33  vmovaps xmm7, [rsp+0x70]
00007dd8609e3a39  vmovaps xmm9, [rsp+0x80]
00007dd8609e3a42  vmovaps xmm10, [rsp+0x90]
00007dd8609e3a4b  vmovaps xmm11, [rsp+0xA0]
00007dd8609e3a54  vmovaps xmm12, [rsp+0xB0]
00007dd8609e3a5d  vmovaps xmm13, [rsp+0xC0]
00007dd8609e3a66  vmovaps xmm14, [rsp+0xD0]
00007dd8609e3a6f  vmovaps xmm15, [rsp+0xE0]
00007dd8609e3a78  add rsp, 0xF0
00007dd8609e3a7f  pop r11
00007dd8609e3a81  pop r10
00007dd8609e3a83  pop r9
00007dd8609e3a85  pop r8
00007dd8609e3a87  pop rsi
00007dd8609e3a88  pop rdi
00007dd8609e3a89  pop rdx
00007dd8609e3a8a  pop rcx
00007dd8609e3a8b  pop rax
00007dd8609e3a8c  add rsp, 0x08
00007dd8609e3a90  jmp 0x00007DD8609DF81D
00007dd8609e3a95  sub rsp, 0x08
00007dd8609e3a99  push rax
00007dd8609e3a9a  push rcx
00007dd8609e3a9b  push rdx
00007dd8609e3a9c  push rdi
00007dd8609e3a9d  push rsi
00007dd8609e3a9e  push r8
00007dd8609e3aa0  push r9
00007dd8609e3aa2  push r10
00007dd8609e3aa4  push r11
00007dd8609e3aa6  sub rsp, 0xF0
00007dd8609e3aad  vmovaps [rsp], xmm0
00007dd8609e3ab2  vmovaps [rsp+0x10], xmm1
00007dd8609e3ab8  vmovaps [rsp+0x20], xmm2
00007dd8609e3abe  vmovaps [rsp+0x30], xmm3
00007dd8609e3ac4  vmovaps [rsp+0x40], xmm4
00007dd8609e3aca  vmovaps [rsp+0x50], xmm5
00007dd8609e3ad0  vmovaps [rsp+0x60], xmm6
00007dd8609e3ad6  vmovaps [rsp+0x70], xmm7
00007dd8609e3adc  vmovaps [rsp+0x80], xmm8
00007dd8609e3ae5  vmovaps [rsp+0x90], xmm9
00007dd8609e3aee  vmovaps [rsp+0xA0], xmm10
00007dd8609e3af7  vmovaps [rsp+0xB0], xmm11
00007dd8609e3b00  vmovaps [rsp+0xC0], xmm12
00007dd8609e3b09  vmovaps [rsp+0xD0], xmm13
00007dd8609e3b12  vmovaps [rsp+0xE0], xmm14
00007dd8609e3b1b  sub rsp, 0x30
00007dd8609e3b1f  movaps [rsp], xmm15
00007dd8609e3b24  movaps [rsp+0x10], xmm11
00007dd8609e3b2a  movaps [rsp+0x20], xmm6
00007dd8609e3b2f  lea rdi, [rsp]
00007dd8609e3b33  mov esi, 0x00
00007dd8609e3b38  mov rax, 0x629C9CFA9530
00007dd8609e3b42  call rax
00007dd8609e3b44  movaps xmm15, [rsp]
00007dd8609e3b49  add rsp, 0x30
00007dd8609e3b4d  vmovaps xmm0, [rsp]
00007dd8609e3b52  vmovaps xmm1, [rsp+0x10]
00007dd8609e3b58  vmovaps xmm2, [rsp+0x20]
00007dd8609e3b5e  vmovaps xmm3, [rsp+0x30]
00007dd8609e3b64  vmovaps xmm4, [rsp+0x40]
00007dd8609e3b6a  vmovaps xmm5, [rsp+0x50]
00007dd8609e3b70  vmovaps xmm6, [rsp+0x60]
00007dd8609e3b76  vmovaps xmm7, [rsp+0x70]
00007dd8609e3b7c  vmovaps xmm8, [rsp+0x80]
00007dd8609e3b85  vmovaps xmm9, [rsp+0x90]
00007dd8609e3b8e  vmovaps xmm10, [rsp+0xA0]
00007dd8609e3b97  vmovaps xmm11, [rsp+0xB0]
00007dd8609e3ba0  vmovaps xmm12, [rsp+0xC0]
00007dd8609e3ba9  vmovaps xmm13, [rsp+0xD0]
00007dd8609e3bb2  vmovaps xmm14, [rsp+0xE0]
00007dd8609e3bbb  add rsp, 0xF0
00007dd8609e3bc2  pop r11
00007dd8609e3bc4  pop r10
00007dd8609e3bc6  pop r9
00007dd8609e3bc8  pop r8
00007dd8609e3bca  pop rsi
00007dd8609e3bcb  pop rdi
00007dd8609e3bcc  pop rdx
00007dd8609e3bcd  pop rcx
00007dd8609e3bce  pop rax
00007dd8609e3bcf  add rsp, 0x08
00007dd8609e3bd3  jmp 0x00007DD8609DF838
00007dd8609e3bd8  sub rsp, 0x08
00007dd8609e3bdc  push rax
00007dd8609e3bdd  push rcx
00007dd8609e3bde  push rdx
00007dd8609e3bdf  push rdi
00007dd8609e3be0  push rsi
00007dd8609e3be1  push r8
00007dd8609e3be3  push r9
00007dd8609e3be5  push r10
00007dd8609e3be7  push r11
00007dd8609e3be9  sub rsp, 0xF0
00007dd8609e3bf0  vmovaps [rsp], xmm0
00007dd8609e3bf5  vmovaps [rsp+0x10], xmm1
00007dd8609e3bfb  vmovaps [rsp+0x20], xmm2
00007dd8609e3c01  vmovaps [rsp+0x30], xmm3
00007dd8609e3c07  vmovaps [rsp+0x40], xmm4
00007dd8609e3c0d  vmovaps [rsp+0x50], xmm5
00007dd8609e3c13  vmovaps [rsp+0x60], xmm6
00007dd8609e3c19  vmovaps [rsp+0x70], xmm8
00007dd8609e3c1f  vmovaps [rsp+0x80], xmm9
00007dd8609e3c28  vmovaps [rsp+0x90], xmm10
00007dd8609e3c31  vmovaps [rsp+0xA0], xmm11
00007dd8609e3c3a  vmovaps [rsp+0xB0], xmm12
00007dd8609e3c43  vmovaps [rsp+0xC0], xmm13
00007dd8609e3c4c  vmovaps [rsp+0xD0], xmm14
00007dd8609e3c55  vmovaps [rsp+0xE0], xmm15
00007dd8609e3c5e  sub rsp, 0x30
00007dd8609e3c62  movaps [rsp], xmm7
00007dd8609e3c66  movaps [rsp+0x10], xmm11
00007dd8609e3c6c  movaps [rsp+0x20], xmm9
00007dd8609e3c72  lea rdi, [rsp]
00007dd8609e3c76  mov esi, 0x00
00007dd8609e3c7b  mov rax, 0x629C9CFA9530
00007dd8609e3c85  call rax
00007dd8609e3c87  movaps xmm7, [rsp]
00007dd8609e3c8b  add rsp, 0x30
00007dd8609e3c8f  vmovaps xmm0, [rsp]
00007dd8609e3c94  vmovaps xmm1, [rsp+0x10]
00007dd8609e3c9a  vmovaps xmm2, [rsp+0x20]
00007dd8609e3ca0  vmovaps xmm3, [rsp+0x30]
00007dd8609e3ca6  vmovaps xmm4, [rsp+0x40]
00007dd8609e3cac  vmovaps xmm5, [rsp+0x50]
00007dd8609e3cb2  vmovaps xmm6, [rsp+0x60]
00007dd8609e3cb8  vmovaps xmm8, [rsp+0x70]
00007dd8609e3cbe  vmovaps xmm9, [rsp+0x80]
00007dd8609e3cc7  vmovaps xmm10, [rsp+0x90]
00007dd8609e3cd0  vmovaps xmm11, [rsp+0xA0]
00007dd8609e3cd9  vmovaps xmm12, [rsp+0xB0]
00007dd8609e3ce2  vmovaps xmm13, [rsp+0xC0]
00007dd8609e3ceb  vmovaps xmm14, [rsp+0xD0]
00007dd8609e3cf4  vmovaps xmm15, [rsp+0xE0]
00007dd8609e3cfd  add rsp, 0xF0
00007dd8609e3d04  pop r11
00007dd8609e3d06  pop r10
00007dd8609e3d08  pop r9
00007dd8609e3d0a  pop r8
00007dd8609e3d0c  pop rsi
00007dd8609e3d0d  pop rdi
00007dd8609e3d0e  pop rdx
00007dd8609e3d0f  pop rcx
00007dd8609e3d10  pop rax
00007dd8609e3d11  add rsp, 0x08
00007dd8609e3d15  jmp 0x00007DD8609DF865
00007dd8609e3d1a  sub rsp, 0x08
00007dd8609e3d1e  push rax
00007dd8609e3d1f  push rcx
00007dd8609e3d20  push rdx
00007dd8609e3d21  push rdi
00007dd8609e3d22  push rsi
00007dd8609e3d23  push r8
00007dd8609e3d25  push r9
00007dd8609e3d27  push r10
00007dd8609e3d29  push r11
00007dd8609e3d2b  sub rsp, 0xF0
00007dd8609e3d32  vmovaps [rsp], xmm0
00007dd8609e3d37  vmovaps [rsp+0x10], xmm1
00007dd8609e3d3d  vmovaps [rsp+0x20], xmm2
00007dd8609e3d43  vmovaps [rsp+0x30], xmm3
00007dd8609e3d49  vmovaps [rsp+0x40], xmm4
00007dd8609e3d4f  vmovaps [rsp+0x50], xmm5
00007dd8609e3d55  vmovaps [rsp+0x60], xmm6
00007dd8609e3d5b  vmovaps [rsp+0x70], xmm7
00007dd8609e3d61  vmovaps [rsp+0x80], xmm8
00007dd8609e3d6a  vmovaps [rsp+0x90], xmm9
00007dd8609e3d73  vmovaps [rsp+0xA0], xmm10
00007dd8609e3d7c  vmovaps [rsp+0xB0], xmm12
00007dd8609e3d85  vmovaps [rsp+0xC0], xmm13
00007dd8609e3d8e  vmovaps [rsp+0xD0], xmm14
00007dd8609e3d97  vmovaps [rsp+0xE0], xmm15
00007dd8609e3da0  sub rsp, 0x30
00007dd8609e3da4  movaps [rsp], xmm11
00007dd8609e3da9  movaps [rsp+0x10], xmm10
00007dd8609e3daf  movaps [rsp+0x20], xmm14
00007dd8609e3db5  lea rdi, [rsp]
00007dd8609e3db9  mov esi, 0x00
00007dd8609e3dbe  mov rax, 0x629C9CFA9530
00007dd8609e3dc8  call rax
00007dd8609e3dca  movaps xmm11, [rsp]
00007dd8609e3dcf  add rsp, 0x30
00007dd8609e3dd3  vmovaps xmm0, [rsp]
00007dd8609e3dd8  vmovaps xmm1, [rsp+0x10]
00007dd8609e3dde  vmovaps xmm2, [rsp+0x20]
00007dd8609e3de4  vmovaps xmm3, [rsp+0x30]
00007dd8609e3dea  vmovaps xmm4, [rsp+0x40]
00007dd8609e3df0  vmovaps xmm5, [rsp+0x50]
00007dd8609e3df6  vmovaps xmm6, [rsp+0x60]
00007dd8609e3dfc  vmovaps xmm7, [rsp+0x70]
00007dd8609e3e02  vmovaps xmm8, [rsp+0x80]
00007dd8609e3e0b  vmovaps xmm9, [rsp+0x90]
00007dd8609e3e14  vmovaps xmm10, [rsp+0xA0]
00007dd8609e3e1d  vmovaps xmm12, [rsp+0xB0]
00007dd8609e3e26  vmovaps xmm13, [rsp+0xC0]
00007dd8609e3e2f  vmovaps xmm14, [rsp+0xD0]
00007dd8609e3e38  vmovaps xmm15, [rsp+0xE0]
00007dd8609e3e41  add rsp, 0xF0
00007dd8609e3e48  pop r11
00007dd8609e3e4a  pop r10
00007dd8609e3e4c  pop r9
00007dd8609e3e4e  pop r8
00007dd8609e3e50  pop rsi
00007dd8609e3e51  pop rdi
00007dd8609e3e52  pop rdx
00007dd8609e3e53  pop rcx
00007dd8609e3e54  pop rax
00007dd8609e3e55  add rsp, 0x08
00007dd8609e3e59  jmp 0x00007DD8609DF880
00007dd8609e3e5e  call 0x00007DD8608C33A0
00007dd8609e3e63  jmp 0x00007DD8609DF88A
00007dd8609e3e68  sub rsp, 0x08
00007dd8609e3e6c  push rax
00007dd8609e3e6d  push rcx
00007dd8609e3e6e  push rdx
00007dd8609e3e6f  push rdi
00007dd8609e3e70  push rsi
00007dd8609e3e71  push r8
00007dd8609e3e73  push r9
00007dd8609e3e75  push r10
00007dd8609e3e77  push r11
00007dd8609e3e79  sub rsp, 0xF0
00007dd8609e3e80  vmovaps [rsp], xmm0
00007dd8609e3e85  vmovaps [rsp+0x10], xmm1
00007dd8609e3e8b  vmovaps [rsp+0x20], xmm2
00007dd8609e3e91  vmovaps [rsp+0x30], xmm3
00007dd8609e3e97  vmovaps [rsp+0x40], xmm4
00007dd8609e3e9d  vmovaps [rsp+0x50], xmm5
00007dd8609e3ea3  vmovaps [rsp+0x60], xmm6
00007dd8609e3ea9  vmovaps [rsp+0x70], xmm7
00007dd8609e3eaf  vmovaps [rsp+0x80], xmm8
00007dd8609e3eb8  vmovaps [rsp+0x90], xmm9
00007dd8609e3ec1  vmovaps [rsp+0xA0], xmm11
00007dd8609e3eca  vmovaps [rsp+0xB0], xmm12
00007dd8609e3ed3  vmovaps [rsp+0xC0], xmm13
00007dd8609e3edc  vmovaps [rsp+0xD0], xmm14
00007dd8609e3ee5  vmovaps [rsp+0xE0], xmm15
00007dd8609e3eee  sub rsp, 0x30
00007dd8609e3ef2  movaps [rsp], xmm10
00007dd8609e3ef7  movaps [rsp+0x10], xmm1
00007dd8609e3efc  movaps [rsp+0x20], xmm12
00007dd8609e3f02  lea rdi, [rsp]
00007dd8609e3f06  mov esi, 0x00
00007dd8609e3f0b  mov rax, 0x629C9CFA9530
00007dd8609e3f15  call rax
00007dd8609e3f17  movaps xmm10, [rsp]
00007dd8609e3f1c  add rsp, 0x30
00007dd8609e3f20  vmovaps xmm0, [rsp]
00007dd8609e3f25  vmovaps xmm1, [rsp+0x10]
00007dd8609e3f2b  vmovaps xmm2, [rsp+0x20]
00007dd8609e3f31  vmovaps xmm3, [rsp+0x30]
00007dd8609e3f37  vmovaps xmm4, [rsp+0x40]
00007dd8609e3f3d  vmovaps xmm5, [rsp+0x50]
00007dd8609e3f43  vmovaps xmm6, [rsp+0x60]
00007dd8609e3f49  vmovaps xmm7, [rsp+0x70]
00007dd8609e3f4f  vmovaps xmm8, [rsp+0x80]
00007dd8609e3f58  vmovaps xmm9, [rsp+0x90]
00007dd8609e3f61  vmovaps xmm11, [rsp+0xA0]
00007dd8609e3f6a  vmovaps xmm12, [rsp+0xB0]
00007dd8609e3f73  vmovaps xmm13, [rsp+0xC0]
00007dd8609e3f7c  vmovaps xmm14, [rsp+0xD0]
00007dd8609e3f85  vmovaps xmm15, [rsp+0xE0]
00007dd8609e3f8e  add rsp, 0xF0
00007dd8609e3f95  pop r11
00007dd8609e3f97  pop r10
00007dd8609e3f99  pop r9
00007dd8609e3f9b  pop r8
00007dd8609e3f9d  pop rsi
00007dd8609e3f9e  pop rdi
00007dd8609e3f9f  pop rdx
00007dd8609e3fa0  pop rcx
00007dd8609e3fa1  pop rax
00007dd8609e3fa2  add rsp, 0x08
00007dd8609e3fa6  jmp 0x00007DD8609DF8AD
00007dd8609e3fab  sub rsp, 0x08
00007dd8609e3faf  push rax
00007dd8609e3fb0  push rcx
00007dd8609e3fb1  push rdx
00007dd8609e3fb2  push rdi
00007dd8609e3fb3  push rsi
00007dd8609e3fb4  push r8
00007dd8609e3fb6  push r9
00007dd8609e3fb8  push r10
00007dd8609e3fba  push r11
00007dd8609e3fbc  sub rsp, 0xF0
00007dd8609e3fc3  vmovaps [rsp], xmm0
00007dd8609e3fc8  vmovaps [rsp+0x10], xmm1
00007dd8609e3fce  vmovaps [rsp+0x20], xmm2
00007dd8609e3fd4  vmovaps [rsp+0x30], xmm3
00007dd8609e3fda  vmovaps [rsp+0x40], xmm4
00007dd8609e3fe0  vmovaps [rsp+0x50], xmm5
00007dd8609e3fe6  vmovaps [rsp+0x60], xmm6
00007dd8609e3fec  vmovaps [rsp+0x70], xmm7
00007dd8609e3ff2  vmovaps [rsp+0x80], xmm8
00007dd8609e3ffb  vmovaps [rsp+0x90], xmm9
00007dd8609e4004  vmovaps [rsp+0xA0], xmm10
00007dd8609e400d  vmovaps [rsp+0xB0], xmm11
00007dd8609e4016  vmovaps [rsp+0xC0], xmm13
00007dd8609e401f  vmovaps [rsp+0xD0], xmm14
00007dd8609e4028  vmovaps [rsp+0xE0], xmm15
00007dd8609e4031  sub rsp, 0x30
00007dd8609e4035  movaps [rsp], xmm12
00007dd8609e403a  movaps [rsp+0x10], xmm14
00007dd8609e4040  movaps [rsp+0x20], xmm1
00007dd8609e4045  lea rdi, [rsp]
00007dd8609e4049  mov esi, 0x00
00007dd8609e404e  mov rax, 0x629C9CFA9530
00007dd8609e4058  call rax
00007dd8609e405a  movaps xmm12, [rsp]
00007dd8609e405f  add rsp, 0x30
00007dd8609e4063  vmovaps xmm0, [rsp]
00007dd8609e4068  vmovaps xmm1, [rsp+0x10]
00007dd8609e406e  vmovaps xmm2, [rsp+0x20]
00007dd8609e4074  vmovaps xmm3, [rsp+0x30]
00007dd8609e407a  vmovaps xmm4, [rsp+0x40]
00007dd8609e4080  vmovaps xmm5, [rsp+0x50]
00007dd8609e4086  vmovaps xmm6, [rsp+0x60]
00007dd8609e408c  vmovaps xmm7, [rsp+0x70]
00007dd8609e4092  vmovaps xmm8, [rsp+0x80]
00007dd8609e409b  vmovaps xmm9, [rsp+0x90]
00007dd8609e40a4  vmovaps xmm10, [rsp+0xA0]
00007dd8609e40ad  vmovaps xmm11, [rsp+0xB0]
00007dd8609e40b6  vmovaps xmm13, [rsp+0xC0]
00007dd8609e40bf  vmovaps xmm14, [rsp+0xD0]
00007dd8609e40c8  vmovaps xmm15, [rsp+0xE0]
00007dd8609e40d1  add rsp, 0xF0
00007dd8609e40d8  pop r11
00007dd8609e40da  pop r10
00007dd8609e40dc  pop r9
00007dd8609e40de  pop r8
00007dd8609e40e0  pop rsi
00007dd8609e40e1  pop rdi
00007dd8609e40e2  pop rdx
00007dd8609e40e3  pop rcx
00007dd8609e40e4  pop rax
00007dd8609e40e5  add rsp, 0x08
00007dd8609e40e9  jmp 0x00007DD8609DF8DC
00007dd8609e40ee  sub rsp, 0x08
00007dd8609e40f2  push rax
00007dd8609e40f3  push rcx
00007dd8609e40f4  push rdx
00007dd8609e40f5  push rdi
00007dd8609e40f6  push rsi
00007dd8609e40f7  push r8
00007dd8609e40f9  push r9
00007dd8609e40fb  push r10
00007dd8609e40fd  push r11
00007dd8609e40ff  sub rsp, 0xF0
00007dd8609e4106  vmovaps [rsp], xmm0
00007dd8609e410b  vmovaps [rsp+0x10], xmm1
00007dd8609e4111  vmovaps [rsp+0x20], xmm2
00007dd8609e4117  vmovaps [rsp+0x30], xmm3
00007dd8609e411d  vmovaps [rsp+0x40], xmm4
00007dd8609e4123  vmovaps [rsp+0x50], xmm5
00007dd8609e4129  vmovaps [rsp+0x60], xmm6
00007dd8609e412f  vmovaps [rsp+0x70], xmm7
00007dd8609e4135  vmovaps [rsp+0x80], xmm8
00007dd8609e413e  vmovaps [rsp+0x90], xmm9
00007dd8609e4147  vmovaps [rsp+0xA0], xmm10
00007dd8609e4150  vmovaps [rsp+0xB0], xmm11
00007dd8609e4159  vmovaps [rsp+0xC0], xmm12
00007dd8609e4162  vmovaps [rsp+0xD0], xmm13
00007dd8609e416b  vmovaps [rsp+0xE0], xmm15
00007dd8609e4174  sub rsp, 0x30
00007dd8609e4178  movaps [rsp], xmm14
00007dd8609e417d  movaps [rsp+0x10], xmm9
00007dd8609e4183  movaps [rsp+0x20], xmm1
00007dd8609e4188  lea rdi, [rsp]
00007dd8609e418c  mov esi, 0x00
00007dd8609e4191  mov rax, 0x629C9CFA9530
00007dd8609e419b  call rax
00007dd8609e419d  movaps xmm14, [rsp]
00007dd8609e41a2  add rsp, 0x30
00007dd8609e41a6  vmovaps xmm0, [rsp]
00007dd8609e41ab  vmovaps xmm1, [rsp+0x10]
00007dd8609e41b1  vmovaps xmm2, [rsp+0x20]
00007dd8609e41b7  vmovaps xmm3, [rsp+0x30]
00007dd8609e41bd  vmovaps xmm4, [rsp+0x40]
00007dd8609e41c3  vmovaps xmm5, [rsp+0x50]
00007dd8609e41c9  vmovaps xmm6, [rsp+0x60]
00007dd8609e41cf  vmovaps xmm7, [rsp+0x70]
00007dd8609e41d5  vmovaps xmm8, [rsp+0x80]
00007dd8609e41de  vmovaps xmm9, [rsp+0x90]
00007dd8609e41e7  vmovaps xmm10, [rsp+0xA0]
00007dd8609e41f0  vmovaps xmm11, [rsp+0xB0]
00007dd8609e41f9  vmovaps xmm12, [rsp+0xC0]
00007dd8609e4202  vmovaps xmm13, [rsp+0xD0]
00007dd8609e420b  vmovaps xmm15, [rsp+0xE0]
00007dd8609e4214  add rsp, 0xF0
00007dd8609e421b  pop r11
00007dd8609e421d  pop r10
00007dd8609e421f  pop r9
00007dd8609e4221  pop r8
00007dd8609e4223  pop rsi
00007dd8609e4224  pop rdi
00007dd8609e4225  pop rdx
00007dd8609e4226  pop rcx
00007dd8609e4227  pop rax
00007dd8609e4228  add rsp, 0x08
00007dd8609e422c  jmp 0x00007DD8609DF90B
00007dd8609e4231  sub rsp, 0x08
00007dd8609e4235  push rax
00007dd8609e4236  push rcx
00007dd8609e4237  push rdx
00007dd8609e4238  push rdi
00007dd8609e4239  push rsi
00007dd8609e423a  push r8
00007dd8609e423c  push r9
00007dd8609e423e  push r10
00007dd8609e4240  push r11
00007dd8609e4242  sub rsp, 0xF0
00007dd8609e4249  vmovaps [rsp], xmm0
00007dd8609e424e  vmovaps [rsp+0x10], xmm2
00007dd8609e4254  vmovaps [rsp+0x20], xmm3
00007dd8609e425a  vmovaps [rsp+0x30], xmm4
00007dd8609e4260  vmovaps [rsp+0x40], xmm5
00007dd8609e4266  vmovaps [rsp+0x50], xmm6
00007dd8609e426c  vmovaps [rsp+0x60], xmm7
00007dd8609e4272  vmovaps [rsp+0x70], xmm8
00007dd8609e4278  vmovaps [rsp+0x80], xmm9
00007dd8609e4281  vmovaps [rsp+0x90], xmm10
00007dd8609e428a  vmovaps [rsp+0xA0], xmm11
00007dd8609e4293  vmovaps [rsp+0xB0], xmm12
00007dd8609e429c  vmovaps [rsp+0xC0], xmm13
00007dd8609e42a5  vmovaps [rsp+0xD0], xmm14
00007dd8609e42ae  vmovaps [rsp+0xE0], xmm15
00007dd8609e42b7  sub rsp, 0x30
00007dd8609e42bb  movaps [rsp], xmm1
00007dd8609e42bf  movaps [rsp+0x10], xmm13
00007dd8609e42c5  movaps [rsp+0x20], xmm8
00007dd8609e42cb  lea rdi, [rsp]
00007dd8609e42cf  mov esi, 0x00
00007dd8609e42d4  mov rax, 0x629C9CFA9530
00007dd8609e42de  call rax
00007dd8609e42e0  movaps xmm1, [rsp]
00007dd8609e42e4  add rsp, 0x30
00007dd8609e42e8  vmovaps xmm0, [rsp]
00007dd8609e42ed  vmovaps xmm2, [rsp+0x10]
00007dd8609e42f3  vmovaps xmm3, [rsp+0x20]
00007dd8609e42f9  vmovaps xmm4, [rsp+0x30]
00007dd8609e42ff  vmovaps xmm5, [rsp+0x40]
00007dd8609e4305  vmovaps xmm6, [rsp+0x50]
00007dd8609e430b  vmovaps xmm7, [rsp+0x60]
00007dd8609e4311  vmovaps xmm8, [rsp+0x70]
00007dd8609e4317  vmovaps xmm9, [rsp+0x80]
00007dd8609e4320  vmovaps xmm10, [rsp+0x90]
00007dd8609e4329  vmovaps xmm11, [rsp+0xA0]
00007dd8609e4332  vmovaps xmm12, [rsp+0xB0]
00007dd8609e433b  vmovaps xmm13, [rsp+0xC0]
00007dd8609e4344  vmovaps xmm14, [rsp+0xD0]
00007dd8609e434d  vmovaps xmm15, [rsp+0xE0]
00007dd8609e4356  add rsp, 0xF0
00007dd8609e435d  pop r11
00007dd8609e435f  pop r10
00007dd8609e4361  pop r9
00007dd8609e4363  pop r8
00007dd8609e4365  pop rsi
00007dd8609e4366  pop rdi
00007dd8609e4367  pop rdx
00007dd8609e4368  pop rcx
00007dd8609e4369  pop rax
00007dd8609e436a  add rsp, 0x08
00007dd8609e436e  jmp 0x00007DD8609DF92D
00007dd8609e4373  call 0x00007DD86080C260
00007dd8609e4378  jmp 0x00007DD8609DF93B
00007dd8609e437d  call 0x00007DD8608BD750
00007dd8609e4382  jmp 0x00007DD8609DF945
00007dd8609e4387  sub rsp, 0x08
00007dd8609e438b  push rax
00007dd8609e438c  push rcx
00007dd8609e438d  push rdx
00007dd8609e438e  push rdi
00007dd8609e438f  push rsi
00007dd8609e4390  push r8
00007dd8609e4392  push r9
00007dd8609e4394  push r10
00007dd8609e4396  push r11
00007dd8609e4398  sub rsp, 0xF0
00007dd8609e439f  vmovaps [rsp], xmm0
00007dd8609e43a4  vmovaps [rsp+0x10], xmm1
00007dd8609e43aa  vmovaps [rsp+0x20], xmm2
00007dd8609e43b0  vmovaps [rsp+0x30], xmm3
00007dd8609e43b6  vmovaps [rsp+0x40], xmm4
00007dd8609e43bc  vmovaps [rsp+0x50], xmm5
00007dd8609e43c2  vmovaps [rsp+0x60], xmm6
00007dd8609e43c8  vmovaps [rsp+0x70], xmm7
00007dd8609e43ce  vmovaps [rsp+0x80], xmm9
00007dd8609e43d7  vmovaps [rsp+0x90], xmm10
00007dd8609e43e0  vmovaps [rsp+0xA0], xmm11
00007dd8609e43e9  vmovaps [rsp+0xB0], xmm12
00007dd8609e43f2  vmovaps [rsp+0xC0], xmm13
00007dd8609e43fb  vmovaps [rsp+0xD0], xmm14
00007dd8609e4404  vmovaps [rsp+0xE0], xmm15
00007dd8609e440d  sub rsp, 0x30
00007dd8609e4411  movaps [rsp], xmm8
00007dd8609e4416  movaps [rsp+0x10], xmm15
00007dd8609e441c  movaps [rsp+0x20], xmm7
00007dd8609e4421  lea rdi, [rsp]
00007dd8609e4425  mov esi, 0x00
00007dd8609e442a  mov rax, 0x629C9CFA9530
00007dd8609e4434  call rax
00007dd8609e4436  movaps xmm8, [rsp]
00007dd8609e443b  add rsp, 0x30
00007dd8609e443f  vmovaps xmm0, [rsp]
00007dd8609e4444  vmovaps xmm1, [rsp+0x10]
00007dd8609e444a  vmovaps xmm2, [rsp+0x20]
00007dd8609e4450  vmovaps xmm3, [rsp+0x30]
00007dd8609e4456  vmovaps xmm4, [rsp+0x40]
00007dd8609e445c  vmovaps xmm5, [rsp+0x50]
00007dd8609e4462  vmovaps xmm6, [rsp+0x60]
00007dd8609e4468  vmovaps xmm7, [rsp+0x70]
00007dd8609e446e  vmovaps xmm9, [rsp+0x80]
00007dd8609e4477  vmovaps xmm10, [rsp+0x90]
00007dd8609e4480  vmovaps xmm11, [rsp+0xA0]
00007dd8609e4489  vmovaps xmm12, [rsp+0xB0]
00007dd8609e4492  vmovaps xmm13, [rsp+0xC0]
00007dd8609e449b  vmovaps xmm14, [rsp+0xD0]
00007dd8609e44a4  vmovaps xmm15, [rsp+0xE0]
00007dd8609e44ad  add rsp, 0xF0
00007dd8609e44b4  pop r11
00007dd8609e44b6  pop r10
00007dd8609e44b8  pop r9
00007dd8609e44ba  pop r8
00007dd8609e44bc  pop rsi
00007dd8609e44bd  pop rdi
00007dd8609e44be  pop rdx
00007dd8609e44bf  pop rcx
00007dd8609e44c0  pop rax
00007dd8609e44c1  add rsp, 0x08
00007dd8609e44c5  jmp 0x00007DD8609DF967
00007dd8609e44ca  sub rsp, 0x08
00007dd8609e44ce  push rax
00007dd8609e44cf  push rcx
00007dd8609e44d0  push rdx
00007dd8609e44d1  push rdi
00007dd8609e44d2  push rsi
00007dd8609e44d3  push r8
00007dd8609e44d5  push r9
00007dd8609e44d7  push r10
00007dd8609e44d9  push r11
00007dd8609e44db  sub rsp, 0xF0
00007dd8609e44e2  vmovaps [rsp], xmm0
00007dd8609e44e7  vmovaps [rsp+0x10], xmm1
00007dd8609e44ed  vmovaps [rsp+0x20], xmm2
00007dd8609e44f3  vmovaps [rsp+0x30], xmm3
00007dd8609e44f9  vmovaps [rsp+0x40], xmm4
00007dd8609e44ff  vmovaps [rsp+0x50], xmm5
00007dd8609e4505  vmovaps [rsp+0x60], xmm6
00007dd8609e450b  vmovaps [rsp+0x70], xmm8
00007dd8609e4511  vmovaps [rsp+0x80], xmm9
00007dd8609e451a  vmovaps [rsp+0x90], xmm10
00007dd8609e4523  vmovaps [rsp+0xA0], xmm11
00007dd8609e452c  vmovaps [rsp+0xB0], xmm12
00007dd8609e4535  vmovaps [rsp+0xC0], xmm13
00007dd8609e453e  vmovaps [rsp+0xD0], xmm14
00007dd8609e4547  vmovaps [rsp+0xE0], xmm15
00007dd8609e4550  sub rsp, 0x30
00007dd8609e4554  movaps [rsp], xmm7
00007dd8609e4558  movaps [rsp+0x10], xmm9
00007dd8609e455e  movaps [rsp+0x20], xmm15
00007dd8609e4564  lea rdi, [rsp]
00007dd8609e4568  mov esi, 0x00
00007dd8609e456d  mov rax, 0x629C9CFA9530
00007dd8609e4577  call rax
00007dd8609e4579  movaps xmm7, [rsp]
00007dd8609e457d  add rsp, 0x30
00007dd8609e4581  vmovaps xmm0, [rsp]
00007dd8609e4586  vmovaps xmm1, [rsp+0x10]
00007dd8609e458c  vmovaps xmm2, [rsp+0x20]
00007dd8609e4592  vmovaps xmm3, [rsp+0x30]
00007dd8609e4598  vmovaps xmm4, [rsp+0x40]
00007dd8609e459e  vmovaps xmm5, [rsp+0x50]
00007dd8609e45a4  vmovaps xmm6, [rsp+0x60]
00007dd8609e45aa  vmovaps xmm8, [rsp+0x70]
00007dd8609e45b0  vmovaps xmm9, [rsp+0x80]
00007dd8609e45b9  vmovaps xmm10, [rsp+0x90]
00007dd8609e45c2  vmovaps xmm11, [rsp+0xA0]
00007dd8609e45cb  vmovaps xmm12, [rsp+0xB0]
00007dd8609e45d4  vmovaps xmm13, [rsp+0xC0]
00007dd8609e45dd  vmovaps xmm14, [rsp+0xD0]
00007dd8609e45e6  vmovaps xmm15, [rsp+0xE0]
00007dd8609e45ef  add rsp, 0xF0
00007dd8609e45f6  pop r11
00007dd8609e45f8  pop r10
00007dd8609e45fa  pop r9
00007dd8609e45fc  pop r8
00007dd8609e45fe  pop rsi
00007dd8609e45ff  pop rdi
00007dd8609e4600  pop rdx
00007dd8609e4601  pop rcx
00007dd8609e4602  pop rax
00007dd8609e4603  add rsp, 0x08
00007dd8609e4607  jmp 0x00007DD8609DF994
00007dd8609e460c  sub rsp, 0x08
00007dd8609e4610  push rax
00007dd8609e4611  push rcx
00007dd8609e4612  push rdx
00007dd8609e4613  push rdi
00007dd8609e4614  push rsi
00007dd8609e4615  push r8
00007dd8609e4617  push r9
00007dd8609e4619  push r10
00007dd8609e461b  push r11
00007dd8609e461d  sub rsp, 0xF0
00007dd8609e4624  vmovaps [rsp], xmm0
00007dd8609e4629  vmovaps [rsp+0x10], xmm1
00007dd8609e462f  vmovaps [rsp+0x20], xmm2
00007dd8609e4635  vmovaps [rsp+0x30], xmm3
00007dd8609e463b  vmovaps [rsp+0x40], xmm4
00007dd8609e4641  vmovaps [rsp+0x50], xmm5
00007dd8609e4647  vmovaps [rsp+0x60], xmm6
00007dd8609e464d  vmovaps [rsp+0x70], xmm7
00007dd8609e4653  vmovaps [rsp+0x80], xmm8
00007dd8609e465c  vmovaps [rsp+0x90], xmm10
00007dd8609e4665  vmovaps [rsp+0xA0], xmm11
00007dd8609e466e  vmovaps [rsp+0xB0], xmm12
00007dd8609e4677  vmovaps [rsp+0xC0], xmm13
00007dd8609e4680  vmovaps [rsp+0xD0], xmm14
00007dd8609e4689  vmovaps [rsp+0xE0], xmm15
00007dd8609e4692  sub rsp, 0x30
00007dd8609e4696  movaps [rsp], xmm9
00007dd8609e469b  movaps [rsp+0x10], xmm13
00007dd8609e46a1  movaps [rsp+0x20], xmm15
00007dd8609e46a7  lea rdi, [rsp]
00007dd8609e46ab  mov esi, 0x00
00007dd8609e46b0  mov rax, 0x629C9CFA9530
00007dd8609e46ba  call rax
00007dd8609e46bc  movaps xmm9, [rsp]
00007dd8609e46c1  add rsp, 0x30
00007dd8609e46c5  vmovaps xmm0, [rsp]
00007dd8609e46ca  vmovaps xmm1, [rsp+0x10]
00007dd8609e46d0  vmovaps xmm2, [rsp+0x20]
00007dd8609e46d6  vmovaps xmm3, [rsp+0x30]
00007dd8609e46dc  vmovaps xmm4, [rsp+0x40]
00007dd8609e46e2  vmovaps xmm5, [rsp+0x50]
00007dd8609e46e8  vmovaps xmm6, [rsp+0x60]
00007dd8609e46ee  vmovaps xmm7, [rsp+0x70]
00007dd8609e46f4  vmovaps xmm8, [rsp+0x80]
00007dd8609e46fd  vmovaps xmm10, [rsp+0x90]
00007dd8609e4706  vmovaps xmm11, [rsp+0xA0]
00007dd8609e470f  vmovaps xmm12, [rsp+0xB0]
00007dd8609e4718  vmovaps xmm13, [rsp+0xC0]
00007dd8609e4721  vmovaps xmm14, [rsp+0xD0]
00007dd8609e472a  vmovaps xmm15, [rsp+0xE0]
00007dd8609e4733  add rsp, 0xF0
00007dd8609e473a  pop r11
00007dd8609e473c  pop r10
00007dd8609e473e  pop r9
00007dd8609e4740  pop r8
00007dd8609e4742  pop rsi
00007dd8609e4743  pop rdi
00007dd8609e4744  pop rdx
00007dd8609e4745  pop rcx
00007dd8609e4746  pop rax
00007dd8609e4747  add rsp, 0x08
00007dd8609e474b  jmp 0x00007DD8609DF9C2
00007dd8609e4750  sub rsp, 0x08
00007dd8609e4754  push rax
00007dd8609e4755  push rcx
00007dd8609e4756  push rdx
00007dd8609e4757  push rdi
00007dd8609e4758  push rsi
00007dd8609e4759  push r8
00007dd8609e475b  push r9
00007dd8609e475d  push r10
00007dd8609e475f  push r11
00007dd8609e4761  sub rsp, 0xF0
00007dd8609e4768  vmovaps [rsp], xmm0
00007dd8609e476d  vmovaps [rsp+0x10], xmm1
00007dd8609e4773  vmovaps [rsp+0x20], xmm2
00007dd8609e4779  vmovaps [rsp+0x30], xmm3
00007dd8609e477f  vmovaps [rsp+0x40], xmm4
00007dd8609e4785  vmovaps [rsp+0x50], xmm5
00007dd8609e478b  vmovaps [rsp+0x60], xmm6
00007dd8609e4791  vmovaps [rsp+0x70], xmm7
00007dd8609e4797  vmovaps [rsp+0x80], xmm8
00007dd8609e47a0  vmovaps [rsp+0x90], xmm9
00007dd8609e47a9  vmovaps [rsp+0xA0], xmm10
00007dd8609e47b2  vmovaps [rsp+0xB0], xmm11
00007dd8609e47bb  vmovaps [rsp+0xC0], xmm12
00007dd8609e47c4  vmovaps [rsp+0xD0], xmm13
00007dd8609e47cd  vmovaps [rsp+0xE0], xmm14
00007dd8609e47d6  sub rsp, 0x30
00007dd8609e47da  movaps [rsp], xmm15
00007dd8609e47df  movaps [rsp+0x10], xmm11
00007dd8609e47e5  movaps [rsp+0x20], xmm12
00007dd8609e47eb  lea rdi, [rsp]
00007dd8609e47ef  mov esi, 0x00
00007dd8609e47f4  mov rax, 0x629C9CFA9530
00007dd8609e47fe  call rax
00007dd8609e4800  movaps xmm15, [rsp]
00007dd8609e4805  add rsp, 0x30
00007dd8609e4809  vmovaps xmm0, [rsp]
00007dd8609e480e  vmovaps xmm1, [rsp+0x10]
00007dd8609e4814  vmovaps xmm2, [rsp+0x20]
00007dd8609e481a  vmovaps xmm3, [rsp+0x30]
00007dd8609e4820  vmovaps xmm4, [rsp+0x40]
00007dd8609e4826  vmovaps xmm5, [rsp+0x50]
00007dd8609e482c  vmovaps xmm6, [rsp+0x60]
00007dd8609e4832  vmovaps xmm7, [rsp+0x70]
00007dd8609e4838  vmovaps xmm8, [rsp+0x80]
00007dd8609e4841  vmovaps xmm9, [rsp+0x90]
00007dd8609e484a  vmovaps xmm10, [rsp+0xA0]
00007dd8609e4853  vmovaps xmm11, [rsp+0xB0]
00007dd8609e485c  vmovaps xmm12, [rsp+0xC0]
00007dd8609e4865  vmovaps xmm13, [rsp+0xD0]
00007dd8609e486e  vmovaps xmm14, [rsp+0xE0]
00007dd8609e4877  add rsp, 0xF0
00007dd8609e487e  pop r11
00007dd8609e4880  pop r10
00007dd8609e4882  pop r9
00007dd8609e4884  pop r8
00007dd8609e4886  pop rsi
00007dd8609e4887  pop rdi
00007dd8609e4888  pop rdx
00007dd8609e4889  pop rcx
00007dd8609e488a  pop rax
00007dd8609e488b  add rsp, 0x08
00007dd8609e488f  jmp 0x00007DD8609DF9DD
00007dd8609e4894  sub rsp, 0x08
00007dd8609e4898  push rax
00007dd8609e4899  push rcx
00007dd8609e489a  push rdx
00007dd8609e489b  push rdi
00007dd8609e489c  push rsi
00007dd8609e489d  push r8
00007dd8609e489f  push r9
00007dd8609e48a1  push r10
00007dd8609e48a3  push r11
00007dd8609e48a5  sub rsp, 0xF0
00007dd8609e48ac  vmovaps [rsp], xmm0
00007dd8609e48b1  vmovaps [rsp+0x10], xmm1
00007dd8609e48b7  vmovaps [rsp+0x20], xmm2
00007dd8609e48bd  vmovaps [rsp+0x30], xmm3
00007dd8609e48c3  vmovaps [rsp+0x40], xmm4
00007dd8609e48c9  vmovaps [rsp+0x50], xmm5
00007dd8609e48cf  vmovaps [rsp+0x60], xmm6
00007dd8609e48d5  vmovaps [rsp+0x70], xmm7
00007dd8609e48db  vmovaps [rsp+0x80], xmm8
00007dd8609e48e4  vmovaps [rsp+0x90], xmm9
00007dd8609e48ed  vmovaps [rsp+0xA0], xmm10
00007dd8609e48f6  vmovaps [rsp+0xB0], xmm11
00007dd8609e48ff  vmovaps [rsp+0xC0], xmm12
00007dd8609e4908  vmovaps [rsp+0xD0], xmm14
00007dd8609e4911  vmovaps [rsp+0xE0], xmm15
00007dd8609e491a  sub rsp, 0x30
00007dd8609e491e  movaps [rsp], xmm13
00007dd8609e4923  movaps [rsp+0x10], xmm10
00007dd8609e4929  movaps [rsp+0x20], xmm14
00007dd8609e492f  lea rdi, [rsp]
00007dd8609e4933  mov esi, 0x00
00007dd8609e4938  mov rax, 0x629C9CFA9530
00007dd8609e4942  call rax
00007dd8609e4944  movaps xmm13, [rsp]
00007dd8609e4949  add rsp, 0x30
00007dd8609e494d  vmovaps xmm0, [rsp]
00007dd8609e4952  vmovaps xmm1, [rsp+0x10]
00007dd8609e4958  vmovaps xmm2, [rsp+0x20]
00007dd8609e495e  vmovaps xmm3, [rsp+0x30]
00007dd8609e4964  vmovaps xmm4, [rsp+0x40]
00007dd8609e496a  vmovaps xmm5, [rsp+0x50]
00007dd8609e4970  vmovaps xmm6, [rsp+0x60]
00007dd8609e4976  vmovaps xmm7, [rsp+0x70]
00007dd8609e497c  vmovaps xmm8, [rsp+0x80]
00007dd8609e4985  vmovaps xmm9, [rsp+0x90]
00007dd8609e498e  vmovaps xmm10, [rsp+0xA0]
00007dd8609e4997  vmovaps xmm11, [rsp+0xB0]
00007dd8609e49a0  vmovaps xmm12, [rsp+0xC0]
00007dd8609e49a9  vmovaps xmm14, [rsp+0xD0]
00007dd8609e49b2  vmovaps xmm15, [rsp+0xE0]
00007dd8609e49bb  add rsp, 0xF0
00007dd8609e49c2  pop r11
00007dd8609e49c4  pop r10
00007dd8609e49c6  pop r9
00007dd8609e49c8  pop r8
00007dd8609e49ca  pop rsi
00007dd8609e49cb  pop rdi
00007dd8609e49cc  pop rdx
00007dd8609e49cd  pop rcx
00007dd8609e49ce  pop rax
00007dd8609e49cf  add rsp, 0x08
00007dd8609e49d3  jmp 0x00007DD8609DFA00
00007dd8609e49d8  sub rsp, 0x08
00007dd8609e49dc  push rax
00007dd8609e49dd  push rcx
00007dd8609e49de  push rdx
00007dd8609e49df  push rdi
00007dd8609e49e0  push rsi
00007dd8609e49e1  push r8
00007dd8609e49e3  push r9
00007dd8609e49e5  push r10
00007dd8609e49e7  push r11
00007dd8609e49e9  sub rsp, 0xF0
00007dd8609e49f0  vmovaps [rsp], xmm0
00007dd8609e49f5  vmovaps [rsp+0x10], xmm1
00007dd8609e49fb  vmovaps [rsp+0x20], xmm2
00007dd8609e4a01  vmovaps [rsp+0x30], xmm3
00007dd8609e4a07  vmovaps [rsp+0x40], xmm4
00007dd8609e4a0d  vmovaps [rsp+0x50], xmm5
00007dd8609e4a13  vmovaps [rsp+0x60], xmm6
00007dd8609e4a19  vmovaps [rsp+0x70], xmm7
00007dd8609e4a1f  vmovaps [rsp+0x80], xmm8
00007dd8609e4a28  vmovaps [rsp+0x90], xmm9
00007dd8609e4a31  vmovaps [rsp+0xA0], xmm10
00007dd8609e4a3a  vmovaps [rsp+0xB0], xmm11
00007dd8609e4a43  vmovaps [rsp+0xC0], xmm12
00007dd8609e4a4c  vmovaps [rsp+0xD0], xmm13
00007dd8609e4a55  vmovaps [rsp+0xE0], xmm15
00007dd8609e4a5e  sub rsp, 0x30
00007dd8609e4a62  movaps [rsp], xmm14
00007dd8609e4a67  movaps [rsp+0x10], xmm1
00007dd8609e4a6c  movaps [rsp+0x20], xmm7
00007dd8609e4a71  lea rdi, [rsp]
00007dd8609e4a75  mov esi, 0x00
00007dd8609e4a7a  mov rax, 0x629C9CFA9530
00007dd8609e4a84  call rax
00007dd8609e4a86  movaps xmm14, [rsp]
00007dd8609e4a8b  add rsp, 0x30
00007dd8609e4a8f  vmovaps xmm0, [rsp]
00007dd8609e4a94  vmovaps xmm1, [rsp+0x10]
00007dd8609e4a9a  vmovaps xmm2, [rsp+0x20]
00007dd8609e4aa0  vmovaps xmm3, [rsp+0x30]
00007dd8609e4aa6  vmovaps xmm4, [rsp+0x40]
00007dd8609e4aac  vmovaps xmm5, [rsp+0x50]
00007dd8609e4ab2  vmovaps xmm6, [rsp+0x60]
00007dd8609e4ab8  vmovaps xmm7, [rsp+0x70]
00007dd8609e4abe  vmovaps xmm8, [rsp+0x80]
00007dd8609e4ac7  vmovaps xmm9, [rsp+0x90]
00007dd8609e4ad0  vmovaps xmm10, [rsp+0xA0]
00007dd8609e4ad9  vmovaps xmm11, [rsp+0xB0]
00007dd8609e4ae2  vmovaps xmm12, [rsp+0xC0]
00007dd8609e4aeb  vmovaps xmm13, [rsp+0xD0]
00007dd8609e4af4  vmovaps xmm15, [rsp+0xE0]
00007dd8609e4afd  add rsp, 0xF0
00007dd8609e4b04  pop r11
00007dd8609e4b06  pop r10
00007dd8609e4b08  pop r9
00007dd8609e4b0a  pop r8
00007dd8609e4b0c  pop rsi
00007dd8609e4b0d  pop rdi
00007dd8609e4b0e  pop rdx
00007dd8609e4b0f  pop rcx
00007dd8609e4b10  pop rax
00007dd8609e4b11  add rsp, 0x08
00007dd8609e4b15  jmp 0x00007DD8609DFA23
00007dd8609e4b1a  sub rsp, 0x08
00007dd8609e4b1e  push rax
00007dd8609e4b1f  push rcx
00007dd8609e4b20  push rdx
00007dd8609e4b21  push rdi
00007dd8609e4b22  push rsi
00007dd8609e4b23  push r8
00007dd8609e4b25  push r9
00007dd8609e4b27  push r10
00007dd8609e4b29  push r11
00007dd8609e4b2b  sub rsp, 0xF0
00007dd8609e4b32  vmovaps [rsp], xmm0
00007dd8609e4b37  vmovaps [rsp+0x10], xmm2
00007dd8609e4b3d  vmovaps [rsp+0x20], xmm3
00007dd8609e4b43  vmovaps [rsp+0x30], xmm4
00007dd8609e4b49  vmovaps [rsp+0x40], xmm5
00007dd8609e4b4f  vmovaps [rsp+0x50], xmm6
00007dd8609e4b55  vmovaps [rsp+0x60], xmm7
00007dd8609e4b5b  vmovaps [rsp+0x70], xmm8
00007dd8609e4b61  vmovaps [rsp+0x80], xmm9
00007dd8609e4b6a  vmovaps [rsp+0x90], xmm10
00007dd8609e4b73  vmovaps [rsp+0xA0], xmm11
00007dd8609e4b7c  vmovaps [rsp+0xB0], xmm12
00007dd8609e4b85  vmovaps [rsp+0xC0], xmm13
00007dd8609e4b8e  vmovaps [rsp+0xD0], xmm14
00007dd8609e4b97  vmovaps [rsp+0xE0], xmm15
00007dd8609e4ba0  sub rsp, 0x30
00007dd8609e4ba4  movaps [rsp], xmm1
00007dd8609e4ba8  movaps [rsp+0x10], xmm8
00007dd8609e4bae  movaps [rsp+0x20], xmm9
00007dd8609e4bb4  lea rdi, [rsp]
00007dd8609e4bb8  mov esi, 0x00
00007dd8609e4bbd  mov rax, 0x629C9CFA9530
00007dd8609e4bc7  call rax
00007dd8609e4bc9  movaps xmm1, [rsp]
00007dd8609e4bcd  add rsp, 0x30
00007dd8609e4bd1  vmovaps xmm0, [rsp]
00007dd8609e4bd6  vmovaps xmm2, [rsp+0x10]
00007dd8609e4bdc  vmovaps xmm3, [rsp+0x20]
00007dd8609e4be2  vmovaps xmm4, [rsp+0x30]
00007dd8609e4be8  vmovaps xmm5, [rsp+0x40]
00007dd8609e4bee  vmovaps xmm6, [rsp+0x50]
00007dd8609e4bf4  vmovaps xmm7, [rsp+0x60]
00007dd8609e4bfa  vmovaps xmm8, [rsp+0x70]
00007dd8609e4c00  vmovaps xmm9, [rsp+0x80]
00007dd8609e4c09  vmovaps xmm10, [rsp+0x90]
00007dd8609e4c12  vmovaps xmm11, [rsp+0xA0]
00007dd8609e4c1b  vmovaps xmm12, [rsp+0xB0]
00007dd8609e4c24  vmovaps xmm13, [rsp+0xC0]
00007dd8609e4c2d  vmovaps xmm14, [rsp+0xD0]
00007dd8609e4c36  vmovaps xmm15, [rsp+0xE0]
00007dd8609e4c3f  add rsp, 0xF0
00007dd8609e4c46  pop r11
00007dd8609e4c48  pop r10
00007dd8609e4c4a  pop r9
00007dd8609e4c4c  pop r8
00007dd8609e4c4e  pop rsi
00007dd8609e4c4f  pop rdi
00007dd8609e4c50  pop rdx
00007dd8609e4c51  pop rcx
00007dd8609e4c52  pop rax
00007dd8609e4c53  add rsp, 0x08
00007dd8609e4c57  jmp 0x00007DD8609DFA45
00007dd8609e4c5c  call 0x00007DD8608E5940
00007dd8609e4c61  jmp 0x00007DD8609DFA53
00007dd8609e4c66  call 0x00007DD86080C380
00007dd8609e4c6b  jmp 0x00007DD8609DFA5D
00007dd8609e4c70  call 0x00007DD86080D600
00007dd8609e4c75  jmp 0x00007DD8609DFA67
00007dd8609e4c7a  call 0x00007DD8607FF540
00007dd8609e4c7f  jmp 0x00007DD8609DFA71
00007dd8609e4c84  int3
00007dd8609e4c85  nop [rax+rax*1], ax
00007dd8609e4c8e  nop
00007dd8609e4c90  mov qword ptr [r15+0x40], 0x430000
00007dd8609e4c98  mov eax, 0x430CC0
00007dd8609e4c9d  mov r14, [r13+rax*1]
00007dd8609e4ca2  movq xmm1, r14
00007dd8609e4ca7  mov rax, [r15+0x50]
00007dd8609e4cab  movups xmm15, [r13+rax*1]
00007dd8609e4cb1  movaps [r15+0x120], xmm15
00007dd8609e4cb9  mov qword ptr [r15+0x48], 0x10
00007dd8609e4cc1  xor eax, eax
00007dd8609e4cc3  mov r14d, 0x10
00007dd8609e4cc9  mov r12d, 0x200
00007dd8609e4ccf  cmp r14, r12
00007dd8609e4cd2  cmc
00007dd8609e4cd3  lahf
00007dd8609e4cd4  seto al
00007dd8609e4cd7  mov [r15+0x108], eax
00007dd8609e4cde  pextrq rax, xmm15, 0x01
00007dd8609e4ce5  movq xmm14, rax
00007dd8609e4cea  movaps [r15+0x130], xmm14
00007dd8609e4cf2  movq rax, xmm1
00007dd8609e4cf7  movq r14, xmm15
00007dd8609e4cfc  vmovq xmm1, rax
00007dd8609e4d01  vmovq xmm15, r14
00007dd8609e4d06  movaps xmm13, xmm1
00007dd8609e4d0a  addsd xmm13, xmm15
00007dd8609e4d0f  ucomisd xmm13, xmm13
00007dd8609e4d14  jp 0x00007DD8609E4DD3
00007dd8609e4d1a  movq xmm13, xmm13
00007dd8609e4d1f  movq rax, xmm13
00007dd8609e4d24  movq r14, xmm14
00007dd8609e4d29  vmovq xmm1, rax
00007dd8609e4d2e  vmovq xmm15, r14
00007dd8609e4d33  movaps xmm14, xmm1
00007dd8609e4d37  addsd xmm14, xmm15
00007dd8609e4d3c  ucomisd xmm14, xmm14
00007dd8609e4d41  jp 0x00007DD8609E4E1B
00007dd8609e4d47  movq xmm14, xmm14
00007dd8609e4d4c  movaps [r15+0x110], xmm14
00007dd8609e4d54  mov eax, [r15+0x108]
00007dd8609e4d5b  sahf
00007dd8609e4d5c  jnz 0x00007DD8609E4D8E
00007dd8609e4d5e  cmp dword ptr [r15+0x318], 0x00
00007dd8609e4d66  jz 0x00007DD8609E5030
00007dd8609e4d6c  nop [rax+rax*1], ax
00007dd8609e4d75  nop [rax+rax*1], eax
00007dd8609e4d7d  mov eax, 0x410704
00007dd8609e4d82  mov [r15+0x100], rax
00007dd8609e4d89  jmp 0x00007DD8607FE110
00007dd8609e4d8e  cmp dword ptr [r15+0x318], 0x00
00007dd8609e4d96  jz 0x00007DD8609E4E70
00007dd8609e4d9c  nop [rax+rax*1], ax
00007dd8609e4da5  nop [rax+rax*1], eax
00007dd8609e4dad  mov eax, 0x4106E8
00007dd8609e4db2  mov [r15+0x100], rax
00007dd8609e4db9  jmp 0x00007DD8607FE110
00007dd8609e4dbe  int3
00007dd8609e4dbf  call 0x00007DD86080DC20
00007dd8609e4dc4  jmp 0x00007DD8609E4CA2
00007dd8609e4dc9  call 0x00007DD86080E760
00007dd8609e4dce  jmp 0x00007DD8609E4CB1
00007dd8609e4dd3  ucomisd xmm1, xmm15
00007dd8609e4dd8  jp 0x00007DD8609E4DE7
00007dd8609e4dda  movaps xmm13, [0x00007DD8605FE060]
00007dd8609e4de2  jmp 0x00007DD8609E4D1A
00007dd8609e4de7  vxorps xmm0, xmm1, xmm15
00007dd8609e4dec  pextrw eax, xmm0, 0x03
00007dd8609e4df1  and eax, 0x7FF8
00007dd8609e4df6  cmp eax, 0x08
00007dd8609e4df9  jnz 0x00007DD8609E4D1A
00007dd8609e4dff  movq rax, xmm15
00007dd8609e4e04  shl rax, 0x0D
00007dd8609e4e08  jbe 0x00007DD8609E4D1A
00007dd8609e4e0e  vorps xmm13, xmm15, [0x00007DD8605FE070]
00007dd8609e4e16  jmp 0x00007DD8609E4D1A
00007dd8609e4e1b  ucomisd xmm1, xmm15
00007dd8609e4e20  jp 0x00007DD8609E4E2F
00007dd8609e4e22  movaps xmm14, [0x00007DD8605FE060]
00007dd8609e4e2a  jmp 0x00007DD8609E4D47
00007dd8609e4e2f  vxorps xmm0, xmm1, xmm15
00007dd8609e4e34  pextrw eax, xmm0, 0x03
00007dd8609e4e39  and eax, 0x7FF8
00007dd8609e4e3e  cmp eax, 0x08
00007dd8609e4e41  jnz 0x00007DD8609E4D47
00007dd8609e4e47  movq rax, xmm15
00007dd8609e4e4c  shl rax, 0x0D
00007dd8609e4e50  jbe 0x00007DD8609E4D47
00007dd8609e4e56  vorps xmm14, xmm15, [0x00007DD8605FE070]
00007dd8609e4e5e  jmp 0x00007DD8609E4D47
00007dd8609e4e63  int3
00007dd8609e4e64  nop [rax+rax*1], ax
00007dd8609e4e6d  nop [rax], eax
00007dd8609e4e70  mov rax, [r15+0x48]
00007dd8609e4e74  mov r14, [r15+0x50]
00007dd8609e4e78  lea r12, [r14+rax*1]
00007dd8609e4e7c  movups xmm1, [r13+r12*1]
00007dd8609e4e82  movaps [r15+0x120], xmm1
00007dd8609e4e8a  lea r14, [rax+0x10]
00007dd8609e4e8e  mov [r15+0x48], r14
00007dd8609e4e92  xor eax, eax
00007dd8609e4e94  mov r12d, 0x200
00007dd8609e4e9a  cmp r14, r12
00007dd8609e4e9d  cmc
00007dd8609e4e9e  lahf
00007dd8609e4e9f  seto al
00007dd8609e4ea2  mov [r15+0x108], eax
00007dd8609e4ea9  pextrq rax, xmm1, 0x01
00007dd8609e4eb0  movq xmm15, rax
00007dd8609e4eb5  movaps [r15+0x130], xmm15
00007dd8609e4ebd  movaps xmm14, [r15+0x110]
00007dd8609e4ec5  movq rax, xmm14
00007dd8609e4eca  movq r14, xmm1
00007dd8609e4ecf  vmovq xmm1, rax
00007dd8609e4ed4  vmovq xmm14, r14
00007dd8609e4ed9  movaps xmm13, xmm1
00007dd8609e4edd  addsd xmm13, xmm14
00007dd8609e4ee2  ucomisd xmm13, xmm13
00007dd8609e4ee7  jp 0x00007DD8609E4F9C
00007dd8609e4eed  movq xmm13, xmm13
00007dd8609e4ef2  movq rax, xmm13
00007dd8609e4ef7  movq r14, xmm15
00007dd8609e4efc  vmovq xmm1, rax
00007dd8609e4f01  vmovq xmm15, r14
00007dd8609e4f06  movaps xmm14, xmm1
00007dd8609e4f0a  addsd xmm14, xmm15
00007dd8609e4f0f  ucomisd xmm14, xmm14
00007dd8609e4f14  jp 0x00007DD8609E4FE4
00007dd8609e4f1a  movq xmm14, xmm14
00007dd8609e4f1f  movaps [r15+0x110], xmm14
00007dd8609e4f27  mov eax, [r15+0x108]
00007dd8609e4f2e  sahf
00007dd8609e4f2f  jnz 0x00007DD8609E4F61
00007dd8609e4f31  cmp dword ptr [r15+0x318], 0x00
00007dd8609e4f39  jz 0x00007DD8609E5030
00007dd8609e4f3f  nop [rax+rax*1], ax
00007dd8609e4f48  nop [rax+rax*1], eax
00007dd8609e4f50  mov eax, 0x410704
00007dd8609e4f55  mov [r15+0x100], rax
00007dd8609e4f5c  jmp 0x00007DD8607FE110
00007dd8609e4f61  cmp dword ptr [r15+0x318], 0x00
00007dd8609e4f69  jz 0x00007DD8609E4E70
00007dd8609e4f6f  nop [rax+rax*1], ax
00007dd8609e4f78  nop [rax+rax*1], eax
00007dd8609e4f80  mov eax, 0x4106E8
00007dd8609e4f85  mov [r15+0x100], rax
00007dd8609e4f8c  jmp 0x00007DD8607FE110
00007dd8609e4f91  int3
00007dd8609e4f92  call 0x00007DD8608B52F0
00007dd8609e4f97  jmp 0x00007DD8609E4E82
00007dd8609e4f9c  ucomisd xmm1, xmm14
00007dd8609e4fa1  jp 0x00007DD8609E4FB0
00007dd8609e4fa3  movaps xmm13, [0x00007DD8605FE060]
00007dd8609e4fab  jmp 0x00007DD8609E4EED
00007dd8609e4fb0  vxorps xmm0, xmm1, xmm14
00007dd8609e4fb5  pextrw eax, xmm0, 0x03
00007dd8609e4fba  and eax, 0x7FF8
00007dd8609e4fbf  cmp eax, 0x08
00007dd8609e4fc2  jnz 0x00007DD8609E4EED
00007dd8609e4fc8  movq rax, xmm14
00007dd8609e4fcd  shl rax, 0x0D
00007dd8609e4fd1  jbe 0x00007DD8609E4EED
00007dd8609e4fd7  vorps xmm13, xmm14, [0x00007DD8605FE070]
00007dd8609e4fdf  jmp 0x00007DD8609E4EED
00007dd8609e4fe4  ucomisd xmm1, xmm15
00007dd8609e4fe9  jp 0x00007DD8609E4FF8
00007dd8609e4feb  movaps xmm14, [0x00007DD8605FE060]
00007dd8609e4ff3  jmp 0x00007DD8609E4F1A
00007dd8609e4ff8  vxorps xmm0, xmm1, xmm15
00007dd8609e4ffd  pextrw eax, xmm0, 0x03
00007dd8609e5002  and eax, 0x7FF8
00007dd8609e5007  cmp eax, 0x08
00007dd8609e500a  jnz 0x00007DD8609E4F1A
00007dd8609e5010  movq rax, xmm15
00007dd8609e5015  shl rax, 0x0D
00007dd8609e5019  jbe 0x00007DD8609E4F1A
00007dd8609e501f  vorps xmm14, xmm15, [0x00007DD8605FE070]
00007dd8609e5027  jmp 0x00007DD8609E4F1A
00007dd8609e502c  int3
00007dd8609e502d  nop [rax], eax
00007dd8609e5030  mov rax, [r15+0xF8]
00007dd8609e5037  lea r14, [rax+0x1D0]
00007dd8609e503e  mov r12, [r13+r14*1]
00007dd8609e5043  lea r14, [rax+0x1D8]
00007dd8609e504a  mov r11, [r13+r14*1]
00007dd8609e504f  mov [r15+0xA0], r12
00007dd8609e5056  mov [r15+0x98], r11
00007dd8609e505d  mov r14, [r15+0x40]
00007dd8609e5061  lea r12, [r14+0xCC0]
00007dd8609e5068  movaps xmm1, [r15+0x110]
00007dd8609e5070  movq r14, xmm1
00007dd8609e5075  mov [r13+r12*1], r14
00007dd8609e507a  lea r14, [rax+0x1C0]
00007dd8609e5081  mov r12, [r13+r14*1]
00007dd8609e5086  lea r14, [rax+0x1C8]
00007dd8609e508d  mov r11, [r13+r14*1]
00007dd8609e5092  mov [r15+0xE8], r12
00007dd8609e5099  mov [r15+0xF0], r11
00007dd8609e50a0  lea r14, [rax+0x1B0]
00007dd8609e50a7  mov r12, [r13+r14*1]
00007dd8609e50ac  lea r14, [rax+0x1B8]
00007dd8609e50b3  mov r10, [r13+r14*1]
00007dd8609e50b8  movq xmm1, r12
00007dd8609e50bd  movq xmm15, r10
00007dd8609e50c2  movq xmm1, xmm1
00007dd8609e50c6  movq xmm1, xmm1
00007dd8609e50ca  movaps [r15+0x1A0], xmm1
00007dd8609e50d2  movq xmm15, xmm15
00007dd8609e50d7  movq xmm15, xmm15
00007dd8609e50dc  movaps [r15+0x190], xmm15
00007dd8609e50e4  lea r14, [rax+0x1A0]
00007dd8609e50eb  mov r12, [r13+r14*1]
00007dd8609e50f0  lea r14, [rax+0x1A8]
00007dd8609e50f7  mov r10, [r13+r14*1]
00007dd8609e50fc  movq xmm1, r12
00007dd8609e5101  movq xmm15, r10
00007dd8609e5106  movq xmm1, xmm1
00007dd8609e510a  movq xmm1, xmm1
00007dd8609e510e  movaps [r15+0x1C0], xmm1
00007dd8609e5116  movq xmm15, xmm15
00007dd8609e511b  movq xmm15, xmm15
00007dd8609e5120  movaps [r15+0x1B0], xmm15
00007dd8609e5128  lea r14, [rax+0x190]
00007dd8609e512f  mov r12, [r13+r14*1]
00007dd8609e5134  lea r14, [rax+0x198]
00007dd8609e513b  mov r10, [r13+r14*1]
00007dd8609e5140  movq xmm1, r12
00007dd8609e5145  movq xmm15, r10
00007dd8609e514a  movq xmm1, xmm1
00007dd8609e514e  movq xmm1, xmm1
00007dd8609e5152  movaps [r15+0x1E0], xmm1
00007dd8609e515a  movq xmm15, xmm15
00007dd8609e515f  movq xmm15, xmm15
00007dd8609e5164  movaps [r15+0x1D0], xmm15
00007dd8609e516c  lea r14, [rax+0x180]
00007dd8609e5173  mov r12, [r13+r14*1]
00007dd8609e5178  lea r14, [rax+0x188]
00007dd8609e517f  mov r10, [r13+r14*1]
00007dd8609e5184  movq xmm1, r12
00007dd8609e5189  movq xmm15, r10
00007dd8609e518e  movq xmm1, xmm1
00007dd8609e5192  movq xmm1, xmm1
00007dd8609e5196  movaps [r15+0x200], xmm1
00007dd8609e519e  movq xmm15, xmm15
00007dd8609e51a3  movq xmm15, xmm15
00007dd8609e51a8  movaps [r15+0x1F0], xmm15
00007dd8609e51b0  lea r14, [rax+0x1E0]
00007dd8609e51b7  mov [r15+0xF8], r14
00007dd8609e51be  mov [r15+0x100], r11
00007dd8609e51c5  jmp 0x00007DD8609CE5C0
00007dd8609e51ca  int3
00007dd8609e51cb  call 0x00007DD8608E27E0
00007dd8609e51d0  jmp 0x00007DD8609E5043
00007dd8609e51d5  call 0x00007DD8608E1570
00007dd8609e51da  jmp 0x00007DD8609E504F
00007dd8609e51df  call 0x00007DD8608C3FE0
00007dd8609e51e4  jmp 0x00007DD8609E507A
00007dd8609e51e9  call 0x00007DD8608E27E0
00007dd8609e51ee  jmp 0x00007DD8609E5086
00007dd8609e51f3  call 0x00007DD8608E1570
00007dd8609e51f8  jmp 0x00007DD8609E5092
00007dd8609e51fd  call 0x00007DD8608E27E0
00007dd8609e5202  jmp 0x00007DD8609E50AC
00007dd8609e5207  call 0x00007DD8608E0300
00007dd8609e520c  jmp 0x00007DD8609E50B8
00007dd8609e5211  call 0x00007DD8608E27E0
00007dd8609e5216  jmp 0x00007DD8609E50F0
00007dd8609e521b  call 0x00007DD8608E0300
00007dd8609e5220  jmp 0x00007DD8609E50FC
00007dd8609e5225  call 0x00007DD8608E27E0
00007dd8609e522a  jmp 0x00007DD8609E5134
00007dd8609e522f  call 0x00007DD8608E0300
00007dd8609e5234  jmp 0x00007DD8609E5140
00007dd8609e5239  call 0x00007DD8608E27E0
00007dd8609e523e  jmp 0x00007DD8609E5178
00007dd8609e5243  call 0x00007DD8608E0300
00007dd8609e5248  jmp 0x00007DD8609E5184
00007dd8609e524d  int3
00007dd8609e524e  nop
00007dd8609e5250  mov qword ptr [r15+0x100], 0x04
00007dd8609e525b  mov esi, 0x00
00007dd8609e5260  mov edx, 0x09
00007dd8609e5265  mov rdi, 0x7FFDDAAEDB10
00007dd8609e526f  mov rax, 0x629C9CE3C970
00007dd8609e5279  call rax
00007dd8609e527b  cmp dword ptr [r15+0x318], 0x00
00007dd8609e5283  jnz 0x00007DD8607FE110
00007dd8609e5289  jmp 0x00007DD8607FE0A0
00007dd8609e528e  int3
00007dd8609e528f  int3
