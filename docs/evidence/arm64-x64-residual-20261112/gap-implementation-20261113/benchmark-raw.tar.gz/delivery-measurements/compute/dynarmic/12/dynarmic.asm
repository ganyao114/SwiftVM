00007531fdbce69b  nop [rax+rax*1], eax
00007531fdbce6a0  mov rax, [r15+0xF8]
00007531fdbce6a7  lea r14, [rax-0x1E0]
00007531fdbce6ae  mov [r15+0xF8], r14
00007531fdbce6b5  lea rax, [r14+0x1D0]
00007531fdbce6bc  mov r12, [r15+0xA0]
00007531fdbce6c3  mov r11, [r15+0x98]
00007531fdbce6ca  mov [r13+rax*1], r12
00007531fdbce6cf  lea rax, [r14+0x1D8]
00007531fdbce6d6  mov [r13+rax*1], r11
00007531fdbce6db  mov eax, 0x420AA0
00007531fdbce6e0  movups xmm1, [r13+rax*1]
00007531fdbce6e6  mov eax, 0x420A30
00007531fdbce6eb  movups xmm15, [r13+rax*1]
00007531fdbce6f1  mov eax, 0x420AC0
00007531fdbce6f6  movups xmm14, [r13+rax*1]
00007531fdbce6fc  mov eax, 0x420A60
00007531fdbce701  movups xmm13, [r13+rax*1]
00007531fdbce707  mov qword ptr [r15+0x98], 0x430CD0
00007531fdbce712  mov eax, 0x420AD0
00007531fdbce717  movups xmm12, [r13+rax*1]
00007531fdbce71d  mov eax, 0x430CD0
00007531fdbce722  movups [r13+rax*1], xmm1
00007531fdbce728  mov eax, 0x430CE0
00007531fdbce72d  movups [r13+rax*1], xmm15
00007531fdbce733  mov eax, 0x430CF0
00007531fdbce738  movups [r13+rax*1], xmm14
00007531fdbce73e  mov eax, 0x430D00
00007531fdbce743  movups [r13+rax*1], xmm13
00007531fdbce749  mov eax, 0x420A20
00007531fdbce74e  movups xmm14, [r13+rax*1]
00007531fdbce754  mov eax, 0x420A10
00007531fdbce759  movups xmm13, [r13+rax*1]
00007531fdbce75f  mov eax, 0x430DD0
00007531fdbce764  movups [r13+rax*1], xmm1
00007531fdbce76a  mov eax, 0x430DE0
00007531fdbce76f  movups [r13+rax*1], xmm15
00007531fdbce775  mov eax, 0x430D10
00007531fdbce77a  movups [r13+rax*1], xmm12
00007531fdbce780  mov eax, 0x430D20
00007531fdbce785  movups [r13+rax*1], xmm14
00007531fdbce78b  mov eax, 0x420A00
00007531fdbce790  movups xmm1, [r13+rax*1]
00007531fdbce796  mov eax, 0x420A70
00007531fdbce79b  movups xmm15, [r13+rax*1]
00007531fdbce7a1  mov eax, 0x430D30
00007531fdbce7a6  movups [r13+rax*1], xmm13
00007531fdbce7ac  mov eax, 0x430D40
00007531fdbce7b1  movups [r13+rax*1], xmm1
00007531fdbce7b7  mov eax, 0x420A80
00007531fdbce7bc  movups xmm1, [r13+rax*1]
00007531fdbce7c2  mov eax, 0x420A50
00007531fdbce7c7  movups xmm14, [r13+rax*1]
00007531fdbce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007531fdbce7d5  mov eax, 0x430D50
00007531fdbce7da  movups [r13+rax*1], xmm15
00007531fdbce7e0  mov eax, 0x430D60
00007531fdbce7e5  movups [r13+rax*1], xmm1
00007531fdbce7eb  mov eax, 0x420AF0
00007531fdbce7f0  movups xmm1, [r13+rax*1]
00007531fdbce7f6  mov eax, 0x420B00
00007531fdbce7fb  movups xmm15, [r13+rax*1]
00007531fdbce801  movaps [r15+0x150], xmm15
00007531fdbce809  mov qword ptr [r15+0xA0], 0x3E8
00007531fdbce814  mov eax, 0x430D70
00007531fdbce819  movups [r13+rax*1], xmm14
00007531fdbce81f  mov eax, 0x430D80
00007531fdbce824  movups [r13+rax*1], xmm1
00007531fdbce82a  mov eax, 0x420AE0
00007531fdbce82f  movups xmm1, [r13+rax*1]
00007531fdbce835  mov eax, 0x420A90
00007531fdbce83a  movups xmm14, [r13+rax*1]
00007531fdbce840  movaps [r15+0x140], xmm14
00007531fdbce848  lea rax, [r14+0x180]
00007531fdbce84f  movq xmm13, qword ptr [r15+0x200]
00007531fdbce858  movq xmm12, qword ptr [r15+0x1F0]
00007531fdbce861  movq r12, xmm13
00007531fdbce866  movq r11, xmm12
00007531fdbce86b  mov [r13+rax*1], r12
00007531fdbce870  lea rax, [r14+0x188]
00007531fdbce877  mov [r13+rax*1], r11
00007531fdbce87c  mov eax, 0x430D90
00007531fdbce881  movups [r13+rax*1], xmm15
00007531fdbce887  mov eax, 0x430DA0
00007531fdbce88c  movups [r13+rax*1], xmm1
00007531fdbce892  mov eax, 0x420AB0
00007531fdbce897  movups xmm1, [r13+rax*1]
00007531fdbce89d  mov eax, 0x420B18
00007531fdbce8a2  mov r12, [r13+rax*1]
00007531fdbce8a7  movq xmm15, r12
00007531fdbce8ac  mov qword ptr [r15+0x40], 0x420B20
00007531fdbce8b4  mov eax, 0x430DB0
00007531fdbce8b9  movups [r13+rax*1], xmm14
00007531fdbce8bf  mov eax, 0x430DC0
00007531fdbce8c4  movups [r13+rax*1], xmm1
00007531fdbce8ca  mov eax, 0x420B80
00007531fdbce8cf  movups xmm1, [r13+rax*1]
00007531fdbce8d5  movq rax, xmm15
00007531fdbce8da  mov r12d, 0x430DF0
00007531fdbce8e0  mov [r13+r12*1], rax
00007531fdbce8e5  mov eax, 0x420B60
00007531fdbce8ea  movups xmm15, [r13+rax*1]
00007531fdbce8f0  mov eax, 0x420B70
00007531fdbce8f5  movups xmm14, [r13+rax*1]
00007531fdbce8fb  lea rax, [r14+0x160]
00007531fdbce902  movups [r13+rax*1], xmm1
00007531fdbce908  lea rax, [r14+0x190]
00007531fdbce90f  movq xmm1, qword ptr [r15+0x1E0]
00007531fdbce918  movq xmm13, qword ptr [r15+0x1D0]
00007531fdbce921  movq r12, xmm1
00007531fdbce926  movq r11, xmm13
00007531fdbce92b  mov [r13+rax*1], r12
00007531fdbce930  lea rax, [r14+0x198]
00007531fdbce937  mov [r13+rax*1], r11
00007531fdbce93c  lea rax, [r14+0x140]
00007531fdbce943  movups [r13+rax*1], xmm15
00007531fdbce949  lea rax, [r14+0x150]
00007531fdbce950  movups [r13+rax*1], xmm14
00007531fdbce956  mov eax, 0x420B20
00007531fdbce95b  movups xmm1, [r13+rax*1]
00007531fdbce961  mov eax, 0x420B30
00007531fdbce966  movups xmm15, [r13+rax*1]
00007531fdbce96c  movaps [r15+0x120], xmm15
00007531fdbce974  lea rax, [r14+0x1A0]
00007531fdbce97b  movq xmm14, qword ptr [r15+0x1C0]
00007531fdbce984  movq xmm13, qword ptr [r15+0x1B0]
00007531fdbce98d  movq r12, xmm14
00007531fdbce992  movq r11, xmm13
00007531fdbce997  mov [r13+rax*1], r12
00007531fdbce99c  lea rax, [r14+0x1A8]
00007531fdbce9a3  mov [r13+rax*1], r11
00007531fdbce9a8  lea rax, [r14+0x1B0]
00007531fdbce9af  movq xmm14, qword ptr [r15+0x1A0]
00007531fdbce9b8  movq xmm13, qword ptr [r15+0x190]
00007531fdbce9c1  movq r12, xmm14
00007531fdbce9c6  movq r11, xmm13
00007531fdbce9cb  mov [r13+rax*1], r12
00007531fdbce9d0  lea rax, [r14+0x1B8]
00007531fdbce9d7  mov [r13+rax*1], r11
00007531fdbce9dc  lea rax, [r14+0x100]
00007531fdbce9e3  movups [r13+rax*1], xmm1
00007531fdbce9e9  lea rax, [r14+0x110]
00007531fdbce9f0  movups [r13+rax*1], xmm15
00007531fdbce9f6  mov eax, 0x420B40
00007531fdbce9fb  movups xmm1, [r13+rax*1]
00007531fdbcea01  mov eax, 0x420B50
00007531fdbcea06  movups xmm15, [r13+rax*1]
00007531fdbcea0c  movaps [r15+0x110], xmm1
00007531fdbcea14  movaps [r15+0x130], xmm15
00007531fdbcea1c  lea rax, [r14+0x1C0]
00007531fdbcea23  mov r12, [r15+0xE8]
00007531fdbcea2a  mov r11, [r15+0xF0]
00007531fdbcea31  mov [r13+rax*1], r12
00007531fdbcea36  lea rax, [r14+0x1C8]
00007531fdbcea3d  mov [r13+rax*1], r11
00007531fdbcea42  mov eax, 0x430DF8
00007531fdbcea47  mov r12d, 0x421DF8D3
00007531fdbcea4d  mov [r13+rax*1], r12d
00007531fdbcea52  lea rax, [r14+0x120]
00007531fdbcea59  movups [r13+rax*1], xmm1
00007531fdbcea5f  lea rax, [r14+0x130]
00007531fdbcea66  movups [r13+rax*1], xmm15
00007531fdbcea6c  lea rax, [r14+0x100]
00007531fdbcea73  mov [r15], rax
00007531fdbcea76  mov qword ptr [r15+0x08], 0x430CD0
00007531fdbcea7e  mov qword ptr [r15+0x10], 0x12C
00007531fdbcea86  mov qword ptr [r15+0xF0], 0x410284
00007531fdbcea91  mov r14d, [r15+0x320]
00007531fdbcea98  mov eax, 0x410284
00007531fdbcea9d  mov rcx, 0x7531FDBD07C0
00007531fdbceaa7  mov [r15+r14*8+0x328], rax
00007531fdbceaaf  mov [r15+r14*8+0x368], rcx
00007531fdbceab7  add r14d, 0x01
00007531fdbceabb  and r14d, 0x07
00007531fdbceabf  mov [r15+0x320], r14d
00007531fdbceac6  cmp dword ptr [r15+0x318], 0x00
00007531fdbceace  jz 0x00007531FDBCED70
00007531fdbcead4  nop [rax+rax*1], ax
00007531fdbceadd  nop [rax+rax*1], eax
00007531fdbceae5  mov eax, 0x410728
00007531fdbceaea  mov [r15+0x100], rax
00007531fdbceaf1  jmp 0x00007531FD9FE110
00007531fdbceaf6  int3
00007531fdbceaf7  call 0x00007531FDA0BC20
00007531fdbceafc  jmp 0x00007531FDBCE6CF
00007531fdbceb01  call 0x00007531FDA0A9A0
00007531fdbceb06  jmp 0x00007531FDBCE6DB
00007531fdbceb0b  call 0x00007531FD9FF430
00007531fdbceb10  jmp 0x00007531FDBCE6E6
00007531fdbceb15  call 0x00007531FDA0E760
00007531fdbceb1a  jmp 0x00007531FDBCE6F1
00007531fdbceb1f  call 0x00007531FDA0D4E0
00007531fdbceb24  jmp 0x00007531FDBCE6FC
00007531fdbceb29  call 0x00007531FDA0C260
00007531fdbceb2e  jmp 0x00007531FDBCE707
00007531fdbceb33  call 0x00007531FDA0AFE0
00007531fdbceb38  jmp 0x00007531FDBCE71D
00007531fdbceb3d  call 0x00007531FD9FF540
00007531fdbceb42  jmp 0x00007531FDBCE728
00007531fdbceb47  call 0x00007531FDA0E880
00007531fdbceb4c  jmp 0x00007531FDBCE733
00007531fdbceb51  call 0x00007531FDA0D600
00007531fdbceb56  jmp 0x00007531FDBCE73E
00007531fdbceb5b  call 0x00007531FDA0C380
00007531fdbceb60  jmp 0x00007531FDBCE749
00007531fdbceb65  call 0x00007531FDA0D4E0
00007531fdbceb6a  jmp 0x00007531FDBCE754
00007531fdbceb6f  call 0x00007531FDA0C260
00007531fdbceb74  jmp 0x00007531FDBCE75F
00007531fdbceb79  call 0x00007531FD9FF540
00007531fdbceb7e  jmp 0x00007531FDBCE76A
00007531fdbceb83  call 0x00007531FDA0E880
00007531fdbceb88  jmp 0x00007531FDBCE775
00007531fdbceb8d  call 0x00007531FDA0B100
00007531fdbceb92  jmp 0x00007531FDBCE780
00007531fdbceb97  call 0x00007531FDA0D600
00007531fdbceb9c  jmp 0x00007531FDBCE78B
00007531fdbceba1  call 0x00007531FD9FF430
00007531fdbceba6  jmp 0x00007531FDBCE796
00007531fdbcebab  call 0x00007531FDA0E760
00007531fdbcebb0  jmp 0x00007531FDBCE7A1
00007531fdbcebb5  call 0x00007531FDA0C380
00007531fdbcebba  jmp 0x00007531FDBCE7AC
00007531fdbcebbf  call 0x00007531FD9FF540
00007531fdbcebc4  jmp 0x00007531FDBCE7B7
00007531fdbcebc9  call 0x00007531FD9FF430
00007531fdbcebce  jmp 0x00007531FDBCE7C2
00007531fdbcebd3  call 0x00007531FDA0D4E0
00007531fdbcebd8  jmp 0x00007531FDBCE7CD
00007531fdbcebdd  call 0x00007531FDA0E880
00007531fdbcebe2  jmp 0x00007531FDBCE7E0
00007531fdbcebe7  call 0x00007531FD9FF540
00007531fdbcebec  jmp 0x00007531FDBCE7EB
00007531fdbcebf1  call 0x00007531FD9FF430
00007531fdbcebf6  jmp 0x00007531FDBCE7F6
00007531fdbcebfb  call 0x00007531FDA0E760
00007531fdbcec00  jmp 0x00007531FDBCE801
00007531fdbcec05  call 0x00007531FDA0D600
00007531fdbcec0a  jmp 0x00007531FDBCE81F
00007531fdbcec0f  call 0x00007531FD9FF540
00007531fdbcec14  jmp 0x00007531FDBCE82A
00007531fdbcec19  call 0x00007531FD9FF430
00007531fdbcec1e  jmp 0x00007531FDBCE835
00007531fdbcec23  call 0x00007531FDA0D4E0
00007531fdbcec28  jmp 0x00007531FDBCE840
00007531fdbcec2d  call 0x00007531FDA0BC20
00007531fdbcec32  jmp 0x00007531FDBCE870
00007531fdbcec37  call 0x00007531FDA0A9A0
00007531fdbcec3c  jmp 0x00007531FDBCE87C
00007531fdbcec41  call 0x00007531FDA0E880
00007531fdbcec46  jmp 0x00007531FDBCE887
00007531fdbcec4b  call 0x00007531FD9FF540
00007531fdbcec50  jmp 0x00007531FDBCE892
00007531fdbcec55  call 0x00007531FD9FF430
00007531fdbcec5a  jmp 0x00007531FDBCE89D
00007531fdbcec5f  call 0x00007531FDA0B720
00007531fdbcec64  jmp 0x00007531FDBCE8A7
00007531fdbcec69  call 0x00007531FDA0D600
00007531fdbcec6e  jmp 0x00007531FDBCE8BF
00007531fdbcec73  call 0x00007531FD9FF540
00007531fdbcec78  jmp 0x00007531FDBCE8CA
00007531fdbcec7d  call 0x00007531FD9FF430
00007531fdbcec82  jmp 0x00007531FDBCE8D5
00007531fdbcec87  call 0x00007531FDAB4CB0
00007531fdbcec8c  jmp 0x00007531FDBCE8E5
00007531fdbcec91  call 0x00007531FDA0E760
00007531fdbcec96  jmp 0x00007531FDBCE8F0
00007531fdbcec9b  call 0x00007531FDA0D4E0
00007531fdbceca0  jmp 0x00007531FDBCE8FB
00007531fdbceca5  call 0x00007531FD9FF540
00007531fdbcecaa  jmp 0x00007531FDBCE908
00007531fdbcecaf  call 0x00007531FDA0BC20
00007531fdbcecb4  jmp 0x00007531FDBCE930
00007531fdbcecb9  call 0x00007531FDA0A9A0
00007531fdbcecbe  jmp 0x00007531FDBCE93C
00007531fdbcecc3  call 0x00007531FDA0E880
00007531fdbcecc8  jmp 0x00007531FDBCE949
00007531fdbceccd  call 0x00007531FDA0D600
00007531fdbcecd2  jmp 0x00007531FDBCE956
00007531fdbcecd7  call 0x00007531FD9FF430
00007531fdbcecdc  jmp 0x00007531FDBCE961
00007531fdbcece1  call 0x00007531FDA0E760
00007531fdbcece6  jmp 0x00007531FDBCE96C
00007531fdbceceb  call 0x00007531FDA0BC20
00007531fdbcecf0  jmp 0x00007531FDBCE99C
00007531fdbcecf5  call 0x00007531FDA0A9A0
00007531fdbcecfa  jmp 0x00007531FDBCE9A8
00007531fdbcecff  call 0x00007531FDA0BC20
00007531fdbced04  jmp 0x00007531FDBCE9D0
00007531fdbced09  call 0x00007531FDA0A9A0
00007531fdbced0e  jmp 0x00007531FDBCE9DC
00007531fdbced13  call 0x00007531FD9FF540
00007531fdbced18  jmp 0x00007531FDBCE9E9
00007531fdbced1d  call 0x00007531FDA0E880
00007531fdbced22  jmp 0x00007531FDBCE9F6
00007531fdbced27  call 0x00007531FD9FF430
00007531fdbced2c  jmp 0x00007531FDBCEA01
00007531fdbced31  call 0x00007531FDA0E760
00007531fdbced36  jmp 0x00007531FDBCEA0C
00007531fdbced3b  call 0x00007531FDA0BC20
00007531fdbced40  jmp 0x00007531FDBCEA36
00007531fdbced45  call 0x00007531FDA0A9A0
00007531fdbced4a  jmp 0x00007531FDBCEA42
00007531fdbced4f  call 0x00007531FDA0BAE0
00007531fdbced54  jmp 0x00007531FDBCEA52
00007531fdbced59  call 0x00007531FD9FF540
00007531fdbced5e  jmp 0x00007531FDBCEA5F
00007531fdbced63  call 0x00007531FDA0E880
00007531fdbced68  jmp 0x00007531FDBCEA6C
00007531fdbced6d  int3
00007531fdbced6e  nop
00007531fdbced70  mov rax, [r15]
00007531fdbced73  lea r14, [rax+0x20]
00007531fdbced77  mov r12, [r13+r14*1]
00007531fdbced7c  mov r14, [r15+0x10]
00007531fdbced80  lea r11, [r12+r14*1]
00007531fdbced84  mov [r15+0x40], r11
00007531fdbced88  lea r12, [rax+0x20]
00007531fdbced8c  mov [r13+r12*1], r11
00007531fdbced91  test r14, r14
00007531fdbced94  setz r14b
00007531fdbced98  movzx r14, r14b
00007531fdbced9c  mov [rsp+0x414], r14b
00007531fdbceda4  cmp byte ptr [rsp+0x414], 0x00
00007531fdbcedac  jz 0x00007531FDBCEDDE
00007531fdbcedae  cmp dword ptr [r15+0x318], 0x00
00007531fdbcedb6  mov eax, 0x4109A0
00007531fdbcedbb  mov [r15+0x100], rax
00007531fdbcedc2  jz 0x00007531FD9FE0A0
00007531fdbcedc8  nop [rax+rax*1], eax
00007531fdbcedcd  mov eax, 0x4109A0
00007531fdbcedd2  mov [r15+0x100], rax
00007531fdbcedd9  jmp 0x00007531FD9FE110
00007531fdbcedde  cmp dword ptr [r15+0x318], 0x00
00007531fdbcede6  jz 0x00007531FDBCEE30
00007531fdbcedec  nop [rax+rax*1], ax
00007531fdbcedf5  nop [rax+rax*1], eax
00007531fdbcedfd  mov eax, 0x410738
00007531fdbcee02  mov [r15+0x100], rax
00007531fdbcee09  jmp 0x00007531FD9FE110
00007531fdbcee0e  int3
00007531fdbcee0f  call 0x00007531FDAE27E0
00007531fdbcee14  jmp 0x00007531FDBCED7C
00007531fdbcee19  call 0x00007531FDAC0860
00007531fdbcee1e  jmp 0x00007531FDBCED91
00007531fdbcee23  int3
00007531fdbcee24  nop [rax+rax*1], ax
00007531fdbcee2d  nop [rax], eax
00007531fdbcee30  mov rax, [r15+0xF8]
00007531fdbcee37  lea r14, [rax-0x150]
00007531fdbcee3e  mov [r15+0xF8], r14
00007531fdbcee45  mov rax, [r15]
00007531fdbcee48  lea r12, [rax+0x68]
00007531fdbcee4c  mov r11, [r13+r12*1]
00007531fdbcee51  mov [r15+0x88], r11
00007531fdbcee58  lea r12, [rax+0x28]
00007531fdbcee5c  mov [r15+0x40], r12
00007531fdbcee60  mov [r15+0x48], r14
00007531fdbcee64  mov qword ptr [r15+0x50], 0x420B90
00007531fdbcee6c  lea rax, [r14+0x100]
00007531fdbcee73  mov r12, [r15+0xE8]
00007531fdbcee7a  mov r11, [r15+0xD8]
00007531fdbcee81  mov [r13+rax*1], r12
00007531fdbcee86  lea rax, [r14+0x108]
00007531fdbcee8d  mov [r13+rax*1], r11
00007531fdbcee92  lea rax, [r14+0x110]
00007531fdbcee99  mov r12, [r15+0xD0]
00007531fdbceea0  mov r11, [r15+0xC8]
00007531fdbceea7  mov [r13+rax*1], r12
00007531fdbceeac  lea rax, [r14+0x118]
00007531fdbceeb3  mov [r13+rax*1], r11
00007531fdbceeb8  lea rax, [r14+0x120]
00007531fdbceebf  mov r12, [r15+0xC0]
00007531fdbceec6  mov r11, [r15+0xB8]
00007531fdbceecd  mov [r13+rax*1], r12
00007531fdbceed2  lea rax, [r14+0x128]
00007531fdbceed9  mov [r13+rax*1], r11
00007531fdbceede  lea rax, [r14+0x130]
00007531fdbceee5  mov r12, [r15+0xB0]
00007531fdbceeec  mov r11, [r15+0xA8]
00007531fdbceef3  mov [r13+rax*1], r12
00007531fdbceef8  lea rax, [r14+0x138]
00007531fdbceeff  mov [r13+rax*1], r11
00007531fdbcef04  lea rax, [r14+0x140]
00007531fdbcef0b  mov r12, [r15+0xA0]
00007531fdbcef12  mov r11, [r15+0x98]
00007531fdbcef19  mov [r13+rax*1], r12
00007531fdbcef1e  lea rax, [r14+0x148]
00007531fdbcef25  mov [r13+rax*1], r11
00007531fdbcef2a  cmp dword ptr [r15+0x318], 0x00
00007531fdbcef32  jz 0x00007531FDBCEFD0
00007531fdbcef38  nop [rax+rax*1], ax
00007531fdbcef41  nop [rax+rax*1], eax
00007531fdbcef49  mov eax, 0x410770
00007531fdbcef4e  mov [r15+0x100], rax
00007531fdbcef55  jmp 0x00007531FD9FE110
00007531fdbcef5a  int3
00007531fdbcef5b  call 0x00007531FDAC0370
00007531fdbcef60  jmp 0x00007531FDBCEE51
00007531fdbcef65  call 0x00007531FDA0BC20
00007531fdbcef6a  jmp 0x00007531FDBCEE86
00007531fdbcef6f  call 0x00007531FDA0A9A0
00007531fdbcef74  jmp 0x00007531FDBCEE92
00007531fdbcef79  call 0x00007531FDA0BC20
00007531fdbcef7e  jmp 0x00007531FDBCEEAC
00007531fdbcef83  call 0x00007531FDA0A9A0
00007531fdbcef88  jmp 0x00007531FDBCEEB8
00007531fdbcef8d  call 0x00007531FDA0BC20
00007531fdbcef92  jmp 0x00007531FDBCEED2
00007531fdbcef97  call 0x00007531FDA0A9A0
00007531fdbcef9c  jmp 0x00007531FDBCEEDE
00007531fdbcefa1  call 0x00007531FDA0BC20
00007531fdbcefa6  jmp 0x00007531FDBCEEF8
00007531fdbcefab  call 0x00007531FDA0A9A0
00007531fdbcefb0  jmp 0x00007531FDBCEF04
00007531fdbcefb5  call 0x00007531FDA0BC20
00007531fdbcefba  jmp 0x00007531FDBCEF1E
00007531fdbcefbf  call 0x00007531FDA0A9A0
00007531fdbcefc4  jmp 0x00007531FDBCEF2A
00007531fdbcefc9  int3
00007531fdbcefca  nop [rax+rax*1], ax
00007531fdbcefd0  mov rax, [r15+0x08]
00007531fdbcefd4  movzx r14d, byte ptr [r13+rax*1]
00007531fdbcefda  movzx r14d, r14b
00007531fdbcefde  mov [rsp+0x10], r14d
00007531fdbcefe3  mov r14d, r14d
00007531fdbcefe6  mov [r15+0x58], r14
00007531fdbcefea  lea r14, [rax+0x01]
00007531fdbcefee  mov [r15+0x08], r14
00007531fdbceff2  mov rax, [r15+0x88]
00007531fdbceff9  lea r14, [rax+0x01]
00007531fdbceffd  mov r12, [r15]
00007531fdbcf000  lea r11, [r12+0x68]
00007531fdbcf005  mov [r13+r11*1], r14
00007531fdbcf00a  lea r14, [r12+rax*1]
00007531fdbcf00e  mov [r15+0x60], r14
00007531fdbcf012  lea rax, [r14+0x28]
00007531fdbcf016  mov r11d, [rsp+0x10]
00007531fdbcf01b  movzx r14d, r11b
00007531fdbcf01f  mov [r13+rax*1], r14b
00007531fdbcf024  lea rax, [r12+0x68]
00007531fdbcf029  mov r14, [r13+rax*1]
00007531fdbcf02e  mov [r15+0x88], r14
00007531fdbcf035  xor eax, eax
00007531fdbcf037  mov r12d, 0x40
00007531fdbcf03d  cmp r14, r12
00007531fdbcf040  cmc
00007531fdbcf041  lahf
00007531fdbcf042  seto al
00007531fdbcf045  mov [r15+0x108], eax
00007531fdbcf04c  mov eax, [r15+0x108]
00007531fdbcf053  sahf
00007531fdbcf054  jnz 0x00007531FDBCF086
00007531fdbcf056  cmp dword ptr [r15+0x318], 0x00
00007531fdbcf05e  jz 0x00007531FDBCF170
00007531fdbcf064  nop [rax+rax*1], ax
00007531fdbcf06d  nop [rax+rax*1], eax
00007531fdbcf075  mov eax, 0x410790
00007531fdbcf07a  mov [r15+0x100], rax
00007531fdbcf081  jmp 0x00007531FD9FE110
00007531fdbcf086  cmp dword ptr [r15+0x318], 0x00
00007531fdbcf08e  jz 0x00007531FDBCF0E0
00007531fdbcf094  nop [rax+rax*1], ax
00007531fdbcf09d  nop [rax+rax*1], eax
00007531fdbcf0a5  mov eax, 0x410768
00007531fdbcf0aa  mov [r15+0x100], rax
00007531fdbcf0b1  jmp 0x00007531FD9FE110
00007531fdbcf0b6  int3
00007531fdbcf0b7  call 0x00007531FDA0D860
00007531fdbcf0bc  jmp 0x00007531FDBCEFDA
00007531fdbcf0c1  call 0x00007531FDAB36E0
00007531fdbcf0c6  jmp 0x00007531FDBCF00A
00007531fdbcf0cb  call 0x00007531FDA0DD60
00007531fdbcf0d0  jmp 0x00007531FDBCF024
00007531fdbcf0d5  call 0x00007531FDA0DC20
00007531fdbcf0da  jmp 0x00007531FDBCF02E
00007531fdbcf0df  int3
00007531fdbcf0e0  mov rax, [r15+0x10]
00007531fdbcf0e4  lea r14, [rax-0x01]
00007531fdbcf0e8  mov [r15+0x10], r14
00007531fdbcf0ec  test r14, r14
00007531fdbcf0ef  setz r14b
00007531fdbcf0f3  movzx r14, r14b
00007531fdbcf0f7  mov [rsp+0x414], r14b
00007531fdbcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007531fdbcf107  jz 0x00007531FDBCF139
00007531fdbcf109  cmp dword ptr [r15+0x318], 0x00
00007531fdbcf111  jz 0x00007531FDBD0670
00007531fdbcf117  nop [rax+rax*1], ax
00007531fdbcf120  nop [rax+rax*1], eax
00007531fdbcf128  mov eax, 0x410988
00007531fdbcf12d  mov [r15+0x100], rax
00007531fdbcf134  jmp 0x00007531FD9FE110
00007531fdbcf139  cmp dword ptr [r15+0x318], 0x00
00007531fdbcf141  jz 0x00007531FDBCEFD0
00007531fdbcf147  nop [rax+rax*1], ax
00007531fdbcf150  nop [rax+rax*1], eax
00007531fdbcf158  mov eax, 0x410770
00007531fdbcf15d  mov [r15+0x100], rax
00007531fdbcf164  jmp 0x00007531FD9FE110
00007531fdbcf169  int3
00007531fdbcf16a  int3
00007531fdbcf16b  nop [rax+rax*1], eax
00007531fdbcf170  mov rax, [r15+0x40]
00007531fdbcf174  movzx r14d, byte ptr [r13+rax*1]
00007531fdbcf17a  movaps xmm1, [r15+0x110]
00007531fdbcf182  pinsrb xmm1, r14d, 0x00
00007531fdbcf189  lea r14, [rax+0x01]
00007531fdbcf18d  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf193  movaps xmm15, [r15+0x120]
00007531fdbcf19b  pinsrb xmm15, r12d, 0x00
00007531fdbcf1a2  lea r14, [rax+0x02]
00007531fdbcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf1ac  movaps xmm14, [r15+0x130]
00007531fdbcf1b4  pinsrb xmm14, r12d, 0x00
00007531fdbcf1bb  lea r14, [rax+0x03]
00007531fdbcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf1c5  movaps xmm13, [r15+0x140]
00007531fdbcf1cd  pinsrb xmm13, r12d, 0x00
00007531fdbcf1d4  lea r14, [rax+0x04]
00007531fdbcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf1de  pinsrb xmm1, r12d, 0x01
00007531fdbcf1e5  lea r14, [rax+0x05]
00007531fdbcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf1ef  pinsrb xmm15, r12d, 0x01
00007531fdbcf1f6  lea r14, [rax+0x06]
00007531fdbcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf200  pinsrb xmm14, r12d, 0x01
00007531fdbcf207  lea r14, [rax+0x07]
00007531fdbcf20b  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf211  pinsrb xmm13, r12d, 0x01
00007531fdbcf218  lea r14, [rax+0x08]
00007531fdbcf21c  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf222  pinsrb xmm1, r12d, 0x02
00007531fdbcf229  lea r14, [rax+0x09]
00007531fdbcf22d  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf233  pinsrb xmm15, r12d, 0x02
00007531fdbcf23a  lea r14, [rax+0x0A]
00007531fdbcf23e  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf244  pinsrb xmm14, r12d, 0x02
00007531fdbcf24b  lea r14, [rax+0x0B]
00007531fdbcf24f  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf255  pinsrb xmm13, r12d, 0x02
00007531fdbcf25c  lea r14, [rax+0x0C]
00007531fdbcf260  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf266  pinsrb xmm1, r12d, 0x03
00007531fdbcf26d  lea r14, [rax+0x0D]
00007531fdbcf271  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf277  pinsrb xmm15, r12d, 0x03
00007531fdbcf27e  lea r14, [rax+0x0E]
00007531fdbcf282  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf288  pinsrb xmm14, r12d, 0x03
00007531fdbcf28f  lea r14, [rax+0x0F]
00007531fdbcf293  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf299  pinsrb xmm13, r12d, 0x03
00007531fdbcf2a0  lea r14, [rax+0x10]
00007531fdbcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf2aa  pinsrb xmm1, r12d, 0x04
00007531fdbcf2b1  lea r14, [rax+0x11]
00007531fdbcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf2bb  pinsrb xmm15, r12d, 0x04
00007531fdbcf2c2  lea r14, [rax+0x12]
00007531fdbcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf2cc  pinsrb xmm14, r12d, 0x04
00007531fdbcf2d3  lea r14, [rax+0x13]
00007531fdbcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf2dd  pinsrb xmm13, r12d, 0x04
00007531fdbcf2e4  lea r14, [rax+0x14]
00007531fdbcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf2ee  pinsrb xmm1, r12d, 0x05
00007531fdbcf2f5  lea r14, [rax+0x15]
00007531fdbcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf2ff  pinsrb xmm15, r12d, 0x05
00007531fdbcf306  lea r14, [rax+0x16]
00007531fdbcf30a  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf310  pinsrb xmm14, r12d, 0x05
00007531fdbcf317  lea r14, [rax+0x17]
00007531fdbcf31b  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf321  pinsrb xmm13, r12d, 0x05
00007531fdbcf328  lea r14, [rax+0x18]
00007531fdbcf32c  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf332  pinsrb xmm1, r12d, 0x06
00007531fdbcf339  lea r14, [rax+0x19]
00007531fdbcf33d  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf343  pinsrb xmm15, r12d, 0x06
00007531fdbcf34a  lea r14, [rax+0x1A]
00007531fdbcf34e  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf354  pinsrb xmm14, r12d, 0x06
00007531fdbcf35b  lea r14, [rax+0x1B]
00007531fdbcf35f  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf365  pinsrb xmm13, r12d, 0x06
00007531fdbcf36c  lea r14, [rax+0x1C]
00007531fdbcf370  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf376  pinsrb xmm1, r12d, 0x07
00007531fdbcf37d  lea r14, [rax+0x1D]
00007531fdbcf381  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf387  pinsrb xmm15, r12d, 0x07
00007531fdbcf38e  lea r14, [rax+0x1E]
00007531fdbcf392  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf398  pinsrb xmm14, r12d, 0x07
00007531fdbcf39f  lea r14, [rax+0x1F]
00007531fdbcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf3a9  pinsrb xmm13, r12d, 0x07
00007531fdbcf3b0  lea r14, [rax+0x20]
00007531fdbcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf3ba  pinsrb xmm1, r12d, 0x08
00007531fdbcf3c1  lea r14, [rax+0x21]
00007531fdbcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf3cb  pinsrb xmm15, r12d, 0x08
00007531fdbcf3d2  lea r14, [rax+0x22]
00007531fdbcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf3dc  pinsrb xmm14, r12d, 0x08
00007531fdbcf3e3  lea r14, [rax+0x23]
00007531fdbcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf3ed  pinsrb xmm13, r12d, 0x08
00007531fdbcf3f4  lea r14, [rax+0x24]
00007531fdbcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf3fe  pinsrb xmm1, r12d, 0x09
00007531fdbcf405  lea r14, [rax+0x25]
00007531fdbcf409  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf40f  pinsrb xmm15, r12d, 0x09
00007531fdbcf416  lea r14, [rax+0x26]
00007531fdbcf41a  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf420  pinsrb xmm14, r12d, 0x09
00007531fdbcf427  lea r14, [rax+0x27]
00007531fdbcf42b  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf431  pinsrb xmm13, r12d, 0x09
00007531fdbcf438  lea r14, [rax+0x28]
00007531fdbcf43c  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf442  pinsrb xmm1, r12d, 0x0A
00007531fdbcf449  lea r14, [rax+0x29]
00007531fdbcf44d  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf453  pinsrb xmm15, r12d, 0x0A
00007531fdbcf45a  lea r14, [rax+0x2A]
00007531fdbcf45e  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf464  pinsrb xmm14, r12d, 0x0A
00007531fdbcf46b  lea r14, [rax+0x2B]
00007531fdbcf46f  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf475  pinsrb xmm13, r12d, 0x0A
00007531fdbcf47c  lea r14, [rax+0x2C]
00007531fdbcf480  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf486  pinsrb xmm1, r12d, 0x0B
00007531fdbcf48d  lea r14, [rax+0x2D]
00007531fdbcf491  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf497  pinsrb xmm15, r12d, 0x0B
00007531fdbcf49e  lea r14, [rax+0x2E]
00007531fdbcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf4a8  pinsrb xmm14, r12d, 0x0B
00007531fdbcf4af  lea r14, [rax+0x2F]
00007531fdbcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf4b9  pinsrb xmm13, r12d, 0x0B
00007531fdbcf4c0  lea r14, [rax+0x30]
00007531fdbcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf4ca  pinsrb xmm1, r12d, 0x0C
00007531fdbcf4d1  lea r14, [rax+0x31]
00007531fdbcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf4db  pinsrb xmm15, r12d, 0x0C
00007531fdbcf4e2  lea r14, [rax+0x32]
00007531fdbcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf4ec  pinsrb xmm14, r12d, 0x0C
00007531fdbcf4f3  lea r14, [rax+0x33]
00007531fdbcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf4fd  pinsrb xmm13, r12d, 0x0C
00007531fdbcf504  lea r14, [rax+0x34]
00007531fdbcf508  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf50e  pinsrb xmm1, r12d, 0x0D
00007531fdbcf515  lea r14, [rax+0x35]
00007531fdbcf519  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf51f  pinsrb xmm15, r12d, 0x0D
00007531fdbcf526  lea r14, [rax+0x36]
00007531fdbcf52a  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf530  pinsrb xmm14, r12d, 0x0D
00007531fdbcf537  lea r14, [rax+0x37]
00007531fdbcf53b  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf541  pinsrb xmm13, r12d, 0x0D
00007531fdbcf548  lea r14, [rax+0x38]
00007531fdbcf54c  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf552  pinsrb xmm1, r12d, 0x0E
00007531fdbcf559  lea r14, [rax+0x39]
00007531fdbcf55d  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf563  pinsrb xmm15, r12d, 0x0E
00007531fdbcf56a  lea r14, [rax+0x3A]
00007531fdbcf56e  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf574  pinsrb xmm14, r12d, 0x0E
00007531fdbcf57b  lea r14, [rax+0x3B]
00007531fdbcf57f  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf585  pinsrb xmm13, r12d, 0x0E
00007531fdbcf58c  lea r14, [rax+0x3C]
00007531fdbcf590  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf596  pinsrb xmm1, r12d, 0x0F
00007531fdbcf59d  movaps [r15+0x110], xmm1
00007531fdbcf5a5  lea r14, [rax+0x3D]
00007531fdbcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf5af  pinsrb xmm15, r12d, 0x0F
00007531fdbcf5b6  movaps [r15+0x120], xmm15
00007531fdbcf5be  lea r14, [rax+0x3E]
00007531fdbcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007531fdbcf5c8  pinsrb xmm14, r12d, 0x0F
00007531fdbcf5cf  movaps [r15+0x130], xmm14
00007531fdbcf5d7  lea r14, [rax+0x3F]
00007531fdbcf5db  movzx eax, byte ptr [r13+r14*1]
00007531fdbcf5e1  pinsrb xmm13, eax, 0x0F
00007531fdbcf5e8  movaps [r15+0x140], xmm13
00007531fdbcf5f0  movq xmm1, qword ptr [r15+0x120]
00007531fdbcf5f9  pmovzxbw xmm1, xmm1
00007531fdbcf5fe  psllw xmm1, 0x00
00007531fdbcf603  movaps [r15+0x150], xmm1
00007531fdbcf60b  movq xmm1, qword ptr [r15+0x130]
00007531fdbcf614  pmovzxbw xmm1, xmm1
00007531fdbcf619  psllw xmm1, 0x00
00007531fdbcf61e  movaps [r15+0x160], xmm1
00007531fdbcf626  movq xmm1, qword ptr [r15+0x110]
00007531fdbcf62f  pmovzxbw xmm1, xmm1
00007531fdbcf634  psllw xmm1, 0x00
00007531fdbcf639  movaps [r15+0x170], xmm1
00007531fdbcf641  movaps xmm15, [r15+0x110]
00007531fdbcf649  pextrq rax, xmm15, 0x01
00007531fdbcf650  movq xmm15, rax
00007531fdbcf655  pmovzxbw xmm15, xmm15
00007531fdbcf65b  psllw xmm15, 0x00
00007531fdbcf661  movaps [r15+0x180], xmm15
00007531fdbcf669  movaps xmm14, [r15+0x120]
00007531fdbcf671  pextrq rax, xmm14, 0x01
00007531fdbcf678  movq xmm14, rax
00007531fdbcf67d  pmovzxbw xmm14, xmm14
00007531fdbcf683  psllw xmm14, 0x00
00007531fdbcf689  movaps [r15+0x210], xmm14
00007531fdbcf691  movaps xmm13, [r15+0x130]
00007531fdbcf699  pextrq rax, xmm13, 0x01
00007531fdbcf6a0  movq xmm13, rax
00007531fdbcf6a5  pmovzxbw xmm13, xmm13
00007531fdbcf6ab  psllw xmm13, 0x00
00007531fdbcf6b1  movaps [r15+0x220], xmm13
00007531fdbcf6b9  movq xmm12, qword ptr [r15+0x140]
00007531fdbcf6c2  pmovzxbw xmm12, xmm12
00007531fdbcf6c8  psllw xmm12, 0x00
00007531fdbcf6ce  movaps [r15+0x250], xmm12
00007531fdbcf6d6  movaps xmm12, [r15+0x140]
00007531fdbcf6de  pextrq rax, xmm12, 0x01
00007531fdbcf6e5  movq xmm12, rax
00007531fdbcf6ea  pmovzxbw xmm12, xmm12
00007531fdbcf6f0  psllw xmm12, 0x00
00007531fdbcf6f6  movaps [r15+0x110], xmm12
00007531fdbcf6fe  movq xmm11, qword ptr [r15+0x150]
00007531fdbcf707  pmovzxwd xmm11, xmm11
00007531fdbcf70d  pslld xmm11, 0x10
00007531fdbcf713  movq xmm10, qword ptr [r15+0x160]
00007531fdbcf71c  pmovzxwd xmm10, xmm10
00007531fdbcf722  pslld xmm10, 0x08
00007531fdbcf728  pextrq rax, xmm1, 0x01
00007531fdbcf72f  movq xmm1, rax
00007531fdbcf734  pmovzxwd xmm1, xmm1
00007531fdbcf739  pslld xmm1, 0x00
00007531fdbcf73e  movaps [r15+0x260], xmm1
00007531fdbcf746  pextrq rax, xmm15, 0x01
00007531fdbcf74d  movq xmm15, rax
00007531fdbcf752  pmovzxwd xmm15, xmm15
00007531fdbcf758  pslld xmm15, 0x00
00007531fdbcf75e  movaps [r15+0x270], xmm15
00007531fdbcf766  movq xmm9, qword ptr [r15+0x170]
00007531fdbcf76f  pmovzxwd xmm9, xmm9
00007531fdbcf775  pslld xmm9, 0x00
00007531fdbcf77b  pextrq rax, xmm14, 0x01
00007531fdbcf782  movq xmm14, rax
00007531fdbcf787  pmovzxwd xmm14, xmm14
00007531fdbcf78d  pslld xmm14, 0x10
00007531fdbcf793  movaps [r15+0x280], xmm14
00007531fdbcf79b  movq xmm8, qword ptr [r15+0x180]
00007531fdbcf7a4  pmovzxwd xmm8, xmm8
00007531fdbcf7aa  pslld xmm8, 0x00
00007531fdbcf7b0  movq xmm7, qword ptr [r15+0x210]
00007531fdbcf7b9  pmovzxwd xmm7, xmm7
00007531fdbcf7be  pslld xmm7, 0x10
00007531fdbcf7c3  movaps xmm6, [r15+0x150]
00007531fdbcf7cb  pextrq rax, xmm6, 0x01
00007531fdbcf7d2  movq xmm6, rax
00007531fdbcf7d7  pmovzxwd xmm6, xmm6
00007531fdbcf7dc  pslld xmm6, 0x10
00007531fdbcf7e1  por xmm11, xmm10
00007531fdbcf7e6  movaps [r15+0x230], xmm11
00007531fdbcf7ee  pextrq rax, xmm13, 0x01
00007531fdbcf7f5  movq xmm13, rax
00007531fdbcf7fa  pmovzxwd xmm13, xmm13
00007531fdbcf800  pslld xmm13, 0x08
00007531fdbcf806  movaps [r15+0x240], xmm13
00007531fdbcf80e  movq xmm10, qword ptr [r15+0x220]
00007531fdbcf817  pmovzxwd xmm10, xmm10
00007531fdbcf81d  pslld xmm10, 0x08
00007531fdbcf823  movaps xmm5, [r15+0x160]
00007531fdbcf82b  pextrq rax, xmm5, 0x01
00007531fdbcf832  movq xmm5, rax
00007531fdbcf837  pmovzxwd xmm5, xmm5
00007531fdbcf83c  pslld xmm5, 0x08
00007531fdbcf841  pslld xmm9, 0x18
00007531fdbcf847  pslld xmm15, 0x18
00007531fdbcf84d  pslld xmm8, 0x18
00007531fdbcf853  movq xmm4, qword ptr [r15+0x250]
00007531fdbcf85c  pmovzxwd xmm4, xmm4
00007531fdbcf861  pslld xmm4, 0x00
00007531fdbcf866  por xmm14, xmm13
00007531fdbcf86b  por xmm7, xmm10
00007531fdbcf870  movaps [r15+0x210], xmm7
00007531fdbcf878  pslld xmm1, 0x18
00007531fdbcf87d  movaps [r15+0x220], xmm1
00007531fdbcf885  por xmm6, xmm5
00007531fdbcf889  por xmm11, xmm9
00007531fdbcf88e  movaps [r15+0x160], xmm11
00007531fdbcf896  pextrq rax, xmm12, 0x01
00007531fdbcf89d  movq xmm13, rax
00007531fdbcf8a2  pmovzxwd xmm13, xmm13
00007531fdbcf8a8  pslld xmm13, 0x00
00007531fdbcf8ae  movaps [r15+0x170], xmm13
00007531fdbcf8b6  movq xmm12, qword ptr [r15+0x110]
00007531fdbcf8bf  pmovzxwd xmm12, xmm12
00007531fdbcf8c5  pslld xmm12, 0x00
00007531fdbcf8cb  por xmm14, xmm15
00007531fdbcf8d0  por xmm7, xmm8
00007531fdbcf8d5  movaps xmm15, [r15+0x250]
00007531fdbcf8dd  pextrq rax, xmm15, 0x01
00007531fdbcf8e4  movq xmm15, rax
00007531fdbcf8e9  pmovzxwd xmm15, xmm15
00007531fdbcf8ef  pslld xmm15, 0x00
00007531fdbcf8f5  movaps [r15+0x180], xmm15
00007531fdbcf8fd  por xmm6, xmm1
00007531fdbcf901  movaps [r15+0x150], xmm6
00007531fdbcf909  por xmm11, xmm4
00007531fdbcf90e  movaps [r15+0x140], xmm11
00007531fdbcf916  por xmm7, xmm12
00007531fdbcf91b  movaps [r15+0x110], xmm7
00007531fdbcf923  por xmm14, xmm13
00007531fdbcf928  movaps [r15+0x120], xmm14
00007531fdbcf930  por xmm6, xmm15
00007531fdbcf935  movaps [r15+0x130], xmm6
00007531fdbcf93d  mov rax, [r15+0xF8]
00007531fdbcf944  lea r14, [rax+0x20]
00007531fdbcf948  movups [r13+r14*1], xmm7
00007531fdbcf94e  lea r14, [rax+0x30]
00007531fdbcf952  movups [r13+r14*1], xmm14
00007531fdbcf958  movups [r13+rax*1], xmm11
00007531fdbcf95e  lea r14, [rax+0x10]
00007531fdbcf962  movups [r13+r14*1], xmm6
00007531fdbcf968  mov r14d, [r13+rax*1]
00007531fdbcf96d  mov rax, [r15+0x48]
00007531fdbcf971  mov [r15+0x68], rax
00007531fdbcf975  mov qword ptr [r15+0x58], 0x04
00007531fdbcf97d  lea r12, [rax+0x04]
00007531fdbcf981  mov r11d, [r13+r12*1]
00007531fdbcf986  mov [rsp+0x10], r11d
00007531fdbcf98b  mov r11d, r11d
00007531fdbcf98e  mov [r15+0x70], r11
00007531fdbcf992  lea r12, [rax+0x38]
00007531fdbcf996  mov r11d, [r13+r12*1]
00007531fdbcf99b  lea r12, [rax+0x24]
00007531fdbcf99f  mov r10d, [r13+r12*1]
00007531fdbcf9a4  mov [rsp+0x20], r10d
00007531fdbcf9a9  mov r10d, r10d
00007531fdbcf9ac  mov [r15+0x90], r10
00007531fdbcf9b3  mov [rsp+0x30], rax
00007531fdbcf9b8  xor eax, eax
00007531fdbcf9ba  mov r12d, 0x04
00007531fdbcf9c0  mov r10d, 0xC0
00007531fdbcf9c6  cmp r12, r10
00007531fdbcf9c9  cmc
00007531fdbcf9ca  lahf
00007531fdbcf9cb  seto al
00007531fdbcf9ce  mov [r15+0x108], eax
00007531fdbcf9d5  mov eax, [rsp+0x10]
00007531fdbcf9d9  mov r12d, [rsp+0x10]
00007531fdbcf9de  shrd eax, r12d, 0x07
00007531fdbcf9e3  mov [rsp+0x10], r11d
00007531fdbcf9e8  mov r10d, [rsp+0x10]
00007531fdbcf9ed  shrd r11d, r10d, 0x11
00007531fdbcf9f2  mov r9d, [rsp+0x20]
00007531fdbcf9f7  lea r8d, [r9d+r14d*1]
00007531fdbcf9fc  rorx r14d, r12d, 0x12
00007531fdbcfa02  xor eax, r14d
00007531fdbcfa05  rorx r14d, r10d, 0x13
00007531fdbcfa0b  xor r11d, r14d
00007531fdbcfa0e  mov [rsp+0x10], r11d
00007531fdbcfa13  mov r11d, r11d
00007531fdbcfa16  mov [r15+0x88], r11
00007531fdbcfa1d  mov [rsp+0x20], r12d
00007531fdbcfa22  shr r12d, 0x03
00007531fdbcfa26  xor eax, r12d
00007531fdbcfa29  mov [rsp+0x40], eax
00007531fdbcfa2d  mov eax, eax
00007531fdbcfa2f  mov [r15+0x80], rax
00007531fdbcfa36  shr r10d, 0x0A
00007531fdbcfa3a  mov eax, [rsp+0x10]
00007531fdbcfa3e  xor eax, r10d
00007531fdbcfa41  mov [rsp+0x10], eax
00007531fdbcfa45  mov eax, eax
00007531fdbcfa47  mov [r15+0x78], rax
00007531fdbcfa4b  mov eax, [rsp+0x40]
00007531fdbcfa4f  lea r14d, [r8d+eax*1]
00007531fdbcfa54  mov eax, [rsp+0x10]
00007531fdbcfa58  lea r12d, [r14d+eax*1]
00007531fdbcfa5d  mov rax, [rsp+0x30]
00007531fdbcfa62  lea r14, [rax+0x40]
00007531fdbcfa66  mov [r13+r14*1], r12d
00007531fdbcfa6b  mov eax, [rsp+0x20]
00007531fdbcfa6f  mov eax, eax
00007531fdbcfa71  mov [r15+0x60], rax
00007531fdbcfa75  mov eax, [r15+0x108]
00007531fdbcfa7c  sahf
00007531fdbcfa7d  jnz 0x00007531FDBCFAAF
00007531fdbcfa7f  cmp dword ptr [r15+0x318], 0x00
00007531fdbcfa87  jz 0x00007531FDBCFF70
00007531fdbcfa8d  nop [rax+rax*1], ax
00007531fdbcfa96  nop [rax+rax*1], eax
00007531fdbcfa9e  mov eax, 0x41088C
00007531fdbcfaa3  mov [r15+0x100], rax
00007531fdbcfaaa  jmp 0x00007531FD9FE110
00007531fdbcfaaf  cmp dword ptr [r15+0x318], 0x00
00007531fdbcfab7  jz 0x00007531FDBCFDC0
00007531fdbcfabd  nop [rax+rax*1], ax
00007531fdbcfac6  nop [rax+rax*1], eax
00007531fdbcface  mov eax, 0x410844
00007531fdbcfad3  mov [r15+0x100], rax
00007531fdbcfada  jmp 0x00007531FD9FE110
00007531fdbcfadf  int3
00007531fdbcfae0  call 0x00007531FDA0D860
00007531fdbcfae5  jmp 0x00007531FDBCF17A
00007531fdbcfaea  call 0x00007531FDAE2420
00007531fdbcfaef  jmp 0x00007531FDBCF193
00007531fdbcfaf4  call 0x00007531FDAE2420
00007531fdbcfaf9  jmp 0x00007531FDBCF1AC
00007531fdbcfafe  call 0x00007531FDAE2420
00007531fdbcfb03  jmp 0x00007531FDBCF1C5
00007531fdbcfb08  call 0x00007531FDAE2420
00007531fdbcfb0d  jmp 0x00007531FDBCF1DE
00007531fdbcfb12  call 0x00007531FDAE2420
00007531fdbcfb17  jmp 0x00007531FDBCF1EF
00007531fdbcfb1c  call 0x00007531FDAE2420
00007531fdbcfb21  jmp 0x00007531FDBCF200
00007531fdbcfb26  call 0x00007531FDAE2420
00007531fdbcfb2b  jmp 0x00007531FDBCF211
00007531fdbcfb30  call 0x00007531FDAE2420
00007531fdbcfb35  jmp 0x00007531FDBCF222
00007531fdbcfb3a  call 0x00007531FDAE2420
00007531fdbcfb3f  jmp 0x00007531FDBCF233
00007531fdbcfb44  call 0x00007531FDAE2420
00007531fdbcfb49  jmp 0x00007531FDBCF244
00007531fdbcfb4e  call 0x00007531FDAE2420
00007531fdbcfb53  jmp 0x00007531FDBCF255
00007531fdbcfb58  call 0x00007531FDAE2420
00007531fdbcfb5d  jmp 0x00007531FDBCF266
00007531fdbcfb62  call 0x00007531FDAE2420
00007531fdbcfb67  jmp 0x00007531FDBCF277
00007531fdbcfb6c  call 0x00007531FDAE2420
00007531fdbcfb71  jmp 0x00007531FDBCF288
00007531fdbcfb76  call 0x00007531FDAE2420
00007531fdbcfb7b  jmp 0x00007531FDBCF299
00007531fdbcfb80  call 0x00007531FDAE2420
00007531fdbcfb85  jmp 0x00007531FDBCF2AA
00007531fdbcfb8a  call 0x00007531FDAE2420
00007531fdbcfb8f  jmp 0x00007531FDBCF2BB
00007531fdbcfb94  call 0x00007531FDAE2420
00007531fdbcfb99  jmp 0x00007531FDBCF2CC
00007531fdbcfb9e  call 0x00007531FDAE2420
00007531fdbcfba3  jmp 0x00007531FDBCF2DD
00007531fdbcfba8  call 0x00007531FDAE2420
00007531fdbcfbad  jmp 0x00007531FDBCF2EE
00007531fdbcfbb2  call 0x00007531FDAE2420
00007531fdbcfbb7  jmp 0x00007531FDBCF2FF
00007531fdbcfbbc  call 0x00007531FDAE2420
00007531fdbcfbc1  jmp 0x00007531FDBCF310
00007531fdbcfbc6  call 0x00007531FDAE2420
00007531fdbcfbcb  jmp 0x00007531FDBCF321
00007531fdbcfbd0  call 0x00007531FDAE2420
00007531fdbcfbd5  jmp 0x00007531FDBCF332
00007531fdbcfbda  call 0x00007531FDAE2420
00007531fdbcfbdf  jmp 0x00007531FDBCF343
00007531fdbcfbe4  call 0x00007531FDAE2420
00007531fdbcfbe9  jmp 0x00007531FDBCF354
00007531fdbcfbee  call 0x00007531FDAE2420
00007531fdbcfbf3  jmp 0x00007531FDBCF365
00007531fdbcfbf8  call 0x00007531FDAE2420
00007531fdbcfbfd  jmp 0x00007531FDBCF376
00007531fdbcfc02  call 0x00007531FDAE2420
00007531fdbcfc07  jmp 0x00007531FDBCF387
00007531fdbcfc0c  call 0x00007531FDAE2420
00007531fdbcfc11  jmp 0x00007531FDBCF398
00007531fdbcfc16  call 0x00007531FDAE2420
00007531fdbcfc1b  jmp 0x00007531FDBCF3A9
00007531fdbcfc20  call 0x00007531FDAE2420
00007531fdbcfc25  jmp 0x00007531FDBCF3BA
00007531fdbcfc2a  call 0x00007531FDAE2420
00007531fdbcfc2f  jmp 0x00007531FDBCF3CB
00007531fdbcfc34  call 0x00007531FDAE2420
00007531fdbcfc39  jmp 0x00007531FDBCF3DC
00007531fdbcfc3e  call 0x00007531FDAE2420
00007531fdbcfc43  jmp 0x00007531FDBCF3ED
00007531fdbcfc48  call 0x00007531FDAE2420
00007531fdbcfc4d  jmp 0x00007531FDBCF3FE
00007531fdbcfc52  call 0x00007531FDAE2420
00007531fdbcfc57  jmp 0x00007531FDBCF40F
00007531fdbcfc5c  call 0x00007531FDAE2420
00007531fdbcfc61  jmp 0x00007531FDBCF420
00007531fdbcfc66  call 0x00007531FDAE2420
00007531fdbcfc6b  jmp 0x00007531FDBCF431
00007531fdbcfc70  call 0x00007531FDAE2420
00007531fdbcfc75  jmp 0x00007531FDBCF442
00007531fdbcfc7a  call 0x00007531FDAE2420
00007531fdbcfc7f  jmp 0x00007531FDBCF453
00007531fdbcfc84  call 0x00007531FDAE2420
00007531fdbcfc89  jmp 0x00007531FDBCF464
00007531fdbcfc8e  call 0x00007531FDAE2420
00007531fdbcfc93  jmp 0x00007531FDBCF475
00007531fdbcfc98  call 0x00007531FDAE2420
00007531fdbcfc9d  jmp 0x00007531FDBCF486
00007531fdbcfca2  call 0x00007531FDAE2420
00007531fdbcfca7  jmp 0x00007531FDBCF497
00007531fdbcfcac  call 0x00007531FDAE2420
00007531fdbcfcb1  jmp 0x00007531FDBCF4A8
00007531fdbcfcb6  call 0x00007531FDAE2420
00007531fdbcfcbb  jmp 0x00007531FDBCF4B9
00007531fdbcfcc0  call 0x00007531FDAE2420
00007531fdbcfcc5  jmp 0x00007531FDBCF4CA
00007531fdbcfcca  call 0x00007531FDAE2420
00007531fdbcfccf  jmp 0x00007531FDBCF4DB
00007531fdbcfcd4  call 0x00007531FDAE2420
00007531fdbcfcd9  jmp 0x00007531FDBCF4EC
00007531fdbcfcde  call 0x00007531FDAE2420
00007531fdbcfce3  jmp 0x00007531FDBCF4FD
00007531fdbcfce8  call 0x00007531FDAE2420
00007531fdbcfced  jmp 0x00007531FDBCF50E
00007531fdbcfcf2  call 0x00007531FDAE2420
00007531fdbcfcf7  jmp 0x00007531FDBCF51F
00007531fdbcfcfc  call 0x00007531FDAE2420
00007531fdbcfd01  jmp 0x00007531FDBCF530
00007531fdbcfd06  call 0x00007531FDAE2420
00007531fdbcfd0b  jmp 0x00007531FDBCF541
00007531fdbcfd10  call 0x00007531FDAE2420
00007531fdbcfd15  jmp 0x00007531FDBCF552
00007531fdbcfd1a  call 0x00007531FDAE2420
00007531fdbcfd1f  jmp 0x00007531FDBCF563
00007531fdbcfd24  call 0x00007531FDAE2420
00007531fdbcfd29  jmp 0x00007531FDBCF574
00007531fdbcfd2e  call 0x00007531FDAE2420
00007531fdbcfd33  jmp 0x00007531FDBCF585
00007531fdbcfd38  call 0x00007531FDAE2420
00007531fdbcfd3d  jmp 0x00007531FDBCF596
00007531fdbcfd42  call 0x00007531FDAE2420
00007531fdbcfd47  jmp 0x00007531FDBCF5AF
00007531fdbcfd4c  call 0x00007531FDAE2420
00007531fdbcfd51  jmp 0x00007531FDBCF5C8
00007531fdbcfd56  call 0x00007531FDAD5610
00007531fdbcfd5b  jmp 0x00007531FDBCF5E1
00007531fdbcfd60  call 0x00007531FDADC580
00007531fdbcfd65  jmp 0x00007531FDBCF94E
00007531fdbcfd6a  call 0x00007531FDAE46C0
00007531fdbcfd6f  jmp 0x00007531FDBCF958
00007531fdbcfd74  call 0x00007531FDA09E90
00007531fdbcfd79  jmp 0x00007531FDBCF95E
00007531fdbcfd7e  call 0x00007531FDADB310
00007531fdbcfd83  jmp 0x00007531FDBCF968
00007531fdbcfd88  call 0x00007531FDA0DAE0
00007531fdbcfd8d  jmp 0x00007531FDBCF96D
00007531fdbcfd92  call 0x00007531FDAC0230
00007531fdbcfd97  jmp 0x00007531FDBCF986
00007531fdbcfd9c  call 0x00007531FDAC0230
00007531fdbcfda1  jmp 0x00007531FDBCF99B
00007531fdbcfda6  call 0x00007531FDABEFC0
00007531fdbcfdab  jmp 0x00007531FDBCF9A4
00007531fdbcfdb0  call 0x00007531FDAE2BA0
00007531fdbcfdb5  jmp 0x00007531FDBCFA6B
00007531fdbcfdba  int3
00007531fdbcfdbb  nop [rax+rax*1], eax
00007531fdbcfdc0  mov rax, [r15+0x48]
00007531fdbcfdc4  mov r14, [r15+0x58]
00007531fdbcfdc8  lea r12, [rax+r14*1]
00007531fdbcfdcc  mov [r15+0x68], r12
00007531fdbcfdd0  lea rax, [r14+0x04]
00007531fdbcfdd4  mov [r15+0x58], rax
00007531fdbcfdd8  lea r14, [r12+0x04]
00007531fdbcfddd  mov r11d, [r13+r14*1]
00007531fdbcfde2  mov [rsp+0x10], r11d
00007531fdbcfde7  mov r11d, r11d
00007531fdbcfdea  mov [r15+0x70], r11
00007531fdbcfdee  lea r14, [r12+0x38]
00007531fdbcfdf3  mov r11d, [r13+r14*1]
00007531fdbcfdf8  lea r14, [r12+0x24]
00007531fdbcfdfd  mov r10d, [r13+r14*1]
00007531fdbcfe02  mov [rsp+0x20], r10d
00007531fdbcfe07  mov r10d, r10d
00007531fdbcfe0a  mov [r15+0x90], r10
00007531fdbcfe11  mov [rsp+0x30], rax
00007531fdbcfe16  xor eax, eax
00007531fdbcfe18  mov r14, [rsp+0x30]
00007531fdbcfe1d  mov r10d, 0xC0
00007531fdbcfe23  cmp r14, r10
00007531fdbcfe26  cmc
00007531fdbcfe27  lahf
00007531fdbcfe28  seto al
00007531fdbcfe2b  mov [r15+0x108], eax
00007531fdbcfe32  mov eax, [rsp+0x10]
00007531fdbcfe36  mov r14d, [rsp+0x10]
00007531fdbcfe3b  shrd eax, r14d, 0x07
00007531fdbcfe40  mov [rsp+0x10], r11d
00007531fdbcfe45  mov r10d, [rsp+0x10]
00007531fdbcfe4a  shrd r11d, r10d, 0x11
00007531fdbcfe4f  mov r9d, [r15+0x60]
00007531fdbcfe53  mov r8d, [rsp+0x20]
00007531fdbcfe58  lea ebp, [r8d+r9d*1]
00007531fdbcfe5d  rorx r9d, r14d, 0x12
00007531fdbcfe63  xor eax, r9d
00007531fdbcfe66  rorx r9d, r10d, 0x13
00007531fdbcfe6c  xor r11d, r9d
00007531fdbcfe6f  mov [rsp+0x10], r11d
00007531fdbcfe74  mov r11d, r11d
00007531fdbcfe77  mov [r15+0x88], r11
00007531fdbcfe7e  mov [rsp+0x20], r14d
00007531fdbcfe83  shr r14d, 0x03
00007531fdbcfe87  xor eax, r14d
00007531fdbcfe8a  mov [rsp+0x30], eax
00007531fdbcfe8e  mov eax, eax
00007531fdbcfe90  mov [r15+0x80], rax
00007531fdbcfe97  shr r10d, 0x0A
00007531fdbcfe9b  mov eax, [rsp+0x10]
00007531fdbcfe9f  xor eax, r10d
00007531fdbcfea2  mov [rsp+0x10], eax
00007531fdbcfea6  mov eax, eax
00007531fdbcfea8  mov [r15+0x78], rax
00007531fdbcfeac  mov eax, [rsp+0x30]
00007531fdbcfeb0  lea r14d, [ebp+eax*1]
00007531fdbcfeb6  mov eax, [rsp+0x10]
00007531fdbcfeba  lea r11d, [r14d+eax*1]
00007531fdbcfebf  lea rax, [r12+0x40]
00007531fdbcfec4  mov [r13+rax*1], r11d
00007531fdbcfec9  mov eax, [rsp+0x20]
00007531fdbcfecd  mov eax, eax
00007531fdbcfecf  mov [r15+0x60], rax
00007531fdbcfed3  mov eax, [r15+0x108]
00007531fdbcfeda  sahf
00007531fdbcfedb  jnz 0x00007531FDBCFF0D
00007531fdbcfedd  cmp dword ptr [r15+0x318], 0x00
00007531fdbcfee5  jz 0x00007531FDBCFF70
00007531fdbcfeeb  nop [rax+rax*1], ax
00007531fdbcfef4  nop [rax+rax*1], eax
00007531fdbcfefc  mov eax, 0x41088C
00007531fdbcff01  mov [r15+0x100], rax
00007531fdbcff08  jmp 0x00007531FD9FE110
00007531fdbcff0d  cmp dword ptr [r15+0x318], 0x00
00007531fdbcff15  jz 0x00007531FDBCFDC0
00007531fdbcff1b  nop [rax+rax*1], ax
00007531fdbcff24  nop [rax+rax*1], eax
00007531fdbcff2c  mov eax, 0x410844
00007531fdbcff31  mov [r15+0x100], rax
00007531fdbcff38  jmp 0x00007531FD9FE110
00007531fdbcff3d  int3
00007531fdbcff3e  call 0x00007531FDAE1430
00007531fdbcff43  jmp 0x00007531FDBCFDE2
00007531fdbcff48  call 0x00007531FDAE1430
00007531fdbcff4d  jmp 0x00007531FDBCFDF8
00007531fdbcff52  call 0x00007531FDAE01C0
00007531fdbcff57  jmp 0x00007531FDBCFE02
00007531fdbcff5c  call 0x00007531FDA0A860
00007531fdbcff61  jmp 0x00007531FDBCFEC9
00007531fdbcff66  int3
00007531fdbcff67  nop [rax+rax*1], ax
00007531fdbcff70  mov rax, [r15]
00007531fdbcff73  mov r14d, [r13+rax*1]
00007531fdbcff78  lea r12, [rax+0x04]
00007531fdbcff7c  mov r11d, [r13+r12*1]
00007531fdbcff81  mov [rsp+0x10], r14d
00007531fdbcff86  mov r14d, r14d
00007531fdbcff89  mov [r15+0x78], r14
00007531fdbcff8d  mov [rsp+0x20], r11d
00007531fdbcff92  mov r11d, r11d
00007531fdbcff95  mov [r15+0x80], r11
00007531fdbcff9c  lea r14, [rax+0x08]
00007531fdbcffa0  mov r12d, [r13+r14*1]
00007531fdbcffa5  lea r14, [rax+0x0C]
00007531fdbcffa9  mov r11d, [r13+r14*1]
00007531fdbcffae  mov [rsp+0x30], r12d
00007531fdbcffb3  mov r12d, r12d
00007531fdbcffb6  mov [r15+0x70], r12
00007531fdbcffba  mov [rsp+0x40], r11d
00007531fdbcffbf  mov r11d, r11d
00007531fdbcffc2  mov [r15+0x68], r11
00007531fdbcffc6  lea r14, [rax+0x18]
00007531fdbcffca  mov r12d, [r13+r14*1]
00007531fdbcffcf  lea r14, [rax+0x1C]
00007531fdbcffd3  mov r11d, [r13+r14*1]
00007531fdbcffd8  mov [rsp+0x50], r12d
00007531fdbcffdd  mov r12d, r12d
00007531fdbcffe0  mov [r15+0x58], r12
00007531fdbcffe4  mov [rsp+0x60], r11d
00007531fdbcffe9  mov r11d, r11d
00007531fdbcffec  mov [r15+0x60], r11
00007531fdbcfff0  lea r14, [rax+0x10]
00007531fdbcfff4  mov r12d, [r13+r14*1]
00007531fdbcfff9  lea r14, [rax+0x14]
00007531fdbcfffd  mov eax, [r13+r14*1]
00007531fdbd0002  mov [rsp+0x70], r12d
00007531fdbd0007  mov r12d, r12d
00007531fdbd000a  mov [r15+0x18], r12
00007531fdbd000e  mov [rsp+0x80], eax
00007531fdbd0015  mov eax, eax
00007531fdbd0017  mov [r15+0x90], rax
00007531fdbd001e  mov eax, [rsp+0x70]
00007531fdbd0022  mov eax, eax
00007531fdbd0024  mov [r15+0x30], rax
00007531fdbd0028  mov eax, [rsp+0x50]
00007531fdbd002c  mov eax, eax
00007531fdbd002e  mov [r15+0xA0], rax
00007531fdbd0035  mov eax, [rsp+0x30]
00007531fdbd0039  mov eax, eax
00007531fdbd003b  mov [r15+0x28], rax
00007531fdbd003f  mov eax, [rsp+0x20]
00007531fdbd0043  mov eax, eax
00007531fdbd0045  mov [r15+0x98], rax
00007531fdbd004c  mov eax, [rsp+0x10]
00007531fdbd0050  mov eax, eax
00007531fdbd0052  mov [r15+0x38], rax
00007531fdbd0056  mov eax, [rsp+0x70]
00007531fdbd005a  mov r14d, [rsp+0x70]
00007531fdbd005f  shrd eax, r14d, 0x06
00007531fdbd0064  mov [rsp+0x70], r14d
00007531fdbd0069  mov r12d, [rsp+0x80]
00007531fdbd0071  and r14d, r12d
00007531fdbd0074  mov r11d, [rsp+0x10]
00007531fdbd0079  mov r10d, [rsp+0x10]
00007531fdbd007e  shrd r11d, r10d, 0x02
00007531fdbd0083  mov [rsp+0x10], r12d
00007531fdbd0088  mov r12d, r12d
00007531fdbd008b  mov [r15+0x20], r12
00007531fdbd008f  mov r12, [r15+0x50]
00007531fdbd0093  mov r9d, [r13+r12*1]
00007531fdbd0098  mov r12d, [rsp+0x50]
00007531fdbd009d  mov r8d, [rsp+0x70]
00007531fdbd00a2  andn ebp, r8d, r12d
00007531fdbd00a7  mov edi, [rsp+0x60]
00007531fdbd00ab  lea esi, [r14d+edi*1]
00007531fdbd00b0  rorx r14d, r8d, 0x0B
00007531fdbd00b6  xor eax, r14d
00007531fdbd00b9  rorx r14d, r10d, 0x0D
00007531fdbd00bf  xor r11d, r14d
00007531fdbd00c2  lea edi, [esi+ebp*1]
00007531fdbd00c6  mov r14, [r15+0x48]
00007531fdbd00ca  mov ebp, [r13+r14*1]
00007531fdbd00cf  mov r14d, [rsp+0x30]
00007531fdbd00d4  mov esi, [rsp+0x20]
00007531fdbd00d8  and r14d, esi
00007531fdbd00db  mov [rsp+0x20], r14d
00007531fdbd00e0  mov r14d, r14d
00007531fdbd00e3  mov [r15+0xD8], r14
00007531fdbd00ea  lea r14d, [edi+r9d*1]
00007531fdbd00ef  mov r9d, [rsp+0x30]
00007531fdbd00f4  xor r9d, esi
00007531fdbd00f7  rorx edi, r8d, 0x19
00007531fdbd00fd  xor eax, edi
00007531fdbd00ff  and r9d, r10d
00007531fdbd0102  rorx edi, r10d, 0x16
00007531fdbd0108  xor r11d, edi
00007531fdbd010b  mov [rsp+0x30], r11d
00007531fdbd0110  mov r11d, r11d
00007531fdbd0113  mov [r15+0xD0], r11
00007531fdbd011a  lea r11d, [r14d+ebp*1]
00007531fdbd011f  mov r10d, [rsp+0x20]
00007531fdbd0124  xor r9d, r10d
00007531fdbd0127  lea r14d, [r11d+eax*1]
00007531fdbd012c  mov qword ptr [r15+0x88], 0x04
00007531fdbd0137  mov eax, [rsp+0x30]
00007531fdbd013b  lea r11d, [r9d+eax*1]
00007531fdbd0140  mov eax, [rsp+0x40]
00007531fdbd0144  lea r10d, [r14d+eax*1]
00007531fdbd0149  mov r10d, r10d
00007531fdbd014c  mov [r15+0xB8], r10
00007531fdbd0153  xor eax, eax
00007531fdbd0155  mov r10d, 0x04
00007531fdbd015b  mov r9d, 0x100
00007531fdbd0161  cmp r10, r9
00007531fdbd0164  cmc
00007531fdbd0165  lahf
00007531fdbd0166  seto al
00007531fdbd0169  mov [r15+0x108], eax
00007531fdbd0170  lea eax, [r11d+r14d*1]
00007531fdbd0175  mov eax, eax
00007531fdbd0177  mov [r15+0xA8], rax
00007531fdbd017e  mov r12d, r12d
00007531fdbd0181  mov [r15+0xB0], r12
00007531fdbd0188  mov eax, [rsp+0x10]
00007531fdbd018c  mov eax, eax
00007531fdbd018e  mov [r15+0xC0], rax
00007531fdbd0195  mov r8d, r8d
00007531fdbd0198  mov [r15+0xC8], r8
00007531fdbd019f  mov eax, [r15+0x108]
00007531fdbd01a6  sahf
00007531fdbd01a7  jnz 0x00007531FDBD01D9
00007531fdbd01a9  cmp dword ptr [r15+0x318], 0x00
00007531fdbd01b1  jz 0x00007531FDBD04A0
00007531fdbd01b7  nop [rax+rax*1], ax
00007531fdbd01c0  nop [rax+rax*1], eax
00007531fdbd01c8  mov eax, 0x41094C
00007531fdbd01cd  mov [r15+0x100], rax
00007531fdbd01d4  jmp 0x00007531FD9FE110
00007531fdbd01d9  cmp dword ptr [r15+0x318], 0x00
00007531fdbd01e1  jz 0x00007531FDBD0270
00007531fdbd01e7  nop [rax+rax*1], ax
00007531fdbd01f0  nop [rax+rax*1], eax
00007531fdbd01f8  mov eax, 0x4108C0
00007531fdbd01fd  mov [r15+0x100], rax
00007531fdbd0204  jmp 0x00007531FD9FE110
00007531fdbd0209  int3
00007531fdbd020a  call 0x00007531FDA0DAE0
00007531fdbd020f  jmp 0x00007531FDBCFF78
00007531fdbd0214  call 0x00007531FDAC0230
00007531fdbd0219  jmp 0x00007531FDBCFF81
00007531fdbd021e  call 0x00007531FDAE26A0
00007531fdbd0223  jmp 0x00007531FDBCFFA5
00007531fdbd0228  call 0x00007531FDAE1430
00007531fdbd022d  jmp 0x00007531FDBCFFAE
00007531fdbd0232  call 0x00007531FDAE26A0
00007531fdbd0237  jmp 0x00007531FDBCFFCF
00007531fdbd023c  call 0x00007531FDAE1430
00007531fdbd0241  jmp 0x00007531FDBCFFD8
00007531fdbd0246  call 0x00007531FDAE26A0
00007531fdbd024b  jmp 0x00007531FDBCFFF9
00007531fdbd0250  call 0x00007531FDAD5890
00007531fdbd0255  jmp 0x00007531FDBD0002
00007531fdbd025a  call 0x00007531FDABDD50
00007531fdbd025f  jmp 0x00007531FDBD0098
00007531fdbd0264  call 0x00007531FDADA580
00007531fdbd0269  jmp 0x00007531FDBD00CF
00007531fdbd026e  int3
00007531fdbd026f  nop
00007531fdbd0270  mov eax, [r15+0xB8]
00007531fdbd0277  mov [rsp+0x10], eax
00007531fdbd027b  mov eax, eax
00007531fdbd027d  mov [r15+0x30], rax
00007531fdbd0281  mov eax, [r15+0xC0]
00007531fdbd0288  mov [rsp+0x20], eax
00007531fdbd028c  mov eax, eax
00007531fdbd028e  mov [r15+0xA0], rax
00007531fdbd0295  mov eax, [r15+0x28]
00007531fdbd0299  mov r14d, [r15+0x98]
00007531fdbd02a0  mov [rsp+0x30], r14d
00007531fdbd02a5  mov r14d, r14d
00007531fdbd02a8  mov [r15+0x28], r14
00007531fdbd02ac  mov r14d, [r15+0x38]
00007531fdbd02b0  mov [rsp+0x40], r14d
00007531fdbd02b5  mov r14d, r14d
00007531fdbd02b8  mov [r15+0x98], r14
00007531fdbd02bf  mov r14d, [r15+0xA8]
00007531fdbd02c6  mov [rsp+0x50], r14d
00007531fdbd02cb  mov r14d, r14d
00007531fdbd02ce  mov [r15+0x38], r14
00007531fdbd02d2  mov r14d, [rsp+0x10]
00007531fdbd02d7  mov r12d, [rsp+0x10]
00007531fdbd02dc  shrd r14d, r12d, 0x06
00007531fdbd02e1  mov r11d, [r15+0xC8]
00007531fdbd02e8  mov [rsp+0x10], r12d
00007531fdbd02ed  and r12d, r11d
00007531fdbd02f0  mov r10d, [rsp+0x50]
00007531fdbd02f5  mov r9d, [rsp+0x50]
00007531fdbd02fa  shrd r10d, r9d, 0x02
00007531fdbd02ff  mov [rsp+0x50], r11d
00007531fdbd0304  mov r11d, r11d
00007531fdbd0307  mov [r15+0x20], r11
00007531fdbd030b  mov r11, [r15+0x88]
00007531fdbd0312  mov r8, [r15+0x50]
00007531fdbd0316  lea rbp, [r8+r11*1]
00007531fdbd031a  mov r8d, [r13+rbp*1]
00007531fdbd031f  mov ebp, [rsp+0x20]
00007531fdbd0323  mov edi, [rsp+0x10]
00007531fdbd0327  andn esi, edi, ebp
00007531fdbd032c  mov edx, [r15+0xB0]
00007531fdbd0333  lea ecx, [r12d+edx*1]
00007531fdbd0338  rorx r12d, edi, 0x0B
00007531fdbd033e  xor r14d, r12d
00007531fdbd0341  rorx r12d, r9d, 0x0D
00007531fdbd0347  xor r10d, r12d
00007531fdbd034a  lea r12d, [ecx+esi*1]
00007531fdbd034f  mov rsi, [r15+0x48]
00007531fdbd0353  lea rdx, [rsi+r11*1]
00007531fdbd0357  mov esi, [r13+rdx*1]
00007531fdbd035c  mov edx, [rsp+0x30]
00007531fdbd0360  mov ecx, [rsp+0x40]
00007531fdbd0364  and edx, ecx
00007531fdbd0366  mov [rsp+0x10], edx
00007531fdbd036a  mov edx, edx
00007531fdbd036c  mov [r15+0xD8], rdx
00007531fdbd0373  lea edx, [r12d+r8d*1]
00007531fdbd0378  mov r12d, [rsp+0x30]
00007531fdbd037d  xor r12d, ecx
00007531fdbd0380  rorx r8d, edi, 0x19
00007531fdbd0386  xor r14d, r8d
00007531fdbd0389  and r12d, r9d
00007531fdbd038c  rorx r8d, r9d, 0x16
00007531fdbd0392  xor r10d, r8d
00007531fdbd0395  mov [rsp+0x20], r10d
00007531fdbd039a  mov r10d, r10d
00007531fdbd039d  mov [r15+0xD0], r10
00007531fdbd03a4  lea r10d, [edx+esi*1]
00007531fdbd03a9  mov r9d, [rsp+0x10]
00007531fdbd03ae  xor r12d, r9d
00007531fdbd03b1  lea r9d, [r10d+r14d*1]
00007531fdbd03b6  lea r14, [r11+0x04]
00007531fdbd03ba  mov [r15+0x88], r14
00007531fdbd03c1  mov r11d, [rsp+0x20]
00007531fdbd03c6  lea r10d, [r12d+r11d*1]
00007531fdbd03cb  lea r11d, [r9d+eax*1]
00007531fdbd03d0  mov r11d, r11d
00007531fdbd03d3  mov [r15+0xB8], r11
00007531fdbd03da  xor eax, eax
00007531fdbd03dc  mov r12d, 0x100
00007531fdbd03e2  cmp r14, r12
00007531fdbd03e5  cmc
00007531fdbd03e6  lahf
00007531fdbd03e7  seto al
00007531fdbd03ea  mov [r15+0x108], eax
00007531fdbd03f1  lea eax, [r10d+r9d*1]
00007531fdbd03f6  mov eax, eax
00007531fdbd03f8  mov [r15+0xA8], rax
00007531fdbd03ff  mov ebp, ebp
00007531fdbd0401  mov [r15+0xB0], rbp
00007531fdbd0408  mov eax, [rsp+0x50]
00007531fdbd040c  mov eax, eax
00007531fdbd040e  mov [r15+0xC0], rax
00007531fdbd0415  mov edi, edi
00007531fdbd0417  mov [r15+0xC8], rdi
00007531fdbd041e  mov eax, [r15+0x108]
00007531fdbd0425  sahf
00007531fdbd0426  jnz 0x00007531FDBD0458
00007531fdbd0428  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0430  jz 0x00007531FDBD04A0
00007531fdbd0436  nop [rax+rax*1], ax
00007531fdbd043f  nop [rax+rax*1], eax
00007531fdbd0447  mov eax, 0x41094C
00007531fdbd044c  mov [r15+0x100], rax
00007531fdbd0453  jmp 0x00007531FD9FE110
00007531fdbd0458  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0460  jz 0x00007531FDBD0270
00007531fdbd0466  nop [rax+rax*1], ax
00007531fdbd046f  nop [rax+rax*1], eax
00007531fdbd0477  mov eax, 0x4108C0
00007531fdbd047c  mov [r15+0x100], rax
00007531fdbd0483  jmp 0x00007531FD9FE110
00007531fdbd0488  int3
00007531fdbd0489  call 0x00007531FDA49010
00007531fdbd048e  jmp 0x00007531FDBD031F
00007531fdbd0493  call 0x00007531FDA25930
00007531fdbd0498  jmp 0x00007531FDBD035C
00007531fdbd049d  int3
00007531fdbd049e  nop
00007531fdbd04a0  mov eax, [r15+0x98]
00007531fdbd04a7  mov r14d, [r15+0x70]
00007531fdbd04ab  lea r12d, [eax+r14d*1]
00007531fdbd04b0  mov eax, [r15+0x28]
00007531fdbd04b4  mov r14d, [r15+0x68]
00007531fdbd04b8  lea r11d, [eax+r14d*1]
00007531fdbd04bd  mov qword ptr [r15+0x88], 0x00
00007531fdbd04c8  mov eax, [r15+0xA8]
00007531fdbd04cf  mov r14d, [r15+0x78]
00007531fdbd04d3  lea r10d, [eax+r14d*1]
00007531fdbd04d8  mov [rsp+0x10], r10d
00007531fdbd04dd  mov r10d, r10d
00007531fdbd04e0  mov [r15+0x78], r10
00007531fdbd04e4  mov eax, [r15+0x38]
00007531fdbd04e8  mov r14d, [r15+0x80]
00007531fdbd04ef  lea r10d, [eax+r14d*1]
00007531fdbd04f4  mov [rsp+0x20], r10d
00007531fdbd04f9  mov r10d, r10d
00007531fdbd04fc  mov [r15+0x80], r10
00007531fdbd0503  mov rax, [r15]
00007531fdbd0506  lea r14, [rax+0x08]
00007531fdbd050a  mov [r13+r14*1], r12d
00007531fdbd050f  lea r14, [rax+0x0C]
00007531fdbd0513  mov [r13+r14*1], r11d
00007531fdbd0518  mov r14d, [r15+0xB8]
00007531fdbd051f  mov r12d, [r15+0x18]
00007531fdbd0523  lea r11d, [r14d+r12d*1]
00007531fdbd0528  mov [rsp+0x30], r11d
00007531fdbd052d  mov r11d, r11d
00007531fdbd0530  mov [r15+0x68], r11
00007531fdbd0534  mov r14d, [r15+0x30]
00007531fdbd0538  mov r12d, [r15+0x90]
00007531fdbd053f  lea r11d, [r14d+r12d*1]
00007531fdbd0544  mov [rsp+0x40], r11d
00007531fdbd0549  mov r11d, r11d
00007531fdbd054c  mov [r15+0x70], r11
00007531fdbd0550  mov r14d, [r15+0x20]
00007531fdbd0554  mov r12d, [r15+0x58]
00007531fdbd0558  lea r11d, [r14d+r12d*1]
00007531fdbd055d  mov [rsp+0x50], r11d
00007531fdbd0562  mov r11d, r11d
00007531fdbd0565  mov [r15+0x58], r11
00007531fdbd0569  mov r14d, [r15+0xA0]
00007531fdbd0570  mov r12d, [r15+0x60]
00007531fdbd0574  lea r11d, [r14d+r12d*1]
00007531fdbd0579  mov [rsp+0x60], r11d
00007531fdbd057e  mov r11d, r11d
00007531fdbd0581  mov [r15+0x60], r11
00007531fdbd0585  mov r14d, [rsp+0x10]
00007531fdbd058a  mov [r13+rax*1], r14d
00007531fdbd058f  lea r14, [rax+0x04]
00007531fdbd0593  mov r12d, [rsp+0x20]
00007531fdbd0598  mov [r13+r14*1], r12d
00007531fdbd059d  lea r14, [rax+0x10]
00007531fdbd05a1  mov r12d, [rsp+0x30]
00007531fdbd05a6  mov [r13+r14*1], r12d
00007531fdbd05ab  lea r14, [rax+0x14]
00007531fdbd05af  mov r12d, [rsp+0x40]
00007531fdbd05b4  mov [r13+r14*1], r12d
00007531fdbd05b9  lea r14, [rax+0x18]
00007531fdbd05bd  mov r12d, [rsp+0x50]
00007531fdbd05c2  mov [r13+r14*1], r12d
00007531fdbd05c7  lea r14, [rax+0x1C]
00007531fdbd05cb  mov r12d, [rsp+0x60]
00007531fdbd05d0  mov [r13+r14*1], r12d
00007531fdbd05d5  lea r14, [rax+0x68]
00007531fdbd05d9  xor eax, eax
00007531fdbd05db  mov [r13+r14*1], rax
00007531fdbd05e0  cmp dword ptr [r15+0x318], 0x00
00007531fdbd05e8  jz 0x00007531FDBCF0E0
00007531fdbd05ee  nop [rax+rax*1], ax
00007531fdbd05f7  nop [rax+rax*1], eax
00007531fdbd05ff  mov eax, 0x410768
00007531fdbd0604  mov [r15+0x100], rax
00007531fdbd060b  jmp 0x00007531FD9FE110
00007531fdbd0610  int3
00007531fdbd0611  call 0x00007531FDAE2BA0
00007531fdbd0616  jmp 0x00007531FDBD050F
00007531fdbd061b  call 0x00007531FDAE1920
00007531fdbd0620  jmp 0x00007531FDBD0518
00007531fdbd0625  call 0x00007531FDA0DFE0
00007531fdbd062a  jmp 0x00007531FDBD058F
00007531fdbd062f  call 0x00007531FDAE2BA0
00007531fdbd0634  jmp 0x00007531FDBD059D
00007531fdbd0639  call 0x00007531FDAE2BA0
00007531fdbd063e  jmp 0x00007531FDBD05AB
00007531fdbd0643  call 0x00007531FDAE2BA0
00007531fdbd0648  jmp 0x00007531FDBD05B9
00007531fdbd064d  call 0x00007531FDAE2BA0
00007531fdbd0652  jmp 0x00007531FDBD05C7
00007531fdbd0657  call 0x00007531FDAE2BA0
00007531fdbd065c  jmp 0x00007531FDBD05D5
00007531fdbd0661  call 0x00007531FDAD5EB0
00007531fdbd0666  jmp 0x00007531FDBD05E0
00007531fdbd066b  int3
00007531fdbd066c  nop [rax], eax
00007531fdbd0670  mov rax, [r15+0xF8]
00007531fdbd0677  lea r14, [rax+0x140]
00007531fdbd067e  mov r12, [r13+r14*1]
00007531fdbd0683  lea r14, [rax+0x148]
00007531fdbd068a  mov r11, [r13+r14*1]
00007531fdbd068f  mov [r15+0xA0], r12
00007531fdbd0696  mov [r15+0x98], r11
00007531fdbd069d  lea r14, [rax+0x130]
00007531fdbd06a4  mov r12, [r13+r14*1]
00007531fdbd06a9  lea r14, [rax+0x138]
00007531fdbd06b0  mov r11, [r13+r14*1]
00007531fdbd06b5  mov [r15+0xB0], r12
00007531fdbd06bc  mov [r15+0xA8], r11
00007531fdbd06c3  lea r14, [rax+0x120]
00007531fdbd06ca  mov r12, [r13+r14*1]
00007531fdbd06cf  lea r14, [rax+0x128]
00007531fdbd06d6  mov r11, [r13+r14*1]
00007531fdbd06db  mov [r15+0xC0], r12
00007531fdbd06e2  mov [r15+0xB8], r11
00007531fdbd06e9  lea r14, [rax+0x110]
00007531fdbd06f0  mov r12, [r13+r14*1]
00007531fdbd06f5  lea r14, [rax+0x118]
00007531fdbd06fc  mov r11, [r13+r14*1]
00007531fdbd0701  mov [r15+0xD0], r12
00007531fdbd0708  mov [r15+0xC8], r11
00007531fdbd070f  lea r14, [rax+0x100]
00007531fdbd0716  mov r12, [r13+r14*1]
00007531fdbd071b  lea r14, [rax+0x108]
00007531fdbd0722  mov r11, [r13+r14*1]
00007531fdbd0727  mov [r15+0xE8], r12
00007531fdbd072e  mov [r15+0xD8], r11
00007531fdbd0735  lea r14, [rax+0x150]
00007531fdbd073c  mov [r15+0xF8], r14
00007531fdbd0743  mov rax, [r15+0xF0]
00007531fdbd074a  mov [r15+0x100], rax
00007531fdbd0751  jmp 0x00007531FDBCE5C0
00007531fdbd0756  int3
00007531fdbd0757  call 0x00007531FDAE27E0
00007531fdbd075c  jmp 0x00007531FDBD0683
00007531fdbd0761  call 0x00007531FDAE1570
00007531fdbd0766  jmp 0x00007531FDBD068F
00007531fdbd076b  call 0x00007531FDAE27E0
00007531fdbd0770  jmp 0x00007531FDBD06A9
00007531fdbd0775  call 0x00007531FDAE1570
00007531fdbd077a  jmp 0x00007531FDBD06B5
00007531fdbd077f  call 0x00007531FDAE27E0
00007531fdbd0784  jmp 0x00007531FDBD06CF
00007531fdbd0789  call 0x00007531FDAE1570
00007531fdbd078e  jmp 0x00007531FDBD06DB
00007531fdbd0793  call 0x00007531FDAE27E0
00007531fdbd0798  jmp 0x00007531FDBD06F5
00007531fdbd079d  call 0x00007531FDAE1570
00007531fdbd07a2  jmp 0x00007531FDBD0701
00007531fdbd07a7  call 0x00007531FDAE27E0
00007531fdbd07ac  jmp 0x00007531FDBD071B
00007531fdbd07b1  call 0x00007531FDAE1570
00007531fdbd07b6  jmp 0x00007531FDBD0727
00007531fdbd07bb  int3
00007531fdbd07bc  nop [rax], eax
00007531fdbd07c0  mov eax, [r15+0xA0]
00007531fdbd07c7  mov [rsp+0x10], eax
00007531fdbd07cb  xor eax, eax
00007531fdbd07cd  mov r14d, [rsp+0x10]
00007531fdbd07d2  sub r14d, 0x01
00007531fdbd07d6  cmc
00007531fdbd07d7  lahf
00007531fdbd07d8  seto al
00007531fdbd07db  mov [r15+0x108], eax
00007531fdbd07e2  mov r14d, r14d
00007531fdbd07e5  mov [r15+0xA0], r14
00007531fdbd07ec  mov eax, [r15+0x108]
00007531fdbd07f3  sahf
00007531fdbd07f4  jnz 0x00007531FDBD0826
00007531fdbd07f6  cmp dword ptr [r15+0x318], 0x00
00007531fdbd07fe  jz 0x00007531FDBD0900
00007531fdbd0804  nop [rax+rax*1], ax
00007531fdbd080d  nop [rax+rax*1], eax
00007531fdbd0815  mov eax, 0x41028C
00007531fdbd081a  mov [r15+0x100], rax
00007531fdbd0821  jmp 0x00007531FD9FE110
00007531fdbd0826  cmp dword ptr [r15+0x318], 0x00
00007531fdbd082e  jz 0x00007531FDBD0860
00007531fdbd0834  nop [rax+rax*1], ax
00007531fdbd083d  nop [rax+rax*1], eax
00007531fdbd0845  mov eax, 0x410274
00007531fdbd084a  mov [r15+0x100], rax
00007531fdbd0851  jmp 0x00007531FD9FE110
00007531fdbd0856  int3
00007531fdbd0857  int3
00007531fdbd0858  nop [rax+rax*1], eax
00007531fdbd0860  mov rax, [r15+0xF8]
00007531fdbd0867  lea r14, [rax+0x100]
00007531fdbd086e  mov [r15], r14
00007531fdbd0871  mov rax, [r15+0x98]
00007531fdbd0878  mov [r15+0x08], rax
00007531fdbd087c  mov qword ptr [r15+0x10], 0x12C
00007531fdbd0884  mov qword ptr [r15+0xF0], 0x410284
00007531fdbd088f  mov r14d, [r15+0x320]
00007531fdbd0896  mov eax, 0x410284
00007531fdbd089b  mov rcx, 0x7531FDBD07C0
00007531fdbd08a5  mov [r15+r14*8+0x328], rax
00007531fdbd08ad  mov [r15+r14*8+0x368], rcx
00007531fdbd08b5  add r14d, 0x01
00007531fdbd08b9  and r14d, 0x07
00007531fdbd08bd  mov [r15+0x320], r14d
00007531fdbd08c4  cmp dword ptr [r15+0x318], 0x00
00007531fdbd08cc  jz 0x00007531FDBCED70
00007531fdbd08d2  nop [rax+rax*1], ax
00007531fdbd08db  nop [rax+rax*1], eax
00007531fdbd08e3  mov eax, 0x410728
00007531fdbd08e8  mov [r15+0x100], rax
00007531fdbd08ef  jmp 0x00007531FD9FE110
00007531fdbd08f4  int3
00007531fdbd08f5  int3
00007531fdbd08f6  nop [rax+rax*1], ax
00007531fdbd08ff  nop
00007531fdbd0900  mov rax, [r15+0xF8]
00007531fdbd0907  lea r14, [rax+0x120]
00007531fdbd090e  mov r12, [r13+r14*1]
00007531fdbd0913  mov [r15+0x98], r12
00007531fdbd091a  mov qword ptr [r15+0x40], 0x80
00007531fdbd0922  lea r14, [rax+0x100]
00007531fdbd0929  mov [r15], r14
00007531fdbd092c  lea r14, [rax+0x17C]
00007531fdbd0933  mov [r15+0x08], r14
00007531fdbd0937  mov qword ptr [r15+0x10], 0x01
00007531fdbd093f  lea r14, [rax+0x17C]
00007531fdbd0946  mov eax, 0x80
00007531fdbd094b  mov [r13+r14*1], al
00007531fdbd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007531fdbd095b  mov r14d, [r15+0x320]
00007531fdbd0962  mov eax, 0x4102A8
00007531fdbd0967  mov rcx, 0x7531FDBD09E0
00007531fdbd0971  mov [r15+r14*8+0x328], rax
00007531fdbd0979  mov [r15+r14*8+0x368], rcx
00007531fdbd0981  add r14d, 0x01
00007531fdbd0985  and r14d, 0x07
00007531fdbd0989  mov [r15+0x320], r14d
00007531fdbd0990  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0998  jz 0x00007531FDBCED70
00007531fdbd099e  nop [rax+rax*1], ax
00007531fdbd09a7  nop [rax+rax*1], eax
00007531fdbd09af  mov eax, 0x410728
00007531fdbd09b4  mov [r15+0x100], rax
00007531fdbd09bb  jmp 0x00007531FD9FE110
00007531fdbd09c0  int3
00007531fdbd09c1  call 0x00007531FDAE27E0
00007531fdbd09c6  jmp 0x00007531FDBD0913
00007531fdbd09cb  call 0x00007531FDAD5AF0
00007531fdbd09d0  jmp 0x00007531FDBD0950
00007531fdbd09d5  int3
00007531fdbd09d6  nop [rax+rax*1], ax
00007531fdbd09df  nop
00007531fdbd09e0  mov rax, [r15+0xF8]
00007531fdbd09e7  lea r14, [rax+0x168]
00007531fdbd09ee  mov r12, [r13+r14*1]
00007531fdbd09f3  mov [r15+0x40], r12
00007531fdbd09f7  lea r14, [rax+0x178]
00007531fdbd09fe  xor eax, eax
00007531fdbd0a00  mov [r13+r14*1], al
00007531fdbd0a05  xor eax, eax
00007531fdbd0a07  mov r14d, 0x38
00007531fdbd0a0d  cmp r12, r14
00007531fdbd0a10  cmc
00007531fdbd0a11  lahf
00007531fdbd0a12  seto al
00007531fdbd0a15  mov [r15+0x108], eax
00007531fdbd0a1c  mov eax, [r15+0x108]
00007531fdbd0a23  sahf
00007531fdbd0a24  jz 0x00007531FDBD0A56
00007531fdbd0a26  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0a2e  jz 0x00007531FDBD0AA0
00007531fdbd0a34  nop [rax+rax*1], ax
00007531fdbd0a3d  nop [rax+rax*1], eax
00007531fdbd0a45  mov eax, 0x4102B8
00007531fdbd0a4a  mov [r15+0x100], rax
00007531fdbd0a51  jmp 0x00007531FD9FE110
00007531fdbd0a56  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0a5e  jz 0x00007531FDBD0BF0
00007531fdbd0a64  nop [rax+rax*1], ax
00007531fdbd0a6d  nop [rax+rax*1], eax
00007531fdbd0a75  mov eax, 0x4102D4
00007531fdbd0a7a  mov [r15+0x100], rax
00007531fdbd0a81  jmp 0x00007531FD9FE110
00007531fdbd0a86  int3
00007531fdbd0a87  call 0x00007531FDAE27E0
00007531fdbd0a8c  jmp 0x00007531FDBD09F3
00007531fdbd0a91  call 0x00007531FDAD5AF0
00007531fdbd0a96  jmp 0x00007531FDBD0A05
00007531fdbd0a9b  int3
00007531fdbd0a9c  nop [rax], eax
00007531fdbd0aa0  mov rax, [r15+0xF8]
00007531fdbd0aa7  lea r14, [rax+0x100]
00007531fdbd0aae  mov [r15], r14
00007531fdbd0ab1  lea r14, [rax+0x178]
00007531fdbd0ab8  mov [r15+0x08], r14
00007531fdbd0abc  mov qword ptr [r15+0x10], 0x01
00007531fdbd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007531fdbd0acf  mov r14d, [r15+0x320]
00007531fdbd0ad6  mov eax, 0x4102C8
00007531fdbd0adb  mov rcx, 0x7531FDBD0B40
00007531fdbd0ae5  mov [r15+r14*8+0x328], rax
00007531fdbd0aed  mov [r15+r14*8+0x368], rcx
00007531fdbd0af5  add r14d, 0x01
00007531fdbd0af9  and r14d, 0x07
00007531fdbd0afd  mov [r15+0x320], r14d
00007531fdbd0b04  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0b0c  jz 0x00007531FDBCED70
00007531fdbd0b12  nop [rax+rax*1], ax
00007531fdbd0b1b  nop [rax+rax*1], eax
00007531fdbd0b23  mov eax, 0x410728
00007531fdbd0b28  mov [r15+0x100], rax
00007531fdbd0b2f  jmp 0x00007531FD9FE110
00007531fdbd0b34  int3
00007531fdbd0b35  int3
00007531fdbd0b36  nop [rax+rax*1], ax
00007531fdbd0b3f  nop
00007531fdbd0b40  mov rax, [r15+0xF8]
00007531fdbd0b47  lea r14, [rax+0x168]
00007531fdbd0b4e  mov rax, [r13+r14*1]
00007531fdbd0b53  mov [r15+0x40], rax
00007531fdbd0b57  mov [rsp+0x10], rax
00007531fdbd0b5c  xor eax, eax
00007531fdbd0b5e  mov r14, [rsp+0x10]
00007531fdbd0b63  mov r12d, 0x38
00007531fdbd0b69  cmp r14, r12
00007531fdbd0b6c  cmc
00007531fdbd0b6d  lahf
00007531fdbd0b6e  seto al
00007531fdbd0b71  mov [r15+0x108], eax
00007531fdbd0b78  mov eax, [r15+0x108]
00007531fdbd0b7f  sahf
00007531fdbd0b80  jnz 0x00007531FDBD0BB2
00007531fdbd0b82  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0b8a  jz 0x00007531FDBD0BF0
00007531fdbd0b90  nop [rax+rax*1], ax
00007531fdbd0b99  nop [rax+rax*1], eax
00007531fdbd0ba1  mov eax, 0x4102D4
00007531fdbd0ba6  mov [r15+0x100], rax
00007531fdbd0bad  jmp 0x00007531FD9FE110
00007531fdbd0bb2  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0bba  jz 0x00007531FDBD0AA0
00007531fdbd0bc0  nop [rax+rax*1], ax
00007531fdbd0bc9  nop [rax+rax*1], eax
00007531fdbd0bd1  mov eax, 0x4102B8
00007531fdbd0bd6  mov [r15+0x100], rax
00007531fdbd0bdd  jmp 0x00007531FD9FE110
00007531fdbd0be2  int3
00007531fdbd0be3  call 0x00007531FDAD59C0
00007531fdbd0be8  jmp 0x00007531FDBD0B53
00007531fdbd0bed  int3
00007531fdbd0bee  nop
00007531fdbd0bf0  mov rax, [r15+0x98]
00007531fdbd0bf7  rorx r14, rax, 0x3D
00007531fdbd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007531fdbd0c01  mov rax, [r15+0xF8]
00007531fdbd0c08  lea r12, [rax+0x100]
00007531fdbd0c0f  mov [r15], r12
00007531fdbd0c12  lea r12, [rax+0x170]
00007531fdbd0c19  mov [r15+0x08], r12
00007531fdbd0c1d  mov qword ptr [r15+0x10], 0x08
00007531fdbd0c25  bswap r14
00007531fdbd0c28  mov [r15+0x40], r14
00007531fdbd0c2c  lea r12, [rax+0x170]
00007531fdbd0c33  mov [r13+r12*1], r14
00007531fdbd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007531fdbd0c43  mov r14d, [r15+0x320]
00007531fdbd0c4a  mov eax, 0x4102F0
00007531fdbd0c4f  mov rcx, 0x7531FDBD0CC0
00007531fdbd0c59  mov [r15+r14*8+0x328], rax
00007531fdbd0c61  mov [r15+r14*8+0x368], rcx
00007531fdbd0c69  add r14d, 0x01
00007531fdbd0c6d  and r14d, 0x07
00007531fdbd0c71  mov [r15+0x320], r14d
00007531fdbd0c78  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0c80  jz 0x00007531FDBCED70
00007531fdbd0c86  nop [rax+rax*1], ax
00007531fdbd0c8f  nop [rax+rax*1], eax
00007531fdbd0c97  mov eax, 0x410728
00007531fdbd0c9c  mov [r15+0x100], rax
00007531fdbd0ca3  jmp 0x00007531FD9FE110
00007531fdbd0ca8  int3
00007531fdbd0ca9  call 0x00007531FDAC3FE0
00007531fdbd0cae  jmp 0x00007531FDBD0C38
00007531fdbd0cb3  int3
00007531fdbd0cb4  nop [rax+rax*1], ax
00007531fdbd0cbd  nop [rax], eax
00007531fdbd0cc0  mov rax, [r15+0xF8]
00007531fdbd0cc7  lea r14, [rax+0x100]
00007531fdbd0cce  mov r12d, [r13+r14*1]
00007531fdbd0cd3  lea r14, [rax+0x104]
00007531fdbd0cda  mov r11d, [r13+r14*1]
00007531fdbd0cdf  mov qword ptr [r15+0x48], 0x430C90
00007531fdbd0ce7  lea r14, [rax+0x108]
00007531fdbd0cee  mov r10d, [r13+r14*1]
00007531fdbd0cf3  lea r14, [rax+0x10C]
00007531fdbd0cfa  mov r9d, [r13+r14*1]
00007531fdbd0cff  bswap r12d
00007531fdbd0d02  bswap r11d
00007531fdbd0d05  mov qword ptr [r15+0xA0], 0x00
00007531fdbd0d10  mov r14d, 0x430C90
00007531fdbd0d16  mov [r13+r14*1], r12d
00007531fdbd0d1b  mov r14d, 0x430C94
00007531fdbd0d21  mov [r13+r14*1], r11d
00007531fdbd0d26  bswap r10d
00007531fdbd0d29  lea r14, [rax+0x110]
00007531fdbd0d30  mov r12d, [r13+r14*1]
00007531fdbd0d35  bswap r9d
00007531fdbd0d38  lea r14, [rax+0x114]
00007531fdbd0d3f  mov r11d, [r13+r14*1]
00007531fdbd0d44  mov qword ptr [r15+0x98], 0x430DFC
00007531fdbd0d4f  mov r14d, 0x430C98
00007531fdbd0d55  mov [r13+r14*1], r10d
00007531fdbd0d5a  mov r14d, 0x430C9C
00007531fdbd0d60  mov [r13+r14*1], r9d
00007531fdbd0d65  bswap r12d
00007531fdbd0d68  lea r14, [rax+0x118]
00007531fdbd0d6f  mov r10d, [r13+r14*1]
00007531fdbd0d74  bswap r11d
00007531fdbd0d77  mov [rsp+0x10], r11d
00007531fdbd0d7c  mov r11d, r11d
00007531fdbd0d7f  mov [r15+0x58], r11
00007531fdbd0d83  lea r14, [rax+0x11C]
00007531fdbd0d8a  mov eax, [r13+r14*1]
00007531fdbd0d8f  mov [rsp+0x20], eax
00007531fdbd0d93  mov eax, eax
00007531fdbd0d95  mov [r15+0x60], rax
00007531fdbd0d99  mov eax, 0x430CA0
00007531fdbd0d9e  mov [r13+rax*1], r12d
00007531fdbd0da3  mov eax, 0x430CA4
00007531fdbd0da8  mov r14d, [rsp+0x10]
00007531fdbd0dad  mov [r13+rax*1], r14d
00007531fdbd0db2  bswap r10d
00007531fdbd0db5  mov [rsp+0x10], r10d
00007531fdbd0dba  mov r10d, r10d
00007531fdbd0dbd  mov [r15+0x40], r10
00007531fdbd0dc1  mov eax, [rsp+0x20]
00007531fdbd0dc5  bswap eax
00007531fdbd0dc7  mov [rsp+0x20], eax
00007531fdbd0dcb  mov eax, eax
00007531fdbd0dcd  mov [r15+0x50], rax
00007531fdbd0dd1  mov eax, 0x430CA8
00007531fdbd0dd6  mov r14d, [rsp+0x10]
00007531fdbd0ddb  mov [r13+rax*1], r14d
00007531fdbd0de0  mov eax, 0x430CAC
00007531fdbd0de5  mov r14d, [rsp+0x20]
00007531fdbd0dea  mov [r13+rax*1], r14d
00007531fdbd0def  mov eax, [r15+0xA0]
00007531fdbd0df6  lea r14d, [eax+0x11]
00007531fdbd0dfb  mov r14d, r14d
00007531fdbd0dfe  mov [r15], r14
00007531fdbd0e01  mov qword ptr [r15+0xF0], 0x41035C
00007531fdbd0e0c  mov r14d, [r15+0x320]
00007531fdbd0e13  mov eax, 0x41035C
00007531fdbd0e18  mov rcx, 0x7531FDBD0F90
00007531fdbd0e22  mov [r15+r14*8+0x328], rax
00007531fdbd0e2a  mov [r15+r14*8+0x368], rcx
00007531fdbd0e32  add r14d, 0x01
00007531fdbd0e36  and r14d, 0x07
00007531fdbd0e3a  mov [r15+0x320], r14d
00007531fdbd0e41  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0e49  jz 0x00007531FDBD0F20
00007531fdbd0e4f  nop [rax+rax*1], ax
00007531fdbd0e58  nop [rax+rax*1], eax
00007531fdbd0e60  mov eax, 0x4109A4
00007531fdbd0e65  mov [r15+0x100], rax
00007531fdbd0e6c  jmp 0x00007531FD9FE110
00007531fdbd0e71  int3
00007531fdbd0e72  call 0x00007531FDAE26A0
00007531fdbd0e77  jmp 0x00007531FDBD0CD3
00007531fdbd0e7c  call 0x00007531FDAE1430
00007531fdbd0e81  jmp 0x00007531FDBD0CDF
00007531fdbd0e86  call 0x00007531FDAE01C0
00007531fdbd0e8b  jmp 0x00007531FDBD0CF3
00007531fdbd0e90  call 0x00007531FDADEF50
00007531fdbd0e95  jmp 0x00007531FDBD0CFF
00007531fdbd0e9a  call 0x00007531FDAE2BA0
00007531fdbd0e9f  jmp 0x00007531FDBD0D1B
00007531fdbd0ea4  call 0x00007531FDAE1920
00007531fdbd0ea9  jmp 0x00007531FDBD0D26
00007531fdbd0eae  call 0x00007531FDAE26A0
00007531fdbd0eb3  jmp 0x00007531FDBD0D35
00007531fdbd0eb8  call 0x00007531FDAE1430
00007531fdbd0ebd  jmp 0x00007531FDBD0D44
00007531fdbd0ec2  call 0x00007531FDAE06B0
00007531fdbd0ec7  jmp 0x00007531FDBD0D5A
00007531fdbd0ecc  call 0x00007531FDADF440
00007531fdbd0ed1  jmp 0x00007531FDBD0D65
00007531fdbd0ed6  call 0x00007531FDAE01C0
00007531fdbd0edb  jmp 0x00007531FDBD0D74
00007531fdbd0ee0  call 0x00007531FDAD5890
00007531fdbd0ee5  jmp 0x00007531FDBD0D8F
00007531fdbd0eea  call 0x00007531FDA0BAE0
00007531fdbd0eef  jmp 0x00007531FDBD0DA3
00007531fdbd0ef4  call 0x00007531FDA0DFE0
00007531fdbd0ef9  jmp 0x00007531FDBD0DB2
00007531fdbd0efe  call 0x00007531FDA0DFE0
00007531fdbd0f03  jmp 0x00007531FDBD0DE0
00007531fdbd0f08  call 0x00007531FDA0DFE0
00007531fdbd0f0d  jmp 0x00007531FDBD0DEF
00007531fdbd0f12  int3
00007531fdbd0f13  nop [rax+rax*1], ax
00007531fdbd0f1c  nop [rax], eax
00007531fdbd0f20  mov eax, [r15]
00007531fdbd0f23  mov [rsp+0x10], eax
00007531fdbd0f27  shr eax, 0x10
00007531fdbd0f2a  mov r14d, [rsp+0x10]
00007531fdbd0f2f  xor r14d, eax
00007531fdbd0f32  imul r14d, r14d, 0x7FEB352D
00007531fdbd0f39  mov eax, 0x846CA68B
00007531fdbd0f3e  mov eax, eax
00007531fdbd0f40  mov [r15+0x48], rax
00007531fdbd0f44  mov [rsp+0x10], r14d
00007531fdbd0f49  shr r14d, 0x0F
00007531fdbd0f4d  mov eax, [rsp+0x10]
00007531fdbd0f51  xor eax, r14d
00007531fdbd0f54  imul eax, eax, 0x846CA68B
00007531fdbd0f5a  mov [rsp+0x10], eax
00007531fdbd0f5e  mov eax, eax
00007531fdbd0f60  mov [r15+0x40], rax
00007531fdbd0f64  mov eax, [rsp+0x10]
00007531fdbd0f68  shr eax, 0x10
00007531fdbd0f6b  mov r14d, [rsp+0x10]
00007531fdbd0f70  xor r14d, eax
00007531fdbd0f73  mov r14d, r14d
00007531fdbd0f76  mov [r15], r14
00007531fdbd0f79  mov rax, [r15+0xF0]
00007531fdbd0f80  mov [r15+0x100], rax
00007531fdbd0f87  jmp 0x00007531FDBCE5C0
00007531fdbd0f8c  int3
00007531fdbd0f8d  int3
00007531fdbd0f8e  nop
00007531fdbd0f90  mov rax, [r15+0xA0]
00007531fdbd0f97  mov [rsp+0x10], rax
00007531fdbd0f9c  shl rax, 0x02
00007531fdbd0fa0  mov r14, [r15+0x98]
00007531fdbd0fa7  lea r12, [r14+rax*1]
00007531fdbd0fab  mov eax, [r15]
00007531fdbd0fae  mov [r13+r12*1], eax
00007531fdbd0fb3  mov rax, [rsp+0x10]
00007531fdbd0fb8  lea r14, [rax+0x01]
00007531fdbd0fbc  mov [r15+0xA0], r14
00007531fdbd0fc3  xor eax, eax
00007531fdbd0fc5  mov r12d, 0x400
00007531fdbd0fcb  cmp r14, r12
00007531fdbd0fce  cmc
00007531fdbd0fcf  lahf
00007531fdbd0fd0  seto al
00007531fdbd0fd3  mov [r15+0x108], eax
00007531fdbd0fda  mov eax, [r15+0x108]
00007531fdbd0fe1  sahf
00007531fdbd0fe2  jnz 0x00007531FDBD1014
00007531fdbd0fe4  cmp dword ptr [r15+0x318], 0x00
00007531fdbd0fec  jz 0x00007531FDBD10E0
00007531fdbd0ff2  nop [rax+rax*1], ax
00007531fdbd0ffb  nop [rax+rax*1], eax
00007531fdbd1003  mov eax, 0x41036C
00007531fdbd1008  mov [r15+0x100], rax
00007531fdbd100f  jmp 0x00007531FD9FE110
00007531fdbd1014  cmp dword ptr [r15+0x318], 0x00
00007531fdbd101c  jz 0x00007531FDBD1050
00007531fdbd1022  nop [rax+rax*1], ax
00007531fdbd102b  nop [rax+rax*1], eax
00007531fdbd1033  mov eax, 0x410354
00007531fdbd1038  mov [r15+0x100], rax
00007531fdbd103f  jmp 0x00007531FD9FE110
00007531fdbd1044  int3
00007531fdbd1045  call 0x00007531FDAB4B70
00007531fdbd104a  jmp 0x00007531FDBD0FB3
00007531fdbd104f  int3
00007531fdbd1050  mov eax, [r15+0xA0]
00007531fdbd1057  lea r14d, [eax+0x11]
00007531fdbd105c  mov r14d, r14d
00007531fdbd105f  mov [r15], r14
00007531fdbd1062  mov qword ptr [r15+0xF0], 0x41035C
00007531fdbd106d  mov r14d, [r15+0x320]
00007531fdbd1074  mov eax, 0x41035C
00007531fdbd1079  mov rcx, 0x7531FDBD0F90
00007531fdbd1083  mov [r15+r14*8+0x328], rax
00007531fdbd108b  mov [r15+r14*8+0x368], rcx
00007531fdbd1093  add r14d, 0x01
00007531fdbd1097  and r14d, 0x07
00007531fdbd109b  mov [r15+0x320], r14d
00007531fdbd10a2  cmp dword ptr [r15+0x318], 0x00
00007531fdbd10aa  jz 0x00007531FDBD0F20
00007531fdbd10b0  nop [rax+rax*1], ax
00007531fdbd10b9  nop [rax+rax*1], eax
00007531fdbd10c1  mov eax, 0x4109A4
00007531fdbd10c6  mov [r15+0x100], rax
00007531fdbd10cd  jmp 0x00007531FD9FE110
00007531fdbd10d2  int3
00007531fdbd10d3  int3
00007531fdbd10d4  nop [rax+rax*1], ax
00007531fdbd10dd  nop [rax], eax
00007531fdbd10e0  mov qword ptr [r15+0x40], 0x01
00007531fdbd10e8  cmp dword ptr [r15+0x318], 0x00
00007531fdbd10f0  jz 0x00007531FDBD1120
00007531fdbd10f6  nop [rax+rax*1], ax
00007531fdbd10ff  nop [rax+rax*1], eax
00007531fdbd1107  mov eax, 0x410388
00007531fdbd110c  mov [r15+0x100], rax
00007531fdbd1113  jmp 0x00007531FD9FE110
00007531fdbd1118  int3
00007531fdbd1119  int3
00007531fdbd111a  nop [rax+rax*1], ax
00007531fdbd1120  mov rax, [r15+0x40]
00007531fdbd1124  mov [rsp+0x10], rax
00007531fdbd1129  shl rax, 0x02
00007531fdbd112d  mov r14, [r15+0x98]
00007531fdbd1134  lea r12, [r14+rax*1]
00007531fdbd1138  mov eax, [r13+r12*1]
00007531fdbd113d  mov [rsp+0x20], eax
00007531fdbd1141  mov eax, eax
00007531fdbd1143  mov [r15+0x48], rax
00007531fdbd1147  mov rax, [rsp+0x10]
00007531fdbd114c  mov [r15+0x50], rax
00007531fdbd1150  mov eax, [r15+0x50]
00007531fdbd1154  lea r12d, [eax-0x01]
00007531fdbd1159  mov r12d, r12d
00007531fdbd115c  mov [r15+0x58], r12
00007531fdbd1160  mov rax, [r15+0x58]
00007531fdbd1164  mov r12d, eax
00007531fdbd1167  mov r12d, r12d
00007531fdbd116a  shl r12, 0x02
00007531fdbd116e  lea rax, [r14+r12*1]
00007531fdbd1172  mov r14d, [r13+rax*1]
00007531fdbd1177  mov [rsp+0x10], r14d
00007531fdbd117c  mov r14d, r14d
00007531fdbd117f  mov [r15+0x60], r14
00007531fdbd1183  xor eax, eax
00007531fdbd1185  mov r14d, [rsp+0x10]
00007531fdbd118a  mov r12d, [rsp+0x20]
00007531fdbd118f  cmp r14d, r12d
00007531fdbd1192  cmc
00007531fdbd1193  lahf
00007531fdbd1194  seto al
00007531fdbd1197  mov [r15+0x108], eax
00007531fdbd119e  mov eax, [r15+0x108]
00007531fdbd11a5  sahf
00007531fdbd11a6  cmc
00007531fdbd11a7  jbe 0x00007531FDBD11D9
00007531fdbd11a9  cmp dword ptr [r15+0x318], 0x00
00007531fdbd11b1  jz 0x00007531FDBD1220
00007531fdbd11b7  nop [rax+rax*1], ax
00007531fdbd11c0  nop [rax+rax*1], eax
00007531fdbd11c8  mov eax, 0x4103A0
00007531fdbd11cd  mov [r15+0x100], rax
00007531fdbd11d4  jmp 0x00007531FD9FE110
00007531fdbd11d9  cmp dword ptr [r15+0x318], 0x00
00007531fdbd11e1  jz 0x00007531FDBD14C0
00007531fdbd11e7  nop [rax+rax*1], ax
00007531fdbd11f0  nop [rax+rax*1], eax
00007531fdbd11f8  mov eax, 0x410378
00007531fdbd11fd  mov [r15+0x100], rax
00007531fdbd1204  jmp 0x00007531FD9FE110
00007531fdbd1209  int3
00007531fdbd120a  call 0x00007531FDAB4690
00007531fdbd120f  jmp 0x00007531FDBD113D
00007531fdbd1214  call 0x00007531FDA0DAE0
00007531fdbd1219  jmp 0x00007531FDBD1177
00007531fdbd121e  int3
00007531fdbd121f  nop
00007531fdbd1220  mov rax, [r15+0x50]
00007531fdbd1224  mov [rsp+0x10], rax
00007531fdbd1229  shl rax, 0x02
00007531fdbd122d  mov r14, [r15+0x98]
00007531fdbd1234  lea r12, [r14+rax*1]
00007531fdbd1238  mov eax, [r15+0x60]
00007531fdbd123c  mov [r13+r12*1], eax
00007531fdbd1241  mov rax, [rsp+0x10]
00007531fdbd1246  lea r14, [rax-0x01]
00007531fdbd124a  mov [r15+0x50], r14
00007531fdbd124e  mov rax, [r15+0x58]
00007531fdbd1252  test rax, rax
00007531fdbd1255  setz al
00007531fdbd1258  movzx rax, al
00007531fdbd125c  mov [rsp+0x414], al
00007531fdbd1263  cmp byte ptr [rsp+0x414], 0x00
00007531fdbd126b  jz 0x00007531FDBD129D
00007531fdbd126d  cmp dword ptr [r15+0x318], 0x00
00007531fdbd1275  jz 0x00007531FDBD12E0
00007531fdbd127b  nop [rax+rax*1], ax
00007531fdbd1284  nop [rax+rax*1], eax
00007531fdbd128c  mov eax, 0x4103AC
00007531fdbd1291  mov [r15+0x100], rax
00007531fdbd1298  jmp 0x00007531FD9FE110
00007531fdbd129d  cmp dword ptr [r15+0x318], 0x00
00007531fdbd12a5  jz 0x00007531FDBD13E0
00007531fdbd12ab  nop [rax+rax*1], ax
00007531fdbd12b4  nop [rax+rax*1], eax
00007531fdbd12bc  mov eax, 0x410390
00007531fdbd12c1  mov [r15+0x100], rax
00007531fdbd12c8  jmp 0x00007531FD9FE110
00007531fdbd12cd  int3
00007531fdbd12ce  call 0x00007531FDAB4B70
00007531fdbd12d3  jmp 0x00007531FDBD1241
00007531fdbd12d8  int3
00007531fdbd12d9  nop [rax], eax
00007531fdbd12e0  cmp dword ptr [r15+0x318], 0x00
00007531fdbd12e8  jz 0x00007531FDBD1320
00007531fdbd12ee  nop [rax+rax*1], ax
00007531fdbd12f7  nop [rax+rax*1], eax
00007531fdbd12ff  mov eax, 0x410374
00007531fdbd1304  mov [r15+0x100], rax
00007531fdbd130b  jmp 0x00007531FD9FE110
00007531fdbd1310  int3
00007531fdbd1311  int3
00007531fdbd1312  nop [rax+rax*1], ax
00007531fdbd131b  nop [rax+rax*1], eax
00007531fdbd1320  mov qword ptr [r15+0x50], 0x00
00007531fdbd1328  mov rax, [r15+0x40]
00007531fdbd132c  lea r14, [rax+0x01]
00007531fdbd1330  mov [r15+0x40], r14
00007531fdbd1334  mov rax, [r15+0x98]
00007531fdbd133b  mov r12d, [r15+0x48]
00007531fdbd133f  mov [r13+rax*1], r12d
00007531fdbd1344  xor eax, eax
00007531fdbd1346  mov r12d, 0x400
00007531fdbd134c  cmp r14, r12
00007531fdbd134f  cmc
00007531fdbd1350  lahf
00007531fdbd1351  seto al
00007531fdbd1354  mov [r15+0x108], eax
00007531fdbd135b  mov eax, [r15+0x108]
00007531fdbd1362  sahf
00007531fdbd1363  jz 0x00007531FDBD1395
00007531fdbd1365  cmp dword ptr [r15+0x318], 0x00
00007531fdbd136d  jz 0x00007531FDBD1120
00007531fdbd1373  nop [rax+rax*1], ax
00007531fdbd137c  nop [rax+rax*1], eax
00007531fdbd1384  mov eax, 0x410388
00007531fdbd1389  mov [r15+0x100], rax
00007531fdbd1390  jmp 0x00007531FD9FE110
00007531fdbd1395  cmp dword ptr [r15+0x318], 0x00
00007531fdbd139d  jz 0x00007531FDBD1580
00007531fdbd13a3  nop [rax+rax*1], ax
00007531fdbd13ac  nop [rax+rax*1], eax
00007531fdbd13b4  mov eax, 0x4103B0
00007531fdbd13b9  mov [r15+0x100], rax
00007531fdbd13c0  jmp 0x00007531FD9FE110
00007531fdbd13c5  int3
00007531fdbd13c6  call 0x00007531FDA0BAE0
00007531fdbd13cb  jmp 0x00007531FDBD1344
00007531fdbd13d0  int3
00007531fdbd13d1  nop [rax+rax*1], ax
00007531fdbd13da  nop [rax+rax*1], ax
00007531fdbd13e0  mov eax, [r15+0x50]
00007531fdbd13e4  lea r14d, [eax-0x01]
00007531fdbd13e9  mov r14d, r14d
00007531fdbd13ec  mov [r15+0x58], r14
00007531fdbd13f0  mov rax, [r15+0x58]
00007531fdbd13f4  mov r14d, eax
00007531fdbd13f7  mov r14d, r14d
00007531fdbd13fa  shl r14, 0x02
00007531fdbd13fe  mov rax, [r15+0x98]
00007531fdbd1405  lea r12, [rax+r14*1]
00007531fdbd1409  mov eax, [r13+r12*1]
00007531fdbd140e  mov [rsp+0x10], eax
00007531fdbd1412  mov eax, eax
00007531fdbd1414  mov [r15+0x60], rax
00007531fdbd1418  mov eax, [r15+0x48]
00007531fdbd141c  mov [rsp+0x20], eax
00007531fdbd1420  xor eax, eax
00007531fdbd1422  mov r14d, [rsp+0x10]
00007531fdbd1427  mov r12d, [rsp+0x20]
00007531fdbd142c  cmp r14d, r12d
00007531fdbd142f  cmc
00007531fdbd1430  lahf
00007531fdbd1431  seto al
00007531fdbd1434  mov [r15+0x108], eax
00007531fdbd143b  mov eax, [r15+0x108]
00007531fdbd1442  sahf
00007531fdbd1443  cmc
00007531fdbd1444  jbe 0x00007531FDBD1476
00007531fdbd1446  cmp dword ptr [r15+0x318], 0x00
00007531fdbd144e  jz 0x00007531FDBD1220
00007531fdbd1454  nop [rax+rax*1], ax
00007531fdbd145d  nop [rax+rax*1], eax
00007531fdbd1465  mov eax, 0x4103A0
00007531fdbd146a  mov [r15+0x100], rax
00007531fdbd1471  jmp 0x00007531FD9FE110
00007531fdbd1476  cmp dword ptr [r15+0x318], 0x00
00007531fdbd147e  jz 0x00007531FDBD14C0
00007531fdbd1484  nop [rax+rax*1], ax
00007531fdbd148d  nop [rax+rax*1], eax
00007531fdbd1495  mov eax, 0x410378
00007531fdbd149a  mov [r15+0x100], rax
00007531fdbd14a1  jmp 0x00007531FD9FE110
00007531fdbd14a6  int3
00007531fdbd14a7  call 0x00007531FDAB4690
00007531fdbd14ac  jmp 0x00007531FDBD140E
00007531fdbd14b1  int3
00007531fdbd14b2  nop [rax+rax*1], ax
00007531fdbd14bb  nop [rax+rax*1], eax
00007531fdbd14c0  mov rax, [r15+0x40]
00007531fdbd14c4  lea r14, [rax+0x01]
00007531fdbd14c8  mov [r15+0x40], r14
00007531fdbd14cc  mov rax, [r15+0x50]
00007531fdbd14d0  mov r12d, eax
00007531fdbd14d3  mov r12d, r12d
00007531fdbd14d6  shl r12, 0x02
00007531fdbd14da  mov rax, [r15+0x98]
00007531fdbd14e1  lea r11, [rax+r12*1]
00007531fdbd14e5  mov eax, [r15+0x48]
00007531fdbd14e9  mov [r13+r11*1], eax
00007531fdbd14ee  xor eax, eax
00007531fdbd14f0  mov r12d, 0x400
00007531fdbd14f6  cmp r14, r12
00007531fdbd14f9  cmc
00007531fdbd14fa  lahf
00007531fdbd14fb  seto al
00007531fdbd14fe  mov [r15+0x108], eax
00007531fdbd1505  mov eax, [r15+0x108]
00007531fdbd150c  sahf
00007531fdbd150d  jz 0x00007531FDBD153F
00007531fdbd150f  cmp dword ptr [r15+0x318], 0x00
00007531fdbd1517  jz 0x00007531FDBD1120
00007531fdbd151d  nop [rax+rax*1], ax
00007531fdbd1526  nop [rax+rax*1], eax
00007531fdbd152e  mov eax, 0x410388
00007531fdbd1533  mov [r15+0x100], rax
00007531fdbd153a  jmp 0x00007531FD9FE110
00007531fdbd153f  cmp dword ptr [r15+0x318], 0x00
00007531fdbd1547  jz 0x00007531FDBD1580
00007531fdbd154d  nop [rax+rax*1], ax
00007531fdbd1556  nop [rax+rax*1], eax
00007531fdbd155e  mov eax, 0x4103B0
00007531fdbd1563  mov [r15+0x100], rax
00007531fdbd156a  jmp 0x00007531FD9FE110
00007531fdbd156f  int3
00007531fdbd1570  call 0x00007531FDAA4270
00007531fdbd1575  jmp 0x00007531FDBD14EE
00007531fdbd157a  int3
00007531fdbd157b  nop [rax+rax*1], eax
00007531fdbd1580  mov qword ptr [r15+0x40], 0x430000
00007531fdbd1588  mov eax, 0x430CB0
00007531fdbd158d  mov r14, [r13+rax*1]
00007531fdbd1592  mov rax, [r15+0x98]
00007531fdbd1599  mov r12d, [r13+rax*1]
00007531fdbd159e  lea r11, [rax+0x04]
00007531fdbd15a2  mov eax, [r13+r11*1]
00007531fdbd15a7  mov r12d, r12d
00007531fdbd15aa  mov [r15+0x68], r12
00007531fdbd15ae  mov eax, eax
00007531fdbd15b0  mov [r15+0x60], rax
00007531fdbd15b4  mov rax, [r15+0x68]
00007531fdbd15b8  mov [r15+0x68], rax
00007531fdbd15bc  mov qword ptr [r15+0x58], 0x02
00007531fdbd15c4  mov [rsp+0x10], rax
00007531fdbd15c9  xor eax, eax
00007531fdbd15cb  mov r12d, 0x02
00007531fdbd15d1  mov r11d, 0x400
00007531fdbd15d7  cmp r12, r11
00007531fdbd15da  cmc
00007531fdbd15db  lahf
00007531fdbd15dc  seto al
00007531fdbd15df  mov [r15+0x108], eax
00007531fdbd15e6  mov rax, [r15+0x60]
00007531fdbd15ea  mov r12d, 0x02
00007531fdbd15f0  imul rax, r12
00007531fdbd15f4  mov [r15+0x50], rax
00007531fdbd15f8  mov rax, [rsp+0x10]
00007531fdbd15fd  lea r12, [rax+r14*1]
00007531fdbd1601  mov [r15+0x48], r12
00007531fdbd1605  mov eax, [r15+0x108]
00007531fdbd160c  sahf
00007531fdbd160d  jnz 0x00007531FDBD163F
00007531fdbd160f  cmp dword ptr [r15+0x318], 0x00
00007531fdbd1617  jz 0x00007531FDBD17B0
00007531fdbd161d  nop [rax+rax*1], ax
00007531fdbd1626  nop [rax+rax*1], eax
00007531fdbd162e  mov eax, 0x4103E0
00007531fdbd1633  mov [r15+0x100], rax
00007531fdbd163a  jmp 0x00007531FD9FE110
00007531fdbd163f  cmp dword ptr [r15+0x318], 0x00
00007531fdbd1647  jz 0x00007531FDBD1690
00007531fdbd164d  nop [rax+rax*1], ax
00007531fdbd1656  nop [rax+rax*1], eax
00007531fdbd165e  mov eax, 0x4103C0
00007531fdbd1663  mov [r15+0x100], rax
00007531fdbd166a  jmp 0x00007531FD9FE110
00007531fdbd166f  int3
00007531fdbd1670  call 0x00007531FDA0DC20
00007531fdbd1675  jmp 0x00007531FDBD1592
00007531fdbd167a  call 0x00007531FDA0B5E0
00007531fdbd167f  jmp 0x00007531FDBD159E
00007531fdbd1684  call 0x00007531FDAA3D90
00007531fdbd1689  jmp 0x00007531FDBD15A7
00007531fdbd168e  int3
00007531fdbd168f  nop
00007531fdbd1690  mov rax, [r15+0x98]
00007531fdbd1697  mov r14, [r15+0x58]
00007531fdbd169b  mov [rsp+0x10], r14
00007531fdbd16a0  shl r14, 0x02
00007531fdbd16a4  lea r12, [rax+r14*1]
00007531fdbd16a8  mov eax, [r13+r12*1]
00007531fdbd16ad  lea r14, [r12+0x04]
00007531fdbd16b2  mov r12d, [r13+r14*1]
00007531fdbd16b7  mov eax, eax
00007531fdbd16b9  mov [r15+0x68], rax
00007531fdbd16bd  mov r12d, r12d
00007531fdbd16c0  mov [r15+0x60], r12
00007531fdbd16c4  mov rax, [r15+0x68]
00007531fdbd16c8  mov [rsp+0x20], rax
00007531fdbd16cd  mov r14, [rsp+0x10]
00007531fdbd16d2  imul rax, r14
00007531fdbd16d6  mov r12, [rsp+0x20]
00007531fdbd16db  lea r11, [r12+rax*1]
00007531fdbd16df  mov [r15+0x68], r11
00007531fdbd16e3  lea rax, [r14+0x02]
00007531fdbd16e7  mov [r15+0x58], rax
00007531fdbd16eb  mov [rsp+0x10], rax
00007531fdbd16f0  xor eax, eax
00007531fdbd16f2  mov r14, [rsp+0x10]
00007531fdbd16f7  mov r12d, 0x400
00007531fdbd16fd  cmp r14, r12
00007531fdbd1700  cmc
00007531fdbd1701  lahf
00007531fdbd1702  seto al
00007531fdbd1705  mov [r15+0x108], eax
00007531fdbd170c  mov rax, [r15+0x50]
00007531fdbd1710  mov r12, [r15+0x60]
00007531fdbd1714  imul r14, r12
00007531fdbd1718  lea r12, [rax+r14*1]
00007531fdbd171c  mov [r15+0x50], r12
00007531fdbd1720  mov rax, [r15+0x48]
00007531fdbd1724  lea r14, [r11+rax*1]
00007531fdbd1728  mov [r15+0x48], r14
00007531fdbd172c  mov eax, [r15+0x108]
00007531fdbd1733  sahf
00007531fdbd1734  jnz 0x00007531FDBD1766
00007531fdbd1736  cmp dword ptr [r15+0x318], 0x00
00007531fdbd173e  jz 0x00007531FDBD17B0
00007531fdbd1744  nop [rax+rax*1], ax
00007531fdbd174d  nop [rax+rax*1], eax
00007531fdbd1755  mov eax, 0x4103E0
00007531fdbd175a  mov [r15+0x100], rax
00007531fdbd1761  jmp 0x00007531FD9FE110
00007531fdbd1766  cmp dword ptr [r15+0x318], 0x00
00007531fdbd176e  jz 0x00007531FDBD1690
00007531fdbd1774  nop [rax+rax*1], ax
00007531fdbd177d  nop [rax+rax*1], eax
00007531fdbd1785  mov eax, 0x4103C0
00007531fdbd178a  mov [r15+0x100], rax
00007531fdbd1791  jmp 0x00007531FD9FE110
00007531fdbd1796  int3
00007531fdbd1797  call 0x00007531FDAB4690
00007531fdbd179c  jmp 0x00007531FDBD16AD
00007531fdbd17a1  call 0x00007531FDAE26A0
00007531fdbd17a6  jmp 0x00007531FDBD16B7
00007531fdbd17ab  int3
00007531fdbd17ac  nop [rax], eax
00007531fdbd17b0  mov qword ptr [r15+0x98], 0x00
00007531fdbd17bb  mov rax, [r15+0x50]
00007531fdbd17bf  mov r14, [r15+0x48]
00007531fdbd17c3  lea r12, [rax+r14*1]
00007531fdbd17c7  mov [r15+0x48], r12
00007531fdbd17cb  mov rax, [r15+0x40]
00007531fdbd17cf  lea r14, [rax+0xCB0]
00007531fdbd17d6  mov [r13+r14*1], r12
00007531fdbd17db  mov qword ptr [r15], 0x01
00007531fdbd17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007531fdbd17ed  mov r14d, [r15+0x320]
00007531fdbd17f4  mov eax, 0x4103F8
00007531fdbd17f9  mov rcx, 0x7531FDBD1860
00007531fdbd1803  mov [r15+r14*8+0x328], rax
00007531fdbd180b  mov [r15+r14*8+0x368], rcx
00007531fdbd1813  add r14d, 0x01
00007531fdbd1817  and r14d, 0x07
00007531fdbd181b  mov [r15+0x320], r14d
00007531fdbd1822  cmp dword ptr [r15+0x318], 0x00
00007531fdbd182a  jz 0x00007531FDBD0F20
00007531fdbd1830  nop [rax+rax*1], ax
00007531fdbd1839  nop [rax+rax*1], eax
00007531fdbd1841  mov eax, 0x4109A4
00007531fdbd1846  mov [r15+0x100], rax
00007531fdbd184d  jmp 0x00007531FD9FE110
00007531fdbd1852  int3
00007531fdbd1853  call 0x00007531FDAE2CE0
00007531fdbd1858  jmp 0x00007531FDBD17DB
00007531fdbd185d  int3
00007531fdbd185e  nop
00007531fdbd1860  mov eax, [r15+0x98]
00007531fdbd1867  lea r14d, [eax+0x01]
00007531fdbd186c  mov [rsp+0x10], r14d
00007531fdbd1871  mov r14d, r14d
00007531fdbd1874  mov [r15+0x98], r14
00007531fdbd187b  xor eax, eax
00007531fdbd187d  mov r14d, [rsp+0x10]
00007531fdbd1882  cmp r14d, 0x10000
00007531fdbd1889  cmc
00007531fdbd188a  lahf
00007531fdbd188b  seto al
00007531fdbd188e  mov [r15+0x108], eax
00007531fdbd1895  mov eax, [r15+0x108]
00007531fdbd189c  sahf
00007531fdbd189d  jnz 0x00007531FDBD18CF
00007531fdbd189f  cmp dword ptr [r15+0x318], 0x00
00007531fdbd18a7  jz 0x00007531FDBD19A0
00007531fdbd18ad  nop [rax+rax*1], ax
00007531fdbd18b6  nop [rax+rax*1], eax
00007531fdbd18be  mov eax, 0x410404
00007531fdbd18c3  mov [r15+0x100], rax
00007531fdbd18ca  jmp 0x00007531FD9FE110
00007531fdbd18cf  cmp dword ptr [r15+0x318], 0x00
00007531fdbd18d7  jz 0x00007531FDBD1910
00007531fdbd18dd  nop [rax+rax*1], ax
00007531fdbd18e6  nop [rax+rax*1], eax
00007531fdbd18ee  mov eax, 0x4103F0
00007531fdbd18f3  mov [r15+0x100], rax
00007531fdbd18fa  jmp 0x00007531FD9FE110
00007531fdbd18ff  int3
00007531fdbd1900  int3
00007531fdbd1901  nop [rax+rax*1], ax
00007531fdbd190a  nop [rax+rax*1], ax
00007531fdbd1910  mov eax, [r15]
00007531fdbd1913  mov r14d, [r15+0x98]
00007531fdbd191a  lea r12d, [eax+r14d*1]
00007531fdbd191f  mov r12d, r12d
00007531fdbd1922  mov [r15], r12
00007531fdbd1925  mov qword ptr [r15+0xF0], 0x4103F8
00007531fdbd1930  mov r14d, [r15+0x320]
00007531fdbd1937  mov eax, 0x4103F8
00007531fdbd193c  mov rcx, 0x7531FDBD1860
00007531fdbd1946  mov [r15+r14*8+0x328], rax
00007531fdbd194e  mov [r15+r14*8+0x368], rcx
00007531fdbd1956  add r14d, 0x01
00007531fdbd195a  and r14d, 0x07
00007531fdbd195e  mov [r15+0x320], r14d
00007531fdbd1965  cmp dword ptr [r15+0x318], 0x00
00007531fdbd196d  jz 0x00007531FDBD0F20
00007531fdbd1973  nop [rax+rax*1], ax
00007531fdbd197c  nop [rax+rax*1], eax
00007531fdbd1984  mov eax, 0x4109A4
00007531fdbd1989  mov [r15+0x100], rax
00007531fdbd1990  jmp 0x00007531FD9FE110
00007531fdbd1995  int3
00007531fdbd1996  int3
00007531fdbd1997  nop [rax+rax*1], ax
00007531fdbd19a0  vmovaps xmm1, [0x00007531FD7FE010]
00007531fdbd19a8  movq xmm1, xmm1
00007531fdbd19ac  movaps [r15+0x110], xmm1
00007531fdbd19b4  mov eax, 0x420B10
00007531fdbd19b9  mov r14, [r13+rax*1]
00007531fdbd19be  movq xmm1, r14
00007531fdbd19c3  movaps [r15+0x120], xmm1
00007531fdbd19cb  vmovaps xmm1, [0x00007531FD7FE020]
00007531fdbd19d3  movq xmm1, xmm1
00007531fdbd19d7  movaps [r15+0x140], xmm1
00007531fdbd19df  vmovaps xmm1, [0x00007531FD7FE030]
00007531fdbd19e7  vpbroadcastq xmm1, xmm1
00007531fdbd19ec  movaps [r15+0x150], xmm1
00007531fdbd19f4  mov qword ptr [r15+0x40], 0x02
00007531fdbd19fc  vmovaps xmm15, [0x00007531FD7FE040]
00007531fdbd1a04  movq xmm15, xmm15
00007531fdbd1a09  movaps [r15+0x160], xmm15
00007531fdbd1a11  vmovaps xmm15, [0x00007531FD7FE050]
00007531fdbd1a19  vpbroadcastq xmm15, xmm15
00007531fdbd1a1e  movaps [r15+0x130], xmm15
00007531fdbd1a26  mov rax, [r15+0x40]
00007531fdbd1a2a  vmovq xmm14, rax
00007531fdbd1a2f  vpbroadcastq xmm14, xmm14
00007531fdbd1a34  movaps [r15+0x170], xmm14
00007531fdbd1a3c  mov eax, 0x420A40
00007531fdbd1a41  movups xmm13, [r13+rax*1]
00007531fdbd1a47  mov qword ptr [r15+0x40], 0x431E00
00007531fdbd1a4f  mov eax, [r15]
00007531fdbd1a52  mov r14d, 0x430CB8
00007531fdbd1a58  mov [r13+r14*1], eax
00007531fdbd1a5d  mov qword ptr [r15+0x50], 0x432000
00007531fdbd1a65  vpmovqd xmm12, xmm13
00007531fdbd1a6b  pxor xmm11, xmm11
00007531fdbd1a70  punpcklqdq xmm12, xmm11
00007531fdbd1a75  movaps [r15+0x210], xmm12
00007531fdbd1a7d  movq xmm12, qword ptr [r15+0x140]
00007531fdbd1a86  movq xmm11, qword ptr [r15+0x120]
00007531fdbd1a8f  psubd xmm12, xmm11
00007531fdbd1a94  movq xmm12, xmm12
00007531fdbd1a99  paddq xmm13, xmm14
00007531fdbd1a9e  movaps [r15+0x180], xmm13
00007531fdbd1aa6  movq xmm14, qword ptr [r15+0x160]
00007531fdbd1aaf  paddd xmm11, xmm14
00007531fdbd1ab4  movq xmm11, xmm11
00007531fdbd1ab9  movq xmm11, xmm11
00007531fdbd1abe  movaps [r15+0x120], xmm11
00007531fdbd1ac6  pmovzxdq xmm12, xmm12
00007531fdbd1acc  psllq xmm12, 0x00
00007531fdbd1ad2  movq xmm14, qword ptr [r15+0x210]
00007531fdbd1adb  movq xmm13, qword ptr [r15+0x110]
00007531fdbd1ae4  paddd xmm14, xmm13
00007531fdbd1ae9  movq xmm14, xmm14
00007531fdbd1aee  vcvtuqq2pd xmm12, xmm12
00007531fdbd1af4  pmovzxdq xmm14, xmm14
00007531fdbd1afa  psllq xmm14, 0x00
00007531fdbd1b00  vcvtuqq2pd xmm14, xmm14
00007531fdbd1b06  movaps xmm13, xmm12
00007531fdbd1b0a  mulpd xmm13, xmm1
00007531fdbd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007531fdbd1b15  ptest xmm11, xmm11
00007531fdbd1b1b  jnz 0x00007531FDBD1C0F
00007531fdbd1b21  movaps [r15+0x220], xmm13
00007531fdbd1b29  mov eax, 0x432000
00007531fdbd1b2e  movups [r13+rax*1], xmm13
00007531fdbd1b34  movaps xmm1, xmm14
00007531fdbd1b38  mulpd xmm1, xmm15
00007531fdbd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007531fdbd1b42  ptest xmm13, xmm13
00007531fdbd1b48  jnz 0x00007531FDBD1D5C
00007531fdbd1b4e  movaps [r15+0x210], xmm1
00007531fdbd1b56  mov eax, 0x431E00
00007531fdbd1b5b  movups [r13+rax*1], xmm1
00007531fdbd1b61  mov qword ptr [r15+0x48], 0x10
00007531fdbd1b69  xor eax, eax
00007531fdbd1b6b  mov r14d, 0x10
00007531fdbd1b71  mov r12d, 0x200
00007531fdbd1b77  cmp r14, r12
00007531fdbd1b7a  cmc
00007531fdbd1b7b  lahf
00007531fdbd1b7c  seto al
00007531fdbd1b7f  mov [r15+0x108], eax
00007531fdbd1b86  mov eax, [r15+0x108]
00007531fdbd1b8d  sahf
00007531fdbd1b8e  jnz 0x00007531FDBD1BC0
00007531fdbd1b90  cmp dword ptr [r15+0x318], 0x00
00007531fdbd1b98  jz 0x00007531FDBD2300
00007531fdbd1b9e  nop [rax+rax*1], ax
00007531fdbd1ba7  nop [rax+rax*1], eax
00007531fdbd1baf  mov eax, 0x410490
00007531fdbd1bb4  mov [r15+0x100], rax
00007531fdbd1bbb  jmp 0x00007531FD9FE110
00007531fdbd1bc0  cmp dword ptr [r15+0x318], 0x00
00007531fdbd1bc8  jz 0x00007531FDBD1EB0
00007531fdbd1bce  nop [rax+rax*1], ax
00007531fdbd1bd7  nop [rax+rax*1], eax
00007531fdbd1bdf  mov eax, 0x410450
00007531fdbd1be4  mov [r15+0x100], rax
00007531fdbd1beb  jmp 0x00007531FD9FE110
00007531fdbd1bf0  int3
00007531fdbd1bf1  call 0x00007531FDA0DC20
00007531fdbd1bf6  jmp 0x00007531FDBD19BE
00007531fdbd1bfb  call 0x00007531FDA0C260
00007531fdbd1c00  jmp 0x00007531FDBD1A47
00007531fdbd1c05  call 0x00007531FDAD5D70
00007531fdbd1c0a  jmp 0x00007531FDBD1A5D
00007531fdbd1c0f  sub rsp, 0x08
00007531fdbd1c13  push rax
00007531fdbd1c14  push rcx
00007531fdbd1c15  push rdx
00007531fdbd1c16  push rdi
00007531fdbd1c17  push rsi
00007531fdbd1c18  push r8
00007531fdbd1c1a  push r9
00007531fdbd1c1c  push r10
00007531fdbd1c1e  push r11
00007531fdbd1c20  sub rsp, 0xF0
00007531fdbd1c27  vmovaps [rsp], xmm0
00007531fdbd1c2c  vmovaps [rsp+0x10], xmm1
00007531fdbd1c32  vmovaps [rsp+0x20], xmm2
00007531fdbd1c38  vmovaps [rsp+0x30], xmm3
00007531fdbd1c3e  vmovaps [rsp+0x40], xmm4
00007531fdbd1c44  vmovaps [rsp+0x50], xmm5
00007531fdbd1c4a  vmovaps [rsp+0x60], xmm6
00007531fdbd1c50  vmovaps [rsp+0x70], xmm7
00007531fdbd1c56  vmovaps [rsp+0x80], xmm8
00007531fdbd1c5f  vmovaps [rsp+0x90], xmm9
00007531fdbd1c68  vmovaps [rsp+0xA0], xmm10
00007531fdbd1c71  vmovaps [rsp+0xB0], xmm11
00007531fdbd1c7a  vmovaps [rsp+0xC0], xmm12
00007531fdbd1c83  vmovaps [rsp+0xD0], xmm14
00007531fdbd1c8c  vmovaps [rsp+0xE0], xmm15
00007531fdbd1c95  sub rsp, 0x30
00007531fdbd1c99  movaps [rsp], xmm13
00007531fdbd1c9e  movaps [rsp+0x10], xmm12
00007531fdbd1ca4  movaps [rsp+0x20], xmm1
00007531fdbd1ca9  lea rdi, [rsp]
00007531fdbd1cad  mov esi, 0x00
00007531fdbd1cb2  mov rax, 0x59ED111DF530
00007531fdbd1cbc  call rax
00007531fdbd1cbe  movaps xmm13, [rsp]
00007531fdbd1cc3  add rsp, 0x30
00007531fdbd1cc7  vmovaps xmm0, [rsp]
00007531fdbd1ccc  vmovaps xmm1, [rsp+0x10]
00007531fdbd1cd2  vmovaps xmm2, [rsp+0x20]
00007531fdbd1cd8  vmovaps xmm3, [rsp+0x30]
00007531fdbd1cde  vmovaps xmm4, [rsp+0x40]
00007531fdbd1ce4  vmovaps xmm5, [rsp+0x50]
00007531fdbd1cea  vmovaps xmm6, [rsp+0x60]
00007531fdbd1cf0  vmovaps xmm7, [rsp+0x70]
00007531fdbd1cf6  vmovaps xmm8, [rsp+0x80]
00007531fdbd1cff  vmovaps xmm9, [rsp+0x90]
00007531fdbd1d08  vmovaps xmm10, [rsp+0xA0]
00007531fdbd1d11  vmovaps xmm11, [rsp+0xB0]
00007531fdbd1d1a  vmovaps xmm12, [rsp+0xC0]
00007531fdbd1d23  vmovaps xmm14, [rsp+0xD0]
00007531fdbd1d2c  vmovaps xmm15, [rsp+0xE0]
00007531fdbd1d35  add rsp, 0xF0
00007531fdbd1d3c  pop r11
00007531fdbd1d3e  pop r10
00007531fdbd1d40  pop r9
00007531fdbd1d42  pop r8
00007531fdbd1d44  pop rsi
00007531fdbd1d45  pop rdi
00007531fdbd1d46  pop rdx
00007531fdbd1d47  pop rcx
00007531fdbd1d48  pop rax
00007531fdbd1d49  add rsp, 0x08
00007531fdbd1d4d  jmp 0x00007531FDBD1B21
00007531fdbd1d52  call 0x00007531FDA0C380
00007531fdbd1d57  jmp 0x00007531FDBD1B34
00007531fdbd1d5c  sub rsp, 0x08
00007531fdbd1d60  push rax
00007531fdbd1d61  push rcx
00007531fdbd1d62  push rdx
00007531fdbd1d63  push rdi
00007531fdbd1d64  push rsi
00007531fdbd1d65  push r8
00007531fdbd1d67  push r9
00007531fdbd1d69  push r10
00007531fdbd1d6b  push r11
00007531fdbd1d6d  sub rsp, 0xF0
00007531fdbd1d74  vmovaps [rsp], xmm0
00007531fdbd1d79  vmovaps [rsp+0x10], xmm2
00007531fdbd1d7f  vmovaps [rsp+0x20], xmm3
00007531fdbd1d85  vmovaps [rsp+0x30], xmm4
00007531fdbd1d8b  vmovaps [rsp+0x40], xmm5
00007531fdbd1d91  vmovaps [rsp+0x50], xmm6
00007531fdbd1d97  vmovaps [rsp+0x60], xmm7
00007531fdbd1d9d  vmovaps [rsp+0x70], xmm8
00007531fdbd1da3  vmovaps [rsp+0x80], xmm9
00007531fdbd1dac  vmovaps [rsp+0x90], xmm10
00007531fdbd1db5  vmovaps [rsp+0xA0], xmm11
00007531fdbd1dbe  vmovaps [rsp+0xB0], xmm12
00007531fdbd1dc7  vmovaps [rsp+0xC0], xmm13
00007531fdbd1dd0  vmovaps [rsp+0xD0], xmm14
00007531fdbd1dd9  vmovaps [rsp+0xE0], xmm15
00007531fdbd1de2  sub rsp, 0x30
00007531fdbd1de6  movaps [rsp], xmm1
00007531fdbd1dea  movaps [rsp+0x10], xmm14
00007531fdbd1df0  movaps [rsp+0x20], xmm15
00007531fdbd1df6  lea rdi, [rsp]
00007531fdbd1dfa  mov esi, 0x00
00007531fdbd1dff  mov rax, 0x59ED111DF530
00007531fdbd1e09  call rax
00007531fdbd1e0b  movaps xmm1, [rsp]
00007531fdbd1e0f  add rsp, 0x30
00007531fdbd1e13  vmovaps xmm0, [rsp]
00007531fdbd1e18  vmovaps xmm2, [rsp+0x10]
00007531fdbd1e1e  vmovaps xmm3, [rsp+0x20]
00007531fdbd1e24  vmovaps xmm4, [rsp+0x30]
00007531fdbd1e2a  vmovaps xmm5, [rsp+0x40]
00007531fdbd1e30  vmovaps xmm6, [rsp+0x50]
00007531fdbd1e36  vmovaps xmm7, [rsp+0x60]
00007531fdbd1e3c  vmovaps xmm8, [rsp+0x70]
00007531fdbd1e42  vmovaps xmm9, [rsp+0x80]
00007531fdbd1e4b  vmovaps xmm10, [rsp+0x90]
00007531fdbd1e54  vmovaps xmm11, [rsp+0xA0]
00007531fdbd1e5d  vmovaps xmm12, [rsp+0xB0]
00007531fdbd1e66  vmovaps xmm13, [rsp+0xC0]
00007531fdbd1e6f  vmovaps xmm14, [rsp+0xD0]
00007531fdbd1e78  vmovaps xmm15, [rsp+0xE0]
00007531fdbd1e81  add rsp, 0xF0
00007531fdbd1e88  pop r11
00007531fdbd1e8a  pop r10
00007531fdbd1e8c  pop r9
00007531fdbd1e8e  pop r8
00007531fdbd1e90  pop rsi
00007531fdbd1e91  pop rdi
00007531fdbd1e92  pop rdx
00007531fdbd1e93  pop rcx
00007531fdbd1e94  pop rax
00007531fdbd1e95  add rsp, 0x08
00007531fdbd1e99  jmp 0x00007531FDBD1B4E
00007531fdbd1e9e  call 0x00007531FD9FF540
00007531fdbd1ea3  jmp 0x00007531FDBD1B61
00007531fdbd1ea8  int3
00007531fdbd1ea9  nop [rax], eax
00007531fdbd1eb0  movaps xmm1, [r15+0x180]
00007531fdbd1eb8  vpmovqd xmm15, xmm1
00007531fdbd1ebe  pxor xmm14, xmm14
00007531fdbd1ec3  punpcklqdq xmm15, xmm14
00007531fdbd1ec8  movaps [r15+0x210], xmm15
00007531fdbd1ed0  movq xmm15, qword ptr [r15+0x140]
00007531fdbd1ed9  movq xmm14, qword ptr [r15+0x120]
00007531fdbd1ee2  psubd xmm15, xmm14
00007531fdbd1ee7  movq xmm15, xmm15
00007531fdbd1eec  movaps xmm13, [r15+0x170]
00007531fdbd1ef4  paddq xmm1, xmm13
00007531fdbd1ef9  movaps [r15+0x180], xmm1
00007531fdbd1f01  movq xmm1, qword ptr [r15+0x160]
00007531fdbd1f0a  paddd xmm14, xmm1
00007531fdbd1f0f  movq xmm14, xmm14
00007531fdbd1f14  movq xmm14, xmm14
00007531fdbd1f19  movaps [r15+0x120], xmm14
00007531fdbd1f21  pmovzxdq xmm15, xmm15
00007531fdbd1f27  psllq xmm15, 0x00
00007531fdbd1f2d  movq xmm1, qword ptr [r15+0x210]
00007531fdbd1f36  movq xmm14, qword ptr [r15+0x110]
00007531fdbd1f3f  paddd xmm1, xmm14
00007531fdbd1f44  movq xmm1, xmm1
00007531fdbd1f48  vcvtuqq2pd xmm15, xmm15
00007531fdbd1f4e  pmovzxdq xmm1, xmm1
00007531fdbd1f53  psllq xmm1, 0x00
00007531fdbd1f58  vcvtuqq2pd xmm1, xmm1
00007531fdbd1f5e  movaps xmm14, [r15+0x150]
00007531fdbd1f66  movaps xmm13, xmm15
00007531fdbd1f6a  mulpd xmm13, xmm14
00007531fdbd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007531fdbd1f75  ptest xmm12, xmm12
00007531fdbd1f7b  jnz 0x00007531FDBD205E
00007531fdbd1f81  movaps [r15+0x220], xmm13
00007531fdbd1f89  mov rax, [r15+0x48]
00007531fdbd1f8d  mov r14, [r15+0x50]
00007531fdbd1f91  lea r12, [r14+rax*1]
00007531fdbd1f95  movups [r13+r12*1], xmm13
00007531fdbd1f9b  movaps xmm15, [r15+0x130]
00007531fdbd1fa3  movaps xmm14, xmm1
00007531fdbd1fa7  mulpd xmm14, xmm15
00007531fdbd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007531fdbd1fb2  ptest xmm13, xmm13
00007531fdbd1fb8  jnz 0x00007531FDBD21AC
00007531fdbd1fbe  movaps [r15+0x210], xmm14
00007531fdbd1fc6  mov r14, [r15+0x40]
00007531fdbd1fca  lea r12, [r14+rax*1]
00007531fdbd1fce  movups [r13+r12*1], xmm14
00007531fdbd1fd4  lea r14, [rax+0x10]
00007531fdbd1fd8  mov [r15+0x48], r14
00007531fdbd1fdc  xor eax, eax
00007531fdbd1fde  mov r12d, 0x200
00007531fdbd1fe4  cmp r14, r12
00007531fdbd1fe7  cmc
00007531fdbd1fe8  lahf
00007531fdbd1fe9  seto al
00007531fdbd1fec  mov [r15+0x108], eax
00007531fdbd1ff3  mov eax, [r15+0x108]
00007531fdbd1ffa  sahf
00007531fdbd1ffb  jnz 0x00007531FDBD202D
00007531fdbd1ffd  cmp dword ptr [r15+0x318], 0x00
00007531fdbd2005  jz 0x00007531FDBD2300
00007531fdbd200b  nop [rax+rax*1], ax
00007531fdbd2014  nop [rax+rax*1], eax
00007531fdbd201c  mov eax, 0x410490
00007531fdbd2021  mov [r15+0x100], rax
00007531fdbd2028  jmp 0x00007531FD9FE110
00007531fdbd202d  cmp dword ptr [r15+0x318], 0x00
00007531fdbd2035  jz 0x00007531FDBD1EB0
00007531fdbd203b  nop [rax+rax*1], ax
00007531fdbd2044  nop [rax+rax*1], eax
00007531fdbd204c  mov eax, 0x410450
00007531fdbd2051  mov [r15+0x100], rax
00007531fdbd2058  jmp 0x00007531FD9FE110
00007531fdbd205d  int3
00007531fdbd205e  sub rsp, 0x08
00007531fdbd2062  push rax
00007531fdbd2063  push rcx
00007531fdbd2064  push rdx
00007531fdbd2065  push rdi
00007531fdbd2066  push rsi
00007531fdbd2067  push r8
00007531fdbd2069  push r9
00007531fdbd206b  push r10
00007531fdbd206d  push r11
00007531fdbd206f  sub rsp, 0xF0
00007531fdbd2076  vmovaps [rsp], xmm0
00007531fdbd207b  vmovaps [rsp+0x10], xmm1
00007531fdbd2081  vmovaps [rsp+0x20], xmm2
00007531fdbd2087  vmovaps [rsp+0x30], xmm3
00007531fdbd208d  vmovaps [rsp+0x40], xmm4
00007531fdbd2093  vmovaps [rsp+0x50], xmm5
00007531fdbd2099  vmovaps [rsp+0x60], xmm6
00007531fdbd209f  vmovaps [rsp+0x70], xmm7
00007531fdbd20a5  vmovaps [rsp+0x80], xmm8
00007531fdbd20ae  vmovaps [rsp+0x90], xmm9
00007531fdbd20b7  vmovaps [rsp+0xA0], xmm10
00007531fdbd20c0  vmovaps [rsp+0xB0], xmm11
00007531fdbd20c9  vmovaps [rsp+0xC0], xmm12
00007531fdbd20d2  vmovaps [rsp+0xD0], xmm14
00007531fdbd20db  vmovaps [rsp+0xE0], xmm15
00007531fdbd20e4  sub rsp, 0x30
00007531fdbd20e8  movaps [rsp], xmm13
00007531fdbd20ed  movaps [rsp+0x10], xmm15
00007531fdbd20f3  movaps [rsp+0x20], xmm14
00007531fdbd20f9  lea rdi, [rsp]
00007531fdbd20fd  mov esi, 0x00
00007531fdbd2102  mov rax, 0x59ED111DF530
00007531fdbd210c  call rax
00007531fdbd210e  movaps xmm13, [rsp]
00007531fdbd2113  add rsp, 0x30
00007531fdbd2117  vmovaps xmm0, [rsp]
00007531fdbd211c  vmovaps xmm1, [rsp+0x10]
00007531fdbd2122  vmovaps xmm2, [rsp+0x20]
00007531fdbd2128  vmovaps xmm3, [rsp+0x30]
00007531fdbd212e  vmovaps xmm4, [rsp+0x40]
00007531fdbd2134  vmovaps xmm5, [rsp+0x50]
00007531fdbd213a  vmovaps xmm6, [rsp+0x60]
00007531fdbd2140  vmovaps xmm7, [rsp+0x70]
00007531fdbd2146  vmovaps xmm8, [rsp+0x80]
00007531fdbd214f  vmovaps xmm9, [rsp+0x90]
00007531fdbd2158  vmovaps xmm10, [rsp+0xA0]
00007531fdbd2161  vmovaps xmm11, [rsp+0xB0]
00007531fdbd216a  vmovaps xmm12, [rsp+0xC0]
00007531fdbd2173  vmovaps xmm14, [rsp+0xD0]
00007531fdbd217c  vmovaps xmm15, [rsp+0xE0]
00007531fdbd2185  add rsp, 0xF0
00007531fdbd218c  pop r11
00007531fdbd218e  pop r10
00007531fdbd2190  pop r9
00007531fdbd2192  pop r8
00007531fdbd2194  pop rsi
00007531fdbd2195  pop rdi
00007531fdbd2196  pop rdx
00007531fdbd2197  pop rcx
00007531fdbd2198  pop rax
00007531fdbd2199  add rsp, 0x08
00007531fdbd219d  jmp 0x00007531FDBD1F81
00007531fdbd21a2  call 0x00007531FDAC2240
00007531fdbd21a7  jmp 0x00007531FDBD1F9B
00007531fdbd21ac  sub rsp, 0x08
00007531fdbd21b0  push rax
00007531fdbd21b1  push rcx
00007531fdbd21b2  push rdx
00007531fdbd21b3  push rdi
00007531fdbd21b4  push rsi
00007531fdbd21b5  push r8
00007531fdbd21b7  push r9
00007531fdbd21b9  push r10
00007531fdbd21bb  push r11
00007531fdbd21bd  sub rsp, 0xF0
00007531fdbd21c4  vmovaps [rsp], xmm0
00007531fdbd21c9  vmovaps [rsp+0x10], xmm1
00007531fdbd21cf  vmovaps [rsp+0x20], xmm2
00007531fdbd21d5  vmovaps [rsp+0x30], xmm3
00007531fdbd21db  vmovaps [rsp+0x40], xmm4
00007531fdbd21e1  vmovaps [rsp+0x50], xmm5
00007531fdbd21e7  vmovaps [rsp+0x60], xmm6
00007531fdbd21ed  vmovaps [rsp+0x70], xmm7
00007531fdbd21f3  vmovaps [rsp+0x80], xmm8
00007531fdbd21fc  vmovaps [rsp+0x90], xmm9
00007531fdbd2205  vmovaps [rsp+0xA0], xmm10
00007531fdbd220e  vmovaps [rsp+0xB0], xmm11
00007531fdbd2217  vmovaps [rsp+0xC0], xmm12
00007531fdbd2220  vmovaps [rsp+0xD0], xmm13
00007531fdbd2229  vmovaps [rsp+0xE0], xmm15
00007531fdbd2232  sub rsp, 0x30
00007531fdbd2236  movaps [rsp], xmm14
00007531fdbd223b  movaps [rsp+0x10], xmm1
00007531fdbd2240  movaps [rsp+0x20], xmm15
00007531fdbd2246  lea rdi, [rsp]
00007531fdbd224a  mov esi, 0x00
00007531fdbd224f  mov rax, 0x59ED111DF530
00007531fdbd2259  call rax
00007531fdbd225b  movaps xmm14, [rsp]
00007531fdbd2260  add rsp, 0x30
00007531fdbd2264  vmovaps xmm0, [rsp]
00007531fdbd2269  vmovaps xmm1, [rsp+0x10]
00007531fdbd226f  vmovaps xmm2, [rsp+0x20]
00007531fdbd2275  vmovaps xmm3, [rsp+0x30]
00007531fdbd227b  vmovaps xmm4, [rsp+0x40]
00007531fdbd2281  vmovaps xmm5, [rsp+0x50]
00007531fdbd2287  vmovaps xmm6, [rsp+0x60]
00007531fdbd228d  vmovaps xmm7, [rsp+0x70]
00007531fdbd2293  vmovaps xmm8, [rsp+0x80]
00007531fdbd229c  vmovaps xmm9, [rsp+0x90]
00007531fdbd22a5  vmovaps xmm10, [rsp+0xA0]
00007531fdbd22ae  vmovaps xmm11, [rsp+0xB0]
00007531fdbd22b7  vmovaps xmm12, [rsp+0xC0]
00007531fdbd22c0  vmovaps xmm13, [rsp+0xD0]
00007531fdbd22c9  vmovaps xmm15, [rsp+0xE0]
00007531fdbd22d2  add rsp, 0xF0
00007531fdbd22d9  pop r11
00007531fdbd22db  pop r10
00007531fdbd22dd  pop r9
00007531fdbd22df  pop r8
00007531fdbd22e1  pop rsi
00007531fdbd22e2  pop rdi
00007531fdbd22e3  pop rdx
00007531fdbd22e4  pop rcx
00007531fdbd22e5  pop rax
00007531fdbd22e6  add rsp, 0x08
00007531fdbd22ea  jmp 0x00007531FDBD1FBE
00007531fdbd22ef  call 0x00007531FDAC34C0
00007531fdbd22f4  jmp 0x00007531FDBD1FD4
00007531fdbd22f9  int3
00007531fdbd22fa  nop [rax+rax*1], ax
00007531fdbd2300  mov rax, [r15+0x50]
00007531fdbd2304  lea r14, [rax+0x80]
00007531fdbd230b  movups xmm1, [r13+r14*1]
00007531fdbd2311  lea r14, [rax+0x90]
00007531fdbd2318  movups xmm15, [r13+r14*1]
00007531fdbd231e  vxorps xmm14, xmm14, xmm14
00007531fdbd2323  vpbroadcastq xmm14, xmm14
00007531fdbd2328  lea r14, [rax+0x40]
00007531fdbd232c  movups xmm13, [r13+r14*1]
00007531fdbd2332  lea r14, [rax+0x50]
00007531fdbd2336  movups xmm12, [r13+r14*1]
00007531fdbd233c  mov qword ptr [r15+0x48], 0x00
00007531fdbd2344  movups xmm11, [r13+rax*1]
00007531fdbd234a  lea r14, [rax+0x10]
00007531fdbd234e  movups xmm10, [r13+r14*1]
00007531fdbd2354  mov r14, [r15+0xF8]
00007531fdbd235b  lea r12, [r14+0xE0]
00007531fdbd2362  movups [r13+r12*1], xmm15
00007531fdbd2368  lea r12, [r14+0xF0]
00007531fdbd236f  movups [r13+r12*1], xmm1
00007531fdbd2375  lea r12, [rax+0xC0]
00007531fdbd237c  movups xmm1, [r13+r12*1]
00007531fdbd2382  lea r12, [rax+0xD0]
00007531fdbd2389  movups xmm15, [r13+r12*1]
00007531fdbd238f  lea r12, [rax+0x140]
00007531fdbd2396  movups xmm9, [r13+r12*1]
00007531fdbd239c  lea r12, [rax+0x150]
00007531fdbd23a3  movups xmm8, [r13+r12*1]
00007531fdbd23a9  lea r12, [rax+0x180]
00007531fdbd23b0  movups xmm7, [r13+r12*1]
00007531fdbd23b6  lea r12, [rax+0x190]
00007531fdbd23bd  movups xmm6, [r13+r12*1]
00007531fdbd23c3  lea r12, [r14+0xC0]
00007531fdbd23ca  movups [r13+r12*1], xmm15
00007531fdbd23d0  lea r12, [r14+0xD0]
00007531fdbd23d7  movups [r13+r12*1], xmm1
00007531fdbd23dd  lea r12, [rax+0x100]
00007531fdbd23e4  movups xmm1, [r13+r12*1]
00007531fdbd23ea  lea r12, [rax+0x110]
00007531fdbd23f1  movups xmm15, [r13+r12*1]
00007531fdbd23f7  lea r12, [rax+0x1C0]
00007531fdbd23fe  movups xmm5, [r13+r12*1]
00007531fdbd2404  lea r12, [rax+0x1D0]
00007531fdbd240b  movups xmm4, [r13+r12*1]
00007531fdbd2411  lea r12, [rax+0x20]
00007531fdbd2415  movups xmm3, [r13+r12*1]
00007531fdbd241b  lea r12, [rax+0x30]
00007531fdbd241f  movups xmm2, [r13+r12*1]
00007531fdbd2425  movaps [r15+0x1F0], xmm2
00007531fdbd242d  lea r12, [r14+0x20]
00007531fdbd2431  movups [r13+r12*1], xmm1
00007531fdbd2437  lea r12, [r14+0x30]
00007531fdbd243b  movups [r13+r12*1], xmm12
00007531fdbd2441  lea r12, [rax+0x60]
00007531fdbd2445  movups xmm1, [r13+r12*1]
00007531fdbd244b  lea r12, [rax+0x70]
00007531fdbd244f  movups xmm12, [r13+r12*1]
00007531fdbd2455  lea r12, [r14+0x60]
00007531fdbd2459  movups [r13+r12*1], xmm11
00007531fdbd245f  lea r12, [r14+0x70]
00007531fdbd2463  movups [r13+r12*1], xmm5
00007531fdbd2469  lea r12, [rax+0xE0]
00007531fdbd2470  movups xmm11, [r13+r12*1]
00007531fdbd2476  lea r12, [rax+0xF0]
00007531fdbd247d  movups xmm5, [r13+r12*1]
00007531fdbd2483  lea r12, [rax+0x120]
00007531fdbd248a  vmovaps [rsp+0x10], xmm1
00007531fdbd2490  movups xmm1, [r13+r12*1]
00007531fdbd2496  lea r12, [rax+0x130]
00007531fdbd249d  vmovaps [rsp+0x20], xmm1
00007531fdbd24a3  movups xmm1, [r13+r12*1]
00007531fdbd24a9  lea r12, [r14+0xA0]
00007531fdbd24b0  movups [r13+r12*1], xmm12
00007531fdbd24b6  lea r12, [r14+0xB0]
00007531fdbd24bd  vmovaps xmm12, [rsp+0x10]
00007531fdbd24c3  movups [r13+r12*1], xmm12
00007531fdbd24c9  lea r12, [rax+0xA0]
00007531fdbd24d0  movups xmm12, [r13+r12*1]
00007531fdbd24d6  lea r12, [rax+0xB0]
00007531fdbd24dd  vmovaps [rsp+0x10], xmm1
00007531fdbd24e3  movups xmm1, [r13+r12*1]
00007531fdbd24e9  lea r12, [rax+0x160]
00007531fdbd24f0  vmovaps [rsp+0x30], xmm1
00007531fdbd24f6  movups xmm1, [r13+r12*1]
00007531fdbd24fc  lea r12, [rax+0x170]
00007531fdbd2503  vmovaps [rsp+0x40], xmm1
00007531fdbd2509  movups xmm1, [r13+r12*1]
00007531fdbd250f  movaps [r15+0x2B0], xmm1
00007531fdbd2517  lea r12, [rax+0x1A0]
00007531fdbd251e  vmovaps [rsp+0x50], xmm1
00007531fdbd2524  movups xmm1, [r13+r12*1]
00007531fdbd252a  lea r12, [rax+0x1B0]
00007531fdbd2531  vmovaps [rsp+0x60], xmm1
00007531fdbd2537  movups xmm1, [r13+r12*1]
00007531fdbd253d  vmovaps [rsp+0x70], xmm1
00007531fdbd2543  vmovaps xmm1, [rsp+0x60]
00007531fdbd2549  movaps [r15+0x290], xmm1
00007531fdbd2551  vmovaps [rsp+0x60], xmm1
00007531fdbd2557  vmovaps xmm1, [rsp+0x70]
00007531fdbd255d  movaps [r15+0x1E0], xmm1
00007531fdbd2565  lea r12, [r14+0x80]
00007531fdbd256c  vmovaps [rsp+0x70], xmm1
00007531fdbd2572  vmovaps xmm1, [rsp+0x30]
00007531fdbd2578  movups [r13+r12*1], xmm1
00007531fdbd257e  lea r12, [r14+0x90]
00007531fdbd2585  movups [r13+r12*1], xmm12
00007531fdbd258b  lea r12, [rax+0x1E0]
00007531fdbd2592  movups xmm1, [r13+r12*1]
00007531fdbd2598  lea r12, [rax+0x1F0]
00007531fdbd259f  movups xmm12, [r13+r12*1]
00007531fdbd25a5  mov qword ptr [r15+0x50], 0x432200
00007531fdbd25ad  lea rax, [r14+0x40]
00007531fdbd25b1  vmovaps [rsp+0x30], xmm1
00007531fdbd25b7  vmovaps xmm1, [rsp+0x40]
00007531fdbd25bd  movups [r13+rax*1], xmm1
00007531fdbd25c3  lea rax, [r14+0x50]
00007531fdbd25c7  movups [r13+rax*1], xmm10
00007531fdbd25cd  movups [r13+r14*1], xmm12
00007531fdbd25d3  lea rax, [r14+0x10]
00007531fdbd25d7  vmovaps xmm1, [rsp+0x30]
00007531fdbd25dd  movups [r13+rax*1], xmm1
00007531fdbd25e3  mov rax, [r15+0x40]
00007531fdbd25e7  vmovaps [rsp+0x30], xmm3
00007531fdbd25ed  vmovaps xmm1, [rsp+0x30]
00007531fdbd25f3  por xmm3, xmm1
00007531fdbd25f7  vmovaps [rsp+0x30], xmm6
00007531fdbd25fd  vmovaps xmm12, [rsp+0x30]
00007531fdbd2603  por xmm6, xmm12
00007531fdbd2608  lea r12, [rax+0x30]
00007531fdbd260c  mov r11, [r13+r12*1]
00007531fdbd2611  lea r12, [rax+0x38]
00007531fdbd2615  mov r10, [r13+r12*1]
00007531fdbd261a  movq xmm12, r11
00007531fdbd261f  movq xmm10, r10
00007531fdbd2624  movq xmm12, xmm12
00007531fdbd2629  vmovaps [rsp+0x30], xmm12
00007531fdbd262f  movq xmm12, xmm12
00007531fdbd2634  movaps [r15+0x130], xmm12
00007531fdbd263c  movq xmm10, xmm10
00007531fdbd2641  vmovaps [rsp+0x40], xmm10
00007531fdbd2647  movq xmm10, xmm10
00007531fdbd264c  movaps [r15+0x280], xmm10
00007531fdbd2654  vmovaps [rsp+0x80], xmm9
00007531fdbd265d  vmovaps xmm12, [rsp+0x80]
00007531fdbd2666  por xmm9, xmm12
00007531fdbd266b  lea r12, [rax+0x20]
00007531fdbd266f  mov r11, [r13+r12*1]
00007531fdbd2674  lea r12, [rax+0x28]
00007531fdbd2678  mov r10, [r13+r12*1]
00007531fdbd267d  movq xmm12, r11
00007531fdbd2682  movq xmm10, r10
00007531fdbd2687  movq xmm12, xmm12
00007531fdbd268c  vmovaps [rsp+0x80], xmm12
00007531fdbd2695  movq xmm12, xmm12
00007531fdbd269a  movaps [r15+0x150], xmm12
00007531fdbd26a2  movq xmm10, xmm10
00007531fdbd26a7  vmovaps [rsp+0x90], xmm10
00007531fdbd26b0  movq xmm10, xmm10
00007531fdbd26b5  movaps [r15+0x140], xmm10
00007531fdbd26bd  lea r12, [rax+0x10]
00007531fdbd26c1  mov r11, [r13+r12*1]
00007531fdbd26c6  lea r12, [rax+0x18]
00007531fdbd26ca  mov r10, [r13+r12*1]
00007531fdbd26cf  movq xmm12, r11
00007531fdbd26d4  movq xmm10, r10
00007531fdbd26d9  movq xmm12, xmm12
00007531fdbd26de  vmovaps [rsp+0xA0], xmm12
00007531fdbd26e7  movq xmm12, xmm12
00007531fdbd26ec  movaps [r15+0x170], xmm12
00007531fdbd26f4  movq xmm10, xmm10
00007531fdbd26f9  vmovaps [rsp+0xB0], xmm10
00007531fdbd2702  movq xmm10, xmm10
00007531fdbd2707  movaps [r15+0x160], xmm10
00007531fdbd270f  mov r12, [r13+rax*1]
00007531fdbd2714  vmovq xmm12, r12
00007531fdbd2719  vpbroadcastq xmm12, xmm12
00007531fdbd271e  lea r12, [rax+0x08]
00007531fdbd2722  mov rax, [r13+r12*1]
00007531fdbd2727  movq xmm10, rax
00007531fdbd272c  movaps [r15+0x230], xmm10
00007531fdbd2734  lea rax, [r14+0x50]
00007531fdbd2738  movups xmm10, [r13+rax*1]
00007531fdbd273e  lea rax, [r14+0x60]
00007531fdbd2742  vmovaps [rsp+0xC0], xmm1
00007531fdbd274b  movups xmm1, [r13+rax*1]
00007531fdbd2751  lea rax, [r14+0x30]
00007531fdbd2755  vmovaps [rsp+0xD0], xmm1
00007531fdbd275e  movups xmm1, [r13+rax*1]
00007531fdbd2764  mov qword ptr [r15+0x60], 0x432200
00007531fdbd276c  mov qword ptr [r15+0x58], 0x40
00007531fdbd2774  vmovaps [rsp+0xE0], xmm1
00007531fdbd277d  vmovaps [rsp+0xF0], xmm15
00007531fdbd2786  vmovaps xmm15, [rsp+0xC0]
00007531fdbd278f  vmovaps [rsp+0xC0], xmm14
00007531fdbd2798  movaps xmm1, xmm12
00007531fdbd279c  mulpd xmm1, xmm15
00007531fdbd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007531fdbd27a6  ptest xmm14, xmm14
00007531fdbd27ac  jnz 0x00007531FDBD3863
00007531fdbd27b2  movq xmm15, qword ptr [r15+0x230]
00007531fdbd27bb  vmovaps [rsp+0x100], xmm15
00007531fdbd27c4  vpermilpd xmm15, xmm15, 0x00
00007531fdbd27ca  vmovaps [rsp+0x110], xmm1
00007531fdbd27d3  vmovaps xmm1, [rsp+0xE0]
00007531fdbd27dc  vmovaps [rsp+0xE0], xmm13
00007531fdbd27e5  movaps xmm14, xmm1
00007531fdbd27e9  mulpd xmm14, xmm15
00007531fdbd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007531fdbd27f4  ptest xmm13, xmm13
00007531fdbd27fa  jnz 0x00007531FDBD39A5
00007531fdbd2800  vxorps xmm1, xmm1, xmm1
00007531fdbd2804  vpbroadcastq xmm1, xmm1
00007531fdbd2809  vmovaps xmm13, [rsp+0xD0]
00007531fdbd2812  vmovaps [rsp+0xD0], xmm1
00007531fdbd281b  movaps xmm15, xmm12
00007531fdbd281f  mulpd xmm15, xmm13
00007531fdbd2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007531fdbd282a  ptest xmm1, xmm1
00007531fdbd282f  jnz 0x00007531FDBD3AE8
00007531fdbd2835  movaps xmm1, xmm12
00007531fdbd2839  mulpd xmm1, xmm10
00007531fdbd283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007531fdbd2843  ptest xmm13, xmm13
00007531fdbd2849  jnz 0x00007531FDBD3C2C
00007531fdbd284f  movaps xmm13, xmm12
00007531fdbd2853  mulpd xmm13, xmm2
00007531fdbd2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007531fdbd285e  ptest xmm10, xmm10
00007531fdbd2864  jnz 0x00007531FDBD3D6E
00007531fdbd286a  vmovaps [rsp+0x120], xmm7
00007531fdbd2873  vmovaps xmm12, [rsp+0x120]
00007531fdbd287c  por xmm7, xmm12
00007531fdbd2881  vmovaps xmm12, [rsp+0xE0]
00007531fdbd288a  vmovaps xmm10, [rsp+0xE0]
00007531fdbd2893  por xmm12, xmm10
00007531fdbd2898  vmovaps xmm2, [rsp+0x100]
00007531fdbd28a1  vpermilpd xmm2, xmm2, 0x00
00007531fdbd28a7  vmovaps [rsp+0xE0], xmm1
00007531fdbd28b0  vmovaps [rsp+0x120], xmm15
00007531fdbd28b9  movaps xmm1, xmm10
00007531fdbd28bd  mulpd xmm1, xmm2
00007531fdbd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007531fdbd28c6  ptest xmm15, xmm15
00007531fdbd28cc  jnz 0x00007531FDBD3EB1
00007531fdbd28d2  xor eax, eax
00007531fdbd28d4  mov r12d, 0x40
00007531fdbd28da  mov r11d, 0x200
00007531fdbd28e0  cmp r12, r11
00007531fdbd28e3  cmc
00007531fdbd28e4  lahf
00007531fdbd28e5  seto al
00007531fdbd28e8  mov [r15+0x108], eax
00007531fdbd28ef  vmovaps xmm10, [rsp+0x110]
00007531fdbd28f8  vmovaps xmm2, [rsp+0xD0]
00007531fdbd2901  vmovaps [rsp+0xD0], xmm1
00007531fdbd290a  movaps xmm15, xmm10
00007531fdbd290e  addpd xmm15, xmm2
00007531fdbd2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007531fdbd2919  ptest xmm1, xmm1
00007531fdbd291e  jnz 0x00007531FDBD3FF2
00007531fdbd2924  vmovaps xmm10, [rsp+0x120]
00007531fdbd292d  vmovaps [rsp+0x110], xmm15
00007531fdbd2936  vmovaps xmm15, [rsp+0xC0]
00007531fdbd293f  vmovaps [rsp+0xC0], xmm14
00007531fdbd2948  movaps xmm1, xmm10
00007531fdbd294c  addpd xmm1, xmm15
00007531fdbd2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007531fdbd2956  ptest xmm14, xmm14
00007531fdbd295c  jnz 0x00007531FDBD4135
00007531fdbd2962  vmovaps xmm10, [rsp+0xE0]
00007531fdbd296b  vmovaps [rsp+0xE0], xmm1
00007531fdbd2974  movaps xmm14, xmm10
00007531fdbd2978  addpd xmm14, xmm15
00007531fdbd297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007531fdbd2983  ptest xmm1, xmm1
00007531fdbd2988  jnz 0x00007531FDBD4277
00007531fdbd298e  vmovaps xmm1, [rsp+0x10]
00007531fdbd2994  vmovaps xmm15, [rsp+0x10]
00007531fdbd299a  por xmm1, xmm15
00007531fdbd299f  vmovaps xmm15, [rsp+0x20]
00007531fdbd29a5  vmovaps xmm10, [rsp+0x20]
00007531fdbd29ab  por xmm15, xmm10
00007531fdbd29b0  vmovaps [rsp+0x10], xmm5
00007531fdbd29b6  vmovaps xmm10, [rsp+0x10]
00007531fdbd29bc  por xmm5, xmm10
00007531fdbd29c1  vmovaps [rsp+0x10], xmm11
00007531fdbd29c7  vmovaps xmm10, [rsp+0x10]
00007531fdbd29cd  por xmm11, xmm10
00007531fdbd29d2  vmovaps [rsp+0x10], xmm4
00007531fdbd29d8  vmovaps xmm10, [rsp+0x10]
00007531fdbd29de  por xmm4, xmm10
00007531fdbd29e3  vmovaps [rsp+0x10], xmm8
00007531fdbd29e9  vmovaps xmm10, [rsp+0x10]
00007531fdbd29ef  por xmm8, xmm10
00007531fdbd29f4  vmovaps xmm10, [rsp+0xF0]
00007531fdbd29fd  vmovaps [rsp+0x10], xmm1
00007531fdbd2a03  vmovaps xmm1, [rsp+0xF0]
00007531fdbd2a0c  por xmm10, xmm1
00007531fdbd2a11  lea rax, [r14+0xA0]
00007531fdbd2a18  movups xmm1, [r13+rax*1]
00007531fdbd2a1e  lea rax, [r14+0xB0]
00007531fdbd2a25  vmovaps [rsp+0x20], xmm1
00007531fdbd2a2b  movups xmm1, [r13+rax*1]
00007531fdbd2a31  vmovaps [rsp+0xF0], xmm1
00007531fdbd2a3a  vmovaps [rsp+0x120], xmm15
00007531fdbd2a43  movaps xmm1, xmm13
00007531fdbd2a47  addpd xmm1, xmm2
00007531fdbd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007531fdbd2a50  ptest xmm15, xmm15
00007531fdbd2a56  jnz 0x00007531FDBD43CF
00007531fdbd2a5c  lea rax, [r14+0xF0]
00007531fdbd2a63  movups xmm15, [r13+rax*1]
00007531fdbd2a69  vmovaps xmm2, [rsp+0xE0]
00007531fdbd2a72  vmovaps [rsp+0xE0], xmm1
00007531fdbd2a7b  vmovaps xmm1, [rsp+0xD0]
00007531fdbd2a84  vmovaps [rsp+0xD0], xmm15
00007531fdbd2a8d  movaps xmm13, xmm2
00007531fdbd2a91  addpd xmm13, xmm1
00007531fdbd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007531fdbd2a9c  ptest xmm15, xmm15
00007531fdbd2aa2  jnz 0x00007531FDBD451A
00007531fdbd2aa8  vmovaps xmm15, [rsp+0xC0]
00007531fdbd2ab1  movaps xmm1, xmm14
00007531fdbd2ab5  addpd xmm1, xmm15
00007531fdbd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007531fdbd2abf  ptest xmm2, xmm2
00007531fdbd2ac4  jnz 0x00007531FDBD465C
00007531fdbd2aca  vmovaps xmm15, [rsp+0x100]
00007531fdbd2ad3  vpermilpd xmm15, xmm15, 0x00
00007531fdbd2ad9  vmovaps xmm2, [rsp+0xF0]
00007531fdbd2ae2  vmovaps [rsp+0xC0], xmm1
00007531fdbd2aeb  movaps xmm14, xmm2
00007531fdbd2aef  mulpd xmm14, xmm15
00007531fdbd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007531fdbd2afa  ptest xmm1, xmm1
00007531fdbd2aff  jnz 0x00007531FDBD479E
00007531fdbd2b05  vmovaps xmm1, [rsp+0xA0]
00007531fdbd2b0e  vpermilpd xmm1, xmm1, 0x00
00007531fdbd2b14  vmovaps xmm2, [rsp+0xD0]
00007531fdbd2b1d  vmovaps [rsp+0xD0], xmm14
00007531fdbd2b26  movaps xmm15, xmm2
00007531fdbd2b2a  mulpd xmm15, xmm1
00007531fdbd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007531fdbd2b35  ptest xmm14, xmm14
00007531fdbd2b3b  jnz 0x00007531FDBD48E1
00007531fdbd2b41  lea rax, [r14+0xE0]
00007531fdbd2b48  movups xmm1, [r13+rax*1]
00007531fdbd2b4e  vmovaps xmm14, [rsp+0x100]
00007531fdbd2b57  vpermilpd xmm14, xmm14, 0x00
00007531fdbd2b5d  vmovaps [rsp+0xF0], xmm1
00007531fdbd2b66  vmovaps xmm1, [rsp+0x20]
00007531fdbd2b6c  vmovaps [rsp+0x20], xmm15
00007531fdbd2b72  movaps xmm2, xmm1
00007531fdbd2b75  mulpd xmm2, xmm14
00007531fdbd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007531fdbd2b7f  ptest xmm15, xmm15
00007531fdbd2b85  jnz 0x00007531FDBD4A2D
00007531fdbd2b8b  vmovaps [rsp+0x100], xmm10
00007531fdbd2b94  vmovaps xmm1, [rsp+0x100]
00007531fdbd2b9d  por xmm10, xmm1
00007531fdbd2ba2  movaps [r15+0x300], xmm10
00007531fdbd2baa  vmovaps [rsp+0x100], xmm8
00007531fdbd2bb3  vmovaps xmm1, [rsp+0x100]
00007531fdbd2bbc  por xmm8, xmm1
00007531fdbd2bc1  movaps [r15+0x190], xmm8
00007531fdbd2bc9  vmovaps xmm1, [rsp+0xA0]
00007531fdbd2bd2  vpermilpd xmm1, xmm1, 0x00
00007531fdbd2bd8  vmovaps xmm14, [rsp+0xF0]
00007531fdbd2be1  vmovaps [rsp+0xF0], xmm13
00007531fdbd2bea  movaps xmm15, xmm14
00007531fdbd2bee  mulpd xmm15, xmm1
00007531fdbd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007531fdbd2bf9  ptest xmm13, xmm13
00007531fdbd2bff  jnz 0x00007531FDBD4B6E
00007531fdbd2c05  lea rax, [r14+0x90]
00007531fdbd2c0c  movups xmm1, [r13+rax*1]
00007531fdbd2c12  vmovaps [rsp+0x100], xmm4
00007531fdbd2c1b  vmovaps xmm14, [rsp+0x100]
00007531fdbd2c24  por xmm4, xmm14
00007531fdbd2c29  movaps [r15+0x1C0], xmm4
00007531fdbd2c31  vmovaps [rsp+0x100], xmm11
00007531fdbd2c3a  vmovaps xmm14, [rsp+0x100]
00007531fdbd2c43  por xmm11, xmm14
00007531fdbd2c48  movaps [r15+0x200], xmm11
00007531fdbd2c50  vmovaps [rsp+0x100], xmm5
00007531fdbd2c59  vmovaps xmm14, [rsp+0x100]
00007531fdbd2c62  por xmm5, xmm14
00007531fdbd2c67  movaps [r15+0x2D0], xmm5
00007531fdbd2c6f  vmovaps xmm14, [rsp+0x120]
00007531fdbd2c78  vmovaps xmm13, [rsp+0x120]
00007531fdbd2c81  por xmm14, xmm13
00007531fdbd2c86  movaps [r15+0x2E0], xmm14
00007531fdbd2c8e  vmovaps [rsp+0x100], xmm1
00007531fdbd2c97  vmovaps xmm1, [rsp+0x110]
00007531fdbd2ca0  vmovaps [rsp+0x110], xmm15
00007531fdbd2ca9  vmovaps xmm15, [rsp+0xD0]
00007531fdbd2cb2  vmovaps [rsp+0xD0], xmm14
00007531fdbd2cbb  movaps xmm13, xmm1
00007531fdbd2cbf  addpd xmm13, xmm15
00007531fdbd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007531fdbd2cca  ptest xmm14, xmm14
00007531fdbd2cd0  jnz 0x00007531FDBD4CBB
00007531fdbd2cd6  vmovaps xmm1, [rsp+0xA0]
00007531fdbd2cdf  vpermilpd xmm1, xmm1, 0x00
00007531fdbd2ce5  vmovaps xmm14, [rsp+0x100]
00007531fdbd2cee  vmovaps [rsp+0x100], xmm13
00007531fdbd2cf7  movaps xmm15, xmm14
00007531fdbd2cfb  mulpd xmm15, xmm1
00007531fdbd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007531fdbd2d06  ptest xmm13, xmm13
00007531fdbd2d0c  jnz 0x00007531FDBD4DFE
00007531fdbd2d12  lea rax, [r14+0x80]
00007531fdbd2d19  movups xmm1, [r13+rax*1]
00007531fdbd2d1f  vmovaps xmm13, [rsp+0xE0]
00007531fdbd2d28  vmovaps [rsp+0xE0], xmm1
00007531fdbd2d31  movaps xmm14, xmm13
00007531fdbd2d35  addpd xmm14, xmm2
00007531fdbd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007531fdbd2d40  ptest xmm1, xmm1
00007531fdbd2d45  jnz 0x00007531FDBD4F4B
00007531fdbd2d4b  vmovaps xmm13, [rsp+0xF0]
00007531fdbd2d54  vmovaps xmm2, [rsp+0x20]
00007531fdbd2d5a  vmovaps [rsp+0x20], xmm15
00007531fdbd2d60  movaps xmm1, xmm13
00007531fdbd2d64  addpd xmm1, xmm2
00007531fdbd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007531fdbd2d6d  ptest xmm15, xmm15
00007531fdbd2d73  jnz 0x00007531FDBD508E
00007531fdbd2d79  vmovaps xmm15, [rsp+0x10]
00007531fdbd2d7f  vmovaps xmm13, [rsp+0x10]
00007531fdbd2d85  por xmm15, xmm13
00007531fdbd2d8a  movaps [r15+0x2F0], xmm15
00007531fdbd2d92  vmovaps xmm13, [rsp+0xA0]
00007531fdbd2d9b  vpermilpd xmm13, xmm13, 0x00
00007531fdbd2da1  vmovaps [rsp+0x10], xmm1
00007531fdbd2da7  vmovaps xmm1, [rsp+0xE0]
00007531fdbd2db0  vmovaps [rsp+0xA0], xmm15
00007531fdbd2db9  movaps xmm2, xmm1
00007531fdbd2dbc  mulpd xmm2, xmm13
00007531fdbd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007531fdbd2dc6  ptest xmm15, xmm15
00007531fdbd2dcc  jnz 0x00007531FDBD51CF
00007531fdbd2dd2  lea rax, [r14+0xD0]
00007531fdbd2dd9  movups xmm1, [r13+rax*1]
00007531fdbd2ddf  vmovaps xmm13, [rsp+0xC0]
00007531fdbd2de8  vmovaps [rsp+0xC0], xmm1
00007531fdbd2df1  vmovaps xmm1, [rsp+0x110]
00007531fdbd2dfa  vmovaps [rsp+0xE0], xmm14
00007531fdbd2e03  movaps xmm15, xmm13
00007531fdbd2e07  addpd xmm15, xmm1
00007531fdbd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007531fdbd2e12  ptest xmm14, xmm14
00007531fdbd2e18  jnz 0x00007531FDBD531A
00007531fdbd2e1e  vmovaps xmm1, [rsp+0xB0]
00007531fdbd2e27  vpermilpd xmm1, xmm1, 0x00
00007531fdbd2e2d  movaps xmm14, xmm11
00007531fdbd2e31  mulpd xmm14, xmm1
00007531fdbd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007531fdbd2e3c  ptest xmm13, xmm13
00007531fdbd2e42  jnz 0x00007531FDBD545D
00007531fdbd2e48  movaps [r15+0x260], xmm14
00007531fdbd2e50  vxorps xmm1, xmm1, xmm1
00007531fdbd2e54  vpbroadcastq xmm1, xmm1
00007531fdbd2e59  movaps [r15+0x1B0], xmm1
00007531fdbd2e61  vmovaps xmm1, [rsp+0xB0]
00007531fdbd2e6a  vpermilpd xmm1, xmm1, 0x00
00007531fdbd2e70  vmovaps xmm11, [rsp+0xC0]
00007531fdbd2e79  vmovaps [rsp+0xC0], xmm15
00007531fdbd2e82  movaps xmm13, xmm11
00007531fdbd2e86  mulpd xmm13, xmm1
00007531fdbd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007531fdbd2e91  ptest xmm15, xmm15
00007531fdbd2e97  jnz 0x00007531FDBD55A0
00007531fdbd2e9d  lea rax, [r14+0xC0]
00007531fdbd2ea4  movups xmm1, [r13+rax*1]
00007531fdbd2eaa  vmovaps xmm11, [rsp+0x100]
00007531fdbd2eb3  vmovaps [rsp+0xF0], xmm1
00007531fdbd2ebc  vmovaps xmm1, [rsp+0x20]
00007531fdbd2ec2  vmovaps [rsp+0x20], xmm14
00007531fdbd2ec8  movaps xmm15, xmm11
00007531fdbd2ecc  addpd xmm15, xmm1
00007531fdbd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007531fdbd2ed7  ptest xmm14, xmm14
00007531fdbd2edd  jnz 0x00007531FDBD56ED
00007531fdbd2ee3  vmovaps [rsp+0x100], xmm9
00007531fdbd2eec  vmovaps xmm1, [rsp+0x100]
00007531fdbd2ef5  por xmm9, xmm1
00007531fdbd2efa  movaps [r15+0x270], xmm9
00007531fdbd2f02  vmovaps [rsp+0x100], xmm6
00007531fdbd2f0b  vmovaps xmm1, [rsp+0x100]
00007531fdbd2f14  por xmm6, xmm1
00007531fdbd2f18  movaps [r15+0x1A0], xmm6
00007531fdbd2f20  vmovaps xmm14, [rsp+0xB0]
00007531fdbd2f29  vpermilpd xmm14, xmm14, 0x00
00007531fdbd2f2f  vmovaps xmm6, [rsp+0xF0]
00007531fdbd2f38  vmovaps [rsp+0xF0], xmm1
00007531fdbd2f41  movaps xmm11, xmm6
00007531fdbd2f45  mulpd xmm11, xmm14
00007531fdbd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007531fdbd2f50  ptest xmm1, xmm1
00007531fdbd2f55  jnz 0x00007531FDBD5830
00007531fdbd2f5b  lea rax, [r14+0x20]
00007531fdbd2f5f  movups xmm1, [r13+rax*1]
00007531fdbd2f65  movaps [r15+0x110], xmm1
00007531fdbd2f6d  vmovaps xmm6, [rsp+0xE0]
00007531fdbd2f76  vmovaps [rsp+0xE0], xmm1
00007531fdbd2f7f  movaps xmm14, xmm6
00007531fdbd2f83  addpd xmm14, xmm2
00007531fdbd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007531fdbd2f8e  ptest xmm1, xmm1
00007531fdbd2f93  jnz 0x00007531FDBD597D
00007531fdbd2f99  vmovaps xmm1, [rsp+0xB0]
00007531fdbd2fa2  vpermilpd xmm1, xmm1, 0x00
00007531fdbd2fa8  movaps xmm6, xmm5
00007531fdbd2fab  mulpd xmm6, xmm1
00007531fdbd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007531fdbd2fb4  ptest xmm2, xmm2
00007531fdbd2fb9  jnz 0x00007531FDBD5ABF
00007531fdbd2fbf  vmovaps xmm5, [rsp+0x10]
00007531fdbd2fc5  movaps xmm1, xmm5
00007531fdbd2fc8  addpd xmm1, xmm13
00007531fdbd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007531fdbd2fd2  ptest xmm2, xmm2
00007531fdbd2fd7  jnz 0x00007531FDBD5BFF
00007531fdbd2fdd  vmovaps xmm13, [rsp+0x80]
00007531fdbd2fe6  vpermilpd xmm13, xmm13, 0x00
00007531fdbd2fec  vmovaps xmm2, [rsp+0xE0]
00007531fdbd2ff5  vmovaps [rsp+0x10], xmm1
00007531fdbd2ffb  movaps xmm5, xmm2
00007531fdbd2ffe  mulpd xmm5, xmm13
00007531fdbd3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007531fdbd3008  ptest xmm1, xmm1
00007531fdbd300d  jnz 0x00007531FDBD5D40
00007531fdbd3013  vmovaps xmm1, [rsp+0x80]
00007531fdbd301c  vpermilpd xmm1, xmm1, 0x00
00007531fdbd3022  movaps xmm13, xmm10
00007531fdbd3026  mulpd xmm13, xmm1
00007531fdbd302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007531fdbd3031  ptest xmm2, xmm2
00007531fdbd3036  jnz 0x00007531FDBD5E81
00007531fdbd303c  vmovaps xmm10, [rsp+0x20]
00007531fdbd3042  movaps xmm1, xmm15
00007531fdbd3046  addpd xmm1, xmm10
00007531fdbd304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007531fdbd3050  ptest xmm2, xmm2
00007531fdbd3055  jnz 0x00007531FDBD5FC4
00007531fdbd305b  vmovaps xmm10, [rsp+0xC0]
00007531fdbd3064  movaps xmm15, xmm10
00007531fdbd3068  addpd xmm15, xmm11
00007531fdbd306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007531fdbd3073  ptest xmm2, xmm2
00007531fdbd3078  jnz 0x00007531FDBD6106
00007531fdbd307e  vmovaps xmm11, [rsp+0x80]
00007531fdbd3087  vpermilpd xmm11, xmm11, 0x00
00007531fdbd308d  vmovaps xmm2, [rsp+0xD0]
00007531fdbd3096  vmovaps [rsp+0x20], xmm1
00007531fdbd309c  movaps xmm10, xmm2
00007531fdbd30a0  mulpd xmm10, xmm11
00007531fdbd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007531fdbd30ab  ptest xmm1, xmm1
00007531fdbd30b0  jnz 0x00007531FDBD624A
00007531fdbd30b6  vmovaps xmm1, [rsp+0x80]
00007531fdbd30bf  vpermilpd xmm1, xmm1, 0x00
00007531fdbd30c5  vmovaps xmm2, [rsp+0xA0]
00007531fdbd30ce  vmovaps [rsp+0x80], xmm15
00007531fdbd30d7  movaps xmm11, xmm2
00007531fdbd30db  mulpd xmm11, xmm1
00007531fdbd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007531fdbd30e6  ptest xmm15, xmm15
00007531fdbd30ec  jnz 0x00007531FDBD638D
00007531fdbd30f2  movaps xmm1, xmm14
00007531fdbd30f6  addpd xmm1, xmm6
00007531fdbd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007531fdbd30ff  ptest xmm15, xmm15
00007531fdbd3105  jnz 0x00007531FDBD64CF
00007531fdbd310b  vmovaps xmm14, [rsp+0x10]
00007531fdbd3111  movaps xmm15, xmm14
00007531fdbd3115  addpd xmm15, xmm5
00007531fdbd311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007531fdbd3120  ptest xmm6, xmm6
00007531fdbd3125  jnz 0x00007531FDBD6610
00007531fdbd312b  vmovaps xmm14, [rsp+0x90]
00007531fdbd3134  vpermilpd xmm14, xmm14, 0x00
00007531fdbd313a  movaps xmm6, xmm9
00007531fdbd313e  mulpd xmm6, xmm14
00007531fdbd3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007531fdbd3148  ptest xmm5, xmm5
00007531fdbd314d  jnz 0x00007531FDBD6753
00007531fdbd3153  vmovaps xmm9, [rsp+0x80]
00007531fdbd315c  movaps xmm14, xmm9
00007531fdbd3160  addpd xmm14, xmm13
00007531fdbd3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007531fdbd316b  ptest xmm5, xmm5
00007531fdbd3170  jnz 0x00007531FDBD6895
00007531fdbd3176  vmovaps xmm9, [rsp+0x20]
00007531fdbd317c  movaps xmm13, xmm9
00007531fdbd3180  addpd xmm13, xmm10
00007531fdbd3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007531fdbd318b  ptest xmm5, xmm5
00007531fdbd3190  jnz 0x00007531FDBD69D9
00007531fdbd3196  vmovaps [rsp+0x10], xmm12
00007531fdbd319c  vmovaps xmm10, [rsp+0x10]
00007531fdbd31a2  por xmm12, xmm10
00007531fdbd31a7  movaps [r15+0x250], xmm12
00007531fdbd31af  vmovaps [rsp+0x10], xmm7
00007531fdbd31b5  vmovaps xmm12, [rsp+0x10]
00007531fdbd31bb  por xmm7, xmm12
00007531fdbd31c0  movaps [r15+0x2A0], xmm7
00007531fdbd31c8  vmovaps [rsp+0x10], xmm3
00007531fdbd31ce  vmovaps xmm12, [rsp+0x10]
00007531fdbd31d4  por xmm3, xmm12
00007531fdbd31d9  movaps [r15+0x1D0], xmm3
00007531fdbd31e1  lea rax, [r14+0x40]
00007531fdbd31e5  movups xmm12, [r13+rax*1]
00007531fdbd31eb  movaps [r15+0x2C0], xmm12
00007531fdbd31f3  vmovaps xmm10, [rsp+0x90]
00007531fdbd31fc  vpermilpd xmm10, xmm10, 0x00
00007531fdbd3202  movaps xmm9, xmm8
00007531fdbd3206  mulpd xmm9, xmm10
00007531fdbd320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007531fdbd3211  ptest xmm5, xmm5
00007531fdbd3216  jnz 0x00007531FDBD6B27
00007531fdbd321c  movaps xmm10, xmm1
00007531fdbd3220  addpd xmm10, xmm11
00007531fdbd3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007531fdbd322b  ptest xmm8, xmm8
00007531fdbd3231  jnz 0x00007531FDBD6C6B
00007531fdbd3237  movaps xmm1, xmm15
00007531fdbd323b  addpd xmm1, xmm6
00007531fdbd323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007531fdbd3244  ptest xmm11, xmm11
00007531fdbd324a  jnz 0x00007531FDBD6DAE
00007531fdbd3250  vmovaps xmm15, [rsp+0x90]
00007531fdbd3259  vpermilpd xmm15, xmm15, 0x00
00007531fdbd325f  movaps xmm11, xmm12
00007531fdbd3263  mulpd xmm11, xmm15
00007531fdbd3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007531fdbd326e  ptest xmm8, xmm8
00007531fdbd3274  jnz 0x00007531FDBD6EEF
00007531fdbd327a  vmovaps xmm15, [rsp+0x90]
00007531fdbd3283  vpermilpd xmm15, xmm15, 0x00
00007531fdbd3289  vmovaps xmm8, [rsp+0x50]
00007531fdbd328f  movaps xmm12, xmm8
00007531fdbd3293  mulpd xmm12, xmm15
00007531fdbd3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007531fdbd329e  ptest xmm6, xmm6
00007531fdbd32a3  jnz 0x00007531FDBD7033
00007531fdbd32a9  vmovaps xmm15, [rsp+0x30]
00007531fdbd32af  vpermilpd xmm15, xmm15, 0x00
00007531fdbd32b5  movaps xmm8, xmm7
00007531fdbd32b9  mulpd xmm8, xmm15
00007531fdbd32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007531fdbd32c4  ptest xmm6, xmm6
00007531fdbd32c9  jnz 0x00007531FDBD7177
00007531fdbd32cf  movaps xmm15, xmm14
00007531fdbd32d3  addpd xmm15, xmm9
00007531fdbd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007531fdbd32de  ptest xmm7, xmm7
00007531fdbd32e3  jnz 0x00007531FDBD72BA
00007531fdbd32e9  vmovaps xmm14, [rsp+0x30]
00007531fdbd32ef  vpermilpd xmm14, xmm14, 0x00
00007531fdbd32f5  vmovaps xmm7, [rsp+0xF0]
00007531fdbd32fe  movaps xmm9, xmm7
00007531fdbd3302  mulpd xmm9, xmm14
00007531fdbd3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007531fdbd330d  ptest xmm6, xmm6
00007531fdbd3312  jnz 0x00007531FDBD73FE
00007531fdbd3318  movaps xmm14, xmm13
00007531fdbd331c  addpd xmm14, xmm11
00007531fdbd3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007531fdbd3327  ptest xmm7, xmm7
00007531fdbd332c  jnz 0x00007531FDBD7541
00007531fdbd3332  vmovaps xmm13, [rsp+0x30]
00007531fdbd3338  vpermilpd xmm13, xmm13, 0x00
00007531fdbd333e  vmovaps xmm7, [rsp+0x60]
00007531fdbd3344  movaps xmm11, xmm7
00007531fdbd3348  mulpd xmm11, xmm13
00007531fdbd334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007531fdbd3353  ptest xmm6, xmm6
00007531fdbd3358  jnz 0x00007531FDBD7685
00007531fdbd335e  movaps xmm13, xmm10
00007531fdbd3362  addpd xmm13, xmm12
00007531fdbd3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007531fdbd336d  ptest xmm7, xmm7
00007531fdbd3372  jnz 0x00007531FDBD77C8
00007531fdbd3378  vmovaps xmm12, [rsp+0x30]
00007531fdbd337e  vpermilpd xmm12, xmm12, 0x00
00007531fdbd3384  vmovaps xmm7, [rsp+0x70]
00007531fdbd338a  movaps xmm10, xmm7
00007531fdbd338e  mulpd xmm10, xmm12
00007531fdbd3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007531fdbd3399  ptest xmm6, xmm6
00007531fdbd339e  jnz 0x00007531FDBD790C
00007531fdbd33a4  movaps xmm12, xmm1
00007531fdbd33a8  addpd xmm12, xmm8
00007531fdbd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007531fdbd33b3  ptest xmm7, xmm7
00007531fdbd33b8  jnz 0x00007531FDBD7A4F
00007531fdbd33be  lea rax, [r14+0x70]
00007531fdbd33c2  movups xmm1, [r13+rax*1]
00007531fdbd33c8  movaps [r15+0x240], xmm1
00007531fdbd33d0  movaps xmm8, xmm15
00007531fdbd33d4  addpd xmm8, xmm9
00007531fdbd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007531fdbd33df  ptest xmm7, xmm7
00007531fdbd33e4  jnz 0x00007531FDBD7B9C
00007531fdbd33ea  movaps [r15+0x170], xmm8
00007531fdbd33f2  vmovaps xmm15, [rsp+0x40]
00007531fdbd33f8  vpermilpd xmm15, xmm15, 0x00
00007531fdbd33fe  movaps xmm9, xmm1
00007531fdbd3402  mulpd xmm9, xmm15
00007531fdbd3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007531fdbd340d  ptest xmm7, xmm7
00007531fdbd3412  jnz 0x00007531FDBD7CE0
00007531fdbd3418  vmovaps xmm1, [rsp+0x40]
00007531fdbd341e  vpermilpd xmm1, xmm1, 0x00
00007531fdbd3424  movaps xmm15, xmm4
00007531fdbd3428  mulpd xmm15, xmm1
00007531fdbd342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007531fdbd3433  ptest xmm7, xmm7
00007531fdbd3438  jnz 0x00007531FDBD7E23
00007531fdbd343e  movaps [r15+0x180], xmm15
00007531fdbd3446  movaps xmm1, xmm14
00007531fdbd344a  addpd xmm1, xmm11
00007531fdbd344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007531fdbd3454  ptest xmm7, xmm7
00007531fdbd3459  jnz 0x00007531FDBD7F65
00007531fdbd345f  movaps [r15+0x210], xmm1
00007531fdbd3467  movups xmm14, [r13+r14*1]
00007531fdbd346d  lea rax, [r14+0x10]
00007531fdbd3471  movups xmm11, [r13+rax*1]
00007531fdbd3477  movaps [r15+0x230], xmm11
00007531fdbd347f  movaps xmm7, xmm13
00007531fdbd3483  addpd xmm7, xmm10
00007531fdbd3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007531fdbd348d  ptest xmm6, xmm6
00007531fdbd3492  jnz 0x00007531FDBD80BB
00007531fdbd3498  movaps [r15+0x130], xmm7
00007531fdbd34a0  vmovaps xmm13, [rsp+0x40]
00007531fdbd34a6  vpermilpd xmm13, xmm13, 0x00
00007531fdbd34ac  movaps xmm10, xmm11
00007531fdbd34b0  mulpd xmm10, xmm13
00007531fdbd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007531fdbd34bb  ptest xmm6, xmm6
00007531fdbd34c0  jnz 0x00007531FDBD81FD
00007531fdbd34c6  movaps [r15+0x220], xmm10
00007531fdbd34ce  vmovaps xmm13, [rsp+0x40]
00007531fdbd34d4  vpermilpd xmm13, xmm13, 0x00
00007531fdbd34da  movaps xmm11, xmm14
00007531fdbd34de  mulpd xmm11, xmm13
00007531fdbd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007531fdbd34e9  ptest xmm6, xmm6
00007531fdbd34ee  jnz 0x00007531FDBD8341
00007531fdbd34f4  movaps xmm14, xmm12
00007531fdbd34f8  addpd xmm14, xmm9
00007531fdbd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007531fdbd3503  ptest xmm13, xmm13
00007531fdbd3509  jnz 0x00007531FDBD8485
00007531fdbd350f  movaps [r15+0x140], xmm14
00007531fdbd3517  movaps xmm13, xmm8
00007531fdbd351b  addpd xmm13, xmm15
00007531fdbd3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007531fdbd3526  ptest xmm12, xmm12
00007531fdbd352c  jnz 0x00007531FDBD85C9
00007531fdbd3532  movaps [r15+0x150], xmm13
00007531fdbd353a  movaps xmm15, xmm1
00007531fdbd353e  addpd xmm15, xmm10
00007531fdbd3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007531fdbd3549  ptest xmm12, xmm12
00007531fdbd354f  jnz 0x00007531FDBD870D
00007531fdbd3555  movaps [r15+0x160], xmm15
00007531fdbd355d  movaps xmm1, xmm7
00007531fdbd3560  addpd xmm1, xmm11
00007531fdbd3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007531fdbd356a  ptest xmm12, xmm12
00007531fdbd3570  jnz 0x00007531FDBD8850
00007531fdbd3576  movaps [r15+0x120], xmm1
00007531fdbd357e  mov eax, 0x432200
00007531fdbd3583  movups [r13+rax*1], xmm14
00007531fdbd3589  mov eax, 0x432210
00007531fdbd358e  movups [r13+rax*1], xmm13
00007531fdbd3594  mov eax, 0x432220
00007531fdbd3599  movups [r13+rax*1], xmm15
00007531fdbd359f  mov eax, 0x432230
00007531fdbd35a4  movups [r13+rax*1], xmm1
00007531fdbd35aa  mov eax, [r15+0x108]
00007531fdbd35b1  sahf
00007531fdbd35b2  jnz 0x00007531FDBD35E4
00007531fdbd35b4  cmp dword ptr [r15+0x318], 0x00
00007531fdbd35bc  jz 0x00007531FDBDEAE0
00007531fdbd35c2  nop [rax+rax*1], ax
00007531fdbd35cb  nop [rax+rax*1], eax
00007531fdbd35d3  mov eax, 0x4106D0
00007531fdbd35d8  mov [r15+0x100], rax
00007531fdbd35df  jmp 0x00007531FD9FE110
00007531fdbd35e4  cmp dword ptr [r15+0x318], 0x00
00007531fdbd35ec  jz 0x00007531FDBD89C0
00007531fdbd35f2  nop [rax+rax*1], ax
00007531fdbd35fb  nop [rax+rax*1], eax
00007531fdbd3603  mov eax, 0x410504
00007531fdbd3608  mov [r15+0x100], rax
00007531fdbd360f  jmp 0x00007531FD9FE110
00007531fdbd3614  int3
00007531fdbd3615  call 0x00007531FDAD64F0
00007531fdbd361a  jmp 0x00007531FDBD2311
00007531fdbd361f  call 0x00007531FDAE5820
00007531fdbd3624  jmp 0x00007531FDBD231E
00007531fdbd3629  call 0x00007531FDAE3320
00007531fdbd362e  jmp 0x00007531FDBD2332
00007531fdbd3633  call 0x00007531FDAE20A0
00007531fdbd3638  jmp 0x00007531FDBD233C
00007531fdbd363d  call 0x00007531FDA09D70
00007531fdbd3642  jmp 0x00007531FDBD234A
00007531fdbd3647  call 0x00007531FDADFBC0
00007531fdbd364c  jmp 0x00007531FDBD2354
00007531fdbd3651  call 0x00007531FDAC4740
00007531fdbd3656  jmp 0x00007531FDBD2368
00007531fdbd365b  call 0x00007531FDAB5400
00007531fdbd3660  jmp 0x00007531FDBD2375
00007531fdbd3665  call 0x00007531FDAB52F0
00007531fdbd366a  jmp 0x00007531FDBD2382
00007531fdbd366f  call 0x00007531FDAC4620
00007531fdbd3674  jmp 0x00007531FDBD238F
00007531fdbd3679  call 0x00007531FDABD750
00007531fdbd367e  jmp 0x00007531FDBD239C
00007531fdbd3683  call 0x00007531FDABC4E0
00007531fdbd3688  jmp 0x00007531FDBD23A9
00007531fdbd368d  call 0x00007531FDABB270
00007531fdbd3692  jmp 0x00007531FDBD23B6
00007531fdbd3697  call 0x00007531FDABA000
00007531fdbd369c  jmp 0x00007531FDBD23C3
00007531fdbd36a1  call 0x00007531FDAC4740
00007531fdbd36a6  jmp 0x00007531FDBD23D0
00007531fdbd36ab  call 0x00007531FDAB5400
00007531fdbd36b0  jmp 0x00007531FDBD23DD
00007531fdbd36b5  call 0x00007531FDAB52F0
00007531fdbd36ba  jmp 0x00007531FDBD23EA
00007531fdbd36bf  call 0x00007531FDAC4620
00007531fdbd36c4  jmp 0x00007531FDBD23F7
00007531fdbd36c9  call 0x00007531FDAB8D90
00007531fdbd36ce  jmp 0x00007531FDBD2404
00007531fdbd36d3  call 0x00007531FDAB8A20
00007531fdbd36d8  jmp 0x00007531FDBD2411
00007531fdbd36dd  call 0x00007531FDAB77B0
00007531fdbd36e2  jmp 0x00007531FDBD241B
00007531fdbd36e7  call 0x00007531FDAB6550
00007531fdbd36ec  jmp 0x00007531FDBD2425
00007531fdbd36f1  call 0x00007531FDAB5400
00007531fdbd36f6  jmp 0x00007531FDBD2437
00007531fdbd36fb  call 0x00007531FDAC0FC0
00007531fdbd3700  jmp 0x00007531FDBD2441
00007531fdbd3705  call 0x00007531FDAB52F0
00007531fdbd370a  jmp 0x00007531FDBD244B
00007531fdbd370f  call 0x00007531FDAC0EA0
00007531fdbd3714  jmp 0x00007531FDBD2455
00007531fdbd3719  call 0x00007531FDABFD50
00007531fdbd371e  jmp 0x00007531FDBD245F
00007531fdbd3723  call 0x00007531FDAB8EA0
00007531fdbd3728  jmp 0x00007531FDBD2469
00007531fdbd372d  call 0x00007531FDABFC30
00007531fdbd3732  jmp 0x00007531FDBD2476
00007531fdbd3737  call 0x00007531FDAB8D90
00007531fdbd373c  jmp 0x00007531FDBD2483
00007531fdbd3741  call 0x00007531FDAB52F0
00007531fdbd3746  jmp 0x00007531FDBD2496
00007531fdbd374b  call 0x00007531FDAB52F0
00007531fdbd3750  jmp 0x00007531FDBD24A9
00007531fdbd3755  call 0x00007531FDAC0FC0
00007531fdbd375a  jmp 0x00007531FDBD24B6
00007531fdbd375f  call 0x00007531FDAC0FC0
00007531fdbd3764  jmp 0x00007531FDBD24C9
00007531fdbd3769  call 0x00007531FDAC0EA0
00007531fdbd376e  jmp 0x00007531FDBD24D6
00007531fdbd3773  call 0x00007531FDAB52F0
00007531fdbd3778  jmp 0x00007531FDBD24E9
00007531fdbd377d  call 0x00007531FDAB52F0
00007531fdbd3782  jmp 0x00007531FDBD24FC
00007531fdbd3787  call 0x00007531FDAB52F0
00007531fdbd378c  jmp 0x00007531FDBD250F
00007531fdbd3791  call 0x00007531FDAB52F0
00007531fdbd3796  jmp 0x00007531FDBD252A
00007531fdbd379b  call 0x00007531FDAB52F0
00007531fdbd37a0  jmp 0x00007531FDBD253D
00007531fdbd37a5  call 0x00007531FDAB5400
00007531fdbd37aa  jmp 0x00007531FDBD257E
00007531fdbd37af  call 0x00007531FDAC0FC0
00007531fdbd37b4  jmp 0x00007531FDBD258B
00007531fdbd37b9  call 0x00007531FDAB52F0
00007531fdbd37be  jmp 0x00007531FDBD2598
00007531fdbd37c3  call 0x00007531FDAC0EA0
00007531fdbd37c8  jmp 0x00007531FDBD25A5
00007531fdbd37cd  call 0x00007531FD9FF540
00007531fdbd37d2  jmp 0x00007531FDBD25C3
00007531fdbd37d7  call 0x00007531FDA08C20
00007531fdbd37dc  jmp 0x00007531FDBD25CD
00007531fdbd37e1  call 0x00007531FDAE21C0
00007531fdbd37e6  jmp 0x00007531FDBD25D3
00007531fdbd37eb  call 0x00007531FD9FF540
00007531fdbd37f0  jmp 0x00007531FDBD25E3
00007531fdbd37f5  call 0x00007531FDAC0370
00007531fdbd37fa  jmp 0x00007531FDBD2611
00007531fdbd37ff  call 0x00007531FDABF100
00007531fdbd3804  jmp 0x00007531FDBD261A
00007531fdbd3809  call 0x00007531FDAC0370
00007531fdbd380e  jmp 0x00007531FDBD2674
00007531fdbd3813  call 0x00007531FDABF100
00007531fdbd3818  jmp 0x00007531FDBD267D
00007531fdbd381d  call 0x00007531FDAC0370
00007531fdbd3822  jmp 0x00007531FDBD26C6
00007531fdbd3827  call 0x00007531FDABF100
00007531fdbd382c  jmp 0x00007531FDBD26CF
00007531fdbd3831  call 0x00007531FDA0B720
00007531fdbd3836  jmp 0x00007531FDBD2714
00007531fdbd383b  call 0x00007531FDAB47C0
00007531fdbd3840  jmp 0x00007531FDBD2727
00007531fdbd3845  call 0x00007531FDA08B00
00007531fdbd384a  jmp 0x00007531FDBD273E
00007531fdbd384f  call 0x00007531FD9FF430
00007531fdbd3854  jmp 0x00007531FDBD2751
00007531fdbd3859  call 0x00007531FD9FF430
00007531fdbd385e  jmp 0x00007531FDBD2764
00007531fdbd3863  sub rsp, 0x08
00007531fdbd3867  push rax
00007531fdbd3868  push rcx
00007531fdbd3869  push rdx
00007531fdbd386a  push rdi
00007531fdbd386b  push rsi
00007531fdbd386c  push r8
00007531fdbd386e  push r9
00007531fdbd3870  push r10
00007531fdbd3872  push r11
00007531fdbd3874  sub rsp, 0xF0
00007531fdbd387b  vmovaps [rsp], xmm0
00007531fdbd3880  vmovaps [rsp+0x10], xmm2
00007531fdbd3886  vmovaps [rsp+0x20], xmm3
00007531fdbd388c  vmovaps [rsp+0x30], xmm4
00007531fdbd3892  vmovaps [rsp+0x40], xmm5
00007531fdbd3898  vmovaps [rsp+0x50], xmm6
00007531fdbd389e  vmovaps [rsp+0x60], xmm7
00007531fdbd38a4  vmovaps [rsp+0x70], xmm8
00007531fdbd38aa  vmovaps [rsp+0x80], xmm9
00007531fdbd38b3  vmovaps [rsp+0x90], xmm10
00007531fdbd38bc  vmovaps [rsp+0xA0], xmm11
00007531fdbd38c5  vmovaps [rsp+0xB0], xmm12
00007531fdbd38ce  vmovaps [rsp+0xC0], xmm13
00007531fdbd38d7  vmovaps [rsp+0xD0], xmm14
00007531fdbd38e0  vmovaps [rsp+0xE0], xmm15
00007531fdbd38e9  sub rsp, 0x30
00007531fdbd38ed  movaps [rsp], xmm1
00007531fdbd38f1  movaps [rsp+0x10], xmm12
00007531fdbd38f7  movaps [rsp+0x20], xmm15
00007531fdbd38fd  lea rdi, [rsp]
00007531fdbd3901  mov esi, 0x00
00007531fdbd3906  mov rax, 0x59ED111DF530
00007531fdbd3910  call rax
00007531fdbd3912  movaps xmm1, [rsp]
00007531fdbd3916  add rsp, 0x30
00007531fdbd391a  vmovaps xmm0, [rsp]
00007531fdbd391f  vmovaps xmm2, [rsp+0x10]
00007531fdbd3925  vmovaps xmm3, [rsp+0x20]
00007531fdbd392b  vmovaps xmm4, [rsp+0x30]
00007531fdbd3931  vmovaps xmm5, [rsp+0x40]
00007531fdbd3937  vmovaps xmm6, [rsp+0x50]
00007531fdbd393d  vmovaps xmm7, [rsp+0x60]
00007531fdbd3943  vmovaps xmm8, [rsp+0x70]
00007531fdbd3949  vmovaps xmm9, [rsp+0x80]
00007531fdbd3952  vmovaps xmm10, [rsp+0x90]
00007531fdbd395b  vmovaps xmm11, [rsp+0xA0]
00007531fdbd3964  vmovaps xmm12, [rsp+0xB0]
00007531fdbd396d  vmovaps xmm13, [rsp+0xC0]
00007531fdbd3976  vmovaps xmm14, [rsp+0xD0]
00007531fdbd397f  vmovaps xmm15, [rsp+0xE0]
00007531fdbd3988  add rsp, 0xF0
00007531fdbd398f  pop r11
00007531fdbd3991  pop r10
00007531fdbd3993  pop r9
00007531fdbd3995  pop r8
00007531fdbd3997  pop rsi
00007531fdbd3998  pop rdi
00007531fdbd3999  pop rdx
00007531fdbd399a  pop rcx
00007531fdbd399b  pop rax
00007531fdbd399c  add rsp, 0x08
00007531fdbd39a0  jmp 0x00007531FDBD27B2
00007531fdbd39a5  sub rsp, 0x08
00007531fdbd39a9  push rax
00007531fdbd39aa  push rcx
00007531fdbd39ab  push rdx
00007531fdbd39ac  push rdi
00007531fdbd39ad  push rsi
00007531fdbd39ae  push r8
00007531fdbd39b0  push r9
00007531fdbd39b2  push r10
00007531fdbd39b4  push r11
00007531fdbd39b6  sub rsp, 0xF0
00007531fdbd39bd  vmovaps [rsp], xmm0
00007531fdbd39c2  vmovaps [rsp+0x10], xmm1
00007531fdbd39c8  vmovaps [rsp+0x20], xmm2
00007531fdbd39ce  vmovaps [rsp+0x30], xmm3
00007531fdbd39d4  vmovaps [rsp+0x40], xmm4
00007531fdbd39da  vmovaps [rsp+0x50], xmm5
00007531fdbd39e0  vmovaps [rsp+0x60], xmm6
00007531fdbd39e6  vmovaps [rsp+0x70], xmm7
00007531fdbd39ec  vmovaps [rsp+0x80], xmm8
00007531fdbd39f5  vmovaps [rsp+0x90], xmm9
00007531fdbd39fe  vmovaps [rsp+0xA0], xmm10
00007531fdbd3a07  vmovaps [rsp+0xB0], xmm11
00007531fdbd3a10  vmovaps [rsp+0xC0], xmm12
00007531fdbd3a19  vmovaps [rsp+0xD0], xmm13
00007531fdbd3a22  vmovaps [rsp+0xE0], xmm15
00007531fdbd3a2b  sub rsp, 0x30
00007531fdbd3a2f  movaps [rsp], xmm14
00007531fdbd3a34  movaps [rsp+0x10], xmm1
00007531fdbd3a39  movaps [rsp+0x20], xmm15
00007531fdbd3a3f  lea rdi, [rsp]
00007531fdbd3a43  mov esi, 0x00
00007531fdbd3a48  mov rax, 0x59ED111DF530
00007531fdbd3a52  call rax
00007531fdbd3a54  movaps xmm14, [rsp]
00007531fdbd3a59  add rsp, 0x30
00007531fdbd3a5d  vmovaps xmm0, [rsp]
00007531fdbd3a62  vmovaps xmm1, [rsp+0x10]
00007531fdbd3a68  vmovaps xmm2, [rsp+0x20]
00007531fdbd3a6e  vmovaps xmm3, [rsp+0x30]
00007531fdbd3a74  vmovaps xmm4, [rsp+0x40]
00007531fdbd3a7a  vmovaps xmm5, [rsp+0x50]
00007531fdbd3a80  vmovaps xmm6, [rsp+0x60]
00007531fdbd3a86  vmovaps xmm7, [rsp+0x70]
00007531fdbd3a8c  vmovaps xmm8, [rsp+0x80]
00007531fdbd3a95  vmovaps xmm9, [rsp+0x90]
00007531fdbd3a9e  vmovaps xmm10, [rsp+0xA0]
00007531fdbd3aa7  vmovaps xmm11, [rsp+0xB0]
00007531fdbd3ab0  vmovaps xmm12, [rsp+0xC0]
00007531fdbd3ab9  vmovaps xmm13, [rsp+0xD0]
00007531fdbd3ac2  vmovaps xmm15, [rsp+0xE0]
00007531fdbd3acb  add rsp, 0xF0
00007531fdbd3ad2  pop r11
00007531fdbd3ad4  pop r10
00007531fdbd3ad6  pop r9
00007531fdbd3ad8  pop r8
00007531fdbd3ada  pop rsi
00007531fdbd3adb  pop rdi
00007531fdbd3adc  pop rdx
00007531fdbd3add  pop rcx
00007531fdbd3ade  pop rax
00007531fdbd3adf  add rsp, 0x08
00007531fdbd3ae3  jmp 0x00007531FDBD2800
00007531fdbd3ae8  sub rsp, 0x08
00007531fdbd3aec  push rax
00007531fdbd3aed  push rcx
00007531fdbd3aee  push rdx
00007531fdbd3aef  push rdi
00007531fdbd3af0  push rsi
00007531fdbd3af1  push r8
00007531fdbd3af3  push r9
00007531fdbd3af5  push r10
00007531fdbd3af7  push r11
00007531fdbd3af9  sub rsp, 0xF0
00007531fdbd3b00  vmovaps [rsp], xmm0
00007531fdbd3b05  vmovaps [rsp+0x10], xmm1
00007531fdbd3b0b  vmovaps [rsp+0x20], xmm2
00007531fdbd3b11  vmovaps [rsp+0x30], xmm3
00007531fdbd3b17  vmovaps [rsp+0x40], xmm4
00007531fdbd3b1d  vmovaps [rsp+0x50], xmm5
00007531fdbd3b23  vmovaps [rsp+0x60], xmm6
00007531fdbd3b29  vmovaps [rsp+0x70], xmm7
00007531fdbd3b2f  vmovaps [rsp+0x80], xmm8
00007531fdbd3b38  vmovaps [rsp+0x90], xmm9
00007531fdbd3b41  vmovaps [rsp+0xA0], xmm10
00007531fdbd3b4a  vmovaps [rsp+0xB0], xmm11
00007531fdbd3b53  vmovaps [rsp+0xC0], xmm12
00007531fdbd3b5c  vmovaps [rsp+0xD0], xmm13
00007531fdbd3b65  vmovaps [rsp+0xE0], xmm14
00007531fdbd3b6e  sub rsp, 0x30
00007531fdbd3b72  movaps [rsp], xmm15
00007531fdbd3b77  movaps [rsp+0x10], xmm12
00007531fdbd3b7d  movaps [rsp+0x20], xmm13
00007531fdbd3b83  lea rdi, [rsp]
00007531fdbd3b87  mov esi, 0x00
00007531fdbd3b8c  mov rax, 0x59ED111DF530
00007531fdbd3b96  call rax
00007531fdbd3b98  movaps xmm15, [rsp]
00007531fdbd3b9d  add rsp, 0x30
00007531fdbd3ba1  vmovaps xmm0, [rsp]
00007531fdbd3ba6  vmovaps xmm1, [rsp+0x10]
00007531fdbd3bac  vmovaps xmm2, [rsp+0x20]
00007531fdbd3bb2  vmovaps xmm3, [rsp+0x30]
00007531fdbd3bb8  vmovaps xmm4, [rsp+0x40]
00007531fdbd3bbe  vmovaps xmm5, [rsp+0x50]
00007531fdbd3bc4  vmovaps xmm6, [rsp+0x60]
00007531fdbd3bca  vmovaps xmm7, [rsp+0x70]
00007531fdbd3bd0  vmovaps xmm8, [rsp+0x80]
00007531fdbd3bd9  vmovaps xmm9, [rsp+0x90]
00007531fdbd3be2  vmovaps xmm10, [rsp+0xA0]
00007531fdbd3beb  vmovaps xmm11, [rsp+0xB0]
00007531fdbd3bf4  vmovaps xmm12, [rsp+0xC0]
00007531fdbd3bfd  vmovaps xmm13, [rsp+0xD0]
00007531fdbd3c06  vmovaps xmm14, [rsp+0xE0]
00007531fdbd3c0f  add rsp, 0xF0
00007531fdbd3c16  pop r11
00007531fdbd3c18  pop r10
00007531fdbd3c1a  pop r9
00007531fdbd3c1c  pop r8
00007531fdbd3c1e  pop rsi
00007531fdbd3c1f  pop rdi
00007531fdbd3c20  pop rdx
00007531fdbd3c21  pop rcx
00007531fdbd3c22  pop rax
00007531fdbd3c23  add rsp, 0x08
00007531fdbd3c27  jmp 0x00007531FDBD2835
00007531fdbd3c2c  sub rsp, 0x08
00007531fdbd3c30  push rax
00007531fdbd3c31  push rcx
00007531fdbd3c32  push rdx
00007531fdbd3c33  push rdi
00007531fdbd3c34  push rsi
00007531fdbd3c35  push r8
00007531fdbd3c37  push r9
00007531fdbd3c39  push r10
00007531fdbd3c3b  push r11
00007531fdbd3c3d  sub rsp, 0xF0
00007531fdbd3c44  vmovaps [rsp], xmm0
00007531fdbd3c49  vmovaps [rsp+0x10], xmm2
00007531fdbd3c4f  vmovaps [rsp+0x20], xmm3
00007531fdbd3c55  vmovaps [rsp+0x30], xmm4
00007531fdbd3c5b  vmovaps [rsp+0x40], xmm5
00007531fdbd3c61  vmovaps [rsp+0x50], xmm6
00007531fdbd3c67  vmovaps [rsp+0x60], xmm7
00007531fdbd3c6d  vmovaps [rsp+0x70], xmm8
00007531fdbd3c73  vmovaps [rsp+0x80], xmm9
00007531fdbd3c7c  vmovaps [rsp+0x90], xmm10
00007531fdbd3c85  vmovaps [rsp+0xA0], xmm11
00007531fdbd3c8e  vmovaps [rsp+0xB0], xmm12
00007531fdbd3c97  vmovaps [rsp+0xC0], xmm13
00007531fdbd3ca0  vmovaps [rsp+0xD0], xmm14
00007531fdbd3ca9  vmovaps [rsp+0xE0], xmm15
00007531fdbd3cb2  sub rsp, 0x30
00007531fdbd3cb6  movaps [rsp], xmm1
00007531fdbd3cba  movaps [rsp+0x10], xmm12
00007531fdbd3cc0  movaps [rsp+0x20], xmm10
00007531fdbd3cc6  lea rdi, [rsp]
00007531fdbd3cca  mov esi, 0x00
00007531fdbd3ccf  mov rax, 0x59ED111DF530
00007531fdbd3cd9  call rax
00007531fdbd3cdb  movaps xmm1, [rsp]
00007531fdbd3cdf  add rsp, 0x30
00007531fdbd3ce3  vmovaps xmm0, [rsp]
00007531fdbd3ce8  vmovaps xmm2, [rsp+0x10]
00007531fdbd3cee  vmovaps xmm3, [rsp+0x20]
00007531fdbd3cf4  vmovaps xmm4, [rsp+0x30]
00007531fdbd3cfa  vmovaps xmm5, [rsp+0x40]
00007531fdbd3d00  vmovaps xmm6, [rsp+0x50]
00007531fdbd3d06  vmovaps xmm7, [rsp+0x60]
00007531fdbd3d0c  vmovaps xmm8, [rsp+0x70]
00007531fdbd3d12  vmovaps xmm9, [rsp+0x80]
00007531fdbd3d1b  vmovaps xmm10, [rsp+0x90]
00007531fdbd3d24  vmovaps xmm11, [rsp+0xA0]
00007531fdbd3d2d  vmovaps xmm12, [rsp+0xB0]
00007531fdbd3d36  vmovaps xmm13, [rsp+0xC0]
00007531fdbd3d3f  vmovaps xmm14, [rsp+0xD0]
00007531fdbd3d48  vmovaps xmm15, [rsp+0xE0]
00007531fdbd3d51  add rsp, 0xF0
00007531fdbd3d58  pop r11
00007531fdbd3d5a  pop r10
00007531fdbd3d5c  pop r9
00007531fdbd3d5e  pop r8
00007531fdbd3d60  pop rsi
00007531fdbd3d61  pop rdi
00007531fdbd3d62  pop rdx
00007531fdbd3d63  pop rcx
00007531fdbd3d64  pop rax
00007531fdbd3d65  add rsp, 0x08
00007531fdbd3d69  jmp 0x00007531FDBD284F
00007531fdbd3d6e  sub rsp, 0x08
00007531fdbd3d72  push rax
00007531fdbd3d73  push rcx
00007531fdbd3d74  push rdx
00007531fdbd3d75  push rdi
00007531fdbd3d76  push rsi
00007531fdbd3d77  push r8
00007531fdbd3d79  push r9
00007531fdbd3d7b  push r10
00007531fdbd3d7d  push r11
00007531fdbd3d7f  sub rsp, 0xF0
00007531fdbd3d86  vmovaps [rsp], xmm0
00007531fdbd3d8b  vmovaps [rsp+0x10], xmm1
00007531fdbd3d91  vmovaps [rsp+0x20], xmm2
00007531fdbd3d97  vmovaps [rsp+0x30], xmm3
00007531fdbd3d9d  vmovaps [rsp+0x40], xmm4
00007531fdbd3da3  vmovaps [rsp+0x50], xmm5
00007531fdbd3da9  vmovaps [rsp+0x60], xmm6
00007531fdbd3daf  vmovaps [rsp+0x70], xmm7
00007531fdbd3db5  vmovaps [rsp+0x80], xmm8
00007531fdbd3dbe  vmovaps [rsp+0x90], xmm9
00007531fdbd3dc7  vmovaps [rsp+0xA0], xmm10
00007531fdbd3dd0  vmovaps [rsp+0xB0], xmm11
00007531fdbd3dd9  vmovaps [rsp+0xC0], xmm12
00007531fdbd3de2  vmovaps [rsp+0xD0], xmm14
00007531fdbd3deb  vmovaps [rsp+0xE0], xmm15
00007531fdbd3df4  sub rsp, 0x30
00007531fdbd3df8  movaps [rsp], xmm13
00007531fdbd3dfd  movaps [rsp+0x10], xmm12
00007531fdbd3e03  movaps [rsp+0x20], xmm2
00007531fdbd3e08  lea rdi, [rsp]
00007531fdbd3e0c  mov esi, 0x00
00007531fdbd3e11  mov rax, 0x59ED111DF530
00007531fdbd3e1b  call rax
00007531fdbd3e1d  movaps xmm13, [rsp]
00007531fdbd3e22  add rsp, 0x30
00007531fdbd3e26  vmovaps xmm0, [rsp]
00007531fdbd3e2b  vmovaps xmm1, [rsp+0x10]
00007531fdbd3e31  vmovaps xmm2, [rsp+0x20]
00007531fdbd3e37  vmovaps xmm3, [rsp+0x30]
00007531fdbd3e3d  vmovaps xmm4, [rsp+0x40]
00007531fdbd3e43  vmovaps xmm5, [rsp+0x50]
00007531fdbd3e49  vmovaps xmm6, [rsp+0x60]
00007531fdbd3e4f  vmovaps xmm7, [rsp+0x70]
00007531fdbd3e55  vmovaps xmm8, [rsp+0x80]
00007531fdbd3e5e  vmovaps xmm9, [rsp+0x90]
00007531fdbd3e67  vmovaps xmm10, [rsp+0xA0]
00007531fdbd3e70  vmovaps xmm11, [rsp+0xB0]
00007531fdbd3e79  vmovaps xmm12, [rsp+0xC0]
00007531fdbd3e82  vmovaps xmm14, [rsp+0xD0]
00007531fdbd3e8b  vmovaps xmm15, [rsp+0xE0]
00007531fdbd3e94  add rsp, 0xF0
00007531fdbd3e9b  pop r11
00007531fdbd3e9d  pop r10
00007531fdbd3e9f  pop r9
00007531fdbd3ea1  pop r8
00007531fdbd3ea3  pop rsi
00007531fdbd3ea4  pop rdi
00007531fdbd3ea5  pop rdx
00007531fdbd3ea6  pop rcx
00007531fdbd3ea7  pop rax
00007531fdbd3ea8  add rsp, 0x08
00007531fdbd3eac  jmp 0x00007531FDBD286A
00007531fdbd3eb1  sub rsp, 0x08
00007531fdbd3eb5  push rax
00007531fdbd3eb6  push rcx
00007531fdbd3eb7  push rdx
00007531fdbd3eb8  push rdi
00007531fdbd3eb9  push rsi
00007531fdbd3eba  push r8
00007531fdbd3ebc  push r9
00007531fdbd3ebe  push r10
00007531fdbd3ec0  push r11
00007531fdbd3ec2  sub rsp, 0xF0
00007531fdbd3ec9  vmovaps [rsp], xmm0
00007531fdbd3ece  vmovaps [rsp+0x10], xmm2
00007531fdbd3ed4  vmovaps [rsp+0x20], xmm3
00007531fdbd3eda  vmovaps [rsp+0x30], xmm4
00007531fdbd3ee0  vmovaps [rsp+0x40], xmm5
00007531fdbd3ee6  vmovaps [rsp+0x50], xmm6
00007531fdbd3eec  vmovaps [rsp+0x60], xmm7
00007531fdbd3ef2  vmovaps [rsp+0x70], xmm8
00007531fdbd3ef8  vmovaps [rsp+0x80], xmm9
00007531fdbd3f01  vmovaps [rsp+0x90], xmm10
00007531fdbd3f0a  vmovaps [rsp+0xA0], xmm11
00007531fdbd3f13  vmovaps [rsp+0xB0], xmm12
00007531fdbd3f1c  vmovaps [rsp+0xC0], xmm13
00007531fdbd3f25  vmovaps [rsp+0xD0], xmm14
00007531fdbd3f2e  vmovaps [rsp+0xE0], xmm15
00007531fdbd3f37  sub rsp, 0x30
00007531fdbd3f3b  movaps [rsp], xmm1
00007531fdbd3f3f  movaps [rsp+0x10], xmm10
00007531fdbd3f45  movaps [rsp+0x20], xmm2
00007531fdbd3f4a  lea rdi, [rsp]
00007531fdbd3f4e  mov esi, 0x00
00007531fdbd3f53  mov rax, 0x59ED111DF530
00007531fdbd3f5d  call rax
00007531fdbd3f5f  movaps xmm1, [rsp]
00007531fdbd3f63  add rsp, 0x30
00007531fdbd3f67  vmovaps xmm0, [rsp]
00007531fdbd3f6c  vmovaps xmm2, [rsp+0x10]
00007531fdbd3f72  vmovaps xmm3, [rsp+0x20]
00007531fdbd3f78  vmovaps xmm4, [rsp+0x30]
00007531fdbd3f7e  vmovaps xmm5, [rsp+0x40]
00007531fdbd3f84  vmovaps xmm6, [rsp+0x50]
00007531fdbd3f8a  vmovaps xmm7, [rsp+0x60]
00007531fdbd3f90  vmovaps xmm8, [rsp+0x70]
00007531fdbd3f96  vmovaps xmm9, [rsp+0x80]
00007531fdbd3f9f  vmovaps xmm10, [rsp+0x90]
00007531fdbd3fa8  vmovaps xmm11, [rsp+0xA0]
00007531fdbd3fb1  vmovaps xmm12, [rsp+0xB0]
00007531fdbd3fba  vmovaps xmm13, [rsp+0xC0]
00007531fdbd3fc3  vmovaps xmm14, [rsp+0xD0]
00007531fdbd3fcc  vmovaps xmm15, [rsp+0xE0]
00007531fdbd3fd5  add rsp, 0xF0
00007531fdbd3fdc  pop r11
00007531fdbd3fde  pop r10
00007531fdbd3fe0  pop r9
00007531fdbd3fe2  pop r8
00007531fdbd3fe4  pop rsi
00007531fdbd3fe5  pop rdi
00007531fdbd3fe6  pop rdx
00007531fdbd3fe7  pop rcx
00007531fdbd3fe8  pop rax
00007531fdbd3fe9  add rsp, 0x08
00007531fdbd3fed  jmp 0x00007531FDBD28D2
00007531fdbd3ff2  sub rsp, 0x08
00007531fdbd3ff6  push rax
00007531fdbd3ff7  push rcx
00007531fdbd3ff8  push rdx
00007531fdbd3ff9  push rdi
00007531fdbd3ffa  push rsi
00007531fdbd3ffb  push r8
00007531fdbd3ffd  push r9
00007531fdbd3fff  push r10
00007531fdbd4001  push r11
00007531fdbd4003  sub rsp, 0xF0
00007531fdbd400a  vmovaps [rsp], xmm0
00007531fdbd400f  vmovaps [rsp+0x10], xmm1
00007531fdbd4015  vmovaps [rsp+0x20], xmm2
00007531fdbd401b  vmovaps [rsp+0x30], xmm3
00007531fdbd4021  vmovaps [rsp+0x40], xmm4
00007531fdbd4027  vmovaps [rsp+0x50], xmm5
00007531fdbd402d  vmovaps [rsp+0x60], xmm6
00007531fdbd4033  vmovaps [rsp+0x70], xmm7
00007531fdbd4039  vmovaps [rsp+0x80], xmm8
00007531fdbd4042  vmovaps [rsp+0x90], xmm9
00007531fdbd404b  vmovaps [rsp+0xA0], xmm10
00007531fdbd4054  vmovaps [rsp+0xB0], xmm11
00007531fdbd405d  vmovaps [rsp+0xC0], xmm12
00007531fdbd4066  vmovaps [rsp+0xD0], xmm13
00007531fdbd406f  vmovaps [rsp+0xE0], xmm14
00007531fdbd4078  sub rsp, 0x30
00007531fdbd407c  movaps [rsp], xmm15
00007531fdbd4081  movaps [rsp+0x10], xmm10
00007531fdbd4087  movaps [rsp+0x20], xmm2
00007531fdbd408c  lea rdi, [rsp]
00007531fdbd4090  mov esi, 0x00
00007531fdbd4095  mov rax, 0x59ED111DF530
00007531fdbd409f  call rax
00007531fdbd40a1  movaps xmm15, [rsp]
00007531fdbd40a6  add rsp, 0x30
00007531fdbd40aa  vmovaps xmm0, [rsp]
00007531fdbd40af  vmovaps xmm1, [rsp+0x10]
00007531fdbd40b5  vmovaps xmm2, [rsp+0x20]
00007531fdbd40bb  vmovaps xmm3, [rsp+0x30]
00007531fdbd40c1  vmovaps xmm4, [rsp+0x40]
00007531fdbd40c7  vmovaps xmm5, [rsp+0x50]
00007531fdbd40cd  vmovaps xmm6, [rsp+0x60]
00007531fdbd40d3  vmovaps xmm7, [rsp+0x70]
00007531fdbd40d9  vmovaps xmm8, [rsp+0x80]
00007531fdbd40e2  vmovaps xmm9, [rsp+0x90]
00007531fdbd40eb  vmovaps xmm10, [rsp+0xA0]
00007531fdbd40f4  vmovaps xmm11, [rsp+0xB0]
00007531fdbd40fd  vmovaps xmm12, [rsp+0xC0]
00007531fdbd4106  vmovaps xmm13, [rsp+0xD0]
00007531fdbd410f  vmovaps xmm14, [rsp+0xE0]
00007531fdbd4118  add rsp, 0xF0
00007531fdbd411f  pop r11
00007531fdbd4121  pop r10
00007531fdbd4123  pop r9
00007531fdbd4125  pop r8
00007531fdbd4127  pop rsi
00007531fdbd4128  pop rdi
00007531fdbd4129  pop rdx
00007531fdbd412a  pop rcx
00007531fdbd412b  pop rax
00007531fdbd412c  add rsp, 0x08
00007531fdbd4130  jmp 0x00007531FDBD2924
00007531fdbd4135  sub rsp, 0x08
00007531fdbd4139  push rax
00007531fdbd413a  push rcx
00007531fdbd413b  push rdx
00007531fdbd413c  push rdi
00007531fdbd413d  push rsi
00007531fdbd413e  push r8
00007531fdbd4140  push r9
00007531fdbd4142  push r10
00007531fdbd4144  push r11
00007531fdbd4146  sub rsp, 0xF0
00007531fdbd414d  vmovaps [rsp], xmm0
00007531fdbd4152  vmovaps [rsp+0x10], xmm2
00007531fdbd4158  vmovaps [rsp+0x20], xmm3
00007531fdbd415e  vmovaps [rsp+0x30], xmm4
00007531fdbd4164  vmovaps [rsp+0x40], xmm5
00007531fdbd416a  vmovaps [rsp+0x50], xmm6
00007531fdbd4170  vmovaps [rsp+0x60], xmm7
00007531fdbd4176  vmovaps [rsp+0x70], xmm8
00007531fdbd417c  vmovaps [rsp+0x80], xmm9
00007531fdbd4185  vmovaps [rsp+0x90], xmm10
00007531fdbd418e  vmovaps [rsp+0xA0], xmm11
00007531fdbd4197  vmovaps [rsp+0xB0], xmm12
00007531fdbd41a0  vmovaps [rsp+0xC0], xmm13
00007531fdbd41a9  vmovaps [rsp+0xD0], xmm14
00007531fdbd41b2  vmovaps [rsp+0xE0], xmm15
00007531fdbd41bb  sub rsp, 0x30
00007531fdbd41bf  movaps [rsp], xmm1
00007531fdbd41c3  movaps [rsp+0x10], xmm10
00007531fdbd41c9  movaps [rsp+0x20], xmm15
00007531fdbd41cf  lea rdi, [rsp]
00007531fdbd41d3  mov esi, 0x00
00007531fdbd41d8  mov rax, 0x59ED111DF530
00007531fdbd41e2  call rax
00007531fdbd41e4  movaps xmm1, [rsp]
00007531fdbd41e8  add rsp, 0x30
00007531fdbd41ec  vmovaps xmm0, [rsp]
00007531fdbd41f1  vmovaps xmm2, [rsp+0x10]
00007531fdbd41f7  vmovaps xmm3, [rsp+0x20]
00007531fdbd41fd  vmovaps xmm4, [rsp+0x30]
00007531fdbd4203  vmovaps xmm5, [rsp+0x40]
00007531fdbd4209  vmovaps xmm6, [rsp+0x50]
00007531fdbd420f  vmovaps xmm7, [rsp+0x60]
00007531fdbd4215  vmovaps xmm8, [rsp+0x70]
00007531fdbd421b  vmovaps xmm9, [rsp+0x80]
00007531fdbd4224  vmovaps xmm10, [rsp+0x90]
00007531fdbd422d  vmovaps xmm11, [rsp+0xA0]
00007531fdbd4236  vmovaps xmm12, [rsp+0xB0]
00007531fdbd423f  vmovaps xmm13, [rsp+0xC0]
00007531fdbd4248  vmovaps xmm14, [rsp+0xD0]
00007531fdbd4251  vmovaps xmm15, [rsp+0xE0]
00007531fdbd425a  add rsp, 0xF0
00007531fdbd4261  pop r11
00007531fdbd4263  pop r10
00007531fdbd4265  pop r9
00007531fdbd4267  pop r8
00007531fdbd4269  pop rsi
00007531fdbd426a  pop rdi
00007531fdbd426b  pop rdx
00007531fdbd426c  pop rcx
00007531fdbd426d  pop rax
00007531fdbd426e  add rsp, 0x08
00007531fdbd4272  jmp 0x00007531FDBD2962
00007531fdbd4277  sub rsp, 0x08
00007531fdbd427b  push rax
00007531fdbd427c  push rcx
00007531fdbd427d  push rdx
00007531fdbd427e  push rdi
00007531fdbd427f  push rsi
00007531fdbd4280  push r8
00007531fdbd4282  push r9
00007531fdbd4284  push r10
00007531fdbd4286  push r11
00007531fdbd4288  sub rsp, 0xF0
00007531fdbd428f  vmovaps [rsp], xmm0
00007531fdbd4294  vmovaps [rsp+0x10], xmm1
00007531fdbd429a  vmovaps [rsp+0x20], xmm2
00007531fdbd42a0  vmovaps [rsp+0x30], xmm3
00007531fdbd42a6  vmovaps [rsp+0x40], xmm4
00007531fdbd42ac  vmovaps [rsp+0x50], xmm5
00007531fdbd42b2  vmovaps [rsp+0x60], xmm6
00007531fdbd42b8  vmovaps [rsp+0x70], xmm7
00007531fdbd42be  vmovaps [rsp+0x80], xmm8
00007531fdbd42c7  vmovaps [rsp+0x90], xmm9
00007531fdbd42d0  vmovaps [rsp+0xA0], xmm10
00007531fdbd42d9  vmovaps [rsp+0xB0], xmm11
00007531fdbd42e2  vmovaps [rsp+0xC0], xmm12
00007531fdbd42eb  vmovaps [rsp+0xD0], xmm13
00007531fdbd42f4  vmovaps [rsp+0xE0], xmm15
00007531fdbd42fd  sub rsp, 0x30
00007531fdbd4301  movaps [rsp], xmm14
00007531fdbd4306  movaps [rsp+0x10], xmm10
00007531fdbd430c  movaps [rsp+0x20], xmm15
00007531fdbd4312  lea rdi, [rsp]
00007531fdbd4316  mov esi, 0x00
00007531fdbd431b  mov rax, 0x59ED111DF530
00007531fdbd4325  call rax
00007531fdbd4327  movaps xmm14, [rsp]
00007531fdbd432c  add rsp, 0x30
00007531fdbd4330  vmovaps xmm0, [rsp]
00007531fdbd4335  vmovaps xmm1, [rsp+0x10]
00007531fdbd433b  vmovaps xmm2, [rsp+0x20]
00007531fdbd4341  vmovaps xmm3, [rsp+0x30]
00007531fdbd4347  vmovaps xmm4, [rsp+0x40]
00007531fdbd434d  vmovaps xmm5, [rsp+0x50]
00007531fdbd4353  vmovaps xmm6, [rsp+0x60]
00007531fdbd4359  vmovaps xmm7, [rsp+0x70]
00007531fdbd435f  vmovaps xmm8, [rsp+0x80]
00007531fdbd4368  vmovaps xmm9, [rsp+0x90]
00007531fdbd4371  vmovaps xmm10, [rsp+0xA0]
00007531fdbd437a  vmovaps xmm11, [rsp+0xB0]
00007531fdbd4383  vmovaps xmm12, [rsp+0xC0]
00007531fdbd438c  vmovaps xmm13, [rsp+0xD0]
00007531fdbd4395  vmovaps xmm15, [rsp+0xE0]
00007531fdbd439e  add rsp, 0xF0
00007531fdbd43a5  pop r11
00007531fdbd43a7  pop r10
00007531fdbd43a9  pop r9
00007531fdbd43ab  pop r8
00007531fdbd43ad  pop rsi
00007531fdbd43ae  pop rdi
00007531fdbd43af  pop rdx
00007531fdbd43b0  pop rcx
00007531fdbd43b1  pop rax
00007531fdbd43b2  add rsp, 0x08
00007531fdbd43b6  jmp 0x00007531FDBD298E
00007531fdbd43bb  call 0x00007531FD9FF430
00007531fdbd43c0  jmp 0x00007531FDBD2A1E
00007531fdbd43c5  call 0x00007531FD9FF430
00007531fdbd43ca  jmp 0x00007531FDBD2A31
00007531fdbd43cf  sub rsp, 0x08
00007531fdbd43d3  push rax
00007531fdbd43d4  push rcx
00007531fdbd43d5  push rdx
00007531fdbd43d6  push rdi
00007531fdbd43d7  push rsi
00007531fdbd43d8  push r8
00007531fdbd43da  push r9
00007531fdbd43dc  push r10
00007531fdbd43de  push r11
00007531fdbd43e0  sub rsp, 0xF0
00007531fdbd43e7  vmovaps [rsp], xmm0
00007531fdbd43ec  vmovaps [rsp+0x10], xmm2
00007531fdbd43f2  vmovaps [rsp+0x20], xmm3
00007531fdbd43f8  vmovaps [rsp+0x30], xmm4
00007531fdbd43fe  vmovaps [rsp+0x40], xmm5
00007531fdbd4404  vmovaps [rsp+0x50], xmm6
00007531fdbd440a  vmovaps [rsp+0x60], xmm7
00007531fdbd4410  vmovaps [rsp+0x70], xmm8
00007531fdbd4416  vmovaps [rsp+0x80], xmm9
00007531fdbd441f  vmovaps [rsp+0x90], xmm10
00007531fdbd4428  vmovaps [rsp+0xA0], xmm11
00007531fdbd4431  vmovaps [rsp+0xB0], xmm12
00007531fdbd443a  vmovaps [rsp+0xC0], xmm13
00007531fdbd4443  vmovaps [rsp+0xD0], xmm14
00007531fdbd444c  vmovaps [rsp+0xE0], xmm15
00007531fdbd4455  sub rsp, 0x30
00007531fdbd4459  movaps [rsp], xmm1
00007531fdbd445d  movaps [rsp+0x10], xmm13
00007531fdbd4463  movaps [rsp+0x20], xmm2
00007531fdbd4468  lea rdi, [rsp]
00007531fdbd446c  mov esi, 0x00
00007531fdbd4471  mov rax, 0x59ED111DF530
00007531fdbd447b  call rax
00007531fdbd447d  movaps xmm1, [rsp]
00007531fdbd4481  add rsp, 0x30
00007531fdbd4485  vmovaps xmm0, [rsp]
00007531fdbd448a  vmovaps xmm2, [rsp+0x10]
00007531fdbd4490  vmovaps xmm3, [rsp+0x20]
00007531fdbd4496  vmovaps xmm4, [rsp+0x30]
00007531fdbd449c  vmovaps xmm5, [rsp+0x40]
00007531fdbd44a2  vmovaps xmm6, [rsp+0x50]
00007531fdbd44a8  vmovaps xmm7, [rsp+0x60]
00007531fdbd44ae  vmovaps xmm8, [rsp+0x70]
00007531fdbd44b4  vmovaps xmm9, [rsp+0x80]
00007531fdbd44bd  vmovaps xmm10, [rsp+0x90]
00007531fdbd44c6  vmovaps xmm11, [rsp+0xA0]
00007531fdbd44cf  vmovaps xmm12, [rsp+0xB0]
00007531fdbd44d8  vmovaps xmm13, [rsp+0xC0]
00007531fdbd44e1  vmovaps xmm14, [rsp+0xD0]
00007531fdbd44ea  vmovaps xmm15, [rsp+0xE0]
00007531fdbd44f3  add rsp, 0xF0
00007531fdbd44fa  pop r11
00007531fdbd44fc  pop r10
00007531fdbd44fe  pop r9
00007531fdbd4500  pop r8
00007531fdbd4502  pop rsi
00007531fdbd4503  pop rdi
00007531fdbd4504  pop rdx
00007531fdbd4505  pop rcx
00007531fdbd4506  pop rax
00007531fdbd4507  add rsp, 0x08
00007531fdbd450b  jmp 0x00007531FDBD2A5C
00007531fdbd4510  call 0x00007531FDA0E760
00007531fdbd4515  jmp 0x00007531FDBD2A69
00007531fdbd451a  sub rsp, 0x08
00007531fdbd451e  push rax
00007531fdbd451f  push rcx
00007531fdbd4520  push rdx
00007531fdbd4521  push rdi
00007531fdbd4522  push rsi
00007531fdbd4523  push r8
00007531fdbd4525  push r9
00007531fdbd4527  push r10
00007531fdbd4529  push r11
00007531fdbd452b  sub rsp, 0xF0
00007531fdbd4532  vmovaps [rsp], xmm0
00007531fdbd4537  vmovaps [rsp+0x10], xmm1
00007531fdbd453d  vmovaps [rsp+0x20], xmm2
00007531fdbd4543  vmovaps [rsp+0x30], xmm3
00007531fdbd4549  vmovaps [rsp+0x40], xmm4
00007531fdbd454f  vmovaps [rsp+0x50], xmm5
00007531fdbd4555  vmovaps [rsp+0x60], xmm6
00007531fdbd455b  vmovaps [rsp+0x70], xmm7
00007531fdbd4561  vmovaps [rsp+0x80], xmm8
00007531fdbd456a  vmovaps [rsp+0x90], xmm9
00007531fdbd4573  vmovaps [rsp+0xA0], xmm10
00007531fdbd457c  vmovaps [rsp+0xB0], xmm11
00007531fdbd4585  vmovaps [rsp+0xC0], xmm12
00007531fdbd458e  vmovaps [rsp+0xD0], xmm14
00007531fdbd4597  vmovaps [rsp+0xE0], xmm15
00007531fdbd45a0  sub rsp, 0x30
00007531fdbd45a4  movaps [rsp], xmm13
00007531fdbd45a9  movaps [rsp+0x10], xmm2
00007531fdbd45ae  movaps [rsp+0x20], xmm1
00007531fdbd45b3  lea rdi, [rsp]
00007531fdbd45b7  mov esi, 0x00
00007531fdbd45bc  mov rax, 0x59ED111DF530
00007531fdbd45c6  call rax
00007531fdbd45c8  movaps xmm13, [rsp]
00007531fdbd45cd  add rsp, 0x30
00007531fdbd45d1  vmovaps xmm0, [rsp]
00007531fdbd45d6  vmovaps xmm1, [rsp+0x10]
00007531fdbd45dc  vmovaps xmm2, [rsp+0x20]
00007531fdbd45e2  vmovaps xmm3, [rsp+0x30]
00007531fdbd45e8  vmovaps xmm4, [rsp+0x40]
00007531fdbd45ee  vmovaps xmm5, [rsp+0x50]
00007531fdbd45f4  vmovaps xmm6, [rsp+0x60]
00007531fdbd45fa  vmovaps xmm7, [rsp+0x70]
00007531fdbd4600  vmovaps xmm8, [rsp+0x80]
00007531fdbd4609  vmovaps xmm9, [rsp+0x90]
00007531fdbd4612  vmovaps xmm10, [rsp+0xA0]
00007531fdbd461b  vmovaps xmm11, [rsp+0xB0]
00007531fdbd4624  vmovaps xmm12, [rsp+0xC0]
00007531fdbd462d  vmovaps xmm14, [rsp+0xD0]
00007531fdbd4636  vmovaps xmm15, [rsp+0xE0]
00007531fdbd463f  add rsp, 0xF0
00007531fdbd4646  pop r11
00007531fdbd4648  pop r10
00007531fdbd464a  pop r9
00007531fdbd464c  pop r8
00007531fdbd464e  pop rsi
00007531fdbd464f  pop rdi
00007531fdbd4650  pop rdx
00007531fdbd4651  pop rcx
00007531fdbd4652  pop rax
00007531fdbd4653  add rsp, 0x08
00007531fdbd4657  jmp 0x00007531FDBD2AA8
00007531fdbd465c  sub rsp, 0x08
00007531fdbd4660  push rax
00007531fdbd4661  push rcx
00007531fdbd4662  push rdx
00007531fdbd4663  push rdi
00007531fdbd4664  push rsi
00007531fdbd4665  push r8
00007531fdbd4667  push r9
00007531fdbd4669  push r10
00007531fdbd466b  push r11
00007531fdbd466d  sub rsp, 0xF0
00007531fdbd4674  vmovaps [rsp], xmm0
00007531fdbd4679  vmovaps [rsp+0x10], xmm2
00007531fdbd467f  vmovaps [rsp+0x20], xmm3
00007531fdbd4685  vmovaps [rsp+0x30], xmm4
00007531fdbd468b  vmovaps [rsp+0x40], xmm5
00007531fdbd4691  vmovaps [rsp+0x50], xmm6
00007531fdbd4697  vmovaps [rsp+0x60], xmm7
00007531fdbd469d  vmovaps [rsp+0x70], xmm8
00007531fdbd46a3  vmovaps [rsp+0x80], xmm9
00007531fdbd46ac  vmovaps [rsp+0x90], xmm10
00007531fdbd46b5  vmovaps [rsp+0xA0], xmm11
00007531fdbd46be  vmovaps [rsp+0xB0], xmm12
00007531fdbd46c7  vmovaps [rsp+0xC0], xmm13
00007531fdbd46d0  vmovaps [rsp+0xD0], xmm14
00007531fdbd46d9  vmovaps [rsp+0xE0], xmm15
00007531fdbd46e2  sub rsp, 0x30
00007531fdbd46e6  movaps [rsp], xmm1
00007531fdbd46ea  movaps [rsp+0x10], xmm14
00007531fdbd46f0  movaps [rsp+0x20], xmm15
00007531fdbd46f6  lea rdi, [rsp]
00007531fdbd46fa  mov esi, 0x00
00007531fdbd46ff  mov rax, 0x59ED111DF530
00007531fdbd4709  call rax
00007531fdbd470b  movaps xmm1, [rsp]
00007531fdbd470f  add rsp, 0x30
00007531fdbd4713  vmovaps xmm0, [rsp]
00007531fdbd4718  vmovaps xmm2, [rsp+0x10]
00007531fdbd471e  vmovaps xmm3, [rsp+0x20]
00007531fdbd4724  vmovaps xmm4, [rsp+0x30]
00007531fdbd472a  vmovaps xmm5, [rsp+0x40]
00007531fdbd4730  vmovaps xmm6, [rsp+0x50]
00007531fdbd4736  vmovaps xmm7, [rsp+0x60]
00007531fdbd473c  vmovaps xmm8, [rsp+0x70]
00007531fdbd4742  vmovaps xmm9, [rsp+0x80]
00007531fdbd474b  vmovaps xmm10, [rsp+0x90]
00007531fdbd4754  vmovaps xmm11, [rsp+0xA0]
00007531fdbd475d  vmovaps xmm12, [rsp+0xB0]
00007531fdbd4766  vmovaps xmm13, [rsp+0xC0]
00007531fdbd476f  vmovaps xmm14, [rsp+0xD0]
00007531fdbd4778  vmovaps xmm15, [rsp+0xE0]
00007531fdbd4781  add rsp, 0xF0
00007531fdbd4788  pop r11
00007531fdbd478a  pop r10
00007531fdbd478c  pop r9
00007531fdbd478e  pop r8
00007531fdbd4790  pop rsi
00007531fdbd4791  pop rdi
00007531fdbd4792  pop rdx
00007531fdbd4793  pop rcx
00007531fdbd4794  pop rax
00007531fdbd4795  add rsp, 0x08
00007531fdbd4799  jmp 0x00007531FDBD2ACA
00007531fdbd479e  sub rsp, 0x08
00007531fdbd47a2  push rax
00007531fdbd47a3  push rcx
00007531fdbd47a4  push rdx
00007531fdbd47a5  push rdi
00007531fdbd47a6  push rsi
00007531fdbd47a7  push r8
00007531fdbd47a9  push r9
00007531fdbd47ab  push r10
00007531fdbd47ad  push r11
00007531fdbd47af  sub rsp, 0xF0
00007531fdbd47b6  vmovaps [rsp], xmm0
00007531fdbd47bb  vmovaps [rsp+0x10], xmm1
00007531fdbd47c1  vmovaps [rsp+0x20], xmm2
00007531fdbd47c7  vmovaps [rsp+0x30], xmm3
00007531fdbd47cd  vmovaps [rsp+0x40], xmm4
00007531fdbd47d3  vmovaps [rsp+0x50], xmm5
00007531fdbd47d9  vmovaps [rsp+0x60], xmm6
00007531fdbd47df  vmovaps [rsp+0x70], xmm7
00007531fdbd47e5  vmovaps [rsp+0x80], xmm8
00007531fdbd47ee  vmovaps [rsp+0x90], xmm9
00007531fdbd47f7  vmovaps [rsp+0xA0], xmm10
00007531fdbd4800  vmovaps [rsp+0xB0], xmm11
00007531fdbd4809  vmovaps [rsp+0xC0], xmm12
00007531fdbd4812  vmovaps [rsp+0xD0], xmm13
00007531fdbd481b  vmovaps [rsp+0xE0], xmm15
00007531fdbd4824  sub rsp, 0x30
00007531fdbd4828  movaps [rsp], xmm14
00007531fdbd482d  movaps [rsp+0x10], xmm2
00007531fdbd4832  movaps [rsp+0x20], xmm15
00007531fdbd4838  lea rdi, [rsp]
00007531fdbd483c  mov esi, 0x00
00007531fdbd4841  mov rax, 0x59ED111DF530
00007531fdbd484b  call rax
00007531fdbd484d  movaps xmm14, [rsp]
00007531fdbd4852  add rsp, 0x30
00007531fdbd4856  vmovaps xmm0, [rsp]
00007531fdbd485b  vmovaps xmm1, [rsp+0x10]
00007531fdbd4861  vmovaps xmm2, [rsp+0x20]
00007531fdbd4867  vmovaps xmm3, [rsp+0x30]
00007531fdbd486d  vmovaps xmm4, [rsp+0x40]
00007531fdbd4873  vmovaps xmm5, [rsp+0x50]
00007531fdbd4879  vmovaps xmm6, [rsp+0x60]
00007531fdbd487f  vmovaps xmm7, [rsp+0x70]
00007531fdbd4885  vmovaps xmm8, [rsp+0x80]
00007531fdbd488e  vmovaps xmm9, [rsp+0x90]
00007531fdbd4897  vmovaps xmm10, [rsp+0xA0]
00007531fdbd48a0  vmovaps xmm11, [rsp+0xB0]
00007531fdbd48a9  vmovaps xmm12, [rsp+0xC0]
00007531fdbd48b2  vmovaps xmm13, [rsp+0xD0]
00007531fdbd48bb  vmovaps xmm15, [rsp+0xE0]
00007531fdbd48c4  add rsp, 0xF0
00007531fdbd48cb  pop r11
00007531fdbd48cd  pop r10
00007531fdbd48cf  pop r9
00007531fdbd48d1  pop r8
00007531fdbd48d3  pop rsi
00007531fdbd48d4  pop rdi
00007531fdbd48d5  pop rdx
00007531fdbd48d6  pop rcx
00007531fdbd48d7  pop rax
00007531fdbd48d8  add rsp, 0x08
00007531fdbd48dc  jmp 0x00007531FDBD2B05
00007531fdbd48e1  sub rsp, 0x08
00007531fdbd48e5  push rax
00007531fdbd48e6  push rcx
00007531fdbd48e7  push rdx
00007531fdbd48e8  push rdi
00007531fdbd48e9  push rsi
00007531fdbd48ea  push r8
00007531fdbd48ec  push r9
00007531fdbd48ee  push r10
00007531fdbd48f0  push r11
00007531fdbd48f2  sub rsp, 0xF0
00007531fdbd48f9  vmovaps [rsp], xmm0
00007531fdbd48fe  vmovaps [rsp+0x10], xmm1
00007531fdbd4904  vmovaps [rsp+0x20], xmm2
00007531fdbd490a  vmovaps [rsp+0x30], xmm3
00007531fdbd4910  vmovaps [rsp+0x40], xmm4
00007531fdbd4916  vmovaps [rsp+0x50], xmm5
00007531fdbd491c  vmovaps [rsp+0x60], xmm6
00007531fdbd4922  vmovaps [rsp+0x70], xmm7
00007531fdbd4928  vmovaps [rsp+0x80], xmm8
00007531fdbd4931  vmovaps [rsp+0x90], xmm9
00007531fdbd493a  vmovaps [rsp+0xA0], xmm10
00007531fdbd4943  vmovaps [rsp+0xB0], xmm11
00007531fdbd494c  vmovaps [rsp+0xC0], xmm12
00007531fdbd4955  vmovaps [rsp+0xD0], xmm13
00007531fdbd495e  vmovaps [rsp+0xE0], xmm14
00007531fdbd4967  sub rsp, 0x30
00007531fdbd496b  movaps [rsp], xmm15
00007531fdbd4970  movaps [rsp+0x10], xmm2
00007531fdbd4975  movaps [rsp+0x20], xmm1
00007531fdbd497a  lea rdi, [rsp]
00007531fdbd497e  mov esi, 0x00
00007531fdbd4983  mov rax, 0x59ED111DF530
00007531fdbd498d  call rax
00007531fdbd498f  movaps xmm15, [rsp]
00007531fdbd4994  add rsp, 0x30
00007531fdbd4998  vmovaps xmm0, [rsp]
00007531fdbd499d  vmovaps xmm1, [rsp+0x10]
00007531fdbd49a3  vmovaps xmm2, [rsp+0x20]
00007531fdbd49a9  vmovaps xmm3, [rsp+0x30]
00007531fdbd49af  vmovaps xmm4, [rsp+0x40]
00007531fdbd49b5  vmovaps xmm5, [rsp+0x50]
00007531fdbd49bb  vmovaps xmm6, [rsp+0x60]
00007531fdbd49c1  vmovaps xmm7, [rsp+0x70]
00007531fdbd49c7  vmovaps xmm8, [rsp+0x80]
00007531fdbd49d0  vmovaps xmm9, [rsp+0x90]
00007531fdbd49d9  vmovaps xmm10, [rsp+0xA0]
00007531fdbd49e2  vmovaps xmm11, [rsp+0xB0]
00007531fdbd49eb  vmovaps xmm12, [rsp+0xC0]
00007531fdbd49f4  vmovaps xmm13, [rsp+0xD0]
00007531fdbd49fd  vmovaps xmm14, [rsp+0xE0]
00007531fdbd4a06  add rsp, 0xF0
00007531fdbd4a0d  pop r11
00007531fdbd4a0f  pop r10
00007531fdbd4a11  pop r9
00007531fdbd4a13  pop r8
00007531fdbd4a15  pop rsi
00007531fdbd4a16  pop rdi
00007531fdbd4a17  pop rdx
00007531fdbd4a18  pop rcx
00007531fdbd4a19  pop rax
00007531fdbd4a1a  add rsp, 0x08
00007531fdbd4a1e  jmp 0x00007531FDBD2B41
00007531fdbd4a23  call 0x00007531FD9FF430
00007531fdbd4a28  jmp 0x00007531FDBD2B4E
00007531fdbd4a2d  sub rsp, 0x08
00007531fdbd4a31  push rax
00007531fdbd4a32  push rcx
00007531fdbd4a33  push rdx
00007531fdbd4a34  push rdi
00007531fdbd4a35  push rsi
00007531fdbd4a36  push r8
00007531fdbd4a38  push r9
00007531fdbd4a3a  push r10
00007531fdbd4a3c  push r11
00007531fdbd4a3e  sub rsp, 0xF0
00007531fdbd4a45  vmovaps [rsp], xmm0
00007531fdbd4a4a  vmovaps [rsp+0x10], xmm1
00007531fdbd4a50  vmovaps [rsp+0x20], xmm3
00007531fdbd4a56  vmovaps [rsp+0x30], xmm4
00007531fdbd4a5c  vmovaps [rsp+0x40], xmm5
00007531fdbd4a62  vmovaps [rsp+0x50], xmm6
00007531fdbd4a68  vmovaps [rsp+0x60], xmm7
00007531fdbd4a6e  vmovaps [rsp+0x70], xmm8
00007531fdbd4a74  vmovaps [rsp+0x80], xmm9
00007531fdbd4a7d  vmovaps [rsp+0x90], xmm10
00007531fdbd4a86  vmovaps [rsp+0xA0], xmm11
00007531fdbd4a8f  vmovaps [rsp+0xB0], xmm12
00007531fdbd4a98  vmovaps [rsp+0xC0], xmm13
00007531fdbd4aa1  vmovaps [rsp+0xD0], xmm14
00007531fdbd4aaa  vmovaps [rsp+0xE0], xmm15
00007531fdbd4ab3  sub rsp, 0x30
00007531fdbd4ab7  movaps [rsp], xmm2
00007531fdbd4abb  movaps [rsp+0x10], xmm1
00007531fdbd4ac0  movaps [rsp+0x20], xmm14
00007531fdbd4ac6  lea rdi, [rsp]
00007531fdbd4aca  mov esi, 0x00
00007531fdbd4acf  mov rax, 0x59ED111DF530
00007531fdbd4ad9  call rax
00007531fdbd4adb  movaps xmm2, [rsp]
00007531fdbd4adf  add rsp, 0x30
00007531fdbd4ae3  vmovaps xmm0, [rsp]
00007531fdbd4ae8  vmovaps xmm1, [rsp+0x10]
00007531fdbd4aee  vmovaps xmm3, [rsp+0x20]
00007531fdbd4af4  vmovaps xmm4, [rsp+0x30]
00007531fdbd4afa  vmovaps xmm5, [rsp+0x40]
00007531fdbd4b00  vmovaps xmm6, [rsp+0x50]
00007531fdbd4b06  vmovaps xmm7, [rsp+0x60]
00007531fdbd4b0c  vmovaps xmm8, [rsp+0x70]
00007531fdbd4b12  vmovaps xmm9, [rsp+0x80]
00007531fdbd4b1b  vmovaps xmm10, [rsp+0x90]
00007531fdbd4b24  vmovaps xmm11, [rsp+0xA0]
00007531fdbd4b2d  vmovaps xmm12, [rsp+0xB0]
00007531fdbd4b36  vmovaps xmm13, [rsp+0xC0]
00007531fdbd4b3f  vmovaps xmm14, [rsp+0xD0]
00007531fdbd4b48  vmovaps xmm15, [rsp+0xE0]
00007531fdbd4b51  add rsp, 0xF0
00007531fdbd4b58  pop r11
00007531fdbd4b5a  pop r10
00007531fdbd4b5c  pop r9
00007531fdbd4b5e  pop r8
00007531fdbd4b60  pop rsi
00007531fdbd4b61  pop rdi
00007531fdbd4b62  pop rdx
00007531fdbd4b63  pop rcx
00007531fdbd4b64  pop rax
00007531fdbd4b65  add rsp, 0x08
00007531fdbd4b69  jmp 0x00007531FDBD2B8B
00007531fdbd4b6e  sub rsp, 0x08
00007531fdbd4b72  push rax
00007531fdbd4b73  push rcx
00007531fdbd4b74  push rdx
00007531fdbd4b75  push rdi
00007531fdbd4b76  push rsi
00007531fdbd4b77  push r8
00007531fdbd4b79  push r9
00007531fdbd4b7b  push r10
00007531fdbd4b7d  push r11
00007531fdbd4b7f  sub rsp, 0xF0
00007531fdbd4b86  vmovaps [rsp], xmm0
00007531fdbd4b8b  vmovaps [rsp+0x10], xmm1
00007531fdbd4b91  vmovaps [rsp+0x20], xmm2
00007531fdbd4b97  vmovaps [rsp+0x30], xmm3
00007531fdbd4b9d  vmovaps [rsp+0x40], xmm4
00007531fdbd4ba3  vmovaps [rsp+0x50], xmm5
00007531fdbd4ba9  vmovaps [rsp+0x60], xmm6
00007531fdbd4baf  vmovaps [rsp+0x70], xmm7
00007531fdbd4bb5  vmovaps [rsp+0x80], xmm8
00007531fdbd4bbe  vmovaps [rsp+0x90], xmm9
00007531fdbd4bc7  vmovaps [rsp+0xA0], xmm10
00007531fdbd4bd0  vmovaps [rsp+0xB0], xmm11
00007531fdbd4bd9  vmovaps [rsp+0xC0], xmm12
00007531fdbd4be2  vmovaps [rsp+0xD0], xmm13
00007531fdbd4beb  vmovaps [rsp+0xE0], xmm14
00007531fdbd4bf4  sub rsp, 0x30
00007531fdbd4bf8  movaps [rsp], xmm15
00007531fdbd4bfd  movaps [rsp+0x10], xmm14
00007531fdbd4c03  movaps [rsp+0x20], xmm1
00007531fdbd4c08  lea rdi, [rsp]
00007531fdbd4c0c  mov esi, 0x00
00007531fdbd4c11  mov rax, 0x59ED111DF530
00007531fdbd4c1b  call rax
00007531fdbd4c1d  movaps xmm15, [rsp]
00007531fdbd4c22  add rsp, 0x30
00007531fdbd4c26  vmovaps xmm0, [rsp]
00007531fdbd4c2b  vmovaps xmm1, [rsp+0x10]
00007531fdbd4c31  vmovaps xmm2, [rsp+0x20]
00007531fdbd4c37  vmovaps xmm3, [rsp+0x30]
00007531fdbd4c3d  vmovaps xmm4, [rsp+0x40]
00007531fdbd4c43  vmovaps xmm5, [rsp+0x50]
00007531fdbd4c49  vmovaps xmm6, [rsp+0x60]
00007531fdbd4c4f  vmovaps xmm7, [rsp+0x70]
00007531fdbd4c55  vmovaps xmm8, [rsp+0x80]
00007531fdbd4c5e  vmovaps xmm9, [rsp+0x90]
00007531fdbd4c67  vmovaps xmm10, [rsp+0xA0]
00007531fdbd4c70  vmovaps xmm11, [rsp+0xB0]
00007531fdbd4c79  vmovaps xmm12, [rsp+0xC0]
00007531fdbd4c82  vmovaps xmm13, [rsp+0xD0]
00007531fdbd4c8b  vmovaps xmm14, [rsp+0xE0]
00007531fdbd4c94  add rsp, 0xF0
00007531fdbd4c9b  pop r11
00007531fdbd4c9d  pop r10
00007531fdbd4c9f  pop r9
00007531fdbd4ca1  pop r8
00007531fdbd4ca3  pop rsi
00007531fdbd4ca4  pop rdi
00007531fdbd4ca5  pop rdx
00007531fdbd4ca6  pop rcx
00007531fdbd4ca7  pop rax
00007531fdbd4ca8  add rsp, 0x08
00007531fdbd4cac  jmp 0x00007531FDBD2C05
00007531fdbd4cb1  call 0x00007531FD9FF430
00007531fdbd4cb6  jmp 0x00007531FDBD2C12
00007531fdbd4cbb  sub rsp, 0x08
00007531fdbd4cbf  push rax
00007531fdbd4cc0  push rcx
00007531fdbd4cc1  push rdx
00007531fdbd4cc2  push rdi
00007531fdbd4cc3  push rsi
00007531fdbd4cc4  push r8
00007531fdbd4cc6  push r9
00007531fdbd4cc8  push r10
00007531fdbd4cca  push r11
00007531fdbd4ccc  sub rsp, 0xF0
00007531fdbd4cd3  vmovaps [rsp], xmm0
00007531fdbd4cd8  vmovaps [rsp+0x10], xmm1
00007531fdbd4cde  vmovaps [rsp+0x20], xmm2
00007531fdbd4ce4  vmovaps [rsp+0x30], xmm3
00007531fdbd4cea  vmovaps [rsp+0x40], xmm4
00007531fdbd4cf0  vmovaps [rsp+0x50], xmm5
00007531fdbd4cf6  vmovaps [rsp+0x60], xmm6
00007531fdbd4cfc  vmovaps [rsp+0x70], xmm7
00007531fdbd4d02  vmovaps [rsp+0x80], xmm8
00007531fdbd4d0b  vmovaps [rsp+0x90], xmm9
00007531fdbd4d14  vmovaps [rsp+0xA0], xmm10
00007531fdbd4d1d  vmovaps [rsp+0xB0], xmm11
00007531fdbd4d26  vmovaps [rsp+0xC0], xmm12
00007531fdbd4d2f  vmovaps [rsp+0xD0], xmm14
00007531fdbd4d38  vmovaps [rsp+0xE0], xmm15
00007531fdbd4d41  sub rsp, 0x30
00007531fdbd4d45  movaps [rsp], xmm13
00007531fdbd4d4a  movaps [rsp+0x10], xmm1
00007531fdbd4d4f  movaps [rsp+0x20], xmm15
00007531fdbd4d55  lea rdi, [rsp]
00007531fdbd4d59  mov esi, 0x00
00007531fdbd4d5e  mov rax, 0x59ED111DF530
00007531fdbd4d68  call rax
00007531fdbd4d6a  movaps xmm13, [rsp]
00007531fdbd4d6f  add rsp, 0x30
00007531fdbd4d73  vmovaps xmm0, [rsp]
00007531fdbd4d78  vmovaps xmm1, [rsp+0x10]
00007531fdbd4d7e  vmovaps xmm2, [rsp+0x20]
00007531fdbd4d84  vmovaps xmm3, [rsp+0x30]
00007531fdbd4d8a  vmovaps xmm4, [rsp+0x40]
00007531fdbd4d90  vmovaps xmm5, [rsp+0x50]
00007531fdbd4d96  vmovaps xmm6, [rsp+0x60]
00007531fdbd4d9c  vmovaps xmm7, [rsp+0x70]
00007531fdbd4da2  vmovaps xmm8, [rsp+0x80]
00007531fdbd4dab  vmovaps xmm9, [rsp+0x90]
00007531fdbd4db4  vmovaps xmm10, [rsp+0xA0]
00007531fdbd4dbd  vmovaps xmm11, [rsp+0xB0]
00007531fdbd4dc6  vmovaps xmm12, [rsp+0xC0]
00007531fdbd4dcf  vmovaps xmm14, [rsp+0xD0]
00007531fdbd4dd8  vmovaps xmm15, [rsp+0xE0]
00007531fdbd4de1  add rsp, 0xF0
00007531fdbd4de8  pop r11
00007531fdbd4dea  pop r10
00007531fdbd4dec  pop r9
00007531fdbd4dee  pop r8
00007531fdbd4df0  pop rsi
00007531fdbd4df1  pop rdi
00007531fdbd4df2  pop rdx
00007531fdbd4df3  pop rcx
00007531fdbd4df4  pop rax
00007531fdbd4df5  add rsp, 0x08
00007531fdbd4df9  jmp 0x00007531FDBD2CD6
00007531fdbd4dfe  sub rsp, 0x08
00007531fdbd4e02  push rax
00007531fdbd4e03  push rcx
00007531fdbd4e04  push rdx
00007531fdbd4e05  push rdi
00007531fdbd4e06  push rsi
00007531fdbd4e07  push r8
00007531fdbd4e09  push r9
00007531fdbd4e0b  push r10
00007531fdbd4e0d  push r11
00007531fdbd4e0f  sub rsp, 0xF0
00007531fdbd4e16  vmovaps [rsp], xmm0
00007531fdbd4e1b  vmovaps [rsp+0x10], xmm1
00007531fdbd4e21  vmovaps [rsp+0x20], xmm2
00007531fdbd4e27  vmovaps [rsp+0x30], xmm3
00007531fdbd4e2d  vmovaps [rsp+0x40], xmm4
00007531fdbd4e33  vmovaps [rsp+0x50], xmm5
00007531fdbd4e39  vmovaps [rsp+0x60], xmm6
00007531fdbd4e3f  vmovaps [rsp+0x70], xmm7
00007531fdbd4e45  vmovaps [rsp+0x80], xmm8
00007531fdbd4e4e  vmovaps [rsp+0x90], xmm9
00007531fdbd4e57  vmovaps [rsp+0xA0], xmm10
00007531fdbd4e60  vmovaps [rsp+0xB0], xmm11
00007531fdbd4e69  vmovaps [rsp+0xC0], xmm12
00007531fdbd4e72  vmovaps [rsp+0xD0], xmm13
00007531fdbd4e7b  vmovaps [rsp+0xE0], xmm14
00007531fdbd4e84  sub rsp, 0x30
00007531fdbd4e88  movaps [rsp], xmm15
00007531fdbd4e8d  movaps [rsp+0x10], xmm14
00007531fdbd4e93  movaps [rsp+0x20], xmm1
00007531fdbd4e98  lea rdi, [rsp]
00007531fdbd4e9c  mov esi, 0x00
00007531fdbd4ea1  mov rax, 0x59ED111DF530
00007531fdbd4eab  call rax
00007531fdbd4ead  movaps xmm15, [rsp]
00007531fdbd4eb2  add rsp, 0x30
00007531fdbd4eb6  vmovaps xmm0, [rsp]
00007531fdbd4ebb  vmovaps xmm1, [rsp+0x10]
00007531fdbd4ec1  vmovaps xmm2, [rsp+0x20]
00007531fdbd4ec7  vmovaps xmm3, [rsp+0x30]
00007531fdbd4ecd  vmovaps xmm4, [rsp+0x40]
00007531fdbd4ed3  vmovaps xmm5, [rsp+0x50]
00007531fdbd4ed9  vmovaps xmm6, [rsp+0x60]
00007531fdbd4edf  vmovaps xmm7, [rsp+0x70]
00007531fdbd4ee5  vmovaps xmm8, [rsp+0x80]
00007531fdbd4eee  vmovaps xmm9, [rsp+0x90]
00007531fdbd4ef7  vmovaps xmm10, [rsp+0xA0]
00007531fdbd4f00  vmovaps xmm11, [rsp+0xB0]
00007531fdbd4f09  vmovaps xmm12, [rsp+0xC0]
00007531fdbd4f12  vmovaps xmm13, [rsp+0xD0]
00007531fdbd4f1b  vmovaps xmm14, [rsp+0xE0]
00007531fdbd4f24  add rsp, 0xF0
00007531fdbd4f2b  pop r11
00007531fdbd4f2d  pop r10
00007531fdbd4f2f  pop r9
00007531fdbd4f31  pop r8
00007531fdbd4f33  pop rsi
00007531fdbd4f34  pop rdi
00007531fdbd4f35  pop rdx
00007531fdbd4f36  pop rcx
00007531fdbd4f37  pop rax
00007531fdbd4f38  add rsp, 0x08
00007531fdbd4f3c  jmp 0x00007531FDBD2D12
00007531fdbd4f41  call 0x00007531FD9FF430
00007531fdbd4f46  jmp 0x00007531FDBD2D1F
00007531fdbd4f4b  sub rsp, 0x08
00007531fdbd4f4f  push rax
00007531fdbd4f50  push rcx
00007531fdbd4f51  push rdx
00007531fdbd4f52  push rdi
00007531fdbd4f53  push rsi
00007531fdbd4f54  push r8
00007531fdbd4f56  push r9
00007531fdbd4f58  push r10
00007531fdbd4f5a  push r11
00007531fdbd4f5c  sub rsp, 0xF0
00007531fdbd4f63  vmovaps [rsp], xmm0
00007531fdbd4f68  vmovaps [rsp+0x10], xmm1
00007531fdbd4f6e  vmovaps [rsp+0x20], xmm2
00007531fdbd4f74  vmovaps [rsp+0x30], xmm3
00007531fdbd4f7a  vmovaps [rsp+0x40], xmm4
00007531fdbd4f80  vmovaps [rsp+0x50], xmm5
00007531fdbd4f86  vmovaps [rsp+0x60], xmm6
00007531fdbd4f8c  vmovaps [rsp+0x70], xmm7
00007531fdbd4f92  vmovaps [rsp+0x80], xmm8
00007531fdbd4f9b  vmovaps [rsp+0x90], xmm9
00007531fdbd4fa4  vmovaps [rsp+0xA0], xmm10
00007531fdbd4fad  vmovaps [rsp+0xB0], xmm11
00007531fdbd4fb6  vmovaps [rsp+0xC0], xmm12
00007531fdbd4fbf  vmovaps [rsp+0xD0], xmm13
00007531fdbd4fc8  vmovaps [rsp+0xE0], xmm15
00007531fdbd4fd1  sub rsp, 0x30
00007531fdbd4fd5  movaps [rsp], xmm14
00007531fdbd4fda  movaps [rsp+0x10], xmm13
00007531fdbd4fe0  movaps [rsp+0x20], xmm2
00007531fdbd4fe5  lea rdi, [rsp]
00007531fdbd4fe9  mov esi, 0x00
00007531fdbd4fee  mov rax, 0x59ED111DF530
00007531fdbd4ff8  call rax
00007531fdbd4ffa  movaps xmm14, [rsp]
00007531fdbd4fff  add rsp, 0x30
00007531fdbd5003  vmovaps xmm0, [rsp]
00007531fdbd5008  vmovaps xmm1, [rsp+0x10]
00007531fdbd500e  vmovaps xmm2, [rsp+0x20]
00007531fdbd5014  vmovaps xmm3, [rsp+0x30]
00007531fdbd501a  vmovaps xmm4, [rsp+0x40]
00007531fdbd5020  vmovaps xmm5, [rsp+0x50]
00007531fdbd5026  vmovaps xmm6, [rsp+0x60]
00007531fdbd502c  vmovaps xmm7, [rsp+0x70]
00007531fdbd5032  vmovaps xmm8, [rsp+0x80]
00007531fdbd503b  vmovaps xmm9, [rsp+0x90]
00007531fdbd5044  vmovaps xmm10, [rsp+0xA0]
00007531fdbd504d  vmovaps xmm11, [rsp+0xB0]
00007531fdbd5056  vmovaps xmm12, [rsp+0xC0]
00007531fdbd505f  vmovaps xmm13, [rsp+0xD0]
00007531fdbd5068  vmovaps xmm15, [rsp+0xE0]
00007531fdbd5071  add rsp, 0xF0
00007531fdbd5078  pop r11
00007531fdbd507a  pop r10
00007531fdbd507c  pop r9
00007531fdbd507e  pop r8
00007531fdbd5080  pop rsi
00007531fdbd5081  pop rdi
00007531fdbd5082  pop rdx
00007531fdbd5083  pop rcx
00007531fdbd5084  pop rax
00007531fdbd5085  add rsp, 0x08
00007531fdbd5089  jmp 0x00007531FDBD2D4B
00007531fdbd508e  sub rsp, 0x08
00007531fdbd5092  push rax
00007531fdbd5093  push rcx
00007531fdbd5094  push rdx
00007531fdbd5095  push rdi
00007531fdbd5096  push rsi
00007531fdbd5097  push r8
00007531fdbd5099  push r9
00007531fdbd509b  push r10
00007531fdbd509d  push r11
00007531fdbd509f  sub rsp, 0xF0
00007531fdbd50a6  vmovaps [rsp], xmm0
00007531fdbd50ab  vmovaps [rsp+0x10], xmm2
00007531fdbd50b1  vmovaps [rsp+0x20], xmm3
00007531fdbd50b7  vmovaps [rsp+0x30], xmm4
00007531fdbd50bd  vmovaps [rsp+0x40], xmm5
00007531fdbd50c3  vmovaps [rsp+0x50], xmm6
00007531fdbd50c9  vmovaps [rsp+0x60], xmm7
00007531fdbd50cf  vmovaps [rsp+0x70], xmm8
00007531fdbd50d5  vmovaps [rsp+0x80], xmm9
00007531fdbd50de  vmovaps [rsp+0x90], xmm10
00007531fdbd50e7  vmovaps [rsp+0xA0], xmm11
00007531fdbd50f0  vmovaps [rsp+0xB0], xmm12
00007531fdbd50f9  vmovaps [rsp+0xC0], xmm13
00007531fdbd5102  vmovaps [rsp+0xD0], xmm14
00007531fdbd510b  vmovaps [rsp+0xE0], xmm15
00007531fdbd5114  sub rsp, 0x30
00007531fdbd5118  movaps [rsp], xmm1
00007531fdbd511c  movaps [rsp+0x10], xmm13
00007531fdbd5122  movaps [rsp+0x20], xmm2
00007531fdbd5127  lea rdi, [rsp]
00007531fdbd512b  mov esi, 0x00
00007531fdbd5130  mov rax, 0x59ED111DF530
00007531fdbd513a  call rax
00007531fdbd513c  movaps xmm1, [rsp]
00007531fdbd5140  add rsp, 0x30
00007531fdbd5144  vmovaps xmm0, [rsp]
00007531fdbd5149  vmovaps xmm2, [rsp+0x10]
00007531fdbd514f  vmovaps xmm3, [rsp+0x20]
00007531fdbd5155  vmovaps xmm4, [rsp+0x30]
00007531fdbd515b  vmovaps xmm5, [rsp+0x40]
00007531fdbd5161  vmovaps xmm6, [rsp+0x50]
00007531fdbd5167  vmovaps xmm7, [rsp+0x60]
00007531fdbd516d  vmovaps xmm8, [rsp+0x70]
00007531fdbd5173  vmovaps xmm9, [rsp+0x80]
00007531fdbd517c  vmovaps xmm10, [rsp+0x90]
00007531fdbd5185  vmovaps xmm11, [rsp+0xA0]
00007531fdbd518e  vmovaps xmm12, [rsp+0xB0]
00007531fdbd5197  vmovaps xmm13, [rsp+0xC0]
00007531fdbd51a0  vmovaps xmm14, [rsp+0xD0]
00007531fdbd51a9  vmovaps xmm15, [rsp+0xE0]
00007531fdbd51b2  add rsp, 0xF0
00007531fdbd51b9  pop r11
00007531fdbd51bb  pop r10
00007531fdbd51bd  pop r9
00007531fdbd51bf  pop r8
00007531fdbd51c1  pop rsi
00007531fdbd51c2  pop rdi
00007531fdbd51c3  pop rdx
00007531fdbd51c4  pop rcx
00007531fdbd51c5  pop rax
00007531fdbd51c6  add rsp, 0x08
00007531fdbd51ca  jmp 0x00007531FDBD2D79
00007531fdbd51cf  sub rsp, 0x08
00007531fdbd51d3  push rax
00007531fdbd51d4  push rcx
00007531fdbd51d5  push rdx
00007531fdbd51d6  push rdi
00007531fdbd51d7  push rsi
00007531fdbd51d8  push r8
00007531fdbd51da  push r9
00007531fdbd51dc  push r10
00007531fdbd51de  push r11
00007531fdbd51e0  sub rsp, 0xF0
00007531fdbd51e7  vmovaps [rsp], xmm0
00007531fdbd51ec  vmovaps [rsp+0x10], xmm1
00007531fdbd51f2  vmovaps [rsp+0x20], xmm3
00007531fdbd51f8  vmovaps [rsp+0x30], xmm4
00007531fdbd51fe  vmovaps [rsp+0x40], xmm5
00007531fdbd5204  vmovaps [rsp+0x50], xmm6
00007531fdbd520a  vmovaps [rsp+0x60], xmm7
00007531fdbd5210  vmovaps [rsp+0x70], xmm8
00007531fdbd5216  vmovaps [rsp+0x80], xmm9
00007531fdbd521f  vmovaps [rsp+0x90], xmm10
00007531fdbd5228  vmovaps [rsp+0xA0], xmm11
00007531fdbd5231  vmovaps [rsp+0xB0], xmm12
00007531fdbd523a  vmovaps [rsp+0xC0], xmm13
00007531fdbd5243  vmovaps [rsp+0xD0], xmm14
00007531fdbd524c  vmovaps [rsp+0xE0], xmm15
00007531fdbd5255  sub rsp, 0x30
00007531fdbd5259  movaps [rsp], xmm2
00007531fdbd525d  movaps [rsp+0x10], xmm1
00007531fdbd5262  movaps [rsp+0x20], xmm13
00007531fdbd5268  lea rdi, [rsp]
00007531fdbd526c  mov esi, 0x00
00007531fdbd5271  mov rax, 0x59ED111DF530
00007531fdbd527b  call rax
00007531fdbd527d  movaps xmm2, [rsp]
00007531fdbd5281  add rsp, 0x30
00007531fdbd5285  vmovaps xmm0, [rsp]
00007531fdbd528a  vmovaps xmm1, [rsp+0x10]
00007531fdbd5290  vmovaps xmm3, [rsp+0x20]
00007531fdbd5296  vmovaps xmm4, [rsp+0x30]
00007531fdbd529c  vmovaps xmm5, [rsp+0x40]
00007531fdbd52a2  vmovaps xmm6, [rsp+0x50]
00007531fdbd52a8  vmovaps xmm7, [rsp+0x60]
00007531fdbd52ae  vmovaps xmm8, [rsp+0x70]
00007531fdbd52b4  vmovaps xmm9, [rsp+0x80]
00007531fdbd52bd  vmovaps xmm10, [rsp+0x90]
00007531fdbd52c6  vmovaps xmm11, [rsp+0xA0]
00007531fdbd52cf  vmovaps xmm12, [rsp+0xB0]
00007531fdbd52d8  vmovaps xmm13, [rsp+0xC0]
00007531fdbd52e1  vmovaps xmm14, [rsp+0xD0]
00007531fdbd52ea  vmovaps xmm15, [rsp+0xE0]
00007531fdbd52f3  add rsp, 0xF0
00007531fdbd52fa  pop r11
00007531fdbd52fc  pop r10
00007531fdbd52fe  pop r9
00007531fdbd5300  pop r8
00007531fdbd5302  pop rsi
00007531fdbd5303  pop rdi
00007531fdbd5304  pop rdx
00007531fdbd5305  pop rcx
00007531fdbd5306  pop rax
00007531fdbd5307  add rsp, 0x08
00007531fdbd530b  jmp 0x00007531FDBD2DD2
00007531fdbd5310  call 0x00007531FD9FF430
00007531fdbd5315  jmp 0x00007531FDBD2DDF
00007531fdbd531a  sub rsp, 0x08
00007531fdbd531e  push rax
00007531fdbd531f  push rcx
00007531fdbd5320  push rdx
00007531fdbd5321  push rdi
00007531fdbd5322  push rsi
00007531fdbd5323  push r8
00007531fdbd5325  push r9
00007531fdbd5327  push r10
00007531fdbd5329  push r11
00007531fdbd532b  sub rsp, 0xF0
00007531fdbd5332  vmovaps [rsp], xmm0
00007531fdbd5337  vmovaps [rsp+0x10], xmm1
00007531fdbd533d  vmovaps [rsp+0x20], xmm2
00007531fdbd5343  vmovaps [rsp+0x30], xmm3
00007531fdbd5349  vmovaps [rsp+0x40], xmm4
00007531fdbd534f  vmovaps [rsp+0x50], xmm5
00007531fdbd5355  vmovaps [rsp+0x60], xmm6
00007531fdbd535b  vmovaps [rsp+0x70], xmm7
00007531fdbd5361  vmovaps [rsp+0x80], xmm8
00007531fdbd536a  vmovaps [rsp+0x90], xmm9
00007531fdbd5373  vmovaps [rsp+0xA0], xmm10
00007531fdbd537c  vmovaps [rsp+0xB0], xmm11
00007531fdbd5385  vmovaps [rsp+0xC0], xmm12
00007531fdbd538e  vmovaps [rsp+0xD0], xmm13
00007531fdbd5397  vmovaps [rsp+0xE0], xmm14
00007531fdbd53a0  sub rsp, 0x30
00007531fdbd53a4  movaps [rsp], xmm15
00007531fdbd53a9  movaps [rsp+0x10], xmm13
00007531fdbd53af  movaps [rsp+0x20], xmm1
00007531fdbd53b4  lea rdi, [rsp]
00007531fdbd53b8  mov esi, 0x00
00007531fdbd53bd  mov rax, 0x59ED111DF530
00007531fdbd53c7  call rax
00007531fdbd53c9  movaps xmm15, [rsp]
00007531fdbd53ce  add rsp, 0x30
00007531fdbd53d2  vmovaps xmm0, [rsp]
00007531fdbd53d7  vmovaps xmm1, [rsp+0x10]
00007531fdbd53dd  vmovaps xmm2, [rsp+0x20]
00007531fdbd53e3  vmovaps xmm3, [rsp+0x30]
00007531fdbd53e9  vmovaps xmm4, [rsp+0x40]
00007531fdbd53ef  vmovaps xmm5, [rsp+0x50]
00007531fdbd53f5  vmovaps xmm6, [rsp+0x60]
00007531fdbd53fb  vmovaps xmm7, [rsp+0x70]
00007531fdbd5401  vmovaps xmm8, [rsp+0x80]
00007531fdbd540a  vmovaps xmm9, [rsp+0x90]
00007531fdbd5413  vmovaps xmm10, [rsp+0xA0]
00007531fdbd541c  vmovaps xmm11, [rsp+0xB0]
00007531fdbd5425  vmovaps xmm12, [rsp+0xC0]
00007531fdbd542e  vmovaps xmm13, [rsp+0xD0]
00007531fdbd5437  vmovaps xmm14, [rsp+0xE0]
00007531fdbd5440  add rsp, 0xF0
00007531fdbd5447  pop r11
00007531fdbd5449  pop r10
00007531fdbd544b  pop r9
00007531fdbd544d  pop r8
00007531fdbd544f  pop rsi
00007531fdbd5450  pop rdi
00007531fdbd5451  pop rdx
00007531fdbd5452  pop rcx
00007531fdbd5453  pop rax
00007531fdbd5454  add rsp, 0x08
00007531fdbd5458  jmp 0x00007531FDBD2E1E
00007531fdbd545d  sub rsp, 0x08
00007531fdbd5461  push rax
00007531fdbd5462  push rcx
00007531fdbd5463  push rdx
00007531fdbd5464  push rdi
00007531fdbd5465  push rsi
00007531fdbd5466  push r8
00007531fdbd5468  push r9
00007531fdbd546a  push r10
00007531fdbd546c  push r11
00007531fdbd546e  sub rsp, 0xF0
00007531fdbd5475  vmovaps [rsp], xmm0
00007531fdbd547a  vmovaps [rsp+0x10], xmm1
00007531fdbd5480  vmovaps [rsp+0x20], xmm2
00007531fdbd5486  vmovaps [rsp+0x30], xmm3
00007531fdbd548c  vmovaps [rsp+0x40], xmm4
00007531fdbd5492  vmovaps [rsp+0x50], xmm5
00007531fdbd5498  vmovaps [rsp+0x60], xmm6
00007531fdbd549e  vmovaps [rsp+0x70], xmm7
00007531fdbd54a4  vmovaps [rsp+0x80], xmm8
00007531fdbd54ad  vmovaps [rsp+0x90], xmm9
00007531fdbd54b6  vmovaps [rsp+0xA0], xmm10
00007531fdbd54bf  vmovaps [rsp+0xB0], xmm11
00007531fdbd54c8  vmovaps [rsp+0xC0], xmm12
00007531fdbd54d1  vmovaps [rsp+0xD0], xmm13
00007531fdbd54da  vmovaps [rsp+0xE0], xmm15
00007531fdbd54e3  sub rsp, 0x30
00007531fdbd54e7  movaps [rsp], xmm14
00007531fdbd54ec  movaps [rsp+0x10], xmm11
00007531fdbd54f2  movaps [rsp+0x20], xmm1
00007531fdbd54f7  lea rdi, [rsp]
00007531fdbd54fb  mov esi, 0x00
00007531fdbd5500  mov rax, 0x59ED111DF530
00007531fdbd550a  call rax
00007531fdbd550c  movaps xmm14, [rsp]
00007531fdbd5511  add rsp, 0x30
00007531fdbd5515  vmovaps xmm0, [rsp]
00007531fdbd551a  vmovaps xmm1, [rsp+0x10]
00007531fdbd5520  vmovaps xmm2, [rsp+0x20]
00007531fdbd5526  vmovaps xmm3, [rsp+0x30]
00007531fdbd552c  vmovaps xmm4, [rsp+0x40]
00007531fdbd5532  vmovaps xmm5, [rsp+0x50]
00007531fdbd5538  vmovaps xmm6, [rsp+0x60]
00007531fdbd553e  vmovaps xmm7, [rsp+0x70]
00007531fdbd5544  vmovaps xmm8, [rsp+0x80]
00007531fdbd554d  vmovaps xmm9, [rsp+0x90]
00007531fdbd5556  vmovaps xmm10, [rsp+0xA0]
00007531fdbd555f  vmovaps xmm11, [rsp+0xB0]
00007531fdbd5568  vmovaps xmm12, [rsp+0xC0]
00007531fdbd5571  vmovaps xmm13, [rsp+0xD0]
00007531fdbd557a  vmovaps xmm15, [rsp+0xE0]
00007531fdbd5583  add rsp, 0xF0
00007531fdbd558a  pop r11
00007531fdbd558c  pop r10
00007531fdbd558e  pop r9
00007531fdbd5590  pop r8
00007531fdbd5592  pop rsi
00007531fdbd5593  pop rdi
00007531fdbd5594  pop rdx
00007531fdbd5595  pop rcx
00007531fdbd5596  pop rax
00007531fdbd5597  add rsp, 0x08
00007531fdbd559b  jmp 0x00007531FDBD2E48
00007531fdbd55a0  sub rsp, 0x08
00007531fdbd55a4  push rax
00007531fdbd55a5  push rcx
00007531fdbd55a6  push rdx
00007531fdbd55a7  push rdi
00007531fdbd55a8  push rsi
00007531fdbd55a9  push r8
00007531fdbd55ab  push r9
00007531fdbd55ad  push r10
00007531fdbd55af  push r11
00007531fdbd55b1  sub rsp, 0xF0
00007531fdbd55b8  vmovaps [rsp], xmm0
00007531fdbd55bd  vmovaps [rsp+0x10], xmm1
00007531fdbd55c3  vmovaps [rsp+0x20], xmm2
00007531fdbd55c9  vmovaps [rsp+0x30], xmm3
00007531fdbd55cf  vmovaps [rsp+0x40], xmm4
00007531fdbd55d5  vmovaps [rsp+0x50], xmm5
00007531fdbd55db  vmovaps [rsp+0x60], xmm6
00007531fdbd55e1  vmovaps [rsp+0x70], xmm7
00007531fdbd55e7  vmovaps [rsp+0x80], xmm8
00007531fdbd55f0  vmovaps [rsp+0x90], xmm9
00007531fdbd55f9  vmovaps [rsp+0xA0], xmm10
00007531fdbd5602  vmovaps [rsp+0xB0], xmm11
00007531fdbd560b  vmovaps [rsp+0xC0], xmm12
00007531fdbd5614  vmovaps [rsp+0xD0], xmm14
00007531fdbd561d  vmovaps [rsp+0xE0], xmm15
00007531fdbd5626  sub rsp, 0x30
00007531fdbd562a  movaps [rsp], xmm13
00007531fdbd562f  movaps [rsp+0x10], xmm11
00007531fdbd5635  movaps [rsp+0x20], xmm1
00007531fdbd563a  lea rdi, [rsp]
00007531fdbd563e  mov esi, 0x00
00007531fdbd5643  mov rax, 0x59ED111DF530
00007531fdbd564d  call rax
00007531fdbd564f  movaps xmm13, [rsp]
00007531fdbd5654  add rsp, 0x30
00007531fdbd5658  vmovaps xmm0, [rsp]
00007531fdbd565d  vmovaps xmm1, [rsp+0x10]
00007531fdbd5663  vmovaps xmm2, [rsp+0x20]
00007531fdbd5669  vmovaps xmm3, [rsp+0x30]
00007531fdbd566f  vmovaps xmm4, [rsp+0x40]
00007531fdbd5675  vmovaps xmm5, [rsp+0x50]
00007531fdbd567b  vmovaps xmm6, [rsp+0x60]
00007531fdbd5681  vmovaps xmm7, [rsp+0x70]
00007531fdbd5687  vmovaps xmm8, [rsp+0x80]
00007531fdbd5690  vmovaps xmm9, [rsp+0x90]
00007531fdbd5699  vmovaps xmm10, [rsp+0xA0]
00007531fdbd56a2  vmovaps xmm11, [rsp+0xB0]
00007531fdbd56ab  vmovaps xmm12, [rsp+0xC0]
00007531fdbd56b4  vmovaps xmm14, [rsp+0xD0]
00007531fdbd56bd  vmovaps xmm15, [rsp+0xE0]
00007531fdbd56c6  add rsp, 0xF0
00007531fdbd56cd  pop r11
00007531fdbd56cf  pop r10
00007531fdbd56d1  pop r9
00007531fdbd56d3  pop r8
00007531fdbd56d5  pop rsi
00007531fdbd56d6  pop rdi
00007531fdbd56d7  pop rdx
00007531fdbd56d8  pop rcx
00007531fdbd56d9  pop rax
00007531fdbd56da  add rsp, 0x08
00007531fdbd56de  jmp 0x00007531FDBD2E9D
00007531fdbd56e3  call 0x00007531FD9FF430
00007531fdbd56e8  jmp 0x00007531FDBD2EAA
00007531fdbd56ed  sub rsp, 0x08
00007531fdbd56f1  push rax
00007531fdbd56f2  push rcx
00007531fdbd56f3  push rdx
00007531fdbd56f4  push rdi
00007531fdbd56f5  push rsi
00007531fdbd56f6  push r8
00007531fdbd56f8  push r9
00007531fdbd56fa  push r10
00007531fdbd56fc  push r11
00007531fdbd56fe  sub rsp, 0xF0
00007531fdbd5705  vmovaps [rsp], xmm0
00007531fdbd570a  vmovaps [rsp+0x10], xmm1
00007531fdbd5710  vmovaps [rsp+0x20], xmm2
00007531fdbd5716  vmovaps [rsp+0x30], xmm3
00007531fdbd571c  vmovaps [rsp+0x40], xmm4
00007531fdbd5722  vmovaps [rsp+0x50], xmm5
00007531fdbd5728  vmovaps [rsp+0x60], xmm6
00007531fdbd572e  vmovaps [rsp+0x70], xmm7
00007531fdbd5734  vmovaps [rsp+0x80], xmm8
00007531fdbd573d  vmovaps [rsp+0x90], xmm9
00007531fdbd5746  vmovaps [rsp+0xA0], xmm10
00007531fdbd574f  vmovaps [rsp+0xB0], xmm11
00007531fdbd5758  vmovaps [rsp+0xC0], xmm12
00007531fdbd5761  vmovaps [rsp+0xD0], xmm13
00007531fdbd576a  vmovaps [rsp+0xE0], xmm14
00007531fdbd5773  sub rsp, 0x30
00007531fdbd5777  movaps [rsp], xmm15
00007531fdbd577c  movaps [rsp+0x10], xmm11
00007531fdbd5782  movaps [rsp+0x20], xmm1
00007531fdbd5787  lea rdi, [rsp]
00007531fdbd578b  mov esi, 0x00
00007531fdbd5790  mov rax, 0x59ED111DF530
00007531fdbd579a  call rax
00007531fdbd579c  movaps xmm15, [rsp]
00007531fdbd57a1  add rsp, 0x30
00007531fdbd57a5  vmovaps xmm0, [rsp]
00007531fdbd57aa  vmovaps xmm1, [rsp+0x10]
00007531fdbd57b0  vmovaps xmm2, [rsp+0x20]
00007531fdbd57b6  vmovaps xmm3, [rsp+0x30]
00007531fdbd57bc  vmovaps xmm4, [rsp+0x40]
00007531fdbd57c2  vmovaps xmm5, [rsp+0x50]
00007531fdbd57c8  vmovaps xmm6, [rsp+0x60]
00007531fdbd57ce  vmovaps xmm7, [rsp+0x70]
00007531fdbd57d4  vmovaps xmm8, [rsp+0x80]
00007531fdbd57dd  vmovaps xmm9, [rsp+0x90]
00007531fdbd57e6  vmovaps xmm10, [rsp+0xA0]
00007531fdbd57ef  vmovaps xmm11, [rsp+0xB0]
00007531fdbd57f8  vmovaps xmm12, [rsp+0xC0]
00007531fdbd5801  vmovaps xmm13, [rsp+0xD0]
00007531fdbd580a  vmovaps xmm14, [rsp+0xE0]
00007531fdbd5813  add rsp, 0xF0
00007531fdbd581a  pop r11
00007531fdbd581c  pop r10
00007531fdbd581e  pop r9
00007531fdbd5820  pop r8
00007531fdbd5822  pop rsi
00007531fdbd5823  pop rdi
00007531fdbd5824  pop rdx
00007531fdbd5825  pop rcx
00007531fdbd5826  pop rax
00007531fdbd5827  add rsp, 0x08
00007531fdbd582b  jmp 0x00007531FDBD2EE3
00007531fdbd5830  sub rsp, 0x08
00007531fdbd5834  push rax
00007531fdbd5835  push rcx
00007531fdbd5836  push rdx
00007531fdbd5837  push rdi
00007531fdbd5838  push rsi
00007531fdbd5839  push r8
00007531fdbd583b  push r9
00007531fdbd583d  push r10
00007531fdbd583f  push r11
00007531fdbd5841  sub rsp, 0xF0
00007531fdbd5848  vmovaps [rsp], xmm0
00007531fdbd584d  vmovaps [rsp+0x10], xmm1
00007531fdbd5853  vmovaps [rsp+0x20], xmm2
00007531fdbd5859  vmovaps [rsp+0x30], xmm3
00007531fdbd585f  vmovaps [rsp+0x40], xmm4
00007531fdbd5865  vmovaps [rsp+0x50], xmm5
00007531fdbd586b  vmovaps [rsp+0x60], xmm6
00007531fdbd5871  vmovaps [rsp+0x70], xmm7
00007531fdbd5877  vmovaps [rsp+0x80], xmm8
00007531fdbd5880  vmovaps [rsp+0x90], xmm9
00007531fdbd5889  vmovaps [rsp+0xA0], xmm10
00007531fdbd5892  vmovaps [rsp+0xB0], xmm12
00007531fdbd589b  vmovaps [rsp+0xC0], xmm13
00007531fdbd58a4  vmovaps [rsp+0xD0], xmm14
00007531fdbd58ad  vmovaps [rsp+0xE0], xmm15
00007531fdbd58b6  sub rsp, 0x30
00007531fdbd58ba  movaps [rsp], xmm11
00007531fdbd58bf  movaps [rsp+0x10], xmm6
00007531fdbd58c4  movaps [rsp+0x20], xmm14
00007531fdbd58ca  lea rdi, [rsp]
00007531fdbd58ce  mov esi, 0x00
00007531fdbd58d3  mov rax, 0x59ED111DF530
00007531fdbd58dd  call rax
00007531fdbd58df  movaps xmm11, [rsp]
00007531fdbd58e4  add rsp, 0x30
00007531fdbd58e8  vmovaps xmm0, [rsp]
00007531fdbd58ed  vmovaps xmm1, [rsp+0x10]
00007531fdbd58f3  vmovaps xmm2, [rsp+0x20]
00007531fdbd58f9  vmovaps xmm3, [rsp+0x30]
00007531fdbd58ff  vmovaps xmm4, [rsp+0x40]
00007531fdbd5905  vmovaps xmm5, [rsp+0x50]
00007531fdbd590b  vmovaps xmm6, [rsp+0x60]
00007531fdbd5911  vmovaps xmm7, [rsp+0x70]
00007531fdbd5917  vmovaps xmm8, [rsp+0x80]
00007531fdbd5920  vmovaps xmm9, [rsp+0x90]
00007531fdbd5929  vmovaps xmm10, [rsp+0xA0]
00007531fdbd5932  vmovaps xmm12, [rsp+0xB0]
00007531fdbd593b  vmovaps xmm13, [rsp+0xC0]
00007531fdbd5944  vmovaps xmm14, [rsp+0xD0]
00007531fdbd594d  vmovaps xmm15, [rsp+0xE0]
00007531fdbd5956  add rsp, 0xF0
00007531fdbd595d  pop r11
00007531fdbd595f  pop r10
00007531fdbd5961  pop r9
00007531fdbd5963  pop r8
00007531fdbd5965  pop rsi
00007531fdbd5966  pop rdi
00007531fdbd5967  pop rdx
00007531fdbd5968  pop rcx
00007531fdbd5969  pop rax
00007531fdbd596a  add rsp, 0x08
00007531fdbd596e  jmp 0x00007531FDBD2F5B
00007531fdbd5973  call 0x00007531FD9FF430
00007531fdbd5978  jmp 0x00007531FDBD2F65
00007531fdbd597d  sub rsp, 0x08
00007531fdbd5981  push rax
00007531fdbd5982  push rcx
00007531fdbd5983  push rdx
00007531fdbd5984  push rdi
00007531fdbd5985  push rsi
00007531fdbd5986  push r8
00007531fdbd5988  push r9
00007531fdbd598a  push r10
00007531fdbd598c  push r11
00007531fdbd598e  sub rsp, 0xF0
00007531fdbd5995  vmovaps [rsp], xmm0
00007531fdbd599a  vmovaps [rsp+0x10], xmm1
00007531fdbd59a0  vmovaps [rsp+0x20], xmm2
00007531fdbd59a6  vmovaps [rsp+0x30], xmm3
00007531fdbd59ac  vmovaps [rsp+0x40], xmm4
00007531fdbd59b2  vmovaps [rsp+0x50], xmm5
00007531fdbd59b8  vmovaps [rsp+0x60], xmm6
00007531fdbd59be  vmovaps [rsp+0x70], xmm7
00007531fdbd59c4  vmovaps [rsp+0x80], xmm8
00007531fdbd59cd  vmovaps [rsp+0x90], xmm9
00007531fdbd59d6  vmovaps [rsp+0xA0], xmm10
00007531fdbd59df  vmovaps [rsp+0xB0], xmm11
00007531fdbd59e8  vmovaps [rsp+0xC0], xmm12
00007531fdbd59f1  vmovaps [rsp+0xD0], xmm13
00007531fdbd59fa  vmovaps [rsp+0xE0], xmm15
00007531fdbd5a03  sub rsp, 0x30
00007531fdbd5a07  movaps [rsp], xmm14
00007531fdbd5a0c  movaps [rsp+0x10], xmm6
00007531fdbd5a11  movaps [rsp+0x20], xmm2
00007531fdbd5a16  lea rdi, [rsp]
00007531fdbd5a1a  mov esi, 0x00
00007531fdbd5a1f  mov rax, 0x59ED111DF530
00007531fdbd5a29  call rax
00007531fdbd5a2b  movaps xmm14, [rsp]
00007531fdbd5a30  add rsp, 0x30
00007531fdbd5a34  vmovaps xmm0, [rsp]
00007531fdbd5a39  vmovaps xmm1, [rsp+0x10]
00007531fdbd5a3f  vmovaps xmm2, [rsp+0x20]
00007531fdbd5a45  vmovaps xmm3, [rsp+0x30]
00007531fdbd5a4b  vmovaps xmm4, [rsp+0x40]
00007531fdbd5a51  vmovaps xmm5, [rsp+0x50]
00007531fdbd5a57  vmovaps xmm6, [rsp+0x60]
00007531fdbd5a5d  vmovaps xmm7, [rsp+0x70]
00007531fdbd5a63  vmovaps xmm8, [rsp+0x80]
00007531fdbd5a6c  vmovaps xmm9, [rsp+0x90]
00007531fdbd5a75  vmovaps xmm10, [rsp+0xA0]
00007531fdbd5a7e  vmovaps xmm11, [rsp+0xB0]
00007531fdbd5a87  vmovaps xmm12, [rsp+0xC0]
00007531fdbd5a90  vmovaps xmm13, [rsp+0xD0]
00007531fdbd5a99  vmovaps xmm15, [rsp+0xE0]
00007531fdbd5aa2  add rsp, 0xF0
00007531fdbd5aa9  pop r11
00007531fdbd5aab  pop r10
00007531fdbd5aad  pop r9
00007531fdbd5aaf  pop r8
00007531fdbd5ab1  pop rsi
00007531fdbd5ab2  pop rdi
00007531fdbd5ab3  pop rdx
00007531fdbd5ab4  pop rcx
00007531fdbd5ab5  pop rax
00007531fdbd5ab6  add rsp, 0x08
00007531fdbd5aba  jmp 0x00007531FDBD2F99
00007531fdbd5abf  sub rsp, 0x08
00007531fdbd5ac3  push rax
00007531fdbd5ac4  push rcx
00007531fdbd5ac5  push rdx
00007531fdbd5ac6  push rdi
00007531fdbd5ac7  push rsi
00007531fdbd5ac8  push r8
00007531fdbd5aca  push r9
00007531fdbd5acc  push r10
00007531fdbd5ace  push r11
00007531fdbd5ad0  sub rsp, 0xF0
00007531fdbd5ad7  vmovaps [rsp], xmm0
00007531fdbd5adc  vmovaps [rsp+0x10], xmm1
00007531fdbd5ae2  vmovaps [rsp+0x20], xmm2
00007531fdbd5ae8  vmovaps [rsp+0x30], xmm3
00007531fdbd5aee  vmovaps [rsp+0x40], xmm4
00007531fdbd5af4  vmovaps [rsp+0x50], xmm5
00007531fdbd5afa  vmovaps [rsp+0x60], xmm7
00007531fdbd5b00  vmovaps [rsp+0x70], xmm8
00007531fdbd5b06  vmovaps [rsp+0x80], xmm9
00007531fdbd5b0f  vmovaps [rsp+0x90], xmm10
00007531fdbd5b18  vmovaps [rsp+0xA0], xmm11
00007531fdbd5b21  vmovaps [rsp+0xB0], xmm12
00007531fdbd5b2a  vmovaps [rsp+0xC0], xmm13
00007531fdbd5b33  vmovaps [rsp+0xD0], xmm14
00007531fdbd5b3c  vmovaps [rsp+0xE0], xmm15
00007531fdbd5b45  sub rsp, 0x30
00007531fdbd5b49  movaps [rsp], xmm6
00007531fdbd5b4d  movaps [rsp+0x10], xmm5
00007531fdbd5b52  movaps [rsp+0x20], xmm1
00007531fdbd5b57  lea rdi, [rsp]
00007531fdbd5b5b  mov esi, 0x00
00007531fdbd5b60  mov rax, 0x59ED111DF530
00007531fdbd5b6a  call rax
00007531fdbd5b6c  movaps xmm6, [rsp]
00007531fdbd5b70  add rsp, 0x30
00007531fdbd5b74  vmovaps xmm0, [rsp]
00007531fdbd5b79  vmovaps xmm1, [rsp+0x10]
00007531fdbd5b7f  vmovaps xmm2, [rsp+0x20]
00007531fdbd5b85  vmovaps xmm3, [rsp+0x30]
00007531fdbd5b8b  vmovaps xmm4, [rsp+0x40]
00007531fdbd5b91  vmovaps xmm5, [rsp+0x50]
00007531fdbd5b97  vmovaps xmm7, [rsp+0x60]
00007531fdbd5b9d  vmovaps xmm8, [rsp+0x70]
00007531fdbd5ba3  vmovaps xmm9, [rsp+0x80]
00007531fdbd5bac  vmovaps xmm10, [rsp+0x90]
00007531fdbd5bb5  vmovaps xmm11, [rsp+0xA0]
00007531fdbd5bbe  vmovaps xmm12, [rsp+0xB0]
00007531fdbd5bc7  vmovaps xmm13, [rsp+0xC0]
00007531fdbd5bd0  vmovaps xmm14, [rsp+0xD0]
00007531fdbd5bd9  vmovaps xmm15, [rsp+0xE0]
00007531fdbd5be2  add rsp, 0xF0
00007531fdbd5be9  pop r11
00007531fdbd5beb  pop r10
00007531fdbd5bed  pop r9
00007531fdbd5bef  pop r8
00007531fdbd5bf1  pop rsi
00007531fdbd5bf2  pop rdi
00007531fdbd5bf3  pop rdx
00007531fdbd5bf4  pop rcx
00007531fdbd5bf5  pop rax
00007531fdbd5bf6  add rsp, 0x08
00007531fdbd5bfa  jmp 0x00007531FDBD2FBF
00007531fdbd5bff  sub rsp, 0x08
00007531fdbd5c03  push rax
00007531fdbd5c04  push rcx
00007531fdbd5c05  push rdx
00007531fdbd5c06  push rdi
00007531fdbd5c07  push rsi
00007531fdbd5c08  push r8
00007531fdbd5c0a  push r9
00007531fdbd5c0c  push r10
00007531fdbd5c0e  push r11
00007531fdbd5c10  sub rsp, 0xF0
00007531fdbd5c17  vmovaps [rsp], xmm0
00007531fdbd5c1c  vmovaps [rsp+0x10], xmm2
00007531fdbd5c22  vmovaps [rsp+0x20], xmm3
00007531fdbd5c28  vmovaps [rsp+0x30], xmm4
00007531fdbd5c2e  vmovaps [rsp+0x40], xmm5
00007531fdbd5c34  vmovaps [rsp+0x50], xmm6
00007531fdbd5c3a  vmovaps [rsp+0x60], xmm7
00007531fdbd5c40  vmovaps [rsp+0x70], xmm8
00007531fdbd5c46  vmovaps [rsp+0x80], xmm9
00007531fdbd5c4f  vmovaps [rsp+0x90], xmm10
00007531fdbd5c58  vmovaps [rsp+0xA0], xmm11
00007531fdbd5c61  vmovaps [rsp+0xB0], xmm12
00007531fdbd5c6a  vmovaps [rsp+0xC0], xmm13
00007531fdbd5c73  vmovaps [rsp+0xD0], xmm14
00007531fdbd5c7c  vmovaps [rsp+0xE0], xmm15
00007531fdbd5c85  sub rsp, 0x30
00007531fdbd5c89  movaps [rsp], xmm1
00007531fdbd5c8d  movaps [rsp+0x10], xmm5
00007531fdbd5c92  movaps [rsp+0x20], xmm13
00007531fdbd5c98  lea rdi, [rsp]
00007531fdbd5c9c  mov esi, 0x00
00007531fdbd5ca1  mov rax, 0x59ED111DF530
00007531fdbd5cab  call rax
00007531fdbd5cad  movaps xmm1, [rsp]
00007531fdbd5cb1  add rsp, 0x30
00007531fdbd5cb5  vmovaps xmm0, [rsp]
00007531fdbd5cba  vmovaps xmm2, [rsp+0x10]
00007531fdbd5cc0  vmovaps xmm3, [rsp+0x20]
00007531fdbd5cc6  vmovaps xmm4, [rsp+0x30]
00007531fdbd5ccc  vmovaps xmm5, [rsp+0x40]
00007531fdbd5cd2  vmovaps xmm6, [rsp+0x50]
00007531fdbd5cd8  vmovaps xmm7, [rsp+0x60]
00007531fdbd5cde  vmovaps xmm8, [rsp+0x70]
00007531fdbd5ce4  vmovaps xmm9, [rsp+0x80]
00007531fdbd5ced  vmovaps xmm10, [rsp+0x90]
00007531fdbd5cf6  vmovaps xmm11, [rsp+0xA0]
00007531fdbd5cff  vmovaps xmm12, [rsp+0xB0]
00007531fdbd5d08  vmovaps xmm13, [rsp+0xC0]
00007531fdbd5d11  vmovaps xmm14, [rsp+0xD0]
00007531fdbd5d1a  vmovaps xmm15, [rsp+0xE0]
00007531fdbd5d23  add rsp, 0xF0
00007531fdbd5d2a  pop r11
00007531fdbd5d2c  pop r10
00007531fdbd5d2e  pop r9
00007531fdbd5d30  pop r8
00007531fdbd5d32  pop rsi
00007531fdbd5d33  pop rdi
00007531fdbd5d34  pop rdx
00007531fdbd5d35  pop rcx
00007531fdbd5d36  pop rax
00007531fdbd5d37  add rsp, 0x08
00007531fdbd5d3b  jmp 0x00007531FDBD2FDD
00007531fdbd5d40  sub rsp, 0x08
00007531fdbd5d44  push rax
00007531fdbd5d45  push rcx
00007531fdbd5d46  push rdx
00007531fdbd5d47  push rdi
00007531fdbd5d48  push rsi
00007531fdbd5d49  push r8
00007531fdbd5d4b  push r9
00007531fdbd5d4d  push r10
00007531fdbd5d4f  push r11
00007531fdbd5d51  sub rsp, 0xF0
00007531fdbd5d58  vmovaps [rsp], xmm0
00007531fdbd5d5d  vmovaps [rsp+0x10], xmm1
00007531fdbd5d63  vmovaps [rsp+0x20], xmm2
00007531fdbd5d69  vmovaps [rsp+0x30], xmm3
00007531fdbd5d6f  vmovaps [rsp+0x40], xmm4
00007531fdbd5d75  vmovaps [rsp+0x50], xmm6
00007531fdbd5d7b  vmovaps [rsp+0x60], xmm7
00007531fdbd5d81  vmovaps [rsp+0x70], xmm8
00007531fdbd5d87  vmovaps [rsp+0x80], xmm9
00007531fdbd5d90  vmovaps [rsp+0x90], xmm10
00007531fdbd5d99  vmovaps [rsp+0xA0], xmm11
00007531fdbd5da2  vmovaps [rsp+0xB0], xmm12
00007531fdbd5dab  vmovaps [rsp+0xC0], xmm13
00007531fdbd5db4  vmovaps [rsp+0xD0], xmm14
00007531fdbd5dbd  vmovaps [rsp+0xE0], xmm15
00007531fdbd5dc6  sub rsp, 0x30
00007531fdbd5dca  movaps [rsp], xmm5
00007531fdbd5dce  movaps [rsp+0x10], xmm2
00007531fdbd5dd3  movaps [rsp+0x20], xmm13
00007531fdbd5dd9  lea rdi, [rsp]
00007531fdbd5ddd  mov esi, 0x00
00007531fdbd5de2  mov rax, 0x59ED111DF530
00007531fdbd5dec  call rax
00007531fdbd5dee  movaps xmm5, [rsp]
00007531fdbd5df2  add rsp, 0x30
00007531fdbd5df6  vmovaps xmm0, [rsp]
00007531fdbd5dfb  vmovaps xmm1, [rsp+0x10]
00007531fdbd5e01  vmovaps xmm2, [rsp+0x20]
00007531fdbd5e07  vmovaps xmm3, [rsp+0x30]
00007531fdbd5e0d  vmovaps xmm4, [rsp+0x40]
00007531fdbd5e13  vmovaps xmm6, [rsp+0x50]
00007531fdbd5e19  vmovaps xmm7, [rsp+0x60]
00007531fdbd5e1f  vmovaps xmm8, [rsp+0x70]
00007531fdbd5e25  vmovaps xmm9, [rsp+0x80]
00007531fdbd5e2e  vmovaps xmm10, [rsp+0x90]
00007531fdbd5e37  vmovaps xmm11, [rsp+0xA0]
00007531fdbd5e40  vmovaps xmm12, [rsp+0xB0]
00007531fdbd5e49  vmovaps xmm13, [rsp+0xC0]
00007531fdbd5e52  vmovaps xmm14, [rsp+0xD0]
00007531fdbd5e5b  vmovaps xmm15, [rsp+0xE0]
00007531fdbd5e64  add rsp, 0xF0
00007531fdbd5e6b  pop r11
00007531fdbd5e6d  pop r10
00007531fdbd5e6f  pop r9
00007531fdbd5e71  pop r8
00007531fdbd5e73  pop rsi
00007531fdbd5e74  pop rdi
00007531fdbd5e75  pop rdx
00007531fdbd5e76  pop rcx
00007531fdbd5e77  pop rax
00007531fdbd5e78  add rsp, 0x08
00007531fdbd5e7c  jmp 0x00007531FDBD3013
00007531fdbd5e81  sub rsp, 0x08
00007531fdbd5e85  push rax
00007531fdbd5e86  push rcx
00007531fdbd5e87  push rdx
00007531fdbd5e88  push rdi
00007531fdbd5e89  push rsi
00007531fdbd5e8a  push r8
00007531fdbd5e8c  push r9
00007531fdbd5e8e  push r10
00007531fdbd5e90  push r11
00007531fdbd5e92  sub rsp, 0xF0
00007531fdbd5e99  vmovaps [rsp], xmm0
00007531fdbd5e9e  vmovaps [rsp+0x10], xmm1
00007531fdbd5ea4  vmovaps [rsp+0x20], xmm2
00007531fdbd5eaa  vmovaps [rsp+0x30], xmm3
00007531fdbd5eb0  vmovaps [rsp+0x40], xmm4
00007531fdbd5eb6  vmovaps [rsp+0x50], xmm5
00007531fdbd5ebc  vmovaps [rsp+0x60], xmm6
00007531fdbd5ec2  vmovaps [rsp+0x70], xmm7
00007531fdbd5ec8  vmovaps [rsp+0x80], xmm8
00007531fdbd5ed1  vmovaps [rsp+0x90], xmm9
00007531fdbd5eda  vmovaps [rsp+0xA0], xmm10
00007531fdbd5ee3  vmovaps [rsp+0xB0], xmm11
00007531fdbd5eec  vmovaps [rsp+0xC0], xmm12
00007531fdbd5ef5  vmovaps [rsp+0xD0], xmm14
00007531fdbd5efe  vmovaps [rsp+0xE0], xmm15
00007531fdbd5f07  sub rsp, 0x30
00007531fdbd5f0b  movaps [rsp], xmm13
00007531fdbd5f10  movaps [rsp+0x10], xmm10
00007531fdbd5f16  movaps [rsp+0x20], xmm1
00007531fdbd5f1b  lea rdi, [rsp]
00007531fdbd5f1f  mov esi, 0x00
00007531fdbd5f24  mov rax, 0x59ED111DF530
00007531fdbd5f2e  call rax
00007531fdbd5f30  movaps xmm13, [rsp]
00007531fdbd5f35  add rsp, 0x30
00007531fdbd5f39  vmovaps xmm0, [rsp]
00007531fdbd5f3e  vmovaps xmm1, [rsp+0x10]
00007531fdbd5f44  vmovaps xmm2, [rsp+0x20]
00007531fdbd5f4a  vmovaps xmm3, [rsp+0x30]
00007531fdbd5f50  vmovaps xmm4, [rsp+0x40]
00007531fdbd5f56  vmovaps xmm5, [rsp+0x50]
00007531fdbd5f5c  vmovaps xmm6, [rsp+0x60]
00007531fdbd5f62  vmovaps xmm7, [rsp+0x70]
00007531fdbd5f68  vmovaps xmm8, [rsp+0x80]
00007531fdbd5f71  vmovaps xmm9, [rsp+0x90]
00007531fdbd5f7a  vmovaps xmm10, [rsp+0xA0]
00007531fdbd5f83  vmovaps xmm11, [rsp+0xB0]
00007531fdbd5f8c  vmovaps xmm12, [rsp+0xC0]
00007531fdbd5f95  vmovaps xmm14, [rsp+0xD0]
00007531fdbd5f9e  vmovaps xmm15, [rsp+0xE0]
00007531fdbd5fa7  add rsp, 0xF0
00007531fdbd5fae  pop r11
00007531fdbd5fb0  pop r10
00007531fdbd5fb2  pop r9
00007531fdbd5fb4  pop r8
00007531fdbd5fb6  pop rsi
00007531fdbd5fb7  pop rdi
00007531fdbd5fb8  pop rdx
00007531fdbd5fb9  pop rcx
00007531fdbd5fba  pop rax
00007531fdbd5fbb  add rsp, 0x08
00007531fdbd5fbf  jmp 0x00007531FDBD303C
00007531fdbd5fc4  sub rsp, 0x08
00007531fdbd5fc8  push rax
00007531fdbd5fc9  push rcx
00007531fdbd5fca  push rdx
00007531fdbd5fcb  push rdi
00007531fdbd5fcc  push rsi
00007531fdbd5fcd  push r8
00007531fdbd5fcf  push r9
00007531fdbd5fd1  push r10
00007531fdbd5fd3  push r11
00007531fdbd5fd5  sub rsp, 0xF0
00007531fdbd5fdc  vmovaps [rsp], xmm0
00007531fdbd5fe1  vmovaps [rsp+0x10], xmm2
00007531fdbd5fe7  vmovaps [rsp+0x20], xmm3
00007531fdbd5fed  vmovaps [rsp+0x30], xmm4
00007531fdbd5ff3  vmovaps [rsp+0x40], xmm5
00007531fdbd5ff9  vmovaps [rsp+0x50], xmm6
00007531fdbd5fff  vmovaps [rsp+0x60], xmm7
00007531fdbd6005  vmovaps [rsp+0x70], xmm8
00007531fdbd600b  vmovaps [rsp+0x80], xmm9
00007531fdbd6014  vmovaps [rsp+0x90], xmm10
00007531fdbd601d  vmovaps [rsp+0xA0], xmm11
00007531fdbd6026  vmovaps [rsp+0xB0], xmm12
00007531fdbd602f  vmovaps [rsp+0xC0], xmm13
00007531fdbd6038  vmovaps [rsp+0xD0], xmm14
00007531fdbd6041  vmovaps [rsp+0xE0], xmm15
00007531fdbd604a  sub rsp, 0x30
00007531fdbd604e  movaps [rsp], xmm1
00007531fdbd6052  movaps [rsp+0x10], xmm15
00007531fdbd6058  movaps [rsp+0x20], xmm10
00007531fdbd605e  lea rdi, [rsp]
00007531fdbd6062  mov esi, 0x00
00007531fdbd6067  mov rax, 0x59ED111DF530
00007531fdbd6071  call rax
00007531fdbd6073  movaps xmm1, [rsp]
00007531fdbd6077  add rsp, 0x30
00007531fdbd607b  vmovaps xmm0, [rsp]
00007531fdbd6080  vmovaps xmm2, [rsp+0x10]
00007531fdbd6086  vmovaps xmm3, [rsp+0x20]
00007531fdbd608c  vmovaps xmm4, [rsp+0x30]
00007531fdbd6092  vmovaps xmm5, [rsp+0x40]
00007531fdbd6098  vmovaps xmm6, [rsp+0x50]
00007531fdbd609e  vmovaps xmm7, [rsp+0x60]
00007531fdbd60a4  vmovaps xmm8, [rsp+0x70]
00007531fdbd60aa  vmovaps xmm9, [rsp+0x80]
00007531fdbd60b3  vmovaps xmm10, [rsp+0x90]
00007531fdbd60bc  vmovaps xmm11, [rsp+0xA0]
00007531fdbd60c5  vmovaps xmm12, [rsp+0xB0]
00007531fdbd60ce  vmovaps xmm13, [rsp+0xC0]
00007531fdbd60d7  vmovaps xmm14, [rsp+0xD0]
00007531fdbd60e0  vmovaps xmm15, [rsp+0xE0]
00007531fdbd60e9  add rsp, 0xF0
00007531fdbd60f0  pop r11
00007531fdbd60f2  pop r10
00007531fdbd60f4  pop r9
00007531fdbd60f6  pop r8
00007531fdbd60f8  pop rsi
00007531fdbd60f9  pop rdi
00007531fdbd60fa  pop rdx
00007531fdbd60fb  pop rcx
00007531fdbd60fc  pop rax
00007531fdbd60fd  add rsp, 0x08
00007531fdbd6101  jmp 0x00007531FDBD305B
00007531fdbd6106  sub rsp, 0x08
00007531fdbd610a  push rax
00007531fdbd610b  push rcx
00007531fdbd610c  push rdx
00007531fdbd610d  push rdi
00007531fdbd610e  push rsi
00007531fdbd610f  push r8
00007531fdbd6111  push r9
00007531fdbd6113  push r10
00007531fdbd6115  push r11
00007531fdbd6117  sub rsp, 0xF0
00007531fdbd611e  vmovaps [rsp], xmm0
00007531fdbd6123  vmovaps [rsp+0x10], xmm1
00007531fdbd6129  vmovaps [rsp+0x20], xmm2
00007531fdbd612f  vmovaps [rsp+0x30], xmm3
00007531fdbd6135  vmovaps [rsp+0x40], xmm4
00007531fdbd613b  vmovaps [rsp+0x50], xmm5
00007531fdbd6141  vmovaps [rsp+0x60], xmm6
00007531fdbd6147  vmovaps [rsp+0x70], xmm7
00007531fdbd614d  vmovaps [rsp+0x80], xmm8
00007531fdbd6156  vmovaps [rsp+0x90], xmm9
00007531fdbd615f  vmovaps [rsp+0xA0], xmm10
00007531fdbd6168  vmovaps [rsp+0xB0], xmm11
00007531fdbd6171  vmovaps [rsp+0xC0], xmm12
00007531fdbd617a  vmovaps [rsp+0xD0], xmm13
00007531fdbd6183  vmovaps [rsp+0xE0], xmm14
00007531fdbd618c  sub rsp, 0x30
00007531fdbd6190  movaps [rsp], xmm15
00007531fdbd6195  movaps [rsp+0x10], xmm10
00007531fdbd619b  movaps [rsp+0x20], xmm11
00007531fdbd61a1  lea rdi, [rsp]
00007531fdbd61a5  mov esi, 0x00
00007531fdbd61aa  mov rax, 0x59ED111DF530
00007531fdbd61b4  call rax
00007531fdbd61b6  movaps xmm15, [rsp]
00007531fdbd61bb  add rsp, 0x30
00007531fdbd61bf  vmovaps xmm0, [rsp]
00007531fdbd61c4  vmovaps xmm1, [rsp+0x10]
00007531fdbd61ca  vmovaps xmm2, [rsp+0x20]
00007531fdbd61d0  vmovaps xmm3, [rsp+0x30]
00007531fdbd61d6  vmovaps xmm4, [rsp+0x40]
00007531fdbd61dc  vmovaps xmm5, [rsp+0x50]
00007531fdbd61e2  vmovaps xmm6, [rsp+0x60]
00007531fdbd61e8  vmovaps xmm7, [rsp+0x70]
00007531fdbd61ee  vmovaps xmm8, [rsp+0x80]
00007531fdbd61f7  vmovaps xmm9, [rsp+0x90]
00007531fdbd6200  vmovaps xmm10, [rsp+0xA0]
00007531fdbd6209  vmovaps xmm11, [rsp+0xB0]
00007531fdbd6212  vmovaps xmm12, [rsp+0xC0]
00007531fdbd621b  vmovaps xmm13, [rsp+0xD0]
00007531fdbd6224  vmovaps xmm14, [rsp+0xE0]
00007531fdbd622d  add rsp, 0xF0
00007531fdbd6234  pop r11
00007531fdbd6236  pop r10
00007531fdbd6238  pop r9
00007531fdbd623a  pop r8
00007531fdbd623c  pop rsi
00007531fdbd623d  pop rdi
00007531fdbd623e  pop rdx
00007531fdbd623f  pop rcx
00007531fdbd6240  pop rax
00007531fdbd6241  add rsp, 0x08
00007531fdbd6245  jmp 0x00007531FDBD307E
00007531fdbd624a  sub rsp, 0x08
00007531fdbd624e  push rax
00007531fdbd624f  push rcx
00007531fdbd6250  push rdx
00007531fdbd6251  push rdi
00007531fdbd6252  push rsi
00007531fdbd6253  push r8
00007531fdbd6255  push r9
00007531fdbd6257  push r10
00007531fdbd6259  push r11
00007531fdbd625b  sub rsp, 0xF0
00007531fdbd6262  vmovaps [rsp], xmm0
00007531fdbd6267  vmovaps [rsp+0x10], xmm1
00007531fdbd626d  vmovaps [rsp+0x20], xmm2
00007531fdbd6273  vmovaps [rsp+0x30], xmm3
00007531fdbd6279  vmovaps [rsp+0x40], xmm4
00007531fdbd627f  vmovaps [rsp+0x50], xmm5
00007531fdbd6285  vmovaps [rsp+0x60], xmm6
00007531fdbd628b  vmovaps [rsp+0x70], xmm7
00007531fdbd6291  vmovaps [rsp+0x80], xmm8
00007531fdbd629a  vmovaps [rsp+0x90], xmm9
00007531fdbd62a3  vmovaps [rsp+0xA0], xmm11
00007531fdbd62ac  vmovaps [rsp+0xB0], xmm12
00007531fdbd62b5  vmovaps [rsp+0xC0], xmm13
00007531fdbd62be  vmovaps [rsp+0xD0], xmm14
00007531fdbd62c7  vmovaps [rsp+0xE0], xmm15
00007531fdbd62d0  sub rsp, 0x30
00007531fdbd62d4  movaps [rsp], xmm10
00007531fdbd62d9  movaps [rsp+0x10], xmm2
00007531fdbd62de  movaps [rsp+0x20], xmm11
00007531fdbd62e4  lea rdi, [rsp]
00007531fdbd62e8  mov esi, 0x00
00007531fdbd62ed  mov rax, 0x59ED111DF530
00007531fdbd62f7  call rax
00007531fdbd62f9  movaps xmm10, [rsp]
00007531fdbd62fe  add rsp, 0x30
00007531fdbd6302  vmovaps xmm0, [rsp]
00007531fdbd6307  vmovaps xmm1, [rsp+0x10]
00007531fdbd630d  vmovaps xmm2, [rsp+0x20]
00007531fdbd6313  vmovaps xmm3, [rsp+0x30]
00007531fdbd6319  vmovaps xmm4, [rsp+0x40]
00007531fdbd631f  vmovaps xmm5, [rsp+0x50]
00007531fdbd6325  vmovaps xmm6, [rsp+0x60]
00007531fdbd632b  vmovaps xmm7, [rsp+0x70]
00007531fdbd6331  vmovaps xmm8, [rsp+0x80]
00007531fdbd633a  vmovaps xmm9, [rsp+0x90]
00007531fdbd6343  vmovaps xmm11, [rsp+0xA0]
00007531fdbd634c  vmovaps xmm12, [rsp+0xB0]
00007531fdbd6355  vmovaps xmm13, [rsp+0xC0]
00007531fdbd635e  vmovaps xmm14, [rsp+0xD0]
00007531fdbd6367  vmovaps xmm15, [rsp+0xE0]
00007531fdbd6370  add rsp, 0xF0
00007531fdbd6377  pop r11
00007531fdbd6379  pop r10
00007531fdbd637b  pop r9
00007531fdbd637d  pop r8
00007531fdbd637f  pop rsi
00007531fdbd6380  pop rdi
00007531fdbd6381  pop rdx
00007531fdbd6382  pop rcx
00007531fdbd6383  pop rax
00007531fdbd6384  add rsp, 0x08
00007531fdbd6388  jmp 0x00007531FDBD30B6
00007531fdbd638d  sub rsp, 0x08
00007531fdbd6391  push rax
00007531fdbd6392  push rcx
00007531fdbd6393  push rdx
00007531fdbd6394  push rdi
00007531fdbd6395  push rsi
00007531fdbd6396  push r8
00007531fdbd6398  push r9
00007531fdbd639a  push r10
00007531fdbd639c  push r11
00007531fdbd639e  sub rsp, 0xF0
00007531fdbd63a5  vmovaps [rsp], xmm0
00007531fdbd63aa  vmovaps [rsp+0x10], xmm1
00007531fdbd63b0  vmovaps [rsp+0x20], xmm2
00007531fdbd63b6  vmovaps [rsp+0x30], xmm3
00007531fdbd63bc  vmovaps [rsp+0x40], xmm4
00007531fdbd63c2  vmovaps [rsp+0x50], xmm5
00007531fdbd63c8  vmovaps [rsp+0x60], xmm6
00007531fdbd63ce  vmovaps [rsp+0x70], xmm7
00007531fdbd63d4  vmovaps [rsp+0x80], xmm8
00007531fdbd63dd  vmovaps [rsp+0x90], xmm9
00007531fdbd63e6  vmovaps [rsp+0xA0], xmm10
00007531fdbd63ef  vmovaps [rsp+0xB0], xmm12
00007531fdbd63f8  vmovaps [rsp+0xC0], xmm13
00007531fdbd6401  vmovaps [rsp+0xD0], xmm14
00007531fdbd640a  vmovaps [rsp+0xE0], xmm15
00007531fdbd6413  sub rsp, 0x30
00007531fdbd6417  movaps [rsp], xmm11
00007531fdbd641c  movaps [rsp+0x10], xmm2
00007531fdbd6421  movaps [rsp+0x20], xmm1
00007531fdbd6426  lea rdi, [rsp]
00007531fdbd642a  mov esi, 0x00
00007531fdbd642f  mov rax, 0x59ED111DF530
00007531fdbd6439  call rax
00007531fdbd643b  movaps xmm11, [rsp]
00007531fdbd6440  add rsp, 0x30
00007531fdbd6444  vmovaps xmm0, [rsp]
00007531fdbd6449  vmovaps xmm1, [rsp+0x10]
00007531fdbd644f  vmovaps xmm2, [rsp+0x20]
00007531fdbd6455  vmovaps xmm3, [rsp+0x30]
00007531fdbd645b  vmovaps xmm4, [rsp+0x40]
00007531fdbd6461  vmovaps xmm5, [rsp+0x50]
00007531fdbd6467  vmovaps xmm6, [rsp+0x60]
00007531fdbd646d  vmovaps xmm7, [rsp+0x70]
00007531fdbd6473  vmovaps xmm8, [rsp+0x80]
00007531fdbd647c  vmovaps xmm9, [rsp+0x90]
00007531fdbd6485  vmovaps xmm10, [rsp+0xA0]
00007531fdbd648e  vmovaps xmm12, [rsp+0xB0]
00007531fdbd6497  vmovaps xmm13, [rsp+0xC0]
00007531fdbd64a0  vmovaps xmm14, [rsp+0xD0]
00007531fdbd64a9  vmovaps xmm15, [rsp+0xE0]
00007531fdbd64b2  add rsp, 0xF0
00007531fdbd64b9  pop r11
00007531fdbd64bb  pop r10
00007531fdbd64bd  pop r9
00007531fdbd64bf  pop r8
00007531fdbd64c1  pop rsi
00007531fdbd64c2  pop rdi
00007531fdbd64c3  pop rdx
00007531fdbd64c4  pop rcx
00007531fdbd64c5  pop rax
00007531fdbd64c6  add rsp, 0x08
00007531fdbd64ca  jmp 0x00007531FDBD30F2
00007531fdbd64cf  sub rsp, 0x08
00007531fdbd64d3  push rax
00007531fdbd64d4  push rcx
00007531fdbd64d5  push rdx
00007531fdbd64d6  push rdi
00007531fdbd64d7  push rsi
00007531fdbd64d8  push r8
00007531fdbd64da  push r9
00007531fdbd64dc  push r10
00007531fdbd64de  push r11
00007531fdbd64e0  sub rsp, 0xF0
00007531fdbd64e7  vmovaps [rsp], xmm0
00007531fdbd64ec  vmovaps [rsp+0x10], xmm2
00007531fdbd64f2  vmovaps [rsp+0x20], xmm3
00007531fdbd64f8  vmovaps [rsp+0x30], xmm4
00007531fdbd64fe  vmovaps [rsp+0x40], xmm5
00007531fdbd6504  vmovaps [rsp+0x50], xmm6
00007531fdbd650a  vmovaps [rsp+0x60], xmm7
00007531fdbd6510  vmovaps [rsp+0x70], xmm8
00007531fdbd6516  vmovaps [rsp+0x80], xmm9
00007531fdbd651f  vmovaps [rsp+0x90], xmm10
00007531fdbd6528  vmovaps [rsp+0xA0], xmm11
00007531fdbd6531  vmovaps [rsp+0xB0], xmm12
00007531fdbd653a  vmovaps [rsp+0xC0], xmm13
00007531fdbd6543  vmovaps [rsp+0xD0], xmm14
00007531fdbd654c  vmovaps [rsp+0xE0], xmm15
00007531fdbd6555  sub rsp, 0x30
00007531fdbd6559  movaps [rsp], xmm1
00007531fdbd655d  movaps [rsp+0x10], xmm14
00007531fdbd6563  movaps [rsp+0x20], xmm6
00007531fdbd6568  lea rdi, [rsp]
00007531fdbd656c  mov esi, 0x00
00007531fdbd6571  mov rax, 0x59ED111DF530
00007531fdbd657b  call rax
00007531fdbd657d  movaps xmm1, [rsp]
00007531fdbd6581  add rsp, 0x30
00007531fdbd6585  vmovaps xmm0, [rsp]
00007531fdbd658a  vmovaps xmm2, [rsp+0x10]
00007531fdbd6590  vmovaps xmm3, [rsp+0x20]
00007531fdbd6596  vmovaps xmm4, [rsp+0x30]
00007531fdbd659c  vmovaps xmm5, [rsp+0x40]
00007531fdbd65a2  vmovaps xmm6, [rsp+0x50]
00007531fdbd65a8  vmovaps xmm7, [rsp+0x60]
00007531fdbd65ae  vmovaps xmm8, [rsp+0x70]
00007531fdbd65b4  vmovaps xmm9, [rsp+0x80]
00007531fdbd65bd  vmovaps xmm10, [rsp+0x90]
00007531fdbd65c6  vmovaps xmm11, [rsp+0xA0]
00007531fdbd65cf  vmovaps xmm12, [rsp+0xB0]
00007531fdbd65d8  vmovaps xmm13, [rsp+0xC0]
00007531fdbd65e1  vmovaps xmm14, [rsp+0xD0]
00007531fdbd65ea  vmovaps xmm15, [rsp+0xE0]
00007531fdbd65f3  add rsp, 0xF0
00007531fdbd65fa  pop r11
00007531fdbd65fc  pop r10
00007531fdbd65fe  pop r9
00007531fdbd6600  pop r8
00007531fdbd6602  pop rsi
00007531fdbd6603  pop rdi
00007531fdbd6604  pop rdx
00007531fdbd6605  pop rcx
00007531fdbd6606  pop rax
00007531fdbd6607  add rsp, 0x08
00007531fdbd660b  jmp 0x00007531FDBD310B
00007531fdbd6610  sub rsp, 0x08
00007531fdbd6614  push rax
00007531fdbd6615  push rcx
00007531fdbd6616  push rdx
00007531fdbd6617  push rdi
00007531fdbd6618  push rsi
00007531fdbd6619  push r8
00007531fdbd661b  push r9
00007531fdbd661d  push r10
00007531fdbd661f  push r11
00007531fdbd6621  sub rsp, 0xF0
00007531fdbd6628  vmovaps [rsp], xmm0
00007531fdbd662d  vmovaps [rsp+0x10], xmm1
00007531fdbd6633  vmovaps [rsp+0x20], xmm2
00007531fdbd6639  vmovaps [rsp+0x30], xmm3
00007531fdbd663f  vmovaps [rsp+0x40], xmm4
00007531fdbd6645  vmovaps [rsp+0x50], xmm5
00007531fdbd664b  vmovaps [rsp+0x60], xmm6
00007531fdbd6651  vmovaps [rsp+0x70], xmm7
00007531fdbd6657  vmovaps [rsp+0x80], xmm8
00007531fdbd6660  vmovaps [rsp+0x90], xmm9
00007531fdbd6669  vmovaps [rsp+0xA0], xmm10
00007531fdbd6672  vmovaps [rsp+0xB0], xmm11
00007531fdbd667b  vmovaps [rsp+0xC0], xmm12
00007531fdbd6684  vmovaps [rsp+0xD0], xmm13
00007531fdbd668d  vmovaps [rsp+0xE0], xmm14
00007531fdbd6696  sub rsp, 0x30
00007531fdbd669a  movaps [rsp], xmm15
00007531fdbd669f  movaps [rsp+0x10], xmm14
00007531fdbd66a5  movaps [rsp+0x20], xmm5
00007531fdbd66aa  lea rdi, [rsp]
00007531fdbd66ae  mov esi, 0x00
00007531fdbd66b3  mov rax, 0x59ED111DF530
00007531fdbd66bd  call rax
00007531fdbd66bf  movaps xmm15, [rsp]
00007531fdbd66c4  add rsp, 0x30
00007531fdbd66c8  vmovaps xmm0, [rsp]
00007531fdbd66cd  vmovaps xmm1, [rsp+0x10]
00007531fdbd66d3  vmovaps xmm2, [rsp+0x20]
00007531fdbd66d9  vmovaps xmm3, [rsp+0x30]
00007531fdbd66df  vmovaps xmm4, [rsp+0x40]
00007531fdbd66e5  vmovaps xmm5, [rsp+0x50]
00007531fdbd66eb  vmovaps xmm6, [rsp+0x60]
00007531fdbd66f1  vmovaps xmm7, [rsp+0x70]
00007531fdbd66f7  vmovaps xmm8, [rsp+0x80]
00007531fdbd6700  vmovaps xmm9, [rsp+0x90]
00007531fdbd6709  vmovaps xmm10, [rsp+0xA0]
00007531fdbd6712  vmovaps xmm11, [rsp+0xB0]
00007531fdbd671b  vmovaps xmm12, [rsp+0xC0]
00007531fdbd6724  vmovaps xmm13, [rsp+0xD0]
00007531fdbd672d  vmovaps xmm14, [rsp+0xE0]
00007531fdbd6736  add rsp, 0xF0
00007531fdbd673d  pop r11
00007531fdbd673f  pop r10
00007531fdbd6741  pop r9
00007531fdbd6743  pop r8
00007531fdbd6745  pop rsi
00007531fdbd6746  pop rdi
00007531fdbd6747  pop rdx
00007531fdbd6748  pop rcx
00007531fdbd6749  pop rax
00007531fdbd674a  add rsp, 0x08
00007531fdbd674e  jmp 0x00007531FDBD312B
00007531fdbd6753  sub rsp, 0x08
00007531fdbd6757  push rax
00007531fdbd6758  push rcx
00007531fdbd6759  push rdx
00007531fdbd675a  push rdi
00007531fdbd675b  push rsi
00007531fdbd675c  push r8
00007531fdbd675e  push r9
00007531fdbd6760  push r10
00007531fdbd6762  push r11
00007531fdbd6764  sub rsp, 0xF0
00007531fdbd676b  vmovaps [rsp], xmm0
00007531fdbd6770  vmovaps [rsp+0x10], xmm1
00007531fdbd6776  vmovaps [rsp+0x20], xmm2
00007531fdbd677c  vmovaps [rsp+0x30], xmm3
00007531fdbd6782  vmovaps [rsp+0x40], xmm4
00007531fdbd6788  vmovaps [rsp+0x50], xmm5
00007531fdbd678e  vmovaps [rsp+0x60], xmm7
00007531fdbd6794  vmovaps [rsp+0x70], xmm8
00007531fdbd679a  vmovaps [rsp+0x80], xmm9
00007531fdbd67a3  vmovaps [rsp+0x90], xmm10
00007531fdbd67ac  vmovaps [rsp+0xA0], xmm11
00007531fdbd67b5  vmovaps [rsp+0xB0], xmm12
00007531fdbd67be  vmovaps [rsp+0xC0], xmm13
00007531fdbd67c7  vmovaps [rsp+0xD0], xmm14
00007531fdbd67d0  vmovaps [rsp+0xE0], xmm15
00007531fdbd67d9  sub rsp, 0x30
00007531fdbd67dd  movaps [rsp], xmm6
00007531fdbd67e1  movaps [rsp+0x10], xmm9
00007531fdbd67e7  movaps [rsp+0x20], xmm14
00007531fdbd67ed  lea rdi, [rsp]
00007531fdbd67f1  mov esi, 0x00
00007531fdbd67f6  mov rax, 0x59ED111DF530
00007531fdbd6800  call rax
00007531fdbd6802  movaps xmm6, [rsp]
00007531fdbd6806  add rsp, 0x30
00007531fdbd680a  vmovaps xmm0, [rsp]
00007531fdbd680f  vmovaps xmm1, [rsp+0x10]
00007531fdbd6815  vmovaps xmm2, [rsp+0x20]
00007531fdbd681b  vmovaps xmm3, [rsp+0x30]
00007531fdbd6821  vmovaps xmm4, [rsp+0x40]
00007531fdbd6827  vmovaps xmm5, [rsp+0x50]
00007531fdbd682d  vmovaps xmm7, [rsp+0x60]
00007531fdbd6833  vmovaps xmm8, [rsp+0x70]
00007531fdbd6839  vmovaps xmm9, [rsp+0x80]
00007531fdbd6842  vmovaps xmm10, [rsp+0x90]
00007531fdbd684b  vmovaps xmm11, [rsp+0xA0]
00007531fdbd6854  vmovaps xmm12, [rsp+0xB0]
00007531fdbd685d  vmovaps xmm13, [rsp+0xC0]
00007531fdbd6866  vmovaps xmm14, [rsp+0xD0]
00007531fdbd686f  vmovaps xmm15, [rsp+0xE0]
00007531fdbd6878  add rsp, 0xF0
00007531fdbd687f  pop r11
00007531fdbd6881  pop r10
00007531fdbd6883  pop r9
00007531fdbd6885  pop r8
00007531fdbd6887  pop rsi
00007531fdbd6888  pop rdi
00007531fdbd6889  pop rdx
00007531fdbd688a  pop rcx
00007531fdbd688b  pop rax
00007531fdbd688c  add rsp, 0x08
00007531fdbd6890  jmp 0x00007531FDBD3153
00007531fdbd6895  sub rsp, 0x08
00007531fdbd6899  push rax
00007531fdbd689a  push rcx
00007531fdbd689b  push rdx
00007531fdbd689c  push rdi
00007531fdbd689d  push rsi
00007531fdbd689e  push r8
00007531fdbd68a0  push r9
00007531fdbd68a2  push r10
00007531fdbd68a4  push r11
00007531fdbd68a6  sub rsp, 0xF0
00007531fdbd68ad  vmovaps [rsp], xmm0
00007531fdbd68b2  vmovaps [rsp+0x10], xmm1
00007531fdbd68b8  vmovaps [rsp+0x20], xmm2
00007531fdbd68be  vmovaps [rsp+0x30], xmm3
00007531fdbd68c4  vmovaps [rsp+0x40], xmm4
00007531fdbd68ca  vmovaps [rsp+0x50], xmm5
00007531fdbd68d0  vmovaps [rsp+0x60], xmm6
00007531fdbd68d6  vmovaps [rsp+0x70], xmm7
00007531fdbd68dc  vmovaps [rsp+0x80], xmm8
00007531fdbd68e5  vmovaps [rsp+0x90], xmm9
00007531fdbd68ee  vmovaps [rsp+0xA0], xmm10
00007531fdbd68f7  vmovaps [rsp+0xB0], xmm11
00007531fdbd6900  vmovaps [rsp+0xC0], xmm12
00007531fdbd6909  vmovaps [rsp+0xD0], xmm13
00007531fdbd6912  vmovaps [rsp+0xE0], xmm15
00007531fdbd691b  sub rsp, 0x30
00007531fdbd691f  movaps [rsp], xmm14
00007531fdbd6924  movaps [rsp+0x10], xmm9
00007531fdbd692a  movaps [rsp+0x20], xmm13
00007531fdbd6930  lea rdi, [rsp]
00007531fdbd6934  mov esi, 0x00
00007531fdbd6939  mov rax, 0x59ED111DF530
00007531fdbd6943  call rax
00007531fdbd6945  movaps xmm14, [rsp]
00007531fdbd694a  add rsp, 0x30
00007531fdbd694e  vmovaps xmm0, [rsp]
00007531fdbd6953  vmovaps xmm1, [rsp+0x10]
00007531fdbd6959  vmovaps xmm2, [rsp+0x20]
00007531fdbd695f  vmovaps xmm3, [rsp+0x30]
00007531fdbd6965  vmovaps xmm4, [rsp+0x40]
00007531fdbd696b  vmovaps xmm5, [rsp+0x50]
00007531fdbd6971  vmovaps xmm6, [rsp+0x60]
00007531fdbd6977  vmovaps xmm7, [rsp+0x70]
00007531fdbd697d  vmovaps xmm8, [rsp+0x80]
00007531fdbd6986  vmovaps xmm9, [rsp+0x90]
00007531fdbd698f  vmovaps xmm10, [rsp+0xA0]
00007531fdbd6998  vmovaps xmm11, [rsp+0xB0]
00007531fdbd69a1  vmovaps xmm12, [rsp+0xC0]
00007531fdbd69aa  vmovaps xmm13, [rsp+0xD0]
00007531fdbd69b3  vmovaps xmm15, [rsp+0xE0]
00007531fdbd69bc  add rsp, 0xF0
00007531fdbd69c3  pop r11
00007531fdbd69c5  pop r10
00007531fdbd69c7  pop r9
00007531fdbd69c9  pop r8
00007531fdbd69cb  pop rsi
00007531fdbd69cc  pop rdi
00007531fdbd69cd  pop rdx
00007531fdbd69ce  pop rcx
00007531fdbd69cf  pop rax
00007531fdbd69d0  add rsp, 0x08
00007531fdbd69d4  jmp 0x00007531FDBD3176
00007531fdbd69d9  sub rsp, 0x08
00007531fdbd69dd  push rax
00007531fdbd69de  push rcx
00007531fdbd69df  push rdx
00007531fdbd69e0  push rdi
00007531fdbd69e1  push rsi
00007531fdbd69e2  push r8
00007531fdbd69e4  push r9
00007531fdbd69e6  push r10
00007531fdbd69e8  push r11
00007531fdbd69ea  sub rsp, 0xF0
00007531fdbd69f1  vmovaps [rsp], xmm0
00007531fdbd69f6  vmovaps [rsp+0x10], xmm1
00007531fdbd69fc  vmovaps [rsp+0x20], xmm2
00007531fdbd6a02  vmovaps [rsp+0x30], xmm3
00007531fdbd6a08  vmovaps [rsp+0x40], xmm4
00007531fdbd6a0e  vmovaps [rsp+0x50], xmm5
00007531fdbd6a14  vmovaps [rsp+0x60], xmm6
00007531fdbd6a1a  vmovaps [rsp+0x70], xmm7
00007531fdbd6a20  vmovaps [rsp+0x80], xmm8
00007531fdbd6a29  vmovaps [rsp+0x90], xmm9
00007531fdbd6a32  vmovaps [rsp+0xA0], xmm10
00007531fdbd6a3b  vmovaps [rsp+0xB0], xmm11
00007531fdbd6a44  vmovaps [rsp+0xC0], xmm12
00007531fdbd6a4d  vmovaps [rsp+0xD0], xmm14
00007531fdbd6a56  vmovaps [rsp+0xE0], xmm15
00007531fdbd6a5f  sub rsp, 0x30
00007531fdbd6a63  movaps [rsp], xmm13
00007531fdbd6a68  movaps [rsp+0x10], xmm9
00007531fdbd6a6e  movaps [rsp+0x20], xmm10
00007531fdbd6a74  lea rdi, [rsp]
00007531fdbd6a78  mov esi, 0x00
00007531fdbd6a7d  mov rax, 0x59ED111DF530
00007531fdbd6a87  call rax
00007531fdbd6a89  movaps xmm13, [rsp]
00007531fdbd6a8e  add rsp, 0x30
00007531fdbd6a92  vmovaps xmm0, [rsp]
00007531fdbd6a97  vmovaps xmm1, [rsp+0x10]
00007531fdbd6a9d  vmovaps xmm2, [rsp+0x20]
00007531fdbd6aa3  vmovaps xmm3, [rsp+0x30]
00007531fdbd6aa9  vmovaps xmm4, [rsp+0x40]
00007531fdbd6aaf  vmovaps xmm5, [rsp+0x50]
00007531fdbd6ab5  vmovaps xmm6, [rsp+0x60]
00007531fdbd6abb  vmovaps xmm7, [rsp+0x70]
00007531fdbd6ac1  vmovaps xmm8, [rsp+0x80]
00007531fdbd6aca  vmovaps xmm9, [rsp+0x90]
00007531fdbd6ad3  vmovaps xmm10, [rsp+0xA0]
00007531fdbd6adc  vmovaps xmm11, [rsp+0xB0]
00007531fdbd6ae5  vmovaps xmm12, [rsp+0xC0]
00007531fdbd6aee  vmovaps xmm14, [rsp+0xD0]
00007531fdbd6af7  vmovaps xmm15, [rsp+0xE0]
00007531fdbd6b00  add rsp, 0xF0
00007531fdbd6b07  pop r11
00007531fdbd6b09  pop r10
00007531fdbd6b0b  pop r9
00007531fdbd6b0d  pop r8
00007531fdbd6b0f  pop rsi
00007531fdbd6b10  pop rdi
00007531fdbd6b11  pop rdx
00007531fdbd6b12  pop rcx
00007531fdbd6b13  pop rax
00007531fdbd6b14  add rsp, 0x08
00007531fdbd6b18  jmp 0x00007531FDBD3196
00007531fdbd6b1d  call 0x00007531FDA0AFE0
00007531fdbd6b22  jmp 0x00007531FDBD31EB
00007531fdbd6b27  sub rsp, 0x08
00007531fdbd6b2b  push rax
00007531fdbd6b2c  push rcx
00007531fdbd6b2d  push rdx
00007531fdbd6b2e  push rdi
00007531fdbd6b2f  push rsi
00007531fdbd6b30  push r8
00007531fdbd6b32  push r9
00007531fdbd6b34  push r10
00007531fdbd6b36  push r11
00007531fdbd6b38  sub rsp, 0xF0
00007531fdbd6b3f  vmovaps [rsp], xmm0
00007531fdbd6b44  vmovaps [rsp+0x10], xmm1
00007531fdbd6b4a  vmovaps [rsp+0x20], xmm2
00007531fdbd6b50  vmovaps [rsp+0x30], xmm3
00007531fdbd6b56  vmovaps [rsp+0x40], xmm4
00007531fdbd6b5c  vmovaps [rsp+0x50], xmm5
00007531fdbd6b62  vmovaps [rsp+0x60], xmm6
00007531fdbd6b68  vmovaps [rsp+0x70], xmm7
00007531fdbd6b6e  vmovaps [rsp+0x80], xmm8
00007531fdbd6b77  vmovaps [rsp+0x90], xmm10
00007531fdbd6b80  vmovaps [rsp+0xA0], xmm11
00007531fdbd6b89  vmovaps [rsp+0xB0], xmm12
00007531fdbd6b92  vmovaps [rsp+0xC0], xmm13
00007531fdbd6b9b  vmovaps [rsp+0xD0], xmm14
00007531fdbd6ba4  vmovaps [rsp+0xE0], xmm15
00007531fdbd6bad  sub rsp, 0x30
00007531fdbd6bb1  movaps [rsp], xmm9
00007531fdbd6bb6  movaps [rsp+0x10], xmm8
00007531fdbd6bbc  movaps [rsp+0x20], xmm10
00007531fdbd6bc2  lea rdi, [rsp]
00007531fdbd6bc6  mov esi, 0x00
00007531fdbd6bcb  mov rax, 0x59ED111DF530
00007531fdbd6bd5  call rax
00007531fdbd6bd7  movaps xmm9, [rsp]
00007531fdbd6bdc  add rsp, 0x30
00007531fdbd6be0  vmovaps xmm0, [rsp]
00007531fdbd6be5  vmovaps xmm1, [rsp+0x10]
00007531fdbd6beb  vmovaps xmm2, [rsp+0x20]
00007531fdbd6bf1  vmovaps xmm3, [rsp+0x30]
00007531fdbd6bf7  vmovaps xmm4, [rsp+0x40]
00007531fdbd6bfd  vmovaps xmm5, [rsp+0x50]
00007531fdbd6c03  vmovaps xmm6, [rsp+0x60]
00007531fdbd6c09  vmovaps xmm7, [rsp+0x70]
00007531fdbd6c0f  vmovaps xmm8, [rsp+0x80]
00007531fdbd6c18  vmovaps xmm10, [rsp+0x90]
00007531fdbd6c21  vmovaps xmm11, [rsp+0xA0]
00007531fdbd6c2a  vmovaps xmm12, [rsp+0xB0]
00007531fdbd6c33  vmovaps xmm13, [rsp+0xC0]
00007531fdbd6c3c  vmovaps xmm14, [rsp+0xD0]
00007531fdbd6c45  vmovaps xmm15, [rsp+0xE0]
00007531fdbd6c4e  add rsp, 0xF0
00007531fdbd6c55  pop r11
00007531fdbd6c57  pop r10
00007531fdbd6c59  pop r9
00007531fdbd6c5b  pop r8
00007531fdbd6c5d  pop rsi
00007531fdbd6c5e  pop rdi
00007531fdbd6c5f  pop rdx
00007531fdbd6c60  pop rcx
00007531fdbd6c61  pop rax
00007531fdbd6c62  add rsp, 0x08
00007531fdbd6c66  jmp 0x00007531FDBD321C
00007531fdbd6c6b  sub rsp, 0x08
00007531fdbd6c6f  push rax
00007531fdbd6c70  push rcx
00007531fdbd6c71  push rdx
00007531fdbd6c72  push rdi
00007531fdbd6c73  push rsi
00007531fdbd6c74  push r8
00007531fdbd6c76  push r9
00007531fdbd6c78  push r10
00007531fdbd6c7a  push r11
00007531fdbd6c7c  sub rsp, 0xF0
00007531fdbd6c83  vmovaps [rsp], xmm0
00007531fdbd6c88  vmovaps [rsp+0x10], xmm1
00007531fdbd6c8e  vmovaps [rsp+0x20], xmm2
00007531fdbd6c94  vmovaps [rsp+0x30], xmm3
00007531fdbd6c9a  vmovaps [rsp+0x40], xmm4
00007531fdbd6ca0  vmovaps [rsp+0x50], xmm5
00007531fdbd6ca6  vmovaps [rsp+0x60], xmm6
00007531fdbd6cac  vmovaps [rsp+0x70], xmm7
00007531fdbd6cb2  vmovaps [rsp+0x80], xmm8
00007531fdbd6cbb  vmovaps [rsp+0x90], xmm9
00007531fdbd6cc4  vmovaps [rsp+0xA0], xmm11
00007531fdbd6ccd  vmovaps [rsp+0xB0], xmm12
00007531fdbd6cd6  vmovaps [rsp+0xC0], xmm13
00007531fdbd6cdf  vmovaps [rsp+0xD0], xmm14
00007531fdbd6ce8  vmovaps [rsp+0xE0], xmm15
00007531fdbd6cf1  sub rsp, 0x30
00007531fdbd6cf5  movaps [rsp], xmm10
00007531fdbd6cfa  movaps [rsp+0x10], xmm1
00007531fdbd6cff  movaps [rsp+0x20], xmm11
00007531fdbd6d05  lea rdi, [rsp]
00007531fdbd6d09  mov esi, 0x00
00007531fdbd6d0e  mov rax, 0x59ED111DF530
00007531fdbd6d18  call rax
00007531fdbd6d1a  movaps xmm10, [rsp]
00007531fdbd6d1f  add rsp, 0x30
00007531fdbd6d23  vmovaps xmm0, [rsp]
00007531fdbd6d28  vmovaps xmm1, [rsp+0x10]
00007531fdbd6d2e  vmovaps xmm2, [rsp+0x20]
00007531fdbd6d34  vmovaps xmm3, [rsp+0x30]
00007531fdbd6d3a  vmovaps xmm4, [rsp+0x40]
00007531fdbd6d40  vmovaps xmm5, [rsp+0x50]
00007531fdbd6d46  vmovaps xmm6, [rsp+0x60]
00007531fdbd6d4c  vmovaps xmm7, [rsp+0x70]
00007531fdbd6d52  vmovaps xmm8, [rsp+0x80]
00007531fdbd6d5b  vmovaps xmm9, [rsp+0x90]
00007531fdbd6d64  vmovaps xmm11, [rsp+0xA0]
00007531fdbd6d6d  vmovaps xmm12, [rsp+0xB0]
00007531fdbd6d76  vmovaps xmm13, [rsp+0xC0]
00007531fdbd6d7f  vmovaps xmm14, [rsp+0xD0]
00007531fdbd6d88  vmovaps xmm15, [rsp+0xE0]
00007531fdbd6d91  add rsp, 0xF0
00007531fdbd6d98  pop r11
00007531fdbd6d9a  pop r10
00007531fdbd6d9c  pop r9
00007531fdbd6d9e  pop r8
00007531fdbd6da0  pop rsi
00007531fdbd6da1  pop rdi
00007531fdbd6da2  pop rdx
00007531fdbd6da3  pop rcx
00007531fdbd6da4  pop rax
00007531fdbd6da5  add rsp, 0x08
00007531fdbd6da9  jmp 0x00007531FDBD3237
00007531fdbd6dae  sub rsp, 0x08
00007531fdbd6db2  push rax
00007531fdbd6db3  push rcx
00007531fdbd6db4  push rdx
00007531fdbd6db5  push rdi
00007531fdbd6db6  push rsi
00007531fdbd6db7  push r8
00007531fdbd6db9  push r9
00007531fdbd6dbb  push r10
00007531fdbd6dbd  push r11
00007531fdbd6dbf  sub rsp, 0xF0
00007531fdbd6dc6  vmovaps [rsp], xmm0
00007531fdbd6dcb  vmovaps [rsp+0x10], xmm2
00007531fdbd6dd1  vmovaps [rsp+0x20], xmm3
00007531fdbd6dd7  vmovaps [rsp+0x30], xmm4
00007531fdbd6ddd  vmovaps [rsp+0x40], xmm5
00007531fdbd6de3  vmovaps [rsp+0x50], xmm6
00007531fdbd6de9  vmovaps [rsp+0x60], xmm7
00007531fdbd6def  vmovaps [rsp+0x70], xmm8
00007531fdbd6df5  vmovaps [rsp+0x80], xmm9
00007531fdbd6dfe  vmovaps [rsp+0x90], xmm10
00007531fdbd6e07  vmovaps [rsp+0xA0], xmm11
00007531fdbd6e10  vmovaps [rsp+0xB0], xmm12
00007531fdbd6e19  vmovaps [rsp+0xC0], xmm13
00007531fdbd6e22  vmovaps [rsp+0xD0], xmm14
00007531fdbd6e2b  vmovaps [rsp+0xE0], xmm15
00007531fdbd6e34  sub rsp, 0x30
00007531fdbd6e38  movaps [rsp], xmm1
00007531fdbd6e3c  movaps [rsp+0x10], xmm15
00007531fdbd6e42  movaps [rsp+0x20], xmm6
00007531fdbd6e47  lea rdi, [rsp]
00007531fdbd6e4b  mov esi, 0x00
00007531fdbd6e50  mov rax, 0x59ED111DF530
00007531fdbd6e5a  call rax
00007531fdbd6e5c  movaps xmm1, [rsp]
00007531fdbd6e60  add rsp, 0x30
00007531fdbd6e64  vmovaps xmm0, [rsp]
00007531fdbd6e69  vmovaps xmm2, [rsp+0x10]
00007531fdbd6e6f  vmovaps xmm3, [rsp+0x20]
00007531fdbd6e75  vmovaps xmm4, [rsp+0x30]
00007531fdbd6e7b  vmovaps xmm5, [rsp+0x40]
00007531fdbd6e81  vmovaps xmm6, [rsp+0x50]
00007531fdbd6e87  vmovaps xmm7, [rsp+0x60]
00007531fdbd6e8d  vmovaps xmm8, [rsp+0x70]
00007531fdbd6e93  vmovaps xmm9, [rsp+0x80]
00007531fdbd6e9c  vmovaps xmm10, [rsp+0x90]
00007531fdbd6ea5  vmovaps xmm11, [rsp+0xA0]
00007531fdbd6eae  vmovaps xmm12, [rsp+0xB0]
00007531fdbd6eb7  vmovaps xmm13, [rsp+0xC0]
00007531fdbd6ec0  vmovaps xmm14, [rsp+0xD0]
00007531fdbd6ec9  vmovaps xmm15, [rsp+0xE0]
00007531fdbd6ed2  add rsp, 0xF0
00007531fdbd6ed9  pop r11
00007531fdbd6edb  pop r10
00007531fdbd6edd  pop r9
00007531fdbd6edf  pop r8
00007531fdbd6ee1  pop rsi
00007531fdbd6ee2  pop rdi
00007531fdbd6ee3  pop rdx
00007531fdbd6ee4  pop rcx
00007531fdbd6ee5  pop rax
00007531fdbd6ee6  add rsp, 0x08
00007531fdbd6eea  jmp 0x00007531FDBD3250
00007531fdbd6eef  sub rsp, 0x08
00007531fdbd6ef3  push rax
00007531fdbd6ef4  push rcx
00007531fdbd6ef5  push rdx
00007531fdbd6ef6  push rdi
00007531fdbd6ef7  push rsi
00007531fdbd6ef8  push r8
00007531fdbd6efa  push r9
00007531fdbd6efc  push r10
00007531fdbd6efe  push r11
00007531fdbd6f00  sub rsp, 0xF0
00007531fdbd6f07  vmovaps [rsp], xmm0
00007531fdbd6f0c  vmovaps [rsp+0x10], xmm1
00007531fdbd6f12  vmovaps [rsp+0x20], xmm2
00007531fdbd6f18  vmovaps [rsp+0x30], xmm3
00007531fdbd6f1e  vmovaps [rsp+0x40], xmm4
00007531fdbd6f24  vmovaps [rsp+0x50], xmm5
00007531fdbd6f2a  vmovaps [rsp+0x60], xmm6
00007531fdbd6f30  vmovaps [rsp+0x70], xmm7
00007531fdbd6f36  vmovaps [rsp+0x80], xmm8
00007531fdbd6f3f  vmovaps [rsp+0x90], xmm9
00007531fdbd6f48  vmovaps [rsp+0xA0], xmm10
00007531fdbd6f51  vmovaps [rsp+0xB0], xmm12
00007531fdbd6f5a  vmovaps [rsp+0xC0], xmm13
00007531fdbd6f63  vmovaps [rsp+0xD0], xmm14
00007531fdbd6f6c  vmovaps [rsp+0xE0], xmm15
00007531fdbd6f75  sub rsp, 0x30
00007531fdbd6f79  movaps [rsp], xmm11
00007531fdbd6f7e  movaps [rsp+0x10], xmm12
00007531fdbd6f84  movaps [rsp+0x20], xmm15
00007531fdbd6f8a  lea rdi, [rsp]
00007531fdbd6f8e  mov esi, 0x00
00007531fdbd6f93  mov rax, 0x59ED111DF530
00007531fdbd6f9d  call rax
00007531fdbd6f9f  movaps xmm11, [rsp]
00007531fdbd6fa4  add rsp, 0x30
00007531fdbd6fa8  vmovaps xmm0, [rsp]
00007531fdbd6fad  vmovaps xmm1, [rsp+0x10]
00007531fdbd6fb3  vmovaps xmm2, [rsp+0x20]
00007531fdbd6fb9  vmovaps xmm3, [rsp+0x30]
00007531fdbd6fbf  vmovaps xmm4, [rsp+0x40]
00007531fdbd6fc5  vmovaps xmm5, [rsp+0x50]
00007531fdbd6fcb  vmovaps xmm6, [rsp+0x60]
00007531fdbd6fd1  vmovaps xmm7, [rsp+0x70]
00007531fdbd6fd7  vmovaps xmm8, [rsp+0x80]
00007531fdbd6fe0  vmovaps xmm9, [rsp+0x90]
00007531fdbd6fe9  vmovaps xmm10, [rsp+0xA0]
00007531fdbd6ff2  vmovaps xmm12, [rsp+0xB0]
00007531fdbd6ffb  vmovaps xmm13, [rsp+0xC0]
00007531fdbd7004  vmovaps xmm14, [rsp+0xD0]
00007531fdbd700d  vmovaps xmm15, [rsp+0xE0]
00007531fdbd7016  add rsp, 0xF0
00007531fdbd701d  pop r11
00007531fdbd701f  pop r10
00007531fdbd7021  pop r9
00007531fdbd7023  pop r8
00007531fdbd7025  pop rsi
00007531fdbd7026  pop rdi
00007531fdbd7027  pop rdx
00007531fdbd7028  pop rcx
00007531fdbd7029  pop rax
00007531fdbd702a  add rsp, 0x08
00007531fdbd702e  jmp 0x00007531FDBD327A
00007531fdbd7033  sub rsp, 0x08
00007531fdbd7037  push rax
00007531fdbd7038  push rcx
00007531fdbd7039  push rdx
00007531fdbd703a  push rdi
00007531fdbd703b  push rsi
00007531fdbd703c  push r8
00007531fdbd703e  push r9
00007531fdbd7040  push r10
00007531fdbd7042  push r11
00007531fdbd7044  sub rsp, 0xF0
00007531fdbd704b  vmovaps [rsp], xmm0
00007531fdbd7050  vmovaps [rsp+0x10], xmm1
00007531fdbd7056  vmovaps [rsp+0x20], xmm2
00007531fdbd705c  vmovaps [rsp+0x30], xmm3
00007531fdbd7062  vmovaps [rsp+0x40], xmm4
00007531fdbd7068  vmovaps [rsp+0x50], xmm5
00007531fdbd706e  vmovaps [rsp+0x60], xmm6
00007531fdbd7074  vmovaps [rsp+0x70], xmm7
00007531fdbd707a  vmovaps [rsp+0x80], xmm8
00007531fdbd7083  vmovaps [rsp+0x90], xmm9
00007531fdbd708c  vmovaps [rsp+0xA0], xmm10
00007531fdbd7095  vmovaps [rsp+0xB0], xmm11
00007531fdbd709e  vmovaps [rsp+0xC0], xmm13
00007531fdbd70a7  vmovaps [rsp+0xD0], xmm14
00007531fdbd70b0  vmovaps [rsp+0xE0], xmm15
00007531fdbd70b9  sub rsp, 0x30
00007531fdbd70bd  movaps [rsp], xmm12
00007531fdbd70c2  movaps [rsp+0x10], xmm8
00007531fdbd70c8  movaps [rsp+0x20], xmm15
00007531fdbd70ce  lea rdi, [rsp]
00007531fdbd70d2  mov esi, 0x00
00007531fdbd70d7  mov rax, 0x59ED111DF530
00007531fdbd70e1  call rax
00007531fdbd70e3  movaps xmm12, [rsp]
00007531fdbd70e8  add rsp, 0x30
00007531fdbd70ec  vmovaps xmm0, [rsp]
00007531fdbd70f1  vmovaps xmm1, [rsp+0x10]
00007531fdbd70f7  vmovaps xmm2, [rsp+0x20]
00007531fdbd70fd  vmovaps xmm3, [rsp+0x30]
00007531fdbd7103  vmovaps xmm4, [rsp+0x40]
00007531fdbd7109  vmovaps xmm5, [rsp+0x50]
00007531fdbd710f  vmovaps xmm6, [rsp+0x60]
00007531fdbd7115  vmovaps xmm7, [rsp+0x70]
00007531fdbd711b  vmovaps xmm8, [rsp+0x80]
00007531fdbd7124  vmovaps xmm9, [rsp+0x90]
00007531fdbd712d  vmovaps xmm10, [rsp+0xA0]
00007531fdbd7136  vmovaps xmm11, [rsp+0xB0]
00007531fdbd713f  vmovaps xmm13, [rsp+0xC0]
00007531fdbd7148  vmovaps xmm14, [rsp+0xD0]
00007531fdbd7151  vmovaps xmm15, [rsp+0xE0]
00007531fdbd715a  add rsp, 0xF0
00007531fdbd7161  pop r11
00007531fdbd7163  pop r10
00007531fdbd7165  pop r9
00007531fdbd7167  pop r8
00007531fdbd7169  pop rsi
00007531fdbd716a  pop rdi
00007531fdbd716b  pop rdx
00007531fdbd716c  pop rcx
00007531fdbd716d  pop rax
00007531fdbd716e  add rsp, 0x08
00007531fdbd7172  jmp 0x00007531FDBD32A9
00007531fdbd7177  sub rsp, 0x08
00007531fdbd717b  push rax
00007531fdbd717c  push rcx
00007531fdbd717d  push rdx
00007531fdbd717e  push rdi
00007531fdbd717f  push rsi
00007531fdbd7180  push r8
00007531fdbd7182  push r9
00007531fdbd7184  push r10
00007531fdbd7186  push r11
00007531fdbd7188  sub rsp, 0xF0
00007531fdbd718f  vmovaps [rsp], xmm0
00007531fdbd7194  vmovaps [rsp+0x10], xmm1
00007531fdbd719a  vmovaps [rsp+0x20], xmm2
00007531fdbd71a0  vmovaps [rsp+0x30], xmm3
00007531fdbd71a6  vmovaps [rsp+0x40], xmm4
00007531fdbd71ac  vmovaps [rsp+0x50], xmm5
00007531fdbd71b2  vmovaps [rsp+0x60], xmm6
00007531fdbd71b8  vmovaps [rsp+0x70], xmm7
00007531fdbd71be  vmovaps [rsp+0x80], xmm9
00007531fdbd71c7  vmovaps [rsp+0x90], xmm10
00007531fdbd71d0  vmovaps [rsp+0xA0], xmm11
00007531fdbd71d9  vmovaps [rsp+0xB0], xmm12
00007531fdbd71e2  vmovaps [rsp+0xC0], xmm13
00007531fdbd71eb  vmovaps [rsp+0xD0], xmm14
00007531fdbd71f4  vmovaps [rsp+0xE0], xmm15
00007531fdbd71fd  sub rsp, 0x30
00007531fdbd7201  movaps [rsp], xmm8
00007531fdbd7206  movaps [rsp+0x10], xmm7
00007531fdbd720b  movaps [rsp+0x20], xmm15
00007531fdbd7211  lea rdi, [rsp]
00007531fdbd7215  mov esi, 0x00
00007531fdbd721a  mov rax, 0x59ED111DF530
00007531fdbd7224  call rax
00007531fdbd7226  movaps xmm8, [rsp]
00007531fdbd722b  add rsp, 0x30
00007531fdbd722f  vmovaps xmm0, [rsp]
00007531fdbd7234  vmovaps xmm1, [rsp+0x10]
00007531fdbd723a  vmovaps xmm2, [rsp+0x20]
00007531fdbd7240  vmovaps xmm3, [rsp+0x30]
00007531fdbd7246  vmovaps xmm4, [rsp+0x40]
00007531fdbd724c  vmovaps xmm5, [rsp+0x50]
00007531fdbd7252  vmovaps xmm6, [rsp+0x60]
00007531fdbd7258  vmovaps xmm7, [rsp+0x70]
00007531fdbd725e  vmovaps xmm9, [rsp+0x80]
00007531fdbd7267  vmovaps xmm10, [rsp+0x90]
00007531fdbd7270  vmovaps xmm11, [rsp+0xA0]
00007531fdbd7279  vmovaps xmm12, [rsp+0xB0]
00007531fdbd7282  vmovaps xmm13, [rsp+0xC0]
00007531fdbd728b  vmovaps xmm14, [rsp+0xD0]
00007531fdbd7294  vmovaps xmm15, [rsp+0xE0]
00007531fdbd729d  add rsp, 0xF0
00007531fdbd72a4  pop r11
00007531fdbd72a6  pop r10
00007531fdbd72a8  pop r9
00007531fdbd72aa  pop r8
00007531fdbd72ac  pop rsi
00007531fdbd72ad  pop rdi
00007531fdbd72ae  pop rdx
00007531fdbd72af  pop rcx
00007531fdbd72b0  pop rax
00007531fdbd72b1  add rsp, 0x08
00007531fdbd72b5  jmp 0x00007531FDBD32CF
00007531fdbd72ba  sub rsp, 0x08
00007531fdbd72be  push rax
00007531fdbd72bf  push rcx
00007531fdbd72c0  push rdx
00007531fdbd72c1  push rdi
00007531fdbd72c2  push rsi
00007531fdbd72c3  push r8
00007531fdbd72c5  push r9
00007531fdbd72c7  push r10
00007531fdbd72c9  push r11
00007531fdbd72cb  sub rsp, 0xF0
00007531fdbd72d2  vmovaps [rsp], xmm0
00007531fdbd72d7  vmovaps [rsp+0x10], xmm1
00007531fdbd72dd  vmovaps [rsp+0x20], xmm2
00007531fdbd72e3  vmovaps [rsp+0x30], xmm3
00007531fdbd72e9  vmovaps [rsp+0x40], xmm4
00007531fdbd72ef  vmovaps [rsp+0x50], xmm5
00007531fdbd72f5  vmovaps [rsp+0x60], xmm6
00007531fdbd72fb  vmovaps [rsp+0x70], xmm7
00007531fdbd7301  vmovaps [rsp+0x80], xmm8
00007531fdbd730a  vmovaps [rsp+0x90], xmm9
00007531fdbd7313  vmovaps [rsp+0xA0], xmm10
00007531fdbd731c  vmovaps [rsp+0xB0], xmm11
00007531fdbd7325  vmovaps [rsp+0xC0], xmm12
00007531fdbd732e  vmovaps [rsp+0xD0], xmm13
00007531fdbd7337  vmovaps [rsp+0xE0], xmm14
00007531fdbd7340  sub rsp, 0x30
00007531fdbd7344  movaps [rsp], xmm15
00007531fdbd7349  movaps [rsp+0x10], xmm14
00007531fdbd734f  movaps [rsp+0x20], xmm9
00007531fdbd7355  lea rdi, [rsp]
00007531fdbd7359  mov esi, 0x00
00007531fdbd735e  mov rax, 0x59ED111DF530
00007531fdbd7368  call rax
00007531fdbd736a  movaps xmm15, [rsp]
00007531fdbd736f  add rsp, 0x30
00007531fdbd7373  vmovaps xmm0, [rsp]
00007531fdbd7378  vmovaps xmm1, [rsp+0x10]
00007531fdbd737e  vmovaps xmm2, [rsp+0x20]
00007531fdbd7384  vmovaps xmm3, [rsp+0x30]
00007531fdbd738a  vmovaps xmm4, [rsp+0x40]
00007531fdbd7390  vmovaps xmm5, [rsp+0x50]
00007531fdbd7396  vmovaps xmm6, [rsp+0x60]
00007531fdbd739c  vmovaps xmm7, [rsp+0x70]
00007531fdbd73a2  vmovaps xmm8, [rsp+0x80]
00007531fdbd73ab  vmovaps xmm9, [rsp+0x90]
00007531fdbd73b4  vmovaps xmm10, [rsp+0xA0]
00007531fdbd73bd  vmovaps xmm11, [rsp+0xB0]
00007531fdbd73c6  vmovaps xmm12, [rsp+0xC0]
00007531fdbd73cf  vmovaps xmm13, [rsp+0xD0]
00007531fdbd73d8  vmovaps xmm14, [rsp+0xE0]
00007531fdbd73e1  add rsp, 0xF0
00007531fdbd73e8  pop r11
00007531fdbd73ea  pop r10
00007531fdbd73ec  pop r9
00007531fdbd73ee  pop r8
00007531fdbd73f0  pop rsi
00007531fdbd73f1  pop rdi
00007531fdbd73f2  pop rdx
00007531fdbd73f3  pop rcx
00007531fdbd73f4  pop rax
00007531fdbd73f5  add rsp, 0x08
00007531fdbd73f9  jmp 0x00007531FDBD32E9
00007531fdbd73fe  sub rsp, 0x08
00007531fdbd7402  push rax
00007531fdbd7403  push rcx
00007531fdbd7404  push rdx
00007531fdbd7405  push rdi
00007531fdbd7406  push rsi
00007531fdbd7407  push r8
00007531fdbd7409  push r9
00007531fdbd740b  push r10
00007531fdbd740d  push r11
00007531fdbd740f  sub rsp, 0xF0
00007531fdbd7416  vmovaps [rsp], xmm0
00007531fdbd741b  vmovaps [rsp+0x10], xmm1
00007531fdbd7421  vmovaps [rsp+0x20], xmm2
00007531fdbd7427  vmovaps [rsp+0x30], xmm3
00007531fdbd742d  vmovaps [rsp+0x40], xmm4
00007531fdbd7433  vmovaps [rsp+0x50], xmm5
00007531fdbd7439  vmovaps [rsp+0x60], xmm6
00007531fdbd743f  vmovaps [rsp+0x70], xmm7
00007531fdbd7445  vmovaps [rsp+0x80], xmm8
00007531fdbd744e  vmovaps [rsp+0x90], xmm10
00007531fdbd7457  vmovaps [rsp+0xA0], xmm11
00007531fdbd7460  vmovaps [rsp+0xB0], xmm12
00007531fdbd7469  vmovaps [rsp+0xC0], xmm13
00007531fdbd7472  vmovaps [rsp+0xD0], xmm14
00007531fdbd747b  vmovaps [rsp+0xE0], xmm15
00007531fdbd7484  sub rsp, 0x30
00007531fdbd7488  movaps [rsp], xmm9
00007531fdbd748d  movaps [rsp+0x10], xmm7
00007531fdbd7492  movaps [rsp+0x20], xmm14
00007531fdbd7498  lea rdi, [rsp]
00007531fdbd749c  mov esi, 0x00
00007531fdbd74a1  mov rax, 0x59ED111DF530
00007531fdbd74ab  call rax
00007531fdbd74ad  movaps xmm9, [rsp]
00007531fdbd74b2  add rsp, 0x30
00007531fdbd74b6  vmovaps xmm0, [rsp]
00007531fdbd74bb  vmovaps xmm1, [rsp+0x10]
00007531fdbd74c1  vmovaps xmm2, [rsp+0x20]
00007531fdbd74c7  vmovaps xmm3, [rsp+0x30]
00007531fdbd74cd  vmovaps xmm4, [rsp+0x40]
00007531fdbd74d3  vmovaps xmm5, [rsp+0x50]
00007531fdbd74d9  vmovaps xmm6, [rsp+0x60]
00007531fdbd74df  vmovaps xmm7, [rsp+0x70]
00007531fdbd74e5  vmovaps xmm8, [rsp+0x80]
00007531fdbd74ee  vmovaps xmm10, [rsp+0x90]
00007531fdbd74f7  vmovaps xmm11, [rsp+0xA0]
00007531fdbd7500  vmovaps xmm12, [rsp+0xB0]
00007531fdbd7509  vmovaps xmm13, [rsp+0xC0]
00007531fdbd7512  vmovaps xmm14, [rsp+0xD0]
00007531fdbd751b  vmovaps xmm15, [rsp+0xE0]
00007531fdbd7524  add rsp, 0xF0
00007531fdbd752b  pop r11
00007531fdbd752d  pop r10
00007531fdbd752f  pop r9
00007531fdbd7531  pop r8
00007531fdbd7533  pop rsi
00007531fdbd7534  pop rdi
00007531fdbd7535  pop rdx
00007531fdbd7536  pop rcx
00007531fdbd7537  pop rax
00007531fdbd7538  add rsp, 0x08
00007531fdbd753c  jmp 0x00007531FDBD3318
00007531fdbd7541  sub rsp, 0x08
00007531fdbd7545  push rax
00007531fdbd7546  push rcx
00007531fdbd7547  push rdx
00007531fdbd7548  push rdi
00007531fdbd7549  push rsi
00007531fdbd754a  push r8
00007531fdbd754c  push r9
00007531fdbd754e  push r10
00007531fdbd7550  push r11
00007531fdbd7552  sub rsp, 0xF0
00007531fdbd7559  vmovaps [rsp], xmm0
00007531fdbd755e  vmovaps [rsp+0x10], xmm1
00007531fdbd7564  vmovaps [rsp+0x20], xmm2
00007531fdbd756a  vmovaps [rsp+0x30], xmm3
00007531fdbd7570  vmovaps [rsp+0x40], xmm4
00007531fdbd7576  vmovaps [rsp+0x50], xmm5
00007531fdbd757c  vmovaps [rsp+0x60], xmm6
00007531fdbd7582  vmovaps [rsp+0x70], xmm7
00007531fdbd7588  vmovaps [rsp+0x80], xmm8
00007531fdbd7591  vmovaps [rsp+0x90], xmm9
00007531fdbd759a  vmovaps [rsp+0xA0], xmm10
00007531fdbd75a3  vmovaps [rsp+0xB0], xmm11
00007531fdbd75ac  vmovaps [rsp+0xC0], xmm12
00007531fdbd75b5  vmovaps [rsp+0xD0], xmm13
00007531fdbd75be  vmovaps [rsp+0xE0], xmm15
00007531fdbd75c7  sub rsp, 0x30
00007531fdbd75cb  movaps [rsp], xmm14
00007531fdbd75d0  movaps [rsp+0x10], xmm13
00007531fdbd75d6  movaps [rsp+0x20], xmm11
00007531fdbd75dc  lea rdi, [rsp]
00007531fdbd75e0  mov esi, 0x00
00007531fdbd75e5  mov rax, 0x59ED111DF530
00007531fdbd75ef  call rax
00007531fdbd75f1  movaps xmm14, [rsp]
00007531fdbd75f6  add rsp, 0x30
00007531fdbd75fa  vmovaps xmm0, [rsp]
00007531fdbd75ff  vmovaps xmm1, [rsp+0x10]
00007531fdbd7605  vmovaps xmm2, [rsp+0x20]
00007531fdbd760b  vmovaps xmm3, [rsp+0x30]
00007531fdbd7611  vmovaps xmm4, [rsp+0x40]
00007531fdbd7617  vmovaps xmm5, [rsp+0x50]
00007531fdbd761d  vmovaps xmm6, [rsp+0x60]
00007531fdbd7623  vmovaps xmm7, [rsp+0x70]
00007531fdbd7629  vmovaps xmm8, [rsp+0x80]
00007531fdbd7632  vmovaps xmm9, [rsp+0x90]
00007531fdbd763b  vmovaps xmm10, [rsp+0xA0]
00007531fdbd7644  vmovaps xmm11, [rsp+0xB0]
00007531fdbd764d  vmovaps xmm12, [rsp+0xC0]
00007531fdbd7656  vmovaps xmm13, [rsp+0xD0]
00007531fdbd765f  vmovaps xmm15, [rsp+0xE0]
00007531fdbd7668  add rsp, 0xF0
00007531fdbd766f  pop r11
00007531fdbd7671  pop r10
00007531fdbd7673  pop r9
00007531fdbd7675  pop r8
00007531fdbd7677  pop rsi
00007531fdbd7678  pop rdi
00007531fdbd7679  pop rdx
00007531fdbd767a  pop rcx
00007531fdbd767b  pop rax
00007531fdbd767c  add rsp, 0x08
00007531fdbd7680  jmp 0x00007531FDBD3332
00007531fdbd7685  sub rsp, 0x08
00007531fdbd7689  push rax
00007531fdbd768a  push rcx
00007531fdbd768b  push rdx
00007531fdbd768c  push rdi
00007531fdbd768d  push rsi
00007531fdbd768e  push r8
00007531fdbd7690  push r9
00007531fdbd7692  push r10
00007531fdbd7694  push r11
00007531fdbd7696  sub rsp, 0xF0
00007531fdbd769d  vmovaps [rsp], xmm0
00007531fdbd76a2  vmovaps [rsp+0x10], xmm1
00007531fdbd76a8  vmovaps [rsp+0x20], xmm2
00007531fdbd76ae  vmovaps [rsp+0x30], xmm3
00007531fdbd76b4  vmovaps [rsp+0x40], xmm4
00007531fdbd76ba  vmovaps [rsp+0x50], xmm5
00007531fdbd76c0  vmovaps [rsp+0x60], xmm6
00007531fdbd76c6  vmovaps [rsp+0x70], xmm7
00007531fdbd76cc  vmovaps [rsp+0x80], xmm8
00007531fdbd76d5  vmovaps [rsp+0x90], xmm9
00007531fdbd76de  vmovaps [rsp+0xA0], xmm10
00007531fdbd76e7  vmovaps [rsp+0xB0], xmm12
00007531fdbd76f0  vmovaps [rsp+0xC0], xmm13
00007531fdbd76f9  vmovaps [rsp+0xD0], xmm14
00007531fdbd7702  vmovaps [rsp+0xE0], xmm15
00007531fdbd770b  sub rsp, 0x30
00007531fdbd770f  movaps [rsp], xmm11
00007531fdbd7714  movaps [rsp+0x10], xmm7
00007531fdbd7719  movaps [rsp+0x20], xmm13
00007531fdbd771f  lea rdi, [rsp]
00007531fdbd7723  mov esi, 0x00
00007531fdbd7728  mov rax, 0x59ED111DF530
00007531fdbd7732  call rax
00007531fdbd7734  movaps xmm11, [rsp]
00007531fdbd7739  add rsp, 0x30
00007531fdbd773d  vmovaps xmm0, [rsp]
00007531fdbd7742  vmovaps xmm1, [rsp+0x10]
00007531fdbd7748  vmovaps xmm2, [rsp+0x20]
00007531fdbd774e  vmovaps xmm3, [rsp+0x30]
00007531fdbd7754  vmovaps xmm4, [rsp+0x40]
00007531fdbd775a  vmovaps xmm5, [rsp+0x50]
00007531fdbd7760  vmovaps xmm6, [rsp+0x60]
00007531fdbd7766  vmovaps xmm7, [rsp+0x70]
00007531fdbd776c  vmovaps xmm8, [rsp+0x80]
00007531fdbd7775  vmovaps xmm9, [rsp+0x90]
00007531fdbd777e  vmovaps xmm10, [rsp+0xA0]
00007531fdbd7787  vmovaps xmm12, [rsp+0xB0]
00007531fdbd7790  vmovaps xmm13, [rsp+0xC0]
00007531fdbd7799  vmovaps xmm14, [rsp+0xD0]
00007531fdbd77a2  vmovaps xmm15, [rsp+0xE0]
00007531fdbd77ab  add rsp, 0xF0
00007531fdbd77b2  pop r11
00007531fdbd77b4  pop r10
00007531fdbd77b6  pop r9
00007531fdbd77b8  pop r8
00007531fdbd77ba  pop rsi
00007531fdbd77bb  pop rdi
00007531fdbd77bc  pop rdx
00007531fdbd77bd  pop rcx
00007531fdbd77be  pop rax
00007531fdbd77bf  add rsp, 0x08
00007531fdbd77c3  jmp 0x00007531FDBD335E
00007531fdbd77c8  sub rsp, 0x08
00007531fdbd77cc  push rax
00007531fdbd77cd  push rcx
00007531fdbd77ce  push rdx
00007531fdbd77cf  push rdi
00007531fdbd77d0  push rsi
00007531fdbd77d1  push r8
00007531fdbd77d3  push r9
00007531fdbd77d5  push r10
00007531fdbd77d7  push r11
00007531fdbd77d9  sub rsp, 0xF0
00007531fdbd77e0  vmovaps [rsp], xmm0
00007531fdbd77e5  vmovaps [rsp+0x10], xmm1
00007531fdbd77eb  vmovaps [rsp+0x20], xmm2
00007531fdbd77f1  vmovaps [rsp+0x30], xmm3
00007531fdbd77f7  vmovaps [rsp+0x40], xmm4
00007531fdbd77fd  vmovaps [rsp+0x50], xmm5
00007531fdbd7803  vmovaps [rsp+0x60], xmm6
00007531fdbd7809  vmovaps [rsp+0x70], xmm7
00007531fdbd780f  vmovaps [rsp+0x80], xmm8
00007531fdbd7818  vmovaps [rsp+0x90], xmm9
00007531fdbd7821  vmovaps [rsp+0xA0], xmm10
00007531fdbd782a  vmovaps [rsp+0xB0], xmm11
00007531fdbd7833  vmovaps [rsp+0xC0], xmm12
00007531fdbd783c  vmovaps [rsp+0xD0], xmm14
00007531fdbd7845  vmovaps [rsp+0xE0], xmm15
00007531fdbd784e  sub rsp, 0x30
00007531fdbd7852  movaps [rsp], xmm13
00007531fdbd7857  movaps [rsp+0x10], xmm10
00007531fdbd785d  movaps [rsp+0x20], xmm12
00007531fdbd7863  lea rdi, [rsp]
00007531fdbd7867  mov esi, 0x00
00007531fdbd786c  mov rax, 0x59ED111DF530
00007531fdbd7876  call rax
00007531fdbd7878  movaps xmm13, [rsp]
00007531fdbd787d  add rsp, 0x30
00007531fdbd7881  vmovaps xmm0, [rsp]
00007531fdbd7886  vmovaps xmm1, [rsp+0x10]
00007531fdbd788c  vmovaps xmm2, [rsp+0x20]
00007531fdbd7892  vmovaps xmm3, [rsp+0x30]
00007531fdbd7898  vmovaps xmm4, [rsp+0x40]
00007531fdbd789e  vmovaps xmm5, [rsp+0x50]
00007531fdbd78a4  vmovaps xmm6, [rsp+0x60]
00007531fdbd78aa  vmovaps xmm7, [rsp+0x70]
00007531fdbd78b0  vmovaps xmm8, [rsp+0x80]
00007531fdbd78b9  vmovaps xmm9, [rsp+0x90]
00007531fdbd78c2  vmovaps xmm10, [rsp+0xA0]
00007531fdbd78cb  vmovaps xmm11, [rsp+0xB0]
00007531fdbd78d4  vmovaps xmm12, [rsp+0xC0]
00007531fdbd78dd  vmovaps xmm14, [rsp+0xD0]
00007531fdbd78e6  vmovaps xmm15, [rsp+0xE0]
00007531fdbd78ef  add rsp, 0xF0
00007531fdbd78f6  pop r11
00007531fdbd78f8  pop r10
00007531fdbd78fa  pop r9
00007531fdbd78fc  pop r8
00007531fdbd78fe  pop rsi
00007531fdbd78ff  pop rdi
00007531fdbd7900  pop rdx
00007531fdbd7901  pop rcx
00007531fdbd7902  pop rax
00007531fdbd7903  add rsp, 0x08
00007531fdbd7907  jmp 0x00007531FDBD3378
00007531fdbd790c  sub rsp, 0x08
00007531fdbd7910  push rax
00007531fdbd7911  push rcx
00007531fdbd7912  push rdx
00007531fdbd7913  push rdi
00007531fdbd7914  push rsi
00007531fdbd7915  push r8
00007531fdbd7917  push r9
00007531fdbd7919  push r10
00007531fdbd791b  push r11
00007531fdbd791d  sub rsp, 0xF0
00007531fdbd7924  vmovaps [rsp], xmm0
00007531fdbd7929  vmovaps [rsp+0x10], xmm1
00007531fdbd792f  vmovaps [rsp+0x20], xmm2
00007531fdbd7935  vmovaps [rsp+0x30], xmm3
00007531fdbd793b  vmovaps [rsp+0x40], xmm4
00007531fdbd7941  vmovaps [rsp+0x50], xmm5
00007531fdbd7947  vmovaps [rsp+0x60], xmm6
00007531fdbd794d  vmovaps [rsp+0x70], xmm7
00007531fdbd7953  vmovaps [rsp+0x80], xmm8
00007531fdbd795c  vmovaps [rsp+0x90], xmm9
00007531fdbd7965  vmovaps [rsp+0xA0], xmm11
00007531fdbd796e  vmovaps [rsp+0xB0], xmm12
00007531fdbd7977  vmovaps [rsp+0xC0], xmm13
00007531fdbd7980  vmovaps [rsp+0xD0], xmm14
00007531fdbd7989  vmovaps [rsp+0xE0], xmm15
00007531fdbd7992  sub rsp, 0x30
00007531fdbd7996  movaps [rsp], xmm10
00007531fdbd799b  movaps [rsp+0x10], xmm7
00007531fdbd79a0  movaps [rsp+0x20], xmm12
00007531fdbd79a6  lea rdi, [rsp]
00007531fdbd79aa  mov esi, 0x00
00007531fdbd79af  mov rax, 0x59ED111DF530
00007531fdbd79b9  call rax
00007531fdbd79bb  movaps xmm10, [rsp]
00007531fdbd79c0  add rsp, 0x30
00007531fdbd79c4  vmovaps xmm0, [rsp]
00007531fdbd79c9  vmovaps xmm1, [rsp+0x10]
00007531fdbd79cf  vmovaps xmm2, [rsp+0x20]
00007531fdbd79d5  vmovaps xmm3, [rsp+0x30]
00007531fdbd79db  vmovaps xmm4, [rsp+0x40]
00007531fdbd79e1  vmovaps xmm5, [rsp+0x50]
00007531fdbd79e7  vmovaps xmm6, [rsp+0x60]
00007531fdbd79ed  vmovaps xmm7, [rsp+0x70]
00007531fdbd79f3  vmovaps xmm8, [rsp+0x80]
00007531fdbd79fc  vmovaps xmm9, [rsp+0x90]
00007531fdbd7a05  vmovaps xmm11, [rsp+0xA0]
00007531fdbd7a0e  vmovaps xmm12, [rsp+0xB0]
00007531fdbd7a17  vmovaps xmm13, [rsp+0xC0]
00007531fdbd7a20  vmovaps xmm14, [rsp+0xD0]
00007531fdbd7a29  vmovaps xmm15, [rsp+0xE0]
00007531fdbd7a32  add rsp, 0xF0
00007531fdbd7a39  pop r11
00007531fdbd7a3b  pop r10
00007531fdbd7a3d  pop r9
00007531fdbd7a3f  pop r8
00007531fdbd7a41  pop rsi
00007531fdbd7a42  pop rdi
00007531fdbd7a43  pop rdx
00007531fdbd7a44  pop rcx
00007531fdbd7a45  pop rax
00007531fdbd7a46  add rsp, 0x08
00007531fdbd7a4a  jmp 0x00007531FDBD33A4
00007531fdbd7a4f  sub rsp, 0x08
00007531fdbd7a53  push rax
00007531fdbd7a54  push rcx
00007531fdbd7a55  push rdx
00007531fdbd7a56  push rdi
00007531fdbd7a57  push rsi
00007531fdbd7a58  push r8
00007531fdbd7a5a  push r9
00007531fdbd7a5c  push r10
00007531fdbd7a5e  push r11
00007531fdbd7a60  sub rsp, 0xF0
00007531fdbd7a67  vmovaps [rsp], xmm0
00007531fdbd7a6c  vmovaps [rsp+0x10], xmm1
00007531fdbd7a72  vmovaps [rsp+0x20], xmm2
00007531fdbd7a78  vmovaps [rsp+0x30], xmm3
00007531fdbd7a7e  vmovaps [rsp+0x40], xmm4
00007531fdbd7a84  vmovaps [rsp+0x50], xmm5
00007531fdbd7a8a  vmovaps [rsp+0x60], xmm6
00007531fdbd7a90  vmovaps [rsp+0x70], xmm7
00007531fdbd7a96  vmovaps [rsp+0x80], xmm8
00007531fdbd7a9f  vmovaps [rsp+0x90], xmm9
00007531fdbd7aa8  vmovaps [rsp+0xA0], xmm10
00007531fdbd7ab1  vmovaps [rsp+0xB0], xmm11
00007531fdbd7aba  vmovaps [rsp+0xC0], xmm13
00007531fdbd7ac3  vmovaps [rsp+0xD0], xmm14
00007531fdbd7acc  vmovaps [rsp+0xE0], xmm15
00007531fdbd7ad5  sub rsp, 0x30
00007531fdbd7ad9  movaps [rsp], xmm12
00007531fdbd7ade  movaps [rsp+0x10], xmm1
00007531fdbd7ae3  movaps [rsp+0x20], xmm8
00007531fdbd7ae9  lea rdi, [rsp]
00007531fdbd7aed  mov esi, 0x00
00007531fdbd7af2  mov rax, 0x59ED111DF530
00007531fdbd7afc  call rax
00007531fdbd7afe  movaps xmm12, [rsp]
00007531fdbd7b03  add rsp, 0x30
00007531fdbd7b07  vmovaps xmm0, [rsp]
00007531fdbd7b0c  vmovaps xmm1, [rsp+0x10]
00007531fdbd7b12  vmovaps xmm2, [rsp+0x20]
00007531fdbd7b18  vmovaps xmm3, [rsp+0x30]
00007531fdbd7b1e  vmovaps xmm4, [rsp+0x40]
00007531fdbd7b24  vmovaps xmm5, [rsp+0x50]
00007531fdbd7b2a  vmovaps xmm6, [rsp+0x60]
00007531fdbd7b30  vmovaps xmm7, [rsp+0x70]
00007531fdbd7b36  vmovaps xmm8, [rsp+0x80]
00007531fdbd7b3f  vmovaps xmm9, [rsp+0x90]
00007531fdbd7b48  vmovaps xmm10, [rsp+0xA0]
00007531fdbd7b51  vmovaps xmm11, [rsp+0xB0]
00007531fdbd7b5a  vmovaps xmm13, [rsp+0xC0]
00007531fdbd7b63  vmovaps xmm14, [rsp+0xD0]
00007531fdbd7b6c  vmovaps xmm15, [rsp+0xE0]
00007531fdbd7b75  add rsp, 0xF0
00007531fdbd7b7c  pop r11
00007531fdbd7b7e  pop r10
00007531fdbd7b80  pop r9
00007531fdbd7b82  pop r8
00007531fdbd7b84  pop rsi
00007531fdbd7b85  pop rdi
00007531fdbd7b86  pop rdx
00007531fdbd7b87  pop rcx
00007531fdbd7b88  pop rax
00007531fdbd7b89  add rsp, 0x08
00007531fdbd7b8d  jmp 0x00007531FDBD33BE
00007531fdbd7b92  call 0x00007531FD9FF430
00007531fdbd7b97  jmp 0x00007531FDBD33C8
00007531fdbd7b9c  sub rsp, 0x08
00007531fdbd7ba0  push rax
00007531fdbd7ba1  push rcx
00007531fdbd7ba2  push rdx
00007531fdbd7ba3  push rdi
00007531fdbd7ba4  push rsi
00007531fdbd7ba5  push r8
00007531fdbd7ba7  push r9
00007531fdbd7ba9  push r10
00007531fdbd7bab  push r11
00007531fdbd7bad  sub rsp, 0xF0
00007531fdbd7bb4  vmovaps [rsp], xmm0
00007531fdbd7bb9  vmovaps [rsp+0x10], xmm1
00007531fdbd7bbf  vmovaps [rsp+0x20], xmm2
00007531fdbd7bc5  vmovaps [rsp+0x30], xmm3
00007531fdbd7bcb  vmovaps [rsp+0x40], xmm4
00007531fdbd7bd1  vmovaps [rsp+0x50], xmm5
00007531fdbd7bd7  vmovaps [rsp+0x60], xmm6
00007531fdbd7bdd  vmovaps [rsp+0x70], xmm7
00007531fdbd7be3  vmovaps [rsp+0x80], xmm9
00007531fdbd7bec  vmovaps [rsp+0x90], xmm10
00007531fdbd7bf5  vmovaps [rsp+0xA0], xmm11
00007531fdbd7bfe  vmovaps [rsp+0xB0], xmm12
00007531fdbd7c07  vmovaps [rsp+0xC0], xmm13
00007531fdbd7c10  vmovaps [rsp+0xD0], xmm14
00007531fdbd7c19  vmovaps [rsp+0xE0], xmm15
00007531fdbd7c22  sub rsp, 0x30
00007531fdbd7c26  movaps [rsp], xmm8
00007531fdbd7c2b  movaps [rsp+0x10], xmm15
00007531fdbd7c31  movaps [rsp+0x20], xmm9
00007531fdbd7c37  lea rdi, [rsp]
00007531fdbd7c3b  mov esi, 0x00
00007531fdbd7c40  mov rax, 0x59ED111DF530
00007531fdbd7c4a  call rax
00007531fdbd7c4c  movaps xmm8, [rsp]
00007531fdbd7c51  add rsp, 0x30
00007531fdbd7c55  vmovaps xmm0, [rsp]
00007531fdbd7c5a  vmovaps xmm1, [rsp+0x10]
00007531fdbd7c60  vmovaps xmm2, [rsp+0x20]
00007531fdbd7c66  vmovaps xmm3, [rsp+0x30]
00007531fdbd7c6c  vmovaps xmm4, [rsp+0x40]
00007531fdbd7c72  vmovaps xmm5, [rsp+0x50]
00007531fdbd7c78  vmovaps xmm6, [rsp+0x60]
00007531fdbd7c7e  vmovaps xmm7, [rsp+0x70]
00007531fdbd7c84  vmovaps xmm9, [rsp+0x80]
00007531fdbd7c8d  vmovaps xmm10, [rsp+0x90]
00007531fdbd7c96  vmovaps xmm11, [rsp+0xA0]
00007531fdbd7c9f  vmovaps xmm12, [rsp+0xB0]
00007531fdbd7ca8  vmovaps xmm13, [rsp+0xC0]
00007531fdbd7cb1  vmovaps xmm14, [rsp+0xD0]
00007531fdbd7cba  vmovaps xmm15, [rsp+0xE0]
00007531fdbd7cc3  add rsp, 0xF0
00007531fdbd7cca  pop r11
00007531fdbd7ccc  pop r10
00007531fdbd7cce  pop r9
00007531fdbd7cd0  pop r8
00007531fdbd7cd2  pop rsi
00007531fdbd7cd3  pop rdi
00007531fdbd7cd4  pop rdx
00007531fdbd7cd5  pop rcx
00007531fdbd7cd6  pop rax
00007531fdbd7cd7  add rsp, 0x08
00007531fdbd7cdb  jmp 0x00007531FDBD33EA
00007531fdbd7ce0  sub rsp, 0x08
00007531fdbd7ce4  push rax
00007531fdbd7ce5  push rcx
00007531fdbd7ce6  push rdx
00007531fdbd7ce7  push rdi
00007531fdbd7ce8  push rsi
00007531fdbd7ce9  push r8
00007531fdbd7ceb  push r9
00007531fdbd7ced  push r10
00007531fdbd7cef  push r11
00007531fdbd7cf1  sub rsp, 0xF0
00007531fdbd7cf8  vmovaps [rsp], xmm0
00007531fdbd7cfd  vmovaps [rsp+0x10], xmm1
00007531fdbd7d03  vmovaps [rsp+0x20], xmm2
00007531fdbd7d09  vmovaps [rsp+0x30], xmm3
00007531fdbd7d0f  vmovaps [rsp+0x40], xmm4
00007531fdbd7d15  vmovaps [rsp+0x50], xmm5
00007531fdbd7d1b  vmovaps [rsp+0x60], xmm6
00007531fdbd7d21  vmovaps [rsp+0x70], xmm7
00007531fdbd7d27  vmovaps [rsp+0x80], xmm8
00007531fdbd7d30  vmovaps [rsp+0x90], xmm10
00007531fdbd7d39  vmovaps [rsp+0xA0], xmm11
00007531fdbd7d42  vmovaps [rsp+0xB0], xmm12
00007531fdbd7d4b  vmovaps [rsp+0xC0], xmm13
00007531fdbd7d54  vmovaps [rsp+0xD0], xmm14
00007531fdbd7d5d  vmovaps [rsp+0xE0], xmm15
00007531fdbd7d66  sub rsp, 0x30
00007531fdbd7d6a  movaps [rsp], xmm9
00007531fdbd7d6f  movaps [rsp+0x10], xmm1
00007531fdbd7d74  movaps [rsp+0x20], xmm15
00007531fdbd7d7a  lea rdi, [rsp]
00007531fdbd7d7e  mov esi, 0x00
00007531fdbd7d83  mov rax, 0x59ED111DF530
00007531fdbd7d8d  call rax
00007531fdbd7d8f  movaps xmm9, [rsp]
00007531fdbd7d94  add rsp, 0x30
00007531fdbd7d98  vmovaps xmm0, [rsp]
00007531fdbd7d9d  vmovaps xmm1, [rsp+0x10]
00007531fdbd7da3  vmovaps xmm2, [rsp+0x20]
00007531fdbd7da9  vmovaps xmm3, [rsp+0x30]
00007531fdbd7daf  vmovaps xmm4, [rsp+0x40]
00007531fdbd7db5  vmovaps xmm5, [rsp+0x50]
00007531fdbd7dbb  vmovaps xmm6, [rsp+0x60]
00007531fdbd7dc1  vmovaps xmm7, [rsp+0x70]
00007531fdbd7dc7  vmovaps xmm8, [rsp+0x80]
00007531fdbd7dd0  vmovaps xmm10, [rsp+0x90]
00007531fdbd7dd9  vmovaps xmm11, [rsp+0xA0]
00007531fdbd7de2  vmovaps xmm12, [rsp+0xB0]
00007531fdbd7deb  vmovaps xmm13, [rsp+0xC0]
00007531fdbd7df4  vmovaps xmm14, [rsp+0xD0]
00007531fdbd7dfd  vmovaps xmm15, [rsp+0xE0]
00007531fdbd7e06  add rsp, 0xF0
00007531fdbd7e0d  pop r11
00007531fdbd7e0f  pop r10
00007531fdbd7e11  pop r9
00007531fdbd7e13  pop r8
00007531fdbd7e15  pop rsi
00007531fdbd7e16  pop rdi
00007531fdbd7e17  pop rdx
00007531fdbd7e18  pop rcx
00007531fdbd7e19  pop rax
00007531fdbd7e1a  add rsp, 0x08
00007531fdbd7e1e  jmp 0x00007531FDBD3418
00007531fdbd7e23  sub rsp, 0x08
00007531fdbd7e27  push rax
00007531fdbd7e28  push rcx
00007531fdbd7e29  push rdx
00007531fdbd7e2a  push rdi
00007531fdbd7e2b  push rsi
00007531fdbd7e2c  push r8
00007531fdbd7e2e  push r9
00007531fdbd7e30  push r10
00007531fdbd7e32  push r11
00007531fdbd7e34  sub rsp, 0xF0
00007531fdbd7e3b  vmovaps [rsp], xmm0
00007531fdbd7e40  vmovaps [rsp+0x10], xmm1
00007531fdbd7e46  vmovaps [rsp+0x20], xmm2
00007531fdbd7e4c  vmovaps [rsp+0x30], xmm3
00007531fdbd7e52  vmovaps [rsp+0x40], xmm4
00007531fdbd7e58  vmovaps [rsp+0x50], xmm5
00007531fdbd7e5e  vmovaps [rsp+0x60], xmm6
00007531fdbd7e64  vmovaps [rsp+0x70], xmm7
00007531fdbd7e6a  vmovaps [rsp+0x80], xmm8
00007531fdbd7e73  vmovaps [rsp+0x90], xmm9
00007531fdbd7e7c  vmovaps [rsp+0xA0], xmm10
00007531fdbd7e85  vmovaps [rsp+0xB0], xmm11
00007531fdbd7e8e  vmovaps [rsp+0xC0], xmm12
00007531fdbd7e97  vmovaps [rsp+0xD0], xmm13
00007531fdbd7ea0  vmovaps [rsp+0xE0], xmm14
00007531fdbd7ea9  sub rsp, 0x30
00007531fdbd7ead  movaps [rsp], xmm15
00007531fdbd7eb2  movaps [rsp+0x10], xmm4
00007531fdbd7eb7  movaps [rsp+0x20], xmm1
00007531fdbd7ebc  lea rdi, [rsp]
00007531fdbd7ec0  mov esi, 0x00
00007531fdbd7ec5  mov rax, 0x59ED111DF530
00007531fdbd7ecf  call rax
00007531fdbd7ed1  movaps xmm15, [rsp]
00007531fdbd7ed6  add rsp, 0x30
00007531fdbd7eda  vmovaps xmm0, [rsp]
00007531fdbd7edf  vmovaps xmm1, [rsp+0x10]
00007531fdbd7ee5  vmovaps xmm2, [rsp+0x20]
00007531fdbd7eeb  vmovaps xmm3, [rsp+0x30]
00007531fdbd7ef1  vmovaps xmm4, [rsp+0x40]
00007531fdbd7ef7  vmovaps xmm5, [rsp+0x50]
00007531fdbd7efd  vmovaps xmm6, [rsp+0x60]
00007531fdbd7f03  vmovaps xmm7, [rsp+0x70]
00007531fdbd7f09  vmovaps xmm8, [rsp+0x80]
00007531fdbd7f12  vmovaps xmm9, [rsp+0x90]
00007531fdbd7f1b  vmovaps xmm10, [rsp+0xA0]
00007531fdbd7f24  vmovaps xmm11, [rsp+0xB0]
00007531fdbd7f2d  vmovaps xmm12, [rsp+0xC0]
00007531fdbd7f36  vmovaps xmm13, [rsp+0xD0]
00007531fdbd7f3f  vmovaps xmm14, [rsp+0xE0]
00007531fdbd7f48  add rsp, 0xF0
00007531fdbd7f4f  pop r11
00007531fdbd7f51  pop r10
00007531fdbd7f53  pop r9
00007531fdbd7f55  pop r8
00007531fdbd7f57  pop rsi
00007531fdbd7f58  pop rdi
00007531fdbd7f59  pop rdx
00007531fdbd7f5a  pop rcx
00007531fdbd7f5b  pop rax
00007531fdbd7f5c  add rsp, 0x08
00007531fdbd7f60  jmp 0x00007531FDBD343E
00007531fdbd7f65  sub rsp, 0x08
00007531fdbd7f69  push rax
00007531fdbd7f6a  push rcx
00007531fdbd7f6b  push rdx
00007531fdbd7f6c  push rdi
00007531fdbd7f6d  push rsi
00007531fdbd7f6e  push r8
00007531fdbd7f70  push r9
00007531fdbd7f72  push r10
00007531fdbd7f74  push r11
00007531fdbd7f76  sub rsp, 0xF0
00007531fdbd7f7d  vmovaps [rsp], xmm0
00007531fdbd7f82  vmovaps [rsp+0x10], xmm2
00007531fdbd7f88  vmovaps [rsp+0x20], xmm3
00007531fdbd7f8e  vmovaps [rsp+0x30], xmm4
00007531fdbd7f94  vmovaps [rsp+0x40], xmm5
00007531fdbd7f9a  vmovaps [rsp+0x50], xmm6
00007531fdbd7fa0  vmovaps [rsp+0x60], xmm7
00007531fdbd7fa6  vmovaps [rsp+0x70], xmm8
00007531fdbd7fac  vmovaps [rsp+0x80], xmm9
00007531fdbd7fb5  vmovaps [rsp+0x90], xmm10
00007531fdbd7fbe  vmovaps [rsp+0xA0], xmm11
00007531fdbd7fc7  vmovaps [rsp+0xB0], xmm12
00007531fdbd7fd0  vmovaps [rsp+0xC0], xmm13
00007531fdbd7fd9  vmovaps [rsp+0xD0], xmm14
00007531fdbd7fe2  vmovaps [rsp+0xE0], xmm15
00007531fdbd7feb  sub rsp, 0x30
00007531fdbd7fef  movaps [rsp], xmm1
00007531fdbd7ff3  movaps [rsp+0x10], xmm14
00007531fdbd7ff9  movaps [rsp+0x20], xmm11
00007531fdbd7fff  lea rdi, [rsp]
00007531fdbd8003  mov esi, 0x00
00007531fdbd8008  mov rax, 0x59ED111DF530
00007531fdbd8012  call rax
00007531fdbd8014  movaps xmm1, [rsp]
00007531fdbd8018  add rsp, 0x30
00007531fdbd801c  vmovaps xmm0, [rsp]
00007531fdbd8021  vmovaps xmm2, [rsp+0x10]
00007531fdbd8027  vmovaps xmm3, [rsp+0x20]
00007531fdbd802d  vmovaps xmm4, [rsp+0x30]
00007531fdbd8033  vmovaps xmm5, [rsp+0x40]
00007531fdbd8039  vmovaps xmm6, [rsp+0x50]
00007531fdbd803f  vmovaps xmm7, [rsp+0x60]
00007531fdbd8045  vmovaps xmm8, [rsp+0x70]
00007531fdbd804b  vmovaps xmm9, [rsp+0x80]
00007531fdbd8054  vmovaps xmm10, [rsp+0x90]
00007531fdbd805d  vmovaps xmm11, [rsp+0xA0]
00007531fdbd8066  vmovaps xmm12, [rsp+0xB0]
00007531fdbd806f  vmovaps xmm13, [rsp+0xC0]
00007531fdbd8078  vmovaps xmm14, [rsp+0xD0]
00007531fdbd8081  vmovaps xmm15, [rsp+0xE0]
00007531fdbd808a  add rsp, 0xF0
00007531fdbd8091  pop r11
00007531fdbd8093  pop r10
00007531fdbd8095  pop r9
00007531fdbd8097  pop r8
00007531fdbd8099  pop rsi
00007531fdbd809a  pop rdi
00007531fdbd809b  pop rdx
00007531fdbd809c  pop rcx
00007531fdbd809d  pop rax
00007531fdbd809e  add rsp, 0x08
00007531fdbd80a2  jmp 0x00007531FDBD345F
00007531fdbd80a7  call 0x00007531FDAE45A0
00007531fdbd80ac  jmp 0x00007531FDBD346D
00007531fdbd80b1  call 0x00007531FDA09D70
00007531fdbd80b6  jmp 0x00007531FDBD3477
00007531fdbd80bb  sub rsp, 0x08
00007531fdbd80bf  push rax
00007531fdbd80c0  push rcx
00007531fdbd80c1  push rdx
00007531fdbd80c2  push rdi
00007531fdbd80c3  push rsi
00007531fdbd80c4  push r8
00007531fdbd80c6  push r9
00007531fdbd80c8  push r10
00007531fdbd80ca  push r11
00007531fdbd80cc  sub rsp, 0xF0
00007531fdbd80d3  vmovaps [rsp], xmm0
00007531fdbd80d8  vmovaps [rsp+0x10], xmm1
00007531fdbd80de  vmovaps [rsp+0x20], xmm2
00007531fdbd80e4  vmovaps [rsp+0x30], xmm3
00007531fdbd80ea  vmovaps [rsp+0x40], xmm4
00007531fdbd80f0  vmovaps [rsp+0x50], xmm5
00007531fdbd80f6  vmovaps [rsp+0x60], xmm6
00007531fdbd80fc  vmovaps [rsp+0x70], xmm8
00007531fdbd8102  vmovaps [rsp+0x80], xmm9
00007531fdbd810b  vmovaps [rsp+0x90], xmm10
00007531fdbd8114  vmovaps [rsp+0xA0], xmm11
00007531fdbd811d  vmovaps [rsp+0xB0], xmm12
00007531fdbd8126  vmovaps [rsp+0xC0], xmm13
00007531fdbd812f  vmovaps [rsp+0xD0], xmm14
00007531fdbd8138  vmovaps [rsp+0xE0], xmm15
00007531fdbd8141  sub rsp, 0x30
00007531fdbd8145  movaps [rsp], xmm7
00007531fdbd8149  movaps [rsp+0x10], xmm13
00007531fdbd814f  movaps [rsp+0x20], xmm10
00007531fdbd8155  lea rdi, [rsp]
00007531fdbd8159  mov esi, 0x00
00007531fdbd815e  mov rax, 0x59ED111DF530
00007531fdbd8168  call rax
00007531fdbd816a  movaps xmm7, [rsp]
00007531fdbd816e  add rsp, 0x30
00007531fdbd8172  vmovaps xmm0, [rsp]
00007531fdbd8177  vmovaps xmm1, [rsp+0x10]
00007531fdbd817d  vmovaps xmm2, [rsp+0x20]
00007531fdbd8183  vmovaps xmm3, [rsp+0x30]
00007531fdbd8189  vmovaps xmm4, [rsp+0x40]
00007531fdbd818f  vmovaps xmm5, [rsp+0x50]
00007531fdbd8195  vmovaps xmm6, [rsp+0x60]
00007531fdbd819b  vmovaps xmm8, [rsp+0x70]
00007531fdbd81a1  vmovaps xmm9, [rsp+0x80]
00007531fdbd81aa  vmovaps xmm10, [rsp+0x90]
00007531fdbd81b3  vmovaps xmm11, [rsp+0xA0]
00007531fdbd81bc  vmovaps xmm12, [rsp+0xB0]
00007531fdbd81c5  vmovaps xmm13, [rsp+0xC0]
00007531fdbd81ce  vmovaps xmm14, [rsp+0xD0]
00007531fdbd81d7  vmovaps xmm15, [rsp+0xE0]
00007531fdbd81e0  add rsp, 0xF0
00007531fdbd81e7  pop r11
00007531fdbd81e9  pop r10
00007531fdbd81eb  pop r9
00007531fdbd81ed  pop r8
00007531fdbd81ef  pop rsi
00007531fdbd81f0  pop rdi
00007531fdbd81f1  pop rdx
00007531fdbd81f2  pop rcx
00007531fdbd81f3  pop rax
00007531fdbd81f4  add rsp, 0x08
00007531fdbd81f8  jmp 0x00007531FDBD3498
00007531fdbd81fd  sub rsp, 0x08
00007531fdbd8201  push rax
00007531fdbd8202  push rcx
00007531fdbd8203  push rdx
00007531fdbd8204  push rdi
00007531fdbd8205  push rsi
00007531fdbd8206  push r8
00007531fdbd8208  push r9
00007531fdbd820a  push r10
00007531fdbd820c  push r11
00007531fdbd820e  sub rsp, 0xF0
00007531fdbd8215  vmovaps [rsp], xmm0
00007531fdbd821a  vmovaps [rsp+0x10], xmm1
00007531fdbd8220  vmovaps [rsp+0x20], xmm2
00007531fdbd8226  vmovaps [rsp+0x30], xmm3
00007531fdbd822c  vmovaps [rsp+0x40], xmm4
00007531fdbd8232  vmovaps [rsp+0x50], xmm5
00007531fdbd8238  vmovaps [rsp+0x60], xmm6
00007531fdbd823e  vmovaps [rsp+0x70], xmm7
00007531fdbd8244  vmovaps [rsp+0x80], xmm8
00007531fdbd824d  vmovaps [rsp+0x90], xmm9
00007531fdbd8256  vmovaps [rsp+0xA0], xmm11
00007531fdbd825f  vmovaps [rsp+0xB0], xmm12
00007531fdbd8268  vmovaps [rsp+0xC0], xmm13
00007531fdbd8271  vmovaps [rsp+0xD0], xmm14
00007531fdbd827a  vmovaps [rsp+0xE0], xmm15
00007531fdbd8283  sub rsp, 0x30
00007531fdbd8287  movaps [rsp], xmm10
00007531fdbd828c  movaps [rsp+0x10], xmm11
00007531fdbd8292  movaps [rsp+0x20], xmm13
00007531fdbd8298  lea rdi, [rsp]
00007531fdbd829c  mov esi, 0x00
00007531fdbd82a1  mov rax, 0x59ED111DF530
00007531fdbd82ab  call rax
00007531fdbd82ad  movaps xmm10, [rsp]
00007531fdbd82b2  add rsp, 0x30
00007531fdbd82b6  vmovaps xmm0, [rsp]
00007531fdbd82bb  vmovaps xmm1, [rsp+0x10]
00007531fdbd82c1  vmovaps xmm2, [rsp+0x20]
00007531fdbd82c7  vmovaps xmm3, [rsp+0x30]
00007531fdbd82cd  vmovaps xmm4, [rsp+0x40]
00007531fdbd82d3  vmovaps xmm5, [rsp+0x50]
00007531fdbd82d9  vmovaps xmm6, [rsp+0x60]
00007531fdbd82df  vmovaps xmm7, [rsp+0x70]
00007531fdbd82e5  vmovaps xmm8, [rsp+0x80]
00007531fdbd82ee  vmovaps xmm9, [rsp+0x90]
00007531fdbd82f7  vmovaps xmm11, [rsp+0xA0]
00007531fdbd8300  vmovaps xmm12, [rsp+0xB0]
00007531fdbd8309  vmovaps xmm13, [rsp+0xC0]
00007531fdbd8312  vmovaps xmm14, [rsp+0xD0]
00007531fdbd831b  vmovaps xmm15, [rsp+0xE0]
00007531fdbd8324  add rsp, 0xF0
00007531fdbd832b  pop r11
00007531fdbd832d  pop r10
00007531fdbd832f  pop r9
00007531fdbd8331  pop r8
00007531fdbd8333  pop rsi
00007531fdbd8334  pop rdi
00007531fdbd8335  pop rdx
00007531fdbd8336  pop rcx
00007531fdbd8337  pop rax
00007531fdbd8338  add rsp, 0x08
00007531fdbd833c  jmp 0x00007531FDBD34C6
00007531fdbd8341  sub rsp, 0x08
00007531fdbd8345  push rax
00007531fdbd8346  push rcx
00007531fdbd8347  push rdx
00007531fdbd8348  push rdi
00007531fdbd8349  push rsi
00007531fdbd834a  push r8
00007531fdbd834c  push r9
00007531fdbd834e  push r10
00007531fdbd8350  push r11
00007531fdbd8352  sub rsp, 0xF0
00007531fdbd8359  vmovaps [rsp], xmm0
00007531fdbd835e  vmovaps [rsp+0x10], xmm1
00007531fdbd8364  vmovaps [rsp+0x20], xmm2
00007531fdbd836a  vmovaps [rsp+0x30], xmm3
00007531fdbd8370  vmovaps [rsp+0x40], xmm4
00007531fdbd8376  vmovaps [rsp+0x50], xmm5
00007531fdbd837c  vmovaps [rsp+0x60], xmm6
00007531fdbd8382  vmovaps [rsp+0x70], xmm7
00007531fdbd8388  vmovaps [rsp+0x80], xmm8
00007531fdbd8391  vmovaps [rsp+0x90], xmm9
00007531fdbd839a  vmovaps [rsp+0xA0], xmm10
00007531fdbd83a3  vmovaps [rsp+0xB0], xmm12
00007531fdbd83ac  vmovaps [rsp+0xC0], xmm13
00007531fdbd83b5  vmovaps [rsp+0xD0], xmm14
00007531fdbd83be  vmovaps [rsp+0xE0], xmm15
00007531fdbd83c7  sub rsp, 0x30
00007531fdbd83cb  movaps [rsp], xmm11
00007531fdbd83d0  movaps [rsp+0x10], xmm14
00007531fdbd83d6  movaps [rsp+0x20], xmm13
00007531fdbd83dc  lea rdi, [rsp]
00007531fdbd83e0  mov esi, 0x00
00007531fdbd83e5  mov rax, 0x59ED111DF530
00007531fdbd83ef  call rax
00007531fdbd83f1  movaps xmm11, [rsp]
00007531fdbd83f6  add rsp, 0x30
00007531fdbd83fa  vmovaps xmm0, [rsp]
00007531fdbd83ff  vmovaps xmm1, [rsp+0x10]
00007531fdbd8405  vmovaps xmm2, [rsp+0x20]
00007531fdbd840b  vmovaps xmm3, [rsp+0x30]
00007531fdbd8411  vmovaps xmm4, [rsp+0x40]
00007531fdbd8417  vmovaps xmm5, [rsp+0x50]
00007531fdbd841d  vmovaps xmm6, [rsp+0x60]
00007531fdbd8423  vmovaps xmm7, [rsp+0x70]
00007531fdbd8429  vmovaps xmm8, [rsp+0x80]
00007531fdbd8432  vmovaps xmm9, [rsp+0x90]
00007531fdbd843b  vmovaps xmm10, [rsp+0xA0]
00007531fdbd8444  vmovaps xmm12, [rsp+0xB0]
00007531fdbd844d  vmovaps xmm13, [rsp+0xC0]
00007531fdbd8456  vmovaps xmm14, [rsp+0xD0]
00007531fdbd845f  vmovaps xmm15, [rsp+0xE0]
00007531fdbd8468  add rsp, 0xF0
00007531fdbd846f  pop r11
00007531fdbd8471  pop r10
00007531fdbd8473  pop r9
00007531fdbd8475  pop r8
00007531fdbd8477  pop rsi
00007531fdbd8478  pop rdi
00007531fdbd8479  pop rdx
00007531fdbd847a  pop rcx
00007531fdbd847b  pop rax
00007531fdbd847c  add rsp, 0x08
00007531fdbd8480  jmp 0x00007531FDBD34F4
00007531fdbd8485  sub rsp, 0x08
00007531fdbd8489  push rax
00007531fdbd848a  push rcx
00007531fdbd848b  push rdx
00007531fdbd848c  push rdi
00007531fdbd848d  push rsi
00007531fdbd848e  push r8
00007531fdbd8490  push r9
00007531fdbd8492  push r10
00007531fdbd8494  push r11
00007531fdbd8496  sub rsp, 0xF0
00007531fdbd849d  vmovaps [rsp], xmm0
00007531fdbd84a2  vmovaps [rsp+0x10], xmm1
00007531fdbd84a8  vmovaps [rsp+0x20], xmm2
00007531fdbd84ae  vmovaps [rsp+0x30], xmm3
00007531fdbd84b4  vmovaps [rsp+0x40], xmm4
00007531fdbd84ba  vmovaps [rsp+0x50], xmm5
00007531fdbd84c0  vmovaps [rsp+0x60], xmm6
00007531fdbd84c6  vmovaps [rsp+0x70], xmm7
00007531fdbd84cc  vmovaps [rsp+0x80], xmm8
00007531fdbd84d5  vmovaps [rsp+0x90], xmm9
00007531fdbd84de  vmovaps [rsp+0xA0], xmm10
00007531fdbd84e7  vmovaps [rsp+0xB0], xmm11
00007531fdbd84f0  vmovaps [rsp+0xC0], xmm12
00007531fdbd84f9  vmovaps [rsp+0xD0], xmm13
00007531fdbd8502  vmovaps [rsp+0xE0], xmm15
00007531fdbd850b  sub rsp, 0x30
00007531fdbd850f  movaps [rsp], xmm14
00007531fdbd8514  movaps [rsp+0x10], xmm12
00007531fdbd851a  movaps [rsp+0x20], xmm9
00007531fdbd8520  lea rdi, [rsp]
00007531fdbd8524  mov esi, 0x00
00007531fdbd8529  mov rax, 0x59ED111DF530
00007531fdbd8533  call rax
00007531fdbd8535  movaps xmm14, [rsp]
00007531fdbd853a  add rsp, 0x30
00007531fdbd853e  vmovaps xmm0, [rsp]
00007531fdbd8543  vmovaps xmm1, [rsp+0x10]
00007531fdbd8549  vmovaps xmm2, [rsp+0x20]
00007531fdbd854f  vmovaps xmm3, [rsp+0x30]
00007531fdbd8555  vmovaps xmm4, [rsp+0x40]
00007531fdbd855b  vmovaps xmm5, [rsp+0x50]
00007531fdbd8561  vmovaps xmm6, [rsp+0x60]
00007531fdbd8567  vmovaps xmm7, [rsp+0x70]
00007531fdbd856d  vmovaps xmm8, [rsp+0x80]
00007531fdbd8576  vmovaps xmm9, [rsp+0x90]
00007531fdbd857f  vmovaps xmm10, [rsp+0xA0]
00007531fdbd8588  vmovaps xmm11, [rsp+0xB0]
00007531fdbd8591  vmovaps xmm12, [rsp+0xC0]
00007531fdbd859a  vmovaps xmm13, [rsp+0xD0]
00007531fdbd85a3  vmovaps xmm15, [rsp+0xE0]
00007531fdbd85ac  add rsp, 0xF0
00007531fdbd85b3  pop r11
00007531fdbd85b5  pop r10
00007531fdbd85b7  pop r9
00007531fdbd85b9  pop r8
00007531fdbd85bb  pop rsi
00007531fdbd85bc  pop rdi
00007531fdbd85bd  pop rdx
00007531fdbd85be  pop rcx
00007531fdbd85bf  pop rax
00007531fdbd85c0  add rsp, 0x08
00007531fdbd85c4  jmp 0x00007531FDBD350F
00007531fdbd85c9  sub rsp, 0x08
00007531fdbd85cd  push rax
00007531fdbd85ce  push rcx
00007531fdbd85cf  push rdx
00007531fdbd85d0  push rdi
00007531fdbd85d1  push rsi
00007531fdbd85d2  push r8
00007531fdbd85d4  push r9
00007531fdbd85d6  push r10
00007531fdbd85d8  push r11
00007531fdbd85da  sub rsp, 0xF0
00007531fdbd85e1  vmovaps [rsp], xmm0
00007531fdbd85e6  vmovaps [rsp+0x10], xmm1
00007531fdbd85ec  vmovaps [rsp+0x20], xmm2
00007531fdbd85f2  vmovaps [rsp+0x30], xmm3
00007531fdbd85f8  vmovaps [rsp+0x40], xmm4
00007531fdbd85fe  vmovaps [rsp+0x50], xmm5
00007531fdbd8604  vmovaps [rsp+0x60], xmm6
00007531fdbd860a  vmovaps [rsp+0x70], xmm7
00007531fdbd8610  vmovaps [rsp+0x80], xmm8
00007531fdbd8619  vmovaps [rsp+0x90], xmm9
00007531fdbd8622  vmovaps [rsp+0xA0], xmm10
00007531fdbd862b  vmovaps [rsp+0xB0], xmm11
00007531fdbd8634  vmovaps [rsp+0xC0], xmm12
00007531fdbd863d  vmovaps [rsp+0xD0], xmm14
00007531fdbd8646  vmovaps [rsp+0xE0], xmm15
00007531fdbd864f  sub rsp, 0x30
00007531fdbd8653  movaps [rsp], xmm13
00007531fdbd8658  movaps [rsp+0x10], xmm8
00007531fdbd865e  movaps [rsp+0x20], xmm15
00007531fdbd8664  lea rdi, [rsp]
00007531fdbd8668  mov esi, 0x00
00007531fdbd866d  mov rax, 0x59ED111DF530
00007531fdbd8677  call rax
00007531fdbd8679  movaps xmm13, [rsp]
00007531fdbd867e  add rsp, 0x30
00007531fdbd8682  vmovaps xmm0, [rsp]
00007531fdbd8687  vmovaps xmm1, [rsp+0x10]
00007531fdbd868d  vmovaps xmm2, [rsp+0x20]
00007531fdbd8693  vmovaps xmm3, [rsp+0x30]
00007531fdbd8699  vmovaps xmm4, [rsp+0x40]
00007531fdbd869f  vmovaps xmm5, [rsp+0x50]
00007531fdbd86a5  vmovaps xmm6, [rsp+0x60]
00007531fdbd86ab  vmovaps xmm7, [rsp+0x70]
00007531fdbd86b1  vmovaps xmm8, [rsp+0x80]
00007531fdbd86ba  vmovaps xmm9, [rsp+0x90]
00007531fdbd86c3  vmovaps xmm10, [rsp+0xA0]
00007531fdbd86cc  vmovaps xmm11, [rsp+0xB0]
00007531fdbd86d5  vmovaps xmm12, [rsp+0xC0]
00007531fdbd86de  vmovaps xmm14, [rsp+0xD0]
00007531fdbd86e7  vmovaps xmm15, [rsp+0xE0]
00007531fdbd86f0  add rsp, 0xF0
00007531fdbd86f7  pop r11
00007531fdbd86f9  pop r10
00007531fdbd86fb  pop r9
00007531fdbd86fd  pop r8
00007531fdbd86ff  pop rsi
00007531fdbd8700  pop rdi
00007531fdbd8701  pop rdx
00007531fdbd8702  pop rcx
00007531fdbd8703  pop rax
00007531fdbd8704  add rsp, 0x08
00007531fdbd8708  jmp 0x00007531FDBD3532
00007531fdbd870d  sub rsp, 0x08
00007531fdbd8711  push rax
00007531fdbd8712  push rcx
00007531fdbd8713  push rdx
00007531fdbd8714  push rdi
00007531fdbd8715  push rsi
00007531fdbd8716  push r8
00007531fdbd8718  push r9
00007531fdbd871a  push r10
00007531fdbd871c  push r11
00007531fdbd871e  sub rsp, 0xF0
00007531fdbd8725  vmovaps [rsp], xmm0
00007531fdbd872a  vmovaps [rsp+0x10], xmm1
00007531fdbd8730  vmovaps [rsp+0x20], xmm2
00007531fdbd8736  vmovaps [rsp+0x30], xmm3
00007531fdbd873c  vmovaps [rsp+0x40], xmm4
00007531fdbd8742  vmovaps [rsp+0x50], xmm5
00007531fdbd8748  vmovaps [rsp+0x60], xmm6
00007531fdbd874e  vmovaps [rsp+0x70], xmm7
00007531fdbd8754  vmovaps [rsp+0x80], xmm8
00007531fdbd875d  vmovaps [rsp+0x90], xmm9
00007531fdbd8766  vmovaps [rsp+0xA0], xmm10
00007531fdbd876f  vmovaps [rsp+0xB0], xmm11
00007531fdbd8778  vmovaps [rsp+0xC0], xmm12
00007531fdbd8781  vmovaps [rsp+0xD0], xmm13
00007531fdbd878a  vmovaps [rsp+0xE0], xmm14
00007531fdbd8793  sub rsp, 0x30
00007531fdbd8797  movaps [rsp], xmm15
00007531fdbd879c  movaps [rsp+0x10], xmm1
00007531fdbd87a1  movaps [rsp+0x20], xmm10
00007531fdbd87a7  lea rdi, [rsp]
00007531fdbd87ab  mov esi, 0x00
00007531fdbd87b0  mov rax, 0x59ED111DF530
00007531fdbd87ba  call rax
00007531fdbd87bc  movaps xmm15, [rsp]
00007531fdbd87c1  add rsp, 0x30
00007531fdbd87c5  vmovaps xmm0, [rsp]
00007531fdbd87ca  vmovaps xmm1, [rsp+0x10]
00007531fdbd87d0  vmovaps xmm2, [rsp+0x20]
00007531fdbd87d6  vmovaps xmm3, [rsp+0x30]
00007531fdbd87dc  vmovaps xmm4, [rsp+0x40]
00007531fdbd87e2  vmovaps xmm5, [rsp+0x50]
00007531fdbd87e8  vmovaps xmm6, [rsp+0x60]
00007531fdbd87ee  vmovaps xmm7, [rsp+0x70]
00007531fdbd87f4  vmovaps xmm8, [rsp+0x80]
00007531fdbd87fd  vmovaps xmm9, [rsp+0x90]
00007531fdbd8806  vmovaps xmm10, [rsp+0xA0]
00007531fdbd880f  vmovaps xmm11, [rsp+0xB0]
00007531fdbd8818  vmovaps xmm12, [rsp+0xC0]
00007531fdbd8821  vmovaps xmm13, [rsp+0xD0]
00007531fdbd882a  vmovaps xmm14, [rsp+0xE0]
00007531fdbd8833  add rsp, 0xF0
00007531fdbd883a  pop r11
00007531fdbd883c  pop r10
00007531fdbd883e  pop r9
00007531fdbd8840  pop r8
00007531fdbd8842  pop rsi
00007531fdbd8843  pop rdi
00007531fdbd8844  pop rdx
00007531fdbd8845  pop rcx
00007531fdbd8846  pop rax
00007531fdbd8847  add rsp, 0x08
00007531fdbd884b  jmp 0x00007531FDBD3555
00007531fdbd8850  sub rsp, 0x08
00007531fdbd8854  push rax
00007531fdbd8855  push rcx
00007531fdbd8856  push rdx
00007531fdbd8857  push rdi
00007531fdbd8858  push rsi
00007531fdbd8859  push r8
00007531fdbd885b  push r9
00007531fdbd885d  push r10
00007531fdbd885f  push r11
00007531fdbd8861  sub rsp, 0xF0
00007531fdbd8868  vmovaps [rsp], xmm0
00007531fdbd886d  vmovaps [rsp+0x10], xmm2
00007531fdbd8873  vmovaps [rsp+0x20], xmm3
00007531fdbd8879  vmovaps [rsp+0x30], xmm4
00007531fdbd887f  vmovaps [rsp+0x40], xmm5
00007531fdbd8885  vmovaps [rsp+0x50], xmm6
00007531fdbd888b  vmovaps [rsp+0x60], xmm7
00007531fdbd8891  vmovaps [rsp+0x70], xmm8
00007531fdbd8897  vmovaps [rsp+0x80], xmm9
00007531fdbd88a0  vmovaps [rsp+0x90], xmm10
00007531fdbd88a9  vmovaps [rsp+0xA0], xmm11
00007531fdbd88b2  vmovaps [rsp+0xB0], xmm12
00007531fdbd88bb  vmovaps [rsp+0xC0], xmm13
00007531fdbd88c4  vmovaps [rsp+0xD0], xmm14
00007531fdbd88cd  vmovaps [rsp+0xE0], xmm15
00007531fdbd88d6  sub rsp, 0x30
00007531fdbd88da  movaps [rsp], xmm1
00007531fdbd88de  movaps [rsp+0x10], xmm7
00007531fdbd88e3  movaps [rsp+0x20], xmm11
00007531fdbd88e9  lea rdi, [rsp]
00007531fdbd88ed  mov esi, 0x00
00007531fdbd88f2  mov rax, 0x59ED111DF530
00007531fdbd88fc  call rax
00007531fdbd88fe  movaps xmm1, [rsp]
00007531fdbd8902  add rsp, 0x30
00007531fdbd8906  vmovaps xmm0, [rsp]
00007531fdbd890b  vmovaps xmm2, [rsp+0x10]
00007531fdbd8911  vmovaps xmm3, [rsp+0x20]
00007531fdbd8917  vmovaps xmm4, [rsp+0x30]
00007531fdbd891d  vmovaps xmm5, [rsp+0x40]
00007531fdbd8923  vmovaps xmm6, [rsp+0x50]
00007531fdbd8929  vmovaps xmm7, [rsp+0x60]
00007531fdbd892f  vmovaps xmm8, [rsp+0x70]
00007531fdbd8935  vmovaps xmm9, [rsp+0x80]
00007531fdbd893e  vmovaps xmm10, [rsp+0x90]
00007531fdbd8947  vmovaps xmm11, [rsp+0xA0]
00007531fdbd8950  vmovaps xmm12, [rsp+0xB0]
00007531fdbd8959  vmovaps xmm13, [rsp+0xC0]
00007531fdbd8962  vmovaps xmm14, [rsp+0xD0]
00007531fdbd896b  vmovaps xmm15, [rsp+0xE0]
00007531fdbd8974  add rsp, 0xF0
00007531fdbd897b  pop r11
00007531fdbd897d  pop r10
00007531fdbd897f  pop r9
00007531fdbd8981  pop r8
00007531fdbd8983  pop rsi
00007531fdbd8984  pop rdi
00007531fdbd8985  pop rdx
00007531fdbd8986  pop rcx
00007531fdbd8987  pop rax
00007531fdbd8988  add rsp, 0x08
00007531fdbd898c  jmp 0x00007531FDBD3576
00007531fdbd8991  call 0x00007531FDA0D600
00007531fdbd8996  jmp 0x00007531FDBD3589
00007531fdbd899b  call 0x00007531FDA0C380
00007531fdbd89a0  jmp 0x00007531FDBD3594
00007531fdbd89a5  call 0x00007531FDA0E880
00007531fdbd89aa  jmp 0x00007531FDBD359F
00007531fdbd89af  call 0x00007531FD9FF540
00007531fdbd89b4  jmp 0x00007531FDBD35AA
00007531fdbd89b9  int3
00007531fdbd89ba  nop [rax+rax*1], ax
00007531fdbd89c0  mov rax, [r15+0x40]
00007531fdbd89c4  mov r14, [r15+0x58]
00007531fdbd89c8  lea r12, [rax+r14*1]
00007531fdbd89cc  movaps xmm1, [r15+0x1D0]
00007531fdbd89d4  vmovaps [rsp+0x10], xmm1
00007531fdbd89da  vmovaps xmm15, [rsp+0x10]
00007531fdbd89e0  por xmm1, xmm15
00007531fdbd89e5  movaps xmm14, [r15+0x1A0]
00007531fdbd89ed  vmovaps [rsp+0x10], xmm14
00007531fdbd89f3  vmovaps xmm13, [rsp+0x10]
00007531fdbd89f9  por xmm14, xmm13
00007531fdbd89fe  lea rax, [r12+0x30]
00007531fdbd8a03  mov r11, [r13+rax*1]
00007531fdbd8a08  lea rax, [r12+0x38]
00007531fdbd8a0d  mov r10, [r13+rax*1]
00007531fdbd8a12  movq xmm13, r11
00007531fdbd8a17  movq xmm12, r10
00007531fdbd8a1c  movq xmm13, xmm13
00007531fdbd8a21  vmovaps [rsp+0x10], xmm13
00007531fdbd8a27  movq xmm13, xmm13
00007531fdbd8a2c  movaps [r15+0x130], xmm13
00007531fdbd8a34  movq xmm12, xmm12
00007531fdbd8a39  vmovaps [rsp+0x20], xmm12
00007531fdbd8a3f  movq xmm12, xmm12
00007531fdbd8a44  movaps [r15+0x280], xmm12
00007531fdbd8a4c  movaps xmm13, [r15+0x270]
00007531fdbd8a54  vmovaps [rsp+0x30], xmm13
00007531fdbd8a5a  vmovaps xmm12, [rsp+0x30]
00007531fdbd8a60  por xmm13, xmm12
00007531fdbd8a65  lea rax, [r12+0x20]
00007531fdbd8a6a  mov r11, [r13+rax*1]
00007531fdbd8a6f  lea rax, [r12+0x28]
00007531fdbd8a74  mov r10, [r13+rax*1]
00007531fdbd8a79  movq xmm12, r11
00007531fdbd8a7e  movq xmm11, r10
00007531fdbd8a83  movq xmm12, xmm12
00007531fdbd8a88  vmovaps [rsp+0x30], xmm12
00007531fdbd8a8e  movq xmm12, xmm12
00007531fdbd8a93  movaps [r15+0x150], xmm12
00007531fdbd8a9b  movq xmm11, xmm11
00007531fdbd8aa0  vmovaps [rsp+0x40], xmm11
00007531fdbd8aa6  movq xmm11, xmm11
00007531fdbd8aab  movaps [r15+0x140], xmm11
00007531fdbd8ab3  lea rax, [r12+0x10]
00007531fdbd8ab8  mov r11, [r13+rax*1]
00007531fdbd8abd  lea rax, [r12+0x18]
00007531fdbd8ac2  mov r10, [r13+rax*1]
00007531fdbd8ac7  movq xmm12, r11
00007531fdbd8acc  movq xmm11, r10
00007531fdbd8ad1  movq xmm12, xmm12
00007531fdbd8ad6  vmovaps [rsp+0x50], xmm12
00007531fdbd8adc  movq xmm12, xmm12
00007531fdbd8ae1  movaps [r15+0x170], xmm12
00007531fdbd8ae9  movq xmm11, xmm11
00007531fdbd8aee  vmovaps [rsp+0x60], xmm11
00007531fdbd8af4  movq xmm11, xmm11
00007531fdbd8af9  movaps [r15+0x160], xmm11
00007531fdbd8b01  mov rax, [r13+r12*1]
00007531fdbd8b06  vmovq xmm12, rax
00007531fdbd8b0b  vpbroadcastq xmm12, xmm12
00007531fdbd8b10  lea rax, [r12+0x08]
00007531fdbd8b15  mov r12, [r13+rax*1]
00007531fdbd8b1a  movq xmm11, r12
00007531fdbd8b1f  movaps [r15+0x230], xmm11
00007531fdbd8b27  mov rax, [r15+0xF8]
00007531fdbd8b2e  lea r12, [rax+0x50]
00007531fdbd8b32  movups xmm11, [r13+r12*1]
00007531fdbd8b38  lea r12, [rax+0x60]
00007531fdbd8b3c  movups xmm10, [r13+r12*1]
00007531fdbd8b42  lea r12, [rax+0x30]
00007531fdbd8b46  movups xmm9, [r13+r12*1]
00007531fdbd8b4c  mov r12, [r15+0x50]
00007531fdbd8b50  lea r11, [r12+r14*1]
00007531fdbd8b54  mov [r15+0x60], r11
00007531fdbd8b58  lea r12, [r14+0x40]
00007531fdbd8b5c  mov [r15+0x58], r12
00007531fdbd8b60  movaps xmm8, xmm12
00007531fdbd8b64  mulpd xmm8, xmm15
00007531fdbd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007531fdbd8b6f  ptest xmm7, xmm7
00007531fdbd8b74  jnz 0x00007531FDBD9997
00007531fdbd8b7a  movq xmm15, qword ptr [r15+0x230]
00007531fdbd8b83  vmovaps [rsp+0x70], xmm15
00007531fdbd8b89  vpermilpd xmm15, xmm15, 0x00
00007531fdbd8b8f  movaps xmm7, xmm9
00007531fdbd8b93  mulpd xmm7, xmm15
00007531fdbd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007531fdbd8b9d  ptest xmm6, xmm6
00007531fdbd8ba2  jnz 0x00007531FDBD9ADB
00007531fdbd8ba8  vxorps xmm15, xmm15, xmm15
00007531fdbd8bad  vpbroadcastq xmm15, xmm15
00007531fdbd8bb2  movaps xmm9, xmm12
00007531fdbd8bb6  mulpd xmm9, xmm10
00007531fdbd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007531fdbd8bc1  ptest xmm6, xmm6
00007531fdbd8bc6  jnz 0x00007531FDBD9C1D
00007531fdbd8bcc  movaps xmm10, xmm12
00007531fdbd8bd0  mulpd xmm10, xmm11
00007531fdbd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007531fdbd8bdb  ptest xmm6, xmm6
00007531fdbd8be0  jnz 0x00007531FDBD9D61
00007531fdbd8be6  movaps xmm11, [r15+0x1F0]
00007531fdbd8bee  movaps xmm6, xmm12
00007531fdbd8bf2  mulpd xmm6, xmm11
00007531fdbd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007531fdbd8bfc  ptest xmm5, xmm5
00007531fdbd8c01  jnz 0x00007531FDBD9EA5
00007531fdbd8c07  movaps xmm12, [r15+0x2A0]
00007531fdbd8c0f  vmovaps [rsp+0x80], xmm12
00007531fdbd8c18  vmovaps xmm11, [rsp+0x80]
00007531fdbd8c21  por xmm12, xmm11
00007531fdbd8c26  movaps xmm11, [r15+0x250]
00007531fdbd8c2e  vmovaps [rsp+0x80], xmm11
00007531fdbd8c37  vmovaps xmm5, [rsp+0x80]
00007531fdbd8c40  por xmm11, xmm5
00007531fdbd8c45  vmovaps xmm4, [rsp+0x70]
00007531fdbd8c4b  vpermilpd xmm4, xmm4, 0x00
00007531fdbd8c51  movaps xmm3, xmm5
00007531fdbd8c54  mulpd xmm3, xmm4
00007531fdbd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007531fdbd8c5d  ptest xmm2, xmm2
00007531fdbd8c62  jnz 0x00007531FDBD9FE7
00007531fdbd8c68  mov [rsp+0x80], rax
00007531fdbd8c70  xor eax, eax
00007531fdbd8c72  mov r14d, 0x200
00007531fdbd8c78  cmp r12, r14
00007531fdbd8c7b  cmc
00007531fdbd8c7c  lahf
00007531fdbd8c7d  seto al
00007531fdbd8c80  mov [r15+0x108], eax
00007531fdbd8c87  movaps xmm5, xmm8
00007531fdbd8c8b  addpd xmm5, xmm15
00007531fdbd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007531fdbd8c95  ptest xmm4, xmm4
00007531fdbd8c9a  jnz 0x00007531FDBDA127
00007531fdbd8ca0  movaps xmm8, [r15+0x1B0]
00007531fdbd8ca8  movaps xmm4, xmm9
00007531fdbd8cac  addpd xmm4, xmm8
00007531fdbd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007531fdbd8cb6  ptest xmm2, xmm2
00007531fdbd8cbb  jnz 0x00007531FDBDA269
00007531fdbd8cc1  movaps xmm9, xmm10
00007531fdbd8cc5  addpd xmm9, xmm8
00007531fdbd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007531fdbd8cd0  ptest xmm2, xmm2
00007531fdbd8cd5  jnz 0x00007531FDBDA3AB
00007531fdbd8cdb  movaps xmm10, [r15+0x2F0]
00007531fdbd8ce3  vmovaps [rsp+0x90], xmm10
00007531fdbd8cec  vmovaps xmm8, [rsp+0x90]
00007531fdbd8cf5  por xmm10, xmm8
00007531fdbd8cfa  movaps xmm8, [r15+0x2E0]
00007531fdbd8d02  vmovaps [rsp+0x90], xmm8
00007531fdbd8d0b  vmovaps xmm2, [rsp+0x90]
00007531fdbd8d14  por xmm8, xmm2
00007531fdbd8d19  movaps xmm2, [r15+0x2D0]
00007531fdbd8d21  vmovaps [rsp+0x90], xmm2
00007531fdbd8d2a  vmovaps [rsp+0xA0], xmm1
00007531fdbd8d33  vmovaps xmm1, [rsp+0x90]
00007531fdbd8d3c  por xmm2, xmm1
00007531fdbd8d40  movaps xmm1, [r15+0x200]
00007531fdbd8d48  vmovaps [rsp+0x90], xmm1
00007531fdbd8d51  vmovaps [rsp+0xB0], xmm15
00007531fdbd8d5a  vmovaps xmm15, [rsp+0x90]
00007531fdbd8d63  por xmm1, xmm15
00007531fdbd8d68  movaps xmm15, [r15+0x1C0]
00007531fdbd8d70  vmovaps [rsp+0x90], xmm15
00007531fdbd8d79  vmovaps [rsp+0xC0], xmm1
00007531fdbd8d82  vmovaps xmm1, [rsp+0x90]
00007531fdbd8d8b  por xmm15, xmm1
00007531fdbd8d90  movaps xmm1, [r15+0x190]
00007531fdbd8d98  vmovaps [rsp+0x90], xmm1
00007531fdbd8da1  vmovaps [rsp+0xD0], xmm15
00007531fdbd8daa  vmovaps xmm15, [rsp+0x90]
00007531fdbd8db3  por xmm1, xmm15
00007531fdbd8db8  movaps xmm15, [r15+0x300]
00007531fdbd8dc0  vmovaps [rsp+0x90], xmm15
00007531fdbd8dc9  vmovaps [rsp+0xE0], xmm1
00007531fdbd8dd2  vmovaps xmm1, [rsp+0x90]
00007531fdbd8ddb  por xmm15, xmm1
00007531fdbd8de0  mov rax, [rsp+0x80]
00007531fdbd8de8  lea r14, [rax+0xA0]
00007531fdbd8def  movups xmm1, [r13+r14*1]
00007531fdbd8df5  lea r14, [rax+0xB0]
00007531fdbd8dfc  vmovaps [rsp+0x80], xmm1
00007531fdbd8e05  movups xmm1, [r13+r14*1]
00007531fdbd8e0b  vmovaps [rsp+0x90], xmm1
00007531fdbd8e14  vmovaps [rsp+0xF0], xmm15
00007531fdbd8e1d  vmovaps xmm15, [rsp+0xB0]
00007531fdbd8e26  vmovaps [rsp+0xB0], xmm14
00007531fdbd8e2f  movaps xmm1, xmm6
00007531fdbd8e32  addpd xmm1, xmm15
00007531fdbd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007531fdbd8e3c  ptest xmm14, xmm14
00007531fdbd8e42  jnz 0x00007531FDBDA503
00007531fdbd8e48  lea r14, [rax+0xF0]
00007531fdbd8e4f  movups xmm15, [r13+r14*1]
00007531fdbd8e55  movaps xmm14, xmm4
00007531fdbd8e59  addpd xmm14, xmm3
00007531fdbd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007531fdbd8e64  ptest xmm6, xmm6
00007531fdbd8e69  jnz 0x00007531FDBDA64E
00007531fdbd8e6f  movaps xmm6, xmm9
00007531fdbd8e73  addpd xmm6, xmm7
00007531fdbd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007531fdbd8e7c  ptest xmm4, xmm4
00007531fdbd8e81  jnz 0x00007531FDBDA790
00007531fdbd8e87  vmovaps xmm9, [rsp+0x70]
00007531fdbd8e8d  vpermilpd xmm9, xmm9, 0x00
00007531fdbd8e93  vmovaps xmm4, [rsp+0x90]
00007531fdbd8e9c  movaps xmm7, xmm4
00007531fdbd8e9f  mulpd xmm7, xmm9
00007531fdbd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007531fdbd8ea9  ptest xmm3, xmm3
00007531fdbd8eae  jnz 0x00007531FDBDA8D1
00007531fdbd8eb4  vmovaps xmm9, [rsp+0x50]
00007531fdbd8eba  vpermilpd xmm9, xmm9, 0x00
00007531fdbd8ec0  movaps xmm4, xmm15
00007531fdbd8ec4  mulpd xmm4, xmm9
00007531fdbd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007531fdbd8ece  ptest xmm3, xmm3
00007531fdbd8ed3  jnz 0x00007531FDBDAA12
00007531fdbd8ed9  lea r14, [rax+0xE0]
00007531fdbd8ee0  movups xmm15, [r13+r14*1]
00007531fdbd8ee6  vmovaps xmm9, [rsp+0x70]
00007531fdbd8eec  vpermilpd xmm9, xmm9, 0x00
00007531fdbd8ef2  vmovaps [rsp+0x70], xmm1
00007531fdbd8ef8  vmovaps xmm1, [rsp+0x80]
00007531fdbd8f01  vmovaps [rsp+0x80], xmm15
00007531fdbd8f0a  movaps xmm3, xmm1
00007531fdbd8f0d  mulpd xmm3, xmm9
00007531fdbd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007531fdbd8f17  ptest xmm15, xmm15
00007531fdbd8f1d  jnz 0x00007531FDBDAB5E
00007531fdbd8f23  vmovaps xmm1, [rsp+0xF0]
00007531fdbd8f2c  vmovaps xmm15, [rsp+0xF0]
00007531fdbd8f35  por xmm1, xmm15
00007531fdbd8f3a  movaps [r15+0x300], xmm1
00007531fdbd8f42  vmovaps xmm15, [rsp+0xE0]
00007531fdbd8f4b  vmovaps xmm9, [rsp+0xE0]
00007531fdbd8f54  por xmm15, xmm9
00007531fdbd8f59  movaps [r15+0x190], xmm15
00007531fdbd8f61  vmovaps xmm9, [rsp+0x50]
00007531fdbd8f67  vpermilpd xmm9, xmm9, 0x00
00007531fdbd8f6d  vmovaps [rsp+0x90], xmm1
00007531fdbd8f76  vmovaps [rsp+0xE0], xmm15
00007531fdbd8f7f  vmovaps xmm15, [rsp+0x80]
00007531fdbd8f88  vmovaps [rsp+0x80], xmm14
00007531fdbd8f91  movaps xmm1, xmm15
00007531fdbd8f95  mulpd xmm1, xmm9
00007531fdbd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007531fdbd8f9f  ptest xmm14, xmm14
00007531fdbd8fa5  jnz 0x00007531FDBDAC9F
00007531fdbd8fab  lea r14, [rax+0x90]
00007531fdbd8fb2  movups xmm15, [r13+r14*1]
00007531fdbd8fb8  vmovaps xmm14, [rsp+0xD0]
00007531fdbd8fc1  vmovaps xmm9, [rsp+0xD0]
00007531fdbd8fca  por xmm14, xmm9
00007531fdbd8fcf  movaps [r15+0x1C0], xmm14
00007531fdbd8fd7  vmovaps xmm9, [rsp+0xC0]
00007531fdbd8fe0  vmovaps [rsp+0xD0], xmm1
00007531fdbd8fe9  vmovaps xmm1, [rsp+0xC0]
00007531fdbd8ff2  por xmm9, xmm1
00007531fdbd8ff7  movaps [r15+0x200], xmm9
00007531fdbd8fff  vmovaps [rsp+0xC0], xmm2
00007531fdbd9008  vmovaps xmm1, [rsp+0xC0]
00007531fdbd9011  por xmm2, xmm1
00007531fdbd9015  movaps [r15+0x2D0], xmm2
00007531fdbd901d  vmovaps [rsp+0xC0], xmm8
00007531fdbd9026  vmovaps xmm1, [rsp+0xC0]
00007531fdbd902f  por xmm8, xmm1
00007531fdbd9034  movaps [r15+0x2E0], xmm8
00007531fdbd903c  vmovaps [rsp+0xC0], xmm15
00007531fdbd9045  movaps xmm1, xmm5
00007531fdbd9048  addpd xmm1, xmm7
00007531fdbd904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007531fdbd9051  ptest xmm15, xmm15
00007531fdbd9057  jnz 0x00007531FDBDADEB
00007531fdbd905d  vmovaps xmm15, [rsp+0x50]
00007531fdbd9063  vpermilpd xmm15, xmm15, 0x00
00007531fdbd9069  vmovaps xmm5, [rsp+0xC0]
00007531fdbd9072  vmovaps [rsp+0xC0], xmm1
00007531fdbd907b  movaps xmm7, xmm5
00007531fdbd907e  mulpd xmm7, xmm15
00007531fdbd9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007531fdbd9088  ptest xmm1, xmm1
00007531fdbd908d  jnz 0x00007531FDBDAF2B
00007531fdbd9093  lea r14, [rax+0x80]
00007531fdbd909a  movups xmm1, [r13+r14*1]
00007531fdbd90a0  vmovaps xmm5, [rsp+0x70]
00007531fdbd90a6  vmovaps [rsp+0x70], xmm1
00007531fdbd90ac  movaps xmm15, xmm5
00007531fdbd90b0  addpd xmm15, xmm3
00007531fdbd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007531fdbd90bb  ptest xmm1, xmm1
00007531fdbd90c0  jnz 0x00007531FDBDB076
00007531fdbd90c6  vmovaps xmm5, [rsp+0x80]
00007531fdbd90cf  movaps xmm1, xmm5
00007531fdbd90d2  addpd xmm1, xmm4
00007531fdbd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007531fdbd90db  ptest xmm3, xmm3
00007531fdbd90e0  jnz 0x00007531FDBDB1B8
00007531fdbd90e6  vmovaps [rsp+0x80], xmm10
00007531fdbd90ef  vmovaps xmm5, [rsp+0x80]
00007531fdbd90f8  por xmm10, xmm5
00007531fdbd90fd  movaps [r15+0x2F0], xmm10
00007531fdbd9105  vmovaps xmm5, [rsp+0x50]
00007531fdbd910b  vpermilpd xmm5, xmm5, 0x00
00007531fdbd9111  vmovaps xmm3, [rsp+0x70]
00007531fdbd9117  vmovaps [rsp+0x50], xmm1
00007531fdbd911d  movaps xmm4, xmm3
00007531fdbd9120  mulpd xmm4, xmm5
00007531fdbd9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007531fdbd9129  ptest xmm1, xmm1
00007531fdbd912e  jnz 0x00007531FDBDB2F8
00007531fdbd9134  lea r14, [rax+0xD0]
00007531fdbd913b  movups xmm1, [r13+r14*1]
00007531fdbd9141  vmovaps xmm3, [rsp+0xD0]
00007531fdbd914a  vmovaps [rsp+0x70], xmm1
00007531fdbd9150  movaps xmm5, xmm6
00007531fdbd9153  addpd xmm5, xmm3
00007531fdbd9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007531fdbd915c  ptest xmm1, xmm1
00007531fdbd9161  jnz 0x00007531FDBDB442
00007531fdbd9167  vmovaps xmm1, [rsp+0x60]
00007531fdbd916d  vpermilpd xmm1, xmm1, 0x00
00007531fdbd9173  movaps xmm6, xmm9
00007531fdbd9177  mulpd xmm6, xmm1
00007531fdbd917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007531fdbd9180  ptest xmm3, xmm3
00007531fdbd9185  jnz 0x00007531FDBDB582
00007531fdbd918b  movaps [r15+0x260], xmm6
00007531fdbd9193  vxorps xmm1, xmm1, xmm1
00007531fdbd9197  vpbroadcastq xmm1, xmm1
00007531fdbd919c  movaps [r15+0x1B0], xmm1
00007531fdbd91a4  vmovaps xmm1, [rsp+0x60]
00007531fdbd91aa  vpermilpd xmm1, xmm1, 0x00
00007531fdbd91b0  vmovaps xmm3, [rsp+0x70]
00007531fdbd91b6  vmovaps [rsp+0x70], xmm15
00007531fdbd91bc  movaps xmm9, xmm3
00007531fdbd91c0  mulpd xmm9, xmm1
00007531fdbd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007531fdbd91cb  ptest xmm15, xmm15
00007531fdbd91d1  jnz 0x00007531FDBDB6C3
00007531fdbd91d7  lea r14, [rax+0xC0]
00007531fdbd91de  movups xmm1, [r13+r14*1]
00007531fdbd91e4  vmovaps xmm3, [rsp+0xC0]
00007531fdbd91ed  vmovaps [rsp+0x80], xmm1
00007531fdbd91f6  movaps xmm15, xmm3
00007531fdbd91fa  addpd xmm15, xmm7
00007531fdbd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007531fdbd9205  ptest xmm1, xmm1
00007531fdbd920a  jnz 0x00007531FDBDB80F
00007531fdbd9210  vmovaps [rsp+0xC0], xmm13
00007531fdbd9219  vmovaps xmm1, [rsp+0xC0]
00007531fdbd9222  por xmm13, xmm1
00007531fdbd9227  movaps [r15+0x270], xmm13
00007531fdbd922f  vmovaps xmm1, [rsp+0xB0]
00007531fdbd9238  vmovaps xmm7, [rsp+0xB0]
00007531fdbd9241  por xmm1, xmm7
00007531fdbd9245  movaps [r15+0x1A0], xmm1
00007531fdbd924d  vmovaps xmm1, [rsp+0x60]
00007531fdbd9253  vpermilpd xmm1, xmm1, 0x00
00007531fdbd9259  vmovaps [rsp+0xB0], xmm1
00007531fdbd9262  vmovaps xmm1, [rsp+0x80]
00007531fdbd926b  vmovaps [rsp+0x80], xmm15
00007531fdbd9274  vmovaps xmm15, [rsp+0xB0]
00007531fdbd927d  vmovaps [rsp+0xB0], xmm14
00007531fdbd9286  movaps xmm3, xmm1
00007531fdbd9289  mulpd xmm3, xmm15
00007531fdbd928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007531fdbd9293  ptest xmm14, xmm14
00007531fdbd9299  jnz 0x00007531FDBDB951
00007531fdbd929f  lea r14, [rax+0x20]
00007531fdbd92a3  movups xmm1, [r13+r14*1]
00007531fdbd92a9  movaps [r15+0x110], xmm1
00007531fdbd92b1  vmovaps xmm14, [rsp+0x70]
00007531fdbd92b7  vmovaps [rsp+0x70], xmm1
00007531fdbd92bd  movaps xmm15, xmm14
00007531fdbd92c1  addpd xmm15, xmm4
00007531fdbd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007531fdbd92cc  ptest xmm1, xmm1
00007531fdbd92d1  jnz 0x00007531FDBDBA9C
00007531fdbd92d7  vmovaps xmm1, [rsp+0x60]
00007531fdbd92dd  vpermilpd xmm1, xmm1, 0x00
00007531fdbd92e3  movaps xmm14, xmm2
00007531fdbd92e7  mulpd xmm14, xmm1
00007531fdbd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007531fdbd92f2  ptest xmm4, xmm4
00007531fdbd92f7  jnz 0x00007531FDBDBBDF
00007531fdbd92fd  vmovaps xmm4, [rsp+0x50]
00007531fdbd9303  movaps xmm1, xmm4
00007531fdbd9306  addpd xmm1, xmm9
00007531fdbd930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007531fdbd9310  ptest xmm2, xmm2
00007531fdbd9315  jnz 0x00007531FDBDBD21
00007531fdbd931b  vmovaps xmm9, [rsp+0x30]
00007531fdbd9321  vpermilpd xmm9, xmm9, 0x00
00007531fdbd9327  vmovaps xmm2, [rsp+0x70]
00007531fdbd932d  vmovaps [rsp+0x50], xmm1
00007531fdbd9333  movaps xmm4, xmm2
00007531fdbd9336  mulpd xmm4, xmm9
00007531fdbd933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007531fdbd9340  ptest xmm1, xmm1
00007531fdbd9345  jnz 0x00007531FDBDBE62
00007531fdbd934b  vmovaps xmm1, [rsp+0x30]
00007531fdbd9351  vpermilpd xmm1, xmm1, 0x00
00007531fdbd9357  vmovaps xmm2, [rsp+0x90]
00007531fdbd9360  vmovaps [rsp+0x60], xmm15
00007531fdbd9366  movaps xmm9, xmm2
00007531fdbd936a  mulpd xmm9, xmm1
00007531fdbd936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007531fdbd9375  ptest xmm15, xmm15
00007531fdbd937b  jnz 0x00007531FDBDBFA3
00007531fdbd9381  vmovaps xmm15, [rsp+0x80]
00007531fdbd938a  movaps xmm1, xmm15
00007531fdbd938e  addpd xmm1, xmm6
00007531fdbd9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007531fdbd9397  ptest xmm2, xmm2
00007531fdbd939c  jnz 0x00007531FDBDC0E5
00007531fdbd93a2  movaps xmm15, xmm5
00007531fdbd93a6  addpd xmm15, xmm3
00007531fdbd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007531fdbd93b1  ptest xmm6, xmm6
00007531fdbd93b6  jnz 0x00007531FDBDC226
00007531fdbd93bc  vmovaps xmm6, [rsp+0x30]
00007531fdbd93c2  vpermilpd xmm6, xmm6, 0x00
00007531fdbd93c8  movaps xmm5, xmm8
00007531fdbd93cc  mulpd xmm5, xmm6
00007531fdbd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007531fdbd93d5  ptest xmm3, xmm3
00007531fdbd93da  jnz 0x00007531FDBDC368
00007531fdbd93e0  vmovaps xmm8, [rsp+0x30]
00007531fdbd93e6  vpermilpd xmm8, xmm8, 0x00
00007531fdbd93ec  movaps xmm6, xmm10
00007531fdbd93f0  mulpd xmm6, xmm8
00007531fdbd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007531fdbd93fa  ptest xmm3, xmm3
00007531fdbd93ff  jnz 0x00007531FDBDC4A9
00007531fdbd9405  vmovaps xmm8, [rsp+0x60]
00007531fdbd940b  movaps xmm10, xmm8
00007531fdbd940f  addpd xmm10, xmm14
00007531fdbd9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007531fdbd941a  ptest xmm3, xmm3
00007531fdbd941f  jnz 0x00007531FDBDC5EB
00007531fdbd9425  vmovaps xmm8, [rsp+0x50]
00007531fdbd942b  movaps xmm14, xmm8
00007531fdbd942f  addpd xmm14, xmm4
00007531fdbd9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007531fdbd943a  ptest xmm3, xmm3
00007531fdbd943f  jnz 0x00007531FDBDC72F
00007531fdbd9445  vmovaps xmm8, [rsp+0x40]
00007531fdbd944b  vpermilpd xmm8, xmm8, 0x00
00007531fdbd9451  movaps xmm4, xmm13
00007531fdbd9455  mulpd xmm4, xmm8
00007531fdbd945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007531fdbd945f  ptest xmm3, xmm3
00007531fdbd9464  jnz 0x00007531FDBDC872
00007531fdbd946a  movaps xmm13, xmm15
00007531fdbd946e  addpd xmm13, xmm9
00007531fdbd9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007531fdbd9479  ptest xmm8, xmm8
00007531fdbd947f  jnz 0x00007531FDBDC9B4
00007531fdbd9485  movaps xmm15, xmm1
00007531fdbd9489  addpd xmm15, xmm5
00007531fdbd948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007531fdbd9494  ptest xmm9, xmm9
00007531fdbd949a  jnz 0x00007531FDBDCAF8
00007531fdbd94a0  vmovaps [rsp+0x30], xmm11
00007531fdbd94a6  vmovaps xmm1, [rsp+0x30]
00007531fdbd94ac  por xmm11, xmm1
00007531fdbd94b1  movaps [r15+0x250], xmm11
00007531fdbd94b9  vmovaps [rsp+0x30], xmm12
00007531fdbd94bf  vmovaps xmm1, [rsp+0x30]
00007531fdbd94c5  por xmm12, xmm1
00007531fdbd94ca  movaps [r15+0x2A0], xmm12
00007531fdbd94d2  vmovaps xmm1, [rsp+0xA0]
00007531fdbd94db  vmovaps xmm11, [rsp+0xA0]
00007531fdbd94e4  por xmm1, xmm11
00007531fdbd94e9  movaps [r15+0x1D0], xmm1
00007531fdbd94f1  lea r14, [rax+0x40]
00007531fdbd94f5  movups xmm1, [r13+r14*1]
00007531fdbd94fb  movaps [r15+0x2C0], xmm1
00007531fdbd9503  vmovaps xmm11, [rsp+0x40]
00007531fdbd9509  vpermilpd xmm11, xmm11, 0x00
00007531fdbd950f  vmovaps xmm8, [rsp+0xE0]
00007531fdbd9518  movaps xmm9, xmm8
00007531fdbd951c  mulpd xmm9, xmm11
00007531fdbd9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007531fdbd9527  ptest xmm5, xmm5
00007531fdbd952c  jnz 0x00007531FDBDCC44
00007531fdbd9532  movaps xmm11, xmm10
00007531fdbd9536  addpd xmm11, xmm6
00007531fdbd953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007531fdbd9541  ptest xmm8, xmm8
00007531fdbd9547  jnz 0x00007531FDBDCD88
00007531fdbd954d  movaps xmm10, xmm14
00007531fdbd9551  addpd xmm10, xmm4
00007531fdbd9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007531fdbd955c  ptest xmm8, xmm8
00007531fdbd9562  jnz 0x00007531FDBDCECB
00007531fdbd9568  vmovaps xmm14, [rsp+0x40]
00007531fdbd956e  vpermilpd xmm14, xmm14, 0x00
00007531fdbd9574  movaps xmm8, xmm1
00007531fdbd9578  mulpd xmm8, xmm14
00007531fdbd957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007531fdbd9583  ptest xmm6, xmm6
00007531fdbd9588  jnz 0x00007531FDBDD00E
00007531fdbd958e  movaps xmm1, [r15+0x2B0]
00007531fdbd9596  vmovaps xmm14, [rsp+0x40]
00007531fdbd959c  vpermilpd xmm14, xmm14, 0x00
00007531fdbd95a2  movaps xmm6, xmm1
00007531fdbd95a5  mulpd xmm6, xmm14
00007531fdbd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007531fdbd95af  ptest xmm5, xmm5
00007531fdbd95b4  jnz 0x00007531FDBDD151
00007531fdbd95ba  vmovaps xmm1, [rsp+0x10]
00007531fdbd95c0  vpermilpd xmm1, xmm1, 0x00
00007531fdbd95c6  movaps xmm14, xmm12
00007531fdbd95ca  mulpd xmm14, xmm1
00007531fdbd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007531fdbd95d5  ptest xmm5, xmm5
00007531fdbd95da  jnz 0x00007531FDBDD292
00007531fdbd95e0  movaps xmm1, xmm13
00007531fdbd95e4  addpd xmm1, xmm9
00007531fdbd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007531fdbd95ee  ptest xmm12, xmm12
00007531fdbd95f4  jnz 0x00007531FDBDD3D5
00007531fdbd95fa  vmovaps xmm13, [rsp+0x10]
00007531fdbd9600  vpermilpd xmm13, xmm13, 0x00
00007531fdbd9606  movaps xmm12, xmm7
00007531fdbd960a  mulpd xmm12, xmm13
00007531fdbd960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007531fdbd9615  ptest xmm9, xmm9
00007531fdbd961b  jnz 0x00007531FDBDD517
00007531fdbd9621  movaps xmm13, xmm15
00007531fdbd9625  addpd xmm13, xmm8
00007531fdbd962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007531fdbd9630  ptest xmm9, xmm9
00007531fdbd9636  jnz 0x00007531FDBDD65A
00007531fdbd963c  movaps xmm15, [r15+0x290]
00007531fdbd9644  vmovaps xmm9, [rsp+0x10]
00007531fdbd964a  vpermilpd xmm9, xmm9, 0x00
00007531fdbd9650  movaps xmm8, xmm15
00007531fdbd9654  mulpd xmm8, xmm9
00007531fdbd9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007531fdbd965f  ptest xmm7, xmm7
00007531fdbd9664  jnz 0x00007531FDBDD79E
00007531fdbd966a  movaps xmm15, xmm11
00007531fdbd966e  addpd xmm15, xmm6
00007531fdbd9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007531fdbd9679  ptest xmm9, xmm9
00007531fdbd967f  jnz 0x00007531FDBDD8E2
00007531fdbd9685  movaps xmm11, [r15+0x1E0]
00007531fdbd968d  vmovaps xmm9, [rsp+0x10]
00007531fdbd9693  vpermilpd xmm9, xmm9, 0x00
00007531fdbd9699  movaps xmm7, xmm11
00007531fdbd969d  mulpd xmm7, xmm9
00007531fdbd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007531fdbd96a7  ptest xmm6, xmm6
00007531fdbd96ac  jnz 0x00007531FDBDDA25
00007531fdbd96b2  movaps xmm11, xmm10
00007531fdbd96b6  addpd xmm11, xmm14
00007531fdbd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007531fdbd96c1  ptest xmm9, xmm9
00007531fdbd96c7  jnz 0x00007531FDBDDB67
00007531fdbd96cd  lea r14, [rax+0x70]
00007531fdbd96d1  movups xmm14, [r13+r14*1]
00007531fdbd96d7  movaps [r15+0x240], xmm14
00007531fdbd96df  movaps xmm10, xmm1
00007531fdbd96e3  addpd xmm10, xmm12
00007531fdbd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007531fdbd96ee  ptest xmm9, xmm9
00007531fdbd96f4  jnz 0x00007531FDBDDCB5
00007531fdbd96fa  movaps [r15+0x170], xmm10
00007531fdbd9702  vmovaps xmm1, [rsp+0x20]
00007531fdbd9708  vpermilpd xmm1, xmm1, 0x00
00007531fdbd970e  movaps xmm12, xmm14
00007531fdbd9712  mulpd xmm12, xmm1
00007531fdbd9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007531fdbd971d  ptest xmm9, xmm9
00007531fdbd9723  jnz 0x00007531FDBDDDF8
00007531fdbd9729  vmovaps xmm1, [rsp+0x20]
00007531fdbd972f  vpermilpd xmm1, xmm1, 0x00
00007531fdbd9735  vmovaps xmm9, [rsp+0xB0]
00007531fdbd973e  movaps xmm14, xmm9
00007531fdbd9742  mulpd xmm14, xmm1
00007531fdbd9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007531fdbd974d  ptest xmm6, xmm6
00007531fdbd9752  jnz 0x00007531FDBDDF3B
00007531fdbd9758  movaps [r15+0x180], xmm14
00007531fdbd9760  movaps xmm1, xmm13
00007531fdbd9764  addpd xmm1, xmm8
00007531fdbd9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007531fdbd976e  ptest xmm9, xmm9
00007531fdbd9774  jnz 0x00007531FDBDE07E
00007531fdbd977a  movaps [r15+0x210], xmm1
00007531fdbd9782  movups xmm13, [r13+rax*1]
00007531fdbd9788  lea r14, [rax+0x10]
00007531fdbd978c  movups xmm9, [r13+r14*1]
00007531fdbd9792  movaps [r15+0x230], xmm9
00007531fdbd979a  movaps xmm8, xmm15
00007531fdbd979e  addpd xmm8, xmm7
00007531fdbd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007531fdbd97a9  ptest xmm6, xmm6
00007531fdbd97ae  jnz 0x00007531FDBDE1D4
00007531fdbd97b4  movaps [r15+0x130], xmm8
00007531fdbd97bc  vmovaps xmm15, [rsp+0x20]
00007531fdbd97c2  vpermilpd xmm15, xmm15, 0x00
00007531fdbd97c8  movaps xmm7, xmm9
00007531fdbd97cc  mulpd xmm7, xmm15
00007531fdbd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007531fdbd97d6  ptest xmm6, xmm6
00007531fdbd97db  jnz 0x00007531FDBDE317
00007531fdbd97e1  movaps [r15+0x220], xmm7
00007531fdbd97e9  vmovaps xmm15, [rsp+0x20]
00007531fdbd97ef  vpermilpd xmm15, xmm15, 0x00
00007531fdbd97f5  movaps xmm9, xmm13
00007531fdbd97f9  mulpd xmm9, xmm15
00007531fdbd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007531fdbd9804  ptest xmm6, xmm6
00007531fdbd9809  jnz 0x00007531FDBDE459
00007531fdbd980f  movaps xmm15, xmm11
00007531fdbd9813  addpd xmm15, xmm12
00007531fdbd9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007531fdbd981e  ptest xmm13, xmm13
00007531fdbd9824  jnz 0x00007531FDBDE59D
00007531fdbd982a  movaps [r15+0x140], xmm15
00007531fdbd9832  movaps xmm13, xmm10
00007531fdbd9836  addpd xmm13, xmm14
00007531fdbd983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007531fdbd9841  ptest xmm12, xmm12
00007531fdbd9847  jnz 0x00007531FDBDE6E1
00007531fdbd984d  movaps [r15+0x150], xmm13
00007531fdbd9855  movaps xmm14, xmm1
00007531fdbd9859  addpd xmm14, xmm7
00007531fdbd985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007531fdbd9864  ptest xmm12, xmm12
00007531fdbd986a  jnz 0x00007531FDBDE825
00007531fdbd9870  movaps [r15+0x160], xmm14
00007531fdbd9878  movaps xmm1, xmm8
00007531fdbd987c  addpd xmm1, xmm9
00007531fdbd9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007531fdbd9886  ptest xmm12, xmm12
00007531fdbd988c  jnz 0x00007531FDBDE967
00007531fdbd9892  movaps [r15+0x120], xmm1
00007531fdbd989a  movups [r13+r11*1], xmm15
00007531fdbd98a0  lea rax, [r11+0x10]
00007531fdbd98a4  movups [r13+rax*1], xmm13
00007531fdbd98aa  lea rax, [r11+0x20]
00007531fdbd98ae  movups [r13+rax*1], xmm14
00007531fdbd98b4  lea rax, [r11+0x30]
00007531fdbd98b8  movups [r13+rax*1], xmm1
00007531fdbd98be  mov eax, [r15+0x108]
00007531fdbd98c5  sahf
00007531fdbd98c6  jnz 0x00007531FDBD98F8
00007531fdbd98c8  cmp dword ptr [r15+0x318], 0x00
00007531fdbd98d0  jz 0x00007531FDBDEAE0
00007531fdbd98d6  nop [rax+rax*1], ax
00007531fdbd98df  nop [rax+rax*1], eax
00007531fdbd98e7  mov eax, 0x4106D0
00007531fdbd98ec  mov [r15+0x100], rax
00007531fdbd98f3  jmp 0x00007531FD9FE110
00007531fdbd98f8  cmp dword ptr [r15+0x318], 0x00
00007531fdbd9900  jz 0x00007531FDBD89C0
00007531fdbd9906  nop [rax+rax*1], ax
00007531fdbd990f  nop [rax+rax*1], eax
00007531fdbd9917  mov eax, 0x410504
00007531fdbd991c  mov [r15+0x100], rax
00007531fdbd9923  jmp 0x00007531FD9FE110
00007531fdbd9928  int3
00007531fdbd9929  call 0x00007531FDA0A4B0
00007531fdbd992e  jmp 0x00007531FDBD8A08
00007531fdbd9933  call 0x00007531FDA09240
00007531fdbd9938  jmp 0x00007531FDBD8A12
00007531fdbd993d  call 0x00007531FDA0A4B0
00007531fdbd9942  jmp 0x00007531FDBD8A6F
00007531fdbd9947  call 0x00007531FDA09240
00007531fdbd994c  jmp 0x00007531FDBD8A79
00007531fdbd9951  call 0x00007531FDA0A4B0
00007531fdbd9956  jmp 0x00007531FDBD8ABD
00007531fdbd995b  call 0x00007531FDA09240
00007531fdbd9960  jmp 0x00007531FDBD8AC7
00007531fdbd9965  call 0x00007531FDAB47C0
00007531fdbd996a  jmp 0x00007531FDBD8B06
00007531fdbd996f  call 0x00007531FDA0B720
00007531fdbd9974  jmp 0x00007531FDBD8B1A
00007531fdbd9979  call 0x00007531FDABFC30
00007531fdbd997e  jmp 0x00007531FDBD8B38
00007531fdbd9983  call 0x00007531FDABE9C0
00007531fdbd9988  jmp 0x00007531FDBD8B42
00007531fdbd998d  call 0x00007531FDABD750
00007531fdbd9992  jmp 0x00007531FDBD8B4C
00007531fdbd9997  sub rsp, 0x08
00007531fdbd999b  push rax
00007531fdbd999c  push rcx
00007531fdbd999d  push rdx
00007531fdbd999e  push rdi
00007531fdbd999f  push rsi
00007531fdbd99a0  push r8
00007531fdbd99a2  push r9
00007531fdbd99a4  push r10
00007531fdbd99a6  push r11
00007531fdbd99a8  sub rsp, 0xF0
00007531fdbd99af  vmovaps [rsp], xmm0
00007531fdbd99b4  vmovaps [rsp+0x10], xmm1
00007531fdbd99ba  vmovaps [rsp+0x20], xmm2
00007531fdbd99c0  vmovaps [rsp+0x30], xmm3
00007531fdbd99c6  vmovaps [rsp+0x40], xmm4
00007531fdbd99cc  vmovaps [rsp+0x50], xmm5
00007531fdbd99d2  vmovaps [rsp+0x60], xmm6
00007531fdbd99d8  vmovaps [rsp+0x70], xmm7
00007531fdbd99de  vmovaps [rsp+0x80], xmm9
00007531fdbd99e7  vmovaps [rsp+0x90], xmm10
00007531fdbd99f0  vmovaps [rsp+0xA0], xmm11
00007531fdbd99f9  vmovaps [rsp+0xB0], xmm12
00007531fdbd9a02  vmovaps [rsp+0xC0], xmm13
00007531fdbd9a0b  vmovaps [rsp+0xD0], xmm14
00007531fdbd9a14  vmovaps [rsp+0xE0], xmm15
00007531fdbd9a1d  sub rsp, 0x30
00007531fdbd9a21  movaps [rsp], xmm8
00007531fdbd9a26  movaps [rsp+0x10], xmm12
00007531fdbd9a2c  movaps [rsp+0x20], xmm15
00007531fdbd9a32  lea rdi, [rsp]
00007531fdbd9a36  mov esi, 0x00
00007531fdbd9a3b  mov rax, 0x59ED111DF530
00007531fdbd9a45  call rax
00007531fdbd9a47  movaps xmm8, [rsp]
00007531fdbd9a4c  add rsp, 0x30
00007531fdbd9a50  vmovaps xmm0, [rsp]
00007531fdbd9a55  vmovaps xmm1, [rsp+0x10]
00007531fdbd9a5b  vmovaps xmm2, [rsp+0x20]
00007531fdbd9a61  vmovaps xmm3, [rsp+0x30]
00007531fdbd9a67  vmovaps xmm4, [rsp+0x40]
00007531fdbd9a6d  vmovaps xmm5, [rsp+0x50]
00007531fdbd9a73  vmovaps xmm6, [rsp+0x60]
00007531fdbd9a79  vmovaps xmm7, [rsp+0x70]
00007531fdbd9a7f  vmovaps xmm9, [rsp+0x80]
00007531fdbd9a88  vmovaps xmm10, [rsp+0x90]
00007531fdbd9a91  vmovaps xmm11, [rsp+0xA0]
00007531fdbd9a9a  vmovaps xmm12, [rsp+0xB0]
00007531fdbd9aa3  vmovaps xmm13, [rsp+0xC0]
00007531fdbd9aac  vmovaps xmm14, [rsp+0xD0]
00007531fdbd9ab5  vmovaps xmm15, [rsp+0xE0]
00007531fdbd9abe  add rsp, 0xF0
00007531fdbd9ac5  pop r11
00007531fdbd9ac7  pop r10
00007531fdbd9ac9  pop r9
00007531fdbd9acb  pop r8
00007531fdbd9acd  pop rsi
00007531fdbd9ace  pop rdi
00007531fdbd9acf  pop rdx
00007531fdbd9ad0  pop rcx
00007531fdbd9ad1  pop rax
00007531fdbd9ad2  add rsp, 0x08
00007531fdbd9ad6  jmp 0x00007531FDBD8B7A
00007531fdbd9adb  sub rsp, 0x08
00007531fdbd9adf  push rax
00007531fdbd9ae0  push rcx
00007531fdbd9ae1  push rdx
00007531fdbd9ae2  push rdi
00007531fdbd9ae3  push rsi
00007531fdbd9ae4  push r8
00007531fdbd9ae6  push r9
00007531fdbd9ae8  push r10
00007531fdbd9aea  push r11
00007531fdbd9aec  sub rsp, 0xF0
00007531fdbd9af3  vmovaps [rsp], xmm0
00007531fdbd9af8  vmovaps [rsp+0x10], xmm1
00007531fdbd9afe  vmovaps [rsp+0x20], xmm2
00007531fdbd9b04  vmovaps [rsp+0x30], xmm3
00007531fdbd9b0a  vmovaps [rsp+0x40], xmm4
00007531fdbd9b10  vmovaps [rsp+0x50], xmm5
00007531fdbd9b16  vmovaps [rsp+0x60], xmm6
00007531fdbd9b1c  vmovaps [rsp+0x70], xmm8
00007531fdbd9b22  vmovaps [rsp+0x80], xmm9
00007531fdbd9b2b  vmovaps [rsp+0x90], xmm10
00007531fdbd9b34  vmovaps [rsp+0xA0], xmm11
00007531fdbd9b3d  vmovaps [rsp+0xB0], xmm12
00007531fdbd9b46  vmovaps [rsp+0xC0], xmm13
00007531fdbd9b4f  vmovaps [rsp+0xD0], xmm14
00007531fdbd9b58  vmovaps [rsp+0xE0], xmm15
00007531fdbd9b61  sub rsp, 0x30
00007531fdbd9b65  movaps [rsp], xmm7
00007531fdbd9b69  movaps [rsp+0x10], xmm9
00007531fdbd9b6f  movaps [rsp+0x20], xmm15
00007531fdbd9b75  lea rdi, [rsp]
00007531fdbd9b79  mov esi, 0x00
00007531fdbd9b7e  mov rax, 0x59ED111DF530
00007531fdbd9b88  call rax
00007531fdbd9b8a  movaps xmm7, [rsp]
00007531fdbd9b8e  add rsp, 0x30
00007531fdbd9b92  vmovaps xmm0, [rsp]
00007531fdbd9b97  vmovaps xmm1, [rsp+0x10]
00007531fdbd9b9d  vmovaps xmm2, [rsp+0x20]
00007531fdbd9ba3  vmovaps xmm3, [rsp+0x30]
00007531fdbd9ba9  vmovaps xmm4, [rsp+0x40]
00007531fdbd9baf  vmovaps xmm5, [rsp+0x50]
00007531fdbd9bb5  vmovaps xmm6, [rsp+0x60]
00007531fdbd9bbb  vmovaps xmm8, [rsp+0x70]
00007531fdbd9bc1  vmovaps xmm9, [rsp+0x80]
00007531fdbd9bca  vmovaps xmm10, [rsp+0x90]
00007531fdbd9bd3  vmovaps xmm11, [rsp+0xA0]
00007531fdbd9bdc  vmovaps xmm12, [rsp+0xB0]
00007531fdbd9be5  vmovaps xmm13, [rsp+0xC0]
00007531fdbd9bee  vmovaps xmm14, [rsp+0xD0]
00007531fdbd9bf7  vmovaps xmm15, [rsp+0xE0]
00007531fdbd9c00  add rsp, 0xF0
00007531fdbd9c07  pop r11
00007531fdbd9c09  pop r10
00007531fdbd9c0b  pop r9
00007531fdbd9c0d  pop r8
00007531fdbd9c0f  pop rsi
00007531fdbd9c10  pop rdi
00007531fdbd9c11  pop rdx
00007531fdbd9c12  pop rcx
00007531fdbd9c13  pop rax
00007531fdbd9c14  add rsp, 0x08
00007531fdbd9c18  jmp 0x00007531FDBD8BA8
00007531fdbd9c1d  sub rsp, 0x08
00007531fdbd9c21  push rax
00007531fdbd9c22  push rcx
00007531fdbd9c23  push rdx
00007531fdbd9c24  push rdi
00007531fdbd9c25  push rsi
00007531fdbd9c26  push r8
00007531fdbd9c28  push r9
00007531fdbd9c2a  push r10
00007531fdbd9c2c  push r11
00007531fdbd9c2e  sub rsp, 0xF0
00007531fdbd9c35  vmovaps [rsp], xmm0
00007531fdbd9c3a  vmovaps [rsp+0x10], xmm1
00007531fdbd9c40  vmovaps [rsp+0x20], xmm2
00007531fdbd9c46  vmovaps [rsp+0x30], xmm3
00007531fdbd9c4c  vmovaps [rsp+0x40], xmm4
00007531fdbd9c52  vmovaps [rsp+0x50], xmm5
00007531fdbd9c58  vmovaps [rsp+0x60], xmm6
00007531fdbd9c5e  vmovaps [rsp+0x70], xmm7
00007531fdbd9c64  vmovaps [rsp+0x80], xmm8
00007531fdbd9c6d  vmovaps [rsp+0x90], xmm10
00007531fdbd9c76  vmovaps [rsp+0xA0], xmm11
00007531fdbd9c7f  vmovaps [rsp+0xB0], xmm12
00007531fdbd9c88  vmovaps [rsp+0xC0], xmm13
00007531fdbd9c91  vmovaps [rsp+0xD0], xmm14
00007531fdbd9c9a  vmovaps [rsp+0xE0], xmm15
00007531fdbd9ca3  sub rsp, 0x30
00007531fdbd9ca7  movaps [rsp], xmm9
00007531fdbd9cac  movaps [rsp+0x10], xmm12
00007531fdbd9cb2  movaps [rsp+0x20], xmm10
00007531fdbd9cb8  lea rdi, [rsp]
00007531fdbd9cbc  mov esi, 0x00
00007531fdbd9cc1  mov rax, 0x59ED111DF530
00007531fdbd9ccb  call rax
00007531fdbd9ccd  movaps xmm9, [rsp]
00007531fdbd9cd2  add rsp, 0x30
00007531fdbd9cd6  vmovaps xmm0, [rsp]
00007531fdbd9cdb  vmovaps xmm1, [rsp+0x10]
00007531fdbd9ce1  vmovaps xmm2, [rsp+0x20]
00007531fdbd9ce7  vmovaps xmm3, [rsp+0x30]
00007531fdbd9ced  vmovaps xmm4, [rsp+0x40]
00007531fdbd9cf3  vmovaps xmm5, [rsp+0x50]
00007531fdbd9cf9  vmovaps xmm6, [rsp+0x60]
00007531fdbd9cff  vmovaps xmm7, [rsp+0x70]
00007531fdbd9d05  vmovaps xmm8, [rsp+0x80]
00007531fdbd9d0e  vmovaps xmm10, [rsp+0x90]
00007531fdbd9d17  vmovaps xmm11, [rsp+0xA0]
00007531fdbd9d20  vmovaps xmm12, [rsp+0xB0]
00007531fdbd9d29  vmovaps xmm13, [rsp+0xC0]
00007531fdbd9d32  vmovaps xmm14, [rsp+0xD0]
00007531fdbd9d3b  vmovaps xmm15, [rsp+0xE0]
00007531fdbd9d44  add rsp, 0xF0
00007531fdbd9d4b  pop r11
00007531fdbd9d4d  pop r10
00007531fdbd9d4f  pop r9
00007531fdbd9d51  pop r8
00007531fdbd9d53  pop rsi
00007531fdbd9d54  pop rdi
00007531fdbd9d55  pop rdx
00007531fdbd9d56  pop rcx
00007531fdbd9d57  pop rax
00007531fdbd9d58  add rsp, 0x08
00007531fdbd9d5c  jmp 0x00007531FDBD8BCC
00007531fdbd9d61  sub rsp, 0x08
00007531fdbd9d65  push rax
00007531fdbd9d66  push rcx
00007531fdbd9d67  push rdx
00007531fdbd9d68  push rdi
00007531fdbd9d69  push rsi
00007531fdbd9d6a  push r8
00007531fdbd9d6c  push r9
00007531fdbd9d6e  push r10
00007531fdbd9d70  push r11
00007531fdbd9d72  sub rsp, 0xF0
00007531fdbd9d79  vmovaps [rsp], xmm0
00007531fdbd9d7e  vmovaps [rsp+0x10], xmm1
00007531fdbd9d84  vmovaps [rsp+0x20], xmm2
00007531fdbd9d8a  vmovaps [rsp+0x30], xmm3
00007531fdbd9d90  vmovaps [rsp+0x40], xmm4
00007531fdbd9d96  vmovaps [rsp+0x50], xmm5
00007531fdbd9d9c  vmovaps [rsp+0x60], xmm6
00007531fdbd9da2  vmovaps [rsp+0x70], xmm7
00007531fdbd9da8  vmovaps [rsp+0x80], xmm8
00007531fdbd9db1  vmovaps [rsp+0x90], xmm9
00007531fdbd9dba  vmovaps [rsp+0xA0], xmm11
00007531fdbd9dc3  vmovaps [rsp+0xB0], xmm12
00007531fdbd9dcc  vmovaps [rsp+0xC0], xmm13
00007531fdbd9dd5  vmovaps [rsp+0xD0], xmm14
00007531fdbd9dde  vmovaps [rsp+0xE0], xmm15
00007531fdbd9de7  sub rsp, 0x30
00007531fdbd9deb  movaps [rsp], xmm10
00007531fdbd9df0  movaps [rsp+0x10], xmm12
00007531fdbd9df6  movaps [rsp+0x20], xmm11
00007531fdbd9dfc  lea rdi, [rsp]
00007531fdbd9e00  mov esi, 0x00
00007531fdbd9e05  mov rax, 0x59ED111DF530
00007531fdbd9e0f  call rax
00007531fdbd9e11  movaps xmm10, [rsp]
00007531fdbd9e16  add rsp, 0x30
00007531fdbd9e1a  vmovaps xmm0, [rsp]
00007531fdbd9e1f  vmovaps xmm1, [rsp+0x10]
00007531fdbd9e25  vmovaps xmm2, [rsp+0x20]
00007531fdbd9e2b  vmovaps xmm3, [rsp+0x30]
00007531fdbd9e31  vmovaps xmm4, [rsp+0x40]
00007531fdbd9e37  vmovaps xmm5, [rsp+0x50]
00007531fdbd9e3d  vmovaps xmm6, [rsp+0x60]
00007531fdbd9e43  vmovaps xmm7, [rsp+0x70]
00007531fdbd9e49  vmovaps xmm8, [rsp+0x80]
00007531fdbd9e52  vmovaps xmm9, [rsp+0x90]
00007531fdbd9e5b  vmovaps xmm11, [rsp+0xA0]
00007531fdbd9e64  vmovaps xmm12, [rsp+0xB0]
00007531fdbd9e6d  vmovaps xmm13, [rsp+0xC0]
00007531fdbd9e76  vmovaps xmm14, [rsp+0xD0]
00007531fdbd9e7f  vmovaps xmm15, [rsp+0xE0]
00007531fdbd9e88  add rsp, 0xF0
00007531fdbd9e8f  pop r11
00007531fdbd9e91  pop r10
00007531fdbd9e93  pop r9
00007531fdbd9e95  pop r8
00007531fdbd9e97  pop rsi
00007531fdbd9e98  pop rdi
00007531fdbd9e99  pop rdx
00007531fdbd9e9a  pop rcx
00007531fdbd9e9b  pop rax
00007531fdbd9e9c  add rsp, 0x08
00007531fdbd9ea0  jmp 0x00007531FDBD8BE6
00007531fdbd9ea5  sub rsp, 0x08
00007531fdbd9ea9  push rax
00007531fdbd9eaa  push rcx
00007531fdbd9eab  push rdx
00007531fdbd9eac  push rdi
00007531fdbd9ead  push rsi
00007531fdbd9eae  push r8
00007531fdbd9eb0  push r9
00007531fdbd9eb2  push r10
00007531fdbd9eb4  push r11
00007531fdbd9eb6  sub rsp, 0xF0
00007531fdbd9ebd  vmovaps [rsp], xmm0
00007531fdbd9ec2  vmovaps [rsp+0x10], xmm1
00007531fdbd9ec8  vmovaps [rsp+0x20], xmm2
00007531fdbd9ece  vmovaps [rsp+0x30], xmm3
00007531fdbd9ed4  vmovaps [rsp+0x40], xmm4
00007531fdbd9eda  vmovaps [rsp+0x50], xmm5
00007531fdbd9ee0  vmovaps [rsp+0x60], xmm7
00007531fdbd9ee6  vmovaps [rsp+0x70], xmm8
00007531fdbd9eec  vmovaps [rsp+0x80], xmm9
00007531fdbd9ef5  vmovaps [rsp+0x90], xmm10
00007531fdbd9efe  vmovaps [rsp+0xA0], xmm11
00007531fdbd9f07  vmovaps [rsp+0xB0], xmm12
00007531fdbd9f10  vmovaps [rsp+0xC0], xmm13
00007531fdbd9f19  vmovaps [rsp+0xD0], xmm14
00007531fdbd9f22  vmovaps [rsp+0xE0], xmm15
00007531fdbd9f2b  sub rsp, 0x30
00007531fdbd9f2f  movaps [rsp], xmm6
00007531fdbd9f33  movaps [rsp+0x10], xmm12
00007531fdbd9f39  movaps [rsp+0x20], xmm11
00007531fdbd9f3f  lea rdi, [rsp]
00007531fdbd9f43  mov esi, 0x00
00007531fdbd9f48  mov rax, 0x59ED111DF530
00007531fdbd9f52  call rax
00007531fdbd9f54  movaps xmm6, [rsp]
00007531fdbd9f58  add rsp, 0x30
00007531fdbd9f5c  vmovaps xmm0, [rsp]
00007531fdbd9f61  vmovaps xmm1, [rsp+0x10]
00007531fdbd9f67  vmovaps xmm2, [rsp+0x20]
00007531fdbd9f6d  vmovaps xmm3, [rsp+0x30]
00007531fdbd9f73  vmovaps xmm4, [rsp+0x40]
00007531fdbd9f79  vmovaps xmm5, [rsp+0x50]
00007531fdbd9f7f  vmovaps xmm7, [rsp+0x60]
00007531fdbd9f85  vmovaps xmm8, [rsp+0x70]
00007531fdbd9f8b  vmovaps xmm9, [rsp+0x80]
00007531fdbd9f94  vmovaps xmm10, [rsp+0x90]
00007531fdbd9f9d  vmovaps xmm11, [rsp+0xA0]
00007531fdbd9fa6  vmovaps xmm12, [rsp+0xB0]
00007531fdbd9faf  vmovaps xmm13, [rsp+0xC0]
00007531fdbd9fb8  vmovaps xmm14, [rsp+0xD0]
00007531fdbd9fc1  vmovaps xmm15, [rsp+0xE0]
00007531fdbd9fca  add rsp, 0xF0
00007531fdbd9fd1  pop r11
00007531fdbd9fd3  pop r10
00007531fdbd9fd5  pop r9
00007531fdbd9fd7  pop r8
00007531fdbd9fd9  pop rsi
00007531fdbd9fda  pop rdi
00007531fdbd9fdb  pop rdx
00007531fdbd9fdc  pop rcx
00007531fdbd9fdd  pop rax
00007531fdbd9fde  add rsp, 0x08
00007531fdbd9fe2  jmp 0x00007531FDBD8C07
00007531fdbd9fe7  sub rsp, 0x08
00007531fdbd9feb  push rax
00007531fdbd9fec  push rcx
00007531fdbd9fed  push rdx
00007531fdbd9fee  push rdi
00007531fdbd9fef  push rsi
00007531fdbd9ff0  push r8
00007531fdbd9ff2  push r9
00007531fdbd9ff4  push r10
00007531fdbd9ff6  push r11
00007531fdbd9ff8  sub rsp, 0xF0
00007531fdbd9fff  vmovaps [rsp], xmm0
00007531fdbda004  vmovaps [rsp+0x10], xmm1
00007531fdbda00a  vmovaps [rsp+0x20], xmm2
00007531fdbda010  vmovaps [rsp+0x30], xmm4
00007531fdbda016  vmovaps [rsp+0x40], xmm5
00007531fdbda01c  vmovaps [rsp+0x50], xmm6
00007531fdbda022  vmovaps [rsp+0x60], xmm7
00007531fdbda028  vmovaps [rsp+0x70], xmm8
00007531fdbda02e  vmovaps [rsp+0x80], xmm9
00007531fdbda037  vmovaps [rsp+0x90], xmm10
00007531fdbda040  vmovaps [rsp+0xA0], xmm11
00007531fdbda049  vmovaps [rsp+0xB0], xmm12
00007531fdbda052  vmovaps [rsp+0xC0], xmm13
00007531fdbda05b  vmovaps [rsp+0xD0], xmm14
00007531fdbda064  vmovaps [rsp+0xE0], xmm15
00007531fdbda06d  sub rsp, 0x30
00007531fdbda071  movaps [rsp], xmm3
00007531fdbda075  movaps [rsp+0x10], xmm5
00007531fdbda07a  movaps [rsp+0x20], xmm4
00007531fdbda07f  lea rdi, [rsp]
00007531fdbda083  mov esi, 0x00
00007531fdbda088  mov rax, 0x59ED111DF530
00007531fdbda092  call rax
00007531fdbda094  movaps xmm3, [rsp]
00007531fdbda098  add rsp, 0x30
00007531fdbda09c  vmovaps xmm0, [rsp]
00007531fdbda0a1  vmovaps xmm1, [rsp+0x10]
00007531fdbda0a7  vmovaps xmm2, [rsp+0x20]
00007531fdbda0ad  vmovaps xmm4, [rsp+0x30]
00007531fdbda0b3  vmovaps xmm5, [rsp+0x40]
00007531fdbda0b9  vmovaps xmm6, [rsp+0x50]
00007531fdbda0bf  vmovaps xmm7, [rsp+0x60]
00007531fdbda0c5  vmovaps xmm8, [rsp+0x70]
00007531fdbda0cb  vmovaps xmm9, [rsp+0x80]
00007531fdbda0d4  vmovaps xmm10, [rsp+0x90]
00007531fdbda0dd  vmovaps xmm11, [rsp+0xA0]
00007531fdbda0e6  vmovaps xmm12, [rsp+0xB0]
00007531fdbda0ef  vmovaps xmm13, [rsp+0xC0]
00007531fdbda0f8  vmovaps xmm14, [rsp+0xD0]
00007531fdbda101  vmovaps xmm15, [rsp+0xE0]
00007531fdbda10a  add rsp, 0xF0
00007531fdbda111  pop r11
00007531fdbda113  pop r10
00007531fdbda115  pop r9
00007531fdbda117  pop r8
00007531fdbda119  pop rsi
00007531fdbda11a  pop rdi
00007531fdbda11b  pop rdx
00007531fdbda11c  pop rcx
00007531fdbda11d  pop rax
00007531fdbda11e  add rsp, 0x08
00007531fdbda122  jmp 0x00007531FDBD8C68
00007531fdbda127  sub rsp, 0x08
00007531fdbda12b  push rax
00007531fdbda12c  push rcx
00007531fdbda12d  push rdx
00007531fdbda12e  push rdi
00007531fdbda12f  push rsi
00007531fdbda130  push r8
00007531fdbda132  push r9
00007531fdbda134  push r10
00007531fdbda136  push r11
00007531fdbda138  sub rsp, 0xF0
00007531fdbda13f  vmovaps [rsp], xmm0
00007531fdbda144  vmovaps [rsp+0x10], xmm1
00007531fdbda14a  vmovaps [rsp+0x20], xmm2
00007531fdbda150  vmovaps [rsp+0x30], xmm3
00007531fdbda156  vmovaps [rsp+0x40], xmm4
00007531fdbda15c  vmovaps [rsp+0x50], xmm6
00007531fdbda162  vmovaps [rsp+0x60], xmm7
00007531fdbda168  vmovaps [rsp+0x70], xmm8
00007531fdbda16e  vmovaps [rsp+0x80], xmm9
00007531fdbda177  vmovaps [rsp+0x90], xmm10
00007531fdbda180  vmovaps [rsp+0xA0], xmm11
00007531fdbda189  vmovaps [rsp+0xB0], xmm12
00007531fdbda192  vmovaps [rsp+0xC0], xmm13
00007531fdbda19b  vmovaps [rsp+0xD0], xmm14
00007531fdbda1a4  vmovaps [rsp+0xE0], xmm15
00007531fdbda1ad  sub rsp, 0x30
00007531fdbda1b1  movaps [rsp], xmm5
00007531fdbda1b5  movaps [rsp+0x10], xmm8
00007531fdbda1bb  movaps [rsp+0x20], xmm15
00007531fdbda1c1  lea rdi, [rsp]
00007531fdbda1c5  mov esi, 0x00
00007531fdbda1ca  mov rax, 0x59ED111DF530
00007531fdbda1d4  call rax
00007531fdbda1d6  movaps xmm5, [rsp]
00007531fdbda1da  add rsp, 0x30
00007531fdbda1de  vmovaps xmm0, [rsp]
00007531fdbda1e3  vmovaps xmm1, [rsp+0x10]
00007531fdbda1e9  vmovaps xmm2, [rsp+0x20]
00007531fdbda1ef  vmovaps xmm3, [rsp+0x30]
00007531fdbda1f5  vmovaps xmm4, [rsp+0x40]
00007531fdbda1fb  vmovaps xmm6, [rsp+0x50]
00007531fdbda201  vmovaps xmm7, [rsp+0x60]
00007531fdbda207  vmovaps xmm8, [rsp+0x70]
00007531fdbda20d  vmovaps xmm9, [rsp+0x80]
00007531fdbda216  vmovaps xmm10, [rsp+0x90]
00007531fdbda21f  vmovaps xmm11, [rsp+0xA0]
00007531fdbda228  vmovaps xmm12, [rsp+0xB0]
00007531fdbda231  vmovaps xmm13, [rsp+0xC0]
00007531fdbda23a  vmovaps xmm14, [rsp+0xD0]
00007531fdbda243  vmovaps xmm15, [rsp+0xE0]
00007531fdbda24c  add rsp, 0xF0
00007531fdbda253  pop r11
00007531fdbda255  pop r10
00007531fdbda257  pop r9
00007531fdbda259  pop r8
00007531fdbda25b  pop rsi
00007531fdbda25c  pop rdi
00007531fdbda25d  pop rdx
00007531fdbda25e  pop rcx
00007531fdbda25f  pop rax
00007531fdbda260  add rsp, 0x08
00007531fdbda264  jmp 0x00007531FDBD8CA0
00007531fdbda269  sub rsp, 0x08
00007531fdbda26d  push rax
00007531fdbda26e  push rcx
00007531fdbda26f  push rdx
00007531fdbda270  push rdi
00007531fdbda271  push rsi
00007531fdbda272  push r8
00007531fdbda274  push r9
00007531fdbda276  push r10
00007531fdbda278  push r11
00007531fdbda27a  sub rsp, 0xF0
00007531fdbda281  vmovaps [rsp], xmm0
00007531fdbda286  vmovaps [rsp+0x10], xmm1
00007531fdbda28c  vmovaps [rsp+0x20], xmm2
00007531fdbda292  vmovaps [rsp+0x30], xmm3
00007531fdbda298  vmovaps [rsp+0x40], xmm5
00007531fdbda29e  vmovaps [rsp+0x50], xmm6
00007531fdbda2a4  vmovaps [rsp+0x60], xmm7
00007531fdbda2aa  vmovaps [rsp+0x70], xmm8
00007531fdbda2b0  vmovaps [rsp+0x80], xmm9
00007531fdbda2b9  vmovaps [rsp+0x90], xmm10
00007531fdbda2c2  vmovaps [rsp+0xA0], xmm11
00007531fdbda2cb  vmovaps [rsp+0xB0], xmm12
00007531fdbda2d4  vmovaps [rsp+0xC0], xmm13
00007531fdbda2dd  vmovaps [rsp+0xD0], xmm14
00007531fdbda2e6  vmovaps [rsp+0xE0], xmm15
00007531fdbda2ef  sub rsp, 0x30
00007531fdbda2f3  movaps [rsp], xmm4
00007531fdbda2f7  movaps [rsp+0x10], xmm9
00007531fdbda2fd  movaps [rsp+0x20], xmm8
00007531fdbda303  lea rdi, [rsp]
00007531fdbda307  mov esi, 0x00
00007531fdbda30c  mov rax, 0x59ED111DF530
00007531fdbda316  call rax
00007531fdbda318  movaps xmm4, [rsp]
00007531fdbda31c  add rsp, 0x30
00007531fdbda320  vmovaps xmm0, [rsp]
00007531fdbda325  vmovaps xmm1, [rsp+0x10]
00007531fdbda32b  vmovaps xmm2, [rsp+0x20]
00007531fdbda331  vmovaps xmm3, [rsp+0x30]
00007531fdbda337  vmovaps xmm5, [rsp+0x40]
00007531fdbda33d  vmovaps xmm6, [rsp+0x50]
00007531fdbda343  vmovaps xmm7, [rsp+0x60]
00007531fdbda349  vmovaps xmm8, [rsp+0x70]
00007531fdbda34f  vmovaps xmm9, [rsp+0x80]
00007531fdbda358  vmovaps xmm10, [rsp+0x90]
00007531fdbda361  vmovaps xmm11, [rsp+0xA0]
00007531fdbda36a  vmovaps xmm12, [rsp+0xB0]
00007531fdbda373  vmovaps xmm13, [rsp+0xC0]
00007531fdbda37c  vmovaps xmm14, [rsp+0xD0]
00007531fdbda385  vmovaps xmm15, [rsp+0xE0]
00007531fdbda38e  add rsp, 0xF0
00007531fdbda395  pop r11
00007531fdbda397  pop r10
00007531fdbda399  pop r9
00007531fdbda39b  pop r8
00007531fdbda39d  pop rsi
00007531fdbda39e  pop rdi
00007531fdbda39f  pop rdx
00007531fdbda3a0  pop rcx
00007531fdbda3a1  pop rax
00007531fdbda3a2  add rsp, 0x08
00007531fdbda3a6  jmp 0x00007531FDBD8CC1
00007531fdbda3ab  sub rsp, 0x08
00007531fdbda3af  push rax
00007531fdbda3b0  push rcx
00007531fdbda3b1  push rdx
00007531fdbda3b2  push rdi
00007531fdbda3b3  push rsi
00007531fdbda3b4  push r8
00007531fdbda3b6  push r9
00007531fdbda3b8  push r10
00007531fdbda3ba  push r11
00007531fdbda3bc  sub rsp, 0xF0
00007531fdbda3c3  vmovaps [rsp], xmm0
00007531fdbda3c8  vmovaps [rsp+0x10], xmm1
00007531fdbda3ce  vmovaps [rsp+0x20], xmm2
00007531fdbda3d4  vmovaps [rsp+0x30], xmm3
00007531fdbda3da  vmovaps [rsp+0x40], xmm4
00007531fdbda3e0  vmovaps [rsp+0x50], xmm5
00007531fdbda3e6  vmovaps [rsp+0x60], xmm6
00007531fdbda3ec  vmovaps [rsp+0x70], xmm7
00007531fdbda3f2  vmovaps [rsp+0x80], xmm8
00007531fdbda3fb  vmovaps [rsp+0x90], xmm10
00007531fdbda404  vmovaps [rsp+0xA0], xmm11
00007531fdbda40d  vmovaps [rsp+0xB0], xmm12
00007531fdbda416  vmovaps [rsp+0xC0], xmm13
00007531fdbda41f  vmovaps [rsp+0xD0], xmm14
00007531fdbda428  vmovaps [rsp+0xE0], xmm15
00007531fdbda431  sub rsp, 0x30
00007531fdbda435  movaps [rsp], xmm9
00007531fdbda43a  movaps [rsp+0x10], xmm10
00007531fdbda440  movaps [rsp+0x20], xmm8
00007531fdbda446  lea rdi, [rsp]
00007531fdbda44a  mov esi, 0x00
00007531fdbda44f  mov rax, 0x59ED111DF530
00007531fdbda459  call rax
00007531fdbda45b  movaps xmm9, [rsp]
00007531fdbda460  add rsp, 0x30
00007531fdbda464  vmovaps xmm0, [rsp]
00007531fdbda469  vmovaps xmm1, [rsp+0x10]
00007531fdbda46f  vmovaps xmm2, [rsp+0x20]
00007531fdbda475  vmovaps xmm3, [rsp+0x30]
00007531fdbda47b  vmovaps xmm4, [rsp+0x40]
00007531fdbda481  vmovaps xmm5, [rsp+0x50]
00007531fdbda487  vmovaps xmm6, [rsp+0x60]
00007531fdbda48d  vmovaps xmm7, [rsp+0x70]
00007531fdbda493  vmovaps xmm8, [rsp+0x80]
00007531fdbda49c  vmovaps xmm10, [rsp+0x90]
00007531fdbda4a5  vmovaps xmm11, [rsp+0xA0]
00007531fdbda4ae  vmovaps xmm12, [rsp+0xB0]
00007531fdbda4b7  vmovaps xmm13, [rsp+0xC0]
00007531fdbda4c0  vmovaps xmm14, [rsp+0xD0]
00007531fdbda4c9  vmovaps xmm15, [rsp+0xE0]
00007531fdbda4d2  add rsp, 0xF0
00007531fdbda4d9  pop r11
00007531fdbda4db  pop r10
00007531fdbda4dd  pop r9
00007531fdbda4df  pop r8
00007531fdbda4e1  pop rsi
00007531fdbda4e2  pop rdi
00007531fdbda4e3  pop rdx
00007531fdbda4e4  pop rcx
00007531fdbda4e5  pop rax
00007531fdbda4e6  add rsp, 0x08
00007531fdbda4ea  jmp 0x00007531FDBD8CDB
00007531fdbda4ef  call 0x00007531FDAD64F0
00007531fdbda4f4  jmp 0x00007531FDBD8DF5
00007531fdbda4f9  call 0x00007531FDAD64F0
00007531fdbda4fe  jmp 0x00007531FDBD8E0B
00007531fdbda503  sub rsp, 0x08
00007531fdbda507  push rax
00007531fdbda508  push rcx
00007531fdbda509  push rdx
00007531fdbda50a  push rdi
00007531fdbda50b  push rsi
00007531fdbda50c  push r8
00007531fdbda50e  push r9
00007531fdbda510  push r10
00007531fdbda512  push r11
00007531fdbda514  sub rsp, 0xF0
00007531fdbda51b  vmovaps [rsp], xmm0
00007531fdbda520  vmovaps [rsp+0x10], xmm2
00007531fdbda526  vmovaps [rsp+0x20], xmm3
00007531fdbda52c  vmovaps [rsp+0x30], xmm4
00007531fdbda532  vmovaps [rsp+0x40], xmm5
00007531fdbda538  vmovaps [rsp+0x50], xmm6
00007531fdbda53e  vmovaps [rsp+0x60], xmm7
00007531fdbda544  vmovaps [rsp+0x70], xmm8
00007531fdbda54a  vmovaps [rsp+0x80], xmm9
00007531fdbda553  vmovaps [rsp+0x90], xmm10
00007531fdbda55c  vmovaps [rsp+0xA0], xmm11
00007531fdbda565  vmovaps [rsp+0xB0], xmm12
00007531fdbda56e  vmovaps [rsp+0xC0], xmm13
00007531fdbda577  vmovaps [rsp+0xD0], xmm14
00007531fdbda580  vmovaps [rsp+0xE0], xmm15
00007531fdbda589  sub rsp, 0x30
00007531fdbda58d  movaps [rsp], xmm1
00007531fdbda591  movaps [rsp+0x10], xmm6
00007531fdbda596  movaps [rsp+0x20], xmm15
00007531fdbda59c  lea rdi, [rsp]
00007531fdbda5a0  mov esi, 0x00
00007531fdbda5a5  mov rax, 0x59ED111DF530
00007531fdbda5af  call rax
00007531fdbda5b1  movaps xmm1, [rsp]
00007531fdbda5b5  add rsp, 0x30
00007531fdbda5b9  vmovaps xmm0, [rsp]
00007531fdbda5be  vmovaps xmm2, [rsp+0x10]
00007531fdbda5c4  vmovaps xmm3, [rsp+0x20]
00007531fdbda5ca  vmovaps xmm4, [rsp+0x30]
00007531fdbda5d0  vmovaps xmm5, [rsp+0x40]
00007531fdbda5d6  vmovaps xmm6, [rsp+0x50]
00007531fdbda5dc  vmovaps xmm7, [rsp+0x60]
00007531fdbda5e2  vmovaps xmm8, [rsp+0x70]
00007531fdbda5e8  vmovaps xmm9, [rsp+0x80]
00007531fdbda5f1  vmovaps xmm10, [rsp+0x90]
00007531fdbda5fa  vmovaps xmm11, [rsp+0xA0]
00007531fdbda603  vmovaps xmm12, [rsp+0xB0]
00007531fdbda60c  vmovaps xmm13, [rsp+0xC0]
00007531fdbda615  vmovaps xmm14, [rsp+0xD0]
00007531fdbda61e  vmovaps xmm15, [rsp+0xE0]
00007531fdbda627  add rsp, 0xF0
00007531fdbda62e  pop r11
00007531fdbda630  pop r10
00007531fdbda632  pop r9
00007531fdbda634  pop r8
00007531fdbda636  pop rsi
00007531fdbda637  pop rdi
00007531fdbda638  pop rdx
00007531fdbda639  pop rcx
00007531fdbda63a  pop rax
00007531fdbda63b  add rsp, 0x08
00007531fdbda63f  jmp 0x00007531FDBD8E48
00007531fdbda644  call 0x00007531FDAE5820
00007531fdbda649  jmp 0x00007531FDBD8E55
00007531fdbda64e  sub rsp, 0x08
00007531fdbda652  push rax
00007531fdbda653  push rcx
00007531fdbda654  push rdx
00007531fdbda655  push rdi
00007531fdbda656  push rsi
00007531fdbda657  push r8
00007531fdbda659  push r9
00007531fdbda65b  push r10
00007531fdbda65d  push r11
00007531fdbda65f  sub rsp, 0xF0
00007531fdbda666  vmovaps [rsp], xmm0
00007531fdbda66b  vmovaps [rsp+0x10], xmm1
00007531fdbda671  vmovaps [rsp+0x20], xmm2
00007531fdbda677  vmovaps [rsp+0x30], xmm3
00007531fdbda67d  vmovaps [rsp+0x40], xmm4
00007531fdbda683  vmovaps [rsp+0x50], xmm5
00007531fdbda689  vmovaps [rsp+0x60], xmm6
00007531fdbda68f  vmovaps [rsp+0x70], xmm7
00007531fdbda695  vmovaps [rsp+0x80], xmm8
00007531fdbda69e  vmovaps [rsp+0x90], xmm9
00007531fdbda6a7  vmovaps [rsp+0xA0], xmm10
00007531fdbda6b0  vmovaps [rsp+0xB0], xmm11
00007531fdbda6b9  vmovaps [rsp+0xC0], xmm12
00007531fdbda6c2  vmovaps [rsp+0xD0], xmm13
00007531fdbda6cb  vmovaps [rsp+0xE0], xmm15
00007531fdbda6d4  sub rsp, 0x30
00007531fdbda6d8  movaps [rsp], xmm14
00007531fdbda6dd  movaps [rsp+0x10], xmm4
00007531fdbda6e2  movaps [rsp+0x20], xmm3
00007531fdbda6e7  lea rdi, [rsp]
00007531fdbda6eb  mov esi, 0x00
00007531fdbda6f0  mov rax, 0x59ED111DF530
00007531fdbda6fa  call rax
00007531fdbda6fc  movaps xmm14, [rsp]
00007531fdbda701  add rsp, 0x30
00007531fdbda705  vmovaps xmm0, [rsp]
00007531fdbda70a  vmovaps xmm1, [rsp+0x10]
00007531fdbda710  vmovaps xmm2, [rsp+0x20]
00007531fdbda716  vmovaps xmm3, [rsp+0x30]
00007531fdbda71c  vmovaps xmm4, [rsp+0x40]
00007531fdbda722  vmovaps xmm5, [rsp+0x50]
00007531fdbda728  vmovaps xmm6, [rsp+0x60]
00007531fdbda72e  vmovaps xmm7, [rsp+0x70]
00007531fdbda734  vmovaps xmm8, [rsp+0x80]
00007531fdbda73d  vmovaps xmm9, [rsp+0x90]
00007531fdbda746  vmovaps xmm10, [rsp+0xA0]
00007531fdbda74f  vmovaps xmm11, [rsp+0xB0]
00007531fdbda758  vmovaps xmm12, [rsp+0xC0]
00007531fdbda761  vmovaps xmm13, [rsp+0xD0]
00007531fdbda76a  vmovaps xmm15, [rsp+0xE0]
00007531fdbda773  add rsp, 0xF0
00007531fdbda77a  pop r11
00007531fdbda77c  pop r10
00007531fdbda77e  pop r9
00007531fdbda780  pop r8
00007531fdbda782  pop rsi
00007531fdbda783  pop rdi
00007531fdbda784  pop rdx
00007531fdbda785  pop rcx
00007531fdbda786  pop rax
00007531fdbda787  add rsp, 0x08
00007531fdbda78b  jmp 0x00007531FDBD8E6F
00007531fdbda790  sub rsp, 0x08
00007531fdbda794  push rax
00007531fdbda795  push rcx
00007531fdbda796  push rdx
00007531fdbda797  push rdi
00007531fdbda798  push rsi
00007531fdbda799  push r8
00007531fdbda79b  push r9
00007531fdbda79d  push r10
00007531fdbda79f  push r11
00007531fdbda7a1  sub rsp, 0xF0
00007531fdbda7a8  vmovaps [rsp], xmm0
00007531fdbda7ad  vmovaps [rsp+0x10], xmm1
00007531fdbda7b3  vmovaps [rsp+0x20], xmm2
00007531fdbda7b9  vmovaps [rsp+0x30], xmm3
00007531fdbda7bf  vmovaps [rsp+0x40], xmm4
00007531fdbda7c5  vmovaps [rsp+0x50], xmm5
00007531fdbda7cb  vmovaps [rsp+0x60], xmm7
00007531fdbda7d1  vmovaps [rsp+0x70], xmm8
00007531fdbda7d7  vmovaps [rsp+0x80], xmm9
00007531fdbda7e0  vmovaps [rsp+0x90], xmm10
00007531fdbda7e9  vmovaps [rsp+0xA0], xmm11
00007531fdbda7f2  vmovaps [rsp+0xB0], xmm12
00007531fdbda7fb  vmovaps [rsp+0xC0], xmm13
00007531fdbda804  vmovaps [rsp+0xD0], xmm14
00007531fdbda80d  vmovaps [rsp+0xE0], xmm15
00007531fdbda816  sub rsp, 0x30
00007531fdbda81a  movaps [rsp], xmm6
00007531fdbda81e  movaps [rsp+0x10], xmm9
00007531fdbda824  movaps [rsp+0x20], xmm7
00007531fdbda829  lea rdi, [rsp]
00007531fdbda82d  mov esi, 0x00
00007531fdbda832  mov rax, 0x59ED111DF530
00007531fdbda83c  call rax
00007531fdbda83e  movaps xmm6, [rsp]
00007531fdbda842  add rsp, 0x30
00007531fdbda846  vmovaps xmm0, [rsp]
00007531fdbda84b  vmovaps xmm1, [rsp+0x10]
00007531fdbda851  vmovaps xmm2, [rsp+0x20]
00007531fdbda857  vmovaps xmm3, [rsp+0x30]
00007531fdbda85d  vmovaps xmm4, [rsp+0x40]
00007531fdbda863  vmovaps xmm5, [rsp+0x50]
00007531fdbda869  vmovaps xmm7, [rsp+0x60]
00007531fdbda86f  vmovaps xmm8, [rsp+0x70]
00007531fdbda875  vmovaps xmm9, [rsp+0x80]
00007531fdbda87e  vmovaps xmm10, [rsp+0x90]
00007531fdbda887  vmovaps xmm11, [rsp+0xA0]
00007531fdbda890  vmovaps xmm12, [rsp+0xB0]
00007531fdbda899  vmovaps xmm13, [rsp+0xC0]
00007531fdbda8a2  vmovaps xmm14, [rsp+0xD0]
00007531fdbda8ab  vmovaps xmm15, [rsp+0xE0]
00007531fdbda8b4  add rsp, 0xF0
00007531fdbda8bb  pop r11
00007531fdbda8bd  pop r10
00007531fdbda8bf  pop r9
00007531fdbda8c1  pop r8
00007531fdbda8c3  pop rsi
00007531fdbda8c4  pop rdi
00007531fdbda8c5  pop rdx
00007531fdbda8c6  pop rcx
00007531fdbda8c7  pop rax
00007531fdbda8c8  add rsp, 0x08
00007531fdbda8cc  jmp 0x00007531FDBD8E87
00007531fdbda8d1  sub rsp, 0x08
00007531fdbda8d5  push rax
00007531fdbda8d6  push rcx
00007531fdbda8d7  push rdx
00007531fdbda8d8  push rdi
00007531fdbda8d9  push rsi
00007531fdbda8da  push r8
00007531fdbda8dc  push r9
00007531fdbda8de  push r10
00007531fdbda8e0  push r11
00007531fdbda8e2  sub rsp, 0xF0
00007531fdbda8e9  vmovaps [rsp], xmm0
00007531fdbda8ee  vmovaps [rsp+0x10], xmm1
00007531fdbda8f4  vmovaps [rsp+0x20], xmm2
00007531fdbda8fa  vmovaps [rsp+0x30], xmm3
00007531fdbda900  vmovaps [rsp+0x40], xmm4
00007531fdbda906  vmovaps [rsp+0x50], xmm5
00007531fdbda90c  vmovaps [rsp+0x60], xmm6
00007531fdbda912  vmovaps [rsp+0x70], xmm8
00007531fdbda918  vmovaps [rsp+0x80], xmm9
00007531fdbda921  vmovaps [rsp+0x90], xmm10
00007531fdbda92a  vmovaps [rsp+0xA0], xmm11
00007531fdbda933  vmovaps [rsp+0xB0], xmm12
00007531fdbda93c  vmovaps [rsp+0xC0], xmm13
00007531fdbda945  vmovaps [rsp+0xD0], xmm14
00007531fdbda94e  vmovaps [rsp+0xE0], xmm15
00007531fdbda957  sub rsp, 0x30
00007531fdbda95b  movaps [rsp], xmm7
00007531fdbda95f  movaps [rsp+0x10], xmm4
00007531fdbda964  movaps [rsp+0x20], xmm9
00007531fdbda96a  lea rdi, [rsp]
00007531fdbda96e  mov esi, 0x00
00007531fdbda973  mov rax, 0x59ED111DF530
00007531fdbda97d  call rax
00007531fdbda97f  movaps xmm7, [rsp]
00007531fdbda983  add rsp, 0x30
00007531fdbda987  vmovaps xmm0, [rsp]
00007531fdbda98c  vmovaps xmm1, [rsp+0x10]
00007531fdbda992  vmovaps xmm2, [rsp+0x20]
00007531fdbda998  vmovaps xmm3, [rsp+0x30]
00007531fdbda99e  vmovaps xmm4, [rsp+0x40]
00007531fdbda9a4  vmovaps xmm5, [rsp+0x50]
00007531fdbda9aa  vmovaps xmm6, [rsp+0x60]
00007531fdbda9b0  vmovaps xmm8, [rsp+0x70]
00007531fdbda9b6  vmovaps xmm9, [rsp+0x80]
00007531fdbda9bf  vmovaps xmm10, [rsp+0x90]
00007531fdbda9c8  vmovaps xmm11, [rsp+0xA0]
00007531fdbda9d1  vmovaps xmm12, [rsp+0xB0]
00007531fdbda9da  vmovaps xmm13, [rsp+0xC0]
00007531fdbda9e3  vmovaps xmm14, [rsp+0xD0]
00007531fdbda9ec  vmovaps xmm15, [rsp+0xE0]
00007531fdbda9f5  add rsp, 0xF0
00007531fdbda9fc  pop r11
00007531fdbda9fe  pop r10
00007531fdbdaa00  pop r9
00007531fdbdaa02  pop r8
00007531fdbdaa04  pop rsi
00007531fdbdaa05  pop rdi
00007531fdbdaa06  pop rdx
00007531fdbdaa07  pop rcx
00007531fdbdaa08  pop rax
00007531fdbdaa09  add rsp, 0x08
00007531fdbdaa0d  jmp 0x00007531FDBD8EB4
00007531fdbdaa12  sub rsp, 0x08
00007531fdbdaa16  push rax
00007531fdbdaa17  push rcx
00007531fdbdaa18  push rdx
00007531fdbdaa19  push rdi
00007531fdbdaa1a  push rsi
00007531fdbdaa1b  push r8
00007531fdbdaa1d  push r9
00007531fdbdaa1f  push r10
00007531fdbdaa21  push r11
00007531fdbdaa23  sub rsp, 0xF0
00007531fdbdaa2a  vmovaps [rsp], xmm0
00007531fdbdaa2f  vmovaps [rsp+0x10], xmm1
00007531fdbdaa35  vmovaps [rsp+0x20], xmm2
00007531fdbdaa3b  vmovaps [rsp+0x30], xmm3
00007531fdbdaa41  vmovaps [rsp+0x40], xmm5
00007531fdbdaa47  vmovaps [rsp+0x50], xmm6
00007531fdbdaa4d  vmovaps [rsp+0x60], xmm7
00007531fdbdaa53  vmovaps [rsp+0x70], xmm8
00007531fdbdaa59  vmovaps [rsp+0x80], xmm9
00007531fdbdaa62  vmovaps [rsp+0x90], xmm10
00007531fdbdaa6b  vmovaps [rsp+0xA0], xmm11
00007531fdbdaa74  vmovaps [rsp+0xB0], xmm12
00007531fdbdaa7d  vmovaps [rsp+0xC0], xmm13
00007531fdbdaa86  vmovaps [rsp+0xD0], xmm14
00007531fdbdaa8f  vmovaps [rsp+0xE0], xmm15
00007531fdbdaa98  sub rsp, 0x30
00007531fdbdaa9c  movaps [rsp], xmm4
00007531fdbdaaa0  movaps [rsp+0x10], xmm15
00007531fdbdaaa6  movaps [rsp+0x20], xmm9
00007531fdbdaaac  lea rdi, [rsp]
00007531fdbdaab0  mov esi, 0x00
00007531fdbdaab5  mov rax, 0x59ED111DF530
00007531fdbdaabf  call rax
00007531fdbdaac1  movaps xmm4, [rsp]
00007531fdbdaac5  add rsp, 0x30
00007531fdbdaac9  vmovaps xmm0, [rsp]
00007531fdbdaace  vmovaps xmm1, [rsp+0x10]
00007531fdbdaad4  vmovaps xmm2, [rsp+0x20]
00007531fdbdaada  vmovaps xmm3, [rsp+0x30]
00007531fdbdaae0  vmovaps xmm5, [rsp+0x40]
00007531fdbdaae6  vmovaps xmm6, [rsp+0x50]
00007531fdbdaaec  vmovaps xmm7, [rsp+0x60]
00007531fdbdaaf2  vmovaps xmm8, [rsp+0x70]
00007531fdbdaaf8  vmovaps xmm9, [rsp+0x80]
00007531fdbdab01  vmovaps xmm10, [rsp+0x90]
00007531fdbdab0a  vmovaps xmm11, [rsp+0xA0]
00007531fdbdab13  vmovaps xmm12, [rsp+0xB0]
00007531fdbdab1c  vmovaps xmm13, [rsp+0xC0]
00007531fdbdab25  vmovaps xmm14, [rsp+0xD0]
00007531fdbdab2e  vmovaps xmm15, [rsp+0xE0]
00007531fdbdab37  add rsp, 0xF0
00007531fdbdab3e  pop r11
00007531fdbdab40  pop r10
00007531fdbdab42  pop r9
00007531fdbdab44  pop r8
00007531fdbdab46  pop rsi
00007531fdbdab47  pop rdi
00007531fdbdab48  pop rdx
00007531fdbdab49  pop rcx
00007531fdbdab4a  pop rax
00007531fdbdab4b  add rsp, 0x08
00007531fdbdab4f  jmp 0x00007531FDBD8ED9
00007531fdbdab54  call 0x00007531FDAE5820
00007531fdbdab59  jmp 0x00007531FDBD8EE6
00007531fdbdab5e  sub rsp, 0x08
00007531fdbdab62  push rax
00007531fdbdab63  push rcx
00007531fdbdab64  push rdx
00007531fdbdab65  push rdi
00007531fdbdab66  push rsi
00007531fdbdab67  push r8
00007531fdbdab69  push r9
00007531fdbdab6b  push r10
00007531fdbdab6d  push r11
00007531fdbdab6f  sub rsp, 0xF0
00007531fdbdab76  vmovaps [rsp], xmm0
00007531fdbdab7b  vmovaps [rsp+0x10], xmm1
00007531fdbdab81  vmovaps [rsp+0x20], xmm2
00007531fdbdab87  vmovaps [rsp+0x30], xmm4
00007531fdbdab8d  vmovaps [rsp+0x40], xmm5
00007531fdbdab93  vmovaps [rsp+0x50], xmm6
00007531fdbdab99  vmovaps [rsp+0x60], xmm7
00007531fdbdab9f  vmovaps [rsp+0x70], xmm8
00007531fdbdaba5  vmovaps [rsp+0x80], xmm9
00007531fdbdabae  vmovaps [rsp+0x90], xmm10
00007531fdbdabb7  vmovaps [rsp+0xA0], xmm11
00007531fdbdabc0  vmovaps [rsp+0xB0], xmm12
00007531fdbdabc9  vmovaps [rsp+0xC0], xmm13
00007531fdbdabd2  vmovaps [rsp+0xD0], xmm14
00007531fdbdabdb  vmovaps [rsp+0xE0], xmm15
00007531fdbdabe4  sub rsp, 0x30
00007531fdbdabe8  movaps [rsp], xmm3
00007531fdbdabec  movaps [rsp+0x10], xmm1
00007531fdbdabf1  movaps [rsp+0x20], xmm9
00007531fdbdabf7  lea rdi, [rsp]
00007531fdbdabfb  mov esi, 0x00
00007531fdbdac00  mov rax, 0x59ED111DF530
00007531fdbdac0a  call rax
00007531fdbdac0c  movaps xmm3, [rsp]
00007531fdbdac10  add rsp, 0x30
00007531fdbdac14  vmovaps xmm0, [rsp]
00007531fdbdac19  vmovaps xmm1, [rsp+0x10]
00007531fdbdac1f  vmovaps xmm2, [rsp+0x20]
00007531fdbdac25  vmovaps xmm4, [rsp+0x30]
00007531fdbdac2b  vmovaps xmm5, [rsp+0x40]
00007531fdbdac31  vmovaps xmm6, [rsp+0x50]
00007531fdbdac37  vmovaps xmm7, [rsp+0x60]
00007531fdbdac3d  vmovaps xmm8, [rsp+0x70]
00007531fdbdac43  vmovaps xmm9, [rsp+0x80]
00007531fdbdac4c  vmovaps xmm10, [rsp+0x90]
00007531fdbdac55  vmovaps xmm11, [rsp+0xA0]
00007531fdbdac5e  vmovaps xmm12, [rsp+0xB0]
00007531fdbdac67  vmovaps xmm13, [rsp+0xC0]
00007531fdbdac70  vmovaps xmm14, [rsp+0xD0]
00007531fdbdac79  vmovaps xmm15, [rsp+0xE0]
00007531fdbdac82  add rsp, 0xF0
00007531fdbdac89  pop r11
00007531fdbdac8b  pop r10
00007531fdbdac8d  pop r9
00007531fdbdac8f  pop r8
00007531fdbdac91  pop rsi
00007531fdbdac92  pop rdi
00007531fdbdac93  pop rdx
00007531fdbdac94  pop rcx
00007531fdbdac95  pop rax
00007531fdbdac96  add rsp, 0x08
00007531fdbdac9a  jmp 0x00007531FDBD8F23
00007531fdbdac9f  sub rsp, 0x08
00007531fdbdaca3  push rax
00007531fdbdaca4  push rcx
00007531fdbdaca5  push rdx
00007531fdbdaca6  push rdi
00007531fdbdaca7  push rsi
00007531fdbdaca8  push r8
00007531fdbdacaa  push r9
00007531fdbdacac  push r10
00007531fdbdacae  push r11
00007531fdbdacb0  sub rsp, 0xF0
00007531fdbdacb7  vmovaps [rsp], xmm0
00007531fdbdacbc  vmovaps [rsp+0x10], xmm2
00007531fdbdacc2  vmovaps [rsp+0x20], xmm3
00007531fdbdacc8  vmovaps [rsp+0x30], xmm4
00007531fdbdacce  vmovaps [rsp+0x40], xmm5
00007531fdbdacd4  vmovaps [rsp+0x50], xmm6
00007531fdbdacda  vmovaps [rsp+0x60], xmm7
00007531fdbdace0  vmovaps [rsp+0x70], xmm8
00007531fdbdace6  vmovaps [rsp+0x80], xmm9
00007531fdbdacef  vmovaps [rsp+0x90], xmm10
00007531fdbdacf8  vmovaps [rsp+0xA0], xmm11
00007531fdbdad01  vmovaps [rsp+0xB0], xmm12
00007531fdbdad0a  vmovaps [rsp+0xC0], xmm13
00007531fdbdad13  vmovaps [rsp+0xD0], xmm14
00007531fdbdad1c  vmovaps [rsp+0xE0], xmm15
00007531fdbdad25  sub rsp, 0x30
00007531fdbdad29  movaps [rsp], xmm1
00007531fdbdad2d  movaps [rsp+0x10], xmm15
00007531fdbdad33  movaps [rsp+0x20], xmm9
00007531fdbdad39  lea rdi, [rsp]
00007531fdbdad3d  mov esi, 0x00
00007531fdbdad42  mov rax, 0x59ED111DF530
00007531fdbdad4c  call rax
00007531fdbdad4e  movaps xmm1, [rsp]
00007531fdbdad52  add rsp, 0x30
00007531fdbdad56  vmovaps xmm0, [rsp]
00007531fdbdad5b  vmovaps xmm2, [rsp+0x10]
00007531fdbdad61  vmovaps xmm3, [rsp+0x20]
00007531fdbdad67  vmovaps xmm4, [rsp+0x30]
00007531fdbdad6d  vmovaps xmm5, [rsp+0x40]
00007531fdbdad73  vmovaps xmm6, [rsp+0x50]
00007531fdbdad79  vmovaps xmm7, [rsp+0x60]
00007531fdbdad7f  vmovaps xmm8, [rsp+0x70]
00007531fdbdad85  vmovaps xmm9, [rsp+0x80]
00007531fdbdad8e  vmovaps xmm10, [rsp+0x90]
00007531fdbdad97  vmovaps xmm11, [rsp+0xA0]
00007531fdbdada0  vmovaps xmm12, [rsp+0xB0]
00007531fdbdada9  vmovaps xmm13, [rsp+0xC0]
00007531fdbdadb2  vmovaps xmm14, [rsp+0xD0]
00007531fdbdadbb  vmovaps xmm15, [rsp+0xE0]
00007531fdbdadc4  add rsp, 0xF0
00007531fdbdadcb  pop r11
00007531fdbdadcd  pop r10
00007531fdbdadcf  pop r9
00007531fdbdadd1  pop r8
00007531fdbdadd3  pop rsi
00007531fdbdadd4  pop rdi
00007531fdbdadd5  pop rdx
00007531fdbdadd6  pop rcx
00007531fdbdadd7  pop rax
00007531fdbdadd8  add rsp, 0x08
00007531fdbdaddc  jmp 0x00007531FDBD8FAB
00007531fdbdade1  call 0x00007531FDAE5820
00007531fdbdade6  jmp 0x00007531FDBD8FB8
00007531fdbdadeb  sub rsp, 0x08
00007531fdbdadef  push rax
00007531fdbdadf0  push rcx
00007531fdbdadf1  push rdx
00007531fdbdadf2  push rdi
00007531fdbdadf3  push rsi
00007531fdbdadf4  push r8
00007531fdbdadf6  push r9
00007531fdbdadf8  push r10
00007531fdbdadfa  push r11
00007531fdbdadfc  sub rsp, 0xF0
00007531fdbdae03  vmovaps [rsp], xmm0
00007531fdbdae08  vmovaps [rsp+0x10], xmm2
00007531fdbdae0e  vmovaps [rsp+0x20], xmm3
00007531fdbdae14  vmovaps [rsp+0x30], xmm4
00007531fdbdae1a  vmovaps [rsp+0x40], xmm5
00007531fdbdae20  vmovaps [rsp+0x50], xmm6
00007531fdbdae26  vmovaps [rsp+0x60], xmm7
00007531fdbdae2c  vmovaps [rsp+0x70], xmm8
00007531fdbdae32  vmovaps [rsp+0x80], xmm9
00007531fdbdae3b  vmovaps [rsp+0x90], xmm10
00007531fdbdae44  vmovaps [rsp+0xA0], xmm11
00007531fdbdae4d  vmovaps [rsp+0xB0], xmm12
00007531fdbdae56  vmovaps [rsp+0xC0], xmm13
00007531fdbdae5f  vmovaps [rsp+0xD0], xmm14
00007531fdbdae68  vmovaps [rsp+0xE0], xmm15
00007531fdbdae71  sub rsp, 0x30
00007531fdbdae75  movaps [rsp], xmm1
00007531fdbdae79  movaps [rsp+0x10], xmm5
00007531fdbdae7e  movaps [rsp+0x20], xmm7
00007531fdbdae83  lea rdi, [rsp]
00007531fdbdae87  mov esi, 0x00
00007531fdbdae8c  mov rax, 0x59ED111DF530
00007531fdbdae96  call rax
00007531fdbdae98  movaps xmm1, [rsp]
00007531fdbdae9c  add rsp, 0x30
00007531fdbdaea0  vmovaps xmm0, [rsp]
00007531fdbdaea5  vmovaps xmm2, [rsp+0x10]
00007531fdbdaeab  vmovaps xmm3, [rsp+0x20]
00007531fdbdaeb1  vmovaps xmm4, [rsp+0x30]
00007531fdbdaeb7  vmovaps xmm5, [rsp+0x40]
00007531fdbdaebd  vmovaps xmm6, [rsp+0x50]
00007531fdbdaec3  vmovaps xmm7, [rsp+0x60]
00007531fdbdaec9  vmovaps xmm8, [rsp+0x70]
00007531fdbdaecf  vmovaps xmm9, [rsp+0x80]
00007531fdbdaed8  vmovaps xmm10, [rsp+0x90]
00007531fdbdaee1  vmovaps xmm11, [rsp+0xA0]
00007531fdbdaeea  vmovaps xmm12, [rsp+0xB0]
00007531fdbdaef3  vmovaps xmm13, [rsp+0xC0]
00007531fdbdaefc  vmovaps xmm14, [rsp+0xD0]
00007531fdbdaf05  vmovaps xmm15, [rsp+0xE0]
00007531fdbdaf0e  add rsp, 0xF0
00007531fdbdaf15  pop r11
00007531fdbdaf17  pop r10
00007531fdbdaf19  pop r9
00007531fdbdaf1b  pop r8
00007531fdbdaf1d  pop rsi
00007531fdbdaf1e  pop rdi
00007531fdbdaf1f  pop rdx
00007531fdbdaf20  pop rcx
00007531fdbdaf21  pop rax
00007531fdbdaf22  add rsp, 0x08
00007531fdbdaf26  jmp 0x00007531FDBD905D
00007531fdbdaf2b  sub rsp, 0x08
00007531fdbdaf2f  push rax
00007531fdbdaf30  push rcx
00007531fdbdaf31  push rdx
00007531fdbdaf32  push rdi
00007531fdbdaf33  push rsi
00007531fdbdaf34  push r8
00007531fdbdaf36  push r9
00007531fdbdaf38  push r10
00007531fdbdaf3a  push r11
00007531fdbdaf3c  sub rsp, 0xF0
00007531fdbdaf43  vmovaps [rsp], xmm0
00007531fdbdaf48  vmovaps [rsp+0x10], xmm1
00007531fdbdaf4e  vmovaps [rsp+0x20], xmm2
00007531fdbdaf54  vmovaps [rsp+0x30], xmm3
00007531fdbdaf5a  vmovaps [rsp+0x40], xmm4
00007531fdbdaf60  vmovaps [rsp+0x50], xmm5
00007531fdbdaf66  vmovaps [rsp+0x60], xmm6
00007531fdbdaf6c  vmovaps [rsp+0x70], xmm8
00007531fdbdaf72  vmovaps [rsp+0x80], xmm9
00007531fdbdaf7b  vmovaps [rsp+0x90], xmm10
00007531fdbdaf84  vmovaps [rsp+0xA0], xmm11
00007531fdbdaf8d  vmovaps [rsp+0xB0], xmm12
00007531fdbdaf96  vmovaps [rsp+0xC0], xmm13
00007531fdbdaf9f  vmovaps [rsp+0xD0], xmm14
00007531fdbdafa8  vmovaps [rsp+0xE0], xmm15
00007531fdbdafb1  sub rsp, 0x30
00007531fdbdafb5  movaps [rsp], xmm7
00007531fdbdafb9  movaps [rsp+0x10], xmm5
00007531fdbdafbe  movaps [rsp+0x20], xmm15
00007531fdbdafc4  lea rdi, [rsp]
00007531fdbdafc8  mov esi, 0x00
00007531fdbdafcd  mov rax, 0x59ED111DF530
00007531fdbdafd7  call rax
00007531fdbdafd9  movaps xmm7, [rsp]
00007531fdbdafdd  add rsp, 0x30
00007531fdbdafe1  vmovaps xmm0, [rsp]
00007531fdbdafe6  vmovaps xmm1, [rsp+0x10]
00007531fdbdafec  vmovaps xmm2, [rsp+0x20]
00007531fdbdaff2  vmovaps xmm3, [rsp+0x30]
00007531fdbdaff8  vmovaps xmm4, [rsp+0x40]
00007531fdbdaffe  vmovaps xmm5, [rsp+0x50]
00007531fdbdb004  vmovaps xmm6, [rsp+0x60]
00007531fdbdb00a  vmovaps xmm8, [rsp+0x70]
00007531fdbdb010  vmovaps xmm9, [rsp+0x80]
00007531fdbdb019  vmovaps xmm10, [rsp+0x90]
00007531fdbdb022  vmovaps xmm11, [rsp+0xA0]
00007531fdbdb02b  vmovaps xmm12, [rsp+0xB0]
00007531fdbdb034  vmovaps xmm13, [rsp+0xC0]
00007531fdbdb03d  vmovaps xmm14, [rsp+0xD0]
00007531fdbdb046  vmovaps xmm15, [rsp+0xE0]
00007531fdbdb04f  add rsp, 0xF0
00007531fdbdb056  pop r11
00007531fdbdb058  pop r10
00007531fdbdb05a  pop r9
00007531fdbdb05c  pop r8
00007531fdbdb05e  pop rsi
00007531fdbdb05f  pop rdi
00007531fdbdb060  pop rdx
00007531fdbdb061  pop rcx
00007531fdbdb062  pop rax
00007531fdbdb063  add rsp, 0x08
00007531fdbdb067  jmp 0x00007531FDBD9093
00007531fdbdb06c  call 0x00007531FDAD64F0
00007531fdbdb071  jmp 0x00007531FDBD90A0
00007531fdbdb076  sub rsp, 0x08
00007531fdbdb07a  push rax
00007531fdbdb07b  push rcx
00007531fdbdb07c  push rdx
00007531fdbdb07d  push rdi
00007531fdbdb07e  push rsi
00007531fdbdb07f  push r8
00007531fdbdb081  push r9
00007531fdbdb083  push r10
00007531fdbdb085  push r11
00007531fdbdb087  sub rsp, 0xF0
00007531fdbdb08e  vmovaps [rsp], xmm0
00007531fdbdb093  vmovaps [rsp+0x10], xmm1
00007531fdbdb099  vmovaps [rsp+0x20], xmm2
00007531fdbdb09f  vmovaps [rsp+0x30], xmm3
00007531fdbdb0a5  vmovaps [rsp+0x40], xmm4
00007531fdbdb0ab  vmovaps [rsp+0x50], xmm5
00007531fdbdb0b1  vmovaps [rsp+0x60], xmm6
00007531fdbdb0b7  vmovaps [rsp+0x70], xmm7
00007531fdbdb0bd  vmovaps [rsp+0x80], xmm8
00007531fdbdb0c6  vmovaps [rsp+0x90], xmm9
00007531fdbdb0cf  vmovaps [rsp+0xA0], xmm10
00007531fdbdb0d8  vmovaps [rsp+0xB0], xmm11
00007531fdbdb0e1  vmovaps [rsp+0xC0], xmm12
00007531fdbdb0ea  vmovaps [rsp+0xD0], xmm13
00007531fdbdb0f3  vmovaps [rsp+0xE0], xmm14
00007531fdbdb0fc  sub rsp, 0x30
00007531fdbdb100  movaps [rsp], xmm15
00007531fdbdb105  movaps [rsp+0x10], xmm5
00007531fdbdb10a  movaps [rsp+0x20], xmm3
00007531fdbdb10f  lea rdi, [rsp]
00007531fdbdb113  mov esi, 0x00
00007531fdbdb118  mov rax, 0x59ED111DF530
00007531fdbdb122  call rax
00007531fdbdb124  movaps xmm15, [rsp]
00007531fdbdb129  add rsp, 0x30
00007531fdbdb12d  vmovaps xmm0, [rsp]
00007531fdbdb132  vmovaps xmm1, [rsp+0x10]
00007531fdbdb138  vmovaps xmm2, [rsp+0x20]
00007531fdbdb13e  vmovaps xmm3, [rsp+0x30]
00007531fdbdb144  vmovaps xmm4, [rsp+0x40]
00007531fdbdb14a  vmovaps xmm5, [rsp+0x50]
00007531fdbdb150  vmovaps xmm6, [rsp+0x60]
00007531fdbdb156  vmovaps xmm7, [rsp+0x70]
00007531fdbdb15c  vmovaps xmm8, [rsp+0x80]
00007531fdbdb165  vmovaps xmm9, [rsp+0x90]
00007531fdbdb16e  vmovaps xmm10, [rsp+0xA0]
00007531fdbdb177  vmovaps xmm11, [rsp+0xB0]
00007531fdbdb180  vmovaps xmm12, [rsp+0xC0]
00007531fdbdb189  vmovaps xmm13, [rsp+0xD0]
00007531fdbdb192  vmovaps xmm14, [rsp+0xE0]
00007531fdbdb19b  add rsp, 0xF0
00007531fdbdb1a2  pop r11
00007531fdbdb1a4  pop r10
00007531fdbdb1a6  pop r9
00007531fdbdb1a8  pop r8
00007531fdbdb1aa  pop rsi
00007531fdbdb1ab  pop rdi
00007531fdbdb1ac  pop rdx
00007531fdbdb1ad  pop rcx
00007531fdbdb1ae  pop rax
00007531fdbdb1af  add rsp, 0x08
00007531fdbdb1b3  jmp 0x00007531FDBD90C6
00007531fdbdb1b8  sub rsp, 0x08
00007531fdbdb1bc  push rax
00007531fdbdb1bd  push rcx
00007531fdbdb1be  push rdx
00007531fdbdb1bf  push rdi
00007531fdbdb1c0  push rsi
00007531fdbdb1c1  push r8
00007531fdbdb1c3  push r9
00007531fdbdb1c5  push r10
00007531fdbdb1c7  push r11
00007531fdbdb1c9  sub rsp, 0xF0
00007531fdbdb1d0  vmovaps [rsp], xmm0
00007531fdbdb1d5  vmovaps [rsp+0x10], xmm2
00007531fdbdb1db  vmovaps [rsp+0x20], xmm3
00007531fdbdb1e1  vmovaps [rsp+0x30], xmm4
00007531fdbdb1e7  vmovaps [rsp+0x40], xmm5
00007531fdbdb1ed  vmovaps [rsp+0x50], xmm6
00007531fdbdb1f3  vmovaps [rsp+0x60], xmm7
00007531fdbdb1f9  vmovaps [rsp+0x70], xmm8
00007531fdbdb1ff  vmovaps [rsp+0x80], xmm9
00007531fdbdb208  vmovaps [rsp+0x90], xmm10
00007531fdbdb211  vmovaps [rsp+0xA0], xmm11
00007531fdbdb21a  vmovaps [rsp+0xB0], xmm12
00007531fdbdb223  vmovaps [rsp+0xC0], xmm13
00007531fdbdb22c  vmovaps [rsp+0xD0], xmm14
00007531fdbdb235  vmovaps [rsp+0xE0], xmm15
00007531fdbdb23e  sub rsp, 0x30
00007531fdbdb242  movaps [rsp], xmm1
00007531fdbdb246  movaps [rsp+0x10], xmm5
00007531fdbdb24b  movaps [rsp+0x20], xmm4
00007531fdbdb250  lea rdi, [rsp]
00007531fdbdb254  mov esi, 0x00
00007531fdbdb259  mov rax, 0x59ED111DF530
00007531fdbdb263  call rax
00007531fdbdb265  movaps xmm1, [rsp]
00007531fdbdb269  add rsp, 0x30
00007531fdbdb26d  vmovaps xmm0, [rsp]
00007531fdbdb272  vmovaps xmm2, [rsp+0x10]
00007531fdbdb278  vmovaps xmm3, [rsp+0x20]
00007531fdbdb27e  vmovaps xmm4, [rsp+0x30]
00007531fdbdb284  vmovaps xmm5, [rsp+0x40]
00007531fdbdb28a  vmovaps xmm6, [rsp+0x50]
00007531fdbdb290  vmovaps xmm7, [rsp+0x60]
00007531fdbdb296  vmovaps xmm8, [rsp+0x70]
00007531fdbdb29c  vmovaps xmm9, [rsp+0x80]
00007531fdbdb2a5  vmovaps xmm10, [rsp+0x90]
00007531fdbdb2ae  vmovaps xmm11, [rsp+0xA0]
00007531fdbdb2b7  vmovaps xmm12, [rsp+0xB0]
00007531fdbdb2c0  vmovaps xmm13, [rsp+0xC0]
00007531fdbdb2c9  vmovaps xmm14, [rsp+0xD0]
00007531fdbdb2d2  vmovaps xmm15, [rsp+0xE0]
00007531fdbdb2db  add rsp, 0xF0
00007531fdbdb2e2  pop r11
00007531fdbdb2e4  pop r10
00007531fdbdb2e6  pop r9
00007531fdbdb2e8  pop r8
00007531fdbdb2ea  pop rsi
00007531fdbdb2eb  pop rdi
00007531fdbdb2ec  pop rdx
00007531fdbdb2ed  pop rcx
00007531fdbdb2ee  pop rax
00007531fdbdb2ef  add rsp, 0x08
00007531fdbdb2f3  jmp 0x00007531FDBD90E6
00007531fdbdb2f8  sub rsp, 0x08
00007531fdbdb2fc  push rax
00007531fdbdb2fd  push rcx
00007531fdbdb2fe  push rdx
00007531fdbdb2ff  push rdi
00007531fdbdb300  push rsi
00007531fdbdb301  push r8
00007531fdbdb303  push r9
00007531fdbdb305  push r10
00007531fdbdb307  push r11
00007531fdbdb309  sub rsp, 0xF0
00007531fdbdb310  vmovaps [rsp], xmm0
00007531fdbdb315  vmovaps [rsp+0x10], xmm1
00007531fdbdb31b  vmovaps [rsp+0x20], xmm2
00007531fdbdb321  vmovaps [rsp+0x30], xmm3
00007531fdbdb327  vmovaps [rsp+0x40], xmm5
00007531fdbdb32d  vmovaps [rsp+0x50], xmm6
00007531fdbdb333  vmovaps [rsp+0x60], xmm7
00007531fdbdb339  vmovaps [rsp+0x70], xmm8
00007531fdbdb33f  vmovaps [rsp+0x80], xmm9
00007531fdbdb348  vmovaps [rsp+0x90], xmm10
00007531fdbdb351  vmovaps [rsp+0xA0], xmm11
00007531fdbdb35a  vmovaps [rsp+0xB0], xmm12
00007531fdbdb363  vmovaps [rsp+0xC0], xmm13
00007531fdbdb36c  vmovaps [rsp+0xD0], xmm14
00007531fdbdb375  vmovaps [rsp+0xE0], xmm15
00007531fdbdb37e  sub rsp, 0x30
00007531fdbdb382  movaps [rsp], xmm4
00007531fdbdb386  movaps [rsp+0x10], xmm3
00007531fdbdb38b  movaps [rsp+0x20], xmm5
00007531fdbdb390  lea rdi, [rsp]
00007531fdbdb394  mov esi, 0x00
00007531fdbdb399  mov rax, 0x59ED111DF530
00007531fdbdb3a3  call rax
00007531fdbdb3a5  movaps xmm4, [rsp]
00007531fdbdb3a9  add rsp, 0x30
00007531fdbdb3ad  vmovaps xmm0, [rsp]
00007531fdbdb3b2  vmovaps xmm1, [rsp+0x10]
00007531fdbdb3b8  vmovaps xmm2, [rsp+0x20]
00007531fdbdb3be  vmovaps xmm3, [rsp+0x30]
00007531fdbdb3c4  vmovaps xmm5, [rsp+0x40]
00007531fdbdb3ca  vmovaps xmm6, [rsp+0x50]
00007531fdbdb3d0  vmovaps xmm7, [rsp+0x60]
00007531fdbdb3d6  vmovaps xmm8, [rsp+0x70]
00007531fdbdb3dc  vmovaps xmm9, [rsp+0x80]
00007531fdbdb3e5  vmovaps xmm10, [rsp+0x90]
00007531fdbdb3ee  vmovaps xmm11, [rsp+0xA0]
00007531fdbdb3f7  vmovaps xmm12, [rsp+0xB0]
00007531fdbdb400  vmovaps xmm13, [rsp+0xC0]
00007531fdbdb409  vmovaps xmm14, [rsp+0xD0]
00007531fdbdb412  vmovaps xmm15, [rsp+0xE0]
00007531fdbdb41b  add rsp, 0xF0
00007531fdbdb422  pop r11
00007531fdbdb424  pop r10
00007531fdbdb426  pop r9
00007531fdbdb428  pop r8
00007531fdbdb42a  pop rsi
00007531fdbdb42b  pop rdi
00007531fdbdb42c  pop rdx
00007531fdbdb42d  pop rcx
00007531fdbdb42e  pop rax
00007531fdbdb42f  add rsp, 0x08
00007531fdbdb433  jmp 0x00007531FDBD9134
00007531fdbdb438  call 0x00007531FDAD64F0
00007531fdbdb43d  jmp 0x00007531FDBD9141
00007531fdbdb442  sub rsp, 0x08
00007531fdbdb446  push rax
00007531fdbdb447  push rcx
00007531fdbdb448  push rdx
00007531fdbdb449  push rdi
00007531fdbdb44a  push rsi
00007531fdbdb44b  push r8
00007531fdbdb44d  push r9
00007531fdbdb44f  push r10
00007531fdbdb451  push r11
00007531fdbdb453  sub rsp, 0xF0
00007531fdbdb45a  vmovaps [rsp], xmm0
00007531fdbdb45f  vmovaps [rsp+0x10], xmm1
00007531fdbdb465  vmovaps [rsp+0x20], xmm2
00007531fdbdb46b  vmovaps [rsp+0x30], xmm3
00007531fdbdb471  vmovaps [rsp+0x40], xmm4
00007531fdbdb477  vmovaps [rsp+0x50], xmm6
00007531fdbdb47d  vmovaps [rsp+0x60], xmm7
00007531fdbdb483  vmovaps [rsp+0x70], xmm8
00007531fdbdb489  vmovaps [rsp+0x80], xmm9
00007531fdbdb492  vmovaps [rsp+0x90], xmm10
00007531fdbdb49b  vmovaps [rsp+0xA0], xmm11
00007531fdbdb4a4  vmovaps [rsp+0xB0], xmm12
00007531fdbdb4ad  vmovaps [rsp+0xC0], xmm13
00007531fdbdb4b6  vmovaps [rsp+0xD0], xmm14
00007531fdbdb4bf  vmovaps [rsp+0xE0], xmm15
00007531fdbdb4c8  sub rsp, 0x30
00007531fdbdb4cc  movaps [rsp], xmm5
00007531fdbdb4d0  movaps [rsp+0x10], xmm6
00007531fdbdb4d5  movaps [rsp+0x20], xmm3
00007531fdbdb4da  lea rdi, [rsp]
00007531fdbdb4de  mov esi, 0x00
00007531fdbdb4e3  mov rax, 0x59ED111DF530
00007531fdbdb4ed  call rax
00007531fdbdb4ef  movaps xmm5, [rsp]
00007531fdbdb4f3  add rsp, 0x30
00007531fdbdb4f7  vmovaps xmm0, [rsp]
00007531fdbdb4fc  vmovaps xmm1, [rsp+0x10]
00007531fdbdb502  vmovaps xmm2, [rsp+0x20]
00007531fdbdb508  vmovaps xmm3, [rsp+0x30]
00007531fdbdb50e  vmovaps xmm4, [rsp+0x40]
00007531fdbdb514  vmovaps xmm6, [rsp+0x50]
00007531fdbdb51a  vmovaps xmm7, [rsp+0x60]
00007531fdbdb520  vmovaps xmm8, [rsp+0x70]
00007531fdbdb526  vmovaps xmm9, [rsp+0x80]
00007531fdbdb52f  vmovaps xmm10, [rsp+0x90]
00007531fdbdb538  vmovaps xmm11, [rsp+0xA0]
00007531fdbdb541  vmovaps xmm12, [rsp+0xB0]
00007531fdbdb54a  vmovaps xmm13, [rsp+0xC0]
00007531fdbdb553  vmovaps xmm14, [rsp+0xD0]
00007531fdbdb55c  vmovaps xmm15, [rsp+0xE0]
00007531fdbdb565  add rsp, 0xF0
00007531fdbdb56c  pop r11
00007531fdbdb56e  pop r10
00007531fdbdb570  pop r9
00007531fdbdb572  pop r8
00007531fdbdb574  pop rsi
00007531fdbdb575  pop rdi
00007531fdbdb576  pop rdx
00007531fdbdb577  pop rcx
00007531fdbdb578  pop rax
00007531fdbdb579  add rsp, 0x08
00007531fdbdb57d  jmp 0x00007531FDBD9167
00007531fdbdb582  sub rsp, 0x08
00007531fdbdb586  push rax
00007531fdbdb587  push rcx
00007531fdbdb588  push rdx
00007531fdbdb589  push rdi
00007531fdbdb58a  push rsi
00007531fdbdb58b  push r8
00007531fdbdb58d  push r9
00007531fdbdb58f  push r10
00007531fdbdb591  push r11
00007531fdbdb593  sub rsp, 0xF0
00007531fdbdb59a  vmovaps [rsp], xmm0
00007531fdbdb59f  vmovaps [rsp+0x10], xmm1
00007531fdbdb5a5  vmovaps [rsp+0x20], xmm2
00007531fdbdb5ab  vmovaps [rsp+0x30], xmm3
00007531fdbdb5b1  vmovaps [rsp+0x40], xmm4
00007531fdbdb5b7  vmovaps [rsp+0x50], xmm5
00007531fdbdb5bd  vmovaps [rsp+0x60], xmm7
00007531fdbdb5c3  vmovaps [rsp+0x70], xmm8
00007531fdbdb5c9  vmovaps [rsp+0x80], xmm9
00007531fdbdb5d2  vmovaps [rsp+0x90], xmm10
00007531fdbdb5db  vmovaps [rsp+0xA0], xmm11
00007531fdbdb5e4  vmovaps [rsp+0xB0], xmm12
00007531fdbdb5ed  vmovaps [rsp+0xC0], xmm13
00007531fdbdb5f6  vmovaps [rsp+0xD0], xmm14
00007531fdbdb5ff  vmovaps [rsp+0xE0], xmm15
00007531fdbdb608  sub rsp, 0x30
00007531fdbdb60c  movaps [rsp], xmm6
00007531fdbdb610  movaps [rsp+0x10], xmm9
00007531fdbdb616  movaps [rsp+0x20], xmm1
00007531fdbdb61b  lea rdi, [rsp]
00007531fdbdb61f  mov esi, 0x00
00007531fdbdb624  mov rax, 0x59ED111DF530
00007531fdbdb62e  call rax
00007531fdbdb630  movaps xmm6, [rsp]
00007531fdbdb634  add rsp, 0x30
00007531fdbdb638  vmovaps xmm0, [rsp]
00007531fdbdb63d  vmovaps xmm1, [rsp+0x10]
00007531fdbdb643  vmovaps xmm2, [rsp+0x20]
00007531fdbdb649  vmovaps xmm3, [rsp+0x30]
00007531fdbdb64f  vmovaps xmm4, [rsp+0x40]
00007531fdbdb655  vmovaps xmm5, [rsp+0x50]
00007531fdbdb65b  vmovaps xmm7, [rsp+0x60]
00007531fdbdb661  vmovaps xmm8, [rsp+0x70]
00007531fdbdb667  vmovaps xmm9, [rsp+0x80]
00007531fdbdb670  vmovaps xmm10, [rsp+0x90]
00007531fdbdb679  vmovaps xmm11, [rsp+0xA0]
00007531fdbdb682  vmovaps xmm12, [rsp+0xB0]
00007531fdbdb68b  vmovaps xmm13, [rsp+0xC0]
00007531fdbdb694  vmovaps xmm14, [rsp+0xD0]
00007531fdbdb69d  vmovaps xmm15, [rsp+0xE0]
00007531fdbdb6a6  add rsp, 0xF0
00007531fdbdb6ad  pop r11
00007531fdbdb6af  pop r10
00007531fdbdb6b1  pop r9
00007531fdbdb6b3  pop r8
00007531fdbdb6b5  pop rsi
00007531fdbdb6b6  pop rdi
00007531fdbdb6b7  pop rdx
00007531fdbdb6b8  pop rcx
00007531fdbdb6b9  pop rax
00007531fdbdb6ba  add rsp, 0x08
00007531fdbdb6be  jmp 0x00007531FDBD918B
00007531fdbdb6c3  sub rsp, 0x08
00007531fdbdb6c7  push rax
00007531fdbdb6c8  push rcx
00007531fdbdb6c9  push rdx
00007531fdbdb6ca  push rdi
00007531fdbdb6cb  push rsi
00007531fdbdb6cc  push r8
00007531fdbdb6ce  push r9
00007531fdbdb6d0  push r10
00007531fdbdb6d2  push r11
00007531fdbdb6d4  sub rsp, 0xF0
00007531fdbdb6db  vmovaps [rsp], xmm0
00007531fdbdb6e0  vmovaps [rsp+0x10], xmm1
00007531fdbdb6e6  vmovaps [rsp+0x20], xmm2
00007531fdbdb6ec  vmovaps [rsp+0x30], xmm3
00007531fdbdb6f2  vmovaps [rsp+0x40], xmm4
00007531fdbdb6f8  vmovaps [rsp+0x50], xmm5
00007531fdbdb6fe  vmovaps [rsp+0x60], xmm6
00007531fdbdb704  vmovaps [rsp+0x70], xmm7
00007531fdbdb70a  vmovaps [rsp+0x80], xmm8
00007531fdbdb713  vmovaps [rsp+0x90], xmm10
00007531fdbdb71c  vmovaps [rsp+0xA0], xmm11
00007531fdbdb725  vmovaps [rsp+0xB0], xmm12
00007531fdbdb72e  vmovaps [rsp+0xC0], xmm13
00007531fdbdb737  vmovaps [rsp+0xD0], xmm14
00007531fdbdb740  vmovaps [rsp+0xE0], xmm15
00007531fdbdb749  sub rsp, 0x30
00007531fdbdb74d  movaps [rsp], xmm9
00007531fdbdb752  movaps [rsp+0x10], xmm3
00007531fdbdb757  movaps [rsp+0x20], xmm1
00007531fdbdb75c  lea rdi, [rsp]
00007531fdbdb760  mov esi, 0x00
00007531fdbdb765  mov rax, 0x59ED111DF530
00007531fdbdb76f  call rax
00007531fdbdb771  movaps xmm9, [rsp]
00007531fdbdb776  add rsp, 0x30
00007531fdbdb77a  vmovaps xmm0, [rsp]
00007531fdbdb77f  vmovaps xmm1, [rsp+0x10]
00007531fdbdb785  vmovaps xmm2, [rsp+0x20]
00007531fdbdb78b  vmovaps xmm3, [rsp+0x30]
00007531fdbdb791  vmovaps xmm4, [rsp+0x40]
00007531fdbdb797  vmovaps xmm5, [rsp+0x50]
00007531fdbdb79d  vmovaps xmm6, [rsp+0x60]
00007531fdbdb7a3  vmovaps xmm7, [rsp+0x70]
00007531fdbdb7a9  vmovaps xmm8, [rsp+0x80]
00007531fdbdb7b2  vmovaps xmm10, [rsp+0x90]
00007531fdbdb7bb  vmovaps xmm11, [rsp+0xA0]
00007531fdbdb7c4  vmovaps xmm12, [rsp+0xB0]
00007531fdbdb7cd  vmovaps xmm13, [rsp+0xC0]
00007531fdbdb7d6  vmovaps xmm14, [rsp+0xD0]
00007531fdbdb7df  vmovaps xmm15, [rsp+0xE0]
00007531fdbdb7e8  add rsp, 0xF0
00007531fdbdb7ef  pop r11
00007531fdbdb7f1  pop r10
00007531fdbdb7f3  pop r9
00007531fdbdb7f5  pop r8
00007531fdbdb7f7  pop rsi
00007531fdbdb7f8  pop rdi
00007531fdbdb7f9  pop rdx
00007531fdbdb7fa  pop rcx
00007531fdbdb7fb  pop rax
00007531fdbdb7fc  add rsp, 0x08
00007531fdbdb800  jmp 0x00007531FDBD91D7
00007531fdbdb805  call 0x00007531FDAD64F0
00007531fdbdb80a  jmp 0x00007531FDBD91E4
00007531fdbdb80f  sub rsp, 0x08
00007531fdbdb813  push rax
00007531fdbdb814  push rcx
00007531fdbdb815  push rdx
00007531fdbdb816  push rdi
00007531fdbdb817  push rsi
00007531fdbdb818  push r8
00007531fdbdb81a  push r9
00007531fdbdb81c  push r10
00007531fdbdb81e  push r11
00007531fdbdb820  sub rsp, 0xF0
00007531fdbdb827  vmovaps [rsp], xmm0
00007531fdbdb82c  vmovaps [rsp+0x10], xmm1
00007531fdbdb832  vmovaps [rsp+0x20], xmm2
00007531fdbdb838  vmovaps [rsp+0x30], xmm3
00007531fdbdb83e  vmovaps [rsp+0x40], xmm4
00007531fdbdb844  vmovaps [rsp+0x50], xmm5
00007531fdbdb84a  vmovaps [rsp+0x60], xmm6
00007531fdbdb850  vmovaps [rsp+0x70], xmm7
00007531fdbdb856  vmovaps [rsp+0x80], xmm8
00007531fdbdb85f  vmovaps [rsp+0x90], xmm9
00007531fdbdb868  vmovaps [rsp+0xA0], xmm10
00007531fdbdb871  vmovaps [rsp+0xB0], xmm11
00007531fdbdb87a  vmovaps [rsp+0xC0], xmm12
00007531fdbdb883  vmovaps [rsp+0xD0], xmm13
00007531fdbdb88c  vmovaps [rsp+0xE0], xmm14
00007531fdbdb895  sub rsp, 0x30
00007531fdbdb899  movaps [rsp], xmm15
00007531fdbdb89e  movaps [rsp+0x10], xmm3
00007531fdbdb8a3  movaps [rsp+0x20], xmm7
00007531fdbdb8a8  lea rdi, [rsp]
00007531fdbdb8ac  mov esi, 0x00
00007531fdbdb8b1  mov rax, 0x59ED111DF530
00007531fdbdb8bb  call rax
00007531fdbdb8bd  movaps xmm15, [rsp]
00007531fdbdb8c2  add rsp, 0x30
00007531fdbdb8c6  vmovaps xmm0, [rsp]
00007531fdbdb8cb  vmovaps xmm1, [rsp+0x10]
00007531fdbdb8d1  vmovaps xmm2, [rsp+0x20]
00007531fdbdb8d7  vmovaps xmm3, [rsp+0x30]
00007531fdbdb8dd  vmovaps xmm4, [rsp+0x40]
00007531fdbdb8e3  vmovaps xmm5, [rsp+0x50]
00007531fdbdb8e9  vmovaps xmm6, [rsp+0x60]
00007531fdbdb8ef  vmovaps xmm7, [rsp+0x70]
00007531fdbdb8f5  vmovaps xmm8, [rsp+0x80]
00007531fdbdb8fe  vmovaps xmm9, [rsp+0x90]
00007531fdbdb907  vmovaps xmm10, [rsp+0xA0]
00007531fdbdb910  vmovaps xmm11, [rsp+0xB0]
00007531fdbdb919  vmovaps xmm12, [rsp+0xC0]
00007531fdbdb922  vmovaps xmm13, [rsp+0xD0]
00007531fdbdb92b  vmovaps xmm14, [rsp+0xE0]
00007531fdbdb934  add rsp, 0xF0
00007531fdbdb93b  pop r11
00007531fdbdb93d  pop r10
00007531fdbdb93f  pop r9
00007531fdbdb941  pop r8
00007531fdbdb943  pop rsi
00007531fdbdb944  pop rdi
00007531fdbdb945  pop rdx
00007531fdbdb946  pop rcx
00007531fdbdb947  pop rax
00007531fdbdb948  add rsp, 0x08
00007531fdbdb94c  jmp 0x00007531FDBD9210
00007531fdbdb951  sub rsp, 0x08
00007531fdbdb955  push rax
00007531fdbdb956  push rcx
00007531fdbdb957  push rdx
00007531fdbdb958  push rdi
00007531fdbdb959  push rsi
00007531fdbdb95a  push r8
00007531fdbdb95c  push r9
00007531fdbdb95e  push r10
00007531fdbdb960  push r11
00007531fdbdb962  sub rsp, 0xF0
00007531fdbdb969  vmovaps [rsp], xmm0
00007531fdbdb96e  vmovaps [rsp+0x10], xmm1
00007531fdbdb974  vmovaps [rsp+0x20], xmm2
00007531fdbdb97a  vmovaps [rsp+0x30], xmm4
00007531fdbdb980  vmovaps [rsp+0x40], xmm5
00007531fdbdb986  vmovaps [rsp+0x50], xmm6
00007531fdbdb98c  vmovaps [rsp+0x60], xmm7
00007531fdbdb992  vmovaps [rsp+0x70], xmm8
00007531fdbdb998  vmovaps [rsp+0x80], xmm9
00007531fdbdb9a1  vmovaps [rsp+0x90], xmm10
00007531fdbdb9aa  vmovaps [rsp+0xA0], xmm11
00007531fdbdb9b3  vmovaps [rsp+0xB0], xmm12
00007531fdbdb9bc  vmovaps [rsp+0xC0], xmm13
00007531fdbdb9c5  vmovaps [rsp+0xD0], xmm14
00007531fdbdb9ce  vmovaps [rsp+0xE0], xmm15
00007531fdbdb9d7  sub rsp, 0x30
00007531fdbdb9db  movaps [rsp], xmm3
00007531fdbdb9df  movaps [rsp+0x10], xmm1
00007531fdbdb9e4  movaps [rsp+0x20], xmm15
00007531fdbdb9ea  lea rdi, [rsp]
00007531fdbdb9ee  mov esi, 0x00
00007531fdbdb9f3  mov rax, 0x59ED111DF530
00007531fdbdb9fd  call rax
00007531fdbdb9ff  movaps xmm3, [rsp]
00007531fdbdba03  add rsp, 0x30
00007531fdbdba07  vmovaps xmm0, [rsp]
00007531fdbdba0c  vmovaps xmm1, [rsp+0x10]
00007531fdbdba12  vmovaps xmm2, [rsp+0x20]
00007531fdbdba18  vmovaps xmm4, [rsp+0x30]
00007531fdbdba1e  vmovaps xmm5, [rsp+0x40]
00007531fdbdba24  vmovaps xmm6, [rsp+0x50]
00007531fdbdba2a  vmovaps xmm7, [rsp+0x60]
00007531fdbdba30  vmovaps xmm8, [rsp+0x70]
00007531fdbdba36  vmovaps xmm9, [rsp+0x80]
00007531fdbdba3f  vmovaps xmm10, [rsp+0x90]
00007531fdbdba48  vmovaps xmm11, [rsp+0xA0]
00007531fdbdba51  vmovaps xmm12, [rsp+0xB0]
00007531fdbdba5a  vmovaps xmm13, [rsp+0xC0]
00007531fdbdba63  vmovaps xmm14, [rsp+0xD0]
00007531fdbdba6c  vmovaps xmm15, [rsp+0xE0]
00007531fdbdba75  add rsp, 0xF0
00007531fdbdba7c  pop r11
00007531fdbdba7e  pop r10
00007531fdbdba80  pop r9
00007531fdbdba82  pop r8
00007531fdbdba84  pop rsi
00007531fdbdba85  pop rdi
00007531fdbdba86  pop rdx
00007531fdbdba87  pop rcx
00007531fdbdba88  pop rax
00007531fdbdba89  add rsp, 0x08
00007531fdbdba8d  jmp 0x00007531FDBD929F
00007531fdbdba92  call 0x00007531FDAD64F0
00007531fdbdba97  jmp 0x00007531FDBD92A9
00007531fdbdba9c  sub rsp, 0x08
00007531fdbdbaa0  push rax
00007531fdbdbaa1  push rcx
00007531fdbdbaa2  push rdx
00007531fdbdbaa3  push rdi
00007531fdbdbaa4  push rsi
00007531fdbdbaa5  push r8
00007531fdbdbaa7  push r9
00007531fdbdbaa9  push r10
00007531fdbdbaab  push r11
00007531fdbdbaad  sub rsp, 0xF0
00007531fdbdbab4  vmovaps [rsp], xmm0
00007531fdbdbab9  vmovaps [rsp+0x10], xmm1
00007531fdbdbabf  vmovaps [rsp+0x20], xmm2
00007531fdbdbac5  vmovaps [rsp+0x30], xmm3
00007531fdbdbacb  vmovaps [rsp+0x40], xmm4
00007531fdbdbad1  vmovaps [rsp+0x50], xmm5
00007531fdbdbad7  vmovaps [rsp+0x60], xmm6
00007531fdbdbadd  vmovaps [rsp+0x70], xmm7
00007531fdbdbae3  vmovaps [rsp+0x80], xmm8
00007531fdbdbaec  vmovaps [rsp+0x90], xmm9
00007531fdbdbaf5  vmovaps [rsp+0xA0], xmm10
00007531fdbdbafe  vmovaps [rsp+0xB0], xmm11
00007531fdbdbb07  vmovaps [rsp+0xC0], xmm12
00007531fdbdbb10  vmovaps [rsp+0xD0], xmm13
00007531fdbdbb19  vmovaps [rsp+0xE0], xmm14
00007531fdbdbb22  sub rsp, 0x30
00007531fdbdbb26  movaps [rsp], xmm15
00007531fdbdbb2b  movaps [rsp+0x10], xmm14
00007531fdbdbb31  movaps [rsp+0x20], xmm4
00007531fdbdbb36  lea rdi, [rsp]
00007531fdbdbb3a  mov esi, 0x00
00007531fdbdbb3f  mov rax, 0x59ED111DF530
00007531fdbdbb49  call rax
00007531fdbdbb4b  movaps xmm15, [rsp]
00007531fdbdbb50  add rsp, 0x30
00007531fdbdbb54  vmovaps xmm0, [rsp]
00007531fdbdbb59  vmovaps xmm1, [rsp+0x10]
00007531fdbdbb5f  vmovaps xmm2, [rsp+0x20]
00007531fdbdbb65  vmovaps xmm3, [rsp+0x30]
00007531fdbdbb6b  vmovaps xmm4, [rsp+0x40]
00007531fdbdbb71  vmovaps xmm5, [rsp+0x50]
00007531fdbdbb77  vmovaps xmm6, [rsp+0x60]
00007531fdbdbb7d  vmovaps xmm7, [rsp+0x70]
00007531fdbdbb83  vmovaps xmm8, [rsp+0x80]
00007531fdbdbb8c  vmovaps xmm9, [rsp+0x90]
00007531fdbdbb95  vmovaps xmm10, [rsp+0xA0]
00007531fdbdbb9e  vmovaps xmm11, [rsp+0xB0]
00007531fdbdbba7  vmovaps xmm12, [rsp+0xC0]
00007531fdbdbbb0  vmovaps xmm13, [rsp+0xD0]
00007531fdbdbbb9  vmovaps xmm14, [rsp+0xE0]
00007531fdbdbbc2  add rsp, 0xF0
00007531fdbdbbc9  pop r11
00007531fdbdbbcb  pop r10
00007531fdbdbbcd  pop r9
00007531fdbdbbcf  pop r8
00007531fdbdbbd1  pop rsi
00007531fdbdbbd2  pop rdi
00007531fdbdbbd3  pop rdx
00007531fdbdbbd4  pop rcx
00007531fdbdbbd5  pop rax
00007531fdbdbbd6  add rsp, 0x08
00007531fdbdbbda  jmp 0x00007531FDBD92D7
00007531fdbdbbdf  sub rsp, 0x08
00007531fdbdbbe3  push rax
00007531fdbdbbe4  push rcx
00007531fdbdbbe5  push rdx
00007531fdbdbbe6  push rdi
00007531fdbdbbe7  push rsi
00007531fdbdbbe8  push r8
00007531fdbdbbea  push r9
00007531fdbdbbec  push r10
00007531fdbdbbee  push r11
00007531fdbdbbf0  sub rsp, 0xF0
00007531fdbdbbf7  vmovaps [rsp], xmm0
00007531fdbdbbfc  vmovaps [rsp+0x10], xmm1
00007531fdbdbc02  vmovaps [rsp+0x20], xmm2
00007531fdbdbc08  vmovaps [rsp+0x30], xmm3
00007531fdbdbc0e  vmovaps [rsp+0x40], xmm4
00007531fdbdbc14  vmovaps [rsp+0x50], xmm5
00007531fdbdbc1a  vmovaps [rsp+0x60], xmm6
00007531fdbdbc20  vmovaps [rsp+0x70], xmm7
00007531fdbdbc26  vmovaps [rsp+0x80], xmm8
00007531fdbdbc2f  vmovaps [rsp+0x90], xmm9
00007531fdbdbc38  vmovaps [rsp+0xA0], xmm10
00007531fdbdbc41  vmovaps [rsp+0xB0], xmm11
00007531fdbdbc4a  vmovaps [rsp+0xC0], xmm12
00007531fdbdbc53  vmovaps [rsp+0xD0], xmm13
00007531fdbdbc5c  vmovaps [rsp+0xE0], xmm15
00007531fdbdbc65  sub rsp, 0x30
00007531fdbdbc69  movaps [rsp], xmm14
00007531fdbdbc6e  movaps [rsp+0x10], xmm2
00007531fdbdbc73  movaps [rsp+0x20], xmm1
00007531fdbdbc78  lea rdi, [rsp]
00007531fdbdbc7c  mov esi, 0x00
00007531fdbdbc81  mov rax, 0x59ED111DF530
00007531fdbdbc8b  call rax
00007531fdbdbc8d  movaps xmm14, [rsp]
00007531fdbdbc92  add rsp, 0x30
00007531fdbdbc96  vmovaps xmm0, [rsp]
00007531fdbdbc9b  vmovaps xmm1, [rsp+0x10]
00007531fdbdbca1  vmovaps xmm2, [rsp+0x20]
00007531fdbdbca7  vmovaps xmm3, [rsp+0x30]
00007531fdbdbcad  vmovaps xmm4, [rsp+0x40]
00007531fdbdbcb3  vmovaps xmm5, [rsp+0x50]
00007531fdbdbcb9  vmovaps xmm6, [rsp+0x60]
00007531fdbdbcbf  vmovaps xmm7, [rsp+0x70]
00007531fdbdbcc5  vmovaps xmm8, [rsp+0x80]
00007531fdbdbcce  vmovaps xmm9, [rsp+0x90]
00007531fdbdbcd7  vmovaps xmm10, [rsp+0xA0]
00007531fdbdbce0  vmovaps xmm11, [rsp+0xB0]
00007531fdbdbce9  vmovaps xmm12, [rsp+0xC0]
00007531fdbdbcf2  vmovaps xmm13, [rsp+0xD0]
00007531fdbdbcfb  vmovaps xmm15, [rsp+0xE0]
00007531fdbdbd04  add rsp, 0xF0
00007531fdbdbd0b  pop r11
00007531fdbdbd0d  pop r10
00007531fdbdbd0f  pop r9
00007531fdbdbd11  pop r8
00007531fdbdbd13  pop rsi
00007531fdbdbd14  pop rdi
00007531fdbdbd15  pop rdx
00007531fdbdbd16  pop rcx
00007531fdbdbd17  pop rax
00007531fdbdbd18  add rsp, 0x08
00007531fdbdbd1c  jmp 0x00007531FDBD92FD
00007531fdbdbd21  sub rsp, 0x08
00007531fdbdbd25  push rax
00007531fdbdbd26  push rcx
00007531fdbdbd27  push rdx
00007531fdbdbd28  push rdi
00007531fdbdbd29  push rsi
00007531fdbdbd2a  push r8
00007531fdbdbd2c  push r9
00007531fdbdbd2e  push r10
00007531fdbdbd30  push r11
00007531fdbdbd32  sub rsp, 0xF0
00007531fdbdbd39  vmovaps [rsp], xmm0
00007531fdbdbd3e  vmovaps [rsp+0x10], xmm2
00007531fdbdbd44  vmovaps [rsp+0x20], xmm3
00007531fdbdbd4a  vmovaps [rsp+0x30], xmm4
00007531fdbdbd50  vmovaps [rsp+0x40], xmm5
00007531fdbdbd56  vmovaps [rsp+0x50], xmm6
00007531fdbdbd5c  vmovaps [rsp+0x60], xmm7
00007531fdbdbd62  vmovaps [rsp+0x70], xmm8
00007531fdbdbd68  vmovaps [rsp+0x80], xmm9
00007531fdbdbd71  vmovaps [rsp+0x90], xmm10
00007531fdbdbd7a  vmovaps [rsp+0xA0], xmm11
00007531fdbdbd83  vmovaps [rsp+0xB0], xmm12
00007531fdbdbd8c  vmovaps [rsp+0xC0], xmm13
00007531fdbdbd95  vmovaps [rsp+0xD0], xmm14
00007531fdbdbd9e  vmovaps [rsp+0xE0], xmm15
00007531fdbdbda7  sub rsp, 0x30
00007531fdbdbdab  movaps [rsp], xmm1
00007531fdbdbdaf  movaps [rsp+0x10], xmm4
00007531fdbdbdb4  movaps [rsp+0x20], xmm9
00007531fdbdbdba  lea rdi, [rsp]
00007531fdbdbdbe  mov esi, 0x00
00007531fdbdbdc3  mov rax, 0x59ED111DF530
00007531fdbdbdcd  call rax
00007531fdbdbdcf  movaps xmm1, [rsp]
00007531fdbdbdd3  add rsp, 0x30
00007531fdbdbdd7  vmovaps xmm0, [rsp]
00007531fdbdbddc  vmovaps xmm2, [rsp+0x10]
00007531fdbdbde2  vmovaps xmm3, [rsp+0x20]
00007531fdbdbde8  vmovaps xmm4, [rsp+0x30]
00007531fdbdbdee  vmovaps xmm5, [rsp+0x40]
00007531fdbdbdf4  vmovaps xmm6, [rsp+0x50]
00007531fdbdbdfa  vmovaps xmm7, [rsp+0x60]
00007531fdbdbe00  vmovaps xmm8, [rsp+0x70]
00007531fdbdbe06  vmovaps xmm9, [rsp+0x80]
00007531fdbdbe0f  vmovaps xmm10, [rsp+0x90]
00007531fdbdbe18  vmovaps xmm11, [rsp+0xA0]
00007531fdbdbe21  vmovaps xmm12, [rsp+0xB0]
00007531fdbdbe2a  vmovaps xmm13, [rsp+0xC0]
00007531fdbdbe33  vmovaps xmm14, [rsp+0xD0]
00007531fdbdbe3c  vmovaps xmm15, [rsp+0xE0]
00007531fdbdbe45  add rsp, 0xF0
00007531fdbdbe4c  pop r11
00007531fdbdbe4e  pop r10
00007531fdbdbe50  pop r9
00007531fdbdbe52  pop r8
00007531fdbdbe54  pop rsi
00007531fdbdbe55  pop rdi
00007531fdbdbe56  pop rdx
00007531fdbdbe57  pop rcx
00007531fdbdbe58  pop rax
00007531fdbdbe59  add rsp, 0x08
00007531fdbdbe5d  jmp 0x00007531FDBD931B
00007531fdbdbe62  sub rsp, 0x08
00007531fdbdbe66  push rax
00007531fdbdbe67  push rcx
00007531fdbdbe68  push rdx
00007531fdbdbe69  push rdi
00007531fdbdbe6a  push rsi
00007531fdbdbe6b  push r8
00007531fdbdbe6d  push r9
00007531fdbdbe6f  push r10
00007531fdbdbe71  push r11
00007531fdbdbe73  sub rsp, 0xF0
00007531fdbdbe7a  vmovaps [rsp], xmm0
00007531fdbdbe7f  vmovaps [rsp+0x10], xmm1
00007531fdbdbe85  vmovaps [rsp+0x20], xmm2
00007531fdbdbe8b  vmovaps [rsp+0x30], xmm3
00007531fdbdbe91  vmovaps [rsp+0x40], xmm5
00007531fdbdbe97  vmovaps [rsp+0x50], xmm6
00007531fdbdbe9d  vmovaps [rsp+0x60], xmm7
00007531fdbdbea3  vmovaps [rsp+0x70], xmm8
00007531fdbdbea9  vmovaps [rsp+0x80], xmm9
00007531fdbdbeb2  vmovaps [rsp+0x90], xmm10
00007531fdbdbebb  vmovaps [rsp+0xA0], xmm11
00007531fdbdbec4  vmovaps [rsp+0xB0], xmm12
00007531fdbdbecd  vmovaps [rsp+0xC0], xmm13
00007531fdbdbed6  vmovaps [rsp+0xD0], xmm14
00007531fdbdbedf  vmovaps [rsp+0xE0], xmm15
00007531fdbdbee8  sub rsp, 0x30
00007531fdbdbeec  movaps [rsp], xmm4
00007531fdbdbef0  movaps [rsp+0x10], xmm2
00007531fdbdbef5  movaps [rsp+0x20], xmm9
00007531fdbdbefb  lea rdi, [rsp]
00007531fdbdbeff  mov esi, 0x00
00007531fdbdbf04  mov rax, 0x59ED111DF530
00007531fdbdbf0e  call rax
00007531fdbdbf10  movaps xmm4, [rsp]
00007531fdbdbf14  add rsp, 0x30
00007531fdbdbf18  vmovaps xmm0, [rsp]
00007531fdbdbf1d  vmovaps xmm1, [rsp+0x10]
00007531fdbdbf23  vmovaps xmm2, [rsp+0x20]
00007531fdbdbf29  vmovaps xmm3, [rsp+0x30]
00007531fdbdbf2f  vmovaps xmm5, [rsp+0x40]
00007531fdbdbf35  vmovaps xmm6, [rsp+0x50]
00007531fdbdbf3b  vmovaps xmm7, [rsp+0x60]
00007531fdbdbf41  vmovaps xmm8, [rsp+0x70]
00007531fdbdbf47  vmovaps xmm9, [rsp+0x80]
00007531fdbdbf50  vmovaps xmm10, [rsp+0x90]
00007531fdbdbf59  vmovaps xmm11, [rsp+0xA0]
00007531fdbdbf62  vmovaps xmm12, [rsp+0xB0]
00007531fdbdbf6b  vmovaps xmm13, [rsp+0xC0]
00007531fdbdbf74  vmovaps xmm14, [rsp+0xD0]
00007531fdbdbf7d  vmovaps xmm15, [rsp+0xE0]
00007531fdbdbf86  add rsp, 0xF0
00007531fdbdbf8d  pop r11
00007531fdbdbf8f  pop r10
00007531fdbdbf91  pop r9
00007531fdbdbf93  pop r8
00007531fdbdbf95  pop rsi
00007531fdbdbf96  pop rdi
00007531fdbdbf97  pop rdx
00007531fdbdbf98  pop rcx
00007531fdbdbf99  pop rax
00007531fdbdbf9a  add rsp, 0x08
00007531fdbdbf9e  jmp 0x00007531FDBD934B
00007531fdbdbfa3  sub rsp, 0x08
00007531fdbdbfa7  push rax
00007531fdbdbfa8  push rcx
00007531fdbdbfa9  push rdx
00007531fdbdbfaa  push rdi
00007531fdbdbfab  push rsi
00007531fdbdbfac  push r8
00007531fdbdbfae  push r9
00007531fdbdbfb0  push r10
00007531fdbdbfb2  push r11
00007531fdbdbfb4  sub rsp, 0xF0
00007531fdbdbfbb  vmovaps [rsp], xmm0
00007531fdbdbfc0  vmovaps [rsp+0x10], xmm1
00007531fdbdbfc6  vmovaps [rsp+0x20], xmm2
00007531fdbdbfcc  vmovaps [rsp+0x30], xmm3
00007531fdbdbfd2  vmovaps [rsp+0x40], xmm4
00007531fdbdbfd8  vmovaps [rsp+0x50], xmm5
00007531fdbdbfde  vmovaps [rsp+0x60], xmm6
00007531fdbdbfe4  vmovaps [rsp+0x70], xmm7
00007531fdbdbfea  vmovaps [rsp+0x80], xmm8
00007531fdbdbff3  vmovaps [rsp+0x90], xmm10
00007531fdbdbffc  vmovaps [rsp+0xA0], xmm11
00007531fdbdc005  vmovaps [rsp+0xB0], xmm12
00007531fdbdc00e  vmovaps [rsp+0xC0], xmm13
00007531fdbdc017  vmovaps [rsp+0xD0], xmm14
00007531fdbdc020  vmovaps [rsp+0xE0], xmm15
00007531fdbdc029  sub rsp, 0x30
00007531fdbdc02d  movaps [rsp], xmm9
00007531fdbdc032  movaps [rsp+0x10], xmm2
00007531fdbdc037  movaps [rsp+0x20], xmm1
00007531fdbdc03c  lea rdi, [rsp]
00007531fdbdc040  mov esi, 0x00
00007531fdbdc045  mov rax, 0x59ED111DF530
00007531fdbdc04f  call rax
00007531fdbdc051  movaps xmm9, [rsp]
00007531fdbdc056  add rsp, 0x30
00007531fdbdc05a  vmovaps xmm0, [rsp]
00007531fdbdc05f  vmovaps xmm1, [rsp+0x10]
00007531fdbdc065  vmovaps xmm2, [rsp+0x20]
00007531fdbdc06b  vmovaps xmm3, [rsp+0x30]
00007531fdbdc071  vmovaps xmm4, [rsp+0x40]
00007531fdbdc077  vmovaps xmm5, [rsp+0x50]
00007531fdbdc07d  vmovaps xmm6, [rsp+0x60]
00007531fdbdc083  vmovaps xmm7, [rsp+0x70]
00007531fdbdc089  vmovaps xmm8, [rsp+0x80]
00007531fdbdc092  vmovaps xmm10, [rsp+0x90]
00007531fdbdc09b  vmovaps xmm11, [rsp+0xA0]
00007531fdbdc0a4  vmovaps xmm12, [rsp+0xB0]
00007531fdbdc0ad  vmovaps xmm13, [rsp+0xC0]
00007531fdbdc0b6  vmovaps xmm14, [rsp+0xD0]
00007531fdbdc0bf  vmovaps xmm15, [rsp+0xE0]
00007531fdbdc0c8  add rsp, 0xF0
00007531fdbdc0cf  pop r11
00007531fdbdc0d1  pop r10
00007531fdbdc0d3  pop r9
00007531fdbdc0d5  pop r8
00007531fdbdc0d7  pop rsi
00007531fdbdc0d8  pop rdi
00007531fdbdc0d9  pop rdx
00007531fdbdc0da  pop rcx
00007531fdbdc0db  pop rax
00007531fdbdc0dc  add rsp, 0x08
00007531fdbdc0e0  jmp 0x00007531FDBD9381
00007531fdbdc0e5  sub rsp, 0x08
00007531fdbdc0e9  push rax
00007531fdbdc0ea  push rcx
00007531fdbdc0eb  push rdx
00007531fdbdc0ec  push rdi
00007531fdbdc0ed  push rsi
00007531fdbdc0ee  push r8
00007531fdbdc0f0  push r9
00007531fdbdc0f2  push r10
00007531fdbdc0f4  push r11
00007531fdbdc0f6  sub rsp, 0xF0
00007531fdbdc0fd  vmovaps [rsp], xmm0
00007531fdbdc102  vmovaps [rsp+0x10], xmm2
00007531fdbdc108  vmovaps [rsp+0x20], xmm3
00007531fdbdc10e  vmovaps [rsp+0x30], xmm4
00007531fdbdc114  vmovaps [rsp+0x40], xmm5
00007531fdbdc11a  vmovaps [rsp+0x50], xmm6
00007531fdbdc120  vmovaps [rsp+0x60], xmm7
00007531fdbdc126  vmovaps [rsp+0x70], xmm8
00007531fdbdc12c  vmovaps [rsp+0x80], xmm9
00007531fdbdc135  vmovaps [rsp+0x90], xmm10
00007531fdbdc13e  vmovaps [rsp+0xA0], xmm11
00007531fdbdc147  vmovaps [rsp+0xB0], xmm12
00007531fdbdc150  vmovaps [rsp+0xC0], xmm13
00007531fdbdc159  vmovaps [rsp+0xD0], xmm14
00007531fdbdc162  vmovaps [rsp+0xE0], xmm15
00007531fdbdc16b  sub rsp, 0x30
00007531fdbdc16f  movaps [rsp], xmm1
00007531fdbdc173  movaps [rsp+0x10], xmm15
00007531fdbdc179  movaps [rsp+0x20], xmm6
00007531fdbdc17e  lea rdi, [rsp]
00007531fdbdc182  mov esi, 0x00
00007531fdbdc187  mov rax, 0x59ED111DF530
00007531fdbdc191  call rax
00007531fdbdc193  movaps xmm1, [rsp]
00007531fdbdc197  add rsp, 0x30
00007531fdbdc19b  vmovaps xmm0, [rsp]
00007531fdbdc1a0  vmovaps xmm2, [rsp+0x10]
00007531fdbdc1a6  vmovaps xmm3, [rsp+0x20]
00007531fdbdc1ac  vmovaps xmm4, [rsp+0x30]
00007531fdbdc1b2  vmovaps xmm5, [rsp+0x40]
00007531fdbdc1b8  vmovaps xmm6, [rsp+0x50]
00007531fdbdc1be  vmovaps xmm7, [rsp+0x60]
00007531fdbdc1c4  vmovaps xmm8, [rsp+0x70]
00007531fdbdc1ca  vmovaps xmm9, [rsp+0x80]
00007531fdbdc1d3  vmovaps xmm10, [rsp+0x90]
00007531fdbdc1dc  vmovaps xmm11, [rsp+0xA0]
00007531fdbdc1e5  vmovaps xmm12, [rsp+0xB0]
00007531fdbdc1ee  vmovaps xmm13, [rsp+0xC0]
00007531fdbdc1f7  vmovaps xmm14, [rsp+0xD0]
00007531fdbdc200  vmovaps xmm15, [rsp+0xE0]
00007531fdbdc209  add rsp, 0xF0
00007531fdbdc210  pop r11
00007531fdbdc212  pop r10
00007531fdbdc214  pop r9
00007531fdbdc216  pop r8
00007531fdbdc218  pop rsi
00007531fdbdc219  pop rdi
00007531fdbdc21a  pop rdx
00007531fdbdc21b  pop rcx
00007531fdbdc21c  pop rax
00007531fdbdc21d  add rsp, 0x08
00007531fdbdc221  jmp 0x00007531FDBD93A2
00007531fdbdc226  sub rsp, 0x08
00007531fdbdc22a  push rax
00007531fdbdc22b  push rcx
00007531fdbdc22c  push rdx
00007531fdbdc22d  push rdi
00007531fdbdc22e  push rsi
00007531fdbdc22f  push r8
00007531fdbdc231  push r9
00007531fdbdc233  push r10
00007531fdbdc235  push r11
00007531fdbdc237  sub rsp, 0xF0
00007531fdbdc23e  vmovaps [rsp], xmm0
00007531fdbdc243  vmovaps [rsp+0x10], xmm1
00007531fdbdc249  vmovaps [rsp+0x20], xmm2
00007531fdbdc24f  vmovaps [rsp+0x30], xmm3
00007531fdbdc255  vmovaps [rsp+0x40], xmm4
00007531fdbdc25b  vmovaps [rsp+0x50], xmm5
00007531fdbdc261  vmovaps [rsp+0x60], xmm6
00007531fdbdc267  vmovaps [rsp+0x70], xmm7
00007531fdbdc26d  vmovaps [rsp+0x80], xmm8
00007531fdbdc276  vmovaps [rsp+0x90], xmm9
00007531fdbdc27f  vmovaps [rsp+0xA0], xmm10
00007531fdbdc288  vmovaps [rsp+0xB0], xmm11
00007531fdbdc291  vmovaps [rsp+0xC0], xmm12
00007531fdbdc29a  vmovaps [rsp+0xD0], xmm13
00007531fdbdc2a3  vmovaps [rsp+0xE0], xmm14
00007531fdbdc2ac  sub rsp, 0x30
00007531fdbdc2b0  movaps [rsp], xmm15
00007531fdbdc2b5  movaps [rsp+0x10], xmm5
00007531fdbdc2ba  movaps [rsp+0x20], xmm3
00007531fdbdc2bf  lea rdi, [rsp]
00007531fdbdc2c3  mov esi, 0x00
00007531fdbdc2c8  mov rax, 0x59ED111DF530
00007531fdbdc2d2  call rax
00007531fdbdc2d4  movaps xmm15, [rsp]
00007531fdbdc2d9  add rsp, 0x30
00007531fdbdc2dd  vmovaps xmm0, [rsp]
00007531fdbdc2e2  vmovaps xmm1, [rsp+0x10]
00007531fdbdc2e8  vmovaps xmm2, [rsp+0x20]
00007531fdbdc2ee  vmovaps xmm3, [rsp+0x30]
00007531fdbdc2f4  vmovaps xmm4, [rsp+0x40]
00007531fdbdc2fa  vmovaps xmm5, [rsp+0x50]
00007531fdbdc300  vmovaps xmm6, [rsp+0x60]
00007531fdbdc306  vmovaps xmm7, [rsp+0x70]
00007531fdbdc30c  vmovaps xmm8, [rsp+0x80]
00007531fdbdc315  vmovaps xmm9, [rsp+0x90]
00007531fdbdc31e  vmovaps xmm10, [rsp+0xA0]
00007531fdbdc327  vmovaps xmm11, [rsp+0xB0]
00007531fdbdc330  vmovaps xmm12, [rsp+0xC0]
00007531fdbdc339  vmovaps xmm13, [rsp+0xD0]
00007531fdbdc342  vmovaps xmm14, [rsp+0xE0]
00007531fdbdc34b  add rsp, 0xF0
00007531fdbdc352  pop r11
00007531fdbdc354  pop r10
00007531fdbdc356  pop r9
00007531fdbdc358  pop r8
00007531fdbdc35a  pop rsi
00007531fdbdc35b  pop rdi
00007531fdbdc35c  pop rdx
00007531fdbdc35d  pop rcx
00007531fdbdc35e  pop rax
00007531fdbdc35f  add rsp, 0x08
00007531fdbdc363  jmp 0x00007531FDBD93BC
00007531fdbdc368  sub rsp, 0x08
00007531fdbdc36c  push rax
00007531fdbdc36d  push rcx
00007531fdbdc36e  push rdx
00007531fdbdc36f  push rdi
00007531fdbdc370  push rsi
00007531fdbdc371  push r8
00007531fdbdc373  push r9
00007531fdbdc375  push r10
00007531fdbdc377  push r11
00007531fdbdc379  sub rsp, 0xF0
00007531fdbdc380  vmovaps [rsp], xmm0
00007531fdbdc385  vmovaps [rsp+0x10], xmm1
00007531fdbdc38b  vmovaps [rsp+0x20], xmm2
00007531fdbdc391  vmovaps [rsp+0x30], xmm3
00007531fdbdc397  vmovaps [rsp+0x40], xmm4
00007531fdbdc39d  vmovaps [rsp+0x50], xmm6
00007531fdbdc3a3  vmovaps [rsp+0x60], xmm7
00007531fdbdc3a9  vmovaps [rsp+0x70], xmm8
00007531fdbdc3af  vmovaps [rsp+0x80], xmm9
00007531fdbdc3b8  vmovaps [rsp+0x90], xmm10
00007531fdbdc3c1  vmovaps [rsp+0xA0], xmm11
00007531fdbdc3ca  vmovaps [rsp+0xB0], xmm12
00007531fdbdc3d3  vmovaps [rsp+0xC0], xmm13
00007531fdbdc3dc  vmovaps [rsp+0xD0], xmm14
00007531fdbdc3e5  vmovaps [rsp+0xE0], xmm15
00007531fdbdc3ee  sub rsp, 0x30
00007531fdbdc3f2  movaps [rsp], xmm5
00007531fdbdc3f6  movaps [rsp+0x10], xmm8
00007531fdbdc3fc  movaps [rsp+0x20], xmm6
00007531fdbdc401  lea rdi, [rsp]
00007531fdbdc405  mov esi, 0x00
00007531fdbdc40a  mov rax, 0x59ED111DF530
00007531fdbdc414  call rax
00007531fdbdc416  movaps xmm5, [rsp]
00007531fdbdc41a  add rsp, 0x30
00007531fdbdc41e  vmovaps xmm0, [rsp]
00007531fdbdc423  vmovaps xmm1, [rsp+0x10]
00007531fdbdc429  vmovaps xmm2, [rsp+0x20]
00007531fdbdc42f  vmovaps xmm3, [rsp+0x30]
00007531fdbdc435  vmovaps xmm4, [rsp+0x40]
00007531fdbdc43b  vmovaps xmm6, [rsp+0x50]
00007531fdbdc441  vmovaps xmm7, [rsp+0x60]
00007531fdbdc447  vmovaps xmm8, [rsp+0x70]
00007531fdbdc44d  vmovaps xmm9, [rsp+0x80]
00007531fdbdc456  vmovaps xmm10, [rsp+0x90]
00007531fdbdc45f  vmovaps xmm11, [rsp+0xA0]
00007531fdbdc468  vmovaps xmm12, [rsp+0xB0]
00007531fdbdc471  vmovaps xmm13, [rsp+0xC0]
00007531fdbdc47a  vmovaps xmm14, [rsp+0xD0]
00007531fdbdc483  vmovaps xmm15, [rsp+0xE0]
00007531fdbdc48c  add rsp, 0xF0
00007531fdbdc493  pop r11
00007531fdbdc495  pop r10
00007531fdbdc497  pop r9
00007531fdbdc499  pop r8
00007531fdbdc49b  pop rsi
00007531fdbdc49c  pop rdi
00007531fdbdc49d  pop rdx
00007531fdbdc49e  pop rcx
00007531fdbdc49f  pop rax
00007531fdbdc4a0  add rsp, 0x08
00007531fdbdc4a4  jmp 0x00007531FDBD93E0
00007531fdbdc4a9  sub rsp, 0x08
00007531fdbdc4ad  push rax
00007531fdbdc4ae  push rcx
00007531fdbdc4af  push rdx
00007531fdbdc4b0  push rdi
00007531fdbdc4b1  push rsi
00007531fdbdc4b2  push r8
00007531fdbdc4b4  push r9
00007531fdbdc4b6  push r10
00007531fdbdc4b8  push r11
00007531fdbdc4ba  sub rsp, 0xF0
00007531fdbdc4c1  vmovaps [rsp], xmm0
00007531fdbdc4c6  vmovaps [rsp+0x10], xmm1
00007531fdbdc4cc  vmovaps [rsp+0x20], xmm2
00007531fdbdc4d2  vmovaps [rsp+0x30], xmm3
00007531fdbdc4d8  vmovaps [rsp+0x40], xmm4
00007531fdbdc4de  vmovaps [rsp+0x50], xmm5
00007531fdbdc4e4  vmovaps [rsp+0x60], xmm7
00007531fdbdc4ea  vmovaps [rsp+0x70], xmm8
00007531fdbdc4f0  vmovaps [rsp+0x80], xmm9
00007531fdbdc4f9  vmovaps [rsp+0x90], xmm10
00007531fdbdc502  vmovaps [rsp+0xA0], xmm11
00007531fdbdc50b  vmovaps [rsp+0xB0], xmm12
00007531fdbdc514  vmovaps [rsp+0xC0], xmm13
00007531fdbdc51d  vmovaps [rsp+0xD0], xmm14
00007531fdbdc526  vmovaps [rsp+0xE0], xmm15
00007531fdbdc52f  sub rsp, 0x30
00007531fdbdc533  movaps [rsp], xmm6
00007531fdbdc537  movaps [rsp+0x10], xmm10
00007531fdbdc53d  movaps [rsp+0x20], xmm8
00007531fdbdc543  lea rdi, [rsp]
00007531fdbdc547  mov esi, 0x00
00007531fdbdc54c  mov rax, 0x59ED111DF530
00007531fdbdc556  call rax
00007531fdbdc558  movaps xmm6, [rsp]
00007531fdbdc55c  add rsp, 0x30
00007531fdbdc560  vmovaps xmm0, [rsp]
00007531fdbdc565  vmovaps xmm1, [rsp+0x10]
00007531fdbdc56b  vmovaps xmm2, [rsp+0x20]
00007531fdbdc571  vmovaps xmm3, [rsp+0x30]
00007531fdbdc577  vmovaps xmm4, [rsp+0x40]
00007531fdbdc57d  vmovaps xmm5, [rsp+0x50]
00007531fdbdc583  vmovaps xmm7, [rsp+0x60]
00007531fdbdc589  vmovaps xmm8, [rsp+0x70]
00007531fdbdc58f  vmovaps xmm9, [rsp+0x80]
00007531fdbdc598  vmovaps xmm10, [rsp+0x90]
00007531fdbdc5a1  vmovaps xmm11, [rsp+0xA0]
00007531fdbdc5aa  vmovaps xmm12, [rsp+0xB0]
00007531fdbdc5b3  vmovaps xmm13, [rsp+0xC0]
00007531fdbdc5bc  vmovaps xmm14, [rsp+0xD0]
00007531fdbdc5c5  vmovaps xmm15, [rsp+0xE0]
00007531fdbdc5ce  add rsp, 0xF0
00007531fdbdc5d5  pop r11
00007531fdbdc5d7  pop r10
00007531fdbdc5d9  pop r9
00007531fdbdc5db  pop r8
00007531fdbdc5dd  pop rsi
00007531fdbdc5de  pop rdi
00007531fdbdc5df  pop rdx
00007531fdbdc5e0  pop rcx
00007531fdbdc5e1  pop rax
00007531fdbdc5e2  add rsp, 0x08
00007531fdbdc5e6  jmp 0x00007531FDBD9405
00007531fdbdc5eb  sub rsp, 0x08
00007531fdbdc5ef  push rax
00007531fdbdc5f0  push rcx
00007531fdbdc5f1  push rdx
00007531fdbdc5f2  push rdi
00007531fdbdc5f3  push rsi
00007531fdbdc5f4  push r8
00007531fdbdc5f6  push r9
00007531fdbdc5f8  push r10
00007531fdbdc5fa  push r11
00007531fdbdc5fc  sub rsp, 0xF0
00007531fdbdc603  vmovaps [rsp], xmm0
00007531fdbdc608  vmovaps [rsp+0x10], xmm1
00007531fdbdc60e  vmovaps [rsp+0x20], xmm2
00007531fdbdc614  vmovaps [rsp+0x30], xmm3
00007531fdbdc61a  vmovaps [rsp+0x40], xmm4
00007531fdbdc620  vmovaps [rsp+0x50], xmm5
00007531fdbdc626  vmovaps [rsp+0x60], xmm6
00007531fdbdc62c  vmovaps [rsp+0x70], xmm7
00007531fdbdc632  vmovaps [rsp+0x80], xmm8
00007531fdbdc63b  vmovaps [rsp+0x90], xmm9
00007531fdbdc644  vmovaps [rsp+0xA0], xmm11
00007531fdbdc64d  vmovaps [rsp+0xB0], xmm12
00007531fdbdc656  vmovaps [rsp+0xC0], xmm13
00007531fdbdc65f  vmovaps [rsp+0xD0], xmm14
00007531fdbdc668  vmovaps [rsp+0xE0], xmm15
00007531fdbdc671  sub rsp, 0x30
00007531fdbdc675  movaps [rsp], xmm10
00007531fdbdc67a  movaps [rsp+0x10], xmm8
00007531fdbdc680  movaps [rsp+0x20], xmm14
00007531fdbdc686  lea rdi, [rsp]
00007531fdbdc68a  mov esi, 0x00
00007531fdbdc68f  mov rax, 0x59ED111DF530
00007531fdbdc699  call rax
00007531fdbdc69b  movaps xmm10, [rsp]
00007531fdbdc6a0  add rsp, 0x30
00007531fdbdc6a4  vmovaps xmm0, [rsp]
00007531fdbdc6a9  vmovaps xmm1, [rsp+0x10]
00007531fdbdc6af  vmovaps xmm2, [rsp+0x20]
00007531fdbdc6b5  vmovaps xmm3, [rsp+0x30]
00007531fdbdc6bb  vmovaps xmm4, [rsp+0x40]
00007531fdbdc6c1  vmovaps xmm5, [rsp+0x50]
00007531fdbdc6c7  vmovaps xmm6, [rsp+0x60]
00007531fdbdc6cd  vmovaps xmm7, [rsp+0x70]
00007531fdbdc6d3  vmovaps xmm8, [rsp+0x80]
00007531fdbdc6dc  vmovaps xmm9, [rsp+0x90]
00007531fdbdc6e5  vmovaps xmm11, [rsp+0xA0]
00007531fdbdc6ee  vmovaps xmm12, [rsp+0xB0]
00007531fdbdc6f7  vmovaps xmm13, [rsp+0xC0]
00007531fdbdc700  vmovaps xmm14, [rsp+0xD0]
00007531fdbdc709  vmovaps xmm15, [rsp+0xE0]
00007531fdbdc712  add rsp, 0xF0
00007531fdbdc719  pop r11
00007531fdbdc71b  pop r10
00007531fdbdc71d  pop r9
00007531fdbdc71f  pop r8
00007531fdbdc721  pop rsi
00007531fdbdc722  pop rdi
00007531fdbdc723  pop rdx
00007531fdbdc724  pop rcx
00007531fdbdc725  pop rax
00007531fdbdc726  add rsp, 0x08
00007531fdbdc72a  jmp 0x00007531FDBD9425
00007531fdbdc72f  sub rsp, 0x08
00007531fdbdc733  push rax
00007531fdbdc734  push rcx
00007531fdbdc735  push rdx
00007531fdbdc736  push rdi
00007531fdbdc737  push rsi
00007531fdbdc738  push r8
00007531fdbdc73a  push r9
00007531fdbdc73c  push r10
00007531fdbdc73e  push r11
00007531fdbdc740  sub rsp, 0xF0
00007531fdbdc747  vmovaps [rsp], xmm0
00007531fdbdc74c  vmovaps [rsp+0x10], xmm1
00007531fdbdc752  vmovaps [rsp+0x20], xmm2
00007531fdbdc758  vmovaps [rsp+0x30], xmm3
00007531fdbdc75e  vmovaps [rsp+0x40], xmm4
00007531fdbdc764  vmovaps [rsp+0x50], xmm5
00007531fdbdc76a  vmovaps [rsp+0x60], xmm6
00007531fdbdc770  vmovaps [rsp+0x70], xmm7
00007531fdbdc776  vmovaps [rsp+0x80], xmm8
00007531fdbdc77f  vmovaps [rsp+0x90], xmm9
00007531fdbdc788  vmovaps [rsp+0xA0], xmm10
00007531fdbdc791  vmovaps [rsp+0xB0], xmm11
00007531fdbdc79a  vmovaps [rsp+0xC0], xmm12
00007531fdbdc7a3  vmovaps [rsp+0xD0], xmm13
00007531fdbdc7ac  vmovaps [rsp+0xE0], xmm15
00007531fdbdc7b5  sub rsp, 0x30
00007531fdbdc7b9  movaps [rsp], xmm14
00007531fdbdc7be  movaps [rsp+0x10], xmm8
00007531fdbdc7c4  movaps [rsp+0x20], xmm4
00007531fdbdc7c9  lea rdi, [rsp]
00007531fdbdc7cd  mov esi, 0x00
00007531fdbdc7d2  mov rax, 0x59ED111DF530
00007531fdbdc7dc  call rax
00007531fdbdc7de  movaps xmm14, [rsp]
00007531fdbdc7e3  add rsp, 0x30
00007531fdbdc7e7  vmovaps xmm0, [rsp]
00007531fdbdc7ec  vmovaps xmm1, [rsp+0x10]
00007531fdbdc7f2  vmovaps xmm2, [rsp+0x20]
00007531fdbdc7f8  vmovaps xmm3, [rsp+0x30]
00007531fdbdc7fe  vmovaps xmm4, [rsp+0x40]
00007531fdbdc804  vmovaps xmm5, [rsp+0x50]
00007531fdbdc80a  vmovaps xmm6, [rsp+0x60]
00007531fdbdc810  vmovaps xmm7, [rsp+0x70]
00007531fdbdc816  vmovaps xmm8, [rsp+0x80]
00007531fdbdc81f  vmovaps xmm9, [rsp+0x90]
00007531fdbdc828  vmovaps xmm10, [rsp+0xA0]
00007531fdbdc831  vmovaps xmm11, [rsp+0xB0]
00007531fdbdc83a  vmovaps xmm12, [rsp+0xC0]
00007531fdbdc843  vmovaps xmm13, [rsp+0xD0]
00007531fdbdc84c  vmovaps xmm15, [rsp+0xE0]
00007531fdbdc855  add rsp, 0xF0
00007531fdbdc85c  pop r11
00007531fdbdc85e  pop r10
00007531fdbdc860  pop r9
00007531fdbdc862  pop r8
00007531fdbdc864  pop rsi
00007531fdbdc865  pop rdi
00007531fdbdc866  pop rdx
00007531fdbdc867  pop rcx
00007531fdbdc868  pop rax
00007531fdbdc869  add rsp, 0x08
00007531fdbdc86d  jmp 0x00007531FDBD9445
00007531fdbdc872  sub rsp, 0x08
00007531fdbdc876  push rax
00007531fdbdc877  push rcx
00007531fdbdc878  push rdx
00007531fdbdc879  push rdi
00007531fdbdc87a  push rsi
00007531fdbdc87b  push r8
00007531fdbdc87d  push r9
00007531fdbdc87f  push r10
00007531fdbdc881  push r11
00007531fdbdc883  sub rsp, 0xF0
00007531fdbdc88a  vmovaps [rsp], xmm0
00007531fdbdc88f  vmovaps [rsp+0x10], xmm1
00007531fdbdc895  vmovaps [rsp+0x20], xmm2
00007531fdbdc89b  vmovaps [rsp+0x30], xmm3
00007531fdbdc8a1  vmovaps [rsp+0x40], xmm5
00007531fdbdc8a7  vmovaps [rsp+0x50], xmm6
00007531fdbdc8ad  vmovaps [rsp+0x60], xmm7
00007531fdbdc8b3  vmovaps [rsp+0x70], xmm8
00007531fdbdc8b9  vmovaps [rsp+0x80], xmm9
00007531fdbdc8c2  vmovaps [rsp+0x90], xmm10
00007531fdbdc8cb  vmovaps [rsp+0xA0], xmm11
00007531fdbdc8d4  vmovaps [rsp+0xB0], xmm12
00007531fdbdc8dd  vmovaps [rsp+0xC0], xmm13
00007531fdbdc8e6  vmovaps [rsp+0xD0], xmm14
00007531fdbdc8ef  vmovaps [rsp+0xE0], xmm15
00007531fdbdc8f8  sub rsp, 0x30
00007531fdbdc8fc  movaps [rsp], xmm4
00007531fdbdc900  movaps [rsp+0x10], xmm13
00007531fdbdc906  movaps [rsp+0x20], xmm8
00007531fdbdc90c  lea rdi, [rsp]
00007531fdbdc910  mov esi, 0x00
00007531fdbdc915  mov rax, 0x59ED111DF530
00007531fdbdc91f  call rax
00007531fdbdc921  movaps xmm4, [rsp]
00007531fdbdc925  add rsp, 0x30
00007531fdbdc929  vmovaps xmm0, [rsp]
00007531fdbdc92e  vmovaps xmm1, [rsp+0x10]
00007531fdbdc934  vmovaps xmm2, [rsp+0x20]
00007531fdbdc93a  vmovaps xmm3, [rsp+0x30]
00007531fdbdc940  vmovaps xmm5, [rsp+0x40]
00007531fdbdc946  vmovaps xmm6, [rsp+0x50]
00007531fdbdc94c  vmovaps xmm7, [rsp+0x60]
00007531fdbdc952  vmovaps xmm8, [rsp+0x70]
00007531fdbdc958  vmovaps xmm9, [rsp+0x80]
00007531fdbdc961  vmovaps xmm10, [rsp+0x90]
00007531fdbdc96a  vmovaps xmm11, [rsp+0xA0]
00007531fdbdc973  vmovaps xmm12, [rsp+0xB0]
00007531fdbdc97c  vmovaps xmm13, [rsp+0xC0]
00007531fdbdc985  vmovaps xmm14, [rsp+0xD0]
00007531fdbdc98e  vmovaps xmm15, [rsp+0xE0]
00007531fdbdc997  add rsp, 0xF0
00007531fdbdc99e  pop r11
00007531fdbdc9a0  pop r10
00007531fdbdc9a2  pop r9
00007531fdbdc9a4  pop r8
00007531fdbdc9a6  pop rsi
00007531fdbdc9a7  pop rdi
00007531fdbdc9a8  pop rdx
00007531fdbdc9a9  pop rcx
00007531fdbdc9aa  pop rax
00007531fdbdc9ab  add rsp, 0x08
00007531fdbdc9af  jmp 0x00007531FDBD946A
00007531fdbdc9b4  sub rsp, 0x08
00007531fdbdc9b8  push rax
00007531fdbdc9b9  push rcx
00007531fdbdc9ba  push rdx
00007531fdbdc9bb  push rdi
00007531fdbdc9bc  push rsi
00007531fdbdc9bd  push r8
00007531fdbdc9bf  push r9
00007531fdbdc9c1  push r10
00007531fdbdc9c3  push r11
00007531fdbdc9c5  sub rsp, 0xF0
00007531fdbdc9cc  vmovaps [rsp], xmm0
00007531fdbdc9d1  vmovaps [rsp+0x10], xmm1
00007531fdbdc9d7  vmovaps [rsp+0x20], xmm2
00007531fdbdc9dd  vmovaps [rsp+0x30], xmm3
00007531fdbdc9e3  vmovaps [rsp+0x40], xmm4
00007531fdbdc9e9  vmovaps [rsp+0x50], xmm5
00007531fdbdc9ef  vmovaps [rsp+0x60], xmm6
00007531fdbdc9f5  vmovaps [rsp+0x70], xmm7
00007531fdbdc9fb  vmovaps [rsp+0x80], xmm8
00007531fdbdca04  vmovaps [rsp+0x90], xmm9
00007531fdbdca0d  vmovaps [rsp+0xA0], xmm10
00007531fdbdca16  vmovaps [rsp+0xB0], xmm11
00007531fdbdca1f  vmovaps [rsp+0xC0], xmm12
00007531fdbdca28  vmovaps [rsp+0xD0], xmm14
00007531fdbdca31  vmovaps [rsp+0xE0], xmm15
00007531fdbdca3a  sub rsp, 0x30
00007531fdbdca3e  movaps [rsp], xmm13
00007531fdbdca43  movaps [rsp+0x10], xmm15
00007531fdbdca49  movaps [rsp+0x20], xmm9
00007531fdbdca4f  lea rdi, [rsp]
00007531fdbdca53  mov esi, 0x00
00007531fdbdca58  mov rax, 0x59ED111DF530
00007531fdbdca62  call rax
00007531fdbdca64  movaps xmm13, [rsp]
00007531fdbdca69  add rsp, 0x30
00007531fdbdca6d  vmovaps xmm0, [rsp]
00007531fdbdca72  vmovaps xmm1, [rsp+0x10]
00007531fdbdca78  vmovaps xmm2, [rsp+0x20]
00007531fdbdca7e  vmovaps xmm3, [rsp+0x30]
00007531fdbdca84  vmovaps xmm4, [rsp+0x40]
00007531fdbdca8a  vmovaps xmm5, [rsp+0x50]
00007531fdbdca90  vmovaps xmm6, [rsp+0x60]
00007531fdbdca96  vmovaps xmm7, [rsp+0x70]
00007531fdbdca9c  vmovaps xmm8, [rsp+0x80]
00007531fdbdcaa5  vmovaps xmm9, [rsp+0x90]
00007531fdbdcaae  vmovaps xmm10, [rsp+0xA0]
00007531fdbdcab7  vmovaps xmm11, [rsp+0xB0]
00007531fdbdcac0  vmovaps xmm12, [rsp+0xC0]
00007531fdbdcac9  vmovaps xmm14, [rsp+0xD0]
00007531fdbdcad2  vmovaps xmm15, [rsp+0xE0]
00007531fdbdcadb  add rsp, 0xF0
00007531fdbdcae2  pop r11
00007531fdbdcae4  pop r10
00007531fdbdcae6  pop r9
00007531fdbdcae8  pop r8
00007531fdbdcaea  pop rsi
00007531fdbdcaeb  pop rdi
00007531fdbdcaec  pop rdx
00007531fdbdcaed  pop rcx
00007531fdbdcaee  pop rax
00007531fdbdcaef  add rsp, 0x08
00007531fdbdcaf3  jmp 0x00007531FDBD9485
00007531fdbdcaf8  sub rsp, 0x08
00007531fdbdcafc  push rax
00007531fdbdcafd  push rcx
00007531fdbdcafe  push rdx
00007531fdbdcaff  push rdi
00007531fdbdcb00  push rsi
00007531fdbdcb01  push r8
00007531fdbdcb03  push r9
00007531fdbdcb05  push r10
00007531fdbdcb07  push r11
00007531fdbdcb09  sub rsp, 0xF0
00007531fdbdcb10  vmovaps [rsp], xmm0
00007531fdbdcb15  vmovaps [rsp+0x10], xmm1
00007531fdbdcb1b  vmovaps [rsp+0x20], xmm2
00007531fdbdcb21  vmovaps [rsp+0x30], xmm3
00007531fdbdcb27  vmovaps [rsp+0x40], xmm4
00007531fdbdcb2d  vmovaps [rsp+0x50], xmm5
00007531fdbdcb33  vmovaps [rsp+0x60], xmm6
00007531fdbdcb39  vmovaps [rsp+0x70], xmm7
00007531fdbdcb3f  vmovaps [rsp+0x80], xmm8
00007531fdbdcb48  vmovaps [rsp+0x90], xmm9
00007531fdbdcb51  vmovaps [rsp+0xA0], xmm10
00007531fdbdcb5a  vmovaps [rsp+0xB0], xmm11
00007531fdbdcb63  vmovaps [rsp+0xC0], xmm12
00007531fdbdcb6c  vmovaps [rsp+0xD0], xmm13
00007531fdbdcb75  vmovaps [rsp+0xE0], xmm14
00007531fdbdcb7e  sub rsp, 0x30
00007531fdbdcb82  movaps [rsp], xmm15
00007531fdbdcb87  movaps [rsp+0x10], xmm1
00007531fdbdcb8c  movaps [rsp+0x20], xmm5
00007531fdbdcb91  lea rdi, [rsp]
00007531fdbdcb95  mov esi, 0x00
00007531fdbdcb9a  mov rax, 0x59ED111DF530
00007531fdbdcba4  call rax
00007531fdbdcba6  movaps xmm15, [rsp]
00007531fdbdcbab  add rsp, 0x30
00007531fdbdcbaf  vmovaps xmm0, [rsp]
00007531fdbdcbb4  vmovaps xmm1, [rsp+0x10]
00007531fdbdcbba  vmovaps xmm2, [rsp+0x20]
00007531fdbdcbc0  vmovaps xmm3, [rsp+0x30]
00007531fdbdcbc6  vmovaps xmm4, [rsp+0x40]
00007531fdbdcbcc  vmovaps xmm5, [rsp+0x50]
00007531fdbdcbd2  vmovaps xmm6, [rsp+0x60]
00007531fdbdcbd8  vmovaps xmm7, [rsp+0x70]
00007531fdbdcbde  vmovaps xmm8, [rsp+0x80]
00007531fdbdcbe7  vmovaps xmm9, [rsp+0x90]
00007531fdbdcbf0  vmovaps xmm10, [rsp+0xA0]
00007531fdbdcbf9  vmovaps xmm11, [rsp+0xB0]
00007531fdbdcc02  vmovaps xmm12, [rsp+0xC0]
00007531fdbdcc0b  vmovaps xmm13, [rsp+0xD0]
00007531fdbdcc14  vmovaps xmm14, [rsp+0xE0]
00007531fdbdcc1d  add rsp, 0xF0
00007531fdbdcc24  pop r11
00007531fdbdcc26  pop r10
00007531fdbdcc28  pop r9
00007531fdbdcc2a  pop r8
00007531fdbdcc2c  pop rsi
00007531fdbdcc2d  pop rdi
00007531fdbdcc2e  pop rdx
00007531fdbdcc2f  pop rcx
00007531fdbdcc30  pop rax
00007531fdbdcc31  add rsp, 0x08
00007531fdbdcc35  jmp 0x00007531FDBD94A0
00007531fdbdcc3a  call 0x00007531FDAD64F0
00007531fdbdcc3f  jmp 0x00007531FDBD94FB
00007531fdbdcc44  sub rsp, 0x08
00007531fdbdcc48  push rax
00007531fdbdcc49  push rcx
00007531fdbdcc4a  push rdx
00007531fdbdcc4b  push rdi
00007531fdbdcc4c  push rsi
00007531fdbdcc4d  push r8
00007531fdbdcc4f  push r9
00007531fdbdcc51  push r10
00007531fdbdcc53  push r11
00007531fdbdcc55  sub rsp, 0xF0
00007531fdbdcc5c  vmovaps [rsp], xmm0
00007531fdbdcc61  vmovaps [rsp+0x10], xmm1
00007531fdbdcc67  vmovaps [rsp+0x20], xmm2
00007531fdbdcc6d  vmovaps [rsp+0x30], xmm3
00007531fdbdcc73  vmovaps [rsp+0x40], xmm4
00007531fdbdcc79  vmovaps [rsp+0x50], xmm5
00007531fdbdcc7f  vmovaps [rsp+0x60], xmm6
00007531fdbdcc85  vmovaps [rsp+0x70], xmm7
00007531fdbdcc8b  vmovaps [rsp+0x80], xmm8
00007531fdbdcc94  vmovaps [rsp+0x90], xmm10
00007531fdbdcc9d  vmovaps [rsp+0xA0], xmm11
00007531fdbdcca6  vmovaps [rsp+0xB0], xmm12
00007531fdbdccaf  vmovaps [rsp+0xC0], xmm13
00007531fdbdccb8  vmovaps [rsp+0xD0], xmm14
00007531fdbdccc1  vmovaps [rsp+0xE0], xmm15
00007531fdbdccca  sub rsp, 0x30
00007531fdbdccce  movaps [rsp], xmm9
00007531fdbdccd3  movaps [rsp+0x10], xmm8
00007531fdbdccd9  movaps [rsp+0x20], xmm11
00007531fdbdccdf  lea rdi, [rsp]
00007531fdbdcce3  mov esi, 0x00
00007531fdbdcce8  mov rax, 0x59ED111DF530
00007531fdbdccf2  call rax
00007531fdbdccf4  movaps xmm9, [rsp]
00007531fdbdccf9  add rsp, 0x30
00007531fdbdccfd  vmovaps xmm0, [rsp]
00007531fdbdcd02  vmovaps xmm1, [rsp+0x10]
00007531fdbdcd08  vmovaps xmm2, [rsp+0x20]
00007531fdbdcd0e  vmovaps xmm3, [rsp+0x30]
00007531fdbdcd14  vmovaps xmm4, [rsp+0x40]
00007531fdbdcd1a  vmovaps xmm5, [rsp+0x50]
00007531fdbdcd20  vmovaps xmm6, [rsp+0x60]
00007531fdbdcd26  vmovaps xmm7, [rsp+0x70]
00007531fdbdcd2c  vmovaps xmm8, [rsp+0x80]
00007531fdbdcd35  vmovaps xmm10, [rsp+0x90]
00007531fdbdcd3e  vmovaps xmm11, [rsp+0xA0]
00007531fdbdcd47  vmovaps xmm12, [rsp+0xB0]
00007531fdbdcd50  vmovaps xmm13, [rsp+0xC0]
00007531fdbdcd59  vmovaps xmm14, [rsp+0xD0]
00007531fdbdcd62  vmovaps xmm15, [rsp+0xE0]
00007531fdbdcd6b  add rsp, 0xF0
00007531fdbdcd72  pop r11
00007531fdbdcd74  pop r10
00007531fdbdcd76  pop r9
00007531fdbdcd78  pop r8
00007531fdbdcd7a  pop rsi
00007531fdbdcd7b  pop rdi
00007531fdbdcd7c  pop rdx
00007531fdbdcd7d  pop rcx
00007531fdbdcd7e  pop rax
00007531fdbdcd7f  add rsp, 0x08
00007531fdbdcd83  jmp 0x00007531FDBD9532
00007531fdbdcd88  sub rsp, 0x08
00007531fdbdcd8c  push rax
00007531fdbdcd8d  push rcx
00007531fdbdcd8e  push rdx
00007531fdbdcd8f  push rdi
00007531fdbdcd90  push rsi
00007531fdbdcd91  push r8
00007531fdbdcd93  push r9
00007531fdbdcd95  push r10
00007531fdbdcd97  push r11
00007531fdbdcd99  sub rsp, 0xF0
00007531fdbdcda0  vmovaps [rsp], xmm0
00007531fdbdcda5  vmovaps [rsp+0x10], xmm1
00007531fdbdcdab  vmovaps [rsp+0x20], xmm2
00007531fdbdcdb1  vmovaps [rsp+0x30], xmm3
00007531fdbdcdb7  vmovaps [rsp+0x40], xmm4
00007531fdbdcdbd  vmovaps [rsp+0x50], xmm5
00007531fdbdcdc3  vmovaps [rsp+0x60], xmm6
00007531fdbdcdc9  vmovaps [rsp+0x70], xmm7
00007531fdbdcdcf  vmovaps [rsp+0x80], xmm8
00007531fdbdcdd8  vmovaps [rsp+0x90], xmm9
00007531fdbdcde1  vmovaps [rsp+0xA0], xmm10
00007531fdbdcdea  vmovaps [rsp+0xB0], xmm12
00007531fdbdcdf3  vmovaps [rsp+0xC0], xmm13
00007531fdbdcdfc  vmovaps [rsp+0xD0], xmm14
00007531fdbdce05  vmovaps [rsp+0xE0], xmm15
00007531fdbdce0e  sub rsp, 0x30
00007531fdbdce12  movaps [rsp], xmm11
00007531fdbdce17  movaps [rsp+0x10], xmm10
00007531fdbdce1d  movaps [rsp+0x20], xmm6
00007531fdbdce22  lea rdi, [rsp]
00007531fdbdce26  mov esi, 0x00
00007531fdbdce2b  mov rax, 0x59ED111DF530
00007531fdbdce35  call rax
00007531fdbdce37  movaps xmm11, [rsp]
00007531fdbdce3c  add rsp, 0x30
00007531fdbdce40  vmovaps xmm0, [rsp]
00007531fdbdce45  vmovaps xmm1, [rsp+0x10]
00007531fdbdce4b  vmovaps xmm2, [rsp+0x20]
00007531fdbdce51  vmovaps xmm3, [rsp+0x30]
00007531fdbdce57  vmovaps xmm4, [rsp+0x40]
00007531fdbdce5d  vmovaps xmm5, [rsp+0x50]
00007531fdbdce63  vmovaps xmm6, [rsp+0x60]
00007531fdbdce69  vmovaps xmm7, [rsp+0x70]
00007531fdbdce6f  vmovaps xmm8, [rsp+0x80]
00007531fdbdce78  vmovaps xmm9, [rsp+0x90]
00007531fdbdce81  vmovaps xmm10, [rsp+0xA0]
00007531fdbdce8a  vmovaps xmm12, [rsp+0xB0]
00007531fdbdce93  vmovaps xmm13, [rsp+0xC0]
00007531fdbdce9c  vmovaps xmm14, [rsp+0xD0]
00007531fdbdcea5  vmovaps xmm15, [rsp+0xE0]
00007531fdbdceae  add rsp, 0xF0
00007531fdbdceb5  pop r11
00007531fdbdceb7  pop r10
00007531fdbdceb9  pop r9
00007531fdbdcebb  pop r8
00007531fdbdcebd  pop rsi
00007531fdbdcebe  pop rdi
00007531fdbdcebf  pop rdx
00007531fdbdcec0  pop rcx
00007531fdbdcec1  pop rax
00007531fdbdcec2  add rsp, 0x08
00007531fdbdcec6  jmp 0x00007531FDBD954D
00007531fdbdcecb  sub rsp, 0x08
00007531fdbdcecf  push rax
00007531fdbdced0  push rcx
00007531fdbdced1  push rdx
00007531fdbdced2  push rdi
00007531fdbdced3  push rsi
00007531fdbdced4  push r8
00007531fdbdced6  push r9
00007531fdbdced8  push r10
00007531fdbdceda  push r11
00007531fdbdcedc  sub rsp, 0xF0
00007531fdbdcee3  vmovaps [rsp], xmm0
00007531fdbdcee8  vmovaps [rsp+0x10], xmm1
00007531fdbdceee  vmovaps [rsp+0x20], xmm2
00007531fdbdcef4  vmovaps [rsp+0x30], xmm3
00007531fdbdcefa  vmovaps [rsp+0x40], xmm4
00007531fdbdcf00  vmovaps [rsp+0x50], xmm5
00007531fdbdcf06  vmovaps [rsp+0x60], xmm6
00007531fdbdcf0c  vmovaps [rsp+0x70], xmm7
00007531fdbdcf12  vmovaps [rsp+0x80], xmm8
00007531fdbdcf1b  vmovaps [rsp+0x90], xmm9
00007531fdbdcf24  vmovaps [rsp+0xA0], xmm11
00007531fdbdcf2d  vmovaps [rsp+0xB0], xmm12
00007531fdbdcf36  vmovaps [rsp+0xC0], xmm13
00007531fdbdcf3f  vmovaps [rsp+0xD0], xmm14
00007531fdbdcf48  vmovaps [rsp+0xE0], xmm15
00007531fdbdcf51  sub rsp, 0x30
00007531fdbdcf55  movaps [rsp], xmm10
00007531fdbdcf5a  movaps [rsp+0x10], xmm14
00007531fdbdcf60  movaps [rsp+0x20], xmm4
00007531fdbdcf65  lea rdi, [rsp]
00007531fdbdcf69  mov esi, 0x00
00007531fdbdcf6e  mov rax, 0x59ED111DF530
00007531fdbdcf78  call rax
00007531fdbdcf7a  movaps xmm10, [rsp]
00007531fdbdcf7f  add rsp, 0x30
00007531fdbdcf83  vmovaps xmm0, [rsp]
00007531fdbdcf88  vmovaps xmm1, [rsp+0x10]
00007531fdbdcf8e  vmovaps xmm2, [rsp+0x20]
00007531fdbdcf94  vmovaps xmm3, [rsp+0x30]
00007531fdbdcf9a  vmovaps xmm4, [rsp+0x40]
00007531fdbdcfa0  vmovaps xmm5, [rsp+0x50]
00007531fdbdcfa6  vmovaps xmm6, [rsp+0x60]
00007531fdbdcfac  vmovaps xmm7, [rsp+0x70]
00007531fdbdcfb2  vmovaps xmm8, [rsp+0x80]
00007531fdbdcfbb  vmovaps xmm9, [rsp+0x90]
00007531fdbdcfc4  vmovaps xmm11, [rsp+0xA0]
00007531fdbdcfcd  vmovaps xmm12, [rsp+0xB0]
00007531fdbdcfd6  vmovaps xmm13, [rsp+0xC0]
00007531fdbdcfdf  vmovaps xmm14, [rsp+0xD0]
00007531fdbdcfe8  vmovaps xmm15, [rsp+0xE0]
00007531fdbdcff1  add rsp, 0xF0
00007531fdbdcff8  pop r11
00007531fdbdcffa  pop r10
00007531fdbdcffc  pop r9
00007531fdbdcffe  pop r8
00007531fdbdd000  pop rsi
00007531fdbdd001  pop rdi
00007531fdbdd002  pop rdx
00007531fdbdd003  pop rcx
00007531fdbdd004  pop rax
00007531fdbdd005  add rsp, 0x08
00007531fdbdd009  jmp 0x00007531FDBD9568
00007531fdbdd00e  sub rsp, 0x08
00007531fdbdd012  push rax
00007531fdbdd013  push rcx
00007531fdbdd014  push rdx
00007531fdbdd015  push rdi
00007531fdbdd016  push rsi
00007531fdbdd017  push r8
00007531fdbdd019  push r9
00007531fdbdd01b  push r10
00007531fdbdd01d  push r11
00007531fdbdd01f  sub rsp, 0xF0
00007531fdbdd026  vmovaps [rsp], xmm0
00007531fdbdd02b  vmovaps [rsp+0x10], xmm1
00007531fdbdd031  vmovaps [rsp+0x20], xmm2
00007531fdbdd037  vmovaps [rsp+0x30], xmm3
00007531fdbdd03d  vmovaps [rsp+0x40], xmm4
00007531fdbdd043  vmovaps [rsp+0x50], xmm5
00007531fdbdd049  vmovaps [rsp+0x60], xmm6
00007531fdbdd04f  vmovaps [rsp+0x70], xmm7
00007531fdbdd055  vmovaps [rsp+0x80], xmm9
00007531fdbdd05e  vmovaps [rsp+0x90], xmm10
00007531fdbdd067  vmovaps [rsp+0xA0], xmm11
00007531fdbdd070  vmovaps [rsp+0xB0], xmm12
00007531fdbdd079  vmovaps [rsp+0xC0], xmm13
00007531fdbdd082  vmovaps [rsp+0xD0], xmm14
00007531fdbdd08b  vmovaps [rsp+0xE0], xmm15
00007531fdbdd094  sub rsp, 0x30
00007531fdbdd098  movaps [rsp], xmm8
00007531fdbdd09d  movaps [rsp+0x10], xmm1
00007531fdbdd0a2  movaps [rsp+0x20], xmm14
00007531fdbdd0a8  lea rdi, [rsp]
00007531fdbdd0ac  mov esi, 0x00
00007531fdbdd0b1  mov rax, 0x59ED111DF530
00007531fdbdd0bb  call rax
00007531fdbdd0bd  movaps xmm8, [rsp]
00007531fdbdd0c2  add rsp, 0x30
00007531fdbdd0c6  vmovaps xmm0, [rsp]
00007531fdbdd0cb  vmovaps xmm1, [rsp+0x10]
00007531fdbdd0d1  vmovaps xmm2, [rsp+0x20]
00007531fdbdd0d7  vmovaps xmm3, [rsp+0x30]
00007531fdbdd0dd  vmovaps xmm4, [rsp+0x40]
00007531fdbdd0e3  vmovaps xmm5, [rsp+0x50]
00007531fdbdd0e9  vmovaps xmm6, [rsp+0x60]
00007531fdbdd0ef  vmovaps xmm7, [rsp+0x70]
00007531fdbdd0f5  vmovaps xmm9, [rsp+0x80]
00007531fdbdd0fe  vmovaps xmm10, [rsp+0x90]
00007531fdbdd107  vmovaps xmm11, [rsp+0xA0]
00007531fdbdd110  vmovaps xmm12, [rsp+0xB0]
00007531fdbdd119  vmovaps xmm13, [rsp+0xC0]
00007531fdbdd122  vmovaps xmm14, [rsp+0xD0]
00007531fdbdd12b  vmovaps xmm15, [rsp+0xE0]
00007531fdbdd134  add rsp, 0xF0
00007531fdbdd13b  pop r11
00007531fdbdd13d  pop r10
00007531fdbdd13f  pop r9
00007531fdbdd141  pop r8
00007531fdbdd143  pop rsi
00007531fdbdd144  pop rdi
00007531fdbdd145  pop rdx
00007531fdbdd146  pop rcx
00007531fdbdd147  pop rax
00007531fdbdd148  add rsp, 0x08
00007531fdbdd14c  jmp 0x00007531FDBD958E
00007531fdbdd151  sub rsp, 0x08
00007531fdbdd155  push rax
00007531fdbdd156  push rcx
00007531fdbdd157  push rdx
00007531fdbdd158  push rdi
00007531fdbdd159  push rsi
00007531fdbdd15a  push r8
00007531fdbdd15c  push r9
00007531fdbdd15e  push r10
00007531fdbdd160  push r11
00007531fdbdd162  sub rsp, 0xF0
00007531fdbdd169  vmovaps [rsp], xmm0
00007531fdbdd16e  vmovaps [rsp+0x10], xmm1
00007531fdbdd174  vmovaps [rsp+0x20], xmm2
00007531fdbdd17a  vmovaps [rsp+0x30], xmm3
00007531fdbdd180  vmovaps [rsp+0x40], xmm4
00007531fdbdd186  vmovaps [rsp+0x50], xmm5
00007531fdbdd18c  vmovaps [rsp+0x60], xmm7
00007531fdbdd192  vmovaps [rsp+0x70], xmm8
00007531fdbdd198  vmovaps [rsp+0x80], xmm9
00007531fdbdd1a1  vmovaps [rsp+0x90], xmm10
00007531fdbdd1aa  vmovaps [rsp+0xA0], xmm11
00007531fdbdd1b3  vmovaps [rsp+0xB0], xmm12
00007531fdbdd1bc  vmovaps [rsp+0xC0], xmm13
00007531fdbdd1c5  vmovaps [rsp+0xD0], xmm14
00007531fdbdd1ce  vmovaps [rsp+0xE0], xmm15
00007531fdbdd1d7  sub rsp, 0x30
00007531fdbdd1db  movaps [rsp], xmm6
00007531fdbdd1df  movaps [rsp+0x10], xmm1
00007531fdbdd1e4  movaps [rsp+0x20], xmm14
00007531fdbdd1ea  lea rdi, [rsp]
00007531fdbdd1ee  mov esi, 0x00
00007531fdbdd1f3  mov rax, 0x59ED111DF530
00007531fdbdd1fd  call rax
00007531fdbdd1ff  movaps xmm6, [rsp]
00007531fdbdd203  add rsp, 0x30
00007531fdbdd207  vmovaps xmm0, [rsp]
00007531fdbdd20c  vmovaps xmm1, [rsp+0x10]
00007531fdbdd212  vmovaps xmm2, [rsp+0x20]
00007531fdbdd218  vmovaps xmm3, [rsp+0x30]
00007531fdbdd21e  vmovaps xmm4, [rsp+0x40]
00007531fdbdd224  vmovaps xmm5, [rsp+0x50]
00007531fdbdd22a  vmovaps xmm7, [rsp+0x60]
00007531fdbdd230  vmovaps xmm8, [rsp+0x70]
00007531fdbdd236  vmovaps xmm9, [rsp+0x80]
00007531fdbdd23f  vmovaps xmm10, [rsp+0x90]
00007531fdbdd248  vmovaps xmm11, [rsp+0xA0]
00007531fdbdd251  vmovaps xmm12, [rsp+0xB0]
00007531fdbdd25a  vmovaps xmm13, [rsp+0xC0]
00007531fdbdd263  vmovaps xmm14, [rsp+0xD0]
00007531fdbdd26c  vmovaps xmm15, [rsp+0xE0]
00007531fdbdd275  add rsp, 0xF0
00007531fdbdd27c  pop r11
00007531fdbdd27e  pop r10
00007531fdbdd280  pop r9
00007531fdbdd282  pop r8
00007531fdbdd284  pop rsi
00007531fdbdd285  pop rdi
00007531fdbdd286  pop rdx
00007531fdbdd287  pop rcx
00007531fdbdd288  pop rax
00007531fdbdd289  add rsp, 0x08
00007531fdbdd28d  jmp 0x00007531FDBD95BA
00007531fdbdd292  sub rsp, 0x08
00007531fdbdd296  push rax
00007531fdbdd297  push rcx
00007531fdbdd298  push rdx
00007531fdbdd299  push rdi
00007531fdbdd29a  push rsi
00007531fdbdd29b  push r8
00007531fdbdd29d  push r9
00007531fdbdd29f  push r10
00007531fdbdd2a1  push r11
00007531fdbdd2a3  sub rsp, 0xF0
00007531fdbdd2aa  vmovaps [rsp], xmm0
00007531fdbdd2af  vmovaps [rsp+0x10], xmm1
00007531fdbdd2b5  vmovaps [rsp+0x20], xmm2
00007531fdbdd2bb  vmovaps [rsp+0x30], xmm3
00007531fdbdd2c1  vmovaps [rsp+0x40], xmm4
00007531fdbdd2c7  vmovaps [rsp+0x50], xmm5
00007531fdbdd2cd  vmovaps [rsp+0x60], xmm6
00007531fdbdd2d3  vmovaps [rsp+0x70], xmm7
00007531fdbdd2d9  vmovaps [rsp+0x80], xmm8
00007531fdbdd2e2  vmovaps [rsp+0x90], xmm9
00007531fdbdd2eb  vmovaps [rsp+0xA0], xmm10
00007531fdbdd2f4  vmovaps [rsp+0xB0], xmm11
00007531fdbdd2fd  vmovaps [rsp+0xC0], xmm12
00007531fdbdd306  vmovaps [rsp+0xD0], xmm13
00007531fdbdd30f  vmovaps [rsp+0xE0], xmm15
00007531fdbdd318  sub rsp, 0x30
00007531fdbdd31c  movaps [rsp], xmm14
00007531fdbdd321  movaps [rsp+0x10], xmm12
00007531fdbdd327  movaps [rsp+0x20], xmm1
00007531fdbdd32c  lea rdi, [rsp]
00007531fdbdd330  mov esi, 0x00
00007531fdbdd335  mov rax, 0x59ED111DF530
00007531fdbdd33f  call rax
00007531fdbdd341  movaps xmm14, [rsp]
00007531fdbdd346  add rsp, 0x30
00007531fdbdd34a  vmovaps xmm0, [rsp]
00007531fdbdd34f  vmovaps xmm1, [rsp+0x10]
00007531fdbdd355  vmovaps xmm2, [rsp+0x20]
00007531fdbdd35b  vmovaps xmm3, [rsp+0x30]
00007531fdbdd361  vmovaps xmm4, [rsp+0x40]
00007531fdbdd367  vmovaps xmm5, [rsp+0x50]
00007531fdbdd36d  vmovaps xmm6, [rsp+0x60]
00007531fdbdd373  vmovaps xmm7, [rsp+0x70]
00007531fdbdd379  vmovaps xmm8, [rsp+0x80]
00007531fdbdd382  vmovaps xmm9, [rsp+0x90]
00007531fdbdd38b  vmovaps xmm10, [rsp+0xA0]
00007531fdbdd394  vmovaps xmm11, [rsp+0xB0]
00007531fdbdd39d  vmovaps xmm12, [rsp+0xC0]
00007531fdbdd3a6  vmovaps xmm13, [rsp+0xD0]
00007531fdbdd3af  vmovaps xmm15, [rsp+0xE0]
00007531fdbdd3b8  add rsp, 0xF0
00007531fdbdd3bf  pop r11
00007531fdbdd3c1  pop r10
00007531fdbdd3c3  pop r9
00007531fdbdd3c5  pop r8
00007531fdbdd3c7  pop rsi
00007531fdbdd3c8  pop rdi
00007531fdbdd3c9  pop rdx
00007531fdbdd3ca  pop rcx
00007531fdbdd3cb  pop rax
00007531fdbdd3cc  add rsp, 0x08
00007531fdbdd3d0  jmp 0x00007531FDBD95E0
00007531fdbdd3d5  sub rsp, 0x08
00007531fdbdd3d9  push rax
00007531fdbdd3da  push rcx
00007531fdbdd3db  push rdx
00007531fdbdd3dc  push rdi
00007531fdbdd3dd  push rsi
00007531fdbdd3de  push r8
00007531fdbdd3e0  push r9
00007531fdbdd3e2  push r10
00007531fdbdd3e4  push r11
00007531fdbdd3e6  sub rsp, 0xF0
00007531fdbdd3ed  vmovaps [rsp], xmm0
00007531fdbdd3f2  vmovaps [rsp+0x10], xmm2
00007531fdbdd3f8  vmovaps [rsp+0x20], xmm3
00007531fdbdd3fe  vmovaps [rsp+0x30], xmm4
00007531fdbdd404  vmovaps [rsp+0x40], xmm5
00007531fdbdd40a  vmovaps [rsp+0x50], xmm6
00007531fdbdd410  vmovaps [rsp+0x60], xmm7
00007531fdbdd416  vmovaps [rsp+0x70], xmm8
00007531fdbdd41c  vmovaps [rsp+0x80], xmm9
00007531fdbdd425  vmovaps [rsp+0x90], xmm10
00007531fdbdd42e  vmovaps [rsp+0xA0], xmm11
00007531fdbdd437  vmovaps [rsp+0xB0], xmm12
00007531fdbdd440  vmovaps [rsp+0xC0], xmm13
00007531fdbdd449  vmovaps [rsp+0xD0], xmm14
00007531fdbdd452  vmovaps [rsp+0xE0], xmm15
00007531fdbdd45b  sub rsp, 0x30
00007531fdbdd45f  movaps [rsp], xmm1
00007531fdbdd463  movaps [rsp+0x10], xmm13
00007531fdbdd469  movaps [rsp+0x20], xmm9
00007531fdbdd46f  lea rdi, [rsp]
00007531fdbdd473  mov esi, 0x00
00007531fdbdd478  mov rax, 0x59ED111DF530
00007531fdbdd482  call rax
00007531fdbdd484  movaps xmm1, [rsp]
00007531fdbdd488  add rsp, 0x30
00007531fdbdd48c  vmovaps xmm0, [rsp]
00007531fdbdd491  vmovaps xmm2, [rsp+0x10]
00007531fdbdd497  vmovaps xmm3, [rsp+0x20]
00007531fdbdd49d  vmovaps xmm4, [rsp+0x30]
00007531fdbdd4a3  vmovaps xmm5, [rsp+0x40]
00007531fdbdd4a9  vmovaps xmm6, [rsp+0x50]
00007531fdbdd4af  vmovaps xmm7, [rsp+0x60]
00007531fdbdd4b5  vmovaps xmm8, [rsp+0x70]
00007531fdbdd4bb  vmovaps xmm9, [rsp+0x80]
00007531fdbdd4c4  vmovaps xmm10, [rsp+0x90]
00007531fdbdd4cd  vmovaps xmm11, [rsp+0xA0]
00007531fdbdd4d6  vmovaps xmm12, [rsp+0xB0]
00007531fdbdd4df  vmovaps xmm13, [rsp+0xC0]
00007531fdbdd4e8  vmovaps xmm14, [rsp+0xD0]
00007531fdbdd4f1  vmovaps xmm15, [rsp+0xE0]
00007531fdbdd4fa  add rsp, 0xF0
00007531fdbdd501  pop r11
00007531fdbdd503  pop r10
00007531fdbdd505  pop r9
00007531fdbdd507  pop r8
00007531fdbdd509  pop rsi
00007531fdbdd50a  pop rdi
00007531fdbdd50b  pop rdx
00007531fdbdd50c  pop rcx
00007531fdbdd50d  pop rax
00007531fdbdd50e  add rsp, 0x08
00007531fdbdd512  jmp 0x00007531FDBD95FA
00007531fdbdd517  sub rsp, 0x08
00007531fdbdd51b  push rax
00007531fdbdd51c  push rcx
00007531fdbdd51d  push rdx
00007531fdbdd51e  push rdi
00007531fdbdd51f  push rsi
00007531fdbdd520  push r8
00007531fdbdd522  push r9
00007531fdbdd524  push r10
00007531fdbdd526  push r11
00007531fdbdd528  sub rsp, 0xF0
00007531fdbdd52f  vmovaps [rsp], xmm0
00007531fdbdd534  vmovaps [rsp+0x10], xmm1
00007531fdbdd53a  vmovaps [rsp+0x20], xmm2
00007531fdbdd540  vmovaps [rsp+0x30], xmm3
00007531fdbdd546  vmovaps [rsp+0x40], xmm4
00007531fdbdd54c  vmovaps [rsp+0x50], xmm5
00007531fdbdd552  vmovaps [rsp+0x60], xmm6
00007531fdbdd558  vmovaps [rsp+0x70], xmm7
00007531fdbdd55e  vmovaps [rsp+0x80], xmm8
00007531fdbdd567  vmovaps [rsp+0x90], xmm9
00007531fdbdd570  vmovaps [rsp+0xA0], xmm10
00007531fdbdd579  vmovaps [rsp+0xB0], xmm11
00007531fdbdd582  vmovaps [rsp+0xC0], xmm13
00007531fdbdd58b  vmovaps [rsp+0xD0], xmm14
00007531fdbdd594  vmovaps [rsp+0xE0], xmm15
00007531fdbdd59d  sub rsp, 0x30
00007531fdbdd5a1  movaps [rsp], xmm12
00007531fdbdd5a6  movaps [rsp+0x10], xmm7
00007531fdbdd5ab  movaps [rsp+0x20], xmm13
00007531fdbdd5b1  lea rdi, [rsp]
00007531fdbdd5b5  mov esi, 0x00
00007531fdbdd5ba  mov rax, 0x59ED111DF530
00007531fdbdd5c4  call rax
00007531fdbdd5c6  movaps xmm12, [rsp]
00007531fdbdd5cb  add rsp, 0x30
00007531fdbdd5cf  vmovaps xmm0, [rsp]
00007531fdbdd5d4  vmovaps xmm1, [rsp+0x10]
00007531fdbdd5da  vmovaps xmm2, [rsp+0x20]
00007531fdbdd5e0  vmovaps xmm3, [rsp+0x30]
00007531fdbdd5e6  vmovaps xmm4, [rsp+0x40]
00007531fdbdd5ec  vmovaps xmm5, [rsp+0x50]
00007531fdbdd5f2  vmovaps xmm6, [rsp+0x60]
00007531fdbdd5f8  vmovaps xmm7, [rsp+0x70]
00007531fdbdd5fe  vmovaps xmm8, [rsp+0x80]
00007531fdbdd607  vmovaps xmm9, [rsp+0x90]
00007531fdbdd610  vmovaps xmm10, [rsp+0xA0]
00007531fdbdd619  vmovaps xmm11, [rsp+0xB0]
00007531fdbdd622  vmovaps xmm13, [rsp+0xC0]
00007531fdbdd62b  vmovaps xmm14, [rsp+0xD0]
00007531fdbdd634  vmovaps xmm15, [rsp+0xE0]
00007531fdbdd63d  add rsp, 0xF0
00007531fdbdd644  pop r11
00007531fdbdd646  pop r10
00007531fdbdd648  pop r9
00007531fdbdd64a  pop r8
00007531fdbdd64c  pop rsi
00007531fdbdd64d  pop rdi
00007531fdbdd64e  pop rdx
00007531fdbdd64f  pop rcx
00007531fdbdd650  pop rax
00007531fdbdd651  add rsp, 0x08
00007531fdbdd655  jmp 0x00007531FDBD9621
00007531fdbdd65a  sub rsp, 0x08
00007531fdbdd65e  push rax
00007531fdbdd65f  push rcx
00007531fdbdd660  push rdx
00007531fdbdd661  push rdi
00007531fdbdd662  push rsi
00007531fdbdd663  push r8
00007531fdbdd665  push r9
00007531fdbdd667  push r10
00007531fdbdd669  push r11
00007531fdbdd66b  sub rsp, 0xF0
00007531fdbdd672  vmovaps [rsp], xmm0
00007531fdbdd677  vmovaps [rsp+0x10], xmm1
00007531fdbdd67d  vmovaps [rsp+0x20], xmm2
00007531fdbdd683  vmovaps [rsp+0x30], xmm3
00007531fdbdd689  vmovaps [rsp+0x40], xmm4
00007531fdbdd68f  vmovaps [rsp+0x50], xmm5
00007531fdbdd695  vmovaps [rsp+0x60], xmm6
00007531fdbdd69b  vmovaps [rsp+0x70], xmm7
00007531fdbdd6a1  vmovaps [rsp+0x80], xmm8
00007531fdbdd6aa  vmovaps [rsp+0x90], xmm9
00007531fdbdd6b3  vmovaps [rsp+0xA0], xmm10
00007531fdbdd6bc  vmovaps [rsp+0xB0], xmm11
00007531fdbdd6c5  vmovaps [rsp+0xC0], xmm12
00007531fdbdd6ce  vmovaps [rsp+0xD0], xmm14
00007531fdbdd6d7  vmovaps [rsp+0xE0], xmm15
00007531fdbdd6e0  sub rsp, 0x30
00007531fdbdd6e4  movaps [rsp], xmm13
00007531fdbdd6e9  movaps [rsp+0x10], xmm15
00007531fdbdd6ef  movaps [rsp+0x20], xmm8
00007531fdbdd6f5  lea rdi, [rsp]
00007531fdbdd6f9  mov esi, 0x00
00007531fdbdd6fe  mov rax, 0x59ED111DF530
00007531fdbdd708  call rax
00007531fdbdd70a  movaps xmm13, [rsp]
00007531fdbdd70f  add rsp, 0x30
00007531fdbdd713  vmovaps xmm0, [rsp]
00007531fdbdd718  vmovaps xmm1, [rsp+0x10]
00007531fdbdd71e  vmovaps xmm2, [rsp+0x20]
00007531fdbdd724  vmovaps xmm3, [rsp+0x30]
00007531fdbdd72a  vmovaps xmm4, [rsp+0x40]
00007531fdbdd730  vmovaps xmm5, [rsp+0x50]
00007531fdbdd736  vmovaps xmm6, [rsp+0x60]
00007531fdbdd73c  vmovaps xmm7, [rsp+0x70]
00007531fdbdd742  vmovaps xmm8, [rsp+0x80]
00007531fdbdd74b  vmovaps xmm9, [rsp+0x90]
00007531fdbdd754  vmovaps xmm10, [rsp+0xA0]
00007531fdbdd75d  vmovaps xmm11, [rsp+0xB0]
00007531fdbdd766  vmovaps xmm12, [rsp+0xC0]
00007531fdbdd76f  vmovaps xmm14, [rsp+0xD0]
00007531fdbdd778  vmovaps xmm15, [rsp+0xE0]
00007531fdbdd781  add rsp, 0xF0
00007531fdbdd788  pop r11
00007531fdbdd78a  pop r10
00007531fdbdd78c  pop r9
00007531fdbdd78e  pop r8
00007531fdbdd790  pop rsi
00007531fdbdd791  pop rdi
00007531fdbdd792  pop rdx
00007531fdbdd793  pop rcx
00007531fdbdd794  pop rax
00007531fdbdd795  add rsp, 0x08
00007531fdbdd799  jmp 0x00007531FDBD963C
00007531fdbdd79e  sub rsp, 0x08
00007531fdbdd7a2  push rax
00007531fdbdd7a3  push rcx
00007531fdbdd7a4  push rdx
00007531fdbdd7a5  push rdi
00007531fdbdd7a6  push rsi
00007531fdbdd7a7  push r8
00007531fdbdd7a9  push r9
00007531fdbdd7ab  push r10
00007531fdbdd7ad  push r11
00007531fdbdd7af  sub rsp, 0xF0
00007531fdbdd7b6  vmovaps [rsp], xmm0
00007531fdbdd7bb  vmovaps [rsp+0x10], xmm1
00007531fdbdd7c1  vmovaps [rsp+0x20], xmm2
00007531fdbdd7c7  vmovaps [rsp+0x30], xmm3
00007531fdbdd7cd  vmovaps [rsp+0x40], xmm4
00007531fdbdd7d3  vmovaps [rsp+0x50], xmm5
00007531fdbdd7d9  vmovaps [rsp+0x60], xmm6
00007531fdbdd7df  vmovaps [rsp+0x70], xmm7
00007531fdbdd7e5  vmovaps [rsp+0x80], xmm9
00007531fdbdd7ee  vmovaps [rsp+0x90], xmm10
00007531fdbdd7f7  vmovaps [rsp+0xA0], xmm11
00007531fdbdd800  vmovaps [rsp+0xB0], xmm12
00007531fdbdd809  vmovaps [rsp+0xC0], xmm13
00007531fdbdd812  vmovaps [rsp+0xD0], xmm14
00007531fdbdd81b  vmovaps [rsp+0xE0], xmm15
00007531fdbdd824  sub rsp, 0x30
00007531fdbdd828  movaps [rsp], xmm8
00007531fdbdd82d  movaps [rsp+0x10], xmm15
00007531fdbdd833  movaps [rsp+0x20], xmm9
00007531fdbdd839  lea rdi, [rsp]
00007531fdbdd83d  mov esi, 0x00
00007531fdbdd842  mov rax, 0x59ED111DF530
00007531fdbdd84c  call rax
00007531fdbdd84e  movaps xmm8, [rsp]
00007531fdbdd853  add rsp, 0x30
00007531fdbdd857  vmovaps xmm0, [rsp]
00007531fdbdd85c  vmovaps xmm1, [rsp+0x10]
00007531fdbdd862  vmovaps xmm2, [rsp+0x20]
00007531fdbdd868  vmovaps xmm3, [rsp+0x30]
00007531fdbdd86e  vmovaps xmm4, [rsp+0x40]
00007531fdbdd874  vmovaps xmm5, [rsp+0x50]
00007531fdbdd87a  vmovaps xmm6, [rsp+0x60]
00007531fdbdd880  vmovaps xmm7, [rsp+0x70]
00007531fdbdd886  vmovaps xmm9, [rsp+0x80]
00007531fdbdd88f  vmovaps xmm10, [rsp+0x90]
00007531fdbdd898  vmovaps xmm11, [rsp+0xA0]
00007531fdbdd8a1  vmovaps xmm12, [rsp+0xB0]
00007531fdbdd8aa  vmovaps xmm13, [rsp+0xC0]
00007531fdbdd8b3  vmovaps xmm14, [rsp+0xD0]
00007531fdbdd8bc  vmovaps xmm15, [rsp+0xE0]
00007531fdbdd8c5  add rsp, 0xF0
00007531fdbdd8cc  pop r11
00007531fdbdd8ce  pop r10
00007531fdbdd8d0  pop r9
00007531fdbdd8d2  pop r8
00007531fdbdd8d4  pop rsi
00007531fdbdd8d5  pop rdi
00007531fdbdd8d6  pop rdx
00007531fdbdd8d7  pop rcx
00007531fdbdd8d8  pop rax
00007531fdbdd8d9  add rsp, 0x08
00007531fdbdd8dd  jmp 0x00007531FDBD966A
00007531fdbdd8e2  sub rsp, 0x08
00007531fdbdd8e6  push rax
00007531fdbdd8e7  push rcx
00007531fdbdd8e8  push rdx
00007531fdbdd8e9  push rdi
00007531fdbdd8ea  push rsi
00007531fdbdd8eb  push r8
00007531fdbdd8ed  push r9
00007531fdbdd8ef  push r10
00007531fdbdd8f1  push r11
00007531fdbdd8f3  sub rsp, 0xF0
00007531fdbdd8fa  vmovaps [rsp], xmm0
00007531fdbdd8ff  vmovaps [rsp+0x10], xmm1
00007531fdbdd905  vmovaps [rsp+0x20], xmm2
00007531fdbdd90b  vmovaps [rsp+0x30], xmm3
00007531fdbdd911  vmovaps [rsp+0x40], xmm4
00007531fdbdd917  vmovaps [rsp+0x50], xmm5
00007531fdbdd91d  vmovaps [rsp+0x60], xmm6
00007531fdbdd923  vmovaps [rsp+0x70], xmm7
00007531fdbdd929  vmovaps [rsp+0x80], xmm8
00007531fdbdd932  vmovaps [rsp+0x90], xmm9
00007531fdbdd93b  vmovaps [rsp+0xA0], xmm10
00007531fdbdd944  vmovaps [rsp+0xB0], xmm11
00007531fdbdd94d  vmovaps [rsp+0xC0], xmm12
00007531fdbdd956  vmovaps [rsp+0xD0], xmm13
00007531fdbdd95f  vmovaps [rsp+0xE0], xmm14
00007531fdbdd968  sub rsp, 0x30
00007531fdbdd96c  movaps [rsp], xmm15
00007531fdbdd971  movaps [rsp+0x10], xmm11
00007531fdbdd977  movaps [rsp+0x20], xmm6
00007531fdbdd97c  lea rdi, [rsp]
00007531fdbdd980  mov esi, 0x00
00007531fdbdd985  mov rax, 0x59ED111DF530
00007531fdbdd98f  call rax
00007531fdbdd991  movaps xmm15, [rsp]
00007531fdbdd996  add rsp, 0x30
00007531fdbdd99a  vmovaps xmm0, [rsp]
00007531fdbdd99f  vmovaps xmm1, [rsp+0x10]
00007531fdbdd9a5  vmovaps xmm2, [rsp+0x20]
00007531fdbdd9ab  vmovaps xmm3, [rsp+0x30]
00007531fdbdd9b1  vmovaps xmm4, [rsp+0x40]
00007531fdbdd9b7  vmovaps xmm5, [rsp+0x50]
00007531fdbdd9bd  vmovaps xmm6, [rsp+0x60]
00007531fdbdd9c3  vmovaps xmm7, [rsp+0x70]
00007531fdbdd9c9  vmovaps xmm8, [rsp+0x80]
00007531fdbdd9d2  vmovaps xmm9, [rsp+0x90]
00007531fdbdd9db  vmovaps xmm10, [rsp+0xA0]
00007531fdbdd9e4  vmovaps xmm11, [rsp+0xB0]
00007531fdbdd9ed  vmovaps xmm12, [rsp+0xC0]
00007531fdbdd9f6  vmovaps xmm13, [rsp+0xD0]
00007531fdbdd9ff  vmovaps xmm14, [rsp+0xE0]
00007531fdbdda08  add rsp, 0xF0
00007531fdbdda0f  pop r11
00007531fdbdda11  pop r10
00007531fdbdda13  pop r9
00007531fdbdda15  pop r8
00007531fdbdda17  pop rsi
00007531fdbdda18  pop rdi
00007531fdbdda19  pop rdx
00007531fdbdda1a  pop rcx
00007531fdbdda1b  pop rax
00007531fdbdda1c  add rsp, 0x08
00007531fdbdda20  jmp 0x00007531FDBD9685
00007531fdbdda25  sub rsp, 0x08
00007531fdbdda29  push rax
00007531fdbdda2a  push rcx
00007531fdbdda2b  push rdx
00007531fdbdda2c  push rdi
00007531fdbdda2d  push rsi
00007531fdbdda2e  push r8
00007531fdbdda30  push r9
00007531fdbdda32  push r10
00007531fdbdda34  push r11
00007531fdbdda36  sub rsp, 0xF0
00007531fdbdda3d  vmovaps [rsp], xmm0
00007531fdbdda42  vmovaps [rsp+0x10], xmm1
00007531fdbdda48  vmovaps [rsp+0x20], xmm2
00007531fdbdda4e  vmovaps [rsp+0x30], xmm3
00007531fdbdda54  vmovaps [rsp+0x40], xmm4
00007531fdbdda5a  vmovaps [rsp+0x50], xmm5
00007531fdbdda60  vmovaps [rsp+0x60], xmm6
00007531fdbdda66  vmovaps [rsp+0x70], xmm8
00007531fdbdda6c  vmovaps [rsp+0x80], xmm9
00007531fdbdda75  vmovaps [rsp+0x90], xmm10
00007531fdbdda7e  vmovaps [rsp+0xA0], xmm11
00007531fdbdda87  vmovaps [rsp+0xB0], xmm12
00007531fdbdda90  vmovaps [rsp+0xC0], xmm13
00007531fdbdda99  vmovaps [rsp+0xD0], xmm14
00007531fdbddaa2  vmovaps [rsp+0xE0], xmm15
00007531fdbddaab  sub rsp, 0x30
00007531fdbddaaf  movaps [rsp], xmm7
00007531fdbddab3  movaps [rsp+0x10], xmm11
00007531fdbddab9  movaps [rsp+0x20], xmm9
00007531fdbddabf  lea rdi, [rsp]
00007531fdbddac3  mov esi, 0x00
00007531fdbddac8  mov rax, 0x59ED111DF530
00007531fdbddad2  call rax
00007531fdbddad4  movaps xmm7, [rsp]
00007531fdbddad8  add rsp, 0x30
00007531fdbddadc  vmovaps xmm0, [rsp]
00007531fdbddae1  vmovaps xmm1, [rsp+0x10]
00007531fdbddae7  vmovaps xmm2, [rsp+0x20]
00007531fdbddaed  vmovaps xmm3, [rsp+0x30]
00007531fdbddaf3  vmovaps xmm4, [rsp+0x40]
00007531fdbddaf9  vmovaps xmm5, [rsp+0x50]
00007531fdbddaff  vmovaps xmm6, [rsp+0x60]
00007531fdbddb05  vmovaps xmm8, [rsp+0x70]
00007531fdbddb0b  vmovaps xmm9, [rsp+0x80]
00007531fdbddb14  vmovaps xmm10, [rsp+0x90]
00007531fdbddb1d  vmovaps xmm11, [rsp+0xA0]
00007531fdbddb26  vmovaps xmm12, [rsp+0xB0]
00007531fdbddb2f  vmovaps xmm13, [rsp+0xC0]
00007531fdbddb38  vmovaps xmm14, [rsp+0xD0]
00007531fdbddb41  vmovaps xmm15, [rsp+0xE0]
00007531fdbddb4a  add rsp, 0xF0
00007531fdbddb51  pop r11
00007531fdbddb53  pop r10
00007531fdbddb55  pop r9
00007531fdbddb57  pop r8
00007531fdbddb59  pop rsi
00007531fdbddb5a  pop rdi
00007531fdbddb5b  pop rdx
00007531fdbddb5c  pop rcx
00007531fdbddb5d  pop rax
00007531fdbddb5e  add rsp, 0x08
00007531fdbddb62  jmp 0x00007531FDBD96B2
00007531fdbddb67  sub rsp, 0x08
00007531fdbddb6b  push rax
00007531fdbddb6c  push rcx
00007531fdbddb6d  push rdx
00007531fdbddb6e  push rdi
00007531fdbddb6f  push rsi
00007531fdbddb70  push r8
00007531fdbddb72  push r9
00007531fdbddb74  push r10
00007531fdbddb76  push r11
00007531fdbddb78  sub rsp, 0xF0
00007531fdbddb7f  vmovaps [rsp], xmm0
00007531fdbddb84  vmovaps [rsp+0x10], xmm1
00007531fdbddb8a  vmovaps [rsp+0x20], xmm2
00007531fdbddb90  vmovaps [rsp+0x30], xmm3
00007531fdbddb96  vmovaps [rsp+0x40], xmm4
00007531fdbddb9c  vmovaps [rsp+0x50], xmm5
00007531fdbddba2  vmovaps [rsp+0x60], xmm6
00007531fdbddba8  vmovaps [rsp+0x70], xmm7
00007531fdbddbae  vmovaps [rsp+0x80], xmm8
00007531fdbddbb7  vmovaps [rsp+0x90], xmm9
00007531fdbddbc0  vmovaps [rsp+0xA0], xmm10
00007531fdbddbc9  vmovaps [rsp+0xB0], xmm12
00007531fdbddbd2  vmovaps [rsp+0xC0], xmm13
00007531fdbddbdb  vmovaps [rsp+0xD0], xmm14
00007531fdbddbe4  vmovaps [rsp+0xE0], xmm15
00007531fdbddbed  sub rsp, 0x30
00007531fdbddbf1  movaps [rsp], xmm11
00007531fdbddbf6  movaps [rsp+0x10], xmm10
00007531fdbddbfc  movaps [rsp+0x20], xmm14
00007531fdbddc02  lea rdi, [rsp]
00007531fdbddc06  mov esi, 0x00
00007531fdbddc0b  mov rax, 0x59ED111DF530
00007531fdbddc15  call rax
00007531fdbddc17  movaps xmm11, [rsp]
00007531fdbddc1c  add rsp, 0x30
00007531fdbddc20  vmovaps xmm0, [rsp]
00007531fdbddc25  vmovaps xmm1, [rsp+0x10]
00007531fdbddc2b  vmovaps xmm2, [rsp+0x20]
00007531fdbddc31  vmovaps xmm3, [rsp+0x30]
00007531fdbddc37  vmovaps xmm4, [rsp+0x40]
00007531fdbddc3d  vmovaps xmm5, [rsp+0x50]
00007531fdbddc43  vmovaps xmm6, [rsp+0x60]
00007531fdbddc49  vmovaps xmm7, [rsp+0x70]
00007531fdbddc4f  vmovaps xmm8, [rsp+0x80]
00007531fdbddc58  vmovaps xmm9, [rsp+0x90]
00007531fdbddc61  vmovaps xmm10, [rsp+0xA0]
00007531fdbddc6a  vmovaps xmm12, [rsp+0xB0]
00007531fdbddc73  vmovaps xmm13, [rsp+0xC0]
00007531fdbddc7c  vmovaps xmm14, [rsp+0xD0]
00007531fdbddc85  vmovaps xmm15, [rsp+0xE0]
00007531fdbddc8e  add rsp, 0xF0
00007531fdbddc95  pop r11
00007531fdbddc97  pop r10
00007531fdbddc99  pop r9
00007531fdbddc9b  pop r8
00007531fdbddc9d  pop rsi
00007531fdbddc9e  pop rdi
00007531fdbddc9f  pop rdx
00007531fdbddca0  pop rcx
00007531fdbddca1  pop rax
00007531fdbddca2  add rsp, 0x08
00007531fdbddca6  jmp 0x00007531FDBD96CD
00007531fdbddcab  call 0x00007531FDAE45A0
00007531fdbddcb0  jmp 0x00007531FDBD96D7
00007531fdbddcb5  sub rsp, 0x08
00007531fdbddcb9  push rax
00007531fdbddcba  push rcx
00007531fdbddcbb  push rdx
00007531fdbddcbc  push rdi
00007531fdbddcbd  push rsi
00007531fdbddcbe  push r8
00007531fdbddcc0  push r9
00007531fdbddcc2  push r10
00007531fdbddcc4  push r11
00007531fdbddcc6  sub rsp, 0xF0
00007531fdbddccd  vmovaps [rsp], xmm0
00007531fdbddcd2  vmovaps [rsp+0x10], xmm1
00007531fdbddcd8  vmovaps [rsp+0x20], xmm2
00007531fdbddcde  vmovaps [rsp+0x30], xmm3
00007531fdbddce4  vmovaps [rsp+0x40], xmm4
00007531fdbddcea  vmovaps [rsp+0x50], xmm5
00007531fdbddcf0  vmovaps [rsp+0x60], xmm6
00007531fdbddcf6  vmovaps [rsp+0x70], xmm7
00007531fdbddcfc  vmovaps [rsp+0x80], xmm8
00007531fdbddd05  vmovaps [rsp+0x90], xmm9
00007531fdbddd0e  vmovaps [rsp+0xA0], xmm11
00007531fdbddd17  vmovaps [rsp+0xB0], xmm12
00007531fdbddd20  vmovaps [rsp+0xC0], xmm13
00007531fdbddd29  vmovaps [rsp+0xD0], xmm14
00007531fdbddd32  vmovaps [rsp+0xE0], xmm15
00007531fdbddd3b  sub rsp, 0x30
00007531fdbddd3f  movaps [rsp], xmm10
00007531fdbddd44  movaps [rsp+0x10], xmm1
00007531fdbddd49  movaps [rsp+0x20], xmm12
00007531fdbddd4f  lea rdi, [rsp]
00007531fdbddd53  mov esi, 0x00
00007531fdbddd58  mov rax, 0x59ED111DF530
00007531fdbddd62  call rax
00007531fdbddd64  movaps xmm10, [rsp]
00007531fdbddd69  add rsp, 0x30
00007531fdbddd6d  vmovaps xmm0, [rsp]
00007531fdbddd72  vmovaps xmm1, [rsp+0x10]
00007531fdbddd78  vmovaps xmm2, [rsp+0x20]
00007531fdbddd7e  vmovaps xmm3, [rsp+0x30]
00007531fdbddd84  vmovaps xmm4, [rsp+0x40]
00007531fdbddd8a  vmovaps xmm5, [rsp+0x50]
00007531fdbddd90  vmovaps xmm6, [rsp+0x60]
00007531fdbddd96  vmovaps xmm7, [rsp+0x70]
00007531fdbddd9c  vmovaps xmm8, [rsp+0x80]
00007531fdbddda5  vmovaps xmm9, [rsp+0x90]
00007531fdbdddae  vmovaps xmm11, [rsp+0xA0]
00007531fdbdddb7  vmovaps xmm12, [rsp+0xB0]
00007531fdbdddc0  vmovaps xmm13, [rsp+0xC0]
00007531fdbdddc9  vmovaps xmm14, [rsp+0xD0]
00007531fdbdddd2  vmovaps xmm15, [rsp+0xE0]
00007531fdbddddb  add rsp, 0xF0
00007531fdbddde2  pop r11
00007531fdbddde4  pop r10
00007531fdbddde6  pop r9
00007531fdbddde8  pop r8
00007531fdbdddea  pop rsi
00007531fdbdddeb  pop rdi
00007531fdbdddec  pop rdx
00007531fdbddded  pop rcx
00007531fdbdddee  pop rax
00007531fdbdddef  add rsp, 0x08
00007531fdbdddf3  jmp 0x00007531FDBD96FA
00007531fdbdddf8  sub rsp, 0x08
00007531fdbdddfc  push rax
00007531fdbdddfd  push rcx
00007531fdbdddfe  push rdx
00007531fdbdddff  push rdi
00007531fdbdde00  push rsi
00007531fdbdde01  push r8
00007531fdbdde03  push r9
00007531fdbdde05  push r10
00007531fdbdde07  push r11
00007531fdbdde09  sub rsp, 0xF0
00007531fdbdde10  vmovaps [rsp], xmm0
00007531fdbdde15  vmovaps [rsp+0x10], xmm1
00007531fdbdde1b  vmovaps [rsp+0x20], xmm2
00007531fdbdde21  vmovaps [rsp+0x30], xmm3
00007531fdbdde27  vmovaps [rsp+0x40], xmm4
00007531fdbdde2d  vmovaps [rsp+0x50], xmm5
00007531fdbdde33  vmovaps [rsp+0x60], xmm6
00007531fdbdde39  vmovaps [rsp+0x70], xmm7
00007531fdbdde3f  vmovaps [rsp+0x80], xmm8
00007531fdbdde48  vmovaps [rsp+0x90], xmm9
00007531fdbdde51  vmovaps [rsp+0xA0], xmm10
00007531fdbdde5a  vmovaps [rsp+0xB0], xmm11
00007531fdbdde63  vmovaps [rsp+0xC0], xmm13
00007531fdbdde6c  vmovaps [rsp+0xD0], xmm14
00007531fdbdde75  vmovaps [rsp+0xE0], xmm15
00007531fdbdde7e  sub rsp, 0x30
00007531fdbdde82  movaps [rsp], xmm12
00007531fdbdde87  movaps [rsp+0x10], xmm14
00007531fdbdde8d  movaps [rsp+0x20], xmm1
00007531fdbdde92  lea rdi, [rsp]
00007531fdbdde96  mov esi, 0x00
00007531fdbdde9b  mov rax, 0x59ED111DF530
00007531fdbddea5  call rax
00007531fdbddea7  movaps xmm12, [rsp]
00007531fdbddeac  add rsp, 0x30
00007531fdbddeb0  vmovaps xmm0, [rsp]
00007531fdbddeb5  vmovaps xmm1, [rsp+0x10]
00007531fdbddebb  vmovaps xmm2, [rsp+0x20]
00007531fdbddec1  vmovaps xmm3, [rsp+0x30]
00007531fdbddec7  vmovaps xmm4, [rsp+0x40]
00007531fdbddecd  vmovaps xmm5, [rsp+0x50]
00007531fdbdded3  vmovaps xmm6, [rsp+0x60]
00007531fdbdded9  vmovaps xmm7, [rsp+0x70]
00007531fdbddedf  vmovaps xmm8, [rsp+0x80]
00007531fdbddee8  vmovaps xmm9, [rsp+0x90]
00007531fdbddef1  vmovaps xmm10, [rsp+0xA0]
00007531fdbddefa  vmovaps xmm11, [rsp+0xB0]
00007531fdbddf03  vmovaps xmm13, [rsp+0xC0]
00007531fdbddf0c  vmovaps xmm14, [rsp+0xD0]
00007531fdbddf15  vmovaps xmm15, [rsp+0xE0]
00007531fdbddf1e  add rsp, 0xF0
00007531fdbddf25  pop r11
00007531fdbddf27  pop r10
00007531fdbddf29  pop r9
00007531fdbddf2b  pop r8
00007531fdbddf2d  pop rsi
00007531fdbddf2e  pop rdi
00007531fdbddf2f  pop rdx
00007531fdbddf30  pop rcx
00007531fdbddf31  pop rax
00007531fdbddf32  add rsp, 0x08
00007531fdbddf36  jmp 0x00007531FDBD9729
00007531fdbddf3b  sub rsp, 0x08
00007531fdbddf3f  push rax
00007531fdbddf40  push rcx
00007531fdbddf41  push rdx
00007531fdbddf42  push rdi
00007531fdbddf43  push rsi
00007531fdbddf44  push r8
00007531fdbddf46  push r9
00007531fdbddf48  push r10
00007531fdbddf4a  push r11
00007531fdbddf4c  sub rsp, 0xF0
00007531fdbddf53  vmovaps [rsp], xmm0
00007531fdbddf58  vmovaps [rsp+0x10], xmm1
00007531fdbddf5e  vmovaps [rsp+0x20], xmm2
00007531fdbddf64  vmovaps [rsp+0x30], xmm3
00007531fdbddf6a  vmovaps [rsp+0x40], xmm4
00007531fdbddf70  vmovaps [rsp+0x50], xmm5
00007531fdbddf76  vmovaps [rsp+0x60], xmm6
00007531fdbddf7c  vmovaps [rsp+0x70], xmm7
00007531fdbddf82  vmovaps [rsp+0x80], xmm8
00007531fdbddf8b  vmovaps [rsp+0x90], xmm9
00007531fdbddf94  vmovaps [rsp+0xA0], xmm10
00007531fdbddf9d  vmovaps [rsp+0xB0], xmm11
00007531fdbddfa6  vmovaps [rsp+0xC0], xmm12
00007531fdbddfaf  vmovaps [rsp+0xD0], xmm13
00007531fdbddfb8  vmovaps [rsp+0xE0], xmm15
00007531fdbddfc1  sub rsp, 0x30
00007531fdbddfc5  movaps [rsp], xmm14
00007531fdbddfca  movaps [rsp+0x10], xmm9
00007531fdbddfd0  movaps [rsp+0x20], xmm1
00007531fdbddfd5  lea rdi, [rsp]
00007531fdbddfd9  mov esi, 0x00
00007531fdbddfde  mov rax, 0x59ED111DF530
00007531fdbddfe8  call rax
00007531fdbddfea  movaps xmm14, [rsp]
00007531fdbddfef  add rsp, 0x30
00007531fdbddff3  vmovaps xmm0, [rsp]
00007531fdbddff8  vmovaps xmm1, [rsp+0x10]
00007531fdbddffe  vmovaps xmm2, [rsp+0x20]
00007531fdbde004  vmovaps xmm3, [rsp+0x30]
00007531fdbde00a  vmovaps xmm4, [rsp+0x40]
00007531fdbde010  vmovaps xmm5, [rsp+0x50]
00007531fdbde016  vmovaps xmm6, [rsp+0x60]
00007531fdbde01c  vmovaps xmm7, [rsp+0x70]
00007531fdbde022  vmovaps xmm8, [rsp+0x80]
00007531fdbde02b  vmovaps xmm9, [rsp+0x90]
00007531fdbde034  vmovaps xmm10, [rsp+0xA0]
00007531fdbde03d  vmovaps xmm11, [rsp+0xB0]
00007531fdbde046  vmovaps xmm12, [rsp+0xC0]
00007531fdbde04f  vmovaps xmm13, [rsp+0xD0]
00007531fdbde058  vmovaps xmm15, [rsp+0xE0]
00007531fdbde061  add rsp, 0xF0
00007531fdbde068  pop r11
00007531fdbde06a  pop r10
00007531fdbde06c  pop r9
00007531fdbde06e  pop r8
00007531fdbde070  pop rsi
00007531fdbde071  pop rdi
00007531fdbde072  pop rdx
00007531fdbde073  pop rcx
00007531fdbde074  pop rax
00007531fdbde075  add rsp, 0x08
00007531fdbde079  jmp 0x00007531FDBD9758
00007531fdbde07e  sub rsp, 0x08
00007531fdbde082  push rax
00007531fdbde083  push rcx
00007531fdbde084  push rdx
00007531fdbde085  push rdi
00007531fdbde086  push rsi
00007531fdbde087  push r8
00007531fdbde089  push r9
00007531fdbde08b  push r10
00007531fdbde08d  push r11
00007531fdbde08f  sub rsp, 0xF0
00007531fdbde096  vmovaps [rsp], xmm0
00007531fdbde09b  vmovaps [rsp+0x10], xmm2
00007531fdbde0a1  vmovaps [rsp+0x20], xmm3
00007531fdbde0a7  vmovaps [rsp+0x30], xmm4
00007531fdbde0ad  vmovaps [rsp+0x40], xmm5
00007531fdbde0b3  vmovaps [rsp+0x50], xmm6
00007531fdbde0b9  vmovaps [rsp+0x60], xmm7
00007531fdbde0bf  vmovaps [rsp+0x70], xmm8
00007531fdbde0c5  vmovaps [rsp+0x80], xmm9
00007531fdbde0ce  vmovaps [rsp+0x90], xmm10
00007531fdbde0d7  vmovaps [rsp+0xA0], xmm11
00007531fdbde0e0  vmovaps [rsp+0xB0], xmm12
00007531fdbde0e9  vmovaps [rsp+0xC0], xmm13
00007531fdbde0f2  vmovaps [rsp+0xD0], xmm14
00007531fdbde0fb  vmovaps [rsp+0xE0], xmm15
00007531fdbde104  sub rsp, 0x30
00007531fdbde108  movaps [rsp], xmm1
00007531fdbde10c  movaps [rsp+0x10], xmm13
00007531fdbde112  movaps [rsp+0x20], xmm8
00007531fdbde118  lea rdi, [rsp]
00007531fdbde11c  mov esi, 0x00
00007531fdbde121  mov rax, 0x59ED111DF530
00007531fdbde12b  call rax
00007531fdbde12d  movaps xmm1, [rsp]
00007531fdbde131  add rsp, 0x30
00007531fdbde135  vmovaps xmm0, [rsp]
00007531fdbde13a  vmovaps xmm2, [rsp+0x10]
00007531fdbde140  vmovaps xmm3, [rsp+0x20]
00007531fdbde146  vmovaps xmm4, [rsp+0x30]
00007531fdbde14c  vmovaps xmm5, [rsp+0x40]
00007531fdbde152  vmovaps xmm6, [rsp+0x50]
00007531fdbde158  vmovaps xmm7, [rsp+0x60]
00007531fdbde15e  vmovaps xmm8, [rsp+0x70]
00007531fdbde164  vmovaps xmm9, [rsp+0x80]
00007531fdbde16d  vmovaps xmm10, [rsp+0x90]
00007531fdbde176  vmovaps xmm11, [rsp+0xA0]
00007531fdbde17f  vmovaps xmm12, [rsp+0xB0]
00007531fdbde188  vmovaps xmm13, [rsp+0xC0]
00007531fdbde191  vmovaps xmm14, [rsp+0xD0]
00007531fdbde19a  vmovaps xmm15, [rsp+0xE0]
00007531fdbde1a3  add rsp, 0xF0
00007531fdbde1aa  pop r11
00007531fdbde1ac  pop r10
00007531fdbde1ae  pop r9
00007531fdbde1b0  pop r8
00007531fdbde1b2  pop rsi
00007531fdbde1b3  pop rdi
00007531fdbde1b4  pop rdx
00007531fdbde1b5  pop rcx
00007531fdbde1b6  pop rax
00007531fdbde1b7  add rsp, 0x08
00007531fdbde1bb  jmp 0x00007531FDBD977A
00007531fdbde1c0  call 0x00007531FDA0C260
00007531fdbde1c5  jmp 0x00007531FDBD9788
00007531fdbde1ca  call 0x00007531FDADE950
00007531fdbde1cf  jmp 0x00007531FDBD9792
00007531fdbde1d4  sub rsp, 0x08
00007531fdbde1d8  push rax
00007531fdbde1d9  push rcx
00007531fdbde1da  push rdx
00007531fdbde1db  push rdi
00007531fdbde1dc  push rsi
00007531fdbde1dd  push r8
00007531fdbde1df  push r9
00007531fdbde1e1  push r10
00007531fdbde1e3  push r11
00007531fdbde1e5  sub rsp, 0xF0
00007531fdbde1ec  vmovaps [rsp], xmm0
00007531fdbde1f1  vmovaps [rsp+0x10], xmm1
00007531fdbde1f7  vmovaps [rsp+0x20], xmm2
00007531fdbde1fd  vmovaps [rsp+0x30], xmm3
00007531fdbde203  vmovaps [rsp+0x40], xmm4
00007531fdbde209  vmovaps [rsp+0x50], xmm5
00007531fdbde20f  vmovaps [rsp+0x60], xmm6
00007531fdbde215  vmovaps [rsp+0x70], xmm7
00007531fdbde21b  vmovaps [rsp+0x80], xmm9
00007531fdbde224  vmovaps [rsp+0x90], xmm10
00007531fdbde22d  vmovaps [rsp+0xA0], xmm11
00007531fdbde236  vmovaps [rsp+0xB0], xmm12
00007531fdbde23f  vmovaps [rsp+0xC0], xmm13
00007531fdbde248  vmovaps [rsp+0xD0], xmm14
00007531fdbde251  vmovaps [rsp+0xE0], xmm15
00007531fdbde25a  sub rsp, 0x30
00007531fdbde25e  movaps [rsp], xmm8
00007531fdbde263  movaps [rsp+0x10], xmm15
00007531fdbde269  movaps [rsp+0x20], xmm7
00007531fdbde26e  lea rdi, [rsp]
00007531fdbde272  mov esi, 0x00
00007531fdbde277  mov rax, 0x59ED111DF530
00007531fdbde281  call rax
00007531fdbde283  movaps xmm8, [rsp]
00007531fdbde288  add rsp, 0x30
00007531fdbde28c  vmovaps xmm0, [rsp]
00007531fdbde291  vmovaps xmm1, [rsp+0x10]
00007531fdbde297  vmovaps xmm2, [rsp+0x20]
00007531fdbde29d  vmovaps xmm3, [rsp+0x30]
00007531fdbde2a3  vmovaps xmm4, [rsp+0x40]
00007531fdbde2a9  vmovaps xmm5, [rsp+0x50]
00007531fdbde2af  vmovaps xmm6, [rsp+0x60]
00007531fdbde2b5  vmovaps xmm7, [rsp+0x70]
00007531fdbde2bb  vmovaps xmm9, [rsp+0x80]
00007531fdbde2c4  vmovaps xmm10, [rsp+0x90]
00007531fdbde2cd  vmovaps xmm11, [rsp+0xA0]
00007531fdbde2d6  vmovaps xmm12, [rsp+0xB0]
00007531fdbde2df  vmovaps xmm13, [rsp+0xC0]
00007531fdbde2e8  vmovaps xmm14, [rsp+0xD0]
00007531fdbde2f1  vmovaps xmm15, [rsp+0xE0]
00007531fdbde2fa  add rsp, 0xF0
00007531fdbde301  pop r11
00007531fdbde303  pop r10
00007531fdbde305  pop r9
00007531fdbde307  pop r8
00007531fdbde309  pop rsi
00007531fdbde30a  pop rdi
00007531fdbde30b  pop rdx
00007531fdbde30c  pop rcx
00007531fdbde30d  pop rax
00007531fdbde30e  add rsp, 0x08
00007531fdbde312  jmp 0x00007531FDBD97B4
00007531fdbde317  sub rsp, 0x08
00007531fdbde31b  push rax
00007531fdbde31c  push rcx
00007531fdbde31d  push rdx
00007531fdbde31e  push rdi
00007531fdbde31f  push rsi
00007531fdbde320  push r8
00007531fdbde322  push r9
00007531fdbde324  push r10
00007531fdbde326  push r11
00007531fdbde328  sub rsp, 0xF0
00007531fdbde32f  vmovaps [rsp], xmm0
00007531fdbde334  vmovaps [rsp+0x10], xmm1
00007531fdbde33a  vmovaps [rsp+0x20], xmm2
00007531fdbde340  vmovaps [rsp+0x30], xmm3
00007531fdbde346  vmovaps [rsp+0x40], xmm4
00007531fdbde34c  vmovaps [rsp+0x50], xmm5
00007531fdbde352  vmovaps [rsp+0x60], xmm6
00007531fdbde358  vmovaps [rsp+0x70], xmm8
00007531fdbde35e  vmovaps [rsp+0x80], xmm9
00007531fdbde367  vmovaps [rsp+0x90], xmm10
00007531fdbde370  vmovaps [rsp+0xA0], xmm11
00007531fdbde379  vmovaps [rsp+0xB0], xmm12
00007531fdbde382  vmovaps [rsp+0xC0], xmm13
00007531fdbde38b  vmovaps [rsp+0xD0], xmm14
00007531fdbde394  vmovaps [rsp+0xE0], xmm15
00007531fdbde39d  sub rsp, 0x30
00007531fdbde3a1  movaps [rsp], xmm7
00007531fdbde3a5  movaps [rsp+0x10], xmm9
00007531fdbde3ab  movaps [rsp+0x20], xmm15
00007531fdbde3b1  lea rdi, [rsp]
00007531fdbde3b5  mov esi, 0x00
00007531fdbde3ba  mov rax, 0x59ED111DF530
00007531fdbde3c4  call rax
00007531fdbde3c6  movaps xmm7, [rsp]
00007531fdbde3ca  add rsp, 0x30
00007531fdbde3ce  vmovaps xmm0, [rsp]
00007531fdbde3d3  vmovaps xmm1, [rsp+0x10]
00007531fdbde3d9  vmovaps xmm2, [rsp+0x20]
00007531fdbde3df  vmovaps xmm3, [rsp+0x30]
00007531fdbde3e5  vmovaps xmm4, [rsp+0x40]
00007531fdbde3eb  vmovaps xmm5, [rsp+0x50]
00007531fdbde3f1  vmovaps xmm6, [rsp+0x60]
00007531fdbde3f7  vmovaps xmm8, [rsp+0x70]
00007531fdbde3fd  vmovaps xmm9, [rsp+0x80]
00007531fdbde406  vmovaps xmm10, [rsp+0x90]
00007531fdbde40f  vmovaps xmm11, [rsp+0xA0]
00007531fdbde418  vmovaps xmm12, [rsp+0xB0]
00007531fdbde421  vmovaps xmm13, [rsp+0xC0]
00007531fdbde42a  vmovaps xmm14, [rsp+0xD0]
00007531fdbde433  vmovaps xmm15, [rsp+0xE0]
00007531fdbde43c  add rsp, 0xF0
00007531fdbde443  pop r11
00007531fdbde445  pop r10
00007531fdbde447  pop r9
00007531fdbde449  pop r8
00007531fdbde44b  pop rsi
00007531fdbde44c  pop rdi
00007531fdbde44d  pop rdx
00007531fdbde44e  pop rcx
00007531fdbde44f  pop rax
00007531fdbde450  add rsp, 0x08
00007531fdbde454  jmp 0x00007531FDBD97E1
00007531fdbde459  sub rsp, 0x08
00007531fdbde45d  push rax
00007531fdbde45e  push rcx
00007531fdbde45f  push rdx
00007531fdbde460  push rdi
00007531fdbde461  push rsi
00007531fdbde462  push r8
00007531fdbde464  push r9
00007531fdbde466  push r10
00007531fdbde468  push r11
00007531fdbde46a  sub rsp, 0xF0
00007531fdbde471  vmovaps [rsp], xmm0
00007531fdbde476  vmovaps [rsp+0x10], xmm1
00007531fdbde47c  vmovaps [rsp+0x20], xmm2
00007531fdbde482  vmovaps [rsp+0x30], xmm3
00007531fdbde488  vmovaps [rsp+0x40], xmm4
00007531fdbde48e  vmovaps [rsp+0x50], xmm5
00007531fdbde494  vmovaps [rsp+0x60], xmm6
00007531fdbde49a  vmovaps [rsp+0x70], xmm7
00007531fdbde4a0  vmovaps [rsp+0x80], xmm8
00007531fdbde4a9  vmovaps [rsp+0x90], xmm10
00007531fdbde4b2  vmovaps [rsp+0xA0], xmm11
00007531fdbde4bb  vmovaps [rsp+0xB0], xmm12
00007531fdbde4c4  vmovaps [rsp+0xC0], xmm13
00007531fdbde4cd  vmovaps [rsp+0xD0], xmm14
00007531fdbde4d6  vmovaps [rsp+0xE0], xmm15
00007531fdbde4df  sub rsp, 0x30
00007531fdbde4e3  movaps [rsp], xmm9
00007531fdbde4e8  movaps [rsp+0x10], xmm13
00007531fdbde4ee  movaps [rsp+0x20], xmm15
00007531fdbde4f4  lea rdi, [rsp]
00007531fdbde4f8  mov esi, 0x00
00007531fdbde4fd  mov rax, 0x59ED111DF530
00007531fdbde507  call rax
00007531fdbde509  movaps xmm9, [rsp]
00007531fdbde50e  add rsp, 0x30
00007531fdbde512  vmovaps xmm0, [rsp]
00007531fdbde517  vmovaps xmm1, [rsp+0x10]
00007531fdbde51d  vmovaps xmm2, [rsp+0x20]
00007531fdbde523  vmovaps xmm3, [rsp+0x30]
00007531fdbde529  vmovaps xmm4, [rsp+0x40]
00007531fdbde52f  vmovaps xmm5, [rsp+0x50]
00007531fdbde535  vmovaps xmm6, [rsp+0x60]
00007531fdbde53b  vmovaps xmm7, [rsp+0x70]
00007531fdbde541  vmovaps xmm8, [rsp+0x80]
00007531fdbde54a  vmovaps xmm10, [rsp+0x90]
00007531fdbde553  vmovaps xmm11, [rsp+0xA0]
00007531fdbde55c  vmovaps xmm12, [rsp+0xB0]
00007531fdbde565  vmovaps xmm13, [rsp+0xC0]
00007531fdbde56e  vmovaps xmm14, [rsp+0xD0]
00007531fdbde577  vmovaps xmm15, [rsp+0xE0]
00007531fdbde580  add rsp, 0xF0
00007531fdbde587  pop r11
00007531fdbde589  pop r10
00007531fdbde58b  pop r9
00007531fdbde58d  pop r8
00007531fdbde58f  pop rsi
00007531fdbde590  pop rdi
00007531fdbde591  pop rdx
00007531fdbde592  pop rcx
00007531fdbde593  pop rax
00007531fdbde594  add rsp, 0x08
00007531fdbde598  jmp 0x00007531FDBD980F
00007531fdbde59d  sub rsp, 0x08
00007531fdbde5a1  push rax
00007531fdbde5a2  push rcx
00007531fdbde5a3  push rdx
00007531fdbde5a4  push rdi
00007531fdbde5a5  push rsi
00007531fdbde5a6  push r8
00007531fdbde5a8  push r9
00007531fdbde5aa  push r10
00007531fdbde5ac  push r11
00007531fdbde5ae  sub rsp, 0xF0
00007531fdbde5b5  vmovaps [rsp], xmm0
00007531fdbde5ba  vmovaps [rsp+0x10], xmm1
00007531fdbde5c0  vmovaps [rsp+0x20], xmm2
00007531fdbde5c6  vmovaps [rsp+0x30], xmm3
00007531fdbde5cc  vmovaps [rsp+0x40], xmm4
00007531fdbde5d2  vmovaps [rsp+0x50], xmm5
00007531fdbde5d8  vmovaps [rsp+0x60], xmm6
00007531fdbde5de  vmovaps [rsp+0x70], xmm7
00007531fdbde5e4  vmovaps [rsp+0x80], xmm8
00007531fdbde5ed  vmovaps [rsp+0x90], xmm9
00007531fdbde5f6  vmovaps [rsp+0xA0], xmm10
00007531fdbde5ff  vmovaps [rsp+0xB0], xmm11
00007531fdbde608  vmovaps [rsp+0xC0], xmm12
00007531fdbde611  vmovaps [rsp+0xD0], xmm13
00007531fdbde61a  vmovaps [rsp+0xE0], xmm14
00007531fdbde623  sub rsp, 0x30
00007531fdbde627  movaps [rsp], xmm15
00007531fdbde62c  movaps [rsp+0x10], xmm11
00007531fdbde632  movaps [rsp+0x20], xmm12
00007531fdbde638  lea rdi, [rsp]
00007531fdbde63c  mov esi, 0x00
00007531fdbde641  mov rax, 0x59ED111DF530
00007531fdbde64b  call rax
00007531fdbde64d  movaps xmm15, [rsp]
00007531fdbde652  add rsp, 0x30
00007531fdbde656  vmovaps xmm0, [rsp]
00007531fdbde65b  vmovaps xmm1, [rsp+0x10]
00007531fdbde661  vmovaps xmm2, [rsp+0x20]
00007531fdbde667  vmovaps xmm3, [rsp+0x30]
00007531fdbde66d  vmovaps xmm4, [rsp+0x40]
00007531fdbde673  vmovaps xmm5, [rsp+0x50]
00007531fdbde679  vmovaps xmm6, [rsp+0x60]
00007531fdbde67f  vmovaps xmm7, [rsp+0x70]
00007531fdbde685  vmovaps xmm8, [rsp+0x80]
00007531fdbde68e  vmovaps xmm9, [rsp+0x90]
00007531fdbde697  vmovaps xmm10, [rsp+0xA0]
00007531fdbde6a0  vmovaps xmm11, [rsp+0xB0]
00007531fdbde6a9  vmovaps xmm12, [rsp+0xC0]
00007531fdbde6b2  vmovaps xmm13, [rsp+0xD0]
00007531fdbde6bb  vmovaps xmm14, [rsp+0xE0]
00007531fdbde6c4  add rsp, 0xF0
00007531fdbde6cb  pop r11
00007531fdbde6cd  pop r10
00007531fdbde6cf  pop r9
00007531fdbde6d1  pop r8
00007531fdbde6d3  pop rsi
00007531fdbde6d4  pop rdi
00007531fdbde6d5  pop rdx
00007531fdbde6d6  pop rcx
00007531fdbde6d7  pop rax
00007531fdbde6d8  add rsp, 0x08
00007531fdbde6dc  jmp 0x00007531FDBD982A
00007531fdbde6e1  sub rsp, 0x08
00007531fdbde6e5  push rax
00007531fdbde6e6  push rcx
00007531fdbde6e7  push rdx
00007531fdbde6e8  push rdi
00007531fdbde6e9  push rsi
00007531fdbde6ea  push r8
00007531fdbde6ec  push r9
00007531fdbde6ee  push r10
00007531fdbde6f0  push r11
00007531fdbde6f2  sub rsp, 0xF0
00007531fdbde6f9  vmovaps [rsp], xmm0
00007531fdbde6fe  vmovaps [rsp+0x10], xmm1
00007531fdbde704  vmovaps [rsp+0x20], xmm2
00007531fdbde70a  vmovaps [rsp+0x30], xmm3
00007531fdbde710  vmovaps [rsp+0x40], xmm4
00007531fdbde716  vmovaps [rsp+0x50], xmm5
00007531fdbde71c  vmovaps [rsp+0x60], xmm6
00007531fdbde722  vmovaps [rsp+0x70], xmm7
00007531fdbde728  vmovaps [rsp+0x80], xmm8
00007531fdbde731  vmovaps [rsp+0x90], xmm9
00007531fdbde73a  vmovaps [rsp+0xA0], xmm10
00007531fdbde743  vmovaps [rsp+0xB0], xmm11
00007531fdbde74c  vmovaps [rsp+0xC0], xmm12
00007531fdbde755  vmovaps [rsp+0xD0], xmm14
00007531fdbde75e  vmovaps [rsp+0xE0], xmm15
00007531fdbde767  sub rsp, 0x30
00007531fdbde76b  movaps [rsp], xmm13
00007531fdbde770  movaps [rsp+0x10], xmm10
00007531fdbde776  movaps [rsp+0x20], xmm14
00007531fdbde77c  lea rdi, [rsp]
00007531fdbde780  mov esi, 0x00
00007531fdbde785  mov rax, 0x59ED111DF530
00007531fdbde78f  call rax
00007531fdbde791  movaps xmm13, [rsp]
00007531fdbde796  add rsp, 0x30
00007531fdbde79a  vmovaps xmm0, [rsp]
00007531fdbde79f  vmovaps xmm1, [rsp+0x10]
00007531fdbde7a5  vmovaps xmm2, [rsp+0x20]
00007531fdbde7ab  vmovaps xmm3, [rsp+0x30]
00007531fdbde7b1  vmovaps xmm4, [rsp+0x40]
00007531fdbde7b7  vmovaps xmm5, [rsp+0x50]
00007531fdbde7bd  vmovaps xmm6, [rsp+0x60]
00007531fdbde7c3  vmovaps xmm7, [rsp+0x70]
00007531fdbde7c9  vmovaps xmm8, [rsp+0x80]
00007531fdbde7d2  vmovaps xmm9, [rsp+0x90]
00007531fdbde7db  vmovaps xmm10, [rsp+0xA0]
00007531fdbde7e4  vmovaps xmm11, [rsp+0xB0]
00007531fdbde7ed  vmovaps xmm12, [rsp+0xC0]
00007531fdbde7f6  vmovaps xmm14, [rsp+0xD0]
00007531fdbde7ff  vmovaps xmm15, [rsp+0xE0]
00007531fdbde808  add rsp, 0xF0
00007531fdbde80f  pop r11
00007531fdbde811  pop r10
00007531fdbde813  pop r9
00007531fdbde815  pop r8
00007531fdbde817  pop rsi
00007531fdbde818  pop rdi
00007531fdbde819  pop rdx
00007531fdbde81a  pop rcx
00007531fdbde81b  pop rax
00007531fdbde81c  add rsp, 0x08
00007531fdbde820  jmp 0x00007531FDBD984D
00007531fdbde825  sub rsp, 0x08
00007531fdbde829  push rax
00007531fdbde82a  push rcx
00007531fdbde82b  push rdx
00007531fdbde82c  push rdi
00007531fdbde82d  push rsi
00007531fdbde82e  push r8
00007531fdbde830  push r9
00007531fdbde832  push r10
00007531fdbde834  push r11
00007531fdbde836  sub rsp, 0xF0
00007531fdbde83d  vmovaps [rsp], xmm0
00007531fdbde842  vmovaps [rsp+0x10], xmm1
00007531fdbde848  vmovaps [rsp+0x20], xmm2
00007531fdbde84e  vmovaps [rsp+0x30], xmm3
00007531fdbde854  vmovaps [rsp+0x40], xmm4
00007531fdbde85a  vmovaps [rsp+0x50], xmm5
00007531fdbde860  vmovaps [rsp+0x60], xmm6
00007531fdbde866  vmovaps [rsp+0x70], xmm7
00007531fdbde86c  vmovaps [rsp+0x80], xmm8
00007531fdbde875  vmovaps [rsp+0x90], xmm9
00007531fdbde87e  vmovaps [rsp+0xA0], xmm10
00007531fdbde887  vmovaps [rsp+0xB0], xmm11
00007531fdbde890  vmovaps [rsp+0xC0], xmm12
00007531fdbde899  vmovaps [rsp+0xD0], xmm13
00007531fdbde8a2  vmovaps [rsp+0xE0], xmm15
00007531fdbde8ab  sub rsp, 0x30
00007531fdbde8af  movaps [rsp], xmm14
00007531fdbde8b4  movaps [rsp+0x10], xmm1
00007531fdbde8b9  movaps [rsp+0x20], xmm7
00007531fdbde8be  lea rdi, [rsp]
00007531fdbde8c2  mov esi, 0x00
00007531fdbde8c7  mov rax, 0x59ED111DF530
00007531fdbde8d1  call rax
00007531fdbde8d3  movaps xmm14, [rsp]
00007531fdbde8d8  add rsp, 0x30
00007531fdbde8dc  vmovaps xmm0, [rsp]
00007531fdbde8e1  vmovaps xmm1, [rsp+0x10]
00007531fdbde8e7  vmovaps xmm2, [rsp+0x20]
00007531fdbde8ed  vmovaps xmm3, [rsp+0x30]
00007531fdbde8f3  vmovaps xmm4, [rsp+0x40]
00007531fdbde8f9  vmovaps xmm5, [rsp+0x50]
00007531fdbde8ff  vmovaps xmm6, [rsp+0x60]
00007531fdbde905  vmovaps xmm7, [rsp+0x70]
00007531fdbde90b  vmovaps xmm8, [rsp+0x80]
00007531fdbde914  vmovaps xmm9, [rsp+0x90]
00007531fdbde91d  vmovaps xmm10, [rsp+0xA0]
00007531fdbde926  vmovaps xmm11, [rsp+0xB0]
00007531fdbde92f  vmovaps xmm12, [rsp+0xC0]
00007531fdbde938  vmovaps xmm13, [rsp+0xD0]
00007531fdbde941  vmovaps xmm15, [rsp+0xE0]
00007531fdbde94a  add rsp, 0xF0
00007531fdbde951  pop r11
00007531fdbde953  pop r10
00007531fdbde955  pop r9
00007531fdbde957  pop r8
00007531fdbde959  pop rsi
00007531fdbde95a  pop rdi
00007531fdbde95b  pop rdx
00007531fdbde95c  pop rcx
00007531fdbde95d  pop rax
00007531fdbde95e  add rsp, 0x08
00007531fdbde962  jmp 0x00007531FDBD9870
00007531fdbde967  sub rsp, 0x08
00007531fdbde96b  push rax
00007531fdbde96c  push rcx
00007531fdbde96d  push rdx
00007531fdbde96e  push rdi
00007531fdbde96f  push rsi
00007531fdbde970  push r8
00007531fdbde972  push r9
00007531fdbde974  push r10
00007531fdbde976  push r11
00007531fdbde978  sub rsp, 0xF0
00007531fdbde97f  vmovaps [rsp], xmm0
00007531fdbde984  vmovaps [rsp+0x10], xmm2
00007531fdbde98a  vmovaps [rsp+0x20], xmm3
00007531fdbde990  vmovaps [rsp+0x30], xmm4
00007531fdbde996  vmovaps [rsp+0x40], xmm5
00007531fdbde99c  vmovaps [rsp+0x50], xmm6
00007531fdbde9a2  vmovaps [rsp+0x60], xmm7
00007531fdbde9a8  vmovaps [rsp+0x70], xmm8
00007531fdbde9ae  vmovaps [rsp+0x80], xmm9
00007531fdbde9b7  vmovaps [rsp+0x90], xmm10
00007531fdbde9c0  vmovaps [rsp+0xA0], xmm11
00007531fdbde9c9  vmovaps [rsp+0xB0], xmm12
00007531fdbde9d2  vmovaps [rsp+0xC0], xmm13
00007531fdbde9db  vmovaps [rsp+0xD0], xmm14
00007531fdbde9e4  vmovaps [rsp+0xE0], xmm15
00007531fdbde9ed  sub rsp, 0x30
00007531fdbde9f1  movaps [rsp], xmm1
00007531fdbde9f5  movaps [rsp+0x10], xmm8
00007531fdbde9fb  movaps [rsp+0x20], xmm9
00007531fdbdea01  lea rdi, [rsp]
00007531fdbdea05  mov esi, 0x00
00007531fdbdea0a  mov rax, 0x59ED111DF530
00007531fdbdea14  call rax
00007531fdbdea16  movaps xmm1, [rsp]
00007531fdbdea1a  add rsp, 0x30
00007531fdbdea1e  vmovaps xmm0, [rsp]
00007531fdbdea23  vmovaps xmm2, [rsp+0x10]
00007531fdbdea29  vmovaps xmm3, [rsp+0x20]
00007531fdbdea2f  vmovaps xmm4, [rsp+0x30]
00007531fdbdea35  vmovaps xmm5, [rsp+0x40]
00007531fdbdea3b  vmovaps xmm6, [rsp+0x50]
00007531fdbdea41  vmovaps xmm7, [rsp+0x60]
00007531fdbdea47  vmovaps xmm8, [rsp+0x70]
00007531fdbdea4d  vmovaps xmm9, [rsp+0x80]
00007531fdbdea56  vmovaps xmm10, [rsp+0x90]
00007531fdbdea5f  vmovaps xmm11, [rsp+0xA0]
00007531fdbdea68  vmovaps xmm12, [rsp+0xB0]
00007531fdbdea71  vmovaps xmm13, [rsp+0xC0]
00007531fdbdea7a  vmovaps xmm14, [rsp+0xD0]
00007531fdbdea83  vmovaps xmm15, [rsp+0xE0]
00007531fdbdea8c  add rsp, 0xF0
00007531fdbdea93  pop r11
00007531fdbdea95  pop r10
00007531fdbdea97  pop r9
00007531fdbdea99  pop r8
00007531fdbdea9b  pop rsi
00007531fdbdea9c  pop rdi
00007531fdbdea9d  pop rdx
00007531fdbdea9e  pop rcx
00007531fdbdea9f  pop rax
00007531fdbdeaa0  add rsp, 0x08
00007531fdbdeaa4  jmp 0x00007531FDBD9892
00007531fdbdeaa9  call 0x00007531FDAB3E40
00007531fdbdeaae  jmp 0x00007531FDBD98A0
00007531fdbdeab3  call 0x00007531FDA0C380
00007531fdbdeab8  jmp 0x00007531FDBD98AA
00007531fdbdeabd  call 0x00007531FDA0D600
00007531fdbdeac2  jmp 0x00007531FDBD98B4
00007531fdbdeac7  call 0x00007531FD9FF540
00007531fdbdeacc  jmp 0x00007531FDBD98BE
00007531fdbdead1  int3
00007531fdbdead2  nop [rax+rax*1], ax
00007531fdbdeadb  nop [rax+rax*1], eax
00007531fdbdeae0  mov eax, [r15+0x48]
00007531fdbdeae4  lea r14d, [eax+0x01]
00007531fdbdeae9  mov [rsp+0x10], r14d
00007531fdbdeaee  mov r14d, r14d
00007531fdbdeaf1  mov [r15+0x48], r14
00007531fdbdeaf5  xor eax, eax
00007531fdbdeaf7  mov r14d, [rsp+0x10]
00007531fdbdeafc  cmp r14d, 0x1F4
00007531fdbdeb03  cmc
00007531fdbdeb04  lahf
00007531fdbdeb05  seto al
00007531fdbdeb08  mov [r15+0x108], eax
00007531fdbdeb0f  mov eax, [r15+0x108]
00007531fdbdeb16  sahf
00007531fdbdeb17  jnz 0x00007531FDBDEB49
00007531fdbdeb19  cmp dword ptr [r15+0x318], 0x00
00007531fdbdeb21  jz 0x00007531FDBE4C90
00007531fdbdeb27  nop [rax+rax*1], ax
00007531fdbdeb30  nop [rax+rax*1], eax
00007531fdbdeb38  mov eax, 0x4106DC
00007531fdbdeb3d  mov [r15+0x100], rax
00007531fdbdeb44  jmp 0x00007531FD9FE110
00007531fdbdeb49  cmp dword ptr [r15+0x318], 0x00
00007531fdbdeb51  jz 0x00007531FDBDEB80
00007531fdbdeb57  nop [rax+rax*1], ax
00007531fdbdeb60  nop [rax+rax*1], eax
00007531fdbdeb68  mov eax, 0x410500
00007531fdbdeb6d  mov [r15+0x100], rax
00007531fdbdeb74  jmp 0x00007531FD9FE110
00007531fdbdeb79  int3
00007531fdbdeb7a  int3
00007531fdbdeb7b  nop [rax+rax*1], eax
00007531fdbdeb80  mov rax, [r15+0x40]
00007531fdbdeb84  movaps xmm1, [r15+0x1D0]
00007531fdbdeb8c  vmovaps [rsp+0x10], xmm1
00007531fdbdeb92  vmovaps xmm15, [rsp+0x10]
00007531fdbdeb98  por xmm1, xmm15
00007531fdbdeb9d  movaps xmm14, [r15+0x1A0]
00007531fdbdeba5  vmovaps [rsp+0x10], xmm14
00007531fdbdebab  vmovaps xmm13, [rsp+0x10]
00007531fdbdebb1  por xmm14, xmm13
00007531fdbdebb6  lea r14, [rax+0x30]
00007531fdbdebba  mov r12, [r13+r14*1]
00007531fdbdebbf  lea r14, [rax+0x38]
00007531fdbdebc3  mov r11, [r13+r14*1]
00007531fdbdebc8  movq xmm13, r12
00007531fdbdebcd  movq xmm12, r11
00007531fdbdebd2  movq xmm13, xmm13
00007531fdbdebd7  vmovaps [rsp+0x10], xmm13
00007531fdbdebdd  movq xmm13, xmm13
00007531fdbdebe2  movaps [r15+0x130], xmm13
00007531fdbdebea  movq xmm12, xmm12
00007531fdbdebef  vmovaps [rsp+0x20], xmm12
00007531fdbdebf5  movq xmm12, xmm12
00007531fdbdebfa  movaps [r15+0x280], xmm12
00007531fdbdec02  movaps xmm13, [r15+0x270]
00007531fdbdec0a  vmovaps [rsp+0x30], xmm13
00007531fdbdec10  vmovaps xmm12, [rsp+0x30]
00007531fdbdec16  por xmm13, xmm12
00007531fdbdec1b  lea r14, [rax+0x20]
00007531fdbdec1f  mov r12, [r13+r14*1]
00007531fdbdec24  lea r14, [rax+0x28]
00007531fdbdec28  mov r11, [r13+r14*1]
00007531fdbdec2d  movq xmm12, r12
00007531fdbdec32  movq xmm11, r11
00007531fdbdec37  movq xmm12, xmm12
00007531fdbdec3c  vmovaps [rsp+0x30], xmm12
00007531fdbdec42  movq xmm12, xmm12
00007531fdbdec47  movaps [r15+0x150], xmm12
00007531fdbdec4f  movq xmm11, xmm11
00007531fdbdec54  vmovaps [rsp+0x40], xmm11
00007531fdbdec5a  movq xmm11, xmm11
00007531fdbdec5f  movaps [r15+0x140], xmm11
00007531fdbdec67  lea r14, [rax+0x10]
00007531fdbdec6b  mov r12, [r13+r14*1]
00007531fdbdec70  lea r14, [rax+0x18]
00007531fdbdec74  mov r11, [r13+r14*1]
00007531fdbdec79  movq xmm12, r12
00007531fdbdec7e  movq xmm11, r11
00007531fdbdec83  movq xmm12, xmm12
00007531fdbdec88  vmovaps [rsp+0x50], xmm12
00007531fdbdec8e  movq xmm12, xmm12
00007531fdbdec93  movaps [r15+0x170], xmm12
00007531fdbdec9b  movq xmm11, xmm11
00007531fdbdeca0  vmovaps [rsp+0x60], xmm11
00007531fdbdeca6  movq xmm11, xmm11
00007531fdbdecab  movaps [r15+0x160], xmm11
00007531fdbdecb3  mov r14, [r13+rax*1]
00007531fdbdecb8  vmovq xmm12, r14
00007531fdbdecbd  vpbroadcastq xmm12, xmm12
00007531fdbdecc2  lea r14, [rax+0x08]
00007531fdbdecc6  mov rax, [r13+r14*1]
00007531fdbdeccb  movq xmm11, rax
00007531fdbdecd0  movaps [r15+0x230], xmm11
00007531fdbdecd8  mov rax, [r15+0xF8]
00007531fdbdecdf  lea r14, [rax+0x50]
00007531fdbdece3  movups xmm11, [r13+r14*1]
00007531fdbdece9  lea r14, [rax+0x60]
00007531fdbdeced  movups xmm10, [r13+r14*1]
00007531fdbdecf3  lea r14, [rax+0x30]
00007531fdbdecf7  movups xmm9, [r13+r14*1]
00007531fdbdecfd  mov r14, [r15+0x50]
00007531fdbded01  mov [r15+0x60], r14
00007531fdbded05  mov qword ptr [r15+0x58], 0x40
00007531fdbded0d  movaps xmm8, xmm12
00007531fdbded11  mulpd xmm8, xmm15
00007531fdbded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007531fdbded1c  ptest xmm7, xmm7
00007531fdbded21  jnz 0x00007531FDBDFB4A
00007531fdbded27  movq xmm15, qword ptr [r15+0x230]
00007531fdbded30  vmovaps [rsp+0x70], xmm15
00007531fdbded36  vpermilpd xmm15, xmm15, 0x00
00007531fdbded3c  movaps xmm7, xmm9
00007531fdbded40  mulpd xmm7, xmm15
00007531fdbded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007531fdbded4a  ptest xmm6, xmm6
00007531fdbded4f  jnz 0x00007531FDBDFC8E
00007531fdbded55  vxorps xmm15, xmm15, xmm15
00007531fdbded5a  vpbroadcastq xmm15, xmm15
00007531fdbded5f  movaps xmm9, xmm12
00007531fdbded63  mulpd xmm9, xmm10
00007531fdbded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007531fdbded6e  ptest xmm6, xmm6
00007531fdbded73  jnz 0x00007531FDBDFDD0
00007531fdbded79  movaps xmm10, xmm12
00007531fdbded7d  mulpd xmm10, xmm11
00007531fdbded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007531fdbded88  ptest xmm6, xmm6
00007531fdbded8d  jnz 0x00007531FDBDFF14
00007531fdbded93  movaps xmm11, [r15+0x1F0]
00007531fdbded9b  movaps xmm6, xmm12
00007531fdbded9f  mulpd xmm6, xmm11
00007531fdbdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007531fdbdeda9  ptest xmm5, xmm5
00007531fdbdedae  jnz 0x00007531FDBE0058
00007531fdbdedb4  movaps xmm12, [r15+0x2A0]
00007531fdbdedbc  vmovaps [rsp+0x80], xmm12
00007531fdbdedc5  vmovaps xmm11, [rsp+0x80]
00007531fdbdedce  por xmm12, xmm11
00007531fdbdedd3  movaps xmm11, [r15+0x250]
00007531fdbdeddb  vmovaps [rsp+0x80], xmm11
00007531fdbdede4  vmovaps xmm5, [rsp+0x80]
00007531fdbdeded  por xmm11, xmm5
00007531fdbdedf2  vmovaps xmm4, [rsp+0x70]
00007531fdbdedf8  vpermilpd xmm4, xmm4, 0x00
00007531fdbdedfe  movaps xmm3, xmm5
00007531fdbdee01  mulpd xmm3, xmm4
00007531fdbdee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007531fdbdee0a  ptest xmm2, xmm2
00007531fdbdee0f  jnz 0x00007531FDBE019A
00007531fdbdee15  mov [rsp+0x80], rax
00007531fdbdee1d  xor eax, eax
00007531fdbdee1f  mov r12d, 0x40
00007531fdbdee25  mov r11d, 0x200
00007531fdbdee2b  cmp r12, r11
00007531fdbdee2e  cmc
00007531fdbdee2f  lahf
00007531fdbdee30  seto al
00007531fdbdee33  mov [r15+0x108], eax
00007531fdbdee3a  movaps xmm5, xmm8
00007531fdbdee3e  addpd xmm5, xmm15
00007531fdbdee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007531fdbdee48  ptest xmm4, xmm4
00007531fdbdee4d  jnz 0x00007531FDBE02DA
00007531fdbdee53  movaps xmm8, [r15+0x1B0]
00007531fdbdee5b  movaps xmm4, xmm9
00007531fdbdee5f  addpd xmm4, xmm8
00007531fdbdee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007531fdbdee69  ptest xmm2, xmm2
00007531fdbdee6e  jnz 0x00007531FDBE041C
00007531fdbdee74  movaps xmm9, xmm10
00007531fdbdee78  addpd xmm9, xmm8
00007531fdbdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007531fdbdee83  ptest xmm2, xmm2
00007531fdbdee88  jnz 0x00007531FDBE055E
00007531fdbdee8e  movaps xmm10, [r15+0x2F0]
00007531fdbdee96  vmovaps [rsp+0x90], xmm10
00007531fdbdee9f  vmovaps xmm8, [rsp+0x90]
00007531fdbdeea8  por xmm10, xmm8
00007531fdbdeead  movaps xmm8, [r15+0x2E0]
00007531fdbdeeb5  vmovaps [rsp+0x90], xmm8
00007531fdbdeebe  vmovaps xmm2, [rsp+0x90]
00007531fdbdeec7  por xmm8, xmm2
00007531fdbdeecc  movaps xmm2, [r15+0x2D0]
00007531fdbdeed4  vmovaps [rsp+0x90], xmm2
00007531fdbdeedd  vmovaps [rsp+0xA0], xmm1
00007531fdbdeee6  vmovaps xmm1, [rsp+0x90]
00007531fdbdeeef  por xmm2, xmm1
00007531fdbdeef3  movaps xmm1, [r15+0x200]
00007531fdbdeefb  vmovaps [rsp+0x90], xmm1
00007531fdbdef04  vmovaps [rsp+0xB0], xmm15
00007531fdbdef0d  vmovaps xmm15, [rsp+0x90]
00007531fdbdef16  por xmm1, xmm15
00007531fdbdef1b  movaps xmm15, [r15+0x1C0]
00007531fdbdef23  vmovaps [rsp+0x90], xmm15
00007531fdbdef2c  vmovaps [rsp+0xC0], xmm1
00007531fdbdef35  vmovaps xmm1, [rsp+0x90]
00007531fdbdef3e  por xmm15, xmm1
00007531fdbdef43  movaps xmm1, [r15+0x190]
00007531fdbdef4b  vmovaps [rsp+0x90], xmm1
00007531fdbdef54  vmovaps [rsp+0xD0], xmm15
00007531fdbdef5d  vmovaps xmm15, [rsp+0x90]
00007531fdbdef66  por xmm1, xmm15
00007531fdbdef6b  movaps xmm15, [r15+0x300]
00007531fdbdef73  vmovaps [rsp+0x90], xmm15
00007531fdbdef7c  vmovaps [rsp+0xE0], xmm1
00007531fdbdef85  vmovaps xmm1, [rsp+0x90]
00007531fdbdef8e  por xmm15, xmm1
00007531fdbdef93  mov rax, [rsp+0x80]
00007531fdbdef9b  lea r12, [rax+0xA0]
00007531fdbdefa2  movups xmm1, [r13+r12*1]
00007531fdbdefa8  lea r12, [rax+0xB0]
00007531fdbdefaf  vmovaps [rsp+0x80], xmm1
00007531fdbdefb8  movups xmm1, [r13+r12*1]
00007531fdbdefbe  vmovaps [rsp+0x90], xmm1
00007531fdbdefc7  vmovaps [rsp+0xF0], xmm15
00007531fdbdefd0  vmovaps xmm15, [rsp+0xB0]
00007531fdbdefd9  vmovaps [rsp+0xB0], xmm14
00007531fdbdefe2  movaps xmm1, xmm6
00007531fdbdefe5  addpd xmm1, xmm15
00007531fdbdefea  vcmppd xmm14, xmm1, xmm1, 0x03
00007531fdbdefef  ptest xmm14, xmm14
00007531fdbdeff5  jnz 0x00007531FDBE06B6
00007531fdbdeffb  lea r12, [rax+0xF0]
00007531fdbdf002  movups xmm15, [r13+r12*1]
00007531fdbdf008  movaps xmm14, xmm4
00007531fdbdf00c  addpd xmm14, xmm3
00007531fdbdf011  vcmppd xmm6, xmm14, xmm14, 0x03
00007531fdbdf017  ptest xmm6, xmm6
00007531fdbdf01c  jnz 0x00007531FDBE0801
00007531fdbdf022  movaps xmm6, xmm9
00007531fdbdf026  addpd xmm6, xmm7
00007531fdbdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007531fdbdf02f  ptest xmm4, xmm4
00007531fdbdf034  jnz 0x00007531FDBE0943
00007531fdbdf03a  vmovaps xmm9, [rsp+0x70]
00007531fdbdf040  vpermilpd xmm9, xmm9, 0x00
00007531fdbdf046  vmovaps xmm4, [rsp+0x90]
00007531fdbdf04f  movaps xmm7, xmm4
00007531fdbdf052  mulpd xmm7, xmm9
00007531fdbdf057  vcmppd xmm3, xmm7, xmm7, 0x03
00007531fdbdf05c  ptest xmm3, xmm3
00007531fdbdf061  jnz 0x00007531FDBE0A84
00007531fdbdf067  vmovaps xmm9, [rsp+0x50]
00007531fdbdf06d  vpermilpd xmm9, xmm9, 0x00
00007531fdbdf073  movaps xmm4, xmm15
00007531fdbdf077  mulpd xmm4, xmm9
00007531fdbdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007531fdbdf081  ptest xmm3, xmm3
00007531fdbdf086  jnz 0x00007531FDBE0BC5
00007531fdbdf08c  lea r12, [rax+0xE0]
00007531fdbdf093  movups xmm15, [r13+r12*1]
00007531fdbdf099  vmovaps xmm9, [rsp+0x70]
00007531fdbdf09f  vpermilpd xmm9, xmm9, 0x00
00007531fdbdf0a5  vmovaps [rsp+0x70], xmm1
00007531fdbdf0ab  vmovaps xmm1, [rsp+0x80]
00007531fdbdf0b4  vmovaps [rsp+0x80], xmm15
00007531fdbdf0bd  movaps xmm3, xmm1
00007531fdbdf0c0  mulpd xmm3, xmm9
00007531fdbdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007531fdbdf0ca  ptest xmm15, xmm15
00007531fdbdf0d0  jnz 0x00007531FDBE0D11
00007531fdbdf0d6  vmovaps xmm1, [rsp+0xF0]
00007531fdbdf0df  vmovaps xmm15, [rsp+0xF0]
00007531fdbdf0e8  por xmm1, xmm15
00007531fdbdf0ed  movaps [r15+0x300], xmm1
00007531fdbdf0f5  vmovaps xmm15, [rsp+0xE0]
00007531fdbdf0fe  vmovaps xmm9, [rsp+0xE0]
00007531fdbdf107  por xmm15, xmm9
00007531fdbdf10c  movaps [r15+0x190], xmm15
00007531fdbdf114  vmovaps xmm9, [rsp+0x50]
00007531fdbdf11a  vpermilpd xmm9, xmm9, 0x00
00007531fdbdf120  vmovaps [rsp+0x90], xmm1
00007531fdbdf129  vmovaps [rsp+0xE0], xmm15
00007531fdbdf132  vmovaps xmm15, [rsp+0x80]
00007531fdbdf13b  vmovaps [rsp+0x80], xmm14
00007531fdbdf144  movaps xmm1, xmm15
00007531fdbdf148  mulpd xmm1, xmm9
00007531fdbdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007531fdbdf152  ptest xmm14, xmm14
00007531fdbdf158  jnz 0x00007531FDBE0E52
00007531fdbdf15e  lea r12, [rax+0x90]
00007531fdbdf165  movups xmm15, [r13+r12*1]
00007531fdbdf16b  vmovaps xmm14, [rsp+0xD0]
00007531fdbdf174  vmovaps xmm9, [rsp+0xD0]
00007531fdbdf17d  por xmm14, xmm9
00007531fdbdf182  movaps [r15+0x1C0], xmm14
00007531fdbdf18a  vmovaps xmm9, [rsp+0xC0]
00007531fdbdf193  vmovaps [rsp+0xD0], xmm1
00007531fdbdf19c  vmovaps xmm1, [rsp+0xC0]
00007531fdbdf1a5  por xmm9, xmm1
00007531fdbdf1aa  movaps [r15+0x200], xmm9
00007531fdbdf1b2  vmovaps [rsp+0xC0], xmm2
00007531fdbdf1bb  vmovaps xmm1, [rsp+0xC0]
00007531fdbdf1c4  por xmm2, xmm1
00007531fdbdf1c8  movaps [r15+0x2D0], xmm2
00007531fdbdf1d0  vmovaps [rsp+0xC0], xmm8
00007531fdbdf1d9  vmovaps xmm1, [rsp+0xC0]
00007531fdbdf1e2  por xmm8, xmm1
00007531fdbdf1e7  movaps [r15+0x2E0], xmm8
00007531fdbdf1ef  vmovaps [rsp+0xC0], xmm15
00007531fdbdf1f8  movaps xmm1, xmm5
00007531fdbdf1fb  addpd xmm1, xmm7
00007531fdbdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007531fdbdf204  ptest xmm15, xmm15
00007531fdbdf20a  jnz 0x00007531FDBE0F9E
00007531fdbdf210  vmovaps xmm15, [rsp+0x50]
00007531fdbdf216  vpermilpd xmm15, xmm15, 0x00
00007531fdbdf21c  vmovaps xmm5, [rsp+0xC0]
00007531fdbdf225  vmovaps [rsp+0xC0], xmm1
00007531fdbdf22e  movaps xmm7, xmm5
00007531fdbdf231  mulpd xmm7, xmm15
00007531fdbdf236  vcmppd xmm1, xmm7, xmm7, 0x03
00007531fdbdf23b  ptest xmm1, xmm1
00007531fdbdf240  jnz 0x00007531FDBE10DE
00007531fdbdf246  lea r12, [rax+0x80]
00007531fdbdf24d  movups xmm1, [r13+r12*1]
00007531fdbdf253  vmovaps xmm5, [rsp+0x70]
00007531fdbdf259  vmovaps [rsp+0x70], xmm1
00007531fdbdf25f  movaps xmm15, xmm5
00007531fdbdf263  addpd xmm15, xmm3
00007531fdbdf268  vcmppd xmm1, xmm15, xmm15, 0x03
00007531fdbdf26e  ptest xmm1, xmm1
00007531fdbdf273  jnz 0x00007531FDBE1229
00007531fdbdf279  vmovaps xmm5, [rsp+0x80]
00007531fdbdf282  movaps xmm1, xmm5
00007531fdbdf285  addpd xmm1, xmm4
00007531fdbdf289  vcmppd xmm3, xmm1, xmm1, 0x03
00007531fdbdf28e  ptest xmm3, xmm3
00007531fdbdf293  jnz 0x00007531FDBE136B
00007531fdbdf299  vmovaps [rsp+0x80], xmm10
00007531fdbdf2a2  vmovaps xmm5, [rsp+0x80]
00007531fdbdf2ab  por xmm10, xmm5
00007531fdbdf2b0  movaps [r15+0x2F0], xmm10
00007531fdbdf2b8  vmovaps xmm5, [rsp+0x50]
00007531fdbdf2be  vpermilpd xmm5, xmm5, 0x00
00007531fdbdf2c4  vmovaps xmm3, [rsp+0x70]
00007531fdbdf2ca  vmovaps [rsp+0x50], xmm1
00007531fdbdf2d0  movaps xmm4, xmm3
00007531fdbdf2d3  mulpd xmm4, xmm5
00007531fdbdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007531fdbdf2dc  ptest xmm1, xmm1
00007531fdbdf2e1  jnz 0x00007531FDBE14AB
00007531fdbdf2e7  lea r12, [rax+0xD0]
00007531fdbdf2ee  movups xmm1, [r13+r12*1]
00007531fdbdf2f4  vmovaps xmm3, [rsp+0xD0]
00007531fdbdf2fd  vmovaps [rsp+0x70], xmm1
00007531fdbdf303  movaps xmm5, xmm6
00007531fdbdf306  addpd xmm5, xmm3
00007531fdbdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007531fdbdf30f  ptest xmm1, xmm1
00007531fdbdf314  jnz 0x00007531FDBE15F5
00007531fdbdf31a  vmovaps xmm1, [rsp+0x60]
00007531fdbdf320  vpermilpd xmm1, xmm1, 0x00
00007531fdbdf326  movaps xmm6, xmm9
00007531fdbdf32a  mulpd xmm6, xmm1
00007531fdbdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007531fdbdf333  ptest xmm3, xmm3
00007531fdbdf338  jnz 0x00007531FDBE1735
00007531fdbdf33e  movaps [r15+0x260], xmm6
00007531fdbdf346  vxorps xmm1, xmm1, xmm1
00007531fdbdf34a  vpbroadcastq xmm1, xmm1
00007531fdbdf34f  movaps [r15+0x1B0], xmm1
00007531fdbdf357  vmovaps xmm1, [rsp+0x60]
00007531fdbdf35d  vpermilpd xmm1, xmm1, 0x00
00007531fdbdf363  vmovaps xmm3, [rsp+0x70]
00007531fdbdf369  vmovaps [rsp+0x70], xmm15
00007531fdbdf36f  movaps xmm9, xmm3
00007531fdbdf373  mulpd xmm9, xmm1
00007531fdbdf378  vcmppd xmm15, xmm9, xmm9, 0x03
00007531fdbdf37e  ptest xmm15, xmm15
00007531fdbdf384  jnz 0x00007531FDBE1876
00007531fdbdf38a  lea r12, [rax+0xC0]
00007531fdbdf391  movups xmm1, [r13+r12*1]
00007531fdbdf397  vmovaps xmm3, [rsp+0xC0]
00007531fdbdf3a0  vmovaps [rsp+0x80], xmm1
00007531fdbdf3a9  movaps xmm15, xmm3
00007531fdbdf3ad  addpd xmm15, xmm7
00007531fdbdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007531fdbdf3b8  ptest xmm1, xmm1
00007531fdbdf3bd  jnz 0x00007531FDBE19C2
00007531fdbdf3c3  vmovaps [rsp+0xC0], xmm13
00007531fdbdf3cc  vmovaps xmm1, [rsp+0xC0]
00007531fdbdf3d5  por xmm13, xmm1
00007531fdbdf3da  movaps [r15+0x270], xmm13
00007531fdbdf3e2  vmovaps xmm1, [rsp+0xB0]
00007531fdbdf3eb  vmovaps xmm7, [rsp+0xB0]
00007531fdbdf3f4  por xmm1, xmm7
00007531fdbdf3f8  movaps [r15+0x1A0], xmm1
00007531fdbdf400  vmovaps xmm1, [rsp+0x60]
00007531fdbdf406  vpermilpd xmm1, xmm1, 0x00
00007531fdbdf40c  vmovaps [rsp+0xB0], xmm1
00007531fdbdf415  vmovaps xmm1, [rsp+0x80]
00007531fdbdf41e  vmovaps [rsp+0x80], xmm15
00007531fdbdf427  vmovaps xmm15, [rsp+0xB0]
00007531fdbdf430  vmovaps [rsp+0xB0], xmm14
00007531fdbdf439  movaps xmm3, xmm1
00007531fdbdf43c  mulpd xmm3, xmm15
00007531fdbdf441  vcmppd xmm14, xmm3, xmm3, 0x03
00007531fdbdf446  ptest xmm14, xmm14
00007531fdbdf44c  jnz 0x00007531FDBE1B04
00007531fdbdf452  lea r12, [rax+0x20]
00007531fdbdf456  movups xmm1, [r13+r12*1]
00007531fdbdf45c  movaps [r15+0x110], xmm1
00007531fdbdf464  vmovaps xmm14, [rsp+0x70]
00007531fdbdf46a  vmovaps [rsp+0x70], xmm1
00007531fdbdf470  movaps xmm15, xmm14
00007531fdbdf474  addpd xmm15, xmm4
00007531fdbdf479  vcmppd xmm1, xmm15, xmm15, 0x03
00007531fdbdf47f  ptest xmm1, xmm1
00007531fdbdf484  jnz 0x00007531FDBE1C4F
00007531fdbdf48a  vmovaps xmm1, [rsp+0x60]
00007531fdbdf490  vpermilpd xmm1, xmm1, 0x00
00007531fdbdf496  movaps xmm14, xmm2
00007531fdbdf49a  mulpd xmm14, xmm1
00007531fdbdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007531fdbdf4a5  ptest xmm4, xmm4
00007531fdbdf4aa  jnz 0x00007531FDBE1D92
00007531fdbdf4b0  vmovaps xmm4, [rsp+0x50]
00007531fdbdf4b6  movaps xmm1, xmm4
00007531fdbdf4b9  addpd xmm1, xmm9
00007531fdbdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007531fdbdf4c3  ptest xmm2, xmm2
00007531fdbdf4c8  jnz 0x00007531FDBE1ED4
00007531fdbdf4ce  vmovaps xmm9, [rsp+0x30]
00007531fdbdf4d4  vpermilpd xmm9, xmm9, 0x00
00007531fdbdf4da  vmovaps xmm2, [rsp+0x70]
00007531fdbdf4e0  vmovaps [rsp+0x50], xmm1
00007531fdbdf4e6  movaps xmm4, xmm2
00007531fdbdf4e9  mulpd xmm4, xmm9
00007531fdbdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007531fdbdf4f3  ptest xmm1, xmm1
00007531fdbdf4f8  jnz 0x00007531FDBE2015
00007531fdbdf4fe  vmovaps xmm1, [rsp+0x30]
00007531fdbdf504  vpermilpd xmm1, xmm1, 0x00
00007531fdbdf50a  vmovaps xmm2, [rsp+0x90]
00007531fdbdf513  vmovaps [rsp+0x60], xmm15
00007531fdbdf519  movaps xmm9, xmm2
00007531fdbdf51d  mulpd xmm9, xmm1
00007531fdbdf522  vcmppd xmm15, xmm9, xmm9, 0x03
00007531fdbdf528  ptest xmm15, xmm15
00007531fdbdf52e  jnz 0x00007531FDBE2156
00007531fdbdf534  vmovaps xmm15, [rsp+0x80]
00007531fdbdf53d  movaps xmm1, xmm15
00007531fdbdf541  addpd xmm1, xmm6
00007531fdbdf545  vcmppd xmm2, xmm1, xmm1, 0x03
00007531fdbdf54a  ptest xmm2, xmm2
00007531fdbdf54f  jnz 0x00007531FDBE2298
00007531fdbdf555  movaps xmm15, xmm5
00007531fdbdf559  addpd xmm15, xmm3
00007531fdbdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007531fdbdf564  ptest xmm6, xmm6
00007531fdbdf569  jnz 0x00007531FDBE23D9
00007531fdbdf56f  vmovaps xmm6, [rsp+0x30]
00007531fdbdf575  vpermilpd xmm6, xmm6, 0x00
00007531fdbdf57b  movaps xmm5, xmm8
00007531fdbdf57f  mulpd xmm5, xmm6
00007531fdbdf583  vcmppd xmm3, xmm5, xmm5, 0x03
00007531fdbdf588  ptest xmm3, xmm3
00007531fdbdf58d  jnz 0x00007531FDBE251B
00007531fdbdf593  vmovaps xmm8, [rsp+0x30]
00007531fdbdf599  vpermilpd xmm8, xmm8, 0x00
00007531fdbdf59f  movaps xmm6, xmm10
00007531fdbdf5a3  mulpd xmm6, xmm8
00007531fdbdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007531fdbdf5ad  ptest xmm3, xmm3
00007531fdbdf5b2  jnz 0x00007531FDBE265C
00007531fdbdf5b8  vmovaps xmm8, [rsp+0x60]
00007531fdbdf5be  movaps xmm10, xmm8
00007531fdbdf5c2  addpd xmm10, xmm14
00007531fdbdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007531fdbdf5cd  ptest xmm3, xmm3
00007531fdbdf5d2  jnz 0x00007531FDBE279E
00007531fdbdf5d8  vmovaps xmm8, [rsp+0x50]
00007531fdbdf5de  movaps xmm14, xmm8
00007531fdbdf5e2  addpd xmm14, xmm4
00007531fdbdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007531fdbdf5ed  ptest xmm3, xmm3
00007531fdbdf5f2  jnz 0x00007531FDBE28E2
00007531fdbdf5f8  vmovaps xmm8, [rsp+0x40]
00007531fdbdf5fe  vpermilpd xmm8, xmm8, 0x00
00007531fdbdf604  movaps xmm4, xmm13
00007531fdbdf608  mulpd xmm4, xmm8
00007531fdbdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007531fdbdf612  ptest xmm3, xmm3
00007531fdbdf617  jnz 0x00007531FDBE2A25
00007531fdbdf61d  movaps xmm13, xmm15
00007531fdbdf621  addpd xmm13, xmm9
00007531fdbdf626  vcmppd xmm8, xmm13, xmm13, 0x03
00007531fdbdf62c  ptest xmm8, xmm8
00007531fdbdf632  jnz 0x00007531FDBE2B67
00007531fdbdf638  movaps xmm15, xmm1
00007531fdbdf63c  addpd xmm15, xmm5
00007531fdbdf641  vcmppd xmm9, xmm15, xmm15, 0x03
00007531fdbdf647  ptest xmm9, xmm9
00007531fdbdf64d  jnz 0x00007531FDBE2CAB
00007531fdbdf653  vmovaps [rsp+0x30], xmm11
00007531fdbdf659  vmovaps xmm1, [rsp+0x30]
00007531fdbdf65f  por xmm11, xmm1
00007531fdbdf664  movaps [r15+0x250], xmm11
00007531fdbdf66c  vmovaps [rsp+0x30], xmm12
00007531fdbdf672  vmovaps xmm1, [rsp+0x30]
00007531fdbdf678  por xmm12, xmm1
00007531fdbdf67d  movaps [r15+0x2A0], xmm12
00007531fdbdf685  vmovaps xmm1, [rsp+0xA0]
00007531fdbdf68e  vmovaps xmm11, [rsp+0xA0]
00007531fdbdf697  por xmm1, xmm11
00007531fdbdf69c  movaps [r15+0x1D0], xmm1
00007531fdbdf6a4  lea r12, [rax+0x40]
00007531fdbdf6a8  movups xmm1, [r13+r12*1]
00007531fdbdf6ae  movaps [r15+0x2C0], xmm1
00007531fdbdf6b6  vmovaps xmm11, [rsp+0x40]
00007531fdbdf6bc  vpermilpd xmm11, xmm11, 0x00
00007531fdbdf6c2  vmovaps xmm8, [rsp+0xE0]
00007531fdbdf6cb  movaps xmm9, xmm8
00007531fdbdf6cf  mulpd xmm9, xmm11
00007531fdbdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007531fdbdf6da  ptest xmm5, xmm5
00007531fdbdf6df  jnz 0x00007531FDBE2DF7
00007531fdbdf6e5  movaps xmm11, xmm10
00007531fdbdf6e9  addpd xmm11, xmm6
00007531fdbdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007531fdbdf6f4  ptest xmm8, xmm8
00007531fdbdf6fa  jnz 0x00007531FDBE2F3B
00007531fdbdf700  movaps xmm10, xmm14
00007531fdbdf704  addpd xmm10, xmm4
00007531fdbdf709  vcmppd xmm8, xmm10, xmm10, 0x03
00007531fdbdf70f  ptest xmm8, xmm8
00007531fdbdf715  jnz 0x00007531FDBE307E
00007531fdbdf71b  vmovaps xmm14, [rsp+0x40]
00007531fdbdf721  vpermilpd xmm14, xmm14, 0x00
00007531fdbdf727  movaps xmm8, xmm1
00007531fdbdf72b  mulpd xmm8, xmm14
00007531fdbdf730  vcmppd xmm6, xmm8, xmm8, 0x03
00007531fdbdf736  ptest xmm6, xmm6
00007531fdbdf73b  jnz 0x00007531FDBE31C1
00007531fdbdf741  movaps xmm1, [r15+0x2B0]
00007531fdbdf749  vmovaps xmm14, [rsp+0x40]
00007531fdbdf74f  vpermilpd xmm14, xmm14, 0x00
00007531fdbdf755  movaps xmm6, xmm1
00007531fdbdf758  mulpd xmm6, xmm14
00007531fdbdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007531fdbdf762  ptest xmm5, xmm5
00007531fdbdf767  jnz 0x00007531FDBE3304
00007531fdbdf76d  vmovaps xmm1, [rsp+0x10]
00007531fdbdf773  vpermilpd xmm1, xmm1, 0x00
00007531fdbdf779  movaps xmm14, xmm12
00007531fdbdf77d  mulpd xmm14, xmm1
00007531fdbdf782  vcmppd xmm5, xmm14, xmm14, 0x03
00007531fdbdf788  ptest xmm5, xmm5
00007531fdbdf78d  jnz 0x00007531FDBE3445
00007531fdbdf793  movaps xmm1, xmm13
00007531fdbdf797  addpd xmm1, xmm9
00007531fdbdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007531fdbdf7a1  ptest xmm12, xmm12
00007531fdbdf7a7  jnz 0x00007531FDBE3588
00007531fdbdf7ad  vmovaps xmm13, [rsp+0x10]
00007531fdbdf7b3  vpermilpd xmm13, xmm13, 0x00
00007531fdbdf7b9  movaps xmm12, xmm7
00007531fdbdf7bd  mulpd xmm12, xmm13
00007531fdbdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007531fdbdf7c8  ptest xmm9, xmm9
00007531fdbdf7ce  jnz 0x00007531FDBE36CA
00007531fdbdf7d4  movaps xmm13, xmm15
00007531fdbdf7d8  addpd xmm13, xmm8
00007531fdbdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007531fdbdf7e3  ptest xmm9, xmm9
00007531fdbdf7e9  jnz 0x00007531FDBE380D
00007531fdbdf7ef  movaps xmm15, [r15+0x290]
00007531fdbdf7f7  vmovaps xmm9, [rsp+0x10]
00007531fdbdf7fd  vpermilpd xmm9, xmm9, 0x00
00007531fdbdf803  movaps xmm8, xmm15
00007531fdbdf807  mulpd xmm8, xmm9
00007531fdbdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007531fdbdf812  ptest xmm7, xmm7
00007531fdbdf817  jnz 0x00007531FDBE3951
00007531fdbdf81d  movaps xmm15, xmm11
00007531fdbdf821  addpd xmm15, xmm6
00007531fdbdf826  vcmppd xmm9, xmm15, xmm15, 0x03
00007531fdbdf82c  ptest xmm9, xmm9
00007531fdbdf832  jnz 0x00007531FDBE3A95
00007531fdbdf838  movaps xmm11, [r15+0x1E0]
00007531fdbdf840  vmovaps xmm9, [rsp+0x10]
00007531fdbdf846  vpermilpd xmm9, xmm9, 0x00
00007531fdbdf84c  movaps xmm7, xmm11
00007531fdbdf850  mulpd xmm7, xmm9
00007531fdbdf855  vcmppd xmm6, xmm7, xmm7, 0x03
00007531fdbdf85a  ptest xmm6, xmm6
00007531fdbdf85f  jnz 0x00007531FDBE3BD8
00007531fdbdf865  movaps xmm11, xmm10
00007531fdbdf869  addpd xmm11, xmm14
00007531fdbdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007531fdbdf874  ptest xmm9, xmm9
00007531fdbdf87a  jnz 0x00007531FDBE3D1A
00007531fdbdf880  lea r12, [rax+0x70]
00007531fdbdf884  movups xmm14, [r13+r12*1]
00007531fdbdf88a  movaps [r15+0x240], xmm14
00007531fdbdf892  movaps xmm10, xmm1
00007531fdbdf896  addpd xmm10, xmm12
00007531fdbdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007531fdbdf8a1  ptest xmm9, xmm9
00007531fdbdf8a7  jnz 0x00007531FDBE3E68
00007531fdbdf8ad  movaps [r15+0x170], xmm10
00007531fdbdf8b5  vmovaps xmm1, [rsp+0x20]
00007531fdbdf8bb  vpermilpd xmm1, xmm1, 0x00
00007531fdbdf8c1  movaps xmm12, xmm14
00007531fdbdf8c5  mulpd xmm12, xmm1
00007531fdbdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007531fdbdf8d0  ptest xmm9, xmm9
00007531fdbdf8d6  jnz 0x00007531FDBE3FAB
00007531fdbdf8dc  vmovaps xmm1, [rsp+0x20]
00007531fdbdf8e2  vpermilpd xmm1, xmm1, 0x00
00007531fdbdf8e8  vmovaps xmm9, [rsp+0xB0]
00007531fdbdf8f1  movaps xmm14, xmm9
00007531fdbdf8f5  mulpd xmm14, xmm1
00007531fdbdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007531fdbdf900  ptest xmm6, xmm6
00007531fdbdf905  jnz 0x00007531FDBE40EE
00007531fdbdf90b  movaps [r15+0x180], xmm14
00007531fdbdf913  movaps xmm1, xmm13
00007531fdbdf917  addpd xmm1, xmm8
00007531fdbdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007531fdbdf921  ptest xmm9, xmm9
00007531fdbdf927  jnz 0x00007531FDBE4231
00007531fdbdf92d  movaps [r15+0x210], xmm1
00007531fdbdf935  movups xmm13, [r13+rax*1]
00007531fdbdf93b  lea r12, [rax+0x10]
00007531fdbdf93f  movups xmm9, [r13+r12*1]
00007531fdbdf945  movaps [r15+0x230], xmm9
00007531fdbdf94d  movaps xmm8, xmm15
00007531fdbdf951  addpd xmm8, xmm7
00007531fdbdf956  vcmppd xmm6, xmm8, xmm8, 0x03
00007531fdbdf95c  ptest xmm6, xmm6
00007531fdbdf961  jnz 0x00007531FDBE4387
00007531fdbdf967  movaps [r15+0x130], xmm8
00007531fdbdf96f  vmovaps xmm15, [rsp+0x20]
00007531fdbdf975  vpermilpd xmm15, xmm15, 0x00
00007531fdbdf97b  movaps xmm7, xmm9
00007531fdbdf97f  mulpd xmm7, xmm15
00007531fdbdf984  vcmppd xmm6, xmm7, xmm7, 0x03
00007531fdbdf989  ptest xmm6, xmm6
00007531fdbdf98e  jnz 0x00007531FDBE44CA
00007531fdbdf994  movaps [r15+0x220], xmm7
00007531fdbdf99c  vmovaps xmm15, [rsp+0x20]
00007531fdbdf9a2  vpermilpd xmm15, xmm15, 0x00
00007531fdbdf9a8  movaps xmm9, xmm13
00007531fdbdf9ac  mulpd xmm9, xmm15
00007531fdbdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007531fdbdf9b7  ptest xmm6, xmm6
00007531fdbdf9bc  jnz 0x00007531FDBE460C
00007531fdbdf9c2  movaps xmm15, xmm11
00007531fdbdf9c6  addpd xmm15, xmm12
00007531fdbdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007531fdbdf9d1  ptest xmm13, xmm13
00007531fdbdf9d7  jnz 0x00007531FDBE4750
00007531fdbdf9dd  movaps [r15+0x140], xmm15
00007531fdbdf9e5  movaps xmm13, xmm10
00007531fdbdf9e9  addpd xmm13, xmm14
00007531fdbdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007531fdbdf9f4  ptest xmm12, xmm12
00007531fdbdf9fa  jnz 0x00007531FDBE4894
00007531fdbdfa00  movaps [r15+0x150], xmm13
00007531fdbdfa08  movaps xmm14, xmm1
00007531fdbdfa0c  addpd xmm14, xmm7
00007531fdbdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007531fdbdfa17  ptest xmm12, xmm12
00007531fdbdfa1d  jnz 0x00007531FDBE49D8
00007531fdbdfa23  movaps [r15+0x160], xmm14
00007531fdbdfa2b  movaps xmm1, xmm8
00007531fdbdfa2f  addpd xmm1, xmm9
00007531fdbdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007531fdbdfa39  ptest xmm12, xmm12
00007531fdbdfa3f  jnz 0x00007531FDBE4B1A
00007531fdbdfa45  movaps [r15+0x120], xmm1
00007531fdbdfa4d  movups [r13+r14*1], xmm15
00007531fdbdfa53  lea rax, [r14+0x10]
00007531fdbdfa57  movups [r13+rax*1], xmm13
00007531fdbdfa5d  lea rax, [r14+0x20]
00007531fdbdfa61  movups [r13+rax*1], xmm14
00007531fdbdfa67  lea rax, [r14+0x30]
00007531fdbdfa6b  movups [r13+rax*1], xmm1
00007531fdbdfa71  mov eax, [r15+0x108]
00007531fdbdfa78  sahf
00007531fdbdfa79  jnz 0x00007531FDBDFAAB
00007531fdbdfa7b  cmp dword ptr [r15+0x318], 0x00
00007531fdbdfa83  jz 0x00007531FDBDEAE0
00007531fdbdfa89  nop [rax+rax*1], ax
00007531fdbdfa92  nop [rax+rax*1], eax
00007531fdbdfa9a  mov eax, 0x4106D0
00007531fdbdfa9f  mov [r15+0x100], rax
00007531fdbdfaa6  jmp 0x00007531FD9FE110
00007531fdbdfaab  cmp dword ptr [r15+0x318], 0x00
00007531fdbdfab3  jz 0x00007531FDBD89C0
00007531fdbdfab9  nop [rax+rax*1], ax
00007531fdbdfac2  nop [rax+rax*1], eax
00007531fdbdfaca  mov eax, 0x410504
00007531fdbdfacf  mov [r15+0x100], rax
00007531fdbdfad6  jmp 0x00007531FD9FE110
00007531fdbdfadb  int3
00007531fdbdfadc  call 0x00007531FDAE27E0
00007531fdbdfae1  jmp 0x00007531FDBDEBBF
00007531fdbdfae6  call 0x00007531FDAE1570
00007531fdbdfaeb  jmp 0x00007531FDBDEBC8
00007531fdbdfaf0  call 0x00007531FDAE27E0
00007531fdbdfaf5  jmp 0x00007531FDBDEC24
00007531fdbdfafa  call 0x00007531FDAE1570
00007531fdbdfaff  jmp 0x00007531FDBDEC2D
00007531fdbdfb04  call 0x00007531FDAE27E0
00007531fdbdfb09  jmp 0x00007531FDBDEC70
00007531fdbdfb0e  call 0x00007531FDAE1570
00007531fdbdfb13  jmp 0x00007531FDBDEC79
00007531fdbdfb18  call 0x00007531FDA0DC20
00007531fdbdfb1d  jmp 0x00007531FDBDECB8
00007531fdbdfb22  call 0x00007531FDAD59C0
00007531fdbdfb27  jmp 0x00007531FDBDECCB
00007531fdbdfb2c  call 0x00007531FDAE0E30
00007531fdbdfb31  jmp 0x00007531FDBDECE9
00007531fdbdfb36  call 0x00007531FDADFBC0
00007531fdbdfb3b  jmp 0x00007531FDBDECF3
00007531fdbdfb40  call 0x00007531FDADE950
00007531fdbdfb45  jmp 0x00007531FDBDECFD
00007531fdbdfb4a  sub rsp, 0x08
00007531fdbdfb4e  push rax
00007531fdbdfb4f  push rcx
00007531fdbdfb50  push rdx
00007531fdbdfb51  push rdi
00007531fdbdfb52  push rsi
00007531fdbdfb53  push r8
00007531fdbdfb55  push r9
00007531fdbdfb57  push r10
00007531fdbdfb59  push r11
00007531fdbdfb5b  sub rsp, 0xF0
00007531fdbdfb62  vmovaps [rsp], xmm0
00007531fdbdfb67  vmovaps [rsp+0x10], xmm1
00007531fdbdfb6d  vmovaps [rsp+0x20], xmm2
00007531fdbdfb73  vmovaps [rsp+0x30], xmm3
00007531fdbdfb79  vmovaps [rsp+0x40], xmm4
00007531fdbdfb7f  vmovaps [rsp+0x50], xmm5
00007531fdbdfb85  vmovaps [rsp+0x60], xmm6
00007531fdbdfb8b  vmovaps [rsp+0x70], xmm7
00007531fdbdfb91  vmovaps [rsp+0x80], xmm9
00007531fdbdfb9a  vmovaps [rsp+0x90], xmm10
00007531fdbdfba3  vmovaps [rsp+0xA0], xmm11
00007531fdbdfbac  vmovaps [rsp+0xB0], xmm12
00007531fdbdfbb5  vmovaps [rsp+0xC0], xmm13
00007531fdbdfbbe  vmovaps [rsp+0xD0], xmm14
00007531fdbdfbc7  vmovaps [rsp+0xE0], xmm15
00007531fdbdfbd0  sub rsp, 0x30
00007531fdbdfbd4  movaps [rsp], xmm8
00007531fdbdfbd9  movaps [rsp+0x10], xmm12
00007531fdbdfbdf  movaps [rsp+0x20], xmm15
00007531fdbdfbe5  lea rdi, [rsp]
00007531fdbdfbe9  mov esi, 0x00
00007531fdbdfbee  mov rax, 0x59ED111DF530
00007531fdbdfbf8  call rax
00007531fdbdfbfa  movaps xmm8, [rsp]
00007531fdbdfbff  add rsp, 0x30
00007531fdbdfc03  vmovaps xmm0, [rsp]
00007531fdbdfc08  vmovaps xmm1, [rsp+0x10]
00007531fdbdfc0e  vmovaps xmm2, [rsp+0x20]
00007531fdbdfc14  vmovaps xmm3, [rsp+0x30]
00007531fdbdfc1a  vmovaps xmm4, [rsp+0x40]
00007531fdbdfc20  vmovaps xmm5, [rsp+0x50]
00007531fdbdfc26  vmovaps xmm6, [rsp+0x60]
00007531fdbdfc2c  vmovaps xmm7, [rsp+0x70]
00007531fdbdfc32  vmovaps xmm9, [rsp+0x80]
00007531fdbdfc3b  vmovaps xmm10, [rsp+0x90]
00007531fdbdfc44  vmovaps xmm11, [rsp+0xA0]
00007531fdbdfc4d  vmovaps xmm12, [rsp+0xB0]
00007531fdbdfc56  vmovaps xmm13, [rsp+0xC0]
00007531fdbdfc5f  vmovaps xmm14, [rsp+0xD0]
00007531fdbdfc68  vmovaps xmm15, [rsp+0xE0]
00007531fdbdfc71  add rsp, 0xF0
00007531fdbdfc78  pop r11
00007531fdbdfc7a  pop r10
00007531fdbdfc7c  pop r9
00007531fdbdfc7e  pop r8
00007531fdbdfc80  pop rsi
00007531fdbdfc81  pop rdi
00007531fdbdfc82  pop rdx
00007531fdbdfc83  pop rcx
00007531fdbdfc84  pop rax
00007531fdbdfc85  add rsp, 0x08
00007531fdbdfc89  jmp 0x00007531FDBDED27
00007531fdbdfc8e  sub rsp, 0x08
00007531fdbdfc92  push rax
00007531fdbdfc93  push rcx
00007531fdbdfc94  push rdx
00007531fdbdfc95  push rdi
00007531fdbdfc96  push rsi
00007531fdbdfc97  push r8
00007531fdbdfc99  push r9
00007531fdbdfc9b  push r10
00007531fdbdfc9d  push r11
00007531fdbdfc9f  sub rsp, 0xF0
00007531fdbdfca6  vmovaps [rsp], xmm0
00007531fdbdfcab  vmovaps [rsp+0x10], xmm1
00007531fdbdfcb1  vmovaps [rsp+0x20], xmm2
00007531fdbdfcb7  vmovaps [rsp+0x30], xmm3
00007531fdbdfcbd  vmovaps [rsp+0x40], xmm4
00007531fdbdfcc3  vmovaps [rsp+0x50], xmm5
00007531fdbdfcc9  vmovaps [rsp+0x60], xmm6
00007531fdbdfccf  vmovaps [rsp+0x70], xmm8
00007531fdbdfcd5  vmovaps [rsp+0x80], xmm9
00007531fdbdfcde  vmovaps [rsp+0x90], xmm10
00007531fdbdfce7  vmovaps [rsp+0xA0], xmm11
00007531fdbdfcf0  vmovaps [rsp+0xB0], xmm12
00007531fdbdfcf9  vmovaps [rsp+0xC0], xmm13
00007531fdbdfd02  vmovaps [rsp+0xD0], xmm14
00007531fdbdfd0b  vmovaps [rsp+0xE0], xmm15
00007531fdbdfd14  sub rsp, 0x30
00007531fdbdfd18  movaps [rsp], xmm7
00007531fdbdfd1c  movaps [rsp+0x10], xmm9
00007531fdbdfd22  movaps [rsp+0x20], xmm15
00007531fdbdfd28  lea rdi, [rsp]
00007531fdbdfd2c  mov esi, 0x00
00007531fdbdfd31  mov rax, 0x59ED111DF530
00007531fdbdfd3b  call rax
00007531fdbdfd3d  movaps xmm7, [rsp]
00007531fdbdfd41  add rsp, 0x30
00007531fdbdfd45  vmovaps xmm0, [rsp]
00007531fdbdfd4a  vmovaps xmm1, [rsp+0x10]
00007531fdbdfd50  vmovaps xmm2, [rsp+0x20]
00007531fdbdfd56  vmovaps xmm3, [rsp+0x30]
00007531fdbdfd5c  vmovaps xmm4, [rsp+0x40]
00007531fdbdfd62  vmovaps xmm5, [rsp+0x50]
00007531fdbdfd68  vmovaps xmm6, [rsp+0x60]
00007531fdbdfd6e  vmovaps xmm8, [rsp+0x70]
00007531fdbdfd74  vmovaps xmm9, [rsp+0x80]
00007531fdbdfd7d  vmovaps xmm10, [rsp+0x90]
00007531fdbdfd86  vmovaps xmm11, [rsp+0xA0]
00007531fdbdfd8f  vmovaps xmm12, [rsp+0xB0]
00007531fdbdfd98  vmovaps xmm13, [rsp+0xC0]
00007531fdbdfda1  vmovaps xmm14, [rsp+0xD0]
00007531fdbdfdaa  vmovaps xmm15, [rsp+0xE0]
00007531fdbdfdb3  add rsp, 0xF0
00007531fdbdfdba  pop r11
00007531fdbdfdbc  pop r10
00007531fdbdfdbe  pop r9
00007531fdbdfdc0  pop r8
00007531fdbdfdc2  pop rsi
00007531fdbdfdc3  pop rdi
00007531fdbdfdc4  pop rdx
00007531fdbdfdc5  pop rcx
00007531fdbdfdc6  pop rax
00007531fdbdfdc7  add rsp, 0x08
00007531fdbdfdcb  jmp 0x00007531FDBDED55
00007531fdbdfdd0  sub rsp, 0x08
00007531fdbdfdd4  push rax
00007531fdbdfdd5  push rcx
00007531fdbdfdd6  push rdx
00007531fdbdfdd7  push rdi
00007531fdbdfdd8  push rsi
00007531fdbdfdd9  push r8
00007531fdbdfddb  push r9
00007531fdbdfddd  push r10
00007531fdbdfddf  push r11
00007531fdbdfde1  sub rsp, 0xF0
00007531fdbdfde8  vmovaps [rsp], xmm0
00007531fdbdfded  vmovaps [rsp+0x10], xmm1
00007531fdbdfdf3  vmovaps [rsp+0x20], xmm2
00007531fdbdfdf9  vmovaps [rsp+0x30], xmm3
00007531fdbdfdff  vmovaps [rsp+0x40], xmm4
00007531fdbdfe05  vmovaps [rsp+0x50], xmm5
00007531fdbdfe0b  vmovaps [rsp+0x60], xmm6
00007531fdbdfe11  vmovaps [rsp+0x70], xmm7
00007531fdbdfe17  vmovaps [rsp+0x80], xmm8
00007531fdbdfe20  vmovaps [rsp+0x90], xmm10
00007531fdbdfe29  vmovaps [rsp+0xA0], xmm11
00007531fdbdfe32  vmovaps [rsp+0xB0], xmm12
00007531fdbdfe3b  vmovaps [rsp+0xC0], xmm13
00007531fdbdfe44  vmovaps [rsp+0xD0], xmm14
00007531fdbdfe4d  vmovaps [rsp+0xE0], xmm15
00007531fdbdfe56  sub rsp, 0x30
00007531fdbdfe5a  movaps [rsp], xmm9
00007531fdbdfe5f  movaps [rsp+0x10], xmm12
00007531fdbdfe65  movaps [rsp+0x20], xmm10
00007531fdbdfe6b  lea rdi, [rsp]
00007531fdbdfe6f  mov esi, 0x00
00007531fdbdfe74  mov rax, 0x59ED111DF530
00007531fdbdfe7e  call rax
00007531fdbdfe80  movaps xmm9, [rsp]
00007531fdbdfe85  add rsp, 0x30
00007531fdbdfe89  vmovaps xmm0, [rsp]
00007531fdbdfe8e  vmovaps xmm1, [rsp+0x10]
00007531fdbdfe94  vmovaps xmm2, [rsp+0x20]
00007531fdbdfe9a  vmovaps xmm3, [rsp+0x30]
00007531fdbdfea0  vmovaps xmm4, [rsp+0x40]
00007531fdbdfea6  vmovaps xmm5, [rsp+0x50]
00007531fdbdfeac  vmovaps xmm6, [rsp+0x60]
00007531fdbdfeb2  vmovaps xmm7, [rsp+0x70]
00007531fdbdfeb8  vmovaps xmm8, [rsp+0x80]
00007531fdbdfec1  vmovaps xmm10, [rsp+0x90]
00007531fdbdfeca  vmovaps xmm11, [rsp+0xA0]
00007531fdbdfed3  vmovaps xmm12, [rsp+0xB0]
00007531fdbdfedc  vmovaps xmm13, [rsp+0xC0]
00007531fdbdfee5  vmovaps xmm14, [rsp+0xD0]
00007531fdbdfeee  vmovaps xmm15, [rsp+0xE0]
00007531fdbdfef7  add rsp, 0xF0
00007531fdbdfefe  pop r11
00007531fdbdff00  pop r10
00007531fdbdff02  pop r9
00007531fdbdff04  pop r8
00007531fdbdff06  pop rsi
00007531fdbdff07  pop rdi
00007531fdbdff08  pop rdx
00007531fdbdff09  pop rcx
00007531fdbdff0a  pop rax
00007531fdbdff0b  add rsp, 0x08
00007531fdbdff0f  jmp 0x00007531FDBDED79
00007531fdbdff14  sub rsp, 0x08
00007531fdbdff18  push rax
00007531fdbdff19  push rcx
00007531fdbdff1a  push rdx
00007531fdbdff1b  push rdi
00007531fdbdff1c  push rsi
00007531fdbdff1d  push r8
00007531fdbdff1f  push r9
00007531fdbdff21  push r10
00007531fdbdff23  push r11
00007531fdbdff25  sub rsp, 0xF0
00007531fdbdff2c  vmovaps [rsp], xmm0
00007531fdbdff31  vmovaps [rsp+0x10], xmm1
00007531fdbdff37  vmovaps [rsp+0x20], xmm2
00007531fdbdff3d  vmovaps [rsp+0x30], xmm3
00007531fdbdff43  vmovaps [rsp+0x40], xmm4
00007531fdbdff49  vmovaps [rsp+0x50], xmm5
00007531fdbdff4f  vmovaps [rsp+0x60], xmm6
00007531fdbdff55  vmovaps [rsp+0x70], xmm7
00007531fdbdff5b  vmovaps [rsp+0x80], xmm8
00007531fdbdff64  vmovaps [rsp+0x90], xmm9
00007531fdbdff6d  vmovaps [rsp+0xA0], xmm11
00007531fdbdff76  vmovaps [rsp+0xB0], xmm12
00007531fdbdff7f  vmovaps [rsp+0xC0], xmm13
00007531fdbdff88  vmovaps [rsp+0xD0], xmm14
00007531fdbdff91  vmovaps [rsp+0xE0], xmm15
00007531fdbdff9a  sub rsp, 0x30
00007531fdbdff9e  movaps [rsp], xmm10
00007531fdbdffa3  movaps [rsp+0x10], xmm12
00007531fdbdffa9  movaps [rsp+0x20], xmm11
00007531fdbdffaf  lea rdi, [rsp]
00007531fdbdffb3  mov esi, 0x00
00007531fdbdffb8  mov rax, 0x59ED111DF530
00007531fdbdffc2  call rax
00007531fdbdffc4  movaps xmm10, [rsp]
00007531fdbdffc9  add rsp, 0x30
00007531fdbdffcd  vmovaps xmm0, [rsp]
00007531fdbdffd2  vmovaps xmm1, [rsp+0x10]
00007531fdbdffd8  vmovaps xmm2, [rsp+0x20]
00007531fdbdffde  vmovaps xmm3, [rsp+0x30]
00007531fdbdffe4  vmovaps xmm4, [rsp+0x40]
00007531fdbdffea  vmovaps xmm5, [rsp+0x50]
00007531fdbdfff0  vmovaps xmm6, [rsp+0x60]
00007531fdbdfff6  vmovaps xmm7, [rsp+0x70]
00007531fdbdfffc  vmovaps xmm8, [rsp+0x80]
00007531fdbe0005  vmovaps xmm9, [rsp+0x90]
00007531fdbe000e  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0017  vmovaps xmm12, [rsp+0xB0]
00007531fdbe0020  vmovaps xmm13, [rsp+0xC0]
00007531fdbe0029  vmovaps xmm14, [rsp+0xD0]
00007531fdbe0032  vmovaps xmm15, [rsp+0xE0]
00007531fdbe003b  add rsp, 0xF0
00007531fdbe0042  pop r11
00007531fdbe0044  pop r10
00007531fdbe0046  pop r9
00007531fdbe0048  pop r8
00007531fdbe004a  pop rsi
00007531fdbe004b  pop rdi
00007531fdbe004c  pop rdx
00007531fdbe004d  pop rcx
00007531fdbe004e  pop rax
00007531fdbe004f  add rsp, 0x08
00007531fdbe0053  jmp 0x00007531FDBDED93
00007531fdbe0058  sub rsp, 0x08
00007531fdbe005c  push rax
00007531fdbe005d  push rcx
00007531fdbe005e  push rdx
00007531fdbe005f  push rdi
00007531fdbe0060  push rsi
00007531fdbe0061  push r8
00007531fdbe0063  push r9
00007531fdbe0065  push r10
00007531fdbe0067  push r11
00007531fdbe0069  sub rsp, 0xF0
00007531fdbe0070  vmovaps [rsp], xmm0
00007531fdbe0075  vmovaps [rsp+0x10], xmm1
00007531fdbe007b  vmovaps [rsp+0x20], xmm2
00007531fdbe0081  vmovaps [rsp+0x30], xmm3
00007531fdbe0087  vmovaps [rsp+0x40], xmm4
00007531fdbe008d  vmovaps [rsp+0x50], xmm5
00007531fdbe0093  vmovaps [rsp+0x60], xmm7
00007531fdbe0099  vmovaps [rsp+0x70], xmm8
00007531fdbe009f  vmovaps [rsp+0x80], xmm9
00007531fdbe00a8  vmovaps [rsp+0x90], xmm10
00007531fdbe00b1  vmovaps [rsp+0xA0], xmm11
00007531fdbe00ba  vmovaps [rsp+0xB0], xmm12
00007531fdbe00c3  vmovaps [rsp+0xC0], xmm13
00007531fdbe00cc  vmovaps [rsp+0xD0], xmm14
00007531fdbe00d5  vmovaps [rsp+0xE0], xmm15
00007531fdbe00de  sub rsp, 0x30
00007531fdbe00e2  movaps [rsp], xmm6
00007531fdbe00e6  movaps [rsp+0x10], xmm12
00007531fdbe00ec  movaps [rsp+0x20], xmm11
00007531fdbe00f2  lea rdi, [rsp]
00007531fdbe00f6  mov esi, 0x00
00007531fdbe00fb  mov rax, 0x59ED111DF530
00007531fdbe0105  call rax
00007531fdbe0107  movaps xmm6, [rsp]
00007531fdbe010b  add rsp, 0x30
00007531fdbe010f  vmovaps xmm0, [rsp]
00007531fdbe0114  vmovaps xmm1, [rsp+0x10]
00007531fdbe011a  vmovaps xmm2, [rsp+0x20]
00007531fdbe0120  vmovaps xmm3, [rsp+0x30]
00007531fdbe0126  vmovaps xmm4, [rsp+0x40]
00007531fdbe012c  vmovaps xmm5, [rsp+0x50]
00007531fdbe0132  vmovaps xmm7, [rsp+0x60]
00007531fdbe0138  vmovaps xmm8, [rsp+0x70]
00007531fdbe013e  vmovaps xmm9, [rsp+0x80]
00007531fdbe0147  vmovaps xmm10, [rsp+0x90]
00007531fdbe0150  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0159  vmovaps xmm12, [rsp+0xB0]
00007531fdbe0162  vmovaps xmm13, [rsp+0xC0]
00007531fdbe016b  vmovaps xmm14, [rsp+0xD0]
00007531fdbe0174  vmovaps xmm15, [rsp+0xE0]
00007531fdbe017d  add rsp, 0xF0
00007531fdbe0184  pop r11
00007531fdbe0186  pop r10
00007531fdbe0188  pop r9
00007531fdbe018a  pop r8
00007531fdbe018c  pop rsi
00007531fdbe018d  pop rdi
00007531fdbe018e  pop rdx
00007531fdbe018f  pop rcx
00007531fdbe0190  pop rax
00007531fdbe0191  add rsp, 0x08
00007531fdbe0195  jmp 0x00007531FDBDEDB4
00007531fdbe019a  sub rsp, 0x08
00007531fdbe019e  push rax
00007531fdbe019f  push rcx
00007531fdbe01a0  push rdx
00007531fdbe01a1  push rdi
00007531fdbe01a2  push rsi
00007531fdbe01a3  push r8
00007531fdbe01a5  push r9
00007531fdbe01a7  push r10
00007531fdbe01a9  push r11
00007531fdbe01ab  sub rsp, 0xF0
00007531fdbe01b2  vmovaps [rsp], xmm0
00007531fdbe01b7  vmovaps [rsp+0x10], xmm1
00007531fdbe01bd  vmovaps [rsp+0x20], xmm2
00007531fdbe01c3  vmovaps [rsp+0x30], xmm4
00007531fdbe01c9  vmovaps [rsp+0x40], xmm5
00007531fdbe01cf  vmovaps [rsp+0x50], xmm6
00007531fdbe01d5  vmovaps [rsp+0x60], xmm7
00007531fdbe01db  vmovaps [rsp+0x70], xmm8
00007531fdbe01e1  vmovaps [rsp+0x80], xmm9
00007531fdbe01ea  vmovaps [rsp+0x90], xmm10
00007531fdbe01f3  vmovaps [rsp+0xA0], xmm11
00007531fdbe01fc  vmovaps [rsp+0xB0], xmm12
00007531fdbe0205  vmovaps [rsp+0xC0], xmm13
00007531fdbe020e  vmovaps [rsp+0xD0], xmm14
00007531fdbe0217  vmovaps [rsp+0xE0], xmm15
00007531fdbe0220  sub rsp, 0x30
00007531fdbe0224  movaps [rsp], xmm3
00007531fdbe0228  movaps [rsp+0x10], xmm5
00007531fdbe022d  movaps [rsp+0x20], xmm4
00007531fdbe0232  lea rdi, [rsp]
00007531fdbe0236  mov esi, 0x00
00007531fdbe023b  mov rax, 0x59ED111DF530
00007531fdbe0245  call rax
00007531fdbe0247  movaps xmm3, [rsp]
00007531fdbe024b  add rsp, 0x30
00007531fdbe024f  vmovaps xmm0, [rsp]
00007531fdbe0254  vmovaps xmm1, [rsp+0x10]
00007531fdbe025a  vmovaps xmm2, [rsp+0x20]
00007531fdbe0260  vmovaps xmm4, [rsp+0x30]
00007531fdbe0266  vmovaps xmm5, [rsp+0x40]
00007531fdbe026c  vmovaps xmm6, [rsp+0x50]
00007531fdbe0272  vmovaps xmm7, [rsp+0x60]
00007531fdbe0278  vmovaps xmm8, [rsp+0x70]
00007531fdbe027e  vmovaps xmm9, [rsp+0x80]
00007531fdbe0287  vmovaps xmm10, [rsp+0x90]
00007531fdbe0290  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0299  vmovaps xmm12, [rsp+0xB0]
00007531fdbe02a2  vmovaps xmm13, [rsp+0xC0]
00007531fdbe02ab  vmovaps xmm14, [rsp+0xD0]
00007531fdbe02b4  vmovaps xmm15, [rsp+0xE0]
00007531fdbe02bd  add rsp, 0xF0
00007531fdbe02c4  pop r11
00007531fdbe02c6  pop r10
00007531fdbe02c8  pop r9
00007531fdbe02ca  pop r8
00007531fdbe02cc  pop rsi
00007531fdbe02cd  pop rdi
00007531fdbe02ce  pop rdx
00007531fdbe02cf  pop rcx
00007531fdbe02d0  pop rax
00007531fdbe02d1  add rsp, 0x08
00007531fdbe02d5  jmp 0x00007531FDBDEE15
00007531fdbe02da  sub rsp, 0x08
00007531fdbe02de  push rax
00007531fdbe02df  push rcx
00007531fdbe02e0  push rdx
00007531fdbe02e1  push rdi
00007531fdbe02e2  push rsi
00007531fdbe02e3  push r8
00007531fdbe02e5  push r9
00007531fdbe02e7  push r10
00007531fdbe02e9  push r11
00007531fdbe02eb  sub rsp, 0xF0
00007531fdbe02f2  vmovaps [rsp], xmm0
00007531fdbe02f7  vmovaps [rsp+0x10], xmm1
00007531fdbe02fd  vmovaps [rsp+0x20], xmm2
00007531fdbe0303  vmovaps [rsp+0x30], xmm3
00007531fdbe0309  vmovaps [rsp+0x40], xmm4
00007531fdbe030f  vmovaps [rsp+0x50], xmm6
00007531fdbe0315  vmovaps [rsp+0x60], xmm7
00007531fdbe031b  vmovaps [rsp+0x70], xmm8
00007531fdbe0321  vmovaps [rsp+0x80], xmm9
00007531fdbe032a  vmovaps [rsp+0x90], xmm10
00007531fdbe0333  vmovaps [rsp+0xA0], xmm11
00007531fdbe033c  vmovaps [rsp+0xB0], xmm12
00007531fdbe0345  vmovaps [rsp+0xC0], xmm13
00007531fdbe034e  vmovaps [rsp+0xD0], xmm14
00007531fdbe0357  vmovaps [rsp+0xE0], xmm15
00007531fdbe0360  sub rsp, 0x30
00007531fdbe0364  movaps [rsp], xmm5
00007531fdbe0368  movaps [rsp+0x10], xmm8
00007531fdbe036e  movaps [rsp+0x20], xmm15
00007531fdbe0374  lea rdi, [rsp]
00007531fdbe0378  mov esi, 0x00
00007531fdbe037d  mov rax, 0x59ED111DF530
00007531fdbe0387  call rax
00007531fdbe0389  movaps xmm5, [rsp]
00007531fdbe038d  add rsp, 0x30
00007531fdbe0391  vmovaps xmm0, [rsp]
00007531fdbe0396  vmovaps xmm1, [rsp+0x10]
00007531fdbe039c  vmovaps xmm2, [rsp+0x20]
00007531fdbe03a2  vmovaps xmm3, [rsp+0x30]
00007531fdbe03a8  vmovaps xmm4, [rsp+0x40]
00007531fdbe03ae  vmovaps xmm6, [rsp+0x50]
00007531fdbe03b4  vmovaps xmm7, [rsp+0x60]
00007531fdbe03ba  vmovaps xmm8, [rsp+0x70]
00007531fdbe03c0  vmovaps xmm9, [rsp+0x80]
00007531fdbe03c9  vmovaps xmm10, [rsp+0x90]
00007531fdbe03d2  vmovaps xmm11, [rsp+0xA0]
00007531fdbe03db  vmovaps xmm12, [rsp+0xB0]
00007531fdbe03e4  vmovaps xmm13, [rsp+0xC0]
00007531fdbe03ed  vmovaps xmm14, [rsp+0xD0]
00007531fdbe03f6  vmovaps xmm15, [rsp+0xE0]
00007531fdbe03ff  add rsp, 0xF0
00007531fdbe0406  pop r11
00007531fdbe0408  pop r10
00007531fdbe040a  pop r9
00007531fdbe040c  pop r8
00007531fdbe040e  pop rsi
00007531fdbe040f  pop rdi
00007531fdbe0410  pop rdx
00007531fdbe0411  pop rcx
00007531fdbe0412  pop rax
00007531fdbe0413  add rsp, 0x08
00007531fdbe0417  jmp 0x00007531FDBDEE53
00007531fdbe041c  sub rsp, 0x08
00007531fdbe0420  push rax
00007531fdbe0421  push rcx
00007531fdbe0422  push rdx
00007531fdbe0423  push rdi
00007531fdbe0424  push rsi
00007531fdbe0425  push r8
00007531fdbe0427  push r9
00007531fdbe0429  push r10
00007531fdbe042b  push r11
00007531fdbe042d  sub rsp, 0xF0
00007531fdbe0434  vmovaps [rsp], xmm0
00007531fdbe0439  vmovaps [rsp+0x10], xmm1
00007531fdbe043f  vmovaps [rsp+0x20], xmm2
00007531fdbe0445  vmovaps [rsp+0x30], xmm3
00007531fdbe044b  vmovaps [rsp+0x40], xmm5
00007531fdbe0451  vmovaps [rsp+0x50], xmm6
00007531fdbe0457  vmovaps [rsp+0x60], xmm7
00007531fdbe045d  vmovaps [rsp+0x70], xmm8
00007531fdbe0463  vmovaps [rsp+0x80], xmm9
00007531fdbe046c  vmovaps [rsp+0x90], xmm10
00007531fdbe0475  vmovaps [rsp+0xA0], xmm11
00007531fdbe047e  vmovaps [rsp+0xB0], xmm12
00007531fdbe0487  vmovaps [rsp+0xC0], xmm13
00007531fdbe0490  vmovaps [rsp+0xD0], xmm14
00007531fdbe0499  vmovaps [rsp+0xE0], xmm15
00007531fdbe04a2  sub rsp, 0x30
00007531fdbe04a6  movaps [rsp], xmm4
00007531fdbe04aa  movaps [rsp+0x10], xmm9
00007531fdbe04b0  movaps [rsp+0x20], xmm8
00007531fdbe04b6  lea rdi, [rsp]
00007531fdbe04ba  mov esi, 0x00
00007531fdbe04bf  mov rax, 0x59ED111DF530
00007531fdbe04c9  call rax
00007531fdbe04cb  movaps xmm4, [rsp]
00007531fdbe04cf  add rsp, 0x30
00007531fdbe04d3  vmovaps xmm0, [rsp]
00007531fdbe04d8  vmovaps xmm1, [rsp+0x10]
00007531fdbe04de  vmovaps xmm2, [rsp+0x20]
00007531fdbe04e4  vmovaps xmm3, [rsp+0x30]
00007531fdbe04ea  vmovaps xmm5, [rsp+0x40]
00007531fdbe04f0  vmovaps xmm6, [rsp+0x50]
00007531fdbe04f6  vmovaps xmm7, [rsp+0x60]
00007531fdbe04fc  vmovaps xmm8, [rsp+0x70]
00007531fdbe0502  vmovaps xmm9, [rsp+0x80]
00007531fdbe050b  vmovaps xmm10, [rsp+0x90]
00007531fdbe0514  vmovaps xmm11, [rsp+0xA0]
00007531fdbe051d  vmovaps xmm12, [rsp+0xB0]
00007531fdbe0526  vmovaps xmm13, [rsp+0xC0]
00007531fdbe052f  vmovaps xmm14, [rsp+0xD0]
00007531fdbe0538  vmovaps xmm15, [rsp+0xE0]
00007531fdbe0541  add rsp, 0xF0
00007531fdbe0548  pop r11
00007531fdbe054a  pop r10
00007531fdbe054c  pop r9
00007531fdbe054e  pop r8
00007531fdbe0550  pop rsi
00007531fdbe0551  pop rdi
00007531fdbe0552  pop rdx
00007531fdbe0553  pop rcx
00007531fdbe0554  pop rax
00007531fdbe0555  add rsp, 0x08
00007531fdbe0559  jmp 0x00007531FDBDEE74
00007531fdbe055e  sub rsp, 0x08
00007531fdbe0562  push rax
00007531fdbe0563  push rcx
00007531fdbe0564  push rdx
00007531fdbe0565  push rdi
00007531fdbe0566  push rsi
00007531fdbe0567  push r8
00007531fdbe0569  push r9
00007531fdbe056b  push r10
00007531fdbe056d  push r11
00007531fdbe056f  sub rsp, 0xF0
00007531fdbe0576  vmovaps [rsp], xmm0
00007531fdbe057b  vmovaps [rsp+0x10], xmm1
00007531fdbe0581  vmovaps [rsp+0x20], xmm2
00007531fdbe0587  vmovaps [rsp+0x30], xmm3
00007531fdbe058d  vmovaps [rsp+0x40], xmm4
00007531fdbe0593  vmovaps [rsp+0x50], xmm5
00007531fdbe0599  vmovaps [rsp+0x60], xmm6
00007531fdbe059f  vmovaps [rsp+0x70], xmm7
00007531fdbe05a5  vmovaps [rsp+0x80], xmm8
00007531fdbe05ae  vmovaps [rsp+0x90], xmm10
00007531fdbe05b7  vmovaps [rsp+0xA0], xmm11
00007531fdbe05c0  vmovaps [rsp+0xB0], xmm12
00007531fdbe05c9  vmovaps [rsp+0xC0], xmm13
00007531fdbe05d2  vmovaps [rsp+0xD0], xmm14
00007531fdbe05db  vmovaps [rsp+0xE0], xmm15
00007531fdbe05e4  sub rsp, 0x30
00007531fdbe05e8  movaps [rsp], xmm9
00007531fdbe05ed  movaps [rsp+0x10], xmm10
00007531fdbe05f3  movaps [rsp+0x20], xmm8
00007531fdbe05f9  lea rdi, [rsp]
00007531fdbe05fd  mov esi, 0x00
00007531fdbe0602  mov rax, 0x59ED111DF530
00007531fdbe060c  call rax
00007531fdbe060e  movaps xmm9, [rsp]
00007531fdbe0613  add rsp, 0x30
00007531fdbe0617  vmovaps xmm0, [rsp]
00007531fdbe061c  vmovaps xmm1, [rsp+0x10]
00007531fdbe0622  vmovaps xmm2, [rsp+0x20]
00007531fdbe0628  vmovaps xmm3, [rsp+0x30]
00007531fdbe062e  vmovaps xmm4, [rsp+0x40]
00007531fdbe0634  vmovaps xmm5, [rsp+0x50]
00007531fdbe063a  vmovaps xmm6, [rsp+0x60]
00007531fdbe0640  vmovaps xmm7, [rsp+0x70]
00007531fdbe0646  vmovaps xmm8, [rsp+0x80]
00007531fdbe064f  vmovaps xmm10, [rsp+0x90]
00007531fdbe0658  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0661  vmovaps xmm12, [rsp+0xB0]
00007531fdbe066a  vmovaps xmm13, [rsp+0xC0]
00007531fdbe0673  vmovaps xmm14, [rsp+0xD0]
00007531fdbe067c  vmovaps xmm15, [rsp+0xE0]
00007531fdbe0685  add rsp, 0xF0
00007531fdbe068c  pop r11
00007531fdbe068e  pop r10
00007531fdbe0690  pop r9
00007531fdbe0692  pop r8
00007531fdbe0694  pop rsi
00007531fdbe0695  pop rdi
00007531fdbe0696  pop rdx
00007531fdbe0697  pop rcx
00007531fdbe0698  pop rax
00007531fdbe0699  add rsp, 0x08
00007531fdbe069d  jmp 0x00007531FDBDEE8E
00007531fdbe06a2  call 0x00007531FDAB52F0
00007531fdbe06a7  jmp 0x00007531FDBDEFA8
00007531fdbe06ac  call 0x00007531FDAB52F0
00007531fdbe06b1  jmp 0x00007531FDBDEFBE
00007531fdbe06b6  sub rsp, 0x08
00007531fdbe06ba  push rax
00007531fdbe06bb  push rcx
00007531fdbe06bc  push rdx
00007531fdbe06bd  push rdi
00007531fdbe06be  push rsi
00007531fdbe06bf  push r8
00007531fdbe06c1  push r9
00007531fdbe06c3  push r10
00007531fdbe06c5  push r11
00007531fdbe06c7  sub rsp, 0xF0
00007531fdbe06ce  vmovaps [rsp], xmm0
00007531fdbe06d3  vmovaps [rsp+0x10], xmm2
00007531fdbe06d9  vmovaps [rsp+0x20], xmm3
00007531fdbe06df  vmovaps [rsp+0x30], xmm4
00007531fdbe06e5  vmovaps [rsp+0x40], xmm5
00007531fdbe06eb  vmovaps [rsp+0x50], xmm6
00007531fdbe06f1  vmovaps [rsp+0x60], xmm7
00007531fdbe06f7  vmovaps [rsp+0x70], xmm8
00007531fdbe06fd  vmovaps [rsp+0x80], xmm9
00007531fdbe0706  vmovaps [rsp+0x90], xmm10
00007531fdbe070f  vmovaps [rsp+0xA0], xmm11
00007531fdbe0718  vmovaps [rsp+0xB0], xmm12
00007531fdbe0721  vmovaps [rsp+0xC0], xmm13
00007531fdbe072a  vmovaps [rsp+0xD0], xmm14
00007531fdbe0733  vmovaps [rsp+0xE0], xmm15
00007531fdbe073c  sub rsp, 0x30
00007531fdbe0740  movaps [rsp], xmm1
00007531fdbe0744  movaps [rsp+0x10], xmm6
00007531fdbe0749  movaps [rsp+0x20], xmm15
00007531fdbe074f  lea rdi, [rsp]
00007531fdbe0753  mov esi, 0x00
00007531fdbe0758  mov rax, 0x59ED111DF530
00007531fdbe0762  call rax
00007531fdbe0764  movaps xmm1, [rsp]
00007531fdbe0768  add rsp, 0x30
00007531fdbe076c  vmovaps xmm0, [rsp]
00007531fdbe0771  vmovaps xmm2, [rsp+0x10]
00007531fdbe0777  vmovaps xmm3, [rsp+0x20]
00007531fdbe077d  vmovaps xmm4, [rsp+0x30]
00007531fdbe0783  vmovaps xmm5, [rsp+0x40]
00007531fdbe0789  vmovaps xmm6, [rsp+0x50]
00007531fdbe078f  vmovaps xmm7, [rsp+0x60]
00007531fdbe0795  vmovaps xmm8, [rsp+0x70]
00007531fdbe079b  vmovaps xmm9, [rsp+0x80]
00007531fdbe07a4  vmovaps xmm10, [rsp+0x90]
00007531fdbe07ad  vmovaps xmm11, [rsp+0xA0]
00007531fdbe07b6  vmovaps xmm12, [rsp+0xB0]
00007531fdbe07bf  vmovaps xmm13, [rsp+0xC0]
00007531fdbe07c8  vmovaps xmm14, [rsp+0xD0]
00007531fdbe07d1  vmovaps xmm15, [rsp+0xE0]
00007531fdbe07da  add rsp, 0xF0
00007531fdbe07e1  pop r11
00007531fdbe07e3  pop r10
00007531fdbe07e5  pop r9
00007531fdbe07e7  pop r8
00007531fdbe07e9  pop rsi
00007531fdbe07ea  pop rdi
00007531fdbe07eb  pop rdx
00007531fdbe07ec  pop rcx
00007531fdbe07ed  pop rax
00007531fdbe07ee  add rsp, 0x08
00007531fdbe07f2  jmp 0x00007531FDBDEFFB
00007531fdbe07f7  call 0x00007531FDAC4620
00007531fdbe07fc  jmp 0x00007531FDBDF008
00007531fdbe0801  sub rsp, 0x08
00007531fdbe0805  push rax
00007531fdbe0806  push rcx
00007531fdbe0807  push rdx
00007531fdbe0808  push rdi
00007531fdbe0809  push rsi
00007531fdbe080a  push r8
00007531fdbe080c  push r9
00007531fdbe080e  push r10
00007531fdbe0810  push r11
00007531fdbe0812  sub rsp, 0xF0
00007531fdbe0819  vmovaps [rsp], xmm0
00007531fdbe081e  vmovaps [rsp+0x10], xmm1
00007531fdbe0824  vmovaps [rsp+0x20], xmm2
00007531fdbe082a  vmovaps [rsp+0x30], xmm3
00007531fdbe0830  vmovaps [rsp+0x40], xmm4
00007531fdbe0836  vmovaps [rsp+0x50], xmm5
00007531fdbe083c  vmovaps [rsp+0x60], xmm6
00007531fdbe0842  vmovaps [rsp+0x70], xmm7
00007531fdbe0848  vmovaps [rsp+0x80], xmm8
00007531fdbe0851  vmovaps [rsp+0x90], xmm9
00007531fdbe085a  vmovaps [rsp+0xA0], xmm10
00007531fdbe0863  vmovaps [rsp+0xB0], xmm11
00007531fdbe086c  vmovaps [rsp+0xC0], xmm12
00007531fdbe0875  vmovaps [rsp+0xD0], xmm13
00007531fdbe087e  vmovaps [rsp+0xE0], xmm15
00007531fdbe0887  sub rsp, 0x30
00007531fdbe088b  movaps [rsp], xmm14
00007531fdbe0890  movaps [rsp+0x10], xmm4
00007531fdbe0895  movaps [rsp+0x20], xmm3
00007531fdbe089a  lea rdi, [rsp]
00007531fdbe089e  mov esi, 0x00
00007531fdbe08a3  mov rax, 0x59ED111DF530
00007531fdbe08ad  call rax
00007531fdbe08af  movaps xmm14, [rsp]
00007531fdbe08b4  add rsp, 0x30
00007531fdbe08b8  vmovaps xmm0, [rsp]
00007531fdbe08bd  vmovaps xmm1, [rsp+0x10]
00007531fdbe08c3  vmovaps xmm2, [rsp+0x20]
00007531fdbe08c9  vmovaps xmm3, [rsp+0x30]
00007531fdbe08cf  vmovaps xmm4, [rsp+0x40]
00007531fdbe08d5  vmovaps xmm5, [rsp+0x50]
00007531fdbe08db  vmovaps xmm6, [rsp+0x60]
00007531fdbe08e1  vmovaps xmm7, [rsp+0x70]
00007531fdbe08e7  vmovaps xmm8, [rsp+0x80]
00007531fdbe08f0  vmovaps xmm9, [rsp+0x90]
00007531fdbe08f9  vmovaps xmm10, [rsp+0xA0]
00007531fdbe0902  vmovaps xmm11, [rsp+0xB0]
00007531fdbe090b  vmovaps xmm12, [rsp+0xC0]
00007531fdbe0914  vmovaps xmm13, [rsp+0xD0]
00007531fdbe091d  vmovaps xmm15, [rsp+0xE0]
00007531fdbe0926  add rsp, 0xF0
00007531fdbe092d  pop r11
00007531fdbe092f  pop r10
00007531fdbe0931  pop r9
00007531fdbe0933  pop r8
00007531fdbe0935  pop rsi
00007531fdbe0936  pop rdi
00007531fdbe0937  pop rdx
00007531fdbe0938  pop rcx
00007531fdbe0939  pop rax
00007531fdbe093a  add rsp, 0x08
00007531fdbe093e  jmp 0x00007531FDBDF022
00007531fdbe0943  sub rsp, 0x08
00007531fdbe0947  push rax
00007531fdbe0948  push rcx
00007531fdbe0949  push rdx
00007531fdbe094a  push rdi
00007531fdbe094b  push rsi
00007531fdbe094c  push r8
00007531fdbe094e  push r9
00007531fdbe0950  push r10
00007531fdbe0952  push r11
00007531fdbe0954  sub rsp, 0xF0
00007531fdbe095b  vmovaps [rsp], xmm0
00007531fdbe0960  vmovaps [rsp+0x10], xmm1
00007531fdbe0966  vmovaps [rsp+0x20], xmm2
00007531fdbe096c  vmovaps [rsp+0x30], xmm3
00007531fdbe0972  vmovaps [rsp+0x40], xmm4
00007531fdbe0978  vmovaps [rsp+0x50], xmm5
00007531fdbe097e  vmovaps [rsp+0x60], xmm7
00007531fdbe0984  vmovaps [rsp+0x70], xmm8
00007531fdbe098a  vmovaps [rsp+0x80], xmm9
00007531fdbe0993  vmovaps [rsp+0x90], xmm10
00007531fdbe099c  vmovaps [rsp+0xA0], xmm11
00007531fdbe09a5  vmovaps [rsp+0xB0], xmm12
00007531fdbe09ae  vmovaps [rsp+0xC0], xmm13
00007531fdbe09b7  vmovaps [rsp+0xD0], xmm14
00007531fdbe09c0  vmovaps [rsp+0xE0], xmm15
00007531fdbe09c9  sub rsp, 0x30
00007531fdbe09cd  movaps [rsp], xmm6
00007531fdbe09d1  movaps [rsp+0x10], xmm9
00007531fdbe09d7  movaps [rsp+0x20], xmm7
00007531fdbe09dc  lea rdi, [rsp]
00007531fdbe09e0  mov esi, 0x00
00007531fdbe09e5  mov rax, 0x59ED111DF530
00007531fdbe09ef  call rax
00007531fdbe09f1  movaps xmm6, [rsp]
00007531fdbe09f5  add rsp, 0x30
00007531fdbe09f9  vmovaps xmm0, [rsp]
00007531fdbe09fe  vmovaps xmm1, [rsp+0x10]
00007531fdbe0a04  vmovaps xmm2, [rsp+0x20]
00007531fdbe0a0a  vmovaps xmm3, [rsp+0x30]
00007531fdbe0a10  vmovaps xmm4, [rsp+0x40]
00007531fdbe0a16  vmovaps xmm5, [rsp+0x50]
00007531fdbe0a1c  vmovaps xmm7, [rsp+0x60]
00007531fdbe0a22  vmovaps xmm8, [rsp+0x70]
00007531fdbe0a28  vmovaps xmm9, [rsp+0x80]
00007531fdbe0a31  vmovaps xmm10, [rsp+0x90]
00007531fdbe0a3a  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0a43  vmovaps xmm12, [rsp+0xB0]
00007531fdbe0a4c  vmovaps xmm13, [rsp+0xC0]
00007531fdbe0a55  vmovaps xmm14, [rsp+0xD0]
00007531fdbe0a5e  vmovaps xmm15, [rsp+0xE0]
00007531fdbe0a67  add rsp, 0xF0
00007531fdbe0a6e  pop r11
00007531fdbe0a70  pop r10
00007531fdbe0a72  pop r9
00007531fdbe0a74  pop r8
00007531fdbe0a76  pop rsi
00007531fdbe0a77  pop rdi
00007531fdbe0a78  pop rdx
00007531fdbe0a79  pop rcx
00007531fdbe0a7a  pop rax
00007531fdbe0a7b  add rsp, 0x08
00007531fdbe0a7f  jmp 0x00007531FDBDF03A
00007531fdbe0a84  sub rsp, 0x08
00007531fdbe0a88  push rax
00007531fdbe0a89  push rcx
00007531fdbe0a8a  push rdx
00007531fdbe0a8b  push rdi
00007531fdbe0a8c  push rsi
00007531fdbe0a8d  push r8
00007531fdbe0a8f  push r9
00007531fdbe0a91  push r10
00007531fdbe0a93  push r11
00007531fdbe0a95  sub rsp, 0xF0
00007531fdbe0a9c  vmovaps [rsp], xmm0
00007531fdbe0aa1  vmovaps [rsp+0x10], xmm1
00007531fdbe0aa7  vmovaps [rsp+0x20], xmm2
00007531fdbe0aad  vmovaps [rsp+0x30], xmm3
00007531fdbe0ab3  vmovaps [rsp+0x40], xmm4
00007531fdbe0ab9  vmovaps [rsp+0x50], xmm5
00007531fdbe0abf  vmovaps [rsp+0x60], xmm6
00007531fdbe0ac5  vmovaps [rsp+0x70], xmm8
00007531fdbe0acb  vmovaps [rsp+0x80], xmm9
00007531fdbe0ad4  vmovaps [rsp+0x90], xmm10
00007531fdbe0add  vmovaps [rsp+0xA0], xmm11
00007531fdbe0ae6  vmovaps [rsp+0xB0], xmm12
00007531fdbe0aef  vmovaps [rsp+0xC0], xmm13
00007531fdbe0af8  vmovaps [rsp+0xD0], xmm14
00007531fdbe0b01  vmovaps [rsp+0xE0], xmm15
00007531fdbe0b0a  sub rsp, 0x30
00007531fdbe0b0e  movaps [rsp], xmm7
00007531fdbe0b12  movaps [rsp+0x10], xmm4
00007531fdbe0b17  movaps [rsp+0x20], xmm9
00007531fdbe0b1d  lea rdi, [rsp]
00007531fdbe0b21  mov esi, 0x00
00007531fdbe0b26  mov rax, 0x59ED111DF530
00007531fdbe0b30  call rax
00007531fdbe0b32  movaps xmm7, [rsp]
00007531fdbe0b36  add rsp, 0x30
00007531fdbe0b3a  vmovaps xmm0, [rsp]
00007531fdbe0b3f  vmovaps xmm1, [rsp+0x10]
00007531fdbe0b45  vmovaps xmm2, [rsp+0x20]
00007531fdbe0b4b  vmovaps xmm3, [rsp+0x30]
00007531fdbe0b51  vmovaps xmm4, [rsp+0x40]
00007531fdbe0b57  vmovaps xmm5, [rsp+0x50]
00007531fdbe0b5d  vmovaps xmm6, [rsp+0x60]
00007531fdbe0b63  vmovaps xmm8, [rsp+0x70]
00007531fdbe0b69  vmovaps xmm9, [rsp+0x80]
00007531fdbe0b72  vmovaps xmm10, [rsp+0x90]
00007531fdbe0b7b  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0b84  vmovaps xmm12, [rsp+0xB0]
00007531fdbe0b8d  vmovaps xmm13, [rsp+0xC0]
00007531fdbe0b96  vmovaps xmm14, [rsp+0xD0]
00007531fdbe0b9f  vmovaps xmm15, [rsp+0xE0]
00007531fdbe0ba8  add rsp, 0xF0
00007531fdbe0baf  pop r11
00007531fdbe0bb1  pop r10
00007531fdbe0bb3  pop r9
00007531fdbe0bb5  pop r8
00007531fdbe0bb7  pop rsi
00007531fdbe0bb8  pop rdi
00007531fdbe0bb9  pop rdx
00007531fdbe0bba  pop rcx
00007531fdbe0bbb  pop rax
00007531fdbe0bbc  add rsp, 0x08
00007531fdbe0bc0  jmp 0x00007531FDBDF067
00007531fdbe0bc5  sub rsp, 0x08
00007531fdbe0bc9  push rax
00007531fdbe0bca  push rcx
00007531fdbe0bcb  push rdx
00007531fdbe0bcc  push rdi
00007531fdbe0bcd  push rsi
00007531fdbe0bce  push r8
00007531fdbe0bd0  push r9
00007531fdbe0bd2  push r10
00007531fdbe0bd4  push r11
00007531fdbe0bd6  sub rsp, 0xF0
00007531fdbe0bdd  vmovaps [rsp], xmm0
00007531fdbe0be2  vmovaps [rsp+0x10], xmm1
00007531fdbe0be8  vmovaps [rsp+0x20], xmm2
00007531fdbe0bee  vmovaps [rsp+0x30], xmm3
00007531fdbe0bf4  vmovaps [rsp+0x40], xmm5
00007531fdbe0bfa  vmovaps [rsp+0x50], xmm6
00007531fdbe0c00  vmovaps [rsp+0x60], xmm7
00007531fdbe0c06  vmovaps [rsp+0x70], xmm8
00007531fdbe0c0c  vmovaps [rsp+0x80], xmm9
00007531fdbe0c15  vmovaps [rsp+0x90], xmm10
00007531fdbe0c1e  vmovaps [rsp+0xA0], xmm11
00007531fdbe0c27  vmovaps [rsp+0xB0], xmm12
00007531fdbe0c30  vmovaps [rsp+0xC0], xmm13
00007531fdbe0c39  vmovaps [rsp+0xD0], xmm14
00007531fdbe0c42  vmovaps [rsp+0xE0], xmm15
00007531fdbe0c4b  sub rsp, 0x30
00007531fdbe0c4f  movaps [rsp], xmm4
00007531fdbe0c53  movaps [rsp+0x10], xmm15
00007531fdbe0c59  movaps [rsp+0x20], xmm9
00007531fdbe0c5f  lea rdi, [rsp]
00007531fdbe0c63  mov esi, 0x00
00007531fdbe0c68  mov rax, 0x59ED111DF530
00007531fdbe0c72  call rax
00007531fdbe0c74  movaps xmm4, [rsp]
00007531fdbe0c78  add rsp, 0x30
00007531fdbe0c7c  vmovaps xmm0, [rsp]
00007531fdbe0c81  vmovaps xmm1, [rsp+0x10]
00007531fdbe0c87  vmovaps xmm2, [rsp+0x20]
00007531fdbe0c8d  vmovaps xmm3, [rsp+0x30]
00007531fdbe0c93  vmovaps xmm5, [rsp+0x40]
00007531fdbe0c99  vmovaps xmm6, [rsp+0x50]
00007531fdbe0c9f  vmovaps xmm7, [rsp+0x60]
00007531fdbe0ca5  vmovaps xmm8, [rsp+0x70]
00007531fdbe0cab  vmovaps xmm9, [rsp+0x80]
00007531fdbe0cb4  vmovaps xmm10, [rsp+0x90]
00007531fdbe0cbd  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0cc6  vmovaps xmm12, [rsp+0xB0]
00007531fdbe0ccf  vmovaps xmm13, [rsp+0xC0]
00007531fdbe0cd8  vmovaps xmm14, [rsp+0xD0]
00007531fdbe0ce1  vmovaps xmm15, [rsp+0xE0]
00007531fdbe0cea  add rsp, 0xF0
00007531fdbe0cf1  pop r11
00007531fdbe0cf3  pop r10
00007531fdbe0cf5  pop r9
00007531fdbe0cf7  pop r8
00007531fdbe0cf9  pop rsi
00007531fdbe0cfa  pop rdi
00007531fdbe0cfb  pop rdx
00007531fdbe0cfc  pop rcx
00007531fdbe0cfd  pop rax
00007531fdbe0cfe  add rsp, 0x08
00007531fdbe0d02  jmp 0x00007531FDBDF08C
00007531fdbe0d07  call 0x00007531FDAC4620
00007531fdbe0d0c  jmp 0x00007531FDBDF099
00007531fdbe0d11  sub rsp, 0x08
00007531fdbe0d15  push rax
00007531fdbe0d16  push rcx
00007531fdbe0d17  push rdx
00007531fdbe0d18  push rdi
00007531fdbe0d19  push rsi
00007531fdbe0d1a  push r8
00007531fdbe0d1c  push r9
00007531fdbe0d1e  push r10
00007531fdbe0d20  push r11
00007531fdbe0d22  sub rsp, 0xF0
00007531fdbe0d29  vmovaps [rsp], xmm0
00007531fdbe0d2e  vmovaps [rsp+0x10], xmm1
00007531fdbe0d34  vmovaps [rsp+0x20], xmm2
00007531fdbe0d3a  vmovaps [rsp+0x30], xmm4
00007531fdbe0d40  vmovaps [rsp+0x40], xmm5
00007531fdbe0d46  vmovaps [rsp+0x50], xmm6
00007531fdbe0d4c  vmovaps [rsp+0x60], xmm7
00007531fdbe0d52  vmovaps [rsp+0x70], xmm8
00007531fdbe0d58  vmovaps [rsp+0x80], xmm9
00007531fdbe0d61  vmovaps [rsp+0x90], xmm10
00007531fdbe0d6a  vmovaps [rsp+0xA0], xmm11
00007531fdbe0d73  vmovaps [rsp+0xB0], xmm12
00007531fdbe0d7c  vmovaps [rsp+0xC0], xmm13
00007531fdbe0d85  vmovaps [rsp+0xD0], xmm14
00007531fdbe0d8e  vmovaps [rsp+0xE0], xmm15
00007531fdbe0d97  sub rsp, 0x30
00007531fdbe0d9b  movaps [rsp], xmm3
00007531fdbe0d9f  movaps [rsp+0x10], xmm1
00007531fdbe0da4  movaps [rsp+0x20], xmm9
00007531fdbe0daa  lea rdi, [rsp]
00007531fdbe0dae  mov esi, 0x00
00007531fdbe0db3  mov rax, 0x59ED111DF530
00007531fdbe0dbd  call rax
00007531fdbe0dbf  movaps xmm3, [rsp]
00007531fdbe0dc3  add rsp, 0x30
00007531fdbe0dc7  vmovaps xmm0, [rsp]
00007531fdbe0dcc  vmovaps xmm1, [rsp+0x10]
00007531fdbe0dd2  vmovaps xmm2, [rsp+0x20]
00007531fdbe0dd8  vmovaps xmm4, [rsp+0x30]
00007531fdbe0dde  vmovaps xmm5, [rsp+0x40]
00007531fdbe0de4  vmovaps xmm6, [rsp+0x50]
00007531fdbe0dea  vmovaps xmm7, [rsp+0x60]
00007531fdbe0df0  vmovaps xmm8, [rsp+0x70]
00007531fdbe0df6  vmovaps xmm9, [rsp+0x80]
00007531fdbe0dff  vmovaps xmm10, [rsp+0x90]
00007531fdbe0e08  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0e11  vmovaps xmm12, [rsp+0xB0]
00007531fdbe0e1a  vmovaps xmm13, [rsp+0xC0]
00007531fdbe0e23  vmovaps xmm14, [rsp+0xD0]
00007531fdbe0e2c  vmovaps xmm15, [rsp+0xE0]
00007531fdbe0e35  add rsp, 0xF0
00007531fdbe0e3c  pop r11
00007531fdbe0e3e  pop r10
00007531fdbe0e40  pop r9
00007531fdbe0e42  pop r8
00007531fdbe0e44  pop rsi
00007531fdbe0e45  pop rdi
00007531fdbe0e46  pop rdx
00007531fdbe0e47  pop rcx
00007531fdbe0e48  pop rax
00007531fdbe0e49  add rsp, 0x08
00007531fdbe0e4d  jmp 0x00007531FDBDF0D6
00007531fdbe0e52  sub rsp, 0x08
00007531fdbe0e56  push rax
00007531fdbe0e57  push rcx
00007531fdbe0e58  push rdx
00007531fdbe0e59  push rdi
00007531fdbe0e5a  push rsi
00007531fdbe0e5b  push r8
00007531fdbe0e5d  push r9
00007531fdbe0e5f  push r10
00007531fdbe0e61  push r11
00007531fdbe0e63  sub rsp, 0xF0
00007531fdbe0e6a  vmovaps [rsp], xmm0
00007531fdbe0e6f  vmovaps [rsp+0x10], xmm2
00007531fdbe0e75  vmovaps [rsp+0x20], xmm3
00007531fdbe0e7b  vmovaps [rsp+0x30], xmm4
00007531fdbe0e81  vmovaps [rsp+0x40], xmm5
00007531fdbe0e87  vmovaps [rsp+0x50], xmm6
00007531fdbe0e8d  vmovaps [rsp+0x60], xmm7
00007531fdbe0e93  vmovaps [rsp+0x70], xmm8
00007531fdbe0e99  vmovaps [rsp+0x80], xmm9
00007531fdbe0ea2  vmovaps [rsp+0x90], xmm10
00007531fdbe0eab  vmovaps [rsp+0xA0], xmm11
00007531fdbe0eb4  vmovaps [rsp+0xB0], xmm12
00007531fdbe0ebd  vmovaps [rsp+0xC0], xmm13
00007531fdbe0ec6  vmovaps [rsp+0xD0], xmm14
00007531fdbe0ecf  vmovaps [rsp+0xE0], xmm15
00007531fdbe0ed8  sub rsp, 0x30
00007531fdbe0edc  movaps [rsp], xmm1
00007531fdbe0ee0  movaps [rsp+0x10], xmm15
00007531fdbe0ee6  movaps [rsp+0x20], xmm9
00007531fdbe0eec  lea rdi, [rsp]
00007531fdbe0ef0  mov esi, 0x00
00007531fdbe0ef5  mov rax, 0x59ED111DF530
00007531fdbe0eff  call rax
00007531fdbe0f01  movaps xmm1, [rsp]
00007531fdbe0f05  add rsp, 0x30
00007531fdbe0f09  vmovaps xmm0, [rsp]
00007531fdbe0f0e  vmovaps xmm2, [rsp+0x10]
00007531fdbe0f14  vmovaps xmm3, [rsp+0x20]
00007531fdbe0f1a  vmovaps xmm4, [rsp+0x30]
00007531fdbe0f20  vmovaps xmm5, [rsp+0x40]
00007531fdbe0f26  vmovaps xmm6, [rsp+0x50]
00007531fdbe0f2c  vmovaps xmm7, [rsp+0x60]
00007531fdbe0f32  vmovaps xmm8, [rsp+0x70]
00007531fdbe0f38  vmovaps xmm9, [rsp+0x80]
00007531fdbe0f41  vmovaps xmm10, [rsp+0x90]
00007531fdbe0f4a  vmovaps xmm11, [rsp+0xA0]
00007531fdbe0f53  vmovaps xmm12, [rsp+0xB0]
00007531fdbe0f5c  vmovaps xmm13, [rsp+0xC0]
00007531fdbe0f65  vmovaps xmm14, [rsp+0xD0]
00007531fdbe0f6e  vmovaps xmm15, [rsp+0xE0]
00007531fdbe0f77  add rsp, 0xF0
00007531fdbe0f7e  pop r11
00007531fdbe0f80  pop r10
00007531fdbe0f82  pop r9
00007531fdbe0f84  pop r8
00007531fdbe0f86  pop rsi
00007531fdbe0f87  pop rdi
00007531fdbe0f88  pop rdx
00007531fdbe0f89  pop rcx
00007531fdbe0f8a  pop rax
00007531fdbe0f8b  add rsp, 0x08
00007531fdbe0f8f  jmp 0x00007531FDBDF15E
00007531fdbe0f94  call 0x00007531FDAC4620
00007531fdbe0f99  jmp 0x00007531FDBDF16B
00007531fdbe0f9e  sub rsp, 0x08
00007531fdbe0fa2  push rax
00007531fdbe0fa3  push rcx
00007531fdbe0fa4  push rdx
00007531fdbe0fa5  push rdi
00007531fdbe0fa6  push rsi
00007531fdbe0fa7  push r8
00007531fdbe0fa9  push r9
00007531fdbe0fab  push r10
00007531fdbe0fad  push r11
00007531fdbe0faf  sub rsp, 0xF0
00007531fdbe0fb6  vmovaps [rsp], xmm0
00007531fdbe0fbb  vmovaps [rsp+0x10], xmm2
00007531fdbe0fc1  vmovaps [rsp+0x20], xmm3
00007531fdbe0fc7  vmovaps [rsp+0x30], xmm4
00007531fdbe0fcd  vmovaps [rsp+0x40], xmm5
00007531fdbe0fd3  vmovaps [rsp+0x50], xmm6
00007531fdbe0fd9  vmovaps [rsp+0x60], xmm7
00007531fdbe0fdf  vmovaps [rsp+0x70], xmm8
00007531fdbe0fe5  vmovaps [rsp+0x80], xmm9
00007531fdbe0fee  vmovaps [rsp+0x90], xmm10
00007531fdbe0ff7  vmovaps [rsp+0xA0], xmm11
00007531fdbe1000  vmovaps [rsp+0xB0], xmm12
00007531fdbe1009  vmovaps [rsp+0xC0], xmm13
00007531fdbe1012  vmovaps [rsp+0xD0], xmm14
00007531fdbe101b  vmovaps [rsp+0xE0], xmm15
00007531fdbe1024  sub rsp, 0x30
00007531fdbe1028  movaps [rsp], xmm1
00007531fdbe102c  movaps [rsp+0x10], xmm5
00007531fdbe1031  movaps [rsp+0x20], xmm7
00007531fdbe1036  lea rdi, [rsp]
00007531fdbe103a  mov esi, 0x00
00007531fdbe103f  mov rax, 0x59ED111DF530
00007531fdbe1049  call rax
00007531fdbe104b  movaps xmm1, [rsp]
00007531fdbe104f  add rsp, 0x30
00007531fdbe1053  vmovaps xmm0, [rsp]
00007531fdbe1058  vmovaps xmm2, [rsp+0x10]
00007531fdbe105e  vmovaps xmm3, [rsp+0x20]
00007531fdbe1064  vmovaps xmm4, [rsp+0x30]
00007531fdbe106a  vmovaps xmm5, [rsp+0x40]
00007531fdbe1070  vmovaps xmm6, [rsp+0x50]
00007531fdbe1076  vmovaps xmm7, [rsp+0x60]
00007531fdbe107c  vmovaps xmm8, [rsp+0x70]
00007531fdbe1082  vmovaps xmm9, [rsp+0x80]
00007531fdbe108b  vmovaps xmm10, [rsp+0x90]
00007531fdbe1094  vmovaps xmm11, [rsp+0xA0]
00007531fdbe109d  vmovaps xmm12, [rsp+0xB0]
00007531fdbe10a6  vmovaps xmm13, [rsp+0xC0]
00007531fdbe10af  vmovaps xmm14, [rsp+0xD0]
00007531fdbe10b8  vmovaps xmm15, [rsp+0xE0]
00007531fdbe10c1  add rsp, 0xF0
00007531fdbe10c8  pop r11
00007531fdbe10ca  pop r10
00007531fdbe10cc  pop r9
00007531fdbe10ce  pop r8
00007531fdbe10d0  pop rsi
00007531fdbe10d1  pop rdi
00007531fdbe10d2  pop rdx
00007531fdbe10d3  pop rcx
00007531fdbe10d4  pop rax
00007531fdbe10d5  add rsp, 0x08
00007531fdbe10d9  jmp 0x00007531FDBDF210
00007531fdbe10de  sub rsp, 0x08
00007531fdbe10e2  push rax
00007531fdbe10e3  push rcx
00007531fdbe10e4  push rdx
00007531fdbe10e5  push rdi
00007531fdbe10e6  push rsi
00007531fdbe10e7  push r8
00007531fdbe10e9  push r9
00007531fdbe10eb  push r10
00007531fdbe10ed  push r11
00007531fdbe10ef  sub rsp, 0xF0
00007531fdbe10f6  vmovaps [rsp], xmm0
00007531fdbe10fb  vmovaps [rsp+0x10], xmm1
00007531fdbe1101  vmovaps [rsp+0x20], xmm2
00007531fdbe1107  vmovaps [rsp+0x30], xmm3
00007531fdbe110d  vmovaps [rsp+0x40], xmm4
00007531fdbe1113  vmovaps [rsp+0x50], xmm5
00007531fdbe1119  vmovaps [rsp+0x60], xmm6
00007531fdbe111f  vmovaps [rsp+0x70], xmm8
00007531fdbe1125  vmovaps [rsp+0x80], xmm9
00007531fdbe112e  vmovaps [rsp+0x90], xmm10
00007531fdbe1137  vmovaps [rsp+0xA0], xmm11
00007531fdbe1140  vmovaps [rsp+0xB0], xmm12
00007531fdbe1149  vmovaps [rsp+0xC0], xmm13
00007531fdbe1152  vmovaps [rsp+0xD0], xmm14
00007531fdbe115b  vmovaps [rsp+0xE0], xmm15
00007531fdbe1164  sub rsp, 0x30
00007531fdbe1168  movaps [rsp], xmm7
00007531fdbe116c  movaps [rsp+0x10], xmm5
00007531fdbe1171  movaps [rsp+0x20], xmm15
00007531fdbe1177  lea rdi, [rsp]
00007531fdbe117b  mov esi, 0x00
00007531fdbe1180  mov rax, 0x59ED111DF530
00007531fdbe118a  call rax
00007531fdbe118c  movaps xmm7, [rsp]
00007531fdbe1190  add rsp, 0x30
00007531fdbe1194  vmovaps xmm0, [rsp]
00007531fdbe1199  vmovaps xmm1, [rsp+0x10]
00007531fdbe119f  vmovaps xmm2, [rsp+0x20]
00007531fdbe11a5  vmovaps xmm3, [rsp+0x30]
00007531fdbe11ab  vmovaps xmm4, [rsp+0x40]
00007531fdbe11b1  vmovaps xmm5, [rsp+0x50]
00007531fdbe11b7  vmovaps xmm6, [rsp+0x60]
00007531fdbe11bd  vmovaps xmm8, [rsp+0x70]
00007531fdbe11c3  vmovaps xmm9, [rsp+0x80]
00007531fdbe11cc  vmovaps xmm10, [rsp+0x90]
00007531fdbe11d5  vmovaps xmm11, [rsp+0xA0]
00007531fdbe11de  vmovaps xmm12, [rsp+0xB0]
00007531fdbe11e7  vmovaps xmm13, [rsp+0xC0]
00007531fdbe11f0  vmovaps xmm14, [rsp+0xD0]
00007531fdbe11f9  vmovaps xmm15, [rsp+0xE0]
00007531fdbe1202  add rsp, 0xF0
00007531fdbe1209  pop r11
00007531fdbe120b  pop r10
00007531fdbe120d  pop r9
00007531fdbe120f  pop r8
00007531fdbe1211  pop rsi
00007531fdbe1212  pop rdi
00007531fdbe1213  pop rdx
00007531fdbe1214  pop rcx
00007531fdbe1215  pop rax
00007531fdbe1216  add rsp, 0x08
00007531fdbe121a  jmp 0x00007531FDBDF246
00007531fdbe121f  call 0x00007531FDAB52F0
00007531fdbe1224  jmp 0x00007531FDBDF253
00007531fdbe1229  sub rsp, 0x08
00007531fdbe122d  push rax
00007531fdbe122e  push rcx
00007531fdbe122f  push rdx
00007531fdbe1230  push rdi
00007531fdbe1231  push rsi
00007531fdbe1232  push r8
00007531fdbe1234  push r9
00007531fdbe1236  push r10
00007531fdbe1238  push r11
00007531fdbe123a  sub rsp, 0xF0
00007531fdbe1241  vmovaps [rsp], xmm0
00007531fdbe1246  vmovaps [rsp+0x10], xmm1
00007531fdbe124c  vmovaps [rsp+0x20], xmm2
00007531fdbe1252  vmovaps [rsp+0x30], xmm3
00007531fdbe1258  vmovaps [rsp+0x40], xmm4
00007531fdbe125e  vmovaps [rsp+0x50], xmm5
00007531fdbe1264  vmovaps [rsp+0x60], xmm6
00007531fdbe126a  vmovaps [rsp+0x70], xmm7
00007531fdbe1270  vmovaps [rsp+0x80], xmm8
00007531fdbe1279  vmovaps [rsp+0x90], xmm9
00007531fdbe1282  vmovaps [rsp+0xA0], xmm10
00007531fdbe128b  vmovaps [rsp+0xB0], xmm11
00007531fdbe1294  vmovaps [rsp+0xC0], xmm12
00007531fdbe129d  vmovaps [rsp+0xD0], xmm13
00007531fdbe12a6  vmovaps [rsp+0xE0], xmm14
00007531fdbe12af  sub rsp, 0x30
00007531fdbe12b3  movaps [rsp], xmm15
00007531fdbe12b8  movaps [rsp+0x10], xmm5
00007531fdbe12bd  movaps [rsp+0x20], xmm3
00007531fdbe12c2  lea rdi, [rsp]
00007531fdbe12c6  mov esi, 0x00
00007531fdbe12cb  mov rax, 0x59ED111DF530
00007531fdbe12d5  call rax
00007531fdbe12d7  movaps xmm15, [rsp]
00007531fdbe12dc  add rsp, 0x30
00007531fdbe12e0  vmovaps xmm0, [rsp]
00007531fdbe12e5  vmovaps xmm1, [rsp+0x10]
00007531fdbe12eb  vmovaps xmm2, [rsp+0x20]
00007531fdbe12f1  vmovaps xmm3, [rsp+0x30]
00007531fdbe12f7  vmovaps xmm4, [rsp+0x40]
00007531fdbe12fd  vmovaps xmm5, [rsp+0x50]
00007531fdbe1303  vmovaps xmm6, [rsp+0x60]
00007531fdbe1309  vmovaps xmm7, [rsp+0x70]
00007531fdbe130f  vmovaps xmm8, [rsp+0x80]
00007531fdbe1318  vmovaps xmm9, [rsp+0x90]
00007531fdbe1321  vmovaps xmm10, [rsp+0xA0]
00007531fdbe132a  vmovaps xmm11, [rsp+0xB0]
00007531fdbe1333  vmovaps xmm12, [rsp+0xC0]
00007531fdbe133c  vmovaps xmm13, [rsp+0xD0]
00007531fdbe1345  vmovaps xmm14, [rsp+0xE0]
00007531fdbe134e  add rsp, 0xF0
00007531fdbe1355  pop r11
00007531fdbe1357  pop r10
00007531fdbe1359  pop r9
00007531fdbe135b  pop r8
00007531fdbe135d  pop rsi
00007531fdbe135e  pop rdi
00007531fdbe135f  pop rdx
00007531fdbe1360  pop rcx
00007531fdbe1361  pop rax
00007531fdbe1362  add rsp, 0x08
00007531fdbe1366  jmp 0x00007531FDBDF279
00007531fdbe136b  sub rsp, 0x08
00007531fdbe136f  push rax
00007531fdbe1370  push rcx
00007531fdbe1371  push rdx
00007531fdbe1372  push rdi
00007531fdbe1373  push rsi
00007531fdbe1374  push r8
00007531fdbe1376  push r9
00007531fdbe1378  push r10
00007531fdbe137a  push r11
00007531fdbe137c  sub rsp, 0xF0
00007531fdbe1383  vmovaps [rsp], xmm0
00007531fdbe1388  vmovaps [rsp+0x10], xmm2
00007531fdbe138e  vmovaps [rsp+0x20], xmm3
00007531fdbe1394  vmovaps [rsp+0x30], xmm4
00007531fdbe139a  vmovaps [rsp+0x40], xmm5
00007531fdbe13a0  vmovaps [rsp+0x50], xmm6
00007531fdbe13a6  vmovaps [rsp+0x60], xmm7
00007531fdbe13ac  vmovaps [rsp+0x70], xmm8
00007531fdbe13b2  vmovaps [rsp+0x80], xmm9
00007531fdbe13bb  vmovaps [rsp+0x90], xmm10
00007531fdbe13c4  vmovaps [rsp+0xA0], xmm11
00007531fdbe13cd  vmovaps [rsp+0xB0], xmm12
00007531fdbe13d6  vmovaps [rsp+0xC0], xmm13
00007531fdbe13df  vmovaps [rsp+0xD0], xmm14
00007531fdbe13e8  vmovaps [rsp+0xE0], xmm15
00007531fdbe13f1  sub rsp, 0x30
00007531fdbe13f5  movaps [rsp], xmm1
00007531fdbe13f9  movaps [rsp+0x10], xmm5
00007531fdbe13fe  movaps [rsp+0x20], xmm4
00007531fdbe1403  lea rdi, [rsp]
00007531fdbe1407  mov esi, 0x00
00007531fdbe140c  mov rax, 0x59ED111DF530
00007531fdbe1416  call rax
00007531fdbe1418  movaps xmm1, [rsp]
00007531fdbe141c  add rsp, 0x30
00007531fdbe1420  vmovaps xmm0, [rsp]
00007531fdbe1425  vmovaps xmm2, [rsp+0x10]
00007531fdbe142b  vmovaps xmm3, [rsp+0x20]
00007531fdbe1431  vmovaps xmm4, [rsp+0x30]
00007531fdbe1437  vmovaps xmm5, [rsp+0x40]
00007531fdbe143d  vmovaps xmm6, [rsp+0x50]
00007531fdbe1443  vmovaps xmm7, [rsp+0x60]
00007531fdbe1449  vmovaps xmm8, [rsp+0x70]
00007531fdbe144f  vmovaps xmm9, [rsp+0x80]
00007531fdbe1458  vmovaps xmm10, [rsp+0x90]
00007531fdbe1461  vmovaps xmm11, [rsp+0xA0]
00007531fdbe146a  vmovaps xmm12, [rsp+0xB0]
00007531fdbe1473  vmovaps xmm13, [rsp+0xC0]
00007531fdbe147c  vmovaps xmm14, [rsp+0xD0]
00007531fdbe1485  vmovaps xmm15, [rsp+0xE0]
00007531fdbe148e  add rsp, 0xF0
00007531fdbe1495  pop r11
00007531fdbe1497  pop r10
00007531fdbe1499  pop r9
00007531fdbe149b  pop r8
00007531fdbe149d  pop rsi
00007531fdbe149e  pop rdi
00007531fdbe149f  pop rdx
00007531fdbe14a0  pop rcx
00007531fdbe14a1  pop rax
00007531fdbe14a2  add rsp, 0x08
00007531fdbe14a6  jmp 0x00007531FDBDF299
00007531fdbe14ab  sub rsp, 0x08
00007531fdbe14af  push rax
00007531fdbe14b0  push rcx
00007531fdbe14b1  push rdx
00007531fdbe14b2  push rdi
00007531fdbe14b3  push rsi
00007531fdbe14b4  push r8
00007531fdbe14b6  push r9
00007531fdbe14b8  push r10
00007531fdbe14ba  push r11
00007531fdbe14bc  sub rsp, 0xF0
00007531fdbe14c3  vmovaps [rsp], xmm0
00007531fdbe14c8  vmovaps [rsp+0x10], xmm1
00007531fdbe14ce  vmovaps [rsp+0x20], xmm2
00007531fdbe14d4  vmovaps [rsp+0x30], xmm3
00007531fdbe14da  vmovaps [rsp+0x40], xmm5
00007531fdbe14e0  vmovaps [rsp+0x50], xmm6
00007531fdbe14e6  vmovaps [rsp+0x60], xmm7
00007531fdbe14ec  vmovaps [rsp+0x70], xmm8
00007531fdbe14f2  vmovaps [rsp+0x80], xmm9
00007531fdbe14fb  vmovaps [rsp+0x90], xmm10
00007531fdbe1504  vmovaps [rsp+0xA0], xmm11
00007531fdbe150d  vmovaps [rsp+0xB0], xmm12
00007531fdbe1516  vmovaps [rsp+0xC0], xmm13
00007531fdbe151f  vmovaps [rsp+0xD0], xmm14
00007531fdbe1528  vmovaps [rsp+0xE0], xmm15
00007531fdbe1531  sub rsp, 0x30
00007531fdbe1535  movaps [rsp], xmm4
00007531fdbe1539  movaps [rsp+0x10], xmm3
00007531fdbe153e  movaps [rsp+0x20], xmm5
00007531fdbe1543  lea rdi, [rsp]
00007531fdbe1547  mov esi, 0x00
00007531fdbe154c  mov rax, 0x59ED111DF530
00007531fdbe1556  call rax
00007531fdbe1558  movaps xmm4, [rsp]
00007531fdbe155c  add rsp, 0x30
00007531fdbe1560  vmovaps xmm0, [rsp]
00007531fdbe1565  vmovaps xmm1, [rsp+0x10]
00007531fdbe156b  vmovaps xmm2, [rsp+0x20]
00007531fdbe1571  vmovaps xmm3, [rsp+0x30]
00007531fdbe1577  vmovaps xmm5, [rsp+0x40]
00007531fdbe157d  vmovaps xmm6, [rsp+0x50]
00007531fdbe1583  vmovaps xmm7, [rsp+0x60]
00007531fdbe1589  vmovaps xmm8, [rsp+0x70]
00007531fdbe158f  vmovaps xmm9, [rsp+0x80]
00007531fdbe1598  vmovaps xmm10, [rsp+0x90]
00007531fdbe15a1  vmovaps xmm11, [rsp+0xA0]
00007531fdbe15aa  vmovaps xmm12, [rsp+0xB0]
00007531fdbe15b3  vmovaps xmm13, [rsp+0xC0]
00007531fdbe15bc  vmovaps xmm14, [rsp+0xD0]
00007531fdbe15c5  vmovaps xmm15, [rsp+0xE0]
00007531fdbe15ce  add rsp, 0xF0
00007531fdbe15d5  pop r11
00007531fdbe15d7  pop r10
00007531fdbe15d9  pop r9
00007531fdbe15db  pop r8
00007531fdbe15dd  pop rsi
00007531fdbe15de  pop rdi
00007531fdbe15df  pop rdx
00007531fdbe15e0  pop rcx
00007531fdbe15e1  pop rax
00007531fdbe15e2  add rsp, 0x08
00007531fdbe15e6  jmp 0x00007531FDBDF2E7
00007531fdbe15eb  call 0x00007531FDAB52F0
00007531fdbe15f0  jmp 0x00007531FDBDF2F4
00007531fdbe15f5  sub rsp, 0x08
00007531fdbe15f9  push rax
00007531fdbe15fa  push rcx
00007531fdbe15fb  push rdx
00007531fdbe15fc  push rdi
00007531fdbe15fd  push rsi
00007531fdbe15fe  push r8
00007531fdbe1600  push r9
00007531fdbe1602  push r10
00007531fdbe1604  push r11
00007531fdbe1606  sub rsp, 0xF0
00007531fdbe160d  vmovaps [rsp], xmm0
00007531fdbe1612  vmovaps [rsp+0x10], xmm1
00007531fdbe1618  vmovaps [rsp+0x20], xmm2
00007531fdbe161e  vmovaps [rsp+0x30], xmm3
00007531fdbe1624  vmovaps [rsp+0x40], xmm4
00007531fdbe162a  vmovaps [rsp+0x50], xmm6
00007531fdbe1630  vmovaps [rsp+0x60], xmm7
00007531fdbe1636  vmovaps [rsp+0x70], xmm8
00007531fdbe163c  vmovaps [rsp+0x80], xmm9
00007531fdbe1645  vmovaps [rsp+0x90], xmm10
00007531fdbe164e  vmovaps [rsp+0xA0], xmm11
00007531fdbe1657  vmovaps [rsp+0xB0], xmm12
00007531fdbe1660  vmovaps [rsp+0xC0], xmm13
00007531fdbe1669  vmovaps [rsp+0xD0], xmm14
00007531fdbe1672  vmovaps [rsp+0xE0], xmm15
00007531fdbe167b  sub rsp, 0x30
00007531fdbe167f  movaps [rsp], xmm5
00007531fdbe1683  movaps [rsp+0x10], xmm6
00007531fdbe1688  movaps [rsp+0x20], xmm3
00007531fdbe168d  lea rdi, [rsp]
00007531fdbe1691  mov esi, 0x00
00007531fdbe1696  mov rax, 0x59ED111DF530
00007531fdbe16a0  call rax
00007531fdbe16a2  movaps xmm5, [rsp]
00007531fdbe16a6  add rsp, 0x30
00007531fdbe16aa  vmovaps xmm0, [rsp]
00007531fdbe16af  vmovaps xmm1, [rsp+0x10]
00007531fdbe16b5  vmovaps xmm2, [rsp+0x20]
00007531fdbe16bb  vmovaps xmm3, [rsp+0x30]
00007531fdbe16c1  vmovaps xmm4, [rsp+0x40]
00007531fdbe16c7  vmovaps xmm6, [rsp+0x50]
00007531fdbe16cd  vmovaps xmm7, [rsp+0x60]
00007531fdbe16d3  vmovaps xmm8, [rsp+0x70]
00007531fdbe16d9  vmovaps xmm9, [rsp+0x80]
00007531fdbe16e2  vmovaps xmm10, [rsp+0x90]
00007531fdbe16eb  vmovaps xmm11, [rsp+0xA0]
00007531fdbe16f4  vmovaps xmm12, [rsp+0xB0]
00007531fdbe16fd  vmovaps xmm13, [rsp+0xC0]
00007531fdbe1706  vmovaps xmm14, [rsp+0xD0]
00007531fdbe170f  vmovaps xmm15, [rsp+0xE0]
00007531fdbe1718  add rsp, 0xF0
00007531fdbe171f  pop r11
00007531fdbe1721  pop r10
00007531fdbe1723  pop r9
00007531fdbe1725  pop r8
00007531fdbe1727  pop rsi
00007531fdbe1728  pop rdi
00007531fdbe1729  pop rdx
00007531fdbe172a  pop rcx
00007531fdbe172b  pop rax
00007531fdbe172c  add rsp, 0x08
00007531fdbe1730  jmp 0x00007531FDBDF31A
00007531fdbe1735  sub rsp, 0x08
00007531fdbe1739  push rax
00007531fdbe173a  push rcx
00007531fdbe173b  push rdx
00007531fdbe173c  push rdi
00007531fdbe173d  push rsi
00007531fdbe173e  push r8
00007531fdbe1740  push r9
00007531fdbe1742  push r10
00007531fdbe1744  push r11
00007531fdbe1746  sub rsp, 0xF0
00007531fdbe174d  vmovaps [rsp], xmm0
00007531fdbe1752  vmovaps [rsp+0x10], xmm1
00007531fdbe1758  vmovaps [rsp+0x20], xmm2
00007531fdbe175e  vmovaps [rsp+0x30], xmm3
00007531fdbe1764  vmovaps [rsp+0x40], xmm4
00007531fdbe176a  vmovaps [rsp+0x50], xmm5
00007531fdbe1770  vmovaps [rsp+0x60], xmm7
00007531fdbe1776  vmovaps [rsp+0x70], xmm8
00007531fdbe177c  vmovaps [rsp+0x80], xmm9
00007531fdbe1785  vmovaps [rsp+0x90], xmm10
00007531fdbe178e  vmovaps [rsp+0xA0], xmm11
00007531fdbe1797  vmovaps [rsp+0xB0], xmm12
00007531fdbe17a0  vmovaps [rsp+0xC0], xmm13
00007531fdbe17a9  vmovaps [rsp+0xD0], xmm14
00007531fdbe17b2  vmovaps [rsp+0xE0], xmm15
00007531fdbe17bb  sub rsp, 0x30
00007531fdbe17bf  movaps [rsp], xmm6
00007531fdbe17c3  movaps [rsp+0x10], xmm9
00007531fdbe17c9  movaps [rsp+0x20], xmm1
00007531fdbe17ce  lea rdi, [rsp]
00007531fdbe17d2  mov esi, 0x00
00007531fdbe17d7  mov rax, 0x59ED111DF530
00007531fdbe17e1  call rax
00007531fdbe17e3  movaps xmm6, [rsp]
00007531fdbe17e7  add rsp, 0x30
00007531fdbe17eb  vmovaps xmm0, [rsp]
00007531fdbe17f0  vmovaps xmm1, [rsp+0x10]
00007531fdbe17f6  vmovaps xmm2, [rsp+0x20]
00007531fdbe17fc  vmovaps xmm3, [rsp+0x30]
00007531fdbe1802  vmovaps xmm4, [rsp+0x40]
00007531fdbe1808  vmovaps xmm5, [rsp+0x50]
00007531fdbe180e  vmovaps xmm7, [rsp+0x60]
00007531fdbe1814  vmovaps xmm8, [rsp+0x70]
00007531fdbe181a  vmovaps xmm9, [rsp+0x80]
00007531fdbe1823  vmovaps xmm10, [rsp+0x90]
00007531fdbe182c  vmovaps xmm11, [rsp+0xA0]
00007531fdbe1835  vmovaps xmm12, [rsp+0xB0]
00007531fdbe183e  vmovaps xmm13, [rsp+0xC0]
00007531fdbe1847  vmovaps xmm14, [rsp+0xD0]
00007531fdbe1850  vmovaps xmm15, [rsp+0xE0]
00007531fdbe1859  add rsp, 0xF0
00007531fdbe1860  pop r11
00007531fdbe1862  pop r10
00007531fdbe1864  pop r9
00007531fdbe1866  pop r8
00007531fdbe1868  pop rsi
00007531fdbe1869  pop rdi
00007531fdbe186a  pop rdx
00007531fdbe186b  pop rcx
00007531fdbe186c  pop rax
00007531fdbe186d  add rsp, 0x08
00007531fdbe1871  jmp 0x00007531FDBDF33E
00007531fdbe1876  sub rsp, 0x08
00007531fdbe187a  push rax
00007531fdbe187b  push rcx
00007531fdbe187c  push rdx
00007531fdbe187d  push rdi
00007531fdbe187e  push rsi
00007531fdbe187f  push r8
00007531fdbe1881  push r9
00007531fdbe1883  push r10
00007531fdbe1885  push r11
00007531fdbe1887  sub rsp, 0xF0
00007531fdbe188e  vmovaps [rsp], xmm0
00007531fdbe1893  vmovaps [rsp+0x10], xmm1
00007531fdbe1899  vmovaps [rsp+0x20], xmm2
00007531fdbe189f  vmovaps [rsp+0x30], xmm3
00007531fdbe18a5  vmovaps [rsp+0x40], xmm4
00007531fdbe18ab  vmovaps [rsp+0x50], xmm5
00007531fdbe18b1  vmovaps [rsp+0x60], xmm6
00007531fdbe18b7  vmovaps [rsp+0x70], xmm7
00007531fdbe18bd  vmovaps [rsp+0x80], xmm8
00007531fdbe18c6  vmovaps [rsp+0x90], xmm10
00007531fdbe18cf  vmovaps [rsp+0xA0], xmm11
00007531fdbe18d8  vmovaps [rsp+0xB0], xmm12
00007531fdbe18e1  vmovaps [rsp+0xC0], xmm13
00007531fdbe18ea  vmovaps [rsp+0xD0], xmm14
00007531fdbe18f3  vmovaps [rsp+0xE0], xmm15
00007531fdbe18fc  sub rsp, 0x30
00007531fdbe1900  movaps [rsp], xmm9
00007531fdbe1905  movaps [rsp+0x10], xmm3
00007531fdbe190a  movaps [rsp+0x20], xmm1
00007531fdbe190f  lea rdi, [rsp]
00007531fdbe1913  mov esi, 0x00
00007531fdbe1918  mov rax, 0x59ED111DF530
00007531fdbe1922  call rax
00007531fdbe1924  movaps xmm9, [rsp]
00007531fdbe1929  add rsp, 0x30
00007531fdbe192d  vmovaps xmm0, [rsp]
00007531fdbe1932  vmovaps xmm1, [rsp+0x10]
00007531fdbe1938  vmovaps xmm2, [rsp+0x20]
00007531fdbe193e  vmovaps xmm3, [rsp+0x30]
00007531fdbe1944  vmovaps xmm4, [rsp+0x40]
00007531fdbe194a  vmovaps xmm5, [rsp+0x50]
00007531fdbe1950  vmovaps xmm6, [rsp+0x60]
00007531fdbe1956  vmovaps xmm7, [rsp+0x70]
00007531fdbe195c  vmovaps xmm8, [rsp+0x80]
00007531fdbe1965  vmovaps xmm10, [rsp+0x90]
00007531fdbe196e  vmovaps xmm11, [rsp+0xA0]
00007531fdbe1977  vmovaps xmm12, [rsp+0xB0]
00007531fdbe1980  vmovaps xmm13, [rsp+0xC0]
00007531fdbe1989  vmovaps xmm14, [rsp+0xD0]
00007531fdbe1992  vmovaps xmm15, [rsp+0xE0]
00007531fdbe199b  add rsp, 0xF0
00007531fdbe19a2  pop r11
00007531fdbe19a4  pop r10
00007531fdbe19a6  pop r9
00007531fdbe19a8  pop r8
00007531fdbe19aa  pop rsi
00007531fdbe19ab  pop rdi
00007531fdbe19ac  pop rdx
00007531fdbe19ad  pop rcx
00007531fdbe19ae  pop rax
00007531fdbe19af  add rsp, 0x08
00007531fdbe19b3  jmp 0x00007531FDBDF38A
00007531fdbe19b8  call 0x00007531FDAB52F0
00007531fdbe19bd  jmp 0x00007531FDBDF397
00007531fdbe19c2  sub rsp, 0x08
00007531fdbe19c6  push rax
00007531fdbe19c7  push rcx
00007531fdbe19c8  push rdx
00007531fdbe19c9  push rdi
00007531fdbe19ca  push rsi
00007531fdbe19cb  push r8
00007531fdbe19cd  push r9
00007531fdbe19cf  push r10
00007531fdbe19d1  push r11
00007531fdbe19d3  sub rsp, 0xF0
00007531fdbe19da  vmovaps [rsp], xmm0
00007531fdbe19df  vmovaps [rsp+0x10], xmm1
00007531fdbe19e5  vmovaps [rsp+0x20], xmm2
00007531fdbe19eb  vmovaps [rsp+0x30], xmm3
00007531fdbe19f1  vmovaps [rsp+0x40], xmm4
00007531fdbe19f7  vmovaps [rsp+0x50], xmm5
00007531fdbe19fd  vmovaps [rsp+0x60], xmm6
00007531fdbe1a03  vmovaps [rsp+0x70], xmm7
00007531fdbe1a09  vmovaps [rsp+0x80], xmm8
00007531fdbe1a12  vmovaps [rsp+0x90], xmm9
00007531fdbe1a1b  vmovaps [rsp+0xA0], xmm10
00007531fdbe1a24  vmovaps [rsp+0xB0], xmm11
00007531fdbe1a2d  vmovaps [rsp+0xC0], xmm12
00007531fdbe1a36  vmovaps [rsp+0xD0], xmm13
00007531fdbe1a3f  vmovaps [rsp+0xE0], xmm14
00007531fdbe1a48  sub rsp, 0x30
00007531fdbe1a4c  movaps [rsp], xmm15
00007531fdbe1a51  movaps [rsp+0x10], xmm3
00007531fdbe1a56  movaps [rsp+0x20], xmm7
00007531fdbe1a5b  lea rdi, [rsp]
00007531fdbe1a5f  mov esi, 0x00
00007531fdbe1a64  mov rax, 0x59ED111DF530
00007531fdbe1a6e  call rax
00007531fdbe1a70  movaps xmm15, [rsp]
00007531fdbe1a75  add rsp, 0x30
00007531fdbe1a79  vmovaps xmm0, [rsp]
00007531fdbe1a7e  vmovaps xmm1, [rsp+0x10]
00007531fdbe1a84  vmovaps xmm2, [rsp+0x20]
00007531fdbe1a8a  vmovaps xmm3, [rsp+0x30]
00007531fdbe1a90  vmovaps xmm4, [rsp+0x40]
00007531fdbe1a96  vmovaps xmm5, [rsp+0x50]
00007531fdbe1a9c  vmovaps xmm6, [rsp+0x60]
00007531fdbe1aa2  vmovaps xmm7, [rsp+0x70]
00007531fdbe1aa8  vmovaps xmm8, [rsp+0x80]
00007531fdbe1ab1  vmovaps xmm9, [rsp+0x90]
00007531fdbe1aba  vmovaps xmm10, [rsp+0xA0]
00007531fdbe1ac3  vmovaps xmm11, [rsp+0xB0]
00007531fdbe1acc  vmovaps xmm12, [rsp+0xC0]
00007531fdbe1ad5  vmovaps xmm13, [rsp+0xD0]
00007531fdbe1ade  vmovaps xmm14, [rsp+0xE0]
00007531fdbe1ae7  add rsp, 0xF0
00007531fdbe1aee  pop r11
00007531fdbe1af0  pop r10
00007531fdbe1af2  pop r9
00007531fdbe1af4  pop r8
00007531fdbe1af6  pop rsi
00007531fdbe1af7  pop rdi
00007531fdbe1af8  pop rdx
00007531fdbe1af9  pop rcx
00007531fdbe1afa  pop rax
00007531fdbe1afb  add rsp, 0x08
00007531fdbe1aff  jmp 0x00007531FDBDF3C3
00007531fdbe1b04  sub rsp, 0x08
00007531fdbe1b08  push rax
00007531fdbe1b09  push rcx
00007531fdbe1b0a  push rdx
00007531fdbe1b0b  push rdi
00007531fdbe1b0c  push rsi
00007531fdbe1b0d  push r8
00007531fdbe1b0f  push r9
00007531fdbe1b11  push r10
00007531fdbe1b13  push r11
00007531fdbe1b15  sub rsp, 0xF0
00007531fdbe1b1c  vmovaps [rsp], xmm0
00007531fdbe1b21  vmovaps [rsp+0x10], xmm1
00007531fdbe1b27  vmovaps [rsp+0x20], xmm2
00007531fdbe1b2d  vmovaps [rsp+0x30], xmm4
00007531fdbe1b33  vmovaps [rsp+0x40], xmm5
00007531fdbe1b39  vmovaps [rsp+0x50], xmm6
00007531fdbe1b3f  vmovaps [rsp+0x60], xmm7
00007531fdbe1b45  vmovaps [rsp+0x70], xmm8
00007531fdbe1b4b  vmovaps [rsp+0x80], xmm9
00007531fdbe1b54  vmovaps [rsp+0x90], xmm10
00007531fdbe1b5d  vmovaps [rsp+0xA0], xmm11
00007531fdbe1b66  vmovaps [rsp+0xB0], xmm12
00007531fdbe1b6f  vmovaps [rsp+0xC0], xmm13
00007531fdbe1b78  vmovaps [rsp+0xD0], xmm14
00007531fdbe1b81  vmovaps [rsp+0xE0], xmm15
00007531fdbe1b8a  sub rsp, 0x30
00007531fdbe1b8e  movaps [rsp], xmm3
00007531fdbe1b92  movaps [rsp+0x10], xmm1
00007531fdbe1b97  movaps [rsp+0x20], xmm15
00007531fdbe1b9d  lea rdi, [rsp]
00007531fdbe1ba1  mov esi, 0x00
00007531fdbe1ba6  mov rax, 0x59ED111DF530
00007531fdbe1bb0  call rax
00007531fdbe1bb2  movaps xmm3, [rsp]
00007531fdbe1bb6  add rsp, 0x30
00007531fdbe1bba  vmovaps xmm0, [rsp]
00007531fdbe1bbf  vmovaps xmm1, [rsp+0x10]
00007531fdbe1bc5  vmovaps xmm2, [rsp+0x20]
00007531fdbe1bcb  vmovaps xmm4, [rsp+0x30]
00007531fdbe1bd1  vmovaps xmm5, [rsp+0x40]
00007531fdbe1bd7  vmovaps xmm6, [rsp+0x50]
00007531fdbe1bdd  vmovaps xmm7, [rsp+0x60]
00007531fdbe1be3  vmovaps xmm8, [rsp+0x70]
00007531fdbe1be9  vmovaps xmm9, [rsp+0x80]
00007531fdbe1bf2  vmovaps xmm10, [rsp+0x90]
00007531fdbe1bfb  vmovaps xmm11, [rsp+0xA0]
00007531fdbe1c04  vmovaps xmm12, [rsp+0xB0]
00007531fdbe1c0d  vmovaps xmm13, [rsp+0xC0]
00007531fdbe1c16  vmovaps xmm14, [rsp+0xD0]
00007531fdbe1c1f  vmovaps xmm15, [rsp+0xE0]
00007531fdbe1c28  add rsp, 0xF0
00007531fdbe1c2f  pop r11
00007531fdbe1c31  pop r10
00007531fdbe1c33  pop r9
00007531fdbe1c35  pop r8
00007531fdbe1c37  pop rsi
00007531fdbe1c38  pop rdi
00007531fdbe1c39  pop rdx
00007531fdbe1c3a  pop rcx
00007531fdbe1c3b  pop rax
00007531fdbe1c3c  add rsp, 0x08
00007531fdbe1c40  jmp 0x00007531FDBDF452
00007531fdbe1c45  call 0x00007531FDAB52F0
00007531fdbe1c4a  jmp 0x00007531FDBDF45C
00007531fdbe1c4f  sub rsp, 0x08
00007531fdbe1c53  push rax
00007531fdbe1c54  push rcx
00007531fdbe1c55  push rdx
00007531fdbe1c56  push rdi
00007531fdbe1c57  push rsi
00007531fdbe1c58  push r8
00007531fdbe1c5a  push r9
00007531fdbe1c5c  push r10
00007531fdbe1c5e  push r11
00007531fdbe1c60  sub rsp, 0xF0
00007531fdbe1c67  vmovaps [rsp], xmm0
00007531fdbe1c6c  vmovaps [rsp+0x10], xmm1
00007531fdbe1c72  vmovaps [rsp+0x20], xmm2
00007531fdbe1c78  vmovaps [rsp+0x30], xmm3
00007531fdbe1c7e  vmovaps [rsp+0x40], xmm4
00007531fdbe1c84  vmovaps [rsp+0x50], xmm5
00007531fdbe1c8a  vmovaps [rsp+0x60], xmm6
00007531fdbe1c90  vmovaps [rsp+0x70], xmm7
00007531fdbe1c96  vmovaps [rsp+0x80], xmm8
00007531fdbe1c9f  vmovaps [rsp+0x90], xmm9
00007531fdbe1ca8  vmovaps [rsp+0xA0], xmm10
00007531fdbe1cb1  vmovaps [rsp+0xB0], xmm11
00007531fdbe1cba  vmovaps [rsp+0xC0], xmm12
00007531fdbe1cc3  vmovaps [rsp+0xD0], xmm13
00007531fdbe1ccc  vmovaps [rsp+0xE0], xmm14
00007531fdbe1cd5  sub rsp, 0x30
00007531fdbe1cd9  movaps [rsp], xmm15
00007531fdbe1cde  movaps [rsp+0x10], xmm14
00007531fdbe1ce4  movaps [rsp+0x20], xmm4
00007531fdbe1ce9  lea rdi, [rsp]
00007531fdbe1ced  mov esi, 0x00
00007531fdbe1cf2  mov rax, 0x59ED111DF530
00007531fdbe1cfc  call rax
00007531fdbe1cfe  movaps xmm15, [rsp]
00007531fdbe1d03  add rsp, 0x30
00007531fdbe1d07  vmovaps xmm0, [rsp]
00007531fdbe1d0c  vmovaps xmm1, [rsp+0x10]
00007531fdbe1d12  vmovaps xmm2, [rsp+0x20]
00007531fdbe1d18  vmovaps xmm3, [rsp+0x30]
00007531fdbe1d1e  vmovaps xmm4, [rsp+0x40]
00007531fdbe1d24  vmovaps xmm5, [rsp+0x50]
00007531fdbe1d2a  vmovaps xmm6, [rsp+0x60]
00007531fdbe1d30  vmovaps xmm7, [rsp+0x70]
00007531fdbe1d36  vmovaps xmm8, [rsp+0x80]
00007531fdbe1d3f  vmovaps xmm9, [rsp+0x90]
00007531fdbe1d48  vmovaps xmm10, [rsp+0xA0]
00007531fdbe1d51  vmovaps xmm11, [rsp+0xB0]
00007531fdbe1d5a  vmovaps xmm12, [rsp+0xC0]
00007531fdbe1d63  vmovaps xmm13, [rsp+0xD0]
00007531fdbe1d6c  vmovaps xmm14, [rsp+0xE0]
00007531fdbe1d75  add rsp, 0xF0
00007531fdbe1d7c  pop r11
00007531fdbe1d7e  pop r10
00007531fdbe1d80  pop r9
00007531fdbe1d82  pop r8
00007531fdbe1d84  pop rsi
00007531fdbe1d85  pop rdi
00007531fdbe1d86  pop rdx
00007531fdbe1d87  pop rcx
00007531fdbe1d88  pop rax
00007531fdbe1d89  add rsp, 0x08
00007531fdbe1d8d  jmp 0x00007531FDBDF48A
00007531fdbe1d92  sub rsp, 0x08
00007531fdbe1d96  push rax
00007531fdbe1d97  push rcx
00007531fdbe1d98  push rdx
00007531fdbe1d99  push rdi
00007531fdbe1d9a  push rsi
00007531fdbe1d9b  push r8
00007531fdbe1d9d  push r9
00007531fdbe1d9f  push r10
00007531fdbe1da1  push r11
00007531fdbe1da3  sub rsp, 0xF0
00007531fdbe1daa  vmovaps [rsp], xmm0
00007531fdbe1daf  vmovaps [rsp+0x10], xmm1
00007531fdbe1db5  vmovaps [rsp+0x20], xmm2
00007531fdbe1dbb  vmovaps [rsp+0x30], xmm3
00007531fdbe1dc1  vmovaps [rsp+0x40], xmm4
00007531fdbe1dc7  vmovaps [rsp+0x50], xmm5
00007531fdbe1dcd  vmovaps [rsp+0x60], xmm6
00007531fdbe1dd3  vmovaps [rsp+0x70], xmm7
00007531fdbe1dd9  vmovaps [rsp+0x80], xmm8
00007531fdbe1de2  vmovaps [rsp+0x90], xmm9
00007531fdbe1deb  vmovaps [rsp+0xA0], xmm10
00007531fdbe1df4  vmovaps [rsp+0xB0], xmm11
00007531fdbe1dfd  vmovaps [rsp+0xC0], xmm12
00007531fdbe1e06  vmovaps [rsp+0xD0], xmm13
00007531fdbe1e0f  vmovaps [rsp+0xE0], xmm15
00007531fdbe1e18  sub rsp, 0x30
00007531fdbe1e1c  movaps [rsp], xmm14
00007531fdbe1e21  movaps [rsp+0x10], xmm2
00007531fdbe1e26  movaps [rsp+0x20], xmm1
00007531fdbe1e2b  lea rdi, [rsp]
00007531fdbe1e2f  mov esi, 0x00
00007531fdbe1e34  mov rax, 0x59ED111DF530
00007531fdbe1e3e  call rax
00007531fdbe1e40  movaps xmm14, [rsp]
00007531fdbe1e45  add rsp, 0x30
00007531fdbe1e49  vmovaps xmm0, [rsp]
00007531fdbe1e4e  vmovaps xmm1, [rsp+0x10]
00007531fdbe1e54  vmovaps xmm2, [rsp+0x20]
00007531fdbe1e5a  vmovaps xmm3, [rsp+0x30]
00007531fdbe1e60  vmovaps xmm4, [rsp+0x40]
00007531fdbe1e66  vmovaps xmm5, [rsp+0x50]
00007531fdbe1e6c  vmovaps xmm6, [rsp+0x60]
00007531fdbe1e72  vmovaps xmm7, [rsp+0x70]
00007531fdbe1e78  vmovaps xmm8, [rsp+0x80]
00007531fdbe1e81  vmovaps xmm9, [rsp+0x90]
00007531fdbe1e8a  vmovaps xmm10, [rsp+0xA0]
00007531fdbe1e93  vmovaps xmm11, [rsp+0xB0]
00007531fdbe1e9c  vmovaps xmm12, [rsp+0xC0]
00007531fdbe1ea5  vmovaps xmm13, [rsp+0xD0]
00007531fdbe1eae  vmovaps xmm15, [rsp+0xE0]
00007531fdbe1eb7  add rsp, 0xF0
00007531fdbe1ebe  pop r11
00007531fdbe1ec0  pop r10
00007531fdbe1ec2  pop r9
00007531fdbe1ec4  pop r8
00007531fdbe1ec6  pop rsi
00007531fdbe1ec7  pop rdi
00007531fdbe1ec8  pop rdx
00007531fdbe1ec9  pop rcx
00007531fdbe1eca  pop rax
00007531fdbe1ecb  add rsp, 0x08
00007531fdbe1ecf  jmp 0x00007531FDBDF4B0
00007531fdbe1ed4  sub rsp, 0x08
00007531fdbe1ed8  push rax
00007531fdbe1ed9  push rcx
00007531fdbe1eda  push rdx
00007531fdbe1edb  push rdi
00007531fdbe1edc  push rsi
00007531fdbe1edd  push r8
00007531fdbe1edf  push r9
00007531fdbe1ee1  push r10
00007531fdbe1ee3  push r11
00007531fdbe1ee5  sub rsp, 0xF0
00007531fdbe1eec  vmovaps [rsp], xmm0
00007531fdbe1ef1  vmovaps [rsp+0x10], xmm2
00007531fdbe1ef7  vmovaps [rsp+0x20], xmm3
00007531fdbe1efd  vmovaps [rsp+0x30], xmm4
00007531fdbe1f03  vmovaps [rsp+0x40], xmm5
00007531fdbe1f09  vmovaps [rsp+0x50], xmm6
00007531fdbe1f0f  vmovaps [rsp+0x60], xmm7
00007531fdbe1f15  vmovaps [rsp+0x70], xmm8
00007531fdbe1f1b  vmovaps [rsp+0x80], xmm9
00007531fdbe1f24  vmovaps [rsp+0x90], xmm10
00007531fdbe1f2d  vmovaps [rsp+0xA0], xmm11
00007531fdbe1f36  vmovaps [rsp+0xB0], xmm12
00007531fdbe1f3f  vmovaps [rsp+0xC0], xmm13
00007531fdbe1f48  vmovaps [rsp+0xD0], xmm14
00007531fdbe1f51  vmovaps [rsp+0xE0], xmm15
00007531fdbe1f5a  sub rsp, 0x30
00007531fdbe1f5e  movaps [rsp], xmm1
00007531fdbe1f62  movaps [rsp+0x10], xmm4
00007531fdbe1f67  movaps [rsp+0x20], xmm9
00007531fdbe1f6d  lea rdi, [rsp]
00007531fdbe1f71  mov esi, 0x00
00007531fdbe1f76  mov rax, 0x59ED111DF530
00007531fdbe1f80  call rax
00007531fdbe1f82  movaps xmm1, [rsp]
00007531fdbe1f86  add rsp, 0x30
00007531fdbe1f8a  vmovaps xmm0, [rsp]
00007531fdbe1f8f  vmovaps xmm2, [rsp+0x10]
00007531fdbe1f95  vmovaps xmm3, [rsp+0x20]
00007531fdbe1f9b  vmovaps xmm4, [rsp+0x30]
00007531fdbe1fa1  vmovaps xmm5, [rsp+0x40]
00007531fdbe1fa7  vmovaps xmm6, [rsp+0x50]
00007531fdbe1fad  vmovaps xmm7, [rsp+0x60]
00007531fdbe1fb3  vmovaps xmm8, [rsp+0x70]
00007531fdbe1fb9  vmovaps xmm9, [rsp+0x80]
00007531fdbe1fc2  vmovaps xmm10, [rsp+0x90]
00007531fdbe1fcb  vmovaps xmm11, [rsp+0xA0]
00007531fdbe1fd4  vmovaps xmm12, [rsp+0xB0]
00007531fdbe1fdd  vmovaps xmm13, [rsp+0xC0]
00007531fdbe1fe6  vmovaps xmm14, [rsp+0xD0]
00007531fdbe1fef  vmovaps xmm15, [rsp+0xE0]
00007531fdbe1ff8  add rsp, 0xF0
00007531fdbe1fff  pop r11
00007531fdbe2001  pop r10
00007531fdbe2003  pop r9
00007531fdbe2005  pop r8
00007531fdbe2007  pop rsi
00007531fdbe2008  pop rdi
00007531fdbe2009  pop rdx
00007531fdbe200a  pop rcx
00007531fdbe200b  pop rax
00007531fdbe200c  add rsp, 0x08
00007531fdbe2010  jmp 0x00007531FDBDF4CE
00007531fdbe2015  sub rsp, 0x08
00007531fdbe2019  push rax
00007531fdbe201a  push rcx
00007531fdbe201b  push rdx
00007531fdbe201c  push rdi
00007531fdbe201d  push rsi
00007531fdbe201e  push r8
00007531fdbe2020  push r9
00007531fdbe2022  push r10
00007531fdbe2024  push r11
00007531fdbe2026  sub rsp, 0xF0
00007531fdbe202d  vmovaps [rsp], xmm0
00007531fdbe2032  vmovaps [rsp+0x10], xmm1
00007531fdbe2038  vmovaps [rsp+0x20], xmm2
00007531fdbe203e  vmovaps [rsp+0x30], xmm3
00007531fdbe2044  vmovaps [rsp+0x40], xmm5
00007531fdbe204a  vmovaps [rsp+0x50], xmm6
00007531fdbe2050  vmovaps [rsp+0x60], xmm7
00007531fdbe2056  vmovaps [rsp+0x70], xmm8
00007531fdbe205c  vmovaps [rsp+0x80], xmm9
00007531fdbe2065  vmovaps [rsp+0x90], xmm10
00007531fdbe206e  vmovaps [rsp+0xA0], xmm11
00007531fdbe2077  vmovaps [rsp+0xB0], xmm12
00007531fdbe2080  vmovaps [rsp+0xC0], xmm13
00007531fdbe2089  vmovaps [rsp+0xD0], xmm14
00007531fdbe2092  vmovaps [rsp+0xE0], xmm15
00007531fdbe209b  sub rsp, 0x30
00007531fdbe209f  movaps [rsp], xmm4
00007531fdbe20a3  movaps [rsp+0x10], xmm2
00007531fdbe20a8  movaps [rsp+0x20], xmm9
00007531fdbe20ae  lea rdi, [rsp]
00007531fdbe20b2  mov esi, 0x00
00007531fdbe20b7  mov rax, 0x59ED111DF530
00007531fdbe20c1  call rax
00007531fdbe20c3  movaps xmm4, [rsp]
00007531fdbe20c7  add rsp, 0x30
00007531fdbe20cb  vmovaps xmm0, [rsp]
00007531fdbe20d0  vmovaps xmm1, [rsp+0x10]
00007531fdbe20d6  vmovaps xmm2, [rsp+0x20]
00007531fdbe20dc  vmovaps xmm3, [rsp+0x30]
00007531fdbe20e2  vmovaps xmm5, [rsp+0x40]
00007531fdbe20e8  vmovaps xmm6, [rsp+0x50]
00007531fdbe20ee  vmovaps xmm7, [rsp+0x60]
00007531fdbe20f4  vmovaps xmm8, [rsp+0x70]
00007531fdbe20fa  vmovaps xmm9, [rsp+0x80]
00007531fdbe2103  vmovaps xmm10, [rsp+0x90]
00007531fdbe210c  vmovaps xmm11, [rsp+0xA0]
00007531fdbe2115  vmovaps xmm12, [rsp+0xB0]
00007531fdbe211e  vmovaps xmm13, [rsp+0xC0]
00007531fdbe2127  vmovaps xmm14, [rsp+0xD0]
00007531fdbe2130  vmovaps xmm15, [rsp+0xE0]
00007531fdbe2139  add rsp, 0xF0
00007531fdbe2140  pop r11
00007531fdbe2142  pop r10
00007531fdbe2144  pop r9
00007531fdbe2146  pop r8
00007531fdbe2148  pop rsi
00007531fdbe2149  pop rdi
00007531fdbe214a  pop rdx
00007531fdbe214b  pop rcx
00007531fdbe214c  pop rax
00007531fdbe214d  add rsp, 0x08
00007531fdbe2151  jmp 0x00007531FDBDF4FE
00007531fdbe2156  sub rsp, 0x08
00007531fdbe215a  push rax
00007531fdbe215b  push rcx
00007531fdbe215c  push rdx
00007531fdbe215d  push rdi
00007531fdbe215e  push rsi
00007531fdbe215f  push r8
00007531fdbe2161  push r9
00007531fdbe2163  push r10
00007531fdbe2165  push r11
00007531fdbe2167  sub rsp, 0xF0
00007531fdbe216e  vmovaps [rsp], xmm0
00007531fdbe2173  vmovaps [rsp+0x10], xmm1
00007531fdbe2179  vmovaps [rsp+0x20], xmm2
00007531fdbe217f  vmovaps [rsp+0x30], xmm3
00007531fdbe2185  vmovaps [rsp+0x40], xmm4
00007531fdbe218b  vmovaps [rsp+0x50], xmm5
00007531fdbe2191  vmovaps [rsp+0x60], xmm6
00007531fdbe2197  vmovaps [rsp+0x70], xmm7
00007531fdbe219d  vmovaps [rsp+0x80], xmm8
00007531fdbe21a6  vmovaps [rsp+0x90], xmm10
00007531fdbe21af  vmovaps [rsp+0xA0], xmm11
00007531fdbe21b8  vmovaps [rsp+0xB0], xmm12
00007531fdbe21c1  vmovaps [rsp+0xC0], xmm13
00007531fdbe21ca  vmovaps [rsp+0xD0], xmm14
00007531fdbe21d3  vmovaps [rsp+0xE0], xmm15
00007531fdbe21dc  sub rsp, 0x30
00007531fdbe21e0  movaps [rsp], xmm9
00007531fdbe21e5  movaps [rsp+0x10], xmm2
00007531fdbe21ea  movaps [rsp+0x20], xmm1
00007531fdbe21ef  lea rdi, [rsp]
00007531fdbe21f3  mov esi, 0x00
00007531fdbe21f8  mov rax, 0x59ED111DF530
00007531fdbe2202  call rax
00007531fdbe2204  movaps xmm9, [rsp]
00007531fdbe2209  add rsp, 0x30
00007531fdbe220d  vmovaps xmm0, [rsp]
00007531fdbe2212  vmovaps xmm1, [rsp+0x10]
00007531fdbe2218  vmovaps xmm2, [rsp+0x20]
00007531fdbe221e  vmovaps xmm3, [rsp+0x30]
00007531fdbe2224  vmovaps xmm4, [rsp+0x40]
00007531fdbe222a  vmovaps xmm5, [rsp+0x50]
00007531fdbe2230  vmovaps xmm6, [rsp+0x60]
00007531fdbe2236  vmovaps xmm7, [rsp+0x70]
00007531fdbe223c  vmovaps xmm8, [rsp+0x80]
00007531fdbe2245  vmovaps xmm10, [rsp+0x90]
00007531fdbe224e  vmovaps xmm11, [rsp+0xA0]
00007531fdbe2257  vmovaps xmm12, [rsp+0xB0]
00007531fdbe2260  vmovaps xmm13, [rsp+0xC0]
00007531fdbe2269  vmovaps xmm14, [rsp+0xD0]
00007531fdbe2272  vmovaps xmm15, [rsp+0xE0]
00007531fdbe227b  add rsp, 0xF0
00007531fdbe2282  pop r11
00007531fdbe2284  pop r10
00007531fdbe2286  pop r9
00007531fdbe2288  pop r8
00007531fdbe228a  pop rsi
00007531fdbe228b  pop rdi
00007531fdbe228c  pop rdx
00007531fdbe228d  pop rcx
00007531fdbe228e  pop rax
00007531fdbe228f  add rsp, 0x08
00007531fdbe2293  jmp 0x00007531FDBDF534
00007531fdbe2298  sub rsp, 0x08
00007531fdbe229c  push rax
00007531fdbe229d  push rcx
00007531fdbe229e  push rdx
00007531fdbe229f  push rdi
00007531fdbe22a0  push rsi
00007531fdbe22a1  push r8
00007531fdbe22a3  push r9
00007531fdbe22a5  push r10
00007531fdbe22a7  push r11
00007531fdbe22a9  sub rsp, 0xF0
00007531fdbe22b0  vmovaps [rsp], xmm0
00007531fdbe22b5  vmovaps [rsp+0x10], xmm2
00007531fdbe22bb  vmovaps [rsp+0x20], xmm3
00007531fdbe22c1  vmovaps [rsp+0x30], xmm4
00007531fdbe22c7  vmovaps [rsp+0x40], xmm5
00007531fdbe22cd  vmovaps [rsp+0x50], xmm6
00007531fdbe22d3  vmovaps [rsp+0x60], xmm7
00007531fdbe22d9  vmovaps [rsp+0x70], xmm8
00007531fdbe22df  vmovaps [rsp+0x80], xmm9
00007531fdbe22e8  vmovaps [rsp+0x90], xmm10
00007531fdbe22f1  vmovaps [rsp+0xA0], xmm11
00007531fdbe22fa  vmovaps [rsp+0xB0], xmm12
00007531fdbe2303  vmovaps [rsp+0xC0], xmm13
00007531fdbe230c  vmovaps [rsp+0xD0], xmm14
00007531fdbe2315  vmovaps [rsp+0xE0], xmm15
00007531fdbe231e  sub rsp, 0x30
00007531fdbe2322  movaps [rsp], xmm1
00007531fdbe2326  movaps [rsp+0x10], xmm15
00007531fdbe232c  movaps [rsp+0x20], xmm6
00007531fdbe2331  lea rdi, [rsp]
00007531fdbe2335  mov esi, 0x00
00007531fdbe233a  mov rax, 0x59ED111DF530
00007531fdbe2344  call rax
00007531fdbe2346  movaps xmm1, [rsp]
00007531fdbe234a  add rsp, 0x30
00007531fdbe234e  vmovaps xmm0, [rsp]
00007531fdbe2353  vmovaps xmm2, [rsp+0x10]
00007531fdbe2359  vmovaps xmm3, [rsp+0x20]
00007531fdbe235f  vmovaps xmm4, [rsp+0x30]
00007531fdbe2365  vmovaps xmm5, [rsp+0x40]
00007531fdbe236b  vmovaps xmm6, [rsp+0x50]
00007531fdbe2371  vmovaps xmm7, [rsp+0x60]
00007531fdbe2377  vmovaps xmm8, [rsp+0x70]
00007531fdbe237d  vmovaps xmm9, [rsp+0x80]
00007531fdbe2386  vmovaps xmm10, [rsp+0x90]
00007531fdbe238f  vmovaps xmm11, [rsp+0xA0]
00007531fdbe2398  vmovaps xmm12, [rsp+0xB0]
00007531fdbe23a1  vmovaps xmm13, [rsp+0xC0]
00007531fdbe23aa  vmovaps xmm14, [rsp+0xD0]
00007531fdbe23b3  vmovaps xmm15, [rsp+0xE0]
00007531fdbe23bc  add rsp, 0xF0
00007531fdbe23c3  pop r11
00007531fdbe23c5  pop r10
00007531fdbe23c7  pop r9
00007531fdbe23c9  pop r8
00007531fdbe23cb  pop rsi
00007531fdbe23cc  pop rdi
00007531fdbe23cd  pop rdx
00007531fdbe23ce  pop rcx
00007531fdbe23cf  pop rax
00007531fdbe23d0  add rsp, 0x08
00007531fdbe23d4  jmp 0x00007531FDBDF555
00007531fdbe23d9  sub rsp, 0x08
00007531fdbe23dd  push rax
00007531fdbe23de  push rcx
00007531fdbe23df  push rdx
00007531fdbe23e0  push rdi
00007531fdbe23e1  push rsi
00007531fdbe23e2  push r8
00007531fdbe23e4  push r9
00007531fdbe23e6  push r10
00007531fdbe23e8  push r11
00007531fdbe23ea  sub rsp, 0xF0
00007531fdbe23f1  vmovaps [rsp], xmm0
00007531fdbe23f6  vmovaps [rsp+0x10], xmm1
00007531fdbe23fc  vmovaps [rsp+0x20], xmm2
00007531fdbe2402  vmovaps [rsp+0x30], xmm3
00007531fdbe2408  vmovaps [rsp+0x40], xmm4
00007531fdbe240e  vmovaps [rsp+0x50], xmm5
00007531fdbe2414  vmovaps [rsp+0x60], xmm6
00007531fdbe241a  vmovaps [rsp+0x70], xmm7
00007531fdbe2420  vmovaps [rsp+0x80], xmm8
00007531fdbe2429  vmovaps [rsp+0x90], xmm9
00007531fdbe2432  vmovaps [rsp+0xA0], xmm10
00007531fdbe243b  vmovaps [rsp+0xB0], xmm11
00007531fdbe2444  vmovaps [rsp+0xC0], xmm12
00007531fdbe244d  vmovaps [rsp+0xD0], xmm13
00007531fdbe2456  vmovaps [rsp+0xE0], xmm14
00007531fdbe245f  sub rsp, 0x30
00007531fdbe2463  movaps [rsp], xmm15
00007531fdbe2468  movaps [rsp+0x10], xmm5
00007531fdbe246d  movaps [rsp+0x20], xmm3
00007531fdbe2472  lea rdi, [rsp]
00007531fdbe2476  mov esi, 0x00
00007531fdbe247b  mov rax, 0x59ED111DF530
00007531fdbe2485  call rax
00007531fdbe2487  movaps xmm15, [rsp]
00007531fdbe248c  add rsp, 0x30
00007531fdbe2490  vmovaps xmm0, [rsp]
00007531fdbe2495  vmovaps xmm1, [rsp+0x10]
00007531fdbe249b  vmovaps xmm2, [rsp+0x20]
00007531fdbe24a1  vmovaps xmm3, [rsp+0x30]
00007531fdbe24a7  vmovaps xmm4, [rsp+0x40]
00007531fdbe24ad  vmovaps xmm5, [rsp+0x50]
00007531fdbe24b3  vmovaps xmm6, [rsp+0x60]
00007531fdbe24b9  vmovaps xmm7, [rsp+0x70]
00007531fdbe24bf  vmovaps xmm8, [rsp+0x80]
00007531fdbe24c8  vmovaps xmm9, [rsp+0x90]
00007531fdbe24d1  vmovaps xmm10, [rsp+0xA0]
00007531fdbe24da  vmovaps xmm11, [rsp+0xB0]
00007531fdbe24e3  vmovaps xmm12, [rsp+0xC0]
00007531fdbe24ec  vmovaps xmm13, [rsp+0xD0]
00007531fdbe24f5  vmovaps xmm14, [rsp+0xE0]
00007531fdbe24fe  add rsp, 0xF0
00007531fdbe2505  pop r11
00007531fdbe2507  pop r10
00007531fdbe2509  pop r9
00007531fdbe250b  pop r8
00007531fdbe250d  pop rsi
00007531fdbe250e  pop rdi
00007531fdbe250f  pop rdx
00007531fdbe2510  pop rcx
00007531fdbe2511  pop rax
00007531fdbe2512  add rsp, 0x08
00007531fdbe2516  jmp 0x00007531FDBDF56F
00007531fdbe251b  sub rsp, 0x08
00007531fdbe251f  push rax
00007531fdbe2520  push rcx
00007531fdbe2521  push rdx
00007531fdbe2522  push rdi
00007531fdbe2523  push rsi
00007531fdbe2524  push r8
00007531fdbe2526  push r9
00007531fdbe2528  push r10
00007531fdbe252a  push r11
00007531fdbe252c  sub rsp, 0xF0
00007531fdbe2533  vmovaps [rsp], xmm0
00007531fdbe2538  vmovaps [rsp+0x10], xmm1
00007531fdbe253e  vmovaps [rsp+0x20], xmm2
00007531fdbe2544  vmovaps [rsp+0x30], xmm3
00007531fdbe254a  vmovaps [rsp+0x40], xmm4
00007531fdbe2550  vmovaps [rsp+0x50], xmm6
00007531fdbe2556  vmovaps [rsp+0x60], xmm7
00007531fdbe255c  vmovaps [rsp+0x70], xmm8
00007531fdbe2562  vmovaps [rsp+0x80], xmm9
00007531fdbe256b  vmovaps [rsp+0x90], xmm10
00007531fdbe2574  vmovaps [rsp+0xA0], xmm11
00007531fdbe257d  vmovaps [rsp+0xB0], xmm12
00007531fdbe2586  vmovaps [rsp+0xC0], xmm13
00007531fdbe258f  vmovaps [rsp+0xD0], xmm14
00007531fdbe2598  vmovaps [rsp+0xE0], xmm15
00007531fdbe25a1  sub rsp, 0x30
00007531fdbe25a5  movaps [rsp], xmm5
00007531fdbe25a9  movaps [rsp+0x10], xmm8
00007531fdbe25af  movaps [rsp+0x20], xmm6
00007531fdbe25b4  lea rdi, [rsp]
00007531fdbe25b8  mov esi, 0x00
00007531fdbe25bd  mov rax, 0x59ED111DF530
00007531fdbe25c7  call rax
00007531fdbe25c9  movaps xmm5, [rsp]
00007531fdbe25cd  add rsp, 0x30
00007531fdbe25d1  vmovaps xmm0, [rsp]
00007531fdbe25d6  vmovaps xmm1, [rsp+0x10]
00007531fdbe25dc  vmovaps xmm2, [rsp+0x20]
00007531fdbe25e2  vmovaps xmm3, [rsp+0x30]
00007531fdbe25e8  vmovaps xmm4, [rsp+0x40]
00007531fdbe25ee  vmovaps xmm6, [rsp+0x50]
00007531fdbe25f4  vmovaps xmm7, [rsp+0x60]
00007531fdbe25fa  vmovaps xmm8, [rsp+0x70]
00007531fdbe2600  vmovaps xmm9, [rsp+0x80]
00007531fdbe2609  vmovaps xmm10, [rsp+0x90]
00007531fdbe2612  vmovaps xmm11, [rsp+0xA0]
00007531fdbe261b  vmovaps xmm12, [rsp+0xB0]
00007531fdbe2624  vmovaps xmm13, [rsp+0xC0]
00007531fdbe262d  vmovaps xmm14, [rsp+0xD0]
00007531fdbe2636  vmovaps xmm15, [rsp+0xE0]
00007531fdbe263f  add rsp, 0xF0
00007531fdbe2646  pop r11
00007531fdbe2648  pop r10
00007531fdbe264a  pop r9
00007531fdbe264c  pop r8
00007531fdbe264e  pop rsi
00007531fdbe264f  pop rdi
00007531fdbe2650  pop rdx
00007531fdbe2651  pop rcx
00007531fdbe2652  pop rax
00007531fdbe2653  add rsp, 0x08
00007531fdbe2657  jmp 0x00007531FDBDF593
00007531fdbe265c  sub rsp, 0x08
00007531fdbe2660  push rax
00007531fdbe2661  push rcx
00007531fdbe2662  push rdx
00007531fdbe2663  push rdi
00007531fdbe2664  push rsi
00007531fdbe2665  push r8
00007531fdbe2667  push r9
00007531fdbe2669  push r10
00007531fdbe266b  push r11
00007531fdbe266d  sub rsp, 0xF0
00007531fdbe2674  vmovaps [rsp], xmm0
00007531fdbe2679  vmovaps [rsp+0x10], xmm1
00007531fdbe267f  vmovaps [rsp+0x20], xmm2
00007531fdbe2685  vmovaps [rsp+0x30], xmm3
00007531fdbe268b  vmovaps [rsp+0x40], xmm4
00007531fdbe2691  vmovaps [rsp+0x50], xmm5
00007531fdbe2697  vmovaps [rsp+0x60], xmm7
00007531fdbe269d  vmovaps [rsp+0x70], xmm8
00007531fdbe26a3  vmovaps [rsp+0x80], xmm9
00007531fdbe26ac  vmovaps [rsp+0x90], xmm10
00007531fdbe26b5  vmovaps [rsp+0xA0], xmm11
00007531fdbe26be  vmovaps [rsp+0xB0], xmm12
00007531fdbe26c7  vmovaps [rsp+0xC0], xmm13
00007531fdbe26d0  vmovaps [rsp+0xD0], xmm14
00007531fdbe26d9  vmovaps [rsp+0xE0], xmm15
00007531fdbe26e2  sub rsp, 0x30
00007531fdbe26e6  movaps [rsp], xmm6
00007531fdbe26ea  movaps [rsp+0x10], xmm10
00007531fdbe26f0  movaps [rsp+0x20], xmm8
00007531fdbe26f6  lea rdi, [rsp]
00007531fdbe26fa  mov esi, 0x00
00007531fdbe26ff  mov rax, 0x59ED111DF530
00007531fdbe2709  call rax
00007531fdbe270b  movaps xmm6, [rsp]
00007531fdbe270f  add rsp, 0x30
00007531fdbe2713  vmovaps xmm0, [rsp]
00007531fdbe2718  vmovaps xmm1, [rsp+0x10]
00007531fdbe271e  vmovaps xmm2, [rsp+0x20]
00007531fdbe2724  vmovaps xmm3, [rsp+0x30]
00007531fdbe272a  vmovaps xmm4, [rsp+0x40]
00007531fdbe2730  vmovaps xmm5, [rsp+0x50]
00007531fdbe2736  vmovaps xmm7, [rsp+0x60]
00007531fdbe273c  vmovaps xmm8, [rsp+0x70]
00007531fdbe2742  vmovaps xmm9, [rsp+0x80]
00007531fdbe274b  vmovaps xmm10, [rsp+0x90]
00007531fdbe2754  vmovaps xmm11, [rsp+0xA0]
00007531fdbe275d  vmovaps xmm12, [rsp+0xB0]
00007531fdbe2766  vmovaps xmm13, [rsp+0xC0]
00007531fdbe276f  vmovaps xmm14, [rsp+0xD0]
00007531fdbe2778  vmovaps xmm15, [rsp+0xE0]
00007531fdbe2781  add rsp, 0xF0
00007531fdbe2788  pop r11
00007531fdbe278a  pop r10
00007531fdbe278c  pop r9
00007531fdbe278e  pop r8
00007531fdbe2790  pop rsi
00007531fdbe2791  pop rdi
00007531fdbe2792  pop rdx
00007531fdbe2793  pop rcx
00007531fdbe2794  pop rax
00007531fdbe2795  add rsp, 0x08
00007531fdbe2799  jmp 0x00007531FDBDF5B8
00007531fdbe279e  sub rsp, 0x08
00007531fdbe27a2  push rax
00007531fdbe27a3  push rcx
00007531fdbe27a4  push rdx
00007531fdbe27a5  push rdi
00007531fdbe27a6  push rsi
00007531fdbe27a7  push r8
00007531fdbe27a9  push r9
00007531fdbe27ab  push r10
00007531fdbe27ad  push r11
00007531fdbe27af  sub rsp, 0xF0
00007531fdbe27b6  vmovaps [rsp], xmm0
00007531fdbe27bb  vmovaps [rsp+0x10], xmm1
00007531fdbe27c1  vmovaps [rsp+0x20], xmm2
00007531fdbe27c7  vmovaps [rsp+0x30], xmm3
00007531fdbe27cd  vmovaps [rsp+0x40], xmm4
00007531fdbe27d3  vmovaps [rsp+0x50], xmm5
00007531fdbe27d9  vmovaps [rsp+0x60], xmm6
00007531fdbe27df  vmovaps [rsp+0x70], xmm7
00007531fdbe27e5  vmovaps [rsp+0x80], xmm8
00007531fdbe27ee  vmovaps [rsp+0x90], xmm9
00007531fdbe27f7  vmovaps [rsp+0xA0], xmm11
00007531fdbe2800  vmovaps [rsp+0xB0], xmm12
00007531fdbe2809  vmovaps [rsp+0xC0], xmm13
00007531fdbe2812  vmovaps [rsp+0xD0], xmm14
00007531fdbe281b  vmovaps [rsp+0xE0], xmm15
00007531fdbe2824  sub rsp, 0x30
00007531fdbe2828  movaps [rsp], xmm10
00007531fdbe282d  movaps [rsp+0x10], xmm8
00007531fdbe2833  movaps [rsp+0x20], xmm14
00007531fdbe2839  lea rdi, [rsp]
00007531fdbe283d  mov esi, 0x00
00007531fdbe2842  mov rax, 0x59ED111DF530
00007531fdbe284c  call rax
00007531fdbe284e  movaps xmm10, [rsp]
00007531fdbe2853  add rsp, 0x30
00007531fdbe2857  vmovaps xmm0, [rsp]
00007531fdbe285c  vmovaps xmm1, [rsp+0x10]
00007531fdbe2862  vmovaps xmm2, [rsp+0x20]
00007531fdbe2868  vmovaps xmm3, [rsp+0x30]
00007531fdbe286e  vmovaps xmm4, [rsp+0x40]
00007531fdbe2874  vmovaps xmm5, [rsp+0x50]
00007531fdbe287a  vmovaps xmm6, [rsp+0x60]
00007531fdbe2880  vmovaps xmm7, [rsp+0x70]
00007531fdbe2886  vmovaps xmm8, [rsp+0x80]
00007531fdbe288f  vmovaps xmm9, [rsp+0x90]
00007531fdbe2898  vmovaps xmm11, [rsp+0xA0]
00007531fdbe28a1  vmovaps xmm12, [rsp+0xB0]
00007531fdbe28aa  vmovaps xmm13, [rsp+0xC0]
00007531fdbe28b3  vmovaps xmm14, [rsp+0xD0]
00007531fdbe28bc  vmovaps xmm15, [rsp+0xE0]
00007531fdbe28c5  add rsp, 0xF0
00007531fdbe28cc  pop r11
00007531fdbe28ce  pop r10
00007531fdbe28d0  pop r9
00007531fdbe28d2  pop r8
00007531fdbe28d4  pop rsi
00007531fdbe28d5  pop rdi
00007531fdbe28d6  pop rdx
00007531fdbe28d7  pop rcx
00007531fdbe28d8  pop rax
00007531fdbe28d9  add rsp, 0x08
00007531fdbe28dd  jmp 0x00007531FDBDF5D8
00007531fdbe28e2  sub rsp, 0x08
00007531fdbe28e6  push rax
00007531fdbe28e7  push rcx
00007531fdbe28e8  push rdx
00007531fdbe28e9  push rdi
00007531fdbe28ea  push rsi
00007531fdbe28eb  push r8
00007531fdbe28ed  push r9
00007531fdbe28ef  push r10
00007531fdbe28f1  push r11
00007531fdbe28f3  sub rsp, 0xF0
00007531fdbe28fa  vmovaps [rsp], xmm0
00007531fdbe28ff  vmovaps [rsp+0x10], xmm1
00007531fdbe2905  vmovaps [rsp+0x20], xmm2
00007531fdbe290b  vmovaps [rsp+0x30], xmm3
00007531fdbe2911  vmovaps [rsp+0x40], xmm4
00007531fdbe2917  vmovaps [rsp+0x50], xmm5
00007531fdbe291d  vmovaps [rsp+0x60], xmm6
00007531fdbe2923  vmovaps [rsp+0x70], xmm7
00007531fdbe2929  vmovaps [rsp+0x80], xmm8
00007531fdbe2932  vmovaps [rsp+0x90], xmm9
00007531fdbe293b  vmovaps [rsp+0xA0], xmm10
00007531fdbe2944  vmovaps [rsp+0xB0], xmm11
00007531fdbe294d  vmovaps [rsp+0xC0], xmm12
00007531fdbe2956  vmovaps [rsp+0xD0], xmm13
00007531fdbe295f  vmovaps [rsp+0xE0], xmm15
00007531fdbe2968  sub rsp, 0x30
00007531fdbe296c  movaps [rsp], xmm14
00007531fdbe2971  movaps [rsp+0x10], xmm8
00007531fdbe2977  movaps [rsp+0x20], xmm4
00007531fdbe297c  lea rdi, [rsp]
00007531fdbe2980  mov esi, 0x00
00007531fdbe2985  mov rax, 0x59ED111DF530
00007531fdbe298f  call rax
00007531fdbe2991  movaps xmm14, [rsp]
00007531fdbe2996  add rsp, 0x30
00007531fdbe299a  vmovaps xmm0, [rsp]
00007531fdbe299f  vmovaps xmm1, [rsp+0x10]
00007531fdbe29a5  vmovaps xmm2, [rsp+0x20]
00007531fdbe29ab  vmovaps xmm3, [rsp+0x30]
00007531fdbe29b1  vmovaps xmm4, [rsp+0x40]
00007531fdbe29b7  vmovaps xmm5, [rsp+0x50]
00007531fdbe29bd  vmovaps xmm6, [rsp+0x60]
00007531fdbe29c3  vmovaps xmm7, [rsp+0x70]
00007531fdbe29c9  vmovaps xmm8, [rsp+0x80]
00007531fdbe29d2  vmovaps xmm9, [rsp+0x90]
00007531fdbe29db  vmovaps xmm10, [rsp+0xA0]
00007531fdbe29e4  vmovaps xmm11, [rsp+0xB0]
00007531fdbe29ed  vmovaps xmm12, [rsp+0xC0]
00007531fdbe29f6  vmovaps xmm13, [rsp+0xD0]
00007531fdbe29ff  vmovaps xmm15, [rsp+0xE0]
00007531fdbe2a08  add rsp, 0xF0
00007531fdbe2a0f  pop r11
00007531fdbe2a11  pop r10
00007531fdbe2a13  pop r9
00007531fdbe2a15  pop r8
00007531fdbe2a17  pop rsi
00007531fdbe2a18  pop rdi
00007531fdbe2a19  pop rdx
00007531fdbe2a1a  pop rcx
00007531fdbe2a1b  pop rax
00007531fdbe2a1c  add rsp, 0x08
00007531fdbe2a20  jmp 0x00007531FDBDF5F8
00007531fdbe2a25  sub rsp, 0x08
00007531fdbe2a29  push rax
00007531fdbe2a2a  push rcx
00007531fdbe2a2b  push rdx
00007531fdbe2a2c  push rdi
00007531fdbe2a2d  push rsi
00007531fdbe2a2e  push r8
00007531fdbe2a30  push r9
00007531fdbe2a32  push r10
00007531fdbe2a34  push r11
00007531fdbe2a36  sub rsp, 0xF0
00007531fdbe2a3d  vmovaps [rsp], xmm0
00007531fdbe2a42  vmovaps [rsp+0x10], xmm1
00007531fdbe2a48  vmovaps [rsp+0x20], xmm2
00007531fdbe2a4e  vmovaps [rsp+0x30], xmm3
00007531fdbe2a54  vmovaps [rsp+0x40], xmm5
00007531fdbe2a5a  vmovaps [rsp+0x50], xmm6
00007531fdbe2a60  vmovaps [rsp+0x60], xmm7
00007531fdbe2a66  vmovaps [rsp+0x70], xmm8
00007531fdbe2a6c  vmovaps [rsp+0x80], xmm9
00007531fdbe2a75  vmovaps [rsp+0x90], xmm10
00007531fdbe2a7e  vmovaps [rsp+0xA0], xmm11
00007531fdbe2a87  vmovaps [rsp+0xB0], xmm12
00007531fdbe2a90  vmovaps [rsp+0xC0], xmm13
00007531fdbe2a99  vmovaps [rsp+0xD0], xmm14
00007531fdbe2aa2  vmovaps [rsp+0xE0], xmm15
00007531fdbe2aab  sub rsp, 0x30
00007531fdbe2aaf  movaps [rsp], xmm4
00007531fdbe2ab3  movaps [rsp+0x10], xmm13
00007531fdbe2ab9  movaps [rsp+0x20], xmm8
00007531fdbe2abf  lea rdi, [rsp]
00007531fdbe2ac3  mov esi, 0x00
00007531fdbe2ac8  mov rax, 0x59ED111DF530
00007531fdbe2ad2  call rax
00007531fdbe2ad4  movaps xmm4, [rsp]
00007531fdbe2ad8  add rsp, 0x30
00007531fdbe2adc  vmovaps xmm0, [rsp]
00007531fdbe2ae1  vmovaps xmm1, [rsp+0x10]
00007531fdbe2ae7  vmovaps xmm2, [rsp+0x20]
00007531fdbe2aed  vmovaps xmm3, [rsp+0x30]
00007531fdbe2af3  vmovaps xmm5, [rsp+0x40]
00007531fdbe2af9  vmovaps xmm6, [rsp+0x50]
00007531fdbe2aff  vmovaps xmm7, [rsp+0x60]
00007531fdbe2b05  vmovaps xmm8, [rsp+0x70]
00007531fdbe2b0b  vmovaps xmm9, [rsp+0x80]
00007531fdbe2b14  vmovaps xmm10, [rsp+0x90]
00007531fdbe2b1d  vmovaps xmm11, [rsp+0xA0]
00007531fdbe2b26  vmovaps xmm12, [rsp+0xB0]
00007531fdbe2b2f  vmovaps xmm13, [rsp+0xC0]
00007531fdbe2b38  vmovaps xmm14, [rsp+0xD0]
00007531fdbe2b41  vmovaps xmm15, [rsp+0xE0]
00007531fdbe2b4a  add rsp, 0xF0
00007531fdbe2b51  pop r11
00007531fdbe2b53  pop r10
00007531fdbe2b55  pop r9
00007531fdbe2b57  pop r8
00007531fdbe2b59  pop rsi
00007531fdbe2b5a  pop rdi
00007531fdbe2b5b  pop rdx
00007531fdbe2b5c  pop rcx
00007531fdbe2b5d  pop rax
00007531fdbe2b5e  add rsp, 0x08
00007531fdbe2b62  jmp 0x00007531FDBDF61D
00007531fdbe2b67  sub rsp, 0x08
00007531fdbe2b6b  push rax
00007531fdbe2b6c  push rcx
00007531fdbe2b6d  push rdx
00007531fdbe2b6e  push rdi
00007531fdbe2b6f  push rsi
00007531fdbe2b70  push r8
00007531fdbe2b72  push r9
00007531fdbe2b74  push r10
00007531fdbe2b76  push r11
00007531fdbe2b78  sub rsp, 0xF0
00007531fdbe2b7f  vmovaps [rsp], xmm0
00007531fdbe2b84  vmovaps [rsp+0x10], xmm1
00007531fdbe2b8a  vmovaps [rsp+0x20], xmm2
00007531fdbe2b90  vmovaps [rsp+0x30], xmm3
00007531fdbe2b96  vmovaps [rsp+0x40], xmm4
00007531fdbe2b9c  vmovaps [rsp+0x50], xmm5
00007531fdbe2ba2  vmovaps [rsp+0x60], xmm6
00007531fdbe2ba8  vmovaps [rsp+0x70], xmm7
00007531fdbe2bae  vmovaps [rsp+0x80], xmm8
00007531fdbe2bb7  vmovaps [rsp+0x90], xmm9
00007531fdbe2bc0  vmovaps [rsp+0xA0], xmm10
00007531fdbe2bc9  vmovaps [rsp+0xB0], xmm11
00007531fdbe2bd2  vmovaps [rsp+0xC0], xmm12
00007531fdbe2bdb  vmovaps [rsp+0xD0], xmm14
00007531fdbe2be4  vmovaps [rsp+0xE0], xmm15
00007531fdbe2bed  sub rsp, 0x30
00007531fdbe2bf1  movaps [rsp], xmm13
00007531fdbe2bf6  movaps [rsp+0x10], xmm15
00007531fdbe2bfc  movaps [rsp+0x20], xmm9
00007531fdbe2c02  lea rdi, [rsp]
00007531fdbe2c06  mov esi, 0x00
00007531fdbe2c0b  mov rax, 0x59ED111DF530
00007531fdbe2c15  call rax
00007531fdbe2c17  movaps xmm13, [rsp]
00007531fdbe2c1c  add rsp, 0x30
00007531fdbe2c20  vmovaps xmm0, [rsp]
00007531fdbe2c25  vmovaps xmm1, [rsp+0x10]
00007531fdbe2c2b  vmovaps xmm2, [rsp+0x20]
00007531fdbe2c31  vmovaps xmm3, [rsp+0x30]
00007531fdbe2c37  vmovaps xmm4, [rsp+0x40]
00007531fdbe2c3d  vmovaps xmm5, [rsp+0x50]
00007531fdbe2c43  vmovaps xmm6, [rsp+0x60]
00007531fdbe2c49  vmovaps xmm7, [rsp+0x70]
00007531fdbe2c4f  vmovaps xmm8, [rsp+0x80]
00007531fdbe2c58  vmovaps xmm9, [rsp+0x90]
00007531fdbe2c61  vmovaps xmm10, [rsp+0xA0]
00007531fdbe2c6a  vmovaps xmm11, [rsp+0xB0]
00007531fdbe2c73  vmovaps xmm12, [rsp+0xC0]
00007531fdbe2c7c  vmovaps xmm14, [rsp+0xD0]
00007531fdbe2c85  vmovaps xmm15, [rsp+0xE0]
00007531fdbe2c8e  add rsp, 0xF0
00007531fdbe2c95  pop r11
00007531fdbe2c97  pop r10
00007531fdbe2c99  pop r9
00007531fdbe2c9b  pop r8
00007531fdbe2c9d  pop rsi
00007531fdbe2c9e  pop rdi
00007531fdbe2c9f  pop rdx
00007531fdbe2ca0  pop rcx
00007531fdbe2ca1  pop rax
00007531fdbe2ca2  add rsp, 0x08
00007531fdbe2ca6  jmp 0x00007531FDBDF638
00007531fdbe2cab  sub rsp, 0x08
00007531fdbe2caf  push rax
00007531fdbe2cb0  push rcx
00007531fdbe2cb1  push rdx
00007531fdbe2cb2  push rdi
00007531fdbe2cb3  push rsi
00007531fdbe2cb4  push r8
00007531fdbe2cb6  push r9
00007531fdbe2cb8  push r10
00007531fdbe2cba  push r11
00007531fdbe2cbc  sub rsp, 0xF0
00007531fdbe2cc3  vmovaps [rsp], xmm0
00007531fdbe2cc8  vmovaps [rsp+0x10], xmm1
00007531fdbe2cce  vmovaps [rsp+0x20], xmm2
00007531fdbe2cd4  vmovaps [rsp+0x30], xmm3
00007531fdbe2cda  vmovaps [rsp+0x40], xmm4
00007531fdbe2ce0  vmovaps [rsp+0x50], xmm5
00007531fdbe2ce6  vmovaps [rsp+0x60], xmm6
00007531fdbe2cec  vmovaps [rsp+0x70], xmm7
00007531fdbe2cf2  vmovaps [rsp+0x80], xmm8
00007531fdbe2cfb  vmovaps [rsp+0x90], xmm9
00007531fdbe2d04  vmovaps [rsp+0xA0], xmm10
00007531fdbe2d0d  vmovaps [rsp+0xB0], xmm11
00007531fdbe2d16  vmovaps [rsp+0xC0], xmm12
00007531fdbe2d1f  vmovaps [rsp+0xD0], xmm13
00007531fdbe2d28  vmovaps [rsp+0xE0], xmm14
00007531fdbe2d31  sub rsp, 0x30
00007531fdbe2d35  movaps [rsp], xmm15
00007531fdbe2d3a  movaps [rsp+0x10], xmm1
00007531fdbe2d3f  movaps [rsp+0x20], xmm5
00007531fdbe2d44  lea rdi, [rsp]
00007531fdbe2d48  mov esi, 0x00
00007531fdbe2d4d  mov rax, 0x59ED111DF530
00007531fdbe2d57  call rax
00007531fdbe2d59  movaps xmm15, [rsp]
00007531fdbe2d5e  add rsp, 0x30
00007531fdbe2d62  vmovaps xmm0, [rsp]
00007531fdbe2d67  vmovaps xmm1, [rsp+0x10]
00007531fdbe2d6d  vmovaps xmm2, [rsp+0x20]
00007531fdbe2d73  vmovaps xmm3, [rsp+0x30]
00007531fdbe2d79  vmovaps xmm4, [rsp+0x40]
00007531fdbe2d7f  vmovaps xmm5, [rsp+0x50]
00007531fdbe2d85  vmovaps xmm6, [rsp+0x60]
00007531fdbe2d8b  vmovaps xmm7, [rsp+0x70]
00007531fdbe2d91  vmovaps xmm8, [rsp+0x80]
00007531fdbe2d9a  vmovaps xmm9, [rsp+0x90]
00007531fdbe2da3  vmovaps xmm10, [rsp+0xA0]
00007531fdbe2dac  vmovaps xmm11, [rsp+0xB0]
00007531fdbe2db5  vmovaps xmm12, [rsp+0xC0]
00007531fdbe2dbe  vmovaps xmm13, [rsp+0xD0]
00007531fdbe2dc7  vmovaps xmm14, [rsp+0xE0]
00007531fdbe2dd0  add rsp, 0xF0
00007531fdbe2dd7  pop r11
00007531fdbe2dd9  pop r10
00007531fdbe2ddb  pop r9
00007531fdbe2ddd  pop r8
00007531fdbe2ddf  pop rsi
00007531fdbe2de0  pop rdi
00007531fdbe2de1  pop rdx
00007531fdbe2de2  pop rcx
00007531fdbe2de3  pop rax
00007531fdbe2de4  add rsp, 0x08
00007531fdbe2de8  jmp 0x00007531FDBDF653
00007531fdbe2ded  call 0x00007531FDAB52F0
00007531fdbe2df2  jmp 0x00007531FDBDF6AE
00007531fdbe2df7  sub rsp, 0x08
00007531fdbe2dfb  push rax
00007531fdbe2dfc  push rcx
00007531fdbe2dfd  push rdx
00007531fdbe2dfe  push rdi
00007531fdbe2dff  push rsi
00007531fdbe2e00  push r8
00007531fdbe2e02  push r9
00007531fdbe2e04  push r10
00007531fdbe2e06  push r11
00007531fdbe2e08  sub rsp, 0xF0
00007531fdbe2e0f  vmovaps [rsp], xmm0
00007531fdbe2e14  vmovaps [rsp+0x10], xmm1
00007531fdbe2e1a  vmovaps [rsp+0x20], xmm2
00007531fdbe2e20  vmovaps [rsp+0x30], xmm3
00007531fdbe2e26  vmovaps [rsp+0x40], xmm4
00007531fdbe2e2c  vmovaps [rsp+0x50], xmm5
00007531fdbe2e32  vmovaps [rsp+0x60], xmm6
00007531fdbe2e38  vmovaps [rsp+0x70], xmm7
00007531fdbe2e3e  vmovaps [rsp+0x80], xmm8
00007531fdbe2e47  vmovaps [rsp+0x90], xmm10
00007531fdbe2e50  vmovaps [rsp+0xA0], xmm11
00007531fdbe2e59  vmovaps [rsp+0xB0], xmm12
00007531fdbe2e62  vmovaps [rsp+0xC0], xmm13
00007531fdbe2e6b  vmovaps [rsp+0xD0], xmm14
00007531fdbe2e74  vmovaps [rsp+0xE0], xmm15
00007531fdbe2e7d  sub rsp, 0x30
00007531fdbe2e81  movaps [rsp], xmm9
00007531fdbe2e86  movaps [rsp+0x10], xmm8
00007531fdbe2e8c  movaps [rsp+0x20], xmm11
00007531fdbe2e92  lea rdi, [rsp]
00007531fdbe2e96  mov esi, 0x00
00007531fdbe2e9b  mov rax, 0x59ED111DF530
00007531fdbe2ea5  call rax
00007531fdbe2ea7  movaps xmm9, [rsp]
00007531fdbe2eac  add rsp, 0x30
00007531fdbe2eb0  vmovaps xmm0, [rsp]
00007531fdbe2eb5  vmovaps xmm1, [rsp+0x10]
00007531fdbe2ebb  vmovaps xmm2, [rsp+0x20]
00007531fdbe2ec1  vmovaps xmm3, [rsp+0x30]
00007531fdbe2ec7  vmovaps xmm4, [rsp+0x40]
00007531fdbe2ecd  vmovaps xmm5, [rsp+0x50]
00007531fdbe2ed3  vmovaps xmm6, [rsp+0x60]
00007531fdbe2ed9  vmovaps xmm7, [rsp+0x70]
00007531fdbe2edf  vmovaps xmm8, [rsp+0x80]
00007531fdbe2ee8  vmovaps xmm10, [rsp+0x90]
00007531fdbe2ef1  vmovaps xmm11, [rsp+0xA0]
00007531fdbe2efa  vmovaps xmm12, [rsp+0xB0]
00007531fdbe2f03  vmovaps xmm13, [rsp+0xC0]
00007531fdbe2f0c  vmovaps xmm14, [rsp+0xD0]
00007531fdbe2f15  vmovaps xmm15, [rsp+0xE0]
00007531fdbe2f1e  add rsp, 0xF0
00007531fdbe2f25  pop r11
00007531fdbe2f27  pop r10
00007531fdbe2f29  pop r9
00007531fdbe2f2b  pop r8
00007531fdbe2f2d  pop rsi
00007531fdbe2f2e  pop rdi
00007531fdbe2f2f  pop rdx
00007531fdbe2f30  pop rcx
00007531fdbe2f31  pop rax
00007531fdbe2f32  add rsp, 0x08
00007531fdbe2f36  jmp 0x00007531FDBDF6E5
00007531fdbe2f3b  sub rsp, 0x08
00007531fdbe2f3f  push rax
00007531fdbe2f40  push rcx
00007531fdbe2f41  push rdx
00007531fdbe2f42  push rdi
00007531fdbe2f43  push rsi
00007531fdbe2f44  push r8
00007531fdbe2f46  push r9
00007531fdbe2f48  push r10
00007531fdbe2f4a  push r11
00007531fdbe2f4c  sub rsp, 0xF0
00007531fdbe2f53  vmovaps [rsp], xmm0
00007531fdbe2f58  vmovaps [rsp+0x10], xmm1
00007531fdbe2f5e  vmovaps [rsp+0x20], xmm2
00007531fdbe2f64  vmovaps [rsp+0x30], xmm3
00007531fdbe2f6a  vmovaps [rsp+0x40], xmm4
00007531fdbe2f70  vmovaps [rsp+0x50], xmm5
00007531fdbe2f76  vmovaps [rsp+0x60], xmm6
00007531fdbe2f7c  vmovaps [rsp+0x70], xmm7
00007531fdbe2f82  vmovaps [rsp+0x80], xmm8
00007531fdbe2f8b  vmovaps [rsp+0x90], xmm9
00007531fdbe2f94  vmovaps [rsp+0xA0], xmm10
00007531fdbe2f9d  vmovaps [rsp+0xB0], xmm12
00007531fdbe2fa6  vmovaps [rsp+0xC0], xmm13
00007531fdbe2faf  vmovaps [rsp+0xD0], xmm14
00007531fdbe2fb8  vmovaps [rsp+0xE0], xmm15
00007531fdbe2fc1  sub rsp, 0x30
00007531fdbe2fc5  movaps [rsp], xmm11
00007531fdbe2fca  movaps [rsp+0x10], xmm10
00007531fdbe2fd0  movaps [rsp+0x20], xmm6
00007531fdbe2fd5  lea rdi, [rsp]
00007531fdbe2fd9  mov esi, 0x00
00007531fdbe2fde  mov rax, 0x59ED111DF530
00007531fdbe2fe8  call rax
00007531fdbe2fea  movaps xmm11, [rsp]
00007531fdbe2fef  add rsp, 0x30
00007531fdbe2ff3  vmovaps xmm0, [rsp]
00007531fdbe2ff8  vmovaps xmm1, [rsp+0x10]
00007531fdbe2ffe  vmovaps xmm2, [rsp+0x20]
00007531fdbe3004  vmovaps xmm3, [rsp+0x30]
00007531fdbe300a  vmovaps xmm4, [rsp+0x40]
00007531fdbe3010  vmovaps xmm5, [rsp+0x50]
00007531fdbe3016  vmovaps xmm6, [rsp+0x60]
00007531fdbe301c  vmovaps xmm7, [rsp+0x70]
00007531fdbe3022  vmovaps xmm8, [rsp+0x80]
00007531fdbe302b  vmovaps xmm9, [rsp+0x90]
00007531fdbe3034  vmovaps xmm10, [rsp+0xA0]
00007531fdbe303d  vmovaps xmm12, [rsp+0xB0]
00007531fdbe3046  vmovaps xmm13, [rsp+0xC0]
00007531fdbe304f  vmovaps xmm14, [rsp+0xD0]
00007531fdbe3058  vmovaps xmm15, [rsp+0xE0]
00007531fdbe3061  add rsp, 0xF0
00007531fdbe3068  pop r11
00007531fdbe306a  pop r10
00007531fdbe306c  pop r9
00007531fdbe306e  pop r8
00007531fdbe3070  pop rsi
00007531fdbe3071  pop rdi
00007531fdbe3072  pop rdx
00007531fdbe3073  pop rcx
00007531fdbe3074  pop rax
00007531fdbe3075  add rsp, 0x08
00007531fdbe3079  jmp 0x00007531FDBDF700
00007531fdbe307e  sub rsp, 0x08
00007531fdbe3082  push rax
00007531fdbe3083  push rcx
00007531fdbe3084  push rdx
00007531fdbe3085  push rdi
00007531fdbe3086  push rsi
00007531fdbe3087  push r8
00007531fdbe3089  push r9
00007531fdbe308b  push r10
00007531fdbe308d  push r11
00007531fdbe308f  sub rsp, 0xF0
00007531fdbe3096  vmovaps [rsp], xmm0
00007531fdbe309b  vmovaps [rsp+0x10], xmm1
00007531fdbe30a1  vmovaps [rsp+0x20], xmm2
00007531fdbe30a7  vmovaps [rsp+0x30], xmm3
00007531fdbe30ad  vmovaps [rsp+0x40], xmm4
00007531fdbe30b3  vmovaps [rsp+0x50], xmm5
00007531fdbe30b9  vmovaps [rsp+0x60], xmm6
00007531fdbe30bf  vmovaps [rsp+0x70], xmm7
00007531fdbe30c5  vmovaps [rsp+0x80], xmm8
00007531fdbe30ce  vmovaps [rsp+0x90], xmm9
00007531fdbe30d7  vmovaps [rsp+0xA0], xmm11
00007531fdbe30e0  vmovaps [rsp+0xB0], xmm12
00007531fdbe30e9  vmovaps [rsp+0xC0], xmm13
00007531fdbe30f2  vmovaps [rsp+0xD0], xmm14
00007531fdbe30fb  vmovaps [rsp+0xE0], xmm15
00007531fdbe3104  sub rsp, 0x30
00007531fdbe3108  movaps [rsp], xmm10
00007531fdbe310d  movaps [rsp+0x10], xmm14
00007531fdbe3113  movaps [rsp+0x20], xmm4
00007531fdbe3118  lea rdi, [rsp]
00007531fdbe311c  mov esi, 0x00
00007531fdbe3121  mov rax, 0x59ED111DF530
00007531fdbe312b  call rax
00007531fdbe312d  movaps xmm10, [rsp]
00007531fdbe3132  add rsp, 0x30
00007531fdbe3136  vmovaps xmm0, [rsp]
00007531fdbe313b  vmovaps xmm1, [rsp+0x10]
00007531fdbe3141  vmovaps xmm2, [rsp+0x20]
00007531fdbe3147  vmovaps xmm3, [rsp+0x30]
00007531fdbe314d  vmovaps xmm4, [rsp+0x40]
00007531fdbe3153  vmovaps xmm5, [rsp+0x50]
00007531fdbe3159  vmovaps xmm6, [rsp+0x60]
00007531fdbe315f  vmovaps xmm7, [rsp+0x70]
00007531fdbe3165  vmovaps xmm8, [rsp+0x80]
00007531fdbe316e  vmovaps xmm9, [rsp+0x90]
00007531fdbe3177  vmovaps xmm11, [rsp+0xA0]
00007531fdbe3180  vmovaps xmm12, [rsp+0xB0]
00007531fdbe3189  vmovaps xmm13, [rsp+0xC0]
00007531fdbe3192  vmovaps xmm14, [rsp+0xD0]
00007531fdbe319b  vmovaps xmm15, [rsp+0xE0]
00007531fdbe31a4  add rsp, 0xF0
00007531fdbe31ab  pop r11
00007531fdbe31ad  pop r10
00007531fdbe31af  pop r9
00007531fdbe31b1  pop r8
00007531fdbe31b3  pop rsi
00007531fdbe31b4  pop rdi
00007531fdbe31b5  pop rdx
00007531fdbe31b6  pop rcx
00007531fdbe31b7  pop rax
00007531fdbe31b8  add rsp, 0x08
00007531fdbe31bc  jmp 0x00007531FDBDF71B
00007531fdbe31c1  sub rsp, 0x08
00007531fdbe31c5  push rax
00007531fdbe31c6  push rcx
00007531fdbe31c7  push rdx
00007531fdbe31c8  push rdi
00007531fdbe31c9  push rsi
00007531fdbe31ca  push r8
00007531fdbe31cc  push r9
00007531fdbe31ce  push r10
00007531fdbe31d0  push r11
00007531fdbe31d2  sub rsp, 0xF0
00007531fdbe31d9  vmovaps [rsp], xmm0
00007531fdbe31de  vmovaps [rsp+0x10], xmm1
00007531fdbe31e4  vmovaps [rsp+0x20], xmm2
00007531fdbe31ea  vmovaps [rsp+0x30], xmm3
00007531fdbe31f0  vmovaps [rsp+0x40], xmm4
00007531fdbe31f6  vmovaps [rsp+0x50], xmm5
00007531fdbe31fc  vmovaps [rsp+0x60], xmm6
00007531fdbe3202  vmovaps [rsp+0x70], xmm7
00007531fdbe3208  vmovaps [rsp+0x80], xmm9
00007531fdbe3211  vmovaps [rsp+0x90], xmm10
00007531fdbe321a  vmovaps [rsp+0xA0], xmm11
00007531fdbe3223  vmovaps [rsp+0xB0], xmm12
00007531fdbe322c  vmovaps [rsp+0xC0], xmm13
00007531fdbe3235  vmovaps [rsp+0xD0], xmm14
00007531fdbe323e  vmovaps [rsp+0xE0], xmm15
00007531fdbe3247  sub rsp, 0x30
00007531fdbe324b  movaps [rsp], xmm8
00007531fdbe3250  movaps [rsp+0x10], xmm1
00007531fdbe3255  movaps [rsp+0x20], xmm14
00007531fdbe325b  lea rdi, [rsp]
00007531fdbe325f  mov esi, 0x00
00007531fdbe3264  mov rax, 0x59ED111DF530
00007531fdbe326e  call rax
00007531fdbe3270  movaps xmm8, [rsp]
00007531fdbe3275  add rsp, 0x30
00007531fdbe3279  vmovaps xmm0, [rsp]
00007531fdbe327e  vmovaps xmm1, [rsp+0x10]
00007531fdbe3284  vmovaps xmm2, [rsp+0x20]
00007531fdbe328a  vmovaps xmm3, [rsp+0x30]
00007531fdbe3290  vmovaps xmm4, [rsp+0x40]
00007531fdbe3296  vmovaps xmm5, [rsp+0x50]
00007531fdbe329c  vmovaps xmm6, [rsp+0x60]
00007531fdbe32a2  vmovaps xmm7, [rsp+0x70]
00007531fdbe32a8  vmovaps xmm9, [rsp+0x80]
00007531fdbe32b1  vmovaps xmm10, [rsp+0x90]
00007531fdbe32ba  vmovaps xmm11, [rsp+0xA0]
00007531fdbe32c3  vmovaps xmm12, [rsp+0xB0]
00007531fdbe32cc  vmovaps xmm13, [rsp+0xC0]
00007531fdbe32d5  vmovaps xmm14, [rsp+0xD0]
00007531fdbe32de  vmovaps xmm15, [rsp+0xE0]
00007531fdbe32e7  add rsp, 0xF0
00007531fdbe32ee  pop r11
00007531fdbe32f0  pop r10
00007531fdbe32f2  pop r9
00007531fdbe32f4  pop r8
00007531fdbe32f6  pop rsi
00007531fdbe32f7  pop rdi
00007531fdbe32f8  pop rdx
00007531fdbe32f9  pop rcx
00007531fdbe32fa  pop rax
00007531fdbe32fb  add rsp, 0x08
00007531fdbe32ff  jmp 0x00007531FDBDF741
00007531fdbe3304  sub rsp, 0x08
00007531fdbe3308  push rax
00007531fdbe3309  push rcx
00007531fdbe330a  push rdx
00007531fdbe330b  push rdi
00007531fdbe330c  push rsi
00007531fdbe330d  push r8
00007531fdbe330f  push r9
00007531fdbe3311  push r10
00007531fdbe3313  push r11
00007531fdbe3315  sub rsp, 0xF0
00007531fdbe331c  vmovaps [rsp], xmm0
00007531fdbe3321  vmovaps [rsp+0x10], xmm1
00007531fdbe3327  vmovaps [rsp+0x20], xmm2
00007531fdbe332d  vmovaps [rsp+0x30], xmm3
00007531fdbe3333  vmovaps [rsp+0x40], xmm4
00007531fdbe3339  vmovaps [rsp+0x50], xmm5
00007531fdbe333f  vmovaps [rsp+0x60], xmm7
00007531fdbe3345  vmovaps [rsp+0x70], xmm8
00007531fdbe334b  vmovaps [rsp+0x80], xmm9
00007531fdbe3354  vmovaps [rsp+0x90], xmm10
00007531fdbe335d  vmovaps [rsp+0xA0], xmm11
00007531fdbe3366  vmovaps [rsp+0xB0], xmm12
00007531fdbe336f  vmovaps [rsp+0xC0], xmm13
00007531fdbe3378  vmovaps [rsp+0xD0], xmm14
00007531fdbe3381  vmovaps [rsp+0xE0], xmm15
00007531fdbe338a  sub rsp, 0x30
00007531fdbe338e  movaps [rsp], xmm6
00007531fdbe3392  movaps [rsp+0x10], xmm1
00007531fdbe3397  movaps [rsp+0x20], xmm14
00007531fdbe339d  lea rdi, [rsp]
00007531fdbe33a1  mov esi, 0x00
00007531fdbe33a6  mov rax, 0x59ED111DF530
00007531fdbe33b0  call rax
00007531fdbe33b2  movaps xmm6, [rsp]
00007531fdbe33b6  add rsp, 0x30
00007531fdbe33ba  vmovaps xmm0, [rsp]
00007531fdbe33bf  vmovaps xmm1, [rsp+0x10]
00007531fdbe33c5  vmovaps xmm2, [rsp+0x20]
00007531fdbe33cb  vmovaps xmm3, [rsp+0x30]
00007531fdbe33d1  vmovaps xmm4, [rsp+0x40]
00007531fdbe33d7  vmovaps xmm5, [rsp+0x50]
00007531fdbe33dd  vmovaps xmm7, [rsp+0x60]
00007531fdbe33e3  vmovaps xmm8, [rsp+0x70]
00007531fdbe33e9  vmovaps xmm9, [rsp+0x80]
00007531fdbe33f2  vmovaps xmm10, [rsp+0x90]
00007531fdbe33fb  vmovaps xmm11, [rsp+0xA0]
00007531fdbe3404  vmovaps xmm12, [rsp+0xB0]
00007531fdbe340d  vmovaps xmm13, [rsp+0xC0]
00007531fdbe3416  vmovaps xmm14, [rsp+0xD0]
00007531fdbe341f  vmovaps xmm15, [rsp+0xE0]
00007531fdbe3428  add rsp, 0xF0
00007531fdbe342f  pop r11
00007531fdbe3431  pop r10
00007531fdbe3433  pop r9
00007531fdbe3435  pop r8
00007531fdbe3437  pop rsi
00007531fdbe3438  pop rdi
00007531fdbe3439  pop rdx
00007531fdbe343a  pop rcx
00007531fdbe343b  pop rax
00007531fdbe343c  add rsp, 0x08
00007531fdbe3440  jmp 0x00007531FDBDF76D
00007531fdbe3445  sub rsp, 0x08
00007531fdbe3449  push rax
00007531fdbe344a  push rcx
00007531fdbe344b  push rdx
00007531fdbe344c  push rdi
00007531fdbe344d  push rsi
00007531fdbe344e  push r8
00007531fdbe3450  push r9
00007531fdbe3452  push r10
00007531fdbe3454  push r11
00007531fdbe3456  sub rsp, 0xF0
00007531fdbe345d  vmovaps [rsp], xmm0
00007531fdbe3462  vmovaps [rsp+0x10], xmm1
00007531fdbe3468  vmovaps [rsp+0x20], xmm2
00007531fdbe346e  vmovaps [rsp+0x30], xmm3
00007531fdbe3474  vmovaps [rsp+0x40], xmm4
00007531fdbe347a  vmovaps [rsp+0x50], xmm5
00007531fdbe3480  vmovaps [rsp+0x60], xmm6
00007531fdbe3486  vmovaps [rsp+0x70], xmm7
00007531fdbe348c  vmovaps [rsp+0x80], xmm8
00007531fdbe3495  vmovaps [rsp+0x90], xmm9
00007531fdbe349e  vmovaps [rsp+0xA0], xmm10
00007531fdbe34a7  vmovaps [rsp+0xB0], xmm11
00007531fdbe34b0  vmovaps [rsp+0xC0], xmm12
00007531fdbe34b9  vmovaps [rsp+0xD0], xmm13
00007531fdbe34c2  vmovaps [rsp+0xE0], xmm15
00007531fdbe34cb  sub rsp, 0x30
00007531fdbe34cf  movaps [rsp], xmm14
00007531fdbe34d4  movaps [rsp+0x10], xmm12
00007531fdbe34da  movaps [rsp+0x20], xmm1
00007531fdbe34df  lea rdi, [rsp]
00007531fdbe34e3  mov esi, 0x00
00007531fdbe34e8  mov rax, 0x59ED111DF530
00007531fdbe34f2  call rax
00007531fdbe34f4  movaps xmm14, [rsp]
00007531fdbe34f9  add rsp, 0x30
00007531fdbe34fd  vmovaps xmm0, [rsp]
00007531fdbe3502  vmovaps xmm1, [rsp+0x10]
00007531fdbe3508  vmovaps xmm2, [rsp+0x20]
00007531fdbe350e  vmovaps xmm3, [rsp+0x30]
00007531fdbe3514  vmovaps xmm4, [rsp+0x40]
00007531fdbe351a  vmovaps xmm5, [rsp+0x50]
00007531fdbe3520  vmovaps xmm6, [rsp+0x60]
00007531fdbe3526  vmovaps xmm7, [rsp+0x70]
00007531fdbe352c  vmovaps xmm8, [rsp+0x80]
00007531fdbe3535  vmovaps xmm9, [rsp+0x90]
00007531fdbe353e  vmovaps xmm10, [rsp+0xA0]
00007531fdbe3547  vmovaps xmm11, [rsp+0xB0]
00007531fdbe3550  vmovaps xmm12, [rsp+0xC0]
00007531fdbe3559  vmovaps xmm13, [rsp+0xD0]
00007531fdbe3562  vmovaps xmm15, [rsp+0xE0]
00007531fdbe356b  add rsp, 0xF0
00007531fdbe3572  pop r11
00007531fdbe3574  pop r10
00007531fdbe3576  pop r9
00007531fdbe3578  pop r8
00007531fdbe357a  pop rsi
00007531fdbe357b  pop rdi
00007531fdbe357c  pop rdx
00007531fdbe357d  pop rcx
00007531fdbe357e  pop rax
00007531fdbe357f  add rsp, 0x08
00007531fdbe3583  jmp 0x00007531FDBDF793
00007531fdbe3588  sub rsp, 0x08
00007531fdbe358c  push rax
00007531fdbe358d  push rcx
00007531fdbe358e  push rdx
00007531fdbe358f  push rdi
00007531fdbe3590  push rsi
00007531fdbe3591  push r8
00007531fdbe3593  push r9
00007531fdbe3595  push r10
00007531fdbe3597  push r11
00007531fdbe3599  sub rsp, 0xF0
00007531fdbe35a0  vmovaps [rsp], xmm0
00007531fdbe35a5  vmovaps [rsp+0x10], xmm2
00007531fdbe35ab  vmovaps [rsp+0x20], xmm3
00007531fdbe35b1  vmovaps [rsp+0x30], xmm4
00007531fdbe35b7  vmovaps [rsp+0x40], xmm5
00007531fdbe35bd  vmovaps [rsp+0x50], xmm6
00007531fdbe35c3  vmovaps [rsp+0x60], xmm7
00007531fdbe35c9  vmovaps [rsp+0x70], xmm8
00007531fdbe35cf  vmovaps [rsp+0x80], xmm9
00007531fdbe35d8  vmovaps [rsp+0x90], xmm10
00007531fdbe35e1  vmovaps [rsp+0xA0], xmm11
00007531fdbe35ea  vmovaps [rsp+0xB0], xmm12
00007531fdbe35f3  vmovaps [rsp+0xC0], xmm13
00007531fdbe35fc  vmovaps [rsp+0xD0], xmm14
00007531fdbe3605  vmovaps [rsp+0xE0], xmm15
00007531fdbe360e  sub rsp, 0x30
00007531fdbe3612  movaps [rsp], xmm1
00007531fdbe3616  movaps [rsp+0x10], xmm13
00007531fdbe361c  movaps [rsp+0x20], xmm9
00007531fdbe3622  lea rdi, [rsp]
00007531fdbe3626  mov esi, 0x00
00007531fdbe362b  mov rax, 0x59ED111DF530
00007531fdbe3635  call rax
00007531fdbe3637  movaps xmm1, [rsp]
00007531fdbe363b  add rsp, 0x30
00007531fdbe363f  vmovaps xmm0, [rsp]
00007531fdbe3644  vmovaps xmm2, [rsp+0x10]
00007531fdbe364a  vmovaps xmm3, [rsp+0x20]
00007531fdbe3650  vmovaps xmm4, [rsp+0x30]
00007531fdbe3656  vmovaps xmm5, [rsp+0x40]
00007531fdbe365c  vmovaps xmm6, [rsp+0x50]
00007531fdbe3662  vmovaps xmm7, [rsp+0x60]
00007531fdbe3668  vmovaps xmm8, [rsp+0x70]
00007531fdbe366e  vmovaps xmm9, [rsp+0x80]
00007531fdbe3677  vmovaps xmm10, [rsp+0x90]
00007531fdbe3680  vmovaps xmm11, [rsp+0xA0]
00007531fdbe3689  vmovaps xmm12, [rsp+0xB0]
00007531fdbe3692  vmovaps xmm13, [rsp+0xC0]
00007531fdbe369b  vmovaps xmm14, [rsp+0xD0]
00007531fdbe36a4  vmovaps xmm15, [rsp+0xE0]
00007531fdbe36ad  add rsp, 0xF0
00007531fdbe36b4  pop r11
00007531fdbe36b6  pop r10
00007531fdbe36b8  pop r9
00007531fdbe36ba  pop r8
00007531fdbe36bc  pop rsi
00007531fdbe36bd  pop rdi
00007531fdbe36be  pop rdx
00007531fdbe36bf  pop rcx
00007531fdbe36c0  pop rax
00007531fdbe36c1  add rsp, 0x08
00007531fdbe36c5  jmp 0x00007531FDBDF7AD
00007531fdbe36ca  sub rsp, 0x08
00007531fdbe36ce  push rax
00007531fdbe36cf  push rcx
00007531fdbe36d0  push rdx
00007531fdbe36d1  push rdi
00007531fdbe36d2  push rsi
00007531fdbe36d3  push r8
00007531fdbe36d5  push r9
00007531fdbe36d7  push r10
00007531fdbe36d9  push r11
00007531fdbe36db  sub rsp, 0xF0
00007531fdbe36e2  vmovaps [rsp], xmm0
00007531fdbe36e7  vmovaps [rsp+0x10], xmm1
00007531fdbe36ed  vmovaps [rsp+0x20], xmm2
00007531fdbe36f3  vmovaps [rsp+0x30], xmm3
00007531fdbe36f9  vmovaps [rsp+0x40], xmm4
00007531fdbe36ff  vmovaps [rsp+0x50], xmm5
00007531fdbe3705  vmovaps [rsp+0x60], xmm6
00007531fdbe370b  vmovaps [rsp+0x70], xmm7
00007531fdbe3711  vmovaps [rsp+0x80], xmm8
00007531fdbe371a  vmovaps [rsp+0x90], xmm9
00007531fdbe3723  vmovaps [rsp+0xA0], xmm10
00007531fdbe372c  vmovaps [rsp+0xB0], xmm11
00007531fdbe3735  vmovaps [rsp+0xC0], xmm13
00007531fdbe373e  vmovaps [rsp+0xD0], xmm14
00007531fdbe3747  vmovaps [rsp+0xE0], xmm15
00007531fdbe3750  sub rsp, 0x30
00007531fdbe3754  movaps [rsp], xmm12
00007531fdbe3759  movaps [rsp+0x10], xmm7
00007531fdbe375e  movaps [rsp+0x20], xmm13
00007531fdbe3764  lea rdi, [rsp]
00007531fdbe3768  mov esi, 0x00
00007531fdbe376d  mov rax, 0x59ED111DF530
00007531fdbe3777  call rax
00007531fdbe3779  movaps xmm12, [rsp]
00007531fdbe377e  add rsp, 0x30
00007531fdbe3782  vmovaps xmm0, [rsp]
00007531fdbe3787  vmovaps xmm1, [rsp+0x10]
00007531fdbe378d  vmovaps xmm2, [rsp+0x20]
00007531fdbe3793  vmovaps xmm3, [rsp+0x30]
00007531fdbe3799  vmovaps xmm4, [rsp+0x40]
00007531fdbe379f  vmovaps xmm5, [rsp+0x50]
00007531fdbe37a5  vmovaps xmm6, [rsp+0x60]
00007531fdbe37ab  vmovaps xmm7, [rsp+0x70]
00007531fdbe37b1  vmovaps xmm8, [rsp+0x80]
00007531fdbe37ba  vmovaps xmm9, [rsp+0x90]
00007531fdbe37c3  vmovaps xmm10, [rsp+0xA0]
00007531fdbe37cc  vmovaps xmm11, [rsp+0xB0]
00007531fdbe37d5  vmovaps xmm13, [rsp+0xC0]
00007531fdbe37de  vmovaps xmm14, [rsp+0xD0]
00007531fdbe37e7  vmovaps xmm15, [rsp+0xE0]
00007531fdbe37f0  add rsp, 0xF0
00007531fdbe37f7  pop r11
00007531fdbe37f9  pop r10
00007531fdbe37fb  pop r9
00007531fdbe37fd  pop r8
00007531fdbe37ff  pop rsi
00007531fdbe3800  pop rdi
00007531fdbe3801  pop rdx
00007531fdbe3802  pop rcx
00007531fdbe3803  pop rax
00007531fdbe3804  add rsp, 0x08
00007531fdbe3808  jmp 0x00007531FDBDF7D4
00007531fdbe380d  sub rsp, 0x08
00007531fdbe3811  push rax
00007531fdbe3812  push rcx
00007531fdbe3813  push rdx
00007531fdbe3814  push rdi
00007531fdbe3815  push rsi
00007531fdbe3816  push r8
00007531fdbe3818  push r9
00007531fdbe381a  push r10
00007531fdbe381c  push r11
00007531fdbe381e  sub rsp, 0xF0
00007531fdbe3825  vmovaps [rsp], xmm0
00007531fdbe382a  vmovaps [rsp+0x10], xmm1
00007531fdbe3830  vmovaps [rsp+0x20], xmm2
00007531fdbe3836  vmovaps [rsp+0x30], xmm3
00007531fdbe383c  vmovaps [rsp+0x40], xmm4
00007531fdbe3842  vmovaps [rsp+0x50], xmm5
00007531fdbe3848  vmovaps [rsp+0x60], xmm6
00007531fdbe384e  vmovaps [rsp+0x70], xmm7
00007531fdbe3854  vmovaps [rsp+0x80], xmm8
00007531fdbe385d  vmovaps [rsp+0x90], xmm9
00007531fdbe3866  vmovaps [rsp+0xA0], xmm10
00007531fdbe386f  vmovaps [rsp+0xB0], xmm11
00007531fdbe3878  vmovaps [rsp+0xC0], xmm12
00007531fdbe3881  vmovaps [rsp+0xD0], xmm14
00007531fdbe388a  vmovaps [rsp+0xE0], xmm15
00007531fdbe3893  sub rsp, 0x30
00007531fdbe3897  movaps [rsp], xmm13
00007531fdbe389c  movaps [rsp+0x10], xmm15
00007531fdbe38a2  movaps [rsp+0x20], xmm8
00007531fdbe38a8  lea rdi, [rsp]
00007531fdbe38ac  mov esi, 0x00
00007531fdbe38b1  mov rax, 0x59ED111DF530
00007531fdbe38bb  call rax
00007531fdbe38bd  movaps xmm13, [rsp]
00007531fdbe38c2  add rsp, 0x30
00007531fdbe38c6  vmovaps xmm0, [rsp]
00007531fdbe38cb  vmovaps xmm1, [rsp+0x10]
00007531fdbe38d1  vmovaps xmm2, [rsp+0x20]
00007531fdbe38d7  vmovaps xmm3, [rsp+0x30]
00007531fdbe38dd  vmovaps xmm4, [rsp+0x40]
00007531fdbe38e3  vmovaps xmm5, [rsp+0x50]
00007531fdbe38e9  vmovaps xmm6, [rsp+0x60]
00007531fdbe38ef  vmovaps xmm7, [rsp+0x70]
00007531fdbe38f5  vmovaps xmm8, [rsp+0x80]
00007531fdbe38fe  vmovaps xmm9, [rsp+0x90]
00007531fdbe3907  vmovaps xmm10, [rsp+0xA0]
00007531fdbe3910  vmovaps xmm11, [rsp+0xB0]
00007531fdbe3919  vmovaps xmm12, [rsp+0xC0]
00007531fdbe3922  vmovaps xmm14, [rsp+0xD0]
00007531fdbe392b  vmovaps xmm15, [rsp+0xE0]
00007531fdbe3934  add rsp, 0xF0
00007531fdbe393b  pop r11
00007531fdbe393d  pop r10
00007531fdbe393f  pop r9
00007531fdbe3941  pop r8
00007531fdbe3943  pop rsi
00007531fdbe3944  pop rdi
00007531fdbe3945  pop rdx
00007531fdbe3946  pop rcx
00007531fdbe3947  pop rax
00007531fdbe3948  add rsp, 0x08
00007531fdbe394c  jmp 0x00007531FDBDF7EF
00007531fdbe3951  sub rsp, 0x08
00007531fdbe3955  push rax
00007531fdbe3956  push rcx
00007531fdbe3957  push rdx
00007531fdbe3958  push rdi
00007531fdbe3959  push rsi
00007531fdbe395a  push r8
00007531fdbe395c  push r9
00007531fdbe395e  push r10
00007531fdbe3960  push r11
00007531fdbe3962  sub rsp, 0xF0
00007531fdbe3969  vmovaps [rsp], xmm0
00007531fdbe396e  vmovaps [rsp+0x10], xmm1
00007531fdbe3974  vmovaps [rsp+0x20], xmm2
00007531fdbe397a  vmovaps [rsp+0x30], xmm3
00007531fdbe3980  vmovaps [rsp+0x40], xmm4
00007531fdbe3986  vmovaps [rsp+0x50], xmm5
00007531fdbe398c  vmovaps [rsp+0x60], xmm6
00007531fdbe3992  vmovaps [rsp+0x70], xmm7
00007531fdbe3998  vmovaps [rsp+0x80], xmm9
00007531fdbe39a1  vmovaps [rsp+0x90], xmm10
00007531fdbe39aa  vmovaps [rsp+0xA0], xmm11
00007531fdbe39b3  vmovaps [rsp+0xB0], xmm12
00007531fdbe39bc  vmovaps [rsp+0xC0], xmm13
00007531fdbe39c5  vmovaps [rsp+0xD0], xmm14
00007531fdbe39ce  vmovaps [rsp+0xE0], xmm15
00007531fdbe39d7  sub rsp, 0x30
00007531fdbe39db  movaps [rsp], xmm8
00007531fdbe39e0  movaps [rsp+0x10], xmm15
00007531fdbe39e6  movaps [rsp+0x20], xmm9
00007531fdbe39ec  lea rdi, [rsp]
00007531fdbe39f0  mov esi, 0x00
00007531fdbe39f5  mov rax, 0x59ED111DF530
00007531fdbe39ff  call rax
00007531fdbe3a01  movaps xmm8, [rsp]
00007531fdbe3a06  add rsp, 0x30
00007531fdbe3a0a  vmovaps xmm0, [rsp]
00007531fdbe3a0f  vmovaps xmm1, [rsp+0x10]
00007531fdbe3a15  vmovaps xmm2, [rsp+0x20]
00007531fdbe3a1b  vmovaps xmm3, [rsp+0x30]
00007531fdbe3a21  vmovaps xmm4, [rsp+0x40]
00007531fdbe3a27  vmovaps xmm5, [rsp+0x50]
00007531fdbe3a2d  vmovaps xmm6, [rsp+0x60]
00007531fdbe3a33  vmovaps xmm7, [rsp+0x70]
00007531fdbe3a39  vmovaps xmm9, [rsp+0x80]
00007531fdbe3a42  vmovaps xmm10, [rsp+0x90]
00007531fdbe3a4b  vmovaps xmm11, [rsp+0xA0]
00007531fdbe3a54  vmovaps xmm12, [rsp+0xB0]
00007531fdbe3a5d  vmovaps xmm13, [rsp+0xC0]
00007531fdbe3a66  vmovaps xmm14, [rsp+0xD0]
00007531fdbe3a6f  vmovaps xmm15, [rsp+0xE0]
00007531fdbe3a78  add rsp, 0xF0
00007531fdbe3a7f  pop r11
00007531fdbe3a81  pop r10
00007531fdbe3a83  pop r9
00007531fdbe3a85  pop r8
00007531fdbe3a87  pop rsi
00007531fdbe3a88  pop rdi
00007531fdbe3a89  pop rdx
00007531fdbe3a8a  pop rcx
00007531fdbe3a8b  pop rax
00007531fdbe3a8c  add rsp, 0x08
00007531fdbe3a90  jmp 0x00007531FDBDF81D
00007531fdbe3a95  sub rsp, 0x08
00007531fdbe3a99  push rax
00007531fdbe3a9a  push rcx
00007531fdbe3a9b  push rdx
00007531fdbe3a9c  push rdi
00007531fdbe3a9d  push rsi
00007531fdbe3a9e  push r8
00007531fdbe3aa0  push r9
00007531fdbe3aa2  push r10
00007531fdbe3aa4  push r11
00007531fdbe3aa6  sub rsp, 0xF0
00007531fdbe3aad  vmovaps [rsp], xmm0
00007531fdbe3ab2  vmovaps [rsp+0x10], xmm1
00007531fdbe3ab8  vmovaps [rsp+0x20], xmm2
00007531fdbe3abe  vmovaps [rsp+0x30], xmm3
00007531fdbe3ac4  vmovaps [rsp+0x40], xmm4
00007531fdbe3aca  vmovaps [rsp+0x50], xmm5
00007531fdbe3ad0  vmovaps [rsp+0x60], xmm6
00007531fdbe3ad6  vmovaps [rsp+0x70], xmm7
00007531fdbe3adc  vmovaps [rsp+0x80], xmm8
00007531fdbe3ae5  vmovaps [rsp+0x90], xmm9
00007531fdbe3aee  vmovaps [rsp+0xA0], xmm10
00007531fdbe3af7  vmovaps [rsp+0xB0], xmm11
00007531fdbe3b00  vmovaps [rsp+0xC0], xmm12
00007531fdbe3b09  vmovaps [rsp+0xD0], xmm13
00007531fdbe3b12  vmovaps [rsp+0xE0], xmm14
00007531fdbe3b1b  sub rsp, 0x30
00007531fdbe3b1f  movaps [rsp], xmm15
00007531fdbe3b24  movaps [rsp+0x10], xmm11
00007531fdbe3b2a  movaps [rsp+0x20], xmm6
00007531fdbe3b2f  lea rdi, [rsp]
00007531fdbe3b33  mov esi, 0x00
00007531fdbe3b38  mov rax, 0x59ED111DF530
00007531fdbe3b42  call rax
00007531fdbe3b44  movaps xmm15, [rsp]
00007531fdbe3b49  add rsp, 0x30
00007531fdbe3b4d  vmovaps xmm0, [rsp]
00007531fdbe3b52  vmovaps xmm1, [rsp+0x10]
00007531fdbe3b58  vmovaps xmm2, [rsp+0x20]
00007531fdbe3b5e  vmovaps xmm3, [rsp+0x30]
00007531fdbe3b64  vmovaps xmm4, [rsp+0x40]
00007531fdbe3b6a  vmovaps xmm5, [rsp+0x50]
00007531fdbe3b70  vmovaps xmm6, [rsp+0x60]
00007531fdbe3b76  vmovaps xmm7, [rsp+0x70]
00007531fdbe3b7c  vmovaps xmm8, [rsp+0x80]
00007531fdbe3b85  vmovaps xmm9, [rsp+0x90]
00007531fdbe3b8e  vmovaps xmm10, [rsp+0xA0]
00007531fdbe3b97  vmovaps xmm11, [rsp+0xB0]
00007531fdbe3ba0  vmovaps xmm12, [rsp+0xC0]
00007531fdbe3ba9  vmovaps xmm13, [rsp+0xD0]
00007531fdbe3bb2  vmovaps xmm14, [rsp+0xE0]
00007531fdbe3bbb  add rsp, 0xF0
00007531fdbe3bc2  pop r11
00007531fdbe3bc4  pop r10
00007531fdbe3bc6  pop r9
00007531fdbe3bc8  pop r8
00007531fdbe3bca  pop rsi
00007531fdbe3bcb  pop rdi
00007531fdbe3bcc  pop rdx
00007531fdbe3bcd  pop rcx
00007531fdbe3bce  pop rax
00007531fdbe3bcf  add rsp, 0x08
00007531fdbe3bd3  jmp 0x00007531FDBDF838
00007531fdbe3bd8  sub rsp, 0x08
00007531fdbe3bdc  push rax
00007531fdbe3bdd  push rcx
00007531fdbe3bde  push rdx
00007531fdbe3bdf  push rdi
00007531fdbe3be0  push rsi
00007531fdbe3be1  push r8
00007531fdbe3be3  push r9
00007531fdbe3be5  push r10
00007531fdbe3be7  push r11
00007531fdbe3be9  sub rsp, 0xF0
00007531fdbe3bf0  vmovaps [rsp], xmm0
00007531fdbe3bf5  vmovaps [rsp+0x10], xmm1
00007531fdbe3bfb  vmovaps [rsp+0x20], xmm2
00007531fdbe3c01  vmovaps [rsp+0x30], xmm3
00007531fdbe3c07  vmovaps [rsp+0x40], xmm4
00007531fdbe3c0d  vmovaps [rsp+0x50], xmm5
00007531fdbe3c13  vmovaps [rsp+0x60], xmm6
00007531fdbe3c19  vmovaps [rsp+0x70], xmm8
00007531fdbe3c1f  vmovaps [rsp+0x80], xmm9
00007531fdbe3c28  vmovaps [rsp+0x90], xmm10
00007531fdbe3c31  vmovaps [rsp+0xA0], xmm11
00007531fdbe3c3a  vmovaps [rsp+0xB0], xmm12
00007531fdbe3c43  vmovaps [rsp+0xC0], xmm13
00007531fdbe3c4c  vmovaps [rsp+0xD0], xmm14
00007531fdbe3c55  vmovaps [rsp+0xE0], xmm15
00007531fdbe3c5e  sub rsp, 0x30
00007531fdbe3c62  movaps [rsp], xmm7
00007531fdbe3c66  movaps [rsp+0x10], xmm11
00007531fdbe3c6c  movaps [rsp+0x20], xmm9
00007531fdbe3c72  lea rdi, [rsp]
00007531fdbe3c76  mov esi, 0x00
00007531fdbe3c7b  mov rax, 0x59ED111DF530
00007531fdbe3c85  call rax
00007531fdbe3c87  movaps xmm7, [rsp]
00007531fdbe3c8b  add rsp, 0x30
00007531fdbe3c8f  vmovaps xmm0, [rsp]
00007531fdbe3c94  vmovaps xmm1, [rsp+0x10]
00007531fdbe3c9a  vmovaps xmm2, [rsp+0x20]
00007531fdbe3ca0  vmovaps xmm3, [rsp+0x30]
00007531fdbe3ca6  vmovaps xmm4, [rsp+0x40]
00007531fdbe3cac  vmovaps xmm5, [rsp+0x50]
00007531fdbe3cb2  vmovaps xmm6, [rsp+0x60]
00007531fdbe3cb8  vmovaps xmm8, [rsp+0x70]
00007531fdbe3cbe  vmovaps xmm9, [rsp+0x80]
00007531fdbe3cc7  vmovaps xmm10, [rsp+0x90]
00007531fdbe3cd0  vmovaps xmm11, [rsp+0xA0]
00007531fdbe3cd9  vmovaps xmm12, [rsp+0xB0]
00007531fdbe3ce2  vmovaps xmm13, [rsp+0xC0]
00007531fdbe3ceb  vmovaps xmm14, [rsp+0xD0]
00007531fdbe3cf4  vmovaps xmm15, [rsp+0xE0]
00007531fdbe3cfd  add rsp, 0xF0
00007531fdbe3d04  pop r11
00007531fdbe3d06  pop r10
00007531fdbe3d08  pop r9
00007531fdbe3d0a  pop r8
00007531fdbe3d0c  pop rsi
00007531fdbe3d0d  pop rdi
00007531fdbe3d0e  pop rdx
00007531fdbe3d0f  pop rcx
00007531fdbe3d10  pop rax
00007531fdbe3d11  add rsp, 0x08
00007531fdbe3d15  jmp 0x00007531FDBDF865
00007531fdbe3d1a  sub rsp, 0x08
00007531fdbe3d1e  push rax
00007531fdbe3d1f  push rcx
00007531fdbe3d20  push rdx
00007531fdbe3d21  push rdi
00007531fdbe3d22  push rsi
00007531fdbe3d23  push r8
00007531fdbe3d25  push r9
00007531fdbe3d27  push r10
00007531fdbe3d29  push r11
00007531fdbe3d2b  sub rsp, 0xF0
00007531fdbe3d32  vmovaps [rsp], xmm0
00007531fdbe3d37  vmovaps [rsp+0x10], xmm1
00007531fdbe3d3d  vmovaps [rsp+0x20], xmm2
00007531fdbe3d43  vmovaps [rsp+0x30], xmm3
00007531fdbe3d49  vmovaps [rsp+0x40], xmm4
00007531fdbe3d4f  vmovaps [rsp+0x50], xmm5
00007531fdbe3d55  vmovaps [rsp+0x60], xmm6
00007531fdbe3d5b  vmovaps [rsp+0x70], xmm7
00007531fdbe3d61  vmovaps [rsp+0x80], xmm8
00007531fdbe3d6a  vmovaps [rsp+0x90], xmm9
00007531fdbe3d73  vmovaps [rsp+0xA0], xmm10
00007531fdbe3d7c  vmovaps [rsp+0xB0], xmm12
00007531fdbe3d85  vmovaps [rsp+0xC0], xmm13
00007531fdbe3d8e  vmovaps [rsp+0xD0], xmm14
00007531fdbe3d97  vmovaps [rsp+0xE0], xmm15
00007531fdbe3da0  sub rsp, 0x30
00007531fdbe3da4  movaps [rsp], xmm11
00007531fdbe3da9  movaps [rsp+0x10], xmm10
00007531fdbe3daf  movaps [rsp+0x20], xmm14
00007531fdbe3db5  lea rdi, [rsp]
00007531fdbe3db9  mov esi, 0x00
00007531fdbe3dbe  mov rax, 0x59ED111DF530
00007531fdbe3dc8  call rax
00007531fdbe3dca  movaps xmm11, [rsp]
00007531fdbe3dcf  add rsp, 0x30
00007531fdbe3dd3  vmovaps xmm0, [rsp]
00007531fdbe3dd8  vmovaps xmm1, [rsp+0x10]
00007531fdbe3dde  vmovaps xmm2, [rsp+0x20]
00007531fdbe3de4  vmovaps xmm3, [rsp+0x30]
00007531fdbe3dea  vmovaps xmm4, [rsp+0x40]
00007531fdbe3df0  vmovaps xmm5, [rsp+0x50]
00007531fdbe3df6  vmovaps xmm6, [rsp+0x60]
00007531fdbe3dfc  vmovaps xmm7, [rsp+0x70]
00007531fdbe3e02  vmovaps xmm8, [rsp+0x80]
00007531fdbe3e0b  vmovaps xmm9, [rsp+0x90]
00007531fdbe3e14  vmovaps xmm10, [rsp+0xA0]
00007531fdbe3e1d  vmovaps xmm12, [rsp+0xB0]
00007531fdbe3e26  vmovaps xmm13, [rsp+0xC0]
00007531fdbe3e2f  vmovaps xmm14, [rsp+0xD0]
00007531fdbe3e38  vmovaps xmm15, [rsp+0xE0]
00007531fdbe3e41  add rsp, 0xF0
00007531fdbe3e48  pop r11
00007531fdbe3e4a  pop r10
00007531fdbe3e4c  pop r9
00007531fdbe3e4e  pop r8
00007531fdbe3e50  pop rsi
00007531fdbe3e51  pop rdi
00007531fdbe3e52  pop rdx
00007531fdbe3e53  pop rcx
00007531fdbe3e54  pop rax
00007531fdbe3e55  add rsp, 0x08
00007531fdbe3e59  jmp 0x00007531FDBDF880
00007531fdbe3e5e  call 0x00007531FDAC33A0
00007531fdbe3e63  jmp 0x00007531FDBDF88A
00007531fdbe3e68  sub rsp, 0x08
00007531fdbe3e6c  push rax
00007531fdbe3e6d  push rcx
00007531fdbe3e6e  push rdx
00007531fdbe3e6f  push rdi
00007531fdbe3e70  push rsi
00007531fdbe3e71  push r8
00007531fdbe3e73  push r9
00007531fdbe3e75  push r10
00007531fdbe3e77  push r11
00007531fdbe3e79  sub rsp, 0xF0
00007531fdbe3e80  vmovaps [rsp], xmm0
00007531fdbe3e85  vmovaps [rsp+0x10], xmm1
00007531fdbe3e8b  vmovaps [rsp+0x20], xmm2
00007531fdbe3e91  vmovaps [rsp+0x30], xmm3
00007531fdbe3e97  vmovaps [rsp+0x40], xmm4
00007531fdbe3e9d  vmovaps [rsp+0x50], xmm5
00007531fdbe3ea3  vmovaps [rsp+0x60], xmm6
00007531fdbe3ea9  vmovaps [rsp+0x70], xmm7
00007531fdbe3eaf  vmovaps [rsp+0x80], xmm8
00007531fdbe3eb8  vmovaps [rsp+0x90], xmm9
00007531fdbe3ec1  vmovaps [rsp+0xA0], xmm11
00007531fdbe3eca  vmovaps [rsp+0xB0], xmm12
00007531fdbe3ed3  vmovaps [rsp+0xC0], xmm13
00007531fdbe3edc  vmovaps [rsp+0xD0], xmm14
00007531fdbe3ee5  vmovaps [rsp+0xE0], xmm15
00007531fdbe3eee  sub rsp, 0x30
00007531fdbe3ef2  movaps [rsp], xmm10
00007531fdbe3ef7  movaps [rsp+0x10], xmm1
00007531fdbe3efc  movaps [rsp+0x20], xmm12
00007531fdbe3f02  lea rdi, [rsp]
00007531fdbe3f06  mov esi, 0x00
00007531fdbe3f0b  mov rax, 0x59ED111DF530
00007531fdbe3f15  call rax
00007531fdbe3f17  movaps xmm10, [rsp]
00007531fdbe3f1c  add rsp, 0x30
00007531fdbe3f20  vmovaps xmm0, [rsp]
00007531fdbe3f25  vmovaps xmm1, [rsp+0x10]
00007531fdbe3f2b  vmovaps xmm2, [rsp+0x20]
00007531fdbe3f31  vmovaps xmm3, [rsp+0x30]
00007531fdbe3f37  vmovaps xmm4, [rsp+0x40]
00007531fdbe3f3d  vmovaps xmm5, [rsp+0x50]
00007531fdbe3f43  vmovaps xmm6, [rsp+0x60]
00007531fdbe3f49  vmovaps xmm7, [rsp+0x70]
00007531fdbe3f4f  vmovaps xmm8, [rsp+0x80]
00007531fdbe3f58  vmovaps xmm9, [rsp+0x90]
00007531fdbe3f61  vmovaps xmm11, [rsp+0xA0]
00007531fdbe3f6a  vmovaps xmm12, [rsp+0xB0]
00007531fdbe3f73  vmovaps xmm13, [rsp+0xC0]
00007531fdbe3f7c  vmovaps xmm14, [rsp+0xD0]
00007531fdbe3f85  vmovaps xmm15, [rsp+0xE0]
00007531fdbe3f8e  add rsp, 0xF0
00007531fdbe3f95  pop r11
00007531fdbe3f97  pop r10
00007531fdbe3f99  pop r9
00007531fdbe3f9b  pop r8
00007531fdbe3f9d  pop rsi
00007531fdbe3f9e  pop rdi
00007531fdbe3f9f  pop rdx
00007531fdbe3fa0  pop rcx
00007531fdbe3fa1  pop rax
00007531fdbe3fa2  add rsp, 0x08
00007531fdbe3fa6  jmp 0x00007531FDBDF8AD
00007531fdbe3fab  sub rsp, 0x08
00007531fdbe3faf  push rax
00007531fdbe3fb0  push rcx
00007531fdbe3fb1  push rdx
00007531fdbe3fb2  push rdi
00007531fdbe3fb3  push rsi
00007531fdbe3fb4  push r8
00007531fdbe3fb6  push r9
00007531fdbe3fb8  push r10
00007531fdbe3fba  push r11
00007531fdbe3fbc  sub rsp, 0xF0
00007531fdbe3fc3  vmovaps [rsp], xmm0
00007531fdbe3fc8  vmovaps [rsp+0x10], xmm1
00007531fdbe3fce  vmovaps [rsp+0x20], xmm2
00007531fdbe3fd4  vmovaps [rsp+0x30], xmm3
00007531fdbe3fda  vmovaps [rsp+0x40], xmm4
00007531fdbe3fe0  vmovaps [rsp+0x50], xmm5
00007531fdbe3fe6  vmovaps [rsp+0x60], xmm6
00007531fdbe3fec  vmovaps [rsp+0x70], xmm7
00007531fdbe3ff2  vmovaps [rsp+0x80], xmm8
00007531fdbe3ffb  vmovaps [rsp+0x90], xmm9
00007531fdbe4004  vmovaps [rsp+0xA0], xmm10
00007531fdbe400d  vmovaps [rsp+0xB0], xmm11
00007531fdbe4016  vmovaps [rsp+0xC0], xmm13
00007531fdbe401f  vmovaps [rsp+0xD0], xmm14
00007531fdbe4028  vmovaps [rsp+0xE0], xmm15
00007531fdbe4031  sub rsp, 0x30
00007531fdbe4035  movaps [rsp], xmm12
00007531fdbe403a  movaps [rsp+0x10], xmm14
00007531fdbe4040  movaps [rsp+0x20], xmm1
00007531fdbe4045  lea rdi, [rsp]
00007531fdbe4049  mov esi, 0x00
00007531fdbe404e  mov rax, 0x59ED111DF530
00007531fdbe4058  call rax
00007531fdbe405a  movaps xmm12, [rsp]
00007531fdbe405f  add rsp, 0x30
00007531fdbe4063  vmovaps xmm0, [rsp]
00007531fdbe4068  vmovaps xmm1, [rsp+0x10]
00007531fdbe406e  vmovaps xmm2, [rsp+0x20]
00007531fdbe4074  vmovaps xmm3, [rsp+0x30]
00007531fdbe407a  vmovaps xmm4, [rsp+0x40]
00007531fdbe4080  vmovaps xmm5, [rsp+0x50]
00007531fdbe4086  vmovaps xmm6, [rsp+0x60]
00007531fdbe408c  vmovaps xmm7, [rsp+0x70]
00007531fdbe4092  vmovaps xmm8, [rsp+0x80]
00007531fdbe409b  vmovaps xmm9, [rsp+0x90]
00007531fdbe40a4  vmovaps xmm10, [rsp+0xA0]
00007531fdbe40ad  vmovaps xmm11, [rsp+0xB0]
00007531fdbe40b6  vmovaps xmm13, [rsp+0xC0]
00007531fdbe40bf  vmovaps xmm14, [rsp+0xD0]
00007531fdbe40c8  vmovaps xmm15, [rsp+0xE0]
00007531fdbe40d1  add rsp, 0xF0
00007531fdbe40d8  pop r11
00007531fdbe40da  pop r10
00007531fdbe40dc  pop r9
00007531fdbe40de  pop r8
00007531fdbe40e0  pop rsi
00007531fdbe40e1  pop rdi
00007531fdbe40e2  pop rdx
00007531fdbe40e3  pop rcx
00007531fdbe40e4  pop rax
00007531fdbe40e5  add rsp, 0x08
00007531fdbe40e9  jmp 0x00007531FDBDF8DC
00007531fdbe40ee  sub rsp, 0x08
00007531fdbe40f2  push rax
00007531fdbe40f3  push rcx
00007531fdbe40f4  push rdx
00007531fdbe40f5  push rdi
00007531fdbe40f6  push rsi
00007531fdbe40f7  push r8
00007531fdbe40f9  push r9
00007531fdbe40fb  push r10
00007531fdbe40fd  push r11
00007531fdbe40ff  sub rsp, 0xF0
00007531fdbe4106  vmovaps [rsp], xmm0
00007531fdbe410b  vmovaps [rsp+0x10], xmm1
00007531fdbe4111  vmovaps [rsp+0x20], xmm2
00007531fdbe4117  vmovaps [rsp+0x30], xmm3
00007531fdbe411d  vmovaps [rsp+0x40], xmm4
00007531fdbe4123  vmovaps [rsp+0x50], xmm5
00007531fdbe4129  vmovaps [rsp+0x60], xmm6
00007531fdbe412f  vmovaps [rsp+0x70], xmm7
00007531fdbe4135  vmovaps [rsp+0x80], xmm8
00007531fdbe413e  vmovaps [rsp+0x90], xmm9
00007531fdbe4147  vmovaps [rsp+0xA0], xmm10
00007531fdbe4150  vmovaps [rsp+0xB0], xmm11
00007531fdbe4159  vmovaps [rsp+0xC0], xmm12
00007531fdbe4162  vmovaps [rsp+0xD0], xmm13
00007531fdbe416b  vmovaps [rsp+0xE0], xmm15
00007531fdbe4174  sub rsp, 0x30
00007531fdbe4178  movaps [rsp], xmm14
00007531fdbe417d  movaps [rsp+0x10], xmm9
00007531fdbe4183  movaps [rsp+0x20], xmm1
00007531fdbe4188  lea rdi, [rsp]
00007531fdbe418c  mov esi, 0x00
00007531fdbe4191  mov rax, 0x59ED111DF530
00007531fdbe419b  call rax
00007531fdbe419d  movaps xmm14, [rsp]
00007531fdbe41a2  add rsp, 0x30
00007531fdbe41a6  vmovaps xmm0, [rsp]
00007531fdbe41ab  vmovaps xmm1, [rsp+0x10]
00007531fdbe41b1  vmovaps xmm2, [rsp+0x20]
00007531fdbe41b7  vmovaps xmm3, [rsp+0x30]
00007531fdbe41bd  vmovaps xmm4, [rsp+0x40]
00007531fdbe41c3  vmovaps xmm5, [rsp+0x50]
00007531fdbe41c9  vmovaps xmm6, [rsp+0x60]
00007531fdbe41cf  vmovaps xmm7, [rsp+0x70]
00007531fdbe41d5  vmovaps xmm8, [rsp+0x80]
00007531fdbe41de  vmovaps xmm9, [rsp+0x90]
00007531fdbe41e7  vmovaps xmm10, [rsp+0xA0]
00007531fdbe41f0  vmovaps xmm11, [rsp+0xB0]
00007531fdbe41f9  vmovaps xmm12, [rsp+0xC0]
00007531fdbe4202  vmovaps xmm13, [rsp+0xD0]
00007531fdbe420b  vmovaps xmm15, [rsp+0xE0]
00007531fdbe4214  add rsp, 0xF0
00007531fdbe421b  pop r11
00007531fdbe421d  pop r10
00007531fdbe421f  pop r9
00007531fdbe4221  pop r8
00007531fdbe4223  pop rsi
00007531fdbe4224  pop rdi
00007531fdbe4225  pop rdx
00007531fdbe4226  pop rcx
00007531fdbe4227  pop rax
00007531fdbe4228  add rsp, 0x08
00007531fdbe422c  jmp 0x00007531FDBDF90B
00007531fdbe4231  sub rsp, 0x08
00007531fdbe4235  push rax
00007531fdbe4236  push rcx
00007531fdbe4237  push rdx
00007531fdbe4238  push rdi
00007531fdbe4239  push rsi
00007531fdbe423a  push r8
00007531fdbe423c  push r9
00007531fdbe423e  push r10
00007531fdbe4240  push r11
00007531fdbe4242  sub rsp, 0xF0
00007531fdbe4249  vmovaps [rsp], xmm0
00007531fdbe424e  vmovaps [rsp+0x10], xmm2
00007531fdbe4254  vmovaps [rsp+0x20], xmm3
00007531fdbe425a  vmovaps [rsp+0x30], xmm4
00007531fdbe4260  vmovaps [rsp+0x40], xmm5
00007531fdbe4266  vmovaps [rsp+0x50], xmm6
00007531fdbe426c  vmovaps [rsp+0x60], xmm7
00007531fdbe4272  vmovaps [rsp+0x70], xmm8
00007531fdbe4278  vmovaps [rsp+0x80], xmm9
00007531fdbe4281  vmovaps [rsp+0x90], xmm10
00007531fdbe428a  vmovaps [rsp+0xA0], xmm11
00007531fdbe4293  vmovaps [rsp+0xB0], xmm12
00007531fdbe429c  vmovaps [rsp+0xC0], xmm13
00007531fdbe42a5  vmovaps [rsp+0xD0], xmm14
00007531fdbe42ae  vmovaps [rsp+0xE0], xmm15
00007531fdbe42b7  sub rsp, 0x30
00007531fdbe42bb  movaps [rsp], xmm1
00007531fdbe42bf  movaps [rsp+0x10], xmm13
00007531fdbe42c5  movaps [rsp+0x20], xmm8
00007531fdbe42cb  lea rdi, [rsp]
00007531fdbe42cf  mov esi, 0x00
00007531fdbe42d4  mov rax, 0x59ED111DF530
00007531fdbe42de  call rax
00007531fdbe42e0  movaps xmm1, [rsp]
00007531fdbe42e4  add rsp, 0x30
00007531fdbe42e8  vmovaps xmm0, [rsp]
00007531fdbe42ed  vmovaps xmm2, [rsp+0x10]
00007531fdbe42f3  vmovaps xmm3, [rsp+0x20]
00007531fdbe42f9  vmovaps xmm4, [rsp+0x30]
00007531fdbe42ff  vmovaps xmm5, [rsp+0x40]
00007531fdbe4305  vmovaps xmm6, [rsp+0x50]
00007531fdbe430b  vmovaps xmm7, [rsp+0x60]
00007531fdbe4311  vmovaps xmm8, [rsp+0x70]
00007531fdbe4317  vmovaps xmm9, [rsp+0x80]
00007531fdbe4320  vmovaps xmm10, [rsp+0x90]
00007531fdbe4329  vmovaps xmm11, [rsp+0xA0]
00007531fdbe4332  vmovaps xmm12, [rsp+0xB0]
00007531fdbe433b  vmovaps xmm13, [rsp+0xC0]
00007531fdbe4344  vmovaps xmm14, [rsp+0xD0]
00007531fdbe434d  vmovaps xmm15, [rsp+0xE0]
00007531fdbe4356  add rsp, 0xF0
00007531fdbe435d  pop r11
00007531fdbe435f  pop r10
00007531fdbe4361  pop r9
00007531fdbe4363  pop r8
00007531fdbe4365  pop rsi
00007531fdbe4366  pop rdi
00007531fdbe4367  pop rdx
00007531fdbe4368  pop rcx
00007531fdbe4369  pop rax
00007531fdbe436a  add rsp, 0x08
00007531fdbe436e  jmp 0x00007531FDBDF92D
00007531fdbe4373  call 0x00007531FDA0C260
00007531fdbe4378  jmp 0x00007531FDBDF93B
00007531fdbe437d  call 0x00007531FDABD750
00007531fdbe4382  jmp 0x00007531FDBDF945
00007531fdbe4387  sub rsp, 0x08
00007531fdbe438b  push rax
00007531fdbe438c  push rcx
00007531fdbe438d  push rdx
00007531fdbe438e  push rdi
00007531fdbe438f  push rsi
00007531fdbe4390  push r8
00007531fdbe4392  push r9
00007531fdbe4394  push r10
00007531fdbe4396  push r11
00007531fdbe4398  sub rsp, 0xF0
00007531fdbe439f  vmovaps [rsp], xmm0
00007531fdbe43a4  vmovaps [rsp+0x10], xmm1
00007531fdbe43aa  vmovaps [rsp+0x20], xmm2
00007531fdbe43b0  vmovaps [rsp+0x30], xmm3
00007531fdbe43b6  vmovaps [rsp+0x40], xmm4
00007531fdbe43bc  vmovaps [rsp+0x50], xmm5
00007531fdbe43c2  vmovaps [rsp+0x60], xmm6
00007531fdbe43c8  vmovaps [rsp+0x70], xmm7
00007531fdbe43ce  vmovaps [rsp+0x80], xmm9
00007531fdbe43d7  vmovaps [rsp+0x90], xmm10
00007531fdbe43e0  vmovaps [rsp+0xA0], xmm11
00007531fdbe43e9  vmovaps [rsp+0xB0], xmm12
00007531fdbe43f2  vmovaps [rsp+0xC0], xmm13
00007531fdbe43fb  vmovaps [rsp+0xD0], xmm14
00007531fdbe4404  vmovaps [rsp+0xE0], xmm15
00007531fdbe440d  sub rsp, 0x30
00007531fdbe4411  movaps [rsp], xmm8
00007531fdbe4416  movaps [rsp+0x10], xmm15
00007531fdbe441c  movaps [rsp+0x20], xmm7
00007531fdbe4421  lea rdi, [rsp]
00007531fdbe4425  mov esi, 0x00
00007531fdbe442a  mov rax, 0x59ED111DF530
00007531fdbe4434  call rax
00007531fdbe4436  movaps xmm8, [rsp]
00007531fdbe443b  add rsp, 0x30
00007531fdbe443f  vmovaps xmm0, [rsp]
00007531fdbe4444  vmovaps xmm1, [rsp+0x10]
00007531fdbe444a  vmovaps xmm2, [rsp+0x20]
00007531fdbe4450  vmovaps xmm3, [rsp+0x30]
00007531fdbe4456  vmovaps xmm4, [rsp+0x40]
00007531fdbe445c  vmovaps xmm5, [rsp+0x50]
00007531fdbe4462  vmovaps xmm6, [rsp+0x60]
00007531fdbe4468  vmovaps xmm7, [rsp+0x70]
00007531fdbe446e  vmovaps xmm9, [rsp+0x80]
00007531fdbe4477  vmovaps xmm10, [rsp+0x90]
00007531fdbe4480  vmovaps xmm11, [rsp+0xA0]
00007531fdbe4489  vmovaps xmm12, [rsp+0xB0]
00007531fdbe4492  vmovaps xmm13, [rsp+0xC0]
00007531fdbe449b  vmovaps xmm14, [rsp+0xD0]
00007531fdbe44a4  vmovaps xmm15, [rsp+0xE0]
00007531fdbe44ad  add rsp, 0xF0
00007531fdbe44b4  pop r11
00007531fdbe44b6  pop r10
00007531fdbe44b8  pop r9
00007531fdbe44ba  pop r8
00007531fdbe44bc  pop rsi
00007531fdbe44bd  pop rdi
00007531fdbe44be  pop rdx
00007531fdbe44bf  pop rcx
00007531fdbe44c0  pop rax
00007531fdbe44c1  add rsp, 0x08
00007531fdbe44c5  jmp 0x00007531FDBDF967
00007531fdbe44ca  sub rsp, 0x08
00007531fdbe44ce  push rax
00007531fdbe44cf  push rcx
00007531fdbe44d0  push rdx
00007531fdbe44d1  push rdi
00007531fdbe44d2  push rsi
00007531fdbe44d3  push r8
00007531fdbe44d5  push r9
00007531fdbe44d7  push r10
00007531fdbe44d9  push r11
00007531fdbe44db  sub rsp, 0xF0
00007531fdbe44e2  vmovaps [rsp], xmm0
00007531fdbe44e7  vmovaps [rsp+0x10], xmm1
00007531fdbe44ed  vmovaps [rsp+0x20], xmm2
00007531fdbe44f3  vmovaps [rsp+0x30], xmm3
00007531fdbe44f9  vmovaps [rsp+0x40], xmm4
00007531fdbe44ff  vmovaps [rsp+0x50], xmm5
00007531fdbe4505  vmovaps [rsp+0x60], xmm6
00007531fdbe450b  vmovaps [rsp+0x70], xmm8
00007531fdbe4511  vmovaps [rsp+0x80], xmm9
00007531fdbe451a  vmovaps [rsp+0x90], xmm10
00007531fdbe4523  vmovaps [rsp+0xA0], xmm11
00007531fdbe452c  vmovaps [rsp+0xB0], xmm12
00007531fdbe4535  vmovaps [rsp+0xC0], xmm13
00007531fdbe453e  vmovaps [rsp+0xD0], xmm14
00007531fdbe4547  vmovaps [rsp+0xE0], xmm15
00007531fdbe4550  sub rsp, 0x30
00007531fdbe4554  movaps [rsp], xmm7
00007531fdbe4558  movaps [rsp+0x10], xmm9
00007531fdbe455e  movaps [rsp+0x20], xmm15
00007531fdbe4564  lea rdi, [rsp]
00007531fdbe4568  mov esi, 0x00
00007531fdbe456d  mov rax, 0x59ED111DF530
00007531fdbe4577  call rax
00007531fdbe4579  movaps xmm7, [rsp]
00007531fdbe457d  add rsp, 0x30
00007531fdbe4581  vmovaps xmm0, [rsp]
00007531fdbe4586  vmovaps xmm1, [rsp+0x10]
00007531fdbe458c  vmovaps xmm2, [rsp+0x20]
00007531fdbe4592  vmovaps xmm3, [rsp+0x30]
00007531fdbe4598  vmovaps xmm4, [rsp+0x40]
00007531fdbe459e  vmovaps xmm5, [rsp+0x50]
00007531fdbe45a4  vmovaps xmm6, [rsp+0x60]
00007531fdbe45aa  vmovaps xmm8, [rsp+0x70]
00007531fdbe45b0  vmovaps xmm9, [rsp+0x80]
00007531fdbe45b9  vmovaps xmm10, [rsp+0x90]
00007531fdbe45c2  vmovaps xmm11, [rsp+0xA0]
00007531fdbe45cb  vmovaps xmm12, [rsp+0xB0]
00007531fdbe45d4  vmovaps xmm13, [rsp+0xC0]
00007531fdbe45dd  vmovaps xmm14, [rsp+0xD0]
00007531fdbe45e6  vmovaps xmm15, [rsp+0xE0]
00007531fdbe45ef  add rsp, 0xF0
00007531fdbe45f6  pop r11
00007531fdbe45f8  pop r10
00007531fdbe45fa  pop r9
00007531fdbe45fc  pop r8
00007531fdbe45fe  pop rsi
00007531fdbe45ff  pop rdi
00007531fdbe4600  pop rdx
00007531fdbe4601  pop rcx
00007531fdbe4602  pop rax
00007531fdbe4603  add rsp, 0x08
00007531fdbe4607  jmp 0x00007531FDBDF994
00007531fdbe460c  sub rsp, 0x08
00007531fdbe4610  push rax
00007531fdbe4611  push rcx
00007531fdbe4612  push rdx
00007531fdbe4613  push rdi
00007531fdbe4614  push rsi
00007531fdbe4615  push r8
00007531fdbe4617  push r9
00007531fdbe4619  push r10
00007531fdbe461b  push r11
00007531fdbe461d  sub rsp, 0xF0
00007531fdbe4624  vmovaps [rsp], xmm0
00007531fdbe4629  vmovaps [rsp+0x10], xmm1
00007531fdbe462f  vmovaps [rsp+0x20], xmm2
00007531fdbe4635  vmovaps [rsp+0x30], xmm3
00007531fdbe463b  vmovaps [rsp+0x40], xmm4
00007531fdbe4641  vmovaps [rsp+0x50], xmm5
00007531fdbe4647  vmovaps [rsp+0x60], xmm6
00007531fdbe464d  vmovaps [rsp+0x70], xmm7
00007531fdbe4653  vmovaps [rsp+0x80], xmm8
00007531fdbe465c  vmovaps [rsp+0x90], xmm10
00007531fdbe4665  vmovaps [rsp+0xA0], xmm11
00007531fdbe466e  vmovaps [rsp+0xB0], xmm12
00007531fdbe4677  vmovaps [rsp+0xC0], xmm13
00007531fdbe4680  vmovaps [rsp+0xD0], xmm14
00007531fdbe4689  vmovaps [rsp+0xE0], xmm15
00007531fdbe4692  sub rsp, 0x30
00007531fdbe4696  movaps [rsp], xmm9
00007531fdbe469b  movaps [rsp+0x10], xmm13
00007531fdbe46a1  movaps [rsp+0x20], xmm15
00007531fdbe46a7  lea rdi, [rsp]
00007531fdbe46ab  mov esi, 0x00
00007531fdbe46b0  mov rax, 0x59ED111DF530
00007531fdbe46ba  call rax
00007531fdbe46bc  movaps xmm9, [rsp]
00007531fdbe46c1  add rsp, 0x30
00007531fdbe46c5  vmovaps xmm0, [rsp]
00007531fdbe46ca  vmovaps xmm1, [rsp+0x10]
00007531fdbe46d0  vmovaps xmm2, [rsp+0x20]
00007531fdbe46d6  vmovaps xmm3, [rsp+0x30]
00007531fdbe46dc  vmovaps xmm4, [rsp+0x40]
00007531fdbe46e2  vmovaps xmm5, [rsp+0x50]
00007531fdbe46e8  vmovaps xmm6, [rsp+0x60]
00007531fdbe46ee  vmovaps xmm7, [rsp+0x70]
00007531fdbe46f4  vmovaps xmm8, [rsp+0x80]
00007531fdbe46fd  vmovaps xmm10, [rsp+0x90]
00007531fdbe4706  vmovaps xmm11, [rsp+0xA0]
00007531fdbe470f  vmovaps xmm12, [rsp+0xB0]
00007531fdbe4718  vmovaps xmm13, [rsp+0xC0]
00007531fdbe4721  vmovaps xmm14, [rsp+0xD0]
00007531fdbe472a  vmovaps xmm15, [rsp+0xE0]
00007531fdbe4733  add rsp, 0xF0
00007531fdbe473a  pop r11
00007531fdbe473c  pop r10
00007531fdbe473e  pop r9
00007531fdbe4740  pop r8
00007531fdbe4742  pop rsi
00007531fdbe4743  pop rdi
00007531fdbe4744  pop rdx
00007531fdbe4745  pop rcx
00007531fdbe4746  pop rax
00007531fdbe4747  add rsp, 0x08
00007531fdbe474b  jmp 0x00007531FDBDF9C2
00007531fdbe4750  sub rsp, 0x08
00007531fdbe4754  push rax
00007531fdbe4755  push rcx
00007531fdbe4756  push rdx
00007531fdbe4757  push rdi
00007531fdbe4758  push rsi
00007531fdbe4759  push r8
00007531fdbe475b  push r9
00007531fdbe475d  push r10
00007531fdbe475f  push r11
00007531fdbe4761  sub rsp, 0xF0
00007531fdbe4768  vmovaps [rsp], xmm0
00007531fdbe476d  vmovaps [rsp+0x10], xmm1
00007531fdbe4773  vmovaps [rsp+0x20], xmm2
00007531fdbe4779  vmovaps [rsp+0x30], xmm3
00007531fdbe477f  vmovaps [rsp+0x40], xmm4
00007531fdbe4785  vmovaps [rsp+0x50], xmm5
00007531fdbe478b  vmovaps [rsp+0x60], xmm6
00007531fdbe4791  vmovaps [rsp+0x70], xmm7
00007531fdbe4797  vmovaps [rsp+0x80], xmm8
00007531fdbe47a0  vmovaps [rsp+0x90], xmm9
00007531fdbe47a9  vmovaps [rsp+0xA0], xmm10
00007531fdbe47b2  vmovaps [rsp+0xB0], xmm11
00007531fdbe47bb  vmovaps [rsp+0xC0], xmm12
00007531fdbe47c4  vmovaps [rsp+0xD0], xmm13
00007531fdbe47cd  vmovaps [rsp+0xE0], xmm14
00007531fdbe47d6  sub rsp, 0x30
00007531fdbe47da  movaps [rsp], xmm15
00007531fdbe47df  movaps [rsp+0x10], xmm11
00007531fdbe47e5  movaps [rsp+0x20], xmm12
00007531fdbe47eb  lea rdi, [rsp]
00007531fdbe47ef  mov esi, 0x00
00007531fdbe47f4  mov rax, 0x59ED111DF530
00007531fdbe47fe  call rax
00007531fdbe4800  movaps xmm15, [rsp]
00007531fdbe4805  add rsp, 0x30
00007531fdbe4809  vmovaps xmm0, [rsp]
00007531fdbe480e  vmovaps xmm1, [rsp+0x10]
00007531fdbe4814  vmovaps xmm2, [rsp+0x20]
00007531fdbe481a  vmovaps xmm3, [rsp+0x30]
00007531fdbe4820  vmovaps xmm4, [rsp+0x40]
00007531fdbe4826  vmovaps xmm5, [rsp+0x50]
00007531fdbe482c  vmovaps xmm6, [rsp+0x60]
00007531fdbe4832  vmovaps xmm7, [rsp+0x70]
00007531fdbe4838  vmovaps xmm8, [rsp+0x80]
00007531fdbe4841  vmovaps xmm9, [rsp+0x90]
00007531fdbe484a  vmovaps xmm10, [rsp+0xA0]
00007531fdbe4853  vmovaps xmm11, [rsp+0xB0]
00007531fdbe485c  vmovaps xmm12, [rsp+0xC0]
00007531fdbe4865  vmovaps xmm13, [rsp+0xD0]
00007531fdbe486e  vmovaps xmm14, [rsp+0xE0]
00007531fdbe4877  add rsp, 0xF0
00007531fdbe487e  pop r11
00007531fdbe4880  pop r10
00007531fdbe4882  pop r9
00007531fdbe4884  pop r8
00007531fdbe4886  pop rsi
00007531fdbe4887  pop rdi
00007531fdbe4888  pop rdx
00007531fdbe4889  pop rcx
00007531fdbe488a  pop rax
00007531fdbe488b  add rsp, 0x08
00007531fdbe488f  jmp 0x00007531FDBDF9DD
00007531fdbe4894  sub rsp, 0x08
00007531fdbe4898  push rax
00007531fdbe4899  push rcx
00007531fdbe489a  push rdx
00007531fdbe489b  push rdi
00007531fdbe489c  push rsi
00007531fdbe489d  push r8
00007531fdbe489f  push r9
00007531fdbe48a1  push r10
00007531fdbe48a3  push r11
00007531fdbe48a5  sub rsp, 0xF0
00007531fdbe48ac  vmovaps [rsp], xmm0
00007531fdbe48b1  vmovaps [rsp+0x10], xmm1
00007531fdbe48b7  vmovaps [rsp+0x20], xmm2
00007531fdbe48bd  vmovaps [rsp+0x30], xmm3
00007531fdbe48c3  vmovaps [rsp+0x40], xmm4
00007531fdbe48c9  vmovaps [rsp+0x50], xmm5
00007531fdbe48cf  vmovaps [rsp+0x60], xmm6
00007531fdbe48d5  vmovaps [rsp+0x70], xmm7
00007531fdbe48db  vmovaps [rsp+0x80], xmm8
00007531fdbe48e4  vmovaps [rsp+0x90], xmm9
00007531fdbe48ed  vmovaps [rsp+0xA0], xmm10
00007531fdbe48f6  vmovaps [rsp+0xB0], xmm11
00007531fdbe48ff  vmovaps [rsp+0xC0], xmm12
00007531fdbe4908  vmovaps [rsp+0xD0], xmm14
00007531fdbe4911  vmovaps [rsp+0xE0], xmm15
00007531fdbe491a  sub rsp, 0x30
00007531fdbe491e  movaps [rsp], xmm13
00007531fdbe4923  movaps [rsp+0x10], xmm10
00007531fdbe4929  movaps [rsp+0x20], xmm14
00007531fdbe492f  lea rdi, [rsp]
00007531fdbe4933  mov esi, 0x00
00007531fdbe4938  mov rax, 0x59ED111DF530
00007531fdbe4942  call rax
00007531fdbe4944  movaps xmm13, [rsp]
00007531fdbe4949  add rsp, 0x30
00007531fdbe494d  vmovaps xmm0, [rsp]
00007531fdbe4952  vmovaps xmm1, [rsp+0x10]
00007531fdbe4958  vmovaps xmm2, [rsp+0x20]
00007531fdbe495e  vmovaps xmm3, [rsp+0x30]
00007531fdbe4964  vmovaps xmm4, [rsp+0x40]
00007531fdbe496a  vmovaps xmm5, [rsp+0x50]
00007531fdbe4970  vmovaps xmm6, [rsp+0x60]
00007531fdbe4976  vmovaps xmm7, [rsp+0x70]
00007531fdbe497c  vmovaps xmm8, [rsp+0x80]
00007531fdbe4985  vmovaps xmm9, [rsp+0x90]
00007531fdbe498e  vmovaps xmm10, [rsp+0xA0]
00007531fdbe4997  vmovaps xmm11, [rsp+0xB0]
00007531fdbe49a0  vmovaps xmm12, [rsp+0xC0]
00007531fdbe49a9  vmovaps xmm14, [rsp+0xD0]
00007531fdbe49b2  vmovaps xmm15, [rsp+0xE0]
00007531fdbe49bb  add rsp, 0xF0
00007531fdbe49c2  pop r11
00007531fdbe49c4  pop r10
00007531fdbe49c6  pop r9
00007531fdbe49c8  pop r8
00007531fdbe49ca  pop rsi
00007531fdbe49cb  pop rdi
00007531fdbe49cc  pop rdx
00007531fdbe49cd  pop rcx
00007531fdbe49ce  pop rax
00007531fdbe49cf  add rsp, 0x08
00007531fdbe49d3  jmp 0x00007531FDBDFA00
00007531fdbe49d8  sub rsp, 0x08
00007531fdbe49dc  push rax
00007531fdbe49dd  push rcx
00007531fdbe49de  push rdx
00007531fdbe49df  push rdi
00007531fdbe49e0  push rsi
00007531fdbe49e1  push r8
00007531fdbe49e3  push r9
00007531fdbe49e5  push r10
00007531fdbe49e7  push r11
00007531fdbe49e9  sub rsp, 0xF0
00007531fdbe49f0  vmovaps [rsp], xmm0
00007531fdbe49f5  vmovaps [rsp+0x10], xmm1
00007531fdbe49fb  vmovaps [rsp+0x20], xmm2
00007531fdbe4a01  vmovaps [rsp+0x30], xmm3
00007531fdbe4a07  vmovaps [rsp+0x40], xmm4
00007531fdbe4a0d  vmovaps [rsp+0x50], xmm5
00007531fdbe4a13  vmovaps [rsp+0x60], xmm6
00007531fdbe4a19  vmovaps [rsp+0x70], xmm7
00007531fdbe4a1f  vmovaps [rsp+0x80], xmm8
00007531fdbe4a28  vmovaps [rsp+0x90], xmm9
00007531fdbe4a31  vmovaps [rsp+0xA0], xmm10
00007531fdbe4a3a  vmovaps [rsp+0xB0], xmm11
00007531fdbe4a43  vmovaps [rsp+0xC0], xmm12
00007531fdbe4a4c  vmovaps [rsp+0xD0], xmm13
00007531fdbe4a55  vmovaps [rsp+0xE0], xmm15
00007531fdbe4a5e  sub rsp, 0x30
00007531fdbe4a62  movaps [rsp], xmm14
00007531fdbe4a67  movaps [rsp+0x10], xmm1
00007531fdbe4a6c  movaps [rsp+0x20], xmm7
00007531fdbe4a71  lea rdi, [rsp]
00007531fdbe4a75  mov esi, 0x00
00007531fdbe4a7a  mov rax, 0x59ED111DF530
00007531fdbe4a84  call rax
00007531fdbe4a86  movaps xmm14, [rsp]
00007531fdbe4a8b  add rsp, 0x30
00007531fdbe4a8f  vmovaps xmm0, [rsp]
00007531fdbe4a94  vmovaps xmm1, [rsp+0x10]
00007531fdbe4a9a  vmovaps xmm2, [rsp+0x20]
00007531fdbe4aa0  vmovaps xmm3, [rsp+0x30]
00007531fdbe4aa6  vmovaps xmm4, [rsp+0x40]
00007531fdbe4aac  vmovaps xmm5, [rsp+0x50]
00007531fdbe4ab2  vmovaps xmm6, [rsp+0x60]
00007531fdbe4ab8  vmovaps xmm7, [rsp+0x70]
00007531fdbe4abe  vmovaps xmm8, [rsp+0x80]
00007531fdbe4ac7  vmovaps xmm9, [rsp+0x90]
00007531fdbe4ad0  vmovaps xmm10, [rsp+0xA0]
00007531fdbe4ad9  vmovaps xmm11, [rsp+0xB0]
00007531fdbe4ae2  vmovaps xmm12, [rsp+0xC0]
00007531fdbe4aeb  vmovaps xmm13, [rsp+0xD0]
00007531fdbe4af4  vmovaps xmm15, [rsp+0xE0]
00007531fdbe4afd  add rsp, 0xF0
00007531fdbe4b04  pop r11
00007531fdbe4b06  pop r10
00007531fdbe4b08  pop r9
00007531fdbe4b0a  pop r8
00007531fdbe4b0c  pop rsi
00007531fdbe4b0d  pop rdi
00007531fdbe4b0e  pop rdx
00007531fdbe4b0f  pop rcx
00007531fdbe4b10  pop rax
00007531fdbe4b11  add rsp, 0x08
00007531fdbe4b15  jmp 0x00007531FDBDFA23
00007531fdbe4b1a  sub rsp, 0x08
00007531fdbe4b1e  push rax
00007531fdbe4b1f  push rcx
00007531fdbe4b20  push rdx
00007531fdbe4b21  push rdi
00007531fdbe4b22  push rsi
00007531fdbe4b23  push r8
00007531fdbe4b25  push r9
00007531fdbe4b27  push r10
00007531fdbe4b29  push r11
00007531fdbe4b2b  sub rsp, 0xF0
00007531fdbe4b32  vmovaps [rsp], xmm0
00007531fdbe4b37  vmovaps [rsp+0x10], xmm2
00007531fdbe4b3d  vmovaps [rsp+0x20], xmm3
00007531fdbe4b43  vmovaps [rsp+0x30], xmm4
00007531fdbe4b49  vmovaps [rsp+0x40], xmm5
00007531fdbe4b4f  vmovaps [rsp+0x50], xmm6
00007531fdbe4b55  vmovaps [rsp+0x60], xmm7
00007531fdbe4b5b  vmovaps [rsp+0x70], xmm8
00007531fdbe4b61  vmovaps [rsp+0x80], xmm9
00007531fdbe4b6a  vmovaps [rsp+0x90], xmm10
00007531fdbe4b73  vmovaps [rsp+0xA0], xmm11
00007531fdbe4b7c  vmovaps [rsp+0xB0], xmm12
00007531fdbe4b85  vmovaps [rsp+0xC0], xmm13
00007531fdbe4b8e  vmovaps [rsp+0xD0], xmm14
00007531fdbe4b97  vmovaps [rsp+0xE0], xmm15
00007531fdbe4ba0  sub rsp, 0x30
00007531fdbe4ba4  movaps [rsp], xmm1
00007531fdbe4ba8  movaps [rsp+0x10], xmm8
00007531fdbe4bae  movaps [rsp+0x20], xmm9
00007531fdbe4bb4  lea rdi, [rsp]
00007531fdbe4bb8  mov esi, 0x00
00007531fdbe4bbd  mov rax, 0x59ED111DF530
00007531fdbe4bc7  call rax
00007531fdbe4bc9  movaps xmm1, [rsp]
00007531fdbe4bcd  add rsp, 0x30
00007531fdbe4bd1  vmovaps xmm0, [rsp]
00007531fdbe4bd6  vmovaps xmm2, [rsp+0x10]
00007531fdbe4bdc  vmovaps xmm3, [rsp+0x20]
00007531fdbe4be2  vmovaps xmm4, [rsp+0x30]
00007531fdbe4be8  vmovaps xmm5, [rsp+0x40]
00007531fdbe4bee  vmovaps xmm6, [rsp+0x50]
00007531fdbe4bf4  vmovaps xmm7, [rsp+0x60]
00007531fdbe4bfa  vmovaps xmm8, [rsp+0x70]
00007531fdbe4c00  vmovaps xmm9, [rsp+0x80]
00007531fdbe4c09  vmovaps xmm10, [rsp+0x90]
00007531fdbe4c12  vmovaps xmm11, [rsp+0xA0]
00007531fdbe4c1b  vmovaps xmm12, [rsp+0xB0]
00007531fdbe4c24  vmovaps xmm13, [rsp+0xC0]
00007531fdbe4c2d  vmovaps xmm14, [rsp+0xD0]
00007531fdbe4c36  vmovaps xmm15, [rsp+0xE0]
00007531fdbe4c3f  add rsp, 0xF0
00007531fdbe4c46  pop r11
00007531fdbe4c48  pop r10
00007531fdbe4c4a  pop r9
00007531fdbe4c4c  pop r8
00007531fdbe4c4e  pop rsi
00007531fdbe4c4f  pop rdi
00007531fdbe4c50  pop rdx
00007531fdbe4c51  pop rcx
00007531fdbe4c52  pop rax
00007531fdbe4c53  add rsp, 0x08
00007531fdbe4c57  jmp 0x00007531FDBDFA45
00007531fdbe4c5c  call 0x00007531FDAE5940
00007531fdbe4c61  jmp 0x00007531FDBDFA53
00007531fdbe4c66  call 0x00007531FDA0C380
00007531fdbe4c6b  jmp 0x00007531FDBDFA5D
00007531fdbe4c70  call 0x00007531FDA0D600
00007531fdbe4c75  jmp 0x00007531FDBDFA67
00007531fdbe4c7a  call 0x00007531FD9FF540
00007531fdbe4c7f  jmp 0x00007531FDBDFA71
00007531fdbe4c84  int3
00007531fdbe4c85  nop [rax+rax*1], ax
00007531fdbe4c8e  nop
00007531fdbe4c90  mov qword ptr [r15+0x40], 0x430000
00007531fdbe4c98  mov eax, 0x430CC0
00007531fdbe4c9d  mov r14, [r13+rax*1]
00007531fdbe4ca2  movq xmm1, r14
00007531fdbe4ca7  mov rax, [r15+0x50]
00007531fdbe4cab  movups xmm15, [r13+rax*1]
00007531fdbe4cb1  movaps [r15+0x120], xmm15
00007531fdbe4cb9  mov qword ptr [r15+0x48], 0x10
00007531fdbe4cc1  xor eax, eax
00007531fdbe4cc3  mov r14d, 0x10
00007531fdbe4cc9  mov r12d, 0x200
00007531fdbe4ccf  cmp r14, r12
00007531fdbe4cd2  cmc
00007531fdbe4cd3  lahf
00007531fdbe4cd4  seto al
00007531fdbe4cd7  mov [r15+0x108], eax
00007531fdbe4cde  pextrq rax, xmm15, 0x01
00007531fdbe4ce5  movq xmm14, rax
00007531fdbe4cea  movaps [r15+0x130], xmm14
00007531fdbe4cf2  movq rax, xmm1
00007531fdbe4cf7  movq r14, xmm15
00007531fdbe4cfc  vmovq xmm1, rax
00007531fdbe4d01  vmovq xmm15, r14
00007531fdbe4d06  movaps xmm13, xmm1
00007531fdbe4d0a  addsd xmm13, xmm15
00007531fdbe4d0f  ucomisd xmm13, xmm13
00007531fdbe4d14  jp 0x00007531FDBE4DD3
00007531fdbe4d1a  movq xmm13, xmm13
00007531fdbe4d1f  movq rax, xmm13
00007531fdbe4d24  movq r14, xmm14
00007531fdbe4d29  vmovq xmm1, rax
00007531fdbe4d2e  vmovq xmm15, r14
00007531fdbe4d33  movaps xmm14, xmm1
00007531fdbe4d37  addsd xmm14, xmm15
00007531fdbe4d3c  ucomisd xmm14, xmm14
00007531fdbe4d41  jp 0x00007531FDBE4E1B
00007531fdbe4d47  movq xmm14, xmm14
00007531fdbe4d4c  movaps [r15+0x110], xmm14
00007531fdbe4d54  mov eax, [r15+0x108]
00007531fdbe4d5b  sahf
00007531fdbe4d5c  jnz 0x00007531FDBE4D8E
00007531fdbe4d5e  cmp dword ptr [r15+0x318], 0x00
00007531fdbe4d66  jz 0x00007531FDBE5030
00007531fdbe4d6c  nop [rax+rax*1], ax
00007531fdbe4d75  nop [rax+rax*1], eax
00007531fdbe4d7d  mov eax, 0x410704
00007531fdbe4d82  mov [r15+0x100], rax
00007531fdbe4d89  jmp 0x00007531FD9FE110
00007531fdbe4d8e  cmp dword ptr [r15+0x318], 0x00
00007531fdbe4d96  jz 0x00007531FDBE4E70
00007531fdbe4d9c  nop [rax+rax*1], ax
00007531fdbe4da5  nop [rax+rax*1], eax
00007531fdbe4dad  mov eax, 0x4106E8
00007531fdbe4db2  mov [r15+0x100], rax
00007531fdbe4db9  jmp 0x00007531FD9FE110
00007531fdbe4dbe  int3
00007531fdbe4dbf  call 0x00007531FDA0DC20
00007531fdbe4dc4  jmp 0x00007531FDBE4CA2
00007531fdbe4dc9  call 0x00007531FDA0E760
00007531fdbe4dce  jmp 0x00007531FDBE4CB1
00007531fdbe4dd3  ucomisd xmm1, xmm15
00007531fdbe4dd8  jp 0x00007531FDBE4DE7
00007531fdbe4dda  movaps xmm13, [0x00007531FD7FE060]
00007531fdbe4de2  jmp 0x00007531FDBE4D1A
00007531fdbe4de7  vxorps xmm0, xmm1, xmm15
00007531fdbe4dec  pextrw eax, xmm0, 0x03
00007531fdbe4df1  and eax, 0x7FF8
00007531fdbe4df6  cmp eax, 0x08
00007531fdbe4df9  jnz 0x00007531FDBE4D1A
00007531fdbe4dff  movq rax, xmm15
00007531fdbe4e04  shl rax, 0x0D
00007531fdbe4e08  jbe 0x00007531FDBE4D1A
00007531fdbe4e0e  vorps xmm13, xmm15, [0x00007531FD7FE070]
00007531fdbe4e16  jmp 0x00007531FDBE4D1A
00007531fdbe4e1b  ucomisd xmm1, xmm15
00007531fdbe4e20  jp 0x00007531FDBE4E2F
00007531fdbe4e22  movaps xmm14, [0x00007531FD7FE060]
00007531fdbe4e2a  jmp 0x00007531FDBE4D47
00007531fdbe4e2f  vxorps xmm0, xmm1, xmm15
00007531fdbe4e34  pextrw eax, xmm0, 0x03
00007531fdbe4e39  and eax, 0x7FF8
00007531fdbe4e3e  cmp eax, 0x08
00007531fdbe4e41  jnz 0x00007531FDBE4D47
00007531fdbe4e47  movq rax, xmm15
00007531fdbe4e4c  shl rax, 0x0D
00007531fdbe4e50  jbe 0x00007531FDBE4D47
00007531fdbe4e56  vorps xmm14, xmm15, [0x00007531FD7FE070]
00007531fdbe4e5e  jmp 0x00007531FDBE4D47
00007531fdbe4e63  int3
00007531fdbe4e64  nop [rax+rax*1], ax
00007531fdbe4e6d  nop [rax], eax
00007531fdbe4e70  mov rax, [r15+0x48]
00007531fdbe4e74  mov r14, [r15+0x50]
00007531fdbe4e78  lea r12, [r14+rax*1]
00007531fdbe4e7c  movups xmm1, [r13+r12*1]
00007531fdbe4e82  movaps [r15+0x120], xmm1
00007531fdbe4e8a  lea r14, [rax+0x10]
00007531fdbe4e8e  mov [r15+0x48], r14
00007531fdbe4e92  xor eax, eax
00007531fdbe4e94  mov r12d, 0x200
00007531fdbe4e9a  cmp r14, r12
00007531fdbe4e9d  cmc
00007531fdbe4e9e  lahf
00007531fdbe4e9f  seto al
00007531fdbe4ea2  mov [r15+0x108], eax
00007531fdbe4ea9  pextrq rax, xmm1, 0x01
00007531fdbe4eb0  movq xmm15, rax
00007531fdbe4eb5  movaps [r15+0x130], xmm15
00007531fdbe4ebd  movaps xmm14, [r15+0x110]
00007531fdbe4ec5  movq rax, xmm14
00007531fdbe4eca  movq r14, xmm1
00007531fdbe4ecf  vmovq xmm1, rax
00007531fdbe4ed4  vmovq xmm14, r14
00007531fdbe4ed9  movaps xmm13, xmm1
00007531fdbe4edd  addsd xmm13, xmm14
00007531fdbe4ee2  ucomisd xmm13, xmm13
00007531fdbe4ee7  jp 0x00007531FDBE4F9C
00007531fdbe4eed  movq xmm13, xmm13
00007531fdbe4ef2  movq rax, xmm13
00007531fdbe4ef7  movq r14, xmm15
00007531fdbe4efc  vmovq xmm1, rax
00007531fdbe4f01  vmovq xmm15, r14
00007531fdbe4f06  movaps xmm14, xmm1
00007531fdbe4f0a  addsd xmm14, xmm15
00007531fdbe4f0f  ucomisd xmm14, xmm14
00007531fdbe4f14  jp 0x00007531FDBE4FE4
00007531fdbe4f1a  movq xmm14, xmm14
00007531fdbe4f1f  movaps [r15+0x110], xmm14
00007531fdbe4f27  mov eax, [r15+0x108]
00007531fdbe4f2e  sahf
00007531fdbe4f2f  jnz 0x00007531FDBE4F61
00007531fdbe4f31  cmp dword ptr [r15+0x318], 0x00
00007531fdbe4f39  jz 0x00007531FDBE5030
00007531fdbe4f3f  nop [rax+rax*1], ax
00007531fdbe4f48  nop [rax+rax*1], eax
00007531fdbe4f50  mov eax, 0x410704
00007531fdbe4f55  mov [r15+0x100], rax
00007531fdbe4f5c  jmp 0x00007531FD9FE110
00007531fdbe4f61  cmp dword ptr [r15+0x318], 0x00
00007531fdbe4f69  jz 0x00007531FDBE4E70
00007531fdbe4f6f  nop [rax+rax*1], ax
00007531fdbe4f78  nop [rax+rax*1], eax
00007531fdbe4f80  mov eax, 0x4106E8
00007531fdbe4f85  mov [r15+0x100], rax
00007531fdbe4f8c  jmp 0x00007531FD9FE110
00007531fdbe4f91  int3
00007531fdbe4f92  call 0x00007531FDAB52F0
00007531fdbe4f97  jmp 0x00007531FDBE4E82
00007531fdbe4f9c  ucomisd xmm1, xmm14
00007531fdbe4fa1  jp 0x00007531FDBE4FB0
00007531fdbe4fa3  movaps xmm13, [0x00007531FD7FE060]
00007531fdbe4fab  jmp 0x00007531FDBE4EED
00007531fdbe4fb0  vxorps xmm0, xmm1, xmm14
00007531fdbe4fb5  pextrw eax, xmm0, 0x03
00007531fdbe4fba  and eax, 0x7FF8
00007531fdbe4fbf  cmp eax, 0x08
00007531fdbe4fc2  jnz 0x00007531FDBE4EED
00007531fdbe4fc8  movq rax, xmm14
00007531fdbe4fcd  shl rax, 0x0D
00007531fdbe4fd1  jbe 0x00007531FDBE4EED
00007531fdbe4fd7  vorps xmm13, xmm14, [0x00007531FD7FE070]
00007531fdbe4fdf  jmp 0x00007531FDBE4EED
00007531fdbe4fe4  ucomisd xmm1, xmm15
00007531fdbe4fe9  jp 0x00007531FDBE4FF8
00007531fdbe4feb  movaps xmm14, [0x00007531FD7FE060]
00007531fdbe4ff3  jmp 0x00007531FDBE4F1A
00007531fdbe4ff8  vxorps xmm0, xmm1, xmm15
00007531fdbe4ffd  pextrw eax, xmm0, 0x03
00007531fdbe5002  and eax, 0x7FF8
00007531fdbe5007  cmp eax, 0x08
00007531fdbe500a  jnz 0x00007531FDBE4F1A
00007531fdbe5010  movq rax, xmm15
00007531fdbe5015  shl rax, 0x0D
00007531fdbe5019  jbe 0x00007531FDBE4F1A
00007531fdbe501f  vorps xmm14, xmm15, [0x00007531FD7FE070]
00007531fdbe5027  jmp 0x00007531FDBE4F1A
00007531fdbe502c  int3
00007531fdbe502d  nop [rax], eax
00007531fdbe5030  mov rax, [r15+0xF8]
00007531fdbe5037  lea r14, [rax+0x1D0]
00007531fdbe503e  mov r12, [r13+r14*1]
00007531fdbe5043  lea r14, [rax+0x1D8]
00007531fdbe504a  mov r11, [r13+r14*1]
00007531fdbe504f  mov [r15+0xA0], r12
00007531fdbe5056  mov [r15+0x98], r11
00007531fdbe505d  mov r14, [r15+0x40]
00007531fdbe5061  lea r12, [r14+0xCC0]
00007531fdbe5068  movaps xmm1, [r15+0x110]
00007531fdbe5070  movq r14, xmm1
00007531fdbe5075  mov [r13+r12*1], r14
00007531fdbe507a  lea r14, [rax+0x1C0]
00007531fdbe5081  mov r12, [r13+r14*1]
00007531fdbe5086  lea r14, [rax+0x1C8]
00007531fdbe508d  mov r11, [r13+r14*1]
00007531fdbe5092  mov [r15+0xE8], r12
00007531fdbe5099  mov [r15+0xF0], r11
00007531fdbe50a0  lea r14, [rax+0x1B0]
00007531fdbe50a7  mov r12, [r13+r14*1]
00007531fdbe50ac  lea r14, [rax+0x1B8]
00007531fdbe50b3  mov r10, [r13+r14*1]
00007531fdbe50b8  movq xmm1, r12
00007531fdbe50bd  movq xmm15, r10
00007531fdbe50c2  movq xmm1, xmm1
00007531fdbe50c6  movq xmm1, xmm1
00007531fdbe50ca  movaps [r15+0x1A0], xmm1
00007531fdbe50d2  movq xmm15, xmm15
00007531fdbe50d7  movq xmm15, xmm15
00007531fdbe50dc  movaps [r15+0x190], xmm15
00007531fdbe50e4  lea r14, [rax+0x1A0]
00007531fdbe50eb  mov r12, [r13+r14*1]
00007531fdbe50f0  lea r14, [rax+0x1A8]
00007531fdbe50f7  mov r10, [r13+r14*1]
00007531fdbe50fc  movq xmm1, r12
00007531fdbe5101  movq xmm15, r10
00007531fdbe5106  movq xmm1, xmm1
00007531fdbe510a  movq xmm1, xmm1
00007531fdbe510e  movaps [r15+0x1C0], xmm1
00007531fdbe5116  movq xmm15, xmm15
00007531fdbe511b  movq xmm15, xmm15
00007531fdbe5120  movaps [r15+0x1B0], xmm15
00007531fdbe5128  lea r14, [rax+0x190]
00007531fdbe512f  mov r12, [r13+r14*1]
00007531fdbe5134  lea r14, [rax+0x198]
00007531fdbe513b  mov r10, [r13+r14*1]
00007531fdbe5140  movq xmm1, r12
00007531fdbe5145  movq xmm15, r10
00007531fdbe514a  movq xmm1, xmm1
00007531fdbe514e  movq xmm1, xmm1
00007531fdbe5152  movaps [r15+0x1E0], xmm1
00007531fdbe515a  movq xmm15, xmm15
00007531fdbe515f  movq xmm15, xmm15
00007531fdbe5164  movaps [r15+0x1D0], xmm15
00007531fdbe516c  lea r14, [rax+0x180]
00007531fdbe5173  mov r12, [r13+r14*1]
00007531fdbe5178  lea r14, [rax+0x188]
00007531fdbe517f  mov r10, [r13+r14*1]
00007531fdbe5184  movq xmm1, r12
00007531fdbe5189  movq xmm15, r10
00007531fdbe518e  movq xmm1, xmm1
00007531fdbe5192  movq xmm1, xmm1
00007531fdbe5196  movaps [r15+0x200], xmm1
00007531fdbe519e  movq xmm15, xmm15
00007531fdbe51a3  movq xmm15, xmm15
00007531fdbe51a8  movaps [r15+0x1F0], xmm15
00007531fdbe51b0  lea r14, [rax+0x1E0]
00007531fdbe51b7  mov [r15+0xF8], r14
00007531fdbe51be  mov [r15+0x100], r11
00007531fdbe51c5  jmp 0x00007531FDBCE5C0
00007531fdbe51ca  int3
00007531fdbe51cb  call 0x00007531FDAE27E0
00007531fdbe51d0  jmp 0x00007531FDBE5043
00007531fdbe51d5  call 0x00007531FDAE1570
00007531fdbe51da  jmp 0x00007531FDBE504F
00007531fdbe51df  call 0x00007531FDAC3FE0
00007531fdbe51e4  jmp 0x00007531FDBE507A
00007531fdbe51e9  call 0x00007531FDAE27E0
00007531fdbe51ee  jmp 0x00007531FDBE5086
00007531fdbe51f3  call 0x00007531FDAE1570
00007531fdbe51f8  jmp 0x00007531FDBE5092
00007531fdbe51fd  call 0x00007531FDAE27E0
00007531fdbe5202  jmp 0x00007531FDBE50AC
00007531fdbe5207  call 0x00007531FDAE0300
00007531fdbe520c  jmp 0x00007531FDBE50B8
00007531fdbe5211  call 0x00007531FDAE27E0
00007531fdbe5216  jmp 0x00007531FDBE50F0
00007531fdbe521b  call 0x00007531FDAE0300
00007531fdbe5220  jmp 0x00007531FDBE50FC
00007531fdbe5225  call 0x00007531FDAE27E0
00007531fdbe522a  jmp 0x00007531FDBE5134
00007531fdbe522f  call 0x00007531FDAE0300
00007531fdbe5234  jmp 0x00007531FDBE5140
00007531fdbe5239  call 0x00007531FDAE27E0
00007531fdbe523e  jmp 0x00007531FDBE5178
00007531fdbe5243  call 0x00007531FDAE0300
00007531fdbe5248  jmp 0x00007531FDBE5184
00007531fdbe524d  int3
00007531fdbe524e  nop
00007531fdbe5250  mov qword ptr [r15+0x100], 0x04
00007531fdbe525b  mov esi, 0x00
00007531fdbe5260  mov edx, 0x09
00007531fdbe5265  mov rdi, 0x7FFEECD328C0
00007531fdbe526f  mov rax, 0x59ED11072970
00007531fdbe5279  call rax
00007531fdbe527b  cmp dword ptr [r15+0x318], 0x00
00007531fdbe5283  jnz 0x00007531FD9FE110
00007531fdbe5289  jmp 0x00007531FD9FE0A0
00007531fdbe528e  int3
00007531fdbe528f  int3
