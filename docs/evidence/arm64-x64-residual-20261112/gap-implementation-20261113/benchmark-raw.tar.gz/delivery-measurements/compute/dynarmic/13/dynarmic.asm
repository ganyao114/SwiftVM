00007d3d13bce69b  nop [rax+rax*1], eax
00007d3d13bce6a0  mov rax, [r15+0xF8]
00007d3d13bce6a7  lea r14, [rax-0x1E0]
00007d3d13bce6ae  mov [r15+0xF8], r14
00007d3d13bce6b5  lea rax, [r14+0x1D0]
00007d3d13bce6bc  mov r12, [r15+0xA0]
00007d3d13bce6c3  mov r11, [r15+0x98]
00007d3d13bce6ca  mov [r13+rax*1], r12
00007d3d13bce6cf  lea rax, [r14+0x1D8]
00007d3d13bce6d6  mov [r13+rax*1], r11
00007d3d13bce6db  mov eax, 0x420AA0
00007d3d13bce6e0  movups xmm1, [r13+rax*1]
00007d3d13bce6e6  mov eax, 0x420A30
00007d3d13bce6eb  movups xmm15, [r13+rax*1]
00007d3d13bce6f1  mov eax, 0x420AC0
00007d3d13bce6f6  movups xmm14, [r13+rax*1]
00007d3d13bce6fc  mov eax, 0x420A60
00007d3d13bce701  movups xmm13, [r13+rax*1]
00007d3d13bce707  mov qword ptr [r15+0x98], 0x430CD0
00007d3d13bce712  mov eax, 0x420AD0
00007d3d13bce717  movups xmm12, [r13+rax*1]
00007d3d13bce71d  mov eax, 0x430CD0
00007d3d13bce722  movups [r13+rax*1], xmm1
00007d3d13bce728  mov eax, 0x430CE0
00007d3d13bce72d  movups [r13+rax*1], xmm15
00007d3d13bce733  mov eax, 0x430CF0
00007d3d13bce738  movups [r13+rax*1], xmm14
00007d3d13bce73e  mov eax, 0x430D00
00007d3d13bce743  movups [r13+rax*1], xmm13
00007d3d13bce749  mov eax, 0x420A20
00007d3d13bce74e  movups xmm14, [r13+rax*1]
00007d3d13bce754  mov eax, 0x420A10
00007d3d13bce759  movups xmm13, [r13+rax*1]
00007d3d13bce75f  mov eax, 0x430DD0
00007d3d13bce764  movups [r13+rax*1], xmm1
00007d3d13bce76a  mov eax, 0x430DE0
00007d3d13bce76f  movups [r13+rax*1], xmm15
00007d3d13bce775  mov eax, 0x430D10
00007d3d13bce77a  movups [r13+rax*1], xmm12
00007d3d13bce780  mov eax, 0x430D20
00007d3d13bce785  movups [r13+rax*1], xmm14
00007d3d13bce78b  mov eax, 0x420A00
00007d3d13bce790  movups xmm1, [r13+rax*1]
00007d3d13bce796  mov eax, 0x420A70
00007d3d13bce79b  movups xmm15, [r13+rax*1]
00007d3d13bce7a1  mov eax, 0x430D30
00007d3d13bce7a6  movups [r13+rax*1], xmm13
00007d3d13bce7ac  mov eax, 0x430D40
00007d3d13bce7b1  movups [r13+rax*1], xmm1
00007d3d13bce7b7  mov eax, 0x420A80
00007d3d13bce7bc  movups xmm1, [r13+rax*1]
00007d3d13bce7c2  mov eax, 0x420A50
00007d3d13bce7c7  movups xmm14, [r13+rax*1]
00007d3d13bce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007d3d13bce7d5  mov eax, 0x430D50
00007d3d13bce7da  movups [r13+rax*1], xmm15
00007d3d13bce7e0  mov eax, 0x430D60
00007d3d13bce7e5  movups [r13+rax*1], xmm1
00007d3d13bce7eb  mov eax, 0x420AF0
00007d3d13bce7f0  movups xmm1, [r13+rax*1]
00007d3d13bce7f6  mov eax, 0x420B00
00007d3d13bce7fb  movups xmm15, [r13+rax*1]
00007d3d13bce801  movaps [r15+0x150], xmm15
00007d3d13bce809  mov qword ptr [r15+0xA0], 0x3E8
00007d3d13bce814  mov eax, 0x430D70
00007d3d13bce819  movups [r13+rax*1], xmm14
00007d3d13bce81f  mov eax, 0x430D80
00007d3d13bce824  movups [r13+rax*1], xmm1
00007d3d13bce82a  mov eax, 0x420AE0
00007d3d13bce82f  movups xmm1, [r13+rax*1]
00007d3d13bce835  mov eax, 0x420A90
00007d3d13bce83a  movups xmm14, [r13+rax*1]
00007d3d13bce840  movaps [r15+0x140], xmm14
00007d3d13bce848  lea rax, [r14+0x180]
00007d3d13bce84f  movq xmm13, qword ptr [r15+0x200]
00007d3d13bce858  movq xmm12, qword ptr [r15+0x1F0]
00007d3d13bce861  movq r12, xmm13
00007d3d13bce866  movq r11, xmm12
00007d3d13bce86b  mov [r13+rax*1], r12
00007d3d13bce870  lea rax, [r14+0x188]
00007d3d13bce877  mov [r13+rax*1], r11
00007d3d13bce87c  mov eax, 0x430D90
00007d3d13bce881  movups [r13+rax*1], xmm15
00007d3d13bce887  mov eax, 0x430DA0
00007d3d13bce88c  movups [r13+rax*1], xmm1
00007d3d13bce892  mov eax, 0x420AB0
00007d3d13bce897  movups xmm1, [r13+rax*1]
00007d3d13bce89d  mov eax, 0x420B18
00007d3d13bce8a2  mov r12, [r13+rax*1]
00007d3d13bce8a7  movq xmm15, r12
00007d3d13bce8ac  mov qword ptr [r15+0x40], 0x420B20
00007d3d13bce8b4  mov eax, 0x430DB0
00007d3d13bce8b9  movups [r13+rax*1], xmm14
00007d3d13bce8bf  mov eax, 0x430DC0
00007d3d13bce8c4  movups [r13+rax*1], xmm1
00007d3d13bce8ca  mov eax, 0x420B80
00007d3d13bce8cf  movups xmm1, [r13+rax*1]
00007d3d13bce8d5  movq rax, xmm15
00007d3d13bce8da  mov r12d, 0x430DF0
00007d3d13bce8e0  mov [r13+r12*1], rax
00007d3d13bce8e5  mov eax, 0x420B60
00007d3d13bce8ea  movups xmm15, [r13+rax*1]
00007d3d13bce8f0  mov eax, 0x420B70
00007d3d13bce8f5  movups xmm14, [r13+rax*1]
00007d3d13bce8fb  lea rax, [r14+0x160]
00007d3d13bce902  movups [r13+rax*1], xmm1
00007d3d13bce908  lea rax, [r14+0x190]
00007d3d13bce90f  movq xmm1, qword ptr [r15+0x1E0]
00007d3d13bce918  movq xmm13, qword ptr [r15+0x1D0]
00007d3d13bce921  movq r12, xmm1
00007d3d13bce926  movq r11, xmm13
00007d3d13bce92b  mov [r13+rax*1], r12
00007d3d13bce930  lea rax, [r14+0x198]
00007d3d13bce937  mov [r13+rax*1], r11
00007d3d13bce93c  lea rax, [r14+0x140]
00007d3d13bce943  movups [r13+rax*1], xmm15
00007d3d13bce949  lea rax, [r14+0x150]
00007d3d13bce950  movups [r13+rax*1], xmm14
00007d3d13bce956  mov eax, 0x420B20
00007d3d13bce95b  movups xmm1, [r13+rax*1]
00007d3d13bce961  mov eax, 0x420B30
00007d3d13bce966  movups xmm15, [r13+rax*1]
00007d3d13bce96c  movaps [r15+0x120], xmm15
00007d3d13bce974  lea rax, [r14+0x1A0]
00007d3d13bce97b  movq xmm14, qword ptr [r15+0x1C0]
00007d3d13bce984  movq xmm13, qword ptr [r15+0x1B0]
00007d3d13bce98d  movq r12, xmm14
00007d3d13bce992  movq r11, xmm13
00007d3d13bce997  mov [r13+rax*1], r12
00007d3d13bce99c  lea rax, [r14+0x1A8]
00007d3d13bce9a3  mov [r13+rax*1], r11
00007d3d13bce9a8  lea rax, [r14+0x1B0]
00007d3d13bce9af  movq xmm14, qword ptr [r15+0x1A0]
00007d3d13bce9b8  movq xmm13, qword ptr [r15+0x190]
00007d3d13bce9c1  movq r12, xmm14
00007d3d13bce9c6  movq r11, xmm13
00007d3d13bce9cb  mov [r13+rax*1], r12
00007d3d13bce9d0  lea rax, [r14+0x1B8]
00007d3d13bce9d7  mov [r13+rax*1], r11
00007d3d13bce9dc  lea rax, [r14+0x100]
00007d3d13bce9e3  movups [r13+rax*1], xmm1
00007d3d13bce9e9  lea rax, [r14+0x110]
00007d3d13bce9f0  movups [r13+rax*1], xmm15
00007d3d13bce9f6  mov eax, 0x420B40
00007d3d13bce9fb  movups xmm1, [r13+rax*1]
00007d3d13bcea01  mov eax, 0x420B50
00007d3d13bcea06  movups xmm15, [r13+rax*1]
00007d3d13bcea0c  movaps [r15+0x110], xmm1
00007d3d13bcea14  movaps [r15+0x130], xmm15
00007d3d13bcea1c  lea rax, [r14+0x1C0]
00007d3d13bcea23  mov r12, [r15+0xE8]
00007d3d13bcea2a  mov r11, [r15+0xF0]
00007d3d13bcea31  mov [r13+rax*1], r12
00007d3d13bcea36  lea rax, [r14+0x1C8]
00007d3d13bcea3d  mov [r13+rax*1], r11
00007d3d13bcea42  mov eax, 0x430DF8
00007d3d13bcea47  mov r12d, 0x421DF8D3
00007d3d13bcea4d  mov [r13+rax*1], r12d
00007d3d13bcea52  lea rax, [r14+0x120]
00007d3d13bcea59  movups [r13+rax*1], xmm1
00007d3d13bcea5f  lea rax, [r14+0x130]
00007d3d13bcea66  movups [r13+rax*1], xmm15
00007d3d13bcea6c  lea rax, [r14+0x100]
00007d3d13bcea73  mov [r15], rax
00007d3d13bcea76  mov qword ptr [r15+0x08], 0x430CD0
00007d3d13bcea7e  mov qword ptr [r15+0x10], 0x12C
00007d3d13bcea86  mov qword ptr [r15+0xF0], 0x410284
00007d3d13bcea91  mov r14d, [r15+0x320]
00007d3d13bcea98  mov eax, 0x410284
00007d3d13bcea9d  mov rcx, 0x7D3D13BD07C0
00007d3d13bceaa7  mov [r15+r14*8+0x328], rax
00007d3d13bceaaf  mov [r15+r14*8+0x368], rcx
00007d3d13bceab7  add r14d, 0x01
00007d3d13bceabb  and r14d, 0x07
00007d3d13bceabf  mov [r15+0x320], r14d
00007d3d13bceac6  cmp dword ptr [r15+0x318], 0x00
00007d3d13bceace  jz 0x00007D3D13BCED70
00007d3d13bcead4  nop [rax+rax*1], ax
00007d3d13bceadd  nop [rax+rax*1], eax
00007d3d13bceae5  mov eax, 0x410728
00007d3d13bceaea  mov [r15+0x100], rax
00007d3d13bceaf1  jmp 0x00007D3D139FE110
00007d3d13bceaf6  int3
00007d3d13bceaf7  call 0x00007D3D13A0BC20
00007d3d13bceafc  jmp 0x00007D3D13BCE6CF
00007d3d13bceb01  call 0x00007D3D13A0A9A0
00007d3d13bceb06  jmp 0x00007D3D13BCE6DB
00007d3d13bceb0b  call 0x00007D3D139FF430
00007d3d13bceb10  jmp 0x00007D3D13BCE6E6
00007d3d13bceb15  call 0x00007D3D13A0E760
00007d3d13bceb1a  jmp 0x00007D3D13BCE6F1
00007d3d13bceb1f  call 0x00007D3D13A0D4E0
00007d3d13bceb24  jmp 0x00007D3D13BCE6FC
00007d3d13bceb29  call 0x00007D3D13A0C260
00007d3d13bceb2e  jmp 0x00007D3D13BCE707
00007d3d13bceb33  call 0x00007D3D13A0AFE0
00007d3d13bceb38  jmp 0x00007D3D13BCE71D
00007d3d13bceb3d  call 0x00007D3D139FF540
00007d3d13bceb42  jmp 0x00007D3D13BCE728
00007d3d13bceb47  call 0x00007D3D13A0E880
00007d3d13bceb4c  jmp 0x00007D3D13BCE733
00007d3d13bceb51  call 0x00007D3D13A0D600
00007d3d13bceb56  jmp 0x00007D3D13BCE73E
00007d3d13bceb5b  call 0x00007D3D13A0C380
00007d3d13bceb60  jmp 0x00007D3D13BCE749
00007d3d13bceb65  call 0x00007D3D13A0D4E0
00007d3d13bceb6a  jmp 0x00007D3D13BCE754
00007d3d13bceb6f  call 0x00007D3D13A0C260
00007d3d13bceb74  jmp 0x00007D3D13BCE75F
00007d3d13bceb79  call 0x00007D3D139FF540
00007d3d13bceb7e  jmp 0x00007D3D13BCE76A
00007d3d13bceb83  call 0x00007D3D13A0E880
00007d3d13bceb88  jmp 0x00007D3D13BCE775
00007d3d13bceb8d  call 0x00007D3D13A0B100
00007d3d13bceb92  jmp 0x00007D3D13BCE780
00007d3d13bceb97  call 0x00007D3D13A0D600
00007d3d13bceb9c  jmp 0x00007D3D13BCE78B
00007d3d13bceba1  call 0x00007D3D139FF430
00007d3d13bceba6  jmp 0x00007D3D13BCE796
00007d3d13bcebab  call 0x00007D3D13A0E760
00007d3d13bcebb0  jmp 0x00007D3D13BCE7A1
00007d3d13bcebb5  call 0x00007D3D13A0C380
00007d3d13bcebba  jmp 0x00007D3D13BCE7AC
00007d3d13bcebbf  call 0x00007D3D139FF540
00007d3d13bcebc4  jmp 0x00007D3D13BCE7B7
00007d3d13bcebc9  call 0x00007D3D139FF430
00007d3d13bcebce  jmp 0x00007D3D13BCE7C2
00007d3d13bcebd3  call 0x00007D3D13A0D4E0
00007d3d13bcebd8  jmp 0x00007D3D13BCE7CD
00007d3d13bcebdd  call 0x00007D3D13A0E880
00007d3d13bcebe2  jmp 0x00007D3D13BCE7E0
00007d3d13bcebe7  call 0x00007D3D139FF540
00007d3d13bcebec  jmp 0x00007D3D13BCE7EB
00007d3d13bcebf1  call 0x00007D3D139FF430
00007d3d13bcebf6  jmp 0x00007D3D13BCE7F6
00007d3d13bcebfb  call 0x00007D3D13A0E760
00007d3d13bcec00  jmp 0x00007D3D13BCE801
00007d3d13bcec05  call 0x00007D3D13A0D600
00007d3d13bcec0a  jmp 0x00007D3D13BCE81F
00007d3d13bcec0f  call 0x00007D3D139FF540
00007d3d13bcec14  jmp 0x00007D3D13BCE82A
00007d3d13bcec19  call 0x00007D3D139FF430
00007d3d13bcec1e  jmp 0x00007D3D13BCE835
00007d3d13bcec23  call 0x00007D3D13A0D4E0
00007d3d13bcec28  jmp 0x00007D3D13BCE840
00007d3d13bcec2d  call 0x00007D3D13A0BC20
00007d3d13bcec32  jmp 0x00007D3D13BCE870
00007d3d13bcec37  call 0x00007D3D13A0A9A0
00007d3d13bcec3c  jmp 0x00007D3D13BCE87C
00007d3d13bcec41  call 0x00007D3D13A0E880
00007d3d13bcec46  jmp 0x00007D3D13BCE887
00007d3d13bcec4b  call 0x00007D3D139FF540
00007d3d13bcec50  jmp 0x00007D3D13BCE892
00007d3d13bcec55  call 0x00007D3D139FF430
00007d3d13bcec5a  jmp 0x00007D3D13BCE89D
00007d3d13bcec5f  call 0x00007D3D13A0B720
00007d3d13bcec64  jmp 0x00007D3D13BCE8A7
00007d3d13bcec69  call 0x00007D3D13A0D600
00007d3d13bcec6e  jmp 0x00007D3D13BCE8BF
00007d3d13bcec73  call 0x00007D3D139FF540
00007d3d13bcec78  jmp 0x00007D3D13BCE8CA
00007d3d13bcec7d  call 0x00007D3D139FF430
00007d3d13bcec82  jmp 0x00007D3D13BCE8D5
00007d3d13bcec87  call 0x00007D3D13AB4CB0
00007d3d13bcec8c  jmp 0x00007D3D13BCE8E5
00007d3d13bcec91  call 0x00007D3D13A0E760
00007d3d13bcec96  jmp 0x00007D3D13BCE8F0
00007d3d13bcec9b  call 0x00007D3D13A0D4E0
00007d3d13bceca0  jmp 0x00007D3D13BCE8FB
00007d3d13bceca5  call 0x00007D3D139FF540
00007d3d13bcecaa  jmp 0x00007D3D13BCE908
00007d3d13bcecaf  call 0x00007D3D13A0BC20
00007d3d13bcecb4  jmp 0x00007D3D13BCE930
00007d3d13bcecb9  call 0x00007D3D13A0A9A0
00007d3d13bcecbe  jmp 0x00007D3D13BCE93C
00007d3d13bcecc3  call 0x00007D3D13A0E880
00007d3d13bcecc8  jmp 0x00007D3D13BCE949
00007d3d13bceccd  call 0x00007D3D13A0D600
00007d3d13bcecd2  jmp 0x00007D3D13BCE956
00007d3d13bcecd7  call 0x00007D3D139FF430
00007d3d13bcecdc  jmp 0x00007D3D13BCE961
00007d3d13bcece1  call 0x00007D3D13A0E760
00007d3d13bcece6  jmp 0x00007D3D13BCE96C
00007d3d13bceceb  call 0x00007D3D13A0BC20
00007d3d13bcecf0  jmp 0x00007D3D13BCE99C
00007d3d13bcecf5  call 0x00007D3D13A0A9A0
00007d3d13bcecfa  jmp 0x00007D3D13BCE9A8
00007d3d13bcecff  call 0x00007D3D13A0BC20
00007d3d13bced04  jmp 0x00007D3D13BCE9D0
00007d3d13bced09  call 0x00007D3D13A0A9A0
00007d3d13bced0e  jmp 0x00007D3D13BCE9DC
00007d3d13bced13  call 0x00007D3D139FF540
00007d3d13bced18  jmp 0x00007D3D13BCE9E9
00007d3d13bced1d  call 0x00007D3D13A0E880
00007d3d13bced22  jmp 0x00007D3D13BCE9F6
00007d3d13bced27  call 0x00007D3D139FF430
00007d3d13bced2c  jmp 0x00007D3D13BCEA01
00007d3d13bced31  call 0x00007D3D13A0E760
00007d3d13bced36  jmp 0x00007D3D13BCEA0C
00007d3d13bced3b  call 0x00007D3D13A0BC20
00007d3d13bced40  jmp 0x00007D3D13BCEA36
00007d3d13bced45  call 0x00007D3D13A0A9A0
00007d3d13bced4a  jmp 0x00007D3D13BCEA42
00007d3d13bced4f  call 0x00007D3D13A0BAE0
00007d3d13bced54  jmp 0x00007D3D13BCEA52
00007d3d13bced59  call 0x00007D3D139FF540
00007d3d13bced5e  jmp 0x00007D3D13BCEA5F
00007d3d13bced63  call 0x00007D3D13A0E880
00007d3d13bced68  jmp 0x00007D3D13BCEA6C
00007d3d13bced6d  int3
00007d3d13bced6e  nop
00007d3d13bced70  mov rax, [r15]
00007d3d13bced73  lea r14, [rax+0x20]
00007d3d13bced77  mov r12, [r13+r14*1]
00007d3d13bced7c  mov r14, [r15+0x10]
00007d3d13bced80  lea r11, [r12+r14*1]
00007d3d13bced84  mov [r15+0x40], r11
00007d3d13bced88  lea r12, [rax+0x20]
00007d3d13bced8c  mov [r13+r12*1], r11
00007d3d13bced91  test r14, r14
00007d3d13bced94  setz r14b
00007d3d13bced98  movzx r14, r14b
00007d3d13bced9c  mov [rsp+0x414], r14b
00007d3d13bceda4  cmp byte ptr [rsp+0x414], 0x00
00007d3d13bcedac  jz 0x00007D3D13BCEDDE
00007d3d13bcedae  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcedb6  mov eax, 0x4109A0
00007d3d13bcedbb  mov [r15+0x100], rax
00007d3d13bcedc2  jz 0x00007D3D139FE0A0
00007d3d13bcedc8  nop [rax+rax*1], eax
00007d3d13bcedcd  mov eax, 0x4109A0
00007d3d13bcedd2  mov [r15+0x100], rax
00007d3d13bcedd9  jmp 0x00007D3D139FE110
00007d3d13bcedde  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcede6  jz 0x00007D3D13BCEE30
00007d3d13bcedec  nop [rax+rax*1], ax
00007d3d13bcedf5  nop [rax+rax*1], eax
00007d3d13bcedfd  mov eax, 0x410738
00007d3d13bcee02  mov [r15+0x100], rax
00007d3d13bcee09  jmp 0x00007D3D139FE110
00007d3d13bcee0e  int3
00007d3d13bcee0f  call 0x00007D3D13AE27E0
00007d3d13bcee14  jmp 0x00007D3D13BCED7C
00007d3d13bcee19  call 0x00007D3D13AC0860
00007d3d13bcee1e  jmp 0x00007D3D13BCED91
00007d3d13bcee23  int3
00007d3d13bcee24  nop [rax+rax*1], ax
00007d3d13bcee2d  nop [rax], eax
00007d3d13bcee30  mov rax, [r15+0xF8]
00007d3d13bcee37  lea r14, [rax-0x150]
00007d3d13bcee3e  mov [r15+0xF8], r14
00007d3d13bcee45  mov rax, [r15]
00007d3d13bcee48  lea r12, [rax+0x68]
00007d3d13bcee4c  mov r11, [r13+r12*1]
00007d3d13bcee51  mov [r15+0x88], r11
00007d3d13bcee58  lea r12, [rax+0x28]
00007d3d13bcee5c  mov [r15+0x40], r12
00007d3d13bcee60  mov [r15+0x48], r14
00007d3d13bcee64  mov qword ptr [r15+0x50], 0x420B90
00007d3d13bcee6c  lea rax, [r14+0x100]
00007d3d13bcee73  mov r12, [r15+0xE8]
00007d3d13bcee7a  mov r11, [r15+0xD8]
00007d3d13bcee81  mov [r13+rax*1], r12
00007d3d13bcee86  lea rax, [r14+0x108]
00007d3d13bcee8d  mov [r13+rax*1], r11
00007d3d13bcee92  lea rax, [r14+0x110]
00007d3d13bcee99  mov r12, [r15+0xD0]
00007d3d13bceea0  mov r11, [r15+0xC8]
00007d3d13bceea7  mov [r13+rax*1], r12
00007d3d13bceeac  lea rax, [r14+0x118]
00007d3d13bceeb3  mov [r13+rax*1], r11
00007d3d13bceeb8  lea rax, [r14+0x120]
00007d3d13bceebf  mov r12, [r15+0xC0]
00007d3d13bceec6  mov r11, [r15+0xB8]
00007d3d13bceecd  mov [r13+rax*1], r12
00007d3d13bceed2  lea rax, [r14+0x128]
00007d3d13bceed9  mov [r13+rax*1], r11
00007d3d13bceede  lea rax, [r14+0x130]
00007d3d13bceee5  mov r12, [r15+0xB0]
00007d3d13bceeec  mov r11, [r15+0xA8]
00007d3d13bceef3  mov [r13+rax*1], r12
00007d3d13bceef8  lea rax, [r14+0x138]
00007d3d13bceeff  mov [r13+rax*1], r11
00007d3d13bcef04  lea rax, [r14+0x140]
00007d3d13bcef0b  mov r12, [r15+0xA0]
00007d3d13bcef12  mov r11, [r15+0x98]
00007d3d13bcef19  mov [r13+rax*1], r12
00007d3d13bcef1e  lea rax, [r14+0x148]
00007d3d13bcef25  mov [r13+rax*1], r11
00007d3d13bcef2a  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcef32  jz 0x00007D3D13BCEFD0
00007d3d13bcef38  nop [rax+rax*1], ax
00007d3d13bcef41  nop [rax+rax*1], eax
00007d3d13bcef49  mov eax, 0x410770
00007d3d13bcef4e  mov [r15+0x100], rax
00007d3d13bcef55  jmp 0x00007D3D139FE110
00007d3d13bcef5a  int3
00007d3d13bcef5b  call 0x00007D3D13AC0370
00007d3d13bcef60  jmp 0x00007D3D13BCEE51
00007d3d13bcef65  call 0x00007D3D13A0BC20
00007d3d13bcef6a  jmp 0x00007D3D13BCEE86
00007d3d13bcef6f  call 0x00007D3D13A0A9A0
00007d3d13bcef74  jmp 0x00007D3D13BCEE92
00007d3d13bcef79  call 0x00007D3D13A0BC20
00007d3d13bcef7e  jmp 0x00007D3D13BCEEAC
00007d3d13bcef83  call 0x00007D3D13A0A9A0
00007d3d13bcef88  jmp 0x00007D3D13BCEEB8
00007d3d13bcef8d  call 0x00007D3D13A0BC20
00007d3d13bcef92  jmp 0x00007D3D13BCEED2
00007d3d13bcef97  call 0x00007D3D13A0A9A0
00007d3d13bcef9c  jmp 0x00007D3D13BCEEDE
00007d3d13bcefa1  call 0x00007D3D13A0BC20
00007d3d13bcefa6  jmp 0x00007D3D13BCEEF8
00007d3d13bcefab  call 0x00007D3D13A0A9A0
00007d3d13bcefb0  jmp 0x00007D3D13BCEF04
00007d3d13bcefb5  call 0x00007D3D13A0BC20
00007d3d13bcefba  jmp 0x00007D3D13BCEF1E
00007d3d13bcefbf  call 0x00007D3D13A0A9A0
00007d3d13bcefc4  jmp 0x00007D3D13BCEF2A
00007d3d13bcefc9  int3
00007d3d13bcefca  nop [rax+rax*1], ax
00007d3d13bcefd0  mov rax, [r15+0x08]
00007d3d13bcefd4  movzx r14d, byte ptr [r13+rax*1]
00007d3d13bcefda  movzx r14d, r14b
00007d3d13bcefde  mov [rsp+0x10], r14d
00007d3d13bcefe3  mov r14d, r14d
00007d3d13bcefe6  mov [r15+0x58], r14
00007d3d13bcefea  lea r14, [rax+0x01]
00007d3d13bcefee  mov [r15+0x08], r14
00007d3d13bceff2  mov rax, [r15+0x88]
00007d3d13bceff9  lea r14, [rax+0x01]
00007d3d13bceffd  mov r12, [r15]
00007d3d13bcf000  lea r11, [r12+0x68]
00007d3d13bcf005  mov [r13+r11*1], r14
00007d3d13bcf00a  lea r14, [r12+rax*1]
00007d3d13bcf00e  mov [r15+0x60], r14
00007d3d13bcf012  lea rax, [r14+0x28]
00007d3d13bcf016  mov r11d, [rsp+0x10]
00007d3d13bcf01b  movzx r14d, r11b
00007d3d13bcf01f  mov [r13+rax*1], r14b
00007d3d13bcf024  lea rax, [r12+0x68]
00007d3d13bcf029  mov r14, [r13+rax*1]
00007d3d13bcf02e  mov [r15+0x88], r14
00007d3d13bcf035  xor eax, eax
00007d3d13bcf037  mov r12d, 0x40
00007d3d13bcf03d  cmp r14, r12
00007d3d13bcf040  cmc
00007d3d13bcf041  lahf
00007d3d13bcf042  seto al
00007d3d13bcf045  mov [r15+0x108], eax
00007d3d13bcf04c  mov eax, [r15+0x108]
00007d3d13bcf053  sahf
00007d3d13bcf054  jnz 0x00007D3D13BCF086
00007d3d13bcf056  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcf05e  jz 0x00007D3D13BCF170
00007d3d13bcf064  nop [rax+rax*1], ax
00007d3d13bcf06d  nop [rax+rax*1], eax
00007d3d13bcf075  mov eax, 0x410790
00007d3d13bcf07a  mov [r15+0x100], rax
00007d3d13bcf081  jmp 0x00007D3D139FE110
00007d3d13bcf086  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcf08e  jz 0x00007D3D13BCF0E0
00007d3d13bcf094  nop [rax+rax*1], ax
00007d3d13bcf09d  nop [rax+rax*1], eax
00007d3d13bcf0a5  mov eax, 0x410768
00007d3d13bcf0aa  mov [r15+0x100], rax
00007d3d13bcf0b1  jmp 0x00007D3D139FE110
00007d3d13bcf0b6  int3
00007d3d13bcf0b7  call 0x00007D3D13A0D860
00007d3d13bcf0bc  jmp 0x00007D3D13BCEFDA
00007d3d13bcf0c1  call 0x00007D3D13AB36E0
00007d3d13bcf0c6  jmp 0x00007D3D13BCF00A
00007d3d13bcf0cb  call 0x00007D3D13A0DD60
00007d3d13bcf0d0  jmp 0x00007D3D13BCF024
00007d3d13bcf0d5  call 0x00007D3D13A0DC20
00007d3d13bcf0da  jmp 0x00007D3D13BCF02E
00007d3d13bcf0df  int3
00007d3d13bcf0e0  mov rax, [r15+0x10]
00007d3d13bcf0e4  lea r14, [rax-0x01]
00007d3d13bcf0e8  mov [r15+0x10], r14
00007d3d13bcf0ec  test r14, r14
00007d3d13bcf0ef  setz r14b
00007d3d13bcf0f3  movzx r14, r14b
00007d3d13bcf0f7  mov [rsp+0x414], r14b
00007d3d13bcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007d3d13bcf107  jz 0x00007D3D13BCF139
00007d3d13bcf109  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcf111  jz 0x00007D3D13BD0670
00007d3d13bcf117  nop [rax+rax*1], ax
00007d3d13bcf120  nop [rax+rax*1], eax
00007d3d13bcf128  mov eax, 0x410988
00007d3d13bcf12d  mov [r15+0x100], rax
00007d3d13bcf134  jmp 0x00007D3D139FE110
00007d3d13bcf139  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcf141  jz 0x00007D3D13BCEFD0
00007d3d13bcf147  nop [rax+rax*1], ax
00007d3d13bcf150  nop [rax+rax*1], eax
00007d3d13bcf158  mov eax, 0x410770
00007d3d13bcf15d  mov [r15+0x100], rax
00007d3d13bcf164  jmp 0x00007D3D139FE110
00007d3d13bcf169  int3
00007d3d13bcf16a  int3
00007d3d13bcf16b  nop [rax+rax*1], eax
00007d3d13bcf170  mov rax, [r15+0x40]
00007d3d13bcf174  movzx r14d, byte ptr [r13+rax*1]
00007d3d13bcf17a  movaps xmm1, [r15+0x110]
00007d3d13bcf182  pinsrb xmm1, r14d, 0x00
00007d3d13bcf189  lea r14, [rax+0x01]
00007d3d13bcf18d  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf193  movaps xmm15, [r15+0x120]
00007d3d13bcf19b  pinsrb xmm15, r12d, 0x00
00007d3d13bcf1a2  lea r14, [rax+0x02]
00007d3d13bcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf1ac  movaps xmm14, [r15+0x130]
00007d3d13bcf1b4  pinsrb xmm14, r12d, 0x00
00007d3d13bcf1bb  lea r14, [rax+0x03]
00007d3d13bcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf1c5  movaps xmm13, [r15+0x140]
00007d3d13bcf1cd  pinsrb xmm13, r12d, 0x00
00007d3d13bcf1d4  lea r14, [rax+0x04]
00007d3d13bcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf1de  pinsrb xmm1, r12d, 0x01
00007d3d13bcf1e5  lea r14, [rax+0x05]
00007d3d13bcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf1ef  pinsrb xmm15, r12d, 0x01
00007d3d13bcf1f6  lea r14, [rax+0x06]
00007d3d13bcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf200  pinsrb xmm14, r12d, 0x01
00007d3d13bcf207  lea r14, [rax+0x07]
00007d3d13bcf20b  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf211  pinsrb xmm13, r12d, 0x01
00007d3d13bcf218  lea r14, [rax+0x08]
00007d3d13bcf21c  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf222  pinsrb xmm1, r12d, 0x02
00007d3d13bcf229  lea r14, [rax+0x09]
00007d3d13bcf22d  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf233  pinsrb xmm15, r12d, 0x02
00007d3d13bcf23a  lea r14, [rax+0x0A]
00007d3d13bcf23e  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf244  pinsrb xmm14, r12d, 0x02
00007d3d13bcf24b  lea r14, [rax+0x0B]
00007d3d13bcf24f  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf255  pinsrb xmm13, r12d, 0x02
00007d3d13bcf25c  lea r14, [rax+0x0C]
00007d3d13bcf260  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf266  pinsrb xmm1, r12d, 0x03
00007d3d13bcf26d  lea r14, [rax+0x0D]
00007d3d13bcf271  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf277  pinsrb xmm15, r12d, 0x03
00007d3d13bcf27e  lea r14, [rax+0x0E]
00007d3d13bcf282  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf288  pinsrb xmm14, r12d, 0x03
00007d3d13bcf28f  lea r14, [rax+0x0F]
00007d3d13bcf293  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf299  pinsrb xmm13, r12d, 0x03
00007d3d13bcf2a0  lea r14, [rax+0x10]
00007d3d13bcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf2aa  pinsrb xmm1, r12d, 0x04
00007d3d13bcf2b1  lea r14, [rax+0x11]
00007d3d13bcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf2bb  pinsrb xmm15, r12d, 0x04
00007d3d13bcf2c2  lea r14, [rax+0x12]
00007d3d13bcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf2cc  pinsrb xmm14, r12d, 0x04
00007d3d13bcf2d3  lea r14, [rax+0x13]
00007d3d13bcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf2dd  pinsrb xmm13, r12d, 0x04
00007d3d13bcf2e4  lea r14, [rax+0x14]
00007d3d13bcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf2ee  pinsrb xmm1, r12d, 0x05
00007d3d13bcf2f5  lea r14, [rax+0x15]
00007d3d13bcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf2ff  pinsrb xmm15, r12d, 0x05
00007d3d13bcf306  lea r14, [rax+0x16]
00007d3d13bcf30a  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf310  pinsrb xmm14, r12d, 0x05
00007d3d13bcf317  lea r14, [rax+0x17]
00007d3d13bcf31b  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf321  pinsrb xmm13, r12d, 0x05
00007d3d13bcf328  lea r14, [rax+0x18]
00007d3d13bcf32c  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf332  pinsrb xmm1, r12d, 0x06
00007d3d13bcf339  lea r14, [rax+0x19]
00007d3d13bcf33d  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf343  pinsrb xmm15, r12d, 0x06
00007d3d13bcf34a  lea r14, [rax+0x1A]
00007d3d13bcf34e  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf354  pinsrb xmm14, r12d, 0x06
00007d3d13bcf35b  lea r14, [rax+0x1B]
00007d3d13bcf35f  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf365  pinsrb xmm13, r12d, 0x06
00007d3d13bcf36c  lea r14, [rax+0x1C]
00007d3d13bcf370  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf376  pinsrb xmm1, r12d, 0x07
00007d3d13bcf37d  lea r14, [rax+0x1D]
00007d3d13bcf381  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf387  pinsrb xmm15, r12d, 0x07
00007d3d13bcf38e  lea r14, [rax+0x1E]
00007d3d13bcf392  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf398  pinsrb xmm14, r12d, 0x07
00007d3d13bcf39f  lea r14, [rax+0x1F]
00007d3d13bcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf3a9  pinsrb xmm13, r12d, 0x07
00007d3d13bcf3b0  lea r14, [rax+0x20]
00007d3d13bcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf3ba  pinsrb xmm1, r12d, 0x08
00007d3d13bcf3c1  lea r14, [rax+0x21]
00007d3d13bcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf3cb  pinsrb xmm15, r12d, 0x08
00007d3d13bcf3d2  lea r14, [rax+0x22]
00007d3d13bcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf3dc  pinsrb xmm14, r12d, 0x08
00007d3d13bcf3e3  lea r14, [rax+0x23]
00007d3d13bcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf3ed  pinsrb xmm13, r12d, 0x08
00007d3d13bcf3f4  lea r14, [rax+0x24]
00007d3d13bcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf3fe  pinsrb xmm1, r12d, 0x09
00007d3d13bcf405  lea r14, [rax+0x25]
00007d3d13bcf409  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf40f  pinsrb xmm15, r12d, 0x09
00007d3d13bcf416  lea r14, [rax+0x26]
00007d3d13bcf41a  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf420  pinsrb xmm14, r12d, 0x09
00007d3d13bcf427  lea r14, [rax+0x27]
00007d3d13bcf42b  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf431  pinsrb xmm13, r12d, 0x09
00007d3d13bcf438  lea r14, [rax+0x28]
00007d3d13bcf43c  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf442  pinsrb xmm1, r12d, 0x0A
00007d3d13bcf449  lea r14, [rax+0x29]
00007d3d13bcf44d  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf453  pinsrb xmm15, r12d, 0x0A
00007d3d13bcf45a  lea r14, [rax+0x2A]
00007d3d13bcf45e  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf464  pinsrb xmm14, r12d, 0x0A
00007d3d13bcf46b  lea r14, [rax+0x2B]
00007d3d13bcf46f  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf475  pinsrb xmm13, r12d, 0x0A
00007d3d13bcf47c  lea r14, [rax+0x2C]
00007d3d13bcf480  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf486  pinsrb xmm1, r12d, 0x0B
00007d3d13bcf48d  lea r14, [rax+0x2D]
00007d3d13bcf491  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf497  pinsrb xmm15, r12d, 0x0B
00007d3d13bcf49e  lea r14, [rax+0x2E]
00007d3d13bcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf4a8  pinsrb xmm14, r12d, 0x0B
00007d3d13bcf4af  lea r14, [rax+0x2F]
00007d3d13bcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf4b9  pinsrb xmm13, r12d, 0x0B
00007d3d13bcf4c0  lea r14, [rax+0x30]
00007d3d13bcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf4ca  pinsrb xmm1, r12d, 0x0C
00007d3d13bcf4d1  lea r14, [rax+0x31]
00007d3d13bcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf4db  pinsrb xmm15, r12d, 0x0C
00007d3d13bcf4e2  lea r14, [rax+0x32]
00007d3d13bcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf4ec  pinsrb xmm14, r12d, 0x0C
00007d3d13bcf4f3  lea r14, [rax+0x33]
00007d3d13bcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf4fd  pinsrb xmm13, r12d, 0x0C
00007d3d13bcf504  lea r14, [rax+0x34]
00007d3d13bcf508  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf50e  pinsrb xmm1, r12d, 0x0D
00007d3d13bcf515  lea r14, [rax+0x35]
00007d3d13bcf519  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf51f  pinsrb xmm15, r12d, 0x0D
00007d3d13bcf526  lea r14, [rax+0x36]
00007d3d13bcf52a  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf530  pinsrb xmm14, r12d, 0x0D
00007d3d13bcf537  lea r14, [rax+0x37]
00007d3d13bcf53b  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf541  pinsrb xmm13, r12d, 0x0D
00007d3d13bcf548  lea r14, [rax+0x38]
00007d3d13bcf54c  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf552  pinsrb xmm1, r12d, 0x0E
00007d3d13bcf559  lea r14, [rax+0x39]
00007d3d13bcf55d  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf563  pinsrb xmm15, r12d, 0x0E
00007d3d13bcf56a  lea r14, [rax+0x3A]
00007d3d13bcf56e  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf574  pinsrb xmm14, r12d, 0x0E
00007d3d13bcf57b  lea r14, [rax+0x3B]
00007d3d13bcf57f  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf585  pinsrb xmm13, r12d, 0x0E
00007d3d13bcf58c  lea r14, [rax+0x3C]
00007d3d13bcf590  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf596  pinsrb xmm1, r12d, 0x0F
00007d3d13bcf59d  movaps [r15+0x110], xmm1
00007d3d13bcf5a5  lea r14, [rax+0x3D]
00007d3d13bcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf5af  pinsrb xmm15, r12d, 0x0F
00007d3d13bcf5b6  movaps [r15+0x120], xmm15
00007d3d13bcf5be  lea r14, [rax+0x3E]
00007d3d13bcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007d3d13bcf5c8  pinsrb xmm14, r12d, 0x0F
00007d3d13bcf5cf  movaps [r15+0x130], xmm14
00007d3d13bcf5d7  lea r14, [rax+0x3F]
00007d3d13bcf5db  movzx eax, byte ptr [r13+r14*1]
00007d3d13bcf5e1  pinsrb xmm13, eax, 0x0F
00007d3d13bcf5e8  movaps [r15+0x140], xmm13
00007d3d13bcf5f0  movq xmm1, qword ptr [r15+0x120]
00007d3d13bcf5f9  pmovzxbw xmm1, xmm1
00007d3d13bcf5fe  psllw xmm1, 0x00
00007d3d13bcf603  movaps [r15+0x150], xmm1
00007d3d13bcf60b  movq xmm1, qword ptr [r15+0x130]
00007d3d13bcf614  pmovzxbw xmm1, xmm1
00007d3d13bcf619  psllw xmm1, 0x00
00007d3d13bcf61e  movaps [r15+0x160], xmm1
00007d3d13bcf626  movq xmm1, qword ptr [r15+0x110]
00007d3d13bcf62f  pmovzxbw xmm1, xmm1
00007d3d13bcf634  psllw xmm1, 0x00
00007d3d13bcf639  movaps [r15+0x170], xmm1
00007d3d13bcf641  movaps xmm15, [r15+0x110]
00007d3d13bcf649  pextrq rax, xmm15, 0x01
00007d3d13bcf650  movq xmm15, rax
00007d3d13bcf655  pmovzxbw xmm15, xmm15
00007d3d13bcf65b  psllw xmm15, 0x00
00007d3d13bcf661  movaps [r15+0x180], xmm15
00007d3d13bcf669  movaps xmm14, [r15+0x120]
00007d3d13bcf671  pextrq rax, xmm14, 0x01
00007d3d13bcf678  movq xmm14, rax
00007d3d13bcf67d  pmovzxbw xmm14, xmm14
00007d3d13bcf683  psllw xmm14, 0x00
00007d3d13bcf689  movaps [r15+0x210], xmm14
00007d3d13bcf691  movaps xmm13, [r15+0x130]
00007d3d13bcf699  pextrq rax, xmm13, 0x01
00007d3d13bcf6a0  movq xmm13, rax
00007d3d13bcf6a5  pmovzxbw xmm13, xmm13
00007d3d13bcf6ab  psllw xmm13, 0x00
00007d3d13bcf6b1  movaps [r15+0x220], xmm13
00007d3d13bcf6b9  movq xmm12, qword ptr [r15+0x140]
00007d3d13bcf6c2  pmovzxbw xmm12, xmm12
00007d3d13bcf6c8  psllw xmm12, 0x00
00007d3d13bcf6ce  movaps [r15+0x250], xmm12
00007d3d13bcf6d6  movaps xmm12, [r15+0x140]
00007d3d13bcf6de  pextrq rax, xmm12, 0x01
00007d3d13bcf6e5  movq xmm12, rax
00007d3d13bcf6ea  pmovzxbw xmm12, xmm12
00007d3d13bcf6f0  psllw xmm12, 0x00
00007d3d13bcf6f6  movaps [r15+0x110], xmm12
00007d3d13bcf6fe  movq xmm11, qword ptr [r15+0x150]
00007d3d13bcf707  pmovzxwd xmm11, xmm11
00007d3d13bcf70d  pslld xmm11, 0x10
00007d3d13bcf713  movq xmm10, qword ptr [r15+0x160]
00007d3d13bcf71c  pmovzxwd xmm10, xmm10
00007d3d13bcf722  pslld xmm10, 0x08
00007d3d13bcf728  pextrq rax, xmm1, 0x01
00007d3d13bcf72f  movq xmm1, rax
00007d3d13bcf734  pmovzxwd xmm1, xmm1
00007d3d13bcf739  pslld xmm1, 0x00
00007d3d13bcf73e  movaps [r15+0x260], xmm1
00007d3d13bcf746  pextrq rax, xmm15, 0x01
00007d3d13bcf74d  movq xmm15, rax
00007d3d13bcf752  pmovzxwd xmm15, xmm15
00007d3d13bcf758  pslld xmm15, 0x00
00007d3d13bcf75e  movaps [r15+0x270], xmm15
00007d3d13bcf766  movq xmm9, qword ptr [r15+0x170]
00007d3d13bcf76f  pmovzxwd xmm9, xmm9
00007d3d13bcf775  pslld xmm9, 0x00
00007d3d13bcf77b  pextrq rax, xmm14, 0x01
00007d3d13bcf782  movq xmm14, rax
00007d3d13bcf787  pmovzxwd xmm14, xmm14
00007d3d13bcf78d  pslld xmm14, 0x10
00007d3d13bcf793  movaps [r15+0x280], xmm14
00007d3d13bcf79b  movq xmm8, qword ptr [r15+0x180]
00007d3d13bcf7a4  pmovzxwd xmm8, xmm8
00007d3d13bcf7aa  pslld xmm8, 0x00
00007d3d13bcf7b0  movq xmm7, qword ptr [r15+0x210]
00007d3d13bcf7b9  pmovzxwd xmm7, xmm7
00007d3d13bcf7be  pslld xmm7, 0x10
00007d3d13bcf7c3  movaps xmm6, [r15+0x150]
00007d3d13bcf7cb  pextrq rax, xmm6, 0x01
00007d3d13bcf7d2  movq xmm6, rax
00007d3d13bcf7d7  pmovzxwd xmm6, xmm6
00007d3d13bcf7dc  pslld xmm6, 0x10
00007d3d13bcf7e1  por xmm11, xmm10
00007d3d13bcf7e6  movaps [r15+0x230], xmm11
00007d3d13bcf7ee  pextrq rax, xmm13, 0x01
00007d3d13bcf7f5  movq xmm13, rax
00007d3d13bcf7fa  pmovzxwd xmm13, xmm13
00007d3d13bcf800  pslld xmm13, 0x08
00007d3d13bcf806  movaps [r15+0x240], xmm13
00007d3d13bcf80e  movq xmm10, qword ptr [r15+0x220]
00007d3d13bcf817  pmovzxwd xmm10, xmm10
00007d3d13bcf81d  pslld xmm10, 0x08
00007d3d13bcf823  movaps xmm5, [r15+0x160]
00007d3d13bcf82b  pextrq rax, xmm5, 0x01
00007d3d13bcf832  movq xmm5, rax
00007d3d13bcf837  pmovzxwd xmm5, xmm5
00007d3d13bcf83c  pslld xmm5, 0x08
00007d3d13bcf841  pslld xmm9, 0x18
00007d3d13bcf847  pslld xmm15, 0x18
00007d3d13bcf84d  pslld xmm8, 0x18
00007d3d13bcf853  movq xmm4, qword ptr [r15+0x250]
00007d3d13bcf85c  pmovzxwd xmm4, xmm4
00007d3d13bcf861  pslld xmm4, 0x00
00007d3d13bcf866  por xmm14, xmm13
00007d3d13bcf86b  por xmm7, xmm10
00007d3d13bcf870  movaps [r15+0x210], xmm7
00007d3d13bcf878  pslld xmm1, 0x18
00007d3d13bcf87d  movaps [r15+0x220], xmm1
00007d3d13bcf885  por xmm6, xmm5
00007d3d13bcf889  por xmm11, xmm9
00007d3d13bcf88e  movaps [r15+0x160], xmm11
00007d3d13bcf896  pextrq rax, xmm12, 0x01
00007d3d13bcf89d  movq xmm13, rax
00007d3d13bcf8a2  pmovzxwd xmm13, xmm13
00007d3d13bcf8a8  pslld xmm13, 0x00
00007d3d13bcf8ae  movaps [r15+0x170], xmm13
00007d3d13bcf8b6  movq xmm12, qword ptr [r15+0x110]
00007d3d13bcf8bf  pmovzxwd xmm12, xmm12
00007d3d13bcf8c5  pslld xmm12, 0x00
00007d3d13bcf8cb  por xmm14, xmm15
00007d3d13bcf8d0  por xmm7, xmm8
00007d3d13bcf8d5  movaps xmm15, [r15+0x250]
00007d3d13bcf8dd  pextrq rax, xmm15, 0x01
00007d3d13bcf8e4  movq xmm15, rax
00007d3d13bcf8e9  pmovzxwd xmm15, xmm15
00007d3d13bcf8ef  pslld xmm15, 0x00
00007d3d13bcf8f5  movaps [r15+0x180], xmm15
00007d3d13bcf8fd  por xmm6, xmm1
00007d3d13bcf901  movaps [r15+0x150], xmm6
00007d3d13bcf909  por xmm11, xmm4
00007d3d13bcf90e  movaps [r15+0x140], xmm11
00007d3d13bcf916  por xmm7, xmm12
00007d3d13bcf91b  movaps [r15+0x110], xmm7
00007d3d13bcf923  por xmm14, xmm13
00007d3d13bcf928  movaps [r15+0x120], xmm14
00007d3d13bcf930  por xmm6, xmm15
00007d3d13bcf935  movaps [r15+0x130], xmm6
00007d3d13bcf93d  mov rax, [r15+0xF8]
00007d3d13bcf944  lea r14, [rax+0x20]
00007d3d13bcf948  movups [r13+r14*1], xmm7
00007d3d13bcf94e  lea r14, [rax+0x30]
00007d3d13bcf952  movups [r13+r14*1], xmm14
00007d3d13bcf958  movups [r13+rax*1], xmm11
00007d3d13bcf95e  lea r14, [rax+0x10]
00007d3d13bcf962  movups [r13+r14*1], xmm6
00007d3d13bcf968  mov r14d, [r13+rax*1]
00007d3d13bcf96d  mov rax, [r15+0x48]
00007d3d13bcf971  mov [r15+0x68], rax
00007d3d13bcf975  mov qword ptr [r15+0x58], 0x04
00007d3d13bcf97d  lea r12, [rax+0x04]
00007d3d13bcf981  mov r11d, [r13+r12*1]
00007d3d13bcf986  mov [rsp+0x10], r11d
00007d3d13bcf98b  mov r11d, r11d
00007d3d13bcf98e  mov [r15+0x70], r11
00007d3d13bcf992  lea r12, [rax+0x38]
00007d3d13bcf996  mov r11d, [r13+r12*1]
00007d3d13bcf99b  lea r12, [rax+0x24]
00007d3d13bcf99f  mov r10d, [r13+r12*1]
00007d3d13bcf9a4  mov [rsp+0x20], r10d
00007d3d13bcf9a9  mov r10d, r10d
00007d3d13bcf9ac  mov [r15+0x90], r10
00007d3d13bcf9b3  mov [rsp+0x30], rax
00007d3d13bcf9b8  xor eax, eax
00007d3d13bcf9ba  mov r12d, 0x04
00007d3d13bcf9c0  mov r10d, 0xC0
00007d3d13bcf9c6  cmp r12, r10
00007d3d13bcf9c9  cmc
00007d3d13bcf9ca  lahf
00007d3d13bcf9cb  seto al
00007d3d13bcf9ce  mov [r15+0x108], eax
00007d3d13bcf9d5  mov eax, [rsp+0x10]
00007d3d13bcf9d9  mov r12d, [rsp+0x10]
00007d3d13bcf9de  shrd eax, r12d, 0x07
00007d3d13bcf9e3  mov [rsp+0x10], r11d
00007d3d13bcf9e8  mov r10d, [rsp+0x10]
00007d3d13bcf9ed  shrd r11d, r10d, 0x11
00007d3d13bcf9f2  mov r9d, [rsp+0x20]
00007d3d13bcf9f7  lea r8d, [r9d+r14d*1]
00007d3d13bcf9fc  rorx r14d, r12d, 0x12
00007d3d13bcfa02  xor eax, r14d
00007d3d13bcfa05  rorx r14d, r10d, 0x13
00007d3d13bcfa0b  xor r11d, r14d
00007d3d13bcfa0e  mov [rsp+0x10], r11d
00007d3d13bcfa13  mov r11d, r11d
00007d3d13bcfa16  mov [r15+0x88], r11
00007d3d13bcfa1d  mov [rsp+0x20], r12d
00007d3d13bcfa22  shr r12d, 0x03
00007d3d13bcfa26  xor eax, r12d
00007d3d13bcfa29  mov [rsp+0x40], eax
00007d3d13bcfa2d  mov eax, eax
00007d3d13bcfa2f  mov [r15+0x80], rax
00007d3d13bcfa36  shr r10d, 0x0A
00007d3d13bcfa3a  mov eax, [rsp+0x10]
00007d3d13bcfa3e  xor eax, r10d
00007d3d13bcfa41  mov [rsp+0x10], eax
00007d3d13bcfa45  mov eax, eax
00007d3d13bcfa47  mov [r15+0x78], rax
00007d3d13bcfa4b  mov eax, [rsp+0x40]
00007d3d13bcfa4f  lea r14d, [r8d+eax*1]
00007d3d13bcfa54  mov eax, [rsp+0x10]
00007d3d13bcfa58  lea r12d, [r14d+eax*1]
00007d3d13bcfa5d  mov rax, [rsp+0x30]
00007d3d13bcfa62  lea r14, [rax+0x40]
00007d3d13bcfa66  mov [r13+r14*1], r12d
00007d3d13bcfa6b  mov eax, [rsp+0x20]
00007d3d13bcfa6f  mov eax, eax
00007d3d13bcfa71  mov [r15+0x60], rax
00007d3d13bcfa75  mov eax, [r15+0x108]
00007d3d13bcfa7c  sahf
00007d3d13bcfa7d  jnz 0x00007D3D13BCFAAF
00007d3d13bcfa7f  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcfa87  jz 0x00007D3D13BCFF70
00007d3d13bcfa8d  nop [rax+rax*1], ax
00007d3d13bcfa96  nop [rax+rax*1], eax
00007d3d13bcfa9e  mov eax, 0x41088C
00007d3d13bcfaa3  mov [r15+0x100], rax
00007d3d13bcfaaa  jmp 0x00007D3D139FE110
00007d3d13bcfaaf  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcfab7  jz 0x00007D3D13BCFDC0
00007d3d13bcfabd  nop [rax+rax*1], ax
00007d3d13bcfac6  nop [rax+rax*1], eax
00007d3d13bcface  mov eax, 0x410844
00007d3d13bcfad3  mov [r15+0x100], rax
00007d3d13bcfada  jmp 0x00007D3D139FE110
00007d3d13bcfadf  int3
00007d3d13bcfae0  call 0x00007D3D13A0D860
00007d3d13bcfae5  jmp 0x00007D3D13BCF17A
00007d3d13bcfaea  call 0x00007D3D13AE2420
00007d3d13bcfaef  jmp 0x00007D3D13BCF193
00007d3d13bcfaf4  call 0x00007D3D13AE2420
00007d3d13bcfaf9  jmp 0x00007D3D13BCF1AC
00007d3d13bcfafe  call 0x00007D3D13AE2420
00007d3d13bcfb03  jmp 0x00007D3D13BCF1C5
00007d3d13bcfb08  call 0x00007D3D13AE2420
00007d3d13bcfb0d  jmp 0x00007D3D13BCF1DE
00007d3d13bcfb12  call 0x00007D3D13AE2420
00007d3d13bcfb17  jmp 0x00007D3D13BCF1EF
00007d3d13bcfb1c  call 0x00007D3D13AE2420
00007d3d13bcfb21  jmp 0x00007D3D13BCF200
00007d3d13bcfb26  call 0x00007D3D13AE2420
00007d3d13bcfb2b  jmp 0x00007D3D13BCF211
00007d3d13bcfb30  call 0x00007D3D13AE2420
00007d3d13bcfb35  jmp 0x00007D3D13BCF222
00007d3d13bcfb3a  call 0x00007D3D13AE2420
00007d3d13bcfb3f  jmp 0x00007D3D13BCF233
00007d3d13bcfb44  call 0x00007D3D13AE2420
00007d3d13bcfb49  jmp 0x00007D3D13BCF244
00007d3d13bcfb4e  call 0x00007D3D13AE2420
00007d3d13bcfb53  jmp 0x00007D3D13BCF255
00007d3d13bcfb58  call 0x00007D3D13AE2420
00007d3d13bcfb5d  jmp 0x00007D3D13BCF266
00007d3d13bcfb62  call 0x00007D3D13AE2420
00007d3d13bcfb67  jmp 0x00007D3D13BCF277
00007d3d13bcfb6c  call 0x00007D3D13AE2420
00007d3d13bcfb71  jmp 0x00007D3D13BCF288
00007d3d13bcfb76  call 0x00007D3D13AE2420
00007d3d13bcfb7b  jmp 0x00007D3D13BCF299
00007d3d13bcfb80  call 0x00007D3D13AE2420
00007d3d13bcfb85  jmp 0x00007D3D13BCF2AA
00007d3d13bcfb8a  call 0x00007D3D13AE2420
00007d3d13bcfb8f  jmp 0x00007D3D13BCF2BB
00007d3d13bcfb94  call 0x00007D3D13AE2420
00007d3d13bcfb99  jmp 0x00007D3D13BCF2CC
00007d3d13bcfb9e  call 0x00007D3D13AE2420
00007d3d13bcfba3  jmp 0x00007D3D13BCF2DD
00007d3d13bcfba8  call 0x00007D3D13AE2420
00007d3d13bcfbad  jmp 0x00007D3D13BCF2EE
00007d3d13bcfbb2  call 0x00007D3D13AE2420
00007d3d13bcfbb7  jmp 0x00007D3D13BCF2FF
00007d3d13bcfbbc  call 0x00007D3D13AE2420
00007d3d13bcfbc1  jmp 0x00007D3D13BCF310
00007d3d13bcfbc6  call 0x00007D3D13AE2420
00007d3d13bcfbcb  jmp 0x00007D3D13BCF321
00007d3d13bcfbd0  call 0x00007D3D13AE2420
00007d3d13bcfbd5  jmp 0x00007D3D13BCF332
00007d3d13bcfbda  call 0x00007D3D13AE2420
00007d3d13bcfbdf  jmp 0x00007D3D13BCF343
00007d3d13bcfbe4  call 0x00007D3D13AE2420
00007d3d13bcfbe9  jmp 0x00007D3D13BCF354
00007d3d13bcfbee  call 0x00007D3D13AE2420
00007d3d13bcfbf3  jmp 0x00007D3D13BCF365
00007d3d13bcfbf8  call 0x00007D3D13AE2420
00007d3d13bcfbfd  jmp 0x00007D3D13BCF376
00007d3d13bcfc02  call 0x00007D3D13AE2420
00007d3d13bcfc07  jmp 0x00007D3D13BCF387
00007d3d13bcfc0c  call 0x00007D3D13AE2420
00007d3d13bcfc11  jmp 0x00007D3D13BCF398
00007d3d13bcfc16  call 0x00007D3D13AE2420
00007d3d13bcfc1b  jmp 0x00007D3D13BCF3A9
00007d3d13bcfc20  call 0x00007D3D13AE2420
00007d3d13bcfc25  jmp 0x00007D3D13BCF3BA
00007d3d13bcfc2a  call 0x00007D3D13AE2420
00007d3d13bcfc2f  jmp 0x00007D3D13BCF3CB
00007d3d13bcfc34  call 0x00007D3D13AE2420
00007d3d13bcfc39  jmp 0x00007D3D13BCF3DC
00007d3d13bcfc3e  call 0x00007D3D13AE2420
00007d3d13bcfc43  jmp 0x00007D3D13BCF3ED
00007d3d13bcfc48  call 0x00007D3D13AE2420
00007d3d13bcfc4d  jmp 0x00007D3D13BCF3FE
00007d3d13bcfc52  call 0x00007D3D13AE2420
00007d3d13bcfc57  jmp 0x00007D3D13BCF40F
00007d3d13bcfc5c  call 0x00007D3D13AE2420
00007d3d13bcfc61  jmp 0x00007D3D13BCF420
00007d3d13bcfc66  call 0x00007D3D13AE2420
00007d3d13bcfc6b  jmp 0x00007D3D13BCF431
00007d3d13bcfc70  call 0x00007D3D13AE2420
00007d3d13bcfc75  jmp 0x00007D3D13BCF442
00007d3d13bcfc7a  call 0x00007D3D13AE2420
00007d3d13bcfc7f  jmp 0x00007D3D13BCF453
00007d3d13bcfc84  call 0x00007D3D13AE2420
00007d3d13bcfc89  jmp 0x00007D3D13BCF464
00007d3d13bcfc8e  call 0x00007D3D13AE2420
00007d3d13bcfc93  jmp 0x00007D3D13BCF475
00007d3d13bcfc98  call 0x00007D3D13AE2420
00007d3d13bcfc9d  jmp 0x00007D3D13BCF486
00007d3d13bcfca2  call 0x00007D3D13AE2420
00007d3d13bcfca7  jmp 0x00007D3D13BCF497
00007d3d13bcfcac  call 0x00007D3D13AE2420
00007d3d13bcfcb1  jmp 0x00007D3D13BCF4A8
00007d3d13bcfcb6  call 0x00007D3D13AE2420
00007d3d13bcfcbb  jmp 0x00007D3D13BCF4B9
00007d3d13bcfcc0  call 0x00007D3D13AE2420
00007d3d13bcfcc5  jmp 0x00007D3D13BCF4CA
00007d3d13bcfcca  call 0x00007D3D13AE2420
00007d3d13bcfccf  jmp 0x00007D3D13BCF4DB
00007d3d13bcfcd4  call 0x00007D3D13AE2420
00007d3d13bcfcd9  jmp 0x00007D3D13BCF4EC
00007d3d13bcfcde  call 0x00007D3D13AE2420
00007d3d13bcfce3  jmp 0x00007D3D13BCF4FD
00007d3d13bcfce8  call 0x00007D3D13AE2420
00007d3d13bcfced  jmp 0x00007D3D13BCF50E
00007d3d13bcfcf2  call 0x00007D3D13AE2420
00007d3d13bcfcf7  jmp 0x00007D3D13BCF51F
00007d3d13bcfcfc  call 0x00007D3D13AE2420
00007d3d13bcfd01  jmp 0x00007D3D13BCF530
00007d3d13bcfd06  call 0x00007D3D13AE2420
00007d3d13bcfd0b  jmp 0x00007D3D13BCF541
00007d3d13bcfd10  call 0x00007D3D13AE2420
00007d3d13bcfd15  jmp 0x00007D3D13BCF552
00007d3d13bcfd1a  call 0x00007D3D13AE2420
00007d3d13bcfd1f  jmp 0x00007D3D13BCF563
00007d3d13bcfd24  call 0x00007D3D13AE2420
00007d3d13bcfd29  jmp 0x00007D3D13BCF574
00007d3d13bcfd2e  call 0x00007D3D13AE2420
00007d3d13bcfd33  jmp 0x00007D3D13BCF585
00007d3d13bcfd38  call 0x00007D3D13AE2420
00007d3d13bcfd3d  jmp 0x00007D3D13BCF596
00007d3d13bcfd42  call 0x00007D3D13AE2420
00007d3d13bcfd47  jmp 0x00007D3D13BCF5AF
00007d3d13bcfd4c  call 0x00007D3D13AE2420
00007d3d13bcfd51  jmp 0x00007D3D13BCF5C8
00007d3d13bcfd56  call 0x00007D3D13AD5610
00007d3d13bcfd5b  jmp 0x00007D3D13BCF5E1
00007d3d13bcfd60  call 0x00007D3D13ADC580
00007d3d13bcfd65  jmp 0x00007D3D13BCF94E
00007d3d13bcfd6a  call 0x00007D3D13AE46C0
00007d3d13bcfd6f  jmp 0x00007D3D13BCF958
00007d3d13bcfd74  call 0x00007D3D13A09E90
00007d3d13bcfd79  jmp 0x00007D3D13BCF95E
00007d3d13bcfd7e  call 0x00007D3D13ADB310
00007d3d13bcfd83  jmp 0x00007D3D13BCF968
00007d3d13bcfd88  call 0x00007D3D13A0DAE0
00007d3d13bcfd8d  jmp 0x00007D3D13BCF96D
00007d3d13bcfd92  call 0x00007D3D13AC0230
00007d3d13bcfd97  jmp 0x00007D3D13BCF986
00007d3d13bcfd9c  call 0x00007D3D13AC0230
00007d3d13bcfda1  jmp 0x00007D3D13BCF99B
00007d3d13bcfda6  call 0x00007D3D13ABEFC0
00007d3d13bcfdab  jmp 0x00007D3D13BCF9A4
00007d3d13bcfdb0  call 0x00007D3D13AE2BA0
00007d3d13bcfdb5  jmp 0x00007D3D13BCFA6B
00007d3d13bcfdba  int3
00007d3d13bcfdbb  nop [rax+rax*1], eax
00007d3d13bcfdc0  mov rax, [r15+0x48]
00007d3d13bcfdc4  mov r14, [r15+0x58]
00007d3d13bcfdc8  lea r12, [rax+r14*1]
00007d3d13bcfdcc  mov [r15+0x68], r12
00007d3d13bcfdd0  lea rax, [r14+0x04]
00007d3d13bcfdd4  mov [r15+0x58], rax
00007d3d13bcfdd8  lea r14, [r12+0x04]
00007d3d13bcfddd  mov r11d, [r13+r14*1]
00007d3d13bcfde2  mov [rsp+0x10], r11d
00007d3d13bcfde7  mov r11d, r11d
00007d3d13bcfdea  mov [r15+0x70], r11
00007d3d13bcfdee  lea r14, [r12+0x38]
00007d3d13bcfdf3  mov r11d, [r13+r14*1]
00007d3d13bcfdf8  lea r14, [r12+0x24]
00007d3d13bcfdfd  mov r10d, [r13+r14*1]
00007d3d13bcfe02  mov [rsp+0x20], r10d
00007d3d13bcfe07  mov r10d, r10d
00007d3d13bcfe0a  mov [r15+0x90], r10
00007d3d13bcfe11  mov [rsp+0x30], rax
00007d3d13bcfe16  xor eax, eax
00007d3d13bcfe18  mov r14, [rsp+0x30]
00007d3d13bcfe1d  mov r10d, 0xC0
00007d3d13bcfe23  cmp r14, r10
00007d3d13bcfe26  cmc
00007d3d13bcfe27  lahf
00007d3d13bcfe28  seto al
00007d3d13bcfe2b  mov [r15+0x108], eax
00007d3d13bcfe32  mov eax, [rsp+0x10]
00007d3d13bcfe36  mov r14d, [rsp+0x10]
00007d3d13bcfe3b  shrd eax, r14d, 0x07
00007d3d13bcfe40  mov [rsp+0x10], r11d
00007d3d13bcfe45  mov r10d, [rsp+0x10]
00007d3d13bcfe4a  shrd r11d, r10d, 0x11
00007d3d13bcfe4f  mov r9d, [r15+0x60]
00007d3d13bcfe53  mov r8d, [rsp+0x20]
00007d3d13bcfe58  lea ebp, [r8d+r9d*1]
00007d3d13bcfe5d  rorx r9d, r14d, 0x12
00007d3d13bcfe63  xor eax, r9d
00007d3d13bcfe66  rorx r9d, r10d, 0x13
00007d3d13bcfe6c  xor r11d, r9d
00007d3d13bcfe6f  mov [rsp+0x10], r11d
00007d3d13bcfe74  mov r11d, r11d
00007d3d13bcfe77  mov [r15+0x88], r11
00007d3d13bcfe7e  mov [rsp+0x20], r14d
00007d3d13bcfe83  shr r14d, 0x03
00007d3d13bcfe87  xor eax, r14d
00007d3d13bcfe8a  mov [rsp+0x30], eax
00007d3d13bcfe8e  mov eax, eax
00007d3d13bcfe90  mov [r15+0x80], rax
00007d3d13bcfe97  shr r10d, 0x0A
00007d3d13bcfe9b  mov eax, [rsp+0x10]
00007d3d13bcfe9f  xor eax, r10d
00007d3d13bcfea2  mov [rsp+0x10], eax
00007d3d13bcfea6  mov eax, eax
00007d3d13bcfea8  mov [r15+0x78], rax
00007d3d13bcfeac  mov eax, [rsp+0x30]
00007d3d13bcfeb0  lea r14d, [ebp+eax*1]
00007d3d13bcfeb6  mov eax, [rsp+0x10]
00007d3d13bcfeba  lea r11d, [r14d+eax*1]
00007d3d13bcfebf  lea rax, [r12+0x40]
00007d3d13bcfec4  mov [r13+rax*1], r11d
00007d3d13bcfec9  mov eax, [rsp+0x20]
00007d3d13bcfecd  mov eax, eax
00007d3d13bcfecf  mov [r15+0x60], rax
00007d3d13bcfed3  mov eax, [r15+0x108]
00007d3d13bcfeda  sahf
00007d3d13bcfedb  jnz 0x00007D3D13BCFF0D
00007d3d13bcfedd  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcfee5  jz 0x00007D3D13BCFF70
00007d3d13bcfeeb  nop [rax+rax*1], ax
00007d3d13bcfef4  nop [rax+rax*1], eax
00007d3d13bcfefc  mov eax, 0x41088C
00007d3d13bcff01  mov [r15+0x100], rax
00007d3d13bcff08  jmp 0x00007D3D139FE110
00007d3d13bcff0d  cmp dword ptr [r15+0x318], 0x00
00007d3d13bcff15  jz 0x00007D3D13BCFDC0
00007d3d13bcff1b  nop [rax+rax*1], ax
00007d3d13bcff24  nop [rax+rax*1], eax
00007d3d13bcff2c  mov eax, 0x410844
00007d3d13bcff31  mov [r15+0x100], rax
00007d3d13bcff38  jmp 0x00007D3D139FE110
00007d3d13bcff3d  int3
00007d3d13bcff3e  call 0x00007D3D13AE1430
00007d3d13bcff43  jmp 0x00007D3D13BCFDE2
00007d3d13bcff48  call 0x00007D3D13AE1430
00007d3d13bcff4d  jmp 0x00007D3D13BCFDF8
00007d3d13bcff52  call 0x00007D3D13AE01C0
00007d3d13bcff57  jmp 0x00007D3D13BCFE02
00007d3d13bcff5c  call 0x00007D3D13A0A860
00007d3d13bcff61  jmp 0x00007D3D13BCFEC9
00007d3d13bcff66  int3
00007d3d13bcff67  nop [rax+rax*1], ax
00007d3d13bcff70  mov rax, [r15]
00007d3d13bcff73  mov r14d, [r13+rax*1]
00007d3d13bcff78  lea r12, [rax+0x04]
00007d3d13bcff7c  mov r11d, [r13+r12*1]
00007d3d13bcff81  mov [rsp+0x10], r14d
00007d3d13bcff86  mov r14d, r14d
00007d3d13bcff89  mov [r15+0x78], r14
00007d3d13bcff8d  mov [rsp+0x20], r11d
00007d3d13bcff92  mov r11d, r11d
00007d3d13bcff95  mov [r15+0x80], r11
00007d3d13bcff9c  lea r14, [rax+0x08]
00007d3d13bcffa0  mov r12d, [r13+r14*1]
00007d3d13bcffa5  lea r14, [rax+0x0C]
00007d3d13bcffa9  mov r11d, [r13+r14*1]
00007d3d13bcffae  mov [rsp+0x30], r12d
00007d3d13bcffb3  mov r12d, r12d
00007d3d13bcffb6  mov [r15+0x70], r12
00007d3d13bcffba  mov [rsp+0x40], r11d
00007d3d13bcffbf  mov r11d, r11d
00007d3d13bcffc2  mov [r15+0x68], r11
00007d3d13bcffc6  lea r14, [rax+0x18]
00007d3d13bcffca  mov r12d, [r13+r14*1]
00007d3d13bcffcf  lea r14, [rax+0x1C]
00007d3d13bcffd3  mov r11d, [r13+r14*1]
00007d3d13bcffd8  mov [rsp+0x50], r12d
00007d3d13bcffdd  mov r12d, r12d
00007d3d13bcffe0  mov [r15+0x58], r12
00007d3d13bcffe4  mov [rsp+0x60], r11d
00007d3d13bcffe9  mov r11d, r11d
00007d3d13bcffec  mov [r15+0x60], r11
00007d3d13bcfff0  lea r14, [rax+0x10]
00007d3d13bcfff4  mov r12d, [r13+r14*1]
00007d3d13bcfff9  lea r14, [rax+0x14]
00007d3d13bcfffd  mov eax, [r13+r14*1]
00007d3d13bd0002  mov [rsp+0x70], r12d
00007d3d13bd0007  mov r12d, r12d
00007d3d13bd000a  mov [r15+0x18], r12
00007d3d13bd000e  mov [rsp+0x80], eax
00007d3d13bd0015  mov eax, eax
00007d3d13bd0017  mov [r15+0x90], rax
00007d3d13bd001e  mov eax, [rsp+0x70]
00007d3d13bd0022  mov eax, eax
00007d3d13bd0024  mov [r15+0x30], rax
00007d3d13bd0028  mov eax, [rsp+0x50]
00007d3d13bd002c  mov eax, eax
00007d3d13bd002e  mov [r15+0xA0], rax
00007d3d13bd0035  mov eax, [rsp+0x30]
00007d3d13bd0039  mov eax, eax
00007d3d13bd003b  mov [r15+0x28], rax
00007d3d13bd003f  mov eax, [rsp+0x20]
00007d3d13bd0043  mov eax, eax
00007d3d13bd0045  mov [r15+0x98], rax
00007d3d13bd004c  mov eax, [rsp+0x10]
00007d3d13bd0050  mov eax, eax
00007d3d13bd0052  mov [r15+0x38], rax
00007d3d13bd0056  mov eax, [rsp+0x70]
00007d3d13bd005a  mov r14d, [rsp+0x70]
00007d3d13bd005f  shrd eax, r14d, 0x06
00007d3d13bd0064  mov [rsp+0x70], r14d
00007d3d13bd0069  mov r12d, [rsp+0x80]
00007d3d13bd0071  and r14d, r12d
00007d3d13bd0074  mov r11d, [rsp+0x10]
00007d3d13bd0079  mov r10d, [rsp+0x10]
00007d3d13bd007e  shrd r11d, r10d, 0x02
00007d3d13bd0083  mov [rsp+0x10], r12d
00007d3d13bd0088  mov r12d, r12d
00007d3d13bd008b  mov [r15+0x20], r12
00007d3d13bd008f  mov r12, [r15+0x50]
00007d3d13bd0093  mov r9d, [r13+r12*1]
00007d3d13bd0098  mov r12d, [rsp+0x50]
00007d3d13bd009d  mov r8d, [rsp+0x70]
00007d3d13bd00a2  andn ebp, r8d, r12d
00007d3d13bd00a7  mov edi, [rsp+0x60]
00007d3d13bd00ab  lea esi, [r14d+edi*1]
00007d3d13bd00b0  rorx r14d, r8d, 0x0B
00007d3d13bd00b6  xor eax, r14d
00007d3d13bd00b9  rorx r14d, r10d, 0x0D
00007d3d13bd00bf  xor r11d, r14d
00007d3d13bd00c2  lea edi, [esi+ebp*1]
00007d3d13bd00c6  mov r14, [r15+0x48]
00007d3d13bd00ca  mov ebp, [r13+r14*1]
00007d3d13bd00cf  mov r14d, [rsp+0x30]
00007d3d13bd00d4  mov esi, [rsp+0x20]
00007d3d13bd00d8  and r14d, esi
00007d3d13bd00db  mov [rsp+0x20], r14d
00007d3d13bd00e0  mov r14d, r14d
00007d3d13bd00e3  mov [r15+0xD8], r14
00007d3d13bd00ea  lea r14d, [edi+r9d*1]
00007d3d13bd00ef  mov r9d, [rsp+0x30]
00007d3d13bd00f4  xor r9d, esi
00007d3d13bd00f7  rorx edi, r8d, 0x19
00007d3d13bd00fd  xor eax, edi
00007d3d13bd00ff  and r9d, r10d
00007d3d13bd0102  rorx edi, r10d, 0x16
00007d3d13bd0108  xor r11d, edi
00007d3d13bd010b  mov [rsp+0x30], r11d
00007d3d13bd0110  mov r11d, r11d
00007d3d13bd0113  mov [r15+0xD0], r11
00007d3d13bd011a  lea r11d, [r14d+ebp*1]
00007d3d13bd011f  mov r10d, [rsp+0x20]
00007d3d13bd0124  xor r9d, r10d
00007d3d13bd0127  lea r14d, [r11d+eax*1]
00007d3d13bd012c  mov qword ptr [r15+0x88], 0x04
00007d3d13bd0137  mov eax, [rsp+0x30]
00007d3d13bd013b  lea r11d, [r9d+eax*1]
00007d3d13bd0140  mov eax, [rsp+0x40]
00007d3d13bd0144  lea r10d, [r14d+eax*1]
00007d3d13bd0149  mov r10d, r10d
00007d3d13bd014c  mov [r15+0xB8], r10
00007d3d13bd0153  xor eax, eax
00007d3d13bd0155  mov r10d, 0x04
00007d3d13bd015b  mov r9d, 0x100
00007d3d13bd0161  cmp r10, r9
00007d3d13bd0164  cmc
00007d3d13bd0165  lahf
00007d3d13bd0166  seto al
00007d3d13bd0169  mov [r15+0x108], eax
00007d3d13bd0170  lea eax, [r11d+r14d*1]
00007d3d13bd0175  mov eax, eax
00007d3d13bd0177  mov [r15+0xA8], rax
00007d3d13bd017e  mov r12d, r12d
00007d3d13bd0181  mov [r15+0xB0], r12
00007d3d13bd0188  mov eax, [rsp+0x10]
00007d3d13bd018c  mov eax, eax
00007d3d13bd018e  mov [r15+0xC0], rax
00007d3d13bd0195  mov r8d, r8d
00007d3d13bd0198  mov [r15+0xC8], r8
00007d3d13bd019f  mov eax, [r15+0x108]
00007d3d13bd01a6  sahf
00007d3d13bd01a7  jnz 0x00007D3D13BD01D9
00007d3d13bd01a9  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd01b1  jz 0x00007D3D13BD04A0
00007d3d13bd01b7  nop [rax+rax*1], ax
00007d3d13bd01c0  nop [rax+rax*1], eax
00007d3d13bd01c8  mov eax, 0x41094C
00007d3d13bd01cd  mov [r15+0x100], rax
00007d3d13bd01d4  jmp 0x00007D3D139FE110
00007d3d13bd01d9  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd01e1  jz 0x00007D3D13BD0270
00007d3d13bd01e7  nop [rax+rax*1], ax
00007d3d13bd01f0  nop [rax+rax*1], eax
00007d3d13bd01f8  mov eax, 0x4108C0
00007d3d13bd01fd  mov [r15+0x100], rax
00007d3d13bd0204  jmp 0x00007D3D139FE110
00007d3d13bd0209  int3
00007d3d13bd020a  call 0x00007D3D13A0DAE0
00007d3d13bd020f  jmp 0x00007D3D13BCFF78
00007d3d13bd0214  call 0x00007D3D13AC0230
00007d3d13bd0219  jmp 0x00007D3D13BCFF81
00007d3d13bd021e  call 0x00007D3D13AE26A0
00007d3d13bd0223  jmp 0x00007D3D13BCFFA5
00007d3d13bd0228  call 0x00007D3D13AE1430
00007d3d13bd022d  jmp 0x00007D3D13BCFFAE
00007d3d13bd0232  call 0x00007D3D13AE26A0
00007d3d13bd0237  jmp 0x00007D3D13BCFFCF
00007d3d13bd023c  call 0x00007D3D13AE1430
00007d3d13bd0241  jmp 0x00007D3D13BCFFD8
00007d3d13bd0246  call 0x00007D3D13AE26A0
00007d3d13bd024b  jmp 0x00007D3D13BCFFF9
00007d3d13bd0250  call 0x00007D3D13AD5890
00007d3d13bd0255  jmp 0x00007D3D13BD0002
00007d3d13bd025a  call 0x00007D3D13ABDD50
00007d3d13bd025f  jmp 0x00007D3D13BD0098
00007d3d13bd0264  call 0x00007D3D13ADA580
00007d3d13bd0269  jmp 0x00007D3D13BD00CF
00007d3d13bd026e  int3
00007d3d13bd026f  nop
00007d3d13bd0270  mov eax, [r15+0xB8]
00007d3d13bd0277  mov [rsp+0x10], eax
00007d3d13bd027b  mov eax, eax
00007d3d13bd027d  mov [r15+0x30], rax
00007d3d13bd0281  mov eax, [r15+0xC0]
00007d3d13bd0288  mov [rsp+0x20], eax
00007d3d13bd028c  mov eax, eax
00007d3d13bd028e  mov [r15+0xA0], rax
00007d3d13bd0295  mov eax, [r15+0x28]
00007d3d13bd0299  mov r14d, [r15+0x98]
00007d3d13bd02a0  mov [rsp+0x30], r14d
00007d3d13bd02a5  mov r14d, r14d
00007d3d13bd02a8  mov [r15+0x28], r14
00007d3d13bd02ac  mov r14d, [r15+0x38]
00007d3d13bd02b0  mov [rsp+0x40], r14d
00007d3d13bd02b5  mov r14d, r14d
00007d3d13bd02b8  mov [r15+0x98], r14
00007d3d13bd02bf  mov r14d, [r15+0xA8]
00007d3d13bd02c6  mov [rsp+0x50], r14d
00007d3d13bd02cb  mov r14d, r14d
00007d3d13bd02ce  mov [r15+0x38], r14
00007d3d13bd02d2  mov r14d, [rsp+0x10]
00007d3d13bd02d7  mov r12d, [rsp+0x10]
00007d3d13bd02dc  shrd r14d, r12d, 0x06
00007d3d13bd02e1  mov r11d, [r15+0xC8]
00007d3d13bd02e8  mov [rsp+0x10], r12d
00007d3d13bd02ed  and r12d, r11d
00007d3d13bd02f0  mov r10d, [rsp+0x50]
00007d3d13bd02f5  mov r9d, [rsp+0x50]
00007d3d13bd02fa  shrd r10d, r9d, 0x02
00007d3d13bd02ff  mov [rsp+0x50], r11d
00007d3d13bd0304  mov r11d, r11d
00007d3d13bd0307  mov [r15+0x20], r11
00007d3d13bd030b  mov r11, [r15+0x88]
00007d3d13bd0312  mov r8, [r15+0x50]
00007d3d13bd0316  lea rbp, [r8+r11*1]
00007d3d13bd031a  mov r8d, [r13+rbp*1]
00007d3d13bd031f  mov ebp, [rsp+0x20]
00007d3d13bd0323  mov edi, [rsp+0x10]
00007d3d13bd0327  andn esi, edi, ebp
00007d3d13bd032c  mov edx, [r15+0xB0]
00007d3d13bd0333  lea ecx, [r12d+edx*1]
00007d3d13bd0338  rorx r12d, edi, 0x0B
00007d3d13bd033e  xor r14d, r12d
00007d3d13bd0341  rorx r12d, r9d, 0x0D
00007d3d13bd0347  xor r10d, r12d
00007d3d13bd034a  lea r12d, [ecx+esi*1]
00007d3d13bd034f  mov rsi, [r15+0x48]
00007d3d13bd0353  lea rdx, [rsi+r11*1]
00007d3d13bd0357  mov esi, [r13+rdx*1]
00007d3d13bd035c  mov edx, [rsp+0x30]
00007d3d13bd0360  mov ecx, [rsp+0x40]
00007d3d13bd0364  and edx, ecx
00007d3d13bd0366  mov [rsp+0x10], edx
00007d3d13bd036a  mov edx, edx
00007d3d13bd036c  mov [r15+0xD8], rdx
00007d3d13bd0373  lea edx, [r12d+r8d*1]
00007d3d13bd0378  mov r12d, [rsp+0x30]
00007d3d13bd037d  xor r12d, ecx
00007d3d13bd0380  rorx r8d, edi, 0x19
00007d3d13bd0386  xor r14d, r8d
00007d3d13bd0389  and r12d, r9d
00007d3d13bd038c  rorx r8d, r9d, 0x16
00007d3d13bd0392  xor r10d, r8d
00007d3d13bd0395  mov [rsp+0x20], r10d
00007d3d13bd039a  mov r10d, r10d
00007d3d13bd039d  mov [r15+0xD0], r10
00007d3d13bd03a4  lea r10d, [edx+esi*1]
00007d3d13bd03a9  mov r9d, [rsp+0x10]
00007d3d13bd03ae  xor r12d, r9d
00007d3d13bd03b1  lea r9d, [r10d+r14d*1]
00007d3d13bd03b6  lea r14, [r11+0x04]
00007d3d13bd03ba  mov [r15+0x88], r14
00007d3d13bd03c1  mov r11d, [rsp+0x20]
00007d3d13bd03c6  lea r10d, [r12d+r11d*1]
00007d3d13bd03cb  lea r11d, [r9d+eax*1]
00007d3d13bd03d0  mov r11d, r11d
00007d3d13bd03d3  mov [r15+0xB8], r11
00007d3d13bd03da  xor eax, eax
00007d3d13bd03dc  mov r12d, 0x100
00007d3d13bd03e2  cmp r14, r12
00007d3d13bd03e5  cmc
00007d3d13bd03e6  lahf
00007d3d13bd03e7  seto al
00007d3d13bd03ea  mov [r15+0x108], eax
00007d3d13bd03f1  lea eax, [r10d+r9d*1]
00007d3d13bd03f6  mov eax, eax
00007d3d13bd03f8  mov [r15+0xA8], rax
00007d3d13bd03ff  mov ebp, ebp
00007d3d13bd0401  mov [r15+0xB0], rbp
00007d3d13bd0408  mov eax, [rsp+0x50]
00007d3d13bd040c  mov eax, eax
00007d3d13bd040e  mov [r15+0xC0], rax
00007d3d13bd0415  mov edi, edi
00007d3d13bd0417  mov [r15+0xC8], rdi
00007d3d13bd041e  mov eax, [r15+0x108]
00007d3d13bd0425  sahf
00007d3d13bd0426  jnz 0x00007D3D13BD0458
00007d3d13bd0428  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0430  jz 0x00007D3D13BD04A0
00007d3d13bd0436  nop [rax+rax*1], ax
00007d3d13bd043f  nop [rax+rax*1], eax
00007d3d13bd0447  mov eax, 0x41094C
00007d3d13bd044c  mov [r15+0x100], rax
00007d3d13bd0453  jmp 0x00007D3D139FE110
00007d3d13bd0458  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0460  jz 0x00007D3D13BD0270
00007d3d13bd0466  nop [rax+rax*1], ax
00007d3d13bd046f  nop [rax+rax*1], eax
00007d3d13bd0477  mov eax, 0x4108C0
00007d3d13bd047c  mov [r15+0x100], rax
00007d3d13bd0483  jmp 0x00007D3D139FE110
00007d3d13bd0488  int3
00007d3d13bd0489  call 0x00007D3D13A49010
00007d3d13bd048e  jmp 0x00007D3D13BD031F
00007d3d13bd0493  call 0x00007D3D13A25930
00007d3d13bd0498  jmp 0x00007D3D13BD035C
00007d3d13bd049d  int3
00007d3d13bd049e  nop
00007d3d13bd04a0  mov eax, [r15+0x98]
00007d3d13bd04a7  mov r14d, [r15+0x70]
00007d3d13bd04ab  lea r12d, [eax+r14d*1]
00007d3d13bd04b0  mov eax, [r15+0x28]
00007d3d13bd04b4  mov r14d, [r15+0x68]
00007d3d13bd04b8  lea r11d, [eax+r14d*1]
00007d3d13bd04bd  mov qword ptr [r15+0x88], 0x00
00007d3d13bd04c8  mov eax, [r15+0xA8]
00007d3d13bd04cf  mov r14d, [r15+0x78]
00007d3d13bd04d3  lea r10d, [eax+r14d*1]
00007d3d13bd04d8  mov [rsp+0x10], r10d
00007d3d13bd04dd  mov r10d, r10d
00007d3d13bd04e0  mov [r15+0x78], r10
00007d3d13bd04e4  mov eax, [r15+0x38]
00007d3d13bd04e8  mov r14d, [r15+0x80]
00007d3d13bd04ef  lea r10d, [eax+r14d*1]
00007d3d13bd04f4  mov [rsp+0x20], r10d
00007d3d13bd04f9  mov r10d, r10d
00007d3d13bd04fc  mov [r15+0x80], r10
00007d3d13bd0503  mov rax, [r15]
00007d3d13bd0506  lea r14, [rax+0x08]
00007d3d13bd050a  mov [r13+r14*1], r12d
00007d3d13bd050f  lea r14, [rax+0x0C]
00007d3d13bd0513  mov [r13+r14*1], r11d
00007d3d13bd0518  mov r14d, [r15+0xB8]
00007d3d13bd051f  mov r12d, [r15+0x18]
00007d3d13bd0523  lea r11d, [r14d+r12d*1]
00007d3d13bd0528  mov [rsp+0x30], r11d
00007d3d13bd052d  mov r11d, r11d
00007d3d13bd0530  mov [r15+0x68], r11
00007d3d13bd0534  mov r14d, [r15+0x30]
00007d3d13bd0538  mov r12d, [r15+0x90]
00007d3d13bd053f  lea r11d, [r14d+r12d*1]
00007d3d13bd0544  mov [rsp+0x40], r11d
00007d3d13bd0549  mov r11d, r11d
00007d3d13bd054c  mov [r15+0x70], r11
00007d3d13bd0550  mov r14d, [r15+0x20]
00007d3d13bd0554  mov r12d, [r15+0x58]
00007d3d13bd0558  lea r11d, [r14d+r12d*1]
00007d3d13bd055d  mov [rsp+0x50], r11d
00007d3d13bd0562  mov r11d, r11d
00007d3d13bd0565  mov [r15+0x58], r11
00007d3d13bd0569  mov r14d, [r15+0xA0]
00007d3d13bd0570  mov r12d, [r15+0x60]
00007d3d13bd0574  lea r11d, [r14d+r12d*1]
00007d3d13bd0579  mov [rsp+0x60], r11d
00007d3d13bd057e  mov r11d, r11d
00007d3d13bd0581  mov [r15+0x60], r11
00007d3d13bd0585  mov r14d, [rsp+0x10]
00007d3d13bd058a  mov [r13+rax*1], r14d
00007d3d13bd058f  lea r14, [rax+0x04]
00007d3d13bd0593  mov r12d, [rsp+0x20]
00007d3d13bd0598  mov [r13+r14*1], r12d
00007d3d13bd059d  lea r14, [rax+0x10]
00007d3d13bd05a1  mov r12d, [rsp+0x30]
00007d3d13bd05a6  mov [r13+r14*1], r12d
00007d3d13bd05ab  lea r14, [rax+0x14]
00007d3d13bd05af  mov r12d, [rsp+0x40]
00007d3d13bd05b4  mov [r13+r14*1], r12d
00007d3d13bd05b9  lea r14, [rax+0x18]
00007d3d13bd05bd  mov r12d, [rsp+0x50]
00007d3d13bd05c2  mov [r13+r14*1], r12d
00007d3d13bd05c7  lea r14, [rax+0x1C]
00007d3d13bd05cb  mov r12d, [rsp+0x60]
00007d3d13bd05d0  mov [r13+r14*1], r12d
00007d3d13bd05d5  lea r14, [rax+0x68]
00007d3d13bd05d9  xor eax, eax
00007d3d13bd05db  mov [r13+r14*1], rax
00007d3d13bd05e0  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd05e8  jz 0x00007D3D13BCF0E0
00007d3d13bd05ee  nop [rax+rax*1], ax
00007d3d13bd05f7  nop [rax+rax*1], eax
00007d3d13bd05ff  mov eax, 0x410768
00007d3d13bd0604  mov [r15+0x100], rax
00007d3d13bd060b  jmp 0x00007D3D139FE110
00007d3d13bd0610  int3
00007d3d13bd0611  call 0x00007D3D13AE2BA0
00007d3d13bd0616  jmp 0x00007D3D13BD050F
00007d3d13bd061b  call 0x00007D3D13AE1920
00007d3d13bd0620  jmp 0x00007D3D13BD0518
00007d3d13bd0625  call 0x00007D3D13A0DFE0
00007d3d13bd062a  jmp 0x00007D3D13BD058F
00007d3d13bd062f  call 0x00007D3D13AE2BA0
00007d3d13bd0634  jmp 0x00007D3D13BD059D
00007d3d13bd0639  call 0x00007D3D13AE2BA0
00007d3d13bd063e  jmp 0x00007D3D13BD05AB
00007d3d13bd0643  call 0x00007D3D13AE2BA0
00007d3d13bd0648  jmp 0x00007D3D13BD05B9
00007d3d13bd064d  call 0x00007D3D13AE2BA0
00007d3d13bd0652  jmp 0x00007D3D13BD05C7
00007d3d13bd0657  call 0x00007D3D13AE2BA0
00007d3d13bd065c  jmp 0x00007D3D13BD05D5
00007d3d13bd0661  call 0x00007D3D13AD5EB0
00007d3d13bd0666  jmp 0x00007D3D13BD05E0
00007d3d13bd066b  int3
00007d3d13bd066c  nop [rax], eax
00007d3d13bd0670  mov rax, [r15+0xF8]
00007d3d13bd0677  lea r14, [rax+0x140]
00007d3d13bd067e  mov r12, [r13+r14*1]
00007d3d13bd0683  lea r14, [rax+0x148]
00007d3d13bd068a  mov r11, [r13+r14*1]
00007d3d13bd068f  mov [r15+0xA0], r12
00007d3d13bd0696  mov [r15+0x98], r11
00007d3d13bd069d  lea r14, [rax+0x130]
00007d3d13bd06a4  mov r12, [r13+r14*1]
00007d3d13bd06a9  lea r14, [rax+0x138]
00007d3d13bd06b0  mov r11, [r13+r14*1]
00007d3d13bd06b5  mov [r15+0xB0], r12
00007d3d13bd06bc  mov [r15+0xA8], r11
00007d3d13bd06c3  lea r14, [rax+0x120]
00007d3d13bd06ca  mov r12, [r13+r14*1]
00007d3d13bd06cf  lea r14, [rax+0x128]
00007d3d13bd06d6  mov r11, [r13+r14*1]
00007d3d13bd06db  mov [r15+0xC0], r12
00007d3d13bd06e2  mov [r15+0xB8], r11
00007d3d13bd06e9  lea r14, [rax+0x110]
00007d3d13bd06f0  mov r12, [r13+r14*1]
00007d3d13bd06f5  lea r14, [rax+0x118]
00007d3d13bd06fc  mov r11, [r13+r14*1]
00007d3d13bd0701  mov [r15+0xD0], r12
00007d3d13bd0708  mov [r15+0xC8], r11
00007d3d13bd070f  lea r14, [rax+0x100]
00007d3d13bd0716  mov r12, [r13+r14*1]
00007d3d13bd071b  lea r14, [rax+0x108]
00007d3d13bd0722  mov r11, [r13+r14*1]
00007d3d13bd0727  mov [r15+0xE8], r12
00007d3d13bd072e  mov [r15+0xD8], r11
00007d3d13bd0735  lea r14, [rax+0x150]
00007d3d13bd073c  mov [r15+0xF8], r14
00007d3d13bd0743  mov rax, [r15+0xF0]
00007d3d13bd074a  mov [r15+0x100], rax
00007d3d13bd0751  jmp 0x00007D3D13BCE5C0
00007d3d13bd0756  int3
00007d3d13bd0757  call 0x00007D3D13AE27E0
00007d3d13bd075c  jmp 0x00007D3D13BD0683
00007d3d13bd0761  call 0x00007D3D13AE1570
00007d3d13bd0766  jmp 0x00007D3D13BD068F
00007d3d13bd076b  call 0x00007D3D13AE27E0
00007d3d13bd0770  jmp 0x00007D3D13BD06A9
00007d3d13bd0775  call 0x00007D3D13AE1570
00007d3d13bd077a  jmp 0x00007D3D13BD06B5
00007d3d13bd077f  call 0x00007D3D13AE27E0
00007d3d13bd0784  jmp 0x00007D3D13BD06CF
00007d3d13bd0789  call 0x00007D3D13AE1570
00007d3d13bd078e  jmp 0x00007D3D13BD06DB
00007d3d13bd0793  call 0x00007D3D13AE27E0
00007d3d13bd0798  jmp 0x00007D3D13BD06F5
00007d3d13bd079d  call 0x00007D3D13AE1570
00007d3d13bd07a2  jmp 0x00007D3D13BD0701
00007d3d13bd07a7  call 0x00007D3D13AE27E0
00007d3d13bd07ac  jmp 0x00007D3D13BD071B
00007d3d13bd07b1  call 0x00007D3D13AE1570
00007d3d13bd07b6  jmp 0x00007D3D13BD0727
00007d3d13bd07bb  int3
00007d3d13bd07bc  nop [rax], eax
00007d3d13bd07c0  mov eax, [r15+0xA0]
00007d3d13bd07c7  mov [rsp+0x10], eax
00007d3d13bd07cb  xor eax, eax
00007d3d13bd07cd  mov r14d, [rsp+0x10]
00007d3d13bd07d2  sub r14d, 0x01
00007d3d13bd07d6  cmc
00007d3d13bd07d7  lahf
00007d3d13bd07d8  seto al
00007d3d13bd07db  mov [r15+0x108], eax
00007d3d13bd07e2  mov r14d, r14d
00007d3d13bd07e5  mov [r15+0xA0], r14
00007d3d13bd07ec  mov eax, [r15+0x108]
00007d3d13bd07f3  sahf
00007d3d13bd07f4  jnz 0x00007D3D13BD0826
00007d3d13bd07f6  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd07fe  jz 0x00007D3D13BD0900
00007d3d13bd0804  nop [rax+rax*1], ax
00007d3d13bd080d  nop [rax+rax*1], eax
00007d3d13bd0815  mov eax, 0x41028C
00007d3d13bd081a  mov [r15+0x100], rax
00007d3d13bd0821  jmp 0x00007D3D139FE110
00007d3d13bd0826  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd082e  jz 0x00007D3D13BD0860
00007d3d13bd0834  nop [rax+rax*1], ax
00007d3d13bd083d  nop [rax+rax*1], eax
00007d3d13bd0845  mov eax, 0x410274
00007d3d13bd084a  mov [r15+0x100], rax
00007d3d13bd0851  jmp 0x00007D3D139FE110
00007d3d13bd0856  int3
00007d3d13bd0857  int3
00007d3d13bd0858  nop [rax+rax*1], eax
00007d3d13bd0860  mov rax, [r15+0xF8]
00007d3d13bd0867  lea r14, [rax+0x100]
00007d3d13bd086e  mov [r15], r14
00007d3d13bd0871  mov rax, [r15+0x98]
00007d3d13bd0878  mov [r15+0x08], rax
00007d3d13bd087c  mov qword ptr [r15+0x10], 0x12C
00007d3d13bd0884  mov qword ptr [r15+0xF0], 0x410284
00007d3d13bd088f  mov r14d, [r15+0x320]
00007d3d13bd0896  mov eax, 0x410284
00007d3d13bd089b  mov rcx, 0x7D3D13BD07C0
00007d3d13bd08a5  mov [r15+r14*8+0x328], rax
00007d3d13bd08ad  mov [r15+r14*8+0x368], rcx
00007d3d13bd08b5  add r14d, 0x01
00007d3d13bd08b9  and r14d, 0x07
00007d3d13bd08bd  mov [r15+0x320], r14d
00007d3d13bd08c4  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd08cc  jz 0x00007D3D13BCED70
00007d3d13bd08d2  nop [rax+rax*1], ax
00007d3d13bd08db  nop [rax+rax*1], eax
00007d3d13bd08e3  mov eax, 0x410728
00007d3d13bd08e8  mov [r15+0x100], rax
00007d3d13bd08ef  jmp 0x00007D3D139FE110
00007d3d13bd08f4  int3
00007d3d13bd08f5  int3
00007d3d13bd08f6  nop [rax+rax*1], ax
00007d3d13bd08ff  nop
00007d3d13bd0900  mov rax, [r15+0xF8]
00007d3d13bd0907  lea r14, [rax+0x120]
00007d3d13bd090e  mov r12, [r13+r14*1]
00007d3d13bd0913  mov [r15+0x98], r12
00007d3d13bd091a  mov qword ptr [r15+0x40], 0x80
00007d3d13bd0922  lea r14, [rax+0x100]
00007d3d13bd0929  mov [r15], r14
00007d3d13bd092c  lea r14, [rax+0x17C]
00007d3d13bd0933  mov [r15+0x08], r14
00007d3d13bd0937  mov qword ptr [r15+0x10], 0x01
00007d3d13bd093f  lea r14, [rax+0x17C]
00007d3d13bd0946  mov eax, 0x80
00007d3d13bd094b  mov [r13+r14*1], al
00007d3d13bd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007d3d13bd095b  mov r14d, [r15+0x320]
00007d3d13bd0962  mov eax, 0x4102A8
00007d3d13bd0967  mov rcx, 0x7D3D13BD09E0
00007d3d13bd0971  mov [r15+r14*8+0x328], rax
00007d3d13bd0979  mov [r15+r14*8+0x368], rcx
00007d3d13bd0981  add r14d, 0x01
00007d3d13bd0985  and r14d, 0x07
00007d3d13bd0989  mov [r15+0x320], r14d
00007d3d13bd0990  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0998  jz 0x00007D3D13BCED70
00007d3d13bd099e  nop [rax+rax*1], ax
00007d3d13bd09a7  nop [rax+rax*1], eax
00007d3d13bd09af  mov eax, 0x410728
00007d3d13bd09b4  mov [r15+0x100], rax
00007d3d13bd09bb  jmp 0x00007D3D139FE110
00007d3d13bd09c0  int3
00007d3d13bd09c1  call 0x00007D3D13AE27E0
00007d3d13bd09c6  jmp 0x00007D3D13BD0913
00007d3d13bd09cb  call 0x00007D3D13AD5AF0
00007d3d13bd09d0  jmp 0x00007D3D13BD0950
00007d3d13bd09d5  int3
00007d3d13bd09d6  nop [rax+rax*1], ax
00007d3d13bd09df  nop
00007d3d13bd09e0  mov rax, [r15+0xF8]
00007d3d13bd09e7  lea r14, [rax+0x168]
00007d3d13bd09ee  mov r12, [r13+r14*1]
00007d3d13bd09f3  mov [r15+0x40], r12
00007d3d13bd09f7  lea r14, [rax+0x178]
00007d3d13bd09fe  xor eax, eax
00007d3d13bd0a00  mov [r13+r14*1], al
00007d3d13bd0a05  xor eax, eax
00007d3d13bd0a07  mov r14d, 0x38
00007d3d13bd0a0d  cmp r12, r14
00007d3d13bd0a10  cmc
00007d3d13bd0a11  lahf
00007d3d13bd0a12  seto al
00007d3d13bd0a15  mov [r15+0x108], eax
00007d3d13bd0a1c  mov eax, [r15+0x108]
00007d3d13bd0a23  sahf
00007d3d13bd0a24  jz 0x00007D3D13BD0A56
00007d3d13bd0a26  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0a2e  jz 0x00007D3D13BD0AA0
00007d3d13bd0a34  nop [rax+rax*1], ax
00007d3d13bd0a3d  nop [rax+rax*1], eax
00007d3d13bd0a45  mov eax, 0x4102B8
00007d3d13bd0a4a  mov [r15+0x100], rax
00007d3d13bd0a51  jmp 0x00007D3D139FE110
00007d3d13bd0a56  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0a5e  jz 0x00007D3D13BD0BF0
00007d3d13bd0a64  nop [rax+rax*1], ax
00007d3d13bd0a6d  nop [rax+rax*1], eax
00007d3d13bd0a75  mov eax, 0x4102D4
00007d3d13bd0a7a  mov [r15+0x100], rax
00007d3d13bd0a81  jmp 0x00007D3D139FE110
00007d3d13bd0a86  int3
00007d3d13bd0a87  call 0x00007D3D13AE27E0
00007d3d13bd0a8c  jmp 0x00007D3D13BD09F3
00007d3d13bd0a91  call 0x00007D3D13AD5AF0
00007d3d13bd0a96  jmp 0x00007D3D13BD0A05
00007d3d13bd0a9b  int3
00007d3d13bd0a9c  nop [rax], eax
00007d3d13bd0aa0  mov rax, [r15+0xF8]
00007d3d13bd0aa7  lea r14, [rax+0x100]
00007d3d13bd0aae  mov [r15], r14
00007d3d13bd0ab1  lea r14, [rax+0x178]
00007d3d13bd0ab8  mov [r15+0x08], r14
00007d3d13bd0abc  mov qword ptr [r15+0x10], 0x01
00007d3d13bd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007d3d13bd0acf  mov r14d, [r15+0x320]
00007d3d13bd0ad6  mov eax, 0x4102C8
00007d3d13bd0adb  mov rcx, 0x7D3D13BD0B40
00007d3d13bd0ae5  mov [r15+r14*8+0x328], rax
00007d3d13bd0aed  mov [r15+r14*8+0x368], rcx
00007d3d13bd0af5  add r14d, 0x01
00007d3d13bd0af9  and r14d, 0x07
00007d3d13bd0afd  mov [r15+0x320], r14d
00007d3d13bd0b04  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0b0c  jz 0x00007D3D13BCED70
00007d3d13bd0b12  nop [rax+rax*1], ax
00007d3d13bd0b1b  nop [rax+rax*1], eax
00007d3d13bd0b23  mov eax, 0x410728
00007d3d13bd0b28  mov [r15+0x100], rax
00007d3d13bd0b2f  jmp 0x00007D3D139FE110
00007d3d13bd0b34  int3
00007d3d13bd0b35  int3
00007d3d13bd0b36  nop [rax+rax*1], ax
00007d3d13bd0b3f  nop
00007d3d13bd0b40  mov rax, [r15+0xF8]
00007d3d13bd0b47  lea r14, [rax+0x168]
00007d3d13bd0b4e  mov rax, [r13+r14*1]
00007d3d13bd0b53  mov [r15+0x40], rax
00007d3d13bd0b57  mov [rsp+0x10], rax
00007d3d13bd0b5c  xor eax, eax
00007d3d13bd0b5e  mov r14, [rsp+0x10]
00007d3d13bd0b63  mov r12d, 0x38
00007d3d13bd0b69  cmp r14, r12
00007d3d13bd0b6c  cmc
00007d3d13bd0b6d  lahf
00007d3d13bd0b6e  seto al
00007d3d13bd0b71  mov [r15+0x108], eax
00007d3d13bd0b78  mov eax, [r15+0x108]
00007d3d13bd0b7f  sahf
00007d3d13bd0b80  jnz 0x00007D3D13BD0BB2
00007d3d13bd0b82  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0b8a  jz 0x00007D3D13BD0BF0
00007d3d13bd0b90  nop [rax+rax*1], ax
00007d3d13bd0b99  nop [rax+rax*1], eax
00007d3d13bd0ba1  mov eax, 0x4102D4
00007d3d13bd0ba6  mov [r15+0x100], rax
00007d3d13bd0bad  jmp 0x00007D3D139FE110
00007d3d13bd0bb2  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0bba  jz 0x00007D3D13BD0AA0
00007d3d13bd0bc0  nop [rax+rax*1], ax
00007d3d13bd0bc9  nop [rax+rax*1], eax
00007d3d13bd0bd1  mov eax, 0x4102B8
00007d3d13bd0bd6  mov [r15+0x100], rax
00007d3d13bd0bdd  jmp 0x00007D3D139FE110
00007d3d13bd0be2  int3
00007d3d13bd0be3  call 0x00007D3D13AD59C0
00007d3d13bd0be8  jmp 0x00007D3D13BD0B53
00007d3d13bd0bed  int3
00007d3d13bd0bee  nop
00007d3d13bd0bf0  mov rax, [r15+0x98]
00007d3d13bd0bf7  rorx r14, rax, 0x3D
00007d3d13bd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007d3d13bd0c01  mov rax, [r15+0xF8]
00007d3d13bd0c08  lea r12, [rax+0x100]
00007d3d13bd0c0f  mov [r15], r12
00007d3d13bd0c12  lea r12, [rax+0x170]
00007d3d13bd0c19  mov [r15+0x08], r12
00007d3d13bd0c1d  mov qword ptr [r15+0x10], 0x08
00007d3d13bd0c25  bswap r14
00007d3d13bd0c28  mov [r15+0x40], r14
00007d3d13bd0c2c  lea r12, [rax+0x170]
00007d3d13bd0c33  mov [r13+r12*1], r14
00007d3d13bd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007d3d13bd0c43  mov r14d, [r15+0x320]
00007d3d13bd0c4a  mov eax, 0x4102F0
00007d3d13bd0c4f  mov rcx, 0x7D3D13BD0CC0
00007d3d13bd0c59  mov [r15+r14*8+0x328], rax
00007d3d13bd0c61  mov [r15+r14*8+0x368], rcx
00007d3d13bd0c69  add r14d, 0x01
00007d3d13bd0c6d  and r14d, 0x07
00007d3d13bd0c71  mov [r15+0x320], r14d
00007d3d13bd0c78  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0c80  jz 0x00007D3D13BCED70
00007d3d13bd0c86  nop [rax+rax*1], ax
00007d3d13bd0c8f  nop [rax+rax*1], eax
00007d3d13bd0c97  mov eax, 0x410728
00007d3d13bd0c9c  mov [r15+0x100], rax
00007d3d13bd0ca3  jmp 0x00007D3D139FE110
00007d3d13bd0ca8  int3
00007d3d13bd0ca9  call 0x00007D3D13AC3FE0
00007d3d13bd0cae  jmp 0x00007D3D13BD0C38
00007d3d13bd0cb3  int3
00007d3d13bd0cb4  nop [rax+rax*1], ax
00007d3d13bd0cbd  nop [rax], eax
00007d3d13bd0cc0  mov rax, [r15+0xF8]
00007d3d13bd0cc7  lea r14, [rax+0x100]
00007d3d13bd0cce  mov r12d, [r13+r14*1]
00007d3d13bd0cd3  lea r14, [rax+0x104]
00007d3d13bd0cda  mov r11d, [r13+r14*1]
00007d3d13bd0cdf  mov qword ptr [r15+0x48], 0x430C90
00007d3d13bd0ce7  lea r14, [rax+0x108]
00007d3d13bd0cee  mov r10d, [r13+r14*1]
00007d3d13bd0cf3  lea r14, [rax+0x10C]
00007d3d13bd0cfa  mov r9d, [r13+r14*1]
00007d3d13bd0cff  bswap r12d
00007d3d13bd0d02  bswap r11d
00007d3d13bd0d05  mov qword ptr [r15+0xA0], 0x00
00007d3d13bd0d10  mov r14d, 0x430C90
00007d3d13bd0d16  mov [r13+r14*1], r12d
00007d3d13bd0d1b  mov r14d, 0x430C94
00007d3d13bd0d21  mov [r13+r14*1], r11d
00007d3d13bd0d26  bswap r10d
00007d3d13bd0d29  lea r14, [rax+0x110]
00007d3d13bd0d30  mov r12d, [r13+r14*1]
00007d3d13bd0d35  bswap r9d
00007d3d13bd0d38  lea r14, [rax+0x114]
00007d3d13bd0d3f  mov r11d, [r13+r14*1]
00007d3d13bd0d44  mov qword ptr [r15+0x98], 0x430DFC
00007d3d13bd0d4f  mov r14d, 0x430C98
00007d3d13bd0d55  mov [r13+r14*1], r10d
00007d3d13bd0d5a  mov r14d, 0x430C9C
00007d3d13bd0d60  mov [r13+r14*1], r9d
00007d3d13bd0d65  bswap r12d
00007d3d13bd0d68  lea r14, [rax+0x118]
00007d3d13bd0d6f  mov r10d, [r13+r14*1]
00007d3d13bd0d74  bswap r11d
00007d3d13bd0d77  mov [rsp+0x10], r11d
00007d3d13bd0d7c  mov r11d, r11d
00007d3d13bd0d7f  mov [r15+0x58], r11
00007d3d13bd0d83  lea r14, [rax+0x11C]
00007d3d13bd0d8a  mov eax, [r13+r14*1]
00007d3d13bd0d8f  mov [rsp+0x20], eax
00007d3d13bd0d93  mov eax, eax
00007d3d13bd0d95  mov [r15+0x60], rax
00007d3d13bd0d99  mov eax, 0x430CA0
00007d3d13bd0d9e  mov [r13+rax*1], r12d
00007d3d13bd0da3  mov eax, 0x430CA4
00007d3d13bd0da8  mov r14d, [rsp+0x10]
00007d3d13bd0dad  mov [r13+rax*1], r14d
00007d3d13bd0db2  bswap r10d
00007d3d13bd0db5  mov [rsp+0x10], r10d
00007d3d13bd0dba  mov r10d, r10d
00007d3d13bd0dbd  mov [r15+0x40], r10
00007d3d13bd0dc1  mov eax, [rsp+0x20]
00007d3d13bd0dc5  bswap eax
00007d3d13bd0dc7  mov [rsp+0x20], eax
00007d3d13bd0dcb  mov eax, eax
00007d3d13bd0dcd  mov [r15+0x50], rax
00007d3d13bd0dd1  mov eax, 0x430CA8
00007d3d13bd0dd6  mov r14d, [rsp+0x10]
00007d3d13bd0ddb  mov [r13+rax*1], r14d
00007d3d13bd0de0  mov eax, 0x430CAC
00007d3d13bd0de5  mov r14d, [rsp+0x20]
00007d3d13bd0dea  mov [r13+rax*1], r14d
00007d3d13bd0def  mov eax, [r15+0xA0]
00007d3d13bd0df6  lea r14d, [eax+0x11]
00007d3d13bd0dfb  mov r14d, r14d
00007d3d13bd0dfe  mov [r15], r14
00007d3d13bd0e01  mov qword ptr [r15+0xF0], 0x41035C
00007d3d13bd0e0c  mov r14d, [r15+0x320]
00007d3d13bd0e13  mov eax, 0x41035C
00007d3d13bd0e18  mov rcx, 0x7D3D13BD0F90
00007d3d13bd0e22  mov [r15+r14*8+0x328], rax
00007d3d13bd0e2a  mov [r15+r14*8+0x368], rcx
00007d3d13bd0e32  add r14d, 0x01
00007d3d13bd0e36  and r14d, 0x07
00007d3d13bd0e3a  mov [r15+0x320], r14d
00007d3d13bd0e41  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0e49  jz 0x00007D3D13BD0F20
00007d3d13bd0e4f  nop [rax+rax*1], ax
00007d3d13bd0e58  nop [rax+rax*1], eax
00007d3d13bd0e60  mov eax, 0x4109A4
00007d3d13bd0e65  mov [r15+0x100], rax
00007d3d13bd0e6c  jmp 0x00007D3D139FE110
00007d3d13bd0e71  int3
00007d3d13bd0e72  call 0x00007D3D13AE26A0
00007d3d13bd0e77  jmp 0x00007D3D13BD0CD3
00007d3d13bd0e7c  call 0x00007D3D13AE1430
00007d3d13bd0e81  jmp 0x00007D3D13BD0CDF
00007d3d13bd0e86  call 0x00007D3D13AE01C0
00007d3d13bd0e8b  jmp 0x00007D3D13BD0CF3
00007d3d13bd0e90  call 0x00007D3D13ADEF50
00007d3d13bd0e95  jmp 0x00007D3D13BD0CFF
00007d3d13bd0e9a  call 0x00007D3D13AE2BA0
00007d3d13bd0e9f  jmp 0x00007D3D13BD0D1B
00007d3d13bd0ea4  call 0x00007D3D13AE1920
00007d3d13bd0ea9  jmp 0x00007D3D13BD0D26
00007d3d13bd0eae  call 0x00007D3D13AE26A0
00007d3d13bd0eb3  jmp 0x00007D3D13BD0D35
00007d3d13bd0eb8  call 0x00007D3D13AE1430
00007d3d13bd0ebd  jmp 0x00007D3D13BD0D44
00007d3d13bd0ec2  call 0x00007D3D13AE06B0
00007d3d13bd0ec7  jmp 0x00007D3D13BD0D5A
00007d3d13bd0ecc  call 0x00007D3D13ADF440
00007d3d13bd0ed1  jmp 0x00007D3D13BD0D65
00007d3d13bd0ed6  call 0x00007D3D13AE01C0
00007d3d13bd0edb  jmp 0x00007D3D13BD0D74
00007d3d13bd0ee0  call 0x00007D3D13AD5890
00007d3d13bd0ee5  jmp 0x00007D3D13BD0D8F
00007d3d13bd0eea  call 0x00007D3D13A0BAE0
00007d3d13bd0eef  jmp 0x00007D3D13BD0DA3
00007d3d13bd0ef4  call 0x00007D3D13A0DFE0
00007d3d13bd0ef9  jmp 0x00007D3D13BD0DB2
00007d3d13bd0efe  call 0x00007D3D13A0DFE0
00007d3d13bd0f03  jmp 0x00007D3D13BD0DE0
00007d3d13bd0f08  call 0x00007D3D13A0DFE0
00007d3d13bd0f0d  jmp 0x00007D3D13BD0DEF
00007d3d13bd0f12  int3
00007d3d13bd0f13  nop [rax+rax*1], ax
00007d3d13bd0f1c  nop [rax], eax
00007d3d13bd0f20  mov eax, [r15]
00007d3d13bd0f23  mov [rsp+0x10], eax
00007d3d13bd0f27  shr eax, 0x10
00007d3d13bd0f2a  mov r14d, [rsp+0x10]
00007d3d13bd0f2f  xor r14d, eax
00007d3d13bd0f32  imul r14d, r14d, 0x7FEB352D
00007d3d13bd0f39  mov eax, 0x846CA68B
00007d3d13bd0f3e  mov eax, eax
00007d3d13bd0f40  mov [r15+0x48], rax
00007d3d13bd0f44  mov [rsp+0x10], r14d
00007d3d13bd0f49  shr r14d, 0x0F
00007d3d13bd0f4d  mov eax, [rsp+0x10]
00007d3d13bd0f51  xor eax, r14d
00007d3d13bd0f54  imul eax, eax, 0x846CA68B
00007d3d13bd0f5a  mov [rsp+0x10], eax
00007d3d13bd0f5e  mov eax, eax
00007d3d13bd0f60  mov [r15+0x40], rax
00007d3d13bd0f64  mov eax, [rsp+0x10]
00007d3d13bd0f68  shr eax, 0x10
00007d3d13bd0f6b  mov r14d, [rsp+0x10]
00007d3d13bd0f70  xor r14d, eax
00007d3d13bd0f73  mov r14d, r14d
00007d3d13bd0f76  mov [r15], r14
00007d3d13bd0f79  mov rax, [r15+0xF0]
00007d3d13bd0f80  mov [r15+0x100], rax
00007d3d13bd0f87  jmp 0x00007D3D13BCE5C0
00007d3d13bd0f8c  int3
00007d3d13bd0f8d  int3
00007d3d13bd0f8e  nop
00007d3d13bd0f90  mov rax, [r15+0xA0]
00007d3d13bd0f97  mov [rsp+0x10], rax
00007d3d13bd0f9c  shl rax, 0x02
00007d3d13bd0fa0  mov r14, [r15+0x98]
00007d3d13bd0fa7  lea r12, [r14+rax*1]
00007d3d13bd0fab  mov eax, [r15]
00007d3d13bd0fae  mov [r13+r12*1], eax
00007d3d13bd0fb3  mov rax, [rsp+0x10]
00007d3d13bd0fb8  lea r14, [rax+0x01]
00007d3d13bd0fbc  mov [r15+0xA0], r14
00007d3d13bd0fc3  xor eax, eax
00007d3d13bd0fc5  mov r12d, 0x400
00007d3d13bd0fcb  cmp r14, r12
00007d3d13bd0fce  cmc
00007d3d13bd0fcf  lahf
00007d3d13bd0fd0  seto al
00007d3d13bd0fd3  mov [r15+0x108], eax
00007d3d13bd0fda  mov eax, [r15+0x108]
00007d3d13bd0fe1  sahf
00007d3d13bd0fe2  jnz 0x00007D3D13BD1014
00007d3d13bd0fe4  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd0fec  jz 0x00007D3D13BD10E0
00007d3d13bd0ff2  nop [rax+rax*1], ax
00007d3d13bd0ffb  nop [rax+rax*1], eax
00007d3d13bd1003  mov eax, 0x41036C
00007d3d13bd1008  mov [r15+0x100], rax
00007d3d13bd100f  jmp 0x00007D3D139FE110
00007d3d13bd1014  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd101c  jz 0x00007D3D13BD1050
00007d3d13bd1022  nop [rax+rax*1], ax
00007d3d13bd102b  nop [rax+rax*1], eax
00007d3d13bd1033  mov eax, 0x410354
00007d3d13bd1038  mov [r15+0x100], rax
00007d3d13bd103f  jmp 0x00007D3D139FE110
00007d3d13bd1044  int3
00007d3d13bd1045  call 0x00007D3D13AB4B70
00007d3d13bd104a  jmp 0x00007D3D13BD0FB3
00007d3d13bd104f  int3
00007d3d13bd1050  mov eax, [r15+0xA0]
00007d3d13bd1057  lea r14d, [eax+0x11]
00007d3d13bd105c  mov r14d, r14d
00007d3d13bd105f  mov [r15], r14
00007d3d13bd1062  mov qword ptr [r15+0xF0], 0x41035C
00007d3d13bd106d  mov r14d, [r15+0x320]
00007d3d13bd1074  mov eax, 0x41035C
00007d3d13bd1079  mov rcx, 0x7D3D13BD0F90
00007d3d13bd1083  mov [r15+r14*8+0x328], rax
00007d3d13bd108b  mov [r15+r14*8+0x368], rcx
00007d3d13bd1093  add r14d, 0x01
00007d3d13bd1097  and r14d, 0x07
00007d3d13bd109b  mov [r15+0x320], r14d
00007d3d13bd10a2  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd10aa  jz 0x00007D3D13BD0F20
00007d3d13bd10b0  nop [rax+rax*1], ax
00007d3d13bd10b9  nop [rax+rax*1], eax
00007d3d13bd10c1  mov eax, 0x4109A4
00007d3d13bd10c6  mov [r15+0x100], rax
00007d3d13bd10cd  jmp 0x00007D3D139FE110
00007d3d13bd10d2  int3
00007d3d13bd10d3  int3
00007d3d13bd10d4  nop [rax+rax*1], ax
00007d3d13bd10dd  nop [rax], eax
00007d3d13bd10e0  mov qword ptr [r15+0x40], 0x01
00007d3d13bd10e8  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd10f0  jz 0x00007D3D13BD1120
00007d3d13bd10f6  nop [rax+rax*1], ax
00007d3d13bd10ff  nop [rax+rax*1], eax
00007d3d13bd1107  mov eax, 0x410388
00007d3d13bd110c  mov [r15+0x100], rax
00007d3d13bd1113  jmp 0x00007D3D139FE110
00007d3d13bd1118  int3
00007d3d13bd1119  int3
00007d3d13bd111a  nop [rax+rax*1], ax
00007d3d13bd1120  mov rax, [r15+0x40]
00007d3d13bd1124  mov [rsp+0x10], rax
00007d3d13bd1129  shl rax, 0x02
00007d3d13bd112d  mov r14, [r15+0x98]
00007d3d13bd1134  lea r12, [r14+rax*1]
00007d3d13bd1138  mov eax, [r13+r12*1]
00007d3d13bd113d  mov [rsp+0x20], eax
00007d3d13bd1141  mov eax, eax
00007d3d13bd1143  mov [r15+0x48], rax
00007d3d13bd1147  mov rax, [rsp+0x10]
00007d3d13bd114c  mov [r15+0x50], rax
00007d3d13bd1150  mov eax, [r15+0x50]
00007d3d13bd1154  lea r12d, [eax-0x01]
00007d3d13bd1159  mov r12d, r12d
00007d3d13bd115c  mov [r15+0x58], r12
00007d3d13bd1160  mov rax, [r15+0x58]
00007d3d13bd1164  mov r12d, eax
00007d3d13bd1167  mov r12d, r12d
00007d3d13bd116a  shl r12, 0x02
00007d3d13bd116e  lea rax, [r14+r12*1]
00007d3d13bd1172  mov r14d, [r13+rax*1]
00007d3d13bd1177  mov [rsp+0x10], r14d
00007d3d13bd117c  mov r14d, r14d
00007d3d13bd117f  mov [r15+0x60], r14
00007d3d13bd1183  xor eax, eax
00007d3d13bd1185  mov r14d, [rsp+0x10]
00007d3d13bd118a  mov r12d, [rsp+0x20]
00007d3d13bd118f  cmp r14d, r12d
00007d3d13bd1192  cmc
00007d3d13bd1193  lahf
00007d3d13bd1194  seto al
00007d3d13bd1197  mov [r15+0x108], eax
00007d3d13bd119e  mov eax, [r15+0x108]
00007d3d13bd11a5  sahf
00007d3d13bd11a6  cmc
00007d3d13bd11a7  jbe 0x00007D3D13BD11D9
00007d3d13bd11a9  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd11b1  jz 0x00007D3D13BD1220
00007d3d13bd11b7  nop [rax+rax*1], ax
00007d3d13bd11c0  nop [rax+rax*1], eax
00007d3d13bd11c8  mov eax, 0x4103A0
00007d3d13bd11cd  mov [r15+0x100], rax
00007d3d13bd11d4  jmp 0x00007D3D139FE110
00007d3d13bd11d9  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd11e1  jz 0x00007D3D13BD14C0
00007d3d13bd11e7  nop [rax+rax*1], ax
00007d3d13bd11f0  nop [rax+rax*1], eax
00007d3d13bd11f8  mov eax, 0x410378
00007d3d13bd11fd  mov [r15+0x100], rax
00007d3d13bd1204  jmp 0x00007D3D139FE110
00007d3d13bd1209  int3
00007d3d13bd120a  call 0x00007D3D13AB4690
00007d3d13bd120f  jmp 0x00007D3D13BD113D
00007d3d13bd1214  call 0x00007D3D13A0DAE0
00007d3d13bd1219  jmp 0x00007D3D13BD1177
00007d3d13bd121e  int3
00007d3d13bd121f  nop
00007d3d13bd1220  mov rax, [r15+0x50]
00007d3d13bd1224  mov [rsp+0x10], rax
00007d3d13bd1229  shl rax, 0x02
00007d3d13bd122d  mov r14, [r15+0x98]
00007d3d13bd1234  lea r12, [r14+rax*1]
00007d3d13bd1238  mov eax, [r15+0x60]
00007d3d13bd123c  mov [r13+r12*1], eax
00007d3d13bd1241  mov rax, [rsp+0x10]
00007d3d13bd1246  lea r14, [rax-0x01]
00007d3d13bd124a  mov [r15+0x50], r14
00007d3d13bd124e  mov rax, [r15+0x58]
00007d3d13bd1252  test rax, rax
00007d3d13bd1255  setz al
00007d3d13bd1258  movzx rax, al
00007d3d13bd125c  mov [rsp+0x414], al
00007d3d13bd1263  cmp byte ptr [rsp+0x414], 0x00
00007d3d13bd126b  jz 0x00007D3D13BD129D
00007d3d13bd126d  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd1275  jz 0x00007D3D13BD12E0
00007d3d13bd127b  nop [rax+rax*1], ax
00007d3d13bd1284  nop [rax+rax*1], eax
00007d3d13bd128c  mov eax, 0x4103AC
00007d3d13bd1291  mov [r15+0x100], rax
00007d3d13bd1298  jmp 0x00007D3D139FE110
00007d3d13bd129d  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd12a5  jz 0x00007D3D13BD13E0
00007d3d13bd12ab  nop [rax+rax*1], ax
00007d3d13bd12b4  nop [rax+rax*1], eax
00007d3d13bd12bc  mov eax, 0x410390
00007d3d13bd12c1  mov [r15+0x100], rax
00007d3d13bd12c8  jmp 0x00007D3D139FE110
00007d3d13bd12cd  int3
00007d3d13bd12ce  call 0x00007D3D13AB4B70
00007d3d13bd12d3  jmp 0x00007D3D13BD1241
00007d3d13bd12d8  int3
00007d3d13bd12d9  nop [rax], eax
00007d3d13bd12e0  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd12e8  jz 0x00007D3D13BD1320
00007d3d13bd12ee  nop [rax+rax*1], ax
00007d3d13bd12f7  nop [rax+rax*1], eax
00007d3d13bd12ff  mov eax, 0x410374
00007d3d13bd1304  mov [r15+0x100], rax
00007d3d13bd130b  jmp 0x00007D3D139FE110
00007d3d13bd1310  int3
00007d3d13bd1311  int3
00007d3d13bd1312  nop [rax+rax*1], ax
00007d3d13bd131b  nop [rax+rax*1], eax
00007d3d13bd1320  mov qword ptr [r15+0x50], 0x00
00007d3d13bd1328  mov rax, [r15+0x40]
00007d3d13bd132c  lea r14, [rax+0x01]
00007d3d13bd1330  mov [r15+0x40], r14
00007d3d13bd1334  mov rax, [r15+0x98]
00007d3d13bd133b  mov r12d, [r15+0x48]
00007d3d13bd133f  mov [r13+rax*1], r12d
00007d3d13bd1344  xor eax, eax
00007d3d13bd1346  mov r12d, 0x400
00007d3d13bd134c  cmp r14, r12
00007d3d13bd134f  cmc
00007d3d13bd1350  lahf
00007d3d13bd1351  seto al
00007d3d13bd1354  mov [r15+0x108], eax
00007d3d13bd135b  mov eax, [r15+0x108]
00007d3d13bd1362  sahf
00007d3d13bd1363  jz 0x00007D3D13BD1395
00007d3d13bd1365  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd136d  jz 0x00007D3D13BD1120
00007d3d13bd1373  nop [rax+rax*1], ax
00007d3d13bd137c  nop [rax+rax*1], eax
00007d3d13bd1384  mov eax, 0x410388
00007d3d13bd1389  mov [r15+0x100], rax
00007d3d13bd1390  jmp 0x00007D3D139FE110
00007d3d13bd1395  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd139d  jz 0x00007D3D13BD1580
00007d3d13bd13a3  nop [rax+rax*1], ax
00007d3d13bd13ac  nop [rax+rax*1], eax
00007d3d13bd13b4  mov eax, 0x4103B0
00007d3d13bd13b9  mov [r15+0x100], rax
00007d3d13bd13c0  jmp 0x00007D3D139FE110
00007d3d13bd13c5  int3
00007d3d13bd13c6  call 0x00007D3D13A0BAE0
00007d3d13bd13cb  jmp 0x00007D3D13BD1344
00007d3d13bd13d0  int3
00007d3d13bd13d1  nop [rax+rax*1], ax
00007d3d13bd13da  nop [rax+rax*1], ax
00007d3d13bd13e0  mov eax, [r15+0x50]
00007d3d13bd13e4  lea r14d, [eax-0x01]
00007d3d13bd13e9  mov r14d, r14d
00007d3d13bd13ec  mov [r15+0x58], r14
00007d3d13bd13f0  mov rax, [r15+0x58]
00007d3d13bd13f4  mov r14d, eax
00007d3d13bd13f7  mov r14d, r14d
00007d3d13bd13fa  shl r14, 0x02
00007d3d13bd13fe  mov rax, [r15+0x98]
00007d3d13bd1405  lea r12, [rax+r14*1]
00007d3d13bd1409  mov eax, [r13+r12*1]
00007d3d13bd140e  mov [rsp+0x10], eax
00007d3d13bd1412  mov eax, eax
00007d3d13bd1414  mov [r15+0x60], rax
00007d3d13bd1418  mov eax, [r15+0x48]
00007d3d13bd141c  mov [rsp+0x20], eax
00007d3d13bd1420  xor eax, eax
00007d3d13bd1422  mov r14d, [rsp+0x10]
00007d3d13bd1427  mov r12d, [rsp+0x20]
00007d3d13bd142c  cmp r14d, r12d
00007d3d13bd142f  cmc
00007d3d13bd1430  lahf
00007d3d13bd1431  seto al
00007d3d13bd1434  mov [r15+0x108], eax
00007d3d13bd143b  mov eax, [r15+0x108]
00007d3d13bd1442  sahf
00007d3d13bd1443  cmc
00007d3d13bd1444  jbe 0x00007D3D13BD1476
00007d3d13bd1446  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd144e  jz 0x00007D3D13BD1220
00007d3d13bd1454  nop [rax+rax*1], ax
00007d3d13bd145d  nop [rax+rax*1], eax
00007d3d13bd1465  mov eax, 0x4103A0
00007d3d13bd146a  mov [r15+0x100], rax
00007d3d13bd1471  jmp 0x00007D3D139FE110
00007d3d13bd1476  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd147e  jz 0x00007D3D13BD14C0
00007d3d13bd1484  nop [rax+rax*1], ax
00007d3d13bd148d  nop [rax+rax*1], eax
00007d3d13bd1495  mov eax, 0x410378
00007d3d13bd149a  mov [r15+0x100], rax
00007d3d13bd14a1  jmp 0x00007D3D139FE110
00007d3d13bd14a6  int3
00007d3d13bd14a7  call 0x00007D3D13AB4690
00007d3d13bd14ac  jmp 0x00007D3D13BD140E
00007d3d13bd14b1  int3
00007d3d13bd14b2  nop [rax+rax*1], ax
00007d3d13bd14bb  nop [rax+rax*1], eax
00007d3d13bd14c0  mov rax, [r15+0x40]
00007d3d13bd14c4  lea r14, [rax+0x01]
00007d3d13bd14c8  mov [r15+0x40], r14
00007d3d13bd14cc  mov rax, [r15+0x50]
00007d3d13bd14d0  mov r12d, eax
00007d3d13bd14d3  mov r12d, r12d
00007d3d13bd14d6  shl r12, 0x02
00007d3d13bd14da  mov rax, [r15+0x98]
00007d3d13bd14e1  lea r11, [rax+r12*1]
00007d3d13bd14e5  mov eax, [r15+0x48]
00007d3d13bd14e9  mov [r13+r11*1], eax
00007d3d13bd14ee  xor eax, eax
00007d3d13bd14f0  mov r12d, 0x400
00007d3d13bd14f6  cmp r14, r12
00007d3d13bd14f9  cmc
00007d3d13bd14fa  lahf
00007d3d13bd14fb  seto al
00007d3d13bd14fe  mov [r15+0x108], eax
00007d3d13bd1505  mov eax, [r15+0x108]
00007d3d13bd150c  sahf
00007d3d13bd150d  jz 0x00007D3D13BD153F
00007d3d13bd150f  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd1517  jz 0x00007D3D13BD1120
00007d3d13bd151d  nop [rax+rax*1], ax
00007d3d13bd1526  nop [rax+rax*1], eax
00007d3d13bd152e  mov eax, 0x410388
00007d3d13bd1533  mov [r15+0x100], rax
00007d3d13bd153a  jmp 0x00007D3D139FE110
00007d3d13bd153f  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd1547  jz 0x00007D3D13BD1580
00007d3d13bd154d  nop [rax+rax*1], ax
00007d3d13bd1556  nop [rax+rax*1], eax
00007d3d13bd155e  mov eax, 0x4103B0
00007d3d13bd1563  mov [r15+0x100], rax
00007d3d13bd156a  jmp 0x00007D3D139FE110
00007d3d13bd156f  int3
00007d3d13bd1570  call 0x00007D3D13AA4270
00007d3d13bd1575  jmp 0x00007D3D13BD14EE
00007d3d13bd157a  int3
00007d3d13bd157b  nop [rax+rax*1], eax
00007d3d13bd1580  mov qword ptr [r15+0x40], 0x430000
00007d3d13bd1588  mov eax, 0x430CB0
00007d3d13bd158d  mov r14, [r13+rax*1]
00007d3d13bd1592  mov rax, [r15+0x98]
00007d3d13bd1599  mov r12d, [r13+rax*1]
00007d3d13bd159e  lea r11, [rax+0x04]
00007d3d13bd15a2  mov eax, [r13+r11*1]
00007d3d13bd15a7  mov r12d, r12d
00007d3d13bd15aa  mov [r15+0x68], r12
00007d3d13bd15ae  mov eax, eax
00007d3d13bd15b0  mov [r15+0x60], rax
00007d3d13bd15b4  mov rax, [r15+0x68]
00007d3d13bd15b8  mov [r15+0x68], rax
00007d3d13bd15bc  mov qword ptr [r15+0x58], 0x02
00007d3d13bd15c4  mov [rsp+0x10], rax
00007d3d13bd15c9  xor eax, eax
00007d3d13bd15cb  mov r12d, 0x02
00007d3d13bd15d1  mov r11d, 0x400
00007d3d13bd15d7  cmp r12, r11
00007d3d13bd15da  cmc
00007d3d13bd15db  lahf
00007d3d13bd15dc  seto al
00007d3d13bd15df  mov [r15+0x108], eax
00007d3d13bd15e6  mov rax, [r15+0x60]
00007d3d13bd15ea  mov r12d, 0x02
00007d3d13bd15f0  imul rax, r12
00007d3d13bd15f4  mov [r15+0x50], rax
00007d3d13bd15f8  mov rax, [rsp+0x10]
00007d3d13bd15fd  lea r12, [rax+r14*1]
00007d3d13bd1601  mov [r15+0x48], r12
00007d3d13bd1605  mov eax, [r15+0x108]
00007d3d13bd160c  sahf
00007d3d13bd160d  jnz 0x00007D3D13BD163F
00007d3d13bd160f  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd1617  jz 0x00007D3D13BD17B0
00007d3d13bd161d  nop [rax+rax*1], ax
00007d3d13bd1626  nop [rax+rax*1], eax
00007d3d13bd162e  mov eax, 0x4103E0
00007d3d13bd1633  mov [r15+0x100], rax
00007d3d13bd163a  jmp 0x00007D3D139FE110
00007d3d13bd163f  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd1647  jz 0x00007D3D13BD1690
00007d3d13bd164d  nop [rax+rax*1], ax
00007d3d13bd1656  nop [rax+rax*1], eax
00007d3d13bd165e  mov eax, 0x4103C0
00007d3d13bd1663  mov [r15+0x100], rax
00007d3d13bd166a  jmp 0x00007D3D139FE110
00007d3d13bd166f  int3
00007d3d13bd1670  call 0x00007D3D13A0DC20
00007d3d13bd1675  jmp 0x00007D3D13BD1592
00007d3d13bd167a  call 0x00007D3D13A0B5E0
00007d3d13bd167f  jmp 0x00007D3D13BD159E
00007d3d13bd1684  call 0x00007D3D13AA3D90
00007d3d13bd1689  jmp 0x00007D3D13BD15A7
00007d3d13bd168e  int3
00007d3d13bd168f  nop
00007d3d13bd1690  mov rax, [r15+0x98]
00007d3d13bd1697  mov r14, [r15+0x58]
00007d3d13bd169b  mov [rsp+0x10], r14
00007d3d13bd16a0  shl r14, 0x02
00007d3d13bd16a4  lea r12, [rax+r14*1]
00007d3d13bd16a8  mov eax, [r13+r12*1]
00007d3d13bd16ad  lea r14, [r12+0x04]
00007d3d13bd16b2  mov r12d, [r13+r14*1]
00007d3d13bd16b7  mov eax, eax
00007d3d13bd16b9  mov [r15+0x68], rax
00007d3d13bd16bd  mov r12d, r12d
00007d3d13bd16c0  mov [r15+0x60], r12
00007d3d13bd16c4  mov rax, [r15+0x68]
00007d3d13bd16c8  mov [rsp+0x20], rax
00007d3d13bd16cd  mov r14, [rsp+0x10]
00007d3d13bd16d2  imul rax, r14
00007d3d13bd16d6  mov r12, [rsp+0x20]
00007d3d13bd16db  lea r11, [r12+rax*1]
00007d3d13bd16df  mov [r15+0x68], r11
00007d3d13bd16e3  lea rax, [r14+0x02]
00007d3d13bd16e7  mov [r15+0x58], rax
00007d3d13bd16eb  mov [rsp+0x10], rax
00007d3d13bd16f0  xor eax, eax
00007d3d13bd16f2  mov r14, [rsp+0x10]
00007d3d13bd16f7  mov r12d, 0x400
00007d3d13bd16fd  cmp r14, r12
00007d3d13bd1700  cmc
00007d3d13bd1701  lahf
00007d3d13bd1702  seto al
00007d3d13bd1705  mov [r15+0x108], eax
00007d3d13bd170c  mov rax, [r15+0x50]
00007d3d13bd1710  mov r12, [r15+0x60]
00007d3d13bd1714  imul r14, r12
00007d3d13bd1718  lea r12, [rax+r14*1]
00007d3d13bd171c  mov [r15+0x50], r12
00007d3d13bd1720  mov rax, [r15+0x48]
00007d3d13bd1724  lea r14, [r11+rax*1]
00007d3d13bd1728  mov [r15+0x48], r14
00007d3d13bd172c  mov eax, [r15+0x108]
00007d3d13bd1733  sahf
00007d3d13bd1734  jnz 0x00007D3D13BD1766
00007d3d13bd1736  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd173e  jz 0x00007D3D13BD17B0
00007d3d13bd1744  nop [rax+rax*1], ax
00007d3d13bd174d  nop [rax+rax*1], eax
00007d3d13bd1755  mov eax, 0x4103E0
00007d3d13bd175a  mov [r15+0x100], rax
00007d3d13bd1761  jmp 0x00007D3D139FE110
00007d3d13bd1766  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd176e  jz 0x00007D3D13BD1690
00007d3d13bd1774  nop [rax+rax*1], ax
00007d3d13bd177d  nop [rax+rax*1], eax
00007d3d13bd1785  mov eax, 0x4103C0
00007d3d13bd178a  mov [r15+0x100], rax
00007d3d13bd1791  jmp 0x00007D3D139FE110
00007d3d13bd1796  int3
00007d3d13bd1797  call 0x00007D3D13AB4690
00007d3d13bd179c  jmp 0x00007D3D13BD16AD
00007d3d13bd17a1  call 0x00007D3D13AE26A0
00007d3d13bd17a6  jmp 0x00007D3D13BD16B7
00007d3d13bd17ab  int3
00007d3d13bd17ac  nop [rax], eax
00007d3d13bd17b0  mov qword ptr [r15+0x98], 0x00
00007d3d13bd17bb  mov rax, [r15+0x50]
00007d3d13bd17bf  mov r14, [r15+0x48]
00007d3d13bd17c3  lea r12, [rax+r14*1]
00007d3d13bd17c7  mov [r15+0x48], r12
00007d3d13bd17cb  mov rax, [r15+0x40]
00007d3d13bd17cf  lea r14, [rax+0xCB0]
00007d3d13bd17d6  mov [r13+r14*1], r12
00007d3d13bd17db  mov qword ptr [r15], 0x01
00007d3d13bd17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007d3d13bd17ed  mov r14d, [r15+0x320]
00007d3d13bd17f4  mov eax, 0x4103F8
00007d3d13bd17f9  mov rcx, 0x7D3D13BD1860
00007d3d13bd1803  mov [r15+r14*8+0x328], rax
00007d3d13bd180b  mov [r15+r14*8+0x368], rcx
00007d3d13bd1813  add r14d, 0x01
00007d3d13bd1817  and r14d, 0x07
00007d3d13bd181b  mov [r15+0x320], r14d
00007d3d13bd1822  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd182a  jz 0x00007D3D13BD0F20
00007d3d13bd1830  nop [rax+rax*1], ax
00007d3d13bd1839  nop [rax+rax*1], eax
00007d3d13bd1841  mov eax, 0x4109A4
00007d3d13bd1846  mov [r15+0x100], rax
00007d3d13bd184d  jmp 0x00007D3D139FE110
00007d3d13bd1852  int3
00007d3d13bd1853  call 0x00007D3D13AE2CE0
00007d3d13bd1858  jmp 0x00007D3D13BD17DB
00007d3d13bd185d  int3
00007d3d13bd185e  nop
00007d3d13bd1860  mov eax, [r15+0x98]
00007d3d13bd1867  lea r14d, [eax+0x01]
00007d3d13bd186c  mov [rsp+0x10], r14d
00007d3d13bd1871  mov r14d, r14d
00007d3d13bd1874  mov [r15+0x98], r14
00007d3d13bd187b  xor eax, eax
00007d3d13bd187d  mov r14d, [rsp+0x10]
00007d3d13bd1882  cmp r14d, 0x10000
00007d3d13bd1889  cmc
00007d3d13bd188a  lahf
00007d3d13bd188b  seto al
00007d3d13bd188e  mov [r15+0x108], eax
00007d3d13bd1895  mov eax, [r15+0x108]
00007d3d13bd189c  sahf
00007d3d13bd189d  jnz 0x00007D3D13BD18CF
00007d3d13bd189f  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd18a7  jz 0x00007D3D13BD19A0
00007d3d13bd18ad  nop [rax+rax*1], ax
00007d3d13bd18b6  nop [rax+rax*1], eax
00007d3d13bd18be  mov eax, 0x410404
00007d3d13bd18c3  mov [r15+0x100], rax
00007d3d13bd18ca  jmp 0x00007D3D139FE110
00007d3d13bd18cf  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd18d7  jz 0x00007D3D13BD1910
00007d3d13bd18dd  nop [rax+rax*1], ax
00007d3d13bd18e6  nop [rax+rax*1], eax
00007d3d13bd18ee  mov eax, 0x4103F0
00007d3d13bd18f3  mov [r15+0x100], rax
00007d3d13bd18fa  jmp 0x00007D3D139FE110
00007d3d13bd18ff  int3
00007d3d13bd1900  int3
00007d3d13bd1901  nop [rax+rax*1], ax
00007d3d13bd190a  nop [rax+rax*1], ax
00007d3d13bd1910  mov eax, [r15]
00007d3d13bd1913  mov r14d, [r15+0x98]
00007d3d13bd191a  lea r12d, [eax+r14d*1]
00007d3d13bd191f  mov r12d, r12d
00007d3d13bd1922  mov [r15], r12
00007d3d13bd1925  mov qword ptr [r15+0xF0], 0x4103F8
00007d3d13bd1930  mov r14d, [r15+0x320]
00007d3d13bd1937  mov eax, 0x4103F8
00007d3d13bd193c  mov rcx, 0x7D3D13BD1860
00007d3d13bd1946  mov [r15+r14*8+0x328], rax
00007d3d13bd194e  mov [r15+r14*8+0x368], rcx
00007d3d13bd1956  add r14d, 0x01
00007d3d13bd195a  and r14d, 0x07
00007d3d13bd195e  mov [r15+0x320], r14d
00007d3d13bd1965  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd196d  jz 0x00007D3D13BD0F20
00007d3d13bd1973  nop [rax+rax*1], ax
00007d3d13bd197c  nop [rax+rax*1], eax
00007d3d13bd1984  mov eax, 0x4109A4
00007d3d13bd1989  mov [r15+0x100], rax
00007d3d13bd1990  jmp 0x00007D3D139FE110
00007d3d13bd1995  int3
00007d3d13bd1996  int3
00007d3d13bd1997  nop [rax+rax*1], ax
00007d3d13bd19a0  vmovaps xmm1, [0x00007D3D137FE010]
00007d3d13bd19a8  movq xmm1, xmm1
00007d3d13bd19ac  movaps [r15+0x110], xmm1
00007d3d13bd19b4  mov eax, 0x420B10
00007d3d13bd19b9  mov r14, [r13+rax*1]
00007d3d13bd19be  movq xmm1, r14
00007d3d13bd19c3  movaps [r15+0x120], xmm1
00007d3d13bd19cb  vmovaps xmm1, [0x00007D3D137FE020]
00007d3d13bd19d3  movq xmm1, xmm1
00007d3d13bd19d7  movaps [r15+0x140], xmm1
00007d3d13bd19df  vmovaps xmm1, [0x00007D3D137FE030]
00007d3d13bd19e7  vpbroadcastq xmm1, xmm1
00007d3d13bd19ec  movaps [r15+0x150], xmm1
00007d3d13bd19f4  mov qword ptr [r15+0x40], 0x02
00007d3d13bd19fc  vmovaps xmm15, [0x00007D3D137FE040]
00007d3d13bd1a04  movq xmm15, xmm15
00007d3d13bd1a09  movaps [r15+0x160], xmm15
00007d3d13bd1a11  vmovaps xmm15, [0x00007D3D137FE050]
00007d3d13bd1a19  vpbroadcastq xmm15, xmm15
00007d3d13bd1a1e  movaps [r15+0x130], xmm15
00007d3d13bd1a26  mov rax, [r15+0x40]
00007d3d13bd1a2a  vmovq xmm14, rax
00007d3d13bd1a2f  vpbroadcastq xmm14, xmm14
00007d3d13bd1a34  movaps [r15+0x170], xmm14
00007d3d13bd1a3c  mov eax, 0x420A40
00007d3d13bd1a41  movups xmm13, [r13+rax*1]
00007d3d13bd1a47  mov qword ptr [r15+0x40], 0x431E00
00007d3d13bd1a4f  mov eax, [r15]
00007d3d13bd1a52  mov r14d, 0x430CB8
00007d3d13bd1a58  mov [r13+r14*1], eax
00007d3d13bd1a5d  mov qword ptr [r15+0x50], 0x432000
00007d3d13bd1a65  vpmovqd xmm12, xmm13
00007d3d13bd1a6b  pxor xmm11, xmm11
00007d3d13bd1a70  punpcklqdq xmm12, xmm11
00007d3d13bd1a75  movaps [r15+0x210], xmm12
00007d3d13bd1a7d  movq xmm12, qword ptr [r15+0x140]
00007d3d13bd1a86  movq xmm11, qword ptr [r15+0x120]
00007d3d13bd1a8f  psubd xmm12, xmm11
00007d3d13bd1a94  movq xmm12, xmm12
00007d3d13bd1a99  paddq xmm13, xmm14
00007d3d13bd1a9e  movaps [r15+0x180], xmm13
00007d3d13bd1aa6  movq xmm14, qword ptr [r15+0x160]
00007d3d13bd1aaf  paddd xmm11, xmm14
00007d3d13bd1ab4  movq xmm11, xmm11
00007d3d13bd1ab9  movq xmm11, xmm11
00007d3d13bd1abe  movaps [r15+0x120], xmm11
00007d3d13bd1ac6  pmovzxdq xmm12, xmm12
00007d3d13bd1acc  psllq xmm12, 0x00
00007d3d13bd1ad2  movq xmm14, qword ptr [r15+0x210]
00007d3d13bd1adb  movq xmm13, qword ptr [r15+0x110]
00007d3d13bd1ae4  paddd xmm14, xmm13
00007d3d13bd1ae9  movq xmm14, xmm14
00007d3d13bd1aee  vcvtuqq2pd xmm12, xmm12
00007d3d13bd1af4  pmovzxdq xmm14, xmm14
00007d3d13bd1afa  psllq xmm14, 0x00
00007d3d13bd1b00  vcvtuqq2pd xmm14, xmm14
00007d3d13bd1b06  movaps xmm13, xmm12
00007d3d13bd1b0a  mulpd xmm13, xmm1
00007d3d13bd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007d3d13bd1b15  ptest xmm11, xmm11
00007d3d13bd1b1b  jnz 0x00007D3D13BD1C0F
00007d3d13bd1b21  movaps [r15+0x220], xmm13
00007d3d13bd1b29  mov eax, 0x432000
00007d3d13bd1b2e  movups [r13+rax*1], xmm13
00007d3d13bd1b34  movaps xmm1, xmm14
00007d3d13bd1b38  mulpd xmm1, xmm15
00007d3d13bd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007d3d13bd1b42  ptest xmm13, xmm13
00007d3d13bd1b48  jnz 0x00007D3D13BD1D5C
00007d3d13bd1b4e  movaps [r15+0x210], xmm1
00007d3d13bd1b56  mov eax, 0x431E00
00007d3d13bd1b5b  movups [r13+rax*1], xmm1
00007d3d13bd1b61  mov qword ptr [r15+0x48], 0x10
00007d3d13bd1b69  xor eax, eax
00007d3d13bd1b6b  mov r14d, 0x10
00007d3d13bd1b71  mov r12d, 0x200
00007d3d13bd1b77  cmp r14, r12
00007d3d13bd1b7a  cmc
00007d3d13bd1b7b  lahf
00007d3d13bd1b7c  seto al
00007d3d13bd1b7f  mov [r15+0x108], eax
00007d3d13bd1b86  mov eax, [r15+0x108]
00007d3d13bd1b8d  sahf
00007d3d13bd1b8e  jnz 0x00007D3D13BD1BC0
00007d3d13bd1b90  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd1b98  jz 0x00007D3D13BD2300
00007d3d13bd1b9e  nop [rax+rax*1], ax
00007d3d13bd1ba7  nop [rax+rax*1], eax
00007d3d13bd1baf  mov eax, 0x410490
00007d3d13bd1bb4  mov [r15+0x100], rax
00007d3d13bd1bbb  jmp 0x00007D3D139FE110
00007d3d13bd1bc0  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd1bc8  jz 0x00007D3D13BD1EB0
00007d3d13bd1bce  nop [rax+rax*1], ax
00007d3d13bd1bd7  nop [rax+rax*1], eax
00007d3d13bd1bdf  mov eax, 0x410450
00007d3d13bd1be4  mov [r15+0x100], rax
00007d3d13bd1beb  jmp 0x00007D3D139FE110
00007d3d13bd1bf0  int3
00007d3d13bd1bf1  call 0x00007D3D13A0DC20
00007d3d13bd1bf6  jmp 0x00007D3D13BD19BE
00007d3d13bd1bfb  call 0x00007D3D13A0C260
00007d3d13bd1c00  jmp 0x00007D3D13BD1A47
00007d3d13bd1c05  call 0x00007D3D13AD5D70
00007d3d13bd1c0a  jmp 0x00007D3D13BD1A5D
00007d3d13bd1c0f  sub rsp, 0x08
00007d3d13bd1c13  push rax
00007d3d13bd1c14  push rcx
00007d3d13bd1c15  push rdx
00007d3d13bd1c16  push rdi
00007d3d13bd1c17  push rsi
00007d3d13bd1c18  push r8
00007d3d13bd1c1a  push r9
00007d3d13bd1c1c  push r10
00007d3d13bd1c1e  push r11
00007d3d13bd1c20  sub rsp, 0xF0
00007d3d13bd1c27  vmovaps [rsp], xmm0
00007d3d13bd1c2c  vmovaps [rsp+0x10], xmm1
00007d3d13bd1c32  vmovaps [rsp+0x20], xmm2
00007d3d13bd1c38  vmovaps [rsp+0x30], xmm3
00007d3d13bd1c3e  vmovaps [rsp+0x40], xmm4
00007d3d13bd1c44  vmovaps [rsp+0x50], xmm5
00007d3d13bd1c4a  vmovaps [rsp+0x60], xmm6
00007d3d13bd1c50  vmovaps [rsp+0x70], xmm7
00007d3d13bd1c56  vmovaps [rsp+0x80], xmm8
00007d3d13bd1c5f  vmovaps [rsp+0x90], xmm9
00007d3d13bd1c68  vmovaps [rsp+0xA0], xmm10
00007d3d13bd1c71  vmovaps [rsp+0xB0], xmm11
00007d3d13bd1c7a  vmovaps [rsp+0xC0], xmm12
00007d3d13bd1c83  vmovaps [rsp+0xD0], xmm14
00007d3d13bd1c8c  vmovaps [rsp+0xE0], xmm15
00007d3d13bd1c95  sub rsp, 0x30
00007d3d13bd1c99  movaps [rsp], xmm13
00007d3d13bd1c9e  movaps [rsp+0x10], xmm12
00007d3d13bd1ca4  movaps [rsp+0x20], xmm1
00007d3d13bd1ca9  lea rdi, [rsp]
00007d3d13bd1cad  mov esi, 0x00
00007d3d13bd1cb2  mov rax, 0x5741DAFC8530
00007d3d13bd1cbc  call rax
00007d3d13bd1cbe  movaps xmm13, [rsp]
00007d3d13bd1cc3  add rsp, 0x30
00007d3d13bd1cc7  vmovaps xmm0, [rsp]
00007d3d13bd1ccc  vmovaps xmm1, [rsp+0x10]
00007d3d13bd1cd2  vmovaps xmm2, [rsp+0x20]
00007d3d13bd1cd8  vmovaps xmm3, [rsp+0x30]
00007d3d13bd1cde  vmovaps xmm4, [rsp+0x40]
00007d3d13bd1ce4  vmovaps xmm5, [rsp+0x50]
00007d3d13bd1cea  vmovaps xmm6, [rsp+0x60]
00007d3d13bd1cf0  vmovaps xmm7, [rsp+0x70]
00007d3d13bd1cf6  vmovaps xmm8, [rsp+0x80]
00007d3d13bd1cff  vmovaps xmm9, [rsp+0x90]
00007d3d13bd1d08  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd1d11  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd1d1a  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd1d23  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd1d2c  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd1d35  add rsp, 0xF0
00007d3d13bd1d3c  pop r11
00007d3d13bd1d3e  pop r10
00007d3d13bd1d40  pop r9
00007d3d13bd1d42  pop r8
00007d3d13bd1d44  pop rsi
00007d3d13bd1d45  pop rdi
00007d3d13bd1d46  pop rdx
00007d3d13bd1d47  pop rcx
00007d3d13bd1d48  pop rax
00007d3d13bd1d49  add rsp, 0x08
00007d3d13bd1d4d  jmp 0x00007D3D13BD1B21
00007d3d13bd1d52  call 0x00007D3D13A0C380
00007d3d13bd1d57  jmp 0x00007D3D13BD1B34
00007d3d13bd1d5c  sub rsp, 0x08
00007d3d13bd1d60  push rax
00007d3d13bd1d61  push rcx
00007d3d13bd1d62  push rdx
00007d3d13bd1d63  push rdi
00007d3d13bd1d64  push rsi
00007d3d13bd1d65  push r8
00007d3d13bd1d67  push r9
00007d3d13bd1d69  push r10
00007d3d13bd1d6b  push r11
00007d3d13bd1d6d  sub rsp, 0xF0
00007d3d13bd1d74  vmovaps [rsp], xmm0
00007d3d13bd1d79  vmovaps [rsp+0x10], xmm2
00007d3d13bd1d7f  vmovaps [rsp+0x20], xmm3
00007d3d13bd1d85  vmovaps [rsp+0x30], xmm4
00007d3d13bd1d8b  vmovaps [rsp+0x40], xmm5
00007d3d13bd1d91  vmovaps [rsp+0x50], xmm6
00007d3d13bd1d97  vmovaps [rsp+0x60], xmm7
00007d3d13bd1d9d  vmovaps [rsp+0x70], xmm8
00007d3d13bd1da3  vmovaps [rsp+0x80], xmm9
00007d3d13bd1dac  vmovaps [rsp+0x90], xmm10
00007d3d13bd1db5  vmovaps [rsp+0xA0], xmm11
00007d3d13bd1dbe  vmovaps [rsp+0xB0], xmm12
00007d3d13bd1dc7  vmovaps [rsp+0xC0], xmm13
00007d3d13bd1dd0  vmovaps [rsp+0xD0], xmm14
00007d3d13bd1dd9  vmovaps [rsp+0xE0], xmm15
00007d3d13bd1de2  sub rsp, 0x30
00007d3d13bd1de6  movaps [rsp], xmm1
00007d3d13bd1dea  movaps [rsp+0x10], xmm14
00007d3d13bd1df0  movaps [rsp+0x20], xmm15
00007d3d13bd1df6  lea rdi, [rsp]
00007d3d13bd1dfa  mov esi, 0x00
00007d3d13bd1dff  mov rax, 0x5741DAFC8530
00007d3d13bd1e09  call rax
00007d3d13bd1e0b  movaps xmm1, [rsp]
00007d3d13bd1e0f  add rsp, 0x30
00007d3d13bd1e13  vmovaps xmm0, [rsp]
00007d3d13bd1e18  vmovaps xmm2, [rsp+0x10]
00007d3d13bd1e1e  vmovaps xmm3, [rsp+0x20]
00007d3d13bd1e24  vmovaps xmm4, [rsp+0x30]
00007d3d13bd1e2a  vmovaps xmm5, [rsp+0x40]
00007d3d13bd1e30  vmovaps xmm6, [rsp+0x50]
00007d3d13bd1e36  vmovaps xmm7, [rsp+0x60]
00007d3d13bd1e3c  vmovaps xmm8, [rsp+0x70]
00007d3d13bd1e42  vmovaps xmm9, [rsp+0x80]
00007d3d13bd1e4b  vmovaps xmm10, [rsp+0x90]
00007d3d13bd1e54  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd1e5d  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd1e66  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd1e6f  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd1e78  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd1e81  add rsp, 0xF0
00007d3d13bd1e88  pop r11
00007d3d13bd1e8a  pop r10
00007d3d13bd1e8c  pop r9
00007d3d13bd1e8e  pop r8
00007d3d13bd1e90  pop rsi
00007d3d13bd1e91  pop rdi
00007d3d13bd1e92  pop rdx
00007d3d13bd1e93  pop rcx
00007d3d13bd1e94  pop rax
00007d3d13bd1e95  add rsp, 0x08
00007d3d13bd1e99  jmp 0x00007D3D13BD1B4E
00007d3d13bd1e9e  call 0x00007D3D139FF540
00007d3d13bd1ea3  jmp 0x00007D3D13BD1B61
00007d3d13bd1ea8  int3
00007d3d13bd1ea9  nop [rax], eax
00007d3d13bd1eb0  movaps xmm1, [r15+0x180]
00007d3d13bd1eb8  vpmovqd xmm15, xmm1
00007d3d13bd1ebe  pxor xmm14, xmm14
00007d3d13bd1ec3  punpcklqdq xmm15, xmm14
00007d3d13bd1ec8  movaps [r15+0x210], xmm15
00007d3d13bd1ed0  movq xmm15, qword ptr [r15+0x140]
00007d3d13bd1ed9  movq xmm14, qword ptr [r15+0x120]
00007d3d13bd1ee2  psubd xmm15, xmm14
00007d3d13bd1ee7  movq xmm15, xmm15
00007d3d13bd1eec  movaps xmm13, [r15+0x170]
00007d3d13bd1ef4  paddq xmm1, xmm13
00007d3d13bd1ef9  movaps [r15+0x180], xmm1
00007d3d13bd1f01  movq xmm1, qword ptr [r15+0x160]
00007d3d13bd1f0a  paddd xmm14, xmm1
00007d3d13bd1f0f  movq xmm14, xmm14
00007d3d13bd1f14  movq xmm14, xmm14
00007d3d13bd1f19  movaps [r15+0x120], xmm14
00007d3d13bd1f21  pmovzxdq xmm15, xmm15
00007d3d13bd1f27  psllq xmm15, 0x00
00007d3d13bd1f2d  movq xmm1, qword ptr [r15+0x210]
00007d3d13bd1f36  movq xmm14, qword ptr [r15+0x110]
00007d3d13bd1f3f  paddd xmm1, xmm14
00007d3d13bd1f44  movq xmm1, xmm1
00007d3d13bd1f48  vcvtuqq2pd xmm15, xmm15
00007d3d13bd1f4e  pmovzxdq xmm1, xmm1
00007d3d13bd1f53  psllq xmm1, 0x00
00007d3d13bd1f58  vcvtuqq2pd xmm1, xmm1
00007d3d13bd1f5e  movaps xmm14, [r15+0x150]
00007d3d13bd1f66  movaps xmm13, xmm15
00007d3d13bd1f6a  mulpd xmm13, xmm14
00007d3d13bd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d3d13bd1f75  ptest xmm12, xmm12
00007d3d13bd1f7b  jnz 0x00007D3D13BD205E
00007d3d13bd1f81  movaps [r15+0x220], xmm13
00007d3d13bd1f89  mov rax, [r15+0x48]
00007d3d13bd1f8d  mov r14, [r15+0x50]
00007d3d13bd1f91  lea r12, [r14+rax*1]
00007d3d13bd1f95  movups [r13+r12*1], xmm13
00007d3d13bd1f9b  movaps xmm15, [r15+0x130]
00007d3d13bd1fa3  movaps xmm14, xmm1
00007d3d13bd1fa7  mulpd xmm14, xmm15
00007d3d13bd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007d3d13bd1fb2  ptest xmm13, xmm13
00007d3d13bd1fb8  jnz 0x00007D3D13BD21AC
00007d3d13bd1fbe  movaps [r15+0x210], xmm14
00007d3d13bd1fc6  mov r14, [r15+0x40]
00007d3d13bd1fca  lea r12, [r14+rax*1]
00007d3d13bd1fce  movups [r13+r12*1], xmm14
00007d3d13bd1fd4  lea r14, [rax+0x10]
00007d3d13bd1fd8  mov [r15+0x48], r14
00007d3d13bd1fdc  xor eax, eax
00007d3d13bd1fde  mov r12d, 0x200
00007d3d13bd1fe4  cmp r14, r12
00007d3d13bd1fe7  cmc
00007d3d13bd1fe8  lahf
00007d3d13bd1fe9  seto al
00007d3d13bd1fec  mov [r15+0x108], eax
00007d3d13bd1ff3  mov eax, [r15+0x108]
00007d3d13bd1ffa  sahf
00007d3d13bd1ffb  jnz 0x00007D3D13BD202D
00007d3d13bd1ffd  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd2005  jz 0x00007D3D13BD2300
00007d3d13bd200b  nop [rax+rax*1], ax
00007d3d13bd2014  nop [rax+rax*1], eax
00007d3d13bd201c  mov eax, 0x410490
00007d3d13bd2021  mov [r15+0x100], rax
00007d3d13bd2028  jmp 0x00007D3D139FE110
00007d3d13bd202d  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd2035  jz 0x00007D3D13BD1EB0
00007d3d13bd203b  nop [rax+rax*1], ax
00007d3d13bd2044  nop [rax+rax*1], eax
00007d3d13bd204c  mov eax, 0x410450
00007d3d13bd2051  mov [r15+0x100], rax
00007d3d13bd2058  jmp 0x00007D3D139FE110
00007d3d13bd205d  int3
00007d3d13bd205e  sub rsp, 0x08
00007d3d13bd2062  push rax
00007d3d13bd2063  push rcx
00007d3d13bd2064  push rdx
00007d3d13bd2065  push rdi
00007d3d13bd2066  push rsi
00007d3d13bd2067  push r8
00007d3d13bd2069  push r9
00007d3d13bd206b  push r10
00007d3d13bd206d  push r11
00007d3d13bd206f  sub rsp, 0xF0
00007d3d13bd2076  vmovaps [rsp], xmm0
00007d3d13bd207b  vmovaps [rsp+0x10], xmm1
00007d3d13bd2081  vmovaps [rsp+0x20], xmm2
00007d3d13bd2087  vmovaps [rsp+0x30], xmm3
00007d3d13bd208d  vmovaps [rsp+0x40], xmm4
00007d3d13bd2093  vmovaps [rsp+0x50], xmm5
00007d3d13bd2099  vmovaps [rsp+0x60], xmm6
00007d3d13bd209f  vmovaps [rsp+0x70], xmm7
00007d3d13bd20a5  vmovaps [rsp+0x80], xmm8
00007d3d13bd20ae  vmovaps [rsp+0x90], xmm9
00007d3d13bd20b7  vmovaps [rsp+0xA0], xmm10
00007d3d13bd20c0  vmovaps [rsp+0xB0], xmm11
00007d3d13bd20c9  vmovaps [rsp+0xC0], xmm12
00007d3d13bd20d2  vmovaps [rsp+0xD0], xmm14
00007d3d13bd20db  vmovaps [rsp+0xE0], xmm15
00007d3d13bd20e4  sub rsp, 0x30
00007d3d13bd20e8  movaps [rsp], xmm13
00007d3d13bd20ed  movaps [rsp+0x10], xmm15
00007d3d13bd20f3  movaps [rsp+0x20], xmm14
00007d3d13bd20f9  lea rdi, [rsp]
00007d3d13bd20fd  mov esi, 0x00
00007d3d13bd2102  mov rax, 0x5741DAFC8530
00007d3d13bd210c  call rax
00007d3d13bd210e  movaps xmm13, [rsp]
00007d3d13bd2113  add rsp, 0x30
00007d3d13bd2117  vmovaps xmm0, [rsp]
00007d3d13bd211c  vmovaps xmm1, [rsp+0x10]
00007d3d13bd2122  vmovaps xmm2, [rsp+0x20]
00007d3d13bd2128  vmovaps xmm3, [rsp+0x30]
00007d3d13bd212e  vmovaps xmm4, [rsp+0x40]
00007d3d13bd2134  vmovaps xmm5, [rsp+0x50]
00007d3d13bd213a  vmovaps xmm6, [rsp+0x60]
00007d3d13bd2140  vmovaps xmm7, [rsp+0x70]
00007d3d13bd2146  vmovaps xmm8, [rsp+0x80]
00007d3d13bd214f  vmovaps xmm9, [rsp+0x90]
00007d3d13bd2158  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd2161  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd216a  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd2173  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd217c  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd2185  add rsp, 0xF0
00007d3d13bd218c  pop r11
00007d3d13bd218e  pop r10
00007d3d13bd2190  pop r9
00007d3d13bd2192  pop r8
00007d3d13bd2194  pop rsi
00007d3d13bd2195  pop rdi
00007d3d13bd2196  pop rdx
00007d3d13bd2197  pop rcx
00007d3d13bd2198  pop rax
00007d3d13bd2199  add rsp, 0x08
00007d3d13bd219d  jmp 0x00007D3D13BD1F81
00007d3d13bd21a2  call 0x00007D3D13AC2240
00007d3d13bd21a7  jmp 0x00007D3D13BD1F9B
00007d3d13bd21ac  sub rsp, 0x08
00007d3d13bd21b0  push rax
00007d3d13bd21b1  push rcx
00007d3d13bd21b2  push rdx
00007d3d13bd21b3  push rdi
00007d3d13bd21b4  push rsi
00007d3d13bd21b5  push r8
00007d3d13bd21b7  push r9
00007d3d13bd21b9  push r10
00007d3d13bd21bb  push r11
00007d3d13bd21bd  sub rsp, 0xF0
00007d3d13bd21c4  vmovaps [rsp], xmm0
00007d3d13bd21c9  vmovaps [rsp+0x10], xmm1
00007d3d13bd21cf  vmovaps [rsp+0x20], xmm2
00007d3d13bd21d5  vmovaps [rsp+0x30], xmm3
00007d3d13bd21db  vmovaps [rsp+0x40], xmm4
00007d3d13bd21e1  vmovaps [rsp+0x50], xmm5
00007d3d13bd21e7  vmovaps [rsp+0x60], xmm6
00007d3d13bd21ed  vmovaps [rsp+0x70], xmm7
00007d3d13bd21f3  vmovaps [rsp+0x80], xmm8
00007d3d13bd21fc  vmovaps [rsp+0x90], xmm9
00007d3d13bd2205  vmovaps [rsp+0xA0], xmm10
00007d3d13bd220e  vmovaps [rsp+0xB0], xmm11
00007d3d13bd2217  vmovaps [rsp+0xC0], xmm12
00007d3d13bd2220  vmovaps [rsp+0xD0], xmm13
00007d3d13bd2229  vmovaps [rsp+0xE0], xmm15
00007d3d13bd2232  sub rsp, 0x30
00007d3d13bd2236  movaps [rsp], xmm14
00007d3d13bd223b  movaps [rsp+0x10], xmm1
00007d3d13bd2240  movaps [rsp+0x20], xmm15
00007d3d13bd2246  lea rdi, [rsp]
00007d3d13bd224a  mov esi, 0x00
00007d3d13bd224f  mov rax, 0x5741DAFC8530
00007d3d13bd2259  call rax
00007d3d13bd225b  movaps xmm14, [rsp]
00007d3d13bd2260  add rsp, 0x30
00007d3d13bd2264  vmovaps xmm0, [rsp]
00007d3d13bd2269  vmovaps xmm1, [rsp+0x10]
00007d3d13bd226f  vmovaps xmm2, [rsp+0x20]
00007d3d13bd2275  vmovaps xmm3, [rsp+0x30]
00007d3d13bd227b  vmovaps xmm4, [rsp+0x40]
00007d3d13bd2281  vmovaps xmm5, [rsp+0x50]
00007d3d13bd2287  vmovaps xmm6, [rsp+0x60]
00007d3d13bd228d  vmovaps xmm7, [rsp+0x70]
00007d3d13bd2293  vmovaps xmm8, [rsp+0x80]
00007d3d13bd229c  vmovaps xmm9, [rsp+0x90]
00007d3d13bd22a5  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd22ae  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd22b7  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd22c0  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd22c9  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd22d2  add rsp, 0xF0
00007d3d13bd22d9  pop r11
00007d3d13bd22db  pop r10
00007d3d13bd22dd  pop r9
00007d3d13bd22df  pop r8
00007d3d13bd22e1  pop rsi
00007d3d13bd22e2  pop rdi
00007d3d13bd22e3  pop rdx
00007d3d13bd22e4  pop rcx
00007d3d13bd22e5  pop rax
00007d3d13bd22e6  add rsp, 0x08
00007d3d13bd22ea  jmp 0x00007D3D13BD1FBE
00007d3d13bd22ef  call 0x00007D3D13AC34C0
00007d3d13bd22f4  jmp 0x00007D3D13BD1FD4
00007d3d13bd22f9  int3
00007d3d13bd22fa  nop [rax+rax*1], ax
00007d3d13bd2300  mov rax, [r15+0x50]
00007d3d13bd2304  lea r14, [rax+0x80]
00007d3d13bd230b  movups xmm1, [r13+r14*1]
00007d3d13bd2311  lea r14, [rax+0x90]
00007d3d13bd2318  movups xmm15, [r13+r14*1]
00007d3d13bd231e  vxorps xmm14, xmm14, xmm14
00007d3d13bd2323  vpbroadcastq xmm14, xmm14
00007d3d13bd2328  lea r14, [rax+0x40]
00007d3d13bd232c  movups xmm13, [r13+r14*1]
00007d3d13bd2332  lea r14, [rax+0x50]
00007d3d13bd2336  movups xmm12, [r13+r14*1]
00007d3d13bd233c  mov qword ptr [r15+0x48], 0x00
00007d3d13bd2344  movups xmm11, [r13+rax*1]
00007d3d13bd234a  lea r14, [rax+0x10]
00007d3d13bd234e  movups xmm10, [r13+r14*1]
00007d3d13bd2354  mov r14, [r15+0xF8]
00007d3d13bd235b  lea r12, [r14+0xE0]
00007d3d13bd2362  movups [r13+r12*1], xmm15
00007d3d13bd2368  lea r12, [r14+0xF0]
00007d3d13bd236f  movups [r13+r12*1], xmm1
00007d3d13bd2375  lea r12, [rax+0xC0]
00007d3d13bd237c  movups xmm1, [r13+r12*1]
00007d3d13bd2382  lea r12, [rax+0xD0]
00007d3d13bd2389  movups xmm15, [r13+r12*1]
00007d3d13bd238f  lea r12, [rax+0x140]
00007d3d13bd2396  movups xmm9, [r13+r12*1]
00007d3d13bd239c  lea r12, [rax+0x150]
00007d3d13bd23a3  movups xmm8, [r13+r12*1]
00007d3d13bd23a9  lea r12, [rax+0x180]
00007d3d13bd23b0  movups xmm7, [r13+r12*1]
00007d3d13bd23b6  lea r12, [rax+0x190]
00007d3d13bd23bd  movups xmm6, [r13+r12*1]
00007d3d13bd23c3  lea r12, [r14+0xC0]
00007d3d13bd23ca  movups [r13+r12*1], xmm15
00007d3d13bd23d0  lea r12, [r14+0xD0]
00007d3d13bd23d7  movups [r13+r12*1], xmm1
00007d3d13bd23dd  lea r12, [rax+0x100]
00007d3d13bd23e4  movups xmm1, [r13+r12*1]
00007d3d13bd23ea  lea r12, [rax+0x110]
00007d3d13bd23f1  movups xmm15, [r13+r12*1]
00007d3d13bd23f7  lea r12, [rax+0x1C0]
00007d3d13bd23fe  movups xmm5, [r13+r12*1]
00007d3d13bd2404  lea r12, [rax+0x1D0]
00007d3d13bd240b  movups xmm4, [r13+r12*1]
00007d3d13bd2411  lea r12, [rax+0x20]
00007d3d13bd2415  movups xmm3, [r13+r12*1]
00007d3d13bd241b  lea r12, [rax+0x30]
00007d3d13bd241f  movups xmm2, [r13+r12*1]
00007d3d13bd2425  movaps [r15+0x1F0], xmm2
00007d3d13bd242d  lea r12, [r14+0x20]
00007d3d13bd2431  movups [r13+r12*1], xmm1
00007d3d13bd2437  lea r12, [r14+0x30]
00007d3d13bd243b  movups [r13+r12*1], xmm12
00007d3d13bd2441  lea r12, [rax+0x60]
00007d3d13bd2445  movups xmm1, [r13+r12*1]
00007d3d13bd244b  lea r12, [rax+0x70]
00007d3d13bd244f  movups xmm12, [r13+r12*1]
00007d3d13bd2455  lea r12, [r14+0x60]
00007d3d13bd2459  movups [r13+r12*1], xmm11
00007d3d13bd245f  lea r12, [r14+0x70]
00007d3d13bd2463  movups [r13+r12*1], xmm5
00007d3d13bd2469  lea r12, [rax+0xE0]
00007d3d13bd2470  movups xmm11, [r13+r12*1]
00007d3d13bd2476  lea r12, [rax+0xF0]
00007d3d13bd247d  movups xmm5, [r13+r12*1]
00007d3d13bd2483  lea r12, [rax+0x120]
00007d3d13bd248a  vmovaps [rsp+0x10], xmm1
00007d3d13bd2490  movups xmm1, [r13+r12*1]
00007d3d13bd2496  lea r12, [rax+0x130]
00007d3d13bd249d  vmovaps [rsp+0x20], xmm1
00007d3d13bd24a3  movups xmm1, [r13+r12*1]
00007d3d13bd24a9  lea r12, [r14+0xA0]
00007d3d13bd24b0  movups [r13+r12*1], xmm12
00007d3d13bd24b6  lea r12, [r14+0xB0]
00007d3d13bd24bd  vmovaps xmm12, [rsp+0x10]
00007d3d13bd24c3  movups [r13+r12*1], xmm12
00007d3d13bd24c9  lea r12, [rax+0xA0]
00007d3d13bd24d0  movups xmm12, [r13+r12*1]
00007d3d13bd24d6  lea r12, [rax+0xB0]
00007d3d13bd24dd  vmovaps [rsp+0x10], xmm1
00007d3d13bd24e3  movups xmm1, [r13+r12*1]
00007d3d13bd24e9  lea r12, [rax+0x160]
00007d3d13bd24f0  vmovaps [rsp+0x30], xmm1
00007d3d13bd24f6  movups xmm1, [r13+r12*1]
00007d3d13bd24fc  lea r12, [rax+0x170]
00007d3d13bd2503  vmovaps [rsp+0x40], xmm1
00007d3d13bd2509  movups xmm1, [r13+r12*1]
00007d3d13bd250f  movaps [r15+0x2B0], xmm1
00007d3d13bd2517  lea r12, [rax+0x1A0]
00007d3d13bd251e  vmovaps [rsp+0x50], xmm1
00007d3d13bd2524  movups xmm1, [r13+r12*1]
00007d3d13bd252a  lea r12, [rax+0x1B0]
00007d3d13bd2531  vmovaps [rsp+0x60], xmm1
00007d3d13bd2537  movups xmm1, [r13+r12*1]
00007d3d13bd253d  vmovaps [rsp+0x70], xmm1
00007d3d13bd2543  vmovaps xmm1, [rsp+0x60]
00007d3d13bd2549  movaps [r15+0x290], xmm1
00007d3d13bd2551  vmovaps [rsp+0x60], xmm1
00007d3d13bd2557  vmovaps xmm1, [rsp+0x70]
00007d3d13bd255d  movaps [r15+0x1E0], xmm1
00007d3d13bd2565  lea r12, [r14+0x80]
00007d3d13bd256c  vmovaps [rsp+0x70], xmm1
00007d3d13bd2572  vmovaps xmm1, [rsp+0x30]
00007d3d13bd2578  movups [r13+r12*1], xmm1
00007d3d13bd257e  lea r12, [r14+0x90]
00007d3d13bd2585  movups [r13+r12*1], xmm12
00007d3d13bd258b  lea r12, [rax+0x1E0]
00007d3d13bd2592  movups xmm1, [r13+r12*1]
00007d3d13bd2598  lea r12, [rax+0x1F0]
00007d3d13bd259f  movups xmm12, [r13+r12*1]
00007d3d13bd25a5  mov qword ptr [r15+0x50], 0x432200
00007d3d13bd25ad  lea rax, [r14+0x40]
00007d3d13bd25b1  vmovaps [rsp+0x30], xmm1
00007d3d13bd25b7  vmovaps xmm1, [rsp+0x40]
00007d3d13bd25bd  movups [r13+rax*1], xmm1
00007d3d13bd25c3  lea rax, [r14+0x50]
00007d3d13bd25c7  movups [r13+rax*1], xmm10
00007d3d13bd25cd  movups [r13+r14*1], xmm12
00007d3d13bd25d3  lea rax, [r14+0x10]
00007d3d13bd25d7  vmovaps xmm1, [rsp+0x30]
00007d3d13bd25dd  movups [r13+rax*1], xmm1
00007d3d13bd25e3  mov rax, [r15+0x40]
00007d3d13bd25e7  vmovaps [rsp+0x30], xmm3
00007d3d13bd25ed  vmovaps xmm1, [rsp+0x30]
00007d3d13bd25f3  por xmm3, xmm1
00007d3d13bd25f7  vmovaps [rsp+0x30], xmm6
00007d3d13bd25fd  vmovaps xmm12, [rsp+0x30]
00007d3d13bd2603  por xmm6, xmm12
00007d3d13bd2608  lea r12, [rax+0x30]
00007d3d13bd260c  mov r11, [r13+r12*1]
00007d3d13bd2611  lea r12, [rax+0x38]
00007d3d13bd2615  mov r10, [r13+r12*1]
00007d3d13bd261a  movq xmm12, r11
00007d3d13bd261f  movq xmm10, r10
00007d3d13bd2624  movq xmm12, xmm12
00007d3d13bd2629  vmovaps [rsp+0x30], xmm12
00007d3d13bd262f  movq xmm12, xmm12
00007d3d13bd2634  movaps [r15+0x130], xmm12
00007d3d13bd263c  movq xmm10, xmm10
00007d3d13bd2641  vmovaps [rsp+0x40], xmm10
00007d3d13bd2647  movq xmm10, xmm10
00007d3d13bd264c  movaps [r15+0x280], xmm10
00007d3d13bd2654  vmovaps [rsp+0x80], xmm9
00007d3d13bd265d  vmovaps xmm12, [rsp+0x80]
00007d3d13bd2666  por xmm9, xmm12
00007d3d13bd266b  lea r12, [rax+0x20]
00007d3d13bd266f  mov r11, [r13+r12*1]
00007d3d13bd2674  lea r12, [rax+0x28]
00007d3d13bd2678  mov r10, [r13+r12*1]
00007d3d13bd267d  movq xmm12, r11
00007d3d13bd2682  movq xmm10, r10
00007d3d13bd2687  movq xmm12, xmm12
00007d3d13bd268c  vmovaps [rsp+0x80], xmm12
00007d3d13bd2695  movq xmm12, xmm12
00007d3d13bd269a  movaps [r15+0x150], xmm12
00007d3d13bd26a2  movq xmm10, xmm10
00007d3d13bd26a7  vmovaps [rsp+0x90], xmm10
00007d3d13bd26b0  movq xmm10, xmm10
00007d3d13bd26b5  movaps [r15+0x140], xmm10
00007d3d13bd26bd  lea r12, [rax+0x10]
00007d3d13bd26c1  mov r11, [r13+r12*1]
00007d3d13bd26c6  lea r12, [rax+0x18]
00007d3d13bd26ca  mov r10, [r13+r12*1]
00007d3d13bd26cf  movq xmm12, r11
00007d3d13bd26d4  movq xmm10, r10
00007d3d13bd26d9  movq xmm12, xmm12
00007d3d13bd26de  vmovaps [rsp+0xA0], xmm12
00007d3d13bd26e7  movq xmm12, xmm12
00007d3d13bd26ec  movaps [r15+0x170], xmm12
00007d3d13bd26f4  movq xmm10, xmm10
00007d3d13bd26f9  vmovaps [rsp+0xB0], xmm10
00007d3d13bd2702  movq xmm10, xmm10
00007d3d13bd2707  movaps [r15+0x160], xmm10
00007d3d13bd270f  mov r12, [r13+rax*1]
00007d3d13bd2714  vmovq xmm12, r12
00007d3d13bd2719  vpbroadcastq xmm12, xmm12
00007d3d13bd271e  lea r12, [rax+0x08]
00007d3d13bd2722  mov rax, [r13+r12*1]
00007d3d13bd2727  movq xmm10, rax
00007d3d13bd272c  movaps [r15+0x230], xmm10
00007d3d13bd2734  lea rax, [r14+0x50]
00007d3d13bd2738  movups xmm10, [r13+rax*1]
00007d3d13bd273e  lea rax, [r14+0x60]
00007d3d13bd2742  vmovaps [rsp+0xC0], xmm1
00007d3d13bd274b  movups xmm1, [r13+rax*1]
00007d3d13bd2751  lea rax, [r14+0x30]
00007d3d13bd2755  vmovaps [rsp+0xD0], xmm1
00007d3d13bd275e  movups xmm1, [r13+rax*1]
00007d3d13bd2764  mov qword ptr [r15+0x60], 0x432200
00007d3d13bd276c  mov qword ptr [r15+0x58], 0x40
00007d3d13bd2774  vmovaps [rsp+0xE0], xmm1
00007d3d13bd277d  vmovaps [rsp+0xF0], xmm15
00007d3d13bd2786  vmovaps xmm15, [rsp+0xC0]
00007d3d13bd278f  vmovaps [rsp+0xC0], xmm14
00007d3d13bd2798  movaps xmm1, xmm12
00007d3d13bd279c  mulpd xmm1, xmm15
00007d3d13bd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d13bd27a6  ptest xmm14, xmm14
00007d3d13bd27ac  jnz 0x00007D3D13BD3863
00007d3d13bd27b2  movq xmm15, qword ptr [r15+0x230]
00007d3d13bd27bb  vmovaps [rsp+0x100], xmm15
00007d3d13bd27c4  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd27ca  vmovaps [rsp+0x110], xmm1
00007d3d13bd27d3  vmovaps xmm1, [rsp+0xE0]
00007d3d13bd27dc  vmovaps [rsp+0xE0], xmm13
00007d3d13bd27e5  movaps xmm14, xmm1
00007d3d13bd27e9  mulpd xmm14, xmm15
00007d3d13bd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007d3d13bd27f4  ptest xmm13, xmm13
00007d3d13bd27fa  jnz 0x00007D3D13BD39A5
00007d3d13bd2800  vxorps xmm1, xmm1, xmm1
00007d3d13bd2804  vpbroadcastq xmm1, xmm1
00007d3d13bd2809  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd2812  vmovaps [rsp+0xD0], xmm1
00007d3d13bd281b  movaps xmm15, xmm12
00007d3d13bd281f  mulpd xmm15, xmm13
00007d3d13bd2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d13bd282a  ptest xmm1, xmm1
00007d3d13bd282f  jnz 0x00007D3D13BD3AE8
00007d3d13bd2835  movaps xmm1, xmm12
00007d3d13bd2839  mulpd xmm1, xmm10
00007d3d13bd283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007d3d13bd2843  ptest xmm13, xmm13
00007d3d13bd2849  jnz 0x00007D3D13BD3C2C
00007d3d13bd284f  movaps xmm13, xmm12
00007d3d13bd2853  mulpd xmm13, xmm2
00007d3d13bd2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007d3d13bd285e  ptest xmm10, xmm10
00007d3d13bd2864  jnz 0x00007D3D13BD3D6E
00007d3d13bd286a  vmovaps [rsp+0x120], xmm7
00007d3d13bd2873  vmovaps xmm12, [rsp+0x120]
00007d3d13bd287c  por xmm7, xmm12
00007d3d13bd2881  vmovaps xmm12, [rsp+0xE0]
00007d3d13bd288a  vmovaps xmm10, [rsp+0xE0]
00007d3d13bd2893  por xmm12, xmm10
00007d3d13bd2898  vmovaps xmm2, [rsp+0x100]
00007d3d13bd28a1  vpermilpd xmm2, xmm2, 0x00
00007d3d13bd28a7  vmovaps [rsp+0xE0], xmm1
00007d3d13bd28b0  vmovaps [rsp+0x120], xmm15
00007d3d13bd28b9  movaps xmm1, xmm10
00007d3d13bd28bd  mulpd xmm1, xmm2
00007d3d13bd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d13bd28c6  ptest xmm15, xmm15
00007d3d13bd28cc  jnz 0x00007D3D13BD3EB1
00007d3d13bd28d2  xor eax, eax
00007d3d13bd28d4  mov r12d, 0x40
00007d3d13bd28da  mov r11d, 0x200
00007d3d13bd28e0  cmp r12, r11
00007d3d13bd28e3  cmc
00007d3d13bd28e4  lahf
00007d3d13bd28e5  seto al
00007d3d13bd28e8  mov [r15+0x108], eax
00007d3d13bd28ef  vmovaps xmm10, [rsp+0x110]
00007d3d13bd28f8  vmovaps xmm2, [rsp+0xD0]
00007d3d13bd2901  vmovaps [rsp+0xD0], xmm1
00007d3d13bd290a  movaps xmm15, xmm10
00007d3d13bd290e  addpd xmm15, xmm2
00007d3d13bd2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d13bd2919  ptest xmm1, xmm1
00007d3d13bd291e  jnz 0x00007D3D13BD3FF2
00007d3d13bd2924  vmovaps xmm10, [rsp+0x120]
00007d3d13bd292d  vmovaps [rsp+0x110], xmm15
00007d3d13bd2936  vmovaps xmm15, [rsp+0xC0]
00007d3d13bd293f  vmovaps [rsp+0xC0], xmm14
00007d3d13bd2948  movaps xmm1, xmm10
00007d3d13bd294c  addpd xmm1, xmm15
00007d3d13bd2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d13bd2956  ptest xmm14, xmm14
00007d3d13bd295c  jnz 0x00007D3D13BD4135
00007d3d13bd2962  vmovaps xmm10, [rsp+0xE0]
00007d3d13bd296b  vmovaps [rsp+0xE0], xmm1
00007d3d13bd2974  movaps xmm14, xmm10
00007d3d13bd2978  addpd xmm14, xmm15
00007d3d13bd297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007d3d13bd2983  ptest xmm1, xmm1
00007d3d13bd2988  jnz 0x00007D3D13BD4277
00007d3d13bd298e  vmovaps xmm1, [rsp+0x10]
00007d3d13bd2994  vmovaps xmm15, [rsp+0x10]
00007d3d13bd299a  por xmm1, xmm15
00007d3d13bd299f  vmovaps xmm15, [rsp+0x20]
00007d3d13bd29a5  vmovaps xmm10, [rsp+0x20]
00007d3d13bd29ab  por xmm15, xmm10
00007d3d13bd29b0  vmovaps [rsp+0x10], xmm5
00007d3d13bd29b6  vmovaps xmm10, [rsp+0x10]
00007d3d13bd29bc  por xmm5, xmm10
00007d3d13bd29c1  vmovaps [rsp+0x10], xmm11
00007d3d13bd29c7  vmovaps xmm10, [rsp+0x10]
00007d3d13bd29cd  por xmm11, xmm10
00007d3d13bd29d2  vmovaps [rsp+0x10], xmm4
00007d3d13bd29d8  vmovaps xmm10, [rsp+0x10]
00007d3d13bd29de  por xmm4, xmm10
00007d3d13bd29e3  vmovaps [rsp+0x10], xmm8
00007d3d13bd29e9  vmovaps xmm10, [rsp+0x10]
00007d3d13bd29ef  por xmm8, xmm10
00007d3d13bd29f4  vmovaps xmm10, [rsp+0xF0]
00007d3d13bd29fd  vmovaps [rsp+0x10], xmm1
00007d3d13bd2a03  vmovaps xmm1, [rsp+0xF0]
00007d3d13bd2a0c  por xmm10, xmm1
00007d3d13bd2a11  lea rax, [r14+0xA0]
00007d3d13bd2a18  movups xmm1, [r13+rax*1]
00007d3d13bd2a1e  lea rax, [r14+0xB0]
00007d3d13bd2a25  vmovaps [rsp+0x20], xmm1
00007d3d13bd2a2b  movups xmm1, [r13+rax*1]
00007d3d13bd2a31  vmovaps [rsp+0xF0], xmm1
00007d3d13bd2a3a  vmovaps [rsp+0x120], xmm15
00007d3d13bd2a43  movaps xmm1, xmm13
00007d3d13bd2a47  addpd xmm1, xmm2
00007d3d13bd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d13bd2a50  ptest xmm15, xmm15
00007d3d13bd2a56  jnz 0x00007D3D13BD43CF
00007d3d13bd2a5c  lea rax, [r14+0xF0]
00007d3d13bd2a63  movups xmm15, [r13+rax*1]
00007d3d13bd2a69  vmovaps xmm2, [rsp+0xE0]
00007d3d13bd2a72  vmovaps [rsp+0xE0], xmm1
00007d3d13bd2a7b  vmovaps xmm1, [rsp+0xD0]
00007d3d13bd2a84  vmovaps [rsp+0xD0], xmm15
00007d3d13bd2a8d  movaps xmm13, xmm2
00007d3d13bd2a91  addpd xmm13, xmm1
00007d3d13bd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007d3d13bd2a9c  ptest xmm15, xmm15
00007d3d13bd2aa2  jnz 0x00007D3D13BD451A
00007d3d13bd2aa8  vmovaps xmm15, [rsp+0xC0]
00007d3d13bd2ab1  movaps xmm1, xmm14
00007d3d13bd2ab5  addpd xmm1, xmm15
00007d3d13bd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d13bd2abf  ptest xmm2, xmm2
00007d3d13bd2ac4  jnz 0x00007D3D13BD465C
00007d3d13bd2aca  vmovaps xmm15, [rsp+0x100]
00007d3d13bd2ad3  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd2ad9  vmovaps xmm2, [rsp+0xF0]
00007d3d13bd2ae2  vmovaps [rsp+0xC0], xmm1
00007d3d13bd2aeb  movaps xmm14, xmm2
00007d3d13bd2aef  mulpd xmm14, xmm15
00007d3d13bd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007d3d13bd2afa  ptest xmm1, xmm1
00007d3d13bd2aff  jnz 0x00007D3D13BD479E
00007d3d13bd2b05  vmovaps xmm1, [rsp+0xA0]
00007d3d13bd2b0e  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd2b14  vmovaps xmm2, [rsp+0xD0]
00007d3d13bd2b1d  vmovaps [rsp+0xD0], xmm14
00007d3d13bd2b26  movaps xmm15, xmm2
00007d3d13bd2b2a  mulpd xmm15, xmm1
00007d3d13bd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007d3d13bd2b35  ptest xmm14, xmm14
00007d3d13bd2b3b  jnz 0x00007D3D13BD48E1
00007d3d13bd2b41  lea rax, [r14+0xE0]
00007d3d13bd2b48  movups xmm1, [r13+rax*1]
00007d3d13bd2b4e  vmovaps xmm14, [rsp+0x100]
00007d3d13bd2b57  vpermilpd xmm14, xmm14, 0x00
00007d3d13bd2b5d  vmovaps [rsp+0xF0], xmm1
00007d3d13bd2b66  vmovaps xmm1, [rsp+0x20]
00007d3d13bd2b6c  vmovaps [rsp+0x20], xmm15
00007d3d13bd2b72  movaps xmm2, xmm1
00007d3d13bd2b75  mulpd xmm2, xmm14
00007d3d13bd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d3d13bd2b7f  ptest xmm15, xmm15
00007d3d13bd2b85  jnz 0x00007D3D13BD4A2D
00007d3d13bd2b8b  vmovaps [rsp+0x100], xmm10
00007d3d13bd2b94  vmovaps xmm1, [rsp+0x100]
00007d3d13bd2b9d  por xmm10, xmm1
00007d3d13bd2ba2  movaps [r15+0x300], xmm10
00007d3d13bd2baa  vmovaps [rsp+0x100], xmm8
00007d3d13bd2bb3  vmovaps xmm1, [rsp+0x100]
00007d3d13bd2bbc  por xmm8, xmm1
00007d3d13bd2bc1  movaps [r15+0x190], xmm8
00007d3d13bd2bc9  vmovaps xmm1, [rsp+0xA0]
00007d3d13bd2bd2  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd2bd8  vmovaps xmm14, [rsp+0xF0]
00007d3d13bd2be1  vmovaps [rsp+0xF0], xmm13
00007d3d13bd2bea  movaps xmm15, xmm14
00007d3d13bd2bee  mulpd xmm15, xmm1
00007d3d13bd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007d3d13bd2bf9  ptest xmm13, xmm13
00007d3d13bd2bff  jnz 0x00007D3D13BD4B6E
00007d3d13bd2c05  lea rax, [r14+0x90]
00007d3d13bd2c0c  movups xmm1, [r13+rax*1]
00007d3d13bd2c12  vmovaps [rsp+0x100], xmm4
00007d3d13bd2c1b  vmovaps xmm14, [rsp+0x100]
00007d3d13bd2c24  por xmm4, xmm14
00007d3d13bd2c29  movaps [r15+0x1C0], xmm4
00007d3d13bd2c31  vmovaps [rsp+0x100], xmm11
00007d3d13bd2c3a  vmovaps xmm14, [rsp+0x100]
00007d3d13bd2c43  por xmm11, xmm14
00007d3d13bd2c48  movaps [r15+0x200], xmm11
00007d3d13bd2c50  vmovaps [rsp+0x100], xmm5
00007d3d13bd2c59  vmovaps xmm14, [rsp+0x100]
00007d3d13bd2c62  por xmm5, xmm14
00007d3d13bd2c67  movaps [r15+0x2D0], xmm5
00007d3d13bd2c6f  vmovaps xmm14, [rsp+0x120]
00007d3d13bd2c78  vmovaps xmm13, [rsp+0x120]
00007d3d13bd2c81  por xmm14, xmm13
00007d3d13bd2c86  movaps [r15+0x2E0], xmm14
00007d3d13bd2c8e  vmovaps [rsp+0x100], xmm1
00007d3d13bd2c97  vmovaps xmm1, [rsp+0x110]
00007d3d13bd2ca0  vmovaps [rsp+0x110], xmm15
00007d3d13bd2ca9  vmovaps xmm15, [rsp+0xD0]
00007d3d13bd2cb2  vmovaps [rsp+0xD0], xmm14
00007d3d13bd2cbb  movaps xmm13, xmm1
00007d3d13bd2cbf  addpd xmm13, xmm15
00007d3d13bd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007d3d13bd2cca  ptest xmm14, xmm14
00007d3d13bd2cd0  jnz 0x00007D3D13BD4CBB
00007d3d13bd2cd6  vmovaps xmm1, [rsp+0xA0]
00007d3d13bd2cdf  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd2ce5  vmovaps xmm14, [rsp+0x100]
00007d3d13bd2cee  vmovaps [rsp+0x100], xmm13
00007d3d13bd2cf7  movaps xmm15, xmm14
00007d3d13bd2cfb  mulpd xmm15, xmm1
00007d3d13bd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007d3d13bd2d06  ptest xmm13, xmm13
00007d3d13bd2d0c  jnz 0x00007D3D13BD4DFE
00007d3d13bd2d12  lea rax, [r14+0x80]
00007d3d13bd2d19  movups xmm1, [r13+rax*1]
00007d3d13bd2d1f  vmovaps xmm13, [rsp+0xE0]
00007d3d13bd2d28  vmovaps [rsp+0xE0], xmm1
00007d3d13bd2d31  movaps xmm14, xmm13
00007d3d13bd2d35  addpd xmm14, xmm2
00007d3d13bd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007d3d13bd2d40  ptest xmm1, xmm1
00007d3d13bd2d45  jnz 0x00007D3D13BD4F4B
00007d3d13bd2d4b  vmovaps xmm13, [rsp+0xF0]
00007d3d13bd2d54  vmovaps xmm2, [rsp+0x20]
00007d3d13bd2d5a  vmovaps [rsp+0x20], xmm15
00007d3d13bd2d60  movaps xmm1, xmm13
00007d3d13bd2d64  addpd xmm1, xmm2
00007d3d13bd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d13bd2d6d  ptest xmm15, xmm15
00007d3d13bd2d73  jnz 0x00007D3D13BD508E
00007d3d13bd2d79  vmovaps xmm15, [rsp+0x10]
00007d3d13bd2d7f  vmovaps xmm13, [rsp+0x10]
00007d3d13bd2d85  por xmm15, xmm13
00007d3d13bd2d8a  movaps [r15+0x2F0], xmm15
00007d3d13bd2d92  vmovaps xmm13, [rsp+0xA0]
00007d3d13bd2d9b  vpermilpd xmm13, xmm13, 0x00
00007d3d13bd2da1  vmovaps [rsp+0x10], xmm1
00007d3d13bd2da7  vmovaps xmm1, [rsp+0xE0]
00007d3d13bd2db0  vmovaps [rsp+0xA0], xmm15
00007d3d13bd2db9  movaps xmm2, xmm1
00007d3d13bd2dbc  mulpd xmm2, xmm13
00007d3d13bd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007d3d13bd2dc6  ptest xmm15, xmm15
00007d3d13bd2dcc  jnz 0x00007D3D13BD51CF
00007d3d13bd2dd2  lea rax, [r14+0xD0]
00007d3d13bd2dd9  movups xmm1, [r13+rax*1]
00007d3d13bd2ddf  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd2de8  vmovaps [rsp+0xC0], xmm1
00007d3d13bd2df1  vmovaps xmm1, [rsp+0x110]
00007d3d13bd2dfa  vmovaps [rsp+0xE0], xmm14
00007d3d13bd2e03  movaps xmm15, xmm13
00007d3d13bd2e07  addpd xmm15, xmm1
00007d3d13bd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007d3d13bd2e12  ptest xmm14, xmm14
00007d3d13bd2e18  jnz 0x00007D3D13BD531A
00007d3d13bd2e1e  vmovaps xmm1, [rsp+0xB0]
00007d3d13bd2e27  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd2e2d  movaps xmm14, xmm11
00007d3d13bd2e31  mulpd xmm14, xmm1
00007d3d13bd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007d3d13bd2e3c  ptest xmm13, xmm13
00007d3d13bd2e42  jnz 0x00007D3D13BD545D
00007d3d13bd2e48  movaps [r15+0x260], xmm14
00007d3d13bd2e50  vxorps xmm1, xmm1, xmm1
00007d3d13bd2e54  vpbroadcastq xmm1, xmm1
00007d3d13bd2e59  movaps [r15+0x1B0], xmm1
00007d3d13bd2e61  vmovaps xmm1, [rsp+0xB0]
00007d3d13bd2e6a  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd2e70  vmovaps xmm11, [rsp+0xC0]
00007d3d13bd2e79  vmovaps [rsp+0xC0], xmm15
00007d3d13bd2e82  movaps xmm13, xmm11
00007d3d13bd2e86  mulpd xmm13, xmm1
00007d3d13bd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007d3d13bd2e91  ptest xmm15, xmm15
00007d3d13bd2e97  jnz 0x00007D3D13BD55A0
00007d3d13bd2e9d  lea rax, [r14+0xC0]
00007d3d13bd2ea4  movups xmm1, [r13+rax*1]
00007d3d13bd2eaa  vmovaps xmm11, [rsp+0x100]
00007d3d13bd2eb3  vmovaps [rsp+0xF0], xmm1
00007d3d13bd2ebc  vmovaps xmm1, [rsp+0x20]
00007d3d13bd2ec2  vmovaps [rsp+0x20], xmm14
00007d3d13bd2ec8  movaps xmm15, xmm11
00007d3d13bd2ecc  addpd xmm15, xmm1
00007d3d13bd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007d3d13bd2ed7  ptest xmm14, xmm14
00007d3d13bd2edd  jnz 0x00007D3D13BD56ED
00007d3d13bd2ee3  vmovaps [rsp+0x100], xmm9
00007d3d13bd2eec  vmovaps xmm1, [rsp+0x100]
00007d3d13bd2ef5  por xmm9, xmm1
00007d3d13bd2efa  movaps [r15+0x270], xmm9
00007d3d13bd2f02  vmovaps [rsp+0x100], xmm6
00007d3d13bd2f0b  vmovaps xmm1, [rsp+0x100]
00007d3d13bd2f14  por xmm6, xmm1
00007d3d13bd2f18  movaps [r15+0x1A0], xmm6
00007d3d13bd2f20  vmovaps xmm14, [rsp+0xB0]
00007d3d13bd2f29  vpermilpd xmm14, xmm14, 0x00
00007d3d13bd2f2f  vmovaps xmm6, [rsp+0xF0]
00007d3d13bd2f38  vmovaps [rsp+0xF0], xmm1
00007d3d13bd2f41  movaps xmm11, xmm6
00007d3d13bd2f45  mulpd xmm11, xmm14
00007d3d13bd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007d3d13bd2f50  ptest xmm1, xmm1
00007d3d13bd2f55  jnz 0x00007D3D13BD5830
00007d3d13bd2f5b  lea rax, [r14+0x20]
00007d3d13bd2f5f  movups xmm1, [r13+rax*1]
00007d3d13bd2f65  movaps [r15+0x110], xmm1
00007d3d13bd2f6d  vmovaps xmm6, [rsp+0xE0]
00007d3d13bd2f76  vmovaps [rsp+0xE0], xmm1
00007d3d13bd2f7f  movaps xmm14, xmm6
00007d3d13bd2f83  addpd xmm14, xmm2
00007d3d13bd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007d3d13bd2f8e  ptest xmm1, xmm1
00007d3d13bd2f93  jnz 0x00007D3D13BD597D
00007d3d13bd2f99  vmovaps xmm1, [rsp+0xB0]
00007d3d13bd2fa2  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd2fa8  movaps xmm6, xmm5
00007d3d13bd2fab  mulpd xmm6, xmm1
00007d3d13bd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007d3d13bd2fb4  ptest xmm2, xmm2
00007d3d13bd2fb9  jnz 0x00007D3D13BD5ABF
00007d3d13bd2fbf  vmovaps xmm5, [rsp+0x10]
00007d3d13bd2fc5  movaps xmm1, xmm5
00007d3d13bd2fc8  addpd xmm1, xmm13
00007d3d13bd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d13bd2fd2  ptest xmm2, xmm2
00007d3d13bd2fd7  jnz 0x00007D3D13BD5BFF
00007d3d13bd2fdd  vmovaps xmm13, [rsp+0x80]
00007d3d13bd2fe6  vpermilpd xmm13, xmm13, 0x00
00007d3d13bd2fec  vmovaps xmm2, [rsp+0xE0]
00007d3d13bd2ff5  vmovaps [rsp+0x10], xmm1
00007d3d13bd2ffb  movaps xmm5, xmm2
00007d3d13bd2ffe  mulpd xmm5, xmm13
00007d3d13bd3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007d3d13bd3008  ptest xmm1, xmm1
00007d3d13bd300d  jnz 0x00007D3D13BD5D40
00007d3d13bd3013  vmovaps xmm1, [rsp+0x80]
00007d3d13bd301c  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd3022  movaps xmm13, xmm10
00007d3d13bd3026  mulpd xmm13, xmm1
00007d3d13bd302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007d3d13bd3031  ptest xmm2, xmm2
00007d3d13bd3036  jnz 0x00007D3D13BD5E81
00007d3d13bd303c  vmovaps xmm10, [rsp+0x20]
00007d3d13bd3042  movaps xmm1, xmm15
00007d3d13bd3046  addpd xmm1, xmm10
00007d3d13bd304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d13bd3050  ptest xmm2, xmm2
00007d3d13bd3055  jnz 0x00007D3D13BD5FC4
00007d3d13bd305b  vmovaps xmm10, [rsp+0xC0]
00007d3d13bd3064  movaps xmm15, xmm10
00007d3d13bd3068  addpd xmm15, xmm11
00007d3d13bd306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007d3d13bd3073  ptest xmm2, xmm2
00007d3d13bd3078  jnz 0x00007D3D13BD6106
00007d3d13bd307e  vmovaps xmm11, [rsp+0x80]
00007d3d13bd3087  vpermilpd xmm11, xmm11, 0x00
00007d3d13bd308d  vmovaps xmm2, [rsp+0xD0]
00007d3d13bd3096  vmovaps [rsp+0x20], xmm1
00007d3d13bd309c  movaps xmm10, xmm2
00007d3d13bd30a0  mulpd xmm10, xmm11
00007d3d13bd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007d3d13bd30ab  ptest xmm1, xmm1
00007d3d13bd30b0  jnz 0x00007D3D13BD624A
00007d3d13bd30b6  vmovaps xmm1, [rsp+0x80]
00007d3d13bd30bf  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd30c5  vmovaps xmm2, [rsp+0xA0]
00007d3d13bd30ce  vmovaps [rsp+0x80], xmm15
00007d3d13bd30d7  movaps xmm11, xmm2
00007d3d13bd30db  mulpd xmm11, xmm1
00007d3d13bd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007d3d13bd30e6  ptest xmm15, xmm15
00007d3d13bd30ec  jnz 0x00007D3D13BD638D
00007d3d13bd30f2  movaps xmm1, xmm14
00007d3d13bd30f6  addpd xmm1, xmm6
00007d3d13bd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d13bd30ff  ptest xmm15, xmm15
00007d3d13bd3105  jnz 0x00007D3D13BD64CF
00007d3d13bd310b  vmovaps xmm14, [rsp+0x10]
00007d3d13bd3111  movaps xmm15, xmm14
00007d3d13bd3115  addpd xmm15, xmm5
00007d3d13bd311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007d3d13bd3120  ptest xmm6, xmm6
00007d3d13bd3125  jnz 0x00007D3D13BD6610
00007d3d13bd312b  vmovaps xmm14, [rsp+0x90]
00007d3d13bd3134  vpermilpd xmm14, xmm14, 0x00
00007d3d13bd313a  movaps xmm6, xmm9
00007d3d13bd313e  mulpd xmm6, xmm14
00007d3d13bd3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d13bd3148  ptest xmm5, xmm5
00007d3d13bd314d  jnz 0x00007D3D13BD6753
00007d3d13bd3153  vmovaps xmm9, [rsp+0x80]
00007d3d13bd315c  movaps xmm14, xmm9
00007d3d13bd3160  addpd xmm14, xmm13
00007d3d13bd3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007d3d13bd316b  ptest xmm5, xmm5
00007d3d13bd3170  jnz 0x00007D3D13BD6895
00007d3d13bd3176  vmovaps xmm9, [rsp+0x20]
00007d3d13bd317c  movaps xmm13, xmm9
00007d3d13bd3180  addpd xmm13, xmm10
00007d3d13bd3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007d3d13bd318b  ptest xmm5, xmm5
00007d3d13bd3190  jnz 0x00007D3D13BD69D9
00007d3d13bd3196  vmovaps [rsp+0x10], xmm12
00007d3d13bd319c  vmovaps xmm10, [rsp+0x10]
00007d3d13bd31a2  por xmm12, xmm10
00007d3d13bd31a7  movaps [r15+0x250], xmm12
00007d3d13bd31af  vmovaps [rsp+0x10], xmm7
00007d3d13bd31b5  vmovaps xmm12, [rsp+0x10]
00007d3d13bd31bb  por xmm7, xmm12
00007d3d13bd31c0  movaps [r15+0x2A0], xmm7
00007d3d13bd31c8  vmovaps [rsp+0x10], xmm3
00007d3d13bd31ce  vmovaps xmm12, [rsp+0x10]
00007d3d13bd31d4  por xmm3, xmm12
00007d3d13bd31d9  movaps [r15+0x1D0], xmm3
00007d3d13bd31e1  lea rax, [r14+0x40]
00007d3d13bd31e5  movups xmm12, [r13+rax*1]
00007d3d13bd31eb  movaps [r15+0x2C0], xmm12
00007d3d13bd31f3  vmovaps xmm10, [rsp+0x90]
00007d3d13bd31fc  vpermilpd xmm10, xmm10, 0x00
00007d3d13bd3202  movaps xmm9, xmm8
00007d3d13bd3206  mulpd xmm9, xmm10
00007d3d13bd320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007d3d13bd3211  ptest xmm5, xmm5
00007d3d13bd3216  jnz 0x00007D3D13BD6B27
00007d3d13bd321c  movaps xmm10, xmm1
00007d3d13bd3220  addpd xmm10, xmm11
00007d3d13bd3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007d3d13bd322b  ptest xmm8, xmm8
00007d3d13bd3231  jnz 0x00007D3D13BD6C6B
00007d3d13bd3237  movaps xmm1, xmm15
00007d3d13bd323b  addpd xmm1, xmm6
00007d3d13bd323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007d3d13bd3244  ptest xmm11, xmm11
00007d3d13bd324a  jnz 0x00007D3D13BD6DAE
00007d3d13bd3250  vmovaps xmm15, [rsp+0x90]
00007d3d13bd3259  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd325f  movaps xmm11, xmm12
00007d3d13bd3263  mulpd xmm11, xmm15
00007d3d13bd3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007d3d13bd326e  ptest xmm8, xmm8
00007d3d13bd3274  jnz 0x00007D3D13BD6EEF
00007d3d13bd327a  vmovaps xmm15, [rsp+0x90]
00007d3d13bd3283  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd3289  vmovaps xmm8, [rsp+0x50]
00007d3d13bd328f  movaps xmm12, xmm8
00007d3d13bd3293  mulpd xmm12, xmm15
00007d3d13bd3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007d3d13bd329e  ptest xmm6, xmm6
00007d3d13bd32a3  jnz 0x00007D3D13BD7033
00007d3d13bd32a9  vmovaps xmm15, [rsp+0x30]
00007d3d13bd32af  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd32b5  movaps xmm8, xmm7
00007d3d13bd32b9  mulpd xmm8, xmm15
00007d3d13bd32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d13bd32c4  ptest xmm6, xmm6
00007d3d13bd32c9  jnz 0x00007D3D13BD7177
00007d3d13bd32cf  movaps xmm15, xmm14
00007d3d13bd32d3  addpd xmm15, xmm9
00007d3d13bd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007d3d13bd32de  ptest xmm7, xmm7
00007d3d13bd32e3  jnz 0x00007D3D13BD72BA
00007d3d13bd32e9  vmovaps xmm14, [rsp+0x30]
00007d3d13bd32ef  vpermilpd xmm14, xmm14, 0x00
00007d3d13bd32f5  vmovaps xmm7, [rsp+0xF0]
00007d3d13bd32fe  movaps xmm9, xmm7
00007d3d13bd3302  mulpd xmm9, xmm14
00007d3d13bd3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d13bd330d  ptest xmm6, xmm6
00007d3d13bd3312  jnz 0x00007D3D13BD73FE
00007d3d13bd3318  movaps xmm14, xmm13
00007d3d13bd331c  addpd xmm14, xmm11
00007d3d13bd3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007d3d13bd3327  ptest xmm7, xmm7
00007d3d13bd332c  jnz 0x00007D3D13BD7541
00007d3d13bd3332  vmovaps xmm13, [rsp+0x30]
00007d3d13bd3338  vpermilpd xmm13, xmm13, 0x00
00007d3d13bd333e  vmovaps xmm7, [rsp+0x60]
00007d3d13bd3344  movaps xmm11, xmm7
00007d3d13bd3348  mulpd xmm11, xmm13
00007d3d13bd334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007d3d13bd3353  ptest xmm6, xmm6
00007d3d13bd3358  jnz 0x00007D3D13BD7685
00007d3d13bd335e  movaps xmm13, xmm10
00007d3d13bd3362  addpd xmm13, xmm12
00007d3d13bd3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007d3d13bd336d  ptest xmm7, xmm7
00007d3d13bd3372  jnz 0x00007D3D13BD77C8
00007d3d13bd3378  vmovaps xmm12, [rsp+0x30]
00007d3d13bd337e  vpermilpd xmm12, xmm12, 0x00
00007d3d13bd3384  vmovaps xmm7, [rsp+0x70]
00007d3d13bd338a  movaps xmm10, xmm7
00007d3d13bd338e  mulpd xmm10, xmm12
00007d3d13bd3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007d3d13bd3399  ptest xmm6, xmm6
00007d3d13bd339e  jnz 0x00007D3D13BD790C
00007d3d13bd33a4  movaps xmm12, xmm1
00007d3d13bd33a8  addpd xmm12, xmm8
00007d3d13bd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007d3d13bd33b3  ptest xmm7, xmm7
00007d3d13bd33b8  jnz 0x00007D3D13BD7A4F
00007d3d13bd33be  lea rax, [r14+0x70]
00007d3d13bd33c2  movups xmm1, [r13+rax*1]
00007d3d13bd33c8  movaps [r15+0x240], xmm1
00007d3d13bd33d0  movaps xmm8, xmm15
00007d3d13bd33d4  addpd xmm8, xmm9
00007d3d13bd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d13bd33df  ptest xmm7, xmm7
00007d3d13bd33e4  jnz 0x00007D3D13BD7B9C
00007d3d13bd33ea  movaps [r15+0x170], xmm8
00007d3d13bd33f2  vmovaps xmm15, [rsp+0x40]
00007d3d13bd33f8  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd33fe  movaps xmm9, xmm1
00007d3d13bd3402  mulpd xmm9, xmm15
00007d3d13bd3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007d3d13bd340d  ptest xmm7, xmm7
00007d3d13bd3412  jnz 0x00007D3D13BD7CE0
00007d3d13bd3418  vmovaps xmm1, [rsp+0x40]
00007d3d13bd341e  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd3424  movaps xmm15, xmm4
00007d3d13bd3428  mulpd xmm15, xmm1
00007d3d13bd342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007d3d13bd3433  ptest xmm7, xmm7
00007d3d13bd3438  jnz 0x00007D3D13BD7E23
00007d3d13bd343e  movaps [r15+0x180], xmm15
00007d3d13bd3446  movaps xmm1, xmm14
00007d3d13bd344a  addpd xmm1, xmm11
00007d3d13bd344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007d3d13bd3454  ptest xmm7, xmm7
00007d3d13bd3459  jnz 0x00007D3D13BD7F65
00007d3d13bd345f  movaps [r15+0x210], xmm1
00007d3d13bd3467  movups xmm14, [r13+r14*1]
00007d3d13bd346d  lea rax, [r14+0x10]
00007d3d13bd3471  movups xmm11, [r13+rax*1]
00007d3d13bd3477  movaps [r15+0x230], xmm11
00007d3d13bd347f  movaps xmm7, xmm13
00007d3d13bd3483  addpd xmm7, xmm10
00007d3d13bd3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d13bd348d  ptest xmm6, xmm6
00007d3d13bd3492  jnz 0x00007D3D13BD80BB
00007d3d13bd3498  movaps [r15+0x130], xmm7
00007d3d13bd34a0  vmovaps xmm13, [rsp+0x40]
00007d3d13bd34a6  vpermilpd xmm13, xmm13, 0x00
00007d3d13bd34ac  movaps xmm10, xmm11
00007d3d13bd34b0  mulpd xmm10, xmm13
00007d3d13bd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d3d13bd34bb  ptest xmm6, xmm6
00007d3d13bd34c0  jnz 0x00007D3D13BD81FD
00007d3d13bd34c6  movaps [r15+0x220], xmm10
00007d3d13bd34ce  vmovaps xmm13, [rsp+0x40]
00007d3d13bd34d4  vpermilpd xmm13, xmm13, 0x00
00007d3d13bd34da  movaps xmm11, xmm14
00007d3d13bd34de  mulpd xmm11, xmm13
00007d3d13bd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007d3d13bd34e9  ptest xmm6, xmm6
00007d3d13bd34ee  jnz 0x00007D3D13BD8341
00007d3d13bd34f4  movaps xmm14, xmm12
00007d3d13bd34f8  addpd xmm14, xmm9
00007d3d13bd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007d3d13bd3503  ptest xmm13, xmm13
00007d3d13bd3509  jnz 0x00007D3D13BD8485
00007d3d13bd350f  movaps [r15+0x140], xmm14
00007d3d13bd3517  movaps xmm13, xmm8
00007d3d13bd351b  addpd xmm13, xmm15
00007d3d13bd3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007d3d13bd3526  ptest xmm12, xmm12
00007d3d13bd352c  jnz 0x00007D3D13BD85C9
00007d3d13bd3532  movaps [r15+0x150], xmm13
00007d3d13bd353a  movaps xmm15, xmm1
00007d3d13bd353e  addpd xmm15, xmm10
00007d3d13bd3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007d3d13bd3549  ptest xmm12, xmm12
00007d3d13bd354f  jnz 0x00007D3D13BD870D
00007d3d13bd3555  movaps [r15+0x160], xmm15
00007d3d13bd355d  movaps xmm1, xmm7
00007d3d13bd3560  addpd xmm1, xmm11
00007d3d13bd3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d13bd356a  ptest xmm12, xmm12
00007d3d13bd3570  jnz 0x00007D3D13BD8850
00007d3d13bd3576  movaps [r15+0x120], xmm1
00007d3d13bd357e  mov eax, 0x432200
00007d3d13bd3583  movups [r13+rax*1], xmm14
00007d3d13bd3589  mov eax, 0x432210
00007d3d13bd358e  movups [r13+rax*1], xmm13
00007d3d13bd3594  mov eax, 0x432220
00007d3d13bd3599  movups [r13+rax*1], xmm15
00007d3d13bd359f  mov eax, 0x432230
00007d3d13bd35a4  movups [r13+rax*1], xmm1
00007d3d13bd35aa  mov eax, [r15+0x108]
00007d3d13bd35b1  sahf
00007d3d13bd35b2  jnz 0x00007D3D13BD35E4
00007d3d13bd35b4  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd35bc  jz 0x00007D3D13BDEAE0
00007d3d13bd35c2  nop [rax+rax*1], ax
00007d3d13bd35cb  nop [rax+rax*1], eax
00007d3d13bd35d3  mov eax, 0x4106D0
00007d3d13bd35d8  mov [r15+0x100], rax
00007d3d13bd35df  jmp 0x00007D3D139FE110
00007d3d13bd35e4  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd35ec  jz 0x00007D3D13BD89C0
00007d3d13bd35f2  nop [rax+rax*1], ax
00007d3d13bd35fb  nop [rax+rax*1], eax
00007d3d13bd3603  mov eax, 0x410504
00007d3d13bd3608  mov [r15+0x100], rax
00007d3d13bd360f  jmp 0x00007D3D139FE110
00007d3d13bd3614  int3
00007d3d13bd3615  call 0x00007D3D13AD64F0
00007d3d13bd361a  jmp 0x00007D3D13BD2311
00007d3d13bd361f  call 0x00007D3D13AE5820
00007d3d13bd3624  jmp 0x00007D3D13BD231E
00007d3d13bd3629  call 0x00007D3D13AE3320
00007d3d13bd362e  jmp 0x00007D3D13BD2332
00007d3d13bd3633  call 0x00007D3D13AE20A0
00007d3d13bd3638  jmp 0x00007D3D13BD233C
00007d3d13bd363d  call 0x00007D3D13A09D70
00007d3d13bd3642  jmp 0x00007D3D13BD234A
00007d3d13bd3647  call 0x00007D3D13ADFBC0
00007d3d13bd364c  jmp 0x00007D3D13BD2354
00007d3d13bd3651  call 0x00007D3D13AC4740
00007d3d13bd3656  jmp 0x00007D3D13BD2368
00007d3d13bd365b  call 0x00007D3D13AB5400
00007d3d13bd3660  jmp 0x00007D3D13BD2375
00007d3d13bd3665  call 0x00007D3D13AB52F0
00007d3d13bd366a  jmp 0x00007D3D13BD2382
00007d3d13bd366f  call 0x00007D3D13AC4620
00007d3d13bd3674  jmp 0x00007D3D13BD238F
00007d3d13bd3679  call 0x00007D3D13ABD750
00007d3d13bd367e  jmp 0x00007D3D13BD239C
00007d3d13bd3683  call 0x00007D3D13ABC4E0
00007d3d13bd3688  jmp 0x00007D3D13BD23A9
00007d3d13bd368d  call 0x00007D3D13ABB270
00007d3d13bd3692  jmp 0x00007D3D13BD23B6
00007d3d13bd3697  call 0x00007D3D13ABA000
00007d3d13bd369c  jmp 0x00007D3D13BD23C3
00007d3d13bd36a1  call 0x00007D3D13AC4740
00007d3d13bd36a6  jmp 0x00007D3D13BD23D0
00007d3d13bd36ab  call 0x00007D3D13AB5400
00007d3d13bd36b0  jmp 0x00007D3D13BD23DD
00007d3d13bd36b5  call 0x00007D3D13AB52F0
00007d3d13bd36ba  jmp 0x00007D3D13BD23EA
00007d3d13bd36bf  call 0x00007D3D13AC4620
00007d3d13bd36c4  jmp 0x00007D3D13BD23F7
00007d3d13bd36c9  call 0x00007D3D13AB8D90
00007d3d13bd36ce  jmp 0x00007D3D13BD2404
00007d3d13bd36d3  call 0x00007D3D13AB8A20
00007d3d13bd36d8  jmp 0x00007D3D13BD2411
00007d3d13bd36dd  call 0x00007D3D13AB77B0
00007d3d13bd36e2  jmp 0x00007D3D13BD241B
00007d3d13bd36e7  call 0x00007D3D13AB6550
00007d3d13bd36ec  jmp 0x00007D3D13BD2425
00007d3d13bd36f1  call 0x00007D3D13AB5400
00007d3d13bd36f6  jmp 0x00007D3D13BD2437
00007d3d13bd36fb  call 0x00007D3D13AC0FC0
00007d3d13bd3700  jmp 0x00007D3D13BD2441
00007d3d13bd3705  call 0x00007D3D13AB52F0
00007d3d13bd370a  jmp 0x00007D3D13BD244B
00007d3d13bd370f  call 0x00007D3D13AC0EA0
00007d3d13bd3714  jmp 0x00007D3D13BD2455
00007d3d13bd3719  call 0x00007D3D13ABFD50
00007d3d13bd371e  jmp 0x00007D3D13BD245F
00007d3d13bd3723  call 0x00007D3D13AB8EA0
00007d3d13bd3728  jmp 0x00007D3D13BD2469
00007d3d13bd372d  call 0x00007D3D13ABFC30
00007d3d13bd3732  jmp 0x00007D3D13BD2476
00007d3d13bd3737  call 0x00007D3D13AB8D90
00007d3d13bd373c  jmp 0x00007D3D13BD2483
00007d3d13bd3741  call 0x00007D3D13AB52F0
00007d3d13bd3746  jmp 0x00007D3D13BD2496
00007d3d13bd374b  call 0x00007D3D13AB52F0
00007d3d13bd3750  jmp 0x00007D3D13BD24A9
00007d3d13bd3755  call 0x00007D3D13AC0FC0
00007d3d13bd375a  jmp 0x00007D3D13BD24B6
00007d3d13bd375f  call 0x00007D3D13AC0FC0
00007d3d13bd3764  jmp 0x00007D3D13BD24C9
00007d3d13bd3769  call 0x00007D3D13AC0EA0
00007d3d13bd376e  jmp 0x00007D3D13BD24D6
00007d3d13bd3773  call 0x00007D3D13AB52F0
00007d3d13bd3778  jmp 0x00007D3D13BD24E9
00007d3d13bd377d  call 0x00007D3D13AB52F0
00007d3d13bd3782  jmp 0x00007D3D13BD24FC
00007d3d13bd3787  call 0x00007D3D13AB52F0
00007d3d13bd378c  jmp 0x00007D3D13BD250F
00007d3d13bd3791  call 0x00007D3D13AB52F0
00007d3d13bd3796  jmp 0x00007D3D13BD252A
00007d3d13bd379b  call 0x00007D3D13AB52F0
00007d3d13bd37a0  jmp 0x00007D3D13BD253D
00007d3d13bd37a5  call 0x00007D3D13AB5400
00007d3d13bd37aa  jmp 0x00007D3D13BD257E
00007d3d13bd37af  call 0x00007D3D13AC0FC0
00007d3d13bd37b4  jmp 0x00007D3D13BD258B
00007d3d13bd37b9  call 0x00007D3D13AB52F0
00007d3d13bd37be  jmp 0x00007D3D13BD2598
00007d3d13bd37c3  call 0x00007D3D13AC0EA0
00007d3d13bd37c8  jmp 0x00007D3D13BD25A5
00007d3d13bd37cd  call 0x00007D3D139FF540
00007d3d13bd37d2  jmp 0x00007D3D13BD25C3
00007d3d13bd37d7  call 0x00007D3D13A08C20
00007d3d13bd37dc  jmp 0x00007D3D13BD25CD
00007d3d13bd37e1  call 0x00007D3D13AE21C0
00007d3d13bd37e6  jmp 0x00007D3D13BD25D3
00007d3d13bd37eb  call 0x00007D3D139FF540
00007d3d13bd37f0  jmp 0x00007D3D13BD25E3
00007d3d13bd37f5  call 0x00007D3D13AC0370
00007d3d13bd37fa  jmp 0x00007D3D13BD2611
00007d3d13bd37ff  call 0x00007D3D13ABF100
00007d3d13bd3804  jmp 0x00007D3D13BD261A
00007d3d13bd3809  call 0x00007D3D13AC0370
00007d3d13bd380e  jmp 0x00007D3D13BD2674
00007d3d13bd3813  call 0x00007D3D13ABF100
00007d3d13bd3818  jmp 0x00007D3D13BD267D
00007d3d13bd381d  call 0x00007D3D13AC0370
00007d3d13bd3822  jmp 0x00007D3D13BD26C6
00007d3d13bd3827  call 0x00007D3D13ABF100
00007d3d13bd382c  jmp 0x00007D3D13BD26CF
00007d3d13bd3831  call 0x00007D3D13A0B720
00007d3d13bd3836  jmp 0x00007D3D13BD2714
00007d3d13bd383b  call 0x00007D3D13AB47C0
00007d3d13bd3840  jmp 0x00007D3D13BD2727
00007d3d13bd3845  call 0x00007D3D13A08B00
00007d3d13bd384a  jmp 0x00007D3D13BD273E
00007d3d13bd384f  call 0x00007D3D139FF430
00007d3d13bd3854  jmp 0x00007D3D13BD2751
00007d3d13bd3859  call 0x00007D3D139FF430
00007d3d13bd385e  jmp 0x00007D3D13BD2764
00007d3d13bd3863  sub rsp, 0x08
00007d3d13bd3867  push rax
00007d3d13bd3868  push rcx
00007d3d13bd3869  push rdx
00007d3d13bd386a  push rdi
00007d3d13bd386b  push rsi
00007d3d13bd386c  push r8
00007d3d13bd386e  push r9
00007d3d13bd3870  push r10
00007d3d13bd3872  push r11
00007d3d13bd3874  sub rsp, 0xF0
00007d3d13bd387b  vmovaps [rsp], xmm0
00007d3d13bd3880  vmovaps [rsp+0x10], xmm2
00007d3d13bd3886  vmovaps [rsp+0x20], xmm3
00007d3d13bd388c  vmovaps [rsp+0x30], xmm4
00007d3d13bd3892  vmovaps [rsp+0x40], xmm5
00007d3d13bd3898  vmovaps [rsp+0x50], xmm6
00007d3d13bd389e  vmovaps [rsp+0x60], xmm7
00007d3d13bd38a4  vmovaps [rsp+0x70], xmm8
00007d3d13bd38aa  vmovaps [rsp+0x80], xmm9
00007d3d13bd38b3  vmovaps [rsp+0x90], xmm10
00007d3d13bd38bc  vmovaps [rsp+0xA0], xmm11
00007d3d13bd38c5  vmovaps [rsp+0xB0], xmm12
00007d3d13bd38ce  vmovaps [rsp+0xC0], xmm13
00007d3d13bd38d7  vmovaps [rsp+0xD0], xmm14
00007d3d13bd38e0  vmovaps [rsp+0xE0], xmm15
00007d3d13bd38e9  sub rsp, 0x30
00007d3d13bd38ed  movaps [rsp], xmm1
00007d3d13bd38f1  movaps [rsp+0x10], xmm12
00007d3d13bd38f7  movaps [rsp+0x20], xmm15
00007d3d13bd38fd  lea rdi, [rsp]
00007d3d13bd3901  mov esi, 0x00
00007d3d13bd3906  mov rax, 0x5741DAFC8530
00007d3d13bd3910  call rax
00007d3d13bd3912  movaps xmm1, [rsp]
00007d3d13bd3916  add rsp, 0x30
00007d3d13bd391a  vmovaps xmm0, [rsp]
00007d3d13bd391f  vmovaps xmm2, [rsp+0x10]
00007d3d13bd3925  vmovaps xmm3, [rsp+0x20]
00007d3d13bd392b  vmovaps xmm4, [rsp+0x30]
00007d3d13bd3931  vmovaps xmm5, [rsp+0x40]
00007d3d13bd3937  vmovaps xmm6, [rsp+0x50]
00007d3d13bd393d  vmovaps xmm7, [rsp+0x60]
00007d3d13bd3943  vmovaps xmm8, [rsp+0x70]
00007d3d13bd3949  vmovaps xmm9, [rsp+0x80]
00007d3d13bd3952  vmovaps xmm10, [rsp+0x90]
00007d3d13bd395b  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd3964  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd396d  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd3976  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd397f  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd3988  add rsp, 0xF0
00007d3d13bd398f  pop r11
00007d3d13bd3991  pop r10
00007d3d13bd3993  pop r9
00007d3d13bd3995  pop r8
00007d3d13bd3997  pop rsi
00007d3d13bd3998  pop rdi
00007d3d13bd3999  pop rdx
00007d3d13bd399a  pop rcx
00007d3d13bd399b  pop rax
00007d3d13bd399c  add rsp, 0x08
00007d3d13bd39a0  jmp 0x00007D3D13BD27B2
00007d3d13bd39a5  sub rsp, 0x08
00007d3d13bd39a9  push rax
00007d3d13bd39aa  push rcx
00007d3d13bd39ab  push rdx
00007d3d13bd39ac  push rdi
00007d3d13bd39ad  push rsi
00007d3d13bd39ae  push r8
00007d3d13bd39b0  push r9
00007d3d13bd39b2  push r10
00007d3d13bd39b4  push r11
00007d3d13bd39b6  sub rsp, 0xF0
00007d3d13bd39bd  vmovaps [rsp], xmm0
00007d3d13bd39c2  vmovaps [rsp+0x10], xmm1
00007d3d13bd39c8  vmovaps [rsp+0x20], xmm2
00007d3d13bd39ce  vmovaps [rsp+0x30], xmm3
00007d3d13bd39d4  vmovaps [rsp+0x40], xmm4
00007d3d13bd39da  vmovaps [rsp+0x50], xmm5
00007d3d13bd39e0  vmovaps [rsp+0x60], xmm6
00007d3d13bd39e6  vmovaps [rsp+0x70], xmm7
00007d3d13bd39ec  vmovaps [rsp+0x80], xmm8
00007d3d13bd39f5  vmovaps [rsp+0x90], xmm9
00007d3d13bd39fe  vmovaps [rsp+0xA0], xmm10
00007d3d13bd3a07  vmovaps [rsp+0xB0], xmm11
00007d3d13bd3a10  vmovaps [rsp+0xC0], xmm12
00007d3d13bd3a19  vmovaps [rsp+0xD0], xmm13
00007d3d13bd3a22  vmovaps [rsp+0xE0], xmm15
00007d3d13bd3a2b  sub rsp, 0x30
00007d3d13bd3a2f  movaps [rsp], xmm14
00007d3d13bd3a34  movaps [rsp+0x10], xmm1
00007d3d13bd3a39  movaps [rsp+0x20], xmm15
00007d3d13bd3a3f  lea rdi, [rsp]
00007d3d13bd3a43  mov esi, 0x00
00007d3d13bd3a48  mov rax, 0x5741DAFC8530
00007d3d13bd3a52  call rax
00007d3d13bd3a54  movaps xmm14, [rsp]
00007d3d13bd3a59  add rsp, 0x30
00007d3d13bd3a5d  vmovaps xmm0, [rsp]
00007d3d13bd3a62  vmovaps xmm1, [rsp+0x10]
00007d3d13bd3a68  vmovaps xmm2, [rsp+0x20]
00007d3d13bd3a6e  vmovaps xmm3, [rsp+0x30]
00007d3d13bd3a74  vmovaps xmm4, [rsp+0x40]
00007d3d13bd3a7a  vmovaps xmm5, [rsp+0x50]
00007d3d13bd3a80  vmovaps xmm6, [rsp+0x60]
00007d3d13bd3a86  vmovaps xmm7, [rsp+0x70]
00007d3d13bd3a8c  vmovaps xmm8, [rsp+0x80]
00007d3d13bd3a95  vmovaps xmm9, [rsp+0x90]
00007d3d13bd3a9e  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd3aa7  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd3ab0  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd3ab9  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd3ac2  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd3acb  add rsp, 0xF0
00007d3d13bd3ad2  pop r11
00007d3d13bd3ad4  pop r10
00007d3d13bd3ad6  pop r9
00007d3d13bd3ad8  pop r8
00007d3d13bd3ada  pop rsi
00007d3d13bd3adb  pop rdi
00007d3d13bd3adc  pop rdx
00007d3d13bd3add  pop rcx
00007d3d13bd3ade  pop rax
00007d3d13bd3adf  add rsp, 0x08
00007d3d13bd3ae3  jmp 0x00007D3D13BD2800
00007d3d13bd3ae8  sub rsp, 0x08
00007d3d13bd3aec  push rax
00007d3d13bd3aed  push rcx
00007d3d13bd3aee  push rdx
00007d3d13bd3aef  push rdi
00007d3d13bd3af0  push rsi
00007d3d13bd3af1  push r8
00007d3d13bd3af3  push r9
00007d3d13bd3af5  push r10
00007d3d13bd3af7  push r11
00007d3d13bd3af9  sub rsp, 0xF0
00007d3d13bd3b00  vmovaps [rsp], xmm0
00007d3d13bd3b05  vmovaps [rsp+0x10], xmm1
00007d3d13bd3b0b  vmovaps [rsp+0x20], xmm2
00007d3d13bd3b11  vmovaps [rsp+0x30], xmm3
00007d3d13bd3b17  vmovaps [rsp+0x40], xmm4
00007d3d13bd3b1d  vmovaps [rsp+0x50], xmm5
00007d3d13bd3b23  vmovaps [rsp+0x60], xmm6
00007d3d13bd3b29  vmovaps [rsp+0x70], xmm7
00007d3d13bd3b2f  vmovaps [rsp+0x80], xmm8
00007d3d13bd3b38  vmovaps [rsp+0x90], xmm9
00007d3d13bd3b41  vmovaps [rsp+0xA0], xmm10
00007d3d13bd3b4a  vmovaps [rsp+0xB0], xmm11
00007d3d13bd3b53  vmovaps [rsp+0xC0], xmm12
00007d3d13bd3b5c  vmovaps [rsp+0xD0], xmm13
00007d3d13bd3b65  vmovaps [rsp+0xE0], xmm14
00007d3d13bd3b6e  sub rsp, 0x30
00007d3d13bd3b72  movaps [rsp], xmm15
00007d3d13bd3b77  movaps [rsp+0x10], xmm12
00007d3d13bd3b7d  movaps [rsp+0x20], xmm13
00007d3d13bd3b83  lea rdi, [rsp]
00007d3d13bd3b87  mov esi, 0x00
00007d3d13bd3b8c  mov rax, 0x5741DAFC8530
00007d3d13bd3b96  call rax
00007d3d13bd3b98  movaps xmm15, [rsp]
00007d3d13bd3b9d  add rsp, 0x30
00007d3d13bd3ba1  vmovaps xmm0, [rsp]
00007d3d13bd3ba6  vmovaps xmm1, [rsp+0x10]
00007d3d13bd3bac  vmovaps xmm2, [rsp+0x20]
00007d3d13bd3bb2  vmovaps xmm3, [rsp+0x30]
00007d3d13bd3bb8  vmovaps xmm4, [rsp+0x40]
00007d3d13bd3bbe  vmovaps xmm5, [rsp+0x50]
00007d3d13bd3bc4  vmovaps xmm6, [rsp+0x60]
00007d3d13bd3bca  vmovaps xmm7, [rsp+0x70]
00007d3d13bd3bd0  vmovaps xmm8, [rsp+0x80]
00007d3d13bd3bd9  vmovaps xmm9, [rsp+0x90]
00007d3d13bd3be2  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd3beb  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd3bf4  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd3bfd  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd3c06  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd3c0f  add rsp, 0xF0
00007d3d13bd3c16  pop r11
00007d3d13bd3c18  pop r10
00007d3d13bd3c1a  pop r9
00007d3d13bd3c1c  pop r8
00007d3d13bd3c1e  pop rsi
00007d3d13bd3c1f  pop rdi
00007d3d13bd3c20  pop rdx
00007d3d13bd3c21  pop rcx
00007d3d13bd3c22  pop rax
00007d3d13bd3c23  add rsp, 0x08
00007d3d13bd3c27  jmp 0x00007D3D13BD2835
00007d3d13bd3c2c  sub rsp, 0x08
00007d3d13bd3c30  push rax
00007d3d13bd3c31  push rcx
00007d3d13bd3c32  push rdx
00007d3d13bd3c33  push rdi
00007d3d13bd3c34  push rsi
00007d3d13bd3c35  push r8
00007d3d13bd3c37  push r9
00007d3d13bd3c39  push r10
00007d3d13bd3c3b  push r11
00007d3d13bd3c3d  sub rsp, 0xF0
00007d3d13bd3c44  vmovaps [rsp], xmm0
00007d3d13bd3c49  vmovaps [rsp+0x10], xmm2
00007d3d13bd3c4f  vmovaps [rsp+0x20], xmm3
00007d3d13bd3c55  vmovaps [rsp+0x30], xmm4
00007d3d13bd3c5b  vmovaps [rsp+0x40], xmm5
00007d3d13bd3c61  vmovaps [rsp+0x50], xmm6
00007d3d13bd3c67  vmovaps [rsp+0x60], xmm7
00007d3d13bd3c6d  vmovaps [rsp+0x70], xmm8
00007d3d13bd3c73  vmovaps [rsp+0x80], xmm9
00007d3d13bd3c7c  vmovaps [rsp+0x90], xmm10
00007d3d13bd3c85  vmovaps [rsp+0xA0], xmm11
00007d3d13bd3c8e  vmovaps [rsp+0xB0], xmm12
00007d3d13bd3c97  vmovaps [rsp+0xC0], xmm13
00007d3d13bd3ca0  vmovaps [rsp+0xD0], xmm14
00007d3d13bd3ca9  vmovaps [rsp+0xE0], xmm15
00007d3d13bd3cb2  sub rsp, 0x30
00007d3d13bd3cb6  movaps [rsp], xmm1
00007d3d13bd3cba  movaps [rsp+0x10], xmm12
00007d3d13bd3cc0  movaps [rsp+0x20], xmm10
00007d3d13bd3cc6  lea rdi, [rsp]
00007d3d13bd3cca  mov esi, 0x00
00007d3d13bd3ccf  mov rax, 0x5741DAFC8530
00007d3d13bd3cd9  call rax
00007d3d13bd3cdb  movaps xmm1, [rsp]
00007d3d13bd3cdf  add rsp, 0x30
00007d3d13bd3ce3  vmovaps xmm0, [rsp]
00007d3d13bd3ce8  vmovaps xmm2, [rsp+0x10]
00007d3d13bd3cee  vmovaps xmm3, [rsp+0x20]
00007d3d13bd3cf4  vmovaps xmm4, [rsp+0x30]
00007d3d13bd3cfa  vmovaps xmm5, [rsp+0x40]
00007d3d13bd3d00  vmovaps xmm6, [rsp+0x50]
00007d3d13bd3d06  vmovaps xmm7, [rsp+0x60]
00007d3d13bd3d0c  vmovaps xmm8, [rsp+0x70]
00007d3d13bd3d12  vmovaps xmm9, [rsp+0x80]
00007d3d13bd3d1b  vmovaps xmm10, [rsp+0x90]
00007d3d13bd3d24  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd3d2d  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd3d36  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd3d3f  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd3d48  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd3d51  add rsp, 0xF0
00007d3d13bd3d58  pop r11
00007d3d13bd3d5a  pop r10
00007d3d13bd3d5c  pop r9
00007d3d13bd3d5e  pop r8
00007d3d13bd3d60  pop rsi
00007d3d13bd3d61  pop rdi
00007d3d13bd3d62  pop rdx
00007d3d13bd3d63  pop rcx
00007d3d13bd3d64  pop rax
00007d3d13bd3d65  add rsp, 0x08
00007d3d13bd3d69  jmp 0x00007D3D13BD284F
00007d3d13bd3d6e  sub rsp, 0x08
00007d3d13bd3d72  push rax
00007d3d13bd3d73  push rcx
00007d3d13bd3d74  push rdx
00007d3d13bd3d75  push rdi
00007d3d13bd3d76  push rsi
00007d3d13bd3d77  push r8
00007d3d13bd3d79  push r9
00007d3d13bd3d7b  push r10
00007d3d13bd3d7d  push r11
00007d3d13bd3d7f  sub rsp, 0xF0
00007d3d13bd3d86  vmovaps [rsp], xmm0
00007d3d13bd3d8b  vmovaps [rsp+0x10], xmm1
00007d3d13bd3d91  vmovaps [rsp+0x20], xmm2
00007d3d13bd3d97  vmovaps [rsp+0x30], xmm3
00007d3d13bd3d9d  vmovaps [rsp+0x40], xmm4
00007d3d13bd3da3  vmovaps [rsp+0x50], xmm5
00007d3d13bd3da9  vmovaps [rsp+0x60], xmm6
00007d3d13bd3daf  vmovaps [rsp+0x70], xmm7
00007d3d13bd3db5  vmovaps [rsp+0x80], xmm8
00007d3d13bd3dbe  vmovaps [rsp+0x90], xmm9
00007d3d13bd3dc7  vmovaps [rsp+0xA0], xmm10
00007d3d13bd3dd0  vmovaps [rsp+0xB0], xmm11
00007d3d13bd3dd9  vmovaps [rsp+0xC0], xmm12
00007d3d13bd3de2  vmovaps [rsp+0xD0], xmm14
00007d3d13bd3deb  vmovaps [rsp+0xE0], xmm15
00007d3d13bd3df4  sub rsp, 0x30
00007d3d13bd3df8  movaps [rsp], xmm13
00007d3d13bd3dfd  movaps [rsp+0x10], xmm12
00007d3d13bd3e03  movaps [rsp+0x20], xmm2
00007d3d13bd3e08  lea rdi, [rsp]
00007d3d13bd3e0c  mov esi, 0x00
00007d3d13bd3e11  mov rax, 0x5741DAFC8530
00007d3d13bd3e1b  call rax
00007d3d13bd3e1d  movaps xmm13, [rsp]
00007d3d13bd3e22  add rsp, 0x30
00007d3d13bd3e26  vmovaps xmm0, [rsp]
00007d3d13bd3e2b  vmovaps xmm1, [rsp+0x10]
00007d3d13bd3e31  vmovaps xmm2, [rsp+0x20]
00007d3d13bd3e37  vmovaps xmm3, [rsp+0x30]
00007d3d13bd3e3d  vmovaps xmm4, [rsp+0x40]
00007d3d13bd3e43  vmovaps xmm5, [rsp+0x50]
00007d3d13bd3e49  vmovaps xmm6, [rsp+0x60]
00007d3d13bd3e4f  vmovaps xmm7, [rsp+0x70]
00007d3d13bd3e55  vmovaps xmm8, [rsp+0x80]
00007d3d13bd3e5e  vmovaps xmm9, [rsp+0x90]
00007d3d13bd3e67  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd3e70  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd3e79  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd3e82  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd3e8b  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd3e94  add rsp, 0xF0
00007d3d13bd3e9b  pop r11
00007d3d13bd3e9d  pop r10
00007d3d13bd3e9f  pop r9
00007d3d13bd3ea1  pop r8
00007d3d13bd3ea3  pop rsi
00007d3d13bd3ea4  pop rdi
00007d3d13bd3ea5  pop rdx
00007d3d13bd3ea6  pop rcx
00007d3d13bd3ea7  pop rax
00007d3d13bd3ea8  add rsp, 0x08
00007d3d13bd3eac  jmp 0x00007D3D13BD286A
00007d3d13bd3eb1  sub rsp, 0x08
00007d3d13bd3eb5  push rax
00007d3d13bd3eb6  push rcx
00007d3d13bd3eb7  push rdx
00007d3d13bd3eb8  push rdi
00007d3d13bd3eb9  push rsi
00007d3d13bd3eba  push r8
00007d3d13bd3ebc  push r9
00007d3d13bd3ebe  push r10
00007d3d13bd3ec0  push r11
00007d3d13bd3ec2  sub rsp, 0xF0
00007d3d13bd3ec9  vmovaps [rsp], xmm0
00007d3d13bd3ece  vmovaps [rsp+0x10], xmm2
00007d3d13bd3ed4  vmovaps [rsp+0x20], xmm3
00007d3d13bd3eda  vmovaps [rsp+0x30], xmm4
00007d3d13bd3ee0  vmovaps [rsp+0x40], xmm5
00007d3d13bd3ee6  vmovaps [rsp+0x50], xmm6
00007d3d13bd3eec  vmovaps [rsp+0x60], xmm7
00007d3d13bd3ef2  vmovaps [rsp+0x70], xmm8
00007d3d13bd3ef8  vmovaps [rsp+0x80], xmm9
00007d3d13bd3f01  vmovaps [rsp+0x90], xmm10
00007d3d13bd3f0a  vmovaps [rsp+0xA0], xmm11
00007d3d13bd3f13  vmovaps [rsp+0xB0], xmm12
00007d3d13bd3f1c  vmovaps [rsp+0xC0], xmm13
00007d3d13bd3f25  vmovaps [rsp+0xD0], xmm14
00007d3d13bd3f2e  vmovaps [rsp+0xE0], xmm15
00007d3d13bd3f37  sub rsp, 0x30
00007d3d13bd3f3b  movaps [rsp], xmm1
00007d3d13bd3f3f  movaps [rsp+0x10], xmm10
00007d3d13bd3f45  movaps [rsp+0x20], xmm2
00007d3d13bd3f4a  lea rdi, [rsp]
00007d3d13bd3f4e  mov esi, 0x00
00007d3d13bd3f53  mov rax, 0x5741DAFC8530
00007d3d13bd3f5d  call rax
00007d3d13bd3f5f  movaps xmm1, [rsp]
00007d3d13bd3f63  add rsp, 0x30
00007d3d13bd3f67  vmovaps xmm0, [rsp]
00007d3d13bd3f6c  vmovaps xmm2, [rsp+0x10]
00007d3d13bd3f72  vmovaps xmm3, [rsp+0x20]
00007d3d13bd3f78  vmovaps xmm4, [rsp+0x30]
00007d3d13bd3f7e  vmovaps xmm5, [rsp+0x40]
00007d3d13bd3f84  vmovaps xmm6, [rsp+0x50]
00007d3d13bd3f8a  vmovaps xmm7, [rsp+0x60]
00007d3d13bd3f90  vmovaps xmm8, [rsp+0x70]
00007d3d13bd3f96  vmovaps xmm9, [rsp+0x80]
00007d3d13bd3f9f  vmovaps xmm10, [rsp+0x90]
00007d3d13bd3fa8  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd3fb1  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd3fba  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd3fc3  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd3fcc  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd3fd5  add rsp, 0xF0
00007d3d13bd3fdc  pop r11
00007d3d13bd3fde  pop r10
00007d3d13bd3fe0  pop r9
00007d3d13bd3fe2  pop r8
00007d3d13bd3fe4  pop rsi
00007d3d13bd3fe5  pop rdi
00007d3d13bd3fe6  pop rdx
00007d3d13bd3fe7  pop rcx
00007d3d13bd3fe8  pop rax
00007d3d13bd3fe9  add rsp, 0x08
00007d3d13bd3fed  jmp 0x00007D3D13BD28D2
00007d3d13bd3ff2  sub rsp, 0x08
00007d3d13bd3ff6  push rax
00007d3d13bd3ff7  push rcx
00007d3d13bd3ff8  push rdx
00007d3d13bd3ff9  push rdi
00007d3d13bd3ffa  push rsi
00007d3d13bd3ffb  push r8
00007d3d13bd3ffd  push r9
00007d3d13bd3fff  push r10
00007d3d13bd4001  push r11
00007d3d13bd4003  sub rsp, 0xF0
00007d3d13bd400a  vmovaps [rsp], xmm0
00007d3d13bd400f  vmovaps [rsp+0x10], xmm1
00007d3d13bd4015  vmovaps [rsp+0x20], xmm2
00007d3d13bd401b  vmovaps [rsp+0x30], xmm3
00007d3d13bd4021  vmovaps [rsp+0x40], xmm4
00007d3d13bd4027  vmovaps [rsp+0x50], xmm5
00007d3d13bd402d  vmovaps [rsp+0x60], xmm6
00007d3d13bd4033  vmovaps [rsp+0x70], xmm7
00007d3d13bd4039  vmovaps [rsp+0x80], xmm8
00007d3d13bd4042  vmovaps [rsp+0x90], xmm9
00007d3d13bd404b  vmovaps [rsp+0xA0], xmm10
00007d3d13bd4054  vmovaps [rsp+0xB0], xmm11
00007d3d13bd405d  vmovaps [rsp+0xC0], xmm12
00007d3d13bd4066  vmovaps [rsp+0xD0], xmm13
00007d3d13bd406f  vmovaps [rsp+0xE0], xmm14
00007d3d13bd4078  sub rsp, 0x30
00007d3d13bd407c  movaps [rsp], xmm15
00007d3d13bd4081  movaps [rsp+0x10], xmm10
00007d3d13bd4087  movaps [rsp+0x20], xmm2
00007d3d13bd408c  lea rdi, [rsp]
00007d3d13bd4090  mov esi, 0x00
00007d3d13bd4095  mov rax, 0x5741DAFC8530
00007d3d13bd409f  call rax
00007d3d13bd40a1  movaps xmm15, [rsp]
00007d3d13bd40a6  add rsp, 0x30
00007d3d13bd40aa  vmovaps xmm0, [rsp]
00007d3d13bd40af  vmovaps xmm1, [rsp+0x10]
00007d3d13bd40b5  vmovaps xmm2, [rsp+0x20]
00007d3d13bd40bb  vmovaps xmm3, [rsp+0x30]
00007d3d13bd40c1  vmovaps xmm4, [rsp+0x40]
00007d3d13bd40c7  vmovaps xmm5, [rsp+0x50]
00007d3d13bd40cd  vmovaps xmm6, [rsp+0x60]
00007d3d13bd40d3  vmovaps xmm7, [rsp+0x70]
00007d3d13bd40d9  vmovaps xmm8, [rsp+0x80]
00007d3d13bd40e2  vmovaps xmm9, [rsp+0x90]
00007d3d13bd40eb  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd40f4  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd40fd  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd4106  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd410f  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd4118  add rsp, 0xF0
00007d3d13bd411f  pop r11
00007d3d13bd4121  pop r10
00007d3d13bd4123  pop r9
00007d3d13bd4125  pop r8
00007d3d13bd4127  pop rsi
00007d3d13bd4128  pop rdi
00007d3d13bd4129  pop rdx
00007d3d13bd412a  pop rcx
00007d3d13bd412b  pop rax
00007d3d13bd412c  add rsp, 0x08
00007d3d13bd4130  jmp 0x00007D3D13BD2924
00007d3d13bd4135  sub rsp, 0x08
00007d3d13bd4139  push rax
00007d3d13bd413a  push rcx
00007d3d13bd413b  push rdx
00007d3d13bd413c  push rdi
00007d3d13bd413d  push rsi
00007d3d13bd413e  push r8
00007d3d13bd4140  push r9
00007d3d13bd4142  push r10
00007d3d13bd4144  push r11
00007d3d13bd4146  sub rsp, 0xF0
00007d3d13bd414d  vmovaps [rsp], xmm0
00007d3d13bd4152  vmovaps [rsp+0x10], xmm2
00007d3d13bd4158  vmovaps [rsp+0x20], xmm3
00007d3d13bd415e  vmovaps [rsp+0x30], xmm4
00007d3d13bd4164  vmovaps [rsp+0x40], xmm5
00007d3d13bd416a  vmovaps [rsp+0x50], xmm6
00007d3d13bd4170  vmovaps [rsp+0x60], xmm7
00007d3d13bd4176  vmovaps [rsp+0x70], xmm8
00007d3d13bd417c  vmovaps [rsp+0x80], xmm9
00007d3d13bd4185  vmovaps [rsp+0x90], xmm10
00007d3d13bd418e  vmovaps [rsp+0xA0], xmm11
00007d3d13bd4197  vmovaps [rsp+0xB0], xmm12
00007d3d13bd41a0  vmovaps [rsp+0xC0], xmm13
00007d3d13bd41a9  vmovaps [rsp+0xD0], xmm14
00007d3d13bd41b2  vmovaps [rsp+0xE0], xmm15
00007d3d13bd41bb  sub rsp, 0x30
00007d3d13bd41bf  movaps [rsp], xmm1
00007d3d13bd41c3  movaps [rsp+0x10], xmm10
00007d3d13bd41c9  movaps [rsp+0x20], xmm15
00007d3d13bd41cf  lea rdi, [rsp]
00007d3d13bd41d3  mov esi, 0x00
00007d3d13bd41d8  mov rax, 0x5741DAFC8530
00007d3d13bd41e2  call rax
00007d3d13bd41e4  movaps xmm1, [rsp]
00007d3d13bd41e8  add rsp, 0x30
00007d3d13bd41ec  vmovaps xmm0, [rsp]
00007d3d13bd41f1  vmovaps xmm2, [rsp+0x10]
00007d3d13bd41f7  vmovaps xmm3, [rsp+0x20]
00007d3d13bd41fd  vmovaps xmm4, [rsp+0x30]
00007d3d13bd4203  vmovaps xmm5, [rsp+0x40]
00007d3d13bd4209  vmovaps xmm6, [rsp+0x50]
00007d3d13bd420f  vmovaps xmm7, [rsp+0x60]
00007d3d13bd4215  vmovaps xmm8, [rsp+0x70]
00007d3d13bd421b  vmovaps xmm9, [rsp+0x80]
00007d3d13bd4224  vmovaps xmm10, [rsp+0x90]
00007d3d13bd422d  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd4236  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd423f  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd4248  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd4251  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd425a  add rsp, 0xF0
00007d3d13bd4261  pop r11
00007d3d13bd4263  pop r10
00007d3d13bd4265  pop r9
00007d3d13bd4267  pop r8
00007d3d13bd4269  pop rsi
00007d3d13bd426a  pop rdi
00007d3d13bd426b  pop rdx
00007d3d13bd426c  pop rcx
00007d3d13bd426d  pop rax
00007d3d13bd426e  add rsp, 0x08
00007d3d13bd4272  jmp 0x00007D3D13BD2962
00007d3d13bd4277  sub rsp, 0x08
00007d3d13bd427b  push rax
00007d3d13bd427c  push rcx
00007d3d13bd427d  push rdx
00007d3d13bd427e  push rdi
00007d3d13bd427f  push rsi
00007d3d13bd4280  push r8
00007d3d13bd4282  push r9
00007d3d13bd4284  push r10
00007d3d13bd4286  push r11
00007d3d13bd4288  sub rsp, 0xF0
00007d3d13bd428f  vmovaps [rsp], xmm0
00007d3d13bd4294  vmovaps [rsp+0x10], xmm1
00007d3d13bd429a  vmovaps [rsp+0x20], xmm2
00007d3d13bd42a0  vmovaps [rsp+0x30], xmm3
00007d3d13bd42a6  vmovaps [rsp+0x40], xmm4
00007d3d13bd42ac  vmovaps [rsp+0x50], xmm5
00007d3d13bd42b2  vmovaps [rsp+0x60], xmm6
00007d3d13bd42b8  vmovaps [rsp+0x70], xmm7
00007d3d13bd42be  vmovaps [rsp+0x80], xmm8
00007d3d13bd42c7  vmovaps [rsp+0x90], xmm9
00007d3d13bd42d0  vmovaps [rsp+0xA0], xmm10
00007d3d13bd42d9  vmovaps [rsp+0xB0], xmm11
00007d3d13bd42e2  vmovaps [rsp+0xC0], xmm12
00007d3d13bd42eb  vmovaps [rsp+0xD0], xmm13
00007d3d13bd42f4  vmovaps [rsp+0xE0], xmm15
00007d3d13bd42fd  sub rsp, 0x30
00007d3d13bd4301  movaps [rsp], xmm14
00007d3d13bd4306  movaps [rsp+0x10], xmm10
00007d3d13bd430c  movaps [rsp+0x20], xmm15
00007d3d13bd4312  lea rdi, [rsp]
00007d3d13bd4316  mov esi, 0x00
00007d3d13bd431b  mov rax, 0x5741DAFC8530
00007d3d13bd4325  call rax
00007d3d13bd4327  movaps xmm14, [rsp]
00007d3d13bd432c  add rsp, 0x30
00007d3d13bd4330  vmovaps xmm0, [rsp]
00007d3d13bd4335  vmovaps xmm1, [rsp+0x10]
00007d3d13bd433b  vmovaps xmm2, [rsp+0x20]
00007d3d13bd4341  vmovaps xmm3, [rsp+0x30]
00007d3d13bd4347  vmovaps xmm4, [rsp+0x40]
00007d3d13bd434d  vmovaps xmm5, [rsp+0x50]
00007d3d13bd4353  vmovaps xmm6, [rsp+0x60]
00007d3d13bd4359  vmovaps xmm7, [rsp+0x70]
00007d3d13bd435f  vmovaps xmm8, [rsp+0x80]
00007d3d13bd4368  vmovaps xmm9, [rsp+0x90]
00007d3d13bd4371  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd437a  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd4383  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd438c  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd4395  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd439e  add rsp, 0xF0
00007d3d13bd43a5  pop r11
00007d3d13bd43a7  pop r10
00007d3d13bd43a9  pop r9
00007d3d13bd43ab  pop r8
00007d3d13bd43ad  pop rsi
00007d3d13bd43ae  pop rdi
00007d3d13bd43af  pop rdx
00007d3d13bd43b0  pop rcx
00007d3d13bd43b1  pop rax
00007d3d13bd43b2  add rsp, 0x08
00007d3d13bd43b6  jmp 0x00007D3D13BD298E
00007d3d13bd43bb  call 0x00007D3D139FF430
00007d3d13bd43c0  jmp 0x00007D3D13BD2A1E
00007d3d13bd43c5  call 0x00007D3D139FF430
00007d3d13bd43ca  jmp 0x00007D3D13BD2A31
00007d3d13bd43cf  sub rsp, 0x08
00007d3d13bd43d3  push rax
00007d3d13bd43d4  push rcx
00007d3d13bd43d5  push rdx
00007d3d13bd43d6  push rdi
00007d3d13bd43d7  push rsi
00007d3d13bd43d8  push r8
00007d3d13bd43da  push r9
00007d3d13bd43dc  push r10
00007d3d13bd43de  push r11
00007d3d13bd43e0  sub rsp, 0xF0
00007d3d13bd43e7  vmovaps [rsp], xmm0
00007d3d13bd43ec  vmovaps [rsp+0x10], xmm2
00007d3d13bd43f2  vmovaps [rsp+0x20], xmm3
00007d3d13bd43f8  vmovaps [rsp+0x30], xmm4
00007d3d13bd43fe  vmovaps [rsp+0x40], xmm5
00007d3d13bd4404  vmovaps [rsp+0x50], xmm6
00007d3d13bd440a  vmovaps [rsp+0x60], xmm7
00007d3d13bd4410  vmovaps [rsp+0x70], xmm8
00007d3d13bd4416  vmovaps [rsp+0x80], xmm9
00007d3d13bd441f  vmovaps [rsp+0x90], xmm10
00007d3d13bd4428  vmovaps [rsp+0xA0], xmm11
00007d3d13bd4431  vmovaps [rsp+0xB0], xmm12
00007d3d13bd443a  vmovaps [rsp+0xC0], xmm13
00007d3d13bd4443  vmovaps [rsp+0xD0], xmm14
00007d3d13bd444c  vmovaps [rsp+0xE0], xmm15
00007d3d13bd4455  sub rsp, 0x30
00007d3d13bd4459  movaps [rsp], xmm1
00007d3d13bd445d  movaps [rsp+0x10], xmm13
00007d3d13bd4463  movaps [rsp+0x20], xmm2
00007d3d13bd4468  lea rdi, [rsp]
00007d3d13bd446c  mov esi, 0x00
00007d3d13bd4471  mov rax, 0x5741DAFC8530
00007d3d13bd447b  call rax
00007d3d13bd447d  movaps xmm1, [rsp]
00007d3d13bd4481  add rsp, 0x30
00007d3d13bd4485  vmovaps xmm0, [rsp]
00007d3d13bd448a  vmovaps xmm2, [rsp+0x10]
00007d3d13bd4490  vmovaps xmm3, [rsp+0x20]
00007d3d13bd4496  vmovaps xmm4, [rsp+0x30]
00007d3d13bd449c  vmovaps xmm5, [rsp+0x40]
00007d3d13bd44a2  vmovaps xmm6, [rsp+0x50]
00007d3d13bd44a8  vmovaps xmm7, [rsp+0x60]
00007d3d13bd44ae  vmovaps xmm8, [rsp+0x70]
00007d3d13bd44b4  vmovaps xmm9, [rsp+0x80]
00007d3d13bd44bd  vmovaps xmm10, [rsp+0x90]
00007d3d13bd44c6  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd44cf  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd44d8  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd44e1  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd44ea  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd44f3  add rsp, 0xF0
00007d3d13bd44fa  pop r11
00007d3d13bd44fc  pop r10
00007d3d13bd44fe  pop r9
00007d3d13bd4500  pop r8
00007d3d13bd4502  pop rsi
00007d3d13bd4503  pop rdi
00007d3d13bd4504  pop rdx
00007d3d13bd4505  pop rcx
00007d3d13bd4506  pop rax
00007d3d13bd4507  add rsp, 0x08
00007d3d13bd450b  jmp 0x00007D3D13BD2A5C
00007d3d13bd4510  call 0x00007D3D13A0E760
00007d3d13bd4515  jmp 0x00007D3D13BD2A69
00007d3d13bd451a  sub rsp, 0x08
00007d3d13bd451e  push rax
00007d3d13bd451f  push rcx
00007d3d13bd4520  push rdx
00007d3d13bd4521  push rdi
00007d3d13bd4522  push rsi
00007d3d13bd4523  push r8
00007d3d13bd4525  push r9
00007d3d13bd4527  push r10
00007d3d13bd4529  push r11
00007d3d13bd452b  sub rsp, 0xF0
00007d3d13bd4532  vmovaps [rsp], xmm0
00007d3d13bd4537  vmovaps [rsp+0x10], xmm1
00007d3d13bd453d  vmovaps [rsp+0x20], xmm2
00007d3d13bd4543  vmovaps [rsp+0x30], xmm3
00007d3d13bd4549  vmovaps [rsp+0x40], xmm4
00007d3d13bd454f  vmovaps [rsp+0x50], xmm5
00007d3d13bd4555  vmovaps [rsp+0x60], xmm6
00007d3d13bd455b  vmovaps [rsp+0x70], xmm7
00007d3d13bd4561  vmovaps [rsp+0x80], xmm8
00007d3d13bd456a  vmovaps [rsp+0x90], xmm9
00007d3d13bd4573  vmovaps [rsp+0xA0], xmm10
00007d3d13bd457c  vmovaps [rsp+0xB0], xmm11
00007d3d13bd4585  vmovaps [rsp+0xC0], xmm12
00007d3d13bd458e  vmovaps [rsp+0xD0], xmm14
00007d3d13bd4597  vmovaps [rsp+0xE0], xmm15
00007d3d13bd45a0  sub rsp, 0x30
00007d3d13bd45a4  movaps [rsp], xmm13
00007d3d13bd45a9  movaps [rsp+0x10], xmm2
00007d3d13bd45ae  movaps [rsp+0x20], xmm1
00007d3d13bd45b3  lea rdi, [rsp]
00007d3d13bd45b7  mov esi, 0x00
00007d3d13bd45bc  mov rax, 0x5741DAFC8530
00007d3d13bd45c6  call rax
00007d3d13bd45c8  movaps xmm13, [rsp]
00007d3d13bd45cd  add rsp, 0x30
00007d3d13bd45d1  vmovaps xmm0, [rsp]
00007d3d13bd45d6  vmovaps xmm1, [rsp+0x10]
00007d3d13bd45dc  vmovaps xmm2, [rsp+0x20]
00007d3d13bd45e2  vmovaps xmm3, [rsp+0x30]
00007d3d13bd45e8  vmovaps xmm4, [rsp+0x40]
00007d3d13bd45ee  vmovaps xmm5, [rsp+0x50]
00007d3d13bd45f4  vmovaps xmm6, [rsp+0x60]
00007d3d13bd45fa  vmovaps xmm7, [rsp+0x70]
00007d3d13bd4600  vmovaps xmm8, [rsp+0x80]
00007d3d13bd4609  vmovaps xmm9, [rsp+0x90]
00007d3d13bd4612  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd461b  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd4624  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd462d  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd4636  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd463f  add rsp, 0xF0
00007d3d13bd4646  pop r11
00007d3d13bd4648  pop r10
00007d3d13bd464a  pop r9
00007d3d13bd464c  pop r8
00007d3d13bd464e  pop rsi
00007d3d13bd464f  pop rdi
00007d3d13bd4650  pop rdx
00007d3d13bd4651  pop rcx
00007d3d13bd4652  pop rax
00007d3d13bd4653  add rsp, 0x08
00007d3d13bd4657  jmp 0x00007D3D13BD2AA8
00007d3d13bd465c  sub rsp, 0x08
00007d3d13bd4660  push rax
00007d3d13bd4661  push rcx
00007d3d13bd4662  push rdx
00007d3d13bd4663  push rdi
00007d3d13bd4664  push rsi
00007d3d13bd4665  push r8
00007d3d13bd4667  push r9
00007d3d13bd4669  push r10
00007d3d13bd466b  push r11
00007d3d13bd466d  sub rsp, 0xF0
00007d3d13bd4674  vmovaps [rsp], xmm0
00007d3d13bd4679  vmovaps [rsp+0x10], xmm2
00007d3d13bd467f  vmovaps [rsp+0x20], xmm3
00007d3d13bd4685  vmovaps [rsp+0x30], xmm4
00007d3d13bd468b  vmovaps [rsp+0x40], xmm5
00007d3d13bd4691  vmovaps [rsp+0x50], xmm6
00007d3d13bd4697  vmovaps [rsp+0x60], xmm7
00007d3d13bd469d  vmovaps [rsp+0x70], xmm8
00007d3d13bd46a3  vmovaps [rsp+0x80], xmm9
00007d3d13bd46ac  vmovaps [rsp+0x90], xmm10
00007d3d13bd46b5  vmovaps [rsp+0xA0], xmm11
00007d3d13bd46be  vmovaps [rsp+0xB0], xmm12
00007d3d13bd46c7  vmovaps [rsp+0xC0], xmm13
00007d3d13bd46d0  vmovaps [rsp+0xD0], xmm14
00007d3d13bd46d9  vmovaps [rsp+0xE0], xmm15
00007d3d13bd46e2  sub rsp, 0x30
00007d3d13bd46e6  movaps [rsp], xmm1
00007d3d13bd46ea  movaps [rsp+0x10], xmm14
00007d3d13bd46f0  movaps [rsp+0x20], xmm15
00007d3d13bd46f6  lea rdi, [rsp]
00007d3d13bd46fa  mov esi, 0x00
00007d3d13bd46ff  mov rax, 0x5741DAFC8530
00007d3d13bd4709  call rax
00007d3d13bd470b  movaps xmm1, [rsp]
00007d3d13bd470f  add rsp, 0x30
00007d3d13bd4713  vmovaps xmm0, [rsp]
00007d3d13bd4718  vmovaps xmm2, [rsp+0x10]
00007d3d13bd471e  vmovaps xmm3, [rsp+0x20]
00007d3d13bd4724  vmovaps xmm4, [rsp+0x30]
00007d3d13bd472a  vmovaps xmm5, [rsp+0x40]
00007d3d13bd4730  vmovaps xmm6, [rsp+0x50]
00007d3d13bd4736  vmovaps xmm7, [rsp+0x60]
00007d3d13bd473c  vmovaps xmm8, [rsp+0x70]
00007d3d13bd4742  vmovaps xmm9, [rsp+0x80]
00007d3d13bd474b  vmovaps xmm10, [rsp+0x90]
00007d3d13bd4754  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd475d  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd4766  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd476f  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd4778  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd4781  add rsp, 0xF0
00007d3d13bd4788  pop r11
00007d3d13bd478a  pop r10
00007d3d13bd478c  pop r9
00007d3d13bd478e  pop r8
00007d3d13bd4790  pop rsi
00007d3d13bd4791  pop rdi
00007d3d13bd4792  pop rdx
00007d3d13bd4793  pop rcx
00007d3d13bd4794  pop rax
00007d3d13bd4795  add rsp, 0x08
00007d3d13bd4799  jmp 0x00007D3D13BD2ACA
00007d3d13bd479e  sub rsp, 0x08
00007d3d13bd47a2  push rax
00007d3d13bd47a3  push rcx
00007d3d13bd47a4  push rdx
00007d3d13bd47a5  push rdi
00007d3d13bd47a6  push rsi
00007d3d13bd47a7  push r8
00007d3d13bd47a9  push r9
00007d3d13bd47ab  push r10
00007d3d13bd47ad  push r11
00007d3d13bd47af  sub rsp, 0xF0
00007d3d13bd47b6  vmovaps [rsp], xmm0
00007d3d13bd47bb  vmovaps [rsp+0x10], xmm1
00007d3d13bd47c1  vmovaps [rsp+0x20], xmm2
00007d3d13bd47c7  vmovaps [rsp+0x30], xmm3
00007d3d13bd47cd  vmovaps [rsp+0x40], xmm4
00007d3d13bd47d3  vmovaps [rsp+0x50], xmm5
00007d3d13bd47d9  vmovaps [rsp+0x60], xmm6
00007d3d13bd47df  vmovaps [rsp+0x70], xmm7
00007d3d13bd47e5  vmovaps [rsp+0x80], xmm8
00007d3d13bd47ee  vmovaps [rsp+0x90], xmm9
00007d3d13bd47f7  vmovaps [rsp+0xA0], xmm10
00007d3d13bd4800  vmovaps [rsp+0xB0], xmm11
00007d3d13bd4809  vmovaps [rsp+0xC0], xmm12
00007d3d13bd4812  vmovaps [rsp+0xD0], xmm13
00007d3d13bd481b  vmovaps [rsp+0xE0], xmm15
00007d3d13bd4824  sub rsp, 0x30
00007d3d13bd4828  movaps [rsp], xmm14
00007d3d13bd482d  movaps [rsp+0x10], xmm2
00007d3d13bd4832  movaps [rsp+0x20], xmm15
00007d3d13bd4838  lea rdi, [rsp]
00007d3d13bd483c  mov esi, 0x00
00007d3d13bd4841  mov rax, 0x5741DAFC8530
00007d3d13bd484b  call rax
00007d3d13bd484d  movaps xmm14, [rsp]
00007d3d13bd4852  add rsp, 0x30
00007d3d13bd4856  vmovaps xmm0, [rsp]
00007d3d13bd485b  vmovaps xmm1, [rsp+0x10]
00007d3d13bd4861  vmovaps xmm2, [rsp+0x20]
00007d3d13bd4867  vmovaps xmm3, [rsp+0x30]
00007d3d13bd486d  vmovaps xmm4, [rsp+0x40]
00007d3d13bd4873  vmovaps xmm5, [rsp+0x50]
00007d3d13bd4879  vmovaps xmm6, [rsp+0x60]
00007d3d13bd487f  vmovaps xmm7, [rsp+0x70]
00007d3d13bd4885  vmovaps xmm8, [rsp+0x80]
00007d3d13bd488e  vmovaps xmm9, [rsp+0x90]
00007d3d13bd4897  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd48a0  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd48a9  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd48b2  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd48bb  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd48c4  add rsp, 0xF0
00007d3d13bd48cb  pop r11
00007d3d13bd48cd  pop r10
00007d3d13bd48cf  pop r9
00007d3d13bd48d1  pop r8
00007d3d13bd48d3  pop rsi
00007d3d13bd48d4  pop rdi
00007d3d13bd48d5  pop rdx
00007d3d13bd48d6  pop rcx
00007d3d13bd48d7  pop rax
00007d3d13bd48d8  add rsp, 0x08
00007d3d13bd48dc  jmp 0x00007D3D13BD2B05
00007d3d13bd48e1  sub rsp, 0x08
00007d3d13bd48e5  push rax
00007d3d13bd48e6  push rcx
00007d3d13bd48e7  push rdx
00007d3d13bd48e8  push rdi
00007d3d13bd48e9  push rsi
00007d3d13bd48ea  push r8
00007d3d13bd48ec  push r9
00007d3d13bd48ee  push r10
00007d3d13bd48f0  push r11
00007d3d13bd48f2  sub rsp, 0xF0
00007d3d13bd48f9  vmovaps [rsp], xmm0
00007d3d13bd48fe  vmovaps [rsp+0x10], xmm1
00007d3d13bd4904  vmovaps [rsp+0x20], xmm2
00007d3d13bd490a  vmovaps [rsp+0x30], xmm3
00007d3d13bd4910  vmovaps [rsp+0x40], xmm4
00007d3d13bd4916  vmovaps [rsp+0x50], xmm5
00007d3d13bd491c  vmovaps [rsp+0x60], xmm6
00007d3d13bd4922  vmovaps [rsp+0x70], xmm7
00007d3d13bd4928  vmovaps [rsp+0x80], xmm8
00007d3d13bd4931  vmovaps [rsp+0x90], xmm9
00007d3d13bd493a  vmovaps [rsp+0xA0], xmm10
00007d3d13bd4943  vmovaps [rsp+0xB0], xmm11
00007d3d13bd494c  vmovaps [rsp+0xC0], xmm12
00007d3d13bd4955  vmovaps [rsp+0xD0], xmm13
00007d3d13bd495e  vmovaps [rsp+0xE0], xmm14
00007d3d13bd4967  sub rsp, 0x30
00007d3d13bd496b  movaps [rsp], xmm15
00007d3d13bd4970  movaps [rsp+0x10], xmm2
00007d3d13bd4975  movaps [rsp+0x20], xmm1
00007d3d13bd497a  lea rdi, [rsp]
00007d3d13bd497e  mov esi, 0x00
00007d3d13bd4983  mov rax, 0x5741DAFC8530
00007d3d13bd498d  call rax
00007d3d13bd498f  movaps xmm15, [rsp]
00007d3d13bd4994  add rsp, 0x30
00007d3d13bd4998  vmovaps xmm0, [rsp]
00007d3d13bd499d  vmovaps xmm1, [rsp+0x10]
00007d3d13bd49a3  vmovaps xmm2, [rsp+0x20]
00007d3d13bd49a9  vmovaps xmm3, [rsp+0x30]
00007d3d13bd49af  vmovaps xmm4, [rsp+0x40]
00007d3d13bd49b5  vmovaps xmm5, [rsp+0x50]
00007d3d13bd49bb  vmovaps xmm6, [rsp+0x60]
00007d3d13bd49c1  vmovaps xmm7, [rsp+0x70]
00007d3d13bd49c7  vmovaps xmm8, [rsp+0x80]
00007d3d13bd49d0  vmovaps xmm9, [rsp+0x90]
00007d3d13bd49d9  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd49e2  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd49eb  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd49f4  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd49fd  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd4a06  add rsp, 0xF0
00007d3d13bd4a0d  pop r11
00007d3d13bd4a0f  pop r10
00007d3d13bd4a11  pop r9
00007d3d13bd4a13  pop r8
00007d3d13bd4a15  pop rsi
00007d3d13bd4a16  pop rdi
00007d3d13bd4a17  pop rdx
00007d3d13bd4a18  pop rcx
00007d3d13bd4a19  pop rax
00007d3d13bd4a1a  add rsp, 0x08
00007d3d13bd4a1e  jmp 0x00007D3D13BD2B41
00007d3d13bd4a23  call 0x00007D3D139FF430
00007d3d13bd4a28  jmp 0x00007D3D13BD2B4E
00007d3d13bd4a2d  sub rsp, 0x08
00007d3d13bd4a31  push rax
00007d3d13bd4a32  push rcx
00007d3d13bd4a33  push rdx
00007d3d13bd4a34  push rdi
00007d3d13bd4a35  push rsi
00007d3d13bd4a36  push r8
00007d3d13bd4a38  push r9
00007d3d13bd4a3a  push r10
00007d3d13bd4a3c  push r11
00007d3d13bd4a3e  sub rsp, 0xF0
00007d3d13bd4a45  vmovaps [rsp], xmm0
00007d3d13bd4a4a  vmovaps [rsp+0x10], xmm1
00007d3d13bd4a50  vmovaps [rsp+0x20], xmm3
00007d3d13bd4a56  vmovaps [rsp+0x30], xmm4
00007d3d13bd4a5c  vmovaps [rsp+0x40], xmm5
00007d3d13bd4a62  vmovaps [rsp+0x50], xmm6
00007d3d13bd4a68  vmovaps [rsp+0x60], xmm7
00007d3d13bd4a6e  vmovaps [rsp+0x70], xmm8
00007d3d13bd4a74  vmovaps [rsp+0x80], xmm9
00007d3d13bd4a7d  vmovaps [rsp+0x90], xmm10
00007d3d13bd4a86  vmovaps [rsp+0xA0], xmm11
00007d3d13bd4a8f  vmovaps [rsp+0xB0], xmm12
00007d3d13bd4a98  vmovaps [rsp+0xC0], xmm13
00007d3d13bd4aa1  vmovaps [rsp+0xD0], xmm14
00007d3d13bd4aaa  vmovaps [rsp+0xE0], xmm15
00007d3d13bd4ab3  sub rsp, 0x30
00007d3d13bd4ab7  movaps [rsp], xmm2
00007d3d13bd4abb  movaps [rsp+0x10], xmm1
00007d3d13bd4ac0  movaps [rsp+0x20], xmm14
00007d3d13bd4ac6  lea rdi, [rsp]
00007d3d13bd4aca  mov esi, 0x00
00007d3d13bd4acf  mov rax, 0x5741DAFC8530
00007d3d13bd4ad9  call rax
00007d3d13bd4adb  movaps xmm2, [rsp]
00007d3d13bd4adf  add rsp, 0x30
00007d3d13bd4ae3  vmovaps xmm0, [rsp]
00007d3d13bd4ae8  vmovaps xmm1, [rsp+0x10]
00007d3d13bd4aee  vmovaps xmm3, [rsp+0x20]
00007d3d13bd4af4  vmovaps xmm4, [rsp+0x30]
00007d3d13bd4afa  vmovaps xmm5, [rsp+0x40]
00007d3d13bd4b00  vmovaps xmm6, [rsp+0x50]
00007d3d13bd4b06  vmovaps xmm7, [rsp+0x60]
00007d3d13bd4b0c  vmovaps xmm8, [rsp+0x70]
00007d3d13bd4b12  vmovaps xmm9, [rsp+0x80]
00007d3d13bd4b1b  vmovaps xmm10, [rsp+0x90]
00007d3d13bd4b24  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd4b2d  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd4b36  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd4b3f  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd4b48  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd4b51  add rsp, 0xF0
00007d3d13bd4b58  pop r11
00007d3d13bd4b5a  pop r10
00007d3d13bd4b5c  pop r9
00007d3d13bd4b5e  pop r8
00007d3d13bd4b60  pop rsi
00007d3d13bd4b61  pop rdi
00007d3d13bd4b62  pop rdx
00007d3d13bd4b63  pop rcx
00007d3d13bd4b64  pop rax
00007d3d13bd4b65  add rsp, 0x08
00007d3d13bd4b69  jmp 0x00007D3D13BD2B8B
00007d3d13bd4b6e  sub rsp, 0x08
00007d3d13bd4b72  push rax
00007d3d13bd4b73  push rcx
00007d3d13bd4b74  push rdx
00007d3d13bd4b75  push rdi
00007d3d13bd4b76  push rsi
00007d3d13bd4b77  push r8
00007d3d13bd4b79  push r9
00007d3d13bd4b7b  push r10
00007d3d13bd4b7d  push r11
00007d3d13bd4b7f  sub rsp, 0xF0
00007d3d13bd4b86  vmovaps [rsp], xmm0
00007d3d13bd4b8b  vmovaps [rsp+0x10], xmm1
00007d3d13bd4b91  vmovaps [rsp+0x20], xmm2
00007d3d13bd4b97  vmovaps [rsp+0x30], xmm3
00007d3d13bd4b9d  vmovaps [rsp+0x40], xmm4
00007d3d13bd4ba3  vmovaps [rsp+0x50], xmm5
00007d3d13bd4ba9  vmovaps [rsp+0x60], xmm6
00007d3d13bd4baf  vmovaps [rsp+0x70], xmm7
00007d3d13bd4bb5  vmovaps [rsp+0x80], xmm8
00007d3d13bd4bbe  vmovaps [rsp+0x90], xmm9
00007d3d13bd4bc7  vmovaps [rsp+0xA0], xmm10
00007d3d13bd4bd0  vmovaps [rsp+0xB0], xmm11
00007d3d13bd4bd9  vmovaps [rsp+0xC0], xmm12
00007d3d13bd4be2  vmovaps [rsp+0xD0], xmm13
00007d3d13bd4beb  vmovaps [rsp+0xE0], xmm14
00007d3d13bd4bf4  sub rsp, 0x30
00007d3d13bd4bf8  movaps [rsp], xmm15
00007d3d13bd4bfd  movaps [rsp+0x10], xmm14
00007d3d13bd4c03  movaps [rsp+0x20], xmm1
00007d3d13bd4c08  lea rdi, [rsp]
00007d3d13bd4c0c  mov esi, 0x00
00007d3d13bd4c11  mov rax, 0x5741DAFC8530
00007d3d13bd4c1b  call rax
00007d3d13bd4c1d  movaps xmm15, [rsp]
00007d3d13bd4c22  add rsp, 0x30
00007d3d13bd4c26  vmovaps xmm0, [rsp]
00007d3d13bd4c2b  vmovaps xmm1, [rsp+0x10]
00007d3d13bd4c31  vmovaps xmm2, [rsp+0x20]
00007d3d13bd4c37  vmovaps xmm3, [rsp+0x30]
00007d3d13bd4c3d  vmovaps xmm4, [rsp+0x40]
00007d3d13bd4c43  vmovaps xmm5, [rsp+0x50]
00007d3d13bd4c49  vmovaps xmm6, [rsp+0x60]
00007d3d13bd4c4f  vmovaps xmm7, [rsp+0x70]
00007d3d13bd4c55  vmovaps xmm8, [rsp+0x80]
00007d3d13bd4c5e  vmovaps xmm9, [rsp+0x90]
00007d3d13bd4c67  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd4c70  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd4c79  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd4c82  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd4c8b  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd4c94  add rsp, 0xF0
00007d3d13bd4c9b  pop r11
00007d3d13bd4c9d  pop r10
00007d3d13bd4c9f  pop r9
00007d3d13bd4ca1  pop r8
00007d3d13bd4ca3  pop rsi
00007d3d13bd4ca4  pop rdi
00007d3d13bd4ca5  pop rdx
00007d3d13bd4ca6  pop rcx
00007d3d13bd4ca7  pop rax
00007d3d13bd4ca8  add rsp, 0x08
00007d3d13bd4cac  jmp 0x00007D3D13BD2C05
00007d3d13bd4cb1  call 0x00007D3D139FF430
00007d3d13bd4cb6  jmp 0x00007D3D13BD2C12
00007d3d13bd4cbb  sub rsp, 0x08
00007d3d13bd4cbf  push rax
00007d3d13bd4cc0  push rcx
00007d3d13bd4cc1  push rdx
00007d3d13bd4cc2  push rdi
00007d3d13bd4cc3  push rsi
00007d3d13bd4cc4  push r8
00007d3d13bd4cc6  push r9
00007d3d13bd4cc8  push r10
00007d3d13bd4cca  push r11
00007d3d13bd4ccc  sub rsp, 0xF0
00007d3d13bd4cd3  vmovaps [rsp], xmm0
00007d3d13bd4cd8  vmovaps [rsp+0x10], xmm1
00007d3d13bd4cde  vmovaps [rsp+0x20], xmm2
00007d3d13bd4ce4  vmovaps [rsp+0x30], xmm3
00007d3d13bd4cea  vmovaps [rsp+0x40], xmm4
00007d3d13bd4cf0  vmovaps [rsp+0x50], xmm5
00007d3d13bd4cf6  vmovaps [rsp+0x60], xmm6
00007d3d13bd4cfc  vmovaps [rsp+0x70], xmm7
00007d3d13bd4d02  vmovaps [rsp+0x80], xmm8
00007d3d13bd4d0b  vmovaps [rsp+0x90], xmm9
00007d3d13bd4d14  vmovaps [rsp+0xA0], xmm10
00007d3d13bd4d1d  vmovaps [rsp+0xB0], xmm11
00007d3d13bd4d26  vmovaps [rsp+0xC0], xmm12
00007d3d13bd4d2f  vmovaps [rsp+0xD0], xmm14
00007d3d13bd4d38  vmovaps [rsp+0xE0], xmm15
00007d3d13bd4d41  sub rsp, 0x30
00007d3d13bd4d45  movaps [rsp], xmm13
00007d3d13bd4d4a  movaps [rsp+0x10], xmm1
00007d3d13bd4d4f  movaps [rsp+0x20], xmm15
00007d3d13bd4d55  lea rdi, [rsp]
00007d3d13bd4d59  mov esi, 0x00
00007d3d13bd4d5e  mov rax, 0x5741DAFC8530
00007d3d13bd4d68  call rax
00007d3d13bd4d6a  movaps xmm13, [rsp]
00007d3d13bd4d6f  add rsp, 0x30
00007d3d13bd4d73  vmovaps xmm0, [rsp]
00007d3d13bd4d78  vmovaps xmm1, [rsp+0x10]
00007d3d13bd4d7e  vmovaps xmm2, [rsp+0x20]
00007d3d13bd4d84  vmovaps xmm3, [rsp+0x30]
00007d3d13bd4d8a  vmovaps xmm4, [rsp+0x40]
00007d3d13bd4d90  vmovaps xmm5, [rsp+0x50]
00007d3d13bd4d96  vmovaps xmm6, [rsp+0x60]
00007d3d13bd4d9c  vmovaps xmm7, [rsp+0x70]
00007d3d13bd4da2  vmovaps xmm8, [rsp+0x80]
00007d3d13bd4dab  vmovaps xmm9, [rsp+0x90]
00007d3d13bd4db4  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd4dbd  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd4dc6  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd4dcf  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd4dd8  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd4de1  add rsp, 0xF0
00007d3d13bd4de8  pop r11
00007d3d13bd4dea  pop r10
00007d3d13bd4dec  pop r9
00007d3d13bd4dee  pop r8
00007d3d13bd4df0  pop rsi
00007d3d13bd4df1  pop rdi
00007d3d13bd4df2  pop rdx
00007d3d13bd4df3  pop rcx
00007d3d13bd4df4  pop rax
00007d3d13bd4df5  add rsp, 0x08
00007d3d13bd4df9  jmp 0x00007D3D13BD2CD6
00007d3d13bd4dfe  sub rsp, 0x08
00007d3d13bd4e02  push rax
00007d3d13bd4e03  push rcx
00007d3d13bd4e04  push rdx
00007d3d13bd4e05  push rdi
00007d3d13bd4e06  push rsi
00007d3d13bd4e07  push r8
00007d3d13bd4e09  push r9
00007d3d13bd4e0b  push r10
00007d3d13bd4e0d  push r11
00007d3d13bd4e0f  sub rsp, 0xF0
00007d3d13bd4e16  vmovaps [rsp], xmm0
00007d3d13bd4e1b  vmovaps [rsp+0x10], xmm1
00007d3d13bd4e21  vmovaps [rsp+0x20], xmm2
00007d3d13bd4e27  vmovaps [rsp+0x30], xmm3
00007d3d13bd4e2d  vmovaps [rsp+0x40], xmm4
00007d3d13bd4e33  vmovaps [rsp+0x50], xmm5
00007d3d13bd4e39  vmovaps [rsp+0x60], xmm6
00007d3d13bd4e3f  vmovaps [rsp+0x70], xmm7
00007d3d13bd4e45  vmovaps [rsp+0x80], xmm8
00007d3d13bd4e4e  vmovaps [rsp+0x90], xmm9
00007d3d13bd4e57  vmovaps [rsp+0xA0], xmm10
00007d3d13bd4e60  vmovaps [rsp+0xB0], xmm11
00007d3d13bd4e69  vmovaps [rsp+0xC0], xmm12
00007d3d13bd4e72  vmovaps [rsp+0xD0], xmm13
00007d3d13bd4e7b  vmovaps [rsp+0xE0], xmm14
00007d3d13bd4e84  sub rsp, 0x30
00007d3d13bd4e88  movaps [rsp], xmm15
00007d3d13bd4e8d  movaps [rsp+0x10], xmm14
00007d3d13bd4e93  movaps [rsp+0x20], xmm1
00007d3d13bd4e98  lea rdi, [rsp]
00007d3d13bd4e9c  mov esi, 0x00
00007d3d13bd4ea1  mov rax, 0x5741DAFC8530
00007d3d13bd4eab  call rax
00007d3d13bd4ead  movaps xmm15, [rsp]
00007d3d13bd4eb2  add rsp, 0x30
00007d3d13bd4eb6  vmovaps xmm0, [rsp]
00007d3d13bd4ebb  vmovaps xmm1, [rsp+0x10]
00007d3d13bd4ec1  vmovaps xmm2, [rsp+0x20]
00007d3d13bd4ec7  vmovaps xmm3, [rsp+0x30]
00007d3d13bd4ecd  vmovaps xmm4, [rsp+0x40]
00007d3d13bd4ed3  vmovaps xmm5, [rsp+0x50]
00007d3d13bd4ed9  vmovaps xmm6, [rsp+0x60]
00007d3d13bd4edf  vmovaps xmm7, [rsp+0x70]
00007d3d13bd4ee5  vmovaps xmm8, [rsp+0x80]
00007d3d13bd4eee  vmovaps xmm9, [rsp+0x90]
00007d3d13bd4ef7  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd4f00  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd4f09  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd4f12  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd4f1b  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd4f24  add rsp, 0xF0
00007d3d13bd4f2b  pop r11
00007d3d13bd4f2d  pop r10
00007d3d13bd4f2f  pop r9
00007d3d13bd4f31  pop r8
00007d3d13bd4f33  pop rsi
00007d3d13bd4f34  pop rdi
00007d3d13bd4f35  pop rdx
00007d3d13bd4f36  pop rcx
00007d3d13bd4f37  pop rax
00007d3d13bd4f38  add rsp, 0x08
00007d3d13bd4f3c  jmp 0x00007D3D13BD2D12
00007d3d13bd4f41  call 0x00007D3D139FF430
00007d3d13bd4f46  jmp 0x00007D3D13BD2D1F
00007d3d13bd4f4b  sub rsp, 0x08
00007d3d13bd4f4f  push rax
00007d3d13bd4f50  push rcx
00007d3d13bd4f51  push rdx
00007d3d13bd4f52  push rdi
00007d3d13bd4f53  push rsi
00007d3d13bd4f54  push r8
00007d3d13bd4f56  push r9
00007d3d13bd4f58  push r10
00007d3d13bd4f5a  push r11
00007d3d13bd4f5c  sub rsp, 0xF0
00007d3d13bd4f63  vmovaps [rsp], xmm0
00007d3d13bd4f68  vmovaps [rsp+0x10], xmm1
00007d3d13bd4f6e  vmovaps [rsp+0x20], xmm2
00007d3d13bd4f74  vmovaps [rsp+0x30], xmm3
00007d3d13bd4f7a  vmovaps [rsp+0x40], xmm4
00007d3d13bd4f80  vmovaps [rsp+0x50], xmm5
00007d3d13bd4f86  vmovaps [rsp+0x60], xmm6
00007d3d13bd4f8c  vmovaps [rsp+0x70], xmm7
00007d3d13bd4f92  vmovaps [rsp+0x80], xmm8
00007d3d13bd4f9b  vmovaps [rsp+0x90], xmm9
00007d3d13bd4fa4  vmovaps [rsp+0xA0], xmm10
00007d3d13bd4fad  vmovaps [rsp+0xB0], xmm11
00007d3d13bd4fb6  vmovaps [rsp+0xC0], xmm12
00007d3d13bd4fbf  vmovaps [rsp+0xD0], xmm13
00007d3d13bd4fc8  vmovaps [rsp+0xE0], xmm15
00007d3d13bd4fd1  sub rsp, 0x30
00007d3d13bd4fd5  movaps [rsp], xmm14
00007d3d13bd4fda  movaps [rsp+0x10], xmm13
00007d3d13bd4fe0  movaps [rsp+0x20], xmm2
00007d3d13bd4fe5  lea rdi, [rsp]
00007d3d13bd4fe9  mov esi, 0x00
00007d3d13bd4fee  mov rax, 0x5741DAFC8530
00007d3d13bd4ff8  call rax
00007d3d13bd4ffa  movaps xmm14, [rsp]
00007d3d13bd4fff  add rsp, 0x30
00007d3d13bd5003  vmovaps xmm0, [rsp]
00007d3d13bd5008  vmovaps xmm1, [rsp+0x10]
00007d3d13bd500e  vmovaps xmm2, [rsp+0x20]
00007d3d13bd5014  vmovaps xmm3, [rsp+0x30]
00007d3d13bd501a  vmovaps xmm4, [rsp+0x40]
00007d3d13bd5020  vmovaps xmm5, [rsp+0x50]
00007d3d13bd5026  vmovaps xmm6, [rsp+0x60]
00007d3d13bd502c  vmovaps xmm7, [rsp+0x70]
00007d3d13bd5032  vmovaps xmm8, [rsp+0x80]
00007d3d13bd503b  vmovaps xmm9, [rsp+0x90]
00007d3d13bd5044  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd504d  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd5056  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd505f  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd5068  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd5071  add rsp, 0xF0
00007d3d13bd5078  pop r11
00007d3d13bd507a  pop r10
00007d3d13bd507c  pop r9
00007d3d13bd507e  pop r8
00007d3d13bd5080  pop rsi
00007d3d13bd5081  pop rdi
00007d3d13bd5082  pop rdx
00007d3d13bd5083  pop rcx
00007d3d13bd5084  pop rax
00007d3d13bd5085  add rsp, 0x08
00007d3d13bd5089  jmp 0x00007D3D13BD2D4B
00007d3d13bd508e  sub rsp, 0x08
00007d3d13bd5092  push rax
00007d3d13bd5093  push rcx
00007d3d13bd5094  push rdx
00007d3d13bd5095  push rdi
00007d3d13bd5096  push rsi
00007d3d13bd5097  push r8
00007d3d13bd5099  push r9
00007d3d13bd509b  push r10
00007d3d13bd509d  push r11
00007d3d13bd509f  sub rsp, 0xF0
00007d3d13bd50a6  vmovaps [rsp], xmm0
00007d3d13bd50ab  vmovaps [rsp+0x10], xmm2
00007d3d13bd50b1  vmovaps [rsp+0x20], xmm3
00007d3d13bd50b7  vmovaps [rsp+0x30], xmm4
00007d3d13bd50bd  vmovaps [rsp+0x40], xmm5
00007d3d13bd50c3  vmovaps [rsp+0x50], xmm6
00007d3d13bd50c9  vmovaps [rsp+0x60], xmm7
00007d3d13bd50cf  vmovaps [rsp+0x70], xmm8
00007d3d13bd50d5  vmovaps [rsp+0x80], xmm9
00007d3d13bd50de  vmovaps [rsp+0x90], xmm10
00007d3d13bd50e7  vmovaps [rsp+0xA0], xmm11
00007d3d13bd50f0  vmovaps [rsp+0xB0], xmm12
00007d3d13bd50f9  vmovaps [rsp+0xC0], xmm13
00007d3d13bd5102  vmovaps [rsp+0xD0], xmm14
00007d3d13bd510b  vmovaps [rsp+0xE0], xmm15
00007d3d13bd5114  sub rsp, 0x30
00007d3d13bd5118  movaps [rsp], xmm1
00007d3d13bd511c  movaps [rsp+0x10], xmm13
00007d3d13bd5122  movaps [rsp+0x20], xmm2
00007d3d13bd5127  lea rdi, [rsp]
00007d3d13bd512b  mov esi, 0x00
00007d3d13bd5130  mov rax, 0x5741DAFC8530
00007d3d13bd513a  call rax
00007d3d13bd513c  movaps xmm1, [rsp]
00007d3d13bd5140  add rsp, 0x30
00007d3d13bd5144  vmovaps xmm0, [rsp]
00007d3d13bd5149  vmovaps xmm2, [rsp+0x10]
00007d3d13bd514f  vmovaps xmm3, [rsp+0x20]
00007d3d13bd5155  vmovaps xmm4, [rsp+0x30]
00007d3d13bd515b  vmovaps xmm5, [rsp+0x40]
00007d3d13bd5161  vmovaps xmm6, [rsp+0x50]
00007d3d13bd5167  vmovaps xmm7, [rsp+0x60]
00007d3d13bd516d  vmovaps xmm8, [rsp+0x70]
00007d3d13bd5173  vmovaps xmm9, [rsp+0x80]
00007d3d13bd517c  vmovaps xmm10, [rsp+0x90]
00007d3d13bd5185  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd518e  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd5197  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd51a0  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd51a9  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd51b2  add rsp, 0xF0
00007d3d13bd51b9  pop r11
00007d3d13bd51bb  pop r10
00007d3d13bd51bd  pop r9
00007d3d13bd51bf  pop r8
00007d3d13bd51c1  pop rsi
00007d3d13bd51c2  pop rdi
00007d3d13bd51c3  pop rdx
00007d3d13bd51c4  pop rcx
00007d3d13bd51c5  pop rax
00007d3d13bd51c6  add rsp, 0x08
00007d3d13bd51ca  jmp 0x00007D3D13BD2D79
00007d3d13bd51cf  sub rsp, 0x08
00007d3d13bd51d3  push rax
00007d3d13bd51d4  push rcx
00007d3d13bd51d5  push rdx
00007d3d13bd51d6  push rdi
00007d3d13bd51d7  push rsi
00007d3d13bd51d8  push r8
00007d3d13bd51da  push r9
00007d3d13bd51dc  push r10
00007d3d13bd51de  push r11
00007d3d13bd51e0  sub rsp, 0xF0
00007d3d13bd51e7  vmovaps [rsp], xmm0
00007d3d13bd51ec  vmovaps [rsp+0x10], xmm1
00007d3d13bd51f2  vmovaps [rsp+0x20], xmm3
00007d3d13bd51f8  vmovaps [rsp+0x30], xmm4
00007d3d13bd51fe  vmovaps [rsp+0x40], xmm5
00007d3d13bd5204  vmovaps [rsp+0x50], xmm6
00007d3d13bd520a  vmovaps [rsp+0x60], xmm7
00007d3d13bd5210  vmovaps [rsp+0x70], xmm8
00007d3d13bd5216  vmovaps [rsp+0x80], xmm9
00007d3d13bd521f  vmovaps [rsp+0x90], xmm10
00007d3d13bd5228  vmovaps [rsp+0xA0], xmm11
00007d3d13bd5231  vmovaps [rsp+0xB0], xmm12
00007d3d13bd523a  vmovaps [rsp+0xC0], xmm13
00007d3d13bd5243  vmovaps [rsp+0xD0], xmm14
00007d3d13bd524c  vmovaps [rsp+0xE0], xmm15
00007d3d13bd5255  sub rsp, 0x30
00007d3d13bd5259  movaps [rsp], xmm2
00007d3d13bd525d  movaps [rsp+0x10], xmm1
00007d3d13bd5262  movaps [rsp+0x20], xmm13
00007d3d13bd5268  lea rdi, [rsp]
00007d3d13bd526c  mov esi, 0x00
00007d3d13bd5271  mov rax, 0x5741DAFC8530
00007d3d13bd527b  call rax
00007d3d13bd527d  movaps xmm2, [rsp]
00007d3d13bd5281  add rsp, 0x30
00007d3d13bd5285  vmovaps xmm0, [rsp]
00007d3d13bd528a  vmovaps xmm1, [rsp+0x10]
00007d3d13bd5290  vmovaps xmm3, [rsp+0x20]
00007d3d13bd5296  vmovaps xmm4, [rsp+0x30]
00007d3d13bd529c  vmovaps xmm5, [rsp+0x40]
00007d3d13bd52a2  vmovaps xmm6, [rsp+0x50]
00007d3d13bd52a8  vmovaps xmm7, [rsp+0x60]
00007d3d13bd52ae  vmovaps xmm8, [rsp+0x70]
00007d3d13bd52b4  vmovaps xmm9, [rsp+0x80]
00007d3d13bd52bd  vmovaps xmm10, [rsp+0x90]
00007d3d13bd52c6  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd52cf  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd52d8  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd52e1  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd52ea  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd52f3  add rsp, 0xF0
00007d3d13bd52fa  pop r11
00007d3d13bd52fc  pop r10
00007d3d13bd52fe  pop r9
00007d3d13bd5300  pop r8
00007d3d13bd5302  pop rsi
00007d3d13bd5303  pop rdi
00007d3d13bd5304  pop rdx
00007d3d13bd5305  pop rcx
00007d3d13bd5306  pop rax
00007d3d13bd5307  add rsp, 0x08
00007d3d13bd530b  jmp 0x00007D3D13BD2DD2
00007d3d13bd5310  call 0x00007D3D139FF430
00007d3d13bd5315  jmp 0x00007D3D13BD2DDF
00007d3d13bd531a  sub rsp, 0x08
00007d3d13bd531e  push rax
00007d3d13bd531f  push rcx
00007d3d13bd5320  push rdx
00007d3d13bd5321  push rdi
00007d3d13bd5322  push rsi
00007d3d13bd5323  push r8
00007d3d13bd5325  push r9
00007d3d13bd5327  push r10
00007d3d13bd5329  push r11
00007d3d13bd532b  sub rsp, 0xF0
00007d3d13bd5332  vmovaps [rsp], xmm0
00007d3d13bd5337  vmovaps [rsp+0x10], xmm1
00007d3d13bd533d  vmovaps [rsp+0x20], xmm2
00007d3d13bd5343  vmovaps [rsp+0x30], xmm3
00007d3d13bd5349  vmovaps [rsp+0x40], xmm4
00007d3d13bd534f  vmovaps [rsp+0x50], xmm5
00007d3d13bd5355  vmovaps [rsp+0x60], xmm6
00007d3d13bd535b  vmovaps [rsp+0x70], xmm7
00007d3d13bd5361  vmovaps [rsp+0x80], xmm8
00007d3d13bd536a  vmovaps [rsp+0x90], xmm9
00007d3d13bd5373  vmovaps [rsp+0xA0], xmm10
00007d3d13bd537c  vmovaps [rsp+0xB0], xmm11
00007d3d13bd5385  vmovaps [rsp+0xC0], xmm12
00007d3d13bd538e  vmovaps [rsp+0xD0], xmm13
00007d3d13bd5397  vmovaps [rsp+0xE0], xmm14
00007d3d13bd53a0  sub rsp, 0x30
00007d3d13bd53a4  movaps [rsp], xmm15
00007d3d13bd53a9  movaps [rsp+0x10], xmm13
00007d3d13bd53af  movaps [rsp+0x20], xmm1
00007d3d13bd53b4  lea rdi, [rsp]
00007d3d13bd53b8  mov esi, 0x00
00007d3d13bd53bd  mov rax, 0x5741DAFC8530
00007d3d13bd53c7  call rax
00007d3d13bd53c9  movaps xmm15, [rsp]
00007d3d13bd53ce  add rsp, 0x30
00007d3d13bd53d2  vmovaps xmm0, [rsp]
00007d3d13bd53d7  vmovaps xmm1, [rsp+0x10]
00007d3d13bd53dd  vmovaps xmm2, [rsp+0x20]
00007d3d13bd53e3  vmovaps xmm3, [rsp+0x30]
00007d3d13bd53e9  vmovaps xmm4, [rsp+0x40]
00007d3d13bd53ef  vmovaps xmm5, [rsp+0x50]
00007d3d13bd53f5  vmovaps xmm6, [rsp+0x60]
00007d3d13bd53fb  vmovaps xmm7, [rsp+0x70]
00007d3d13bd5401  vmovaps xmm8, [rsp+0x80]
00007d3d13bd540a  vmovaps xmm9, [rsp+0x90]
00007d3d13bd5413  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd541c  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd5425  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd542e  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd5437  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd5440  add rsp, 0xF0
00007d3d13bd5447  pop r11
00007d3d13bd5449  pop r10
00007d3d13bd544b  pop r9
00007d3d13bd544d  pop r8
00007d3d13bd544f  pop rsi
00007d3d13bd5450  pop rdi
00007d3d13bd5451  pop rdx
00007d3d13bd5452  pop rcx
00007d3d13bd5453  pop rax
00007d3d13bd5454  add rsp, 0x08
00007d3d13bd5458  jmp 0x00007D3D13BD2E1E
00007d3d13bd545d  sub rsp, 0x08
00007d3d13bd5461  push rax
00007d3d13bd5462  push rcx
00007d3d13bd5463  push rdx
00007d3d13bd5464  push rdi
00007d3d13bd5465  push rsi
00007d3d13bd5466  push r8
00007d3d13bd5468  push r9
00007d3d13bd546a  push r10
00007d3d13bd546c  push r11
00007d3d13bd546e  sub rsp, 0xF0
00007d3d13bd5475  vmovaps [rsp], xmm0
00007d3d13bd547a  vmovaps [rsp+0x10], xmm1
00007d3d13bd5480  vmovaps [rsp+0x20], xmm2
00007d3d13bd5486  vmovaps [rsp+0x30], xmm3
00007d3d13bd548c  vmovaps [rsp+0x40], xmm4
00007d3d13bd5492  vmovaps [rsp+0x50], xmm5
00007d3d13bd5498  vmovaps [rsp+0x60], xmm6
00007d3d13bd549e  vmovaps [rsp+0x70], xmm7
00007d3d13bd54a4  vmovaps [rsp+0x80], xmm8
00007d3d13bd54ad  vmovaps [rsp+0x90], xmm9
00007d3d13bd54b6  vmovaps [rsp+0xA0], xmm10
00007d3d13bd54bf  vmovaps [rsp+0xB0], xmm11
00007d3d13bd54c8  vmovaps [rsp+0xC0], xmm12
00007d3d13bd54d1  vmovaps [rsp+0xD0], xmm13
00007d3d13bd54da  vmovaps [rsp+0xE0], xmm15
00007d3d13bd54e3  sub rsp, 0x30
00007d3d13bd54e7  movaps [rsp], xmm14
00007d3d13bd54ec  movaps [rsp+0x10], xmm11
00007d3d13bd54f2  movaps [rsp+0x20], xmm1
00007d3d13bd54f7  lea rdi, [rsp]
00007d3d13bd54fb  mov esi, 0x00
00007d3d13bd5500  mov rax, 0x5741DAFC8530
00007d3d13bd550a  call rax
00007d3d13bd550c  movaps xmm14, [rsp]
00007d3d13bd5511  add rsp, 0x30
00007d3d13bd5515  vmovaps xmm0, [rsp]
00007d3d13bd551a  vmovaps xmm1, [rsp+0x10]
00007d3d13bd5520  vmovaps xmm2, [rsp+0x20]
00007d3d13bd5526  vmovaps xmm3, [rsp+0x30]
00007d3d13bd552c  vmovaps xmm4, [rsp+0x40]
00007d3d13bd5532  vmovaps xmm5, [rsp+0x50]
00007d3d13bd5538  vmovaps xmm6, [rsp+0x60]
00007d3d13bd553e  vmovaps xmm7, [rsp+0x70]
00007d3d13bd5544  vmovaps xmm8, [rsp+0x80]
00007d3d13bd554d  vmovaps xmm9, [rsp+0x90]
00007d3d13bd5556  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd555f  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd5568  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd5571  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd557a  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd5583  add rsp, 0xF0
00007d3d13bd558a  pop r11
00007d3d13bd558c  pop r10
00007d3d13bd558e  pop r9
00007d3d13bd5590  pop r8
00007d3d13bd5592  pop rsi
00007d3d13bd5593  pop rdi
00007d3d13bd5594  pop rdx
00007d3d13bd5595  pop rcx
00007d3d13bd5596  pop rax
00007d3d13bd5597  add rsp, 0x08
00007d3d13bd559b  jmp 0x00007D3D13BD2E48
00007d3d13bd55a0  sub rsp, 0x08
00007d3d13bd55a4  push rax
00007d3d13bd55a5  push rcx
00007d3d13bd55a6  push rdx
00007d3d13bd55a7  push rdi
00007d3d13bd55a8  push rsi
00007d3d13bd55a9  push r8
00007d3d13bd55ab  push r9
00007d3d13bd55ad  push r10
00007d3d13bd55af  push r11
00007d3d13bd55b1  sub rsp, 0xF0
00007d3d13bd55b8  vmovaps [rsp], xmm0
00007d3d13bd55bd  vmovaps [rsp+0x10], xmm1
00007d3d13bd55c3  vmovaps [rsp+0x20], xmm2
00007d3d13bd55c9  vmovaps [rsp+0x30], xmm3
00007d3d13bd55cf  vmovaps [rsp+0x40], xmm4
00007d3d13bd55d5  vmovaps [rsp+0x50], xmm5
00007d3d13bd55db  vmovaps [rsp+0x60], xmm6
00007d3d13bd55e1  vmovaps [rsp+0x70], xmm7
00007d3d13bd55e7  vmovaps [rsp+0x80], xmm8
00007d3d13bd55f0  vmovaps [rsp+0x90], xmm9
00007d3d13bd55f9  vmovaps [rsp+0xA0], xmm10
00007d3d13bd5602  vmovaps [rsp+0xB0], xmm11
00007d3d13bd560b  vmovaps [rsp+0xC0], xmm12
00007d3d13bd5614  vmovaps [rsp+0xD0], xmm14
00007d3d13bd561d  vmovaps [rsp+0xE0], xmm15
00007d3d13bd5626  sub rsp, 0x30
00007d3d13bd562a  movaps [rsp], xmm13
00007d3d13bd562f  movaps [rsp+0x10], xmm11
00007d3d13bd5635  movaps [rsp+0x20], xmm1
00007d3d13bd563a  lea rdi, [rsp]
00007d3d13bd563e  mov esi, 0x00
00007d3d13bd5643  mov rax, 0x5741DAFC8530
00007d3d13bd564d  call rax
00007d3d13bd564f  movaps xmm13, [rsp]
00007d3d13bd5654  add rsp, 0x30
00007d3d13bd5658  vmovaps xmm0, [rsp]
00007d3d13bd565d  vmovaps xmm1, [rsp+0x10]
00007d3d13bd5663  vmovaps xmm2, [rsp+0x20]
00007d3d13bd5669  vmovaps xmm3, [rsp+0x30]
00007d3d13bd566f  vmovaps xmm4, [rsp+0x40]
00007d3d13bd5675  vmovaps xmm5, [rsp+0x50]
00007d3d13bd567b  vmovaps xmm6, [rsp+0x60]
00007d3d13bd5681  vmovaps xmm7, [rsp+0x70]
00007d3d13bd5687  vmovaps xmm8, [rsp+0x80]
00007d3d13bd5690  vmovaps xmm9, [rsp+0x90]
00007d3d13bd5699  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd56a2  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd56ab  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd56b4  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd56bd  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd56c6  add rsp, 0xF0
00007d3d13bd56cd  pop r11
00007d3d13bd56cf  pop r10
00007d3d13bd56d1  pop r9
00007d3d13bd56d3  pop r8
00007d3d13bd56d5  pop rsi
00007d3d13bd56d6  pop rdi
00007d3d13bd56d7  pop rdx
00007d3d13bd56d8  pop rcx
00007d3d13bd56d9  pop rax
00007d3d13bd56da  add rsp, 0x08
00007d3d13bd56de  jmp 0x00007D3D13BD2E9D
00007d3d13bd56e3  call 0x00007D3D139FF430
00007d3d13bd56e8  jmp 0x00007D3D13BD2EAA
00007d3d13bd56ed  sub rsp, 0x08
00007d3d13bd56f1  push rax
00007d3d13bd56f2  push rcx
00007d3d13bd56f3  push rdx
00007d3d13bd56f4  push rdi
00007d3d13bd56f5  push rsi
00007d3d13bd56f6  push r8
00007d3d13bd56f8  push r9
00007d3d13bd56fa  push r10
00007d3d13bd56fc  push r11
00007d3d13bd56fe  sub rsp, 0xF0
00007d3d13bd5705  vmovaps [rsp], xmm0
00007d3d13bd570a  vmovaps [rsp+0x10], xmm1
00007d3d13bd5710  vmovaps [rsp+0x20], xmm2
00007d3d13bd5716  vmovaps [rsp+0x30], xmm3
00007d3d13bd571c  vmovaps [rsp+0x40], xmm4
00007d3d13bd5722  vmovaps [rsp+0x50], xmm5
00007d3d13bd5728  vmovaps [rsp+0x60], xmm6
00007d3d13bd572e  vmovaps [rsp+0x70], xmm7
00007d3d13bd5734  vmovaps [rsp+0x80], xmm8
00007d3d13bd573d  vmovaps [rsp+0x90], xmm9
00007d3d13bd5746  vmovaps [rsp+0xA0], xmm10
00007d3d13bd574f  vmovaps [rsp+0xB0], xmm11
00007d3d13bd5758  vmovaps [rsp+0xC0], xmm12
00007d3d13bd5761  vmovaps [rsp+0xD0], xmm13
00007d3d13bd576a  vmovaps [rsp+0xE0], xmm14
00007d3d13bd5773  sub rsp, 0x30
00007d3d13bd5777  movaps [rsp], xmm15
00007d3d13bd577c  movaps [rsp+0x10], xmm11
00007d3d13bd5782  movaps [rsp+0x20], xmm1
00007d3d13bd5787  lea rdi, [rsp]
00007d3d13bd578b  mov esi, 0x00
00007d3d13bd5790  mov rax, 0x5741DAFC8530
00007d3d13bd579a  call rax
00007d3d13bd579c  movaps xmm15, [rsp]
00007d3d13bd57a1  add rsp, 0x30
00007d3d13bd57a5  vmovaps xmm0, [rsp]
00007d3d13bd57aa  vmovaps xmm1, [rsp+0x10]
00007d3d13bd57b0  vmovaps xmm2, [rsp+0x20]
00007d3d13bd57b6  vmovaps xmm3, [rsp+0x30]
00007d3d13bd57bc  vmovaps xmm4, [rsp+0x40]
00007d3d13bd57c2  vmovaps xmm5, [rsp+0x50]
00007d3d13bd57c8  vmovaps xmm6, [rsp+0x60]
00007d3d13bd57ce  vmovaps xmm7, [rsp+0x70]
00007d3d13bd57d4  vmovaps xmm8, [rsp+0x80]
00007d3d13bd57dd  vmovaps xmm9, [rsp+0x90]
00007d3d13bd57e6  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd57ef  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd57f8  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd5801  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd580a  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd5813  add rsp, 0xF0
00007d3d13bd581a  pop r11
00007d3d13bd581c  pop r10
00007d3d13bd581e  pop r9
00007d3d13bd5820  pop r8
00007d3d13bd5822  pop rsi
00007d3d13bd5823  pop rdi
00007d3d13bd5824  pop rdx
00007d3d13bd5825  pop rcx
00007d3d13bd5826  pop rax
00007d3d13bd5827  add rsp, 0x08
00007d3d13bd582b  jmp 0x00007D3D13BD2EE3
00007d3d13bd5830  sub rsp, 0x08
00007d3d13bd5834  push rax
00007d3d13bd5835  push rcx
00007d3d13bd5836  push rdx
00007d3d13bd5837  push rdi
00007d3d13bd5838  push rsi
00007d3d13bd5839  push r8
00007d3d13bd583b  push r9
00007d3d13bd583d  push r10
00007d3d13bd583f  push r11
00007d3d13bd5841  sub rsp, 0xF0
00007d3d13bd5848  vmovaps [rsp], xmm0
00007d3d13bd584d  vmovaps [rsp+0x10], xmm1
00007d3d13bd5853  vmovaps [rsp+0x20], xmm2
00007d3d13bd5859  vmovaps [rsp+0x30], xmm3
00007d3d13bd585f  vmovaps [rsp+0x40], xmm4
00007d3d13bd5865  vmovaps [rsp+0x50], xmm5
00007d3d13bd586b  vmovaps [rsp+0x60], xmm6
00007d3d13bd5871  vmovaps [rsp+0x70], xmm7
00007d3d13bd5877  vmovaps [rsp+0x80], xmm8
00007d3d13bd5880  vmovaps [rsp+0x90], xmm9
00007d3d13bd5889  vmovaps [rsp+0xA0], xmm10
00007d3d13bd5892  vmovaps [rsp+0xB0], xmm12
00007d3d13bd589b  vmovaps [rsp+0xC0], xmm13
00007d3d13bd58a4  vmovaps [rsp+0xD0], xmm14
00007d3d13bd58ad  vmovaps [rsp+0xE0], xmm15
00007d3d13bd58b6  sub rsp, 0x30
00007d3d13bd58ba  movaps [rsp], xmm11
00007d3d13bd58bf  movaps [rsp+0x10], xmm6
00007d3d13bd58c4  movaps [rsp+0x20], xmm14
00007d3d13bd58ca  lea rdi, [rsp]
00007d3d13bd58ce  mov esi, 0x00
00007d3d13bd58d3  mov rax, 0x5741DAFC8530
00007d3d13bd58dd  call rax
00007d3d13bd58df  movaps xmm11, [rsp]
00007d3d13bd58e4  add rsp, 0x30
00007d3d13bd58e8  vmovaps xmm0, [rsp]
00007d3d13bd58ed  vmovaps xmm1, [rsp+0x10]
00007d3d13bd58f3  vmovaps xmm2, [rsp+0x20]
00007d3d13bd58f9  vmovaps xmm3, [rsp+0x30]
00007d3d13bd58ff  vmovaps xmm4, [rsp+0x40]
00007d3d13bd5905  vmovaps xmm5, [rsp+0x50]
00007d3d13bd590b  vmovaps xmm6, [rsp+0x60]
00007d3d13bd5911  vmovaps xmm7, [rsp+0x70]
00007d3d13bd5917  vmovaps xmm8, [rsp+0x80]
00007d3d13bd5920  vmovaps xmm9, [rsp+0x90]
00007d3d13bd5929  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd5932  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd593b  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd5944  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd594d  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd5956  add rsp, 0xF0
00007d3d13bd595d  pop r11
00007d3d13bd595f  pop r10
00007d3d13bd5961  pop r9
00007d3d13bd5963  pop r8
00007d3d13bd5965  pop rsi
00007d3d13bd5966  pop rdi
00007d3d13bd5967  pop rdx
00007d3d13bd5968  pop rcx
00007d3d13bd5969  pop rax
00007d3d13bd596a  add rsp, 0x08
00007d3d13bd596e  jmp 0x00007D3D13BD2F5B
00007d3d13bd5973  call 0x00007D3D139FF430
00007d3d13bd5978  jmp 0x00007D3D13BD2F65
00007d3d13bd597d  sub rsp, 0x08
00007d3d13bd5981  push rax
00007d3d13bd5982  push rcx
00007d3d13bd5983  push rdx
00007d3d13bd5984  push rdi
00007d3d13bd5985  push rsi
00007d3d13bd5986  push r8
00007d3d13bd5988  push r9
00007d3d13bd598a  push r10
00007d3d13bd598c  push r11
00007d3d13bd598e  sub rsp, 0xF0
00007d3d13bd5995  vmovaps [rsp], xmm0
00007d3d13bd599a  vmovaps [rsp+0x10], xmm1
00007d3d13bd59a0  vmovaps [rsp+0x20], xmm2
00007d3d13bd59a6  vmovaps [rsp+0x30], xmm3
00007d3d13bd59ac  vmovaps [rsp+0x40], xmm4
00007d3d13bd59b2  vmovaps [rsp+0x50], xmm5
00007d3d13bd59b8  vmovaps [rsp+0x60], xmm6
00007d3d13bd59be  vmovaps [rsp+0x70], xmm7
00007d3d13bd59c4  vmovaps [rsp+0x80], xmm8
00007d3d13bd59cd  vmovaps [rsp+0x90], xmm9
00007d3d13bd59d6  vmovaps [rsp+0xA0], xmm10
00007d3d13bd59df  vmovaps [rsp+0xB0], xmm11
00007d3d13bd59e8  vmovaps [rsp+0xC0], xmm12
00007d3d13bd59f1  vmovaps [rsp+0xD0], xmm13
00007d3d13bd59fa  vmovaps [rsp+0xE0], xmm15
00007d3d13bd5a03  sub rsp, 0x30
00007d3d13bd5a07  movaps [rsp], xmm14
00007d3d13bd5a0c  movaps [rsp+0x10], xmm6
00007d3d13bd5a11  movaps [rsp+0x20], xmm2
00007d3d13bd5a16  lea rdi, [rsp]
00007d3d13bd5a1a  mov esi, 0x00
00007d3d13bd5a1f  mov rax, 0x5741DAFC8530
00007d3d13bd5a29  call rax
00007d3d13bd5a2b  movaps xmm14, [rsp]
00007d3d13bd5a30  add rsp, 0x30
00007d3d13bd5a34  vmovaps xmm0, [rsp]
00007d3d13bd5a39  vmovaps xmm1, [rsp+0x10]
00007d3d13bd5a3f  vmovaps xmm2, [rsp+0x20]
00007d3d13bd5a45  vmovaps xmm3, [rsp+0x30]
00007d3d13bd5a4b  vmovaps xmm4, [rsp+0x40]
00007d3d13bd5a51  vmovaps xmm5, [rsp+0x50]
00007d3d13bd5a57  vmovaps xmm6, [rsp+0x60]
00007d3d13bd5a5d  vmovaps xmm7, [rsp+0x70]
00007d3d13bd5a63  vmovaps xmm8, [rsp+0x80]
00007d3d13bd5a6c  vmovaps xmm9, [rsp+0x90]
00007d3d13bd5a75  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd5a7e  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd5a87  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd5a90  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd5a99  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd5aa2  add rsp, 0xF0
00007d3d13bd5aa9  pop r11
00007d3d13bd5aab  pop r10
00007d3d13bd5aad  pop r9
00007d3d13bd5aaf  pop r8
00007d3d13bd5ab1  pop rsi
00007d3d13bd5ab2  pop rdi
00007d3d13bd5ab3  pop rdx
00007d3d13bd5ab4  pop rcx
00007d3d13bd5ab5  pop rax
00007d3d13bd5ab6  add rsp, 0x08
00007d3d13bd5aba  jmp 0x00007D3D13BD2F99
00007d3d13bd5abf  sub rsp, 0x08
00007d3d13bd5ac3  push rax
00007d3d13bd5ac4  push rcx
00007d3d13bd5ac5  push rdx
00007d3d13bd5ac6  push rdi
00007d3d13bd5ac7  push rsi
00007d3d13bd5ac8  push r8
00007d3d13bd5aca  push r9
00007d3d13bd5acc  push r10
00007d3d13bd5ace  push r11
00007d3d13bd5ad0  sub rsp, 0xF0
00007d3d13bd5ad7  vmovaps [rsp], xmm0
00007d3d13bd5adc  vmovaps [rsp+0x10], xmm1
00007d3d13bd5ae2  vmovaps [rsp+0x20], xmm2
00007d3d13bd5ae8  vmovaps [rsp+0x30], xmm3
00007d3d13bd5aee  vmovaps [rsp+0x40], xmm4
00007d3d13bd5af4  vmovaps [rsp+0x50], xmm5
00007d3d13bd5afa  vmovaps [rsp+0x60], xmm7
00007d3d13bd5b00  vmovaps [rsp+0x70], xmm8
00007d3d13bd5b06  vmovaps [rsp+0x80], xmm9
00007d3d13bd5b0f  vmovaps [rsp+0x90], xmm10
00007d3d13bd5b18  vmovaps [rsp+0xA0], xmm11
00007d3d13bd5b21  vmovaps [rsp+0xB0], xmm12
00007d3d13bd5b2a  vmovaps [rsp+0xC0], xmm13
00007d3d13bd5b33  vmovaps [rsp+0xD0], xmm14
00007d3d13bd5b3c  vmovaps [rsp+0xE0], xmm15
00007d3d13bd5b45  sub rsp, 0x30
00007d3d13bd5b49  movaps [rsp], xmm6
00007d3d13bd5b4d  movaps [rsp+0x10], xmm5
00007d3d13bd5b52  movaps [rsp+0x20], xmm1
00007d3d13bd5b57  lea rdi, [rsp]
00007d3d13bd5b5b  mov esi, 0x00
00007d3d13bd5b60  mov rax, 0x5741DAFC8530
00007d3d13bd5b6a  call rax
00007d3d13bd5b6c  movaps xmm6, [rsp]
00007d3d13bd5b70  add rsp, 0x30
00007d3d13bd5b74  vmovaps xmm0, [rsp]
00007d3d13bd5b79  vmovaps xmm1, [rsp+0x10]
00007d3d13bd5b7f  vmovaps xmm2, [rsp+0x20]
00007d3d13bd5b85  vmovaps xmm3, [rsp+0x30]
00007d3d13bd5b8b  vmovaps xmm4, [rsp+0x40]
00007d3d13bd5b91  vmovaps xmm5, [rsp+0x50]
00007d3d13bd5b97  vmovaps xmm7, [rsp+0x60]
00007d3d13bd5b9d  vmovaps xmm8, [rsp+0x70]
00007d3d13bd5ba3  vmovaps xmm9, [rsp+0x80]
00007d3d13bd5bac  vmovaps xmm10, [rsp+0x90]
00007d3d13bd5bb5  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd5bbe  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd5bc7  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd5bd0  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd5bd9  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd5be2  add rsp, 0xF0
00007d3d13bd5be9  pop r11
00007d3d13bd5beb  pop r10
00007d3d13bd5bed  pop r9
00007d3d13bd5bef  pop r8
00007d3d13bd5bf1  pop rsi
00007d3d13bd5bf2  pop rdi
00007d3d13bd5bf3  pop rdx
00007d3d13bd5bf4  pop rcx
00007d3d13bd5bf5  pop rax
00007d3d13bd5bf6  add rsp, 0x08
00007d3d13bd5bfa  jmp 0x00007D3D13BD2FBF
00007d3d13bd5bff  sub rsp, 0x08
00007d3d13bd5c03  push rax
00007d3d13bd5c04  push rcx
00007d3d13bd5c05  push rdx
00007d3d13bd5c06  push rdi
00007d3d13bd5c07  push rsi
00007d3d13bd5c08  push r8
00007d3d13bd5c0a  push r9
00007d3d13bd5c0c  push r10
00007d3d13bd5c0e  push r11
00007d3d13bd5c10  sub rsp, 0xF0
00007d3d13bd5c17  vmovaps [rsp], xmm0
00007d3d13bd5c1c  vmovaps [rsp+0x10], xmm2
00007d3d13bd5c22  vmovaps [rsp+0x20], xmm3
00007d3d13bd5c28  vmovaps [rsp+0x30], xmm4
00007d3d13bd5c2e  vmovaps [rsp+0x40], xmm5
00007d3d13bd5c34  vmovaps [rsp+0x50], xmm6
00007d3d13bd5c3a  vmovaps [rsp+0x60], xmm7
00007d3d13bd5c40  vmovaps [rsp+0x70], xmm8
00007d3d13bd5c46  vmovaps [rsp+0x80], xmm9
00007d3d13bd5c4f  vmovaps [rsp+0x90], xmm10
00007d3d13bd5c58  vmovaps [rsp+0xA0], xmm11
00007d3d13bd5c61  vmovaps [rsp+0xB0], xmm12
00007d3d13bd5c6a  vmovaps [rsp+0xC0], xmm13
00007d3d13bd5c73  vmovaps [rsp+0xD0], xmm14
00007d3d13bd5c7c  vmovaps [rsp+0xE0], xmm15
00007d3d13bd5c85  sub rsp, 0x30
00007d3d13bd5c89  movaps [rsp], xmm1
00007d3d13bd5c8d  movaps [rsp+0x10], xmm5
00007d3d13bd5c92  movaps [rsp+0x20], xmm13
00007d3d13bd5c98  lea rdi, [rsp]
00007d3d13bd5c9c  mov esi, 0x00
00007d3d13bd5ca1  mov rax, 0x5741DAFC8530
00007d3d13bd5cab  call rax
00007d3d13bd5cad  movaps xmm1, [rsp]
00007d3d13bd5cb1  add rsp, 0x30
00007d3d13bd5cb5  vmovaps xmm0, [rsp]
00007d3d13bd5cba  vmovaps xmm2, [rsp+0x10]
00007d3d13bd5cc0  vmovaps xmm3, [rsp+0x20]
00007d3d13bd5cc6  vmovaps xmm4, [rsp+0x30]
00007d3d13bd5ccc  vmovaps xmm5, [rsp+0x40]
00007d3d13bd5cd2  vmovaps xmm6, [rsp+0x50]
00007d3d13bd5cd8  vmovaps xmm7, [rsp+0x60]
00007d3d13bd5cde  vmovaps xmm8, [rsp+0x70]
00007d3d13bd5ce4  vmovaps xmm9, [rsp+0x80]
00007d3d13bd5ced  vmovaps xmm10, [rsp+0x90]
00007d3d13bd5cf6  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd5cff  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd5d08  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd5d11  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd5d1a  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd5d23  add rsp, 0xF0
00007d3d13bd5d2a  pop r11
00007d3d13bd5d2c  pop r10
00007d3d13bd5d2e  pop r9
00007d3d13bd5d30  pop r8
00007d3d13bd5d32  pop rsi
00007d3d13bd5d33  pop rdi
00007d3d13bd5d34  pop rdx
00007d3d13bd5d35  pop rcx
00007d3d13bd5d36  pop rax
00007d3d13bd5d37  add rsp, 0x08
00007d3d13bd5d3b  jmp 0x00007D3D13BD2FDD
00007d3d13bd5d40  sub rsp, 0x08
00007d3d13bd5d44  push rax
00007d3d13bd5d45  push rcx
00007d3d13bd5d46  push rdx
00007d3d13bd5d47  push rdi
00007d3d13bd5d48  push rsi
00007d3d13bd5d49  push r8
00007d3d13bd5d4b  push r9
00007d3d13bd5d4d  push r10
00007d3d13bd5d4f  push r11
00007d3d13bd5d51  sub rsp, 0xF0
00007d3d13bd5d58  vmovaps [rsp], xmm0
00007d3d13bd5d5d  vmovaps [rsp+0x10], xmm1
00007d3d13bd5d63  vmovaps [rsp+0x20], xmm2
00007d3d13bd5d69  vmovaps [rsp+0x30], xmm3
00007d3d13bd5d6f  vmovaps [rsp+0x40], xmm4
00007d3d13bd5d75  vmovaps [rsp+0x50], xmm6
00007d3d13bd5d7b  vmovaps [rsp+0x60], xmm7
00007d3d13bd5d81  vmovaps [rsp+0x70], xmm8
00007d3d13bd5d87  vmovaps [rsp+0x80], xmm9
00007d3d13bd5d90  vmovaps [rsp+0x90], xmm10
00007d3d13bd5d99  vmovaps [rsp+0xA0], xmm11
00007d3d13bd5da2  vmovaps [rsp+0xB0], xmm12
00007d3d13bd5dab  vmovaps [rsp+0xC0], xmm13
00007d3d13bd5db4  vmovaps [rsp+0xD0], xmm14
00007d3d13bd5dbd  vmovaps [rsp+0xE0], xmm15
00007d3d13bd5dc6  sub rsp, 0x30
00007d3d13bd5dca  movaps [rsp], xmm5
00007d3d13bd5dce  movaps [rsp+0x10], xmm2
00007d3d13bd5dd3  movaps [rsp+0x20], xmm13
00007d3d13bd5dd9  lea rdi, [rsp]
00007d3d13bd5ddd  mov esi, 0x00
00007d3d13bd5de2  mov rax, 0x5741DAFC8530
00007d3d13bd5dec  call rax
00007d3d13bd5dee  movaps xmm5, [rsp]
00007d3d13bd5df2  add rsp, 0x30
00007d3d13bd5df6  vmovaps xmm0, [rsp]
00007d3d13bd5dfb  vmovaps xmm1, [rsp+0x10]
00007d3d13bd5e01  vmovaps xmm2, [rsp+0x20]
00007d3d13bd5e07  vmovaps xmm3, [rsp+0x30]
00007d3d13bd5e0d  vmovaps xmm4, [rsp+0x40]
00007d3d13bd5e13  vmovaps xmm6, [rsp+0x50]
00007d3d13bd5e19  vmovaps xmm7, [rsp+0x60]
00007d3d13bd5e1f  vmovaps xmm8, [rsp+0x70]
00007d3d13bd5e25  vmovaps xmm9, [rsp+0x80]
00007d3d13bd5e2e  vmovaps xmm10, [rsp+0x90]
00007d3d13bd5e37  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd5e40  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd5e49  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd5e52  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd5e5b  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd5e64  add rsp, 0xF0
00007d3d13bd5e6b  pop r11
00007d3d13bd5e6d  pop r10
00007d3d13bd5e6f  pop r9
00007d3d13bd5e71  pop r8
00007d3d13bd5e73  pop rsi
00007d3d13bd5e74  pop rdi
00007d3d13bd5e75  pop rdx
00007d3d13bd5e76  pop rcx
00007d3d13bd5e77  pop rax
00007d3d13bd5e78  add rsp, 0x08
00007d3d13bd5e7c  jmp 0x00007D3D13BD3013
00007d3d13bd5e81  sub rsp, 0x08
00007d3d13bd5e85  push rax
00007d3d13bd5e86  push rcx
00007d3d13bd5e87  push rdx
00007d3d13bd5e88  push rdi
00007d3d13bd5e89  push rsi
00007d3d13bd5e8a  push r8
00007d3d13bd5e8c  push r9
00007d3d13bd5e8e  push r10
00007d3d13bd5e90  push r11
00007d3d13bd5e92  sub rsp, 0xF0
00007d3d13bd5e99  vmovaps [rsp], xmm0
00007d3d13bd5e9e  vmovaps [rsp+0x10], xmm1
00007d3d13bd5ea4  vmovaps [rsp+0x20], xmm2
00007d3d13bd5eaa  vmovaps [rsp+0x30], xmm3
00007d3d13bd5eb0  vmovaps [rsp+0x40], xmm4
00007d3d13bd5eb6  vmovaps [rsp+0x50], xmm5
00007d3d13bd5ebc  vmovaps [rsp+0x60], xmm6
00007d3d13bd5ec2  vmovaps [rsp+0x70], xmm7
00007d3d13bd5ec8  vmovaps [rsp+0x80], xmm8
00007d3d13bd5ed1  vmovaps [rsp+0x90], xmm9
00007d3d13bd5eda  vmovaps [rsp+0xA0], xmm10
00007d3d13bd5ee3  vmovaps [rsp+0xB0], xmm11
00007d3d13bd5eec  vmovaps [rsp+0xC0], xmm12
00007d3d13bd5ef5  vmovaps [rsp+0xD0], xmm14
00007d3d13bd5efe  vmovaps [rsp+0xE0], xmm15
00007d3d13bd5f07  sub rsp, 0x30
00007d3d13bd5f0b  movaps [rsp], xmm13
00007d3d13bd5f10  movaps [rsp+0x10], xmm10
00007d3d13bd5f16  movaps [rsp+0x20], xmm1
00007d3d13bd5f1b  lea rdi, [rsp]
00007d3d13bd5f1f  mov esi, 0x00
00007d3d13bd5f24  mov rax, 0x5741DAFC8530
00007d3d13bd5f2e  call rax
00007d3d13bd5f30  movaps xmm13, [rsp]
00007d3d13bd5f35  add rsp, 0x30
00007d3d13bd5f39  vmovaps xmm0, [rsp]
00007d3d13bd5f3e  vmovaps xmm1, [rsp+0x10]
00007d3d13bd5f44  vmovaps xmm2, [rsp+0x20]
00007d3d13bd5f4a  vmovaps xmm3, [rsp+0x30]
00007d3d13bd5f50  vmovaps xmm4, [rsp+0x40]
00007d3d13bd5f56  vmovaps xmm5, [rsp+0x50]
00007d3d13bd5f5c  vmovaps xmm6, [rsp+0x60]
00007d3d13bd5f62  vmovaps xmm7, [rsp+0x70]
00007d3d13bd5f68  vmovaps xmm8, [rsp+0x80]
00007d3d13bd5f71  vmovaps xmm9, [rsp+0x90]
00007d3d13bd5f7a  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd5f83  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd5f8c  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd5f95  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd5f9e  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd5fa7  add rsp, 0xF0
00007d3d13bd5fae  pop r11
00007d3d13bd5fb0  pop r10
00007d3d13bd5fb2  pop r9
00007d3d13bd5fb4  pop r8
00007d3d13bd5fb6  pop rsi
00007d3d13bd5fb7  pop rdi
00007d3d13bd5fb8  pop rdx
00007d3d13bd5fb9  pop rcx
00007d3d13bd5fba  pop rax
00007d3d13bd5fbb  add rsp, 0x08
00007d3d13bd5fbf  jmp 0x00007D3D13BD303C
00007d3d13bd5fc4  sub rsp, 0x08
00007d3d13bd5fc8  push rax
00007d3d13bd5fc9  push rcx
00007d3d13bd5fca  push rdx
00007d3d13bd5fcb  push rdi
00007d3d13bd5fcc  push rsi
00007d3d13bd5fcd  push r8
00007d3d13bd5fcf  push r9
00007d3d13bd5fd1  push r10
00007d3d13bd5fd3  push r11
00007d3d13bd5fd5  sub rsp, 0xF0
00007d3d13bd5fdc  vmovaps [rsp], xmm0
00007d3d13bd5fe1  vmovaps [rsp+0x10], xmm2
00007d3d13bd5fe7  vmovaps [rsp+0x20], xmm3
00007d3d13bd5fed  vmovaps [rsp+0x30], xmm4
00007d3d13bd5ff3  vmovaps [rsp+0x40], xmm5
00007d3d13bd5ff9  vmovaps [rsp+0x50], xmm6
00007d3d13bd5fff  vmovaps [rsp+0x60], xmm7
00007d3d13bd6005  vmovaps [rsp+0x70], xmm8
00007d3d13bd600b  vmovaps [rsp+0x80], xmm9
00007d3d13bd6014  vmovaps [rsp+0x90], xmm10
00007d3d13bd601d  vmovaps [rsp+0xA0], xmm11
00007d3d13bd6026  vmovaps [rsp+0xB0], xmm12
00007d3d13bd602f  vmovaps [rsp+0xC0], xmm13
00007d3d13bd6038  vmovaps [rsp+0xD0], xmm14
00007d3d13bd6041  vmovaps [rsp+0xE0], xmm15
00007d3d13bd604a  sub rsp, 0x30
00007d3d13bd604e  movaps [rsp], xmm1
00007d3d13bd6052  movaps [rsp+0x10], xmm15
00007d3d13bd6058  movaps [rsp+0x20], xmm10
00007d3d13bd605e  lea rdi, [rsp]
00007d3d13bd6062  mov esi, 0x00
00007d3d13bd6067  mov rax, 0x5741DAFC8530
00007d3d13bd6071  call rax
00007d3d13bd6073  movaps xmm1, [rsp]
00007d3d13bd6077  add rsp, 0x30
00007d3d13bd607b  vmovaps xmm0, [rsp]
00007d3d13bd6080  vmovaps xmm2, [rsp+0x10]
00007d3d13bd6086  vmovaps xmm3, [rsp+0x20]
00007d3d13bd608c  vmovaps xmm4, [rsp+0x30]
00007d3d13bd6092  vmovaps xmm5, [rsp+0x40]
00007d3d13bd6098  vmovaps xmm6, [rsp+0x50]
00007d3d13bd609e  vmovaps xmm7, [rsp+0x60]
00007d3d13bd60a4  vmovaps xmm8, [rsp+0x70]
00007d3d13bd60aa  vmovaps xmm9, [rsp+0x80]
00007d3d13bd60b3  vmovaps xmm10, [rsp+0x90]
00007d3d13bd60bc  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd60c5  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd60ce  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd60d7  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd60e0  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd60e9  add rsp, 0xF0
00007d3d13bd60f0  pop r11
00007d3d13bd60f2  pop r10
00007d3d13bd60f4  pop r9
00007d3d13bd60f6  pop r8
00007d3d13bd60f8  pop rsi
00007d3d13bd60f9  pop rdi
00007d3d13bd60fa  pop rdx
00007d3d13bd60fb  pop rcx
00007d3d13bd60fc  pop rax
00007d3d13bd60fd  add rsp, 0x08
00007d3d13bd6101  jmp 0x00007D3D13BD305B
00007d3d13bd6106  sub rsp, 0x08
00007d3d13bd610a  push rax
00007d3d13bd610b  push rcx
00007d3d13bd610c  push rdx
00007d3d13bd610d  push rdi
00007d3d13bd610e  push rsi
00007d3d13bd610f  push r8
00007d3d13bd6111  push r9
00007d3d13bd6113  push r10
00007d3d13bd6115  push r11
00007d3d13bd6117  sub rsp, 0xF0
00007d3d13bd611e  vmovaps [rsp], xmm0
00007d3d13bd6123  vmovaps [rsp+0x10], xmm1
00007d3d13bd6129  vmovaps [rsp+0x20], xmm2
00007d3d13bd612f  vmovaps [rsp+0x30], xmm3
00007d3d13bd6135  vmovaps [rsp+0x40], xmm4
00007d3d13bd613b  vmovaps [rsp+0x50], xmm5
00007d3d13bd6141  vmovaps [rsp+0x60], xmm6
00007d3d13bd6147  vmovaps [rsp+0x70], xmm7
00007d3d13bd614d  vmovaps [rsp+0x80], xmm8
00007d3d13bd6156  vmovaps [rsp+0x90], xmm9
00007d3d13bd615f  vmovaps [rsp+0xA0], xmm10
00007d3d13bd6168  vmovaps [rsp+0xB0], xmm11
00007d3d13bd6171  vmovaps [rsp+0xC0], xmm12
00007d3d13bd617a  vmovaps [rsp+0xD0], xmm13
00007d3d13bd6183  vmovaps [rsp+0xE0], xmm14
00007d3d13bd618c  sub rsp, 0x30
00007d3d13bd6190  movaps [rsp], xmm15
00007d3d13bd6195  movaps [rsp+0x10], xmm10
00007d3d13bd619b  movaps [rsp+0x20], xmm11
00007d3d13bd61a1  lea rdi, [rsp]
00007d3d13bd61a5  mov esi, 0x00
00007d3d13bd61aa  mov rax, 0x5741DAFC8530
00007d3d13bd61b4  call rax
00007d3d13bd61b6  movaps xmm15, [rsp]
00007d3d13bd61bb  add rsp, 0x30
00007d3d13bd61bf  vmovaps xmm0, [rsp]
00007d3d13bd61c4  vmovaps xmm1, [rsp+0x10]
00007d3d13bd61ca  vmovaps xmm2, [rsp+0x20]
00007d3d13bd61d0  vmovaps xmm3, [rsp+0x30]
00007d3d13bd61d6  vmovaps xmm4, [rsp+0x40]
00007d3d13bd61dc  vmovaps xmm5, [rsp+0x50]
00007d3d13bd61e2  vmovaps xmm6, [rsp+0x60]
00007d3d13bd61e8  vmovaps xmm7, [rsp+0x70]
00007d3d13bd61ee  vmovaps xmm8, [rsp+0x80]
00007d3d13bd61f7  vmovaps xmm9, [rsp+0x90]
00007d3d13bd6200  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd6209  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd6212  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd621b  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd6224  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd622d  add rsp, 0xF0
00007d3d13bd6234  pop r11
00007d3d13bd6236  pop r10
00007d3d13bd6238  pop r9
00007d3d13bd623a  pop r8
00007d3d13bd623c  pop rsi
00007d3d13bd623d  pop rdi
00007d3d13bd623e  pop rdx
00007d3d13bd623f  pop rcx
00007d3d13bd6240  pop rax
00007d3d13bd6241  add rsp, 0x08
00007d3d13bd6245  jmp 0x00007D3D13BD307E
00007d3d13bd624a  sub rsp, 0x08
00007d3d13bd624e  push rax
00007d3d13bd624f  push rcx
00007d3d13bd6250  push rdx
00007d3d13bd6251  push rdi
00007d3d13bd6252  push rsi
00007d3d13bd6253  push r8
00007d3d13bd6255  push r9
00007d3d13bd6257  push r10
00007d3d13bd6259  push r11
00007d3d13bd625b  sub rsp, 0xF0
00007d3d13bd6262  vmovaps [rsp], xmm0
00007d3d13bd6267  vmovaps [rsp+0x10], xmm1
00007d3d13bd626d  vmovaps [rsp+0x20], xmm2
00007d3d13bd6273  vmovaps [rsp+0x30], xmm3
00007d3d13bd6279  vmovaps [rsp+0x40], xmm4
00007d3d13bd627f  vmovaps [rsp+0x50], xmm5
00007d3d13bd6285  vmovaps [rsp+0x60], xmm6
00007d3d13bd628b  vmovaps [rsp+0x70], xmm7
00007d3d13bd6291  vmovaps [rsp+0x80], xmm8
00007d3d13bd629a  vmovaps [rsp+0x90], xmm9
00007d3d13bd62a3  vmovaps [rsp+0xA0], xmm11
00007d3d13bd62ac  vmovaps [rsp+0xB0], xmm12
00007d3d13bd62b5  vmovaps [rsp+0xC0], xmm13
00007d3d13bd62be  vmovaps [rsp+0xD0], xmm14
00007d3d13bd62c7  vmovaps [rsp+0xE0], xmm15
00007d3d13bd62d0  sub rsp, 0x30
00007d3d13bd62d4  movaps [rsp], xmm10
00007d3d13bd62d9  movaps [rsp+0x10], xmm2
00007d3d13bd62de  movaps [rsp+0x20], xmm11
00007d3d13bd62e4  lea rdi, [rsp]
00007d3d13bd62e8  mov esi, 0x00
00007d3d13bd62ed  mov rax, 0x5741DAFC8530
00007d3d13bd62f7  call rax
00007d3d13bd62f9  movaps xmm10, [rsp]
00007d3d13bd62fe  add rsp, 0x30
00007d3d13bd6302  vmovaps xmm0, [rsp]
00007d3d13bd6307  vmovaps xmm1, [rsp+0x10]
00007d3d13bd630d  vmovaps xmm2, [rsp+0x20]
00007d3d13bd6313  vmovaps xmm3, [rsp+0x30]
00007d3d13bd6319  vmovaps xmm4, [rsp+0x40]
00007d3d13bd631f  vmovaps xmm5, [rsp+0x50]
00007d3d13bd6325  vmovaps xmm6, [rsp+0x60]
00007d3d13bd632b  vmovaps xmm7, [rsp+0x70]
00007d3d13bd6331  vmovaps xmm8, [rsp+0x80]
00007d3d13bd633a  vmovaps xmm9, [rsp+0x90]
00007d3d13bd6343  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd634c  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd6355  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd635e  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd6367  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd6370  add rsp, 0xF0
00007d3d13bd6377  pop r11
00007d3d13bd6379  pop r10
00007d3d13bd637b  pop r9
00007d3d13bd637d  pop r8
00007d3d13bd637f  pop rsi
00007d3d13bd6380  pop rdi
00007d3d13bd6381  pop rdx
00007d3d13bd6382  pop rcx
00007d3d13bd6383  pop rax
00007d3d13bd6384  add rsp, 0x08
00007d3d13bd6388  jmp 0x00007D3D13BD30B6
00007d3d13bd638d  sub rsp, 0x08
00007d3d13bd6391  push rax
00007d3d13bd6392  push rcx
00007d3d13bd6393  push rdx
00007d3d13bd6394  push rdi
00007d3d13bd6395  push rsi
00007d3d13bd6396  push r8
00007d3d13bd6398  push r9
00007d3d13bd639a  push r10
00007d3d13bd639c  push r11
00007d3d13bd639e  sub rsp, 0xF0
00007d3d13bd63a5  vmovaps [rsp], xmm0
00007d3d13bd63aa  vmovaps [rsp+0x10], xmm1
00007d3d13bd63b0  vmovaps [rsp+0x20], xmm2
00007d3d13bd63b6  vmovaps [rsp+0x30], xmm3
00007d3d13bd63bc  vmovaps [rsp+0x40], xmm4
00007d3d13bd63c2  vmovaps [rsp+0x50], xmm5
00007d3d13bd63c8  vmovaps [rsp+0x60], xmm6
00007d3d13bd63ce  vmovaps [rsp+0x70], xmm7
00007d3d13bd63d4  vmovaps [rsp+0x80], xmm8
00007d3d13bd63dd  vmovaps [rsp+0x90], xmm9
00007d3d13bd63e6  vmovaps [rsp+0xA0], xmm10
00007d3d13bd63ef  vmovaps [rsp+0xB0], xmm12
00007d3d13bd63f8  vmovaps [rsp+0xC0], xmm13
00007d3d13bd6401  vmovaps [rsp+0xD0], xmm14
00007d3d13bd640a  vmovaps [rsp+0xE0], xmm15
00007d3d13bd6413  sub rsp, 0x30
00007d3d13bd6417  movaps [rsp], xmm11
00007d3d13bd641c  movaps [rsp+0x10], xmm2
00007d3d13bd6421  movaps [rsp+0x20], xmm1
00007d3d13bd6426  lea rdi, [rsp]
00007d3d13bd642a  mov esi, 0x00
00007d3d13bd642f  mov rax, 0x5741DAFC8530
00007d3d13bd6439  call rax
00007d3d13bd643b  movaps xmm11, [rsp]
00007d3d13bd6440  add rsp, 0x30
00007d3d13bd6444  vmovaps xmm0, [rsp]
00007d3d13bd6449  vmovaps xmm1, [rsp+0x10]
00007d3d13bd644f  vmovaps xmm2, [rsp+0x20]
00007d3d13bd6455  vmovaps xmm3, [rsp+0x30]
00007d3d13bd645b  vmovaps xmm4, [rsp+0x40]
00007d3d13bd6461  vmovaps xmm5, [rsp+0x50]
00007d3d13bd6467  vmovaps xmm6, [rsp+0x60]
00007d3d13bd646d  vmovaps xmm7, [rsp+0x70]
00007d3d13bd6473  vmovaps xmm8, [rsp+0x80]
00007d3d13bd647c  vmovaps xmm9, [rsp+0x90]
00007d3d13bd6485  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd648e  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd6497  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd64a0  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd64a9  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd64b2  add rsp, 0xF0
00007d3d13bd64b9  pop r11
00007d3d13bd64bb  pop r10
00007d3d13bd64bd  pop r9
00007d3d13bd64bf  pop r8
00007d3d13bd64c1  pop rsi
00007d3d13bd64c2  pop rdi
00007d3d13bd64c3  pop rdx
00007d3d13bd64c4  pop rcx
00007d3d13bd64c5  pop rax
00007d3d13bd64c6  add rsp, 0x08
00007d3d13bd64ca  jmp 0x00007D3D13BD30F2
00007d3d13bd64cf  sub rsp, 0x08
00007d3d13bd64d3  push rax
00007d3d13bd64d4  push rcx
00007d3d13bd64d5  push rdx
00007d3d13bd64d6  push rdi
00007d3d13bd64d7  push rsi
00007d3d13bd64d8  push r8
00007d3d13bd64da  push r9
00007d3d13bd64dc  push r10
00007d3d13bd64de  push r11
00007d3d13bd64e0  sub rsp, 0xF0
00007d3d13bd64e7  vmovaps [rsp], xmm0
00007d3d13bd64ec  vmovaps [rsp+0x10], xmm2
00007d3d13bd64f2  vmovaps [rsp+0x20], xmm3
00007d3d13bd64f8  vmovaps [rsp+0x30], xmm4
00007d3d13bd64fe  vmovaps [rsp+0x40], xmm5
00007d3d13bd6504  vmovaps [rsp+0x50], xmm6
00007d3d13bd650a  vmovaps [rsp+0x60], xmm7
00007d3d13bd6510  vmovaps [rsp+0x70], xmm8
00007d3d13bd6516  vmovaps [rsp+0x80], xmm9
00007d3d13bd651f  vmovaps [rsp+0x90], xmm10
00007d3d13bd6528  vmovaps [rsp+0xA0], xmm11
00007d3d13bd6531  vmovaps [rsp+0xB0], xmm12
00007d3d13bd653a  vmovaps [rsp+0xC0], xmm13
00007d3d13bd6543  vmovaps [rsp+0xD0], xmm14
00007d3d13bd654c  vmovaps [rsp+0xE0], xmm15
00007d3d13bd6555  sub rsp, 0x30
00007d3d13bd6559  movaps [rsp], xmm1
00007d3d13bd655d  movaps [rsp+0x10], xmm14
00007d3d13bd6563  movaps [rsp+0x20], xmm6
00007d3d13bd6568  lea rdi, [rsp]
00007d3d13bd656c  mov esi, 0x00
00007d3d13bd6571  mov rax, 0x5741DAFC8530
00007d3d13bd657b  call rax
00007d3d13bd657d  movaps xmm1, [rsp]
00007d3d13bd6581  add rsp, 0x30
00007d3d13bd6585  vmovaps xmm0, [rsp]
00007d3d13bd658a  vmovaps xmm2, [rsp+0x10]
00007d3d13bd6590  vmovaps xmm3, [rsp+0x20]
00007d3d13bd6596  vmovaps xmm4, [rsp+0x30]
00007d3d13bd659c  vmovaps xmm5, [rsp+0x40]
00007d3d13bd65a2  vmovaps xmm6, [rsp+0x50]
00007d3d13bd65a8  vmovaps xmm7, [rsp+0x60]
00007d3d13bd65ae  vmovaps xmm8, [rsp+0x70]
00007d3d13bd65b4  vmovaps xmm9, [rsp+0x80]
00007d3d13bd65bd  vmovaps xmm10, [rsp+0x90]
00007d3d13bd65c6  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd65cf  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd65d8  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd65e1  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd65ea  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd65f3  add rsp, 0xF0
00007d3d13bd65fa  pop r11
00007d3d13bd65fc  pop r10
00007d3d13bd65fe  pop r9
00007d3d13bd6600  pop r8
00007d3d13bd6602  pop rsi
00007d3d13bd6603  pop rdi
00007d3d13bd6604  pop rdx
00007d3d13bd6605  pop rcx
00007d3d13bd6606  pop rax
00007d3d13bd6607  add rsp, 0x08
00007d3d13bd660b  jmp 0x00007D3D13BD310B
00007d3d13bd6610  sub rsp, 0x08
00007d3d13bd6614  push rax
00007d3d13bd6615  push rcx
00007d3d13bd6616  push rdx
00007d3d13bd6617  push rdi
00007d3d13bd6618  push rsi
00007d3d13bd6619  push r8
00007d3d13bd661b  push r9
00007d3d13bd661d  push r10
00007d3d13bd661f  push r11
00007d3d13bd6621  sub rsp, 0xF0
00007d3d13bd6628  vmovaps [rsp], xmm0
00007d3d13bd662d  vmovaps [rsp+0x10], xmm1
00007d3d13bd6633  vmovaps [rsp+0x20], xmm2
00007d3d13bd6639  vmovaps [rsp+0x30], xmm3
00007d3d13bd663f  vmovaps [rsp+0x40], xmm4
00007d3d13bd6645  vmovaps [rsp+0x50], xmm5
00007d3d13bd664b  vmovaps [rsp+0x60], xmm6
00007d3d13bd6651  vmovaps [rsp+0x70], xmm7
00007d3d13bd6657  vmovaps [rsp+0x80], xmm8
00007d3d13bd6660  vmovaps [rsp+0x90], xmm9
00007d3d13bd6669  vmovaps [rsp+0xA0], xmm10
00007d3d13bd6672  vmovaps [rsp+0xB0], xmm11
00007d3d13bd667b  vmovaps [rsp+0xC0], xmm12
00007d3d13bd6684  vmovaps [rsp+0xD0], xmm13
00007d3d13bd668d  vmovaps [rsp+0xE0], xmm14
00007d3d13bd6696  sub rsp, 0x30
00007d3d13bd669a  movaps [rsp], xmm15
00007d3d13bd669f  movaps [rsp+0x10], xmm14
00007d3d13bd66a5  movaps [rsp+0x20], xmm5
00007d3d13bd66aa  lea rdi, [rsp]
00007d3d13bd66ae  mov esi, 0x00
00007d3d13bd66b3  mov rax, 0x5741DAFC8530
00007d3d13bd66bd  call rax
00007d3d13bd66bf  movaps xmm15, [rsp]
00007d3d13bd66c4  add rsp, 0x30
00007d3d13bd66c8  vmovaps xmm0, [rsp]
00007d3d13bd66cd  vmovaps xmm1, [rsp+0x10]
00007d3d13bd66d3  vmovaps xmm2, [rsp+0x20]
00007d3d13bd66d9  vmovaps xmm3, [rsp+0x30]
00007d3d13bd66df  vmovaps xmm4, [rsp+0x40]
00007d3d13bd66e5  vmovaps xmm5, [rsp+0x50]
00007d3d13bd66eb  vmovaps xmm6, [rsp+0x60]
00007d3d13bd66f1  vmovaps xmm7, [rsp+0x70]
00007d3d13bd66f7  vmovaps xmm8, [rsp+0x80]
00007d3d13bd6700  vmovaps xmm9, [rsp+0x90]
00007d3d13bd6709  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd6712  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd671b  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd6724  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd672d  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd6736  add rsp, 0xF0
00007d3d13bd673d  pop r11
00007d3d13bd673f  pop r10
00007d3d13bd6741  pop r9
00007d3d13bd6743  pop r8
00007d3d13bd6745  pop rsi
00007d3d13bd6746  pop rdi
00007d3d13bd6747  pop rdx
00007d3d13bd6748  pop rcx
00007d3d13bd6749  pop rax
00007d3d13bd674a  add rsp, 0x08
00007d3d13bd674e  jmp 0x00007D3D13BD312B
00007d3d13bd6753  sub rsp, 0x08
00007d3d13bd6757  push rax
00007d3d13bd6758  push rcx
00007d3d13bd6759  push rdx
00007d3d13bd675a  push rdi
00007d3d13bd675b  push rsi
00007d3d13bd675c  push r8
00007d3d13bd675e  push r9
00007d3d13bd6760  push r10
00007d3d13bd6762  push r11
00007d3d13bd6764  sub rsp, 0xF0
00007d3d13bd676b  vmovaps [rsp], xmm0
00007d3d13bd6770  vmovaps [rsp+0x10], xmm1
00007d3d13bd6776  vmovaps [rsp+0x20], xmm2
00007d3d13bd677c  vmovaps [rsp+0x30], xmm3
00007d3d13bd6782  vmovaps [rsp+0x40], xmm4
00007d3d13bd6788  vmovaps [rsp+0x50], xmm5
00007d3d13bd678e  vmovaps [rsp+0x60], xmm7
00007d3d13bd6794  vmovaps [rsp+0x70], xmm8
00007d3d13bd679a  vmovaps [rsp+0x80], xmm9
00007d3d13bd67a3  vmovaps [rsp+0x90], xmm10
00007d3d13bd67ac  vmovaps [rsp+0xA0], xmm11
00007d3d13bd67b5  vmovaps [rsp+0xB0], xmm12
00007d3d13bd67be  vmovaps [rsp+0xC0], xmm13
00007d3d13bd67c7  vmovaps [rsp+0xD0], xmm14
00007d3d13bd67d0  vmovaps [rsp+0xE0], xmm15
00007d3d13bd67d9  sub rsp, 0x30
00007d3d13bd67dd  movaps [rsp], xmm6
00007d3d13bd67e1  movaps [rsp+0x10], xmm9
00007d3d13bd67e7  movaps [rsp+0x20], xmm14
00007d3d13bd67ed  lea rdi, [rsp]
00007d3d13bd67f1  mov esi, 0x00
00007d3d13bd67f6  mov rax, 0x5741DAFC8530
00007d3d13bd6800  call rax
00007d3d13bd6802  movaps xmm6, [rsp]
00007d3d13bd6806  add rsp, 0x30
00007d3d13bd680a  vmovaps xmm0, [rsp]
00007d3d13bd680f  vmovaps xmm1, [rsp+0x10]
00007d3d13bd6815  vmovaps xmm2, [rsp+0x20]
00007d3d13bd681b  vmovaps xmm3, [rsp+0x30]
00007d3d13bd6821  vmovaps xmm4, [rsp+0x40]
00007d3d13bd6827  vmovaps xmm5, [rsp+0x50]
00007d3d13bd682d  vmovaps xmm7, [rsp+0x60]
00007d3d13bd6833  vmovaps xmm8, [rsp+0x70]
00007d3d13bd6839  vmovaps xmm9, [rsp+0x80]
00007d3d13bd6842  vmovaps xmm10, [rsp+0x90]
00007d3d13bd684b  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd6854  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd685d  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd6866  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd686f  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd6878  add rsp, 0xF0
00007d3d13bd687f  pop r11
00007d3d13bd6881  pop r10
00007d3d13bd6883  pop r9
00007d3d13bd6885  pop r8
00007d3d13bd6887  pop rsi
00007d3d13bd6888  pop rdi
00007d3d13bd6889  pop rdx
00007d3d13bd688a  pop rcx
00007d3d13bd688b  pop rax
00007d3d13bd688c  add rsp, 0x08
00007d3d13bd6890  jmp 0x00007D3D13BD3153
00007d3d13bd6895  sub rsp, 0x08
00007d3d13bd6899  push rax
00007d3d13bd689a  push rcx
00007d3d13bd689b  push rdx
00007d3d13bd689c  push rdi
00007d3d13bd689d  push rsi
00007d3d13bd689e  push r8
00007d3d13bd68a0  push r9
00007d3d13bd68a2  push r10
00007d3d13bd68a4  push r11
00007d3d13bd68a6  sub rsp, 0xF0
00007d3d13bd68ad  vmovaps [rsp], xmm0
00007d3d13bd68b2  vmovaps [rsp+0x10], xmm1
00007d3d13bd68b8  vmovaps [rsp+0x20], xmm2
00007d3d13bd68be  vmovaps [rsp+0x30], xmm3
00007d3d13bd68c4  vmovaps [rsp+0x40], xmm4
00007d3d13bd68ca  vmovaps [rsp+0x50], xmm5
00007d3d13bd68d0  vmovaps [rsp+0x60], xmm6
00007d3d13bd68d6  vmovaps [rsp+0x70], xmm7
00007d3d13bd68dc  vmovaps [rsp+0x80], xmm8
00007d3d13bd68e5  vmovaps [rsp+0x90], xmm9
00007d3d13bd68ee  vmovaps [rsp+0xA0], xmm10
00007d3d13bd68f7  vmovaps [rsp+0xB0], xmm11
00007d3d13bd6900  vmovaps [rsp+0xC0], xmm12
00007d3d13bd6909  vmovaps [rsp+0xD0], xmm13
00007d3d13bd6912  vmovaps [rsp+0xE0], xmm15
00007d3d13bd691b  sub rsp, 0x30
00007d3d13bd691f  movaps [rsp], xmm14
00007d3d13bd6924  movaps [rsp+0x10], xmm9
00007d3d13bd692a  movaps [rsp+0x20], xmm13
00007d3d13bd6930  lea rdi, [rsp]
00007d3d13bd6934  mov esi, 0x00
00007d3d13bd6939  mov rax, 0x5741DAFC8530
00007d3d13bd6943  call rax
00007d3d13bd6945  movaps xmm14, [rsp]
00007d3d13bd694a  add rsp, 0x30
00007d3d13bd694e  vmovaps xmm0, [rsp]
00007d3d13bd6953  vmovaps xmm1, [rsp+0x10]
00007d3d13bd6959  vmovaps xmm2, [rsp+0x20]
00007d3d13bd695f  vmovaps xmm3, [rsp+0x30]
00007d3d13bd6965  vmovaps xmm4, [rsp+0x40]
00007d3d13bd696b  vmovaps xmm5, [rsp+0x50]
00007d3d13bd6971  vmovaps xmm6, [rsp+0x60]
00007d3d13bd6977  vmovaps xmm7, [rsp+0x70]
00007d3d13bd697d  vmovaps xmm8, [rsp+0x80]
00007d3d13bd6986  vmovaps xmm9, [rsp+0x90]
00007d3d13bd698f  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd6998  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd69a1  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd69aa  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd69b3  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd69bc  add rsp, 0xF0
00007d3d13bd69c3  pop r11
00007d3d13bd69c5  pop r10
00007d3d13bd69c7  pop r9
00007d3d13bd69c9  pop r8
00007d3d13bd69cb  pop rsi
00007d3d13bd69cc  pop rdi
00007d3d13bd69cd  pop rdx
00007d3d13bd69ce  pop rcx
00007d3d13bd69cf  pop rax
00007d3d13bd69d0  add rsp, 0x08
00007d3d13bd69d4  jmp 0x00007D3D13BD3176
00007d3d13bd69d9  sub rsp, 0x08
00007d3d13bd69dd  push rax
00007d3d13bd69de  push rcx
00007d3d13bd69df  push rdx
00007d3d13bd69e0  push rdi
00007d3d13bd69e1  push rsi
00007d3d13bd69e2  push r8
00007d3d13bd69e4  push r9
00007d3d13bd69e6  push r10
00007d3d13bd69e8  push r11
00007d3d13bd69ea  sub rsp, 0xF0
00007d3d13bd69f1  vmovaps [rsp], xmm0
00007d3d13bd69f6  vmovaps [rsp+0x10], xmm1
00007d3d13bd69fc  vmovaps [rsp+0x20], xmm2
00007d3d13bd6a02  vmovaps [rsp+0x30], xmm3
00007d3d13bd6a08  vmovaps [rsp+0x40], xmm4
00007d3d13bd6a0e  vmovaps [rsp+0x50], xmm5
00007d3d13bd6a14  vmovaps [rsp+0x60], xmm6
00007d3d13bd6a1a  vmovaps [rsp+0x70], xmm7
00007d3d13bd6a20  vmovaps [rsp+0x80], xmm8
00007d3d13bd6a29  vmovaps [rsp+0x90], xmm9
00007d3d13bd6a32  vmovaps [rsp+0xA0], xmm10
00007d3d13bd6a3b  vmovaps [rsp+0xB0], xmm11
00007d3d13bd6a44  vmovaps [rsp+0xC0], xmm12
00007d3d13bd6a4d  vmovaps [rsp+0xD0], xmm14
00007d3d13bd6a56  vmovaps [rsp+0xE0], xmm15
00007d3d13bd6a5f  sub rsp, 0x30
00007d3d13bd6a63  movaps [rsp], xmm13
00007d3d13bd6a68  movaps [rsp+0x10], xmm9
00007d3d13bd6a6e  movaps [rsp+0x20], xmm10
00007d3d13bd6a74  lea rdi, [rsp]
00007d3d13bd6a78  mov esi, 0x00
00007d3d13bd6a7d  mov rax, 0x5741DAFC8530
00007d3d13bd6a87  call rax
00007d3d13bd6a89  movaps xmm13, [rsp]
00007d3d13bd6a8e  add rsp, 0x30
00007d3d13bd6a92  vmovaps xmm0, [rsp]
00007d3d13bd6a97  vmovaps xmm1, [rsp+0x10]
00007d3d13bd6a9d  vmovaps xmm2, [rsp+0x20]
00007d3d13bd6aa3  vmovaps xmm3, [rsp+0x30]
00007d3d13bd6aa9  vmovaps xmm4, [rsp+0x40]
00007d3d13bd6aaf  vmovaps xmm5, [rsp+0x50]
00007d3d13bd6ab5  vmovaps xmm6, [rsp+0x60]
00007d3d13bd6abb  vmovaps xmm7, [rsp+0x70]
00007d3d13bd6ac1  vmovaps xmm8, [rsp+0x80]
00007d3d13bd6aca  vmovaps xmm9, [rsp+0x90]
00007d3d13bd6ad3  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd6adc  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd6ae5  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd6aee  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd6af7  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd6b00  add rsp, 0xF0
00007d3d13bd6b07  pop r11
00007d3d13bd6b09  pop r10
00007d3d13bd6b0b  pop r9
00007d3d13bd6b0d  pop r8
00007d3d13bd6b0f  pop rsi
00007d3d13bd6b10  pop rdi
00007d3d13bd6b11  pop rdx
00007d3d13bd6b12  pop rcx
00007d3d13bd6b13  pop rax
00007d3d13bd6b14  add rsp, 0x08
00007d3d13bd6b18  jmp 0x00007D3D13BD3196
00007d3d13bd6b1d  call 0x00007D3D13A0AFE0
00007d3d13bd6b22  jmp 0x00007D3D13BD31EB
00007d3d13bd6b27  sub rsp, 0x08
00007d3d13bd6b2b  push rax
00007d3d13bd6b2c  push rcx
00007d3d13bd6b2d  push rdx
00007d3d13bd6b2e  push rdi
00007d3d13bd6b2f  push rsi
00007d3d13bd6b30  push r8
00007d3d13bd6b32  push r9
00007d3d13bd6b34  push r10
00007d3d13bd6b36  push r11
00007d3d13bd6b38  sub rsp, 0xF0
00007d3d13bd6b3f  vmovaps [rsp], xmm0
00007d3d13bd6b44  vmovaps [rsp+0x10], xmm1
00007d3d13bd6b4a  vmovaps [rsp+0x20], xmm2
00007d3d13bd6b50  vmovaps [rsp+0x30], xmm3
00007d3d13bd6b56  vmovaps [rsp+0x40], xmm4
00007d3d13bd6b5c  vmovaps [rsp+0x50], xmm5
00007d3d13bd6b62  vmovaps [rsp+0x60], xmm6
00007d3d13bd6b68  vmovaps [rsp+0x70], xmm7
00007d3d13bd6b6e  vmovaps [rsp+0x80], xmm8
00007d3d13bd6b77  vmovaps [rsp+0x90], xmm10
00007d3d13bd6b80  vmovaps [rsp+0xA0], xmm11
00007d3d13bd6b89  vmovaps [rsp+0xB0], xmm12
00007d3d13bd6b92  vmovaps [rsp+0xC0], xmm13
00007d3d13bd6b9b  vmovaps [rsp+0xD0], xmm14
00007d3d13bd6ba4  vmovaps [rsp+0xE0], xmm15
00007d3d13bd6bad  sub rsp, 0x30
00007d3d13bd6bb1  movaps [rsp], xmm9
00007d3d13bd6bb6  movaps [rsp+0x10], xmm8
00007d3d13bd6bbc  movaps [rsp+0x20], xmm10
00007d3d13bd6bc2  lea rdi, [rsp]
00007d3d13bd6bc6  mov esi, 0x00
00007d3d13bd6bcb  mov rax, 0x5741DAFC8530
00007d3d13bd6bd5  call rax
00007d3d13bd6bd7  movaps xmm9, [rsp]
00007d3d13bd6bdc  add rsp, 0x30
00007d3d13bd6be0  vmovaps xmm0, [rsp]
00007d3d13bd6be5  vmovaps xmm1, [rsp+0x10]
00007d3d13bd6beb  vmovaps xmm2, [rsp+0x20]
00007d3d13bd6bf1  vmovaps xmm3, [rsp+0x30]
00007d3d13bd6bf7  vmovaps xmm4, [rsp+0x40]
00007d3d13bd6bfd  vmovaps xmm5, [rsp+0x50]
00007d3d13bd6c03  vmovaps xmm6, [rsp+0x60]
00007d3d13bd6c09  vmovaps xmm7, [rsp+0x70]
00007d3d13bd6c0f  vmovaps xmm8, [rsp+0x80]
00007d3d13bd6c18  vmovaps xmm10, [rsp+0x90]
00007d3d13bd6c21  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd6c2a  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd6c33  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd6c3c  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd6c45  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd6c4e  add rsp, 0xF0
00007d3d13bd6c55  pop r11
00007d3d13bd6c57  pop r10
00007d3d13bd6c59  pop r9
00007d3d13bd6c5b  pop r8
00007d3d13bd6c5d  pop rsi
00007d3d13bd6c5e  pop rdi
00007d3d13bd6c5f  pop rdx
00007d3d13bd6c60  pop rcx
00007d3d13bd6c61  pop rax
00007d3d13bd6c62  add rsp, 0x08
00007d3d13bd6c66  jmp 0x00007D3D13BD321C
00007d3d13bd6c6b  sub rsp, 0x08
00007d3d13bd6c6f  push rax
00007d3d13bd6c70  push rcx
00007d3d13bd6c71  push rdx
00007d3d13bd6c72  push rdi
00007d3d13bd6c73  push rsi
00007d3d13bd6c74  push r8
00007d3d13bd6c76  push r9
00007d3d13bd6c78  push r10
00007d3d13bd6c7a  push r11
00007d3d13bd6c7c  sub rsp, 0xF0
00007d3d13bd6c83  vmovaps [rsp], xmm0
00007d3d13bd6c88  vmovaps [rsp+0x10], xmm1
00007d3d13bd6c8e  vmovaps [rsp+0x20], xmm2
00007d3d13bd6c94  vmovaps [rsp+0x30], xmm3
00007d3d13bd6c9a  vmovaps [rsp+0x40], xmm4
00007d3d13bd6ca0  vmovaps [rsp+0x50], xmm5
00007d3d13bd6ca6  vmovaps [rsp+0x60], xmm6
00007d3d13bd6cac  vmovaps [rsp+0x70], xmm7
00007d3d13bd6cb2  vmovaps [rsp+0x80], xmm8
00007d3d13bd6cbb  vmovaps [rsp+0x90], xmm9
00007d3d13bd6cc4  vmovaps [rsp+0xA0], xmm11
00007d3d13bd6ccd  vmovaps [rsp+0xB0], xmm12
00007d3d13bd6cd6  vmovaps [rsp+0xC0], xmm13
00007d3d13bd6cdf  vmovaps [rsp+0xD0], xmm14
00007d3d13bd6ce8  vmovaps [rsp+0xE0], xmm15
00007d3d13bd6cf1  sub rsp, 0x30
00007d3d13bd6cf5  movaps [rsp], xmm10
00007d3d13bd6cfa  movaps [rsp+0x10], xmm1
00007d3d13bd6cff  movaps [rsp+0x20], xmm11
00007d3d13bd6d05  lea rdi, [rsp]
00007d3d13bd6d09  mov esi, 0x00
00007d3d13bd6d0e  mov rax, 0x5741DAFC8530
00007d3d13bd6d18  call rax
00007d3d13bd6d1a  movaps xmm10, [rsp]
00007d3d13bd6d1f  add rsp, 0x30
00007d3d13bd6d23  vmovaps xmm0, [rsp]
00007d3d13bd6d28  vmovaps xmm1, [rsp+0x10]
00007d3d13bd6d2e  vmovaps xmm2, [rsp+0x20]
00007d3d13bd6d34  vmovaps xmm3, [rsp+0x30]
00007d3d13bd6d3a  vmovaps xmm4, [rsp+0x40]
00007d3d13bd6d40  vmovaps xmm5, [rsp+0x50]
00007d3d13bd6d46  vmovaps xmm6, [rsp+0x60]
00007d3d13bd6d4c  vmovaps xmm7, [rsp+0x70]
00007d3d13bd6d52  vmovaps xmm8, [rsp+0x80]
00007d3d13bd6d5b  vmovaps xmm9, [rsp+0x90]
00007d3d13bd6d64  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd6d6d  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd6d76  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd6d7f  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd6d88  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd6d91  add rsp, 0xF0
00007d3d13bd6d98  pop r11
00007d3d13bd6d9a  pop r10
00007d3d13bd6d9c  pop r9
00007d3d13bd6d9e  pop r8
00007d3d13bd6da0  pop rsi
00007d3d13bd6da1  pop rdi
00007d3d13bd6da2  pop rdx
00007d3d13bd6da3  pop rcx
00007d3d13bd6da4  pop rax
00007d3d13bd6da5  add rsp, 0x08
00007d3d13bd6da9  jmp 0x00007D3D13BD3237
00007d3d13bd6dae  sub rsp, 0x08
00007d3d13bd6db2  push rax
00007d3d13bd6db3  push rcx
00007d3d13bd6db4  push rdx
00007d3d13bd6db5  push rdi
00007d3d13bd6db6  push rsi
00007d3d13bd6db7  push r8
00007d3d13bd6db9  push r9
00007d3d13bd6dbb  push r10
00007d3d13bd6dbd  push r11
00007d3d13bd6dbf  sub rsp, 0xF0
00007d3d13bd6dc6  vmovaps [rsp], xmm0
00007d3d13bd6dcb  vmovaps [rsp+0x10], xmm2
00007d3d13bd6dd1  vmovaps [rsp+0x20], xmm3
00007d3d13bd6dd7  vmovaps [rsp+0x30], xmm4
00007d3d13bd6ddd  vmovaps [rsp+0x40], xmm5
00007d3d13bd6de3  vmovaps [rsp+0x50], xmm6
00007d3d13bd6de9  vmovaps [rsp+0x60], xmm7
00007d3d13bd6def  vmovaps [rsp+0x70], xmm8
00007d3d13bd6df5  vmovaps [rsp+0x80], xmm9
00007d3d13bd6dfe  vmovaps [rsp+0x90], xmm10
00007d3d13bd6e07  vmovaps [rsp+0xA0], xmm11
00007d3d13bd6e10  vmovaps [rsp+0xB0], xmm12
00007d3d13bd6e19  vmovaps [rsp+0xC0], xmm13
00007d3d13bd6e22  vmovaps [rsp+0xD0], xmm14
00007d3d13bd6e2b  vmovaps [rsp+0xE0], xmm15
00007d3d13bd6e34  sub rsp, 0x30
00007d3d13bd6e38  movaps [rsp], xmm1
00007d3d13bd6e3c  movaps [rsp+0x10], xmm15
00007d3d13bd6e42  movaps [rsp+0x20], xmm6
00007d3d13bd6e47  lea rdi, [rsp]
00007d3d13bd6e4b  mov esi, 0x00
00007d3d13bd6e50  mov rax, 0x5741DAFC8530
00007d3d13bd6e5a  call rax
00007d3d13bd6e5c  movaps xmm1, [rsp]
00007d3d13bd6e60  add rsp, 0x30
00007d3d13bd6e64  vmovaps xmm0, [rsp]
00007d3d13bd6e69  vmovaps xmm2, [rsp+0x10]
00007d3d13bd6e6f  vmovaps xmm3, [rsp+0x20]
00007d3d13bd6e75  vmovaps xmm4, [rsp+0x30]
00007d3d13bd6e7b  vmovaps xmm5, [rsp+0x40]
00007d3d13bd6e81  vmovaps xmm6, [rsp+0x50]
00007d3d13bd6e87  vmovaps xmm7, [rsp+0x60]
00007d3d13bd6e8d  vmovaps xmm8, [rsp+0x70]
00007d3d13bd6e93  vmovaps xmm9, [rsp+0x80]
00007d3d13bd6e9c  vmovaps xmm10, [rsp+0x90]
00007d3d13bd6ea5  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd6eae  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd6eb7  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd6ec0  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd6ec9  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd6ed2  add rsp, 0xF0
00007d3d13bd6ed9  pop r11
00007d3d13bd6edb  pop r10
00007d3d13bd6edd  pop r9
00007d3d13bd6edf  pop r8
00007d3d13bd6ee1  pop rsi
00007d3d13bd6ee2  pop rdi
00007d3d13bd6ee3  pop rdx
00007d3d13bd6ee4  pop rcx
00007d3d13bd6ee5  pop rax
00007d3d13bd6ee6  add rsp, 0x08
00007d3d13bd6eea  jmp 0x00007D3D13BD3250
00007d3d13bd6eef  sub rsp, 0x08
00007d3d13bd6ef3  push rax
00007d3d13bd6ef4  push rcx
00007d3d13bd6ef5  push rdx
00007d3d13bd6ef6  push rdi
00007d3d13bd6ef7  push rsi
00007d3d13bd6ef8  push r8
00007d3d13bd6efa  push r9
00007d3d13bd6efc  push r10
00007d3d13bd6efe  push r11
00007d3d13bd6f00  sub rsp, 0xF0
00007d3d13bd6f07  vmovaps [rsp], xmm0
00007d3d13bd6f0c  vmovaps [rsp+0x10], xmm1
00007d3d13bd6f12  vmovaps [rsp+0x20], xmm2
00007d3d13bd6f18  vmovaps [rsp+0x30], xmm3
00007d3d13bd6f1e  vmovaps [rsp+0x40], xmm4
00007d3d13bd6f24  vmovaps [rsp+0x50], xmm5
00007d3d13bd6f2a  vmovaps [rsp+0x60], xmm6
00007d3d13bd6f30  vmovaps [rsp+0x70], xmm7
00007d3d13bd6f36  vmovaps [rsp+0x80], xmm8
00007d3d13bd6f3f  vmovaps [rsp+0x90], xmm9
00007d3d13bd6f48  vmovaps [rsp+0xA0], xmm10
00007d3d13bd6f51  vmovaps [rsp+0xB0], xmm12
00007d3d13bd6f5a  vmovaps [rsp+0xC0], xmm13
00007d3d13bd6f63  vmovaps [rsp+0xD0], xmm14
00007d3d13bd6f6c  vmovaps [rsp+0xE0], xmm15
00007d3d13bd6f75  sub rsp, 0x30
00007d3d13bd6f79  movaps [rsp], xmm11
00007d3d13bd6f7e  movaps [rsp+0x10], xmm12
00007d3d13bd6f84  movaps [rsp+0x20], xmm15
00007d3d13bd6f8a  lea rdi, [rsp]
00007d3d13bd6f8e  mov esi, 0x00
00007d3d13bd6f93  mov rax, 0x5741DAFC8530
00007d3d13bd6f9d  call rax
00007d3d13bd6f9f  movaps xmm11, [rsp]
00007d3d13bd6fa4  add rsp, 0x30
00007d3d13bd6fa8  vmovaps xmm0, [rsp]
00007d3d13bd6fad  vmovaps xmm1, [rsp+0x10]
00007d3d13bd6fb3  vmovaps xmm2, [rsp+0x20]
00007d3d13bd6fb9  vmovaps xmm3, [rsp+0x30]
00007d3d13bd6fbf  vmovaps xmm4, [rsp+0x40]
00007d3d13bd6fc5  vmovaps xmm5, [rsp+0x50]
00007d3d13bd6fcb  vmovaps xmm6, [rsp+0x60]
00007d3d13bd6fd1  vmovaps xmm7, [rsp+0x70]
00007d3d13bd6fd7  vmovaps xmm8, [rsp+0x80]
00007d3d13bd6fe0  vmovaps xmm9, [rsp+0x90]
00007d3d13bd6fe9  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd6ff2  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd6ffb  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd7004  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd700d  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd7016  add rsp, 0xF0
00007d3d13bd701d  pop r11
00007d3d13bd701f  pop r10
00007d3d13bd7021  pop r9
00007d3d13bd7023  pop r8
00007d3d13bd7025  pop rsi
00007d3d13bd7026  pop rdi
00007d3d13bd7027  pop rdx
00007d3d13bd7028  pop rcx
00007d3d13bd7029  pop rax
00007d3d13bd702a  add rsp, 0x08
00007d3d13bd702e  jmp 0x00007D3D13BD327A
00007d3d13bd7033  sub rsp, 0x08
00007d3d13bd7037  push rax
00007d3d13bd7038  push rcx
00007d3d13bd7039  push rdx
00007d3d13bd703a  push rdi
00007d3d13bd703b  push rsi
00007d3d13bd703c  push r8
00007d3d13bd703e  push r9
00007d3d13bd7040  push r10
00007d3d13bd7042  push r11
00007d3d13bd7044  sub rsp, 0xF0
00007d3d13bd704b  vmovaps [rsp], xmm0
00007d3d13bd7050  vmovaps [rsp+0x10], xmm1
00007d3d13bd7056  vmovaps [rsp+0x20], xmm2
00007d3d13bd705c  vmovaps [rsp+0x30], xmm3
00007d3d13bd7062  vmovaps [rsp+0x40], xmm4
00007d3d13bd7068  vmovaps [rsp+0x50], xmm5
00007d3d13bd706e  vmovaps [rsp+0x60], xmm6
00007d3d13bd7074  vmovaps [rsp+0x70], xmm7
00007d3d13bd707a  vmovaps [rsp+0x80], xmm8
00007d3d13bd7083  vmovaps [rsp+0x90], xmm9
00007d3d13bd708c  vmovaps [rsp+0xA0], xmm10
00007d3d13bd7095  vmovaps [rsp+0xB0], xmm11
00007d3d13bd709e  vmovaps [rsp+0xC0], xmm13
00007d3d13bd70a7  vmovaps [rsp+0xD0], xmm14
00007d3d13bd70b0  vmovaps [rsp+0xE0], xmm15
00007d3d13bd70b9  sub rsp, 0x30
00007d3d13bd70bd  movaps [rsp], xmm12
00007d3d13bd70c2  movaps [rsp+0x10], xmm8
00007d3d13bd70c8  movaps [rsp+0x20], xmm15
00007d3d13bd70ce  lea rdi, [rsp]
00007d3d13bd70d2  mov esi, 0x00
00007d3d13bd70d7  mov rax, 0x5741DAFC8530
00007d3d13bd70e1  call rax
00007d3d13bd70e3  movaps xmm12, [rsp]
00007d3d13bd70e8  add rsp, 0x30
00007d3d13bd70ec  vmovaps xmm0, [rsp]
00007d3d13bd70f1  vmovaps xmm1, [rsp+0x10]
00007d3d13bd70f7  vmovaps xmm2, [rsp+0x20]
00007d3d13bd70fd  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7103  vmovaps xmm4, [rsp+0x40]
00007d3d13bd7109  vmovaps xmm5, [rsp+0x50]
00007d3d13bd710f  vmovaps xmm6, [rsp+0x60]
00007d3d13bd7115  vmovaps xmm7, [rsp+0x70]
00007d3d13bd711b  vmovaps xmm8, [rsp+0x80]
00007d3d13bd7124  vmovaps xmm9, [rsp+0x90]
00007d3d13bd712d  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd7136  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd713f  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd7148  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd7151  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd715a  add rsp, 0xF0
00007d3d13bd7161  pop r11
00007d3d13bd7163  pop r10
00007d3d13bd7165  pop r9
00007d3d13bd7167  pop r8
00007d3d13bd7169  pop rsi
00007d3d13bd716a  pop rdi
00007d3d13bd716b  pop rdx
00007d3d13bd716c  pop rcx
00007d3d13bd716d  pop rax
00007d3d13bd716e  add rsp, 0x08
00007d3d13bd7172  jmp 0x00007D3D13BD32A9
00007d3d13bd7177  sub rsp, 0x08
00007d3d13bd717b  push rax
00007d3d13bd717c  push rcx
00007d3d13bd717d  push rdx
00007d3d13bd717e  push rdi
00007d3d13bd717f  push rsi
00007d3d13bd7180  push r8
00007d3d13bd7182  push r9
00007d3d13bd7184  push r10
00007d3d13bd7186  push r11
00007d3d13bd7188  sub rsp, 0xF0
00007d3d13bd718f  vmovaps [rsp], xmm0
00007d3d13bd7194  vmovaps [rsp+0x10], xmm1
00007d3d13bd719a  vmovaps [rsp+0x20], xmm2
00007d3d13bd71a0  vmovaps [rsp+0x30], xmm3
00007d3d13bd71a6  vmovaps [rsp+0x40], xmm4
00007d3d13bd71ac  vmovaps [rsp+0x50], xmm5
00007d3d13bd71b2  vmovaps [rsp+0x60], xmm6
00007d3d13bd71b8  vmovaps [rsp+0x70], xmm7
00007d3d13bd71be  vmovaps [rsp+0x80], xmm9
00007d3d13bd71c7  vmovaps [rsp+0x90], xmm10
00007d3d13bd71d0  vmovaps [rsp+0xA0], xmm11
00007d3d13bd71d9  vmovaps [rsp+0xB0], xmm12
00007d3d13bd71e2  vmovaps [rsp+0xC0], xmm13
00007d3d13bd71eb  vmovaps [rsp+0xD0], xmm14
00007d3d13bd71f4  vmovaps [rsp+0xE0], xmm15
00007d3d13bd71fd  sub rsp, 0x30
00007d3d13bd7201  movaps [rsp], xmm8
00007d3d13bd7206  movaps [rsp+0x10], xmm7
00007d3d13bd720b  movaps [rsp+0x20], xmm15
00007d3d13bd7211  lea rdi, [rsp]
00007d3d13bd7215  mov esi, 0x00
00007d3d13bd721a  mov rax, 0x5741DAFC8530
00007d3d13bd7224  call rax
00007d3d13bd7226  movaps xmm8, [rsp]
00007d3d13bd722b  add rsp, 0x30
00007d3d13bd722f  vmovaps xmm0, [rsp]
00007d3d13bd7234  vmovaps xmm1, [rsp+0x10]
00007d3d13bd723a  vmovaps xmm2, [rsp+0x20]
00007d3d13bd7240  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7246  vmovaps xmm4, [rsp+0x40]
00007d3d13bd724c  vmovaps xmm5, [rsp+0x50]
00007d3d13bd7252  vmovaps xmm6, [rsp+0x60]
00007d3d13bd7258  vmovaps xmm7, [rsp+0x70]
00007d3d13bd725e  vmovaps xmm9, [rsp+0x80]
00007d3d13bd7267  vmovaps xmm10, [rsp+0x90]
00007d3d13bd7270  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd7279  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd7282  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd728b  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd7294  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd729d  add rsp, 0xF0
00007d3d13bd72a4  pop r11
00007d3d13bd72a6  pop r10
00007d3d13bd72a8  pop r9
00007d3d13bd72aa  pop r8
00007d3d13bd72ac  pop rsi
00007d3d13bd72ad  pop rdi
00007d3d13bd72ae  pop rdx
00007d3d13bd72af  pop rcx
00007d3d13bd72b0  pop rax
00007d3d13bd72b1  add rsp, 0x08
00007d3d13bd72b5  jmp 0x00007D3D13BD32CF
00007d3d13bd72ba  sub rsp, 0x08
00007d3d13bd72be  push rax
00007d3d13bd72bf  push rcx
00007d3d13bd72c0  push rdx
00007d3d13bd72c1  push rdi
00007d3d13bd72c2  push rsi
00007d3d13bd72c3  push r8
00007d3d13bd72c5  push r9
00007d3d13bd72c7  push r10
00007d3d13bd72c9  push r11
00007d3d13bd72cb  sub rsp, 0xF0
00007d3d13bd72d2  vmovaps [rsp], xmm0
00007d3d13bd72d7  vmovaps [rsp+0x10], xmm1
00007d3d13bd72dd  vmovaps [rsp+0x20], xmm2
00007d3d13bd72e3  vmovaps [rsp+0x30], xmm3
00007d3d13bd72e9  vmovaps [rsp+0x40], xmm4
00007d3d13bd72ef  vmovaps [rsp+0x50], xmm5
00007d3d13bd72f5  vmovaps [rsp+0x60], xmm6
00007d3d13bd72fb  vmovaps [rsp+0x70], xmm7
00007d3d13bd7301  vmovaps [rsp+0x80], xmm8
00007d3d13bd730a  vmovaps [rsp+0x90], xmm9
00007d3d13bd7313  vmovaps [rsp+0xA0], xmm10
00007d3d13bd731c  vmovaps [rsp+0xB0], xmm11
00007d3d13bd7325  vmovaps [rsp+0xC0], xmm12
00007d3d13bd732e  vmovaps [rsp+0xD0], xmm13
00007d3d13bd7337  vmovaps [rsp+0xE0], xmm14
00007d3d13bd7340  sub rsp, 0x30
00007d3d13bd7344  movaps [rsp], xmm15
00007d3d13bd7349  movaps [rsp+0x10], xmm14
00007d3d13bd734f  movaps [rsp+0x20], xmm9
00007d3d13bd7355  lea rdi, [rsp]
00007d3d13bd7359  mov esi, 0x00
00007d3d13bd735e  mov rax, 0x5741DAFC8530
00007d3d13bd7368  call rax
00007d3d13bd736a  movaps xmm15, [rsp]
00007d3d13bd736f  add rsp, 0x30
00007d3d13bd7373  vmovaps xmm0, [rsp]
00007d3d13bd7378  vmovaps xmm1, [rsp+0x10]
00007d3d13bd737e  vmovaps xmm2, [rsp+0x20]
00007d3d13bd7384  vmovaps xmm3, [rsp+0x30]
00007d3d13bd738a  vmovaps xmm4, [rsp+0x40]
00007d3d13bd7390  vmovaps xmm5, [rsp+0x50]
00007d3d13bd7396  vmovaps xmm6, [rsp+0x60]
00007d3d13bd739c  vmovaps xmm7, [rsp+0x70]
00007d3d13bd73a2  vmovaps xmm8, [rsp+0x80]
00007d3d13bd73ab  vmovaps xmm9, [rsp+0x90]
00007d3d13bd73b4  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd73bd  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd73c6  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd73cf  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd73d8  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd73e1  add rsp, 0xF0
00007d3d13bd73e8  pop r11
00007d3d13bd73ea  pop r10
00007d3d13bd73ec  pop r9
00007d3d13bd73ee  pop r8
00007d3d13bd73f0  pop rsi
00007d3d13bd73f1  pop rdi
00007d3d13bd73f2  pop rdx
00007d3d13bd73f3  pop rcx
00007d3d13bd73f4  pop rax
00007d3d13bd73f5  add rsp, 0x08
00007d3d13bd73f9  jmp 0x00007D3D13BD32E9
00007d3d13bd73fe  sub rsp, 0x08
00007d3d13bd7402  push rax
00007d3d13bd7403  push rcx
00007d3d13bd7404  push rdx
00007d3d13bd7405  push rdi
00007d3d13bd7406  push rsi
00007d3d13bd7407  push r8
00007d3d13bd7409  push r9
00007d3d13bd740b  push r10
00007d3d13bd740d  push r11
00007d3d13bd740f  sub rsp, 0xF0
00007d3d13bd7416  vmovaps [rsp], xmm0
00007d3d13bd741b  vmovaps [rsp+0x10], xmm1
00007d3d13bd7421  vmovaps [rsp+0x20], xmm2
00007d3d13bd7427  vmovaps [rsp+0x30], xmm3
00007d3d13bd742d  vmovaps [rsp+0x40], xmm4
00007d3d13bd7433  vmovaps [rsp+0x50], xmm5
00007d3d13bd7439  vmovaps [rsp+0x60], xmm6
00007d3d13bd743f  vmovaps [rsp+0x70], xmm7
00007d3d13bd7445  vmovaps [rsp+0x80], xmm8
00007d3d13bd744e  vmovaps [rsp+0x90], xmm10
00007d3d13bd7457  vmovaps [rsp+0xA0], xmm11
00007d3d13bd7460  vmovaps [rsp+0xB0], xmm12
00007d3d13bd7469  vmovaps [rsp+0xC0], xmm13
00007d3d13bd7472  vmovaps [rsp+0xD0], xmm14
00007d3d13bd747b  vmovaps [rsp+0xE0], xmm15
00007d3d13bd7484  sub rsp, 0x30
00007d3d13bd7488  movaps [rsp], xmm9
00007d3d13bd748d  movaps [rsp+0x10], xmm7
00007d3d13bd7492  movaps [rsp+0x20], xmm14
00007d3d13bd7498  lea rdi, [rsp]
00007d3d13bd749c  mov esi, 0x00
00007d3d13bd74a1  mov rax, 0x5741DAFC8530
00007d3d13bd74ab  call rax
00007d3d13bd74ad  movaps xmm9, [rsp]
00007d3d13bd74b2  add rsp, 0x30
00007d3d13bd74b6  vmovaps xmm0, [rsp]
00007d3d13bd74bb  vmovaps xmm1, [rsp+0x10]
00007d3d13bd74c1  vmovaps xmm2, [rsp+0x20]
00007d3d13bd74c7  vmovaps xmm3, [rsp+0x30]
00007d3d13bd74cd  vmovaps xmm4, [rsp+0x40]
00007d3d13bd74d3  vmovaps xmm5, [rsp+0x50]
00007d3d13bd74d9  vmovaps xmm6, [rsp+0x60]
00007d3d13bd74df  vmovaps xmm7, [rsp+0x70]
00007d3d13bd74e5  vmovaps xmm8, [rsp+0x80]
00007d3d13bd74ee  vmovaps xmm10, [rsp+0x90]
00007d3d13bd74f7  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd7500  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd7509  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd7512  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd751b  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd7524  add rsp, 0xF0
00007d3d13bd752b  pop r11
00007d3d13bd752d  pop r10
00007d3d13bd752f  pop r9
00007d3d13bd7531  pop r8
00007d3d13bd7533  pop rsi
00007d3d13bd7534  pop rdi
00007d3d13bd7535  pop rdx
00007d3d13bd7536  pop rcx
00007d3d13bd7537  pop rax
00007d3d13bd7538  add rsp, 0x08
00007d3d13bd753c  jmp 0x00007D3D13BD3318
00007d3d13bd7541  sub rsp, 0x08
00007d3d13bd7545  push rax
00007d3d13bd7546  push rcx
00007d3d13bd7547  push rdx
00007d3d13bd7548  push rdi
00007d3d13bd7549  push rsi
00007d3d13bd754a  push r8
00007d3d13bd754c  push r9
00007d3d13bd754e  push r10
00007d3d13bd7550  push r11
00007d3d13bd7552  sub rsp, 0xF0
00007d3d13bd7559  vmovaps [rsp], xmm0
00007d3d13bd755e  vmovaps [rsp+0x10], xmm1
00007d3d13bd7564  vmovaps [rsp+0x20], xmm2
00007d3d13bd756a  vmovaps [rsp+0x30], xmm3
00007d3d13bd7570  vmovaps [rsp+0x40], xmm4
00007d3d13bd7576  vmovaps [rsp+0x50], xmm5
00007d3d13bd757c  vmovaps [rsp+0x60], xmm6
00007d3d13bd7582  vmovaps [rsp+0x70], xmm7
00007d3d13bd7588  vmovaps [rsp+0x80], xmm8
00007d3d13bd7591  vmovaps [rsp+0x90], xmm9
00007d3d13bd759a  vmovaps [rsp+0xA0], xmm10
00007d3d13bd75a3  vmovaps [rsp+0xB0], xmm11
00007d3d13bd75ac  vmovaps [rsp+0xC0], xmm12
00007d3d13bd75b5  vmovaps [rsp+0xD0], xmm13
00007d3d13bd75be  vmovaps [rsp+0xE0], xmm15
00007d3d13bd75c7  sub rsp, 0x30
00007d3d13bd75cb  movaps [rsp], xmm14
00007d3d13bd75d0  movaps [rsp+0x10], xmm13
00007d3d13bd75d6  movaps [rsp+0x20], xmm11
00007d3d13bd75dc  lea rdi, [rsp]
00007d3d13bd75e0  mov esi, 0x00
00007d3d13bd75e5  mov rax, 0x5741DAFC8530
00007d3d13bd75ef  call rax
00007d3d13bd75f1  movaps xmm14, [rsp]
00007d3d13bd75f6  add rsp, 0x30
00007d3d13bd75fa  vmovaps xmm0, [rsp]
00007d3d13bd75ff  vmovaps xmm1, [rsp+0x10]
00007d3d13bd7605  vmovaps xmm2, [rsp+0x20]
00007d3d13bd760b  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7611  vmovaps xmm4, [rsp+0x40]
00007d3d13bd7617  vmovaps xmm5, [rsp+0x50]
00007d3d13bd761d  vmovaps xmm6, [rsp+0x60]
00007d3d13bd7623  vmovaps xmm7, [rsp+0x70]
00007d3d13bd7629  vmovaps xmm8, [rsp+0x80]
00007d3d13bd7632  vmovaps xmm9, [rsp+0x90]
00007d3d13bd763b  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd7644  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd764d  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd7656  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd765f  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd7668  add rsp, 0xF0
00007d3d13bd766f  pop r11
00007d3d13bd7671  pop r10
00007d3d13bd7673  pop r9
00007d3d13bd7675  pop r8
00007d3d13bd7677  pop rsi
00007d3d13bd7678  pop rdi
00007d3d13bd7679  pop rdx
00007d3d13bd767a  pop rcx
00007d3d13bd767b  pop rax
00007d3d13bd767c  add rsp, 0x08
00007d3d13bd7680  jmp 0x00007D3D13BD3332
00007d3d13bd7685  sub rsp, 0x08
00007d3d13bd7689  push rax
00007d3d13bd768a  push rcx
00007d3d13bd768b  push rdx
00007d3d13bd768c  push rdi
00007d3d13bd768d  push rsi
00007d3d13bd768e  push r8
00007d3d13bd7690  push r9
00007d3d13bd7692  push r10
00007d3d13bd7694  push r11
00007d3d13bd7696  sub rsp, 0xF0
00007d3d13bd769d  vmovaps [rsp], xmm0
00007d3d13bd76a2  vmovaps [rsp+0x10], xmm1
00007d3d13bd76a8  vmovaps [rsp+0x20], xmm2
00007d3d13bd76ae  vmovaps [rsp+0x30], xmm3
00007d3d13bd76b4  vmovaps [rsp+0x40], xmm4
00007d3d13bd76ba  vmovaps [rsp+0x50], xmm5
00007d3d13bd76c0  vmovaps [rsp+0x60], xmm6
00007d3d13bd76c6  vmovaps [rsp+0x70], xmm7
00007d3d13bd76cc  vmovaps [rsp+0x80], xmm8
00007d3d13bd76d5  vmovaps [rsp+0x90], xmm9
00007d3d13bd76de  vmovaps [rsp+0xA0], xmm10
00007d3d13bd76e7  vmovaps [rsp+0xB0], xmm12
00007d3d13bd76f0  vmovaps [rsp+0xC0], xmm13
00007d3d13bd76f9  vmovaps [rsp+0xD0], xmm14
00007d3d13bd7702  vmovaps [rsp+0xE0], xmm15
00007d3d13bd770b  sub rsp, 0x30
00007d3d13bd770f  movaps [rsp], xmm11
00007d3d13bd7714  movaps [rsp+0x10], xmm7
00007d3d13bd7719  movaps [rsp+0x20], xmm13
00007d3d13bd771f  lea rdi, [rsp]
00007d3d13bd7723  mov esi, 0x00
00007d3d13bd7728  mov rax, 0x5741DAFC8530
00007d3d13bd7732  call rax
00007d3d13bd7734  movaps xmm11, [rsp]
00007d3d13bd7739  add rsp, 0x30
00007d3d13bd773d  vmovaps xmm0, [rsp]
00007d3d13bd7742  vmovaps xmm1, [rsp+0x10]
00007d3d13bd7748  vmovaps xmm2, [rsp+0x20]
00007d3d13bd774e  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7754  vmovaps xmm4, [rsp+0x40]
00007d3d13bd775a  vmovaps xmm5, [rsp+0x50]
00007d3d13bd7760  vmovaps xmm6, [rsp+0x60]
00007d3d13bd7766  vmovaps xmm7, [rsp+0x70]
00007d3d13bd776c  vmovaps xmm8, [rsp+0x80]
00007d3d13bd7775  vmovaps xmm9, [rsp+0x90]
00007d3d13bd777e  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd7787  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd7790  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd7799  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd77a2  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd77ab  add rsp, 0xF0
00007d3d13bd77b2  pop r11
00007d3d13bd77b4  pop r10
00007d3d13bd77b6  pop r9
00007d3d13bd77b8  pop r8
00007d3d13bd77ba  pop rsi
00007d3d13bd77bb  pop rdi
00007d3d13bd77bc  pop rdx
00007d3d13bd77bd  pop rcx
00007d3d13bd77be  pop rax
00007d3d13bd77bf  add rsp, 0x08
00007d3d13bd77c3  jmp 0x00007D3D13BD335E
00007d3d13bd77c8  sub rsp, 0x08
00007d3d13bd77cc  push rax
00007d3d13bd77cd  push rcx
00007d3d13bd77ce  push rdx
00007d3d13bd77cf  push rdi
00007d3d13bd77d0  push rsi
00007d3d13bd77d1  push r8
00007d3d13bd77d3  push r9
00007d3d13bd77d5  push r10
00007d3d13bd77d7  push r11
00007d3d13bd77d9  sub rsp, 0xF0
00007d3d13bd77e0  vmovaps [rsp], xmm0
00007d3d13bd77e5  vmovaps [rsp+0x10], xmm1
00007d3d13bd77eb  vmovaps [rsp+0x20], xmm2
00007d3d13bd77f1  vmovaps [rsp+0x30], xmm3
00007d3d13bd77f7  vmovaps [rsp+0x40], xmm4
00007d3d13bd77fd  vmovaps [rsp+0x50], xmm5
00007d3d13bd7803  vmovaps [rsp+0x60], xmm6
00007d3d13bd7809  vmovaps [rsp+0x70], xmm7
00007d3d13bd780f  vmovaps [rsp+0x80], xmm8
00007d3d13bd7818  vmovaps [rsp+0x90], xmm9
00007d3d13bd7821  vmovaps [rsp+0xA0], xmm10
00007d3d13bd782a  vmovaps [rsp+0xB0], xmm11
00007d3d13bd7833  vmovaps [rsp+0xC0], xmm12
00007d3d13bd783c  vmovaps [rsp+0xD0], xmm14
00007d3d13bd7845  vmovaps [rsp+0xE0], xmm15
00007d3d13bd784e  sub rsp, 0x30
00007d3d13bd7852  movaps [rsp], xmm13
00007d3d13bd7857  movaps [rsp+0x10], xmm10
00007d3d13bd785d  movaps [rsp+0x20], xmm12
00007d3d13bd7863  lea rdi, [rsp]
00007d3d13bd7867  mov esi, 0x00
00007d3d13bd786c  mov rax, 0x5741DAFC8530
00007d3d13bd7876  call rax
00007d3d13bd7878  movaps xmm13, [rsp]
00007d3d13bd787d  add rsp, 0x30
00007d3d13bd7881  vmovaps xmm0, [rsp]
00007d3d13bd7886  vmovaps xmm1, [rsp+0x10]
00007d3d13bd788c  vmovaps xmm2, [rsp+0x20]
00007d3d13bd7892  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7898  vmovaps xmm4, [rsp+0x40]
00007d3d13bd789e  vmovaps xmm5, [rsp+0x50]
00007d3d13bd78a4  vmovaps xmm6, [rsp+0x60]
00007d3d13bd78aa  vmovaps xmm7, [rsp+0x70]
00007d3d13bd78b0  vmovaps xmm8, [rsp+0x80]
00007d3d13bd78b9  vmovaps xmm9, [rsp+0x90]
00007d3d13bd78c2  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd78cb  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd78d4  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd78dd  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd78e6  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd78ef  add rsp, 0xF0
00007d3d13bd78f6  pop r11
00007d3d13bd78f8  pop r10
00007d3d13bd78fa  pop r9
00007d3d13bd78fc  pop r8
00007d3d13bd78fe  pop rsi
00007d3d13bd78ff  pop rdi
00007d3d13bd7900  pop rdx
00007d3d13bd7901  pop rcx
00007d3d13bd7902  pop rax
00007d3d13bd7903  add rsp, 0x08
00007d3d13bd7907  jmp 0x00007D3D13BD3378
00007d3d13bd790c  sub rsp, 0x08
00007d3d13bd7910  push rax
00007d3d13bd7911  push rcx
00007d3d13bd7912  push rdx
00007d3d13bd7913  push rdi
00007d3d13bd7914  push rsi
00007d3d13bd7915  push r8
00007d3d13bd7917  push r9
00007d3d13bd7919  push r10
00007d3d13bd791b  push r11
00007d3d13bd791d  sub rsp, 0xF0
00007d3d13bd7924  vmovaps [rsp], xmm0
00007d3d13bd7929  vmovaps [rsp+0x10], xmm1
00007d3d13bd792f  vmovaps [rsp+0x20], xmm2
00007d3d13bd7935  vmovaps [rsp+0x30], xmm3
00007d3d13bd793b  vmovaps [rsp+0x40], xmm4
00007d3d13bd7941  vmovaps [rsp+0x50], xmm5
00007d3d13bd7947  vmovaps [rsp+0x60], xmm6
00007d3d13bd794d  vmovaps [rsp+0x70], xmm7
00007d3d13bd7953  vmovaps [rsp+0x80], xmm8
00007d3d13bd795c  vmovaps [rsp+0x90], xmm9
00007d3d13bd7965  vmovaps [rsp+0xA0], xmm11
00007d3d13bd796e  vmovaps [rsp+0xB0], xmm12
00007d3d13bd7977  vmovaps [rsp+0xC0], xmm13
00007d3d13bd7980  vmovaps [rsp+0xD0], xmm14
00007d3d13bd7989  vmovaps [rsp+0xE0], xmm15
00007d3d13bd7992  sub rsp, 0x30
00007d3d13bd7996  movaps [rsp], xmm10
00007d3d13bd799b  movaps [rsp+0x10], xmm7
00007d3d13bd79a0  movaps [rsp+0x20], xmm12
00007d3d13bd79a6  lea rdi, [rsp]
00007d3d13bd79aa  mov esi, 0x00
00007d3d13bd79af  mov rax, 0x5741DAFC8530
00007d3d13bd79b9  call rax
00007d3d13bd79bb  movaps xmm10, [rsp]
00007d3d13bd79c0  add rsp, 0x30
00007d3d13bd79c4  vmovaps xmm0, [rsp]
00007d3d13bd79c9  vmovaps xmm1, [rsp+0x10]
00007d3d13bd79cf  vmovaps xmm2, [rsp+0x20]
00007d3d13bd79d5  vmovaps xmm3, [rsp+0x30]
00007d3d13bd79db  vmovaps xmm4, [rsp+0x40]
00007d3d13bd79e1  vmovaps xmm5, [rsp+0x50]
00007d3d13bd79e7  vmovaps xmm6, [rsp+0x60]
00007d3d13bd79ed  vmovaps xmm7, [rsp+0x70]
00007d3d13bd79f3  vmovaps xmm8, [rsp+0x80]
00007d3d13bd79fc  vmovaps xmm9, [rsp+0x90]
00007d3d13bd7a05  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd7a0e  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd7a17  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd7a20  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd7a29  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd7a32  add rsp, 0xF0
00007d3d13bd7a39  pop r11
00007d3d13bd7a3b  pop r10
00007d3d13bd7a3d  pop r9
00007d3d13bd7a3f  pop r8
00007d3d13bd7a41  pop rsi
00007d3d13bd7a42  pop rdi
00007d3d13bd7a43  pop rdx
00007d3d13bd7a44  pop rcx
00007d3d13bd7a45  pop rax
00007d3d13bd7a46  add rsp, 0x08
00007d3d13bd7a4a  jmp 0x00007D3D13BD33A4
00007d3d13bd7a4f  sub rsp, 0x08
00007d3d13bd7a53  push rax
00007d3d13bd7a54  push rcx
00007d3d13bd7a55  push rdx
00007d3d13bd7a56  push rdi
00007d3d13bd7a57  push rsi
00007d3d13bd7a58  push r8
00007d3d13bd7a5a  push r9
00007d3d13bd7a5c  push r10
00007d3d13bd7a5e  push r11
00007d3d13bd7a60  sub rsp, 0xF0
00007d3d13bd7a67  vmovaps [rsp], xmm0
00007d3d13bd7a6c  vmovaps [rsp+0x10], xmm1
00007d3d13bd7a72  vmovaps [rsp+0x20], xmm2
00007d3d13bd7a78  vmovaps [rsp+0x30], xmm3
00007d3d13bd7a7e  vmovaps [rsp+0x40], xmm4
00007d3d13bd7a84  vmovaps [rsp+0x50], xmm5
00007d3d13bd7a8a  vmovaps [rsp+0x60], xmm6
00007d3d13bd7a90  vmovaps [rsp+0x70], xmm7
00007d3d13bd7a96  vmovaps [rsp+0x80], xmm8
00007d3d13bd7a9f  vmovaps [rsp+0x90], xmm9
00007d3d13bd7aa8  vmovaps [rsp+0xA0], xmm10
00007d3d13bd7ab1  vmovaps [rsp+0xB0], xmm11
00007d3d13bd7aba  vmovaps [rsp+0xC0], xmm13
00007d3d13bd7ac3  vmovaps [rsp+0xD0], xmm14
00007d3d13bd7acc  vmovaps [rsp+0xE0], xmm15
00007d3d13bd7ad5  sub rsp, 0x30
00007d3d13bd7ad9  movaps [rsp], xmm12
00007d3d13bd7ade  movaps [rsp+0x10], xmm1
00007d3d13bd7ae3  movaps [rsp+0x20], xmm8
00007d3d13bd7ae9  lea rdi, [rsp]
00007d3d13bd7aed  mov esi, 0x00
00007d3d13bd7af2  mov rax, 0x5741DAFC8530
00007d3d13bd7afc  call rax
00007d3d13bd7afe  movaps xmm12, [rsp]
00007d3d13bd7b03  add rsp, 0x30
00007d3d13bd7b07  vmovaps xmm0, [rsp]
00007d3d13bd7b0c  vmovaps xmm1, [rsp+0x10]
00007d3d13bd7b12  vmovaps xmm2, [rsp+0x20]
00007d3d13bd7b18  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7b1e  vmovaps xmm4, [rsp+0x40]
00007d3d13bd7b24  vmovaps xmm5, [rsp+0x50]
00007d3d13bd7b2a  vmovaps xmm6, [rsp+0x60]
00007d3d13bd7b30  vmovaps xmm7, [rsp+0x70]
00007d3d13bd7b36  vmovaps xmm8, [rsp+0x80]
00007d3d13bd7b3f  vmovaps xmm9, [rsp+0x90]
00007d3d13bd7b48  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd7b51  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd7b5a  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd7b63  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd7b6c  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd7b75  add rsp, 0xF0
00007d3d13bd7b7c  pop r11
00007d3d13bd7b7e  pop r10
00007d3d13bd7b80  pop r9
00007d3d13bd7b82  pop r8
00007d3d13bd7b84  pop rsi
00007d3d13bd7b85  pop rdi
00007d3d13bd7b86  pop rdx
00007d3d13bd7b87  pop rcx
00007d3d13bd7b88  pop rax
00007d3d13bd7b89  add rsp, 0x08
00007d3d13bd7b8d  jmp 0x00007D3D13BD33BE
00007d3d13bd7b92  call 0x00007D3D139FF430
00007d3d13bd7b97  jmp 0x00007D3D13BD33C8
00007d3d13bd7b9c  sub rsp, 0x08
00007d3d13bd7ba0  push rax
00007d3d13bd7ba1  push rcx
00007d3d13bd7ba2  push rdx
00007d3d13bd7ba3  push rdi
00007d3d13bd7ba4  push rsi
00007d3d13bd7ba5  push r8
00007d3d13bd7ba7  push r9
00007d3d13bd7ba9  push r10
00007d3d13bd7bab  push r11
00007d3d13bd7bad  sub rsp, 0xF0
00007d3d13bd7bb4  vmovaps [rsp], xmm0
00007d3d13bd7bb9  vmovaps [rsp+0x10], xmm1
00007d3d13bd7bbf  vmovaps [rsp+0x20], xmm2
00007d3d13bd7bc5  vmovaps [rsp+0x30], xmm3
00007d3d13bd7bcb  vmovaps [rsp+0x40], xmm4
00007d3d13bd7bd1  vmovaps [rsp+0x50], xmm5
00007d3d13bd7bd7  vmovaps [rsp+0x60], xmm6
00007d3d13bd7bdd  vmovaps [rsp+0x70], xmm7
00007d3d13bd7be3  vmovaps [rsp+0x80], xmm9
00007d3d13bd7bec  vmovaps [rsp+0x90], xmm10
00007d3d13bd7bf5  vmovaps [rsp+0xA0], xmm11
00007d3d13bd7bfe  vmovaps [rsp+0xB0], xmm12
00007d3d13bd7c07  vmovaps [rsp+0xC0], xmm13
00007d3d13bd7c10  vmovaps [rsp+0xD0], xmm14
00007d3d13bd7c19  vmovaps [rsp+0xE0], xmm15
00007d3d13bd7c22  sub rsp, 0x30
00007d3d13bd7c26  movaps [rsp], xmm8
00007d3d13bd7c2b  movaps [rsp+0x10], xmm15
00007d3d13bd7c31  movaps [rsp+0x20], xmm9
00007d3d13bd7c37  lea rdi, [rsp]
00007d3d13bd7c3b  mov esi, 0x00
00007d3d13bd7c40  mov rax, 0x5741DAFC8530
00007d3d13bd7c4a  call rax
00007d3d13bd7c4c  movaps xmm8, [rsp]
00007d3d13bd7c51  add rsp, 0x30
00007d3d13bd7c55  vmovaps xmm0, [rsp]
00007d3d13bd7c5a  vmovaps xmm1, [rsp+0x10]
00007d3d13bd7c60  vmovaps xmm2, [rsp+0x20]
00007d3d13bd7c66  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7c6c  vmovaps xmm4, [rsp+0x40]
00007d3d13bd7c72  vmovaps xmm5, [rsp+0x50]
00007d3d13bd7c78  vmovaps xmm6, [rsp+0x60]
00007d3d13bd7c7e  vmovaps xmm7, [rsp+0x70]
00007d3d13bd7c84  vmovaps xmm9, [rsp+0x80]
00007d3d13bd7c8d  vmovaps xmm10, [rsp+0x90]
00007d3d13bd7c96  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd7c9f  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd7ca8  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd7cb1  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd7cba  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd7cc3  add rsp, 0xF0
00007d3d13bd7cca  pop r11
00007d3d13bd7ccc  pop r10
00007d3d13bd7cce  pop r9
00007d3d13bd7cd0  pop r8
00007d3d13bd7cd2  pop rsi
00007d3d13bd7cd3  pop rdi
00007d3d13bd7cd4  pop rdx
00007d3d13bd7cd5  pop rcx
00007d3d13bd7cd6  pop rax
00007d3d13bd7cd7  add rsp, 0x08
00007d3d13bd7cdb  jmp 0x00007D3D13BD33EA
00007d3d13bd7ce0  sub rsp, 0x08
00007d3d13bd7ce4  push rax
00007d3d13bd7ce5  push rcx
00007d3d13bd7ce6  push rdx
00007d3d13bd7ce7  push rdi
00007d3d13bd7ce8  push rsi
00007d3d13bd7ce9  push r8
00007d3d13bd7ceb  push r9
00007d3d13bd7ced  push r10
00007d3d13bd7cef  push r11
00007d3d13bd7cf1  sub rsp, 0xF0
00007d3d13bd7cf8  vmovaps [rsp], xmm0
00007d3d13bd7cfd  vmovaps [rsp+0x10], xmm1
00007d3d13bd7d03  vmovaps [rsp+0x20], xmm2
00007d3d13bd7d09  vmovaps [rsp+0x30], xmm3
00007d3d13bd7d0f  vmovaps [rsp+0x40], xmm4
00007d3d13bd7d15  vmovaps [rsp+0x50], xmm5
00007d3d13bd7d1b  vmovaps [rsp+0x60], xmm6
00007d3d13bd7d21  vmovaps [rsp+0x70], xmm7
00007d3d13bd7d27  vmovaps [rsp+0x80], xmm8
00007d3d13bd7d30  vmovaps [rsp+0x90], xmm10
00007d3d13bd7d39  vmovaps [rsp+0xA0], xmm11
00007d3d13bd7d42  vmovaps [rsp+0xB0], xmm12
00007d3d13bd7d4b  vmovaps [rsp+0xC0], xmm13
00007d3d13bd7d54  vmovaps [rsp+0xD0], xmm14
00007d3d13bd7d5d  vmovaps [rsp+0xE0], xmm15
00007d3d13bd7d66  sub rsp, 0x30
00007d3d13bd7d6a  movaps [rsp], xmm9
00007d3d13bd7d6f  movaps [rsp+0x10], xmm1
00007d3d13bd7d74  movaps [rsp+0x20], xmm15
00007d3d13bd7d7a  lea rdi, [rsp]
00007d3d13bd7d7e  mov esi, 0x00
00007d3d13bd7d83  mov rax, 0x5741DAFC8530
00007d3d13bd7d8d  call rax
00007d3d13bd7d8f  movaps xmm9, [rsp]
00007d3d13bd7d94  add rsp, 0x30
00007d3d13bd7d98  vmovaps xmm0, [rsp]
00007d3d13bd7d9d  vmovaps xmm1, [rsp+0x10]
00007d3d13bd7da3  vmovaps xmm2, [rsp+0x20]
00007d3d13bd7da9  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7daf  vmovaps xmm4, [rsp+0x40]
00007d3d13bd7db5  vmovaps xmm5, [rsp+0x50]
00007d3d13bd7dbb  vmovaps xmm6, [rsp+0x60]
00007d3d13bd7dc1  vmovaps xmm7, [rsp+0x70]
00007d3d13bd7dc7  vmovaps xmm8, [rsp+0x80]
00007d3d13bd7dd0  vmovaps xmm10, [rsp+0x90]
00007d3d13bd7dd9  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd7de2  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd7deb  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd7df4  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd7dfd  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd7e06  add rsp, 0xF0
00007d3d13bd7e0d  pop r11
00007d3d13bd7e0f  pop r10
00007d3d13bd7e11  pop r9
00007d3d13bd7e13  pop r8
00007d3d13bd7e15  pop rsi
00007d3d13bd7e16  pop rdi
00007d3d13bd7e17  pop rdx
00007d3d13bd7e18  pop rcx
00007d3d13bd7e19  pop rax
00007d3d13bd7e1a  add rsp, 0x08
00007d3d13bd7e1e  jmp 0x00007D3D13BD3418
00007d3d13bd7e23  sub rsp, 0x08
00007d3d13bd7e27  push rax
00007d3d13bd7e28  push rcx
00007d3d13bd7e29  push rdx
00007d3d13bd7e2a  push rdi
00007d3d13bd7e2b  push rsi
00007d3d13bd7e2c  push r8
00007d3d13bd7e2e  push r9
00007d3d13bd7e30  push r10
00007d3d13bd7e32  push r11
00007d3d13bd7e34  sub rsp, 0xF0
00007d3d13bd7e3b  vmovaps [rsp], xmm0
00007d3d13bd7e40  vmovaps [rsp+0x10], xmm1
00007d3d13bd7e46  vmovaps [rsp+0x20], xmm2
00007d3d13bd7e4c  vmovaps [rsp+0x30], xmm3
00007d3d13bd7e52  vmovaps [rsp+0x40], xmm4
00007d3d13bd7e58  vmovaps [rsp+0x50], xmm5
00007d3d13bd7e5e  vmovaps [rsp+0x60], xmm6
00007d3d13bd7e64  vmovaps [rsp+0x70], xmm7
00007d3d13bd7e6a  vmovaps [rsp+0x80], xmm8
00007d3d13bd7e73  vmovaps [rsp+0x90], xmm9
00007d3d13bd7e7c  vmovaps [rsp+0xA0], xmm10
00007d3d13bd7e85  vmovaps [rsp+0xB0], xmm11
00007d3d13bd7e8e  vmovaps [rsp+0xC0], xmm12
00007d3d13bd7e97  vmovaps [rsp+0xD0], xmm13
00007d3d13bd7ea0  vmovaps [rsp+0xE0], xmm14
00007d3d13bd7ea9  sub rsp, 0x30
00007d3d13bd7ead  movaps [rsp], xmm15
00007d3d13bd7eb2  movaps [rsp+0x10], xmm4
00007d3d13bd7eb7  movaps [rsp+0x20], xmm1
00007d3d13bd7ebc  lea rdi, [rsp]
00007d3d13bd7ec0  mov esi, 0x00
00007d3d13bd7ec5  mov rax, 0x5741DAFC8530
00007d3d13bd7ecf  call rax
00007d3d13bd7ed1  movaps xmm15, [rsp]
00007d3d13bd7ed6  add rsp, 0x30
00007d3d13bd7eda  vmovaps xmm0, [rsp]
00007d3d13bd7edf  vmovaps xmm1, [rsp+0x10]
00007d3d13bd7ee5  vmovaps xmm2, [rsp+0x20]
00007d3d13bd7eeb  vmovaps xmm3, [rsp+0x30]
00007d3d13bd7ef1  vmovaps xmm4, [rsp+0x40]
00007d3d13bd7ef7  vmovaps xmm5, [rsp+0x50]
00007d3d13bd7efd  vmovaps xmm6, [rsp+0x60]
00007d3d13bd7f03  vmovaps xmm7, [rsp+0x70]
00007d3d13bd7f09  vmovaps xmm8, [rsp+0x80]
00007d3d13bd7f12  vmovaps xmm9, [rsp+0x90]
00007d3d13bd7f1b  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd7f24  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd7f2d  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd7f36  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd7f3f  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd7f48  add rsp, 0xF0
00007d3d13bd7f4f  pop r11
00007d3d13bd7f51  pop r10
00007d3d13bd7f53  pop r9
00007d3d13bd7f55  pop r8
00007d3d13bd7f57  pop rsi
00007d3d13bd7f58  pop rdi
00007d3d13bd7f59  pop rdx
00007d3d13bd7f5a  pop rcx
00007d3d13bd7f5b  pop rax
00007d3d13bd7f5c  add rsp, 0x08
00007d3d13bd7f60  jmp 0x00007D3D13BD343E
00007d3d13bd7f65  sub rsp, 0x08
00007d3d13bd7f69  push rax
00007d3d13bd7f6a  push rcx
00007d3d13bd7f6b  push rdx
00007d3d13bd7f6c  push rdi
00007d3d13bd7f6d  push rsi
00007d3d13bd7f6e  push r8
00007d3d13bd7f70  push r9
00007d3d13bd7f72  push r10
00007d3d13bd7f74  push r11
00007d3d13bd7f76  sub rsp, 0xF0
00007d3d13bd7f7d  vmovaps [rsp], xmm0
00007d3d13bd7f82  vmovaps [rsp+0x10], xmm2
00007d3d13bd7f88  vmovaps [rsp+0x20], xmm3
00007d3d13bd7f8e  vmovaps [rsp+0x30], xmm4
00007d3d13bd7f94  vmovaps [rsp+0x40], xmm5
00007d3d13bd7f9a  vmovaps [rsp+0x50], xmm6
00007d3d13bd7fa0  vmovaps [rsp+0x60], xmm7
00007d3d13bd7fa6  vmovaps [rsp+0x70], xmm8
00007d3d13bd7fac  vmovaps [rsp+0x80], xmm9
00007d3d13bd7fb5  vmovaps [rsp+0x90], xmm10
00007d3d13bd7fbe  vmovaps [rsp+0xA0], xmm11
00007d3d13bd7fc7  vmovaps [rsp+0xB0], xmm12
00007d3d13bd7fd0  vmovaps [rsp+0xC0], xmm13
00007d3d13bd7fd9  vmovaps [rsp+0xD0], xmm14
00007d3d13bd7fe2  vmovaps [rsp+0xE0], xmm15
00007d3d13bd7feb  sub rsp, 0x30
00007d3d13bd7fef  movaps [rsp], xmm1
00007d3d13bd7ff3  movaps [rsp+0x10], xmm14
00007d3d13bd7ff9  movaps [rsp+0x20], xmm11
00007d3d13bd7fff  lea rdi, [rsp]
00007d3d13bd8003  mov esi, 0x00
00007d3d13bd8008  mov rax, 0x5741DAFC8530
00007d3d13bd8012  call rax
00007d3d13bd8014  movaps xmm1, [rsp]
00007d3d13bd8018  add rsp, 0x30
00007d3d13bd801c  vmovaps xmm0, [rsp]
00007d3d13bd8021  vmovaps xmm2, [rsp+0x10]
00007d3d13bd8027  vmovaps xmm3, [rsp+0x20]
00007d3d13bd802d  vmovaps xmm4, [rsp+0x30]
00007d3d13bd8033  vmovaps xmm5, [rsp+0x40]
00007d3d13bd8039  vmovaps xmm6, [rsp+0x50]
00007d3d13bd803f  vmovaps xmm7, [rsp+0x60]
00007d3d13bd8045  vmovaps xmm8, [rsp+0x70]
00007d3d13bd804b  vmovaps xmm9, [rsp+0x80]
00007d3d13bd8054  vmovaps xmm10, [rsp+0x90]
00007d3d13bd805d  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd8066  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd806f  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd8078  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd8081  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd808a  add rsp, 0xF0
00007d3d13bd8091  pop r11
00007d3d13bd8093  pop r10
00007d3d13bd8095  pop r9
00007d3d13bd8097  pop r8
00007d3d13bd8099  pop rsi
00007d3d13bd809a  pop rdi
00007d3d13bd809b  pop rdx
00007d3d13bd809c  pop rcx
00007d3d13bd809d  pop rax
00007d3d13bd809e  add rsp, 0x08
00007d3d13bd80a2  jmp 0x00007D3D13BD345F
00007d3d13bd80a7  call 0x00007D3D13AE45A0
00007d3d13bd80ac  jmp 0x00007D3D13BD346D
00007d3d13bd80b1  call 0x00007D3D13A09D70
00007d3d13bd80b6  jmp 0x00007D3D13BD3477
00007d3d13bd80bb  sub rsp, 0x08
00007d3d13bd80bf  push rax
00007d3d13bd80c0  push rcx
00007d3d13bd80c1  push rdx
00007d3d13bd80c2  push rdi
00007d3d13bd80c3  push rsi
00007d3d13bd80c4  push r8
00007d3d13bd80c6  push r9
00007d3d13bd80c8  push r10
00007d3d13bd80ca  push r11
00007d3d13bd80cc  sub rsp, 0xF0
00007d3d13bd80d3  vmovaps [rsp], xmm0
00007d3d13bd80d8  vmovaps [rsp+0x10], xmm1
00007d3d13bd80de  vmovaps [rsp+0x20], xmm2
00007d3d13bd80e4  vmovaps [rsp+0x30], xmm3
00007d3d13bd80ea  vmovaps [rsp+0x40], xmm4
00007d3d13bd80f0  vmovaps [rsp+0x50], xmm5
00007d3d13bd80f6  vmovaps [rsp+0x60], xmm6
00007d3d13bd80fc  vmovaps [rsp+0x70], xmm8
00007d3d13bd8102  vmovaps [rsp+0x80], xmm9
00007d3d13bd810b  vmovaps [rsp+0x90], xmm10
00007d3d13bd8114  vmovaps [rsp+0xA0], xmm11
00007d3d13bd811d  vmovaps [rsp+0xB0], xmm12
00007d3d13bd8126  vmovaps [rsp+0xC0], xmm13
00007d3d13bd812f  vmovaps [rsp+0xD0], xmm14
00007d3d13bd8138  vmovaps [rsp+0xE0], xmm15
00007d3d13bd8141  sub rsp, 0x30
00007d3d13bd8145  movaps [rsp], xmm7
00007d3d13bd8149  movaps [rsp+0x10], xmm13
00007d3d13bd814f  movaps [rsp+0x20], xmm10
00007d3d13bd8155  lea rdi, [rsp]
00007d3d13bd8159  mov esi, 0x00
00007d3d13bd815e  mov rax, 0x5741DAFC8530
00007d3d13bd8168  call rax
00007d3d13bd816a  movaps xmm7, [rsp]
00007d3d13bd816e  add rsp, 0x30
00007d3d13bd8172  vmovaps xmm0, [rsp]
00007d3d13bd8177  vmovaps xmm1, [rsp+0x10]
00007d3d13bd817d  vmovaps xmm2, [rsp+0x20]
00007d3d13bd8183  vmovaps xmm3, [rsp+0x30]
00007d3d13bd8189  vmovaps xmm4, [rsp+0x40]
00007d3d13bd818f  vmovaps xmm5, [rsp+0x50]
00007d3d13bd8195  vmovaps xmm6, [rsp+0x60]
00007d3d13bd819b  vmovaps xmm8, [rsp+0x70]
00007d3d13bd81a1  vmovaps xmm9, [rsp+0x80]
00007d3d13bd81aa  vmovaps xmm10, [rsp+0x90]
00007d3d13bd81b3  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd81bc  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd81c5  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd81ce  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd81d7  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd81e0  add rsp, 0xF0
00007d3d13bd81e7  pop r11
00007d3d13bd81e9  pop r10
00007d3d13bd81eb  pop r9
00007d3d13bd81ed  pop r8
00007d3d13bd81ef  pop rsi
00007d3d13bd81f0  pop rdi
00007d3d13bd81f1  pop rdx
00007d3d13bd81f2  pop rcx
00007d3d13bd81f3  pop rax
00007d3d13bd81f4  add rsp, 0x08
00007d3d13bd81f8  jmp 0x00007D3D13BD3498
00007d3d13bd81fd  sub rsp, 0x08
00007d3d13bd8201  push rax
00007d3d13bd8202  push rcx
00007d3d13bd8203  push rdx
00007d3d13bd8204  push rdi
00007d3d13bd8205  push rsi
00007d3d13bd8206  push r8
00007d3d13bd8208  push r9
00007d3d13bd820a  push r10
00007d3d13bd820c  push r11
00007d3d13bd820e  sub rsp, 0xF0
00007d3d13bd8215  vmovaps [rsp], xmm0
00007d3d13bd821a  vmovaps [rsp+0x10], xmm1
00007d3d13bd8220  vmovaps [rsp+0x20], xmm2
00007d3d13bd8226  vmovaps [rsp+0x30], xmm3
00007d3d13bd822c  vmovaps [rsp+0x40], xmm4
00007d3d13bd8232  vmovaps [rsp+0x50], xmm5
00007d3d13bd8238  vmovaps [rsp+0x60], xmm6
00007d3d13bd823e  vmovaps [rsp+0x70], xmm7
00007d3d13bd8244  vmovaps [rsp+0x80], xmm8
00007d3d13bd824d  vmovaps [rsp+0x90], xmm9
00007d3d13bd8256  vmovaps [rsp+0xA0], xmm11
00007d3d13bd825f  vmovaps [rsp+0xB0], xmm12
00007d3d13bd8268  vmovaps [rsp+0xC0], xmm13
00007d3d13bd8271  vmovaps [rsp+0xD0], xmm14
00007d3d13bd827a  vmovaps [rsp+0xE0], xmm15
00007d3d13bd8283  sub rsp, 0x30
00007d3d13bd8287  movaps [rsp], xmm10
00007d3d13bd828c  movaps [rsp+0x10], xmm11
00007d3d13bd8292  movaps [rsp+0x20], xmm13
00007d3d13bd8298  lea rdi, [rsp]
00007d3d13bd829c  mov esi, 0x00
00007d3d13bd82a1  mov rax, 0x5741DAFC8530
00007d3d13bd82ab  call rax
00007d3d13bd82ad  movaps xmm10, [rsp]
00007d3d13bd82b2  add rsp, 0x30
00007d3d13bd82b6  vmovaps xmm0, [rsp]
00007d3d13bd82bb  vmovaps xmm1, [rsp+0x10]
00007d3d13bd82c1  vmovaps xmm2, [rsp+0x20]
00007d3d13bd82c7  vmovaps xmm3, [rsp+0x30]
00007d3d13bd82cd  vmovaps xmm4, [rsp+0x40]
00007d3d13bd82d3  vmovaps xmm5, [rsp+0x50]
00007d3d13bd82d9  vmovaps xmm6, [rsp+0x60]
00007d3d13bd82df  vmovaps xmm7, [rsp+0x70]
00007d3d13bd82e5  vmovaps xmm8, [rsp+0x80]
00007d3d13bd82ee  vmovaps xmm9, [rsp+0x90]
00007d3d13bd82f7  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd8300  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd8309  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd8312  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd831b  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd8324  add rsp, 0xF0
00007d3d13bd832b  pop r11
00007d3d13bd832d  pop r10
00007d3d13bd832f  pop r9
00007d3d13bd8331  pop r8
00007d3d13bd8333  pop rsi
00007d3d13bd8334  pop rdi
00007d3d13bd8335  pop rdx
00007d3d13bd8336  pop rcx
00007d3d13bd8337  pop rax
00007d3d13bd8338  add rsp, 0x08
00007d3d13bd833c  jmp 0x00007D3D13BD34C6
00007d3d13bd8341  sub rsp, 0x08
00007d3d13bd8345  push rax
00007d3d13bd8346  push rcx
00007d3d13bd8347  push rdx
00007d3d13bd8348  push rdi
00007d3d13bd8349  push rsi
00007d3d13bd834a  push r8
00007d3d13bd834c  push r9
00007d3d13bd834e  push r10
00007d3d13bd8350  push r11
00007d3d13bd8352  sub rsp, 0xF0
00007d3d13bd8359  vmovaps [rsp], xmm0
00007d3d13bd835e  vmovaps [rsp+0x10], xmm1
00007d3d13bd8364  vmovaps [rsp+0x20], xmm2
00007d3d13bd836a  vmovaps [rsp+0x30], xmm3
00007d3d13bd8370  vmovaps [rsp+0x40], xmm4
00007d3d13bd8376  vmovaps [rsp+0x50], xmm5
00007d3d13bd837c  vmovaps [rsp+0x60], xmm6
00007d3d13bd8382  vmovaps [rsp+0x70], xmm7
00007d3d13bd8388  vmovaps [rsp+0x80], xmm8
00007d3d13bd8391  vmovaps [rsp+0x90], xmm9
00007d3d13bd839a  vmovaps [rsp+0xA0], xmm10
00007d3d13bd83a3  vmovaps [rsp+0xB0], xmm12
00007d3d13bd83ac  vmovaps [rsp+0xC0], xmm13
00007d3d13bd83b5  vmovaps [rsp+0xD0], xmm14
00007d3d13bd83be  vmovaps [rsp+0xE0], xmm15
00007d3d13bd83c7  sub rsp, 0x30
00007d3d13bd83cb  movaps [rsp], xmm11
00007d3d13bd83d0  movaps [rsp+0x10], xmm14
00007d3d13bd83d6  movaps [rsp+0x20], xmm13
00007d3d13bd83dc  lea rdi, [rsp]
00007d3d13bd83e0  mov esi, 0x00
00007d3d13bd83e5  mov rax, 0x5741DAFC8530
00007d3d13bd83ef  call rax
00007d3d13bd83f1  movaps xmm11, [rsp]
00007d3d13bd83f6  add rsp, 0x30
00007d3d13bd83fa  vmovaps xmm0, [rsp]
00007d3d13bd83ff  vmovaps xmm1, [rsp+0x10]
00007d3d13bd8405  vmovaps xmm2, [rsp+0x20]
00007d3d13bd840b  vmovaps xmm3, [rsp+0x30]
00007d3d13bd8411  vmovaps xmm4, [rsp+0x40]
00007d3d13bd8417  vmovaps xmm5, [rsp+0x50]
00007d3d13bd841d  vmovaps xmm6, [rsp+0x60]
00007d3d13bd8423  vmovaps xmm7, [rsp+0x70]
00007d3d13bd8429  vmovaps xmm8, [rsp+0x80]
00007d3d13bd8432  vmovaps xmm9, [rsp+0x90]
00007d3d13bd843b  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd8444  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd844d  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd8456  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd845f  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd8468  add rsp, 0xF0
00007d3d13bd846f  pop r11
00007d3d13bd8471  pop r10
00007d3d13bd8473  pop r9
00007d3d13bd8475  pop r8
00007d3d13bd8477  pop rsi
00007d3d13bd8478  pop rdi
00007d3d13bd8479  pop rdx
00007d3d13bd847a  pop rcx
00007d3d13bd847b  pop rax
00007d3d13bd847c  add rsp, 0x08
00007d3d13bd8480  jmp 0x00007D3D13BD34F4
00007d3d13bd8485  sub rsp, 0x08
00007d3d13bd8489  push rax
00007d3d13bd848a  push rcx
00007d3d13bd848b  push rdx
00007d3d13bd848c  push rdi
00007d3d13bd848d  push rsi
00007d3d13bd848e  push r8
00007d3d13bd8490  push r9
00007d3d13bd8492  push r10
00007d3d13bd8494  push r11
00007d3d13bd8496  sub rsp, 0xF0
00007d3d13bd849d  vmovaps [rsp], xmm0
00007d3d13bd84a2  vmovaps [rsp+0x10], xmm1
00007d3d13bd84a8  vmovaps [rsp+0x20], xmm2
00007d3d13bd84ae  vmovaps [rsp+0x30], xmm3
00007d3d13bd84b4  vmovaps [rsp+0x40], xmm4
00007d3d13bd84ba  vmovaps [rsp+0x50], xmm5
00007d3d13bd84c0  vmovaps [rsp+0x60], xmm6
00007d3d13bd84c6  vmovaps [rsp+0x70], xmm7
00007d3d13bd84cc  vmovaps [rsp+0x80], xmm8
00007d3d13bd84d5  vmovaps [rsp+0x90], xmm9
00007d3d13bd84de  vmovaps [rsp+0xA0], xmm10
00007d3d13bd84e7  vmovaps [rsp+0xB0], xmm11
00007d3d13bd84f0  vmovaps [rsp+0xC0], xmm12
00007d3d13bd84f9  vmovaps [rsp+0xD0], xmm13
00007d3d13bd8502  vmovaps [rsp+0xE0], xmm15
00007d3d13bd850b  sub rsp, 0x30
00007d3d13bd850f  movaps [rsp], xmm14
00007d3d13bd8514  movaps [rsp+0x10], xmm12
00007d3d13bd851a  movaps [rsp+0x20], xmm9
00007d3d13bd8520  lea rdi, [rsp]
00007d3d13bd8524  mov esi, 0x00
00007d3d13bd8529  mov rax, 0x5741DAFC8530
00007d3d13bd8533  call rax
00007d3d13bd8535  movaps xmm14, [rsp]
00007d3d13bd853a  add rsp, 0x30
00007d3d13bd853e  vmovaps xmm0, [rsp]
00007d3d13bd8543  vmovaps xmm1, [rsp+0x10]
00007d3d13bd8549  vmovaps xmm2, [rsp+0x20]
00007d3d13bd854f  vmovaps xmm3, [rsp+0x30]
00007d3d13bd8555  vmovaps xmm4, [rsp+0x40]
00007d3d13bd855b  vmovaps xmm5, [rsp+0x50]
00007d3d13bd8561  vmovaps xmm6, [rsp+0x60]
00007d3d13bd8567  vmovaps xmm7, [rsp+0x70]
00007d3d13bd856d  vmovaps xmm8, [rsp+0x80]
00007d3d13bd8576  vmovaps xmm9, [rsp+0x90]
00007d3d13bd857f  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd8588  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd8591  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd859a  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd85a3  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd85ac  add rsp, 0xF0
00007d3d13bd85b3  pop r11
00007d3d13bd85b5  pop r10
00007d3d13bd85b7  pop r9
00007d3d13bd85b9  pop r8
00007d3d13bd85bb  pop rsi
00007d3d13bd85bc  pop rdi
00007d3d13bd85bd  pop rdx
00007d3d13bd85be  pop rcx
00007d3d13bd85bf  pop rax
00007d3d13bd85c0  add rsp, 0x08
00007d3d13bd85c4  jmp 0x00007D3D13BD350F
00007d3d13bd85c9  sub rsp, 0x08
00007d3d13bd85cd  push rax
00007d3d13bd85ce  push rcx
00007d3d13bd85cf  push rdx
00007d3d13bd85d0  push rdi
00007d3d13bd85d1  push rsi
00007d3d13bd85d2  push r8
00007d3d13bd85d4  push r9
00007d3d13bd85d6  push r10
00007d3d13bd85d8  push r11
00007d3d13bd85da  sub rsp, 0xF0
00007d3d13bd85e1  vmovaps [rsp], xmm0
00007d3d13bd85e6  vmovaps [rsp+0x10], xmm1
00007d3d13bd85ec  vmovaps [rsp+0x20], xmm2
00007d3d13bd85f2  vmovaps [rsp+0x30], xmm3
00007d3d13bd85f8  vmovaps [rsp+0x40], xmm4
00007d3d13bd85fe  vmovaps [rsp+0x50], xmm5
00007d3d13bd8604  vmovaps [rsp+0x60], xmm6
00007d3d13bd860a  vmovaps [rsp+0x70], xmm7
00007d3d13bd8610  vmovaps [rsp+0x80], xmm8
00007d3d13bd8619  vmovaps [rsp+0x90], xmm9
00007d3d13bd8622  vmovaps [rsp+0xA0], xmm10
00007d3d13bd862b  vmovaps [rsp+0xB0], xmm11
00007d3d13bd8634  vmovaps [rsp+0xC0], xmm12
00007d3d13bd863d  vmovaps [rsp+0xD0], xmm14
00007d3d13bd8646  vmovaps [rsp+0xE0], xmm15
00007d3d13bd864f  sub rsp, 0x30
00007d3d13bd8653  movaps [rsp], xmm13
00007d3d13bd8658  movaps [rsp+0x10], xmm8
00007d3d13bd865e  movaps [rsp+0x20], xmm15
00007d3d13bd8664  lea rdi, [rsp]
00007d3d13bd8668  mov esi, 0x00
00007d3d13bd866d  mov rax, 0x5741DAFC8530
00007d3d13bd8677  call rax
00007d3d13bd8679  movaps xmm13, [rsp]
00007d3d13bd867e  add rsp, 0x30
00007d3d13bd8682  vmovaps xmm0, [rsp]
00007d3d13bd8687  vmovaps xmm1, [rsp+0x10]
00007d3d13bd868d  vmovaps xmm2, [rsp+0x20]
00007d3d13bd8693  vmovaps xmm3, [rsp+0x30]
00007d3d13bd8699  vmovaps xmm4, [rsp+0x40]
00007d3d13bd869f  vmovaps xmm5, [rsp+0x50]
00007d3d13bd86a5  vmovaps xmm6, [rsp+0x60]
00007d3d13bd86ab  vmovaps xmm7, [rsp+0x70]
00007d3d13bd86b1  vmovaps xmm8, [rsp+0x80]
00007d3d13bd86ba  vmovaps xmm9, [rsp+0x90]
00007d3d13bd86c3  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd86cc  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd86d5  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd86de  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd86e7  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd86f0  add rsp, 0xF0
00007d3d13bd86f7  pop r11
00007d3d13bd86f9  pop r10
00007d3d13bd86fb  pop r9
00007d3d13bd86fd  pop r8
00007d3d13bd86ff  pop rsi
00007d3d13bd8700  pop rdi
00007d3d13bd8701  pop rdx
00007d3d13bd8702  pop rcx
00007d3d13bd8703  pop rax
00007d3d13bd8704  add rsp, 0x08
00007d3d13bd8708  jmp 0x00007D3D13BD3532
00007d3d13bd870d  sub rsp, 0x08
00007d3d13bd8711  push rax
00007d3d13bd8712  push rcx
00007d3d13bd8713  push rdx
00007d3d13bd8714  push rdi
00007d3d13bd8715  push rsi
00007d3d13bd8716  push r8
00007d3d13bd8718  push r9
00007d3d13bd871a  push r10
00007d3d13bd871c  push r11
00007d3d13bd871e  sub rsp, 0xF0
00007d3d13bd8725  vmovaps [rsp], xmm0
00007d3d13bd872a  vmovaps [rsp+0x10], xmm1
00007d3d13bd8730  vmovaps [rsp+0x20], xmm2
00007d3d13bd8736  vmovaps [rsp+0x30], xmm3
00007d3d13bd873c  vmovaps [rsp+0x40], xmm4
00007d3d13bd8742  vmovaps [rsp+0x50], xmm5
00007d3d13bd8748  vmovaps [rsp+0x60], xmm6
00007d3d13bd874e  vmovaps [rsp+0x70], xmm7
00007d3d13bd8754  vmovaps [rsp+0x80], xmm8
00007d3d13bd875d  vmovaps [rsp+0x90], xmm9
00007d3d13bd8766  vmovaps [rsp+0xA0], xmm10
00007d3d13bd876f  vmovaps [rsp+0xB0], xmm11
00007d3d13bd8778  vmovaps [rsp+0xC0], xmm12
00007d3d13bd8781  vmovaps [rsp+0xD0], xmm13
00007d3d13bd878a  vmovaps [rsp+0xE0], xmm14
00007d3d13bd8793  sub rsp, 0x30
00007d3d13bd8797  movaps [rsp], xmm15
00007d3d13bd879c  movaps [rsp+0x10], xmm1
00007d3d13bd87a1  movaps [rsp+0x20], xmm10
00007d3d13bd87a7  lea rdi, [rsp]
00007d3d13bd87ab  mov esi, 0x00
00007d3d13bd87b0  mov rax, 0x5741DAFC8530
00007d3d13bd87ba  call rax
00007d3d13bd87bc  movaps xmm15, [rsp]
00007d3d13bd87c1  add rsp, 0x30
00007d3d13bd87c5  vmovaps xmm0, [rsp]
00007d3d13bd87ca  vmovaps xmm1, [rsp+0x10]
00007d3d13bd87d0  vmovaps xmm2, [rsp+0x20]
00007d3d13bd87d6  vmovaps xmm3, [rsp+0x30]
00007d3d13bd87dc  vmovaps xmm4, [rsp+0x40]
00007d3d13bd87e2  vmovaps xmm5, [rsp+0x50]
00007d3d13bd87e8  vmovaps xmm6, [rsp+0x60]
00007d3d13bd87ee  vmovaps xmm7, [rsp+0x70]
00007d3d13bd87f4  vmovaps xmm8, [rsp+0x80]
00007d3d13bd87fd  vmovaps xmm9, [rsp+0x90]
00007d3d13bd8806  vmovaps xmm10, [rsp+0xA0]
00007d3d13bd880f  vmovaps xmm11, [rsp+0xB0]
00007d3d13bd8818  vmovaps xmm12, [rsp+0xC0]
00007d3d13bd8821  vmovaps xmm13, [rsp+0xD0]
00007d3d13bd882a  vmovaps xmm14, [rsp+0xE0]
00007d3d13bd8833  add rsp, 0xF0
00007d3d13bd883a  pop r11
00007d3d13bd883c  pop r10
00007d3d13bd883e  pop r9
00007d3d13bd8840  pop r8
00007d3d13bd8842  pop rsi
00007d3d13bd8843  pop rdi
00007d3d13bd8844  pop rdx
00007d3d13bd8845  pop rcx
00007d3d13bd8846  pop rax
00007d3d13bd8847  add rsp, 0x08
00007d3d13bd884b  jmp 0x00007D3D13BD3555
00007d3d13bd8850  sub rsp, 0x08
00007d3d13bd8854  push rax
00007d3d13bd8855  push rcx
00007d3d13bd8856  push rdx
00007d3d13bd8857  push rdi
00007d3d13bd8858  push rsi
00007d3d13bd8859  push r8
00007d3d13bd885b  push r9
00007d3d13bd885d  push r10
00007d3d13bd885f  push r11
00007d3d13bd8861  sub rsp, 0xF0
00007d3d13bd8868  vmovaps [rsp], xmm0
00007d3d13bd886d  vmovaps [rsp+0x10], xmm2
00007d3d13bd8873  vmovaps [rsp+0x20], xmm3
00007d3d13bd8879  vmovaps [rsp+0x30], xmm4
00007d3d13bd887f  vmovaps [rsp+0x40], xmm5
00007d3d13bd8885  vmovaps [rsp+0x50], xmm6
00007d3d13bd888b  vmovaps [rsp+0x60], xmm7
00007d3d13bd8891  vmovaps [rsp+0x70], xmm8
00007d3d13bd8897  vmovaps [rsp+0x80], xmm9
00007d3d13bd88a0  vmovaps [rsp+0x90], xmm10
00007d3d13bd88a9  vmovaps [rsp+0xA0], xmm11
00007d3d13bd88b2  vmovaps [rsp+0xB0], xmm12
00007d3d13bd88bb  vmovaps [rsp+0xC0], xmm13
00007d3d13bd88c4  vmovaps [rsp+0xD0], xmm14
00007d3d13bd88cd  vmovaps [rsp+0xE0], xmm15
00007d3d13bd88d6  sub rsp, 0x30
00007d3d13bd88da  movaps [rsp], xmm1
00007d3d13bd88de  movaps [rsp+0x10], xmm7
00007d3d13bd88e3  movaps [rsp+0x20], xmm11
00007d3d13bd88e9  lea rdi, [rsp]
00007d3d13bd88ed  mov esi, 0x00
00007d3d13bd88f2  mov rax, 0x5741DAFC8530
00007d3d13bd88fc  call rax
00007d3d13bd88fe  movaps xmm1, [rsp]
00007d3d13bd8902  add rsp, 0x30
00007d3d13bd8906  vmovaps xmm0, [rsp]
00007d3d13bd890b  vmovaps xmm2, [rsp+0x10]
00007d3d13bd8911  vmovaps xmm3, [rsp+0x20]
00007d3d13bd8917  vmovaps xmm4, [rsp+0x30]
00007d3d13bd891d  vmovaps xmm5, [rsp+0x40]
00007d3d13bd8923  vmovaps xmm6, [rsp+0x50]
00007d3d13bd8929  vmovaps xmm7, [rsp+0x60]
00007d3d13bd892f  vmovaps xmm8, [rsp+0x70]
00007d3d13bd8935  vmovaps xmm9, [rsp+0x80]
00007d3d13bd893e  vmovaps xmm10, [rsp+0x90]
00007d3d13bd8947  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd8950  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd8959  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd8962  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd896b  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd8974  add rsp, 0xF0
00007d3d13bd897b  pop r11
00007d3d13bd897d  pop r10
00007d3d13bd897f  pop r9
00007d3d13bd8981  pop r8
00007d3d13bd8983  pop rsi
00007d3d13bd8984  pop rdi
00007d3d13bd8985  pop rdx
00007d3d13bd8986  pop rcx
00007d3d13bd8987  pop rax
00007d3d13bd8988  add rsp, 0x08
00007d3d13bd898c  jmp 0x00007D3D13BD3576
00007d3d13bd8991  call 0x00007D3D13A0D600
00007d3d13bd8996  jmp 0x00007D3D13BD3589
00007d3d13bd899b  call 0x00007D3D13A0C380
00007d3d13bd89a0  jmp 0x00007D3D13BD3594
00007d3d13bd89a5  call 0x00007D3D13A0E880
00007d3d13bd89aa  jmp 0x00007D3D13BD359F
00007d3d13bd89af  call 0x00007D3D139FF540
00007d3d13bd89b4  jmp 0x00007D3D13BD35AA
00007d3d13bd89b9  int3
00007d3d13bd89ba  nop [rax+rax*1], ax
00007d3d13bd89c0  mov rax, [r15+0x40]
00007d3d13bd89c4  mov r14, [r15+0x58]
00007d3d13bd89c8  lea r12, [rax+r14*1]
00007d3d13bd89cc  movaps xmm1, [r15+0x1D0]
00007d3d13bd89d4  vmovaps [rsp+0x10], xmm1
00007d3d13bd89da  vmovaps xmm15, [rsp+0x10]
00007d3d13bd89e0  por xmm1, xmm15
00007d3d13bd89e5  movaps xmm14, [r15+0x1A0]
00007d3d13bd89ed  vmovaps [rsp+0x10], xmm14
00007d3d13bd89f3  vmovaps xmm13, [rsp+0x10]
00007d3d13bd89f9  por xmm14, xmm13
00007d3d13bd89fe  lea rax, [r12+0x30]
00007d3d13bd8a03  mov r11, [r13+rax*1]
00007d3d13bd8a08  lea rax, [r12+0x38]
00007d3d13bd8a0d  mov r10, [r13+rax*1]
00007d3d13bd8a12  movq xmm13, r11
00007d3d13bd8a17  movq xmm12, r10
00007d3d13bd8a1c  movq xmm13, xmm13
00007d3d13bd8a21  vmovaps [rsp+0x10], xmm13
00007d3d13bd8a27  movq xmm13, xmm13
00007d3d13bd8a2c  movaps [r15+0x130], xmm13
00007d3d13bd8a34  movq xmm12, xmm12
00007d3d13bd8a39  vmovaps [rsp+0x20], xmm12
00007d3d13bd8a3f  movq xmm12, xmm12
00007d3d13bd8a44  movaps [r15+0x280], xmm12
00007d3d13bd8a4c  movaps xmm13, [r15+0x270]
00007d3d13bd8a54  vmovaps [rsp+0x30], xmm13
00007d3d13bd8a5a  vmovaps xmm12, [rsp+0x30]
00007d3d13bd8a60  por xmm13, xmm12
00007d3d13bd8a65  lea rax, [r12+0x20]
00007d3d13bd8a6a  mov r11, [r13+rax*1]
00007d3d13bd8a6f  lea rax, [r12+0x28]
00007d3d13bd8a74  mov r10, [r13+rax*1]
00007d3d13bd8a79  movq xmm12, r11
00007d3d13bd8a7e  movq xmm11, r10
00007d3d13bd8a83  movq xmm12, xmm12
00007d3d13bd8a88  vmovaps [rsp+0x30], xmm12
00007d3d13bd8a8e  movq xmm12, xmm12
00007d3d13bd8a93  movaps [r15+0x150], xmm12
00007d3d13bd8a9b  movq xmm11, xmm11
00007d3d13bd8aa0  vmovaps [rsp+0x40], xmm11
00007d3d13bd8aa6  movq xmm11, xmm11
00007d3d13bd8aab  movaps [r15+0x140], xmm11
00007d3d13bd8ab3  lea rax, [r12+0x10]
00007d3d13bd8ab8  mov r11, [r13+rax*1]
00007d3d13bd8abd  lea rax, [r12+0x18]
00007d3d13bd8ac2  mov r10, [r13+rax*1]
00007d3d13bd8ac7  movq xmm12, r11
00007d3d13bd8acc  movq xmm11, r10
00007d3d13bd8ad1  movq xmm12, xmm12
00007d3d13bd8ad6  vmovaps [rsp+0x50], xmm12
00007d3d13bd8adc  movq xmm12, xmm12
00007d3d13bd8ae1  movaps [r15+0x170], xmm12
00007d3d13bd8ae9  movq xmm11, xmm11
00007d3d13bd8aee  vmovaps [rsp+0x60], xmm11
00007d3d13bd8af4  movq xmm11, xmm11
00007d3d13bd8af9  movaps [r15+0x160], xmm11
00007d3d13bd8b01  mov rax, [r13+r12*1]
00007d3d13bd8b06  vmovq xmm12, rax
00007d3d13bd8b0b  vpbroadcastq xmm12, xmm12
00007d3d13bd8b10  lea rax, [r12+0x08]
00007d3d13bd8b15  mov r12, [r13+rax*1]
00007d3d13bd8b1a  movq xmm11, r12
00007d3d13bd8b1f  movaps [r15+0x230], xmm11
00007d3d13bd8b27  mov rax, [r15+0xF8]
00007d3d13bd8b2e  lea r12, [rax+0x50]
00007d3d13bd8b32  movups xmm11, [r13+r12*1]
00007d3d13bd8b38  lea r12, [rax+0x60]
00007d3d13bd8b3c  movups xmm10, [r13+r12*1]
00007d3d13bd8b42  lea r12, [rax+0x30]
00007d3d13bd8b46  movups xmm9, [r13+r12*1]
00007d3d13bd8b4c  mov r12, [r15+0x50]
00007d3d13bd8b50  lea r11, [r12+r14*1]
00007d3d13bd8b54  mov [r15+0x60], r11
00007d3d13bd8b58  lea r12, [r14+0x40]
00007d3d13bd8b5c  mov [r15+0x58], r12
00007d3d13bd8b60  movaps xmm8, xmm12
00007d3d13bd8b64  mulpd xmm8, xmm15
00007d3d13bd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d13bd8b6f  ptest xmm7, xmm7
00007d3d13bd8b74  jnz 0x00007D3D13BD9997
00007d3d13bd8b7a  movq xmm15, qword ptr [r15+0x230]
00007d3d13bd8b83  vmovaps [rsp+0x70], xmm15
00007d3d13bd8b89  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd8b8f  movaps xmm7, xmm9
00007d3d13bd8b93  mulpd xmm7, xmm15
00007d3d13bd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d13bd8b9d  ptest xmm6, xmm6
00007d3d13bd8ba2  jnz 0x00007D3D13BD9ADB
00007d3d13bd8ba8  vxorps xmm15, xmm15, xmm15
00007d3d13bd8bad  vpbroadcastq xmm15, xmm15
00007d3d13bd8bb2  movaps xmm9, xmm12
00007d3d13bd8bb6  mulpd xmm9, xmm10
00007d3d13bd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d13bd8bc1  ptest xmm6, xmm6
00007d3d13bd8bc6  jnz 0x00007D3D13BD9C1D
00007d3d13bd8bcc  movaps xmm10, xmm12
00007d3d13bd8bd0  mulpd xmm10, xmm11
00007d3d13bd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d3d13bd8bdb  ptest xmm6, xmm6
00007d3d13bd8be0  jnz 0x00007D3D13BD9D61
00007d3d13bd8be6  movaps xmm11, [r15+0x1F0]
00007d3d13bd8bee  movaps xmm6, xmm12
00007d3d13bd8bf2  mulpd xmm6, xmm11
00007d3d13bd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d13bd8bfc  ptest xmm5, xmm5
00007d3d13bd8c01  jnz 0x00007D3D13BD9EA5
00007d3d13bd8c07  movaps xmm12, [r15+0x2A0]
00007d3d13bd8c0f  vmovaps [rsp+0x80], xmm12
00007d3d13bd8c18  vmovaps xmm11, [rsp+0x80]
00007d3d13bd8c21  por xmm12, xmm11
00007d3d13bd8c26  movaps xmm11, [r15+0x250]
00007d3d13bd8c2e  vmovaps [rsp+0x80], xmm11
00007d3d13bd8c37  vmovaps xmm5, [rsp+0x80]
00007d3d13bd8c40  por xmm11, xmm5
00007d3d13bd8c45  vmovaps xmm4, [rsp+0x70]
00007d3d13bd8c4b  vpermilpd xmm4, xmm4, 0x00
00007d3d13bd8c51  movaps xmm3, xmm5
00007d3d13bd8c54  mulpd xmm3, xmm4
00007d3d13bd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007d3d13bd8c5d  ptest xmm2, xmm2
00007d3d13bd8c62  jnz 0x00007D3D13BD9FE7
00007d3d13bd8c68  mov [rsp+0x80], rax
00007d3d13bd8c70  xor eax, eax
00007d3d13bd8c72  mov r14d, 0x200
00007d3d13bd8c78  cmp r12, r14
00007d3d13bd8c7b  cmc
00007d3d13bd8c7c  lahf
00007d3d13bd8c7d  seto al
00007d3d13bd8c80  mov [r15+0x108], eax
00007d3d13bd8c87  movaps xmm5, xmm8
00007d3d13bd8c8b  addpd xmm5, xmm15
00007d3d13bd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007d3d13bd8c95  ptest xmm4, xmm4
00007d3d13bd8c9a  jnz 0x00007D3D13BDA127
00007d3d13bd8ca0  movaps xmm8, [r15+0x1B0]
00007d3d13bd8ca8  movaps xmm4, xmm9
00007d3d13bd8cac  addpd xmm4, xmm8
00007d3d13bd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d3d13bd8cb6  ptest xmm2, xmm2
00007d3d13bd8cbb  jnz 0x00007D3D13BDA269
00007d3d13bd8cc1  movaps xmm9, xmm10
00007d3d13bd8cc5  addpd xmm9, xmm8
00007d3d13bd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007d3d13bd8cd0  ptest xmm2, xmm2
00007d3d13bd8cd5  jnz 0x00007D3D13BDA3AB
00007d3d13bd8cdb  movaps xmm10, [r15+0x2F0]
00007d3d13bd8ce3  vmovaps [rsp+0x90], xmm10
00007d3d13bd8cec  vmovaps xmm8, [rsp+0x90]
00007d3d13bd8cf5  por xmm10, xmm8
00007d3d13bd8cfa  movaps xmm8, [r15+0x2E0]
00007d3d13bd8d02  vmovaps [rsp+0x90], xmm8
00007d3d13bd8d0b  vmovaps xmm2, [rsp+0x90]
00007d3d13bd8d14  por xmm8, xmm2
00007d3d13bd8d19  movaps xmm2, [r15+0x2D0]
00007d3d13bd8d21  vmovaps [rsp+0x90], xmm2
00007d3d13bd8d2a  vmovaps [rsp+0xA0], xmm1
00007d3d13bd8d33  vmovaps xmm1, [rsp+0x90]
00007d3d13bd8d3c  por xmm2, xmm1
00007d3d13bd8d40  movaps xmm1, [r15+0x200]
00007d3d13bd8d48  vmovaps [rsp+0x90], xmm1
00007d3d13bd8d51  vmovaps [rsp+0xB0], xmm15
00007d3d13bd8d5a  vmovaps xmm15, [rsp+0x90]
00007d3d13bd8d63  por xmm1, xmm15
00007d3d13bd8d68  movaps xmm15, [r15+0x1C0]
00007d3d13bd8d70  vmovaps [rsp+0x90], xmm15
00007d3d13bd8d79  vmovaps [rsp+0xC0], xmm1
00007d3d13bd8d82  vmovaps xmm1, [rsp+0x90]
00007d3d13bd8d8b  por xmm15, xmm1
00007d3d13bd8d90  movaps xmm1, [r15+0x190]
00007d3d13bd8d98  vmovaps [rsp+0x90], xmm1
00007d3d13bd8da1  vmovaps [rsp+0xD0], xmm15
00007d3d13bd8daa  vmovaps xmm15, [rsp+0x90]
00007d3d13bd8db3  por xmm1, xmm15
00007d3d13bd8db8  movaps xmm15, [r15+0x300]
00007d3d13bd8dc0  vmovaps [rsp+0x90], xmm15
00007d3d13bd8dc9  vmovaps [rsp+0xE0], xmm1
00007d3d13bd8dd2  vmovaps xmm1, [rsp+0x90]
00007d3d13bd8ddb  por xmm15, xmm1
00007d3d13bd8de0  mov rax, [rsp+0x80]
00007d3d13bd8de8  lea r14, [rax+0xA0]
00007d3d13bd8def  movups xmm1, [r13+r14*1]
00007d3d13bd8df5  lea r14, [rax+0xB0]
00007d3d13bd8dfc  vmovaps [rsp+0x80], xmm1
00007d3d13bd8e05  movups xmm1, [r13+r14*1]
00007d3d13bd8e0b  vmovaps [rsp+0x90], xmm1
00007d3d13bd8e14  vmovaps [rsp+0xF0], xmm15
00007d3d13bd8e1d  vmovaps xmm15, [rsp+0xB0]
00007d3d13bd8e26  vmovaps [rsp+0xB0], xmm14
00007d3d13bd8e2f  movaps xmm1, xmm6
00007d3d13bd8e32  addpd xmm1, xmm15
00007d3d13bd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d13bd8e3c  ptest xmm14, xmm14
00007d3d13bd8e42  jnz 0x00007D3D13BDA503
00007d3d13bd8e48  lea r14, [rax+0xF0]
00007d3d13bd8e4f  movups xmm15, [r13+r14*1]
00007d3d13bd8e55  movaps xmm14, xmm4
00007d3d13bd8e59  addpd xmm14, xmm3
00007d3d13bd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d13bd8e64  ptest xmm6, xmm6
00007d3d13bd8e69  jnz 0x00007D3D13BDA64E
00007d3d13bd8e6f  movaps xmm6, xmm9
00007d3d13bd8e73  addpd xmm6, xmm7
00007d3d13bd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007d3d13bd8e7c  ptest xmm4, xmm4
00007d3d13bd8e81  jnz 0x00007D3D13BDA790
00007d3d13bd8e87  vmovaps xmm9, [rsp+0x70]
00007d3d13bd8e8d  vpermilpd xmm9, xmm9, 0x00
00007d3d13bd8e93  vmovaps xmm4, [rsp+0x90]
00007d3d13bd8e9c  movaps xmm7, xmm4
00007d3d13bd8e9f  mulpd xmm7, xmm9
00007d3d13bd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d3d13bd8ea9  ptest xmm3, xmm3
00007d3d13bd8eae  jnz 0x00007D3D13BDA8D1
00007d3d13bd8eb4  vmovaps xmm9, [rsp+0x50]
00007d3d13bd8eba  vpermilpd xmm9, xmm9, 0x00
00007d3d13bd8ec0  movaps xmm4, xmm15
00007d3d13bd8ec4  mulpd xmm4, xmm9
00007d3d13bd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d3d13bd8ece  ptest xmm3, xmm3
00007d3d13bd8ed3  jnz 0x00007D3D13BDAA12
00007d3d13bd8ed9  lea r14, [rax+0xE0]
00007d3d13bd8ee0  movups xmm15, [r13+r14*1]
00007d3d13bd8ee6  vmovaps xmm9, [rsp+0x70]
00007d3d13bd8eec  vpermilpd xmm9, xmm9, 0x00
00007d3d13bd8ef2  vmovaps [rsp+0x70], xmm1
00007d3d13bd8ef8  vmovaps xmm1, [rsp+0x80]
00007d3d13bd8f01  vmovaps [rsp+0x80], xmm15
00007d3d13bd8f0a  movaps xmm3, xmm1
00007d3d13bd8f0d  mulpd xmm3, xmm9
00007d3d13bd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007d3d13bd8f17  ptest xmm15, xmm15
00007d3d13bd8f1d  jnz 0x00007D3D13BDAB5E
00007d3d13bd8f23  vmovaps xmm1, [rsp+0xF0]
00007d3d13bd8f2c  vmovaps xmm15, [rsp+0xF0]
00007d3d13bd8f35  por xmm1, xmm15
00007d3d13bd8f3a  movaps [r15+0x300], xmm1
00007d3d13bd8f42  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd8f4b  vmovaps xmm9, [rsp+0xE0]
00007d3d13bd8f54  por xmm15, xmm9
00007d3d13bd8f59  movaps [r15+0x190], xmm15
00007d3d13bd8f61  vmovaps xmm9, [rsp+0x50]
00007d3d13bd8f67  vpermilpd xmm9, xmm9, 0x00
00007d3d13bd8f6d  vmovaps [rsp+0x90], xmm1
00007d3d13bd8f76  vmovaps [rsp+0xE0], xmm15
00007d3d13bd8f7f  vmovaps xmm15, [rsp+0x80]
00007d3d13bd8f88  vmovaps [rsp+0x80], xmm14
00007d3d13bd8f91  movaps xmm1, xmm15
00007d3d13bd8f95  mulpd xmm1, xmm9
00007d3d13bd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d13bd8f9f  ptest xmm14, xmm14
00007d3d13bd8fa5  jnz 0x00007D3D13BDAC9F
00007d3d13bd8fab  lea r14, [rax+0x90]
00007d3d13bd8fb2  movups xmm15, [r13+r14*1]
00007d3d13bd8fb8  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd8fc1  vmovaps xmm9, [rsp+0xD0]
00007d3d13bd8fca  por xmm14, xmm9
00007d3d13bd8fcf  movaps [r15+0x1C0], xmm14
00007d3d13bd8fd7  vmovaps xmm9, [rsp+0xC0]
00007d3d13bd8fe0  vmovaps [rsp+0xD0], xmm1
00007d3d13bd8fe9  vmovaps xmm1, [rsp+0xC0]
00007d3d13bd8ff2  por xmm9, xmm1
00007d3d13bd8ff7  movaps [r15+0x200], xmm9
00007d3d13bd8fff  vmovaps [rsp+0xC0], xmm2
00007d3d13bd9008  vmovaps xmm1, [rsp+0xC0]
00007d3d13bd9011  por xmm2, xmm1
00007d3d13bd9015  movaps [r15+0x2D0], xmm2
00007d3d13bd901d  vmovaps [rsp+0xC0], xmm8
00007d3d13bd9026  vmovaps xmm1, [rsp+0xC0]
00007d3d13bd902f  por xmm8, xmm1
00007d3d13bd9034  movaps [r15+0x2E0], xmm8
00007d3d13bd903c  vmovaps [rsp+0xC0], xmm15
00007d3d13bd9045  movaps xmm1, xmm5
00007d3d13bd9048  addpd xmm1, xmm7
00007d3d13bd904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d13bd9051  ptest xmm15, xmm15
00007d3d13bd9057  jnz 0x00007D3D13BDADEB
00007d3d13bd905d  vmovaps xmm15, [rsp+0x50]
00007d3d13bd9063  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd9069  vmovaps xmm5, [rsp+0xC0]
00007d3d13bd9072  vmovaps [rsp+0xC0], xmm1
00007d3d13bd907b  movaps xmm7, xmm5
00007d3d13bd907e  mulpd xmm7, xmm15
00007d3d13bd9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007d3d13bd9088  ptest xmm1, xmm1
00007d3d13bd908d  jnz 0x00007D3D13BDAF2B
00007d3d13bd9093  lea r14, [rax+0x80]
00007d3d13bd909a  movups xmm1, [r13+r14*1]
00007d3d13bd90a0  vmovaps xmm5, [rsp+0x70]
00007d3d13bd90a6  vmovaps [rsp+0x70], xmm1
00007d3d13bd90ac  movaps xmm15, xmm5
00007d3d13bd90b0  addpd xmm15, xmm3
00007d3d13bd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d13bd90bb  ptest xmm1, xmm1
00007d3d13bd90c0  jnz 0x00007D3D13BDB076
00007d3d13bd90c6  vmovaps xmm5, [rsp+0x80]
00007d3d13bd90cf  movaps xmm1, xmm5
00007d3d13bd90d2  addpd xmm1, xmm4
00007d3d13bd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d3d13bd90db  ptest xmm3, xmm3
00007d3d13bd90e0  jnz 0x00007D3D13BDB1B8
00007d3d13bd90e6  vmovaps [rsp+0x80], xmm10
00007d3d13bd90ef  vmovaps xmm5, [rsp+0x80]
00007d3d13bd90f8  por xmm10, xmm5
00007d3d13bd90fd  movaps [r15+0x2F0], xmm10
00007d3d13bd9105  vmovaps xmm5, [rsp+0x50]
00007d3d13bd910b  vpermilpd xmm5, xmm5, 0x00
00007d3d13bd9111  vmovaps xmm3, [rsp+0x70]
00007d3d13bd9117  vmovaps [rsp+0x50], xmm1
00007d3d13bd911d  movaps xmm4, xmm3
00007d3d13bd9120  mulpd xmm4, xmm5
00007d3d13bd9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007d3d13bd9129  ptest xmm1, xmm1
00007d3d13bd912e  jnz 0x00007D3D13BDB2F8
00007d3d13bd9134  lea r14, [rax+0xD0]
00007d3d13bd913b  movups xmm1, [r13+r14*1]
00007d3d13bd9141  vmovaps xmm3, [rsp+0xD0]
00007d3d13bd914a  vmovaps [rsp+0x70], xmm1
00007d3d13bd9150  movaps xmm5, xmm6
00007d3d13bd9153  addpd xmm5, xmm3
00007d3d13bd9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007d3d13bd915c  ptest xmm1, xmm1
00007d3d13bd9161  jnz 0x00007D3D13BDB442
00007d3d13bd9167  vmovaps xmm1, [rsp+0x60]
00007d3d13bd916d  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd9173  movaps xmm6, xmm9
00007d3d13bd9177  mulpd xmm6, xmm1
00007d3d13bd917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d3d13bd9180  ptest xmm3, xmm3
00007d3d13bd9185  jnz 0x00007D3D13BDB582
00007d3d13bd918b  movaps [r15+0x260], xmm6
00007d3d13bd9193  vxorps xmm1, xmm1, xmm1
00007d3d13bd9197  vpbroadcastq xmm1, xmm1
00007d3d13bd919c  movaps [r15+0x1B0], xmm1
00007d3d13bd91a4  vmovaps xmm1, [rsp+0x60]
00007d3d13bd91aa  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd91b0  vmovaps xmm3, [rsp+0x70]
00007d3d13bd91b6  vmovaps [rsp+0x70], xmm15
00007d3d13bd91bc  movaps xmm9, xmm3
00007d3d13bd91c0  mulpd xmm9, xmm1
00007d3d13bd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d3d13bd91cb  ptest xmm15, xmm15
00007d3d13bd91d1  jnz 0x00007D3D13BDB6C3
00007d3d13bd91d7  lea r14, [rax+0xC0]
00007d3d13bd91de  movups xmm1, [r13+r14*1]
00007d3d13bd91e4  vmovaps xmm3, [rsp+0xC0]
00007d3d13bd91ed  vmovaps [rsp+0x80], xmm1
00007d3d13bd91f6  movaps xmm15, xmm3
00007d3d13bd91fa  addpd xmm15, xmm7
00007d3d13bd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d13bd9205  ptest xmm1, xmm1
00007d3d13bd920a  jnz 0x00007D3D13BDB80F
00007d3d13bd9210  vmovaps [rsp+0xC0], xmm13
00007d3d13bd9219  vmovaps xmm1, [rsp+0xC0]
00007d3d13bd9222  por xmm13, xmm1
00007d3d13bd9227  movaps [r15+0x270], xmm13
00007d3d13bd922f  vmovaps xmm1, [rsp+0xB0]
00007d3d13bd9238  vmovaps xmm7, [rsp+0xB0]
00007d3d13bd9241  por xmm1, xmm7
00007d3d13bd9245  movaps [r15+0x1A0], xmm1
00007d3d13bd924d  vmovaps xmm1, [rsp+0x60]
00007d3d13bd9253  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd9259  vmovaps [rsp+0xB0], xmm1
00007d3d13bd9262  vmovaps xmm1, [rsp+0x80]
00007d3d13bd926b  vmovaps [rsp+0x80], xmm15
00007d3d13bd9274  vmovaps xmm15, [rsp+0xB0]
00007d3d13bd927d  vmovaps [rsp+0xB0], xmm14
00007d3d13bd9286  movaps xmm3, xmm1
00007d3d13bd9289  mulpd xmm3, xmm15
00007d3d13bd928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007d3d13bd9293  ptest xmm14, xmm14
00007d3d13bd9299  jnz 0x00007D3D13BDB951
00007d3d13bd929f  lea r14, [rax+0x20]
00007d3d13bd92a3  movups xmm1, [r13+r14*1]
00007d3d13bd92a9  movaps [r15+0x110], xmm1
00007d3d13bd92b1  vmovaps xmm14, [rsp+0x70]
00007d3d13bd92b7  vmovaps [rsp+0x70], xmm1
00007d3d13bd92bd  movaps xmm15, xmm14
00007d3d13bd92c1  addpd xmm15, xmm4
00007d3d13bd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d13bd92cc  ptest xmm1, xmm1
00007d3d13bd92d1  jnz 0x00007D3D13BDBA9C
00007d3d13bd92d7  vmovaps xmm1, [rsp+0x60]
00007d3d13bd92dd  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd92e3  movaps xmm14, xmm2
00007d3d13bd92e7  mulpd xmm14, xmm1
00007d3d13bd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007d3d13bd92f2  ptest xmm4, xmm4
00007d3d13bd92f7  jnz 0x00007D3D13BDBBDF
00007d3d13bd92fd  vmovaps xmm4, [rsp+0x50]
00007d3d13bd9303  movaps xmm1, xmm4
00007d3d13bd9306  addpd xmm1, xmm9
00007d3d13bd930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d13bd9310  ptest xmm2, xmm2
00007d3d13bd9315  jnz 0x00007D3D13BDBD21
00007d3d13bd931b  vmovaps xmm9, [rsp+0x30]
00007d3d13bd9321  vpermilpd xmm9, xmm9, 0x00
00007d3d13bd9327  vmovaps xmm2, [rsp+0x70]
00007d3d13bd932d  vmovaps [rsp+0x50], xmm1
00007d3d13bd9333  movaps xmm4, xmm2
00007d3d13bd9336  mulpd xmm4, xmm9
00007d3d13bd933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d3d13bd9340  ptest xmm1, xmm1
00007d3d13bd9345  jnz 0x00007D3D13BDBE62
00007d3d13bd934b  vmovaps xmm1, [rsp+0x30]
00007d3d13bd9351  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd9357  vmovaps xmm2, [rsp+0x90]
00007d3d13bd9360  vmovaps [rsp+0x60], xmm15
00007d3d13bd9366  movaps xmm9, xmm2
00007d3d13bd936a  mulpd xmm9, xmm1
00007d3d13bd936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d3d13bd9375  ptest xmm15, xmm15
00007d3d13bd937b  jnz 0x00007D3D13BDBFA3
00007d3d13bd9381  vmovaps xmm15, [rsp+0x80]
00007d3d13bd938a  movaps xmm1, xmm15
00007d3d13bd938e  addpd xmm1, xmm6
00007d3d13bd9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d13bd9397  ptest xmm2, xmm2
00007d3d13bd939c  jnz 0x00007D3D13BDC0E5
00007d3d13bd93a2  movaps xmm15, xmm5
00007d3d13bd93a6  addpd xmm15, xmm3
00007d3d13bd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007d3d13bd93b1  ptest xmm6, xmm6
00007d3d13bd93b6  jnz 0x00007D3D13BDC226
00007d3d13bd93bc  vmovaps xmm6, [rsp+0x30]
00007d3d13bd93c2  vpermilpd xmm6, xmm6, 0x00
00007d3d13bd93c8  movaps xmm5, xmm8
00007d3d13bd93cc  mulpd xmm5, xmm6
00007d3d13bd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d3d13bd93d5  ptest xmm3, xmm3
00007d3d13bd93da  jnz 0x00007D3D13BDC368
00007d3d13bd93e0  vmovaps xmm8, [rsp+0x30]
00007d3d13bd93e6  vpermilpd xmm8, xmm8, 0x00
00007d3d13bd93ec  movaps xmm6, xmm10
00007d3d13bd93f0  mulpd xmm6, xmm8
00007d3d13bd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007d3d13bd93fa  ptest xmm3, xmm3
00007d3d13bd93ff  jnz 0x00007D3D13BDC4A9
00007d3d13bd9405  vmovaps xmm8, [rsp+0x60]
00007d3d13bd940b  movaps xmm10, xmm8
00007d3d13bd940f  addpd xmm10, xmm14
00007d3d13bd9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007d3d13bd941a  ptest xmm3, xmm3
00007d3d13bd941f  jnz 0x00007D3D13BDC5EB
00007d3d13bd9425  vmovaps xmm8, [rsp+0x50]
00007d3d13bd942b  movaps xmm14, xmm8
00007d3d13bd942f  addpd xmm14, xmm4
00007d3d13bd9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007d3d13bd943a  ptest xmm3, xmm3
00007d3d13bd943f  jnz 0x00007D3D13BDC72F
00007d3d13bd9445  vmovaps xmm8, [rsp+0x40]
00007d3d13bd944b  vpermilpd xmm8, xmm8, 0x00
00007d3d13bd9451  movaps xmm4, xmm13
00007d3d13bd9455  mulpd xmm4, xmm8
00007d3d13bd945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d3d13bd945f  ptest xmm3, xmm3
00007d3d13bd9464  jnz 0x00007D3D13BDC872
00007d3d13bd946a  movaps xmm13, xmm15
00007d3d13bd946e  addpd xmm13, xmm9
00007d3d13bd9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007d3d13bd9479  ptest xmm8, xmm8
00007d3d13bd947f  jnz 0x00007D3D13BDC9B4
00007d3d13bd9485  movaps xmm15, xmm1
00007d3d13bd9489  addpd xmm15, xmm5
00007d3d13bd948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d13bd9494  ptest xmm9, xmm9
00007d3d13bd949a  jnz 0x00007D3D13BDCAF8
00007d3d13bd94a0  vmovaps [rsp+0x30], xmm11
00007d3d13bd94a6  vmovaps xmm1, [rsp+0x30]
00007d3d13bd94ac  por xmm11, xmm1
00007d3d13bd94b1  movaps [r15+0x250], xmm11
00007d3d13bd94b9  vmovaps [rsp+0x30], xmm12
00007d3d13bd94bf  vmovaps xmm1, [rsp+0x30]
00007d3d13bd94c5  por xmm12, xmm1
00007d3d13bd94ca  movaps [r15+0x2A0], xmm12
00007d3d13bd94d2  vmovaps xmm1, [rsp+0xA0]
00007d3d13bd94db  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd94e4  por xmm1, xmm11
00007d3d13bd94e9  movaps [r15+0x1D0], xmm1
00007d3d13bd94f1  lea r14, [rax+0x40]
00007d3d13bd94f5  movups xmm1, [r13+r14*1]
00007d3d13bd94fb  movaps [r15+0x2C0], xmm1
00007d3d13bd9503  vmovaps xmm11, [rsp+0x40]
00007d3d13bd9509  vpermilpd xmm11, xmm11, 0x00
00007d3d13bd950f  vmovaps xmm8, [rsp+0xE0]
00007d3d13bd9518  movaps xmm9, xmm8
00007d3d13bd951c  mulpd xmm9, xmm11
00007d3d13bd9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007d3d13bd9527  ptest xmm5, xmm5
00007d3d13bd952c  jnz 0x00007D3D13BDCC44
00007d3d13bd9532  movaps xmm11, xmm10
00007d3d13bd9536  addpd xmm11, xmm6
00007d3d13bd953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d3d13bd9541  ptest xmm8, xmm8
00007d3d13bd9547  jnz 0x00007D3D13BDCD88
00007d3d13bd954d  movaps xmm10, xmm14
00007d3d13bd9551  addpd xmm10, xmm4
00007d3d13bd9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007d3d13bd955c  ptest xmm8, xmm8
00007d3d13bd9562  jnz 0x00007D3D13BDCECB
00007d3d13bd9568  vmovaps xmm14, [rsp+0x40]
00007d3d13bd956e  vpermilpd xmm14, xmm14, 0x00
00007d3d13bd9574  movaps xmm8, xmm1
00007d3d13bd9578  mulpd xmm8, xmm14
00007d3d13bd957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d13bd9583  ptest xmm6, xmm6
00007d3d13bd9588  jnz 0x00007D3D13BDD00E
00007d3d13bd958e  movaps xmm1, [r15+0x2B0]
00007d3d13bd9596  vmovaps xmm14, [rsp+0x40]
00007d3d13bd959c  vpermilpd xmm14, xmm14, 0x00
00007d3d13bd95a2  movaps xmm6, xmm1
00007d3d13bd95a5  mulpd xmm6, xmm14
00007d3d13bd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d13bd95af  ptest xmm5, xmm5
00007d3d13bd95b4  jnz 0x00007D3D13BDD151
00007d3d13bd95ba  vmovaps xmm1, [rsp+0x10]
00007d3d13bd95c0  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd95c6  movaps xmm14, xmm12
00007d3d13bd95ca  mulpd xmm14, xmm1
00007d3d13bd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007d3d13bd95d5  ptest xmm5, xmm5
00007d3d13bd95da  jnz 0x00007D3D13BDD292
00007d3d13bd95e0  movaps xmm1, xmm13
00007d3d13bd95e4  addpd xmm1, xmm9
00007d3d13bd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d13bd95ee  ptest xmm12, xmm12
00007d3d13bd95f4  jnz 0x00007D3D13BDD3D5
00007d3d13bd95fa  vmovaps xmm13, [rsp+0x10]
00007d3d13bd9600  vpermilpd xmm13, xmm13, 0x00
00007d3d13bd9606  movaps xmm12, xmm7
00007d3d13bd960a  mulpd xmm12, xmm13
00007d3d13bd960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d13bd9615  ptest xmm9, xmm9
00007d3d13bd961b  jnz 0x00007D3D13BDD517
00007d3d13bd9621  movaps xmm13, xmm15
00007d3d13bd9625  addpd xmm13, xmm8
00007d3d13bd962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d3d13bd9630  ptest xmm9, xmm9
00007d3d13bd9636  jnz 0x00007D3D13BDD65A
00007d3d13bd963c  movaps xmm15, [r15+0x290]
00007d3d13bd9644  vmovaps xmm9, [rsp+0x10]
00007d3d13bd964a  vpermilpd xmm9, xmm9, 0x00
00007d3d13bd9650  movaps xmm8, xmm15
00007d3d13bd9654  mulpd xmm8, xmm9
00007d3d13bd9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d13bd965f  ptest xmm7, xmm7
00007d3d13bd9664  jnz 0x00007D3D13BDD79E
00007d3d13bd966a  movaps xmm15, xmm11
00007d3d13bd966e  addpd xmm15, xmm6
00007d3d13bd9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d13bd9679  ptest xmm9, xmm9
00007d3d13bd967f  jnz 0x00007D3D13BDD8E2
00007d3d13bd9685  movaps xmm11, [r15+0x1E0]
00007d3d13bd968d  vmovaps xmm9, [rsp+0x10]
00007d3d13bd9693  vpermilpd xmm9, xmm9, 0x00
00007d3d13bd9699  movaps xmm7, xmm11
00007d3d13bd969d  mulpd xmm7, xmm9
00007d3d13bd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d13bd96a7  ptest xmm6, xmm6
00007d3d13bd96ac  jnz 0x00007D3D13BDDA25
00007d3d13bd96b2  movaps xmm11, xmm10
00007d3d13bd96b6  addpd xmm11, xmm14
00007d3d13bd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007d3d13bd96c1  ptest xmm9, xmm9
00007d3d13bd96c7  jnz 0x00007D3D13BDDB67
00007d3d13bd96cd  lea r14, [rax+0x70]
00007d3d13bd96d1  movups xmm14, [r13+r14*1]
00007d3d13bd96d7  movaps [r15+0x240], xmm14
00007d3d13bd96df  movaps xmm10, xmm1
00007d3d13bd96e3  addpd xmm10, xmm12
00007d3d13bd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007d3d13bd96ee  ptest xmm9, xmm9
00007d3d13bd96f4  jnz 0x00007D3D13BDDCB5
00007d3d13bd96fa  movaps [r15+0x170], xmm10
00007d3d13bd9702  vmovaps xmm1, [rsp+0x20]
00007d3d13bd9708  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd970e  movaps xmm12, xmm14
00007d3d13bd9712  mulpd xmm12, xmm1
00007d3d13bd9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d13bd971d  ptest xmm9, xmm9
00007d3d13bd9723  jnz 0x00007D3D13BDDDF8
00007d3d13bd9729  vmovaps xmm1, [rsp+0x20]
00007d3d13bd972f  vpermilpd xmm1, xmm1, 0x00
00007d3d13bd9735  vmovaps xmm9, [rsp+0xB0]
00007d3d13bd973e  movaps xmm14, xmm9
00007d3d13bd9742  mulpd xmm14, xmm1
00007d3d13bd9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d13bd974d  ptest xmm6, xmm6
00007d3d13bd9752  jnz 0x00007D3D13BDDF3B
00007d3d13bd9758  movaps [r15+0x180], xmm14
00007d3d13bd9760  movaps xmm1, xmm13
00007d3d13bd9764  addpd xmm1, xmm8
00007d3d13bd9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007d3d13bd976e  ptest xmm9, xmm9
00007d3d13bd9774  jnz 0x00007D3D13BDE07E
00007d3d13bd977a  movaps [r15+0x210], xmm1
00007d3d13bd9782  movups xmm13, [r13+rax*1]
00007d3d13bd9788  lea r14, [rax+0x10]
00007d3d13bd978c  movups xmm9, [r13+r14*1]
00007d3d13bd9792  movaps [r15+0x230], xmm9
00007d3d13bd979a  movaps xmm8, xmm15
00007d3d13bd979e  addpd xmm8, xmm7
00007d3d13bd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d13bd97a9  ptest xmm6, xmm6
00007d3d13bd97ae  jnz 0x00007D3D13BDE1D4
00007d3d13bd97b4  movaps [r15+0x130], xmm8
00007d3d13bd97bc  vmovaps xmm15, [rsp+0x20]
00007d3d13bd97c2  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd97c8  movaps xmm7, xmm9
00007d3d13bd97cc  mulpd xmm7, xmm15
00007d3d13bd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d13bd97d6  ptest xmm6, xmm6
00007d3d13bd97db  jnz 0x00007D3D13BDE317
00007d3d13bd97e1  movaps [r15+0x220], xmm7
00007d3d13bd97e9  vmovaps xmm15, [rsp+0x20]
00007d3d13bd97ef  vpermilpd xmm15, xmm15, 0x00
00007d3d13bd97f5  movaps xmm9, xmm13
00007d3d13bd97f9  mulpd xmm9, xmm15
00007d3d13bd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d13bd9804  ptest xmm6, xmm6
00007d3d13bd9809  jnz 0x00007D3D13BDE459
00007d3d13bd980f  movaps xmm15, xmm11
00007d3d13bd9813  addpd xmm15, xmm12
00007d3d13bd9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007d3d13bd981e  ptest xmm13, xmm13
00007d3d13bd9824  jnz 0x00007D3D13BDE59D
00007d3d13bd982a  movaps [r15+0x140], xmm15
00007d3d13bd9832  movaps xmm13, xmm10
00007d3d13bd9836  addpd xmm13, xmm14
00007d3d13bd983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d3d13bd9841  ptest xmm12, xmm12
00007d3d13bd9847  jnz 0x00007D3D13BDE6E1
00007d3d13bd984d  movaps [r15+0x150], xmm13
00007d3d13bd9855  movaps xmm14, xmm1
00007d3d13bd9859  addpd xmm14, xmm7
00007d3d13bd985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d3d13bd9864  ptest xmm12, xmm12
00007d3d13bd986a  jnz 0x00007D3D13BDE825
00007d3d13bd9870  movaps [r15+0x160], xmm14
00007d3d13bd9878  movaps xmm1, xmm8
00007d3d13bd987c  addpd xmm1, xmm9
00007d3d13bd9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d13bd9886  ptest xmm12, xmm12
00007d3d13bd988c  jnz 0x00007D3D13BDE967
00007d3d13bd9892  movaps [r15+0x120], xmm1
00007d3d13bd989a  movups [r13+r11*1], xmm15
00007d3d13bd98a0  lea rax, [r11+0x10]
00007d3d13bd98a4  movups [r13+rax*1], xmm13
00007d3d13bd98aa  lea rax, [r11+0x20]
00007d3d13bd98ae  movups [r13+rax*1], xmm14
00007d3d13bd98b4  lea rax, [r11+0x30]
00007d3d13bd98b8  movups [r13+rax*1], xmm1
00007d3d13bd98be  mov eax, [r15+0x108]
00007d3d13bd98c5  sahf
00007d3d13bd98c6  jnz 0x00007D3D13BD98F8
00007d3d13bd98c8  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd98d0  jz 0x00007D3D13BDEAE0
00007d3d13bd98d6  nop [rax+rax*1], ax
00007d3d13bd98df  nop [rax+rax*1], eax
00007d3d13bd98e7  mov eax, 0x4106D0
00007d3d13bd98ec  mov [r15+0x100], rax
00007d3d13bd98f3  jmp 0x00007D3D139FE110
00007d3d13bd98f8  cmp dword ptr [r15+0x318], 0x00
00007d3d13bd9900  jz 0x00007D3D13BD89C0
00007d3d13bd9906  nop [rax+rax*1], ax
00007d3d13bd990f  nop [rax+rax*1], eax
00007d3d13bd9917  mov eax, 0x410504
00007d3d13bd991c  mov [r15+0x100], rax
00007d3d13bd9923  jmp 0x00007D3D139FE110
00007d3d13bd9928  int3
00007d3d13bd9929  call 0x00007D3D13A0A4B0
00007d3d13bd992e  jmp 0x00007D3D13BD8A08
00007d3d13bd9933  call 0x00007D3D13A09240
00007d3d13bd9938  jmp 0x00007D3D13BD8A12
00007d3d13bd993d  call 0x00007D3D13A0A4B0
00007d3d13bd9942  jmp 0x00007D3D13BD8A6F
00007d3d13bd9947  call 0x00007D3D13A09240
00007d3d13bd994c  jmp 0x00007D3D13BD8A79
00007d3d13bd9951  call 0x00007D3D13A0A4B0
00007d3d13bd9956  jmp 0x00007D3D13BD8ABD
00007d3d13bd995b  call 0x00007D3D13A09240
00007d3d13bd9960  jmp 0x00007D3D13BD8AC7
00007d3d13bd9965  call 0x00007D3D13AB47C0
00007d3d13bd996a  jmp 0x00007D3D13BD8B06
00007d3d13bd996f  call 0x00007D3D13A0B720
00007d3d13bd9974  jmp 0x00007D3D13BD8B1A
00007d3d13bd9979  call 0x00007D3D13ABFC30
00007d3d13bd997e  jmp 0x00007D3D13BD8B38
00007d3d13bd9983  call 0x00007D3D13ABE9C0
00007d3d13bd9988  jmp 0x00007D3D13BD8B42
00007d3d13bd998d  call 0x00007D3D13ABD750
00007d3d13bd9992  jmp 0x00007D3D13BD8B4C
00007d3d13bd9997  sub rsp, 0x08
00007d3d13bd999b  push rax
00007d3d13bd999c  push rcx
00007d3d13bd999d  push rdx
00007d3d13bd999e  push rdi
00007d3d13bd999f  push rsi
00007d3d13bd99a0  push r8
00007d3d13bd99a2  push r9
00007d3d13bd99a4  push r10
00007d3d13bd99a6  push r11
00007d3d13bd99a8  sub rsp, 0xF0
00007d3d13bd99af  vmovaps [rsp], xmm0
00007d3d13bd99b4  vmovaps [rsp+0x10], xmm1
00007d3d13bd99ba  vmovaps [rsp+0x20], xmm2
00007d3d13bd99c0  vmovaps [rsp+0x30], xmm3
00007d3d13bd99c6  vmovaps [rsp+0x40], xmm4
00007d3d13bd99cc  vmovaps [rsp+0x50], xmm5
00007d3d13bd99d2  vmovaps [rsp+0x60], xmm6
00007d3d13bd99d8  vmovaps [rsp+0x70], xmm7
00007d3d13bd99de  vmovaps [rsp+0x80], xmm9
00007d3d13bd99e7  vmovaps [rsp+0x90], xmm10
00007d3d13bd99f0  vmovaps [rsp+0xA0], xmm11
00007d3d13bd99f9  vmovaps [rsp+0xB0], xmm12
00007d3d13bd9a02  vmovaps [rsp+0xC0], xmm13
00007d3d13bd9a0b  vmovaps [rsp+0xD0], xmm14
00007d3d13bd9a14  vmovaps [rsp+0xE0], xmm15
00007d3d13bd9a1d  sub rsp, 0x30
00007d3d13bd9a21  movaps [rsp], xmm8
00007d3d13bd9a26  movaps [rsp+0x10], xmm12
00007d3d13bd9a2c  movaps [rsp+0x20], xmm15
00007d3d13bd9a32  lea rdi, [rsp]
00007d3d13bd9a36  mov esi, 0x00
00007d3d13bd9a3b  mov rax, 0x5741DAFC8530
00007d3d13bd9a45  call rax
00007d3d13bd9a47  movaps xmm8, [rsp]
00007d3d13bd9a4c  add rsp, 0x30
00007d3d13bd9a50  vmovaps xmm0, [rsp]
00007d3d13bd9a55  vmovaps xmm1, [rsp+0x10]
00007d3d13bd9a5b  vmovaps xmm2, [rsp+0x20]
00007d3d13bd9a61  vmovaps xmm3, [rsp+0x30]
00007d3d13bd9a67  vmovaps xmm4, [rsp+0x40]
00007d3d13bd9a6d  vmovaps xmm5, [rsp+0x50]
00007d3d13bd9a73  vmovaps xmm6, [rsp+0x60]
00007d3d13bd9a79  vmovaps xmm7, [rsp+0x70]
00007d3d13bd9a7f  vmovaps xmm9, [rsp+0x80]
00007d3d13bd9a88  vmovaps xmm10, [rsp+0x90]
00007d3d13bd9a91  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd9a9a  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd9aa3  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd9aac  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd9ab5  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd9abe  add rsp, 0xF0
00007d3d13bd9ac5  pop r11
00007d3d13bd9ac7  pop r10
00007d3d13bd9ac9  pop r9
00007d3d13bd9acb  pop r8
00007d3d13bd9acd  pop rsi
00007d3d13bd9ace  pop rdi
00007d3d13bd9acf  pop rdx
00007d3d13bd9ad0  pop rcx
00007d3d13bd9ad1  pop rax
00007d3d13bd9ad2  add rsp, 0x08
00007d3d13bd9ad6  jmp 0x00007D3D13BD8B7A
00007d3d13bd9adb  sub rsp, 0x08
00007d3d13bd9adf  push rax
00007d3d13bd9ae0  push rcx
00007d3d13bd9ae1  push rdx
00007d3d13bd9ae2  push rdi
00007d3d13bd9ae3  push rsi
00007d3d13bd9ae4  push r8
00007d3d13bd9ae6  push r9
00007d3d13bd9ae8  push r10
00007d3d13bd9aea  push r11
00007d3d13bd9aec  sub rsp, 0xF0
00007d3d13bd9af3  vmovaps [rsp], xmm0
00007d3d13bd9af8  vmovaps [rsp+0x10], xmm1
00007d3d13bd9afe  vmovaps [rsp+0x20], xmm2
00007d3d13bd9b04  vmovaps [rsp+0x30], xmm3
00007d3d13bd9b0a  vmovaps [rsp+0x40], xmm4
00007d3d13bd9b10  vmovaps [rsp+0x50], xmm5
00007d3d13bd9b16  vmovaps [rsp+0x60], xmm6
00007d3d13bd9b1c  vmovaps [rsp+0x70], xmm8
00007d3d13bd9b22  vmovaps [rsp+0x80], xmm9
00007d3d13bd9b2b  vmovaps [rsp+0x90], xmm10
00007d3d13bd9b34  vmovaps [rsp+0xA0], xmm11
00007d3d13bd9b3d  vmovaps [rsp+0xB0], xmm12
00007d3d13bd9b46  vmovaps [rsp+0xC0], xmm13
00007d3d13bd9b4f  vmovaps [rsp+0xD0], xmm14
00007d3d13bd9b58  vmovaps [rsp+0xE0], xmm15
00007d3d13bd9b61  sub rsp, 0x30
00007d3d13bd9b65  movaps [rsp], xmm7
00007d3d13bd9b69  movaps [rsp+0x10], xmm9
00007d3d13bd9b6f  movaps [rsp+0x20], xmm15
00007d3d13bd9b75  lea rdi, [rsp]
00007d3d13bd9b79  mov esi, 0x00
00007d3d13bd9b7e  mov rax, 0x5741DAFC8530
00007d3d13bd9b88  call rax
00007d3d13bd9b8a  movaps xmm7, [rsp]
00007d3d13bd9b8e  add rsp, 0x30
00007d3d13bd9b92  vmovaps xmm0, [rsp]
00007d3d13bd9b97  vmovaps xmm1, [rsp+0x10]
00007d3d13bd9b9d  vmovaps xmm2, [rsp+0x20]
00007d3d13bd9ba3  vmovaps xmm3, [rsp+0x30]
00007d3d13bd9ba9  vmovaps xmm4, [rsp+0x40]
00007d3d13bd9baf  vmovaps xmm5, [rsp+0x50]
00007d3d13bd9bb5  vmovaps xmm6, [rsp+0x60]
00007d3d13bd9bbb  vmovaps xmm8, [rsp+0x70]
00007d3d13bd9bc1  vmovaps xmm9, [rsp+0x80]
00007d3d13bd9bca  vmovaps xmm10, [rsp+0x90]
00007d3d13bd9bd3  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd9bdc  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd9be5  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd9bee  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd9bf7  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd9c00  add rsp, 0xF0
00007d3d13bd9c07  pop r11
00007d3d13bd9c09  pop r10
00007d3d13bd9c0b  pop r9
00007d3d13bd9c0d  pop r8
00007d3d13bd9c0f  pop rsi
00007d3d13bd9c10  pop rdi
00007d3d13bd9c11  pop rdx
00007d3d13bd9c12  pop rcx
00007d3d13bd9c13  pop rax
00007d3d13bd9c14  add rsp, 0x08
00007d3d13bd9c18  jmp 0x00007D3D13BD8BA8
00007d3d13bd9c1d  sub rsp, 0x08
00007d3d13bd9c21  push rax
00007d3d13bd9c22  push rcx
00007d3d13bd9c23  push rdx
00007d3d13bd9c24  push rdi
00007d3d13bd9c25  push rsi
00007d3d13bd9c26  push r8
00007d3d13bd9c28  push r9
00007d3d13bd9c2a  push r10
00007d3d13bd9c2c  push r11
00007d3d13bd9c2e  sub rsp, 0xF0
00007d3d13bd9c35  vmovaps [rsp], xmm0
00007d3d13bd9c3a  vmovaps [rsp+0x10], xmm1
00007d3d13bd9c40  vmovaps [rsp+0x20], xmm2
00007d3d13bd9c46  vmovaps [rsp+0x30], xmm3
00007d3d13bd9c4c  vmovaps [rsp+0x40], xmm4
00007d3d13bd9c52  vmovaps [rsp+0x50], xmm5
00007d3d13bd9c58  vmovaps [rsp+0x60], xmm6
00007d3d13bd9c5e  vmovaps [rsp+0x70], xmm7
00007d3d13bd9c64  vmovaps [rsp+0x80], xmm8
00007d3d13bd9c6d  vmovaps [rsp+0x90], xmm10
00007d3d13bd9c76  vmovaps [rsp+0xA0], xmm11
00007d3d13bd9c7f  vmovaps [rsp+0xB0], xmm12
00007d3d13bd9c88  vmovaps [rsp+0xC0], xmm13
00007d3d13bd9c91  vmovaps [rsp+0xD0], xmm14
00007d3d13bd9c9a  vmovaps [rsp+0xE0], xmm15
00007d3d13bd9ca3  sub rsp, 0x30
00007d3d13bd9ca7  movaps [rsp], xmm9
00007d3d13bd9cac  movaps [rsp+0x10], xmm12
00007d3d13bd9cb2  movaps [rsp+0x20], xmm10
00007d3d13bd9cb8  lea rdi, [rsp]
00007d3d13bd9cbc  mov esi, 0x00
00007d3d13bd9cc1  mov rax, 0x5741DAFC8530
00007d3d13bd9ccb  call rax
00007d3d13bd9ccd  movaps xmm9, [rsp]
00007d3d13bd9cd2  add rsp, 0x30
00007d3d13bd9cd6  vmovaps xmm0, [rsp]
00007d3d13bd9cdb  vmovaps xmm1, [rsp+0x10]
00007d3d13bd9ce1  vmovaps xmm2, [rsp+0x20]
00007d3d13bd9ce7  vmovaps xmm3, [rsp+0x30]
00007d3d13bd9ced  vmovaps xmm4, [rsp+0x40]
00007d3d13bd9cf3  vmovaps xmm5, [rsp+0x50]
00007d3d13bd9cf9  vmovaps xmm6, [rsp+0x60]
00007d3d13bd9cff  vmovaps xmm7, [rsp+0x70]
00007d3d13bd9d05  vmovaps xmm8, [rsp+0x80]
00007d3d13bd9d0e  vmovaps xmm10, [rsp+0x90]
00007d3d13bd9d17  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd9d20  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd9d29  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd9d32  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd9d3b  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd9d44  add rsp, 0xF0
00007d3d13bd9d4b  pop r11
00007d3d13bd9d4d  pop r10
00007d3d13bd9d4f  pop r9
00007d3d13bd9d51  pop r8
00007d3d13bd9d53  pop rsi
00007d3d13bd9d54  pop rdi
00007d3d13bd9d55  pop rdx
00007d3d13bd9d56  pop rcx
00007d3d13bd9d57  pop rax
00007d3d13bd9d58  add rsp, 0x08
00007d3d13bd9d5c  jmp 0x00007D3D13BD8BCC
00007d3d13bd9d61  sub rsp, 0x08
00007d3d13bd9d65  push rax
00007d3d13bd9d66  push rcx
00007d3d13bd9d67  push rdx
00007d3d13bd9d68  push rdi
00007d3d13bd9d69  push rsi
00007d3d13bd9d6a  push r8
00007d3d13bd9d6c  push r9
00007d3d13bd9d6e  push r10
00007d3d13bd9d70  push r11
00007d3d13bd9d72  sub rsp, 0xF0
00007d3d13bd9d79  vmovaps [rsp], xmm0
00007d3d13bd9d7e  vmovaps [rsp+0x10], xmm1
00007d3d13bd9d84  vmovaps [rsp+0x20], xmm2
00007d3d13bd9d8a  vmovaps [rsp+0x30], xmm3
00007d3d13bd9d90  vmovaps [rsp+0x40], xmm4
00007d3d13bd9d96  vmovaps [rsp+0x50], xmm5
00007d3d13bd9d9c  vmovaps [rsp+0x60], xmm6
00007d3d13bd9da2  vmovaps [rsp+0x70], xmm7
00007d3d13bd9da8  vmovaps [rsp+0x80], xmm8
00007d3d13bd9db1  vmovaps [rsp+0x90], xmm9
00007d3d13bd9dba  vmovaps [rsp+0xA0], xmm11
00007d3d13bd9dc3  vmovaps [rsp+0xB0], xmm12
00007d3d13bd9dcc  vmovaps [rsp+0xC0], xmm13
00007d3d13bd9dd5  vmovaps [rsp+0xD0], xmm14
00007d3d13bd9dde  vmovaps [rsp+0xE0], xmm15
00007d3d13bd9de7  sub rsp, 0x30
00007d3d13bd9deb  movaps [rsp], xmm10
00007d3d13bd9df0  movaps [rsp+0x10], xmm12
00007d3d13bd9df6  movaps [rsp+0x20], xmm11
00007d3d13bd9dfc  lea rdi, [rsp]
00007d3d13bd9e00  mov esi, 0x00
00007d3d13bd9e05  mov rax, 0x5741DAFC8530
00007d3d13bd9e0f  call rax
00007d3d13bd9e11  movaps xmm10, [rsp]
00007d3d13bd9e16  add rsp, 0x30
00007d3d13bd9e1a  vmovaps xmm0, [rsp]
00007d3d13bd9e1f  vmovaps xmm1, [rsp+0x10]
00007d3d13bd9e25  vmovaps xmm2, [rsp+0x20]
00007d3d13bd9e2b  vmovaps xmm3, [rsp+0x30]
00007d3d13bd9e31  vmovaps xmm4, [rsp+0x40]
00007d3d13bd9e37  vmovaps xmm5, [rsp+0x50]
00007d3d13bd9e3d  vmovaps xmm6, [rsp+0x60]
00007d3d13bd9e43  vmovaps xmm7, [rsp+0x70]
00007d3d13bd9e49  vmovaps xmm8, [rsp+0x80]
00007d3d13bd9e52  vmovaps xmm9, [rsp+0x90]
00007d3d13bd9e5b  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd9e64  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd9e6d  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd9e76  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd9e7f  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd9e88  add rsp, 0xF0
00007d3d13bd9e8f  pop r11
00007d3d13bd9e91  pop r10
00007d3d13bd9e93  pop r9
00007d3d13bd9e95  pop r8
00007d3d13bd9e97  pop rsi
00007d3d13bd9e98  pop rdi
00007d3d13bd9e99  pop rdx
00007d3d13bd9e9a  pop rcx
00007d3d13bd9e9b  pop rax
00007d3d13bd9e9c  add rsp, 0x08
00007d3d13bd9ea0  jmp 0x00007D3D13BD8BE6
00007d3d13bd9ea5  sub rsp, 0x08
00007d3d13bd9ea9  push rax
00007d3d13bd9eaa  push rcx
00007d3d13bd9eab  push rdx
00007d3d13bd9eac  push rdi
00007d3d13bd9ead  push rsi
00007d3d13bd9eae  push r8
00007d3d13bd9eb0  push r9
00007d3d13bd9eb2  push r10
00007d3d13bd9eb4  push r11
00007d3d13bd9eb6  sub rsp, 0xF0
00007d3d13bd9ebd  vmovaps [rsp], xmm0
00007d3d13bd9ec2  vmovaps [rsp+0x10], xmm1
00007d3d13bd9ec8  vmovaps [rsp+0x20], xmm2
00007d3d13bd9ece  vmovaps [rsp+0x30], xmm3
00007d3d13bd9ed4  vmovaps [rsp+0x40], xmm4
00007d3d13bd9eda  vmovaps [rsp+0x50], xmm5
00007d3d13bd9ee0  vmovaps [rsp+0x60], xmm7
00007d3d13bd9ee6  vmovaps [rsp+0x70], xmm8
00007d3d13bd9eec  vmovaps [rsp+0x80], xmm9
00007d3d13bd9ef5  vmovaps [rsp+0x90], xmm10
00007d3d13bd9efe  vmovaps [rsp+0xA0], xmm11
00007d3d13bd9f07  vmovaps [rsp+0xB0], xmm12
00007d3d13bd9f10  vmovaps [rsp+0xC0], xmm13
00007d3d13bd9f19  vmovaps [rsp+0xD0], xmm14
00007d3d13bd9f22  vmovaps [rsp+0xE0], xmm15
00007d3d13bd9f2b  sub rsp, 0x30
00007d3d13bd9f2f  movaps [rsp], xmm6
00007d3d13bd9f33  movaps [rsp+0x10], xmm12
00007d3d13bd9f39  movaps [rsp+0x20], xmm11
00007d3d13bd9f3f  lea rdi, [rsp]
00007d3d13bd9f43  mov esi, 0x00
00007d3d13bd9f48  mov rax, 0x5741DAFC8530
00007d3d13bd9f52  call rax
00007d3d13bd9f54  movaps xmm6, [rsp]
00007d3d13bd9f58  add rsp, 0x30
00007d3d13bd9f5c  vmovaps xmm0, [rsp]
00007d3d13bd9f61  vmovaps xmm1, [rsp+0x10]
00007d3d13bd9f67  vmovaps xmm2, [rsp+0x20]
00007d3d13bd9f6d  vmovaps xmm3, [rsp+0x30]
00007d3d13bd9f73  vmovaps xmm4, [rsp+0x40]
00007d3d13bd9f79  vmovaps xmm5, [rsp+0x50]
00007d3d13bd9f7f  vmovaps xmm7, [rsp+0x60]
00007d3d13bd9f85  vmovaps xmm8, [rsp+0x70]
00007d3d13bd9f8b  vmovaps xmm9, [rsp+0x80]
00007d3d13bd9f94  vmovaps xmm10, [rsp+0x90]
00007d3d13bd9f9d  vmovaps xmm11, [rsp+0xA0]
00007d3d13bd9fa6  vmovaps xmm12, [rsp+0xB0]
00007d3d13bd9faf  vmovaps xmm13, [rsp+0xC0]
00007d3d13bd9fb8  vmovaps xmm14, [rsp+0xD0]
00007d3d13bd9fc1  vmovaps xmm15, [rsp+0xE0]
00007d3d13bd9fca  add rsp, 0xF0
00007d3d13bd9fd1  pop r11
00007d3d13bd9fd3  pop r10
00007d3d13bd9fd5  pop r9
00007d3d13bd9fd7  pop r8
00007d3d13bd9fd9  pop rsi
00007d3d13bd9fda  pop rdi
00007d3d13bd9fdb  pop rdx
00007d3d13bd9fdc  pop rcx
00007d3d13bd9fdd  pop rax
00007d3d13bd9fde  add rsp, 0x08
00007d3d13bd9fe2  jmp 0x00007D3D13BD8C07
00007d3d13bd9fe7  sub rsp, 0x08
00007d3d13bd9feb  push rax
00007d3d13bd9fec  push rcx
00007d3d13bd9fed  push rdx
00007d3d13bd9fee  push rdi
00007d3d13bd9fef  push rsi
00007d3d13bd9ff0  push r8
00007d3d13bd9ff2  push r9
00007d3d13bd9ff4  push r10
00007d3d13bd9ff6  push r11
00007d3d13bd9ff8  sub rsp, 0xF0
00007d3d13bd9fff  vmovaps [rsp], xmm0
00007d3d13bda004  vmovaps [rsp+0x10], xmm1
00007d3d13bda00a  vmovaps [rsp+0x20], xmm2
00007d3d13bda010  vmovaps [rsp+0x30], xmm4
00007d3d13bda016  vmovaps [rsp+0x40], xmm5
00007d3d13bda01c  vmovaps [rsp+0x50], xmm6
00007d3d13bda022  vmovaps [rsp+0x60], xmm7
00007d3d13bda028  vmovaps [rsp+0x70], xmm8
00007d3d13bda02e  vmovaps [rsp+0x80], xmm9
00007d3d13bda037  vmovaps [rsp+0x90], xmm10
00007d3d13bda040  vmovaps [rsp+0xA0], xmm11
00007d3d13bda049  vmovaps [rsp+0xB0], xmm12
00007d3d13bda052  vmovaps [rsp+0xC0], xmm13
00007d3d13bda05b  vmovaps [rsp+0xD0], xmm14
00007d3d13bda064  vmovaps [rsp+0xE0], xmm15
00007d3d13bda06d  sub rsp, 0x30
00007d3d13bda071  movaps [rsp], xmm3
00007d3d13bda075  movaps [rsp+0x10], xmm5
00007d3d13bda07a  movaps [rsp+0x20], xmm4
00007d3d13bda07f  lea rdi, [rsp]
00007d3d13bda083  mov esi, 0x00
00007d3d13bda088  mov rax, 0x5741DAFC8530
00007d3d13bda092  call rax
00007d3d13bda094  movaps xmm3, [rsp]
00007d3d13bda098  add rsp, 0x30
00007d3d13bda09c  vmovaps xmm0, [rsp]
00007d3d13bda0a1  vmovaps xmm1, [rsp+0x10]
00007d3d13bda0a7  vmovaps xmm2, [rsp+0x20]
00007d3d13bda0ad  vmovaps xmm4, [rsp+0x30]
00007d3d13bda0b3  vmovaps xmm5, [rsp+0x40]
00007d3d13bda0b9  vmovaps xmm6, [rsp+0x50]
00007d3d13bda0bf  vmovaps xmm7, [rsp+0x60]
00007d3d13bda0c5  vmovaps xmm8, [rsp+0x70]
00007d3d13bda0cb  vmovaps xmm9, [rsp+0x80]
00007d3d13bda0d4  vmovaps xmm10, [rsp+0x90]
00007d3d13bda0dd  vmovaps xmm11, [rsp+0xA0]
00007d3d13bda0e6  vmovaps xmm12, [rsp+0xB0]
00007d3d13bda0ef  vmovaps xmm13, [rsp+0xC0]
00007d3d13bda0f8  vmovaps xmm14, [rsp+0xD0]
00007d3d13bda101  vmovaps xmm15, [rsp+0xE0]
00007d3d13bda10a  add rsp, 0xF0
00007d3d13bda111  pop r11
00007d3d13bda113  pop r10
00007d3d13bda115  pop r9
00007d3d13bda117  pop r8
00007d3d13bda119  pop rsi
00007d3d13bda11a  pop rdi
00007d3d13bda11b  pop rdx
00007d3d13bda11c  pop rcx
00007d3d13bda11d  pop rax
00007d3d13bda11e  add rsp, 0x08
00007d3d13bda122  jmp 0x00007D3D13BD8C68
00007d3d13bda127  sub rsp, 0x08
00007d3d13bda12b  push rax
00007d3d13bda12c  push rcx
00007d3d13bda12d  push rdx
00007d3d13bda12e  push rdi
00007d3d13bda12f  push rsi
00007d3d13bda130  push r8
00007d3d13bda132  push r9
00007d3d13bda134  push r10
00007d3d13bda136  push r11
00007d3d13bda138  sub rsp, 0xF0
00007d3d13bda13f  vmovaps [rsp], xmm0
00007d3d13bda144  vmovaps [rsp+0x10], xmm1
00007d3d13bda14a  vmovaps [rsp+0x20], xmm2
00007d3d13bda150  vmovaps [rsp+0x30], xmm3
00007d3d13bda156  vmovaps [rsp+0x40], xmm4
00007d3d13bda15c  vmovaps [rsp+0x50], xmm6
00007d3d13bda162  vmovaps [rsp+0x60], xmm7
00007d3d13bda168  vmovaps [rsp+0x70], xmm8
00007d3d13bda16e  vmovaps [rsp+0x80], xmm9
00007d3d13bda177  vmovaps [rsp+0x90], xmm10
00007d3d13bda180  vmovaps [rsp+0xA0], xmm11
00007d3d13bda189  vmovaps [rsp+0xB0], xmm12
00007d3d13bda192  vmovaps [rsp+0xC0], xmm13
00007d3d13bda19b  vmovaps [rsp+0xD0], xmm14
00007d3d13bda1a4  vmovaps [rsp+0xE0], xmm15
00007d3d13bda1ad  sub rsp, 0x30
00007d3d13bda1b1  movaps [rsp], xmm5
00007d3d13bda1b5  movaps [rsp+0x10], xmm8
00007d3d13bda1bb  movaps [rsp+0x20], xmm15
00007d3d13bda1c1  lea rdi, [rsp]
00007d3d13bda1c5  mov esi, 0x00
00007d3d13bda1ca  mov rax, 0x5741DAFC8530
00007d3d13bda1d4  call rax
00007d3d13bda1d6  movaps xmm5, [rsp]
00007d3d13bda1da  add rsp, 0x30
00007d3d13bda1de  vmovaps xmm0, [rsp]
00007d3d13bda1e3  vmovaps xmm1, [rsp+0x10]
00007d3d13bda1e9  vmovaps xmm2, [rsp+0x20]
00007d3d13bda1ef  vmovaps xmm3, [rsp+0x30]
00007d3d13bda1f5  vmovaps xmm4, [rsp+0x40]
00007d3d13bda1fb  vmovaps xmm6, [rsp+0x50]
00007d3d13bda201  vmovaps xmm7, [rsp+0x60]
00007d3d13bda207  vmovaps xmm8, [rsp+0x70]
00007d3d13bda20d  vmovaps xmm9, [rsp+0x80]
00007d3d13bda216  vmovaps xmm10, [rsp+0x90]
00007d3d13bda21f  vmovaps xmm11, [rsp+0xA0]
00007d3d13bda228  vmovaps xmm12, [rsp+0xB0]
00007d3d13bda231  vmovaps xmm13, [rsp+0xC0]
00007d3d13bda23a  vmovaps xmm14, [rsp+0xD0]
00007d3d13bda243  vmovaps xmm15, [rsp+0xE0]
00007d3d13bda24c  add rsp, 0xF0
00007d3d13bda253  pop r11
00007d3d13bda255  pop r10
00007d3d13bda257  pop r9
00007d3d13bda259  pop r8
00007d3d13bda25b  pop rsi
00007d3d13bda25c  pop rdi
00007d3d13bda25d  pop rdx
00007d3d13bda25e  pop rcx
00007d3d13bda25f  pop rax
00007d3d13bda260  add rsp, 0x08
00007d3d13bda264  jmp 0x00007D3D13BD8CA0
00007d3d13bda269  sub rsp, 0x08
00007d3d13bda26d  push rax
00007d3d13bda26e  push rcx
00007d3d13bda26f  push rdx
00007d3d13bda270  push rdi
00007d3d13bda271  push rsi
00007d3d13bda272  push r8
00007d3d13bda274  push r9
00007d3d13bda276  push r10
00007d3d13bda278  push r11
00007d3d13bda27a  sub rsp, 0xF0
00007d3d13bda281  vmovaps [rsp], xmm0
00007d3d13bda286  vmovaps [rsp+0x10], xmm1
00007d3d13bda28c  vmovaps [rsp+0x20], xmm2
00007d3d13bda292  vmovaps [rsp+0x30], xmm3
00007d3d13bda298  vmovaps [rsp+0x40], xmm5
00007d3d13bda29e  vmovaps [rsp+0x50], xmm6
00007d3d13bda2a4  vmovaps [rsp+0x60], xmm7
00007d3d13bda2aa  vmovaps [rsp+0x70], xmm8
00007d3d13bda2b0  vmovaps [rsp+0x80], xmm9
00007d3d13bda2b9  vmovaps [rsp+0x90], xmm10
00007d3d13bda2c2  vmovaps [rsp+0xA0], xmm11
00007d3d13bda2cb  vmovaps [rsp+0xB0], xmm12
00007d3d13bda2d4  vmovaps [rsp+0xC0], xmm13
00007d3d13bda2dd  vmovaps [rsp+0xD0], xmm14
00007d3d13bda2e6  vmovaps [rsp+0xE0], xmm15
00007d3d13bda2ef  sub rsp, 0x30
00007d3d13bda2f3  movaps [rsp], xmm4
00007d3d13bda2f7  movaps [rsp+0x10], xmm9
00007d3d13bda2fd  movaps [rsp+0x20], xmm8
00007d3d13bda303  lea rdi, [rsp]
00007d3d13bda307  mov esi, 0x00
00007d3d13bda30c  mov rax, 0x5741DAFC8530
00007d3d13bda316  call rax
00007d3d13bda318  movaps xmm4, [rsp]
00007d3d13bda31c  add rsp, 0x30
00007d3d13bda320  vmovaps xmm0, [rsp]
00007d3d13bda325  vmovaps xmm1, [rsp+0x10]
00007d3d13bda32b  vmovaps xmm2, [rsp+0x20]
00007d3d13bda331  vmovaps xmm3, [rsp+0x30]
00007d3d13bda337  vmovaps xmm5, [rsp+0x40]
00007d3d13bda33d  vmovaps xmm6, [rsp+0x50]
00007d3d13bda343  vmovaps xmm7, [rsp+0x60]
00007d3d13bda349  vmovaps xmm8, [rsp+0x70]
00007d3d13bda34f  vmovaps xmm9, [rsp+0x80]
00007d3d13bda358  vmovaps xmm10, [rsp+0x90]
00007d3d13bda361  vmovaps xmm11, [rsp+0xA0]
00007d3d13bda36a  vmovaps xmm12, [rsp+0xB0]
00007d3d13bda373  vmovaps xmm13, [rsp+0xC0]
00007d3d13bda37c  vmovaps xmm14, [rsp+0xD0]
00007d3d13bda385  vmovaps xmm15, [rsp+0xE0]
00007d3d13bda38e  add rsp, 0xF0
00007d3d13bda395  pop r11
00007d3d13bda397  pop r10
00007d3d13bda399  pop r9
00007d3d13bda39b  pop r8
00007d3d13bda39d  pop rsi
00007d3d13bda39e  pop rdi
00007d3d13bda39f  pop rdx
00007d3d13bda3a0  pop rcx
00007d3d13bda3a1  pop rax
00007d3d13bda3a2  add rsp, 0x08
00007d3d13bda3a6  jmp 0x00007D3D13BD8CC1
00007d3d13bda3ab  sub rsp, 0x08
00007d3d13bda3af  push rax
00007d3d13bda3b0  push rcx
00007d3d13bda3b1  push rdx
00007d3d13bda3b2  push rdi
00007d3d13bda3b3  push rsi
00007d3d13bda3b4  push r8
00007d3d13bda3b6  push r9
00007d3d13bda3b8  push r10
00007d3d13bda3ba  push r11
00007d3d13bda3bc  sub rsp, 0xF0
00007d3d13bda3c3  vmovaps [rsp], xmm0
00007d3d13bda3c8  vmovaps [rsp+0x10], xmm1
00007d3d13bda3ce  vmovaps [rsp+0x20], xmm2
00007d3d13bda3d4  vmovaps [rsp+0x30], xmm3
00007d3d13bda3da  vmovaps [rsp+0x40], xmm4
00007d3d13bda3e0  vmovaps [rsp+0x50], xmm5
00007d3d13bda3e6  vmovaps [rsp+0x60], xmm6
00007d3d13bda3ec  vmovaps [rsp+0x70], xmm7
00007d3d13bda3f2  vmovaps [rsp+0x80], xmm8
00007d3d13bda3fb  vmovaps [rsp+0x90], xmm10
00007d3d13bda404  vmovaps [rsp+0xA0], xmm11
00007d3d13bda40d  vmovaps [rsp+0xB0], xmm12
00007d3d13bda416  vmovaps [rsp+0xC0], xmm13
00007d3d13bda41f  vmovaps [rsp+0xD0], xmm14
00007d3d13bda428  vmovaps [rsp+0xE0], xmm15
00007d3d13bda431  sub rsp, 0x30
00007d3d13bda435  movaps [rsp], xmm9
00007d3d13bda43a  movaps [rsp+0x10], xmm10
00007d3d13bda440  movaps [rsp+0x20], xmm8
00007d3d13bda446  lea rdi, [rsp]
00007d3d13bda44a  mov esi, 0x00
00007d3d13bda44f  mov rax, 0x5741DAFC8530
00007d3d13bda459  call rax
00007d3d13bda45b  movaps xmm9, [rsp]
00007d3d13bda460  add rsp, 0x30
00007d3d13bda464  vmovaps xmm0, [rsp]
00007d3d13bda469  vmovaps xmm1, [rsp+0x10]
00007d3d13bda46f  vmovaps xmm2, [rsp+0x20]
00007d3d13bda475  vmovaps xmm3, [rsp+0x30]
00007d3d13bda47b  vmovaps xmm4, [rsp+0x40]
00007d3d13bda481  vmovaps xmm5, [rsp+0x50]
00007d3d13bda487  vmovaps xmm6, [rsp+0x60]
00007d3d13bda48d  vmovaps xmm7, [rsp+0x70]
00007d3d13bda493  vmovaps xmm8, [rsp+0x80]
00007d3d13bda49c  vmovaps xmm10, [rsp+0x90]
00007d3d13bda4a5  vmovaps xmm11, [rsp+0xA0]
00007d3d13bda4ae  vmovaps xmm12, [rsp+0xB0]
00007d3d13bda4b7  vmovaps xmm13, [rsp+0xC0]
00007d3d13bda4c0  vmovaps xmm14, [rsp+0xD0]
00007d3d13bda4c9  vmovaps xmm15, [rsp+0xE0]
00007d3d13bda4d2  add rsp, 0xF0
00007d3d13bda4d9  pop r11
00007d3d13bda4db  pop r10
00007d3d13bda4dd  pop r9
00007d3d13bda4df  pop r8
00007d3d13bda4e1  pop rsi
00007d3d13bda4e2  pop rdi
00007d3d13bda4e3  pop rdx
00007d3d13bda4e4  pop rcx
00007d3d13bda4e5  pop rax
00007d3d13bda4e6  add rsp, 0x08
00007d3d13bda4ea  jmp 0x00007D3D13BD8CDB
00007d3d13bda4ef  call 0x00007D3D13AD64F0
00007d3d13bda4f4  jmp 0x00007D3D13BD8DF5
00007d3d13bda4f9  call 0x00007D3D13AD64F0
00007d3d13bda4fe  jmp 0x00007D3D13BD8E0B
00007d3d13bda503  sub rsp, 0x08
00007d3d13bda507  push rax
00007d3d13bda508  push rcx
00007d3d13bda509  push rdx
00007d3d13bda50a  push rdi
00007d3d13bda50b  push rsi
00007d3d13bda50c  push r8
00007d3d13bda50e  push r9
00007d3d13bda510  push r10
00007d3d13bda512  push r11
00007d3d13bda514  sub rsp, 0xF0
00007d3d13bda51b  vmovaps [rsp], xmm0
00007d3d13bda520  vmovaps [rsp+0x10], xmm2
00007d3d13bda526  vmovaps [rsp+0x20], xmm3
00007d3d13bda52c  vmovaps [rsp+0x30], xmm4
00007d3d13bda532  vmovaps [rsp+0x40], xmm5
00007d3d13bda538  vmovaps [rsp+0x50], xmm6
00007d3d13bda53e  vmovaps [rsp+0x60], xmm7
00007d3d13bda544  vmovaps [rsp+0x70], xmm8
00007d3d13bda54a  vmovaps [rsp+0x80], xmm9
00007d3d13bda553  vmovaps [rsp+0x90], xmm10
00007d3d13bda55c  vmovaps [rsp+0xA0], xmm11
00007d3d13bda565  vmovaps [rsp+0xB0], xmm12
00007d3d13bda56e  vmovaps [rsp+0xC0], xmm13
00007d3d13bda577  vmovaps [rsp+0xD0], xmm14
00007d3d13bda580  vmovaps [rsp+0xE0], xmm15
00007d3d13bda589  sub rsp, 0x30
00007d3d13bda58d  movaps [rsp], xmm1
00007d3d13bda591  movaps [rsp+0x10], xmm6
00007d3d13bda596  movaps [rsp+0x20], xmm15
00007d3d13bda59c  lea rdi, [rsp]
00007d3d13bda5a0  mov esi, 0x00
00007d3d13bda5a5  mov rax, 0x5741DAFC8530
00007d3d13bda5af  call rax
00007d3d13bda5b1  movaps xmm1, [rsp]
00007d3d13bda5b5  add rsp, 0x30
00007d3d13bda5b9  vmovaps xmm0, [rsp]
00007d3d13bda5be  vmovaps xmm2, [rsp+0x10]
00007d3d13bda5c4  vmovaps xmm3, [rsp+0x20]
00007d3d13bda5ca  vmovaps xmm4, [rsp+0x30]
00007d3d13bda5d0  vmovaps xmm5, [rsp+0x40]
00007d3d13bda5d6  vmovaps xmm6, [rsp+0x50]
00007d3d13bda5dc  vmovaps xmm7, [rsp+0x60]
00007d3d13bda5e2  vmovaps xmm8, [rsp+0x70]
00007d3d13bda5e8  vmovaps xmm9, [rsp+0x80]
00007d3d13bda5f1  vmovaps xmm10, [rsp+0x90]
00007d3d13bda5fa  vmovaps xmm11, [rsp+0xA0]
00007d3d13bda603  vmovaps xmm12, [rsp+0xB0]
00007d3d13bda60c  vmovaps xmm13, [rsp+0xC0]
00007d3d13bda615  vmovaps xmm14, [rsp+0xD0]
00007d3d13bda61e  vmovaps xmm15, [rsp+0xE0]
00007d3d13bda627  add rsp, 0xF0
00007d3d13bda62e  pop r11
00007d3d13bda630  pop r10
00007d3d13bda632  pop r9
00007d3d13bda634  pop r8
00007d3d13bda636  pop rsi
00007d3d13bda637  pop rdi
00007d3d13bda638  pop rdx
00007d3d13bda639  pop rcx
00007d3d13bda63a  pop rax
00007d3d13bda63b  add rsp, 0x08
00007d3d13bda63f  jmp 0x00007D3D13BD8E48
00007d3d13bda644  call 0x00007D3D13AE5820
00007d3d13bda649  jmp 0x00007D3D13BD8E55
00007d3d13bda64e  sub rsp, 0x08
00007d3d13bda652  push rax
00007d3d13bda653  push rcx
00007d3d13bda654  push rdx
00007d3d13bda655  push rdi
00007d3d13bda656  push rsi
00007d3d13bda657  push r8
00007d3d13bda659  push r9
00007d3d13bda65b  push r10
00007d3d13bda65d  push r11
00007d3d13bda65f  sub rsp, 0xF0
00007d3d13bda666  vmovaps [rsp], xmm0
00007d3d13bda66b  vmovaps [rsp+0x10], xmm1
00007d3d13bda671  vmovaps [rsp+0x20], xmm2
00007d3d13bda677  vmovaps [rsp+0x30], xmm3
00007d3d13bda67d  vmovaps [rsp+0x40], xmm4
00007d3d13bda683  vmovaps [rsp+0x50], xmm5
00007d3d13bda689  vmovaps [rsp+0x60], xmm6
00007d3d13bda68f  vmovaps [rsp+0x70], xmm7
00007d3d13bda695  vmovaps [rsp+0x80], xmm8
00007d3d13bda69e  vmovaps [rsp+0x90], xmm9
00007d3d13bda6a7  vmovaps [rsp+0xA0], xmm10
00007d3d13bda6b0  vmovaps [rsp+0xB0], xmm11
00007d3d13bda6b9  vmovaps [rsp+0xC0], xmm12
00007d3d13bda6c2  vmovaps [rsp+0xD0], xmm13
00007d3d13bda6cb  vmovaps [rsp+0xE0], xmm15
00007d3d13bda6d4  sub rsp, 0x30
00007d3d13bda6d8  movaps [rsp], xmm14
00007d3d13bda6dd  movaps [rsp+0x10], xmm4
00007d3d13bda6e2  movaps [rsp+0x20], xmm3
00007d3d13bda6e7  lea rdi, [rsp]
00007d3d13bda6eb  mov esi, 0x00
00007d3d13bda6f0  mov rax, 0x5741DAFC8530
00007d3d13bda6fa  call rax
00007d3d13bda6fc  movaps xmm14, [rsp]
00007d3d13bda701  add rsp, 0x30
00007d3d13bda705  vmovaps xmm0, [rsp]
00007d3d13bda70a  vmovaps xmm1, [rsp+0x10]
00007d3d13bda710  vmovaps xmm2, [rsp+0x20]
00007d3d13bda716  vmovaps xmm3, [rsp+0x30]
00007d3d13bda71c  vmovaps xmm4, [rsp+0x40]
00007d3d13bda722  vmovaps xmm5, [rsp+0x50]
00007d3d13bda728  vmovaps xmm6, [rsp+0x60]
00007d3d13bda72e  vmovaps xmm7, [rsp+0x70]
00007d3d13bda734  vmovaps xmm8, [rsp+0x80]
00007d3d13bda73d  vmovaps xmm9, [rsp+0x90]
00007d3d13bda746  vmovaps xmm10, [rsp+0xA0]
00007d3d13bda74f  vmovaps xmm11, [rsp+0xB0]
00007d3d13bda758  vmovaps xmm12, [rsp+0xC0]
00007d3d13bda761  vmovaps xmm13, [rsp+0xD0]
00007d3d13bda76a  vmovaps xmm15, [rsp+0xE0]
00007d3d13bda773  add rsp, 0xF0
00007d3d13bda77a  pop r11
00007d3d13bda77c  pop r10
00007d3d13bda77e  pop r9
00007d3d13bda780  pop r8
00007d3d13bda782  pop rsi
00007d3d13bda783  pop rdi
00007d3d13bda784  pop rdx
00007d3d13bda785  pop rcx
00007d3d13bda786  pop rax
00007d3d13bda787  add rsp, 0x08
00007d3d13bda78b  jmp 0x00007D3D13BD8E6F
00007d3d13bda790  sub rsp, 0x08
00007d3d13bda794  push rax
00007d3d13bda795  push rcx
00007d3d13bda796  push rdx
00007d3d13bda797  push rdi
00007d3d13bda798  push rsi
00007d3d13bda799  push r8
00007d3d13bda79b  push r9
00007d3d13bda79d  push r10
00007d3d13bda79f  push r11
00007d3d13bda7a1  sub rsp, 0xF0
00007d3d13bda7a8  vmovaps [rsp], xmm0
00007d3d13bda7ad  vmovaps [rsp+0x10], xmm1
00007d3d13bda7b3  vmovaps [rsp+0x20], xmm2
00007d3d13bda7b9  vmovaps [rsp+0x30], xmm3
00007d3d13bda7bf  vmovaps [rsp+0x40], xmm4
00007d3d13bda7c5  vmovaps [rsp+0x50], xmm5
00007d3d13bda7cb  vmovaps [rsp+0x60], xmm7
00007d3d13bda7d1  vmovaps [rsp+0x70], xmm8
00007d3d13bda7d7  vmovaps [rsp+0x80], xmm9
00007d3d13bda7e0  vmovaps [rsp+0x90], xmm10
00007d3d13bda7e9  vmovaps [rsp+0xA0], xmm11
00007d3d13bda7f2  vmovaps [rsp+0xB0], xmm12
00007d3d13bda7fb  vmovaps [rsp+0xC0], xmm13
00007d3d13bda804  vmovaps [rsp+0xD0], xmm14
00007d3d13bda80d  vmovaps [rsp+0xE0], xmm15
00007d3d13bda816  sub rsp, 0x30
00007d3d13bda81a  movaps [rsp], xmm6
00007d3d13bda81e  movaps [rsp+0x10], xmm9
00007d3d13bda824  movaps [rsp+0x20], xmm7
00007d3d13bda829  lea rdi, [rsp]
00007d3d13bda82d  mov esi, 0x00
00007d3d13bda832  mov rax, 0x5741DAFC8530
00007d3d13bda83c  call rax
00007d3d13bda83e  movaps xmm6, [rsp]
00007d3d13bda842  add rsp, 0x30
00007d3d13bda846  vmovaps xmm0, [rsp]
00007d3d13bda84b  vmovaps xmm1, [rsp+0x10]
00007d3d13bda851  vmovaps xmm2, [rsp+0x20]
00007d3d13bda857  vmovaps xmm3, [rsp+0x30]
00007d3d13bda85d  vmovaps xmm4, [rsp+0x40]
00007d3d13bda863  vmovaps xmm5, [rsp+0x50]
00007d3d13bda869  vmovaps xmm7, [rsp+0x60]
00007d3d13bda86f  vmovaps xmm8, [rsp+0x70]
00007d3d13bda875  vmovaps xmm9, [rsp+0x80]
00007d3d13bda87e  vmovaps xmm10, [rsp+0x90]
00007d3d13bda887  vmovaps xmm11, [rsp+0xA0]
00007d3d13bda890  vmovaps xmm12, [rsp+0xB0]
00007d3d13bda899  vmovaps xmm13, [rsp+0xC0]
00007d3d13bda8a2  vmovaps xmm14, [rsp+0xD0]
00007d3d13bda8ab  vmovaps xmm15, [rsp+0xE0]
00007d3d13bda8b4  add rsp, 0xF0
00007d3d13bda8bb  pop r11
00007d3d13bda8bd  pop r10
00007d3d13bda8bf  pop r9
00007d3d13bda8c1  pop r8
00007d3d13bda8c3  pop rsi
00007d3d13bda8c4  pop rdi
00007d3d13bda8c5  pop rdx
00007d3d13bda8c6  pop rcx
00007d3d13bda8c7  pop rax
00007d3d13bda8c8  add rsp, 0x08
00007d3d13bda8cc  jmp 0x00007D3D13BD8E87
00007d3d13bda8d1  sub rsp, 0x08
00007d3d13bda8d5  push rax
00007d3d13bda8d6  push rcx
00007d3d13bda8d7  push rdx
00007d3d13bda8d8  push rdi
00007d3d13bda8d9  push rsi
00007d3d13bda8da  push r8
00007d3d13bda8dc  push r9
00007d3d13bda8de  push r10
00007d3d13bda8e0  push r11
00007d3d13bda8e2  sub rsp, 0xF0
00007d3d13bda8e9  vmovaps [rsp], xmm0
00007d3d13bda8ee  vmovaps [rsp+0x10], xmm1
00007d3d13bda8f4  vmovaps [rsp+0x20], xmm2
00007d3d13bda8fa  vmovaps [rsp+0x30], xmm3
00007d3d13bda900  vmovaps [rsp+0x40], xmm4
00007d3d13bda906  vmovaps [rsp+0x50], xmm5
00007d3d13bda90c  vmovaps [rsp+0x60], xmm6
00007d3d13bda912  vmovaps [rsp+0x70], xmm8
00007d3d13bda918  vmovaps [rsp+0x80], xmm9
00007d3d13bda921  vmovaps [rsp+0x90], xmm10
00007d3d13bda92a  vmovaps [rsp+0xA0], xmm11
00007d3d13bda933  vmovaps [rsp+0xB0], xmm12
00007d3d13bda93c  vmovaps [rsp+0xC0], xmm13
00007d3d13bda945  vmovaps [rsp+0xD0], xmm14
00007d3d13bda94e  vmovaps [rsp+0xE0], xmm15
00007d3d13bda957  sub rsp, 0x30
00007d3d13bda95b  movaps [rsp], xmm7
00007d3d13bda95f  movaps [rsp+0x10], xmm4
00007d3d13bda964  movaps [rsp+0x20], xmm9
00007d3d13bda96a  lea rdi, [rsp]
00007d3d13bda96e  mov esi, 0x00
00007d3d13bda973  mov rax, 0x5741DAFC8530
00007d3d13bda97d  call rax
00007d3d13bda97f  movaps xmm7, [rsp]
00007d3d13bda983  add rsp, 0x30
00007d3d13bda987  vmovaps xmm0, [rsp]
00007d3d13bda98c  vmovaps xmm1, [rsp+0x10]
00007d3d13bda992  vmovaps xmm2, [rsp+0x20]
00007d3d13bda998  vmovaps xmm3, [rsp+0x30]
00007d3d13bda99e  vmovaps xmm4, [rsp+0x40]
00007d3d13bda9a4  vmovaps xmm5, [rsp+0x50]
00007d3d13bda9aa  vmovaps xmm6, [rsp+0x60]
00007d3d13bda9b0  vmovaps xmm8, [rsp+0x70]
00007d3d13bda9b6  vmovaps xmm9, [rsp+0x80]
00007d3d13bda9bf  vmovaps xmm10, [rsp+0x90]
00007d3d13bda9c8  vmovaps xmm11, [rsp+0xA0]
00007d3d13bda9d1  vmovaps xmm12, [rsp+0xB0]
00007d3d13bda9da  vmovaps xmm13, [rsp+0xC0]
00007d3d13bda9e3  vmovaps xmm14, [rsp+0xD0]
00007d3d13bda9ec  vmovaps xmm15, [rsp+0xE0]
00007d3d13bda9f5  add rsp, 0xF0
00007d3d13bda9fc  pop r11
00007d3d13bda9fe  pop r10
00007d3d13bdaa00  pop r9
00007d3d13bdaa02  pop r8
00007d3d13bdaa04  pop rsi
00007d3d13bdaa05  pop rdi
00007d3d13bdaa06  pop rdx
00007d3d13bdaa07  pop rcx
00007d3d13bdaa08  pop rax
00007d3d13bdaa09  add rsp, 0x08
00007d3d13bdaa0d  jmp 0x00007D3D13BD8EB4
00007d3d13bdaa12  sub rsp, 0x08
00007d3d13bdaa16  push rax
00007d3d13bdaa17  push rcx
00007d3d13bdaa18  push rdx
00007d3d13bdaa19  push rdi
00007d3d13bdaa1a  push rsi
00007d3d13bdaa1b  push r8
00007d3d13bdaa1d  push r9
00007d3d13bdaa1f  push r10
00007d3d13bdaa21  push r11
00007d3d13bdaa23  sub rsp, 0xF0
00007d3d13bdaa2a  vmovaps [rsp], xmm0
00007d3d13bdaa2f  vmovaps [rsp+0x10], xmm1
00007d3d13bdaa35  vmovaps [rsp+0x20], xmm2
00007d3d13bdaa3b  vmovaps [rsp+0x30], xmm3
00007d3d13bdaa41  vmovaps [rsp+0x40], xmm5
00007d3d13bdaa47  vmovaps [rsp+0x50], xmm6
00007d3d13bdaa4d  vmovaps [rsp+0x60], xmm7
00007d3d13bdaa53  vmovaps [rsp+0x70], xmm8
00007d3d13bdaa59  vmovaps [rsp+0x80], xmm9
00007d3d13bdaa62  vmovaps [rsp+0x90], xmm10
00007d3d13bdaa6b  vmovaps [rsp+0xA0], xmm11
00007d3d13bdaa74  vmovaps [rsp+0xB0], xmm12
00007d3d13bdaa7d  vmovaps [rsp+0xC0], xmm13
00007d3d13bdaa86  vmovaps [rsp+0xD0], xmm14
00007d3d13bdaa8f  vmovaps [rsp+0xE0], xmm15
00007d3d13bdaa98  sub rsp, 0x30
00007d3d13bdaa9c  movaps [rsp], xmm4
00007d3d13bdaaa0  movaps [rsp+0x10], xmm15
00007d3d13bdaaa6  movaps [rsp+0x20], xmm9
00007d3d13bdaaac  lea rdi, [rsp]
00007d3d13bdaab0  mov esi, 0x00
00007d3d13bdaab5  mov rax, 0x5741DAFC8530
00007d3d13bdaabf  call rax
00007d3d13bdaac1  movaps xmm4, [rsp]
00007d3d13bdaac5  add rsp, 0x30
00007d3d13bdaac9  vmovaps xmm0, [rsp]
00007d3d13bdaace  vmovaps xmm1, [rsp+0x10]
00007d3d13bdaad4  vmovaps xmm2, [rsp+0x20]
00007d3d13bdaada  vmovaps xmm3, [rsp+0x30]
00007d3d13bdaae0  vmovaps xmm5, [rsp+0x40]
00007d3d13bdaae6  vmovaps xmm6, [rsp+0x50]
00007d3d13bdaaec  vmovaps xmm7, [rsp+0x60]
00007d3d13bdaaf2  vmovaps xmm8, [rsp+0x70]
00007d3d13bdaaf8  vmovaps xmm9, [rsp+0x80]
00007d3d13bdab01  vmovaps xmm10, [rsp+0x90]
00007d3d13bdab0a  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdab13  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdab1c  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdab25  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdab2e  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdab37  add rsp, 0xF0
00007d3d13bdab3e  pop r11
00007d3d13bdab40  pop r10
00007d3d13bdab42  pop r9
00007d3d13bdab44  pop r8
00007d3d13bdab46  pop rsi
00007d3d13bdab47  pop rdi
00007d3d13bdab48  pop rdx
00007d3d13bdab49  pop rcx
00007d3d13bdab4a  pop rax
00007d3d13bdab4b  add rsp, 0x08
00007d3d13bdab4f  jmp 0x00007D3D13BD8ED9
00007d3d13bdab54  call 0x00007D3D13AE5820
00007d3d13bdab59  jmp 0x00007D3D13BD8EE6
00007d3d13bdab5e  sub rsp, 0x08
00007d3d13bdab62  push rax
00007d3d13bdab63  push rcx
00007d3d13bdab64  push rdx
00007d3d13bdab65  push rdi
00007d3d13bdab66  push rsi
00007d3d13bdab67  push r8
00007d3d13bdab69  push r9
00007d3d13bdab6b  push r10
00007d3d13bdab6d  push r11
00007d3d13bdab6f  sub rsp, 0xF0
00007d3d13bdab76  vmovaps [rsp], xmm0
00007d3d13bdab7b  vmovaps [rsp+0x10], xmm1
00007d3d13bdab81  vmovaps [rsp+0x20], xmm2
00007d3d13bdab87  vmovaps [rsp+0x30], xmm4
00007d3d13bdab8d  vmovaps [rsp+0x40], xmm5
00007d3d13bdab93  vmovaps [rsp+0x50], xmm6
00007d3d13bdab99  vmovaps [rsp+0x60], xmm7
00007d3d13bdab9f  vmovaps [rsp+0x70], xmm8
00007d3d13bdaba5  vmovaps [rsp+0x80], xmm9
00007d3d13bdabae  vmovaps [rsp+0x90], xmm10
00007d3d13bdabb7  vmovaps [rsp+0xA0], xmm11
00007d3d13bdabc0  vmovaps [rsp+0xB0], xmm12
00007d3d13bdabc9  vmovaps [rsp+0xC0], xmm13
00007d3d13bdabd2  vmovaps [rsp+0xD0], xmm14
00007d3d13bdabdb  vmovaps [rsp+0xE0], xmm15
00007d3d13bdabe4  sub rsp, 0x30
00007d3d13bdabe8  movaps [rsp], xmm3
00007d3d13bdabec  movaps [rsp+0x10], xmm1
00007d3d13bdabf1  movaps [rsp+0x20], xmm9
00007d3d13bdabf7  lea rdi, [rsp]
00007d3d13bdabfb  mov esi, 0x00
00007d3d13bdac00  mov rax, 0x5741DAFC8530
00007d3d13bdac0a  call rax
00007d3d13bdac0c  movaps xmm3, [rsp]
00007d3d13bdac10  add rsp, 0x30
00007d3d13bdac14  vmovaps xmm0, [rsp]
00007d3d13bdac19  vmovaps xmm1, [rsp+0x10]
00007d3d13bdac1f  vmovaps xmm2, [rsp+0x20]
00007d3d13bdac25  vmovaps xmm4, [rsp+0x30]
00007d3d13bdac2b  vmovaps xmm5, [rsp+0x40]
00007d3d13bdac31  vmovaps xmm6, [rsp+0x50]
00007d3d13bdac37  vmovaps xmm7, [rsp+0x60]
00007d3d13bdac3d  vmovaps xmm8, [rsp+0x70]
00007d3d13bdac43  vmovaps xmm9, [rsp+0x80]
00007d3d13bdac4c  vmovaps xmm10, [rsp+0x90]
00007d3d13bdac55  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdac5e  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdac67  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdac70  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdac79  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdac82  add rsp, 0xF0
00007d3d13bdac89  pop r11
00007d3d13bdac8b  pop r10
00007d3d13bdac8d  pop r9
00007d3d13bdac8f  pop r8
00007d3d13bdac91  pop rsi
00007d3d13bdac92  pop rdi
00007d3d13bdac93  pop rdx
00007d3d13bdac94  pop rcx
00007d3d13bdac95  pop rax
00007d3d13bdac96  add rsp, 0x08
00007d3d13bdac9a  jmp 0x00007D3D13BD8F23
00007d3d13bdac9f  sub rsp, 0x08
00007d3d13bdaca3  push rax
00007d3d13bdaca4  push rcx
00007d3d13bdaca5  push rdx
00007d3d13bdaca6  push rdi
00007d3d13bdaca7  push rsi
00007d3d13bdaca8  push r8
00007d3d13bdacaa  push r9
00007d3d13bdacac  push r10
00007d3d13bdacae  push r11
00007d3d13bdacb0  sub rsp, 0xF0
00007d3d13bdacb7  vmovaps [rsp], xmm0
00007d3d13bdacbc  vmovaps [rsp+0x10], xmm2
00007d3d13bdacc2  vmovaps [rsp+0x20], xmm3
00007d3d13bdacc8  vmovaps [rsp+0x30], xmm4
00007d3d13bdacce  vmovaps [rsp+0x40], xmm5
00007d3d13bdacd4  vmovaps [rsp+0x50], xmm6
00007d3d13bdacda  vmovaps [rsp+0x60], xmm7
00007d3d13bdace0  vmovaps [rsp+0x70], xmm8
00007d3d13bdace6  vmovaps [rsp+0x80], xmm9
00007d3d13bdacef  vmovaps [rsp+0x90], xmm10
00007d3d13bdacf8  vmovaps [rsp+0xA0], xmm11
00007d3d13bdad01  vmovaps [rsp+0xB0], xmm12
00007d3d13bdad0a  vmovaps [rsp+0xC0], xmm13
00007d3d13bdad13  vmovaps [rsp+0xD0], xmm14
00007d3d13bdad1c  vmovaps [rsp+0xE0], xmm15
00007d3d13bdad25  sub rsp, 0x30
00007d3d13bdad29  movaps [rsp], xmm1
00007d3d13bdad2d  movaps [rsp+0x10], xmm15
00007d3d13bdad33  movaps [rsp+0x20], xmm9
00007d3d13bdad39  lea rdi, [rsp]
00007d3d13bdad3d  mov esi, 0x00
00007d3d13bdad42  mov rax, 0x5741DAFC8530
00007d3d13bdad4c  call rax
00007d3d13bdad4e  movaps xmm1, [rsp]
00007d3d13bdad52  add rsp, 0x30
00007d3d13bdad56  vmovaps xmm0, [rsp]
00007d3d13bdad5b  vmovaps xmm2, [rsp+0x10]
00007d3d13bdad61  vmovaps xmm3, [rsp+0x20]
00007d3d13bdad67  vmovaps xmm4, [rsp+0x30]
00007d3d13bdad6d  vmovaps xmm5, [rsp+0x40]
00007d3d13bdad73  vmovaps xmm6, [rsp+0x50]
00007d3d13bdad79  vmovaps xmm7, [rsp+0x60]
00007d3d13bdad7f  vmovaps xmm8, [rsp+0x70]
00007d3d13bdad85  vmovaps xmm9, [rsp+0x80]
00007d3d13bdad8e  vmovaps xmm10, [rsp+0x90]
00007d3d13bdad97  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdada0  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdada9  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdadb2  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdadbb  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdadc4  add rsp, 0xF0
00007d3d13bdadcb  pop r11
00007d3d13bdadcd  pop r10
00007d3d13bdadcf  pop r9
00007d3d13bdadd1  pop r8
00007d3d13bdadd3  pop rsi
00007d3d13bdadd4  pop rdi
00007d3d13bdadd5  pop rdx
00007d3d13bdadd6  pop rcx
00007d3d13bdadd7  pop rax
00007d3d13bdadd8  add rsp, 0x08
00007d3d13bdaddc  jmp 0x00007D3D13BD8FAB
00007d3d13bdade1  call 0x00007D3D13AE5820
00007d3d13bdade6  jmp 0x00007D3D13BD8FB8
00007d3d13bdadeb  sub rsp, 0x08
00007d3d13bdadef  push rax
00007d3d13bdadf0  push rcx
00007d3d13bdadf1  push rdx
00007d3d13bdadf2  push rdi
00007d3d13bdadf3  push rsi
00007d3d13bdadf4  push r8
00007d3d13bdadf6  push r9
00007d3d13bdadf8  push r10
00007d3d13bdadfa  push r11
00007d3d13bdadfc  sub rsp, 0xF0
00007d3d13bdae03  vmovaps [rsp], xmm0
00007d3d13bdae08  vmovaps [rsp+0x10], xmm2
00007d3d13bdae0e  vmovaps [rsp+0x20], xmm3
00007d3d13bdae14  vmovaps [rsp+0x30], xmm4
00007d3d13bdae1a  vmovaps [rsp+0x40], xmm5
00007d3d13bdae20  vmovaps [rsp+0x50], xmm6
00007d3d13bdae26  vmovaps [rsp+0x60], xmm7
00007d3d13bdae2c  vmovaps [rsp+0x70], xmm8
00007d3d13bdae32  vmovaps [rsp+0x80], xmm9
00007d3d13bdae3b  vmovaps [rsp+0x90], xmm10
00007d3d13bdae44  vmovaps [rsp+0xA0], xmm11
00007d3d13bdae4d  vmovaps [rsp+0xB0], xmm12
00007d3d13bdae56  vmovaps [rsp+0xC0], xmm13
00007d3d13bdae5f  vmovaps [rsp+0xD0], xmm14
00007d3d13bdae68  vmovaps [rsp+0xE0], xmm15
00007d3d13bdae71  sub rsp, 0x30
00007d3d13bdae75  movaps [rsp], xmm1
00007d3d13bdae79  movaps [rsp+0x10], xmm5
00007d3d13bdae7e  movaps [rsp+0x20], xmm7
00007d3d13bdae83  lea rdi, [rsp]
00007d3d13bdae87  mov esi, 0x00
00007d3d13bdae8c  mov rax, 0x5741DAFC8530
00007d3d13bdae96  call rax
00007d3d13bdae98  movaps xmm1, [rsp]
00007d3d13bdae9c  add rsp, 0x30
00007d3d13bdaea0  vmovaps xmm0, [rsp]
00007d3d13bdaea5  vmovaps xmm2, [rsp+0x10]
00007d3d13bdaeab  vmovaps xmm3, [rsp+0x20]
00007d3d13bdaeb1  vmovaps xmm4, [rsp+0x30]
00007d3d13bdaeb7  vmovaps xmm5, [rsp+0x40]
00007d3d13bdaebd  vmovaps xmm6, [rsp+0x50]
00007d3d13bdaec3  vmovaps xmm7, [rsp+0x60]
00007d3d13bdaec9  vmovaps xmm8, [rsp+0x70]
00007d3d13bdaecf  vmovaps xmm9, [rsp+0x80]
00007d3d13bdaed8  vmovaps xmm10, [rsp+0x90]
00007d3d13bdaee1  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdaeea  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdaef3  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdaefc  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdaf05  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdaf0e  add rsp, 0xF0
00007d3d13bdaf15  pop r11
00007d3d13bdaf17  pop r10
00007d3d13bdaf19  pop r9
00007d3d13bdaf1b  pop r8
00007d3d13bdaf1d  pop rsi
00007d3d13bdaf1e  pop rdi
00007d3d13bdaf1f  pop rdx
00007d3d13bdaf20  pop rcx
00007d3d13bdaf21  pop rax
00007d3d13bdaf22  add rsp, 0x08
00007d3d13bdaf26  jmp 0x00007D3D13BD905D
00007d3d13bdaf2b  sub rsp, 0x08
00007d3d13bdaf2f  push rax
00007d3d13bdaf30  push rcx
00007d3d13bdaf31  push rdx
00007d3d13bdaf32  push rdi
00007d3d13bdaf33  push rsi
00007d3d13bdaf34  push r8
00007d3d13bdaf36  push r9
00007d3d13bdaf38  push r10
00007d3d13bdaf3a  push r11
00007d3d13bdaf3c  sub rsp, 0xF0
00007d3d13bdaf43  vmovaps [rsp], xmm0
00007d3d13bdaf48  vmovaps [rsp+0x10], xmm1
00007d3d13bdaf4e  vmovaps [rsp+0x20], xmm2
00007d3d13bdaf54  vmovaps [rsp+0x30], xmm3
00007d3d13bdaf5a  vmovaps [rsp+0x40], xmm4
00007d3d13bdaf60  vmovaps [rsp+0x50], xmm5
00007d3d13bdaf66  vmovaps [rsp+0x60], xmm6
00007d3d13bdaf6c  vmovaps [rsp+0x70], xmm8
00007d3d13bdaf72  vmovaps [rsp+0x80], xmm9
00007d3d13bdaf7b  vmovaps [rsp+0x90], xmm10
00007d3d13bdaf84  vmovaps [rsp+0xA0], xmm11
00007d3d13bdaf8d  vmovaps [rsp+0xB0], xmm12
00007d3d13bdaf96  vmovaps [rsp+0xC0], xmm13
00007d3d13bdaf9f  vmovaps [rsp+0xD0], xmm14
00007d3d13bdafa8  vmovaps [rsp+0xE0], xmm15
00007d3d13bdafb1  sub rsp, 0x30
00007d3d13bdafb5  movaps [rsp], xmm7
00007d3d13bdafb9  movaps [rsp+0x10], xmm5
00007d3d13bdafbe  movaps [rsp+0x20], xmm15
00007d3d13bdafc4  lea rdi, [rsp]
00007d3d13bdafc8  mov esi, 0x00
00007d3d13bdafcd  mov rax, 0x5741DAFC8530
00007d3d13bdafd7  call rax
00007d3d13bdafd9  movaps xmm7, [rsp]
00007d3d13bdafdd  add rsp, 0x30
00007d3d13bdafe1  vmovaps xmm0, [rsp]
00007d3d13bdafe6  vmovaps xmm1, [rsp+0x10]
00007d3d13bdafec  vmovaps xmm2, [rsp+0x20]
00007d3d13bdaff2  vmovaps xmm3, [rsp+0x30]
00007d3d13bdaff8  vmovaps xmm4, [rsp+0x40]
00007d3d13bdaffe  vmovaps xmm5, [rsp+0x50]
00007d3d13bdb004  vmovaps xmm6, [rsp+0x60]
00007d3d13bdb00a  vmovaps xmm8, [rsp+0x70]
00007d3d13bdb010  vmovaps xmm9, [rsp+0x80]
00007d3d13bdb019  vmovaps xmm10, [rsp+0x90]
00007d3d13bdb022  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdb02b  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdb034  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdb03d  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdb046  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdb04f  add rsp, 0xF0
00007d3d13bdb056  pop r11
00007d3d13bdb058  pop r10
00007d3d13bdb05a  pop r9
00007d3d13bdb05c  pop r8
00007d3d13bdb05e  pop rsi
00007d3d13bdb05f  pop rdi
00007d3d13bdb060  pop rdx
00007d3d13bdb061  pop rcx
00007d3d13bdb062  pop rax
00007d3d13bdb063  add rsp, 0x08
00007d3d13bdb067  jmp 0x00007D3D13BD9093
00007d3d13bdb06c  call 0x00007D3D13AD64F0
00007d3d13bdb071  jmp 0x00007D3D13BD90A0
00007d3d13bdb076  sub rsp, 0x08
00007d3d13bdb07a  push rax
00007d3d13bdb07b  push rcx
00007d3d13bdb07c  push rdx
00007d3d13bdb07d  push rdi
00007d3d13bdb07e  push rsi
00007d3d13bdb07f  push r8
00007d3d13bdb081  push r9
00007d3d13bdb083  push r10
00007d3d13bdb085  push r11
00007d3d13bdb087  sub rsp, 0xF0
00007d3d13bdb08e  vmovaps [rsp], xmm0
00007d3d13bdb093  vmovaps [rsp+0x10], xmm1
00007d3d13bdb099  vmovaps [rsp+0x20], xmm2
00007d3d13bdb09f  vmovaps [rsp+0x30], xmm3
00007d3d13bdb0a5  vmovaps [rsp+0x40], xmm4
00007d3d13bdb0ab  vmovaps [rsp+0x50], xmm5
00007d3d13bdb0b1  vmovaps [rsp+0x60], xmm6
00007d3d13bdb0b7  vmovaps [rsp+0x70], xmm7
00007d3d13bdb0bd  vmovaps [rsp+0x80], xmm8
00007d3d13bdb0c6  vmovaps [rsp+0x90], xmm9
00007d3d13bdb0cf  vmovaps [rsp+0xA0], xmm10
00007d3d13bdb0d8  vmovaps [rsp+0xB0], xmm11
00007d3d13bdb0e1  vmovaps [rsp+0xC0], xmm12
00007d3d13bdb0ea  vmovaps [rsp+0xD0], xmm13
00007d3d13bdb0f3  vmovaps [rsp+0xE0], xmm14
00007d3d13bdb0fc  sub rsp, 0x30
00007d3d13bdb100  movaps [rsp], xmm15
00007d3d13bdb105  movaps [rsp+0x10], xmm5
00007d3d13bdb10a  movaps [rsp+0x20], xmm3
00007d3d13bdb10f  lea rdi, [rsp]
00007d3d13bdb113  mov esi, 0x00
00007d3d13bdb118  mov rax, 0x5741DAFC8530
00007d3d13bdb122  call rax
00007d3d13bdb124  movaps xmm15, [rsp]
00007d3d13bdb129  add rsp, 0x30
00007d3d13bdb12d  vmovaps xmm0, [rsp]
00007d3d13bdb132  vmovaps xmm1, [rsp+0x10]
00007d3d13bdb138  vmovaps xmm2, [rsp+0x20]
00007d3d13bdb13e  vmovaps xmm3, [rsp+0x30]
00007d3d13bdb144  vmovaps xmm4, [rsp+0x40]
00007d3d13bdb14a  vmovaps xmm5, [rsp+0x50]
00007d3d13bdb150  vmovaps xmm6, [rsp+0x60]
00007d3d13bdb156  vmovaps xmm7, [rsp+0x70]
00007d3d13bdb15c  vmovaps xmm8, [rsp+0x80]
00007d3d13bdb165  vmovaps xmm9, [rsp+0x90]
00007d3d13bdb16e  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdb177  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdb180  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdb189  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdb192  vmovaps xmm14, [rsp+0xE0]
00007d3d13bdb19b  add rsp, 0xF0
00007d3d13bdb1a2  pop r11
00007d3d13bdb1a4  pop r10
00007d3d13bdb1a6  pop r9
00007d3d13bdb1a8  pop r8
00007d3d13bdb1aa  pop rsi
00007d3d13bdb1ab  pop rdi
00007d3d13bdb1ac  pop rdx
00007d3d13bdb1ad  pop rcx
00007d3d13bdb1ae  pop rax
00007d3d13bdb1af  add rsp, 0x08
00007d3d13bdb1b3  jmp 0x00007D3D13BD90C6
00007d3d13bdb1b8  sub rsp, 0x08
00007d3d13bdb1bc  push rax
00007d3d13bdb1bd  push rcx
00007d3d13bdb1be  push rdx
00007d3d13bdb1bf  push rdi
00007d3d13bdb1c0  push rsi
00007d3d13bdb1c1  push r8
00007d3d13bdb1c3  push r9
00007d3d13bdb1c5  push r10
00007d3d13bdb1c7  push r11
00007d3d13bdb1c9  sub rsp, 0xF0
00007d3d13bdb1d0  vmovaps [rsp], xmm0
00007d3d13bdb1d5  vmovaps [rsp+0x10], xmm2
00007d3d13bdb1db  vmovaps [rsp+0x20], xmm3
00007d3d13bdb1e1  vmovaps [rsp+0x30], xmm4
00007d3d13bdb1e7  vmovaps [rsp+0x40], xmm5
00007d3d13bdb1ed  vmovaps [rsp+0x50], xmm6
00007d3d13bdb1f3  vmovaps [rsp+0x60], xmm7
00007d3d13bdb1f9  vmovaps [rsp+0x70], xmm8
00007d3d13bdb1ff  vmovaps [rsp+0x80], xmm9
00007d3d13bdb208  vmovaps [rsp+0x90], xmm10
00007d3d13bdb211  vmovaps [rsp+0xA0], xmm11
00007d3d13bdb21a  vmovaps [rsp+0xB0], xmm12
00007d3d13bdb223  vmovaps [rsp+0xC0], xmm13
00007d3d13bdb22c  vmovaps [rsp+0xD0], xmm14
00007d3d13bdb235  vmovaps [rsp+0xE0], xmm15
00007d3d13bdb23e  sub rsp, 0x30
00007d3d13bdb242  movaps [rsp], xmm1
00007d3d13bdb246  movaps [rsp+0x10], xmm5
00007d3d13bdb24b  movaps [rsp+0x20], xmm4
00007d3d13bdb250  lea rdi, [rsp]
00007d3d13bdb254  mov esi, 0x00
00007d3d13bdb259  mov rax, 0x5741DAFC8530
00007d3d13bdb263  call rax
00007d3d13bdb265  movaps xmm1, [rsp]
00007d3d13bdb269  add rsp, 0x30
00007d3d13bdb26d  vmovaps xmm0, [rsp]
00007d3d13bdb272  vmovaps xmm2, [rsp+0x10]
00007d3d13bdb278  vmovaps xmm3, [rsp+0x20]
00007d3d13bdb27e  vmovaps xmm4, [rsp+0x30]
00007d3d13bdb284  vmovaps xmm5, [rsp+0x40]
00007d3d13bdb28a  vmovaps xmm6, [rsp+0x50]
00007d3d13bdb290  vmovaps xmm7, [rsp+0x60]
00007d3d13bdb296  vmovaps xmm8, [rsp+0x70]
00007d3d13bdb29c  vmovaps xmm9, [rsp+0x80]
00007d3d13bdb2a5  vmovaps xmm10, [rsp+0x90]
00007d3d13bdb2ae  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdb2b7  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdb2c0  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdb2c9  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdb2d2  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdb2db  add rsp, 0xF0
00007d3d13bdb2e2  pop r11
00007d3d13bdb2e4  pop r10
00007d3d13bdb2e6  pop r9
00007d3d13bdb2e8  pop r8
00007d3d13bdb2ea  pop rsi
00007d3d13bdb2eb  pop rdi
00007d3d13bdb2ec  pop rdx
00007d3d13bdb2ed  pop rcx
00007d3d13bdb2ee  pop rax
00007d3d13bdb2ef  add rsp, 0x08
00007d3d13bdb2f3  jmp 0x00007D3D13BD90E6
00007d3d13bdb2f8  sub rsp, 0x08
00007d3d13bdb2fc  push rax
00007d3d13bdb2fd  push rcx
00007d3d13bdb2fe  push rdx
00007d3d13bdb2ff  push rdi
00007d3d13bdb300  push rsi
00007d3d13bdb301  push r8
00007d3d13bdb303  push r9
00007d3d13bdb305  push r10
00007d3d13bdb307  push r11
00007d3d13bdb309  sub rsp, 0xF0
00007d3d13bdb310  vmovaps [rsp], xmm0
00007d3d13bdb315  vmovaps [rsp+0x10], xmm1
00007d3d13bdb31b  vmovaps [rsp+0x20], xmm2
00007d3d13bdb321  vmovaps [rsp+0x30], xmm3
00007d3d13bdb327  vmovaps [rsp+0x40], xmm5
00007d3d13bdb32d  vmovaps [rsp+0x50], xmm6
00007d3d13bdb333  vmovaps [rsp+0x60], xmm7
00007d3d13bdb339  vmovaps [rsp+0x70], xmm8
00007d3d13bdb33f  vmovaps [rsp+0x80], xmm9
00007d3d13bdb348  vmovaps [rsp+0x90], xmm10
00007d3d13bdb351  vmovaps [rsp+0xA0], xmm11
00007d3d13bdb35a  vmovaps [rsp+0xB0], xmm12
00007d3d13bdb363  vmovaps [rsp+0xC0], xmm13
00007d3d13bdb36c  vmovaps [rsp+0xD0], xmm14
00007d3d13bdb375  vmovaps [rsp+0xE0], xmm15
00007d3d13bdb37e  sub rsp, 0x30
00007d3d13bdb382  movaps [rsp], xmm4
00007d3d13bdb386  movaps [rsp+0x10], xmm3
00007d3d13bdb38b  movaps [rsp+0x20], xmm5
00007d3d13bdb390  lea rdi, [rsp]
00007d3d13bdb394  mov esi, 0x00
00007d3d13bdb399  mov rax, 0x5741DAFC8530
00007d3d13bdb3a3  call rax
00007d3d13bdb3a5  movaps xmm4, [rsp]
00007d3d13bdb3a9  add rsp, 0x30
00007d3d13bdb3ad  vmovaps xmm0, [rsp]
00007d3d13bdb3b2  vmovaps xmm1, [rsp+0x10]
00007d3d13bdb3b8  vmovaps xmm2, [rsp+0x20]
00007d3d13bdb3be  vmovaps xmm3, [rsp+0x30]
00007d3d13bdb3c4  vmovaps xmm5, [rsp+0x40]
00007d3d13bdb3ca  vmovaps xmm6, [rsp+0x50]
00007d3d13bdb3d0  vmovaps xmm7, [rsp+0x60]
00007d3d13bdb3d6  vmovaps xmm8, [rsp+0x70]
00007d3d13bdb3dc  vmovaps xmm9, [rsp+0x80]
00007d3d13bdb3e5  vmovaps xmm10, [rsp+0x90]
00007d3d13bdb3ee  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdb3f7  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdb400  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdb409  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdb412  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdb41b  add rsp, 0xF0
00007d3d13bdb422  pop r11
00007d3d13bdb424  pop r10
00007d3d13bdb426  pop r9
00007d3d13bdb428  pop r8
00007d3d13bdb42a  pop rsi
00007d3d13bdb42b  pop rdi
00007d3d13bdb42c  pop rdx
00007d3d13bdb42d  pop rcx
00007d3d13bdb42e  pop rax
00007d3d13bdb42f  add rsp, 0x08
00007d3d13bdb433  jmp 0x00007D3D13BD9134
00007d3d13bdb438  call 0x00007D3D13AD64F0
00007d3d13bdb43d  jmp 0x00007D3D13BD9141
00007d3d13bdb442  sub rsp, 0x08
00007d3d13bdb446  push rax
00007d3d13bdb447  push rcx
00007d3d13bdb448  push rdx
00007d3d13bdb449  push rdi
00007d3d13bdb44a  push rsi
00007d3d13bdb44b  push r8
00007d3d13bdb44d  push r9
00007d3d13bdb44f  push r10
00007d3d13bdb451  push r11
00007d3d13bdb453  sub rsp, 0xF0
00007d3d13bdb45a  vmovaps [rsp], xmm0
00007d3d13bdb45f  vmovaps [rsp+0x10], xmm1
00007d3d13bdb465  vmovaps [rsp+0x20], xmm2
00007d3d13bdb46b  vmovaps [rsp+0x30], xmm3
00007d3d13bdb471  vmovaps [rsp+0x40], xmm4
00007d3d13bdb477  vmovaps [rsp+0x50], xmm6
00007d3d13bdb47d  vmovaps [rsp+0x60], xmm7
00007d3d13bdb483  vmovaps [rsp+0x70], xmm8
00007d3d13bdb489  vmovaps [rsp+0x80], xmm9
00007d3d13bdb492  vmovaps [rsp+0x90], xmm10
00007d3d13bdb49b  vmovaps [rsp+0xA0], xmm11
00007d3d13bdb4a4  vmovaps [rsp+0xB0], xmm12
00007d3d13bdb4ad  vmovaps [rsp+0xC0], xmm13
00007d3d13bdb4b6  vmovaps [rsp+0xD0], xmm14
00007d3d13bdb4bf  vmovaps [rsp+0xE0], xmm15
00007d3d13bdb4c8  sub rsp, 0x30
00007d3d13bdb4cc  movaps [rsp], xmm5
00007d3d13bdb4d0  movaps [rsp+0x10], xmm6
00007d3d13bdb4d5  movaps [rsp+0x20], xmm3
00007d3d13bdb4da  lea rdi, [rsp]
00007d3d13bdb4de  mov esi, 0x00
00007d3d13bdb4e3  mov rax, 0x5741DAFC8530
00007d3d13bdb4ed  call rax
00007d3d13bdb4ef  movaps xmm5, [rsp]
00007d3d13bdb4f3  add rsp, 0x30
00007d3d13bdb4f7  vmovaps xmm0, [rsp]
00007d3d13bdb4fc  vmovaps xmm1, [rsp+0x10]
00007d3d13bdb502  vmovaps xmm2, [rsp+0x20]
00007d3d13bdb508  vmovaps xmm3, [rsp+0x30]
00007d3d13bdb50e  vmovaps xmm4, [rsp+0x40]
00007d3d13bdb514  vmovaps xmm6, [rsp+0x50]
00007d3d13bdb51a  vmovaps xmm7, [rsp+0x60]
00007d3d13bdb520  vmovaps xmm8, [rsp+0x70]
00007d3d13bdb526  vmovaps xmm9, [rsp+0x80]
00007d3d13bdb52f  vmovaps xmm10, [rsp+0x90]
00007d3d13bdb538  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdb541  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdb54a  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdb553  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdb55c  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdb565  add rsp, 0xF0
00007d3d13bdb56c  pop r11
00007d3d13bdb56e  pop r10
00007d3d13bdb570  pop r9
00007d3d13bdb572  pop r8
00007d3d13bdb574  pop rsi
00007d3d13bdb575  pop rdi
00007d3d13bdb576  pop rdx
00007d3d13bdb577  pop rcx
00007d3d13bdb578  pop rax
00007d3d13bdb579  add rsp, 0x08
00007d3d13bdb57d  jmp 0x00007D3D13BD9167
00007d3d13bdb582  sub rsp, 0x08
00007d3d13bdb586  push rax
00007d3d13bdb587  push rcx
00007d3d13bdb588  push rdx
00007d3d13bdb589  push rdi
00007d3d13bdb58a  push rsi
00007d3d13bdb58b  push r8
00007d3d13bdb58d  push r9
00007d3d13bdb58f  push r10
00007d3d13bdb591  push r11
00007d3d13bdb593  sub rsp, 0xF0
00007d3d13bdb59a  vmovaps [rsp], xmm0
00007d3d13bdb59f  vmovaps [rsp+0x10], xmm1
00007d3d13bdb5a5  vmovaps [rsp+0x20], xmm2
00007d3d13bdb5ab  vmovaps [rsp+0x30], xmm3
00007d3d13bdb5b1  vmovaps [rsp+0x40], xmm4
00007d3d13bdb5b7  vmovaps [rsp+0x50], xmm5
00007d3d13bdb5bd  vmovaps [rsp+0x60], xmm7
00007d3d13bdb5c3  vmovaps [rsp+0x70], xmm8
00007d3d13bdb5c9  vmovaps [rsp+0x80], xmm9
00007d3d13bdb5d2  vmovaps [rsp+0x90], xmm10
00007d3d13bdb5db  vmovaps [rsp+0xA0], xmm11
00007d3d13bdb5e4  vmovaps [rsp+0xB0], xmm12
00007d3d13bdb5ed  vmovaps [rsp+0xC0], xmm13
00007d3d13bdb5f6  vmovaps [rsp+0xD0], xmm14
00007d3d13bdb5ff  vmovaps [rsp+0xE0], xmm15
00007d3d13bdb608  sub rsp, 0x30
00007d3d13bdb60c  movaps [rsp], xmm6
00007d3d13bdb610  movaps [rsp+0x10], xmm9
00007d3d13bdb616  movaps [rsp+0x20], xmm1
00007d3d13bdb61b  lea rdi, [rsp]
00007d3d13bdb61f  mov esi, 0x00
00007d3d13bdb624  mov rax, 0x5741DAFC8530
00007d3d13bdb62e  call rax
00007d3d13bdb630  movaps xmm6, [rsp]
00007d3d13bdb634  add rsp, 0x30
00007d3d13bdb638  vmovaps xmm0, [rsp]
00007d3d13bdb63d  vmovaps xmm1, [rsp+0x10]
00007d3d13bdb643  vmovaps xmm2, [rsp+0x20]
00007d3d13bdb649  vmovaps xmm3, [rsp+0x30]
00007d3d13bdb64f  vmovaps xmm4, [rsp+0x40]
00007d3d13bdb655  vmovaps xmm5, [rsp+0x50]
00007d3d13bdb65b  vmovaps xmm7, [rsp+0x60]
00007d3d13bdb661  vmovaps xmm8, [rsp+0x70]
00007d3d13bdb667  vmovaps xmm9, [rsp+0x80]
00007d3d13bdb670  vmovaps xmm10, [rsp+0x90]
00007d3d13bdb679  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdb682  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdb68b  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdb694  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdb69d  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdb6a6  add rsp, 0xF0
00007d3d13bdb6ad  pop r11
00007d3d13bdb6af  pop r10
00007d3d13bdb6b1  pop r9
00007d3d13bdb6b3  pop r8
00007d3d13bdb6b5  pop rsi
00007d3d13bdb6b6  pop rdi
00007d3d13bdb6b7  pop rdx
00007d3d13bdb6b8  pop rcx
00007d3d13bdb6b9  pop rax
00007d3d13bdb6ba  add rsp, 0x08
00007d3d13bdb6be  jmp 0x00007D3D13BD918B
00007d3d13bdb6c3  sub rsp, 0x08
00007d3d13bdb6c7  push rax
00007d3d13bdb6c8  push rcx
00007d3d13bdb6c9  push rdx
00007d3d13bdb6ca  push rdi
00007d3d13bdb6cb  push rsi
00007d3d13bdb6cc  push r8
00007d3d13bdb6ce  push r9
00007d3d13bdb6d0  push r10
00007d3d13bdb6d2  push r11
00007d3d13bdb6d4  sub rsp, 0xF0
00007d3d13bdb6db  vmovaps [rsp], xmm0
00007d3d13bdb6e0  vmovaps [rsp+0x10], xmm1
00007d3d13bdb6e6  vmovaps [rsp+0x20], xmm2
00007d3d13bdb6ec  vmovaps [rsp+0x30], xmm3
00007d3d13bdb6f2  vmovaps [rsp+0x40], xmm4
00007d3d13bdb6f8  vmovaps [rsp+0x50], xmm5
00007d3d13bdb6fe  vmovaps [rsp+0x60], xmm6
00007d3d13bdb704  vmovaps [rsp+0x70], xmm7
00007d3d13bdb70a  vmovaps [rsp+0x80], xmm8
00007d3d13bdb713  vmovaps [rsp+0x90], xmm10
00007d3d13bdb71c  vmovaps [rsp+0xA0], xmm11
00007d3d13bdb725  vmovaps [rsp+0xB0], xmm12
00007d3d13bdb72e  vmovaps [rsp+0xC0], xmm13
00007d3d13bdb737  vmovaps [rsp+0xD0], xmm14
00007d3d13bdb740  vmovaps [rsp+0xE0], xmm15
00007d3d13bdb749  sub rsp, 0x30
00007d3d13bdb74d  movaps [rsp], xmm9
00007d3d13bdb752  movaps [rsp+0x10], xmm3
00007d3d13bdb757  movaps [rsp+0x20], xmm1
00007d3d13bdb75c  lea rdi, [rsp]
00007d3d13bdb760  mov esi, 0x00
00007d3d13bdb765  mov rax, 0x5741DAFC8530
00007d3d13bdb76f  call rax
00007d3d13bdb771  movaps xmm9, [rsp]
00007d3d13bdb776  add rsp, 0x30
00007d3d13bdb77a  vmovaps xmm0, [rsp]
00007d3d13bdb77f  vmovaps xmm1, [rsp+0x10]
00007d3d13bdb785  vmovaps xmm2, [rsp+0x20]
00007d3d13bdb78b  vmovaps xmm3, [rsp+0x30]
00007d3d13bdb791  vmovaps xmm4, [rsp+0x40]
00007d3d13bdb797  vmovaps xmm5, [rsp+0x50]
00007d3d13bdb79d  vmovaps xmm6, [rsp+0x60]
00007d3d13bdb7a3  vmovaps xmm7, [rsp+0x70]
00007d3d13bdb7a9  vmovaps xmm8, [rsp+0x80]
00007d3d13bdb7b2  vmovaps xmm10, [rsp+0x90]
00007d3d13bdb7bb  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdb7c4  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdb7cd  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdb7d6  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdb7df  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdb7e8  add rsp, 0xF0
00007d3d13bdb7ef  pop r11
00007d3d13bdb7f1  pop r10
00007d3d13bdb7f3  pop r9
00007d3d13bdb7f5  pop r8
00007d3d13bdb7f7  pop rsi
00007d3d13bdb7f8  pop rdi
00007d3d13bdb7f9  pop rdx
00007d3d13bdb7fa  pop rcx
00007d3d13bdb7fb  pop rax
00007d3d13bdb7fc  add rsp, 0x08
00007d3d13bdb800  jmp 0x00007D3D13BD91D7
00007d3d13bdb805  call 0x00007D3D13AD64F0
00007d3d13bdb80a  jmp 0x00007D3D13BD91E4
00007d3d13bdb80f  sub rsp, 0x08
00007d3d13bdb813  push rax
00007d3d13bdb814  push rcx
00007d3d13bdb815  push rdx
00007d3d13bdb816  push rdi
00007d3d13bdb817  push rsi
00007d3d13bdb818  push r8
00007d3d13bdb81a  push r9
00007d3d13bdb81c  push r10
00007d3d13bdb81e  push r11
00007d3d13bdb820  sub rsp, 0xF0
00007d3d13bdb827  vmovaps [rsp], xmm0
00007d3d13bdb82c  vmovaps [rsp+0x10], xmm1
00007d3d13bdb832  vmovaps [rsp+0x20], xmm2
00007d3d13bdb838  vmovaps [rsp+0x30], xmm3
00007d3d13bdb83e  vmovaps [rsp+0x40], xmm4
00007d3d13bdb844  vmovaps [rsp+0x50], xmm5
00007d3d13bdb84a  vmovaps [rsp+0x60], xmm6
00007d3d13bdb850  vmovaps [rsp+0x70], xmm7
00007d3d13bdb856  vmovaps [rsp+0x80], xmm8
00007d3d13bdb85f  vmovaps [rsp+0x90], xmm9
00007d3d13bdb868  vmovaps [rsp+0xA0], xmm10
00007d3d13bdb871  vmovaps [rsp+0xB0], xmm11
00007d3d13bdb87a  vmovaps [rsp+0xC0], xmm12
00007d3d13bdb883  vmovaps [rsp+0xD0], xmm13
00007d3d13bdb88c  vmovaps [rsp+0xE0], xmm14
00007d3d13bdb895  sub rsp, 0x30
00007d3d13bdb899  movaps [rsp], xmm15
00007d3d13bdb89e  movaps [rsp+0x10], xmm3
00007d3d13bdb8a3  movaps [rsp+0x20], xmm7
00007d3d13bdb8a8  lea rdi, [rsp]
00007d3d13bdb8ac  mov esi, 0x00
00007d3d13bdb8b1  mov rax, 0x5741DAFC8530
00007d3d13bdb8bb  call rax
00007d3d13bdb8bd  movaps xmm15, [rsp]
00007d3d13bdb8c2  add rsp, 0x30
00007d3d13bdb8c6  vmovaps xmm0, [rsp]
00007d3d13bdb8cb  vmovaps xmm1, [rsp+0x10]
00007d3d13bdb8d1  vmovaps xmm2, [rsp+0x20]
00007d3d13bdb8d7  vmovaps xmm3, [rsp+0x30]
00007d3d13bdb8dd  vmovaps xmm4, [rsp+0x40]
00007d3d13bdb8e3  vmovaps xmm5, [rsp+0x50]
00007d3d13bdb8e9  vmovaps xmm6, [rsp+0x60]
00007d3d13bdb8ef  vmovaps xmm7, [rsp+0x70]
00007d3d13bdb8f5  vmovaps xmm8, [rsp+0x80]
00007d3d13bdb8fe  vmovaps xmm9, [rsp+0x90]
00007d3d13bdb907  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdb910  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdb919  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdb922  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdb92b  vmovaps xmm14, [rsp+0xE0]
00007d3d13bdb934  add rsp, 0xF0
00007d3d13bdb93b  pop r11
00007d3d13bdb93d  pop r10
00007d3d13bdb93f  pop r9
00007d3d13bdb941  pop r8
00007d3d13bdb943  pop rsi
00007d3d13bdb944  pop rdi
00007d3d13bdb945  pop rdx
00007d3d13bdb946  pop rcx
00007d3d13bdb947  pop rax
00007d3d13bdb948  add rsp, 0x08
00007d3d13bdb94c  jmp 0x00007D3D13BD9210
00007d3d13bdb951  sub rsp, 0x08
00007d3d13bdb955  push rax
00007d3d13bdb956  push rcx
00007d3d13bdb957  push rdx
00007d3d13bdb958  push rdi
00007d3d13bdb959  push rsi
00007d3d13bdb95a  push r8
00007d3d13bdb95c  push r9
00007d3d13bdb95e  push r10
00007d3d13bdb960  push r11
00007d3d13bdb962  sub rsp, 0xF0
00007d3d13bdb969  vmovaps [rsp], xmm0
00007d3d13bdb96e  vmovaps [rsp+0x10], xmm1
00007d3d13bdb974  vmovaps [rsp+0x20], xmm2
00007d3d13bdb97a  vmovaps [rsp+0x30], xmm4
00007d3d13bdb980  vmovaps [rsp+0x40], xmm5
00007d3d13bdb986  vmovaps [rsp+0x50], xmm6
00007d3d13bdb98c  vmovaps [rsp+0x60], xmm7
00007d3d13bdb992  vmovaps [rsp+0x70], xmm8
00007d3d13bdb998  vmovaps [rsp+0x80], xmm9
00007d3d13bdb9a1  vmovaps [rsp+0x90], xmm10
00007d3d13bdb9aa  vmovaps [rsp+0xA0], xmm11
00007d3d13bdb9b3  vmovaps [rsp+0xB0], xmm12
00007d3d13bdb9bc  vmovaps [rsp+0xC0], xmm13
00007d3d13bdb9c5  vmovaps [rsp+0xD0], xmm14
00007d3d13bdb9ce  vmovaps [rsp+0xE0], xmm15
00007d3d13bdb9d7  sub rsp, 0x30
00007d3d13bdb9db  movaps [rsp], xmm3
00007d3d13bdb9df  movaps [rsp+0x10], xmm1
00007d3d13bdb9e4  movaps [rsp+0x20], xmm15
00007d3d13bdb9ea  lea rdi, [rsp]
00007d3d13bdb9ee  mov esi, 0x00
00007d3d13bdb9f3  mov rax, 0x5741DAFC8530
00007d3d13bdb9fd  call rax
00007d3d13bdb9ff  movaps xmm3, [rsp]
00007d3d13bdba03  add rsp, 0x30
00007d3d13bdba07  vmovaps xmm0, [rsp]
00007d3d13bdba0c  vmovaps xmm1, [rsp+0x10]
00007d3d13bdba12  vmovaps xmm2, [rsp+0x20]
00007d3d13bdba18  vmovaps xmm4, [rsp+0x30]
00007d3d13bdba1e  vmovaps xmm5, [rsp+0x40]
00007d3d13bdba24  vmovaps xmm6, [rsp+0x50]
00007d3d13bdba2a  vmovaps xmm7, [rsp+0x60]
00007d3d13bdba30  vmovaps xmm8, [rsp+0x70]
00007d3d13bdba36  vmovaps xmm9, [rsp+0x80]
00007d3d13bdba3f  vmovaps xmm10, [rsp+0x90]
00007d3d13bdba48  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdba51  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdba5a  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdba63  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdba6c  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdba75  add rsp, 0xF0
00007d3d13bdba7c  pop r11
00007d3d13bdba7e  pop r10
00007d3d13bdba80  pop r9
00007d3d13bdba82  pop r8
00007d3d13bdba84  pop rsi
00007d3d13bdba85  pop rdi
00007d3d13bdba86  pop rdx
00007d3d13bdba87  pop rcx
00007d3d13bdba88  pop rax
00007d3d13bdba89  add rsp, 0x08
00007d3d13bdba8d  jmp 0x00007D3D13BD929F
00007d3d13bdba92  call 0x00007D3D13AD64F0
00007d3d13bdba97  jmp 0x00007D3D13BD92A9
00007d3d13bdba9c  sub rsp, 0x08
00007d3d13bdbaa0  push rax
00007d3d13bdbaa1  push rcx
00007d3d13bdbaa2  push rdx
00007d3d13bdbaa3  push rdi
00007d3d13bdbaa4  push rsi
00007d3d13bdbaa5  push r8
00007d3d13bdbaa7  push r9
00007d3d13bdbaa9  push r10
00007d3d13bdbaab  push r11
00007d3d13bdbaad  sub rsp, 0xF0
00007d3d13bdbab4  vmovaps [rsp], xmm0
00007d3d13bdbab9  vmovaps [rsp+0x10], xmm1
00007d3d13bdbabf  vmovaps [rsp+0x20], xmm2
00007d3d13bdbac5  vmovaps [rsp+0x30], xmm3
00007d3d13bdbacb  vmovaps [rsp+0x40], xmm4
00007d3d13bdbad1  vmovaps [rsp+0x50], xmm5
00007d3d13bdbad7  vmovaps [rsp+0x60], xmm6
00007d3d13bdbadd  vmovaps [rsp+0x70], xmm7
00007d3d13bdbae3  vmovaps [rsp+0x80], xmm8
00007d3d13bdbaec  vmovaps [rsp+0x90], xmm9
00007d3d13bdbaf5  vmovaps [rsp+0xA0], xmm10
00007d3d13bdbafe  vmovaps [rsp+0xB0], xmm11
00007d3d13bdbb07  vmovaps [rsp+0xC0], xmm12
00007d3d13bdbb10  vmovaps [rsp+0xD0], xmm13
00007d3d13bdbb19  vmovaps [rsp+0xE0], xmm14
00007d3d13bdbb22  sub rsp, 0x30
00007d3d13bdbb26  movaps [rsp], xmm15
00007d3d13bdbb2b  movaps [rsp+0x10], xmm14
00007d3d13bdbb31  movaps [rsp+0x20], xmm4
00007d3d13bdbb36  lea rdi, [rsp]
00007d3d13bdbb3a  mov esi, 0x00
00007d3d13bdbb3f  mov rax, 0x5741DAFC8530
00007d3d13bdbb49  call rax
00007d3d13bdbb4b  movaps xmm15, [rsp]
00007d3d13bdbb50  add rsp, 0x30
00007d3d13bdbb54  vmovaps xmm0, [rsp]
00007d3d13bdbb59  vmovaps xmm1, [rsp+0x10]
00007d3d13bdbb5f  vmovaps xmm2, [rsp+0x20]
00007d3d13bdbb65  vmovaps xmm3, [rsp+0x30]
00007d3d13bdbb6b  vmovaps xmm4, [rsp+0x40]
00007d3d13bdbb71  vmovaps xmm5, [rsp+0x50]
00007d3d13bdbb77  vmovaps xmm6, [rsp+0x60]
00007d3d13bdbb7d  vmovaps xmm7, [rsp+0x70]
00007d3d13bdbb83  vmovaps xmm8, [rsp+0x80]
00007d3d13bdbb8c  vmovaps xmm9, [rsp+0x90]
00007d3d13bdbb95  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdbb9e  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdbba7  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdbbb0  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdbbb9  vmovaps xmm14, [rsp+0xE0]
00007d3d13bdbbc2  add rsp, 0xF0
00007d3d13bdbbc9  pop r11
00007d3d13bdbbcb  pop r10
00007d3d13bdbbcd  pop r9
00007d3d13bdbbcf  pop r8
00007d3d13bdbbd1  pop rsi
00007d3d13bdbbd2  pop rdi
00007d3d13bdbbd3  pop rdx
00007d3d13bdbbd4  pop rcx
00007d3d13bdbbd5  pop rax
00007d3d13bdbbd6  add rsp, 0x08
00007d3d13bdbbda  jmp 0x00007D3D13BD92D7
00007d3d13bdbbdf  sub rsp, 0x08
00007d3d13bdbbe3  push rax
00007d3d13bdbbe4  push rcx
00007d3d13bdbbe5  push rdx
00007d3d13bdbbe6  push rdi
00007d3d13bdbbe7  push rsi
00007d3d13bdbbe8  push r8
00007d3d13bdbbea  push r9
00007d3d13bdbbec  push r10
00007d3d13bdbbee  push r11
00007d3d13bdbbf0  sub rsp, 0xF0
00007d3d13bdbbf7  vmovaps [rsp], xmm0
00007d3d13bdbbfc  vmovaps [rsp+0x10], xmm1
00007d3d13bdbc02  vmovaps [rsp+0x20], xmm2
00007d3d13bdbc08  vmovaps [rsp+0x30], xmm3
00007d3d13bdbc0e  vmovaps [rsp+0x40], xmm4
00007d3d13bdbc14  vmovaps [rsp+0x50], xmm5
00007d3d13bdbc1a  vmovaps [rsp+0x60], xmm6
00007d3d13bdbc20  vmovaps [rsp+0x70], xmm7
00007d3d13bdbc26  vmovaps [rsp+0x80], xmm8
00007d3d13bdbc2f  vmovaps [rsp+0x90], xmm9
00007d3d13bdbc38  vmovaps [rsp+0xA0], xmm10
00007d3d13bdbc41  vmovaps [rsp+0xB0], xmm11
00007d3d13bdbc4a  vmovaps [rsp+0xC0], xmm12
00007d3d13bdbc53  vmovaps [rsp+0xD0], xmm13
00007d3d13bdbc5c  vmovaps [rsp+0xE0], xmm15
00007d3d13bdbc65  sub rsp, 0x30
00007d3d13bdbc69  movaps [rsp], xmm14
00007d3d13bdbc6e  movaps [rsp+0x10], xmm2
00007d3d13bdbc73  movaps [rsp+0x20], xmm1
00007d3d13bdbc78  lea rdi, [rsp]
00007d3d13bdbc7c  mov esi, 0x00
00007d3d13bdbc81  mov rax, 0x5741DAFC8530
00007d3d13bdbc8b  call rax
00007d3d13bdbc8d  movaps xmm14, [rsp]
00007d3d13bdbc92  add rsp, 0x30
00007d3d13bdbc96  vmovaps xmm0, [rsp]
00007d3d13bdbc9b  vmovaps xmm1, [rsp+0x10]
00007d3d13bdbca1  vmovaps xmm2, [rsp+0x20]
00007d3d13bdbca7  vmovaps xmm3, [rsp+0x30]
00007d3d13bdbcad  vmovaps xmm4, [rsp+0x40]
00007d3d13bdbcb3  vmovaps xmm5, [rsp+0x50]
00007d3d13bdbcb9  vmovaps xmm6, [rsp+0x60]
00007d3d13bdbcbf  vmovaps xmm7, [rsp+0x70]
00007d3d13bdbcc5  vmovaps xmm8, [rsp+0x80]
00007d3d13bdbcce  vmovaps xmm9, [rsp+0x90]
00007d3d13bdbcd7  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdbce0  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdbce9  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdbcf2  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdbcfb  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdbd04  add rsp, 0xF0
00007d3d13bdbd0b  pop r11
00007d3d13bdbd0d  pop r10
00007d3d13bdbd0f  pop r9
00007d3d13bdbd11  pop r8
00007d3d13bdbd13  pop rsi
00007d3d13bdbd14  pop rdi
00007d3d13bdbd15  pop rdx
00007d3d13bdbd16  pop rcx
00007d3d13bdbd17  pop rax
00007d3d13bdbd18  add rsp, 0x08
00007d3d13bdbd1c  jmp 0x00007D3D13BD92FD
00007d3d13bdbd21  sub rsp, 0x08
00007d3d13bdbd25  push rax
00007d3d13bdbd26  push rcx
00007d3d13bdbd27  push rdx
00007d3d13bdbd28  push rdi
00007d3d13bdbd29  push rsi
00007d3d13bdbd2a  push r8
00007d3d13bdbd2c  push r9
00007d3d13bdbd2e  push r10
00007d3d13bdbd30  push r11
00007d3d13bdbd32  sub rsp, 0xF0
00007d3d13bdbd39  vmovaps [rsp], xmm0
00007d3d13bdbd3e  vmovaps [rsp+0x10], xmm2
00007d3d13bdbd44  vmovaps [rsp+0x20], xmm3
00007d3d13bdbd4a  vmovaps [rsp+0x30], xmm4
00007d3d13bdbd50  vmovaps [rsp+0x40], xmm5
00007d3d13bdbd56  vmovaps [rsp+0x50], xmm6
00007d3d13bdbd5c  vmovaps [rsp+0x60], xmm7
00007d3d13bdbd62  vmovaps [rsp+0x70], xmm8
00007d3d13bdbd68  vmovaps [rsp+0x80], xmm9
00007d3d13bdbd71  vmovaps [rsp+0x90], xmm10
00007d3d13bdbd7a  vmovaps [rsp+0xA0], xmm11
00007d3d13bdbd83  vmovaps [rsp+0xB0], xmm12
00007d3d13bdbd8c  vmovaps [rsp+0xC0], xmm13
00007d3d13bdbd95  vmovaps [rsp+0xD0], xmm14
00007d3d13bdbd9e  vmovaps [rsp+0xE0], xmm15
00007d3d13bdbda7  sub rsp, 0x30
00007d3d13bdbdab  movaps [rsp], xmm1
00007d3d13bdbdaf  movaps [rsp+0x10], xmm4
00007d3d13bdbdb4  movaps [rsp+0x20], xmm9
00007d3d13bdbdba  lea rdi, [rsp]
00007d3d13bdbdbe  mov esi, 0x00
00007d3d13bdbdc3  mov rax, 0x5741DAFC8530
00007d3d13bdbdcd  call rax
00007d3d13bdbdcf  movaps xmm1, [rsp]
00007d3d13bdbdd3  add rsp, 0x30
00007d3d13bdbdd7  vmovaps xmm0, [rsp]
00007d3d13bdbddc  vmovaps xmm2, [rsp+0x10]
00007d3d13bdbde2  vmovaps xmm3, [rsp+0x20]
00007d3d13bdbde8  vmovaps xmm4, [rsp+0x30]
00007d3d13bdbdee  vmovaps xmm5, [rsp+0x40]
00007d3d13bdbdf4  vmovaps xmm6, [rsp+0x50]
00007d3d13bdbdfa  vmovaps xmm7, [rsp+0x60]
00007d3d13bdbe00  vmovaps xmm8, [rsp+0x70]
00007d3d13bdbe06  vmovaps xmm9, [rsp+0x80]
00007d3d13bdbe0f  vmovaps xmm10, [rsp+0x90]
00007d3d13bdbe18  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdbe21  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdbe2a  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdbe33  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdbe3c  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdbe45  add rsp, 0xF0
00007d3d13bdbe4c  pop r11
00007d3d13bdbe4e  pop r10
00007d3d13bdbe50  pop r9
00007d3d13bdbe52  pop r8
00007d3d13bdbe54  pop rsi
00007d3d13bdbe55  pop rdi
00007d3d13bdbe56  pop rdx
00007d3d13bdbe57  pop rcx
00007d3d13bdbe58  pop rax
00007d3d13bdbe59  add rsp, 0x08
00007d3d13bdbe5d  jmp 0x00007D3D13BD931B
00007d3d13bdbe62  sub rsp, 0x08
00007d3d13bdbe66  push rax
00007d3d13bdbe67  push rcx
00007d3d13bdbe68  push rdx
00007d3d13bdbe69  push rdi
00007d3d13bdbe6a  push rsi
00007d3d13bdbe6b  push r8
00007d3d13bdbe6d  push r9
00007d3d13bdbe6f  push r10
00007d3d13bdbe71  push r11
00007d3d13bdbe73  sub rsp, 0xF0
00007d3d13bdbe7a  vmovaps [rsp], xmm0
00007d3d13bdbe7f  vmovaps [rsp+0x10], xmm1
00007d3d13bdbe85  vmovaps [rsp+0x20], xmm2
00007d3d13bdbe8b  vmovaps [rsp+0x30], xmm3
00007d3d13bdbe91  vmovaps [rsp+0x40], xmm5
00007d3d13bdbe97  vmovaps [rsp+0x50], xmm6
00007d3d13bdbe9d  vmovaps [rsp+0x60], xmm7
00007d3d13bdbea3  vmovaps [rsp+0x70], xmm8
00007d3d13bdbea9  vmovaps [rsp+0x80], xmm9
00007d3d13bdbeb2  vmovaps [rsp+0x90], xmm10
00007d3d13bdbebb  vmovaps [rsp+0xA0], xmm11
00007d3d13bdbec4  vmovaps [rsp+0xB0], xmm12
00007d3d13bdbecd  vmovaps [rsp+0xC0], xmm13
00007d3d13bdbed6  vmovaps [rsp+0xD0], xmm14
00007d3d13bdbedf  vmovaps [rsp+0xE0], xmm15
00007d3d13bdbee8  sub rsp, 0x30
00007d3d13bdbeec  movaps [rsp], xmm4
00007d3d13bdbef0  movaps [rsp+0x10], xmm2
00007d3d13bdbef5  movaps [rsp+0x20], xmm9
00007d3d13bdbefb  lea rdi, [rsp]
00007d3d13bdbeff  mov esi, 0x00
00007d3d13bdbf04  mov rax, 0x5741DAFC8530
00007d3d13bdbf0e  call rax
00007d3d13bdbf10  movaps xmm4, [rsp]
00007d3d13bdbf14  add rsp, 0x30
00007d3d13bdbf18  vmovaps xmm0, [rsp]
00007d3d13bdbf1d  vmovaps xmm1, [rsp+0x10]
00007d3d13bdbf23  vmovaps xmm2, [rsp+0x20]
00007d3d13bdbf29  vmovaps xmm3, [rsp+0x30]
00007d3d13bdbf2f  vmovaps xmm5, [rsp+0x40]
00007d3d13bdbf35  vmovaps xmm6, [rsp+0x50]
00007d3d13bdbf3b  vmovaps xmm7, [rsp+0x60]
00007d3d13bdbf41  vmovaps xmm8, [rsp+0x70]
00007d3d13bdbf47  vmovaps xmm9, [rsp+0x80]
00007d3d13bdbf50  vmovaps xmm10, [rsp+0x90]
00007d3d13bdbf59  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdbf62  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdbf6b  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdbf74  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdbf7d  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdbf86  add rsp, 0xF0
00007d3d13bdbf8d  pop r11
00007d3d13bdbf8f  pop r10
00007d3d13bdbf91  pop r9
00007d3d13bdbf93  pop r8
00007d3d13bdbf95  pop rsi
00007d3d13bdbf96  pop rdi
00007d3d13bdbf97  pop rdx
00007d3d13bdbf98  pop rcx
00007d3d13bdbf99  pop rax
00007d3d13bdbf9a  add rsp, 0x08
00007d3d13bdbf9e  jmp 0x00007D3D13BD934B
00007d3d13bdbfa3  sub rsp, 0x08
00007d3d13bdbfa7  push rax
00007d3d13bdbfa8  push rcx
00007d3d13bdbfa9  push rdx
00007d3d13bdbfaa  push rdi
00007d3d13bdbfab  push rsi
00007d3d13bdbfac  push r8
00007d3d13bdbfae  push r9
00007d3d13bdbfb0  push r10
00007d3d13bdbfb2  push r11
00007d3d13bdbfb4  sub rsp, 0xF0
00007d3d13bdbfbb  vmovaps [rsp], xmm0
00007d3d13bdbfc0  vmovaps [rsp+0x10], xmm1
00007d3d13bdbfc6  vmovaps [rsp+0x20], xmm2
00007d3d13bdbfcc  vmovaps [rsp+0x30], xmm3
00007d3d13bdbfd2  vmovaps [rsp+0x40], xmm4
00007d3d13bdbfd8  vmovaps [rsp+0x50], xmm5
00007d3d13bdbfde  vmovaps [rsp+0x60], xmm6
00007d3d13bdbfe4  vmovaps [rsp+0x70], xmm7
00007d3d13bdbfea  vmovaps [rsp+0x80], xmm8
00007d3d13bdbff3  vmovaps [rsp+0x90], xmm10
00007d3d13bdbffc  vmovaps [rsp+0xA0], xmm11
00007d3d13bdc005  vmovaps [rsp+0xB0], xmm12
00007d3d13bdc00e  vmovaps [rsp+0xC0], xmm13
00007d3d13bdc017  vmovaps [rsp+0xD0], xmm14
00007d3d13bdc020  vmovaps [rsp+0xE0], xmm15
00007d3d13bdc029  sub rsp, 0x30
00007d3d13bdc02d  movaps [rsp], xmm9
00007d3d13bdc032  movaps [rsp+0x10], xmm2
00007d3d13bdc037  movaps [rsp+0x20], xmm1
00007d3d13bdc03c  lea rdi, [rsp]
00007d3d13bdc040  mov esi, 0x00
00007d3d13bdc045  mov rax, 0x5741DAFC8530
00007d3d13bdc04f  call rax
00007d3d13bdc051  movaps xmm9, [rsp]
00007d3d13bdc056  add rsp, 0x30
00007d3d13bdc05a  vmovaps xmm0, [rsp]
00007d3d13bdc05f  vmovaps xmm1, [rsp+0x10]
00007d3d13bdc065  vmovaps xmm2, [rsp+0x20]
00007d3d13bdc06b  vmovaps xmm3, [rsp+0x30]
00007d3d13bdc071  vmovaps xmm4, [rsp+0x40]
00007d3d13bdc077  vmovaps xmm5, [rsp+0x50]
00007d3d13bdc07d  vmovaps xmm6, [rsp+0x60]
00007d3d13bdc083  vmovaps xmm7, [rsp+0x70]
00007d3d13bdc089  vmovaps xmm8, [rsp+0x80]
00007d3d13bdc092  vmovaps xmm10, [rsp+0x90]
00007d3d13bdc09b  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdc0a4  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdc0ad  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdc0b6  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdc0bf  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdc0c8  add rsp, 0xF0
00007d3d13bdc0cf  pop r11
00007d3d13bdc0d1  pop r10
00007d3d13bdc0d3  pop r9
00007d3d13bdc0d5  pop r8
00007d3d13bdc0d7  pop rsi
00007d3d13bdc0d8  pop rdi
00007d3d13bdc0d9  pop rdx
00007d3d13bdc0da  pop rcx
00007d3d13bdc0db  pop rax
00007d3d13bdc0dc  add rsp, 0x08
00007d3d13bdc0e0  jmp 0x00007D3D13BD9381
00007d3d13bdc0e5  sub rsp, 0x08
00007d3d13bdc0e9  push rax
00007d3d13bdc0ea  push rcx
00007d3d13bdc0eb  push rdx
00007d3d13bdc0ec  push rdi
00007d3d13bdc0ed  push rsi
00007d3d13bdc0ee  push r8
00007d3d13bdc0f0  push r9
00007d3d13bdc0f2  push r10
00007d3d13bdc0f4  push r11
00007d3d13bdc0f6  sub rsp, 0xF0
00007d3d13bdc0fd  vmovaps [rsp], xmm0
00007d3d13bdc102  vmovaps [rsp+0x10], xmm2
00007d3d13bdc108  vmovaps [rsp+0x20], xmm3
00007d3d13bdc10e  vmovaps [rsp+0x30], xmm4
00007d3d13bdc114  vmovaps [rsp+0x40], xmm5
00007d3d13bdc11a  vmovaps [rsp+0x50], xmm6
00007d3d13bdc120  vmovaps [rsp+0x60], xmm7
00007d3d13bdc126  vmovaps [rsp+0x70], xmm8
00007d3d13bdc12c  vmovaps [rsp+0x80], xmm9
00007d3d13bdc135  vmovaps [rsp+0x90], xmm10
00007d3d13bdc13e  vmovaps [rsp+0xA0], xmm11
00007d3d13bdc147  vmovaps [rsp+0xB0], xmm12
00007d3d13bdc150  vmovaps [rsp+0xC0], xmm13
00007d3d13bdc159  vmovaps [rsp+0xD0], xmm14
00007d3d13bdc162  vmovaps [rsp+0xE0], xmm15
00007d3d13bdc16b  sub rsp, 0x30
00007d3d13bdc16f  movaps [rsp], xmm1
00007d3d13bdc173  movaps [rsp+0x10], xmm15
00007d3d13bdc179  movaps [rsp+0x20], xmm6
00007d3d13bdc17e  lea rdi, [rsp]
00007d3d13bdc182  mov esi, 0x00
00007d3d13bdc187  mov rax, 0x5741DAFC8530
00007d3d13bdc191  call rax
00007d3d13bdc193  movaps xmm1, [rsp]
00007d3d13bdc197  add rsp, 0x30
00007d3d13bdc19b  vmovaps xmm0, [rsp]
00007d3d13bdc1a0  vmovaps xmm2, [rsp+0x10]
00007d3d13bdc1a6  vmovaps xmm3, [rsp+0x20]
00007d3d13bdc1ac  vmovaps xmm4, [rsp+0x30]
00007d3d13bdc1b2  vmovaps xmm5, [rsp+0x40]
00007d3d13bdc1b8  vmovaps xmm6, [rsp+0x50]
00007d3d13bdc1be  vmovaps xmm7, [rsp+0x60]
00007d3d13bdc1c4  vmovaps xmm8, [rsp+0x70]
00007d3d13bdc1ca  vmovaps xmm9, [rsp+0x80]
00007d3d13bdc1d3  vmovaps xmm10, [rsp+0x90]
00007d3d13bdc1dc  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdc1e5  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdc1ee  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdc1f7  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdc200  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdc209  add rsp, 0xF0
00007d3d13bdc210  pop r11
00007d3d13bdc212  pop r10
00007d3d13bdc214  pop r9
00007d3d13bdc216  pop r8
00007d3d13bdc218  pop rsi
00007d3d13bdc219  pop rdi
00007d3d13bdc21a  pop rdx
00007d3d13bdc21b  pop rcx
00007d3d13bdc21c  pop rax
00007d3d13bdc21d  add rsp, 0x08
00007d3d13bdc221  jmp 0x00007D3D13BD93A2
00007d3d13bdc226  sub rsp, 0x08
00007d3d13bdc22a  push rax
00007d3d13bdc22b  push rcx
00007d3d13bdc22c  push rdx
00007d3d13bdc22d  push rdi
00007d3d13bdc22e  push rsi
00007d3d13bdc22f  push r8
00007d3d13bdc231  push r9
00007d3d13bdc233  push r10
00007d3d13bdc235  push r11
00007d3d13bdc237  sub rsp, 0xF0
00007d3d13bdc23e  vmovaps [rsp], xmm0
00007d3d13bdc243  vmovaps [rsp+0x10], xmm1
00007d3d13bdc249  vmovaps [rsp+0x20], xmm2
00007d3d13bdc24f  vmovaps [rsp+0x30], xmm3
00007d3d13bdc255  vmovaps [rsp+0x40], xmm4
00007d3d13bdc25b  vmovaps [rsp+0x50], xmm5
00007d3d13bdc261  vmovaps [rsp+0x60], xmm6
00007d3d13bdc267  vmovaps [rsp+0x70], xmm7
00007d3d13bdc26d  vmovaps [rsp+0x80], xmm8
00007d3d13bdc276  vmovaps [rsp+0x90], xmm9
00007d3d13bdc27f  vmovaps [rsp+0xA0], xmm10
00007d3d13bdc288  vmovaps [rsp+0xB0], xmm11
00007d3d13bdc291  vmovaps [rsp+0xC0], xmm12
00007d3d13bdc29a  vmovaps [rsp+0xD0], xmm13
00007d3d13bdc2a3  vmovaps [rsp+0xE0], xmm14
00007d3d13bdc2ac  sub rsp, 0x30
00007d3d13bdc2b0  movaps [rsp], xmm15
00007d3d13bdc2b5  movaps [rsp+0x10], xmm5
00007d3d13bdc2ba  movaps [rsp+0x20], xmm3
00007d3d13bdc2bf  lea rdi, [rsp]
00007d3d13bdc2c3  mov esi, 0x00
00007d3d13bdc2c8  mov rax, 0x5741DAFC8530
00007d3d13bdc2d2  call rax
00007d3d13bdc2d4  movaps xmm15, [rsp]
00007d3d13bdc2d9  add rsp, 0x30
00007d3d13bdc2dd  vmovaps xmm0, [rsp]
00007d3d13bdc2e2  vmovaps xmm1, [rsp+0x10]
00007d3d13bdc2e8  vmovaps xmm2, [rsp+0x20]
00007d3d13bdc2ee  vmovaps xmm3, [rsp+0x30]
00007d3d13bdc2f4  vmovaps xmm4, [rsp+0x40]
00007d3d13bdc2fa  vmovaps xmm5, [rsp+0x50]
00007d3d13bdc300  vmovaps xmm6, [rsp+0x60]
00007d3d13bdc306  vmovaps xmm7, [rsp+0x70]
00007d3d13bdc30c  vmovaps xmm8, [rsp+0x80]
00007d3d13bdc315  vmovaps xmm9, [rsp+0x90]
00007d3d13bdc31e  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdc327  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdc330  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdc339  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdc342  vmovaps xmm14, [rsp+0xE0]
00007d3d13bdc34b  add rsp, 0xF0
00007d3d13bdc352  pop r11
00007d3d13bdc354  pop r10
00007d3d13bdc356  pop r9
00007d3d13bdc358  pop r8
00007d3d13bdc35a  pop rsi
00007d3d13bdc35b  pop rdi
00007d3d13bdc35c  pop rdx
00007d3d13bdc35d  pop rcx
00007d3d13bdc35e  pop rax
00007d3d13bdc35f  add rsp, 0x08
00007d3d13bdc363  jmp 0x00007D3D13BD93BC
00007d3d13bdc368  sub rsp, 0x08
00007d3d13bdc36c  push rax
00007d3d13bdc36d  push rcx
00007d3d13bdc36e  push rdx
00007d3d13bdc36f  push rdi
00007d3d13bdc370  push rsi
00007d3d13bdc371  push r8
00007d3d13bdc373  push r9
00007d3d13bdc375  push r10
00007d3d13bdc377  push r11
00007d3d13bdc379  sub rsp, 0xF0
00007d3d13bdc380  vmovaps [rsp], xmm0
00007d3d13bdc385  vmovaps [rsp+0x10], xmm1
00007d3d13bdc38b  vmovaps [rsp+0x20], xmm2
00007d3d13bdc391  vmovaps [rsp+0x30], xmm3
00007d3d13bdc397  vmovaps [rsp+0x40], xmm4
00007d3d13bdc39d  vmovaps [rsp+0x50], xmm6
00007d3d13bdc3a3  vmovaps [rsp+0x60], xmm7
00007d3d13bdc3a9  vmovaps [rsp+0x70], xmm8
00007d3d13bdc3af  vmovaps [rsp+0x80], xmm9
00007d3d13bdc3b8  vmovaps [rsp+0x90], xmm10
00007d3d13bdc3c1  vmovaps [rsp+0xA0], xmm11
00007d3d13bdc3ca  vmovaps [rsp+0xB0], xmm12
00007d3d13bdc3d3  vmovaps [rsp+0xC0], xmm13
00007d3d13bdc3dc  vmovaps [rsp+0xD0], xmm14
00007d3d13bdc3e5  vmovaps [rsp+0xE0], xmm15
00007d3d13bdc3ee  sub rsp, 0x30
00007d3d13bdc3f2  movaps [rsp], xmm5
00007d3d13bdc3f6  movaps [rsp+0x10], xmm8
00007d3d13bdc3fc  movaps [rsp+0x20], xmm6
00007d3d13bdc401  lea rdi, [rsp]
00007d3d13bdc405  mov esi, 0x00
00007d3d13bdc40a  mov rax, 0x5741DAFC8530
00007d3d13bdc414  call rax
00007d3d13bdc416  movaps xmm5, [rsp]
00007d3d13bdc41a  add rsp, 0x30
00007d3d13bdc41e  vmovaps xmm0, [rsp]
00007d3d13bdc423  vmovaps xmm1, [rsp+0x10]
00007d3d13bdc429  vmovaps xmm2, [rsp+0x20]
00007d3d13bdc42f  vmovaps xmm3, [rsp+0x30]
00007d3d13bdc435  vmovaps xmm4, [rsp+0x40]
00007d3d13bdc43b  vmovaps xmm6, [rsp+0x50]
00007d3d13bdc441  vmovaps xmm7, [rsp+0x60]
00007d3d13bdc447  vmovaps xmm8, [rsp+0x70]
00007d3d13bdc44d  vmovaps xmm9, [rsp+0x80]
00007d3d13bdc456  vmovaps xmm10, [rsp+0x90]
00007d3d13bdc45f  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdc468  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdc471  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdc47a  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdc483  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdc48c  add rsp, 0xF0
00007d3d13bdc493  pop r11
00007d3d13bdc495  pop r10
00007d3d13bdc497  pop r9
00007d3d13bdc499  pop r8
00007d3d13bdc49b  pop rsi
00007d3d13bdc49c  pop rdi
00007d3d13bdc49d  pop rdx
00007d3d13bdc49e  pop rcx
00007d3d13bdc49f  pop rax
00007d3d13bdc4a0  add rsp, 0x08
00007d3d13bdc4a4  jmp 0x00007D3D13BD93E0
00007d3d13bdc4a9  sub rsp, 0x08
00007d3d13bdc4ad  push rax
00007d3d13bdc4ae  push rcx
00007d3d13bdc4af  push rdx
00007d3d13bdc4b0  push rdi
00007d3d13bdc4b1  push rsi
00007d3d13bdc4b2  push r8
00007d3d13bdc4b4  push r9
00007d3d13bdc4b6  push r10
00007d3d13bdc4b8  push r11
00007d3d13bdc4ba  sub rsp, 0xF0
00007d3d13bdc4c1  vmovaps [rsp], xmm0
00007d3d13bdc4c6  vmovaps [rsp+0x10], xmm1
00007d3d13bdc4cc  vmovaps [rsp+0x20], xmm2
00007d3d13bdc4d2  vmovaps [rsp+0x30], xmm3
00007d3d13bdc4d8  vmovaps [rsp+0x40], xmm4
00007d3d13bdc4de  vmovaps [rsp+0x50], xmm5
00007d3d13bdc4e4  vmovaps [rsp+0x60], xmm7
00007d3d13bdc4ea  vmovaps [rsp+0x70], xmm8
00007d3d13bdc4f0  vmovaps [rsp+0x80], xmm9
00007d3d13bdc4f9  vmovaps [rsp+0x90], xmm10
00007d3d13bdc502  vmovaps [rsp+0xA0], xmm11
00007d3d13bdc50b  vmovaps [rsp+0xB0], xmm12
00007d3d13bdc514  vmovaps [rsp+0xC0], xmm13
00007d3d13bdc51d  vmovaps [rsp+0xD0], xmm14
00007d3d13bdc526  vmovaps [rsp+0xE0], xmm15
00007d3d13bdc52f  sub rsp, 0x30
00007d3d13bdc533  movaps [rsp], xmm6
00007d3d13bdc537  movaps [rsp+0x10], xmm10
00007d3d13bdc53d  movaps [rsp+0x20], xmm8
00007d3d13bdc543  lea rdi, [rsp]
00007d3d13bdc547  mov esi, 0x00
00007d3d13bdc54c  mov rax, 0x5741DAFC8530
00007d3d13bdc556  call rax
00007d3d13bdc558  movaps xmm6, [rsp]
00007d3d13bdc55c  add rsp, 0x30
00007d3d13bdc560  vmovaps xmm0, [rsp]
00007d3d13bdc565  vmovaps xmm1, [rsp+0x10]
00007d3d13bdc56b  vmovaps xmm2, [rsp+0x20]
00007d3d13bdc571  vmovaps xmm3, [rsp+0x30]
00007d3d13bdc577  vmovaps xmm4, [rsp+0x40]
00007d3d13bdc57d  vmovaps xmm5, [rsp+0x50]
00007d3d13bdc583  vmovaps xmm7, [rsp+0x60]
00007d3d13bdc589  vmovaps xmm8, [rsp+0x70]
00007d3d13bdc58f  vmovaps xmm9, [rsp+0x80]
00007d3d13bdc598  vmovaps xmm10, [rsp+0x90]
00007d3d13bdc5a1  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdc5aa  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdc5b3  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdc5bc  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdc5c5  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdc5ce  add rsp, 0xF0
00007d3d13bdc5d5  pop r11
00007d3d13bdc5d7  pop r10
00007d3d13bdc5d9  pop r9
00007d3d13bdc5db  pop r8
00007d3d13bdc5dd  pop rsi
00007d3d13bdc5de  pop rdi
00007d3d13bdc5df  pop rdx
00007d3d13bdc5e0  pop rcx
00007d3d13bdc5e1  pop rax
00007d3d13bdc5e2  add rsp, 0x08
00007d3d13bdc5e6  jmp 0x00007D3D13BD9405
00007d3d13bdc5eb  sub rsp, 0x08
00007d3d13bdc5ef  push rax
00007d3d13bdc5f0  push rcx
00007d3d13bdc5f1  push rdx
00007d3d13bdc5f2  push rdi
00007d3d13bdc5f3  push rsi
00007d3d13bdc5f4  push r8
00007d3d13bdc5f6  push r9
00007d3d13bdc5f8  push r10
00007d3d13bdc5fa  push r11
00007d3d13bdc5fc  sub rsp, 0xF0
00007d3d13bdc603  vmovaps [rsp], xmm0
00007d3d13bdc608  vmovaps [rsp+0x10], xmm1
00007d3d13bdc60e  vmovaps [rsp+0x20], xmm2
00007d3d13bdc614  vmovaps [rsp+0x30], xmm3
00007d3d13bdc61a  vmovaps [rsp+0x40], xmm4
00007d3d13bdc620  vmovaps [rsp+0x50], xmm5
00007d3d13bdc626  vmovaps [rsp+0x60], xmm6
00007d3d13bdc62c  vmovaps [rsp+0x70], xmm7
00007d3d13bdc632  vmovaps [rsp+0x80], xmm8
00007d3d13bdc63b  vmovaps [rsp+0x90], xmm9
00007d3d13bdc644  vmovaps [rsp+0xA0], xmm11
00007d3d13bdc64d  vmovaps [rsp+0xB0], xmm12
00007d3d13bdc656  vmovaps [rsp+0xC0], xmm13
00007d3d13bdc65f  vmovaps [rsp+0xD0], xmm14
00007d3d13bdc668  vmovaps [rsp+0xE0], xmm15
00007d3d13bdc671  sub rsp, 0x30
00007d3d13bdc675  movaps [rsp], xmm10
00007d3d13bdc67a  movaps [rsp+0x10], xmm8
00007d3d13bdc680  movaps [rsp+0x20], xmm14
00007d3d13bdc686  lea rdi, [rsp]
00007d3d13bdc68a  mov esi, 0x00
00007d3d13bdc68f  mov rax, 0x5741DAFC8530
00007d3d13bdc699  call rax
00007d3d13bdc69b  movaps xmm10, [rsp]
00007d3d13bdc6a0  add rsp, 0x30
00007d3d13bdc6a4  vmovaps xmm0, [rsp]
00007d3d13bdc6a9  vmovaps xmm1, [rsp+0x10]
00007d3d13bdc6af  vmovaps xmm2, [rsp+0x20]
00007d3d13bdc6b5  vmovaps xmm3, [rsp+0x30]
00007d3d13bdc6bb  vmovaps xmm4, [rsp+0x40]
00007d3d13bdc6c1  vmovaps xmm5, [rsp+0x50]
00007d3d13bdc6c7  vmovaps xmm6, [rsp+0x60]
00007d3d13bdc6cd  vmovaps xmm7, [rsp+0x70]
00007d3d13bdc6d3  vmovaps xmm8, [rsp+0x80]
00007d3d13bdc6dc  vmovaps xmm9, [rsp+0x90]
00007d3d13bdc6e5  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdc6ee  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdc6f7  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdc700  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdc709  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdc712  add rsp, 0xF0
00007d3d13bdc719  pop r11
00007d3d13bdc71b  pop r10
00007d3d13bdc71d  pop r9
00007d3d13bdc71f  pop r8
00007d3d13bdc721  pop rsi
00007d3d13bdc722  pop rdi
00007d3d13bdc723  pop rdx
00007d3d13bdc724  pop rcx
00007d3d13bdc725  pop rax
00007d3d13bdc726  add rsp, 0x08
00007d3d13bdc72a  jmp 0x00007D3D13BD9425
00007d3d13bdc72f  sub rsp, 0x08
00007d3d13bdc733  push rax
00007d3d13bdc734  push rcx
00007d3d13bdc735  push rdx
00007d3d13bdc736  push rdi
00007d3d13bdc737  push rsi
00007d3d13bdc738  push r8
00007d3d13bdc73a  push r9
00007d3d13bdc73c  push r10
00007d3d13bdc73e  push r11
00007d3d13bdc740  sub rsp, 0xF0
00007d3d13bdc747  vmovaps [rsp], xmm0
00007d3d13bdc74c  vmovaps [rsp+0x10], xmm1
00007d3d13bdc752  vmovaps [rsp+0x20], xmm2
00007d3d13bdc758  vmovaps [rsp+0x30], xmm3
00007d3d13bdc75e  vmovaps [rsp+0x40], xmm4
00007d3d13bdc764  vmovaps [rsp+0x50], xmm5
00007d3d13bdc76a  vmovaps [rsp+0x60], xmm6
00007d3d13bdc770  vmovaps [rsp+0x70], xmm7
00007d3d13bdc776  vmovaps [rsp+0x80], xmm8
00007d3d13bdc77f  vmovaps [rsp+0x90], xmm9
00007d3d13bdc788  vmovaps [rsp+0xA0], xmm10
00007d3d13bdc791  vmovaps [rsp+0xB0], xmm11
00007d3d13bdc79a  vmovaps [rsp+0xC0], xmm12
00007d3d13bdc7a3  vmovaps [rsp+0xD0], xmm13
00007d3d13bdc7ac  vmovaps [rsp+0xE0], xmm15
00007d3d13bdc7b5  sub rsp, 0x30
00007d3d13bdc7b9  movaps [rsp], xmm14
00007d3d13bdc7be  movaps [rsp+0x10], xmm8
00007d3d13bdc7c4  movaps [rsp+0x20], xmm4
00007d3d13bdc7c9  lea rdi, [rsp]
00007d3d13bdc7cd  mov esi, 0x00
00007d3d13bdc7d2  mov rax, 0x5741DAFC8530
00007d3d13bdc7dc  call rax
00007d3d13bdc7de  movaps xmm14, [rsp]
00007d3d13bdc7e3  add rsp, 0x30
00007d3d13bdc7e7  vmovaps xmm0, [rsp]
00007d3d13bdc7ec  vmovaps xmm1, [rsp+0x10]
00007d3d13bdc7f2  vmovaps xmm2, [rsp+0x20]
00007d3d13bdc7f8  vmovaps xmm3, [rsp+0x30]
00007d3d13bdc7fe  vmovaps xmm4, [rsp+0x40]
00007d3d13bdc804  vmovaps xmm5, [rsp+0x50]
00007d3d13bdc80a  vmovaps xmm6, [rsp+0x60]
00007d3d13bdc810  vmovaps xmm7, [rsp+0x70]
00007d3d13bdc816  vmovaps xmm8, [rsp+0x80]
00007d3d13bdc81f  vmovaps xmm9, [rsp+0x90]
00007d3d13bdc828  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdc831  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdc83a  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdc843  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdc84c  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdc855  add rsp, 0xF0
00007d3d13bdc85c  pop r11
00007d3d13bdc85e  pop r10
00007d3d13bdc860  pop r9
00007d3d13bdc862  pop r8
00007d3d13bdc864  pop rsi
00007d3d13bdc865  pop rdi
00007d3d13bdc866  pop rdx
00007d3d13bdc867  pop rcx
00007d3d13bdc868  pop rax
00007d3d13bdc869  add rsp, 0x08
00007d3d13bdc86d  jmp 0x00007D3D13BD9445
00007d3d13bdc872  sub rsp, 0x08
00007d3d13bdc876  push rax
00007d3d13bdc877  push rcx
00007d3d13bdc878  push rdx
00007d3d13bdc879  push rdi
00007d3d13bdc87a  push rsi
00007d3d13bdc87b  push r8
00007d3d13bdc87d  push r9
00007d3d13bdc87f  push r10
00007d3d13bdc881  push r11
00007d3d13bdc883  sub rsp, 0xF0
00007d3d13bdc88a  vmovaps [rsp], xmm0
00007d3d13bdc88f  vmovaps [rsp+0x10], xmm1
00007d3d13bdc895  vmovaps [rsp+0x20], xmm2
00007d3d13bdc89b  vmovaps [rsp+0x30], xmm3
00007d3d13bdc8a1  vmovaps [rsp+0x40], xmm5
00007d3d13bdc8a7  vmovaps [rsp+0x50], xmm6
00007d3d13bdc8ad  vmovaps [rsp+0x60], xmm7
00007d3d13bdc8b3  vmovaps [rsp+0x70], xmm8
00007d3d13bdc8b9  vmovaps [rsp+0x80], xmm9
00007d3d13bdc8c2  vmovaps [rsp+0x90], xmm10
00007d3d13bdc8cb  vmovaps [rsp+0xA0], xmm11
00007d3d13bdc8d4  vmovaps [rsp+0xB0], xmm12
00007d3d13bdc8dd  vmovaps [rsp+0xC0], xmm13
00007d3d13bdc8e6  vmovaps [rsp+0xD0], xmm14
00007d3d13bdc8ef  vmovaps [rsp+0xE0], xmm15
00007d3d13bdc8f8  sub rsp, 0x30
00007d3d13bdc8fc  movaps [rsp], xmm4
00007d3d13bdc900  movaps [rsp+0x10], xmm13
00007d3d13bdc906  movaps [rsp+0x20], xmm8
00007d3d13bdc90c  lea rdi, [rsp]
00007d3d13bdc910  mov esi, 0x00
00007d3d13bdc915  mov rax, 0x5741DAFC8530
00007d3d13bdc91f  call rax
00007d3d13bdc921  movaps xmm4, [rsp]
00007d3d13bdc925  add rsp, 0x30
00007d3d13bdc929  vmovaps xmm0, [rsp]
00007d3d13bdc92e  vmovaps xmm1, [rsp+0x10]
00007d3d13bdc934  vmovaps xmm2, [rsp+0x20]
00007d3d13bdc93a  vmovaps xmm3, [rsp+0x30]
00007d3d13bdc940  vmovaps xmm5, [rsp+0x40]
00007d3d13bdc946  vmovaps xmm6, [rsp+0x50]
00007d3d13bdc94c  vmovaps xmm7, [rsp+0x60]
00007d3d13bdc952  vmovaps xmm8, [rsp+0x70]
00007d3d13bdc958  vmovaps xmm9, [rsp+0x80]
00007d3d13bdc961  vmovaps xmm10, [rsp+0x90]
00007d3d13bdc96a  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdc973  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdc97c  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdc985  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdc98e  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdc997  add rsp, 0xF0
00007d3d13bdc99e  pop r11
00007d3d13bdc9a0  pop r10
00007d3d13bdc9a2  pop r9
00007d3d13bdc9a4  pop r8
00007d3d13bdc9a6  pop rsi
00007d3d13bdc9a7  pop rdi
00007d3d13bdc9a8  pop rdx
00007d3d13bdc9a9  pop rcx
00007d3d13bdc9aa  pop rax
00007d3d13bdc9ab  add rsp, 0x08
00007d3d13bdc9af  jmp 0x00007D3D13BD946A
00007d3d13bdc9b4  sub rsp, 0x08
00007d3d13bdc9b8  push rax
00007d3d13bdc9b9  push rcx
00007d3d13bdc9ba  push rdx
00007d3d13bdc9bb  push rdi
00007d3d13bdc9bc  push rsi
00007d3d13bdc9bd  push r8
00007d3d13bdc9bf  push r9
00007d3d13bdc9c1  push r10
00007d3d13bdc9c3  push r11
00007d3d13bdc9c5  sub rsp, 0xF0
00007d3d13bdc9cc  vmovaps [rsp], xmm0
00007d3d13bdc9d1  vmovaps [rsp+0x10], xmm1
00007d3d13bdc9d7  vmovaps [rsp+0x20], xmm2
00007d3d13bdc9dd  vmovaps [rsp+0x30], xmm3
00007d3d13bdc9e3  vmovaps [rsp+0x40], xmm4
00007d3d13bdc9e9  vmovaps [rsp+0x50], xmm5
00007d3d13bdc9ef  vmovaps [rsp+0x60], xmm6
00007d3d13bdc9f5  vmovaps [rsp+0x70], xmm7
00007d3d13bdc9fb  vmovaps [rsp+0x80], xmm8
00007d3d13bdca04  vmovaps [rsp+0x90], xmm9
00007d3d13bdca0d  vmovaps [rsp+0xA0], xmm10
00007d3d13bdca16  vmovaps [rsp+0xB0], xmm11
00007d3d13bdca1f  vmovaps [rsp+0xC0], xmm12
00007d3d13bdca28  vmovaps [rsp+0xD0], xmm14
00007d3d13bdca31  vmovaps [rsp+0xE0], xmm15
00007d3d13bdca3a  sub rsp, 0x30
00007d3d13bdca3e  movaps [rsp], xmm13
00007d3d13bdca43  movaps [rsp+0x10], xmm15
00007d3d13bdca49  movaps [rsp+0x20], xmm9
00007d3d13bdca4f  lea rdi, [rsp]
00007d3d13bdca53  mov esi, 0x00
00007d3d13bdca58  mov rax, 0x5741DAFC8530
00007d3d13bdca62  call rax
00007d3d13bdca64  movaps xmm13, [rsp]
00007d3d13bdca69  add rsp, 0x30
00007d3d13bdca6d  vmovaps xmm0, [rsp]
00007d3d13bdca72  vmovaps xmm1, [rsp+0x10]
00007d3d13bdca78  vmovaps xmm2, [rsp+0x20]
00007d3d13bdca7e  vmovaps xmm3, [rsp+0x30]
00007d3d13bdca84  vmovaps xmm4, [rsp+0x40]
00007d3d13bdca8a  vmovaps xmm5, [rsp+0x50]
00007d3d13bdca90  vmovaps xmm6, [rsp+0x60]
00007d3d13bdca96  vmovaps xmm7, [rsp+0x70]
00007d3d13bdca9c  vmovaps xmm8, [rsp+0x80]
00007d3d13bdcaa5  vmovaps xmm9, [rsp+0x90]
00007d3d13bdcaae  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdcab7  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdcac0  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdcac9  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdcad2  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdcadb  add rsp, 0xF0
00007d3d13bdcae2  pop r11
00007d3d13bdcae4  pop r10
00007d3d13bdcae6  pop r9
00007d3d13bdcae8  pop r8
00007d3d13bdcaea  pop rsi
00007d3d13bdcaeb  pop rdi
00007d3d13bdcaec  pop rdx
00007d3d13bdcaed  pop rcx
00007d3d13bdcaee  pop rax
00007d3d13bdcaef  add rsp, 0x08
00007d3d13bdcaf3  jmp 0x00007D3D13BD9485
00007d3d13bdcaf8  sub rsp, 0x08
00007d3d13bdcafc  push rax
00007d3d13bdcafd  push rcx
00007d3d13bdcafe  push rdx
00007d3d13bdcaff  push rdi
00007d3d13bdcb00  push rsi
00007d3d13bdcb01  push r8
00007d3d13bdcb03  push r9
00007d3d13bdcb05  push r10
00007d3d13bdcb07  push r11
00007d3d13bdcb09  sub rsp, 0xF0
00007d3d13bdcb10  vmovaps [rsp], xmm0
00007d3d13bdcb15  vmovaps [rsp+0x10], xmm1
00007d3d13bdcb1b  vmovaps [rsp+0x20], xmm2
00007d3d13bdcb21  vmovaps [rsp+0x30], xmm3
00007d3d13bdcb27  vmovaps [rsp+0x40], xmm4
00007d3d13bdcb2d  vmovaps [rsp+0x50], xmm5
00007d3d13bdcb33  vmovaps [rsp+0x60], xmm6
00007d3d13bdcb39  vmovaps [rsp+0x70], xmm7
00007d3d13bdcb3f  vmovaps [rsp+0x80], xmm8
00007d3d13bdcb48  vmovaps [rsp+0x90], xmm9
00007d3d13bdcb51  vmovaps [rsp+0xA0], xmm10
00007d3d13bdcb5a  vmovaps [rsp+0xB0], xmm11
00007d3d13bdcb63  vmovaps [rsp+0xC0], xmm12
00007d3d13bdcb6c  vmovaps [rsp+0xD0], xmm13
00007d3d13bdcb75  vmovaps [rsp+0xE0], xmm14
00007d3d13bdcb7e  sub rsp, 0x30
00007d3d13bdcb82  movaps [rsp], xmm15
00007d3d13bdcb87  movaps [rsp+0x10], xmm1
00007d3d13bdcb8c  movaps [rsp+0x20], xmm5
00007d3d13bdcb91  lea rdi, [rsp]
00007d3d13bdcb95  mov esi, 0x00
00007d3d13bdcb9a  mov rax, 0x5741DAFC8530
00007d3d13bdcba4  call rax
00007d3d13bdcba6  movaps xmm15, [rsp]
00007d3d13bdcbab  add rsp, 0x30
00007d3d13bdcbaf  vmovaps xmm0, [rsp]
00007d3d13bdcbb4  vmovaps xmm1, [rsp+0x10]
00007d3d13bdcbba  vmovaps xmm2, [rsp+0x20]
00007d3d13bdcbc0  vmovaps xmm3, [rsp+0x30]
00007d3d13bdcbc6  vmovaps xmm4, [rsp+0x40]
00007d3d13bdcbcc  vmovaps xmm5, [rsp+0x50]
00007d3d13bdcbd2  vmovaps xmm6, [rsp+0x60]
00007d3d13bdcbd8  vmovaps xmm7, [rsp+0x70]
00007d3d13bdcbde  vmovaps xmm8, [rsp+0x80]
00007d3d13bdcbe7  vmovaps xmm9, [rsp+0x90]
00007d3d13bdcbf0  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdcbf9  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdcc02  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdcc0b  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdcc14  vmovaps xmm14, [rsp+0xE0]
00007d3d13bdcc1d  add rsp, 0xF0
00007d3d13bdcc24  pop r11
00007d3d13bdcc26  pop r10
00007d3d13bdcc28  pop r9
00007d3d13bdcc2a  pop r8
00007d3d13bdcc2c  pop rsi
00007d3d13bdcc2d  pop rdi
00007d3d13bdcc2e  pop rdx
00007d3d13bdcc2f  pop rcx
00007d3d13bdcc30  pop rax
00007d3d13bdcc31  add rsp, 0x08
00007d3d13bdcc35  jmp 0x00007D3D13BD94A0
00007d3d13bdcc3a  call 0x00007D3D13AD64F0
00007d3d13bdcc3f  jmp 0x00007D3D13BD94FB
00007d3d13bdcc44  sub rsp, 0x08
00007d3d13bdcc48  push rax
00007d3d13bdcc49  push rcx
00007d3d13bdcc4a  push rdx
00007d3d13bdcc4b  push rdi
00007d3d13bdcc4c  push rsi
00007d3d13bdcc4d  push r8
00007d3d13bdcc4f  push r9
00007d3d13bdcc51  push r10
00007d3d13bdcc53  push r11
00007d3d13bdcc55  sub rsp, 0xF0
00007d3d13bdcc5c  vmovaps [rsp], xmm0
00007d3d13bdcc61  vmovaps [rsp+0x10], xmm1
00007d3d13bdcc67  vmovaps [rsp+0x20], xmm2
00007d3d13bdcc6d  vmovaps [rsp+0x30], xmm3
00007d3d13bdcc73  vmovaps [rsp+0x40], xmm4
00007d3d13bdcc79  vmovaps [rsp+0x50], xmm5
00007d3d13bdcc7f  vmovaps [rsp+0x60], xmm6
00007d3d13bdcc85  vmovaps [rsp+0x70], xmm7
00007d3d13bdcc8b  vmovaps [rsp+0x80], xmm8
00007d3d13bdcc94  vmovaps [rsp+0x90], xmm10
00007d3d13bdcc9d  vmovaps [rsp+0xA0], xmm11
00007d3d13bdcca6  vmovaps [rsp+0xB0], xmm12
00007d3d13bdccaf  vmovaps [rsp+0xC0], xmm13
00007d3d13bdccb8  vmovaps [rsp+0xD0], xmm14
00007d3d13bdccc1  vmovaps [rsp+0xE0], xmm15
00007d3d13bdccca  sub rsp, 0x30
00007d3d13bdccce  movaps [rsp], xmm9
00007d3d13bdccd3  movaps [rsp+0x10], xmm8
00007d3d13bdccd9  movaps [rsp+0x20], xmm11
00007d3d13bdccdf  lea rdi, [rsp]
00007d3d13bdcce3  mov esi, 0x00
00007d3d13bdcce8  mov rax, 0x5741DAFC8530
00007d3d13bdccf2  call rax
00007d3d13bdccf4  movaps xmm9, [rsp]
00007d3d13bdccf9  add rsp, 0x30
00007d3d13bdccfd  vmovaps xmm0, [rsp]
00007d3d13bdcd02  vmovaps xmm1, [rsp+0x10]
00007d3d13bdcd08  vmovaps xmm2, [rsp+0x20]
00007d3d13bdcd0e  vmovaps xmm3, [rsp+0x30]
00007d3d13bdcd14  vmovaps xmm4, [rsp+0x40]
00007d3d13bdcd1a  vmovaps xmm5, [rsp+0x50]
00007d3d13bdcd20  vmovaps xmm6, [rsp+0x60]
00007d3d13bdcd26  vmovaps xmm7, [rsp+0x70]
00007d3d13bdcd2c  vmovaps xmm8, [rsp+0x80]
00007d3d13bdcd35  vmovaps xmm10, [rsp+0x90]
00007d3d13bdcd3e  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdcd47  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdcd50  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdcd59  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdcd62  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdcd6b  add rsp, 0xF0
00007d3d13bdcd72  pop r11
00007d3d13bdcd74  pop r10
00007d3d13bdcd76  pop r9
00007d3d13bdcd78  pop r8
00007d3d13bdcd7a  pop rsi
00007d3d13bdcd7b  pop rdi
00007d3d13bdcd7c  pop rdx
00007d3d13bdcd7d  pop rcx
00007d3d13bdcd7e  pop rax
00007d3d13bdcd7f  add rsp, 0x08
00007d3d13bdcd83  jmp 0x00007D3D13BD9532
00007d3d13bdcd88  sub rsp, 0x08
00007d3d13bdcd8c  push rax
00007d3d13bdcd8d  push rcx
00007d3d13bdcd8e  push rdx
00007d3d13bdcd8f  push rdi
00007d3d13bdcd90  push rsi
00007d3d13bdcd91  push r8
00007d3d13bdcd93  push r9
00007d3d13bdcd95  push r10
00007d3d13bdcd97  push r11
00007d3d13bdcd99  sub rsp, 0xF0
00007d3d13bdcda0  vmovaps [rsp], xmm0
00007d3d13bdcda5  vmovaps [rsp+0x10], xmm1
00007d3d13bdcdab  vmovaps [rsp+0x20], xmm2
00007d3d13bdcdb1  vmovaps [rsp+0x30], xmm3
00007d3d13bdcdb7  vmovaps [rsp+0x40], xmm4
00007d3d13bdcdbd  vmovaps [rsp+0x50], xmm5
00007d3d13bdcdc3  vmovaps [rsp+0x60], xmm6
00007d3d13bdcdc9  vmovaps [rsp+0x70], xmm7
00007d3d13bdcdcf  vmovaps [rsp+0x80], xmm8
00007d3d13bdcdd8  vmovaps [rsp+0x90], xmm9
00007d3d13bdcde1  vmovaps [rsp+0xA0], xmm10
00007d3d13bdcdea  vmovaps [rsp+0xB0], xmm12
00007d3d13bdcdf3  vmovaps [rsp+0xC0], xmm13
00007d3d13bdcdfc  vmovaps [rsp+0xD0], xmm14
00007d3d13bdce05  vmovaps [rsp+0xE0], xmm15
00007d3d13bdce0e  sub rsp, 0x30
00007d3d13bdce12  movaps [rsp], xmm11
00007d3d13bdce17  movaps [rsp+0x10], xmm10
00007d3d13bdce1d  movaps [rsp+0x20], xmm6
00007d3d13bdce22  lea rdi, [rsp]
00007d3d13bdce26  mov esi, 0x00
00007d3d13bdce2b  mov rax, 0x5741DAFC8530
00007d3d13bdce35  call rax
00007d3d13bdce37  movaps xmm11, [rsp]
00007d3d13bdce3c  add rsp, 0x30
00007d3d13bdce40  vmovaps xmm0, [rsp]
00007d3d13bdce45  vmovaps xmm1, [rsp+0x10]
00007d3d13bdce4b  vmovaps xmm2, [rsp+0x20]
00007d3d13bdce51  vmovaps xmm3, [rsp+0x30]
00007d3d13bdce57  vmovaps xmm4, [rsp+0x40]
00007d3d13bdce5d  vmovaps xmm5, [rsp+0x50]
00007d3d13bdce63  vmovaps xmm6, [rsp+0x60]
00007d3d13bdce69  vmovaps xmm7, [rsp+0x70]
00007d3d13bdce6f  vmovaps xmm8, [rsp+0x80]
00007d3d13bdce78  vmovaps xmm9, [rsp+0x90]
00007d3d13bdce81  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdce8a  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdce93  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdce9c  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdcea5  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdceae  add rsp, 0xF0
00007d3d13bdceb5  pop r11
00007d3d13bdceb7  pop r10
00007d3d13bdceb9  pop r9
00007d3d13bdcebb  pop r8
00007d3d13bdcebd  pop rsi
00007d3d13bdcebe  pop rdi
00007d3d13bdcebf  pop rdx
00007d3d13bdcec0  pop rcx
00007d3d13bdcec1  pop rax
00007d3d13bdcec2  add rsp, 0x08
00007d3d13bdcec6  jmp 0x00007D3D13BD954D
00007d3d13bdcecb  sub rsp, 0x08
00007d3d13bdcecf  push rax
00007d3d13bdced0  push rcx
00007d3d13bdced1  push rdx
00007d3d13bdced2  push rdi
00007d3d13bdced3  push rsi
00007d3d13bdced4  push r8
00007d3d13bdced6  push r9
00007d3d13bdced8  push r10
00007d3d13bdceda  push r11
00007d3d13bdcedc  sub rsp, 0xF0
00007d3d13bdcee3  vmovaps [rsp], xmm0
00007d3d13bdcee8  vmovaps [rsp+0x10], xmm1
00007d3d13bdceee  vmovaps [rsp+0x20], xmm2
00007d3d13bdcef4  vmovaps [rsp+0x30], xmm3
00007d3d13bdcefa  vmovaps [rsp+0x40], xmm4
00007d3d13bdcf00  vmovaps [rsp+0x50], xmm5
00007d3d13bdcf06  vmovaps [rsp+0x60], xmm6
00007d3d13bdcf0c  vmovaps [rsp+0x70], xmm7
00007d3d13bdcf12  vmovaps [rsp+0x80], xmm8
00007d3d13bdcf1b  vmovaps [rsp+0x90], xmm9
00007d3d13bdcf24  vmovaps [rsp+0xA0], xmm11
00007d3d13bdcf2d  vmovaps [rsp+0xB0], xmm12
00007d3d13bdcf36  vmovaps [rsp+0xC0], xmm13
00007d3d13bdcf3f  vmovaps [rsp+0xD0], xmm14
00007d3d13bdcf48  vmovaps [rsp+0xE0], xmm15
00007d3d13bdcf51  sub rsp, 0x30
00007d3d13bdcf55  movaps [rsp], xmm10
00007d3d13bdcf5a  movaps [rsp+0x10], xmm14
00007d3d13bdcf60  movaps [rsp+0x20], xmm4
00007d3d13bdcf65  lea rdi, [rsp]
00007d3d13bdcf69  mov esi, 0x00
00007d3d13bdcf6e  mov rax, 0x5741DAFC8530
00007d3d13bdcf78  call rax
00007d3d13bdcf7a  movaps xmm10, [rsp]
00007d3d13bdcf7f  add rsp, 0x30
00007d3d13bdcf83  vmovaps xmm0, [rsp]
00007d3d13bdcf88  vmovaps xmm1, [rsp+0x10]
00007d3d13bdcf8e  vmovaps xmm2, [rsp+0x20]
00007d3d13bdcf94  vmovaps xmm3, [rsp+0x30]
00007d3d13bdcf9a  vmovaps xmm4, [rsp+0x40]
00007d3d13bdcfa0  vmovaps xmm5, [rsp+0x50]
00007d3d13bdcfa6  vmovaps xmm6, [rsp+0x60]
00007d3d13bdcfac  vmovaps xmm7, [rsp+0x70]
00007d3d13bdcfb2  vmovaps xmm8, [rsp+0x80]
00007d3d13bdcfbb  vmovaps xmm9, [rsp+0x90]
00007d3d13bdcfc4  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdcfcd  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdcfd6  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdcfdf  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdcfe8  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdcff1  add rsp, 0xF0
00007d3d13bdcff8  pop r11
00007d3d13bdcffa  pop r10
00007d3d13bdcffc  pop r9
00007d3d13bdcffe  pop r8
00007d3d13bdd000  pop rsi
00007d3d13bdd001  pop rdi
00007d3d13bdd002  pop rdx
00007d3d13bdd003  pop rcx
00007d3d13bdd004  pop rax
00007d3d13bdd005  add rsp, 0x08
00007d3d13bdd009  jmp 0x00007D3D13BD9568
00007d3d13bdd00e  sub rsp, 0x08
00007d3d13bdd012  push rax
00007d3d13bdd013  push rcx
00007d3d13bdd014  push rdx
00007d3d13bdd015  push rdi
00007d3d13bdd016  push rsi
00007d3d13bdd017  push r8
00007d3d13bdd019  push r9
00007d3d13bdd01b  push r10
00007d3d13bdd01d  push r11
00007d3d13bdd01f  sub rsp, 0xF0
00007d3d13bdd026  vmovaps [rsp], xmm0
00007d3d13bdd02b  vmovaps [rsp+0x10], xmm1
00007d3d13bdd031  vmovaps [rsp+0x20], xmm2
00007d3d13bdd037  vmovaps [rsp+0x30], xmm3
00007d3d13bdd03d  vmovaps [rsp+0x40], xmm4
00007d3d13bdd043  vmovaps [rsp+0x50], xmm5
00007d3d13bdd049  vmovaps [rsp+0x60], xmm6
00007d3d13bdd04f  vmovaps [rsp+0x70], xmm7
00007d3d13bdd055  vmovaps [rsp+0x80], xmm9
00007d3d13bdd05e  vmovaps [rsp+0x90], xmm10
00007d3d13bdd067  vmovaps [rsp+0xA0], xmm11
00007d3d13bdd070  vmovaps [rsp+0xB0], xmm12
00007d3d13bdd079  vmovaps [rsp+0xC0], xmm13
00007d3d13bdd082  vmovaps [rsp+0xD0], xmm14
00007d3d13bdd08b  vmovaps [rsp+0xE0], xmm15
00007d3d13bdd094  sub rsp, 0x30
00007d3d13bdd098  movaps [rsp], xmm8
00007d3d13bdd09d  movaps [rsp+0x10], xmm1
00007d3d13bdd0a2  movaps [rsp+0x20], xmm14
00007d3d13bdd0a8  lea rdi, [rsp]
00007d3d13bdd0ac  mov esi, 0x00
00007d3d13bdd0b1  mov rax, 0x5741DAFC8530
00007d3d13bdd0bb  call rax
00007d3d13bdd0bd  movaps xmm8, [rsp]
00007d3d13bdd0c2  add rsp, 0x30
00007d3d13bdd0c6  vmovaps xmm0, [rsp]
00007d3d13bdd0cb  vmovaps xmm1, [rsp+0x10]
00007d3d13bdd0d1  vmovaps xmm2, [rsp+0x20]
00007d3d13bdd0d7  vmovaps xmm3, [rsp+0x30]
00007d3d13bdd0dd  vmovaps xmm4, [rsp+0x40]
00007d3d13bdd0e3  vmovaps xmm5, [rsp+0x50]
00007d3d13bdd0e9  vmovaps xmm6, [rsp+0x60]
00007d3d13bdd0ef  vmovaps xmm7, [rsp+0x70]
00007d3d13bdd0f5  vmovaps xmm9, [rsp+0x80]
00007d3d13bdd0fe  vmovaps xmm10, [rsp+0x90]
00007d3d13bdd107  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdd110  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdd119  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdd122  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdd12b  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdd134  add rsp, 0xF0
00007d3d13bdd13b  pop r11
00007d3d13bdd13d  pop r10
00007d3d13bdd13f  pop r9
00007d3d13bdd141  pop r8
00007d3d13bdd143  pop rsi
00007d3d13bdd144  pop rdi
00007d3d13bdd145  pop rdx
00007d3d13bdd146  pop rcx
00007d3d13bdd147  pop rax
00007d3d13bdd148  add rsp, 0x08
00007d3d13bdd14c  jmp 0x00007D3D13BD958E
00007d3d13bdd151  sub rsp, 0x08
00007d3d13bdd155  push rax
00007d3d13bdd156  push rcx
00007d3d13bdd157  push rdx
00007d3d13bdd158  push rdi
00007d3d13bdd159  push rsi
00007d3d13bdd15a  push r8
00007d3d13bdd15c  push r9
00007d3d13bdd15e  push r10
00007d3d13bdd160  push r11
00007d3d13bdd162  sub rsp, 0xF0
00007d3d13bdd169  vmovaps [rsp], xmm0
00007d3d13bdd16e  vmovaps [rsp+0x10], xmm1
00007d3d13bdd174  vmovaps [rsp+0x20], xmm2
00007d3d13bdd17a  vmovaps [rsp+0x30], xmm3
00007d3d13bdd180  vmovaps [rsp+0x40], xmm4
00007d3d13bdd186  vmovaps [rsp+0x50], xmm5
00007d3d13bdd18c  vmovaps [rsp+0x60], xmm7
00007d3d13bdd192  vmovaps [rsp+0x70], xmm8
00007d3d13bdd198  vmovaps [rsp+0x80], xmm9
00007d3d13bdd1a1  vmovaps [rsp+0x90], xmm10
00007d3d13bdd1aa  vmovaps [rsp+0xA0], xmm11
00007d3d13bdd1b3  vmovaps [rsp+0xB0], xmm12
00007d3d13bdd1bc  vmovaps [rsp+0xC0], xmm13
00007d3d13bdd1c5  vmovaps [rsp+0xD0], xmm14
00007d3d13bdd1ce  vmovaps [rsp+0xE0], xmm15
00007d3d13bdd1d7  sub rsp, 0x30
00007d3d13bdd1db  movaps [rsp], xmm6
00007d3d13bdd1df  movaps [rsp+0x10], xmm1
00007d3d13bdd1e4  movaps [rsp+0x20], xmm14
00007d3d13bdd1ea  lea rdi, [rsp]
00007d3d13bdd1ee  mov esi, 0x00
00007d3d13bdd1f3  mov rax, 0x5741DAFC8530
00007d3d13bdd1fd  call rax
00007d3d13bdd1ff  movaps xmm6, [rsp]
00007d3d13bdd203  add rsp, 0x30
00007d3d13bdd207  vmovaps xmm0, [rsp]
00007d3d13bdd20c  vmovaps xmm1, [rsp+0x10]
00007d3d13bdd212  vmovaps xmm2, [rsp+0x20]
00007d3d13bdd218  vmovaps xmm3, [rsp+0x30]
00007d3d13bdd21e  vmovaps xmm4, [rsp+0x40]
00007d3d13bdd224  vmovaps xmm5, [rsp+0x50]
00007d3d13bdd22a  vmovaps xmm7, [rsp+0x60]
00007d3d13bdd230  vmovaps xmm8, [rsp+0x70]
00007d3d13bdd236  vmovaps xmm9, [rsp+0x80]
00007d3d13bdd23f  vmovaps xmm10, [rsp+0x90]
00007d3d13bdd248  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdd251  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdd25a  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdd263  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdd26c  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdd275  add rsp, 0xF0
00007d3d13bdd27c  pop r11
00007d3d13bdd27e  pop r10
00007d3d13bdd280  pop r9
00007d3d13bdd282  pop r8
00007d3d13bdd284  pop rsi
00007d3d13bdd285  pop rdi
00007d3d13bdd286  pop rdx
00007d3d13bdd287  pop rcx
00007d3d13bdd288  pop rax
00007d3d13bdd289  add rsp, 0x08
00007d3d13bdd28d  jmp 0x00007D3D13BD95BA
00007d3d13bdd292  sub rsp, 0x08
00007d3d13bdd296  push rax
00007d3d13bdd297  push rcx
00007d3d13bdd298  push rdx
00007d3d13bdd299  push rdi
00007d3d13bdd29a  push rsi
00007d3d13bdd29b  push r8
00007d3d13bdd29d  push r9
00007d3d13bdd29f  push r10
00007d3d13bdd2a1  push r11
00007d3d13bdd2a3  sub rsp, 0xF0
00007d3d13bdd2aa  vmovaps [rsp], xmm0
00007d3d13bdd2af  vmovaps [rsp+0x10], xmm1
00007d3d13bdd2b5  vmovaps [rsp+0x20], xmm2
00007d3d13bdd2bb  vmovaps [rsp+0x30], xmm3
00007d3d13bdd2c1  vmovaps [rsp+0x40], xmm4
00007d3d13bdd2c7  vmovaps [rsp+0x50], xmm5
00007d3d13bdd2cd  vmovaps [rsp+0x60], xmm6
00007d3d13bdd2d3  vmovaps [rsp+0x70], xmm7
00007d3d13bdd2d9  vmovaps [rsp+0x80], xmm8
00007d3d13bdd2e2  vmovaps [rsp+0x90], xmm9
00007d3d13bdd2eb  vmovaps [rsp+0xA0], xmm10
00007d3d13bdd2f4  vmovaps [rsp+0xB0], xmm11
00007d3d13bdd2fd  vmovaps [rsp+0xC0], xmm12
00007d3d13bdd306  vmovaps [rsp+0xD0], xmm13
00007d3d13bdd30f  vmovaps [rsp+0xE0], xmm15
00007d3d13bdd318  sub rsp, 0x30
00007d3d13bdd31c  movaps [rsp], xmm14
00007d3d13bdd321  movaps [rsp+0x10], xmm12
00007d3d13bdd327  movaps [rsp+0x20], xmm1
00007d3d13bdd32c  lea rdi, [rsp]
00007d3d13bdd330  mov esi, 0x00
00007d3d13bdd335  mov rax, 0x5741DAFC8530
00007d3d13bdd33f  call rax
00007d3d13bdd341  movaps xmm14, [rsp]
00007d3d13bdd346  add rsp, 0x30
00007d3d13bdd34a  vmovaps xmm0, [rsp]
00007d3d13bdd34f  vmovaps xmm1, [rsp+0x10]
00007d3d13bdd355  vmovaps xmm2, [rsp+0x20]
00007d3d13bdd35b  vmovaps xmm3, [rsp+0x30]
00007d3d13bdd361  vmovaps xmm4, [rsp+0x40]
00007d3d13bdd367  vmovaps xmm5, [rsp+0x50]
00007d3d13bdd36d  vmovaps xmm6, [rsp+0x60]
00007d3d13bdd373  vmovaps xmm7, [rsp+0x70]
00007d3d13bdd379  vmovaps xmm8, [rsp+0x80]
00007d3d13bdd382  vmovaps xmm9, [rsp+0x90]
00007d3d13bdd38b  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdd394  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdd39d  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdd3a6  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdd3af  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdd3b8  add rsp, 0xF0
00007d3d13bdd3bf  pop r11
00007d3d13bdd3c1  pop r10
00007d3d13bdd3c3  pop r9
00007d3d13bdd3c5  pop r8
00007d3d13bdd3c7  pop rsi
00007d3d13bdd3c8  pop rdi
00007d3d13bdd3c9  pop rdx
00007d3d13bdd3ca  pop rcx
00007d3d13bdd3cb  pop rax
00007d3d13bdd3cc  add rsp, 0x08
00007d3d13bdd3d0  jmp 0x00007D3D13BD95E0
00007d3d13bdd3d5  sub rsp, 0x08
00007d3d13bdd3d9  push rax
00007d3d13bdd3da  push rcx
00007d3d13bdd3db  push rdx
00007d3d13bdd3dc  push rdi
00007d3d13bdd3dd  push rsi
00007d3d13bdd3de  push r8
00007d3d13bdd3e0  push r9
00007d3d13bdd3e2  push r10
00007d3d13bdd3e4  push r11
00007d3d13bdd3e6  sub rsp, 0xF0
00007d3d13bdd3ed  vmovaps [rsp], xmm0
00007d3d13bdd3f2  vmovaps [rsp+0x10], xmm2
00007d3d13bdd3f8  vmovaps [rsp+0x20], xmm3
00007d3d13bdd3fe  vmovaps [rsp+0x30], xmm4
00007d3d13bdd404  vmovaps [rsp+0x40], xmm5
00007d3d13bdd40a  vmovaps [rsp+0x50], xmm6
00007d3d13bdd410  vmovaps [rsp+0x60], xmm7
00007d3d13bdd416  vmovaps [rsp+0x70], xmm8
00007d3d13bdd41c  vmovaps [rsp+0x80], xmm9
00007d3d13bdd425  vmovaps [rsp+0x90], xmm10
00007d3d13bdd42e  vmovaps [rsp+0xA0], xmm11
00007d3d13bdd437  vmovaps [rsp+0xB0], xmm12
00007d3d13bdd440  vmovaps [rsp+0xC0], xmm13
00007d3d13bdd449  vmovaps [rsp+0xD0], xmm14
00007d3d13bdd452  vmovaps [rsp+0xE0], xmm15
00007d3d13bdd45b  sub rsp, 0x30
00007d3d13bdd45f  movaps [rsp], xmm1
00007d3d13bdd463  movaps [rsp+0x10], xmm13
00007d3d13bdd469  movaps [rsp+0x20], xmm9
00007d3d13bdd46f  lea rdi, [rsp]
00007d3d13bdd473  mov esi, 0x00
00007d3d13bdd478  mov rax, 0x5741DAFC8530
00007d3d13bdd482  call rax
00007d3d13bdd484  movaps xmm1, [rsp]
00007d3d13bdd488  add rsp, 0x30
00007d3d13bdd48c  vmovaps xmm0, [rsp]
00007d3d13bdd491  vmovaps xmm2, [rsp+0x10]
00007d3d13bdd497  vmovaps xmm3, [rsp+0x20]
00007d3d13bdd49d  vmovaps xmm4, [rsp+0x30]
00007d3d13bdd4a3  vmovaps xmm5, [rsp+0x40]
00007d3d13bdd4a9  vmovaps xmm6, [rsp+0x50]
00007d3d13bdd4af  vmovaps xmm7, [rsp+0x60]
00007d3d13bdd4b5  vmovaps xmm8, [rsp+0x70]
00007d3d13bdd4bb  vmovaps xmm9, [rsp+0x80]
00007d3d13bdd4c4  vmovaps xmm10, [rsp+0x90]
00007d3d13bdd4cd  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdd4d6  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdd4df  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdd4e8  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdd4f1  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdd4fa  add rsp, 0xF0
00007d3d13bdd501  pop r11
00007d3d13bdd503  pop r10
00007d3d13bdd505  pop r9
00007d3d13bdd507  pop r8
00007d3d13bdd509  pop rsi
00007d3d13bdd50a  pop rdi
00007d3d13bdd50b  pop rdx
00007d3d13bdd50c  pop rcx
00007d3d13bdd50d  pop rax
00007d3d13bdd50e  add rsp, 0x08
00007d3d13bdd512  jmp 0x00007D3D13BD95FA
00007d3d13bdd517  sub rsp, 0x08
00007d3d13bdd51b  push rax
00007d3d13bdd51c  push rcx
00007d3d13bdd51d  push rdx
00007d3d13bdd51e  push rdi
00007d3d13bdd51f  push rsi
00007d3d13bdd520  push r8
00007d3d13bdd522  push r9
00007d3d13bdd524  push r10
00007d3d13bdd526  push r11
00007d3d13bdd528  sub rsp, 0xF0
00007d3d13bdd52f  vmovaps [rsp], xmm0
00007d3d13bdd534  vmovaps [rsp+0x10], xmm1
00007d3d13bdd53a  vmovaps [rsp+0x20], xmm2
00007d3d13bdd540  vmovaps [rsp+0x30], xmm3
00007d3d13bdd546  vmovaps [rsp+0x40], xmm4
00007d3d13bdd54c  vmovaps [rsp+0x50], xmm5
00007d3d13bdd552  vmovaps [rsp+0x60], xmm6
00007d3d13bdd558  vmovaps [rsp+0x70], xmm7
00007d3d13bdd55e  vmovaps [rsp+0x80], xmm8
00007d3d13bdd567  vmovaps [rsp+0x90], xmm9
00007d3d13bdd570  vmovaps [rsp+0xA0], xmm10
00007d3d13bdd579  vmovaps [rsp+0xB0], xmm11
00007d3d13bdd582  vmovaps [rsp+0xC0], xmm13
00007d3d13bdd58b  vmovaps [rsp+0xD0], xmm14
00007d3d13bdd594  vmovaps [rsp+0xE0], xmm15
00007d3d13bdd59d  sub rsp, 0x30
00007d3d13bdd5a1  movaps [rsp], xmm12
00007d3d13bdd5a6  movaps [rsp+0x10], xmm7
00007d3d13bdd5ab  movaps [rsp+0x20], xmm13
00007d3d13bdd5b1  lea rdi, [rsp]
00007d3d13bdd5b5  mov esi, 0x00
00007d3d13bdd5ba  mov rax, 0x5741DAFC8530
00007d3d13bdd5c4  call rax
00007d3d13bdd5c6  movaps xmm12, [rsp]
00007d3d13bdd5cb  add rsp, 0x30
00007d3d13bdd5cf  vmovaps xmm0, [rsp]
00007d3d13bdd5d4  vmovaps xmm1, [rsp+0x10]
00007d3d13bdd5da  vmovaps xmm2, [rsp+0x20]
00007d3d13bdd5e0  vmovaps xmm3, [rsp+0x30]
00007d3d13bdd5e6  vmovaps xmm4, [rsp+0x40]
00007d3d13bdd5ec  vmovaps xmm5, [rsp+0x50]
00007d3d13bdd5f2  vmovaps xmm6, [rsp+0x60]
00007d3d13bdd5f8  vmovaps xmm7, [rsp+0x70]
00007d3d13bdd5fe  vmovaps xmm8, [rsp+0x80]
00007d3d13bdd607  vmovaps xmm9, [rsp+0x90]
00007d3d13bdd610  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdd619  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdd622  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdd62b  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdd634  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdd63d  add rsp, 0xF0
00007d3d13bdd644  pop r11
00007d3d13bdd646  pop r10
00007d3d13bdd648  pop r9
00007d3d13bdd64a  pop r8
00007d3d13bdd64c  pop rsi
00007d3d13bdd64d  pop rdi
00007d3d13bdd64e  pop rdx
00007d3d13bdd64f  pop rcx
00007d3d13bdd650  pop rax
00007d3d13bdd651  add rsp, 0x08
00007d3d13bdd655  jmp 0x00007D3D13BD9621
00007d3d13bdd65a  sub rsp, 0x08
00007d3d13bdd65e  push rax
00007d3d13bdd65f  push rcx
00007d3d13bdd660  push rdx
00007d3d13bdd661  push rdi
00007d3d13bdd662  push rsi
00007d3d13bdd663  push r8
00007d3d13bdd665  push r9
00007d3d13bdd667  push r10
00007d3d13bdd669  push r11
00007d3d13bdd66b  sub rsp, 0xF0
00007d3d13bdd672  vmovaps [rsp], xmm0
00007d3d13bdd677  vmovaps [rsp+0x10], xmm1
00007d3d13bdd67d  vmovaps [rsp+0x20], xmm2
00007d3d13bdd683  vmovaps [rsp+0x30], xmm3
00007d3d13bdd689  vmovaps [rsp+0x40], xmm4
00007d3d13bdd68f  vmovaps [rsp+0x50], xmm5
00007d3d13bdd695  vmovaps [rsp+0x60], xmm6
00007d3d13bdd69b  vmovaps [rsp+0x70], xmm7
00007d3d13bdd6a1  vmovaps [rsp+0x80], xmm8
00007d3d13bdd6aa  vmovaps [rsp+0x90], xmm9
00007d3d13bdd6b3  vmovaps [rsp+0xA0], xmm10
00007d3d13bdd6bc  vmovaps [rsp+0xB0], xmm11
00007d3d13bdd6c5  vmovaps [rsp+0xC0], xmm12
00007d3d13bdd6ce  vmovaps [rsp+0xD0], xmm14
00007d3d13bdd6d7  vmovaps [rsp+0xE0], xmm15
00007d3d13bdd6e0  sub rsp, 0x30
00007d3d13bdd6e4  movaps [rsp], xmm13
00007d3d13bdd6e9  movaps [rsp+0x10], xmm15
00007d3d13bdd6ef  movaps [rsp+0x20], xmm8
00007d3d13bdd6f5  lea rdi, [rsp]
00007d3d13bdd6f9  mov esi, 0x00
00007d3d13bdd6fe  mov rax, 0x5741DAFC8530
00007d3d13bdd708  call rax
00007d3d13bdd70a  movaps xmm13, [rsp]
00007d3d13bdd70f  add rsp, 0x30
00007d3d13bdd713  vmovaps xmm0, [rsp]
00007d3d13bdd718  vmovaps xmm1, [rsp+0x10]
00007d3d13bdd71e  vmovaps xmm2, [rsp+0x20]
00007d3d13bdd724  vmovaps xmm3, [rsp+0x30]
00007d3d13bdd72a  vmovaps xmm4, [rsp+0x40]
00007d3d13bdd730  vmovaps xmm5, [rsp+0x50]
00007d3d13bdd736  vmovaps xmm6, [rsp+0x60]
00007d3d13bdd73c  vmovaps xmm7, [rsp+0x70]
00007d3d13bdd742  vmovaps xmm8, [rsp+0x80]
00007d3d13bdd74b  vmovaps xmm9, [rsp+0x90]
00007d3d13bdd754  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdd75d  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdd766  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdd76f  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdd778  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdd781  add rsp, 0xF0
00007d3d13bdd788  pop r11
00007d3d13bdd78a  pop r10
00007d3d13bdd78c  pop r9
00007d3d13bdd78e  pop r8
00007d3d13bdd790  pop rsi
00007d3d13bdd791  pop rdi
00007d3d13bdd792  pop rdx
00007d3d13bdd793  pop rcx
00007d3d13bdd794  pop rax
00007d3d13bdd795  add rsp, 0x08
00007d3d13bdd799  jmp 0x00007D3D13BD963C
00007d3d13bdd79e  sub rsp, 0x08
00007d3d13bdd7a2  push rax
00007d3d13bdd7a3  push rcx
00007d3d13bdd7a4  push rdx
00007d3d13bdd7a5  push rdi
00007d3d13bdd7a6  push rsi
00007d3d13bdd7a7  push r8
00007d3d13bdd7a9  push r9
00007d3d13bdd7ab  push r10
00007d3d13bdd7ad  push r11
00007d3d13bdd7af  sub rsp, 0xF0
00007d3d13bdd7b6  vmovaps [rsp], xmm0
00007d3d13bdd7bb  vmovaps [rsp+0x10], xmm1
00007d3d13bdd7c1  vmovaps [rsp+0x20], xmm2
00007d3d13bdd7c7  vmovaps [rsp+0x30], xmm3
00007d3d13bdd7cd  vmovaps [rsp+0x40], xmm4
00007d3d13bdd7d3  vmovaps [rsp+0x50], xmm5
00007d3d13bdd7d9  vmovaps [rsp+0x60], xmm6
00007d3d13bdd7df  vmovaps [rsp+0x70], xmm7
00007d3d13bdd7e5  vmovaps [rsp+0x80], xmm9
00007d3d13bdd7ee  vmovaps [rsp+0x90], xmm10
00007d3d13bdd7f7  vmovaps [rsp+0xA0], xmm11
00007d3d13bdd800  vmovaps [rsp+0xB0], xmm12
00007d3d13bdd809  vmovaps [rsp+0xC0], xmm13
00007d3d13bdd812  vmovaps [rsp+0xD0], xmm14
00007d3d13bdd81b  vmovaps [rsp+0xE0], xmm15
00007d3d13bdd824  sub rsp, 0x30
00007d3d13bdd828  movaps [rsp], xmm8
00007d3d13bdd82d  movaps [rsp+0x10], xmm15
00007d3d13bdd833  movaps [rsp+0x20], xmm9
00007d3d13bdd839  lea rdi, [rsp]
00007d3d13bdd83d  mov esi, 0x00
00007d3d13bdd842  mov rax, 0x5741DAFC8530
00007d3d13bdd84c  call rax
00007d3d13bdd84e  movaps xmm8, [rsp]
00007d3d13bdd853  add rsp, 0x30
00007d3d13bdd857  vmovaps xmm0, [rsp]
00007d3d13bdd85c  vmovaps xmm1, [rsp+0x10]
00007d3d13bdd862  vmovaps xmm2, [rsp+0x20]
00007d3d13bdd868  vmovaps xmm3, [rsp+0x30]
00007d3d13bdd86e  vmovaps xmm4, [rsp+0x40]
00007d3d13bdd874  vmovaps xmm5, [rsp+0x50]
00007d3d13bdd87a  vmovaps xmm6, [rsp+0x60]
00007d3d13bdd880  vmovaps xmm7, [rsp+0x70]
00007d3d13bdd886  vmovaps xmm9, [rsp+0x80]
00007d3d13bdd88f  vmovaps xmm10, [rsp+0x90]
00007d3d13bdd898  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdd8a1  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdd8aa  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdd8b3  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdd8bc  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdd8c5  add rsp, 0xF0
00007d3d13bdd8cc  pop r11
00007d3d13bdd8ce  pop r10
00007d3d13bdd8d0  pop r9
00007d3d13bdd8d2  pop r8
00007d3d13bdd8d4  pop rsi
00007d3d13bdd8d5  pop rdi
00007d3d13bdd8d6  pop rdx
00007d3d13bdd8d7  pop rcx
00007d3d13bdd8d8  pop rax
00007d3d13bdd8d9  add rsp, 0x08
00007d3d13bdd8dd  jmp 0x00007D3D13BD966A
00007d3d13bdd8e2  sub rsp, 0x08
00007d3d13bdd8e6  push rax
00007d3d13bdd8e7  push rcx
00007d3d13bdd8e8  push rdx
00007d3d13bdd8e9  push rdi
00007d3d13bdd8ea  push rsi
00007d3d13bdd8eb  push r8
00007d3d13bdd8ed  push r9
00007d3d13bdd8ef  push r10
00007d3d13bdd8f1  push r11
00007d3d13bdd8f3  sub rsp, 0xF0
00007d3d13bdd8fa  vmovaps [rsp], xmm0
00007d3d13bdd8ff  vmovaps [rsp+0x10], xmm1
00007d3d13bdd905  vmovaps [rsp+0x20], xmm2
00007d3d13bdd90b  vmovaps [rsp+0x30], xmm3
00007d3d13bdd911  vmovaps [rsp+0x40], xmm4
00007d3d13bdd917  vmovaps [rsp+0x50], xmm5
00007d3d13bdd91d  vmovaps [rsp+0x60], xmm6
00007d3d13bdd923  vmovaps [rsp+0x70], xmm7
00007d3d13bdd929  vmovaps [rsp+0x80], xmm8
00007d3d13bdd932  vmovaps [rsp+0x90], xmm9
00007d3d13bdd93b  vmovaps [rsp+0xA0], xmm10
00007d3d13bdd944  vmovaps [rsp+0xB0], xmm11
00007d3d13bdd94d  vmovaps [rsp+0xC0], xmm12
00007d3d13bdd956  vmovaps [rsp+0xD0], xmm13
00007d3d13bdd95f  vmovaps [rsp+0xE0], xmm14
00007d3d13bdd968  sub rsp, 0x30
00007d3d13bdd96c  movaps [rsp], xmm15
00007d3d13bdd971  movaps [rsp+0x10], xmm11
00007d3d13bdd977  movaps [rsp+0x20], xmm6
00007d3d13bdd97c  lea rdi, [rsp]
00007d3d13bdd980  mov esi, 0x00
00007d3d13bdd985  mov rax, 0x5741DAFC8530
00007d3d13bdd98f  call rax
00007d3d13bdd991  movaps xmm15, [rsp]
00007d3d13bdd996  add rsp, 0x30
00007d3d13bdd99a  vmovaps xmm0, [rsp]
00007d3d13bdd99f  vmovaps xmm1, [rsp+0x10]
00007d3d13bdd9a5  vmovaps xmm2, [rsp+0x20]
00007d3d13bdd9ab  vmovaps xmm3, [rsp+0x30]
00007d3d13bdd9b1  vmovaps xmm4, [rsp+0x40]
00007d3d13bdd9b7  vmovaps xmm5, [rsp+0x50]
00007d3d13bdd9bd  vmovaps xmm6, [rsp+0x60]
00007d3d13bdd9c3  vmovaps xmm7, [rsp+0x70]
00007d3d13bdd9c9  vmovaps xmm8, [rsp+0x80]
00007d3d13bdd9d2  vmovaps xmm9, [rsp+0x90]
00007d3d13bdd9db  vmovaps xmm10, [rsp+0xA0]
00007d3d13bdd9e4  vmovaps xmm11, [rsp+0xB0]
00007d3d13bdd9ed  vmovaps xmm12, [rsp+0xC0]
00007d3d13bdd9f6  vmovaps xmm13, [rsp+0xD0]
00007d3d13bdd9ff  vmovaps xmm14, [rsp+0xE0]
00007d3d13bdda08  add rsp, 0xF0
00007d3d13bdda0f  pop r11
00007d3d13bdda11  pop r10
00007d3d13bdda13  pop r9
00007d3d13bdda15  pop r8
00007d3d13bdda17  pop rsi
00007d3d13bdda18  pop rdi
00007d3d13bdda19  pop rdx
00007d3d13bdda1a  pop rcx
00007d3d13bdda1b  pop rax
00007d3d13bdda1c  add rsp, 0x08
00007d3d13bdda20  jmp 0x00007D3D13BD9685
00007d3d13bdda25  sub rsp, 0x08
00007d3d13bdda29  push rax
00007d3d13bdda2a  push rcx
00007d3d13bdda2b  push rdx
00007d3d13bdda2c  push rdi
00007d3d13bdda2d  push rsi
00007d3d13bdda2e  push r8
00007d3d13bdda30  push r9
00007d3d13bdda32  push r10
00007d3d13bdda34  push r11
00007d3d13bdda36  sub rsp, 0xF0
00007d3d13bdda3d  vmovaps [rsp], xmm0
00007d3d13bdda42  vmovaps [rsp+0x10], xmm1
00007d3d13bdda48  vmovaps [rsp+0x20], xmm2
00007d3d13bdda4e  vmovaps [rsp+0x30], xmm3
00007d3d13bdda54  vmovaps [rsp+0x40], xmm4
00007d3d13bdda5a  vmovaps [rsp+0x50], xmm5
00007d3d13bdda60  vmovaps [rsp+0x60], xmm6
00007d3d13bdda66  vmovaps [rsp+0x70], xmm8
00007d3d13bdda6c  vmovaps [rsp+0x80], xmm9
00007d3d13bdda75  vmovaps [rsp+0x90], xmm10
00007d3d13bdda7e  vmovaps [rsp+0xA0], xmm11
00007d3d13bdda87  vmovaps [rsp+0xB0], xmm12
00007d3d13bdda90  vmovaps [rsp+0xC0], xmm13
00007d3d13bdda99  vmovaps [rsp+0xD0], xmm14
00007d3d13bddaa2  vmovaps [rsp+0xE0], xmm15
00007d3d13bddaab  sub rsp, 0x30
00007d3d13bddaaf  movaps [rsp], xmm7
00007d3d13bddab3  movaps [rsp+0x10], xmm11
00007d3d13bddab9  movaps [rsp+0x20], xmm9
00007d3d13bddabf  lea rdi, [rsp]
00007d3d13bddac3  mov esi, 0x00
00007d3d13bddac8  mov rax, 0x5741DAFC8530
00007d3d13bddad2  call rax
00007d3d13bddad4  movaps xmm7, [rsp]
00007d3d13bddad8  add rsp, 0x30
00007d3d13bddadc  vmovaps xmm0, [rsp]
00007d3d13bddae1  vmovaps xmm1, [rsp+0x10]
00007d3d13bddae7  vmovaps xmm2, [rsp+0x20]
00007d3d13bddaed  vmovaps xmm3, [rsp+0x30]
00007d3d13bddaf3  vmovaps xmm4, [rsp+0x40]
00007d3d13bddaf9  vmovaps xmm5, [rsp+0x50]
00007d3d13bddaff  vmovaps xmm6, [rsp+0x60]
00007d3d13bddb05  vmovaps xmm8, [rsp+0x70]
00007d3d13bddb0b  vmovaps xmm9, [rsp+0x80]
00007d3d13bddb14  vmovaps xmm10, [rsp+0x90]
00007d3d13bddb1d  vmovaps xmm11, [rsp+0xA0]
00007d3d13bddb26  vmovaps xmm12, [rsp+0xB0]
00007d3d13bddb2f  vmovaps xmm13, [rsp+0xC0]
00007d3d13bddb38  vmovaps xmm14, [rsp+0xD0]
00007d3d13bddb41  vmovaps xmm15, [rsp+0xE0]
00007d3d13bddb4a  add rsp, 0xF0
00007d3d13bddb51  pop r11
00007d3d13bddb53  pop r10
00007d3d13bddb55  pop r9
00007d3d13bddb57  pop r8
00007d3d13bddb59  pop rsi
00007d3d13bddb5a  pop rdi
00007d3d13bddb5b  pop rdx
00007d3d13bddb5c  pop rcx
00007d3d13bddb5d  pop rax
00007d3d13bddb5e  add rsp, 0x08
00007d3d13bddb62  jmp 0x00007D3D13BD96B2
00007d3d13bddb67  sub rsp, 0x08
00007d3d13bddb6b  push rax
00007d3d13bddb6c  push rcx
00007d3d13bddb6d  push rdx
00007d3d13bddb6e  push rdi
00007d3d13bddb6f  push rsi
00007d3d13bddb70  push r8
00007d3d13bddb72  push r9
00007d3d13bddb74  push r10
00007d3d13bddb76  push r11
00007d3d13bddb78  sub rsp, 0xF0
00007d3d13bddb7f  vmovaps [rsp], xmm0
00007d3d13bddb84  vmovaps [rsp+0x10], xmm1
00007d3d13bddb8a  vmovaps [rsp+0x20], xmm2
00007d3d13bddb90  vmovaps [rsp+0x30], xmm3
00007d3d13bddb96  vmovaps [rsp+0x40], xmm4
00007d3d13bddb9c  vmovaps [rsp+0x50], xmm5
00007d3d13bddba2  vmovaps [rsp+0x60], xmm6
00007d3d13bddba8  vmovaps [rsp+0x70], xmm7
00007d3d13bddbae  vmovaps [rsp+0x80], xmm8
00007d3d13bddbb7  vmovaps [rsp+0x90], xmm9
00007d3d13bddbc0  vmovaps [rsp+0xA0], xmm10
00007d3d13bddbc9  vmovaps [rsp+0xB0], xmm12
00007d3d13bddbd2  vmovaps [rsp+0xC0], xmm13
00007d3d13bddbdb  vmovaps [rsp+0xD0], xmm14
00007d3d13bddbe4  vmovaps [rsp+0xE0], xmm15
00007d3d13bddbed  sub rsp, 0x30
00007d3d13bddbf1  movaps [rsp], xmm11
00007d3d13bddbf6  movaps [rsp+0x10], xmm10
00007d3d13bddbfc  movaps [rsp+0x20], xmm14
00007d3d13bddc02  lea rdi, [rsp]
00007d3d13bddc06  mov esi, 0x00
00007d3d13bddc0b  mov rax, 0x5741DAFC8530
00007d3d13bddc15  call rax
00007d3d13bddc17  movaps xmm11, [rsp]
00007d3d13bddc1c  add rsp, 0x30
00007d3d13bddc20  vmovaps xmm0, [rsp]
00007d3d13bddc25  vmovaps xmm1, [rsp+0x10]
00007d3d13bddc2b  vmovaps xmm2, [rsp+0x20]
00007d3d13bddc31  vmovaps xmm3, [rsp+0x30]
00007d3d13bddc37  vmovaps xmm4, [rsp+0x40]
00007d3d13bddc3d  vmovaps xmm5, [rsp+0x50]
00007d3d13bddc43  vmovaps xmm6, [rsp+0x60]
00007d3d13bddc49  vmovaps xmm7, [rsp+0x70]
00007d3d13bddc4f  vmovaps xmm8, [rsp+0x80]
00007d3d13bddc58  vmovaps xmm9, [rsp+0x90]
00007d3d13bddc61  vmovaps xmm10, [rsp+0xA0]
00007d3d13bddc6a  vmovaps xmm12, [rsp+0xB0]
00007d3d13bddc73  vmovaps xmm13, [rsp+0xC0]
00007d3d13bddc7c  vmovaps xmm14, [rsp+0xD0]
00007d3d13bddc85  vmovaps xmm15, [rsp+0xE0]
00007d3d13bddc8e  add rsp, 0xF0
00007d3d13bddc95  pop r11
00007d3d13bddc97  pop r10
00007d3d13bddc99  pop r9
00007d3d13bddc9b  pop r8
00007d3d13bddc9d  pop rsi
00007d3d13bddc9e  pop rdi
00007d3d13bddc9f  pop rdx
00007d3d13bddca0  pop rcx
00007d3d13bddca1  pop rax
00007d3d13bddca2  add rsp, 0x08
00007d3d13bddca6  jmp 0x00007D3D13BD96CD
00007d3d13bddcab  call 0x00007D3D13AE45A0
00007d3d13bddcb0  jmp 0x00007D3D13BD96D7
00007d3d13bddcb5  sub rsp, 0x08
00007d3d13bddcb9  push rax
00007d3d13bddcba  push rcx
00007d3d13bddcbb  push rdx
00007d3d13bddcbc  push rdi
00007d3d13bddcbd  push rsi
00007d3d13bddcbe  push r8
00007d3d13bddcc0  push r9
00007d3d13bddcc2  push r10
00007d3d13bddcc4  push r11
00007d3d13bddcc6  sub rsp, 0xF0
00007d3d13bddccd  vmovaps [rsp], xmm0
00007d3d13bddcd2  vmovaps [rsp+0x10], xmm1
00007d3d13bddcd8  vmovaps [rsp+0x20], xmm2
00007d3d13bddcde  vmovaps [rsp+0x30], xmm3
00007d3d13bddce4  vmovaps [rsp+0x40], xmm4
00007d3d13bddcea  vmovaps [rsp+0x50], xmm5
00007d3d13bddcf0  vmovaps [rsp+0x60], xmm6
00007d3d13bddcf6  vmovaps [rsp+0x70], xmm7
00007d3d13bddcfc  vmovaps [rsp+0x80], xmm8
00007d3d13bddd05  vmovaps [rsp+0x90], xmm9
00007d3d13bddd0e  vmovaps [rsp+0xA0], xmm11
00007d3d13bddd17  vmovaps [rsp+0xB0], xmm12
00007d3d13bddd20  vmovaps [rsp+0xC0], xmm13
00007d3d13bddd29  vmovaps [rsp+0xD0], xmm14
00007d3d13bddd32  vmovaps [rsp+0xE0], xmm15
00007d3d13bddd3b  sub rsp, 0x30
00007d3d13bddd3f  movaps [rsp], xmm10
00007d3d13bddd44  movaps [rsp+0x10], xmm1
00007d3d13bddd49  movaps [rsp+0x20], xmm12
00007d3d13bddd4f  lea rdi, [rsp]
00007d3d13bddd53  mov esi, 0x00
00007d3d13bddd58  mov rax, 0x5741DAFC8530
00007d3d13bddd62  call rax
00007d3d13bddd64  movaps xmm10, [rsp]
00007d3d13bddd69  add rsp, 0x30
00007d3d13bddd6d  vmovaps xmm0, [rsp]
00007d3d13bddd72  vmovaps xmm1, [rsp+0x10]
00007d3d13bddd78  vmovaps xmm2, [rsp+0x20]
00007d3d13bddd7e  vmovaps xmm3, [rsp+0x30]
00007d3d13bddd84  vmovaps xmm4, [rsp+0x40]
00007d3d13bddd8a  vmovaps xmm5, [rsp+0x50]
00007d3d13bddd90  vmovaps xmm6, [rsp+0x60]
00007d3d13bddd96  vmovaps xmm7, [rsp+0x70]
00007d3d13bddd9c  vmovaps xmm8, [rsp+0x80]
00007d3d13bddda5  vmovaps xmm9, [rsp+0x90]
00007d3d13bdddae  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdddb7  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdddc0  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdddc9  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdddd2  vmovaps xmm15, [rsp+0xE0]
00007d3d13bddddb  add rsp, 0xF0
00007d3d13bddde2  pop r11
00007d3d13bddde4  pop r10
00007d3d13bddde6  pop r9
00007d3d13bddde8  pop r8
00007d3d13bdddea  pop rsi
00007d3d13bdddeb  pop rdi
00007d3d13bdddec  pop rdx
00007d3d13bddded  pop rcx
00007d3d13bdddee  pop rax
00007d3d13bdddef  add rsp, 0x08
00007d3d13bdddf3  jmp 0x00007D3D13BD96FA
00007d3d13bdddf8  sub rsp, 0x08
00007d3d13bdddfc  push rax
00007d3d13bdddfd  push rcx
00007d3d13bdddfe  push rdx
00007d3d13bdddff  push rdi
00007d3d13bdde00  push rsi
00007d3d13bdde01  push r8
00007d3d13bdde03  push r9
00007d3d13bdde05  push r10
00007d3d13bdde07  push r11
00007d3d13bdde09  sub rsp, 0xF0
00007d3d13bdde10  vmovaps [rsp], xmm0
00007d3d13bdde15  vmovaps [rsp+0x10], xmm1
00007d3d13bdde1b  vmovaps [rsp+0x20], xmm2
00007d3d13bdde21  vmovaps [rsp+0x30], xmm3
00007d3d13bdde27  vmovaps [rsp+0x40], xmm4
00007d3d13bdde2d  vmovaps [rsp+0x50], xmm5
00007d3d13bdde33  vmovaps [rsp+0x60], xmm6
00007d3d13bdde39  vmovaps [rsp+0x70], xmm7
00007d3d13bdde3f  vmovaps [rsp+0x80], xmm8
00007d3d13bdde48  vmovaps [rsp+0x90], xmm9
00007d3d13bdde51  vmovaps [rsp+0xA0], xmm10
00007d3d13bdde5a  vmovaps [rsp+0xB0], xmm11
00007d3d13bdde63  vmovaps [rsp+0xC0], xmm13
00007d3d13bdde6c  vmovaps [rsp+0xD0], xmm14
00007d3d13bdde75  vmovaps [rsp+0xE0], xmm15
00007d3d13bdde7e  sub rsp, 0x30
00007d3d13bdde82  movaps [rsp], xmm12
00007d3d13bdde87  movaps [rsp+0x10], xmm14
00007d3d13bdde8d  movaps [rsp+0x20], xmm1
00007d3d13bdde92  lea rdi, [rsp]
00007d3d13bdde96  mov esi, 0x00
00007d3d13bdde9b  mov rax, 0x5741DAFC8530
00007d3d13bddea5  call rax
00007d3d13bddea7  movaps xmm12, [rsp]
00007d3d13bddeac  add rsp, 0x30
00007d3d13bddeb0  vmovaps xmm0, [rsp]
00007d3d13bddeb5  vmovaps xmm1, [rsp+0x10]
00007d3d13bddebb  vmovaps xmm2, [rsp+0x20]
00007d3d13bddec1  vmovaps xmm3, [rsp+0x30]
00007d3d13bddec7  vmovaps xmm4, [rsp+0x40]
00007d3d13bddecd  vmovaps xmm5, [rsp+0x50]
00007d3d13bdded3  vmovaps xmm6, [rsp+0x60]
00007d3d13bdded9  vmovaps xmm7, [rsp+0x70]
00007d3d13bddedf  vmovaps xmm8, [rsp+0x80]
00007d3d13bddee8  vmovaps xmm9, [rsp+0x90]
00007d3d13bddef1  vmovaps xmm10, [rsp+0xA0]
00007d3d13bddefa  vmovaps xmm11, [rsp+0xB0]
00007d3d13bddf03  vmovaps xmm13, [rsp+0xC0]
00007d3d13bddf0c  vmovaps xmm14, [rsp+0xD0]
00007d3d13bddf15  vmovaps xmm15, [rsp+0xE0]
00007d3d13bddf1e  add rsp, 0xF0
00007d3d13bddf25  pop r11
00007d3d13bddf27  pop r10
00007d3d13bddf29  pop r9
00007d3d13bddf2b  pop r8
00007d3d13bddf2d  pop rsi
00007d3d13bddf2e  pop rdi
00007d3d13bddf2f  pop rdx
00007d3d13bddf30  pop rcx
00007d3d13bddf31  pop rax
00007d3d13bddf32  add rsp, 0x08
00007d3d13bddf36  jmp 0x00007D3D13BD9729
00007d3d13bddf3b  sub rsp, 0x08
00007d3d13bddf3f  push rax
00007d3d13bddf40  push rcx
00007d3d13bddf41  push rdx
00007d3d13bddf42  push rdi
00007d3d13bddf43  push rsi
00007d3d13bddf44  push r8
00007d3d13bddf46  push r9
00007d3d13bddf48  push r10
00007d3d13bddf4a  push r11
00007d3d13bddf4c  sub rsp, 0xF0
00007d3d13bddf53  vmovaps [rsp], xmm0
00007d3d13bddf58  vmovaps [rsp+0x10], xmm1
00007d3d13bddf5e  vmovaps [rsp+0x20], xmm2
00007d3d13bddf64  vmovaps [rsp+0x30], xmm3
00007d3d13bddf6a  vmovaps [rsp+0x40], xmm4
00007d3d13bddf70  vmovaps [rsp+0x50], xmm5
00007d3d13bddf76  vmovaps [rsp+0x60], xmm6
00007d3d13bddf7c  vmovaps [rsp+0x70], xmm7
00007d3d13bddf82  vmovaps [rsp+0x80], xmm8
00007d3d13bddf8b  vmovaps [rsp+0x90], xmm9
00007d3d13bddf94  vmovaps [rsp+0xA0], xmm10
00007d3d13bddf9d  vmovaps [rsp+0xB0], xmm11
00007d3d13bddfa6  vmovaps [rsp+0xC0], xmm12
00007d3d13bddfaf  vmovaps [rsp+0xD0], xmm13
00007d3d13bddfb8  vmovaps [rsp+0xE0], xmm15
00007d3d13bddfc1  sub rsp, 0x30
00007d3d13bddfc5  movaps [rsp], xmm14
00007d3d13bddfca  movaps [rsp+0x10], xmm9
00007d3d13bddfd0  movaps [rsp+0x20], xmm1
00007d3d13bddfd5  lea rdi, [rsp]
00007d3d13bddfd9  mov esi, 0x00
00007d3d13bddfde  mov rax, 0x5741DAFC8530
00007d3d13bddfe8  call rax
00007d3d13bddfea  movaps xmm14, [rsp]
00007d3d13bddfef  add rsp, 0x30
00007d3d13bddff3  vmovaps xmm0, [rsp]
00007d3d13bddff8  vmovaps xmm1, [rsp+0x10]
00007d3d13bddffe  vmovaps xmm2, [rsp+0x20]
00007d3d13bde004  vmovaps xmm3, [rsp+0x30]
00007d3d13bde00a  vmovaps xmm4, [rsp+0x40]
00007d3d13bde010  vmovaps xmm5, [rsp+0x50]
00007d3d13bde016  vmovaps xmm6, [rsp+0x60]
00007d3d13bde01c  vmovaps xmm7, [rsp+0x70]
00007d3d13bde022  vmovaps xmm8, [rsp+0x80]
00007d3d13bde02b  vmovaps xmm9, [rsp+0x90]
00007d3d13bde034  vmovaps xmm10, [rsp+0xA0]
00007d3d13bde03d  vmovaps xmm11, [rsp+0xB0]
00007d3d13bde046  vmovaps xmm12, [rsp+0xC0]
00007d3d13bde04f  vmovaps xmm13, [rsp+0xD0]
00007d3d13bde058  vmovaps xmm15, [rsp+0xE0]
00007d3d13bde061  add rsp, 0xF0
00007d3d13bde068  pop r11
00007d3d13bde06a  pop r10
00007d3d13bde06c  pop r9
00007d3d13bde06e  pop r8
00007d3d13bde070  pop rsi
00007d3d13bde071  pop rdi
00007d3d13bde072  pop rdx
00007d3d13bde073  pop rcx
00007d3d13bde074  pop rax
00007d3d13bde075  add rsp, 0x08
00007d3d13bde079  jmp 0x00007D3D13BD9758
00007d3d13bde07e  sub rsp, 0x08
00007d3d13bde082  push rax
00007d3d13bde083  push rcx
00007d3d13bde084  push rdx
00007d3d13bde085  push rdi
00007d3d13bde086  push rsi
00007d3d13bde087  push r8
00007d3d13bde089  push r9
00007d3d13bde08b  push r10
00007d3d13bde08d  push r11
00007d3d13bde08f  sub rsp, 0xF0
00007d3d13bde096  vmovaps [rsp], xmm0
00007d3d13bde09b  vmovaps [rsp+0x10], xmm2
00007d3d13bde0a1  vmovaps [rsp+0x20], xmm3
00007d3d13bde0a7  vmovaps [rsp+0x30], xmm4
00007d3d13bde0ad  vmovaps [rsp+0x40], xmm5
00007d3d13bde0b3  vmovaps [rsp+0x50], xmm6
00007d3d13bde0b9  vmovaps [rsp+0x60], xmm7
00007d3d13bde0bf  vmovaps [rsp+0x70], xmm8
00007d3d13bde0c5  vmovaps [rsp+0x80], xmm9
00007d3d13bde0ce  vmovaps [rsp+0x90], xmm10
00007d3d13bde0d7  vmovaps [rsp+0xA0], xmm11
00007d3d13bde0e0  vmovaps [rsp+0xB0], xmm12
00007d3d13bde0e9  vmovaps [rsp+0xC0], xmm13
00007d3d13bde0f2  vmovaps [rsp+0xD0], xmm14
00007d3d13bde0fb  vmovaps [rsp+0xE0], xmm15
00007d3d13bde104  sub rsp, 0x30
00007d3d13bde108  movaps [rsp], xmm1
00007d3d13bde10c  movaps [rsp+0x10], xmm13
00007d3d13bde112  movaps [rsp+0x20], xmm8
00007d3d13bde118  lea rdi, [rsp]
00007d3d13bde11c  mov esi, 0x00
00007d3d13bde121  mov rax, 0x5741DAFC8530
00007d3d13bde12b  call rax
00007d3d13bde12d  movaps xmm1, [rsp]
00007d3d13bde131  add rsp, 0x30
00007d3d13bde135  vmovaps xmm0, [rsp]
00007d3d13bde13a  vmovaps xmm2, [rsp+0x10]
00007d3d13bde140  vmovaps xmm3, [rsp+0x20]
00007d3d13bde146  vmovaps xmm4, [rsp+0x30]
00007d3d13bde14c  vmovaps xmm5, [rsp+0x40]
00007d3d13bde152  vmovaps xmm6, [rsp+0x50]
00007d3d13bde158  vmovaps xmm7, [rsp+0x60]
00007d3d13bde15e  vmovaps xmm8, [rsp+0x70]
00007d3d13bde164  vmovaps xmm9, [rsp+0x80]
00007d3d13bde16d  vmovaps xmm10, [rsp+0x90]
00007d3d13bde176  vmovaps xmm11, [rsp+0xA0]
00007d3d13bde17f  vmovaps xmm12, [rsp+0xB0]
00007d3d13bde188  vmovaps xmm13, [rsp+0xC0]
00007d3d13bde191  vmovaps xmm14, [rsp+0xD0]
00007d3d13bde19a  vmovaps xmm15, [rsp+0xE0]
00007d3d13bde1a3  add rsp, 0xF0
00007d3d13bde1aa  pop r11
00007d3d13bde1ac  pop r10
00007d3d13bde1ae  pop r9
00007d3d13bde1b0  pop r8
00007d3d13bde1b2  pop rsi
00007d3d13bde1b3  pop rdi
00007d3d13bde1b4  pop rdx
00007d3d13bde1b5  pop rcx
00007d3d13bde1b6  pop rax
00007d3d13bde1b7  add rsp, 0x08
00007d3d13bde1bb  jmp 0x00007D3D13BD977A
00007d3d13bde1c0  call 0x00007D3D13A0C260
00007d3d13bde1c5  jmp 0x00007D3D13BD9788
00007d3d13bde1ca  call 0x00007D3D13ADE950
00007d3d13bde1cf  jmp 0x00007D3D13BD9792
00007d3d13bde1d4  sub rsp, 0x08
00007d3d13bde1d8  push rax
00007d3d13bde1d9  push rcx
00007d3d13bde1da  push rdx
00007d3d13bde1db  push rdi
00007d3d13bde1dc  push rsi
00007d3d13bde1dd  push r8
00007d3d13bde1df  push r9
00007d3d13bde1e1  push r10
00007d3d13bde1e3  push r11
00007d3d13bde1e5  sub rsp, 0xF0
00007d3d13bde1ec  vmovaps [rsp], xmm0
00007d3d13bde1f1  vmovaps [rsp+0x10], xmm1
00007d3d13bde1f7  vmovaps [rsp+0x20], xmm2
00007d3d13bde1fd  vmovaps [rsp+0x30], xmm3
00007d3d13bde203  vmovaps [rsp+0x40], xmm4
00007d3d13bde209  vmovaps [rsp+0x50], xmm5
00007d3d13bde20f  vmovaps [rsp+0x60], xmm6
00007d3d13bde215  vmovaps [rsp+0x70], xmm7
00007d3d13bde21b  vmovaps [rsp+0x80], xmm9
00007d3d13bde224  vmovaps [rsp+0x90], xmm10
00007d3d13bde22d  vmovaps [rsp+0xA0], xmm11
00007d3d13bde236  vmovaps [rsp+0xB0], xmm12
00007d3d13bde23f  vmovaps [rsp+0xC0], xmm13
00007d3d13bde248  vmovaps [rsp+0xD0], xmm14
00007d3d13bde251  vmovaps [rsp+0xE0], xmm15
00007d3d13bde25a  sub rsp, 0x30
00007d3d13bde25e  movaps [rsp], xmm8
00007d3d13bde263  movaps [rsp+0x10], xmm15
00007d3d13bde269  movaps [rsp+0x20], xmm7
00007d3d13bde26e  lea rdi, [rsp]
00007d3d13bde272  mov esi, 0x00
00007d3d13bde277  mov rax, 0x5741DAFC8530
00007d3d13bde281  call rax
00007d3d13bde283  movaps xmm8, [rsp]
00007d3d13bde288  add rsp, 0x30
00007d3d13bde28c  vmovaps xmm0, [rsp]
00007d3d13bde291  vmovaps xmm1, [rsp+0x10]
00007d3d13bde297  vmovaps xmm2, [rsp+0x20]
00007d3d13bde29d  vmovaps xmm3, [rsp+0x30]
00007d3d13bde2a3  vmovaps xmm4, [rsp+0x40]
00007d3d13bde2a9  vmovaps xmm5, [rsp+0x50]
00007d3d13bde2af  vmovaps xmm6, [rsp+0x60]
00007d3d13bde2b5  vmovaps xmm7, [rsp+0x70]
00007d3d13bde2bb  vmovaps xmm9, [rsp+0x80]
00007d3d13bde2c4  vmovaps xmm10, [rsp+0x90]
00007d3d13bde2cd  vmovaps xmm11, [rsp+0xA0]
00007d3d13bde2d6  vmovaps xmm12, [rsp+0xB0]
00007d3d13bde2df  vmovaps xmm13, [rsp+0xC0]
00007d3d13bde2e8  vmovaps xmm14, [rsp+0xD0]
00007d3d13bde2f1  vmovaps xmm15, [rsp+0xE0]
00007d3d13bde2fa  add rsp, 0xF0
00007d3d13bde301  pop r11
00007d3d13bde303  pop r10
00007d3d13bde305  pop r9
00007d3d13bde307  pop r8
00007d3d13bde309  pop rsi
00007d3d13bde30a  pop rdi
00007d3d13bde30b  pop rdx
00007d3d13bde30c  pop rcx
00007d3d13bde30d  pop rax
00007d3d13bde30e  add rsp, 0x08
00007d3d13bde312  jmp 0x00007D3D13BD97B4
00007d3d13bde317  sub rsp, 0x08
00007d3d13bde31b  push rax
00007d3d13bde31c  push rcx
00007d3d13bde31d  push rdx
00007d3d13bde31e  push rdi
00007d3d13bde31f  push rsi
00007d3d13bde320  push r8
00007d3d13bde322  push r9
00007d3d13bde324  push r10
00007d3d13bde326  push r11
00007d3d13bde328  sub rsp, 0xF0
00007d3d13bde32f  vmovaps [rsp], xmm0
00007d3d13bde334  vmovaps [rsp+0x10], xmm1
00007d3d13bde33a  vmovaps [rsp+0x20], xmm2
00007d3d13bde340  vmovaps [rsp+0x30], xmm3
00007d3d13bde346  vmovaps [rsp+0x40], xmm4
00007d3d13bde34c  vmovaps [rsp+0x50], xmm5
00007d3d13bde352  vmovaps [rsp+0x60], xmm6
00007d3d13bde358  vmovaps [rsp+0x70], xmm8
00007d3d13bde35e  vmovaps [rsp+0x80], xmm9
00007d3d13bde367  vmovaps [rsp+0x90], xmm10
00007d3d13bde370  vmovaps [rsp+0xA0], xmm11
00007d3d13bde379  vmovaps [rsp+0xB0], xmm12
00007d3d13bde382  vmovaps [rsp+0xC0], xmm13
00007d3d13bde38b  vmovaps [rsp+0xD0], xmm14
00007d3d13bde394  vmovaps [rsp+0xE0], xmm15
00007d3d13bde39d  sub rsp, 0x30
00007d3d13bde3a1  movaps [rsp], xmm7
00007d3d13bde3a5  movaps [rsp+0x10], xmm9
00007d3d13bde3ab  movaps [rsp+0x20], xmm15
00007d3d13bde3b1  lea rdi, [rsp]
00007d3d13bde3b5  mov esi, 0x00
00007d3d13bde3ba  mov rax, 0x5741DAFC8530
00007d3d13bde3c4  call rax
00007d3d13bde3c6  movaps xmm7, [rsp]
00007d3d13bde3ca  add rsp, 0x30
00007d3d13bde3ce  vmovaps xmm0, [rsp]
00007d3d13bde3d3  vmovaps xmm1, [rsp+0x10]
00007d3d13bde3d9  vmovaps xmm2, [rsp+0x20]
00007d3d13bde3df  vmovaps xmm3, [rsp+0x30]
00007d3d13bde3e5  vmovaps xmm4, [rsp+0x40]
00007d3d13bde3eb  vmovaps xmm5, [rsp+0x50]
00007d3d13bde3f1  vmovaps xmm6, [rsp+0x60]
00007d3d13bde3f7  vmovaps xmm8, [rsp+0x70]
00007d3d13bde3fd  vmovaps xmm9, [rsp+0x80]
00007d3d13bde406  vmovaps xmm10, [rsp+0x90]
00007d3d13bde40f  vmovaps xmm11, [rsp+0xA0]
00007d3d13bde418  vmovaps xmm12, [rsp+0xB0]
00007d3d13bde421  vmovaps xmm13, [rsp+0xC0]
00007d3d13bde42a  vmovaps xmm14, [rsp+0xD0]
00007d3d13bde433  vmovaps xmm15, [rsp+0xE0]
00007d3d13bde43c  add rsp, 0xF0
00007d3d13bde443  pop r11
00007d3d13bde445  pop r10
00007d3d13bde447  pop r9
00007d3d13bde449  pop r8
00007d3d13bde44b  pop rsi
00007d3d13bde44c  pop rdi
00007d3d13bde44d  pop rdx
00007d3d13bde44e  pop rcx
00007d3d13bde44f  pop rax
00007d3d13bde450  add rsp, 0x08
00007d3d13bde454  jmp 0x00007D3D13BD97E1
00007d3d13bde459  sub rsp, 0x08
00007d3d13bde45d  push rax
00007d3d13bde45e  push rcx
00007d3d13bde45f  push rdx
00007d3d13bde460  push rdi
00007d3d13bde461  push rsi
00007d3d13bde462  push r8
00007d3d13bde464  push r9
00007d3d13bde466  push r10
00007d3d13bde468  push r11
00007d3d13bde46a  sub rsp, 0xF0
00007d3d13bde471  vmovaps [rsp], xmm0
00007d3d13bde476  vmovaps [rsp+0x10], xmm1
00007d3d13bde47c  vmovaps [rsp+0x20], xmm2
00007d3d13bde482  vmovaps [rsp+0x30], xmm3
00007d3d13bde488  vmovaps [rsp+0x40], xmm4
00007d3d13bde48e  vmovaps [rsp+0x50], xmm5
00007d3d13bde494  vmovaps [rsp+0x60], xmm6
00007d3d13bde49a  vmovaps [rsp+0x70], xmm7
00007d3d13bde4a0  vmovaps [rsp+0x80], xmm8
00007d3d13bde4a9  vmovaps [rsp+0x90], xmm10
00007d3d13bde4b2  vmovaps [rsp+0xA0], xmm11
00007d3d13bde4bb  vmovaps [rsp+0xB0], xmm12
00007d3d13bde4c4  vmovaps [rsp+0xC0], xmm13
00007d3d13bde4cd  vmovaps [rsp+0xD0], xmm14
00007d3d13bde4d6  vmovaps [rsp+0xE0], xmm15
00007d3d13bde4df  sub rsp, 0x30
00007d3d13bde4e3  movaps [rsp], xmm9
00007d3d13bde4e8  movaps [rsp+0x10], xmm13
00007d3d13bde4ee  movaps [rsp+0x20], xmm15
00007d3d13bde4f4  lea rdi, [rsp]
00007d3d13bde4f8  mov esi, 0x00
00007d3d13bde4fd  mov rax, 0x5741DAFC8530
00007d3d13bde507  call rax
00007d3d13bde509  movaps xmm9, [rsp]
00007d3d13bde50e  add rsp, 0x30
00007d3d13bde512  vmovaps xmm0, [rsp]
00007d3d13bde517  vmovaps xmm1, [rsp+0x10]
00007d3d13bde51d  vmovaps xmm2, [rsp+0x20]
00007d3d13bde523  vmovaps xmm3, [rsp+0x30]
00007d3d13bde529  vmovaps xmm4, [rsp+0x40]
00007d3d13bde52f  vmovaps xmm5, [rsp+0x50]
00007d3d13bde535  vmovaps xmm6, [rsp+0x60]
00007d3d13bde53b  vmovaps xmm7, [rsp+0x70]
00007d3d13bde541  vmovaps xmm8, [rsp+0x80]
00007d3d13bde54a  vmovaps xmm10, [rsp+0x90]
00007d3d13bde553  vmovaps xmm11, [rsp+0xA0]
00007d3d13bde55c  vmovaps xmm12, [rsp+0xB0]
00007d3d13bde565  vmovaps xmm13, [rsp+0xC0]
00007d3d13bde56e  vmovaps xmm14, [rsp+0xD0]
00007d3d13bde577  vmovaps xmm15, [rsp+0xE0]
00007d3d13bde580  add rsp, 0xF0
00007d3d13bde587  pop r11
00007d3d13bde589  pop r10
00007d3d13bde58b  pop r9
00007d3d13bde58d  pop r8
00007d3d13bde58f  pop rsi
00007d3d13bde590  pop rdi
00007d3d13bde591  pop rdx
00007d3d13bde592  pop rcx
00007d3d13bde593  pop rax
00007d3d13bde594  add rsp, 0x08
00007d3d13bde598  jmp 0x00007D3D13BD980F
00007d3d13bde59d  sub rsp, 0x08
00007d3d13bde5a1  push rax
00007d3d13bde5a2  push rcx
00007d3d13bde5a3  push rdx
00007d3d13bde5a4  push rdi
00007d3d13bde5a5  push rsi
00007d3d13bde5a6  push r8
00007d3d13bde5a8  push r9
00007d3d13bde5aa  push r10
00007d3d13bde5ac  push r11
00007d3d13bde5ae  sub rsp, 0xF0
00007d3d13bde5b5  vmovaps [rsp], xmm0
00007d3d13bde5ba  vmovaps [rsp+0x10], xmm1
00007d3d13bde5c0  vmovaps [rsp+0x20], xmm2
00007d3d13bde5c6  vmovaps [rsp+0x30], xmm3
00007d3d13bde5cc  vmovaps [rsp+0x40], xmm4
00007d3d13bde5d2  vmovaps [rsp+0x50], xmm5
00007d3d13bde5d8  vmovaps [rsp+0x60], xmm6
00007d3d13bde5de  vmovaps [rsp+0x70], xmm7
00007d3d13bde5e4  vmovaps [rsp+0x80], xmm8
00007d3d13bde5ed  vmovaps [rsp+0x90], xmm9
00007d3d13bde5f6  vmovaps [rsp+0xA0], xmm10
00007d3d13bde5ff  vmovaps [rsp+0xB0], xmm11
00007d3d13bde608  vmovaps [rsp+0xC0], xmm12
00007d3d13bde611  vmovaps [rsp+0xD0], xmm13
00007d3d13bde61a  vmovaps [rsp+0xE0], xmm14
00007d3d13bde623  sub rsp, 0x30
00007d3d13bde627  movaps [rsp], xmm15
00007d3d13bde62c  movaps [rsp+0x10], xmm11
00007d3d13bde632  movaps [rsp+0x20], xmm12
00007d3d13bde638  lea rdi, [rsp]
00007d3d13bde63c  mov esi, 0x00
00007d3d13bde641  mov rax, 0x5741DAFC8530
00007d3d13bde64b  call rax
00007d3d13bde64d  movaps xmm15, [rsp]
00007d3d13bde652  add rsp, 0x30
00007d3d13bde656  vmovaps xmm0, [rsp]
00007d3d13bde65b  vmovaps xmm1, [rsp+0x10]
00007d3d13bde661  vmovaps xmm2, [rsp+0x20]
00007d3d13bde667  vmovaps xmm3, [rsp+0x30]
00007d3d13bde66d  vmovaps xmm4, [rsp+0x40]
00007d3d13bde673  vmovaps xmm5, [rsp+0x50]
00007d3d13bde679  vmovaps xmm6, [rsp+0x60]
00007d3d13bde67f  vmovaps xmm7, [rsp+0x70]
00007d3d13bde685  vmovaps xmm8, [rsp+0x80]
00007d3d13bde68e  vmovaps xmm9, [rsp+0x90]
00007d3d13bde697  vmovaps xmm10, [rsp+0xA0]
00007d3d13bde6a0  vmovaps xmm11, [rsp+0xB0]
00007d3d13bde6a9  vmovaps xmm12, [rsp+0xC0]
00007d3d13bde6b2  vmovaps xmm13, [rsp+0xD0]
00007d3d13bde6bb  vmovaps xmm14, [rsp+0xE0]
00007d3d13bde6c4  add rsp, 0xF0
00007d3d13bde6cb  pop r11
00007d3d13bde6cd  pop r10
00007d3d13bde6cf  pop r9
00007d3d13bde6d1  pop r8
00007d3d13bde6d3  pop rsi
00007d3d13bde6d4  pop rdi
00007d3d13bde6d5  pop rdx
00007d3d13bde6d6  pop rcx
00007d3d13bde6d7  pop rax
00007d3d13bde6d8  add rsp, 0x08
00007d3d13bde6dc  jmp 0x00007D3D13BD982A
00007d3d13bde6e1  sub rsp, 0x08
00007d3d13bde6e5  push rax
00007d3d13bde6e6  push rcx
00007d3d13bde6e7  push rdx
00007d3d13bde6e8  push rdi
00007d3d13bde6e9  push rsi
00007d3d13bde6ea  push r8
00007d3d13bde6ec  push r9
00007d3d13bde6ee  push r10
00007d3d13bde6f0  push r11
00007d3d13bde6f2  sub rsp, 0xF0
00007d3d13bde6f9  vmovaps [rsp], xmm0
00007d3d13bde6fe  vmovaps [rsp+0x10], xmm1
00007d3d13bde704  vmovaps [rsp+0x20], xmm2
00007d3d13bde70a  vmovaps [rsp+0x30], xmm3
00007d3d13bde710  vmovaps [rsp+0x40], xmm4
00007d3d13bde716  vmovaps [rsp+0x50], xmm5
00007d3d13bde71c  vmovaps [rsp+0x60], xmm6
00007d3d13bde722  vmovaps [rsp+0x70], xmm7
00007d3d13bde728  vmovaps [rsp+0x80], xmm8
00007d3d13bde731  vmovaps [rsp+0x90], xmm9
00007d3d13bde73a  vmovaps [rsp+0xA0], xmm10
00007d3d13bde743  vmovaps [rsp+0xB0], xmm11
00007d3d13bde74c  vmovaps [rsp+0xC0], xmm12
00007d3d13bde755  vmovaps [rsp+0xD0], xmm14
00007d3d13bde75e  vmovaps [rsp+0xE0], xmm15
00007d3d13bde767  sub rsp, 0x30
00007d3d13bde76b  movaps [rsp], xmm13
00007d3d13bde770  movaps [rsp+0x10], xmm10
00007d3d13bde776  movaps [rsp+0x20], xmm14
00007d3d13bde77c  lea rdi, [rsp]
00007d3d13bde780  mov esi, 0x00
00007d3d13bde785  mov rax, 0x5741DAFC8530
00007d3d13bde78f  call rax
00007d3d13bde791  movaps xmm13, [rsp]
00007d3d13bde796  add rsp, 0x30
00007d3d13bde79a  vmovaps xmm0, [rsp]
00007d3d13bde79f  vmovaps xmm1, [rsp+0x10]
00007d3d13bde7a5  vmovaps xmm2, [rsp+0x20]
00007d3d13bde7ab  vmovaps xmm3, [rsp+0x30]
00007d3d13bde7b1  vmovaps xmm4, [rsp+0x40]
00007d3d13bde7b7  vmovaps xmm5, [rsp+0x50]
00007d3d13bde7bd  vmovaps xmm6, [rsp+0x60]
00007d3d13bde7c3  vmovaps xmm7, [rsp+0x70]
00007d3d13bde7c9  vmovaps xmm8, [rsp+0x80]
00007d3d13bde7d2  vmovaps xmm9, [rsp+0x90]
00007d3d13bde7db  vmovaps xmm10, [rsp+0xA0]
00007d3d13bde7e4  vmovaps xmm11, [rsp+0xB0]
00007d3d13bde7ed  vmovaps xmm12, [rsp+0xC0]
00007d3d13bde7f6  vmovaps xmm14, [rsp+0xD0]
00007d3d13bde7ff  vmovaps xmm15, [rsp+0xE0]
00007d3d13bde808  add rsp, 0xF0
00007d3d13bde80f  pop r11
00007d3d13bde811  pop r10
00007d3d13bde813  pop r9
00007d3d13bde815  pop r8
00007d3d13bde817  pop rsi
00007d3d13bde818  pop rdi
00007d3d13bde819  pop rdx
00007d3d13bde81a  pop rcx
00007d3d13bde81b  pop rax
00007d3d13bde81c  add rsp, 0x08
00007d3d13bde820  jmp 0x00007D3D13BD984D
00007d3d13bde825  sub rsp, 0x08
00007d3d13bde829  push rax
00007d3d13bde82a  push rcx
00007d3d13bde82b  push rdx
00007d3d13bde82c  push rdi
00007d3d13bde82d  push rsi
00007d3d13bde82e  push r8
00007d3d13bde830  push r9
00007d3d13bde832  push r10
00007d3d13bde834  push r11
00007d3d13bde836  sub rsp, 0xF0
00007d3d13bde83d  vmovaps [rsp], xmm0
00007d3d13bde842  vmovaps [rsp+0x10], xmm1
00007d3d13bde848  vmovaps [rsp+0x20], xmm2
00007d3d13bde84e  vmovaps [rsp+0x30], xmm3
00007d3d13bde854  vmovaps [rsp+0x40], xmm4
00007d3d13bde85a  vmovaps [rsp+0x50], xmm5
00007d3d13bde860  vmovaps [rsp+0x60], xmm6
00007d3d13bde866  vmovaps [rsp+0x70], xmm7
00007d3d13bde86c  vmovaps [rsp+0x80], xmm8
00007d3d13bde875  vmovaps [rsp+0x90], xmm9
00007d3d13bde87e  vmovaps [rsp+0xA0], xmm10
00007d3d13bde887  vmovaps [rsp+0xB0], xmm11
00007d3d13bde890  vmovaps [rsp+0xC0], xmm12
00007d3d13bde899  vmovaps [rsp+0xD0], xmm13
00007d3d13bde8a2  vmovaps [rsp+0xE0], xmm15
00007d3d13bde8ab  sub rsp, 0x30
00007d3d13bde8af  movaps [rsp], xmm14
00007d3d13bde8b4  movaps [rsp+0x10], xmm1
00007d3d13bde8b9  movaps [rsp+0x20], xmm7
00007d3d13bde8be  lea rdi, [rsp]
00007d3d13bde8c2  mov esi, 0x00
00007d3d13bde8c7  mov rax, 0x5741DAFC8530
00007d3d13bde8d1  call rax
00007d3d13bde8d3  movaps xmm14, [rsp]
00007d3d13bde8d8  add rsp, 0x30
00007d3d13bde8dc  vmovaps xmm0, [rsp]
00007d3d13bde8e1  vmovaps xmm1, [rsp+0x10]
00007d3d13bde8e7  vmovaps xmm2, [rsp+0x20]
00007d3d13bde8ed  vmovaps xmm3, [rsp+0x30]
00007d3d13bde8f3  vmovaps xmm4, [rsp+0x40]
00007d3d13bde8f9  vmovaps xmm5, [rsp+0x50]
00007d3d13bde8ff  vmovaps xmm6, [rsp+0x60]
00007d3d13bde905  vmovaps xmm7, [rsp+0x70]
00007d3d13bde90b  vmovaps xmm8, [rsp+0x80]
00007d3d13bde914  vmovaps xmm9, [rsp+0x90]
00007d3d13bde91d  vmovaps xmm10, [rsp+0xA0]
00007d3d13bde926  vmovaps xmm11, [rsp+0xB0]
00007d3d13bde92f  vmovaps xmm12, [rsp+0xC0]
00007d3d13bde938  vmovaps xmm13, [rsp+0xD0]
00007d3d13bde941  vmovaps xmm15, [rsp+0xE0]
00007d3d13bde94a  add rsp, 0xF0
00007d3d13bde951  pop r11
00007d3d13bde953  pop r10
00007d3d13bde955  pop r9
00007d3d13bde957  pop r8
00007d3d13bde959  pop rsi
00007d3d13bde95a  pop rdi
00007d3d13bde95b  pop rdx
00007d3d13bde95c  pop rcx
00007d3d13bde95d  pop rax
00007d3d13bde95e  add rsp, 0x08
00007d3d13bde962  jmp 0x00007D3D13BD9870
00007d3d13bde967  sub rsp, 0x08
00007d3d13bde96b  push rax
00007d3d13bde96c  push rcx
00007d3d13bde96d  push rdx
00007d3d13bde96e  push rdi
00007d3d13bde96f  push rsi
00007d3d13bde970  push r8
00007d3d13bde972  push r9
00007d3d13bde974  push r10
00007d3d13bde976  push r11
00007d3d13bde978  sub rsp, 0xF0
00007d3d13bde97f  vmovaps [rsp], xmm0
00007d3d13bde984  vmovaps [rsp+0x10], xmm2
00007d3d13bde98a  vmovaps [rsp+0x20], xmm3
00007d3d13bde990  vmovaps [rsp+0x30], xmm4
00007d3d13bde996  vmovaps [rsp+0x40], xmm5
00007d3d13bde99c  vmovaps [rsp+0x50], xmm6
00007d3d13bde9a2  vmovaps [rsp+0x60], xmm7
00007d3d13bde9a8  vmovaps [rsp+0x70], xmm8
00007d3d13bde9ae  vmovaps [rsp+0x80], xmm9
00007d3d13bde9b7  vmovaps [rsp+0x90], xmm10
00007d3d13bde9c0  vmovaps [rsp+0xA0], xmm11
00007d3d13bde9c9  vmovaps [rsp+0xB0], xmm12
00007d3d13bde9d2  vmovaps [rsp+0xC0], xmm13
00007d3d13bde9db  vmovaps [rsp+0xD0], xmm14
00007d3d13bde9e4  vmovaps [rsp+0xE0], xmm15
00007d3d13bde9ed  sub rsp, 0x30
00007d3d13bde9f1  movaps [rsp], xmm1
00007d3d13bde9f5  movaps [rsp+0x10], xmm8
00007d3d13bde9fb  movaps [rsp+0x20], xmm9
00007d3d13bdea01  lea rdi, [rsp]
00007d3d13bdea05  mov esi, 0x00
00007d3d13bdea0a  mov rax, 0x5741DAFC8530
00007d3d13bdea14  call rax
00007d3d13bdea16  movaps xmm1, [rsp]
00007d3d13bdea1a  add rsp, 0x30
00007d3d13bdea1e  vmovaps xmm0, [rsp]
00007d3d13bdea23  vmovaps xmm2, [rsp+0x10]
00007d3d13bdea29  vmovaps xmm3, [rsp+0x20]
00007d3d13bdea2f  vmovaps xmm4, [rsp+0x30]
00007d3d13bdea35  vmovaps xmm5, [rsp+0x40]
00007d3d13bdea3b  vmovaps xmm6, [rsp+0x50]
00007d3d13bdea41  vmovaps xmm7, [rsp+0x60]
00007d3d13bdea47  vmovaps xmm8, [rsp+0x70]
00007d3d13bdea4d  vmovaps xmm9, [rsp+0x80]
00007d3d13bdea56  vmovaps xmm10, [rsp+0x90]
00007d3d13bdea5f  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdea68  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdea71  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdea7a  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdea83  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdea8c  add rsp, 0xF0
00007d3d13bdea93  pop r11
00007d3d13bdea95  pop r10
00007d3d13bdea97  pop r9
00007d3d13bdea99  pop r8
00007d3d13bdea9b  pop rsi
00007d3d13bdea9c  pop rdi
00007d3d13bdea9d  pop rdx
00007d3d13bdea9e  pop rcx
00007d3d13bdea9f  pop rax
00007d3d13bdeaa0  add rsp, 0x08
00007d3d13bdeaa4  jmp 0x00007D3D13BD9892
00007d3d13bdeaa9  call 0x00007D3D13AB3E40
00007d3d13bdeaae  jmp 0x00007D3D13BD98A0
00007d3d13bdeab3  call 0x00007D3D13A0C380
00007d3d13bdeab8  jmp 0x00007D3D13BD98AA
00007d3d13bdeabd  call 0x00007D3D13A0D600
00007d3d13bdeac2  jmp 0x00007D3D13BD98B4
00007d3d13bdeac7  call 0x00007D3D139FF540
00007d3d13bdeacc  jmp 0x00007D3D13BD98BE
00007d3d13bdead1  int3
00007d3d13bdead2  nop [rax+rax*1], ax
00007d3d13bdeadb  nop [rax+rax*1], eax
00007d3d13bdeae0  mov eax, [r15+0x48]
00007d3d13bdeae4  lea r14d, [eax+0x01]
00007d3d13bdeae9  mov [rsp+0x10], r14d
00007d3d13bdeaee  mov r14d, r14d
00007d3d13bdeaf1  mov [r15+0x48], r14
00007d3d13bdeaf5  xor eax, eax
00007d3d13bdeaf7  mov r14d, [rsp+0x10]
00007d3d13bdeafc  cmp r14d, 0x1F4
00007d3d13bdeb03  cmc
00007d3d13bdeb04  lahf
00007d3d13bdeb05  seto al
00007d3d13bdeb08  mov [r15+0x108], eax
00007d3d13bdeb0f  mov eax, [r15+0x108]
00007d3d13bdeb16  sahf
00007d3d13bdeb17  jnz 0x00007D3D13BDEB49
00007d3d13bdeb19  cmp dword ptr [r15+0x318], 0x00
00007d3d13bdeb21  jz 0x00007D3D13BE4C90
00007d3d13bdeb27  nop [rax+rax*1], ax
00007d3d13bdeb30  nop [rax+rax*1], eax
00007d3d13bdeb38  mov eax, 0x4106DC
00007d3d13bdeb3d  mov [r15+0x100], rax
00007d3d13bdeb44  jmp 0x00007D3D139FE110
00007d3d13bdeb49  cmp dword ptr [r15+0x318], 0x00
00007d3d13bdeb51  jz 0x00007D3D13BDEB80
00007d3d13bdeb57  nop [rax+rax*1], ax
00007d3d13bdeb60  nop [rax+rax*1], eax
00007d3d13bdeb68  mov eax, 0x410500
00007d3d13bdeb6d  mov [r15+0x100], rax
00007d3d13bdeb74  jmp 0x00007D3D139FE110
00007d3d13bdeb79  int3
00007d3d13bdeb7a  int3
00007d3d13bdeb7b  nop [rax+rax*1], eax
00007d3d13bdeb80  mov rax, [r15+0x40]
00007d3d13bdeb84  movaps xmm1, [r15+0x1D0]
00007d3d13bdeb8c  vmovaps [rsp+0x10], xmm1
00007d3d13bdeb92  vmovaps xmm15, [rsp+0x10]
00007d3d13bdeb98  por xmm1, xmm15
00007d3d13bdeb9d  movaps xmm14, [r15+0x1A0]
00007d3d13bdeba5  vmovaps [rsp+0x10], xmm14
00007d3d13bdebab  vmovaps xmm13, [rsp+0x10]
00007d3d13bdebb1  por xmm14, xmm13
00007d3d13bdebb6  lea r14, [rax+0x30]
00007d3d13bdebba  mov r12, [r13+r14*1]
00007d3d13bdebbf  lea r14, [rax+0x38]
00007d3d13bdebc3  mov r11, [r13+r14*1]
00007d3d13bdebc8  movq xmm13, r12
00007d3d13bdebcd  movq xmm12, r11
00007d3d13bdebd2  movq xmm13, xmm13
00007d3d13bdebd7  vmovaps [rsp+0x10], xmm13
00007d3d13bdebdd  movq xmm13, xmm13
00007d3d13bdebe2  movaps [r15+0x130], xmm13
00007d3d13bdebea  movq xmm12, xmm12
00007d3d13bdebef  vmovaps [rsp+0x20], xmm12
00007d3d13bdebf5  movq xmm12, xmm12
00007d3d13bdebfa  movaps [r15+0x280], xmm12
00007d3d13bdec02  movaps xmm13, [r15+0x270]
00007d3d13bdec0a  vmovaps [rsp+0x30], xmm13
00007d3d13bdec10  vmovaps xmm12, [rsp+0x30]
00007d3d13bdec16  por xmm13, xmm12
00007d3d13bdec1b  lea r14, [rax+0x20]
00007d3d13bdec1f  mov r12, [r13+r14*1]
00007d3d13bdec24  lea r14, [rax+0x28]
00007d3d13bdec28  mov r11, [r13+r14*1]
00007d3d13bdec2d  movq xmm12, r12
00007d3d13bdec32  movq xmm11, r11
00007d3d13bdec37  movq xmm12, xmm12
00007d3d13bdec3c  vmovaps [rsp+0x30], xmm12
00007d3d13bdec42  movq xmm12, xmm12
00007d3d13bdec47  movaps [r15+0x150], xmm12
00007d3d13bdec4f  movq xmm11, xmm11
00007d3d13bdec54  vmovaps [rsp+0x40], xmm11
00007d3d13bdec5a  movq xmm11, xmm11
00007d3d13bdec5f  movaps [r15+0x140], xmm11
00007d3d13bdec67  lea r14, [rax+0x10]
00007d3d13bdec6b  mov r12, [r13+r14*1]
00007d3d13bdec70  lea r14, [rax+0x18]
00007d3d13bdec74  mov r11, [r13+r14*1]
00007d3d13bdec79  movq xmm12, r12
00007d3d13bdec7e  movq xmm11, r11
00007d3d13bdec83  movq xmm12, xmm12
00007d3d13bdec88  vmovaps [rsp+0x50], xmm12
00007d3d13bdec8e  movq xmm12, xmm12
00007d3d13bdec93  movaps [r15+0x170], xmm12
00007d3d13bdec9b  movq xmm11, xmm11
00007d3d13bdeca0  vmovaps [rsp+0x60], xmm11
00007d3d13bdeca6  movq xmm11, xmm11
00007d3d13bdecab  movaps [r15+0x160], xmm11
00007d3d13bdecb3  mov r14, [r13+rax*1]
00007d3d13bdecb8  vmovq xmm12, r14
00007d3d13bdecbd  vpbroadcastq xmm12, xmm12
00007d3d13bdecc2  lea r14, [rax+0x08]
00007d3d13bdecc6  mov rax, [r13+r14*1]
00007d3d13bdeccb  movq xmm11, rax
00007d3d13bdecd0  movaps [r15+0x230], xmm11
00007d3d13bdecd8  mov rax, [r15+0xF8]
00007d3d13bdecdf  lea r14, [rax+0x50]
00007d3d13bdece3  movups xmm11, [r13+r14*1]
00007d3d13bdece9  lea r14, [rax+0x60]
00007d3d13bdeced  movups xmm10, [r13+r14*1]
00007d3d13bdecf3  lea r14, [rax+0x30]
00007d3d13bdecf7  movups xmm9, [r13+r14*1]
00007d3d13bdecfd  mov r14, [r15+0x50]
00007d3d13bded01  mov [r15+0x60], r14
00007d3d13bded05  mov qword ptr [r15+0x58], 0x40
00007d3d13bded0d  movaps xmm8, xmm12
00007d3d13bded11  mulpd xmm8, xmm15
00007d3d13bded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d13bded1c  ptest xmm7, xmm7
00007d3d13bded21  jnz 0x00007D3D13BDFB4A
00007d3d13bded27  movq xmm15, qword ptr [r15+0x230]
00007d3d13bded30  vmovaps [rsp+0x70], xmm15
00007d3d13bded36  vpermilpd xmm15, xmm15, 0x00
00007d3d13bded3c  movaps xmm7, xmm9
00007d3d13bded40  mulpd xmm7, xmm15
00007d3d13bded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d13bded4a  ptest xmm6, xmm6
00007d3d13bded4f  jnz 0x00007D3D13BDFC8E
00007d3d13bded55  vxorps xmm15, xmm15, xmm15
00007d3d13bded5a  vpbroadcastq xmm15, xmm15
00007d3d13bded5f  movaps xmm9, xmm12
00007d3d13bded63  mulpd xmm9, xmm10
00007d3d13bded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d13bded6e  ptest xmm6, xmm6
00007d3d13bded73  jnz 0x00007D3D13BDFDD0
00007d3d13bded79  movaps xmm10, xmm12
00007d3d13bded7d  mulpd xmm10, xmm11
00007d3d13bded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007d3d13bded88  ptest xmm6, xmm6
00007d3d13bded8d  jnz 0x00007D3D13BDFF14
00007d3d13bded93  movaps xmm11, [r15+0x1F0]
00007d3d13bded9b  movaps xmm6, xmm12
00007d3d13bded9f  mulpd xmm6, xmm11
00007d3d13bdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d13bdeda9  ptest xmm5, xmm5
00007d3d13bdedae  jnz 0x00007D3D13BE0058
00007d3d13bdedb4  movaps xmm12, [r15+0x2A0]
00007d3d13bdedbc  vmovaps [rsp+0x80], xmm12
00007d3d13bdedc5  vmovaps xmm11, [rsp+0x80]
00007d3d13bdedce  por xmm12, xmm11
00007d3d13bdedd3  movaps xmm11, [r15+0x250]
00007d3d13bdeddb  vmovaps [rsp+0x80], xmm11
00007d3d13bdede4  vmovaps xmm5, [rsp+0x80]
00007d3d13bdeded  por xmm11, xmm5
00007d3d13bdedf2  vmovaps xmm4, [rsp+0x70]
00007d3d13bdedf8  vpermilpd xmm4, xmm4, 0x00
00007d3d13bdedfe  movaps xmm3, xmm5
00007d3d13bdee01  mulpd xmm3, xmm4
00007d3d13bdee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007d3d13bdee0a  ptest xmm2, xmm2
00007d3d13bdee0f  jnz 0x00007D3D13BE019A
00007d3d13bdee15  mov [rsp+0x80], rax
00007d3d13bdee1d  xor eax, eax
00007d3d13bdee1f  mov r12d, 0x40
00007d3d13bdee25  mov r11d, 0x200
00007d3d13bdee2b  cmp r12, r11
00007d3d13bdee2e  cmc
00007d3d13bdee2f  lahf
00007d3d13bdee30  seto al
00007d3d13bdee33  mov [r15+0x108], eax
00007d3d13bdee3a  movaps xmm5, xmm8
00007d3d13bdee3e  addpd xmm5, xmm15
00007d3d13bdee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007d3d13bdee48  ptest xmm4, xmm4
00007d3d13bdee4d  jnz 0x00007D3D13BE02DA
00007d3d13bdee53  movaps xmm8, [r15+0x1B0]
00007d3d13bdee5b  movaps xmm4, xmm9
00007d3d13bdee5f  addpd xmm4, xmm8
00007d3d13bdee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007d3d13bdee69  ptest xmm2, xmm2
00007d3d13bdee6e  jnz 0x00007D3D13BE041C
00007d3d13bdee74  movaps xmm9, xmm10
00007d3d13bdee78  addpd xmm9, xmm8
00007d3d13bdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d3d13bdee83  ptest xmm2, xmm2
00007d3d13bdee88  jnz 0x00007D3D13BE055E
00007d3d13bdee8e  movaps xmm10, [r15+0x2F0]
00007d3d13bdee96  vmovaps [rsp+0x90], xmm10
00007d3d13bdee9f  vmovaps xmm8, [rsp+0x90]
00007d3d13bdeea8  por xmm10, xmm8
00007d3d13bdeead  movaps xmm8, [r15+0x2E0]
00007d3d13bdeeb5  vmovaps [rsp+0x90], xmm8
00007d3d13bdeebe  vmovaps xmm2, [rsp+0x90]
00007d3d13bdeec7  por xmm8, xmm2
00007d3d13bdeecc  movaps xmm2, [r15+0x2D0]
00007d3d13bdeed4  vmovaps [rsp+0x90], xmm2
00007d3d13bdeedd  vmovaps [rsp+0xA0], xmm1
00007d3d13bdeee6  vmovaps xmm1, [rsp+0x90]
00007d3d13bdeeef  por xmm2, xmm1
00007d3d13bdeef3  movaps xmm1, [r15+0x200]
00007d3d13bdeefb  vmovaps [rsp+0x90], xmm1
00007d3d13bdef04  vmovaps [rsp+0xB0], xmm15
00007d3d13bdef0d  vmovaps xmm15, [rsp+0x90]
00007d3d13bdef16  por xmm1, xmm15
00007d3d13bdef1b  movaps xmm15, [r15+0x1C0]
00007d3d13bdef23  vmovaps [rsp+0x90], xmm15
00007d3d13bdef2c  vmovaps [rsp+0xC0], xmm1
00007d3d13bdef35  vmovaps xmm1, [rsp+0x90]
00007d3d13bdef3e  por xmm15, xmm1
00007d3d13bdef43  movaps xmm1, [r15+0x190]
00007d3d13bdef4b  vmovaps [rsp+0x90], xmm1
00007d3d13bdef54  vmovaps [rsp+0xD0], xmm15
00007d3d13bdef5d  vmovaps xmm15, [rsp+0x90]
00007d3d13bdef66  por xmm1, xmm15
00007d3d13bdef6b  movaps xmm15, [r15+0x300]
00007d3d13bdef73  vmovaps [rsp+0x90], xmm15
00007d3d13bdef7c  vmovaps [rsp+0xE0], xmm1
00007d3d13bdef85  vmovaps xmm1, [rsp+0x90]
00007d3d13bdef8e  por xmm15, xmm1
00007d3d13bdef93  mov rax, [rsp+0x80]
00007d3d13bdef9b  lea r12, [rax+0xA0]
00007d3d13bdefa2  movups xmm1, [r13+r12*1]
00007d3d13bdefa8  lea r12, [rax+0xB0]
00007d3d13bdefaf  vmovaps [rsp+0x80], xmm1
00007d3d13bdefb8  movups xmm1, [r13+r12*1]
00007d3d13bdefbe  vmovaps [rsp+0x90], xmm1
00007d3d13bdefc7  vmovaps [rsp+0xF0], xmm15
00007d3d13bdefd0  vmovaps xmm15, [rsp+0xB0]
00007d3d13bdefd9  vmovaps [rsp+0xB0], xmm14
00007d3d13bdefe2  movaps xmm1, xmm6
00007d3d13bdefe5  addpd xmm1, xmm15
00007d3d13bdefea  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d13bdefef  ptest xmm14, xmm14
00007d3d13bdeff5  jnz 0x00007D3D13BE06B6
00007d3d13bdeffb  lea r12, [rax+0xF0]
00007d3d13bdf002  movups xmm15, [r13+r12*1]
00007d3d13bdf008  movaps xmm14, xmm4
00007d3d13bdf00c  addpd xmm14, xmm3
00007d3d13bdf011  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d13bdf017  ptest xmm6, xmm6
00007d3d13bdf01c  jnz 0x00007D3D13BE0801
00007d3d13bdf022  movaps xmm6, xmm9
00007d3d13bdf026  addpd xmm6, xmm7
00007d3d13bdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d3d13bdf02f  ptest xmm4, xmm4
00007d3d13bdf034  jnz 0x00007D3D13BE0943
00007d3d13bdf03a  vmovaps xmm9, [rsp+0x70]
00007d3d13bdf040  vpermilpd xmm9, xmm9, 0x00
00007d3d13bdf046  vmovaps xmm4, [rsp+0x90]
00007d3d13bdf04f  movaps xmm7, xmm4
00007d3d13bdf052  mulpd xmm7, xmm9
00007d3d13bdf057  vcmppd xmm3, xmm7, xmm7, 0x03
00007d3d13bdf05c  ptest xmm3, xmm3
00007d3d13bdf061  jnz 0x00007D3D13BE0A84
00007d3d13bdf067  vmovaps xmm9, [rsp+0x50]
00007d3d13bdf06d  vpermilpd xmm9, xmm9, 0x00
00007d3d13bdf073  movaps xmm4, xmm15
00007d3d13bdf077  mulpd xmm4, xmm9
00007d3d13bdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d3d13bdf081  ptest xmm3, xmm3
00007d3d13bdf086  jnz 0x00007D3D13BE0BC5
00007d3d13bdf08c  lea r12, [rax+0xE0]
00007d3d13bdf093  movups xmm15, [r13+r12*1]
00007d3d13bdf099  vmovaps xmm9, [rsp+0x70]
00007d3d13bdf09f  vpermilpd xmm9, xmm9, 0x00
00007d3d13bdf0a5  vmovaps [rsp+0x70], xmm1
00007d3d13bdf0ab  vmovaps xmm1, [rsp+0x80]
00007d3d13bdf0b4  vmovaps [rsp+0x80], xmm15
00007d3d13bdf0bd  movaps xmm3, xmm1
00007d3d13bdf0c0  mulpd xmm3, xmm9
00007d3d13bdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d3d13bdf0ca  ptest xmm15, xmm15
00007d3d13bdf0d0  jnz 0x00007D3D13BE0D11
00007d3d13bdf0d6  vmovaps xmm1, [rsp+0xF0]
00007d3d13bdf0df  vmovaps xmm15, [rsp+0xF0]
00007d3d13bdf0e8  por xmm1, xmm15
00007d3d13bdf0ed  movaps [r15+0x300], xmm1
00007d3d13bdf0f5  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdf0fe  vmovaps xmm9, [rsp+0xE0]
00007d3d13bdf107  por xmm15, xmm9
00007d3d13bdf10c  movaps [r15+0x190], xmm15
00007d3d13bdf114  vmovaps xmm9, [rsp+0x50]
00007d3d13bdf11a  vpermilpd xmm9, xmm9, 0x00
00007d3d13bdf120  vmovaps [rsp+0x90], xmm1
00007d3d13bdf129  vmovaps [rsp+0xE0], xmm15
00007d3d13bdf132  vmovaps xmm15, [rsp+0x80]
00007d3d13bdf13b  vmovaps [rsp+0x80], xmm14
00007d3d13bdf144  movaps xmm1, xmm15
00007d3d13bdf148  mulpd xmm1, xmm9
00007d3d13bdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d13bdf152  ptest xmm14, xmm14
00007d3d13bdf158  jnz 0x00007D3D13BE0E52
00007d3d13bdf15e  lea r12, [rax+0x90]
00007d3d13bdf165  movups xmm15, [r13+r12*1]
00007d3d13bdf16b  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdf174  vmovaps xmm9, [rsp+0xD0]
00007d3d13bdf17d  por xmm14, xmm9
00007d3d13bdf182  movaps [r15+0x1C0], xmm14
00007d3d13bdf18a  vmovaps xmm9, [rsp+0xC0]
00007d3d13bdf193  vmovaps [rsp+0xD0], xmm1
00007d3d13bdf19c  vmovaps xmm1, [rsp+0xC0]
00007d3d13bdf1a5  por xmm9, xmm1
00007d3d13bdf1aa  movaps [r15+0x200], xmm9
00007d3d13bdf1b2  vmovaps [rsp+0xC0], xmm2
00007d3d13bdf1bb  vmovaps xmm1, [rsp+0xC0]
00007d3d13bdf1c4  por xmm2, xmm1
00007d3d13bdf1c8  movaps [r15+0x2D0], xmm2
00007d3d13bdf1d0  vmovaps [rsp+0xC0], xmm8
00007d3d13bdf1d9  vmovaps xmm1, [rsp+0xC0]
00007d3d13bdf1e2  por xmm8, xmm1
00007d3d13bdf1e7  movaps [r15+0x2E0], xmm8
00007d3d13bdf1ef  vmovaps [rsp+0xC0], xmm15
00007d3d13bdf1f8  movaps xmm1, xmm5
00007d3d13bdf1fb  addpd xmm1, xmm7
00007d3d13bdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d13bdf204  ptest xmm15, xmm15
00007d3d13bdf20a  jnz 0x00007D3D13BE0F9E
00007d3d13bdf210  vmovaps xmm15, [rsp+0x50]
00007d3d13bdf216  vpermilpd xmm15, xmm15, 0x00
00007d3d13bdf21c  vmovaps xmm5, [rsp+0xC0]
00007d3d13bdf225  vmovaps [rsp+0xC0], xmm1
00007d3d13bdf22e  movaps xmm7, xmm5
00007d3d13bdf231  mulpd xmm7, xmm15
00007d3d13bdf236  vcmppd xmm1, xmm7, xmm7, 0x03
00007d3d13bdf23b  ptest xmm1, xmm1
00007d3d13bdf240  jnz 0x00007D3D13BE10DE
00007d3d13bdf246  lea r12, [rax+0x80]
00007d3d13bdf24d  movups xmm1, [r13+r12*1]
00007d3d13bdf253  vmovaps xmm5, [rsp+0x70]
00007d3d13bdf259  vmovaps [rsp+0x70], xmm1
00007d3d13bdf25f  movaps xmm15, xmm5
00007d3d13bdf263  addpd xmm15, xmm3
00007d3d13bdf268  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d13bdf26e  ptest xmm1, xmm1
00007d3d13bdf273  jnz 0x00007D3D13BE1229
00007d3d13bdf279  vmovaps xmm5, [rsp+0x80]
00007d3d13bdf282  movaps xmm1, xmm5
00007d3d13bdf285  addpd xmm1, xmm4
00007d3d13bdf289  vcmppd xmm3, xmm1, xmm1, 0x03
00007d3d13bdf28e  ptest xmm3, xmm3
00007d3d13bdf293  jnz 0x00007D3D13BE136B
00007d3d13bdf299  vmovaps [rsp+0x80], xmm10
00007d3d13bdf2a2  vmovaps xmm5, [rsp+0x80]
00007d3d13bdf2ab  por xmm10, xmm5
00007d3d13bdf2b0  movaps [r15+0x2F0], xmm10
00007d3d13bdf2b8  vmovaps xmm5, [rsp+0x50]
00007d3d13bdf2be  vpermilpd xmm5, xmm5, 0x00
00007d3d13bdf2c4  vmovaps xmm3, [rsp+0x70]
00007d3d13bdf2ca  vmovaps [rsp+0x50], xmm1
00007d3d13bdf2d0  movaps xmm4, xmm3
00007d3d13bdf2d3  mulpd xmm4, xmm5
00007d3d13bdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d3d13bdf2dc  ptest xmm1, xmm1
00007d3d13bdf2e1  jnz 0x00007D3D13BE14AB
00007d3d13bdf2e7  lea r12, [rax+0xD0]
00007d3d13bdf2ee  movups xmm1, [r13+r12*1]
00007d3d13bdf2f4  vmovaps xmm3, [rsp+0xD0]
00007d3d13bdf2fd  vmovaps [rsp+0x70], xmm1
00007d3d13bdf303  movaps xmm5, xmm6
00007d3d13bdf306  addpd xmm5, xmm3
00007d3d13bdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d3d13bdf30f  ptest xmm1, xmm1
00007d3d13bdf314  jnz 0x00007D3D13BE15F5
00007d3d13bdf31a  vmovaps xmm1, [rsp+0x60]
00007d3d13bdf320  vpermilpd xmm1, xmm1, 0x00
00007d3d13bdf326  movaps xmm6, xmm9
00007d3d13bdf32a  mulpd xmm6, xmm1
00007d3d13bdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d3d13bdf333  ptest xmm3, xmm3
00007d3d13bdf338  jnz 0x00007D3D13BE1735
00007d3d13bdf33e  movaps [r15+0x260], xmm6
00007d3d13bdf346  vxorps xmm1, xmm1, xmm1
00007d3d13bdf34a  vpbroadcastq xmm1, xmm1
00007d3d13bdf34f  movaps [r15+0x1B0], xmm1
00007d3d13bdf357  vmovaps xmm1, [rsp+0x60]
00007d3d13bdf35d  vpermilpd xmm1, xmm1, 0x00
00007d3d13bdf363  vmovaps xmm3, [rsp+0x70]
00007d3d13bdf369  vmovaps [rsp+0x70], xmm15
00007d3d13bdf36f  movaps xmm9, xmm3
00007d3d13bdf373  mulpd xmm9, xmm1
00007d3d13bdf378  vcmppd xmm15, xmm9, xmm9, 0x03
00007d3d13bdf37e  ptest xmm15, xmm15
00007d3d13bdf384  jnz 0x00007D3D13BE1876
00007d3d13bdf38a  lea r12, [rax+0xC0]
00007d3d13bdf391  movups xmm1, [r13+r12*1]
00007d3d13bdf397  vmovaps xmm3, [rsp+0xC0]
00007d3d13bdf3a0  vmovaps [rsp+0x80], xmm1
00007d3d13bdf3a9  movaps xmm15, xmm3
00007d3d13bdf3ad  addpd xmm15, xmm7
00007d3d13bdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d13bdf3b8  ptest xmm1, xmm1
00007d3d13bdf3bd  jnz 0x00007D3D13BE19C2
00007d3d13bdf3c3  vmovaps [rsp+0xC0], xmm13
00007d3d13bdf3cc  vmovaps xmm1, [rsp+0xC0]
00007d3d13bdf3d5  por xmm13, xmm1
00007d3d13bdf3da  movaps [r15+0x270], xmm13
00007d3d13bdf3e2  vmovaps xmm1, [rsp+0xB0]
00007d3d13bdf3eb  vmovaps xmm7, [rsp+0xB0]
00007d3d13bdf3f4  por xmm1, xmm7
00007d3d13bdf3f8  movaps [r15+0x1A0], xmm1
00007d3d13bdf400  vmovaps xmm1, [rsp+0x60]
00007d3d13bdf406  vpermilpd xmm1, xmm1, 0x00
00007d3d13bdf40c  vmovaps [rsp+0xB0], xmm1
00007d3d13bdf415  vmovaps xmm1, [rsp+0x80]
00007d3d13bdf41e  vmovaps [rsp+0x80], xmm15
00007d3d13bdf427  vmovaps xmm15, [rsp+0xB0]
00007d3d13bdf430  vmovaps [rsp+0xB0], xmm14
00007d3d13bdf439  movaps xmm3, xmm1
00007d3d13bdf43c  mulpd xmm3, xmm15
00007d3d13bdf441  vcmppd xmm14, xmm3, xmm3, 0x03
00007d3d13bdf446  ptest xmm14, xmm14
00007d3d13bdf44c  jnz 0x00007D3D13BE1B04
00007d3d13bdf452  lea r12, [rax+0x20]
00007d3d13bdf456  movups xmm1, [r13+r12*1]
00007d3d13bdf45c  movaps [r15+0x110], xmm1
00007d3d13bdf464  vmovaps xmm14, [rsp+0x70]
00007d3d13bdf46a  vmovaps [rsp+0x70], xmm1
00007d3d13bdf470  movaps xmm15, xmm14
00007d3d13bdf474  addpd xmm15, xmm4
00007d3d13bdf479  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d13bdf47f  ptest xmm1, xmm1
00007d3d13bdf484  jnz 0x00007D3D13BE1C4F
00007d3d13bdf48a  vmovaps xmm1, [rsp+0x60]
00007d3d13bdf490  vpermilpd xmm1, xmm1, 0x00
00007d3d13bdf496  movaps xmm14, xmm2
00007d3d13bdf49a  mulpd xmm14, xmm1
00007d3d13bdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007d3d13bdf4a5  ptest xmm4, xmm4
00007d3d13bdf4aa  jnz 0x00007D3D13BE1D92
00007d3d13bdf4b0  vmovaps xmm4, [rsp+0x50]
00007d3d13bdf4b6  movaps xmm1, xmm4
00007d3d13bdf4b9  addpd xmm1, xmm9
00007d3d13bdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d13bdf4c3  ptest xmm2, xmm2
00007d3d13bdf4c8  jnz 0x00007D3D13BE1ED4
00007d3d13bdf4ce  vmovaps xmm9, [rsp+0x30]
00007d3d13bdf4d4  vpermilpd xmm9, xmm9, 0x00
00007d3d13bdf4da  vmovaps xmm2, [rsp+0x70]
00007d3d13bdf4e0  vmovaps [rsp+0x50], xmm1
00007d3d13bdf4e6  movaps xmm4, xmm2
00007d3d13bdf4e9  mulpd xmm4, xmm9
00007d3d13bdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007d3d13bdf4f3  ptest xmm1, xmm1
00007d3d13bdf4f8  jnz 0x00007D3D13BE2015
00007d3d13bdf4fe  vmovaps xmm1, [rsp+0x30]
00007d3d13bdf504  vpermilpd xmm1, xmm1, 0x00
00007d3d13bdf50a  vmovaps xmm2, [rsp+0x90]
00007d3d13bdf513  vmovaps [rsp+0x60], xmm15
00007d3d13bdf519  movaps xmm9, xmm2
00007d3d13bdf51d  mulpd xmm9, xmm1
00007d3d13bdf522  vcmppd xmm15, xmm9, xmm9, 0x03
00007d3d13bdf528  ptest xmm15, xmm15
00007d3d13bdf52e  jnz 0x00007D3D13BE2156
00007d3d13bdf534  vmovaps xmm15, [rsp+0x80]
00007d3d13bdf53d  movaps xmm1, xmm15
00007d3d13bdf541  addpd xmm1, xmm6
00007d3d13bdf545  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d13bdf54a  ptest xmm2, xmm2
00007d3d13bdf54f  jnz 0x00007D3D13BE2298
00007d3d13bdf555  movaps xmm15, xmm5
00007d3d13bdf559  addpd xmm15, xmm3
00007d3d13bdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d3d13bdf564  ptest xmm6, xmm6
00007d3d13bdf569  jnz 0x00007D3D13BE23D9
00007d3d13bdf56f  vmovaps xmm6, [rsp+0x30]
00007d3d13bdf575  vpermilpd xmm6, xmm6, 0x00
00007d3d13bdf57b  movaps xmm5, xmm8
00007d3d13bdf57f  mulpd xmm5, xmm6
00007d3d13bdf583  vcmppd xmm3, xmm5, xmm5, 0x03
00007d3d13bdf588  ptest xmm3, xmm3
00007d3d13bdf58d  jnz 0x00007D3D13BE251B
00007d3d13bdf593  vmovaps xmm8, [rsp+0x30]
00007d3d13bdf599  vpermilpd xmm8, xmm8, 0x00
00007d3d13bdf59f  movaps xmm6, xmm10
00007d3d13bdf5a3  mulpd xmm6, xmm8
00007d3d13bdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d3d13bdf5ad  ptest xmm3, xmm3
00007d3d13bdf5b2  jnz 0x00007D3D13BE265C
00007d3d13bdf5b8  vmovaps xmm8, [rsp+0x60]
00007d3d13bdf5be  movaps xmm10, xmm8
00007d3d13bdf5c2  addpd xmm10, xmm14
00007d3d13bdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d3d13bdf5cd  ptest xmm3, xmm3
00007d3d13bdf5d2  jnz 0x00007D3D13BE279E
00007d3d13bdf5d8  vmovaps xmm8, [rsp+0x50]
00007d3d13bdf5de  movaps xmm14, xmm8
00007d3d13bdf5e2  addpd xmm14, xmm4
00007d3d13bdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007d3d13bdf5ed  ptest xmm3, xmm3
00007d3d13bdf5f2  jnz 0x00007D3D13BE28E2
00007d3d13bdf5f8  vmovaps xmm8, [rsp+0x40]
00007d3d13bdf5fe  vpermilpd xmm8, xmm8, 0x00
00007d3d13bdf604  movaps xmm4, xmm13
00007d3d13bdf608  mulpd xmm4, xmm8
00007d3d13bdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d3d13bdf612  ptest xmm3, xmm3
00007d3d13bdf617  jnz 0x00007D3D13BE2A25
00007d3d13bdf61d  movaps xmm13, xmm15
00007d3d13bdf621  addpd xmm13, xmm9
00007d3d13bdf626  vcmppd xmm8, xmm13, xmm13, 0x03
00007d3d13bdf62c  ptest xmm8, xmm8
00007d3d13bdf632  jnz 0x00007D3D13BE2B67
00007d3d13bdf638  movaps xmm15, xmm1
00007d3d13bdf63c  addpd xmm15, xmm5
00007d3d13bdf641  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d13bdf647  ptest xmm9, xmm9
00007d3d13bdf64d  jnz 0x00007D3D13BE2CAB
00007d3d13bdf653  vmovaps [rsp+0x30], xmm11
00007d3d13bdf659  vmovaps xmm1, [rsp+0x30]
00007d3d13bdf65f  por xmm11, xmm1
00007d3d13bdf664  movaps [r15+0x250], xmm11
00007d3d13bdf66c  vmovaps [rsp+0x30], xmm12
00007d3d13bdf672  vmovaps xmm1, [rsp+0x30]
00007d3d13bdf678  por xmm12, xmm1
00007d3d13bdf67d  movaps [r15+0x2A0], xmm12
00007d3d13bdf685  vmovaps xmm1, [rsp+0xA0]
00007d3d13bdf68e  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdf697  por xmm1, xmm11
00007d3d13bdf69c  movaps [r15+0x1D0], xmm1
00007d3d13bdf6a4  lea r12, [rax+0x40]
00007d3d13bdf6a8  movups xmm1, [r13+r12*1]
00007d3d13bdf6ae  movaps [r15+0x2C0], xmm1
00007d3d13bdf6b6  vmovaps xmm11, [rsp+0x40]
00007d3d13bdf6bc  vpermilpd xmm11, xmm11, 0x00
00007d3d13bdf6c2  vmovaps xmm8, [rsp+0xE0]
00007d3d13bdf6cb  movaps xmm9, xmm8
00007d3d13bdf6cf  mulpd xmm9, xmm11
00007d3d13bdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d3d13bdf6da  ptest xmm5, xmm5
00007d3d13bdf6df  jnz 0x00007D3D13BE2DF7
00007d3d13bdf6e5  movaps xmm11, xmm10
00007d3d13bdf6e9  addpd xmm11, xmm6
00007d3d13bdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007d3d13bdf6f4  ptest xmm8, xmm8
00007d3d13bdf6fa  jnz 0x00007D3D13BE2F3B
00007d3d13bdf700  movaps xmm10, xmm14
00007d3d13bdf704  addpd xmm10, xmm4
00007d3d13bdf709  vcmppd xmm8, xmm10, xmm10, 0x03
00007d3d13bdf70f  ptest xmm8, xmm8
00007d3d13bdf715  jnz 0x00007D3D13BE307E
00007d3d13bdf71b  vmovaps xmm14, [rsp+0x40]
00007d3d13bdf721  vpermilpd xmm14, xmm14, 0x00
00007d3d13bdf727  movaps xmm8, xmm1
00007d3d13bdf72b  mulpd xmm8, xmm14
00007d3d13bdf730  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d13bdf736  ptest xmm6, xmm6
00007d3d13bdf73b  jnz 0x00007D3D13BE31C1
00007d3d13bdf741  movaps xmm1, [r15+0x2B0]
00007d3d13bdf749  vmovaps xmm14, [rsp+0x40]
00007d3d13bdf74f  vpermilpd xmm14, xmm14, 0x00
00007d3d13bdf755  movaps xmm6, xmm1
00007d3d13bdf758  mulpd xmm6, xmm14
00007d3d13bdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d13bdf762  ptest xmm5, xmm5
00007d3d13bdf767  jnz 0x00007D3D13BE3304
00007d3d13bdf76d  vmovaps xmm1, [rsp+0x10]
00007d3d13bdf773  vpermilpd xmm1, xmm1, 0x00
00007d3d13bdf779  movaps xmm14, xmm12
00007d3d13bdf77d  mulpd xmm14, xmm1
00007d3d13bdf782  vcmppd xmm5, xmm14, xmm14, 0x03
00007d3d13bdf788  ptest xmm5, xmm5
00007d3d13bdf78d  jnz 0x00007D3D13BE3445
00007d3d13bdf793  movaps xmm1, xmm13
00007d3d13bdf797  addpd xmm1, xmm9
00007d3d13bdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d13bdf7a1  ptest xmm12, xmm12
00007d3d13bdf7a7  jnz 0x00007D3D13BE3588
00007d3d13bdf7ad  vmovaps xmm13, [rsp+0x10]
00007d3d13bdf7b3  vpermilpd xmm13, xmm13, 0x00
00007d3d13bdf7b9  movaps xmm12, xmm7
00007d3d13bdf7bd  mulpd xmm12, xmm13
00007d3d13bdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d13bdf7c8  ptest xmm9, xmm9
00007d3d13bdf7ce  jnz 0x00007D3D13BE36CA
00007d3d13bdf7d4  movaps xmm13, xmm15
00007d3d13bdf7d8  addpd xmm13, xmm8
00007d3d13bdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d3d13bdf7e3  ptest xmm9, xmm9
00007d3d13bdf7e9  jnz 0x00007D3D13BE380D
00007d3d13bdf7ef  movaps xmm15, [r15+0x290]
00007d3d13bdf7f7  vmovaps xmm9, [rsp+0x10]
00007d3d13bdf7fd  vpermilpd xmm9, xmm9, 0x00
00007d3d13bdf803  movaps xmm8, xmm15
00007d3d13bdf807  mulpd xmm8, xmm9
00007d3d13bdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d13bdf812  ptest xmm7, xmm7
00007d3d13bdf817  jnz 0x00007D3D13BE3951
00007d3d13bdf81d  movaps xmm15, xmm11
00007d3d13bdf821  addpd xmm15, xmm6
00007d3d13bdf826  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d13bdf82c  ptest xmm9, xmm9
00007d3d13bdf832  jnz 0x00007D3D13BE3A95
00007d3d13bdf838  movaps xmm11, [r15+0x1E0]
00007d3d13bdf840  vmovaps xmm9, [rsp+0x10]
00007d3d13bdf846  vpermilpd xmm9, xmm9, 0x00
00007d3d13bdf84c  movaps xmm7, xmm11
00007d3d13bdf850  mulpd xmm7, xmm9
00007d3d13bdf855  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d13bdf85a  ptest xmm6, xmm6
00007d3d13bdf85f  jnz 0x00007D3D13BE3BD8
00007d3d13bdf865  movaps xmm11, xmm10
00007d3d13bdf869  addpd xmm11, xmm14
00007d3d13bdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d3d13bdf874  ptest xmm9, xmm9
00007d3d13bdf87a  jnz 0x00007D3D13BE3D1A
00007d3d13bdf880  lea r12, [rax+0x70]
00007d3d13bdf884  movups xmm14, [r13+r12*1]
00007d3d13bdf88a  movaps [r15+0x240], xmm14
00007d3d13bdf892  movaps xmm10, xmm1
00007d3d13bdf896  addpd xmm10, xmm12
00007d3d13bdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007d3d13bdf8a1  ptest xmm9, xmm9
00007d3d13bdf8a7  jnz 0x00007D3D13BE3E68
00007d3d13bdf8ad  movaps [r15+0x170], xmm10
00007d3d13bdf8b5  vmovaps xmm1, [rsp+0x20]
00007d3d13bdf8bb  vpermilpd xmm1, xmm1, 0x00
00007d3d13bdf8c1  movaps xmm12, xmm14
00007d3d13bdf8c5  mulpd xmm12, xmm1
00007d3d13bdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d13bdf8d0  ptest xmm9, xmm9
00007d3d13bdf8d6  jnz 0x00007D3D13BE3FAB
00007d3d13bdf8dc  vmovaps xmm1, [rsp+0x20]
00007d3d13bdf8e2  vpermilpd xmm1, xmm1, 0x00
00007d3d13bdf8e8  vmovaps xmm9, [rsp+0xB0]
00007d3d13bdf8f1  movaps xmm14, xmm9
00007d3d13bdf8f5  mulpd xmm14, xmm1
00007d3d13bdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d13bdf900  ptest xmm6, xmm6
00007d3d13bdf905  jnz 0x00007D3D13BE40EE
00007d3d13bdf90b  movaps [r15+0x180], xmm14
00007d3d13bdf913  movaps xmm1, xmm13
00007d3d13bdf917  addpd xmm1, xmm8
00007d3d13bdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d3d13bdf921  ptest xmm9, xmm9
00007d3d13bdf927  jnz 0x00007D3D13BE4231
00007d3d13bdf92d  movaps [r15+0x210], xmm1
00007d3d13bdf935  movups xmm13, [r13+rax*1]
00007d3d13bdf93b  lea r12, [rax+0x10]
00007d3d13bdf93f  movups xmm9, [r13+r12*1]
00007d3d13bdf945  movaps [r15+0x230], xmm9
00007d3d13bdf94d  movaps xmm8, xmm15
00007d3d13bdf951  addpd xmm8, xmm7
00007d3d13bdf956  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d13bdf95c  ptest xmm6, xmm6
00007d3d13bdf961  jnz 0x00007D3D13BE4387
00007d3d13bdf967  movaps [r15+0x130], xmm8
00007d3d13bdf96f  vmovaps xmm15, [rsp+0x20]
00007d3d13bdf975  vpermilpd xmm15, xmm15, 0x00
00007d3d13bdf97b  movaps xmm7, xmm9
00007d3d13bdf97f  mulpd xmm7, xmm15
00007d3d13bdf984  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d13bdf989  ptest xmm6, xmm6
00007d3d13bdf98e  jnz 0x00007D3D13BE44CA
00007d3d13bdf994  movaps [r15+0x220], xmm7
00007d3d13bdf99c  vmovaps xmm15, [rsp+0x20]
00007d3d13bdf9a2  vpermilpd xmm15, xmm15, 0x00
00007d3d13bdf9a8  movaps xmm9, xmm13
00007d3d13bdf9ac  mulpd xmm9, xmm15
00007d3d13bdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d13bdf9b7  ptest xmm6, xmm6
00007d3d13bdf9bc  jnz 0x00007D3D13BE460C
00007d3d13bdf9c2  movaps xmm15, xmm11
00007d3d13bdf9c6  addpd xmm15, xmm12
00007d3d13bdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d3d13bdf9d1  ptest xmm13, xmm13
00007d3d13bdf9d7  jnz 0x00007D3D13BE4750
00007d3d13bdf9dd  movaps [r15+0x140], xmm15
00007d3d13bdf9e5  movaps xmm13, xmm10
00007d3d13bdf9e9  addpd xmm13, xmm14
00007d3d13bdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007d3d13bdf9f4  ptest xmm12, xmm12
00007d3d13bdf9fa  jnz 0x00007D3D13BE4894
00007d3d13bdfa00  movaps [r15+0x150], xmm13
00007d3d13bdfa08  movaps xmm14, xmm1
00007d3d13bdfa0c  addpd xmm14, xmm7
00007d3d13bdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007d3d13bdfa17  ptest xmm12, xmm12
00007d3d13bdfa1d  jnz 0x00007D3D13BE49D8
00007d3d13bdfa23  movaps [r15+0x160], xmm14
00007d3d13bdfa2b  movaps xmm1, xmm8
00007d3d13bdfa2f  addpd xmm1, xmm9
00007d3d13bdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d13bdfa39  ptest xmm12, xmm12
00007d3d13bdfa3f  jnz 0x00007D3D13BE4B1A
00007d3d13bdfa45  movaps [r15+0x120], xmm1
00007d3d13bdfa4d  movups [r13+r14*1], xmm15
00007d3d13bdfa53  lea rax, [r14+0x10]
00007d3d13bdfa57  movups [r13+rax*1], xmm13
00007d3d13bdfa5d  lea rax, [r14+0x20]
00007d3d13bdfa61  movups [r13+rax*1], xmm14
00007d3d13bdfa67  lea rax, [r14+0x30]
00007d3d13bdfa6b  movups [r13+rax*1], xmm1
00007d3d13bdfa71  mov eax, [r15+0x108]
00007d3d13bdfa78  sahf
00007d3d13bdfa79  jnz 0x00007D3D13BDFAAB
00007d3d13bdfa7b  cmp dword ptr [r15+0x318], 0x00
00007d3d13bdfa83  jz 0x00007D3D13BDEAE0
00007d3d13bdfa89  nop [rax+rax*1], ax
00007d3d13bdfa92  nop [rax+rax*1], eax
00007d3d13bdfa9a  mov eax, 0x4106D0
00007d3d13bdfa9f  mov [r15+0x100], rax
00007d3d13bdfaa6  jmp 0x00007D3D139FE110
00007d3d13bdfaab  cmp dword ptr [r15+0x318], 0x00
00007d3d13bdfab3  jz 0x00007D3D13BD89C0
00007d3d13bdfab9  nop [rax+rax*1], ax
00007d3d13bdfac2  nop [rax+rax*1], eax
00007d3d13bdfaca  mov eax, 0x410504
00007d3d13bdfacf  mov [r15+0x100], rax
00007d3d13bdfad6  jmp 0x00007D3D139FE110
00007d3d13bdfadb  int3
00007d3d13bdfadc  call 0x00007D3D13AE27E0
00007d3d13bdfae1  jmp 0x00007D3D13BDEBBF
00007d3d13bdfae6  call 0x00007D3D13AE1570
00007d3d13bdfaeb  jmp 0x00007D3D13BDEBC8
00007d3d13bdfaf0  call 0x00007D3D13AE27E0
00007d3d13bdfaf5  jmp 0x00007D3D13BDEC24
00007d3d13bdfafa  call 0x00007D3D13AE1570
00007d3d13bdfaff  jmp 0x00007D3D13BDEC2D
00007d3d13bdfb04  call 0x00007D3D13AE27E0
00007d3d13bdfb09  jmp 0x00007D3D13BDEC70
00007d3d13bdfb0e  call 0x00007D3D13AE1570
00007d3d13bdfb13  jmp 0x00007D3D13BDEC79
00007d3d13bdfb18  call 0x00007D3D13A0DC20
00007d3d13bdfb1d  jmp 0x00007D3D13BDECB8
00007d3d13bdfb22  call 0x00007D3D13AD59C0
00007d3d13bdfb27  jmp 0x00007D3D13BDECCB
00007d3d13bdfb2c  call 0x00007D3D13AE0E30
00007d3d13bdfb31  jmp 0x00007D3D13BDECE9
00007d3d13bdfb36  call 0x00007D3D13ADFBC0
00007d3d13bdfb3b  jmp 0x00007D3D13BDECF3
00007d3d13bdfb40  call 0x00007D3D13ADE950
00007d3d13bdfb45  jmp 0x00007D3D13BDECFD
00007d3d13bdfb4a  sub rsp, 0x08
00007d3d13bdfb4e  push rax
00007d3d13bdfb4f  push rcx
00007d3d13bdfb50  push rdx
00007d3d13bdfb51  push rdi
00007d3d13bdfb52  push rsi
00007d3d13bdfb53  push r8
00007d3d13bdfb55  push r9
00007d3d13bdfb57  push r10
00007d3d13bdfb59  push r11
00007d3d13bdfb5b  sub rsp, 0xF0
00007d3d13bdfb62  vmovaps [rsp], xmm0
00007d3d13bdfb67  vmovaps [rsp+0x10], xmm1
00007d3d13bdfb6d  vmovaps [rsp+0x20], xmm2
00007d3d13bdfb73  vmovaps [rsp+0x30], xmm3
00007d3d13bdfb79  vmovaps [rsp+0x40], xmm4
00007d3d13bdfb7f  vmovaps [rsp+0x50], xmm5
00007d3d13bdfb85  vmovaps [rsp+0x60], xmm6
00007d3d13bdfb8b  vmovaps [rsp+0x70], xmm7
00007d3d13bdfb91  vmovaps [rsp+0x80], xmm9
00007d3d13bdfb9a  vmovaps [rsp+0x90], xmm10
00007d3d13bdfba3  vmovaps [rsp+0xA0], xmm11
00007d3d13bdfbac  vmovaps [rsp+0xB0], xmm12
00007d3d13bdfbb5  vmovaps [rsp+0xC0], xmm13
00007d3d13bdfbbe  vmovaps [rsp+0xD0], xmm14
00007d3d13bdfbc7  vmovaps [rsp+0xE0], xmm15
00007d3d13bdfbd0  sub rsp, 0x30
00007d3d13bdfbd4  movaps [rsp], xmm8
00007d3d13bdfbd9  movaps [rsp+0x10], xmm12
00007d3d13bdfbdf  movaps [rsp+0x20], xmm15
00007d3d13bdfbe5  lea rdi, [rsp]
00007d3d13bdfbe9  mov esi, 0x00
00007d3d13bdfbee  mov rax, 0x5741DAFC8530
00007d3d13bdfbf8  call rax
00007d3d13bdfbfa  movaps xmm8, [rsp]
00007d3d13bdfbff  add rsp, 0x30
00007d3d13bdfc03  vmovaps xmm0, [rsp]
00007d3d13bdfc08  vmovaps xmm1, [rsp+0x10]
00007d3d13bdfc0e  vmovaps xmm2, [rsp+0x20]
00007d3d13bdfc14  vmovaps xmm3, [rsp+0x30]
00007d3d13bdfc1a  vmovaps xmm4, [rsp+0x40]
00007d3d13bdfc20  vmovaps xmm5, [rsp+0x50]
00007d3d13bdfc26  vmovaps xmm6, [rsp+0x60]
00007d3d13bdfc2c  vmovaps xmm7, [rsp+0x70]
00007d3d13bdfc32  vmovaps xmm9, [rsp+0x80]
00007d3d13bdfc3b  vmovaps xmm10, [rsp+0x90]
00007d3d13bdfc44  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdfc4d  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdfc56  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdfc5f  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdfc68  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdfc71  add rsp, 0xF0
00007d3d13bdfc78  pop r11
00007d3d13bdfc7a  pop r10
00007d3d13bdfc7c  pop r9
00007d3d13bdfc7e  pop r8
00007d3d13bdfc80  pop rsi
00007d3d13bdfc81  pop rdi
00007d3d13bdfc82  pop rdx
00007d3d13bdfc83  pop rcx
00007d3d13bdfc84  pop rax
00007d3d13bdfc85  add rsp, 0x08
00007d3d13bdfc89  jmp 0x00007D3D13BDED27
00007d3d13bdfc8e  sub rsp, 0x08
00007d3d13bdfc92  push rax
00007d3d13bdfc93  push rcx
00007d3d13bdfc94  push rdx
00007d3d13bdfc95  push rdi
00007d3d13bdfc96  push rsi
00007d3d13bdfc97  push r8
00007d3d13bdfc99  push r9
00007d3d13bdfc9b  push r10
00007d3d13bdfc9d  push r11
00007d3d13bdfc9f  sub rsp, 0xF0
00007d3d13bdfca6  vmovaps [rsp], xmm0
00007d3d13bdfcab  vmovaps [rsp+0x10], xmm1
00007d3d13bdfcb1  vmovaps [rsp+0x20], xmm2
00007d3d13bdfcb7  vmovaps [rsp+0x30], xmm3
00007d3d13bdfcbd  vmovaps [rsp+0x40], xmm4
00007d3d13bdfcc3  vmovaps [rsp+0x50], xmm5
00007d3d13bdfcc9  vmovaps [rsp+0x60], xmm6
00007d3d13bdfccf  vmovaps [rsp+0x70], xmm8
00007d3d13bdfcd5  vmovaps [rsp+0x80], xmm9
00007d3d13bdfcde  vmovaps [rsp+0x90], xmm10
00007d3d13bdfce7  vmovaps [rsp+0xA0], xmm11
00007d3d13bdfcf0  vmovaps [rsp+0xB0], xmm12
00007d3d13bdfcf9  vmovaps [rsp+0xC0], xmm13
00007d3d13bdfd02  vmovaps [rsp+0xD0], xmm14
00007d3d13bdfd0b  vmovaps [rsp+0xE0], xmm15
00007d3d13bdfd14  sub rsp, 0x30
00007d3d13bdfd18  movaps [rsp], xmm7
00007d3d13bdfd1c  movaps [rsp+0x10], xmm9
00007d3d13bdfd22  movaps [rsp+0x20], xmm15
00007d3d13bdfd28  lea rdi, [rsp]
00007d3d13bdfd2c  mov esi, 0x00
00007d3d13bdfd31  mov rax, 0x5741DAFC8530
00007d3d13bdfd3b  call rax
00007d3d13bdfd3d  movaps xmm7, [rsp]
00007d3d13bdfd41  add rsp, 0x30
00007d3d13bdfd45  vmovaps xmm0, [rsp]
00007d3d13bdfd4a  vmovaps xmm1, [rsp+0x10]
00007d3d13bdfd50  vmovaps xmm2, [rsp+0x20]
00007d3d13bdfd56  vmovaps xmm3, [rsp+0x30]
00007d3d13bdfd5c  vmovaps xmm4, [rsp+0x40]
00007d3d13bdfd62  vmovaps xmm5, [rsp+0x50]
00007d3d13bdfd68  vmovaps xmm6, [rsp+0x60]
00007d3d13bdfd6e  vmovaps xmm8, [rsp+0x70]
00007d3d13bdfd74  vmovaps xmm9, [rsp+0x80]
00007d3d13bdfd7d  vmovaps xmm10, [rsp+0x90]
00007d3d13bdfd86  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdfd8f  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdfd98  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdfda1  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdfdaa  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdfdb3  add rsp, 0xF0
00007d3d13bdfdba  pop r11
00007d3d13bdfdbc  pop r10
00007d3d13bdfdbe  pop r9
00007d3d13bdfdc0  pop r8
00007d3d13bdfdc2  pop rsi
00007d3d13bdfdc3  pop rdi
00007d3d13bdfdc4  pop rdx
00007d3d13bdfdc5  pop rcx
00007d3d13bdfdc6  pop rax
00007d3d13bdfdc7  add rsp, 0x08
00007d3d13bdfdcb  jmp 0x00007D3D13BDED55
00007d3d13bdfdd0  sub rsp, 0x08
00007d3d13bdfdd4  push rax
00007d3d13bdfdd5  push rcx
00007d3d13bdfdd6  push rdx
00007d3d13bdfdd7  push rdi
00007d3d13bdfdd8  push rsi
00007d3d13bdfdd9  push r8
00007d3d13bdfddb  push r9
00007d3d13bdfddd  push r10
00007d3d13bdfddf  push r11
00007d3d13bdfde1  sub rsp, 0xF0
00007d3d13bdfde8  vmovaps [rsp], xmm0
00007d3d13bdfded  vmovaps [rsp+0x10], xmm1
00007d3d13bdfdf3  vmovaps [rsp+0x20], xmm2
00007d3d13bdfdf9  vmovaps [rsp+0x30], xmm3
00007d3d13bdfdff  vmovaps [rsp+0x40], xmm4
00007d3d13bdfe05  vmovaps [rsp+0x50], xmm5
00007d3d13bdfe0b  vmovaps [rsp+0x60], xmm6
00007d3d13bdfe11  vmovaps [rsp+0x70], xmm7
00007d3d13bdfe17  vmovaps [rsp+0x80], xmm8
00007d3d13bdfe20  vmovaps [rsp+0x90], xmm10
00007d3d13bdfe29  vmovaps [rsp+0xA0], xmm11
00007d3d13bdfe32  vmovaps [rsp+0xB0], xmm12
00007d3d13bdfe3b  vmovaps [rsp+0xC0], xmm13
00007d3d13bdfe44  vmovaps [rsp+0xD0], xmm14
00007d3d13bdfe4d  vmovaps [rsp+0xE0], xmm15
00007d3d13bdfe56  sub rsp, 0x30
00007d3d13bdfe5a  movaps [rsp], xmm9
00007d3d13bdfe5f  movaps [rsp+0x10], xmm12
00007d3d13bdfe65  movaps [rsp+0x20], xmm10
00007d3d13bdfe6b  lea rdi, [rsp]
00007d3d13bdfe6f  mov esi, 0x00
00007d3d13bdfe74  mov rax, 0x5741DAFC8530
00007d3d13bdfe7e  call rax
00007d3d13bdfe80  movaps xmm9, [rsp]
00007d3d13bdfe85  add rsp, 0x30
00007d3d13bdfe89  vmovaps xmm0, [rsp]
00007d3d13bdfe8e  vmovaps xmm1, [rsp+0x10]
00007d3d13bdfe94  vmovaps xmm2, [rsp+0x20]
00007d3d13bdfe9a  vmovaps xmm3, [rsp+0x30]
00007d3d13bdfea0  vmovaps xmm4, [rsp+0x40]
00007d3d13bdfea6  vmovaps xmm5, [rsp+0x50]
00007d3d13bdfeac  vmovaps xmm6, [rsp+0x60]
00007d3d13bdfeb2  vmovaps xmm7, [rsp+0x70]
00007d3d13bdfeb8  vmovaps xmm8, [rsp+0x80]
00007d3d13bdfec1  vmovaps xmm10, [rsp+0x90]
00007d3d13bdfeca  vmovaps xmm11, [rsp+0xA0]
00007d3d13bdfed3  vmovaps xmm12, [rsp+0xB0]
00007d3d13bdfedc  vmovaps xmm13, [rsp+0xC0]
00007d3d13bdfee5  vmovaps xmm14, [rsp+0xD0]
00007d3d13bdfeee  vmovaps xmm15, [rsp+0xE0]
00007d3d13bdfef7  add rsp, 0xF0
00007d3d13bdfefe  pop r11
00007d3d13bdff00  pop r10
00007d3d13bdff02  pop r9
00007d3d13bdff04  pop r8
00007d3d13bdff06  pop rsi
00007d3d13bdff07  pop rdi
00007d3d13bdff08  pop rdx
00007d3d13bdff09  pop rcx
00007d3d13bdff0a  pop rax
00007d3d13bdff0b  add rsp, 0x08
00007d3d13bdff0f  jmp 0x00007D3D13BDED79
00007d3d13bdff14  sub rsp, 0x08
00007d3d13bdff18  push rax
00007d3d13bdff19  push rcx
00007d3d13bdff1a  push rdx
00007d3d13bdff1b  push rdi
00007d3d13bdff1c  push rsi
00007d3d13bdff1d  push r8
00007d3d13bdff1f  push r9
00007d3d13bdff21  push r10
00007d3d13bdff23  push r11
00007d3d13bdff25  sub rsp, 0xF0
00007d3d13bdff2c  vmovaps [rsp], xmm0
00007d3d13bdff31  vmovaps [rsp+0x10], xmm1
00007d3d13bdff37  vmovaps [rsp+0x20], xmm2
00007d3d13bdff3d  vmovaps [rsp+0x30], xmm3
00007d3d13bdff43  vmovaps [rsp+0x40], xmm4
00007d3d13bdff49  vmovaps [rsp+0x50], xmm5
00007d3d13bdff4f  vmovaps [rsp+0x60], xmm6
00007d3d13bdff55  vmovaps [rsp+0x70], xmm7
00007d3d13bdff5b  vmovaps [rsp+0x80], xmm8
00007d3d13bdff64  vmovaps [rsp+0x90], xmm9
00007d3d13bdff6d  vmovaps [rsp+0xA0], xmm11
00007d3d13bdff76  vmovaps [rsp+0xB0], xmm12
00007d3d13bdff7f  vmovaps [rsp+0xC0], xmm13
00007d3d13bdff88  vmovaps [rsp+0xD0], xmm14
00007d3d13bdff91  vmovaps [rsp+0xE0], xmm15
00007d3d13bdff9a  sub rsp, 0x30
00007d3d13bdff9e  movaps [rsp], xmm10
00007d3d13bdffa3  movaps [rsp+0x10], xmm12
00007d3d13bdffa9  movaps [rsp+0x20], xmm11
00007d3d13bdffaf  lea rdi, [rsp]
00007d3d13bdffb3  mov esi, 0x00
00007d3d13bdffb8  mov rax, 0x5741DAFC8530
00007d3d13bdffc2  call rax
00007d3d13bdffc4  movaps xmm10, [rsp]
00007d3d13bdffc9  add rsp, 0x30
00007d3d13bdffcd  vmovaps xmm0, [rsp]
00007d3d13bdffd2  vmovaps xmm1, [rsp+0x10]
00007d3d13bdffd8  vmovaps xmm2, [rsp+0x20]
00007d3d13bdffde  vmovaps xmm3, [rsp+0x30]
00007d3d13bdffe4  vmovaps xmm4, [rsp+0x40]
00007d3d13bdffea  vmovaps xmm5, [rsp+0x50]
00007d3d13bdfff0  vmovaps xmm6, [rsp+0x60]
00007d3d13bdfff6  vmovaps xmm7, [rsp+0x70]
00007d3d13bdfffc  vmovaps xmm8, [rsp+0x80]
00007d3d13be0005  vmovaps xmm9, [rsp+0x90]
00007d3d13be000e  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0017  vmovaps xmm12, [rsp+0xB0]
00007d3d13be0020  vmovaps xmm13, [rsp+0xC0]
00007d3d13be0029  vmovaps xmm14, [rsp+0xD0]
00007d3d13be0032  vmovaps xmm15, [rsp+0xE0]
00007d3d13be003b  add rsp, 0xF0
00007d3d13be0042  pop r11
00007d3d13be0044  pop r10
00007d3d13be0046  pop r9
00007d3d13be0048  pop r8
00007d3d13be004a  pop rsi
00007d3d13be004b  pop rdi
00007d3d13be004c  pop rdx
00007d3d13be004d  pop rcx
00007d3d13be004e  pop rax
00007d3d13be004f  add rsp, 0x08
00007d3d13be0053  jmp 0x00007D3D13BDED93
00007d3d13be0058  sub rsp, 0x08
00007d3d13be005c  push rax
00007d3d13be005d  push rcx
00007d3d13be005e  push rdx
00007d3d13be005f  push rdi
00007d3d13be0060  push rsi
00007d3d13be0061  push r8
00007d3d13be0063  push r9
00007d3d13be0065  push r10
00007d3d13be0067  push r11
00007d3d13be0069  sub rsp, 0xF0
00007d3d13be0070  vmovaps [rsp], xmm0
00007d3d13be0075  vmovaps [rsp+0x10], xmm1
00007d3d13be007b  vmovaps [rsp+0x20], xmm2
00007d3d13be0081  vmovaps [rsp+0x30], xmm3
00007d3d13be0087  vmovaps [rsp+0x40], xmm4
00007d3d13be008d  vmovaps [rsp+0x50], xmm5
00007d3d13be0093  vmovaps [rsp+0x60], xmm7
00007d3d13be0099  vmovaps [rsp+0x70], xmm8
00007d3d13be009f  vmovaps [rsp+0x80], xmm9
00007d3d13be00a8  vmovaps [rsp+0x90], xmm10
00007d3d13be00b1  vmovaps [rsp+0xA0], xmm11
00007d3d13be00ba  vmovaps [rsp+0xB0], xmm12
00007d3d13be00c3  vmovaps [rsp+0xC0], xmm13
00007d3d13be00cc  vmovaps [rsp+0xD0], xmm14
00007d3d13be00d5  vmovaps [rsp+0xE0], xmm15
00007d3d13be00de  sub rsp, 0x30
00007d3d13be00e2  movaps [rsp], xmm6
00007d3d13be00e6  movaps [rsp+0x10], xmm12
00007d3d13be00ec  movaps [rsp+0x20], xmm11
00007d3d13be00f2  lea rdi, [rsp]
00007d3d13be00f6  mov esi, 0x00
00007d3d13be00fb  mov rax, 0x5741DAFC8530
00007d3d13be0105  call rax
00007d3d13be0107  movaps xmm6, [rsp]
00007d3d13be010b  add rsp, 0x30
00007d3d13be010f  vmovaps xmm0, [rsp]
00007d3d13be0114  vmovaps xmm1, [rsp+0x10]
00007d3d13be011a  vmovaps xmm2, [rsp+0x20]
00007d3d13be0120  vmovaps xmm3, [rsp+0x30]
00007d3d13be0126  vmovaps xmm4, [rsp+0x40]
00007d3d13be012c  vmovaps xmm5, [rsp+0x50]
00007d3d13be0132  vmovaps xmm7, [rsp+0x60]
00007d3d13be0138  vmovaps xmm8, [rsp+0x70]
00007d3d13be013e  vmovaps xmm9, [rsp+0x80]
00007d3d13be0147  vmovaps xmm10, [rsp+0x90]
00007d3d13be0150  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0159  vmovaps xmm12, [rsp+0xB0]
00007d3d13be0162  vmovaps xmm13, [rsp+0xC0]
00007d3d13be016b  vmovaps xmm14, [rsp+0xD0]
00007d3d13be0174  vmovaps xmm15, [rsp+0xE0]
00007d3d13be017d  add rsp, 0xF0
00007d3d13be0184  pop r11
00007d3d13be0186  pop r10
00007d3d13be0188  pop r9
00007d3d13be018a  pop r8
00007d3d13be018c  pop rsi
00007d3d13be018d  pop rdi
00007d3d13be018e  pop rdx
00007d3d13be018f  pop rcx
00007d3d13be0190  pop rax
00007d3d13be0191  add rsp, 0x08
00007d3d13be0195  jmp 0x00007D3D13BDEDB4
00007d3d13be019a  sub rsp, 0x08
00007d3d13be019e  push rax
00007d3d13be019f  push rcx
00007d3d13be01a0  push rdx
00007d3d13be01a1  push rdi
00007d3d13be01a2  push rsi
00007d3d13be01a3  push r8
00007d3d13be01a5  push r9
00007d3d13be01a7  push r10
00007d3d13be01a9  push r11
00007d3d13be01ab  sub rsp, 0xF0
00007d3d13be01b2  vmovaps [rsp], xmm0
00007d3d13be01b7  vmovaps [rsp+0x10], xmm1
00007d3d13be01bd  vmovaps [rsp+0x20], xmm2
00007d3d13be01c3  vmovaps [rsp+0x30], xmm4
00007d3d13be01c9  vmovaps [rsp+0x40], xmm5
00007d3d13be01cf  vmovaps [rsp+0x50], xmm6
00007d3d13be01d5  vmovaps [rsp+0x60], xmm7
00007d3d13be01db  vmovaps [rsp+0x70], xmm8
00007d3d13be01e1  vmovaps [rsp+0x80], xmm9
00007d3d13be01ea  vmovaps [rsp+0x90], xmm10
00007d3d13be01f3  vmovaps [rsp+0xA0], xmm11
00007d3d13be01fc  vmovaps [rsp+0xB0], xmm12
00007d3d13be0205  vmovaps [rsp+0xC0], xmm13
00007d3d13be020e  vmovaps [rsp+0xD0], xmm14
00007d3d13be0217  vmovaps [rsp+0xE0], xmm15
00007d3d13be0220  sub rsp, 0x30
00007d3d13be0224  movaps [rsp], xmm3
00007d3d13be0228  movaps [rsp+0x10], xmm5
00007d3d13be022d  movaps [rsp+0x20], xmm4
00007d3d13be0232  lea rdi, [rsp]
00007d3d13be0236  mov esi, 0x00
00007d3d13be023b  mov rax, 0x5741DAFC8530
00007d3d13be0245  call rax
00007d3d13be0247  movaps xmm3, [rsp]
00007d3d13be024b  add rsp, 0x30
00007d3d13be024f  vmovaps xmm0, [rsp]
00007d3d13be0254  vmovaps xmm1, [rsp+0x10]
00007d3d13be025a  vmovaps xmm2, [rsp+0x20]
00007d3d13be0260  vmovaps xmm4, [rsp+0x30]
00007d3d13be0266  vmovaps xmm5, [rsp+0x40]
00007d3d13be026c  vmovaps xmm6, [rsp+0x50]
00007d3d13be0272  vmovaps xmm7, [rsp+0x60]
00007d3d13be0278  vmovaps xmm8, [rsp+0x70]
00007d3d13be027e  vmovaps xmm9, [rsp+0x80]
00007d3d13be0287  vmovaps xmm10, [rsp+0x90]
00007d3d13be0290  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0299  vmovaps xmm12, [rsp+0xB0]
00007d3d13be02a2  vmovaps xmm13, [rsp+0xC0]
00007d3d13be02ab  vmovaps xmm14, [rsp+0xD0]
00007d3d13be02b4  vmovaps xmm15, [rsp+0xE0]
00007d3d13be02bd  add rsp, 0xF0
00007d3d13be02c4  pop r11
00007d3d13be02c6  pop r10
00007d3d13be02c8  pop r9
00007d3d13be02ca  pop r8
00007d3d13be02cc  pop rsi
00007d3d13be02cd  pop rdi
00007d3d13be02ce  pop rdx
00007d3d13be02cf  pop rcx
00007d3d13be02d0  pop rax
00007d3d13be02d1  add rsp, 0x08
00007d3d13be02d5  jmp 0x00007D3D13BDEE15
00007d3d13be02da  sub rsp, 0x08
00007d3d13be02de  push rax
00007d3d13be02df  push rcx
00007d3d13be02e0  push rdx
00007d3d13be02e1  push rdi
00007d3d13be02e2  push rsi
00007d3d13be02e3  push r8
00007d3d13be02e5  push r9
00007d3d13be02e7  push r10
00007d3d13be02e9  push r11
00007d3d13be02eb  sub rsp, 0xF0
00007d3d13be02f2  vmovaps [rsp], xmm0
00007d3d13be02f7  vmovaps [rsp+0x10], xmm1
00007d3d13be02fd  vmovaps [rsp+0x20], xmm2
00007d3d13be0303  vmovaps [rsp+0x30], xmm3
00007d3d13be0309  vmovaps [rsp+0x40], xmm4
00007d3d13be030f  vmovaps [rsp+0x50], xmm6
00007d3d13be0315  vmovaps [rsp+0x60], xmm7
00007d3d13be031b  vmovaps [rsp+0x70], xmm8
00007d3d13be0321  vmovaps [rsp+0x80], xmm9
00007d3d13be032a  vmovaps [rsp+0x90], xmm10
00007d3d13be0333  vmovaps [rsp+0xA0], xmm11
00007d3d13be033c  vmovaps [rsp+0xB0], xmm12
00007d3d13be0345  vmovaps [rsp+0xC0], xmm13
00007d3d13be034e  vmovaps [rsp+0xD0], xmm14
00007d3d13be0357  vmovaps [rsp+0xE0], xmm15
00007d3d13be0360  sub rsp, 0x30
00007d3d13be0364  movaps [rsp], xmm5
00007d3d13be0368  movaps [rsp+0x10], xmm8
00007d3d13be036e  movaps [rsp+0x20], xmm15
00007d3d13be0374  lea rdi, [rsp]
00007d3d13be0378  mov esi, 0x00
00007d3d13be037d  mov rax, 0x5741DAFC8530
00007d3d13be0387  call rax
00007d3d13be0389  movaps xmm5, [rsp]
00007d3d13be038d  add rsp, 0x30
00007d3d13be0391  vmovaps xmm0, [rsp]
00007d3d13be0396  vmovaps xmm1, [rsp+0x10]
00007d3d13be039c  vmovaps xmm2, [rsp+0x20]
00007d3d13be03a2  vmovaps xmm3, [rsp+0x30]
00007d3d13be03a8  vmovaps xmm4, [rsp+0x40]
00007d3d13be03ae  vmovaps xmm6, [rsp+0x50]
00007d3d13be03b4  vmovaps xmm7, [rsp+0x60]
00007d3d13be03ba  vmovaps xmm8, [rsp+0x70]
00007d3d13be03c0  vmovaps xmm9, [rsp+0x80]
00007d3d13be03c9  vmovaps xmm10, [rsp+0x90]
00007d3d13be03d2  vmovaps xmm11, [rsp+0xA0]
00007d3d13be03db  vmovaps xmm12, [rsp+0xB0]
00007d3d13be03e4  vmovaps xmm13, [rsp+0xC0]
00007d3d13be03ed  vmovaps xmm14, [rsp+0xD0]
00007d3d13be03f6  vmovaps xmm15, [rsp+0xE0]
00007d3d13be03ff  add rsp, 0xF0
00007d3d13be0406  pop r11
00007d3d13be0408  pop r10
00007d3d13be040a  pop r9
00007d3d13be040c  pop r8
00007d3d13be040e  pop rsi
00007d3d13be040f  pop rdi
00007d3d13be0410  pop rdx
00007d3d13be0411  pop rcx
00007d3d13be0412  pop rax
00007d3d13be0413  add rsp, 0x08
00007d3d13be0417  jmp 0x00007D3D13BDEE53
00007d3d13be041c  sub rsp, 0x08
00007d3d13be0420  push rax
00007d3d13be0421  push rcx
00007d3d13be0422  push rdx
00007d3d13be0423  push rdi
00007d3d13be0424  push rsi
00007d3d13be0425  push r8
00007d3d13be0427  push r9
00007d3d13be0429  push r10
00007d3d13be042b  push r11
00007d3d13be042d  sub rsp, 0xF0
00007d3d13be0434  vmovaps [rsp], xmm0
00007d3d13be0439  vmovaps [rsp+0x10], xmm1
00007d3d13be043f  vmovaps [rsp+0x20], xmm2
00007d3d13be0445  vmovaps [rsp+0x30], xmm3
00007d3d13be044b  vmovaps [rsp+0x40], xmm5
00007d3d13be0451  vmovaps [rsp+0x50], xmm6
00007d3d13be0457  vmovaps [rsp+0x60], xmm7
00007d3d13be045d  vmovaps [rsp+0x70], xmm8
00007d3d13be0463  vmovaps [rsp+0x80], xmm9
00007d3d13be046c  vmovaps [rsp+0x90], xmm10
00007d3d13be0475  vmovaps [rsp+0xA0], xmm11
00007d3d13be047e  vmovaps [rsp+0xB0], xmm12
00007d3d13be0487  vmovaps [rsp+0xC0], xmm13
00007d3d13be0490  vmovaps [rsp+0xD0], xmm14
00007d3d13be0499  vmovaps [rsp+0xE0], xmm15
00007d3d13be04a2  sub rsp, 0x30
00007d3d13be04a6  movaps [rsp], xmm4
00007d3d13be04aa  movaps [rsp+0x10], xmm9
00007d3d13be04b0  movaps [rsp+0x20], xmm8
00007d3d13be04b6  lea rdi, [rsp]
00007d3d13be04ba  mov esi, 0x00
00007d3d13be04bf  mov rax, 0x5741DAFC8530
00007d3d13be04c9  call rax
00007d3d13be04cb  movaps xmm4, [rsp]
00007d3d13be04cf  add rsp, 0x30
00007d3d13be04d3  vmovaps xmm0, [rsp]
00007d3d13be04d8  vmovaps xmm1, [rsp+0x10]
00007d3d13be04de  vmovaps xmm2, [rsp+0x20]
00007d3d13be04e4  vmovaps xmm3, [rsp+0x30]
00007d3d13be04ea  vmovaps xmm5, [rsp+0x40]
00007d3d13be04f0  vmovaps xmm6, [rsp+0x50]
00007d3d13be04f6  vmovaps xmm7, [rsp+0x60]
00007d3d13be04fc  vmovaps xmm8, [rsp+0x70]
00007d3d13be0502  vmovaps xmm9, [rsp+0x80]
00007d3d13be050b  vmovaps xmm10, [rsp+0x90]
00007d3d13be0514  vmovaps xmm11, [rsp+0xA0]
00007d3d13be051d  vmovaps xmm12, [rsp+0xB0]
00007d3d13be0526  vmovaps xmm13, [rsp+0xC0]
00007d3d13be052f  vmovaps xmm14, [rsp+0xD0]
00007d3d13be0538  vmovaps xmm15, [rsp+0xE0]
00007d3d13be0541  add rsp, 0xF0
00007d3d13be0548  pop r11
00007d3d13be054a  pop r10
00007d3d13be054c  pop r9
00007d3d13be054e  pop r8
00007d3d13be0550  pop rsi
00007d3d13be0551  pop rdi
00007d3d13be0552  pop rdx
00007d3d13be0553  pop rcx
00007d3d13be0554  pop rax
00007d3d13be0555  add rsp, 0x08
00007d3d13be0559  jmp 0x00007D3D13BDEE74
00007d3d13be055e  sub rsp, 0x08
00007d3d13be0562  push rax
00007d3d13be0563  push rcx
00007d3d13be0564  push rdx
00007d3d13be0565  push rdi
00007d3d13be0566  push rsi
00007d3d13be0567  push r8
00007d3d13be0569  push r9
00007d3d13be056b  push r10
00007d3d13be056d  push r11
00007d3d13be056f  sub rsp, 0xF0
00007d3d13be0576  vmovaps [rsp], xmm0
00007d3d13be057b  vmovaps [rsp+0x10], xmm1
00007d3d13be0581  vmovaps [rsp+0x20], xmm2
00007d3d13be0587  vmovaps [rsp+0x30], xmm3
00007d3d13be058d  vmovaps [rsp+0x40], xmm4
00007d3d13be0593  vmovaps [rsp+0x50], xmm5
00007d3d13be0599  vmovaps [rsp+0x60], xmm6
00007d3d13be059f  vmovaps [rsp+0x70], xmm7
00007d3d13be05a5  vmovaps [rsp+0x80], xmm8
00007d3d13be05ae  vmovaps [rsp+0x90], xmm10
00007d3d13be05b7  vmovaps [rsp+0xA0], xmm11
00007d3d13be05c0  vmovaps [rsp+0xB0], xmm12
00007d3d13be05c9  vmovaps [rsp+0xC0], xmm13
00007d3d13be05d2  vmovaps [rsp+0xD0], xmm14
00007d3d13be05db  vmovaps [rsp+0xE0], xmm15
00007d3d13be05e4  sub rsp, 0x30
00007d3d13be05e8  movaps [rsp], xmm9
00007d3d13be05ed  movaps [rsp+0x10], xmm10
00007d3d13be05f3  movaps [rsp+0x20], xmm8
00007d3d13be05f9  lea rdi, [rsp]
00007d3d13be05fd  mov esi, 0x00
00007d3d13be0602  mov rax, 0x5741DAFC8530
00007d3d13be060c  call rax
00007d3d13be060e  movaps xmm9, [rsp]
00007d3d13be0613  add rsp, 0x30
00007d3d13be0617  vmovaps xmm0, [rsp]
00007d3d13be061c  vmovaps xmm1, [rsp+0x10]
00007d3d13be0622  vmovaps xmm2, [rsp+0x20]
00007d3d13be0628  vmovaps xmm3, [rsp+0x30]
00007d3d13be062e  vmovaps xmm4, [rsp+0x40]
00007d3d13be0634  vmovaps xmm5, [rsp+0x50]
00007d3d13be063a  vmovaps xmm6, [rsp+0x60]
00007d3d13be0640  vmovaps xmm7, [rsp+0x70]
00007d3d13be0646  vmovaps xmm8, [rsp+0x80]
00007d3d13be064f  vmovaps xmm10, [rsp+0x90]
00007d3d13be0658  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0661  vmovaps xmm12, [rsp+0xB0]
00007d3d13be066a  vmovaps xmm13, [rsp+0xC0]
00007d3d13be0673  vmovaps xmm14, [rsp+0xD0]
00007d3d13be067c  vmovaps xmm15, [rsp+0xE0]
00007d3d13be0685  add rsp, 0xF0
00007d3d13be068c  pop r11
00007d3d13be068e  pop r10
00007d3d13be0690  pop r9
00007d3d13be0692  pop r8
00007d3d13be0694  pop rsi
00007d3d13be0695  pop rdi
00007d3d13be0696  pop rdx
00007d3d13be0697  pop rcx
00007d3d13be0698  pop rax
00007d3d13be0699  add rsp, 0x08
00007d3d13be069d  jmp 0x00007D3D13BDEE8E
00007d3d13be06a2  call 0x00007D3D13AB52F0
00007d3d13be06a7  jmp 0x00007D3D13BDEFA8
00007d3d13be06ac  call 0x00007D3D13AB52F0
00007d3d13be06b1  jmp 0x00007D3D13BDEFBE
00007d3d13be06b6  sub rsp, 0x08
00007d3d13be06ba  push rax
00007d3d13be06bb  push rcx
00007d3d13be06bc  push rdx
00007d3d13be06bd  push rdi
00007d3d13be06be  push rsi
00007d3d13be06bf  push r8
00007d3d13be06c1  push r9
00007d3d13be06c3  push r10
00007d3d13be06c5  push r11
00007d3d13be06c7  sub rsp, 0xF0
00007d3d13be06ce  vmovaps [rsp], xmm0
00007d3d13be06d3  vmovaps [rsp+0x10], xmm2
00007d3d13be06d9  vmovaps [rsp+0x20], xmm3
00007d3d13be06df  vmovaps [rsp+0x30], xmm4
00007d3d13be06e5  vmovaps [rsp+0x40], xmm5
00007d3d13be06eb  vmovaps [rsp+0x50], xmm6
00007d3d13be06f1  vmovaps [rsp+0x60], xmm7
00007d3d13be06f7  vmovaps [rsp+0x70], xmm8
00007d3d13be06fd  vmovaps [rsp+0x80], xmm9
00007d3d13be0706  vmovaps [rsp+0x90], xmm10
00007d3d13be070f  vmovaps [rsp+0xA0], xmm11
00007d3d13be0718  vmovaps [rsp+0xB0], xmm12
00007d3d13be0721  vmovaps [rsp+0xC0], xmm13
00007d3d13be072a  vmovaps [rsp+0xD0], xmm14
00007d3d13be0733  vmovaps [rsp+0xE0], xmm15
00007d3d13be073c  sub rsp, 0x30
00007d3d13be0740  movaps [rsp], xmm1
00007d3d13be0744  movaps [rsp+0x10], xmm6
00007d3d13be0749  movaps [rsp+0x20], xmm15
00007d3d13be074f  lea rdi, [rsp]
00007d3d13be0753  mov esi, 0x00
00007d3d13be0758  mov rax, 0x5741DAFC8530
00007d3d13be0762  call rax
00007d3d13be0764  movaps xmm1, [rsp]
00007d3d13be0768  add rsp, 0x30
00007d3d13be076c  vmovaps xmm0, [rsp]
00007d3d13be0771  vmovaps xmm2, [rsp+0x10]
00007d3d13be0777  vmovaps xmm3, [rsp+0x20]
00007d3d13be077d  vmovaps xmm4, [rsp+0x30]
00007d3d13be0783  vmovaps xmm5, [rsp+0x40]
00007d3d13be0789  vmovaps xmm6, [rsp+0x50]
00007d3d13be078f  vmovaps xmm7, [rsp+0x60]
00007d3d13be0795  vmovaps xmm8, [rsp+0x70]
00007d3d13be079b  vmovaps xmm9, [rsp+0x80]
00007d3d13be07a4  vmovaps xmm10, [rsp+0x90]
00007d3d13be07ad  vmovaps xmm11, [rsp+0xA0]
00007d3d13be07b6  vmovaps xmm12, [rsp+0xB0]
00007d3d13be07bf  vmovaps xmm13, [rsp+0xC0]
00007d3d13be07c8  vmovaps xmm14, [rsp+0xD0]
00007d3d13be07d1  vmovaps xmm15, [rsp+0xE0]
00007d3d13be07da  add rsp, 0xF0
00007d3d13be07e1  pop r11
00007d3d13be07e3  pop r10
00007d3d13be07e5  pop r9
00007d3d13be07e7  pop r8
00007d3d13be07e9  pop rsi
00007d3d13be07ea  pop rdi
00007d3d13be07eb  pop rdx
00007d3d13be07ec  pop rcx
00007d3d13be07ed  pop rax
00007d3d13be07ee  add rsp, 0x08
00007d3d13be07f2  jmp 0x00007D3D13BDEFFB
00007d3d13be07f7  call 0x00007D3D13AC4620
00007d3d13be07fc  jmp 0x00007D3D13BDF008
00007d3d13be0801  sub rsp, 0x08
00007d3d13be0805  push rax
00007d3d13be0806  push rcx
00007d3d13be0807  push rdx
00007d3d13be0808  push rdi
00007d3d13be0809  push rsi
00007d3d13be080a  push r8
00007d3d13be080c  push r9
00007d3d13be080e  push r10
00007d3d13be0810  push r11
00007d3d13be0812  sub rsp, 0xF0
00007d3d13be0819  vmovaps [rsp], xmm0
00007d3d13be081e  vmovaps [rsp+0x10], xmm1
00007d3d13be0824  vmovaps [rsp+0x20], xmm2
00007d3d13be082a  vmovaps [rsp+0x30], xmm3
00007d3d13be0830  vmovaps [rsp+0x40], xmm4
00007d3d13be0836  vmovaps [rsp+0x50], xmm5
00007d3d13be083c  vmovaps [rsp+0x60], xmm6
00007d3d13be0842  vmovaps [rsp+0x70], xmm7
00007d3d13be0848  vmovaps [rsp+0x80], xmm8
00007d3d13be0851  vmovaps [rsp+0x90], xmm9
00007d3d13be085a  vmovaps [rsp+0xA0], xmm10
00007d3d13be0863  vmovaps [rsp+0xB0], xmm11
00007d3d13be086c  vmovaps [rsp+0xC0], xmm12
00007d3d13be0875  vmovaps [rsp+0xD0], xmm13
00007d3d13be087e  vmovaps [rsp+0xE0], xmm15
00007d3d13be0887  sub rsp, 0x30
00007d3d13be088b  movaps [rsp], xmm14
00007d3d13be0890  movaps [rsp+0x10], xmm4
00007d3d13be0895  movaps [rsp+0x20], xmm3
00007d3d13be089a  lea rdi, [rsp]
00007d3d13be089e  mov esi, 0x00
00007d3d13be08a3  mov rax, 0x5741DAFC8530
00007d3d13be08ad  call rax
00007d3d13be08af  movaps xmm14, [rsp]
00007d3d13be08b4  add rsp, 0x30
00007d3d13be08b8  vmovaps xmm0, [rsp]
00007d3d13be08bd  vmovaps xmm1, [rsp+0x10]
00007d3d13be08c3  vmovaps xmm2, [rsp+0x20]
00007d3d13be08c9  vmovaps xmm3, [rsp+0x30]
00007d3d13be08cf  vmovaps xmm4, [rsp+0x40]
00007d3d13be08d5  vmovaps xmm5, [rsp+0x50]
00007d3d13be08db  vmovaps xmm6, [rsp+0x60]
00007d3d13be08e1  vmovaps xmm7, [rsp+0x70]
00007d3d13be08e7  vmovaps xmm8, [rsp+0x80]
00007d3d13be08f0  vmovaps xmm9, [rsp+0x90]
00007d3d13be08f9  vmovaps xmm10, [rsp+0xA0]
00007d3d13be0902  vmovaps xmm11, [rsp+0xB0]
00007d3d13be090b  vmovaps xmm12, [rsp+0xC0]
00007d3d13be0914  vmovaps xmm13, [rsp+0xD0]
00007d3d13be091d  vmovaps xmm15, [rsp+0xE0]
00007d3d13be0926  add rsp, 0xF0
00007d3d13be092d  pop r11
00007d3d13be092f  pop r10
00007d3d13be0931  pop r9
00007d3d13be0933  pop r8
00007d3d13be0935  pop rsi
00007d3d13be0936  pop rdi
00007d3d13be0937  pop rdx
00007d3d13be0938  pop rcx
00007d3d13be0939  pop rax
00007d3d13be093a  add rsp, 0x08
00007d3d13be093e  jmp 0x00007D3D13BDF022
00007d3d13be0943  sub rsp, 0x08
00007d3d13be0947  push rax
00007d3d13be0948  push rcx
00007d3d13be0949  push rdx
00007d3d13be094a  push rdi
00007d3d13be094b  push rsi
00007d3d13be094c  push r8
00007d3d13be094e  push r9
00007d3d13be0950  push r10
00007d3d13be0952  push r11
00007d3d13be0954  sub rsp, 0xF0
00007d3d13be095b  vmovaps [rsp], xmm0
00007d3d13be0960  vmovaps [rsp+0x10], xmm1
00007d3d13be0966  vmovaps [rsp+0x20], xmm2
00007d3d13be096c  vmovaps [rsp+0x30], xmm3
00007d3d13be0972  vmovaps [rsp+0x40], xmm4
00007d3d13be0978  vmovaps [rsp+0x50], xmm5
00007d3d13be097e  vmovaps [rsp+0x60], xmm7
00007d3d13be0984  vmovaps [rsp+0x70], xmm8
00007d3d13be098a  vmovaps [rsp+0x80], xmm9
00007d3d13be0993  vmovaps [rsp+0x90], xmm10
00007d3d13be099c  vmovaps [rsp+0xA0], xmm11
00007d3d13be09a5  vmovaps [rsp+0xB0], xmm12
00007d3d13be09ae  vmovaps [rsp+0xC0], xmm13
00007d3d13be09b7  vmovaps [rsp+0xD0], xmm14
00007d3d13be09c0  vmovaps [rsp+0xE0], xmm15
00007d3d13be09c9  sub rsp, 0x30
00007d3d13be09cd  movaps [rsp], xmm6
00007d3d13be09d1  movaps [rsp+0x10], xmm9
00007d3d13be09d7  movaps [rsp+0x20], xmm7
00007d3d13be09dc  lea rdi, [rsp]
00007d3d13be09e0  mov esi, 0x00
00007d3d13be09e5  mov rax, 0x5741DAFC8530
00007d3d13be09ef  call rax
00007d3d13be09f1  movaps xmm6, [rsp]
00007d3d13be09f5  add rsp, 0x30
00007d3d13be09f9  vmovaps xmm0, [rsp]
00007d3d13be09fe  vmovaps xmm1, [rsp+0x10]
00007d3d13be0a04  vmovaps xmm2, [rsp+0x20]
00007d3d13be0a0a  vmovaps xmm3, [rsp+0x30]
00007d3d13be0a10  vmovaps xmm4, [rsp+0x40]
00007d3d13be0a16  vmovaps xmm5, [rsp+0x50]
00007d3d13be0a1c  vmovaps xmm7, [rsp+0x60]
00007d3d13be0a22  vmovaps xmm8, [rsp+0x70]
00007d3d13be0a28  vmovaps xmm9, [rsp+0x80]
00007d3d13be0a31  vmovaps xmm10, [rsp+0x90]
00007d3d13be0a3a  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0a43  vmovaps xmm12, [rsp+0xB0]
00007d3d13be0a4c  vmovaps xmm13, [rsp+0xC0]
00007d3d13be0a55  vmovaps xmm14, [rsp+0xD0]
00007d3d13be0a5e  vmovaps xmm15, [rsp+0xE0]
00007d3d13be0a67  add rsp, 0xF0
00007d3d13be0a6e  pop r11
00007d3d13be0a70  pop r10
00007d3d13be0a72  pop r9
00007d3d13be0a74  pop r8
00007d3d13be0a76  pop rsi
00007d3d13be0a77  pop rdi
00007d3d13be0a78  pop rdx
00007d3d13be0a79  pop rcx
00007d3d13be0a7a  pop rax
00007d3d13be0a7b  add rsp, 0x08
00007d3d13be0a7f  jmp 0x00007D3D13BDF03A
00007d3d13be0a84  sub rsp, 0x08
00007d3d13be0a88  push rax
00007d3d13be0a89  push rcx
00007d3d13be0a8a  push rdx
00007d3d13be0a8b  push rdi
00007d3d13be0a8c  push rsi
00007d3d13be0a8d  push r8
00007d3d13be0a8f  push r9
00007d3d13be0a91  push r10
00007d3d13be0a93  push r11
00007d3d13be0a95  sub rsp, 0xF0
00007d3d13be0a9c  vmovaps [rsp], xmm0
00007d3d13be0aa1  vmovaps [rsp+0x10], xmm1
00007d3d13be0aa7  vmovaps [rsp+0x20], xmm2
00007d3d13be0aad  vmovaps [rsp+0x30], xmm3
00007d3d13be0ab3  vmovaps [rsp+0x40], xmm4
00007d3d13be0ab9  vmovaps [rsp+0x50], xmm5
00007d3d13be0abf  vmovaps [rsp+0x60], xmm6
00007d3d13be0ac5  vmovaps [rsp+0x70], xmm8
00007d3d13be0acb  vmovaps [rsp+0x80], xmm9
00007d3d13be0ad4  vmovaps [rsp+0x90], xmm10
00007d3d13be0add  vmovaps [rsp+0xA0], xmm11
00007d3d13be0ae6  vmovaps [rsp+0xB0], xmm12
00007d3d13be0aef  vmovaps [rsp+0xC0], xmm13
00007d3d13be0af8  vmovaps [rsp+0xD0], xmm14
00007d3d13be0b01  vmovaps [rsp+0xE0], xmm15
00007d3d13be0b0a  sub rsp, 0x30
00007d3d13be0b0e  movaps [rsp], xmm7
00007d3d13be0b12  movaps [rsp+0x10], xmm4
00007d3d13be0b17  movaps [rsp+0x20], xmm9
00007d3d13be0b1d  lea rdi, [rsp]
00007d3d13be0b21  mov esi, 0x00
00007d3d13be0b26  mov rax, 0x5741DAFC8530
00007d3d13be0b30  call rax
00007d3d13be0b32  movaps xmm7, [rsp]
00007d3d13be0b36  add rsp, 0x30
00007d3d13be0b3a  vmovaps xmm0, [rsp]
00007d3d13be0b3f  vmovaps xmm1, [rsp+0x10]
00007d3d13be0b45  vmovaps xmm2, [rsp+0x20]
00007d3d13be0b4b  vmovaps xmm3, [rsp+0x30]
00007d3d13be0b51  vmovaps xmm4, [rsp+0x40]
00007d3d13be0b57  vmovaps xmm5, [rsp+0x50]
00007d3d13be0b5d  vmovaps xmm6, [rsp+0x60]
00007d3d13be0b63  vmovaps xmm8, [rsp+0x70]
00007d3d13be0b69  vmovaps xmm9, [rsp+0x80]
00007d3d13be0b72  vmovaps xmm10, [rsp+0x90]
00007d3d13be0b7b  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0b84  vmovaps xmm12, [rsp+0xB0]
00007d3d13be0b8d  vmovaps xmm13, [rsp+0xC0]
00007d3d13be0b96  vmovaps xmm14, [rsp+0xD0]
00007d3d13be0b9f  vmovaps xmm15, [rsp+0xE0]
00007d3d13be0ba8  add rsp, 0xF0
00007d3d13be0baf  pop r11
00007d3d13be0bb1  pop r10
00007d3d13be0bb3  pop r9
00007d3d13be0bb5  pop r8
00007d3d13be0bb7  pop rsi
00007d3d13be0bb8  pop rdi
00007d3d13be0bb9  pop rdx
00007d3d13be0bba  pop rcx
00007d3d13be0bbb  pop rax
00007d3d13be0bbc  add rsp, 0x08
00007d3d13be0bc0  jmp 0x00007D3D13BDF067
00007d3d13be0bc5  sub rsp, 0x08
00007d3d13be0bc9  push rax
00007d3d13be0bca  push rcx
00007d3d13be0bcb  push rdx
00007d3d13be0bcc  push rdi
00007d3d13be0bcd  push rsi
00007d3d13be0bce  push r8
00007d3d13be0bd0  push r9
00007d3d13be0bd2  push r10
00007d3d13be0bd4  push r11
00007d3d13be0bd6  sub rsp, 0xF0
00007d3d13be0bdd  vmovaps [rsp], xmm0
00007d3d13be0be2  vmovaps [rsp+0x10], xmm1
00007d3d13be0be8  vmovaps [rsp+0x20], xmm2
00007d3d13be0bee  vmovaps [rsp+0x30], xmm3
00007d3d13be0bf4  vmovaps [rsp+0x40], xmm5
00007d3d13be0bfa  vmovaps [rsp+0x50], xmm6
00007d3d13be0c00  vmovaps [rsp+0x60], xmm7
00007d3d13be0c06  vmovaps [rsp+0x70], xmm8
00007d3d13be0c0c  vmovaps [rsp+0x80], xmm9
00007d3d13be0c15  vmovaps [rsp+0x90], xmm10
00007d3d13be0c1e  vmovaps [rsp+0xA0], xmm11
00007d3d13be0c27  vmovaps [rsp+0xB0], xmm12
00007d3d13be0c30  vmovaps [rsp+0xC0], xmm13
00007d3d13be0c39  vmovaps [rsp+0xD0], xmm14
00007d3d13be0c42  vmovaps [rsp+0xE0], xmm15
00007d3d13be0c4b  sub rsp, 0x30
00007d3d13be0c4f  movaps [rsp], xmm4
00007d3d13be0c53  movaps [rsp+0x10], xmm15
00007d3d13be0c59  movaps [rsp+0x20], xmm9
00007d3d13be0c5f  lea rdi, [rsp]
00007d3d13be0c63  mov esi, 0x00
00007d3d13be0c68  mov rax, 0x5741DAFC8530
00007d3d13be0c72  call rax
00007d3d13be0c74  movaps xmm4, [rsp]
00007d3d13be0c78  add rsp, 0x30
00007d3d13be0c7c  vmovaps xmm0, [rsp]
00007d3d13be0c81  vmovaps xmm1, [rsp+0x10]
00007d3d13be0c87  vmovaps xmm2, [rsp+0x20]
00007d3d13be0c8d  vmovaps xmm3, [rsp+0x30]
00007d3d13be0c93  vmovaps xmm5, [rsp+0x40]
00007d3d13be0c99  vmovaps xmm6, [rsp+0x50]
00007d3d13be0c9f  vmovaps xmm7, [rsp+0x60]
00007d3d13be0ca5  vmovaps xmm8, [rsp+0x70]
00007d3d13be0cab  vmovaps xmm9, [rsp+0x80]
00007d3d13be0cb4  vmovaps xmm10, [rsp+0x90]
00007d3d13be0cbd  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0cc6  vmovaps xmm12, [rsp+0xB0]
00007d3d13be0ccf  vmovaps xmm13, [rsp+0xC0]
00007d3d13be0cd8  vmovaps xmm14, [rsp+0xD0]
00007d3d13be0ce1  vmovaps xmm15, [rsp+0xE0]
00007d3d13be0cea  add rsp, 0xF0
00007d3d13be0cf1  pop r11
00007d3d13be0cf3  pop r10
00007d3d13be0cf5  pop r9
00007d3d13be0cf7  pop r8
00007d3d13be0cf9  pop rsi
00007d3d13be0cfa  pop rdi
00007d3d13be0cfb  pop rdx
00007d3d13be0cfc  pop rcx
00007d3d13be0cfd  pop rax
00007d3d13be0cfe  add rsp, 0x08
00007d3d13be0d02  jmp 0x00007D3D13BDF08C
00007d3d13be0d07  call 0x00007D3D13AC4620
00007d3d13be0d0c  jmp 0x00007D3D13BDF099
00007d3d13be0d11  sub rsp, 0x08
00007d3d13be0d15  push rax
00007d3d13be0d16  push rcx
00007d3d13be0d17  push rdx
00007d3d13be0d18  push rdi
00007d3d13be0d19  push rsi
00007d3d13be0d1a  push r8
00007d3d13be0d1c  push r9
00007d3d13be0d1e  push r10
00007d3d13be0d20  push r11
00007d3d13be0d22  sub rsp, 0xF0
00007d3d13be0d29  vmovaps [rsp], xmm0
00007d3d13be0d2e  vmovaps [rsp+0x10], xmm1
00007d3d13be0d34  vmovaps [rsp+0x20], xmm2
00007d3d13be0d3a  vmovaps [rsp+0x30], xmm4
00007d3d13be0d40  vmovaps [rsp+0x40], xmm5
00007d3d13be0d46  vmovaps [rsp+0x50], xmm6
00007d3d13be0d4c  vmovaps [rsp+0x60], xmm7
00007d3d13be0d52  vmovaps [rsp+0x70], xmm8
00007d3d13be0d58  vmovaps [rsp+0x80], xmm9
00007d3d13be0d61  vmovaps [rsp+0x90], xmm10
00007d3d13be0d6a  vmovaps [rsp+0xA0], xmm11
00007d3d13be0d73  vmovaps [rsp+0xB0], xmm12
00007d3d13be0d7c  vmovaps [rsp+0xC0], xmm13
00007d3d13be0d85  vmovaps [rsp+0xD0], xmm14
00007d3d13be0d8e  vmovaps [rsp+0xE0], xmm15
00007d3d13be0d97  sub rsp, 0x30
00007d3d13be0d9b  movaps [rsp], xmm3
00007d3d13be0d9f  movaps [rsp+0x10], xmm1
00007d3d13be0da4  movaps [rsp+0x20], xmm9
00007d3d13be0daa  lea rdi, [rsp]
00007d3d13be0dae  mov esi, 0x00
00007d3d13be0db3  mov rax, 0x5741DAFC8530
00007d3d13be0dbd  call rax
00007d3d13be0dbf  movaps xmm3, [rsp]
00007d3d13be0dc3  add rsp, 0x30
00007d3d13be0dc7  vmovaps xmm0, [rsp]
00007d3d13be0dcc  vmovaps xmm1, [rsp+0x10]
00007d3d13be0dd2  vmovaps xmm2, [rsp+0x20]
00007d3d13be0dd8  vmovaps xmm4, [rsp+0x30]
00007d3d13be0dde  vmovaps xmm5, [rsp+0x40]
00007d3d13be0de4  vmovaps xmm6, [rsp+0x50]
00007d3d13be0dea  vmovaps xmm7, [rsp+0x60]
00007d3d13be0df0  vmovaps xmm8, [rsp+0x70]
00007d3d13be0df6  vmovaps xmm9, [rsp+0x80]
00007d3d13be0dff  vmovaps xmm10, [rsp+0x90]
00007d3d13be0e08  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0e11  vmovaps xmm12, [rsp+0xB0]
00007d3d13be0e1a  vmovaps xmm13, [rsp+0xC0]
00007d3d13be0e23  vmovaps xmm14, [rsp+0xD0]
00007d3d13be0e2c  vmovaps xmm15, [rsp+0xE0]
00007d3d13be0e35  add rsp, 0xF0
00007d3d13be0e3c  pop r11
00007d3d13be0e3e  pop r10
00007d3d13be0e40  pop r9
00007d3d13be0e42  pop r8
00007d3d13be0e44  pop rsi
00007d3d13be0e45  pop rdi
00007d3d13be0e46  pop rdx
00007d3d13be0e47  pop rcx
00007d3d13be0e48  pop rax
00007d3d13be0e49  add rsp, 0x08
00007d3d13be0e4d  jmp 0x00007D3D13BDF0D6
00007d3d13be0e52  sub rsp, 0x08
00007d3d13be0e56  push rax
00007d3d13be0e57  push rcx
00007d3d13be0e58  push rdx
00007d3d13be0e59  push rdi
00007d3d13be0e5a  push rsi
00007d3d13be0e5b  push r8
00007d3d13be0e5d  push r9
00007d3d13be0e5f  push r10
00007d3d13be0e61  push r11
00007d3d13be0e63  sub rsp, 0xF0
00007d3d13be0e6a  vmovaps [rsp], xmm0
00007d3d13be0e6f  vmovaps [rsp+0x10], xmm2
00007d3d13be0e75  vmovaps [rsp+0x20], xmm3
00007d3d13be0e7b  vmovaps [rsp+0x30], xmm4
00007d3d13be0e81  vmovaps [rsp+0x40], xmm5
00007d3d13be0e87  vmovaps [rsp+0x50], xmm6
00007d3d13be0e8d  vmovaps [rsp+0x60], xmm7
00007d3d13be0e93  vmovaps [rsp+0x70], xmm8
00007d3d13be0e99  vmovaps [rsp+0x80], xmm9
00007d3d13be0ea2  vmovaps [rsp+0x90], xmm10
00007d3d13be0eab  vmovaps [rsp+0xA0], xmm11
00007d3d13be0eb4  vmovaps [rsp+0xB0], xmm12
00007d3d13be0ebd  vmovaps [rsp+0xC0], xmm13
00007d3d13be0ec6  vmovaps [rsp+0xD0], xmm14
00007d3d13be0ecf  vmovaps [rsp+0xE0], xmm15
00007d3d13be0ed8  sub rsp, 0x30
00007d3d13be0edc  movaps [rsp], xmm1
00007d3d13be0ee0  movaps [rsp+0x10], xmm15
00007d3d13be0ee6  movaps [rsp+0x20], xmm9
00007d3d13be0eec  lea rdi, [rsp]
00007d3d13be0ef0  mov esi, 0x00
00007d3d13be0ef5  mov rax, 0x5741DAFC8530
00007d3d13be0eff  call rax
00007d3d13be0f01  movaps xmm1, [rsp]
00007d3d13be0f05  add rsp, 0x30
00007d3d13be0f09  vmovaps xmm0, [rsp]
00007d3d13be0f0e  vmovaps xmm2, [rsp+0x10]
00007d3d13be0f14  vmovaps xmm3, [rsp+0x20]
00007d3d13be0f1a  vmovaps xmm4, [rsp+0x30]
00007d3d13be0f20  vmovaps xmm5, [rsp+0x40]
00007d3d13be0f26  vmovaps xmm6, [rsp+0x50]
00007d3d13be0f2c  vmovaps xmm7, [rsp+0x60]
00007d3d13be0f32  vmovaps xmm8, [rsp+0x70]
00007d3d13be0f38  vmovaps xmm9, [rsp+0x80]
00007d3d13be0f41  vmovaps xmm10, [rsp+0x90]
00007d3d13be0f4a  vmovaps xmm11, [rsp+0xA0]
00007d3d13be0f53  vmovaps xmm12, [rsp+0xB0]
00007d3d13be0f5c  vmovaps xmm13, [rsp+0xC0]
00007d3d13be0f65  vmovaps xmm14, [rsp+0xD0]
00007d3d13be0f6e  vmovaps xmm15, [rsp+0xE0]
00007d3d13be0f77  add rsp, 0xF0
00007d3d13be0f7e  pop r11
00007d3d13be0f80  pop r10
00007d3d13be0f82  pop r9
00007d3d13be0f84  pop r8
00007d3d13be0f86  pop rsi
00007d3d13be0f87  pop rdi
00007d3d13be0f88  pop rdx
00007d3d13be0f89  pop rcx
00007d3d13be0f8a  pop rax
00007d3d13be0f8b  add rsp, 0x08
00007d3d13be0f8f  jmp 0x00007D3D13BDF15E
00007d3d13be0f94  call 0x00007D3D13AC4620
00007d3d13be0f99  jmp 0x00007D3D13BDF16B
00007d3d13be0f9e  sub rsp, 0x08
00007d3d13be0fa2  push rax
00007d3d13be0fa3  push rcx
00007d3d13be0fa4  push rdx
00007d3d13be0fa5  push rdi
00007d3d13be0fa6  push rsi
00007d3d13be0fa7  push r8
00007d3d13be0fa9  push r9
00007d3d13be0fab  push r10
00007d3d13be0fad  push r11
00007d3d13be0faf  sub rsp, 0xF0
00007d3d13be0fb6  vmovaps [rsp], xmm0
00007d3d13be0fbb  vmovaps [rsp+0x10], xmm2
00007d3d13be0fc1  vmovaps [rsp+0x20], xmm3
00007d3d13be0fc7  vmovaps [rsp+0x30], xmm4
00007d3d13be0fcd  vmovaps [rsp+0x40], xmm5
00007d3d13be0fd3  vmovaps [rsp+0x50], xmm6
00007d3d13be0fd9  vmovaps [rsp+0x60], xmm7
00007d3d13be0fdf  vmovaps [rsp+0x70], xmm8
00007d3d13be0fe5  vmovaps [rsp+0x80], xmm9
00007d3d13be0fee  vmovaps [rsp+0x90], xmm10
00007d3d13be0ff7  vmovaps [rsp+0xA0], xmm11
00007d3d13be1000  vmovaps [rsp+0xB0], xmm12
00007d3d13be1009  vmovaps [rsp+0xC0], xmm13
00007d3d13be1012  vmovaps [rsp+0xD0], xmm14
00007d3d13be101b  vmovaps [rsp+0xE0], xmm15
00007d3d13be1024  sub rsp, 0x30
00007d3d13be1028  movaps [rsp], xmm1
00007d3d13be102c  movaps [rsp+0x10], xmm5
00007d3d13be1031  movaps [rsp+0x20], xmm7
00007d3d13be1036  lea rdi, [rsp]
00007d3d13be103a  mov esi, 0x00
00007d3d13be103f  mov rax, 0x5741DAFC8530
00007d3d13be1049  call rax
00007d3d13be104b  movaps xmm1, [rsp]
00007d3d13be104f  add rsp, 0x30
00007d3d13be1053  vmovaps xmm0, [rsp]
00007d3d13be1058  vmovaps xmm2, [rsp+0x10]
00007d3d13be105e  vmovaps xmm3, [rsp+0x20]
00007d3d13be1064  vmovaps xmm4, [rsp+0x30]
00007d3d13be106a  vmovaps xmm5, [rsp+0x40]
00007d3d13be1070  vmovaps xmm6, [rsp+0x50]
00007d3d13be1076  vmovaps xmm7, [rsp+0x60]
00007d3d13be107c  vmovaps xmm8, [rsp+0x70]
00007d3d13be1082  vmovaps xmm9, [rsp+0x80]
00007d3d13be108b  vmovaps xmm10, [rsp+0x90]
00007d3d13be1094  vmovaps xmm11, [rsp+0xA0]
00007d3d13be109d  vmovaps xmm12, [rsp+0xB0]
00007d3d13be10a6  vmovaps xmm13, [rsp+0xC0]
00007d3d13be10af  vmovaps xmm14, [rsp+0xD0]
00007d3d13be10b8  vmovaps xmm15, [rsp+0xE0]
00007d3d13be10c1  add rsp, 0xF0
00007d3d13be10c8  pop r11
00007d3d13be10ca  pop r10
00007d3d13be10cc  pop r9
00007d3d13be10ce  pop r8
00007d3d13be10d0  pop rsi
00007d3d13be10d1  pop rdi
00007d3d13be10d2  pop rdx
00007d3d13be10d3  pop rcx
00007d3d13be10d4  pop rax
00007d3d13be10d5  add rsp, 0x08
00007d3d13be10d9  jmp 0x00007D3D13BDF210
00007d3d13be10de  sub rsp, 0x08
00007d3d13be10e2  push rax
00007d3d13be10e3  push rcx
00007d3d13be10e4  push rdx
00007d3d13be10e5  push rdi
00007d3d13be10e6  push rsi
00007d3d13be10e7  push r8
00007d3d13be10e9  push r9
00007d3d13be10eb  push r10
00007d3d13be10ed  push r11
00007d3d13be10ef  sub rsp, 0xF0
00007d3d13be10f6  vmovaps [rsp], xmm0
00007d3d13be10fb  vmovaps [rsp+0x10], xmm1
00007d3d13be1101  vmovaps [rsp+0x20], xmm2
00007d3d13be1107  vmovaps [rsp+0x30], xmm3
00007d3d13be110d  vmovaps [rsp+0x40], xmm4
00007d3d13be1113  vmovaps [rsp+0x50], xmm5
00007d3d13be1119  vmovaps [rsp+0x60], xmm6
00007d3d13be111f  vmovaps [rsp+0x70], xmm8
00007d3d13be1125  vmovaps [rsp+0x80], xmm9
00007d3d13be112e  vmovaps [rsp+0x90], xmm10
00007d3d13be1137  vmovaps [rsp+0xA0], xmm11
00007d3d13be1140  vmovaps [rsp+0xB0], xmm12
00007d3d13be1149  vmovaps [rsp+0xC0], xmm13
00007d3d13be1152  vmovaps [rsp+0xD0], xmm14
00007d3d13be115b  vmovaps [rsp+0xE0], xmm15
00007d3d13be1164  sub rsp, 0x30
00007d3d13be1168  movaps [rsp], xmm7
00007d3d13be116c  movaps [rsp+0x10], xmm5
00007d3d13be1171  movaps [rsp+0x20], xmm15
00007d3d13be1177  lea rdi, [rsp]
00007d3d13be117b  mov esi, 0x00
00007d3d13be1180  mov rax, 0x5741DAFC8530
00007d3d13be118a  call rax
00007d3d13be118c  movaps xmm7, [rsp]
00007d3d13be1190  add rsp, 0x30
00007d3d13be1194  vmovaps xmm0, [rsp]
00007d3d13be1199  vmovaps xmm1, [rsp+0x10]
00007d3d13be119f  vmovaps xmm2, [rsp+0x20]
00007d3d13be11a5  vmovaps xmm3, [rsp+0x30]
00007d3d13be11ab  vmovaps xmm4, [rsp+0x40]
00007d3d13be11b1  vmovaps xmm5, [rsp+0x50]
00007d3d13be11b7  vmovaps xmm6, [rsp+0x60]
00007d3d13be11bd  vmovaps xmm8, [rsp+0x70]
00007d3d13be11c3  vmovaps xmm9, [rsp+0x80]
00007d3d13be11cc  vmovaps xmm10, [rsp+0x90]
00007d3d13be11d5  vmovaps xmm11, [rsp+0xA0]
00007d3d13be11de  vmovaps xmm12, [rsp+0xB0]
00007d3d13be11e7  vmovaps xmm13, [rsp+0xC0]
00007d3d13be11f0  vmovaps xmm14, [rsp+0xD0]
00007d3d13be11f9  vmovaps xmm15, [rsp+0xE0]
00007d3d13be1202  add rsp, 0xF0
00007d3d13be1209  pop r11
00007d3d13be120b  pop r10
00007d3d13be120d  pop r9
00007d3d13be120f  pop r8
00007d3d13be1211  pop rsi
00007d3d13be1212  pop rdi
00007d3d13be1213  pop rdx
00007d3d13be1214  pop rcx
00007d3d13be1215  pop rax
00007d3d13be1216  add rsp, 0x08
00007d3d13be121a  jmp 0x00007D3D13BDF246
00007d3d13be121f  call 0x00007D3D13AB52F0
00007d3d13be1224  jmp 0x00007D3D13BDF253
00007d3d13be1229  sub rsp, 0x08
00007d3d13be122d  push rax
00007d3d13be122e  push rcx
00007d3d13be122f  push rdx
00007d3d13be1230  push rdi
00007d3d13be1231  push rsi
00007d3d13be1232  push r8
00007d3d13be1234  push r9
00007d3d13be1236  push r10
00007d3d13be1238  push r11
00007d3d13be123a  sub rsp, 0xF0
00007d3d13be1241  vmovaps [rsp], xmm0
00007d3d13be1246  vmovaps [rsp+0x10], xmm1
00007d3d13be124c  vmovaps [rsp+0x20], xmm2
00007d3d13be1252  vmovaps [rsp+0x30], xmm3
00007d3d13be1258  vmovaps [rsp+0x40], xmm4
00007d3d13be125e  vmovaps [rsp+0x50], xmm5
00007d3d13be1264  vmovaps [rsp+0x60], xmm6
00007d3d13be126a  vmovaps [rsp+0x70], xmm7
00007d3d13be1270  vmovaps [rsp+0x80], xmm8
00007d3d13be1279  vmovaps [rsp+0x90], xmm9
00007d3d13be1282  vmovaps [rsp+0xA0], xmm10
00007d3d13be128b  vmovaps [rsp+0xB0], xmm11
00007d3d13be1294  vmovaps [rsp+0xC0], xmm12
00007d3d13be129d  vmovaps [rsp+0xD0], xmm13
00007d3d13be12a6  vmovaps [rsp+0xE0], xmm14
00007d3d13be12af  sub rsp, 0x30
00007d3d13be12b3  movaps [rsp], xmm15
00007d3d13be12b8  movaps [rsp+0x10], xmm5
00007d3d13be12bd  movaps [rsp+0x20], xmm3
00007d3d13be12c2  lea rdi, [rsp]
00007d3d13be12c6  mov esi, 0x00
00007d3d13be12cb  mov rax, 0x5741DAFC8530
00007d3d13be12d5  call rax
00007d3d13be12d7  movaps xmm15, [rsp]
00007d3d13be12dc  add rsp, 0x30
00007d3d13be12e0  vmovaps xmm0, [rsp]
00007d3d13be12e5  vmovaps xmm1, [rsp+0x10]
00007d3d13be12eb  vmovaps xmm2, [rsp+0x20]
00007d3d13be12f1  vmovaps xmm3, [rsp+0x30]
00007d3d13be12f7  vmovaps xmm4, [rsp+0x40]
00007d3d13be12fd  vmovaps xmm5, [rsp+0x50]
00007d3d13be1303  vmovaps xmm6, [rsp+0x60]
00007d3d13be1309  vmovaps xmm7, [rsp+0x70]
00007d3d13be130f  vmovaps xmm8, [rsp+0x80]
00007d3d13be1318  vmovaps xmm9, [rsp+0x90]
00007d3d13be1321  vmovaps xmm10, [rsp+0xA0]
00007d3d13be132a  vmovaps xmm11, [rsp+0xB0]
00007d3d13be1333  vmovaps xmm12, [rsp+0xC0]
00007d3d13be133c  vmovaps xmm13, [rsp+0xD0]
00007d3d13be1345  vmovaps xmm14, [rsp+0xE0]
00007d3d13be134e  add rsp, 0xF0
00007d3d13be1355  pop r11
00007d3d13be1357  pop r10
00007d3d13be1359  pop r9
00007d3d13be135b  pop r8
00007d3d13be135d  pop rsi
00007d3d13be135e  pop rdi
00007d3d13be135f  pop rdx
00007d3d13be1360  pop rcx
00007d3d13be1361  pop rax
00007d3d13be1362  add rsp, 0x08
00007d3d13be1366  jmp 0x00007D3D13BDF279
00007d3d13be136b  sub rsp, 0x08
00007d3d13be136f  push rax
00007d3d13be1370  push rcx
00007d3d13be1371  push rdx
00007d3d13be1372  push rdi
00007d3d13be1373  push rsi
00007d3d13be1374  push r8
00007d3d13be1376  push r9
00007d3d13be1378  push r10
00007d3d13be137a  push r11
00007d3d13be137c  sub rsp, 0xF0
00007d3d13be1383  vmovaps [rsp], xmm0
00007d3d13be1388  vmovaps [rsp+0x10], xmm2
00007d3d13be138e  vmovaps [rsp+0x20], xmm3
00007d3d13be1394  vmovaps [rsp+0x30], xmm4
00007d3d13be139a  vmovaps [rsp+0x40], xmm5
00007d3d13be13a0  vmovaps [rsp+0x50], xmm6
00007d3d13be13a6  vmovaps [rsp+0x60], xmm7
00007d3d13be13ac  vmovaps [rsp+0x70], xmm8
00007d3d13be13b2  vmovaps [rsp+0x80], xmm9
00007d3d13be13bb  vmovaps [rsp+0x90], xmm10
00007d3d13be13c4  vmovaps [rsp+0xA0], xmm11
00007d3d13be13cd  vmovaps [rsp+0xB0], xmm12
00007d3d13be13d6  vmovaps [rsp+0xC0], xmm13
00007d3d13be13df  vmovaps [rsp+0xD0], xmm14
00007d3d13be13e8  vmovaps [rsp+0xE0], xmm15
00007d3d13be13f1  sub rsp, 0x30
00007d3d13be13f5  movaps [rsp], xmm1
00007d3d13be13f9  movaps [rsp+0x10], xmm5
00007d3d13be13fe  movaps [rsp+0x20], xmm4
00007d3d13be1403  lea rdi, [rsp]
00007d3d13be1407  mov esi, 0x00
00007d3d13be140c  mov rax, 0x5741DAFC8530
00007d3d13be1416  call rax
00007d3d13be1418  movaps xmm1, [rsp]
00007d3d13be141c  add rsp, 0x30
00007d3d13be1420  vmovaps xmm0, [rsp]
00007d3d13be1425  vmovaps xmm2, [rsp+0x10]
00007d3d13be142b  vmovaps xmm3, [rsp+0x20]
00007d3d13be1431  vmovaps xmm4, [rsp+0x30]
00007d3d13be1437  vmovaps xmm5, [rsp+0x40]
00007d3d13be143d  vmovaps xmm6, [rsp+0x50]
00007d3d13be1443  vmovaps xmm7, [rsp+0x60]
00007d3d13be1449  vmovaps xmm8, [rsp+0x70]
00007d3d13be144f  vmovaps xmm9, [rsp+0x80]
00007d3d13be1458  vmovaps xmm10, [rsp+0x90]
00007d3d13be1461  vmovaps xmm11, [rsp+0xA0]
00007d3d13be146a  vmovaps xmm12, [rsp+0xB0]
00007d3d13be1473  vmovaps xmm13, [rsp+0xC0]
00007d3d13be147c  vmovaps xmm14, [rsp+0xD0]
00007d3d13be1485  vmovaps xmm15, [rsp+0xE0]
00007d3d13be148e  add rsp, 0xF0
00007d3d13be1495  pop r11
00007d3d13be1497  pop r10
00007d3d13be1499  pop r9
00007d3d13be149b  pop r8
00007d3d13be149d  pop rsi
00007d3d13be149e  pop rdi
00007d3d13be149f  pop rdx
00007d3d13be14a0  pop rcx
00007d3d13be14a1  pop rax
00007d3d13be14a2  add rsp, 0x08
00007d3d13be14a6  jmp 0x00007D3D13BDF299
00007d3d13be14ab  sub rsp, 0x08
00007d3d13be14af  push rax
00007d3d13be14b0  push rcx
00007d3d13be14b1  push rdx
00007d3d13be14b2  push rdi
00007d3d13be14b3  push rsi
00007d3d13be14b4  push r8
00007d3d13be14b6  push r9
00007d3d13be14b8  push r10
00007d3d13be14ba  push r11
00007d3d13be14bc  sub rsp, 0xF0
00007d3d13be14c3  vmovaps [rsp], xmm0
00007d3d13be14c8  vmovaps [rsp+0x10], xmm1
00007d3d13be14ce  vmovaps [rsp+0x20], xmm2
00007d3d13be14d4  vmovaps [rsp+0x30], xmm3
00007d3d13be14da  vmovaps [rsp+0x40], xmm5
00007d3d13be14e0  vmovaps [rsp+0x50], xmm6
00007d3d13be14e6  vmovaps [rsp+0x60], xmm7
00007d3d13be14ec  vmovaps [rsp+0x70], xmm8
00007d3d13be14f2  vmovaps [rsp+0x80], xmm9
00007d3d13be14fb  vmovaps [rsp+0x90], xmm10
00007d3d13be1504  vmovaps [rsp+0xA0], xmm11
00007d3d13be150d  vmovaps [rsp+0xB0], xmm12
00007d3d13be1516  vmovaps [rsp+0xC0], xmm13
00007d3d13be151f  vmovaps [rsp+0xD0], xmm14
00007d3d13be1528  vmovaps [rsp+0xE0], xmm15
00007d3d13be1531  sub rsp, 0x30
00007d3d13be1535  movaps [rsp], xmm4
00007d3d13be1539  movaps [rsp+0x10], xmm3
00007d3d13be153e  movaps [rsp+0x20], xmm5
00007d3d13be1543  lea rdi, [rsp]
00007d3d13be1547  mov esi, 0x00
00007d3d13be154c  mov rax, 0x5741DAFC8530
00007d3d13be1556  call rax
00007d3d13be1558  movaps xmm4, [rsp]
00007d3d13be155c  add rsp, 0x30
00007d3d13be1560  vmovaps xmm0, [rsp]
00007d3d13be1565  vmovaps xmm1, [rsp+0x10]
00007d3d13be156b  vmovaps xmm2, [rsp+0x20]
00007d3d13be1571  vmovaps xmm3, [rsp+0x30]
00007d3d13be1577  vmovaps xmm5, [rsp+0x40]
00007d3d13be157d  vmovaps xmm6, [rsp+0x50]
00007d3d13be1583  vmovaps xmm7, [rsp+0x60]
00007d3d13be1589  vmovaps xmm8, [rsp+0x70]
00007d3d13be158f  vmovaps xmm9, [rsp+0x80]
00007d3d13be1598  vmovaps xmm10, [rsp+0x90]
00007d3d13be15a1  vmovaps xmm11, [rsp+0xA0]
00007d3d13be15aa  vmovaps xmm12, [rsp+0xB0]
00007d3d13be15b3  vmovaps xmm13, [rsp+0xC0]
00007d3d13be15bc  vmovaps xmm14, [rsp+0xD0]
00007d3d13be15c5  vmovaps xmm15, [rsp+0xE0]
00007d3d13be15ce  add rsp, 0xF0
00007d3d13be15d5  pop r11
00007d3d13be15d7  pop r10
00007d3d13be15d9  pop r9
00007d3d13be15db  pop r8
00007d3d13be15dd  pop rsi
00007d3d13be15de  pop rdi
00007d3d13be15df  pop rdx
00007d3d13be15e0  pop rcx
00007d3d13be15e1  pop rax
00007d3d13be15e2  add rsp, 0x08
00007d3d13be15e6  jmp 0x00007D3D13BDF2E7
00007d3d13be15eb  call 0x00007D3D13AB52F0
00007d3d13be15f0  jmp 0x00007D3D13BDF2F4
00007d3d13be15f5  sub rsp, 0x08
00007d3d13be15f9  push rax
00007d3d13be15fa  push rcx
00007d3d13be15fb  push rdx
00007d3d13be15fc  push rdi
00007d3d13be15fd  push rsi
00007d3d13be15fe  push r8
00007d3d13be1600  push r9
00007d3d13be1602  push r10
00007d3d13be1604  push r11
00007d3d13be1606  sub rsp, 0xF0
00007d3d13be160d  vmovaps [rsp], xmm0
00007d3d13be1612  vmovaps [rsp+0x10], xmm1
00007d3d13be1618  vmovaps [rsp+0x20], xmm2
00007d3d13be161e  vmovaps [rsp+0x30], xmm3
00007d3d13be1624  vmovaps [rsp+0x40], xmm4
00007d3d13be162a  vmovaps [rsp+0x50], xmm6
00007d3d13be1630  vmovaps [rsp+0x60], xmm7
00007d3d13be1636  vmovaps [rsp+0x70], xmm8
00007d3d13be163c  vmovaps [rsp+0x80], xmm9
00007d3d13be1645  vmovaps [rsp+0x90], xmm10
00007d3d13be164e  vmovaps [rsp+0xA0], xmm11
00007d3d13be1657  vmovaps [rsp+0xB0], xmm12
00007d3d13be1660  vmovaps [rsp+0xC0], xmm13
00007d3d13be1669  vmovaps [rsp+0xD0], xmm14
00007d3d13be1672  vmovaps [rsp+0xE0], xmm15
00007d3d13be167b  sub rsp, 0x30
00007d3d13be167f  movaps [rsp], xmm5
00007d3d13be1683  movaps [rsp+0x10], xmm6
00007d3d13be1688  movaps [rsp+0x20], xmm3
00007d3d13be168d  lea rdi, [rsp]
00007d3d13be1691  mov esi, 0x00
00007d3d13be1696  mov rax, 0x5741DAFC8530
00007d3d13be16a0  call rax
00007d3d13be16a2  movaps xmm5, [rsp]
00007d3d13be16a6  add rsp, 0x30
00007d3d13be16aa  vmovaps xmm0, [rsp]
00007d3d13be16af  vmovaps xmm1, [rsp+0x10]
00007d3d13be16b5  vmovaps xmm2, [rsp+0x20]
00007d3d13be16bb  vmovaps xmm3, [rsp+0x30]
00007d3d13be16c1  vmovaps xmm4, [rsp+0x40]
00007d3d13be16c7  vmovaps xmm6, [rsp+0x50]
00007d3d13be16cd  vmovaps xmm7, [rsp+0x60]
00007d3d13be16d3  vmovaps xmm8, [rsp+0x70]
00007d3d13be16d9  vmovaps xmm9, [rsp+0x80]
00007d3d13be16e2  vmovaps xmm10, [rsp+0x90]
00007d3d13be16eb  vmovaps xmm11, [rsp+0xA0]
00007d3d13be16f4  vmovaps xmm12, [rsp+0xB0]
00007d3d13be16fd  vmovaps xmm13, [rsp+0xC0]
00007d3d13be1706  vmovaps xmm14, [rsp+0xD0]
00007d3d13be170f  vmovaps xmm15, [rsp+0xE0]
00007d3d13be1718  add rsp, 0xF0
00007d3d13be171f  pop r11
00007d3d13be1721  pop r10
00007d3d13be1723  pop r9
00007d3d13be1725  pop r8
00007d3d13be1727  pop rsi
00007d3d13be1728  pop rdi
00007d3d13be1729  pop rdx
00007d3d13be172a  pop rcx
00007d3d13be172b  pop rax
00007d3d13be172c  add rsp, 0x08
00007d3d13be1730  jmp 0x00007D3D13BDF31A
00007d3d13be1735  sub rsp, 0x08
00007d3d13be1739  push rax
00007d3d13be173a  push rcx
00007d3d13be173b  push rdx
00007d3d13be173c  push rdi
00007d3d13be173d  push rsi
00007d3d13be173e  push r8
00007d3d13be1740  push r9
00007d3d13be1742  push r10
00007d3d13be1744  push r11
00007d3d13be1746  sub rsp, 0xF0
00007d3d13be174d  vmovaps [rsp], xmm0
00007d3d13be1752  vmovaps [rsp+0x10], xmm1
00007d3d13be1758  vmovaps [rsp+0x20], xmm2
00007d3d13be175e  vmovaps [rsp+0x30], xmm3
00007d3d13be1764  vmovaps [rsp+0x40], xmm4
00007d3d13be176a  vmovaps [rsp+0x50], xmm5
00007d3d13be1770  vmovaps [rsp+0x60], xmm7
00007d3d13be1776  vmovaps [rsp+0x70], xmm8
00007d3d13be177c  vmovaps [rsp+0x80], xmm9
00007d3d13be1785  vmovaps [rsp+0x90], xmm10
00007d3d13be178e  vmovaps [rsp+0xA0], xmm11
00007d3d13be1797  vmovaps [rsp+0xB0], xmm12
00007d3d13be17a0  vmovaps [rsp+0xC0], xmm13
00007d3d13be17a9  vmovaps [rsp+0xD0], xmm14
00007d3d13be17b2  vmovaps [rsp+0xE0], xmm15
00007d3d13be17bb  sub rsp, 0x30
00007d3d13be17bf  movaps [rsp], xmm6
00007d3d13be17c3  movaps [rsp+0x10], xmm9
00007d3d13be17c9  movaps [rsp+0x20], xmm1
00007d3d13be17ce  lea rdi, [rsp]
00007d3d13be17d2  mov esi, 0x00
00007d3d13be17d7  mov rax, 0x5741DAFC8530
00007d3d13be17e1  call rax
00007d3d13be17e3  movaps xmm6, [rsp]
00007d3d13be17e7  add rsp, 0x30
00007d3d13be17eb  vmovaps xmm0, [rsp]
00007d3d13be17f0  vmovaps xmm1, [rsp+0x10]
00007d3d13be17f6  vmovaps xmm2, [rsp+0x20]
00007d3d13be17fc  vmovaps xmm3, [rsp+0x30]
00007d3d13be1802  vmovaps xmm4, [rsp+0x40]
00007d3d13be1808  vmovaps xmm5, [rsp+0x50]
00007d3d13be180e  vmovaps xmm7, [rsp+0x60]
00007d3d13be1814  vmovaps xmm8, [rsp+0x70]
00007d3d13be181a  vmovaps xmm9, [rsp+0x80]
00007d3d13be1823  vmovaps xmm10, [rsp+0x90]
00007d3d13be182c  vmovaps xmm11, [rsp+0xA0]
00007d3d13be1835  vmovaps xmm12, [rsp+0xB0]
00007d3d13be183e  vmovaps xmm13, [rsp+0xC0]
00007d3d13be1847  vmovaps xmm14, [rsp+0xD0]
00007d3d13be1850  vmovaps xmm15, [rsp+0xE0]
00007d3d13be1859  add rsp, 0xF0
00007d3d13be1860  pop r11
00007d3d13be1862  pop r10
00007d3d13be1864  pop r9
00007d3d13be1866  pop r8
00007d3d13be1868  pop rsi
00007d3d13be1869  pop rdi
00007d3d13be186a  pop rdx
00007d3d13be186b  pop rcx
00007d3d13be186c  pop rax
00007d3d13be186d  add rsp, 0x08
00007d3d13be1871  jmp 0x00007D3D13BDF33E
00007d3d13be1876  sub rsp, 0x08
00007d3d13be187a  push rax
00007d3d13be187b  push rcx
00007d3d13be187c  push rdx
00007d3d13be187d  push rdi
00007d3d13be187e  push rsi
00007d3d13be187f  push r8
00007d3d13be1881  push r9
00007d3d13be1883  push r10
00007d3d13be1885  push r11
00007d3d13be1887  sub rsp, 0xF0
00007d3d13be188e  vmovaps [rsp], xmm0
00007d3d13be1893  vmovaps [rsp+0x10], xmm1
00007d3d13be1899  vmovaps [rsp+0x20], xmm2
00007d3d13be189f  vmovaps [rsp+0x30], xmm3
00007d3d13be18a5  vmovaps [rsp+0x40], xmm4
00007d3d13be18ab  vmovaps [rsp+0x50], xmm5
00007d3d13be18b1  vmovaps [rsp+0x60], xmm6
00007d3d13be18b7  vmovaps [rsp+0x70], xmm7
00007d3d13be18bd  vmovaps [rsp+0x80], xmm8
00007d3d13be18c6  vmovaps [rsp+0x90], xmm10
00007d3d13be18cf  vmovaps [rsp+0xA0], xmm11
00007d3d13be18d8  vmovaps [rsp+0xB0], xmm12
00007d3d13be18e1  vmovaps [rsp+0xC0], xmm13
00007d3d13be18ea  vmovaps [rsp+0xD0], xmm14
00007d3d13be18f3  vmovaps [rsp+0xE0], xmm15
00007d3d13be18fc  sub rsp, 0x30
00007d3d13be1900  movaps [rsp], xmm9
00007d3d13be1905  movaps [rsp+0x10], xmm3
00007d3d13be190a  movaps [rsp+0x20], xmm1
00007d3d13be190f  lea rdi, [rsp]
00007d3d13be1913  mov esi, 0x00
00007d3d13be1918  mov rax, 0x5741DAFC8530
00007d3d13be1922  call rax
00007d3d13be1924  movaps xmm9, [rsp]
00007d3d13be1929  add rsp, 0x30
00007d3d13be192d  vmovaps xmm0, [rsp]
00007d3d13be1932  vmovaps xmm1, [rsp+0x10]
00007d3d13be1938  vmovaps xmm2, [rsp+0x20]
00007d3d13be193e  vmovaps xmm3, [rsp+0x30]
00007d3d13be1944  vmovaps xmm4, [rsp+0x40]
00007d3d13be194a  vmovaps xmm5, [rsp+0x50]
00007d3d13be1950  vmovaps xmm6, [rsp+0x60]
00007d3d13be1956  vmovaps xmm7, [rsp+0x70]
00007d3d13be195c  vmovaps xmm8, [rsp+0x80]
00007d3d13be1965  vmovaps xmm10, [rsp+0x90]
00007d3d13be196e  vmovaps xmm11, [rsp+0xA0]
00007d3d13be1977  vmovaps xmm12, [rsp+0xB0]
00007d3d13be1980  vmovaps xmm13, [rsp+0xC0]
00007d3d13be1989  vmovaps xmm14, [rsp+0xD0]
00007d3d13be1992  vmovaps xmm15, [rsp+0xE0]
00007d3d13be199b  add rsp, 0xF0
00007d3d13be19a2  pop r11
00007d3d13be19a4  pop r10
00007d3d13be19a6  pop r9
00007d3d13be19a8  pop r8
00007d3d13be19aa  pop rsi
00007d3d13be19ab  pop rdi
00007d3d13be19ac  pop rdx
00007d3d13be19ad  pop rcx
00007d3d13be19ae  pop rax
00007d3d13be19af  add rsp, 0x08
00007d3d13be19b3  jmp 0x00007D3D13BDF38A
00007d3d13be19b8  call 0x00007D3D13AB52F0
00007d3d13be19bd  jmp 0x00007D3D13BDF397
00007d3d13be19c2  sub rsp, 0x08
00007d3d13be19c6  push rax
00007d3d13be19c7  push rcx
00007d3d13be19c8  push rdx
00007d3d13be19c9  push rdi
00007d3d13be19ca  push rsi
00007d3d13be19cb  push r8
00007d3d13be19cd  push r9
00007d3d13be19cf  push r10
00007d3d13be19d1  push r11
00007d3d13be19d3  sub rsp, 0xF0
00007d3d13be19da  vmovaps [rsp], xmm0
00007d3d13be19df  vmovaps [rsp+0x10], xmm1
00007d3d13be19e5  vmovaps [rsp+0x20], xmm2
00007d3d13be19eb  vmovaps [rsp+0x30], xmm3
00007d3d13be19f1  vmovaps [rsp+0x40], xmm4
00007d3d13be19f7  vmovaps [rsp+0x50], xmm5
00007d3d13be19fd  vmovaps [rsp+0x60], xmm6
00007d3d13be1a03  vmovaps [rsp+0x70], xmm7
00007d3d13be1a09  vmovaps [rsp+0x80], xmm8
00007d3d13be1a12  vmovaps [rsp+0x90], xmm9
00007d3d13be1a1b  vmovaps [rsp+0xA0], xmm10
00007d3d13be1a24  vmovaps [rsp+0xB0], xmm11
00007d3d13be1a2d  vmovaps [rsp+0xC0], xmm12
00007d3d13be1a36  vmovaps [rsp+0xD0], xmm13
00007d3d13be1a3f  vmovaps [rsp+0xE0], xmm14
00007d3d13be1a48  sub rsp, 0x30
00007d3d13be1a4c  movaps [rsp], xmm15
00007d3d13be1a51  movaps [rsp+0x10], xmm3
00007d3d13be1a56  movaps [rsp+0x20], xmm7
00007d3d13be1a5b  lea rdi, [rsp]
00007d3d13be1a5f  mov esi, 0x00
00007d3d13be1a64  mov rax, 0x5741DAFC8530
00007d3d13be1a6e  call rax
00007d3d13be1a70  movaps xmm15, [rsp]
00007d3d13be1a75  add rsp, 0x30
00007d3d13be1a79  vmovaps xmm0, [rsp]
00007d3d13be1a7e  vmovaps xmm1, [rsp+0x10]
00007d3d13be1a84  vmovaps xmm2, [rsp+0x20]
00007d3d13be1a8a  vmovaps xmm3, [rsp+0x30]
00007d3d13be1a90  vmovaps xmm4, [rsp+0x40]
00007d3d13be1a96  vmovaps xmm5, [rsp+0x50]
00007d3d13be1a9c  vmovaps xmm6, [rsp+0x60]
00007d3d13be1aa2  vmovaps xmm7, [rsp+0x70]
00007d3d13be1aa8  vmovaps xmm8, [rsp+0x80]
00007d3d13be1ab1  vmovaps xmm9, [rsp+0x90]
00007d3d13be1aba  vmovaps xmm10, [rsp+0xA0]
00007d3d13be1ac3  vmovaps xmm11, [rsp+0xB0]
00007d3d13be1acc  vmovaps xmm12, [rsp+0xC0]
00007d3d13be1ad5  vmovaps xmm13, [rsp+0xD0]
00007d3d13be1ade  vmovaps xmm14, [rsp+0xE0]
00007d3d13be1ae7  add rsp, 0xF0
00007d3d13be1aee  pop r11
00007d3d13be1af0  pop r10
00007d3d13be1af2  pop r9
00007d3d13be1af4  pop r8
00007d3d13be1af6  pop rsi
00007d3d13be1af7  pop rdi
00007d3d13be1af8  pop rdx
00007d3d13be1af9  pop rcx
00007d3d13be1afa  pop rax
00007d3d13be1afb  add rsp, 0x08
00007d3d13be1aff  jmp 0x00007D3D13BDF3C3
00007d3d13be1b04  sub rsp, 0x08
00007d3d13be1b08  push rax
00007d3d13be1b09  push rcx
00007d3d13be1b0a  push rdx
00007d3d13be1b0b  push rdi
00007d3d13be1b0c  push rsi
00007d3d13be1b0d  push r8
00007d3d13be1b0f  push r9
00007d3d13be1b11  push r10
00007d3d13be1b13  push r11
00007d3d13be1b15  sub rsp, 0xF0
00007d3d13be1b1c  vmovaps [rsp], xmm0
00007d3d13be1b21  vmovaps [rsp+0x10], xmm1
00007d3d13be1b27  vmovaps [rsp+0x20], xmm2
00007d3d13be1b2d  vmovaps [rsp+0x30], xmm4
00007d3d13be1b33  vmovaps [rsp+0x40], xmm5
00007d3d13be1b39  vmovaps [rsp+0x50], xmm6
00007d3d13be1b3f  vmovaps [rsp+0x60], xmm7
00007d3d13be1b45  vmovaps [rsp+0x70], xmm8
00007d3d13be1b4b  vmovaps [rsp+0x80], xmm9
00007d3d13be1b54  vmovaps [rsp+0x90], xmm10
00007d3d13be1b5d  vmovaps [rsp+0xA0], xmm11
00007d3d13be1b66  vmovaps [rsp+0xB0], xmm12
00007d3d13be1b6f  vmovaps [rsp+0xC0], xmm13
00007d3d13be1b78  vmovaps [rsp+0xD0], xmm14
00007d3d13be1b81  vmovaps [rsp+0xE0], xmm15
00007d3d13be1b8a  sub rsp, 0x30
00007d3d13be1b8e  movaps [rsp], xmm3
00007d3d13be1b92  movaps [rsp+0x10], xmm1
00007d3d13be1b97  movaps [rsp+0x20], xmm15
00007d3d13be1b9d  lea rdi, [rsp]
00007d3d13be1ba1  mov esi, 0x00
00007d3d13be1ba6  mov rax, 0x5741DAFC8530
00007d3d13be1bb0  call rax
00007d3d13be1bb2  movaps xmm3, [rsp]
00007d3d13be1bb6  add rsp, 0x30
00007d3d13be1bba  vmovaps xmm0, [rsp]
00007d3d13be1bbf  vmovaps xmm1, [rsp+0x10]
00007d3d13be1bc5  vmovaps xmm2, [rsp+0x20]
00007d3d13be1bcb  vmovaps xmm4, [rsp+0x30]
00007d3d13be1bd1  vmovaps xmm5, [rsp+0x40]
00007d3d13be1bd7  vmovaps xmm6, [rsp+0x50]
00007d3d13be1bdd  vmovaps xmm7, [rsp+0x60]
00007d3d13be1be3  vmovaps xmm8, [rsp+0x70]
00007d3d13be1be9  vmovaps xmm9, [rsp+0x80]
00007d3d13be1bf2  vmovaps xmm10, [rsp+0x90]
00007d3d13be1bfb  vmovaps xmm11, [rsp+0xA0]
00007d3d13be1c04  vmovaps xmm12, [rsp+0xB0]
00007d3d13be1c0d  vmovaps xmm13, [rsp+0xC0]
00007d3d13be1c16  vmovaps xmm14, [rsp+0xD0]
00007d3d13be1c1f  vmovaps xmm15, [rsp+0xE0]
00007d3d13be1c28  add rsp, 0xF0
00007d3d13be1c2f  pop r11
00007d3d13be1c31  pop r10
00007d3d13be1c33  pop r9
00007d3d13be1c35  pop r8
00007d3d13be1c37  pop rsi
00007d3d13be1c38  pop rdi
00007d3d13be1c39  pop rdx
00007d3d13be1c3a  pop rcx
00007d3d13be1c3b  pop rax
00007d3d13be1c3c  add rsp, 0x08
00007d3d13be1c40  jmp 0x00007D3D13BDF452
00007d3d13be1c45  call 0x00007D3D13AB52F0
00007d3d13be1c4a  jmp 0x00007D3D13BDF45C
00007d3d13be1c4f  sub rsp, 0x08
00007d3d13be1c53  push rax
00007d3d13be1c54  push rcx
00007d3d13be1c55  push rdx
00007d3d13be1c56  push rdi
00007d3d13be1c57  push rsi
00007d3d13be1c58  push r8
00007d3d13be1c5a  push r9
00007d3d13be1c5c  push r10
00007d3d13be1c5e  push r11
00007d3d13be1c60  sub rsp, 0xF0
00007d3d13be1c67  vmovaps [rsp], xmm0
00007d3d13be1c6c  vmovaps [rsp+0x10], xmm1
00007d3d13be1c72  vmovaps [rsp+0x20], xmm2
00007d3d13be1c78  vmovaps [rsp+0x30], xmm3
00007d3d13be1c7e  vmovaps [rsp+0x40], xmm4
00007d3d13be1c84  vmovaps [rsp+0x50], xmm5
00007d3d13be1c8a  vmovaps [rsp+0x60], xmm6
00007d3d13be1c90  vmovaps [rsp+0x70], xmm7
00007d3d13be1c96  vmovaps [rsp+0x80], xmm8
00007d3d13be1c9f  vmovaps [rsp+0x90], xmm9
00007d3d13be1ca8  vmovaps [rsp+0xA0], xmm10
00007d3d13be1cb1  vmovaps [rsp+0xB0], xmm11
00007d3d13be1cba  vmovaps [rsp+0xC0], xmm12
00007d3d13be1cc3  vmovaps [rsp+0xD0], xmm13
00007d3d13be1ccc  vmovaps [rsp+0xE0], xmm14
00007d3d13be1cd5  sub rsp, 0x30
00007d3d13be1cd9  movaps [rsp], xmm15
00007d3d13be1cde  movaps [rsp+0x10], xmm14
00007d3d13be1ce4  movaps [rsp+0x20], xmm4
00007d3d13be1ce9  lea rdi, [rsp]
00007d3d13be1ced  mov esi, 0x00
00007d3d13be1cf2  mov rax, 0x5741DAFC8530
00007d3d13be1cfc  call rax
00007d3d13be1cfe  movaps xmm15, [rsp]
00007d3d13be1d03  add rsp, 0x30
00007d3d13be1d07  vmovaps xmm0, [rsp]
00007d3d13be1d0c  vmovaps xmm1, [rsp+0x10]
00007d3d13be1d12  vmovaps xmm2, [rsp+0x20]
00007d3d13be1d18  vmovaps xmm3, [rsp+0x30]
00007d3d13be1d1e  vmovaps xmm4, [rsp+0x40]
00007d3d13be1d24  vmovaps xmm5, [rsp+0x50]
00007d3d13be1d2a  vmovaps xmm6, [rsp+0x60]
00007d3d13be1d30  vmovaps xmm7, [rsp+0x70]
00007d3d13be1d36  vmovaps xmm8, [rsp+0x80]
00007d3d13be1d3f  vmovaps xmm9, [rsp+0x90]
00007d3d13be1d48  vmovaps xmm10, [rsp+0xA0]
00007d3d13be1d51  vmovaps xmm11, [rsp+0xB0]
00007d3d13be1d5a  vmovaps xmm12, [rsp+0xC0]
00007d3d13be1d63  vmovaps xmm13, [rsp+0xD0]
00007d3d13be1d6c  vmovaps xmm14, [rsp+0xE0]
00007d3d13be1d75  add rsp, 0xF0
00007d3d13be1d7c  pop r11
00007d3d13be1d7e  pop r10
00007d3d13be1d80  pop r9
00007d3d13be1d82  pop r8
00007d3d13be1d84  pop rsi
00007d3d13be1d85  pop rdi
00007d3d13be1d86  pop rdx
00007d3d13be1d87  pop rcx
00007d3d13be1d88  pop rax
00007d3d13be1d89  add rsp, 0x08
00007d3d13be1d8d  jmp 0x00007D3D13BDF48A
00007d3d13be1d92  sub rsp, 0x08
00007d3d13be1d96  push rax
00007d3d13be1d97  push rcx
00007d3d13be1d98  push rdx
00007d3d13be1d99  push rdi
00007d3d13be1d9a  push rsi
00007d3d13be1d9b  push r8
00007d3d13be1d9d  push r9
00007d3d13be1d9f  push r10
00007d3d13be1da1  push r11
00007d3d13be1da3  sub rsp, 0xF0
00007d3d13be1daa  vmovaps [rsp], xmm0
00007d3d13be1daf  vmovaps [rsp+0x10], xmm1
00007d3d13be1db5  vmovaps [rsp+0x20], xmm2
00007d3d13be1dbb  vmovaps [rsp+0x30], xmm3
00007d3d13be1dc1  vmovaps [rsp+0x40], xmm4
00007d3d13be1dc7  vmovaps [rsp+0x50], xmm5
00007d3d13be1dcd  vmovaps [rsp+0x60], xmm6
00007d3d13be1dd3  vmovaps [rsp+0x70], xmm7
00007d3d13be1dd9  vmovaps [rsp+0x80], xmm8
00007d3d13be1de2  vmovaps [rsp+0x90], xmm9
00007d3d13be1deb  vmovaps [rsp+0xA0], xmm10
00007d3d13be1df4  vmovaps [rsp+0xB0], xmm11
00007d3d13be1dfd  vmovaps [rsp+0xC0], xmm12
00007d3d13be1e06  vmovaps [rsp+0xD0], xmm13
00007d3d13be1e0f  vmovaps [rsp+0xE0], xmm15
00007d3d13be1e18  sub rsp, 0x30
00007d3d13be1e1c  movaps [rsp], xmm14
00007d3d13be1e21  movaps [rsp+0x10], xmm2
00007d3d13be1e26  movaps [rsp+0x20], xmm1
00007d3d13be1e2b  lea rdi, [rsp]
00007d3d13be1e2f  mov esi, 0x00
00007d3d13be1e34  mov rax, 0x5741DAFC8530
00007d3d13be1e3e  call rax
00007d3d13be1e40  movaps xmm14, [rsp]
00007d3d13be1e45  add rsp, 0x30
00007d3d13be1e49  vmovaps xmm0, [rsp]
00007d3d13be1e4e  vmovaps xmm1, [rsp+0x10]
00007d3d13be1e54  vmovaps xmm2, [rsp+0x20]
00007d3d13be1e5a  vmovaps xmm3, [rsp+0x30]
00007d3d13be1e60  vmovaps xmm4, [rsp+0x40]
00007d3d13be1e66  vmovaps xmm5, [rsp+0x50]
00007d3d13be1e6c  vmovaps xmm6, [rsp+0x60]
00007d3d13be1e72  vmovaps xmm7, [rsp+0x70]
00007d3d13be1e78  vmovaps xmm8, [rsp+0x80]
00007d3d13be1e81  vmovaps xmm9, [rsp+0x90]
00007d3d13be1e8a  vmovaps xmm10, [rsp+0xA0]
00007d3d13be1e93  vmovaps xmm11, [rsp+0xB0]
00007d3d13be1e9c  vmovaps xmm12, [rsp+0xC0]
00007d3d13be1ea5  vmovaps xmm13, [rsp+0xD0]
00007d3d13be1eae  vmovaps xmm15, [rsp+0xE0]
00007d3d13be1eb7  add rsp, 0xF0
00007d3d13be1ebe  pop r11
00007d3d13be1ec0  pop r10
00007d3d13be1ec2  pop r9
00007d3d13be1ec4  pop r8
00007d3d13be1ec6  pop rsi
00007d3d13be1ec7  pop rdi
00007d3d13be1ec8  pop rdx
00007d3d13be1ec9  pop rcx
00007d3d13be1eca  pop rax
00007d3d13be1ecb  add rsp, 0x08
00007d3d13be1ecf  jmp 0x00007D3D13BDF4B0
00007d3d13be1ed4  sub rsp, 0x08
00007d3d13be1ed8  push rax
00007d3d13be1ed9  push rcx
00007d3d13be1eda  push rdx
00007d3d13be1edb  push rdi
00007d3d13be1edc  push rsi
00007d3d13be1edd  push r8
00007d3d13be1edf  push r9
00007d3d13be1ee1  push r10
00007d3d13be1ee3  push r11
00007d3d13be1ee5  sub rsp, 0xF0
00007d3d13be1eec  vmovaps [rsp], xmm0
00007d3d13be1ef1  vmovaps [rsp+0x10], xmm2
00007d3d13be1ef7  vmovaps [rsp+0x20], xmm3
00007d3d13be1efd  vmovaps [rsp+0x30], xmm4
00007d3d13be1f03  vmovaps [rsp+0x40], xmm5
00007d3d13be1f09  vmovaps [rsp+0x50], xmm6
00007d3d13be1f0f  vmovaps [rsp+0x60], xmm7
00007d3d13be1f15  vmovaps [rsp+0x70], xmm8
00007d3d13be1f1b  vmovaps [rsp+0x80], xmm9
00007d3d13be1f24  vmovaps [rsp+0x90], xmm10
00007d3d13be1f2d  vmovaps [rsp+0xA0], xmm11
00007d3d13be1f36  vmovaps [rsp+0xB0], xmm12
00007d3d13be1f3f  vmovaps [rsp+0xC0], xmm13
00007d3d13be1f48  vmovaps [rsp+0xD0], xmm14
00007d3d13be1f51  vmovaps [rsp+0xE0], xmm15
00007d3d13be1f5a  sub rsp, 0x30
00007d3d13be1f5e  movaps [rsp], xmm1
00007d3d13be1f62  movaps [rsp+0x10], xmm4
00007d3d13be1f67  movaps [rsp+0x20], xmm9
00007d3d13be1f6d  lea rdi, [rsp]
00007d3d13be1f71  mov esi, 0x00
00007d3d13be1f76  mov rax, 0x5741DAFC8530
00007d3d13be1f80  call rax
00007d3d13be1f82  movaps xmm1, [rsp]
00007d3d13be1f86  add rsp, 0x30
00007d3d13be1f8a  vmovaps xmm0, [rsp]
00007d3d13be1f8f  vmovaps xmm2, [rsp+0x10]
00007d3d13be1f95  vmovaps xmm3, [rsp+0x20]
00007d3d13be1f9b  vmovaps xmm4, [rsp+0x30]
00007d3d13be1fa1  vmovaps xmm5, [rsp+0x40]
00007d3d13be1fa7  vmovaps xmm6, [rsp+0x50]
00007d3d13be1fad  vmovaps xmm7, [rsp+0x60]
00007d3d13be1fb3  vmovaps xmm8, [rsp+0x70]
00007d3d13be1fb9  vmovaps xmm9, [rsp+0x80]
00007d3d13be1fc2  vmovaps xmm10, [rsp+0x90]
00007d3d13be1fcb  vmovaps xmm11, [rsp+0xA0]
00007d3d13be1fd4  vmovaps xmm12, [rsp+0xB0]
00007d3d13be1fdd  vmovaps xmm13, [rsp+0xC0]
00007d3d13be1fe6  vmovaps xmm14, [rsp+0xD0]
00007d3d13be1fef  vmovaps xmm15, [rsp+0xE0]
00007d3d13be1ff8  add rsp, 0xF0
00007d3d13be1fff  pop r11
00007d3d13be2001  pop r10
00007d3d13be2003  pop r9
00007d3d13be2005  pop r8
00007d3d13be2007  pop rsi
00007d3d13be2008  pop rdi
00007d3d13be2009  pop rdx
00007d3d13be200a  pop rcx
00007d3d13be200b  pop rax
00007d3d13be200c  add rsp, 0x08
00007d3d13be2010  jmp 0x00007D3D13BDF4CE
00007d3d13be2015  sub rsp, 0x08
00007d3d13be2019  push rax
00007d3d13be201a  push rcx
00007d3d13be201b  push rdx
00007d3d13be201c  push rdi
00007d3d13be201d  push rsi
00007d3d13be201e  push r8
00007d3d13be2020  push r9
00007d3d13be2022  push r10
00007d3d13be2024  push r11
00007d3d13be2026  sub rsp, 0xF0
00007d3d13be202d  vmovaps [rsp], xmm0
00007d3d13be2032  vmovaps [rsp+0x10], xmm1
00007d3d13be2038  vmovaps [rsp+0x20], xmm2
00007d3d13be203e  vmovaps [rsp+0x30], xmm3
00007d3d13be2044  vmovaps [rsp+0x40], xmm5
00007d3d13be204a  vmovaps [rsp+0x50], xmm6
00007d3d13be2050  vmovaps [rsp+0x60], xmm7
00007d3d13be2056  vmovaps [rsp+0x70], xmm8
00007d3d13be205c  vmovaps [rsp+0x80], xmm9
00007d3d13be2065  vmovaps [rsp+0x90], xmm10
00007d3d13be206e  vmovaps [rsp+0xA0], xmm11
00007d3d13be2077  vmovaps [rsp+0xB0], xmm12
00007d3d13be2080  vmovaps [rsp+0xC0], xmm13
00007d3d13be2089  vmovaps [rsp+0xD0], xmm14
00007d3d13be2092  vmovaps [rsp+0xE0], xmm15
00007d3d13be209b  sub rsp, 0x30
00007d3d13be209f  movaps [rsp], xmm4
00007d3d13be20a3  movaps [rsp+0x10], xmm2
00007d3d13be20a8  movaps [rsp+0x20], xmm9
00007d3d13be20ae  lea rdi, [rsp]
00007d3d13be20b2  mov esi, 0x00
00007d3d13be20b7  mov rax, 0x5741DAFC8530
00007d3d13be20c1  call rax
00007d3d13be20c3  movaps xmm4, [rsp]
00007d3d13be20c7  add rsp, 0x30
00007d3d13be20cb  vmovaps xmm0, [rsp]
00007d3d13be20d0  vmovaps xmm1, [rsp+0x10]
00007d3d13be20d6  vmovaps xmm2, [rsp+0x20]
00007d3d13be20dc  vmovaps xmm3, [rsp+0x30]
00007d3d13be20e2  vmovaps xmm5, [rsp+0x40]
00007d3d13be20e8  vmovaps xmm6, [rsp+0x50]
00007d3d13be20ee  vmovaps xmm7, [rsp+0x60]
00007d3d13be20f4  vmovaps xmm8, [rsp+0x70]
00007d3d13be20fa  vmovaps xmm9, [rsp+0x80]
00007d3d13be2103  vmovaps xmm10, [rsp+0x90]
00007d3d13be210c  vmovaps xmm11, [rsp+0xA0]
00007d3d13be2115  vmovaps xmm12, [rsp+0xB0]
00007d3d13be211e  vmovaps xmm13, [rsp+0xC0]
00007d3d13be2127  vmovaps xmm14, [rsp+0xD0]
00007d3d13be2130  vmovaps xmm15, [rsp+0xE0]
00007d3d13be2139  add rsp, 0xF0
00007d3d13be2140  pop r11
00007d3d13be2142  pop r10
00007d3d13be2144  pop r9
00007d3d13be2146  pop r8
00007d3d13be2148  pop rsi
00007d3d13be2149  pop rdi
00007d3d13be214a  pop rdx
00007d3d13be214b  pop rcx
00007d3d13be214c  pop rax
00007d3d13be214d  add rsp, 0x08
00007d3d13be2151  jmp 0x00007D3D13BDF4FE
00007d3d13be2156  sub rsp, 0x08
00007d3d13be215a  push rax
00007d3d13be215b  push rcx
00007d3d13be215c  push rdx
00007d3d13be215d  push rdi
00007d3d13be215e  push rsi
00007d3d13be215f  push r8
00007d3d13be2161  push r9
00007d3d13be2163  push r10
00007d3d13be2165  push r11
00007d3d13be2167  sub rsp, 0xF0
00007d3d13be216e  vmovaps [rsp], xmm0
00007d3d13be2173  vmovaps [rsp+0x10], xmm1
00007d3d13be2179  vmovaps [rsp+0x20], xmm2
00007d3d13be217f  vmovaps [rsp+0x30], xmm3
00007d3d13be2185  vmovaps [rsp+0x40], xmm4
00007d3d13be218b  vmovaps [rsp+0x50], xmm5
00007d3d13be2191  vmovaps [rsp+0x60], xmm6
00007d3d13be2197  vmovaps [rsp+0x70], xmm7
00007d3d13be219d  vmovaps [rsp+0x80], xmm8
00007d3d13be21a6  vmovaps [rsp+0x90], xmm10
00007d3d13be21af  vmovaps [rsp+0xA0], xmm11
00007d3d13be21b8  vmovaps [rsp+0xB0], xmm12
00007d3d13be21c1  vmovaps [rsp+0xC0], xmm13
00007d3d13be21ca  vmovaps [rsp+0xD0], xmm14
00007d3d13be21d3  vmovaps [rsp+0xE0], xmm15
00007d3d13be21dc  sub rsp, 0x30
00007d3d13be21e0  movaps [rsp], xmm9
00007d3d13be21e5  movaps [rsp+0x10], xmm2
00007d3d13be21ea  movaps [rsp+0x20], xmm1
00007d3d13be21ef  lea rdi, [rsp]
00007d3d13be21f3  mov esi, 0x00
00007d3d13be21f8  mov rax, 0x5741DAFC8530
00007d3d13be2202  call rax
00007d3d13be2204  movaps xmm9, [rsp]
00007d3d13be2209  add rsp, 0x30
00007d3d13be220d  vmovaps xmm0, [rsp]
00007d3d13be2212  vmovaps xmm1, [rsp+0x10]
00007d3d13be2218  vmovaps xmm2, [rsp+0x20]
00007d3d13be221e  vmovaps xmm3, [rsp+0x30]
00007d3d13be2224  vmovaps xmm4, [rsp+0x40]
00007d3d13be222a  vmovaps xmm5, [rsp+0x50]
00007d3d13be2230  vmovaps xmm6, [rsp+0x60]
00007d3d13be2236  vmovaps xmm7, [rsp+0x70]
00007d3d13be223c  vmovaps xmm8, [rsp+0x80]
00007d3d13be2245  vmovaps xmm10, [rsp+0x90]
00007d3d13be224e  vmovaps xmm11, [rsp+0xA0]
00007d3d13be2257  vmovaps xmm12, [rsp+0xB0]
00007d3d13be2260  vmovaps xmm13, [rsp+0xC0]
00007d3d13be2269  vmovaps xmm14, [rsp+0xD0]
00007d3d13be2272  vmovaps xmm15, [rsp+0xE0]
00007d3d13be227b  add rsp, 0xF0
00007d3d13be2282  pop r11
00007d3d13be2284  pop r10
00007d3d13be2286  pop r9
00007d3d13be2288  pop r8
00007d3d13be228a  pop rsi
00007d3d13be228b  pop rdi
00007d3d13be228c  pop rdx
00007d3d13be228d  pop rcx
00007d3d13be228e  pop rax
00007d3d13be228f  add rsp, 0x08
00007d3d13be2293  jmp 0x00007D3D13BDF534
00007d3d13be2298  sub rsp, 0x08
00007d3d13be229c  push rax
00007d3d13be229d  push rcx
00007d3d13be229e  push rdx
00007d3d13be229f  push rdi
00007d3d13be22a0  push rsi
00007d3d13be22a1  push r8
00007d3d13be22a3  push r9
00007d3d13be22a5  push r10
00007d3d13be22a7  push r11
00007d3d13be22a9  sub rsp, 0xF0
00007d3d13be22b0  vmovaps [rsp], xmm0
00007d3d13be22b5  vmovaps [rsp+0x10], xmm2
00007d3d13be22bb  vmovaps [rsp+0x20], xmm3
00007d3d13be22c1  vmovaps [rsp+0x30], xmm4
00007d3d13be22c7  vmovaps [rsp+0x40], xmm5
00007d3d13be22cd  vmovaps [rsp+0x50], xmm6
00007d3d13be22d3  vmovaps [rsp+0x60], xmm7
00007d3d13be22d9  vmovaps [rsp+0x70], xmm8
00007d3d13be22df  vmovaps [rsp+0x80], xmm9
00007d3d13be22e8  vmovaps [rsp+0x90], xmm10
00007d3d13be22f1  vmovaps [rsp+0xA0], xmm11
00007d3d13be22fa  vmovaps [rsp+0xB0], xmm12
00007d3d13be2303  vmovaps [rsp+0xC0], xmm13
00007d3d13be230c  vmovaps [rsp+0xD0], xmm14
00007d3d13be2315  vmovaps [rsp+0xE0], xmm15
00007d3d13be231e  sub rsp, 0x30
00007d3d13be2322  movaps [rsp], xmm1
00007d3d13be2326  movaps [rsp+0x10], xmm15
00007d3d13be232c  movaps [rsp+0x20], xmm6
00007d3d13be2331  lea rdi, [rsp]
00007d3d13be2335  mov esi, 0x00
00007d3d13be233a  mov rax, 0x5741DAFC8530
00007d3d13be2344  call rax
00007d3d13be2346  movaps xmm1, [rsp]
00007d3d13be234a  add rsp, 0x30
00007d3d13be234e  vmovaps xmm0, [rsp]
00007d3d13be2353  vmovaps xmm2, [rsp+0x10]
00007d3d13be2359  vmovaps xmm3, [rsp+0x20]
00007d3d13be235f  vmovaps xmm4, [rsp+0x30]
00007d3d13be2365  vmovaps xmm5, [rsp+0x40]
00007d3d13be236b  vmovaps xmm6, [rsp+0x50]
00007d3d13be2371  vmovaps xmm7, [rsp+0x60]
00007d3d13be2377  vmovaps xmm8, [rsp+0x70]
00007d3d13be237d  vmovaps xmm9, [rsp+0x80]
00007d3d13be2386  vmovaps xmm10, [rsp+0x90]
00007d3d13be238f  vmovaps xmm11, [rsp+0xA0]
00007d3d13be2398  vmovaps xmm12, [rsp+0xB0]
00007d3d13be23a1  vmovaps xmm13, [rsp+0xC0]
00007d3d13be23aa  vmovaps xmm14, [rsp+0xD0]
00007d3d13be23b3  vmovaps xmm15, [rsp+0xE0]
00007d3d13be23bc  add rsp, 0xF0
00007d3d13be23c3  pop r11
00007d3d13be23c5  pop r10
00007d3d13be23c7  pop r9
00007d3d13be23c9  pop r8
00007d3d13be23cb  pop rsi
00007d3d13be23cc  pop rdi
00007d3d13be23cd  pop rdx
00007d3d13be23ce  pop rcx
00007d3d13be23cf  pop rax
00007d3d13be23d0  add rsp, 0x08
00007d3d13be23d4  jmp 0x00007D3D13BDF555
00007d3d13be23d9  sub rsp, 0x08
00007d3d13be23dd  push rax
00007d3d13be23de  push rcx
00007d3d13be23df  push rdx
00007d3d13be23e0  push rdi
00007d3d13be23e1  push rsi
00007d3d13be23e2  push r8
00007d3d13be23e4  push r9
00007d3d13be23e6  push r10
00007d3d13be23e8  push r11
00007d3d13be23ea  sub rsp, 0xF0
00007d3d13be23f1  vmovaps [rsp], xmm0
00007d3d13be23f6  vmovaps [rsp+0x10], xmm1
00007d3d13be23fc  vmovaps [rsp+0x20], xmm2
00007d3d13be2402  vmovaps [rsp+0x30], xmm3
00007d3d13be2408  vmovaps [rsp+0x40], xmm4
00007d3d13be240e  vmovaps [rsp+0x50], xmm5
00007d3d13be2414  vmovaps [rsp+0x60], xmm6
00007d3d13be241a  vmovaps [rsp+0x70], xmm7
00007d3d13be2420  vmovaps [rsp+0x80], xmm8
00007d3d13be2429  vmovaps [rsp+0x90], xmm9
00007d3d13be2432  vmovaps [rsp+0xA0], xmm10
00007d3d13be243b  vmovaps [rsp+0xB0], xmm11
00007d3d13be2444  vmovaps [rsp+0xC0], xmm12
00007d3d13be244d  vmovaps [rsp+0xD0], xmm13
00007d3d13be2456  vmovaps [rsp+0xE0], xmm14
00007d3d13be245f  sub rsp, 0x30
00007d3d13be2463  movaps [rsp], xmm15
00007d3d13be2468  movaps [rsp+0x10], xmm5
00007d3d13be246d  movaps [rsp+0x20], xmm3
00007d3d13be2472  lea rdi, [rsp]
00007d3d13be2476  mov esi, 0x00
00007d3d13be247b  mov rax, 0x5741DAFC8530
00007d3d13be2485  call rax
00007d3d13be2487  movaps xmm15, [rsp]
00007d3d13be248c  add rsp, 0x30
00007d3d13be2490  vmovaps xmm0, [rsp]
00007d3d13be2495  vmovaps xmm1, [rsp+0x10]
00007d3d13be249b  vmovaps xmm2, [rsp+0x20]
00007d3d13be24a1  vmovaps xmm3, [rsp+0x30]
00007d3d13be24a7  vmovaps xmm4, [rsp+0x40]
00007d3d13be24ad  vmovaps xmm5, [rsp+0x50]
00007d3d13be24b3  vmovaps xmm6, [rsp+0x60]
00007d3d13be24b9  vmovaps xmm7, [rsp+0x70]
00007d3d13be24bf  vmovaps xmm8, [rsp+0x80]
00007d3d13be24c8  vmovaps xmm9, [rsp+0x90]
00007d3d13be24d1  vmovaps xmm10, [rsp+0xA0]
00007d3d13be24da  vmovaps xmm11, [rsp+0xB0]
00007d3d13be24e3  vmovaps xmm12, [rsp+0xC0]
00007d3d13be24ec  vmovaps xmm13, [rsp+0xD0]
00007d3d13be24f5  vmovaps xmm14, [rsp+0xE0]
00007d3d13be24fe  add rsp, 0xF0
00007d3d13be2505  pop r11
00007d3d13be2507  pop r10
00007d3d13be2509  pop r9
00007d3d13be250b  pop r8
00007d3d13be250d  pop rsi
00007d3d13be250e  pop rdi
00007d3d13be250f  pop rdx
00007d3d13be2510  pop rcx
00007d3d13be2511  pop rax
00007d3d13be2512  add rsp, 0x08
00007d3d13be2516  jmp 0x00007D3D13BDF56F
00007d3d13be251b  sub rsp, 0x08
00007d3d13be251f  push rax
00007d3d13be2520  push rcx
00007d3d13be2521  push rdx
00007d3d13be2522  push rdi
00007d3d13be2523  push rsi
00007d3d13be2524  push r8
00007d3d13be2526  push r9
00007d3d13be2528  push r10
00007d3d13be252a  push r11
00007d3d13be252c  sub rsp, 0xF0
00007d3d13be2533  vmovaps [rsp], xmm0
00007d3d13be2538  vmovaps [rsp+0x10], xmm1
00007d3d13be253e  vmovaps [rsp+0x20], xmm2
00007d3d13be2544  vmovaps [rsp+0x30], xmm3
00007d3d13be254a  vmovaps [rsp+0x40], xmm4
00007d3d13be2550  vmovaps [rsp+0x50], xmm6
00007d3d13be2556  vmovaps [rsp+0x60], xmm7
00007d3d13be255c  vmovaps [rsp+0x70], xmm8
00007d3d13be2562  vmovaps [rsp+0x80], xmm9
00007d3d13be256b  vmovaps [rsp+0x90], xmm10
00007d3d13be2574  vmovaps [rsp+0xA0], xmm11
00007d3d13be257d  vmovaps [rsp+0xB0], xmm12
00007d3d13be2586  vmovaps [rsp+0xC0], xmm13
00007d3d13be258f  vmovaps [rsp+0xD0], xmm14
00007d3d13be2598  vmovaps [rsp+0xE0], xmm15
00007d3d13be25a1  sub rsp, 0x30
00007d3d13be25a5  movaps [rsp], xmm5
00007d3d13be25a9  movaps [rsp+0x10], xmm8
00007d3d13be25af  movaps [rsp+0x20], xmm6
00007d3d13be25b4  lea rdi, [rsp]
00007d3d13be25b8  mov esi, 0x00
00007d3d13be25bd  mov rax, 0x5741DAFC8530
00007d3d13be25c7  call rax
00007d3d13be25c9  movaps xmm5, [rsp]
00007d3d13be25cd  add rsp, 0x30
00007d3d13be25d1  vmovaps xmm0, [rsp]
00007d3d13be25d6  vmovaps xmm1, [rsp+0x10]
00007d3d13be25dc  vmovaps xmm2, [rsp+0x20]
00007d3d13be25e2  vmovaps xmm3, [rsp+0x30]
00007d3d13be25e8  vmovaps xmm4, [rsp+0x40]
00007d3d13be25ee  vmovaps xmm6, [rsp+0x50]
00007d3d13be25f4  vmovaps xmm7, [rsp+0x60]
00007d3d13be25fa  vmovaps xmm8, [rsp+0x70]
00007d3d13be2600  vmovaps xmm9, [rsp+0x80]
00007d3d13be2609  vmovaps xmm10, [rsp+0x90]
00007d3d13be2612  vmovaps xmm11, [rsp+0xA0]
00007d3d13be261b  vmovaps xmm12, [rsp+0xB0]
00007d3d13be2624  vmovaps xmm13, [rsp+0xC0]
00007d3d13be262d  vmovaps xmm14, [rsp+0xD0]
00007d3d13be2636  vmovaps xmm15, [rsp+0xE0]
00007d3d13be263f  add rsp, 0xF0
00007d3d13be2646  pop r11
00007d3d13be2648  pop r10
00007d3d13be264a  pop r9
00007d3d13be264c  pop r8
00007d3d13be264e  pop rsi
00007d3d13be264f  pop rdi
00007d3d13be2650  pop rdx
00007d3d13be2651  pop rcx
00007d3d13be2652  pop rax
00007d3d13be2653  add rsp, 0x08
00007d3d13be2657  jmp 0x00007D3D13BDF593
00007d3d13be265c  sub rsp, 0x08
00007d3d13be2660  push rax
00007d3d13be2661  push rcx
00007d3d13be2662  push rdx
00007d3d13be2663  push rdi
00007d3d13be2664  push rsi
00007d3d13be2665  push r8
00007d3d13be2667  push r9
00007d3d13be2669  push r10
00007d3d13be266b  push r11
00007d3d13be266d  sub rsp, 0xF0
00007d3d13be2674  vmovaps [rsp], xmm0
00007d3d13be2679  vmovaps [rsp+0x10], xmm1
00007d3d13be267f  vmovaps [rsp+0x20], xmm2
00007d3d13be2685  vmovaps [rsp+0x30], xmm3
00007d3d13be268b  vmovaps [rsp+0x40], xmm4
00007d3d13be2691  vmovaps [rsp+0x50], xmm5
00007d3d13be2697  vmovaps [rsp+0x60], xmm7
00007d3d13be269d  vmovaps [rsp+0x70], xmm8
00007d3d13be26a3  vmovaps [rsp+0x80], xmm9
00007d3d13be26ac  vmovaps [rsp+0x90], xmm10
00007d3d13be26b5  vmovaps [rsp+0xA0], xmm11
00007d3d13be26be  vmovaps [rsp+0xB0], xmm12
00007d3d13be26c7  vmovaps [rsp+0xC0], xmm13
00007d3d13be26d0  vmovaps [rsp+0xD0], xmm14
00007d3d13be26d9  vmovaps [rsp+0xE0], xmm15
00007d3d13be26e2  sub rsp, 0x30
00007d3d13be26e6  movaps [rsp], xmm6
00007d3d13be26ea  movaps [rsp+0x10], xmm10
00007d3d13be26f0  movaps [rsp+0x20], xmm8
00007d3d13be26f6  lea rdi, [rsp]
00007d3d13be26fa  mov esi, 0x00
00007d3d13be26ff  mov rax, 0x5741DAFC8530
00007d3d13be2709  call rax
00007d3d13be270b  movaps xmm6, [rsp]
00007d3d13be270f  add rsp, 0x30
00007d3d13be2713  vmovaps xmm0, [rsp]
00007d3d13be2718  vmovaps xmm1, [rsp+0x10]
00007d3d13be271e  vmovaps xmm2, [rsp+0x20]
00007d3d13be2724  vmovaps xmm3, [rsp+0x30]
00007d3d13be272a  vmovaps xmm4, [rsp+0x40]
00007d3d13be2730  vmovaps xmm5, [rsp+0x50]
00007d3d13be2736  vmovaps xmm7, [rsp+0x60]
00007d3d13be273c  vmovaps xmm8, [rsp+0x70]
00007d3d13be2742  vmovaps xmm9, [rsp+0x80]
00007d3d13be274b  vmovaps xmm10, [rsp+0x90]
00007d3d13be2754  vmovaps xmm11, [rsp+0xA0]
00007d3d13be275d  vmovaps xmm12, [rsp+0xB0]
00007d3d13be2766  vmovaps xmm13, [rsp+0xC0]
00007d3d13be276f  vmovaps xmm14, [rsp+0xD0]
00007d3d13be2778  vmovaps xmm15, [rsp+0xE0]
00007d3d13be2781  add rsp, 0xF0
00007d3d13be2788  pop r11
00007d3d13be278a  pop r10
00007d3d13be278c  pop r9
00007d3d13be278e  pop r8
00007d3d13be2790  pop rsi
00007d3d13be2791  pop rdi
00007d3d13be2792  pop rdx
00007d3d13be2793  pop rcx
00007d3d13be2794  pop rax
00007d3d13be2795  add rsp, 0x08
00007d3d13be2799  jmp 0x00007D3D13BDF5B8
00007d3d13be279e  sub rsp, 0x08
00007d3d13be27a2  push rax
00007d3d13be27a3  push rcx
00007d3d13be27a4  push rdx
00007d3d13be27a5  push rdi
00007d3d13be27a6  push rsi
00007d3d13be27a7  push r8
00007d3d13be27a9  push r9
00007d3d13be27ab  push r10
00007d3d13be27ad  push r11
00007d3d13be27af  sub rsp, 0xF0
00007d3d13be27b6  vmovaps [rsp], xmm0
00007d3d13be27bb  vmovaps [rsp+0x10], xmm1
00007d3d13be27c1  vmovaps [rsp+0x20], xmm2
00007d3d13be27c7  vmovaps [rsp+0x30], xmm3
00007d3d13be27cd  vmovaps [rsp+0x40], xmm4
00007d3d13be27d3  vmovaps [rsp+0x50], xmm5
00007d3d13be27d9  vmovaps [rsp+0x60], xmm6
00007d3d13be27df  vmovaps [rsp+0x70], xmm7
00007d3d13be27e5  vmovaps [rsp+0x80], xmm8
00007d3d13be27ee  vmovaps [rsp+0x90], xmm9
00007d3d13be27f7  vmovaps [rsp+0xA0], xmm11
00007d3d13be2800  vmovaps [rsp+0xB0], xmm12
00007d3d13be2809  vmovaps [rsp+0xC0], xmm13
00007d3d13be2812  vmovaps [rsp+0xD0], xmm14
00007d3d13be281b  vmovaps [rsp+0xE0], xmm15
00007d3d13be2824  sub rsp, 0x30
00007d3d13be2828  movaps [rsp], xmm10
00007d3d13be282d  movaps [rsp+0x10], xmm8
00007d3d13be2833  movaps [rsp+0x20], xmm14
00007d3d13be2839  lea rdi, [rsp]
00007d3d13be283d  mov esi, 0x00
00007d3d13be2842  mov rax, 0x5741DAFC8530
00007d3d13be284c  call rax
00007d3d13be284e  movaps xmm10, [rsp]
00007d3d13be2853  add rsp, 0x30
00007d3d13be2857  vmovaps xmm0, [rsp]
00007d3d13be285c  vmovaps xmm1, [rsp+0x10]
00007d3d13be2862  vmovaps xmm2, [rsp+0x20]
00007d3d13be2868  vmovaps xmm3, [rsp+0x30]
00007d3d13be286e  vmovaps xmm4, [rsp+0x40]
00007d3d13be2874  vmovaps xmm5, [rsp+0x50]
00007d3d13be287a  vmovaps xmm6, [rsp+0x60]
00007d3d13be2880  vmovaps xmm7, [rsp+0x70]
00007d3d13be2886  vmovaps xmm8, [rsp+0x80]
00007d3d13be288f  vmovaps xmm9, [rsp+0x90]
00007d3d13be2898  vmovaps xmm11, [rsp+0xA0]
00007d3d13be28a1  vmovaps xmm12, [rsp+0xB0]
00007d3d13be28aa  vmovaps xmm13, [rsp+0xC0]
00007d3d13be28b3  vmovaps xmm14, [rsp+0xD0]
00007d3d13be28bc  vmovaps xmm15, [rsp+0xE0]
00007d3d13be28c5  add rsp, 0xF0
00007d3d13be28cc  pop r11
00007d3d13be28ce  pop r10
00007d3d13be28d0  pop r9
00007d3d13be28d2  pop r8
00007d3d13be28d4  pop rsi
00007d3d13be28d5  pop rdi
00007d3d13be28d6  pop rdx
00007d3d13be28d7  pop rcx
00007d3d13be28d8  pop rax
00007d3d13be28d9  add rsp, 0x08
00007d3d13be28dd  jmp 0x00007D3D13BDF5D8
00007d3d13be28e2  sub rsp, 0x08
00007d3d13be28e6  push rax
00007d3d13be28e7  push rcx
00007d3d13be28e8  push rdx
00007d3d13be28e9  push rdi
00007d3d13be28ea  push rsi
00007d3d13be28eb  push r8
00007d3d13be28ed  push r9
00007d3d13be28ef  push r10
00007d3d13be28f1  push r11
00007d3d13be28f3  sub rsp, 0xF0
00007d3d13be28fa  vmovaps [rsp], xmm0
00007d3d13be28ff  vmovaps [rsp+0x10], xmm1
00007d3d13be2905  vmovaps [rsp+0x20], xmm2
00007d3d13be290b  vmovaps [rsp+0x30], xmm3
00007d3d13be2911  vmovaps [rsp+0x40], xmm4
00007d3d13be2917  vmovaps [rsp+0x50], xmm5
00007d3d13be291d  vmovaps [rsp+0x60], xmm6
00007d3d13be2923  vmovaps [rsp+0x70], xmm7
00007d3d13be2929  vmovaps [rsp+0x80], xmm8
00007d3d13be2932  vmovaps [rsp+0x90], xmm9
00007d3d13be293b  vmovaps [rsp+0xA0], xmm10
00007d3d13be2944  vmovaps [rsp+0xB0], xmm11
00007d3d13be294d  vmovaps [rsp+0xC0], xmm12
00007d3d13be2956  vmovaps [rsp+0xD0], xmm13
00007d3d13be295f  vmovaps [rsp+0xE0], xmm15
00007d3d13be2968  sub rsp, 0x30
00007d3d13be296c  movaps [rsp], xmm14
00007d3d13be2971  movaps [rsp+0x10], xmm8
00007d3d13be2977  movaps [rsp+0x20], xmm4
00007d3d13be297c  lea rdi, [rsp]
00007d3d13be2980  mov esi, 0x00
00007d3d13be2985  mov rax, 0x5741DAFC8530
00007d3d13be298f  call rax
00007d3d13be2991  movaps xmm14, [rsp]
00007d3d13be2996  add rsp, 0x30
00007d3d13be299a  vmovaps xmm0, [rsp]
00007d3d13be299f  vmovaps xmm1, [rsp+0x10]
00007d3d13be29a5  vmovaps xmm2, [rsp+0x20]
00007d3d13be29ab  vmovaps xmm3, [rsp+0x30]
00007d3d13be29b1  vmovaps xmm4, [rsp+0x40]
00007d3d13be29b7  vmovaps xmm5, [rsp+0x50]
00007d3d13be29bd  vmovaps xmm6, [rsp+0x60]
00007d3d13be29c3  vmovaps xmm7, [rsp+0x70]
00007d3d13be29c9  vmovaps xmm8, [rsp+0x80]
00007d3d13be29d2  vmovaps xmm9, [rsp+0x90]
00007d3d13be29db  vmovaps xmm10, [rsp+0xA0]
00007d3d13be29e4  vmovaps xmm11, [rsp+0xB0]
00007d3d13be29ed  vmovaps xmm12, [rsp+0xC0]
00007d3d13be29f6  vmovaps xmm13, [rsp+0xD0]
00007d3d13be29ff  vmovaps xmm15, [rsp+0xE0]
00007d3d13be2a08  add rsp, 0xF0
00007d3d13be2a0f  pop r11
00007d3d13be2a11  pop r10
00007d3d13be2a13  pop r9
00007d3d13be2a15  pop r8
00007d3d13be2a17  pop rsi
00007d3d13be2a18  pop rdi
00007d3d13be2a19  pop rdx
00007d3d13be2a1a  pop rcx
00007d3d13be2a1b  pop rax
00007d3d13be2a1c  add rsp, 0x08
00007d3d13be2a20  jmp 0x00007D3D13BDF5F8
00007d3d13be2a25  sub rsp, 0x08
00007d3d13be2a29  push rax
00007d3d13be2a2a  push rcx
00007d3d13be2a2b  push rdx
00007d3d13be2a2c  push rdi
00007d3d13be2a2d  push rsi
00007d3d13be2a2e  push r8
00007d3d13be2a30  push r9
00007d3d13be2a32  push r10
00007d3d13be2a34  push r11
00007d3d13be2a36  sub rsp, 0xF0
00007d3d13be2a3d  vmovaps [rsp], xmm0
00007d3d13be2a42  vmovaps [rsp+0x10], xmm1
00007d3d13be2a48  vmovaps [rsp+0x20], xmm2
00007d3d13be2a4e  vmovaps [rsp+0x30], xmm3
00007d3d13be2a54  vmovaps [rsp+0x40], xmm5
00007d3d13be2a5a  vmovaps [rsp+0x50], xmm6
00007d3d13be2a60  vmovaps [rsp+0x60], xmm7
00007d3d13be2a66  vmovaps [rsp+0x70], xmm8
00007d3d13be2a6c  vmovaps [rsp+0x80], xmm9
00007d3d13be2a75  vmovaps [rsp+0x90], xmm10
00007d3d13be2a7e  vmovaps [rsp+0xA0], xmm11
00007d3d13be2a87  vmovaps [rsp+0xB0], xmm12
00007d3d13be2a90  vmovaps [rsp+0xC0], xmm13
00007d3d13be2a99  vmovaps [rsp+0xD0], xmm14
00007d3d13be2aa2  vmovaps [rsp+0xE0], xmm15
00007d3d13be2aab  sub rsp, 0x30
00007d3d13be2aaf  movaps [rsp], xmm4
00007d3d13be2ab3  movaps [rsp+0x10], xmm13
00007d3d13be2ab9  movaps [rsp+0x20], xmm8
00007d3d13be2abf  lea rdi, [rsp]
00007d3d13be2ac3  mov esi, 0x00
00007d3d13be2ac8  mov rax, 0x5741DAFC8530
00007d3d13be2ad2  call rax
00007d3d13be2ad4  movaps xmm4, [rsp]
00007d3d13be2ad8  add rsp, 0x30
00007d3d13be2adc  vmovaps xmm0, [rsp]
00007d3d13be2ae1  vmovaps xmm1, [rsp+0x10]
00007d3d13be2ae7  vmovaps xmm2, [rsp+0x20]
00007d3d13be2aed  vmovaps xmm3, [rsp+0x30]
00007d3d13be2af3  vmovaps xmm5, [rsp+0x40]
00007d3d13be2af9  vmovaps xmm6, [rsp+0x50]
00007d3d13be2aff  vmovaps xmm7, [rsp+0x60]
00007d3d13be2b05  vmovaps xmm8, [rsp+0x70]
00007d3d13be2b0b  vmovaps xmm9, [rsp+0x80]
00007d3d13be2b14  vmovaps xmm10, [rsp+0x90]
00007d3d13be2b1d  vmovaps xmm11, [rsp+0xA0]
00007d3d13be2b26  vmovaps xmm12, [rsp+0xB0]
00007d3d13be2b2f  vmovaps xmm13, [rsp+0xC0]
00007d3d13be2b38  vmovaps xmm14, [rsp+0xD0]
00007d3d13be2b41  vmovaps xmm15, [rsp+0xE0]
00007d3d13be2b4a  add rsp, 0xF0
00007d3d13be2b51  pop r11
00007d3d13be2b53  pop r10
00007d3d13be2b55  pop r9
00007d3d13be2b57  pop r8
00007d3d13be2b59  pop rsi
00007d3d13be2b5a  pop rdi
00007d3d13be2b5b  pop rdx
00007d3d13be2b5c  pop rcx
00007d3d13be2b5d  pop rax
00007d3d13be2b5e  add rsp, 0x08
00007d3d13be2b62  jmp 0x00007D3D13BDF61D
00007d3d13be2b67  sub rsp, 0x08
00007d3d13be2b6b  push rax
00007d3d13be2b6c  push rcx
00007d3d13be2b6d  push rdx
00007d3d13be2b6e  push rdi
00007d3d13be2b6f  push rsi
00007d3d13be2b70  push r8
00007d3d13be2b72  push r9
00007d3d13be2b74  push r10
00007d3d13be2b76  push r11
00007d3d13be2b78  sub rsp, 0xF0
00007d3d13be2b7f  vmovaps [rsp], xmm0
00007d3d13be2b84  vmovaps [rsp+0x10], xmm1
00007d3d13be2b8a  vmovaps [rsp+0x20], xmm2
00007d3d13be2b90  vmovaps [rsp+0x30], xmm3
00007d3d13be2b96  vmovaps [rsp+0x40], xmm4
00007d3d13be2b9c  vmovaps [rsp+0x50], xmm5
00007d3d13be2ba2  vmovaps [rsp+0x60], xmm6
00007d3d13be2ba8  vmovaps [rsp+0x70], xmm7
00007d3d13be2bae  vmovaps [rsp+0x80], xmm8
00007d3d13be2bb7  vmovaps [rsp+0x90], xmm9
00007d3d13be2bc0  vmovaps [rsp+0xA0], xmm10
00007d3d13be2bc9  vmovaps [rsp+0xB0], xmm11
00007d3d13be2bd2  vmovaps [rsp+0xC0], xmm12
00007d3d13be2bdb  vmovaps [rsp+0xD0], xmm14
00007d3d13be2be4  vmovaps [rsp+0xE0], xmm15
00007d3d13be2bed  sub rsp, 0x30
00007d3d13be2bf1  movaps [rsp], xmm13
00007d3d13be2bf6  movaps [rsp+0x10], xmm15
00007d3d13be2bfc  movaps [rsp+0x20], xmm9
00007d3d13be2c02  lea rdi, [rsp]
00007d3d13be2c06  mov esi, 0x00
00007d3d13be2c0b  mov rax, 0x5741DAFC8530
00007d3d13be2c15  call rax
00007d3d13be2c17  movaps xmm13, [rsp]
00007d3d13be2c1c  add rsp, 0x30
00007d3d13be2c20  vmovaps xmm0, [rsp]
00007d3d13be2c25  vmovaps xmm1, [rsp+0x10]
00007d3d13be2c2b  vmovaps xmm2, [rsp+0x20]
00007d3d13be2c31  vmovaps xmm3, [rsp+0x30]
00007d3d13be2c37  vmovaps xmm4, [rsp+0x40]
00007d3d13be2c3d  vmovaps xmm5, [rsp+0x50]
00007d3d13be2c43  vmovaps xmm6, [rsp+0x60]
00007d3d13be2c49  vmovaps xmm7, [rsp+0x70]
00007d3d13be2c4f  vmovaps xmm8, [rsp+0x80]
00007d3d13be2c58  vmovaps xmm9, [rsp+0x90]
00007d3d13be2c61  vmovaps xmm10, [rsp+0xA0]
00007d3d13be2c6a  vmovaps xmm11, [rsp+0xB0]
00007d3d13be2c73  vmovaps xmm12, [rsp+0xC0]
00007d3d13be2c7c  vmovaps xmm14, [rsp+0xD0]
00007d3d13be2c85  vmovaps xmm15, [rsp+0xE0]
00007d3d13be2c8e  add rsp, 0xF0
00007d3d13be2c95  pop r11
00007d3d13be2c97  pop r10
00007d3d13be2c99  pop r9
00007d3d13be2c9b  pop r8
00007d3d13be2c9d  pop rsi
00007d3d13be2c9e  pop rdi
00007d3d13be2c9f  pop rdx
00007d3d13be2ca0  pop rcx
00007d3d13be2ca1  pop rax
00007d3d13be2ca2  add rsp, 0x08
00007d3d13be2ca6  jmp 0x00007D3D13BDF638
00007d3d13be2cab  sub rsp, 0x08
00007d3d13be2caf  push rax
00007d3d13be2cb0  push rcx
00007d3d13be2cb1  push rdx
00007d3d13be2cb2  push rdi
00007d3d13be2cb3  push rsi
00007d3d13be2cb4  push r8
00007d3d13be2cb6  push r9
00007d3d13be2cb8  push r10
00007d3d13be2cba  push r11
00007d3d13be2cbc  sub rsp, 0xF0
00007d3d13be2cc3  vmovaps [rsp], xmm0
00007d3d13be2cc8  vmovaps [rsp+0x10], xmm1
00007d3d13be2cce  vmovaps [rsp+0x20], xmm2
00007d3d13be2cd4  vmovaps [rsp+0x30], xmm3
00007d3d13be2cda  vmovaps [rsp+0x40], xmm4
00007d3d13be2ce0  vmovaps [rsp+0x50], xmm5
00007d3d13be2ce6  vmovaps [rsp+0x60], xmm6
00007d3d13be2cec  vmovaps [rsp+0x70], xmm7
00007d3d13be2cf2  vmovaps [rsp+0x80], xmm8
00007d3d13be2cfb  vmovaps [rsp+0x90], xmm9
00007d3d13be2d04  vmovaps [rsp+0xA0], xmm10
00007d3d13be2d0d  vmovaps [rsp+0xB0], xmm11
00007d3d13be2d16  vmovaps [rsp+0xC0], xmm12
00007d3d13be2d1f  vmovaps [rsp+0xD0], xmm13
00007d3d13be2d28  vmovaps [rsp+0xE0], xmm14
00007d3d13be2d31  sub rsp, 0x30
00007d3d13be2d35  movaps [rsp], xmm15
00007d3d13be2d3a  movaps [rsp+0x10], xmm1
00007d3d13be2d3f  movaps [rsp+0x20], xmm5
00007d3d13be2d44  lea rdi, [rsp]
00007d3d13be2d48  mov esi, 0x00
00007d3d13be2d4d  mov rax, 0x5741DAFC8530
00007d3d13be2d57  call rax
00007d3d13be2d59  movaps xmm15, [rsp]
00007d3d13be2d5e  add rsp, 0x30
00007d3d13be2d62  vmovaps xmm0, [rsp]
00007d3d13be2d67  vmovaps xmm1, [rsp+0x10]
00007d3d13be2d6d  vmovaps xmm2, [rsp+0x20]
00007d3d13be2d73  vmovaps xmm3, [rsp+0x30]
00007d3d13be2d79  vmovaps xmm4, [rsp+0x40]
00007d3d13be2d7f  vmovaps xmm5, [rsp+0x50]
00007d3d13be2d85  vmovaps xmm6, [rsp+0x60]
00007d3d13be2d8b  vmovaps xmm7, [rsp+0x70]
00007d3d13be2d91  vmovaps xmm8, [rsp+0x80]
00007d3d13be2d9a  vmovaps xmm9, [rsp+0x90]
00007d3d13be2da3  vmovaps xmm10, [rsp+0xA0]
00007d3d13be2dac  vmovaps xmm11, [rsp+0xB0]
00007d3d13be2db5  vmovaps xmm12, [rsp+0xC0]
00007d3d13be2dbe  vmovaps xmm13, [rsp+0xD0]
00007d3d13be2dc7  vmovaps xmm14, [rsp+0xE0]
00007d3d13be2dd0  add rsp, 0xF0
00007d3d13be2dd7  pop r11
00007d3d13be2dd9  pop r10
00007d3d13be2ddb  pop r9
00007d3d13be2ddd  pop r8
00007d3d13be2ddf  pop rsi
00007d3d13be2de0  pop rdi
00007d3d13be2de1  pop rdx
00007d3d13be2de2  pop rcx
00007d3d13be2de3  pop rax
00007d3d13be2de4  add rsp, 0x08
00007d3d13be2de8  jmp 0x00007D3D13BDF653
00007d3d13be2ded  call 0x00007D3D13AB52F0
00007d3d13be2df2  jmp 0x00007D3D13BDF6AE
00007d3d13be2df7  sub rsp, 0x08
00007d3d13be2dfb  push rax
00007d3d13be2dfc  push rcx
00007d3d13be2dfd  push rdx
00007d3d13be2dfe  push rdi
00007d3d13be2dff  push rsi
00007d3d13be2e00  push r8
00007d3d13be2e02  push r9
00007d3d13be2e04  push r10
00007d3d13be2e06  push r11
00007d3d13be2e08  sub rsp, 0xF0
00007d3d13be2e0f  vmovaps [rsp], xmm0
00007d3d13be2e14  vmovaps [rsp+0x10], xmm1
00007d3d13be2e1a  vmovaps [rsp+0x20], xmm2
00007d3d13be2e20  vmovaps [rsp+0x30], xmm3
00007d3d13be2e26  vmovaps [rsp+0x40], xmm4
00007d3d13be2e2c  vmovaps [rsp+0x50], xmm5
00007d3d13be2e32  vmovaps [rsp+0x60], xmm6
00007d3d13be2e38  vmovaps [rsp+0x70], xmm7
00007d3d13be2e3e  vmovaps [rsp+0x80], xmm8
00007d3d13be2e47  vmovaps [rsp+0x90], xmm10
00007d3d13be2e50  vmovaps [rsp+0xA0], xmm11
00007d3d13be2e59  vmovaps [rsp+0xB0], xmm12
00007d3d13be2e62  vmovaps [rsp+0xC0], xmm13
00007d3d13be2e6b  vmovaps [rsp+0xD0], xmm14
00007d3d13be2e74  vmovaps [rsp+0xE0], xmm15
00007d3d13be2e7d  sub rsp, 0x30
00007d3d13be2e81  movaps [rsp], xmm9
00007d3d13be2e86  movaps [rsp+0x10], xmm8
00007d3d13be2e8c  movaps [rsp+0x20], xmm11
00007d3d13be2e92  lea rdi, [rsp]
00007d3d13be2e96  mov esi, 0x00
00007d3d13be2e9b  mov rax, 0x5741DAFC8530
00007d3d13be2ea5  call rax
00007d3d13be2ea7  movaps xmm9, [rsp]
00007d3d13be2eac  add rsp, 0x30
00007d3d13be2eb0  vmovaps xmm0, [rsp]
00007d3d13be2eb5  vmovaps xmm1, [rsp+0x10]
00007d3d13be2ebb  vmovaps xmm2, [rsp+0x20]
00007d3d13be2ec1  vmovaps xmm3, [rsp+0x30]
00007d3d13be2ec7  vmovaps xmm4, [rsp+0x40]
00007d3d13be2ecd  vmovaps xmm5, [rsp+0x50]
00007d3d13be2ed3  vmovaps xmm6, [rsp+0x60]
00007d3d13be2ed9  vmovaps xmm7, [rsp+0x70]
00007d3d13be2edf  vmovaps xmm8, [rsp+0x80]
00007d3d13be2ee8  vmovaps xmm10, [rsp+0x90]
00007d3d13be2ef1  vmovaps xmm11, [rsp+0xA0]
00007d3d13be2efa  vmovaps xmm12, [rsp+0xB0]
00007d3d13be2f03  vmovaps xmm13, [rsp+0xC0]
00007d3d13be2f0c  vmovaps xmm14, [rsp+0xD0]
00007d3d13be2f15  vmovaps xmm15, [rsp+0xE0]
00007d3d13be2f1e  add rsp, 0xF0
00007d3d13be2f25  pop r11
00007d3d13be2f27  pop r10
00007d3d13be2f29  pop r9
00007d3d13be2f2b  pop r8
00007d3d13be2f2d  pop rsi
00007d3d13be2f2e  pop rdi
00007d3d13be2f2f  pop rdx
00007d3d13be2f30  pop rcx
00007d3d13be2f31  pop rax
00007d3d13be2f32  add rsp, 0x08
00007d3d13be2f36  jmp 0x00007D3D13BDF6E5
00007d3d13be2f3b  sub rsp, 0x08
00007d3d13be2f3f  push rax
00007d3d13be2f40  push rcx
00007d3d13be2f41  push rdx
00007d3d13be2f42  push rdi
00007d3d13be2f43  push rsi
00007d3d13be2f44  push r8
00007d3d13be2f46  push r9
00007d3d13be2f48  push r10
00007d3d13be2f4a  push r11
00007d3d13be2f4c  sub rsp, 0xF0
00007d3d13be2f53  vmovaps [rsp], xmm0
00007d3d13be2f58  vmovaps [rsp+0x10], xmm1
00007d3d13be2f5e  vmovaps [rsp+0x20], xmm2
00007d3d13be2f64  vmovaps [rsp+0x30], xmm3
00007d3d13be2f6a  vmovaps [rsp+0x40], xmm4
00007d3d13be2f70  vmovaps [rsp+0x50], xmm5
00007d3d13be2f76  vmovaps [rsp+0x60], xmm6
00007d3d13be2f7c  vmovaps [rsp+0x70], xmm7
00007d3d13be2f82  vmovaps [rsp+0x80], xmm8
00007d3d13be2f8b  vmovaps [rsp+0x90], xmm9
00007d3d13be2f94  vmovaps [rsp+0xA0], xmm10
00007d3d13be2f9d  vmovaps [rsp+0xB0], xmm12
00007d3d13be2fa6  vmovaps [rsp+0xC0], xmm13
00007d3d13be2faf  vmovaps [rsp+0xD0], xmm14
00007d3d13be2fb8  vmovaps [rsp+0xE0], xmm15
00007d3d13be2fc1  sub rsp, 0x30
00007d3d13be2fc5  movaps [rsp], xmm11
00007d3d13be2fca  movaps [rsp+0x10], xmm10
00007d3d13be2fd0  movaps [rsp+0x20], xmm6
00007d3d13be2fd5  lea rdi, [rsp]
00007d3d13be2fd9  mov esi, 0x00
00007d3d13be2fde  mov rax, 0x5741DAFC8530
00007d3d13be2fe8  call rax
00007d3d13be2fea  movaps xmm11, [rsp]
00007d3d13be2fef  add rsp, 0x30
00007d3d13be2ff3  vmovaps xmm0, [rsp]
00007d3d13be2ff8  vmovaps xmm1, [rsp+0x10]
00007d3d13be2ffe  vmovaps xmm2, [rsp+0x20]
00007d3d13be3004  vmovaps xmm3, [rsp+0x30]
00007d3d13be300a  vmovaps xmm4, [rsp+0x40]
00007d3d13be3010  vmovaps xmm5, [rsp+0x50]
00007d3d13be3016  vmovaps xmm6, [rsp+0x60]
00007d3d13be301c  vmovaps xmm7, [rsp+0x70]
00007d3d13be3022  vmovaps xmm8, [rsp+0x80]
00007d3d13be302b  vmovaps xmm9, [rsp+0x90]
00007d3d13be3034  vmovaps xmm10, [rsp+0xA0]
00007d3d13be303d  vmovaps xmm12, [rsp+0xB0]
00007d3d13be3046  vmovaps xmm13, [rsp+0xC0]
00007d3d13be304f  vmovaps xmm14, [rsp+0xD0]
00007d3d13be3058  vmovaps xmm15, [rsp+0xE0]
00007d3d13be3061  add rsp, 0xF0
00007d3d13be3068  pop r11
00007d3d13be306a  pop r10
00007d3d13be306c  pop r9
00007d3d13be306e  pop r8
00007d3d13be3070  pop rsi
00007d3d13be3071  pop rdi
00007d3d13be3072  pop rdx
00007d3d13be3073  pop rcx
00007d3d13be3074  pop rax
00007d3d13be3075  add rsp, 0x08
00007d3d13be3079  jmp 0x00007D3D13BDF700
00007d3d13be307e  sub rsp, 0x08
00007d3d13be3082  push rax
00007d3d13be3083  push rcx
00007d3d13be3084  push rdx
00007d3d13be3085  push rdi
00007d3d13be3086  push rsi
00007d3d13be3087  push r8
00007d3d13be3089  push r9
00007d3d13be308b  push r10
00007d3d13be308d  push r11
00007d3d13be308f  sub rsp, 0xF0
00007d3d13be3096  vmovaps [rsp], xmm0
00007d3d13be309b  vmovaps [rsp+0x10], xmm1
00007d3d13be30a1  vmovaps [rsp+0x20], xmm2
00007d3d13be30a7  vmovaps [rsp+0x30], xmm3
00007d3d13be30ad  vmovaps [rsp+0x40], xmm4
00007d3d13be30b3  vmovaps [rsp+0x50], xmm5
00007d3d13be30b9  vmovaps [rsp+0x60], xmm6
00007d3d13be30bf  vmovaps [rsp+0x70], xmm7
00007d3d13be30c5  vmovaps [rsp+0x80], xmm8
00007d3d13be30ce  vmovaps [rsp+0x90], xmm9
00007d3d13be30d7  vmovaps [rsp+0xA0], xmm11
00007d3d13be30e0  vmovaps [rsp+0xB0], xmm12
00007d3d13be30e9  vmovaps [rsp+0xC0], xmm13
00007d3d13be30f2  vmovaps [rsp+0xD0], xmm14
00007d3d13be30fb  vmovaps [rsp+0xE0], xmm15
00007d3d13be3104  sub rsp, 0x30
00007d3d13be3108  movaps [rsp], xmm10
00007d3d13be310d  movaps [rsp+0x10], xmm14
00007d3d13be3113  movaps [rsp+0x20], xmm4
00007d3d13be3118  lea rdi, [rsp]
00007d3d13be311c  mov esi, 0x00
00007d3d13be3121  mov rax, 0x5741DAFC8530
00007d3d13be312b  call rax
00007d3d13be312d  movaps xmm10, [rsp]
00007d3d13be3132  add rsp, 0x30
00007d3d13be3136  vmovaps xmm0, [rsp]
00007d3d13be313b  vmovaps xmm1, [rsp+0x10]
00007d3d13be3141  vmovaps xmm2, [rsp+0x20]
00007d3d13be3147  vmovaps xmm3, [rsp+0x30]
00007d3d13be314d  vmovaps xmm4, [rsp+0x40]
00007d3d13be3153  vmovaps xmm5, [rsp+0x50]
00007d3d13be3159  vmovaps xmm6, [rsp+0x60]
00007d3d13be315f  vmovaps xmm7, [rsp+0x70]
00007d3d13be3165  vmovaps xmm8, [rsp+0x80]
00007d3d13be316e  vmovaps xmm9, [rsp+0x90]
00007d3d13be3177  vmovaps xmm11, [rsp+0xA0]
00007d3d13be3180  vmovaps xmm12, [rsp+0xB0]
00007d3d13be3189  vmovaps xmm13, [rsp+0xC0]
00007d3d13be3192  vmovaps xmm14, [rsp+0xD0]
00007d3d13be319b  vmovaps xmm15, [rsp+0xE0]
00007d3d13be31a4  add rsp, 0xF0
00007d3d13be31ab  pop r11
00007d3d13be31ad  pop r10
00007d3d13be31af  pop r9
00007d3d13be31b1  pop r8
00007d3d13be31b3  pop rsi
00007d3d13be31b4  pop rdi
00007d3d13be31b5  pop rdx
00007d3d13be31b6  pop rcx
00007d3d13be31b7  pop rax
00007d3d13be31b8  add rsp, 0x08
00007d3d13be31bc  jmp 0x00007D3D13BDF71B
00007d3d13be31c1  sub rsp, 0x08
00007d3d13be31c5  push rax
00007d3d13be31c6  push rcx
00007d3d13be31c7  push rdx
00007d3d13be31c8  push rdi
00007d3d13be31c9  push rsi
00007d3d13be31ca  push r8
00007d3d13be31cc  push r9
00007d3d13be31ce  push r10
00007d3d13be31d0  push r11
00007d3d13be31d2  sub rsp, 0xF0
00007d3d13be31d9  vmovaps [rsp], xmm0
00007d3d13be31de  vmovaps [rsp+0x10], xmm1
00007d3d13be31e4  vmovaps [rsp+0x20], xmm2
00007d3d13be31ea  vmovaps [rsp+0x30], xmm3
00007d3d13be31f0  vmovaps [rsp+0x40], xmm4
00007d3d13be31f6  vmovaps [rsp+0x50], xmm5
00007d3d13be31fc  vmovaps [rsp+0x60], xmm6
00007d3d13be3202  vmovaps [rsp+0x70], xmm7
00007d3d13be3208  vmovaps [rsp+0x80], xmm9
00007d3d13be3211  vmovaps [rsp+0x90], xmm10
00007d3d13be321a  vmovaps [rsp+0xA0], xmm11
00007d3d13be3223  vmovaps [rsp+0xB0], xmm12
00007d3d13be322c  vmovaps [rsp+0xC0], xmm13
00007d3d13be3235  vmovaps [rsp+0xD0], xmm14
00007d3d13be323e  vmovaps [rsp+0xE0], xmm15
00007d3d13be3247  sub rsp, 0x30
00007d3d13be324b  movaps [rsp], xmm8
00007d3d13be3250  movaps [rsp+0x10], xmm1
00007d3d13be3255  movaps [rsp+0x20], xmm14
00007d3d13be325b  lea rdi, [rsp]
00007d3d13be325f  mov esi, 0x00
00007d3d13be3264  mov rax, 0x5741DAFC8530
00007d3d13be326e  call rax
00007d3d13be3270  movaps xmm8, [rsp]
00007d3d13be3275  add rsp, 0x30
00007d3d13be3279  vmovaps xmm0, [rsp]
00007d3d13be327e  vmovaps xmm1, [rsp+0x10]
00007d3d13be3284  vmovaps xmm2, [rsp+0x20]
00007d3d13be328a  vmovaps xmm3, [rsp+0x30]
00007d3d13be3290  vmovaps xmm4, [rsp+0x40]
00007d3d13be3296  vmovaps xmm5, [rsp+0x50]
00007d3d13be329c  vmovaps xmm6, [rsp+0x60]
00007d3d13be32a2  vmovaps xmm7, [rsp+0x70]
00007d3d13be32a8  vmovaps xmm9, [rsp+0x80]
00007d3d13be32b1  vmovaps xmm10, [rsp+0x90]
00007d3d13be32ba  vmovaps xmm11, [rsp+0xA0]
00007d3d13be32c3  vmovaps xmm12, [rsp+0xB0]
00007d3d13be32cc  vmovaps xmm13, [rsp+0xC0]
00007d3d13be32d5  vmovaps xmm14, [rsp+0xD0]
00007d3d13be32de  vmovaps xmm15, [rsp+0xE0]
00007d3d13be32e7  add rsp, 0xF0
00007d3d13be32ee  pop r11
00007d3d13be32f0  pop r10
00007d3d13be32f2  pop r9
00007d3d13be32f4  pop r8
00007d3d13be32f6  pop rsi
00007d3d13be32f7  pop rdi
00007d3d13be32f8  pop rdx
00007d3d13be32f9  pop rcx
00007d3d13be32fa  pop rax
00007d3d13be32fb  add rsp, 0x08
00007d3d13be32ff  jmp 0x00007D3D13BDF741
00007d3d13be3304  sub rsp, 0x08
00007d3d13be3308  push rax
00007d3d13be3309  push rcx
00007d3d13be330a  push rdx
00007d3d13be330b  push rdi
00007d3d13be330c  push rsi
00007d3d13be330d  push r8
00007d3d13be330f  push r9
00007d3d13be3311  push r10
00007d3d13be3313  push r11
00007d3d13be3315  sub rsp, 0xF0
00007d3d13be331c  vmovaps [rsp], xmm0
00007d3d13be3321  vmovaps [rsp+0x10], xmm1
00007d3d13be3327  vmovaps [rsp+0x20], xmm2
00007d3d13be332d  vmovaps [rsp+0x30], xmm3
00007d3d13be3333  vmovaps [rsp+0x40], xmm4
00007d3d13be3339  vmovaps [rsp+0x50], xmm5
00007d3d13be333f  vmovaps [rsp+0x60], xmm7
00007d3d13be3345  vmovaps [rsp+0x70], xmm8
00007d3d13be334b  vmovaps [rsp+0x80], xmm9
00007d3d13be3354  vmovaps [rsp+0x90], xmm10
00007d3d13be335d  vmovaps [rsp+0xA0], xmm11
00007d3d13be3366  vmovaps [rsp+0xB0], xmm12
00007d3d13be336f  vmovaps [rsp+0xC0], xmm13
00007d3d13be3378  vmovaps [rsp+0xD0], xmm14
00007d3d13be3381  vmovaps [rsp+0xE0], xmm15
00007d3d13be338a  sub rsp, 0x30
00007d3d13be338e  movaps [rsp], xmm6
00007d3d13be3392  movaps [rsp+0x10], xmm1
00007d3d13be3397  movaps [rsp+0x20], xmm14
00007d3d13be339d  lea rdi, [rsp]
00007d3d13be33a1  mov esi, 0x00
00007d3d13be33a6  mov rax, 0x5741DAFC8530
00007d3d13be33b0  call rax
00007d3d13be33b2  movaps xmm6, [rsp]
00007d3d13be33b6  add rsp, 0x30
00007d3d13be33ba  vmovaps xmm0, [rsp]
00007d3d13be33bf  vmovaps xmm1, [rsp+0x10]
00007d3d13be33c5  vmovaps xmm2, [rsp+0x20]
00007d3d13be33cb  vmovaps xmm3, [rsp+0x30]
00007d3d13be33d1  vmovaps xmm4, [rsp+0x40]
00007d3d13be33d7  vmovaps xmm5, [rsp+0x50]
00007d3d13be33dd  vmovaps xmm7, [rsp+0x60]
00007d3d13be33e3  vmovaps xmm8, [rsp+0x70]
00007d3d13be33e9  vmovaps xmm9, [rsp+0x80]
00007d3d13be33f2  vmovaps xmm10, [rsp+0x90]
00007d3d13be33fb  vmovaps xmm11, [rsp+0xA0]
00007d3d13be3404  vmovaps xmm12, [rsp+0xB0]
00007d3d13be340d  vmovaps xmm13, [rsp+0xC0]
00007d3d13be3416  vmovaps xmm14, [rsp+0xD0]
00007d3d13be341f  vmovaps xmm15, [rsp+0xE0]
00007d3d13be3428  add rsp, 0xF0
00007d3d13be342f  pop r11
00007d3d13be3431  pop r10
00007d3d13be3433  pop r9
00007d3d13be3435  pop r8
00007d3d13be3437  pop rsi
00007d3d13be3438  pop rdi
00007d3d13be3439  pop rdx
00007d3d13be343a  pop rcx
00007d3d13be343b  pop rax
00007d3d13be343c  add rsp, 0x08
00007d3d13be3440  jmp 0x00007D3D13BDF76D
00007d3d13be3445  sub rsp, 0x08
00007d3d13be3449  push rax
00007d3d13be344a  push rcx
00007d3d13be344b  push rdx
00007d3d13be344c  push rdi
00007d3d13be344d  push rsi
00007d3d13be344e  push r8
00007d3d13be3450  push r9
00007d3d13be3452  push r10
00007d3d13be3454  push r11
00007d3d13be3456  sub rsp, 0xF0
00007d3d13be345d  vmovaps [rsp], xmm0
00007d3d13be3462  vmovaps [rsp+0x10], xmm1
00007d3d13be3468  vmovaps [rsp+0x20], xmm2
00007d3d13be346e  vmovaps [rsp+0x30], xmm3
00007d3d13be3474  vmovaps [rsp+0x40], xmm4
00007d3d13be347a  vmovaps [rsp+0x50], xmm5
00007d3d13be3480  vmovaps [rsp+0x60], xmm6
00007d3d13be3486  vmovaps [rsp+0x70], xmm7
00007d3d13be348c  vmovaps [rsp+0x80], xmm8
00007d3d13be3495  vmovaps [rsp+0x90], xmm9
00007d3d13be349e  vmovaps [rsp+0xA0], xmm10
00007d3d13be34a7  vmovaps [rsp+0xB0], xmm11
00007d3d13be34b0  vmovaps [rsp+0xC0], xmm12
00007d3d13be34b9  vmovaps [rsp+0xD0], xmm13
00007d3d13be34c2  vmovaps [rsp+0xE0], xmm15
00007d3d13be34cb  sub rsp, 0x30
00007d3d13be34cf  movaps [rsp], xmm14
00007d3d13be34d4  movaps [rsp+0x10], xmm12
00007d3d13be34da  movaps [rsp+0x20], xmm1
00007d3d13be34df  lea rdi, [rsp]
00007d3d13be34e3  mov esi, 0x00
00007d3d13be34e8  mov rax, 0x5741DAFC8530
00007d3d13be34f2  call rax
00007d3d13be34f4  movaps xmm14, [rsp]
00007d3d13be34f9  add rsp, 0x30
00007d3d13be34fd  vmovaps xmm0, [rsp]
00007d3d13be3502  vmovaps xmm1, [rsp+0x10]
00007d3d13be3508  vmovaps xmm2, [rsp+0x20]
00007d3d13be350e  vmovaps xmm3, [rsp+0x30]
00007d3d13be3514  vmovaps xmm4, [rsp+0x40]
00007d3d13be351a  vmovaps xmm5, [rsp+0x50]
00007d3d13be3520  vmovaps xmm6, [rsp+0x60]
00007d3d13be3526  vmovaps xmm7, [rsp+0x70]
00007d3d13be352c  vmovaps xmm8, [rsp+0x80]
00007d3d13be3535  vmovaps xmm9, [rsp+0x90]
00007d3d13be353e  vmovaps xmm10, [rsp+0xA0]
00007d3d13be3547  vmovaps xmm11, [rsp+0xB0]
00007d3d13be3550  vmovaps xmm12, [rsp+0xC0]
00007d3d13be3559  vmovaps xmm13, [rsp+0xD0]
00007d3d13be3562  vmovaps xmm15, [rsp+0xE0]
00007d3d13be356b  add rsp, 0xF0
00007d3d13be3572  pop r11
00007d3d13be3574  pop r10
00007d3d13be3576  pop r9
00007d3d13be3578  pop r8
00007d3d13be357a  pop rsi
00007d3d13be357b  pop rdi
00007d3d13be357c  pop rdx
00007d3d13be357d  pop rcx
00007d3d13be357e  pop rax
00007d3d13be357f  add rsp, 0x08
00007d3d13be3583  jmp 0x00007D3D13BDF793
00007d3d13be3588  sub rsp, 0x08
00007d3d13be358c  push rax
00007d3d13be358d  push rcx
00007d3d13be358e  push rdx
00007d3d13be358f  push rdi
00007d3d13be3590  push rsi
00007d3d13be3591  push r8
00007d3d13be3593  push r9
00007d3d13be3595  push r10
00007d3d13be3597  push r11
00007d3d13be3599  sub rsp, 0xF0
00007d3d13be35a0  vmovaps [rsp], xmm0
00007d3d13be35a5  vmovaps [rsp+0x10], xmm2
00007d3d13be35ab  vmovaps [rsp+0x20], xmm3
00007d3d13be35b1  vmovaps [rsp+0x30], xmm4
00007d3d13be35b7  vmovaps [rsp+0x40], xmm5
00007d3d13be35bd  vmovaps [rsp+0x50], xmm6
00007d3d13be35c3  vmovaps [rsp+0x60], xmm7
00007d3d13be35c9  vmovaps [rsp+0x70], xmm8
00007d3d13be35cf  vmovaps [rsp+0x80], xmm9
00007d3d13be35d8  vmovaps [rsp+0x90], xmm10
00007d3d13be35e1  vmovaps [rsp+0xA0], xmm11
00007d3d13be35ea  vmovaps [rsp+0xB0], xmm12
00007d3d13be35f3  vmovaps [rsp+0xC0], xmm13
00007d3d13be35fc  vmovaps [rsp+0xD0], xmm14
00007d3d13be3605  vmovaps [rsp+0xE0], xmm15
00007d3d13be360e  sub rsp, 0x30
00007d3d13be3612  movaps [rsp], xmm1
00007d3d13be3616  movaps [rsp+0x10], xmm13
00007d3d13be361c  movaps [rsp+0x20], xmm9
00007d3d13be3622  lea rdi, [rsp]
00007d3d13be3626  mov esi, 0x00
00007d3d13be362b  mov rax, 0x5741DAFC8530
00007d3d13be3635  call rax
00007d3d13be3637  movaps xmm1, [rsp]
00007d3d13be363b  add rsp, 0x30
00007d3d13be363f  vmovaps xmm0, [rsp]
00007d3d13be3644  vmovaps xmm2, [rsp+0x10]
00007d3d13be364a  vmovaps xmm3, [rsp+0x20]
00007d3d13be3650  vmovaps xmm4, [rsp+0x30]
00007d3d13be3656  vmovaps xmm5, [rsp+0x40]
00007d3d13be365c  vmovaps xmm6, [rsp+0x50]
00007d3d13be3662  vmovaps xmm7, [rsp+0x60]
00007d3d13be3668  vmovaps xmm8, [rsp+0x70]
00007d3d13be366e  vmovaps xmm9, [rsp+0x80]
00007d3d13be3677  vmovaps xmm10, [rsp+0x90]
00007d3d13be3680  vmovaps xmm11, [rsp+0xA0]
00007d3d13be3689  vmovaps xmm12, [rsp+0xB0]
00007d3d13be3692  vmovaps xmm13, [rsp+0xC0]
00007d3d13be369b  vmovaps xmm14, [rsp+0xD0]
00007d3d13be36a4  vmovaps xmm15, [rsp+0xE0]
00007d3d13be36ad  add rsp, 0xF0
00007d3d13be36b4  pop r11
00007d3d13be36b6  pop r10
00007d3d13be36b8  pop r9
00007d3d13be36ba  pop r8
00007d3d13be36bc  pop rsi
00007d3d13be36bd  pop rdi
00007d3d13be36be  pop rdx
00007d3d13be36bf  pop rcx
00007d3d13be36c0  pop rax
00007d3d13be36c1  add rsp, 0x08
00007d3d13be36c5  jmp 0x00007D3D13BDF7AD
00007d3d13be36ca  sub rsp, 0x08
00007d3d13be36ce  push rax
00007d3d13be36cf  push rcx
00007d3d13be36d0  push rdx
00007d3d13be36d1  push rdi
00007d3d13be36d2  push rsi
00007d3d13be36d3  push r8
00007d3d13be36d5  push r9
00007d3d13be36d7  push r10
00007d3d13be36d9  push r11
00007d3d13be36db  sub rsp, 0xF0
00007d3d13be36e2  vmovaps [rsp], xmm0
00007d3d13be36e7  vmovaps [rsp+0x10], xmm1
00007d3d13be36ed  vmovaps [rsp+0x20], xmm2
00007d3d13be36f3  vmovaps [rsp+0x30], xmm3
00007d3d13be36f9  vmovaps [rsp+0x40], xmm4
00007d3d13be36ff  vmovaps [rsp+0x50], xmm5
00007d3d13be3705  vmovaps [rsp+0x60], xmm6
00007d3d13be370b  vmovaps [rsp+0x70], xmm7
00007d3d13be3711  vmovaps [rsp+0x80], xmm8
00007d3d13be371a  vmovaps [rsp+0x90], xmm9
00007d3d13be3723  vmovaps [rsp+0xA0], xmm10
00007d3d13be372c  vmovaps [rsp+0xB0], xmm11
00007d3d13be3735  vmovaps [rsp+0xC0], xmm13
00007d3d13be373e  vmovaps [rsp+0xD0], xmm14
00007d3d13be3747  vmovaps [rsp+0xE0], xmm15
00007d3d13be3750  sub rsp, 0x30
00007d3d13be3754  movaps [rsp], xmm12
00007d3d13be3759  movaps [rsp+0x10], xmm7
00007d3d13be375e  movaps [rsp+0x20], xmm13
00007d3d13be3764  lea rdi, [rsp]
00007d3d13be3768  mov esi, 0x00
00007d3d13be376d  mov rax, 0x5741DAFC8530
00007d3d13be3777  call rax
00007d3d13be3779  movaps xmm12, [rsp]
00007d3d13be377e  add rsp, 0x30
00007d3d13be3782  vmovaps xmm0, [rsp]
00007d3d13be3787  vmovaps xmm1, [rsp+0x10]
00007d3d13be378d  vmovaps xmm2, [rsp+0x20]
00007d3d13be3793  vmovaps xmm3, [rsp+0x30]
00007d3d13be3799  vmovaps xmm4, [rsp+0x40]
00007d3d13be379f  vmovaps xmm5, [rsp+0x50]
00007d3d13be37a5  vmovaps xmm6, [rsp+0x60]
00007d3d13be37ab  vmovaps xmm7, [rsp+0x70]
00007d3d13be37b1  vmovaps xmm8, [rsp+0x80]
00007d3d13be37ba  vmovaps xmm9, [rsp+0x90]
00007d3d13be37c3  vmovaps xmm10, [rsp+0xA0]
00007d3d13be37cc  vmovaps xmm11, [rsp+0xB0]
00007d3d13be37d5  vmovaps xmm13, [rsp+0xC0]
00007d3d13be37de  vmovaps xmm14, [rsp+0xD0]
00007d3d13be37e7  vmovaps xmm15, [rsp+0xE0]
00007d3d13be37f0  add rsp, 0xF0
00007d3d13be37f7  pop r11
00007d3d13be37f9  pop r10
00007d3d13be37fb  pop r9
00007d3d13be37fd  pop r8
00007d3d13be37ff  pop rsi
00007d3d13be3800  pop rdi
00007d3d13be3801  pop rdx
00007d3d13be3802  pop rcx
00007d3d13be3803  pop rax
00007d3d13be3804  add rsp, 0x08
00007d3d13be3808  jmp 0x00007D3D13BDF7D4
00007d3d13be380d  sub rsp, 0x08
00007d3d13be3811  push rax
00007d3d13be3812  push rcx
00007d3d13be3813  push rdx
00007d3d13be3814  push rdi
00007d3d13be3815  push rsi
00007d3d13be3816  push r8
00007d3d13be3818  push r9
00007d3d13be381a  push r10
00007d3d13be381c  push r11
00007d3d13be381e  sub rsp, 0xF0
00007d3d13be3825  vmovaps [rsp], xmm0
00007d3d13be382a  vmovaps [rsp+0x10], xmm1
00007d3d13be3830  vmovaps [rsp+0x20], xmm2
00007d3d13be3836  vmovaps [rsp+0x30], xmm3
00007d3d13be383c  vmovaps [rsp+0x40], xmm4
00007d3d13be3842  vmovaps [rsp+0x50], xmm5
00007d3d13be3848  vmovaps [rsp+0x60], xmm6
00007d3d13be384e  vmovaps [rsp+0x70], xmm7
00007d3d13be3854  vmovaps [rsp+0x80], xmm8
00007d3d13be385d  vmovaps [rsp+0x90], xmm9
00007d3d13be3866  vmovaps [rsp+0xA0], xmm10
00007d3d13be386f  vmovaps [rsp+0xB0], xmm11
00007d3d13be3878  vmovaps [rsp+0xC0], xmm12
00007d3d13be3881  vmovaps [rsp+0xD0], xmm14
00007d3d13be388a  vmovaps [rsp+0xE0], xmm15
00007d3d13be3893  sub rsp, 0x30
00007d3d13be3897  movaps [rsp], xmm13
00007d3d13be389c  movaps [rsp+0x10], xmm15
00007d3d13be38a2  movaps [rsp+0x20], xmm8
00007d3d13be38a8  lea rdi, [rsp]
00007d3d13be38ac  mov esi, 0x00
00007d3d13be38b1  mov rax, 0x5741DAFC8530
00007d3d13be38bb  call rax
00007d3d13be38bd  movaps xmm13, [rsp]
00007d3d13be38c2  add rsp, 0x30
00007d3d13be38c6  vmovaps xmm0, [rsp]
00007d3d13be38cb  vmovaps xmm1, [rsp+0x10]
00007d3d13be38d1  vmovaps xmm2, [rsp+0x20]
00007d3d13be38d7  vmovaps xmm3, [rsp+0x30]
00007d3d13be38dd  vmovaps xmm4, [rsp+0x40]
00007d3d13be38e3  vmovaps xmm5, [rsp+0x50]
00007d3d13be38e9  vmovaps xmm6, [rsp+0x60]
00007d3d13be38ef  vmovaps xmm7, [rsp+0x70]
00007d3d13be38f5  vmovaps xmm8, [rsp+0x80]
00007d3d13be38fe  vmovaps xmm9, [rsp+0x90]
00007d3d13be3907  vmovaps xmm10, [rsp+0xA0]
00007d3d13be3910  vmovaps xmm11, [rsp+0xB0]
00007d3d13be3919  vmovaps xmm12, [rsp+0xC0]
00007d3d13be3922  vmovaps xmm14, [rsp+0xD0]
00007d3d13be392b  vmovaps xmm15, [rsp+0xE0]
00007d3d13be3934  add rsp, 0xF0
00007d3d13be393b  pop r11
00007d3d13be393d  pop r10
00007d3d13be393f  pop r9
00007d3d13be3941  pop r8
00007d3d13be3943  pop rsi
00007d3d13be3944  pop rdi
00007d3d13be3945  pop rdx
00007d3d13be3946  pop rcx
00007d3d13be3947  pop rax
00007d3d13be3948  add rsp, 0x08
00007d3d13be394c  jmp 0x00007D3D13BDF7EF
00007d3d13be3951  sub rsp, 0x08
00007d3d13be3955  push rax
00007d3d13be3956  push rcx
00007d3d13be3957  push rdx
00007d3d13be3958  push rdi
00007d3d13be3959  push rsi
00007d3d13be395a  push r8
00007d3d13be395c  push r9
00007d3d13be395e  push r10
00007d3d13be3960  push r11
00007d3d13be3962  sub rsp, 0xF0
00007d3d13be3969  vmovaps [rsp], xmm0
00007d3d13be396e  vmovaps [rsp+0x10], xmm1
00007d3d13be3974  vmovaps [rsp+0x20], xmm2
00007d3d13be397a  vmovaps [rsp+0x30], xmm3
00007d3d13be3980  vmovaps [rsp+0x40], xmm4
00007d3d13be3986  vmovaps [rsp+0x50], xmm5
00007d3d13be398c  vmovaps [rsp+0x60], xmm6
00007d3d13be3992  vmovaps [rsp+0x70], xmm7
00007d3d13be3998  vmovaps [rsp+0x80], xmm9
00007d3d13be39a1  vmovaps [rsp+0x90], xmm10
00007d3d13be39aa  vmovaps [rsp+0xA0], xmm11
00007d3d13be39b3  vmovaps [rsp+0xB0], xmm12
00007d3d13be39bc  vmovaps [rsp+0xC0], xmm13
00007d3d13be39c5  vmovaps [rsp+0xD0], xmm14
00007d3d13be39ce  vmovaps [rsp+0xE0], xmm15
00007d3d13be39d7  sub rsp, 0x30
00007d3d13be39db  movaps [rsp], xmm8
00007d3d13be39e0  movaps [rsp+0x10], xmm15
00007d3d13be39e6  movaps [rsp+0x20], xmm9
00007d3d13be39ec  lea rdi, [rsp]
00007d3d13be39f0  mov esi, 0x00
00007d3d13be39f5  mov rax, 0x5741DAFC8530
00007d3d13be39ff  call rax
00007d3d13be3a01  movaps xmm8, [rsp]
00007d3d13be3a06  add rsp, 0x30
00007d3d13be3a0a  vmovaps xmm0, [rsp]
00007d3d13be3a0f  vmovaps xmm1, [rsp+0x10]
00007d3d13be3a15  vmovaps xmm2, [rsp+0x20]
00007d3d13be3a1b  vmovaps xmm3, [rsp+0x30]
00007d3d13be3a21  vmovaps xmm4, [rsp+0x40]
00007d3d13be3a27  vmovaps xmm5, [rsp+0x50]
00007d3d13be3a2d  vmovaps xmm6, [rsp+0x60]
00007d3d13be3a33  vmovaps xmm7, [rsp+0x70]
00007d3d13be3a39  vmovaps xmm9, [rsp+0x80]
00007d3d13be3a42  vmovaps xmm10, [rsp+0x90]
00007d3d13be3a4b  vmovaps xmm11, [rsp+0xA0]
00007d3d13be3a54  vmovaps xmm12, [rsp+0xB0]
00007d3d13be3a5d  vmovaps xmm13, [rsp+0xC0]
00007d3d13be3a66  vmovaps xmm14, [rsp+0xD0]
00007d3d13be3a6f  vmovaps xmm15, [rsp+0xE0]
00007d3d13be3a78  add rsp, 0xF0
00007d3d13be3a7f  pop r11
00007d3d13be3a81  pop r10
00007d3d13be3a83  pop r9
00007d3d13be3a85  pop r8
00007d3d13be3a87  pop rsi
00007d3d13be3a88  pop rdi
00007d3d13be3a89  pop rdx
00007d3d13be3a8a  pop rcx
00007d3d13be3a8b  pop rax
00007d3d13be3a8c  add rsp, 0x08
00007d3d13be3a90  jmp 0x00007D3D13BDF81D
00007d3d13be3a95  sub rsp, 0x08
00007d3d13be3a99  push rax
00007d3d13be3a9a  push rcx
00007d3d13be3a9b  push rdx
00007d3d13be3a9c  push rdi
00007d3d13be3a9d  push rsi
00007d3d13be3a9e  push r8
00007d3d13be3aa0  push r9
00007d3d13be3aa2  push r10
00007d3d13be3aa4  push r11
00007d3d13be3aa6  sub rsp, 0xF0
00007d3d13be3aad  vmovaps [rsp], xmm0
00007d3d13be3ab2  vmovaps [rsp+0x10], xmm1
00007d3d13be3ab8  vmovaps [rsp+0x20], xmm2
00007d3d13be3abe  vmovaps [rsp+0x30], xmm3
00007d3d13be3ac4  vmovaps [rsp+0x40], xmm4
00007d3d13be3aca  vmovaps [rsp+0x50], xmm5
00007d3d13be3ad0  vmovaps [rsp+0x60], xmm6
00007d3d13be3ad6  vmovaps [rsp+0x70], xmm7
00007d3d13be3adc  vmovaps [rsp+0x80], xmm8
00007d3d13be3ae5  vmovaps [rsp+0x90], xmm9
00007d3d13be3aee  vmovaps [rsp+0xA0], xmm10
00007d3d13be3af7  vmovaps [rsp+0xB0], xmm11
00007d3d13be3b00  vmovaps [rsp+0xC0], xmm12
00007d3d13be3b09  vmovaps [rsp+0xD0], xmm13
00007d3d13be3b12  vmovaps [rsp+0xE0], xmm14
00007d3d13be3b1b  sub rsp, 0x30
00007d3d13be3b1f  movaps [rsp], xmm15
00007d3d13be3b24  movaps [rsp+0x10], xmm11
00007d3d13be3b2a  movaps [rsp+0x20], xmm6
00007d3d13be3b2f  lea rdi, [rsp]
00007d3d13be3b33  mov esi, 0x00
00007d3d13be3b38  mov rax, 0x5741DAFC8530
00007d3d13be3b42  call rax
00007d3d13be3b44  movaps xmm15, [rsp]
00007d3d13be3b49  add rsp, 0x30
00007d3d13be3b4d  vmovaps xmm0, [rsp]
00007d3d13be3b52  vmovaps xmm1, [rsp+0x10]
00007d3d13be3b58  vmovaps xmm2, [rsp+0x20]
00007d3d13be3b5e  vmovaps xmm3, [rsp+0x30]
00007d3d13be3b64  vmovaps xmm4, [rsp+0x40]
00007d3d13be3b6a  vmovaps xmm5, [rsp+0x50]
00007d3d13be3b70  vmovaps xmm6, [rsp+0x60]
00007d3d13be3b76  vmovaps xmm7, [rsp+0x70]
00007d3d13be3b7c  vmovaps xmm8, [rsp+0x80]
00007d3d13be3b85  vmovaps xmm9, [rsp+0x90]
00007d3d13be3b8e  vmovaps xmm10, [rsp+0xA0]
00007d3d13be3b97  vmovaps xmm11, [rsp+0xB0]
00007d3d13be3ba0  vmovaps xmm12, [rsp+0xC0]
00007d3d13be3ba9  vmovaps xmm13, [rsp+0xD0]
00007d3d13be3bb2  vmovaps xmm14, [rsp+0xE0]
00007d3d13be3bbb  add rsp, 0xF0
00007d3d13be3bc2  pop r11
00007d3d13be3bc4  pop r10
00007d3d13be3bc6  pop r9
00007d3d13be3bc8  pop r8
00007d3d13be3bca  pop rsi
00007d3d13be3bcb  pop rdi
00007d3d13be3bcc  pop rdx
00007d3d13be3bcd  pop rcx
00007d3d13be3bce  pop rax
00007d3d13be3bcf  add rsp, 0x08
00007d3d13be3bd3  jmp 0x00007D3D13BDF838
00007d3d13be3bd8  sub rsp, 0x08
00007d3d13be3bdc  push rax
00007d3d13be3bdd  push rcx
00007d3d13be3bde  push rdx
00007d3d13be3bdf  push rdi
00007d3d13be3be0  push rsi
00007d3d13be3be1  push r8
00007d3d13be3be3  push r9
00007d3d13be3be5  push r10
00007d3d13be3be7  push r11
00007d3d13be3be9  sub rsp, 0xF0
00007d3d13be3bf0  vmovaps [rsp], xmm0
00007d3d13be3bf5  vmovaps [rsp+0x10], xmm1
00007d3d13be3bfb  vmovaps [rsp+0x20], xmm2
00007d3d13be3c01  vmovaps [rsp+0x30], xmm3
00007d3d13be3c07  vmovaps [rsp+0x40], xmm4
00007d3d13be3c0d  vmovaps [rsp+0x50], xmm5
00007d3d13be3c13  vmovaps [rsp+0x60], xmm6
00007d3d13be3c19  vmovaps [rsp+0x70], xmm8
00007d3d13be3c1f  vmovaps [rsp+0x80], xmm9
00007d3d13be3c28  vmovaps [rsp+0x90], xmm10
00007d3d13be3c31  vmovaps [rsp+0xA0], xmm11
00007d3d13be3c3a  vmovaps [rsp+0xB0], xmm12
00007d3d13be3c43  vmovaps [rsp+0xC0], xmm13
00007d3d13be3c4c  vmovaps [rsp+0xD0], xmm14
00007d3d13be3c55  vmovaps [rsp+0xE0], xmm15
00007d3d13be3c5e  sub rsp, 0x30
00007d3d13be3c62  movaps [rsp], xmm7
00007d3d13be3c66  movaps [rsp+0x10], xmm11
00007d3d13be3c6c  movaps [rsp+0x20], xmm9
00007d3d13be3c72  lea rdi, [rsp]
00007d3d13be3c76  mov esi, 0x00
00007d3d13be3c7b  mov rax, 0x5741DAFC8530
00007d3d13be3c85  call rax
00007d3d13be3c87  movaps xmm7, [rsp]
00007d3d13be3c8b  add rsp, 0x30
00007d3d13be3c8f  vmovaps xmm0, [rsp]
00007d3d13be3c94  vmovaps xmm1, [rsp+0x10]
00007d3d13be3c9a  vmovaps xmm2, [rsp+0x20]
00007d3d13be3ca0  vmovaps xmm3, [rsp+0x30]
00007d3d13be3ca6  vmovaps xmm4, [rsp+0x40]
00007d3d13be3cac  vmovaps xmm5, [rsp+0x50]
00007d3d13be3cb2  vmovaps xmm6, [rsp+0x60]
00007d3d13be3cb8  vmovaps xmm8, [rsp+0x70]
00007d3d13be3cbe  vmovaps xmm9, [rsp+0x80]
00007d3d13be3cc7  vmovaps xmm10, [rsp+0x90]
00007d3d13be3cd0  vmovaps xmm11, [rsp+0xA0]
00007d3d13be3cd9  vmovaps xmm12, [rsp+0xB0]
00007d3d13be3ce2  vmovaps xmm13, [rsp+0xC0]
00007d3d13be3ceb  vmovaps xmm14, [rsp+0xD0]
00007d3d13be3cf4  vmovaps xmm15, [rsp+0xE0]
00007d3d13be3cfd  add rsp, 0xF0
00007d3d13be3d04  pop r11
00007d3d13be3d06  pop r10
00007d3d13be3d08  pop r9
00007d3d13be3d0a  pop r8
00007d3d13be3d0c  pop rsi
00007d3d13be3d0d  pop rdi
00007d3d13be3d0e  pop rdx
00007d3d13be3d0f  pop rcx
00007d3d13be3d10  pop rax
00007d3d13be3d11  add rsp, 0x08
00007d3d13be3d15  jmp 0x00007D3D13BDF865
00007d3d13be3d1a  sub rsp, 0x08
00007d3d13be3d1e  push rax
00007d3d13be3d1f  push rcx
00007d3d13be3d20  push rdx
00007d3d13be3d21  push rdi
00007d3d13be3d22  push rsi
00007d3d13be3d23  push r8
00007d3d13be3d25  push r9
00007d3d13be3d27  push r10
00007d3d13be3d29  push r11
00007d3d13be3d2b  sub rsp, 0xF0
00007d3d13be3d32  vmovaps [rsp], xmm0
00007d3d13be3d37  vmovaps [rsp+0x10], xmm1
00007d3d13be3d3d  vmovaps [rsp+0x20], xmm2
00007d3d13be3d43  vmovaps [rsp+0x30], xmm3
00007d3d13be3d49  vmovaps [rsp+0x40], xmm4
00007d3d13be3d4f  vmovaps [rsp+0x50], xmm5
00007d3d13be3d55  vmovaps [rsp+0x60], xmm6
00007d3d13be3d5b  vmovaps [rsp+0x70], xmm7
00007d3d13be3d61  vmovaps [rsp+0x80], xmm8
00007d3d13be3d6a  vmovaps [rsp+0x90], xmm9
00007d3d13be3d73  vmovaps [rsp+0xA0], xmm10
00007d3d13be3d7c  vmovaps [rsp+0xB0], xmm12
00007d3d13be3d85  vmovaps [rsp+0xC0], xmm13
00007d3d13be3d8e  vmovaps [rsp+0xD0], xmm14
00007d3d13be3d97  vmovaps [rsp+0xE0], xmm15
00007d3d13be3da0  sub rsp, 0x30
00007d3d13be3da4  movaps [rsp], xmm11
00007d3d13be3da9  movaps [rsp+0x10], xmm10
00007d3d13be3daf  movaps [rsp+0x20], xmm14
00007d3d13be3db5  lea rdi, [rsp]
00007d3d13be3db9  mov esi, 0x00
00007d3d13be3dbe  mov rax, 0x5741DAFC8530
00007d3d13be3dc8  call rax
00007d3d13be3dca  movaps xmm11, [rsp]
00007d3d13be3dcf  add rsp, 0x30
00007d3d13be3dd3  vmovaps xmm0, [rsp]
00007d3d13be3dd8  vmovaps xmm1, [rsp+0x10]
00007d3d13be3dde  vmovaps xmm2, [rsp+0x20]
00007d3d13be3de4  vmovaps xmm3, [rsp+0x30]
00007d3d13be3dea  vmovaps xmm4, [rsp+0x40]
00007d3d13be3df0  vmovaps xmm5, [rsp+0x50]
00007d3d13be3df6  vmovaps xmm6, [rsp+0x60]
00007d3d13be3dfc  vmovaps xmm7, [rsp+0x70]
00007d3d13be3e02  vmovaps xmm8, [rsp+0x80]
00007d3d13be3e0b  vmovaps xmm9, [rsp+0x90]
00007d3d13be3e14  vmovaps xmm10, [rsp+0xA0]
00007d3d13be3e1d  vmovaps xmm12, [rsp+0xB0]
00007d3d13be3e26  vmovaps xmm13, [rsp+0xC0]
00007d3d13be3e2f  vmovaps xmm14, [rsp+0xD0]
00007d3d13be3e38  vmovaps xmm15, [rsp+0xE0]
00007d3d13be3e41  add rsp, 0xF0
00007d3d13be3e48  pop r11
00007d3d13be3e4a  pop r10
00007d3d13be3e4c  pop r9
00007d3d13be3e4e  pop r8
00007d3d13be3e50  pop rsi
00007d3d13be3e51  pop rdi
00007d3d13be3e52  pop rdx
00007d3d13be3e53  pop rcx
00007d3d13be3e54  pop rax
00007d3d13be3e55  add rsp, 0x08
00007d3d13be3e59  jmp 0x00007D3D13BDF880
00007d3d13be3e5e  call 0x00007D3D13AC33A0
00007d3d13be3e63  jmp 0x00007D3D13BDF88A
00007d3d13be3e68  sub rsp, 0x08
00007d3d13be3e6c  push rax
00007d3d13be3e6d  push rcx
00007d3d13be3e6e  push rdx
00007d3d13be3e6f  push rdi
00007d3d13be3e70  push rsi
00007d3d13be3e71  push r8
00007d3d13be3e73  push r9
00007d3d13be3e75  push r10
00007d3d13be3e77  push r11
00007d3d13be3e79  sub rsp, 0xF0
00007d3d13be3e80  vmovaps [rsp], xmm0
00007d3d13be3e85  vmovaps [rsp+0x10], xmm1
00007d3d13be3e8b  vmovaps [rsp+0x20], xmm2
00007d3d13be3e91  vmovaps [rsp+0x30], xmm3
00007d3d13be3e97  vmovaps [rsp+0x40], xmm4
00007d3d13be3e9d  vmovaps [rsp+0x50], xmm5
00007d3d13be3ea3  vmovaps [rsp+0x60], xmm6
00007d3d13be3ea9  vmovaps [rsp+0x70], xmm7
00007d3d13be3eaf  vmovaps [rsp+0x80], xmm8
00007d3d13be3eb8  vmovaps [rsp+0x90], xmm9
00007d3d13be3ec1  vmovaps [rsp+0xA0], xmm11
00007d3d13be3eca  vmovaps [rsp+0xB0], xmm12
00007d3d13be3ed3  vmovaps [rsp+0xC0], xmm13
00007d3d13be3edc  vmovaps [rsp+0xD0], xmm14
00007d3d13be3ee5  vmovaps [rsp+0xE0], xmm15
00007d3d13be3eee  sub rsp, 0x30
00007d3d13be3ef2  movaps [rsp], xmm10
00007d3d13be3ef7  movaps [rsp+0x10], xmm1
00007d3d13be3efc  movaps [rsp+0x20], xmm12
00007d3d13be3f02  lea rdi, [rsp]
00007d3d13be3f06  mov esi, 0x00
00007d3d13be3f0b  mov rax, 0x5741DAFC8530
00007d3d13be3f15  call rax
00007d3d13be3f17  movaps xmm10, [rsp]
00007d3d13be3f1c  add rsp, 0x30
00007d3d13be3f20  vmovaps xmm0, [rsp]
00007d3d13be3f25  vmovaps xmm1, [rsp+0x10]
00007d3d13be3f2b  vmovaps xmm2, [rsp+0x20]
00007d3d13be3f31  vmovaps xmm3, [rsp+0x30]
00007d3d13be3f37  vmovaps xmm4, [rsp+0x40]
00007d3d13be3f3d  vmovaps xmm5, [rsp+0x50]
00007d3d13be3f43  vmovaps xmm6, [rsp+0x60]
00007d3d13be3f49  vmovaps xmm7, [rsp+0x70]
00007d3d13be3f4f  vmovaps xmm8, [rsp+0x80]
00007d3d13be3f58  vmovaps xmm9, [rsp+0x90]
00007d3d13be3f61  vmovaps xmm11, [rsp+0xA0]
00007d3d13be3f6a  vmovaps xmm12, [rsp+0xB0]
00007d3d13be3f73  vmovaps xmm13, [rsp+0xC0]
00007d3d13be3f7c  vmovaps xmm14, [rsp+0xD0]
00007d3d13be3f85  vmovaps xmm15, [rsp+0xE0]
00007d3d13be3f8e  add rsp, 0xF0
00007d3d13be3f95  pop r11
00007d3d13be3f97  pop r10
00007d3d13be3f99  pop r9
00007d3d13be3f9b  pop r8
00007d3d13be3f9d  pop rsi
00007d3d13be3f9e  pop rdi
00007d3d13be3f9f  pop rdx
00007d3d13be3fa0  pop rcx
00007d3d13be3fa1  pop rax
00007d3d13be3fa2  add rsp, 0x08
00007d3d13be3fa6  jmp 0x00007D3D13BDF8AD
00007d3d13be3fab  sub rsp, 0x08
00007d3d13be3faf  push rax
00007d3d13be3fb0  push rcx
00007d3d13be3fb1  push rdx
00007d3d13be3fb2  push rdi
00007d3d13be3fb3  push rsi
00007d3d13be3fb4  push r8
00007d3d13be3fb6  push r9
00007d3d13be3fb8  push r10
00007d3d13be3fba  push r11
00007d3d13be3fbc  sub rsp, 0xF0
00007d3d13be3fc3  vmovaps [rsp], xmm0
00007d3d13be3fc8  vmovaps [rsp+0x10], xmm1
00007d3d13be3fce  vmovaps [rsp+0x20], xmm2
00007d3d13be3fd4  vmovaps [rsp+0x30], xmm3
00007d3d13be3fda  vmovaps [rsp+0x40], xmm4
00007d3d13be3fe0  vmovaps [rsp+0x50], xmm5
00007d3d13be3fe6  vmovaps [rsp+0x60], xmm6
00007d3d13be3fec  vmovaps [rsp+0x70], xmm7
00007d3d13be3ff2  vmovaps [rsp+0x80], xmm8
00007d3d13be3ffb  vmovaps [rsp+0x90], xmm9
00007d3d13be4004  vmovaps [rsp+0xA0], xmm10
00007d3d13be400d  vmovaps [rsp+0xB0], xmm11
00007d3d13be4016  vmovaps [rsp+0xC0], xmm13
00007d3d13be401f  vmovaps [rsp+0xD0], xmm14
00007d3d13be4028  vmovaps [rsp+0xE0], xmm15
00007d3d13be4031  sub rsp, 0x30
00007d3d13be4035  movaps [rsp], xmm12
00007d3d13be403a  movaps [rsp+0x10], xmm14
00007d3d13be4040  movaps [rsp+0x20], xmm1
00007d3d13be4045  lea rdi, [rsp]
00007d3d13be4049  mov esi, 0x00
00007d3d13be404e  mov rax, 0x5741DAFC8530
00007d3d13be4058  call rax
00007d3d13be405a  movaps xmm12, [rsp]
00007d3d13be405f  add rsp, 0x30
00007d3d13be4063  vmovaps xmm0, [rsp]
00007d3d13be4068  vmovaps xmm1, [rsp+0x10]
00007d3d13be406e  vmovaps xmm2, [rsp+0x20]
00007d3d13be4074  vmovaps xmm3, [rsp+0x30]
00007d3d13be407a  vmovaps xmm4, [rsp+0x40]
00007d3d13be4080  vmovaps xmm5, [rsp+0x50]
00007d3d13be4086  vmovaps xmm6, [rsp+0x60]
00007d3d13be408c  vmovaps xmm7, [rsp+0x70]
00007d3d13be4092  vmovaps xmm8, [rsp+0x80]
00007d3d13be409b  vmovaps xmm9, [rsp+0x90]
00007d3d13be40a4  vmovaps xmm10, [rsp+0xA0]
00007d3d13be40ad  vmovaps xmm11, [rsp+0xB0]
00007d3d13be40b6  vmovaps xmm13, [rsp+0xC0]
00007d3d13be40bf  vmovaps xmm14, [rsp+0xD0]
00007d3d13be40c8  vmovaps xmm15, [rsp+0xE0]
00007d3d13be40d1  add rsp, 0xF0
00007d3d13be40d8  pop r11
00007d3d13be40da  pop r10
00007d3d13be40dc  pop r9
00007d3d13be40de  pop r8
00007d3d13be40e0  pop rsi
00007d3d13be40e1  pop rdi
00007d3d13be40e2  pop rdx
00007d3d13be40e3  pop rcx
00007d3d13be40e4  pop rax
00007d3d13be40e5  add rsp, 0x08
00007d3d13be40e9  jmp 0x00007D3D13BDF8DC
00007d3d13be40ee  sub rsp, 0x08
00007d3d13be40f2  push rax
00007d3d13be40f3  push rcx
00007d3d13be40f4  push rdx
00007d3d13be40f5  push rdi
00007d3d13be40f6  push rsi
00007d3d13be40f7  push r8
00007d3d13be40f9  push r9
00007d3d13be40fb  push r10
00007d3d13be40fd  push r11
00007d3d13be40ff  sub rsp, 0xF0
00007d3d13be4106  vmovaps [rsp], xmm0
00007d3d13be410b  vmovaps [rsp+0x10], xmm1
00007d3d13be4111  vmovaps [rsp+0x20], xmm2
00007d3d13be4117  vmovaps [rsp+0x30], xmm3
00007d3d13be411d  vmovaps [rsp+0x40], xmm4
00007d3d13be4123  vmovaps [rsp+0x50], xmm5
00007d3d13be4129  vmovaps [rsp+0x60], xmm6
00007d3d13be412f  vmovaps [rsp+0x70], xmm7
00007d3d13be4135  vmovaps [rsp+0x80], xmm8
00007d3d13be413e  vmovaps [rsp+0x90], xmm9
00007d3d13be4147  vmovaps [rsp+0xA0], xmm10
00007d3d13be4150  vmovaps [rsp+0xB0], xmm11
00007d3d13be4159  vmovaps [rsp+0xC0], xmm12
00007d3d13be4162  vmovaps [rsp+0xD0], xmm13
00007d3d13be416b  vmovaps [rsp+0xE0], xmm15
00007d3d13be4174  sub rsp, 0x30
00007d3d13be4178  movaps [rsp], xmm14
00007d3d13be417d  movaps [rsp+0x10], xmm9
00007d3d13be4183  movaps [rsp+0x20], xmm1
00007d3d13be4188  lea rdi, [rsp]
00007d3d13be418c  mov esi, 0x00
00007d3d13be4191  mov rax, 0x5741DAFC8530
00007d3d13be419b  call rax
00007d3d13be419d  movaps xmm14, [rsp]
00007d3d13be41a2  add rsp, 0x30
00007d3d13be41a6  vmovaps xmm0, [rsp]
00007d3d13be41ab  vmovaps xmm1, [rsp+0x10]
00007d3d13be41b1  vmovaps xmm2, [rsp+0x20]
00007d3d13be41b7  vmovaps xmm3, [rsp+0x30]
00007d3d13be41bd  vmovaps xmm4, [rsp+0x40]
00007d3d13be41c3  vmovaps xmm5, [rsp+0x50]
00007d3d13be41c9  vmovaps xmm6, [rsp+0x60]
00007d3d13be41cf  vmovaps xmm7, [rsp+0x70]
00007d3d13be41d5  vmovaps xmm8, [rsp+0x80]
00007d3d13be41de  vmovaps xmm9, [rsp+0x90]
00007d3d13be41e7  vmovaps xmm10, [rsp+0xA0]
00007d3d13be41f0  vmovaps xmm11, [rsp+0xB0]
00007d3d13be41f9  vmovaps xmm12, [rsp+0xC0]
00007d3d13be4202  vmovaps xmm13, [rsp+0xD0]
00007d3d13be420b  vmovaps xmm15, [rsp+0xE0]
00007d3d13be4214  add rsp, 0xF0
00007d3d13be421b  pop r11
00007d3d13be421d  pop r10
00007d3d13be421f  pop r9
00007d3d13be4221  pop r8
00007d3d13be4223  pop rsi
00007d3d13be4224  pop rdi
00007d3d13be4225  pop rdx
00007d3d13be4226  pop rcx
00007d3d13be4227  pop rax
00007d3d13be4228  add rsp, 0x08
00007d3d13be422c  jmp 0x00007D3D13BDF90B
00007d3d13be4231  sub rsp, 0x08
00007d3d13be4235  push rax
00007d3d13be4236  push rcx
00007d3d13be4237  push rdx
00007d3d13be4238  push rdi
00007d3d13be4239  push rsi
00007d3d13be423a  push r8
00007d3d13be423c  push r9
00007d3d13be423e  push r10
00007d3d13be4240  push r11
00007d3d13be4242  sub rsp, 0xF0
00007d3d13be4249  vmovaps [rsp], xmm0
00007d3d13be424e  vmovaps [rsp+0x10], xmm2
00007d3d13be4254  vmovaps [rsp+0x20], xmm3
00007d3d13be425a  vmovaps [rsp+0x30], xmm4
00007d3d13be4260  vmovaps [rsp+0x40], xmm5
00007d3d13be4266  vmovaps [rsp+0x50], xmm6
00007d3d13be426c  vmovaps [rsp+0x60], xmm7
00007d3d13be4272  vmovaps [rsp+0x70], xmm8
00007d3d13be4278  vmovaps [rsp+0x80], xmm9
00007d3d13be4281  vmovaps [rsp+0x90], xmm10
00007d3d13be428a  vmovaps [rsp+0xA0], xmm11
00007d3d13be4293  vmovaps [rsp+0xB0], xmm12
00007d3d13be429c  vmovaps [rsp+0xC0], xmm13
00007d3d13be42a5  vmovaps [rsp+0xD0], xmm14
00007d3d13be42ae  vmovaps [rsp+0xE0], xmm15
00007d3d13be42b7  sub rsp, 0x30
00007d3d13be42bb  movaps [rsp], xmm1
00007d3d13be42bf  movaps [rsp+0x10], xmm13
00007d3d13be42c5  movaps [rsp+0x20], xmm8
00007d3d13be42cb  lea rdi, [rsp]
00007d3d13be42cf  mov esi, 0x00
00007d3d13be42d4  mov rax, 0x5741DAFC8530
00007d3d13be42de  call rax
00007d3d13be42e0  movaps xmm1, [rsp]
00007d3d13be42e4  add rsp, 0x30
00007d3d13be42e8  vmovaps xmm0, [rsp]
00007d3d13be42ed  vmovaps xmm2, [rsp+0x10]
00007d3d13be42f3  vmovaps xmm3, [rsp+0x20]
00007d3d13be42f9  vmovaps xmm4, [rsp+0x30]
00007d3d13be42ff  vmovaps xmm5, [rsp+0x40]
00007d3d13be4305  vmovaps xmm6, [rsp+0x50]
00007d3d13be430b  vmovaps xmm7, [rsp+0x60]
00007d3d13be4311  vmovaps xmm8, [rsp+0x70]
00007d3d13be4317  vmovaps xmm9, [rsp+0x80]
00007d3d13be4320  vmovaps xmm10, [rsp+0x90]
00007d3d13be4329  vmovaps xmm11, [rsp+0xA0]
00007d3d13be4332  vmovaps xmm12, [rsp+0xB0]
00007d3d13be433b  vmovaps xmm13, [rsp+0xC0]
00007d3d13be4344  vmovaps xmm14, [rsp+0xD0]
00007d3d13be434d  vmovaps xmm15, [rsp+0xE0]
00007d3d13be4356  add rsp, 0xF0
00007d3d13be435d  pop r11
00007d3d13be435f  pop r10
00007d3d13be4361  pop r9
00007d3d13be4363  pop r8
00007d3d13be4365  pop rsi
00007d3d13be4366  pop rdi
00007d3d13be4367  pop rdx
00007d3d13be4368  pop rcx
00007d3d13be4369  pop rax
00007d3d13be436a  add rsp, 0x08
00007d3d13be436e  jmp 0x00007D3D13BDF92D
00007d3d13be4373  call 0x00007D3D13A0C260
00007d3d13be4378  jmp 0x00007D3D13BDF93B
00007d3d13be437d  call 0x00007D3D13ABD750
00007d3d13be4382  jmp 0x00007D3D13BDF945
00007d3d13be4387  sub rsp, 0x08
00007d3d13be438b  push rax
00007d3d13be438c  push rcx
00007d3d13be438d  push rdx
00007d3d13be438e  push rdi
00007d3d13be438f  push rsi
00007d3d13be4390  push r8
00007d3d13be4392  push r9
00007d3d13be4394  push r10
00007d3d13be4396  push r11
00007d3d13be4398  sub rsp, 0xF0
00007d3d13be439f  vmovaps [rsp], xmm0
00007d3d13be43a4  vmovaps [rsp+0x10], xmm1
00007d3d13be43aa  vmovaps [rsp+0x20], xmm2
00007d3d13be43b0  vmovaps [rsp+0x30], xmm3
00007d3d13be43b6  vmovaps [rsp+0x40], xmm4
00007d3d13be43bc  vmovaps [rsp+0x50], xmm5
00007d3d13be43c2  vmovaps [rsp+0x60], xmm6
00007d3d13be43c8  vmovaps [rsp+0x70], xmm7
00007d3d13be43ce  vmovaps [rsp+0x80], xmm9
00007d3d13be43d7  vmovaps [rsp+0x90], xmm10
00007d3d13be43e0  vmovaps [rsp+0xA0], xmm11
00007d3d13be43e9  vmovaps [rsp+0xB0], xmm12
00007d3d13be43f2  vmovaps [rsp+0xC0], xmm13
00007d3d13be43fb  vmovaps [rsp+0xD0], xmm14
00007d3d13be4404  vmovaps [rsp+0xE0], xmm15
00007d3d13be440d  sub rsp, 0x30
00007d3d13be4411  movaps [rsp], xmm8
00007d3d13be4416  movaps [rsp+0x10], xmm15
00007d3d13be441c  movaps [rsp+0x20], xmm7
00007d3d13be4421  lea rdi, [rsp]
00007d3d13be4425  mov esi, 0x00
00007d3d13be442a  mov rax, 0x5741DAFC8530
00007d3d13be4434  call rax
00007d3d13be4436  movaps xmm8, [rsp]
00007d3d13be443b  add rsp, 0x30
00007d3d13be443f  vmovaps xmm0, [rsp]
00007d3d13be4444  vmovaps xmm1, [rsp+0x10]
00007d3d13be444a  vmovaps xmm2, [rsp+0x20]
00007d3d13be4450  vmovaps xmm3, [rsp+0x30]
00007d3d13be4456  vmovaps xmm4, [rsp+0x40]
00007d3d13be445c  vmovaps xmm5, [rsp+0x50]
00007d3d13be4462  vmovaps xmm6, [rsp+0x60]
00007d3d13be4468  vmovaps xmm7, [rsp+0x70]
00007d3d13be446e  vmovaps xmm9, [rsp+0x80]
00007d3d13be4477  vmovaps xmm10, [rsp+0x90]
00007d3d13be4480  vmovaps xmm11, [rsp+0xA0]
00007d3d13be4489  vmovaps xmm12, [rsp+0xB0]
00007d3d13be4492  vmovaps xmm13, [rsp+0xC0]
00007d3d13be449b  vmovaps xmm14, [rsp+0xD0]
00007d3d13be44a4  vmovaps xmm15, [rsp+0xE0]
00007d3d13be44ad  add rsp, 0xF0
00007d3d13be44b4  pop r11
00007d3d13be44b6  pop r10
00007d3d13be44b8  pop r9
00007d3d13be44ba  pop r8
00007d3d13be44bc  pop rsi
00007d3d13be44bd  pop rdi
00007d3d13be44be  pop rdx
00007d3d13be44bf  pop rcx
00007d3d13be44c0  pop rax
00007d3d13be44c1  add rsp, 0x08
00007d3d13be44c5  jmp 0x00007D3D13BDF967
00007d3d13be44ca  sub rsp, 0x08
00007d3d13be44ce  push rax
00007d3d13be44cf  push rcx
00007d3d13be44d0  push rdx
00007d3d13be44d1  push rdi
00007d3d13be44d2  push rsi
00007d3d13be44d3  push r8
00007d3d13be44d5  push r9
00007d3d13be44d7  push r10
00007d3d13be44d9  push r11
00007d3d13be44db  sub rsp, 0xF0
00007d3d13be44e2  vmovaps [rsp], xmm0
00007d3d13be44e7  vmovaps [rsp+0x10], xmm1
00007d3d13be44ed  vmovaps [rsp+0x20], xmm2
00007d3d13be44f3  vmovaps [rsp+0x30], xmm3
00007d3d13be44f9  vmovaps [rsp+0x40], xmm4
00007d3d13be44ff  vmovaps [rsp+0x50], xmm5
00007d3d13be4505  vmovaps [rsp+0x60], xmm6
00007d3d13be450b  vmovaps [rsp+0x70], xmm8
00007d3d13be4511  vmovaps [rsp+0x80], xmm9
00007d3d13be451a  vmovaps [rsp+0x90], xmm10
00007d3d13be4523  vmovaps [rsp+0xA0], xmm11
00007d3d13be452c  vmovaps [rsp+0xB0], xmm12
00007d3d13be4535  vmovaps [rsp+0xC0], xmm13
00007d3d13be453e  vmovaps [rsp+0xD0], xmm14
00007d3d13be4547  vmovaps [rsp+0xE0], xmm15
00007d3d13be4550  sub rsp, 0x30
00007d3d13be4554  movaps [rsp], xmm7
00007d3d13be4558  movaps [rsp+0x10], xmm9
00007d3d13be455e  movaps [rsp+0x20], xmm15
00007d3d13be4564  lea rdi, [rsp]
00007d3d13be4568  mov esi, 0x00
00007d3d13be456d  mov rax, 0x5741DAFC8530
00007d3d13be4577  call rax
00007d3d13be4579  movaps xmm7, [rsp]
00007d3d13be457d  add rsp, 0x30
00007d3d13be4581  vmovaps xmm0, [rsp]
00007d3d13be4586  vmovaps xmm1, [rsp+0x10]
00007d3d13be458c  vmovaps xmm2, [rsp+0x20]
00007d3d13be4592  vmovaps xmm3, [rsp+0x30]
00007d3d13be4598  vmovaps xmm4, [rsp+0x40]
00007d3d13be459e  vmovaps xmm5, [rsp+0x50]
00007d3d13be45a4  vmovaps xmm6, [rsp+0x60]
00007d3d13be45aa  vmovaps xmm8, [rsp+0x70]
00007d3d13be45b0  vmovaps xmm9, [rsp+0x80]
00007d3d13be45b9  vmovaps xmm10, [rsp+0x90]
00007d3d13be45c2  vmovaps xmm11, [rsp+0xA0]
00007d3d13be45cb  vmovaps xmm12, [rsp+0xB0]
00007d3d13be45d4  vmovaps xmm13, [rsp+0xC0]
00007d3d13be45dd  vmovaps xmm14, [rsp+0xD0]
00007d3d13be45e6  vmovaps xmm15, [rsp+0xE0]
00007d3d13be45ef  add rsp, 0xF0
00007d3d13be45f6  pop r11
00007d3d13be45f8  pop r10
00007d3d13be45fa  pop r9
00007d3d13be45fc  pop r8
00007d3d13be45fe  pop rsi
00007d3d13be45ff  pop rdi
00007d3d13be4600  pop rdx
00007d3d13be4601  pop rcx
00007d3d13be4602  pop rax
00007d3d13be4603  add rsp, 0x08
00007d3d13be4607  jmp 0x00007D3D13BDF994
00007d3d13be460c  sub rsp, 0x08
00007d3d13be4610  push rax
00007d3d13be4611  push rcx
00007d3d13be4612  push rdx
00007d3d13be4613  push rdi
00007d3d13be4614  push rsi
00007d3d13be4615  push r8
00007d3d13be4617  push r9
00007d3d13be4619  push r10
00007d3d13be461b  push r11
00007d3d13be461d  sub rsp, 0xF0
00007d3d13be4624  vmovaps [rsp], xmm0
00007d3d13be4629  vmovaps [rsp+0x10], xmm1
00007d3d13be462f  vmovaps [rsp+0x20], xmm2
00007d3d13be4635  vmovaps [rsp+0x30], xmm3
00007d3d13be463b  vmovaps [rsp+0x40], xmm4
00007d3d13be4641  vmovaps [rsp+0x50], xmm5
00007d3d13be4647  vmovaps [rsp+0x60], xmm6
00007d3d13be464d  vmovaps [rsp+0x70], xmm7
00007d3d13be4653  vmovaps [rsp+0x80], xmm8
00007d3d13be465c  vmovaps [rsp+0x90], xmm10
00007d3d13be4665  vmovaps [rsp+0xA0], xmm11
00007d3d13be466e  vmovaps [rsp+0xB0], xmm12
00007d3d13be4677  vmovaps [rsp+0xC0], xmm13
00007d3d13be4680  vmovaps [rsp+0xD0], xmm14
00007d3d13be4689  vmovaps [rsp+0xE0], xmm15
00007d3d13be4692  sub rsp, 0x30
00007d3d13be4696  movaps [rsp], xmm9
00007d3d13be469b  movaps [rsp+0x10], xmm13
00007d3d13be46a1  movaps [rsp+0x20], xmm15
00007d3d13be46a7  lea rdi, [rsp]
00007d3d13be46ab  mov esi, 0x00
00007d3d13be46b0  mov rax, 0x5741DAFC8530
00007d3d13be46ba  call rax
00007d3d13be46bc  movaps xmm9, [rsp]
00007d3d13be46c1  add rsp, 0x30
00007d3d13be46c5  vmovaps xmm0, [rsp]
00007d3d13be46ca  vmovaps xmm1, [rsp+0x10]
00007d3d13be46d0  vmovaps xmm2, [rsp+0x20]
00007d3d13be46d6  vmovaps xmm3, [rsp+0x30]
00007d3d13be46dc  vmovaps xmm4, [rsp+0x40]
00007d3d13be46e2  vmovaps xmm5, [rsp+0x50]
00007d3d13be46e8  vmovaps xmm6, [rsp+0x60]
00007d3d13be46ee  vmovaps xmm7, [rsp+0x70]
00007d3d13be46f4  vmovaps xmm8, [rsp+0x80]
00007d3d13be46fd  vmovaps xmm10, [rsp+0x90]
00007d3d13be4706  vmovaps xmm11, [rsp+0xA0]
00007d3d13be470f  vmovaps xmm12, [rsp+0xB0]
00007d3d13be4718  vmovaps xmm13, [rsp+0xC0]
00007d3d13be4721  vmovaps xmm14, [rsp+0xD0]
00007d3d13be472a  vmovaps xmm15, [rsp+0xE0]
00007d3d13be4733  add rsp, 0xF0
00007d3d13be473a  pop r11
00007d3d13be473c  pop r10
00007d3d13be473e  pop r9
00007d3d13be4740  pop r8
00007d3d13be4742  pop rsi
00007d3d13be4743  pop rdi
00007d3d13be4744  pop rdx
00007d3d13be4745  pop rcx
00007d3d13be4746  pop rax
00007d3d13be4747  add rsp, 0x08
00007d3d13be474b  jmp 0x00007D3D13BDF9C2
00007d3d13be4750  sub rsp, 0x08
00007d3d13be4754  push rax
00007d3d13be4755  push rcx
00007d3d13be4756  push rdx
00007d3d13be4757  push rdi
00007d3d13be4758  push rsi
00007d3d13be4759  push r8
00007d3d13be475b  push r9
00007d3d13be475d  push r10
00007d3d13be475f  push r11
00007d3d13be4761  sub rsp, 0xF0
00007d3d13be4768  vmovaps [rsp], xmm0
00007d3d13be476d  vmovaps [rsp+0x10], xmm1
00007d3d13be4773  vmovaps [rsp+0x20], xmm2
00007d3d13be4779  vmovaps [rsp+0x30], xmm3
00007d3d13be477f  vmovaps [rsp+0x40], xmm4
00007d3d13be4785  vmovaps [rsp+0x50], xmm5
00007d3d13be478b  vmovaps [rsp+0x60], xmm6
00007d3d13be4791  vmovaps [rsp+0x70], xmm7
00007d3d13be4797  vmovaps [rsp+0x80], xmm8
00007d3d13be47a0  vmovaps [rsp+0x90], xmm9
00007d3d13be47a9  vmovaps [rsp+0xA0], xmm10
00007d3d13be47b2  vmovaps [rsp+0xB0], xmm11
00007d3d13be47bb  vmovaps [rsp+0xC0], xmm12
00007d3d13be47c4  vmovaps [rsp+0xD0], xmm13
00007d3d13be47cd  vmovaps [rsp+0xE0], xmm14
00007d3d13be47d6  sub rsp, 0x30
00007d3d13be47da  movaps [rsp], xmm15
00007d3d13be47df  movaps [rsp+0x10], xmm11
00007d3d13be47e5  movaps [rsp+0x20], xmm12
00007d3d13be47eb  lea rdi, [rsp]
00007d3d13be47ef  mov esi, 0x00
00007d3d13be47f4  mov rax, 0x5741DAFC8530
00007d3d13be47fe  call rax
00007d3d13be4800  movaps xmm15, [rsp]
00007d3d13be4805  add rsp, 0x30
00007d3d13be4809  vmovaps xmm0, [rsp]
00007d3d13be480e  vmovaps xmm1, [rsp+0x10]
00007d3d13be4814  vmovaps xmm2, [rsp+0x20]
00007d3d13be481a  vmovaps xmm3, [rsp+0x30]
00007d3d13be4820  vmovaps xmm4, [rsp+0x40]
00007d3d13be4826  vmovaps xmm5, [rsp+0x50]
00007d3d13be482c  vmovaps xmm6, [rsp+0x60]
00007d3d13be4832  vmovaps xmm7, [rsp+0x70]
00007d3d13be4838  vmovaps xmm8, [rsp+0x80]
00007d3d13be4841  vmovaps xmm9, [rsp+0x90]
00007d3d13be484a  vmovaps xmm10, [rsp+0xA0]
00007d3d13be4853  vmovaps xmm11, [rsp+0xB0]
00007d3d13be485c  vmovaps xmm12, [rsp+0xC0]
00007d3d13be4865  vmovaps xmm13, [rsp+0xD0]
00007d3d13be486e  vmovaps xmm14, [rsp+0xE0]
00007d3d13be4877  add rsp, 0xF0
00007d3d13be487e  pop r11
00007d3d13be4880  pop r10
00007d3d13be4882  pop r9
00007d3d13be4884  pop r8
00007d3d13be4886  pop rsi
00007d3d13be4887  pop rdi
00007d3d13be4888  pop rdx
00007d3d13be4889  pop rcx
00007d3d13be488a  pop rax
00007d3d13be488b  add rsp, 0x08
00007d3d13be488f  jmp 0x00007D3D13BDF9DD
00007d3d13be4894  sub rsp, 0x08
00007d3d13be4898  push rax
00007d3d13be4899  push rcx
00007d3d13be489a  push rdx
00007d3d13be489b  push rdi
00007d3d13be489c  push rsi
00007d3d13be489d  push r8
00007d3d13be489f  push r9
00007d3d13be48a1  push r10
00007d3d13be48a3  push r11
00007d3d13be48a5  sub rsp, 0xF0
00007d3d13be48ac  vmovaps [rsp], xmm0
00007d3d13be48b1  vmovaps [rsp+0x10], xmm1
00007d3d13be48b7  vmovaps [rsp+0x20], xmm2
00007d3d13be48bd  vmovaps [rsp+0x30], xmm3
00007d3d13be48c3  vmovaps [rsp+0x40], xmm4
00007d3d13be48c9  vmovaps [rsp+0x50], xmm5
00007d3d13be48cf  vmovaps [rsp+0x60], xmm6
00007d3d13be48d5  vmovaps [rsp+0x70], xmm7
00007d3d13be48db  vmovaps [rsp+0x80], xmm8
00007d3d13be48e4  vmovaps [rsp+0x90], xmm9
00007d3d13be48ed  vmovaps [rsp+0xA0], xmm10
00007d3d13be48f6  vmovaps [rsp+0xB0], xmm11
00007d3d13be48ff  vmovaps [rsp+0xC0], xmm12
00007d3d13be4908  vmovaps [rsp+0xD0], xmm14
00007d3d13be4911  vmovaps [rsp+0xE0], xmm15
00007d3d13be491a  sub rsp, 0x30
00007d3d13be491e  movaps [rsp], xmm13
00007d3d13be4923  movaps [rsp+0x10], xmm10
00007d3d13be4929  movaps [rsp+0x20], xmm14
00007d3d13be492f  lea rdi, [rsp]
00007d3d13be4933  mov esi, 0x00
00007d3d13be4938  mov rax, 0x5741DAFC8530
00007d3d13be4942  call rax
00007d3d13be4944  movaps xmm13, [rsp]
00007d3d13be4949  add rsp, 0x30
00007d3d13be494d  vmovaps xmm0, [rsp]
00007d3d13be4952  vmovaps xmm1, [rsp+0x10]
00007d3d13be4958  vmovaps xmm2, [rsp+0x20]
00007d3d13be495e  vmovaps xmm3, [rsp+0x30]
00007d3d13be4964  vmovaps xmm4, [rsp+0x40]
00007d3d13be496a  vmovaps xmm5, [rsp+0x50]
00007d3d13be4970  vmovaps xmm6, [rsp+0x60]
00007d3d13be4976  vmovaps xmm7, [rsp+0x70]
00007d3d13be497c  vmovaps xmm8, [rsp+0x80]
00007d3d13be4985  vmovaps xmm9, [rsp+0x90]
00007d3d13be498e  vmovaps xmm10, [rsp+0xA0]
00007d3d13be4997  vmovaps xmm11, [rsp+0xB0]
00007d3d13be49a0  vmovaps xmm12, [rsp+0xC0]
00007d3d13be49a9  vmovaps xmm14, [rsp+0xD0]
00007d3d13be49b2  vmovaps xmm15, [rsp+0xE0]
00007d3d13be49bb  add rsp, 0xF0
00007d3d13be49c2  pop r11
00007d3d13be49c4  pop r10
00007d3d13be49c6  pop r9
00007d3d13be49c8  pop r8
00007d3d13be49ca  pop rsi
00007d3d13be49cb  pop rdi
00007d3d13be49cc  pop rdx
00007d3d13be49cd  pop rcx
00007d3d13be49ce  pop rax
00007d3d13be49cf  add rsp, 0x08
00007d3d13be49d3  jmp 0x00007D3D13BDFA00
00007d3d13be49d8  sub rsp, 0x08
00007d3d13be49dc  push rax
00007d3d13be49dd  push rcx
00007d3d13be49de  push rdx
00007d3d13be49df  push rdi
00007d3d13be49e0  push rsi
00007d3d13be49e1  push r8
00007d3d13be49e3  push r9
00007d3d13be49e5  push r10
00007d3d13be49e7  push r11
00007d3d13be49e9  sub rsp, 0xF0
00007d3d13be49f0  vmovaps [rsp], xmm0
00007d3d13be49f5  vmovaps [rsp+0x10], xmm1
00007d3d13be49fb  vmovaps [rsp+0x20], xmm2
00007d3d13be4a01  vmovaps [rsp+0x30], xmm3
00007d3d13be4a07  vmovaps [rsp+0x40], xmm4
00007d3d13be4a0d  vmovaps [rsp+0x50], xmm5
00007d3d13be4a13  vmovaps [rsp+0x60], xmm6
00007d3d13be4a19  vmovaps [rsp+0x70], xmm7
00007d3d13be4a1f  vmovaps [rsp+0x80], xmm8
00007d3d13be4a28  vmovaps [rsp+0x90], xmm9
00007d3d13be4a31  vmovaps [rsp+0xA0], xmm10
00007d3d13be4a3a  vmovaps [rsp+0xB0], xmm11
00007d3d13be4a43  vmovaps [rsp+0xC0], xmm12
00007d3d13be4a4c  vmovaps [rsp+0xD0], xmm13
00007d3d13be4a55  vmovaps [rsp+0xE0], xmm15
00007d3d13be4a5e  sub rsp, 0x30
00007d3d13be4a62  movaps [rsp], xmm14
00007d3d13be4a67  movaps [rsp+0x10], xmm1
00007d3d13be4a6c  movaps [rsp+0x20], xmm7
00007d3d13be4a71  lea rdi, [rsp]
00007d3d13be4a75  mov esi, 0x00
00007d3d13be4a7a  mov rax, 0x5741DAFC8530
00007d3d13be4a84  call rax
00007d3d13be4a86  movaps xmm14, [rsp]
00007d3d13be4a8b  add rsp, 0x30
00007d3d13be4a8f  vmovaps xmm0, [rsp]
00007d3d13be4a94  vmovaps xmm1, [rsp+0x10]
00007d3d13be4a9a  vmovaps xmm2, [rsp+0x20]
00007d3d13be4aa0  vmovaps xmm3, [rsp+0x30]
00007d3d13be4aa6  vmovaps xmm4, [rsp+0x40]
00007d3d13be4aac  vmovaps xmm5, [rsp+0x50]
00007d3d13be4ab2  vmovaps xmm6, [rsp+0x60]
00007d3d13be4ab8  vmovaps xmm7, [rsp+0x70]
00007d3d13be4abe  vmovaps xmm8, [rsp+0x80]
00007d3d13be4ac7  vmovaps xmm9, [rsp+0x90]
00007d3d13be4ad0  vmovaps xmm10, [rsp+0xA0]
00007d3d13be4ad9  vmovaps xmm11, [rsp+0xB0]
00007d3d13be4ae2  vmovaps xmm12, [rsp+0xC0]
00007d3d13be4aeb  vmovaps xmm13, [rsp+0xD0]
00007d3d13be4af4  vmovaps xmm15, [rsp+0xE0]
00007d3d13be4afd  add rsp, 0xF0
00007d3d13be4b04  pop r11
00007d3d13be4b06  pop r10
00007d3d13be4b08  pop r9
00007d3d13be4b0a  pop r8
00007d3d13be4b0c  pop rsi
00007d3d13be4b0d  pop rdi
00007d3d13be4b0e  pop rdx
00007d3d13be4b0f  pop rcx
00007d3d13be4b10  pop rax
00007d3d13be4b11  add rsp, 0x08
00007d3d13be4b15  jmp 0x00007D3D13BDFA23
00007d3d13be4b1a  sub rsp, 0x08
00007d3d13be4b1e  push rax
00007d3d13be4b1f  push rcx
00007d3d13be4b20  push rdx
00007d3d13be4b21  push rdi
00007d3d13be4b22  push rsi
00007d3d13be4b23  push r8
00007d3d13be4b25  push r9
00007d3d13be4b27  push r10
00007d3d13be4b29  push r11
00007d3d13be4b2b  sub rsp, 0xF0
00007d3d13be4b32  vmovaps [rsp], xmm0
00007d3d13be4b37  vmovaps [rsp+0x10], xmm2
00007d3d13be4b3d  vmovaps [rsp+0x20], xmm3
00007d3d13be4b43  vmovaps [rsp+0x30], xmm4
00007d3d13be4b49  vmovaps [rsp+0x40], xmm5
00007d3d13be4b4f  vmovaps [rsp+0x50], xmm6
00007d3d13be4b55  vmovaps [rsp+0x60], xmm7
00007d3d13be4b5b  vmovaps [rsp+0x70], xmm8
00007d3d13be4b61  vmovaps [rsp+0x80], xmm9
00007d3d13be4b6a  vmovaps [rsp+0x90], xmm10
00007d3d13be4b73  vmovaps [rsp+0xA0], xmm11
00007d3d13be4b7c  vmovaps [rsp+0xB0], xmm12
00007d3d13be4b85  vmovaps [rsp+0xC0], xmm13
00007d3d13be4b8e  vmovaps [rsp+0xD0], xmm14
00007d3d13be4b97  vmovaps [rsp+0xE0], xmm15
00007d3d13be4ba0  sub rsp, 0x30
00007d3d13be4ba4  movaps [rsp], xmm1
00007d3d13be4ba8  movaps [rsp+0x10], xmm8
00007d3d13be4bae  movaps [rsp+0x20], xmm9
00007d3d13be4bb4  lea rdi, [rsp]
00007d3d13be4bb8  mov esi, 0x00
00007d3d13be4bbd  mov rax, 0x5741DAFC8530
00007d3d13be4bc7  call rax
00007d3d13be4bc9  movaps xmm1, [rsp]
00007d3d13be4bcd  add rsp, 0x30
00007d3d13be4bd1  vmovaps xmm0, [rsp]
00007d3d13be4bd6  vmovaps xmm2, [rsp+0x10]
00007d3d13be4bdc  vmovaps xmm3, [rsp+0x20]
00007d3d13be4be2  vmovaps xmm4, [rsp+0x30]
00007d3d13be4be8  vmovaps xmm5, [rsp+0x40]
00007d3d13be4bee  vmovaps xmm6, [rsp+0x50]
00007d3d13be4bf4  vmovaps xmm7, [rsp+0x60]
00007d3d13be4bfa  vmovaps xmm8, [rsp+0x70]
00007d3d13be4c00  vmovaps xmm9, [rsp+0x80]
00007d3d13be4c09  vmovaps xmm10, [rsp+0x90]
00007d3d13be4c12  vmovaps xmm11, [rsp+0xA0]
00007d3d13be4c1b  vmovaps xmm12, [rsp+0xB0]
00007d3d13be4c24  vmovaps xmm13, [rsp+0xC0]
00007d3d13be4c2d  vmovaps xmm14, [rsp+0xD0]
00007d3d13be4c36  vmovaps xmm15, [rsp+0xE0]
00007d3d13be4c3f  add rsp, 0xF0
00007d3d13be4c46  pop r11
00007d3d13be4c48  pop r10
00007d3d13be4c4a  pop r9
00007d3d13be4c4c  pop r8
00007d3d13be4c4e  pop rsi
00007d3d13be4c4f  pop rdi
00007d3d13be4c50  pop rdx
00007d3d13be4c51  pop rcx
00007d3d13be4c52  pop rax
00007d3d13be4c53  add rsp, 0x08
00007d3d13be4c57  jmp 0x00007D3D13BDFA45
00007d3d13be4c5c  call 0x00007D3D13AE5940
00007d3d13be4c61  jmp 0x00007D3D13BDFA53
00007d3d13be4c66  call 0x00007D3D13A0C380
00007d3d13be4c6b  jmp 0x00007D3D13BDFA5D
00007d3d13be4c70  call 0x00007D3D13A0D600
00007d3d13be4c75  jmp 0x00007D3D13BDFA67
00007d3d13be4c7a  call 0x00007D3D139FF540
00007d3d13be4c7f  jmp 0x00007D3D13BDFA71
00007d3d13be4c84  int3
00007d3d13be4c85  nop [rax+rax*1], ax
00007d3d13be4c8e  nop
00007d3d13be4c90  mov qword ptr [r15+0x40], 0x430000
00007d3d13be4c98  mov eax, 0x430CC0
00007d3d13be4c9d  mov r14, [r13+rax*1]
00007d3d13be4ca2  movq xmm1, r14
00007d3d13be4ca7  mov rax, [r15+0x50]
00007d3d13be4cab  movups xmm15, [r13+rax*1]
00007d3d13be4cb1  movaps [r15+0x120], xmm15
00007d3d13be4cb9  mov qword ptr [r15+0x48], 0x10
00007d3d13be4cc1  xor eax, eax
00007d3d13be4cc3  mov r14d, 0x10
00007d3d13be4cc9  mov r12d, 0x200
00007d3d13be4ccf  cmp r14, r12
00007d3d13be4cd2  cmc
00007d3d13be4cd3  lahf
00007d3d13be4cd4  seto al
00007d3d13be4cd7  mov [r15+0x108], eax
00007d3d13be4cde  pextrq rax, xmm15, 0x01
00007d3d13be4ce5  movq xmm14, rax
00007d3d13be4cea  movaps [r15+0x130], xmm14
00007d3d13be4cf2  movq rax, xmm1
00007d3d13be4cf7  movq r14, xmm15
00007d3d13be4cfc  vmovq xmm1, rax
00007d3d13be4d01  vmovq xmm15, r14
00007d3d13be4d06  movaps xmm13, xmm1
00007d3d13be4d0a  addsd xmm13, xmm15
00007d3d13be4d0f  ucomisd xmm13, xmm13
00007d3d13be4d14  jp 0x00007D3D13BE4DD3
00007d3d13be4d1a  movq xmm13, xmm13
00007d3d13be4d1f  movq rax, xmm13
00007d3d13be4d24  movq r14, xmm14
00007d3d13be4d29  vmovq xmm1, rax
00007d3d13be4d2e  vmovq xmm15, r14
00007d3d13be4d33  movaps xmm14, xmm1
00007d3d13be4d37  addsd xmm14, xmm15
00007d3d13be4d3c  ucomisd xmm14, xmm14
00007d3d13be4d41  jp 0x00007D3D13BE4E1B
00007d3d13be4d47  movq xmm14, xmm14
00007d3d13be4d4c  movaps [r15+0x110], xmm14
00007d3d13be4d54  mov eax, [r15+0x108]
00007d3d13be4d5b  sahf
00007d3d13be4d5c  jnz 0x00007D3D13BE4D8E
00007d3d13be4d5e  cmp dword ptr [r15+0x318], 0x00
00007d3d13be4d66  jz 0x00007D3D13BE5030
00007d3d13be4d6c  nop [rax+rax*1], ax
00007d3d13be4d75  nop [rax+rax*1], eax
00007d3d13be4d7d  mov eax, 0x410704
00007d3d13be4d82  mov [r15+0x100], rax
00007d3d13be4d89  jmp 0x00007D3D139FE110
00007d3d13be4d8e  cmp dword ptr [r15+0x318], 0x00
00007d3d13be4d96  jz 0x00007D3D13BE4E70
00007d3d13be4d9c  nop [rax+rax*1], ax
00007d3d13be4da5  nop [rax+rax*1], eax
00007d3d13be4dad  mov eax, 0x4106E8
00007d3d13be4db2  mov [r15+0x100], rax
00007d3d13be4db9  jmp 0x00007D3D139FE110
00007d3d13be4dbe  int3
00007d3d13be4dbf  call 0x00007D3D13A0DC20
00007d3d13be4dc4  jmp 0x00007D3D13BE4CA2
00007d3d13be4dc9  call 0x00007D3D13A0E760
00007d3d13be4dce  jmp 0x00007D3D13BE4CB1
00007d3d13be4dd3  ucomisd xmm1, xmm15
00007d3d13be4dd8  jp 0x00007D3D13BE4DE7
00007d3d13be4dda  movaps xmm13, [0x00007D3D137FE060]
00007d3d13be4de2  jmp 0x00007D3D13BE4D1A
00007d3d13be4de7  vxorps xmm0, xmm1, xmm15
00007d3d13be4dec  pextrw eax, xmm0, 0x03
00007d3d13be4df1  and eax, 0x7FF8
00007d3d13be4df6  cmp eax, 0x08
00007d3d13be4df9  jnz 0x00007D3D13BE4D1A
00007d3d13be4dff  movq rax, xmm15
00007d3d13be4e04  shl rax, 0x0D
00007d3d13be4e08  jbe 0x00007D3D13BE4D1A
00007d3d13be4e0e  vorps xmm13, xmm15, [0x00007D3D137FE070]
00007d3d13be4e16  jmp 0x00007D3D13BE4D1A
00007d3d13be4e1b  ucomisd xmm1, xmm15
00007d3d13be4e20  jp 0x00007D3D13BE4E2F
00007d3d13be4e22  movaps xmm14, [0x00007D3D137FE060]
00007d3d13be4e2a  jmp 0x00007D3D13BE4D47
00007d3d13be4e2f  vxorps xmm0, xmm1, xmm15
00007d3d13be4e34  pextrw eax, xmm0, 0x03
00007d3d13be4e39  and eax, 0x7FF8
00007d3d13be4e3e  cmp eax, 0x08
00007d3d13be4e41  jnz 0x00007D3D13BE4D47
00007d3d13be4e47  movq rax, xmm15
00007d3d13be4e4c  shl rax, 0x0D
00007d3d13be4e50  jbe 0x00007D3D13BE4D47
00007d3d13be4e56  vorps xmm14, xmm15, [0x00007D3D137FE070]
00007d3d13be4e5e  jmp 0x00007D3D13BE4D47
00007d3d13be4e63  int3
00007d3d13be4e64  nop [rax+rax*1], ax
00007d3d13be4e6d  nop [rax], eax
00007d3d13be4e70  mov rax, [r15+0x48]
00007d3d13be4e74  mov r14, [r15+0x50]
00007d3d13be4e78  lea r12, [r14+rax*1]
00007d3d13be4e7c  movups xmm1, [r13+r12*1]
00007d3d13be4e82  movaps [r15+0x120], xmm1
00007d3d13be4e8a  lea r14, [rax+0x10]
00007d3d13be4e8e  mov [r15+0x48], r14
00007d3d13be4e92  xor eax, eax
00007d3d13be4e94  mov r12d, 0x200
00007d3d13be4e9a  cmp r14, r12
00007d3d13be4e9d  cmc
00007d3d13be4e9e  lahf
00007d3d13be4e9f  seto al
00007d3d13be4ea2  mov [r15+0x108], eax
00007d3d13be4ea9  pextrq rax, xmm1, 0x01
00007d3d13be4eb0  movq xmm15, rax
00007d3d13be4eb5  movaps [r15+0x130], xmm15
00007d3d13be4ebd  movaps xmm14, [r15+0x110]
00007d3d13be4ec5  movq rax, xmm14
00007d3d13be4eca  movq r14, xmm1
00007d3d13be4ecf  vmovq xmm1, rax
00007d3d13be4ed4  vmovq xmm14, r14
00007d3d13be4ed9  movaps xmm13, xmm1
00007d3d13be4edd  addsd xmm13, xmm14
00007d3d13be4ee2  ucomisd xmm13, xmm13
00007d3d13be4ee7  jp 0x00007D3D13BE4F9C
00007d3d13be4eed  movq xmm13, xmm13
00007d3d13be4ef2  movq rax, xmm13
00007d3d13be4ef7  movq r14, xmm15
00007d3d13be4efc  vmovq xmm1, rax
00007d3d13be4f01  vmovq xmm15, r14
00007d3d13be4f06  movaps xmm14, xmm1
00007d3d13be4f0a  addsd xmm14, xmm15
00007d3d13be4f0f  ucomisd xmm14, xmm14
00007d3d13be4f14  jp 0x00007D3D13BE4FE4
00007d3d13be4f1a  movq xmm14, xmm14
00007d3d13be4f1f  movaps [r15+0x110], xmm14
00007d3d13be4f27  mov eax, [r15+0x108]
00007d3d13be4f2e  sahf
00007d3d13be4f2f  jnz 0x00007D3D13BE4F61
00007d3d13be4f31  cmp dword ptr [r15+0x318], 0x00
00007d3d13be4f39  jz 0x00007D3D13BE5030
00007d3d13be4f3f  nop [rax+rax*1], ax
00007d3d13be4f48  nop [rax+rax*1], eax
00007d3d13be4f50  mov eax, 0x410704
00007d3d13be4f55  mov [r15+0x100], rax
00007d3d13be4f5c  jmp 0x00007D3D139FE110
00007d3d13be4f61  cmp dword ptr [r15+0x318], 0x00
00007d3d13be4f69  jz 0x00007D3D13BE4E70
00007d3d13be4f6f  nop [rax+rax*1], ax
00007d3d13be4f78  nop [rax+rax*1], eax
00007d3d13be4f80  mov eax, 0x4106E8
00007d3d13be4f85  mov [r15+0x100], rax
00007d3d13be4f8c  jmp 0x00007D3D139FE110
00007d3d13be4f91  int3
00007d3d13be4f92  call 0x00007D3D13AB52F0
00007d3d13be4f97  jmp 0x00007D3D13BE4E82
00007d3d13be4f9c  ucomisd xmm1, xmm14
00007d3d13be4fa1  jp 0x00007D3D13BE4FB0
00007d3d13be4fa3  movaps xmm13, [0x00007D3D137FE060]
00007d3d13be4fab  jmp 0x00007D3D13BE4EED
00007d3d13be4fb0  vxorps xmm0, xmm1, xmm14
00007d3d13be4fb5  pextrw eax, xmm0, 0x03
00007d3d13be4fba  and eax, 0x7FF8
00007d3d13be4fbf  cmp eax, 0x08
00007d3d13be4fc2  jnz 0x00007D3D13BE4EED
00007d3d13be4fc8  movq rax, xmm14
00007d3d13be4fcd  shl rax, 0x0D
00007d3d13be4fd1  jbe 0x00007D3D13BE4EED
00007d3d13be4fd7  vorps xmm13, xmm14, [0x00007D3D137FE070]
00007d3d13be4fdf  jmp 0x00007D3D13BE4EED
00007d3d13be4fe4  ucomisd xmm1, xmm15
00007d3d13be4fe9  jp 0x00007D3D13BE4FF8
00007d3d13be4feb  movaps xmm14, [0x00007D3D137FE060]
00007d3d13be4ff3  jmp 0x00007D3D13BE4F1A
00007d3d13be4ff8  vxorps xmm0, xmm1, xmm15
00007d3d13be4ffd  pextrw eax, xmm0, 0x03
00007d3d13be5002  and eax, 0x7FF8
00007d3d13be5007  cmp eax, 0x08
00007d3d13be500a  jnz 0x00007D3D13BE4F1A
00007d3d13be5010  movq rax, xmm15
00007d3d13be5015  shl rax, 0x0D
00007d3d13be5019  jbe 0x00007D3D13BE4F1A
00007d3d13be501f  vorps xmm14, xmm15, [0x00007D3D137FE070]
00007d3d13be5027  jmp 0x00007D3D13BE4F1A
00007d3d13be502c  int3
00007d3d13be502d  nop [rax], eax
00007d3d13be5030  mov rax, [r15+0xF8]
00007d3d13be5037  lea r14, [rax+0x1D0]
00007d3d13be503e  mov r12, [r13+r14*1]
00007d3d13be5043  lea r14, [rax+0x1D8]
00007d3d13be504a  mov r11, [r13+r14*1]
00007d3d13be504f  mov [r15+0xA0], r12
00007d3d13be5056  mov [r15+0x98], r11
00007d3d13be505d  mov r14, [r15+0x40]
00007d3d13be5061  lea r12, [r14+0xCC0]
00007d3d13be5068  movaps xmm1, [r15+0x110]
00007d3d13be5070  movq r14, xmm1
00007d3d13be5075  mov [r13+r12*1], r14
00007d3d13be507a  lea r14, [rax+0x1C0]
00007d3d13be5081  mov r12, [r13+r14*1]
00007d3d13be5086  lea r14, [rax+0x1C8]
00007d3d13be508d  mov r11, [r13+r14*1]
00007d3d13be5092  mov [r15+0xE8], r12
00007d3d13be5099  mov [r15+0xF0], r11
00007d3d13be50a0  lea r14, [rax+0x1B0]
00007d3d13be50a7  mov r12, [r13+r14*1]
00007d3d13be50ac  lea r14, [rax+0x1B8]
00007d3d13be50b3  mov r10, [r13+r14*1]
00007d3d13be50b8  movq xmm1, r12
00007d3d13be50bd  movq xmm15, r10
00007d3d13be50c2  movq xmm1, xmm1
00007d3d13be50c6  movq xmm1, xmm1
00007d3d13be50ca  movaps [r15+0x1A0], xmm1
00007d3d13be50d2  movq xmm15, xmm15
00007d3d13be50d7  movq xmm15, xmm15
00007d3d13be50dc  movaps [r15+0x190], xmm15
00007d3d13be50e4  lea r14, [rax+0x1A0]
00007d3d13be50eb  mov r12, [r13+r14*1]
00007d3d13be50f0  lea r14, [rax+0x1A8]
00007d3d13be50f7  mov r10, [r13+r14*1]
00007d3d13be50fc  movq xmm1, r12
00007d3d13be5101  movq xmm15, r10
00007d3d13be5106  movq xmm1, xmm1
00007d3d13be510a  movq xmm1, xmm1
00007d3d13be510e  movaps [r15+0x1C0], xmm1
00007d3d13be5116  movq xmm15, xmm15
00007d3d13be511b  movq xmm15, xmm15
00007d3d13be5120  movaps [r15+0x1B0], xmm15
00007d3d13be5128  lea r14, [rax+0x190]
00007d3d13be512f  mov r12, [r13+r14*1]
00007d3d13be5134  lea r14, [rax+0x198]
00007d3d13be513b  mov r10, [r13+r14*1]
00007d3d13be5140  movq xmm1, r12
00007d3d13be5145  movq xmm15, r10
00007d3d13be514a  movq xmm1, xmm1
00007d3d13be514e  movq xmm1, xmm1
00007d3d13be5152  movaps [r15+0x1E0], xmm1
00007d3d13be515a  movq xmm15, xmm15
00007d3d13be515f  movq xmm15, xmm15
00007d3d13be5164  movaps [r15+0x1D0], xmm15
00007d3d13be516c  lea r14, [rax+0x180]
00007d3d13be5173  mov r12, [r13+r14*1]
00007d3d13be5178  lea r14, [rax+0x188]
00007d3d13be517f  mov r10, [r13+r14*1]
00007d3d13be5184  movq xmm1, r12
00007d3d13be5189  movq xmm15, r10
00007d3d13be518e  movq xmm1, xmm1
00007d3d13be5192  movq xmm1, xmm1
00007d3d13be5196  movaps [r15+0x200], xmm1
00007d3d13be519e  movq xmm15, xmm15
00007d3d13be51a3  movq xmm15, xmm15
00007d3d13be51a8  movaps [r15+0x1F0], xmm15
00007d3d13be51b0  lea r14, [rax+0x1E0]
00007d3d13be51b7  mov [r15+0xF8], r14
00007d3d13be51be  mov [r15+0x100], r11
00007d3d13be51c5  jmp 0x00007D3D13BCE5C0
00007d3d13be51ca  int3
00007d3d13be51cb  call 0x00007D3D13AE27E0
00007d3d13be51d0  jmp 0x00007D3D13BE5043
00007d3d13be51d5  call 0x00007D3D13AE1570
00007d3d13be51da  jmp 0x00007D3D13BE504F
00007d3d13be51df  call 0x00007D3D13AC3FE0
00007d3d13be51e4  jmp 0x00007D3D13BE507A
00007d3d13be51e9  call 0x00007D3D13AE27E0
00007d3d13be51ee  jmp 0x00007D3D13BE5086
00007d3d13be51f3  call 0x00007D3D13AE1570
00007d3d13be51f8  jmp 0x00007D3D13BE5092
00007d3d13be51fd  call 0x00007D3D13AE27E0
00007d3d13be5202  jmp 0x00007D3D13BE50AC
00007d3d13be5207  call 0x00007D3D13AE0300
00007d3d13be520c  jmp 0x00007D3D13BE50B8
00007d3d13be5211  call 0x00007D3D13AE27E0
00007d3d13be5216  jmp 0x00007D3D13BE50F0
00007d3d13be521b  call 0x00007D3D13AE0300
00007d3d13be5220  jmp 0x00007D3D13BE50FC
00007d3d13be5225  call 0x00007D3D13AE27E0
00007d3d13be522a  jmp 0x00007D3D13BE5134
00007d3d13be522f  call 0x00007D3D13AE0300
00007d3d13be5234  jmp 0x00007D3D13BE5140
00007d3d13be5239  call 0x00007D3D13AE27E0
00007d3d13be523e  jmp 0x00007D3D13BE5178
00007d3d13be5243  call 0x00007D3D13AE0300
00007d3d13be5248  jmp 0x00007D3D13BE5184
00007d3d13be524d  int3
00007d3d13be524e  nop
00007d3d13be5250  mov qword ptr [r15+0x100], 0x04
00007d3d13be525b  mov esi, 0x00
00007d3d13be5260  mov edx, 0x09
00007d3d13be5265  mov rdi, 0x7FFE76256DC0
00007d3d13be526f  mov rax, 0x5741DAE5B970
00007d3d13be5279  call rax
00007d3d13be527b  cmp dword ptr [r15+0x318], 0x00
00007d3d13be5283  jnz 0x00007D3D139FE110
00007d3d13be5289  jmp 0x00007D3D139FE0A0
00007d3d13be528e  int3
00007d3d13be528f  int3
