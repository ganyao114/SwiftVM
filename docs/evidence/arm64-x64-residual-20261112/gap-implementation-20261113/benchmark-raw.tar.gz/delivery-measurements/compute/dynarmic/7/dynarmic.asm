00007e2c933ce69b  nop [rax+rax*1], eax
00007e2c933ce6a0  mov rax, [r15+0xF8]
00007e2c933ce6a7  lea r14, [rax-0x1E0]
00007e2c933ce6ae  mov [r15+0xF8], r14
00007e2c933ce6b5  lea rax, [r14+0x1D0]
00007e2c933ce6bc  mov r12, [r15+0xA0]
00007e2c933ce6c3  mov r11, [r15+0x98]
00007e2c933ce6ca  mov [r13+rax*1], r12
00007e2c933ce6cf  lea rax, [r14+0x1D8]
00007e2c933ce6d6  mov [r13+rax*1], r11
00007e2c933ce6db  mov eax, 0x420AA0
00007e2c933ce6e0  movups xmm1, [r13+rax*1]
00007e2c933ce6e6  mov eax, 0x420A30
00007e2c933ce6eb  movups xmm15, [r13+rax*1]
00007e2c933ce6f1  mov eax, 0x420AC0
00007e2c933ce6f6  movups xmm14, [r13+rax*1]
00007e2c933ce6fc  mov eax, 0x420A60
00007e2c933ce701  movups xmm13, [r13+rax*1]
00007e2c933ce707  mov qword ptr [r15+0x98], 0x430CD0
00007e2c933ce712  mov eax, 0x420AD0
00007e2c933ce717  movups xmm12, [r13+rax*1]
00007e2c933ce71d  mov eax, 0x430CD0
00007e2c933ce722  movups [r13+rax*1], xmm1
00007e2c933ce728  mov eax, 0x430CE0
00007e2c933ce72d  movups [r13+rax*1], xmm15
00007e2c933ce733  mov eax, 0x430CF0
00007e2c933ce738  movups [r13+rax*1], xmm14
00007e2c933ce73e  mov eax, 0x430D00
00007e2c933ce743  movups [r13+rax*1], xmm13
00007e2c933ce749  mov eax, 0x420A20
00007e2c933ce74e  movups xmm14, [r13+rax*1]
00007e2c933ce754  mov eax, 0x420A10
00007e2c933ce759  movups xmm13, [r13+rax*1]
00007e2c933ce75f  mov eax, 0x430DD0
00007e2c933ce764  movups [r13+rax*1], xmm1
00007e2c933ce76a  mov eax, 0x430DE0
00007e2c933ce76f  movups [r13+rax*1], xmm15
00007e2c933ce775  mov eax, 0x430D10
00007e2c933ce77a  movups [r13+rax*1], xmm12
00007e2c933ce780  mov eax, 0x430D20
00007e2c933ce785  movups [r13+rax*1], xmm14
00007e2c933ce78b  mov eax, 0x420A00
00007e2c933ce790  movups xmm1, [r13+rax*1]
00007e2c933ce796  mov eax, 0x420A70
00007e2c933ce79b  movups xmm15, [r13+rax*1]
00007e2c933ce7a1  mov eax, 0x430D30
00007e2c933ce7a6  movups [r13+rax*1], xmm13
00007e2c933ce7ac  mov eax, 0x430D40
00007e2c933ce7b1  movups [r13+rax*1], xmm1
00007e2c933ce7b7  mov eax, 0x420A80
00007e2c933ce7bc  movups xmm1, [r13+rax*1]
00007e2c933ce7c2  mov eax, 0x420A50
00007e2c933ce7c7  movups xmm14, [r13+rax*1]
00007e2c933ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007e2c933ce7d5  mov eax, 0x430D50
00007e2c933ce7da  movups [r13+rax*1], xmm15
00007e2c933ce7e0  mov eax, 0x430D60
00007e2c933ce7e5  movups [r13+rax*1], xmm1
00007e2c933ce7eb  mov eax, 0x420AF0
00007e2c933ce7f0  movups xmm1, [r13+rax*1]
00007e2c933ce7f6  mov eax, 0x420B00
00007e2c933ce7fb  movups xmm15, [r13+rax*1]
00007e2c933ce801  movaps [r15+0x150], xmm15
00007e2c933ce809  mov qword ptr [r15+0xA0], 0x3E8
00007e2c933ce814  mov eax, 0x430D70
00007e2c933ce819  movups [r13+rax*1], xmm14
00007e2c933ce81f  mov eax, 0x430D80
00007e2c933ce824  movups [r13+rax*1], xmm1
00007e2c933ce82a  mov eax, 0x420AE0
00007e2c933ce82f  movups xmm1, [r13+rax*1]
00007e2c933ce835  mov eax, 0x420A90
00007e2c933ce83a  movups xmm14, [r13+rax*1]
00007e2c933ce840  movaps [r15+0x140], xmm14
00007e2c933ce848  lea rax, [r14+0x180]
00007e2c933ce84f  movq xmm13, qword ptr [r15+0x200]
00007e2c933ce858  movq xmm12, qword ptr [r15+0x1F0]
00007e2c933ce861  movq r12, xmm13
00007e2c933ce866  movq r11, xmm12
00007e2c933ce86b  mov [r13+rax*1], r12
00007e2c933ce870  lea rax, [r14+0x188]
00007e2c933ce877  mov [r13+rax*1], r11
00007e2c933ce87c  mov eax, 0x430D90
00007e2c933ce881  movups [r13+rax*1], xmm15
00007e2c933ce887  mov eax, 0x430DA0
00007e2c933ce88c  movups [r13+rax*1], xmm1
00007e2c933ce892  mov eax, 0x420AB0
00007e2c933ce897  movups xmm1, [r13+rax*1]
00007e2c933ce89d  mov eax, 0x420B18
00007e2c933ce8a2  mov r12, [r13+rax*1]
00007e2c933ce8a7  movq xmm15, r12
00007e2c933ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007e2c933ce8b4  mov eax, 0x430DB0
00007e2c933ce8b9  movups [r13+rax*1], xmm14
00007e2c933ce8bf  mov eax, 0x430DC0
00007e2c933ce8c4  movups [r13+rax*1], xmm1
00007e2c933ce8ca  mov eax, 0x420B80
00007e2c933ce8cf  movups xmm1, [r13+rax*1]
00007e2c933ce8d5  movq rax, xmm15
00007e2c933ce8da  mov r12d, 0x430DF0
00007e2c933ce8e0  mov [r13+r12*1], rax
00007e2c933ce8e5  mov eax, 0x420B60
00007e2c933ce8ea  movups xmm15, [r13+rax*1]
00007e2c933ce8f0  mov eax, 0x420B70
00007e2c933ce8f5  movups xmm14, [r13+rax*1]
00007e2c933ce8fb  lea rax, [r14+0x160]
00007e2c933ce902  movups [r13+rax*1], xmm1
00007e2c933ce908  lea rax, [r14+0x190]
00007e2c933ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007e2c933ce918  movq xmm13, qword ptr [r15+0x1D0]
00007e2c933ce921  movq r12, xmm1
00007e2c933ce926  movq r11, xmm13
00007e2c933ce92b  mov [r13+rax*1], r12
00007e2c933ce930  lea rax, [r14+0x198]
00007e2c933ce937  mov [r13+rax*1], r11
00007e2c933ce93c  lea rax, [r14+0x140]
00007e2c933ce943  movups [r13+rax*1], xmm15
00007e2c933ce949  lea rax, [r14+0x150]
00007e2c933ce950  movups [r13+rax*1], xmm14
00007e2c933ce956  mov eax, 0x420B20
00007e2c933ce95b  movups xmm1, [r13+rax*1]
00007e2c933ce961  mov eax, 0x420B30
00007e2c933ce966  movups xmm15, [r13+rax*1]
00007e2c933ce96c  movaps [r15+0x120], xmm15
00007e2c933ce974  lea rax, [r14+0x1A0]
00007e2c933ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007e2c933ce984  movq xmm13, qword ptr [r15+0x1B0]
00007e2c933ce98d  movq r12, xmm14
00007e2c933ce992  movq r11, xmm13
00007e2c933ce997  mov [r13+rax*1], r12
00007e2c933ce99c  lea rax, [r14+0x1A8]
00007e2c933ce9a3  mov [r13+rax*1], r11
00007e2c933ce9a8  lea rax, [r14+0x1B0]
00007e2c933ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007e2c933ce9b8  movq xmm13, qword ptr [r15+0x190]
00007e2c933ce9c1  movq r12, xmm14
00007e2c933ce9c6  movq r11, xmm13
00007e2c933ce9cb  mov [r13+rax*1], r12
00007e2c933ce9d0  lea rax, [r14+0x1B8]
00007e2c933ce9d7  mov [r13+rax*1], r11
00007e2c933ce9dc  lea rax, [r14+0x100]
00007e2c933ce9e3  movups [r13+rax*1], xmm1
00007e2c933ce9e9  lea rax, [r14+0x110]
00007e2c933ce9f0  movups [r13+rax*1], xmm15
00007e2c933ce9f6  mov eax, 0x420B40
00007e2c933ce9fb  movups xmm1, [r13+rax*1]
00007e2c933cea01  mov eax, 0x420B50
00007e2c933cea06  movups xmm15, [r13+rax*1]
00007e2c933cea0c  movaps [r15+0x110], xmm1
00007e2c933cea14  movaps [r15+0x130], xmm15
00007e2c933cea1c  lea rax, [r14+0x1C0]
00007e2c933cea23  mov r12, [r15+0xE8]
00007e2c933cea2a  mov r11, [r15+0xF0]
00007e2c933cea31  mov [r13+rax*1], r12
00007e2c933cea36  lea rax, [r14+0x1C8]
00007e2c933cea3d  mov [r13+rax*1], r11
00007e2c933cea42  mov eax, 0x430DF8
00007e2c933cea47  mov r12d, 0x421DF8D3
00007e2c933cea4d  mov [r13+rax*1], r12d
00007e2c933cea52  lea rax, [r14+0x120]
00007e2c933cea59  movups [r13+rax*1], xmm1
00007e2c933cea5f  lea rax, [r14+0x130]
00007e2c933cea66  movups [r13+rax*1], xmm15
00007e2c933cea6c  lea rax, [r14+0x100]
00007e2c933cea73  mov [r15], rax
00007e2c933cea76  mov qword ptr [r15+0x08], 0x430CD0
00007e2c933cea7e  mov qword ptr [r15+0x10], 0x12C
00007e2c933cea86  mov qword ptr [r15+0xF0], 0x410284
00007e2c933cea91  mov r14d, [r15+0x320]
00007e2c933cea98  mov eax, 0x410284
00007e2c933cea9d  mov rcx, 0x7E2C933D07C0
00007e2c933ceaa7  mov [r15+r14*8+0x328], rax
00007e2c933ceaaf  mov [r15+r14*8+0x368], rcx
00007e2c933ceab7  add r14d, 0x01
00007e2c933ceabb  and r14d, 0x07
00007e2c933ceabf  mov [r15+0x320], r14d
00007e2c933ceac6  cmp dword ptr [r15+0x318], 0x00
00007e2c933ceace  jz 0x00007E2C933CED70
00007e2c933cead4  nop [rax+rax*1], ax
00007e2c933ceadd  nop [rax+rax*1], eax
00007e2c933ceae5  mov eax, 0x410728
00007e2c933ceaea  mov [r15+0x100], rax
00007e2c933ceaf1  jmp 0x00007E2C931FE110
00007e2c933ceaf6  int3
00007e2c933ceaf7  call 0x00007E2C9320BC20
00007e2c933ceafc  jmp 0x00007E2C933CE6CF
00007e2c933ceb01  call 0x00007E2C9320A9A0
00007e2c933ceb06  jmp 0x00007E2C933CE6DB
00007e2c933ceb0b  call 0x00007E2C931FF430
00007e2c933ceb10  jmp 0x00007E2C933CE6E6
00007e2c933ceb15  call 0x00007E2C9320E760
00007e2c933ceb1a  jmp 0x00007E2C933CE6F1
00007e2c933ceb1f  call 0x00007E2C9320D4E0
00007e2c933ceb24  jmp 0x00007E2C933CE6FC
00007e2c933ceb29  call 0x00007E2C9320C260
00007e2c933ceb2e  jmp 0x00007E2C933CE707
00007e2c933ceb33  call 0x00007E2C9320AFE0
00007e2c933ceb38  jmp 0x00007E2C933CE71D
00007e2c933ceb3d  call 0x00007E2C931FF540
00007e2c933ceb42  jmp 0x00007E2C933CE728
00007e2c933ceb47  call 0x00007E2C9320E880
00007e2c933ceb4c  jmp 0x00007E2C933CE733
00007e2c933ceb51  call 0x00007E2C9320D600
00007e2c933ceb56  jmp 0x00007E2C933CE73E
00007e2c933ceb5b  call 0x00007E2C9320C380
00007e2c933ceb60  jmp 0x00007E2C933CE749
00007e2c933ceb65  call 0x00007E2C9320D4E0
00007e2c933ceb6a  jmp 0x00007E2C933CE754
00007e2c933ceb6f  call 0x00007E2C9320C260
00007e2c933ceb74  jmp 0x00007E2C933CE75F
00007e2c933ceb79  call 0x00007E2C931FF540
00007e2c933ceb7e  jmp 0x00007E2C933CE76A
00007e2c933ceb83  call 0x00007E2C9320E880
00007e2c933ceb88  jmp 0x00007E2C933CE775
00007e2c933ceb8d  call 0x00007E2C9320B100
00007e2c933ceb92  jmp 0x00007E2C933CE780
00007e2c933ceb97  call 0x00007E2C9320D600
00007e2c933ceb9c  jmp 0x00007E2C933CE78B
00007e2c933ceba1  call 0x00007E2C931FF430
00007e2c933ceba6  jmp 0x00007E2C933CE796
00007e2c933cebab  call 0x00007E2C9320E760
00007e2c933cebb0  jmp 0x00007E2C933CE7A1
00007e2c933cebb5  call 0x00007E2C9320C380
00007e2c933cebba  jmp 0x00007E2C933CE7AC
00007e2c933cebbf  call 0x00007E2C931FF540
00007e2c933cebc4  jmp 0x00007E2C933CE7B7
00007e2c933cebc9  call 0x00007E2C931FF430
00007e2c933cebce  jmp 0x00007E2C933CE7C2
00007e2c933cebd3  call 0x00007E2C9320D4E0
00007e2c933cebd8  jmp 0x00007E2C933CE7CD
00007e2c933cebdd  call 0x00007E2C9320E880
00007e2c933cebe2  jmp 0x00007E2C933CE7E0
00007e2c933cebe7  call 0x00007E2C931FF540
00007e2c933cebec  jmp 0x00007E2C933CE7EB
00007e2c933cebf1  call 0x00007E2C931FF430
00007e2c933cebf6  jmp 0x00007E2C933CE7F6
00007e2c933cebfb  call 0x00007E2C9320E760
00007e2c933cec00  jmp 0x00007E2C933CE801
00007e2c933cec05  call 0x00007E2C9320D600
00007e2c933cec0a  jmp 0x00007E2C933CE81F
00007e2c933cec0f  call 0x00007E2C931FF540
00007e2c933cec14  jmp 0x00007E2C933CE82A
00007e2c933cec19  call 0x00007E2C931FF430
00007e2c933cec1e  jmp 0x00007E2C933CE835
00007e2c933cec23  call 0x00007E2C9320D4E0
00007e2c933cec28  jmp 0x00007E2C933CE840
00007e2c933cec2d  call 0x00007E2C9320BC20
00007e2c933cec32  jmp 0x00007E2C933CE870
00007e2c933cec37  call 0x00007E2C9320A9A0
00007e2c933cec3c  jmp 0x00007E2C933CE87C
00007e2c933cec41  call 0x00007E2C9320E880
00007e2c933cec46  jmp 0x00007E2C933CE887
00007e2c933cec4b  call 0x00007E2C931FF540
00007e2c933cec50  jmp 0x00007E2C933CE892
00007e2c933cec55  call 0x00007E2C931FF430
00007e2c933cec5a  jmp 0x00007E2C933CE89D
00007e2c933cec5f  call 0x00007E2C9320B720
00007e2c933cec64  jmp 0x00007E2C933CE8A7
00007e2c933cec69  call 0x00007E2C9320D600
00007e2c933cec6e  jmp 0x00007E2C933CE8BF
00007e2c933cec73  call 0x00007E2C931FF540
00007e2c933cec78  jmp 0x00007E2C933CE8CA
00007e2c933cec7d  call 0x00007E2C931FF430
00007e2c933cec82  jmp 0x00007E2C933CE8D5
00007e2c933cec87  call 0x00007E2C932B4CB0
00007e2c933cec8c  jmp 0x00007E2C933CE8E5
00007e2c933cec91  call 0x00007E2C9320E760
00007e2c933cec96  jmp 0x00007E2C933CE8F0
00007e2c933cec9b  call 0x00007E2C9320D4E0
00007e2c933ceca0  jmp 0x00007E2C933CE8FB
00007e2c933ceca5  call 0x00007E2C931FF540
00007e2c933cecaa  jmp 0x00007E2C933CE908
00007e2c933cecaf  call 0x00007E2C9320BC20
00007e2c933cecb4  jmp 0x00007E2C933CE930
00007e2c933cecb9  call 0x00007E2C9320A9A0
00007e2c933cecbe  jmp 0x00007E2C933CE93C
00007e2c933cecc3  call 0x00007E2C9320E880
00007e2c933cecc8  jmp 0x00007E2C933CE949
00007e2c933ceccd  call 0x00007E2C9320D600
00007e2c933cecd2  jmp 0x00007E2C933CE956
00007e2c933cecd7  call 0x00007E2C931FF430
00007e2c933cecdc  jmp 0x00007E2C933CE961
00007e2c933cece1  call 0x00007E2C9320E760
00007e2c933cece6  jmp 0x00007E2C933CE96C
00007e2c933ceceb  call 0x00007E2C9320BC20
00007e2c933cecf0  jmp 0x00007E2C933CE99C
00007e2c933cecf5  call 0x00007E2C9320A9A0
00007e2c933cecfa  jmp 0x00007E2C933CE9A8
00007e2c933cecff  call 0x00007E2C9320BC20
00007e2c933ced04  jmp 0x00007E2C933CE9D0
00007e2c933ced09  call 0x00007E2C9320A9A0
00007e2c933ced0e  jmp 0x00007E2C933CE9DC
00007e2c933ced13  call 0x00007E2C931FF540
00007e2c933ced18  jmp 0x00007E2C933CE9E9
00007e2c933ced1d  call 0x00007E2C9320E880
00007e2c933ced22  jmp 0x00007E2C933CE9F6
00007e2c933ced27  call 0x00007E2C931FF430
00007e2c933ced2c  jmp 0x00007E2C933CEA01
00007e2c933ced31  call 0x00007E2C9320E760
00007e2c933ced36  jmp 0x00007E2C933CEA0C
00007e2c933ced3b  call 0x00007E2C9320BC20
00007e2c933ced40  jmp 0x00007E2C933CEA36
00007e2c933ced45  call 0x00007E2C9320A9A0
00007e2c933ced4a  jmp 0x00007E2C933CEA42
00007e2c933ced4f  call 0x00007E2C9320BAE0
00007e2c933ced54  jmp 0x00007E2C933CEA52
00007e2c933ced59  call 0x00007E2C931FF540
00007e2c933ced5e  jmp 0x00007E2C933CEA5F
00007e2c933ced63  call 0x00007E2C9320E880
00007e2c933ced68  jmp 0x00007E2C933CEA6C
00007e2c933ced6d  int3
00007e2c933ced6e  nop
00007e2c933ced70  mov rax, [r15]
00007e2c933ced73  lea r14, [rax+0x20]
00007e2c933ced77  mov r12, [r13+r14*1]
00007e2c933ced7c  mov r14, [r15+0x10]
00007e2c933ced80  lea r11, [r12+r14*1]
00007e2c933ced84  mov [r15+0x40], r11
00007e2c933ced88  lea r12, [rax+0x20]
00007e2c933ced8c  mov [r13+r12*1], r11
00007e2c933ced91  test r14, r14
00007e2c933ced94  setz r14b
00007e2c933ced98  movzx r14, r14b
00007e2c933ced9c  mov [rsp+0x414], r14b
00007e2c933ceda4  cmp byte ptr [rsp+0x414], 0x00
00007e2c933cedac  jz 0x00007E2C933CEDDE
00007e2c933cedae  cmp dword ptr [r15+0x318], 0x00
00007e2c933cedb6  mov eax, 0x4109A0
00007e2c933cedbb  mov [r15+0x100], rax
00007e2c933cedc2  jz 0x00007E2C931FE0A0
00007e2c933cedc8  nop [rax+rax*1], eax
00007e2c933cedcd  mov eax, 0x4109A0
00007e2c933cedd2  mov [r15+0x100], rax
00007e2c933cedd9  jmp 0x00007E2C931FE110
00007e2c933cedde  cmp dword ptr [r15+0x318], 0x00
00007e2c933cede6  jz 0x00007E2C933CEE30
00007e2c933cedec  nop [rax+rax*1], ax
00007e2c933cedf5  nop [rax+rax*1], eax
00007e2c933cedfd  mov eax, 0x410738
00007e2c933cee02  mov [r15+0x100], rax
00007e2c933cee09  jmp 0x00007E2C931FE110
00007e2c933cee0e  int3
00007e2c933cee0f  call 0x00007E2C932E27E0
00007e2c933cee14  jmp 0x00007E2C933CED7C
00007e2c933cee19  call 0x00007E2C932C0860
00007e2c933cee1e  jmp 0x00007E2C933CED91
00007e2c933cee23  int3
00007e2c933cee24  nop [rax+rax*1], ax
00007e2c933cee2d  nop [rax], eax
00007e2c933cee30  mov rax, [r15+0xF8]
00007e2c933cee37  lea r14, [rax-0x150]
00007e2c933cee3e  mov [r15+0xF8], r14
00007e2c933cee45  mov rax, [r15]
00007e2c933cee48  lea r12, [rax+0x68]
00007e2c933cee4c  mov r11, [r13+r12*1]
00007e2c933cee51  mov [r15+0x88], r11
00007e2c933cee58  lea r12, [rax+0x28]
00007e2c933cee5c  mov [r15+0x40], r12
00007e2c933cee60  mov [r15+0x48], r14
00007e2c933cee64  mov qword ptr [r15+0x50], 0x420B90
00007e2c933cee6c  lea rax, [r14+0x100]
00007e2c933cee73  mov r12, [r15+0xE8]
00007e2c933cee7a  mov r11, [r15+0xD8]
00007e2c933cee81  mov [r13+rax*1], r12
00007e2c933cee86  lea rax, [r14+0x108]
00007e2c933cee8d  mov [r13+rax*1], r11
00007e2c933cee92  lea rax, [r14+0x110]
00007e2c933cee99  mov r12, [r15+0xD0]
00007e2c933ceea0  mov r11, [r15+0xC8]
00007e2c933ceea7  mov [r13+rax*1], r12
00007e2c933ceeac  lea rax, [r14+0x118]
00007e2c933ceeb3  mov [r13+rax*1], r11
00007e2c933ceeb8  lea rax, [r14+0x120]
00007e2c933ceebf  mov r12, [r15+0xC0]
00007e2c933ceec6  mov r11, [r15+0xB8]
00007e2c933ceecd  mov [r13+rax*1], r12
00007e2c933ceed2  lea rax, [r14+0x128]
00007e2c933ceed9  mov [r13+rax*1], r11
00007e2c933ceede  lea rax, [r14+0x130]
00007e2c933ceee5  mov r12, [r15+0xB0]
00007e2c933ceeec  mov r11, [r15+0xA8]
00007e2c933ceef3  mov [r13+rax*1], r12
00007e2c933ceef8  lea rax, [r14+0x138]
00007e2c933ceeff  mov [r13+rax*1], r11
00007e2c933cef04  lea rax, [r14+0x140]
00007e2c933cef0b  mov r12, [r15+0xA0]
00007e2c933cef12  mov r11, [r15+0x98]
00007e2c933cef19  mov [r13+rax*1], r12
00007e2c933cef1e  lea rax, [r14+0x148]
00007e2c933cef25  mov [r13+rax*1], r11
00007e2c933cef2a  cmp dword ptr [r15+0x318], 0x00
00007e2c933cef32  jz 0x00007E2C933CEFD0
00007e2c933cef38  nop [rax+rax*1], ax
00007e2c933cef41  nop [rax+rax*1], eax
00007e2c933cef49  mov eax, 0x410770
00007e2c933cef4e  mov [r15+0x100], rax
00007e2c933cef55  jmp 0x00007E2C931FE110
00007e2c933cef5a  int3
00007e2c933cef5b  call 0x00007E2C932C0370
00007e2c933cef60  jmp 0x00007E2C933CEE51
00007e2c933cef65  call 0x00007E2C9320BC20
00007e2c933cef6a  jmp 0x00007E2C933CEE86
00007e2c933cef6f  call 0x00007E2C9320A9A0
00007e2c933cef74  jmp 0x00007E2C933CEE92
00007e2c933cef79  call 0x00007E2C9320BC20
00007e2c933cef7e  jmp 0x00007E2C933CEEAC
00007e2c933cef83  call 0x00007E2C9320A9A0
00007e2c933cef88  jmp 0x00007E2C933CEEB8
00007e2c933cef8d  call 0x00007E2C9320BC20
00007e2c933cef92  jmp 0x00007E2C933CEED2
00007e2c933cef97  call 0x00007E2C9320A9A0
00007e2c933cef9c  jmp 0x00007E2C933CEEDE
00007e2c933cefa1  call 0x00007E2C9320BC20
00007e2c933cefa6  jmp 0x00007E2C933CEEF8
00007e2c933cefab  call 0x00007E2C9320A9A0
00007e2c933cefb0  jmp 0x00007E2C933CEF04
00007e2c933cefb5  call 0x00007E2C9320BC20
00007e2c933cefba  jmp 0x00007E2C933CEF1E
00007e2c933cefbf  call 0x00007E2C9320A9A0
00007e2c933cefc4  jmp 0x00007E2C933CEF2A
00007e2c933cefc9  int3
00007e2c933cefca  nop [rax+rax*1], ax
00007e2c933cefd0  mov rax, [r15+0x08]
00007e2c933cefd4  movzx r14d, byte ptr [r13+rax*1]
00007e2c933cefda  movzx r14d, r14b
00007e2c933cefde  mov [rsp+0x10], r14d
00007e2c933cefe3  mov r14d, r14d
00007e2c933cefe6  mov [r15+0x58], r14
00007e2c933cefea  lea r14, [rax+0x01]
00007e2c933cefee  mov [r15+0x08], r14
00007e2c933ceff2  mov rax, [r15+0x88]
00007e2c933ceff9  lea r14, [rax+0x01]
00007e2c933ceffd  mov r12, [r15]
00007e2c933cf000  lea r11, [r12+0x68]
00007e2c933cf005  mov [r13+r11*1], r14
00007e2c933cf00a  lea r14, [r12+rax*1]
00007e2c933cf00e  mov [r15+0x60], r14
00007e2c933cf012  lea rax, [r14+0x28]
00007e2c933cf016  mov r11d, [rsp+0x10]
00007e2c933cf01b  movzx r14d, r11b
00007e2c933cf01f  mov [r13+rax*1], r14b
00007e2c933cf024  lea rax, [r12+0x68]
00007e2c933cf029  mov r14, [r13+rax*1]
00007e2c933cf02e  mov [r15+0x88], r14
00007e2c933cf035  xor eax, eax
00007e2c933cf037  mov r12d, 0x40
00007e2c933cf03d  cmp r14, r12
00007e2c933cf040  cmc
00007e2c933cf041  lahf
00007e2c933cf042  seto al
00007e2c933cf045  mov [r15+0x108], eax
00007e2c933cf04c  mov eax, [r15+0x108]
00007e2c933cf053  sahf
00007e2c933cf054  jnz 0x00007E2C933CF086
00007e2c933cf056  cmp dword ptr [r15+0x318], 0x00
00007e2c933cf05e  jz 0x00007E2C933CF170
00007e2c933cf064  nop [rax+rax*1], ax
00007e2c933cf06d  nop [rax+rax*1], eax
00007e2c933cf075  mov eax, 0x410790
00007e2c933cf07a  mov [r15+0x100], rax
00007e2c933cf081  jmp 0x00007E2C931FE110
00007e2c933cf086  cmp dword ptr [r15+0x318], 0x00
00007e2c933cf08e  jz 0x00007E2C933CF0E0
00007e2c933cf094  nop [rax+rax*1], ax
00007e2c933cf09d  nop [rax+rax*1], eax
00007e2c933cf0a5  mov eax, 0x410768
00007e2c933cf0aa  mov [r15+0x100], rax
00007e2c933cf0b1  jmp 0x00007E2C931FE110
00007e2c933cf0b6  int3
00007e2c933cf0b7  call 0x00007E2C9320D860
00007e2c933cf0bc  jmp 0x00007E2C933CEFDA
00007e2c933cf0c1  call 0x00007E2C932B36E0
00007e2c933cf0c6  jmp 0x00007E2C933CF00A
00007e2c933cf0cb  call 0x00007E2C9320DD60
00007e2c933cf0d0  jmp 0x00007E2C933CF024
00007e2c933cf0d5  call 0x00007E2C9320DC20
00007e2c933cf0da  jmp 0x00007E2C933CF02E
00007e2c933cf0df  int3
00007e2c933cf0e0  mov rax, [r15+0x10]
00007e2c933cf0e4  lea r14, [rax-0x01]
00007e2c933cf0e8  mov [r15+0x10], r14
00007e2c933cf0ec  test r14, r14
00007e2c933cf0ef  setz r14b
00007e2c933cf0f3  movzx r14, r14b
00007e2c933cf0f7  mov [rsp+0x414], r14b
00007e2c933cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007e2c933cf107  jz 0x00007E2C933CF139
00007e2c933cf109  cmp dword ptr [r15+0x318], 0x00
00007e2c933cf111  jz 0x00007E2C933D0670
00007e2c933cf117  nop [rax+rax*1], ax
00007e2c933cf120  nop [rax+rax*1], eax
00007e2c933cf128  mov eax, 0x410988
00007e2c933cf12d  mov [r15+0x100], rax
00007e2c933cf134  jmp 0x00007E2C931FE110
00007e2c933cf139  cmp dword ptr [r15+0x318], 0x00
00007e2c933cf141  jz 0x00007E2C933CEFD0
00007e2c933cf147  nop [rax+rax*1], ax
00007e2c933cf150  nop [rax+rax*1], eax
00007e2c933cf158  mov eax, 0x410770
00007e2c933cf15d  mov [r15+0x100], rax
00007e2c933cf164  jmp 0x00007E2C931FE110
00007e2c933cf169  int3
00007e2c933cf16a  int3
00007e2c933cf16b  nop [rax+rax*1], eax
00007e2c933cf170  mov rax, [r15+0x40]
00007e2c933cf174  movzx r14d, byte ptr [r13+rax*1]
00007e2c933cf17a  movaps xmm1, [r15+0x110]
00007e2c933cf182  pinsrb xmm1, r14d, 0x00
00007e2c933cf189  lea r14, [rax+0x01]
00007e2c933cf18d  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf193  movaps xmm15, [r15+0x120]
00007e2c933cf19b  pinsrb xmm15, r12d, 0x00
00007e2c933cf1a2  lea r14, [rax+0x02]
00007e2c933cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf1ac  movaps xmm14, [r15+0x130]
00007e2c933cf1b4  pinsrb xmm14, r12d, 0x00
00007e2c933cf1bb  lea r14, [rax+0x03]
00007e2c933cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf1c5  movaps xmm13, [r15+0x140]
00007e2c933cf1cd  pinsrb xmm13, r12d, 0x00
00007e2c933cf1d4  lea r14, [rax+0x04]
00007e2c933cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf1de  pinsrb xmm1, r12d, 0x01
00007e2c933cf1e5  lea r14, [rax+0x05]
00007e2c933cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf1ef  pinsrb xmm15, r12d, 0x01
00007e2c933cf1f6  lea r14, [rax+0x06]
00007e2c933cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf200  pinsrb xmm14, r12d, 0x01
00007e2c933cf207  lea r14, [rax+0x07]
00007e2c933cf20b  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf211  pinsrb xmm13, r12d, 0x01
00007e2c933cf218  lea r14, [rax+0x08]
00007e2c933cf21c  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf222  pinsrb xmm1, r12d, 0x02
00007e2c933cf229  lea r14, [rax+0x09]
00007e2c933cf22d  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf233  pinsrb xmm15, r12d, 0x02
00007e2c933cf23a  lea r14, [rax+0x0A]
00007e2c933cf23e  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf244  pinsrb xmm14, r12d, 0x02
00007e2c933cf24b  lea r14, [rax+0x0B]
00007e2c933cf24f  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf255  pinsrb xmm13, r12d, 0x02
00007e2c933cf25c  lea r14, [rax+0x0C]
00007e2c933cf260  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf266  pinsrb xmm1, r12d, 0x03
00007e2c933cf26d  lea r14, [rax+0x0D]
00007e2c933cf271  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf277  pinsrb xmm15, r12d, 0x03
00007e2c933cf27e  lea r14, [rax+0x0E]
00007e2c933cf282  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf288  pinsrb xmm14, r12d, 0x03
00007e2c933cf28f  lea r14, [rax+0x0F]
00007e2c933cf293  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf299  pinsrb xmm13, r12d, 0x03
00007e2c933cf2a0  lea r14, [rax+0x10]
00007e2c933cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf2aa  pinsrb xmm1, r12d, 0x04
00007e2c933cf2b1  lea r14, [rax+0x11]
00007e2c933cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf2bb  pinsrb xmm15, r12d, 0x04
00007e2c933cf2c2  lea r14, [rax+0x12]
00007e2c933cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf2cc  pinsrb xmm14, r12d, 0x04
00007e2c933cf2d3  lea r14, [rax+0x13]
00007e2c933cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf2dd  pinsrb xmm13, r12d, 0x04
00007e2c933cf2e4  lea r14, [rax+0x14]
00007e2c933cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf2ee  pinsrb xmm1, r12d, 0x05
00007e2c933cf2f5  lea r14, [rax+0x15]
00007e2c933cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf2ff  pinsrb xmm15, r12d, 0x05
00007e2c933cf306  lea r14, [rax+0x16]
00007e2c933cf30a  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf310  pinsrb xmm14, r12d, 0x05
00007e2c933cf317  lea r14, [rax+0x17]
00007e2c933cf31b  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf321  pinsrb xmm13, r12d, 0x05
00007e2c933cf328  lea r14, [rax+0x18]
00007e2c933cf32c  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf332  pinsrb xmm1, r12d, 0x06
00007e2c933cf339  lea r14, [rax+0x19]
00007e2c933cf33d  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf343  pinsrb xmm15, r12d, 0x06
00007e2c933cf34a  lea r14, [rax+0x1A]
00007e2c933cf34e  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf354  pinsrb xmm14, r12d, 0x06
00007e2c933cf35b  lea r14, [rax+0x1B]
00007e2c933cf35f  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf365  pinsrb xmm13, r12d, 0x06
00007e2c933cf36c  lea r14, [rax+0x1C]
00007e2c933cf370  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf376  pinsrb xmm1, r12d, 0x07
00007e2c933cf37d  lea r14, [rax+0x1D]
00007e2c933cf381  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf387  pinsrb xmm15, r12d, 0x07
00007e2c933cf38e  lea r14, [rax+0x1E]
00007e2c933cf392  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf398  pinsrb xmm14, r12d, 0x07
00007e2c933cf39f  lea r14, [rax+0x1F]
00007e2c933cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf3a9  pinsrb xmm13, r12d, 0x07
00007e2c933cf3b0  lea r14, [rax+0x20]
00007e2c933cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf3ba  pinsrb xmm1, r12d, 0x08
00007e2c933cf3c1  lea r14, [rax+0x21]
00007e2c933cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf3cb  pinsrb xmm15, r12d, 0x08
00007e2c933cf3d2  lea r14, [rax+0x22]
00007e2c933cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf3dc  pinsrb xmm14, r12d, 0x08
00007e2c933cf3e3  lea r14, [rax+0x23]
00007e2c933cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf3ed  pinsrb xmm13, r12d, 0x08
00007e2c933cf3f4  lea r14, [rax+0x24]
00007e2c933cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf3fe  pinsrb xmm1, r12d, 0x09
00007e2c933cf405  lea r14, [rax+0x25]
00007e2c933cf409  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf40f  pinsrb xmm15, r12d, 0x09
00007e2c933cf416  lea r14, [rax+0x26]
00007e2c933cf41a  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf420  pinsrb xmm14, r12d, 0x09
00007e2c933cf427  lea r14, [rax+0x27]
00007e2c933cf42b  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf431  pinsrb xmm13, r12d, 0x09
00007e2c933cf438  lea r14, [rax+0x28]
00007e2c933cf43c  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf442  pinsrb xmm1, r12d, 0x0A
00007e2c933cf449  lea r14, [rax+0x29]
00007e2c933cf44d  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf453  pinsrb xmm15, r12d, 0x0A
00007e2c933cf45a  lea r14, [rax+0x2A]
00007e2c933cf45e  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf464  pinsrb xmm14, r12d, 0x0A
00007e2c933cf46b  lea r14, [rax+0x2B]
00007e2c933cf46f  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf475  pinsrb xmm13, r12d, 0x0A
00007e2c933cf47c  lea r14, [rax+0x2C]
00007e2c933cf480  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf486  pinsrb xmm1, r12d, 0x0B
00007e2c933cf48d  lea r14, [rax+0x2D]
00007e2c933cf491  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf497  pinsrb xmm15, r12d, 0x0B
00007e2c933cf49e  lea r14, [rax+0x2E]
00007e2c933cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf4a8  pinsrb xmm14, r12d, 0x0B
00007e2c933cf4af  lea r14, [rax+0x2F]
00007e2c933cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf4b9  pinsrb xmm13, r12d, 0x0B
00007e2c933cf4c0  lea r14, [rax+0x30]
00007e2c933cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf4ca  pinsrb xmm1, r12d, 0x0C
00007e2c933cf4d1  lea r14, [rax+0x31]
00007e2c933cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf4db  pinsrb xmm15, r12d, 0x0C
00007e2c933cf4e2  lea r14, [rax+0x32]
00007e2c933cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf4ec  pinsrb xmm14, r12d, 0x0C
00007e2c933cf4f3  lea r14, [rax+0x33]
00007e2c933cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf4fd  pinsrb xmm13, r12d, 0x0C
00007e2c933cf504  lea r14, [rax+0x34]
00007e2c933cf508  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf50e  pinsrb xmm1, r12d, 0x0D
00007e2c933cf515  lea r14, [rax+0x35]
00007e2c933cf519  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf51f  pinsrb xmm15, r12d, 0x0D
00007e2c933cf526  lea r14, [rax+0x36]
00007e2c933cf52a  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf530  pinsrb xmm14, r12d, 0x0D
00007e2c933cf537  lea r14, [rax+0x37]
00007e2c933cf53b  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf541  pinsrb xmm13, r12d, 0x0D
00007e2c933cf548  lea r14, [rax+0x38]
00007e2c933cf54c  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf552  pinsrb xmm1, r12d, 0x0E
00007e2c933cf559  lea r14, [rax+0x39]
00007e2c933cf55d  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf563  pinsrb xmm15, r12d, 0x0E
00007e2c933cf56a  lea r14, [rax+0x3A]
00007e2c933cf56e  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf574  pinsrb xmm14, r12d, 0x0E
00007e2c933cf57b  lea r14, [rax+0x3B]
00007e2c933cf57f  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf585  pinsrb xmm13, r12d, 0x0E
00007e2c933cf58c  lea r14, [rax+0x3C]
00007e2c933cf590  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf596  pinsrb xmm1, r12d, 0x0F
00007e2c933cf59d  movaps [r15+0x110], xmm1
00007e2c933cf5a5  lea r14, [rax+0x3D]
00007e2c933cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf5af  pinsrb xmm15, r12d, 0x0F
00007e2c933cf5b6  movaps [r15+0x120], xmm15
00007e2c933cf5be  lea r14, [rax+0x3E]
00007e2c933cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007e2c933cf5c8  pinsrb xmm14, r12d, 0x0F
00007e2c933cf5cf  movaps [r15+0x130], xmm14
00007e2c933cf5d7  lea r14, [rax+0x3F]
00007e2c933cf5db  movzx eax, byte ptr [r13+r14*1]
00007e2c933cf5e1  pinsrb xmm13, eax, 0x0F
00007e2c933cf5e8  movaps [r15+0x140], xmm13
00007e2c933cf5f0  movq xmm1, qword ptr [r15+0x120]
00007e2c933cf5f9  pmovzxbw xmm1, xmm1
00007e2c933cf5fe  psllw xmm1, 0x00
00007e2c933cf603  movaps [r15+0x150], xmm1
00007e2c933cf60b  movq xmm1, qword ptr [r15+0x130]
00007e2c933cf614  pmovzxbw xmm1, xmm1
00007e2c933cf619  psllw xmm1, 0x00
00007e2c933cf61e  movaps [r15+0x160], xmm1
00007e2c933cf626  movq xmm1, qword ptr [r15+0x110]
00007e2c933cf62f  pmovzxbw xmm1, xmm1
00007e2c933cf634  psllw xmm1, 0x00
00007e2c933cf639  movaps [r15+0x170], xmm1
00007e2c933cf641  movaps xmm15, [r15+0x110]
00007e2c933cf649  pextrq rax, xmm15, 0x01
00007e2c933cf650  movq xmm15, rax
00007e2c933cf655  pmovzxbw xmm15, xmm15
00007e2c933cf65b  psllw xmm15, 0x00
00007e2c933cf661  movaps [r15+0x180], xmm15
00007e2c933cf669  movaps xmm14, [r15+0x120]
00007e2c933cf671  pextrq rax, xmm14, 0x01
00007e2c933cf678  movq xmm14, rax
00007e2c933cf67d  pmovzxbw xmm14, xmm14
00007e2c933cf683  psllw xmm14, 0x00
00007e2c933cf689  movaps [r15+0x210], xmm14
00007e2c933cf691  movaps xmm13, [r15+0x130]
00007e2c933cf699  pextrq rax, xmm13, 0x01
00007e2c933cf6a0  movq xmm13, rax
00007e2c933cf6a5  pmovzxbw xmm13, xmm13
00007e2c933cf6ab  psllw xmm13, 0x00
00007e2c933cf6b1  movaps [r15+0x220], xmm13
00007e2c933cf6b9  movq xmm12, qword ptr [r15+0x140]
00007e2c933cf6c2  pmovzxbw xmm12, xmm12
00007e2c933cf6c8  psllw xmm12, 0x00
00007e2c933cf6ce  movaps [r15+0x250], xmm12
00007e2c933cf6d6  movaps xmm12, [r15+0x140]
00007e2c933cf6de  pextrq rax, xmm12, 0x01
00007e2c933cf6e5  movq xmm12, rax
00007e2c933cf6ea  pmovzxbw xmm12, xmm12
00007e2c933cf6f0  psllw xmm12, 0x00
00007e2c933cf6f6  movaps [r15+0x110], xmm12
00007e2c933cf6fe  movq xmm11, qword ptr [r15+0x150]
00007e2c933cf707  pmovzxwd xmm11, xmm11
00007e2c933cf70d  pslld xmm11, 0x10
00007e2c933cf713  movq xmm10, qword ptr [r15+0x160]
00007e2c933cf71c  pmovzxwd xmm10, xmm10
00007e2c933cf722  pslld xmm10, 0x08
00007e2c933cf728  pextrq rax, xmm1, 0x01
00007e2c933cf72f  movq xmm1, rax
00007e2c933cf734  pmovzxwd xmm1, xmm1
00007e2c933cf739  pslld xmm1, 0x00
00007e2c933cf73e  movaps [r15+0x260], xmm1
00007e2c933cf746  pextrq rax, xmm15, 0x01
00007e2c933cf74d  movq xmm15, rax
00007e2c933cf752  pmovzxwd xmm15, xmm15
00007e2c933cf758  pslld xmm15, 0x00
00007e2c933cf75e  movaps [r15+0x270], xmm15
00007e2c933cf766  movq xmm9, qword ptr [r15+0x170]
00007e2c933cf76f  pmovzxwd xmm9, xmm9
00007e2c933cf775  pslld xmm9, 0x00
00007e2c933cf77b  pextrq rax, xmm14, 0x01
00007e2c933cf782  movq xmm14, rax
00007e2c933cf787  pmovzxwd xmm14, xmm14
00007e2c933cf78d  pslld xmm14, 0x10
00007e2c933cf793  movaps [r15+0x280], xmm14
00007e2c933cf79b  movq xmm8, qword ptr [r15+0x180]
00007e2c933cf7a4  pmovzxwd xmm8, xmm8
00007e2c933cf7aa  pslld xmm8, 0x00
00007e2c933cf7b0  movq xmm7, qword ptr [r15+0x210]
00007e2c933cf7b9  pmovzxwd xmm7, xmm7
00007e2c933cf7be  pslld xmm7, 0x10
00007e2c933cf7c3  movaps xmm6, [r15+0x150]
00007e2c933cf7cb  pextrq rax, xmm6, 0x01
00007e2c933cf7d2  movq xmm6, rax
00007e2c933cf7d7  pmovzxwd xmm6, xmm6
00007e2c933cf7dc  pslld xmm6, 0x10
00007e2c933cf7e1  por xmm11, xmm10
00007e2c933cf7e6  movaps [r15+0x230], xmm11
00007e2c933cf7ee  pextrq rax, xmm13, 0x01
00007e2c933cf7f5  movq xmm13, rax
00007e2c933cf7fa  pmovzxwd xmm13, xmm13
00007e2c933cf800  pslld xmm13, 0x08
00007e2c933cf806  movaps [r15+0x240], xmm13
00007e2c933cf80e  movq xmm10, qword ptr [r15+0x220]
00007e2c933cf817  pmovzxwd xmm10, xmm10
00007e2c933cf81d  pslld xmm10, 0x08
00007e2c933cf823  movaps xmm5, [r15+0x160]
00007e2c933cf82b  pextrq rax, xmm5, 0x01
00007e2c933cf832  movq xmm5, rax
00007e2c933cf837  pmovzxwd xmm5, xmm5
00007e2c933cf83c  pslld xmm5, 0x08
00007e2c933cf841  pslld xmm9, 0x18
00007e2c933cf847  pslld xmm15, 0x18
00007e2c933cf84d  pslld xmm8, 0x18
00007e2c933cf853  movq xmm4, qword ptr [r15+0x250]
00007e2c933cf85c  pmovzxwd xmm4, xmm4
00007e2c933cf861  pslld xmm4, 0x00
00007e2c933cf866  por xmm14, xmm13
00007e2c933cf86b  por xmm7, xmm10
00007e2c933cf870  movaps [r15+0x210], xmm7
00007e2c933cf878  pslld xmm1, 0x18
00007e2c933cf87d  movaps [r15+0x220], xmm1
00007e2c933cf885  por xmm6, xmm5
00007e2c933cf889  por xmm11, xmm9
00007e2c933cf88e  movaps [r15+0x160], xmm11
00007e2c933cf896  pextrq rax, xmm12, 0x01
00007e2c933cf89d  movq xmm13, rax
00007e2c933cf8a2  pmovzxwd xmm13, xmm13
00007e2c933cf8a8  pslld xmm13, 0x00
00007e2c933cf8ae  movaps [r15+0x170], xmm13
00007e2c933cf8b6  movq xmm12, qword ptr [r15+0x110]
00007e2c933cf8bf  pmovzxwd xmm12, xmm12
00007e2c933cf8c5  pslld xmm12, 0x00
00007e2c933cf8cb  por xmm14, xmm15
00007e2c933cf8d0  por xmm7, xmm8
00007e2c933cf8d5  movaps xmm15, [r15+0x250]
00007e2c933cf8dd  pextrq rax, xmm15, 0x01
00007e2c933cf8e4  movq xmm15, rax
00007e2c933cf8e9  pmovzxwd xmm15, xmm15
00007e2c933cf8ef  pslld xmm15, 0x00
00007e2c933cf8f5  movaps [r15+0x180], xmm15
00007e2c933cf8fd  por xmm6, xmm1
00007e2c933cf901  movaps [r15+0x150], xmm6
00007e2c933cf909  por xmm11, xmm4
00007e2c933cf90e  movaps [r15+0x140], xmm11
00007e2c933cf916  por xmm7, xmm12
00007e2c933cf91b  movaps [r15+0x110], xmm7
00007e2c933cf923  por xmm14, xmm13
00007e2c933cf928  movaps [r15+0x120], xmm14
00007e2c933cf930  por xmm6, xmm15
00007e2c933cf935  movaps [r15+0x130], xmm6
00007e2c933cf93d  mov rax, [r15+0xF8]
00007e2c933cf944  lea r14, [rax+0x20]
00007e2c933cf948  movups [r13+r14*1], xmm7
00007e2c933cf94e  lea r14, [rax+0x30]
00007e2c933cf952  movups [r13+r14*1], xmm14
00007e2c933cf958  movups [r13+rax*1], xmm11
00007e2c933cf95e  lea r14, [rax+0x10]
00007e2c933cf962  movups [r13+r14*1], xmm6
00007e2c933cf968  mov r14d, [r13+rax*1]
00007e2c933cf96d  mov rax, [r15+0x48]
00007e2c933cf971  mov [r15+0x68], rax
00007e2c933cf975  mov qword ptr [r15+0x58], 0x04
00007e2c933cf97d  lea r12, [rax+0x04]
00007e2c933cf981  mov r11d, [r13+r12*1]
00007e2c933cf986  mov [rsp+0x10], r11d
00007e2c933cf98b  mov r11d, r11d
00007e2c933cf98e  mov [r15+0x70], r11
00007e2c933cf992  lea r12, [rax+0x38]
00007e2c933cf996  mov r11d, [r13+r12*1]
00007e2c933cf99b  lea r12, [rax+0x24]
00007e2c933cf99f  mov r10d, [r13+r12*1]
00007e2c933cf9a4  mov [rsp+0x20], r10d
00007e2c933cf9a9  mov r10d, r10d
00007e2c933cf9ac  mov [r15+0x90], r10
00007e2c933cf9b3  mov [rsp+0x30], rax
00007e2c933cf9b8  xor eax, eax
00007e2c933cf9ba  mov r12d, 0x04
00007e2c933cf9c0  mov r10d, 0xC0
00007e2c933cf9c6  cmp r12, r10
00007e2c933cf9c9  cmc
00007e2c933cf9ca  lahf
00007e2c933cf9cb  seto al
00007e2c933cf9ce  mov [r15+0x108], eax
00007e2c933cf9d5  mov eax, [rsp+0x10]
00007e2c933cf9d9  mov r12d, [rsp+0x10]
00007e2c933cf9de  shrd eax, r12d, 0x07
00007e2c933cf9e3  mov [rsp+0x10], r11d
00007e2c933cf9e8  mov r10d, [rsp+0x10]
00007e2c933cf9ed  shrd r11d, r10d, 0x11
00007e2c933cf9f2  mov r9d, [rsp+0x20]
00007e2c933cf9f7  lea r8d, [r9d+r14d*1]
00007e2c933cf9fc  rorx r14d, r12d, 0x12
00007e2c933cfa02  xor eax, r14d
00007e2c933cfa05  rorx r14d, r10d, 0x13
00007e2c933cfa0b  xor r11d, r14d
00007e2c933cfa0e  mov [rsp+0x10], r11d
00007e2c933cfa13  mov r11d, r11d
00007e2c933cfa16  mov [r15+0x88], r11
00007e2c933cfa1d  mov [rsp+0x20], r12d
00007e2c933cfa22  shr r12d, 0x03
00007e2c933cfa26  xor eax, r12d
00007e2c933cfa29  mov [rsp+0x40], eax
00007e2c933cfa2d  mov eax, eax
00007e2c933cfa2f  mov [r15+0x80], rax
00007e2c933cfa36  shr r10d, 0x0A
00007e2c933cfa3a  mov eax, [rsp+0x10]
00007e2c933cfa3e  xor eax, r10d
00007e2c933cfa41  mov [rsp+0x10], eax
00007e2c933cfa45  mov eax, eax
00007e2c933cfa47  mov [r15+0x78], rax
00007e2c933cfa4b  mov eax, [rsp+0x40]
00007e2c933cfa4f  lea r14d, [r8d+eax*1]
00007e2c933cfa54  mov eax, [rsp+0x10]
00007e2c933cfa58  lea r12d, [r14d+eax*1]
00007e2c933cfa5d  mov rax, [rsp+0x30]
00007e2c933cfa62  lea r14, [rax+0x40]
00007e2c933cfa66  mov [r13+r14*1], r12d
00007e2c933cfa6b  mov eax, [rsp+0x20]
00007e2c933cfa6f  mov eax, eax
00007e2c933cfa71  mov [r15+0x60], rax
00007e2c933cfa75  mov eax, [r15+0x108]
00007e2c933cfa7c  sahf
00007e2c933cfa7d  jnz 0x00007E2C933CFAAF
00007e2c933cfa7f  cmp dword ptr [r15+0x318], 0x00
00007e2c933cfa87  jz 0x00007E2C933CFF70
00007e2c933cfa8d  nop [rax+rax*1], ax
00007e2c933cfa96  nop [rax+rax*1], eax
00007e2c933cfa9e  mov eax, 0x41088C
00007e2c933cfaa3  mov [r15+0x100], rax
00007e2c933cfaaa  jmp 0x00007E2C931FE110
00007e2c933cfaaf  cmp dword ptr [r15+0x318], 0x00
00007e2c933cfab7  jz 0x00007E2C933CFDC0
00007e2c933cfabd  nop [rax+rax*1], ax
00007e2c933cfac6  nop [rax+rax*1], eax
00007e2c933cface  mov eax, 0x410844
00007e2c933cfad3  mov [r15+0x100], rax
00007e2c933cfada  jmp 0x00007E2C931FE110
00007e2c933cfadf  int3
00007e2c933cfae0  call 0x00007E2C9320D860
00007e2c933cfae5  jmp 0x00007E2C933CF17A
00007e2c933cfaea  call 0x00007E2C932E2420
00007e2c933cfaef  jmp 0x00007E2C933CF193
00007e2c933cfaf4  call 0x00007E2C932E2420
00007e2c933cfaf9  jmp 0x00007E2C933CF1AC
00007e2c933cfafe  call 0x00007E2C932E2420
00007e2c933cfb03  jmp 0x00007E2C933CF1C5
00007e2c933cfb08  call 0x00007E2C932E2420
00007e2c933cfb0d  jmp 0x00007E2C933CF1DE
00007e2c933cfb12  call 0x00007E2C932E2420
00007e2c933cfb17  jmp 0x00007E2C933CF1EF
00007e2c933cfb1c  call 0x00007E2C932E2420
00007e2c933cfb21  jmp 0x00007E2C933CF200
00007e2c933cfb26  call 0x00007E2C932E2420
00007e2c933cfb2b  jmp 0x00007E2C933CF211
00007e2c933cfb30  call 0x00007E2C932E2420
00007e2c933cfb35  jmp 0x00007E2C933CF222
00007e2c933cfb3a  call 0x00007E2C932E2420
00007e2c933cfb3f  jmp 0x00007E2C933CF233
00007e2c933cfb44  call 0x00007E2C932E2420
00007e2c933cfb49  jmp 0x00007E2C933CF244
00007e2c933cfb4e  call 0x00007E2C932E2420
00007e2c933cfb53  jmp 0x00007E2C933CF255
00007e2c933cfb58  call 0x00007E2C932E2420
00007e2c933cfb5d  jmp 0x00007E2C933CF266
00007e2c933cfb62  call 0x00007E2C932E2420
00007e2c933cfb67  jmp 0x00007E2C933CF277
00007e2c933cfb6c  call 0x00007E2C932E2420
00007e2c933cfb71  jmp 0x00007E2C933CF288
00007e2c933cfb76  call 0x00007E2C932E2420
00007e2c933cfb7b  jmp 0x00007E2C933CF299
00007e2c933cfb80  call 0x00007E2C932E2420
00007e2c933cfb85  jmp 0x00007E2C933CF2AA
00007e2c933cfb8a  call 0x00007E2C932E2420
00007e2c933cfb8f  jmp 0x00007E2C933CF2BB
00007e2c933cfb94  call 0x00007E2C932E2420
00007e2c933cfb99  jmp 0x00007E2C933CF2CC
00007e2c933cfb9e  call 0x00007E2C932E2420
00007e2c933cfba3  jmp 0x00007E2C933CF2DD
00007e2c933cfba8  call 0x00007E2C932E2420
00007e2c933cfbad  jmp 0x00007E2C933CF2EE
00007e2c933cfbb2  call 0x00007E2C932E2420
00007e2c933cfbb7  jmp 0x00007E2C933CF2FF
00007e2c933cfbbc  call 0x00007E2C932E2420
00007e2c933cfbc1  jmp 0x00007E2C933CF310
00007e2c933cfbc6  call 0x00007E2C932E2420
00007e2c933cfbcb  jmp 0x00007E2C933CF321
00007e2c933cfbd0  call 0x00007E2C932E2420
00007e2c933cfbd5  jmp 0x00007E2C933CF332
00007e2c933cfbda  call 0x00007E2C932E2420
00007e2c933cfbdf  jmp 0x00007E2C933CF343
00007e2c933cfbe4  call 0x00007E2C932E2420
00007e2c933cfbe9  jmp 0x00007E2C933CF354
00007e2c933cfbee  call 0x00007E2C932E2420
00007e2c933cfbf3  jmp 0x00007E2C933CF365
00007e2c933cfbf8  call 0x00007E2C932E2420
00007e2c933cfbfd  jmp 0x00007E2C933CF376
00007e2c933cfc02  call 0x00007E2C932E2420
00007e2c933cfc07  jmp 0x00007E2C933CF387
00007e2c933cfc0c  call 0x00007E2C932E2420
00007e2c933cfc11  jmp 0x00007E2C933CF398
00007e2c933cfc16  call 0x00007E2C932E2420
00007e2c933cfc1b  jmp 0x00007E2C933CF3A9
00007e2c933cfc20  call 0x00007E2C932E2420
00007e2c933cfc25  jmp 0x00007E2C933CF3BA
00007e2c933cfc2a  call 0x00007E2C932E2420
00007e2c933cfc2f  jmp 0x00007E2C933CF3CB
00007e2c933cfc34  call 0x00007E2C932E2420
00007e2c933cfc39  jmp 0x00007E2C933CF3DC
00007e2c933cfc3e  call 0x00007E2C932E2420
00007e2c933cfc43  jmp 0x00007E2C933CF3ED
00007e2c933cfc48  call 0x00007E2C932E2420
00007e2c933cfc4d  jmp 0x00007E2C933CF3FE
00007e2c933cfc52  call 0x00007E2C932E2420
00007e2c933cfc57  jmp 0x00007E2C933CF40F
00007e2c933cfc5c  call 0x00007E2C932E2420
00007e2c933cfc61  jmp 0x00007E2C933CF420
00007e2c933cfc66  call 0x00007E2C932E2420
00007e2c933cfc6b  jmp 0x00007E2C933CF431
00007e2c933cfc70  call 0x00007E2C932E2420
00007e2c933cfc75  jmp 0x00007E2C933CF442
00007e2c933cfc7a  call 0x00007E2C932E2420
00007e2c933cfc7f  jmp 0x00007E2C933CF453
00007e2c933cfc84  call 0x00007E2C932E2420
00007e2c933cfc89  jmp 0x00007E2C933CF464
00007e2c933cfc8e  call 0x00007E2C932E2420
00007e2c933cfc93  jmp 0x00007E2C933CF475
00007e2c933cfc98  call 0x00007E2C932E2420
00007e2c933cfc9d  jmp 0x00007E2C933CF486
00007e2c933cfca2  call 0x00007E2C932E2420
00007e2c933cfca7  jmp 0x00007E2C933CF497
00007e2c933cfcac  call 0x00007E2C932E2420
00007e2c933cfcb1  jmp 0x00007E2C933CF4A8
00007e2c933cfcb6  call 0x00007E2C932E2420
00007e2c933cfcbb  jmp 0x00007E2C933CF4B9
00007e2c933cfcc0  call 0x00007E2C932E2420
00007e2c933cfcc5  jmp 0x00007E2C933CF4CA
00007e2c933cfcca  call 0x00007E2C932E2420
00007e2c933cfccf  jmp 0x00007E2C933CF4DB
00007e2c933cfcd4  call 0x00007E2C932E2420
00007e2c933cfcd9  jmp 0x00007E2C933CF4EC
00007e2c933cfcde  call 0x00007E2C932E2420
00007e2c933cfce3  jmp 0x00007E2C933CF4FD
00007e2c933cfce8  call 0x00007E2C932E2420
00007e2c933cfced  jmp 0x00007E2C933CF50E
00007e2c933cfcf2  call 0x00007E2C932E2420
00007e2c933cfcf7  jmp 0x00007E2C933CF51F
00007e2c933cfcfc  call 0x00007E2C932E2420
00007e2c933cfd01  jmp 0x00007E2C933CF530
00007e2c933cfd06  call 0x00007E2C932E2420
00007e2c933cfd0b  jmp 0x00007E2C933CF541
00007e2c933cfd10  call 0x00007E2C932E2420
00007e2c933cfd15  jmp 0x00007E2C933CF552
00007e2c933cfd1a  call 0x00007E2C932E2420
00007e2c933cfd1f  jmp 0x00007E2C933CF563
00007e2c933cfd24  call 0x00007E2C932E2420
00007e2c933cfd29  jmp 0x00007E2C933CF574
00007e2c933cfd2e  call 0x00007E2C932E2420
00007e2c933cfd33  jmp 0x00007E2C933CF585
00007e2c933cfd38  call 0x00007E2C932E2420
00007e2c933cfd3d  jmp 0x00007E2C933CF596
00007e2c933cfd42  call 0x00007E2C932E2420
00007e2c933cfd47  jmp 0x00007E2C933CF5AF
00007e2c933cfd4c  call 0x00007E2C932E2420
00007e2c933cfd51  jmp 0x00007E2C933CF5C8
00007e2c933cfd56  call 0x00007E2C932D5610
00007e2c933cfd5b  jmp 0x00007E2C933CF5E1
00007e2c933cfd60  call 0x00007E2C932DC580
00007e2c933cfd65  jmp 0x00007E2C933CF94E
00007e2c933cfd6a  call 0x00007E2C932E46C0
00007e2c933cfd6f  jmp 0x00007E2C933CF958
00007e2c933cfd74  call 0x00007E2C93209E90
00007e2c933cfd79  jmp 0x00007E2C933CF95E
00007e2c933cfd7e  call 0x00007E2C932DB310
00007e2c933cfd83  jmp 0x00007E2C933CF968
00007e2c933cfd88  call 0x00007E2C9320DAE0
00007e2c933cfd8d  jmp 0x00007E2C933CF96D
00007e2c933cfd92  call 0x00007E2C932C0230
00007e2c933cfd97  jmp 0x00007E2C933CF986
00007e2c933cfd9c  call 0x00007E2C932C0230
00007e2c933cfda1  jmp 0x00007E2C933CF99B
00007e2c933cfda6  call 0x00007E2C932BEFC0
00007e2c933cfdab  jmp 0x00007E2C933CF9A4
00007e2c933cfdb0  call 0x00007E2C932E2BA0
00007e2c933cfdb5  jmp 0x00007E2C933CFA6B
00007e2c933cfdba  int3
00007e2c933cfdbb  nop [rax+rax*1], eax
00007e2c933cfdc0  mov rax, [r15+0x48]
00007e2c933cfdc4  mov r14, [r15+0x58]
00007e2c933cfdc8  lea r12, [rax+r14*1]
00007e2c933cfdcc  mov [r15+0x68], r12
00007e2c933cfdd0  lea rax, [r14+0x04]
00007e2c933cfdd4  mov [r15+0x58], rax
00007e2c933cfdd8  lea r14, [r12+0x04]
00007e2c933cfddd  mov r11d, [r13+r14*1]
00007e2c933cfde2  mov [rsp+0x10], r11d
00007e2c933cfde7  mov r11d, r11d
00007e2c933cfdea  mov [r15+0x70], r11
00007e2c933cfdee  lea r14, [r12+0x38]
00007e2c933cfdf3  mov r11d, [r13+r14*1]
00007e2c933cfdf8  lea r14, [r12+0x24]
00007e2c933cfdfd  mov r10d, [r13+r14*1]
00007e2c933cfe02  mov [rsp+0x20], r10d
00007e2c933cfe07  mov r10d, r10d
00007e2c933cfe0a  mov [r15+0x90], r10
00007e2c933cfe11  mov [rsp+0x30], rax
00007e2c933cfe16  xor eax, eax
00007e2c933cfe18  mov r14, [rsp+0x30]
00007e2c933cfe1d  mov r10d, 0xC0
00007e2c933cfe23  cmp r14, r10
00007e2c933cfe26  cmc
00007e2c933cfe27  lahf
00007e2c933cfe28  seto al
00007e2c933cfe2b  mov [r15+0x108], eax
00007e2c933cfe32  mov eax, [rsp+0x10]
00007e2c933cfe36  mov r14d, [rsp+0x10]
00007e2c933cfe3b  shrd eax, r14d, 0x07
00007e2c933cfe40  mov [rsp+0x10], r11d
00007e2c933cfe45  mov r10d, [rsp+0x10]
00007e2c933cfe4a  shrd r11d, r10d, 0x11
00007e2c933cfe4f  mov r9d, [r15+0x60]
00007e2c933cfe53  mov r8d, [rsp+0x20]
00007e2c933cfe58  lea ebp, [r8d+r9d*1]
00007e2c933cfe5d  rorx r9d, r14d, 0x12
00007e2c933cfe63  xor eax, r9d
00007e2c933cfe66  rorx r9d, r10d, 0x13
00007e2c933cfe6c  xor r11d, r9d
00007e2c933cfe6f  mov [rsp+0x10], r11d
00007e2c933cfe74  mov r11d, r11d
00007e2c933cfe77  mov [r15+0x88], r11
00007e2c933cfe7e  mov [rsp+0x20], r14d
00007e2c933cfe83  shr r14d, 0x03
00007e2c933cfe87  xor eax, r14d
00007e2c933cfe8a  mov [rsp+0x30], eax
00007e2c933cfe8e  mov eax, eax
00007e2c933cfe90  mov [r15+0x80], rax
00007e2c933cfe97  shr r10d, 0x0A
00007e2c933cfe9b  mov eax, [rsp+0x10]
00007e2c933cfe9f  xor eax, r10d
00007e2c933cfea2  mov [rsp+0x10], eax
00007e2c933cfea6  mov eax, eax
00007e2c933cfea8  mov [r15+0x78], rax
00007e2c933cfeac  mov eax, [rsp+0x30]
00007e2c933cfeb0  lea r14d, [ebp+eax*1]
00007e2c933cfeb6  mov eax, [rsp+0x10]
00007e2c933cfeba  lea r11d, [r14d+eax*1]
00007e2c933cfebf  lea rax, [r12+0x40]
00007e2c933cfec4  mov [r13+rax*1], r11d
00007e2c933cfec9  mov eax, [rsp+0x20]
00007e2c933cfecd  mov eax, eax
00007e2c933cfecf  mov [r15+0x60], rax
00007e2c933cfed3  mov eax, [r15+0x108]
00007e2c933cfeda  sahf
00007e2c933cfedb  jnz 0x00007E2C933CFF0D
00007e2c933cfedd  cmp dword ptr [r15+0x318], 0x00
00007e2c933cfee5  jz 0x00007E2C933CFF70
00007e2c933cfeeb  nop [rax+rax*1], ax
00007e2c933cfef4  nop [rax+rax*1], eax
00007e2c933cfefc  mov eax, 0x41088C
00007e2c933cff01  mov [r15+0x100], rax
00007e2c933cff08  jmp 0x00007E2C931FE110
00007e2c933cff0d  cmp dword ptr [r15+0x318], 0x00
00007e2c933cff15  jz 0x00007E2C933CFDC0
00007e2c933cff1b  nop [rax+rax*1], ax
00007e2c933cff24  nop [rax+rax*1], eax
00007e2c933cff2c  mov eax, 0x410844
00007e2c933cff31  mov [r15+0x100], rax
00007e2c933cff38  jmp 0x00007E2C931FE110
00007e2c933cff3d  int3
00007e2c933cff3e  call 0x00007E2C932E1430
00007e2c933cff43  jmp 0x00007E2C933CFDE2
00007e2c933cff48  call 0x00007E2C932E1430
00007e2c933cff4d  jmp 0x00007E2C933CFDF8
00007e2c933cff52  call 0x00007E2C932E01C0
00007e2c933cff57  jmp 0x00007E2C933CFE02
00007e2c933cff5c  call 0x00007E2C9320A860
00007e2c933cff61  jmp 0x00007E2C933CFEC9
00007e2c933cff66  int3
00007e2c933cff67  nop [rax+rax*1], ax
00007e2c933cff70  mov rax, [r15]
00007e2c933cff73  mov r14d, [r13+rax*1]
00007e2c933cff78  lea r12, [rax+0x04]
00007e2c933cff7c  mov r11d, [r13+r12*1]
00007e2c933cff81  mov [rsp+0x10], r14d
00007e2c933cff86  mov r14d, r14d
00007e2c933cff89  mov [r15+0x78], r14
00007e2c933cff8d  mov [rsp+0x20], r11d
00007e2c933cff92  mov r11d, r11d
00007e2c933cff95  mov [r15+0x80], r11
00007e2c933cff9c  lea r14, [rax+0x08]
00007e2c933cffa0  mov r12d, [r13+r14*1]
00007e2c933cffa5  lea r14, [rax+0x0C]
00007e2c933cffa9  mov r11d, [r13+r14*1]
00007e2c933cffae  mov [rsp+0x30], r12d
00007e2c933cffb3  mov r12d, r12d
00007e2c933cffb6  mov [r15+0x70], r12
00007e2c933cffba  mov [rsp+0x40], r11d
00007e2c933cffbf  mov r11d, r11d
00007e2c933cffc2  mov [r15+0x68], r11
00007e2c933cffc6  lea r14, [rax+0x18]
00007e2c933cffca  mov r12d, [r13+r14*1]
00007e2c933cffcf  lea r14, [rax+0x1C]
00007e2c933cffd3  mov r11d, [r13+r14*1]
00007e2c933cffd8  mov [rsp+0x50], r12d
00007e2c933cffdd  mov r12d, r12d
00007e2c933cffe0  mov [r15+0x58], r12
00007e2c933cffe4  mov [rsp+0x60], r11d
00007e2c933cffe9  mov r11d, r11d
00007e2c933cffec  mov [r15+0x60], r11
00007e2c933cfff0  lea r14, [rax+0x10]
00007e2c933cfff4  mov r12d, [r13+r14*1]
00007e2c933cfff9  lea r14, [rax+0x14]
00007e2c933cfffd  mov eax, [r13+r14*1]
00007e2c933d0002  mov [rsp+0x70], r12d
00007e2c933d0007  mov r12d, r12d
00007e2c933d000a  mov [r15+0x18], r12
00007e2c933d000e  mov [rsp+0x80], eax
00007e2c933d0015  mov eax, eax
00007e2c933d0017  mov [r15+0x90], rax
00007e2c933d001e  mov eax, [rsp+0x70]
00007e2c933d0022  mov eax, eax
00007e2c933d0024  mov [r15+0x30], rax
00007e2c933d0028  mov eax, [rsp+0x50]
00007e2c933d002c  mov eax, eax
00007e2c933d002e  mov [r15+0xA0], rax
00007e2c933d0035  mov eax, [rsp+0x30]
00007e2c933d0039  mov eax, eax
00007e2c933d003b  mov [r15+0x28], rax
00007e2c933d003f  mov eax, [rsp+0x20]
00007e2c933d0043  mov eax, eax
00007e2c933d0045  mov [r15+0x98], rax
00007e2c933d004c  mov eax, [rsp+0x10]
00007e2c933d0050  mov eax, eax
00007e2c933d0052  mov [r15+0x38], rax
00007e2c933d0056  mov eax, [rsp+0x70]
00007e2c933d005a  mov r14d, [rsp+0x70]
00007e2c933d005f  shrd eax, r14d, 0x06
00007e2c933d0064  mov [rsp+0x70], r14d
00007e2c933d0069  mov r12d, [rsp+0x80]
00007e2c933d0071  and r14d, r12d
00007e2c933d0074  mov r11d, [rsp+0x10]
00007e2c933d0079  mov r10d, [rsp+0x10]
00007e2c933d007e  shrd r11d, r10d, 0x02
00007e2c933d0083  mov [rsp+0x10], r12d
00007e2c933d0088  mov r12d, r12d
00007e2c933d008b  mov [r15+0x20], r12
00007e2c933d008f  mov r12, [r15+0x50]
00007e2c933d0093  mov r9d, [r13+r12*1]
00007e2c933d0098  mov r12d, [rsp+0x50]
00007e2c933d009d  mov r8d, [rsp+0x70]
00007e2c933d00a2  andn ebp, r8d, r12d
00007e2c933d00a7  mov edi, [rsp+0x60]
00007e2c933d00ab  lea esi, [r14d+edi*1]
00007e2c933d00b0  rorx r14d, r8d, 0x0B
00007e2c933d00b6  xor eax, r14d
00007e2c933d00b9  rorx r14d, r10d, 0x0D
00007e2c933d00bf  xor r11d, r14d
00007e2c933d00c2  lea edi, [esi+ebp*1]
00007e2c933d00c6  mov r14, [r15+0x48]
00007e2c933d00ca  mov ebp, [r13+r14*1]
00007e2c933d00cf  mov r14d, [rsp+0x30]
00007e2c933d00d4  mov esi, [rsp+0x20]
00007e2c933d00d8  and r14d, esi
00007e2c933d00db  mov [rsp+0x20], r14d
00007e2c933d00e0  mov r14d, r14d
00007e2c933d00e3  mov [r15+0xD8], r14
00007e2c933d00ea  lea r14d, [edi+r9d*1]
00007e2c933d00ef  mov r9d, [rsp+0x30]
00007e2c933d00f4  xor r9d, esi
00007e2c933d00f7  rorx edi, r8d, 0x19
00007e2c933d00fd  xor eax, edi
00007e2c933d00ff  and r9d, r10d
00007e2c933d0102  rorx edi, r10d, 0x16
00007e2c933d0108  xor r11d, edi
00007e2c933d010b  mov [rsp+0x30], r11d
00007e2c933d0110  mov r11d, r11d
00007e2c933d0113  mov [r15+0xD0], r11
00007e2c933d011a  lea r11d, [r14d+ebp*1]
00007e2c933d011f  mov r10d, [rsp+0x20]
00007e2c933d0124  xor r9d, r10d
00007e2c933d0127  lea r14d, [r11d+eax*1]
00007e2c933d012c  mov qword ptr [r15+0x88], 0x04
00007e2c933d0137  mov eax, [rsp+0x30]
00007e2c933d013b  lea r11d, [r9d+eax*1]
00007e2c933d0140  mov eax, [rsp+0x40]
00007e2c933d0144  lea r10d, [r14d+eax*1]
00007e2c933d0149  mov r10d, r10d
00007e2c933d014c  mov [r15+0xB8], r10
00007e2c933d0153  xor eax, eax
00007e2c933d0155  mov r10d, 0x04
00007e2c933d015b  mov r9d, 0x100
00007e2c933d0161  cmp r10, r9
00007e2c933d0164  cmc
00007e2c933d0165  lahf
00007e2c933d0166  seto al
00007e2c933d0169  mov [r15+0x108], eax
00007e2c933d0170  lea eax, [r11d+r14d*1]
00007e2c933d0175  mov eax, eax
00007e2c933d0177  mov [r15+0xA8], rax
00007e2c933d017e  mov r12d, r12d
00007e2c933d0181  mov [r15+0xB0], r12
00007e2c933d0188  mov eax, [rsp+0x10]
00007e2c933d018c  mov eax, eax
00007e2c933d018e  mov [r15+0xC0], rax
00007e2c933d0195  mov r8d, r8d
00007e2c933d0198  mov [r15+0xC8], r8
00007e2c933d019f  mov eax, [r15+0x108]
00007e2c933d01a6  sahf
00007e2c933d01a7  jnz 0x00007E2C933D01D9
00007e2c933d01a9  cmp dword ptr [r15+0x318], 0x00
00007e2c933d01b1  jz 0x00007E2C933D04A0
00007e2c933d01b7  nop [rax+rax*1], ax
00007e2c933d01c0  nop [rax+rax*1], eax
00007e2c933d01c8  mov eax, 0x41094C
00007e2c933d01cd  mov [r15+0x100], rax
00007e2c933d01d4  jmp 0x00007E2C931FE110
00007e2c933d01d9  cmp dword ptr [r15+0x318], 0x00
00007e2c933d01e1  jz 0x00007E2C933D0270
00007e2c933d01e7  nop [rax+rax*1], ax
00007e2c933d01f0  nop [rax+rax*1], eax
00007e2c933d01f8  mov eax, 0x4108C0
00007e2c933d01fd  mov [r15+0x100], rax
00007e2c933d0204  jmp 0x00007E2C931FE110
00007e2c933d0209  int3
00007e2c933d020a  call 0x00007E2C9320DAE0
00007e2c933d020f  jmp 0x00007E2C933CFF78
00007e2c933d0214  call 0x00007E2C932C0230
00007e2c933d0219  jmp 0x00007E2C933CFF81
00007e2c933d021e  call 0x00007E2C932E26A0
00007e2c933d0223  jmp 0x00007E2C933CFFA5
00007e2c933d0228  call 0x00007E2C932E1430
00007e2c933d022d  jmp 0x00007E2C933CFFAE
00007e2c933d0232  call 0x00007E2C932E26A0
00007e2c933d0237  jmp 0x00007E2C933CFFCF
00007e2c933d023c  call 0x00007E2C932E1430
00007e2c933d0241  jmp 0x00007E2C933CFFD8
00007e2c933d0246  call 0x00007E2C932E26A0
00007e2c933d024b  jmp 0x00007E2C933CFFF9
00007e2c933d0250  call 0x00007E2C932D5890
00007e2c933d0255  jmp 0x00007E2C933D0002
00007e2c933d025a  call 0x00007E2C932BDD50
00007e2c933d025f  jmp 0x00007E2C933D0098
00007e2c933d0264  call 0x00007E2C932DA580
00007e2c933d0269  jmp 0x00007E2C933D00CF
00007e2c933d026e  int3
00007e2c933d026f  nop
00007e2c933d0270  mov eax, [r15+0xB8]
00007e2c933d0277  mov [rsp+0x10], eax
00007e2c933d027b  mov eax, eax
00007e2c933d027d  mov [r15+0x30], rax
00007e2c933d0281  mov eax, [r15+0xC0]
00007e2c933d0288  mov [rsp+0x20], eax
00007e2c933d028c  mov eax, eax
00007e2c933d028e  mov [r15+0xA0], rax
00007e2c933d0295  mov eax, [r15+0x28]
00007e2c933d0299  mov r14d, [r15+0x98]
00007e2c933d02a0  mov [rsp+0x30], r14d
00007e2c933d02a5  mov r14d, r14d
00007e2c933d02a8  mov [r15+0x28], r14
00007e2c933d02ac  mov r14d, [r15+0x38]
00007e2c933d02b0  mov [rsp+0x40], r14d
00007e2c933d02b5  mov r14d, r14d
00007e2c933d02b8  mov [r15+0x98], r14
00007e2c933d02bf  mov r14d, [r15+0xA8]
00007e2c933d02c6  mov [rsp+0x50], r14d
00007e2c933d02cb  mov r14d, r14d
00007e2c933d02ce  mov [r15+0x38], r14
00007e2c933d02d2  mov r14d, [rsp+0x10]
00007e2c933d02d7  mov r12d, [rsp+0x10]
00007e2c933d02dc  shrd r14d, r12d, 0x06
00007e2c933d02e1  mov r11d, [r15+0xC8]
00007e2c933d02e8  mov [rsp+0x10], r12d
00007e2c933d02ed  and r12d, r11d
00007e2c933d02f0  mov r10d, [rsp+0x50]
00007e2c933d02f5  mov r9d, [rsp+0x50]
00007e2c933d02fa  shrd r10d, r9d, 0x02
00007e2c933d02ff  mov [rsp+0x50], r11d
00007e2c933d0304  mov r11d, r11d
00007e2c933d0307  mov [r15+0x20], r11
00007e2c933d030b  mov r11, [r15+0x88]
00007e2c933d0312  mov r8, [r15+0x50]
00007e2c933d0316  lea rbp, [r8+r11*1]
00007e2c933d031a  mov r8d, [r13+rbp*1]
00007e2c933d031f  mov ebp, [rsp+0x20]
00007e2c933d0323  mov edi, [rsp+0x10]
00007e2c933d0327  andn esi, edi, ebp
00007e2c933d032c  mov edx, [r15+0xB0]
00007e2c933d0333  lea ecx, [r12d+edx*1]
00007e2c933d0338  rorx r12d, edi, 0x0B
00007e2c933d033e  xor r14d, r12d
00007e2c933d0341  rorx r12d, r9d, 0x0D
00007e2c933d0347  xor r10d, r12d
00007e2c933d034a  lea r12d, [ecx+esi*1]
00007e2c933d034f  mov rsi, [r15+0x48]
00007e2c933d0353  lea rdx, [rsi+r11*1]
00007e2c933d0357  mov esi, [r13+rdx*1]
00007e2c933d035c  mov edx, [rsp+0x30]
00007e2c933d0360  mov ecx, [rsp+0x40]
00007e2c933d0364  and edx, ecx
00007e2c933d0366  mov [rsp+0x10], edx
00007e2c933d036a  mov edx, edx
00007e2c933d036c  mov [r15+0xD8], rdx
00007e2c933d0373  lea edx, [r12d+r8d*1]
00007e2c933d0378  mov r12d, [rsp+0x30]
00007e2c933d037d  xor r12d, ecx
00007e2c933d0380  rorx r8d, edi, 0x19
00007e2c933d0386  xor r14d, r8d
00007e2c933d0389  and r12d, r9d
00007e2c933d038c  rorx r8d, r9d, 0x16
00007e2c933d0392  xor r10d, r8d
00007e2c933d0395  mov [rsp+0x20], r10d
00007e2c933d039a  mov r10d, r10d
00007e2c933d039d  mov [r15+0xD0], r10
00007e2c933d03a4  lea r10d, [edx+esi*1]
00007e2c933d03a9  mov r9d, [rsp+0x10]
00007e2c933d03ae  xor r12d, r9d
00007e2c933d03b1  lea r9d, [r10d+r14d*1]
00007e2c933d03b6  lea r14, [r11+0x04]
00007e2c933d03ba  mov [r15+0x88], r14
00007e2c933d03c1  mov r11d, [rsp+0x20]
00007e2c933d03c6  lea r10d, [r12d+r11d*1]
00007e2c933d03cb  lea r11d, [r9d+eax*1]
00007e2c933d03d0  mov r11d, r11d
00007e2c933d03d3  mov [r15+0xB8], r11
00007e2c933d03da  xor eax, eax
00007e2c933d03dc  mov r12d, 0x100
00007e2c933d03e2  cmp r14, r12
00007e2c933d03e5  cmc
00007e2c933d03e6  lahf
00007e2c933d03e7  seto al
00007e2c933d03ea  mov [r15+0x108], eax
00007e2c933d03f1  lea eax, [r10d+r9d*1]
00007e2c933d03f6  mov eax, eax
00007e2c933d03f8  mov [r15+0xA8], rax
00007e2c933d03ff  mov ebp, ebp
00007e2c933d0401  mov [r15+0xB0], rbp
00007e2c933d0408  mov eax, [rsp+0x50]
00007e2c933d040c  mov eax, eax
00007e2c933d040e  mov [r15+0xC0], rax
00007e2c933d0415  mov edi, edi
00007e2c933d0417  mov [r15+0xC8], rdi
00007e2c933d041e  mov eax, [r15+0x108]
00007e2c933d0425  sahf
00007e2c933d0426  jnz 0x00007E2C933D0458
00007e2c933d0428  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0430  jz 0x00007E2C933D04A0
00007e2c933d0436  nop [rax+rax*1], ax
00007e2c933d043f  nop [rax+rax*1], eax
00007e2c933d0447  mov eax, 0x41094C
00007e2c933d044c  mov [r15+0x100], rax
00007e2c933d0453  jmp 0x00007E2C931FE110
00007e2c933d0458  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0460  jz 0x00007E2C933D0270
00007e2c933d0466  nop [rax+rax*1], ax
00007e2c933d046f  nop [rax+rax*1], eax
00007e2c933d0477  mov eax, 0x4108C0
00007e2c933d047c  mov [r15+0x100], rax
00007e2c933d0483  jmp 0x00007E2C931FE110
00007e2c933d0488  int3
00007e2c933d0489  call 0x00007E2C93249010
00007e2c933d048e  jmp 0x00007E2C933D031F
00007e2c933d0493  call 0x00007E2C93225930
00007e2c933d0498  jmp 0x00007E2C933D035C
00007e2c933d049d  int3
00007e2c933d049e  nop
00007e2c933d04a0  mov eax, [r15+0x98]
00007e2c933d04a7  mov r14d, [r15+0x70]
00007e2c933d04ab  lea r12d, [eax+r14d*1]
00007e2c933d04b0  mov eax, [r15+0x28]
00007e2c933d04b4  mov r14d, [r15+0x68]
00007e2c933d04b8  lea r11d, [eax+r14d*1]
00007e2c933d04bd  mov qword ptr [r15+0x88], 0x00
00007e2c933d04c8  mov eax, [r15+0xA8]
00007e2c933d04cf  mov r14d, [r15+0x78]
00007e2c933d04d3  lea r10d, [eax+r14d*1]
00007e2c933d04d8  mov [rsp+0x10], r10d
00007e2c933d04dd  mov r10d, r10d
00007e2c933d04e0  mov [r15+0x78], r10
00007e2c933d04e4  mov eax, [r15+0x38]
00007e2c933d04e8  mov r14d, [r15+0x80]
00007e2c933d04ef  lea r10d, [eax+r14d*1]
00007e2c933d04f4  mov [rsp+0x20], r10d
00007e2c933d04f9  mov r10d, r10d
00007e2c933d04fc  mov [r15+0x80], r10
00007e2c933d0503  mov rax, [r15]
00007e2c933d0506  lea r14, [rax+0x08]
00007e2c933d050a  mov [r13+r14*1], r12d
00007e2c933d050f  lea r14, [rax+0x0C]
00007e2c933d0513  mov [r13+r14*1], r11d
00007e2c933d0518  mov r14d, [r15+0xB8]
00007e2c933d051f  mov r12d, [r15+0x18]
00007e2c933d0523  lea r11d, [r14d+r12d*1]
00007e2c933d0528  mov [rsp+0x30], r11d
00007e2c933d052d  mov r11d, r11d
00007e2c933d0530  mov [r15+0x68], r11
00007e2c933d0534  mov r14d, [r15+0x30]
00007e2c933d0538  mov r12d, [r15+0x90]
00007e2c933d053f  lea r11d, [r14d+r12d*1]
00007e2c933d0544  mov [rsp+0x40], r11d
00007e2c933d0549  mov r11d, r11d
00007e2c933d054c  mov [r15+0x70], r11
00007e2c933d0550  mov r14d, [r15+0x20]
00007e2c933d0554  mov r12d, [r15+0x58]
00007e2c933d0558  lea r11d, [r14d+r12d*1]
00007e2c933d055d  mov [rsp+0x50], r11d
00007e2c933d0562  mov r11d, r11d
00007e2c933d0565  mov [r15+0x58], r11
00007e2c933d0569  mov r14d, [r15+0xA0]
00007e2c933d0570  mov r12d, [r15+0x60]
00007e2c933d0574  lea r11d, [r14d+r12d*1]
00007e2c933d0579  mov [rsp+0x60], r11d
00007e2c933d057e  mov r11d, r11d
00007e2c933d0581  mov [r15+0x60], r11
00007e2c933d0585  mov r14d, [rsp+0x10]
00007e2c933d058a  mov [r13+rax*1], r14d
00007e2c933d058f  lea r14, [rax+0x04]
00007e2c933d0593  mov r12d, [rsp+0x20]
00007e2c933d0598  mov [r13+r14*1], r12d
00007e2c933d059d  lea r14, [rax+0x10]
00007e2c933d05a1  mov r12d, [rsp+0x30]
00007e2c933d05a6  mov [r13+r14*1], r12d
00007e2c933d05ab  lea r14, [rax+0x14]
00007e2c933d05af  mov r12d, [rsp+0x40]
00007e2c933d05b4  mov [r13+r14*1], r12d
00007e2c933d05b9  lea r14, [rax+0x18]
00007e2c933d05bd  mov r12d, [rsp+0x50]
00007e2c933d05c2  mov [r13+r14*1], r12d
00007e2c933d05c7  lea r14, [rax+0x1C]
00007e2c933d05cb  mov r12d, [rsp+0x60]
00007e2c933d05d0  mov [r13+r14*1], r12d
00007e2c933d05d5  lea r14, [rax+0x68]
00007e2c933d05d9  xor eax, eax
00007e2c933d05db  mov [r13+r14*1], rax
00007e2c933d05e0  cmp dword ptr [r15+0x318], 0x00
00007e2c933d05e8  jz 0x00007E2C933CF0E0
00007e2c933d05ee  nop [rax+rax*1], ax
00007e2c933d05f7  nop [rax+rax*1], eax
00007e2c933d05ff  mov eax, 0x410768
00007e2c933d0604  mov [r15+0x100], rax
00007e2c933d060b  jmp 0x00007E2C931FE110
00007e2c933d0610  int3
00007e2c933d0611  call 0x00007E2C932E2BA0
00007e2c933d0616  jmp 0x00007E2C933D050F
00007e2c933d061b  call 0x00007E2C932E1920
00007e2c933d0620  jmp 0x00007E2C933D0518
00007e2c933d0625  call 0x00007E2C9320DFE0
00007e2c933d062a  jmp 0x00007E2C933D058F
00007e2c933d062f  call 0x00007E2C932E2BA0
00007e2c933d0634  jmp 0x00007E2C933D059D
00007e2c933d0639  call 0x00007E2C932E2BA0
00007e2c933d063e  jmp 0x00007E2C933D05AB
00007e2c933d0643  call 0x00007E2C932E2BA0
00007e2c933d0648  jmp 0x00007E2C933D05B9
00007e2c933d064d  call 0x00007E2C932E2BA0
00007e2c933d0652  jmp 0x00007E2C933D05C7
00007e2c933d0657  call 0x00007E2C932E2BA0
00007e2c933d065c  jmp 0x00007E2C933D05D5
00007e2c933d0661  call 0x00007E2C932D5EB0
00007e2c933d0666  jmp 0x00007E2C933D05E0
00007e2c933d066b  int3
00007e2c933d066c  nop [rax], eax
00007e2c933d0670  mov rax, [r15+0xF8]
00007e2c933d0677  lea r14, [rax+0x140]
00007e2c933d067e  mov r12, [r13+r14*1]
00007e2c933d0683  lea r14, [rax+0x148]
00007e2c933d068a  mov r11, [r13+r14*1]
00007e2c933d068f  mov [r15+0xA0], r12
00007e2c933d0696  mov [r15+0x98], r11
00007e2c933d069d  lea r14, [rax+0x130]
00007e2c933d06a4  mov r12, [r13+r14*1]
00007e2c933d06a9  lea r14, [rax+0x138]
00007e2c933d06b0  mov r11, [r13+r14*1]
00007e2c933d06b5  mov [r15+0xB0], r12
00007e2c933d06bc  mov [r15+0xA8], r11
00007e2c933d06c3  lea r14, [rax+0x120]
00007e2c933d06ca  mov r12, [r13+r14*1]
00007e2c933d06cf  lea r14, [rax+0x128]
00007e2c933d06d6  mov r11, [r13+r14*1]
00007e2c933d06db  mov [r15+0xC0], r12
00007e2c933d06e2  mov [r15+0xB8], r11
00007e2c933d06e9  lea r14, [rax+0x110]
00007e2c933d06f0  mov r12, [r13+r14*1]
00007e2c933d06f5  lea r14, [rax+0x118]
00007e2c933d06fc  mov r11, [r13+r14*1]
00007e2c933d0701  mov [r15+0xD0], r12
00007e2c933d0708  mov [r15+0xC8], r11
00007e2c933d070f  lea r14, [rax+0x100]
00007e2c933d0716  mov r12, [r13+r14*1]
00007e2c933d071b  lea r14, [rax+0x108]
00007e2c933d0722  mov r11, [r13+r14*1]
00007e2c933d0727  mov [r15+0xE8], r12
00007e2c933d072e  mov [r15+0xD8], r11
00007e2c933d0735  lea r14, [rax+0x150]
00007e2c933d073c  mov [r15+0xF8], r14
00007e2c933d0743  mov rax, [r15+0xF0]
00007e2c933d074a  mov [r15+0x100], rax
00007e2c933d0751  jmp 0x00007E2C933CE5C0
00007e2c933d0756  int3
00007e2c933d0757  call 0x00007E2C932E27E0
00007e2c933d075c  jmp 0x00007E2C933D0683
00007e2c933d0761  call 0x00007E2C932E1570
00007e2c933d0766  jmp 0x00007E2C933D068F
00007e2c933d076b  call 0x00007E2C932E27E0
00007e2c933d0770  jmp 0x00007E2C933D06A9
00007e2c933d0775  call 0x00007E2C932E1570
00007e2c933d077a  jmp 0x00007E2C933D06B5
00007e2c933d077f  call 0x00007E2C932E27E0
00007e2c933d0784  jmp 0x00007E2C933D06CF
00007e2c933d0789  call 0x00007E2C932E1570
00007e2c933d078e  jmp 0x00007E2C933D06DB
00007e2c933d0793  call 0x00007E2C932E27E0
00007e2c933d0798  jmp 0x00007E2C933D06F5
00007e2c933d079d  call 0x00007E2C932E1570
00007e2c933d07a2  jmp 0x00007E2C933D0701
00007e2c933d07a7  call 0x00007E2C932E27E0
00007e2c933d07ac  jmp 0x00007E2C933D071B
00007e2c933d07b1  call 0x00007E2C932E1570
00007e2c933d07b6  jmp 0x00007E2C933D0727
00007e2c933d07bb  int3
00007e2c933d07bc  nop [rax], eax
00007e2c933d07c0  mov eax, [r15+0xA0]
00007e2c933d07c7  mov [rsp+0x10], eax
00007e2c933d07cb  xor eax, eax
00007e2c933d07cd  mov r14d, [rsp+0x10]
00007e2c933d07d2  sub r14d, 0x01
00007e2c933d07d6  cmc
00007e2c933d07d7  lahf
00007e2c933d07d8  seto al
00007e2c933d07db  mov [r15+0x108], eax
00007e2c933d07e2  mov r14d, r14d
00007e2c933d07e5  mov [r15+0xA0], r14
00007e2c933d07ec  mov eax, [r15+0x108]
00007e2c933d07f3  sahf
00007e2c933d07f4  jnz 0x00007E2C933D0826
00007e2c933d07f6  cmp dword ptr [r15+0x318], 0x00
00007e2c933d07fe  jz 0x00007E2C933D0900
00007e2c933d0804  nop [rax+rax*1], ax
00007e2c933d080d  nop [rax+rax*1], eax
00007e2c933d0815  mov eax, 0x41028C
00007e2c933d081a  mov [r15+0x100], rax
00007e2c933d0821  jmp 0x00007E2C931FE110
00007e2c933d0826  cmp dword ptr [r15+0x318], 0x00
00007e2c933d082e  jz 0x00007E2C933D0860
00007e2c933d0834  nop [rax+rax*1], ax
00007e2c933d083d  nop [rax+rax*1], eax
00007e2c933d0845  mov eax, 0x410274
00007e2c933d084a  mov [r15+0x100], rax
00007e2c933d0851  jmp 0x00007E2C931FE110
00007e2c933d0856  int3
00007e2c933d0857  int3
00007e2c933d0858  nop [rax+rax*1], eax
00007e2c933d0860  mov rax, [r15+0xF8]
00007e2c933d0867  lea r14, [rax+0x100]
00007e2c933d086e  mov [r15], r14
00007e2c933d0871  mov rax, [r15+0x98]
00007e2c933d0878  mov [r15+0x08], rax
00007e2c933d087c  mov qword ptr [r15+0x10], 0x12C
00007e2c933d0884  mov qword ptr [r15+0xF0], 0x410284
00007e2c933d088f  mov r14d, [r15+0x320]
00007e2c933d0896  mov eax, 0x410284
00007e2c933d089b  mov rcx, 0x7E2C933D07C0
00007e2c933d08a5  mov [r15+r14*8+0x328], rax
00007e2c933d08ad  mov [r15+r14*8+0x368], rcx
00007e2c933d08b5  add r14d, 0x01
00007e2c933d08b9  and r14d, 0x07
00007e2c933d08bd  mov [r15+0x320], r14d
00007e2c933d08c4  cmp dword ptr [r15+0x318], 0x00
00007e2c933d08cc  jz 0x00007E2C933CED70
00007e2c933d08d2  nop [rax+rax*1], ax
00007e2c933d08db  nop [rax+rax*1], eax
00007e2c933d08e3  mov eax, 0x410728
00007e2c933d08e8  mov [r15+0x100], rax
00007e2c933d08ef  jmp 0x00007E2C931FE110
00007e2c933d08f4  int3
00007e2c933d08f5  int3
00007e2c933d08f6  nop [rax+rax*1], ax
00007e2c933d08ff  nop
00007e2c933d0900  mov rax, [r15+0xF8]
00007e2c933d0907  lea r14, [rax+0x120]
00007e2c933d090e  mov r12, [r13+r14*1]
00007e2c933d0913  mov [r15+0x98], r12
00007e2c933d091a  mov qword ptr [r15+0x40], 0x80
00007e2c933d0922  lea r14, [rax+0x100]
00007e2c933d0929  mov [r15], r14
00007e2c933d092c  lea r14, [rax+0x17C]
00007e2c933d0933  mov [r15+0x08], r14
00007e2c933d0937  mov qword ptr [r15+0x10], 0x01
00007e2c933d093f  lea r14, [rax+0x17C]
00007e2c933d0946  mov eax, 0x80
00007e2c933d094b  mov [r13+r14*1], al
00007e2c933d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007e2c933d095b  mov r14d, [r15+0x320]
00007e2c933d0962  mov eax, 0x4102A8
00007e2c933d0967  mov rcx, 0x7E2C933D09E0
00007e2c933d0971  mov [r15+r14*8+0x328], rax
00007e2c933d0979  mov [r15+r14*8+0x368], rcx
00007e2c933d0981  add r14d, 0x01
00007e2c933d0985  and r14d, 0x07
00007e2c933d0989  mov [r15+0x320], r14d
00007e2c933d0990  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0998  jz 0x00007E2C933CED70
00007e2c933d099e  nop [rax+rax*1], ax
00007e2c933d09a7  nop [rax+rax*1], eax
00007e2c933d09af  mov eax, 0x410728
00007e2c933d09b4  mov [r15+0x100], rax
00007e2c933d09bb  jmp 0x00007E2C931FE110
00007e2c933d09c0  int3
00007e2c933d09c1  call 0x00007E2C932E27E0
00007e2c933d09c6  jmp 0x00007E2C933D0913
00007e2c933d09cb  call 0x00007E2C932D5AF0
00007e2c933d09d0  jmp 0x00007E2C933D0950
00007e2c933d09d5  int3
00007e2c933d09d6  nop [rax+rax*1], ax
00007e2c933d09df  nop
00007e2c933d09e0  mov rax, [r15+0xF8]
00007e2c933d09e7  lea r14, [rax+0x168]
00007e2c933d09ee  mov r12, [r13+r14*1]
00007e2c933d09f3  mov [r15+0x40], r12
00007e2c933d09f7  lea r14, [rax+0x178]
00007e2c933d09fe  xor eax, eax
00007e2c933d0a00  mov [r13+r14*1], al
00007e2c933d0a05  xor eax, eax
00007e2c933d0a07  mov r14d, 0x38
00007e2c933d0a0d  cmp r12, r14
00007e2c933d0a10  cmc
00007e2c933d0a11  lahf
00007e2c933d0a12  seto al
00007e2c933d0a15  mov [r15+0x108], eax
00007e2c933d0a1c  mov eax, [r15+0x108]
00007e2c933d0a23  sahf
00007e2c933d0a24  jz 0x00007E2C933D0A56
00007e2c933d0a26  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0a2e  jz 0x00007E2C933D0AA0
00007e2c933d0a34  nop [rax+rax*1], ax
00007e2c933d0a3d  nop [rax+rax*1], eax
00007e2c933d0a45  mov eax, 0x4102B8
00007e2c933d0a4a  mov [r15+0x100], rax
00007e2c933d0a51  jmp 0x00007E2C931FE110
00007e2c933d0a56  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0a5e  jz 0x00007E2C933D0BF0
00007e2c933d0a64  nop [rax+rax*1], ax
00007e2c933d0a6d  nop [rax+rax*1], eax
00007e2c933d0a75  mov eax, 0x4102D4
00007e2c933d0a7a  mov [r15+0x100], rax
00007e2c933d0a81  jmp 0x00007E2C931FE110
00007e2c933d0a86  int3
00007e2c933d0a87  call 0x00007E2C932E27E0
00007e2c933d0a8c  jmp 0x00007E2C933D09F3
00007e2c933d0a91  call 0x00007E2C932D5AF0
00007e2c933d0a96  jmp 0x00007E2C933D0A05
00007e2c933d0a9b  int3
00007e2c933d0a9c  nop [rax], eax
00007e2c933d0aa0  mov rax, [r15+0xF8]
00007e2c933d0aa7  lea r14, [rax+0x100]
00007e2c933d0aae  mov [r15], r14
00007e2c933d0ab1  lea r14, [rax+0x178]
00007e2c933d0ab8  mov [r15+0x08], r14
00007e2c933d0abc  mov qword ptr [r15+0x10], 0x01
00007e2c933d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007e2c933d0acf  mov r14d, [r15+0x320]
00007e2c933d0ad6  mov eax, 0x4102C8
00007e2c933d0adb  mov rcx, 0x7E2C933D0B40
00007e2c933d0ae5  mov [r15+r14*8+0x328], rax
00007e2c933d0aed  mov [r15+r14*8+0x368], rcx
00007e2c933d0af5  add r14d, 0x01
00007e2c933d0af9  and r14d, 0x07
00007e2c933d0afd  mov [r15+0x320], r14d
00007e2c933d0b04  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0b0c  jz 0x00007E2C933CED70
00007e2c933d0b12  nop [rax+rax*1], ax
00007e2c933d0b1b  nop [rax+rax*1], eax
00007e2c933d0b23  mov eax, 0x410728
00007e2c933d0b28  mov [r15+0x100], rax
00007e2c933d0b2f  jmp 0x00007E2C931FE110
00007e2c933d0b34  int3
00007e2c933d0b35  int3
00007e2c933d0b36  nop [rax+rax*1], ax
00007e2c933d0b3f  nop
00007e2c933d0b40  mov rax, [r15+0xF8]
00007e2c933d0b47  lea r14, [rax+0x168]
00007e2c933d0b4e  mov rax, [r13+r14*1]
00007e2c933d0b53  mov [r15+0x40], rax
00007e2c933d0b57  mov [rsp+0x10], rax
00007e2c933d0b5c  xor eax, eax
00007e2c933d0b5e  mov r14, [rsp+0x10]
00007e2c933d0b63  mov r12d, 0x38
00007e2c933d0b69  cmp r14, r12
00007e2c933d0b6c  cmc
00007e2c933d0b6d  lahf
00007e2c933d0b6e  seto al
00007e2c933d0b71  mov [r15+0x108], eax
00007e2c933d0b78  mov eax, [r15+0x108]
00007e2c933d0b7f  sahf
00007e2c933d0b80  jnz 0x00007E2C933D0BB2
00007e2c933d0b82  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0b8a  jz 0x00007E2C933D0BF0
00007e2c933d0b90  nop [rax+rax*1], ax
00007e2c933d0b99  nop [rax+rax*1], eax
00007e2c933d0ba1  mov eax, 0x4102D4
00007e2c933d0ba6  mov [r15+0x100], rax
00007e2c933d0bad  jmp 0x00007E2C931FE110
00007e2c933d0bb2  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0bba  jz 0x00007E2C933D0AA0
00007e2c933d0bc0  nop [rax+rax*1], ax
00007e2c933d0bc9  nop [rax+rax*1], eax
00007e2c933d0bd1  mov eax, 0x4102B8
00007e2c933d0bd6  mov [r15+0x100], rax
00007e2c933d0bdd  jmp 0x00007E2C931FE110
00007e2c933d0be2  int3
00007e2c933d0be3  call 0x00007E2C932D59C0
00007e2c933d0be8  jmp 0x00007E2C933D0B53
00007e2c933d0bed  int3
00007e2c933d0bee  nop
00007e2c933d0bf0  mov rax, [r15+0x98]
00007e2c933d0bf7  rorx r14, rax, 0x3D
00007e2c933d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007e2c933d0c01  mov rax, [r15+0xF8]
00007e2c933d0c08  lea r12, [rax+0x100]
00007e2c933d0c0f  mov [r15], r12
00007e2c933d0c12  lea r12, [rax+0x170]
00007e2c933d0c19  mov [r15+0x08], r12
00007e2c933d0c1d  mov qword ptr [r15+0x10], 0x08
00007e2c933d0c25  bswap r14
00007e2c933d0c28  mov [r15+0x40], r14
00007e2c933d0c2c  lea r12, [rax+0x170]
00007e2c933d0c33  mov [r13+r12*1], r14
00007e2c933d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007e2c933d0c43  mov r14d, [r15+0x320]
00007e2c933d0c4a  mov eax, 0x4102F0
00007e2c933d0c4f  mov rcx, 0x7E2C933D0CC0
00007e2c933d0c59  mov [r15+r14*8+0x328], rax
00007e2c933d0c61  mov [r15+r14*8+0x368], rcx
00007e2c933d0c69  add r14d, 0x01
00007e2c933d0c6d  and r14d, 0x07
00007e2c933d0c71  mov [r15+0x320], r14d
00007e2c933d0c78  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0c80  jz 0x00007E2C933CED70
00007e2c933d0c86  nop [rax+rax*1], ax
00007e2c933d0c8f  nop [rax+rax*1], eax
00007e2c933d0c97  mov eax, 0x410728
00007e2c933d0c9c  mov [r15+0x100], rax
00007e2c933d0ca3  jmp 0x00007E2C931FE110
00007e2c933d0ca8  int3
00007e2c933d0ca9  call 0x00007E2C932C3FE0
00007e2c933d0cae  jmp 0x00007E2C933D0C38
00007e2c933d0cb3  int3
00007e2c933d0cb4  nop [rax+rax*1], ax
00007e2c933d0cbd  nop [rax], eax
00007e2c933d0cc0  mov rax, [r15+0xF8]
00007e2c933d0cc7  lea r14, [rax+0x100]
00007e2c933d0cce  mov r12d, [r13+r14*1]
00007e2c933d0cd3  lea r14, [rax+0x104]
00007e2c933d0cda  mov r11d, [r13+r14*1]
00007e2c933d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007e2c933d0ce7  lea r14, [rax+0x108]
00007e2c933d0cee  mov r10d, [r13+r14*1]
00007e2c933d0cf3  lea r14, [rax+0x10C]
00007e2c933d0cfa  mov r9d, [r13+r14*1]
00007e2c933d0cff  bswap r12d
00007e2c933d0d02  bswap r11d
00007e2c933d0d05  mov qword ptr [r15+0xA0], 0x00
00007e2c933d0d10  mov r14d, 0x430C90
00007e2c933d0d16  mov [r13+r14*1], r12d
00007e2c933d0d1b  mov r14d, 0x430C94
00007e2c933d0d21  mov [r13+r14*1], r11d
00007e2c933d0d26  bswap r10d
00007e2c933d0d29  lea r14, [rax+0x110]
00007e2c933d0d30  mov r12d, [r13+r14*1]
00007e2c933d0d35  bswap r9d
00007e2c933d0d38  lea r14, [rax+0x114]
00007e2c933d0d3f  mov r11d, [r13+r14*1]
00007e2c933d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007e2c933d0d4f  mov r14d, 0x430C98
00007e2c933d0d55  mov [r13+r14*1], r10d
00007e2c933d0d5a  mov r14d, 0x430C9C
00007e2c933d0d60  mov [r13+r14*1], r9d
00007e2c933d0d65  bswap r12d
00007e2c933d0d68  lea r14, [rax+0x118]
00007e2c933d0d6f  mov r10d, [r13+r14*1]
00007e2c933d0d74  bswap r11d
00007e2c933d0d77  mov [rsp+0x10], r11d
00007e2c933d0d7c  mov r11d, r11d
00007e2c933d0d7f  mov [r15+0x58], r11
00007e2c933d0d83  lea r14, [rax+0x11C]
00007e2c933d0d8a  mov eax, [r13+r14*1]
00007e2c933d0d8f  mov [rsp+0x20], eax
00007e2c933d0d93  mov eax, eax
00007e2c933d0d95  mov [r15+0x60], rax
00007e2c933d0d99  mov eax, 0x430CA0
00007e2c933d0d9e  mov [r13+rax*1], r12d
00007e2c933d0da3  mov eax, 0x430CA4
00007e2c933d0da8  mov r14d, [rsp+0x10]
00007e2c933d0dad  mov [r13+rax*1], r14d
00007e2c933d0db2  bswap r10d
00007e2c933d0db5  mov [rsp+0x10], r10d
00007e2c933d0dba  mov r10d, r10d
00007e2c933d0dbd  mov [r15+0x40], r10
00007e2c933d0dc1  mov eax, [rsp+0x20]
00007e2c933d0dc5  bswap eax
00007e2c933d0dc7  mov [rsp+0x20], eax
00007e2c933d0dcb  mov eax, eax
00007e2c933d0dcd  mov [r15+0x50], rax
00007e2c933d0dd1  mov eax, 0x430CA8
00007e2c933d0dd6  mov r14d, [rsp+0x10]
00007e2c933d0ddb  mov [r13+rax*1], r14d
00007e2c933d0de0  mov eax, 0x430CAC
00007e2c933d0de5  mov r14d, [rsp+0x20]
00007e2c933d0dea  mov [r13+rax*1], r14d
00007e2c933d0def  mov eax, [r15+0xA0]
00007e2c933d0df6  lea r14d, [eax+0x11]
00007e2c933d0dfb  mov r14d, r14d
00007e2c933d0dfe  mov [r15], r14
00007e2c933d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007e2c933d0e0c  mov r14d, [r15+0x320]
00007e2c933d0e13  mov eax, 0x41035C
00007e2c933d0e18  mov rcx, 0x7E2C933D0F90
00007e2c933d0e22  mov [r15+r14*8+0x328], rax
00007e2c933d0e2a  mov [r15+r14*8+0x368], rcx
00007e2c933d0e32  add r14d, 0x01
00007e2c933d0e36  and r14d, 0x07
00007e2c933d0e3a  mov [r15+0x320], r14d
00007e2c933d0e41  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0e49  jz 0x00007E2C933D0F20
00007e2c933d0e4f  nop [rax+rax*1], ax
00007e2c933d0e58  nop [rax+rax*1], eax
00007e2c933d0e60  mov eax, 0x4109A4
00007e2c933d0e65  mov [r15+0x100], rax
00007e2c933d0e6c  jmp 0x00007E2C931FE110
00007e2c933d0e71  int3
00007e2c933d0e72  call 0x00007E2C932E26A0
00007e2c933d0e77  jmp 0x00007E2C933D0CD3
00007e2c933d0e7c  call 0x00007E2C932E1430
00007e2c933d0e81  jmp 0x00007E2C933D0CDF
00007e2c933d0e86  call 0x00007E2C932E01C0
00007e2c933d0e8b  jmp 0x00007E2C933D0CF3
00007e2c933d0e90  call 0x00007E2C932DEF50
00007e2c933d0e95  jmp 0x00007E2C933D0CFF
00007e2c933d0e9a  call 0x00007E2C932E2BA0
00007e2c933d0e9f  jmp 0x00007E2C933D0D1B
00007e2c933d0ea4  call 0x00007E2C932E1920
00007e2c933d0ea9  jmp 0x00007E2C933D0D26
00007e2c933d0eae  call 0x00007E2C932E26A0
00007e2c933d0eb3  jmp 0x00007E2C933D0D35
00007e2c933d0eb8  call 0x00007E2C932E1430
00007e2c933d0ebd  jmp 0x00007E2C933D0D44
00007e2c933d0ec2  call 0x00007E2C932E06B0
00007e2c933d0ec7  jmp 0x00007E2C933D0D5A
00007e2c933d0ecc  call 0x00007E2C932DF440
00007e2c933d0ed1  jmp 0x00007E2C933D0D65
00007e2c933d0ed6  call 0x00007E2C932E01C0
00007e2c933d0edb  jmp 0x00007E2C933D0D74
00007e2c933d0ee0  call 0x00007E2C932D5890
00007e2c933d0ee5  jmp 0x00007E2C933D0D8F
00007e2c933d0eea  call 0x00007E2C9320BAE0
00007e2c933d0eef  jmp 0x00007E2C933D0DA3
00007e2c933d0ef4  call 0x00007E2C9320DFE0
00007e2c933d0ef9  jmp 0x00007E2C933D0DB2
00007e2c933d0efe  call 0x00007E2C9320DFE0
00007e2c933d0f03  jmp 0x00007E2C933D0DE0
00007e2c933d0f08  call 0x00007E2C9320DFE0
00007e2c933d0f0d  jmp 0x00007E2C933D0DEF
00007e2c933d0f12  int3
00007e2c933d0f13  nop [rax+rax*1], ax
00007e2c933d0f1c  nop [rax], eax
00007e2c933d0f20  mov eax, [r15]
00007e2c933d0f23  mov [rsp+0x10], eax
00007e2c933d0f27  shr eax, 0x10
00007e2c933d0f2a  mov r14d, [rsp+0x10]
00007e2c933d0f2f  xor r14d, eax
00007e2c933d0f32  imul r14d, r14d, 0x7FEB352D
00007e2c933d0f39  mov eax, 0x846CA68B
00007e2c933d0f3e  mov eax, eax
00007e2c933d0f40  mov [r15+0x48], rax
00007e2c933d0f44  mov [rsp+0x10], r14d
00007e2c933d0f49  shr r14d, 0x0F
00007e2c933d0f4d  mov eax, [rsp+0x10]
00007e2c933d0f51  xor eax, r14d
00007e2c933d0f54  imul eax, eax, 0x846CA68B
00007e2c933d0f5a  mov [rsp+0x10], eax
00007e2c933d0f5e  mov eax, eax
00007e2c933d0f60  mov [r15+0x40], rax
00007e2c933d0f64  mov eax, [rsp+0x10]
00007e2c933d0f68  shr eax, 0x10
00007e2c933d0f6b  mov r14d, [rsp+0x10]
00007e2c933d0f70  xor r14d, eax
00007e2c933d0f73  mov r14d, r14d
00007e2c933d0f76  mov [r15], r14
00007e2c933d0f79  mov rax, [r15+0xF0]
00007e2c933d0f80  mov [r15+0x100], rax
00007e2c933d0f87  jmp 0x00007E2C933CE5C0
00007e2c933d0f8c  int3
00007e2c933d0f8d  int3
00007e2c933d0f8e  nop
00007e2c933d0f90  mov rax, [r15+0xA0]
00007e2c933d0f97  mov [rsp+0x10], rax
00007e2c933d0f9c  shl rax, 0x02
00007e2c933d0fa0  mov r14, [r15+0x98]
00007e2c933d0fa7  lea r12, [r14+rax*1]
00007e2c933d0fab  mov eax, [r15]
00007e2c933d0fae  mov [r13+r12*1], eax
00007e2c933d0fb3  mov rax, [rsp+0x10]
00007e2c933d0fb8  lea r14, [rax+0x01]
00007e2c933d0fbc  mov [r15+0xA0], r14
00007e2c933d0fc3  xor eax, eax
00007e2c933d0fc5  mov r12d, 0x400
00007e2c933d0fcb  cmp r14, r12
00007e2c933d0fce  cmc
00007e2c933d0fcf  lahf
00007e2c933d0fd0  seto al
00007e2c933d0fd3  mov [r15+0x108], eax
00007e2c933d0fda  mov eax, [r15+0x108]
00007e2c933d0fe1  sahf
00007e2c933d0fe2  jnz 0x00007E2C933D1014
00007e2c933d0fe4  cmp dword ptr [r15+0x318], 0x00
00007e2c933d0fec  jz 0x00007E2C933D10E0
00007e2c933d0ff2  nop [rax+rax*1], ax
00007e2c933d0ffb  nop [rax+rax*1], eax
00007e2c933d1003  mov eax, 0x41036C
00007e2c933d1008  mov [r15+0x100], rax
00007e2c933d100f  jmp 0x00007E2C931FE110
00007e2c933d1014  cmp dword ptr [r15+0x318], 0x00
00007e2c933d101c  jz 0x00007E2C933D1050
00007e2c933d1022  nop [rax+rax*1], ax
00007e2c933d102b  nop [rax+rax*1], eax
00007e2c933d1033  mov eax, 0x410354
00007e2c933d1038  mov [r15+0x100], rax
00007e2c933d103f  jmp 0x00007E2C931FE110
00007e2c933d1044  int3
00007e2c933d1045  call 0x00007E2C932B4B70
00007e2c933d104a  jmp 0x00007E2C933D0FB3
00007e2c933d104f  int3
00007e2c933d1050  mov eax, [r15+0xA0]
00007e2c933d1057  lea r14d, [eax+0x11]
00007e2c933d105c  mov r14d, r14d
00007e2c933d105f  mov [r15], r14
00007e2c933d1062  mov qword ptr [r15+0xF0], 0x41035C
00007e2c933d106d  mov r14d, [r15+0x320]
00007e2c933d1074  mov eax, 0x41035C
00007e2c933d1079  mov rcx, 0x7E2C933D0F90
00007e2c933d1083  mov [r15+r14*8+0x328], rax
00007e2c933d108b  mov [r15+r14*8+0x368], rcx
00007e2c933d1093  add r14d, 0x01
00007e2c933d1097  and r14d, 0x07
00007e2c933d109b  mov [r15+0x320], r14d
00007e2c933d10a2  cmp dword ptr [r15+0x318], 0x00
00007e2c933d10aa  jz 0x00007E2C933D0F20
00007e2c933d10b0  nop [rax+rax*1], ax
00007e2c933d10b9  nop [rax+rax*1], eax
00007e2c933d10c1  mov eax, 0x4109A4
00007e2c933d10c6  mov [r15+0x100], rax
00007e2c933d10cd  jmp 0x00007E2C931FE110
00007e2c933d10d2  int3
00007e2c933d10d3  int3
00007e2c933d10d4  nop [rax+rax*1], ax
00007e2c933d10dd  nop [rax], eax
00007e2c933d10e0  mov qword ptr [r15+0x40], 0x01
00007e2c933d10e8  cmp dword ptr [r15+0x318], 0x00
00007e2c933d10f0  jz 0x00007E2C933D1120
00007e2c933d10f6  nop [rax+rax*1], ax
00007e2c933d10ff  nop [rax+rax*1], eax
00007e2c933d1107  mov eax, 0x410388
00007e2c933d110c  mov [r15+0x100], rax
00007e2c933d1113  jmp 0x00007E2C931FE110
00007e2c933d1118  int3
00007e2c933d1119  int3
00007e2c933d111a  nop [rax+rax*1], ax
00007e2c933d1120  mov rax, [r15+0x40]
00007e2c933d1124  mov [rsp+0x10], rax
00007e2c933d1129  shl rax, 0x02
00007e2c933d112d  mov r14, [r15+0x98]
00007e2c933d1134  lea r12, [r14+rax*1]
00007e2c933d1138  mov eax, [r13+r12*1]
00007e2c933d113d  mov [rsp+0x20], eax
00007e2c933d1141  mov eax, eax
00007e2c933d1143  mov [r15+0x48], rax
00007e2c933d1147  mov rax, [rsp+0x10]
00007e2c933d114c  mov [r15+0x50], rax
00007e2c933d1150  mov eax, [r15+0x50]
00007e2c933d1154  lea r12d, [eax-0x01]
00007e2c933d1159  mov r12d, r12d
00007e2c933d115c  mov [r15+0x58], r12
00007e2c933d1160  mov rax, [r15+0x58]
00007e2c933d1164  mov r12d, eax
00007e2c933d1167  mov r12d, r12d
00007e2c933d116a  shl r12, 0x02
00007e2c933d116e  lea rax, [r14+r12*1]
00007e2c933d1172  mov r14d, [r13+rax*1]
00007e2c933d1177  mov [rsp+0x10], r14d
00007e2c933d117c  mov r14d, r14d
00007e2c933d117f  mov [r15+0x60], r14
00007e2c933d1183  xor eax, eax
00007e2c933d1185  mov r14d, [rsp+0x10]
00007e2c933d118a  mov r12d, [rsp+0x20]
00007e2c933d118f  cmp r14d, r12d
00007e2c933d1192  cmc
00007e2c933d1193  lahf
00007e2c933d1194  seto al
00007e2c933d1197  mov [r15+0x108], eax
00007e2c933d119e  mov eax, [r15+0x108]
00007e2c933d11a5  sahf
00007e2c933d11a6  cmc
00007e2c933d11a7  jbe 0x00007E2C933D11D9
00007e2c933d11a9  cmp dword ptr [r15+0x318], 0x00
00007e2c933d11b1  jz 0x00007E2C933D1220
00007e2c933d11b7  nop [rax+rax*1], ax
00007e2c933d11c0  nop [rax+rax*1], eax
00007e2c933d11c8  mov eax, 0x4103A0
00007e2c933d11cd  mov [r15+0x100], rax
00007e2c933d11d4  jmp 0x00007E2C931FE110
00007e2c933d11d9  cmp dword ptr [r15+0x318], 0x00
00007e2c933d11e1  jz 0x00007E2C933D14C0
00007e2c933d11e7  nop [rax+rax*1], ax
00007e2c933d11f0  nop [rax+rax*1], eax
00007e2c933d11f8  mov eax, 0x410378
00007e2c933d11fd  mov [r15+0x100], rax
00007e2c933d1204  jmp 0x00007E2C931FE110
00007e2c933d1209  int3
00007e2c933d120a  call 0x00007E2C932B4690
00007e2c933d120f  jmp 0x00007E2C933D113D
00007e2c933d1214  call 0x00007E2C9320DAE0
00007e2c933d1219  jmp 0x00007E2C933D1177
00007e2c933d121e  int3
00007e2c933d121f  nop
00007e2c933d1220  mov rax, [r15+0x50]
00007e2c933d1224  mov [rsp+0x10], rax
00007e2c933d1229  shl rax, 0x02
00007e2c933d122d  mov r14, [r15+0x98]
00007e2c933d1234  lea r12, [r14+rax*1]
00007e2c933d1238  mov eax, [r15+0x60]
00007e2c933d123c  mov [r13+r12*1], eax
00007e2c933d1241  mov rax, [rsp+0x10]
00007e2c933d1246  lea r14, [rax-0x01]
00007e2c933d124a  mov [r15+0x50], r14
00007e2c933d124e  mov rax, [r15+0x58]
00007e2c933d1252  test rax, rax
00007e2c933d1255  setz al
00007e2c933d1258  movzx rax, al
00007e2c933d125c  mov [rsp+0x414], al
00007e2c933d1263  cmp byte ptr [rsp+0x414], 0x00
00007e2c933d126b  jz 0x00007E2C933D129D
00007e2c933d126d  cmp dword ptr [r15+0x318], 0x00
00007e2c933d1275  jz 0x00007E2C933D12E0
00007e2c933d127b  nop [rax+rax*1], ax
00007e2c933d1284  nop [rax+rax*1], eax
00007e2c933d128c  mov eax, 0x4103AC
00007e2c933d1291  mov [r15+0x100], rax
00007e2c933d1298  jmp 0x00007E2C931FE110
00007e2c933d129d  cmp dword ptr [r15+0x318], 0x00
00007e2c933d12a5  jz 0x00007E2C933D13E0
00007e2c933d12ab  nop [rax+rax*1], ax
00007e2c933d12b4  nop [rax+rax*1], eax
00007e2c933d12bc  mov eax, 0x410390
00007e2c933d12c1  mov [r15+0x100], rax
00007e2c933d12c8  jmp 0x00007E2C931FE110
00007e2c933d12cd  int3
00007e2c933d12ce  call 0x00007E2C932B4B70
00007e2c933d12d3  jmp 0x00007E2C933D1241
00007e2c933d12d8  int3
00007e2c933d12d9  nop [rax], eax
00007e2c933d12e0  cmp dword ptr [r15+0x318], 0x00
00007e2c933d12e8  jz 0x00007E2C933D1320
00007e2c933d12ee  nop [rax+rax*1], ax
00007e2c933d12f7  nop [rax+rax*1], eax
00007e2c933d12ff  mov eax, 0x410374
00007e2c933d1304  mov [r15+0x100], rax
00007e2c933d130b  jmp 0x00007E2C931FE110
00007e2c933d1310  int3
00007e2c933d1311  int3
00007e2c933d1312  nop [rax+rax*1], ax
00007e2c933d131b  nop [rax+rax*1], eax
00007e2c933d1320  mov qword ptr [r15+0x50], 0x00
00007e2c933d1328  mov rax, [r15+0x40]
00007e2c933d132c  lea r14, [rax+0x01]
00007e2c933d1330  mov [r15+0x40], r14
00007e2c933d1334  mov rax, [r15+0x98]
00007e2c933d133b  mov r12d, [r15+0x48]
00007e2c933d133f  mov [r13+rax*1], r12d
00007e2c933d1344  xor eax, eax
00007e2c933d1346  mov r12d, 0x400
00007e2c933d134c  cmp r14, r12
00007e2c933d134f  cmc
00007e2c933d1350  lahf
00007e2c933d1351  seto al
00007e2c933d1354  mov [r15+0x108], eax
00007e2c933d135b  mov eax, [r15+0x108]
00007e2c933d1362  sahf
00007e2c933d1363  jz 0x00007E2C933D1395
00007e2c933d1365  cmp dword ptr [r15+0x318], 0x00
00007e2c933d136d  jz 0x00007E2C933D1120
00007e2c933d1373  nop [rax+rax*1], ax
00007e2c933d137c  nop [rax+rax*1], eax
00007e2c933d1384  mov eax, 0x410388
00007e2c933d1389  mov [r15+0x100], rax
00007e2c933d1390  jmp 0x00007E2C931FE110
00007e2c933d1395  cmp dword ptr [r15+0x318], 0x00
00007e2c933d139d  jz 0x00007E2C933D1580
00007e2c933d13a3  nop [rax+rax*1], ax
00007e2c933d13ac  nop [rax+rax*1], eax
00007e2c933d13b4  mov eax, 0x4103B0
00007e2c933d13b9  mov [r15+0x100], rax
00007e2c933d13c0  jmp 0x00007E2C931FE110
00007e2c933d13c5  int3
00007e2c933d13c6  call 0x00007E2C9320BAE0
00007e2c933d13cb  jmp 0x00007E2C933D1344
00007e2c933d13d0  int3
00007e2c933d13d1  nop [rax+rax*1], ax
00007e2c933d13da  nop [rax+rax*1], ax
00007e2c933d13e0  mov eax, [r15+0x50]
00007e2c933d13e4  lea r14d, [eax-0x01]
00007e2c933d13e9  mov r14d, r14d
00007e2c933d13ec  mov [r15+0x58], r14
00007e2c933d13f0  mov rax, [r15+0x58]
00007e2c933d13f4  mov r14d, eax
00007e2c933d13f7  mov r14d, r14d
00007e2c933d13fa  shl r14, 0x02
00007e2c933d13fe  mov rax, [r15+0x98]
00007e2c933d1405  lea r12, [rax+r14*1]
00007e2c933d1409  mov eax, [r13+r12*1]
00007e2c933d140e  mov [rsp+0x10], eax
00007e2c933d1412  mov eax, eax
00007e2c933d1414  mov [r15+0x60], rax
00007e2c933d1418  mov eax, [r15+0x48]
00007e2c933d141c  mov [rsp+0x20], eax
00007e2c933d1420  xor eax, eax
00007e2c933d1422  mov r14d, [rsp+0x10]
00007e2c933d1427  mov r12d, [rsp+0x20]
00007e2c933d142c  cmp r14d, r12d
00007e2c933d142f  cmc
00007e2c933d1430  lahf
00007e2c933d1431  seto al
00007e2c933d1434  mov [r15+0x108], eax
00007e2c933d143b  mov eax, [r15+0x108]
00007e2c933d1442  sahf
00007e2c933d1443  cmc
00007e2c933d1444  jbe 0x00007E2C933D1476
00007e2c933d1446  cmp dword ptr [r15+0x318], 0x00
00007e2c933d144e  jz 0x00007E2C933D1220
00007e2c933d1454  nop [rax+rax*1], ax
00007e2c933d145d  nop [rax+rax*1], eax
00007e2c933d1465  mov eax, 0x4103A0
00007e2c933d146a  mov [r15+0x100], rax
00007e2c933d1471  jmp 0x00007E2C931FE110
00007e2c933d1476  cmp dword ptr [r15+0x318], 0x00
00007e2c933d147e  jz 0x00007E2C933D14C0
00007e2c933d1484  nop [rax+rax*1], ax
00007e2c933d148d  nop [rax+rax*1], eax
00007e2c933d1495  mov eax, 0x410378
00007e2c933d149a  mov [r15+0x100], rax
00007e2c933d14a1  jmp 0x00007E2C931FE110
00007e2c933d14a6  int3
00007e2c933d14a7  call 0x00007E2C932B4690
00007e2c933d14ac  jmp 0x00007E2C933D140E
00007e2c933d14b1  int3
00007e2c933d14b2  nop [rax+rax*1], ax
00007e2c933d14bb  nop [rax+rax*1], eax
00007e2c933d14c0  mov rax, [r15+0x40]
00007e2c933d14c4  lea r14, [rax+0x01]
00007e2c933d14c8  mov [r15+0x40], r14
00007e2c933d14cc  mov rax, [r15+0x50]
00007e2c933d14d0  mov r12d, eax
00007e2c933d14d3  mov r12d, r12d
00007e2c933d14d6  shl r12, 0x02
00007e2c933d14da  mov rax, [r15+0x98]
00007e2c933d14e1  lea r11, [rax+r12*1]
00007e2c933d14e5  mov eax, [r15+0x48]
00007e2c933d14e9  mov [r13+r11*1], eax
00007e2c933d14ee  xor eax, eax
00007e2c933d14f0  mov r12d, 0x400
00007e2c933d14f6  cmp r14, r12
00007e2c933d14f9  cmc
00007e2c933d14fa  lahf
00007e2c933d14fb  seto al
00007e2c933d14fe  mov [r15+0x108], eax
00007e2c933d1505  mov eax, [r15+0x108]
00007e2c933d150c  sahf
00007e2c933d150d  jz 0x00007E2C933D153F
00007e2c933d150f  cmp dword ptr [r15+0x318], 0x00
00007e2c933d1517  jz 0x00007E2C933D1120
00007e2c933d151d  nop [rax+rax*1], ax
00007e2c933d1526  nop [rax+rax*1], eax
00007e2c933d152e  mov eax, 0x410388
00007e2c933d1533  mov [r15+0x100], rax
00007e2c933d153a  jmp 0x00007E2C931FE110
00007e2c933d153f  cmp dword ptr [r15+0x318], 0x00
00007e2c933d1547  jz 0x00007E2C933D1580
00007e2c933d154d  nop [rax+rax*1], ax
00007e2c933d1556  nop [rax+rax*1], eax
00007e2c933d155e  mov eax, 0x4103B0
00007e2c933d1563  mov [r15+0x100], rax
00007e2c933d156a  jmp 0x00007E2C931FE110
00007e2c933d156f  int3
00007e2c933d1570  call 0x00007E2C932A4270
00007e2c933d1575  jmp 0x00007E2C933D14EE
00007e2c933d157a  int3
00007e2c933d157b  nop [rax+rax*1], eax
00007e2c933d1580  mov qword ptr [r15+0x40], 0x430000
00007e2c933d1588  mov eax, 0x430CB0
00007e2c933d158d  mov r14, [r13+rax*1]
00007e2c933d1592  mov rax, [r15+0x98]
00007e2c933d1599  mov r12d, [r13+rax*1]
00007e2c933d159e  lea r11, [rax+0x04]
00007e2c933d15a2  mov eax, [r13+r11*1]
00007e2c933d15a7  mov r12d, r12d
00007e2c933d15aa  mov [r15+0x68], r12
00007e2c933d15ae  mov eax, eax
00007e2c933d15b0  mov [r15+0x60], rax
00007e2c933d15b4  mov rax, [r15+0x68]
00007e2c933d15b8  mov [r15+0x68], rax
00007e2c933d15bc  mov qword ptr [r15+0x58], 0x02
00007e2c933d15c4  mov [rsp+0x10], rax
00007e2c933d15c9  xor eax, eax
00007e2c933d15cb  mov r12d, 0x02
00007e2c933d15d1  mov r11d, 0x400
00007e2c933d15d7  cmp r12, r11
00007e2c933d15da  cmc
00007e2c933d15db  lahf
00007e2c933d15dc  seto al
00007e2c933d15df  mov [r15+0x108], eax
00007e2c933d15e6  mov rax, [r15+0x60]
00007e2c933d15ea  mov r12d, 0x02
00007e2c933d15f0  imul rax, r12
00007e2c933d15f4  mov [r15+0x50], rax
00007e2c933d15f8  mov rax, [rsp+0x10]
00007e2c933d15fd  lea r12, [rax+r14*1]
00007e2c933d1601  mov [r15+0x48], r12
00007e2c933d1605  mov eax, [r15+0x108]
00007e2c933d160c  sahf
00007e2c933d160d  jnz 0x00007E2C933D163F
00007e2c933d160f  cmp dword ptr [r15+0x318], 0x00
00007e2c933d1617  jz 0x00007E2C933D17B0
00007e2c933d161d  nop [rax+rax*1], ax
00007e2c933d1626  nop [rax+rax*1], eax
00007e2c933d162e  mov eax, 0x4103E0
00007e2c933d1633  mov [r15+0x100], rax
00007e2c933d163a  jmp 0x00007E2C931FE110
00007e2c933d163f  cmp dword ptr [r15+0x318], 0x00
00007e2c933d1647  jz 0x00007E2C933D1690
00007e2c933d164d  nop [rax+rax*1], ax
00007e2c933d1656  nop [rax+rax*1], eax
00007e2c933d165e  mov eax, 0x4103C0
00007e2c933d1663  mov [r15+0x100], rax
00007e2c933d166a  jmp 0x00007E2C931FE110
00007e2c933d166f  int3
00007e2c933d1670  call 0x00007E2C9320DC20
00007e2c933d1675  jmp 0x00007E2C933D1592
00007e2c933d167a  call 0x00007E2C9320B5E0
00007e2c933d167f  jmp 0x00007E2C933D159E
00007e2c933d1684  call 0x00007E2C932A3D90
00007e2c933d1689  jmp 0x00007E2C933D15A7
00007e2c933d168e  int3
00007e2c933d168f  nop
00007e2c933d1690  mov rax, [r15+0x98]
00007e2c933d1697  mov r14, [r15+0x58]
00007e2c933d169b  mov [rsp+0x10], r14
00007e2c933d16a0  shl r14, 0x02
00007e2c933d16a4  lea r12, [rax+r14*1]
00007e2c933d16a8  mov eax, [r13+r12*1]
00007e2c933d16ad  lea r14, [r12+0x04]
00007e2c933d16b2  mov r12d, [r13+r14*1]
00007e2c933d16b7  mov eax, eax
00007e2c933d16b9  mov [r15+0x68], rax
00007e2c933d16bd  mov r12d, r12d
00007e2c933d16c0  mov [r15+0x60], r12
00007e2c933d16c4  mov rax, [r15+0x68]
00007e2c933d16c8  mov [rsp+0x20], rax
00007e2c933d16cd  mov r14, [rsp+0x10]
00007e2c933d16d2  imul rax, r14
00007e2c933d16d6  mov r12, [rsp+0x20]
00007e2c933d16db  lea r11, [r12+rax*1]
00007e2c933d16df  mov [r15+0x68], r11
00007e2c933d16e3  lea rax, [r14+0x02]
00007e2c933d16e7  mov [r15+0x58], rax
00007e2c933d16eb  mov [rsp+0x10], rax
00007e2c933d16f0  xor eax, eax
00007e2c933d16f2  mov r14, [rsp+0x10]
00007e2c933d16f7  mov r12d, 0x400
00007e2c933d16fd  cmp r14, r12
00007e2c933d1700  cmc
00007e2c933d1701  lahf
00007e2c933d1702  seto al
00007e2c933d1705  mov [r15+0x108], eax
00007e2c933d170c  mov rax, [r15+0x50]
00007e2c933d1710  mov r12, [r15+0x60]
00007e2c933d1714  imul r14, r12
00007e2c933d1718  lea r12, [rax+r14*1]
00007e2c933d171c  mov [r15+0x50], r12
00007e2c933d1720  mov rax, [r15+0x48]
00007e2c933d1724  lea r14, [r11+rax*1]
00007e2c933d1728  mov [r15+0x48], r14
00007e2c933d172c  mov eax, [r15+0x108]
00007e2c933d1733  sahf
00007e2c933d1734  jnz 0x00007E2C933D1766
00007e2c933d1736  cmp dword ptr [r15+0x318], 0x00
00007e2c933d173e  jz 0x00007E2C933D17B0
00007e2c933d1744  nop [rax+rax*1], ax
00007e2c933d174d  nop [rax+rax*1], eax
00007e2c933d1755  mov eax, 0x4103E0
00007e2c933d175a  mov [r15+0x100], rax
00007e2c933d1761  jmp 0x00007E2C931FE110
00007e2c933d1766  cmp dword ptr [r15+0x318], 0x00
00007e2c933d176e  jz 0x00007E2C933D1690
00007e2c933d1774  nop [rax+rax*1], ax
00007e2c933d177d  nop [rax+rax*1], eax
00007e2c933d1785  mov eax, 0x4103C0
00007e2c933d178a  mov [r15+0x100], rax
00007e2c933d1791  jmp 0x00007E2C931FE110
00007e2c933d1796  int3
00007e2c933d1797  call 0x00007E2C932B4690
00007e2c933d179c  jmp 0x00007E2C933D16AD
00007e2c933d17a1  call 0x00007E2C932E26A0
00007e2c933d17a6  jmp 0x00007E2C933D16B7
00007e2c933d17ab  int3
00007e2c933d17ac  nop [rax], eax
00007e2c933d17b0  mov qword ptr [r15+0x98], 0x00
00007e2c933d17bb  mov rax, [r15+0x50]
00007e2c933d17bf  mov r14, [r15+0x48]
00007e2c933d17c3  lea r12, [rax+r14*1]
00007e2c933d17c7  mov [r15+0x48], r12
00007e2c933d17cb  mov rax, [r15+0x40]
00007e2c933d17cf  lea r14, [rax+0xCB0]
00007e2c933d17d6  mov [r13+r14*1], r12
00007e2c933d17db  mov qword ptr [r15], 0x01
00007e2c933d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007e2c933d17ed  mov r14d, [r15+0x320]
00007e2c933d17f4  mov eax, 0x4103F8
00007e2c933d17f9  mov rcx, 0x7E2C933D1860
00007e2c933d1803  mov [r15+r14*8+0x328], rax
00007e2c933d180b  mov [r15+r14*8+0x368], rcx
00007e2c933d1813  add r14d, 0x01
00007e2c933d1817  and r14d, 0x07
00007e2c933d181b  mov [r15+0x320], r14d
00007e2c933d1822  cmp dword ptr [r15+0x318], 0x00
00007e2c933d182a  jz 0x00007E2C933D0F20
00007e2c933d1830  nop [rax+rax*1], ax
00007e2c933d1839  nop [rax+rax*1], eax
00007e2c933d1841  mov eax, 0x4109A4
00007e2c933d1846  mov [r15+0x100], rax
00007e2c933d184d  jmp 0x00007E2C931FE110
00007e2c933d1852  int3
00007e2c933d1853  call 0x00007E2C932E2CE0
00007e2c933d1858  jmp 0x00007E2C933D17DB
00007e2c933d185d  int3
00007e2c933d185e  nop
00007e2c933d1860  mov eax, [r15+0x98]
00007e2c933d1867  lea r14d, [eax+0x01]
00007e2c933d186c  mov [rsp+0x10], r14d
00007e2c933d1871  mov r14d, r14d
00007e2c933d1874  mov [r15+0x98], r14
00007e2c933d187b  xor eax, eax
00007e2c933d187d  mov r14d, [rsp+0x10]
00007e2c933d1882  cmp r14d, 0x10000
00007e2c933d1889  cmc
00007e2c933d188a  lahf
00007e2c933d188b  seto al
00007e2c933d188e  mov [r15+0x108], eax
00007e2c933d1895  mov eax, [r15+0x108]
00007e2c933d189c  sahf
00007e2c933d189d  jnz 0x00007E2C933D18CF
00007e2c933d189f  cmp dword ptr [r15+0x318], 0x00
00007e2c933d18a7  jz 0x00007E2C933D19A0
00007e2c933d18ad  nop [rax+rax*1], ax
00007e2c933d18b6  nop [rax+rax*1], eax
00007e2c933d18be  mov eax, 0x410404
00007e2c933d18c3  mov [r15+0x100], rax
00007e2c933d18ca  jmp 0x00007E2C931FE110
00007e2c933d18cf  cmp dword ptr [r15+0x318], 0x00
00007e2c933d18d7  jz 0x00007E2C933D1910
00007e2c933d18dd  nop [rax+rax*1], ax
00007e2c933d18e6  nop [rax+rax*1], eax
00007e2c933d18ee  mov eax, 0x4103F0
00007e2c933d18f3  mov [r15+0x100], rax
00007e2c933d18fa  jmp 0x00007E2C931FE110
00007e2c933d18ff  int3
00007e2c933d1900  int3
00007e2c933d1901  nop [rax+rax*1], ax
00007e2c933d190a  nop [rax+rax*1], ax
00007e2c933d1910  mov eax, [r15]
00007e2c933d1913  mov r14d, [r15+0x98]
00007e2c933d191a  lea r12d, [eax+r14d*1]
00007e2c933d191f  mov r12d, r12d
00007e2c933d1922  mov [r15], r12
00007e2c933d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007e2c933d1930  mov r14d, [r15+0x320]
00007e2c933d1937  mov eax, 0x4103F8
00007e2c933d193c  mov rcx, 0x7E2C933D1860
00007e2c933d1946  mov [r15+r14*8+0x328], rax
00007e2c933d194e  mov [r15+r14*8+0x368], rcx
00007e2c933d1956  add r14d, 0x01
00007e2c933d195a  and r14d, 0x07
00007e2c933d195e  mov [r15+0x320], r14d
00007e2c933d1965  cmp dword ptr [r15+0x318], 0x00
00007e2c933d196d  jz 0x00007E2C933D0F20
00007e2c933d1973  nop [rax+rax*1], ax
00007e2c933d197c  nop [rax+rax*1], eax
00007e2c933d1984  mov eax, 0x4109A4
00007e2c933d1989  mov [r15+0x100], rax
00007e2c933d1990  jmp 0x00007E2C931FE110
00007e2c933d1995  int3
00007e2c933d1996  int3
00007e2c933d1997  nop [rax+rax*1], ax
00007e2c933d19a0  vmovaps xmm1, [0x00007E2C92FFE010]
00007e2c933d19a8  movq xmm1, xmm1
00007e2c933d19ac  movaps [r15+0x110], xmm1
00007e2c933d19b4  mov eax, 0x420B10
00007e2c933d19b9  mov r14, [r13+rax*1]
00007e2c933d19be  movq xmm1, r14
00007e2c933d19c3  movaps [r15+0x120], xmm1
00007e2c933d19cb  vmovaps xmm1, [0x00007E2C92FFE020]
00007e2c933d19d3  movq xmm1, xmm1
00007e2c933d19d7  movaps [r15+0x140], xmm1
00007e2c933d19df  vmovaps xmm1, [0x00007E2C92FFE030]
00007e2c933d19e7  vpbroadcastq xmm1, xmm1
00007e2c933d19ec  movaps [r15+0x150], xmm1
00007e2c933d19f4  mov qword ptr [r15+0x40], 0x02
00007e2c933d19fc  vmovaps xmm15, [0x00007E2C92FFE040]
00007e2c933d1a04  movq xmm15, xmm15
00007e2c933d1a09  movaps [r15+0x160], xmm15
00007e2c933d1a11  vmovaps xmm15, [0x00007E2C92FFE050]
00007e2c933d1a19  vpbroadcastq xmm15, xmm15
00007e2c933d1a1e  movaps [r15+0x130], xmm15
00007e2c933d1a26  mov rax, [r15+0x40]
00007e2c933d1a2a  vmovq xmm14, rax
00007e2c933d1a2f  vpbroadcastq xmm14, xmm14
00007e2c933d1a34  movaps [r15+0x170], xmm14
00007e2c933d1a3c  mov eax, 0x420A40
00007e2c933d1a41  movups xmm13, [r13+rax*1]
00007e2c933d1a47  mov qword ptr [r15+0x40], 0x431E00
00007e2c933d1a4f  mov eax, [r15]
00007e2c933d1a52  mov r14d, 0x430CB8
00007e2c933d1a58  mov [r13+r14*1], eax
00007e2c933d1a5d  mov qword ptr [r15+0x50], 0x432000
00007e2c933d1a65  vpmovqd xmm12, xmm13
00007e2c933d1a6b  pxor xmm11, xmm11
00007e2c933d1a70  punpcklqdq xmm12, xmm11
00007e2c933d1a75  movaps [r15+0x210], xmm12
00007e2c933d1a7d  movq xmm12, qword ptr [r15+0x140]
00007e2c933d1a86  movq xmm11, qword ptr [r15+0x120]
00007e2c933d1a8f  psubd xmm12, xmm11
00007e2c933d1a94  movq xmm12, xmm12
00007e2c933d1a99  paddq xmm13, xmm14
00007e2c933d1a9e  movaps [r15+0x180], xmm13
00007e2c933d1aa6  movq xmm14, qword ptr [r15+0x160]
00007e2c933d1aaf  paddd xmm11, xmm14
00007e2c933d1ab4  movq xmm11, xmm11
00007e2c933d1ab9  movq xmm11, xmm11
00007e2c933d1abe  movaps [r15+0x120], xmm11
00007e2c933d1ac6  pmovzxdq xmm12, xmm12
00007e2c933d1acc  psllq xmm12, 0x00
00007e2c933d1ad2  movq xmm14, qword ptr [r15+0x210]
00007e2c933d1adb  movq xmm13, qword ptr [r15+0x110]
00007e2c933d1ae4  paddd xmm14, xmm13
00007e2c933d1ae9  movq xmm14, xmm14
00007e2c933d1aee  vcvtuqq2pd xmm12, xmm12
00007e2c933d1af4  pmovzxdq xmm14, xmm14
00007e2c933d1afa  psllq xmm14, 0x00
00007e2c933d1b00  vcvtuqq2pd xmm14, xmm14
00007e2c933d1b06  movaps xmm13, xmm12
00007e2c933d1b0a  mulpd xmm13, xmm1
00007e2c933d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007e2c933d1b15  ptest xmm11, xmm11
00007e2c933d1b1b  jnz 0x00007E2C933D1C0F
00007e2c933d1b21  movaps [r15+0x220], xmm13
00007e2c933d1b29  mov eax, 0x432000
00007e2c933d1b2e  movups [r13+rax*1], xmm13
00007e2c933d1b34  movaps xmm1, xmm14
00007e2c933d1b38  mulpd xmm1, xmm15
00007e2c933d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007e2c933d1b42  ptest xmm13, xmm13
00007e2c933d1b48  jnz 0x00007E2C933D1D5C
00007e2c933d1b4e  movaps [r15+0x210], xmm1
00007e2c933d1b56  mov eax, 0x431E00
00007e2c933d1b5b  movups [r13+rax*1], xmm1
00007e2c933d1b61  mov qword ptr [r15+0x48], 0x10
00007e2c933d1b69  xor eax, eax
00007e2c933d1b6b  mov r14d, 0x10
00007e2c933d1b71  mov r12d, 0x200
00007e2c933d1b77  cmp r14, r12
00007e2c933d1b7a  cmc
00007e2c933d1b7b  lahf
00007e2c933d1b7c  seto al
00007e2c933d1b7f  mov [r15+0x108], eax
00007e2c933d1b86  mov eax, [r15+0x108]
00007e2c933d1b8d  sahf
00007e2c933d1b8e  jnz 0x00007E2C933D1BC0
00007e2c933d1b90  cmp dword ptr [r15+0x318], 0x00
00007e2c933d1b98  jz 0x00007E2C933D2300
00007e2c933d1b9e  nop [rax+rax*1], ax
00007e2c933d1ba7  nop [rax+rax*1], eax
00007e2c933d1baf  mov eax, 0x410490
00007e2c933d1bb4  mov [r15+0x100], rax
00007e2c933d1bbb  jmp 0x00007E2C931FE110
00007e2c933d1bc0  cmp dword ptr [r15+0x318], 0x00
00007e2c933d1bc8  jz 0x00007E2C933D1EB0
00007e2c933d1bce  nop [rax+rax*1], ax
00007e2c933d1bd7  nop [rax+rax*1], eax
00007e2c933d1bdf  mov eax, 0x410450
00007e2c933d1be4  mov [r15+0x100], rax
00007e2c933d1beb  jmp 0x00007E2C931FE110
00007e2c933d1bf0  int3
00007e2c933d1bf1  call 0x00007E2C9320DC20
00007e2c933d1bf6  jmp 0x00007E2C933D19BE
00007e2c933d1bfb  call 0x00007E2C9320C260
00007e2c933d1c00  jmp 0x00007E2C933D1A47
00007e2c933d1c05  call 0x00007E2C932D5D70
00007e2c933d1c0a  jmp 0x00007E2C933D1A5D
00007e2c933d1c0f  sub rsp, 0x08
00007e2c933d1c13  push rax
00007e2c933d1c14  push rcx
00007e2c933d1c15  push rdx
00007e2c933d1c16  push rdi
00007e2c933d1c17  push rsi
00007e2c933d1c18  push r8
00007e2c933d1c1a  push r9
00007e2c933d1c1c  push r10
00007e2c933d1c1e  push r11
00007e2c933d1c20  sub rsp, 0xF0
00007e2c933d1c27  vmovaps [rsp], xmm0
00007e2c933d1c2c  vmovaps [rsp+0x10], xmm1
00007e2c933d1c32  vmovaps [rsp+0x20], xmm2
00007e2c933d1c38  vmovaps [rsp+0x30], xmm3
00007e2c933d1c3e  vmovaps [rsp+0x40], xmm4
00007e2c933d1c44  vmovaps [rsp+0x50], xmm5
00007e2c933d1c4a  vmovaps [rsp+0x60], xmm6
00007e2c933d1c50  vmovaps [rsp+0x70], xmm7
00007e2c933d1c56  vmovaps [rsp+0x80], xmm8
00007e2c933d1c5f  vmovaps [rsp+0x90], xmm9
00007e2c933d1c68  vmovaps [rsp+0xA0], xmm10
00007e2c933d1c71  vmovaps [rsp+0xB0], xmm11
00007e2c933d1c7a  vmovaps [rsp+0xC0], xmm12
00007e2c933d1c83  vmovaps [rsp+0xD0], xmm14
00007e2c933d1c8c  vmovaps [rsp+0xE0], xmm15
00007e2c933d1c95  sub rsp, 0x30
00007e2c933d1c99  movaps [rsp], xmm13
00007e2c933d1c9e  movaps [rsp+0x10], xmm12
00007e2c933d1ca4  movaps [rsp+0x20], xmm1
00007e2c933d1ca9  lea rdi, [rsp]
00007e2c933d1cad  mov esi, 0x00
00007e2c933d1cb2  mov rax, 0x5A263F1C7530
00007e2c933d1cbc  call rax
00007e2c933d1cbe  movaps xmm13, [rsp]
00007e2c933d1cc3  add rsp, 0x30
00007e2c933d1cc7  vmovaps xmm0, [rsp]
00007e2c933d1ccc  vmovaps xmm1, [rsp+0x10]
00007e2c933d1cd2  vmovaps xmm2, [rsp+0x20]
00007e2c933d1cd8  vmovaps xmm3, [rsp+0x30]
00007e2c933d1cde  vmovaps xmm4, [rsp+0x40]
00007e2c933d1ce4  vmovaps xmm5, [rsp+0x50]
00007e2c933d1cea  vmovaps xmm6, [rsp+0x60]
00007e2c933d1cf0  vmovaps xmm7, [rsp+0x70]
00007e2c933d1cf6  vmovaps xmm8, [rsp+0x80]
00007e2c933d1cff  vmovaps xmm9, [rsp+0x90]
00007e2c933d1d08  vmovaps xmm10, [rsp+0xA0]
00007e2c933d1d11  vmovaps xmm11, [rsp+0xB0]
00007e2c933d1d1a  vmovaps xmm12, [rsp+0xC0]
00007e2c933d1d23  vmovaps xmm14, [rsp+0xD0]
00007e2c933d1d2c  vmovaps xmm15, [rsp+0xE0]
00007e2c933d1d35  add rsp, 0xF0
00007e2c933d1d3c  pop r11
00007e2c933d1d3e  pop r10
00007e2c933d1d40  pop r9
00007e2c933d1d42  pop r8
00007e2c933d1d44  pop rsi
00007e2c933d1d45  pop rdi
00007e2c933d1d46  pop rdx
00007e2c933d1d47  pop rcx
00007e2c933d1d48  pop rax
00007e2c933d1d49  add rsp, 0x08
00007e2c933d1d4d  jmp 0x00007E2C933D1B21
00007e2c933d1d52  call 0x00007E2C9320C380
00007e2c933d1d57  jmp 0x00007E2C933D1B34
00007e2c933d1d5c  sub rsp, 0x08
00007e2c933d1d60  push rax
00007e2c933d1d61  push rcx
00007e2c933d1d62  push rdx
00007e2c933d1d63  push rdi
00007e2c933d1d64  push rsi
00007e2c933d1d65  push r8
00007e2c933d1d67  push r9
00007e2c933d1d69  push r10
00007e2c933d1d6b  push r11
00007e2c933d1d6d  sub rsp, 0xF0
00007e2c933d1d74  vmovaps [rsp], xmm0
00007e2c933d1d79  vmovaps [rsp+0x10], xmm2
00007e2c933d1d7f  vmovaps [rsp+0x20], xmm3
00007e2c933d1d85  vmovaps [rsp+0x30], xmm4
00007e2c933d1d8b  vmovaps [rsp+0x40], xmm5
00007e2c933d1d91  vmovaps [rsp+0x50], xmm6
00007e2c933d1d97  vmovaps [rsp+0x60], xmm7
00007e2c933d1d9d  vmovaps [rsp+0x70], xmm8
00007e2c933d1da3  vmovaps [rsp+0x80], xmm9
00007e2c933d1dac  vmovaps [rsp+0x90], xmm10
00007e2c933d1db5  vmovaps [rsp+0xA0], xmm11
00007e2c933d1dbe  vmovaps [rsp+0xB0], xmm12
00007e2c933d1dc7  vmovaps [rsp+0xC0], xmm13
00007e2c933d1dd0  vmovaps [rsp+0xD0], xmm14
00007e2c933d1dd9  vmovaps [rsp+0xE0], xmm15
00007e2c933d1de2  sub rsp, 0x30
00007e2c933d1de6  movaps [rsp], xmm1
00007e2c933d1dea  movaps [rsp+0x10], xmm14
00007e2c933d1df0  movaps [rsp+0x20], xmm15
00007e2c933d1df6  lea rdi, [rsp]
00007e2c933d1dfa  mov esi, 0x00
00007e2c933d1dff  mov rax, 0x5A263F1C7530
00007e2c933d1e09  call rax
00007e2c933d1e0b  movaps xmm1, [rsp]
00007e2c933d1e0f  add rsp, 0x30
00007e2c933d1e13  vmovaps xmm0, [rsp]
00007e2c933d1e18  vmovaps xmm2, [rsp+0x10]
00007e2c933d1e1e  vmovaps xmm3, [rsp+0x20]
00007e2c933d1e24  vmovaps xmm4, [rsp+0x30]
00007e2c933d1e2a  vmovaps xmm5, [rsp+0x40]
00007e2c933d1e30  vmovaps xmm6, [rsp+0x50]
00007e2c933d1e36  vmovaps xmm7, [rsp+0x60]
00007e2c933d1e3c  vmovaps xmm8, [rsp+0x70]
00007e2c933d1e42  vmovaps xmm9, [rsp+0x80]
00007e2c933d1e4b  vmovaps xmm10, [rsp+0x90]
00007e2c933d1e54  vmovaps xmm11, [rsp+0xA0]
00007e2c933d1e5d  vmovaps xmm12, [rsp+0xB0]
00007e2c933d1e66  vmovaps xmm13, [rsp+0xC0]
00007e2c933d1e6f  vmovaps xmm14, [rsp+0xD0]
00007e2c933d1e78  vmovaps xmm15, [rsp+0xE0]
00007e2c933d1e81  add rsp, 0xF0
00007e2c933d1e88  pop r11
00007e2c933d1e8a  pop r10
00007e2c933d1e8c  pop r9
00007e2c933d1e8e  pop r8
00007e2c933d1e90  pop rsi
00007e2c933d1e91  pop rdi
00007e2c933d1e92  pop rdx
00007e2c933d1e93  pop rcx
00007e2c933d1e94  pop rax
00007e2c933d1e95  add rsp, 0x08
00007e2c933d1e99  jmp 0x00007E2C933D1B4E
00007e2c933d1e9e  call 0x00007E2C931FF540
00007e2c933d1ea3  jmp 0x00007E2C933D1B61
00007e2c933d1ea8  int3
00007e2c933d1ea9  nop [rax], eax
00007e2c933d1eb0  movaps xmm1, [r15+0x180]
00007e2c933d1eb8  vpmovqd xmm15, xmm1
00007e2c933d1ebe  pxor xmm14, xmm14
00007e2c933d1ec3  punpcklqdq xmm15, xmm14
00007e2c933d1ec8  movaps [r15+0x210], xmm15
00007e2c933d1ed0  movq xmm15, qword ptr [r15+0x140]
00007e2c933d1ed9  movq xmm14, qword ptr [r15+0x120]
00007e2c933d1ee2  psubd xmm15, xmm14
00007e2c933d1ee7  movq xmm15, xmm15
00007e2c933d1eec  movaps xmm13, [r15+0x170]
00007e2c933d1ef4  paddq xmm1, xmm13
00007e2c933d1ef9  movaps [r15+0x180], xmm1
00007e2c933d1f01  movq xmm1, qword ptr [r15+0x160]
00007e2c933d1f0a  paddd xmm14, xmm1
00007e2c933d1f0f  movq xmm14, xmm14
00007e2c933d1f14  movq xmm14, xmm14
00007e2c933d1f19  movaps [r15+0x120], xmm14
00007e2c933d1f21  pmovzxdq xmm15, xmm15
00007e2c933d1f27  psllq xmm15, 0x00
00007e2c933d1f2d  movq xmm1, qword ptr [r15+0x210]
00007e2c933d1f36  movq xmm14, qword ptr [r15+0x110]
00007e2c933d1f3f  paddd xmm1, xmm14
00007e2c933d1f44  movq xmm1, xmm1
00007e2c933d1f48  vcvtuqq2pd xmm15, xmm15
00007e2c933d1f4e  pmovzxdq xmm1, xmm1
00007e2c933d1f53  psllq xmm1, 0x00
00007e2c933d1f58  vcvtuqq2pd xmm1, xmm1
00007e2c933d1f5e  movaps xmm14, [r15+0x150]
00007e2c933d1f66  movaps xmm13, xmm15
00007e2c933d1f6a  mulpd xmm13, xmm14
00007e2c933d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007e2c933d1f75  ptest xmm12, xmm12
00007e2c933d1f7b  jnz 0x00007E2C933D205E
00007e2c933d1f81  movaps [r15+0x220], xmm13
00007e2c933d1f89  mov rax, [r15+0x48]
00007e2c933d1f8d  mov r14, [r15+0x50]
00007e2c933d1f91  lea r12, [r14+rax*1]
00007e2c933d1f95  movups [r13+r12*1], xmm13
00007e2c933d1f9b  movaps xmm15, [r15+0x130]
00007e2c933d1fa3  movaps xmm14, xmm1
00007e2c933d1fa7  mulpd xmm14, xmm15
00007e2c933d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007e2c933d1fb2  ptest xmm13, xmm13
00007e2c933d1fb8  jnz 0x00007E2C933D21AC
00007e2c933d1fbe  movaps [r15+0x210], xmm14
00007e2c933d1fc6  mov r14, [r15+0x40]
00007e2c933d1fca  lea r12, [r14+rax*1]
00007e2c933d1fce  movups [r13+r12*1], xmm14
00007e2c933d1fd4  lea r14, [rax+0x10]
00007e2c933d1fd8  mov [r15+0x48], r14
00007e2c933d1fdc  xor eax, eax
00007e2c933d1fde  mov r12d, 0x200
00007e2c933d1fe4  cmp r14, r12
00007e2c933d1fe7  cmc
00007e2c933d1fe8  lahf
00007e2c933d1fe9  seto al
00007e2c933d1fec  mov [r15+0x108], eax
00007e2c933d1ff3  mov eax, [r15+0x108]
00007e2c933d1ffa  sahf
00007e2c933d1ffb  jnz 0x00007E2C933D202D
00007e2c933d1ffd  cmp dword ptr [r15+0x318], 0x00
00007e2c933d2005  jz 0x00007E2C933D2300
00007e2c933d200b  nop [rax+rax*1], ax
00007e2c933d2014  nop [rax+rax*1], eax
00007e2c933d201c  mov eax, 0x410490
00007e2c933d2021  mov [r15+0x100], rax
00007e2c933d2028  jmp 0x00007E2C931FE110
00007e2c933d202d  cmp dword ptr [r15+0x318], 0x00
00007e2c933d2035  jz 0x00007E2C933D1EB0
00007e2c933d203b  nop [rax+rax*1], ax
00007e2c933d2044  nop [rax+rax*1], eax
00007e2c933d204c  mov eax, 0x410450
00007e2c933d2051  mov [r15+0x100], rax
00007e2c933d2058  jmp 0x00007E2C931FE110
00007e2c933d205d  int3
00007e2c933d205e  sub rsp, 0x08
00007e2c933d2062  push rax
00007e2c933d2063  push rcx
00007e2c933d2064  push rdx
00007e2c933d2065  push rdi
00007e2c933d2066  push rsi
00007e2c933d2067  push r8
00007e2c933d2069  push r9
00007e2c933d206b  push r10
00007e2c933d206d  push r11
00007e2c933d206f  sub rsp, 0xF0
00007e2c933d2076  vmovaps [rsp], xmm0
00007e2c933d207b  vmovaps [rsp+0x10], xmm1
00007e2c933d2081  vmovaps [rsp+0x20], xmm2
00007e2c933d2087  vmovaps [rsp+0x30], xmm3
00007e2c933d208d  vmovaps [rsp+0x40], xmm4
00007e2c933d2093  vmovaps [rsp+0x50], xmm5
00007e2c933d2099  vmovaps [rsp+0x60], xmm6
00007e2c933d209f  vmovaps [rsp+0x70], xmm7
00007e2c933d20a5  vmovaps [rsp+0x80], xmm8
00007e2c933d20ae  vmovaps [rsp+0x90], xmm9
00007e2c933d20b7  vmovaps [rsp+0xA0], xmm10
00007e2c933d20c0  vmovaps [rsp+0xB0], xmm11
00007e2c933d20c9  vmovaps [rsp+0xC0], xmm12
00007e2c933d20d2  vmovaps [rsp+0xD0], xmm14
00007e2c933d20db  vmovaps [rsp+0xE0], xmm15
00007e2c933d20e4  sub rsp, 0x30
00007e2c933d20e8  movaps [rsp], xmm13
00007e2c933d20ed  movaps [rsp+0x10], xmm15
00007e2c933d20f3  movaps [rsp+0x20], xmm14
00007e2c933d20f9  lea rdi, [rsp]
00007e2c933d20fd  mov esi, 0x00
00007e2c933d2102  mov rax, 0x5A263F1C7530
00007e2c933d210c  call rax
00007e2c933d210e  movaps xmm13, [rsp]
00007e2c933d2113  add rsp, 0x30
00007e2c933d2117  vmovaps xmm0, [rsp]
00007e2c933d211c  vmovaps xmm1, [rsp+0x10]
00007e2c933d2122  vmovaps xmm2, [rsp+0x20]
00007e2c933d2128  vmovaps xmm3, [rsp+0x30]
00007e2c933d212e  vmovaps xmm4, [rsp+0x40]
00007e2c933d2134  vmovaps xmm5, [rsp+0x50]
00007e2c933d213a  vmovaps xmm6, [rsp+0x60]
00007e2c933d2140  vmovaps xmm7, [rsp+0x70]
00007e2c933d2146  vmovaps xmm8, [rsp+0x80]
00007e2c933d214f  vmovaps xmm9, [rsp+0x90]
00007e2c933d2158  vmovaps xmm10, [rsp+0xA0]
00007e2c933d2161  vmovaps xmm11, [rsp+0xB0]
00007e2c933d216a  vmovaps xmm12, [rsp+0xC0]
00007e2c933d2173  vmovaps xmm14, [rsp+0xD0]
00007e2c933d217c  vmovaps xmm15, [rsp+0xE0]
00007e2c933d2185  add rsp, 0xF0
00007e2c933d218c  pop r11
00007e2c933d218e  pop r10
00007e2c933d2190  pop r9
00007e2c933d2192  pop r8
00007e2c933d2194  pop rsi
00007e2c933d2195  pop rdi
00007e2c933d2196  pop rdx
00007e2c933d2197  pop rcx
00007e2c933d2198  pop rax
00007e2c933d2199  add rsp, 0x08
00007e2c933d219d  jmp 0x00007E2C933D1F81
00007e2c933d21a2  call 0x00007E2C932C2240
00007e2c933d21a7  jmp 0x00007E2C933D1F9B
00007e2c933d21ac  sub rsp, 0x08
00007e2c933d21b0  push rax
00007e2c933d21b1  push rcx
00007e2c933d21b2  push rdx
00007e2c933d21b3  push rdi
00007e2c933d21b4  push rsi
00007e2c933d21b5  push r8
00007e2c933d21b7  push r9
00007e2c933d21b9  push r10
00007e2c933d21bb  push r11
00007e2c933d21bd  sub rsp, 0xF0
00007e2c933d21c4  vmovaps [rsp], xmm0
00007e2c933d21c9  vmovaps [rsp+0x10], xmm1
00007e2c933d21cf  vmovaps [rsp+0x20], xmm2
00007e2c933d21d5  vmovaps [rsp+0x30], xmm3
00007e2c933d21db  vmovaps [rsp+0x40], xmm4
00007e2c933d21e1  vmovaps [rsp+0x50], xmm5
00007e2c933d21e7  vmovaps [rsp+0x60], xmm6
00007e2c933d21ed  vmovaps [rsp+0x70], xmm7
00007e2c933d21f3  vmovaps [rsp+0x80], xmm8
00007e2c933d21fc  vmovaps [rsp+0x90], xmm9
00007e2c933d2205  vmovaps [rsp+0xA0], xmm10
00007e2c933d220e  vmovaps [rsp+0xB0], xmm11
00007e2c933d2217  vmovaps [rsp+0xC0], xmm12
00007e2c933d2220  vmovaps [rsp+0xD0], xmm13
00007e2c933d2229  vmovaps [rsp+0xE0], xmm15
00007e2c933d2232  sub rsp, 0x30
00007e2c933d2236  movaps [rsp], xmm14
00007e2c933d223b  movaps [rsp+0x10], xmm1
00007e2c933d2240  movaps [rsp+0x20], xmm15
00007e2c933d2246  lea rdi, [rsp]
00007e2c933d224a  mov esi, 0x00
00007e2c933d224f  mov rax, 0x5A263F1C7530
00007e2c933d2259  call rax
00007e2c933d225b  movaps xmm14, [rsp]
00007e2c933d2260  add rsp, 0x30
00007e2c933d2264  vmovaps xmm0, [rsp]
00007e2c933d2269  vmovaps xmm1, [rsp+0x10]
00007e2c933d226f  vmovaps xmm2, [rsp+0x20]
00007e2c933d2275  vmovaps xmm3, [rsp+0x30]
00007e2c933d227b  vmovaps xmm4, [rsp+0x40]
00007e2c933d2281  vmovaps xmm5, [rsp+0x50]
00007e2c933d2287  vmovaps xmm6, [rsp+0x60]
00007e2c933d228d  vmovaps xmm7, [rsp+0x70]
00007e2c933d2293  vmovaps xmm8, [rsp+0x80]
00007e2c933d229c  vmovaps xmm9, [rsp+0x90]
00007e2c933d22a5  vmovaps xmm10, [rsp+0xA0]
00007e2c933d22ae  vmovaps xmm11, [rsp+0xB0]
00007e2c933d22b7  vmovaps xmm12, [rsp+0xC0]
00007e2c933d22c0  vmovaps xmm13, [rsp+0xD0]
00007e2c933d22c9  vmovaps xmm15, [rsp+0xE0]
00007e2c933d22d2  add rsp, 0xF0
00007e2c933d22d9  pop r11
00007e2c933d22db  pop r10
00007e2c933d22dd  pop r9
00007e2c933d22df  pop r8
00007e2c933d22e1  pop rsi
00007e2c933d22e2  pop rdi
00007e2c933d22e3  pop rdx
00007e2c933d22e4  pop rcx
00007e2c933d22e5  pop rax
00007e2c933d22e6  add rsp, 0x08
00007e2c933d22ea  jmp 0x00007E2C933D1FBE
00007e2c933d22ef  call 0x00007E2C932C34C0
00007e2c933d22f4  jmp 0x00007E2C933D1FD4
00007e2c933d22f9  int3
00007e2c933d22fa  nop [rax+rax*1], ax
00007e2c933d2300  mov rax, [r15+0x50]
00007e2c933d2304  lea r14, [rax+0x80]
00007e2c933d230b  movups xmm1, [r13+r14*1]
00007e2c933d2311  lea r14, [rax+0x90]
00007e2c933d2318  movups xmm15, [r13+r14*1]
00007e2c933d231e  vxorps xmm14, xmm14, xmm14
00007e2c933d2323  vpbroadcastq xmm14, xmm14
00007e2c933d2328  lea r14, [rax+0x40]
00007e2c933d232c  movups xmm13, [r13+r14*1]
00007e2c933d2332  lea r14, [rax+0x50]
00007e2c933d2336  movups xmm12, [r13+r14*1]
00007e2c933d233c  mov qword ptr [r15+0x48], 0x00
00007e2c933d2344  movups xmm11, [r13+rax*1]
00007e2c933d234a  lea r14, [rax+0x10]
00007e2c933d234e  movups xmm10, [r13+r14*1]
00007e2c933d2354  mov r14, [r15+0xF8]
00007e2c933d235b  lea r12, [r14+0xE0]
00007e2c933d2362  movups [r13+r12*1], xmm15
00007e2c933d2368  lea r12, [r14+0xF0]
00007e2c933d236f  movups [r13+r12*1], xmm1
00007e2c933d2375  lea r12, [rax+0xC0]
00007e2c933d237c  movups xmm1, [r13+r12*1]
00007e2c933d2382  lea r12, [rax+0xD0]
00007e2c933d2389  movups xmm15, [r13+r12*1]
00007e2c933d238f  lea r12, [rax+0x140]
00007e2c933d2396  movups xmm9, [r13+r12*1]
00007e2c933d239c  lea r12, [rax+0x150]
00007e2c933d23a3  movups xmm8, [r13+r12*1]
00007e2c933d23a9  lea r12, [rax+0x180]
00007e2c933d23b0  movups xmm7, [r13+r12*1]
00007e2c933d23b6  lea r12, [rax+0x190]
00007e2c933d23bd  movups xmm6, [r13+r12*1]
00007e2c933d23c3  lea r12, [r14+0xC0]
00007e2c933d23ca  movups [r13+r12*1], xmm15
00007e2c933d23d0  lea r12, [r14+0xD0]
00007e2c933d23d7  movups [r13+r12*1], xmm1
00007e2c933d23dd  lea r12, [rax+0x100]
00007e2c933d23e4  movups xmm1, [r13+r12*1]
00007e2c933d23ea  lea r12, [rax+0x110]
00007e2c933d23f1  movups xmm15, [r13+r12*1]
00007e2c933d23f7  lea r12, [rax+0x1C0]
00007e2c933d23fe  movups xmm5, [r13+r12*1]
00007e2c933d2404  lea r12, [rax+0x1D0]
00007e2c933d240b  movups xmm4, [r13+r12*1]
00007e2c933d2411  lea r12, [rax+0x20]
00007e2c933d2415  movups xmm3, [r13+r12*1]
00007e2c933d241b  lea r12, [rax+0x30]
00007e2c933d241f  movups xmm2, [r13+r12*1]
00007e2c933d2425  movaps [r15+0x1F0], xmm2
00007e2c933d242d  lea r12, [r14+0x20]
00007e2c933d2431  movups [r13+r12*1], xmm1
00007e2c933d2437  lea r12, [r14+0x30]
00007e2c933d243b  movups [r13+r12*1], xmm12
00007e2c933d2441  lea r12, [rax+0x60]
00007e2c933d2445  movups xmm1, [r13+r12*1]
00007e2c933d244b  lea r12, [rax+0x70]
00007e2c933d244f  movups xmm12, [r13+r12*1]
00007e2c933d2455  lea r12, [r14+0x60]
00007e2c933d2459  movups [r13+r12*1], xmm11
00007e2c933d245f  lea r12, [r14+0x70]
00007e2c933d2463  movups [r13+r12*1], xmm5
00007e2c933d2469  lea r12, [rax+0xE0]
00007e2c933d2470  movups xmm11, [r13+r12*1]
00007e2c933d2476  lea r12, [rax+0xF0]
00007e2c933d247d  movups xmm5, [r13+r12*1]
00007e2c933d2483  lea r12, [rax+0x120]
00007e2c933d248a  vmovaps [rsp+0x10], xmm1
00007e2c933d2490  movups xmm1, [r13+r12*1]
00007e2c933d2496  lea r12, [rax+0x130]
00007e2c933d249d  vmovaps [rsp+0x20], xmm1
00007e2c933d24a3  movups xmm1, [r13+r12*1]
00007e2c933d24a9  lea r12, [r14+0xA0]
00007e2c933d24b0  movups [r13+r12*1], xmm12
00007e2c933d24b6  lea r12, [r14+0xB0]
00007e2c933d24bd  vmovaps xmm12, [rsp+0x10]
00007e2c933d24c3  movups [r13+r12*1], xmm12
00007e2c933d24c9  lea r12, [rax+0xA0]
00007e2c933d24d0  movups xmm12, [r13+r12*1]
00007e2c933d24d6  lea r12, [rax+0xB0]
00007e2c933d24dd  vmovaps [rsp+0x10], xmm1
00007e2c933d24e3  movups xmm1, [r13+r12*1]
00007e2c933d24e9  lea r12, [rax+0x160]
00007e2c933d24f0  vmovaps [rsp+0x30], xmm1
00007e2c933d24f6  movups xmm1, [r13+r12*1]
00007e2c933d24fc  lea r12, [rax+0x170]
00007e2c933d2503  vmovaps [rsp+0x40], xmm1
00007e2c933d2509  movups xmm1, [r13+r12*1]
00007e2c933d250f  movaps [r15+0x2B0], xmm1
00007e2c933d2517  lea r12, [rax+0x1A0]
00007e2c933d251e  vmovaps [rsp+0x50], xmm1
00007e2c933d2524  movups xmm1, [r13+r12*1]
00007e2c933d252a  lea r12, [rax+0x1B0]
00007e2c933d2531  vmovaps [rsp+0x60], xmm1
00007e2c933d2537  movups xmm1, [r13+r12*1]
00007e2c933d253d  vmovaps [rsp+0x70], xmm1
00007e2c933d2543  vmovaps xmm1, [rsp+0x60]
00007e2c933d2549  movaps [r15+0x290], xmm1
00007e2c933d2551  vmovaps [rsp+0x60], xmm1
00007e2c933d2557  vmovaps xmm1, [rsp+0x70]
00007e2c933d255d  movaps [r15+0x1E0], xmm1
00007e2c933d2565  lea r12, [r14+0x80]
00007e2c933d256c  vmovaps [rsp+0x70], xmm1
00007e2c933d2572  vmovaps xmm1, [rsp+0x30]
00007e2c933d2578  movups [r13+r12*1], xmm1
00007e2c933d257e  lea r12, [r14+0x90]
00007e2c933d2585  movups [r13+r12*1], xmm12
00007e2c933d258b  lea r12, [rax+0x1E0]
00007e2c933d2592  movups xmm1, [r13+r12*1]
00007e2c933d2598  lea r12, [rax+0x1F0]
00007e2c933d259f  movups xmm12, [r13+r12*1]
00007e2c933d25a5  mov qword ptr [r15+0x50], 0x432200
00007e2c933d25ad  lea rax, [r14+0x40]
00007e2c933d25b1  vmovaps [rsp+0x30], xmm1
00007e2c933d25b7  vmovaps xmm1, [rsp+0x40]
00007e2c933d25bd  movups [r13+rax*1], xmm1
00007e2c933d25c3  lea rax, [r14+0x50]
00007e2c933d25c7  movups [r13+rax*1], xmm10
00007e2c933d25cd  movups [r13+r14*1], xmm12
00007e2c933d25d3  lea rax, [r14+0x10]
00007e2c933d25d7  vmovaps xmm1, [rsp+0x30]
00007e2c933d25dd  movups [r13+rax*1], xmm1
00007e2c933d25e3  mov rax, [r15+0x40]
00007e2c933d25e7  vmovaps [rsp+0x30], xmm3
00007e2c933d25ed  vmovaps xmm1, [rsp+0x30]
00007e2c933d25f3  por xmm3, xmm1
00007e2c933d25f7  vmovaps [rsp+0x30], xmm6
00007e2c933d25fd  vmovaps xmm12, [rsp+0x30]
00007e2c933d2603  por xmm6, xmm12
00007e2c933d2608  lea r12, [rax+0x30]
00007e2c933d260c  mov r11, [r13+r12*1]
00007e2c933d2611  lea r12, [rax+0x38]
00007e2c933d2615  mov r10, [r13+r12*1]
00007e2c933d261a  movq xmm12, r11
00007e2c933d261f  movq xmm10, r10
00007e2c933d2624  movq xmm12, xmm12
00007e2c933d2629  vmovaps [rsp+0x30], xmm12
00007e2c933d262f  movq xmm12, xmm12
00007e2c933d2634  movaps [r15+0x130], xmm12
00007e2c933d263c  movq xmm10, xmm10
00007e2c933d2641  vmovaps [rsp+0x40], xmm10
00007e2c933d2647  movq xmm10, xmm10
00007e2c933d264c  movaps [r15+0x280], xmm10
00007e2c933d2654  vmovaps [rsp+0x80], xmm9
00007e2c933d265d  vmovaps xmm12, [rsp+0x80]
00007e2c933d2666  por xmm9, xmm12
00007e2c933d266b  lea r12, [rax+0x20]
00007e2c933d266f  mov r11, [r13+r12*1]
00007e2c933d2674  lea r12, [rax+0x28]
00007e2c933d2678  mov r10, [r13+r12*1]
00007e2c933d267d  movq xmm12, r11
00007e2c933d2682  movq xmm10, r10
00007e2c933d2687  movq xmm12, xmm12
00007e2c933d268c  vmovaps [rsp+0x80], xmm12
00007e2c933d2695  movq xmm12, xmm12
00007e2c933d269a  movaps [r15+0x150], xmm12
00007e2c933d26a2  movq xmm10, xmm10
00007e2c933d26a7  vmovaps [rsp+0x90], xmm10
00007e2c933d26b0  movq xmm10, xmm10
00007e2c933d26b5  movaps [r15+0x140], xmm10
00007e2c933d26bd  lea r12, [rax+0x10]
00007e2c933d26c1  mov r11, [r13+r12*1]
00007e2c933d26c6  lea r12, [rax+0x18]
00007e2c933d26ca  mov r10, [r13+r12*1]
00007e2c933d26cf  movq xmm12, r11
00007e2c933d26d4  movq xmm10, r10
00007e2c933d26d9  movq xmm12, xmm12
00007e2c933d26de  vmovaps [rsp+0xA0], xmm12
00007e2c933d26e7  movq xmm12, xmm12
00007e2c933d26ec  movaps [r15+0x170], xmm12
00007e2c933d26f4  movq xmm10, xmm10
00007e2c933d26f9  vmovaps [rsp+0xB0], xmm10
00007e2c933d2702  movq xmm10, xmm10
00007e2c933d2707  movaps [r15+0x160], xmm10
00007e2c933d270f  mov r12, [r13+rax*1]
00007e2c933d2714  vmovq xmm12, r12
00007e2c933d2719  vpbroadcastq xmm12, xmm12
00007e2c933d271e  lea r12, [rax+0x08]
00007e2c933d2722  mov rax, [r13+r12*1]
00007e2c933d2727  movq xmm10, rax
00007e2c933d272c  movaps [r15+0x230], xmm10
00007e2c933d2734  lea rax, [r14+0x50]
00007e2c933d2738  movups xmm10, [r13+rax*1]
00007e2c933d273e  lea rax, [r14+0x60]
00007e2c933d2742  vmovaps [rsp+0xC0], xmm1
00007e2c933d274b  movups xmm1, [r13+rax*1]
00007e2c933d2751  lea rax, [r14+0x30]
00007e2c933d2755  vmovaps [rsp+0xD0], xmm1
00007e2c933d275e  movups xmm1, [r13+rax*1]
00007e2c933d2764  mov qword ptr [r15+0x60], 0x432200
00007e2c933d276c  mov qword ptr [r15+0x58], 0x40
00007e2c933d2774  vmovaps [rsp+0xE0], xmm1
00007e2c933d277d  vmovaps [rsp+0xF0], xmm15
00007e2c933d2786  vmovaps xmm15, [rsp+0xC0]
00007e2c933d278f  vmovaps [rsp+0xC0], xmm14
00007e2c933d2798  movaps xmm1, xmm12
00007e2c933d279c  mulpd xmm1, xmm15
00007e2c933d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007e2c933d27a6  ptest xmm14, xmm14
00007e2c933d27ac  jnz 0x00007E2C933D3863
00007e2c933d27b2  movq xmm15, qword ptr [r15+0x230]
00007e2c933d27bb  vmovaps [rsp+0x100], xmm15
00007e2c933d27c4  vpermilpd xmm15, xmm15, 0x00
00007e2c933d27ca  vmovaps [rsp+0x110], xmm1
00007e2c933d27d3  vmovaps xmm1, [rsp+0xE0]
00007e2c933d27dc  vmovaps [rsp+0xE0], xmm13
00007e2c933d27e5  movaps xmm14, xmm1
00007e2c933d27e9  mulpd xmm14, xmm15
00007e2c933d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007e2c933d27f4  ptest xmm13, xmm13
00007e2c933d27fa  jnz 0x00007E2C933D39A5
00007e2c933d2800  vxorps xmm1, xmm1, xmm1
00007e2c933d2804  vpbroadcastq xmm1, xmm1
00007e2c933d2809  vmovaps xmm13, [rsp+0xD0]
00007e2c933d2812  vmovaps [rsp+0xD0], xmm1
00007e2c933d281b  movaps xmm15, xmm12
00007e2c933d281f  mulpd xmm15, xmm13
00007e2c933d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007e2c933d282a  ptest xmm1, xmm1
00007e2c933d282f  jnz 0x00007E2C933D3AE8
00007e2c933d2835  movaps xmm1, xmm12
00007e2c933d2839  mulpd xmm1, xmm10
00007e2c933d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007e2c933d2843  ptest xmm13, xmm13
00007e2c933d2849  jnz 0x00007E2C933D3C2C
00007e2c933d284f  movaps xmm13, xmm12
00007e2c933d2853  mulpd xmm13, xmm2
00007e2c933d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007e2c933d285e  ptest xmm10, xmm10
00007e2c933d2864  jnz 0x00007E2C933D3D6E
00007e2c933d286a  vmovaps [rsp+0x120], xmm7
00007e2c933d2873  vmovaps xmm12, [rsp+0x120]
00007e2c933d287c  por xmm7, xmm12
00007e2c933d2881  vmovaps xmm12, [rsp+0xE0]
00007e2c933d288a  vmovaps xmm10, [rsp+0xE0]
00007e2c933d2893  por xmm12, xmm10
00007e2c933d2898  vmovaps xmm2, [rsp+0x100]
00007e2c933d28a1  vpermilpd xmm2, xmm2, 0x00
00007e2c933d28a7  vmovaps [rsp+0xE0], xmm1
00007e2c933d28b0  vmovaps [rsp+0x120], xmm15
00007e2c933d28b9  movaps xmm1, xmm10
00007e2c933d28bd  mulpd xmm1, xmm2
00007e2c933d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007e2c933d28c6  ptest xmm15, xmm15
00007e2c933d28cc  jnz 0x00007E2C933D3EB1
00007e2c933d28d2  xor eax, eax
00007e2c933d28d4  mov r12d, 0x40
00007e2c933d28da  mov r11d, 0x200
00007e2c933d28e0  cmp r12, r11
00007e2c933d28e3  cmc
00007e2c933d28e4  lahf
00007e2c933d28e5  seto al
00007e2c933d28e8  mov [r15+0x108], eax
00007e2c933d28ef  vmovaps xmm10, [rsp+0x110]
00007e2c933d28f8  vmovaps xmm2, [rsp+0xD0]
00007e2c933d2901  vmovaps [rsp+0xD0], xmm1
00007e2c933d290a  movaps xmm15, xmm10
00007e2c933d290e  addpd xmm15, xmm2
00007e2c933d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007e2c933d2919  ptest xmm1, xmm1
00007e2c933d291e  jnz 0x00007E2C933D3FF2
00007e2c933d2924  vmovaps xmm10, [rsp+0x120]
00007e2c933d292d  vmovaps [rsp+0x110], xmm15
00007e2c933d2936  vmovaps xmm15, [rsp+0xC0]
00007e2c933d293f  vmovaps [rsp+0xC0], xmm14
00007e2c933d2948  movaps xmm1, xmm10
00007e2c933d294c  addpd xmm1, xmm15
00007e2c933d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007e2c933d2956  ptest xmm14, xmm14
00007e2c933d295c  jnz 0x00007E2C933D4135
00007e2c933d2962  vmovaps xmm10, [rsp+0xE0]
00007e2c933d296b  vmovaps [rsp+0xE0], xmm1
00007e2c933d2974  movaps xmm14, xmm10
00007e2c933d2978  addpd xmm14, xmm15
00007e2c933d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007e2c933d2983  ptest xmm1, xmm1
00007e2c933d2988  jnz 0x00007E2C933D4277
00007e2c933d298e  vmovaps xmm1, [rsp+0x10]
00007e2c933d2994  vmovaps xmm15, [rsp+0x10]
00007e2c933d299a  por xmm1, xmm15
00007e2c933d299f  vmovaps xmm15, [rsp+0x20]
00007e2c933d29a5  vmovaps xmm10, [rsp+0x20]
00007e2c933d29ab  por xmm15, xmm10
00007e2c933d29b0  vmovaps [rsp+0x10], xmm5
00007e2c933d29b6  vmovaps xmm10, [rsp+0x10]
00007e2c933d29bc  por xmm5, xmm10
00007e2c933d29c1  vmovaps [rsp+0x10], xmm11
00007e2c933d29c7  vmovaps xmm10, [rsp+0x10]
00007e2c933d29cd  por xmm11, xmm10
00007e2c933d29d2  vmovaps [rsp+0x10], xmm4
00007e2c933d29d8  vmovaps xmm10, [rsp+0x10]
00007e2c933d29de  por xmm4, xmm10
00007e2c933d29e3  vmovaps [rsp+0x10], xmm8
00007e2c933d29e9  vmovaps xmm10, [rsp+0x10]
00007e2c933d29ef  por xmm8, xmm10
00007e2c933d29f4  vmovaps xmm10, [rsp+0xF0]
00007e2c933d29fd  vmovaps [rsp+0x10], xmm1
00007e2c933d2a03  vmovaps xmm1, [rsp+0xF0]
00007e2c933d2a0c  por xmm10, xmm1
00007e2c933d2a11  lea rax, [r14+0xA0]
00007e2c933d2a18  movups xmm1, [r13+rax*1]
00007e2c933d2a1e  lea rax, [r14+0xB0]
00007e2c933d2a25  vmovaps [rsp+0x20], xmm1
00007e2c933d2a2b  movups xmm1, [r13+rax*1]
00007e2c933d2a31  vmovaps [rsp+0xF0], xmm1
00007e2c933d2a3a  vmovaps [rsp+0x120], xmm15
00007e2c933d2a43  movaps xmm1, xmm13
00007e2c933d2a47  addpd xmm1, xmm2
00007e2c933d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007e2c933d2a50  ptest xmm15, xmm15
00007e2c933d2a56  jnz 0x00007E2C933D43CF
00007e2c933d2a5c  lea rax, [r14+0xF0]
00007e2c933d2a63  movups xmm15, [r13+rax*1]
00007e2c933d2a69  vmovaps xmm2, [rsp+0xE0]
00007e2c933d2a72  vmovaps [rsp+0xE0], xmm1
00007e2c933d2a7b  vmovaps xmm1, [rsp+0xD0]
00007e2c933d2a84  vmovaps [rsp+0xD0], xmm15
00007e2c933d2a8d  movaps xmm13, xmm2
00007e2c933d2a91  addpd xmm13, xmm1
00007e2c933d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007e2c933d2a9c  ptest xmm15, xmm15
00007e2c933d2aa2  jnz 0x00007E2C933D451A
00007e2c933d2aa8  vmovaps xmm15, [rsp+0xC0]
00007e2c933d2ab1  movaps xmm1, xmm14
00007e2c933d2ab5  addpd xmm1, xmm15
00007e2c933d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007e2c933d2abf  ptest xmm2, xmm2
00007e2c933d2ac4  jnz 0x00007E2C933D465C
00007e2c933d2aca  vmovaps xmm15, [rsp+0x100]
00007e2c933d2ad3  vpermilpd xmm15, xmm15, 0x00
00007e2c933d2ad9  vmovaps xmm2, [rsp+0xF0]
00007e2c933d2ae2  vmovaps [rsp+0xC0], xmm1
00007e2c933d2aeb  movaps xmm14, xmm2
00007e2c933d2aef  mulpd xmm14, xmm15
00007e2c933d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007e2c933d2afa  ptest xmm1, xmm1
00007e2c933d2aff  jnz 0x00007E2C933D479E
00007e2c933d2b05  vmovaps xmm1, [rsp+0xA0]
00007e2c933d2b0e  vpermilpd xmm1, xmm1, 0x00
00007e2c933d2b14  vmovaps xmm2, [rsp+0xD0]
00007e2c933d2b1d  vmovaps [rsp+0xD0], xmm14
00007e2c933d2b26  movaps xmm15, xmm2
00007e2c933d2b2a  mulpd xmm15, xmm1
00007e2c933d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007e2c933d2b35  ptest xmm14, xmm14
00007e2c933d2b3b  jnz 0x00007E2C933D48E1
00007e2c933d2b41  lea rax, [r14+0xE0]
00007e2c933d2b48  movups xmm1, [r13+rax*1]
00007e2c933d2b4e  vmovaps xmm14, [rsp+0x100]
00007e2c933d2b57  vpermilpd xmm14, xmm14, 0x00
00007e2c933d2b5d  vmovaps [rsp+0xF0], xmm1
00007e2c933d2b66  vmovaps xmm1, [rsp+0x20]
00007e2c933d2b6c  vmovaps [rsp+0x20], xmm15
00007e2c933d2b72  movaps xmm2, xmm1
00007e2c933d2b75  mulpd xmm2, xmm14
00007e2c933d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007e2c933d2b7f  ptest xmm15, xmm15
00007e2c933d2b85  jnz 0x00007E2C933D4A2D
00007e2c933d2b8b  vmovaps [rsp+0x100], xmm10
00007e2c933d2b94  vmovaps xmm1, [rsp+0x100]
00007e2c933d2b9d  por xmm10, xmm1
00007e2c933d2ba2  movaps [r15+0x300], xmm10
00007e2c933d2baa  vmovaps [rsp+0x100], xmm8
00007e2c933d2bb3  vmovaps xmm1, [rsp+0x100]
00007e2c933d2bbc  por xmm8, xmm1
00007e2c933d2bc1  movaps [r15+0x190], xmm8
00007e2c933d2bc9  vmovaps xmm1, [rsp+0xA0]
00007e2c933d2bd2  vpermilpd xmm1, xmm1, 0x00
00007e2c933d2bd8  vmovaps xmm14, [rsp+0xF0]
00007e2c933d2be1  vmovaps [rsp+0xF0], xmm13
00007e2c933d2bea  movaps xmm15, xmm14
00007e2c933d2bee  mulpd xmm15, xmm1
00007e2c933d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007e2c933d2bf9  ptest xmm13, xmm13
00007e2c933d2bff  jnz 0x00007E2C933D4B6E
00007e2c933d2c05  lea rax, [r14+0x90]
00007e2c933d2c0c  movups xmm1, [r13+rax*1]
00007e2c933d2c12  vmovaps [rsp+0x100], xmm4
00007e2c933d2c1b  vmovaps xmm14, [rsp+0x100]
00007e2c933d2c24  por xmm4, xmm14
00007e2c933d2c29  movaps [r15+0x1C0], xmm4
00007e2c933d2c31  vmovaps [rsp+0x100], xmm11
00007e2c933d2c3a  vmovaps xmm14, [rsp+0x100]
00007e2c933d2c43  por xmm11, xmm14
00007e2c933d2c48  movaps [r15+0x200], xmm11
00007e2c933d2c50  vmovaps [rsp+0x100], xmm5
00007e2c933d2c59  vmovaps xmm14, [rsp+0x100]
00007e2c933d2c62  por xmm5, xmm14
00007e2c933d2c67  movaps [r15+0x2D0], xmm5
00007e2c933d2c6f  vmovaps xmm14, [rsp+0x120]
00007e2c933d2c78  vmovaps xmm13, [rsp+0x120]
00007e2c933d2c81  por xmm14, xmm13
00007e2c933d2c86  movaps [r15+0x2E0], xmm14
00007e2c933d2c8e  vmovaps [rsp+0x100], xmm1
00007e2c933d2c97  vmovaps xmm1, [rsp+0x110]
00007e2c933d2ca0  vmovaps [rsp+0x110], xmm15
00007e2c933d2ca9  vmovaps xmm15, [rsp+0xD0]
00007e2c933d2cb2  vmovaps [rsp+0xD0], xmm14
00007e2c933d2cbb  movaps xmm13, xmm1
00007e2c933d2cbf  addpd xmm13, xmm15
00007e2c933d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007e2c933d2cca  ptest xmm14, xmm14
00007e2c933d2cd0  jnz 0x00007E2C933D4CBB
00007e2c933d2cd6  vmovaps xmm1, [rsp+0xA0]
00007e2c933d2cdf  vpermilpd xmm1, xmm1, 0x00
00007e2c933d2ce5  vmovaps xmm14, [rsp+0x100]
00007e2c933d2cee  vmovaps [rsp+0x100], xmm13
00007e2c933d2cf7  movaps xmm15, xmm14
00007e2c933d2cfb  mulpd xmm15, xmm1
00007e2c933d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007e2c933d2d06  ptest xmm13, xmm13
00007e2c933d2d0c  jnz 0x00007E2C933D4DFE
00007e2c933d2d12  lea rax, [r14+0x80]
00007e2c933d2d19  movups xmm1, [r13+rax*1]
00007e2c933d2d1f  vmovaps xmm13, [rsp+0xE0]
00007e2c933d2d28  vmovaps [rsp+0xE0], xmm1
00007e2c933d2d31  movaps xmm14, xmm13
00007e2c933d2d35  addpd xmm14, xmm2
00007e2c933d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007e2c933d2d40  ptest xmm1, xmm1
00007e2c933d2d45  jnz 0x00007E2C933D4F4B
00007e2c933d2d4b  vmovaps xmm13, [rsp+0xF0]
00007e2c933d2d54  vmovaps xmm2, [rsp+0x20]
00007e2c933d2d5a  vmovaps [rsp+0x20], xmm15
00007e2c933d2d60  movaps xmm1, xmm13
00007e2c933d2d64  addpd xmm1, xmm2
00007e2c933d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007e2c933d2d6d  ptest xmm15, xmm15
00007e2c933d2d73  jnz 0x00007E2C933D508E
00007e2c933d2d79  vmovaps xmm15, [rsp+0x10]
00007e2c933d2d7f  vmovaps xmm13, [rsp+0x10]
00007e2c933d2d85  por xmm15, xmm13
00007e2c933d2d8a  movaps [r15+0x2F0], xmm15
00007e2c933d2d92  vmovaps xmm13, [rsp+0xA0]
00007e2c933d2d9b  vpermilpd xmm13, xmm13, 0x00
00007e2c933d2da1  vmovaps [rsp+0x10], xmm1
00007e2c933d2da7  vmovaps xmm1, [rsp+0xE0]
00007e2c933d2db0  vmovaps [rsp+0xA0], xmm15
00007e2c933d2db9  movaps xmm2, xmm1
00007e2c933d2dbc  mulpd xmm2, xmm13
00007e2c933d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007e2c933d2dc6  ptest xmm15, xmm15
00007e2c933d2dcc  jnz 0x00007E2C933D51CF
00007e2c933d2dd2  lea rax, [r14+0xD0]
00007e2c933d2dd9  movups xmm1, [r13+rax*1]
00007e2c933d2ddf  vmovaps xmm13, [rsp+0xC0]
00007e2c933d2de8  vmovaps [rsp+0xC0], xmm1
00007e2c933d2df1  vmovaps xmm1, [rsp+0x110]
00007e2c933d2dfa  vmovaps [rsp+0xE0], xmm14
00007e2c933d2e03  movaps xmm15, xmm13
00007e2c933d2e07  addpd xmm15, xmm1
00007e2c933d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007e2c933d2e12  ptest xmm14, xmm14
00007e2c933d2e18  jnz 0x00007E2C933D531A
00007e2c933d2e1e  vmovaps xmm1, [rsp+0xB0]
00007e2c933d2e27  vpermilpd xmm1, xmm1, 0x00
00007e2c933d2e2d  movaps xmm14, xmm11
00007e2c933d2e31  mulpd xmm14, xmm1
00007e2c933d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007e2c933d2e3c  ptest xmm13, xmm13
00007e2c933d2e42  jnz 0x00007E2C933D545D
00007e2c933d2e48  movaps [r15+0x260], xmm14
00007e2c933d2e50  vxorps xmm1, xmm1, xmm1
00007e2c933d2e54  vpbroadcastq xmm1, xmm1
00007e2c933d2e59  movaps [r15+0x1B0], xmm1
00007e2c933d2e61  vmovaps xmm1, [rsp+0xB0]
00007e2c933d2e6a  vpermilpd xmm1, xmm1, 0x00
00007e2c933d2e70  vmovaps xmm11, [rsp+0xC0]
00007e2c933d2e79  vmovaps [rsp+0xC0], xmm15
00007e2c933d2e82  movaps xmm13, xmm11
00007e2c933d2e86  mulpd xmm13, xmm1
00007e2c933d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007e2c933d2e91  ptest xmm15, xmm15
00007e2c933d2e97  jnz 0x00007E2C933D55A0
00007e2c933d2e9d  lea rax, [r14+0xC0]
00007e2c933d2ea4  movups xmm1, [r13+rax*1]
00007e2c933d2eaa  vmovaps xmm11, [rsp+0x100]
00007e2c933d2eb3  vmovaps [rsp+0xF0], xmm1
00007e2c933d2ebc  vmovaps xmm1, [rsp+0x20]
00007e2c933d2ec2  vmovaps [rsp+0x20], xmm14
00007e2c933d2ec8  movaps xmm15, xmm11
00007e2c933d2ecc  addpd xmm15, xmm1
00007e2c933d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007e2c933d2ed7  ptest xmm14, xmm14
00007e2c933d2edd  jnz 0x00007E2C933D56ED
00007e2c933d2ee3  vmovaps [rsp+0x100], xmm9
00007e2c933d2eec  vmovaps xmm1, [rsp+0x100]
00007e2c933d2ef5  por xmm9, xmm1
00007e2c933d2efa  movaps [r15+0x270], xmm9
00007e2c933d2f02  vmovaps [rsp+0x100], xmm6
00007e2c933d2f0b  vmovaps xmm1, [rsp+0x100]
00007e2c933d2f14  por xmm6, xmm1
00007e2c933d2f18  movaps [r15+0x1A0], xmm6
00007e2c933d2f20  vmovaps xmm14, [rsp+0xB0]
00007e2c933d2f29  vpermilpd xmm14, xmm14, 0x00
00007e2c933d2f2f  vmovaps xmm6, [rsp+0xF0]
00007e2c933d2f38  vmovaps [rsp+0xF0], xmm1
00007e2c933d2f41  movaps xmm11, xmm6
00007e2c933d2f45  mulpd xmm11, xmm14
00007e2c933d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007e2c933d2f50  ptest xmm1, xmm1
00007e2c933d2f55  jnz 0x00007E2C933D5830
00007e2c933d2f5b  lea rax, [r14+0x20]
00007e2c933d2f5f  movups xmm1, [r13+rax*1]
00007e2c933d2f65  movaps [r15+0x110], xmm1
00007e2c933d2f6d  vmovaps xmm6, [rsp+0xE0]
00007e2c933d2f76  vmovaps [rsp+0xE0], xmm1
00007e2c933d2f7f  movaps xmm14, xmm6
00007e2c933d2f83  addpd xmm14, xmm2
00007e2c933d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007e2c933d2f8e  ptest xmm1, xmm1
00007e2c933d2f93  jnz 0x00007E2C933D597D
00007e2c933d2f99  vmovaps xmm1, [rsp+0xB0]
00007e2c933d2fa2  vpermilpd xmm1, xmm1, 0x00
00007e2c933d2fa8  movaps xmm6, xmm5
00007e2c933d2fab  mulpd xmm6, xmm1
00007e2c933d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007e2c933d2fb4  ptest xmm2, xmm2
00007e2c933d2fb9  jnz 0x00007E2C933D5ABF
00007e2c933d2fbf  vmovaps xmm5, [rsp+0x10]
00007e2c933d2fc5  movaps xmm1, xmm5
00007e2c933d2fc8  addpd xmm1, xmm13
00007e2c933d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007e2c933d2fd2  ptest xmm2, xmm2
00007e2c933d2fd7  jnz 0x00007E2C933D5BFF
00007e2c933d2fdd  vmovaps xmm13, [rsp+0x80]
00007e2c933d2fe6  vpermilpd xmm13, xmm13, 0x00
00007e2c933d2fec  vmovaps xmm2, [rsp+0xE0]
00007e2c933d2ff5  vmovaps [rsp+0x10], xmm1
00007e2c933d2ffb  movaps xmm5, xmm2
00007e2c933d2ffe  mulpd xmm5, xmm13
00007e2c933d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007e2c933d3008  ptest xmm1, xmm1
00007e2c933d300d  jnz 0x00007E2C933D5D40
00007e2c933d3013  vmovaps xmm1, [rsp+0x80]
00007e2c933d301c  vpermilpd xmm1, xmm1, 0x00
00007e2c933d3022  movaps xmm13, xmm10
00007e2c933d3026  mulpd xmm13, xmm1
00007e2c933d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007e2c933d3031  ptest xmm2, xmm2
00007e2c933d3036  jnz 0x00007E2C933D5E81
00007e2c933d303c  vmovaps xmm10, [rsp+0x20]
00007e2c933d3042  movaps xmm1, xmm15
00007e2c933d3046  addpd xmm1, xmm10
00007e2c933d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e2c933d3050  ptest xmm2, xmm2
00007e2c933d3055  jnz 0x00007E2C933D5FC4
00007e2c933d305b  vmovaps xmm10, [rsp+0xC0]
00007e2c933d3064  movaps xmm15, xmm10
00007e2c933d3068  addpd xmm15, xmm11
00007e2c933d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007e2c933d3073  ptest xmm2, xmm2
00007e2c933d3078  jnz 0x00007E2C933D6106
00007e2c933d307e  vmovaps xmm11, [rsp+0x80]
00007e2c933d3087  vpermilpd xmm11, xmm11, 0x00
00007e2c933d308d  vmovaps xmm2, [rsp+0xD0]
00007e2c933d3096  vmovaps [rsp+0x20], xmm1
00007e2c933d309c  movaps xmm10, xmm2
00007e2c933d30a0  mulpd xmm10, xmm11
00007e2c933d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007e2c933d30ab  ptest xmm1, xmm1
00007e2c933d30b0  jnz 0x00007E2C933D624A
00007e2c933d30b6  vmovaps xmm1, [rsp+0x80]
00007e2c933d30bf  vpermilpd xmm1, xmm1, 0x00
00007e2c933d30c5  vmovaps xmm2, [rsp+0xA0]
00007e2c933d30ce  vmovaps [rsp+0x80], xmm15
00007e2c933d30d7  movaps xmm11, xmm2
00007e2c933d30db  mulpd xmm11, xmm1
00007e2c933d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007e2c933d30e6  ptest xmm15, xmm15
00007e2c933d30ec  jnz 0x00007E2C933D638D
00007e2c933d30f2  movaps xmm1, xmm14
00007e2c933d30f6  addpd xmm1, xmm6
00007e2c933d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007e2c933d30ff  ptest xmm15, xmm15
00007e2c933d3105  jnz 0x00007E2C933D64CF
00007e2c933d310b  vmovaps xmm14, [rsp+0x10]
00007e2c933d3111  movaps xmm15, xmm14
00007e2c933d3115  addpd xmm15, xmm5
00007e2c933d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007e2c933d3120  ptest xmm6, xmm6
00007e2c933d3125  jnz 0x00007E2C933D6610
00007e2c933d312b  vmovaps xmm14, [rsp+0x90]
00007e2c933d3134  vpermilpd xmm14, xmm14, 0x00
00007e2c933d313a  movaps xmm6, xmm9
00007e2c933d313e  mulpd xmm6, xmm14
00007e2c933d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007e2c933d3148  ptest xmm5, xmm5
00007e2c933d314d  jnz 0x00007E2C933D6753
00007e2c933d3153  vmovaps xmm9, [rsp+0x80]
00007e2c933d315c  movaps xmm14, xmm9
00007e2c933d3160  addpd xmm14, xmm13
00007e2c933d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007e2c933d316b  ptest xmm5, xmm5
00007e2c933d3170  jnz 0x00007E2C933D6895
00007e2c933d3176  vmovaps xmm9, [rsp+0x20]
00007e2c933d317c  movaps xmm13, xmm9
00007e2c933d3180  addpd xmm13, xmm10
00007e2c933d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007e2c933d318b  ptest xmm5, xmm5
00007e2c933d3190  jnz 0x00007E2C933D69D9
00007e2c933d3196  vmovaps [rsp+0x10], xmm12
00007e2c933d319c  vmovaps xmm10, [rsp+0x10]
00007e2c933d31a2  por xmm12, xmm10
00007e2c933d31a7  movaps [r15+0x250], xmm12
00007e2c933d31af  vmovaps [rsp+0x10], xmm7
00007e2c933d31b5  vmovaps xmm12, [rsp+0x10]
00007e2c933d31bb  por xmm7, xmm12
00007e2c933d31c0  movaps [r15+0x2A0], xmm7
00007e2c933d31c8  vmovaps [rsp+0x10], xmm3
00007e2c933d31ce  vmovaps xmm12, [rsp+0x10]
00007e2c933d31d4  por xmm3, xmm12
00007e2c933d31d9  movaps [r15+0x1D0], xmm3
00007e2c933d31e1  lea rax, [r14+0x40]
00007e2c933d31e5  movups xmm12, [r13+rax*1]
00007e2c933d31eb  movaps [r15+0x2C0], xmm12
00007e2c933d31f3  vmovaps xmm10, [rsp+0x90]
00007e2c933d31fc  vpermilpd xmm10, xmm10, 0x00
00007e2c933d3202  movaps xmm9, xmm8
00007e2c933d3206  mulpd xmm9, xmm10
00007e2c933d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007e2c933d3211  ptest xmm5, xmm5
00007e2c933d3216  jnz 0x00007E2C933D6B27
00007e2c933d321c  movaps xmm10, xmm1
00007e2c933d3220  addpd xmm10, xmm11
00007e2c933d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007e2c933d322b  ptest xmm8, xmm8
00007e2c933d3231  jnz 0x00007E2C933D6C6B
00007e2c933d3237  movaps xmm1, xmm15
00007e2c933d323b  addpd xmm1, xmm6
00007e2c933d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007e2c933d3244  ptest xmm11, xmm11
00007e2c933d324a  jnz 0x00007E2C933D6DAE
00007e2c933d3250  vmovaps xmm15, [rsp+0x90]
00007e2c933d3259  vpermilpd xmm15, xmm15, 0x00
00007e2c933d325f  movaps xmm11, xmm12
00007e2c933d3263  mulpd xmm11, xmm15
00007e2c933d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007e2c933d326e  ptest xmm8, xmm8
00007e2c933d3274  jnz 0x00007E2C933D6EEF
00007e2c933d327a  vmovaps xmm15, [rsp+0x90]
00007e2c933d3283  vpermilpd xmm15, xmm15, 0x00
00007e2c933d3289  vmovaps xmm8, [rsp+0x50]
00007e2c933d328f  movaps xmm12, xmm8
00007e2c933d3293  mulpd xmm12, xmm15
00007e2c933d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007e2c933d329e  ptest xmm6, xmm6
00007e2c933d32a3  jnz 0x00007E2C933D7033
00007e2c933d32a9  vmovaps xmm15, [rsp+0x30]
00007e2c933d32af  vpermilpd xmm15, xmm15, 0x00
00007e2c933d32b5  movaps xmm8, xmm7
00007e2c933d32b9  mulpd xmm8, xmm15
00007e2c933d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007e2c933d32c4  ptest xmm6, xmm6
00007e2c933d32c9  jnz 0x00007E2C933D7177
00007e2c933d32cf  movaps xmm15, xmm14
00007e2c933d32d3  addpd xmm15, xmm9
00007e2c933d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007e2c933d32de  ptest xmm7, xmm7
00007e2c933d32e3  jnz 0x00007E2C933D72BA
00007e2c933d32e9  vmovaps xmm14, [rsp+0x30]
00007e2c933d32ef  vpermilpd xmm14, xmm14, 0x00
00007e2c933d32f5  vmovaps xmm7, [rsp+0xF0]
00007e2c933d32fe  movaps xmm9, xmm7
00007e2c933d3302  mulpd xmm9, xmm14
00007e2c933d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007e2c933d330d  ptest xmm6, xmm6
00007e2c933d3312  jnz 0x00007E2C933D73FE
00007e2c933d3318  movaps xmm14, xmm13
00007e2c933d331c  addpd xmm14, xmm11
00007e2c933d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007e2c933d3327  ptest xmm7, xmm7
00007e2c933d332c  jnz 0x00007E2C933D7541
00007e2c933d3332  vmovaps xmm13, [rsp+0x30]
00007e2c933d3338  vpermilpd xmm13, xmm13, 0x00
00007e2c933d333e  vmovaps xmm7, [rsp+0x60]
00007e2c933d3344  movaps xmm11, xmm7
00007e2c933d3348  mulpd xmm11, xmm13
00007e2c933d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007e2c933d3353  ptest xmm6, xmm6
00007e2c933d3358  jnz 0x00007E2C933D7685
00007e2c933d335e  movaps xmm13, xmm10
00007e2c933d3362  addpd xmm13, xmm12
00007e2c933d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007e2c933d336d  ptest xmm7, xmm7
00007e2c933d3372  jnz 0x00007E2C933D77C8
00007e2c933d3378  vmovaps xmm12, [rsp+0x30]
00007e2c933d337e  vpermilpd xmm12, xmm12, 0x00
00007e2c933d3384  vmovaps xmm7, [rsp+0x70]
00007e2c933d338a  movaps xmm10, xmm7
00007e2c933d338e  mulpd xmm10, xmm12
00007e2c933d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007e2c933d3399  ptest xmm6, xmm6
00007e2c933d339e  jnz 0x00007E2C933D790C
00007e2c933d33a4  movaps xmm12, xmm1
00007e2c933d33a8  addpd xmm12, xmm8
00007e2c933d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007e2c933d33b3  ptest xmm7, xmm7
00007e2c933d33b8  jnz 0x00007E2C933D7A4F
00007e2c933d33be  lea rax, [r14+0x70]
00007e2c933d33c2  movups xmm1, [r13+rax*1]
00007e2c933d33c8  movaps [r15+0x240], xmm1
00007e2c933d33d0  movaps xmm8, xmm15
00007e2c933d33d4  addpd xmm8, xmm9
00007e2c933d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007e2c933d33df  ptest xmm7, xmm7
00007e2c933d33e4  jnz 0x00007E2C933D7B9C
00007e2c933d33ea  movaps [r15+0x170], xmm8
00007e2c933d33f2  vmovaps xmm15, [rsp+0x40]
00007e2c933d33f8  vpermilpd xmm15, xmm15, 0x00
00007e2c933d33fe  movaps xmm9, xmm1
00007e2c933d3402  mulpd xmm9, xmm15
00007e2c933d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007e2c933d340d  ptest xmm7, xmm7
00007e2c933d3412  jnz 0x00007E2C933D7CE0
00007e2c933d3418  vmovaps xmm1, [rsp+0x40]
00007e2c933d341e  vpermilpd xmm1, xmm1, 0x00
00007e2c933d3424  movaps xmm15, xmm4
00007e2c933d3428  mulpd xmm15, xmm1
00007e2c933d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007e2c933d3433  ptest xmm7, xmm7
00007e2c933d3438  jnz 0x00007E2C933D7E23
00007e2c933d343e  movaps [r15+0x180], xmm15
00007e2c933d3446  movaps xmm1, xmm14
00007e2c933d344a  addpd xmm1, xmm11
00007e2c933d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007e2c933d3454  ptest xmm7, xmm7
00007e2c933d3459  jnz 0x00007E2C933D7F65
00007e2c933d345f  movaps [r15+0x210], xmm1
00007e2c933d3467  movups xmm14, [r13+r14*1]
00007e2c933d346d  lea rax, [r14+0x10]
00007e2c933d3471  movups xmm11, [r13+rax*1]
00007e2c933d3477  movaps [r15+0x230], xmm11
00007e2c933d347f  movaps xmm7, xmm13
00007e2c933d3483  addpd xmm7, xmm10
00007e2c933d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007e2c933d348d  ptest xmm6, xmm6
00007e2c933d3492  jnz 0x00007E2C933D80BB
00007e2c933d3498  movaps [r15+0x130], xmm7
00007e2c933d34a0  vmovaps xmm13, [rsp+0x40]
00007e2c933d34a6  vpermilpd xmm13, xmm13, 0x00
00007e2c933d34ac  movaps xmm10, xmm11
00007e2c933d34b0  mulpd xmm10, xmm13
00007e2c933d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e2c933d34bb  ptest xmm6, xmm6
00007e2c933d34c0  jnz 0x00007E2C933D81FD
00007e2c933d34c6  movaps [r15+0x220], xmm10
00007e2c933d34ce  vmovaps xmm13, [rsp+0x40]
00007e2c933d34d4  vpermilpd xmm13, xmm13, 0x00
00007e2c933d34da  movaps xmm11, xmm14
00007e2c933d34de  mulpd xmm11, xmm13
00007e2c933d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007e2c933d34e9  ptest xmm6, xmm6
00007e2c933d34ee  jnz 0x00007E2C933D8341
00007e2c933d34f4  movaps xmm14, xmm12
00007e2c933d34f8  addpd xmm14, xmm9
00007e2c933d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007e2c933d3503  ptest xmm13, xmm13
00007e2c933d3509  jnz 0x00007E2C933D8485
00007e2c933d350f  movaps [r15+0x140], xmm14
00007e2c933d3517  movaps xmm13, xmm8
00007e2c933d351b  addpd xmm13, xmm15
00007e2c933d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007e2c933d3526  ptest xmm12, xmm12
00007e2c933d352c  jnz 0x00007E2C933D85C9
00007e2c933d3532  movaps [r15+0x150], xmm13
00007e2c933d353a  movaps xmm15, xmm1
00007e2c933d353e  addpd xmm15, xmm10
00007e2c933d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007e2c933d3549  ptest xmm12, xmm12
00007e2c933d354f  jnz 0x00007E2C933D870D
00007e2c933d3555  movaps [r15+0x160], xmm15
00007e2c933d355d  movaps xmm1, xmm7
00007e2c933d3560  addpd xmm1, xmm11
00007e2c933d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007e2c933d356a  ptest xmm12, xmm12
00007e2c933d3570  jnz 0x00007E2C933D8850
00007e2c933d3576  movaps [r15+0x120], xmm1
00007e2c933d357e  mov eax, 0x432200
00007e2c933d3583  movups [r13+rax*1], xmm14
00007e2c933d3589  mov eax, 0x432210
00007e2c933d358e  movups [r13+rax*1], xmm13
00007e2c933d3594  mov eax, 0x432220
00007e2c933d3599  movups [r13+rax*1], xmm15
00007e2c933d359f  mov eax, 0x432230
00007e2c933d35a4  movups [r13+rax*1], xmm1
00007e2c933d35aa  mov eax, [r15+0x108]
00007e2c933d35b1  sahf
00007e2c933d35b2  jnz 0x00007E2C933D35E4
00007e2c933d35b4  cmp dword ptr [r15+0x318], 0x00
00007e2c933d35bc  jz 0x00007E2C933DEAE0
00007e2c933d35c2  nop [rax+rax*1], ax
00007e2c933d35cb  nop [rax+rax*1], eax
00007e2c933d35d3  mov eax, 0x4106D0
00007e2c933d35d8  mov [r15+0x100], rax
00007e2c933d35df  jmp 0x00007E2C931FE110
00007e2c933d35e4  cmp dword ptr [r15+0x318], 0x00
00007e2c933d35ec  jz 0x00007E2C933D89C0
00007e2c933d35f2  nop [rax+rax*1], ax
00007e2c933d35fb  nop [rax+rax*1], eax
00007e2c933d3603  mov eax, 0x410504
00007e2c933d3608  mov [r15+0x100], rax
00007e2c933d360f  jmp 0x00007E2C931FE110
00007e2c933d3614  int3
00007e2c933d3615  call 0x00007E2C932D64F0
00007e2c933d361a  jmp 0x00007E2C933D2311
00007e2c933d361f  call 0x00007E2C932E5820
00007e2c933d3624  jmp 0x00007E2C933D231E
00007e2c933d3629  call 0x00007E2C932E3320
00007e2c933d362e  jmp 0x00007E2C933D2332
00007e2c933d3633  call 0x00007E2C932E20A0
00007e2c933d3638  jmp 0x00007E2C933D233C
00007e2c933d363d  call 0x00007E2C93209D70
00007e2c933d3642  jmp 0x00007E2C933D234A
00007e2c933d3647  call 0x00007E2C932DFBC0
00007e2c933d364c  jmp 0x00007E2C933D2354
00007e2c933d3651  call 0x00007E2C932C4740
00007e2c933d3656  jmp 0x00007E2C933D2368
00007e2c933d365b  call 0x00007E2C932B5400
00007e2c933d3660  jmp 0x00007E2C933D2375
00007e2c933d3665  call 0x00007E2C932B52F0
00007e2c933d366a  jmp 0x00007E2C933D2382
00007e2c933d366f  call 0x00007E2C932C4620
00007e2c933d3674  jmp 0x00007E2C933D238F
00007e2c933d3679  call 0x00007E2C932BD750
00007e2c933d367e  jmp 0x00007E2C933D239C
00007e2c933d3683  call 0x00007E2C932BC4E0
00007e2c933d3688  jmp 0x00007E2C933D23A9
00007e2c933d368d  call 0x00007E2C932BB270
00007e2c933d3692  jmp 0x00007E2C933D23B6
00007e2c933d3697  call 0x00007E2C932BA000
00007e2c933d369c  jmp 0x00007E2C933D23C3
00007e2c933d36a1  call 0x00007E2C932C4740
00007e2c933d36a6  jmp 0x00007E2C933D23D0
00007e2c933d36ab  call 0x00007E2C932B5400
00007e2c933d36b0  jmp 0x00007E2C933D23DD
00007e2c933d36b5  call 0x00007E2C932B52F0
00007e2c933d36ba  jmp 0x00007E2C933D23EA
00007e2c933d36bf  call 0x00007E2C932C4620
00007e2c933d36c4  jmp 0x00007E2C933D23F7
00007e2c933d36c9  call 0x00007E2C932B8D90
00007e2c933d36ce  jmp 0x00007E2C933D2404
00007e2c933d36d3  call 0x00007E2C932B8A20
00007e2c933d36d8  jmp 0x00007E2C933D2411
00007e2c933d36dd  call 0x00007E2C932B77B0
00007e2c933d36e2  jmp 0x00007E2C933D241B
00007e2c933d36e7  call 0x00007E2C932B6550
00007e2c933d36ec  jmp 0x00007E2C933D2425
00007e2c933d36f1  call 0x00007E2C932B5400
00007e2c933d36f6  jmp 0x00007E2C933D2437
00007e2c933d36fb  call 0x00007E2C932C0FC0
00007e2c933d3700  jmp 0x00007E2C933D2441
00007e2c933d3705  call 0x00007E2C932B52F0
00007e2c933d370a  jmp 0x00007E2C933D244B
00007e2c933d370f  call 0x00007E2C932C0EA0
00007e2c933d3714  jmp 0x00007E2C933D2455
00007e2c933d3719  call 0x00007E2C932BFD50
00007e2c933d371e  jmp 0x00007E2C933D245F
00007e2c933d3723  call 0x00007E2C932B8EA0
00007e2c933d3728  jmp 0x00007E2C933D2469
00007e2c933d372d  call 0x00007E2C932BFC30
00007e2c933d3732  jmp 0x00007E2C933D2476
00007e2c933d3737  call 0x00007E2C932B8D90
00007e2c933d373c  jmp 0x00007E2C933D2483
00007e2c933d3741  call 0x00007E2C932B52F0
00007e2c933d3746  jmp 0x00007E2C933D2496
00007e2c933d374b  call 0x00007E2C932B52F0
00007e2c933d3750  jmp 0x00007E2C933D24A9
00007e2c933d3755  call 0x00007E2C932C0FC0
00007e2c933d375a  jmp 0x00007E2C933D24B6
00007e2c933d375f  call 0x00007E2C932C0FC0
00007e2c933d3764  jmp 0x00007E2C933D24C9
00007e2c933d3769  call 0x00007E2C932C0EA0
00007e2c933d376e  jmp 0x00007E2C933D24D6
00007e2c933d3773  call 0x00007E2C932B52F0
00007e2c933d3778  jmp 0x00007E2C933D24E9
00007e2c933d377d  call 0x00007E2C932B52F0
00007e2c933d3782  jmp 0x00007E2C933D24FC
00007e2c933d3787  call 0x00007E2C932B52F0
00007e2c933d378c  jmp 0x00007E2C933D250F
00007e2c933d3791  call 0x00007E2C932B52F0
00007e2c933d3796  jmp 0x00007E2C933D252A
00007e2c933d379b  call 0x00007E2C932B52F0
00007e2c933d37a0  jmp 0x00007E2C933D253D
00007e2c933d37a5  call 0x00007E2C932B5400
00007e2c933d37aa  jmp 0x00007E2C933D257E
00007e2c933d37af  call 0x00007E2C932C0FC0
00007e2c933d37b4  jmp 0x00007E2C933D258B
00007e2c933d37b9  call 0x00007E2C932B52F0
00007e2c933d37be  jmp 0x00007E2C933D2598
00007e2c933d37c3  call 0x00007E2C932C0EA0
00007e2c933d37c8  jmp 0x00007E2C933D25A5
00007e2c933d37cd  call 0x00007E2C931FF540
00007e2c933d37d2  jmp 0x00007E2C933D25C3
00007e2c933d37d7  call 0x00007E2C93208C20
00007e2c933d37dc  jmp 0x00007E2C933D25CD
00007e2c933d37e1  call 0x00007E2C932E21C0
00007e2c933d37e6  jmp 0x00007E2C933D25D3
00007e2c933d37eb  call 0x00007E2C931FF540
00007e2c933d37f0  jmp 0x00007E2C933D25E3
00007e2c933d37f5  call 0x00007E2C932C0370
00007e2c933d37fa  jmp 0x00007E2C933D2611
00007e2c933d37ff  call 0x00007E2C932BF100
00007e2c933d3804  jmp 0x00007E2C933D261A
00007e2c933d3809  call 0x00007E2C932C0370
00007e2c933d380e  jmp 0x00007E2C933D2674
00007e2c933d3813  call 0x00007E2C932BF100
00007e2c933d3818  jmp 0x00007E2C933D267D
00007e2c933d381d  call 0x00007E2C932C0370
00007e2c933d3822  jmp 0x00007E2C933D26C6
00007e2c933d3827  call 0x00007E2C932BF100
00007e2c933d382c  jmp 0x00007E2C933D26CF
00007e2c933d3831  call 0x00007E2C9320B720
00007e2c933d3836  jmp 0x00007E2C933D2714
00007e2c933d383b  call 0x00007E2C932B47C0
00007e2c933d3840  jmp 0x00007E2C933D2727
00007e2c933d3845  call 0x00007E2C93208B00
00007e2c933d384a  jmp 0x00007E2C933D273E
00007e2c933d384f  call 0x00007E2C931FF430
00007e2c933d3854  jmp 0x00007E2C933D2751
00007e2c933d3859  call 0x00007E2C931FF430
00007e2c933d385e  jmp 0x00007E2C933D2764
00007e2c933d3863  sub rsp, 0x08
00007e2c933d3867  push rax
00007e2c933d3868  push rcx
00007e2c933d3869  push rdx
00007e2c933d386a  push rdi
00007e2c933d386b  push rsi
00007e2c933d386c  push r8
00007e2c933d386e  push r9
00007e2c933d3870  push r10
00007e2c933d3872  push r11
00007e2c933d3874  sub rsp, 0xF0
00007e2c933d387b  vmovaps [rsp], xmm0
00007e2c933d3880  vmovaps [rsp+0x10], xmm2
00007e2c933d3886  vmovaps [rsp+0x20], xmm3
00007e2c933d388c  vmovaps [rsp+0x30], xmm4
00007e2c933d3892  vmovaps [rsp+0x40], xmm5
00007e2c933d3898  vmovaps [rsp+0x50], xmm6
00007e2c933d389e  vmovaps [rsp+0x60], xmm7
00007e2c933d38a4  vmovaps [rsp+0x70], xmm8
00007e2c933d38aa  vmovaps [rsp+0x80], xmm9
00007e2c933d38b3  vmovaps [rsp+0x90], xmm10
00007e2c933d38bc  vmovaps [rsp+0xA0], xmm11
00007e2c933d38c5  vmovaps [rsp+0xB0], xmm12
00007e2c933d38ce  vmovaps [rsp+0xC0], xmm13
00007e2c933d38d7  vmovaps [rsp+0xD0], xmm14
00007e2c933d38e0  vmovaps [rsp+0xE0], xmm15
00007e2c933d38e9  sub rsp, 0x30
00007e2c933d38ed  movaps [rsp], xmm1
00007e2c933d38f1  movaps [rsp+0x10], xmm12
00007e2c933d38f7  movaps [rsp+0x20], xmm15
00007e2c933d38fd  lea rdi, [rsp]
00007e2c933d3901  mov esi, 0x00
00007e2c933d3906  mov rax, 0x5A263F1C7530
00007e2c933d3910  call rax
00007e2c933d3912  movaps xmm1, [rsp]
00007e2c933d3916  add rsp, 0x30
00007e2c933d391a  vmovaps xmm0, [rsp]
00007e2c933d391f  vmovaps xmm2, [rsp+0x10]
00007e2c933d3925  vmovaps xmm3, [rsp+0x20]
00007e2c933d392b  vmovaps xmm4, [rsp+0x30]
00007e2c933d3931  vmovaps xmm5, [rsp+0x40]
00007e2c933d3937  vmovaps xmm6, [rsp+0x50]
00007e2c933d393d  vmovaps xmm7, [rsp+0x60]
00007e2c933d3943  vmovaps xmm8, [rsp+0x70]
00007e2c933d3949  vmovaps xmm9, [rsp+0x80]
00007e2c933d3952  vmovaps xmm10, [rsp+0x90]
00007e2c933d395b  vmovaps xmm11, [rsp+0xA0]
00007e2c933d3964  vmovaps xmm12, [rsp+0xB0]
00007e2c933d396d  vmovaps xmm13, [rsp+0xC0]
00007e2c933d3976  vmovaps xmm14, [rsp+0xD0]
00007e2c933d397f  vmovaps xmm15, [rsp+0xE0]
00007e2c933d3988  add rsp, 0xF0
00007e2c933d398f  pop r11
00007e2c933d3991  pop r10
00007e2c933d3993  pop r9
00007e2c933d3995  pop r8
00007e2c933d3997  pop rsi
00007e2c933d3998  pop rdi
00007e2c933d3999  pop rdx
00007e2c933d399a  pop rcx
00007e2c933d399b  pop rax
00007e2c933d399c  add rsp, 0x08
00007e2c933d39a0  jmp 0x00007E2C933D27B2
00007e2c933d39a5  sub rsp, 0x08
00007e2c933d39a9  push rax
00007e2c933d39aa  push rcx
00007e2c933d39ab  push rdx
00007e2c933d39ac  push rdi
00007e2c933d39ad  push rsi
00007e2c933d39ae  push r8
00007e2c933d39b0  push r9
00007e2c933d39b2  push r10
00007e2c933d39b4  push r11
00007e2c933d39b6  sub rsp, 0xF0
00007e2c933d39bd  vmovaps [rsp], xmm0
00007e2c933d39c2  vmovaps [rsp+0x10], xmm1
00007e2c933d39c8  vmovaps [rsp+0x20], xmm2
00007e2c933d39ce  vmovaps [rsp+0x30], xmm3
00007e2c933d39d4  vmovaps [rsp+0x40], xmm4
00007e2c933d39da  vmovaps [rsp+0x50], xmm5
00007e2c933d39e0  vmovaps [rsp+0x60], xmm6
00007e2c933d39e6  vmovaps [rsp+0x70], xmm7
00007e2c933d39ec  vmovaps [rsp+0x80], xmm8
00007e2c933d39f5  vmovaps [rsp+0x90], xmm9
00007e2c933d39fe  vmovaps [rsp+0xA0], xmm10
00007e2c933d3a07  vmovaps [rsp+0xB0], xmm11
00007e2c933d3a10  vmovaps [rsp+0xC0], xmm12
00007e2c933d3a19  vmovaps [rsp+0xD0], xmm13
00007e2c933d3a22  vmovaps [rsp+0xE0], xmm15
00007e2c933d3a2b  sub rsp, 0x30
00007e2c933d3a2f  movaps [rsp], xmm14
00007e2c933d3a34  movaps [rsp+0x10], xmm1
00007e2c933d3a39  movaps [rsp+0x20], xmm15
00007e2c933d3a3f  lea rdi, [rsp]
00007e2c933d3a43  mov esi, 0x00
00007e2c933d3a48  mov rax, 0x5A263F1C7530
00007e2c933d3a52  call rax
00007e2c933d3a54  movaps xmm14, [rsp]
00007e2c933d3a59  add rsp, 0x30
00007e2c933d3a5d  vmovaps xmm0, [rsp]
00007e2c933d3a62  vmovaps xmm1, [rsp+0x10]
00007e2c933d3a68  vmovaps xmm2, [rsp+0x20]
00007e2c933d3a6e  vmovaps xmm3, [rsp+0x30]
00007e2c933d3a74  vmovaps xmm4, [rsp+0x40]
00007e2c933d3a7a  vmovaps xmm5, [rsp+0x50]
00007e2c933d3a80  vmovaps xmm6, [rsp+0x60]
00007e2c933d3a86  vmovaps xmm7, [rsp+0x70]
00007e2c933d3a8c  vmovaps xmm8, [rsp+0x80]
00007e2c933d3a95  vmovaps xmm9, [rsp+0x90]
00007e2c933d3a9e  vmovaps xmm10, [rsp+0xA0]
00007e2c933d3aa7  vmovaps xmm11, [rsp+0xB0]
00007e2c933d3ab0  vmovaps xmm12, [rsp+0xC0]
00007e2c933d3ab9  vmovaps xmm13, [rsp+0xD0]
00007e2c933d3ac2  vmovaps xmm15, [rsp+0xE0]
00007e2c933d3acb  add rsp, 0xF0
00007e2c933d3ad2  pop r11
00007e2c933d3ad4  pop r10
00007e2c933d3ad6  pop r9
00007e2c933d3ad8  pop r8
00007e2c933d3ada  pop rsi
00007e2c933d3adb  pop rdi
00007e2c933d3adc  pop rdx
00007e2c933d3add  pop rcx
00007e2c933d3ade  pop rax
00007e2c933d3adf  add rsp, 0x08
00007e2c933d3ae3  jmp 0x00007E2C933D2800
00007e2c933d3ae8  sub rsp, 0x08
00007e2c933d3aec  push rax
00007e2c933d3aed  push rcx
00007e2c933d3aee  push rdx
00007e2c933d3aef  push rdi
00007e2c933d3af0  push rsi
00007e2c933d3af1  push r8
00007e2c933d3af3  push r9
00007e2c933d3af5  push r10
00007e2c933d3af7  push r11
00007e2c933d3af9  sub rsp, 0xF0
00007e2c933d3b00  vmovaps [rsp], xmm0
00007e2c933d3b05  vmovaps [rsp+0x10], xmm1
00007e2c933d3b0b  vmovaps [rsp+0x20], xmm2
00007e2c933d3b11  vmovaps [rsp+0x30], xmm3
00007e2c933d3b17  vmovaps [rsp+0x40], xmm4
00007e2c933d3b1d  vmovaps [rsp+0x50], xmm5
00007e2c933d3b23  vmovaps [rsp+0x60], xmm6
00007e2c933d3b29  vmovaps [rsp+0x70], xmm7
00007e2c933d3b2f  vmovaps [rsp+0x80], xmm8
00007e2c933d3b38  vmovaps [rsp+0x90], xmm9
00007e2c933d3b41  vmovaps [rsp+0xA0], xmm10
00007e2c933d3b4a  vmovaps [rsp+0xB0], xmm11
00007e2c933d3b53  vmovaps [rsp+0xC0], xmm12
00007e2c933d3b5c  vmovaps [rsp+0xD0], xmm13
00007e2c933d3b65  vmovaps [rsp+0xE0], xmm14
00007e2c933d3b6e  sub rsp, 0x30
00007e2c933d3b72  movaps [rsp], xmm15
00007e2c933d3b77  movaps [rsp+0x10], xmm12
00007e2c933d3b7d  movaps [rsp+0x20], xmm13
00007e2c933d3b83  lea rdi, [rsp]
00007e2c933d3b87  mov esi, 0x00
00007e2c933d3b8c  mov rax, 0x5A263F1C7530
00007e2c933d3b96  call rax
00007e2c933d3b98  movaps xmm15, [rsp]
00007e2c933d3b9d  add rsp, 0x30
00007e2c933d3ba1  vmovaps xmm0, [rsp]
00007e2c933d3ba6  vmovaps xmm1, [rsp+0x10]
00007e2c933d3bac  vmovaps xmm2, [rsp+0x20]
00007e2c933d3bb2  vmovaps xmm3, [rsp+0x30]
00007e2c933d3bb8  vmovaps xmm4, [rsp+0x40]
00007e2c933d3bbe  vmovaps xmm5, [rsp+0x50]
00007e2c933d3bc4  vmovaps xmm6, [rsp+0x60]
00007e2c933d3bca  vmovaps xmm7, [rsp+0x70]
00007e2c933d3bd0  vmovaps xmm8, [rsp+0x80]
00007e2c933d3bd9  vmovaps xmm9, [rsp+0x90]
00007e2c933d3be2  vmovaps xmm10, [rsp+0xA0]
00007e2c933d3beb  vmovaps xmm11, [rsp+0xB0]
00007e2c933d3bf4  vmovaps xmm12, [rsp+0xC0]
00007e2c933d3bfd  vmovaps xmm13, [rsp+0xD0]
00007e2c933d3c06  vmovaps xmm14, [rsp+0xE0]
00007e2c933d3c0f  add rsp, 0xF0
00007e2c933d3c16  pop r11
00007e2c933d3c18  pop r10
00007e2c933d3c1a  pop r9
00007e2c933d3c1c  pop r8
00007e2c933d3c1e  pop rsi
00007e2c933d3c1f  pop rdi
00007e2c933d3c20  pop rdx
00007e2c933d3c21  pop rcx
00007e2c933d3c22  pop rax
00007e2c933d3c23  add rsp, 0x08
00007e2c933d3c27  jmp 0x00007E2C933D2835
00007e2c933d3c2c  sub rsp, 0x08
00007e2c933d3c30  push rax
00007e2c933d3c31  push rcx
00007e2c933d3c32  push rdx
00007e2c933d3c33  push rdi
00007e2c933d3c34  push rsi
00007e2c933d3c35  push r8
00007e2c933d3c37  push r9
00007e2c933d3c39  push r10
00007e2c933d3c3b  push r11
00007e2c933d3c3d  sub rsp, 0xF0
00007e2c933d3c44  vmovaps [rsp], xmm0
00007e2c933d3c49  vmovaps [rsp+0x10], xmm2
00007e2c933d3c4f  vmovaps [rsp+0x20], xmm3
00007e2c933d3c55  vmovaps [rsp+0x30], xmm4
00007e2c933d3c5b  vmovaps [rsp+0x40], xmm5
00007e2c933d3c61  vmovaps [rsp+0x50], xmm6
00007e2c933d3c67  vmovaps [rsp+0x60], xmm7
00007e2c933d3c6d  vmovaps [rsp+0x70], xmm8
00007e2c933d3c73  vmovaps [rsp+0x80], xmm9
00007e2c933d3c7c  vmovaps [rsp+0x90], xmm10
00007e2c933d3c85  vmovaps [rsp+0xA0], xmm11
00007e2c933d3c8e  vmovaps [rsp+0xB0], xmm12
00007e2c933d3c97  vmovaps [rsp+0xC0], xmm13
00007e2c933d3ca0  vmovaps [rsp+0xD0], xmm14
00007e2c933d3ca9  vmovaps [rsp+0xE0], xmm15
00007e2c933d3cb2  sub rsp, 0x30
00007e2c933d3cb6  movaps [rsp], xmm1
00007e2c933d3cba  movaps [rsp+0x10], xmm12
00007e2c933d3cc0  movaps [rsp+0x20], xmm10
00007e2c933d3cc6  lea rdi, [rsp]
00007e2c933d3cca  mov esi, 0x00
00007e2c933d3ccf  mov rax, 0x5A263F1C7530
00007e2c933d3cd9  call rax
00007e2c933d3cdb  movaps xmm1, [rsp]
00007e2c933d3cdf  add rsp, 0x30
00007e2c933d3ce3  vmovaps xmm0, [rsp]
00007e2c933d3ce8  vmovaps xmm2, [rsp+0x10]
00007e2c933d3cee  vmovaps xmm3, [rsp+0x20]
00007e2c933d3cf4  vmovaps xmm4, [rsp+0x30]
00007e2c933d3cfa  vmovaps xmm5, [rsp+0x40]
00007e2c933d3d00  vmovaps xmm6, [rsp+0x50]
00007e2c933d3d06  vmovaps xmm7, [rsp+0x60]
00007e2c933d3d0c  vmovaps xmm8, [rsp+0x70]
00007e2c933d3d12  vmovaps xmm9, [rsp+0x80]
00007e2c933d3d1b  vmovaps xmm10, [rsp+0x90]
00007e2c933d3d24  vmovaps xmm11, [rsp+0xA0]
00007e2c933d3d2d  vmovaps xmm12, [rsp+0xB0]
00007e2c933d3d36  vmovaps xmm13, [rsp+0xC0]
00007e2c933d3d3f  vmovaps xmm14, [rsp+0xD0]
00007e2c933d3d48  vmovaps xmm15, [rsp+0xE0]
00007e2c933d3d51  add rsp, 0xF0
00007e2c933d3d58  pop r11
00007e2c933d3d5a  pop r10
00007e2c933d3d5c  pop r9
00007e2c933d3d5e  pop r8
00007e2c933d3d60  pop rsi
00007e2c933d3d61  pop rdi
00007e2c933d3d62  pop rdx
00007e2c933d3d63  pop rcx
00007e2c933d3d64  pop rax
00007e2c933d3d65  add rsp, 0x08
00007e2c933d3d69  jmp 0x00007E2C933D284F
00007e2c933d3d6e  sub rsp, 0x08
00007e2c933d3d72  push rax
00007e2c933d3d73  push rcx
00007e2c933d3d74  push rdx
00007e2c933d3d75  push rdi
00007e2c933d3d76  push rsi
00007e2c933d3d77  push r8
00007e2c933d3d79  push r9
00007e2c933d3d7b  push r10
00007e2c933d3d7d  push r11
00007e2c933d3d7f  sub rsp, 0xF0
00007e2c933d3d86  vmovaps [rsp], xmm0
00007e2c933d3d8b  vmovaps [rsp+0x10], xmm1
00007e2c933d3d91  vmovaps [rsp+0x20], xmm2
00007e2c933d3d97  vmovaps [rsp+0x30], xmm3
00007e2c933d3d9d  vmovaps [rsp+0x40], xmm4
00007e2c933d3da3  vmovaps [rsp+0x50], xmm5
00007e2c933d3da9  vmovaps [rsp+0x60], xmm6
00007e2c933d3daf  vmovaps [rsp+0x70], xmm7
00007e2c933d3db5  vmovaps [rsp+0x80], xmm8
00007e2c933d3dbe  vmovaps [rsp+0x90], xmm9
00007e2c933d3dc7  vmovaps [rsp+0xA0], xmm10
00007e2c933d3dd0  vmovaps [rsp+0xB0], xmm11
00007e2c933d3dd9  vmovaps [rsp+0xC0], xmm12
00007e2c933d3de2  vmovaps [rsp+0xD0], xmm14
00007e2c933d3deb  vmovaps [rsp+0xE0], xmm15
00007e2c933d3df4  sub rsp, 0x30
00007e2c933d3df8  movaps [rsp], xmm13
00007e2c933d3dfd  movaps [rsp+0x10], xmm12
00007e2c933d3e03  movaps [rsp+0x20], xmm2
00007e2c933d3e08  lea rdi, [rsp]
00007e2c933d3e0c  mov esi, 0x00
00007e2c933d3e11  mov rax, 0x5A263F1C7530
00007e2c933d3e1b  call rax
00007e2c933d3e1d  movaps xmm13, [rsp]
00007e2c933d3e22  add rsp, 0x30
00007e2c933d3e26  vmovaps xmm0, [rsp]
00007e2c933d3e2b  vmovaps xmm1, [rsp+0x10]
00007e2c933d3e31  vmovaps xmm2, [rsp+0x20]
00007e2c933d3e37  vmovaps xmm3, [rsp+0x30]
00007e2c933d3e3d  vmovaps xmm4, [rsp+0x40]
00007e2c933d3e43  vmovaps xmm5, [rsp+0x50]
00007e2c933d3e49  vmovaps xmm6, [rsp+0x60]
00007e2c933d3e4f  vmovaps xmm7, [rsp+0x70]
00007e2c933d3e55  vmovaps xmm8, [rsp+0x80]
00007e2c933d3e5e  vmovaps xmm9, [rsp+0x90]
00007e2c933d3e67  vmovaps xmm10, [rsp+0xA0]
00007e2c933d3e70  vmovaps xmm11, [rsp+0xB0]
00007e2c933d3e79  vmovaps xmm12, [rsp+0xC0]
00007e2c933d3e82  vmovaps xmm14, [rsp+0xD0]
00007e2c933d3e8b  vmovaps xmm15, [rsp+0xE0]
00007e2c933d3e94  add rsp, 0xF0
00007e2c933d3e9b  pop r11
00007e2c933d3e9d  pop r10
00007e2c933d3e9f  pop r9
00007e2c933d3ea1  pop r8
00007e2c933d3ea3  pop rsi
00007e2c933d3ea4  pop rdi
00007e2c933d3ea5  pop rdx
00007e2c933d3ea6  pop rcx
00007e2c933d3ea7  pop rax
00007e2c933d3ea8  add rsp, 0x08
00007e2c933d3eac  jmp 0x00007E2C933D286A
00007e2c933d3eb1  sub rsp, 0x08
00007e2c933d3eb5  push rax
00007e2c933d3eb6  push rcx
00007e2c933d3eb7  push rdx
00007e2c933d3eb8  push rdi
00007e2c933d3eb9  push rsi
00007e2c933d3eba  push r8
00007e2c933d3ebc  push r9
00007e2c933d3ebe  push r10
00007e2c933d3ec0  push r11
00007e2c933d3ec2  sub rsp, 0xF0
00007e2c933d3ec9  vmovaps [rsp], xmm0
00007e2c933d3ece  vmovaps [rsp+0x10], xmm2
00007e2c933d3ed4  vmovaps [rsp+0x20], xmm3
00007e2c933d3eda  vmovaps [rsp+0x30], xmm4
00007e2c933d3ee0  vmovaps [rsp+0x40], xmm5
00007e2c933d3ee6  vmovaps [rsp+0x50], xmm6
00007e2c933d3eec  vmovaps [rsp+0x60], xmm7
00007e2c933d3ef2  vmovaps [rsp+0x70], xmm8
00007e2c933d3ef8  vmovaps [rsp+0x80], xmm9
00007e2c933d3f01  vmovaps [rsp+0x90], xmm10
00007e2c933d3f0a  vmovaps [rsp+0xA0], xmm11
00007e2c933d3f13  vmovaps [rsp+0xB0], xmm12
00007e2c933d3f1c  vmovaps [rsp+0xC0], xmm13
00007e2c933d3f25  vmovaps [rsp+0xD0], xmm14
00007e2c933d3f2e  vmovaps [rsp+0xE0], xmm15
00007e2c933d3f37  sub rsp, 0x30
00007e2c933d3f3b  movaps [rsp], xmm1
00007e2c933d3f3f  movaps [rsp+0x10], xmm10
00007e2c933d3f45  movaps [rsp+0x20], xmm2
00007e2c933d3f4a  lea rdi, [rsp]
00007e2c933d3f4e  mov esi, 0x00
00007e2c933d3f53  mov rax, 0x5A263F1C7530
00007e2c933d3f5d  call rax
00007e2c933d3f5f  movaps xmm1, [rsp]
00007e2c933d3f63  add rsp, 0x30
00007e2c933d3f67  vmovaps xmm0, [rsp]
00007e2c933d3f6c  vmovaps xmm2, [rsp+0x10]
00007e2c933d3f72  vmovaps xmm3, [rsp+0x20]
00007e2c933d3f78  vmovaps xmm4, [rsp+0x30]
00007e2c933d3f7e  vmovaps xmm5, [rsp+0x40]
00007e2c933d3f84  vmovaps xmm6, [rsp+0x50]
00007e2c933d3f8a  vmovaps xmm7, [rsp+0x60]
00007e2c933d3f90  vmovaps xmm8, [rsp+0x70]
00007e2c933d3f96  vmovaps xmm9, [rsp+0x80]
00007e2c933d3f9f  vmovaps xmm10, [rsp+0x90]
00007e2c933d3fa8  vmovaps xmm11, [rsp+0xA0]
00007e2c933d3fb1  vmovaps xmm12, [rsp+0xB0]
00007e2c933d3fba  vmovaps xmm13, [rsp+0xC0]
00007e2c933d3fc3  vmovaps xmm14, [rsp+0xD0]
00007e2c933d3fcc  vmovaps xmm15, [rsp+0xE0]
00007e2c933d3fd5  add rsp, 0xF0
00007e2c933d3fdc  pop r11
00007e2c933d3fde  pop r10
00007e2c933d3fe0  pop r9
00007e2c933d3fe2  pop r8
00007e2c933d3fe4  pop rsi
00007e2c933d3fe5  pop rdi
00007e2c933d3fe6  pop rdx
00007e2c933d3fe7  pop rcx
00007e2c933d3fe8  pop rax
00007e2c933d3fe9  add rsp, 0x08
00007e2c933d3fed  jmp 0x00007E2C933D28D2
00007e2c933d3ff2  sub rsp, 0x08
00007e2c933d3ff6  push rax
00007e2c933d3ff7  push rcx
00007e2c933d3ff8  push rdx
00007e2c933d3ff9  push rdi
00007e2c933d3ffa  push rsi
00007e2c933d3ffb  push r8
00007e2c933d3ffd  push r9
00007e2c933d3fff  push r10
00007e2c933d4001  push r11
00007e2c933d4003  sub rsp, 0xF0
00007e2c933d400a  vmovaps [rsp], xmm0
00007e2c933d400f  vmovaps [rsp+0x10], xmm1
00007e2c933d4015  vmovaps [rsp+0x20], xmm2
00007e2c933d401b  vmovaps [rsp+0x30], xmm3
00007e2c933d4021  vmovaps [rsp+0x40], xmm4
00007e2c933d4027  vmovaps [rsp+0x50], xmm5
00007e2c933d402d  vmovaps [rsp+0x60], xmm6
00007e2c933d4033  vmovaps [rsp+0x70], xmm7
00007e2c933d4039  vmovaps [rsp+0x80], xmm8
00007e2c933d4042  vmovaps [rsp+0x90], xmm9
00007e2c933d404b  vmovaps [rsp+0xA0], xmm10
00007e2c933d4054  vmovaps [rsp+0xB0], xmm11
00007e2c933d405d  vmovaps [rsp+0xC0], xmm12
00007e2c933d4066  vmovaps [rsp+0xD0], xmm13
00007e2c933d406f  vmovaps [rsp+0xE0], xmm14
00007e2c933d4078  sub rsp, 0x30
00007e2c933d407c  movaps [rsp], xmm15
00007e2c933d4081  movaps [rsp+0x10], xmm10
00007e2c933d4087  movaps [rsp+0x20], xmm2
00007e2c933d408c  lea rdi, [rsp]
00007e2c933d4090  mov esi, 0x00
00007e2c933d4095  mov rax, 0x5A263F1C7530
00007e2c933d409f  call rax
00007e2c933d40a1  movaps xmm15, [rsp]
00007e2c933d40a6  add rsp, 0x30
00007e2c933d40aa  vmovaps xmm0, [rsp]
00007e2c933d40af  vmovaps xmm1, [rsp+0x10]
00007e2c933d40b5  vmovaps xmm2, [rsp+0x20]
00007e2c933d40bb  vmovaps xmm3, [rsp+0x30]
00007e2c933d40c1  vmovaps xmm4, [rsp+0x40]
00007e2c933d40c7  vmovaps xmm5, [rsp+0x50]
00007e2c933d40cd  vmovaps xmm6, [rsp+0x60]
00007e2c933d40d3  vmovaps xmm7, [rsp+0x70]
00007e2c933d40d9  vmovaps xmm8, [rsp+0x80]
00007e2c933d40e2  vmovaps xmm9, [rsp+0x90]
00007e2c933d40eb  vmovaps xmm10, [rsp+0xA0]
00007e2c933d40f4  vmovaps xmm11, [rsp+0xB0]
00007e2c933d40fd  vmovaps xmm12, [rsp+0xC0]
00007e2c933d4106  vmovaps xmm13, [rsp+0xD0]
00007e2c933d410f  vmovaps xmm14, [rsp+0xE0]
00007e2c933d4118  add rsp, 0xF0
00007e2c933d411f  pop r11
00007e2c933d4121  pop r10
00007e2c933d4123  pop r9
00007e2c933d4125  pop r8
00007e2c933d4127  pop rsi
00007e2c933d4128  pop rdi
00007e2c933d4129  pop rdx
00007e2c933d412a  pop rcx
00007e2c933d412b  pop rax
00007e2c933d412c  add rsp, 0x08
00007e2c933d4130  jmp 0x00007E2C933D2924
00007e2c933d4135  sub rsp, 0x08
00007e2c933d4139  push rax
00007e2c933d413a  push rcx
00007e2c933d413b  push rdx
00007e2c933d413c  push rdi
00007e2c933d413d  push rsi
00007e2c933d413e  push r8
00007e2c933d4140  push r9
00007e2c933d4142  push r10
00007e2c933d4144  push r11
00007e2c933d4146  sub rsp, 0xF0
00007e2c933d414d  vmovaps [rsp], xmm0
00007e2c933d4152  vmovaps [rsp+0x10], xmm2
00007e2c933d4158  vmovaps [rsp+0x20], xmm3
00007e2c933d415e  vmovaps [rsp+0x30], xmm4
00007e2c933d4164  vmovaps [rsp+0x40], xmm5
00007e2c933d416a  vmovaps [rsp+0x50], xmm6
00007e2c933d4170  vmovaps [rsp+0x60], xmm7
00007e2c933d4176  vmovaps [rsp+0x70], xmm8
00007e2c933d417c  vmovaps [rsp+0x80], xmm9
00007e2c933d4185  vmovaps [rsp+0x90], xmm10
00007e2c933d418e  vmovaps [rsp+0xA0], xmm11
00007e2c933d4197  vmovaps [rsp+0xB0], xmm12
00007e2c933d41a0  vmovaps [rsp+0xC0], xmm13
00007e2c933d41a9  vmovaps [rsp+0xD0], xmm14
00007e2c933d41b2  vmovaps [rsp+0xE0], xmm15
00007e2c933d41bb  sub rsp, 0x30
00007e2c933d41bf  movaps [rsp], xmm1
00007e2c933d41c3  movaps [rsp+0x10], xmm10
00007e2c933d41c9  movaps [rsp+0x20], xmm15
00007e2c933d41cf  lea rdi, [rsp]
00007e2c933d41d3  mov esi, 0x00
00007e2c933d41d8  mov rax, 0x5A263F1C7530
00007e2c933d41e2  call rax
00007e2c933d41e4  movaps xmm1, [rsp]
00007e2c933d41e8  add rsp, 0x30
00007e2c933d41ec  vmovaps xmm0, [rsp]
00007e2c933d41f1  vmovaps xmm2, [rsp+0x10]
00007e2c933d41f7  vmovaps xmm3, [rsp+0x20]
00007e2c933d41fd  vmovaps xmm4, [rsp+0x30]
00007e2c933d4203  vmovaps xmm5, [rsp+0x40]
00007e2c933d4209  vmovaps xmm6, [rsp+0x50]
00007e2c933d420f  vmovaps xmm7, [rsp+0x60]
00007e2c933d4215  vmovaps xmm8, [rsp+0x70]
00007e2c933d421b  vmovaps xmm9, [rsp+0x80]
00007e2c933d4224  vmovaps xmm10, [rsp+0x90]
00007e2c933d422d  vmovaps xmm11, [rsp+0xA0]
00007e2c933d4236  vmovaps xmm12, [rsp+0xB0]
00007e2c933d423f  vmovaps xmm13, [rsp+0xC0]
00007e2c933d4248  vmovaps xmm14, [rsp+0xD0]
00007e2c933d4251  vmovaps xmm15, [rsp+0xE0]
00007e2c933d425a  add rsp, 0xF0
00007e2c933d4261  pop r11
00007e2c933d4263  pop r10
00007e2c933d4265  pop r9
00007e2c933d4267  pop r8
00007e2c933d4269  pop rsi
00007e2c933d426a  pop rdi
00007e2c933d426b  pop rdx
00007e2c933d426c  pop rcx
00007e2c933d426d  pop rax
00007e2c933d426e  add rsp, 0x08
00007e2c933d4272  jmp 0x00007E2C933D2962
00007e2c933d4277  sub rsp, 0x08
00007e2c933d427b  push rax
00007e2c933d427c  push rcx
00007e2c933d427d  push rdx
00007e2c933d427e  push rdi
00007e2c933d427f  push rsi
00007e2c933d4280  push r8
00007e2c933d4282  push r9
00007e2c933d4284  push r10
00007e2c933d4286  push r11
00007e2c933d4288  sub rsp, 0xF0
00007e2c933d428f  vmovaps [rsp], xmm0
00007e2c933d4294  vmovaps [rsp+0x10], xmm1
00007e2c933d429a  vmovaps [rsp+0x20], xmm2
00007e2c933d42a0  vmovaps [rsp+0x30], xmm3
00007e2c933d42a6  vmovaps [rsp+0x40], xmm4
00007e2c933d42ac  vmovaps [rsp+0x50], xmm5
00007e2c933d42b2  vmovaps [rsp+0x60], xmm6
00007e2c933d42b8  vmovaps [rsp+0x70], xmm7
00007e2c933d42be  vmovaps [rsp+0x80], xmm8
00007e2c933d42c7  vmovaps [rsp+0x90], xmm9
00007e2c933d42d0  vmovaps [rsp+0xA0], xmm10
00007e2c933d42d9  vmovaps [rsp+0xB0], xmm11
00007e2c933d42e2  vmovaps [rsp+0xC0], xmm12
00007e2c933d42eb  vmovaps [rsp+0xD0], xmm13
00007e2c933d42f4  vmovaps [rsp+0xE0], xmm15
00007e2c933d42fd  sub rsp, 0x30
00007e2c933d4301  movaps [rsp], xmm14
00007e2c933d4306  movaps [rsp+0x10], xmm10
00007e2c933d430c  movaps [rsp+0x20], xmm15
00007e2c933d4312  lea rdi, [rsp]
00007e2c933d4316  mov esi, 0x00
00007e2c933d431b  mov rax, 0x5A263F1C7530
00007e2c933d4325  call rax
00007e2c933d4327  movaps xmm14, [rsp]
00007e2c933d432c  add rsp, 0x30
00007e2c933d4330  vmovaps xmm0, [rsp]
00007e2c933d4335  vmovaps xmm1, [rsp+0x10]
00007e2c933d433b  vmovaps xmm2, [rsp+0x20]
00007e2c933d4341  vmovaps xmm3, [rsp+0x30]
00007e2c933d4347  vmovaps xmm4, [rsp+0x40]
00007e2c933d434d  vmovaps xmm5, [rsp+0x50]
00007e2c933d4353  vmovaps xmm6, [rsp+0x60]
00007e2c933d4359  vmovaps xmm7, [rsp+0x70]
00007e2c933d435f  vmovaps xmm8, [rsp+0x80]
00007e2c933d4368  vmovaps xmm9, [rsp+0x90]
00007e2c933d4371  vmovaps xmm10, [rsp+0xA0]
00007e2c933d437a  vmovaps xmm11, [rsp+0xB0]
00007e2c933d4383  vmovaps xmm12, [rsp+0xC0]
00007e2c933d438c  vmovaps xmm13, [rsp+0xD0]
00007e2c933d4395  vmovaps xmm15, [rsp+0xE0]
00007e2c933d439e  add rsp, 0xF0
00007e2c933d43a5  pop r11
00007e2c933d43a7  pop r10
00007e2c933d43a9  pop r9
00007e2c933d43ab  pop r8
00007e2c933d43ad  pop rsi
00007e2c933d43ae  pop rdi
00007e2c933d43af  pop rdx
00007e2c933d43b0  pop rcx
00007e2c933d43b1  pop rax
00007e2c933d43b2  add rsp, 0x08
00007e2c933d43b6  jmp 0x00007E2C933D298E
00007e2c933d43bb  call 0x00007E2C931FF430
00007e2c933d43c0  jmp 0x00007E2C933D2A1E
00007e2c933d43c5  call 0x00007E2C931FF430
00007e2c933d43ca  jmp 0x00007E2C933D2A31
00007e2c933d43cf  sub rsp, 0x08
00007e2c933d43d3  push rax
00007e2c933d43d4  push rcx
00007e2c933d43d5  push rdx
00007e2c933d43d6  push rdi
00007e2c933d43d7  push rsi
00007e2c933d43d8  push r8
00007e2c933d43da  push r9
00007e2c933d43dc  push r10
00007e2c933d43de  push r11
00007e2c933d43e0  sub rsp, 0xF0
00007e2c933d43e7  vmovaps [rsp], xmm0
00007e2c933d43ec  vmovaps [rsp+0x10], xmm2
00007e2c933d43f2  vmovaps [rsp+0x20], xmm3
00007e2c933d43f8  vmovaps [rsp+0x30], xmm4
00007e2c933d43fe  vmovaps [rsp+0x40], xmm5
00007e2c933d4404  vmovaps [rsp+0x50], xmm6
00007e2c933d440a  vmovaps [rsp+0x60], xmm7
00007e2c933d4410  vmovaps [rsp+0x70], xmm8
00007e2c933d4416  vmovaps [rsp+0x80], xmm9
00007e2c933d441f  vmovaps [rsp+0x90], xmm10
00007e2c933d4428  vmovaps [rsp+0xA0], xmm11
00007e2c933d4431  vmovaps [rsp+0xB0], xmm12
00007e2c933d443a  vmovaps [rsp+0xC0], xmm13
00007e2c933d4443  vmovaps [rsp+0xD0], xmm14
00007e2c933d444c  vmovaps [rsp+0xE0], xmm15
00007e2c933d4455  sub rsp, 0x30
00007e2c933d4459  movaps [rsp], xmm1
00007e2c933d445d  movaps [rsp+0x10], xmm13
00007e2c933d4463  movaps [rsp+0x20], xmm2
00007e2c933d4468  lea rdi, [rsp]
00007e2c933d446c  mov esi, 0x00
00007e2c933d4471  mov rax, 0x5A263F1C7530
00007e2c933d447b  call rax
00007e2c933d447d  movaps xmm1, [rsp]
00007e2c933d4481  add rsp, 0x30
00007e2c933d4485  vmovaps xmm0, [rsp]
00007e2c933d448a  vmovaps xmm2, [rsp+0x10]
00007e2c933d4490  vmovaps xmm3, [rsp+0x20]
00007e2c933d4496  vmovaps xmm4, [rsp+0x30]
00007e2c933d449c  vmovaps xmm5, [rsp+0x40]
00007e2c933d44a2  vmovaps xmm6, [rsp+0x50]
00007e2c933d44a8  vmovaps xmm7, [rsp+0x60]
00007e2c933d44ae  vmovaps xmm8, [rsp+0x70]
00007e2c933d44b4  vmovaps xmm9, [rsp+0x80]
00007e2c933d44bd  vmovaps xmm10, [rsp+0x90]
00007e2c933d44c6  vmovaps xmm11, [rsp+0xA0]
00007e2c933d44cf  vmovaps xmm12, [rsp+0xB0]
00007e2c933d44d8  vmovaps xmm13, [rsp+0xC0]
00007e2c933d44e1  vmovaps xmm14, [rsp+0xD0]
00007e2c933d44ea  vmovaps xmm15, [rsp+0xE0]
00007e2c933d44f3  add rsp, 0xF0
00007e2c933d44fa  pop r11
00007e2c933d44fc  pop r10
00007e2c933d44fe  pop r9
00007e2c933d4500  pop r8
00007e2c933d4502  pop rsi
00007e2c933d4503  pop rdi
00007e2c933d4504  pop rdx
00007e2c933d4505  pop rcx
00007e2c933d4506  pop rax
00007e2c933d4507  add rsp, 0x08
00007e2c933d450b  jmp 0x00007E2C933D2A5C
00007e2c933d4510  call 0x00007E2C9320E760
00007e2c933d4515  jmp 0x00007E2C933D2A69
00007e2c933d451a  sub rsp, 0x08
00007e2c933d451e  push rax
00007e2c933d451f  push rcx
00007e2c933d4520  push rdx
00007e2c933d4521  push rdi
00007e2c933d4522  push rsi
00007e2c933d4523  push r8
00007e2c933d4525  push r9
00007e2c933d4527  push r10
00007e2c933d4529  push r11
00007e2c933d452b  sub rsp, 0xF0
00007e2c933d4532  vmovaps [rsp], xmm0
00007e2c933d4537  vmovaps [rsp+0x10], xmm1
00007e2c933d453d  vmovaps [rsp+0x20], xmm2
00007e2c933d4543  vmovaps [rsp+0x30], xmm3
00007e2c933d4549  vmovaps [rsp+0x40], xmm4
00007e2c933d454f  vmovaps [rsp+0x50], xmm5
00007e2c933d4555  vmovaps [rsp+0x60], xmm6
00007e2c933d455b  vmovaps [rsp+0x70], xmm7
00007e2c933d4561  vmovaps [rsp+0x80], xmm8
00007e2c933d456a  vmovaps [rsp+0x90], xmm9
00007e2c933d4573  vmovaps [rsp+0xA0], xmm10
00007e2c933d457c  vmovaps [rsp+0xB0], xmm11
00007e2c933d4585  vmovaps [rsp+0xC0], xmm12
00007e2c933d458e  vmovaps [rsp+0xD0], xmm14
00007e2c933d4597  vmovaps [rsp+0xE0], xmm15
00007e2c933d45a0  sub rsp, 0x30
00007e2c933d45a4  movaps [rsp], xmm13
00007e2c933d45a9  movaps [rsp+0x10], xmm2
00007e2c933d45ae  movaps [rsp+0x20], xmm1
00007e2c933d45b3  lea rdi, [rsp]
00007e2c933d45b7  mov esi, 0x00
00007e2c933d45bc  mov rax, 0x5A263F1C7530
00007e2c933d45c6  call rax
00007e2c933d45c8  movaps xmm13, [rsp]
00007e2c933d45cd  add rsp, 0x30
00007e2c933d45d1  vmovaps xmm0, [rsp]
00007e2c933d45d6  vmovaps xmm1, [rsp+0x10]
00007e2c933d45dc  vmovaps xmm2, [rsp+0x20]
00007e2c933d45e2  vmovaps xmm3, [rsp+0x30]
00007e2c933d45e8  vmovaps xmm4, [rsp+0x40]
00007e2c933d45ee  vmovaps xmm5, [rsp+0x50]
00007e2c933d45f4  vmovaps xmm6, [rsp+0x60]
00007e2c933d45fa  vmovaps xmm7, [rsp+0x70]
00007e2c933d4600  vmovaps xmm8, [rsp+0x80]
00007e2c933d4609  vmovaps xmm9, [rsp+0x90]
00007e2c933d4612  vmovaps xmm10, [rsp+0xA0]
00007e2c933d461b  vmovaps xmm11, [rsp+0xB0]
00007e2c933d4624  vmovaps xmm12, [rsp+0xC0]
00007e2c933d462d  vmovaps xmm14, [rsp+0xD0]
00007e2c933d4636  vmovaps xmm15, [rsp+0xE0]
00007e2c933d463f  add rsp, 0xF0
00007e2c933d4646  pop r11
00007e2c933d4648  pop r10
00007e2c933d464a  pop r9
00007e2c933d464c  pop r8
00007e2c933d464e  pop rsi
00007e2c933d464f  pop rdi
00007e2c933d4650  pop rdx
00007e2c933d4651  pop rcx
00007e2c933d4652  pop rax
00007e2c933d4653  add rsp, 0x08
00007e2c933d4657  jmp 0x00007E2C933D2AA8
00007e2c933d465c  sub rsp, 0x08
00007e2c933d4660  push rax
00007e2c933d4661  push rcx
00007e2c933d4662  push rdx
00007e2c933d4663  push rdi
00007e2c933d4664  push rsi
00007e2c933d4665  push r8
00007e2c933d4667  push r9
00007e2c933d4669  push r10
00007e2c933d466b  push r11
00007e2c933d466d  sub rsp, 0xF0
00007e2c933d4674  vmovaps [rsp], xmm0
00007e2c933d4679  vmovaps [rsp+0x10], xmm2
00007e2c933d467f  vmovaps [rsp+0x20], xmm3
00007e2c933d4685  vmovaps [rsp+0x30], xmm4
00007e2c933d468b  vmovaps [rsp+0x40], xmm5
00007e2c933d4691  vmovaps [rsp+0x50], xmm6
00007e2c933d4697  vmovaps [rsp+0x60], xmm7
00007e2c933d469d  vmovaps [rsp+0x70], xmm8
00007e2c933d46a3  vmovaps [rsp+0x80], xmm9
00007e2c933d46ac  vmovaps [rsp+0x90], xmm10
00007e2c933d46b5  vmovaps [rsp+0xA0], xmm11
00007e2c933d46be  vmovaps [rsp+0xB0], xmm12
00007e2c933d46c7  vmovaps [rsp+0xC0], xmm13
00007e2c933d46d0  vmovaps [rsp+0xD0], xmm14
00007e2c933d46d9  vmovaps [rsp+0xE0], xmm15
00007e2c933d46e2  sub rsp, 0x30
00007e2c933d46e6  movaps [rsp], xmm1
00007e2c933d46ea  movaps [rsp+0x10], xmm14
00007e2c933d46f0  movaps [rsp+0x20], xmm15
00007e2c933d46f6  lea rdi, [rsp]
00007e2c933d46fa  mov esi, 0x00
00007e2c933d46ff  mov rax, 0x5A263F1C7530
00007e2c933d4709  call rax
00007e2c933d470b  movaps xmm1, [rsp]
00007e2c933d470f  add rsp, 0x30
00007e2c933d4713  vmovaps xmm0, [rsp]
00007e2c933d4718  vmovaps xmm2, [rsp+0x10]
00007e2c933d471e  vmovaps xmm3, [rsp+0x20]
00007e2c933d4724  vmovaps xmm4, [rsp+0x30]
00007e2c933d472a  vmovaps xmm5, [rsp+0x40]
00007e2c933d4730  vmovaps xmm6, [rsp+0x50]
00007e2c933d4736  vmovaps xmm7, [rsp+0x60]
00007e2c933d473c  vmovaps xmm8, [rsp+0x70]
00007e2c933d4742  vmovaps xmm9, [rsp+0x80]
00007e2c933d474b  vmovaps xmm10, [rsp+0x90]
00007e2c933d4754  vmovaps xmm11, [rsp+0xA0]
00007e2c933d475d  vmovaps xmm12, [rsp+0xB0]
00007e2c933d4766  vmovaps xmm13, [rsp+0xC0]
00007e2c933d476f  vmovaps xmm14, [rsp+0xD0]
00007e2c933d4778  vmovaps xmm15, [rsp+0xE0]
00007e2c933d4781  add rsp, 0xF0
00007e2c933d4788  pop r11
00007e2c933d478a  pop r10
00007e2c933d478c  pop r9
00007e2c933d478e  pop r8
00007e2c933d4790  pop rsi
00007e2c933d4791  pop rdi
00007e2c933d4792  pop rdx
00007e2c933d4793  pop rcx
00007e2c933d4794  pop rax
00007e2c933d4795  add rsp, 0x08
00007e2c933d4799  jmp 0x00007E2C933D2ACA
00007e2c933d479e  sub rsp, 0x08
00007e2c933d47a2  push rax
00007e2c933d47a3  push rcx
00007e2c933d47a4  push rdx
00007e2c933d47a5  push rdi
00007e2c933d47a6  push rsi
00007e2c933d47a7  push r8
00007e2c933d47a9  push r9
00007e2c933d47ab  push r10
00007e2c933d47ad  push r11
00007e2c933d47af  sub rsp, 0xF0
00007e2c933d47b6  vmovaps [rsp], xmm0
00007e2c933d47bb  vmovaps [rsp+0x10], xmm1
00007e2c933d47c1  vmovaps [rsp+0x20], xmm2
00007e2c933d47c7  vmovaps [rsp+0x30], xmm3
00007e2c933d47cd  vmovaps [rsp+0x40], xmm4
00007e2c933d47d3  vmovaps [rsp+0x50], xmm5
00007e2c933d47d9  vmovaps [rsp+0x60], xmm6
00007e2c933d47df  vmovaps [rsp+0x70], xmm7
00007e2c933d47e5  vmovaps [rsp+0x80], xmm8
00007e2c933d47ee  vmovaps [rsp+0x90], xmm9
00007e2c933d47f7  vmovaps [rsp+0xA0], xmm10
00007e2c933d4800  vmovaps [rsp+0xB0], xmm11
00007e2c933d4809  vmovaps [rsp+0xC0], xmm12
00007e2c933d4812  vmovaps [rsp+0xD0], xmm13
00007e2c933d481b  vmovaps [rsp+0xE0], xmm15
00007e2c933d4824  sub rsp, 0x30
00007e2c933d4828  movaps [rsp], xmm14
00007e2c933d482d  movaps [rsp+0x10], xmm2
00007e2c933d4832  movaps [rsp+0x20], xmm15
00007e2c933d4838  lea rdi, [rsp]
00007e2c933d483c  mov esi, 0x00
00007e2c933d4841  mov rax, 0x5A263F1C7530
00007e2c933d484b  call rax
00007e2c933d484d  movaps xmm14, [rsp]
00007e2c933d4852  add rsp, 0x30
00007e2c933d4856  vmovaps xmm0, [rsp]
00007e2c933d485b  vmovaps xmm1, [rsp+0x10]
00007e2c933d4861  vmovaps xmm2, [rsp+0x20]
00007e2c933d4867  vmovaps xmm3, [rsp+0x30]
00007e2c933d486d  vmovaps xmm4, [rsp+0x40]
00007e2c933d4873  vmovaps xmm5, [rsp+0x50]
00007e2c933d4879  vmovaps xmm6, [rsp+0x60]
00007e2c933d487f  vmovaps xmm7, [rsp+0x70]
00007e2c933d4885  vmovaps xmm8, [rsp+0x80]
00007e2c933d488e  vmovaps xmm9, [rsp+0x90]
00007e2c933d4897  vmovaps xmm10, [rsp+0xA0]
00007e2c933d48a0  vmovaps xmm11, [rsp+0xB0]
00007e2c933d48a9  vmovaps xmm12, [rsp+0xC0]
00007e2c933d48b2  vmovaps xmm13, [rsp+0xD0]
00007e2c933d48bb  vmovaps xmm15, [rsp+0xE0]
00007e2c933d48c4  add rsp, 0xF0
00007e2c933d48cb  pop r11
00007e2c933d48cd  pop r10
00007e2c933d48cf  pop r9
00007e2c933d48d1  pop r8
00007e2c933d48d3  pop rsi
00007e2c933d48d4  pop rdi
00007e2c933d48d5  pop rdx
00007e2c933d48d6  pop rcx
00007e2c933d48d7  pop rax
00007e2c933d48d8  add rsp, 0x08
00007e2c933d48dc  jmp 0x00007E2C933D2B05
00007e2c933d48e1  sub rsp, 0x08
00007e2c933d48e5  push rax
00007e2c933d48e6  push rcx
00007e2c933d48e7  push rdx
00007e2c933d48e8  push rdi
00007e2c933d48e9  push rsi
00007e2c933d48ea  push r8
00007e2c933d48ec  push r9
00007e2c933d48ee  push r10
00007e2c933d48f0  push r11
00007e2c933d48f2  sub rsp, 0xF0
00007e2c933d48f9  vmovaps [rsp], xmm0
00007e2c933d48fe  vmovaps [rsp+0x10], xmm1
00007e2c933d4904  vmovaps [rsp+0x20], xmm2
00007e2c933d490a  vmovaps [rsp+0x30], xmm3
00007e2c933d4910  vmovaps [rsp+0x40], xmm4
00007e2c933d4916  vmovaps [rsp+0x50], xmm5
00007e2c933d491c  vmovaps [rsp+0x60], xmm6
00007e2c933d4922  vmovaps [rsp+0x70], xmm7
00007e2c933d4928  vmovaps [rsp+0x80], xmm8
00007e2c933d4931  vmovaps [rsp+0x90], xmm9
00007e2c933d493a  vmovaps [rsp+0xA0], xmm10
00007e2c933d4943  vmovaps [rsp+0xB0], xmm11
00007e2c933d494c  vmovaps [rsp+0xC0], xmm12
00007e2c933d4955  vmovaps [rsp+0xD0], xmm13
00007e2c933d495e  vmovaps [rsp+0xE0], xmm14
00007e2c933d4967  sub rsp, 0x30
00007e2c933d496b  movaps [rsp], xmm15
00007e2c933d4970  movaps [rsp+0x10], xmm2
00007e2c933d4975  movaps [rsp+0x20], xmm1
00007e2c933d497a  lea rdi, [rsp]
00007e2c933d497e  mov esi, 0x00
00007e2c933d4983  mov rax, 0x5A263F1C7530
00007e2c933d498d  call rax
00007e2c933d498f  movaps xmm15, [rsp]
00007e2c933d4994  add rsp, 0x30
00007e2c933d4998  vmovaps xmm0, [rsp]
00007e2c933d499d  vmovaps xmm1, [rsp+0x10]
00007e2c933d49a3  vmovaps xmm2, [rsp+0x20]
00007e2c933d49a9  vmovaps xmm3, [rsp+0x30]
00007e2c933d49af  vmovaps xmm4, [rsp+0x40]
00007e2c933d49b5  vmovaps xmm5, [rsp+0x50]
00007e2c933d49bb  vmovaps xmm6, [rsp+0x60]
00007e2c933d49c1  vmovaps xmm7, [rsp+0x70]
00007e2c933d49c7  vmovaps xmm8, [rsp+0x80]
00007e2c933d49d0  vmovaps xmm9, [rsp+0x90]
00007e2c933d49d9  vmovaps xmm10, [rsp+0xA0]
00007e2c933d49e2  vmovaps xmm11, [rsp+0xB0]
00007e2c933d49eb  vmovaps xmm12, [rsp+0xC0]
00007e2c933d49f4  vmovaps xmm13, [rsp+0xD0]
00007e2c933d49fd  vmovaps xmm14, [rsp+0xE0]
00007e2c933d4a06  add rsp, 0xF0
00007e2c933d4a0d  pop r11
00007e2c933d4a0f  pop r10
00007e2c933d4a11  pop r9
00007e2c933d4a13  pop r8
00007e2c933d4a15  pop rsi
00007e2c933d4a16  pop rdi
00007e2c933d4a17  pop rdx
00007e2c933d4a18  pop rcx
00007e2c933d4a19  pop rax
00007e2c933d4a1a  add rsp, 0x08
00007e2c933d4a1e  jmp 0x00007E2C933D2B41
00007e2c933d4a23  call 0x00007E2C931FF430
00007e2c933d4a28  jmp 0x00007E2C933D2B4E
00007e2c933d4a2d  sub rsp, 0x08
00007e2c933d4a31  push rax
00007e2c933d4a32  push rcx
00007e2c933d4a33  push rdx
00007e2c933d4a34  push rdi
00007e2c933d4a35  push rsi
00007e2c933d4a36  push r8
00007e2c933d4a38  push r9
00007e2c933d4a3a  push r10
00007e2c933d4a3c  push r11
00007e2c933d4a3e  sub rsp, 0xF0
00007e2c933d4a45  vmovaps [rsp], xmm0
00007e2c933d4a4a  vmovaps [rsp+0x10], xmm1
00007e2c933d4a50  vmovaps [rsp+0x20], xmm3
00007e2c933d4a56  vmovaps [rsp+0x30], xmm4
00007e2c933d4a5c  vmovaps [rsp+0x40], xmm5
00007e2c933d4a62  vmovaps [rsp+0x50], xmm6
00007e2c933d4a68  vmovaps [rsp+0x60], xmm7
00007e2c933d4a6e  vmovaps [rsp+0x70], xmm8
00007e2c933d4a74  vmovaps [rsp+0x80], xmm9
00007e2c933d4a7d  vmovaps [rsp+0x90], xmm10
00007e2c933d4a86  vmovaps [rsp+0xA0], xmm11
00007e2c933d4a8f  vmovaps [rsp+0xB0], xmm12
00007e2c933d4a98  vmovaps [rsp+0xC0], xmm13
00007e2c933d4aa1  vmovaps [rsp+0xD0], xmm14
00007e2c933d4aaa  vmovaps [rsp+0xE0], xmm15
00007e2c933d4ab3  sub rsp, 0x30
00007e2c933d4ab7  movaps [rsp], xmm2
00007e2c933d4abb  movaps [rsp+0x10], xmm1
00007e2c933d4ac0  movaps [rsp+0x20], xmm14
00007e2c933d4ac6  lea rdi, [rsp]
00007e2c933d4aca  mov esi, 0x00
00007e2c933d4acf  mov rax, 0x5A263F1C7530
00007e2c933d4ad9  call rax
00007e2c933d4adb  movaps xmm2, [rsp]
00007e2c933d4adf  add rsp, 0x30
00007e2c933d4ae3  vmovaps xmm0, [rsp]
00007e2c933d4ae8  vmovaps xmm1, [rsp+0x10]
00007e2c933d4aee  vmovaps xmm3, [rsp+0x20]
00007e2c933d4af4  vmovaps xmm4, [rsp+0x30]
00007e2c933d4afa  vmovaps xmm5, [rsp+0x40]
00007e2c933d4b00  vmovaps xmm6, [rsp+0x50]
00007e2c933d4b06  vmovaps xmm7, [rsp+0x60]
00007e2c933d4b0c  vmovaps xmm8, [rsp+0x70]
00007e2c933d4b12  vmovaps xmm9, [rsp+0x80]
00007e2c933d4b1b  vmovaps xmm10, [rsp+0x90]
00007e2c933d4b24  vmovaps xmm11, [rsp+0xA0]
00007e2c933d4b2d  vmovaps xmm12, [rsp+0xB0]
00007e2c933d4b36  vmovaps xmm13, [rsp+0xC0]
00007e2c933d4b3f  vmovaps xmm14, [rsp+0xD0]
00007e2c933d4b48  vmovaps xmm15, [rsp+0xE0]
00007e2c933d4b51  add rsp, 0xF0
00007e2c933d4b58  pop r11
00007e2c933d4b5a  pop r10
00007e2c933d4b5c  pop r9
00007e2c933d4b5e  pop r8
00007e2c933d4b60  pop rsi
00007e2c933d4b61  pop rdi
00007e2c933d4b62  pop rdx
00007e2c933d4b63  pop rcx
00007e2c933d4b64  pop rax
00007e2c933d4b65  add rsp, 0x08
00007e2c933d4b69  jmp 0x00007E2C933D2B8B
00007e2c933d4b6e  sub rsp, 0x08
00007e2c933d4b72  push rax
00007e2c933d4b73  push rcx
00007e2c933d4b74  push rdx
00007e2c933d4b75  push rdi
00007e2c933d4b76  push rsi
00007e2c933d4b77  push r8
00007e2c933d4b79  push r9
00007e2c933d4b7b  push r10
00007e2c933d4b7d  push r11
00007e2c933d4b7f  sub rsp, 0xF0
00007e2c933d4b86  vmovaps [rsp], xmm0
00007e2c933d4b8b  vmovaps [rsp+0x10], xmm1
00007e2c933d4b91  vmovaps [rsp+0x20], xmm2
00007e2c933d4b97  vmovaps [rsp+0x30], xmm3
00007e2c933d4b9d  vmovaps [rsp+0x40], xmm4
00007e2c933d4ba3  vmovaps [rsp+0x50], xmm5
00007e2c933d4ba9  vmovaps [rsp+0x60], xmm6
00007e2c933d4baf  vmovaps [rsp+0x70], xmm7
00007e2c933d4bb5  vmovaps [rsp+0x80], xmm8
00007e2c933d4bbe  vmovaps [rsp+0x90], xmm9
00007e2c933d4bc7  vmovaps [rsp+0xA0], xmm10
00007e2c933d4bd0  vmovaps [rsp+0xB0], xmm11
00007e2c933d4bd9  vmovaps [rsp+0xC0], xmm12
00007e2c933d4be2  vmovaps [rsp+0xD0], xmm13
00007e2c933d4beb  vmovaps [rsp+0xE0], xmm14
00007e2c933d4bf4  sub rsp, 0x30
00007e2c933d4bf8  movaps [rsp], xmm15
00007e2c933d4bfd  movaps [rsp+0x10], xmm14
00007e2c933d4c03  movaps [rsp+0x20], xmm1
00007e2c933d4c08  lea rdi, [rsp]
00007e2c933d4c0c  mov esi, 0x00
00007e2c933d4c11  mov rax, 0x5A263F1C7530
00007e2c933d4c1b  call rax
00007e2c933d4c1d  movaps xmm15, [rsp]
00007e2c933d4c22  add rsp, 0x30
00007e2c933d4c26  vmovaps xmm0, [rsp]
00007e2c933d4c2b  vmovaps xmm1, [rsp+0x10]
00007e2c933d4c31  vmovaps xmm2, [rsp+0x20]
00007e2c933d4c37  vmovaps xmm3, [rsp+0x30]
00007e2c933d4c3d  vmovaps xmm4, [rsp+0x40]
00007e2c933d4c43  vmovaps xmm5, [rsp+0x50]
00007e2c933d4c49  vmovaps xmm6, [rsp+0x60]
00007e2c933d4c4f  vmovaps xmm7, [rsp+0x70]
00007e2c933d4c55  vmovaps xmm8, [rsp+0x80]
00007e2c933d4c5e  vmovaps xmm9, [rsp+0x90]
00007e2c933d4c67  vmovaps xmm10, [rsp+0xA0]
00007e2c933d4c70  vmovaps xmm11, [rsp+0xB0]
00007e2c933d4c79  vmovaps xmm12, [rsp+0xC0]
00007e2c933d4c82  vmovaps xmm13, [rsp+0xD0]
00007e2c933d4c8b  vmovaps xmm14, [rsp+0xE0]
00007e2c933d4c94  add rsp, 0xF0
00007e2c933d4c9b  pop r11
00007e2c933d4c9d  pop r10
00007e2c933d4c9f  pop r9
00007e2c933d4ca1  pop r8
00007e2c933d4ca3  pop rsi
00007e2c933d4ca4  pop rdi
00007e2c933d4ca5  pop rdx
00007e2c933d4ca6  pop rcx
00007e2c933d4ca7  pop rax
00007e2c933d4ca8  add rsp, 0x08
00007e2c933d4cac  jmp 0x00007E2C933D2C05
00007e2c933d4cb1  call 0x00007E2C931FF430
00007e2c933d4cb6  jmp 0x00007E2C933D2C12
00007e2c933d4cbb  sub rsp, 0x08
00007e2c933d4cbf  push rax
00007e2c933d4cc0  push rcx
00007e2c933d4cc1  push rdx
00007e2c933d4cc2  push rdi
00007e2c933d4cc3  push rsi
00007e2c933d4cc4  push r8
00007e2c933d4cc6  push r9
00007e2c933d4cc8  push r10
00007e2c933d4cca  push r11
00007e2c933d4ccc  sub rsp, 0xF0
00007e2c933d4cd3  vmovaps [rsp], xmm0
00007e2c933d4cd8  vmovaps [rsp+0x10], xmm1
00007e2c933d4cde  vmovaps [rsp+0x20], xmm2
00007e2c933d4ce4  vmovaps [rsp+0x30], xmm3
00007e2c933d4cea  vmovaps [rsp+0x40], xmm4
00007e2c933d4cf0  vmovaps [rsp+0x50], xmm5
00007e2c933d4cf6  vmovaps [rsp+0x60], xmm6
00007e2c933d4cfc  vmovaps [rsp+0x70], xmm7
00007e2c933d4d02  vmovaps [rsp+0x80], xmm8
00007e2c933d4d0b  vmovaps [rsp+0x90], xmm9
00007e2c933d4d14  vmovaps [rsp+0xA0], xmm10
00007e2c933d4d1d  vmovaps [rsp+0xB0], xmm11
00007e2c933d4d26  vmovaps [rsp+0xC0], xmm12
00007e2c933d4d2f  vmovaps [rsp+0xD0], xmm14
00007e2c933d4d38  vmovaps [rsp+0xE0], xmm15
00007e2c933d4d41  sub rsp, 0x30
00007e2c933d4d45  movaps [rsp], xmm13
00007e2c933d4d4a  movaps [rsp+0x10], xmm1
00007e2c933d4d4f  movaps [rsp+0x20], xmm15
00007e2c933d4d55  lea rdi, [rsp]
00007e2c933d4d59  mov esi, 0x00
00007e2c933d4d5e  mov rax, 0x5A263F1C7530
00007e2c933d4d68  call rax
00007e2c933d4d6a  movaps xmm13, [rsp]
00007e2c933d4d6f  add rsp, 0x30
00007e2c933d4d73  vmovaps xmm0, [rsp]
00007e2c933d4d78  vmovaps xmm1, [rsp+0x10]
00007e2c933d4d7e  vmovaps xmm2, [rsp+0x20]
00007e2c933d4d84  vmovaps xmm3, [rsp+0x30]
00007e2c933d4d8a  vmovaps xmm4, [rsp+0x40]
00007e2c933d4d90  vmovaps xmm5, [rsp+0x50]
00007e2c933d4d96  vmovaps xmm6, [rsp+0x60]
00007e2c933d4d9c  vmovaps xmm7, [rsp+0x70]
00007e2c933d4da2  vmovaps xmm8, [rsp+0x80]
00007e2c933d4dab  vmovaps xmm9, [rsp+0x90]
00007e2c933d4db4  vmovaps xmm10, [rsp+0xA0]
00007e2c933d4dbd  vmovaps xmm11, [rsp+0xB0]
00007e2c933d4dc6  vmovaps xmm12, [rsp+0xC0]
00007e2c933d4dcf  vmovaps xmm14, [rsp+0xD0]
00007e2c933d4dd8  vmovaps xmm15, [rsp+0xE0]
00007e2c933d4de1  add rsp, 0xF0
00007e2c933d4de8  pop r11
00007e2c933d4dea  pop r10
00007e2c933d4dec  pop r9
00007e2c933d4dee  pop r8
00007e2c933d4df0  pop rsi
00007e2c933d4df1  pop rdi
00007e2c933d4df2  pop rdx
00007e2c933d4df3  pop rcx
00007e2c933d4df4  pop rax
00007e2c933d4df5  add rsp, 0x08
00007e2c933d4df9  jmp 0x00007E2C933D2CD6
00007e2c933d4dfe  sub rsp, 0x08
00007e2c933d4e02  push rax
00007e2c933d4e03  push rcx
00007e2c933d4e04  push rdx
00007e2c933d4e05  push rdi
00007e2c933d4e06  push rsi
00007e2c933d4e07  push r8
00007e2c933d4e09  push r9
00007e2c933d4e0b  push r10
00007e2c933d4e0d  push r11
00007e2c933d4e0f  sub rsp, 0xF0
00007e2c933d4e16  vmovaps [rsp], xmm0
00007e2c933d4e1b  vmovaps [rsp+0x10], xmm1
00007e2c933d4e21  vmovaps [rsp+0x20], xmm2
00007e2c933d4e27  vmovaps [rsp+0x30], xmm3
00007e2c933d4e2d  vmovaps [rsp+0x40], xmm4
00007e2c933d4e33  vmovaps [rsp+0x50], xmm5
00007e2c933d4e39  vmovaps [rsp+0x60], xmm6
00007e2c933d4e3f  vmovaps [rsp+0x70], xmm7
00007e2c933d4e45  vmovaps [rsp+0x80], xmm8
00007e2c933d4e4e  vmovaps [rsp+0x90], xmm9
00007e2c933d4e57  vmovaps [rsp+0xA0], xmm10
00007e2c933d4e60  vmovaps [rsp+0xB0], xmm11
00007e2c933d4e69  vmovaps [rsp+0xC0], xmm12
00007e2c933d4e72  vmovaps [rsp+0xD0], xmm13
00007e2c933d4e7b  vmovaps [rsp+0xE0], xmm14
00007e2c933d4e84  sub rsp, 0x30
00007e2c933d4e88  movaps [rsp], xmm15
00007e2c933d4e8d  movaps [rsp+0x10], xmm14
00007e2c933d4e93  movaps [rsp+0x20], xmm1
00007e2c933d4e98  lea rdi, [rsp]
00007e2c933d4e9c  mov esi, 0x00
00007e2c933d4ea1  mov rax, 0x5A263F1C7530
00007e2c933d4eab  call rax
00007e2c933d4ead  movaps xmm15, [rsp]
00007e2c933d4eb2  add rsp, 0x30
00007e2c933d4eb6  vmovaps xmm0, [rsp]
00007e2c933d4ebb  vmovaps xmm1, [rsp+0x10]
00007e2c933d4ec1  vmovaps xmm2, [rsp+0x20]
00007e2c933d4ec7  vmovaps xmm3, [rsp+0x30]
00007e2c933d4ecd  vmovaps xmm4, [rsp+0x40]
00007e2c933d4ed3  vmovaps xmm5, [rsp+0x50]
00007e2c933d4ed9  vmovaps xmm6, [rsp+0x60]
00007e2c933d4edf  vmovaps xmm7, [rsp+0x70]
00007e2c933d4ee5  vmovaps xmm8, [rsp+0x80]
00007e2c933d4eee  vmovaps xmm9, [rsp+0x90]
00007e2c933d4ef7  vmovaps xmm10, [rsp+0xA0]
00007e2c933d4f00  vmovaps xmm11, [rsp+0xB0]
00007e2c933d4f09  vmovaps xmm12, [rsp+0xC0]
00007e2c933d4f12  vmovaps xmm13, [rsp+0xD0]
00007e2c933d4f1b  vmovaps xmm14, [rsp+0xE0]
00007e2c933d4f24  add rsp, 0xF0
00007e2c933d4f2b  pop r11
00007e2c933d4f2d  pop r10
00007e2c933d4f2f  pop r9
00007e2c933d4f31  pop r8
00007e2c933d4f33  pop rsi
00007e2c933d4f34  pop rdi
00007e2c933d4f35  pop rdx
00007e2c933d4f36  pop rcx
00007e2c933d4f37  pop rax
00007e2c933d4f38  add rsp, 0x08
00007e2c933d4f3c  jmp 0x00007E2C933D2D12
00007e2c933d4f41  call 0x00007E2C931FF430
00007e2c933d4f46  jmp 0x00007E2C933D2D1F
00007e2c933d4f4b  sub rsp, 0x08
00007e2c933d4f4f  push rax
00007e2c933d4f50  push rcx
00007e2c933d4f51  push rdx
00007e2c933d4f52  push rdi
00007e2c933d4f53  push rsi
00007e2c933d4f54  push r8
00007e2c933d4f56  push r9
00007e2c933d4f58  push r10
00007e2c933d4f5a  push r11
00007e2c933d4f5c  sub rsp, 0xF0
00007e2c933d4f63  vmovaps [rsp], xmm0
00007e2c933d4f68  vmovaps [rsp+0x10], xmm1
00007e2c933d4f6e  vmovaps [rsp+0x20], xmm2
00007e2c933d4f74  vmovaps [rsp+0x30], xmm3
00007e2c933d4f7a  vmovaps [rsp+0x40], xmm4
00007e2c933d4f80  vmovaps [rsp+0x50], xmm5
00007e2c933d4f86  vmovaps [rsp+0x60], xmm6
00007e2c933d4f8c  vmovaps [rsp+0x70], xmm7
00007e2c933d4f92  vmovaps [rsp+0x80], xmm8
00007e2c933d4f9b  vmovaps [rsp+0x90], xmm9
00007e2c933d4fa4  vmovaps [rsp+0xA0], xmm10
00007e2c933d4fad  vmovaps [rsp+0xB0], xmm11
00007e2c933d4fb6  vmovaps [rsp+0xC0], xmm12
00007e2c933d4fbf  vmovaps [rsp+0xD0], xmm13
00007e2c933d4fc8  vmovaps [rsp+0xE0], xmm15
00007e2c933d4fd1  sub rsp, 0x30
00007e2c933d4fd5  movaps [rsp], xmm14
00007e2c933d4fda  movaps [rsp+0x10], xmm13
00007e2c933d4fe0  movaps [rsp+0x20], xmm2
00007e2c933d4fe5  lea rdi, [rsp]
00007e2c933d4fe9  mov esi, 0x00
00007e2c933d4fee  mov rax, 0x5A263F1C7530
00007e2c933d4ff8  call rax
00007e2c933d4ffa  movaps xmm14, [rsp]
00007e2c933d4fff  add rsp, 0x30
00007e2c933d5003  vmovaps xmm0, [rsp]
00007e2c933d5008  vmovaps xmm1, [rsp+0x10]
00007e2c933d500e  vmovaps xmm2, [rsp+0x20]
00007e2c933d5014  vmovaps xmm3, [rsp+0x30]
00007e2c933d501a  vmovaps xmm4, [rsp+0x40]
00007e2c933d5020  vmovaps xmm5, [rsp+0x50]
00007e2c933d5026  vmovaps xmm6, [rsp+0x60]
00007e2c933d502c  vmovaps xmm7, [rsp+0x70]
00007e2c933d5032  vmovaps xmm8, [rsp+0x80]
00007e2c933d503b  vmovaps xmm9, [rsp+0x90]
00007e2c933d5044  vmovaps xmm10, [rsp+0xA0]
00007e2c933d504d  vmovaps xmm11, [rsp+0xB0]
00007e2c933d5056  vmovaps xmm12, [rsp+0xC0]
00007e2c933d505f  vmovaps xmm13, [rsp+0xD0]
00007e2c933d5068  vmovaps xmm15, [rsp+0xE0]
00007e2c933d5071  add rsp, 0xF0
00007e2c933d5078  pop r11
00007e2c933d507a  pop r10
00007e2c933d507c  pop r9
00007e2c933d507e  pop r8
00007e2c933d5080  pop rsi
00007e2c933d5081  pop rdi
00007e2c933d5082  pop rdx
00007e2c933d5083  pop rcx
00007e2c933d5084  pop rax
00007e2c933d5085  add rsp, 0x08
00007e2c933d5089  jmp 0x00007E2C933D2D4B
00007e2c933d508e  sub rsp, 0x08
00007e2c933d5092  push rax
00007e2c933d5093  push rcx
00007e2c933d5094  push rdx
00007e2c933d5095  push rdi
00007e2c933d5096  push rsi
00007e2c933d5097  push r8
00007e2c933d5099  push r9
00007e2c933d509b  push r10
00007e2c933d509d  push r11
00007e2c933d509f  sub rsp, 0xF0
00007e2c933d50a6  vmovaps [rsp], xmm0
00007e2c933d50ab  vmovaps [rsp+0x10], xmm2
00007e2c933d50b1  vmovaps [rsp+0x20], xmm3
00007e2c933d50b7  vmovaps [rsp+0x30], xmm4
00007e2c933d50bd  vmovaps [rsp+0x40], xmm5
00007e2c933d50c3  vmovaps [rsp+0x50], xmm6
00007e2c933d50c9  vmovaps [rsp+0x60], xmm7
00007e2c933d50cf  vmovaps [rsp+0x70], xmm8
00007e2c933d50d5  vmovaps [rsp+0x80], xmm9
00007e2c933d50de  vmovaps [rsp+0x90], xmm10
00007e2c933d50e7  vmovaps [rsp+0xA0], xmm11
00007e2c933d50f0  vmovaps [rsp+0xB0], xmm12
00007e2c933d50f9  vmovaps [rsp+0xC0], xmm13
00007e2c933d5102  vmovaps [rsp+0xD0], xmm14
00007e2c933d510b  vmovaps [rsp+0xE0], xmm15
00007e2c933d5114  sub rsp, 0x30
00007e2c933d5118  movaps [rsp], xmm1
00007e2c933d511c  movaps [rsp+0x10], xmm13
00007e2c933d5122  movaps [rsp+0x20], xmm2
00007e2c933d5127  lea rdi, [rsp]
00007e2c933d512b  mov esi, 0x00
00007e2c933d5130  mov rax, 0x5A263F1C7530
00007e2c933d513a  call rax
00007e2c933d513c  movaps xmm1, [rsp]
00007e2c933d5140  add rsp, 0x30
00007e2c933d5144  vmovaps xmm0, [rsp]
00007e2c933d5149  vmovaps xmm2, [rsp+0x10]
00007e2c933d514f  vmovaps xmm3, [rsp+0x20]
00007e2c933d5155  vmovaps xmm4, [rsp+0x30]
00007e2c933d515b  vmovaps xmm5, [rsp+0x40]
00007e2c933d5161  vmovaps xmm6, [rsp+0x50]
00007e2c933d5167  vmovaps xmm7, [rsp+0x60]
00007e2c933d516d  vmovaps xmm8, [rsp+0x70]
00007e2c933d5173  vmovaps xmm9, [rsp+0x80]
00007e2c933d517c  vmovaps xmm10, [rsp+0x90]
00007e2c933d5185  vmovaps xmm11, [rsp+0xA0]
00007e2c933d518e  vmovaps xmm12, [rsp+0xB0]
00007e2c933d5197  vmovaps xmm13, [rsp+0xC0]
00007e2c933d51a0  vmovaps xmm14, [rsp+0xD0]
00007e2c933d51a9  vmovaps xmm15, [rsp+0xE0]
00007e2c933d51b2  add rsp, 0xF0
00007e2c933d51b9  pop r11
00007e2c933d51bb  pop r10
00007e2c933d51bd  pop r9
00007e2c933d51bf  pop r8
00007e2c933d51c1  pop rsi
00007e2c933d51c2  pop rdi
00007e2c933d51c3  pop rdx
00007e2c933d51c4  pop rcx
00007e2c933d51c5  pop rax
00007e2c933d51c6  add rsp, 0x08
00007e2c933d51ca  jmp 0x00007E2C933D2D79
00007e2c933d51cf  sub rsp, 0x08
00007e2c933d51d3  push rax
00007e2c933d51d4  push rcx
00007e2c933d51d5  push rdx
00007e2c933d51d6  push rdi
00007e2c933d51d7  push rsi
00007e2c933d51d8  push r8
00007e2c933d51da  push r9
00007e2c933d51dc  push r10
00007e2c933d51de  push r11
00007e2c933d51e0  sub rsp, 0xF0
00007e2c933d51e7  vmovaps [rsp], xmm0
00007e2c933d51ec  vmovaps [rsp+0x10], xmm1
00007e2c933d51f2  vmovaps [rsp+0x20], xmm3
00007e2c933d51f8  vmovaps [rsp+0x30], xmm4
00007e2c933d51fe  vmovaps [rsp+0x40], xmm5
00007e2c933d5204  vmovaps [rsp+0x50], xmm6
00007e2c933d520a  vmovaps [rsp+0x60], xmm7
00007e2c933d5210  vmovaps [rsp+0x70], xmm8
00007e2c933d5216  vmovaps [rsp+0x80], xmm9
00007e2c933d521f  vmovaps [rsp+0x90], xmm10
00007e2c933d5228  vmovaps [rsp+0xA0], xmm11
00007e2c933d5231  vmovaps [rsp+0xB0], xmm12
00007e2c933d523a  vmovaps [rsp+0xC0], xmm13
00007e2c933d5243  vmovaps [rsp+0xD0], xmm14
00007e2c933d524c  vmovaps [rsp+0xE0], xmm15
00007e2c933d5255  sub rsp, 0x30
00007e2c933d5259  movaps [rsp], xmm2
00007e2c933d525d  movaps [rsp+0x10], xmm1
00007e2c933d5262  movaps [rsp+0x20], xmm13
00007e2c933d5268  lea rdi, [rsp]
00007e2c933d526c  mov esi, 0x00
00007e2c933d5271  mov rax, 0x5A263F1C7530
00007e2c933d527b  call rax
00007e2c933d527d  movaps xmm2, [rsp]
00007e2c933d5281  add rsp, 0x30
00007e2c933d5285  vmovaps xmm0, [rsp]
00007e2c933d528a  vmovaps xmm1, [rsp+0x10]
00007e2c933d5290  vmovaps xmm3, [rsp+0x20]
00007e2c933d5296  vmovaps xmm4, [rsp+0x30]
00007e2c933d529c  vmovaps xmm5, [rsp+0x40]
00007e2c933d52a2  vmovaps xmm6, [rsp+0x50]
00007e2c933d52a8  vmovaps xmm7, [rsp+0x60]
00007e2c933d52ae  vmovaps xmm8, [rsp+0x70]
00007e2c933d52b4  vmovaps xmm9, [rsp+0x80]
00007e2c933d52bd  vmovaps xmm10, [rsp+0x90]
00007e2c933d52c6  vmovaps xmm11, [rsp+0xA0]
00007e2c933d52cf  vmovaps xmm12, [rsp+0xB0]
00007e2c933d52d8  vmovaps xmm13, [rsp+0xC0]
00007e2c933d52e1  vmovaps xmm14, [rsp+0xD0]
00007e2c933d52ea  vmovaps xmm15, [rsp+0xE0]
00007e2c933d52f3  add rsp, 0xF0
00007e2c933d52fa  pop r11
00007e2c933d52fc  pop r10
00007e2c933d52fe  pop r9
00007e2c933d5300  pop r8
00007e2c933d5302  pop rsi
00007e2c933d5303  pop rdi
00007e2c933d5304  pop rdx
00007e2c933d5305  pop rcx
00007e2c933d5306  pop rax
00007e2c933d5307  add rsp, 0x08
00007e2c933d530b  jmp 0x00007E2C933D2DD2
00007e2c933d5310  call 0x00007E2C931FF430
00007e2c933d5315  jmp 0x00007E2C933D2DDF
00007e2c933d531a  sub rsp, 0x08
00007e2c933d531e  push rax
00007e2c933d531f  push rcx
00007e2c933d5320  push rdx
00007e2c933d5321  push rdi
00007e2c933d5322  push rsi
00007e2c933d5323  push r8
00007e2c933d5325  push r9
00007e2c933d5327  push r10
00007e2c933d5329  push r11
00007e2c933d532b  sub rsp, 0xF0
00007e2c933d5332  vmovaps [rsp], xmm0
00007e2c933d5337  vmovaps [rsp+0x10], xmm1
00007e2c933d533d  vmovaps [rsp+0x20], xmm2
00007e2c933d5343  vmovaps [rsp+0x30], xmm3
00007e2c933d5349  vmovaps [rsp+0x40], xmm4
00007e2c933d534f  vmovaps [rsp+0x50], xmm5
00007e2c933d5355  vmovaps [rsp+0x60], xmm6
00007e2c933d535b  vmovaps [rsp+0x70], xmm7
00007e2c933d5361  vmovaps [rsp+0x80], xmm8
00007e2c933d536a  vmovaps [rsp+0x90], xmm9
00007e2c933d5373  vmovaps [rsp+0xA0], xmm10
00007e2c933d537c  vmovaps [rsp+0xB0], xmm11
00007e2c933d5385  vmovaps [rsp+0xC0], xmm12
00007e2c933d538e  vmovaps [rsp+0xD0], xmm13
00007e2c933d5397  vmovaps [rsp+0xE0], xmm14
00007e2c933d53a0  sub rsp, 0x30
00007e2c933d53a4  movaps [rsp], xmm15
00007e2c933d53a9  movaps [rsp+0x10], xmm13
00007e2c933d53af  movaps [rsp+0x20], xmm1
00007e2c933d53b4  lea rdi, [rsp]
00007e2c933d53b8  mov esi, 0x00
00007e2c933d53bd  mov rax, 0x5A263F1C7530
00007e2c933d53c7  call rax
00007e2c933d53c9  movaps xmm15, [rsp]
00007e2c933d53ce  add rsp, 0x30
00007e2c933d53d2  vmovaps xmm0, [rsp]
00007e2c933d53d7  vmovaps xmm1, [rsp+0x10]
00007e2c933d53dd  vmovaps xmm2, [rsp+0x20]
00007e2c933d53e3  vmovaps xmm3, [rsp+0x30]
00007e2c933d53e9  vmovaps xmm4, [rsp+0x40]
00007e2c933d53ef  vmovaps xmm5, [rsp+0x50]
00007e2c933d53f5  vmovaps xmm6, [rsp+0x60]
00007e2c933d53fb  vmovaps xmm7, [rsp+0x70]
00007e2c933d5401  vmovaps xmm8, [rsp+0x80]
00007e2c933d540a  vmovaps xmm9, [rsp+0x90]
00007e2c933d5413  vmovaps xmm10, [rsp+0xA0]
00007e2c933d541c  vmovaps xmm11, [rsp+0xB0]
00007e2c933d5425  vmovaps xmm12, [rsp+0xC0]
00007e2c933d542e  vmovaps xmm13, [rsp+0xD0]
00007e2c933d5437  vmovaps xmm14, [rsp+0xE0]
00007e2c933d5440  add rsp, 0xF0
00007e2c933d5447  pop r11
00007e2c933d5449  pop r10
00007e2c933d544b  pop r9
00007e2c933d544d  pop r8
00007e2c933d544f  pop rsi
00007e2c933d5450  pop rdi
00007e2c933d5451  pop rdx
00007e2c933d5452  pop rcx
00007e2c933d5453  pop rax
00007e2c933d5454  add rsp, 0x08
00007e2c933d5458  jmp 0x00007E2C933D2E1E
00007e2c933d545d  sub rsp, 0x08
00007e2c933d5461  push rax
00007e2c933d5462  push rcx
00007e2c933d5463  push rdx
00007e2c933d5464  push rdi
00007e2c933d5465  push rsi
00007e2c933d5466  push r8
00007e2c933d5468  push r9
00007e2c933d546a  push r10
00007e2c933d546c  push r11
00007e2c933d546e  sub rsp, 0xF0
00007e2c933d5475  vmovaps [rsp], xmm0
00007e2c933d547a  vmovaps [rsp+0x10], xmm1
00007e2c933d5480  vmovaps [rsp+0x20], xmm2
00007e2c933d5486  vmovaps [rsp+0x30], xmm3
00007e2c933d548c  vmovaps [rsp+0x40], xmm4
00007e2c933d5492  vmovaps [rsp+0x50], xmm5
00007e2c933d5498  vmovaps [rsp+0x60], xmm6
00007e2c933d549e  vmovaps [rsp+0x70], xmm7
00007e2c933d54a4  vmovaps [rsp+0x80], xmm8
00007e2c933d54ad  vmovaps [rsp+0x90], xmm9
00007e2c933d54b6  vmovaps [rsp+0xA0], xmm10
00007e2c933d54bf  vmovaps [rsp+0xB0], xmm11
00007e2c933d54c8  vmovaps [rsp+0xC0], xmm12
00007e2c933d54d1  vmovaps [rsp+0xD0], xmm13
00007e2c933d54da  vmovaps [rsp+0xE0], xmm15
00007e2c933d54e3  sub rsp, 0x30
00007e2c933d54e7  movaps [rsp], xmm14
00007e2c933d54ec  movaps [rsp+0x10], xmm11
00007e2c933d54f2  movaps [rsp+0x20], xmm1
00007e2c933d54f7  lea rdi, [rsp]
00007e2c933d54fb  mov esi, 0x00
00007e2c933d5500  mov rax, 0x5A263F1C7530
00007e2c933d550a  call rax
00007e2c933d550c  movaps xmm14, [rsp]
00007e2c933d5511  add rsp, 0x30
00007e2c933d5515  vmovaps xmm0, [rsp]
00007e2c933d551a  vmovaps xmm1, [rsp+0x10]
00007e2c933d5520  vmovaps xmm2, [rsp+0x20]
00007e2c933d5526  vmovaps xmm3, [rsp+0x30]
00007e2c933d552c  vmovaps xmm4, [rsp+0x40]
00007e2c933d5532  vmovaps xmm5, [rsp+0x50]
00007e2c933d5538  vmovaps xmm6, [rsp+0x60]
00007e2c933d553e  vmovaps xmm7, [rsp+0x70]
00007e2c933d5544  vmovaps xmm8, [rsp+0x80]
00007e2c933d554d  vmovaps xmm9, [rsp+0x90]
00007e2c933d5556  vmovaps xmm10, [rsp+0xA0]
00007e2c933d555f  vmovaps xmm11, [rsp+0xB0]
00007e2c933d5568  vmovaps xmm12, [rsp+0xC0]
00007e2c933d5571  vmovaps xmm13, [rsp+0xD0]
00007e2c933d557a  vmovaps xmm15, [rsp+0xE0]
00007e2c933d5583  add rsp, 0xF0
00007e2c933d558a  pop r11
00007e2c933d558c  pop r10
00007e2c933d558e  pop r9
00007e2c933d5590  pop r8
00007e2c933d5592  pop rsi
00007e2c933d5593  pop rdi
00007e2c933d5594  pop rdx
00007e2c933d5595  pop rcx
00007e2c933d5596  pop rax
00007e2c933d5597  add rsp, 0x08
00007e2c933d559b  jmp 0x00007E2C933D2E48
00007e2c933d55a0  sub rsp, 0x08
00007e2c933d55a4  push rax
00007e2c933d55a5  push rcx
00007e2c933d55a6  push rdx
00007e2c933d55a7  push rdi
00007e2c933d55a8  push rsi
00007e2c933d55a9  push r8
00007e2c933d55ab  push r9
00007e2c933d55ad  push r10
00007e2c933d55af  push r11
00007e2c933d55b1  sub rsp, 0xF0
00007e2c933d55b8  vmovaps [rsp], xmm0
00007e2c933d55bd  vmovaps [rsp+0x10], xmm1
00007e2c933d55c3  vmovaps [rsp+0x20], xmm2
00007e2c933d55c9  vmovaps [rsp+0x30], xmm3
00007e2c933d55cf  vmovaps [rsp+0x40], xmm4
00007e2c933d55d5  vmovaps [rsp+0x50], xmm5
00007e2c933d55db  vmovaps [rsp+0x60], xmm6
00007e2c933d55e1  vmovaps [rsp+0x70], xmm7
00007e2c933d55e7  vmovaps [rsp+0x80], xmm8
00007e2c933d55f0  vmovaps [rsp+0x90], xmm9
00007e2c933d55f9  vmovaps [rsp+0xA0], xmm10
00007e2c933d5602  vmovaps [rsp+0xB0], xmm11
00007e2c933d560b  vmovaps [rsp+0xC0], xmm12
00007e2c933d5614  vmovaps [rsp+0xD0], xmm14
00007e2c933d561d  vmovaps [rsp+0xE0], xmm15
00007e2c933d5626  sub rsp, 0x30
00007e2c933d562a  movaps [rsp], xmm13
00007e2c933d562f  movaps [rsp+0x10], xmm11
00007e2c933d5635  movaps [rsp+0x20], xmm1
00007e2c933d563a  lea rdi, [rsp]
00007e2c933d563e  mov esi, 0x00
00007e2c933d5643  mov rax, 0x5A263F1C7530
00007e2c933d564d  call rax
00007e2c933d564f  movaps xmm13, [rsp]
00007e2c933d5654  add rsp, 0x30
00007e2c933d5658  vmovaps xmm0, [rsp]
00007e2c933d565d  vmovaps xmm1, [rsp+0x10]
00007e2c933d5663  vmovaps xmm2, [rsp+0x20]
00007e2c933d5669  vmovaps xmm3, [rsp+0x30]
00007e2c933d566f  vmovaps xmm4, [rsp+0x40]
00007e2c933d5675  vmovaps xmm5, [rsp+0x50]
00007e2c933d567b  vmovaps xmm6, [rsp+0x60]
00007e2c933d5681  vmovaps xmm7, [rsp+0x70]
00007e2c933d5687  vmovaps xmm8, [rsp+0x80]
00007e2c933d5690  vmovaps xmm9, [rsp+0x90]
00007e2c933d5699  vmovaps xmm10, [rsp+0xA0]
00007e2c933d56a2  vmovaps xmm11, [rsp+0xB0]
00007e2c933d56ab  vmovaps xmm12, [rsp+0xC0]
00007e2c933d56b4  vmovaps xmm14, [rsp+0xD0]
00007e2c933d56bd  vmovaps xmm15, [rsp+0xE0]
00007e2c933d56c6  add rsp, 0xF0
00007e2c933d56cd  pop r11
00007e2c933d56cf  pop r10
00007e2c933d56d1  pop r9
00007e2c933d56d3  pop r8
00007e2c933d56d5  pop rsi
00007e2c933d56d6  pop rdi
00007e2c933d56d7  pop rdx
00007e2c933d56d8  pop rcx
00007e2c933d56d9  pop rax
00007e2c933d56da  add rsp, 0x08
00007e2c933d56de  jmp 0x00007E2C933D2E9D
00007e2c933d56e3  call 0x00007E2C931FF430
00007e2c933d56e8  jmp 0x00007E2C933D2EAA
00007e2c933d56ed  sub rsp, 0x08
00007e2c933d56f1  push rax
00007e2c933d56f2  push rcx
00007e2c933d56f3  push rdx
00007e2c933d56f4  push rdi
00007e2c933d56f5  push rsi
00007e2c933d56f6  push r8
00007e2c933d56f8  push r9
00007e2c933d56fa  push r10
00007e2c933d56fc  push r11
00007e2c933d56fe  sub rsp, 0xF0
00007e2c933d5705  vmovaps [rsp], xmm0
00007e2c933d570a  vmovaps [rsp+0x10], xmm1
00007e2c933d5710  vmovaps [rsp+0x20], xmm2
00007e2c933d5716  vmovaps [rsp+0x30], xmm3
00007e2c933d571c  vmovaps [rsp+0x40], xmm4
00007e2c933d5722  vmovaps [rsp+0x50], xmm5
00007e2c933d5728  vmovaps [rsp+0x60], xmm6
00007e2c933d572e  vmovaps [rsp+0x70], xmm7
00007e2c933d5734  vmovaps [rsp+0x80], xmm8
00007e2c933d573d  vmovaps [rsp+0x90], xmm9
00007e2c933d5746  vmovaps [rsp+0xA0], xmm10
00007e2c933d574f  vmovaps [rsp+0xB0], xmm11
00007e2c933d5758  vmovaps [rsp+0xC0], xmm12
00007e2c933d5761  vmovaps [rsp+0xD0], xmm13
00007e2c933d576a  vmovaps [rsp+0xE0], xmm14
00007e2c933d5773  sub rsp, 0x30
00007e2c933d5777  movaps [rsp], xmm15
00007e2c933d577c  movaps [rsp+0x10], xmm11
00007e2c933d5782  movaps [rsp+0x20], xmm1
00007e2c933d5787  lea rdi, [rsp]
00007e2c933d578b  mov esi, 0x00
00007e2c933d5790  mov rax, 0x5A263F1C7530
00007e2c933d579a  call rax
00007e2c933d579c  movaps xmm15, [rsp]
00007e2c933d57a1  add rsp, 0x30
00007e2c933d57a5  vmovaps xmm0, [rsp]
00007e2c933d57aa  vmovaps xmm1, [rsp+0x10]
00007e2c933d57b0  vmovaps xmm2, [rsp+0x20]
00007e2c933d57b6  vmovaps xmm3, [rsp+0x30]
00007e2c933d57bc  vmovaps xmm4, [rsp+0x40]
00007e2c933d57c2  vmovaps xmm5, [rsp+0x50]
00007e2c933d57c8  vmovaps xmm6, [rsp+0x60]
00007e2c933d57ce  vmovaps xmm7, [rsp+0x70]
00007e2c933d57d4  vmovaps xmm8, [rsp+0x80]
00007e2c933d57dd  vmovaps xmm9, [rsp+0x90]
00007e2c933d57e6  vmovaps xmm10, [rsp+0xA0]
00007e2c933d57ef  vmovaps xmm11, [rsp+0xB0]
00007e2c933d57f8  vmovaps xmm12, [rsp+0xC0]
00007e2c933d5801  vmovaps xmm13, [rsp+0xD0]
00007e2c933d580a  vmovaps xmm14, [rsp+0xE0]
00007e2c933d5813  add rsp, 0xF0
00007e2c933d581a  pop r11
00007e2c933d581c  pop r10
00007e2c933d581e  pop r9
00007e2c933d5820  pop r8
00007e2c933d5822  pop rsi
00007e2c933d5823  pop rdi
00007e2c933d5824  pop rdx
00007e2c933d5825  pop rcx
00007e2c933d5826  pop rax
00007e2c933d5827  add rsp, 0x08
00007e2c933d582b  jmp 0x00007E2C933D2EE3
00007e2c933d5830  sub rsp, 0x08
00007e2c933d5834  push rax
00007e2c933d5835  push rcx
00007e2c933d5836  push rdx
00007e2c933d5837  push rdi
00007e2c933d5838  push rsi
00007e2c933d5839  push r8
00007e2c933d583b  push r9
00007e2c933d583d  push r10
00007e2c933d583f  push r11
00007e2c933d5841  sub rsp, 0xF0
00007e2c933d5848  vmovaps [rsp], xmm0
00007e2c933d584d  vmovaps [rsp+0x10], xmm1
00007e2c933d5853  vmovaps [rsp+0x20], xmm2
00007e2c933d5859  vmovaps [rsp+0x30], xmm3
00007e2c933d585f  vmovaps [rsp+0x40], xmm4
00007e2c933d5865  vmovaps [rsp+0x50], xmm5
00007e2c933d586b  vmovaps [rsp+0x60], xmm6
00007e2c933d5871  vmovaps [rsp+0x70], xmm7
00007e2c933d5877  vmovaps [rsp+0x80], xmm8
00007e2c933d5880  vmovaps [rsp+0x90], xmm9
00007e2c933d5889  vmovaps [rsp+0xA0], xmm10
00007e2c933d5892  vmovaps [rsp+0xB0], xmm12
00007e2c933d589b  vmovaps [rsp+0xC0], xmm13
00007e2c933d58a4  vmovaps [rsp+0xD0], xmm14
00007e2c933d58ad  vmovaps [rsp+0xE0], xmm15
00007e2c933d58b6  sub rsp, 0x30
00007e2c933d58ba  movaps [rsp], xmm11
00007e2c933d58bf  movaps [rsp+0x10], xmm6
00007e2c933d58c4  movaps [rsp+0x20], xmm14
00007e2c933d58ca  lea rdi, [rsp]
00007e2c933d58ce  mov esi, 0x00
00007e2c933d58d3  mov rax, 0x5A263F1C7530
00007e2c933d58dd  call rax
00007e2c933d58df  movaps xmm11, [rsp]
00007e2c933d58e4  add rsp, 0x30
00007e2c933d58e8  vmovaps xmm0, [rsp]
00007e2c933d58ed  vmovaps xmm1, [rsp+0x10]
00007e2c933d58f3  vmovaps xmm2, [rsp+0x20]
00007e2c933d58f9  vmovaps xmm3, [rsp+0x30]
00007e2c933d58ff  vmovaps xmm4, [rsp+0x40]
00007e2c933d5905  vmovaps xmm5, [rsp+0x50]
00007e2c933d590b  vmovaps xmm6, [rsp+0x60]
00007e2c933d5911  vmovaps xmm7, [rsp+0x70]
00007e2c933d5917  vmovaps xmm8, [rsp+0x80]
00007e2c933d5920  vmovaps xmm9, [rsp+0x90]
00007e2c933d5929  vmovaps xmm10, [rsp+0xA0]
00007e2c933d5932  vmovaps xmm12, [rsp+0xB0]
00007e2c933d593b  vmovaps xmm13, [rsp+0xC0]
00007e2c933d5944  vmovaps xmm14, [rsp+0xD0]
00007e2c933d594d  vmovaps xmm15, [rsp+0xE0]
00007e2c933d5956  add rsp, 0xF0
00007e2c933d595d  pop r11
00007e2c933d595f  pop r10
00007e2c933d5961  pop r9
00007e2c933d5963  pop r8
00007e2c933d5965  pop rsi
00007e2c933d5966  pop rdi
00007e2c933d5967  pop rdx
00007e2c933d5968  pop rcx
00007e2c933d5969  pop rax
00007e2c933d596a  add rsp, 0x08
00007e2c933d596e  jmp 0x00007E2C933D2F5B
00007e2c933d5973  call 0x00007E2C931FF430
00007e2c933d5978  jmp 0x00007E2C933D2F65
00007e2c933d597d  sub rsp, 0x08
00007e2c933d5981  push rax
00007e2c933d5982  push rcx
00007e2c933d5983  push rdx
00007e2c933d5984  push rdi
00007e2c933d5985  push rsi
00007e2c933d5986  push r8
00007e2c933d5988  push r9
00007e2c933d598a  push r10
00007e2c933d598c  push r11
00007e2c933d598e  sub rsp, 0xF0
00007e2c933d5995  vmovaps [rsp], xmm0
00007e2c933d599a  vmovaps [rsp+0x10], xmm1
00007e2c933d59a0  vmovaps [rsp+0x20], xmm2
00007e2c933d59a6  vmovaps [rsp+0x30], xmm3
00007e2c933d59ac  vmovaps [rsp+0x40], xmm4
00007e2c933d59b2  vmovaps [rsp+0x50], xmm5
00007e2c933d59b8  vmovaps [rsp+0x60], xmm6
00007e2c933d59be  vmovaps [rsp+0x70], xmm7
00007e2c933d59c4  vmovaps [rsp+0x80], xmm8
00007e2c933d59cd  vmovaps [rsp+0x90], xmm9
00007e2c933d59d6  vmovaps [rsp+0xA0], xmm10
00007e2c933d59df  vmovaps [rsp+0xB0], xmm11
00007e2c933d59e8  vmovaps [rsp+0xC0], xmm12
00007e2c933d59f1  vmovaps [rsp+0xD0], xmm13
00007e2c933d59fa  vmovaps [rsp+0xE0], xmm15
00007e2c933d5a03  sub rsp, 0x30
00007e2c933d5a07  movaps [rsp], xmm14
00007e2c933d5a0c  movaps [rsp+0x10], xmm6
00007e2c933d5a11  movaps [rsp+0x20], xmm2
00007e2c933d5a16  lea rdi, [rsp]
00007e2c933d5a1a  mov esi, 0x00
00007e2c933d5a1f  mov rax, 0x5A263F1C7530
00007e2c933d5a29  call rax
00007e2c933d5a2b  movaps xmm14, [rsp]
00007e2c933d5a30  add rsp, 0x30
00007e2c933d5a34  vmovaps xmm0, [rsp]
00007e2c933d5a39  vmovaps xmm1, [rsp+0x10]
00007e2c933d5a3f  vmovaps xmm2, [rsp+0x20]
00007e2c933d5a45  vmovaps xmm3, [rsp+0x30]
00007e2c933d5a4b  vmovaps xmm4, [rsp+0x40]
00007e2c933d5a51  vmovaps xmm5, [rsp+0x50]
00007e2c933d5a57  vmovaps xmm6, [rsp+0x60]
00007e2c933d5a5d  vmovaps xmm7, [rsp+0x70]
00007e2c933d5a63  vmovaps xmm8, [rsp+0x80]
00007e2c933d5a6c  vmovaps xmm9, [rsp+0x90]
00007e2c933d5a75  vmovaps xmm10, [rsp+0xA0]
00007e2c933d5a7e  vmovaps xmm11, [rsp+0xB0]
00007e2c933d5a87  vmovaps xmm12, [rsp+0xC0]
00007e2c933d5a90  vmovaps xmm13, [rsp+0xD0]
00007e2c933d5a99  vmovaps xmm15, [rsp+0xE0]
00007e2c933d5aa2  add rsp, 0xF0
00007e2c933d5aa9  pop r11
00007e2c933d5aab  pop r10
00007e2c933d5aad  pop r9
00007e2c933d5aaf  pop r8
00007e2c933d5ab1  pop rsi
00007e2c933d5ab2  pop rdi
00007e2c933d5ab3  pop rdx
00007e2c933d5ab4  pop rcx
00007e2c933d5ab5  pop rax
00007e2c933d5ab6  add rsp, 0x08
00007e2c933d5aba  jmp 0x00007E2C933D2F99
00007e2c933d5abf  sub rsp, 0x08
00007e2c933d5ac3  push rax
00007e2c933d5ac4  push rcx
00007e2c933d5ac5  push rdx
00007e2c933d5ac6  push rdi
00007e2c933d5ac7  push rsi
00007e2c933d5ac8  push r8
00007e2c933d5aca  push r9
00007e2c933d5acc  push r10
00007e2c933d5ace  push r11
00007e2c933d5ad0  sub rsp, 0xF0
00007e2c933d5ad7  vmovaps [rsp], xmm0
00007e2c933d5adc  vmovaps [rsp+0x10], xmm1
00007e2c933d5ae2  vmovaps [rsp+0x20], xmm2
00007e2c933d5ae8  vmovaps [rsp+0x30], xmm3
00007e2c933d5aee  vmovaps [rsp+0x40], xmm4
00007e2c933d5af4  vmovaps [rsp+0x50], xmm5
00007e2c933d5afa  vmovaps [rsp+0x60], xmm7
00007e2c933d5b00  vmovaps [rsp+0x70], xmm8
00007e2c933d5b06  vmovaps [rsp+0x80], xmm9
00007e2c933d5b0f  vmovaps [rsp+0x90], xmm10
00007e2c933d5b18  vmovaps [rsp+0xA0], xmm11
00007e2c933d5b21  vmovaps [rsp+0xB0], xmm12
00007e2c933d5b2a  vmovaps [rsp+0xC0], xmm13
00007e2c933d5b33  vmovaps [rsp+0xD0], xmm14
00007e2c933d5b3c  vmovaps [rsp+0xE0], xmm15
00007e2c933d5b45  sub rsp, 0x30
00007e2c933d5b49  movaps [rsp], xmm6
00007e2c933d5b4d  movaps [rsp+0x10], xmm5
00007e2c933d5b52  movaps [rsp+0x20], xmm1
00007e2c933d5b57  lea rdi, [rsp]
00007e2c933d5b5b  mov esi, 0x00
00007e2c933d5b60  mov rax, 0x5A263F1C7530
00007e2c933d5b6a  call rax
00007e2c933d5b6c  movaps xmm6, [rsp]
00007e2c933d5b70  add rsp, 0x30
00007e2c933d5b74  vmovaps xmm0, [rsp]
00007e2c933d5b79  vmovaps xmm1, [rsp+0x10]
00007e2c933d5b7f  vmovaps xmm2, [rsp+0x20]
00007e2c933d5b85  vmovaps xmm3, [rsp+0x30]
00007e2c933d5b8b  vmovaps xmm4, [rsp+0x40]
00007e2c933d5b91  vmovaps xmm5, [rsp+0x50]
00007e2c933d5b97  vmovaps xmm7, [rsp+0x60]
00007e2c933d5b9d  vmovaps xmm8, [rsp+0x70]
00007e2c933d5ba3  vmovaps xmm9, [rsp+0x80]
00007e2c933d5bac  vmovaps xmm10, [rsp+0x90]
00007e2c933d5bb5  vmovaps xmm11, [rsp+0xA0]
00007e2c933d5bbe  vmovaps xmm12, [rsp+0xB0]
00007e2c933d5bc7  vmovaps xmm13, [rsp+0xC0]
00007e2c933d5bd0  vmovaps xmm14, [rsp+0xD0]
00007e2c933d5bd9  vmovaps xmm15, [rsp+0xE0]
00007e2c933d5be2  add rsp, 0xF0
00007e2c933d5be9  pop r11
00007e2c933d5beb  pop r10
00007e2c933d5bed  pop r9
00007e2c933d5bef  pop r8
00007e2c933d5bf1  pop rsi
00007e2c933d5bf2  pop rdi
00007e2c933d5bf3  pop rdx
00007e2c933d5bf4  pop rcx
00007e2c933d5bf5  pop rax
00007e2c933d5bf6  add rsp, 0x08
00007e2c933d5bfa  jmp 0x00007E2C933D2FBF
00007e2c933d5bff  sub rsp, 0x08
00007e2c933d5c03  push rax
00007e2c933d5c04  push rcx
00007e2c933d5c05  push rdx
00007e2c933d5c06  push rdi
00007e2c933d5c07  push rsi
00007e2c933d5c08  push r8
00007e2c933d5c0a  push r9
00007e2c933d5c0c  push r10
00007e2c933d5c0e  push r11
00007e2c933d5c10  sub rsp, 0xF0
00007e2c933d5c17  vmovaps [rsp], xmm0
00007e2c933d5c1c  vmovaps [rsp+0x10], xmm2
00007e2c933d5c22  vmovaps [rsp+0x20], xmm3
00007e2c933d5c28  vmovaps [rsp+0x30], xmm4
00007e2c933d5c2e  vmovaps [rsp+0x40], xmm5
00007e2c933d5c34  vmovaps [rsp+0x50], xmm6
00007e2c933d5c3a  vmovaps [rsp+0x60], xmm7
00007e2c933d5c40  vmovaps [rsp+0x70], xmm8
00007e2c933d5c46  vmovaps [rsp+0x80], xmm9
00007e2c933d5c4f  vmovaps [rsp+0x90], xmm10
00007e2c933d5c58  vmovaps [rsp+0xA0], xmm11
00007e2c933d5c61  vmovaps [rsp+0xB0], xmm12
00007e2c933d5c6a  vmovaps [rsp+0xC0], xmm13
00007e2c933d5c73  vmovaps [rsp+0xD0], xmm14
00007e2c933d5c7c  vmovaps [rsp+0xE0], xmm15
00007e2c933d5c85  sub rsp, 0x30
00007e2c933d5c89  movaps [rsp], xmm1
00007e2c933d5c8d  movaps [rsp+0x10], xmm5
00007e2c933d5c92  movaps [rsp+0x20], xmm13
00007e2c933d5c98  lea rdi, [rsp]
00007e2c933d5c9c  mov esi, 0x00
00007e2c933d5ca1  mov rax, 0x5A263F1C7530
00007e2c933d5cab  call rax
00007e2c933d5cad  movaps xmm1, [rsp]
00007e2c933d5cb1  add rsp, 0x30
00007e2c933d5cb5  vmovaps xmm0, [rsp]
00007e2c933d5cba  vmovaps xmm2, [rsp+0x10]
00007e2c933d5cc0  vmovaps xmm3, [rsp+0x20]
00007e2c933d5cc6  vmovaps xmm4, [rsp+0x30]
00007e2c933d5ccc  vmovaps xmm5, [rsp+0x40]
00007e2c933d5cd2  vmovaps xmm6, [rsp+0x50]
00007e2c933d5cd8  vmovaps xmm7, [rsp+0x60]
00007e2c933d5cde  vmovaps xmm8, [rsp+0x70]
00007e2c933d5ce4  vmovaps xmm9, [rsp+0x80]
00007e2c933d5ced  vmovaps xmm10, [rsp+0x90]
00007e2c933d5cf6  vmovaps xmm11, [rsp+0xA0]
00007e2c933d5cff  vmovaps xmm12, [rsp+0xB0]
00007e2c933d5d08  vmovaps xmm13, [rsp+0xC0]
00007e2c933d5d11  vmovaps xmm14, [rsp+0xD0]
00007e2c933d5d1a  vmovaps xmm15, [rsp+0xE0]
00007e2c933d5d23  add rsp, 0xF0
00007e2c933d5d2a  pop r11
00007e2c933d5d2c  pop r10
00007e2c933d5d2e  pop r9
00007e2c933d5d30  pop r8
00007e2c933d5d32  pop rsi
00007e2c933d5d33  pop rdi
00007e2c933d5d34  pop rdx
00007e2c933d5d35  pop rcx
00007e2c933d5d36  pop rax
00007e2c933d5d37  add rsp, 0x08
00007e2c933d5d3b  jmp 0x00007E2C933D2FDD
00007e2c933d5d40  sub rsp, 0x08
00007e2c933d5d44  push rax
00007e2c933d5d45  push rcx
00007e2c933d5d46  push rdx
00007e2c933d5d47  push rdi
00007e2c933d5d48  push rsi
00007e2c933d5d49  push r8
00007e2c933d5d4b  push r9
00007e2c933d5d4d  push r10
00007e2c933d5d4f  push r11
00007e2c933d5d51  sub rsp, 0xF0
00007e2c933d5d58  vmovaps [rsp], xmm0
00007e2c933d5d5d  vmovaps [rsp+0x10], xmm1
00007e2c933d5d63  vmovaps [rsp+0x20], xmm2
00007e2c933d5d69  vmovaps [rsp+0x30], xmm3
00007e2c933d5d6f  vmovaps [rsp+0x40], xmm4
00007e2c933d5d75  vmovaps [rsp+0x50], xmm6
00007e2c933d5d7b  vmovaps [rsp+0x60], xmm7
00007e2c933d5d81  vmovaps [rsp+0x70], xmm8
00007e2c933d5d87  vmovaps [rsp+0x80], xmm9
00007e2c933d5d90  vmovaps [rsp+0x90], xmm10
00007e2c933d5d99  vmovaps [rsp+0xA0], xmm11
00007e2c933d5da2  vmovaps [rsp+0xB0], xmm12
00007e2c933d5dab  vmovaps [rsp+0xC0], xmm13
00007e2c933d5db4  vmovaps [rsp+0xD0], xmm14
00007e2c933d5dbd  vmovaps [rsp+0xE0], xmm15
00007e2c933d5dc6  sub rsp, 0x30
00007e2c933d5dca  movaps [rsp], xmm5
00007e2c933d5dce  movaps [rsp+0x10], xmm2
00007e2c933d5dd3  movaps [rsp+0x20], xmm13
00007e2c933d5dd9  lea rdi, [rsp]
00007e2c933d5ddd  mov esi, 0x00
00007e2c933d5de2  mov rax, 0x5A263F1C7530
00007e2c933d5dec  call rax
00007e2c933d5dee  movaps xmm5, [rsp]
00007e2c933d5df2  add rsp, 0x30
00007e2c933d5df6  vmovaps xmm0, [rsp]
00007e2c933d5dfb  vmovaps xmm1, [rsp+0x10]
00007e2c933d5e01  vmovaps xmm2, [rsp+0x20]
00007e2c933d5e07  vmovaps xmm3, [rsp+0x30]
00007e2c933d5e0d  vmovaps xmm4, [rsp+0x40]
00007e2c933d5e13  vmovaps xmm6, [rsp+0x50]
00007e2c933d5e19  vmovaps xmm7, [rsp+0x60]
00007e2c933d5e1f  vmovaps xmm8, [rsp+0x70]
00007e2c933d5e25  vmovaps xmm9, [rsp+0x80]
00007e2c933d5e2e  vmovaps xmm10, [rsp+0x90]
00007e2c933d5e37  vmovaps xmm11, [rsp+0xA0]
00007e2c933d5e40  vmovaps xmm12, [rsp+0xB0]
00007e2c933d5e49  vmovaps xmm13, [rsp+0xC0]
00007e2c933d5e52  vmovaps xmm14, [rsp+0xD0]
00007e2c933d5e5b  vmovaps xmm15, [rsp+0xE0]
00007e2c933d5e64  add rsp, 0xF0
00007e2c933d5e6b  pop r11
00007e2c933d5e6d  pop r10
00007e2c933d5e6f  pop r9
00007e2c933d5e71  pop r8
00007e2c933d5e73  pop rsi
00007e2c933d5e74  pop rdi
00007e2c933d5e75  pop rdx
00007e2c933d5e76  pop rcx
00007e2c933d5e77  pop rax
00007e2c933d5e78  add rsp, 0x08
00007e2c933d5e7c  jmp 0x00007E2C933D3013
00007e2c933d5e81  sub rsp, 0x08
00007e2c933d5e85  push rax
00007e2c933d5e86  push rcx
00007e2c933d5e87  push rdx
00007e2c933d5e88  push rdi
00007e2c933d5e89  push rsi
00007e2c933d5e8a  push r8
00007e2c933d5e8c  push r9
00007e2c933d5e8e  push r10
00007e2c933d5e90  push r11
00007e2c933d5e92  sub rsp, 0xF0
00007e2c933d5e99  vmovaps [rsp], xmm0
00007e2c933d5e9e  vmovaps [rsp+0x10], xmm1
00007e2c933d5ea4  vmovaps [rsp+0x20], xmm2
00007e2c933d5eaa  vmovaps [rsp+0x30], xmm3
00007e2c933d5eb0  vmovaps [rsp+0x40], xmm4
00007e2c933d5eb6  vmovaps [rsp+0x50], xmm5
00007e2c933d5ebc  vmovaps [rsp+0x60], xmm6
00007e2c933d5ec2  vmovaps [rsp+0x70], xmm7
00007e2c933d5ec8  vmovaps [rsp+0x80], xmm8
00007e2c933d5ed1  vmovaps [rsp+0x90], xmm9
00007e2c933d5eda  vmovaps [rsp+0xA0], xmm10
00007e2c933d5ee3  vmovaps [rsp+0xB0], xmm11
00007e2c933d5eec  vmovaps [rsp+0xC0], xmm12
00007e2c933d5ef5  vmovaps [rsp+0xD0], xmm14
00007e2c933d5efe  vmovaps [rsp+0xE0], xmm15
00007e2c933d5f07  sub rsp, 0x30
00007e2c933d5f0b  movaps [rsp], xmm13
00007e2c933d5f10  movaps [rsp+0x10], xmm10
00007e2c933d5f16  movaps [rsp+0x20], xmm1
00007e2c933d5f1b  lea rdi, [rsp]
00007e2c933d5f1f  mov esi, 0x00
00007e2c933d5f24  mov rax, 0x5A263F1C7530
00007e2c933d5f2e  call rax
00007e2c933d5f30  movaps xmm13, [rsp]
00007e2c933d5f35  add rsp, 0x30
00007e2c933d5f39  vmovaps xmm0, [rsp]
00007e2c933d5f3e  vmovaps xmm1, [rsp+0x10]
00007e2c933d5f44  vmovaps xmm2, [rsp+0x20]
00007e2c933d5f4a  vmovaps xmm3, [rsp+0x30]
00007e2c933d5f50  vmovaps xmm4, [rsp+0x40]
00007e2c933d5f56  vmovaps xmm5, [rsp+0x50]
00007e2c933d5f5c  vmovaps xmm6, [rsp+0x60]
00007e2c933d5f62  vmovaps xmm7, [rsp+0x70]
00007e2c933d5f68  vmovaps xmm8, [rsp+0x80]
00007e2c933d5f71  vmovaps xmm9, [rsp+0x90]
00007e2c933d5f7a  vmovaps xmm10, [rsp+0xA0]
00007e2c933d5f83  vmovaps xmm11, [rsp+0xB0]
00007e2c933d5f8c  vmovaps xmm12, [rsp+0xC0]
00007e2c933d5f95  vmovaps xmm14, [rsp+0xD0]
00007e2c933d5f9e  vmovaps xmm15, [rsp+0xE0]
00007e2c933d5fa7  add rsp, 0xF0
00007e2c933d5fae  pop r11
00007e2c933d5fb0  pop r10
00007e2c933d5fb2  pop r9
00007e2c933d5fb4  pop r8
00007e2c933d5fb6  pop rsi
00007e2c933d5fb7  pop rdi
00007e2c933d5fb8  pop rdx
00007e2c933d5fb9  pop rcx
00007e2c933d5fba  pop rax
00007e2c933d5fbb  add rsp, 0x08
00007e2c933d5fbf  jmp 0x00007E2C933D303C
00007e2c933d5fc4  sub rsp, 0x08
00007e2c933d5fc8  push rax
00007e2c933d5fc9  push rcx
00007e2c933d5fca  push rdx
00007e2c933d5fcb  push rdi
00007e2c933d5fcc  push rsi
00007e2c933d5fcd  push r8
00007e2c933d5fcf  push r9
00007e2c933d5fd1  push r10
00007e2c933d5fd3  push r11
00007e2c933d5fd5  sub rsp, 0xF0
00007e2c933d5fdc  vmovaps [rsp], xmm0
00007e2c933d5fe1  vmovaps [rsp+0x10], xmm2
00007e2c933d5fe7  vmovaps [rsp+0x20], xmm3
00007e2c933d5fed  vmovaps [rsp+0x30], xmm4
00007e2c933d5ff3  vmovaps [rsp+0x40], xmm5
00007e2c933d5ff9  vmovaps [rsp+0x50], xmm6
00007e2c933d5fff  vmovaps [rsp+0x60], xmm7
00007e2c933d6005  vmovaps [rsp+0x70], xmm8
00007e2c933d600b  vmovaps [rsp+0x80], xmm9
00007e2c933d6014  vmovaps [rsp+0x90], xmm10
00007e2c933d601d  vmovaps [rsp+0xA0], xmm11
00007e2c933d6026  vmovaps [rsp+0xB0], xmm12
00007e2c933d602f  vmovaps [rsp+0xC0], xmm13
00007e2c933d6038  vmovaps [rsp+0xD0], xmm14
00007e2c933d6041  vmovaps [rsp+0xE0], xmm15
00007e2c933d604a  sub rsp, 0x30
00007e2c933d604e  movaps [rsp], xmm1
00007e2c933d6052  movaps [rsp+0x10], xmm15
00007e2c933d6058  movaps [rsp+0x20], xmm10
00007e2c933d605e  lea rdi, [rsp]
00007e2c933d6062  mov esi, 0x00
00007e2c933d6067  mov rax, 0x5A263F1C7530
00007e2c933d6071  call rax
00007e2c933d6073  movaps xmm1, [rsp]
00007e2c933d6077  add rsp, 0x30
00007e2c933d607b  vmovaps xmm0, [rsp]
00007e2c933d6080  vmovaps xmm2, [rsp+0x10]
00007e2c933d6086  vmovaps xmm3, [rsp+0x20]
00007e2c933d608c  vmovaps xmm4, [rsp+0x30]
00007e2c933d6092  vmovaps xmm5, [rsp+0x40]
00007e2c933d6098  vmovaps xmm6, [rsp+0x50]
00007e2c933d609e  vmovaps xmm7, [rsp+0x60]
00007e2c933d60a4  vmovaps xmm8, [rsp+0x70]
00007e2c933d60aa  vmovaps xmm9, [rsp+0x80]
00007e2c933d60b3  vmovaps xmm10, [rsp+0x90]
00007e2c933d60bc  vmovaps xmm11, [rsp+0xA0]
00007e2c933d60c5  vmovaps xmm12, [rsp+0xB0]
00007e2c933d60ce  vmovaps xmm13, [rsp+0xC0]
00007e2c933d60d7  vmovaps xmm14, [rsp+0xD0]
00007e2c933d60e0  vmovaps xmm15, [rsp+0xE0]
00007e2c933d60e9  add rsp, 0xF0
00007e2c933d60f0  pop r11
00007e2c933d60f2  pop r10
00007e2c933d60f4  pop r9
00007e2c933d60f6  pop r8
00007e2c933d60f8  pop rsi
00007e2c933d60f9  pop rdi
00007e2c933d60fa  pop rdx
00007e2c933d60fb  pop rcx
00007e2c933d60fc  pop rax
00007e2c933d60fd  add rsp, 0x08
00007e2c933d6101  jmp 0x00007E2C933D305B
00007e2c933d6106  sub rsp, 0x08
00007e2c933d610a  push rax
00007e2c933d610b  push rcx
00007e2c933d610c  push rdx
00007e2c933d610d  push rdi
00007e2c933d610e  push rsi
00007e2c933d610f  push r8
00007e2c933d6111  push r9
00007e2c933d6113  push r10
00007e2c933d6115  push r11
00007e2c933d6117  sub rsp, 0xF0
00007e2c933d611e  vmovaps [rsp], xmm0
00007e2c933d6123  vmovaps [rsp+0x10], xmm1
00007e2c933d6129  vmovaps [rsp+0x20], xmm2
00007e2c933d612f  vmovaps [rsp+0x30], xmm3
00007e2c933d6135  vmovaps [rsp+0x40], xmm4
00007e2c933d613b  vmovaps [rsp+0x50], xmm5
00007e2c933d6141  vmovaps [rsp+0x60], xmm6
00007e2c933d6147  vmovaps [rsp+0x70], xmm7
00007e2c933d614d  vmovaps [rsp+0x80], xmm8
00007e2c933d6156  vmovaps [rsp+0x90], xmm9
00007e2c933d615f  vmovaps [rsp+0xA0], xmm10
00007e2c933d6168  vmovaps [rsp+0xB0], xmm11
00007e2c933d6171  vmovaps [rsp+0xC0], xmm12
00007e2c933d617a  vmovaps [rsp+0xD0], xmm13
00007e2c933d6183  vmovaps [rsp+0xE0], xmm14
00007e2c933d618c  sub rsp, 0x30
00007e2c933d6190  movaps [rsp], xmm15
00007e2c933d6195  movaps [rsp+0x10], xmm10
00007e2c933d619b  movaps [rsp+0x20], xmm11
00007e2c933d61a1  lea rdi, [rsp]
00007e2c933d61a5  mov esi, 0x00
00007e2c933d61aa  mov rax, 0x5A263F1C7530
00007e2c933d61b4  call rax
00007e2c933d61b6  movaps xmm15, [rsp]
00007e2c933d61bb  add rsp, 0x30
00007e2c933d61bf  vmovaps xmm0, [rsp]
00007e2c933d61c4  vmovaps xmm1, [rsp+0x10]
00007e2c933d61ca  vmovaps xmm2, [rsp+0x20]
00007e2c933d61d0  vmovaps xmm3, [rsp+0x30]
00007e2c933d61d6  vmovaps xmm4, [rsp+0x40]
00007e2c933d61dc  vmovaps xmm5, [rsp+0x50]
00007e2c933d61e2  vmovaps xmm6, [rsp+0x60]
00007e2c933d61e8  vmovaps xmm7, [rsp+0x70]
00007e2c933d61ee  vmovaps xmm8, [rsp+0x80]
00007e2c933d61f7  vmovaps xmm9, [rsp+0x90]
00007e2c933d6200  vmovaps xmm10, [rsp+0xA0]
00007e2c933d6209  vmovaps xmm11, [rsp+0xB0]
00007e2c933d6212  vmovaps xmm12, [rsp+0xC0]
00007e2c933d621b  vmovaps xmm13, [rsp+0xD0]
00007e2c933d6224  vmovaps xmm14, [rsp+0xE0]
00007e2c933d622d  add rsp, 0xF0
00007e2c933d6234  pop r11
00007e2c933d6236  pop r10
00007e2c933d6238  pop r9
00007e2c933d623a  pop r8
00007e2c933d623c  pop rsi
00007e2c933d623d  pop rdi
00007e2c933d623e  pop rdx
00007e2c933d623f  pop rcx
00007e2c933d6240  pop rax
00007e2c933d6241  add rsp, 0x08
00007e2c933d6245  jmp 0x00007E2C933D307E
00007e2c933d624a  sub rsp, 0x08
00007e2c933d624e  push rax
00007e2c933d624f  push rcx
00007e2c933d6250  push rdx
00007e2c933d6251  push rdi
00007e2c933d6252  push rsi
00007e2c933d6253  push r8
00007e2c933d6255  push r9
00007e2c933d6257  push r10
00007e2c933d6259  push r11
00007e2c933d625b  sub rsp, 0xF0
00007e2c933d6262  vmovaps [rsp], xmm0
00007e2c933d6267  vmovaps [rsp+0x10], xmm1
00007e2c933d626d  vmovaps [rsp+0x20], xmm2
00007e2c933d6273  vmovaps [rsp+0x30], xmm3
00007e2c933d6279  vmovaps [rsp+0x40], xmm4
00007e2c933d627f  vmovaps [rsp+0x50], xmm5
00007e2c933d6285  vmovaps [rsp+0x60], xmm6
00007e2c933d628b  vmovaps [rsp+0x70], xmm7
00007e2c933d6291  vmovaps [rsp+0x80], xmm8
00007e2c933d629a  vmovaps [rsp+0x90], xmm9
00007e2c933d62a3  vmovaps [rsp+0xA0], xmm11
00007e2c933d62ac  vmovaps [rsp+0xB0], xmm12
00007e2c933d62b5  vmovaps [rsp+0xC0], xmm13
00007e2c933d62be  vmovaps [rsp+0xD0], xmm14
00007e2c933d62c7  vmovaps [rsp+0xE0], xmm15
00007e2c933d62d0  sub rsp, 0x30
00007e2c933d62d4  movaps [rsp], xmm10
00007e2c933d62d9  movaps [rsp+0x10], xmm2
00007e2c933d62de  movaps [rsp+0x20], xmm11
00007e2c933d62e4  lea rdi, [rsp]
00007e2c933d62e8  mov esi, 0x00
00007e2c933d62ed  mov rax, 0x5A263F1C7530
00007e2c933d62f7  call rax
00007e2c933d62f9  movaps xmm10, [rsp]
00007e2c933d62fe  add rsp, 0x30
00007e2c933d6302  vmovaps xmm0, [rsp]
00007e2c933d6307  vmovaps xmm1, [rsp+0x10]
00007e2c933d630d  vmovaps xmm2, [rsp+0x20]
00007e2c933d6313  vmovaps xmm3, [rsp+0x30]
00007e2c933d6319  vmovaps xmm4, [rsp+0x40]
00007e2c933d631f  vmovaps xmm5, [rsp+0x50]
00007e2c933d6325  vmovaps xmm6, [rsp+0x60]
00007e2c933d632b  vmovaps xmm7, [rsp+0x70]
00007e2c933d6331  vmovaps xmm8, [rsp+0x80]
00007e2c933d633a  vmovaps xmm9, [rsp+0x90]
00007e2c933d6343  vmovaps xmm11, [rsp+0xA0]
00007e2c933d634c  vmovaps xmm12, [rsp+0xB0]
00007e2c933d6355  vmovaps xmm13, [rsp+0xC0]
00007e2c933d635e  vmovaps xmm14, [rsp+0xD0]
00007e2c933d6367  vmovaps xmm15, [rsp+0xE0]
00007e2c933d6370  add rsp, 0xF0
00007e2c933d6377  pop r11
00007e2c933d6379  pop r10
00007e2c933d637b  pop r9
00007e2c933d637d  pop r8
00007e2c933d637f  pop rsi
00007e2c933d6380  pop rdi
00007e2c933d6381  pop rdx
00007e2c933d6382  pop rcx
00007e2c933d6383  pop rax
00007e2c933d6384  add rsp, 0x08
00007e2c933d6388  jmp 0x00007E2C933D30B6
00007e2c933d638d  sub rsp, 0x08
00007e2c933d6391  push rax
00007e2c933d6392  push rcx
00007e2c933d6393  push rdx
00007e2c933d6394  push rdi
00007e2c933d6395  push rsi
00007e2c933d6396  push r8
00007e2c933d6398  push r9
00007e2c933d639a  push r10
00007e2c933d639c  push r11
00007e2c933d639e  sub rsp, 0xF0
00007e2c933d63a5  vmovaps [rsp], xmm0
00007e2c933d63aa  vmovaps [rsp+0x10], xmm1
00007e2c933d63b0  vmovaps [rsp+0x20], xmm2
00007e2c933d63b6  vmovaps [rsp+0x30], xmm3
00007e2c933d63bc  vmovaps [rsp+0x40], xmm4
00007e2c933d63c2  vmovaps [rsp+0x50], xmm5
00007e2c933d63c8  vmovaps [rsp+0x60], xmm6
00007e2c933d63ce  vmovaps [rsp+0x70], xmm7
00007e2c933d63d4  vmovaps [rsp+0x80], xmm8
00007e2c933d63dd  vmovaps [rsp+0x90], xmm9
00007e2c933d63e6  vmovaps [rsp+0xA0], xmm10
00007e2c933d63ef  vmovaps [rsp+0xB0], xmm12
00007e2c933d63f8  vmovaps [rsp+0xC0], xmm13
00007e2c933d6401  vmovaps [rsp+0xD0], xmm14
00007e2c933d640a  vmovaps [rsp+0xE0], xmm15
00007e2c933d6413  sub rsp, 0x30
00007e2c933d6417  movaps [rsp], xmm11
00007e2c933d641c  movaps [rsp+0x10], xmm2
00007e2c933d6421  movaps [rsp+0x20], xmm1
00007e2c933d6426  lea rdi, [rsp]
00007e2c933d642a  mov esi, 0x00
00007e2c933d642f  mov rax, 0x5A263F1C7530
00007e2c933d6439  call rax
00007e2c933d643b  movaps xmm11, [rsp]
00007e2c933d6440  add rsp, 0x30
00007e2c933d6444  vmovaps xmm0, [rsp]
00007e2c933d6449  vmovaps xmm1, [rsp+0x10]
00007e2c933d644f  vmovaps xmm2, [rsp+0x20]
00007e2c933d6455  vmovaps xmm3, [rsp+0x30]
00007e2c933d645b  vmovaps xmm4, [rsp+0x40]
00007e2c933d6461  vmovaps xmm5, [rsp+0x50]
00007e2c933d6467  vmovaps xmm6, [rsp+0x60]
00007e2c933d646d  vmovaps xmm7, [rsp+0x70]
00007e2c933d6473  vmovaps xmm8, [rsp+0x80]
00007e2c933d647c  vmovaps xmm9, [rsp+0x90]
00007e2c933d6485  vmovaps xmm10, [rsp+0xA0]
00007e2c933d648e  vmovaps xmm12, [rsp+0xB0]
00007e2c933d6497  vmovaps xmm13, [rsp+0xC0]
00007e2c933d64a0  vmovaps xmm14, [rsp+0xD0]
00007e2c933d64a9  vmovaps xmm15, [rsp+0xE0]
00007e2c933d64b2  add rsp, 0xF0
00007e2c933d64b9  pop r11
00007e2c933d64bb  pop r10
00007e2c933d64bd  pop r9
00007e2c933d64bf  pop r8
00007e2c933d64c1  pop rsi
00007e2c933d64c2  pop rdi
00007e2c933d64c3  pop rdx
00007e2c933d64c4  pop rcx
00007e2c933d64c5  pop rax
00007e2c933d64c6  add rsp, 0x08
00007e2c933d64ca  jmp 0x00007E2C933D30F2
00007e2c933d64cf  sub rsp, 0x08
00007e2c933d64d3  push rax
00007e2c933d64d4  push rcx
00007e2c933d64d5  push rdx
00007e2c933d64d6  push rdi
00007e2c933d64d7  push rsi
00007e2c933d64d8  push r8
00007e2c933d64da  push r9
00007e2c933d64dc  push r10
00007e2c933d64de  push r11
00007e2c933d64e0  sub rsp, 0xF0
00007e2c933d64e7  vmovaps [rsp], xmm0
00007e2c933d64ec  vmovaps [rsp+0x10], xmm2
00007e2c933d64f2  vmovaps [rsp+0x20], xmm3
00007e2c933d64f8  vmovaps [rsp+0x30], xmm4
00007e2c933d64fe  vmovaps [rsp+0x40], xmm5
00007e2c933d6504  vmovaps [rsp+0x50], xmm6
00007e2c933d650a  vmovaps [rsp+0x60], xmm7
00007e2c933d6510  vmovaps [rsp+0x70], xmm8
00007e2c933d6516  vmovaps [rsp+0x80], xmm9
00007e2c933d651f  vmovaps [rsp+0x90], xmm10
00007e2c933d6528  vmovaps [rsp+0xA0], xmm11
00007e2c933d6531  vmovaps [rsp+0xB0], xmm12
00007e2c933d653a  vmovaps [rsp+0xC0], xmm13
00007e2c933d6543  vmovaps [rsp+0xD0], xmm14
00007e2c933d654c  vmovaps [rsp+0xE0], xmm15
00007e2c933d6555  sub rsp, 0x30
00007e2c933d6559  movaps [rsp], xmm1
00007e2c933d655d  movaps [rsp+0x10], xmm14
00007e2c933d6563  movaps [rsp+0x20], xmm6
00007e2c933d6568  lea rdi, [rsp]
00007e2c933d656c  mov esi, 0x00
00007e2c933d6571  mov rax, 0x5A263F1C7530
00007e2c933d657b  call rax
00007e2c933d657d  movaps xmm1, [rsp]
00007e2c933d6581  add rsp, 0x30
00007e2c933d6585  vmovaps xmm0, [rsp]
00007e2c933d658a  vmovaps xmm2, [rsp+0x10]
00007e2c933d6590  vmovaps xmm3, [rsp+0x20]
00007e2c933d6596  vmovaps xmm4, [rsp+0x30]
00007e2c933d659c  vmovaps xmm5, [rsp+0x40]
00007e2c933d65a2  vmovaps xmm6, [rsp+0x50]
00007e2c933d65a8  vmovaps xmm7, [rsp+0x60]
00007e2c933d65ae  vmovaps xmm8, [rsp+0x70]
00007e2c933d65b4  vmovaps xmm9, [rsp+0x80]
00007e2c933d65bd  vmovaps xmm10, [rsp+0x90]
00007e2c933d65c6  vmovaps xmm11, [rsp+0xA0]
00007e2c933d65cf  vmovaps xmm12, [rsp+0xB0]
00007e2c933d65d8  vmovaps xmm13, [rsp+0xC0]
00007e2c933d65e1  vmovaps xmm14, [rsp+0xD0]
00007e2c933d65ea  vmovaps xmm15, [rsp+0xE0]
00007e2c933d65f3  add rsp, 0xF0
00007e2c933d65fa  pop r11
00007e2c933d65fc  pop r10
00007e2c933d65fe  pop r9
00007e2c933d6600  pop r8
00007e2c933d6602  pop rsi
00007e2c933d6603  pop rdi
00007e2c933d6604  pop rdx
00007e2c933d6605  pop rcx
00007e2c933d6606  pop rax
00007e2c933d6607  add rsp, 0x08
00007e2c933d660b  jmp 0x00007E2C933D310B
00007e2c933d6610  sub rsp, 0x08
00007e2c933d6614  push rax
00007e2c933d6615  push rcx
00007e2c933d6616  push rdx
00007e2c933d6617  push rdi
00007e2c933d6618  push rsi
00007e2c933d6619  push r8
00007e2c933d661b  push r9
00007e2c933d661d  push r10
00007e2c933d661f  push r11
00007e2c933d6621  sub rsp, 0xF0
00007e2c933d6628  vmovaps [rsp], xmm0
00007e2c933d662d  vmovaps [rsp+0x10], xmm1
00007e2c933d6633  vmovaps [rsp+0x20], xmm2
00007e2c933d6639  vmovaps [rsp+0x30], xmm3
00007e2c933d663f  vmovaps [rsp+0x40], xmm4
00007e2c933d6645  vmovaps [rsp+0x50], xmm5
00007e2c933d664b  vmovaps [rsp+0x60], xmm6
00007e2c933d6651  vmovaps [rsp+0x70], xmm7
00007e2c933d6657  vmovaps [rsp+0x80], xmm8
00007e2c933d6660  vmovaps [rsp+0x90], xmm9
00007e2c933d6669  vmovaps [rsp+0xA0], xmm10
00007e2c933d6672  vmovaps [rsp+0xB0], xmm11
00007e2c933d667b  vmovaps [rsp+0xC0], xmm12
00007e2c933d6684  vmovaps [rsp+0xD0], xmm13
00007e2c933d668d  vmovaps [rsp+0xE0], xmm14
00007e2c933d6696  sub rsp, 0x30
00007e2c933d669a  movaps [rsp], xmm15
00007e2c933d669f  movaps [rsp+0x10], xmm14
00007e2c933d66a5  movaps [rsp+0x20], xmm5
00007e2c933d66aa  lea rdi, [rsp]
00007e2c933d66ae  mov esi, 0x00
00007e2c933d66b3  mov rax, 0x5A263F1C7530
00007e2c933d66bd  call rax
00007e2c933d66bf  movaps xmm15, [rsp]
00007e2c933d66c4  add rsp, 0x30
00007e2c933d66c8  vmovaps xmm0, [rsp]
00007e2c933d66cd  vmovaps xmm1, [rsp+0x10]
00007e2c933d66d3  vmovaps xmm2, [rsp+0x20]
00007e2c933d66d9  vmovaps xmm3, [rsp+0x30]
00007e2c933d66df  vmovaps xmm4, [rsp+0x40]
00007e2c933d66e5  vmovaps xmm5, [rsp+0x50]
00007e2c933d66eb  vmovaps xmm6, [rsp+0x60]
00007e2c933d66f1  vmovaps xmm7, [rsp+0x70]
00007e2c933d66f7  vmovaps xmm8, [rsp+0x80]
00007e2c933d6700  vmovaps xmm9, [rsp+0x90]
00007e2c933d6709  vmovaps xmm10, [rsp+0xA0]
00007e2c933d6712  vmovaps xmm11, [rsp+0xB0]
00007e2c933d671b  vmovaps xmm12, [rsp+0xC0]
00007e2c933d6724  vmovaps xmm13, [rsp+0xD0]
00007e2c933d672d  vmovaps xmm14, [rsp+0xE0]
00007e2c933d6736  add rsp, 0xF0
00007e2c933d673d  pop r11
00007e2c933d673f  pop r10
00007e2c933d6741  pop r9
00007e2c933d6743  pop r8
00007e2c933d6745  pop rsi
00007e2c933d6746  pop rdi
00007e2c933d6747  pop rdx
00007e2c933d6748  pop rcx
00007e2c933d6749  pop rax
00007e2c933d674a  add rsp, 0x08
00007e2c933d674e  jmp 0x00007E2C933D312B
00007e2c933d6753  sub rsp, 0x08
00007e2c933d6757  push rax
00007e2c933d6758  push rcx
00007e2c933d6759  push rdx
00007e2c933d675a  push rdi
00007e2c933d675b  push rsi
00007e2c933d675c  push r8
00007e2c933d675e  push r9
00007e2c933d6760  push r10
00007e2c933d6762  push r11
00007e2c933d6764  sub rsp, 0xF0
00007e2c933d676b  vmovaps [rsp], xmm0
00007e2c933d6770  vmovaps [rsp+0x10], xmm1
00007e2c933d6776  vmovaps [rsp+0x20], xmm2
00007e2c933d677c  vmovaps [rsp+0x30], xmm3
00007e2c933d6782  vmovaps [rsp+0x40], xmm4
00007e2c933d6788  vmovaps [rsp+0x50], xmm5
00007e2c933d678e  vmovaps [rsp+0x60], xmm7
00007e2c933d6794  vmovaps [rsp+0x70], xmm8
00007e2c933d679a  vmovaps [rsp+0x80], xmm9
00007e2c933d67a3  vmovaps [rsp+0x90], xmm10
00007e2c933d67ac  vmovaps [rsp+0xA0], xmm11
00007e2c933d67b5  vmovaps [rsp+0xB0], xmm12
00007e2c933d67be  vmovaps [rsp+0xC0], xmm13
00007e2c933d67c7  vmovaps [rsp+0xD0], xmm14
00007e2c933d67d0  vmovaps [rsp+0xE0], xmm15
00007e2c933d67d9  sub rsp, 0x30
00007e2c933d67dd  movaps [rsp], xmm6
00007e2c933d67e1  movaps [rsp+0x10], xmm9
00007e2c933d67e7  movaps [rsp+0x20], xmm14
00007e2c933d67ed  lea rdi, [rsp]
00007e2c933d67f1  mov esi, 0x00
00007e2c933d67f6  mov rax, 0x5A263F1C7530
00007e2c933d6800  call rax
00007e2c933d6802  movaps xmm6, [rsp]
00007e2c933d6806  add rsp, 0x30
00007e2c933d680a  vmovaps xmm0, [rsp]
00007e2c933d680f  vmovaps xmm1, [rsp+0x10]
00007e2c933d6815  vmovaps xmm2, [rsp+0x20]
00007e2c933d681b  vmovaps xmm3, [rsp+0x30]
00007e2c933d6821  vmovaps xmm4, [rsp+0x40]
00007e2c933d6827  vmovaps xmm5, [rsp+0x50]
00007e2c933d682d  vmovaps xmm7, [rsp+0x60]
00007e2c933d6833  vmovaps xmm8, [rsp+0x70]
00007e2c933d6839  vmovaps xmm9, [rsp+0x80]
00007e2c933d6842  vmovaps xmm10, [rsp+0x90]
00007e2c933d684b  vmovaps xmm11, [rsp+0xA0]
00007e2c933d6854  vmovaps xmm12, [rsp+0xB0]
00007e2c933d685d  vmovaps xmm13, [rsp+0xC0]
00007e2c933d6866  vmovaps xmm14, [rsp+0xD0]
00007e2c933d686f  vmovaps xmm15, [rsp+0xE0]
00007e2c933d6878  add rsp, 0xF0
00007e2c933d687f  pop r11
00007e2c933d6881  pop r10
00007e2c933d6883  pop r9
00007e2c933d6885  pop r8
00007e2c933d6887  pop rsi
00007e2c933d6888  pop rdi
00007e2c933d6889  pop rdx
00007e2c933d688a  pop rcx
00007e2c933d688b  pop rax
00007e2c933d688c  add rsp, 0x08
00007e2c933d6890  jmp 0x00007E2C933D3153
00007e2c933d6895  sub rsp, 0x08
00007e2c933d6899  push rax
00007e2c933d689a  push rcx
00007e2c933d689b  push rdx
00007e2c933d689c  push rdi
00007e2c933d689d  push rsi
00007e2c933d689e  push r8
00007e2c933d68a0  push r9
00007e2c933d68a2  push r10
00007e2c933d68a4  push r11
00007e2c933d68a6  sub rsp, 0xF0
00007e2c933d68ad  vmovaps [rsp], xmm0
00007e2c933d68b2  vmovaps [rsp+0x10], xmm1
00007e2c933d68b8  vmovaps [rsp+0x20], xmm2
00007e2c933d68be  vmovaps [rsp+0x30], xmm3
00007e2c933d68c4  vmovaps [rsp+0x40], xmm4
00007e2c933d68ca  vmovaps [rsp+0x50], xmm5
00007e2c933d68d0  vmovaps [rsp+0x60], xmm6
00007e2c933d68d6  vmovaps [rsp+0x70], xmm7
00007e2c933d68dc  vmovaps [rsp+0x80], xmm8
00007e2c933d68e5  vmovaps [rsp+0x90], xmm9
00007e2c933d68ee  vmovaps [rsp+0xA0], xmm10
00007e2c933d68f7  vmovaps [rsp+0xB0], xmm11
00007e2c933d6900  vmovaps [rsp+0xC0], xmm12
00007e2c933d6909  vmovaps [rsp+0xD0], xmm13
00007e2c933d6912  vmovaps [rsp+0xE0], xmm15
00007e2c933d691b  sub rsp, 0x30
00007e2c933d691f  movaps [rsp], xmm14
00007e2c933d6924  movaps [rsp+0x10], xmm9
00007e2c933d692a  movaps [rsp+0x20], xmm13
00007e2c933d6930  lea rdi, [rsp]
00007e2c933d6934  mov esi, 0x00
00007e2c933d6939  mov rax, 0x5A263F1C7530
00007e2c933d6943  call rax
00007e2c933d6945  movaps xmm14, [rsp]
00007e2c933d694a  add rsp, 0x30
00007e2c933d694e  vmovaps xmm0, [rsp]
00007e2c933d6953  vmovaps xmm1, [rsp+0x10]
00007e2c933d6959  vmovaps xmm2, [rsp+0x20]
00007e2c933d695f  vmovaps xmm3, [rsp+0x30]
00007e2c933d6965  vmovaps xmm4, [rsp+0x40]
00007e2c933d696b  vmovaps xmm5, [rsp+0x50]
00007e2c933d6971  vmovaps xmm6, [rsp+0x60]
00007e2c933d6977  vmovaps xmm7, [rsp+0x70]
00007e2c933d697d  vmovaps xmm8, [rsp+0x80]
00007e2c933d6986  vmovaps xmm9, [rsp+0x90]
00007e2c933d698f  vmovaps xmm10, [rsp+0xA0]
00007e2c933d6998  vmovaps xmm11, [rsp+0xB0]
00007e2c933d69a1  vmovaps xmm12, [rsp+0xC0]
00007e2c933d69aa  vmovaps xmm13, [rsp+0xD0]
00007e2c933d69b3  vmovaps xmm15, [rsp+0xE0]
00007e2c933d69bc  add rsp, 0xF0
00007e2c933d69c3  pop r11
00007e2c933d69c5  pop r10
00007e2c933d69c7  pop r9
00007e2c933d69c9  pop r8
00007e2c933d69cb  pop rsi
00007e2c933d69cc  pop rdi
00007e2c933d69cd  pop rdx
00007e2c933d69ce  pop rcx
00007e2c933d69cf  pop rax
00007e2c933d69d0  add rsp, 0x08
00007e2c933d69d4  jmp 0x00007E2C933D3176
00007e2c933d69d9  sub rsp, 0x08
00007e2c933d69dd  push rax
00007e2c933d69de  push rcx
00007e2c933d69df  push rdx
00007e2c933d69e0  push rdi
00007e2c933d69e1  push rsi
00007e2c933d69e2  push r8
00007e2c933d69e4  push r9
00007e2c933d69e6  push r10
00007e2c933d69e8  push r11
00007e2c933d69ea  sub rsp, 0xF0
00007e2c933d69f1  vmovaps [rsp], xmm0
00007e2c933d69f6  vmovaps [rsp+0x10], xmm1
00007e2c933d69fc  vmovaps [rsp+0x20], xmm2
00007e2c933d6a02  vmovaps [rsp+0x30], xmm3
00007e2c933d6a08  vmovaps [rsp+0x40], xmm4
00007e2c933d6a0e  vmovaps [rsp+0x50], xmm5
00007e2c933d6a14  vmovaps [rsp+0x60], xmm6
00007e2c933d6a1a  vmovaps [rsp+0x70], xmm7
00007e2c933d6a20  vmovaps [rsp+0x80], xmm8
00007e2c933d6a29  vmovaps [rsp+0x90], xmm9
00007e2c933d6a32  vmovaps [rsp+0xA0], xmm10
00007e2c933d6a3b  vmovaps [rsp+0xB0], xmm11
00007e2c933d6a44  vmovaps [rsp+0xC0], xmm12
00007e2c933d6a4d  vmovaps [rsp+0xD0], xmm14
00007e2c933d6a56  vmovaps [rsp+0xE0], xmm15
00007e2c933d6a5f  sub rsp, 0x30
00007e2c933d6a63  movaps [rsp], xmm13
00007e2c933d6a68  movaps [rsp+0x10], xmm9
00007e2c933d6a6e  movaps [rsp+0x20], xmm10
00007e2c933d6a74  lea rdi, [rsp]
00007e2c933d6a78  mov esi, 0x00
00007e2c933d6a7d  mov rax, 0x5A263F1C7530
00007e2c933d6a87  call rax
00007e2c933d6a89  movaps xmm13, [rsp]
00007e2c933d6a8e  add rsp, 0x30
00007e2c933d6a92  vmovaps xmm0, [rsp]
00007e2c933d6a97  vmovaps xmm1, [rsp+0x10]
00007e2c933d6a9d  vmovaps xmm2, [rsp+0x20]
00007e2c933d6aa3  vmovaps xmm3, [rsp+0x30]
00007e2c933d6aa9  vmovaps xmm4, [rsp+0x40]
00007e2c933d6aaf  vmovaps xmm5, [rsp+0x50]
00007e2c933d6ab5  vmovaps xmm6, [rsp+0x60]
00007e2c933d6abb  vmovaps xmm7, [rsp+0x70]
00007e2c933d6ac1  vmovaps xmm8, [rsp+0x80]
00007e2c933d6aca  vmovaps xmm9, [rsp+0x90]
00007e2c933d6ad3  vmovaps xmm10, [rsp+0xA0]
00007e2c933d6adc  vmovaps xmm11, [rsp+0xB0]
00007e2c933d6ae5  vmovaps xmm12, [rsp+0xC0]
00007e2c933d6aee  vmovaps xmm14, [rsp+0xD0]
00007e2c933d6af7  vmovaps xmm15, [rsp+0xE0]
00007e2c933d6b00  add rsp, 0xF0
00007e2c933d6b07  pop r11
00007e2c933d6b09  pop r10
00007e2c933d6b0b  pop r9
00007e2c933d6b0d  pop r8
00007e2c933d6b0f  pop rsi
00007e2c933d6b10  pop rdi
00007e2c933d6b11  pop rdx
00007e2c933d6b12  pop rcx
00007e2c933d6b13  pop rax
00007e2c933d6b14  add rsp, 0x08
00007e2c933d6b18  jmp 0x00007E2C933D3196
00007e2c933d6b1d  call 0x00007E2C9320AFE0
00007e2c933d6b22  jmp 0x00007E2C933D31EB
00007e2c933d6b27  sub rsp, 0x08
00007e2c933d6b2b  push rax
00007e2c933d6b2c  push rcx
00007e2c933d6b2d  push rdx
00007e2c933d6b2e  push rdi
00007e2c933d6b2f  push rsi
00007e2c933d6b30  push r8
00007e2c933d6b32  push r9
00007e2c933d6b34  push r10
00007e2c933d6b36  push r11
00007e2c933d6b38  sub rsp, 0xF0
00007e2c933d6b3f  vmovaps [rsp], xmm0
00007e2c933d6b44  vmovaps [rsp+0x10], xmm1
00007e2c933d6b4a  vmovaps [rsp+0x20], xmm2
00007e2c933d6b50  vmovaps [rsp+0x30], xmm3
00007e2c933d6b56  vmovaps [rsp+0x40], xmm4
00007e2c933d6b5c  vmovaps [rsp+0x50], xmm5
00007e2c933d6b62  vmovaps [rsp+0x60], xmm6
00007e2c933d6b68  vmovaps [rsp+0x70], xmm7
00007e2c933d6b6e  vmovaps [rsp+0x80], xmm8
00007e2c933d6b77  vmovaps [rsp+0x90], xmm10
00007e2c933d6b80  vmovaps [rsp+0xA0], xmm11
00007e2c933d6b89  vmovaps [rsp+0xB0], xmm12
00007e2c933d6b92  vmovaps [rsp+0xC0], xmm13
00007e2c933d6b9b  vmovaps [rsp+0xD0], xmm14
00007e2c933d6ba4  vmovaps [rsp+0xE0], xmm15
00007e2c933d6bad  sub rsp, 0x30
00007e2c933d6bb1  movaps [rsp], xmm9
00007e2c933d6bb6  movaps [rsp+0x10], xmm8
00007e2c933d6bbc  movaps [rsp+0x20], xmm10
00007e2c933d6bc2  lea rdi, [rsp]
00007e2c933d6bc6  mov esi, 0x00
00007e2c933d6bcb  mov rax, 0x5A263F1C7530
00007e2c933d6bd5  call rax
00007e2c933d6bd7  movaps xmm9, [rsp]
00007e2c933d6bdc  add rsp, 0x30
00007e2c933d6be0  vmovaps xmm0, [rsp]
00007e2c933d6be5  vmovaps xmm1, [rsp+0x10]
00007e2c933d6beb  vmovaps xmm2, [rsp+0x20]
00007e2c933d6bf1  vmovaps xmm3, [rsp+0x30]
00007e2c933d6bf7  vmovaps xmm4, [rsp+0x40]
00007e2c933d6bfd  vmovaps xmm5, [rsp+0x50]
00007e2c933d6c03  vmovaps xmm6, [rsp+0x60]
00007e2c933d6c09  vmovaps xmm7, [rsp+0x70]
00007e2c933d6c0f  vmovaps xmm8, [rsp+0x80]
00007e2c933d6c18  vmovaps xmm10, [rsp+0x90]
00007e2c933d6c21  vmovaps xmm11, [rsp+0xA0]
00007e2c933d6c2a  vmovaps xmm12, [rsp+0xB0]
00007e2c933d6c33  vmovaps xmm13, [rsp+0xC0]
00007e2c933d6c3c  vmovaps xmm14, [rsp+0xD0]
00007e2c933d6c45  vmovaps xmm15, [rsp+0xE0]
00007e2c933d6c4e  add rsp, 0xF0
00007e2c933d6c55  pop r11
00007e2c933d6c57  pop r10
00007e2c933d6c59  pop r9
00007e2c933d6c5b  pop r8
00007e2c933d6c5d  pop rsi
00007e2c933d6c5e  pop rdi
00007e2c933d6c5f  pop rdx
00007e2c933d6c60  pop rcx
00007e2c933d6c61  pop rax
00007e2c933d6c62  add rsp, 0x08
00007e2c933d6c66  jmp 0x00007E2C933D321C
00007e2c933d6c6b  sub rsp, 0x08
00007e2c933d6c6f  push rax
00007e2c933d6c70  push rcx
00007e2c933d6c71  push rdx
00007e2c933d6c72  push rdi
00007e2c933d6c73  push rsi
00007e2c933d6c74  push r8
00007e2c933d6c76  push r9
00007e2c933d6c78  push r10
00007e2c933d6c7a  push r11
00007e2c933d6c7c  sub rsp, 0xF0
00007e2c933d6c83  vmovaps [rsp], xmm0
00007e2c933d6c88  vmovaps [rsp+0x10], xmm1
00007e2c933d6c8e  vmovaps [rsp+0x20], xmm2
00007e2c933d6c94  vmovaps [rsp+0x30], xmm3
00007e2c933d6c9a  vmovaps [rsp+0x40], xmm4
00007e2c933d6ca0  vmovaps [rsp+0x50], xmm5
00007e2c933d6ca6  vmovaps [rsp+0x60], xmm6
00007e2c933d6cac  vmovaps [rsp+0x70], xmm7
00007e2c933d6cb2  vmovaps [rsp+0x80], xmm8
00007e2c933d6cbb  vmovaps [rsp+0x90], xmm9
00007e2c933d6cc4  vmovaps [rsp+0xA0], xmm11
00007e2c933d6ccd  vmovaps [rsp+0xB0], xmm12
00007e2c933d6cd6  vmovaps [rsp+0xC0], xmm13
00007e2c933d6cdf  vmovaps [rsp+0xD0], xmm14
00007e2c933d6ce8  vmovaps [rsp+0xE0], xmm15
00007e2c933d6cf1  sub rsp, 0x30
00007e2c933d6cf5  movaps [rsp], xmm10
00007e2c933d6cfa  movaps [rsp+0x10], xmm1
00007e2c933d6cff  movaps [rsp+0x20], xmm11
00007e2c933d6d05  lea rdi, [rsp]
00007e2c933d6d09  mov esi, 0x00
00007e2c933d6d0e  mov rax, 0x5A263F1C7530
00007e2c933d6d18  call rax
00007e2c933d6d1a  movaps xmm10, [rsp]
00007e2c933d6d1f  add rsp, 0x30
00007e2c933d6d23  vmovaps xmm0, [rsp]
00007e2c933d6d28  vmovaps xmm1, [rsp+0x10]
00007e2c933d6d2e  vmovaps xmm2, [rsp+0x20]
00007e2c933d6d34  vmovaps xmm3, [rsp+0x30]
00007e2c933d6d3a  vmovaps xmm4, [rsp+0x40]
00007e2c933d6d40  vmovaps xmm5, [rsp+0x50]
00007e2c933d6d46  vmovaps xmm6, [rsp+0x60]
00007e2c933d6d4c  vmovaps xmm7, [rsp+0x70]
00007e2c933d6d52  vmovaps xmm8, [rsp+0x80]
00007e2c933d6d5b  vmovaps xmm9, [rsp+0x90]
00007e2c933d6d64  vmovaps xmm11, [rsp+0xA0]
00007e2c933d6d6d  vmovaps xmm12, [rsp+0xB0]
00007e2c933d6d76  vmovaps xmm13, [rsp+0xC0]
00007e2c933d6d7f  vmovaps xmm14, [rsp+0xD0]
00007e2c933d6d88  vmovaps xmm15, [rsp+0xE0]
00007e2c933d6d91  add rsp, 0xF0
00007e2c933d6d98  pop r11
00007e2c933d6d9a  pop r10
00007e2c933d6d9c  pop r9
00007e2c933d6d9e  pop r8
00007e2c933d6da0  pop rsi
00007e2c933d6da1  pop rdi
00007e2c933d6da2  pop rdx
00007e2c933d6da3  pop rcx
00007e2c933d6da4  pop rax
00007e2c933d6da5  add rsp, 0x08
00007e2c933d6da9  jmp 0x00007E2C933D3237
00007e2c933d6dae  sub rsp, 0x08
00007e2c933d6db2  push rax
00007e2c933d6db3  push rcx
00007e2c933d6db4  push rdx
00007e2c933d6db5  push rdi
00007e2c933d6db6  push rsi
00007e2c933d6db7  push r8
00007e2c933d6db9  push r9
00007e2c933d6dbb  push r10
00007e2c933d6dbd  push r11
00007e2c933d6dbf  sub rsp, 0xF0
00007e2c933d6dc6  vmovaps [rsp], xmm0
00007e2c933d6dcb  vmovaps [rsp+0x10], xmm2
00007e2c933d6dd1  vmovaps [rsp+0x20], xmm3
00007e2c933d6dd7  vmovaps [rsp+0x30], xmm4
00007e2c933d6ddd  vmovaps [rsp+0x40], xmm5
00007e2c933d6de3  vmovaps [rsp+0x50], xmm6
00007e2c933d6de9  vmovaps [rsp+0x60], xmm7
00007e2c933d6def  vmovaps [rsp+0x70], xmm8
00007e2c933d6df5  vmovaps [rsp+0x80], xmm9
00007e2c933d6dfe  vmovaps [rsp+0x90], xmm10
00007e2c933d6e07  vmovaps [rsp+0xA0], xmm11
00007e2c933d6e10  vmovaps [rsp+0xB0], xmm12
00007e2c933d6e19  vmovaps [rsp+0xC0], xmm13
00007e2c933d6e22  vmovaps [rsp+0xD0], xmm14
00007e2c933d6e2b  vmovaps [rsp+0xE0], xmm15
00007e2c933d6e34  sub rsp, 0x30
00007e2c933d6e38  movaps [rsp], xmm1
00007e2c933d6e3c  movaps [rsp+0x10], xmm15
00007e2c933d6e42  movaps [rsp+0x20], xmm6
00007e2c933d6e47  lea rdi, [rsp]
00007e2c933d6e4b  mov esi, 0x00
00007e2c933d6e50  mov rax, 0x5A263F1C7530
00007e2c933d6e5a  call rax
00007e2c933d6e5c  movaps xmm1, [rsp]
00007e2c933d6e60  add rsp, 0x30
00007e2c933d6e64  vmovaps xmm0, [rsp]
00007e2c933d6e69  vmovaps xmm2, [rsp+0x10]
00007e2c933d6e6f  vmovaps xmm3, [rsp+0x20]
00007e2c933d6e75  vmovaps xmm4, [rsp+0x30]
00007e2c933d6e7b  vmovaps xmm5, [rsp+0x40]
00007e2c933d6e81  vmovaps xmm6, [rsp+0x50]
00007e2c933d6e87  vmovaps xmm7, [rsp+0x60]
00007e2c933d6e8d  vmovaps xmm8, [rsp+0x70]
00007e2c933d6e93  vmovaps xmm9, [rsp+0x80]
00007e2c933d6e9c  vmovaps xmm10, [rsp+0x90]
00007e2c933d6ea5  vmovaps xmm11, [rsp+0xA0]
00007e2c933d6eae  vmovaps xmm12, [rsp+0xB0]
00007e2c933d6eb7  vmovaps xmm13, [rsp+0xC0]
00007e2c933d6ec0  vmovaps xmm14, [rsp+0xD0]
00007e2c933d6ec9  vmovaps xmm15, [rsp+0xE0]
00007e2c933d6ed2  add rsp, 0xF0
00007e2c933d6ed9  pop r11
00007e2c933d6edb  pop r10
00007e2c933d6edd  pop r9
00007e2c933d6edf  pop r8
00007e2c933d6ee1  pop rsi
00007e2c933d6ee2  pop rdi
00007e2c933d6ee3  pop rdx
00007e2c933d6ee4  pop rcx
00007e2c933d6ee5  pop rax
00007e2c933d6ee6  add rsp, 0x08
00007e2c933d6eea  jmp 0x00007E2C933D3250
00007e2c933d6eef  sub rsp, 0x08
00007e2c933d6ef3  push rax
00007e2c933d6ef4  push rcx
00007e2c933d6ef5  push rdx
00007e2c933d6ef6  push rdi
00007e2c933d6ef7  push rsi
00007e2c933d6ef8  push r8
00007e2c933d6efa  push r9
00007e2c933d6efc  push r10
00007e2c933d6efe  push r11
00007e2c933d6f00  sub rsp, 0xF0
00007e2c933d6f07  vmovaps [rsp], xmm0
00007e2c933d6f0c  vmovaps [rsp+0x10], xmm1
00007e2c933d6f12  vmovaps [rsp+0x20], xmm2
00007e2c933d6f18  vmovaps [rsp+0x30], xmm3
00007e2c933d6f1e  vmovaps [rsp+0x40], xmm4
00007e2c933d6f24  vmovaps [rsp+0x50], xmm5
00007e2c933d6f2a  vmovaps [rsp+0x60], xmm6
00007e2c933d6f30  vmovaps [rsp+0x70], xmm7
00007e2c933d6f36  vmovaps [rsp+0x80], xmm8
00007e2c933d6f3f  vmovaps [rsp+0x90], xmm9
00007e2c933d6f48  vmovaps [rsp+0xA0], xmm10
00007e2c933d6f51  vmovaps [rsp+0xB0], xmm12
00007e2c933d6f5a  vmovaps [rsp+0xC0], xmm13
00007e2c933d6f63  vmovaps [rsp+0xD0], xmm14
00007e2c933d6f6c  vmovaps [rsp+0xE0], xmm15
00007e2c933d6f75  sub rsp, 0x30
00007e2c933d6f79  movaps [rsp], xmm11
00007e2c933d6f7e  movaps [rsp+0x10], xmm12
00007e2c933d6f84  movaps [rsp+0x20], xmm15
00007e2c933d6f8a  lea rdi, [rsp]
00007e2c933d6f8e  mov esi, 0x00
00007e2c933d6f93  mov rax, 0x5A263F1C7530
00007e2c933d6f9d  call rax
00007e2c933d6f9f  movaps xmm11, [rsp]
00007e2c933d6fa4  add rsp, 0x30
00007e2c933d6fa8  vmovaps xmm0, [rsp]
00007e2c933d6fad  vmovaps xmm1, [rsp+0x10]
00007e2c933d6fb3  vmovaps xmm2, [rsp+0x20]
00007e2c933d6fb9  vmovaps xmm3, [rsp+0x30]
00007e2c933d6fbf  vmovaps xmm4, [rsp+0x40]
00007e2c933d6fc5  vmovaps xmm5, [rsp+0x50]
00007e2c933d6fcb  vmovaps xmm6, [rsp+0x60]
00007e2c933d6fd1  vmovaps xmm7, [rsp+0x70]
00007e2c933d6fd7  vmovaps xmm8, [rsp+0x80]
00007e2c933d6fe0  vmovaps xmm9, [rsp+0x90]
00007e2c933d6fe9  vmovaps xmm10, [rsp+0xA0]
00007e2c933d6ff2  vmovaps xmm12, [rsp+0xB0]
00007e2c933d6ffb  vmovaps xmm13, [rsp+0xC0]
00007e2c933d7004  vmovaps xmm14, [rsp+0xD0]
00007e2c933d700d  vmovaps xmm15, [rsp+0xE0]
00007e2c933d7016  add rsp, 0xF0
00007e2c933d701d  pop r11
00007e2c933d701f  pop r10
00007e2c933d7021  pop r9
00007e2c933d7023  pop r8
00007e2c933d7025  pop rsi
00007e2c933d7026  pop rdi
00007e2c933d7027  pop rdx
00007e2c933d7028  pop rcx
00007e2c933d7029  pop rax
00007e2c933d702a  add rsp, 0x08
00007e2c933d702e  jmp 0x00007E2C933D327A
00007e2c933d7033  sub rsp, 0x08
00007e2c933d7037  push rax
00007e2c933d7038  push rcx
00007e2c933d7039  push rdx
00007e2c933d703a  push rdi
00007e2c933d703b  push rsi
00007e2c933d703c  push r8
00007e2c933d703e  push r9
00007e2c933d7040  push r10
00007e2c933d7042  push r11
00007e2c933d7044  sub rsp, 0xF0
00007e2c933d704b  vmovaps [rsp], xmm0
00007e2c933d7050  vmovaps [rsp+0x10], xmm1
00007e2c933d7056  vmovaps [rsp+0x20], xmm2
00007e2c933d705c  vmovaps [rsp+0x30], xmm3
00007e2c933d7062  vmovaps [rsp+0x40], xmm4
00007e2c933d7068  vmovaps [rsp+0x50], xmm5
00007e2c933d706e  vmovaps [rsp+0x60], xmm6
00007e2c933d7074  vmovaps [rsp+0x70], xmm7
00007e2c933d707a  vmovaps [rsp+0x80], xmm8
00007e2c933d7083  vmovaps [rsp+0x90], xmm9
00007e2c933d708c  vmovaps [rsp+0xA0], xmm10
00007e2c933d7095  vmovaps [rsp+0xB0], xmm11
00007e2c933d709e  vmovaps [rsp+0xC0], xmm13
00007e2c933d70a7  vmovaps [rsp+0xD0], xmm14
00007e2c933d70b0  vmovaps [rsp+0xE0], xmm15
00007e2c933d70b9  sub rsp, 0x30
00007e2c933d70bd  movaps [rsp], xmm12
00007e2c933d70c2  movaps [rsp+0x10], xmm8
00007e2c933d70c8  movaps [rsp+0x20], xmm15
00007e2c933d70ce  lea rdi, [rsp]
00007e2c933d70d2  mov esi, 0x00
00007e2c933d70d7  mov rax, 0x5A263F1C7530
00007e2c933d70e1  call rax
00007e2c933d70e3  movaps xmm12, [rsp]
00007e2c933d70e8  add rsp, 0x30
00007e2c933d70ec  vmovaps xmm0, [rsp]
00007e2c933d70f1  vmovaps xmm1, [rsp+0x10]
00007e2c933d70f7  vmovaps xmm2, [rsp+0x20]
00007e2c933d70fd  vmovaps xmm3, [rsp+0x30]
00007e2c933d7103  vmovaps xmm4, [rsp+0x40]
00007e2c933d7109  vmovaps xmm5, [rsp+0x50]
00007e2c933d710f  vmovaps xmm6, [rsp+0x60]
00007e2c933d7115  vmovaps xmm7, [rsp+0x70]
00007e2c933d711b  vmovaps xmm8, [rsp+0x80]
00007e2c933d7124  vmovaps xmm9, [rsp+0x90]
00007e2c933d712d  vmovaps xmm10, [rsp+0xA0]
00007e2c933d7136  vmovaps xmm11, [rsp+0xB0]
00007e2c933d713f  vmovaps xmm13, [rsp+0xC0]
00007e2c933d7148  vmovaps xmm14, [rsp+0xD0]
00007e2c933d7151  vmovaps xmm15, [rsp+0xE0]
00007e2c933d715a  add rsp, 0xF0
00007e2c933d7161  pop r11
00007e2c933d7163  pop r10
00007e2c933d7165  pop r9
00007e2c933d7167  pop r8
00007e2c933d7169  pop rsi
00007e2c933d716a  pop rdi
00007e2c933d716b  pop rdx
00007e2c933d716c  pop rcx
00007e2c933d716d  pop rax
00007e2c933d716e  add rsp, 0x08
00007e2c933d7172  jmp 0x00007E2C933D32A9
00007e2c933d7177  sub rsp, 0x08
00007e2c933d717b  push rax
00007e2c933d717c  push rcx
00007e2c933d717d  push rdx
00007e2c933d717e  push rdi
00007e2c933d717f  push rsi
00007e2c933d7180  push r8
00007e2c933d7182  push r9
00007e2c933d7184  push r10
00007e2c933d7186  push r11
00007e2c933d7188  sub rsp, 0xF0
00007e2c933d718f  vmovaps [rsp], xmm0
00007e2c933d7194  vmovaps [rsp+0x10], xmm1
00007e2c933d719a  vmovaps [rsp+0x20], xmm2
00007e2c933d71a0  vmovaps [rsp+0x30], xmm3
00007e2c933d71a6  vmovaps [rsp+0x40], xmm4
00007e2c933d71ac  vmovaps [rsp+0x50], xmm5
00007e2c933d71b2  vmovaps [rsp+0x60], xmm6
00007e2c933d71b8  vmovaps [rsp+0x70], xmm7
00007e2c933d71be  vmovaps [rsp+0x80], xmm9
00007e2c933d71c7  vmovaps [rsp+0x90], xmm10
00007e2c933d71d0  vmovaps [rsp+0xA0], xmm11
00007e2c933d71d9  vmovaps [rsp+0xB0], xmm12
00007e2c933d71e2  vmovaps [rsp+0xC0], xmm13
00007e2c933d71eb  vmovaps [rsp+0xD0], xmm14
00007e2c933d71f4  vmovaps [rsp+0xE0], xmm15
00007e2c933d71fd  sub rsp, 0x30
00007e2c933d7201  movaps [rsp], xmm8
00007e2c933d7206  movaps [rsp+0x10], xmm7
00007e2c933d720b  movaps [rsp+0x20], xmm15
00007e2c933d7211  lea rdi, [rsp]
00007e2c933d7215  mov esi, 0x00
00007e2c933d721a  mov rax, 0x5A263F1C7530
00007e2c933d7224  call rax
00007e2c933d7226  movaps xmm8, [rsp]
00007e2c933d722b  add rsp, 0x30
00007e2c933d722f  vmovaps xmm0, [rsp]
00007e2c933d7234  vmovaps xmm1, [rsp+0x10]
00007e2c933d723a  vmovaps xmm2, [rsp+0x20]
00007e2c933d7240  vmovaps xmm3, [rsp+0x30]
00007e2c933d7246  vmovaps xmm4, [rsp+0x40]
00007e2c933d724c  vmovaps xmm5, [rsp+0x50]
00007e2c933d7252  vmovaps xmm6, [rsp+0x60]
00007e2c933d7258  vmovaps xmm7, [rsp+0x70]
00007e2c933d725e  vmovaps xmm9, [rsp+0x80]
00007e2c933d7267  vmovaps xmm10, [rsp+0x90]
00007e2c933d7270  vmovaps xmm11, [rsp+0xA0]
00007e2c933d7279  vmovaps xmm12, [rsp+0xB0]
00007e2c933d7282  vmovaps xmm13, [rsp+0xC0]
00007e2c933d728b  vmovaps xmm14, [rsp+0xD0]
00007e2c933d7294  vmovaps xmm15, [rsp+0xE0]
00007e2c933d729d  add rsp, 0xF0
00007e2c933d72a4  pop r11
00007e2c933d72a6  pop r10
00007e2c933d72a8  pop r9
00007e2c933d72aa  pop r8
00007e2c933d72ac  pop rsi
00007e2c933d72ad  pop rdi
00007e2c933d72ae  pop rdx
00007e2c933d72af  pop rcx
00007e2c933d72b0  pop rax
00007e2c933d72b1  add rsp, 0x08
00007e2c933d72b5  jmp 0x00007E2C933D32CF
00007e2c933d72ba  sub rsp, 0x08
00007e2c933d72be  push rax
00007e2c933d72bf  push rcx
00007e2c933d72c0  push rdx
00007e2c933d72c1  push rdi
00007e2c933d72c2  push rsi
00007e2c933d72c3  push r8
00007e2c933d72c5  push r9
00007e2c933d72c7  push r10
00007e2c933d72c9  push r11
00007e2c933d72cb  sub rsp, 0xF0
00007e2c933d72d2  vmovaps [rsp], xmm0
00007e2c933d72d7  vmovaps [rsp+0x10], xmm1
00007e2c933d72dd  vmovaps [rsp+0x20], xmm2
00007e2c933d72e3  vmovaps [rsp+0x30], xmm3
00007e2c933d72e9  vmovaps [rsp+0x40], xmm4
00007e2c933d72ef  vmovaps [rsp+0x50], xmm5
00007e2c933d72f5  vmovaps [rsp+0x60], xmm6
00007e2c933d72fb  vmovaps [rsp+0x70], xmm7
00007e2c933d7301  vmovaps [rsp+0x80], xmm8
00007e2c933d730a  vmovaps [rsp+0x90], xmm9
00007e2c933d7313  vmovaps [rsp+0xA0], xmm10
00007e2c933d731c  vmovaps [rsp+0xB0], xmm11
00007e2c933d7325  vmovaps [rsp+0xC0], xmm12
00007e2c933d732e  vmovaps [rsp+0xD0], xmm13
00007e2c933d7337  vmovaps [rsp+0xE0], xmm14
00007e2c933d7340  sub rsp, 0x30
00007e2c933d7344  movaps [rsp], xmm15
00007e2c933d7349  movaps [rsp+0x10], xmm14
00007e2c933d734f  movaps [rsp+0x20], xmm9
00007e2c933d7355  lea rdi, [rsp]
00007e2c933d7359  mov esi, 0x00
00007e2c933d735e  mov rax, 0x5A263F1C7530
00007e2c933d7368  call rax
00007e2c933d736a  movaps xmm15, [rsp]
00007e2c933d736f  add rsp, 0x30
00007e2c933d7373  vmovaps xmm0, [rsp]
00007e2c933d7378  vmovaps xmm1, [rsp+0x10]
00007e2c933d737e  vmovaps xmm2, [rsp+0x20]
00007e2c933d7384  vmovaps xmm3, [rsp+0x30]
00007e2c933d738a  vmovaps xmm4, [rsp+0x40]
00007e2c933d7390  vmovaps xmm5, [rsp+0x50]
00007e2c933d7396  vmovaps xmm6, [rsp+0x60]
00007e2c933d739c  vmovaps xmm7, [rsp+0x70]
00007e2c933d73a2  vmovaps xmm8, [rsp+0x80]
00007e2c933d73ab  vmovaps xmm9, [rsp+0x90]
00007e2c933d73b4  vmovaps xmm10, [rsp+0xA0]
00007e2c933d73bd  vmovaps xmm11, [rsp+0xB0]
00007e2c933d73c6  vmovaps xmm12, [rsp+0xC0]
00007e2c933d73cf  vmovaps xmm13, [rsp+0xD0]
00007e2c933d73d8  vmovaps xmm14, [rsp+0xE0]
00007e2c933d73e1  add rsp, 0xF0
00007e2c933d73e8  pop r11
00007e2c933d73ea  pop r10
00007e2c933d73ec  pop r9
00007e2c933d73ee  pop r8
00007e2c933d73f0  pop rsi
00007e2c933d73f1  pop rdi
00007e2c933d73f2  pop rdx
00007e2c933d73f3  pop rcx
00007e2c933d73f4  pop rax
00007e2c933d73f5  add rsp, 0x08
00007e2c933d73f9  jmp 0x00007E2C933D32E9
00007e2c933d73fe  sub rsp, 0x08
00007e2c933d7402  push rax
00007e2c933d7403  push rcx
00007e2c933d7404  push rdx
00007e2c933d7405  push rdi
00007e2c933d7406  push rsi
00007e2c933d7407  push r8
00007e2c933d7409  push r9
00007e2c933d740b  push r10
00007e2c933d740d  push r11
00007e2c933d740f  sub rsp, 0xF0
00007e2c933d7416  vmovaps [rsp], xmm0
00007e2c933d741b  vmovaps [rsp+0x10], xmm1
00007e2c933d7421  vmovaps [rsp+0x20], xmm2
00007e2c933d7427  vmovaps [rsp+0x30], xmm3
00007e2c933d742d  vmovaps [rsp+0x40], xmm4
00007e2c933d7433  vmovaps [rsp+0x50], xmm5
00007e2c933d7439  vmovaps [rsp+0x60], xmm6
00007e2c933d743f  vmovaps [rsp+0x70], xmm7
00007e2c933d7445  vmovaps [rsp+0x80], xmm8
00007e2c933d744e  vmovaps [rsp+0x90], xmm10
00007e2c933d7457  vmovaps [rsp+0xA0], xmm11
00007e2c933d7460  vmovaps [rsp+0xB0], xmm12
00007e2c933d7469  vmovaps [rsp+0xC0], xmm13
00007e2c933d7472  vmovaps [rsp+0xD0], xmm14
00007e2c933d747b  vmovaps [rsp+0xE0], xmm15
00007e2c933d7484  sub rsp, 0x30
00007e2c933d7488  movaps [rsp], xmm9
00007e2c933d748d  movaps [rsp+0x10], xmm7
00007e2c933d7492  movaps [rsp+0x20], xmm14
00007e2c933d7498  lea rdi, [rsp]
00007e2c933d749c  mov esi, 0x00
00007e2c933d74a1  mov rax, 0x5A263F1C7530
00007e2c933d74ab  call rax
00007e2c933d74ad  movaps xmm9, [rsp]
00007e2c933d74b2  add rsp, 0x30
00007e2c933d74b6  vmovaps xmm0, [rsp]
00007e2c933d74bb  vmovaps xmm1, [rsp+0x10]
00007e2c933d74c1  vmovaps xmm2, [rsp+0x20]
00007e2c933d74c7  vmovaps xmm3, [rsp+0x30]
00007e2c933d74cd  vmovaps xmm4, [rsp+0x40]
00007e2c933d74d3  vmovaps xmm5, [rsp+0x50]
00007e2c933d74d9  vmovaps xmm6, [rsp+0x60]
00007e2c933d74df  vmovaps xmm7, [rsp+0x70]
00007e2c933d74e5  vmovaps xmm8, [rsp+0x80]
00007e2c933d74ee  vmovaps xmm10, [rsp+0x90]
00007e2c933d74f7  vmovaps xmm11, [rsp+0xA0]
00007e2c933d7500  vmovaps xmm12, [rsp+0xB0]
00007e2c933d7509  vmovaps xmm13, [rsp+0xC0]
00007e2c933d7512  vmovaps xmm14, [rsp+0xD0]
00007e2c933d751b  vmovaps xmm15, [rsp+0xE0]
00007e2c933d7524  add rsp, 0xF0
00007e2c933d752b  pop r11
00007e2c933d752d  pop r10
00007e2c933d752f  pop r9
00007e2c933d7531  pop r8
00007e2c933d7533  pop rsi
00007e2c933d7534  pop rdi
00007e2c933d7535  pop rdx
00007e2c933d7536  pop rcx
00007e2c933d7537  pop rax
00007e2c933d7538  add rsp, 0x08
00007e2c933d753c  jmp 0x00007E2C933D3318
00007e2c933d7541  sub rsp, 0x08
00007e2c933d7545  push rax
00007e2c933d7546  push rcx
00007e2c933d7547  push rdx
00007e2c933d7548  push rdi
00007e2c933d7549  push rsi
00007e2c933d754a  push r8
00007e2c933d754c  push r9
00007e2c933d754e  push r10
00007e2c933d7550  push r11
00007e2c933d7552  sub rsp, 0xF0
00007e2c933d7559  vmovaps [rsp], xmm0
00007e2c933d755e  vmovaps [rsp+0x10], xmm1
00007e2c933d7564  vmovaps [rsp+0x20], xmm2
00007e2c933d756a  vmovaps [rsp+0x30], xmm3
00007e2c933d7570  vmovaps [rsp+0x40], xmm4
00007e2c933d7576  vmovaps [rsp+0x50], xmm5
00007e2c933d757c  vmovaps [rsp+0x60], xmm6
00007e2c933d7582  vmovaps [rsp+0x70], xmm7
00007e2c933d7588  vmovaps [rsp+0x80], xmm8
00007e2c933d7591  vmovaps [rsp+0x90], xmm9
00007e2c933d759a  vmovaps [rsp+0xA0], xmm10
00007e2c933d75a3  vmovaps [rsp+0xB0], xmm11
00007e2c933d75ac  vmovaps [rsp+0xC0], xmm12
00007e2c933d75b5  vmovaps [rsp+0xD0], xmm13
00007e2c933d75be  vmovaps [rsp+0xE0], xmm15
00007e2c933d75c7  sub rsp, 0x30
00007e2c933d75cb  movaps [rsp], xmm14
00007e2c933d75d0  movaps [rsp+0x10], xmm13
00007e2c933d75d6  movaps [rsp+0x20], xmm11
00007e2c933d75dc  lea rdi, [rsp]
00007e2c933d75e0  mov esi, 0x00
00007e2c933d75e5  mov rax, 0x5A263F1C7530
00007e2c933d75ef  call rax
00007e2c933d75f1  movaps xmm14, [rsp]
00007e2c933d75f6  add rsp, 0x30
00007e2c933d75fa  vmovaps xmm0, [rsp]
00007e2c933d75ff  vmovaps xmm1, [rsp+0x10]
00007e2c933d7605  vmovaps xmm2, [rsp+0x20]
00007e2c933d760b  vmovaps xmm3, [rsp+0x30]
00007e2c933d7611  vmovaps xmm4, [rsp+0x40]
00007e2c933d7617  vmovaps xmm5, [rsp+0x50]
00007e2c933d761d  vmovaps xmm6, [rsp+0x60]
00007e2c933d7623  vmovaps xmm7, [rsp+0x70]
00007e2c933d7629  vmovaps xmm8, [rsp+0x80]
00007e2c933d7632  vmovaps xmm9, [rsp+0x90]
00007e2c933d763b  vmovaps xmm10, [rsp+0xA0]
00007e2c933d7644  vmovaps xmm11, [rsp+0xB0]
00007e2c933d764d  vmovaps xmm12, [rsp+0xC0]
00007e2c933d7656  vmovaps xmm13, [rsp+0xD0]
00007e2c933d765f  vmovaps xmm15, [rsp+0xE0]
00007e2c933d7668  add rsp, 0xF0
00007e2c933d766f  pop r11
00007e2c933d7671  pop r10
00007e2c933d7673  pop r9
00007e2c933d7675  pop r8
00007e2c933d7677  pop rsi
00007e2c933d7678  pop rdi
00007e2c933d7679  pop rdx
00007e2c933d767a  pop rcx
00007e2c933d767b  pop rax
00007e2c933d767c  add rsp, 0x08
00007e2c933d7680  jmp 0x00007E2C933D3332
00007e2c933d7685  sub rsp, 0x08
00007e2c933d7689  push rax
00007e2c933d768a  push rcx
00007e2c933d768b  push rdx
00007e2c933d768c  push rdi
00007e2c933d768d  push rsi
00007e2c933d768e  push r8
00007e2c933d7690  push r9
00007e2c933d7692  push r10
00007e2c933d7694  push r11
00007e2c933d7696  sub rsp, 0xF0
00007e2c933d769d  vmovaps [rsp], xmm0
00007e2c933d76a2  vmovaps [rsp+0x10], xmm1
00007e2c933d76a8  vmovaps [rsp+0x20], xmm2
00007e2c933d76ae  vmovaps [rsp+0x30], xmm3
00007e2c933d76b4  vmovaps [rsp+0x40], xmm4
00007e2c933d76ba  vmovaps [rsp+0x50], xmm5
00007e2c933d76c0  vmovaps [rsp+0x60], xmm6
00007e2c933d76c6  vmovaps [rsp+0x70], xmm7
00007e2c933d76cc  vmovaps [rsp+0x80], xmm8
00007e2c933d76d5  vmovaps [rsp+0x90], xmm9
00007e2c933d76de  vmovaps [rsp+0xA0], xmm10
00007e2c933d76e7  vmovaps [rsp+0xB0], xmm12
00007e2c933d76f0  vmovaps [rsp+0xC0], xmm13
00007e2c933d76f9  vmovaps [rsp+0xD0], xmm14
00007e2c933d7702  vmovaps [rsp+0xE0], xmm15
00007e2c933d770b  sub rsp, 0x30
00007e2c933d770f  movaps [rsp], xmm11
00007e2c933d7714  movaps [rsp+0x10], xmm7
00007e2c933d7719  movaps [rsp+0x20], xmm13
00007e2c933d771f  lea rdi, [rsp]
00007e2c933d7723  mov esi, 0x00
00007e2c933d7728  mov rax, 0x5A263F1C7530
00007e2c933d7732  call rax
00007e2c933d7734  movaps xmm11, [rsp]
00007e2c933d7739  add rsp, 0x30
00007e2c933d773d  vmovaps xmm0, [rsp]
00007e2c933d7742  vmovaps xmm1, [rsp+0x10]
00007e2c933d7748  vmovaps xmm2, [rsp+0x20]
00007e2c933d774e  vmovaps xmm3, [rsp+0x30]
00007e2c933d7754  vmovaps xmm4, [rsp+0x40]
00007e2c933d775a  vmovaps xmm5, [rsp+0x50]
00007e2c933d7760  vmovaps xmm6, [rsp+0x60]
00007e2c933d7766  vmovaps xmm7, [rsp+0x70]
00007e2c933d776c  vmovaps xmm8, [rsp+0x80]
00007e2c933d7775  vmovaps xmm9, [rsp+0x90]
00007e2c933d777e  vmovaps xmm10, [rsp+0xA0]
00007e2c933d7787  vmovaps xmm12, [rsp+0xB0]
00007e2c933d7790  vmovaps xmm13, [rsp+0xC0]
00007e2c933d7799  vmovaps xmm14, [rsp+0xD0]
00007e2c933d77a2  vmovaps xmm15, [rsp+0xE0]
00007e2c933d77ab  add rsp, 0xF0
00007e2c933d77b2  pop r11
00007e2c933d77b4  pop r10
00007e2c933d77b6  pop r9
00007e2c933d77b8  pop r8
00007e2c933d77ba  pop rsi
00007e2c933d77bb  pop rdi
00007e2c933d77bc  pop rdx
00007e2c933d77bd  pop rcx
00007e2c933d77be  pop rax
00007e2c933d77bf  add rsp, 0x08
00007e2c933d77c3  jmp 0x00007E2C933D335E
00007e2c933d77c8  sub rsp, 0x08
00007e2c933d77cc  push rax
00007e2c933d77cd  push rcx
00007e2c933d77ce  push rdx
00007e2c933d77cf  push rdi
00007e2c933d77d0  push rsi
00007e2c933d77d1  push r8
00007e2c933d77d3  push r9
00007e2c933d77d5  push r10
00007e2c933d77d7  push r11
00007e2c933d77d9  sub rsp, 0xF0
00007e2c933d77e0  vmovaps [rsp], xmm0
00007e2c933d77e5  vmovaps [rsp+0x10], xmm1
00007e2c933d77eb  vmovaps [rsp+0x20], xmm2
00007e2c933d77f1  vmovaps [rsp+0x30], xmm3
00007e2c933d77f7  vmovaps [rsp+0x40], xmm4
00007e2c933d77fd  vmovaps [rsp+0x50], xmm5
00007e2c933d7803  vmovaps [rsp+0x60], xmm6
00007e2c933d7809  vmovaps [rsp+0x70], xmm7
00007e2c933d780f  vmovaps [rsp+0x80], xmm8
00007e2c933d7818  vmovaps [rsp+0x90], xmm9
00007e2c933d7821  vmovaps [rsp+0xA0], xmm10
00007e2c933d782a  vmovaps [rsp+0xB0], xmm11
00007e2c933d7833  vmovaps [rsp+0xC0], xmm12
00007e2c933d783c  vmovaps [rsp+0xD0], xmm14
00007e2c933d7845  vmovaps [rsp+0xE0], xmm15
00007e2c933d784e  sub rsp, 0x30
00007e2c933d7852  movaps [rsp], xmm13
00007e2c933d7857  movaps [rsp+0x10], xmm10
00007e2c933d785d  movaps [rsp+0x20], xmm12
00007e2c933d7863  lea rdi, [rsp]
00007e2c933d7867  mov esi, 0x00
00007e2c933d786c  mov rax, 0x5A263F1C7530
00007e2c933d7876  call rax
00007e2c933d7878  movaps xmm13, [rsp]
00007e2c933d787d  add rsp, 0x30
00007e2c933d7881  vmovaps xmm0, [rsp]
00007e2c933d7886  vmovaps xmm1, [rsp+0x10]
00007e2c933d788c  vmovaps xmm2, [rsp+0x20]
00007e2c933d7892  vmovaps xmm3, [rsp+0x30]
00007e2c933d7898  vmovaps xmm4, [rsp+0x40]
00007e2c933d789e  vmovaps xmm5, [rsp+0x50]
00007e2c933d78a4  vmovaps xmm6, [rsp+0x60]
00007e2c933d78aa  vmovaps xmm7, [rsp+0x70]
00007e2c933d78b0  vmovaps xmm8, [rsp+0x80]
00007e2c933d78b9  vmovaps xmm9, [rsp+0x90]
00007e2c933d78c2  vmovaps xmm10, [rsp+0xA0]
00007e2c933d78cb  vmovaps xmm11, [rsp+0xB0]
00007e2c933d78d4  vmovaps xmm12, [rsp+0xC0]
00007e2c933d78dd  vmovaps xmm14, [rsp+0xD0]
00007e2c933d78e6  vmovaps xmm15, [rsp+0xE0]
00007e2c933d78ef  add rsp, 0xF0
00007e2c933d78f6  pop r11
00007e2c933d78f8  pop r10
00007e2c933d78fa  pop r9
00007e2c933d78fc  pop r8
00007e2c933d78fe  pop rsi
00007e2c933d78ff  pop rdi
00007e2c933d7900  pop rdx
00007e2c933d7901  pop rcx
00007e2c933d7902  pop rax
00007e2c933d7903  add rsp, 0x08
00007e2c933d7907  jmp 0x00007E2C933D3378
00007e2c933d790c  sub rsp, 0x08
00007e2c933d7910  push rax
00007e2c933d7911  push rcx
00007e2c933d7912  push rdx
00007e2c933d7913  push rdi
00007e2c933d7914  push rsi
00007e2c933d7915  push r8
00007e2c933d7917  push r9
00007e2c933d7919  push r10
00007e2c933d791b  push r11
00007e2c933d791d  sub rsp, 0xF0
00007e2c933d7924  vmovaps [rsp], xmm0
00007e2c933d7929  vmovaps [rsp+0x10], xmm1
00007e2c933d792f  vmovaps [rsp+0x20], xmm2
00007e2c933d7935  vmovaps [rsp+0x30], xmm3
00007e2c933d793b  vmovaps [rsp+0x40], xmm4
00007e2c933d7941  vmovaps [rsp+0x50], xmm5
00007e2c933d7947  vmovaps [rsp+0x60], xmm6
00007e2c933d794d  vmovaps [rsp+0x70], xmm7
00007e2c933d7953  vmovaps [rsp+0x80], xmm8
00007e2c933d795c  vmovaps [rsp+0x90], xmm9
00007e2c933d7965  vmovaps [rsp+0xA0], xmm11
00007e2c933d796e  vmovaps [rsp+0xB0], xmm12
00007e2c933d7977  vmovaps [rsp+0xC0], xmm13
00007e2c933d7980  vmovaps [rsp+0xD0], xmm14
00007e2c933d7989  vmovaps [rsp+0xE0], xmm15
00007e2c933d7992  sub rsp, 0x30
00007e2c933d7996  movaps [rsp], xmm10
00007e2c933d799b  movaps [rsp+0x10], xmm7
00007e2c933d79a0  movaps [rsp+0x20], xmm12
00007e2c933d79a6  lea rdi, [rsp]
00007e2c933d79aa  mov esi, 0x00
00007e2c933d79af  mov rax, 0x5A263F1C7530
00007e2c933d79b9  call rax
00007e2c933d79bb  movaps xmm10, [rsp]
00007e2c933d79c0  add rsp, 0x30
00007e2c933d79c4  vmovaps xmm0, [rsp]
00007e2c933d79c9  vmovaps xmm1, [rsp+0x10]
00007e2c933d79cf  vmovaps xmm2, [rsp+0x20]
00007e2c933d79d5  vmovaps xmm3, [rsp+0x30]
00007e2c933d79db  vmovaps xmm4, [rsp+0x40]
00007e2c933d79e1  vmovaps xmm5, [rsp+0x50]
00007e2c933d79e7  vmovaps xmm6, [rsp+0x60]
00007e2c933d79ed  vmovaps xmm7, [rsp+0x70]
00007e2c933d79f3  vmovaps xmm8, [rsp+0x80]
00007e2c933d79fc  vmovaps xmm9, [rsp+0x90]
00007e2c933d7a05  vmovaps xmm11, [rsp+0xA0]
00007e2c933d7a0e  vmovaps xmm12, [rsp+0xB0]
00007e2c933d7a17  vmovaps xmm13, [rsp+0xC0]
00007e2c933d7a20  vmovaps xmm14, [rsp+0xD0]
00007e2c933d7a29  vmovaps xmm15, [rsp+0xE0]
00007e2c933d7a32  add rsp, 0xF0
00007e2c933d7a39  pop r11
00007e2c933d7a3b  pop r10
00007e2c933d7a3d  pop r9
00007e2c933d7a3f  pop r8
00007e2c933d7a41  pop rsi
00007e2c933d7a42  pop rdi
00007e2c933d7a43  pop rdx
00007e2c933d7a44  pop rcx
00007e2c933d7a45  pop rax
00007e2c933d7a46  add rsp, 0x08
00007e2c933d7a4a  jmp 0x00007E2C933D33A4
00007e2c933d7a4f  sub rsp, 0x08
00007e2c933d7a53  push rax
00007e2c933d7a54  push rcx
00007e2c933d7a55  push rdx
00007e2c933d7a56  push rdi
00007e2c933d7a57  push rsi
00007e2c933d7a58  push r8
00007e2c933d7a5a  push r9
00007e2c933d7a5c  push r10
00007e2c933d7a5e  push r11
00007e2c933d7a60  sub rsp, 0xF0
00007e2c933d7a67  vmovaps [rsp], xmm0
00007e2c933d7a6c  vmovaps [rsp+0x10], xmm1
00007e2c933d7a72  vmovaps [rsp+0x20], xmm2
00007e2c933d7a78  vmovaps [rsp+0x30], xmm3
00007e2c933d7a7e  vmovaps [rsp+0x40], xmm4
00007e2c933d7a84  vmovaps [rsp+0x50], xmm5
00007e2c933d7a8a  vmovaps [rsp+0x60], xmm6
00007e2c933d7a90  vmovaps [rsp+0x70], xmm7
00007e2c933d7a96  vmovaps [rsp+0x80], xmm8
00007e2c933d7a9f  vmovaps [rsp+0x90], xmm9
00007e2c933d7aa8  vmovaps [rsp+0xA0], xmm10
00007e2c933d7ab1  vmovaps [rsp+0xB0], xmm11
00007e2c933d7aba  vmovaps [rsp+0xC0], xmm13
00007e2c933d7ac3  vmovaps [rsp+0xD0], xmm14
00007e2c933d7acc  vmovaps [rsp+0xE0], xmm15
00007e2c933d7ad5  sub rsp, 0x30
00007e2c933d7ad9  movaps [rsp], xmm12
00007e2c933d7ade  movaps [rsp+0x10], xmm1
00007e2c933d7ae3  movaps [rsp+0x20], xmm8
00007e2c933d7ae9  lea rdi, [rsp]
00007e2c933d7aed  mov esi, 0x00
00007e2c933d7af2  mov rax, 0x5A263F1C7530
00007e2c933d7afc  call rax
00007e2c933d7afe  movaps xmm12, [rsp]
00007e2c933d7b03  add rsp, 0x30
00007e2c933d7b07  vmovaps xmm0, [rsp]
00007e2c933d7b0c  vmovaps xmm1, [rsp+0x10]
00007e2c933d7b12  vmovaps xmm2, [rsp+0x20]
00007e2c933d7b18  vmovaps xmm3, [rsp+0x30]
00007e2c933d7b1e  vmovaps xmm4, [rsp+0x40]
00007e2c933d7b24  vmovaps xmm5, [rsp+0x50]
00007e2c933d7b2a  vmovaps xmm6, [rsp+0x60]
00007e2c933d7b30  vmovaps xmm7, [rsp+0x70]
00007e2c933d7b36  vmovaps xmm8, [rsp+0x80]
00007e2c933d7b3f  vmovaps xmm9, [rsp+0x90]
00007e2c933d7b48  vmovaps xmm10, [rsp+0xA0]
00007e2c933d7b51  vmovaps xmm11, [rsp+0xB0]
00007e2c933d7b5a  vmovaps xmm13, [rsp+0xC0]
00007e2c933d7b63  vmovaps xmm14, [rsp+0xD0]
00007e2c933d7b6c  vmovaps xmm15, [rsp+0xE0]
00007e2c933d7b75  add rsp, 0xF0
00007e2c933d7b7c  pop r11
00007e2c933d7b7e  pop r10
00007e2c933d7b80  pop r9
00007e2c933d7b82  pop r8
00007e2c933d7b84  pop rsi
00007e2c933d7b85  pop rdi
00007e2c933d7b86  pop rdx
00007e2c933d7b87  pop rcx
00007e2c933d7b88  pop rax
00007e2c933d7b89  add rsp, 0x08
00007e2c933d7b8d  jmp 0x00007E2C933D33BE
00007e2c933d7b92  call 0x00007E2C931FF430
00007e2c933d7b97  jmp 0x00007E2C933D33C8
00007e2c933d7b9c  sub rsp, 0x08
00007e2c933d7ba0  push rax
00007e2c933d7ba1  push rcx
00007e2c933d7ba2  push rdx
00007e2c933d7ba3  push rdi
00007e2c933d7ba4  push rsi
00007e2c933d7ba5  push r8
00007e2c933d7ba7  push r9
00007e2c933d7ba9  push r10
00007e2c933d7bab  push r11
00007e2c933d7bad  sub rsp, 0xF0
00007e2c933d7bb4  vmovaps [rsp], xmm0
00007e2c933d7bb9  vmovaps [rsp+0x10], xmm1
00007e2c933d7bbf  vmovaps [rsp+0x20], xmm2
00007e2c933d7bc5  vmovaps [rsp+0x30], xmm3
00007e2c933d7bcb  vmovaps [rsp+0x40], xmm4
00007e2c933d7bd1  vmovaps [rsp+0x50], xmm5
00007e2c933d7bd7  vmovaps [rsp+0x60], xmm6
00007e2c933d7bdd  vmovaps [rsp+0x70], xmm7
00007e2c933d7be3  vmovaps [rsp+0x80], xmm9
00007e2c933d7bec  vmovaps [rsp+0x90], xmm10
00007e2c933d7bf5  vmovaps [rsp+0xA0], xmm11
00007e2c933d7bfe  vmovaps [rsp+0xB0], xmm12
00007e2c933d7c07  vmovaps [rsp+0xC0], xmm13
00007e2c933d7c10  vmovaps [rsp+0xD0], xmm14
00007e2c933d7c19  vmovaps [rsp+0xE0], xmm15
00007e2c933d7c22  sub rsp, 0x30
00007e2c933d7c26  movaps [rsp], xmm8
00007e2c933d7c2b  movaps [rsp+0x10], xmm15
00007e2c933d7c31  movaps [rsp+0x20], xmm9
00007e2c933d7c37  lea rdi, [rsp]
00007e2c933d7c3b  mov esi, 0x00
00007e2c933d7c40  mov rax, 0x5A263F1C7530
00007e2c933d7c4a  call rax
00007e2c933d7c4c  movaps xmm8, [rsp]
00007e2c933d7c51  add rsp, 0x30
00007e2c933d7c55  vmovaps xmm0, [rsp]
00007e2c933d7c5a  vmovaps xmm1, [rsp+0x10]
00007e2c933d7c60  vmovaps xmm2, [rsp+0x20]
00007e2c933d7c66  vmovaps xmm3, [rsp+0x30]
00007e2c933d7c6c  vmovaps xmm4, [rsp+0x40]
00007e2c933d7c72  vmovaps xmm5, [rsp+0x50]
00007e2c933d7c78  vmovaps xmm6, [rsp+0x60]
00007e2c933d7c7e  vmovaps xmm7, [rsp+0x70]
00007e2c933d7c84  vmovaps xmm9, [rsp+0x80]
00007e2c933d7c8d  vmovaps xmm10, [rsp+0x90]
00007e2c933d7c96  vmovaps xmm11, [rsp+0xA0]
00007e2c933d7c9f  vmovaps xmm12, [rsp+0xB0]
00007e2c933d7ca8  vmovaps xmm13, [rsp+0xC0]
00007e2c933d7cb1  vmovaps xmm14, [rsp+0xD0]
00007e2c933d7cba  vmovaps xmm15, [rsp+0xE0]
00007e2c933d7cc3  add rsp, 0xF0
00007e2c933d7cca  pop r11
00007e2c933d7ccc  pop r10
00007e2c933d7cce  pop r9
00007e2c933d7cd0  pop r8
00007e2c933d7cd2  pop rsi
00007e2c933d7cd3  pop rdi
00007e2c933d7cd4  pop rdx
00007e2c933d7cd5  pop rcx
00007e2c933d7cd6  pop rax
00007e2c933d7cd7  add rsp, 0x08
00007e2c933d7cdb  jmp 0x00007E2C933D33EA
00007e2c933d7ce0  sub rsp, 0x08
00007e2c933d7ce4  push rax
00007e2c933d7ce5  push rcx
00007e2c933d7ce6  push rdx
00007e2c933d7ce7  push rdi
00007e2c933d7ce8  push rsi
00007e2c933d7ce9  push r8
00007e2c933d7ceb  push r9
00007e2c933d7ced  push r10
00007e2c933d7cef  push r11
00007e2c933d7cf1  sub rsp, 0xF0
00007e2c933d7cf8  vmovaps [rsp], xmm0
00007e2c933d7cfd  vmovaps [rsp+0x10], xmm1
00007e2c933d7d03  vmovaps [rsp+0x20], xmm2
00007e2c933d7d09  vmovaps [rsp+0x30], xmm3
00007e2c933d7d0f  vmovaps [rsp+0x40], xmm4
00007e2c933d7d15  vmovaps [rsp+0x50], xmm5
00007e2c933d7d1b  vmovaps [rsp+0x60], xmm6
00007e2c933d7d21  vmovaps [rsp+0x70], xmm7
00007e2c933d7d27  vmovaps [rsp+0x80], xmm8
00007e2c933d7d30  vmovaps [rsp+0x90], xmm10
00007e2c933d7d39  vmovaps [rsp+0xA0], xmm11
00007e2c933d7d42  vmovaps [rsp+0xB0], xmm12
00007e2c933d7d4b  vmovaps [rsp+0xC0], xmm13
00007e2c933d7d54  vmovaps [rsp+0xD0], xmm14
00007e2c933d7d5d  vmovaps [rsp+0xE0], xmm15
00007e2c933d7d66  sub rsp, 0x30
00007e2c933d7d6a  movaps [rsp], xmm9
00007e2c933d7d6f  movaps [rsp+0x10], xmm1
00007e2c933d7d74  movaps [rsp+0x20], xmm15
00007e2c933d7d7a  lea rdi, [rsp]
00007e2c933d7d7e  mov esi, 0x00
00007e2c933d7d83  mov rax, 0x5A263F1C7530
00007e2c933d7d8d  call rax
00007e2c933d7d8f  movaps xmm9, [rsp]
00007e2c933d7d94  add rsp, 0x30
00007e2c933d7d98  vmovaps xmm0, [rsp]
00007e2c933d7d9d  vmovaps xmm1, [rsp+0x10]
00007e2c933d7da3  vmovaps xmm2, [rsp+0x20]
00007e2c933d7da9  vmovaps xmm3, [rsp+0x30]
00007e2c933d7daf  vmovaps xmm4, [rsp+0x40]
00007e2c933d7db5  vmovaps xmm5, [rsp+0x50]
00007e2c933d7dbb  vmovaps xmm6, [rsp+0x60]
00007e2c933d7dc1  vmovaps xmm7, [rsp+0x70]
00007e2c933d7dc7  vmovaps xmm8, [rsp+0x80]
00007e2c933d7dd0  vmovaps xmm10, [rsp+0x90]
00007e2c933d7dd9  vmovaps xmm11, [rsp+0xA0]
00007e2c933d7de2  vmovaps xmm12, [rsp+0xB0]
00007e2c933d7deb  vmovaps xmm13, [rsp+0xC0]
00007e2c933d7df4  vmovaps xmm14, [rsp+0xD0]
00007e2c933d7dfd  vmovaps xmm15, [rsp+0xE0]
00007e2c933d7e06  add rsp, 0xF0
00007e2c933d7e0d  pop r11
00007e2c933d7e0f  pop r10
00007e2c933d7e11  pop r9
00007e2c933d7e13  pop r8
00007e2c933d7e15  pop rsi
00007e2c933d7e16  pop rdi
00007e2c933d7e17  pop rdx
00007e2c933d7e18  pop rcx
00007e2c933d7e19  pop rax
00007e2c933d7e1a  add rsp, 0x08
00007e2c933d7e1e  jmp 0x00007E2C933D3418
00007e2c933d7e23  sub rsp, 0x08
00007e2c933d7e27  push rax
00007e2c933d7e28  push rcx
00007e2c933d7e29  push rdx
00007e2c933d7e2a  push rdi
00007e2c933d7e2b  push rsi
00007e2c933d7e2c  push r8
00007e2c933d7e2e  push r9
00007e2c933d7e30  push r10
00007e2c933d7e32  push r11
00007e2c933d7e34  sub rsp, 0xF0
00007e2c933d7e3b  vmovaps [rsp], xmm0
00007e2c933d7e40  vmovaps [rsp+0x10], xmm1
00007e2c933d7e46  vmovaps [rsp+0x20], xmm2
00007e2c933d7e4c  vmovaps [rsp+0x30], xmm3
00007e2c933d7e52  vmovaps [rsp+0x40], xmm4
00007e2c933d7e58  vmovaps [rsp+0x50], xmm5
00007e2c933d7e5e  vmovaps [rsp+0x60], xmm6
00007e2c933d7e64  vmovaps [rsp+0x70], xmm7
00007e2c933d7e6a  vmovaps [rsp+0x80], xmm8
00007e2c933d7e73  vmovaps [rsp+0x90], xmm9
00007e2c933d7e7c  vmovaps [rsp+0xA0], xmm10
00007e2c933d7e85  vmovaps [rsp+0xB0], xmm11
00007e2c933d7e8e  vmovaps [rsp+0xC0], xmm12
00007e2c933d7e97  vmovaps [rsp+0xD0], xmm13
00007e2c933d7ea0  vmovaps [rsp+0xE0], xmm14
00007e2c933d7ea9  sub rsp, 0x30
00007e2c933d7ead  movaps [rsp], xmm15
00007e2c933d7eb2  movaps [rsp+0x10], xmm4
00007e2c933d7eb7  movaps [rsp+0x20], xmm1
00007e2c933d7ebc  lea rdi, [rsp]
00007e2c933d7ec0  mov esi, 0x00
00007e2c933d7ec5  mov rax, 0x5A263F1C7530
00007e2c933d7ecf  call rax
00007e2c933d7ed1  movaps xmm15, [rsp]
00007e2c933d7ed6  add rsp, 0x30
00007e2c933d7eda  vmovaps xmm0, [rsp]
00007e2c933d7edf  vmovaps xmm1, [rsp+0x10]
00007e2c933d7ee5  vmovaps xmm2, [rsp+0x20]
00007e2c933d7eeb  vmovaps xmm3, [rsp+0x30]
00007e2c933d7ef1  vmovaps xmm4, [rsp+0x40]
00007e2c933d7ef7  vmovaps xmm5, [rsp+0x50]
00007e2c933d7efd  vmovaps xmm6, [rsp+0x60]
00007e2c933d7f03  vmovaps xmm7, [rsp+0x70]
00007e2c933d7f09  vmovaps xmm8, [rsp+0x80]
00007e2c933d7f12  vmovaps xmm9, [rsp+0x90]
00007e2c933d7f1b  vmovaps xmm10, [rsp+0xA0]
00007e2c933d7f24  vmovaps xmm11, [rsp+0xB0]
00007e2c933d7f2d  vmovaps xmm12, [rsp+0xC0]
00007e2c933d7f36  vmovaps xmm13, [rsp+0xD0]
00007e2c933d7f3f  vmovaps xmm14, [rsp+0xE0]
00007e2c933d7f48  add rsp, 0xF0
00007e2c933d7f4f  pop r11
00007e2c933d7f51  pop r10
00007e2c933d7f53  pop r9
00007e2c933d7f55  pop r8
00007e2c933d7f57  pop rsi
00007e2c933d7f58  pop rdi
00007e2c933d7f59  pop rdx
00007e2c933d7f5a  pop rcx
00007e2c933d7f5b  pop rax
00007e2c933d7f5c  add rsp, 0x08
00007e2c933d7f60  jmp 0x00007E2C933D343E
00007e2c933d7f65  sub rsp, 0x08
00007e2c933d7f69  push rax
00007e2c933d7f6a  push rcx
00007e2c933d7f6b  push rdx
00007e2c933d7f6c  push rdi
00007e2c933d7f6d  push rsi
00007e2c933d7f6e  push r8
00007e2c933d7f70  push r9
00007e2c933d7f72  push r10
00007e2c933d7f74  push r11
00007e2c933d7f76  sub rsp, 0xF0
00007e2c933d7f7d  vmovaps [rsp], xmm0
00007e2c933d7f82  vmovaps [rsp+0x10], xmm2
00007e2c933d7f88  vmovaps [rsp+0x20], xmm3
00007e2c933d7f8e  vmovaps [rsp+0x30], xmm4
00007e2c933d7f94  vmovaps [rsp+0x40], xmm5
00007e2c933d7f9a  vmovaps [rsp+0x50], xmm6
00007e2c933d7fa0  vmovaps [rsp+0x60], xmm7
00007e2c933d7fa6  vmovaps [rsp+0x70], xmm8
00007e2c933d7fac  vmovaps [rsp+0x80], xmm9
00007e2c933d7fb5  vmovaps [rsp+0x90], xmm10
00007e2c933d7fbe  vmovaps [rsp+0xA0], xmm11
00007e2c933d7fc7  vmovaps [rsp+0xB0], xmm12
00007e2c933d7fd0  vmovaps [rsp+0xC0], xmm13
00007e2c933d7fd9  vmovaps [rsp+0xD0], xmm14
00007e2c933d7fe2  vmovaps [rsp+0xE0], xmm15
00007e2c933d7feb  sub rsp, 0x30
00007e2c933d7fef  movaps [rsp], xmm1
00007e2c933d7ff3  movaps [rsp+0x10], xmm14
00007e2c933d7ff9  movaps [rsp+0x20], xmm11
00007e2c933d7fff  lea rdi, [rsp]
00007e2c933d8003  mov esi, 0x00
00007e2c933d8008  mov rax, 0x5A263F1C7530
00007e2c933d8012  call rax
00007e2c933d8014  movaps xmm1, [rsp]
00007e2c933d8018  add rsp, 0x30
00007e2c933d801c  vmovaps xmm0, [rsp]
00007e2c933d8021  vmovaps xmm2, [rsp+0x10]
00007e2c933d8027  vmovaps xmm3, [rsp+0x20]
00007e2c933d802d  vmovaps xmm4, [rsp+0x30]
00007e2c933d8033  vmovaps xmm5, [rsp+0x40]
00007e2c933d8039  vmovaps xmm6, [rsp+0x50]
00007e2c933d803f  vmovaps xmm7, [rsp+0x60]
00007e2c933d8045  vmovaps xmm8, [rsp+0x70]
00007e2c933d804b  vmovaps xmm9, [rsp+0x80]
00007e2c933d8054  vmovaps xmm10, [rsp+0x90]
00007e2c933d805d  vmovaps xmm11, [rsp+0xA0]
00007e2c933d8066  vmovaps xmm12, [rsp+0xB0]
00007e2c933d806f  vmovaps xmm13, [rsp+0xC0]
00007e2c933d8078  vmovaps xmm14, [rsp+0xD0]
00007e2c933d8081  vmovaps xmm15, [rsp+0xE0]
00007e2c933d808a  add rsp, 0xF0
00007e2c933d8091  pop r11
00007e2c933d8093  pop r10
00007e2c933d8095  pop r9
00007e2c933d8097  pop r8
00007e2c933d8099  pop rsi
00007e2c933d809a  pop rdi
00007e2c933d809b  pop rdx
00007e2c933d809c  pop rcx
00007e2c933d809d  pop rax
00007e2c933d809e  add rsp, 0x08
00007e2c933d80a2  jmp 0x00007E2C933D345F
00007e2c933d80a7  call 0x00007E2C932E45A0
00007e2c933d80ac  jmp 0x00007E2C933D346D
00007e2c933d80b1  call 0x00007E2C93209D70
00007e2c933d80b6  jmp 0x00007E2C933D3477
00007e2c933d80bb  sub rsp, 0x08
00007e2c933d80bf  push rax
00007e2c933d80c0  push rcx
00007e2c933d80c1  push rdx
00007e2c933d80c2  push rdi
00007e2c933d80c3  push rsi
00007e2c933d80c4  push r8
00007e2c933d80c6  push r9
00007e2c933d80c8  push r10
00007e2c933d80ca  push r11
00007e2c933d80cc  sub rsp, 0xF0
00007e2c933d80d3  vmovaps [rsp], xmm0
00007e2c933d80d8  vmovaps [rsp+0x10], xmm1
00007e2c933d80de  vmovaps [rsp+0x20], xmm2
00007e2c933d80e4  vmovaps [rsp+0x30], xmm3
00007e2c933d80ea  vmovaps [rsp+0x40], xmm4
00007e2c933d80f0  vmovaps [rsp+0x50], xmm5
00007e2c933d80f6  vmovaps [rsp+0x60], xmm6
00007e2c933d80fc  vmovaps [rsp+0x70], xmm8
00007e2c933d8102  vmovaps [rsp+0x80], xmm9
00007e2c933d810b  vmovaps [rsp+0x90], xmm10
00007e2c933d8114  vmovaps [rsp+0xA0], xmm11
00007e2c933d811d  vmovaps [rsp+0xB0], xmm12
00007e2c933d8126  vmovaps [rsp+0xC0], xmm13
00007e2c933d812f  vmovaps [rsp+0xD0], xmm14
00007e2c933d8138  vmovaps [rsp+0xE0], xmm15
00007e2c933d8141  sub rsp, 0x30
00007e2c933d8145  movaps [rsp], xmm7
00007e2c933d8149  movaps [rsp+0x10], xmm13
00007e2c933d814f  movaps [rsp+0x20], xmm10
00007e2c933d8155  lea rdi, [rsp]
00007e2c933d8159  mov esi, 0x00
00007e2c933d815e  mov rax, 0x5A263F1C7530
00007e2c933d8168  call rax
00007e2c933d816a  movaps xmm7, [rsp]
00007e2c933d816e  add rsp, 0x30
00007e2c933d8172  vmovaps xmm0, [rsp]
00007e2c933d8177  vmovaps xmm1, [rsp+0x10]
00007e2c933d817d  vmovaps xmm2, [rsp+0x20]
00007e2c933d8183  vmovaps xmm3, [rsp+0x30]
00007e2c933d8189  vmovaps xmm4, [rsp+0x40]
00007e2c933d818f  vmovaps xmm5, [rsp+0x50]
00007e2c933d8195  vmovaps xmm6, [rsp+0x60]
00007e2c933d819b  vmovaps xmm8, [rsp+0x70]
00007e2c933d81a1  vmovaps xmm9, [rsp+0x80]
00007e2c933d81aa  vmovaps xmm10, [rsp+0x90]
00007e2c933d81b3  vmovaps xmm11, [rsp+0xA0]
00007e2c933d81bc  vmovaps xmm12, [rsp+0xB0]
00007e2c933d81c5  vmovaps xmm13, [rsp+0xC0]
00007e2c933d81ce  vmovaps xmm14, [rsp+0xD0]
00007e2c933d81d7  vmovaps xmm15, [rsp+0xE0]
00007e2c933d81e0  add rsp, 0xF0
00007e2c933d81e7  pop r11
00007e2c933d81e9  pop r10
00007e2c933d81eb  pop r9
00007e2c933d81ed  pop r8
00007e2c933d81ef  pop rsi
00007e2c933d81f0  pop rdi
00007e2c933d81f1  pop rdx
00007e2c933d81f2  pop rcx
00007e2c933d81f3  pop rax
00007e2c933d81f4  add rsp, 0x08
00007e2c933d81f8  jmp 0x00007E2C933D3498
00007e2c933d81fd  sub rsp, 0x08
00007e2c933d8201  push rax
00007e2c933d8202  push rcx
00007e2c933d8203  push rdx
00007e2c933d8204  push rdi
00007e2c933d8205  push rsi
00007e2c933d8206  push r8
00007e2c933d8208  push r9
00007e2c933d820a  push r10
00007e2c933d820c  push r11
00007e2c933d820e  sub rsp, 0xF0
00007e2c933d8215  vmovaps [rsp], xmm0
00007e2c933d821a  vmovaps [rsp+0x10], xmm1
00007e2c933d8220  vmovaps [rsp+0x20], xmm2
00007e2c933d8226  vmovaps [rsp+0x30], xmm3
00007e2c933d822c  vmovaps [rsp+0x40], xmm4
00007e2c933d8232  vmovaps [rsp+0x50], xmm5
00007e2c933d8238  vmovaps [rsp+0x60], xmm6
00007e2c933d823e  vmovaps [rsp+0x70], xmm7
00007e2c933d8244  vmovaps [rsp+0x80], xmm8
00007e2c933d824d  vmovaps [rsp+0x90], xmm9
00007e2c933d8256  vmovaps [rsp+0xA0], xmm11
00007e2c933d825f  vmovaps [rsp+0xB0], xmm12
00007e2c933d8268  vmovaps [rsp+0xC0], xmm13
00007e2c933d8271  vmovaps [rsp+0xD0], xmm14
00007e2c933d827a  vmovaps [rsp+0xE0], xmm15
00007e2c933d8283  sub rsp, 0x30
00007e2c933d8287  movaps [rsp], xmm10
00007e2c933d828c  movaps [rsp+0x10], xmm11
00007e2c933d8292  movaps [rsp+0x20], xmm13
00007e2c933d8298  lea rdi, [rsp]
00007e2c933d829c  mov esi, 0x00
00007e2c933d82a1  mov rax, 0x5A263F1C7530
00007e2c933d82ab  call rax
00007e2c933d82ad  movaps xmm10, [rsp]
00007e2c933d82b2  add rsp, 0x30
00007e2c933d82b6  vmovaps xmm0, [rsp]
00007e2c933d82bb  vmovaps xmm1, [rsp+0x10]
00007e2c933d82c1  vmovaps xmm2, [rsp+0x20]
00007e2c933d82c7  vmovaps xmm3, [rsp+0x30]
00007e2c933d82cd  vmovaps xmm4, [rsp+0x40]
00007e2c933d82d3  vmovaps xmm5, [rsp+0x50]
00007e2c933d82d9  vmovaps xmm6, [rsp+0x60]
00007e2c933d82df  vmovaps xmm7, [rsp+0x70]
00007e2c933d82e5  vmovaps xmm8, [rsp+0x80]
00007e2c933d82ee  vmovaps xmm9, [rsp+0x90]
00007e2c933d82f7  vmovaps xmm11, [rsp+0xA0]
00007e2c933d8300  vmovaps xmm12, [rsp+0xB0]
00007e2c933d8309  vmovaps xmm13, [rsp+0xC0]
00007e2c933d8312  vmovaps xmm14, [rsp+0xD0]
00007e2c933d831b  vmovaps xmm15, [rsp+0xE0]
00007e2c933d8324  add rsp, 0xF0
00007e2c933d832b  pop r11
00007e2c933d832d  pop r10
00007e2c933d832f  pop r9
00007e2c933d8331  pop r8
00007e2c933d8333  pop rsi
00007e2c933d8334  pop rdi
00007e2c933d8335  pop rdx
00007e2c933d8336  pop rcx
00007e2c933d8337  pop rax
00007e2c933d8338  add rsp, 0x08
00007e2c933d833c  jmp 0x00007E2C933D34C6
00007e2c933d8341  sub rsp, 0x08
00007e2c933d8345  push rax
00007e2c933d8346  push rcx
00007e2c933d8347  push rdx
00007e2c933d8348  push rdi
00007e2c933d8349  push rsi
00007e2c933d834a  push r8
00007e2c933d834c  push r9
00007e2c933d834e  push r10
00007e2c933d8350  push r11
00007e2c933d8352  sub rsp, 0xF0
00007e2c933d8359  vmovaps [rsp], xmm0
00007e2c933d835e  vmovaps [rsp+0x10], xmm1
00007e2c933d8364  vmovaps [rsp+0x20], xmm2
00007e2c933d836a  vmovaps [rsp+0x30], xmm3
00007e2c933d8370  vmovaps [rsp+0x40], xmm4
00007e2c933d8376  vmovaps [rsp+0x50], xmm5
00007e2c933d837c  vmovaps [rsp+0x60], xmm6
00007e2c933d8382  vmovaps [rsp+0x70], xmm7
00007e2c933d8388  vmovaps [rsp+0x80], xmm8
00007e2c933d8391  vmovaps [rsp+0x90], xmm9
00007e2c933d839a  vmovaps [rsp+0xA0], xmm10
00007e2c933d83a3  vmovaps [rsp+0xB0], xmm12
00007e2c933d83ac  vmovaps [rsp+0xC0], xmm13
00007e2c933d83b5  vmovaps [rsp+0xD0], xmm14
00007e2c933d83be  vmovaps [rsp+0xE0], xmm15
00007e2c933d83c7  sub rsp, 0x30
00007e2c933d83cb  movaps [rsp], xmm11
00007e2c933d83d0  movaps [rsp+0x10], xmm14
00007e2c933d83d6  movaps [rsp+0x20], xmm13
00007e2c933d83dc  lea rdi, [rsp]
00007e2c933d83e0  mov esi, 0x00
00007e2c933d83e5  mov rax, 0x5A263F1C7530
00007e2c933d83ef  call rax
00007e2c933d83f1  movaps xmm11, [rsp]
00007e2c933d83f6  add rsp, 0x30
00007e2c933d83fa  vmovaps xmm0, [rsp]
00007e2c933d83ff  vmovaps xmm1, [rsp+0x10]
00007e2c933d8405  vmovaps xmm2, [rsp+0x20]
00007e2c933d840b  vmovaps xmm3, [rsp+0x30]
00007e2c933d8411  vmovaps xmm4, [rsp+0x40]
00007e2c933d8417  vmovaps xmm5, [rsp+0x50]
00007e2c933d841d  vmovaps xmm6, [rsp+0x60]
00007e2c933d8423  vmovaps xmm7, [rsp+0x70]
00007e2c933d8429  vmovaps xmm8, [rsp+0x80]
00007e2c933d8432  vmovaps xmm9, [rsp+0x90]
00007e2c933d843b  vmovaps xmm10, [rsp+0xA0]
00007e2c933d8444  vmovaps xmm12, [rsp+0xB0]
00007e2c933d844d  vmovaps xmm13, [rsp+0xC0]
00007e2c933d8456  vmovaps xmm14, [rsp+0xD0]
00007e2c933d845f  vmovaps xmm15, [rsp+0xE0]
00007e2c933d8468  add rsp, 0xF0
00007e2c933d846f  pop r11
00007e2c933d8471  pop r10
00007e2c933d8473  pop r9
00007e2c933d8475  pop r8
00007e2c933d8477  pop rsi
00007e2c933d8478  pop rdi
00007e2c933d8479  pop rdx
00007e2c933d847a  pop rcx
00007e2c933d847b  pop rax
00007e2c933d847c  add rsp, 0x08
00007e2c933d8480  jmp 0x00007E2C933D34F4
00007e2c933d8485  sub rsp, 0x08
00007e2c933d8489  push rax
00007e2c933d848a  push rcx
00007e2c933d848b  push rdx
00007e2c933d848c  push rdi
00007e2c933d848d  push rsi
00007e2c933d848e  push r8
00007e2c933d8490  push r9
00007e2c933d8492  push r10
00007e2c933d8494  push r11
00007e2c933d8496  sub rsp, 0xF0
00007e2c933d849d  vmovaps [rsp], xmm0
00007e2c933d84a2  vmovaps [rsp+0x10], xmm1
00007e2c933d84a8  vmovaps [rsp+0x20], xmm2
00007e2c933d84ae  vmovaps [rsp+0x30], xmm3
00007e2c933d84b4  vmovaps [rsp+0x40], xmm4
00007e2c933d84ba  vmovaps [rsp+0x50], xmm5
00007e2c933d84c0  vmovaps [rsp+0x60], xmm6
00007e2c933d84c6  vmovaps [rsp+0x70], xmm7
00007e2c933d84cc  vmovaps [rsp+0x80], xmm8
00007e2c933d84d5  vmovaps [rsp+0x90], xmm9
00007e2c933d84de  vmovaps [rsp+0xA0], xmm10
00007e2c933d84e7  vmovaps [rsp+0xB0], xmm11
00007e2c933d84f0  vmovaps [rsp+0xC0], xmm12
00007e2c933d84f9  vmovaps [rsp+0xD0], xmm13
00007e2c933d8502  vmovaps [rsp+0xE0], xmm15
00007e2c933d850b  sub rsp, 0x30
00007e2c933d850f  movaps [rsp], xmm14
00007e2c933d8514  movaps [rsp+0x10], xmm12
00007e2c933d851a  movaps [rsp+0x20], xmm9
00007e2c933d8520  lea rdi, [rsp]
00007e2c933d8524  mov esi, 0x00
00007e2c933d8529  mov rax, 0x5A263F1C7530
00007e2c933d8533  call rax
00007e2c933d8535  movaps xmm14, [rsp]
00007e2c933d853a  add rsp, 0x30
00007e2c933d853e  vmovaps xmm0, [rsp]
00007e2c933d8543  vmovaps xmm1, [rsp+0x10]
00007e2c933d8549  vmovaps xmm2, [rsp+0x20]
00007e2c933d854f  vmovaps xmm3, [rsp+0x30]
00007e2c933d8555  vmovaps xmm4, [rsp+0x40]
00007e2c933d855b  vmovaps xmm5, [rsp+0x50]
00007e2c933d8561  vmovaps xmm6, [rsp+0x60]
00007e2c933d8567  vmovaps xmm7, [rsp+0x70]
00007e2c933d856d  vmovaps xmm8, [rsp+0x80]
00007e2c933d8576  vmovaps xmm9, [rsp+0x90]
00007e2c933d857f  vmovaps xmm10, [rsp+0xA0]
00007e2c933d8588  vmovaps xmm11, [rsp+0xB0]
00007e2c933d8591  vmovaps xmm12, [rsp+0xC0]
00007e2c933d859a  vmovaps xmm13, [rsp+0xD0]
00007e2c933d85a3  vmovaps xmm15, [rsp+0xE0]
00007e2c933d85ac  add rsp, 0xF0
00007e2c933d85b3  pop r11
00007e2c933d85b5  pop r10
00007e2c933d85b7  pop r9
00007e2c933d85b9  pop r8
00007e2c933d85bb  pop rsi
00007e2c933d85bc  pop rdi
00007e2c933d85bd  pop rdx
00007e2c933d85be  pop rcx
00007e2c933d85bf  pop rax
00007e2c933d85c0  add rsp, 0x08
00007e2c933d85c4  jmp 0x00007E2C933D350F
00007e2c933d85c9  sub rsp, 0x08
00007e2c933d85cd  push rax
00007e2c933d85ce  push rcx
00007e2c933d85cf  push rdx
00007e2c933d85d0  push rdi
00007e2c933d85d1  push rsi
00007e2c933d85d2  push r8
00007e2c933d85d4  push r9
00007e2c933d85d6  push r10
00007e2c933d85d8  push r11
00007e2c933d85da  sub rsp, 0xF0
00007e2c933d85e1  vmovaps [rsp], xmm0
00007e2c933d85e6  vmovaps [rsp+0x10], xmm1
00007e2c933d85ec  vmovaps [rsp+0x20], xmm2
00007e2c933d85f2  vmovaps [rsp+0x30], xmm3
00007e2c933d85f8  vmovaps [rsp+0x40], xmm4
00007e2c933d85fe  vmovaps [rsp+0x50], xmm5
00007e2c933d8604  vmovaps [rsp+0x60], xmm6
00007e2c933d860a  vmovaps [rsp+0x70], xmm7
00007e2c933d8610  vmovaps [rsp+0x80], xmm8
00007e2c933d8619  vmovaps [rsp+0x90], xmm9
00007e2c933d8622  vmovaps [rsp+0xA0], xmm10
00007e2c933d862b  vmovaps [rsp+0xB0], xmm11
00007e2c933d8634  vmovaps [rsp+0xC0], xmm12
00007e2c933d863d  vmovaps [rsp+0xD0], xmm14
00007e2c933d8646  vmovaps [rsp+0xE0], xmm15
00007e2c933d864f  sub rsp, 0x30
00007e2c933d8653  movaps [rsp], xmm13
00007e2c933d8658  movaps [rsp+0x10], xmm8
00007e2c933d865e  movaps [rsp+0x20], xmm15
00007e2c933d8664  lea rdi, [rsp]
00007e2c933d8668  mov esi, 0x00
00007e2c933d866d  mov rax, 0x5A263F1C7530
00007e2c933d8677  call rax
00007e2c933d8679  movaps xmm13, [rsp]
00007e2c933d867e  add rsp, 0x30
00007e2c933d8682  vmovaps xmm0, [rsp]
00007e2c933d8687  vmovaps xmm1, [rsp+0x10]
00007e2c933d868d  vmovaps xmm2, [rsp+0x20]
00007e2c933d8693  vmovaps xmm3, [rsp+0x30]
00007e2c933d8699  vmovaps xmm4, [rsp+0x40]
00007e2c933d869f  vmovaps xmm5, [rsp+0x50]
00007e2c933d86a5  vmovaps xmm6, [rsp+0x60]
00007e2c933d86ab  vmovaps xmm7, [rsp+0x70]
00007e2c933d86b1  vmovaps xmm8, [rsp+0x80]
00007e2c933d86ba  vmovaps xmm9, [rsp+0x90]
00007e2c933d86c3  vmovaps xmm10, [rsp+0xA0]
00007e2c933d86cc  vmovaps xmm11, [rsp+0xB0]
00007e2c933d86d5  vmovaps xmm12, [rsp+0xC0]
00007e2c933d86de  vmovaps xmm14, [rsp+0xD0]
00007e2c933d86e7  vmovaps xmm15, [rsp+0xE0]
00007e2c933d86f0  add rsp, 0xF0
00007e2c933d86f7  pop r11
00007e2c933d86f9  pop r10
00007e2c933d86fb  pop r9
00007e2c933d86fd  pop r8
00007e2c933d86ff  pop rsi
00007e2c933d8700  pop rdi
00007e2c933d8701  pop rdx
00007e2c933d8702  pop rcx
00007e2c933d8703  pop rax
00007e2c933d8704  add rsp, 0x08
00007e2c933d8708  jmp 0x00007E2C933D3532
00007e2c933d870d  sub rsp, 0x08
00007e2c933d8711  push rax
00007e2c933d8712  push rcx
00007e2c933d8713  push rdx
00007e2c933d8714  push rdi
00007e2c933d8715  push rsi
00007e2c933d8716  push r8
00007e2c933d8718  push r9
00007e2c933d871a  push r10
00007e2c933d871c  push r11
00007e2c933d871e  sub rsp, 0xF0
00007e2c933d8725  vmovaps [rsp], xmm0
00007e2c933d872a  vmovaps [rsp+0x10], xmm1
00007e2c933d8730  vmovaps [rsp+0x20], xmm2
00007e2c933d8736  vmovaps [rsp+0x30], xmm3
00007e2c933d873c  vmovaps [rsp+0x40], xmm4
00007e2c933d8742  vmovaps [rsp+0x50], xmm5
00007e2c933d8748  vmovaps [rsp+0x60], xmm6
00007e2c933d874e  vmovaps [rsp+0x70], xmm7
00007e2c933d8754  vmovaps [rsp+0x80], xmm8
00007e2c933d875d  vmovaps [rsp+0x90], xmm9
00007e2c933d8766  vmovaps [rsp+0xA0], xmm10
00007e2c933d876f  vmovaps [rsp+0xB0], xmm11
00007e2c933d8778  vmovaps [rsp+0xC0], xmm12
00007e2c933d8781  vmovaps [rsp+0xD0], xmm13
00007e2c933d878a  vmovaps [rsp+0xE0], xmm14
00007e2c933d8793  sub rsp, 0x30
00007e2c933d8797  movaps [rsp], xmm15
00007e2c933d879c  movaps [rsp+0x10], xmm1
00007e2c933d87a1  movaps [rsp+0x20], xmm10
00007e2c933d87a7  lea rdi, [rsp]
00007e2c933d87ab  mov esi, 0x00
00007e2c933d87b0  mov rax, 0x5A263F1C7530
00007e2c933d87ba  call rax
00007e2c933d87bc  movaps xmm15, [rsp]
00007e2c933d87c1  add rsp, 0x30
00007e2c933d87c5  vmovaps xmm0, [rsp]
00007e2c933d87ca  vmovaps xmm1, [rsp+0x10]
00007e2c933d87d0  vmovaps xmm2, [rsp+0x20]
00007e2c933d87d6  vmovaps xmm3, [rsp+0x30]
00007e2c933d87dc  vmovaps xmm4, [rsp+0x40]
00007e2c933d87e2  vmovaps xmm5, [rsp+0x50]
00007e2c933d87e8  vmovaps xmm6, [rsp+0x60]
00007e2c933d87ee  vmovaps xmm7, [rsp+0x70]
00007e2c933d87f4  vmovaps xmm8, [rsp+0x80]
00007e2c933d87fd  vmovaps xmm9, [rsp+0x90]
00007e2c933d8806  vmovaps xmm10, [rsp+0xA0]
00007e2c933d880f  vmovaps xmm11, [rsp+0xB0]
00007e2c933d8818  vmovaps xmm12, [rsp+0xC0]
00007e2c933d8821  vmovaps xmm13, [rsp+0xD0]
00007e2c933d882a  vmovaps xmm14, [rsp+0xE0]
00007e2c933d8833  add rsp, 0xF0
00007e2c933d883a  pop r11
00007e2c933d883c  pop r10
00007e2c933d883e  pop r9
00007e2c933d8840  pop r8
00007e2c933d8842  pop rsi
00007e2c933d8843  pop rdi
00007e2c933d8844  pop rdx
00007e2c933d8845  pop rcx
00007e2c933d8846  pop rax
00007e2c933d8847  add rsp, 0x08
00007e2c933d884b  jmp 0x00007E2C933D3555
00007e2c933d8850  sub rsp, 0x08
00007e2c933d8854  push rax
00007e2c933d8855  push rcx
00007e2c933d8856  push rdx
00007e2c933d8857  push rdi
00007e2c933d8858  push rsi
00007e2c933d8859  push r8
00007e2c933d885b  push r9
00007e2c933d885d  push r10
00007e2c933d885f  push r11
00007e2c933d8861  sub rsp, 0xF0
00007e2c933d8868  vmovaps [rsp], xmm0
00007e2c933d886d  vmovaps [rsp+0x10], xmm2
00007e2c933d8873  vmovaps [rsp+0x20], xmm3
00007e2c933d8879  vmovaps [rsp+0x30], xmm4
00007e2c933d887f  vmovaps [rsp+0x40], xmm5
00007e2c933d8885  vmovaps [rsp+0x50], xmm6
00007e2c933d888b  vmovaps [rsp+0x60], xmm7
00007e2c933d8891  vmovaps [rsp+0x70], xmm8
00007e2c933d8897  vmovaps [rsp+0x80], xmm9
00007e2c933d88a0  vmovaps [rsp+0x90], xmm10
00007e2c933d88a9  vmovaps [rsp+0xA0], xmm11
00007e2c933d88b2  vmovaps [rsp+0xB0], xmm12
00007e2c933d88bb  vmovaps [rsp+0xC0], xmm13
00007e2c933d88c4  vmovaps [rsp+0xD0], xmm14
00007e2c933d88cd  vmovaps [rsp+0xE0], xmm15
00007e2c933d88d6  sub rsp, 0x30
00007e2c933d88da  movaps [rsp], xmm1
00007e2c933d88de  movaps [rsp+0x10], xmm7
00007e2c933d88e3  movaps [rsp+0x20], xmm11
00007e2c933d88e9  lea rdi, [rsp]
00007e2c933d88ed  mov esi, 0x00
00007e2c933d88f2  mov rax, 0x5A263F1C7530
00007e2c933d88fc  call rax
00007e2c933d88fe  movaps xmm1, [rsp]
00007e2c933d8902  add rsp, 0x30
00007e2c933d8906  vmovaps xmm0, [rsp]
00007e2c933d890b  vmovaps xmm2, [rsp+0x10]
00007e2c933d8911  vmovaps xmm3, [rsp+0x20]
00007e2c933d8917  vmovaps xmm4, [rsp+0x30]
00007e2c933d891d  vmovaps xmm5, [rsp+0x40]
00007e2c933d8923  vmovaps xmm6, [rsp+0x50]
00007e2c933d8929  vmovaps xmm7, [rsp+0x60]
00007e2c933d892f  vmovaps xmm8, [rsp+0x70]
00007e2c933d8935  vmovaps xmm9, [rsp+0x80]
00007e2c933d893e  vmovaps xmm10, [rsp+0x90]
00007e2c933d8947  vmovaps xmm11, [rsp+0xA0]
00007e2c933d8950  vmovaps xmm12, [rsp+0xB0]
00007e2c933d8959  vmovaps xmm13, [rsp+0xC0]
00007e2c933d8962  vmovaps xmm14, [rsp+0xD0]
00007e2c933d896b  vmovaps xmm15, [rsp+0xE0]
00007e2c933d8974  add rsp, 0xF0
00007e2c933d897b  pop r11
00007e2c933d897d  pop r10
00007e2c933d897f  pop r9
00007e2c933d8981  pop r8
00007e2c933d8983  pop rsi
00007e2c933d8984  pop rdi
00007e2c933d8985  pop rdx
00007e2c933d8986  pop rcx
00007e2c933d8987  pop rax
00007e2c933d8988  add rsp, 0x08
00007e2c933d898c  jmp 0x00007E2C933D3576
00007e2c933d8991  call 0x00007E2C9320D600
00007e2c933d8996  jmp 0x00007E2C933D3589
00007e2c933d899b  call 0x00007E2C9320C380
00007e2c933d89a0  jmp 0x00007E2C933D3594
00007e2c933d89a5  call 0x00007E2C9320E880
00007e2c933d89aa  jmp 0x00007E2C933D359F
00007e2c933d89af  call 0x00007E2C931FF540
00007e2c933d89b4  jmp 0x00007E2C933D35AA
00007e2c933d89b9  int3
00007e2c933d89ba  nop [rax+rax*1], ax
00007e2c933d89c0  mov rax, [r15+0x40]
00007e2c933d89c4  mov r14, [r15+0x58]
00007e2c933d89c8  lea r12, [rax+r14*1]
00007e2c933d89cc  movaps xmm1, [r15+0x1D0]
00007e2c933d89d4  vmovaps [rsp+0x10], xmm1
00007e2c933d89da  vmovaps xmm15, [rsp+0x10]
00007e2c933d89e0  por xmm1, xmm15
00007e2c933d89e5  movaps xmm14, [r15+0x1A0]
00007e2c933d89ed  vmovaps [rsp+0x10], xmm14
00007e2c933d89f3  vmovaps xmm13, [rsp+0x10]
00007e2c933d89f9  por xmm14, xmm13
00007e2c933d89fe  lea rax, [r12+0x30]
00007e2c933d8a03  mov r11, [r13+rax*1]
00007e2c933d8a08  lea rax, [r12+0x38]
00007e2c933d8a0d  mov r10, [r13+rax*1]
00007e2c933d8a12  movq xmm13, r11
00007e2c933d8a17  movq xmm12, r10
00007e2c933d8a1c  movq xmm13, xmm13
00007e2c933d8a21  vmovaps [rsp+0x10], xmm13
00007e2c933d8a27  movq xmm13, xmm13
00007e2c933d8a2c  movaps [r15+0x130], xmm13
00007e2c933d8a34  movq xmm12, xmm12
00007e2c933d8a39  vmovaps [rsp+0x20], xmm12
00007e2c933d8a3f  movq xmm12, xmm12
00007e2c933d8a44  movaps [r15+0x280], xmm12
00007e2c933d8a4c  movaps xmm13, [r15+0x270]
00007e2c933d8a54  vmovaps [rsp+0x30], xmm13
00007e2c933d8a5a  vmovaps xmm12, [rsp+0x30]
00007e2c933d8a60  por xmm13, xmm12
00007e2c933d8a65  lea rax, [r12+0x20]
00007e2c933d8a6a  mov r11, [r13+rax*1]
00007e2c933d8a6f  lea rax, [r12+0x28]
00007e2c933d8a74  mov r10, [r13+rax*1]
00007e2c933d8a79  movq xmm12, r11
00007e2c933d8a7e  movq xmm11, r10
00007e2c933d8a83  movq xmm12, xmm12
00007e2c933d8a88  vmovaps [rsp+0x30], xmm12
00007e2c933d8a8e  movq xmm12, xmm12
00007e2c933d8a93  movaps [r15+0x150], xmm12
00007e2c933d8a9b  movq xmm11, xmm11
00007e2c933d8aa0  vmovaps [rsp+0x40], xmm11
00007e2c933d8aa6  movq xmm11, xmm11
00007e2c933d8aab  movaps [r15+0x140], xmm11
00007e2c933d8ab3  lea rax, [r12+0x10]
00007e2c933d8ab8  mov r11, [r13+rax*1]
00007e2c933d8abd  lea rax, [r12+0x18]
00007e2c933d8ac2  mov r10, [r13+rax*1]
00007e2c933d8ac7  movq xmm12, r11
00007e2c933d8acc  movq xmm11, r10
00007e2c933d8ad1  movq xmm12, xmm12
00007e2c933d8ad6  vmovaps [rsp+0x50], xmm12
00007e2c933d8adc  movq xmm12, xmm12
00007e2c933d8ae1  movaps [r15+0x170], xmm12
00007e2c933d8ae9  movq xmm11, xmm11
00007e2c933d8aee  vmovaps [rsp+0x60], xmm11
00007e2c933d8af4  movq xmm11, xmm11
00007e2c933d8af9  movaps [r15+0x160], xmm11
00007e2c933d8b01  mov rax, [r13+r12*1]
00007e2c933d8b06  vmovq xmm12, rax
00007e2c933d8b0b  vpbroadcastq xmm12, xmm12
00007e2c933d8b10  lea rax, [r12+0x08]
00007e2c933d8b15  mov r12, [r13+rax*1]
00007e2c933d8b1a  movq xmm11, r12
00007e2c933d8b1f  movaps [r15+0x230], xmm11
00007e2c933d8b27  mov rax, [r15+0xF8]
00007e2c933d8b2e  lea r12, [rax+0x50]
00007e2c933d8b32  movups xmm11, [r13+r12*1]
00007e2c933d8b38  lea r12, [rax+0x60]
00007e2c933d8b3c  movups xmm10, [r13+r12*1]
00007e2c933d8b42  lea r12, [rax+0x30]
00007e2c933d8b46  movups xmm9, [r13+r12*1]
00007e2c933d8b4c  mov r12, [r15+0x50]
00007e2c933d8b50  lea r11, [r12+r14*1]
00007e2c933d8b54  mov [r15+0x60], r11
00007e2c933d8b58  lea r12, [r14+0x40]
00007e2c933d8b5c  mov [r15+0x58], r12
00007e2c933d8b60  movaps xmm8, xmm12
00007e2c933d8b64  mulpd xmm8, xmm15
00007e2c933d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007e2c933d8b6f  ptest xmm7, xmm7
00007e2c933d8b74  jnz 0x00007E2C933D9997
00007e2c933d8b7a  movq xmm15, qword ptr [r15+0x230]
00007e2c933d8b83  vmovaps [rsp+0x70], xmm15
00007e2c933d8b89  vpermilpd xmm15, xmm15, 0x00
00007e2c933d8b8f  movaps xmm7, xmm9
00007e2c933d8b93  mulpd xmm7, xmm15
00007e2c933d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007e2c933d8b9d  ptest xmm6, xmm6
00007e2c933d8ba2  jnz 0x00007E2C933D9ADB
00007e2c933d8ba8  vxorps xmm15, xmm15, xmm15
00007e2c933d8bad  vpbroadcastq xmm15, xmm15
00007e2c933d8bb2  movaps xmm9, xmm12
00007e2c933d8bb6  mulpd xmm9, xmm10
00007e2c933d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007e2c933d8bc1  ptest xmm6, xmm6
00007e2c933d8bc6  jnz 0x00007E2C933D9C1D
00007e2c933d8bcc  movaps xmm10, xmm12
00007e2c933d8bd0  mulpd xmm10, xmm11
00007e2c933d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e2c933d8bdb  ptest xmm6, xmm6
00007e2c933d8be0  jnz 0x00007E2C933D9D61
00007e2c933d8be6  movaps xmm11, [r15+0x1F0]
00007e2c933d8bee  movaps xmm6, xmm12
00007e2c933d8bf2  mulpd xmm6, xmm11
00007e2c933d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007e2c933d8bfc  ptest xmm5, xmm5
00007e2c933d8c01  jnz 0x00007E2C933D9EA5
00007e2c933d8c07  movaps xmm12, [r15+0x2A0]
00007e2c933d8c0f  vmovaps [rsp+0x80], xmm12
00007e2c933d8c18  vmovaps xmm11, [rsp+0x80]
00007e2c933d8c21  por xmm12, xmm11
00007e2c933d8c26  movaps xmm11, [r15+0x250]
00007e2c933d8c2e  vmovaps [rsp+0x80], xmm11
00007e2c933d8c37  vmovaps xmm5, [rsp+0x80]
00007e2c933d8c40  por xmm11, xmm5
00007e2c933d8c45  vmovaps xmm4, [rsp+0x70]
00007e2c933d8c4b  vpermilpd xmm4, xmm4, 0x00
00007e2c933d8c51  movaps xmm3, xmm5
00007e2c933d8c54  mulpd xmm3, xmm4
00007e2c933d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007e2c933d8c5d  ptest xmm2, xmm2
00007e2c933d8c62  jnz 0x00007E2C933D9FE7
00007e2c933d8c68  mov [rsp+0x80], rax
00007e2c933d8c70  xor eax, eax
00007e2c933d8c72  mov r14d, 0x200
00007e2c933d8c78  cmp r12, r14
00007e2c933d8c7b  cmc
00007e2c933d8c7c  lahf
00007e2c933d8c7d  seto al
00007e2c933d8c80  mov [r15+0x108], eax
00007e2c933d8c87  movaps xmm5, xmm8
00007e2c933d8c8b  addpd xmm5, xmm15
00007e2c933d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007e2c933d8c95  ptest xmm4, xmm4
00007e2c933d8c9a  jnz 0x00007E2C933DA127
00007e2c933d8ca0  movaps xmm8, [r15+0x1B0]
00007e2c933d8ca8  movaps xmm4, xmm9
00007e2c933d8cac  addpd xmm4, xmm8
00007e2c933d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007e2c933d8cb6  ptest xmm2, xmm2
00007e2c933d8cbb  jnz 0x00007E2C933DA269
00007e2c933d8cc1  movaps xmm9, xmm10
00007e2c933d8cc5  addpd xmm9, xmm8
00007e2c933d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007e2c933d8cd0  ptest xmm2, xmm2
00007e2c933d8cd5  jnz 0x00007E2C933DA3AB
00007e2c933d8cdb  movaps xmm10, [r15+0x2F0]
00007e2c933d8ce3  vmovaps [rsp+0x90], xmm10
00007e2c933d8cec  vmovaps xmm8, [rsp+0x90]
00007e2c933d8cf5  por xmm10, xmm8
00007e2c933d8cfa  movaps xmm8, [r15+0x2E0]
00007e2c933d8d02  vmovaps [rsp+0x90], xmm8
00007e2c933d8d0b  vmovaps xmm2, [rsp+0x90]
00007e2c933d8d14  por xmm8, xmm2
00007e2c933d8d19  movaps xmm2, [r15+0x2D0]
00007e2c933d8d21  vmovaps [rsp+0x90], xmm2
00007e2c933d8d2a  vmovaps [rsp+0xA0], xmm1
00007e2c933d8d33  vmovaps xmm1, [rsp+0x90]
00007e2c933d8d3c  por xmm2, xmm1
00007e2c933d8d40  movaps xmm1, [r15+0x200]
00007e2c933d8d48  vmovaps [rsp+0x90], xmm1
00007e2c933d8d51  vmovaps [rsp+0xB0], xmm15
00007e2c933d8d5a  vmovaps xmm15, [rsp+0x90]
00007e2c933d8d63  por xmm1, xmm15
00007e2c933d8d68  movaps xmm15, [r15+0x1C0]
00007e2c933d8d70  vmovaps [rsp+0x90], xmm15
00007e2c933d8d79  vmovaps [rsp+0xC0], xmm1
00007e2c933d8d82  vmovaps xmm1, [rsp+0x90]
00007e2c933d8d8b  por xmm15, xmm1
00007e2c933d8d90  movaps xmm1, [r15+0x190]
00007e2c933d8d98  vmovaps [rsp+0x90], xmm1
00007e2c933d8da1  vmovaps [rsp+0xD0], xmm15
00007e2c933d8daa  vmovaps xmm15, [rsp+0x90]
00007e2c933d8db3  por xmm1, xmm15
00007e2c933d8db8  movaps xmm15, [r15+0x300]
00007e2c933d8dc0  vmovaps [rsp+0x90], xmm15
00007e2c933d8dc9  vmovaps [rsp+0xE0], xmm1
00007e2c933d8dd2  vmovaps xmm1, [rsp+0x90]
00007e2c933d8ddb  por xmm15, xmm1
00007e2c933d8de0  mov rax, [rsp+0x80]
00007e2c933d8de8  lea r14, [rax+0xA0]
00007e2c933d8def  movups xmm1, [r13+r14*1]
00007e2c933d8df5  lea r14, [rax+0xB0]
00007e2c933d8dfc  vmovaps [rsp+0x80], xmm1
00007e2c933d8e05  movups xmm1, [r13+r14*1]
00007e2c933d8e0b  vmovaps [rsp+0x90], xmm1
00007e2c933d8e14  vmovaps [rsp+0xF0], xmm15
00007e2c933d8e1d  vmovaps xmm15, [rsp+0xB0]
00007e2c933d8e26  vmovaps [rsp+0xB0], xmm14
00007e2c933d8e2f  movaps xmm1, xmm6
00007e2c933d8e32  addpd xmm1, xmm15
00007e2c933d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007e2c933d8e3c  ptest xmm14, xmm14
00007e2c933d8e42  jnz 0x00007E2C933DA503
00007e2c933d8e48  lea r14, [rax+0xF0]
00007e2c933d8e4f  movups xmm15, [r13+r14*1]
00007e2c933d8e55  movaps xmm14, xmm4
00007e2c933d8e59  addpd xmm14, xmm3
00007e2c933d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007e2c933d8e64  ptest xmm6, xmm6
00007e2c933d8e69  jnz 0x00007E2C933DA64E
00007e2c933d8e6f  movaps xmm6, xmm9
00007e2c933d8e73  addpd xmm6, xmm7
00007e2c933d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007e2c933d8e7c  ptest xmm4, xmm4
00007e2c933d8e81  jnz 0x00007E2C933DA790
00007e2c933d8e87  vmovaps xmm9, [rsp+0x70]
00007e2c933d8e8d  vpermilpd xmm9, xmm9, 0x00
00007e2c933d8e93  vmovaps xmm4, [rsp+0x90]
00007e2c933d8e9c  movaps xmm7, xmm4
00007e2c933d8e9f  mulpd xmm7, xmm9
00007e2c933d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007e2c933d8ea9  ptest xmm3, xmm3
00007e2c933d8eae  jnz 0x00007E2C933DA8D1
00007e2c933d8eb4  vmovaps xmm9, [rsp+0x50]
00007e2c933d8eba  vpermilpd xmm9, xmm9, 0x00
00007e2c933d8ec0  movaps xmm4, xmm15
00007e2c933d8ec4  mulpd xmm4, xmm9
00007e2c933d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007e2c933d8ece  ptest xmm3, xmm3
00007e2c933d8ed3  jnz 0x00007E2C933DAA12
00007e2c933d8ed9  lea r14, [rax+0xE0]
00007e2c933d8ee0  movups xmm15, [r13+r14*1]
00007e2c933d8ee6  vmovaps xmm9, [rsp+0x70]
00007e2c933d8eec  vpermilpd xmm9, xmm9, 0x00
00007e2c933d8ef2  vmovaps [rsp+0x70], xmm1
00007e2c933d8ef8  vmovaps xmm1, [rsp+0x80]
00007e2c933d8f01  vmovaps [rsp+0x80], xmm15
00007e2c933d8f0a  movaps xmm3, xmm1
00007e2c933d8f0d  mulpd xmm3, xmm9
00007e2c933d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007e2c933d8f17  ptest xmm15, xmm15
00007e2c933d8f1d  jnz 0x00007E2C933DAB5E
00007e2c933d8f23  vmovaps xmm1, [rsp+0xF0]
00007e2c933d8f2c  vmovaps xmm15, [rsp+0xF0]
00007e2c933d8f35  por xmm1, xmm15
00007e2c933d8f3a  movaps [r15+0x300], xmm1
00007e2c933d8f42  vmovaps xmm15, [rsp+0xE0]
00007e2c933d8f4b  vmovaps xmm9, [rsp+0xE0]
00007e2c933d8f54  por xmm15, xmm9
00007e2c933d8f59  movaps [r15+0x190], xmm15
00007e2c933d8f61  vmovaps xmm9, [rsp+0x50]
00007e2c933d8f67  vpermilpd xmm9, xmm9, 0x00
00007e2c933d8f6d  vmovaps [rsp+0x90], xmm1
00007e2c933d8f76  vmovaps [rsp+0xE0], xmm15
00007e2c933d8f7f  vmovaps xmm15, [rsp+0x80]
00007e2c933d8f88  vmovaps [rsp+0x80], xmm14
00007e2c933d8f91  movaps xmm1, xmm15
00007e2c933d8f95  mulpd xmm1, xmm9
00007e2c933d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007e2c933d8f9f  ptest xmm14, xmm14
00007e2c933d8fa5  jnz 0x00007E2C933DAC9F
00007e2c933d8fab  lea r14, [rax+0x90]
00007e2c933d8fb2  movups xmm15, [r13+r14*1]
00007e2c933d8fb8  vmovaps xmm14, [rsp+0xD0]
00007e2c933d8fc1  vmovaps xmm9, [rsp+0xD0]
00007e2c933d8fca  por xmm14, xmm9
00007e2c933d8fcf  movaps [r15+0x1C0], xmm14
00007e2c933d8fd7  vmovaps xmm9, [rsp+0xC0]
00007e2c933d8fe0  vmovaps [rsp+0xD0], xmm1
00007e2c933d8fe9  vmovaps xmm1, [rsp+0xC0]
00007e2c933d8ff2  por xmm9, xmm1
00007e2c933d8ff7  movaps [r15+0x200], xmm9
00007e2c933d8fff  vmovaps [rsp+0xC0], xmm2
00007e2c933d9008  vmovaps xmm1, [rsp+0xC0]
00007e2c933d9011  por xmm2, xmm1
00007e2c933d9015  movaps [r15+0x2D0], xmm2
00007e2c933d901d  vmovaps [rsp+0xC0], xmm8
00007e2c933d9026  vmovaps xmm1, [rsp+0xC0]
00007e2c933d902f  por xmm8, xmm1
00007e2c933d9034  movaps [r15+0x2E0], xmm8
00007e2c933d903c  vmovaps [rsp+0xC0], xmm15
00007e2c933d9045  movaps xmm1, xmm5
00007e2c933d9048  addpd xmm1, xmm7
00007e2c933d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007e2c933d9051  ptest xmm15, xmm15
00007e2c933d9057  jnz 0x00007E2C933DADEB
00007e2c933d905d  vmovaps xmm15, [rsp+0x50]
00007e2c933d9063  vpermilpd xmm15, xmm15, 0x00
00007e2c933d9069  vmovaps xmm5, [rsp+0xC0]
00007e2c933d9072  vmovaps [rsp+0xC0], xmm1
00007e2c933d907b  movaps xmm7, xmm5
00007e2c933d907e  mulpd xmm7, xmm15
00007e2c933d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007e2c933d9088  ptest xmm1, xmm1
00007e2c933d908d  jnz 0x00007E2C933DAF2B
00007e2c933d9093  lea r14, [rax+0x80]
00007e2c933d909a  movups xmm1, [r13+r14*1]
00007e2c933d90a0  vmovaps xmm5, [rsp+0x70]
00007e2c933d90a6  vmovaps [rsp+0x70], xmm1
00007e2c933d90ac  movaps xmm15, xmm5
00007e2c933d90b0  addpd xmm15, xmm3
00007e2c933d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e2c933d90bb  ptest xmm1, xmm1
00007e2c933d90c0  jnz 0x00007E2C933DB076
00007e2c933d90c6  vmovaps xmm5, [rsp+0x80]
00007e2c933d90cf  movaps xmm1, xmm5
00007e2c933d90d2  addpd xmm1, xmm4
00007e2c933d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007e2c933d90db  ptest xmm3, xmm3
00007e2c933d90e0  jnz 0x00007E2C933DB1B8
00007e2c933d90e6  vmovaps [rsp+0x80], xmm10
00007e2c933d90ef  vmovaps xmm5, [rsp+0x80]
00007e2c933d90f8  por xmm10, xmm5
00007e2c933d90fd  movaps [r15+0x2F0], xmm10
00007e2c933d9105  vmovaps xmm5, [rsp+0x50]
00007e2c933d910b  vpermilpd xmm5, xmm5, 0x00
00007e2c933d9111  vmovaps xmm3, [rsp+0x70]
00007e2c933d9117  vmovaps [rsp+0x50], xmm1
00007e2c933d911d  movaps xmm4, xmm3
00007e2c933d9120  mulpd xmm4, xmm5
00007e2c933d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007e2c933d9129  ptest xmm1, xmm1
00007e2c933d912e  jnz 0x00007E2C933DB2F8
00007e2c933d9134  lea r14, [rax+0xD0]
00007e2c933d913b  movups xmm1, [r13+r14*1]
00007e2c933d9141  vmovaps xmm3, [rsp+0xD0]
00007e2c933d914a  vmovaps [rsp+0x70], xmm1
00007e2c933d9150  movaps xmm5, xmm6
00007e2c933d9153  addpd xmm5, xmm3
00007e2c933d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007e2c933d915c  ptest xmm1, xmm1
00007e2c933d9161  jnz 0x00007E2C933DB442
00007e2c933d9167  vmovaps xmm1, [rsp+0x60]
00007e2c933d916d  vpermilpd xmm1, xmm1, 0x00
00007e2c933d9173  movaps xmm6, xmm9
00007e2c933d9177  mulpd xmm6, xmm1
00007e2c933d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007e2c933d9180  ptest xmm3, xmm3
00007e2c933d9185  jnz 0x00007E2C933DB582
00007e2c933d918b  movaps [r15+0x260], xmm6
00007e2c933d9193  vxorps xmm1, xmm1, xmm1
00007e2c933d9197  vpbroadcastq xmm1, xmm1
00007e2c933d919c  movaps [r15+0x1B0], xmm1
00007e2c933d91a4  vmovaps xmm1, [rsp+0x60]
00007e2c933d91aa  vpermilpd xmm1, xmm1, 0x00
00007e2c933d91b0  vmovaps xmm3, [rsp+0x70]
00007e2c933d91b6  vmovaps [rsp+0x70], xmm15
00007e2c933d91bc  movaps xmm9, xmm3
00007e2c933d91c0  mulpd xmm9, xmm1
00007e2c933d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007e2c933d91cb  ptest xmm15, xmm15
00007e2c933d91d1  jnz 0x00007E2C933DB6C3
00007e2c933d91d7  lea r14, [rax+0xC0]
00007e2c933d91de  movups xmm1, [r13+r14*1]
00007e2c933d91e4  vmovaps xmm3, [rsp+0xC0]
00007e2c933d91ed  vmovaps [rsp+0x80], xmm1
00007e2c933d91f6  movaps xmm15, xmm3
00007e2c933d91fa  addpd xmm15, xmm7
00007e2c933d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007e2c933d9205  ptest xmm1, xmm1
00007e2c933d920a  jnz 0x00007E2C933DB80F
00007e2c933d9210  vmovaps [rsp+0xC0], xmm13
00007e2c933d9219  vmovaps xmm1, [rsp+0xC0]
00007e2c933d9222  por xmm13, xmm1
00007e2c933d9227  movaps [r15+0x270], xmm13
00007e2c933d922f  vmovaps xmm1, [rsp+0xB0]
00007e2c933d9238  vmovaps xmm7, [rsp+0xB0]
00007e2c933d9241  por xmm1, xmm7
00007e2c933d9245  movaps [r15+0x1A0], xmm1
00007e2c933d924d  vmovaps xmm1, [rsp+0x60]
00007e2c933d9253  vpermilpd xmm1, xmm1, 0x00
00007e2c933d9259  vmovaps [rsp+0xB0], xmm1
00007e2c933d9262  vmovaps xmm1, [rsp+0x80]
00007e2c933d926b  vmovaps [rsp+0x80], xmm15
00007e2c933d9274  vmovaps xmm15, [rsp+0xB0]
00007e2c933d927d  vmovaps [rsp+0xB0], xmm14
00007e2c933d9286  movaps xmm3, xmm1
00007e2c933d9289  mulpd xmm3, xmm15
00007e2c933d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007e2c933d9293  ptest xmm14, xmm14
00007e2c933d9299  jnz 0x00007E2C933DB951
00007e2c933d929f  lea r14, [rax+0x20]
00007e2c933d92a3  movups xmm1, [r13+r14*1]
00007e2c933d92a9  movaps [r15+0x110], xmm1
00007e2c933d92b1  vmovaps xmm14, [rsp+0x70]
00007e2c933d92b7  vmovaps [rsp+0x70], xmm1
00007e2c933d92bd  movaps xmm15, xmm14
00007e2c933d92c1  addpd xmm15, xmm4
00007e2c933d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007e2c933d92cc  ptest xmm1, xmm1
00007e2c933d92d1  jnz 0x00007E2C933DBA9C
00007e2c933d92d7  vmovaps xmm1, [rsp+0x60]
00007e2c933d92dd  vpermilpd xmm1, xmm1, 0x00
00007e2c933d92e3  movaps xmm14, xmm2
00007e2c933d92e7  mulpd xmm14, xmm1
00007e2c933d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007e2c933d92f2  ptest xmm4, xmm4
00007e2c933d92f7  jnz 0x00007E2C933DBBDF
00007e2c933d92fd  vmovaps xmm4, [rsp+0x50]
00007e2c933d9303  movaps xmm1, xmm4
00007e2c933d9306  addpd xmm1, xmm9
00007e2c933d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e2c933d9310  ptest xmm2, xmm2
00007e2c933d9315  jnz 0x00007E2C933DBD21
00007e2c933d931b  vmovaps xmm9, [rsp+0x30]
00007e2c933d9321  vpermilpd xmm9, xmm9, 0x00
00007e2c933d9327  vmovaps xmm2, [rsp+0x70]
00007e2c933d932d  vmovaps [rsp+0x50], xmm1
00007e2c933d9333  movaps xmm4, xmm2
00007e2c933d9336  mulpd xmm4, xmm9
00007e2c933d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007e2c933d9340  ptest xmm1, xmm1
00007e2c933d9345  jnz 0x00007E2C933DBE62
00007e2c933d934b  vmovaps xmm1, [rsp+0x30]
00007e2c933d9351  vpermilpd xmm1, xmm1, 0x00
00007e2c933d9357  vmovaps xmm2, [rsp+0x90]
00007e2c933d9360  vmovaps [rsp+0x60], xmm15
00007e2c933d9366  movaps xmm9, xmm2
00007e2c933d936a  mulpd xmm9, xmm1
00007e2c933d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007e2c933d9375  ptest xmm15, xmm15
00007e2c933d937b  jnz 0x00007E2C933DBFA3
00007e2c933d9381  vmovaps xmm15, [rsp+0x80]
00007e2c933d938a  movaps xmm1, xmm15
00007e2c933d938e  addpd xmm1, xmm6
00007e2c933d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007e2c933d9397  ptest xmm2, xmm2
00007e2c933d939c  jnz 0x00007E2C933DC0E5
00007e2c933d93a2  movaps xmm15, xmm5
00007e2c933d93a6  addpd xmm15, xmm3
00007e2c933d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007e2c933d93b1  ptest xmm6, xmm6
00007e2c933d93b6  jnz 0x00007E2C933DC226
00007e2c933d93bc  vmovaps xmm6, [rsp+0x30]
00007e2c933d93c2  vpermilpd xmm6, xmm6, 0x00
00007e2c933d93c8  movaps xmm5, xmm8
00007e2c933d93cc  mulpd xmm5, xmm6
00007e2c933d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007e2c933d93d5  ptest xmm3, xmm3
00007e2c933d93da  jnz 0x00007E2C933DC368
00007e2c933d93e0  vmovaps xmm8, [rsp+0x30]
00007e2c933d93e6  vpermilpd xmm8, xmm8, 0x00
00007e2c933d93ec  movaps xmm6, xmm10
00007e2c933d93f0  mulpd xmm6, xmm8
00007e2c933d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007e2c933d93fa  ptest xmm3, xmm3
00007e2c933d93ff  jnz 0x00007E2C933DC4A9
00007e2c933d9405  vmovaps xmm8, [rsp+0x60]
00007e2c933d940b  movaps xmm10, xmm8
00007e2c933d940f  addpd xmm10, xmm14
00007e2c933d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007e2c933d941a  ptest xmm3, xmm3
00007e2c933d941f  jnz 0x00007E2C933DC5EB
00007e2c933d9425  vmovaps xmm8, [rsp+0x50]
00007e2c933d942b  movaps xmm14, xmm8
00007e2c933d942f  addpd xmm14, xmm4
00007e2c933d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007e2c933d943a  ptest xmm3, xmm3
00007e2c933d943f  jnz 0x00007E2C933DC72F
00007e2c933d9445  vmovaps xmm8, [rsp+0x40]
00007e2c933d944b  vpermilpd xmm8, xmm8, 0x00
00007e2c933d9451  movaps xmm4, xmm13
00007e2c933d9455  mulpd xmm4, xmm8
00007e2c933d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007e2c933d945f  ptest xmm3, xmm3
00007e2c933d9464  jnz 0x00007E2C933DC872
00007e2c933d946a  movaps xmm13, xmm15
00007e2c933d946e  addpd xmm13, xmm9
00007e2c933d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007e2c933d9479  ptest xmm8, xmm8
00007e2c933d947f  jnz 0x00007E2C933DC9B4
00007e2c933d9485  movaps xmm15, xmm1
00007e2c933d9489  addpd xmm15, xmm5
00007e2c933d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007e2c933d9494  ptest xmm9, xmm9
00007e2c933d949a  jnz 0x00007E2C933DCAF8
00007e2c933d94a0  vmovaps [rsp+0x30], xmm11
00007e2c933d94a6  vmovaps xmm1, [rsp+0x30]
00007e2c933d94ac  por xmm11, xmm1
00007e2c933d94b1  movaps [r15+0x250], xmm11
00007e2c933d94b9  vmovaps [rsp+0x30], xmm12
00007e2c933d94bf  vmovaps xmm1, [rsp+0x30]
00007e2c933d94c5  por xmm12, xmm1
00007e2c933d94ca  movaps [r15+0x2A0], xmm12
00007e2c933d94d2  vmovaps xmm1, [rsp+0xA0]
00007e2c933d94db  vmovaps xmm11, [rsp+0xA0]
00007e2c933d94e4  por xmm1, xmm11
00007e2c933d94e9  movaps [r15+0x1D0], xmm1
00007e2c933d94f1  lea r14, [rax+0x40]
00007e2c933d94f5  movups xmm1, [r13+r14*1]
00007e2c933d94fb  movaps [r15+0x2C0], xmm1
00007e2c933d9503  vmovaps xmm11, [rsp+0x40]
00007e2c933d9509  vpermilpd xmm11, xmm11, 0x00
00007e2c933d950f  vmovaps xmm8, [rsp+0xE0]
00007e2c933d9518  movaps xmm9, xmm8
00007e2c933d951c  mulpd xmm9, xmm11
00007e2c933d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007e2c933d9527  ptest xmm5, xmm5
00007e2c933d952c  jnz 0x00007E2C933DCC44
00007e2c933d9532  movaps xmm11, xmm10
00007e2c933d9536  addpd xmm11, xmm6
00007e2c933d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007e2c933d9541  ptest xmm8, xmm8
00007e2c933d9547  jnz 0x00007E2C933DCD88
00007e2c933d954d  movaps xmm10, xmm14
00007e2c933d9551  addpd xmm10, xmm4
00007e2c933d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007e2c933d955c  ptest xmm8, xmm8
00007e2c933d9562  jnz 0x00007E2C933DCECB
00007e2c933d9568  vmovaps xmm14, [rsp+0x40]
00007e2c933d956e  vpermilpd xmm14, xmm14, 0x00
00007e2c933d9574  movaps xmm8, xmm1
00007e2c933d9578  mulpd xmm8, xmm14
00007e2c933d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007e2c933d9583  ptest xmm6, xmm6
00007e2c933d9588  jnz 0x00007E2C933DD00E
00007e2c933d958e  movaps xmm1, [r15+0x2B0]
00007e2c933d9596  vmovaps xmm14, [rsp+0x40]
00007e2c933d959c  vpermilpd xmm14, xmm14, 0x00
00007e2c933d95a2  movaps xmm6, xmm1
00007e2c933d95a5  mulpd xmm6, xmm14
00007e2c933d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007e2c933d95af  ptest xmm5, xmm5
00007e2c933d95b4  jnz 0x00007E2C933DD151
00007e2c933d95ba  vmovaps xmm1, [rsp+0x10]
00007e2c933d95c0  vpermilpd xmm1, xmm1, 0x00
00007e2c933d95c6  movaps xmm14, xmm12
00007e2c933d95ca  mulpd xmm14, xmm1
00007e2c933d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007e2c933d95d5  ptest xmm5, xmm5
00007e2c933d95da  jnz 0x00007E2C933DD292
00007e2c933d95e0  movaps xmm1, xmm13
00007e2c933d95e4  addpd xmm1, xmm9
00007e2c933d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007e2c933d95ee  ptest xmm12, xmm12
00007e2c933d95f4  jnz 0x00007E2C933DD3D5
00007e2c933d95fa  vmovaps xmm13, [rsp+0x10]
00007e2c933d9600  vpermilpd xmm13, xmm13, 0x00
00007e2c933d9606  movaps xmm12, xmm7
00007e2c933d960a  mulpd xmm12, xmm13
00007e2c933d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007e2c933d9615  ptest xmm9, xmm9
00007e2c933d961b  jnz 0x00007E2C933DD517
00007e2c933d9621  movaps xmm13, xmm15
00007e2c933d9625  addpd xmm13, xmm8
00007e2c933d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007e2c933d9630  ptest xmm9, xmm9
00007e2c933d9636  jnz 0x00007E2C933DD65A
00007e2c933d963c  movaps xmm15, [r15+0x290]
00007e2c933d9644  vmovaps xmm9, [rsp+0x10]
00007e2c933d964a  vpermilpd xmm9, xmm9, 0x00
00007e2c933d9650  movaps xmm8, xmm15
00007e2c933d9654  mulpd xmm8, xmm9
00007e2c933d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007e2c933d965f  ptest xmm7, xmm7
00007e2c933d9664  jnz 0x00007E2C933DD79E
00007e2c933d966a  movaps xmm15, xmm11
00007e2c933d966e  addpd xmm15, xmm6
00007e2c933d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007e2c933d9679  ptest xmm9, xmm9
00007e2c933d967f  jnz 0x00007E2C933DD8E2
00007e2c933d9685  movaps xmm11, [r15+0x1E0]
00007e2c933d968d  vmovaps xmm9, [rsp+0x10]
00007e2c933d9693  vpermilpd xmm9, xmm9, 0x00
00007e2c933d9699  movaps xmm7, xmm11
00007e2c933d969d  mulpd xmm7, xmm9
00007e2c933d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007e2c933d96a7  ptest xmm6, xmm6
00007e2c933d96ac  jnz 0x00007E2C933DDA25
00007e2c933d96b2  movaps xmm11, xmm10
00007e2c933d96b6  addpd xmm11, xmm14
00007e2c933d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007e2c933d96c1  ptest xmm9, xmm9
00007e2c933d96c7  jnz 0x00007E2C933DDB67
00007e2c933d96cd  lea r14, [rax+0x70]
00007e2c933d96d1  movups xmm14, [r13+r14*1]
00007e2c933d96d7  movaps [r15+0x240], xmm14
00007e2c933d96df  movaps xmm10, xmm1
00007e2c933d96e3  addpd xmm10, xmm12
00007e2c933d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007e2c933d96ee  ptest xmm9, xmm9
00007e2c933d96f4  jnz 0x00007E2C933DDCB5
00007e2c933d96fa  movaps [r15+0x170], xmm10
00007e2c933d9702  vmovaps xmm1, [rsp+0x20]
00007e2c933d9708  vpermilpd xmm1, xmm1, 0x00
00007e2c933d970e  movaps xmm12, xmm14
00007e2c933d9712  mulpd xmm12, xmm1
00007e2c933d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007e2c933d971d  ptest xmm9, xmm9
00007e2c933d9723  jnz 0x00007E2C933DDDF8
00007e2c933d9729  vmovaps xmm1, [rsp+0x20]
00007e2c933d972f  vpermilpd xmm1, xmm1, 0x00
00007e2c933d9735  vmovaps xmm9, [rsp+0xB0]
00007e2c933d973e  movaps xmm14, xmm9
00007e2c933d9742  mulpd xmm14, xmm1
00007e2c933d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007e2c933d974d  ptest xmm6, xmm6
00007e2c933d9752  jnz 0x00007E2C933DDF3B
00007e2c933d9758  movaps [r15+0x180], xmm14
00007e2c933d9760  movaps xmm1, xmm13
00007e2c933d9764  addpd xmm1, xmm8
00007e2c933d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007e2c933d976e  ptest xmm9, xmm9
00007e2c933d9774  jnz 0x00007E2C933DE07E
00007e2c933d977a  movaps [r15+0x210], xmm1
00007e2c933d9782  movups xmm13, [r13+rax*1]
00007e2c933d9788  lea r14, [rax+0x10]
00007e2c933d978c  movups xmm9, [r13+r14*1]
00007e2c933d9792  movaps [r15+0x230], xmm9
00007e2c933d979a  movaps xmm8, xmm15
00007e2c933d979e  addpd xmm8, xmm7
00007e2c933d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007e2c933d97a9  ptest xmm6, xmm6
00007e2c933d97ae  jnz 0x00007E2C933DE1D4
00007e2c933d97b4  movaps [r15+0x130], xmm8
00007e2c933d97bc  vmovaps xmm15, [rsp+0x20]
00007e2c933d97c2  vpermilpd xmm15, xmm15, 0x00
00007e2c933d97c8  movaps xmm7, xmm9
00007e2c933d97cc  mulpd xmm7, xmm15
00007e2c933d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007e2c933d97d6  ptest xmm6, xmm6
00007e2c933d97db  jnz 0x00007E2C933DE317
00007e2c933d97e1  movaps [r15+0x220], xmm7
00007e2c933d97e9  vmovaps xmm15, [rsp+0x20]
00007e2c933d97ef  vpermilpd xmm15, xmm15, 0x00
00007e2c933d97f5  movaps xmm9, xmm13
00007e2c933d97f9  mulpd xmm9, xmm15
00007e2c933d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007e2c933d9804  ptest xmm6, xmm6
00007e2c933d9809  jnz 0x00007E2C933DE459
00007e2c933d980f  movaps xmm15, xmm11
00007e2c933d9813  addpd xmm15, xmm12
00007e2c933d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007e2c933d981e  ptest xmm13, xmm13
00007e2c933d9824  jnz 0x00007E2C933DE59D
00007e2c933d982a  movaps [r15+0x140], xmm15
00007e2c933d9832  movaps xmm13, xmm10
00007e2c933d9836  addpd xmm13, xmm14
00007e2c933d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007e2c933d9841  ptest xmm12, xmm12
00007e2c933d9847  jnz 0x00007E2C933DE6E1
00007e2c933d984d  movaps [r15+0x150], xmm13
00007e2c933d9855  movaps xmm14, xmm1
00007e2c933d9859  addpd xmm14, xmm7
00007e2c933d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007e2c933d9864  ptest xmm12, xmm12
00007e2c933d986a  jnz 0x00007E2C933DE825
00007e2c933d9870  movaps [r15+0x160], xmm14
00007e2c933d9878  movaps xmm1, xmm8
00007e2c933d987c  addpd xmm1, xmm9
00007e2c933d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007e2c933d9886  ptest xmm12, xmm12
00007e2c933d988c  jnz 0x00007E2C933DE967
00007e2c933d9892  movaps [r15+0x120], xmm1
00007e2c933d989a  movups [r13+r11*1], xmm15
00007e2c933d98a0  lea rax, [r11+0x10]
00007e2c933d98a4  movups [r13+rax*1], xmm13
00007e2c933d98aa  lea rax, [r11+0x20]
00007e2c933d98ae  movups [r13+rax*1], xmm14
00007e2c933d98b4  lea rax, [r11+0x30]
00007e2c933d98b8  movups [r13+rax*1], xmm1
00007e2c933d98be  mov eax, [r15+0x108]
00007e2c933d98c5  sahf
00007e2c933d98c6  jnz 0x00007E2C933D98F8
00007e2c933d98c8  cmp dword ptr [r15+0x318], 0x00
00007e2c933d98d0  jz 0x00007E2C933DEAE0
00007e2c933d98d6  nop [rax+rax*1], ax
00007e2c933d98df  nop [rax+rax*1], eax
00007e2c933d98e7  mov eax, 0x4106D0
00007e2c933d98ec  mov [r15+0x100], rax
00007e2c933d98f3  jmp 0x00007E2C931FE110
00007e2c933d98f8  cmp dword ptr [r15+0x318], 0x00
00007e2c933d9900  jz 0x00007E2C933D89C0
00007e2c933d9906  nop [rax+rax*1], ax
00007e2c933d990f  nop [rax+rax*1], eax
00007e2c933d9917  mov eax, 0x410504
00007e2c933d991c  mov [r15+0x100], rax
00007e2c933d9923  jmp 0x00007E2C931FE110
00007e2c933d9928  int3
00007e2c933d9929  call 0x00007E2C9320A4B0
00007e2c933d992e  jmp 0x00007E2C933D8A08
00007e2c933d9933  call 0x00007E2C93209240
00007e2c933d9938  jmp 0x00007E2C933D8A12
00007e2c933d993d  call 0x00007E2C9320A4B0
00007e2c933d9942  jmp 0x00007E2C933D8A6F
00007e2c933d9947  call 0x00007E2C93209240
00007e2c933d994c  jmp 0x00007E2C933D8A79
00007e2c933d9951  call 0x00007E2C9320A4B0
00007e2c933d9956  jmp 0x00007E2C933D8ABD
00007e2c933d995b  call 0x00007E2C93209240
00007e2c933d9960  jmp 0x00007E2C933D8AC7
00007e2c933d9965  call 0x00007E2C932B47C0
00007e2c933d996a  jmp 0x00007E2C933D8B06
00007e2c933d996f  call 0x00007E2C9320B720
00007e2c933d9974  jmp 0x00007E2C933D8B1A
00007e2c933d9979  call 0x00007E2C932BFC30
00007e2c933d997e  jmp 0x00007E2C933D8B38
00007e2c933d9983  call 0x00007E2C932BE9C0
00007e2c933d9988  jmp 0x00007E2C933D8B42
00007e2c933d998d  call 0x00007E2C932BD750
00007e2c933d9992  jmp 0x00007E2C933D8B4C
00007e2c933d9997  sub rsp, 0x08
00007e2c933d999b  push rax
00007e2c933d999c  push rcx
00007e2c933d999d  push rdx
00007e2c933d999e  push rdi
00007e2c933d999f  push rsi
00007e2c933d99a0  push r8
00007e2c933d99a2  push r9
00007e2c933d99a4  push r10
00007e2c933d99a6  push r11
00007e2c933d99a8  sub rsp, 0xF0
00007e2c933d99af  vmovaps [rsp], xmm0
00007e2c933d99b4  vmovaps [rsp+0x10], xmm1
00007e2c933d99ba  vmovaps [rsp+0x20], xmm2
00007e2c933d99c0  vmovaps [rsp+0x30], xmm3
00007e2c933d99c6  vmovaps [rsp+0x40], xmm4
00007e2c933d99cc  vmovaps [rsp+0x50], xmm5
00007e2c933d99d2  vmovaps [rsp+0x60], xmm6
00007e2c933d99d8  vmovaps [rsp+0x70], xmm7
00007e2c933d99de  vmovaps [rsp+0x80], xmm9
00007e2c933d99e7  vmovaps [rsp+0x90], xmm10
00007e2c933d99f0  vmovaps [rsp+0xA0], xmm11
00007e2c933d99f9  vmovaps [rsp+0xB0], xmm12
00007e2c933d9a02  vmovaps [rsp+0xC0], xmm13
00007e2c933d9a0b  vmovaps [rsp+0xD0], xmm14
00007e2c933d9a14  vmovaps [rsp+0xE0], xmm15
00007e2c933d9a1d  sub rsp, 0x30
00007e2c933d9a21  movaps [rsp], xmm8
00007e2c933d9a26  movaps [rsp+0x10], xmm12
00007e2c933d9a2c  movaps [rsp+0x20], xmm15
00007e2c933d9a32  lea rdi, [rsp]
00007e2c933d9a36  mov esi, 0x00
00007e2c933d9a3b  mov rax, 0x5A263F1C7530
00007e2c933d9a45  call rax
00007e2c933d9a47  movaps xmm8, [rsp]
00007e2c933d9a4c  add rsp, 0x30
00007e2c933d9a50  vmovaps xmm0, [rsp]
00007e2c933d9a55  vmovaps xmm1, [rsp+0x10]
00007e2c933d9a5b  vmovaps xmm2, [rsp+0x20]
00007e2c933d9a61  vmovaps xmm3, [rsp+0x30]
00007e2c933d9a67  vmovaps xmm4, [rsp+0x40]
00007e2c933d9a6d  vmovaps xmm5, [rsp+0x50]
00007e2c933d9a73  vmovaps xmm6, [rsp+0x60]
00007e2c933d9a79  vmovaps xmm7, [rsp+0x70]
00007e2c933d9a7f  vmovaps xmm9, [rsp+0x80]
00007e2c933d9a88  vmovaps xmm10, [rsp+0x90]
00007e2c933d9a91  vmovaps xmm11, [rsp+0xA0]
00007e2c933d9a9a  vmovaps xmm12, [rsp+0xB0]
00007e2c933d9aa3  vmovaps xmm13, [rsp+0xC0]
00007e2c933d9aac  vmovaps xmm14, [rsp+0xD0]
00007e2c933d9ab5  vmovaps xmm15, [rsp+0xE0]
00007e2c933d9abe  add rsp, 0xF0
00007e2c933d9ac5  pop r11
00007e2c933d9ac7  pop r10
00007e2c933d9ac9  pop r9
00007e2c933d9acb  pop r8
00007e2c933d9acd  pop rsi
00007e2c933d9ace  pop rdi
00007e2c933d9acf  pop rdx
00007e2c933d9ad0  pop rcx
00007e2c933d9ad1  pop rax
00007e2c933d9ad2  add rsp, 0x08
00007e2c933d9ad6  jmp 0x00007E2C933D8B7A
00007e2c933d9adb  sub rsp, 0x08
00007e2c933d9adf  push rax
00007e2c933d9ae0  push rcx
00007e2c933d9ae1  push rdx
00007e2c933d9ae2  push rdi
00007e2c933d9ae3  push rsi
00007e2c933d9ae4  push r8
00007e2c933d9ae6  push r9
00007e2c933d9ae8  push r10
00007e2c933d9aea  push r11
00007e2c933d9aec  sub rsp, 0xF0
00007e2c933d9af3  vmovaps [rsp], xmm0
00007e2c933d9af8  vmovaps [rsp+0x10], xmm1
00007e2c933d9afe  vmovaps [rsp+0x20], xmm2
00007e2c933d9b04  vmovaps [rsp+0x30], xmm3
00007e2c933d9b0a  vmovaps [rsp+0x40], xmm4
00007e2c933d9b10  vmovaps [rsp+0x50], xmm5
00007e2c933d9b16  vmovaps [rsp+0x60], xmm6
00007e2c933d9b1c  vmovaps [rsp+0x70], xmm8
00007e2c933d9b22  vmovaps [rsp+0x80], xmm9
00007e2c933d9b2b  vmovaps [rsp+0x90], xmm10
00007e2c933d9b34  vmovaps [rsp+0xA0], xmm11
00007e2c933d9b3d  vmovaps [rsp+0xB0], xmm12
00007e2c933d9b46  vmovaps [rsp+0xC0], xmm13
00007e2c933d9b4f  vmovaps [rsp+0xD0], xmm14
00007e2c933d9b58  vmovaps [rsp+0xE0], xmm15
00007e2c933d9b61  sub rsp, 0x30
00007e2c933d9b65  movaps [rsp], xmm7
00007e2c933d9b69  movaps [rsp+0x10], xmm9
00007e2c933d9b6f  movaps [rsp+0x20], xmm15
00007e2c933d9b75  lea rdi, [rsp]
00007e2c933d9b79  mov esi, 0x00
00007e2c933d9b7e  mov rax, 0x5A263F1C7530
00007e2c933d9b88  call rax
00007e2c933d9b8a  movaps xmm7, [rsp]
00007e2c933d9b8e  add rsp, 0x30
00007e2c933d9b92  vmovaps xmm0, [rsp]
00007e2c933d9b97  vmovaps xmm1, [rsp+0x10]
00007e2c933d9b9d  vmovaps xmm2, [rsp+0x20]
00007e2c933d9ba3  vmovaps xmm3, [rsp+0x30]
00007e2c933d9ba9  vmovaps xmm4, [rsp+0x40]
00007e2c933d9baf  vmovaps xmm5, [rsp+0x50]
00007e2c933d9bb5  vmovaps xmm6, [rsp+0x60]
00007e2c933d9bbb  vmovaps xmm8, [rsp+0x70]
00007e2c933d9bc1  vmovaps xmm9, [rsp+0x80]
00007e2c933d9bca  vmovaps xmm10, [rsp+0x90]
00007e2c933d9bd3  vmovaps xmm11, [rsp+0xA0]
00007e2c933d9bdc  vmovaps xmm12, [rsp+0xB0]
00007e2c933d9be5  vmovaps xmm13, [rsp+0xC0]
00007e2c933d9bee  vmovaps xmm14, [rsp+0xD0]
00007e2c933d9bf7  vmovaps xmm15, [rsp+0xE0]
00007e2c933d9c00  add rsp, 0xF0
00007e2c933d9c07  pop r11
00007e2c933d9c09  pop r10
00007e2c933d9c0b  pop r9
00007e2c933d9c0d  pop r8
00007e2c933d9c0f  pop rsi
00007e2c933d9c10  pop rdi
00007e2c933d9c11  pop rdx
00007e2c933d9c12  pop rcx
00007e2c933d9c13  pop rax
00007e2c933d9c14  add rsp, 0x08
00007e2c933d9c18  jmp 0x00007E2C933D8BA8
00007e2c933d9c1d  sub rsp, 0x08
00007e2c933d9c21  push rax
00007e2c933d9c22  push rcx
00007e2c933d9c23  push rdx
00007e2c933d9c24  push rdi
00007e2c933d9c25  push rsi
00007e2c933d9c26  push r8
00007e2c933d9c28  push r9
00007e2c933d9c2a  push r10
00007e2c933d9c2c  push r11
00007e2c933d9c2e  sub rsp, 0xF0
00007e2c933d9c35  vmovaps [rsp], xmm0
00007e2c933d9c3a  vmovaps [rsp+0x10], xmm1
00007e2c933d9c40  vmovaps [rsp+0x20], xmm2
00007e2c933d9c46  vmovaps [rsp+0x30], xmm3
00007e2c933d9c4c  vmovaps [rsp+0x40], xmm4
00007e2c933d9c52  vmovaps [rsp+0x50], xmm5
00007e2c933d9c58  vmovaps [rsp+0x60], xmm6
00007e2c933d9c5e  vmovaps [rsp+0x70], xmm7
00007e2c933d9c64  vmovaps [rsp+0x80], xmm8
00007e2c933d9c6d  vmovaps [rsp+0x90], xmm10
00007e2c933d9c76  vmovaps [rsp+0xA0], xmm11
00007e2c933d9c7f  vmovaps [rsp+0xB0], xmm12
00007e2c933d9c88  vmovaps [rsp+0xC0], xmm13
00007e2c933d9c91  vmovaps [rsp+0xD0], xmm14
00007e2c933d9c9a  vmovaps [rsp+0xE0], xmm15
00007e2c933d9ca3  sub rsp, 0x30
00007e2c933d9ca7  movaps [rsp], xmm9
00007e2c933d9cac  movaps [rsp+0x10], xmm12
00007e2c933d9cb2  movaps [rsp+0x20], xmm10
00007e2c933d9cb8  lea rdi, [rsp]
00007e2c933d9cbc  mov esi, 0x00
00007e2c933d9cc1  mov rax, 0x5A263F1C7530
00007e2c933d9ccb  call rax
00007e2c933d9ccd  movaps xmm9, [rsp]
00007e2c933d9cd2  add rsp, 0x30
00007e2c933d9cd6  vmovaps xmm0, [rsp]
00007e2c933d9cdb  vmovaps xmm1, [rsp+0x10]
00007e2c933d9ce1  vmovaps xmm2, [rsp+0x20]
00007e2c933d9ce7  vmovaps xmm3, [rsp+0x30]
00007e2c933d9ced  vmovaps xmm4, [rsp+0x40]
00007e2c933d9cf3  vmovaps xmm5, [rsp+0x50]
00007e2c933d9cf9  vmovaps xmm6, [rsp+0x60]
00007e2c933d9cff  vmovaps xmm7, [rsp+0x70]
00007e2c933d9d05  vmovaps xmm8, [rsp+0x80]
00007e2c933d9d0e  vmovaps xmm10, [rsp+0x90]
00007e2c933d9d17  vmovaps xmm11, [rsp+0xA0]
00007e2c933d9d20  vmovaps xmm12, [rsp+0xB0]
00007e2c933d9d29  vmovaps xmm13, [rsp+0xC0]
00007e2c933d9d32  vmovaps xmm14, [rsp+0xD0]
00007e2c933d9d3b  vmovaps xmm15, [rsp+0xE0]
00007e2c933d9d44  add rsp, 0xF0
00007e2c933d9d4b  pop r11
00007e2c933d9d4d  pop r10
00007e2c933d9d4f  pop r9
00007e2c933d9d51  pop r8
00007e2c933d9d53  pop rsi
00007e2c933d9d54  pop rdi
00007e2c933d9d55  pop rdx
00007e2c933d9d56  pop rcx
00007e2c933d9d57  pop rax
00007e2c933d9d58  add rsp, 0x08
00007e2c933d9d5c  jmp 0x00007E2C933D8BCC
00007e2c933d9d61  sub rsp, 0x08
00007e2c933d9d65  push rax
00007e2c933d9d66  push rcx
00007e2c933d9d67  push rdx
00007e2c933d9d68  push rdi
00007e2c933d9d69  push rsi
00007e2c933d9d6a  push r8
00007e2c933d9d6c  push r9
00007e2c933d9d6e  push r10
00007e2c933d9d70  push r11
00007e2c933d9d72  sub rsp, 0xF0
00007e2c933d9d79  vmovaps [rsp], xmm0
00007e2c933d9d7e  vmovaps [rsp+0x10], xmm1
00007e2c933d9d84  vmovaps [rsp+0x20], xmm2
00007e2c933d9d8a  vmovaps [rsp+0x30], xmm3
00007e2c933d9d90  vmovaps [rsp+0x40], xmm4
00007e2c933d9d96  vmovaps [rsp+0x50], xmm5
00007e2c933d9d9c  vmovaps [rsp+0x60], xmm6
00007e2c933d9da2  vmovaps [rsp+0x70], xmm7
00007e2c933d9da8  vmovaps [rsp+0x80], xmm8
00007e2c933d9db1  vmovaps [rsp+0x90], xmm9
00007e2c933d9dba  vmovaps [rsp+0xA0], xmm11
00007e2c933d9dc3  vmovaps [rsp+0xB0], xmm12
00007e2c933d9dcc  vmovaps [rsp+0xC0], xmm13
00007e2c933d9dd5  vmovaps [rsp+0xD0], xmm14
00007e2c933d9dde  vmovaps [rsp+0xE0], xmm15
00007e2c933d9de7  sub rsp, 0x30
00007e2c933d9deb  movaps [rsp], xmm10
00007e2c933d9df0  movaps [rsp+0x10], xmm12
00007e2c933d9df6  movaps [rsp+0x20], xmm11
00007e2c933d9dfc  lea rdi, [rsp]
00007e2c933d9e00  mov esi, 0x00
00007e2c933d9e05  mov rax, 0x5A263F1C7530
00007e2c933d9e0f  call rax
00007e2c933d9e11  movaps xmm10, [rsp]
00007e2c933d9e16  add rsp, 0x30
00007e2c933d9e1a  vmovaps xmm0, [rsp]
00007e2c933d9e1f  vmovaps xmm1, [rsp+0x10]
00007e2c933d9e25  vmovaps xmm2, [rsp+0x20]
00007e2c933d9e2b  vmovaps xmm3, [rsp+0x30]
00007e2c933d9e31  vmovaps xmm4, [rsp+0x40]
00007e2c933d9e37  vmovaps xmm5, [rsp+0x50]
00007e2c933d9e3d  vmovaps xmm6, [rsp+0x60]
00007e2c933d9e43  vmovaps xmm7, [rsp+0x70]
00007e2c933d9e49  vmovaps xmm8, [rsp+0x80]
00007e2c933d9e52  vmovaps xmm9, [rsp+0x90]
00007e2c933d9e5b  vmovaps xmm11, [rsp+0xA0]
00007e2c933d9e64  vmovaps xmm12, [rsp+0xB0]
00007e2c933d9e6d  vmovaps xmm13, [rsp+0xC0]
00007e2c933d9e76  vmovaps xmm14, [rsp+0xD0]
00007e2c933d9e7f  vmovaps xmm15, [rsp+0xE0]
00007e2c933d9e88  add rsp, 0xF0
00007e2c933d9e8f  pop r11
00007e2c933d9e91  pop r10
00007e2c933d9e93  pop r9
00007e2c933d9e95  pop r8
00007e2c933d9e97  pop rsi
00007e2c933d9e98  pop rdi
00007e2c933d9e99  pop rdx
00007e2c933d9e9a  pop rcx
00007e2c933d9e9b  pop rax
00007e2c933d9e9c  add rsp, 0x08
00007e2c933d9ea0  jmp 0x00007E2C933D8BE6
00007e2c933d9ea5  sub rsp, 0x08
00007e2c933d9ea9  push rax
00007e2c933d9eaa  push rcx
00007e2c933d9eab  push rdx
00007e2c933d9eac  push rdi
00007e2c933d9ead  push rsi
00007e2c933d9eae  push r8
00007e2c933d9eb0  push r9
00007e2c933d9eb2  push r10
00007e2c933d9eb4  push r11
00007e2c933d9eb6  sub rsp, 0xF0
00007e2c933d9ebd  vmovaps [rsp], xmm0
00007e2c933d9ec2  vmovaps [rsp+0x10], xmm1
00007e2c933d9ec8  vmovaps [rsp+0x20], xmm2
00007e2c933d9ece  vmovaps [rsp+0x30], xmm3
00007e2c933d9ed4  vmovaps [rsp+0x40], xmm4
00007e2c933d9eda  vmovaps [rsp+0x50], xmm5
00007e2c933d9ee0  vmovaps [rsp+0x60], xmm7
00007e2c933d9ee6  vmovaps [rsp+0x70], xmm8
00007e2c933d9eec  vmovaps [rsp+0x80], xmm9
00007e2c933d9ef5  vmovaps [rsp+0x90], xmm10
00007e2c933d9efe  vmovaps [rsp+0xA0], xmm11
00007e2c933d9f07  vmovaps [rsp+0xB0], xmm12
00007e2c933d9f10  vmovaps [rsp+0xC0], xmm13
00007e2c933d9f19  vmovaps [rsp+0xD0], xmm14
00007e2c933d9f22  vmovaps [rsp+0xE0], xmm15
00007e2c933d9f2b  sub rsp, 0x30
00007e2c933d9f2f  movaps [rsp], xmm6
00007e2c933d9f33  movaps [rsp+0x10], xmm12
00007e2c933d9f39  movaps [rsp+0x20], xmm11
00007e2c933d9f3f  lea rdi, [rsp]
00007e2c933d9f43  mov esi, 0x00
00007e2c933d9f48  mov rax, 0x5A263F1C7530
00007e2c933d9f52  call rax
00007e2c933d9f54  movaps xmm6, [rsp]
00007e2c933d9f58  add rsp, 0x30
00007e2c933d9f5c  vmovaps xmm0, [rsp]
00007e2c933d9f61  vmovaps xmm1, [rsp+0x10]
00007e2c933d9f67  vmovaps xmm2, [rsp+0x20]
00007e2c933d9f6d  vmovaps xmm3, [rsp+0x30]
00007e2c933d9f73  vmovaps xmm4, [rsp+0x40]
00007e2c933d9f79  vmovaps xmm5, [rsp+0x50]
00007e2c933d9f7f  vmovaps xmm7, [rsp+0x60]
00007e2c933d9f85  vmovaps xmm8, [rsp+0x70]
00007e2c933d9f8b  vmovaps xmm9, [rsp+0x80]
00007e2c933d9f94  vmovaps xmm10, [rsp+0x90]
00007e2c933d9f9d  vmovaps xmm11, [rsp+0xA0]
00007e2c933d9fa6  vmovaps xmm12, [rsp+0xB0]
00007e2c933d9faf  vmovaps xmm13, [rsp+0xC0]
00007e2c933d9fb8  vmovaps xmm14, [rsp+0xD0]
00007e2c933d9fc1  vmovaps xmm15, [rsp+0xE0]
00007e2c933d9fca  add rsp, 0xF0
00007e2c933d9fd1  pop r11
00007e2c933d9fd3  pop r10
00007e2c933d9fd5  pop r9
00007e2c933d9fd7  pop r8
00007e2c933d9fd9  pop rsi
00007e2c933d9fda  pop rdi
00007e2c933d9fdb  pop rdx
00007e2c933d9fdc  pop rcx
00007e2c933d9fdd  pop rax
00007e2c933d9fde  add rsp, 0x08
00007e2c933d9fe2  jmp 0x00007E2C933D8C07
00007e2c933d9fe7  sub rsp, 0x08
00007e2c933d9feb  push rax
00007e2c933d9fec  push rcx
00007e2c933d9fed  push rdx
00007e2c933d9fee  push rdi
00007e2c933d9fef  push rsi
00007e2c933d9ff0  push r8
00007e2c933d9ff2  push r9
00007e2c933d9ff4  push r10
00007e2c933d9ff6  push r11
00007e2c933d9ff8  sub rsp, 0xF0
00007e2c933d9fff  vmovaps [rsp], xmm0
00007e2c933da004  vmovaps [rsp+0x10], xmm1
00007e2c933da00a  vmovaps [rsp+0x20], xmm2
00007e2c933da010  vmovaps [rsp+0x30], xmm4
00007e2c933da016  vmovaps [rsp+0x40], xmm5
00007e2c933da01c  vmovaps [rsp+0x50], xmm6
00007e2c933da022  vmovaps [rsp+0x60], xmm7
00007e2c933da028  vmovaps [rsp+0x70], xmm8
00007e2c933da02e  vmovaps [rsp+0x80], xmm9
00007e2c933da037  vmovaps [rsp+0x90], xmm10
00007e2c933da040  vmovaps [rsp+0xA0], xmm11
00007e2c933da049  vmovaps [rsp+0xB0], xmm12
00007e2c933da052  vmovaps [rsp+0xC0], xmm13
00007e2c933da05b  vmovaps [rsp+0xD0], xmm14
00007e2c933da064  vmovaps [rsp+0xE0], xmm15
00007e2c933da06d  sub rsp, 0x30
00007e2c933da071  movaps [rsp], xmm3
00007e2c933da075  movaps [rsp+0x10], xmm5
00007e2c933da07a  movaps [rsp+0x20], xmm4
00007e2c933da07f  lea rdi, [rsp]
00007e2c933da083  mov esi, 0x00
00007e2c933da088  mov rax, 0x5A263F1C7530
00007e2c933da092  call rax
00007e2c933da094  movaps xmm3, [rsp]
00007e2c933da098  add rsp, 0x30
00007e2c933da09c  vmovaps xmm0, [rsp]
00007e2c933da0a1  vmovaps xmm1, [rsp+0x10]
00007e2c933da0a7  vmovaps xmm2, [rsp+0x20]
00007e2c933da0ad  vmovaps xmm4, [rsp+0x30]
00007e2c933da0b3  vmovaps xmm5, [rsp+0x40]
00007e2c933da0b9  vmovaps xmm6, [rsp+0x50]
00007e2c933da0bf  vmovaps xmm7, [rsp+0x60]
00007e2c933da0c5  vmovaps xmm8, [rsp+0x70]
00007e2c933da0cb  vmovaps xmm9, [rsp+0x80]
00007e2c933da0d4  vmovaps xmm10, [rsp+0x90]
00007e2c933da0dd  vmovaps xmm11, [rsp+0xA0]
00007e2c933da0e6  vmovaps xmm12, [rsp+0xB0]
00007e2c933da0ef  vmovaps xmm13, [rsp+0xC0]
00007e2c933da0f8  vmovaps xmm14, [rsp+0xD0]
00007e2c933da101  vmovaps xmm15, [rsp+0xE0]
00007e2c933da10a  add rsp, 0xF0
00007e2c933da111  pop r11
00007e2c933da113  pop r10
00007e2c933da115  pop r9
00007e2c933da117  pop r8
00007e2c933da119  pop rsi
00007e2c933da11a  pop rdi
00007e2c933da11b  pop rdx
00007e2c933da11c  pop rcx
00007e2c933da11d  pop rax
00007e2c933da11e  add rsp, 0x08
00007e2c933da122  jmp 0x00007E2C933D8C68
00007e2c933da127  sub rsp, 0x08
00007e2c933da12b  push rax
00007e2c933da12c  push rcx
00007e2c933da12d  push rdx
00007e2c933da12e  push rdi
00007e2c933da12f  push rsi
00007e2c933da130  push r8
00007e2c933da132  push r9
00007e2c933da134  push r10
00007e2c933da136  push r11
00007e2c933da138  sub rsp, 0xF0
00007e2c933da13f  vmovaps [rsp], xmm0
00007e2c933da144  vmovaps [rsp+0x10], xmm1
00007e2c933da14a  vmovaps [rsp+0x20], xmm2
00007e2c933da150  vmovaps [rsp+0x30], xmm3
00007e2c933da156  vmovaps [rsp+0x40], xmm4
00007e2c933da15c  vmovaps [rsp+0x50], xmm6
00007e2c933da162  vmovaps [rsp+0x60], xmm7
00007e2c933da168  vmovaps [rsp+0x70], xmm8
00007e2c933da16e  vmovaps [rsp+0x80], xmm9
00007e2c933da177  vmovaps [rsp+0x90], xmm10
00007e2c933da180  vmovaps [rsp+0xA0], xmm11
00007e2c933da189  vmovaps [rsp+0xB0], xmm12
00007e2c933da192  vmovaps [rsp+0xC0], xmm13
00007e2c933da19b  vmovaps [rsp+0xD0], xmm14
00007e2c933da1a4  vmovaps [rsp+0xE0], xmm15
00007e2c933da1ad  sub rsp, 0x30
00007e2c933da1b1  movaps [rsp], xmm5
00007e2c933da1b5  movaps [rsp+0x10], xmm8
00007e2c933da1bb  movaps [rsp+0x20], xmm15
00007e2c933da1c1  lea rdi, [rsp]
00007e2c933da1c5  mov esi, 0x00
00007e2c933da1ca  mov rax, 0x5A263F1C7530
00007e2c933da1d4  call rax
00007e2c933da1d6  movaps xmm5, [rsp]
00007e2c933da1da  add rsp, 0x30
00007e2c933da1de  vmovaps xmm0, [rsp]
00007e2c933da1e3  vmovaps xmm1, [rsp+0x10]
00007e2c933da1e9  vmovaps xmm2, [rsp+0x20]
00007e2c933da1ef  vmovaps xmm3, [rsp+0x30]
00007e2c933da1f5  vmovaps xmm4, [rsp+0x40]
00007e2c933da1fb  vmovaps xmm6, [rsp+0x50]
00007e2c933da201  vmovaps xmm7, [rsp+0x60]
00007e2c933da207  vmovaps xmm8, [rsp+0x70]
00007e2c933da20d  vmovaps xmm9, [rsp+0x80]
00007e2c933da216  vmovaps xmm10, [rsp+0x90]
00007e2c933da21f  vmovaps xmm11, [rsp+0xA0]
00007e2c933da228  vmovaps xmm12, [rsp+0xB0]
00007e2c933da231  vmovaps xmm13, [rsp+0xC0]
00007e2c933da23a  vmovaps xmm14, [rsp+0xD0]
00007e2c933da243  vmovaps xmm15, [rsp+0xE0]
00007e2c933da24c  add rsp, 0xF0
00007e2c933da253  pop r11
00007e2c933da255  pop r10
00007e2c933da257  pop r9
00007e2c933da259  pop r8
00007e2c933da25b  pop rsi
00007e2c933da25c  pop rdi
00007e2c933da25d  pop rdx
00007e2c933da25e  pop rcx
00007e2c933da25f  pop rax
00007e2c933da260  add rsp, 0x08
00007e2c933da264  jmp 0x00007E2C933D8CA0
00007e2c933da269  sub rsp, 0x08
00007e2c933da26d  push rax
00007e2c933da26e  push rcx
00007e2c933da26f  push rdx
00007e2c933da270  push rdi
00007e2c933da271  push rsi
00007e2c933da272  push r8
00007e2c933da274  push r9
00007e2c933da276  push r10
00007e2c933da278  push r11
00007e2c933da27a  sub rsp, 0xF0
00007e2c933da281  vmovaps [rsp], xmm0
00007e2c933da286  vmovaps [rsp+0x10], xmm1
00007e2c933da28c  vmovaps [rsp+0x20], xmm2
00007e2c933da292  vmovaps [rsp+0x30], xmm3
00007e2c933da298  vmovaps [rsp+0x40], xmm5
00007e2c933da29e  vmovaps [rsp+0x50], xmm6
00007e2c933da2a4  vmovaps [rsp+0x60], xmm7
00007e2c933da2aa  vmovaps [rsp+0x70], xmm8
00007e2c933da2b0  vmovaps [rsp+0x80], xmm9
00007e2c933da2b9  vmovaps [rsp+0x90], xmm10
00007e2c933da2c2  vmovaps [rsp+0xA0], xmm11
00007e2c933da2cb  vmovaps [rsp+0xB0], xmm12
00007e2c933da2d4  vmovaps [rsp+0xC0], xmm13
00007e2c933da2dd  vmovaps [rsp+0xD0], xmm14
00007e2c933da2e6  vmovaps [rsp+0xE0], xmm15
00007e2c933da2ef  sub rsp, 0x30
00007e2c933da2f3  movaps [rsp], xmm4
00007e2c933da2f7  movaps [rsp+0x10], xmm9
00007e2c933da2fd  movaps [rsp+0x20], xmm8
00007e2c933da303  lea rdi, [rsp]
00007e2c933da307  mov esi, 0x00
00007e2c933da30c  mov rax, 0x5A263F1C7530
00007e2c933da316  call rax
00007e2c933da318  movaps xmm4, [rsp]
00007e2c933da31c  add rsp, 0x30
00007e2c933da320  vmovaps xmm0, [rsp]
00007e2c933da325  vmovaps xmm1, [rsp+0x10]
00007e2c933da32b  vmovaps xmm2, [rsp+0x20]
00007e2c933da331  vmovaps xmm3, [rsp+0x30]
00007e2c933da337  vmovaps xmm5, [rsp+0x40]
00007e2c933da33d  vmovaps xmm6, [rsp+0x50]
00007e2c933da343  vmovaps xmm7, [rsp+0x60]
00007e2c933da349  vmovaps xmm8, [rsp+0x70]
00007e2c933da34f  vmovaps xmm9, [rsp+0x80]
00007e2c933da358  vmovaps xmm10, [rsp+0x90]
00007e2c933da361  vmovaps xmm11, [rsp+0xA0]
00007e2c933da36a  vmovaps xmm12, [rsp+0xB0]
00007e2c933da373  vmovaps xmm13, [rsp+0xC0]
00007e2c933da37c  vmovaps xmm14, [rsp+0xD0]
00007e2c933da385  vmovaps xmm15, [rsp+0xE0]
00007e2c933da38e  add rsp, 0xF0
00007e2c933da395  pop r11
00007e2c933da397  pop r10
00007e2c933da399  pop r9
00007e2c933da39b  pop r8
00007e2c933da39d  pop rsi
00007e2c933da39e  pop rdi
00007e2c933da39f  pop rdx
00007e2c933da3a0  pop rcx
00007e2c933da3a1  pop rax
00007e2c933da3a2  add rsp, 0x08
00007e2c933da3a6  jmp 0x00007E2C933D8CC1
00007e2c933da3ab  sub rsp, 0x08
00007e2c933da3af  push rax
00007e2c933da3b0  push rcx
00007e2c933da3b1  push rdx
00007e2c933da3b2  push rdi
00007e2c933da3b3  push rsi
00007e2c933da3b4  push r8
00007e2c933da3b6  push r9
00007e2c933da3b8  push r10
00007e2c933da3ba  push r11
00007e2c933da3bc  sub rsp, 0xF0
00007e2c933da3c3  vmovaps [rsp], xmm0
00007e2c933da3c8  vmovaps [rsp+0x10], xmm1
00007e2c933da3ce  vmovaps [rsp+0x20], xmm2
00007e2c933da3d4  vmovaps [rsp+0x30], xmm3
00007e2c933da3da  vmovaps [rsp+0x40], xmm4
00007e2c933da3e0  vmovaps [rsp+0x50], xmm5
00007e2c933da3e6  vmovaps [rsp+0x60], xmm6
00007e2c933da3ec  vmovaps [rsp+0x70], xmm7
00007e2c933da3f2  vmovaps [rsp+0x80], xmm8
00007e2c933da3fb  vmovaps [rsp+0x90], xmm10
00007e2c933da404  vmovaps [rsp+0xA0], xmm11
00007e2c933da40d  vmovaps [rsp+0xB0], xmm12
00007e2c933da416  vmovaps [rsp+0xC0], xmm13
00007e2c933da41f  vmovaps [rsp+0xD0], xmm14
00007e2c933da428  vmovaps [rsp+0xE0], xmm15
00007e2c933da431  sub rsp, 0x30
00007e2c933da435  movaps [rsp], xmm9
00007e2c933da43a  movaps [rsp+0x10], xmm10
00007e2c933da440  movaps [rsp+0x20], xmm8
00007e2c933da446  lea rdi, [rsp]
00007e2c933da44a  mov esi, 0x00
00007e2c933da44f  mov rax, 0x5A263F1C7530
00007e2c933da459  call rax
00007e2c933da45b  movaps xmm9, [rsp]
00007e2c933da460  add rsp, 0x30
00007e2c933da464  vmovaps xmm0, [rsp]
00007e2c933da469  vmovaps xmm1, [rsp+0x10]
00007e2c933da46f  vmovaps xmm2, [rsp+0x20]
00007e2c933da475  vmovaps xmm3, [rsp+0x30]
00007e2c933da47b  vmovaps xmm4, [rsp+0x40]
00007e2c933da481  vmovaps xmm5, [rsp+0x50]
00007e2c933da487  vmovaps xmm6, [rsp+0x60]
00007e2c933da48d  vmovaps xmm7, [rsp+0x70]
00007e2c933da493  vmovaps xmm8, [rsp+0x80]
00007e2c933da49c  vmovaps xmm10, [rsp+0x90]
00007e2c933da4a5  vmovaps xmm11, [rsp+0xA0]
00007e2c933da4ae  vmovaps xmm12, [rsp+0xB0]
00007e2c933da4b7  vmovaps xmm13, [rsp+0xC0]
00007e2c933da4c0  vmovaps xmm14, [rsp+0xD0]
00007e2c933da4c9  vmovaps xmm15, [rsp+0xE0]
00007e2c933da4d2  add rsp, 0xF0
00007e2c933da4d9  pop r11
00007e2c933da4db  pop r10
00007e2c933da4dd  pop r9
00007e2c933da4df  pop r8
00007e2c933da4e1  pop rsi
00007e2c933da4e2  pop rdi
00007e2c933da4e3  pop rdx
00007e2c933da4e4  pop rcx
00007e2c933da4e5  pop rax
00007e2c933da4e6  add rsp, 0x08
00007e2c933da4ea  jmp 0x00007E2C933D8CDB
00007e2c933da4ef  call 0x00007E2C932D64F0
00007e2c933da4f4  jmp 0x00007E2C933D8DF5
00007e2c933da4f9  call 0x00007E2C932D64F0
00007e2c933da4fe  jmp 0x00007E2C933D8E0B
00007e2c933da503  sub rsp, 0x08
00007e2c933da507  push rax
00007e2c933da508  push rcx
00007e2c933da509  push rdx
00007e2c933da50a  push rdi
00007e2c933da50b  push rsi
00007e2c933da50c  push r8
00007e2c933da50e  push r9
00007e2c933da510  push r10
00007e2c933da512  push r11
00007e2c933da514  sub rsp, 0xF0
00007e2c933da51b  vmovaps [rsp], xmm0
00007e2c933da520  vmovaps [rsp+0x10], xmm2
00007e2c933da526  vmovaps [rsp+0x20], xmm3
00007e2c933da52c  vmovaps [rsp+0x30], xmm4
00007e2c933da532  vmovaps [rsp+0x40], xmm5
00007e2c933da538  vmovaps [rsp+0x50], xmm6
00007e2c933da53e  vmovaps [rsp+0x60], xmm7
00007e2c933da544  vmovaps [rsp+0x70], xmm8
00007e2c933da54a  vmovaps [rsp+0x80], xmm9
00007e2c933da553  vmovaps [rsp+0x90], xmm10
00007e2c933da55c  vmovaps [rsp+0xA0], xmm11
00007e2c933da565  vmovaps [rsp+0xB0], xmm12
00007e2c933da56e  vmovaps [rsp+0xC0], xmm13
00007e2c933da577  vmovaps [rsp+0xD0], xmm14
00007e2c933da580  vmovaps [rsp+0xE0], xmm15
00007e2c933da589  sub rsp, 0x30
00007e2c933da58d  movaps [rsp], xmm1
00007e2c933da591  movaps [rsp+0x10], xmm6
00007e2c933da596  movaps [rsp+0x20], xmm15
00007e2c933da59c  lea rdi, [rsp]
00007e2c933da5a0  mov esi, 0x00
00007e2c933da5a5  mov rax, 0x5A263F1C7530
00007e2c933da5af  call rax
00007e2c933da5b1  movaps xmm1, [rsp]
00007e2c933da5b5  add rsp, 0x30
00007e2c933da5b9  vmovaps xmm0, [rsp]
00007e2c933da5be  vmovaps xmm2, [rsp+0x10]
00007e2c933da5c4  vmovaps xmm3, [rsp+0x20]
00007e2c933da5ca  vmovaps xmm4, [rsp+0x30]
00007e2c933da5d0  vmovaps xmm5, [rsp+0x40]
00007e2c933da5d6  vmovaps xmm6, [rsp+0x50]
00007e2c933da5dc  vmovaps xmm7, [rsp+0x60]
00007e2c933da5e2  vmovaps xmm8, [rsp+0x70]
00007e2c933da5e8  vmovaps xmm9, [rsp+0x80]
00007e2c933da5f1  vmovaps xmm10, [rsp+0x90]
00007e2c933da5fa  vmovaps xmm11, [rsp+0xA0]
00007e2c933da603  vmovaps xmm12, [rsp+0xB0]
00007e2c933da60c  vmovaps xmm13, [rsp+0xC0]
00007e2c933da615  vmovaps xmm14, [rsp+0xD0]
00007e2c933da61e  vmovaps xmm15, [rsp+0xE0]
00007e2c933da627  add rsp, 0xF0
00007e2c933da62e  pop r11
00007e2c933da630  pop r10
00007e2c933da632  pop r9
00007e2c933da634  pop r8
00007e2c933da636  pop rsi
00007e2c933da637  pop rdi
00007e2c933da638  pop rdx
00007e2c933da639  pop rcx
00007e2c933da63a  pop rax
00007e2c933da63b  add rsp, 0x08
00007e2c933da63f  jmp 0x00007E2C933D8E48
00007e2c933da644  call 0x00007E2C932E5820
00007e2c933da649  jmp 0x00007E2C933D8E55
00007e2c933da64e  sub rsp, 0x08
00007e2c933da652  push rax
00007e2c933da653  push rcx
00007e2c933da654  push rdx
00007e2c933da655  push rdi
00007e2c933da656  push rsi
00007e2c933da657  push r8
00007e2c933da659  push r9
00007e2c933da65b  push r10
00007e2c933da65d  push r11
00007e2c933da65f  sub rsp, 0xF0
00007e2c933da666  vmovaps [rsp], xmm0
00007e2c933da66b  vmovaps [rsp+0x10], xmm1
00007e2c933da671  vmovaps [rsp+0x20], xmm2
00007e2c933da677  vmovaps [rsp+0x30], xmm3
00007e2c933da67d  vmovaps [rsp+0x40], xmm4
00007e2c933da683  vmovaps [rsp+0x50], xmm5
00007e2c933da689  vmovaps [rsp+0x60], xmm6
00007e2c933da68f  vmovaps [rsp+0x70], xmm7
00007e2c933da695  vmovaps [rsp+0x80], xmm8
00007e2c933da69e  vmovaps [rsp+0x90], xmm9
00007e2c933da6a7  vmovaps [rsp+0xA0], xmm10
00007e2c933da6b0  vmovaps [rsp+0xB0], xmm11
00007e2c933da6b9  vmovaps [rsp+0xC0], xmm12
00007e2c933da6c2  vmovaps [rsp+0xD0], xmm13
00007e2c933da6cb  vmovaps [rsp+0xE0], xmm15
00007e2c933da6d4  sub rsp, 0x30
00007e2c933da6d8  movaps [rsp], xmm14
00007e2c933da6dd  movaps [rsp+0x10], xmm4
00007e2c933da6e2  movaps [rsp+0x20], xmm3
00007e2c933da6e7  lea rdi, [rsp]
00007e2c933da6eb  mov esi, 0x00
00007e2c933da6f0  mov rax, 0x5A263F1C7530
00007e2c933da6fa  call rax
00007e2c933da6fc  movaps xmm14, [rsp]
00007e2c933da701  add rsp, 0x30
00007e2c933da705  vmovaps xmm0, [rsp]
00007e2c933da70a  vmovaps xmm1, [rsp+0x10]
00007e2c933da710  vmovaps xmm2, [rsp+0x20]
00007e2c933da716  vmovaps xmm3, [rsp+0x30]
00007e2c933da71c  vmovaps xmm4, [rsp+0x40]
00007e2c933da722  vmovaps xmm5, [rsp+0x50]
00007e2c933da728  vmovaps xmm6, [rsp+0x60]
00007e2c933da72e  vmovaps xmm7, [rsp+0x70]
00007e2c933da734  vmovaps xmm8, [rsp+0x80]
00007e2c933da73d  vmovaps xmm9, [rsp+0x90]
00007e2c933da746  vmovaps xmm10, [rsp+0xA0]
00007e2c933da74f  vmovaps xmm11, [rsp+0xB0]
00007e2c933da758  vmovaps xmm12, [rsp+0xC0]
00007e2c933da761  vmovaps xmm13, [rsp+0xD0]
00007e2c933da76a  vmovaps xmm15, [rsp+0xE0]
00007e2c933da773  add rsp, 0xF0
00007e2c933da77a  pop r11
00007e2c933da77c  pop r10
00007e2c933da77e  pop r9
00007e2c933da780  pop r8
00007e2c933da782  pop rsi
00007e2c933da783  pop rdi
00007e2c933da784  pop rdx
00007e2c933da785  pop rcx
00007e2c933da786  pop rax
00007e2c933da787  add rsp, 0x08
00007e2c933da78b  jmp 0x00007E2C933D8E6F
00007e2c933da790  sub rsp, 0x08
00007e2c933da794  push rax
00007e2c933da795  push rcx
00007e2c933da796  push rdx
00007e2c933da797  push rdi
00007e2c933da798  push rsi
00007e2c933da799  push r8
00007e2c933da79b  push r9
00007e2c933da79d  push r10
00007e2c933da79f  push r11
00007e2c933da7a1  sub rsp, 0xF0
00007e2c933da7a8  vmovaps [rsp], xmm0
00007e2c933da7ad  vmovaps [rsp+0x10], xmm1
00007e2c933da7b3  vmovaps [rsp+0x20], xmm2
00007e2c933da7b9  vmovaps [rsp+0x30], xmm3
00007e2c933da7bf  vmovaps [rsp+0x40], xmm4
00007e2c933da7c5  vmovaps [rsp+0x50], xmm5
00007e2c933da7cb  vmovaps [rsp+0x60], xmm7
00007e2c933da7d1  vmovaps [rsp+0x70], xmm8
00007e2c933da7d7  vmovaps [rsp+0x80], xmm9
00007e2c933da7e0  vmovaps [rsp+0x90], xmm10
00007e2c933da7e9  vmovaps [rsp+0xA0], xmm11
00007e2c933da7f2  vmovaps [rsp+0xB0], xmm12
00007e2c933da7fb  vmovaps [rsp+0xC0], xmm13
00007e2c933da804  vmovaps [rsp+0xD0], xmm14
00007e2c933da80d  vmovaps [rsp+0xE0], xmm15
00007e2c933da816  sub rsp, 0x30
00007e2c933da81a  movaps [rsp], xmm6
00007e2c933da81e  movaps [rsp+0x10], xmm9
00007e2c933da824  movaps [rsp+0x20], xmm7
00007e2c933da829  lea rdi, [rsp]
00007e2c933da82d  mov esi, 0x00
00007e2c933da832  mov rax, 0x5A263F1C7530
00007e2c933da83c  call rax
00007e2c933da83e  movaps xmm6, [rsp]
00007e2c933da842  add rsp, 0x30
00007e2c933da846  vmovaps xmm0, [rsp]
00007e2c933da84b  vmovaps xmm1, [rsp+0x10]
00007e2c933da851  vmovaps xmm2, [rsp+0x20]
00007e2c933da857  vmovaps xmm3, [rsp+0x30]
00007e2c933da85d  vmovaps xmm4, [rsp+0x40]
00007e2c933da863  vmovaps xmm5, [rsp+0x50]
00007e2c933da869  vmovaps xmm7, [rsp+0x60]
00007e2c933da86f  vmovaps xmm8, [rsp+0x70]
00007e2c933da875  vmovaps xmm9, [rsp+0x80]
00007e2c933da87e  vmovaps xmm10, [rsp+0x90]
00007e2c933da887  vmovaps xmm11, [rsp+0xA0]
00007e2c933da890  vmovaps xmm12, [rsp+0xB0]
00007e2c933da899  vmovaps xmm13, [rsp+0xC0]
00007e2c933da8a2  vmovaps xmm14, [rsp+0xD0]
00007e2c933da8ab  vmovaps xmm15, [rsp+0xE0]
00007e2c933da8b4  add rsp, 0xF0
00007e2c933da8bb  pop r11
00007e2c933da8bd  pop r10
00007e2c933da8bf  pop r9
00007e2c933da8c1  pop r8
00007e2c933da8c3  pop rsi
00007e2c933da8c4  pop rdi
00007e2c933da8c5  pop rdx
00007e2c933da8c6  pop rcx
00007e2c933da8c7  pop rax
00007e2c933da8c8  add rsp, 0x08
00007e2c933da8cc  jmp 0x00007E2C933D8E87
00007e2c933da8d1  sub rsp, 0x08
00007e2c933da8d5  push rax
00007e2c933da8d6  push rcx
00007e2c933da8d7  push rdx
00007e2c933da8d8  push rdi
00007e2c933da8d9  push rsi
00007e2c933da8da  push r8
00007e2c933da8dc  push r9
00007e2c933da8de  push r10
00007e2c933da8e0  push r11
00007e2c933da8e2  sub rsp, 0xF0
00007e2c933da8e9  vmovaps [rsp], xmm0
00007e2c933da8ee  vmovaps [rsp+0x10], xmm1
00007e2c933da8f4  vmovaps [rsp+0x20], xmm2
00007e2c933da8fa  vmovaps [rsp+0x30], xmm3
00007e2c933da900  vmovaps [rsp+0x40], xmm4
00007e2c933da906  vmovaps [rsp+0x50], xmm5
00007e2c933da90c  vmovaps [rsp+0x60], xmm6
00007e2c933da912  vmovaps [rsp+0x70], xmm8
00007e2c933da918  vmovaps [rsp+0x80], xmm9
00007e2c933da921  vmovaps [rsp+0x90], xmm10
00007e2c933da92a  vmovaps [rsp+0xA0], xmm11
00007e2c933da933  vmovaps [rsp+0xB0], xmm12
00007e2c933da93c  vmovaps [rsp+0xC0], xmm13
00007e2c933da945  vmovaps [rsp+0xD0], xmm14
00007e2c933da94e  vmovaps [rsp+0xE0], xmm15
00007e2c933da957  sub rsp, 0x30
00007e2c933da95b  movaps [rsp], xmm7
00007e2c933da95f  movaps [rsp+0x10], xmm4
00007e2c933da964  movaps [rsp+0x20], xmm9
00007e2c933da96a  lea rdi, [rsp]
00007e2c933da96e  mov esi, 0x00
00007e2c933da973  mov rax, 0x5A263F1C7530
00007e2c933da97d  call rax
00007e2c933da97f  movaps xmm7, [rsp]
00007e2c933da983  add rsp, 0x30
00007e2c933da987  vmovaps xmm0, [rsp]
00007e2c933da98c  vmovaps xmm1, [rsp+0x10]
00007e2c933da992  vmovaps xmm2, [rsp+0x20]
00007e2c933da998  vmovaps xmm3, [rsp+0x30]
00007e2c933da99e  vmovaps xmm4, [rsp+0x40]
00007e2c933da9a4  vmovaps xmm5, [rsp+0x50]
00007e2c933da9aa  vmovaps xmm6, [rsp+0x60]
00007e2c933da9b0  vmovaps xmm8, [rsp+0x70]
00007e2c933da9b6  vmovaps xmm9, [rsp+0x80]
00007e2c933da9bf  vmovaps xmm10, [rsp+0x90]
00007e2c933da9c8  vmovaps xmm11, [rsp+0xA0]
00007e2c933da9d1  vmovaps xmm12, [rsp+0xB0]
00007e2c933da9da  vmovaps xmm13, [rsp+0xC0]
00007e2c933da9e3  vmovaps xmm14, [rsp+0xD0]
00007e2c933da9ec  vmovaps xmm15, [rsp+0xE0]
00007e2c933da9f5  add rsp, 0xF0
00007e2c933da9fc  pop r11
00007e2c933da9fe  pop r10
00007e2c933daa00  pop r9
00007e2c933daa02  pop r8
00007e2c933daa04  pop rsi
00007e2c933daa05  pop rdi
00007e2c933daa06  pop rdx
00007e2c933daa07  pop rcx
00007e2c933daa08  pop rax
00007e2c933daa09  add rsp, 0x08
00007e2c933daa0d  jmp 0x00007E2C933D8EB4
00007e2c933daa12  sub rsp, 0x08
00007e2c933daa16  push rax
00007e2c933daa17  push rcx
00007e2c933daa18  push rdx
00007e2c933daa19  push rdi
00007e2c933daa1a  push rsi
00007e2c933daa1b  push r8
00007e2c933daa1d  push r9
00007e2c933daa1f  push r10
00007e2c933daa21  push r11
00007e2c933daa23  sub rsp, 0xF0
00007e2c933daa2a  vmovaps [rsp], xmm0
00007e2c933daa2f  vmovaps [rsp+0x10], xmm1
00007e2c933daa35  vmovaps [rsp+0x20], xmm2
00007e2c933daa3b  vmovaps [rsp+0x30], xmm3
00007e2c933daa41  vmovaps [rsp+0x40], xmm5
00007e2c933daa47  vmovaps [rsp+0x50], xmm6
00007e2c933daa4d  vmovaps [rsp+0x60], xmm7
00007e2c933daa53  vmovaps [rsp+0x70], xmm8
00007e2c933daa59  vmovaps [rsp+0x80], xmm9
00007e2c933daa62  vmovaps [rsp+0x90], xmm10
00007e2c933daa6b  vmovaps [rsp+0xA0], xmm11
00007e2c933daa74  vmovaps [rsp+0xB0], xmm12
00007e2c933daa7d  vmovaps [rsp+0xC0], xmm13
00007e2c933daa86  vmovaps [rsp+0xD0], xmm14
00007e2c933daa8f  vmovaps [rsp+0xE0], xmm15
00007e2c933daa98  sub rsp, 0x30
00007e2c933daa9c  movaps [rsp], xmm4
00007e2c933daaa0  movaps [rsp+0x10], xmm15
00007e2c933daaa6  movaps [rsp+0x20], xmm9
00007e2c933daaac  lea rdi, [rsp]
00007e2c933daab0  mov esi, 0x00
00007e2c933daab5  mov rax, 0x5A263F1C7530
00007e2c933daabf  call rax
00007e2c933daac1  movaps xmm4, [rsp]
00007e2c933daac5  add rsp, 0x30
00007e2c933daac9  vmovaps xmm0, [rsp]
00007e2c933daace  vmovaps xmm1, [rsp+0x10]
00007e2c933daad4  vmovaps xmm2, [rsp+0x20]
00007e2c933daada  vmovaps xmm3, [rsp+0x30]
00007e2c933daae0  vmovaps xmm5, [rsp+0x40]
00007e2c933daae6  vmovaps xmm6, [rsp+0x50]
00007e2c933daaec  vmovaps xmm7, [rsp+0x60]
00007e2c933daaf2  vmovaps xmm8, [rsp+0x70]
00007e2c933daaf8  vmovaps xmm9, [rsp+0x80]
00007e2c933dab01  vmovaps xmm10, [rsp+0x90]
00007e2c933dab0a  vmovaps xmm11, [rsp+0xA0]
00007e2c933dab13  vmovaps xmm12, [rsp+0xB0]
00007e2c933dab1c  vmovaps xmm13, [rsp+0xC0]
00007e2c933dab25  vmovaps xmm14, [rsp+0xD0]
00007e2c933dab2e  vmovaps xmm15, [rsp+0xE0]
00007e2c933dab37  add rsp, 0xF0
00007e2c933dab3e  pop r11
00007e2c933dab40  pop r10
00007e2c933dab42  pop r9
00007e2c933dab44  pop r8
00007e2c933dab46  pop rsi
00007e2c933dab47  pop rdi
00007e2c933dab48  pop rdx
00007e2c933dab49  pop rcx
00007e2c933dab4a  pop rax
00007e2c933dab4b  add rsp, 0x08
00007e2c933dab4f  jmp 0x00007E2C933D8ED9
00007e2c933dab54  call 0x00007E2C932E5820
00007e2c933dab59  jmp 0x00007E2C933D8EE6
00007e2c933dab5e  sub rsp, 0x08
00007e2c933dab62  push rax
00007e2c933dab63  push rcx
00007e2c933dab64  push rdx
00007e2c933dab65  push rdi
00007e2c933dab66  push rsi
00007e2c933dab67  push r8
00007e2c933dab69  push r9
00007e2c933dab6b  push r10
00007e2c933dab6d  push r11
00007e2c933dab6f  sub rsp, 0xF0
00007e2c933dab76  vmovaps [rsp], xmm0
00007e2c933dab7b  vmovaps [rsp+0x10], xmm1
00007e2c933dab81  vmovaps [rsp+0x20], xmm2
00007e2c933dab87  vmovaps [rsp+0x30], xmm4
00007e2c933dab8d  vmovaps [rsp+0x40], xmm5
00007e2c933dab93  vmovaps [rsp+0x50], xmm6
00007e2c933dab99  vmovaps [rsp+0x60], xmm7
00007e2c933dab9f  vmovaps [rsp+0x70], xmm8
00007e2c933daba5  vmovaps [rsp+0x80], xmm9
00007e2c933dabae  vmovaps [rsp+0x90], xmm10
00007e2c933dabb7  vmovaps [rsp+0xA0], xmm11
00007e2c933dabc0  vmovaps [rsp+0xB0], xmm12
00007e2c933dabc9  vmovaps [rsp+0xC0], xmm13
00007e2c933dabd2  vmovaps [rsp+0xD0], xmm14
00007e2c933dabdb  vmovaps [rsp+0xE0], xmm15
00007e2c933dabe4  sub rsp, 0x30
00007e2c933dabe8  movaps [rsp], xmm3
00007e2c933dabec  movaps [rsp+0x10], xmm1
00007e2c933dabf1  movaps [rsp+0x20], xmm9
00007e2c933dabf7  lea rdi, [rsp]
00007e2c933dabfb  mov esi, 0x00
00007e2c933dac00  mov rax, 0x5A263F1C7530
00007e2c933dac0a  call rax
00007e2c933dac0c  movaps xmm3, [rsp]
00007e2c933dac10  add rsp, 0x30
00007e2c933dac14  vmovaps xmm0, [rsp]
00007e2c933dac19  vmovaps xmm1, [rsp+0x10]
00007e2c933dac1f  vmovaps xmm2, [rsp+0x20]
00007e2c933dac25  vmovaps xmm4, [rsp+0x30]
00007e2c933dac2b  vmovaps xmm5, [rsp+0x40]
00007e2c933dac31  vmovaps xmm6, [rsp+0x50]
00007e2c933dac37  vmovaps xmm7, [rsp+0x60]
00007e2c933dac3d  vmovaps xmm8, [rsp+0x70]
00007e2c933dac43  vmovaps xmm9, [rsp+0x80]
00007e2c933dac4c  vmovaps xmm10, [rsp+0x90]
00007e2c933dac55  vmovaps xmm11, [rsp+0xA0]
00007e2c933dac5e  vmovaps xmm12, [rsp+0xB0]
00007e2c933dac67  vmovaps xmm13, [rsp+0xC0]
00007e2c933dac70  vmovaps xmm14, [rsp+0xD0]
00007e2c933dac79  vmovaps xmm15, [rsp+0xE0]
00007e2c933dac82  add rsp, 0xF0
00007e2c933dac89  pop r11
00007e2c933dac8b  pop r10
00007e2c933dac8d  pop r9
00007e2c933dac8f  pop r8
00007e2c933dac91  pop rsi
00007e2c933dac92  pop rdi
00007e2c933dac93  pop rdx
00007e2c933dac94  pop rcx
00007e2c933dac95  pop rax
00007e2c933dac96  add rsp, 0x08
00007e2c933dac9a  jmp 0x00007E2C933D8F23
00007e2c933dac9f  sub rsp, 0x08
00007e2c933daca3  push rax
00007e2c933daca4  push rcx
00007e2c933daca5  push rdx
00007e2c933daca6  push rdi
00007e2c933daca7  push rsi
00007e2c933daca8  push r8
00007e2c933dacaa  push r9
00007e2c933dacac  push r10
00007e2c933dacae  push r11
00007e2c933dacb0  sub rsp, 0xF0
00007e2c933dacb7  vmovaps [rsp], xmm0
00007e2c933dacbc  vmovaps [rsp+0x10], xmm2
00007e2c933dacc2  vmovaps [rsp+0x20], xmm3
00007e2c933dacc8  vmovaps [rsp+0x30], xmm4
00007e2c933dacce  vmovaps [rsp+0x40], xmm5
00007e2c933dacd4  vmovaps [rsp+0x50], xmm6
00007e2c933dacda  vmovaps [rsp+0x60], xmm7
00007e2c933dace0  vmovaps [rsp+0x70], xmm8
00007e2c933dace6  vmovaps [rsp+0x80], xmm9
00007e2c933dacef  vmovaps [rsp+0x90], xmm10
00007e2c933dacf8  vmovaps [rsp+0xA0], xmm11
00007e2c933dad01  vmovaps [rsp+0xB0], xmm12
00007e2c933dad0a  vmovaps [rsp+0xC0], xmm13
00007e2c933dad13  vmovaps [rsp+0xD0], xmm14
00007e2c933dad1c  vmovaps [rsp+0xE0], xmm15
00007e2c933dad25  sub rsp, 0x30
00007e2c933dad29  movaps [rsp], xmm1
00007e2c933dad2d  movaps [rsp+0x10], xmm15
00007e2c933dad33  movaps [rsp+0x20], xmm9
00007e2c933dad39  lea rdi, [rsp]
00007e2c933dad3d  mov esi, 0x00
00007e2c933dad42  mov rax, 0x5A263F1C7530
00007e2c933dad4c  call rax
00007e2c933dad4e  movaps xmm1, [rsp]
00007e2c933dad52  add rsp, 0x30
00007e2c933dad56  vmovaps xmm0, [rsp]
00007e2c933dad5b  vmovaps xmm2, [rsp+0x10]
00007e2c933dad61  vmovaps xmm3, [rsp+0x20]
00007e2c933dad67  vmovaps xmm4, [rsp+0x30]
00007e2c933dad6d  vmovaps xmm5, [rsp+0x40]
00007e2c933dad73  vmovaps xmm6, [rsp+0x50]
00007e2c933dad79  vmovaps xmm7, [rsp+0x60]
00007e2c933dad7f  vmovaps xmm8, [rsp+0x70]
00007e2c933dad85  vmovaps xmm9, [rsp+0x80]
00007e2c933dad8e  vmovaps xmm10, [rsp+0x90]
00007e2c933dad97  vmovaps xmm11, [rsp+0xA0]
00007e2c933dada0  vmovaps xmm12, [rsp+0xB0]
00007e2c933dada9  vmovaps xmm13, [rsp+0xC0]
00007e2c933dadb2  vmovaps xmm14, [rsp+0xD0]
00007e2c933dadbb  vmovaps xmm15, [rsp+0xE0]
00007e2c933dadc4  add rsp, 0xF0
00007e2c933dadcb  pop r11
00007e2c933dadcd  pop r10
00007e2c933dadcf  pop r9
00007e2c933dadd1  pop r8
00007e2c933dadd3  pop rsi
00007e2c933dadd4  pop rdi
00007e2c933dadd5  pop rdx
00007e2c933dadd6  pop rcx
00007e2c933dadd7  pop rax
00007e2c933dadd8  add rsp, 0x08
00007e2c933daddc  jmp 0x00007E2C933D8FAB
00007e2c933dade1  call 0x00007E2C932E5820
00007e2c933dade6  jmp 0x00007E2C933D8FB8
00007e2c933dadeb  sub rsp, 0x08
00007e2c933dadef  push rax
00007e2c933dadf0  push rcx
00007e2c933dadf1  push rdx
00007e2c933dadf2  push rdi
00007e2c933dadf3  push rsi
00007e2c933dadf4  push r8
00007e2c933dadf6  push r9
00007e2c933dadf8  push r10
00007e2c933dadfa  push r11
00007e2c933dadfc  sub rsp, 0xF0
00007e2c933dae03  vmovaps [rsp], xmm0
00007e2c933dae08  vmovaps [rsp+0x10], xmm2
00007e2c933dae0e  vmovaps [rsp+0x20], xmm3
00007e2c933dae14  vmovaps [rsp+0x30], xmm4
00007e2c933dae1a  vmovaps [rsp+0x40], xmm5
00007e2c933dae20  vmovaps [rsp+0x50], xmm6
00007e2c933dae26  vmovaps [rsp+0x60], xmm7
00007e2c933dae2c  vmovaps [rsp+0x70], xmm8
00007e2c933dae32  vmovaps [rsp+0x80], xmm9
00007e2c933dae3b  vmovaps [rsp+0x90], xmm10
00007e2c933dae44  vmovaps [rsp+0xA0], xmm11
00007e2c933dae4d  vmovaps [rsp+0xB0], xmm12
00007e2c933dae56  vmovaps [rsp+0xC0], xmm13
00007e2c933dae5f  vmovaps [rsp+0xD0], xmm14
00007e2c933dae68  vmovaps [rsp+0xE0], xmm15
00007e2c933dae71  sub rsp, 0x30
00007e2c933dae75  movaps [rsp], xmm1
00007e2c933dae79  movaps [rsp+0x10], xmm5
00007e2c933dae7e  movaps [rsp+0x20], xmm7
00007e2c933dae83  lea rdi, [rsp]
00007e2c933dae87  mov esi, 0x00
00007e2c933dae8c  mov rax, 0x5A263F1C7530
00007e2c933dae96  call rax
00007e2c933dae98  movaps xmm1, [rsp]
00007e2c933dae9c  add rsp, 0x30
00007e2c933daea0  vmovaps xmm0, [rsp]
00007e2c933daea5  vmovaps xmm2, [rsp+0x10]
00007e2c933daeab  vmovaps xmm3, [rsp+0x20]
00007e2c933daeb1  vmovaps xmm4, [rsp+0x30]
00007e2c933daeb7  vmovaps xmm5, [rsp+0x40]
00007e2c933daebd  vmovaps xmm6, [rsp+0x50]
00007e2c933daec3  vmovaps xmm7, [rsp+0x60]
00007e2c933daec9  vmovaps xmm8, [rsp+0x70]
00007e2c933daecf  vmovaps xmm9, [rsp+0x80]
00007e2c933daed8  vmovaps xmm10, [rsp+0x90]
00007e2c933daee1  vmovaps xmm11, [rsp+0xA0]
00007e2c933daeea  vmovaps xmm12, [rsp+0xB0]
00007e2c933daef3  vmovaps xmm13, [rsp+0xC0]
00007e2c933daefc  vmovaps xmm14, [rsp+0xD0]
00007e2c933daf05  vmovaps xmm15, [rsp+0xE0]
00007e2c933daf0e  add rsp, 0xF0
00007e2c933daf15  pop r11
00007e2c933daf17  pop r10
00007e2c933daf19  pop r9
00007e2c933daf1b  pop r8
00007e2c933daf1d  pop rsi
00007e2c933daf1e  pop rdi
00007e2c933daf1f  pop rdx
00007e2c933daf20  pop rcx
00007e2c933daf21  pop rax
00007e2c933daf22  add rsp, 0x08
00007e2c933daf26  jmp 0x00007E2C933D905D
00007e2c933daf2b  sub rsp, 0x08
00007e2c933daf2f  push rax
00007e2c933daf30  push rcx
00007e2c933daf31  push rdx
00007e2c933daf32  push rdi
00007e2c933daf33  push rsi
00007e2c933daf34  push r8
00007e2c933daf36  push r9
00007e2c933daf38  push r10
00007e2c933daf3a  push r11
00007e2c933daf3c  sub rsp, 0xF0
00007e2c933daf43  vmovaps [rsp], xmm0
00007e2c933daf48  vmovaps [rsp+0x10], xmm1
00007e2c933daf4e  vmovaps [rsp+0x20], xmm2
00007e2c933daf54  vmovaps [rsp+0x30], xmm3
00007e2c933daf5a  vmovaps [rsp+0x40], xmm4
00007e2c933daf60  vmovaps [rsp+0x50], xmm5
00007e2c933daf66  vmovaps [rsp+0x60], xmm6
00007e2c933daf6c  vmovaps [rsp+0x70], xmm8
00007e2c933daf72  vmovaps [rsp+0x80], xmm9
00007e2c933daf7b  vmovaps [rsp+0x90], xmm10
00007e2c933daf84  vmovaps [rsp+0xA0], xmm11
00007e2c933daf8d  vmovaps [rsp+0xB0], xmm12
00007e2c933daf96  vmovaps [rsp+0xC0], xmm13
00007e2c933daf9f  vmovaps [rsp+0xD0], xmm14
00007e2c933dafa8  vmovaps [rsp+0xE0], xmm15
00007e2c933dafb1  sub rsp, 0x30
00007e2c933dafb5  movaps [rsp], xmm7
00007e2c933dafb9  movaps [rsp+0x10], xmm5
00007e2c933dafbe  movaps [rsp+0x20], xmm15
00007e2c933dafc4  lea rdi, [rsp]
00007e2c933dafc8  mov esi, 0x00
00007e2c933dafcd  mov rax, 0x5A263F1C7530
00007e2c933dafd7  call rax
00007e2c933dafd9  movaps xmm7, [rsp]
00007e2c933dafdd  add rsp, 0x30
00007e2c933dafe1  vmovaps xmm0, [rsp]
00007e2c933dafe6  vmovaps xmm1, [rsp+0x10]
00007e2c933dafec  vmovaps xmm2, [rsp+0x20]
00007e2c933daff2  vmovaps xmm3, [rsp+0x30]
00007e2c933daff8  vmovaps xmm4, [rsp+0x40]
00007e2c933daffe  vmovaps xmm5, [rsp+0x50]
00007e2c933db004  vmovaps xmm6, [rsp+0x60]
00007e2c933db00a  vmovaps xmm8, [rsp+0x70]
00007e2c933db010  vmovaps xmm9, [rsp+0x80]
00007e2c933db019  vmovaps xmm10, [rsp+0x90]
00007e2c933db022  vmovaps xmm11, [rsp+0xA0]
00007e2c933db02b  vmovaps xmm12, [rsp+0xB0]
00007e2c933db034  vmovaps xmm13, [rsp+0xC0]
00007e2c933db03d  vmovaps xmm14, [rsp+0xD0]
00007e2c933db046  vmovaps xmm15, [rsp+0xE0]
00007e2c933db04f  add rsp, 0xF0
00007e2c933db056  pop r11
00007e2c933db058  pop r10
00007e2c933db05a  pop r9
00007e2c933db05c  pop r8
00007e2c933db05e  pop rsi
00007e2c933db05f  pop rdi
00007e2c933db060  pop rdx
00007e2c933db061  pop rcx
00007e2c933db062  pop rax
00007e2c933db063  add rsp, 0x08
00007e2c933db067  jmp 0x00007E2C933D9093
00007e2c933db06c  call 0x00007E2C932D64F0
00007e2c933db071  jmp 0x00007E2C933D90A0
00007e2c933db076  sub rsp, 0x08
00007e2c933db07a  push rax
00007e2c933db07b  push rcx
00007e2c933db07c  push rdx
00007e2c933db07d  push rdi
00007e2c933db07e  push rsi
00007e2c933db07f  push r8
00007e2c933db081  push r9
00007e2c933db083  push r10
00007e2c933db085  push r11
00007e2c933db087  sub rsp, 0xF0
00007e2c933db08e  vmovaps [rsp], xmm0
00007e2c933db093  vmovaps [rsp+0x10], xmm1
00007e2c933db099  vmovaps [rsp+0x20], xmm2
00007e2c933db09f  vmovaps [rsp+0x30], xmm3
00007e2c933db0a5  vmovaps [rsp+0x40], xmm4
00007e2c933db0ab  vmovaps [rsp+0x50], xmm5
00007e2c933db0b1  vmovaps [rsp+0x60], xmm6
00007e2c933db0b7  vmovaps [rsp+0x70], xmm7
00007e2c933db0bd  vmovaps [rsp+0x80], xmm8
00007e2c933db0c6  vmovaps [rsp+0x90], xmm9
00007e2c933db0cf  vmovaps [rsp+0xA0], xmm10
00007e2c933db0d8  vmovaps [rsp+0xB0], xmm11
00007e2c933db0e1  vmovaps [rsp+0xC0], xmm12
00007e2c933db0ea  vmovaps [rsp+0xD0], xmm13
00007e2c933db0f3  vmovaps [rsp+0xE0], xmm14
00007e2c933db0fc  sub rsp, 0x30
00007e2c933db100  movaps [rsp], xmm15
00007e2c933db105  movaps [rsp+0x10], xmm5
00007e2c933db10a  movaps [rsp+0x20], xmm3
00007e2c933db10f  lea rdi, [rsp]
00007e2c933db113  mov esi, 0x00
00007e2c933db118  mov rax, 0x5A263F1C7530
00007e2c933db122  call rax
00007e2c933db124  movaps xmm15, [rsp]
00007e2c933db129  add rsp, 0x30
00007e2c933db12d  vmovaps xmm0, [rsp]
00007e2c933db132  vmovaps xmm1, [rsp+0x10]
00007e2c933db138  vmovaps xmm2, [rsp+0x20]
00007e2c933db13e  vmovaps xmm3, [rsp+0x30]
00007e2c933db144  vmovaps xmm4, [rsp+0x40]
00007e2c933db14a  vmovaps xmm5, [rsp+0x50]
00007e2c933db150  vmovaps xmm6, [rsp+0x60]
00007e2c933db156  vmovaps xmm7, [rsp+0x70]
00007e2c933db15c  vmovaps xmm8, [rsp+0x80]
00007e2c933db165  vmovaps xmm9, [rsp+0x90]
00007e2c933db16e  vmovaps xmm10, [rsp+0xA0]
00007e2c933db177  vmovaps xmm11, [rsp+0xB0]
00007e2c933db180  vmovaps xmm12, [rsp+0xC0]
00007e2c933db189  vmovaps xmm13, [rsp+0xD0]
00007e2c933db192  vmovaps xmm14, [rsp+0xE0]
00007e2c933db19b  add rsp, 0xF0
00007e2c933db1a2  pop r11
00007e2c933db1a4  pop r10
00007e2c933db1a6  pop r9
00007e2c933db1a8  pop r8
00007e2c933db1aa  pop rsi
00007e2c933db1ab  pop rdi
00007e2c933db1ac  pop rdx
00007e2c933db1ad  pop rcx
00007e2c933db1ae  pop rax
00007e2c933db1af  add rsp, 0x08
00007e2c933db1b3  jmp 0x00007E2C933D90C6
00007e2c933db1b8  sub rsp, 0x08
00007e2c933db1bc  push rax
00007e2c933db1bd  push rcx
00007e2c933db1be  push rdx
00007e2c933db1bf  push rdi
00007e2c933db1c0  push rsi
00007e2c933db1c1  push r8
00007e2c933db1c3  push r9
00007e2c933db1c5  push r10
00007e2c933db1c7  push r11
00007e2c933db1c9  sub rsp, 0xF0
00007e2c933db1d0  vmovaps [rsp], xmm0
00007e2c933db1d5  vmovaps [rsp+0x10], xmm2
00007e2c933db1db  vmovaps [rsp+0x20], xmm3
00007e2c933db1e1  vmovaps [rsp+0x30], xmm4
00007e2c933db1e7  vmovaps [rsp+0x40], xmm5
00007e2c933db1ed  vmovaps [rsp+0x50], xmm6
00007e2c933db1f3  vmovaps [rsp+0x60], xmm7
00007e2c933db1f9  vmovaps [rsp+0x70], xmm8
00007e2c933db1ff  vmovaps [rsp+0x80], xmm9
00007e2c933db208  vmovaps [rsp+0x90], xmm10
00007e2c933db211  vmovaps [rsp+0xA0], xmm11
00007e2c933db21a  vmovaps [rsp+0xB0], xmm12
00007e2c933db223  vmovaps [rsp+0xC0], xmm13
00007e2c933db22c  vmovaps [rsp+0xD0], xmm14
00007e2c933db235  vmovaps [rsp+0xE0], xmm15
00007e2c933db23e  sub rsp, 0x30
00007e2c933db242  movaps [rsp], xmm1
00007e2c933db246  movaps [rsp+0x10], xmm5
00007e2c933db24b  movaps [rsp+0x20], xmm4
00007e2c933db250  lea rdi, [rsp]
00007e2c933db254  mov esi, 0x00
00007e2c933db259  mov rax, 0x5A263F1C7530
00007e2c933db263  call rax
00007e2c933db265  movaps xmm1, [rsp]
00007e2c933db269  add rsp, 0x30
00007e2c933db26d  vmovaps xmm0, [rsp]
00007e2c933db272  vmovaps xmm2, [rsp+0x10]
00007e2c933db278  vmovaps xmm3, [rsp+0x20]
00007e2c933db27e  vmovaps xmm4, [rsp+0x30]
00007e2c933db284  vmovaps xmm5, [rsp+0x40]
00007e2c933db28a  vmovaps xmm6, [rsp+0x50]
00007e2c933db290  vmovaps xmm7, [rsp+0x60]
00007e2c933db296  vmovaps xmm8, [rsp+0x70]
00007e2c933db29c  vmovaps xmm9, [rsp+0x80]
00007e2c933db2a5  vmovaps xmm10, [rsp+0x90]
00007e2c933db2ae  vmovaps xmm11, [rsp+0xA0]
00007e2c933db2b7  vmovaps xmm12, [rsp+0xB0]
00007e2c933db2c0  vmovaps xmm13, [rsp+0xC0]
00007e2c933db2c9  vmovaps xmm14, [rsp+0xD0]
00007e2c933db2d2  vmovaps xmm15, [rsp+0xE0]
00007e2c933db2db  add rsp, 0xF0
00007e2c933db2e2  pop r11
00007e2c933db2e4  pop r10
00007e2c933db2e6  pop r9
00007e2c933db2e8  pop r8
00007e2c933db2ea  pop rsi
00007e2c933db2eb  pop rdi
00007e2c933db2ec  pop rdx
00007e2c933db2ed  pop rcx
00007e2c933db2ee  pop rax
00007e2c933db2ef  add rsp, 0x08
00007e2c933db2f3  jmp 0x00007E2C933D90E6
00007e2c933db2f8  sub rsp, 0x08
00007e2c933db2fc  push rax
00007e2c933db2fd  push rcx
00007e2c933db2fe  push rdx
00007e2c933db2ff  push rdi
00007e2c933db300  push rsi
00007e2c933db301  push r8
00007e2c933db303  push r9
00007e2c933db305  push r10
00007e2c933db307  push r11
00007e2c933db309  sub rsp, 0xF0
00007e2c933db310  vmovaps [rsp], xmm0
00007e2c933db315  vmovaps [rsp+0x10], xmm1
00007e2c933db31b  vmovaps [rsp+0x20], xmm2
00007e2c933db321  vmovaps [rsp+0x30], xmm3
00007e2c933db327  vmovaps [rsp+0x40], xmm5
00007e2c933db32d  vmovaps [rsp+0x50], xmm6
00007e2c933db333  vmovaps [rsp+0x60], xmm7
00007e2c933db339  vmovaps [rsp+0x70], xmm8
00007e2c933db33f  vmovaps [rsp+0x80], xmm9
00007e2c933db348  vmovaps [rsp+0x90], xmm10
00007e2c933db351  vmovaps [rsp+0xA0], xmm11
00007e2c933db35a  vmovaps [rsp+0xB0], xmm12
00007e2c933db363  vmovaps [rsp+0xC0], xmm13
00007e2c933db36c  vmovaps [rsp+0xD0], xmm14
00007e2c933db375  vmovaps [rsp+0xE0], xmm15
00007e2c933db37e  sub rsp, 0x30
00007e2c933db382  movaps [rsp], xmm4
00007e2c933db386  movaps [rsp+0x10], xmm3
00007e2c933db38b  movaps [rsp+0x20], xmm5
00007e2c933db390  lea rdi, [rsp]
00007e2c933db394  mov esi, 0x00
00007e2c933db399  mov rax, 0x5A263F1C7530
00007e2c933db3a3  call rax
00007e2c933db3a5  movaps xmm4, [rsp]
00007e2c933db3a9  add rsp, 0x30
00007e2c933db3ad  vmovaps xmm0, [rsp]
00007e2c933db3b2  vmovaps xmm1, [rsp+0x10]
00007e2c933db3b8  vmovaps xmm2, [rsp+0x20]
00007e2c933db3be  vmovaps xmm3, [rsp+0x30]
00007e2c933db3c4  vmovaps xmm5, [rsp+0x40]
00007e2c933db3ca  vmovaps xmm6, [rsp+0x50]
00007e2c933db3d0  vmovaps xmm7, [rsp+0x60]
00007e2c933db3d6  vmovaps xmm8, [rsp+0x70]
00007e2c933db3dc  vmovaps xmm9, [rsp+0x80]
00007e2c933db3e5  vmovaps xmm10, [rsp+0x90]
00007e2c933db3ee  vmovaps xmm11, [rsp+0xA0]
00007e2c933db3f7  vmovaps xmm12, [rsp+0xB0]
00007e2c933db400  vmovaps xmm13, [rsp+0xC0]
00007e2c933db409  vmovaps xmm14, [rsp+0xD0]
00007e2c933db412  vmovaps xmm15, [rsp+0xE0]
00007e2c933db41b  add rsp, 0xF0
00007e2c933db422  pop r11
00007e2c933db424  pop r10
00007e2c933db426  pop r9
00007e2c933db428  pop r8
00007e2c933db42a  pop rsi
00007e2c933db42b  pop rdi
00007e2c933db42c  pop rdx
00007e2c933db42d  pop rcx
00007e2c933db42e  pop rax
00007e2c933db42f  add rsp, 0x08
00007e2c933db433  jmp 0x00007E2C933D9134
00007e2c933db438  call 0x00007E2C932D64F0
00007e2c933db43d  jmp 0x00007E2C933D9141
00007e2c933db442  sub rsp, 0x08
00007e2c933db446  push rax
00007e2c933db447  push rcx
00007e2c933db448  push rdx
00007e2c933db449  push rdi
00007e2c933db44a  push rsi
00007e2c933db44b  push r8
00007e2c933db44d  push r9
00007e2c933db44f  push r10
00007e2c933db451  push r11
00007e2c933db453  sub rsp, 0xF0
00007e2c933db45a  vmovaps [rsp], xmm0
00007e2c933db45f  vmovaps [rsp+0x10], xmm1
00007e2c933db465  vmovaps [rsp+0x20], xmm2
00007e2c933db46b  vmovaps [rsp+0x30], xmm3
00007e2c933db471  vmovaps [rsp+0x40], xmm4
00007e2c933db477  vmovaps [rsp+0x50], xmm6
00007e2c933db47d  vmovaps [rsp+0x60], xmm7
00007e2c933db483  vmovaps [rsp+0x70], xmm8
00007e2c933db489  vmovaps [rsp+0x80], xmm9
00007e2c933db492  vmovaps [rsp+0x90], xmm10
00007e2c933db49b  vmovaps [rsp+0xA0], xmm11
00007e2c933db4a4  vmovaps [rsp+0xB0], xmm12
00007e2c933db4ad  vmovaps [rsp+0xC0], xmm13
00007e2c933db4b6  vmovaps [rsp+0xD0], xmm14
00007e2c933db4bf  vmovaps [rsp+0xE0], xmm15
00007e2c933db4c8  sub rsp, 0x30
00007e2c933db4cc  movaps [rsp], xmm5
00007e2c933db4d0  movaps [rsp+0x10], xmm6
00007e2c933db4d5  movaps [rsp+0x20], xmm3
00007e2c933db4da  lea rdi, [rsp]
00007e2c933db4de  mov esi, 0x00
00007e2c933db4e3  mov rax, 0x5A263F1C7530
00007e2c933db4ed  call rax
00007e2c933db4ef  movaps xmm5, [rsp]
00007e2c933db4f3  add rsp, 0x30
00007e2c933db4f7  vmovaps xmm0, [rsp]
00007e2c933db4fc  vmovaps xmm1, [rsp+0x10]
00007e2c933db502  vmovaps xmm2, [rsp+0x20]
00007e2c933db508  vmovaps xmm3, [rsp+0x30]
00007e2c933db50e  vmovaps xmm4, [rsp+0x40]
00007e2c933db514  vmovaps xmm6, [rsp+0x50]
00007e2c933db51a  vmovaps xmm7, [rsp+0x60]
00007e2c933db520  vmovaps xmm8, [rsp+0x70]
00007e2c933db526  vmovaps xmm9, [rsp+0x80]
00007e2c933db52f  vmovaps xmm10, [rsp+0x90]
00007e2c933db538  vmovaps xmm11, [rsp+0xA0]
00007e2c933db541  vmovaps xmm12, [rsp+0xB0]
00007e2c933db54a  vmovaps xmm13, [rsp+0xC0]
00007e2c933db553  vmovaps xmm14, [rsp+0xD0]
00007e2c933db55c  vmovaps xmm15, [rsp+0xE0]
00007e2c933db565  add rsp, 0xF0
00007e2c933db56c  pop r11
00007e2c933db56e  pop r10
00007e2c933db570  pop r9
00007e2c933db572  pop r8
00007e2c933db574  pop rsi
00007e2c933db575  pop rdi
00007e2c933db576  pop rdx
00007e2c933db577  pop rcx
00007e2c933db578  pop rax
00007e2c933db579  add rsp, 0x08
00007e2c933db57d  jmp 0x00007E2C933D9167
00007e2c933db582  sub rsp, 0x08
00007e2c933db586  push rax
00007e2c933db587  push rcx
00007e2c933db588  push rdx
00007e2c933db589  push rdi
00007e2c933db58a  push rsi
00007e2c933db58b  push r8
00007e2c933db58d  push r9
00007e2c933db58f  push r10
00007e2c933db591  push r11
00007e2c933db593  sub rsp, 0xF0
00007e2c933db59a  vmovaps [rsp], xmm0
00007e2c933db59f  vmovaps [rsp+0x10], xmm1
00007e2c933db5a5  vmovaps [rsp+0x20], xmm2
00007e2c933db5ab  vmovaps [rsp+0x30], xmm3
00007e2c933db5b1  vmovaps [rsp+0x40], xmm4
00007e2c933db5b7  vmovaps [rsp+0x50], xmm5
00007e2c933db5bd  vmovaps [rsp+0x60], xmm7
00007e2c933db5c3  vmovaps [rsp+0x70], xmm8
00007e2c933db5c9  vmovaps [rsp+0x80], xmm9
00007e2c933db5d2  vmovaps [rsp+0x90], xmm10
00007e2c933db5db  vmovaps [rsp+0xA0], xmm11
00007e2c933db5e4  vmovaps [rsp+0xB0], xmm12
00007e2c933db5ed  vmovaps [rsp+0xC0], xmm13
00007e2c933db5f6  vmovaps [rsp+0xD0], xmm14
00007e2c933db5ff  vmovaps [rsp+0xE0], xmm15
00007e2c933db608  sub rsp, 0x30
00007e2c933db60c  movaps [rsp], xmm6
00007e2c933db610  movaps [rsp+0x10], xmm9
00007e2c933db616  movaps [rsp+0x20], xmm1
00007e2c933db61b  lea rdi, [rsp]
00007e2c933db61f  mov esi, 0x00
00007e2c933db624  mov rax, 0x5A263F1C7530
00007e2c933db62e  call rax
00007e2c933db630  movaps xmm6, [rsp]
00007e2c933db634  add rsp, 0x30
00007e2c933db638  vmovaps xmm0, [rsp]
00007e2c933db63d  vmovaps xmm1, [rsp+0x10]
00007e2c933db643  vmovaps xmm2, [rsp+0x20]
00007e2c933db649  vmovaps xmm3, [rsp+0x30]
00007e2c933db64f  vmovaps xmm4, [rsp+0x40]
00007e2c933db655  vmovaps xmm5, [rsp+0x50]
00007e2c933db65b  vmovaps xmm7, [rsp+0x60]
00007e2c933db661  vmovaps xmm8, [rsp+0x70]
00007e2c933db667  vmovaps xmm9, [rsp+0x80]
00007e2c933db670  vmovaps xmm10, [rsp+0x90]
00007e2c933db679  vmovaps xmm11, [rsp+0xA0]
00007e2c933db682  vmovaps xmm12, [rsp+0xB0]
00007e2c933db68b  vmovaps xmm13, [rsp+0xC0]
00007e2c933db694  vmovaps xmm14, [rsp+0xD0]
00007e2c933db69d  vmovaps xmm15, [rsp+0xE0]
00007e2c933db6a6  add rsp, 0xF0
00007e2c933db6ad  pop r11
00007e2c933db6af  pop r10
00007e2c933db6b1  pop r9
00007e2c933db6b3  pop r8
00007e2c933db6b5  pop rsi
00007e2c933db6b6  pop rdi
00007e2c933db6b7  pop rdx
00007e2c933db6b8  pop rcx
00007e2c933db6b9  pop rax
00007e2c933db6ba  add rsp, 0x08
00007e2c933db6be  jmp 0x00007E2C933D918B
00007e2c933db6c3  sub rsp, 0x08
00007e2c933db6c7  push rax
00007e2c933db6c8  push rcx
00007e2c933db6c9  push rdx
00007e2c933db6ca  push rdi
00007e2c933db6cb  push rsi
00007e2c933db6cc  push r8
00007e2c933db6ce  push r9
00007e2c933db6d0  push r10
00007e2c933db6d2  push r11
00007e2c933db6d4  sub rsp, 0xF0
00007e2c933db6db  vmovaps [rsp], xmm0
00007e2c933db6e0  vmovaps [rsp+0x10], xmm1
00007e2c933db6e6  vmovaps [rsp+0x20], xmm2
00007e2c933db6ec  vmovaps [rsp+0x30], xmm3
00007e2c933db6f2  vmovaps [rsp+0x40], xmm4
00007e2c933db6f8  vmovaps [rsp+0x50], xmm5
00007e2c933db6fe  vmovaps [rsp+0x60], xmm6
00007e2c933db704  vmovaps [rsp+0x70], xmm7
00007e2c933db70a  vmovaps [rsp+0x80], xmm8
00007e2c933db713  vmovaps [rsp+0x90], xmm10
00007e2c933db71c  vmovaps [rsp+0xA0], xmm11
00007e2c933db725  vmovaps [rsp+0xB0], xmm12
00007e2c933db72e  vmovaps [rsp+0xC0], xmm13
00007e2c933db737  vmovaps [rsp+0xD0], xmm14
00007e2c933db740  vmovaps [rsp+0xE0], xmm15
00007e2c933db749  sub rsp, 0x30
00007e2c933db74d  movaps [rsp], xmm9
00007e2c933db752  movaps [rsp+0x10], xmm3
00007e2c933db757  movaps [rsp+0x20], xmm1
00007e2c933db75c  lea rdi, [rsp]
00007e2c933db760  mov esi, 0x00
00007e2c933db765  mov rax, 0x5A263F1C7530
00007e2c933db76f  call rax
00007e2c933db771  movaps xmm9, [rsp]
00007e2c933db776  add rsp, 0x30
00007e2c933db77a  vmovaps xmm0, [rsp]
00007e2c933db77f  vmovaps xmm1, [rsp+0x10]
00007e2c933db785  vmovaps xmm2, [rsp+0x20]
00007e2c933db78b  vmovaps xmm3, [rsp+0x30]
00007e2c933db791  vmovaps xmm4, [rsp+0x40]
00007e2c933db797  vmovaps xmm5, [rsp+0x50]
00007e2c933db79d  vmovaps xmm6, [rsp+0x60]
00007e2c933db7a3  vmovaps xmm7, [rsp+0x70]
00007e2c933db7a9  vmovaps xmm8, [rsp+0x80]
00007e2c933db7b2  vmovaps xmm10, [rsp+0x90]
00007e2c933db7bb  vmovaps xmm11, [rsp+0xA0]
00007e2c933db7c4  vmovaps xmm12, [rsp+0xB0]
00007e2c933db7cd  vmovaps xmm13, [rsp+0xC0]
00007e2c933db7d6  vmovaps xmm14, [rsp+0xD0]
00007e2c933db7df  vmovaps xmm15, [rsp+0xE0]
00007e2c933db7e8  add rsp, 0xF0
00007e2c933db7ef  pop r11
00007e2c933db7f1  pop r10
00007e2c933db7f3  pop r9
00007e2c933db7f5  pop r8
00007e2c933db7f7  pop rsi
00007e2c933db7f8  pop rdi
00007e2c933db7f9  pop rdx
00007e2c933db7fa  pop rcx
00007e2c933db7fb  pop rax
00007e2c933db7fc  add rsp, 0x08
00007e2c933db800  jmp 0x00007E2C933D91D7
00007e2c933db805  call 0x00007E2C932D64F0
00007e2c933db80a  jmp 0x00007E2C933D91E4
00007e2c933db80f  sub rsp, 0x08
00007e2c933db813  push rax
00007e2c933db814  push rcx
00007e2c933db815  push rdx
00007e2c933db816  push rdi
00007e2c933db817  push rsi
00007e2c933db818  push r8
00007e2c933db81a  push r9
00007e2c933db81c  push r10
00007e2c933db81e  push r11
00007e2c933db820  sub rsp, 0xF0
00007e2c933db827  vmovaps [rsp], xmm0
00007e2c933db82c  vmovaps [rsp+0x10], xmm1
00007e2c933db832  vmovaps [rsp+0x20], xmm2
00007e2c933db838  vmovaps [rsp+0x30], xmm3
00007e2c933db83e  vmovaps [rsp+0x40], xmm4
00007e2c933db844  vmovaps [rsp+0x50], xmm5
00007e2c933db84a  vmovaps [rsp+0x60], xmm6
00007e2c933db850  vmovaps [rsp+0x70], xmm7
00007e2c933db856  vmovaps [rsp+0x80], xmm8
00007e2c933db85f  vmovaps [rsp+0x90], xmm9
00007e2c933db868  vmovaps [rsp+0xA0], xmm10
00007e2c933db871  vmovaps [rsp+0xB0], xmm11
00007e2c933db87a  vmovaps [rsp+0xC0], xmm12
00007e2c933db883  vmovaps [rsp+0xD0], xmm13
00007e2c933db88c  vmovaps [rsp+0xE0], xmm14
00007e2c933db895  sub rsp, 0x30
00007e2c933db899  movaps [rsp], xmm15
00007e2c933db89e  movaps [rsp+0x10], xmm3
00007e2c933db8a3  movaps [rsp+0x20], xmm7
00007e2c933db8a8  lea rdi, [rsp]
00007e2c933db8ac  mov esi, 0x00
00007e2c933db8b1  mov rax, 0x5A263F1C7530
00007e2c933db8bb  call rax
00007e2c933db8bd  movaps xmm15, [rsp]
00007e2c933db8c2  add rsp, 0x30
00007e2c933db8c6  vmovaps xmm0, [rsp]
00007e2c933db8cb  vmovaps xmm1, [rsp+0x10]
00007e2c933db8d1  vmovaps xmm2, [rsp+0x20]
00007e2c933db8d7  vmovaps xmm3, [rsp+0x30]
00007e2c933db8dd  vmovaps xmm4, [rsp+0x40]
00007e2c933db8e3  vmovaps xmm5, [rsp+0x50]
00007e2c933db8e9  vmovaps xmm6, [rsp+0x60]
00007e2c933db8ef  vmovaps xmm7, [rsp+0x70]
00007e2c933db8f5  vmovaps xmm8, [rsp+0x80]
00007e2c933db8fe  vmovaps xmm9, [rsp+0x90]
00007e2c933db907  vmovaps xmm10, [rsp+0xA0]
00007e2c933db910  vmovaps xmm11, [rsp+0xB0]
00007e2c933db919  vmovaps xmm12, [rsp+0xC0]
00007e2c933db922  vmovaps xmm13, [rsp+0xD0]
00007e2c933db92b  vmovaps xmm14, [rsp+0xE0]
00007e2c933db934  add rsp, 0xF0
00007e2c933db93b  pop r11
00007e2c933db93d  pop r10
00007e2c933db93f  pop r9
00007e2c933db941  pop r8
00007e2c933db943  pop rsi
00007e2c933db944  pop rdi
00007e2c933db945  pop rdx
00007e2c933db946  pop rcx
00007e2c933db947  pop rax
00007e2c933db948  add rsp, 0x08
00007e2c933db94c  jmp 0x00007E2C933D9210
00007e2c933db951  sub rsp, 0x08
00007e2c933db955  push rax
00007e2c933db956  push rcx
00007e2c933db957  push rdx
00007e2c933db958  push rdi
00007e2c933db959  push rsi
00007e2c933db95a  push r8
00007e2c933db95c  push r9
00007e2c933db95e  push r10
00007e2c933db960  push r11
00007e2c933db962  sub rsp, 0xF0
00007e2c933db969  vmovaps [rsp], xmm0
00007e2c933db96e  vmovaps [rsp+0x10], xmm1
00007e2c933db974  vmovaps [rsp+0x20], xmm2
00007e2c933db97a  vmovaps [rsp+0x30], xmm4
00007e2c933db980  vmovaps [rsp+0x40], xmm5
00007e2c933db986  vmovaps [rsp+0x50], xmm6
00007e2c933db98c  vmovaps [rsp+0x60], xmm7
00007e2c933db992  vmovaps [rsp+0x70], xmm8
00007e2c933db998  vmovaps [rsp+0x80], xmm9
00007e2c933db9a1  vmovaps [rsp+0x90], xmm10
00007e2c933db9aa  vmovaps [rsp+0xA0], xmm11
00007e2c933db9b3  vmovaps [rsp+0xB0], xmm12
00007e2c933db9bc  vmovaps [rsp+0xC0], xmm13
00007e2c933db9c5  vmovaps [rsp+0xD0], xmm14
00007e2c933db9ce  vmovaps [rsp+0xE0], xmm15
00007e2c933db9d7  sub rsp, 0x30
00007e2c933db9db  movaps [rsp], xmm3
00007e2c933db9df  movaps [rsp+0x10], xmm1
00007e2c933db9e4  movaps [rsp+0x20], xmm15
00007e2c933db9ea  lea rdi, [rsp]
00007e2c933db9ee  mov esi, 0x00
00007e2c933db9f3  mov rax, 0x5A263F1C7530
00007e2c933db9fd  call rax
00007e2c933db9ff  movaps xmm3, [rsp]
00007e2c933dba03  add rsp, 0x30
00007e2c933dba07  vmovaps xmm0, [rsp]
00007e2c933dba0c  vmovaps xmm1, [rsp+0x10]
00007e2c933dba12  vmovaps xmm2, [rsp+0x20]
00007e2c933dba18  vmovaps xmm4, [rsp+0x30]
00007e2c933dba1e  vmovaps xmm5, [rsp+0x40]
00007e2c933dba24  vmovaps xmm6, [rsp+0x50]
00007e2c933dba2a  vmovaps xmm7, [rsp+0x60]
00007e2c933dba30  vmovaps xmm8, [rsp+0x70]
00007e2c933dba36  vmovaps xmm9, [rsp+0x80]
00007e2c933dba3f  vmovaps xmm10, [rsp+0x90]
00007e2c933dba48  vmovaps xmm11, [rsp+0xA0]
00007e2c933dba51  vmovaps xmm12, [rsp+0xB0]
00007e2c933dba5a  vmovaps xmm13, [rsp+0xC0]
00007e2c933dba63  vmovaps xmm14, [rsp+0xD0]
00007e2c933dba6c  vmovaps xmm15, [rsp+0xE0]
00007e2c933dba75  add rsp, 0xF0
00007e2c933dba7c  pop r11
00007e2c933dba7e  pop r10
00007e2c933dba80  pop r9
00007e2c933dba82  pop r8
00007e2c933dba84  pop rsi
00007e2c933dba85  pop rdi
00007e2c933dba86  pop rdx
00007e2c933dba87  pop rcx
00007e2c933dba88  pop rax
00007e2c933dba89  add rsp, 0x08
00007e2c933dba8d  jmp 0x00007E2C933D929F
00007e2c933dba92  call 0x00007E2C932D64F0
00007e2c933dba97  jmp 0x00007E2C933D92A9
00007e2c933dba9c  sub rsp, 0x08
00007e2c933dbaa0  push rax
00007e2c933dbaa1  push rcx
00007e2c933dbaa2  push rdx
00007e2c933dbaa3  push rdi
00007e2c933dbaa4  push rsi
00007e2c933dbaa5  push r8
00007e2c933dbaa7  push r9
00007e2c933dbaa9  push r10
00007e2c933dbaab  push r11
00007e2c933dbaad  sub rsp, 0xF0
00007e2c933dbab4  vmovaps [rsp], xmm0
00007e2c933dbab9  vmovaps [rsp+0x10], xmm1
00007e2c933dbabf  vmovaps [rsp+0x20], xmm2
00007e2c933dbac5  vmovaps [rsp+0x30], xmm3
00007e2c933dbacb  vmovaps [rsp+0x40], xmm4
00007e2c933dbad1  vmovaps [rsp+0x50], xmm5
00007e2c933dbad7  vmovaps [rsp+0x60], xmm6
00007e2c933dbadd  vmovaps [rsp+0x70], xmm7
00007e2c933dbae3  vmovaps [rsp+0x80], xmm8
00007e2c933dbaec  vmovaps [rsp+0x90], xmm9
00007e2c933dbaf5  vmovaps [rsp+0xA0], xmm10
00007e2c933dbafe  vmovaps [rsp+0xB0], xmm11
00007e2c933dbb07  vmovaps [rsp+0xC0], xmm12
00007e2c933dbb10  vmovaps [rsp+0xD0], xmm13
00007e2c933dbb19  vmovaps [rsp+0xE0], xmm14
00007e2c933dbb22  sub rsp, 0x30
00007e2c933dbb26  movaps [rsp], xmm15
00007e2c933dbb2b  movaps [rsp+0x10], xmm14
00007e2c933dbb31  movaps [rsp+0x20], xmm4
00007e2c933dbb36  lea rdi, [rsp]
00007e2c933dbb3a  mov esi, 0x00
00007e2c933dbb3f  mov rax, 0x5A263F1C7530
00007e2c933dbb49  call rax
00007e2c933dbb4b  movaps xmm15, [rsp]
00007e2c933dbb50  add rsp, 0x30
00007e2c933dbb54  vmovaps xmm0, [rsp]
00007e2c933dbb59  vmovaps xmm1, [rsp+0x10]
00007e2c933dbb5f  vmovaps xmm2, [rsp+0x20]
00007e2c933dbb65  vmovaps xmm3, [rsp+0x30]
00007e2c933dbb6b  vmovaps xmm4, [rsp+0x40]
00007e2c933dbb71  vmovaps xmm5, [rsp+0x50]
00007e2c933dbb77  vmovaps xmm6, [rsp+0x60]
00007e2c933dbb7d  vmovaps xmm7, [rsp+0x70]
00007e2c933dbb83  vmovaps xmm8, [rsp+0x80]
00007e2c933dbb8c  vmovaps xmm9, [rsp+0x90]
00007e2c933dbb95  vmovaps xmm10, [rsp+0xA0]
00007e2c933dbb9e  vmovaps xmm11, [rsp+0xB0]
00007e2c933dbba7  vmovaps xmm12, [rsp+0xC0]
00007e2c933dbbb0  vmovaps xmm13, [rsp+0xD0]
00007e2c933dbbb9  vmovaps xmm14, [rsp+0xE0]
00007e2c933dbbc2  add rsp, 0xF0
00007e2c933dbbc9  pop r11
00007e2c933dbbcb  pop r10
00007e2c933dbbcd  pop r9
00007e2c933dbbcf  pop r8
00007e2c933dbbd1  pop rsi
00007e2c933dbbd2  pop rdi
00007e2c933dbbd3  pop rdx
00007e2c933dbbd4  pop rcx
00007e2c933dbbd5  pop rax
00007e2c933dbbd6  add rsp, 0x08
00007e2c933dbbda  jmp 0x00007E2C933D92D7
00007e2c933dbbdf  sub rsp, 0x08
00007e2c933dbbe3  push rax
00007e2c933dbbe4  push rcx
00007e2c933dbbe5  push rdx
00007e2c933dbbe6  push rdi
00007e2c933dbbe7  push rsi
00007e2c933dbbe8  push r8
00007e2c933dbbea  push r9
00007e2c933dbbec  push r10
00007e2c933dbbee  push r11
00007e2c933dbbf0  sub rsp, 0xF0
00007e2c933dbbf7  vmovaps [rsp], xmm0
00007e2c933dbbfc  vmovaps [rsp+0x10], xmm1
00007e2c933dbc02  vmovaps [rsp+0x20], xmm2
00007e2c933dbc08  vmovaps [rsp+0x30], xmm3
00007e2c933dbc0e  vmovaps [rsp+0x40], xmm4
00007e2c933dbc14  vmovaps [rsp+0x50], xmm5
00007e2c933dbc1a  vmovaps [rsp+0x60], xmm6
00007e2c933dbc20  vmovaps [rsp+0x70], xmm7
00007e2c933dbc26  vmovaps [rsp+0x80], xmm8
00007e2c933dbc2f  vmovaps [rsp+0x90], xmm9
00007e2c933dbc38  vmovaps [rsp+0xA0], xmm10
00007e2c933dbc41  vmovaps [rsp+0xB0], xmm11
00007e2c933dbc4a  vmovaps [rsp+0xC0], xmm12
00007e2c933dbc53  vmovaps [rsp+0xD0], xmm13
00007e2c933dbc5c  vmovaps [rsp+0xE0], xmm15
00007e2c933dbc65  sub rsp, 0x30
00007e2c933dbc69  movaps [rsp], xmm14
00007e2c933dbc6e  movaps [rsp+0x10], xmm2
00007e2c933dbc73  movaps [rsp+0x20], xmm1
00007e2c933dbc78  lea rdi, [rsp]
00007e2c933dbc7c  mov esi, 0x00
00007e2c933dbc81  mov rax, 0x5A263F1C7530
00007e2c933dbc8b  call rax
00007e2c933dbc8d  movaps xmm14, [rsp]
00007e2c933dbc92  add rsp, 0x30
00007e2c933dbc96  vmovaps xmm0, [rsp]
00007e2c933dbc9b  vmovaps xmm1, [rsp+0x10]
00007e2c933dbca1  vmovaps xmm2, [rsp+0x20]
00007e2c933dbca7  vmovaps xmm3, [rsp+0x30]
00007e2c933dbcad  vmovaps xmm4, [rsp+0x40]
00007e2c933dbcb3  vmovaps xmm5, [rsp+0x50]
00007e2c933dbcb9  vmovaps xmm6, [rsp+0x60]
00007e2c933dbcbf  vmovaps xmm7, [rsp+0x70]
00007e2c933dbcc5  vmovaps xmm8, [rsp+0x80]
00007e2c933dbcce  vmovaps xmm9, [rsp+0x90]
00007e2c933dbcd7  vmovaps xmm10, [rsp+0xA0]
00007e2c933dbce0  vmovaps xmm11, [rsp+0xB0]
00007e2c933dbce9  vmovaps xmm12, [rsp+0xC0]
00007e2c933dbcf2  vmovaps xmm13, [rsp+0xD0]
00007e2c933dbcfb  vmovaps xmm15, [rsp+0xE0]
00007e2c933dbd04  add rsp, 0xF0
00007e2c933dbd0b  pop r11
00007e2c933dbd0d  pop r10
00007e2c933dbd0f  pop r9
00007e2c933dbd11  pop r8
00007e2c933dbd13  pop rsi
00007e2c933dbd14  pop rdi
00007e2c933dbd15  pop rdx
00007e2c933dbd16  pop rcx
00007e2c933dbd17  pop rax
00007e2c933dbd18  add rsp, 0x08
00007e2c933dbd1c  jmp 0x00007E2C933D92FD
00007e2c933dbd21  sub rsp, 0x08
00007e2c933dbd25  push rax
00007e2c933dbd26  push rcx
00007e2c933dbd27  push rdx
00007e2c933dbd28  push rdi
00007e2c933dbd29  push rsi
00007e2c933dbd2a  push r8
00007e2c933dbd2c  push r9
00007e2c933dbd2e  push r10
00007e2c933dbd30  push r11
00007e2c933dbd32  sub rsp, 0xF0
00007e2c933dbd39  vmovaps [rsp], xmm0
00007e2c933dbd3e  vmovaps [rsp+0x10], xmm2
00007e2c933dbd44  vmovaps [rsp+0x20], xmm3
00007e2c933dbd4a  vmovaps [rsp+0x30], xmm4
00007e2c933dbd50  vmovaps [rsp+0x40], xmm5
00007e2c933dbd56  vmovaps [rsp+0x50], xmm6
00007e2c933dbd5c  vmovaps [rsp+0x60], xmm7
00007e2c933dbd62  vmovaps [rsp+0x70], xmm8
00007e2c933dbd68  vmovaps [rsp+0x80], xmm9
00007e2c933dbd71  vmovaps [rsp+0x90], xmm10
00007e2c933dbd7a  vmovaps [rsp+0xA0], xmm11
00007e2c933dbd83  vmovaps [rsp+0xB0], xmm12
00007e2c933dbd8c  vmovaps [rsp+0xC0], xmm13
00007e2c933dbd95  vmovaps [rsp+0xD0], xmm14
00007e2c933dbd9e  vmovaps [rsp+0xE0], xmm15
00007e2c933dbda7  sub rsp, 0x30
00007e2c933dbdab  movaps [rsp], xmm1
00007e2c933dbdaf  movaps [rsp+0x10], xmm4
00007e2c933dbdb4  movaps [rsp+0x20], xmm9
00007e2c933dbdba  lea rdi, [rsp]
00007e2c933dbdbe  mov esi, 0x00
00007e2c933dbdc3  mov rax, 0x5A263F1C7530
00007e2c933dbdcd  call rax
00007e2c933dbdcf  movaps xmm1, [rsp]
00007e2c933dbdd3  add rsp, 0x30
00007e2c933dbdd7  vmovaps xmm0, [rsp]
00007e2c933dbddc  vmovaps xmm2, [rsp+0x10]
00007e2c933dbde2  vmovaps xmm3, [rsp+0x20]
00007e2c933dbde8  vmovaps xmm4, [rsp+0x30]
00007e2c933dbdee  vmovaps xmm5, [rsp+0x40]
00007e2c933dbdf4  vmovaps xmm6, [rsp+0x50]
00007e2c933dbdfa  vmovaps xmm7, [rsp+0x60]
00007e2c933dbe00  vmovaps xmm8, [rsp+0x70]
00007e2c933dbe06  vmovaps xmm9, [rsp+0x80]
00007e2c933dbe0f  vmovaps xmm10, [rsp+0x90]
00007e2c933dbe18  vmovaps xmm11, [rsp+0xA0]
00007e2c933dbe21  vmovaps xmm12, [rsp+0xB0]
00007e2c933dbe2a  vmovaps xmm13, [rsp+0xC0]
00007e2c933dbe33  vmovaps xmm14, [rsp+0xD0]
00007e2c933dbe3c  vmovaps xmm15, [rsp+0xE0]
00007e2c933dbe45  add rsp, 0xF0
00007e2c933dbe4c  pop r11
00007e2c933dbe4e  pop r10
00007e2c933dbe50  pop r9
00007e2c933dbe52  pop r8
00007e2c933dbe54  pop rsi
00007e2c933dbe55  pop rdi
00007e2c933dbe56  pop rdx
00007e2c933dbe57  pop rcx
00007e2c933dbe58  pop rax
00007e2c933dbe59  add rsp, 0x08
00007e2c933dbe5d  jmp 0x00007E2C933D931B
00007e2c933dbe62  sub rsp, 0x08
00007e2c933dbe66  push rax
00007e2c933dbe67  push rcx
00007e2c933dbe68  push rdx
00007e2c933dbe69  push rdi
00007e2c933dbe6a  push rsi
00007e2c933dbe6b  push r8
00007e2c933dbe6d  push r9
00007e2c933dbe6f  push r10
00007e2c933dbe71  push r11
00007e2c933dbe73  sub rsp, 0xF0
00007e2c933dbe7a  vmovaps [rsp], xmm0
00007e2c933dbe7f  vmovaps [rsp+0x10], xmm1
00007e2c933dbe85  vmovaps [rsp+0x20], xmm2
00007e2c933dbe8b  vmovaps [rsp+0x30], xmm3
00007e2c933dbe91  vmovaps [rsp+0x40], xmm5
00007e2c933dbe97  vmovaps [rsp+0x50], xmm6
00007e2c933dbe9d  vmovaps [rsp+0x60], xmm7
00007e2c933dbea3  vmovaps [rsp+0x70], xmm8
00007e2c933dbea9  vmovaps [rsp+0x80], xmm9
00007e2c933dbeb2  vmovaps [rsp+0x90], xmm10
00007e2c933dbebb  vmovaps [rsp+0xA0], xmm11
00007e2c933dbec4  vmovaps [rsp+0xB0], xmm12
00007e2c933dbecd  vmovaps [rsp+0xC0], xmm13
00007e2c933dbed6  vmovaps [rsp+0xD0], xmm14
00007e2c933dbedf  vmovaps [rsp+0xE0], xmm15
00007e2c933dbee8  sub rsp, 0x30
00007e2c933dbeec  movaps [rsp], xmm4
00007e2c933dbef0  movaps [rsp+0x10], xmm2
00007e2c933dbef5  movaps [rsp+0x20], xmm9
00007e2c933dbefb  lea rdi, [rsp]
00007e2c933dbeff  mov esi, 0x00
00007e2c933dbf04  mov rax, 0x5A263F1C7530
00007e2c933dbf0e  call rax
00007e2c933dbf10  movaps xmm4, [rsp]
00007e2c933dbf14  add rsp, 0x30
00007e2c933dbf18  vmovaps xmm0, [rsp]
00007e2c933dbf1d  vmovaps xmm1, [rsp+0x10]
00007e2c933dbf23  vmovaps xmm2, [rsp+0x20]
00007e2c933dbf29  vmovaps xmm3, [rsp+0x30]
00007e2c933dbf2f  vmovaps xmm5, [rsp+0x40]
00007e2c933dbf35  vmovaps xmm6, [rsp+0x50]
00007e2c933dbf3b  vmovaps xmm7, [rsp+0x60]
00007e2c933dbf41  vmovaps xmm8, [rsp+0x70]
00007e2c933dbf47  vmovaps xmm9, [rsp+0x80]
00007e2c933dbf50  vmovaps xmm10, [rsp+0x90]
00007e2c933dbf59  vmovaps xmm11, [rsp+0xA0]
00007e2c933dbf62  vmovaps xmm12, [rsp+0xB0]
00007e2c933dbf6b  vmovaps xmm13, [rsp+0xC0]
00007e2c933dbf74  vmovaps xmm14, [rsp+0xD0]
00007e2c933dbf7d  vmovaps xmm15, [rsp+0xE0]
00007e2c933dbf86  add rsp, 0xF0
00007e2c933dbf8d  pop r11
00007e2c933dbf8f  pop r10
00007e2c933dbf91  pop r9
00007e2c933dbf93  pop r8
00007e2c933dbf95  pop rsi
00007e2c933dbf96  pop rdi
00007e2c933dbf97  pop rdx
00007e2c933dbf98  pop rcx
00007e2c933dbf99  pop rax
00007e2c933dbf9a  add rsp, 0x08
00007e2c933dbf9e  jmp 0x00007E2C933D934B
00007e2c933dbfa3  sub rsp, 0x08
00007e2c933dbfa7  push rax
00007e2c933dbfa8  push rcx
00007e2c933dbfa9  push rdx
00007e2c933dbfaa  push rdi
00007e2c933dbfab  push rsi
00007e2c933dbfac  push r8
00007e2c933dbfae  push r9
00007e2c933dbfb0  push r10
00007e2c933dbfb2  push r11
00007e2c933dbfb4  sub rsp, 0xF0
00007e2c933dbfbb  vmovaps [rsp], xmm0
00007e2c933dbfc0  vmovaps [rsp+0x10], xmm1
00007e2c933dbfc6  vmovaps [rsp+0x20], xmm2
00007e2c933dbfcc  vmovaps [rsp+0x30], xmm3
00007e2c933dbfd2  vmovaps [rsp+0x40], xmm4
00007e2c933dbfd8  vmovaps [rsp+0x50], xmm5
00007e2c933dbfde  vmovaps [rsp+0x60], xmm6
00007e2c933dbfe4  vmovaps [rsp+0x70], xmm7
00007e2c933dbfea  vmovaps [rsp+0x80], xmm8
00007e2c933dbff3  vmovaps [rsp+0x90], xmm10
00007e2c933dbffc  vmovaps [rsp+0xA0], xmm11
00007e2c933dc005  vmovaps [rsp+0xB0], xmm12
00007e2c933dc00e  vmovaps [rsp+0xC0], xmm13
00007e2c933dc017  vmovaps [rsp+0xD0], xmm14
00007e2c933dc020  vmovaps [rsp+0xE0], xmm15
00007e2c933dc029  sub rsp, 0x30
00007e2c933dc02d  movaps [rsp], xmm9
00007e2c933dc032  movaps [rsp+0x10], xmm2
00007e2c933dc037  movaps [rsp+0x20], xmm1
00007e2c933dc03c  lea rdi, [rsp]
00007e2c933dc040  mov esi, 0x00
00007e2c933dc045  mov rax, 0x5A263F1C7530
00007e2c933dc04f  call rax
00007e2c933dc051  movaps xmm9, [rsp]
00007e2c933dc056  add rsp, 0x30
00007e2c933dc05a  vmovaps xmm0, [rsp]
00007e2c933dc05f  vmovaps xmm1, [rsp+0x10]
00007e2c933dc065  vmovaps xmm2, [rsp+0x20]
00007e2c933dc06b  vmovaps xmm3, [rsp+0x30]
00007e2c933dc071  vmovaps xmm4, [rsp+0x40]
00007e2c933dc077  vmovaps xmm5, [rsp+0x50]
00007e2c933dc07d  vmovaps xmm6, [rsp+0x60]
00007e2c933dc083  vmovaps xmm7, [rsp+0x70]
00007e2c933dc089  vmovaps xmm8, [rsp+0x80]
00007e2c933dc092  vmovaps xmm10, [rsp+0x90]
00007e2c933dc09b  vmovaps xmm11, [rsp+0xA0]
00007e2c933dc0a4  vmovaps xmm12, [rsp+0xB0]
00007e2c933dc0ad  vmovaps xmm13, [rsp+0xC0]
00007e2c933dc0b6  vmovaps xmm14, [rsp+0xD0]
00007e2c933dc0bf  vmovaps xmm15, [rsp+0xE0]
00007e2c933dc0c8  add rsp, 0xF0
00007e2c933dc0cf  pop r11
00007e2c933dc0d1  pop r10
00007e2c933dc0d3  pop r9
00007e2c933dc0d5  pop r8
00007e2c933dc0d7  pop rsi
00007e2c933dc0d8  pop rdi
00007e2c933dc0d9  pop rdx
00007e2c933dc0da  pop rcx
00007e2c933dc0db  pop rax
00007e2c933dc0dc  add rsp, 0x08
00007e2c933dc0e0  jmp 0x00007E2C933D9381
00007e2c933dc0e5  sub rsp, 0x08
00007e2c933dc0e9  push rax
00007e2c933dc0ea  push rcx
00007e2c933dc0eb  push rdx
00007e2c933dc0ec  push rdi
00007e2c933dc0ed  push rsi
00007e2c933dc0ee  push r8
00007e2c933dc0f0  push r9
00007e2c933dc0f2  push r10
00007e2c933dc0f4  push r11
00007e2c933dc0f6  sub rsp, 0xF0
00007e2c933dc0fd  vmovaps [rsp], xmm0
00007e2c933dc102  vmovaps [rsp+0x10], xmm2
00007e2c933dc108  vmovaps [rsp+0x20], xmm3
00007e2c933dc10e  vmovaps [rsp+0x30], xmm4
00007e2c933dc114  vmovaps [rsp+0x40], xmm5
00007e2c933dc11a  vmovaps [rsp+0x50], xmm6
00007e2c933dc120  vmovaps [rsp+0x60], xmm7
00007e2c933dc126  vmovaps [rsp+0x70], xmm8
00007e2c933dc12c  vmovaps [rsp+0x80], xmm9
00007e2c933dc135  vmovaps [rsp+0x90], xmm10
00007e2c933dc13e  vmovaps [rsp+0xA0], xmm11
00007e2c933dc147  vmovaps [rsp+0xB0], xmm12
00007e2c933dc150  vmovaps [rsp+0xC0], xmm13
00007e2c933dc159  vmovaps [rsp+0xD0], xmm14
00007e2c933dc162  vmovaps [rsp+0xE0], xmm15
00007e2c933dc16b  sub rsp, 0x30
00007e2c933dc16f  movaps [rsp], xmm1
00007e2c933dc173  movaps [rsp+0x10], xmm15
00007e2c933dc179  movaps [rsp+0x20], xmm6
00007e2c933dc17e  lea rdi, [rsp]
00007e2c933dc182  mov esi, 0x00
00007e2c933dc187  mov rax, 0x5A263F1C7530
00007e2c933dc191  call rax
00007e2c933dc193  movaps xmm1, [rsp]
00007e2c933dc197  add rsp, 0x30
00007e2c933dc19b  vmovaps xmm0, [rsp]
00007e2c933dc1a0  vmovaps xmm2, [rsp+0x10]
00007e2c933dc1a6  vmovaps xmm3, [rsp+0x20]
00007e2c933dc1ac  vmovaps xmm4, [rsp+0x30]
00007e2c933dc1b2  vmovaps xmm5, [rsp+0x40]
00007e2c933dc1b8  vmovaps xmm6, [rsp+0x50]
00007e2c933dc1be  vmovaps xmm7, [rsp+0x60]
00007e2c933dc1c4  vmovaps xmm8, [rsp+0x70]
00007e2c933dc1ca  vmovaps xmm9, [rsp+0x80]
00007e2c933dc1d3  vmovaps xmm10, [rsp+0x90]
00007e2c933dc1dc  vmovaps xmm11, [rsp+0xA0]
00007e2c933dc1e5  vmovaps xmm12, [rsp+0xB0]
00007e2c933dc1ee  vmovaps xmm13, [rsp+0xC0]
00007e2c933dc1f7  vmovaps xmm14, [rsp+0xD0]
00007e2c933dc200  vmovaps xmm15, [rsp+0xE0]
00007e2c933dc209  add rsp, 0xF0
00007e2c933dc210  pop r11
00007e2c933dc212  pop r10
00007e2c933dc214  pop r9
00007e2c933dc216  pop r8
00007e2c933dc218  pop rsi
00007e2c933dc219  pop rdi
00007e2c933dc21a  pop rdx
00007e2c933dc21b  pop rcx
00007e2c933dc21c  pop rax
00007e2c933dc21d  add rsp, 0x08
00007e2c933dc221  jmp 0x00007E2C933D93A2
00007e2c933dc226  sub rsp, 0x08
00007e2c933dc22a  push rax
00007e2c933dc22b  push rcx
00007e2c933dc22c  push rdx
00007e2c933dc22d  push rdi
00007e2c933dc22e  push rsi
00007e2c933dc22f  push r8
00007e2c933dc231  push r9
00007e2c933dc233  push r10
00007e2c933dc235  push r11
00007e2c933dc237  sub rsp, 0xF0
00007e2c933dc23e  vmovaps [rsp], xmm0
00007e2c933dc243  vmovaps [rsp+0x10], xmm1
00007e2c933dc249  vmovaps [rsp+0x20], xmm2
00007e2c933dc24f  vmovaps [rsp+0x30], xmm3
00007e2c933dc255  vmovaps [rsp+0x40], xmm4
00007e2c933dc25b  vmovaps [rsp+0x50], xmm5
00007e2c933dc261  vmovaps [rsp+0x60], xmm6
00007e2c933dc267  vmovaps [rsp+0x70], xmm7
00007e2c933dc26d  vmovaps [rsp+0x80], xmm8
00007e2c933dc276  vmovaps [rsp+0x90], xmm9
00007e2c933dc27f  vmovaps [rsp+0xA0], xmm10
00007e2c933dc288  vmovaps [rsp+0xB0], xmm11
00007e2c933dc291  vmovaps [rsp+0xC0], xmm12
00007e2c933dc29a  vmovaps [rsp+0xD0], xmm13
00007e2c933dc2a3  vmovaps [rsp+0xE0], xmm14
00007e2c933dc2ac  sub rsp, 0x30
00007e2c933dc2b0  movaps [rsp], xmm15
00007e2c933dc2b5  movaps [rsp+0x10], xmm5
00007e2c933dc2ba  movaps [rsp+0x20], xmm3
00007e2c933dc2bf  lea rdi, [rsp]
00007e2c933dc2c3  mov esi, 0x00
00007e2c933dc2c8  mov rax, 0x5A263F1C7530
00007e2c933dc2d2  call rax
00007e2c933dc2d4  movaps xmm15, [rsp]
00007e2c933dc2d9  add rsp, 0x30
00007e2c933dc2dd  vmovaps xmm0, [rsp]
00007e2c933dc2e2  vmovaps xmm1, [rsp+0x10]
00007e2c933dc2e8  vmovaps xmm2, [rsp+0x20]
00007e2c933dc2ee  vmovaps xmm3, [rsp+0x30]
00007e2c933dc2f4  vmovaps xmm4, [rsp+0x40]
00007e2c933dc2fa  vmovaps xmm5, [rsp+0x50]
00007e2c933dc300  vmovaps xmm6, [rsp+0x60]
00007e2c933dc306  vmovaps xmm7, [rsp+0x70]
00007e2c933dc30c  vmovaps xmm8, [rsp+0x80]
00007e2c933dc315  vmovaps xmm9, [rsp+0x90]
00007e2c933dc31e  vmovaps xmm10, [rsp+0xA0]
00007e2c933dc327  vmovaps xmm11, [rsp+0xB0]
00007e2c933dc330  vmovaps xmm12, [rsp+0xC0]
00007e2c933dc339  vmovaps xmm13, [rsp+0xD0]
00007e2c933dc342  vmovaps xmm14, [rsp+0xE0]
00007e2c933dc34b  add rsp, 0xF0
00007e2c933dc352  pop r11
00007e2c933dc354  pop r10
00007e2c933dc356  pop r9
00007e2c933dc358  pop r8
00007e2c933dc35a  pop rsi
00007e2c933dc35b  pop rdi
00007e2c933dc35c  pop rdx
00007e2c933dc35d  pop rcx
00007e2c933dc35e  pop rax
00007e2c933dc35f  add rsp, 0x08
00007e2c933dc363  jmp 0x00007E2C933D93BC
00007e2c933dc368  sub rsp, 0x08
00007e2c933dc36c  push rax
00007e2c933dc36d  push rcx
00007e2c933dc36e  push rdx
00007e2c933dc36f  push rdi
00007e2c933dc370  push rsi
00007e2c933dc371  push r8
00007e2c933dc373  push r9
00007e2c933dc375  push r10
00007e2c933dc377  push r11
00007e2c933dc379  sub rsp, 0xF0
00007e2c933dc380  vmovaps [rsp], xmm0
00007e2c933dc385  vmovaps [rsp+0x10], xmm1
00007e2c933dc38b  vmovaps [rsp+0x20], xmm2
00007e2c933dc391  vmovaps [rsp+0x30], xmm3
00007e2c933dc397  vmovaps [rsp+0x40], xmm4
00007e2c933dc39d  vmovaps [rsp+0x50], xmm6
00007e2c933dc3a3  vmovaps [rsp+0x60], xmm7
00007e2c933dc3a9  vmovaps [rsp+0x70], xmm8
00007e2c933dc3af  vmovaps [rsp+0x80], xmm9
00007e2c933dc3b8  vmovaps [rsp+0x90], xmm10
00007e2c933dc3c1  vmovaps [rsp+0xA0], xmm11
00007e2c933dc3ca  vmovaps [rsp+0xB0], xmm12
00007e2c933dc3d3  vmovaps [rsp+0xC0], xmm13
00007e2c933dc3dc  vmovaps [rsp+0xD0], xmm14
00007e2c933dc3e5  vmovaps [rsp+0xE0], xmm15
00007e2c933dc3ee  sub rsp, 0x30
00007e2c933dc3f2  movaps [rsp], xmm5
00007e2c933dc3f6  movaps [rsp+0x10], xmm8
00007e2c933dc3fc  movaps [rsp+0x20], xmm6
00007e2c933dc401  lea rdi, [rsp]
00007e2c933dc405  mov esi, 0x00
00007e2c933dc40a  mov rax, 0x5A263F1C7530
00007e2c933dc414  call rax
00007e2c933dc416  movaps xmm5, [rsp]
00007e2c933dc41a  add rsp, 0x30
00007e2c933dc41e  vmovaps xmm0, [rsp]
00007e2c933dc423  vmovaps xmm1, [rsp+0x10]
00007e2c933dc429  vmovaps xmm2, [rsp+0x20]
00007e2c933dc42f  vmovaps xmm3, [rsp+0x30]
00007e2c933dc435  vmovaps xmm4, [rsp+0x40]
00007e2c933dc43b  vmovaps xmm6, [rsp+0x50]
00007e2c933dc441  vmovaps xmm7, [rsp+0x60]
00007e2c933dc447  vmovaps xmm8, [rsp+0x70]
00007e2c933dc44d  vmovaps xmm9, [rsp+0x80]
00007e2c933dc456  vmovaps xmm10, [rsp+0x90]
00007e2c933dc45f  vmovaps xmm11, [rsp+0xA0]
00007e2c933dc468  vmovaps xmm12, [rsp+0xB0]
00007e2c933dc471  vmovaps xmm13, [rsp+0xC0]
00007e2c933dc47a  vmovaps xmm14, [rsp+0xD0]
00007e2c933dc483  vmovaps xmm15, [rsp+0xE0]
00007e2c933dc48c  add rsp, 0xF0
00007e2c933dc493  pop r11
00007e2c933dc495  pop r10
00007e2c933dc497  pop r9
00007e2c933dc499  pop r8
00007e2c933dc49b  pop rsi
00007e2c933dc49c  pop rdi
00007e2c933dc49d  pop rdx
00007e2c933dc49e  pop rcx
00007e2c933dc49f  pop rax
00007e2c933dc4a0  add rsp, 0x08
00007e2c933dc4a4  jmp 0x00007E2C933D93E0
00007e2c933dc4a9  sub rsp, 0x08
00007e2c933dc4ad  push rax
00007e2c933dc4ae  push rcx
00007e2c933dc4af  push rdx
00007e2c933dc4b0  push rdi
00007e2c933dc4b1  push rsi
00007e2c933dc4b2  push r8
00007e2c933dc4b4  push r9
00007e2c933dc4b6  push r10
00007e2c933dc4b8  push r11
00007e2c933dc4ba  sub rsp, 0xF0
00007e2c933dc4c1  vmovaps [rsp], xmm0
00007e2c933dc4c6  vmovaps [rsp+0x10], xmm1
00007e2c933dc4cc  vmovaps [rsp+0x20], xmm2
00007e2c933dc4d2  vmovaps [rsp+0x30], xmm3
00007e2c933dc4d8  vmovaps [rsp+0x40], xmm4
00007e2c933dc4de  vmovaps [rsp+0x50], xmm5
00007e2c933dc4e4  vmovaps [rsp+0x60], xmm7
00007e2c933dc4ea  vmovaps [rsp+0x70], xmm8
00007e2c933dc4f0  vmovaps [rsp+0x80], xmm9
00007e2c933dc4f9  vmovaps [rsp+0x90], xmm10
00007e2c933dc502  vmovaps [rsp+0xA0], xmm11
00007e2c933dc50b  vmovaps [rsp+0xB0], xmm12
00007e2c933dc514  vmovaps [rsp+0xC0], xmm13
00007e2c933dc51d  vmovaps [rsp+0xD0], xmm14
00007e2c933dc526  vmovaps [rsp+0xE0], xmm15
00007e2c933dc52f  sub rsp, 0x30
00007e2c933dc533  movaps [rsp], xmm6
00007e2c933dc537  movaps [rsp+0x10], xmm10
00007e2c933dc53d  movaps [rsp+0x20], xmm8
00007e2c933dc543  lea rdi, [rsp]
00007e2c933dc547  mov esi, 0x00
00007e2c933dc54c  mov rax, 0x5A263F1C7530
00007e2c933dc556  call rax
00007e2c933dc558  movaps xmm6, [rsp]
00007e2c933dc55c  add rsp, 0x30
00007e2c933dc560  vmovaps xmm0, [rsp]
00007e2c933dc565  vmovaps xmm1, [rsp+0x10]
00007e2c933dc56b  vmovaps xmm2, [rsp+0x20]
00007e2c933dc571  vmovaps xmm3, [rsp+0x30]
00007e2c933dc577  vmovaps xmm4, [rsp+0x40]
00007e2c933dc57d  vmovaps xmm5, [rsp+0x50]
00007e2c933dc583  vmovaps xmm7, [rsp+0x60]
00007e2c933dc589  vmovaps xmm8, [rsp+0x70]
00007e2c933dc58f  vmovaps xmm9, [rsp+0x80]
00007e2c933dc598  vmovaps xmm10, [rsp+0x90]
00007e2c933dc5a1  vmovaps xmm11, [rsp+0xA0]
00007e2c933dc5aa  vmovaps xmm12, [rsp+0xB0]
00007e2c933dc5b3  vmovaps xmm13, [rsp+0xC0]
00007e2c933dc5bc  vmovaps xmm14, [rsp+0xD0]
00007e2c933dc5c5  vmovaps xmm15, [rsp+0xE0]
00007e2c933dc5ce  add rsp, 0xF0
00007e2c933dc5d5  pop r11
00007e2c933dc5d7  pop r10
00007e2c933dc5d9  pop r9
00007e2c933dc5db  pop r8
00007e2c933dc5dd  pop rsi
00007e2c933dc5de  pop rdi
00007e2c933dc5df  pop rdx
00007e2c933dc5e0  pop rcx
00007e2c933dc5e1  pop rax
00007e2c933dc5e2  add rsp, 0x08
00007e2c933dc5e6  jmp 0x00007E2C933D9405
00007e2c933dc5eb  sub rsp, 0x08
00007e2c933dc5ef  push rax
00007e2c933dc5f0  push rcx
00007e2c933dc5f1  push rdx
00007e2c933dc5f2  push rdi
00007e2c933dc5f3  push rsi
00007e2c933dc5f4  push r8
00007e2c933dc5f6  push r9
00007e2c933dc5f8  push r10
00007e2c933dc5fa  push r11
00007e2c933dc5fc  sub rsp, 0xF0
00007e2c933dc603  vmovaps [rsp], xmm0
00007e2c933dc608  vmovaps [rsp+0x10], xmm1
00007e2c933dc60e  vmovaps [rsp+0x20], xmm2
00007e2c933dc614  vmovaps [rsp+0x30], xmm3
00007e2c933dc61a  vmovaps [rsp+0x40], xmm4
00007e2c933dc620  vmovaps [rsp+0x50], xmm5
00007e2c933dc626  vmovaps [rsp+0x60], xmm6
00007e2c933dc62c  vmovaps [rsp+0x70], xmm7
00007e2c933dc632  vmovaps [rsp+0x80], xmm8
00007e2c933dc63b  vmovaps [rsp+0x90], xmm9
00007e2c933dc644  vmovaps [rsp+0xA0], xmm11
00007e2c933dc64d  vmovaps [rsp+0xB0], xmm12
00007e2c933dc656  vmovaps [rsp+0xC0], xmm13
00007e2c933dc65f  vmovaps [rsp+0xD0], xmm14
00007e2c933dc668  vmovaps [rsp+0xE0], xmm15
00007e2c933dc671  sub rsp, 0x30
00007e2c933dc675  movaps [rsp], xmm10
00007e2c933dc67a  movaps [rsp+0x10], xmm8
00007e2c933dc680  movaps [rsp+0x20], xmm14
00007e2c933dc686  lea rdi, [rsp]
00007e2c933dc68a  mov esi, 0x00
00007e2c933dc68f  mov rax, 0x5A263F1C7530
00007e2c933dc699  call rax
00007e2c933dc69b  movaps xmm10, [rsp]
00007e2c933dc6a0  add rsp, 0x30
00007e2c933dc6a4  vmovaps xmm0, [rsp]
00007e2c933dc6a9  vmovaps xmm1, [rsp+0x10]
00007e2c933dc6af  vmovaps xmm2, [rsp+0x20]
00007e2c933dc6b5  vmovaps xmm3, [rsp+0x30]
00007e2c933dc6bb  vmovaps xmm4, [rsp+0x40]
00007e2c933dc6c1  vmovaps xmm5, [rsp+0x50]
00007e2c933dc6c7  vmovaps xmm6, [rsp+0x60]
00007e2c933dc6cd  vmovaps xmm7, [rsp+0x70]
00007e2c933dc6d3  vmovaps xmm8, [rsp+0x80]
00007e2c933dc6dc  vmovaps xmm9, [rsp+0x90]
00007e2c933dc6e5  vmovaps xmm11, [rsp+0xA0]
00007e2c933dc6ee  vmovaps xmm12, [rsp+0xB0]
00007e2c933dc6f7  vmovaps xmm13, [rsp+0xC0]
00007e2c933dc700  vmovaps xmm14, [rsp+0xD0]
00007e2c933dc709  vmovaps xmm15, [rsp+0xE0]
00007e2c933dc712  add rsp, 0xF0
00007e2c933dc719  pop r11
00007e2c933dc71b  pop r10
00007e2c933dc71d  pop r9
00007e2c933dc71f  pop r8
00007e2c933dc721  pop rsi
00007e2c933dc722  pop rdi
00007e2c933dc723  pop rdx
00007e2c933dc724  pop rcx
00007e2c933dc725  pop rax
00007e2c933dc726  add rsp, 0x08
00007e2c933dc72a  jmp 0x00007E2C933D9425
00007e2c933dc72f  sub rsp, 0x08
00007e2c933dc733  push rax
00007e2c933dc734  push rcx
00007e2c933dc735  push rdx
00007e2c933dc736  push rdi
00007e2c933dc737  push rsi
00007e2c933dc738  push r8
00007e2c933dc73a  push r9
00007e2c933dc73c  push r10
00007e2c933dc73e  push r11
00007e2c933dc740  sub rsp, 0xF0
00007e2c933dc747  vmovaps [rsp], xmm0
00007e2c933dc74c  vmovaps [rsp+0x10], xmm1
00007e2c933dc752  vmovaps [rsp+0x20], xmm2
00007e2c933dc758  vmovaps [rsp+0x30], xmm3
00007e2c933dc75e  vmovaps [rsp+0x40], xmm4
00007e2c933dc764  vmovaps [rsp+0x50], xmm5
00007e2c933dc76a  vmovaps [rsp+0x60], xmm6
00007e2c933dc770  vmovaps [rsp+0x70], xmm7
00007e2c933dc776  vmovaps [rsp+0x80], xmm8
00007e2c933dc77f  vmovaps [rsp+0x90], xmm9
00007e2c933dc788  vmovaps [rsp+0xA0], xmm10
00007e2c933dc791  vmovaps [rsp+0xB0], xmm11
00007e2c933dc79a  vmovaps [rsp+0xC0], xmm12
00007e2c933dc7a3  vmovaps [rsp+0xD0], xmm13
00007e2c933dc7ac  vmovaps [rsp+0xE0], xmm15
00007e2c933dc7b5  sub rsp, 0x30
00007e2c933dc7b9  movaps [rsp], xmm14
00007e2c933dc7be  movaps [rsp+0x10], xmm8
00007e2c933dc7c4  movaps [rsp+0x20], xmm4
00007e2c933dc7c9  lea rdi, [rsp]
00007e2c933dc7cd  mov esi, 0x00
00007e2c933dc7d2  mov rax, 0x5A263F1C7530
00007e2c933dc7dc  call rax
00007e2c933dc7de  movaps xmm14, [rsp]
00007e2c933dc7e3  add rsp, 0x30
00007e2c933dc7e7  vmovaps xmm0, [rsp]
00007e2c933dc7ec  vmovaps xmm1, [rsp+0x10]
00007e2c933dc7f2  vmovaps xmm2, [rsp+0x20]
00007e2c933dc7f8  vmovaps xmm3, [rsp+0x30]
00007e2c933dc7fe  vmovaps xmm4, [rsp+0x40]
00007e2c933dc804  vmovaps xmm5, [rsp+0x50]
00007e2c933dc80a  vmovaps xmm6, [rsp+0x60]
00007e2c933dc810  vmovaps xmm7, [rsp+0x70]
00007e2c933dc816  vmovaps xmm8, [rsp+0x80]
00007e2c933dc81f  vmovaps xmm9, [rsp+0x90]
00007e2c933dc828  vmovaps xmm10, [rsp+0xA0]
00007e2c933dc831  vmovaps xmm11, [rsp+0xB0]
00007e2c933dc83a  vmovaps xmm12, [rsp+0xC0]
00007e2c933dc843  vmovaps xmm13, [rsp+0xD0]
00007e2c933dc84c  vmovaps xmm15, [rsp+0xE0]
00007e2c933dc855  add rsp, 0xF0
00007e2c933dc85c  pop r11
00007e2c933dc85e  pop r10
00007e2c933dc860  pop r9
00007e2c933dc862  pop r8
00007e2c933dc864  pop rsi
00007e2c933dc865  pop rdi
00007e2c933dc866  pop rdx
00007e2c933dc867  pop rcx
00007e2c933dc868  pop rax
00007e2c933dc869  add rsp, 0x08
00007e2c933dc86d  jmp 0x00007E2C933D9445
00007e2c933dc872  sub rsp, 0x08
00007e2c933dc876  push rax
00007e2c933dc877  push rcx
00007e2c933dc878  push rdx
00007e2c933dc879  push rdi
00007e2c933dc87a  push rsi
00007e2c933dc87b  push r8
00007e2c933dc87d  push r9
00007e2c933dc87f  push r10
00007e2c933dc881  push r11
00007e2c933dc883  sub rsp, 0xF0
00007e2c933dc88a  vmovaps [rsp], xmm0
00007e2c933dc88f  vmovaps [rsp+0x10], xmm1
00007e2c933dc895  vmovaps [rsp+0x20], xmm2
00007e2c933dc89b  vmovaps [rsp+0x30], xmm3
00007e2c933dc8a1  vmovaps [rsp+0x40], xmm5
00007e2c933dc8a7  vmovaps [rsp+0x50], xmm6
00007e2c933dc8ad  vmovaps [rsp+0x60], xmm7
00007e2c933dc8b3  vmovaps [rsp+0x70], xmm8
00007e2c933dc8b9  vmovaps [rsp+0x80], xmm9
00007e2c933dc8c2  vmovaps [rsp+0x90], xmm10
00007e2c933dc8cb  vmovaps [rsp+0xA0], xmm11
00007e2c933dc8d4  vmovaps [rsp+0xB0], xmm12
00007e2c933dc8dd  vmovaps [rsp+0xC0], xmm13
00007e2c933dc8e6  vmovaps [rsp+0xD0], xmm14
00007e2c933dc8ef  vmovaps [rsp+0xE0], xmm15
00007e2c933dc8f8  sub rsp, 0x30
00007e2c933dc8fc  movaps [rsp], xmm4
00007e2c933dc900  movaps [rsp+0x10], xmm13
00007e2c933dc906  movaps [rsp+0x20], xmm8
00007e2c933dc90c  lea rdi, [rsp]
00007e2c933dc910  mov esi, 0x00
00007e2c933dc915  mov rax, 0x5A263F1C7530
00007e2c933dc91f  call rax
00007e2c933dc921  movaps xmm4, [rsp]
00007e2c933dc925  add rsp, 0x30
00007e2c933dc929  vmovaps xmm0, [rsp]
00007e2c933dc92e  vmovaps xmm1, [rsp+0x10]
00007e2c933dc934  vmovaps xmm2, [rsp+0x20]
00007e2c933dc93a  vmovaps xmm3, [rsp+0x30]
00007e2c933dc940  vmovaps xmm5, [rsp+0x40]
00007e2c933dc946  vmovaps xmm6, [rsp+0x50]
00007e2c933dc94c  vmovaps xmm7, [rsp+0x60]
00007e2c933dc952  vmovaps xmm8, [rsp+0x70]
00007e2c933dc958  vmovaps xmm9, [rsp+0x80]
00007e2c933dc961  vmovaps xmm10, [rsp+0x90]
00007e2c933dc96a  vmovaps xmm11, [rsp+0xA0]
00007e2c933dc973  vmovaps xmm12, [rsp+0xB0]
00007e2c933dc97c  vmovaps xmm13, [rsp+0xC0]
00007e2c933dc985  vmovaps xmm14, [rsp+0xD0]
00007e2c933dc98e  vmovaps xmm15, [rsp+0xE0]
00007e2c933dc997  add rsp, 0xF0
00007e2c933dc99e  pop r11
00007e2c933dc9a0  pop r10
00007e2c933dc9a2  pop r9
00007e2c933dc9a4  pop r8
00007e2c933dc9a6  pop rsi
00007e2c933dc9a7  pop rdi
00007e2c933dc9a8  pop rdx
00007e2c933dc9a9  pop rcx
00007e2c933dc9aa  pop rax
00007e2c933dc9ab  add rsp, 0x08
00007e2c933dc9af  jmp 0x00007E2C933D946A
00007e2c933dc9b4  sub rsp, 0x08
00007e2c933dc9b8  push rax
00007e2c933dc9b9  push rcx
00007e2c933dc9ba  push rdx
00007e2c933dc9bb  push rdi
00007e2c933dc9bc  push rsi
00007e2c933dc9bd  push r8
00007e2c933dc9bf  push r9
00007e2c933dc9c1  push r10
00007e2c933dc9c3  push r11
00007e2c933dc9c5  sub rsp, 0xF0
00007e2c933dc9cc  vmovaps [rsp], xmm0
00007e2c933dc9d1  vmovaps [rsp+0x10], xmm1
00007e2c933dc9d7  vmovaps [rsp+0x20], xmm2
00007e2c933dc9dd  vmovaps [rsp+0x30], xmm3
00007e2c933dc9e3  vmovaps [rsp+0x40], xmm4
00007e2c933dc9e9  vmovaps [rsp+0x50], xmm5
00007e2c933dc9ef  vmovaps [rsp+0x60], xmm6
00007e2c933dc9f5  vmovaps [rsp+0x70], xmm7
00007e2c933dc9fb  vmovaps [rsp+0x80], xmm8
00007e2c933dca04  vmovaps [rsp+0x90], xmm9
00007e2c933dca0d  vmovaps [rsp+0xA0], xmm10
00007e2c933dca16  vmovaps [rsp+0xB0], xmm11
00007e2c933dca1f  vmovaps [rsp+0xC0], xmm12
00007e2c933dca28  vmovaps [rsp+0xD0], xmm14
00007e2c933dca31  vmovaps [rsp+0xE0], xmm15
00007e2c933dca3a  sub rsp, 0x30
00007e2c933dca3e  movaps [rsp], xmm13
00007e2c933dca43  movaps [rsp+0x10], xmm15
00007e2c933dca49  movaps [rsp+0x20], xmm9
00007e2c933dca4f  lea rdi, [rsp]
00007e2c933dca53  mov esi, 0x00
00007e2c933dca58  mov rax, 0x5A263F1C7530
00007e2c933dca62  call rax
00007e2c933dca64  movaps xmm13, [rsp]
00007e2c933dca69  add rsp, 0x30
00007e2c933dca6d  vmovaps xmm0, [rsp]
00007e2c933dca72  vmovaps xmm1, [rsp+0x10]
00007e2c933dca78  vmovaps xmm2, [rsp+0x20]
00007e2c933dca7e  vmovaps xmm3, [rsp+0x30]
00007e2c933dca84  vmovaps xmm4, [rsp+0x40]
00007e2c933dca8a  vmovaps xmm5, [rsp+0x50]
00007e2c933dca90  vmovaps xmm6, [rsp+0x60]
00007e2c933dca96  vmovaps xmm7, [rsp+0x70]
00007e2c933dca9c  vmovaps xmm8, [rsp+0x80]
00007e2c933dcaa5  vmovaps xmm9, [rsp+0x90]
00007e2c933dcaae  vmovaps xmm10, [rsp+0xA0]
00007e2c933dcab7  vmovaps xmm11, [rsp+0xB0]
00007e2c933dcac0  vmovaps xmm12, [rsp+0xC0]
00007e2c933dcac9  vmovaps xmm14, [rsp+0xD0]
00007e2c933dcad2  vmovaps xmm15, [rsp+0xE0]
00007e2c933dcadb  add rsp, 0xF0
00007e2c933dcae2  pop r11
00007e2c933dcae4  pop r10
00007e2c933dcae6  pop r9
00007e2c933dcae8  pop r8
00007e2c933dcaea  pop rsi
00007e2c933dcaeb  pop rdi
00007e2c933dcaec  pop rdx
00007e2c933dcaed  pop rcx
00007e2c933dcaee  pop rax
00007e2c933dcaef  add rsp, 0x08
00007e2c933dcaf3  jmp 0x00007E2C933D9485
00007e2c933dcaf8  sub rsp, 0x08
00007e2c933dcafc  push rax
00007e2c933dcafd  push rcx
00007e2c933dcafe  push rdx
00007e2c933dcaff  push rdi
00007e2c933dcb00  push rsi
00007e2c933dcb01  push r8
00007e2c933dcb03  push r9
00007e2c933dcb05  push r10
00007e2c933dcb07  push r11
00007e2c933dcb09  sub rsp, 0xF0
00007e2c933dcb10  vmovaps [rsp], xmm0
00007e2c933dcb15  vmovaps [rsp+0x10], xmm1
00007e2c933dcb1b  vmovaps [rsp+0x20], xmm2
00007e2c933dcb21  vmovaps [rsp+0x30], xmm3
00007e2c933dcb27  vmovaps [rsp+0x40], xmm4
00007e2c933dcb2d  vmovaps [rsp+0x50], xmm5
00007e2c933dcb33  vmovaps [rsp+0x60], xmm6
00007e2c933dcb39  vmovaps [rsp+0x70], xmm7
00007e2c933dcb3f  vmovaps [rsp+0x80], xmm8
00007e2c933dcb48  vmovaps [rsp+0x90], xmm9
00007e2c933dcb51  vmovaps [rsp+0xA0], xmm10
00007e2c933dcb5a  vmovaps [rsp+0xB0], xmm11
00007e2c933dcb63  vmovaps [rsp+0xC0], xmm12
00007e2c933dcb6c  vmovaps [rsp+0xD0], xmm13
00007e2c933dcb75  vmovaps [rsp+0xE0], xmm14
00007e2c933dcb7e  sub rsp, 0x30
00007e2c933dcb82  movaps [rsp], xmm15
00007e2c933dcb87  movaps [rsp+0x10], xmm1
00007e2c933dcb8c  movaps [rsp+0x20], xmm5
00007e2c933dcb91  lea rdi, [rsp]
00007e2c933dcb95  mov esi, 0x00
00007e2c933dcb9a  mov rax, 0x5A263F1C7530
00007e2c933dcba4  call rax
00007e2c933dcba6  movaps xmm15, [rsp]
00007e2c933dcbab  add rsp, 0x30
00007e2c933dcbaf  vmovaps xmm0, [rsp]
00007e2c933dcbb4  vmovaps xmm1, [rsp+0x10]
00007e2c933dcbba  vmovaps xmm2, [rsp+0x20]
00007e2c933dcbc0  vmovaps xmm3, [rsp+0x30]
00007e2c933dcbc6  vmovaps xmm4, [rsp+0x40]
00007e2c933dcbcc  vmovaps xmm5, [rsp+0x50]
00007e2c933dcbd2  vmovaps xmm6, [rsp+0x60]
00007e2c933dcbd8  vmovaps xmm7, [rsp+0x70]
00007e2c933dcbde  vmovaps xmm8, [rsp+0x80]
00007e2c933dcbe7  vmovaps xmm9, [rsp+0x90]
00007e2c933dcbf0  vmovaps xmm10, [rsp+0xA0]
00007e2c933dcbf9  vmovaps xmm11, [rsp+0xB0]
00007e2c933dcc02  vmovaps xmm12, [rsp+0xC0]
00007e2c933dcc0b  vmovaps xmm13, [rsp+0xD0]
00007e2c933dcc14  vmovaps xmm14, [rsp+0xE0]
00007e2c933dcc1d  add rsp, 0xF0
00007e2c933dcc24  pop r11
00007e2c933dcc26  pop r10
00007e2c933dcc28  pop r9
00007e2c933dcc2a  pop r8
00007e2c933dcc2c  pop rsi
00007e2c933dcc2d  pop rdi
00007e2c933dcc2e  pop rdx
00007e2c933dcc2f  pop rcx
00007e2c933dcc30  pop rax
00007e2c933dcc31  add rsp, 0x08
00007e2c933dcc35  jmp 0x00007E2C933D94A0
00007e2c933dcc3a  call 0x00007E2C932D64F0
00007e2c933dcc3f  jmp 0x00007E2C933D94FB
00007e2c933dcc44  sub rsp, 0x08
00007e2c933dcc48  push rax
00007e2c933dcc49  push rcx
00007e2c933dcc4a  push rdx
00007e2c933dcc4b  push rdi
00007e2c933dcc4c  push rsi
00007e2c933dcc4d  push r8
00007e2c933dcc4f  push r9
00007e2c933dcc51  push r10
00007e2c933dcc53  push r11
00007e2c933dcc55  sub rsp, 0xF0
00007e2c933dcc5c  vmovaps [rsp], xmm0
00007e2c933dcc61  vmovaps [rsp+0x10], xmm1
00007e2c933dcc67  vmovaps [rsp+0x20], xmm2
00007e2c933dcc6d  vmovaps [rsp+0x30], xmm3
00007e2c933dcc73  vmovaps [rsp+0x40], xmm4
00007e2c933dcc79  vmovaps [rsp+0x50], xmm5
00007e2c933dcc7f  vmovaps [rsp+0x60], xmm6
00007e2c933dcc85  vmovaps [rsp+0x70], xmm7
00007e2c933dcc8b  vmovaps [rsp+0x80], xmm8
00007e2c933dcc94  vmovaps [rsp+0x90], xmm10
00007e2c933dcc9d  vmovaps [rsp+0xA0], xmm11
00007e2c933dcca6  vmovaps [rsp+0xB0], xmm12
00007e2c933dccaf  vmovaps [rsp+0xC0], xmm13
00007e2c933dccb8  vmovaps [rsp+0xD0], xmm14
00007e2c933dccc1  vmovaps [rsp+0xE0], xmm15
00007e2c933dccca  sub rsp, 0x30
00007e2c933dccce  movaps [rsp], xmm9
00007e2c933dccd3  movaps [rsp+0x10], xmm8
00007e2c933dccd9  movaps [rsp+0x20], xmm11
00007e2c933dccdf  lea rdi, [rsp]
00007e2c933dcce3  mov esi, 0x00
00007e2c933dcce8  mov rax, 0x5A263F1C7530
00007e2c933dccf2  call rax
00007e2c933dccf4  movaps xmm9, [rsp]
00007e2c933dccf9  add rsp, 0x30
00007e2c933dccfd  vmovaps xmm0, [rsp]
00007e2c933dcd02  vmovaps xmm1, [rsp+0x10]
00007e2c933dcd08  vmovaps xmm2, [rsp+0x20]
00007e2c933dcd0e  vmovaps xmm3, [rsp+0x30]
00007e2c933dcd14  vmovaps xmm4, [rsp+0x40]
00007e2c933dcd1a  vmovaps xmm5, [rsp+0x50]
00007e2c933dcd20  vmovaps xmm6, [rsp+0x60]
00007e2c933dcd26  vmovaps xmm7, [rsp+0x70]
00007e2c933dcd2c  vmovaps xmm8, [rsp+0x80]
00007e2c933dcd35  vmovaps xmm10, [rsp+0x90]
00007e2c933dcd3e  vmovaps xmm11, [rsp+0xA0]
00007e2c933dcd47  vmovaps xmm12, [rsp+0xB0]
00007e2c933dcd50  vmovaps xmm13, [rsp+0xC0]
00007e2c933dcd59  vmovaps xmm14, [rsp+0xD0]
00007e2c933dcd62  vmovaps xmm15, [rsp+0xE0]
00007e2c933dcd6b  add rsp, 0xF0
00007e2c933dcd72  pop r11
00007e2c933dcd74  pop r10
00007e2c933dcd76  pop r9
00007e2c933dcd78  pop r8
00007e2c933dcd7a  pop rsi
00007e2c933dcd7b  pop rdi
00007e2c933dcd7c  pop rdx
00007e2c933dcd7d  pop rcx
00007e2c933dcd7e  pop rax
00007e2c933dcd7f  add rsp, 0x08
00007e2c933dcd83  jmp 0x00007E2C933D9532
00007e2c933dcd88  sub rsp, 0x08
00007e2c933dcd8c  push rax
00007e2c933dcd8d  push rcx
00007e2c933dcd8e  push rdx
00007e2c933dcd8f  push rdi
00007e2c933dcd90  push rsi
00007e2c933dcd91  push r8
00007e2c933dcd93  push r9
00007e2c933dcd95  push r10
00007e2c933dcd97  push r11
00007e2c933dcd99  sub rsp, 0xF0
00007e2c933dcda0  vmovaps [rsp], xmm0
00007e2c933dcda5  vmovaps [rsp+0x10], xmm1
00007e2c933dcdab  vmovaps [rsp+0x20], xmm2
00007e2c933dcdb1  vmovaps [rsp+0x30], xmm3
00007e2c933dcdb7  vmovaps [rsp+0x40], xmm4
00007e2c933dcdbd  vmovaps [rsp+0x50], xmm5
00007e2c933dcdc3  vmovaps [rsp+0x60], xmm6
00007e2c933dcdc9  vmovaps [rsp+0x70], xmm7
00007e2c933dcdcf  vmovaps [rsp+0x80], xmm8
00007e2c933dcdd8  vmovaps [rsp+0x90], xmm9
00007e2c933dcde1  vmovaps [rsp+0xA0], xmm10
00007e2c933dcdea  vmovaps [rsp+0xB0], xmm12
00007e2c933dcdf3  vmovaps [rsp+0xC0], xmm13
00007e2c933dcdfc  vmovaps [rsp+0xD0], xmm14
00007e2c933dce05  vmovaps [rsp+0xE0], xmm15
00007e2c933dce0e  sub rsp, 0x30
00007e2c933dce12  movaps [rsp], xmm11
00007e2c933dce17  movaps [rsp+0x10], xmm10
00007e2c933dce1d  movaps [rsp+0x20], xmm6
00007e2c933dce22  lea rdi, [rsp]
00007e2c933dce26  mov esi, 0x00
00007e2c933dce2b  mov rax, 0x5A263F1C7530
00007e2c933dce35  call rax
00007e2c933dce37  movaps xmm11, [rsp]
00007e2c933dce3c  add rsp, 0x30
00007e2c933dce40  vmovaps xmm0, [rsp]
00007e2c933dce45  vmovaps xmm1, [rsp+0x10]
00007e2c933dce4b  vmovaps xmm2, [rsp+0x20]
00007e2c933dce51  vmovaps xmm3, [rsp+0x30]
00007e2c933dce57  vmovaps xmm4, [rsp+0x40]
00007e2c933dce5d  vmovaps xmm5, [rsp+0x50]
00007e2c933dce63  vmovaps xmm6, [rsp+0x60]
00007e2c933dce69  vmovaps xmm7, [rsp+0x70]
00007e2c933dce6f  vmovaps xmm8, [rsp+0x80]
00007e2c933dce78  vmovaps xmm9, [rsp+0x90]
00007e2c933dce81  vmovaps xmm10, [rsp+0xA0]
00007e2c933dce8a  vmovaps xmm12, [rsp+0xB0]
00007e2c933dce93  vmovaps xmm13, [rsp+0xC0]
00007e2c933dce9c  vmovaps xmm14, [rsp+0xD0]
00007e2c933dcea5  vmovaps xmm15, [rsp+0xE0]
00007e2c933dceae  add rsp, 0xF0
00007e2c933dceb5  pop r11
00007e2c933dceb7  pop r10
00007e2c933dceb9  pop r9
00007e2c933dcebb  pop r8
00007e2c933dcebd  pop rsi
00007e2c933dcebe  pop rdi
00007e2c933dcebf  pop rdx
00007e2c933dcec0  pop rcx
00007e2c933dcec1  pop rax
00007e2c933dcec2  add rsp, 0x08
00007e2c933dcec6  jmp 0x00007E2C933D954D
00007e2c933dcecb  sub rsp, 0x08
00007e2c933dcecf  push rax
00007e2c933dced0  push rcx
00007e2c933dced1  push rdx
00007e2c933dced2  push rdi
00007e2c933dced3  push rsi
00007e2c933dced4  push r8
00007e2c933dced6  push r9
00007e2c933dced8  push r10
00007e2c933dceda  push r11
00007e2c933dcedc  sub rsp, 0xF0
00007e2c933dcee3  vmovaps [rsp], xmm0
00007e2c933dcee8  vmovaps [rsp+0x10], xmm1
00007e2c933dceee  vmovaps [rsp+0x20], xmm2
00007e2c933dcef4  vmovaps [rsp+0x30], xmm3
00007e2c933dcefa  vmovaps [rsp+0x40], xmm4
00007e2c933dcf00  vmovaps [rsp+0x50], xmm5
00007e2c933dcf06  vmovaps [rsp+0x60], xmm6
00007e2c933dcf0c  vmovaps [rsp+0x70], xmm7
00007e2c933dcf12  vmovaps [rsp+0x80], xmm8
00007e2c933dcf1b  vmovaps [rsp+0x90], xmm9
00007e2c933dcf24  vmovaps [rsp+0xA0], xmm11
00007e2c933dcf2d  vmovaps [rsp+0xB0], xmm12
00007e2c933dcf36  vmovaps [rsp+0xC0], xmm13
00007e2c933dcf3f  vmovaps [rsp+0xD0], xmm14
00007e2c933dcf48  vmovaps [rsp+0xE0], xmm15
00007e2c933dcf51  sub rsp, 0x30
00007e2c933dcf55  movaps [rsp], xmm10
00007e2c933dcf5a  movaps [rsp+0x10], xmm14
00007e2c933dcf60  movaps [rsp+0x20], xmm4
00007e2c933dcf65  lea rdi, [rsp]
00007e2c933dcf69  mov esi, 0x00
00007e2c933dcf6e  mov rax, 0x5A263F1C7530
00007e2c933dcf78  call rax
00007e2c933dcf7a  movaps xmm10, [rsp]
00007e2c933dcf7f  add rsp, 0x30
00007e2c933dcf83  vmovaps xmm0, [rsp]
00007e2c933dcf88  vmovaps xmm1, [rsp+0x10]
00007e2c933dcf8e  vmovaps xmm2, [rsp+0x20]
00007e2c933dcf94  vmovaps xmm3, [rsp+0x30]
00007e2c933dcf9a  vmovaps xmm4, [rsp+0x40]
00007e2c933dcfa0  vmovaps xmm5, [rsp+0x50]
00007e2c933dcfa6  vmovaps xmm6, [rsp+0x60]
00007e2c933dcfac  vmovaps xmm7, [rsp+0x70]
00007e2c933dcfb2  vmovaps xmm8, [rsp+0x80]
00007e2c933dcfbb  vmovaps xmm9, [rsp+0x90]
00007e2c933dcfc4  vmovaps xmm11, [rsp+0xA0]
00007e2c933dcfcd  vmovaps xmm12, [rsp+0xB0]
00007e2c933dcfd6  vmovaps xmm13, [rsp+0xC0]
00007e2c933dcfdf  vmovaps xmm14, [rsp+0xD0]
00007e2c933dcfe8  vmovaps xmm15, [rsp+0xE0]
00007e2c933dcff1  add rsp, 0xF0
00007e2c933dcff8  pop r11
00007e2c933dcffa  pop r10
00007e2c933dcffc  pop r9
00007e2c933dcffe  pop r8
00007e2c933dd000  pop rsi
00007e2c933dd001  pop rdi
00007e2c933dd002  pop rdx
00007e2c933dd003  pop rcx
00007e2c933dd004  pop rax
00007e2c933dd005  add rsp, 0x08
00007e2c933dd009  jmp 0x00007E2C933D9568
00007e2c933dd00e  sub rsp, 0x08
00007e2c933dd012  push rax
00007e2c933dd013  push rcx
00007e2c933dd014  push rdx
00007e2c933dd015  push rdi
00007e2c933dd016  push rsi
00007e2c933dd017  push r8
00007e2c933dd019  push r9
00007e2c933dd01b  push r10
00007e2c933dd01d  push r11
00007e2c933dd01f  sub rsp, 0xF0
00007e2c933dd026  vmovaps [rsp], xmm0
00007e2c933dd02b  vmovaps [rsp+0x10], xmm1
00007e2c933dd031  vmovaps [rsp+0x20], xmm2
00007e2c933dd037  vmovaps [rsp+0x30], xmm3
00007e2c933dd03d  vmovaps [rsp+0x40], xmm4
00007e2c933dd043  vmovaps [rsp+0x50], xmm5
00007e2c933dd049  vmovaps [rsp+0x60], xmm6
00007e2c933dd04f  vmovaps [rsp+0x70], xmm7
00007e2c933dd055  vmovaps [rsp+0x80], xmm9
00007e2c933dd05e  vmovaps [rsp+0x90], xmm10
00007e2c933dd067  vmovaps [rsp+0xA0], xmm11
00007e2c933dd070  vmovaps [rsp+0xB0], xmm12
00007e2c933dd079  vmovaps [rsp+0xC0], xmm13
00007e2c933dd082  vmovaps [rsp+0xD0], xmm14
00007e2c933dd08b  vmovaps [rsp+0xE0], xmm15
00007e2c933dd094  sub rsp, 0x30
00007e2c933dd098  movaps [rsp], xmm8
00007e2c933dd09d  movaps [rsp+0x10], xmm1
00007e2c933dd0a2  movaps [rsp+0x20], xmm14
00007e2c933dd0a8  lea rdi, [rsp]
00007e2c933dd0ac  mov esi, 0x00
00007e2c933dd0b1  mov rax, 0x5A263F1C7530
00007e2c933dd0bb  call rax
00007e2c933dd0bd  movaps xmm8, [rsp]
00007e2c933dd0c2  add rsp, 0x30
00007e2c933dd0c6  vmovaps xmm0, [rsp]
00007e2c933dd0cb  vmovaps xmm1, [rsp+0x10]
00007e2c933dd0d1  vmovaps xmm2, [rsp+0x20]
00007e2c933dd0d7  vmovaps xmm3, [rsp+0x30]
00007e2c933dd0dd  vmovaps xmm4, [rsp+0x40]
00007e2c933dd0e3  vmovaps xmm5, [rsp+0x50]
00007e2c933dd0e9  vmovaps xmm6, [rsp+0x60]
00007e2c933dd0ef  vmovaps xmm7, [rsp+0x70]
00007e2c933dd0f5  vmovaps xmm9, [rsp+0x80]
00007e2c933dd0fe  vmovaps xmm10, [rsp+0x90]
00007e2c933dd107  vmovaps xmm11, [rsp+0xA0]
00007e2c933dd110  vmovaps xmm12, [rsp+0xB0]
00007e2c933dd119  vmovaps xmm13, [rsp+0xC0]
00007e2c933dd122  vmovaps xmm14, [rsp+0xD0]
00007e2c933dd12b  vmovaps xmm15, [rsp+0xE0]
00007e2c933dd134  add rsp, 0xF0
00007e2c933dd13b  pop r11
00007e2c933dd13d  pop r10
00007e2c933dd13f  pop r9
00007e2c933dd141  pop r8
00007e2c933dd143  pop rsi
00007e2c933dd144  pop rdi
00007e2c933dd145  pop rdx
00007e2c933dd146  pop rcx
00007e2c933dd147  pop rax
00007e2c933dd148  add rsp, 0x08
00007e2c933dd14c  jmp 0x00007E2C933D958E
00007e2c933dd151  sub rsp, 0x08
00007e2c933dd155  push rax
00007e2c933dd156  push rcx
00007e2c933dd157  push rdx
00007e2c933dd158  push rdi
00007e2c933dd159  push rsi
00007e2c933dd15a  push r8
00007e2c933dd15c  push r9
00007e2c933dd15e  push r10
00007e2c933dd160  push r11
00007e2c933dd162  sub rsp, 0xF0
00007e2c933dd169  vmovaps [rsp], xmm0
00007e2c933dd16e  vmovaps [rsp+0x10], xmm1
00007e2c933dd174  vmovaps [rsp+0x20], xmm2
00007e2c933dd17a  vmovaps [rsp+0x30], xmm3
00007e2c933dd180  vmovaps [rsp+0x40], xmm4
00007e2c933dd186  vmovaps [rsp+0x50], xmm5
00007e2c933dd18c  vmovaps [rsp+0x60], xmm7
00007e2c933dd192  vmovaps [rsp+0x70], xmm8
00007e2c933dd198  vmovaps [rsp+0x80], xmm9
00007e2c933dd1a1  vmovaps [rsp+0x90], xmm10
00007e2c933dd1aa  vmovaps [rsp+0xA0], xmm11
00007e2c933dd1b3  vmovaps [rsp+0xB0], xmm12
00007e2c933dd1bc  vmovaps [rsp+0xC0], xmm13
00007e2c933dd1c5  vmovaps [rsp+0xD0], xmm14
00007e2c933dd1ce  vmovaps [rsp+0xE0], xmm15
00007e2c933dd1d7  sub rsp, 0x30
00007e2c933dd1db  movaps [rsp], xmm6
00007e2c933dd1df  movaps [rsp+0x10], xmm1
00007e2c933dd1e4  movaps [rsp+0x20], xmm14
00007e2c933dd1ea  lea rdi, [rsp]
00007e2c933dd1ee  mov esi, 0x00
00007e2c933dd1f3  mov rax, 0x5A263F1C7530
00007e2c933dd1fd  call rax
00007e2c933dd1ff  movaps xmm6, [rsp]
00007e2c933dd203  add rsp, 0x30
00007e2c933dd207  vmovaps xmm0, [rsp]
00007e2c933dd20c  vmovaps xmm1, [rsp+0x10]
00007e2c933dd212  vmovaps xmm2, [rsp+0x20]
00007e2c933dd218  vmovaps xmm3, [rsp+0x30]
00007e2c933dd21e  vmovaps xmm4, [rsp+0x40]
00007e2c933dd224  vmovaps xmm5, [rsp+0x50]
00007e2c933dd22a  vmovaps xmm7, [rsp+0x60]
00007e2c933dd230  vmovaps xmm8, [rsp+0x70]
00007e2c933dd236  vmovaps xmm9, [rsp+0x80]
00007e2c933dd23f  vmovaps xmm10, [rsp+0x90]
00007e2c933dd248  vmovaps xmm11, [rsp+0xA0]
00007e2c933dd251  vmovaps xmm12, [rsp+0xB0]
00007e2c933dd25a  vmovaps xmm13, [rsp+0xC0]
00007e2c933dd263  vmovaps xmm14, [rsp+0xD0]
00007e2c933dd26c  vmovaps xmm15, [rsp+0xE0]
00007e2c933dd275  add rsp, 0xF0
00007e2c933dd27c  pop r11
00007e2c933dd27e  pop r10
00007e2c933dd280  pop r9
00007e2c933dd282  pop r8
00007e2c933dd284  pop rsi
00007e2c933dd285  pop rdi
00007e2c933dd286  pop rdx
00007e2c933dd287  pop rcx
00007e2c933dd288  pop rax
00007e2c933dd289  add rsp, 0x08
00007e2c933dd28d  jmp 0x00007E2C933D95BA
00007e2c933dd292  sub rsp, 0x08
00007e2c933dd296  push rax
00007e2c933dd297  push rcx
00007e2c933dd298  push rdx
00007e2c933dd299  push rdi
00007e2c933dd29a  push rsi
00007e2c933dd29b  push r8
00007e2c933dd29d  push r9
00007e2c933dd29f  push r10
00007e2c933dd2a1  push r11
00007e2c933dd2a3  sub rsp, 0xF0
00007e2c933dd2aa  vmovaps [rsp], xmm0
00007e2c933dd2af  vmovaps [rsp+0x10], xmm1
00007e2c933dd2b5  vmovaps [rsp+0x20], xmm2
00007e2c933dd2bb  vmovaps [rsp+0x30], xmm3
00007e2c933dd2c1  vmovaps [rsp+0x40], xmm4
00007e2c933dd2c7  vmovaps [rsp+0x50], xmm5
00007e2c933dd2cd  vmovaps [rsp+0x60], xmm6
00007e2c933dd2d3  vmovaps [rsp+0x70], xmm7
00007e2c933dd2d9  vmovaps [rsp+0x80], xmm8
00007e2c933dd2e2  vmovaps [rsp+0x90], xmm9
00007e2c933dd2eb  vmovaps [rsp+0xA0], xmm10
00007e2c933dd2f4  vmovaps [rsp+0xB0], xmm11
00007e2c933dd2fd  vmovaps [rsp+0xC0], xmm12
00007e2c933dd306  vmovaps [rsp+0xD0], xmm13
00007e2c933dd30f  vmovaps [rsp+0xE0], xmm15
00007e2c933dd318  sub rsp, 0x30
00007e2c933dd31c  movaps [rsp], xmm14
00007e2c933dd321  movaps [rsp+0x10], xmm12
00007e2c933dd327  movaps [rsp+0x20], xmm1
00007e2c933dd32c  lea rdi, [rsp]
00007e2c933dd330  mov esi, 0x00
00007e2c933dd335  mov rax, 0x5A263F1C7530
00007e2c933dd33f  call rax
00007e2c933dd341  movaps xmm14, [rsp]
00007e2c933dd346  add rsp, 0x30
00007e2c933dd34a  vmovaps xmm0, [rsp]
00007e2c933dd34f  vmovaps xmm1, [rsp+0x10]
00007e2c933dd355  vmovaps xmm2, [rsp+0x20]
00007e2c933dd35b  vmovaps xmm3, [rsp+0x30]
00007e2c933dd361  vmovaps xmm4, [rsp+0x40]
00007e2c933dd367  vmovaps xmm5, [rsp+0x50]
00007e2c933dd36d  vmovaps xmm6, [rsp+0x60]
00007e2c933dd373  vmovaps xmm7, [rsp+0x70]
00007e2c933dd379  vmovaps xmm8, [rsp+0x80]
00007e2c933dd382  vmovaps xmm9, [rsp+0x90]
00007e2c933dd38b  vmovaps xmm10, [rsp+0xA0]
00007e2c933dd394  vmovaps xmm11, [rsp+0xB0]
00007e2c933dd39d  vmovaps xmm12, [rsp+0xC0]
00007e2c933dd3a6  vmovaps xmm13, [rsp+0xD0]
00007e2c933dd3af  vmovaps xmm15, [rsp+0xE0]
00007e2c933dd3b8  add rsp, 0xF0
00007e2c933dd3bf  pop r11
00007e2c933dd3c1  pop r10
00007e2c933dd3c3  pop r9
00007e2c933dd3c5  pop r8
00007e2c933dd3c7  pop rsi
00007e2c933dd3c8  pop rdi
00007e2c933dd3c9  pop rdx
00007e2c933dd3ca  pop rcx
00007e2c933dd3cb  pop rax
00007e2c933dd3cc  add rsp, 0x08
00007e2c933dd3d0  jmp 0x00007E2C933D95E0
00007e2c933dd3d5  sub rsp, 0x08
00007e2c933dd3d9  push rax
00007e2c933dd3da  push rcx
00007e2c933dd3db  push rdx
00007e2c933dd3dc  push rdi
00007e2c933dd3dd  push rsi
00007e2c933dd3de  push r8
00007e2c933dd3e0  push r9
00007e2c933dd3e2  push r10
00007e2c933dd3e4  push r11
00007e2c933dd3e6  sub rsp, 0xF0
00007e2c933dd3ed  vmovaps [rsp], xmm0
00007e2c933dd3f2  vmovaps [rsp+0x10], xmm2
00007e2c933dd3f8  vmovaps [rsp+0x20], xmm3
00007e2c933dd3fe  vmovaps [rsp+0x30], xmm4
00007e2c933dd404  vmovaps [rsp+0x40], xmm5
00007e2c933dd40a  vmovaps [rsp+0x50], xmm6
00007e2c933dd410  vmovaps [rsp+0x60], xmm7
00007e2c933dd416  vmovaps [rsp+0x70], xmm8
00007e2c933dd41c  vmovaps [rsp+0x80], xmm9
00007e2c933dd425  vmovaps [rsp+0x90], xmm10
00007e2c933dd42e  vmovaps [rsp+0xA0], xmm11
00007e2c933dd437  vmovaps [rsp+0xB0], xmm12
00007e2c933dd440  vmovaps [rsp+0xC0], xmm13
00007e2c933dd449  vmovaps [rsp+0xD0], xmm14
00007e2c933dd452  vmovaps [rsp+0xE0], xmm15
00007e2c933dd45b  sub rsp, 0x30
00007e2c933dd45f  movaps [rsp], xmm1
00007e2c933dd463  movaps [rsp+0x10], xmm13
00007e2c933dd469  movaps [rsp+0x20], xmm9
00007e2c933dd46f  lea rdi, [rsp]
00007e2c933dd473  mov esi, 0x00
00007e2c933dd478  mov rax, 0x5A263F1C7530
00007e2c933dd482  call rax
00007e2c933dd484  movaps xmm1, [rsp]
00007e2c933dd488  add rsp, 0x30
00007e2c933dd48c  vmovaps xmm0, [rsp]
00007e2c933dd491  vmovaps xmm2, [rsp+0x10]
00007e2c933dd497  vmovaps xmm3, [rsp+0x20]
00007e2c933dd49d  vmovaps xmm4, [rsp+0x30]
00007e2c933dd4a3  vmovaps xmm5, [rsp+0x40]
00007e2c933dd4a9  vmovaps xmm6, [rsp+0x50]
00007e2c933dd4af  vmovaps xmm7, [rsp+0x60]
00007e2c933dd4b5  vmovaps xmm8, [rsp+0x70]
00007e2c933dd4bb  vmovaps xmm9, [rsp+0x80]
00007e2c933dd4c4  vmovaps xmm10, [rsp+0x90]
00007e2c933dd4cd  vmovaps xmm11, [rsp+0xA0]
00007e2c933dd4d6  vmovaps xmm12, [rsp+0xB0]
00007e2c933dd4df  vmovaps xmm13, [rsp+0xC0]
00007e2c933dd4e8  vmovaps xmm14, [rsp+0xD0]
00007e2c933dd4f1  vmovaps xmm15, [rsp+0xE0]
00007e2c933dd4fa  add rsp, 0xF0
00007e2c933dd501  pop r11
00007e2c933dd503  pop r10
00007e2c933dd505  pop r9
00007e2c933dd507  pop r8
00007e2c933dd509  pop rsi
00007e2c933dd50a  pop rdi
00007e2c933dd50b  pop rdx
00007e2c933dd50c  pop rcx
00007e2c933dd50d  pop rax
00007e2c933dd50e  add rsp, 0x08
00007e2c933dd512  jmp 0x00007E2C933D95FA
00007e2c933dd517  sub rsp, 0x08
00007e2c933dd51b  push rax
00007e2c933dd51c  push rcx
00007e2c933dd51d  push rdx
00007e2c933dd51e  push rdi
00007e2c933dd51f  push rsi
00007e2c933dd520  push r8
00007e2c933dd522  push r9
00007e2c933dd524  push r10
00007e2c933dd526  push r11
00007e2c933dd528  sub rsp, 0xF0
00007e2c933dd52f  vmovaps [rsp], xmm0
00007e2c933dd534  vmovaps [rsp+0x10], xmm1
00007e2c933dd53a  vmovaps [rsp+0x20], xmm2
00007e2c933dd540  vmovaps [rsp+0x30], xmm3
00007e2c933dd546  vmovaps [rsp+0x40], xmm4
00007e2c933dd54c  vmovaps [rsp+0x50], xmm5
00007e2c933dd552  vmovaps [rsp+0x60], xmm6
00007e2c933dd558  vmovaps [rsp+0x70], xmm7
00007e2c933dd55e  vmovaps [rsp+0x80], xmm8
00007e2c933dd567  vmovaps [rsp+0x90], xmm9
00007e2c933dd570  vmovaps [rsp+0xA0], xmm10
00007e2c933dd579  vmovaps [rsp+0xB0], xmm11
00007e2c933dd582  vmovaps [rsp+0xC0], xmm13
00007e2c933dd58b  vmovaps [rsp+0xD0], xmm14
00007e2c933dd594  vmovaps [rsp+0xE0], xmm15
00007e2c933dd59d  sub rsp, 0x30
00007e2c933dd5a1  movaps [rsp], xmm12
00007e2c933dd5a6  movaps [rsp+0x10], xmm7
00007e2c933dd5ab  movaps [rsp+0x20], xmm13
00007e2c933dd5b1  lea rdi, [rsp]
00007e2c933dd5b5  mov esi, 0x00
00007e2c933dd5ba  mov rax, 0x5A263F1C7530
00007e2c933dd5c4  call rax
00007e2c933dd5c6  movaps xmm12, [rsp]
00007e2c933dd5cb  add rsp, 0x30
00007e2c933dd5cf  vmovaps xmm0, [rsp]
00007e2c933dd5d4  vmovaps xmm1, [rsp+0x10]
00007e2c933dd5da  vmovaps xmm2, [rsp+0x20]
00007e2c933dd5e0  vmovaps xmm3, [rsp+0x30]
00007e2c933dd5e6  vmovaps xmm4, [rsp+0x40]
00007e2c933dd5ec  vmovaps xmm5, [rsp+0x50]
00007e2c933dd5f2  vmovaps xmm6, [rsp+0x60]
00007e2c933dd5f8  vmovaps xmm7, [rsp+0x70]
00007e2c933dd5fe  vmovaps xmm8, [rsp+0x80]
00007e2c933dd607  vmovaps xmm9, [rsp+0x90]
00007e2c933dd610  vmovaps xmm10, [rsp+0xA0]
00007e2c933dd619  vmovaps xmm11, [rsp+0xB0]
00007e2c933dd622  vmovaps xmm13, [rsp+0xC0]
00007e2c933dd62b  vmovaps xmm14, [rsp+0xD0]
00007e2c933dd634  vmovaps xmm15, [rsp+0xE0]
00007e2c933dd63d  add rsp, 0xF0
00007e2c933dd644  pop r11
00007e2c933dd646  pop r10
00007e2c933dd648  pop r9
00007e2c933dd64a  pop r8
00007e2c933dd64c  pop rsi
00007e2c933dd64d  pop rdi
00007e2c933dd64e  pop rdx
00007e2c933dd64f  pop rcx
00007e2c933dd650  pop rax
00007e2c933dd651  add rsp, 0x08
00007e2c933dd655  jmp 0x00007E2C933D9621
00007e2c933dd65a  sub rsp, 0x08
00007e2c933dd65e  push rax
00007e2c933dd65f  push rcx
00007e2c933dd660  push rdx
00007e2c933dd661  push rdi
00007e2c933dd662  push rsi
00007e2c933dd663  push r8
00007e2c933dd665  push r9
00007e2c933dd667  push r10
00007e2c933dd669  push r11
00007e2c933dd66b  sub rsp, 0xF0
00007e2c933dd672  vmovaps [rsp], xmm0
00007e2c933dd677  vmovaps [rsp+0x10], xmm1
00007e2c933dd67d  vmovaps [rsp+0x20], xmm2
00007e2c933dd683  vmovaps [rsp+0x30], xmm3
00007e2c933dd689  vmovaps [rsp+0x40], xmm4
00007e2c933dd68f  vmovaps [rsp+0x50], xmm5
00007e2c933dd695  vmovaps [rsp+0x60], xmm6
00007e2c933dd69b  vmovaps [rsp+0x70], xmm7
00007e2c933dd6a1  vmovaps [rsp+0x80], xmm8
00007e2c933dd6aa  vmovaps [rsp+0x90], xmm9
00007e2c933dd6b3  vmovaps [rsp+0xA0], xmm10
00007e2c933dd6bc  vmovaps [rsp+0xB0], xmm11
00007e2c933dd6c5  vmovaps [rsp+0xC0], xmm12
00007e2c933dd6ce  vmovaps [rsp+0xD0], xmm14
00007e2c933dd6d7  vmovaps [rsp+0xE0], xmm15
00007e2c933dd6e0  sub rsp, 0x30
00007e2c933dd6e4  movaps [rsp], xmm13
00007e2c933dd6e9  movaps [rsp+0x10], xmm15
00007e2c933dd6ef  movaps [rsp+0x20], xmm8
00007e2c933dd6f5  lea rdi, [rsp]
00007e2c933dd6f9  mov esi, 0x00
00007e2c933dd6fe  mov rax, 0x5A263F1C7530
00007e2c933dd708  call rax
00007e2c933dd70a  movaps xmm13, [rsp]
00007e2c933dd70f  add rsp, 0x30
00007e2c933dd713  vmovaps xmm0, [rsp]
00007e2c933dd718  vmovaps xmm1, [rsp+0x10]
00007e2c933dd71e  vmovaps xmm2, [rsp+0x20]
00007e2c933dd724  vmovaps xmm3, [rsp+0x30]
00007e2c933dd72a  vmovaps xmm4, [rsp+0x40]
00007e2c933dd730  vmovaps xmm5, [rsp+0x50]
00007e2c933dd736  vmovaps xmm6, [rsp+0x60]
00007e2c933dd73c  vmovaps xmm7, [rsp+0x70]
00007e2c933dd742  vmovaps xmm8, [rsp+0x80]
00007e2c933dd74b  vmovaps xmm9, [rsp+0x90]
00007e2c933dd754  vmovaps xmm10, [rsp+0xA0]
00007e2c933dd75d  vmovaps xmm11, [rsp+0xB0]
00007e2c933dd766  vmovaps xmm12, [rsp+0xC0]
00007e2c933dd76f  vmovaps xmm14, [rsp+0xD0]
00007e2c933dd778  vmovaps xmm15, [rsp+0xE0]
00007e2c933dd781  add rsp, 0xF0
00007e2c933dd788  pop r11
00007e2c933dd78a  pop r10
00007e2c933dd78c  pop r9
00007e2c933dd78e  pop r8
00007e2c933dd790  pop rsi
00007e2c933dd791  pop rdi
00007e2c933dd792  pop rdx
00007e2c933dd793  pop rcx
00007e2c933dd794  pop rax
00007e2c933dd795  add rsp, 0x08
00007e2c933dd799  jmp 0x00007E2C933D963C
00007e2c933dd79e  sub rsp, 0x08
00007e2c933dd7a2  push rax
00007e2c933dd7a3  push rcx
00007e2c933dd7a4  push rdx
00007e2c933dd7a5  push rdi
00007e2c933dd7a6  push rsi
00007e2c933dd7a7  push r8
00007e2c933dd7a9  push r9
00007e2c933dd7ab  push r10
00007e2c933dd7ad  push r11
00007e2c933dd7af  sub rsp, 0xF0
00007e2c933dd7b6  vmovaps [rsp], xmm0
00007e2c933dd7bb  vmovaps [rsp+0x10], xmm1
00007e2c933dd7c1  vmovaps [rsp+0x20], xmm2
00007e2c933dd7c7  vmovaps [rsp+0x30], xmm3
00007e2c933dd7cd  vmovaps [rsp+0x40], xmm4
00007e2c933dd7d3  vmovaps [rsp+0x50], xmm5
00007e2c933dd7d9  vmovaps [rsp+0x60], xmm6
00007e2c933dd7df  vmovaps [rsp+0x70], xmm7
00007e2c933dd7e5  vmovaps [rsp+0x80], xmm9
00007e2c933dd7ee  vmovaps [rsp+0x90], xmm10
00007e2c933dd7f7  vmovaps [rsp+0xA0], xmm11
00007e2c933dd800  vmovaps [rsp+0xB0], xmm12
00007e2c933dd809  vmovaps [rsp+0xC0], xmm13
00007e2c933dd812  vmovaps [rsp+0xD0], xmm14
00007e2c933dd81b  vmovaps [rsp+0xE0], xmm15
00007e2c933dd824  sub rsp, 0x30
00007e2c933dd828  movaps [rsp], xmm8
00007e2c933dd82d  movaps [rsp+0x10], xmm15
00007e2c933dd833  movaps [rsp+0x20], xmm9
00007e2c933dd839  lea rdi, [rsp]
00007e2c933dd83d  mov esi, 0x00
00007e2c933dd842  mov rax, 0x5A263F1C7530
00007e2c933dd84c  call rax
00007e2c933dd84e  movaps xmm8, [rsp]
00007e2c933dd853  add rsp, 0x30
00007e2c933dd857  vmovaps xmm0, [rsp]
00007e2c933dd85c  vmovaps xmm1, [rsp+0x10]
00007e2c933dd862  vmovaps xmm2, [rsp+0x20]
00007e2c933dd868  vmovaps xmm3, [rsp+0x30]
00007e2c933dd86e  vmovaps xmm4, [rsp+0x40]
00007e2c933dd874  vmovaps xmm5, [rsp+0x50]
00007e2c933dd87a  vmovaps xmm6, [rsp+0x60]
00007e2c933dd880  vmovaps xmm7, [rsp+0x70]
00007e2c933dd886  vmovaps xmm9, [rsp+0x80]
00007e2c933dd88f  vmovaps xmm10, [rsp+0x90]
00007e2c933dd898  vmovaps xmm11, [rsp+0xA0]
00007e2c933dd8a1  vmovaps xmm12, [rsp+0xB0]
00007e2c933dd8aa  vmovaps xmm13, [rsp+0xC0]
00007e2c933dd8b3  vmovaps xmm14, [rsp+0xD0]
00007e2c933dd8bc  vmovaps xmm15, [rsp+0xE0]
00007e2c933dd8c5  add rsp, 0xF0
00007e2c933dd8cc  pop r11
00007e2c933dd8ce  pop r10
00007e2c933dd8d0  pop r9
00007e2c933dd8d2  pop r8
00007e2c933dd8d4  pop rsi
00007e2c933dd8d5  pop rdi
00007e2c933dd8d6  pop rdx
00007e2c933dd8d7  pop rcx
00007e2c933dd8d8  pop rax
00007e2c933dd8d9  add rsp, 0x08
00007e2c933dd8dd  jmp 0x00007E2C933D966A
00007e2c933dd8e2  sub rsp, 0x08
00007e2c933dd8e6  push rax
00007e2c933dd8e7  push rcx
00007e2c933dd8e8  push rdx
00007e2c933dd8e9  push rdi
00007e2c933dd8ea  push rsi
00007e2c933dd8eb  push r8
00007e2c933dd8ed  push r9
00007e2c933dd8ef  push r10
00007e2c933dd8f1  push r11
00007e2c933dd8f3  sub rsp, 0xF0
00007e2c933dd8fa  vmovaps [rsp], xmm0
00007e2c933dd8ff  vmovaps [rsp+0x10], xmm1
00007e2c933dd905  vmovaps [rsp+0x20], xmm2
00007e2c933dd90b  vmovaps [rsp+0x30], xmm3
00007e2c933dd911  vmovaps [rsp+0x40], xmm4
00007e2c933dd917  vmovaps [rsp+0x50], xmm5
00007e2c933dd91d  vmovaps [rsp+0x60], xmm6
00007e2c933dd923  vmovaps [rsp+0x70], xmm7
00007e2c933dd929  vmovaps [rsp+0x80], xmm8
00007e2c933dd932  vmovaps [rsp+0x90], xmm9
00007e2c933dd93b  vmovaps [rsp+0xA0], xmm10
00007e2c933dd944  vmovaps [rsp+0xB0], xmm11
00007e2c933dd94d  vmovaps [rsp+0xC0], xmm12
00007e2c933dd956  vmovaps [rsp+0xD0], xmm13
00007e2c933dd95f  vmovaps [rsp+0xE0], xmm14
00007e2c933dd968  sub rsp, 0x30
00007e2c933dd96c  movaps [rsp], xmm15
00007e2c933dd971  movaps [rsp+0x10], xmm11
00007e2c933dd977  movaps [rsp+0x20], xmm6
00007e2c933dd97c  lea rdi, [rsp]
00007e2c933dd980  mov esi, 0x00
00007e2c933dd985  mov rax, 0x5A263F1C7530
00007e2c933dd98f  call rax
00007e2c933dd991  movaps xmm15, [rsp]
00007e2c933dd996  add rsp, 0x30
00007e2c933dd99a  vmovaps xmm0, [rsp]
00007e2c933dd99f  vmovaps xmm1, [rsp+0x10]
00007e2c933dd9a5  vmovaps xmm2, [rsp+0x20]
00007e2c933dd9ab  vmovaps xmm3, [rsp+0x30]
00007e2c933dd9b1  vmovaps xmm4, [rsp+0x40]
00007e2c933dd9b7  vmovaps xmm5, [rsp+0x50]
00007e2c933dd9bd  vmovaps xmm6, [rsp+0x60]
00007e2c933dd9c3  vmovaps xmm7, [rsp+0x70]
00007e2c933dd9c9  vmovaps xmm8, [rsp+0x80]
00007e2c933dd9d2  vmovaps xmm9, [rsp+0x90]
00007e2c933dd9db  vmovaps xmm10, [rsp+0xA0]
00007e2c933dd9e4  vmovaps xmm11, [rsp+0xB0]
00007e2c933dd9ed  vmovaps xmm12, [rsp+0xC0]
00007e2c933dd9f6  vmovaps xmm13, [rsp+0xD0]
00007e2c933dd9ff  vmovaps xmm14, [rsp+0xE0]
00007e2c933dda08  add rsp, 0xF0
00007e2c933dda0f  pop r11
00007e2c933dda11  pop r10
00007e2c933dda13  pop r9
00007e2c933dda15  pop r8
00007e2c933dda17  pop rsi
00007e2c933dda18  pop rdi
00007e2c933dda19  pop rdx
00007e2c933dda1a  pop rcx
00007e2c933dda1b  pop rax
00007e2c933dda1c  add rsp, 0x08
00007e2c933dda20  jmp 0x00007E2C933D9685
00007e2c933dda25  sub rsp, 0x08
00007e2c933dda29  push rax
00007e2c933dda2a  push rcx
00007e2c933dda2b  push rdx
00007e2c933dda2c  push rdi
00007e2c933dda2d  push rsi
00007e2c933dda2e  push r8
00007e2c933dda30  push r9
00007e2c933dda32  push r10
00007e2c933dda34  push r11
00007e2c933dda36  sub rsp, 0xF0
00007e2c933dda3d  vmovaps [rsp], xmm0
00007e2c933dda42  vmovaps [rsp+0x10], xmm1
00007e2c933dda48  vmovaps [rsp+0x20], xmm2
00007e2c933dda4e  vmovaps [rsp+0x30], xmm3
00007e2c933dda54  vmovaps [rsp+0x40], xmm4
00007e2c933dda5a  vmovaps [rsp+0x50], xmm5
00007e2c933dda60  vmovaps [rsp+0x60], xmm6
00007e2c933dda66  vmovaps [rsp+0x70], xmm8
00007e2c933dda6c  vmovaps [rsp+0x80], xmm9
00007e2c933dda75  vmovaps [rsp+0x90], xmm10
00007e2c933dda7e  vmovaps [rsp+0xA0], xmm11
00007e2c933dda87  vmovaps [rsp+0xB0], xmm12
00007e2c933dda90  vmovaps [rsp+0xC0], xmm13
00007e2c933dda99  vmovaps [rsp+0xD0], xmm14
00007e2c933ddaa2  vmovaps [rsp+0xE0], xmm15
00007e2c933ddaab  sub rsp, 0x30
00007e2c933ddaaf  movaps [rsp], xmm7
00007e2c933ddab3  movaps [rsp+0x10], xmm11
00007e2c933ddab9  movaps [rsp+0x20], xmm9
00007e2c933ddabf  lea rdi, [rsp]
00007e2c933ddac3  mov esi, 0x00
00007e2c933ddac8  mov rax, 0x5A263F1C7530
00007e2c933ddad2  call rax
00007e2c933ddad4  movaps xmm7, [rsp]
00007e2c933ddad8  add rsp, 0x30
00007e2c933ddadc  vmovaps xmm0, [rsp]
00007e2c933ddae1  vmovaps xmm1, [rsp+0x10]
00007e2c933ddae7  vmovaps xmm2, [rsp+0x20]
00007e2c933ddaed  vmovaps xmm3, [rsp+0x30]
00007e2c933ddaf3  vmovaps xmm4, [rsp+0x40]
00007e2c933ddaf9  vmovaps xmm5, [rsp+0x50]
00007e2c933ddaff  vmovaps xmm6, [rsp+0x60]
00007e2c933ddb05  vmovaps xmm8, [rsp+0x70]
00007e2c933ddb0b  vmovaps xmm9, [rsp+0x80]
00007e2c933ddb14  vmovaps xmm10, [rsp+0x90]
00007e2c933ddb1d  vmovaps xmm11, [rsp+0xA0]
00007e2c933ddb26  vmovaps xmm12, [rsp+0xB0]
00007e2c933ddb2f  vmovaps xmm13, [rsp+0xC0]
00007e2c933ddb38  vmovaps xmm14, [rsp+0xD0]
00007e2c933ddb41  vmovaps xmm15, [rsp+0xE0]
00007e2c933ddb4a  add rsp, 0xF0
00007e2c933ddb51  pop r11
00007e2c933ddb53  pop r10
00007e2c933ddb55  pop r9
00007e2c933ddb57  pop r8
00007e2c933ddb59  pop rsi
00007e2c933ddb5a  pop rdi
00007e2c933ddb5b  pop rdx
00007e2c933ddb5c  pop rcx
00007e2c933ddb5d  pop rax
00007e2c933ddb5e  add rsp, 0x08
00007e2c933ddb62  jmp 0x00007E2C933D96B2
00007e2c933ddb67  sub rsp, 0x08
00007e2c933ddb6b  push rax
00007e2c933ddb6c  push rcx
00007e2c933ddb6d  push rdx
00007e2c933ddb6e  push rdi
00007e2c933ddb6f  push rsi
00007e2c933ddb70  push r8
00007e2c933ddb72  push r9
00007e2c933ddb74  push r10
00007e2c933ddb76  push r11
00007e2c933ddb78  sub rsp, 0xF0
00007e2c933ddb7f  vmovaps [rsp], xmm0
00007e2c933ddb84  vmovaps [rsp+0x10], xmm1
00007e2c933ddb8a  vmovaps [rsp+0x20], xmm2
00007e2c933ddb90  vmovaps [rsp+0x30], xmm3
00007e2c933ddb96  vmovaps [rsp+0x40], xmm4
00007e2c933ddb9c  vmovaps [rsp+0x50], xmm5
00007e2c933ddba2  vmovaps [rsp+0x60], xmm6
00007e2c933ddba8  vmovaps [rsp+0x70], xmm7
00007e2c933ddbae  vmovaps [rsp+0x80], xmm8
00007e2c933ddbb7  vmovaps [rsp+0x90], xmm9
00007e2c933ddbc0  vmovaps [rsp+0xA0], xmm10
00007e2c933ddbc9  vmovaps [rsp+0xB0], xmm12
00007e2c933ddbd2  vmovaps [rsp+0xC0], xmm13
00007e2c933ddbdb  vmovaps [rsp+0xD0], xmm14
00007e2c933ddbe4  vmovaps [rsp+0xE0], xmm15
00007e2c933ddbed  sub rsp, 0x30
00007e2c933ddbf1  movaps [rsp], xmm11
00007e2c933ddbf6  movaps [rsp+0x10], xmm10
00007e2c933ddbfc  movaps [rsp+0x20], xmm14
00007e2c933ddc02  lea rdi, [rsp]
00007e2c933ddc06  mov esi, 0x00
00007e2c933ddc0b  mov rax, 0x5A263F1C7530
00007e2c933ddc15  call rax
00007e2c933ddc17  movaps xmm11, [rsp]
00007e2c933ddc1c  add rsp, 0x30
00007e2c933ddc20  vmovaps xmm0, [rsp]
00007e2c933ddc25  vmovaps xmm1, [rsp+0x10]
00007e2c933ddc2b  vmovaps xmm2, [rsp+0x20]
00007e2c933ddc31  vmovaps xmm3, [rsp+0x30]
00007e2c933ddc37  vmovaps xmm4, [rsp+0x40]
00007e2c933ddc3d  vmovaps xmm5, [rsp+0x50]
00007e2c933ddc43  vmovaps xmm6, [rsp+0x60]
00007e2c933ddc49  vmovaps xmm7, [rsp+0x70]
00007e2c933ddc4f  vmovaps xmm8, [rsp+0x80]
00007e2c933ddc58  vmovaps xmm9, [rsp+0x90]
00007e2c933ddc61  vmovaps xmm10, [rsp+0xA0]
00007e2c933ddc6a  vmovaps xmm12, [rsp+0xB0]
00007e2c933ddc73  vmovaps xmm13, [rsp+0xC0]
00007e2c933ddc7c  vmovaps xmm14, [rsp+0xD0]
00007e2c933ddc85  vmovaps xmm15, [rsp+0xE0]
00007e2c933ddc8e  add rsp, 0xF0
00007e2c933ddc95  pop r11
00007e2c933ddc97  pop r10
00007e2c933ddc99  pop r9
00007e2c933ddc9b  pop r8
00007e2c933ddc9d  pop rsi
00007e2c933ddc9e  pop rdi
00007e2c933ddc9f  pop rdx
00007e2c933ddca0  pop rcx
00007e2c933ddca1  pop rax
00007e2c933ddca2  add rsp, 0x08
00007e2c933ddca6  jmp 0x00007E2C933D96CD
00007e2c933ddcab  call 0x00007E2C932E45A0
00007e2c933ddcb0  jmp 0x00007E2C933D96D7
00007e2c933ddcb5  sub rsp, 0x08
00007e2c933ddcb9  push rax
00007e2c933ddcba  push rcx
00007e2c933ddcbb  push rdx
00007e2c933ddcbc  push rdi
00007e2c933ddcbd  push rsi
00007e2c933ddcbe  push r8
00007e2c933ddcc0  push r9
00007e2c933ddcc2  push r10
00007e2c933ddcc4  push r11
00007e2c933ddcc6  sub rsp, 0xF0
00007e2c933ddccd  vmovaps [rsp], xmm0
00007e2c933ddcd2  vmovaps [rsp+0x10], xmm1
00007e2c933ddcd8  vmovaps [rsp+0x20], xmm2
00007e2c933ddcde  vmovaps [rsp+0x30], xmm3
00007e2c933ddce4  vmovaps [rsp+0x40], xmm4
00007e2c933ddcea  vmovaps [rsp+0x50], xmm5
00007e2c933ddcf0  vmovaps [rsp+0x60], xmm6
00007e2c933ddcf6  vmovaps [rsp+0x70], xmm7
00007e2c933ddcfc  vmovaps [rsp+0x80], xmm8
00007e2c933ddd05  vmovaps [rsp+0x90], xmm9
00007e2c933ddd0e  vmovaps [rsp+0xA0], xmm11
00007e2c933ddd17  vmovaps [rsp+0xB0], xmm12
00007e2c933ddd20  vmovaps [rsp+0xC0], xmm13
00007e2c933ddd29  vmovaps [rsp+0xD0], xmm14
00007e2c933ddd32  vmovaps [rsp+0xE0], xmm15
00007e2c933ddd3b  sub rsp, 0x30
00007e2c933ddd3f  movaps [rsp], xmm10
00007e2c933ddd44  movaps [rsp+0x10], xmm1
00007e2c933ddd49  movaps [rsp+0x20], xmm12
00007e2c933ddd4f  lea rdi, [rsp]
00007e2c933ddd53  mov esi, 0x00
00007e2c933ddd58  mov rax, 0x5A263F1C7530
00007e2c933ddd62  call rax
00007e2c933ddd64  movaps xmm10, [rsp]
00007e2c933ddd69  add rsp, 0x30
00007e2c933ddd6d  vmovaps xmm0, [rsp]
00007e2c933ddd72  vmovaps xmm1, [rsp+0x10]
00007e2c933ddd78  vmovaps xmm2, [rsp+0x20]
00007e2c933ddd7e  vmovaps xmm3, [rsp+0x30]
00007e2c933ddd84  vmovaps xmm4, [rsp+0x40]
00007e2c933ddd8a  vmovaps xmm5, [rsp+0x50]
00007e2c933ddd90  vmovaps xmm6, [rsp+0x60]
00007e2c933ddd96  vmovaps xmm7, [rsp+0x70]
00007e2c933ddd9c  vmovaps xmm8, [rsp+0x80]
00007e2c933ddda5  vmovaps xmm9, [rsp+0x90]
00007e2c933dddae  vmovaps xmm11, [rsp+0xA0]
00007e2c933dddb7  vmovaps xmm12, [rsp+0xB0]
00007e2c933dddc0  vmovaps xmm13, [rsp+0xC0]
00007e2c933dddc9  vmovaps xmm14, [rsp+0xD0]
00007e2c933dddd2  vmovaps xmm15, [rsp+0xE0]
00007e2c933ddddb  add rsp, 0xF0
00007e2c933ddde2  pop r11
00007e2c933ddde4  pop r10
00007e2c933ddde6  pop r9
00007e2c933ddde8  pop r8
00007e2c933dddea  pop rsi
00007e2c933dddeb  pop rdi
00007e2c933dddec  pop rdx
00007e2c933ddded  pop rcx
00007e2c933dddee  pop rax
00007e2c933dddef  add rsp, 0x08
00007e2c933dddf3  jmp 0x00007E2C933D96FA
00007e2c933dddf8  sub rsp, 0x08
00007e2c933dddfc  push rax
00007e2c933dddfd  push rcx
00007e2c933dddfe  push rdx
00007e2c933dddff  push rdi
00007e2c933dde00  push rsi
00007e2c933dde01  push r8
00007e2c933dde03  push r9
00007e2c933dde05  push r10
00007e2c933dde07  push r11
00007e2c933dde09  sub rsp, 0xF0
00007e2c933dde10  vmovaps [rsp], xmm0
00007e2c933dde15  vmovaps [rsp+0x10], xmm1
00007e2c933dde1b  vmovaps [rsp+0x20], xmm2
00007e2c933dde21  vmovaps [rsp+0x30], xmm3
00007e2c933dde27  vmovaps [rsp+0x40], xmm4
00007e2c933dde2d  vmovaps [rsp+0x50], xmm5
00007e2c933dde33  vmovaps [rsp+0x60], xmm6
00007e2c933dde39  vmovaps [rsp+0x70], xmm7
00007e2c933dde3f  vmovaps [rsp+0x80], xmm8
00007e2c933dde48  vmovaps [rsp+0x90], xmm9
00007e2c933dde51  vmovaps [rsp+0xA0], xmm10
00007e2c933dde5a  vmovaps [rsp+0xB0], xmm11
00007e2c933dde63  vmovaps [rsp+0xC0], xmm13
00007e2c933dde6c  vmovaps [rsp+0xD0], xmm14
00007e2c933dde75  vmovaps [rsp+0xE0], xmm15
00007e2c933dde7e  sub rsp, 0x30
00007e2c933dde82  movaps [rsp], xmm12
00007e2c933dde87  movaps [rsp+0x10], xmm14
00007e2c933dde8d  movaps [rsp+0x20], xmm1
00007e2c933dde92  lea rdi, [rsp]
00007e2c933dde96  mov esi, 0x00
00007e2c933dde9b  mov rax, 0x5A263F1C7530
00007e2c933ddea5  call rax
00007e2c933ddea7  movaps xmm12, [rsp]
00007e2c933ddeac  add rsp, 0x30
00007e2c933ddeb0  vmovaps xmm0, [rsp]
00007e2c933ddeb5  vmovaps xmm1, [rsp+0x10]
00007e2c933ddebb  vmovaps xmm2, [rsp+0x20]
00007e2c933ddec1  vmovaps xmm3, [rsp+0x30]
00007e2c933ddec7  vmovaps xmm4, [rsp+0x40]
00007e2c933ddecd  vmovaps xmm5, [rsp+0x50]
00007e2c933dded3  vmovaps xmm6, [rsp+0x60]
00007e2c933dded9  vmovaps xmm7, [rsp+0x70]
00007e2c933ddedf  vmovaps xmm8, [rsp+0x80]
00007e2c933ddee8  vmovaps xmm9, [rsp+0x90]
00007e2c933ddef1  vmovaps xmm10, [rsp+0xA0]
00007e2c933ddefa  vmovaps xmm11, [rsp+0xB0]
00007e2c933ddf03  vmovaps xmm13, [rsp+0xC0]
00007e2c933ddf0c  vmovaps xmm14, [rsp+0xD0]
00007e2c933ddf15  vmovaps xmm15, [rsp+0xE0]
00007e2c933ddf1e  add rsp, 0xF0
00007e2c933ddf25  pop r11
00007e2c933ddf27  pop r10
00007e2c933ddf29  pop r9
00007e2c933ddf2b  pop r8
00007e2c933ddf2d  pop rsi
00007e2c933ddf2e  pop rdi
00007e2c933ddf2f  pop rdx
00007e2c933ddf30  pop rcx
00007e2c933ddf31  pop rax
00007e2c933ddf32  add rsp, 0x08
00007e2c933ddf36  jmp 0x00007E2C933D9729
00007e2c933ddf3b  sub rsp, 0x08
00007e2c933ddf3f  push rax
00007e2c933ddf40  push rcx
00007e2c933ddf41  push rdx
00007e2c933ddf42  push rdi
00007e2c933ddf43  push rsi
00007e2c933ddf44  push r8
00007e2c933ddf46  push r9
00007e2c933ddf48  push r10
00007e2c933ddf4a  push r11
00007e2c933ddf4c  sub rsp, 0xF0
00007e2c933ddf53  vmovaps [rsp], xmm0
00007e2c933ddf58  vmovaps [rsp+0x10], xmm1
00007e2c933ddf5e  vmovaps [rsp+0x20], xmm2
00007e2c933ddf64  vmovaps [rsp+0x30], xmm3
00007e2c933ddf6a  vmovaps [rsp+0x40], xmm4
00007e2c933ddf70  vmovaps [rsp+0x50], xmm5
00007e2c933ddf76  vmovaps [rsp+0x60], xmm6
00007e2c933ddf7c  vmovaps [rsp+0x70], xmm7
00007e2c933ddf82  vmovaps [rsp+0x80], xmm8
00007e2c933ddf8b  vmovaps [rsp+0x90], xmm9
00007e2c933ddf94  vmovaps [rsp+0xA0], xmm10
00007e2c933ddf9d  vmovaps [rsp+0xB0], xmm11
00007e2c933ddfa6  vmovaps [rsp+0xC0], xmm12
00007e2c933ddfaf  vmovaps [rsp+0xD0], xmm13
00007e2c933ddfb8  vmovaps [rsp+0xE0], xmm15
00007e2c933ddfc1  sub rsp, 0x30
00007e2c933ddfc5  movaps [rsp], xmm14
00007e2c933ddfca  movaps [rsp+0x10], xmm9
00007e2c933ddfd0  movaps [rsp+0x20], xmm1
00007e2c933ddfd5  lea rdi, [rsp]
00007e2c933ddfd9  mov esi, 0x00
00007e2c933ddfde  mov rax, 0x5A263F1C7530
00007e2c933ddfe8  call rax
00007e2c933ddfea  movaps xmm14, [rsp]
00007e2c933ddfef  add rsp, 0x30
00007e2c933ddff3  vmovaps xmm0, [rsp]
00007e2c933ddff8  vmovaps xmm1, [rsp+0x10]
00007e2c933ddffe  vmovaps xmm2, [rsp+0x20]
00007e2c933de004  vmovaps xmm3, [rsp+0x30]
00007e2c933de00a  vmovaps xmm4, [rsp+0x40]
00007e2c933de010  vmovaps xmm5, [rsp+0x50]
00007e2c933de016  vmovaps xmm6, [rsp+0x60]
00007e2c933de01c  vmovaps xmm7, [rsp+0x70]
00007e2c933de022  vmovaps xmm8, [rsp+0x80]
00007e2c933de02b  vmovaps xmm9, [rsp+0x90]
00007e2c933de034  vmovaps xmm10, [rsp+0xA0]
00007e2c933de03d  vmovaps xmm11, [rsp+0xB0]
00007e2c933de046  vmovaps xmm12, [rsp+0xC0]
00007e2c933de04f  vmovaps xmm13, [rsp+0xD0]
00007e2c933de058  vmovaps xmm15, [rsp+0xE0]
00007e2c933de061  add rsp, 0xF0
00007e2c933de068  pop r11
00007e2c933de06a  pop r10
00007e2c933de06c  pop r9
00007e2c933de06e  pop r8
00007e2c933de070  pop rsi
00007e2c933de071  pop rdi
00007e2c933de072  pop rdx
00007e2c933de073  pop rcx
00007e2c933de074  pop rax
00007e2c933de075  add rsp, 0x08
00007e2c933de079  jmp 0x00007E2C933D9758
00007e2c933de07e  sub rsp, 0x08
00007e2c933de082  push rax
00007e2c933de083  push rcx
00007e2c933de084  push rdx
00007e2c933de085  push rdi
00007e2c933de086  push rsi
00007e2c933de087  push r8
00007e2c933de089  push r9
00007e2c933de08b  push r10
00007e2c933de08d  push r11
00007e2c933de08f  sub rsp, 0xF0
00007e2c933de096  vmovaps [rsp], xmm0
00007e2c933de09b  vmovaps [rsp+0x10], xmm2
00007e2c933de0a1  vmovaps [rsp+0x20], xmm3
00007e2c933de0a7  vmovaps [rsp+0x30], xmm4
00007e2c933de0ad  vmovaps [rsp+0x40], xmm5
00007e2c933de0b3  vmovaps [rsp+0x50], xmm6
00007e2c933de0b9  vmovaps [rsp+0x60], xmm7
00007e2c933de0bf  vmovaps [rsp+0x70], xmm8
00007e2c933de0c5  vmovaps [rsp+0x80], xmm9
00007e2c933de0ce  vmovaps [rsp+0x90], xmm10
00007e2c933de0d7  vmovaps [rsp+0xA0], xmm11
00007e2c933de0e0  vmovaps [rsp+0xB0], xmm12
00007e2c933de0e9  vmovaps [rsp+0xC0], xmm13
00007e2c933de0f2  vmovaps [rsp+0xD0], xmm14
00007e2c933de0fb  vmovaps [rsp+0xE0], xmm15
00007e2c933de104  sub rsp, 0x30
00007e2c933de108  movaps [rsp], xmm1
00007e2c933de10c  movaps [rsp+0x10], xmm13
00007e2c933de112  movaps [rsp+0x20], xmm8
00007e2c933de118  lea rdi, [rsp]
00007e2c933de11c  mov esi, 0x00
00007e2c933de121  mov rax, 0x5A263F1C7530
00007e2c933de12b  call rax
00007e2c933de12d  movaps xmm1, [rsp]
00007e2c933de131  add rsp, 0x30
00007e2c933de135  vmovaps xmm0, [rsp]
00007e2c933de13a  vmovaps xmm2, [rsp+0x10]
00007e2c933de140  vmovaps xmm3, [rsp+0x20]
00007e2c933de146  vmovaps xmm4, [rsp+0x30]
00007e2c933de14c  vmovaps xmm5, [rsp+0x40]
00007e2c933de152  vmovaps xmm6, [rsp+0x50]
00007e2c933de158  vmovaps xmm7, [rsp+0x60]
00007e2c933de15e  vmovaps xmm8, [rsp+0x70]
00007e2c933de164  vmovaps xmm9, [rsp+0x80]
00007e2c933de16d  vmovaps xmm10, [rsp+0x90]
00007e2c933de176  vmovaps xmm11, [rsp+0xA0]
00007e2c933de17f  vmovaps xmm12, [rsp+0xB0]
00007e2c933de188  vmovaps xmm13, [rsp+0xC0]
00007e2c933de191  vmovaps xmm14, [rsp+0xD0]
00007e2c933de19a  vmovaps xmm15, [rsp+0xE0]
00007e2c933de1a3  add rsp, 0xF0
00007e2c933de1aa  pop r11
00007e2c933de1ac  pop r10
00007e2c933de1ae  pop r9
00007e2c933de1b0  pop r8
00007e2c933de1b2  pop rsi
00007e2c933de1b3  pop rdi
00007e2c933de1b4  pop rdx
00007e2c933de1b5  pop rcx
00007e2c933de1b6  pop rax
00007e2c933de1b7  add rsp, 0x08
00007e2c933de1bb  jmp 0x00007E2C933D977A
00007e2c933de1c0  call 0x00007E2C9320C260
00007e2c933de1c5  jmp 0x00007E2C933D9788
00007e2c933de1ca  call 0x00007E2C932DE950
00007e2c933de1cf  jmp 0x00007E2C933D9792
00007e2c933de1d4  sub rsp, 0x08
00007e2c933de1d8  push rax
00007e2c933de1d9  push rcx
00007e2c933de1da  push rdx
00007e2c933de1db  push rdi
00007e2c933de1dc  push rsi
00007e2c933de1dd  push r8
00007e2c933de1df  push r9
00007e2c933de1e1  push r10
00007e2c933de1e3  push r11
00007e2c933de1e5  sub rsp, 0xF0
00007e2c933de1ec  vmovaps [rsp], xmm0
00007e2c933de1f1  vmovaps [rsp+0x10], xmm1
00007e2c933de1f7  vmovaps [rsp+0x20], xmm2
00007e2c933de1fd  vmovaps [rsp+0x30], xmm3
00007e2c933de203  vmovaps [rsp+0x40], xmm4
00007e2c933de209  vmovaps [rsp+0x50], xmm5
00007e2c933de20f  vmovaps [rsp+0x60], xmm6
00007e2c933de215  vmovaps [rsp+0x70], xmm7
00007e2c933de21b  vmovaps [rsp+0x80], xmm9
00007e2c933de224  vmovaps [rsp+0x90], xmm10
00007e2c933de22d  vmovaps [rsp+0xA0], xmm11
00007e2c933de236  vmovaps [rsp+0xB0], xmm12
00007e2c933de23f  vmovaps [rsp+0xC0], xmm13
00007e2c933de248  vmovaps [rsp+0xD0], xmm14
00007e2c933de251  vmovaps [rsp+0xE0], xmm15
00007e2c933de25a  sub rsp, 0x30
00007e2c933de25e  movaps [rsp], xmm8
00007e2c933de263  movaps [rsp+0x10], xmm15
00007e2c933de269  movaps [rsp+0x20], xmm7
00007e2c933de26e  lea rdi, [rsp]
00007e2c933de272  mov esi, 0x00
00007e2c933de277  mov rax, 0x5A263F1C7530
00007e2c933de281  call rax
00007e2c933de283  movaps xmm8, [rsp]
00007e2c933de288  add rsp, 0x30
00007e2c933de28c  vmovaps xmm0, [rsp]
00007e2c933de291  vmovaps xmm1, [rsp+0x10]
00007e2c933de297  vmovaps xmm2, [rsp+0x20]
00007e2c933de29d  vmovaps xmm3, [rsp+0x30]
00007e2c933de2a3  vmovaps xmm4, [rsp+0x40]
00007e2c933de2a9  vmovaps xmm5, [rsp+0x50]
00007e2c933de2af  vmovaps xmm6, [rsp+0x60]
00007e2c933de2b5  vmovaps xmm7, [rsp+0x70]
00007e2c933de2bb  vmovaps xmm9, [rsp+0x80]
00007e2c933de2c4  vmovaps xmm10, [rsp+0x90]
00007e2c933de2cd  vmovaps xmm11, [rsp+0xA0]
00007e2c933de2d6  vmovaps xmm12, [rsp+0xB0]
00007e2c933de2df  vmovaps xmm13, [rsp+0xC0]
00007e2c933de2e8  vmovaps xmm14, [rsp+0xD0]
00007e2c933de2f1  vmovaps xmm15, [rsp+0xE0]
00007e2c933de2fa  add rsp, 0xF0
00007e2c933de301  pop r11
00007e2c933de303  pop r10
00007e2c933de305  pop r9
00007e2c933de307  pop r8
00007e2c933de309  pop rsi
00007e2c933de30a  pop rdi
00007e2c933de30b  pop rdx
00007e2c933de30c  pop rcx
00007e2c933de30d  pop rax
00007e2c933de30e  add rsp, 0x08
00007e2c933de312  jmp 0x00007E2C933D97B4
00007e2c933de317  sub rsp, 0x08
00007e2c933de31b  push rax
00007e2c933de31c  push rcx
00007e2c933de31d  push rdx
00007e2c933de31e  push rdi
00007e2c933de31f  push rsi
00007e2c933de320  push r8
00007e2c933de322  push r9
00007e2c933de324  push r10
00007e2c933de326  push r11
00007e2c933de328  sub rsp, 0xF0
00007e2c933de32f  vmovaps [rsp], xmm0
00007e2c933de334  vmovaps [rsp+0x10], xmm1
00007e2c933de33a  vmovaps [rsp+0x20], xmm2
00007e2c933de340  vmovaps [rsp+0x30], xmm3
00007e2c933de346  vmovaps [rsp+0x40], xmm4
00007e2c933de34c  vmovaps [rsp+0x50], xmm5
00007e2c933de352  vmovaps [rsp+0x60], xmm6
00007e2c933de358  vmovaps [rsp+0x70], xmm8
00007e2c933de35e  vmovaps [rsp+0x80], xmm9
00007e2c933de367  vmovaps [rsp+0x90], xmm10
00007e2c933de370  vmovaps [rsp+0xA0], xmm11
00007e2c933de379  vmovaps [rsp+0xB0], xmm12
00007e2c933de382  vmovaps [rsp+0xC0], xmm13
00007e2c933de38b  vmovaps [rsp+0xD0], xmm14
00007e2c933de394  vmovaps [rsp+0xE0], xmm15
00007e2c933de39d  sub rsp, 0x30
00007e2c933de3a1  movaps [rsp], xmm7
00007e2c933de3a5  movaps [rsp+0x10], xmm9
00007e2c933de3ab  movaps [rsp+0x20], xmm15
00007e2c933de3b1  lea rdi, [rsp]
00007e2c933de3b5  mov esi, 0x00
00007e2c933de3ba  mov rax, 0x5A263F1C7530
00007e2c933de3c4  call rax
00007e2c933de3c6  movaps xmm7, [rsp]
00007e2c933de3ca  add rsp, 0x30
00007e2c933de3ce  vmovaps xmm0, [rsp]
00007e2c933de3d3  vmovaps xmm1, [rsp+0x10]
00007e2c933de3d9  vmovaps xmm2, [rsp+0x20]
00007e2c933de3df  vmovaps xmm3, [rsp+0x30]
00007e2c933de3e5  vmovaps xmm4, [rsp+0x40]
00007e2c933de3eb  vmovaps xmm5, [rsp+0x50]
00007e2c933de3f1  vmovaps xmm6, [rsp+0x60]
00007e2c933de3f7  vmovaps xmm8, [rsp+0x70]
00007e2c933de3fd  vmovaps xmm9, [rsp+0x80]
00007e2c933de406  vmovaps xmm10, [rsp+0x90]
00007e2c933de40f  vmovaps xmm11, [rsp+0xA0]
00007e2c933de418  vmovaps xmm12, [rsp+0xB0]
00007e2c933de421  vmovaps xmm13, [rsp+0xC0]
00007e2c933de42a  vmovaps xmm14, [rsp+0xD0]
00007e2c933de433  vmovaps xmm15, [rsp+0xE0]
00007e2c933de43c  add rsp, 0xF0
00007e2c933de443  pop r11
00007e2c933de445  pop r10
00007e2c933de447  pop r9
00007e2c933de449  pop r8
00007e2c933de44b  pop rsi
00007e2c933de44c  pop rdi
00007e2c933de44d  pop rdx
00007e2c933de44e  pop rcx
00007e2c933de44f  pop rax
00007e2c933de450  add rsp, 0x08
00007e2c933de454  jmp 0x00007E2C933D97E1
00007e2c933de459  sub rsp, 0x08
00007e2c933de45d  push rax
00007e2c933de45e  push rcx
00007e2c933de45f  push rdx
00007e2c933de460  push rdi
00007e2c933de461  push rsi
00007e2c933de462  push r8
00007e2c933de464  push r9
00007e2c933de466  push r10
00007e2c933de468  push r11
00007e2c933de46a  sub rsp, 0xF0
00007e2c933de471  vmovaps [rsp], xmm0
00007e2c933de476  vmovaps [rsp+0x10], xmm1
00007e2c933de47c  vmovaps [rsp+0x20], xmm2
00007e2c933de482  vmovaps [rsp+0x30], xmm3
00007e2c933de488  vmovaps [rsp+0x40], xmm4
00007e2c933de48e  vmovaps [rsp+0x50], xmm5
00007e2c933de494  vmovaps [rsp+0x60], xmm6
00007e2c933de49a  vmovaps [rsp+0x70], xmm7
00007e2c933de4a0  vmovaps [rsp+0x80], xmm8
00007e2c933de4a9  vmovaps [rsp+0x90], xmm10
00007e2c933de4b2  vmovaps [rsp+0xA0], xmm11
00007e2c933de4bb  vmovaps [rsp+0xB0], xmm12
00007e2c933de4c4  vmovaps [rsp+0xC0], xmm13
00007e2c933de4cd  vmovaps [rsp+0xD0], xmm14
00007e2c933de4d6  vmovaps [rsp+0xE0], xmm15
00007e2c933de4df  sub rsp, 0x30
00007e2c933de4e3  movaps [rsp], xmm9
00007e2c933de4e8  movaps [rsp+0x10], xmm13
00007e2c933de4ee  movaps [rsp+0x20], xmm15
00007e2c933de4f4  lea rdi, [rsp]
00007e2c933de4f8  mov esi, 0x00
00007e2c933de4fd  mov rax, 0x5A263F1C7530
00007e2c933de507  call rax
00007e2c933de509  movaps xmm9, [rsp]
00007e2c933de50e  add rsp, 0x30
00007e2c933de512  vmovaps xmm0, [rsp]
00007e2c933de517  vmovaps xmm1, [rsp+0x10]
00007e2c933de51d  vmovaps xmm2, [rsp+0x20]
00007e2c933de523  vmovaps xmm3, [rsp+0x30]
00007e2c933de529  vmovaps xmm4, [rsp+0x40]
00007e2c933de52f  vmovaps xmm5, [rsp+0x50]
00007e2c933de535  vmovaps xmm6, [rsp+0x60]
00007e2c933de53b  vmovaps xmm7, [rsp+0x70]
00007e2c933de541  vmovaps xmm8, [rsp+0x80]
00007e2c933de54a  vmovaps xmm10, [rsp+0x90]
00007e2c933de553  vmovaps xmm11, [rsp+0xA0]
00007e2c933de55c  vmovaps xmm12, [rsp+0xB0]
00007e2c933de565  vmovaps xmm13, [rsp+0xC0]
00007e2c933de56e  vmovaps xmm14, [rsp+0xD0]
00007e2c933de577  vmovaps xmm15, [rsp+0xE0]
00007e2c933de580  add rsp, 0xF0
00007e2c933de587  pop r11
00007e2c933de589  pop r10
00007e2c933de58b  pop r9
00007e2c933de58d  pop r8
00007e2c933de58f  pop rsi
00007e2c933de590  pop rdi
00007e2c933de591  pop rdx
00007e2c933de592  pop rcx
00007e2c933de593  pop rax
00007e2c933de594  add rsp, 0x08
00007e2c933de598  jmp 0x00007E2C933D980F
00007e2c933de59d  sub rsp, 0x08
00007e2c933de5a1  push rax
00007e2c933de5a2  push rcx
00007e2c933de5a3  push rdx
00007e2c933de5a4  push rdi
00007e2c933de5a5  push rsi
00007e2c933de5a6  push r8
00007e2c933de5a8  push r9
00007e2c933de5aa  push r10
00007e2c933de5ac  push r11
00007e2c933de5ae  sub rsp, 0xF0
00007e2c933de5b5  vmovaps [rsp], xmm0
00007e2c933de5ba  vmovaps [rsp+0x10], xmm1
00007e2c933de5c0  vmovaps [rsp+0x20], xmm2
00007e2c933de5c6  vmovaps [rsp+0x30], xmm3
00007e2c933de5cc  vmovaps [rsp+0x40], xmm4
00007e2c933de5d2  vmovaps [rsp+0x50], xmm5
00007e2c933de5d8  vmovaps [rsp+0x60], xmm6
00007e2c933de5de  vmovaps [rsp+0x70], xmm7
00007e2c933de5e4  vmovaps [rsp+0x80], xmm8
00007e2c933de5ed  vmovaps [rsp+0x90], xmm9
00007e2c933de5f6  vmovaps [rsp+0xA0], xmm10
00007e2c933de5ff  vmovaps [rsp+0xB0], xmm11
00007e2c933de608  vmovaps [rsp+0xC0], xmm12
00007e2c933de611  vmovaps [rsp+0xD0], xmm13
00007e2c933de61a  vmovaps [rsp+0xE0], xmm14
00007e2c933de623  sub rsp, 0x30
00007e2c933de627  movaps [rsp], xmm15
00007e2c933de62c  movaps [rsp+0x10], xmm11
00007e2c933de632  movaps [rsp+0x20], xmm12
00007e2c933de638  lea rdi, [rsp]
00007e2c933de63c  mov esi, 0x00
00007e2c933de641  mov rax, 0x5A263F1C7530
00007e2c933de64b  call rax
00007e2c933de64d  movaps xmm15, [rsp]
00007e2c933de652  add rsp, 0x30
00007e2c933de656  vmovaps xmm0, [rsp]
00007e2c933de65b  vmovaps xmm1, [rsp+0x10]
00007e2c933de661  vmovaps xmm2, [rsp+0x20]
00007e2c933de667  vmovaps xmm3, [rsp+0x30]
00007e2c933de66d  vmovaps xmm4, [rsp+0x40]
00007e2c933de673  vmovaps xmm5, [rsp+0x50]
00007e2c933de679  vmovaps xmm6, [rsp+0x60]
00007e2c933de67f  vmovaps xmm7, [rsp+0x70]
00007e2c933de685  vmovaps xmm8, [rsp+0x80]
00007e2c933de68e  vmovaps xmm9, [rsp+0x90]
00007e2c933de697  vmovaps xmm10, [rsp+0xA0]
00007e2c933de6a0  vmovaps xmm11, [rsp+0xB0]
00007e2c933de6a9  vmovaps xmm12, [rsp+0xC0]
00007e2c933de6b2  vmovaps xmm13, [rsp+0xD0]
00007e2c933de6bb  vmovaps xmm14, [rsp+0xE0]
00007e2c933de6c4  add rsp, 0xF0
00007e2c933de6cb  pop r11
00007e2c933de6cd  pop r10
00007e2c933de6cf  pop r9
00007e2c933de6d1  pop r8
00007e2c933de6d3  pop rsi
00007e2c933de6d4  pop rdi
00007e2c933de6d5  pop rdx
00007e2c933de6d6  pop rcx
00007e2c933de6d7  pop rax
00007e2c933de6d8  add rsp, 0x08
00007e2c933de6dc  jmp 0x00007E2C933D982A
00007e2c933de6e1  sub rsp, 0x08
00007e2c933de6e5  push rax
00007e2c933de6e6  push rcx
00007e2c933de6e7  push rdx
00007e2c933de6e8  push rdi
00007e2c933de6e9  push rsi
00007e2c933de6ea  push r8
00007e2c933de6ec  push r9
00007e2c933de6ee  push r10
00007e2c933de6f0  push r11
00007e2c933de6f2  sub rsp, 0xF0
00007e2c933de6f9  vmovaps [rsp], xmm0
00007e2c933de6fe  vmovaps [rsp+0x10], xmm1
00007e2c933de704  vmovaps [rsp+0x20], xmm2
00007e2c933de70a  vmovaps [rsp+0x30], xmm3
00007e2c933de710  vmovaps [rsp+0x40], xmm4
00007e2c933de716  vmovaps [rsp+0x50], xmm5
00007e2c933de71c  vmovaps [rsp+0x60], xmm6
00007e2c933de722  vmovaps [rsp+0x70], xmm7
00007e2c933de728  vmovaps [rsp+0x80], xmm8
00007e2c933de731  vmovaps [rsp+0x90], xmm9
00007e2c933de73a  vmovaps [rsp+0xA0], xmm10
00007e2c933de743  vmovaps [rsp+0xB0], xmm11
00007e2c933de74c  vmovaps [rsp+0xC0], xmm12
00007e2c933de755  vmovaps [rsp+0xD0], xmm14
00007e2c933de75e  vmovaps [rsp+0xE0], xmm15
00007e2c933de767  sub rsp, 0x30
00007e2c933de76b  movaps [rsp], xmm13
00007e2c933de770  movaps [rsp+0x10], xmm10
00007e2c933de776  movaps [rsp+0x20], xmm14
00007e2c933de77c  lea rdi, [rsp]
00007e2c933de780  mov esi, 0x00
00007e2c933de785  mov rax, 0x5A263F1C7530
00007e2c933de78f  call rax
00007e2c933de791  movaps xmm13, [rsp]
00007e2c933de796  add rsp, 0x30
00007e2c933de79a  vmovaps xmm0, [rsp]
00007e2c933de79f  vmovaps xmm1, [rsp+0x10]
00007e2c933de7a5  vmovaps xmm2, [rsp+0x20]
00007e2c933de7ab  vmovaps xmm3, [rsp+0x30]
00007e2c933de7b1  vmovaps xmm4, [rsp+0x40]
00007e2c933de7b7  vmovaps xmm5, [rsp+0x50]
00007e2c933de7bd  vmovaps xmm6, [rsp+0x60]
00007e2c933de7c3  vmovaps xmm7, [rsp+0x70]
00007e2c933de7c9  vmovaps xmm8, [rsp+0x80]
00007e2c933de7d2  vmovaps xmm9, [rsp+0x90]
00007e2c933de7db  vmovaps xmm10, [rsp+0xA0]
00007e2c933de7e4  vmovaps xmm11, [rsp+0xB0]
00007e2c933de7ed  vmovaps xmm12, [rsp+0xC0]
00007e2c933de7f6  vmovaps xmm14, [rsp+0xD0]
00007e2c933de7ff  vmovaps xmm15, [rsp+0xE0]
00007e2c933de808  add rsp, 0xF0
00007e2c933de80f  pop r11
00007e2c933de811  pop r10
00007e2c933de813  pop r9
00007e2c933de815  pop r8
00007e2c933de817  pop rsi
00007e2c933de818  pop rdi
00007e2c933de819  pop rdx
00007e2c933de81a  pop rcx
00007e2c933de81b  pop rax
00007e2c933de81c  add rsp, 0x08
00007e2c933de820  jmp 0x00007E2C933D984D
00007e2c933de825  sub rsp, 0x08
00007e2c933de829  push rax
00007e2c933de82a  push rcx
00007e2c933de82b  push rdx
00007e2c933de82c  push rdi
00007e2c933de82d  push rsi
00007e2c933de82e  push r8
00007e2c933de830  push r9
00007e2c933de832  push r10
00007e2c933de834  push r11
00007e2c933de836  sub rsp, 0xF0
00007e2c933de83d  vmovaps [rsp], xmm0
00007e2c933de842  vmovaps [rsp+0x10], xmm1
00007e2c933de848  vmovaps [rsp+0x20], xmm2
00007e2c933de84e  vmovaps [rsp+0x30], xmm3
00007e2c933de854  vmovaps [rsp+0x40], xmm4
00007e2c933de85a  vmovaps [rsp+0x50], xmm5
00007e2c933de860  vmovaps [rsp+0x60], xmm6
00007e2c933de866  vmovaps [rsp+0x70], xmm7
00007e2c933de86c  vmovaps [rsp+0x80], xmm8
00007e2c933de875  vmovaps [rsp+0x90], xmm9
00007e2c933de87e  vmovaps [rsp+0xA0], xmm10
00007e2c933de887  vmovaps [rsp+0xB0], xmm11
00007e2c933de890  vmovaps [rsp+0xC0], xmm12
00007e2c933de899  vmovaps [rsp+0xD0], xmm13
00007e2c933de8a2  vmovaps [rsp+0xE0], xmm15
00007e2c933de8ab  sub rsp, 0x30
00007e2c933de8af  movaps [rsp], xmm14
00007e2c933de8b4  movaps [rsp+0x10], xmm1
00007e2c933de8b9  movaps [rsp+0x20], xmm7
00007e2c933de8be  lea rdi, [rsp]
00007e2c933de8c2  mov esi, 0x00
00007e2c933de8c7  mov rax, 0x5A263F1C7530
00007e2c933de8d1  call rax
00007e2c933de8d3  movaps xmm14, [rsp]
00007e2c933de8d8  add rsp, 0x30
00007e2c933de8dc  vmovaps xmm0, [rsp]
00007e2c933de8e1  vmovaps xmm1, [rsp+0x10]
00007e2c933de8e7  vmovaps xmm2, [rsp+0x20]
00007e2c933de8ed  vmovaps xmm3, [rsp+0x30]
00007e2c933de8f3  vmovaps xmm4, [rsp+0x40]
00007e2c933de8f9  vmovaps xmm5, [rsp+0x50]
00007e2c933de8ff  vmovaps xmm6, [rsp+0x60]
00007e2c933de905  vmovaps xmm7, [rsp+0x70]
00007e2c933de90b  vmovaps xmm8, [rsp+0x80]
00007e2c933de914  vmovaps xmm9, [rsp+0x90]
00007e2c933de91d  vmovaps xmm10, [rsp+0xA0]
00007e2c933de926  vmovaps xmm11, [rsp+0xB0]
00007e2c933de92f  vmovaps xmm12, [rsp+0xC0]
00007e2c933de938  vmovaps xmm13, [rsp+0xD0]
00007e2c933de941  vmovaps xmm15, [rsp+0xE0]
00007e2c933de94a  add rsp, 0xF0
00007e2c933de951  pop r11
00007e2c933de953  pop r10
00007e2c933de955  pop r9
00007e2c933de957  pop r8
00007e2c933de959  pop rsi
00007e2c933de95a  pop rdi
00007e2c933de95b  pop rdx
00007e2c933de95c  pop rcx
00007e2c933de95d  pop rax
00007e2c933de95e  add rsp, 0x08
00007e2c933de962  jmp 0x00007E2C933D9870
00007e2c933de967  sub rsp, 0x08
00007e2c933de96b  push rax
00007e2c933de96c  push rcx
00007e2c933de96d  push rdx
00007e2c933de96e  push rdi
00007e2c933de96f  push rsi
00007e2c933de970  push r8
00007e2c933de972  push r9
00007e2c933de974  push r10
00007e2c933de976  push r11
00007e2c933de978  sub rsp, 0xF0
00007e2c933de97f  vmovaps [rsp], xmm0
00007e2c933de984  vmovaps [rsp+0x10], xmm2
00007e2c933de98a  vmovaps [rsp+0x20], xmm3
00007e2c933de990  vmovaps [rsp+0x30], xmm4
00007e2c933de996  vmovaps [rsp+0x40], xmm5
00007e2c933de99c  vmovaps [rsp+0x50], xmm6
00007e2c933de9a2  vmovaps [rsp+0x60], xmm7
00007e2c933de9a8  vmovaps [rsp+0x70], xmm8
00007e2c933de9ae  vmovaps [rsp+0x80], xmm9
00007e2c933de9b7  vmovaps [rsp+0x90], xmm10
00007e2c933de9c0  vmovaps [rsp+0xA0], xmm11
00007e2c933de9c9  vmovaps [rsp+0xB0], xmm12
00007e2c933de9d2  vmovaps [rsp+0xC0], xmm13
00007e2c933de9db  vmovaps [rsp+0xD0], xmm14
00007e2c933de9e4  vmovaps [rsp+0xE0], xmm15
00007e2c933de9ed  sub rsp, 0x30
00007e2c933de9f1  movaps [rsp], xmm1
00007e2c933de9f5  movaps [rsp+0x10], xmm8
00007e2c933de9fb  movaps [rsp+0x20], xmm9
00007e2c933dea01  lea rdi, [rsp]
00007e2c933dea05  mov esi, 0x00
00007e2c933dea0a  mov rax, 0x5A263F1C7530
00007e2c933dea14  call rax
00007e2c933dea16  movaps xmm1, [rsp]
00007e2c933dea1a  add rsp, 0x30
00007e2c933dea1e  vmovaps xmm0, [rsp]
00007e2c933dea23  vmovaps xmm2, [rsp+0x10]
00007e2c933dea29  vmovaps xmm3, [rsp+0x20]
00007e2c933dea2f  vmovaps xmm4, [rsp+0x30]
00007e2c933dea35  vmovaps xmm5, [rsp+0x40]
00007e2c933dea3b  vmovaps xmm6, [rsp+0x50]
00007e2c933dea41  vmovaps xmm7, [rsp+0x60]
00007e2c933dea47  vmovaps xmm8, [rsp+0x70]
00007e2c933dea4d  vmovaps xmm9, [rsp+0x80]
00007e2c933dea56  vmovaps xmm10, [rsp+0x90]
00007e2c933dea5f  vmovaps xmm11, [rsp+0xA0]
00007e2c933dea68  vmovaps xmm12, [rsp+0xB0]
00007e2c933dea71  vmovaps xmm13, [rsp+0xC0]
00007e2c933dea7a  vmovaps xmm14, [rsp+0xD0]
00007e2c933dea83  vmovaps xmm15, [rsp+0xE0]
00007e2c933dea8c  add rsp, 0xF0
00007e2c933dea93  pop r11
00007e2c933dea95  pop r10
00007e2c933dea97  pop r9
00007e2c933dea99  pop r8
00007e2c933dea9b  pop rsi
00007e2c933dea9c  pop rdi
00007e2c933dea9d  pop rdx
00007e2c933dea9e  pop rcx
00007e2c933dea9f  pop rax
00007e2c933deaa0  add rsp, 0x08
00007e2c933deaa4  jmp 0x00007E2C933D9892
00007e2c933deaa9  call 0x00007E2C932B3E40
00007e2c933deaae  jmp 0x00007E2C933D98A0
00007e2c933deab3  call 0x00007E2C9320C380
00007e2c933deab8  jmp 0x00007E2C933D98AA
00007e2c933deabd  call 0x00007E2C9320D600
00007e2c933deac2  jmp 0x00007E2C933D98B4
00007e2c933deac7  call 0x00007E2C931FF540
00007e2c933deacc  jmp 0x00007E2C933D98BE
00007e2c933dead1  int3
00007e2c933dead2  nop [rax+rax*1], ax
00007e2c933deadb  nop [rax+rax*1], eax
00007e2c933deae0  mov eax, [r15+0x48]
00007e2c933deae4  lea r14d, [eax+0x01]
00007e2c933deae9  mov [rsp+0x10], r14d
00007e2c933deaee  mov r14d, r14d
00007e2c933deaf1  mov [r15+0x48], r14
00007e2c933deaf5  xor eax, eax
00007e2c933deaf7  mov r14d, [rsp+0x10]
00007e2c933deafc  cmp r14d, 0x1F4
00007e2c933deb03  cmc
00007e2c933deb04  lahf
00007e2c933deb05  seto al
00007e2c933deb08  mov [r15+0x108], eax
00007e2c933deb0f  mov eax, [r15+0x108]
00007e2c933deb16  sahf
00007e2c933deb17  jnz 0x00007E2C933DEB49
00007e2c933deb19  cmp dword ptr [r15+0x318], 0x00
00007e2c933deb21  jz 0x00007E2C933E4C90
00007e2c933deb27  nop [rax+rax*1], ax
00007e2c933deb30  nop [rax+rax*1], eax
00007e2c933deb38  mov eax, 0x4106DC
00007e2c933deb3d  mov [r15+0x100], rax
00007e2c933deb44  jmp 0x00007E2C931FE110
00007e2c933deb49  cmp dword ptr [r15+0x318], 0x00
00007e2c933deb51  jz 0x00007E2C933DEB80
00007e2c933deb57  nop [rax+rax*1], ax
00007e2c933deb60  nop [rax+rax*1], eax
00007e2c933deb68  mov eax, 0x410500
00007e2c933deb6d  mov [r15+0x100], rax
00007e2c933deb74  jmp 0x00007E2C931FE110
00007e2c933deb79  int3
00007e2c933deb7a  int3
00007e2c933deb7b  nop [rax+rax*1], eax
00007e2c933deb80  mov rax, [r15+0x40]
00007e2c933deb84  movaps xmm1, [r15+0x1D0]
00007e2c933deb8c  vmovaps [rsp+0x10], xmm1
00007e2c933deb92  vmovaps xmm15, [rsp+0x10]
00007e2c933deb98  por xmm1, xmm15
00007e2c933deb9d  movaps xmm14, [r15+0x1A0]
00007e2c933deba5  vmovaps [rsp+0x10], xmm14
00007e2c933debab  vmovaps xmm13, [rsp+0x10]
00007e2c933debb1  por xmm14, xmm13
00007e2c933debb6  lea r14, [rax+0x30]
00007e2c933debba  mov r12, [r13+r14*1]
00007e2c933debbf  lea r14, [rax+0x38]
00007e2c933debc3  mov r11, [r13+r14*1]
00007e2c933debc8  movq xmm13, r12
00007e2c933debcd  movq xmm12, r11
00007e2c933debd2  movq xmm13, xmm13
00007e2c933debd7  vmovaps [rsp+0x10], xmm13
00007e2c933debdd  movq xmm13, xmm13
00007e2c933debe2  movaps [r15+0x130], xmm13
00007e2c933debea  movq xmm12, xmm12
00007e2c933debef  vmovaps [rsp+0x20], xmm12
00007e2c933debf5  movq xmm12, xmm12
00007e2c933debfa  movaps [r15+0x280], xmm12
00007e2c933dec02  movaps xmm13, [r15+0x270]
00007e2c933dec0a  vmovaps [rsp+0x30], xmm13
00007e2c933dec10  vmovaps xmm12, [rsp+0x30]
00007e2c933dec16  por xmm13, xmm12
00007e2c933dec1b  lea r14, [rax+0x20]
00007e2c933dec1f  mov r12, [r13+r14*1]
00007e2c933dec24  lea r14, [rax+0x28]
00007e2c933dec28  mov r11, [r13+r14*1]
00007e2c933dec2d  movq xmm12, r12
00007e2c933dec32  movq xmm11, r11
00007e2c933dec37  movq xmm12, xmm12
00007e2c933dec3c  vmovaps [rsp+0x30], xmm12
00007e2c933dec42  movq xmm12, xmm12
00007e2c933dec47  movaps [r15+0x150], xmm12
00007e2c933dec4f  movq xmm11, xmm11
00007e2c933dec54  vmovaps [rsp+0x40], xmm11
00007e2c933dec5a  movq xmm11, xmm11
00007e2c933dec5f  movaps [r15+0x140], xmm11
00007e2c933dec67  lea r14, [rax+0x10]
00007e2c933dec6b  mov r12, [r13+r14*1]
00007e2c933dec70  lea r14, [rax+0x18]
00007e2c933dec74  mov r11, [r13+r14*1]
00007e2c933dec79  movq xmm12, r12
00007e2c933dec7e  movq xmm11, r11
00007e2c933dec83  movq xmm12, xmm12
00007e2c933dec88  vmovaps [rsp+0x50], xmm12
00007e2c933dec8e  movq xmm12, xmm12
00007e2c933dec93  movaps [r15+0x170], xmm12
00007e2c933dec9b  movq xmm11, xmm11
00007e2c933deca0  vmovaps [rsp+0x60], xmm11
00007e2c933deca6  movq xmm11, xmm11
00007e2c933decab  movaps [r15+0x160], xmm11
00007e2c933decb3  mov r14, [r13+rax*1]
00007e2c933decb8  vmovq xmm12, r14
00007e2c933decbd  vpbroadcastq xmm12, xmm12
00007e2c933decc2  lea r14, [rax+0x08]
00007e2c933decc6  mov rax, [r13+r14*1]
00007e2c933deccb  movq xmm11, rax
00007e2c933decd0  movaps [r15+0x230], xmm11
00007e2c933decd8  mov rax, [r15+0xF8]
00007e2c933decdf  lea r14, [rax+0x50]
00007e2c933dece3  movups xmm11, [r13+r14*1]
00007e2c933dece9  lea r14, [rax+0x60]
00007e2c933deced  movups xmm10, [r13+r14*1]
00007e2c933decf3  lea r14, [rax+0x30]
00007e2c933decf7  movups xmm9, [r13+r14*1]
00007e2c933decfd  mov r14, [r15+0x50]
00007e2c933ded01  mov [r15+0x60], r14
00007e2c933ded05  mov qword ptr [r15+0x58], 0x40
00007e2c933ded0d  movaps xmm8, xmm12
00007e2c933ded11  mulpd xmm8, xmm15
00007e2c933ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007e2c933ded1c  ptest xmm7, xmm7
00007e2c933ded21  jnz 0x00007E2C933DFB4A
00007e2c933ded27  movq xmm15, qword ptr [r15+0x230]
00007e2c933ded30  vmovaps [rsp+0x70], xmm15
00007e2c933ded36  vpermilpd xmm15, xmm15, 0x00
00007e2c933ded3c  movaps xmm7, xmm9
00007e2c933ded40  mulpd xmm7, xmm15
00007e2c933ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007e2c933ded4a  ptest xmm6, xmm6
00007e2c933ded4f  jnz 0x00007E2C933DFC8E
00007e2c933ded55  vxorps xmm15, xmm15, xmm15
00007e2c933ded5a  vpbroadcastq xmm15, xmm15
00007e2c933ded5f  movaps xmm9, xmm12
00007e2c933ded63  mulpd xmm9, xmm10
00007e2c933ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007e2c933ded6e  ptest xmm6, xmm6
00007e2c933ded73  jnz 0x00007E2C933DFDD0
00007e2c933ded79  movaps xmm10, xmm12
00007e2c933ded7d  mulpd xmm10, xmm11
00007e2c933ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007e2c933ded88  ptest xmm6, xmm6
00007e2c933ded8d  jnz 0x00007E2C933DFF14
00007e2c933ded93  movaps xmm11, [r15+0x1F0]
00007e2c933ded9b  movaps xmm6, xmm12
00007e2c933ded9f  mulpd xmm6, xmm11
00007e2c933deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007e2c933deda9  ptest xmm5, xmm5
00007e2c933dedae  jnz 0x00007E2C933E0058
00007e2c933dedb4  movaps xmm12, [r15+0x2A0]
00007e2c933dedbc  vmovaps [rsp+0x80], xmm12
00007e2c933dedc5  vmovaps xmm11, [rsp+0x80]
00007e2c933dedce  por xmm12, xmm11
00007e2c933dedd3  movaps xmm11, [r15+0x250]
00007e2c933deddb  vmovaps [rsp+0x80], xmm11
00007e2c933dede4  vmovaps xmm5, [rsp+0x80]
00007e2c933deded  por xmm11, xmm5
00007e2c933dedf2  vmovaps xmm4, [rsp+0x70]
00007e2c933dedf8  vpermilpd xmm4, xmm4, 0x00
00007e2c933dedfe  movaps xmm3, xmm5
00007e2c933dee01  mulpd xmm3, xmm4
00007e2c933dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007e2c933dee0a  ptest xmm2, xmm2
00007e2c933dee0f  jnz 0x00007E2C933E019A
00007e2c933dee15  mov [rsp+0x80], rax
00007e2c933dee1d  xor eax, eax
00007e2c933dee1f  mov r12d, 0x40
00007e2c933dee25  mov r11d, 0x200
00007e2c933dee2b  cmp r12, r11
00007e2c933dee2e  cmc
00007e2c933dee2f  lahf
00007e2c933dee30  seto al
00007e2c933dee33  mov [r15+0x108], eax
00007e2c933dee3a  movaps xmm5, xmm8
00007e2c933dee3e  addpd xmm5, xmm15
00007e2c933dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007e2c933dee48  ptest xmm4, xmm4
00007e2c933dee4d  jnz 0x00007E2C933E02DA
00007e2c933dee53  movaps xmm8, [r15+0x1B0]
00007e2c933dee5b  movaps xmm4, xmm9
00007e2c933dee5f  addpd xmm4, xmm8
00007e2c933dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007e2c933dee69  ptest xmm2, xmm2
00007e2c933dee6e  jnz 0x00007E2C933E041C
00007e2c933dee74  movaps xmm9, xmm10
00007e2c933dee78  addpd xmm9, xmm8
00007e2c933dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007e2c933dee83  ptest xmm2, xmm2
00007e2c933dee88  jnz 0x00007E2C933E055E
00007e2c933dee8e  movaps xmm10, [r15+0x2F0]
00007e2c933dee96  vmovaps [rsp+0x90], xmm10
00007e2c933dee9f  vmovaps xmm8, [rsp+0x90]
00007e2c933deea8  por xmm10, xmm8
00007e2c933deead  movaps xmm8, [r15+0x2E0]
00007e2c933deeb5  vmovaps [rsp+0x90], xmm8
00007e2c933deebe  vmovaps xmm2, [rsp+0x90]
00007e2c933deec7  por xmm8, xmm2
00007e2c933deecc  movaps xmm2, [r15+0x2D0]
00007e2c933deed4  vmovaps [rsp+0x90], xmm2
00007e2c933deedd  vmovaps [rsp+0xA0], xmm1
00007e2c933deee6  vmovaps xmm1, [rsp+0x90]
00007e2c933deeef  por xmm2, xmm1
00007e2c933deef3  movaps xmm1, [r15+0x200]
00007e2c933deefb  vmovaps [rsp+0x90], xmm1
00007e2c933def04  vmovaps [rsp+0xB0], xmm15
00007e2c933def0d  vmovaps xmm15, [rsp+0x90]
00007e2c933def16  por xmm1, xmm15
00007e2c933def1b  movaps xmm15, [r15+0x1C0]
00007e2c933def23  vmovaps [rsp+0x90], xmm15
00007e2c933def2c  vmovaps [rsp+0xC0], xmm1
00007e2c933def35  vmovaps xmm1, [rsp+0x90]
00007e2c933def3e  por xmm15, xmm1
00007e2c933def43  movaps xmm1, [r15+0x190]
00007e2c933def4b  vmovaps [rsp+0x90], xmm1
00007e2c933def54  vmovaps [rsp+0xD0], xmm15
00007e2c933def5d  vmovaps xmm15, [rsp+0x90]
00007e2c933def66  por xmm1, xmm15
00007e2c933def6b  movaps xmm15, [r15+0x300]
00007e2c933def73  vmovaps [rsp+0x90], xmm15
00007e2c933def7c  vmovaps [rsp+0xE0], xmm1
00007e2c933def85  vmovaps xmm1, [rsp+0x90]
00007e2c933def8e  por xmm15, xmm1
00007e2c933def93  mov rax, [rsp+0x80]
00007e2c933def9b  lea r12, [rax+0xA0]
00007e2c933defa2  movups xmm1, [r13+r12*1]
00007e2c933defa8  lea r12, [rax+0xB0]
00007e2c933defaf  vmovaps [rsp+0x80], xmm1
00007e2c933defb8  movups xmm1, [r13+r12*1]
00007e2c933defbe  vmovaps [rsp+0x90], xmm1
00007e2c933defc7  vmovaps [rsp+0xF0], xmm15
00007e2c933defd0  vmovaps xmm15, [rsp+0xB0]
00007e2c933defd9  vmovaps [rsp+0xB0], xmm14
00007e2c933defe2  movaps xmm1, xmm6
00007e2c933defe5  addpd xmm1, xmm15
00007e2c933defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007e2c933defef  ptest xmm14, xmm14
00007e2c933deff5  jnz 0x00007E2C933E06B6
00007e2c933deffb  lea r12, [rax+0xF0]
00007e2c933df002  movups xmm15, [r13+r12*1]
00007e2c933df008  movaps xmm14, xmm4
00007e2c933df00c  addpd xmm14, xmm3
00007e2c933df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007e2c933df017  ptest xmm6, xmm6
00007e2c933df01c  jnz 0x00007E2C933E0801
00007e2c933df022  movaps xmm6, xmm9
00007e2c933df026  addpd xmm6, xmm7
00007e2c933df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007e2c933df02f  ptest xmm4, xmm4
00007e2c933df034  jnz 0x00007E2C933E0943
00007e2c933df03a  vmovaps xmm9, [rsp+0x70]
00007e2c933df040  vpermilpd xmm9, xmm9, 0x00
00007e2c933df046  vmovaps xmm4, [rsp+0x90]
00007e2c933df04f  movaps xmm7, xmm4
00007e2c933df052  mulpd xmm7, xmm9
00007e2c933df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007e2c933df05c  ptest xmm3, xmm3
00007e2c933df061  jnz 0x00007E2C933E0A84
00007e2c933df067  vmovaps xmm9, [rsp+0x50]
00007e2c933df06d  vpermilpd xmm9, xmm9, 0x00
00007e2c933df073  movaps xmm4, xmm15
00007e2c933df077  mulpd xmm4, xmm9
00007e2c933df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007e2c933df081  ptest xmm3, xmm3
00007e2c933df086  jnz 0x00007E2C933E0BC5
00007e2c933df08c  lea r12, [rax+0xE0]
00007e2c933df093  movups xmm15, [r13+r12*1]
00007e2c933df099  vmovaps xmm9, [rsp+0x70]
00007e2c933df09f  vpermilpd xmm9, xmm9, 0x00
00007e2c933df0a5  vmovaps [rsp+0x70], xmm1
00007e2c933df0ab  vmovaps xmm1, [rsp+0x80]
00007e2c933df0b4  vmovaps [rsp+0x80], xmm15
00007e2c933df0bd  movaps xmm3, xmm1
00007e2c933df0c0  mulpd xmm3, xmm9
00007e2c933df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007e2c933df0ca  ptest xmm15, xmm15
00007e2c933df0d0  jnz 0x00007E2C933E0D11
00007e2c933df0d6  vmovaps xmm1, [rsp+0xF0]
00007e2c933df0df  vmovaps xmm15, [rsp+0xF0]
00007e2c933df0e8  por xmm1, xmm15
00007e2c933df0ed  movaps [r15+0x300], xmm1
00007e2c933df0f5  vmovaps xmm15, [rsp+0xE0]
00007e2c933df0fe  vmovaps xmm9, [rsp+0xE0]
00007e2c933df107  por xmm15, xmm9
00007e2c933df10c  movaps [r15+0x190], xmm15
00007e2c933df114  vmovaps xmm9, [rsp+0x50]
00007e2c933df11a  vpermilpd xmm9, xmm9, 0x00
00007e2c933df120  vmovaps [rsp+0x90], xmm1
00007e2c933df129  vmovaps [rsp+0xE0], xmm15
00007e2c933df132  vmovaps xmm15, [rsp+0x80]
00007e2c933df13b  vmovaps [rsp+0x80], xmm14
00007e2c933df144  movaps xmm1, xmm15
00007e2c933df148  mulpd xmm1, xmm9
00007e2c933df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007e2c933df152  ptest xmm14, xmm14
00007e2c933df158  jnz 0x00007E2C933E0E52
00007e2c933df15e  lea r12, [rax+0x90]
00007e2c933df165  movups xmm15, [r13+r12*1]
00007e2c933df16b  vmovaps xmm14, [rsp+0xD0]
00007e2c933df174  vmovaps xmm9, [rsp+0xD0]
00007e2c933df17d  por xmm14, xmm9
00007e2c933df182  movaps [r15+0x1C0], xmm14
00007e2c933df18a  vmovaps xmm9, [rsp+0xC0]
00007e2c933df193  vmovaps [rsp+0xD0], xmm1
00007e2c933df19c  vmovaps xmm1, [rsp+0xC0]
00007e2c933df1a5  por xmm9, xmm1
00007e2c933df1aa  movaps [r15+0x200], xmm9
00007e2c933df1b2  vmovaps [rsp+0xC0], xmm2
00007e2c933df1bb  vmovaps xmm1, [rsp+0xC0]
00007e2c933df1c4  por xmm2, xmm1
00007e2c933df1c8  movaps [r15+0x2D0], xmm2
00007e2c933df1d0  vmovaps [rsp+0xC0], xmm8
00007e2c933df1d9  vmovaps xmm1, [rsp+0xC0]
00007e2c933df1e2  por xmm8, xmm1
00007e2c933df1e7  movaps [r15+0x2E0], xmm8
00007e2c933df1ef  vmovaps [rsp+0xC0], xmm15
00007e2c933df1f8  movaps xmm1, xmm5
00007e2c933df1fb  addpd xmm1, xmm7
00007e2c933df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007e2c933df204  ptest xmm15, xmm15
00007e2c933df20a  jnz 0x00007E2C933E0F9E
00007e2c933df210  vmovaps xmm15, [rsp+0x50]
00007e2c933df216  vpermilpd xmm15, xmm15, 0x00
00007e2c933df21c  vmovaps xmm5, [rsp+0xC0]
00007e2c933df225  vmovaps [rsp+0xC0], xmm1
00007e2c933df22e  movaps xmm7, xmm5
00007e2c933df231  mulpd xmm7, xmm15
00007e2c933df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007e2c933df23b  ptest xmm1, xmm1
00007e2c933df240  jnz 0x00007E2C933E10DE
00007e2c933df246  lea r12, [rax+0x80]
00007e2c933df24d  movups xmm1, [r13+r12*1]
00007e2c933df253  vmovaps xmm5, [rsp+0x70]
00007e2c933df259  vmovaps [rsp+0x70], xmm1
00007e2c933df25f  movaps xmm15, xmm5
00007e2c933df263  addpd xmm15, xmm3
00007e2c933df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007e2c933df26e  ptest xmm1, xmm1
00007e2c933df273  jnz 0x00007E2C933E1229
00007e2c933df279  vmovaps xmm5, [rsp+0x80]
00007e2c933df282  movaps xmm1, xmm5
00007e2c933df285  addpd xmm1, xmm4
00007e2c933df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007e2c933df28e  ptest xmm3, xmm3
00007e2c933df293  jnz 0x00007E2C933E136B
00007e2c933df299  vmovaps [rsp+0x80], xmm10
00007e2c933df2a2  vmovaps xmm5, [rsp+0x80]
00007e2c933df2ab  por xmm10, xmm5
00007e2c933df2b0  movaps [r15+0x2F0], xmm10
00007e2c933df2b8  vmovaps xmm5, [rsp+0x50]
00007e2c933df2be  vpermilpd xmm5, xmm5, 0x00
00007e2c933df2c4  vmovaps xmm3, [rsp+0x70]
00007e2c933df2ca  vmovaps [rsp+0x50], xmm1
00007e2c933df2d0  movaps xmm4, xmm3
00007e2c933df2d3  mulpd xmm4, xmm5
00007e2c933df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007e2c933df2dc  ptest xmm1, xmm1
00007e2c933df2e1  jnz 0x00007E2C933E14AB
00007e2c933df2e7  lea r12, [rax+0xD0]
00007e2c933df2ee  movups xmm1, [r13+r12*1]
00007e2c933df2f4  vmovaps xmm3, [rsp+0xD0]
00007e2c933df2fd  vmovaps [rsp+0x70], xmm1
00007e2c933df303  movaps xmm5, xmm6
00007e2c933df306  addpd xmm5, xmm3
00007e2c933df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007e2c933df30f  ptest xmm1, xmm1
00007e2c933df314  jnz 0x00007E2C933E15F5
00007e2c933df31a  vmovaps xmm1, [rsp+0x60]
00007e2c933df320  vpermilpd xmm1, xmm1, 0x00
00007e2c933df326  movaps xmm6, xmm9
00007e2c933df32a  mulpd xmm6, xmm1
00007e2c933df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007e2c933df333  ptest xmm3, xmm3
00007e2c933df338  jnz 0x00007E2C933E1735
00007e2c933df33e  movaps [r15+0x260], xmm6
00007e2c933df346  vxorps xmm1, xmm1, xmm1
00007e2c933df34a  vpbroadcastq xmm1, xmm1
00007e2c933df34f  movaps [r15+0x1B0], xmm1
00007e2c933df357  vmovaps xmm1, [rsp+0x60]
00007e2c933df35d  vpermilpd xmm1, xmm1, 0x00
00007e2c933df363  vmovaps xmm3, [rsp+0x70]
00007e2c933df369  vmovaps [rsp+0x70], xmm15
00007e2c933df36f  movaps xmm9, xmm3
00007e2c933df373  mulpd xmm9, xmm1
00007e2c933df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007e2c933df37e  ptest xmm15, xmm15
00007e2c933df384  jnz 0x00007E2C933E1876
00007e2c933df38a  lea r12, [rax+0xC0]
00007e2c933df391  movups xmm1, [r13+r12*1]
00007e2c933df397  vmovaps xmm3, [rsp+0xC0]
00007e2c933df3a0  vmovaps [rsp+0x80], xmm1
00007e2c933df3a9  movaps xmm15, xmm3
00007e2c933df3ad  addpd xmm15, xmm7
00007e2c933df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007e2c933df3b8  ptest xmm1, xmm1
00007e2c933df3bd  jnz 0x00007E2C933E19C2
00007e2c933df3c3  vmovaps [rsp+0xC0], xmm13
00007e2c933df3cc  vmovaps xmm1, [rsp+0xC0]
00007e2c933df3d5  por xmm13, xmm1
00007e2c933df3da  movaps [r15+0x270], xmm13
00007e2c933df3e2  vmovaps xmm1, [rsp+0xB0]
00007e2c933df3eb  vmovaps xmm7, [rsp+0xB0]
00007e2c933df3f4  por xmm1, xmm7
00007e2c933df3f8  movaps [r15+0x1A0], xmm1
00007e2c933df400  vmovaps xmm1, [rsp+0x60]
00007e2c933df406  vpermilpd xmm1, xmm1, 0x00
00007e2c933df40c  vmovaps [rsp+0xB0], xmm1
00007e2c933df415  vmovaps xmm1, [rsp+0x80]
00007e2c933df41e  vmovaps [rsp+0x80], xmm15
00007e2c933df427  vmovaps xmm15, [rsp+0xB0]
00007e2c933df430  vmovaps [rsp+0xB0], xmm14
00007e2c933df439  movaps xmm3, xmm1
00007e2c933df43c  mulpd xmm3, xmm15
00007e2c933df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007e2c933df446  ptest xmm14, xmm14
00007e2c933df44c  jnz 0x00007E2C933E1B04
00007e2c933df452  lea r12, [rax+0x20]
00007e2c933df456  movups xmm1, [r13+r12*1]
00007e2c933df45c  movaps [r15+0x110], xmm1
00007e2c933df464  vmovaps xmm14, [rsp+0x70]
00007e2c933df46a  vmovaps [rsp+0x70], xmm1
00007e2c933df470  movaps xmm15, xmm14
00007e2c933df474  addpd xmm15, xmm4
00007e2c933df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007e2c933df47f  ptest xmm1, xmm1
00007e2c933df484  jnz 0x00007E2C933E1C4F
00007e2c933df48a  vmovaps xmm1, [rsp+0x60]
00007e2c933df490  vpermilpd xmm1, xmm1, 0x00
00007e2c933df496  movaps xmm14, xmm2
00007e2c933df49a  mulpd xmm14, xmm1
00007e2c933df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007e2c933df4a5  ptest xmm4, xmm4
00007e2c933df4aa  jnz 0x00007E2C933E1D92
00007e2c933df4b0  vmovaps xmm4, [rsp+0x50]
00007e2c933df4b6  movaps xmm1, xmm4
00007e2c933df4b9  addpd xmm1, xmm9
00007e2c933df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007e2c933df4c3  ptest xmm2, xmm2
00007e2c933df4c8  jnz 0x00007E2C933E1ED4
00007e2c933df4ce  vmovaps xmm9, [rsp+0x30]
00007e2c933df4d4  vpermilpd xmm9, xmm9, 0x00
00007e2c933df4da  vmovaps xmm2, [rsp+0x70]
00007e2c933df4e0  vmovaps [rsp+0x50], xmm1
00007e2c933df4e6  movaps xmm4, xmm2
00007e2c933df4e9  mulpd xmm4, xmm9
00007e2c933df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007e2c933df4f3  ptest xmm1, xmm1
00007e2c933df4f8  jnz 0x00007E2C933E2015
00007e2c933df4fe  vmovaps xmm1, [rsp+0x30]
00007e2c933df504  vpermilpd xmm1, xmm1, 0x00
00007e2c933df50a  vmovaps xmm2, [rsp+0x90]
00007e2c933df513  vmovaps [rsp+0x60], xmm15
00007e2c933df519  movaps xmm9, xmm2
00007e2c933df51d  mulpd xmm9, xmm1
00007e2c933df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007e2c933df528  ptest xmm15, xmm15
00007e2c933df52e  jnz 0x00007E2C933E2156
00007e2c933df534  vmovaps xmm15, [rsp+0x80]
00007e2c933df53d  movaps xmm1, xmm15
00007e2c933df541  addpd xmm1, xmm6
00007e2c933df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007e2c933df54a  ptest xmm2, xmm2
00007e2c933df54f  jnz 0x00007E2C933E2298
00007e2c933df555  movaps xmm15, xmm5
00007e2c933df559  addpd xmm15, xmm3
00007e2c933df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007e2c933df564  ptest xmm6, xmm6
00007e2c933df569  jnz 0x00007E2C933E23D9
00007e2c933df56f  vmovaps xmm6, [rsp+0x30]
00007e2c933df575  vpermilpd xmm6, xmm6, 0x00
00007e2c933df57b  movaps xmm5, xmm8
00007e2c933df57f  mulpd xmm5, xmm6
00007e2c933df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007e2c933df588  ptest xmm3, xmm3
00007e2c933df58d  jnz 0x00007E2C933E251B
00007e2c933df593  vmovaps xmm8, [rsp+0x30]
00007e2c933df599  vpermilpd xmm8, xmm8, 0x00
00007e2c933df59f  movaps xmm6, xmm10
00007e2c933df5a3  mulpd xmm6, xmm8
00007e2c933df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007e2c933df5ad  ptest xmm3, xmm3
00007e2c933df5b2  jnz 0x00007E2C933E265C
00007e2c933df5b8  vmovaps xmm8, [rsp+0x60]
00007e2c933df5be  movaps xmm10, xmm8
00007e2c933df5c2  addpd xmm10, xmm14
00007e2c933df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007e2c933df5cd  ptest xmm3, xmm3
00007e2c933df5d2  jnz 0x00007E2C933E279E
00007e2c933df5d8  vmovaps xmm8, [rsp+0x50]
00007e2c933df5de  movaps xmm14, xmm8
00007e2c933df5e2  addpd xmm14, xmm4
00007e2c933df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007e2c933df5ed  ptest xmm3, xmm3
00007e2c933df5f2  jnz 0x00007E2C933E28E2
00007e2c933df5f8  vmovaps xmm8, [rsp+0x40]
00007e2c933df5fe  vpermilpd xmm8, xmm8, 0x00
00007e2c933df604  movaps xmm4, xmm13
00007e2c933df608  mulpd xmm4, xmm8
00007e2c933df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007e2c933df612  ptest xmm3, xmm3
00007e2c933df617  jnz 0x00007E2C933E2A25
00007e2c933df61d  movaps xmm13, xmm15
00007e2c933df621  addpd xmm13, xmm9
00007e2c933df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007e2c933df62c  ptest xmm8, xmm8
00007e2c933df632  jnz 0x00007E2C933E2B67
00007e2c933df638  movaps xmm15, xmm1
00007e2c933df63c  addpd xmm15, xmm5
00007e2c933df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007e2c933df647  ptest xmm9, xmm9
00007e2c933df64d  jnz 0x00007E2C933E2CAB
00007e2c933df653  vmovaps [rsp+0x30], xmm11
00007e2c933df659  vmovaps xmm1, [rsp+0x30]
00007e2c933df65f  por xmm11, xmm1
00007e2c933df664  movaps [r15+0x250], xmm11
00007e2c933df66c  vmovaps [rsp+0x30], xmm12
00007e2c933df672  vmovaps xmm1, [rsp+0x30]
00007e2c933df678  por xmm12, xmm1
00007e2c933df67d  movaps [r15+0x2A0], xmm12
00007e2c933df685  vmovaps xmm1, [rsp+0xA0]
00007e2c933df68e  vmovaps xmm11, [rsp+0xA0]
00007e2c933df697  por xmm1, xmm11
00007e2c933df69c  movaps [r15+0x1D0], xmm1
00007e2c933df6a4  lea r12, [rax+0x40]
00007e2c933df6a8  movups xmm1, [r13+r12*1]
00007e2c933df6ae  movaps [r15+0x2C0], xmm1
00007e2c933df6b6  vmovaps xmm11, [rsp+0x40]
00007e2c933df6bc  vpermilpd xmm11, xmm11, 0x00
00007e2c933df6c2  vmovaps xmm8, [rsp+0xE0]
00007e2c933df6cb  movaps xmm9, xmm8
00007e2c933df6cf  mulpd xmm9, xmm11
00007e2c933df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007e2c933df6da  ptest xmm5, xmm5
00007e2c933df6df  jnz 0x00007E2C933E2DF7
00007e2c933df6e5  movaps xmm11, xmm10
00007e2c933df6e9  addpd xmm11, xmm6
00007e2c933df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007e2c933df6f4  ptest xmm8, xmm8
00007e2c933df6fa  jnz 0x00007E2C933E2F3B
00007e2c933df700  movaps xmm10, xmm14
00007e2c933df704  addpd xmm10, xmm4
00007e2c933df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007e2c933df70f  ptest xmm8, xmm8
00007e2c933df715  jnz 0x00007E2C933E307E
00007e2c933df71b  vmovaps xmm14, [rsp+0x40]
00007e2c933df721  vpermilpd xmm14, xmm14, 0x00
00007e2c933df727  movaps xmm8, xmm1
00007e2c933df72b  mulpd xmm8, xmm14
00007e2c933df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007e2c933df736  ptest xmm6, xmm6
00007e2c933df73b  jnz 0x00007E2C933E31C1
00007e2c933df741  movaps xmm1, [r15+0x2B0]
00007e2c933df749  vmovaps xmm14, [rsp+0x40]
00007e2c933df74f  vpermilpd xmm14, xmm14, 0x00
00007e2c933df755  movaps xmm6, xmm1
00007e2c933df758  mulpd xmm6, xmm14
00007e2c933df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007e2c933df762  ptest xmm5, xmm5
00007e2c933df767  jnz 0x00007E2C933E3304
00007e2c933df76d  vmovaps xmm1, [rsp+0x10]
00007e2c933df773  vpermilpd xmm1, xmm1, 0x00
00007e2c933df779  movaps xmm14, xmm12
00007e2c933df77d  mulpd xmm14, xmm1
00007e2c933df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007e2c933df788  ptest xmm5, xmm5
00007e2c933df78d  jnz 0x00007E2C933E3445
00007e2c933df793  movaps xmm1, xmm13
00007e2c933df797  addpd xmm1, xmm9
00007e2c933df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007e2c933df7a1  ptest xmm12, xmm12
00007e2c933df7a7  jnz 0x00007E2C933E3588
00007e2c933df7ad  vmovaps xmm13, [rsp+0x10]
00007e2c933df7b3  vpermilpd xmm13, xmm13, 0x00
00007e2c933df7b9  movaps xmm12, xmm7
00007e2c933df7bd  mulpd xmm12, xmm13
00007e2c933df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007e2c933df7c8  ptest xmm9, xmm9
00007e2c933df7ce  jnz 0x00007E2C933E36CA
00007e2c933df7d4  movaps xmm13, xmm15
00007e2c933df7d8  addpd xmm13, xmm8
00007e2c933df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007e2c933df7e3  ptest xmm9, xmm9
00007e2c933df7e9  jnz 0x00007E2C933E380D
00007e2c933df7ef  movaps xmm15, [r15+0x290]
00007e2c933df7f7  vmovaps xmm9, [rsp+0x10]
00007e2c933df7fd  vpermilpd xmm9, xmm9, 0x00
00007e2c933df803  movaps xmm8, xmm15
00007e2c933df807  mulpd xmm8, xmm9
00007e2c933df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007e2c933df812  ptest xmm7, xmm7
00007e2c933df817  jnz 0x00007E2C933E3951
00007e2c933df81d  movaps xmm15, xmm11
00007e2c933df821  addpd xmm15, xmm6
00007e2c933df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007e2c933df82c  ptest xmm9, xmm9
00007e2c933df832  jnz 0x00007E2C933E3A95
00007e2c933df838  movaps xmm11, [r15+0x1E0]
00007e2c933df840  vmovaps xmm9, [rsp+0x10]
00007e2c933df846  vpermilpd xmm9, xmm9, 0x00
00007e2c933df84c  movaps xmm7, xmm11
00007e2c933df850  mulpd xmm7, xmm9
00007e2c933df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007e2c933df85a  ptest xmm6, xmm6
00007e2c933df85f  jnz 0x00007E2C933E3BD8
00007e2c933df865  movaps xmm11, xmm10
00007e2c933df869  addpd xmm11, xmm14
00007e2c933df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007e2c933df874  ptest xmm9, xmm9
00007e2c933df87a  jnz 0x00007E2C933E3D1A
00007e2c933df880  lea r12, [rax+0x70]
00007e2c933df884  movups xmm14, [r13+r12*1]
00007e2c933df88a  movaps [r15+0x240], xmm14
00007e2c933df892  movaps xmm10, xmm1
00007e2c933df896  addpd xmm10, xmm12
00007e2c933df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007e2c933df8a1  ptest xmm9, xmm9
00007e2c933df8a7  jnz 0x00007E2C933E3E68
00007e2c933df8ad  movaps [r15+0x170], xmm10
00007e2c933df8b5  vmovaps xmm1, [rsp+0x20]
00007e2c933df8bb  vpermilpd xmm1, xmm1, 0x00
00007e2c933df8c1  movaps xmm12, xmm14
00007e2c933df8c5  mulpd xmm12, xmm1
00007e2c933df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007e2c933df8d0  ptest xmm9, xmm9
00007e2c933df8d6  jnz 0x00007E2C933E3FAB
00007e2c933df8dc  vmovaps xmm1, [rsp+0x20]
00007e2c933df8e2  vpermilpd xmm1, xmm1, 0x00
00007e2c933df8e8  vmovaps xmm9, [rsp+0xB0]
00007e2c933df8f1  movaps xmm14, xmm9
00007e2c933df8f5  mulpd xmm14, xmm1
00007e2c933df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007e2c933df900  ptest xmm6, xmm6
00007e2c933df905  jnz 0x00007E2C933E40EE
00007e2c933df90b  movaps [r15+0x180], xmm14
00007e2c933df913  movaps xmm1, xmm13
00007e2c933df917  addpd xmm1, xmm8
00007e2c933df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007e2c933df921  ptest xmm9, xmm9
00007e2c933df927  jnz 0x00007E2C933E4231
00007e2c933df92d  movaps [r15+0x210], xmm1
00007e2c933df935  movups xmm13, [r13+rax*1]
00007e2c933df93b  lea r12, [rax+0x10]
00007e2c933df93f  movups xmm9, [r13+r12*1]
00007e2c933df945  movaps [r15+0x230], xmm9
00007e2c933df94d  movaps xmm8, xmm15
00007e2c933df951  addpd xmm8, xmm7
00007e2c933df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007e2c933df95c  ptest xmm6, xmm6
00007e2c933df961  jnz 0x00007E2C933E4387
00007e2c933df967  movaps [r15+0x130], xmm8
00007e2c933df96f  vmovaps xmm15, [rsp+0x20]
00007e2c933df975  vpermilpd xmm15, xmm15, 0x00
00007e2c933df97b  movaps xmm7, xmm9
00007e2c933df97f  mulpd xmm7, xmm15
00007e2c933df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007e2c933df989  ptest xmm6, xmm6
00007e2c933df98e  jnz 0x00007E2C933E44CA
00007e2c933df994  movaps [r15+0x220], xmm7
00007e2c933df99c  vmovaps xmm15, [rsp+0x20]
00007e2c933df9a2  vpermilpd xmm15, xmm15, 0x00
00007e2c933df9a8  movaps xmm9, xmm13
00007e2c933df9ac  mulpd xmm9, xmm15
00007e2c933df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007e2c933df9b7  ptest xmm6, xmm6
00007e2c933df9bc  jnz 0x00007E2C933E460C
00007e2c933df9c2  movaps xmm15, xmm11
00007e2c933df9c6  addpd xmm15, xmm12
00007e2c933df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007e2c933df9d1  ptest xmm13, xmm13
00007e2c933df9d7  jnz 0x00007E2C933E4750
00007e2c933df9dd  movaps [r15+0x140], xmm15
00007e2c933df9e5  movaps xmm13, xmm10
00007e2c933df9e9  addpd xmm13, xmm14
00007e2c933df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007e2c933df9f4  ptest xmm12, xmm12
00007e2c933df9fa  jnz 0x00007E2C933E4894
00007e2c933dfa00  movaps [r15+0x150], xmm13
00007e2c933dfa08  movaps xmm14, xmm1
00007e2c933dfa0c  addpd xmm14, xmm7
00007e2c933dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007e2c933dfa17  ptest xmm12, xmm12
00007e2c933dfa1d  jnz 0x00007E2C933E49D8
00007e2c933dfa23  movaps [r15+0x160], xmm14
00007e2c933dfa2b  movaps xmm1, xmm8
00007e2c933dfa2f  addpd xmm1, xmm9
00007e2c933dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007e2c933dfa39  ptest xmm12, xmm12
00007e2c933dfa3f  jnz 0x00007E2C933E4B1A
00007e2c933dfa45  movaps [r15+0x120], xmm1
00007e2c933dfa4d  movups [r13+r14*1], xmm15
00007e2c933dfa53  lea rax, [r14+0x10]
00007e2c933dfa57  movups [r13+rax*1], xmm13
00007e2c933dfa5d  lea rax, [r14+0x20]
00007e2c933dfa61  movups [r13+rax*1], xmm14
00007e2c933dfa67  lea rax, [r14+0x30]
00007e2c933dfa6b  movups [r13+rax*1], xmm1
00007e2c933dfa71  mov eax, [r15+0x108]
00007e2c933dfa78  sahf
00007e2c933dfa79  jnz 0x00007E2C933DFAAB
00007e2c933dfa7b  cmp dword ptr [r15+0x318], 0x00
00007e2c933dfa83  jz 0x00007E2C933DEAE0
00007e2c933dfa89  nop [rax+rax*1], ax
00007e2c933dfa92  nop [rax+rax*1], eax
00007e2c933dfa9a  mov eax, 0x4106D0
00007e2c933dfa9f  mov [r15+0x100], rax
00007e2c933dfaa6  jmp 0x00007E2C931FE110
00007e2c933dfaab  cmp dword ptr [r15+0x318], 0x00
00007e2c933dfab3  jz 0x00007E2C933D89C0
00007e2c933dfab9  nop [rax+rax*1], ax
00007e2c933dfac2  nop [rax+rax*1], eax
00007e2c933dfaca  mov eax, 0x410504
00007e2c933dfacf  mov [r15+0x100], rax
00007e2c933dfad6  jmp 0x00007E2C931FE110
00007e2c933dfadb  int3
00007e2c933dfadc  call 0x00007E2C932E27E0
00007e2c933dfae1  jmp 0x00007E2C933DEBBF
00007e2c933dfae6  call 0x00007E2C932E1570
00007e2c933dfaeb  jmp 0x00007E2C933DEBC8
00007e2c933dfaf0  call 0x00007E2C932E27E0
00007e2c933dfaf5  jmp 0x00007E2C933DEC24
00007e2c933dfafa  call 0x00007E2C932E1570
00007e2c933dfaff  jmp 0x00007E2C933DEC2D
00007e2c933dfb04  call 0x00007E2C932E27E0
00007e2c933dfb09  jmp 0x00007E2C933DEC70
00007e2c933dfb0e  call 0x00007E2C932E1570
00007e2c933dfb13  jmp 0x00007E2C933DEC79
00007e2c933dfb18  call 0x00007E2C9320DC20
00007e2c933dfb1d  jmp 0x00007E2C933DECB8
00007e2c933dfb22  call 0x00007E2C932D59C0
00007e2c933dfb27  jmp 0x00007E2C933DECCB
00007e2c933dfb2c  call 0x00007E2C932E0E30
00007e2c933dfb31  jmp 0x00007E2C933DECE9
00007e2c933dfb36  call 0x00007E2C932DFBC0
00007e2c933dfb3b  jmp 0x00007E2C933DECF3
00007e2c933dfb40  call 0x00007E2C932DE950
00007e2c933dfb45  jmp 0x00007E2C933DECFD
00007e2c933dfb4a  sub rsp, 0x08
00007e2c933dfb4e  push rax
00007e2c933dfb4f  push rcx
00007e2c933dfb50  push rdx
00007e2c933dfb51  push rdi
00007e2c933dfb52  push rsi
00007e2c933dfb53  push r8
00007e2c933dfb55  push r9
00007e2c933dfb57  push r10
00007e2c933dfb59  push r11
00007e2c933dfb5b  sub rsp, 0xF0
00007e2c933dfb62  vmovaps [rsp], xmm0
00007e2c933dfb67  vmovaps [rsp+0x10], xmm1
00007e2c933dfb6d  vmovaps [rsp+0x20], xmm2
00007e2c933dfb73  vmovaps [rsp+0x30], xmm3
00007e2c933dfb79  vmovaps [rsp+0x40], xmm4
00007e2c933dfb7f  vmovaps [rsp+0x50], xmm5
00007e2c933dfb85  vmovaps [rsp+0x60], xmm6
00007e2c933dfb8b  vmovaps [rsp+0x70], xmm7
00007e2c933dfb91  vmovaps [rsp+0x80], xmm9
00007e2c933dfb9a  vmovaps [rsp+0x90], xmm10
00007e2c933dfba3  vmovaps [rsp+0xA0], xmm11
00007e2c933dfbac  vmovaps [rsp+0xB0], xmm12
00007e2c933dfbb5  vmovaps [rsp+0xC0], xmm13
00007e2c933dfbbe  vmovaps [rsp+0xD0], xmm14
00007e2c933dfbc7  vmovaps [rsp+0xE0], xmm15
00007e2c933dfbd0  sub rsp, 0x30
00007e2c933dfbd4  movaps [rsp], xmm8
00007e2c933dfbd9  movaps [rsp+0x10], xmm12
00007e2c933dfbdf  movaps [rsp+0x20], xmm15
00007e2c933dfbe5  lea rdi, [rsp]
00007e2c933dfbe9  mov esi, 0x00
00007e2c933dfbee  mov rax, 0x5A263F1C7530
00007e2c933dfbf8  call rax
00007e2c933dfbfa  movaps xmm8, [rsp]
00007e2c933dfbff  add rsp, 0x30
00007e2c933dfc03  vmovaps xmm0, [rsp]
00007e2c933dfc08  vmovaps xmm1, [rsp+0x10]
00007e2c933dfc0e  vmovaps xmm2, [rsp+0x20]
00007e2c933dfc14  vmovaps xmm3, [rsp+0x30]
00007e2c933dfc1a  vmovaps xmm4, [rsp+0x40]
00007e2c933dfc20  vmovaps xmm5, [rsp+0x50]
00007e2c933dfc26  vmovaps xmm6, [rsp+0x60]
00007e2c933dfc2c  vmovaps xmm7, [rsp+0x70]
00007e2c933dfc32  vmovaps xmm9, [rsp+0x80]
00007e2c933dfc3b  vmovaps xmm10, [rsp+0x90]
00007e2c933dfc44  vmovaps xmm11, [rsp+0xA0]
00007e2c933dfc4d  vmovaps xmm12, [rsp+0xB0]
00007e2c933dfc56  vmovaps xmm13, [rsp+0xC0]
00007e2c933dfc5f  vmovaps xmm14, [rsp+0xD0]
00007e2c933dfc68  vmovaps xmm15, [rsp+0xE0]
00007e2c933dfc71  add rsp, 0xF0
00007e2c933dfc78  pop r11
00007e2c933dfc7a  pop r10
00007e2c933dfc7c  pop r9
00007e2c933dfc7e  pop r8
00007e2c933dfc80  pop rsi
00007e2c933dfc81  pop rdi
00007e2c933dfc82  pop rdx
00007e2c933dfc83  pop rcx
00007e2c933dfc84  pop rax
00007e2c933dfc85  add rsp, 0x08
00007e2c933dfc89  jmp 0x00007E2C933DED27
00007e2c933dfc8e  sub rsp, 0x08
00007e2c933dfc92  push rax
00007e2c933dfc93  push rcx
00007e2c933dfc94  push rdx
00007e2c933dfc95  push rdi
00007e2c933dfc96  push rsi
00007e2c933dfc97  push r8
00007e2c933dfc99  push r9
00007e2c933dfc9b  push r10
00007e2c933dfc9d  push r11
00007e2c933dfc9f  sub rsp, 0xF0
00007e2c933dfca6  vmovaps [rsp], xmm0
00007e2c933dfcab  vmovaps [rsp+0x10], xmm1
00007e2c933dfcb1  vmovaps [rsp+0x20], xmm2
00007e2c933dfcb7  vmovaps [rsp+0x30], xmm3
00007e2c933dfcbd  vmovaps [rsp+0x40], xmm4
00007e2c933dfcc3  vmovaps [rsp+0x50], xmm5
00007e2c933dfcc9  vmovaps [rsp+0x60], xmm6
00007e2c933dfccf  vmovaps [rsp+0x70], xmm8
00007e2c933dfcd5  vmovaps [rsp+0x80], xmm9
00007e2c933dfcde  vmovaps [rsp+0x90], xmm10
00007e2c933dfce7  vmovaps [rsp+0xA0], xmm11
00007e2c933dfcf0  vmovaps [rsp+0xB0], xmm12
00007e2c933dfcf9  vmovaps [rsp+0xC0], xmm13
00007e2c933dfd02  vmovaps [rsp+0xD0], xmm14
00007e2c933dfd0b  vmovaps [rsp+0xE0], xmm15
00007e2c933dfd14  sub rsp, 0x30
00007e2c933dfd18  movaps [rsp], xmm7
00007e2c933dfd1c  movaps [rsp+0x10], xmm9
00007e2c933dfd22  movaps [rsp+0x20], xmm15
00007e2c933dfd28  lea rdi, [rsp]
00007e2c933dfd2c  mov esi, 0x00
00007e2c933dfd31  mov rax, 0x5A263F1C7530
00007e2c933dfd3b  call rax
00007e2c933dfd3d  movaps xmm7, [rsp]
00007e2c933dfd41  add rsp, 0x30
00007e2c933dfd45  vmovaps xmm0, [rsp]
00007e2c933dfd4a  vmovaps xmm1, [rsp+0x10]
00007e2c933dfd50  vmovaps xmm2, [rsp+0x20]
00007e2c933dfd56  vmovaps xmm3, [rsp+0x30]
00007e2c933dfd5c  vmovaps xmm4, [rsp+0x40]
00007e2c933dfd62  vmovaps xmm5, [rsp+0x50]
00007e2c933dfd68  vmovaps xmm6, [rsp+0x60]
00007e2c933dfd6e  vmovaps xmm8, [rsp+0x70]
00007e2c933dfd74  vmovaps xmm9, [rsp+0x80]
00007e2c933dfd7d  vmovaps xmm10, [rsp+0x90]
00007e2c933dfd86  vmovaps xmm11, [rsp+0xA0]
00007e2c933dfd8f  vmovaps xmm12, [rsp+0xB0]
00007e2c933dfd98  vmovaps xmm13, [rsp+0xC0]
00007e2c933dfda1  vmovaps xmm14, [rsp+0xD0]
00007e2c933dfdaa  vmovaps xmm15, [rsp+0xE0]
00007e2c933dfdb3  add rsp, 0xF0
00007e2c933dfdba  pop r11
00007e2c933dfdbc  pop r10
00007e2c933dfdbe  pop r9
00007e2c933dfdc0  pop r8
00007e2c933dfdc2  pop rsi
00007e2c933dfdc3  pop rdi
00007e2c933dfdc4  pop rdx
00007e2c933dfdc5  pop rcx
00007e2c933dfdc6  pop rax
00007e2c933dfdc7  add rsp, 0x08
00007e2c933dfdcb  jmp 0x00007E2C933DED55
00007e2c933dfdd0  sub rsp, 0x08
00007e2c933dfdd4  push rax
00007e2c933dfdd5  push rcx
00007e2c933dfdd6  push rdx
00007e2c933dfdd7  push rdi
00007e2c933dfdd8  push rsi
00007e2c933dfdd9  push r8
00007e2c933dfddb  push r9
00007e2c933dfddd  push r10
00007e2c933dfddf  push r11
00007e2c933dfde1  sub rsp, 0xF0
00007e2c933dfde8  vmovaps [rsp], xmm0
00007e2c933dfded  vmovaps [rsp+0x10], xmm1
00007e2c933dfdf3  vmovaps [rsp+0x20], xmm2
00007e2c933dfdf9  vmovaps [rsp+0x30], xmm3
00007e2c933dfdff  vmovaps [rsp+0x40], xmm4
00007e2c933dfe05  vmovaps [rsp+0x50], xmm5
00007e2c933dfe0b  vmovaps [rsp+0x60], xmm6
00007e2c933dfe11  vmovaps [rsp+0x70], xmm7
00007e2c933dfe17  vmovaps [rsp+0x80], xmm8
00007e2c933dfe20  vmovaps [rsp+0x90], xmm10
00007e2c933dfe29  vmovaps [rsp+0xA0], xmm11
00007e2c933dfe32  vmovaps [rsp+0xB0], xmm12
00007e2c933dfe3b  vmovaps [rsp+0xC0], xmm13
00007e2c933dfe44  vmovaps [rsp+0xD0], xmm14
00007e2c933dfe4d  vmovaps [rsp+0xE0], xmm15
00007e2c933dfe56  sub rsp, 0x30
00007e2c933dfe5a  movaps [rsp], xmm9
00007e2c933dfe5f  movaps [rsp+0x10], xmm12
00007e2c933dfe65  movaps [rsp+0x20], xmm10
00007e2c933dfe6b  lea rdi, [rsp]
00007e2c933dfe6f  mov esi, 0x00
00007e2c933dfe74  mov rax, 0x5A263F1C7530
00007e2c933dfe7e  call rax
00007e2c933dfe80  movaps xmm9, [rsp]
00007e2c933dfe85  add rsp, 0x30
00007e2c933dfe89  vmovaps xmm0, [rsp]
00007e2c933dfe8e  vmovaps xmm1, [rsp+0x10]
00007e2c933dfe94  vmovaps xmm2, [rsp+0x20]
00007e2c933dfe9a  vmovaps xmm3, [rsp+0x30]
00007e2c933dfea0  vmovaps xmm4, [rsp+0x40]
00007e2c933dfea6  vmovaps xmm5, [rsp+0x50]
00007e2c933dfeac  vmovaps xmm6, [rsp+0x60]
00007e2c933dfeb2  vmovaps xmm7, [rsp+0x70]
00007e2c933dfeb8  vmovaps xmm8, [rsp+0x80]
00007e2c933dfec1  vmovaps xmm10, [rsp+0x90]
00007e2c933dfeca  vmovaps xmm11, [rsp+0xA0]
00007e2c933dfed3  vmovaps xmm12, [rsp+0xB0]
00007e2c933dfedc  vmovaps xmm13, [rsp+0xC0]
00007e2c933dfee5  vmovaps xmm14, [rsp+0xD0]
00007e2c933dfeee  vmovaps xmm15, [rsp+0xE0]
00007e2c933dfef7  add rsp, 0xF0
00007e2c933dfefe  pop r11
00007e2c933dff00  pop r10
00007e2c933dff02  pop r9
00007e2c933dff04  pop r8
00007e2c933dff06  pop rsi
00007e2c933dff07  pop rdi
00007e2c933dff08  pop rdx
00007e2c933dff09  pop rcx
00007e2c933dff0a  pop rax
00007e2c933dff0b  add rsp, 0x08
00007e2c933dff0f  jmp 0x00007E2C933DED79
00007e2c933dff14  sub rsp, 0x08
00007e2c933dff18  push rax
00007e2c933dff19  push rcx
00007e2c933dff1a  push rdx
00007e2c933dff1b  push rdi
00007e2c933dff1c  push rsi
00007e2c933dff1d  push r8
00007e2c933dff1f  push r9
00007e2c933dff21  push r10
00007e2c933dff23  push r11
00007e2c933dff25  sub rsp, 0xF0
00007e2c933dff2c  vmovaps [rsp], xmm0
00007e2c933dff31  vmovaps [rsp+0x10], xmm1
00007e2c933dff37  vmovaps [rsp+0x20], xmm2
00007e2c933dff3d  vmovaps [rsp+0x30], xmm3
00007e2c933dff43  vmovaps [rsp+0x40], xmm4
00007e2c933dff49  vmovaps [rsp+0x50], xmm5
00007e2c933dff4f  vmovaps [rsp+0x60], xmm6
00007e2c933dff55  vmovaps [rsp+0x70], xmm7
00007e2c933dff5b  vmovaps [rsp+0x80], xmm8
00007e2c933dff64  vmovaps [rsp+0x90], xmm9
00007e2c933dff6d  vmovaps [rsp+0xA0], xmm11
00007e2c933dff76  vmovaps [rsp+0xB0], xmm12
00007e2c933dff7f  vmovaps [rsp+0xC0], xmm13
00007e2c933dff88  vmovaps [rsp+0xD0], xmm14
00007e2c933dff91  vmovaps [rsp+0xE0], xmm15
00007e2c933dff9a  sub rsp, 0x30
00007e2c933dff9e  movaps [rsp], xmm10
00007e2c933dffa3  movaps [rsp+0x10], xmm12
00007e2c933dffa9  movaps [rsp+0x20], xmm11
00007e2c933dffaf  lea rdi, [rsp]
00007e2c933dffb3  mov esi, 0x00
00007e2c933dffb8  mov rax, 0x5A263F1C7530
00007e2c933dffc2  call rax
00007e2c933dffc4  movaps xmm10, [rsp]
00007e2c933dffc9  add rsp, 0x30
00007e2c933dffcd  vmovaps xmm0, [rsp]
00007e2c933dffd2  vmovaps xmm1, [rsp+0x10]
00007e2c933dffd8  vmovaps xmm2, [rsp+0x20]
00007e2c933dffde  vmovaps xmm3, [rsp+0x30]
00007e2c933dffe4  vmovaps xmm4, [rsp+0x40]
00007e2c933dffea  vmovaps xmm5, [rsp+0x50]
00007e2c933dfff0  vmovaps xmm6, [rsp+0x60]
00007e2c933dfff6  vmovaps xmm7, [rsp+0x70]
00007e2c933dfffc  vmovaps xmm8, [rsp+0x80]
00007e2c933e0005  vmovaps xmm9, [rsp+0x90]
00007e2c933e000e  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0017  vmovaps xmm12, [rsp+0xB0]
00007e2c933e0020  vmovaps xmm13, [rsp+0xC0]
00007e2c933e0029  vmovaps xmm14, [rsp+0xD0]
00007e2c933e0032  vmovaps xmm15, [rsp+0xE0]
00007e2c933e003b  add rsp, 0xF0
00007e2c933e0042  pop r11
00007e2c933e0044  pop r10
00007e2c933e0046  pop r9
00007e2c933e0048  pop r8
00007e2c933e004a  pop rsi
00007e2c933e004b  pop rdi
00007e2c933e004c  pop rdx
00007e2c933e004d  pop rcx
00007e2c933e004e  pop rax
00007e2c933e004f  add rsp, 0x08
00007e2c933e0053  jmp 0x00007E2C933DED93
00007e2c933e0058  sub rsp, 0x08
00007e2c933e005c  push rax
00007e2c933e005d  push rcx
00007e2c933e005e  push rdx
00007e2c933e005f  push rdi
00007e2c933e0060  push rsi
00007e2c933e0061  push r8
00007e2c933e0063  push r9
00007e2c933e0065  push r10
00007e2c933e0067  push r11
00007e2c933e0069  sub rsp, 0xF0
00007e2c933e0070  vmovaps [rsp], xmm0
00007e2c933e0075  vmovaps [rsp+0x10], xmm1
00007e2c933e007b  vmovaps [rsp+0x20], xmm2
00007e2c933e0081  vmovaps [rsp+0x30], xmm3
00007e2c933e0087  vmovaps [rsp+0x40], xmm4
00007e2c933e008d  vmovaps [rsp+0x50], xmm5
00007e2c933e0093  vmovaps [rsp+0x60], xmm7
00007e2c933e0099  vmovaps [rsp+0x70], xmm8
00007e2c933e009f  vmovaps [rsp+0x80], xmm9
00007e2c933e00a8  vmovaps [rsp+0x90], xmm10
00007e2c933e00b1  vmovaps [rsp+0xA0], xmm11
00007e2c933e00ba  vmovaps [rsp+0xB0], xmm12
00007e2c933e00c3  vmovaps [rsp+0xC0], xmm13
00007e2c933e00cc  vmovaps [rsp+0xD0], xmm14
00007e2c933e00d5  vmovaps [rsp+0xE0], xmm15
00007e2c933e00de  sub rsp, 0x30
00007e2c933e00e2  movaps [rsp], xmm6
00007e2c933e00e6  movaps [rsp+0x10], xmm12
00007e2c933e00ec  movaps [rsp+0x20], xmm11
00007e2c933e00f2  lea rdi, [rsp]
00007e2c933e00f6  mov esi, 0x00
00007e2c933e00fb  mov rax, 0x5A263F1C7530
00007e2c933e0105  call rax
00007e2c933e0107  movaps xmm6, [rsp]
00007e2c933e010b  add rsp, 0x30
00007e2c933e010f  vmovaps xmm0, [rsp]
00007e2c933e0114  vmovaps xmm1, [rsp+0x10]
00007e2c933e011a  vmovaps xmm2, [rsp+0x20]
00007e2c933e0120  vmovaps xmm3, [rsp+0x30]
00007e2c933e0126  vmovaps xmm4, [rsp+0x40]
00007e2c933e012c  vmovaps xmm5, [rsp+0x50]
00007e2c933e0132  vmovaps xmm7, [rsp+0x60]
00007e2c933e0138  vmovaps xmm8, [rsp+0x70]
00007e2c933e013e  vmovaps xmm9, [rsp+0x80]
00007e2c933e0147  vmovaps xmm10, [rsp+0x90]
00007e2c933e0150  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0159  vmovaps xmm12, [rsp+0xB0]
00007e2c933e0162  vmovaps xmm13, [rsp+0xC0]
00007e2c933e016b  vmovaps xmm14, [rsp+0xD0]
00007e2c933e0174  vmovaps xmm15, [rsp+0xE0]
00007e2c933e017d  add rsp, 0xF0
00007e2c933e0184  pop r11
00007e2c933e0186  pop r10
00007e2c933e0188  pop r9
00007e2c933e018a  pop r8
00007e2c933e018c  pop rsi
00007e2c933e018d  pop rdi
00007e2c933e018e  pop rdx
00007e2c933e018f  pop rcx
00007e2c933e0190  pop rax
00007e2c933e0191  add rsp, 0x08
00007e2c933e0195  jmp 0x00007E2C933DEDB4
00007e2c933e019a  sub rsp, 0x08
00007e2c933e019e  push rax
00007e2c933e019f  push rcx
00007e2c933e01a0  push rdx
00007e2c933e01a1  push rdi
00007e2c933e01a2  push rsi
00007e2c933e01a3  push r8
00007e2c933e01a5  push r9
00007e2c933e01a7  push r10
00007e2c933e01a9  push r11
00007e2c933e01ab  sub rsp, 0xF0
00007e2c933e01b2  vmovaps [rsp], xmm0
00007e2c933e01b7  vmovaps [rsp+0x10], xmm1
00007e2c933e01bd  vmovaps [rsp+0x20], xmm2
00007e2c933e01c3  vmovaps [rsp+0x30], xmm4
00007e2c933e01c9  vmovaps [rsp+0x40], xmm5
00007e2c933e01cf  vmovaps [rsp+0x50], xmm6
00007e2c933e01d5  vmovaps [rsp+0x60], xmm7
00007e2c933e01db  vmovaps [rsp+0x70], xmm8
00007e2c933e01e1  vmovaps [rsp+0x80], xmm9
00007e2c933e01ea  vmovaps [rsp+0x90], xmm10
00007e2c933e01f3  vmovaps [rsp+0xA0], xmm11
00007e2c933e01fc  vmovaps [rsp+0xB0], xmm12
00007e2c933e0205  vmovaps [rsp+0xC0], xmm13
00007e2c933e020e  vmovaps [rsp+0xD0], xmm14
00007e2c933e0217  vmovaps [rsp+0xE0], xmm15
00007e2c933e0220  sub rsp, 0x30
00007e2c933e0224  movaps [rsp], xmm3
00007e2c933e0228  movaps [rsp+0x10], xmm5
00007e2c933e022d  movaps [rsp+0x20], xmm4
00007e2c933e0232  lea rdi, [rsp]
00007e2c933e0236  mov esi, 0x00
00007e2c933e023b  mov rax, 0x5A263F1C7530
00007e2c933e0245  call rax
00007e2c933e0247  movaps xmm3, [rsp]
00007e2c933e024b  add rsp, 0x30
00007e2c933e024f  vmovaps xmm0, [rsp]
00007e2c933e0254  vmovaps xmm1, [rsp+0x10]
00007e2c933e025a  vmovaps xmm2, [rsp+0x20]
00007e2c933e0260  vmovaps xmm4, [rsp+0x30]
00007e2c933e0266  vmovaps xmm5, [rsp+0x40]
00007e2c933e026c  vmovaps xmm6, [rsp+0x50]
00007e2c933e0272  vmovaps xmm7, [rsp+0x60]
00007e2c933e0278  vmovaps xmm8, [rsp+0x70]
00007e2c933e027e  vmovaps xmm9, [rsp+0x80]
00007e2c933e0287  vmovaps xmm10, [rsp+0x90]
00007e2c933e0290  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0299  vmovaps xmm12, [rsp+0xB0]
00007e2c933e02a2  vmovaps xmm13, [rsp+0xC0]
00007e2c933e02ab  vmovaps xmm14, [rsp+0xD0]
00007e2c933e02b4  vmovaps xmm15, [rsp+0xE0]
00007e2c933e02bd  add rsp, 0xF0
00007e2c933e02c4  pop r11
00007e2c933e02c6  pop r10
00007e2c933e02c8  pop r9
00007e2c933e02ca  pop r8
00007e2c933e02cc  pop rsi
00007e2c933e02cd  pop rdi
00007e2c933e02ce  pop rdx
00007e2c933e02cf  pop rcx
00007e2c933e02d0  pop rax
00007e2c933e02d1  add rsp, 0x08
00007e2c933e02d5  jmp 0x00007E2C933DEE15
00007e2c933e02da  sub rsp, 0x08
00007e2c933e02de  push rax
00007e2c933e02df  push rcx
00007e2c933e02e0  push rdx
00007e2c933e02e1  push rdi
00007e2c933e02e2  push rsi
00007e2c933e02e3  push r8
00007e2c933e02e5  push r9
00007e2c933e02e7  push r10
00007e2c933e02e9  push r11
00007e2c933e02eb  sub rsp, 0xF0
00007e2c933e02f2  vmovaps [rsp], xmm0
00007e2c933e02f7  vmovaps [rsp+0x10], xmm1
00007e2c933e02fd  vmovaps [rsp+0x20], xmm2
00007e2c933e0303  vmovaps [rsp+0x30], xmm3
00007e2c933e0309  vmovaps [rsp+0x40], xmm4
00007e2c933e030f  vmovaps [rsp+0x50], xmm6
00007e2c933e0315  vmovaps [rsp+0x60], xmm7
00007e2c933e031b  vmovaps [rsp+0x70], xmm8
00007e2c933e0321  vmovaps [rsp+0x80], xmm9
00007e2c933e032a  vmovaps [rsp+0x90], xmm10
00007e2c933e0333  vmovaps [rsp+0xA0], xmm11
00007e2c933e033c  vmovaps [rsp+0xB0], xmm12
00007e2c933e0345  vmovaps [rsp+0xC0], xmm13
00007e2c933e034e  vmovaps [rsp+0xD0], xmm14
00007e2c933e0357  vmovaps [rsp+0xE0], xmm15
00007e2c933e0360  sub rsp, 0x30
00007e2c933e0364  movaps [rsp], xmm5
00007e2c933e0368  movaps [rsp+0x10], xmm8
00007e2c933e036e  movaps [rsp+0x20], xmm15
00007e2c933e0374  lea rdi, [rsp]
00007e2c933e0378  mov esi, 0x00
00007e2c933e037d  mov rax, 0x5A263F1C7530
00007e2c933e0387  call rax
00007e2c933e0389  movaps xmm5, [rsp]
00007e2c933e038d  add rsp, 0x30
00007e2c933e0391  vmovaps xmm0, [rsp]
00007e2c933e0396  vmovaps xmm1, [rsp+0x10]
00007e2c933e039c  vmovaps xmm2, [rsp+0x20]
00007e2c933e03a2  vmovaps xmm3, [rsp+0x30]
00007e2c933e03a8  vmovaps xmm4, [rsp+0x40]
00007e2c933e03ae  vmovaps xmm6, [rsp+0x50]
00007e2c933e03b4  vmovaps xmm7, [rsp+0x60]
00007e2c933e03ba  vmovaps xmm8, [rsp+0x70]
00007e2c933e03c0  vmovaps xmm9, [rsp+0x80]
00007e2c933e03c9  vmovaps xmm10, [rsp+0x90]
00007e2c933e03d2  vmovaps xmm11, [rsp+0xA0]
00007e2c933e03db  vmovaps xmm12, [rsp+0xB0]
00007e2c933e03e4  vmovaps xmm13, [rsp+0xC0]
00007e2c933e03ed  vmovaps xmm14, [rsp+0xD0]
00007e2c933e03f6  vmovaps xmm15, [rsp+0xE0]
00007e2c933e03ff  add rsp, 0xF0
00007e2c933e0406  pop r11
00007e2c933e0408  pop r10
00007e2c933e040a  pop r9
00007e2c933e040c  pop r8
00007e2c933e040e  pop rsi
00007e2c933e040f  pop rdi
00007e2c933e0410  pop rdx
00007e2c933e0411  pop rcx
00007e2c933e0412  pop rax
00007e2c933e0413  add rsp, 0x08
00007e2c933e0417  jmp 0x00007E2C933DEE53
00007e2c933e041c  sub rsp, 0x08
00007e2c933e0420  push rax
00007e2c933e0421  push rcx
00007e2c933e0422  push rdx
00007e2c933e0423  push rdi
00007e2c933e0424  push rsi
00007e2c933e0425  push r8
00007e2c933e0427  push r9
00007e2c933e0429  push r10
00007e2c933e042b  push r11
00007e2c933e042d  sub rsp, 0xF0
00007e2c933e0434  vmovaps [rsp], xmm0
00007e2c933e0439  vmovaps [rsp+0x10], xmm1
00007e2c933e043f  vmovaps [rsp+0x20], xmm2
00007e2c933e0445  vmovaps [rsp+0x30], xmm3
00007e2c933e044b  vmovaps [rsp+0x40], xmm5
00007e2c933e0451  vmovaps [rsp+0x50], xmm6
00007e2c933e0457  vmovaps [rsp+0x60], xmm7
00007e2c933e045d  vmovaps [rsp+0x70], xmm8
00007e2c933e0463  vmovaps [rsp+0x80], xmm9
00007e2c933e046c  vmovaps [rsp+0x90], xmm10
00007e2c933e0475  vmovaps [rsp+0xA0], xmm11
00007e2c933e047e  vmovaps [rsp+0xB0], xmm12
00007e2c933e0487  vmovaps [rsp+0xC0], xmm13
00007e2c933e0490  vmovaps [rsp+0xD0], xmm14
00007e2c933e0499  vmovaps [rsp+0xE0], xmm15
00007e2c933e04a2  sub rsp, 0x30
00007e2c933e04a6  movaps [rsp], xmm4
00007e2c933e04aa  movaps [rsp+0x10], xmm9
00007e2c933e04b0  movaps [rsp+0x20], xmm8
00007e2c933e04b6  lea rdi, [rsp]
00007e2c933e04ba  mov esi, 0x00
00007e2c933e04bf  mov rax, 0x5A263F1C7530
00007e2c933e04c9  call rax
00007e2c933e04cb  movaps xmm4, [rsp]
00007e2c933e04cf  add rsp, 0x30
00007e2c933e04d3  vmovaps xmm0, [rsp]
00007e2c933e04d8  vmovaps xmm1, [rsp+0x10]
00007e2c933e04de  vmovaps xmm2, [rsp+0x20]
00007e2c933e04e4  vmovaps xmm3, [rsp+0x30]
00007e2c933e04ea  vmovaps xmm5, [rsp+0x40]
00007e2c933e04f0  vmovaps xmm6, [rsp+0x50]
00007e2c933e04f6  vmovaps xmm7, [rsp+0x60]
00007e2c933e04fc  vmovaps xmm8, [rsp+0x70]
00007e2c933e0502  vmovaps xmm9, [rsp+0x80]
00007e2c933e050b  vmovaps xmm10, [rsp+0x90]
00007e2c933e0514  vmovaps xmm11, [rsp+0xA0]
00007e2c933e051d  vmovaps xmm12, [rsp+0xB0]
00007e2c933e0526  vmovaps xmm13, [rsp+0xC0]
00007e2c933e052f  vmovaps xmm14, [rsp+0xD0]
00007e2c933e0538  vmovaps xmm15, [rsp+0xE0]
00007e2c933e0541  add rsp, 0xF0
00007e2c933e0548  pop r11
00007e2c933e054a  pop r10
00007e2c933e054c  pop r9
00007e2c933e054e  pop r8
00007e2c933e0550  pop rsi
00007e2c933e0551  pop rdi
00007e2c933e0552  pop rdx
00007e2c933e0553  pop rcx
00007e2c933e0554  pop rax
00007e2c933e0555  add rsp, 0x08
00007e2c933e0559  jmp 0x00007E2C933DEE74
00007e2c933e055e  sub rsp, 0x08
00007e2c933e0562  push rax
00007e2c933e0563  push rcx
00007e2c933e0564  push rdx
00007e2c933e0565  push rdi
00007e2c933e0566  push rsi
00007e2c933e0567  push r8
00007e2c933e0569  push r9
00007e2c933e056b  push r10
00007e2c933e056d  push r11
00007e2c933e056f  sub rsp, 0xF0
00007e2c933e0576  vmovaps [rsp], xmm0
00007e2c933e057b  vmovaps [rsp+0x10], xmm1
00007e2c933e0581  vmovaps [rsp+0x20], xmm2
00007e2c933e0587  vmovaps [rsp+0x30], xmm3
00007e2c933e058d  vmovaps [rsp+0x40], xmm4
00007e2c933e0593  vmovaps [rsp+0x50], xmm5
00007e2c933e0599  vmovaps [rsp+0x60], xmm6
00007e2c933e059f  vmovaps [rsp+0x70], xmm7
00007e2c933e05a5  vmovaps [rsp+0x80], xmm8
00007e2c933e05ae  vmovaps [rsp+0x90], xmm10
00007e2c933e05b7  vmovaps [rsp+0xA0], xmm11
00007e2c933e05c0  vmovaps [rsp+0xB0], xmm12
00007e2c933e05c9  vmovaps [rsp+0xC0], xmm13
00007e2c933e05d2  vmovaps [rsp+0xD0], xmm14
00007e2c933e05db  vmovaps [rsp+0xE0], xmm15
00007e2c933e05e4  sub rsp, 0x30
00007e2c933e05e8  movaps [rsp], xmm9
00007e2c933e05ed  movaps [rsp+0x10], xmm10
00007e2c933e05f3  movaps [rsp+0x20], xmm8
00007e2c933e05f9  lea rdi, [rsp]
00007e2c933e05fd  mov esi, 0x00
00007e2c933e0602  mov rax, 0x5A263F1C7530
00007e2c933e060c  call rax
00007e2c933e060e  movaps xmm9, [rsp]
00007e2c933e0613  add rsp, 0x30
00007e2c933e0617  vmovaps xmm0, [rsp]
00007e2c933e061c  vmovaps xmm1, [rsp+0x10]
00007e2c933e0622  vmovaps xmm2, [rsp+0x20]
00007e2c933e0628  vmovaps xmm3, [rsp+0x30]
00007e2c933e062e  vmovaps xmm4, [rsp+0x40]
00007e2c933e0634  vmovaps xmm5, [rsp+0x50]
00007e2c933e063a  vmovaps xmm6, [rsp+0x60]
00007e2c933e0640  vmovaps xmm7, [rsp+0x70]
00007e2c933e0646  vmovaps xmm8, [rsp+0x80]
00007e2c933e064f  vmovaps xmm10, [rsp+0x90]
00007e2c933e0658  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0661  vmovaps xmm12, [rsp+0xB0]
00007e2c933e066a  vmovaps xmm13, [rsp+0xC0]
00007e2c933e0673  vmovaps xmm14, [rsp+0xD0]
00007e2c933e067c  vmovaps xmm15, [rsp+0xE0]
00007e2c933e0685  add rsp, 0xF0
00007e2c933e068c  pop r11
00007e2c933e068e  pop r10
00007e2c933e0690  pop r9
00007e2c933e0692  pop r8
00007e2c933e0694  pop rsi
00007e2c933e0695  pop rdi
00007e2c933e0696  pop rdx
00007e2c933e0697  pop rcx
00007e2c933e0698  pop rax
00007e2c933e0699  add rsp, 0x08
00007e2c933e069d  jmp 0x00007E2C933DEE8E
00007e2c933e06a2  call 0x00007E2C932B52F0
00007e2c933e06a7  jmp 0x00007E2C933DEFA8
00007e2c933e06ac  call 0x00007E2C932B52F0
00007e2c933e06b1  jmp 0x00007E2C933DEFBE
00007e2c933e06b6  sub rsp, 0x08
00007e2c933e06ba  push rax
00007e2c933e06bb  push rcx
00007e2c933e06bc  push rdx
00007e2c933e06bd  push rdi
00007e2c933e06be  push rsi
00007e2c933e06bf  push r8
00007e2c933e06c1  push r9
00007e2c933e06c3  push r10
00007e2c933e06c5  push r11
00007e2c933e06c7  sub rsp, 0xF0
00007e2c933e06ce  vmovaps [rsp], xmm0
00007e2c933e06d3  vmovaps [rsp+0x10], xmm2
00007e2c933e06d9  vmovaps [rsp+0x20], xmm3
00007e2c933e06df  vmovaps [rsp+0x30], xmm4
00007e2c933e06e5  vmovaps [rsp+0x40], xmm5
00007e2c933e06eb  vmovaps [rsp+0x50], xmm6
00007e2c933e06f1  vmovaps [rsp+0x60], xmm7
00007e2c933e06f7  vmovaps [rsp+0x70], xmm8
00007e2c933e06fd  vmovaps [rsp+0x80], xmm9
00007e2c933e0706  vmovaps [rsp+0x90], xmm10
00007e2c933e070f  vmovaps [rsp+0xA0], xmm11
00007e2c933e0718  vmovaps [rsp+0xB0], xmm12
00007e2c933e0721  vmovaps [rsp+0xC0], xmm13
00007e2c933e072a  vmovaps [rsp+0xD0], xmm14
00007e2c933e0733  vmovaps [rsp+0xE0], xmm15
00007e2c933e073c  sub rsp, 0x30
00007e2c933e0740  movaps [rsp], xmm1
00007e2c933e0744  movaps [rsp+0x10], xmm6
00007e2c933e0749  movaps [rsp+0x20], xmm15
00007e2c933e074f  lea rdi, [rsp]
00007e2c933e0753  mov esi, 0x00
00007e2c933e0758  mov rax, 0x5A263F1C7530
00007e2c933e0762  call rax
00007e2c933e0764  movaps xmm1, [rsp]
00007e2c933e0768  add rsp, 0x30
00007e2c933e076c  vmovaps xmm0, [rsp]
00007e2c933e0771  vmovaps xmm2, [rsp+0x10]
00007e2c933e0777  vmovaps xmm3, [rsp+0x20]
00007e2c933e077d  vmovaps xmm4, [rsp+0x30]
00007e2c933e0783  vmovaps xmm5, [rsp+0x40]
00007e2c933e0789  vmovaps xmm6, [rsp+0x50]
00007e2c933e078f  vmovaps xmm7, [rsp+0x60]
00007e2c933e0795  vmovaps xmm8, [rsp+0x70]
00007e2c933e079b  vmovaps xmm9, [rsp+0x80]
00007e2c933e07a4  vmovaps xmm10, [rsp+0x90]
00007e2c933e07ad  vmovaps xmm11, [rsp+0xA0]
00007e2c933e07b6  vmovaps xmm12, [rsp+0xB0]
00007e2c933e07bf  vmovaps xmm13, [rsp+0xC0]
00007e2c933e07c8  vmovaps xmm14, [rsp+0xD0]
00007e2c933e07d1  vmovaps xmm15, [rsp+0xE0]
00007e2c933e07da  add rsp, 0xF0
00007e2c933e07e1  pop r11
00007e2c933e07e3  pop r10
00007e2c933e07e5  pop r9
00007e2c933e07e7  pop r8
00007e2c933e07e9  pop rsi
00007e2c933e07ea  pop rdi
00007e2c933e07eb  pop rdx
00007e2c933e07ec  pop rcx
00007e2c933e07ed  pop rax
00007e2c933e07ee  add rsp, 0x08
00007e2c933e07f2  jmp 0x00007E2C933DEFFB
00007e2c933e07f7  call 0x00007E2C932C4620
00007e2c933e07fc  jmp 0x00007E2C933DF008
00007e2c933e0801  sub rsp, 0x08
00007e2c933e0805  push rax
00007e2c933e0806  push rcx
00007e2c933e0807  push rdx
00007e2c933e0808  push rdi
00007e2c933e0809  push rsi
00007e2c933e080a  push r8
00007e2c933e080c  push r9
00007e2c933e080e  push r10
00007e2c933e0810  push r11
00007e2c933e0812  sub rsp, 0xF0
00007e2c933e0819  vmovaps [rsp], xmm0
00007e2c933e081e  vmovaps [rsp+0x10], xmm1
00007e2c933e0824  vmovaps [rsp+0x20], xmm2
00007e2c933e082a  vmovaps [rsp+0x30], xmm3
00007e2c933e0830  vmovaps [rsp+0x40], xmm4
00007e2c933e0836  vmovaps [rsp+0x50], xmm5
00007e2c933e083c  vmovaps [rsp+0x60], xmm6
00007e2c933e0842  vmovaps [rsp+0x70], xmm7
00007e2c933e0848  vmovaps [rsp+0x80], xmm8
00007e2c933e0851  vmovaps [rsp+0x90], xmm9
00007e2c933e085a  vmovaps [rsp+0xA0], xmm10
00007e2c933e0863  vmovaps [rsp+0xB0], xmm11
00007e2c933e086c  vmovaps [rsp+0xC0], xmm12
00007e2c933e0875  vmovaps [rsp+0xD0], xmm13
00007e2c933e087e  vmovaps [rsp+0xE0], xmm15
00007e2c933e0887  sub rsp, 0x30
00007e2c933e088b  movaps [rsp], xmm14
00007e2c933e0890  movaps [rsp+0x10], xmm4
00007e2c933e0895  movaps [rsp+0x20], xmm3
00007e2c933e089a  lea rdi, [rsp]
00007e2c933e089e  mov esi, 0x00
00007e2c933e08a3  mov rax, 0x5A263F1C7530
00007e2c933e08ad  call rax
00007e2c933e08af  movaps xmm14, [rsp]
00007e2c933e08b4  add rsp, 0x30
00007e2c933e08b8  vmovaps xmm0, [rsp]
00007e2c933e08bd  vmovaps xmm1, [rsp+0x10]
00007e2c933e08c3  vmovaps xmm2, [rsp+0x20]
00007e2c933e08c9  vmovaps xmm3, [rsp+0x30]
00007e2c933e08cf  vmovaps xmm4, [rsp+0x40]
00007e2c933e08d5  vmovaps xmm5, [rsp+0x50]
00007e2c933e08db  vmovaps xmm6, [rsp+0x60]
00007e2c933e08e1  vmovaps xmm7, [rsp+0x70]
00007e2c933e08e7  vmovaps xmm8, [rsp+0x80]
00007e2c933e08f0  vmovaps xmm9, [rsp+0x90]
00007e2c933e08f9  vmovaps xmm10, [rsp+0xA0]
00007e2c933e0902  vmovaps xmm11, [rsp+0xB0]
00007e2c933e090b  vmovaps xmm12, [rsp+0xC0]
00007e2c933e0914  vmovaps xmm13, [rsp+0xD0]
00007e2c933e091d  vmovaps xmm15, [rsp+0xE0]
00007e2c933e0926  add rsp, 0xF0
00007e2c933e092d  pop r11
00007e2c933e092f  pop r10
00007e2c933e0931  pop r9
00007e2c933e0933  pop r8
00007e2c933e0935  pop rsi
00007e2c933e0936  pop rdi
00007e2c933e0937  pop rdx
00007e2c933e0938  pop rcx
00007e2c933e0939  pop rax
00007e2c933e093a  add rsp, 0x08
00007e2c933e093e  jmp 0x00007E2C933DF022
00007e2c933e0943  sub rsp, 0x08
00007e2c933e0947  push rax
00007e2c933e0948  push rcx
00007e2c933e0949  push rdx
00007e2c933e094a  push rdi
00007e2c933e094b  push rsi
00007e2c933e094c  push r8
00007e2c933e094e  push r9
00007e2c933e0950  push r10
00007e2c933e0952  push r11
00007e2c933e0954  sub rsp, 0xF0
00007e2c933e095b  vmovaps [rsp], xmm0
00007e2c933e0960  vmovaps [rsp+0x10], xmm1
00007e2c933e0966  vmovaps [rsp+0x20], xmm2
00007e2c933e096c  vmovaps [rsp+0x30], xmm3
00007e2c933e0972  vmovaps [rsp+0x40], xmm4
00007e2c933e0978  vmovaps [rsp+0x50], xmm5
00007e2c933e097e  vmovaps [rsp+0x60], xmm7
00007e2c933e0984  vmovaps [rsp+0x70], xmm8
00007e2c933e098a  vmovaps [rsp+0x80], xmm9
00007e2c933e0993  vmovaps [rsp+0x90], xmm10
00007e2c933e099c  vmovaps [rsp+0xA0], xmm11
00007e2c933e09a5  vmovaps [rsp+0xB0], xmm12
00007e2c933e09ae  vmovaps [rsp+0xC0], xmm13
00007e2c933e09b7  vmovaps [rsp+0xD0], xmm14
00007e2c933e09c0  vmovaps [rsp+0xE0], xmm15
00007e2c933e09c9  sub rsp, 0x30
00007e2c933e09cd  movaps [rsp], xmm6
00007e2c933e09d1  movaps [rsp+0x10], xmm9
00007e2c933e09d7  movaps [rsp+0x20], xmm7
00007e2c933e09dc  lea rdi, [rsp]
00007e2c933e09e0  mov esi, 0x00
00007e2c933e09e5  mov rax, 0x5A263F1C7530
00007e2c933e09ef  call rax
00007e2c933e09f1  movaps xmm6, [rsp]
00007e2c933e09f5  add rsp, 0x30
00007e2c933e09f9  vmovaps xmm0, [rsp]
00007e2c933e09fe  vmovaps xmm1, [rsp+0x10]
00007e2c933e0a04  vmovaps xmm2, [rsp+0x20]
00007e2c933e0a0a  vmovaps xmm3, [rsp+0x30]
00007e2c933e0a10  vmovaps xmm4, [rsp+0x40]
00007e2c933e0a16  vmovaps xmm5, [rsp+0x50]
00007e2c933e0a1c  vmovaps xmm7, [rsp+0x60]
00007e2c933e0a22  vmovaps xmm8, [rsp+0x70]
00007e2c933e0a28  vmovaps xmm9, [rsp+0x80]
00007e2c933e0a31  vmovaps xmm10, [rsp+0x90]
00007e2c933e0a3a  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0a43  vmovaps xmm12, [rsp+0xB0]
00007e2c933e0a4c  vmovaps xmm13, [rsp+0xC0]
00007e2c933e0a55  vmovaps xmm14, [rsp+0xD0]
00007e2c933e0a5e  vmovaps xmm15, [rsp+0xE0]
00007e2c933e0a67  add rsp, 0xF0
00007e2c933e0a6e  pop r11
00007e2c933e0a70  pop r10
00007e2c933e0a72  pop r9
00007e2c933e0a74  pop r8
00007e2c933e0a76  pop rsi
00007e2c933e0a77  pop rdi
00007e2c933e0a78  pop rdx
00007e2c933e0a79  pop rcx
00007e2c933e0a7a  pop rax
00007e2c933e0a7b  add rsp, 0x08
00007e2c933e0a7f  jmp 0x00007E2C933DF03A
00007e2c933e0a84  sub rsp, 0x08
00007e2c933e0a88  push rax
00007e2c933e0a89  push rcx
00007e2c933e0a8a  push rdx
00007e2c933e0a8b  push rdi
00007e2c933e0a8c  push rsi
00007e2c933e0a8d  push r8
00007e2c933e0a8f  push r9
00007e2c933e0a91  push r10
00007e2c933e0a93  push r11
00007e2c933e0a95  sub rsp, 0xF0
00007e2c933e0a9c  vmovaps [rsp], xmm0
00007e2c933e0aa1  vmovaps [rsp+0x10], xmm1
00007e2c933e0aa7  vmovaps [rsp+0x20], xmm2
00007e2c933e0aad  vmovaps [rsp+0x30], xmm3
00007e2c933e0ab3  vmovaps [rsp+0x40], xmm4
00007e2c933e0ab9  vmovaps [rsp+0x50], xmm5
00007e2c933e0abf  vmovaps [rsp+0x60], xmm6
00007e2c933e0ac5  vmovaps [rsp+0x70], xmm8
00007e2c933e0acb  vmovaps [rsp+0x80], xmm9
00007e2c933e0ad4  vmovaps [rsp+0x90], xmm10
00007e2c933e0add  vmovaps [rsp+0xA0], xmm11
00007e2c933e0ae6  vmovaps [rsp+0xB0], xmm12
00007e2c933e0aef  vmovaps [rsp+0xC0], xmm13
00007e2c933e0af8  vmovaps [rsp+0xD0], xmm14
00007e2c933e0b01  vmovaps [rsp+0xE0], xmm15
00007e2c933e0b0a  sub rsp, 0x30
00007e2c933e0b0e  movaps [rsp], xmm7
00007e2c933e0b12  movaps [rsp+0x10], xmm4
00007e2c933e0b17  movaps [rsp+0x20], xmm9
00007e2c933e0b1d  lea rdi, [rsp]
00007e2c933e0b21  mov esi, 0x00
00007e2c933e0b26  mov rax, 0x5A263F1C7530
00007e2c933e0b30  call rax
00007e2c933e0b32  movaps xmm7, [rsp]
00007e2c933e0b36  add rsp, 0x30
00007e2c933e0b3a  vmovaps xmm0, [rsp]
00007e2c933e0b3f  vmovaps xmm1, [rsp+0x10]
00007e2c933e0b45  vmovaps xmm2, [rsp+0x20]
00007e2c933e0b4b  vmovaps xmm3, [rsp+0x30]
00007e2c933e0b51  vmovaps xmm4, [rsp+0x40]
00007e2c933e0b57  vmovaps xmm5, [rsp+0x50]
00007e2c933e0b5d  vmovaps xmm6, [rsp+0x60]
00007e2c933e0b63  vmovaps xmm8, [rsp+0x70]
00007e2c933e0b69  vmovaps xmm9, [rsp+0x80]
00007e2c933e0b72  vmovaps xmm10, [rsp+0x90]
00007e2c933e0b7b  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0b84  vmovaps xmm12, [rsp+0xB0]
00007e2c933e0b8d  vmovaps xmm13, [rsp+0xC0]
00007e2c933e0b96  vmovaps xmm14, [rsp+0xD0]
00007e2c933e0b9f  vmovaps xmm15, [rsp+0xE0]
00007e2c933e0ba8  add rsp, 0xF0
00007e2c933e0baf  pop r11
00007e2c933e0bb1  pop r10
00007e2c933e0bb3  pop r9
00007e2c933e0bb5  pop r8
00007e2c933e0bb7  pop rsi
00007e2c933e0bb8  pop rdi
00007e2c933e0bb9  pop rdx
00007e2c933e0bba  pop rcx
00007e2c933e0bbb  pop rax
00007e2c933e0bbc  add rsp, 0x08
00007e2c933e0bc0  jmp 0x00007E2C933DF067
00007e2c933e0bc5  sub rsp, 0x08
00007e2c933e0bc9  push rax
00007e2c933e0bca  push rcx
00007e2c933e0bcb  push rdx
00007e2c933e0bcc  push rdi
00007e2c933e0bcd  push rsi
00007e2c933e0bce  push r8
00007e2c933e0bd0  push r9
00007e2c933e0bd2  push r10
00007e2c933e0bd4  push r11
00007e2c933e0bd6  sub rsp, 0xF0
00007e2c933e0bdd  vmovaps [rsp], xmm0
00007e2c933e0be2  vmovaps [rsp+0x10], xmm1
00007e2c933e0be8  vmovaps [rsp+0x20], xmm2
00007e2c933e0bee  vmovaps [rsp+0x30], xmm3
00007e2c933e0bf4  vmovaps [rsp+0x40], xmm5
00007e2c933e0bfa  vmovaps [rsp+0x50], xmm6
00007e2c933e0c00  vmovaps [rsp+0x60], xmm7
00007e2c933e0c06  vmovaps [rsp+0x70], xmm8
00007e2c933e0c0c  vmovaps [rsp+0x80], xmm9
00007e2c933e0c15  vmovaps [rsp+0x90], xmm10
00007e2c933e0c1e  vmovaps [rsp+0xA0], xmm11
00007e2c933e0c27  vmovaps [rsp+0xB0], xmm12
00007e2c933e0c30  vmovaps [rsp+0xC0], xmm13
00007e2c933e0c39  vmovaps [rsp+0xD0], xmm14
00007e2c933e0c42  vmovaps [rsp+0xE0], xmm15
00007e2c933e0c4b  sub rsp, 0x30
00007e2c933e0c4f  movaps [rsp], xmm4
00007e2c933e0c53  movaps [rsp+0x10], xmm15
00007e2c933e0c59  movaps [rsp+0x20], xmm9
00007e2c933e0c5f  lea rdi, [rsp]
00007e2c933e0c63  mov esi, 0x00
00007e2c933e0c68  mov rax, 0x5A263F1C7530
00007e2c933e0c72  call rax
00007e2c933e0c74  movaps xmm4, [rsp]
00007e2c933e0c78  add rsp, 0x30
00007e2c933e0c7c  vmovaps xmm0, [rsp]
00007e2c933e0c81  vmovaps xmm1, [rsp+0x10]
00007e2c933e0c87  vmovaps xmm2, [rsp+0x20]
00007e2c933e0c8d  vmovaps xmm3, [rsp+0x30]
00007e2c933e0c93  vmovaps xmm5, [rsp+0x40]
00007e2c933e0c99  vmovaps xmm6, [rsp+0x50]
00007e2c933e0c9f  vmovaps xmm7, [rsp+0x60]
00007e2c933e0ca5  vmovaps xmm8, [rsp+0x70]
00007e2c933e0cab  vmovaps xmm9, [rsp+0x80]
00007e2c933e0cb4  vmovaps xmm10, [rsp+0x90]
00007e2c933e0cbd  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0cc6  vmovaps xmm12, [rsp+0xB0]
00007e2c933e0ccf  vmovaps xmm13, [rsp+0xC0]
00007e2c933e0cd8  vmovaps xmm14, [rsp+0xD0]
00007e2c933e0ce1  vmovaps xmm15, [rsp+0xE0]
00007e2c933e0cea  add rsp, 0xF0
00007e2c933e0cf1  pop r11
00007e2c933e0cf3  pop r10
00007e2c933e0cf5  pop r9
00007e2c933e0cf7  pop r8
00007e2c933e0cf9  pop rsi
00007e2c933e0cfa  pop rdi
00007e2c933e0cfb  pop rdx
00007e2c933e0cfc  pop rcx
00007e2c933e0cfd  pop rax
00007e2c933e0cfe  add rsp, 0x08
00007e2c933e0d02  jmp 0x00007E2C933DF08C
00007e2c933e0d07  call 0x00007E2C932C4620
00007e2c933e0d0c  jmp 0x00007E2C933DF099
00007e2c933e0d11  sub rsp, 0x08
00007e2c933e0d15  push rax
00007e2c933e0d16  push rcx
00007e2c933e0d17  push rdx
00007e2c933e0d18  push rdi
00007e2c933e0d19  push rsi
00007e2c933e0d1a  push r8
00007e2c933e0d1c  push r9
00007e2c933e0d1e  push r10
00007e2c933e0d20  push r11
00007e2c933e0d22  sub rsp, 0xF0
00007e2c933e0d29  vmovaps [rsp], xmm0
00007e2c933e0d2e  vmovaps [rsp+0x10], xmm1
00007e2c933e0d34  vmovaps [rsp+0x20], xmm2
00007e2c933e0d3a  vmovaps [rsp+0x30], xmm4
00007e2c933e0d40  vmovaps [rsp+0x40], xmm5
00007e2c933e0d46  vmovaps [rsp+0x50], xmm6
00007e2c933e0d4c  vmovaps [rsp+0x60], xmm7
00007e2c933e0d52  vmovaps [rsp+0x70], xmm8
00007e2c933e0d58  vmovaps [rsp+0x80], xmm9
00007e2c933e0d61  vmovaps [rsp+0x90], xmm10
00007e2c933e0d6a  vmovaps [rsp+0xA0], xmm11
00007e2c933e0d73  vmovaps [rsp+0xB0], xmm12
00007e2c933e0d7c  vmovaps [rsp+0xC0], xmm13
00007e2c933e0d85  vmovaps [rsp+0xD0], xmm14
00007e2c933e0d8e  vmovaps [rsp+0xE0], xmm15
00007e2c933e0d97  sub rsp, 0x30
00007e2c933e0d9b  movaps [rsp], xmm3
00007e2c933e0d9f  movaps [rsp+0x10], xmm1
00007e2c933e0da4  movaps [rsp+0x20], xmm9
00007e2c933e0daa  lea rdi, [rsp]
00007e2c933e0dae  mov esi, 0x00
00007e2c933e0db3  mov rax, 0x5A263F1C7530
00007e2c933e0dbd  call rax
00007e2c933e0dbf  movaps xmm3, [rsp]
00007e2c933e0dc3  add rsp, 0x30
00007e2c933e0dc7  vmovaps xmm0, [rsp]
00007e2c933e0dcc  vmovaps xmm1, [rsp+0x10]
00007e2c933e0dd2  vmovaps xmm2, [rsp+0x20]
00007e2c933e0dd8  vmovaps xmm4, [rsp+0x30]
00007e2c933e0dde  vmovaps xmm5, [rsp+0x40]
00007e2c933e0de4  vmovaps xmm6, [rsp+0x50]
00007e2c933e0dea  vmovaps xmm7, [rsp+0x60]
00007e2c933e0df0  vmovaps xmm8, [rsp+0x70]
00007e2c933e0df6  vmovaps xmm9, [rsp+0x80]
00007e2c933e0dff  vmovaps xmm10, [rsp+0x90]
00007e2c933e0e08  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0e11  vmovaps xmm12, [rsp+0xB0]
00007e2c933e0e1a  vmovaps xmm13, [rsp+0xC0]
00007e2c933e0e23  vmovaps xmm14, [rsp+0xD0]
00007e2c933e0e2c  vmovaps xmm15, [rsp+0xE0]
00007e2c933e0e35  add rsp, 0xF0
00007e2c933e0e3c  pop r11
00007e2c933e0e3e  pop r10
00007e2c933e0e40  pop r9
00007e2c933e0e42  pop r8
00007e2c933e0e44  pop rsi
00007e2c933e0e45  pop rdi
00007e2c933e0e46  pop rdx
00007e2c933e0e47  pop rcx
00007e2c933e0e48  pop rax
00007e2c933e0e49  add rsp, 0x08
00007e2c933e0e4d  jmp 0x00007E2C933DF0D6
00007e2c933e0e52  sub rsp, 0x08
00007e2c933e0e56  push rax
00007e2c933e0e57  push rcx
00007e2c933e0e58  push rdx
00007e2c933e0e59  push rdi
00007e2c933e0e5a  push rsi
00007e2c933e0e5b  push r8
00007e2c933e0e5d  push r9
00007e2c933e0e5f  push r10
00007e2c933e0e61  push r11
00007e2c933e0e63  sub rsp, 0xF0
00007e2c933e0e6a  vmovaps [rsp], xmm0
00007e2c933e0e6f  vmovaps [rsp+0x10], xmm2
00007e2c933e0e75  vmovaps [rsp+0x20], xmm3
00007e2c933e0e7b  vmovaps [rsp+0x30], xmm4
00007e2c933e0e81  vmovaps [rsp+0x40], xmm5
00007e2c933e0e87  vmovaps [rsp+0x50], xmm6
00007e2c933e0e8d  vmovaps [rsp+0x60], xmm7
00007e2c933e0e93  vmovaps [rsp+0x70], xmm8
00007e2c933e0e99  vmovaps [rsp+0x80], xmm9
00007e2c933e0ea2  vmovaps [rsp+0x90], xmm10
00007e2c933e0eab  vmovaps [rsp+0xA0], xmm11
00007e2c933e0eb4  vmovaps [rsp+0xB0], xmm12
00007e2c933e0ebd  vmovaps [rsp+0xC0], xmm13
00007e2c933e0ec6  vmovaps [rsp+0xD0], xmm14
00007e2c933e0ecf  vmovaps [rsp+0xE0], xmm15
00007e2c933e0ed8  sub rsp, 0x30
00007e2c933e0edc  movaps [rsp], xmm1
00007e2c933e0ee0  movaps [rsp+0x10], xmm15
00007e2c933e0ee6  movaps [rsp+0x20], xmm9
00007e2c933e0eec  lea rdi, [rsp]
00007e2c933e0ef0  mov esi, 0x00
00007e2c933e0ef5  mov rax, 0x5A263F1C7530
00007e2c933e0eff  call rax
00007e2c933e0f01  movaps xmm1, [rsp]
00007e2c933e0f05  add rsp, 0x30
00007e2c933e0f09  vmovaps xmm0, [rsp]
00007e2c933e0f0e  vmovaps xmm2, [rsp+0x10]
00007e2c933e0f14  vmovaps xmm3, [rsp+0x20]
00007e2c933e0f1a  vmovaps xmm4, [rsp+0x30]
00007e2c933e0f20  vmovaps xmm5, [rsp+0x40]
00007e2c933e0f26  vmovaps xmm6, [rsp+0x50]
00007e2c933e0f2c  vmovaps xmm7, [rsp+0x60]
00007e2c933e0f32  vmovaps xmm8, [rsp+0x70]
00007e2c933e0f38  vmovaps xmm9, [rsp+0x80]
00007e2c933e0f41  vmovaps xmm10, [rsp+0x90]
00007e2c933e0f4a  vmovaps xmm11, [rsp+0xA0]
00007e2c933e0f53  vmovaps xmm12, [rsp+0xB0]
00007e2c933e0f5c  vmovaps xmm13, [rsp+0xC0]
00007e2c933e0f65  vmovaps xmm14, [rsp+0xD0]
00007e2c933e0f6e  vmovaps xmm15, [rsp+0xE0]
00007e2c933e0f77  add rsp, 0xF0
00007e2c933e0f7e  pop r11
00007e2c933e0f80  pop r10
00007e2c933e0f82  pop r9
00007e2c933e0f84  pop r8
00007e2c933e0f86  pop rsi
00007e2c933e0f87  pop rdi
00007e2c933e0f88  pop rdx
00007e2c933e0f89  pop rcx
00007e2c933e0f8a  pop rax
00007e2c933e0f8b  add rsp, 0x08
00007e2c933e0f8f  jmp 0x00007E2C933DF15E
00007e2c933e0f94  call 0x00007E2C932C4620
00007e2c933e0f99  jmp 0x00007E2C933DF16B
00007e2c933e0f9e  sub rsp, 0x08
00007e2c933e0fa2  push rax
00007e2c933e0fa3  push rcx
00007e2c933e0fa4  push rdx
00007e2c933e0fa5  push rdi
00007e2c933e0fa6  push rsi
00007e2c933e0fa7  push r8
00007e2c933e0fa9  push r9
00007e2c933e0fab  push r10
00007e2c933e0fad  push r11
00007e2c933e0faf  sub rsp, 0xF0
00007e2c933e0fb6  vmovaps [rsp], xmm0
00007e2c933e0fbb  vmovaps [rsp+0x10], xmm2
00007e2c933e0fc1  vmovaps [rsp+0x20], xmm3
00007e2c933e0fc7  vmovaps [rsp+0x30], xmm4
00007e2c933e0fcd  vmovaps [rsp+0x40], xmm5
00007e2c933e0fd3  vmovaps [rsp+0x50], xmm6
00007e2c933e0fd9  vmovaps [rsp+0x60], xmm7
00007e2c933e0fdf  vmovaps [rsp+0x70], xmm8
00007e2c933e0fe5  vmovaps [rsp+0x80], xmm9
00007e2c933e0fee  vmovaps [rsp+0x90], xmm10
00007e2c933e0ff7  vmovaps [rsp+0xA0], xmm11
00007e2c933e1000  vmovaps [rsp+0xB0], xmm12
00007e2c933e1009  vmovaps [rsp+0xC0], xmm13
00007e2c933e1012  vmovaps [rsp+0xD0], xmm14
00007e2c933e101b  vmovaps [rsp+0xE0], xmm15
00007e2c933e1024  sub rsp, 0x30
00007e2c933e1028  movaps [rsp], xmm1
00007e2c933e102c  movaps [rsp+0x10], xmm5
00007e2c933e1031  movaps [rsp+0x20], xmm7
00007e2c933e1036  lea rdi, [rsp]
00007e2c933e103a  mov esi, 0x00
00007e2c933e103f  mov rax, 0x5A263F1C7530
00007e2c933e1049  call rax
00007e2c933e104b  movaps xmm1, [rsp]
00007e2c933e104f  add rsp, 0x30
00007e2c933e1053  vmovaps xmm0, [rsp]
00007e2c933e1058  vmovaps xmm2, [rsp+0x10]
00007e2c933e105e  vmovaps xmm3, [rsp+0x20]
00007e2c933e1064  vmovaps xmm4, [rsp+0x30]
00007e2c933e106a  vmovaps xmm5, [rsp+0x40]
00007e2c933e1070  vmovaps xmm6, [rsp+0x50]
00007e2c933e1076  vmovaps xmm7, [rsp+0x60]
00007e2c933e107c  vmovaps xmm8, [rsp+0x70]
00007e2c933e1082  vmovaps xmm9, [rsp+0x80]
00007e2c933e108b  vmovaps xmm10, [rsp+0x90]
00007e2c933e1094  vmovaps xmm11, [rsp+0xA0]
00007e2c933e109d  vmovaps xmm12, [rsp+0xB0]
00007e2c933e10a6  vmovaps xmm13, [rsp+0xC0]
00007e2c933e10af  vmovaps xmm14, [rsp+0xD0]
00007e2c933e10b8  vmovaps xmm15, [rsp+0xE0]
00007e2c933e10c1  add rsp, 0xF0
00007e2c933e10c8  pop r11
00007e2c933e10ca  pop r10
00007e2c933e10cc  pop r9
00007e2c933e10ce  pop r8
00007e2c933e10d0  pop rsi
00007e2c933e10d1  pop rdi
00007e2c933e10d2  pop rdx
00007e2c933e10d3  pop rcx
00007e2c933e10d4  pop rax
00007e2c933e10d5  add rsp, 0x08
00007e2c933e10d9  jmp 0x00007E2C933DF210
00007e2c933e10de  sub rsp, 0x08
00007e2c933e10e2  push rax
00007e2c933e10e3  push rcx
00007e2c933e10e4  push rdx
00007e2c933e10e5  push rdi
00007e2c933e10e6  push rsi
00007e2c933e10e7  push r8
00007e2c933e10e9  push r9
00007e2c933e10eb  push r10
00007e2c933e10ed  push r11
00007e2c933e10ef  sub rsp, 0xF0
00007e2c933e10f6  vmovaps [rsp], xmm0
00007e2c933e10fb  vmovaps [rsp+0x10], xmm1
00007e2c933e1101  vmovaps [rsp+0x20], xmm2
00007e2c933e1107  vmovaps [rsp+0x30], xmm3
00007e2c933e110d  vmovaps [rsp+0x40], xmm4
00007e2c933e1113  vmovaps [rsp+0x50], xmm5
00007e2c933e1119  vmovaps [rsp+0x60], xmm6
00007e2c933e111f  vmovaps [rsp+0x70], xmm8
00007e2c933e1125  vmovaps [rsp+0x80], xmm9
00007e2c933e112e  vmovaps [rsp+0x90], xmm10
00007e2c933e1137  vmovaps [rsp+0xA0], xmm11
00007e2c933e1140  vmovaps [rsp+0xB0], xmm12
00007e2c933e1149  vmovaps [rsp+0xC0], xmm13
00007e2c933e1152  vmovaps [rsp+0xD0], xmm14
00007e2c933e115b  vmovaps [rsp+0xE0], xmm15
00007e2c933e1164  sub rsp, 0x30
00007e2c933e1168  movaps [rsp], xmm7
00007e2c933e116c  movaps [rsp+0x10], xmm5
00007e2c933e1171  movaps [rsp+0x20], xmm15
00007e2c933e1177  lea rdi, [rsp]
00007e2c933e117b  mov esi, 0x00
00007e2c933e1180  mov rax, 0x5A263F1C7530
00007e2c933e118a  call rax
00007e2c933e118c  movaps xmm7, [rsp]
00007e2c933e1190  add rsp, 0x30
00007e2c933e1194  vmovaps xmm0, [rsp]
00007e2c933e1199  vmovaps xmm1, [rsp+0x10]
00007e2c933e119f  vmovaps xmm2, [rsp+0x20]
00007e2c933e11a5  vmovaps xmm3, [rsp+0x30]
00007e2c933e11ab  vmovaps xmm4, [rsp+0x40]
00007e2c933e11b1  vmovaps xmm5, [rsp+0x50]
00007e2c933e11b7  vmovaps xmm6, [rsp+0x60]
00007e2c933e11bd  vmovaps xmm8, [rsp+0x70]
00007e2c933e11c3  vmovaps xmm9, [rsp+0x80]
00007e2c933e11cc  vmovaps xmm10, [rsp+0x90]
00007e2c933e11d5  vmovaps xmm11, [rsp+0xA0]
00007e2c933e11de  vmovaps xmm12, [rsp+0xB0]
00007e2c933e11e7  vmovaps xmm13, [rsp+0xC0]
00007e2c933e11f0  vmovaps xmm14, [rsp+0xD0]
00007e2c933e11f9  vmovaps xmm15, [rsp+0xE0]
00007e2c933e1202  add rsp, 0xF0
00007e2c933e1209  pop r11
00007e2c933e120b  pop r10
00007e2c933e120d  pop r9
00007e2c933e120f  pop r8
00007e2c933e1211  pop rsi
00007e2c933e1212  pop rdi
00007e2c933e1213  pop rdx
00007e2c933e1214  pop rcx
00007e2c933e1215  pop rax
00007e2c933e1216  add rsp, 0x08
00007e2c933e121a  jmp 0x00007E2C933DF246
00007e2c933e121f  call 0x00007E2C932B52F0
00007e2c933e1224  jmp 0x00007E2C933DF253
00007e2c933e1229  sub rsp, 0x08
00007e2c933e122d  push rax
00007e2c933e122e  push rcx
00007e2c933e122f  push rdx
00007e2c933e1230  push rdi
00007e2c933e1231  push rsi
00007e2c933e1232  push r8
00007e2c933e1234  push r9
00007e2c933e1236  push r10
00007e2c933e1238  push r11
00007e2c933e123a  sub rsp, 0xF0
00007e2c933e1241  vmovaps [rsp], xmm0
00007e2c933e1246  vmovaps [rsp+0x10], xmm1
00007e2c933e124c  vmovaps [rsp+0x20], xmm2
00007e2c933e1252  vmovaps [rsp+0x30], xmm3
00007e2c933e1258  vmovaps [rsp+0x40], xmm4
00007e2c933e125e  vmovaps [rsp+0x50], xmm5
00007e2c933e1264  vmovaps [rsp+0x60], xmm6
00007e2c933e126a  vmovaps [rsp+0x70], xmm7
00007e2c933e1270  vmovaps [rsp+0x80], xmm8
00007e2c933e1279  vmovaps [rsp+0x90], xmm9
00007e2c933e1282  vmovaps [rsp+0xA0], xmm10
00007e2c933e128b  vmovaps [rsp+0xB0], xmm11
00007e2c933e1294  vmovaps [rsp+0xC0], xmm12
00007e2c933e129d  vmovaps [rsp+0xD0], xmm13
00007e2c933e12a6  vmovaps [rsp+0xE0], xmm14
00007e2c933e12af  sub rsp, 0x30
00007e2c933e12b3  movaps [rsp], xmm15
00007e2c933e12b8  movaps [rsp+0x10], xmm5
00007e2c933e12bd  movaps [rsp+0x20], xmm3
00007e2c933e12c2  lea rdi, [rsp]
00007e2c933e12c6  mov esi, 0x00
00007e2c933e12cb  mov rax, 0x5A263F1C7530
00007e2c933e12d5  call rax
00007e2c933e12d7  movaps xmm15, [rsp]
00007e2c933e12dc  add rsp, 0x30
00007e2c933e12e0  vmovaps xmm0, [rsp]
00007e2c933e12e5  vmovaps xmm1, [rsp+0x10]
00007e2c933e12eb  vmovaps xmm2, [rsp+0x20]
00007e2c933e12f1  vmovaps xmm3, [rsp+0x30]
00007e2c933e12f7  vmovaps xmm4, [rsp+0x40]
00007e2c933e12fd  vmovaps xmm5, [rsp+0x50]
00007e2c933e1303  vmovaps xmm6, [rsp+0x60]
00007e2c933e1309  vmovaps xmm7, [rsp+0x70]
00007e2c933e130f  vmovaps xmm8, [rsp+0x80]
00007e2c933e1318  vmovaps xmm9, [rsp+0x90]
00007e2c933e1321  vmovaps xmm10, [rsp+0xA0]
00007e2c933e132a  vmovaps xmm11, [rsp+0xB0]
00007e2c933e1333  vmovaps xmm12, [rsp+0xC0]
00007e2c933e133c  vmovaps xmm13, [rsp+0xD0]
00007e2c933e1345  vmovaps xmm14, [rsp+0xE0]
00007e2c933e134e  add rsp, 0xF0
00007e2c933e1355  pop r11
00007e2c933e1357  pop r10
00007e2c933e1359  pop r9
00007e2c933e135b  pop r8
00007e2c933e135d  pop rsi
00007e2c933e135e  pop rdi
00007e2c933e135f  pop rdx
00007e2c933e1360  pop rcx
00007e2c933e1361  pop rax
00007e2c933e1362  add rsp, 0x08
00007e2c933e1366  jmp 0x00007E2C933DF279
00007e2c933e136b  sub rsp, 0x08
00007e2c933e136f  push rax
00007e2c933e1370  push rcx
00007e2c933e1371  push rdx
00007e2c933e1372  push rdi
00007e2c933e1373  push rsi
00007e2c933e1374  push r8
00007e2c933e1376  push r9
00007e2c933e1378  push r10
00007e2c933e137a  push r11
00007e2c933e137c  sub rsp, 0xF0
00007e2c933e1383  vmovaps [rsp], xmm0
00007e2c933e1388  vmovaps [rsp+0x10], xmm2
00007e2c933e138e  vmovaps [rsp+0x20], xmm3
00007e2c933e1394  vmovaps [rsp+0x30], xmm4
00007e2c933e139a  vmovaps [rsp+0x40], xmm5
00007e2c933e13a0  vmovaps [rsp+0x50], xmm6
00007e2c933e13a6  vmovaps [rsp+0x60], xmm7
00007e2c933e13ac  vmovaps [rsp+0x70], xmm8
00007e2c933e13b2  vmovaps [rsp+0x80], xmm9
00007e2c933e13bb  vmovaps [rsp+0x90], xmm10
00007e2c933e13c4  vmovaps [rsp+0xA0], xmm11
00007e2c933e13cd  vmovaps [rsp+0xB0], xmm12
00007e2c933e13d6  vmovaps [rsp+0xC0], xmm13
00007e2c933e13df  vmovaps [rsp+0xD0], xmm14
00007e2c933e13e8  vmovaps [rsp+0xE0], xmm15
00007e2c933e13f1  sub rsp, 0x30
00007e2c933e13f5  movaps [rsp], xmm1
00007e2c933e13f9  movaps [rsp+0x10], xmm5
00007e2c933e13fe  movaps [rsp+0x20], xmm4
00007e2c933e1403  lea rdi, [rsp]
00007e2c933e1407  mov esi, 0x00
00007e2c933e140c  mov rax, 0x5A263F1C7530
00007e2c933e1416  call rax
00007e2c933e1418  movaps xmm1, [rsp]
00007e2c933e141c  add rsp, 0x30
00007e2c933e1420  vmovaps xmm0, [rsp]
00007e2c933e1425  vmovaps xmm2, [rsp+0x10]
00007e2c933e142b  vmovaps xmm3, [rsp+0x20]
00007e2c933e1431  vmovaps xmm4, [rsp+0x30]
00007e2c933e1437  vmovaps xmm5, [rsp+0x40]
00007e2c933e143d  vmovaps xmm6, [rsp+0x50]
00007e2c933e1443  vmovaps xmm7, [rsp+0x60]
00007e2c933e1449  vmovaps xmm8, [rsp+0x70]
00007e2c933e144f  vmovaps xmm9, [rsp+0x80]
00007e2c933e1458  vmovaps xmm10, [rsp+0x90]
00007e2c933e1461  vmovaps xmm11, [rsp+0xA0]
00007e2c933e146a  vmovaps xmm12, [rsp+0xB0]
00007e2c933e1473  vmovaps xmm13, [rsp+0xC0]
00007e2c933e147c  vmovaps xmm14, [rsp+0xD0]
00007e2c933e1485  vmovaps xmm15, [rsp+0xE0]
00007e2c933e148e  add rsp, 0xF0
00007e2c933e1495  pop r11
00007e2c933e1497  pop r10
00007e2c933e1499  pop r9
00007e2c933e149b  pop r8
00007e2c933e149d  pop rsi
00007e2c933e149e  pop rdi
00007e2c933e149f  pop rdx
00007e2c933e14a0  pop rcx
00007e2c933e14a1  pop rax
00007e2c933e14a2  add rsp, 0x08
00007e2c933e14a6  jmp 0x00007E2C933DF299
00007e2c933e14ab  sub rsp, 0x08
00007e2c933e14af  push rax
00007e2c933e14b0  push rcx
00007e2c933e14b1  push rdx
00007e2c933e14b2  push rdi
00007e2c933e14b3  push rsi
00007e2c933e14b4  push r8
00007e2c933e14b6  push r9
00007e2c933e14b8  push r10
00007e2c933e14ba  push r11
00007e2c933e14bc  sub rsp, 0xF0
00007e2c933e14c3  vmovaps [rsp], xmm0
00007e2c933e14c8  vmovaps [rsp+0x10], xmm1
00007e2c933e14ce  vmovaps [rsp+0x20], xmm2
00007e2c933e14d4  vmovaps [rsp+0x30], xmm3
00007e2c933e14da  vmovaps [rsp+0x40], xmm5
00007e2c933e14e0  vmovaps [rsp+0x50], xmm6
00007e2c933e14e6  vmovaps [rsp+0x60], xmm7
00007e2c933e14ec  vmovaps [rsp+0x70], xmm8
00007e2c933e14f2  vmovaps [rsp+0x80], xmm9
00007e2c933e14fb  vmovaps [rsp+0x90], xmm10
00007e2c933e1504  vmovaps [rsp+0xA0], xmm11
00007e2c933e150d  vmovaps [rsp+0xB0], xmm12
00007e2c933e1516  vmovaps [rsp+0xC0], xmm13
00007e2c933e151f  vmovaps [rsp+0xD0], xmm14
00007e2c933e1528  vmovaps [rsp+0xE0], xmm15
00007e2c933e1531  sub rsp, 0x30
00007e2c933e1535  movaps [rsp], xmm4
00007e2c933e1539  movaps [rsp+0x10], xmm3
00007e2c933e153e  movaps [rsp+0x20], xmm5
00007e2c933e1543  lea rdi, [rsp]
00007e2c933e1547  mov esi, 0x00
00007e2c933e154c  mov rax, 0x5A263F1C7530
00007e2c933e1556  call rax
00007e2c933e1558  movaps xmm4, [rsp]
00007e2c933e155c  add rsp, 0x30
00007e2c933e1560  vmovaps xmm0, [rsp]
00007e2c933e1565  vmovaps xmm1, [rsp+0x10]
00007e2c933e156b  vmovaps xmm2, [rsp+0x20]
00007e2c933e1571  vmovaps xmm3, [rsp+0x30]
00007e2c933e1577  vmovaps xmm5, [rsp+0x40]
00007e2c933e157d  vmovaps xmm6, [rsp+0x50]
00007e2c933e1583  vmovaps xmm7, [rsp+0x60]
00007e2c933e1589  vmovaps xmm8, [rsp+0x70]
00007e2c933e158f  vmovaps xmm9, [rsp+0x80]
00007e2c933e1598  vmovaps xmm10, [rsp+0x90]
00007e2c933e15a1  vmovaps xmm11, [rsp+0xA0]
00007e2c933e15aa  vmovaps xmm12, [rsp+0xB0]
00007e2c933e15b3  vmovaps xmm13, [rsp+0xC0]
00007e2c933e15bc  vmovaps xmm14, [rsp+0xD0]
00007e2c933e15c5  vmovaps xmm15, [rsp+0xE0]
00007e2c933e15ce  add rsp, 0xF0
00007e2c933e15d5  pop r11
00007e2c933e15d7  pop r10
00007e2c933e15d9  pop r9
00007e2c933e15db  pop r8
00007e2c933e15dd  pop rsi
00007e2c933e15de  pop rdi
00007e2c933e15df  pop rdx
00007e2c933e15e0  pop rcx
00007e2c933e15e1  pop rax
00007e2c933e15e2  add rsp, 0x08
00007e2c933e15e6  jmp 0x00007E2C933DF2E7
00007e2c933e15eb  call 0x00007E2C932B52F0
00007e2c933e15f0  jmp 0x00007E2C933DF2F4
00007e2c933e15f5  sub rsp, 0x08
00007e2c933e15f9  push rax
00007e2c933e15fa  push rcx
00007e2c933e15fb  push rdx
00007e2c933e15fc  push rdi
00007e2c933e15fd  push rsi
00007e2c933e15fe  push r8
00007e2c933e1600  push r9
00007e2c933e1602  push r10
00007e2c933e1604  push r11
00007e2c933e1606  sub rsp, 0xF0
00007e2c933e160d  vmovaps [rsp], xmm0
00007e2c933e1612  vmovaps [rsp+0x10], xmm1
00007e2c933e1618  vmovaps [rsp+0x20], xmm2
00007e2c933e161e  vmovaps [rsp+0x30], xmm3
00007e2c933e1624  vmovaps [rsp+0x40], xmm4
00007e2c933e162a  vmovaps [rsp+0x50], xmm6
00007e2c933e1630  vmovaps [rsp+0x60], xmm7
00007e2c933e1636  vmovaps [rsp+0x70], xmm8
00007e2c933e163c  vmovaps [rsp+0x80], xmm9
00007e2c933e1645  vmovaps [rsp+0x90], xmm10
00007e2c933e164e  vmovaps [rsp+0xA0], xmm11
00007e2c933e1657  vmovaps [rsp+0xB0], xmm12
00007e2c933e1660  vmovaps [rsp+0xC0], xmm13
00007e2c933e1669  vmovaps [rsp+0xD0], xmm14
00007e2c933e1672  vmovaps [rsp+0xE0], xmm15
00007e2c933e167b  sub rsp, 0x30
00007e2c933e167f  movaps [rsp], xmm5
00007e2c933e1683  movaps [rsp+0x10], xmm6
00007e2c933e1688  movaps [rsp+0x20], xmm3
00007e2c933e168d  lea rdi, [rsp]
00007e2c933e1691  mov esi, 0x00
00007e2c933e1696  mov rax, 0x5A263F1C7530
00007e2c933e16a0  call rax
00007e2c933e16a2  movaps xmm5, [rsp]
00007e2c933e16a6  add rsp, 0x30
00007e2c933e16aa  vmovaps xmm0, [rsp]
00007e2c933e16af  vmovaps xmm1, [rsp+0x10]
00007e2c933e16b5  vmovaps xmm2, [rsp+0x20]
00007e2c933e16bb  vmovaps xmm3, [rsp+0x30]
00007e2c933e16c1  vmovaps xmm4, [rsp+0x40]
00007e2c933e16c7  vmovaps xmm6, [rsp+0x50]
00007e2c933e16cd  vmovaps xmm7, [rsp+0x60]
00007e2c933e16d3  vmovaps xmm8, [rsp+0x70]
00007e2c933e16d9  vmovaps xmm9, [rsp+0x80]
00007e2c933e16e2  vmovaps xmm10, [rsp+0x90]
00007e2c933e16eb  vmovaps xmm11, [rsp+0xA0]
00007e2c933e16f4  vmovaps xmm12, [rsp+0xB0]
00007e2c933e16fd  vmovaps xmm13, [rsp+0xC0]
00007e2c933e1706  vmovaps xmm14, [rsp+0xD0]
00007e2c933e170f  vmovaps xmm15, [rsp+0xE0]
00007e2c933e1718  add rsp, 0xF0
00007e2c933e171f  pop r11
00007e2c933e1721  pop r10
00007e2c933e1723  pop r9
00007e2c933e1725  pop r8
00007e2c933e1727  pop rsi
00007e2c933e1728  pop rdi
00007e2c933e1729  pop rdx
00007e2c933e172a  pop rcx
00007e2c933e172b  pop rax
00007e2c933e172c  add rsp, 0x08
00007e2c933e1730  jmp 0x00007E2C933DF31A
00007e2c933e1735  sub rsp, 0x08
00007e2c933e1739  push rax
00007e2c933e173a  push rcx
00007e2c933e173b  push rdx
00007e2c933e173c  push rdi
00007e2c933e173d  push rsi
00007e2c933e173e  push r8
00007e2c933e1740  push r9
00007e2c933e1742  push r10
00007e2c933e1744  push r11
00007e2c933e1746  sub rsp, 0xF0
00007e2c933e174d  vmovaps [rsp], xmm0
00007e2c933e1752  vmovaps [rsp+0x10], xmm1
00007e2c933e1758  vmovaps [rsp+0x20], xmm2
00007e2c933e175e  vmovaps [rsp+0x30], xmm3
00007e2c933e1764  vmovaps [rsp+0x40], xmm4
00007e2c933e176a  vmovaps [rsp+0x50], xmm5
00007e2c933e1770  vmovaps [rsp+0x60], xmm7
00007e2c933e1776  vmovaps [rsp+0x70], xmm8
00007e2c933e177c  vmovaps [rsp+0x80], xmm9
00007e2c933e1785  vmovaps [rsp+0x90], xmm10
00007e2c933e178e  vmovaps [rsp+0xA0], xmm11
00007e2c933e1797  vmovaps [rsp+0xB0], xmm12
00007e2c933e17a0  vmovaps [rsp+0xC0], xmm13
00007e2c933e17a9  vmovaps [rsp+0xD0], xmm14
00007e2c933e17b2  vmovaps [rsp+0xE0], xmm15
00007e2c933e17bb  sub rsp, 0x30
00007e2c933e17bf  movaps [rsp], xmm6
00007e2c933e17c3  movaps [rsp+0x10], xmm9
00007e2c933e17c9  movaps [rsp+0x20], xmm1
00007e2c933e17ce  lea rdi, [rsp]
00007e2c933e17d2  mov esi, 0x00
00007e2c933e17d7  mov rax, 0x5A263F1C7530
00007e2c933e17e1  call rax
00007e2c933e17e3  movaps xmm6, [rsp]
00007e2c933e17e7  add rsp, 0x30
00007e2c933e17eb  vmovaps xmm0, [rsp]
00007e2c933e17f0  vmovaps xmm1, [rsp+0x10]
00007e2c933e17f6  vmovaps xmm2, [rsp+0x20]
00007e2c933e17fc  vmovaps xmm3, [rsp+0x30]
00007e2c933e1802  vmovaps xmm4, [rsp+0x40]
00007e2c933e1808  vmovaps xmm5, [rsp+0x50]
00007e2c933e180e  vmovaps xmm7, [rsp+0x60]
00007e2c933e1814  vmovaps xmm8, [rsp+0x70]
00007e2c933e181a  vmovaps xmm9, [rsp+0x80]
00007e2c933e1823  vmovaps xmm10, [rsp+0x90]
00007e2c933e182c  vmovaps xmm11, [rsp+0xA0]
00007e2c933e1835  vmovaps xmm12, [rsp+0xB0]
00007e2c933e183e  vmovaps xmm13, [rsp+0xC0]
00007e2c933e1847  vmovaps xmm14, [rsp+0xD0]
00007e2c933e1850  vmovaps xmm15, [rsp+0xE0]
00007e2c933e1859  add rsp, 0xF0
00007e2c933e1860  pop r11
00007e2c933e1862  pop r10
00007e2c933e1864  pop r9
00007e2c933e1866  pop r8
00007e2c933e1868  pop rsi
00007e2c933e1869  pop rdi
00007e2c933e186a  pop rdx
00007e2c933e186b  pop rcx
00007e2c933e186c  pop rax
00007e2c933e186d  add rsp, 0x08
00007e2c933e1871  jmp 0x00007E2C933DF33E
00007e2c933e1876  sub rsp, 0x08
00007e2c933e187a  push rax
00007e2c933e187b  push rcx
00007e2c933e187c  push rdx
00007e2c933e187d  push rdi
00007e2c933e187e  push rsi
00007e2c933e187f  push r8
00007e2c933e1881  push r9
00007e2c933e1883  push r10
00007e2c933e1885  push r11
00007e2c933e1887  sub rsp, 0xF0
00007e2c933e188e  vmovaps [rsp], xmm0
00007e2c933e1893  vmovaps [rsp+0x10], xmm1
00007e2c933e1899  vmovaps [rsp+0x20], xmm2
00007e2c933e189f  vmovaps [rsp+0x30], xmm3
00007e2c933e18a5  vmovaps [rsp+0x40], xmm4
00007e2c933e18ab  vmovaps [rsp+0x50], xmm5
00007e2c933e18b1  vmovaps [rsp+0x60], xmm6
00007e2c933e18b7  vmovaps [rsp+0x70], xmm7
00007e2c933e18bd  vmovaps [rsp+0x80], xmm8
00007e2c933e18c6  vmovaps [rsp+0x90], xmm10
00007e2c933e18cf  vmovaps [rsp+0xA0], xmm11
00007e2c933e18d8  vmovaps [rsp+0xB0], xmm12
00007e2c933e18e1  vmovaps [rsp+0xC0], xmm13
00007e2c933e18ea  vmovaps [rsp+0xD0], xmm14
00007e2c933e18f3  vmovaps [rsp+0xE0], xmm15
00007e2c933e18fc  sub rsp, 0x30
00007e2c933e1900  movaps [rsp], xmm9
00007e2c933e1905  movaps [rsp+0x10], xmm3
00007e2c933e190a  movaps [rsp+0x20], xmm1
00007e2c933e190f  lea rdi, [rsp]
00007e2c933e1913  mov esi, 0x00
00007e2c933e1918  mov rax, 0x5A263F1C7530
00007e2c933e1922  call rax
00007e2c933e1924  movaps xmm9, [rsp]
00007e2c933e1929  add rsp, 0x30
00007e2c933e192d  vmovaps xmm0, [rsp]
00007e2c933e1932  vmovaps xmm1, [rsp+0x10]
00007e2c933e1938  vmovaps xmm2, [rsp+0x20]
00007e2c933e193e  vmovaps xmm3, [rsp+0x30]
00007e2c933e1944  vmovaps xmm4, [rsp+0x40]
00007e2c933e194a  vmovaps xmm5, [rsp+0x50]
00007e2c933e1950  vmovaps xmm6, [rsp+0x60]
00007e2c933e1956  vmovaps xmm7, [rsp+0x70]
00007e2c933e195c  vmovaps xmm8, [rsp+0x80]
00007e2c933e1965  vmovaps xmm10, [rsp+0x90]
00007e2c933e196e  vmovaps xmm11, [rsp+0xA0]
00007e2c933e1977  vmovaps xmm12, [rsp+0xB0]
00007e2c933e1980  vmovaps xmm13, [rsp+0xC0]
00007e2c933e1989  vmovaps xmm14, [rsp+0xD0]
00007e2c933e1992  vmovaps xmm15, [rsp+0xE0]
00007e2c933e199b  add rsp, 0xF0
00007e2c933e19a2  pop r11
00007e2c933e19a4  pop r10
00007e2c933e19a6  pop r9
00007e2c933e19a8  pop r8
00007e2c933e19aa  pop rsi
00007e2c933e19ab  pop rdi
00007e2c933e19ac  pop rdx
00007e2c933e19ad  pop rcx
00007e2c933e19ae  pop rax
00007e2c933e19af  add rsp, 0x08
00007e2c933e19b3  jmp 0x00007E2C933DF38A
00007e2c933e19b8  call 0x00007E2C932B52F0
00007e2c933e19bd  jmp 0x00007E2C933DF397
00007e2c933e19c2  sub rsp, 0x08
00007e2c933e19c6  push rax
00007e2c933e19c7  push rcx
00007e2c933e19c8  push rdx
00007e2c933e19c9  push rdi
00007e2c933e19ca  push rsi
00007e2c933e19cb  push r8
00007e2c933e19cd  push r9
00007e2c933e19cf  push r10
00007e2c933e19d1  push r11
00007e2c933e19d3  sub rsp, 0xF0
00007e2c933e19da  vmovaps [rsp], xmm0
00007e2c933e19df  vmovaps [rsp+0x10], xmm1
00007e2c933e19e5  vmovaps [rsp+0x20], xmm2
00007e2c933e19eb  vmovaps [rsp+0x30], xmm3
00007e2c933e19f1  vmovaps [rsp+0x40], xmm4
00007e2c933e19f7  vmovaps [rsp+0x50], xmm5
00007e2c933e19fd  vmovaps [rsp+0x60], xmm6
00007e2c933e1a03  vmovaps [rsp+0x70], xmm7
00007e2c933e1a09  vmovaps [rsp+0x80], xmm8
00007e2c933e1a12  vmovaps [rsp+0x90], xmm9
00007e2c933e1a1b  vmovaps [rsp+0xA0], xmm10
00007e2c933e1a24  vmovaps [rsp+0xB0], xmm11
00007e2c933e1a2d  vmovaps [rsp+0xC0], xmm12
00007e2c933e1a36  vmovaps [rsp+0xD0], xmm13
00007e2c933e1a3f  vmovaps [rsp+0xE0], xmm14
00007e2c933e1a48  sub rsp, 0x30
00007e2c933e1a4c  movaps [rsp], xmm15
00007e2c933e1a51  movaps [rsp+0x10], xmm3
00007e2c933e1a56  movaps [rsp+0x20], xmm7
00007e2c933e1a5b  lea rdi, [rsp]
00007e2c933e1a5f  mov esi, 0x00
00007e2c933e1a64  mov rax, 0x5A263F1C7530
00007e2c933e1a6e  call rax
00007e2c933e1a70  movaps xmm15, [rsp]
00007e2c933e1a75  add rsp, 0x30
00007e2c933e1a79  vmovaps xmm0, [rsp]
00007e2c933e1a7e  vmovaps xmm1, [rsp+0x10]
00007e2c933e1a84  vmovaps xmm2, [rsp+0x20]
00007e2c933e1a8a  vmovaps xmm3, [rsp+0x30]
00007e2c933e1a90  vmovaps xmm4, [rsp+0x40]
00007e2c933e1a96  vmovaps xmm5, [rsp+0x50]
00007e2c933e1a9c  vmovaps xmm6, [rsp+0x60]
00007e2c933e1aa2  vmovaps xmm7, [rsp+0x70]
00007e2c933e1aa8  vmovaps xmm8, [rsp+0x80]
00007e2c933e1ab1  vmovaps xmm9, [rsp+0x90]
00007e2c933e1aba  vmovaps xmm10, [rsp+0xA0]
00007e2c933e1ac3  vmovaps xmm11, [rsp+0xB0]
00007e2c933e1acc  vmovaps xmm12, [rsp+0xC0]
00007e2c933e1ad5  vmovaps xmm13, [rsp+0xD0]
00007e2c933e1ade  vmovaps xmm14, [rsp+0xE0]
00007e2c933e1ae7  add rsp, 0xF0
00007e2c933e1aee  pop r11
00007e2c933e1af0  pop r10
00007e2c933e1af2  pop r9
00007e2c933e1af4  pop r8
00007e2c933e1af6  pop rsi
00007e2c933e1af7  pop rdi
00007e2c933e1af8  pop rdx
00007e2c933e1af9  pop rcx
00007e2c933e1afa  pop rax
00007e2c933e1afb  add rsp, 0x08
00007e2c933e1aff  jmp 0x00007E2C933DF3C3
00007e2c933e1b04  sub rsp, 0x08
00007e2c933e1b08  push rax
00007e2c933e1b09  push rcx
00007e2c933e1b0a  push rdx
00007e2c933e1b0b  push rdi
00007e2c933e1b0c  push rsi
00007e2c933e1b0d  push r8
00007e2c933e1b0f  push r9
00007e2c933e1b11  push r10
00007e2c933e1b13  push r11
00007e2c933e1b15  sub rsp, 0xF0
00007e2c933e1b1c  vmovaps [rsp], xmm0
00007e2c933e1b21  vmovaps [rsp+0x10], xmm1
00007e2c933e1b27  vmovaps [rsp+0x20], xmm2
00007e2c933e1b2d  vmovaps [rsp+0x30], xmm4
00007e2c933e1b33  vmovaps [rsp+0x40], xmm5
00007e2c933e1b39  vmovaps [rsp+0x50], xmm6
00007e2c933e1b3f  vmovaps [rsp+0x60], xmm7
00007e2c933e1b45  vmovaps [rsp+0x70], xmm8
00007e2c933e1b4b  vmovaps [rsp+0x80], xmm9
00007e2c933e1b54  vmovaps [rsp+0x90], xmm10
00007e2c933e1b5d  vmovaps [rsp+0xA0], xmm11
00007e2c933e1b66  vmovaps [rsp+0xB0], xmm12
00007e2c933e1b6f  vmovaps [rsp+0xC0], xmm13
00007e2c933e1b78  vmovaps [rsp+0xD0], xmm14
00007e2c933e1b81  vmovaps [rsp+0xE0], xmm15
00007e2c933e1b8a  sub rsp, 0x30
00007e2c933e1b8e  movaps [rsp], xmm3
00007e2c933e1b92  movaps [rsp+0x10], xmm1
00007e2c933e1b97  movaps [rsp+0x20], xmm15
00007e2c933e1b9d  lea rdi, [rsp]
00007e2c933e1ba1  mov esi, 0x00
00007e2c933e1ba6  mov rax, 0x5A263F1C7530
00007e2c933e1bb0  call rax
00007e2c933e1bb2  movaps xmm3, [rsp]
00007e2c933e1bb6  add rsp, 0x30
00007e2c933e1bba  vmovaps xmm0, [rsp]
00007e2c933e1bbf  vmovaps xmm1, [rsp+0x10]
00007e2c933e1bc5  vmovaps xmm2, [rsp+0x20]
00007e2c933e1bcb  vmovaps xmm4, [rsp+0x30]
00007e2c933e1bd1  vmovaps xmm5, [rsp+0x40]
00007e2c933e1bd7  vmovaps xmm6, [rsp+0x50]
00007e2c933e1bdd  vmovaps xmm7, [rsp+0x60]
00007e2c933e1be3  vmovaps xmm8, [rsp+0x70]
00007e2c933e1be9  vmovaps xmm9, [rsp+0x80]
00007e2c933e1bf2  vmovaps xmm10, [rsp+0x90]
00007e2c933e1bfb  vmovaps xmm11, [rsp+0xA0]
00007e2c933e1c04  vmovaps xmm12, [rsp+0xB0]
00007e2c933e1c0d  vmovaps xmm13, [rsp+0xC0]
00007e2c933e1c16  vmovaps xmm14, [rsp+0xD0]
00007e2c933e1c1f  vmovaps xmm15, [rsp+0xE0]
00007e2c933e1c28  add rsp, 0xF0
00007e2c933e1c2f  pop r11
00007e2c933e1c31  pop r10
00007e2c933e1c33  pop r9
00007e2c933e1c35  pop r8
00007e2c933e1c37  pop rsi
00007e2c933e1c38  pop rdi
00007e2c933e1c39  pop rdx
00007e2c933e1c3a  pop rcx
00007e2c933e1c3b  pop rax
00007e2c933e1c3c  add rsp, 0x08
00007e2c933e1c40  jmp 0x00007E2C933DF452
00007e2c933e1c45  call 0x00007E2C932B52F0
00007e2c933e1c4a  jmp 0x00007E2C933DF45C
00007e2c933e1c4f  sub rsp, 0x08
00007e2c933e1c53  push rax
00007e2c933e1c54  push rcx
00007e2c933e1c55  push rdx
00007e2c933e1c56  push rdi
00007e2c933e1c57  push rsi
00007e2c933e1c58  push r8
00007e2c933e1c5a  push r9
00007e2c933e1c5c  push r10
00007e2c933e1c5e  push r11
00007e2c933e1c60  sub rsp, 0xF0
00007e2c933e1c67  vmovaps [rsp], xmm0
00007e2c933e1c6c  vmovaps [rsp+0x10], xmm1
00007e2c933e1c72  vmovaps [rsp+0x20], xmm2
00007e2c933e1c78  vmovaps [rsp+0x30], xmm3
00007e2c933e1c7e  vmovaps [rsp+0x40], xmm4
00007e2c933e1c84  vmovaps [rsp+0x50], xmm5
00007e2c933e1c8a  vmovaps [rsp+0x60], xmm6
00007e2c933e1c90  vmovaps [rsp+0x70], xmm7
00007e2c933e1c96  vmovaps [rsp+0x80], xmm8
00007e2c933e1c9f  vmovaps [rsp+0x90], xmm9
00007e2c933e1ca8  vmovaps [rsp+0xA0], xmm10
00007e2c933e1cb1  vmovaps [rsp+0xB0], xmm11
00007e2c933e1cba  vmovaps [rsp+0xC0], xmm12
00007e2c933e1cc3  vmovaps [rsp+0xD0], xmm13
00007e2c933e1ccc  vmovaps [rsp+0xE0], xmm14
00007e2c933e1cd5  sub rsp, 0x30
00007e2c933e1cd9  movaps [rsp], xmm15
00007e2c933e1cde  movaps [rsp+0x10], xmm14
00007e2c933e1ce4  movaps [rsp+0x20], xmm4
00007e2c933e1ce9  lea rdi, [rsp]
00007e2c933e1ced  mov esi, 0x00
00007e2c933e1cf2  mov rax, 0x5A263F1C7530
00007e2c933e1cfc  call rax
00007e2c933e1cfe  movaps xmm15, [rsp]
00007e2c933e1d03  add rsp, 0x30
00007e2c933e1d07  vmovaps xmm0, [rsp]
00007e2c933e1d0c  vmovaps xmm1, [rsp+0x10]
00007e2c933e1d12  vmovaps xmm2, [rsp+0x20]
00007e2c933e1d18  vmovaps xmm3, [rsp+0x30]
00007e2c933e1d1e  vmovaps xmm4, [rsp+0x40]
00007e2c933e1d24  vmovaps xmm5, [rsp+0x50]
00007e2c933e1d2a  vmovaps xmm6, [rsp+0x60]
00007e2c933e1d30  vmovaps xmm7, [rsp+0x70]
00007e2c933e1d36  vmovaps xmm8, [rsp+0x80]
00007e2c933e1d3f  vmovaps xmm9, [rsp+0x90]
00007e2c933e1d48  vmovaps xmm10, [rsp+0xA0]
00007e2c933e1d51  vmovaps xmm11, [rsp+0xB0]
00007e2c933e1d5a  vmovaps xmm12, [rsp+0xC0]
00007e2c933e1d63  vmovaps xmm13, [rsp+0xD0]
00007e2c933e1d6c  vmovaps xmm14, [rsp+0xE0]
00007e2c933e1d75  add rsp, 0xF0
00007e2c933e1d7c  pop r11
00007e2c933e1d7e  pop r10
00007e2c933e1d80  pop r9
00007e2c933e1d82  pop r8
00007e2c933e1d84  pop rsi
00007e2c933e1d85  pop rdi
00007e2c933e1d86  pop rdx
00007e2c933e1d87  pop rcx
00007e2c933e1d88  pop rax
00007e2c933e1d89  add rsp, 0x08
00007e2c933e1d8d  jmp 0x00007E2C933DF48A
00007e2c933e1d92  sub rsp, 0x08
00007e2c933e1d96  push rax
00007e2c933e1d97  push rcx
00007e2c933e1d98  push rdx
00007e2c933e1d99  push rdi
00007e2c933e1d9a  push rsi
00007e2c933e1d9b  push r8
00007e2c933e1d9d  push r9
00007e2c933e1d9f  push r10
00007e2c933e1da1  push r11
00007e2c933e1da3  sub rsp, 0xF0
00007e2c933e1daa  vmovaps [rsp], xmm0
00007e2c933e1daf  vmovaps [rsp+0x10], xmm1
00007e2c933e1db5  vmovaps [rsp+0x20], xmm2
00007e2c933e1dbb  vmovaps [rsp+0x30], xmm3
00007e2c933e1dc1  vmovaps [rsp+0x40], xmm4
00007e2c933e1dc7  vmovaps [rsp+0x50], xmm5
00007e2c933e1dcd  vmovaps [rsp+0x60], xmm6
00007e2c933e1dd3  vmovaps [rsp+0x70], xmm7
00007e2c933e1dd9  vmovaps [rsp+0x80], xmm8
00007e2c933e1de2  vmovaps [rsp+0x90], xmm9
00007e2c933e1deb  vmovaps [rsp+0xA0], xmm10
00007e2c933e1df4  vmovaps [rsp+0xB0], xmm11
00007e2c933e1dfd  vmovaps [rsp+0xC0], xmm12
00007e2c933e1e06  vmovaps [rsp+0xD0], xmm13
00007e2c933e1e0f  vmovaps [rsp+0xE0], xmm15
00007e2c933e1e18  sub rsp, 0x30
00007e2c933e1e1c  movaps [rsp], xmm14
00007e2c933e1e21  movaps [rsp+0x10], xmm2
00007e2c933e1e26  movaps [rsp+0x20], xmm1
00007e2c933e1e2b  lea rdi, [rsp]
00007e2c933e1e2f  mov esi, 0x00
00007e2c933e1e34  mov rax, 0x5A263F1C7530
00007e2c933e1e3e  call rax
00007e2c933e1e40  movaps xmm14, [rsp]
00007e2c933e1e45  add rsp, 0x30
00007e2c933e1e49  vmovaps xmm0, [rsp]
00007e2c933e1e4e  vmovaps xmm1, [rsp+0x10]
00007e2c933e1e54  vmovaps xmm2, [rsp+0x20]
00007e2c933e1e5a  vmovaps xmm3, [rsp+0x30]
00007e2c933e1e60  vmovaps xmm4, [rsp+0x40]
00007e2c933e1e66  vmovaps xmm5, [rsp+0x50]
00007e2c933e1e6c  vmovaps xmm6, [rsp+0x60]
00007e2c933e1e72  vmovaps xmm7, [rsp+0x70]
00007e2c933e1e78  vmovaps xmm8, [rsp+0x80]
00007e2c933e1e81  vmovaps xmm9, [rsp+0x90]
00007e2c933e1e8a  vmovaps xmm10, [rsp+0xA0]
00007e2c933e1e93  vmovaps xmm11, [rsp+0xB0]
00007e2c933e1e9c  vmovaps xmm12, [rsp+0xC0]
00007e2c933e1ea5  vmovaps xmm13, [rsp+0xD0]
00007e2c933e1eae  vmovaps xmm15, [rsp+0xE0]
00007e2c933e1eb7  add rsp, 0xF0
00007e2c933e1ebe  pop r11
00007e2c933e1ec0  pop r10
00007e2c933e1ec2  pop r9
00007e2c933e1ec4  pop r8
00007e2c933e1ec6  pop rsi
00007e2c933e1ec7  pop rdi
00007e2c933e1ec8  pop rdx
00007e2c933e1ec9  pop rcx
00007e2c933e1eca  pop rax
00007e2c933e1ecb  add rsp, 0x08
00007e2c933e1ecf  jmp 0x00007E2C933DF4B0
00007e2c933e1ed4  sub rsp, 0x08
00007e2c933e1ed8  push rax
00007e2c933e1ed9  push rcx
00007e2c933e1eda  push rdx
00007e2c933e1edb  push rdi
00007e2c933e1edc  push rsi
00007e2c933e1edd  push r8
00007e2c933e1edf  push r9
00007e2c933e1ee1  push r10
00007e2c933e1ee3  push r11
00007e2c933e1ee5  sub rsp, 0xF0
00007e2c933e1eec  vmovaps [rsp], xmm0
00007e2c933e1ef1  vmovaps [rsp+0x10], xmm2
00007e2c933e1ef7  vmovaps [rsp+0x20], xmm3
00007e2c933e1efd  vmovaps [rsp+0x30], xmm4
00007e2c933e1f03  vmovaps [rsp+0x40], xmm5
00007e2c933e1f09  vmovaps [rsp+0x50], xmm6
00007e2c933e1f0f  vmovaps [rsp+0x60], xmm7
00007e2c933e1f15  vmovaps [rsp+0x70], xmm8
00007e2c933e1f1b  vmovaps [rsp+0x80], xmm9
00007e2c933e1f24  vmovaps [rsp+0x90], xmm10
00007e2c933e1f2d  vmovaps [rsp+0xA0], xmm11
00007e2c933e1f36  vmovaps [rsp+0xB0], xmm12
00007e2c933e1f3f  vmovaps [rsp+0xC0], xmm13
00007e2c933e1f48  vmovaps [rsp+0xD0], xmm14
00007e2c933e1f51  vmovaps [rsp+0xE0], xmm15
00007e2c933e1f5a  sub rsp, 0x30
00007e2c933e1f5e  movaps [rsp], xmm1
00007e2c933e1f62  movaps [rsp+0x10], xmm4
00007e2c933e1f67  movaps [rsp+0x20], xmm9
00007e2c933e1f6d  lea rdi, [rsp]
00007e2c933e1f71  mov esi, 0x00
00007e2c933e1f76  mov rax, 0x5A263F1C7530
00007e2c933e1f80  call rax
00007e2c933e1f82  movaps xmm1, [rsp]
00007e2c933e1f86  add rsp, 0x30
00007e2c933e1f8a  vmovaps xmm0, [rsp]
00007e2c933e1f8f  vmovaps xmm2, [rsp+0x10]
00007e2c933e1f95  vmovaps xmm3, [rsp+0x20]
00007e2c933e1f9b  vmovaps xmm4, [rsp+0x30]
00007e2c933e1fa1  vmovaps xmm5, [rsp+0x40]
00007e2c933e1fa7  vmovaps xmm6, [rsp+0x50]
00007e2c933e1fad  vmovaps xmm7, [rsp+0x60]
00007e2c933e1fb3  vmovaps xmm8, [rsp+0x70]
00007e2c933e1fb9  vmovaps xmm9, [rsp+0x80]
00007e2c933e1fc2  vmovaps xmm10, [rsp+0x90]
00007e2c933e1fcb  vmovaps xmm11, [rsp+0xA0]
00007e2c933e1fd4  vmovaps xmm12, [rsp+0xB0]
00007e2c933e1fdd  vmovaps xmm13, [rsp+0xC0]
00007e2c933e1fe6  vmovaps xmm14, [rsp+0xD0]
00007e2c933e1fef  vmovaps xmm15, [rsp+0xE0]
00007e2c933e1ff8  add rsp, 0xF0
00007e2c933e1fff  pop r11
00007e2c933e2001  pop r10
00007e2c933e2003  pop r9
00007e2c933e2005  pop r8
00007e2c933e2007  pop rsi
00007e2c933e2008  pop rdi
00007e2c933e2009  pop rdx
00007e2c933e200a  pop rcx
00007e2c933e200b  pop rax
00007e2c933e200c  add rsp, 0x08
00007e2c933e2010  jmp 0x00007E2C933DF4CE
00007e2c933e2015  sub rsp, 0x08
00007e2c933e2019  push rax
00007e2c933e201a  push rcx
00007e2c933e201b  push rdx
00007e2c933e201c  push rdi
00007e2c933e201d  push rsi
00007e2c933e201e  push r8
00007e2c933e2020  push r9
00007e2c933e2022  push r10
00007e2c933e2024  push r11
00007e2c933e2026  sub rsp, 0xF0
00007e2c933e202d  vmovaps [rsp], xmm0
00007e2c933e2032  vmovaps [rsp+0x10], xmm1
00007e2c933e2038  vmovaps [rsp+0x20], xmm2
00007e2c933e203e  vmovaps [rsp+0x30], xmm3
00007e2c933e2044  vmovaps [rsp+0x40], xmm5
00007e2c933e204a  vmovaps [rsp+0x50], xmm6
00007e2c933e2050  vmovaps [rsp+0x60], xmm7
00007e2c933e2056  vmovaps [rsp+0x70], xmm8
00007e2c933e205c  vmovaps [rsp+0x80], xmm9
00007e2c933e2065  vmovaps [rsp+0x90], xmm10
00007e2c933e206e  vmovaps [rsp+0xA0], xmm11
00007e2c933e2077  vmovaps [rsp+0xB0], xmm12
00007e2c933e2080  vmovaps [rsp+0xC0], xmm13
00007e2c933e2089  vmovaps [rsp+0xD0], xmm14
00007e2c933e2092  vmovaps [rsp+0xE0], xmm15
00007e2c933e209b  sub rsp, 0x30
00007e2c933e209f  movaps [rsp], xmm4
00007e2c933e20a3  movaps [rsp+0x10], xmm2
00007e2c933e20a8  movaps [rsp+0x20], xmm9
00007e2c933e20ae  lea rdi, [rsp]
00007e2c933e20b2  mov esi, 0x00
00007e2c933e20b7  mov rax, 0x5A263F1C7530
00007e2c933e20c1  call rax
00007e2c933e20c3  movaps xmm4, [rsp]
00007e2c933e20c7  add rsp, 0x30
00007e2c933e20cb  vmovaps xmm0, [rsp]
00007e2c933e20d0  vmovaps xmm1, [rsp+0x10]
00007e2c933e20d6  vmovaps xmm2, [rsp+0x20]
00007e2c933e20dc  vmovaps xmm3, [rsp+0x30]
00007e2c933e20e2  vmovaps xmm5, [rsp+0x40]
00007e2c933e20e8  vmovaps xmm6, [rsp+0x50]
00007e2c933e20ee  vmovaps xmm7, [rsp+0x60]
00007e2c933e20f4  vmovaps xmm8, [rsp+0x70]
00007e2c933e20fa  vmovaps xmm9, [rsp+0x80]
00007e2c933e2103  vmovaps xmm10, [rsp+0x90]
00007e2c933e210c  vmovaps xmm11, [rsp+0xA0]
00007e2c933e2115  vmovaps xmm12, [rsp+0xB0]
00007e2c933e211e  vmovaps xmm13, [rsp+0xC0]
00007e2c933e2127  vmovaps xmm14, [rsp+0xD0]
00007e2c933e2130  vmovaps xmm15, [rsp+0xE0]
00007e2c933e2139  add rsp, 0xF0
00007e2c933e2140  pop r11
00007e2c933e2142  pop r10
00007e2c933e2144  pop r9
00007e2c933e2146  pop r8
00007e2c933e2148  pop rsi
00007e2c933e2149  pop rdi
00007e2c933e214a  pop rdx
00007e2c933e214b  pop rcx
00007e2c933e214c  pop rax
00007e2c933e214d  add rsp, 0x08
00007e2c933e2151  jmp 0x00007E2C933DF4FE
00007e2c933e2156  sub rsp, 0x08
00007e2c933e215a  push rax
00007e2c933e215b  push rcx
00007e2c933e215c  push rdx
00007e2c933e215d  push rdi
00007e2c933e215e  push rsi
00007e2c933e215f  push r8
00007e2c933e2161  push r9
00007e2c933e2163  push r10
00007e2c933e2165  push r11
00007e2c933e2167  sub rsp, 0xF0
00007e2c933e216e  vmovaps [rsp], xmm0
00007e2c933e2173  vmovaps [rsp+0x10], xmm1
00007e2c933e2179  vmovaps [rsp+0x20], xmm2
00007e2c933e217f  vmovaps [rsp+0x30], xmm3
00007e2c933e2185  vmovaps [rsp+0x40], xmm4
00007e2c933e218b  vmovaps [rsp+0x50], xmm5
00007e2c933e2191  vmovaps [rsp+0x60], xmm6
00007e2c933e2197  vmovaps [rsp+0x70], xmm7
00007e2c933e219d  vmovaps [rsp+0x80], xmm8
00007e2c933e21a6  vmovaps [rsp+0x90], xmm10
00007e2c933e21af  vmovaps [rsp+0xA0], xmm11
00007e2c933e21b8  vmovaps [rsp+0xB0], xmm12
00007e2c933e21c1  vmovaps [rsp+0xC0], xmm13
00007e2c933e21ca  vmovaps [rsp+0xD0], xmm14
00007e2c933e21d3  vmovaps [rsp+0xE0], xmm15
00007e2c933e21dc  sub rsp, 0x30
00007e2c933e21e0  movaps [rsp], xmm9
00007e2c933e21e5  movaps [rsp+0x10], xmm2
00007e2c933e21ea  movaps [rsp+0x20], xmm1
00007e2c933e21ef  lea rdi, [rsp]
00007e2c933e21f3  mov esi, 0x00
00007e2c933e21f8  mov rax, 0x5A263F1C7530
00007e2c933e2202  call rax
00007e2c933e2204  movaps xmm9, [rsp]
00007e2c933e2209  add rsp, 0x30
00007e2c933e220d  vmovaps xmm0, [rsp]
00007e2c933e2212  vmovaps xmm1, [rsp+0x10]
00007e2c933e2218  vmovaps xmm2, [rsp+0x20]
00007e2c933e221e  vmovaps xmm3, [rsp+0x30]
00007e2c933e2224  vmovaps xmm4, [rsp+0x40]
00007e2c933e222a  vmovaps xmm5, [rsp+0x50]
00007e2c933e2230  vmovaps xmm6, [rsp+0x60]
00007e2c933e2236  vmovaps xmm7, [rsp+0x70]
00007e2c933e223c  vmovaps xmm8, [rsp+0x80]
00007e2c933e2245  vmovaps xmm10, [rsp+0x90]
00007e2c933e224e  vmovaps xmm11, [rsp+0xA0]
00007e2c933e2257  vmovaps xmm12, [rsp+0xB0]
00007e2c933e2260  vmovaps xmm13, [rsp+0xC0]
00007e2c933e2269  vmovaps xmm14, [rsp+0xD0]
00007e2c933e2272  vmovaps xmm15, [rsp+0xE0]
00007e2c933e227b  add rsp, 0xF0
00007e2c933e2282  pop r11
00007e2c933e2284  pop r10
00007e2c933e2286  pop r9
00007e2c933e2288  pop r8
00007e2c933e228a  pop rsi
00007e2c933e228b  pop rdi
00007e2c933e228c  pop rdx
00007e2c933e228d  pop rcx
00007e2c933e228e  pop rax
00007e2c933e228f  add rsp, 0x08
00007e2c933e2293  jmp 0x00007E2C933DF534
00007e2c933e2298  sub rsp, 0x08
00007e2c933e229c  push rax
00007e2c933e229d  push rcx
00007e2c933e229e  push rdx
00007e2c933e229f  push rdi
00007e2c933e22a0  push rsi
00007e2c933e22a1  push r8
00007e2c933e22a3  push r9
00007e2c933e22a5  push r10
00007e2c933e22a7  push r11
00007e2c933e22a9  sub rsp, 0xF0
00007e2c933e22b0  vmovaps [rsp], xmm0
00007e2c933e22b5  vmovaps [rsp+0x10], xmm2
00007e2c933e22bb  vmovaps [rsp+0x20], xmm3
00007e2c933e22c1  vmovaps [rsp+0x30], xmm4
00007e2c933e22c7  vmovaps [rsp+0x40], xmm5
00007e2c933e22cd  vmovaps [rsp+0x50], xmm6
00007e2c933e22d3  vmovaps [rsp+0x60], xmm7
00007e2c933e22d9  vmovaps [rsp+0x70], xmm8
00007e2c933e22df  vmovaps [rsp+0x80], xmm9
00007e2c933e22e8  vmovaps [rsp+0x90], xmm10
00007e2c933e22f1  vmovaps [rsp+0xA0], xmm11
00007e2c933e22fa  vmovaps [rsp+0xB0], xmm12
00007e2c933e2303  vmovaps [rsp+0xC0], xmm13
00007e2c933e230c  vmovaps [rsp+0xD0], xmm14
00007e2c933e2315  vmovaps [rsp+0xE0], xmm15
00007e2c933e231e  sub rsp, 0x30
00007e2c933e2322  movaps [rsp], xmm1
00007e2c933e2326  movaps [rsp+0x10], xmm15
00007e2c933e232c  movaps [rsp+0x20], xmm6
00007e2c933e2331  lea rdi, [rsp]
00007e2c933e2335  mov esi, 0x00
00007e2c933e233a  mov rax, 0x5A263F1C7530
00007e2c933e2344  call rax
00007e2c933e2346  movaps xmm1, [rsp]
00007e2c933e234a  add rsp, 0x30
00007e2c933e234e  vmovaps xmm0, [rsp]
00007e2c933e2353  vmovaps xmm2, [rsp+0x10]
00007e2c933e2359  vmovaps xmm3, [rsp+0x20]
00007e2c933e235f  vmovaps xmm4, [rsp+0x30]
00007e2c933e2365  vmovaps xmm5, [rsp+0x40]
00007e2c933e236b  vmovaps xmm6, [rsp+0x50]
00007e2c933e2371  vmovaps xmm7, [rsp+0x60]
00007e2c933e2377  vmovaps xmm8, [rsp+0x70]
00007e2c933e237d  vmovaps xmm9, [rsp+0x80]
00007e2c933e2386  vmovaps xmm10, [rsp+0x90]
00007e2c933e238f  vmovaps xmm11, [rsp+0xA0]
00007e2c933e2398  vmovaps xmm12, [rsp+0xB0]
00007e2c933e23a1  vmovaps xmm13, [rsp+0xC0]
00007e2c933e23aa  vmovaps xmm14, [rsp+0xD0]
00007e2c933e23b3  vmovaps xmm15, [rsp+0xE0]
00007e2c933e23bc  add rsp, 0xF0
00007e2c933e23c3  pop r11
00007e2c933e23c5  pop r10
00007e2c933e23c7  pop r9
00007e2c933e23c9  pop r8
00007e2c933e23cb  pop rsi
00007e2c933e23cc  pop rdi
00007e2c933e23cd  pop rdx
00007e2c933e23ce  pop rcx
00007e2c933e23cf  pop rax
00007e2c933e23d0  add rsp, 0x08
00007e2c933e23d4  jmp 0x00007E2C933DF555
00007e2c933e23d9  sub rsp, 0x08
00007e2c933e23dd  push rax
00007e2c933e23de  push rcx
00007e2c933e23df  push rdx
00007e2c933e23e0  push rdi
00007e2c933e23e1  push rsi
00007e2c933e23e2  push r8
00007e2c933e23e4  push r9
00007e2c933e23e6  push r10
00007e2c933e23e8  push r11
00007e2c933e23ea  sub rsp, 0xF0
00007e2c933e23f1  vmovaps [rsp], xmm0
00007e2c933e23f6  vmovaps [rsp+0x10], xmm1
00007e2c933e23fc  vmovaps [rsp+0x20], xmm2
00007e2c933e2402  vmovaps [rsp+0x30], xmm3
00007e2c933e2408  vmovaps [rsp+0x40], xmm4
00007e2c933e240e  vmovaps [rsp+0x50], xmm5
00007e2c933e2414  vmovaps [rsp+0x60], xmm6
00007e2c933e241a  vmovaps [rsp+0x70], xmm7
00007e2c933e2420  vmovaps [rsp+0x80], xmm8
00007e2c933e2429  vmovaps [rsp+0x90], xmm9
00007e2c933e2432  vmovaps [rsp+0xA0], xmm10
00007e2c933e243b  vmovaps [rsp+0xB0], xmm11
00007e2c933e2444  vmovaps [rsp+0xC0], xmm12
00007e2c933e244d  vmovaps [rsp+0xD0], xmm13
00007e2c933e2456  vmovaps [rsp+0xE0], xmm14
00007e2c933e245f  sub rsp, 0x30
00007e2c933e2463  movaps [rsp], xmm15
00007e2c933e2468  movaps [rsp+0x10], xmm5
00007e2c933e246d  movaps [rsp+0x20], xmm3
00007e2c933e2472  lea rdi, [rsp]
00007e2c933e2476  mov esi, 0x00
00007e2c933e247b  mov rax, 0x5A263F1C7530
00007e2c933e2485  call rax
00007e2c933e2487  movaps xmm15, [rsp]
00007e2c933e248c  add rsp, 0x30
00007e2c933e2490  vmovaps xmm0, [rsp]
00007e2c933e2495  vmovaps xmm1, [rsp+0x10]
00007e2c933e249b  vmovaps xmm2, [rsp+0x20]
00007e2c933e24a1  vmovaps xmm3, [rsp+0x30]
00007e2c933e24a7  vmovaps xmm4, [rsp+0x40]
00007e2c933e24ad  vmovaps xmm5, [rsp+0x50]
00007e2c933e24b3  vmovaps xmm6, [rsp+0x60]
00007e2c933e24b9  vmovaps xmm7, [rsp+0x70]
00007e2c933e24bf  vmovaps xmm8, [rsp+0x80]
00007e2c933e24c8  vmovaps xmm9, [rsp+0x90]
00007e2c933e24d1  vmovaps xmm10, [rsp+0xA0]
00007e2c933e24da  vmovaps xmm11, [rsp+0xB0]
00007e2c933e24e3  vmovaps xmm12, [rsp+0xC0]
00007e2c933e24ec  vmovaps xmm13, [rsp+0xD0]
00007e2c933e24f5  vmovaps xmm14, [rsp+0xE0]
00007e2c933e24fe  add rsp, 0xF0
00007e2c933e2505  pop r11
00007e2c933e2507  pop r10
00007e2c933e2509  pop r9
00007e2c933e250b  pop r8
00007e2c933e250d  pop rsi
00007e2c933e250e  pop rdi
00007e2c933e250f  pop rdx
00007e2c933e2510  pop rcx
00007e2c933e2511  pop rax
00007e2c933e2512  add rsp, 0x08
00007e2c933e2516  jmp 0x00007E2C933DF56F
00007e2c933e251b  sub rsp, 0x08
00007e2c933e251f  push rax
00007e2c933e2520  push rcx
00007e2c933e2521  push rdx
00007e2c933e2522  push rdi
00007e2c933e2523  push rsi
00007e2c933e2524  push r8
00007e2c933e2526  push r9
00007e2c933e2528  push r10
00007e2c933e252a  push r11
00007e2c933e252c  sub rsp, 0xF0
00007e2c933e2533  vmovaps [rsp], xmm0
00007e2c933e2538  vmovaps [rsp+0x10], xmm1
00007e2c933e253e  vmovaps [rsp+0x20], xmm2
00007e2c933e2544  vmovaps [rsp+0x30], xmm3
00007e2c933e254a  vmovaps [rsp+0x40], xmm4
00007e2c933e2550  vmovaps [rsp+0x50], xmm6
00007e2c933e2556  vmovaps [rsp+0x60], xmm7
00007e2c933e255c  vmovaps [rsp+0x70], xmm8
00007e2c933e2562  vmovaps [rsp+0x80], xmm9
00007e2c933e256b  vmovaps [rsp+0x90], xmm10
00007e2c933e2574  vmovaps [rsp+0xA0], xmm11
00007e2c933e257d  vmovaps [rsp+0xB0], xmm12
00007e2c933e2586  vmovaps [rsp+0xC0], xmm13
00007e2c933e258f  vmovaps [rsp+0xD0], xmm14
00007e2c933e2598  vmovaps [rsp+0xE0], xmm15
00007e2c933e25a1  sub rsp, 0x30
00007e2c933e25a5  movaps [rsp], xmm5
00007e2c933e25a9  movaps [rsp+0x10], xmm8
00007e2c933e25af  movaps [rsp+0x20], xmm6
00007e2c933e25b4  lea rdi, [rsp]
00007e2c933e25b8  mov esi, 0x00
00007e2c933e25bd  mov rax, 0x5A263F1C7530
00007e2c933e25c7  call rax
00007e2c933e25c9  movaps xmm5, [rsp]
00007e2c933e25cd  add rsp, 0x30
00007e2c933e25d1  vmovaps xmm0, [rsp]
00007e2c933e25d6  vmovaps xmm1, [rsp+0x10]
00007e2c933e25dc  vmovaps xmm2, [rsp+0x20]
00007e2c933e25e2  vmovaps xmm3, [rsp+0x30]
00007e2c933e25e8  vmovaps xmm4, [rsp+0x40]
00007e2c933e25ee  vmovaps xmm6, [rsp+0x50]
00007e2c933e25f4  vmovaps xmm7, [rsp+0x60]
00007e2c933e25fa  vmovaps xmm8, [rsp+0x70]
00007e2c933e2600  vmovaps xmm9, [rsp+0x80]
00007e2c933e2609  vmovaps xmm10, [rsp+0x90]
00007e2c933e2612  vmovaps xmm11, [rsp+0xA0]
00007e2c933e261b  vmovaps xmm12, [rsp+0xB0]
00007e2c933e2624  vmovaps xmm13, [rsp+0xC0]
00007e2c933e262d  vmovaps xmm14, [rsp+0xD0]
00007e2c933e2636  vmovaps xmm15, [rsp+0xE0]
00007e2c933e263f  add rsp, 0xF0
00007e2c933e2646  pop r11
00007e2c933e2648  pop r10
00007e2c933e264a  pop r9
00007e2c933e264c  pop r8
00007e2c933e264e  pop rsi
00007e2c933e264f  pop rdi
00007e2c933e2650  pop rdx
00007e2c933e2651  pop rcx
00007e2c933e2652  pop rax
00007e2c933e2653  add rsp, 0x08
00007e2c933e2657  jmp 0x00007E2C933DF593
00007e2c933e265c  sub rsp, 0x08
00007e2c933e2660  push rax
00007e2c933e2661  push rcx
00007e2c933e2662  push rdx
00007e2c933e2663  push rdi
00007e2c933e2664  push rsi
00007e2c933e2665  push r8
00007e2c933e2667  push r9
00007e2c933e2669  push r10
00007e2c933e266b  push r11
00007e2c933e266d  sub rsp, 0xF0
00007e2c933e2674  vmovaps [rsp], xmm0
00007e2c933e2679  vmovaps [rsp+0x10], xmm1
00007e2c933e267f  vmovaps [rsp+0x20], xmm2
00007e2c933e2685  vmovaps [rsp+0x30], xmm3
00007e2c933e268b  vmovaps [rsp+0x40], xmm4
00007e2c933e2691  vmovaps [rsp+0x50], xmm5
00007e2c933e2697  vmovaps [rsp+0x60], xmm7
00007e2c933e269d  vmovaps [rsp+0x70], xmm8
00007e2c933e26a3  vmovaps [rsp+0x80], xmm9
00007e2c933e26ac  vmovaps [rsp+0x90], xmm10
00007e2c933e26b5  vmovaps [rsp+0xA0], xmm11
00007e2c933e26be  vmovaps [rsp+0xB0], xmm12
00007e2c933e26c7  vmovaps [rsp+0xC0], xmm13
00007e2c933e26d0  vmovaps [rsp+0xD0], xmm14
00007e2c933e26d9  vmovaps [rsp+0xE0], xmm15
00007e2c933e26e2  sub rsp, 0x30
00007e2c933e26e6  movaps [rsp], xmm6
00007e2c933e26ea  movaps [rsp+0x10], xmm10
00007e2c933e26f0  movaps [rsp+0x20], xmm8
00007e2c933e26f6  lea rdi, [rsp]
00007e2c933e26fa  mov esi, 0x00
00007e2c933e26ff  mov rax, 0x5A263F1C7530
00007e2c933e2709  call rax
00007e2c933e270b  movaps xmm6, [rsp]
00007e2c933e270f  add rsp, 0x30
00007e2c933e2713  vmovaps xmm0, [rsp]
00007e2c933e2718  vmovaps xmm1, [rsp+0x10]
00007e2c933e271e  vmovaps xmm2, [rsp+0x20]
00007e2c933e2724  vmovaps xmm3, [rsp+0x30]
00007e2c933e272a  vmovaps xmm4, [rsp+0x40]
00007e2c933e2730  vmovaps xmm5, [rsp+0x50]
00007e2c933e2736  vmovaps xmm7, [rsp+0x60]
00007e2c933e273c  vmovaps xmm8, [rsp+0x70]
00007e2c933e2742  vmovaps xmm9, [rsp+0x80]
00007e2c933e274b  vmovaps xmm10, [rsp+0x90]
00007e2c933e2754  vmovaps xmm11, [rsp+0xA0]
00007e2c933e275d  vmovaps xmm12, [rsp+0xB0]
00007e2c933e2766  vmovaps xmm13, [rsp+0xC0]
00007e2c933e276f  vmovaps xmm14, [rsp+0xD0]
00007e2c933e2778  vmovaps xmm15, [rsp+0xE0]
00007e2c933e2781  add rsp, 0xF0
00007e2c933e2788  pop r11
00007e2c933e278a  pop r10
00007e2c933e278c  pop r9
00007e2c933e278e  pop r8
00007e2c933e2790  pop rsi
00007e2c933e2791  pop rdi
00007e2c933e2792  pop rdx
00007e2c933e2793  pop rcx
00007e2c933e2794  pop rax
00007e2c933e2795  add rsp, 0x08
00007e2c933e2799  jmp 0x00007E2C933DF5B8
00007e2c933e279e  sub rsp, 0x08
00007e2c933e27a2  push rax
00007e2c933e27a3  push rcx
00007e2c933e27a4  push rdx
00007e2c933e27a5  push rdi
00007e2c933e27a6  push rsi
00007e2c933e27a7  push r8
00007e2c933e27a9  push r9
00007e2c933e27ab  push r10
00007e2c933e27ad  push r11
00007e2c933e27af  sub rsp, 0xF0
00007e2c933e27b6  vmovaps [rsp], xmm0
00007e2c933e27bb  vmovaps [rsp+0x10], xmm1
00007e2c933e27c1  vmovaps [rsp+0x20], xmm2
00007e2c933e27c7  vmovaps [rsp+0x30], xmm3
00007e2c933e27cd  vmovaps [rsp+0x40], xmm4
00007e2c933e27d3  vmovaps [rsp+0x50], xmm5
00007e2c933e27d9  vmovaps [rsp+0x60], xmm6
00007e2c933e27df  vmovaps [rsp+0x70], xmm7
00007e2c933e27e5  vmovaps [rsp+0x80], xmm8
00007e2c933e27ee  vmovaps [rsp+0x90], xmm9
00007e2c933e27f7  vmovaps [rsp+0xA0], xmm11
00007e2c933e2800  vmovaps [rsp+0xB0], xmm12
00007e2c933e2809  vmovaps [rsp+0xC0], xmm13
00007e2c933e2812  vmovaps [rsp+0xD0], xmm14
00007e2c933e281b  vmovaps [rsp+0xE0], xmm15
00007e2c933e2824  sub rsp, 0x30
00007e2c933e2828  movaps [rsp], xmm10
00007e2c933e282d  movaps [rsp+0x10], xmm8
00007e2c933e2833  movaps [rsp+0x20], xmm14
00007e2c933e2839  lea rdi, [rsp]
00007e2c933e283d  mov esi, 0x00
00007e2c933e2842  mov rax, 0x5A263F1C7530
00007e2c933e284c  call rax
00007e2c933e284e  movaps xmm10, [rsp]
00007e2c933e2853  add rsp, 0x30
00007e2c933e2857  vmovaps xmm0, [rsp]
00007e2c933e285c  vmovaps xmm1, [rsp+0x10]
00007e2c933e2862  vmovaps xmm2, [rsp+0x20]
00007e2c933e2868  vmovaps xmm3, [rsp+0x30]
00007e2c933e286e  vmovaps xmm4, [rsp+0x40]
00007e2c933e2874  vmovaps xmm5, [rsp+0x50]
00007e2c933e287a  vmovaps xmm6, [rsp+0x60]
00007e2c933e2880  vmovaps xmm7, [rsp+0x70]
00007e2c933e2886  vmovaps xmm8, [rsp+0x80]
00007e2c933e288f  vmovaps xmm9, [rsp+0x90]
00007e2c933e2898  vmovaps xmm11, [rsp+0xA0]
00007e2c933e28a1  vmovaps xmm12, [rsp+0xB0]
00007e2c933e28aa  vmovaps xmm13, [rsp+0xC0]
00007e2c933e28b3  vmovaps xmm14, [rsp+0xD0]
00007e2c933e28bc  vmovaps xmm15, [rsp+0xE0]
00007e2c933e28c5  add rsp, 0xF0
00007e2c933e28cc  pop r11
00007e2c933e28ce  pop r10
00007e2c933e28d0  pop r9
00007e2c933e28d2  pop r8
00007e2c933e28d4  pop rsi
00007e2c933e28d5  pop rdi
00007e2c933e28d6  pop rdx
00007e2c933e28d7  pop rcx
00007e2c933e28d8  pop rax
00007e2c933e28d9  add rsp, 0x08
00007e2c933e28dd  jmp 0x00007E2C933DF5D8
00007e2c933e28e2  sub rsp, 0x08
00007e2c933e28e6  push rax
00007e2c933e28e7  push rcx
00007e2c933e28e8  push rdx
00007e2c933e28e9  push rdi
00007e2c933e28ea  push rsi
00007e2c933e28eb  push r8
00007e2c933e28ed  push r9
00007e2c933e28ef  push r10
00007e2c933e28f1  push r11
00007e2c933e28f3  sub rsp, 0xF0
00007e2c933e28fa  vmovaps [rsp], xmm0
00007e2c933e28ff  vmovaps [rsp+0x10], xmm1
00007e2c933e2905  vmovaps [rsp+0x20], xmm2
00007e2c933e290b  vmovaps [rsp+0x30], xmm3
00007e2c933e2911  vmovaps [rsp+0x40], xmm4
00007e2c933e2917  vmovaps [rsp+0x50], xmm5
00007e2c933e291d  vmovaps [rsp+0x60], xmm6
00007e2c933e2923  vmovaps [rsp+0x70], xmm7
00007e2c933e2929  vmovaps [rsp+0x80], xmm8
00007e2c933e2932  vmovaps [rsp+0x90], xmm9
00007e2c933e293b  vmovaps [rsp+0xA0], xmm10
00007e2c933e2944  vmovaps [rsp+0xB0], xmm11
00007e2c933e294d  vmovaps [rsp+0xC0], xmm12
00007e2c933e2956  vmovaps [rsp+0xD0], xmm13
00007e2c933e295f  vmovaps [rsp+0xE0], xmm15
00007e2c933e2968  sub rsp, 0x30
00007e2c933e296c  movaps [rsp], xmm14
00007e2c933e2971  movaps [rsp+0x10], xmm8
00007e2c933e2977  movaps [rsp+0x20], xmm4
00007e2c933e297c  lea rdi, [rsp]
00007e2c933e2980  mov esi, 0x00
00007e2c933e2985  mov rax, 0x5A263F1C7530
00007e2c933e298f  call rax
00007e2c933e2991  movaps xmm14, [rsp]
00007e2c933e2996  add rsp, 0x30
00007e2c933e299a  vmovaps xmm0, [rsp]
00007e2c933e299f  vmovaps xmm1, [rsp+0x10]
00007e2c933e29a5  vmovaps xmm2, [rsp+0x20]
00007e2c933e29ab  vmovaps xmm3, [rsp+0x30]
00007e2c933e29b1  vmovaps xmm4, [rsp+0x40]
00007e2c933e29b7  vmovaps xmm5, [rsp+0x50]
00007e2c933e29bd  vmovaps xmm6, [rsp+0x60]
00007e2c933e29c3  vmovaps xmm7, [rsp+0x70]
00007e2c933e29c9  vmovaps xmm8, [rsp+0x80]
00007e2c933e29d2  vmovaps xmm9, [rsp+0x90]
00007e2c933e29db  vmovaps xmm10, [rsp+0xA0]
00007e2c933e29e4  vmovaps xmm11, [rsp+0xB0]
00007e2c933e29ed  vmovaps xmm12, [rsp+0xC0]
00007e2c933e29f6  vmovaps xmm13, [rsp+0xD0]
00007e2c933e29ff  vmovaps xmm15, [rsp+0xE0]
00007e2c933e2a08  add rsp, 0xF0
00007e2c933e2a0f  pop r11
00007e2c933e2a11  pop r10
00007e2c933e2a13  pop r9
00007e2c933e2a15  pop r8
00007e2c933e2a17  pop rsi
00007e2c933e2a18  pop rdi
00007e2c933e2a19  pop rdx
00007e2c933e2a1a  pop rcx
00007e2c933e2a1b  pop rax
00007e2c933e2a1c  add rsp, 0x08
00007e2c933e2a20  jmp 0x00007E2C933DF5F8
00007e2c933e2a25  sub rsp, 0x08
00007e2c933e2a29  push rax
00007e2c933e2a2a  push rcx
00007e2c933e2a2b  push rdx
00007e2c933e2a2c  push rdi
00007e2c933e2a2d  push rsi
00007e2c933e2a2e  push r8
00007e2c933e2a30  push r9
00007e2c933e2a32  push r10
00007e2c933e2a34  push r11
00007e2c933e2a36  sub rsp, 0xF0
00007e2c933e2a3d  vmovaps [rsp], xmm0
00007e2c933e2a42  vmovaps [rsp+0x10], xmm1
00007e2c933e2a48  vmovaps [rsp+0x20], xmm2
00007e2c933e2a4e  vmovaps [rsp+0x30], xmm3
00007e2c933e2a54  vmovaps [rsp+0x40], xmm5
00007e2c933e2a5a  vmovaps [rsp+0x50], xmm6
00007e2c933e2a60  vmovaps [rsp+0x60], xmm7
00007e2c933e2a66  vmovaps [rsp+0x70], xmm8
00007e2c933e2a6c  vmovaps [rsp+0x80], xmm9
00007e2c933e2a75  vmovaps [rsp+0x90], xmm10
00007e2c933e2a7e  vmovaps [rsp+0xA0], xmm11
00007e2c933e2a87  vmovaps [rsp+0xB0], xmm12
00007e2c933e2a90  vmovaps [rsp+0xC0], xmm13
00007e2c933e2a99  vmovaps [rsp+0xD0], xmm14
00007e2c933e2aa2  vmovaps [rsp+0xE0], xmm15
00007e2c933e2aab  sub rsp, 0x30
00007e2c933e2aaf  movaps [rsp], xmm4
00007e2c933e2ab3  movaps [rsp+0x10], xmm13
00007e2c933e2ab9  movaps [rsp+0x20], xmm8
00007e2c933e2abf  lea rdi, [rsp]
00007e2c933e2ac3  mov esi, 0x00
00007e2c933e2ac8  mov rax, 0x5A263F1C7530
00007e2c933e2ad2  call rax
00007e2c933e2ad4  movaps xmm4, [rsp]
00007e2c933e2ad8  add rsp, 0x30
00007e2c933e2adc  vmovaps xmm0, [rsp]
00007e2c933e2ae1  vmovaps xmm1, [rsp+0x10]
00007e2c933e2ae7  vmovaps xmm2, [rsp+0x20]
00007e2c933e2aed  vmovaps xmm3, [rsp+0x30]
00007e2c933e2af3  vmovaps xmm5, [rsp+0x40]
00007e2c933e2af9  vmovaps xmm6, [rsp+0x50]
00007e2c933e2aff  vmovaps xmm7, [rsp+0x60]
00007e2c933e2b05  vmovaps xmm8, [rsp+0x70]
00007e2c933e2b0b  vmovaps xmm9, [rsp+0x80]
00007e2c933e2b14  vmovaps xmm10, [rsp+0x90]
00007e2c933e2b1d  vmovaps xmm11, [rsp+0xA0]
00007e2c933e2b26  vmovaps xmm12, [rsp+0xB0]
00007e2c933e2b2f  vmovaps xmm13, [rsp+0xC0]
00007e2c933e2b38  vmovaps xmm14, [rsp+0xD0]
00007e2c933e2b41  vmovaps xmm15, [rsp+0xE0]
00007e2c933e2b4a  add rsp, 0xF0
00007e2c933e2b51  pop r11
00007e2c933e2b53  pop r10
00007e2c933e2b55  pop r9
00007e2c933e2b57  pop r8
00007e2c933e2b59  pop rsi
00007e2c933e2b5a  pop rdi
00007e2c933e2b5b  pop rdx
00007e2c933e2b5c  pop rcx
00007e2c933e2b5d  pop rax
00007e2c933e2b5e  add rsp, 0x08
00007e2c933e2b62  jmp 0x00007E2C933DF61D
00007e2c933e2b67  sub rsp, 0x08
00007e2c933e2b6b  push rax
00007e2c933e2b6c  push rcx
00007e2c933e2b6d  push rdx
00007e2c933e2b6e  push rdi
00007e2c933e2b6f  push rsi
00007e2c933e2b70  push r8
00007e2c933e2b72  push r9
00007e2c933e2b74  push r10
00007e2c933e2b76  push r11
00007e2c933e2b78  sub rsp, 0xF0
00007e2c933e2b7f  vmovaps [rsp], xmm0
00007e2c933e2b84  vmovaps [rsp+0x10], xmm1
00007e2c933e2b8a  vmovaps [rsp+0x20], xmm2
00007e2c933e2b90  vmovaps [rsp+0x30], xmm3
00007e2c933e2b96  vmovaps [rsp+0x40], xmm4
00007e2c933e2b9c  vmovaps [rsp+0x50], xmm5
00007e2c933e2ba2  vmovaps [rsp+0x60], xmm6
00007e2c933e2ba8  vmovaps [rsp+0x70], xmm7
00007e2c933e2bae  vmovaps [rsp+0x80], xmm8
00007e2c933e2bb7  vmovaps [rsp+0x90], xmm9
00007e2c933e2bc0  vmovaps [rsp+0xA0], xmm10
00007e2c933e2bc9  vmovaps [rsp+0xB0], xmm11
00007e2c933e2bd2  vmovaps [rsp+0xC0], xmm12
00007e2c933e2bdb  vmovaps [rsp+0xD0], xmm14
00007e2c933e2be4  vmovaps [rsp+0xE0], xmm15
00007e2c933e2bed  sub rsp, 0x30
00007e2c933e2bf1  movaps [rsp], xmm13
00007e2c933e2bf6  movaps [rsp+0x10], xmm15
00007e2c933e2bfc  movaps [rsp+0x20], xmm9
00007e2c933e2c02  lea rdi, [rsp]
00007e2c933e2c06  mov esi, 0x00
00007e2c933e2c0b  mov rax, 0x5A263F1C7530
00007e2c933e2c15  call rax
00007e2c933e2c17  movaps xmm13, [rsp]
00007e2c933e2c1c  add rsp, 0x30
00007e2c933e2c20  vmovaps xmm0, [rsp]
00007e2c933e2c25  vmovaps xmm1, [rsp+0x10]
00007e2c933e2c2b  vmovaps xmm2, [rsp+0x20]
00007e2c933e2c31  vmovaps xmm3, [rsp+0x30]
00007e2c933e2c37  vmovaps xmm4, [rsp+0x40]
00007e2c933e2c3d  vmovaps xmm5, [rsp+0x50]
00007e2c933e2c43  vmovaps xmm6, [rsp+0x60]
00007e2c933e2c49  vmovaps xmm7, [rsp+0x70]
00007e2c933e2c4f  vmovaps xmm8, [rsp+0x80]
00007e2c933e2c58  vmovaps xmm9, [rsp+0x90]
00007e2c933e2c61  vmovaps xmm10, [rsp+0xA0]
00007e2c933e2c6a  vmovaps xmm11, [rsp+0xB0]
00007e2c933e2c73  vmovaps xmm12, [rsp+0xC0]
00007e2c933e2c7c  vmovaps xmm14, [rsp+0xD0]
00007e2c933e2c85  vmovaps xmm15, [rsp+0xE0]
00007e2c933e2c8e  add rsp, 0xF0
00007e2c933e2c95  pop r11
00007e2c933e2c97  pop r10
00007e2c933e2c99  pop r9
00007e2c933e2c9b  pop r8
00007e2c933e2c9d  pop rsi
00007e2c933e2c9e  pop rdi
00007e2c933e2c9f  pop rdx
00007e2c933e2ca0  pop rcx
00007e2c933e2ca1  pop rax
00007e2c933e2ca2  add rsp, 0x08
00007e2c933e2ca6  jmp 0x00007E2C933DF638
00007e2c933e2cab  sub rsp, 0x08
00007e2c933e2caf  push rax
00007e2c933e2cb0  push rcx
00007e2c933e2cb1  push rdx
00007e2c933e2cb2  push rdi
00007e2c933e2cb3  push rsi
00007e2c933e2cb4  push r8
00007e2c933e2cb6  push r9
00007e2c933e2cb8  push r10
00007e2c933e2cba  push r11
00007e2c933e2cbc  sub rsp, 0xF0
00007e2c933e2cc3  vmovaps [rsp], xmm0
00007e2c933e2cc8  vmovaps [rsp+0x10], xmm1
00007e2c933e2cce  vmovaps [rsp+0x20], xmm2
00007e2c933e2cd4  vmovaps [rsp+0x30], xmm3
00007e2c933e2cda  vmovaps [rsp+0x40], xmm4
00007e2c933e2ce0  vmovaps [rsp+0x50], xmm5
00007e2c933e2ce6  vmovaps [rsp+0x60], xmm6
00007e2c933e2cec  vmovaps [rsp+0x70], xmm7
00007e2c933e2cf2  vmovaps [rsp+0x80], xmm8
00007e2c933e2cfb  vmovaps [rsp+0x90], xmm9
00007e2c933e2d04  vmovaps [rsp+0xA0], xmm10
00007e2c933e2d0d  vmovaps [rsp+0xB0], xmm11
00007e2c933e2d16  vmovaps [rsp+0xC0], xmm12
00007e2c933e2d1f  vmovaps [rsp+0xD0], xmm13
00007e2c933e2d28  vmovaps [rsp+0xE0], xmm14
00007e2c933e2d31  sub rsp, 0x30
00007e2c933e2d35  movaps [rsp], xmm15
00007e2c933e2d3a  movaps [rsp+0x10], xmm1
00007e2c933e2d3f  movaps [rsp+0x20], xmm5
00007e2c933e2d44  lea rdi, [rsp]
00007e2c933e2d48  mov esi, 0x00
00007e2c933e2d4d  mov rax, 0x5A263F1C7530
00007e2c933e2d57  call rax
00007e2c933e2d59  movaps xmm15, [rsp]
00007e2c933e2d5e  add rsp, 0x30
00007e2c933e2d62  vmovaps xmm0, [rsp]
00007e2c933e2d67  vmovaps xmm1, [rsp+0x10]
00007e2c933e2d6d  vmovaps xmm2, [rsp+0x20]
00007e2c933e2d73  vmovaps xmm3, [rsp+0x30]
00007e2c933e2d79  vmovaps xmm4, [rsp+0x40]
00007e2c933e2d7f  vmovaps xmm5, [rsp+0x50]
00007e2c933e2d85  vmovaps xmm6, [rsp+0x60]
00007e2c933e2d8b  vmovaps xmm7, [rsp+0x70]
00007e2c933e2d91  vmovaps xmm8, [rsp+0x80]
00007e2c933e2d9a  vmovaps xmm9, [rsp+0x90]
00007e2c933e2da3  vmovaps xmm10, [rsp+0xA0]
00007e2c933e2dac  vmovaps xmm11, [rsp+0xB0]
00007e2c933e2db5  vmovaps xmm12, [rsp+0xC0]
00007e2c933e2dbe  vmovaps xmm13, [rsp+0xD0]
00007e2c933e2dc7  vmovaps xmm14, [rsp+0xE0]
00007e2c933e2dd0  add rsp, 0xF0
00007e2c933e2dd7  pop r11
00007e2c933e2dd9  pop r10
00007e2c933e2ddb  pop r9
00007e2c933e2ddd  pop r8
00007e2c933e2ddf  pop rsi
00007e2c933e2de0  pop rdi
00007e2c933e2de1  pop rdx
00007e2c933e2de2  pop rcx
00007e2c933e2de3  pop rax
00007e2c933e2de4  add rsp, 0x08
00007e2c933e2de8  jmp 0x00007E2C933DF653
00007e2c933e2ded  call 0x00007E2C932B52F0
00007e2c933e2df2  jmp 0x00007E2C933DF6AE
00007e2c933e2df7  sub rsp, 0x08
00007e2c933e2dfb  push rax
00007e2c933e2dfc  push rcx
00007e2c933e2dfd  push rdx
00007e2c933e2dfe  push rdi
00007e2c933e2dff  push rsi
00007e2c933e2e00  push r8
00007e2c933e2e02  push r9
00007e2c933e2e04  push r10
00007e2c933e2e06  push r11
00007e2c933e2e08  sub rsp, 0xF0
00007e2c933e2e0f  vmovaps [rsp], xmm0
00007e2c933e2e14  vmovaps [rsp+0x10], xmm1
00007e2c933e2e1a  vmovaps [rsp+0x20], xmm2
00007e2c933e2e20  vmovaps [rsp+0x30], xmm3
00007e2c933e2e26  vmovaps [rsp+0x40], xmm4
00007e2c933e2e2c  vmovaps [rsp+0x50], xmm5
00007e2c933e2e32  vmovaps [rsp+0x60], xmm6
00007e2c933e2e38  vmovaps [rsp+0x70], xmm7
00007e2c933e2e3e  vmovaps [rsp+0x80], xmm8
00007e2c933e2e47  vmovaps [rsp+0x90], xmm10
00007e2c933e2e50  vmovaps [rsp+0xA0], xmm11
00007e2c933e2e59  vmovaps [rsp+0xB0], xmm12
00007e2c933e2e62  vmovaps [rsp+0xC0], xmm13
00007e2c933e2e6b  vmovaps [rsp+0xD0], xmm14
00007e2c933e2e74  vmovaps [rsp+0xE0], xmm15
00007e2c933e2e7d  sub rsp, 0x30
00007e2c933e2e81  movaps [rsp], xmm9
00007e2c933e2e86  movaps [rsp+0x10], xmm8
00007e2c933e2e8c  movaps [rsp+0x20], xmm11
00007e2c933e2e92  lea rdi, [rsp]
00007e2c933e2e96  mov esi, 0x00
00007e2c933e2e9b  mov rax, 0x5A263F1C7530
00007e2c933e2ea5  call rax
00007e2c933e2ea7  movaps xmm9, [rsp]
00007e2c933e2eac  add rsp, 0x30
00007e2c933e2eb0  vmovaps xmm0, [rsp]
00007e2c933e2eb5  vmovaps xmm1, [rsp+0x10]
00007e2c933e2ebb  vmovaps xmm2, [rsp+0x20]
00007e2c933e2ec1  vmovaps xmm3, [rsp+0x30]
00007e2c933e2ec7  vmovaps xmm4, [rsp+0x40]
00007e2c933e2ecd  vmovaps xmm5, [rsp+0x50]
00007e2c933e2ed3  vmovaps xmm6, [rsp+0x60]
00007e2c933e2ed9  vmovaps xmm7, [rsp+0x70]
00007e2c933e2edf  vmovaps xmm8, [rsp+0x80]
00007e2c933e2ee8  vmovaps xmm10, [rsp+0x90]
00007e2c933e2ef1  vmovaps xmm11, [rsp+0xA0]
00007e2c933e2efa  vmovaps xmm12, [rsp+0xB0]
00007e2c933e2f03  vmovaps xmm13, [rsp+0xC0]
00007e2c933e2f0c  vmovaps xmm14, [rsp+0xD0]
00007e2c933e2f15  vmovaps xmm15, [rsp+0xE0]
00007e2c933e2f1e  add rsp, 0xF0
00007e2c933e2f25  pop r11
00007e2c933e2f27  pop r10
00007e2c933e2f29  pop r9
00007e2c933e2f2b  pop r8
00007e2c933e2f2d  pop rsi
00007e2c933e2f2e  pop rdi
00007e2c933e2f2f  pop rdx
00007e2c933e2f30  pop rcx
00007e2c933e2f31  pop rax
00007e2c933e2f32  add rsp, 0x08
00007e2c933e2f36  jmp 0x00007E2C933DF6E5
00007e2c933e2f3b  sub rsp, 0x08
00007e2c933e2f3f  push rax
00007e2c933e2f40  push rcx
00007e2c933e2f41  push rdx
00007e2c933e2f42  push rdi
00007e2c933e2f43  push rsi
00007e2c933e2f44  push r8
00007e2c933e2f46  push r9
00007e2c933e2f48  push r10
00007e2c933e2f4a  push r11
00007e2c933e2f4c  sub rsp, 0xF0
00007e2c933e2f53  vmovaps [rsp], xmm0
00007e2c933e2f58  vmovaps [rsp+0x10], xmm1
00007e2c933e2f5e  vmovaps [rsp+0x20], xmm2
00007e2c933e2f64  vmovaps [rsp+0x30], xmm3
00007e2c933e2f6a  vmovaps [rsp+0x40], xmm4
00007e2c933e2f70  vmovaps [rsp+0x50], xmm5
00007e2c933e2f76  vmovaps [rsp+0x60], xmm6
00007e2c933e2f7c  vmovaps [rsp+0x70], xmm7
00007e2c933e2f82  vmovaps [rsp+0x80], xmm8
00007e2c933e2f8b  vmovaps [rsp+0x90], xmm9
00007e2c933e2f94  vmovaps [rsp+0xA0], xmm10
00007e2c933e2f9d  vmovaps [rsp+0xB0], xmm12
00007e2c933e2fa6  vmovaps [rsp+0xC0], xmm13
00007e2c933e2faf  vmovaps [rsp+0xD0], xmm14
00007e2c933e2fb8  vmovaps [rsp+0xE0], xmm15
00007e2c933e2fc1  sub rsp, 0x30
00007e2c933e2fc5  movaps [rsp], xmm11
00007e2c933e2fca  movaps [rsp+0x10], xmm10
00007e2c933e2fd0  movaps [rsp+0x20], xmm6
00007e2c933e2fd5  lea rdi, [rsp]
00007e2c933e2fd9  mov esi, 0x00
00007e2c933e2fde  mov rax, 0x5A263F1C7530
00007e2c933e2fe8  call rax
00007e2c933e2fea  movaps xmm11, [rsp]
00007e2c933e2fef  add rsp, 0x30
00007e2c933e2ff3  vmovaps xmm0, [rsp]
00007e2c933e2ff8  vmovaps xmm1, [rsp+0x10]
00007e2c933e2ffe  vmovaps xmm2, [rsp+0x20]
00007e2c933e3004  vmovaps xmm3, [rsp+0x30]
00007e2c933e300a  vmovaps xmm4, [rsp+0x40]
00007e2c933e3010  vmovaps xmm5, [rsp+0x50]
00007e2c933e3016  vmovaps xmm6, [rsp+0x60]
00007e2c933e301c  vmovaps xmm7, [rsp+0x70]
00007e2c933e3022  vmovaps xmm8, [rsp+0x80]
00007e2c933e302b  vmovaps xmm9, [rsp+0x90]
00007e2c933e3034  vmovaps xmm10, [rsp+0xA0]
00007e2c933e303d  vmovaps xmm12, [rsp+0xB0]
00007e2c933e3046  vmovaps xmm13, [rsp+0xC0]
00007e2c933e304f  vmovaps xmm14, [rsp+0xD0]
00007e2c933e3058  vmovaps xmm15, [rsp+0xE0]
00007e2c933e3061  add rsp, 0xF0
00007e2c933e3068  pop r11
00007e2c933e306a  pop r10
00007e2c933e306c  pop r9
00007e2c933e306e  pop r8
00007e2c933e3070  pop rsi
00007e2c933e3071  pop rdi
00007e2c933e3072  pop rdx
00007e2c933e3073  pop rcx
00007e2c933e3074  pop rax
00007e2c933e3075  add rsp, 0x08
00007e2c933e3079  jmp 0x00007E2C933DF700
00007e2c933e307e  sub rsp, 0x08
00007e2c933e3082  push rax
00007e2c933e3083  push rcx
00007e2c933e3084  push rdx
00007e2c933e3085  push rdi
00007e2c933e3086  push rsi
00007e2c933e3087  push r8
00007e2c933e3089  push r9
00007e2c933e308b  push r10
00007e2c933e308d  push r11
00007e2c933e308f  sub rsp, 0xF0
00007e2c933e3096  vmovaps [rsp], xmm0
00007e2c933e309b  vmovaps [rsp+0x10], xmm1
00007e2c933e30a1  vmovaps [rsp+0x20], xmm2
00007e2c933e30a7  vmovaps [rsp+0x30], xmm3
00007e2c933e30ad  vmovaps [rsp+0x40], xmm4
00007e2c933e30b3  vmovaps [rsp+0x50], xmm5
00007e2c933e30b9  vmovaps [rsp+0x60], xmm6
00007e2c933e30bf  vmovaps [rsp+0x70], xmm7
00007e2c933e30c5  vmovaps [rsp+0x80], xmm8
00007e2c933e30ce  vmovaps [rsp+0x90], xmm9
00007e2c933e30d7  vmovaps [rsp+0xA0], xmm11
00007e2c933e30e0  vmovaps [rsp+0xB0], xmm12
00007e2c933e30e9  vmovaps [rsp+0xC0], xmm13
00007e2c933e30f2  vmovaps [rsp+0xD0], xmm14
00007e2c933e30fb  vmovaps [rsp+0xE0], xmm15
00007e2c933e3104  sub rsp, 0x30
00007e2c933e3108  movaps [rsp], xmm10
00007e2c933e310d  movaps [rsp+0x10], xmm14
00007e2c933e3113  movaps [rsp+0x20], xmm4
00007e2c933e3118  lea rdi, [rsp]
00007e2c933e311c  mov esi, 0x00
00007e2c933e3121  mov rax, 0x5A263F1C7530
00007e2c933e312b  call rax
00007e2c933e312d  movaps xmm10, [rsp]
00007e2c933e3132  add rsp, 0x30
00007e2c933e3136  vmovaps xmm0, [rsp]
00007e2c933e313b  vmovaps xmm1, [rsp+0x10]
00007e2c933e3141  vmovaps xmm2, [rsp+0x20]
00007e2c933e3147  vmovaps xmm3, [rsp+0x30]
00007e2c933e314d  vmovaps xmm4, [rsp+0x40]
00007e2c933e3153  vmovaps xmm5, [rsp+0x50]
00007e2c933e3159  vmovaps xmm6, [rsp+0x60]
00007e2c933e315f  vmovaps xmm7, [rsp+0x70]
00007e2c933e3165  vmovaps xmm8, [rsp+0x80]
00007e2c933e316e  vmovaps xmm9, [rsp+0x90]
00007e2c933e3177  vmovaps xmm11, [rsp+0xA0]
00007e2c933e3180  vmovaps xmm12, [rsp+0xB0]
00007e2c933e3189  vmovaps xmm13, [rsp+0xC0]
00007e2c933e3192  vmovaps xmm14, [rsp+0xD0]
00007e2c933e319b  vmovaps xmm15, [rsp+0xE0]
00007e2c933e31a4  add rsp, 0xF0
00007e2c933e31ab  pop r11
00007e2c933e31ad  pop r10
00007e2c933e31af  pop r9
00007e2c933e31b1  pop r8
00007e2c933e31b3  pop rsi
00007e2c933e31b4  pop rdi
00007e2c933e31b5  pop rdx
00007e2c933e31b6  pop rcx
00007e2c933e31b7  pop rax
00007e2c933e31b8  add rsp, 0x08
00007e2c933e31bc  jmp 0x00007E2C933DF71B
00007e2c933e31c1  sub rsp, 0x08
00007e2c933e31c5  push rax
00007e2c933e31c6  push rcx
00007e2c933e31c7  push rdx
00007e2c933e31c8  push rdi
00007e2c933e31c9  push rsi
00007e2c933e31ca  push r8
00007e2c933e31cc  push r9
00007e2c933e31ce  push r10
00007e2c933e31d0  push r11
00007e2c933e31d2  sub rsp, 0xF0
00007e2c933e31d9  vmovaps [rsp], xmm0
00007e2c933e31de  vmovaps [rsp+0x10], xmm1
00007e2c933e31e4  vmovaps [rsp+0x20], xmm2
00007e2c933e31ea  vmovaps [rsp+0x30], xmm3
00007e2c933e31f0  vmovaps [rsp+0x40], xmm4
00007e2c933e31f6  vmovaps [rsp+0x50], xmm5
00007e2c933e31fc  vmovaps [rsp+0x60], xmm6
00007e2c933e3202  vmovaps [rsp+0x70], xmm7
00007e2c933e3208  vmovaps [rsp+0x80], xmm9
00007e2c933e3211  vmovaps [rsp+0x90], xmm10
00007e2c933e321a  vmovaps [rsp+0xA0], xmm11
00007e2c933e3223  vmovaps [rsp+0xB0], xmm12
00007e2c933e322c  vmovaps [rsp+0xC0], xmm13
00007e2c933e3235  vmovaps [rsp+0xD0], xmm14
00007e2c933e323e  vmovaps [rsp+0xE0], xmm15
00007e2c933e3247  sub rsp, 0x30
00007e2c933e324b  movaps [rsp], xmm8
00007e2c933e3250  movaps [rsp+0x10], xmm1
00007e2c933e3255  movaps [rsp+0x20], xmm14
00007e2c933e325b  lea rdi, [rsp]
00007e2c933e325f  mov esi, 0x00
00007e2c933e3264  mov rax, 0x5A263F1C7530
00007e2c933e326e  call rax
00007e2c933e3270  movaps xmm8, [rsp]
00007e2c933e3275  add rsp, 0x30
00007e2c933e3279  vmovaps xmm0, [rsp]
00007e2c933e327e  vmovaps xmm1, [rsp+0x10]
00007e2c933e3284  vmovaps xmm2, [rsp+0x20]
00007e2c933e328a  vmovaps xmm3, [rsp+0x30]
00007e2c933e3290  vmovaps xmm4, [rsp+0x40]
00007e2c933e3296  vmovaps xmm5, [rsp+0x50]
00007e2c933e329c  vmovaps xmm6, [rsp+0x60]
00007e2c933e32a2  vmovaps xmm7, [rsp+0x70]
00007e2c933e32a8  vmovaps xmm9, [rsp+0x80]
00007e2c933e32b1  vmovaps xmm10, [rsp+0x90]
00007e2c933e32ba  vmovaps xmm11, [rsp+0xA0]
00007e2c933e32c3  vmovaps xmm12, [rsp+0xB0]
00007e2c933e32cc  vmovaps xmm13, [rsp+0xC0]
00007e2c933e32d5  vmovaps xmm14, [rsp+0xD0]
00007e2c933e32de  vmovaps xmm15, [rsp+0xE0]
00007e2c933e32e7  add rsp, 0xF0
00007e2c933e32ee  pop r11
00007e2c933e32f0  pop r10
00007e2c933e32f2  pop r9
00007e2c933e32f4  pop r8
00007e2c933e32f6  pop rsi
00007e2c933e32f7  pop rdi
00007e2c933e32f8  pop rdx
00007e2c933e32f9  pop rcx
00007e2c933e32fa  pop rax
00007e2c933e32fb  add rsp, 0x08
00007e2c933e32ff  jmp 0x00007E2C933DF741
00007e2c933e3304  sub rsp, 0x08
00007e2c933e3308  push rax
00007e2c933e3309  push rcx
00007e2c933e330a  push rdx
00007e2c933e330b  push rdi
00007e2c933e330c  push rsi
00007e2c933e330d  push r8
00007e2c933e330f  push r9
00007e2c933e3311  push r10
00007e2c933e3313  push r11
00007e2c933e3315  sub rsp, 0xF0
00007e2c933e331c  vmovaps [rsp], xmm0
00007e2c933e3321  vmovaps [rsp+0x10], xmm1
00007e2c933e3327  vmovaps [rsp+0x20], xmm2
00007e2c933e332d  vmovaps [rsp+0x30], xmm3
00007e2c933e3333  vmovaps [rsp+0x40], xmm4
00007e2c933e3339  vmovaps [rsp+0x50], xmm5
00007e2c933e333f  vmovaps [rsp+0x60], xmm7
00007e2c933e3345  vmovaps [rsp+0x70], xmm8
00007e2c933e334b  vmovaps [rsp+0x80], xmm9
00007e2c933e3354  vmovaps [rsp+0x90], xmm10
00007e2c933e335d  vmovaps [rsp+0xA0], xmm11
00007e2c933e3366  vmovaps [rsp+0xB0], xmm12
00007e2c933e336f  vmovaps [rsp+0xC0], xmm13
00007e2c933e3378  vmovaps [rsp+0xD0], xmm14
00007e2c933e3381  vmovaps [rsp+0xE0], xmm15
00007e2c933e338a  sub rsp, 0x30
00007e2c933e338e  movaps [rsp], xmm6
00007e2c933e3392  movaps [rsp+0x10], xmm1
00007e2c933e3397  movaps [rsp+0x20], xmm14
00007e2c933e339d  lea rdi, [rsp]
00007e2c933e33a1  mov esi, 0x00
00007e2c933e33a6  mov rax, 0x5A263F1C7530
00007e2c933e33b0  call rax
00007e2c933e33b2  movaps xmm6, [rsp]
00007e2c933e33b6  add rsp, 0x30
00007e2c933e33ba  vmovaps xmm0, [rsp]
00007e2c933e33bf  vmovaps xmm1, [rsp+0x10]
00007e2c933e33c5  vmovaps xmm2, [rsp+0x20]
00007e2c933e33cb  vmovaps xmm3, [rsp+0x30]
00007e2c933e33d1  vmovaps xmm4, [rsp+0x40]
00007e2c933e33d7  vmovaps xmm5, [rsp+0x50]
00007e2c933e33dd  vmovaps xmm7, [rsp+0x60]
00007e2c933e33e3  vmovaps xmm8, [rsp+0x70]
00007e2c933e33e9  vmovaps xmm9, [rsp+0x80]
00007e2c933e33f2  vmovaps xmm10, [rsp+0x90]
00007e2c933e33fb  vmovaps xmm11, [rsp+0xA0]
00007e2c933e3404  vmovaps xmm12, [rsp+0xB0]
00007e2c933e340d  vmovaps xmm13, [rsp+0xC0]
00007e2c933e3416  vmovaps xmm14, [rsp+0xD0]
00007e2c933e341f  vmovaps xmm15, [rsp+0xE0]
00007e2c933e3428  add rsp, 0xF0
00007e2c933e342f  pop r11
00007e2c933e3431  pop r10
00007e2c933e3433  pop r9
00007e2c933e3435  pop r8
00007e2c933e3437  pop rsi
00007e2c933e3438  pop rdi
00007e2c933e3439  pop rdx
00007e2c933e343a  pop rcx
00007e2c933e343b  pop rax
00007e2c933e343c  add rsp, 0x08
00007e2c933e3440  jmp 0x00007E2C933DF76D
00007e2c933e3445  sub rsp, 0x08
00007e2c933e3449  push rax
00007e2c933e344a  push rcx
00007e2c933e344b  push rdx
00007e2c933e344c  push rdi
00007e2c933e344d  push rsi
00007e2c933e344e  push r8
00007e2c933e3450  push r9
00007e2c933e3452  push r10
00007e2c933e3454  push r11
00007e2c933e3456  sub rsp, 0xF0
00007e2c933e345d  vmovaps [rsp], xmm0
00007e2c933e3462  vmovaps [rsp+0x10], xmm1
00007e2c933e3468  vmovaps [rsp+0x20], xmm2
00007e2c933e346e  vmovaps [rsp+0x30], xmm3
00007e2c933e3474  vmovaps [rsp+0x40], xmm4
00007e2c933e347a  vmovaps [rsp+0x50], xmm5
00007e2c933e3480  vmovaps [rsp+0x60], xmm6
00007e2c933e3486  vmovaps [rsp+0x70], xmm7
00007e2c933e348c  vmovaps [rsp+0x80], xmm8
00007e2c933e3495  vmovaps [rsp+0x90], xmm9
00007e2c933e349e  vmovaps [rsp+0xA0], xmm10
00007e2c933e34a7  vmovaps [rsp+0xB0], xmm11
00007e2c933e34b0  vmovaps [rsp+0xC0], xmm12
00007e2c933e34b9  vmovaps [rsp+0xD0], xmm13
00007e2c933e34c2  vmovaps [rsp+0xE0], xmm15
00007e2c933e34cb  sub rsp, 0x30
00007e2c933e34cf  movaps [rsp], xmm14
00007e2c933e34d4  movaps [rsp+0x10], xmm12
00007e2c933e34da  movaps [rsp+0x20], xmm1
00007e2c933e34df  lea rdi, [rsp]
00007e2c933e34e3  mov esi, 0x00
00007e2c933e34e8  mov rax, 0x5A263F1C7530
00007e2c933e34f2  call rax
00007e2c933e34f4  movaps xmm14, [rsp]
00007e2c933e34f9  add rsp, 0x30
00007e2c933e34fd  vmovaps xmm0, [rsp]
00007e2c933e3502  vmovaps xmm1, [rsp+0x10]
00007e2c933e3508  vmovaps xmm2, [rsp+0x20]
00007e2c933e350e  vmovaps xmm3, [rsp+0x30]
00007e2c933e3514  vmovaps xmm4, [rsp+0x40]
00007e2c933e351a  vmovaps xmm5, [rsp+0x50]
00007e2c933e3520  vmovaps xmm6, [rsp+0x60]
00007e2c933e3526  vmovaps xmm7, [rsp+0x70]
00007e2c933e352c  vmovaps xmm8, [rsp+0x80]
00007e2c933e3535  vmovaps xmm9, [rsp+0x90]
00007e2c933e353e  vmovaps xmm10, [rsp+0xA0]
00007e2c933e3547  vmovaps xmm11, [rsp+0xB0]
00007e2c933e3550  vmovaps xmm12, [rsp+0xC0]
00007e2c933e3559  vmovaps xmm13, [rsp+0xD0]
00007e2c933e3562  vmovaps xmm15, [rsp+0xE0]
00007e2c933e356b  add rsp, 0xF0
00007e2c933e3572  pop r11
00007e2c933e3574  pop r10
00007e2c933e3576  pop r9
00007e2c933e3578  pop r8
00007e2c933e357a  pop rsi
00007e2c933e357b  pop rdi
00007e2c933e357c  pop rdx
00007e2c933e357d  pop rcx
00007e2c933e357e  pop rax
00007e2c933e357f  add rsp, 0x08
00007e2c933e3583  jmp 0x00007E2C933DF793
00007e2c933e3588  sub rsp, 0x08
00007e2c933e358c  push rax
00007e2c933e358d  push rcx
00007e2c933e358e  push rdx
00007e2c933e358f  push rdi
00007e2c933e3590  push rsi
00007e2c933e3591  push r8
00007e2c933e3593  push r9
00007e2c933e3595  push r10
00007e2c933e3597  push r11
00007e2c933e3599  sub rsp, 0xF0
00007e2c933e35a0  vmovaps [rsp], xmm0
00007e2c933e35a5  vmovaps [rsp+0x10], xmm2
00007e2c933e35ab  vmovaps [rsp+0x20], xmm3
00007e2c933e35b1  vmovaps [rsp+0x30], xmm4
00007e2c933e35b7  vmovaps [rsp+0x40], xmm5
00007e2c933e35bd  vmovaps [rsp+0x50], xmm6
00007e2c933e35c3  vmovaps [rsp+0x60], xmm7
00007e2c933e35c9  vmovaps [rsp+0x70], xmm8
00007e2c933e35cf  vmovaps [rsp+0x80], xmm9
00007e2c933e35d8  vmovaps [rsp+0x90], xmm10
00007e2c933e35e1  vmovaps [rsp+0xA0], xmm11
00007e2c933e35ea  vmovaps [rsp+0xB0], xmm12
00007e2c933e35f3  vmovaps [rsp+0xC0], xmm13
00007e2c933e35fc  vmovaps [rsp+0xD0], xmm14
00007e2c933e3605  vmovaps [rsp+0xE0], xmm15
00007e2c933e360e  sub rsp, 0x30
00007e2c933e3612  movaps [rsp], xmm1
00007e2c933e3616  movaps [rsp+0x10], xmm13
00007e2c933e361c  movaps [rsp+0x20], xmm9
00007e2c933e3622  lea rdi, [rsp]
00007e2c933e3626  mov esi, 0x00
00007e2c933e362b  mov rax, 0x5A263F1C7530
00007e2c933e3635  call rax
00007e2c933e3637  movaps xmm1, [rsp]
00007e2c933e363b  add rsp, 0x30
00007e2c933e363f  vmovaps xmm0, [rsp]
00007e2c933e3644  vmovaps xmm2, [rsp+0x10]
00007e2c933e364a  vmovaps xmm3, [rsp+0x20]
00007e2c933e3650  vmovaps xmm4, [rsp+0x30]
00007e2c933e3656  vmovaps xmm5, [rsp+0x40]
00007e2c933e365c  vmovaps xmm6, [rsp+0x50]
00007e2c933e3662  vmovaps xmm7, [rsp+0x60]
00007e2c933e3668  vmovaps xmm8, [rsp+0x70]
00007e2c933e366e  vmovaps xmm9, [rsp+0x80]
00007e2c933e3677  vmovaps xmm10, [rsp+0x90]
00007e2c933e3680  vmovaps xmm11, [rsp+0xA0]
00007e2c933e3689  vmovaps xmm12, [rsp+0xB0]
00007e2c933e3692  vmovaps xmm13, [rsp+0xC0]
00007e2c933e369b  vmovaps xmm14, [rsp+0xD0]
00007e2c933e36a4  vmovaps xmm15, [rsp+0xE0]
00007e2c933e36ad  add rsp, 0xF0
00007e2c933e36b4  pop r11
00007e2c933e36b6  pop r10
00007e2c933e36b8  pop r9
00007e2c933e36ba  pop r8
00007e2c933e36bc  pop rsi
00007e2c933e36bd  pop rdi
00007e2c933e36be  pop rdx
00007e2c933e36bf  pop rcx
00007e2c933e36c0  pop rax
00007e2c933e36c1  add rsp, 0x08
00007e2c933e36c5  jmp 0x00007E2C933DF7AD
00007e2c933e36ca  sub rsp, 0x08
00007e2c933e36ce  push rax
00007e2c933e36cf  push rcx
00007e2c933e36d0  push rdx
00007e2c933e36d1  push rdi
00007e2c933e36d2  push rsi
00007e2c933e36d3  push r8
00007e2c933e36d5  push r9
00007e2c933e36d7  push r10
00007e2c933e36d9  push r11
00007e2c933e36db  sub rsp, 0xF0
00007e2c933e36e2  vmovaps [rsp], xmm0
00007e2c933e36e7  vmovaps [rsp+0x10], xmm1
00007e2c933e36ed  vmovaps [rsp+0x20], xmm2
00007e2c933e36f3  vmovaps [rsp+0x30], xmm3
00007e2c933e36f9  vmovaps [rsp+0x40], xmm4
00007e2c933e36ff  vmovaps [rsp+0x50], xmm5
00007e2c933e3705  vmovaps [rsp+0x60], xmm6
00007e2c933e370b  vmovaps [rsp+0x70], xmm7
00007e2c933e3711  vmovaps [rsp+0x80], xmm8
00007e2c933e371a  vmovaps [rsp+0x90], xmm9
00007e2c933e3723  vmovaps [rsp+0xA0], xmm10
00007e2c933e372c  vmovaps [rsp+0xB0], xmm11
00007e2c933e3735  vmovaps [rsp+0xC0], xmm13
00007e2c933e373e  vmovaps [rsp+0xD0], xmm14
00007e2c933e3747  vmovaps [rsp+0xE0], xmm15
00007e2c933e3750  sub rsp, 0x30
00007e2c933e3754  movaps [rsp], xmm12
00007e2c933e3759  movaps [rsp+0x10], xmm7
00007e2c933e375e  movaps [rsp+0x20], xmm13
00007e2c933e3764  lea rdi, [rsp]
00007e2c933e3768  mov esi, 0x00
00007e2c933e376d  mov rax, 0x5A263F1C7530
00007e2c933e3777  call rax
00007e2c933e3779  movaps xmm12, [rsp]
00007e2c933e377e  add rsp, 0x30
00007e2c933e3782  vmovaps xmm0, [rsp]
00007e2c933e3787  vmovaps xmm1, [rsp+0x10]
00007e2c933e378d  vmovaps xmm2, [rsp+0x20]
00007e2c933e3793  vmovaps xmm3, [rsp+0x30]
00007e2c933e3799  vmovaps xmm4, [rsp+0x40]
00007e2c933e379f  vmovaps xmm5, [rsp+0x50]
00007e2c933e37a5  vmovaps xmm6, [rsp+0x60]
00007e2c933e37ab  vmovaps xmm7, [rsp+0x70]
00007e2c933e37b1  vmovaps xmm8, [rsp+0x80]
00007e2c933e37ba  vmovaps xmm9, [rsp+0x90]
00007e2c933e37c3  vmovaps xmm10, [rsp+0xA0]
00007e2c933e37cc  vmovaps xmm11, [rsp+0xB0]
00007e2c933e37d5  vmovaps xmm13, [rsp+0xC0]
00007e2c933e37de  vmovaps xmm14, [rsp+0xD0]
00007e2c933e37e7  vmovaps xmm15, [rsp+0xE0]
00007e2c933e37f0  add rsp, 0xF0
00007e2c933e37f7  pop r11
00007e2c933e37f9  pop r10
00007e2c933e37fb  pop r9
00007e2c933e37fd  pop r8
00007e2c933e37ff  pop rsi
00007e2c933e3800  pop rdi
00007e2c933e3801  pop rdx
00007e2c933e3802  pop rcx
00007e2c933e3803  pop rax
00007e2c933e3804  add rsp, 0x08
00007e2c933e3808  jmp 0x00007E2C933DF7D4
00007e2c933e380d  sub rsp, 0x08
00007e2c933e3811  push rax
00007e2c933e3812  push rcx
00007e2c933e3813  push rdx
00007e2c933e3814  push rdi
00007e2c933e3815  push rsi
00007e2c933e3816  push r8
00007e2c933e3818  push r9
00007e2c933e381a  push r10
00007e2c933e381c  push r11
00007e2c933e381e  sub rsp, 0xF0
00007e2c933e3825  vmovaps [rsp], xmm0
00007e2c933e382a  vmovaps [rsp+0x10], xmm1
00007e2c933e3830  vmovaps [rsp+0x20], xmm2
00007e2c933e3836  vmovaps [rsp+0x30], xmm3
00007e2c933e383c  vmovaps [rsp+0x40], xmm4
00007e2c933e3842  vmovaps [rsp+0x50], xmm5
00007e2c933e3848  vmovaps [rsp+0x60], xmm6
00007e2c933e384e  vmovaps [rsp+0x70], xmm7
00007e2c933e3854  vmovaps [rsp+0x80], xmm8
00007e2c933e385d  vmovaps [rsp+0x90], xmm9
00007e2c933e3866  vmovaps [rsp+0xA0], xmm10
00007e2c933e386f  vmovaps [rsp+0xB0], xmm11
00007e2c933e3878  vmovaps [rsp+0xC0], xmm12
00007e2c933e3881  vmovaps [rsp+0xD0], xmm14
00007e2c933e388a  vmovaps [rsp+0xE0], xmm15
00007e2c933e3893  sub rsp, 0x30
00007e2c933e3897  movaps [rsp], xmm13
00007e2c933e389c  movaps [rsp+0x10], xmm15
00007e2c933e38a2  movaps [rsp+0x20], xmm8
00007e2c933e38a8  lea rdi, [rsp]
00007e2c933e38ac  mov esi, 0x00
00007e2c933e38b1  mov rax, 0x5A263F1C7530
00007e2c933e38bb  call rax
00007e2c933e38bd  movaps xmm13, [rsp]
00007e2c933e38c2  add rsp, 0x30
00007e2c933e38c6  vmovaps xmm0, [rsp]
00007e2c933e38cb  vmovaps xmm1, [rsp+0x10]
00007e2c933e38d1  vmovaps xmm2, [rsp+0x20]
00007e2c933e38d7  vmovaps xmm3, [rsp+0x30]
00007e2c933e38dd  vmovaps xmm4, [rsp+0x40]
00007e2c933e38e3  vmovaps xmm5, [rsp+0x50]
00007e2c933e38e9  vmovaps xmm6, [rsp+0x60]
00007e2c933e38ef  vmovaps xmm7, [rsp+0x70]
00007e2c933e38f5  vmovaps xmm8, [rsp+0x80]
00007e2c933e38fe  vmovaps xmm9, [rsp+0x90]
00007e2c933e3907  vmovaps xmm10, [rsp+0xA0]
00007e2c933e3910  vmovaps xmm11, [rsp+0xB0]
00007e2c933e3919  vmovaps xmm12, [rsp+0xC0]
00007e2c933e3922  vmovaps xmm14, [rsp+0xD0]
00007e2c933e392b  vmovaps xmm15, [rsp+0xE0]
00007e2c933e3934  add rsp, 0xF0
00007e2c933e393b  pop r11
00007e2c933e393d  pop r10
00007e2c933e393f  pop r9
00007e2c933e3941  pop r8
00007e2c933e3943  pop rsi
00007e2c933e3944  pop rdi
00007e2c933e3945  pop rdx
00007e2c933e3946  pop rcx
00007e2c933e3947  pop rax
00007e2c933e3948  add rsp, 0x08
00007e2c933e394c  jmp 0x00007E2C933DF7EF
00007e2c933e3951  sub rsp, 0x08
00007e2c933e3955  push rax
00007e2c933e3956  push rcx
00007e2c933e3957  push rdx
00007e2c933e3958  push rdi
00007e2c933e3959  push rsi
00007e2c933e395a  push r8
00007e2c933e395c  push r9
00007e2c933e395e  push r10
00007e2c933e3960  push r11
00007e2c933e3962  sub rsp, 0xF0
00007e2c933e3969  vmovaps [rsp], xmm0
00007e2c933e396e  vmovaps [rsp+0x10], xmm1
00007e2c933e3974  vmovaps [rsp+0x20], xmm2
00007e2c933e397a  vmovaps [rsp+0x30], xmm3
00007e2c933e3980  vmovaps [rsp+0x40], xmm4
00007e2c933e3986  vmovaps [rsp+0x50], xmm5
00007e2c933e398c  vmovaps [rsp+0x60], xmm6
00007e2c933e3992  vmovaps [rsp+0x70], xmm7
00007e2c933e3998  vmovaps [rsp+0x80], xmm9
00007e2c933e39a1  vmovaps [rsp+0x90], xmm10
00007e2c933e39aa  vmovaps [rsp+0xA0], xmm11
00007e2c933e39b3  vmovaps [rsp+0xB0], xmm12
00007e2c933e39bc  vmovaps [rsp+0xC0], xmm13
00007e2c933e39c5  vmovaps [rsp+0xD0], xmm14
00007e2c933e39ce  vmovaps [rsp+0xE0], xmm15
00007e2c933e39d7  sub rsp, 0x30
00007e2c933e39db  movaps [rsp], xmm8
00007e2c933e39e0  movaps [rsp+0x10], xmm15
00007e2c933e39e6  movaps [rsp+0x20], xmm9
00007e2c933e39ec  lea rdi, [rsp]
00007e2c933e39f0  mov esi, 0x00
00007e2c933e39f5  mov rax, 0x5A263F1C7530
00007e2c933e39ff  call rax
00007e2c933e3a01  movaps xmm8, [rsp]
00007e2c933e3a06  add rsp, 0x30
00007e2c933e3a0a  vmovaps xmm0, [rsp]
00007e2c933e3a0f  vmovaps xmm1, [rsp+0x10]
00007e2c933e3a15  vmovaps xmm2, [rsp+0x20]
00007e2c933e3a1b  vmovaps xmm3, [rsp+0x30]
00007e2c933e3a21  vmovaps xmm4, [rsp+0x40]
00007e2c933e3a27  vmovaps xmm5, [rsp+0x50]
00007e2c933e3a2d  vmovaps xmm6, [rsp+0x60]
00007e2c933e3a33  vmovaps xmm7, [rsp+0x70]
00007e2c933e3a39  vmovaps xmm9, [rsp+0x80]
00007e2c933e3a42  vmovaps xmm10, [rsp+0x90]
00007e2c933e3a4b  vmovaps xmm11, [rsp+0xA0]
00007e2c933e3a54  vmovaps xmm12, [rsp+0xB0]
00007e2c933e3a5d  vmovaps xmm13, [rsp+0xC0]
00007e2c933e3a66  vmovaps xmm14, [rsp+0xD0]
00007e2c933e3a6f  vmovaps xmm15, [rsp+0xE0]
00007e2c933e3a78  add rsp, 0xF0
00007e2c933e3a7f  pop r11
00007e2c933e3a81  pop r10
00007e2c933e3a83  pop r9
00007e2c933e3a85  pop r8
00007e2c933e3a87  pop rsi
00007e2c933e3a88  pop rdi
00007e2c933e3a89  pop rdx
00007e2c933e3a8a  pop rcx
00007e2c933e3a8b  pop rax
00007e2c933e3a8c  add rsp, 0x08
00007e2c933e3a90  jmp 0x00007E2C933DF81D
00007e2c933e3a95  sub rsp, 0x08
00007e2c933e3a99  push rax
00007e2c933e3a9a  push rcx
00007e2c933e3a9b  push rdx
00007e2c933e3a9c  push rdi
00007e2c933e3a9d  push rsi
00007e2c933e3a9e  push r8
00007e2c933e3aa0  push r9
00007e2c933e3aa2  push r10
00007e2c933e3aa4  push r11
00007e2c933e3aa6  sub rsp, 0xF0
00007e2c933e3aad  vmovaps [rsp], xmm0
00007e2c933e3ab2  vmovaps [rsp+0x10], xmm1
00007e2c933e3ab8  vmovaps [rsp+0x20], xmm2
00007e2c933e3abe  vmovaps [rsp+0x30], xmm3
00007e2c933e3ac4  vmovaps [rsp+0x40], xmm4
00007e2c933e3aca  vmovaps [rsp+0x50], xmm5
00007e2c933e3ad0  vmovaps [rsp+0x60], xmm6
00007e2c933e3ad6  vmovaps [rsp+0x70], xmm7
00007e2c933e3adc  vmovaps [rsp+0x80], xmm8
00007e2c933e3ae5  vmovaps [rsp+0x90], xmm9
00007e2c933e3aee  vmovaps [rsp+0xA0], xmm10
00007e2c933e3af7  vmovaps [rsp+0xB0], xmm11
00007e2c933e3b00  vmovaps [rsp+0xC0], xmm12
00007e2c933e3b09  vmovaps [rsp+0xD0], xmm13
00007e2c933e3b12  vmovaps [rsp+0xE0], xmm14
00007e2c933e3b1b  sub rsp, 0x30
00007e2c933e3b1f  movaps [rsp], xmm15
00007e2c933e3b24  movaps [rsp+0x10], xmm11
00007e2c933e3b2a  movaps [rsp+0x20], xmm6
00007e2c933e3b2f  lea rdi, [rsp]
00007e2c933e3b33  mov esi, 0x00
00007e2c933e3b38  mov rax, 0x5A263F1C7530
00007e2c933e3b42  call rax
00007e2c933e3b44  movaps xmm15, [rsp]
00007e2c933e3b49  add rsp, 0x30
00007e2c933e3b4d  vmovaps xmm0, [rsp]
00007e2c933e3b52  vmovaps xmm1, [rsp+0x10]
00007e2c933e3b58  vmovaps xmm2, [rsp+0x20]
00007e2c933e3b5e  vmovaps xmm3, [rsp+0x30]
00007e2c933e3b64  vmovaps xmm4, [rsp+0x40]
00007e2c933e3b6a  vmovaps xmm5, [rsp+0x50]
00007e2c933e3b70  vmovaps xmm6, [rsp+0x60]
00007e2c933e3b76  vmovaps xmm7, [rsp+0x70]
00007e2c933e3b7c  vmovaps xmm8, [rsp+0x80]
00007e2c933e3b85  vmovaps xmm9, [rsp+0x90]
00007e2c933e3b8e  vmovaps xmm10, [rsp+0xA0]
00007e2c933e3b97  vmovaps xmm11, [rsp+0xB0]
00007e2c933e3ba0  vmovaps xmm12, [rsp+0xC0]
00007e2c933e3ba9  vmovaps xmm13, [rsp+0xD0]
00007e2c933e3bb2  vmovaps xmm14, [rsp+0xE0]
00007e2c933e3bbb  add rsp, 0xF0
00007e2c933e3bc2  pop r11
00007e2c933e3bc4  pop r10
00007e2c933e3bc6  pop r9
00007e2c933e3bc8  pop r8
00007e2c933e3bca  pop rsi
00007e2c933e3bcb  pop rdi
00007e2c933e3bcc  pop rdx
00007e2c933e3bcd  pop rcx
00007e2c933e3bce  pop rax
00007e2c933e3bcf  add rsp, 0x08
00007e2c933e3bd3  jmp 0x00007E2C933DF838
00007e2c933e3bd8  sub rsp, 0x08
00007e2c933e3bdc  push rax
00007e2c933e3bdd  push rcx
00007e2c933e3bde  push rdx
00007e2c933e3bdf  push rdi
00007e2c933e3be0  push rsi
00007e2c933e3be1  push r8
00007e2c933e3be3  push r9
00007e2c933e3be5  push r10
00007e2c933e3be7  push r11
00007e2c933e3be9  sub rsp, 0xF0
00007e2c933e3bf0  vmovaps [rsp], xmm0
00007e2c933e3bf5  vmovaps [rsp+0x10], xmm1
00007e2c933e3bfb  vmovaps [rsp+0x20], xmm2
00007e2c933e3c01  vmovaps [rsp+0x30], xmm3
00007e2c933e3c07  vmovaps [rsp+0x40], xmm4
00007e2c933e3c0d  vmovaps [rsp+0x50], xmm5
00007e2c933e3c13  vmovaps [rsp+0x60], xmm6
00007e2c933e3c19  vmovaps [rsp+0x70], xmm8
00007e2c933e3c1f  vmovaps [rsp+0x80], xmm9
00007e2c933e3c28  vmovaps [rsp+0x90], xmm10
00007e2c933e3c31  vmovaps [rsp+0xA0], xmm11
00007e2c933e3c3a  vmovaps [rsp+0xB0], xmm12
00007e2c933e3c43  vmovaps [rsp+0xC0], xmm13
00007e2c933e3c4c  vmovaps [rsp+0xD0], xmm14
00007e2c933e3c55  vmovaps [rsp+0xE0], xmm15
00007e2c933e3c5e  sub rsp, 0x30
00007e2c933e3c62  movaps [rsp], xmm7
00007e2c933e3c66  movaps [rsp+0x10], xmm11
00007e2c933e3c6c  movaps [rsp+0x20], xmm9
00007e2c933e3c72  lea rdi, [rsp]
00007e2c933e3c76  mov esi, 0x00
00007e2c933e3c7b  mov rax, 0x5A263F1C7530
00007e2c933e3c85  call rax
00007e2c933e3c87  movaps xmm7, [rsp]
00007e2c933e3c8b  add rsp, 0x30
00007e2c933e3c8f  vmovaps xmm0, [rsp]
00007e2c933e3c94  vmovaps xmm1, [rsp+0x10]
00007e2c933e3c9a  vmovaps xmm2, [rsp+0x20]
00007e2c933e3ca0  vmovaps xmm3, [rsp+0x30]
00007e2c933e3ca6  vmovaps xmm4, [rsp+0x40]
00007e2c933e3cac  vmovaps xmm5, [rsp+0x50]
00007e2c933e3cb2  vmovaps xmm6, [rsp+0x60]
00007e2c933e3cb8  vmovaps xmm8, [rsp+0x70]
00007e2c933e3cbe  vmovaps xmm9, [rsp+0x80]
00007e2c933e3cc7  vmovaps xmm10, [rsp+0x90]
00007e2c933e3cd0  vmovaps xmm11, [rsp+0xA0]
00007e2c933e3cd9  vmovaps xmm12, [rsp+0xB0]
00007e2c933e3ce2  vmovaps xmm13, [rsp+0xC0]
00007e2c933e3ceb  vmovaps xmm14, [rsp+0xD0]
00007e2c933e3cf4  vmovaps xmm15, [rsp+0xE0]
00007e2c933e3cfd  add rsp, 0xF0
00007e2c933e3d04  pop r11
00007e2c933e3d06  pop r10
00007e2c933e3d08  pop r9
00007e2c933e3d0a  pop r8
00007e2c933e3d0c  pop rsi
00007e2c933e3d0d  pop rdi
00007e2c933e3d0e  pop rdx
00007e2c933e3d0f  pop rcx
00007e2c933e3d10  pop rax
00007e2c933e3d11  add rsp, 0x08
00007e2c933e3d15  jmp 0x00007E2C933DF865
00007e2c933e3d1a  sub rsp, 0x08
00007e2c933e3d1e  push rax
00007e2c933e3d1f  push rcx
00007e2c933e3d20  push rdx
00007e2c933e3d21  push rdi
00007e2c933e3d22  push rsi
00007e2c933e3d23  push r8
00007e2c933e3d25  push r9
00007e2c933e3d27  push r10
00007e2c933e3d29  push r11
00007e2c933e3d2b  sub rsp, 0xF0
00007e2c933e3d32  vmovaps [rsp], xmm0
00007e2c933e3d37  vmovaps [rsp+0x10], xmm1
00007e2c933e3d3d  vmovaps [rsp+0x20], xmm2
00007e2c933e3d43  vmovaps [rsp+0x30], xmm3
00007e2c933e3d49  vmovaps [rsp+0x40], xmm4
00007e2c933e3d4f  vmovaps [rsp+0x50], xmm5
00007e2c933e3d55  vmovaps [rsp+0x60], xmm6
00007e2c933e3d5b  vmovaps [rsp+0x70], xmm7
00007e2c933e3d61  vmovaps [rsp+0x80], xmm8
00007e2c933e3d6a  vmovaps [rsp+0x90], xmm9
00007e2c933e3d73  vmovaps [rsp+0xA0], xmm10
00007e2c933e3d7c  vmovaps [rsp+0xB0], xmm12
00007e2c933e3d85  vmovaps [rsp+0xC0], xmm13
00007e2c933e3d8e  vmovaps [rsp+0xD0], xmm14
00007e2c933e3d97  vmovaps [rsp+0xE0], xmm15
00007e2c933e3da0  sub rsp, 0x30
00007e2c933e3da4  movaps [rsp], xmm11
00007e2c933e3da9  movaps [rsp+0x10], xmm10
00007e2c933e3daf  movaps [rsp+0x20], xmm14
00007e2c933e3db5  lea rdi, [rsp]
00007e2c933e3db9  mov esi, 0x00
00007e2c933e3dbe  mov rax, 0x5A263F1C7530
00007e2c933e3dc8  call rax
00007e2c933e3dca  movaps xmm11, [rsp]
00007e2c933e3dcf  add rsp, 0x30
00007e2c933e3dd3  vmovaps xmm0, [rsp]
00007e2c933e3dd8  vmovaps xmm1, [rsp+0x10]
00007e2c933e3dde  vmovaps xmm2, [rsp+0x20]
00007e2c933e3de4  vmovaps xmm3, [rsp+0x30]
00007e2c933e3dea  vmovaps xmm4, [rsp+0x40]
00007e2c933e3df0  vmovaps xmm5, [rsp+0x50]
00007e2c933e3df6  vmovaps xmm6, [rsp+0x60]
00007e2c933e3dfc  vmovaps xmm7, [rsp+0x70]
00007e2c933e3e02  vmovaps xmm8, [rsp+0x80]
00007e2c933e3e0b  vmovaps xmm9, [rsp+0x90]
00007e2c933e3e14  vmovaps xmm10, [rsp+0xA0]
00007e2c933e3e1d  vmovaps xmm12, [rsp+0xB0]
00007e2c933e3e26  vmovaps xmm13, [rsp+0xC0]
00007e2c933e3e2f  vmovaps xmm14, [rsp+0xD0]
00007e2c933e3e38  vmovaps xmm15, [rsp+0xE0]
00007e2c933e3e41  add rsp, 0xF0
00007e2c933e3e48  pop r11
00007e2c933e3e4a  pop r10
00007e2c933e3e4c  pop r9
00007e2c933e3e4e  pop r8
00007e2c933e3e50  pop rsi
00007e2c933e3e51  pop rdi
00007e2c933e3e52  pop rdx
00007e2c933e3e53  pop rcx
00007e2c933e3e54  pop rax
00007e2c933e3e55  add rsp, 0x08
00007e2c933e3e59  jmp 0x00007E2C933DF880
00007e2c933e3e5e  call 0x00007E2C932C33A0
00007e2c933e3e63  jmp 0x00007E2C933DF88A
00007e2c933e3e68  sub rsp, 0x08
00007e2c933e3e6c  push rax
00007e2c933e3e6d  push rcx
00007e2c933e3e6e  push rdx
00007e2c933e3e6f  push rdi
00007e2c933e3e70  push rsi
00007e2c933e3e71  push r8
00007e2c933e3e73  push r9
00007e2c933e3e75  push r10
00007e2c933e3e77  push r11
00007e2c933e3e79  sub rsp, 0xF0
00007e2c933e3e80  vmovaps [rsp], xmm0
00007e2c933e3e85  vmovaps [rsp+0x10], xmm1
00007e2c933e3e8b  vmovaps [rsp+0x20], xmm2
00007e2c933e3e91  vmovaps [rsp+0x30], xmm3
00007e2c933e3e97  vmovaps [rsp+0x40], xmm4
00007e2c933e3e9d  vmovaps [rsp+0x50], xmm5
00007e2c933e3ea3  vmovaps [rsp+0x60], xmm6
00007e2c933e3ea9  vmovaps [rsp+0x70], xmm7
00007e2c933e3eaf  vmovaps [rsp+0x80], xmm8
00007e2c933e3eb8  vmovaps [rsp+0x90], xmm9
00007e2c933e3ec1  vmovaps [rsp+0xA0], xmm11
00007e2c933e3eca  vmovaps [rsp+0xB0], xmm12
00007e2c933e3ed3  vmovaps [rsp+0xC0], xmm13
00007e2c933e3edc  vmovaps [rsp+0xD0], xmm14
00007e2c933e3ee5  vmovaps [rsp+0xE0], xmm15
00007e2c933e3eee  sub rsp, 0x30
00007e2c933e3ef2  movaps [rsp], xmm10
00007e2c933e3ef7  movaps [rsp+0x10], xmm1
00007e2c933e3efc  movaps [rsp+0x20], xmm12
00007e2c933e3f02  lea rdi, [rsp]
00007e2c933e3f06  mov esi, 0x00
00007e2c933e3f0b  mov rax, 0x5A263F1C7530
00007e2c933e3f15  call rax
00007e2c933e3f17  movaps xmm10, [rsp]
00007e2c933e3f1c  add rsp, 0x30
00007e2c933e3f20  vmovaps xmm0, [rsp]
00007e2c933e3f25  vmovaps xmm1, [rsp+0x10]
00007e2c933e3f2b  vmovaps xmm2, [rsp+0x20]
00007e2c933e3f31  vmovaps xmm3, [rsp+0x30]
00007e2c933e3f37  vmovaps xmm4, [rsp+0x40]
00007e2c933e3f3d  vmovaps xmm5, [rsp+0x50]
00007e2c933e3f43  vmovaps xmm6, [rsp+0x60]
00007e2c933e3f49  vmovaps xmm7, [rsp+0x70]
00007e2c933e3f4f  vmovaps xmm8, [rsp+0x80]
00007e2c933e3f58  vmovaps xmm9, [rsp+0x90]
00007e2c933e3f61  vmovaps xmm11, [rsp+0xA0]
00007e2c933e3f6a  vmovaps xmm12, [rsp+0xB0]
00007e2c933e3f73  vmovaps xmm13, [rsp+0xC0]
00007e2c933e3f7c  vmovaps xmm14, [rsp+0xD0]
00007e2c933e3f85  vmovaps xmm15, [rsp+0xE0]
00007e2c933e3f8e  add rsp, 0xF0
00007e2c933e3f95  pop r11
00007e2c933e3f97  pop r10
00007e2c933e3f99  pop r9
00007e2c933e3f9b  pop r8
00007e2c933e3f9d  pop rsi
00007e2c933e3f9e  pop rdi
00007e2c933e3f9f  pop rdx
00007e2c933e3fa0  pop rcx
00007e2c933e3fa1  pop rax
00007e2c933e3fa2  add rsp, 0x08
00007e2c933e3fa6  jmp 0x00007E2C933DF8AD
00007e2c933e3fab  sub rsp, 0x08
00007e2c933e3faf  push rax
00007e2c933e3fb0  push rcx
00007e2c933e3fb1  push rdx
00007e2c933e3fb2  push rdi
00007e2c933e3fb3  push rsi
00007e2c933e3fb4  push r8
00007e2c933e3fb6  push r9
00007e2c933e3fb8  push r10
00007e2c933e3fba  push r11
00007e2c933e3fbc  sub rsp, 0xF0
00007e2c933e3fc3  vmovaps [rsp], xmm0
00007e2c933e3fc8  vmovaps [rsp+0x10], xmm1
00007e2c933e3fce  vmovaps [rsp+0x20], xmm2
00007e2c933e3fd4  vmovaps [rsp+0x30], xmm3
00007e2c933e3fda  vmovaps [rsp+0x40], xmm4
00007e2c933e3fe0  vmovaps [rsp+0x50], xmm5
00007e2c933e3fe6  vmovaps [rsp+0x60], xmm6
00007e2c933e3fec  vmovaps [rsp+0x70], xmm7
00007e2c933e3ff2  vmovaps [rsp+0x80], xmm8
00007e2c933e3ffb  vmovaps [rsp+0x90], xmm9
00007e2c933e4004  vmovaps [rsp+0xA0], xmm10
00007e2c933e400d  vmovaps [rsp+0xB0], xmm11
00007e2c933e4016  vmovaps [rsp+0xC0], xmm13
00007e2c933e401f  vmovaps [rsp+0xD0], xmm14
00007e2c933e4028  vmovaps [rsp+0xE0], xmm15
00007e2c933e4031  sub rsp, 0x30
00007e2c933e4035  movaps [rsp], xmm12
00007e2c933e403a  movaps [rsp+0x10], xmm14
00007e2c933e4040  movaps [rsp+0x20], xmm1
00007e2c933e4045  lea rdi, [rsp]
00007e2c933e4049  mov esi, 0x00
00007e2c933e404e  mov rax, 0x5A263F1C7530
00007e2c933e4058  call rax
00007e2c933e405a  movaps xmm12, [rsp]
00007e2c933e405f  add rsp, 0x30
00007e2c933e4063  vmovaps xmm0, [rsp]
00007e2c933e4068  vmovaps xmm1, [rsp+0x10]
00007e2c933e406e  vmovaps xmm2, [rsp+0x20]
00007e2c933e4074  vmovaps xmm3, [rsp+0x30]
00007e2c933e407a  vmovaps xmm4, [rsp+0x40]
00007e2c933e4080  vmovaps xmm5, [rsp+0x50]
00007e2c933e4086  vmovaps xmm6, [rsp+0x60]
00007e2c933e408c  vmovaps xmm7, [rsp+0x70]
00007e2c933e4092  vmovaps xmm8, [rsp+0x80]
00007e2c933e409b  vmovaps xmm9, [rsp+0x90]
00007e2c933e40a4  vmovaps xmm10, [rsp+0xA0]
00007e2c933e40ad  vmovaps xmm11, [rsp+0xB0]
00007e2c933e40b6  vmovaps xmm13, [rsp+0xC0]
00007e2c933e40bf  vmovaps xmm14, [rsp+0xD0]
00007e2c933e40c8  vmovaps xmm15, [rsp+0xE0]
00007e2c933e40d1  add rsp, 0xF0
00007e2c933e40d8  pop r11
00007e2c933e40da  pop r10
00007e2c933e40dc  pop r9
00007e2c933e40de  pop r8
00007e2c933e40e0  pop rsi
00007e2c933e40e1  pop rdi
00007e2c933e40e2  pop rdx
00007e2c933e40e3  pop rcx
00007e2c933e40e4  pop rax
00007e2c933e40e5  add rsp, 0x08
00007e2c933e40e9  jmp 0x00007E2C933DF8DC
00007e2c933e40ee  sub rsp, 0x08
00007e2c933e40f2  push rax
00007e2c933e40f3  push rcx
00007e2c933e40f4  push rdx
00007e2c933e40f5  push rdi
00007e2c933e40f6  push rsi
00007e2c933e40f7  push r8
00007e2c933e40f9  push r9
00007e2c933e40fb  push r10
00007e2c933e40fd  push r11
00007e2c933e40ff  sub rsp, 0xF0
00007e2c933e4106  vmovaps [rsp], xmm0
00007e2c933e410b  vmovaps [rsp+0x10], xmm1
00007e2c933e4111  vmovaps [rsp+0x20], xmm2
00007e2c933e4117  vmovaps [rsp+0x30], xmm3
00007e2c933e411d  vmovaps [rsp+0x40], xmm4
00007e2c933e4123  vmovaps [rsp+0x50], xmm5
00007e2c933e4129  vmovaps [rsp+0x60], xmm6
00007e2c933e412f  vmovaps [rsp+0x70], xmm7
00007e2c933e4135  vmovaps [rsp+0x80], xmm8
00007e2c933e413e  vmovaps [rsp+0x90], xmm9
00007e2c933e4147  vmovaps [rsp+0xA0], xmm10
00007e2c933e4150  vmovaps [rsp+0xB0], xmm11
00007e2c933e4159  vmovaps [rsp+0xC0], xmm12
00007e2c933e4162  vmovaps [rsp+0xD0], xmm13
00007e2c933e416b  vmovaps [rsp+0xE0], xmm15
00007e2c933e4174  sub rsp, 0x30
00007e2c933e4178  movaps [rsp], xmm14
00007e2c933e417d  movaps [rsp+0x10], xmm9
00007e2c933e4183  movaps [rsp+0x20], xmm1
00007e2c933e4188  lea rdi, [rsp]
00007e2c933e418c  mov esi, 0x00
00007e2c933e4191  mov rax, 0x5A263F1C7530
00007e2c933e419b  call rax
00007e2c933e419d  movaps xmm14, [rsp]
00007e2c933e41a2  add rsp, 0x30
00007e2c933e41a6  vmovaps xmm0, [rsp]
00007e2c933e41ab  vmovaps xmm1, [rsp+0x10]
00007e2c933e41b1  vmovaps xmm2, [rsp+0x20]
00007e2c933e41b7  vmovaps xmm3, [rsp+0x30]
00007e2c933e41bd  vmovaps xmm4, [rsp+0x40]
00007e2c933e41c3  vmovaps xmm5, [rsp+0x50]
00007e2c933e41c9  vmovaps xmm6, [rsp+0x60]
00007e2c933e41cf  vmovaps xmm7, [rsp+0x70]
00007e2c933e41d5  vmovaps xmm8, [rsp+0x80]
00007e2c933e41de  vmovaps xmm9, [rsp+0x90]
00007e2c933e41e7  vmovaps xmm10, [rsp+0xA0]
00007e2c933e41f0  vmovaps xmm11, [rsp+0xB0]
00007e2c933e41f9  vmovaps xmm12, [rsp+0xC0]
00007e2c933e4202  vmovaps xmm13, [rsp+0xD0]
00007e2c933e420b  vmovaps xmm15, [rsp+0xE0]
00007e2c933e4214  add rsp, 0xF0
00007e2c933e421b  pop r11
00007e2c933e421d  pop r10
00007e2c933e421f  pop r9
00007e2c933e4221  pop r8
00007e2c933e4223  pop rsi
00007e2c933e4224  pop rdi
00007e2c933e4225  pop rdx
00007e2c933e4226  pop rcx
00007e2c933e4227  pop rax
00007e2c933e4228  add rsp, 0x08
00007e2c933e422c  jmp 0x00007E2C933DF90B
00007e2c933e4231  sub rsp, 0x08
00007e2c933e4235  push rax
00007e2c933e4236  push rcx
00007e2c933e4237  push rdx
00007e2c933e4238  push rdi
00007e2c933e4239  push rsi
00007e2c933e423a  push r8
00007e2c933e423c  push r9
00007e2c933e423e  push r10
00007e2c933e4240  push r11
00007e2c933e4242  sub rsp, 0xF0
00007e2c933e4249  vmovaps [rsp], xmm0
00007e2c933e424e  vmovaps [rsp+0x10], xmm2
00007e2c933e4254  vmovaps [rsp+0x20], xmm3
00007e2c933e425a  vmovaps [rsp+0x30], xmm4
00007e2c933e4260  vmovaps [rsp+0x40], xmm5
00007e2c933e4266  vmovaps [rsp+0x50], xmm6
00007e2c933e426c  vmovaps [rsp+0x60], xmm7
00007e2c933e4272  vmovaps [rsp+0x70], xmm8
00007e2c933e4278  vmovaps [rsp+0x80], xmm9
00007e2c933e4281  vmovaps [rsp+0x90], xmm10
00007e2c933e428a  vmovaps [rsp+0xA0], xmm11
00007e2c933e4293  vmovaps [rsp+0xB0], xmm12
00007e2c933e429c  vmovaps [rsp+0xC0], xmm13
00007e2c933e42a5  vmovaps [rsp+0xD0], xmm14
00007e2c933e42ae  vmovaps [rsp+0xE0], xmm15
00007e2c933e42b7  sub rsp, 0x30
00007e2c933e42bb  movaps [rsp], xmm1
00007e2c933e42bf  movaps [rsp+0x10], xmm13
00007e2c933e42c5  movaps [rsp+0x20], xmm8
00007e2c933e42cb  lea rdi, [rsp]
00007e2c933e42cf  mov esi, 0x00
00007e2c933e42d4  mov rax, 0x5A263F1C7530
00007e2c933e42de  call rax
00007e2c933e42e0  movaps xmm1, [rsp]
00007e2c933e42e4  add rsp, 0x30
00007e2c933e42e8  vmovaps xmm0, [rsp]
00007e2c933e42ed  vmovaps xmm2, [rsp+0x10]
00007e2c933e42f3  vmovaps xmm3, [rsp+0x20]
00007e2c933e42f9  vmovaps xmm4, [rsp+0x30]
00007e2c933e42ff  vmovaps xmm5, [rsp+0x40]
00007e2c933e4305  vmovaps xmm6, [rsp+0x50]
00007e2c933e430b  vmovaps xmm7, [rsp+0x60]
00007e2c933e4311  vmovaps xmm8, [rsp+0x70]
00007e2c933e4317  vmovaps xmm9, [rsp+0x80]
00007e2c933e4320  vmovaps xmm10, [rsp+0x90]
00007e2c933e4329  vmovaps xmm11, [rsp+0xA0]
00007e2c933e4332  vmovaps xmm12, [rsp+0xB0]
00007e2c933e433b  vmovaps xmm13, [rsp+0xC0]
00007e2c933e4344  vmovaps xmm14, [rsp+0xD0]
00007e2c933e434d  vmovaps xmm15, [rsp+0xE0]
00007e2c933e4356  add rsp, 0xF0
00007e2c933e435d  pop r11
00007e2c933e435f  pop r10
00007e2c933e4361  pop r9
00007e2c933e4363  pop r8
00007e2c933e4365  pop rsi
00007e2c933e4366  pop rdi
00007e2c933e4367  pop rdx
00007e2c933e4368  pop rcx
00007e2c933e4369  pop rax
00007e2c933e436a  add rsp, 0x08
00007e2c933e436e  jmp 0x00007E2C933DF92D
00007e2c933e4373  call 0x00007E2C9320C260
00007e2c933e4378  jmp 0x00007E2C933DF93B
00007e2c933e437d  call 0x00007E2C932BD750
00007e2c933e4382  jmp 0x00007E2C933DF945
00007e2c933e4387  sub rsp, 0x08
00007e2c933e438b  push rax
00007e2c933e438c  push rcx
00007e2c933e438d  push rdx
00007e2c933e438e  push rdi
00007e2c933e438f  push rsi
00007e2c933e4390  push r8
00007e2c933e4392  push r9
00007e2c933e4394  push r10
00007e2c933e4396  push r11
00007e2c933e4398  sub rsp, 0xF0
00007e2c933e439f  vmovaps [rsp], xmm0
00007e2c933e43a4  vmovaps [rsp+0x10], xmm1
00007e2c933e43aa  vmovaps [rsp+0x20], xmm2
00007e2c933e43b0  vmovaps [rsp+0x30], xmm3
00007e2c933e43b6  vmovaps [rsp+0x40], xmm4
00007e2c933e43bc  vmovaps [rsp+0x50], xmm5
00007e2c933e43c2  vmovaps [rsp+0x60], xmm6
00007e2c933e43c8  vmovaps [rsp+0x70], xmm7
00007e2c933e43ce  vmovaps [rsp+0x80], xmm9
00007e2c933e43d7  vmovaps [rsp+0x90], xmm10
00007e2c933e43e0  vmovaps [rsp+0xA0], xmm11
00007e2c933e43e9  vmovaps [rsp+0xB0], xmm12
00007e2c933e43f2  vmovaps [rsp+0xC0], xmm13
00007e2c933e43fb  vmovaps [rsp+0xD0], xmm14
00007e2c933e4404  vmovaps [rsp+0xE0], xmm15
00007e2c933e440d  sub rsp, 0x30
00007e2c933e4411  movaps [rsp], xmm8
00007e2c933e4416  movaps [rsp+0x10], xmm15
00007e2c933e441c  movaps [rsp+0x20], xmm7
00007e2c933e4421  lea rdi, [rsp]
00007e2c933e4425  mov esi, 0x00
00007e2c933e442a  mov rax, 0x5A263F1C7530
00007e2c933e4434  call rax
00007e2c933e4436  movaps xmm8, [rsp]
00007e2c933e443b  add rsp, 0x30
00007e2c933e443f  vmovaps xmm0, [rsp]
00007e2c933e4444  vmovaps xmm1, [rsp+0x10]
00007e2c933e444a  vmovaps xmm2, [rsp+0x20]
00007e2c933e4450  vmovaps xmm3, [rsp+0x30]
00007e2c933e4456  vmovaps xmm4, [rsp+0x40]
00007e2c933e445c  vmovaps xmm5, [rsp+0x50]
00007e2c933e4462  vmovaps xmm6, [rsp+0x60]
00007e2c933e4468  vmovaps xmm7, [rsp+0x70]
00007e2c933e446e  vmovaps xmm9, [rsp+0x80]
00007e2c933e4477  vmovaps xmm10, [rsp+0x90]
00007e2c933e4480  vmovaps xmm11, [rsp+0xA0]
00007e2c933e4489  vmovaps xmm12, [rsp+0xB0]
00007e2c933e4492  vmovaps xmm13, [rsp+0xC0]
00007e2c933e449b  vmovaps xmm14, [rsp+0xD0]
00007e2c933e44a4  vmovaps xmm15, [rsp+0xE0]
00007e2c933e44ad  add rsp, 0xF0
00007e2c933e44b4  pop r11
00007e2c933e44b6  pop r10
00007e2c933e44b8  pop r9
00007e2c933e44ba  pop r8
00007e2c933e44bc  pop rsi
00007e2c933e44bd  pop rdi
00007e2c933e44be  pop rdx
00007e2c933e44bf  pop rcx
00007e2c933e44c0  pop rax
00007e2c933e44c1  add rsp, 0x08
00007e2c933e44c5  jmp 0x00007E2C933DF967
00007e2c933e44ca  sub rsp, 0x08
00007e2c933e44ce  push rax
00007e2c933e44cf  push rcx
00007e2c933e44d0  push rdx
00007e2c933e44d1  push rdi
00007e2c933e44d2  push rsi
00007e2c933e44d3  push r8
00007e2c933e44d5  push r9
00007e2c933e44d7  push r10
00007e2c933e44d9  push r11
00007e2c933e44db  sub rsp, 0xF0
00007e2c933e44e2  vmovaps [rsp], xmm0
00007e2c933e44e7  vmovaps [rsp+0x10], xmm1
00007e2c933e44ed  vmovaps [rsp+0x20], xmm2
00007e2c933e44f3  vmovaps [rsp+0x30], xmm3
00007e2c933e44f9  vmovaps [rsp+0x40], xmm4
00007e2c933e44ff  vmovaps [rsp+0x50], xmm5
00007e2c933e4505  vmovaps [rsp+0x60], xmm6
00007e2c933e450b  vmovaps [rsp+0x70], xmm8
00007e2c933e4511  vmovaps [rsp+0x80], xmm9
00007e2c933e451a  vmovaps [rsp+0x90], xmm10
00007e2c933e4523  vmovaps [rsp+0xA0], xmm11
00007e2c933e452c  vmovaps [rsp+0xB0], xmm12
00007e2c933e4535  vmovaps [rsp+0xC0], xmm13
00007e2c933e453e  vmovaps [rsp+0xD0], xmm14
00007e2c933e4547  vmovaps [rsp+0xE0], xmm15
00007e2c933e4550  sub rsp, 0x30
00007e2c933e4554  movaps [rsp], xmm7
00007e2c933e4558  movaps [rsp+0x10], xmm9
00007e2c933e455e  movaps [rsp+0x20], xmm15
00007e2c933e4564  lea rdi, [rsp]
00007e2c933e4568  mov esi, 0x00
00007e2c933e456d  mov rax, 0x5A263F1C7530
00007e2c933e4577  call rax
00007e2c933e4579  movaps xmm7, [rsp]
00007e2c933e457d  add rsp, 0x30
00007e2c933e4581  vmovaps xmm0, [rsp]
00007e2c933e4586  vmovaps xmm1, [rsp+0x10]
00007e2c933e458c  vmovaps xmm2, [rsp+0x20]
00007e2c933e4592  vmovaps xmm3, [rsp+0x30]
00007e2c933e4598  vmovaps xmm4, [rsp+0x40]
00007e2c933e459e  vmovaps xmm5, [rsp+0x50]
00007e2c933e45a4  vmovaps xmm6, [rsp+0x60]
00007e2c933e45aa  vmovaps xmm8, [rsp+0x70]
00007e2c933e45b0  vmovaps xmm9, [rsp+0x80]
00007e2c933e45b9  vmovaps xmm10, [rsp+0x90]
00007e2c933e45c2  vmovaps xmm11, [rsp+0xA0]
00007e2c933e45cb  vmovaps xmm12, [rsp+0xB0]
00007e2c933e45d4  vmovaps xmm13, [rsp+0xC0]
00007e2c933e45dd  vmovaps xmm14, [rsp+0xD0]
00007e2c933e45e6  vmovaps xmm15, [rsp+0xE0]
00007e2c933e45ef  add rsp, 0xF0
00007e2c933e45f6  pop r11
00007e2c933e45f8  pop r10
00007e2c933e45fa  pop r9
00007e2c933e45fc  pop r8
00007e2c933e45fe  pop rsi
00007e2c933e45ff  pop rdi
00007e2c933e4600  pop rdx
00007e2c933e4601  pop rcx
00007e2c933e4602  pop rax
00007e2c933e4603  add rsp, 0x08
00007e2c933e4607  jmp 0x00007E2C933DF994
00007e2c933e460c  sub rsp, 0x08
00007e2c933e4610  push rax
00007e2c933e4611  push rcx
00007e2c933e4612  push rdx
00007e2c933e4613  push rdi
00007e2c933e4614  push rsi
00007e2c933e4615  push r8
00007e2c933e4617  push r9
00007e2c933e4619  push r10
00007e2c933e461b  push r11
00007e2c933e461d  sub rsp, 0xF0
00007e2c933e4624  vmovaps [rsp], xmm0
00007e2c933e4629  vmovaps [rsp+0x10], xmm1
00007e2c933e462f  vmovaps [rsp+0x20], xmm2
00007e2c933e4635  vmovaps [rsp+0x30], xmm3
00007e2c933e463b  vmovaps [rsp+0x40], xmm4
00007e2c933e4641  vmovaps [rsp+0x50], xmm5
00007e2c933e4647  vmovaps [rsp+0x60], xmm6
00007e2c933e464d  vmovaps [rsp+0x70], xmm7
00007e2c933e4653  vmovaps [rsp+0x80], xmm8
00007e2c933e465c  vmovaps [rsp+0x90], xmm10
00007e2c933e4665  vmovaps [rsp+0xA0], xmm11
00007e2c933e466e  vmovaps [rsp+0xB0], xmm12
00007e2c933e4677  vmovaps [rsp+0xC0], xmm13
00007e2c933e4680  vmovaps [rsp+0xD0], xmm14
00007e2c933e4689  vmovaps [rsp+0xE0], xmm15
00007e2c933e4692  sub rsp, 0x30
00007e2c933e4696  movaps [rsp], xmm9
00007e2c933e469b  movaps [rsp+0x10], xmm13
00007e2c933e46a1  movaps [rsp+0x20], xmm15
00007e2c933e46a7  lea rdi, [rsp]
00007e2c933e46ab  mov esi, 0x00
00007e2c933e46b0  mov rax, 0x5A263F1C7530
00007e2c933e46ba  call rax
00007e2c933e46bc  movaps xmm9, [rsp]
00007e2c933e46c1  add rsp, 0x30
00007e2c933e46c5  vmovaps xmm0, [rsp]
00007e2c933e46ca  vmovaps xmm1, [rsp+0x10]
00007e2c933e46d0  vmovaps xmm2, [rsp+0x20]
00007e2c933e46d6  vmovaps xmm3, [rsp+0x30]
00007e2c933e46dc  vmovaps xmm4, [rsp+0x40]
00007e2c933e46e2  vmovaps xmm5, [rsp+0x50]
00007e2c933e46e8  vmovaps xmm6, [rsp+0x60]
00007e2c933e46ee  vmovaps xmm7, [rsp+0x70]
00007e2c933e46f4  vmovaps xmm8, [rsp+0x80]
00007e2c933e46fd  vmovaps xmm10, [rsp+0x90]
00007e2c933e4706  vmovaps xmm11, [rsp+0xA0]
00007e2c933e470f  vmovaps xmm12, [rsp+0xB0]
00007e2c933e4718  vmovaps xmm13, [rsp+0xC0]
00007e2c933e4721  vmovaps xmm14, [rsp+0xD0]
00007e2c933e472a  vmovaps xmm15, [rsp+0xE0]
00007e2c933e4733  add rsp, 0xF0
00007e2c933e473a  pop r11
00007e2c933e473c  pop r10
00007e2c933e473e  pop r9
00007e2c933e4740  pop r8
00007e2c933e4742  pop rsi
00007e2c933e4743  pop rdi
00007e2c933e4744  pop rdx
00007e2c933e4745  pop rcx
00007e2c933e4746  pop rax
00007e2c933e4747  add rsp, 0x08
00007e2c933e474b  jmp 0x00007E2C933DF9C2
00007e2c933e4750  sub rsp, 0x08
00007e2c933e4754  push rax
00007e2c933e4755  push rcx
00007e2c933e4756  push rdx
00007e2c933e4757  push rdi
00007e2c933e4758  push rsi
00007e2c933e4759  push r8
00007e2c933e475b  push r9
00007e2c933e475d  push r10
00007e2c933e475f  push r11
00007e2c933e4761  sub rsp, 0xF0
00007e2c933e4768  vmovaps [rsp], xmm0
00007e2c933e476d  vmovaps [rsp+0x10], xmm1
00007e2c933e4773  vmovaps [rsp+0x20], xmm2
00007e2c933e4779  vmovaps [rsp+0x30], xmm3
00007e2c933e477f  vmovaps [rsp+0x40], xmm4
00007e2c933e4785  vmovaps [rsp+0x50], xmm5
00007e2c933e478b  vmovaps [rsp+0x60], xmm6
00007e2c933e4791  vmovaps [rsp+0x70], xmm7
00007e2c933e4797  vmovaps [rsp+0x80], xmm8
00007e2c933e47a0  vmovaps [rsp+0x90], xmm9
00007e2c933e47a9  vmovaps [rsp+0xA0], xmm10
00007e2c933e47b2  vmovaps [rsp+0xB0], xmm11
00007e2c933e47bb  vmovaps [rsp+0xC0], xmm12
00007e2c933e47c4  vmovaps [rsp+0xD0], xmm13
00007e2c933e47cd  vmovaps [rsp+0xE0], xmm14
00007e2c933e47d6  sub rsp, 0x30
00007e2c933e47da  movaps [rsp], xmm15
00007e2c933e47df  movaps [rsp+0x10], xmm11
00007e2c933e47e5  movaps [rsp+0x20], xmm12
00007e2c933e47eb  lea rdi, [rsp]
00007e2c933e47ef  mov esi, 0x00
00007e2c933e47f4  mov rax, 0x5A263F1C7530
00007e2c933e47fe  call rax
00007e2c933e4800  movaps xmm15, [rsp]
00007e2c933e4805  add rsp, 0x30
00007e2c933e4809  vmovaps xmm0, [rsp]
00007e2c933e480e  vmovaps xmm1, [rsp+0x10]
00007e2c933e4814  vmovaps xmm2, [rsp+0x20]
00007e2c933e481a  vmovaps xmm3, [rsp+0x30]
00007e2c933e4820  vmovaps xmm4, [rsp+0x40]
00007e2c933e4826  vmovaps xmm5, [rsp+0x50]
00007e2c933e482c  vmovaps xmm6, [rsp+0x60]
00007e2c933e4832  vmovaps xmm7, [rsp+0x70]
00007e2c933e4838  vmovaps xmm8, [rsp+0x80]
00007e2c933e4841  vmovaps xmm9, [rsp+0x90]
00007e2c933e484a  vmovaps xmm10, [rsp+0xA0]
00007e2c933e4853  vmovaps xmm11, [rsp+0xB0]
00007e2c933e485c  vmovaps xmm12, [rsp+0xC0]
00007e2c933e4865  vmovaps xmm13, [rsp+0xD0]
00007e2c933e486e  vmovaps xmm14, [rsp+0xE0]
00007e2c933e4877  add rsp, 0xF0
00007e2c933e487e  pop r11
00007e2c933e4880  pop r10
00007e2c933e4882  pop r9
00007e2c933e4884  pop r8
00007e2c933e4886  pop rsi
00007e2c933e4887  pop rdi
00007e2c933e4888  pop rdx
00007e2c933e4889  pop rcx
00007e2c933e488a  pop rax
00007e2c933e488b  add rsp, 0x08
00007e2c933e488f  jmp 0x00007E2C933DF9DD
00007e2c933e4894  sub rsp, 0x08
00007e2c933e4898  push rax
00007e2c933e4899  push rcx
00007e2c933e489a  push rdx
00007e2c933e489b  push rdi
00007e2c933e489c  push rsi
00007e2c933e489d  push r8
00007e2c933e489f  push r9
00007e2c933e48a1  push r10
00007e2c933e48a3  push r11
00007e2c933e48a5  sub rsp, 0xF0
00007e2c933e48ac  vmovaps [rsp], xmm0
00007e2c933e48b1  vmovaps [rsp+0x10], xmm1
00007e2c933e48b7  vmovaps [rsp+0x20], xmm2
00007e2c933e48bd  vmovaps [rsp+0x30], xmm3
00007e2c933e48c3  vmovaps [rsp+0x40], xmm4
00007e2c933e48c9  vmovaps [rsp+0x50], xmm5
00007e2c933e48cf  vmovaps [rsp+0x60], xmm6
00007e2c933e48d5  vmovaps [rsp+0x70], xmm7
00007e2c933e48db  vmovaps [rsp+0x80], xmm8
00007e2c933e48e4  vmovaps [rsp+0x90], xmm9
00007e2c933e48ed  vmovaps [rsp+0xA0], xmm10
00007e2c933e48f6  vmovaps [rsp+0xB0], xmm11
00007e2c933e48ff  vmovaps [rsp+0xC0], xmm12
00007e2c933e4908  vmovaps [rsp+0xD0], xmm14
00007e2c933e4911  vmovaps [rsp+0xE0], xmm15
00007e2c933e491a  sub rsp, 0x30
00007e2c933e491e  movaps [rsp], xmm13
00007e2c933e4923  movaps [rsp+0x10], xmm10
00007e2c933e4929  movaps [rsp+0x20], xmm14
00007e2c933e492f  lea rdi, [rsp]
00007e2c933e4933  mov esi, 0x00
00007e2c933e4938  mov rax, 0x5A263F1C7530
00007e2c933e4942  call rax
00007e2c933e4944  movaps xmm13, [rsp]
00007e2c933e4949  add rsp, 0x30
00007e2c933e494d  vmovaps xmm0, [rsp]
00007e2c933e4952  vmovaps xmm1, [rsp+0x10]
00007e2c933e4958  vmovaps xmm2, [rsp+0x20]
00007e2c933e495e  vmovaps xmm3, [rsp+0x30]
00007e2c933e4964  vmovaps xmm4, [rsp+0x40]
00007e2c933e496a  vmovaps xmm5, [rsp+0x50]
00007e2c933e4970  vmovaps xmm6, [rsp+0x60]
00007e2c933e4976  vmovaps xmm7, [rsp+0x70]
00007e2c933e497c  vmovaps xmm8, [rsp+0x80]
00007e2c933e4985  vmovaps xmm9, [rsp+0x90]
00007e2c933e498e  vmovaps xmm10, [rsp+0xA0]
00007e2c933e4997  vmovaps xmm11, [rsp+0xB0]
00007e2c933e49a0  vmovaps xmm12, [rsp+0xC0]
00007e2c933e49a9  vmovaps xmm14, [rsp+0xD0]
00007e2c933e49b2  vmovaps xmm15, [rsp+0xE0]
00007e2c933e49bb  add rsp, 0xF0
00007e2c933e49c2  pop r11
00007e2c933e49c4  pop r10
00007e2c933e49c6  pop r9
00007e2c933e49c8  pop r8
00007e2c933e49ca  pop rsi
00007e2c933e49cb  pop rdi
00007e2c933e49cc  pop rdx
00007e2c933e49cd  pop rcx
00007e2c933e49ce  pop rax
00007e2c933e49cf  add rsp, 0x08
00007e2c933e49d3  jmp 0x00007E2C933DFA00
00007e2c933e49d8  sub rsp, 0x08
00007e2c933e49dc  push rax
00007e2c933e49dd  push rcx
00007e2c933e49de  push rdx
00007e2c933e49df  push rdi
00007e2c933e49e0  push rsi
00007e2c933e49e1  push r8
00007e2c933e49e3  push r9
00007e2c933e49e5  push r10
00007e2c933e49e7  push r11
00007e2c933e49e9  sub rsp, 0xF0
00007e2c933e49f0  vmovaps [rsp], xmm0
00007e2c933e49f5  vmovaps [rsp+0x10], xmm1
00007e2c933e49fb  vmovaps [rsp+0x20], xmm2
00007e2c933e4a01  vmovaps [rsp+0x30], xmm3
00007e2c933e4a07  vmovaps [rsp+0x40], xmm4
00007e2c933e4a0d  vmovaps [rsp+0x50], xmm5
00007e2c933e4a13  vmovaps [rsp+0x60], xmm6
00007e2c933e4a19  vmovaps [rsp+0x70], xmm7
00007e2c933e4a1f  vmovaps [rsp+0x80], xmm8
00007e2c933e4a28  vmovaps [rsp+0x90], xmm9
00007e2c933e4a31  vmovaps [rsp+0xA0], xmm10
00007e2c933e4a3a  vmovaps [rsp+0xB0], xmm11
00007e2c933e4a43  vmovaps [rsp+0xC0], xmm12
00007e2c933e4a4c  vmovaps [rsp+0xD0], xmm13
00007e2c933e4a55  vmovaps [rsp+0xE0], xmm15
00007e2c933e4a5e  sub rsp, 0x30
00007e2c933e4a62  movaps [rsp], xmm14
00007e2c933e4a67  movaps [rsp+0x10], xmm1
00007e2c933e4a6c  movaps [rsp+0x20], xmm7
00007e2c933e4a71  lea rdi, [rsp]
00007e2c933e4a75  mov esi, 0x00
00007e2c933e4a7a  mov rax, 0x5A263F1C7530
00007e2c933e4a84  call rax
00007e2c933e4a86  movaps xmm14, [rsp]
00007e2c933e4a8b  add rsp, 0x30
00007e2c933e4a8f  vmovaps xmm0, [rsp]
00007e2c933e4a94  vmovaps xmm1, [rsp+0x10]
00007e2c933e4a9a  vmovaps xmm2, [rsp+0x20]
00007e2c933e4aa0  vmovaps xmm3, [rsp+0x30]
00007e2c933e4aa6  vmovaps xmm4, [rsp+0x40]
00007e2c933e4aac  vmovaps xmm5, [rsp+0x50]
00007e2c933e4ab2  vmovaps xmm6, [rsp+0x60]
00007e2c933e4ab8  vmovaps xmm7, [rsp+0x70]
00007e2c933e4abe  vmovaps xmm8, [rsp+0x80]
00007e2c933e4ac7  vmovaps xmm9, [rsp+0x90]
00007e2c933e4ad0  vmovaps xmm10, [rsp+0xA0]
00007e2c933e4ad9  vmovaps xmm11, [rsp+0xB0]
00007e2c933e4ae2  vmovaps xmm12, [rsp+0xC0]
00007e2c933e4aeb  vmovaps xmm13, [rsp+0xD0]
00007e2c933e4af4  vmovaps xmm15, [rsp+0xE0]
00007e2c933e4afd  add rsp, 0xF0
00007e2c933e4b04  pop r11
00007e2c933e4b06  pop r10
00007e2c933e4b08  pop r9
00007e2c933e4b0a  pop r8
00007e2c933e4b0c  pop rsi
00007e2c933e4b0d  pop rdi
00007e2c933e4b0e  pop rdx
00007e2c933e4b0f  pop rcx
00007e2c933e4b10  pop rax
00007e2c933e4b11  add rsp, 0x08
00007e2c933e4b15  jmp 0x00007E2C933DFA23
00007e2c933e4b1a  sub rsp, 0x08
00007e2c933e4b1e  push rax
00007e2c933e4b1f  push rcx
00007e2c933e4b20  push rdx
00007e2c933e4b21  push rdi
00007e2c933e4b22  push rsi
00007e2c933e4b23  push r8
00007e2c933e4b25  push r9
00007e2c933e4b27  push r10
00007e2c933e4b29  push r11
00007e2c933e4b2b  sub rsp, 0xF0
00007e2c933e4b32  vmovaps [rsp], xmm0
00007e2c933e4b37  vmovaps [rsp+0x10], xmm2
00007e2c933e4b3d  vmovaps [rsp+0x20], xmm3
00007e2c933e4b43  vmovaps [rsp+0x30], xmm4
00007e2c933e4b49  vmovaps [rsp+0x40], xmm5
00007e2c933e4b4f  vmovaps [rsp+0x50], xmm6
00007e2c933e4b55  vmovaps [rsp+0x60], xmm7
00007e2c933e4b5b  vmovaps [rsp+0x70], xmm8
00007e2c933e4b61  vmovaps [rsp+0x80], xmm9
00007e2c933e4b6a  vmovaps [rsp+0x90], xmm10
00007e2c933e4b73  vmovaps [rsp+0xA0], xmm11
00007e2c933e4b7c  vmovaps [rsp+0xB0], xmm12
00007e2c933e4b85  vmovaps [rsp+0xC0], xmm13
00007e2c933e4b8e  vmovaps [rsp+0xD0], xmm14
00007e2c933e4b97  vmovaps [rsp+0xE0], xmm15
00007e2c933e4ba0  sub rsp, 0x30
00007e2c933e4ba4  movaps [rsp], xmm1
00007e2c933e4ba8  movaps [rsp+0x10], xmm8
00007e2c933e4bae  movaps [rsp+0x20], xmm9
00007e2c933e4bb4  lea rdi, [rsp]
00007e2c933e4bb8  mov esi, 0x00
00007e2c933e4bbd  mov rax, 0x5A263F1C7530
00007e2c933e4bc7  call rax
00007e2c933e4bc9  movaps xmm1, [rsp]
00007e2c933e4bcd  add rsp, 0x30
00007e2c933e4bd1  vmovaps xmm0, [rsp]
00007e2c933e4bd6  vmovaps xmm2, [rsp+0x10]
00007e2c933e4bdc  vmovaps xmm3, [rsp+0x20]
00007e2c933e4be2  vmovaps xmm4, [rsp+0x30]
00007e2c933e4be8  vmovaps xmm5, [rsp+0x40]
00007e2c933e4bee  vmovaps xmm6, [rsp+0x50]
00007e2c933e4bf4  vmovaps xmm7, [rsp+0x60]
00007e2c933e4bfa  vmovaps xmm8, [rsp+0x70]
00007e2c933e4c00  vmovaps xmm9, [rsp+0x80]
00007e2c933e4c09  vmovaps xmm10, [rsp+0x90]
00007e2c933e4c12  vmovaps xmm11, [rsp+0xA0]
00007e2c933e4c1b  vmovaps xmm12, [rsp+0xB0]
00007e2c933e4c24  vmovaps xmm13, [rsp+0xC0]
00007e2c933e4c2d  vmovaps xmm14, [rsp+0xD0]
00007e2c933e4c36  vmovaps xmm15, [rsp+0xE0]
00007e2c933e4c3f  add rsp, 0xF0
00007e2c933e4c46  pop r11
00007e2c933e4c48  pop r10
00007e2c933e4c4a  pop r9
00007e2c933e4c4c  pop r8
00007e2c933e4c4e  pop rsi
00007e2c933e4c4f  pop rdi
00007e2c933e4c50  pop rdx
00007e2c933e4c51  pop rcx
00007e2c933e4c52  pop rax
00007e2c933e4c53  add rsp, 0x08
00007e2c933e4c57  jmp 0x00007E2C933DFA45
00007e2c933e4c5c  call 0x00007E2C932E5940
00007e2c933e4c61  jmp 0x00007E2C933DFA53
00007e2c933e4c66  call 0x00007E2C9320C380
00007e2c933e4c6b  jmp 0x00007E2C933DFA5D
00007e2c933e4c70  call 0x00007E2C9320D600
00007e2c933e4c75  jmp 0x00007E2C933DFA67
00007e2c933e4c7a  call 0x00007E2C931FF540
00007e2c933e4c7f  jmp 0x00007E2C933DFA71
00007e2c933e4c84  int3
00007e2c933e4c85  nop [rax+rax*1], ax
00007e2c933e4c8e  nop
00007e2c933e4c90  mov qword ptr [r15+0x40], 0x430000
00007e2c933e4c98  mov eax, 0x430CC0
00007e2c933e4c9d  mov r14, [r13+rax*1]
00007e2c933e4ca2  movq xmm1, r14
00007e2c933e4ca7  mov rax, [r15+0x50]
00007e2c933e4cab  movups xmm15, [r13+rax*1]
00007e2c933e4cb1  movaps [r15+0x120], xmm15
00007e2c933e4cb9  mov qword ptr [r15+0x48], 0x10
00007e2c933e4cc1  xor eax, eax
00007e2c933e4cc3  mov r14d, 0x10
00007e2c933e4cc9  mov r12d, 0x200
00007e2c933e4ccf  cmp r14, r12
00007e2c933e4cd2  cmc
00007e2c933e4cd3  lahf
00007e2c933e4cd4  seto al
00007e2c933e4cd7  mov [r15+0x108], eax
00007e2c933e4cde  pextrq rax, xmm15, 0x01
00007e2c933e4ce5  movq xmm14, rax
00007e2c933e4cea  movaps [r15+0x130], xmm14
00007e2c933e4cf2  movq rax, xmm1
00007e2c933e4cf7  movq r14, xmm15
00007e2c933e4cfc  vmovq xmm1, rax
00007e2c933e4d01  vmovq xmm15, r14
00007e2c933e4d06  movaps xmm13, xmm1
00007e2c933e4d0a  addsd xmm13, xmm15
00007e2c933e4d0f  ucomisd xmm13, xmm13
00007e2c933e4d14  jp 0x00007E2C933E4DD3
00007e2c933e4d1a  movq xmm13, xmm13
00007e2c933e4d1f  movq rax, xmm13
00007e2c933e4d24  movq r14, xmm14
00007e2c933e4d29  vmovq xmm1, rax
00007e2c933e4d2e  vmovq xmm15, r14
00007e2c933e4d33  movaps xmm14, xmm1
00007e2c933e4d37  addsd xmm14, xmm15
00007e2c933e4d3c  ucomisd xmm14, xmm14
00007e2c933e4d41  jp 0x00007E2C933E4E1B
00007e2c933e4d47  movq xmm14, xmm14
00007e2c933e4d4c  movaps [r15+0x110], xmm14
00007e2c933e4d54  mov eax, [r15+0x108]
00007e2c933e4d5b  sahf
00007e2c933e4d5c  jnz 0x00007E2C933E4D8E
00007e2c933e4d5e  cmp dword ptr [r15+0x318], 0x00
00007e2c933e4d66  jz 0x00007E2C933E5030
00007e2c933e4d6c  nop [rax+rax*1], ax
00007e2c933e4d75  nop [rax+rax*1], eax
00007e2c933e4d7d  mov eax, 0x410704
00007e2c933e4d82  mov [r15+0x100], rax
00007e2c933e4d89  jmp 0x00007E2C931FE110
00007e2c933e4d8e  cmp dword ptr [r15+0x318], 0x00
00007e2c933e4d96  jz 0x00007E2C933E4E70
00007e2c933e4d9c  nop [rax+rax*1], ax
00007e2c933e4da5  nop [rax+rax*1], eax
00007e2c933e4dad  mov eax, 0x4106E8
00007e2c933e4db2  mov [r15+0x100], rax
00007e2c933e4db9  jmp 0x00007E2C931FE110
00007e2c933e4dbe  int3
00007e2c933e4dbf  call 0x00007E2C9320DC20
00007e2c933e4dc4  jmp 0x00007E2C933E4CA2
00007e2c933e4dc9  call 0x00007E2C9320E760
00007e2c933e4dce  jmp 0x00007E2C933E4CB1
00007e2c933e4dd3  ucomisd xmm1, xmm15
00007e2c933e4dd8  jp 0x00007E2C933E4DE7
00007e2c933e4dda  movaps xmm13, [0x00007E2C92FFE060]
00007e2c933e4de2  jmp 0x00007E2C933E4D1A
00007e2c933e4de7  vxorps xmm0, xmm1, xmm15
00007e2c933e4dec  pextrw eax, xmm0, 0x03
00007e2c933e4df1  and eax, 0x7FF8
00007e2c933e4df6  cmp eax, 0x08
00007e2c933e4df9  jnz 0x00007E2C933E4D1A
00007e2c933e4dff  movq rax, xmm15
00007e2c933e4e04  shl rax, 0x0D
00007e2c933e4e08  jbe 0x00007E2C933E4D1A
00007e2c933e4e0e  vorps xmm13, xmm15, [0x00007E2C92FFE070]
00007e2c933e4e16  jmp 0x00007E2C933E4D1A
00007e2c933e4e1b  ucomisd xmm1, xmm15
00007e2c933e4e20  jp 0x00007E2C933E4E2F
00007e2c933e4e22  movaps xmm14, [0x00007E2C92FFE060]
00007e2c933e4e2a  jmp 0x00007E2C933E4D47
00007e2c933e4e2f  vxorps xmm0, xmm1, xmm15
00007e2c933e4e34  pextrw eax, xmm0, 0x03
00007e2c933e4e39  and eax, 0x7FF8
00007e2c933e4e3e  cmp eax, 0x08
00007e2c933e4e41  jnz 0x00007E2C933E4D47
00007e2c933e4e47  movq rax, xmm15
00007e2c933e4e4c  shl rax, 0x0D
00007e2c933e4e50  jbe 0x00007E2C933E4D47
00007e2c933e4e56  vorps xmm14, xmm15, [0x00007E2C92FFE070]
00007e2c933e4e5e  jmp 0x00007E2C933E4D47
00007e2c933e4e63  int3
00007e2c933e4e64  nop [rax+rax*1], ax
00007e2c933e4e6d  nop [rax], eax
00007e2c933e4e70  mov rax, [r15+0x48]
00007e2c933e4e74  mov r14, [r15+0x50]
00007e2c933e4e78  lea r12, [r14+rax*1]
00007e2c933e4e7c  movups xmm1, [r13+r12*1]
00007e2c933e4e82  movaps [r15+0x120], xmm1
00007e2c933e4e8a  lea r14, [rax+0x10]
00007e2c933e4e8e  mov [r15+0x48], r14
00007e2c933e4e92  xor eax, eax
00007e2c933e4e94  mov r12d, 0x200
00007e2c933e4e9a  cmp r14, r12
00007e2c933e4e9d  cmc
00007e2c933e4e9e  lahf
00007e2c933e4e9f  seto al
00007e2c933e4ea2  mov [r15+0x108], eax
00007e2c933e4ea9  pextrq rax, xmm1, 0x01
00007e2c933e4eb0  movq xmm15, rax
00007e2c933e4eb5  movaps [r15+0x130], xmm15
00007e2c933e4ebd  movaps xmm14, [r15+0x110]
00007e2c933e4ec5  movq rax, xmm14
00007e2c933e4eca  movq r14, xmm1
00007e2c933e4ecf  vmovq xmm1, rax
00007e2c933e4ed4  vmovq xmm14, r14
00007e2c933e4ed9  movaps xmm13, xmm1
00007e2c933e4edd  addsd xmm13, xmm14
00007e2c933e4ee2  ucomisd xmm13, xmm13
00007e2c933e4ee7  jp 0x00007E2C933E4F9C
00007e2c933e4eed  movq xmm13, xmm13
00007e2c933e4ef2  movq rax, xmm13
00007e2c933e4ef7  movq r14, xmm15
00007e2c933e4efc  vmovq xmm1, rax
00007e2c933e4f01  vmovq xmm15, r14
00007e2c933e4f06  movaps xmm14, xmm1
00007e2c933e4f0a  addsd xmm14, xmm15
00007e2c933e4f0f  ucomisd xmm14, xmm14
00007e2c933e4f14  jp 0x00007E2C933E4FE4
00007e2c933e4f1a  movq xmm14, xmm14
00007e2c933e4f1f  movaps [r15+0x110], xmm14
00007e2c933e4f27  mov eax, [r15+0x108]
00007e2c933e4f2e  sahf
00007e2c933e4f2f  jnz 0x00007E2C933E4F61
00007e2c933e4f31  cmp dword ptr [r15+0x318], 0x00
00007e2c933e4f39  jz 0x00007E2C933E5030
00007e2c933e4f3f  nop [rax+rax*1], ax
00007e2c933e4f48  nop [rax+rax*1], eax
00007e2c933e4f50  mov eax, 0x410704
00007e2c933e4f55  mov [r15+0x100], rax
00007e2c933e4f5c  jmp 0x00007E2C931FE110
00007e2c933e4f61  cmp dword ptr [r15+0x318], 0x00
00007e2c933e4f69  jz 0x00007E2C933E4E70
00007e2c933e4f6f  nop [rax+rax*1], ax
00007e2c933e4f78  nop [rax+rax*1], eax
00007e2c933e4f80  mov eax, 0x4106E8
00007e2c933e4f85  mov [r15+0x100], rax
00007e2c933e4f8c  jmp 0x00007E2C931FE110
00007e2c933e4f91  int3
00007e2c933e4f92  call 0x00007E2C932B52F0
00007e2c933e4f97  jmp 0x00007E2C933E4E82
00007e2c933e4f9c  ucomisd xmm1, xmm14
00007e2c933e4fa1  jp 0x00007E2C933E4FB0
00007e2c933e4fa3  movaps xmm13, [0x00007E2C92FFE060]
00007e2c933e4fab  jmp 0x00007E2C933E4EED
00007e2c933e4fb0  vxorps xmm0, xmm1, xmm14
00007e2c933e4fb5  pextrw eax, xmm0, 0x03
00007e2c933e4fba  and eax, 0x7FF8
00007e2c933e4fbf  cmp eax, 0x08
00007e2c933e4fc2  jnz 0x00007E2C933E4EED
00007e2c933e4fc8  movq rax, xmm14
00007e2c933e4fcd  shl rax, 0x0D
00007e2c933e4fd1  jbe 0x00007E2C933E4EED
00007e2c933e4fd7  vorps xmm13, xmm14, [0x00007E2C92FFE070]
00007e2c933e4fdf  jmp 0x00007E2C933E4EED
00007e2c933e4fe4  ucomisd xmm1, xmm15
00007e2c933e4fe9  jp 0x00007E2C933E4FF8
00007e2c933e4feb  movaps xmm14, [0x00007E2C92FFE060]
00007e2c933e4ff3  jmp 0x00007E2C933E4F1A
00007e2c933e4ff8  vxorps xmm0, xmm1, xmm15
00007e2c933e4ffd  pextrw eax, xmm0, 0x03
00007e2c933e5002  and eax, 0x7FF8
00007e2c933e5007  cmp eax, 0x08
00007e2c933e500a  jnz 0x00007E2C933E4F1A
00007e2c933e5010  movq rax, xmm15
00007e2c933e5015  shl rax, 0x0D
00007e2c933e5019  jbe 0x00007E2C933E4F1A
00007e2c933e501f  vorps xmm14, xmm15, [0x00007E2C92FFE070]
00007e2c933e5027  jmp 0x00007E2C933E4F1A
00007e2c933e502c  int3
00007e2c933e502d  nop [rax], eax
00007e2c933e5030  mov rax, [r15+0xF8]
00007e2c933e5037  lea r14, [rax+0x1D0]
00007e2c933e503e  mov r12, [r13+r14*1]
00007e2c933e5043  lea r14, [rax+0x1D8]
00007e2c933e504a  mov r11, [r13+r14*1]
00007e2c933e504f  mov [r15+0xA0], r12
00007e2c933e5056  mov [r15+0x98], r11
00007e2c933e505d  mov r14, [r15+0x40]
00007e2c933e5061  lea r12, [r14+0xCC0]
00007e2c933e5068  movaps xmm1, [r15+0x110]
00007e2c933e5070  movq r14, xmm1
00007e2c933e5075  mov [r13+r12*1], r14
00007e2c933e507a  lea r14, [rax+0x1C0]
00007e2c933e5081  mov r12, [r13+r14*1]
00007e2c933e5086  lea r14, [rax+0x1C8]
00007e2c933e508d  mov r11, [r13+r14*1]
00007e2c933e5092  mov [r15+0xE8], r12
00007e2c933e5099  mov [r15+0xF0], r11
00007e2c933e50a0  lea r14, [rax+0x1B0]
00007e2c933e50a7  mov r12, [r13+r14*1]
00007e2c933e50ac  lea r14, [rax+0x1B8]
00007e2c933e50b3  mov r10, [r13+r14*1]
00007e2c933e50b8  movq xmm1, r12
00007e2c933e50bd  movq xmm15, r10
00007e2c933e50c2  movq xmm1, xmm1
00007e2c933e50c6  movq xmm1, xmm1
00007e2c933e50ca  movaps [r15+0x1A0], xmm1
00007e2c933e50d2  movq xmm15, xmm15
00007e2c933e50d7  movq xmm15, xmm15
00007e2c933e50dc  movaps [r15+0x190], xmm15
00007e2c933e50e4  lea r14, [rax+0x1A0]
00007e2c933e50eb  mov r12, [r13+r14*1]
00007e2c933e50f0  lea r14, [rax+0x1A8]
00007e2c933e50f7  mov r10, [r13+r14*1]
00007e2c933e50fc  movq xmm1, r12
00007e2c933e5101  movq xmm15, r10
00007e2c933e5106  movq xmm1, xmm1
00007e2c933e510a  movq xmm1, xmm1
00007e2c933e510e  movaps [r15+0x1C0], xmm1
00007e2c933e5116  movq xmm15, xmm15
00007e2c933e511b  movq xmm15, xmm15
00007e2c933e5120  movaps [r15+0x1B0], xmm15
00007e2c933e5128  lea r14, [rax+0x190]
00007e2c933e512f  mov r12, [r13+r14*1]
00007e2c933e5134  lea r14, [rax+0x198]
00007e2c933e513b  mov r10, [r13+r14*1]
00007e2c933e5140  movq xmm1, r12
00007e2c933e5145  movq xmm15, r10
00007e2c933e514a  movq xmm1, xmm1
00007e2c933e514e  movq xmm1, xmm1
00007e2c933e5152  movaps [r15+0x1E0], xmm1
00007e2c933e515a  movq xmm15, xmm15
00007e2c933e515f  movq xmm15, xmm15
00007e2c933e5164  movaps [r15+0x1D0], xmm15
00007e2c933e516c  lea r14, [rax+0x180]
00007e2c933e5173  mov r12, [r13+r14*1]
00007e2c933e5178  lea r14, [rax+0x188]
00007e2c933e517f  mov r10, [r13+r14*1]
00007e2c933e5184  movq xmm1, r12
00007e2c933e5189  movq xmm15, r10
00007e2c933e518e  movq xmm1, xmm1
00007e2c933e5192  movq xmm1, xmm1
00007e2c933e5196  movaps [r15+0x200], xmm1
00007e2c933e519e  movq xmm15, xmm15
00007e2c933e51a3  movq xmm15, xmm15
00007e2c933e51a8  movaps [r15+0x1F0], xmm15
00007e2c933e51b0  lea r14, [rax+0x1E0]
00007e2c933e51b7  mov [r15+0xF8], r14
00007e2c933e51be  mov [r15+0x100], r11
00007e2c933e51c5  jmp 0x00007E2C933CE5C0
00007e2c933e51ca  int3
00007e2c933e51cb  call 0x00007E2C932E27E0
00007e2c933e51d0  jmp 0x00007E2C933E5043
00007e2c933e51d5  call 0x00007E2C932E1570
00007e2c933e51da  jmp 0x00007E2C933E504F
00007e2c933e51df  call 0x00007E2C932C3FE0
00007e2c933e51e4  jmp 0x00007E2C933E507A
00007e2c933e51e9  call 0x00007E2C932E27E0
00007e2c933e51ee  jmp 0x00007E2C933E5086
00007e2c933e51f3  call 0x00007E2C932E1570
00007e2c933e51f8  jmp 0x00007E2C933E5092
00007e2c933e51fd  call 0x00007E2C932E27E0
00007e2c933e5202  jmp 0x00007E2C933E50AC
00007e2c933e5207  call 0x00007E2C932E0300
00007e2c933e520c  jmp 0x00007E2C933E50B8
00007e2c933e5211  call 0x00007E2C932E27E0
00007e2c933e5216  jmp 0x00007E2C933E50F0
00007e2c933e521b  call 0x00007E2C932E0300
00007e2c933e5220  jmp 0x00007E2C933E50FC
00007e2c933e5225  call 0x00007E2C932E27E0
00007e2c933e522a  jmp 0x00007E2C933E5134
00007e2c933e522f  call 0x00007E2C932E0300
00007e2c933e5234  jmp 0x00007E2C933E5140
00007e2c933e5239  call 0x00007E2C932E27E0
00007e2c933e523e  jmp 0x00007E2C933E5178
00007e2c933e5243  call 0x00007E2C932E0300
00007e2c933e5248  jmp 0x00007E2C933E5184
00007e2c933e524d  int3
00007e2c933e524e  nop
00007e2c933e5250  mov qword ptr [r15+0x100], 0x04
00007e2c933e525b  mov esi, 0x00
00007e2c933e5260  mov edx, 0x09
00007e2c933e5265  mov rdi, 0x7FFEB03C87D0
00007e2c933e526f  mov rax, 0x5A263F05A970
00007e2c933e5279  call rax
00007e2c933e527b  cmp dword ptr [r15+0x318], 0x00
00007e2c933e5283  jnz 0x00007E2C931FE110
00007e2c933e5289  jmp 0x00007E2C931FE0A0
00007e2c933e528e  int3
00007e2c933e528f  int3
