00007c454bbce69b  nop [rax+rax*1], eax
00007c454bbce6a0  mov rax, [r15+0xF8]
00007c454bbce6a7  lea r14, [rax-0x1E0]
00007c454bbce6ae  mov [r15+0xF8], r14
00007c454bbce6b5  lea rax, [r14+0x1D0]
00007c454bbce6bc  mov r12, [r15+0xA0]
00007c454bbce6c3  mov r11, [r15+0x98]
00007c454bbce6ca  mov [r13+rax*1], r12
00007c454bbce6cf  lea rax, [r14+0x1D8]
00007c454bbce6d6  mov [r13+rax*1], r11
00007c454bbce6db  mov eax, 0x420AA0
00007c454bbce6e0  movups xmm1, [r13+rax*1]
00007c454bbce6e6  mov eax, 0x420A30
00007c454bbce6eb  movups xmm15, [r13+rax*1]
00007c454bbce6f1  mov eax, 0x420AC0
00007c454bbce6f6  movups xmm14, [r13+rax*1]
00007c454bbce6fc  mov eax, 0x420A60
00007c454bbce701  movups xmm13, [r13+rax*1]
00007c454bbce707  mov qword ptr [r15+0x98], 0x430CD0
00007c454bbce712  mov eax, 0x420AD0
00007c454bbce717  movups xmm12, [r13+rax*1]
00007c454bbce71d  mov eax, 0x430CD0
00007c454bbce722  movups [r13+rax*1], xmm1
00007c454bbce728  mov eax, 0x430CE0
00007c454bbce72d  movups [r13+rax*1], xmm15
00007c454bbce733  mov eax, 0x430CF0
00007c454bbce738  movups [r13+rax*1], xmm14
00007c454bbce73e  mov eax, 0x430D00
00007c454bbce743  movups [r13+rax*1], xmm13
00007c454bbce749  mov eax, 0x420A20
00007c454bbce74e  movups xmm14, [r13+rax*1]
00007c454bbce754  mov eax, 0x420A10
00007c454bbce759  movups xmm13, [r13+rax*1]
00007c454bbce75f  mov eax, 0x430DD0
00007c454bbce764  movups [r13+rax*1], xmm1
00007c454bbce76a  mov eax, 0x430DE0
00007c454bbce76f  movups [r13+rax*1], xmm15
00007c454bbce775  mov eax, 0x430D10
00007c454bbce77a  movups [r13+rax*1], xmm12
00007c454bbce780  mov eax, 0x430D20
00007c454bbce785  movups [r13+rax*1], xmm14
00007c454bbce78b  mov eax, 0x420A00
00007c454bbce790  movups xmm1, [r13+rax*1]
00007c454bbce796  mov eax, 0x420A70
00007c454bbce79b  movups xmm15, [r13+rax*1]
00007c454bbce7a1  mov eax, 0x430D30
00007c454bbce7a6  movups [r13+rax*1], xmm13
00007c454bbce7ac  mov eax, 0x430D40
00007c454bbce7b1  movups [r13+rax*1], xmm1
00007c454bbce7b7  mov eax, 0x420A80
00007c454bbce7bc  movups xmm1, [r13+rax*1]
00007c454bbce7c2  mov eax, 0x420A50
00007c454bbce7c7  movups xmm14, [r13+rax*1]
00007c454bbce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007c454bbce7d5  mov eax, 0x430D50
00007c454bbce7da  movups [r13+rax*1], xmm15
00007c454bbce7e0  mov eax, 0x430D60
00007c454bbce7e5  movups [r13+rax*1], xmm1
00007c454bbce7eb  mov eax, 0x420AF0
00007c454bbce7f0  movups xmm1, [r13+rax*1]
00007c454bbce7f6  mov eax, 0x420B00
00007c454bbce7fb  movups xmm15, [r13+rax*1]
00007c454bbce801  movaps [r15+0x150], xmm15
00007c454bbce809  mov qword ptr [r15+0xA0], 0x3E8
00007c454bbce814  mov eax, 0x430D70
00007c454bbce819  movups [r13+rax*1], xmm14
00007c454bbce81f  mov eax, 0x430D80
00007c454bbce824  movups [r13+rax*1], xmm1
00007c454bbce82a  mov eax, 0x420AE0
00007c454bbce82f  movups xmm1, [r13+rax*1]
00007c454bbce835  mov eax, 0x420A90
00007c454bbce83a  movups xmm14, [r13+rax*1]
00007c454bbce840  movaps [r15+0x140], xmm14
00007c454bbce848  lea rax, [r14+0x180]
00007c454bbce84f  movq xmm13, qword ptr [r15+0x200]
00007c454bbce858  movq xmm12, qword ptr [r15+0x1F0]
00007c454bbce861  movq r12, xmm13
00007c454bbce866  movq r11, xmm12
00007c454bbce86b  mov [r13+rax*1], r12
00007c454bbce870  lea rax, [r14+0x188]
00007c454bbce877  mov [r13+rax*1], r11
00007c454bbce87c  mov eax, 0x430D90
00007c454bbce881  movups [r13+rax*1], xmm15
00007c454bbce887  mov eax, 0x430DA0
00007c454bbce88c  movups [r13+rax*1], xmm1
00007c454bbce892  mov eax, 0x420AB0
00007c454bbce897  movups xmm1, [r13+rax*1]
00007c454bbce89d  mov eax, 0x420B18
00007c454bbce8a2  mov r12, [r13+rax*1]
00007c454bbce8a7  movq xmm15, r12
00007c454bbce8ac  mov qword ptr [r15+0x40], 0x420B20
00007c454bbce8b4  mov eax, 0x430DB0
00007c454bbce8b9  movups [r13+rax*1], xmm14
00007c454bbce8bf  mov eax, 0x430DC0
00007c454bbce8c4  movups [r13+rax*1], xmm1
00007c454bbce8ca  mov eax, 0x420B80
00007c454bbce8cf  movups xmm1, [r13+rax*1]
00007c454bbce8d5  movq rax, xmm15
00007c454bbce8da  mov r12d, 0x430DF0
00007c454bbce8e0  mov [r13+r12*1], rax
00007c454bbce8e5  mov eax, 0x420B60
00007c454bbce8ea  movups xmm15, [r13+rax*1]
00007c454bbce8f0  mov eax, 0x420B70
00007c454bbce8f5  movups xmm14, [r13+rax*1]
00007c454bbce8fb  lea rax, [r14+0x160]
00007c454bbce902  movups [r13+rax*1], xmm1
00007c454bbce908  lea rax, [r14+0x190]
00007c454bbce90f  movq xmm1, qword ptr [r15+0x1E0]
00007c454bbce918  movq xmm13, qword ptr [r15+0x1D0]
00007c454bbce921  movq r12, xmm1
00007c454bbce926  movq r11, xmm13
00007c454bbce92b  mov [r13+rax*1], r12
00007c454bbce930  lea rax, [r14+0x198]
00007c454bbce937  mov [r13+rax*1], r11
00007c454bbce93c  lea rax, [r14+0x140]
00007c454bbce943  movups [r13+rax*1], xmm15
00007c454bbce949  lea rax, [r14+0x150]
00007c454bbce950  movups [r13+rax*1], xmm14
00007c454bbce956  mov eax, 0x420B20
00007c454bbce95b  movups xmm1, [r13+rax*1]
00007c454bbce961  mov eax, 0x420B30
00007c454bbce966  movups xmm15, [r13+rax*1]
00007c454bbce96c  movaps [r15+0x120], xmm15
00007c454bbce974  lea rax, [r14+0x1A0]
00007c454bbce97b  movq xmm14, qword ptr [r15+0x1C0]
00007c454bbce984  movq xmm13, qword ptr [r15+0x1B0]
00007c454bbce98d  movq r12, xmm14
00007c454bbce992  movq r11, xmm13
00007c454bbce997  mov [r13+rax*1], r12
00007c454bbce99c  lea rax, [r14+0x1A8]
00007c454bbce9a3  mov [r13+rax*1], r11
00007c454bbce9a8  lea rax, [r14+0x1B0]
00007c454bbce9af  movq xmm14, qword ptr [r15+0x1A0]
00007c454bbce9b8  movq xmm13, qword ptr [r15+0x190]
00007c454bbce9c1  movq r12, xmm14
00007c454bbce9c6  movq r11, xmm13
00007c454bbce9cb  mov [r13+rax*1], r12
00007c454bbce9d0  lea rax, [r14+0x1B8]
00007c454bbce9d7  mov [r13+rax*1], r11
00007c454bbce9dc  lea rax, [r14+0x100]
00007c454bbce9e3  movups [r13+rax*1], xmm1
00007c454bbce9e9  lea rax, [r14+0x110]
00007c454bbce9f0  movups [r13+rax*1], xmm15
00007c454bbce9f6  mov eax, 0x420B40
00007c454bbce9fb  movups xmm1, [r13+rax*1]
00007c454bbcea01  mov eax, 0x420B50
00007c454bbcea06  movups xmm15, [r13+rax*1]
00007c454bbcea0c  movaps [r15+0x110], xmm1
00007c454bbcea14  movaps [r15+0x130], xmm15
00007c454bbcea1c  lea rax, [r14+0x1C0]
00007c454bbcea23  mov r12, [r15+0xE8]
00007c454bbcea2a  mov r11, [r15+0xF0]
00007c454bbcea31  mov [r13+rax*1], r12
00007c454bbcea36  lea rax, [r14+0x1C8]
00007c454bbcea3d  mov [r13+rax*1], r11
00007c454bbcea42  mov eax, 0x430DF8
00007c454bbcea47  mov r12d, 0x421DF8D3
00007c454bbcea4d  mov [r13+rax*1], r12d
00007c454bbcea52  lea rax, [r14+0x120]
00007c454bbcea59  movups [r13+rax*1], xmm1
00007c454bbcea5f  lea rax, [r14+0x130]
00007c454bbcea66  movups [r13+rax*1], xmm15
00007c454bbcea6c  lea rax, [r14+0x100]
00007c454bbcea73  mov [r15], rax
00007c454bbcea76  mov qword ptr [r15+0x08], 0x430CD0
00007c454bbcea7e  mov qword ptr [r15+0x10], 0x12C
00007c454bbcea86  mov qword ptr [r15+0xF0], 0x410284
00007c454bbcea91  mov r14d, [r15+0x320]
00007c454bbcea98  mov eax, 0x410284
00007c454bbcea9d  mov rcx, 0x7C454BBD07C0
00007c454bbceaa7  mov [r15+r14*8+0x328], rax
00007c454bbceaaf  mov [r15+r14*8+0x368], rcx
00007c454bbceab7  add r14d, 0x01
00007c454bbceabb  and r14d, 0x07
00007c454bbceabf  mov [r15+0x320], r14d
00007c454bbceac6  cmp dword ptr [r15+0x318], 0x00
00007c454bbceace  jz 0x00007C454BBCED70
00007c454bbcead4  nop [rax+rax*1], ax
00007c454bbceadd  nop [rax+rax*1], eax
00007c454bbceae5  mov eax, 0x410728
00007c454bbceaea  mov [r15+0x100], rax
00007c454bbceaf1  jmp 0x00007C454B9FE110
00007c454bbceaf6  int3
00007c454bbceaf7  call 0x00007C454BA0BC20
00007c454bbceafc  jmp 0x00007C454BBCE6CF
00007c454bbceb01  call 0x00007C454BA0A9A0
00007c454bbceb06  jmp 0x00007C454BBCE6DB
00007c454bbceb0b  call 0x00007C454B9FF430
00007c454bbceb10  jmp 0x00007C454BBCE6E6
00007c454bbceb15  call 0x00007C454BA0E760
00007c454bbceb1a  jmp 0x00007C454BBCE6F1
00007c454bbceb1f  call 0x00007C454BA0D4E0
00007c454bbceb24  jmp 0x00007C454BBCE6FC
00007c454bbceb29  call 0x00007C454BA0C260
00007c454bbceb2e  jmp 0x00007C454BBCE707
00007c454bbceb33  call 0x00007C454BA0AFE0
00007c454bbceb38  jmp 0x00007C454BBCE71D
00007c454bbceb3d  call 0x00007C454B9FF540
00007c454bbceb42  jmp 0x00007C454BBCE728
00007c454bbceb47  call 0x00007C454BA0E880
00007c454bbceb4c  jmp 0x00007C454BBCE733
00007c454bbceb51  call 0x00007C454BA0D600
00007c454bbceb56  jmp 0x00007C454BBCE73E
00007c454bbceb5b  call 0x00007C454BA0C380
00007c454bbceb60  jmp 0x00007C454BBCE749
00007c454bbceb65  call 0x00007C454BA0D4E0
00007c454bbceb6a  jmp 0x00007C454BBCE754
00007c454bbceb6f  call 0x00007C454BA0C260
00007c454bbceb74  jmp 0x00007C454BBCE75F
00007c454bbceb79  call 0x00007C454B9FF540
00007c454bbceb7e  jmp 0x00007C454BBCE76A
00007c454bbceb83  call 0x00007C454BA0E880
00007c454bbceb88  jmp 0x00007C454BBCE775
00007c454bbceb8d  call 0x00007C454BA0B100
00007c454bbceb92  jmp 0x00007C454BBCE780
00007c454bbceb97  call 0x00007C454BA0D600
00007c454bbceb9c  jmp 0x00007C454BBCE78B
00007c454bbceba1  call 0x00007C454B9FF430
00007c454bbceba6  jmp 0x00007C454BBCE796
00007c454bbcebab  call 0x00007C454BA0E760
00007c454bbcebb0  jmp 0x00007C454BBCE7A1
00007c454bbcebb5  call 0x00007C454BA0C380
00007c454bbcebba  jmp 0x00007C454BBCE7AC
00007c454bbcebbf  call 0x00007C454B9FF540
00007c454bbcebc4  jmp 0x00007C454BBCE7B7
00007c454bbcebc9  call 0x00007C454B9FF430
00007c454bbcebce  jmp 0x00007C454BBCE7C2
00007c454bbcebd3  call 0x00007C454BA0D4E0
00007c454bbcebd8  jmp 0x00007C454BBCE7CD
00007c454bbcebdd  call 0x00007C454BA0E880
00007c454bbcebe2  jmp 0x00007C454BBCE7E0
00007c454bbcebe7  call 0x00007C454B9FF540
00007c454bbcebec  jmp 0x00007C454BBCE7EB
00007c454bbcebf1  call 0x00007C454B9FF430
00007c454bbcebf6  jmp 0x00007C454BBCE7F6
00007c454bbcebfb  call 0x00007C454BA0E760
00007c454bbcec00  jmp 0x00007C454BBCE801
00007c454bbcec05  call 0x00007C454BA0D600
00007c454bbcec0a  jmp 0x00007C454BBCE81F
00007c454bbcec0f  call 0x00007C454B9FF540
00007c454bbcec14  jmp 0x00007C454BBCE82A
00007c454bbcec19  call 0x00007C454B9FF430
00007c454bbcec1e  jmp 0x00007C454BBCE835
00007c454bbcec23  call 0x00007C454BA0D4E0
00007c454bbcec28  jmp 0x00007C454BBCE840
00007c454bbcec2d  call 0x00007C454BA0BC20
00007c454bbcec32  jmp 0x00007C454BBCE870
00007c454bbcec37  call 0x00007C454BA0A9A0
00007c454bbcec3c  jmp 0x00007C454BBCE87C
00007c454bbcec41  call 0x00007C454BA0E880
00007c454bbcec46  jmp 0x00007C454BBCE887
00007c454bbcec4b  call 0x00007C454B9FF540
00007c454bbcec50  jmp 0x00007C454BBCE892
00007c454bbcec55  call 0x00007C454B9FF430
00007c454bbcec5a  jmp 0x00007C454BBCE89D
00007c454bbcec5f  call 0x00007C454BA0B720
00007c454bbcec64  jmp 0x00007C454BBCE8A7
00007c454bbcec69  call 0x00007C454BA0D600
00007c454bbcec6e  jmp 0x00007C454BBCE8BF
00007c454bbcec73  call 0x00007C454B9FF540
00007c454bbcec78  jmp 0x00007C454BBCE8CA
00007c454bbcec7d  call 0x00007C454B9FF430
00007c454bbcec82  jmp 0x00007C454BBCE8D5
00007c454bbcec87  call 0x00007C454BAB4CB0
00007c454bbcec8c  jmp 0x00007C454BBCE8E5
00007c454bbcec91  call 0x00007C454BA0E760
00007c454bbcec96  jmp 0x00007C454BBCE8F0
00007c454bbcec9b  call 0x00007C454BA0D4E0
00007c454bbceca0  jmp 0x00007C454BBCE8FB
00007c454bbceca5  call 0x00007C454B9FF540
00007c454bbcecaa  jmp 0x00007C454BBCE908
00007c454bbcecaf  call 0x00007C454BA0BC20
00007c454bbcecb4  jmp 0x00007C454BBCE930
00007c454bbcecb9  call 0x00007C454BA0A9A0
00007c454bbcecbe  jmp 0x00007C454BBCE93C
00007c454bbcecc3  call 0x00007C454BA0E880
00007c454bbcecc8  jmp 0x00007C454BBCE949
00007c454bbceccd  call 0x00007C454BA0D600
00007c454bbcecd2  jmp 0x00007C454BBCE956
00007c454bbcecd7  call 0x00007C454B9FF430
00007c454bbcecdc  jmp 0x00007C454BBCE961
00007c454bbcece1  call 0x00007C454BA0E760
00007c454bbcece6  jmp 0x00007C454BBCE96C
00007c454bbceceb  call 0x00007C454BA0BC20
00007c454bbcecf0  jmp 0x00007C454BBCE99C
00007c454bbcecf5  call 0x00007C454BA0A9A0
00007c454bbcecfa  jmp 0x00007C454BBCE9A8
00007c454bbcecff  call 0x00007C454BA0BC20
00007c454bbced04  jmp 0x00007C454BBCE9D0
00007c454bbced09  call 0x00007C454BA0A9A0
00007c454bbced0e  jmp 0x00007C454BBCE9DC
00007c454bbced13  call 0x00007C454B9FF540
00007c454bbced18  jmp 0x00007C454BBCE9E9
00007c454bbced1d  call 0x00007C454BA0E880
00007c454bbced22  jmp 0x00007C454BBCE9F6
00007c454bbced27  call 0x00007C454B9FF430
00007c454bbced2c  jmp 0x00007C454BBCEA01
00007c454bbced31  call 0x00007C454BA0E760
00007c454bbced36  jmp 0x00007C454BBCEA0C
00007c454bbced3b  call 0x00007C454BA0BC20
00007c454bbced40  jmp 0x00007C454BBCEA36
00007c454bbced45  call 0x00007C454BA0A9A0
00007c454bbced4a  jmp 0x00007C454BBCEA42
00007c454bbced4f  call 0x00007C454BA0BAE0
00007c454bbced54  jmp 0x00007C454BBCEA52
00007c454bbced59  call 0x00007C454B9FF540
00007c454bbced5e  jmp 0x00007C454BBCEA5F
00007c454bbced63  call 0x00007C454BA0E880
00007c454bbced68  jmp 0x00007C454BBCEA6C
00007c454bbced6d  int3
00007c454bbced6e  nop
00007c454bbced70  mov rax, [r15]
00007c454bbced73  lea r14, [rax+0x20]
00007c454bbced77  mov r12, [r13+r14*1]
00007c454bbced7c  mov r14, [r15+0x10]
00007c454bbced80  lea r11, [r12+r14*1]
00007c454bbced84  mov [r15+0x40], r11
00007c454bbced88  lea r12, [rax+0x20]
00007c454bbced8c  mov [r13+r12*1], r11
00007c454bbced91  test r14, r14
00007c454bbced94  setz r14b
00007c454bbced98  movzx r14, r14b
00007c454bbced9c  mov [rsp+0x414], r14b
00007c454bbceda4  cmp byte ptr [rsp+0x414], 0x00
00007c454bbcedac  jz 0x00007C454BBCEDDE
00007c454bbcedae  cmp dword ptr [r15+0x318], 0x00
00007c454bbcedb6  mov eax, 0x4109A0
00007c454bbcedbb  mov [r15+0x100], rax
00007c454bbcedc2  jz 0x00007C454B9FE0A0
00007c454bbcedc8  nop [rax+rax*1], eax
00007c454bbcedcd  mov eax, 0x4109A0
00007c454bbcedd2  mov [r15+0x100], rax
00007c454bbcedd9  jmp 0x00007C454B9FE110
00007c454bbcedde  cmp dword ptr [r15+0x318], 0x00
00007c454bbcede6  jz 0x00007C454BBCEE30
00007c454bbcedec  nop [rax+rax*1], ax
00007c454bbcedf5  nop [rax+rax*1], eax
00007c454bbcedfd  mov eax, 0x410738
00007c454bbcee02  mov [r15+0x100], rax
00007c454bbcee09  jmp 0x00007C454B9FE110
00007c454bbcee0e  int3
00007c454bbcee0f  call 0x00007C454BAE27E0
00007c454bbcee14  jmp 0x00007C454BBCED7C
00007c454bbcee19  call 0x00007C454BAC0860
00007c454bbcee1e  jmp 0x00007C454BBCED91
00007c454bbcee23  int3
00007c454bbcee24  nop [rax+rax*1], ax
00007c454bbcee2d  nop [rax], eax
00007c454bbcee30  mov rax, [r15+0xF8]
00007c454bbcee37  lea r14, [rax-0x150]
00007c454bbcee3e  mov [r15+0xF8], r14
00007c454bbcee45  mov rax, [r15]
00007c454bbcee48  lea r12, [rax+0x68]
00007c454bbcee4c  mov r11, [r13+r12*1]
00007c454bbcee51  mov [r15+0x88], r11
00007c454bbcee58  lea r12, [rax+0x28]
00007c454bbcee5c  mov [r15+0x40], r12
00007c454bbcee60  mov [r15+0x48], r14
00007c454bbcee64  mov qword ptr [r15+0x50], 0x420B90
00007c454bbcee6c  lea rax, [r14+0x100]
00007c454bbcee73  mov r12, [r15+0xE8]
00007c454bbcee7a  mov r11, [r15+0xD8]
00007c454bbcee81  mov [r13+rax*1], r12
00007c454bbcee86  lea rax, [r14+0x108]
00007c454bbcee8d  mov [r13+rax*1], r11
00007c454bbcee92  lea rax, [r14+0x110]
00007c454bbcee99  mov r12, [r15+0xD0]
00007c454bbceea0  mov r11, [r15+0xC8]
00007c454bbceea7  mov [r13+rax*1], r12
00007c454bbceeac  lea rax, [r14+0x118]
00007c454bbceeb3  mov [r13+rax*1], r11
00007c454bbceeb8  lea rax, [r14+0x120]
00007c454bbceebf  mov r12, [r15+0xC0]
00007c454bbceec6  mov r11, [r15+0xB8]
00007c454bbceecd  mov [r13+rax*1], r12
00007c454bbceed2  lea rax, [r14+0x128]
00007c454bbceed9  mov [r13+rax*1], r11
00007c454bbceede  lea rax, [r14+0x130]
00007c454bbceee5  mov r12, [r15+0xB0]
00007c454bbceeec  mov r11, [r15+0xA8]
00007c454bbceef3  mov [r13+rax*1], r12
00007c454bbceef8  lea rax, [r14+0x138]
00007c454bbceeff  mov [r13+rax*1], r11
00007c454bbcef04  lea rax, [r14+0x140]
00007c454bbcef0b  mov r12, [r15+0xA0]
00007c454bbcef12  mov r11, [r15+0x98]
00007c454bbcef19  mov [r13+rax*1], r12
00007c454bbcef1e  lea rax, [r14+0x148]
00007c454bbcef25  mov [r13+rax*1], r11
00007c454bbcef2a  cmp dword ptr [r15+0x318], 0x00
00007c454bbcef32  jz 0x00007C454BBCEFD0
00007c454bbcef38  nop [rax+rax*1], ax
00007c454bbcef41  nop [rax+rax*1], eax
00007c454bbcef49  mov eax, 0x410770
00007c454bbcef4e  mov [r15+0x100], rax
00007c454bbcef55  jmp 0x00007C454B9FE110
00007c454bbcef5a  int3
00007c454bbcef5b  call 0x00007C454BAC0370
00007c454bbcef60  jmp 0x00007C454BBCEE51
00007c454bbcef65  call 0x00007C454BA0BC20
00007c454bbcef6a  jmp 0x00007C454BBCEE86
00007c454bbcef6f  call 0x00007C454BA0A9A0
00007c454bbcef74  jmp 0x00007C454BBCEE92
00007c454bbcef79  call 0x00007C454BA0BC20
00007c454bbcef7e  jmp 0x00007C454BBCEEAC
00007c454bbcef83  call 0x00007C454BA0A9A0
00007c454bbcef88  jmp 0x00007C454BBCEEB8
00007c454bbcef8d  call 0x00007C454BA0BC20
00007c454bbcef92  jmp 0x00007C454BBCEED2
00007c454bbcef97  call 0x00007C454BA0A9A0
00007c454bbcef9c  jmp 0x00007C454BBCEEDE
00007c454bbcefa1  call 0x00007C454BA0BC20
00007c454bbcefa6  jmp 0x00007C454BBCEEF8
00007c454bbcefab  call 0x00007C454BA0A9A0
00007c454bbcefb0  jmp 0x00007C454BBCEF04
00007c454bbcefb5  call 0x00007C454BA0BC20
00007c454bbcefba  jmp 0x00007C454BBCEF1E
00007c454bbcefbf  call 0x00007C454BA0A9A0
00007c454bbcefc4  jmp 0x00007C454BBCEF2A
00007c454bbcefc9  int3
00007c454bbcefca  nop [rax+rax*1], ax
00007c454bbcefd0  mov rax, [r15+0x08]
00007c454bbcefd4  movzx r14d, byte ptr [r13+rax*1]
00007c454bbcefda  movzx r14d, r14b
00007c454bbcefde  mov [rsp+0x10], r14d
00007c454bbcefe3  mov r14d, r14d
00007c454bbcefe6  mov [r15+0x58], r14
00007c454bbcefea  lea r14, [rax+0x01]
00007c454bbcefee  mov [r15+0x08], r14
00007c454bbceff2  mov rax, [r15+0x88]
00007c454bbceff9  lea r14, [rax+0x01]
00007c454bbceffd  mov r12, [r15]
00007c454bbcf000  lea r11, [r12+0x68]
00007c454bbcf005  mov [r13+r11*1], r14
00007c454bbcf00a  lea r14, [r12+rax*1]
00007c454bbcf00e  mov [r15+0x60], r14
00007c454bbcf012  lea rax, [r14+0x28]
00007c454bbcf016  mov r11d, [rsp+0x10]
00007c454bbcf01b  movzx r14d, r11b
00007c454bbcf01f  mov [r13+rax*1], r14b
00007c454bbcf024  lea rax, [r12+0x68]
00007c454bbcf029  mov r14, [r13+rax*1]
00007c454bbcf02e  mov [r15+0x88], r14
00007c454bbcf035  xor eax, eax
00007c454bbcf037  mov r12d, 0x40
00007c454bbcf03d  cmp r14, r12
00007c454bbcf040  cmc
00007c454bbcf041  lahf
00007c454bbcf042  seto al
00007c454bbcf045  mov [r15+0x108], eax
00007c454bbcf04c  mov eax, [r15+0x108]
00007c454bbcf053  sahf
00007c454bbcf054  jnz 0x00007C454BBCF086
00007c454bbcf056  cmp dword ptr [r15+0x318], 0x00
00007c454bbcf05e  jz 0x00007C454BBCF170
00007c454bbcf064  nop [rax+rax*1], ax
00007c454bbcf06d  nop [rax+rax*1], eax
00007c454bbcf075  mov eax, 0x410790
00007c454bbcf07a  mov [r15+0x100], rax
00007c454bbcf081  jmp 0x00007C454B9FE110
00007c454bbcf086  cmp dword ptr [r15+0x318], 0x00
00007c454bbcf08e  jz 0x00007C454BBCF0E0
00007c454bbcf094  nop [rax+rax*1], ax
00007c454bbcf09d  nop [rax+rax*1], eax
00007c454bbcf0a5  mov eax, 0x410768
00007c454bbcf0aa  mov [r15+0x100], rax
00007c454bbcf0b1  jmp 0x00007C454B9FE110
00007c454bbcf0b6  int3
00007c454bbcf0b7  call 0x00007C454BA0D860
00007c454bbcf0bc  jmp 0x00007C454BBCEFDA
00007c454bbcf0c1  call 0x00007C454BAB36E0
00007c454bbcf0c6  jmp 0x00007C454BBCF00A
00007c454bbcf0cb  call 0x00007C454BA0DD60
00007c454bbcf0d0  jmp 0x00007C454BBCF024
00007c454bbcf0d5  call 0x00007C454BA0DC20
00007c454bbcf0da  jmp 0x00007C454BBCF02E
00007c454bbcf0df  int3
00007c454bbcf0e0  mov rax, [r15+0x10]
00007c454bbcf0e4  lea r14, [rax-0x01]
00007c454bbcf0e8  mov [r15+0x10], r14
00007c454bbcf0ec  test r14, r14
00007c454bbcf0ef  setz r14b
00007c454bbcf0f3  movzx r14, r14b
00007c454bbcf0f7  mov [rsp+0x414], r14b
00007c454bbcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007c454bbcf107  jz 0x00007C454BBCF139
00007c454bbcf109  cmp dword ptr [r15+0x318], 0x00
00007c454bbcf111  jz 0x00007C454BBD0670
00007c454bbcf117  nop [rax+rax*1], ax
00007c454bbcf120  nop [rax+rax*1], eax
00007c454bbcf128  mov eax, 0x410988
00007c454bbcf12d  mov [r15+0x100], rax
00007c454bbcf134  jmp 0x00007C454B9FE110
00007c454bbcf139  cmp dword ptr [r15+0x318], 0x00
00007c454bbcf141  jz 0x00007C454BBCEFD0
00007c454bbcf147  nop [rax+rax*1], ax
00007c454bbcf150  nop [rax+rax*1], eax
00007c454bbcf158  mov eax, 0x410770
00007c454bbcf15d  mov [r15+0x100], rax
00007c454bbcf164  jmp 0x00007C454B9FE110
00007c454bbcf169  int3
00007c454bbcf16a  int3
00007c454bbcf16b  nop [rax+rax*1], eax
00007c454bbcf170  mov rax, [r15+0x40]
00007c454bbcf174  movzx r14d, byte ptr [r13+rax*1]
00007c454bbcf17a  movaps xmm1, [r15+0x110]
00007c454bbcf182  pinsrb xmm1, r14d, 0x00
00007c454bbcf189  lea r14, [rax+0x01]
00007c454bbcf18d  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf193  movaps xmm15, [r15+0x120]
00007c454bbcf19b  pinsrb xmm15, r12d, 0x00
00007c454bbcf1a2  lea r14, [rax+0x02]
00007c454bbcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf1ac  movaps xmm14, [r15+0x130]
00007c454bbcf1b4  pinsrb xmm14, r12d, 0x00
00007c454bbcf1bb  lea r14, [rax+0x03]
00007c454bbcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf1c5  movaps xmm13, [r15+0x140]
00007c454bbcf1cd  pinsrb xmm13, r12d, 0x00
00007c454bbcf1d4  lea r14, [rax+0x04]
00007c454bbcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf1de  pinsrb xmm1, r12d, 0x01
00007c454bbcf1e5  lea r14, [rax+0x05]
00007c454bbcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf1ef  pinsrb xmm15, r12d, 0x01
00007c454bbcf1f6  lea r14, [rax+0x06]
00007c454bbcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf200  pinsrb xmm14, r12d, 0x01
00007c454bbcf207  lea r14, [rax+0x07]
00007c454bbcf20b  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf211  pinsrb xmm13, r12d, 0x01
00007c454bbcf218  lea r14, [rax+0x08]
00007c454bbcf21c  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf222  pinsrb xmm1, r12d, 0x02
00007c454bbcf229  lea r14, [rax+0x09]
00007c454bbcf22d  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf233  pinsrb xmm15, r12d, 0x02
00007c454bbcf23a  lea r14, [rax+0x0A]
00007c454bbcf23e  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf244  pinsrb xmm14, r12d, 0x02
00007c454bbcf24b  lea r14, [rax+0x0B]
00007c454bbcf24f  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf255  pinsrb xmm13, r12d, 0x02
00007c454bbcf25c  lea r14, [rax+0x0C]
00007c454bbcf260  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf266  pinsrb xmm1, r12d, 0x03
00007c454bbcf26d  lea r14, [rax+0x0D]
00007c454bbcf271  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf277  pinsrb xmm15, r12d, 0x03
00007c454bbcf27e  lea r14, [rax+0x0E]
00007c454bbcf282  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf288  pinsrb xmm14, r12d, 0x03
00007c454bbcf28f  lea r14, [rax+0x0F]
00007c454bbcf293  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf299  pinsrb xmm13, r12d, 0x03
00007c454bbcf2a0  lea r14, [rax+0x10]
00007c454bbcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf2aa  pinsrb xmm1, r12d, 0x04
00007c454bbcf2b1  lea r14, [rax+0x11]
00007c454bbcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf2bb  pinsrb xmm15, r12d, 0x04
00007c454bbcf2c2  lea r14, [rax+0x12]
00007c454bbcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf2cc  pinsrb xmm14, r12d, 0x04
00007c454bbcf2d3  lea r14, [rax+0x13]
00007c454bbcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf2dd  pinsrb xmm13, r12d, 0x04
00007c454bbcf2e4  lea r14, [rax+0x14]
00007c454bbcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf2ee  pinsrb xmm1, r12d, 0x05
00007c454bbcf2f5  lea r14, [rax+0x15]
00007c454bbcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf2ff  pinsrb xmm15, r12d, 0x05
00007c454bbcf306  lea r14, [rax+0x16]
00007c454bbcf30a  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf310  pinsrb xmm14, r12d, 0x05
00007c454bbcf317  lea r14, [rax+0x17]
00007c454bbcf31b  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf321  pinsrb xmm13, r12d, 0x05
00007c454bbcf328  lea r14, [rax+0x18]
00007c454bbcf32c  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf332  pinsrb xmm1, r12d, 0x06
00007c454bbcf339  lea r14, [rax+0x19]
00007c454bbcf33d  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf343  pinsrb xmm15, r12d, 0x06
00007c454bbcf34a  lea r14, [rax+0x1A]
00007c454bbcf34e  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf354  pinsrb xmm14, r12d, 0x06
00007c454bbcf35b  lea r14, [rax+0x1B]
00007c454bbcf35f  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf365  pinsrb xmm13, r12d, 0x06
00007c454bbcf36c  lea r14, [rax+0x1C]
00007c454bbcf370  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf376  pinsrb xmm1, r12d, 0x07
00007c454bbcf37d  lea r14, [rax+0x1D]
00007c454bbcf381  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf387  pinsrb xmm15, r12d, 0x07
00007c454bbcf38e  lea r14, [rax+0x1E]
00007c454bbcf392  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf398  pinsrb xmm14, r12d, 0x07
00007c454bbcf39f  lea r14, [rax+0x1F]
00007c454bbcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf3a9  pinsrb xmm13, r12d, 0x07
00007c454bbcf3b0  lea r14, [rax+0x20]
00007c454bbcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf3ba  pinsrb xmm1, r12d, 0x08
00007c454bbcf3c1  lea r14, [rax+0x21]
00007c454bbcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf3cb  pinsrb xmm15, r12d, 0x08
00007c454bbcf3d2  lea r14, [rax+0x22]
00007c454bbcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf3dc  pinsrb xmm14, r12d, 0x08
00007c454bbcf3e3  lea r14, [rax+0x23]
00007c454bbcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf3ed  pinsrb xmm13, r12d, 0x08
00007c454bbcf3f4  lea r14, [rax+0x24]
00007c454bbcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf3fe  pinsrb xmm1, r12d, 0x09
00007c454bbcf405  lea r14, [rax+0x25]
00007c454bbcf409  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf40f  pinsrb xmm15, r12d, 0x09
00007c454bbcf416  lea r14, [rax+0x26]
00007c454bbcf41a  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf420  pinsrb xmm14, r12d, 0x09
00007c454bbcf427  lea r14, [rax+0x27]
00007c454bbcf42b  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf431  pinsrb xmm13, r12d, 0x09
00007c454bbcf438  lea r14, [rax+0x28]
00007c454bbcf43c  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf442  pinsrb xmm1, r12d, 0x0A
00007c454bbcf449  lea r14, [rax+0x29]
00007c454bbcf44d  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf453  pinsrb xmm15, r12d, 0x0A
00007c454bbcf45a  lea r14, [rax+0x2A]
00007c454bbcf45e  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf464  pinsrb xmm14, r12d, 0x0A
00007c454bbcf46b  lea r14, [rax+0x2B]
00007c454bbcf46f  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf475  pinsrb xmm13, r12d, 0x0A
00007c454bbcf47c  lea r14, [rax+0x2C]
00007c454bbcf480  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf486  pinsrb xmm1, r12d, 0x0B
00007c454bbcf48d  lea r14, [rax+0x2D]
00007c454bbcf491  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf497  pinsrb xmm15, r12d, 0x0B
00007c454bbcf49e  lea r14, [rax+0x2E]
00007c454bbcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf4a8  pinsrb xmm14, r12d, 0x0B
00007c454bbcf4af  lea r14, [rax+0x2F]
00007c454bbcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf4b9  pinsrb xmm13, r12d, 0x0B
00007c454bbcf4c0  lea r14, [rax+0x30]
00007c454bbcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf4ca  pinsrb xmm1, r12d, 0x0C
00007c454bbcf4d1  lea r14, [rax+0x31]
00007c454bbcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf4db  pinsrb xmm15, r12d, 0x0C
00007c454bbcf4e2  lea r14, [rax+0x32]
00007c454bbcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf4ec  pinsrb xmm14, r12d, 0x0C
00007c454bbcf4f3  lea r14, [rax+0x33]
00007c454bbcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf4fd  pinsrb xmm13, r12d, 0x0C
00007c454bbcf504  lea r14, [rax+0x34]
00007c454bbcf508  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf50e  pinsrb xmm1, r12d, 0x0D
00007c454bbcf515  lea r14, [rax+0x35]
00007c454bbcf519  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf51f  pinsrb xmm15, r12d, 0x0D
00007c454bbcf526  lea r14, [rax+0x36]
00007c454bbcf52a  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf530  pinsrb xmm14, r12d, 0x0D
00007c454bbcf537  lea r14, [rax+0x37]
00007c454bbcf53b  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf541  pinsrb xmm13, r12d, 0x0D
00007c454bbcf548  lea r14, [rax+0x38]
00007c454bbcf54c  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf552  pinsrb xmm1, r12d, 0x0E
00007c454bbcf559  lea r14, [rax+0x39]
00007c454bbcf55d  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf563  pinsrb xmm15, r12d, 0x0E
00007c454bbcf56a  lea r14, [rax+0x3A]
00007c454bbcf56e  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf574  pinsrb xmm14, r12d, 0x0E
00007c454bbcf57b  lea r14, [rax+0x3B]
00007c454bbcf57f  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf585  pinsrb xmm13, r12d, 0x0E
00007c454bbcf58c  lea r14, [rax+0x3C]
00007c454bbcf590  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf596  pinsrb xmm1, r12d, 0x0F
00007c454bbcf59d  movaps [r15+0x110], xmm1
00007c454bbcf5a5  lea r14, [rax+0x3D]
00007c454bbcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf5af  pinsrb xmm15, r12d, 0x0F
00007c454bbcf5b6  movaps [r15+0x120], xmm15
00007c454bbcf5be  lea r14, [rax+0x3E]
00007c454bbcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007c454bbcf5c8  pinsrb xmm14, r12d, 0x0F
00007c454bbcf5cf  movaps [r15+0x130], xmm14
00007c454bbcf5d7  lea r14, [rax+0x3F]
00007c454bbcf5db  movzx eax, byte ptr [r13+r14*1]
00007c454bbcf5e1  pinsrb xmm13, eax, 0x0F
00007c454bbcf5e8  movaps [r15+0x140], xmm13
00007c454bbcf5f0  movq xmm1, qword ptr [r15+0x120]
00007c454bbcf5f9  pmovzxbw xmm1, xmm1
00007c454bbcf5fe  psllw xmm1, 0x00
00007c454bbcf603  movaps [r15+0x150], xmm1
00007c454bbcf60b  movq xmm1, qword ptr [r15+0x130]
00007c454bbcf614  pmovzxbw xmm1, xmm1
00007c454bbcf619  psllw xmm1, 0x00
00007c454bbcf61e  movaps [r15+0x160], xmm1
00007c454bbcf626  movq xmm1, qword ptr [r15+0x110]
00007c454bbcf62f  pmovzxbw xmm1, xmm1
00007c454bbcf634  psllw xmm1, 0x00
00007c454bbcf639  movaps [r15+0x170], xmm1
00007c454bbcf641  movaps xmm15, [r15+0x110]
00007c454bbcf649  pextrq rax, xmm15, 0x01
00007c454bbcf650  movq xmm15, rax
00007c454bbcf655  pmovzxbw xmm15, xmm15
00007c454bbcf65b  psllw xmm15, 0x00
00007c454bbcf661  movaps [r15+0x180], xmm15
00007c454bbcf669  movaps xmm14, [r15+0x120]
00007c454bbcf671  pextrq rax, xmm14, 0x01
00007c454bbcf678  movq xmm14, rax
00007c454bbcf67d  pmovzxbw xmm14, xmm14
00007c454bbcf683  psllw xmm14, 0x00
00007c454bbcf689  movaps [r15+0x210], xmm14
00007c454bbcf691  movaps xmm13, [r15+0x130]
00007c454bbcf699  pextrq rax, xmm13, 0x01
00007c454bbcf6a0  movq xmm13, rax
00007c454bbcf6a5  pmovzxbw xmm13, xmm13
00007c454bbcf6ab  psllw xmm13, 0x00
00007c454bbcf6b1  movaps [r15+0x220], xmm13
00007c454bbcf6b9  movq xmm12, qword ptr [r15+0x140]
00007c454bbcf6c2  pmovzxbw xmm12, xmm12
00007c454bbcf6c8  psllw xmm12, 0x00
00007c454bbcf6ce  movaps [r15+0x250], xmm12
00007c454bbcf6d6  movaps xmm12, [r15+0x140]
00007c454bbcf6de  pextrq rax, xmm12, 0x01
00007c454bbcf6e5  movq xmm12, rax
00007c454bbcf6ea  pmovzxbw xmm12, xmm12
00007c454bbcf6f0  psllw xmm12, 0x00
00007c454bbcf6f6  movaps [r15+0x110], xmm12
00007c454bbcf6fe  movq xmm11, qword ptr [r15+0x150]
00007c454bbcf707  pmovzxwd xmm11, xmm11
00007c454bbcf70d  pslld xmm11, 0x10
00007c454bbcf713  movq xmm10, qword ptr [r15+0x160]
00007c454bbcf71c  pmovzxwd xmm10, xmm10
00007c454bbcf722  pslld xmm10, 0x08
00007c454bbcf728  pextrq rax, xmm1, 0x01
00007c454bbcf72f  movq xmm1, rax
00007c454bbcf734  pmovzxwd xmm1, xmm1
00007c454bbcf739  pslld xmm1, 0x00
00007c454bbcf73e  movaps [r15+0x260], xmm1
00007c454bbcf746  pextrq rax, xmm15, 0x01
00007c454bbcf74d  movq xmm15, rax
00007c454bbcf752  pmovzxwd xmm15, xmm15
00007c454bbcf758  pslld xmm15, 0x00
00007c454bbcf75e  movaps [r15+0x270], xmm15
00007c454bbcf766  movq xmm9, qword ptr [r15+0x170]
00007c454bbcf76f  pmovzxwd xmm9, xmm9
00007c454bbcf775  pslld xmm9, 0x00
00007c454bbcf77b  pextrq rax, xmm14, 0x01
00007c454bbcf782  movq xmm14, rax
00007c454bbcf787  pmovzxwd xmm14, xmm14
00007c454bbcf78d  pslld xmm14, 0x10
00007c454bbcf793  movaps [r15+0x280], xmm14
00007c454bbcf79b  movq xmm8, qword ptr [r15+0x180]
00007c454bbcf7a4  pmovzxwd xmm8, xmm8
00007c454bbcf7aa  pslld xmm8, 0x00
00007c454bbcf7b0  movq xmm7, qword ptr [r15+0x210]
00007c454bbcf7b9  pmovzxwd xmm7, xmm7
00007c454bbcf7be  pslld xmm7, 0x10
00007c454bbcf7c3  movaps xmm6, [r15+0x150]
00007c454bbcf7cb  pextrq rax, xmm6, 0x01
00007c454bbcf7d2  movq xmm6, rax
00007c454bbcf7d7  pmovzxwd xmm6, xmm6
00007c454bbcf7dc  pslld xmm6, 0x10
00007c454bbcf7e1  por xmm11, xmm10
00007c454bbcf7e6  movaps [r15+0x230], xmm11
00007c454bbcf7ee  pextrq rax, xmm13, 0x01
00007c454bbcf7f5  movq xmm13, rax
00007c454bbcf7fa  pmovzxwd xmm13, xmm13
00007c454bbcf800  pslld xmm13, 0x08
00007c454bbcf806  movaps [r15+0x240], xmm13
00007c454bbcf80e  movq xmm10, qword ptr [r15+0x220]
00007c454bbcf817  pmovzxwd xmm10, xmm10
00007c454bbcf81d  pslld xmm10, 0x08
00007c454bbcf823  movaps xmm5, [r15+0x160]
00007c454bbcf82b  pextrq rax, xmm5, 0x01
00007c454bbcf832  movq xmm5, rax
00007c454bbcf837  pmovzxwd xmm5, xmm5
00007c454bbcf83c  pslld xmm5, 0x08
00007c454bbcf841  pslld xmm9, 0x18
00007c454bbcf847  pslld xmm15, 0x18
00007c454bbcf84d  pslld xmm8, 0x18
00007c454bbcf853  movq xmm4, qword ptr [r15+0x250]
00007c454bbcf85c  pmovzxwd xmm4, xmm4
00007c454bbcf861  pslld xmm4, 0x00
00007c454bbcf866  por xmm14, xmm13
00007c454bbcf86b  por xmm7, xmm10
00007c454bbcf870  movaps [r15+0x210], xmm7
00007c454bbcf878  pslld xmm1, 0x18
00007c454bbcf87d  movaps [r15+0x220], xmm1
00007c454bbcf885  por xmm6, xmm5
00007c454bbcf889  por xmm11, xmm9
00007c454bbcf88e  movaps [r15+0x160], xmm11
00007c454bbcf896  pextrq rax, xmm12, 0x01
00007c454bbcf89d  movq xmm13, rax
00007c454bbcf8a2  pmovzxwd xmm13, xmm13
00007c454bbcf8a8  pslld xmm13, 0x00
00007c454bbcf8ae  movaps [r15+0x170], xmm13
00007c454bbcf8b6  movq xmm12, qword ptr [r15+0x110]
00007c454bbcf8bf  pmovzxwd xmm12, xmm12
00007c454bbcf8c5  pslld xmm12, 0x00
00007c454bbcf8cb  por xmm14, xmm15
00007c454bbcf8d0  por xmm7, xmm8
00007c454bbcf8d5  movaps xmm15, [r15+0x250]
00007c454bbcf8dd  pextrq rax, xmm15, 0x01
00007c454bbcf8e4  movq xmm15, rax
00007c454bbcf8e9  pmovzxwd xmm15, xmm15
00007c454bbcf8ef  pslld xmm15, 0x00
00007c454bbcf8f5  movaps [r15+0x180], xmm15
00007c454bbcf8fd  por xmm6, xmm1
00007c454bbcf901  movaps [r15+0x150], xmm6
00007c454bbcf909  por xmm11, xmm4
00007c454bbcf90e  movaps [r15+0x140], xmm11
00007c454bbcf916  por xmm7, xmm12
00007c454bbcf91b  movaps [r15+0x110], xmm7
00007c454bbcf923  por xmm14, xmm13
00007c454bbcf928  movaps [r15+0x120], xmm14
00007c454bbcf930  por xmm6, xmm15
00007c454bbcf935  movaps [r15+0x130], xmm6
00007c454bbcf93d  mov rax, [r15+0xF8]
00007c454bbcf944  lea r14, [rax+0x20]
00007c454bbcf948  movups [r13+r14*1], xmm7
00007c454bbcf94e  lea r14, [rax+0x30]
00007c454bbcf952  movups [r13+r14*1], xmm14
00007c454bbcf958  movups [r13+rax*1], xmm11
00007c454bbcf95e  lea r14, [rax+0x10]
00007c454bbcf962  movups [r13+r14*1], xmm6
00007c454bbcf968  mov r14d, [r13+rax*1]
00007c454bbcf96d  mov rax, [r15+0x48]
00007c454bbcf971  mov [r15+0x68], rax
00007c454bbcf975  mov qword ptr [r15+0x58], 0x04
00007c454bbcf97d  lea r12, [rax+0x04]
00007c454bbcf981  mov r11d, [r13+r12*1]
00007c454bbcf986  mov [rsp+0x10], r11d
00007c454bbcf98b  mov r11d, r11d
00007c454bbcf98e  mov [r15+0x70], r11
00007c454bbcf992  lea r12, [rax+0x38]
00007c454bbcf996  mov r11d, [r13+r12*1]
00007c454bbcf99b  lea r12, [rax+0x24]
00007c454bbcf99f  mov r10d, [r13+r12*1]
00007c454bbcf9a4  mov [rsp+0x20], r10d
00007c454bbcf9a9  mov r10d, r10d
00007c454bbcf9ac  mov [r15+0x90], r10
00007c454bbcf9b3  mov [rsp+0x30], rax
00007c454bbcf9b8  xor eax, eax
00007c454bbcf9ba  mov r12d, 0x04
00007c454bbcf9c0  mov r10d, 0xC0
00007c454bbcf9c6  cmp r12, r10
00007c454bbcf9c9  cmc
00007c454bbcf9ca  lahf
00007c454bbcf9cb  seto al
00007c454bbcf9ce  mov [r15+0x108], eax
00007c454bbcf9d5  mov eax, [rsp+0x10]
00007c454bbcf9d9  mov r12d, [rsp+0x10]
00007c454bbcf9de  shrd eax, r12d, 0x07
00007c454bbcf9e3  mov [rsp+0x10], r11d
00007c454bbcf9e8  mov r10d, [rsp+0x10]
00007c454bbcf9ed  shrd r11d, r10d, 0x11
00007c454bbcf9f2  mov r9d, [rsp+0x20]
00007c454bbcf9f7  lea r8d, [r9d+r14d*1]
00007c454bbcf9fc  rorx r14d, r12d, 0x12
00007c454bbcfa02  xor eax, r14d
00007c454bbcfa05  rorx r14d, r10d, 0x13
00007c454bbcfa0b  xor r11d, r14d
00007c454bbcfa0e  mov [rsp+0x10], r11d
00007c454bbcfa13  mov r11d, r11d
00007c454bbcfa16  mov [r15+0x88], r11
00007c454bbcfa1d  mov [rsp+0x20], r12d
00007c454bbcfa22  shr r12d, 0x03
00007c454bbcfa26  xor eax, r12d
00007c454bbcfa29  mov [rsp+0x40], eax
00007c454bbcfa2d  mov eax, eax
00007c454bbcfa2f  mov [r15+0x80], rax
00007c454bbcfa36  shr r10d, 0x0A
00007c454bbcfa3a  mov eax, [rsp+0x10]
00007c454bbcfa3e  xor eax, r10d
00007c454bbcfa41  mov [rsp+0x10], eax
00007c454bbcfa45  mov eax, eax
00007c454bbcfa47  mov [r15+0x78], rax
00007c454bbcfa4b  mov eax, [rsp+0x40]
00007c454bbcfa4f  lea r14d, [r8d+eax*1]
00007c454bbcfa54  mov eax, [rsp+0x10]
00007c454bbcfa58  lea r12d, [r14d+eax*1]
00007c454bbcfa5d  mov rax, [rsp+0x30]
00007c454bbcfa62  lea r14, [rax+0x40]
00007c454bbcfa66  mov [r13+r14*1], r12d
00007c454bbcfa6b  mov eax, [rsp+0x20]
00007c454bbcfa6f  mov eax, eax
00007c454bbcfa71  mov [r15+0x60], rax
00007c454bbcfa75  mov eax, [r15+0x108]
00007c454bbcfa7c  sahf
00007c454bbcfa7d  jnz 0x00007C454BBCFAAF
00007c454bbcfa7f  cmp dword ptr [r15+0x318], 0x00
00007c454bbcfa87  jz 0x00007C454BBCFF70
00007c454bbcfa8d  nop [rax+rax*1], ax
00007c454bbcfa96  nop [rax+rax*1], eax
00007c454bbcfa9e  mov eax, 0x41088C
00007c454bbcfaa3  mov [r15+0x100], rax
00007c454bbcfaaa  jmp 0x00007C454B9FE110
00007c454bbcfaaf  cmp dword ptr [r15+0x318], 0x00
00007c454bbcfab7  jz 0x00007C454BBCFDC0
00007c454bbcfabd  nop [rax+rax*1], ax
00007c454bbcfac6  nop [rax+rax*1], eax
00007c454bbcface  mov eax, 0x410844
00007c454bbcfad3  mov [r15+0x100], rax
00007c454bbcfada  jmp 0x00007C454B9FE110
00007c454bbcfadf  int3
00007c454bbcfae0  call 0x00007C454BA0D860
00007c454bbcfae5  jmp 0x00007C454BBCF17A
00007c454bbcfaea  call 0x00007C454BAE2420
00007c454bbcfaef  jmp 0x00007C454BBCF193
00007c454bbcfaf4  call 0x00007C454BAE2420
00007c454bbcfaf9  jmp 0x00007C454BBCF1AC
00007c454bbcfafe  call 0x00007C454BAE2420
00007c454bbcfb03  jmp 0x00007C454BBCF1C5
00007c454bbcfb08  call 0x00007C454BAE2420
00007c454bbcfb0d  jmp 0x00007C454BBCF1DE
00007c454bbcfb12  call 0x00007C454BAE2420
00007c454bbcfb17  jmp 0x00007C454BBCF1EF
00007c454bbcfb1c  call 0x00007C454BAE2420
00007c454bbcfb21  jmp 0x00007C454BBCF200
00007c454bbcfb26  call 0x00007C454BAE2420
00007c454bbcfb2b  jmp 0x00007C454BBCF211
00007c454bbcfb30  call 0x00007C454BAE2420
00007c454bbcfb35  jmp 0x00007C454BBCF222
00007c454bbcfb3a  call 0x00007C454BAE2420
00007c454bbcfb3f  jmp 0x00007C454BBCF233
00007c454bbcfb44  call 0x00007C454BAE2420
00007c454bbcfb49  jmp 0x00007C454BBCF244
00007c454bbcfb4e  call 0x00007C454BAE2420
00007c454bbcfb53  jmp 0x00007C454BBCF255
00007c454bbcfb58  call 0x00007C454BAE2420
00007c454bbcfb5d  jmp 0x00007C454BBCF266
00007c454bbcfb62  call 0x00007C454BAE2420
00007c454bbcfb67  jmp 0x00007C454BBCF277
00007c454bbcfb6c  call 0x00007C454BAE2420
00007c454bbcfb71  jmp 0x00007C454BBCF288
00007c454bbcfb76  call 0x00007C454BAE2420
00007c454bbcfb7b  jmp 0x00007C454BBCF299
00007c454bbcfb80  call 0x00007C454BAE2420
00007c454bbcfb85  jmp 0x00007C454BBCF2AA
00007c454bbcfb8a  call 0x00007C454BAE2420
00007c454bbcfb8f  jmp 0x00007C454BBCF2BB
00007c454bbcfb94  call 0x00007C454BAE2420
00007c454bbcfb99  jmp 0x00007C454BBCF2CC
00007c454bbcfb9e  call 0x00007C454BAE2420
00007c454bbcfba3  jmp 0x00007C454BBCF2DD
00007c454bbcfba8  call 0x00007C454BAE2420
00007c454bbcfbad  jmp 0x00007C454BBCF2EE
00007c454bbcfbb2  call 0x00007C454BAE2420
00007c454bbcfbb7  jmp 0x00007C454BBCF2FF
00007c454bbcfbbc  call 0x00007C454BAE2420
00007c454bbcfbc1  jmp 0x00007C454BBCF310
00007c454bbcfbc6  call 0x00007C454BAE2420
00007c454bbcfbcb  jmp 0x00007C454BBCF321
00007c454bbcfbd0  call 0x00007C454BAE2420
00007c454bbcfbd5  jmp 0x00007C454BBCF332
00007c454bbcfbda  call 0x00007C454BAE2420
00007c454bbcfbdf  jmp 0x00007C454BBCF343
00007c454bbcfbe4  call 0x00007C454BAE2420
00007c454bbcfbe9  jmp 0x00007C454BBCF354
00007c454bbcfbee  call 0x00007C454BAE2420
00007c454bbcfbf3  jmp 0x00007C454BBCF365
00007c454bbcfbf8  call 0x00007C454BAE2420
00007c454bbcfbfd  jmp 0x00007C454BBCF376
00007c454bbcfc02  call 0x00007C454BAE2420
00007c454bbcfc07  jmp 0x00007C454BBCF387
00007c454bbcfc0c  call 0x00007C454BAE2420
00007c454bbcfc11  jmp 0x00007C454BBCF398
00007c454bbcfc16  call 0x00007C454BAE2420
00007c454bbcfc1b  jmp 0x00007C454BBCF3A9
00007c454bbcfc20  call 0x00007C454BAE2420
00007c454bbcfc25  jmp 0x00007C454BBCF3BA
00007c454bbcfc2a  call 0x00007C454BAE2420
00007c454bbcfc2f  jmp 0x00007C454BBCF3CB
00007c454bbcfc34  call 0x00007C454BAE2420
00007c454bbcfc39  jmp 0x00007C454BBCF3DC
00007c454bbcfc3e  call 0x00007C454BAE2420
00007c454bbcfc43  jmp 0x00007C454BBCF3ED
00007c454bbcfc48  call 0x00007C454BAE2420
00007c454bbcfc4d  jmp 0x00007C454BBCF3FE
00007c454bbcfc52  call 0x00007C454BAE2420
00007c454bbcfc57  jmp 0x00007C454BBCF40F
00007c454bbcfc5c  call 0x00007C454BAE2420
00007c454bbcfc61  jmp 0x00007C454BBCF420
00007c454bbcfc66  call 0x00007C454BAE2420
00007c454bbcfc6b  jmp 0x00007C454BBCF431
00007c454bbcfc70  call 0x00007C454BAE2420
00007c454bbcfc75  jmp 0x00007C454BBCF442
00007c454bbcfc7a  call 0x00007C454BAE2420
00007c454bbcfc7f  jmp 0x00007C454BBCF453
00007c454bbcfc84  call 0x00007C454BAE2420
00007c454bbcfc89  jmp 0x00007C454BBCF464
00007c454bbcfc8e  call 0x00007C454BAE2420
00007c454bbcfc93  jmp 0x00007C454BBCF475
00007c454bbcfc98  call 0x00007C454BAE2420
00007c454bbcfc9d  jmp 0x00007C454BBCF486
00007c454bbcfca2  call 0x00007C454BAE2420
00007c454bbcfca7  jmp 0x00007C454BBCF497
00007c454bbcfcac  call 0x00007C454BAE2420
00007c454bbcfcb1  jmp 0x00007C454BBCF4A8
00007c454bbcfcb6  call 0x00007C454BAE2420
00007c454bbcfcbb  jmp 0x00007C454BBCF4B9
00007c454bbcfcc0  call 0x00007C454BAE2420
00007c454bbcfcc5  jmp 0x00007C454BBCF4CA
00007c454bbcfcca  call 0x00007C454BAE2420
00007c454bbcfccf  jmp 0x00007C454BBCF4DB
00007c454bbcfcd4  call 0x00007C454BAE2420
00007c454bbcfcd9  jmp 0x00007C454BBCF4EC
00007c454bbcfcde  call 0x00007C454BAE2420
00007c454bbcfce3  jmp 0x00007C454BBCF4FD
00007c454bbcfce8  call 0x00007C454BAE2420
00007c454bbcfced  jmp 0x00007C454BBCF50E
00007c454bbcfcf2  call 0x00007C454BAE2420
00007c454bbcfcf7  jmp 0x00007C454BBCF51F
00007c454bbcfcfc  call 0x00007C454BAE2420
00007c454bbcfd01  jmp 0x00007C454BBCF530
00007c454bbcfd06  call 0x00007C454BAE2420
00007c454bbcfd0b  jmp 0x00007C454BBCF541
00007c454bbcfd10  call 0x00007C454BAE2420
00007c454bbcfd15  jmp 0x00007C454BBCF552
00007c454bbcfd1a  call 0x00007C454BAE2420
00007c454bbcfd1f  jmp 0x00007C454BBCF563
00007c454bbcfd24  call 0x00007C454BAE2420
00007c454bbcfd29  jmp 0x00007C454BBCF574
00007c454bbcfd2e  call 0x00007C454BAE2420
00007c454bbcfd33  jmp 0x00007C454BBCF585
00007c454bbcfd38  call 0x00007C454BAE2420
00007c454bbcfd3d  jmp 0x00007C454BBCF596
00007c454bbcfd42  call 0x00007C454BAE2420
00007c454bbcfd47  jmp 0x00007C454BBCF5AF
00007c454bbcfd4c  call 0x00007C454BAE2420
00007c454bbcfd51  jmp 0x00007C454BBCF5C8
00007c454bbcfd56  call 0x00007C454BAD5610
00007c454bbcfd5b  jmp 0x00007C454BBCF5E1
00007c454bbcfd60  call 0x00007C454BADC580
00007c454bbcfd65  jmp 0x00007C454BBCF94E
00007c454bbcfd6a  call 0x00007C454BAE46C0
00007c454bbcfd6f  jmp 0x00007C454BBCF958
00007c454bbcfd74  call 0x00007C454BA09E90
00007c454bbcfd79  jmp 0x00007C454BBCF95E
00007c454bbcfd7e  call 0x00007C454BADB310
00007c454bbcfd83  jmp 0x00007C454BBCF968
00007c454bbcfd88  call 0x00007C454BA0DAE0
00007c454bbcfd8d  jmp 0x00007C454BBCF96D
00007c454bbcfd92  call 0x00007C454BAC0230
00007c454bbcfd97  jmp 0x00007C454BBCF986
00007c454bbcfd9c  call 0x00007C454BAC0230
00007c454bbcfda1  jmp 0x00007C454BBCF99B
00007c454bbcfda6  call 0x00007C454BABEFC0
00007c454bbcfdab  jmp 0x00007C454BBCF9A4
00007c454bbcfdb0  call 0x00007C454BAE2BA0
00007c454bbcfdb5  jmp 0x00007C454BBCFA6B
00007c454bbcfdba  int3
00007c454bbcfdbb  nop [rax+rax*1], eax
00007c454bbcfdc0  mov rax, [r15+0x48]
00007c454bbcfdc4  mov r14, [r15+0x58]
00007c454bbcfdc8  lea r12, [rax+r14*1]
00007c454bbcfdcc  mov [r15+0x68], r12
00007c454bbcfdd0  lea rax, [r14+0x04]
00007c454bbcfdd4  mov [r15+0x58], rax
00007c454bbcfdd8  lea r14, [r12+0x04]
00007c454bbcfddd  mov r11d, [r13+r14*1]
00007c454bbcfde2  mov [rsp+0x10], r11d
00007c454bbcfde7  mov r11d, r11d
00007c454bbcfdea  mov [r15+0x70], r11
00007c454bbcfdee  lea r14, [r12+0x38]
00007c454bbcfdf3  mov r11d, [r13+r14*1]
00007c454bbcfdf8  lea r14, [r12+0x24]
00007c454bbcfdfd  mov r10d, [r13+r14*1]
00007c454bbcfe02  mov [rsp+0x20], r10d
00007c454bbcfe07  mov r10d, r10d
00007c454bbcfe0a  mov [r15+0x90], r10
00007c454bbcfe11  mov [rsp+0x30], rax
00007c454bbcfe16  xor eax, eax
00007c454bbcfe18  mov r14, [rsp+0x30]
00007c454bbcfe1d  mov r10d, 0xC0
00007c454bbcfe23  cmp r14, r10
00007c454bbcfe26  cmc
00007c454bbcfe27  lahf
00007c454bbcfe28  seto al
00007c454bbcfe2b  mov [r15+0x108], eax
00007c454bbcfe32  mov eax, [rsp+0x10]
00007c454bbcfe36  mov r14d, [rsp+0x10]
00007c454bbcfe3b  shrd eax, r14d, 0x07
00007c454bbcfe40  mov [rsp+0x10], r11d
00007c454bbcfe45  mov r10d, [rsp+0x10]
00007c454bbcfe4a  shrd r11d, r10d, 0x11
00007c454bbcfe4f  mov r9d, [r15+0x60]
00007c454bbcfe53  mov r8d, [rsp+0x20]
00007c454bbcfe58  lea ebp, [r8d+r9d*1]
00007c454bbcfe5d  rorx r9d, r14d, 0x12
00007c454bbcfe63  xor eax, r9d
00007c454bbcfe66  rorx r9d, r10d, 0x13
00007c454bbcfe6c  xor r11d, r9d
00007c454bbcfe6f  mov [rsp+0x10], r11d
00007c454bbcfe74  mov r11d, r11d
00007c454bbcfe77  mov [r15+0x88], r11
00007c454bbcfe7e  mov [rsp+0x20], r14d
00007c454bbcfe83  shr r14d, 0x03
00007c454bbcfe87  xor eax, r14d
00007c454bbcfe8a  mov [rsp+0x30], eax
00007c454bbcfe8e  mov eax, eax
00007c454bbcfe90  mov [r15+0x80], rax
00007c454bbcfe97  shr r10d, 0x0A
00007c454bbcfe9b  mov eax, [rsp+0x10]
00007c454bbcfe9f  xor eax, r10d
00007c454bbcfea2  mov [rsp+0x10], eax
00007c454bbcfea6  mov eax, eax
00007c454bbcfea8  mov [r15+0x78], rax
00007c454bbcfeac  mov eax, [rsp+0x30]
00007c454bbcfeb0  lea r14d, [ebp+eax*1]
00007c454bbcfeb6  mov eax, [rsp+0x10]
00007c454bbcfeba  lea r11d, [r14d+eax*1]
00007c454bbcfebf  lea rax, [r12+0x40]
00007c454bbcfec4  mov [r13+rax*1], r11d
00007c454bbcfec9  mov eax, [rsp+0x20]
00007c454bbcfecd  mov eax, eax
00007c454bbcfecf  mov [r15+0x60], rax
00007c454bbcfed3  mov eax, [r15+0x108]
00007c454bbcfeda  sahf
00007c454bbcfedb  jnz 0x00007C454BBCFF0D
00007c454bbcfedd  cmp dword ptr [r15+0x318], 0x00
00007c454bbcfee5  jz 0x00007C454BBCFF70
00007c454bbcfeeb  nop [rax+rax*1], ax
00007c454bbcfef4  nop [rax+rax*1], eax
00007c454bbcfefc  mov eax, 0x41088C
00007c454bbcff01  mov [r15+0x100], rax
00007c454bbcff08  jmp 0x00007C454B9FE110
00007c454bbcff0d  cmp dword ptr [r15+0x318], 0x00
00007c454bbcff15  jz 0x00007C454BBCFDC0
00007c454bbcff1b  nop [rax+rax*1], ax
00007c454bbcff24  nop [rax+rax*1], eax
00007c454bbcff2c  mov eax, 0x410844
00007c454bbcff31  mov [r15+0x100], rax
00007c454bbcff38  jmp 0x00007C454B9FE110
00007c454bbcff3d  int3
00007c454bbcff3e  call 0x00007C454BAE1430
00007c454bbcff43  jmp 0x00007C454BBCFDE2
00007c454bbcff48  call 0x00007C454BAE1430
00007c454bbcff4d  jmp 0x00007C454BBCFDF8
00007c454bbcff52  call 0x00007C454BAE01C0
00007c454bbcff57  jmp 0x00007C454BBCFE02
00007c454bbcff5c  call 0x00007C454BA0A860
00007c454bbcff61  jmp 0x00007C454BBCFEC9
00007c454bbcff66  int3
00007c454bbcff67  nop [rax+rax*1], ax
00007c454bbcff70  mov rax, [r15]
00007c454bbcff73  mov r14d, [r13+rax*1]
00007c454bbcff78  lea r12, [rax+0x04]
00007c454bbcff7c  mov r11d, [r13+r12*1]
00007c454bbcff81  mov [rsp+0x10], r14d
00007c454bbcff86  mov r14d, r14d
00007c454bbcff89  mov [r15+0x78], r14
00007c454bbcff8d  mov [rsp+0x20], r11d
00007c454bbcff92  mov r11d, r11d
00007c454bbcff95  mov [r15+0x80], r11
00007c454bbcff9c  lea r14, [rax+0x08]
00007c454bbcffa0  mov r12d, [r13+r14*1]
00007c454bbcffa5  lea r14, [rax+0x0C]
00007c454bbcffa9  mov r11d, [r13+r14*1]
00007c454bbcffae  mov [rsp+0x30], r12d
00007c454bbcffb3  mov r12d, r12d
00007c454bbcffb6  mov [r15+0x70], r12
00007c454bbcffba  mov [rsp+0x40], r11d
00007c454bbcffbf  mov r11d, r11d
00007c454bbcffc2  mov [r15+0x68], r11
00007c454bbcffc6  lea r14, [rax+0x18]
00007c454bbcffca  mov r12d, [r13+r14*1]
00007c454bbcffcf  lea r14, [rax+0x1C]
00007c454bbcffd3  mov r11d, [r13+r14*1]
00007c454bbcffd8  mov [rsp+0x50], r12d
00007c454bbcffdd  mov r12d, r12d
00007c454bbcffe0  mov [r15+0x58], r12
00007c454bbcffe4  mov [rsp+0x60], r11d
00007c454bbcffe9  mov r11d, r11d
00007c454bbcffec  mov [r15+0x60], r11
00007c454bbcfff0  lea r14, [rax+0x10]
00007c454bbcfff4  mov r12d, [r13+r14*1]
00007c454bbcfff9  lea r14, [rax+0x14]
00007c454bbcfffd  mov eax, [r13+r14*1]
00007c454bbd0002  mov [rsp+0x70], r12d
00007c454bbd0007  mov r12d, r12d
00007c454bbd000a  mov [r15+0x18], r12
00007c454bbd000e  mov [rsp+0x80], eax
00007c454bbd0015  mov eax, eax
00007c454bbd0017  mov [r15+0x90], rax
00007c454bbd001e  mov eax, [rsp+0x70]
00007c454bbd0022  mov eax, eax
00007c454bbd0024  mov [r15+0x30], rax
00007c454bbd0028  mov eax, [rsp+0x50]
00007c454bbd002c  mov eax, eax
00007c454bbd002e  mov [r15+0xA0], rax
00007c454bbd0035  mov eax, [rsp+0x30]
00007c454bbd0039  mov eax, eax
00007c454bbd003b  mov [r15+0x28], rax
00007c454bbd003f  mov eax, [rsp+0x20]
00007c454bbd0043  mov eax, eax
00007c454bbd0045  mov [r15+0x98], rax
00007c454bbd004c  mov eax, [rsp+0x10]
00007c454bbd0050  mov eax, eax
00007c454bbd0052  mov [r15+0x38], rax
00007c454bbd0056  mov eax, [rsp+0x70]
00007c454bbd005a  mov r14d, [rsp+0x70]
00007c454bbd005f  shrd eax, r14d, 0x06
00007c454bbd0064  mov [rsp+0x70], r14d
00007c454bbd0069  mov r12d, [rsp+0x80]
00007c454bbd0071  and r14d, r12d
00007c454bbd0074  mov r11d, [rsp+0x10]
00007c454bbd0079  mov r10d, [rsp+0x10]
00007c454bbd007e  shrd r11d, r10d, 0x02
00007c454bbd0083  mov [rsp+0x10], r12d
00007c454bbd0088  mov r12d, r12d
00007c454bbd008b  mov [r15+0x20], r12
00007c454bbd008f  mov r12, [r15+0x50]
00007c454bbd0093  mov r9d, [r13+r12*1]
00007c454bbd0098  mov r12d, [rsp+0x50]
00007c454bbd009d  mov r8d, [rsp+0x70]
00007c454bbd00a2  andn ebp, r8d, r12d
00007c454bbd00a7  mov edi, [rsp+0x60]
00007c454bbd00ab  lea esi, [r14d+edi*1]
00007c454bbd00b0  rorx r14d, r8d, 0x0B
00007c454bbd00b6  xor eax, r14d
00007c454bbd00b9  rorx r14d, r10d, 0x0D
00007c454bbd00bf  xor r11d, r14d
00007c454bbd00c2  lea edi, [esi+ebp*1]
00007c454bbd00c6  mov r14, [r15+0x48]
00007c454bbd00ca  mov ebp, [r13+r14*1]
00007c454bbd00cf  mov r14d, [rsp+0x30]
00007c454bbd00d4  mov esi, [rsp+0x20]
00007c454bbd00d8  and r14d, esi
00007c454bbd00db  mov [rsp+0x20], r14d
00007c454bbd00e0  mov r14d, r14d
00007c454bbd00e3  mov [r15+0xD8], r14
00007c454bbd00ea  lea r14d, [edi+r9d*1]
00007c454bbd00ef  mov r9d, [rsp+0x30]
00007c454bbd00f4  xor r9d, esi
00007c454bbd00f7  rorx edi, r8d, 0x19
00007c454bbd00fd  xor eax, edi
00007c454bbd00ff  and r9d, r10d
00007c454bbd0102  rorx edi, r10d, 0x16
00007c454bbd0108  xor r11d, edi
00007c454bbd010b  mov [rsp+0x30], r11d
00007c454bbd0110  mov r11d, r11d
00007c454bbd0113  mov [r15+0xD0], r11
00007c454bbd011a  lea r11d, [r14d+ebp*1]
00007c454bbd011f  mov r10d, [rsp+0x20]
00007c454bbd0124  xor r9d, r10d
00007c454bbd0127  lea r14d, [r11d+eax*1]
00007c454bbd012c  mov qword ptr [r15+0x88], 0x04
00007c454bbd0137  mov eax, [rsp+0x30]
00007c454bbd013b  lea r11d, [r9d+eax*1]
00007c454bbd0140  mov eax, [rsp+0x40]
00007c454bbd0144  lea r10d, [r14d+eax*1]
00007c454bbd0149  mov r10d, r10d
00007c454bbd014c  mov [r15+0xB8], r10
00007c454bbd0153  xor eax, eax
00007c454bbd0155  mov r10d, 0x04
00007c454bbd015b  mov r9d, 0x100
00007c454bbd0161  cmp r10, r9
00007c454bbd0164  cmc
00007c454bbd0165  lahf
00007c454bbd0166  seto al
00007c454bbd0169  mov [r15+0x108], eax
00007c454bbd0170  lea eax, [r11d+r14d*1]
00007c454bbd0175  mov eax, eax
00007c454bbd0177  mov [r15+0xA8], rax
00007c454bbd017e  mov r12d, r12d
00007c454bbd0181  mov [r15+0xB0], r12
00007c454bbd0188  mov eax, [rsp+0x10]
00007c454bbd018c  mov eax, eax
00007c454bbd018e  mov [r15+0xC0], rax
00007c454bbd0195  mov r8d, r8d
00007c454bbd0198  mov [r15+0xC8], r8
00007c454bbd019f  mov eax, [r15+0x108]
00007c454bbd01a6  sahf
00007c454bbd01a7  jnz 0x00007C454BBD01D9
00007c454bbd01a9  cmp dword ptr [r15+0x318], 0x00
00007c454bbd01b1  jz 0x00007C454BBD04A0
00007c454bbd01b7  nop [rax+rax*1], ax
00007c454bbd01c0  nop [rax+rax*1], eax
00007c454bbd01c8  mov eax, 0x41094C
00007c454bbd01cd  mov [r15+0x100], rax
00007c454bbd01d4  jmp 0x00007C454B9FE110
00007c454bbd01d9  cmp dword ptr [r15+0x318], 0x00
00007c454bbd01e1  jz 0x00007C454BBD0270
00007c454bbd01e7  nop [rax+rax*1], ax
00007c454bbd01f0  nop [rax+rax*1], eax
00007c454bbd01f8  mov eax, 0x4108C0
00007c454bbd01fd  mov [r15+0x100], rax
00007c454bbd0204  jmp 0x00007C454B9FE110
00007c454bbd0209  int3
00007c454bbd020a  call 0x00007C454BA0DAE0
00007c454bbd020f  jmp 0x00007C454BBCFF78
00007c454bbd0214  call 0x00007C454BAC0230
00007c454bbd0219  jmp 0x00007C454BBCFF81
00007c454bbd021e  call 0x00007C454BAE26A0
00007c454bbd0223  jmp 0x00007C454BBCFFA5
00007c454bbd0228  call 0x00007C454BAE1430
00007c454bbd022d  jmp 0x00007C454BBCFFAE
00007c454bbd0232  call 0x00007C454BAE26A0
00007c454bbd0237  jmp 0x00007C454BBCFFCF
00007c454bbd023c  call 0x00007C454BAE1430
00007c454bbd0241  jmp 0x00007C454BBCFFD8
00007c454bbd0246  call 0x00007C454BAE26A0
00007c454bbd024b  jmp 0x00007C454BBCFFF9
00007c454bbd0250  call 0x00007C454BAD5890
00007c454bbd0255  jmp 0x00007C454BBD0002
00007c454bbd025a  call 0x00007C454BABDD50
00007c454bbd025f  jmp 0x00007C454BBD0098
00007c454bbd0264  call 0x00007C454BADA580
00007c454bbd0269  jmp 0x00007C454BBD00CF
00007c454bbd026e  int3
00007c454bbd026f  nop
00007c454bbd0270  mov eax, [r15+0xB8]
00007c454bbd0277  mov [rsp+0x10], eax
00007c454bbd027b  mov eax, eax
00007c454bbd027d  mov [r15+0x30], rax
00007c454bbd0281  mov eax, [r15+0xC0]
00007c454bbd0288  mov [rsp+0x20], eax
00007c454bbd028c  mov eax, eax
00007c454bbd028e  mov [r15+0xA0], rax
00007c454bbd0295  mov eax, [r15+0x28]
00007c454bbd0299  mov r14d, [r15+0x98]
00007c454bbd02a0  mov [rsp+0x30], r14d
00007c454bbd02a5  mov r14d, r14d
00007c454bbd02a8  mov [r15+0x28], r14
00007c454bbd02ac  mov r14d, [r15+0x38]
00007c454bbd02b0  mov [rsp+0x40], r14d
00007c454bbd02b5  mov r14d, r14d
00007c454bbd02b8  mov [r15+0x98], r14
00007c454bbd02bf  mov r14d, [r15+0xA8]
00007c454bbd02c6  mov [rsp+0x50], r14d
00007c454bbd02cb  mov r14d, r14d
00007c454bbd02ce  mov [r15+0x38], r14
00007c454bbd02d2  mov r14d, [rsp+0x10]
00007c454bbd02d7  mov r12d, [rsp+0x10]
00007c454bbd02dc  shrd r14d, r12d, 0x06
00007c454bbd02e1  mov r11d, [r15+0xC8]
00007c454bbd02e8  mov [rsp+0x10], r12d
00007c454bbd02ed  and r12d, r11d
00007c454bbd02f0  mov r10d, [rsp+0x50]
00007c454bbd02f5  mov r9d, [rsp+0x50]
00007c454bbd02fa  shrd r10d, r9d, 0x02
00007c454bbd02ff  mov [rsp+0x50], r11d
00007c454bbd0304  mov r11d, r11d
00007c454bbd0307  mov [r15+0x20], r11
00007c454bbd030b  mov r11, [r15+0x88]
00007c454bbd0312  mov r8, [r15+0x50]
00007c454bbd0316  lea rbp, [r8+r11*1]
00007c454bbd031a  mov r8d, [r13+rbp*1]
00007c454bbd031f  mov ebp, [rsp+0x20]
00007c454bbd0323  mov edi, [rsp+0x10]
00007c454bbd0327  andn esi, edi, ebp
00007c454bbd032c  mov edx, [r15+0xB0]
00007c454bbd0333  lea ecx, [r12d+edx*1]
00007c454bbd0338  rorx r12d, edi, 0x0B
00007c454bbd033e  xor r14d, r12d
00007c454bbd0341  rorx r12d, r9d, 0x0D
00007c454bbd0347  xor r10d, r12d
00007c454bbd034a  lea r12d, [ecx+esi*1]
00007c454bbd034f  mov rsi, [r15+0x48]
00007c454bbd0353  lea rdx, [rsi+r11*1]
00007c454bbd0357  mov esi, [r13+rdx*1]
00007c454bbd035c  mov edx, [rsp+0x30]
00007c454bbd0360  mov ecx, [rsp+0x40]
00007c454bbd0364  and edx, ecx
00007c454bbd0366  mov [rsp+0x10], edx
00007c454bbd036a  mov edx, edx
00007c454bbd036c  mov [r15+0xD8], rdx
00007c454bbd0373  lea edx, [r12d+r8d*1]
00007c454bbd0378  mov r12d, [rsp+0x30]
00007c454bbd037d  xor r12d, ecx
00007c454bbd0380  rorx r8d, edi, 0x19
00007c454bbd0386  xor r14d, r8d
00007c454bbd0389  and r12d, r9d
00007c454bbd038c  rorx r8d, r9d, 0x16
00007c454bbd0392  xor r10d, r8d
00007c454bbd0395  mov [rsp+0x20], r10d
00007c454bbd039a  mov r10d, r10d
00007c454bbd039d  mov [r15+0xD0], r10
00007c454bbd03a4  lea r10d, [edx+esi*1]
00007c454bbd03a9  mov r9d, [rsp+0x10]
00007c454bbd03ae  xor r12d, r9d
00007c454bbd03b1  lea r9d, [r10d+r14d*1]
00007c454bbd03b6  lea r14, [r11+0x04]
00007c454bbd03ba  mov [r15+0x88], r14
00007c454bbd03c1  mov r11d, [rsp+0x20]
00007c454bbd03c6  lea r10d, [r12d+r11d*1]
00007c454bbd03cb  lea r11d, [r9d+eax*1]
00007c454bbd03d0  mov r11d, r11d
00007c454bbd03d3  mov [r15+0xB8], r11
00007c454bbd03da  xor eax, eax
00007c454bbd03dc  mov r12d, 0x100
00007c454bbd03e2  cmp r14, r12
00007c454bbd03e5  cmc
00007c454bbd03e6  lahf
00007c454bbd03e7  seto al
00007c454bbd03ea  mov [r15+0x108], eax
00007c454bbd03f1  lea eax, [r10d+r9d*1]
00007c454bbd03f6  mov eax, eax
00007c454bbd03f8  mov [r15+0xA8], rax
00007c454bbd03ff  mov ebp, ebp
00007c454bbd0401  mov [r15+0xB0], rbp
00007c454bbd0408  mov eax, [rsp+0x50]
00007c454bbd040c  mov eax, eax
00007c454bbd040e  mov [r15+0xC0], rax
00007c454bbd0415  mov edi, edi
00007c454bbd0417  mov [r15+0xC8], rdi
00007c454bbd041e  mov eax, [r15+0x108]
00007c454bbd0425  sahf
00007c454bbd0426  jnz 0x00007C454BBD0458
00007c454bbd0428  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0430  jz 0x00007C454BBD04A0
00007c454bbd0436  nop [rax+rax*1], ax
00007c454bbd043f  nop [rax+rax*1], eax
00007c454bbd0447  mov eax, 0x41094C
00007c454bbd044c  mov [r15+0x100], rax
00007c454bbd0453  jmp 0x00007C454B9FE110
00007c454bbd0458  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0460  jz 0x00007C454BBD0270
00007c454bbd0466  nop [rax+rax*1], ax
00007c454bbd046f  nop [rax+rax*1], eax
00007c454bbd0477  mov eax, 0x4108C0
00007c454bbd047c  mov [r15+0x100], rax
00007c454bbd0483  jmp 0x00007C454B9FE110
00007c454bbd0488  int3
00007c454bbd0489  call 0x00007C454BA49010
00007c454bbd048e  jmp 0x00007C454BBD031F
00007c454bbd0493  call 0x00007C454BA25930
00007c454bbd0498  jmp 0x00007C454BBD035C
00007c454bbd049d  int3
00007c454bbd049e  nop
00007c454bbd04a0  mov eax, [r15+0x98]
00007c454bbd04a7  mov r14d, [r15+0x70]
00007c454bbd04ab  lea r12d, [eax+r14d*1]
00007c454bbd04b0  mov eax, [r15+0x28]
00007c454bbd04b4  mov r14d, [r15+0x68]
00007c454bbd04b8  lea r11d, [eax+r14d*1]
00007c454bbd04bd  mov qword ptr [r15+0x88], 0x00
00007c454bbd04c8  mov eax, [r15+0xA8]
00007c454bbd04cf  mov r14d, [r15+0x78]
00007c454bbd04d3  lea r10d, [eax+r14d*1]
00007c454bbd04d8  mov [rsp+0x10], r10d
00007c454bbd04dd  mov r10d, r10d
00007c454bbd04e0  mov [r15+0x78], r10
00007c454bbd04e4  mov eax, [r15+0x38]
00007c454bbd04e8  mov r14d, [r15+0x80]
00007c454bbd04ef  lea r10d, [eax+r14d*1]
00007c454bbd04f4  mov [rsp+0x20], r10d
00007c454bbd04f9  mov r10d, r10d
00007c454bbd04fc  mov [r15+0x80], r10
00007c454bbd0503  mov rax, [r15]
00007c454bbd0506  lea r14, [rax+0x08]
00007c454bbd050a  mov [r13+r14*1], r12d
00007c454bbd050f  lea r14, [rax+0x0C]
00007c454bbd0513  mov [r13+r14*1], r11d
00007c454bbd0518  mov r14d, [r15+0xB8]
00007c454bbd051f  mov r12d, [r15+0x18]
00007c454bbd0523  lea r11d, [r14d+r12d*1]
00007c454bbd0528  mov [rsp+0x30], r11d
00007c454bbd052d  mov r11d, r11d
00007c454bbd0530  mov [r15+0x68], r11
00007c454bbd0534  mov r14d, [r15+0x30]
00007c454bbd0538  mov r12d, [r15+0x90]
00007c454bbd053f  lea r11d, [r14d+r12d*1]
00007c454bbd0544  mov [rsp+0x40], r11d
00007c454bbd0549  mov r11d, r11d
00007c454bbd054c  mov [r15+0x70], r11
00007c454bbd0550  mov r14d, [r15+0x20]
00007c454bbd0554  mov r12d, [r15+0x58]
00007c454bbd0558  lea r11d, [r14d+r12d*1]
00007c454bbd055d  mov [rsp+0x50], r11d
00007c454bbd0562  mov r11d, r11d
00007c454bbd0565  mov [r15+0x58], r11
00007c454bbd0569  mov r14d, [r15+0xA0]
00007c454bbd0570  mov r12d, [r15+0x60]
00007c454bbd0574  lea r11d, [r14d+r12d*1]
00007c454bbd0579  mov [rsp+0x60], r11d
00007c454bbd057e  mov r11d, r11d
00007c454bbd0581  mov [r15+0x60], r11
00007c454bbd0585  mov r14d, [rsp+0x10]
00007c454bbd058a  mov [r13+rax*1], r14d
00007c454bbd058f  lea r14, [rax+0x04]
00007c454bbd0593  mov r12d, [rsp+0x20]
00007c454bbd0598  mov [r13+r14*1], r12d
00007c454bbd059d  lea r14, [rax+0x10]
00007c454bbd05a1  mov r12d, [rsp+0x30]
00007c454bbd05a6  mov [r13+r14*1], r12d
00007c454bbd05ab  lea r14, [rax+0x14]
00007c454bbd05af  mov r12d, [rsp+0x40]
00007c454bbd05b4  mov [r13+r14*1], r12d
00007c454bbd05b9  lea r14, [rax+0x18]
00007c454bbd05bd  mov r12d, [rsp+0x50]
00007c454bbd05c2  mov [r13+r14*1], r12d
00007c454bbd05c7  lea r14, [rax+0x1C]
00007c454bbd05cb  mov r12d, [rsp+0x60]
00007c454bbd05d0  mov [r13+r14*1], r12d
00007c454bbd05d5  lea r14, [rax+0x68]
00007c454bbd05d9  xor eax, eax
00007c454bbd05db  mov [r13+r14*1], rax
00007c454bbd05e0  cmp dword ptr [r15+0x318], 0x00
00007c454bbd05e8  jz 0x00007C454BBCF0E0
00007c454bbd05ee  nop [rax+rax*1], ax
00007c454bbd05f7  nop [rax+rax*1], eax
00007c454bbd05ff  mov eax, 0x410768
00007c454bbd0604  mov [r15+0x100], rax
00007c454bbd060b  jmp 0x00007C454B9FE110
00007c454bbd0610  int3
00007c454bbd0611  call 0x00007C454BAE2BA0
00007c454bbd0616  jmp 0x00007C454BBD050F
00007c454bbd061b  call 0x00007C454BAE1920
00007c454bbd0620  jmp 0x00007C454BBD0518
00007c454bbd0625  call 0x00007C454BA0DFE0
00007c454bbd062a  jmp 0x00007C454BBD058F
00007c454bbd062f  call 0x00007C454BAE2BA0
00007c454bbd0634  jmp 0x00007C454BBD059D
00007c454bbd0639  call 0x00007C454BAE2BA0
00007c454bbd063e  jmp 0x00007C454BBD05AB
00007c454bbd0643  call 0x00007C454BAE2BA0
00007c454bbd0648  jmp 0x00007C454BBD05B9
00007c454bbd064d  call 0x00007C454BAE2BA0
00007c454bbd0652  jmp 0x00007C454BBD05C7
00007c454bbd0657  call 0x00007C454BAE2BA0
00007c454bbd065c  jmp 0x00007C454BBD05D5
00007c454bbd0661  call 0x00007C454BAD5EB0
00007c454bbd0666  jmp 0x00007C454BBD05E0
00007c454bbd066b  int3
00007c454bbd066c  nop [rax], eax
00007c454bbd0670  mov rax, [r15+0xF8]
00007c454bbd0677  lea r14, [rax+0x140]
00007c454bbd067e  mov r12, [r13+r14*1]
00007c454bbd0683  lea r14, [rax+0x148]
00007c454bbd068a  mov r11, [r13+r14*1]
00007c454bbd068f  mov [r15+0xA0], r12
00007c454bbd0696  mov [r15+0x98], r11
00007c454bbd069d  lea r14, [rax+0x130]
00007c454bbd06a4  mov r12, [r13+r14*1]
00007c454bbd06a9  lea r14, [rax+0x138]
00007c454bbd06b0  mov r11, [r13+r14*1]
00007c454bbd06b5  mov [r15+0xB0], r12
00007c454bbd06bc  mov [r15+0xA8], r11
00007c454bbd06c3  lea r14, [rax+0x120]
00007c454bbd06ca  mov r12, [r13+r14*1]
00007c454bbd06cf  lea r14, [rax+0x128]
00007c454bbd06d6  mov r11, [r13+r14*1]
00007c454bbd06db  mov [r15+0xC0], r12
00007c454bbd06e2  mov [r15+0xB8], r11
00007c454bbd06e9  lea r14, [rax+0x110]
00007c454bbd06f0  mov r12, [r13+r14*1]
00007c454bbd06f5  lea r14, [rax+0x118]
00007c454bbd06fc  mov r11, [r13+r14*1]
00007c454bbd0701  mov [r15+0xD0], r12
00007c454bbd0708  mov [r15+0xC8], r11
00007c454bbd070f  lea r14, [rax+0x100]
00007c454bbd0716  mov r12, [r13+r14*1]
00007c454bbd071b  lea r14, [rax+0x108]
00007c454bbd0722  mov r11, [r13+r14*1]
00007c454bbd0727  mov [r15+0xE8], r12
00007c454bbd072e  mov [r15+0xD8], r11
00007c454bbd0735  lea r14, [rax+0x150]
00007c454bbd073c  mov [r15+0xF8], r14
00007c454bbd0743  mov rax, [r15+0xF0]
00007c454bbd074a  mov [r15+0x100], rax
00007c454bbd0751  jmp 0x00007C454BBCE5C0
00007c454bbd0756  int3
00007c454bbd0757  call 0x00007C454BAE27E0
00007c454bbd075c  jmp 0x00007C454BBD0683
00007c454bbd0761  call 0x00007C454BAE1570
00007c454bbd0766  jmp 0x00007C454BBD068F
00007c454bbd076b  call 0x00007C454BAE27E0
00007c454bbd0770  jmp 0x00007C454BBD06A9
00007c454bbd0775  call 0x00007C454BAE1570
00007c454bbd077a  jmp 0x00007C454BBD06B5
00007c454bbd077f  call 0x00007C454BAE27E0
00007c454bbd0784  jmp 0x00007C454BBD06CF
00007c454bbd0789  call 0x00007C454BAE1570
00007c454bbd078e  jmp 0x00007C454BBD06DB
00007c454bbd0793  call 0x00007C454BAE27E0
00007c454bbd0798  jmp 0x00007C454BBD06F5
00007c454bbd079d  call 0x00007C454BAE1570
00007c454bbd07a2  jmp 0x00007C454BBD0701
00007c454bbd07a7  call 0x00007C454BAE27E0
00007c454bbd07ac  jmp 0x00007C454BBD071B
00007c454bbd07b1  call 0x00007C454BAE1570
00007c454bbd07b6  jmp 0x00007C454BBD0727
00007c454bbd07bb  int3
00007c454bbd07bc  nop [rax], eax
00007c454bbd07c0  mov eax, [r15+0xA0]
00007c454bbd07c7  mov [rsp+0x10], eax
00007c454bbd07cb  xor eax, eax
00007c454bbd07cd  mov r14d, [rsp+0x10]
00007c454bbd07d2  sub r14d, 0x01
00007c454bbd07d6  cmc
00007c454bbd07d7  lahf
00007c454bbd07d8  seto al
00007c454bbd07db  mov [r15+0x108], eax
00007c454bbd07e2  mov r14d, r14d
00007c454bbd07e5  mov [r15+0xA0], r14
00007c454bbd07ec  mov eax, [r15+0x108]
00007c454bbd07f3  sahf
00007c454bbd07f4  jnz 0x00007C454BBD0826
00007c454bbd07f6  cmp dword ptr [r15+0x318], 0x00
00007c454bbd07fe  jz 0x00007C454BBD0900
00007c454bbd0804  nop [rax+rax*1], ax
00007c454bbd080d  nop [rax+rax*1], eax
00007c454bbd0815  mov eax, 0x41028C
00007c454bbd081a  mov [r15+0x100], rax
00007c454bbd0821  jmp 0x00007C454B9FE110
00007c454bbd0826  cmp dword ptr [r15+0x318], 0x00
00007c454bbd082e  jz 0x00007C454BBD0860
00007c454bbd0834  nop [rax+rax*1], ax
00007c454bbd083d  nop [rax+rax*1], eax
00007c454bbd0845  mov eax, 0x410274
00007c454bbd084a  mov [r15+0x100], rax
00007c454bbd0851  jmp 0x00007C454B9FE110
00007c454bbd0856  int3
00007c454bbd0857  int3
00007c454bbd0858  nop [rax+rax*1], eax
00007c454bbd0860  mov rax, [r15+0xF8]
00007c454bbd0867  lea r14, [rax+0x100]
00007c454bbd086e  mov [r15], r14
00007c454bbd0871  mov rax, [r15+0x98]
00007c454bbd0878  mov [r15+0x08], rax
00007c454bbd087c  mov qword ptr [r15+0x10], 0x12C
00007c454bbd0884  mov qword ptr [r15+0xF0], 0x410284
00007c454bbd088f  mov r14d, [r15+0x320]
00007c454bbd0896  mov eax, 0x410284
00007c454bbd089b  mov rcx, 0x7C454BBD07C0
00007c454bbd08a5  mov [r15+r14*8+0x328], rax
00007c454bbd08ad  mov [r15+r14*8+0x368], rcx
00007c454bbd08b5  add r14d, 0x01
00007c454bbd08b9  and r14d, 0x07
00007c454bbd08bd  mov [r15+0x320], r14d
00007c454bbd08c4  cmp dword ptr [r15+0x318], 0x00
00007c454bbd08cc  jz 0x00007C454BBCED70
00007c454bbd08d2  nop [rax+rax*1], ax
00007c454bbd08db  nop [rax+rax*1], eax
00007c454bbd08e3  mov eax, 0x410728
00007c454bbd08e8  mov [r15+0x100], rax
00007c454bbd08ef  jmp 0x00007C454B9FE110
00007c454bbd08f4  int3
00007c454bbd08f5  int3
00007c454bbd08f6  nop [rax+rax*1], ax
00007c454bbd08ff  nop
00007c454bbd0900  mov rax, [r15+0xF8]
00007c454bbd0907  lea r14, [rax+0x120]
00007c454bbd090e  mov r12, [r13+r14*1]
00007c454bbd0913  mov [r15+0x98], r12
00007c454bbd091a  mov qword ptr [r15+0x40], 0x80
00007c454bbd0922  lea r14, [rax+0x100]
00007c454bbd0929  mov [r15], r14
00007c454bbd092c  lea r14, [rax+0x17C]
00007c454bbd0933  mov [r15+0x08], r14
00007c454bbd0937  mov qword ptr [r15+0x10], 0x01
00007c454bbd093f  lea r14, [rax+0x17C]
00007c454bbd0946  mov eax, 0x80
00007c454bbd094b  mov [r13+r14*1], al
00007c454bbd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007c454bbd095b  mov r14d, [r15+0x320]
00007c454bbd0962  mov eax, 0x4102A8
00007c454bbd0967  mov rcx, 0x7C454BBD09E0
00007c454bbd0971  mov [r15+r14*8+0x328], rax
00007c454bbd0979  mov [r15+r14*8+0x368], rcx
00007c454bbd0981  add r14d, 0x01
00007c454bbd0985  and r14d, 0x07
00007c454bbd0989  mov [r15+0x320], r14d
00007c454bbd0990  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0998  jz 0x00007C454BBCED70
00007c454bbd099e  nop [rax+rax*1], ax
00007c454bbd09a7  nop [rax+rax*1], eax
00007c454bbd09af  mov eax, 0x410728
00007c454bbd09b4  mov [r15+0x100], rax
00007c454bbd09bb  jmp 0x00007C454B9FE110
00007c454bbd09c0  int3
00007c454bbd09c1  call 0x00007C454BAE27E0
00007c454bbd09c6  jmp 0x00007C454BBD0913
00007c454bbd09cb  call 0x00007C454BAD5AF0
00007c454bbd09d0  jmp 0x00007C454BBD0950
00007c454bbd09d5  int3
00007c454bbd09d6  nop [rax+rax*1], ax
00007c454bbd09df  nop
00007c454bbd09e0  mov rax, [r15+0xF8]
00007c454bbd09e7  lea r14, [rax+0x168]
00007c454bbd09ee  mov r12, [r13+r14*1]
00007c454bbd09f3  mov [r15+0x40], r12
00007c454bbd09f7  lea r14, [rax+0x178]
00007c454bbd09fe  xor eax, eax
00007c454bbd0a00  mov [r13+r14*1], al
00007c454bbd0a05  xor eax, eax
00007c454bbd0a07  mov r14d, 0x38
00007c454bbd0a0d  cmp r12, r14
00007c454bbd0a10  cmc
00007c454bbd0a11  lahf
00007c454bbd0a12  seto al
00007c454bbd0a15  mov [r15+0x108], eax
00007c454bbd0a1c  mov eax, [r15+0x108]
00007c454bbd0a23  sahf
00007c454bbd0a24  jz 0x00007C454BBD0A56
00007c454bbd0a26  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0a2e  jz 0x00007C454BBD0AA0
00007c454bbd0a34  nop [rax+rax*1], ax
00007c454bbd0a3d  nop [rax+rax*1], eax
00007c454bbd0a45  mov eax, 0x4102B8
00007c454bbd0a4a  mov [r15+0x100], rax
00007c454bbd0a51  jmp 0x00007C454B9FE110
00007c454bbd0a56  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0a5e  jz 0x00007C454BBD0BF0
00007c454bbd0a64  nop [rax+rax*1], ax
00007c454bbd0a6d  nop [rax+rax*1], eax
00007c454bbd0a75  mov eax, 0x4102D4
00007c454bbd0a7a  mov [r15+0x100], rax
00007c454bbd0a81  jmp 0x00007C454B9FE110
00007c454bbd0a86  int3
00007c454bbd0a87  call 0x00007C454BAE27E0
00007c454bbd0a8c  jmp 0x00007C454BBD09F3
00007c454bbd0a91  call 0x00007C454BAD5AF0
00007c454bbd0a96  jmp 0x00007C454BBD0A05
00007c454bbd0a9b  int3
00007c454bbd0a9c  nop [rax], eax
00007c454bbd0aa0  mov rax, [r15+0xF8]
00007c454bbd0aa7  lea r14, [rax+0x100]
00007c454bbd0aae  mov [r15], r14
00007c454bbd0ab1  lea r14, [rax+0x178]
00007c454bbd0ab8  mov [r15+0x08], r14
00007c454bbd0abc  mov qword ptr [r15+0x10], 0x01
00007c454bbd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007c454bbd0acf  mov r14d, [r15+0x320]
00007c454bbd0ad6  mov eax, 0x4102C8
00007c454bbd0adb  mov rcx, 0x7C454BBD0B40
00007c454bbd0ae5  mov [r15+r14*8+0x328], rax
00007c454bbd0aed  mov [r15+r14*8+0x368], rcx
00007c454bbd0af5  add r14d, 0x01
00007c454bbd0af9  and r14d, 0x07
00007c454bbd0afd  mov [r15+0x320], r14d
00007c454bbd0b04  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0b0c  jz 0x00007C454BBCED70
00007c454bbd0b12  nop [rax+rax*1], ax
00007c454bbd0b1b  nop [rax+rax*1], eax
00007c454bbd0b23  mov eax, 0x410728
00007c454bbd0b28  mov [r15+0x100], rax
00007c454bbd0b2f  jmp 0x00007C454B9FE110
00007c454bbd0b34  int3
00007c454bbd0b35  int3
00007c454bbd0b36  nop [rax+rax*1], ax
00007c454bbd0b3f  nop
00007c454bbd0b40  mov rax, [r15+0xF8]
00007c454bbd0b47  lea r14, [rax+0x168]
00007c454bbd0b4e  mov rax, [r13+r14*1]
00007c454bbd0b53  mov [r15+0x40], rax
00007c454bbd0b57  mov [rsp+0x10], rax
00007c454bbd0b5c  xor eax, eax
00007c454bbd0b5e  mov r14, [rsp+0x10]
00007c454bbd0b63  mov r12d, 0x38
00007c454bbd0b69  cmp r14, r12
00007c454bbd0b6c  cmc
00007c454bbd0b6d  lahf
00007c454bbd0b6e  seto al
00007c454bbd0b71  mov [r15+0x108], eax
00007c454bbd0b78  mov eax, [r15+0x108]
00007c454bbd0b7f  sahf
00007c454bbd0b80  jnz 0x00007C454BBD0BB2
00007c454bbd0b82  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0b8a  jz 0x00007C454BBD0BF0
00007c454bbd0b90  nop [rax+rax*1], ax
00007c454bbd0b99  nop [rax+rax*1], eax
00007c454bbd0ba1  mov eax, 0x4102D4
00007c454bbd0ba6  mov [r15+0x100], rax
00007c454bbd0bad  jmp 0x00007C454B9FE110
00007c454bbd0bb2  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0bba  jz 0x00007C454BBD0AA0
00007c454bbd0bc0  nop [rax+rax*1], ax
00007c454bbd0bc9  nop [rax+rax*1], eax
00007c454bbd0bd1  mov eax, 0x4102B8
00007c454bbd0bd6  mov [r15+0x100], rax
00007c454bbd0bdd  jmp 0x00007C454B9FE110
00007c454bbd0be2  int3
00007c454bbd0be3  call 0x00007C454BAD59C0
00007c454bbd0be8  jmp 0x00007C454BBD0B53
00007c454bbd0bed  int3
00007c454bbd0bee  nop
00007c454bbd0bf0  mov rax, [r15+0x98]
00007c454bbd0bf7  rorx r14, rax, 0x3D
00007c454bbd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007c454bbd0c01  mov rax, [r15+0xF8]
00007c454bbd0c08  lea r12, [rax+0x100]
00007c454bbd0c0f  mov [r15], r12
00007c454bbd0c12  lea r12, [rax+0x170]
00007c454bbd0c19  mov [r15+0x08], r12
00007c454bbd0c1d  mov qword ptr [r15+0x10], 0x08
00007c454bbd0c25  bswap r14
00007c454bbd0c28  mov [r15+0x40], r14
00007c454bbd0c2c  lea r12, [rax+0x170]
00007c454bbd0c33  mov [r13+r12*1], r14
00007c454bbd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007c454bbd0c43  mov r14d, [r15+0x320]
00007c454bbd0c4a  mov eax, 0x4102F0
00007c454bbd0c4f  mov rcx, 0x7C454BBD0CC0
00007c454bbd0c59  mov [r15+r14*8+0x328], rax
00007c454bbd0c61  mov [r15+r14*8+0x368], rcx
00007c454bbd0c69  add r14d, 0x01
00007c454bbd0c6d  and r14d, 0x07
00007c454bbd0c71  mov [r15+0x320], r14d
00007c454bbd0c78  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0c80  jz 0x00007C454BBCED70
00007c454bbd0c86  nop [rax+rax*1], ax
00007c454bbd0c8f  nop [rax+rax*1], eax
00007c454bbd0c97  mov eax, 0x410728
00007c454bbd0c9c  mov [r15+0x100], rax
00007c454bbd0ca3  jmp 0x00007C454B9FE110
00007c454bbd0ca8  int3
00007c454bbd0ca9  call 0x00007C454BAC3FE0
00007c454bbd0cae  jmp 0x00007C454BBD0C38
00007c454bbd0cb3  int3
00007c454bbd0cb4  nop [rax+rax*1], ax
00007c454bbd0cbd  nop [rax], eax
00007c454bbd0cc0  mov rax, [r15+0xF8]
00007c454bbd0cc7  lea r14, [rax+0x100]
00007c454bbd0cce  mov r12d, [r13+r14*1]
00007c454bbd0cd3  lea r14, [rax+0x104]
00007c454bbd0cda  mov r11d, [r13+r14*1]
00007c454bbd0cdf  mov qword ptr [r15+0x48], 0x430C90
00007c454bbd0ce7  lea r14, [rax+0x108]
00007c454bbd0cee  mov r10d, [r13+r14*1]
00007c454bbd0cf3  lea r14, [rax+0x10C]
00007c454bbd0cfa  mov r9d, [r13+r14*1]
00007c454bbd0cff  bswap r12d
00007c454bbd0d02  bswap r11d
00007c454bbd0d05  mov qword ptr [r15+0xA0], 0x00
00007c454bbd0d10  mov r14d, 0x430C90
00007c454bbd0d16  mov [r13+r14*1], r12d
00007c454bbd0d1b  mov r14d, 0x430C94
00007c454bbd0d21  mov [r13+r14*1], r11d
00007c454bbd0d26  bswap r10d
00007c454bbd0d29  lea r14, [rax+0x110]
00007c454bbd0d30  mov r12d, [r13+r14*1]
00007c454bbd0d35  bswap r9d
00007c454bbd0d38  lea r14, [rax+0x114]
00007c454bbd0d3f  mov r11d, [r13+r14*1]
00007c454bbd0d44  mov qword ptr [r15+0x98], 0x430DFC
00007c454bbd0d4f  mov r14d, 0x430C98
00007c454bbd0d55  mov [r13+r14*1], r10d
00007c454bbd0d5a  mov r14d, 0x430C9C
00007c454bbd0d60  mov [r13+r14*1], r9d
00007c454bbd0d65  bswap r12d
00007c454bbd0d68  lea r14, [rax+0x118]
00007c454bbd0d6f  mov r10d, [r13+r14*1]
00007c454bbd0d74  bswap r11d
00007c454bbd0d77  mov [rsp+0x10], r11d
00007c454bbd0d7c  mov r11d, r11d
00007c454bbd0d7f  mov [r15+0x58], r11
00007c454bbd0d83  lea r14, [rax+0x11C]
00007c454bbd0d8a  mov eax, [r13+r14*1]
00007c454bbd0d8f  mov [rsp+0x20], eax
00007c454bbd0d93  mov eax, eax
00007c454bbd0d95  mov [r15+0x60], rax
00007c454bbd0d99  mov eax, 0x430CA0
00007c454bbd0d9e  mov [r13+rax*1], r12d
00007c454bbd0da3  mov eax, 0x430CA4
00007c454bbd0da8  mov r14d, [rsp+0x10]
00007c454bbd0dad  mov [r13+rax*1], r14d
00007c454bbd0db2  bswap r10d
00007c454bbd0db5  mov [rsp+0x10], r10d
00007c454bbd0dba  mov r10d, r10d
00007c454bbd0dbd  mov [r15+0x40], r10
00007c454bbd0dc1  mov eax, [rsp+0x20]
00007c454bbd0dc5  bswap eax
00007c454bbd0dc7  mov [rsp+0x20], eax
00007c454bbd0dcb  mov eax, eax
00007c454bbd0dcd  mov [r15+0x50], rax
00007c454bbd0dd1  mov eax, 0x430CA8
00007c454bbd0dd6  mov r14d, [rsp+0x10]
00007c454bbd0ddb  mov [r13+rax*1], r14d
00007c454bbd0de0  mov eax, 0x430CAC
00007c454bbd0de5  mov r14d, [rsp+0x20]
00007c454bbd0dea  mov [r13+rax*1], r14d
00007c454bbd0def  mov eax, [r15+0xA0]
00007c454bbd0df6  lea r14d, [eax+0x11]
00007c454bbd0dfb  mov r14d, r14d
00007c454bbd0dfe  mov [r15], r14
00007c454bbd0e01  mov qword ptr [r15+0xF0], 0x41035C
00007c454bbd0e0c  mov r14d, [r15+0x320]
00007c454bbd0e13  mov eax, 0x41035C
00007c454bbd0e18  mov rcx, 0x7C454BBD0F90
00007c454bbd0e22  mov [r15+r14*8+0x328], rax
00007c454bbd0e2a  mov [r15+r14*8+0x368], rcx
00007c454bbd0e32  add r14d, 0x01
00007c454bbd0e36  and r14d, 0x07
00007c454bbd0e3a  mov [r15+0x320], r14d
00007c454bbd0e41  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0e49  jz 0x00007C454BBD0F20
00007c454bbd0e4f  nop [rax+rax*1], ax
00007c454bbd0e58  nop [rax+rax*1], eax
00007c454bbd0e60  mov eax, 0x4109A4
00007c454bbd0e65  mov [r15+0x100], rax
00007c454bbd0e6c  jmp 0x00007C454B9FE110
00007c454bbd0e71  int3
00007c454bbd0e72  call 0x00007C454BAE26A0
00007c454bbd0e77  jmp 0x00007C454BBD0CD3
00007c454bbd0e7c  call 0x00007C454BAE1430
00007c454bbd0e81  jmp 0x00007C454BBD0CDF
00007c454bbd0e86  call 0x00007C454BAE01C0
00007c454bbd0e8b  jmp 0x00007C454BBD0CF3
00007c454bbd0e90  call 0x00007C454BADEF50
00007c454bbd0e95  jmp 0x00007C454BBD0CFF
00007c454bbd0e9a  call 0x00007C454BAE2BA0
00007c454bbd0e9f  jmp 0x00007C454BBD0D1B
00007c454bbd0ea4  call 0x00007C454BAE1920
00007c454bbd0ea9  jmp 0x00007C454BBD0D26
00007c454bbd0eae  call 0x00007C454BAE26A0
00007c454bbd0eb3  jmp 0x00007C454BBD0D35
00007c454bbd0eb8  call 0x00007C454BAE1430
00007c454bbd0ebd  jmp 0x00007C454BBD0D44
00007c454bbd0ec2  call 0x00007C454BAE06B0
00007c454bbd0ec7  jmp 0x00007C454BBD0D5A
00007c454bbd0ecc  call 0x00007C454BADF440
00007c454bbd0ed1  jmp 0x00007C454BBD0D65
00007c454bbd0ed6  call 0x00007C454BAE01C0
00007c454bbd0edb  jmp 0x00007C454BBD0D74
00007c454bbd0ee0  call 0x00007C454BAD5890
00007c454bbd0ee5  jmp 0x00007C454BBD0D8F
00007c454bbd0eea  call 0x00007C454BA0BAE0
00007c454bbd0eef  jmp 0x00007C454BBD0DA3
00007c454bbd0ef4  call 0x00007C454BA0DFE0
00007c454bbd0ef9  jmp 0x00007C454BBD0DB2
00007c454bbd0efe  call 0x00007C454BA0DFE0
00007c454bbd0f03  jmp 0x00007C454BBD0DE0
00007c454bbd0f08  call 0x00007C454BA0DFE0
00007c454bbd0f0d  jmp 0x00007C454BBD0DEF
00007c454bbd0f12  int3
00007c454bbd0f13  nop [rax+rax*1], ax
00007c454bbd0f1c  nop [rax], eax
00007c454bbd0f20  mov eax, [r15]
00007c454bbd0f23  mov [rsp+0x10], eax
00007c454bbd0f27  shr eax, 0x10
00007c454bbd0f2a  mov r14d, [rsp+0x10]
00007c454bbd0f2f  xor r14d, eax
00007c454bbd0f32  imul r14d, r14d, 0x7FEB352D
00007c454bbd0f39  mov eax, 0x846CA68B
00007c454bbd0f3e  mov eax, eax
00007c454bbd0f40  mov [r15+0x48], rax
00007c454bbd0f44  mov [rsp+0x10], r14d
00007c454bbd0f49  shr r14d, 0x0F
00007c454bbd0f4d  mov eax, [rsp+0x10]
00007c454bbd0f51  xor eax, r14d
00007c454bbd0f54  imul eax, eax, 0x846CA68B
00007c454bbd0f5a  mov [rsp+0x10], eax
00007c454bbd0f5e  mov eax, eax
00007c454bbd0f60  mov [r15+0x40], rax
00007c454bbd0f64  mov eax, [rsp+0x10]
00007c454bbd0f68  shr eax, 0x10
00007c454bbd0f6b  mov r14d, [rsp+0x10]
00007c454bbd0f70  xor r14d, eax
00007c454bbd0f73  mov r14d, r14d
00007c454bbd0f76  mov [r15], r14
00007c454bbd0f79  mov rax, [r15+0xF0]
00007c454bbd0f80  mov [r15+0x100], rax
00007c454bbd0f87  jmp 0x00007C454BBCE5C0
00007c454bbd0f8c  int3
00007c454bbd0f8d  int3
00007c454bbd0f8e  nop
00007c454bbd0f90  mov rax, [r15+0xA0]
00007c454bbd0f97  mov [rsp+0x10], rax
00007c454bbd0f9c  shl rax, 0x02
00007c454bbd0fa0  mov r14, [r15+0x98]
00007c454bbd0fa7  lea r12, [r14+rax*1]
00007c454bbd0fab  mov eax, [r15]
00007c454bbd0fae  mov [r13+r12*1], eax
00007c454bbd0fb3  mov rax, [rsp+0x10]
00007c454bbd0fb8  lea r14, [rax+0x01]
00007c454bbd0fbc  mov [r15+0xA0], r14
00007c454bbd0fc3  xor eax, eax
00007c454bbd0fc5  mov r12d, 0x400
00007c454bbd0fcb  cmp r14, r12
00007c454bbd0fce  cmc
00007c454bbd0fcf  lahf
00007c454bbd0fd0  seto al
00007c454bbd0fd3  mov [r15+0x108], eax
00007c454bbd0fda  mov eax, [r15+0x108]
00007c454bbd0fe1  sahf
00007c454bbd0fe2  jnz 0x00007C454BBD1014
00007c454bbd0fe4  cmp dword ptr [r15+0x318], 0x00
00007c454bbd0fec  jz 0x00007C454BBD10E0
00007c454bbd0ff2  nop [rax+rax*1], ax
00007c454bbd0ffb  nop [rax+rax*1], eax
00007c454bbd1003  mov eax, 0x41036C
00007c454bbd1008  mov [r15+0x100], rax
00007c454bbd100f  jmp 0x00007C454B9FE110
00007c454bbd1014  cmp dword ptr [r15+0x318], 0x00
00007c454bbd101c  jz 0x00007C454BBD1050
00007c454bbd1022  nop [rax+rax*1], ax
00007c454bbd102b  nop [rax+rax*1], eax
00007c454bbd1033  mov eax, 0x410354
00007c454bbd1038  mov [r15+0x100], rax
00007c454bbd103f  jmp 0x00007C454B9FE110
00007c454bbd1044  int3
00007c454bbd1045  call 0x00007C454BAB4B70
00007c454bbd104a  jmp 0x00007C454BBD0FB3
00007c454bbd104f  int3
00007c454bbd1050  mov eax, [r15+0xA0]
00007c454bbd1057  lea r14d, [eax+0x11]
00007c454bbd105c  mov r14d, r14d
00007c454bbd105f  mov [r15], r14
00007c454bbd1062  mov qword ptr [r15+0xF0], 0x41035C
00007c454bbd106d  mov r14d, [r15+0x320]
00007c454bbd1074  mov eax, 0x41035C
00007c454bbd1079  mov rcx, 0x7C454BBD0F90
00007c454bbd1083  mov [r15+r14*8+0x328], rax
00007c454bbd108b  mov [r15+r14*8+0x368], rcx
00007c454bbd1093  add r14d, 0x01
00007c454bbd1097  and r14d, 0x07
00007c454bbd109b  mov [r15+0x320], r14d
00007c454bbd10a2  cmp dword ptr [r15+0x318], 0x00
00007c454bbd10aa  jz 0x00007C454BBD0F20
00007c454bbd10b0  nop [rax+rax*1], ax
00007c454bbd10b9  nop [rax+rax*1], eax
00007c454bbd10c1  mov eax, 0x4109A4
00007c454bbd10c6  mov [r15+0x100], rax
00007c454bbd10cd  jmp 0x00007C454B9FE110
00007c454bbd10d2  int3
00007c454bbd10d3  int3
00007c454bbd10d4  nop [rax+rax*1], ax
00007c454bbd10dd  nop [rax], eax
00007c454bbd10e0  mov qword ptr [r15+0x40], 0x01
00007c454bbd10e8  cmp dword ptr [r15+0x318], 0x00
00007c454bbd10f0  jz 0x00007C454BBD1120
00007c454bbd10f6  nop [rax+rax*1], ax
00007c454bbd10ff  nop [rax+rax*1], eax
00007c454bbd1107  mov eax, 0x410388
00007c454bbd110c  mov [r15+0x100], rax
00007c454bbd1113  jmp 0x00007C454B9FE110
00007c454bbd1118  int3
00007c454bbd1119  int3
00007c454bbd111a  nop [rax+rax*1], ax
00007c454bbd1120  mov rax, [r15+0x40]
00007c454bbd1124  mov [rsp+0x10], rax
00007c454bbd1129  shl rax, 0x02
00007c454bbd112d  mov r14, [r15+0x98]
00007c454bbd1134  lea r12, [r14+rax*1]
00007c454bbd1138  mov eax, [r13+r12*1]
00007c454bbd113d  mov [rsp+0x20], eax
00007c454bbd1141  mov eax, eax
00007c454bbd1143  mov [r15+0x48], rax
00007c454bbd1147  mov rax, [rsp+0x10]
00007c454bbd114c  mov [r15+0x50], rax
00007c454bbd1150  mov eax, [r15+0x50]
00007c454bbd1154  lea r12d, [eax-0x01]
00007c454bbd1159  mov r12d, r12d
00007c454bbd115c  mov [r15+0x58], r12
00007c454bbd1160  mov rax, [r15+0x58]
00007c454bbd1164  mov r12d, eax
00007c454bbd1167  mov r12d, r12d
00007c454bbd116a  shl r12, 0x02
00007c454bbd116e  lea rax, [r14+r12*1]
00007c454bbd1172  mov r14d, [r13+rax*1]
00007c454bbd1177  mov [rsp+0x10], r14d
00007c454bbd117c  mov r14d, r14d
00007c454bbd117f  mov [r15+0x60], r14
00007c454bbd1183  xor eax, eax
00007c454bbd1185  mov r14d, [rsp+0x10]
00007c454bbd118a  mov r12d, [rsp+0x20]
00007c454bbd118f  cmp r14d, r12d
00007c454bbd1192  cmc
00007c454bbd1193  lahf
00007c454bbd1194  seto al
00007c454bbd1197  mov [r15+0x108], eax
00007c454bbd119e  mov eax, [r15+0x108]
00007c454bbd11a5  sahf
00007c454bbd11a6  cmc
00007c454bbd11a7  jbe 0x00007C454BBD11D9
00007c454bbd11a9  cmp dword ptr [r15+0x318], 0x00
00007c454bbd11b1  jz 0x00007C454BBD1220
00007c454bbd11b7  nop [rax+rax*1], ax
00007c454bbd11c0  nop [rax+rax*1], eax
00007c454bbd11c8  mov eax, 0x4103A0
00007c454bbd11cd  mov [r15+0x100], rax
00007c454bbd11d4  jmp 0x00007C454B9FE110
00007c454bbd11d9  cmp dword ptr [r15+0x318], 0x00
00007c454bbd11e1  jz 0x00007C454BBD14C0
00007c454bbd11e7  nop [rax+rax*1], ax
00007c454bbd11f0  nop [rax+rax*1], eax
00007c454bbd11f8  mov eax, 0x410378
00007c454bbd11fd  mov [r15+0x100], rax
00007c454bbd1204  jmp 0x00007C454B9FE110
00007c454bbd1209  int3
00007c454bbd120a  call 0x00007C454BAB4690
00007c454bbd120f  jmp 0x00007C454BBD113D
00007c454bbd1214  call 0x00007C454BA0DAE0
00007c454bbd1219  jmp 0x00007C454BBD1177
00007c454bbd121e  int3
00007c454bbd121f  nop
00007c454bbd1220  mov rax, [r15+0x50]
00007c454bbd1224  mov [rsp+0x10], rax
00007c454bbd1229  shl rax, 0x02
00007c454bbd122d  mov r14, [r15+0x98]
00007c454bbd1234  lea r12, [r14+rax*1]
00007c454bbd1238  mov eax, [r15+0x60]
00007c454bbd123c  mov [r13+r12*1], eax
00007c454bbd1241  mov rax, [rsp+0x10]
00007c454bbd1246  lea r14, [rax-0x01]
00007c454bbd124a  mov [r15+0x50], r14
00007c454bbd124e  mov rax, [r15+0x58]
00007c454bbd1252  test rax, rax
00007c454bbd1255  setz al
00007c454bbd1258  movzx rax, al
00007c454bbd125c  mov [rsp+0x414], al
00007c454bbd1263  cmp byte ptr [rsp+0x414], 0x00
00007c454bbd126b  jz 0x00007C454BBD129D
00007c454bbd126d  cmp dword ptr [r15+0x318], 0x00
00007c454bbd1275  jz 0x00007C454BBD12E0
00007c454bbd127b  nop [rax+rax*1], ax
00007c454bbd1284  nop [rax+rax*1], eax
00007c454bbd128c  mov eax, 0x4103AC
00007c454bbd1291  mov [r15+0x100], rax
00007c454bbd1298  jmp 0x00007C454B9FE110
00007c454bbd129d  cmp dword ptr [r15+0x318], 0x00
00007c454bbd12a5  jz 0x00007C454BBD13E0
00007c454bbd12ab  nop [rax+rax*1], ax
00007c454bbd12b4  nop [rax+rax*1], eax
00007c454bbd12bc  mov eax, 0x410390
00007c454bbd12c1  mov [r15+0x100], rax
00007c454bbd12c8  jmp 0x00007C454B9FE110
00007c454bbd12cd  int3
00007c454bbd12ce  call 0x00007C454BAB4B70
00007c454bbd12d3  jmp 0x00007C454BBD1241
00007c454bbd12d8  int3
00007c454bbd12d9  nop [rax], eax
00007c454bbd12e0  cmp dword ptr [r15+0x318], 0x00
00007c454bbd12e8  jz 0x00007C454BBD1320
00007c454bbd12ee  nop [rax+rax*1], ax
00007c454bbd12f7  nop [rax+rax*1], eax
00007c454bbd12ff  mov eax, 0x410374
00007c454bbd1304  mov [r15+0x100], rax
00007c454bbd130b  jmp 0x00007C454B9FE110
00007c454bbd1310  int3
00007c454bbd1311  int3
00007c454bbd1312  nop [rax+rax*1], ax
00007c454bbd131b  nop [rax+rax*1], eax
00007c454bbd1320  mov qword ptr [r15+0x50], 0x00
00007c454bbd1328  mov rax, [r15+0x40]
00007c454bbd132c  lea r14, [rax+0x01]
00007c454bbd1330  mov [r15+0x40], r14
00007c454bbd1334  mov rax, [r15+0x98]
00007c454bbd133b  mov r12d, [r15+0x48]
00007c454bbd133f  mov [r13+rax*1], r12d
00007c454bbd1344  xor eax, eax
00007c454bbd1346  mov r12d, 0x400
00007c454bbd134c  cmp r14, r12
00007c454bbd134f  cmc
00007c454bbd1350  lahf
00007c454bbd1351  seto al
00007c454bbd1354  mov [r15+0x108], eax
00007c454bbd135b  mov eax, [r15+0x108]
00007c454bbd1362  sahf
00007c454bbd1363  jz 0x00007C454BBD1395
00007c454bbd1365  cmp dword ptr [r15+0x318], 0x00
00007c454bbd136d  jz 0x00007C454BBD1120
00007c454bbd1373  nop [rax+rax*1], ax
00007c454bbd137c  nop [rax+rax*1], eax
00007c454bbd1384  mov eax, 0x410388
00007c454bbd1389  mov [r15+0x100], rax
00007c454bbd1390  jmp 0x00007C454B9FE110
00007c454bbd1395  cmp dword ptr [r15+0x318], 0x00
00007c454bbd139d  jz 0x00007C454BBD1580
00007c454bbd13a3  nop [rax+rax*1], ax
00007c454bbd13ac  nop [rax+rax*1], eax
00007c454bbd13b4  mov eax, 0x4103B0
00007c454bbd13b9  mov [r15+0x100], rax
00007c454bbd13c0  jmp 0x00007C454B9FE110
00007c454bbd13c5  int3
00007c454bbd13c6  call 0x00007C454BA0BAE0
00007c454bbd13cb  jmp 0x00007C454BBD1344
00007c454bbd13d0  int3
00007c454bbd13d1  nop [rax+rax*1], ax
00007c454bbd13da  nop [rax+rax*1], ax
00007c454bbd13e0  mov eax, [r15+0x50]
00007c454bbd13e4  lea r14d, [eax-0x01]
00007c454bbd13e9  mov r14d, r14d
00007c454bbd13ec  mov [r15+0x58], r14
00007c454bbd13f0  mov rax, [r15+0x58]
00007c454bbd13f4  mov r14d, eax
00007c454bbd13f7  mov r14d, r14d
00007c454bbd13fa  shl r14, 0x02
00007c454bbd13fe  mov rax, [r15+0x98]
00007c454bbd1405  lea r12, [rax+r14*1]
00007c454bbd1409  mov eax, [r13+r12*1]
00007c454bbd140e  mov [rsp+0x10], eax
00007c454bbd1412  mov eax, eax
00007c454bbd1414  mov [r15+0x60], rax
00007c454bbd1418  mov eax, [r15+0x48]
00007c454bbd141c  mov [rsp+0x20], eax
00007c454bbd1420  xor eax, eax
00007c454bbd1422  mov r14d, [rsp+0x10]
00007c454bbd1427  mov r12d, [rsp+0x20]
00007c454bbd142c  cmp r14d, r12d
00007c454bbd142f  cmc
00007c454bbd1430  lahf
00007c454bbd1431  seto al
00007c454bbd1434  mov [r15+0x108], eax
00007c454bbd143b  mov eax, [r15+0x108]
00007c454bbd1442  sahf
00007c454bbd1443  cmc
00007c454bbd1444  jbe 0x00007C454BBD1476
00007c454bbd1446  cmp dword ptr [r15+0x318], 0x00
00007c454bbd144e  jz 0x00007C454BBD1220
00007c454bbd1454  nop [rax+rax*1], ax
00007c454bbd145d  nop [rax+rax*1], eax
00007c454bbd1465  mov eax, 0x4103A0
00007c454bbd146a  mov [r15+0x100], rax
00007c454bbd1471  jmp 0x00007C454B9FE110
00007c454bbd1476  cmp dword ptr [r15+0x318], 0x00
00007c454bbd147e  jz 0x00007C454BBD14C0
00007c454bbd1484  nop [rax+rax*1], ax
00007c454bbd148d  nop [rax+rax*1], eax
00007c454bbd1495  mov eax, 0x410378
00007c454bbd149a  mov [r15+0x100], rax
00007c454bbd14a1  jmp 0x00007C454B9FE110
00007c454bbd14a6  int3
00007c454bbd14a7  call 0x00007C454BAB4690
00007c454bbd14ac  jmp 0x00007C454BBD140E
00007c454bbd14b1  int3
00007c454bbd14b2  nop [rax+rax*1], ax
00007c454bbd14bb  nop [rax+rax*1], eax
00007c454bbd14c0  mov rax, [r15+0x40]
00007c454bbd14c4  lea r14, [rax+0x01]
00007c454bbd14c8  mov [r15+0x40], r14
00007c454bbd14cc  mov rax, [r15+0x50]
00007c454bbd14d0  mov r12d, eax
00007c454bbd14d3  mov r12d, r12d
00007c454bbd14d6  shl r12, 0x02
00007c454bbd14da  mov rax, [r15+0x98]
00007c454bbd14e1  lea r11, [rax+r12*1]
00007c454bbd14e5  mov eax, [r15+0x48]
00007c454bbd14e9  mov [r13+r11*1], eax
00007c454bbd14ee  xor eax, eax
00007c454bbd14f0  mov r12d, 0x400
00007c454bbd14f6  cmp r14, r12
00007c454bbd14f9  cmc
00007c454bbd14fa  lahf
00007c454bbd14fb  seto al
00007c454bbd14fe  mov [r15+0x108], eax
00007c454bbd1505  mov eax, [r15+0x108]
00007c454bbd150c  sahf
00007c454bbd150d  jz 0x00007C454BBD153F
00007c454bbd150f  cmp dword ptr [r15+0x318], 0x00
00007c454bbd1517  jz 0x00007C454BBD1120
00007c454bbd151d  nop [rax+rax*1], ax
00007c454bbd1526  nop [rax+rax*1], eax
00007c454bbd152e  mov eax, 0x410388
00007c454bbd1533  mov [r15+0x100], rax
00007c454bbd153a  jmp 0x00007C454B9FE110
00007c454bbd153f  cmp dword ptr [r15+0x318], 0x00
00007c454bbd1547  jz 0x00007C454BBD1580
00007c454bbd154d  nop [rax+rax*1], ax
00007c454bbd1556  nop [rax+rax*1], eax
00007c454bbd155e  mov eax, 0x4103B0
00007c454bbd1563  mov [r15+0x100], rax
00007c454bbd156a  jmp 0x00007C454B9FE110
00007c454bbd156f  int3
00007c454bbd1570  call 0x00007C454BAA4270
00007c454bbd1575  jmp 0x00007C454BBD14EE
00007c454bbd157a  int3
00007c454bbd157b  nop [rax+rax*1], eax
00007c454bbd1580  mov qword ptr [r15+0x40], 0x430000
00007c454bbd1588  mov eax, 0x430CB0
00007c454bbd158d  mov r14, [r13+rax*1]
00007c454bbd1592  mov rax, [r15+0x98]
00007c454bbd1599  mov r12d, [r13+rax*1]
00007c454bbd159e  lea r11, [rax+0x04]
00007c454bbd15a2  mov eax, [r13+r11*1]
00007c454bbd15a7  mov r12d, r12d
00007c454bbd15aa  mov [r15+0x68], r12
00007c454bbd15ae  mov eax, eax
00007c454bbd15b0  mov [r15+0x60], rax
00007c454bbd15b4  mov rax, [r15+0x68]
00007c454bbd15b8  mov [r15+0x68], rax
00007c454bbd15bc  mov qword ptr [r15+0x58], 0x02
00007c454bbd15c4  mov [rsp+0x10], rax
00007c454bbd15c9  xor eax, eax
00007c454bbd15cb  mov r12d, 0x02
00007c454bbd15d1  mov r11d, 0x400
00007c454bbd15d7  cmp r12, r11
00007c454bbd15da  cmc
00007c454bbd15db  lahf
00007c454bbd15dc  seto al
00007c454bbd15df  mov [r15+0x108], eax
00007c454bbd15e6  mov rax, [r15+0x60]
00007c454bbd15ea  mov r12d, 0x02
00007c454bbd15f0  imul rax, r12
00007c454bbd15f4  mov [r15+0x50], rax
00007c454bbd15f8  mov rax, [rsp+0x10]
00007c454bbd15fd  lea r12, [rax+r14*1]
00007c454bbd1601  mov [r15+0x48], r12
00007c454bbd1605  mov eax, [r15+0x108]
00007c454bbd160c  sahf
00007c454bbd160d  jnz 0x00007C454BBD163F
00007c454bbd160f  cmp dword ptr [r15+0x318], 0x00
00007c454bbd1617  jz 0x00007C454BBD17B0
00007c454bbd161d  nop [rax+rax*1], ax
00007c454bbd1626  nop [rax+rax*1], eax
00007c454bbd162e  mov eax, 0x4103E0
00007c454bbd1633  mov [r15+0x100], rax
00007c454bbd163a  jmp 0x00007C454B9FE110
00007c454bbd163f  cmp dword ptr [r15+0x318], 0x00
00007c454bbd1647  jz 0x00007C454BBD1690
00007c454bbd164d  nop [rax+rax*1], ax
00007c454bbd1656  nop [rax+rax*1], eax
00007c454bbd165e  mov eax, 0x4103C0
00007c454bbd1663  mov [r15+0x100], rax
00007c454bbd166a  jmp 0x00007C454B9FE110
00007c454bbd166f  int3
00007c454bbd1670  call 0x00007C454BA0DC20
00007c454bbd1675  jmp 0x00007C454BBD1592
00007c454bbd167a  call 0x00007C454BA0B5E0
00007c454bbd167f  jmp 0x00007C454BBD159E
00007c454bbd1684  call 0x00007C454BAA3D90
00007c454bbd1689  jmp 0x00007C454BBD15A7
00007c454bbd168e  int3
00007c454bbd168f  nop
00007c454bbd1690  mov rax, [r15+0x98]
00007c454bbd1697  mov r14, [r15+0x58]
00007c454bbd169b  mov [rsp+0x10], r14
00007c454bbd16a0  shl r14, 0x02
00007c454bbd16a4  lea r12, [rax+r14*1]
00007c454bbd16a8  mov eax, [r13+r12*1]
00007c454bbd16ad  lea r14, [r12+0x04]
00007c454bbd16b2  mov r12d, [r13+r14*1]
00007c454bbd16b7  mov eax, eax
00007c454bbd16b9  mov [r15+0x68], rax
00007c454bbd16bd  mov r12d, r12d
00007c454bbd16c0  mov [r15+0x60], r12
00007c454bbd16c4  mov rax, [r15+0x68]
00007c454bbd16c8  mov [rsp+0x20], rax
00007c454bbd16cd  mov r14, [rsp+0x10]
00007c454bbd16d2  imul rax, r14
00007c454bbd16d6  mov r12, [rsp+0x20]
00007c454bbd16db  lea r11, [r12+rax*1]
00007c454bbd16df  mov [r15+0x68], r11
00007c454bbd16e3  lea rax, [r14+0x02]
00007c454bbd16e7  mov [r15+0x58], rax
00007c454bbd16eb  mov [rsp+0x10], rax
00007c454bbd16f0  xor eax, eax
00007c454bbd16f2  mov r14, [rsp+0x10]
00007c454bbd16f7  mov r12d, 0x400
00007c454bbd16fd  cmp r14, r12
00007c454bbd1700  cmc
00007c454bbd1701  lahf
00007c454bbd1702  seto al
00007c454bbd1705  mov [r15+0x108], eax
00007c454bbd170c  mov rax, [r15+0x50]
00007c454bbd1710  mov r12, [r15+0x60]
00007c454bbd1714  imul r14, r12
00007c454bbd1718  lea r12, [rax+r14*1]
00007c454bbd171c  mov [r15+0x50], r12
00007c454bbd1720  mov rax, [r15+0x48]
00007c454bbd1724  lea r14, [r11+rax*1]
00007c454bbd1728  mov [r15+0x48], r14
00007c454bbd172c  mov eax, [r15+0x108]
00007c454bbd1733  sahf
00007c454bbd1734  jnz 0x00007C454BBD1766
00007c454bbd1736  cmp dword ptr [r15+0x318], 0x00
00007c454bbd173e  jz 0x00007C454BBD17B0
00007c454bbd1744  nop [rax+rax*1], ax
00007c454bbd174d  nop [rax+rax*1], eax
00007c454bbd1755  mov eax, 0x4103E0
00007c454bbd175a  mov [r15+0x100], rax
00007c454bbd1761  jmp 0x00007C454B9FE110
00007c454bbd1766  cmp dword ptr [r15+0x318], 0x00
00007c454bbd176e  jz 0x00007C454BBD1690
00007c454bbd1774  nop [rax+rax*1], ax
00007c454bbd177d  nop [rax+rax*1], eax
00007c454bbd1785  mov eax, 0x4103C0
00007c454bbd178a  mov [r15+0x100], rax
00007c454bbd1791  jmp 0x00007C454B9FE110
00007c454bbd1796  int3
00007c454bbd1797  call 0x00007C454BAB4690
00007c454bbd179c  jmp 0x00007C454BBD16AD
00007c454bbd17a1  call 0x00007C454BAE26A0
00007c454bbd17a6  jmp 0x00007C454BBD16B7
00007c454bbd17ab  int3
00007c454bbd17ac  nop [rax], eax
00007c454bbd17b0  mov qword ptr [r15+0x98], 0x00
00007c454bbd17bb  mov rax, [r15+0x50]
00007c454bbd17bf  mov r14, [r15+0x48]
00007c454bbd17c3  lea r12, [rax+r14*1]
00007c454bbd17c7  mov [r15+0x48], r12
00007c454bbd17cb  mov rax, [r15+0x40]
00007c454bbd17cf  lea r14, [rax+0xCB0]
00007c454bbd17d6  mov [r13+r14*1], r12
00007c454bbd17db  mov qword ptr [r15], 0x01
00007c454bbd17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007c454bbd17ed  mov r14d, [r15+0x320]
00007c454bbd17f4  mov eax, 0x4103F8
00007c454bbd17f9  mov rcx, 0x7C454BBD1860
00007c454bbd1803  mov [r15+r14*8+0x328], rax
00007c454bbd180b  mov [r15+r14*8+0x368], rcx
00007c454bbd1813  add r14d, 0x01
00007c454bbd1817  and r14d, 0x07
00007c454bbd181b  mov [r15+0x320], r14d
00007c454bbd1822  cmp dword ptr [r15+0x318], 0x00
00007c454bbd182a  jz 0x00007C454BBD0F20
00007c454bbd1830  nop [rax+rax*1], ax
00007c454bbd1839  nop [rax+rax*1], eax
00007c454bbd1841  mov eax, 0x4109A4
00007c454bbd1846  mov [r15+0x100], rax
00007c454bbd184d  jmp 0x00007C454B9FE110
00007c454bbd1852  int3
00007c454bbd1853  call 0x00007C454BAE2CE0
00007c454bbd1858  jmp 0x00007C454BBD17DB
00007c454bbd185d  int3
00007c454bbd185e  nop
00007c454bbd1860  mov eax, [r15+0x98]
00007c454bbd1867  lea r14d, [eax+0x01]
00007c454bbd186c  mov [rsp+0x10], r14d
00007c454bbd1871  mov r14d, r14d
00007c454bbd1874  mov [r15+0x98], r14
00007c454bbd187b  xor eax, eax
00007c454bbd187d  mov r14d, [rsp+0x10]
00007c454bbd1882  cmp r14d, 0x10000
00007c454bbd1889  cmc
00007c454bbd188a  lahf
00007c454bbd188b  seto al
00007c454bbd188e  mov [r15+0x108], eax
00007c454bbd1895  mov eax, [r15+0x108]
00007c454bbd189c  sahf
00007c454bbd189d  jnz 0x00007C454BBD18CF
00007c454bbd189f  cmp dword ptr [r15+0x318], 0x00
00007c454bbd18a7  jz 0x00007C454BBD19A0
00007c454bbd18ad  nop [rax+rax*1], ax
00007c454bbd18b6  nop [rax+rax*1], eax
00007c454bbd18be  mov eax, 0x410404
00007c454bbd18c3  mov [r15+0x100], rax
00007c454bbd18ca  jmp 0x00007C454B9FE110
00007c454bbd18cf  cmp dword ptr [r15+0x318], 0x00
00007c454bbd18d7  jz 0x00007C454BBD1910
00007c454bbd18dd  nop [rax+rax*1], ax
00007c454bbd18e6  nop [rax+rax*1], eax
00007c454bbd18ee  mov eax, 0x4103F0
00007c454bbd18f3  mov [r15+0x100], rax
00007c454bbd18fa  jmp 0x00007C454B9FE110
00007c454bbd18ff  int3
00007c454bbd1900  int3
00007c454bbd1901  nop [rax+rax*1], ax
00007c454bbd190a  nop [rax+rax*1], ax
00007c454bbd1910  mov eax, [r15]
00007c454bbd1913  mov r14d, [r15+0x98]
00007c454bbd191a  lea r12d, [eax+r14d*1]
00007c454bbd191f  mov r12d, r12d
00007c454bbd1922  mov [r15], r12
00007c454bbd1925  mov qword ptr [r15+0xF0], 0x4103F8
00007c454bbd1930  mov r14d, [r15+0x320]
00007c454bbd1937  mov eax, 0x4103F8
00007c454bbd193c  mov rcx, 0x7C454BBD1860
00007c454bbd1946  mov [r15+r14*8+0x328], rax
00007c454bbd194e  mov [r15+r14*8+0x368], rcx
00007c454bbd1956  add r14d, 0x01
00007c454bbd195a  and r14d, 0x07
00007c454bbd195e  mov [r15+0x320], r14d
00007c454bbd1965  cmp dword ptr [r15+0x318], 0x00
00007c454bbd196d  jz 0x00007C454BBD0F20
00007c454bbd1973  nop [rax+rax*1], ax
00007c454bbd197c  nop [rax+rax*1], eax
00007c454bbd1984  mov eax, 0x4109A4
00007c454bbd1989  mov [r15+0x100], rax
00007c454bbd1990  jmp 0x00007C454B9FE110
00007c454bbd1995  int3
00007c454bbd1996  int3
00007c454bbd1997  nop [rax+rax*1], ax
00007c454bbd19a0  vmovaps xmm1, [0x00007C454B7FE010]
00007c454bbd19a8  movq xmm1, xmm1
00007c454bbd19ac  movaps [r15+0x110], xmm1
00007c454bbd19b4  mov eax, 0x420B10
00007c454bbd19b9  mov r14, [r13+rax*1]
00007c454bbd19be  movq xmm1, r14
00007c454bbd19c3  movaps [r15+0x120], xmm1
00007c454bbd19cb  vmovaps xmm1, [0x00007C454B7FE020]
00007c454bbd19d3  movq xmm1, xmm1
00007c454bbd19d7  movaps [r15+0x140], xmm1
00007c454bbd19df  vmovaps xmm1, [0x00007C454B7FE030]
00007c454bbd19e7  vpbroadcastq xmm1, xmm1
00007c454bbd19ec  movaps [r15+0x150], xmm1
00007c454bbd19f4  mov qword ptr [r15+0x40], 0x02
00007c454bbd19fc  vmovaps xmm15, [0x00007C454B7FE040]
00007c454bbd1a04  movq xmm15, xmm15
00007c454bbd1a09  movaps [r15+0x160], xmm15
00007c454bbd1a11  vmovaps xmm15, [0x00007C454B7FE050]
00007c454bbd1a19  vpbroadcastq xmm15, xmm15
00007c454bbd1a1e  movaps [r15+0x130], xmm15
00007c454bbd1a26  mov rax, [r15+0x40]
00007c454bbd1a2a  vmovq xmm14, rax
00007c454bbd1a2f  vpbroadcastq xmm14, xmm14
00007c454bbd1a34  movaps [r15+0x170], xmm14
00007c454bbd1a3c  mov eax, 0x420A40
00007c454bbd1a41  movups xmm13, [r13+rax*1]
00007c454bbd1a47  mov qword ptr [r15+0x40], 0x431E00
00007c454bbd1a4f  mov eax, [r15]
00007c454bbd1a52  mov r14d, 0x430CB8
00007c454bbd1a58  mov [r13+r14*1], eax
00007c454bbd1a5d  mov qword ptr [r15+0x50], 0x432000
00007c454bbd1a65  vpmovqd xmm12, xmm13
00007c454bbd1a6b  pxor xmm11, xmm11
00007c454bbd1a70  punpcklqdq xmm12, xmm11
00007c454bbd1a75  movaps [r15+0x210], xmm12
00007c454bbd1a7d  movq xmm12, qword ptr [r15+0x140]
00007c454bbd1a86  movq xmm11, qword ptr [r15+0x120]
00007c454bbd1a8f  psubd xmm12, xmm11
00007c454bbd1a94  movq xmm12, xmm12
00007c454bbd1a99  paddq xmm13, xmm14
00007c454bbd1a9e  movaps [r15+0x180], xmm13
00007c454bbd1aa6  movq xmm14, qword ptr [r15+0x160]
00007c454bbd1aaf  paddd xmm11, xmm14
00007c454bbd1ab4  movq xmm11, xmm11
00007c454bbd1ab9  movq xmm11, xmm11
00007c454bbd1abe  movaps [r15+0x120], xmm11
00007c454bbd1ac6  pmovzxdq xmm12, xmm12
00007c454bbd1acc  psllq xmm12, 0x00
00007c454bbd1ad2  movq xmm14, qword ptr [r15+0x210]
00007c454bbd1adb  movq xmm13, qword ptr [r15+0x110]
00007c454bbd1ae4  paddd xmm14, xmm13
00007c454bbd1ae9  movq xmm14, xmm14
00007c454bbd1aee  vcvtuqq2pd xmm12, xmm12
00007c454bbd1af4  pmovzxdq xmm14, xmm14
00007c454bbd1afa  psllq xmm14, 0x00
00007c454bbd1b00  vcvtuqq2pd xmm14, xmm14
00007c454bbd1b06  movaps xmm13, xmm12
00007c454bbd1b0a  mulpd xmm13, xmm1
00007c454bbd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007c454bbd1b15  ptest xmm11, xmm11
00007c454bbd1b1b  jnz 0x00007C454BBD1C0F
00007c454bbd1b21  movaps [r15+0x220], xmm13
00007c454bbd1b29  mov eax, 0x432000
00007c454bbd1b2e  movups [r13+rax*1], xmm13
00007c454bbd1b34  movaps xmm1, xmm14
00007c454bbd1b38  mulpd xmm1, xmm15
00007c454bbd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007c454bbd1b42  ptest xmm13, xmm13
00007c454bbd1b48  jnz 0x00007C454BBD1D5C
00007c454bbd1b4e  movaps [r15+0x210], xmm1
00007c454bbd1b56  mov eax, 0x431E00
00007c454bbd1b5b  movups [r13+rax*1], xmm1
00007c454bbd1b61  mov qword ptr [r15+0x48], 0x10
00007c454bbd1b69  xor eax, eax
00007c454bbd1b6b  mov r14d, 0x10
00007c454bbd1b71  mov r12d, 0x200
00007c454bbd1b77  cmp r14, r12
00007c454bbd1b7a  cmc
00007c454bbd1b7b  lahf
00007c454bbd1b7c  seto al
00007c454bbd1b7f  mov [r15+0x108], eax
00007c454bbd1b86  mov eax, [r15+0x108]
00007c454bbd1b8d  sahf
00007c454bbd1b8e  jnz 0x00007C454BBD1BC0
00007c454bbd1b90  cmp dword ptr [r15+0x318], 0x00
00007c454bbd1b98  jz 0x00007C454BBD2300
00007c454bbd1b9e  nop [rax+rax*1], ax
00007c454bbd1ba7  nop [rax+rax*1], eax
00007c454bbd1baf  mov eax, 0x410490
00007c454bbd1bb4  mov [r15+0x100], rax
00007c454bbd1bbb  jmp 0x00007C454B9FE110
00007c454bbd1bc0  cmp dword ptr [r15+0x318], 0x00
00007c454bbd1bc8  jz 0x00007C454BBD1EB0
00007c454bbd1bce  nop [rax+rax*1], ax
00007c454bbd1bd7  nop [rax+rax*1], eax
00007c454bbd1bdf  mov eax, 0x410450
00007c454bbd1be4  mov [r15+0x100], rax
00007c454bbd1beb  jmp 0x00007C454B9FE110
00007c454bbd1bf0  int3
00007c454bbd1bf1  call 0x00007C454BA0DC20
00007c454bbd1bf6  jmp 0x00007C454BBD19BE
00007c454bbd1bfb  call 0x00007C454BA0C260
00007c454bbd1c00  jmp 0x00007C454BBD1A47
00007c454bbd1c05  call 0x00007C454BAD5D70
00007c454bbd1c0a  jmp 0x00007C454BBD1A5D
00007c454bbd1c0f  sub rsp, 0x08
00007c454bbd1c13  push rax
00007c454bbd1c14  push rcx
00007c454bbd1c15  push rdx
00007c454bbd1c16  push rdi
00007c454bbd1c17  push rsi
00007c454bbd1c18  push r8
00007c454bbd1c1a  push r9
00007c454bbd1c1c  push r10
00007c454bbd1c1e  push r11
00007c454bbd1c20  sub rsp, 0xF0
00007c454bbd1c27  vmovaps [rsp], xmm0
00007c454bbd1c2c  vmovaps [rsp+0x10], xmm1
00007c454bbd1c32  vmovaps [rsp+0x20], xmm2
00007c454bbd1c38  vmovaps [rsp+0x30], xmm3
00007c454bbd1c3e  vmovaps [rsp+0x40], xmm4
00007c454bbd1c44  vmovaps [rsp+0x50], xmm5
00007c454bbd1c4a  vmovaps [rsp+0x60], xmm6
00007c454bbd1c50  vmovaps [rsp+0x70], xmm7
00007c454bbd1c56  vmovaps [rsp+0x80], xmm8
00007c454bbd1c5f  vmovaps [rsp+0x90], xmm9
00007c454bbd1c68  vmovaps [rsp+0xA0], xmm10
00007c454bbd1c71  vmovaps [rsp+0xB0], xmm11
00007c454bbd1c7a  vmovaps [rsp+0xC0], xmm12
00007c454bbd1c83  vmovaps [rsp+0xD0], xmm14
00007c454bbd1c8c  vmovaps [rsp+0xE0], xmm15
00007c454bbd1c95  sub rsp, 0x30
00007c454bbd1c99  movaps [rsp], xmm13
00007c454bbd1c9e  movaps [rsp+0x10], xmm12
00007c454bbd1ca4  movaps [rsp+0x20], xmm1
00007c454bbd1ca9  lea rdi, [rsp]
00007c454bbd1cad  mov esi, 0x00
00007c454bbd1cb2  mov rax, 0x56A18AC54530
00007c454bbd1cbc  call rax
00007c454bbd1cbe  movaps xmm13, [rsp]
00007c454bbd1cc3  add rsp, 0x30
00007c454bbd1cc7  vmovaps xmm0, [rsp]
00007c454bbd1ccc  vmovaps xmm1, [rsp+0x10]
00007c454bbd1cd2  vmovaps xmm2, [rsp+0x20]
00007c454bbd1cd8  vmovaps xmm3, [rsp+0x30]
00007c454bbd1cde  vmovaps xmm4, [rsp+0x40]
00007c454bbd1ce4  vmovaps xmm5, [rsp+0x50]
00007c454bbd1cea  vmovaps xmm6, [rsp+0x60]
00007c454bbd1cf0  vmovaps xmm7, [rsp+0x70]
00007c454bbd1cf6  vmovaps xmm8, [rsp+0x80]
00007c454bbd1cff  vmovaps xmm9, [rsp+0x90]
00007c454bbd1d08  vmovaps xmm10, [rsp+0xA0]
00007c454bbd1d11  vmovaps xmm11, [rsp+0xB0]
00007c454bbd1d1a  vmovaps xmm12, [rsp+0xC0]
00007c454bbd1d23  vmovaps xmm14, [rsp+0xD0]
00007c454bbd1d2c  vmovaps xmm15, [rsp+0xE0]
00007c454bbd1d35  add rsp, 0xF0
00007c454bbd1d3c  pop r11
00007c454bbd1d3e  pop r10
00007c454bbd1d40  pop r9
00007c454bbd1d42  pop r8
00007c454bbd1d44  pop rsi
00007c454bbd1d45  pop rdi
00007c454bbd1d46  pop rdx
00007c454bbd1d47  pop rcx
00007c454bbd1d48  pop rax
00007c454bbd1d49  add rsp, 0x08
00007c454bbd1d4d  jmp 0x00007C454BBD1B21
00007c454bbd1d52  call 0x00007C454BA0C380
00007c454bbd1d57  jmp 0x00007C454BBD1B34
00007c454bbd1d5c  sub rsp, 0x08
00007c454bbd1d60  push rax
00007c454bbd1d61  push rcx
00007c454bbd1d62  push rdx
00007c454bbd1d63  push rdi
00007c454bbd1d64  push rsi
00007c454bbd1d65  push r8
00007c454bbd1d67  push r9
00007c454bbd1d69  push r10
00007c454bbd1d6b  push r11
00007c454bbd1d6d  sub rsp, 0xF0
00007c454bbd1d74  vmovaps [rsp], xmm0
00007c454bbd1d79  vmovaps [rsp+0x10], xmm2
00007c454bbd1d7f  vmovaps [rsp+0x20], xmm3
00007c454bbd1d85  vmovaps [rsp+0x30], xmm4
00007c454bbd1d8b  vmovaps [rsp+0x40], xmm5
00007c454bbd1d91  vmovaps [rsp+0x50], xmm6
00007c454bbd1d97  vmovaps [rsp+0x60], xmm7
00007c454bbd1d9d  vmovaps [rsp+0x70], xmm8
00007c454bbd1da3  vmovaps [rsp+0x80], xmm9
00007c454bbd1dac  vmovaps [rsp+0x90], xmm10
00007c454bbd1db5  vmovaps [rsp+0xA0], xmm11
00007c454bbd1dbe  vmovaps [rsp+0xB0], xmm12
00007c454bbd1dc7  vmovaps [rsp+0xC0], xmm13
00007c454bbd1dd0  vmovaps [rsp+0xD0], xmm14
00007c454bbd1dd9  vmovaps [rsp+0xE0], xmm15
00007c454bbd1de2  sub rsp, 0x30
00007c454bbd1de6  movaps [rsp], xmm1
00007c454bbd1dea  movaps [rsp+0x10], xmm14
00007c454bbd1df0  movaps [rsp+0x20], xmm15
00007c454bbd1df6  lea rdi, [rsp]
00007c454bbd1dfa  mov esi, 0x00
00007c454bbd1dff  mov rax, 0x56A18AC54530
00007c454bbd1e09  call rax
00007c454bbd1e0b  movaps xmm1, [rsp]
00007c454bbd1e0f  add rsp, 0x30
00007c454bbd1e13  vmovaps xmm0, [rsp]
00007c454bbd1e18  vmovaps xmm2, [rsp+0x10]
00007c454bbd1e1e  vmovaps xmm3, [rsp+0x20]
00007c454bbd1e24  vmovaps xmm4, [rsp+0x30]
00007c454bbd1e2a  vmovaps xmm5, [rsp+0x40]
00007c454bbd1e30  vmovaps xmm6, [rsp+0x50]
00007c454bbd1e36  vmovaps xmm7, [rsp+0x60]
00007c454bbd1e3c  vmovaps xmm8, [rsp+0x70]
00007c454bbd1e42  vmovaps xmm9, [rsp+0x80]
00007c454bbd1e4b  vmovaps xmm10, [rsp+0x90]
00007c454bbd1e54  vmovaps xmm11, [rsp+0xA0]
00007c454bbd1e5d  vmovaps xmm12, [rsp+0xB0]
00007c454bbd1e66  vmovaps xmm13, [rsp+0xC0]
00007c454bbd1e6f  vmovaps xmm14, [rsp+0xD0]
00007c454bbd1e78  vmovaps xmm15, [rsp+0xE0]
00007c454bbd1e81  add rsp, 0xF0
00007c454bbd1e88  pop r11
00007c454bbd1e8a  pop r10
00007c454bbd1e8c  pop r9
00007c454bbd1e8e  pop r8
00007c454bbd1e90  pop rsi
00007c454bbd1e91  pop rdi
00007c454bbd1e92  pop rdx
00007c454bbd1e93  pop rcx
00007c454bbd1e94  pop rax
00007c454bbd1e95  add rsp, 0x08
00007c454bbd1e99  jmp 0x00007C454BBD1B4E
00007c454bbd1e9e  call 0x00007C454B9FF540
00007c454bbd1ea3  jmp 0x00007C454BBD1B61
00007c454bbd1ea8  int3
00007c454bbd1ea9  nop [rax], eax
00007c454bbd1eb0  movaps xmm1, [r15+0x180]
00007c454bbd1eb8  vpmovqd xmm15, xmm1
00007c454bbd1ebe  pxor xmm14, xmm14
00007c454bbd1ec3  punpcklqdq xmm15, xmm14
00007c454bbd1ec8  movaps [r15+0x210], xmm15
00007c454bbd1ed0  movq xmm15, qword ptr [r15+0x140]
00007c454bbd1ed9  movq xmm14, qword ptr [r15+0x120]
00007c454bbd1ee2  psubd xmm15, xmm14
00007c454bbd1ee7  movq xmm15, xmm15
00007c454bbd1eec  movaps xmm13, [r15+0x170]
00007c454bbd1ef4  paddq xmm1, xmm13
00007c454bbd1ef9  movaps [r15+0x180], xmm1
00007c454bbd1f01  movq xmm1, qword ptr [r15+0x160]
00007c454bbd1f0a  paddd xmm14, xmm1
00007c454bbd1f0f  movq xmm14, xmm14
00007c454bbd1f14  movq xmm14, xmm14
00007c454bbd1f19  movaps [r15+0x120], xmm14
00007c454bbd1f21  pmovzxdq xmm15, xmm15
00007c454bbd1f27  psllq xmm15, 0x00
00007c454bbd1f2d  movq xmm1, qword ptr [r15+0x210]
00007c454bbd1f36  movq xmm14, qword ptr [r15+0x110]
00007c454bbd1f3f  paddd xmm1, xmm14
00007c454bbd1f44  movq xmm1, xmm1
00007c454bbd1f48  vcvtuqq2pd xmm15, xmm15
00007c454bbd1f4e  pmovzxdq xmm1, xmm1
00007c454bbd1f53  psllq xmm1, 0x00
00007c454bbd1f58  vcvtuqq2pd xmm1, xmm1
00007c454bbd1f5e  movaps xmm14, [r15+0x150]
00007c454bbd1f66  movaps xmm13, xmm15
00007c454bbd1f6a  mulpd xmm13, xmm14
00007c454bbd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007c454bbd1f75  ptest xmm12, xmm12
00007c454bbd1f7b  jnz 0x00007C454BBD205E
00007c454bbd1f81  movaps [r15+0x220], xmm13
00007c454bbd1f89  mov rax, [r15+0x48]
00007c454bbd1f8d  mov r14, [r15+0x50]
00007c454bbd1f91  lea r12, [r14+rax*1]
00007c454bbd1f95  movups [r13+r12*1], xmm13
00007c454bbd1f9b  movaps xmm15, [r15+0x130]
00007c454bbd1fa3  movaps xmm14, xmm1
00007c454bbd1fa7  mulpd xmm14, xmm15
00007c454bbd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007c454bbd1fb2  ptest xmm13, xmm13
00007c454bbd1fb8  jnz 0x00007C454BBD21AC
00007c454bbd1fbe  movaps [r15+0x210], xmm14
00007c454bbd1fc6  mov r14, [r15+0x40]
00007c454bbd1fca  lea r12, [r14+rax*1]
00007c454bbd1fce  movups [r13+r12*1], xmm14
00007c454bbd1fd4  lea r14, [rax+0x10]
00007c454bbd1fd8  mov [r15+0x48], r14
00007c454bbd1fdc  xor eax, eax
00007c454bbd1fde  mov r12d, 0x200
00007c454bbd1fe4  cmp r14, r12
00007c454bbd1fe7  cmc
00007c454bbd1fe8  lahf
00007c454bbd1fe9  seto al
00007c454bbd1fec  mov [r15+0x108], eax
00007c454bbd1ff3  mov eax, [r15+0x108]
00007c454bbd1ffa  sahf
00007c454bbd1ffb  jnz 0x00007C454BBD202D
00007c454bbd1ffd  cmp dword ptr [r15+0x318], 0x00
00007c454bbd2005  jz 0x00007C454BBD2300
00007c454bbd200b  nop [rax+rax*1], ax
00007c454bbd2014  nop [rax+rax*1], eax
00007c454bbd201c  mov eax, 0x410490
00007c454bbd2021  mov [r15+0x100], rax
00007c454bbd2028  jmp 0x00007C454B9FE110
00007c454bbd202d  cmp dword ptr [r15+0x318], 0x00
00007c454bbd2035  jz 0x00007C454BBD1EB0
00007c454bbd203b  nop [rax+rax*1], ax
00007c454bbd2044  nop [rax+rax*1], eax
00007c454bbd204c  mov eax, 0x410450
00007c454bbd2051  mov [r15+0x100], rax
00007c454bbd2058  jmp 0x00007C454B9FE110
00007c454bbd205d  int3
00007c454bbd205e  sub rsp, 0x08
00007c454bbd2062  push rax
00007c454bbd2063  push rcx
00007c454bbd2064  push rdx
00007c454bbd2065  push rdi
00007c454bbd2066  push rsi
00007c454bbd2067  push r8
00007c454bbd2069  push r9
00007c454bbd206b  push r10
00007c454bbd206d  push r11
00007c454bbd206f  sub rsp, 0xF0
00007c454bbd2076  vmovaps [rsp], xmm0
00007c454bbd207b  vmovaps [rsp+0x10], xmm1
00007c454bbd2081  vmovaps [rsp+0x20], xmm2
00007c454bbd2087  vmovaps [rsp+0x30], xmm3
00007c454bbd208d  vmovaps [rsp+0x40], xmm4
00007c454bbd2093  vmovaps [rsp+0x50], xmm5
00007c454bbd2099  vmovaps [rsp+0x60], xmm6
00007c454bbd209f  vmovaps [rsp+0x70], xmm7
00007c454bbd20a5  vmovaps [rsp+0x80], xmm8
00007c454bbd20ae  vmovaps [rsp+0x90], xmm9
00007c454bbd20b7  vmovaps [rsp+0xA0], xmm10
00007c454bbd20c0  vmovaps [rsp+0xB0], xmm11
00007c454bbd20c9  vmovaps [rsp+0xC0], xmm12
00007c454bbd20d2  vmovaps [rsp+0xD0], xmm14
00007c454bbd20db  vmovaps [rsp+0xE0], xmm15
00007c454bbd20e4  sub rsp, 0x30
00007c454bbd20e8  movaps [rsp], xmm13
00007c454bbd20ed  movaps [rsp+0x10], xmm15
00007c454bbd20f3  movaps [rsp+0x20], xmm14
00007c454bbd20f9  lea rdi, [rsp]
00007c454bbd20fd  mov esi, 0x00
00007c454bbd2102  mov rax, 0x56A18AC54530
00007c454bbd210c  call rax
00007c454bbd210e  movaps xmm13, [rsp]
00007c454bbd2113  add rsp, 0x30
00007c454bbd2117  vmovaps xmm0, [rsp]
00007c454bbd211c  vmovaps xmm1, [rsp+0x10]
00007c454bbd2122  vmovaps xmm2, [rsp+0x20]
00007c454bbd2128  vmovaps xmm3, [rsp+0x30]
00007c454bbd212e  vmovaps xmm4, [rsp+0x40]
00007c454bbd2134  vmovaps xmm5, [rsp+0x50]
00007c454bbd213a  vmovaps xmm6, [rsp+0x60]
00007c454bbd2140  vmovaps xmm7, [rsp+0x70]
00007c454bbd2146  vmovaps xmm8, [rsp+0x80]
00007c454bbd214f  vmovaps xmm9, [rsp+0x90]
00007c454bbd2158  vmovaps xmm10, [rsp+0xA0]
00007c454bbd2161  vmovaps xmm11, [rsp+0xB0]
00007c454bbd216a  vmovaps xmm12, [rsp+0xC0]
00007c454bbd2173  vmovaps xmm14, [rsp+0xD0]
00007c454bbd217c  vmovaps xmm15, [rsp+0xE0]
00007c454bbd2185  add rsp, 0xF0
00007c454bbd218c  pop r11
00007c454bbd218e  pop r10
00007c454bbd2190  pop r9
00007c454bbd2192  pop r8
00007c454bbd2194  pop rsi
00007c454bbd2195  pop rdi
00007c454bbd2196  pop rdx
00007c454bbd2197  pop rcx
00007c454bbd2198  pop rax
00007c454bbd2199  add rsp, 0x08
00007c454bbd219d  jmp 0x00007C454BBD1F81
00007c454bbd21a2  call 0x00007C454BAC2240
00007c454bbd21a7  jmp 0x00007C454BBD1F9B
00007c454bbd21ac  sub rsp, 0x08
00007c454bbd21b0  push rax
00007c454bbd21b1  push rcx
00007c454bbd21b2  push rdx
00007c454bbd21b3  push rdi
00007c454bbd21b4  push rsi
00007c454bbd21b5  push r8
00007c454bbd21b7  push r9
00007c454bbd21b9  push r10
00007c454bbd21bb  push r11
00007c454bbd21bd  sub rsp, 0xF0
00007c454bbd21c4  vmovaps [rsp], xmm0
00007c454bbd21c9  vmovaps [rsp+0x10], xmm1
00007c454bbd21cf  vmovaps [rsp+0x20], xmm2
00007c454bbd21d5  vmovaps [rsp+0x30], xmm3
00007c454bbd21db  vmovaps [rsp+0x40], xmm4
00007c454bbd21e1  vmovaps [rsp+0x50], xmm5
00007c454bbd21e7  vmovaps [rsp+0x60], xmm6
00007c454bbd21ed  vmovaps [rsp+0x70], xmm7
00007c454bbd21f3  vmovaps [rsp+0x80], xmm8
00007c454bbd21fc  vmovaps [rsp+0x90], xmm9
00007c454bbd2205  vmovaps [rsp+0xA0], xmm10
00007c454bbd220e  vmovaps [rsp+0xB0], xmm11
00007c454bbd2217  vmovaps [rsp+0xC0], xmm12
00007c454bbd2220  vmovaps [rsp+0xD0], xmm13
00007c454bbd2229  vmovaps [rsp+0xE0], xmm15
00007c454bbd2232  sub rsp, 0x30
00007c454bbd2236  movaps [rsp], xmm14
00007c454bbd223b  movaps [rsp+0x10], xmm1
00007c454bbd2240  movaps [rsp+0x20], xmm15
00007c454bbd2246  lea rdi, [rsp]
00007c454bbd224a  mov esi, 0x00
00007c454bbd224f  mov rax, 0x56A18AC54530
00007c454bbd2259  call rax
00007c454bbd225b  movaps xmm14, [rsp]
00007c454bbd2260  add rsp, 0x30
00007c454bbd2264  vmovaps xmm0, [rsp]
00007c454bbd2269  vmovaps xmm1, [rsp+0x10]
00007c454bbd226f  vmovaps xmm2, [rsp+0x20]
00007c454bbd2275  vmovaps xmm3, [rsp+0x30]
00007c454bbd227b  vmovaps xmm4, [rsp+0x40]
00007c454bbd2281  vmovaps xmm5, [rsp+0x50]
00007c454bbd2287  vmovaps xmm6, [rsp+0x60]
00007c454bbd228d  vmovaps xmm7, [rsp+0x70]
00007c454bbd2293  vmovaps xmm8, [rsp+0x80]
00007c454bbd229c  vmovaps xmm9, [rsp+0x90]
00007c454bbd22a5  vmovaps xmm10, [rsp+0xA0]
00007c454bbd22ae  vmovaps xmm11, [rsp+0xB0]
00007c454bbd22b7  vmovaps xmm12, [rsp+0xC0]
00007c454bbd22c0  vmovaps xmm13, [rsp+0xD0]
00007c454bbd22c9  vmovaps xmm15, [rsp+0xE0]
00007c454bbd22d2  add rsp, 0xF0
00007c454bbd22d9  pop r11
00007c454bbd22db  pop r10
00007c454bbd22dd  pop r9
00007c454bbd22df  pop r8
00007c454bbd22e1  pop rsi
00007c454bbd22e2  pop rdi
00007c454bbd22e3  pop rdx
00007c454bbd22e4  pop rcx
00007c454bbd22e5  pop rax
00007c454bbd22e6  add rsp, 0x08
00007c454bbd22ea  jmp 0x00007C454BBD1FBE
00007c454bbd22ef  call 0x00007C454BAC34C0
00007c454bbd22f4  jmp 0x00007C454BBD1FD4
00007c454bbd22f9  int3
00007c454bbd22fa  nop [rax+rax*1], ax
00007c454bbd2300  mov rax, [r15+0x50]
00007c454bbd2304  lea r14, [rax+0x80]
00007c454bbd230b  movups xmm1, [r13+r14*1]
00007c454bbd2311  lea r14, [rax+0x90]
00007c454bbd2318  movups xmm15, [r13+r14*1]
00007c454bbd231e  vxorps xmm14, xmm14, xmm14
00007c454bbd2323  vpbroadcastq xmm14, xmm14
00007c454bbd2328  lea r14, [rax+0x40]
00007c454bbd232c  movups xmm13, [r13+r14*1]
00007c454bbd2332  lea r14, [rax+0x50]
00007c454bbd2336  movups xmm12, [r13+r14*1]
00007c454bbd233c  mov qword ptr [r15+0x48], 0x00
00007c454bbd2344  movups xmm11, [r13+rax*1]
00007c454bbd234a  lea r14, [rax+0x10]
00007c454bbd234e  movups xmm10, [r13+r14*1]
00007c454bbd2354  mov r14, [r15+0xF8]
00007c454bbd235b  lea r12, [r14+0xE0]
00007c454bbd2362  movups [r13+r12*1], xmm15
00007c454bbd2368  lea r12, [r14+0xF0]
00007c454bbd236f  movups [r13+r12*1], xmm1
00007c454bbd2375  lea r12, [rax+0xC0]
00007c454bbd237c  movups xmm1, [r13+r12*1]
00007c454bbd2382  lea r12, [rax+0xD0]
00007c454bbd2389  movups xmm15, [r13+r12*1]
00007c454bbd238f  lea r12, [rax+0x140]
00007c454bbd2396  movups xmm9, [r13+r12*1]
00007c454bbd239c  lea r12, [rax+0x150]
00007c454bbd23a3  movups xmm8, [r13+r12*1]
00007c454bbd23a9  lea r12, [rax+0x180]
00007c454bbd23b0  movups xmm7, [r13+r12*1]
00007c454bbd23b6  lea r12, [rax+0x190]
00007c454bbd23bd  movups xmm6, [r13+r12*1]
00007c454bbd23c3  lea r12, [r14+0xC0]
00007c454bbd23ca  movups [r13+r12*1], xmm15
00007c454bbd23d0  lea r12, [r14+0xD0]
00007c454bbd23d7  movups [r13+r12*1], xmm1
00007c454bbd23dd  lea r12, [rax+0x100]
00007c454bbd23e4  movups xmm1, [r13+r12*1]
00007c454bbd23ea  lea r12, [rax+0x110]
00007c454bbd23f1  movups xmm15, [r13+r12*1]
00007c454bbd23f7  lea r12, [rax+0x1C0]
00007c454bbd23fe  movups xmm5, [r13+r12*1]
00007c454bbd2404  lea r12, [rax+0x1D0]
00007c454bbd240b  movups xmm4, [r13+r12*1]
00007c454bbd2411  lea r12, [rax+0x20]
00007c454bbd2415  movups xmm3, [r13+r12*1]
00007c454bbd241b  lea r12, [rax+0x30]
00007c454bbd241f  movups xmm2, [r13+r12*1]
00007c454bbd2425  movaps [r15+0x1F0], xmm2
00007c454bbd242d  lea r12, [r14+0x20]
00007c454bbd2431  movups [r13+r12*1], xmm1
00007c454bbd2437  lea r12, [r14+0x30]
00007c454bbd243b  movups [r13+r12*1], xmm12
00007c454bbd2441  lea r12, [rax+0x60]
00007c454bbd2445  movups xmm1, [r13+r12*1]
00007c454bbd244b  lea r12, [rax+0x70]
00007c454bbd244f  movups xmm12, [r13+r12*1]
00007c454bbd2455  lea r12, [r14+0x60]
00007c454bbd2459  movups [r13+r12*1], xmm11
00007c454bbd245f  lea r12, [r14+0x70]
00007c454bbd2463  movups [r13+r12*1], xmm5
00007c454bbd2469  lea r12, [rax+0xE0]
00007c454bbd2470  movups xmm11, [r13+r12*1]
00007c454bbd2476  lea r12, [rax+0xF0]
00007c454bbd247d  movups xmm5, [r13+r12*1]
00007c454bbd2483  lea r12, [rax+0x120]
00007c454bbd248a  vmovaps [rsp+0x10], xmm1
00007c454bbd2490  movups xmm1, [r13+r12*1]
00007c454bbd2496  lea r12, [rax+0x130]
00007c454bbd249d  vmovaps [rsp+0x20], xmm1
00007c454bbd24a3  movups xmm1, [r13+r12*1]
00007c454bbd24a9  lea r12, [r14+0xA0]
00007c454bbd24b0  movups [r13+r12*1], xmm12
00007c454bbd24b6  lea r12, [r14+0xB0]
00007c454bbd24bd  vmovaps xmm12, [rsp+0x10]
00007c454bbd24c3  movups [r13+r12*1], xmm12
00007c454bbd24c9  lea r12, [rax+0xA0]
00007c454bbd24d0  movups xmm12, [r13+r12*1]
00007c454bbd24d6  lea r12, [rax+0xB0]
00007c454bbd24dd  vmovaps [rsp+0x10], xmm1
00007c454bbd24e3  movups xmm1, [r13+r12*1]
00007c454bbd24e9  lea r12, [rax+0x160]
00007c454bbd24f0  vmovaps [rsp+0x30], xmm1
00007c454bbd24f6  movups xmm1, [r13+r12*1]
00007c454bbd24fc  lea r12, [rax+0x170]
00007c454bbd2503  vmovaps [rsp+0x40], xmm1
00007c454bbd2509  movups xmm1, [r13+r12*1]
00007c454bbd250f  movaps [r15+0x2B0], xmm1
00007c454bbd2517  lea r12, [rax+0x1A0]
00007c454bbd251e  vmovaps [rsp+0x50], xmm1
00007c454bbd2524  movups xmm1, [r13+r12*1]
00007c454bbd252a  lea r12, [rax+0x1B0]
00007c454bbd2531  vmovaps [rsp+0x60], xmm1
00007c454bbd2537  movups xmm1, [r13+r12*1]
00007c454bbd253d  vmovaps [rsp+0x70], xmm1
00007c454bbd2543  vmovaps xmm1, [rsp+0x60]
00007c454bbd2549  movaps [r15+0x290], xmm1
00007c454bbd2551  vmovaps [rsp+0x60], xmm1
00007c454bbd2557  vmovaps xmm1, [rsp+0x70]
00007c454bbd255d  movaps [r15+0x1E0], xmm1
00007c454bbd2565  lea r12, [r14+0x80]
00007c454bbd256c  vmovaps [rsp+0x70], xmm1
00007c454bbd2572  vmovaps xmm1, [rsp+0x30]
00007c454bbd2578  movups [r13+r12*1], xmm1
00007c454bbd257e  lea r12, [r14+0x90]
00007c454bbd2585  movups [r13+r12*1], xmm12
00007c454bbd258b  lea r12, [rax+0x1E0]
00007c454bbd2592  movups xmm1, [r13+r12*1]
00007c454bbd2598  lea r12, [rax+0x1F0]
00007c454bbd259f  movups xmm12, [r13+r12*1]
00007c454bbd25a5  mov qword ptr [r15+0x50], 0x432200
00007c454bbd25ad  lea rax, [r14+0x40]
00007c454bbd25b1  vmovaps [rsp+0x30], xmm1
00007c454bbd25b7  vmovaps xmm1, [rsp+0x40]
00007c454bbd25bd  movups [r13+rax*1], xmm1
00007c454bbd25c3  lea rax, [r14+0x50]
00007c454bbd25c7  movups [r13+rax*1], xmm10
00007c454bbd25cd  movups [r13+r14*1], xmm12
00007c454bbd25d3  lea rax, [r14+0x10]
00007c454bbd25d7  vmovaps xmm1, [rsp+0x30]
00007c454bbd25dd  movups [r13+rax*1], xmm1
00007c454bbd25e3  mov rax, [r15+0x40]
00007c454bbd25e7  vmovaps [rsp+0x30], xmm3
00007c454bbd25ed  vmovaps xmm1, [rsp+0x30]
00007c454bbd25f3  por xmm3, xmm1
00007c454bbd25f7  vmovaps [rsp+0x30], xmm6
00007c454bbd25fd  vmovaps xmm12, [rsp+0x30]
00007c454bbd2603  por xmm6, xmm12
00007c454bbd2608  lea r12, [rax+0x30]
00007c454bbd260c  mov r11, [r13+r12*1]
00007c454bbd2611  lea r12, [rax+0x38]
00007c454bbd2615  mov r10, [r13+r12*1]
00007c454bbd261a  movq xmm12, r11
00007c454bbd261f  movq xmm10, r10
00007c454bbd2624  movq xmm12, xmm12
00007c454bbd2629  vmovaps [rsp+0x30], xmm12
00007c454bbd262f  movq xmm12, xmm12
00007c454bbd2634  movaps [r15+0x130], xmm12
00007c454bbd263c  movq xmm10, xmm10
00007c454bbd2641  vmovaps [rsp+0x40], xmm10
00007c454bbd2647  movq xmm10, xmm10
00007c454bbd264c  movaps [r15+0x280], xmm10
00007c454bbd2654  vmovaps [rsp+0x80], xmm9
00007c454bbd265d  vmovaps xmm12, [rsp+0x80]
00007c454bbd2666  por xmm9, xmm12
00007c454bbd266b  lea r12, [rax+0x20]
00007c454bbd266f  mov r11, [r13+r12*1]
00007c454bbd2674  lea r12, [rax+0x28]
00007c454bbd2678  mov r10, [r13+r12*1]
00007c454bbd267d  movq xmm12, r11
00007c454bbd2682  movq xmm10, r10
00007c454bbd2687  movq xmm12, xmm12
00007c454bbd268c  vmovaps [rsp+0x80], xmm12
00007c454bbd2695  movq xmm12, xmm12
00007c454bbd269a  movaps [r15+0x150], xmm12
00007c454bbd26a2  movq xmm10, xmm10
00007c454bbd26a7  vmovaps [rsp+0x90], xmm10
00007c454bbd26b0  movq xmm10, xmm10
00007c454bbd26b5  movaps [r15+0x140], xmm10
00007c454bbd26bd  lea r12, [rax+0x10]
00007c454bbd26c1  mov r11, [r13+r12*1]
00007c454bbd26c6  lea r12, [rax+0x18]
00007c454bbd26ca  mov r10, [r13+r12*1]
00007c454bbd26cf  movq xmm12, r11
00007c454bbd26d4  movq xmm10, r10
00007c454bbd26d9  movq xmm12, xmm12
00007c454bbd26de  vmovaps [rsp+0xA0], xmm12
00007c454bbd26e7  movq xmm12, xmm12
00007c454bbd26ec  movaps [r15+0x170], xmm12
00007c454bbd26f4  movq xmm10, xmm10
00007c454bbd26f9  vmovaps [rsp+0xB0], xmm10
00007c454bbd2702  movq xmm10, xmm10
00007c454bbd2707  movaps [r15+0x160], xmm10
00007c454bbd270f  mov r12, [r13+rax*1]
00007c454bbd2714  vmovq xmm12, r12
00007c454bbd2719  vpbroadcastq xmm12, xmm12
00007c454bbd271e  lea r12, [rax+0x08]
00007c454bbd2722  mov rax, [r13+r12*1]
00007c454bbd2727  movq xmm10, rax
00007c454bbd272c  movaps [r15+0x230], xmm10
00007c454bbd2734  lea rax, [r14+0x50]
00007c454bbd2738  movups xmm10, [r13+rax*1]
00007c454bbd273e  lea rax, [r14+0x60]
00007c454bbd2742  vmovaps [rsp+0xC0], xmm1
00007c454bbd274b  movups xmm1, [r13+rax*1]
00007c454bbd2751  lea rax, [r14+0x30]
00007c454bbd2755  vmovaps [rsp+0xD0], xmm1
00007c454bbd275e  movups xmm1, [r13+rax*1]
00007c454bbd2764  mov qword ptr [r15+0x60], 0x432200
00007c454bbd276c  mov qword ptr [r15+0x58], 0x40
00007c454bbd2774  vmovaps [rsp+0xE0], xmm1
00007c454bbd277d  vmovaps [rsp+0xF0], xmm15
00007c454bbd2786  vmovaps xmm15, [rsp+0xC0]
00007c454bbd278f  vmovaps [rsp+0xC0], xmm14
00007c454bbd2798  movaps xmm1, xmm12
00007c454bbd279c  mulpd xmm1, xmm15
00007c454bbd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007c454bbd27a6  ptest xmm14, xmm14
00007c454bbd27ac  jnz 0x00007C454BBD3863
00007c454bbd27b2  movq xmm15, qword ptr [r15+0x230]
00007c454bbd27bb  vmovaps [rsp+0x100], xmm15
00007c454bbd27c4  vpermilpd xmm15, xmm15, 0x00
00007c454bbd27ca  vmovaps [rsp+0x110], xmm1
00007c454bbd27d3  vmovaps xmm1, [rsp+0xE0]
00007c454bbd27dc  vmovaps [rsp+0xE0], xmm13
00007c454bbd27e5  movaps xmm14, xmm1
00007c454bbd27e9  mulpd xmm14, xmm15
00007c454bbd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007c454bbd27f4  ptest xmm13, xmm13
00007c454bbd27fa  jnz 0x00007C454BBD39A5
00007c454bbd2800  vxorps xmm1, xmm1, xmm1
00007c454bbd2804  vpbroadcastq xmm1, xmm1
00007c454bbd2809  vmovaps xmm13, [rsp+0xD0]
00007c454bbd2812  vmovaps [rsp+0xD0], xmm1
00007c454bbd281b  movaps xmm15, xmm12
00007c454bbd281f  mulpd xmm15, xmm13
00007c454bbd2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007c454bbd282a  ptest xmm1, xmm1
00007c454bbd282f  jnz 0x00007C454BBD3AE8
00007c454bbd2835  movaps xmm1, xmm12
00007c454bbd2839  mulpd xmm1, xmm10
00007c454bbd283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007c454bbd2843  ptest xmm13, xmm13
00007c454bbd2849  jnz 0x00007C454BBD3C2C
00007c454bbd284f  movaps xmm13, xmm12
00007c454bbd2853  mulpd xmm13, xmm2
00007c454bbd2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007c454bbd285e  ptest xmm10, xmm10
00007c454bbd2864  jnz 0x00007C454BBD3D6E
00007c454bbd286a  vmovaps [rsp+0x120], xmm7
00007c454bbd2873  vmovaps xmm12, [rsp+0x120]
00007c454bbd287c  por xmm7, xmm12
00007c454bbd2881  vmovaps xmm12, [rsp+0xE0]
00007c454bbd288a  vmovaps xmm10, [rsp+0xE0]
00007c454bbd2893  por xmm12, xmm10
00007c454bbd2898  vmovaps xmm2, [rsp+0x100]
00007c454bbd28a1  vpermilpd xmm2, xmm2, 0x00
00007c454bbd28a7  vmovaps [rsp+0xE0], xmm1
00007c454bbd28b0  vmovaps [rsp+0x120], xmm15
00007c454bbd28b9  movaps xmm1, xmm10
00007c454bbd28bd  mulpd xmm1, xmm2
00007c454bbd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007c454bbd28c6  ptest xmm15, xmm15
00007c454bbd28cc  jnz 0x00007C454BBD3EB1
00007c454bbd28d2  xor eax, eax
00007c454bbd28d4  mov r12d, 0x40
00007c454bbd28da  mov r11d, 0x200
00007c454bbd28e0  cmp r12, r11
00007c454bbd28e3  cmc
00007c454bbd28e4  lahf
00007c454bbd28e5  seto al
00007c454bbd28e8  mov [r15+0x108], eax
00007c454bbd28ef  vmovaps xmm10, [rsp+0x110]
00007c454bbd28f8  vmovaps xmm2, [rsp+0xD0]
00007c454bbd2901  vmovaps [rsp+0xD0], xmm1
00007c454bbd290a  movaps xmm15, xmm10
00007c454bbd290e  addpd xmm15, xmm2
00007c454bbd2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007c454bbd2919  ptest xmm1, xmm1
00007c454bbd291e  jnz 0x00007C454BBD3FF2
00007c454bbd2924  vmovaps xmm10, [rsp+0x120]
00007c454bbd292d  vmovaps [rsp+0x110], xmm15
00007c454bbd2936  vmovaps xmm15, [rsp+0xC0]
00007c454bbd293f  vmovaps [rsp+0xC0], xmm14
00007c454bbd2948  movaps xmm1, xmm10
00007c454bbd294c  addpd xmm1, xmm15
00007c454bbd2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007c454bbd2956  ptest xmm14, xmm14
00007c454bbd295c  jnz 0x00007C454BBD4135
00007c454bbd2962  vmovaps xmm10, [rsp+0xE0]
00007c454bbd296b  vmovaps [rsp+0xE0], xmm1
00007c454bbd2974  movaps xmm14, xmm10
00007c454bbd2978  addpd xmm14, xmm15
00007c454bbd297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007c454bbd2983  ptest xmm1, xmm1
00007c454bbd2988  jnz 0x00007C454BBD4277
00007c454bbd298e  vmovaps xmm1, [rsp+0x10]
00007c454bbd2994  vmovaps xmm15, [rsp+0x10]
00007c454bbd299a  por xmm1, xmm15
00007c454bbd299f  vmovaps xmm15, [rsp+0x20]
00007c454bbd29a5  vmovaps xmm10, [rsp+0x20]
00007c454bbd29ab  por xmm15, xmm10
00007c454bbd29b0  vmovaps [rsp+0x10], xmm5
00007c454bbd29b6  vmovaps xmm10, [rsp+0x10]
00007c454bbd29bc  por xmm5, xmm10
00007c454bbd29c1  vmovaps [rsp+0x10], xmm11
00007c454bbd29c7  vmovaps xmm10, [rsp+0x10]
00007c454bbd29cd  por xmm11, xmm10
00007c454bbd29d2  vmovaps [rsp+0x10], xmm4
00007c454bbd29d8  vmovaps xmm10, [rsp+0x10]
00007c454bbd29de  por xmm4, xmm10
00007c454bbd29e3  vmovaps [rsp+0x10], xmm8
00007c454bbd29e9  vmovaps xmm10, [rsp+0x10]
00007c454bbd29ef  por xmm8, xmm10
00007c454bbd29f4  vmovaps xmm10, [rsp+0xF0]
00007c454bbd29fd  vmovaps [rsp+0x10], xmm1
00007c454bbd2a03  vmovaps xmm1, [rsp+0xF0]
00007c454bbd2a0c  por xmm10, xmm1
00007c454bbd2a11  lea rax, [r14+0xA0]
00007c454bbd2a18  movups xmm1, [r13+rax*1]
00007c454bbd2a1e  lea rax, [r14+0xB0]
00007c454bbd2a25  vmovaps [rsp+0x20], xmm1
00007c454bbd2a2b  movups xmm1, [r13+rax*1]
00007c454bbd2a31  vmovaps [rsp+0xF0], xmm1
00007c454bbd2a3a  vmovaps [rsp+0x120], xmm15
00007c454bbd2a43  movaps xmm1, xmm13
00007c454bbd2a47  addpd xmm1, xmm2
00007c454bbd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007c454bbd2a50  ptest xmm15, xmm15
00007c454bbd2a56  jnz 0x00007C454BBD43CF
00007c454bbd2a5c  lea rax, [r14+0xF0]
00007c454bbd2a63  movups xmm15, [r13+rax*1]
00007c454bbd2a69  vmovaps xmm2, [rsp+0xE0]
00007c454bbd2a72  vmovaps [rsp+0xE0], xmm1
00007c454bbd2a7b  vmovaps xmm1, [rsp+0xD0]
00007c454bbd2a84  vmovaps [rsp+0xD0], xmm15
00007c454bbd2a8d  movaps xmm13, xmm2
00007c454bbd2a91  addpd xmm13, xmm1
00007c454bbd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007c454bbd2a9c  ptest xmm15, xmm15
00007c454bbd2aa2  jnz 0x00007C454BBD451A
00007c454bbd2aa8  vmovaps xmm15, [rsp+0xC0]
00007c454bbd2ab1  movaps xmm1, xmm14
00007c454bbd2ab5  addpd xmm1, xmm15
00007c454bbd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007c454bbd2abf  ptest xmm2, xmm2
00007c454bbd2ac4  jnz 0x00007C454BBD465C
00007c454bbd2aca  vmovaps xmm15, [rsp+0x100]
00007c454bbd2ad3  vpermilpd xmm15, xmm15, 0x00
00007c454bbd2ad9  vmovaps xmm2, [rsp+0xF0]
00007c454bbd2ae2  vmovaps [rsp+0xC0], xmm1
00007c454bbd2aeb  movaps xmm14, xmm2
00007c454bbd2aef  mulpd xmm14, xmm15
00007c454bbd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007c454bbd2afa  ptest xmm1, xmm1
00007c454bbd2aff  jnz 0x00007C454BBD479E
00007c454bbd2b05  vmovaps xmm1, [rsp+0xA0]
00007c454bbd2b0e  vpermilpd xmm1, xmm1, 0x00
00007c454bbd2b14  vmovaps xmm2, [rsp+0xD0]
00007c454bbd2b1d  vmovaps [rsp+0xD0], xmm14
00007c454bbd2b26  movaps xmm15, xmm2
00007c454bbd2b2a  mulpd xmm15, xmm1
00007c454bbd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007c454bbd2b35  ptest xmm14, xmm14
00007c454bbd2b3b  jnz 0x00007C454BBD48E1
00007c454bbd2b41  lea rax, [r14+0xE0]
00007c454bbd2b48  movups xmm1, [r13+rax*1]
00007c454bbd2b4e  vmovaps xmm14, [rsp+0x100]
00007c454bbd2b57  vpermilpd xmm14, xmm14, 0x00
00007c454bbd2b5d  vmovaps [rsp+0xF0], xmm1
00007c454bbd2b66  vmovaps xmm1, [rsp+0x20]
00007c454bbd2b6c  vmovaps [rsp+0x20], xmm15
00007c454bbd2b72  movaps xmm2, xmm1
00007c454bbd2b75  mulpd xmm2, xmm14
00007c454bbd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007c454bbd2b7f  ptest xmm15, xmm15
00007c454bbd2b85  jnz 0x00007C454BBD4A2D
00007c454bbd2b8b  vmovaps [rsp+0x100], xmm10
00007c454bbd2b94  vmovaps xmm1, [rsp+0x100]
00007c454bbd2b9d  por xmm10, xmm1
00007c454bbd2ba2  movaps [r15+0x300], xmm10
00007c454bbd2baa  vmovaps [rsp+0x100], xmm8
00007c454bbd2bb3  vmovaps xmm1, [rsp+0x100]
00007c454bbd2bbc  por xmm8, xmm1
00007c454bbd2bc1  movaps [r15+0x190], xmm8
00007c454bbd2bc9  vmovaps xmm1, [rsp+0xA0]
00007c454bbd2bd2  vpermilpd xmm1, xmm1, 0x00
00007c454bbd2bd8  vmovaps xmm14, [rsp+0xF0]
00007c454bbd2be1  vmovaps [rsp+0xF0], xmm13
00007c454bbd2bea  movaps xmm15, xmm14
00007c454bbd2bee  mulpd xmm15, xmm1
00007c454bbd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007c454bbd2bf9  ptest xmm13, xmm13
00007c454bbd2bff  jnz 0x00007C454BBD4B6E
00007c454bbd2c05  lea rax, [r14+0x90]
00007c454bbd2c0c  movups xmm1, [r13+rax*1]
00007c454bbd2c12  vmovaps [rsp+0x100], xmm4
00007c454bbd2c1b  vmovaps xmm14, [rsp+0x100]
00007c454bbd2c24  por xmm4, xmm14
00007c454bbd2c29  movaps [r15+0x1C0], xmm4
00007c454bbd2c31  vmovaps [rsp+0x100], xmm11
00007c454bbd2c3a  vmovaps xmm14, [rsp+0x100]
00007c454bbd2c43  por xmm11, xmm14
00007c454bbd2c48  movaps [r15+0x200], xmm11
00007c454bbd2c50  vmovaps [rsp+0x100], xmm5
00007c454bbd2c59  vmovaps xmm14, [rsp+0x100]
00007c454bbd2c62  por xmm5, xmm14
00007c454bbd2c67  movaps [r15+0x2D0], xmm5
00007c454bbd2c6f  vmovaps xmm14, [rsp+0x120]
00007c454bbd2c78  vmovaps xmm13, [rsp+0x120]
00007c454bbd2c81  por xmm14, xmm13
00007c454bbd2c86  movaps [r15+0x2E0], xmm14
00007c454bbd2c8e  vmovaps [rsp+0x100], xmm1
00007c454bbd2c97  vmovaps xmm1, [rsp+0x110]
00007c454bbd2ca0  vmovaps [rsp+0x110], xmm15
00007c454bbd2ca9  vmovaps xmm15, [rsp+0xD0]
00007c454bbd2cb2  vmovaps [rsp+0xD0], xmm14
00007c454bbd2cbb  movaps xmm13, xmm1
00007c454bbd2cbf  addpd xmm13, xmm15
00007c454bbd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007c454bbd2cca  ptest xmm14, xmm14
00007c454bbd2cd0  jnz 0x00007C454BBD4CBB
00007c454bbd2cd6  vmovaps xmm1, [rsp+0xA0]
00007c454bbd2cdf  vpermilpd xmm1, xmm1, 0x00
00007c454bbd2ce5  vmovaps xmm14, [rsp+0x100]
00007c454bbd2cee  vmovaps [rsp+0x100], xmm13
00007c454bbd2cf7  movaps xmm15, xmm14
00007c454bbd2cfb  mulpd xmm15, xmm1
00007c454bbd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007c454bbd2d06  ptest xmm13, xmm13
00007c454bbd2d0c  jnz 0x00007C454BBD4DFE
00007c454bbd2d12  lea rax, [r14+0x80]
00007c454bbd2d19  movups xmm1, [r13+rax*1]
00007c454bbd2d1f  vmovaps xmm13, [rsp+0xE0]
00007c454bbd2d28  vmovaps [rsp+0xE0], xmm1
00007c454bbd2d31  movaps xmm14, xmm13
00007c454bbd2d35  addpd xmm14, xmm2
00007c454bbd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007c454bbd2d40  ptest xmm1, xmm1
00007c454bbd2d45  jnz 0x00007C454BBD4F4B
00007c454bbd2d4b  vmovaps xmm13, [rsp+0xF0]
00007c454bbd2d54  vmovaps xmm2, [rsp+0x20]
00007c454bbd2d5a  vmovaps [rsp+0x20], xmm15
00007c454bbd2d60  movaps xmm1, xmm13
00007c454bbd2d64  addpd xmm1, xmm2
00007c454bbd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007c454bbd2d6d  ptest xmm15, xmm15
00007c454bbd2d73  jnz 0x00007C454BBD508E
00007c454bbd2d79  vmovaps xmm15, [rsp+0x10]
00007c454bbd2d7f  vmovaps xmm13, [rsp+0x10]
00007c454bbd2d85  por xmm15, xmm13
00007c454bbd2d8a  movaps [r15+0x2F0], xmm15
00007c454bbd2d92  vmovaps xmm13, [rsp+0xA0]
00007c454bbd2d9b  vpermilpd xmm13, xmm13, 0x00
00007c454bbd2da1  vmovaps [rsp+0x10], xmm1
00007c454bbd2da7  vmovaps xmm1, [rsp+0xE0]
00007c454bbd2db0  vmovaps [rsp+0xA0], xmm15
00007c454bbd2db9  movaps xmm2, xmm1
00007c454bbd2dbc  mulpd xmm2, xmm13
00007c454bbd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007c454bbd2dc6  ptest xmm15, xmm15
00007c454bbd2dcc  jnz 0x00007C454BBD51CF
00007c454bbd2dd2  lea rax, [r14+0xD0]
00007c454bbd2dd9  movups xmm1, [r13+rax*1]
00007c454bbd2ddf  vmovaps xmm13, [rsp+0xC0]
00007c454bbd2de8  vmovaps [rsp+0xC0], xmm1
00007c454bbd2df1  vmovaps xmm1, [rsp+0x110]
00007c454bbd2dfa  vmovaps [rsp+0xE0], xmm14
00007c454bbd2e03  movaps xmm15, xmm13
00007c454bbd2e07  addpd xmm15, xmm1
00007c454bbd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007c454bbd2e12  ptest xmm14, xmm14
00007c454bbd2e18  jnz 0x00007C454BBD531A
00007c454bbd2e1e  vmovaps xmm1, [rsp+0xB0]
00007c454bbd2e27  vpermilpd xmm1, xmm1, 0x00
00007c454bbd2e2d  movaps xmm14, xmm11
00007c454bbd2e31  mulpd xmm14, xmm1
00007c454bbd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007c454bbd2e3c  ptest xmm13, xmm13
00007c454bbd2e42  jnz 0x00007C454BBD545D
00007c454bbd2e48  movaps [r15+0x260], xmm14
00007c454bbd2e50  vxorps xmm1, xmm1, xmm1
00007c454bbd2e54  vpbroadcastq xmm1, xmm1
00007c454bbd2e59  movaps [r15+0x1B0], xmm1
00007c454bbd2e61  vmovaps xmm1, [rsp+0xB0]
00007c454bbd2e6a  vpermilpd xmm1, xmm1, 0x00
00007c454bbd2e70  vmovaps xmm11, [rsp+0xC0]
00007c454bbd2e79  vmovaps [rsp+0xC0], xmm15
00007c454bbd2e82  movaps xmm13, xmm11
00007c454bbd2e86  mulpd xmm13, xmm1
00007c454bbd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007c454bbd2e91  ptest xmm15, xmm15
00007c454bbd2e97  jnz 0x00007C454BBD55A0
00007c454bbd2e9d  lea rax, [r14+0xC0]
00007c454bbd2ea4  movups xmm1, [r13+rax*1]
00007c454bbd2eaa  vmovaps xmm11, [rsp+0x100]
00007c454bbd2eb3  vmovaps [rsp+0xF0], xmm1
00007c454bbd2ebc  vmovaps xmm1, [rsp+0x20]
00007c454bbd2ec2  vmovaps [rsp+0x20], xmm14
00007c454bbd2ec8  movaps xmm15, xmm11
00007c454bbd2ecc  addpd xmm15, xmm1
00007c454bbd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007c454bbd2ed7  ptest xmm14, xmm14
00007c454bbd2edd  jnz 0x00007C454BBD56ED
00007c454bbd2ee3  vmovaps [rsp+0x100], xmm9
00007c454bbd2eec  vmovaps xmm1, [rsp+0x100]
00007c454bbd2ef5  por xmm9, xmm1
00007c454bbd2efa  movaps [r15+0x270], xmm9
00007c454bbd2f02  vmovaps [rsp+0x100], xmm6
00007c454bbd2f0b  vmovaps xmm1, [rsp+0x100]
00007c454bbd2f14  por xmm6, xmm1
00007c454bbd2f18  movaps [r15+0x1A0], xmm6
00007c454bbd2f20  vmovaps xmm14, [rsp+0xB0]
00007c454bbd2f29  vpermilpd xmm14, xmm14, 0x00
00007c454bbd2f2f  vmovaps xmm6, [rsp+0xF0]
00007c454bbd2f38  vmovaps [rsp+0xF0], xmm1
00007c454bbd2f41  movaps xmm11, xmm6
00007c454bbd2f45  mulpd xmm11, xmm14
00007c454bbd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007c454bbd2f50  ptest xmm1, xmm1
00007c454bbd2f55  jnz 0x00007C454BBD5830
00007c454bbd2f5b  lea rax, [r14+0x20]
00007c454bbd2f5f  movups xmm1, [r13+rax*1]
00007c454bbd2f65  movaps [r15+0x110], xmm1
00007c454bbd2f6d  vmovaps xmm6, [rsp+0xE0]
00007c454bbd2f76  vmovaps [rsp+0xE0], xmm1
00007c454bbd2f7f  movaps xmm14, xmm6
00007c454bbd2f83  addpd xmm14, xmm2
00007c454bbd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007c454bbd2f8e  ptest xmm1, xmm1
00007c454bbd2f93  jnz 0x00007C454BBD597D
00007c454bbd2f99  vmovaps xmm1, [rsp+0xB0]
00007c454bbd2fa2  vpermilpd xmm1, xmm1, 0x00
00007c454bbd2fa8  movaps xmm6, xmm5
00007c454bbd2fab  mulpd xmm6, xmm1
00007c454bbd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007c454bbd2fb4  ptest xmm2, xmm2
00007c454bbd2fb9  jnz 0x00007C454BBD5ABF
00007c454bbd2fbf  vmovaps xmm5, [rsp+0x10]
00007c454bbd2fc5  movaps xmm1, xmm5
00007c454bbd2fc8  addpd xmm1, xmm13
00007c454bbd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007c454bbd2fd2  ptest xmm2, xmm2
00007c454bbd2fd7  jnz 0x00007C454BBD5BFF
00007c454bbd2fdd  vmovaps xmm13, [rsp+0x80]
00007c454bbd2fe6  vpermilpd xmm13, xmm13, 0x00
00007c454bbd2fec  vmovaps xmm2, [rsp+0xE0]
00007c454bbd2ff5  vmovaps [rsp+0x10], xmm1
00007c454bbd2ffb  movaps xmm5, xmm2
00007c454bbd2ffe  mulpd xmm5, xmm13
00007c454bbd3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007c454bbd3008  ptest xmm1, xmm1
00007c454bbd300d  jnz 0x00007C454BBD5D40
00007c454bbd3013  vmovaps xmm1, [rsp+0x80]
00007c454bbd301c  vpermilpd xmm1, xmm1, 0x00
00007c454bbd3022  movaps xmm13, xmm10
00007c454bbd3026  mulpd xmm13, xmm1
00007c454bbd302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007c454bbd3031  ptest xmm2, xmm2
00007c454bbd3036  jnz 0x00007C454BBD5E81
00007c454bbd303c  vmovaps xmm10, [rsp+0x20]
00007c454bbd3042  movaps xmm1, xmm15
00007c454bbd3046  addpd xmm1, xmm10
00007c454bbd304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007c454bbd3050  ptest xmm2, xmm2
00007c454bbd3055  jnz 0x00007C454BBD5FC4
00007c454bbd305b  vmovaps xmm10, [rsp+0xC0]
00007c454bbd3064  movaps xmm15, xmm10
00007c454bbd3068  addpd xmm15, xmm11
00007c454bbd306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007c454bbd3073  ptest xmm2, xmm2
00007c454bbd3078  jnz 0x00007C454BBD6106
00007c454bbd307e  vmovaps xmm11, [rsp+0x80]
00007c454bbd3087  vpermilpd xmm11, xmm11, 0x00
00007c454bbd308d  vmovaps xmm2, [rsp+0xD0]
00007c454bbd3096  vmovaps [rsp+0x20], xmm1
00007c454bbd309c  movaps xmm10, xmm2
00007c454bbd30a0  mulpd xmm10, xmm11
00007c454bbd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007c454bbd30ab  ptest xmm1, xmm1
00007c454bbd30b0  jnz 0x00007C454BBD624A
00007c454bbd30b6  vmovaps xmm1, [rsp+0x80]
00007c454bbd30bf  vpermilpd xmm1, xmm1, 0x00
00007c454bbd30c5  vmovaps xmm2, [rsp+0xA0]
00007c454bbd30ce  vmovaps [rsp+0x80], xmm15
00007c454bbd30d7  movaps xmm11, xmm2
00007c454bbd30db  mulpd xmm11, xmm1
00007c454bbd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007c454bbd30e6  ptest xmm15, xmm15
00007c454bbd30ec  jnz 0x00007C454BBD638D
00007c454bbd30f2  movaps xmm1, xmm14
00007c454bbd30f6  addpd xmm1, xmm6
00007c454bbd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007c454bbd30ff  ptest xmm15, xmm15
00007c454bbd3105  jnz 0x00007C454BBD64CF
00007c454bbd310b  vmovaps xmm14, [rsp+0x10]
00007c454bbd3111  movaps xmm15, xmm14
00007c454bbd3115  addpd xmm15, xmm5
00007c454bbd311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007c454bbd3120  ptest xmm6, xmm6
00007c454bbd3125  jnz 0x00007C454BBD6610
00007c454bbd312b  vmovaps xmm14, [rsp+0x90]
00007c454bbd3134  vpermilpd xmm14, xmm14, 0x00
00007c454bbd313a  movaps xmm6, xmm9
00007c454bbd313e  mulpd xmm6, xmm14
00007c454bbd3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007c454bbd3148  ptest xmm5, xmm5
00007c454bbd314d  jnz 0x00007C454BBD6753
00007c454bbd3153  vmovaps xmm9, [rsp+0x80]
00007c454bbd315c  movaps xmm14, xmm9
00007c454bbd3160  addpd xmm14, xmm13
00007c454bbd3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007c454bbd316b  ptest xmm5, xmm5
00007c454bbd3170  jnz 0x00007C454BBD6895
00007c454bbd3176  vmovaps xmm9, [rsp+0x20]
00007c454bbd317c  movaps xmm13, xmm9
00007c454bbd3180  addpd xmm13, xmm10
00007c454bbd3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007c454bbd318b  ptest xmm5, xmm5
00007c454bbd3190  jnz 0x00007C454BBD69D9
00007c454bbd3196  vmovaps [rsp+0x10], xmm12
00007c454bbd319c  vmovaps xmm10, [rsp+0x10]
00007c454bbd31a2  por xmm12, xmm10
00007c454bbd31a7  movaps [r15+0x250], xmm12
00007c454bbd31af  vmovaps [rsp+0x10], xmm7
00007c454bbd31b5  vmovaps xmm12, [rsp+0x10]
00007c454bbd31bb  por xmm7, xmm12
00007c454bbd31c0  movaps [r15+0x2A0], xmm7
00007c454bbd31c8  vmovaps [rsp+0x10], xmm3
00007c454bbd31ce  vmovaps xmm12, [rsp+0x10]
00007c454bbd31d4  por xmm3, xmm12
00007c454bbd31d9  movaps [r15+0x1D0], xmm3
00007c454bbd31e1  lea rax, [r14+0x40]
00007c454bbd31e5  movups xmm12, [r13+rax*1]
00007c454bbd31eb  movaps [r15+0x2C0], xmm12
00007c454bbd31f3  vmovaps xmm10, [rsp+0x90]
00007c454bbd31fc  vpermilpd xmm10, xmm10, 0x00
00007c454bbd3202  movaps xmm9, xmm8
00007c454bbd3206  mulpd xmm9, xmm10
00007c454bbd320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007c454bbd3211  ptest xmm5, xmm5
00007c454bbd3216  jnz 0x00007C454BBD6B27
00007c454bbd321c  movaps xmm10, xmm1
00007c454bbd3220  addpd xmm10, xmm11
00007c454bbd3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007c454bbd322b  ptest xmm8, xmm8
00007c454bbd3231  jnz 0x00007C454BBD6C6B
00007c454bbd3237  movaps xmm1, xmm15
00007c454bbd323b  addpd xmm1, xmm6
00007c454bbd323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007c454bbd3244  ptest xmm11, xmm11
00007c454bbd324a  jnz 0x00007C454BBD6DAE
00007c454bbd3250  vmovaps xmm15, [rsp+0x90]
00007c454bbd3259  vpermilpd xmm15, xmm15, 0x00
00007c454bbd325f  movaps xmm11, xmm12
00007c454bbd3263  mulpd xmm11, xmm15
00007c454bbd3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007c454bbd326e  ptest xmm8, xmm8
00007c454bbd3274  jnz 0x00007C454BBD6EEF
00007c454bbd327a  vmovaps xmm15, [rsp+0x90]
00007c454bbd3283  vpermilpd xmm15, xmm15, 0x00
00007c454bbd3289  vmovaps xmm8, [rsp+0x50]
00007c454bbd328f  movaps xmm12, xmm8
00007c454bbd3293  mulpd xmm12, xmm15
00007c454bbd3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007c454bbd329e  ptest xmm6, xmm6
00007c454bbd32a3  jnz 0x00007C454BBD7033
00007c454bbd32a9  vmovaps xmm15, [rsp+0x30]
00007c454bbd32af  vpermilpd xmm15, xmm15, 0x00
00007c454bbd32b5  movaps xmm8, xmm7
00007c454bbd32b9  mulpd xmm8, xmm15
00007c454bbd32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007c454bbd32c4  ptest xmm6, xmm6
00007c454bbd32c9  jnz 0x00007C454BBD7177
00007c454bbd32cf  movaps xmm15, xmm14
00007c454bbd32d3  addpd xmm15, xmm9
00007c454bbd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007c454bbd32de  ptest xmm7, xmm7
00007c454bbd32e3  jnz 0x00007C454BBD72BA
00007c454bbd32e9  vmovaps xmm14, [rsp+0x30]
00007c454bbd32ef  vpermilpd xmm14, xmm14, 0x00
00007c454bbd32f5  vmovaps xmm7, [rsp+0xF0]
00007c454bbd32fe  movaps xmm9, xmm7
00007c454bbd3302  mulpd xmm9, xmm14
00007c454bbd3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007c454bbd330d  ptest xmm6, xmm6
00007c454bbd3312  jnz 0x00007C454BBD73FE
00007c454bbd3318  movaps xmm14, xmm13
00007c454bbd331c  addpd xmm14, xmm11
00007c454bbd3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007c454bbd3327  ptest xmm7, xmm7
00007c454bbd332c  jnz 0x00007C454BBD7541
00007c454bbd3332  vmovaps xmm13, [rsp+0x30]
00007c454bbd3338  vpermilpd xmm13, xmm13, 0x00
00007c454bbd333e  vmovaps xmm7, [rsp+0x60]
00007c454bbd3344  movaps xmm11, xmm7
00007c454bbd3348  mulpd xmm11, xmm13
00007c454bbd334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007c454bbd3353  ptest xmm6, xmm6
00007c454bbd3358  jnz 0x00007C454BBD7685
00007c454bbd335e  movaps xmm13, xmm10
00007c454bbd3362  addpd xmm13, xmm12
00007c454bbd3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007c454bbd336d  ptest xmm7, xmm7
00007c454bbd3372  jnz 0x00007C454BBD77C8
00007c454bbd3378  vmovaps xmm12, [rsp+0x30]
00007c454bbd337e  vpermilpd xmm12, xmm12, 0x00
00007c454bbd3384  vmovaps xmm7, [rsp+0x70]
00007c454bbd338a  movaps xmm10, xmm7
00007c454bbd338e  mulpd xmm10, xmm12
00007c454bbd3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007c454bbd3399  ptest xmm6, xmm6
00007c454bbd339e  jnz 0x00007C454BBD790C
00007c454bbd33a4  movaps xmm12, xmm1
00007c454bbd33a8  addpd xmm12, xmm8
00007c454bbd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007c454bbd33b3  ptest xmm7, xmm7
00007c454bbd33b8  jnz 0x00007C454BBD7A4F
00007c454bbd33be  lea rax, [r14+0x70]
00007c454bbd33c2  movups xmm1, [r13+rax*1]
00007c454bbd33c8  movaps [r15+0x240], xmm1
00007c454bbd33d0  movaps xmm8, xmm15
00007c454bbd33d4  addpd xmm8, xmm9
00007c454bbd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007c454bbd33df  ptest xmm7, xmm7
00007c454bbd33e4  jnz 0x00007C454BBD7B9C
00007c454bbd33ea  movaps [r15+0x170], xmm8
00007c454bbd33f2  vmovaps xmm15, [rsp+0x40]
00007c454bbd33f8  vpermilpd xmm15, xmm15, 0x00
00007c454bbd33fe  movaps xmm9, xmm1
00007c454bbd3402  mulpd xmm9, xmm15
00007c454bbd3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007c454bbd340d  ptest xmm7, xmm7
00007c454bbd3412  jnz 0x00007C454BBD7CE0
00007c454bbd3418  vmovaps xmm1, [rsp+0x40]
00007c454bbd341e  vpermilpd xmm1, xmm1, 0x00
00007c454bbd3424  movaps xmm15, xmm4
00007c454bbd3428  mulpd xmm15, xmm1
00007c454bbd342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007c454bbd3433  ptest xmm7, xmm7
00007c454bbd3438  jnz 0x00007C454BBD7E23
00007c454bbd343e  movaps [r15+0x180], xmm15
00007c454bbd3446  movaps xmm1, xmm14
00007c454bbd344a  addpd xmm1, xmm11
00007c454bbd344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007c454bbd3454  ptest xmm7, xmm7
00007c454bbd3459  jnz 0x00007C454BBD7F65
00007c454bbd345f  movaps [r15+0x210], xmm1
00007c454bbd3467  movups xmm14, [r13+r14*1]
00007c454bbd346d  lea rax, [r14+0x10]
00007c454bbd3471  movups xmm11, [r13+rax*1]
00007c454bbd3477  movaps [r15+0x230], xmm11
00007c454bbd347f  movaps xmm7, xmm13
00007c454bbd3483  addpd xmm7, xmm10
00007c454bbd3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007c454bbd348d  ptest xmm6, xmm6
00007c454bbd3492  jnz 0x00007C454BBD80BB
00007c454bbd3498  movaps [r15+0x130], xmm7
00007c454bbd34a0  vmovaps xmm13, [rsp+0x40]
00007c454bbd34a6  vpermilpd xmm13, xmm13, 0x00
00007c454bbd34ac  movaps xmm10, xmm11
00007c454bbd34b0  mulpd xmm10, xmm13
00007c454bbd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007c454bbd34bb  ptest xmm6, xmm6
00007c454bbd34c0  jnz 0x00007C454BBD81FD
00007c454bbd34c6  movaps [r15+0x220], xmm10
00007c454bbd34ce  vmovaps xmm13, [rsp+0x40]
00007c454bbd34d4  vpermilpd xmm13, xmm13, 0x00
00007c454bbd34da  movaps xmm11, xmm14
00007c454bbd34de  mulpd xmm11, xmm13
00007c454bbd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007c454bbd34e9  ptest xmm6, xmm6
00007c454bbd34ee  jnz 0x00007C454BBD8341
00007c454bbd34f4  movaps xmm14, xmm12
00007c454bbd34f8  addpd xmm14, xmm9
00007c454bbd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007c454bbd3503  ptest xmm13, xmm13
00007c454bbd3509  jnz 0x00007C454BBD8485
00007c454bbd350f  movaps [r15+0x140], xmm14
00007c454bbd3517  movaps xmm13, xmm8
00007c454bbd351b  addpd xmm13, xmm15
00007c454bbd3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007c454bbd3526  ptest xmm12, xmm12
00007c454bbd352c  jnz 0x00007C454BBD85C9
00007c454bbd3532  movaps [r15+0x150], xmm13
00007c454bbd353a  movaps xmm15, xmm1
00007c454bbd353e  addpd xmm15, xmm10
00007c454bbd3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007c454bbd3549  ptest xmm12, xmm12
00007c454bbd354f  jnz 0x00007C454BBD870D
00007c454bbd3555  movaps [r15+0x160], xmm15
00007c454bbd355d  movaps xmm1, xmm7
00007c454bbd3560  addpd xmm1, xmm11
00007c454bbd3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007c454bbd356a  ptest xmm12, xmm12
00007c454bbd3570  jnz 0x00007C454BBD8850
00007c454bbd3576  movaps [r15+0x120], xmm1
00007c454bbd357e  mov eax, 0x432200
00007c454bbd3583  movups [r13+rax*1], xmm14
00007c454bbd3589  mov eax, 0x432210
00007c454bbd358e  movups [r13+rax*1], xmm13
00007c454bbd3594  mov eax, 0x432220
00007c454bbd3599  movups [r13+rax*1], xmm15
00007c454bbd359f  mov eax, 0x432230
00007c454bbd35a4  movups [r13+rax*1], xmm1
00007c454bbd35aa  mov eax, [r15+0x108]
00007c454bbd35b1  sahf
00007c454bbd35b2  jnz 0x00007C454BBD35E4
00007c454bbd35b4  cmp dword ptr [r15+0x318], 0x00
00007c454bbd35bc  jz 0x00007C454BBDEAE0
00007c454bbd35c2  nop [rax+rax*1], ax
00007c454bbd35cb  nop [rax+rax*1], eax
00007c454bbd35d3  mov eax, 0x4106D0
00007c454bbd35d8  mov [r15+0x100], rax
00007c454bbd35df  jmp 0x00007C454B9FE110
00007c454bbd35e4  cmp dword ptr [r15+0x318], 0x00
00007c454bbd35ec  jz 0x00007C454BBD89C0
00007c454bbd35f2  nop [rax+rax*1], ax
00007c454bbd35fb  nop [rax+rax*1], eax
00007c454bbd3603  mov eax, 0x410504
00007c454bbd3608  mov [r15+0x100], rax
00007c454bbd360f  jmp 0x00007C454B9FE110
00007c454bbd3614  int3
00007c454bbd3615  call 0x00007C454BAD64F0
00007c454bbd361a  jmp 0x00007C454BBD2311
00007c454bbd361f  call 0x00007C454BAE5820
00007c454bbd3624  jmp 0x00007C454BBD231E
00007c454bbd3629  call 0x00007C454BAE3320
00007c454bbd362e  jmp 0x00007C454BBD2332
00007c454bbd3633  call 0x00007C454BAE20A0
00007c454bbd3638  jmp 0x00007C454BBD233C
00007c454bbd363d  call 0x00007C454BA09D70
00007c454bbd3642  jmp 0x00007C454BBD234A
00007c454bbd3647  call 0x00007C454BADFBC0
00007c454bbd364c  jmp 0x00007C454BBD2354
00007c454bbd3651  call 0x00007C454BAC4740
00007c454bbd3656  jmp 0x00007C454BBD2368
00007c454bbd365b  call 0x00007C454BAB5400
00007c454bbd3660  jmp 0x00007C454BBD2375
00007c454bbd3665  call 0x00007C454BAB52F0
00007c454bbd366a  jmp 0x00007C454BBD2382
00007c454bbd366f  call 0x00007C454BAC4620
00007c454bbd3674  jmp 0x00007C454BBD238F
00007c454bbd3679  call 0x00007C454BABD750
00007c454bbd367e  jmp 0x00007C454BBD239C
00007c454bbd3683  call 0x00007C454BABC4E0
00007c454bbd3688  jmp 0x00007C454BBD23A9
00007c454bbd368d  call 0x00007C454BABB270
00007c454bbd3692  jmp 0x00007C454BBD23B6
00007c454bbd3697  call 0x00007C454BABA000
00007c454bbd369c  jmp 0x00007C454BBD23C3
00007c454bbd36a1  call 0x00007C454BAC4740
00007c454bbd36a6  jmp 0x00007C454BBD23D0
00007c454bbd36ab  call 0x00007C454BAB5400
00007c454bbd36b0  jmp 0x00007C454BBD23DD
00007c454bbd36b5  call 0x00007C454BAB52F0
00007c454bbd36ba  jmp 0x00007C454BBD23EA
00007c454bbd36bf  call 0x00007C454BAC4620
00007c454bbd36c4  jmp 0x00007C454BBD23F7
00007c454bbd36c9  call 0x00007C454BAB8D90
00007c454bbd36ce  jmp 0x00007C454BBD2404
00007c454bbd36d3  call 0x00007C454BAB8A20
00007c454bbd36d8  jmp 0x00007C454BBD2411
00007c454bbd36dd  call 0x00007C454BAB77B0
00007c454bbd36e2  jmp 0x00007C454BBD241B
00007c454bbd36e7  call 0x00007C454BAB6550
00007c454bbd36ec  jmp 0x00007C454BBD2425
00007c454bbd36f1  call 0x00007C454BAB5400
00007c454bbd36f6  jmp 0x00007C454BBD2437
00007c454bbd36fb  call 0x00007C454BAC0FC0
00007c454bbd3700  jmp 0x00007C454BBD2441
00007c454bbd3705  call 0x00007C454BAB52F0
00007c454bbd370a  jmp 0x00007C454BBD244B
00007c454bbd370f  call 0x00007C454BAC0EA0
00007c454bbd3714  jmp 0x00007C454BBD2455
00007c454bbd3719  call 0x00007C454BABFD50
00007c454bbd371e  jmp 0x00007C454BBD245F
00007c454bbd3723  call 0x00007C454BAB8EA0
00007c454bbd3728  jmp 0x00007C454BBD2469
00007c454bbd372d  call 0x00007C454BABFC30
00007c454bbd3732  jmp 0x00007C454BBD2476
00007c454bbd3737  call 0x00007C454BAB8D90
00007c454bbd373c  jmp 0x00007C454BBD2483
00007c454bbd3741  call 0x00007C454BAB52F0
00007c454bbd3746  jmp 0x00007C454BBD2496
00007c454bbd374b  call 0x00007C454BAB52F0
00007c454bbd3750  jmp 0x00007C454BBD24A9
00007c454bbd3755  call 0x00007C454BAC0FC0
00007c454bbd375a  jmp 0x00007C454BBD24B6
00007c454bbd375f  call 0x00007C454BAC0FC0
00007c454bbd3764  jmp 0x00007C454BBD24C9
00007c454bbd3769  call 0x00007C454BAC0EA0
00007c454bbd376e  jmp 0x00007C454BBD24D6
00007c454bbd3773  call 0x00007C454BAB52F0
00007c454bbd3778  jmp 0x00007C454BBD24E9
00007c454bbd377d  call 0x00007C454BAB52F0
00007c454bbd3782  jmp 0x00007C454BBD24FC
00007c454bbd3787  call 0x00007C454BAB52F0
00007c454bbd378c  jmp 0x00007C454BBD250F
00007c454bbd3791  call 0x00007C454BAB52F0
00007c454bbd3796  jmp 0x00007C454BBD252A
00007c454bbd379b  call 0x00007C454BAB52F0
00007c454bbd37a0  jmp 0x00007C454BBD253D
00007c454bbd37a5  call 0x00007C454BAB5400
00007c454bbd37aa  jmp 0x00007C454BBD257E
00007c454bbd37af  call 0x00007C454BAC0FC0
00007c454bbd37b4  jmp 0x00007C454BBD258B
00007c454bbd37b9  call 0x00007C454BAB52F0
00007c454bbd37be  jmp 0x00007C454BBD2598
00007c454bbd37c3  call 0x00007C454BAC0EA0
00007c454bbd37c8  jmp 0x00007C454BBD25A5
00007c454bbd37cd  call 0x00007C454B9FF540
00007c454bbd37d2  jmp 0x00007C454BBD25C3
00007c454bbd37d7  call 0x00007C454BA08C20
00007c454bbd37dc  jmp 0x00007C454BBD25CD
00007c454bbd37e1  call 0x00007C454BAE21C0
00007c454bbd37e6  jmp 0x00007C454BBD25D3
00007c454bbd37eb  call 0x00007C454B9FF540
00007c454bbd37f0  jmp 0x00007C454BBD25E3
00007c454bbd37f5  call 0x00007C454BAC0370
00007c454bbd37fa  jmp 0x00007C454BBD2611
00007c454bbd37ff  call 0x00007C454BABF100
00007c454bbd3804  jmp 0x00007C454BBD261A
00007c454bbd3809  call 0x00007C454BAC0370
00007c454bbd380e  jmp 0x00007C454BBD2674
00007c454bbd3813  call 0x00007C454BABF100
00007c454bbd3818  jmp 0x00007C454BBD267D
00007c454bbd381d  call 0x00007C454BAC0370
00007c454bbd3822  jmp 0x00007C454BBD26C6
00007c454bbd3827  call 0x00007C454BABF100
00007c454bbd382c  jmp 0x00007C454BBD26CF
00007c454bbd3831  call 0x00007C454BA0B720
00007c454bbd3836  jmp 0x00007C454BBD2714
00007c454bbd383b  call 0x00007C454BAB47C0
00007c454bbd3840  jmp 0x00007C454BBD2727
00007c454bbd3845  call 0x00007C454BA08B00
00007c454bbd384a  jmp 0x00007C454BBD273E
00007c454bbd384f  call 0x00007C454B9FF430
00007c454bbd3854  jmp 0x00007C454BBD2751
00007c454bbd3859  call 0x00007C454B9FF430
00007c454bbd385e  jmp 0x00007C454BBD2764
00007c454bbd3863  sub rsp, 0x08
00007c454bbd3867  push rax
00007c454bbd3868  push rcx
00007c454bbd3869  push rdx
00007c454bbd386a  push rdi
00007c454bbd386b  push rsi
00007c454bbd386c  push r8
00007c454bbd386e  push r9
00007c454bbd3870  push r10
00007c454bbd3872  push r11
00007c454bbd3874  sub rsp, 0xF0
00007c454bbd387b  vmovaps [rsp], xmm0
00007c454bbd3880  vmovaps [rsp+0x10], xmm2
00007c454bbd3886  vmovaps [rsp+0x20], xmm3
00007c454bbd388c  vmovaps [rsp+0x30], xmm4
00007c454bbd3892  vmovaps [rsp+0x40], xmm5
00007c454bbd3898  vmovaps [rsp+0x50], xmm6
00007c454bbd389e  vmovaps [rsp+0x60], xmm7
00007c454bbd38a4  vmovaps [rsp+0x70], xmm8
00007c454bbd38aa  vmovaps [rsp+0x80], xmm9
00007c454bbd38b3  vmovaps [rsp+0x90], xmm10
00007c454bbd38bc  vmovaps [rsp+0xA0], xmm11
00007c454bbd38c5  vmovaps [rsp+0xB0], xmm12
00007c454bbd38ce  vmovaps [rsp+0xC0], xmm13
00007c454bbd38d7  vmovaps [rsp+0xD0], xmm14
00007c454bbd38e0  vmovaps [rsp+0xE0], xmm15
00007c454bbd38e9  sub rsp, 0x30
00007c454bbd38ed  movaps [rsp], xmm1
00007c454bbd38f1  movaps [rsp+0x10], xmm12
00007c454bbd38f7  movaps [rsp+0x20], xmm15
00007c454bbd38fd  lea rdi, [rsp]
00007c454bbd3901  mov esi, 0x00
00007c454bbd3906  mov rax, 0x56A18AC54530
00007c454bbd3910  call rax
00007c454bbd3912  movaps xmm1, [rsp]
00007c454bbd3916  add rsp, 0x30
00007c454bbd391a  vmovaps xmm0, [rsp]
00007c454bbd391f  vmovaps xmm2, [rsp+0x10]
00007c454bbd3925  vmovaps xmm3, [rsp+0x20]
00007c454bbd392b  vmovaps xmm4, [rsp+0x30]
00007c454bbd3931  vmovaps xmm5, [rsp+0x40]
00007c454bbd3937  vmovaps xmm6, [rsp+0x50]
00007c454bbd393d  vmovaps xmm7, [rsp+0x60]
00007c454bbd3943  vmovaps xmm8, [rsp+0x70]
00007c454bbd3949  vmovaps xmm9, [rsp+0x80]
00007c454bbd3952  vmovaps xmm10, [rsp+0x90]
00007c454bbd395b  vmovaps xmm11, [rsp+0xA0]
00007c454bbd3964  vmovaps xmm12, [rsp+0xB0]
00007c454bbd396d  vmovaps xmm13, [rsp+0xC0]
00007c454bbd3976  vmovaps xmm14, [rsp+0xD0]
00007c454bbd397f  vmovaps xmm15, [rsp+0xE0]
00007c454bbd3988  add rsp, 0xF0
00007c454bbd398f  pop r11
00007c454bbd3991  pop r10
00007c454bbd3993  pop r9
00007c454bbd3995  pop r8
00007c454bbd3997  pop rsi
00007c454bbd3998  pop rdi
00007c454bbd3999  pop rdx
00007c454bbd399a  pop rcx
00007c454bbd399b  pop rax
00007c454bbd399c  add rsp, 0x08
00007c454bbd39a0  jmp 0x00007C454BBD27B2
00007c454bbd39a5  sub rsp, 0x08
00007c454bbd39a9  push rax
00007c454bbd39aa  push rcx
00007c454bbd39ab  push rdx
00007c454bbd39ac  push rdi
00007c454bbd39ad  push rsi
00007c454bbd39ae  push r8
00007c454bbd39b0  push r9
00007c454bbd39b2  push r10
00007c454bbd39b4  push r11
00007c454bbd39b6  sub rsp, 0xF0
00007c454bbd39bd  vmovaps [rsp], xmm0
00007c454bbd39c2  vmovaps [rsp+0x10], xmm1
00007c454bbd39c8  vmovaps [rsp+0x20], xmm2
00007c454bbd39ce  vmovaps [rsp+0x30], xmm3
00007c454bbd39d4  vmovaps [rsp+0x40], xmm4
00007c454bbd39da  vmovaps [rsp+0x50], xmm5
00007c454bbd39e0  vmovaps [rsp+0x60], xmm6
00007c454bbd39e6  vmovaps [rsp+0x70], xmm7
00007c454bbd39ec  vmovaps [rsp+0x80], xmm8
00007c454bbd39f5  vmovaps [rsp+0x90], xmm9
00007c454bbd39fe  vmovaps [rsp+0xA0], xmm10
00007c454bbd3a07  vmovaps [rsp+0xB0], xmm11
00007c454bbd3a10  vmovaps [rsp+0xC0], xmm12
00007c454bbd3a19  vmovaps [rsp+0xD0], xmm13
00007c454bbd3a22  vmovaps [rsp+0xE0], xmm15
00007c454bbd3a2b  sub rsp, 0x30
00007c454bbd3a2f  movaps [rsp], xmm14
00007c454bbd3a34  movaps [rsp+0x10], xmm1
00007c454bbd3a39  movaps [rsp+0x20], xmm15
00007c454bbd3a3f  lea rdi, [rsp]
00007c454bbd3a43  mov esi, 0x00
00007c454bbd3a48  mov rax, 0x56A18AC54530
00007c454bbd3a52  call rax
00007c454bbd3a54  movaps xmm14, [rsp]
00007c454bbd3a59  add rsp, 0x30
00007c454bbd3a5d  vmovaps xmm0, [rsp]
00007c454bbd3a62  vmovaps xmm1, [rsp+0x10]
00007c454bbd3a68  vmovaps xmm2, [rsp+0x20]
00007c454bbd3a6e  vmovaps xmm3, [rsp+0x30]
00007c454bbd3a74  vmovaps xmm4, [rsp+0x40]
00007c454bbd3a7a  vmovaps xmm5, [rsp+0x50]
00007c454bbd3a80  vmovaps xmm6, [rsp+0x60]
00007c454bbd3a86  vmovaps xmm7, [rsp+0x70]
00007c454bbd3a8c  vmovaps xmm8, [rsp+0x80]
00007c454bbd3a95  vmovaps xmm9, [rsp+0x90]
00007c454bbd3a9e  vmovaps xmm10, [rsp+0xA0]
00007c454bbd3aa7  vmovaps xmm11, [rsp+0xB0]
00007c454bbd3ab0  vmovaps xmm12, [rsp+0xC0]
00007c454bbd3ab9  vmovaps xmm13, [rsp+0xD0]
00007c454bbd3ac2  vmovaps xmm15, [rsp+0xE0]
00007c454bbd3acb  add rsp, 0xF0
00007c454bbd3ad2  pop r11
00007c454bbd3ad4  pop r10
00007c454bbd3ad6  pop r9
00007c454bbd3ad8  pop r8
00007c454bbd3ada  pop rsi
00007c454bbd3adb  pop rdi
00007c454bbd3adc  pop rdx
00007c454bbd3add  pop rcx
00007c454bbd3ade  pop rax
00007c454bbd3adf  add rsp, 0x08
00007c454bbd3ae3  jmp 0x00007C454BBD2800
00007c454bbd3ae8  sub rsp, 0x08
00007c454bbd3aec  push rax
00007c454bbd3aed  push rcx
00007c454bbd3aee  push rdx
00007c454bbd3aef  push rdi
00007c454bbd3af0  push rsi
00007c454bbd3af1  push r8
00007c454bbd3af3  push r9
00007c454bbd3af5  push r10
00007c454bbd3af7  push r11
00007c454bbd3af9  sub rsp, 0xF0
00007c454bbd3b00  vmovaps [rsp], xmm0
00007c454bbd3b05  vmovaps [rsp+0x10], xmm1
00007c454bbd3b0b  vmovaps [rsp+0x20], xmm2
00007c454bbd3b11  vmovaps [rsp+0x30], xmm3
00007c454bbd3b17  vmovaps [rsp+0x40], xmm4
00007c454bbd3b1d  vmovaps [rsp+0x50], xmm5
00007c454bbd3b23  vmovaps [rsp+0x60], xmm6
00007c454bbd3b29  vmovaps [rsp+0x70], xmm7
00007c454bbd3b2f  vmovaps [rsp+0x80], xmm8
00007c454bbd3b38  vmovaps [rsp+0x90], xmm9
00007c454bbd3b41  vmovaps [rsp+0xA0], xmm10
00007c454bbd3b4a  vmovaps [rsp+0xB0], xmm11
00007c454bbd3b53  vmovaps [rsp+0xC0], xmm12
00007c454bbd3b5c  vmovaps [rsp+0xD0], xmm13
00007c454bbd3b65  vmovaps [rsp+0xE0], xmm14
00007c454bbd3b6e  sub rsp, 0x30
00007c454bbd3b72  movaps [rsp], xmm15
00007c454bbd3b77  movaps [rsp+0x10], xmm12
00007c454bbd3b7d  movaps [rsp+0x20], xmm13
00007c454bbd3b83  lea rdi, [rsp]
00007c454bbd3b87  mov esi, 0x00
00007c454bbd3b8c  mov rax, 0x56A18AC54530
00007c454bbd3b96  call rax
00007c454bbd3b98  movaps xmm15, [rsp]
00007c454bbd3b9d  add rsp, 0x30
00007c454bbd3ba1  vmovaps xmm0, [rsp]
00007c454bbd3ba6  vmovaps xmm1, [rsp+0x10]
00007c454bbd3bac  vmovaps xmm2, [rsp+0x20]
00007c454bbd3bb2  vmovaps xmm3, [rsp+0x30]
00007c454bbd3bb8  vmovaps xmm4, [rsp+0x40]
00007c454bbd3bbe  vmovaps xmm5, [rsp+0x50]
00007c454bbd3bc4  vmovaps xmm6, [rsp+0x60]
00007c454bbd3bca  vmovaps xmm7, [rsp+0x70]
00007c454bbd3bd0  vmovaps xmm8, [rsp+0x80]
00007c454bbd3bd9  vmovaps xmm9, [rsp+0x90]
00007c454bbd3be2  vmovaps xmm10, [rsp+0xA0]
00007c454bbd3beb  vmovaps xmm11, [rsp+0xB0]
00007c454bbd3bf4  vmovaps xmm12, [rsp+0xC0]
00007c454bbd3bfd  vmovaps xmm13, [rsp+0xD0]
00007c454bbd3c06  vmovaps xmm14, [rsp+0xE0]
00007c454bbd3c0f  add rsp, 0xF0
00007c454bbd3c16  pop r11
00007c454bbd3c18  pop r10
00007c454bbd3c1a  pop r9
00007c454bbd3c1c  pop r8
00007c454bbd3c1e  pop rsi
00007c454bbd3c1f  pop rdi
00007c454bbd3c20  pop rdx
00007c454bbd3c21  pop rcx
00007c454bbd3c22  pop rax
00007c454bbd3c23  add rsp, 0x08
00007c454bbd3c27  jmp 0x00007C454BBD2835
00007c454bbd3c2c  sub rsp, 0x08
00007c454bbd3c30  push rax
00007c454bbd3c31  push rcx
00007c454bbd3c32  push rdx
00007c454bbd3c33  push rdi
00007c454bbd3c34  push rsi
00007c454bbd3c35  push r8
00007c454bbd3c37  push r9
00007c454bbd3c39  push r10
00007c454bbd3c3b  push r11
00007c454bbd3c3d  sub rsp, 0xF0
00007c454bbd3c44  vmovaps [rsp], xmm0
00007c454bbd3c49  vmovaps [rsp+0x10], xmm2
00007c454bbd3c4f  vmovaps [rsp+0x20], xmm3
00007c454bbd3c55  vmovaps [rsp+0x30], xmm4
00007c454bbd3c5b  vmovaps [rsp+0x40], xmm5
00007c454bbd3c61  vmovaps [rsp+0x50], xmm6
00007c454bbd3c67  vmovaps [rsp+0x60], xmm7
00007c454bbd3c6d  vmovaps [rsp+0x70], xmm8
00007c454bbd3c73  vmovaps [rsp+0x80], xmm9
00007c454bbd3c7c  vmovaps [rsp+0x90], xmm10
00007c454bbd3c85  vmovaps [rsp+0xA0], xmm11
00007c454bbd3c8e  vmovaps [rsp+0xB0], xmm12
00007c454bbd3c97  vmovaps [rsp+0xC0], xmm13
00007c454bbd3ca0  vmovaps [rsp+0xD0], xmm14
00007c454bbd3ca9  vmovaps [rsp+0xE0], xmm15
00007c454bbd3cb2  sub rsp, 0x30
00007c454bbd3cb6  movaps [rsp], xmm1
00007c454bbd3cba  movaps [rsp+0x10], xmm12
00007c454bbd3cc0  movaps [rsp+0x20], xmm10
00007c454bbd3cc6  lea rdi, [rsp]
00007c454bbd3cca  mov esi, 0x00
00007c454bbd3ccf  mov rax, 0x56A18AC54530
00007c454bbd3cd9  call rax
00007c454bbd3cdb  movaps xmm1, [rsp]
00007c454bbd3cdf  add rsp, 0x30
00007c454bbd3ce3  vmovaps xmm0, [rsp]
00007c454bbd3ce8  vmovaps xmm2, [rsp+0x10]
00007c454bbd3cee  vmovaps xmm3, [rsp+0x20]
00007c454bbd3cf4  vmovaps xmm4, [rsp+0x30]
00007c454bbd3cfa  vmovaps xmm5, [rsp+0x40]
00007c454bbd3d00  vmovaps xmm6, [rsp+0x50]
00007c454bbd3d06  vmovaps xmm7, [rsp+0x60]
00007c454bbd3d0c  vmovaps xmm8, [rsp+0x70]
00007c454bbd3d12  vmovaps xmm9, [rsp+0x80]
00007c454bbd3d1b  vmovaps xmm10, [rsp+0x90]
00007c454bbd3d24  vmovaps xmm11, [rsp+0xA0]
00007c454bbd3d2d  vmovaps xmm12, [rsp+0xB0]
00007c454bbd3d36  vmovaps xmm13, [rsp+0xC0]
00007c454bbd3d3f  vmovaps xmm14, [rsp+0xD0]
00007c454bbd3d48  vmovaps xmm15, [rsp+0xE0]
00007c454bbd3d51  add rsp, 0xF0
00007c454bbd3d58  pop r11
00007c454bbd3d5a  pop r10
00007c454bbd3d5c  pop r9
00007c454bbd3d5e  pop r8
00007c454bbd3d60  pop rsi
00007c454bbd3d61  pop rdi
00007c454bbd3d62  pop rdx
00007c454bbd3d63  pop rcx
00007c454bbd3d64  pop rax
00007c454bbd3d65  add rsp, 0x08
00007c454bbd3d69  jmp 0x00007C454BBD284F
00007c454bbd3d6e  sub rsp, 0x08
00007c454bbd3d72  push rax
00007c454bbd3d73  push rcx
00007c454bbd3d74  push rdx
00007c454bbd3d75  push rdi
00007c454bbd3d76  push rsi
00007c454bbd3d77  push r8
00007c454bbd3d79  push r9
00007c454bbd3d7b  push r10
00007c454bbd3d7d  push r11
00007c454bbd3d7f  sub rsp, 0xF0
00007c454bbd3d86  vmovaps [rsp], xmm0
00007c454bbd3d8b  vmovaps [rsp+0x10], xmm1
00007c454bbd3d91  vmovaps [rsp+0x20], xmm2
00007c454bbd3d97  vmovaps [rsp+0x30], xmm3
00007c454bbd3d9d  vmovaps [rsp+0x40], xmm4
00007c454bbd3da3  vmovaps [rsp+0x50], xmm5
00007c454bbd3da9  vmovaps [rsp+0x60], xmm6
00007c454bbd3daf  vmovaps [rsp+0x70], xmm7
00007c454bbd3db5  vmovaps [rsp+0x80], xmm8
00007c454bbd3dbe  vmovaps [rsp+0x90], xmm9
00007c454bbd3dc7  vmovaps [rsp+0xA0], xmm10
00007c454bbd3dd0  vmovaps [rsp+0xB0], xmm11
00007c454bbd3dd9  vmovaps [rsp+0xC0], xmm12
00007c454bbd3de2  vmovaps [rsp+0xD0], xmm14
00007c454bbd3deb  vmovaps [rsp+0xE0], xmm15
00007c454bbd3df4  sub rsp, 0x30
00007c454bbd3df8  movaps [rsp], xmm13
00007c454bbd3dfd  movaps [rsp+0x10], xmm12
00007c454bbd3e03  movaps [rsp+0x20], xmm2
00007c454bbd3e08  lea rdi, [rsp]
00007c454bbd3e0c  mov esi, 0x00
00007c454bbd3e11  mov rax, 0x56A18AC54530
00007c454bbd3e1b  call rax
00007c454bbd3e1d  movaps xmm13, [rsp]
00007c454bbd3e22  add rsp, 0x30
00007c454bbd3e26  vmovaps xmm0, [rsp]
00007c454bbd3e2b  vmovaps xmm1, [rsp+0x10]
00007c454bbd3e31  vmovaps xmm2, [rsp+0x20]
00007c454bbd3e37  vmovaps xmm3, [rsp+0x30]
00007c454bbd3e3d  vmovaps xmm4, [rsp+0x40]
00007c454bbd3e43  vmovaps xmm5, [rsp+0x50]
00007c454bbd3e49  vmovaps xmm6, [rsp+0x60]
00007c454bbd3e4f  vmovaps xmm7, [rsp+0x70]
00007c454bbd3e55  vmovaps xmm8, [rsp+0x80]
00007c454bbd3e5e  vmovaps xmm9, [rsp+0x90]
00007c454bbd3e67  vmovaps xmm10, [rsp+0xA0]
00007c454bbd3e70  vmovaps xmm11, [rsp+0xB0]
00007c454bbd3e79  vmovaps xmm12, [rsp+0xC0]
00007c454bbd3e82  vmovaps xmm14, [rsp+0xD0]
00007c454bbd3e8b  vmovaps xmm15, [rsp+0xE0]
00007c454bbd3e94  add rsp, 0xF0
00007c454bbd3e9b  pop r11
00007c454bbd3e9d  pop r10
00007c454bbd3e9f  pop r9
00007c454bbd3ea1  pop r8
00007c454bbd3ea3  pop rsi
00007c454bbd3ea4  pop rdi
00007c454bbd3ea5  pop rdx
00007c454bbd3ea6  pop rcx
00007c454bbd3ea7  pop rax
00007c454bbd3ea8  add rsp, 0x08
00007c454bbd3eac  jmp 0x00007C454BBD286A
00007c454bbd3eb1  sub rsp, 0x08
00007c454bbd3eb5  push rax
00007c454bbd3eb6  push rcx
00007c454bbd3eb7  push rdx
00007c454bbd3eb8  push rdi
00007c454bbd3eb9  push rsi
00007c454bbd3eba  push r8
00007c454bbd3ebc  push r9
00007c454bbd3ebe  push r10
00007c454bbd3ec0  push r11
00007c454bbd3ec2  sub rsp, 0xF0
00007c454bbd3ec9  vmovaps [rsp], xmm0
00007c454bbd3ece  vmovaps [rsp+0x10], xmm2
00007c454bbd3ed4  vmovaps [rsp+0x20], xmm3
00007c454bbd3eda  vmovaps [rsp+0x30], xmm4
00007c454bbd3ee0  vmovaps [rsp+0x40], xmm5
00007c454bbd3ee6  vmovaps [rsp+0x50], xmm6
00007c454bbd3eec  vmovaps [rsp+0x60], xmm7
00007c454bbd3ef2  vmovaps [rsp+0x70], xmm8
00007c454bbd3ef8  vmovaps [rsp+0x80], xmm9
00007c454bbd3f01  vmovaps [rsp+0x90], xmm10
00007c454bbd3f0a  vmovaps [rsp+0xA0], xmm11
00007c454bbd3f13  vmovaps [rsp+0xB0], xmm12
00007c454bbd3f1c  vmovaps [rsp+0xC0], xmm13
00007c454bbd3f25  vmovaps [rsp+0xD0], xmm14
00007c454bbd3f2e  vmovaps [rsp+0xE0], xmm15
00007c454bbd3f37  sub rsp, 0x30
00007c454bbd3f3b  movaps [rsp], xmm1
00007c454bbd3f3f  movaps [rsp+0x10], xmm10
00007c454bbd3f45  movaps [rsp+0x20], xmm2
00007c454bbd3f4a  lea rdi, [rsp]
00007c454bbd3f4e  mov esi, 0x00
00007c454bbd3f53  mov rax, 0x56A18AC54530
00007c454bbd3f5d  call rax
00007c454bbd3f5f  movaps xmm1, [rsp]
00007c454bbd3f63  add rsp, 0x30
00007c454bbd3f67  vmovaps xmm0, [rsp]
00007c454bbd3f6c  vmovaps xmm2, [rsp+0x10]
00007c454bbd3f72  vmovaps xmm3, [rsp+0x20]
00007c454bbd3f78  vmovaps xmm4, [rsp+0x30]
00007c454bbd3f7e  vmovaps xmm5, [rsp+0x40]
00007c454bbd3f84  vmovaps xmm6, [rsp+0x50]
00007c454bbd3f8a  vmovaps xmm7, [rsp+0x60]
00007c454bbd3f90  vmovaps xmm8, [rsp+0x70]
00007c454bbd3f96  vmovaps xmm9, [rsp+0x80]
00007c454bbd3f9f  vmovaps xmm10, [rsp+0x90]
00007c454bbd3fa8  vmovaps xmm11, [rsp+0xA0]
00007c454bbd3fb1  vmovaps xmm12, [rsp+0xB0]
00007c454bbd3fba  vmovaps xmm13, [rsp+0xC0]
00007c454bbd3fc3  vmovaps xmm14, [rsp+0xD0]
00007c454bbd3fcc  vmovaps xmm15, [rsp+0xE0]
00007c454bbd3fd5  add rsp, 0xF0
00007c454bbd3fdc  pop r11
00007c454bbd3fde  pop r10
00007c454bbd3fe0  pop r9
00007c454bbd3fe2  pop r8
00007c454bbd3fe4  pop rsi
00007c454bbd3fe5  pop rdi
00007c454bbd3fe6  pop rdx
00007c454bbd3fe7  pop rcx
00007c454bbd3fe8  pop rax
00007c454bbd3fe9  add rsp, 0x08
00007c454bbd3fed  jmp 0x00007C454BBD28D2
00007c454bbd3ff2  sub rsp, 0x08
00007c454bbd3ff6  push rax
00007c454bbd3ff7  push rcx
00007c454bbd3ff8  push rdx
00007c454bbd3ff9  push rdi
00007c454bbd3ffa  push rsi
00007c454bbd3ffb  push r8
00007c454bbd3ffd  push r9
00007c454bbd3fff  push r10
00007c454bbd4001  push r11
00007c454bbd4003  sub rsp, 0xF0
00007c454bbd400a  vmovaps [rsp], xmm0
00007c454bbd400f  vmovaps [rsp+0x10], xmm1
00007c454bbd4015  vmovaps [rsp+0x20], xmm2
00007c454bbd401b  vmovaps [rsp+0x30], xmm3
00007c454bbd4021  vmovaps [rsp+0x40], xmm4
00007c454bbd4027  vmovaps [rsp+0x50], xmm5
00007c454bbd402d  vmovaps [rsp+0x60], xmm6
00007c454bbd4033  vmovaps [rsp+0x70], xmm7
00007c454bbd4039  vmovaps [rsp+0x80], xmm8
00007c454bbd4042  vmovaps [rsp+0x90], xmm9
00007c454bbd404b  vmovaps [rsp+0xA0], xmm10
00007c454bbd4054  vmovaps [rsp+0xB0], xmm11
00007c454bbd405d  vmovaps [rsp+0xC0], xmm12
00007c454bbd4066  vmovaps [rsp+0xD0], xmm13
00007c454bbd406f  vmovaps [rsp+0xE0], xmm14
00007c454bbd4078  sub rsp, 0x30
00007c454bbd407c  movaps [rsp], xmm15
00007c454bbd4081  movaps [rsp+0x10], xmm10
00007c454bbd4087  movaps [rsp+0x20], xmm2
00007c454bbd408c  lea rdi, [rsp]
00007c454bbd4090  mov esi, 0x00
00007c454bbd4095  mov rax, 0x56A18AC54530
00007c454bbd409f  call rax
00007c454bbd40a1  movaps xmm15, [rsp]
00007c454bbd40a6  add rsp, 0x30
00007c454bbd40aa  vmovaps xmm0, [rsp]
00007c454bbd40af  vmovaps xmm1, [rsp+0x10]
00007c454bbd40b5  vmovaps xmm2, [rsp+0x20]
00007c454bbd40bb  vmovaps xmm3, [rsp+0x30]
00007c454bbd40c1  vmovaps xmm4, [rsp+0x40]
00007c454bbd40c7  vmovaps xmm5, [rsp+0x50]
00007c454bbd40cd  vmovaps xmm6, [rsp+0x60]
00007c454bbd40d3  vmovaps xmm7, [rsp+0x70]
00007c454bbd40d9  vmovaps xmm8, [rsp+0x80]
00007c454bbd40e2  vmovaps xmm9, [rsp+0x90]
00007c454bbd40eb  vmovaps xmm10, [rsp+0xA0]
00007c454bbd40f4  vmovaps xmm11, [rsp+0xB0]
00007c454bbd40fd  vmovaps xmm12, [rsp+0xC0]
00007c454bbd4106  vmovaps xmm13, [rsp+0xD0]
00007c454bbd410f  vmovaps xmm14, [rsp+0xE0]
00007c454bbd4118  add rsp, 0xF0
00007c454bbd411f  pop r11
00007c454bbd4121  pop r10
00007c454bbd4123  pop r9
00007c454bbd4125  pop r8
00007c454bbd4127  pop rsi
00007c454bbd4128  pop rdi
00007c454bbd4129  pop rdx
00007c454bbd412a  pop rcx
00007c454bbd412b  pop rax
00007c454bbd412c  add rsp, 0x08
00007c454bbd4130  jmp 0x00007C454BBD2924
00007c454bbd4135  sub rsp, 0x08
00007c454bbd4139  push rax
00007c454bbd413a  push rcx
00007c454bbd413b  push rdx
00007c454bbd413c  push rdi
00007c454bbd413d  push rsi
00007c454bbd413e  push r8
00007c454bbd4140  push r9
00007c454bbd4142  push r10
00007c454bbd4144  push r11
00007c454bbd4146  sub rsp, 0xF0
00007c454bbd414d  vmovaps [rsp], xmm0
00007c454bbd4152  vmovaps [rsp+0x10], xmm2
00007c454bbd4158  vmovaps [rsp+0x20], xmm3
00007c454bbd415e  vmovaps [rsp+0x30], xmm4
00007c454bbd4164  vmovaps [rsp+0x40], xmm5
00007c454bbd416a  vmovaps [rsp+0x50], xmm6
00007c454bbd4170  vmovaps [rsp+0x60], xmm7
00007c454bbd4176  vmovaps [rsp+0x70], xmm8
00007c454bbd417c  vmovaps [rsp+0x80], xmm9
00007c454bbd4185  vmovaps [rsp+0x90], xmm10
00007c454bbd418e  vmovaps [rsp+0xA0], xmm11
00007c454bbd4197  vmovaps [rsp+0xB0], xmm12
00007c454bbd41a0  vmovaps [rsp+0xC0], xmm13
00007c454bbd41a9  vmovaps [rsp+0xD0], xmm14
00007c454bbd41b2  vmovaps [rsp+0xE0], xmm15
00007c454bbd41bb  sub rsp, 0x30
00007c454bbd41bf  movaps [rsp], xmm1
00007c454bbd41c3  movaps [rsp+0x10], xmm10
00007c454bbd41c9  movaps [rsp+0x20], xmm15
00007c454bbd41cf  lea rdi, [rsp]
00007c454bbd41d3  mov esi, 0x00
00007c454bbd41d8  mov rax, 0x56A18AC54530
00007c454bbd41e2  call rax
00007c454bbd41e4  movaps xmm1, [rsp]
00007c454bbd41e8  add rsp, 0x30
00007c454bbd41ec  vmovaps xmm0, [rsp]
00007c454bbd41f1  vmovaps xmm2, [rsp+0x10]
00007c454bbd41f7  vmovaps xmm3, [rsp+0x20]
00007c454bbd41fd  vmovaps xmm4, [rsp+0x30]
00007c454bbd4203  vmovaps xmm5, [rsp+0x40]
00007c454bbd4209  vmovaps xmm6, [rsp+0x50]
00007c454bbd420f  vmovaps xmm7, [rsp+0x60]
00007c454bbd4215  vmovaps xmm8, [rsp+0x70]
00007c454bbd421b  vmovaps xmm9, [rsp+0x80]
00007c454bbd4224  vmovaps xmm10, [rsp+0x90]
00007c454bbd422d  vmovaps xmm11, [rsp+0xA0]
00007c454bbd4236  vmovaps xmm12, [rsp+0xB0]
00007c454bbd423f  vmovaps xmm13, [rsp+0xC0]
00007c454bbd4248  vmovaps xmm14, [rsp+0xD0]
00007c454bbd4251  vmovaps xmm15, [rsp+0xE0]
00007c454bbd425a  add rsp, 0xF0
00007c454bbd4261  pop r11
00007c454bbd4263  pop r10
00007c454bbd4265  pop r9
00007c454bbd4267  pop r8
00007c454bbd4269  pop rsi
00007c454bbd426a  pop rdi
00007c454bbd426b  pop rdx
00007c454bbd426c  pop rcx
00007c454bbd426d  pop rax
00007c454bbd426e  add rsp, 0x08
00007c454bbd4272  jmp 0x00007C454BBD2962
00007c454bbd4277  sub rsp, 0x08
00007c454bbd427b  push rax
00007c454bbd427c  push rcx
00007c454bbd427d  push rdx
00007c454bbd427e  push rdi
00007c454bbd427f  push rsi
00007c454bbd4280  push r8
00007c454bbd4282  push r9
00007c454bbd4284  push r10
00007c454bbd4286  push r11
00007c454bbd4288  sub rsp, 0xF0
00007c454bbd428f  vmovaps [rsp], xmm0
00007c454bbd4294  vmovaps [rsp+0x10], xmm1
00007c454bbd429a  vmovaps [rsp+0x20], xmm2
00007c454bbd42a0  vmovaps [rsp+0x30], xmm3
00007c454bbd42a6  vmovaps [rsp+0x40], xmm4
00007c454bbd42ac  vmovaps [rsp+0x50], xmm5
00007c454bbd42b2  vmovaps [rsp+0x60], xmm6
00007c454bbd42b8  vmovaps [rsp+0x70], xmm7
00007c454bbd42be  vmovaps [rsp+0x80], xmm8
00007c454bbd42c7  vmovaps [rsp+0x90], xmm9
00007c454bbd42d0  vmovaps [rsp+0xA0], xmm10
00007c454bbd42d9  vmovaps [rsp+0xB0], xmm11
00007c454bbd42e2  vmovaps [rsp+0xC0], xmm12
00007c454bbd42eb  vmovaps [rsp+0xD0], xmm13
00007c454bbd42f4  vmovaps [rsp+0xE0], xmm15
00007c454bbd42fd  sub rsp, 0x30
00007c454bbd4301  movaps [rsp], xmm14
00007c454bbd4306  movaps [rsp+0x10], xmm10
00007c454bbd430c  movaps [rsp+0x20], xmm15
00007c454bbd4312  lea rdi, [rsp]
00007c454bbd4316  mov esi, 0x00
00007c454bbd431b  mov rax, 0x56A18AC54530
00007c454bbd4325  call rax
00007c454bbd4327  movaps xmm14, [rsp]
00007c454bbd432c  add rsp, 0x30
00007c454bbd4330  vmovaps xmm0, [rsp]
00007c454bbd4335  vmovaps xmm1, [rsp+0x10]
00007c454bbd433b  vmovaps xmm2, [rsp+0x20]
00007c454bbd4341  vmovaps xmm3, [rsp+0x30]
00007c454bbd4347  vmovaps xmm4, [rsp+0x40]
00007c454bbd434d  vmovaps xmm5, [rsp+0x50]
00007c454bbd4353  vmovaps xmm6, [rsp+0x60]
00007c454bbd4359  vmovaps xmm7, [rsp+0x70]
00007c454bbd435f  vmovaps xmm8, [rsp+0x80]
00007c454bbd4368  vmovaps xmm9, [rsp+0x90]
00007c454bbd4371  vmovaps xmm10, [rsp+0xA0]
00007c454bbd437a  vmovaps xmm11, [rsp+0xB0]
00007c454bbd4383  vmovaps xmm12, [rsp+0xC0]
00007c454bbd438c  vmovaps xmm13, [rsp+0xD0]
00007c454bbd4395  vmovaps xmm15, [rsp+0xE0]
00007c454bbd439e  add rsp, 0xF0
00007c454bbd43a5  pop r11
00007c454bbd43a7  pop r10
00007c454bbd43a9  pop r9
00007c454bbd43ab  pop r8
00007c454bbd43ad  pop rsi
00007c454bbd43ae  pop rdi
00007c454bbd43af  pop rdx
00007c454bbd43b0  pop rcx
00007c454bbd43b1  pop rax
00007c454bbd43b2  add rsp, 0x08
00007c454bbd43b6  jmp 0x00007C454BBD298E
00007c454bbd43bb  call 0x00007C454B9FF430
00007c454bbd43c0  jmp 0x00007C454BBD2A1E
00007c454bbd43c5  call 0x00007C454B9FF430
00007c454bbd43ca  jmp 0x00007C454BBD2A31
00007c454bbd43cf  sub rsp, 0x08
00007c454bbd43d3  push rax
00007c454bbd43d4  push rcx
00007c454bbd43d5  push rdx
00007c454bbd43d6  push rdi
00007c454bbd43d7  push rsi
00007c454bbd43d8  push r8
00007c454bbd43da  push r9
00007c454bbd43dc  push r10
00007c454bbd43de  push r11
00007c454bbd43e0  sub rsp, 0xF0
00007c454bbd43e7  vmovaps [rsp], xmm0
00007c454bbd43ec  vmovaps [rsp+0x10], xmm2
00007c454bbd43f2  vmovaps [rsp+0x20], xmm3
00007c454bbd43f8  vmovaps [rsp+0x30], xmm4
00007c454bbd43fe  vmovaps [rsp+0x40], xmm5
00007c454bbd4404  vmovaps [rsp+0x50], xmm6
00007c454bbd440a  vmovaps [rsp+0x60], xmm7
00007c454bbd4410  vmovaps [rsp+0x70], xmm8
00007c454bbd4416  vmovaps [rsp+0x80], xmm9
00007c454bbd441f  vmovaps [rsp+0x90], xmm10
00007c454bbd4428  vmovaps [rsp+0xA0], xmm11
00007c454bbd4431  vmovaps [rsp+0xB0], xmm12
00007c454bbd443a  vmovaps [rsp+0xC0], xmm13
00007c454bbd4443  vmovaps [rsp+0xD0], xmm14
00007c454bbd444c  vmovaps [rsp+0xE0], xmm15
00007c454bbd4455  sub rsp, 0x30
00007c454bbd4459  movaps [rsp], xmm1
00007c454bbd445d  movaps [rsp+0x10], xmm13
00007c454bbd4463  movaps [rsp+0x20], xmm2
00007c454bbd4468  lea rdi, [rsp]
00007c454bbd446c  mov esi, 0x00
00007c454bbd4471  mov rax, 0x56A18AC54530
00007c454bbd447b  call rax
00007c454bbd447d  movaps xmm1, [rsp]
00007c454bbd4481  add rsp, 0x30
00007c454bbd4485  vmovaps xmm0, [rsp]
00007c454bbd448a  vmovaps xmm2, [rsp+0x10]
00007c454bbd4490  vmovaps xmm3, [rsp+0x20]
00007c454bbd4496  vmovaps xmm4, [rsp+0x30]
00007c454bbd449c  vmovaps xmm5, [rsp+0x40]
00007c454bbd44a2  vmovaps xmm6, [rsp+0x50]
00007c454bbd44a8  vmovaps xmm7, [rsp+0x60]
00007c454bbd44ae  vmovaps xmm8, [rsp+0x70]
00007c454bbd44b4  vmovaps xmm9, [rsp+0x80]
00007c454bbd44bd  vmovaps xmm10, [rsp+0x90]
00007c454bbd44c6  vmovaps xmm11, [rsp+0xA0]
00007c454bbd44cf  vmovaps xmm12, [rsp+0xB0]
00007c454bbd44d8  vmovaps xmm13, [rsp+0xC0]
00007c454bbd44e1  vmovaps xmm14, [rsp+0xD0]
00007c454bbd44ea  vmovaps xmm15, [rsp+0xE0]
00007c454bbd44f3  add rsp, 0xF0
00007c454bbd44fa  pop r11
00007c454bbd44fc  pop r10
00007c454bbd44fe  pop r9
00007c454bbd4500  pop r8
00007c454bbd4502  pop rsi
00007c454bbd4503  pop rdi
00007c454bbd4504  pop rdx
00007c454bbd4505  pop rcx
00007c454bbd4506  pop rax
00007c454bbd4507  add rsp, 0x08
00007c454bbd450b  jmp 0x00007C454BBD2A5C
00007c454bbd4510  call 0x00007C454BA0E760
00007c454bbd4515  jmp 0x00007C454BBD2A69
00007c454bbd451a  sub rsp, 0x08
00007c454bbd451e  push rax
00007c454bbd451f  push rcx
00007c454bbd4520  push rdx
00007c454bbd4521  push rdi
00007c454bbd4522  push rsi
00007c454bbd4523  push r8
00007c454bbd4525  push r9
00007c454bbd4527  push r10
00007c454bbd4529  push r11
00007c454bbd452b  sub rsp, 0xF0
00007c454bbd4532  vmovaps [rsp], xmm0
00007c454bbd4537  vmovaps [rsp+0x10], xmm1
00007c454bbd453d  vmovaps [rsp+0x20], xmm2
00007c454bbd4543  vmovaps [rsp+0x30], xmm3
00007c454bbd4549  vmovaps [rsp+0x40], xmm4
00007c454bbd454f  vmovaps [rsp+0x50], xmm5
00007c454bbd4555  vmovaps [rsp+0x60], xmm6
00007c454bbd455b  vmovaps [rsp+0x70], xmm7
00007c454bbd4561  vmovaps [rsp+0x80], xmm8
00007c454bbd456a  vmovaps [rsp+0x90], xmm9
00007c454bbd4573  vmovaps [rsp+0xA0], xmm10
00007c454bbd457c  vmovaps [rsp+0xB0], xmm11
00007c454bbd4585  vmovaps [rsp+0xC0], xmm12
00007c454bbd458e  vmovaps [rsp+0xD0], xmm14
00007c454bbd4597  vmovaps [rsp+0xE0], xmm15
00007c454bbd45a0  sub rsp, 0x30
00007c454bbd45a4  movaps [rsp], xmm13
00007c454bbd45a9  movaps [rsp+0x10], xmm2
00007c454bbd45ae  movaps [rsp+0x20], xmm1
00007c454bbd45b3  lea rdi, [rsp]
00007c454bbd45b7  mov esi, 0x00
00007c454bbd45bc  mov rax, 0x56A18AC54530
00007c454bbd45c6  call rax
00007c454bbd45c8  movaps xmm13, [rsp]
00007c454bbd45cd  add rsp, 0x30
00007c454bbd45d1  vmovaps xmm0, [rsp]
00007c454bbd45d6  vmovaps xmm1, [rsp+0x10]
00007c454bbd45dc  vmovaps xmm2, [rsp+0x20]
00007c454bbd45e2  vmovaps xmm3, [rsp+0x30]
00007c454bbd45e8  vmovaps xmm4, [rsp+0x40]
00007c454bbd45ee  vmovaps xmm5, [rsp+0x50]
00007c454bbd45f4  vmovaps xmm6, [rsp+0x60]
00007c454bbd45fa  vmovaps xmm7, [rsp+0x70]
00007c454bbd4600  vmovaps xmm8, [rsp+0x80]
00007c454bbd4609  vmovaps xmm9, [rsp+0x90]
00007c454bbd4612  vmovaps xmm10, [rsp+0xA0]
00007c454bbd461b  vmovaps xmm11, [rsp+0xB0]
00007c454bbd4624  vmovaps xmm12, [rsp+0xC0]
00007c454bbd462d  vmovaps xmm14, [rsp+0xD0]
00007c454bbd4636  vmovaps xmm15, [rsp+0xE0]
00007c454bbd463f  add rsp, 0xF0
00007c454bbd4646  pop r11
00007c454bbd4648  pop r10
00007c454bbd464a  pop r9
00007c454bbd464c  pop r8
00007c454bbd464e  pop rsi
00007c454bbd464f  pop rdi
00007c454bbd4650  pop rdx
00007c454bbd4651  pop rcx
00007c454bbd4652  pop rax
00007c454bbd4653  add rsp, 0x08
00007c454bbd4657  jmp 0x00007C454BBD2AA8
00007c454bbd465c  sub rsp, 0x08
00007c454bbd4660  push rax
00007c454bbd4661  push rcx
00007c454bbd4662  push rdx
00007c454bbd4663  push rdi
00007c454bbd4664  push rsi
00007c454bbd4665  push r8
00007c454bbd4667  push r9
00007c454bbd4669  push r10
00007c454bbd466b  push r11
00007c454bbd466d  sub rsp, 0xF0
00007c454bbd4674  vmovaps [rsp], xmm0
00007c454bbd4679  vmovaps [rsp+0x10], xmm2
00007c454bbd467f  vmovaps [rsp+0x20], xmm3
00007c454bbd4685  vmovaps [rsp+0x30], xmm4
00007c454bbd468b  vmovaps [rsp+0x40], xmm5
00007c454bbd4691  vmovaps [rsp+0x50], xmm6
00007c454bbd4697  vmovaps [rsp+0x60], xmm7
00007c454bbd469d  vmovaps [rsp+0x70], xmm8
00007c454bbd46a3  vmovaps [rsp+0x80], xmm9
00007c454bbd46ac  vmovaps [rsp+0x90], xmm10
00007c454bbd46b5  vmovaps [rsp+0xA0], xmm11
00007c454bbd46be  vmovaps [rsp+0xB0], xmm12
00007c454bbd46c7  vmovaps [rsp+0xC0], xmm13
00007c454bbd46d0  vmovaps [rsp+0xD0], xmm14
00007c454bbd46d9  vmovaps [rsp+0xE0], xmm15
00007c454bbd46e2  sub rsp, 0x30
00007c454bbd46e6  movaps [rsp], xmm1
00007c454bbd46ea  movaps [rsp+0x10], xmm14
00007c454bbd46f0  movaps [rsp+0x20], xmm15
00007c454bbd46f6  lea rdi, [rsp]
00007c454bbd46fa  mov esi, 0x00
00007c454bbd46ff  mov rax, 0x56A18AC54530
00007c454bbd4709  call rax
00007c454bbd470b  movaps xmm1, [rsp]
00007c454bbd470f  add rsp, 0x30
00007c454bbd4713  vmovaps xmm0, [rsp]
00007c454bbd4718  vmovaps xmm2, [rsp+0x10]
00007c454bbd471e  vmovaps xmm3, [rsp+0x20]
00007c454bbd4724  vmovaps xmm4, [rsp+0x30]
00007c454bbd472a  vmovaps xmm5, [rsp+0x40]
00007c454bbd4730  vmovaps xmm6, [rsp+0x50]
00007c454bbd4736  vmovaps xmm7, [rsp+0x60]
00007c454bbd473c  vmovaps xmm8, [rsp+0x70]
00007c454bbd4742  vmovaps xmm9, [rsp+0x80]
00007c454bbd474b  vmovaps xmm10, [rsp+0x90]
00007c454bbd4754  vmovaps xmm11, [rsp+0xA0]
00007c454bbd475d  vmovaps xmm12, [rsp+0xB0]
00007c454bbd4766  vmovaps xmm13, [rsp+0xC0]
00007c454bbd476f  vmovaps xmm14, [rsp+0xD0]
00007c454bbd4778  vmovaps xmm15, [rsp+0xE0]
00007c454bbd4781  add rsp, 0xF0
00007c454bbd4788  pop r11
00007c454bbd478a  pop r10
00007c454bbd478c  pop r9
00007c454bbd478e  pop r8
00007c454bbd4790  pop rsi
00007c454bbd4791  pop rdi
00007c454bbd4792  pop rdx
00007c454bbd4793  pop rcx
00007c454bbd4794  pop rax
00007c454bbd4795  add rsp, 0x08
00007c454bbd4799  jmp 0x00007C454BBD2ACA
00007c454bbd479e  sub rsp, 0x08
00007c454bbd47a2  push rax
00007c454bbd47a3  push rcx
00007c454bbd47a4  push rdx
00007c454bbd47a5  push rdi
00007c454bbd47a6  push rsi
00007c454bbd47a7  push r8
00007c454bbd47a9  push r9
00007c454bbd47ab  push r10
00007c454bbd47ad  push r11
00007c454bbd47af  sub rsp, 0xF0
00007c454bbd47b6  vmovaps [rsp], xmm0
00007c454bbd47bb  vmovaps [rsp+0x10], xmm1
00007c454bbd47c1  vmovaps [rsp+0x20], xmm2
00007c454bbd47c7  vmovaps [rsp+0x30], xmm3
00007c454bbd47cd  vmovaps [rsp+0x40], xmm4
00007c454bbd47d3  vmovaps [rsp+0x50], xmm5
00007c454bbd47d9  vmovaps [rsp+0x60], xmm6
00007c454bbd47df  vmovaps [rsp+0x70], xmm7
00007c454bbd47e5  vmovaps [rsp+0x80], xmm8
00007c454bbd47ee  vmovaps [rsp+0x90], xmm9
00007c454bbd47f7  vmovaps [rsp+0xA0], xmm10
00007c454bbd4800  vmovaps [rsp+0xB0], xmm11
00007c454bbd4809  vmovaps [rsp+0xC0], xmm12
00007c454bbd4812  vmovaps [rsp+0xD0], xmm13
00007c454bbd481b  vmovaps [rsp+0xE0], xmm15
00007c454bbd4824  sub rsp, 0x30
00007c454bbd4828  movaps [rsp], xmm14
00007c454bbd482d  movaps [rsp+0x10], xmm2
00007c454bbd4832  movaps [rsp+0x20], xmm15
00007c454bbd4838  lea rdi, [rsp]
00007c454bbd483c  mov esi, 0x00
00007c454bbd4841  mov rax, 0x56A18AC54530
00007c454bbd484b  call rax
00007c454bbd484d  movaps xmm14, [rsp]
00007c454bbd4852  add rsp, 0x30
00007c454bbd4856  vmovaps xmm0, [rsp]
00007c454bbd485b  vmovaps xmm1, [rsp+0x10]
00007c454bbd4861  vmovaps xmm2, [rsp+0x20]
00007c454bbd4867  vmovaps xmm3, [rsp+0x30]
00007c454bbd486d  vmovaps xmm4, [rsp+0x40]
00007c454bbd4873  vmovaps xmm5, [rsp+0x50]
00007c454bbd4879  vmovaps xmm6, [rsp+0x60]
00007c454bbd487f  vmovaps xmm7, [rsp+0x70]
00007c454bbd4885  vmovaps xmm8, [rsp+0x80]
00007c454bbd488e  vmovaps xmm9, [rsp+0x90]
00007c454bbd4897  vmovaps xmm10, [rsp+0xA0]
00007c454bbd48a0  vmovaps xmm11, [rsp+0xB0]
00007c454bbd48a9  vmovaps xmm12, [rsp+0xC0]
00007c454bbd48b2  vmovaps xmm13, [rsp+0xD0]
00007c454bbd48bb  vmovaps xmm15, [rsp+0xE0]
00007c454bbd48c4  add rsp, 0xF0
00007c454bbd48cb  pop r11
00007c454bbd48cd  pop r10
00007c454bbd48cf  pop r9
00007c454bbd48d1  pop r8
00007c454bbd48d3  pop rsi
00007c454bbd48d4  pop rdi
00007c454bbd48d5  pop rdx
00007c454bbd48d6  pop rcx
00007c454bbd48d7  pop rax
00007c454bbd48d8  add rsp, 0x08
00007c454bbd48dc  jmp 0x00007C454BBD2B05
00007c454bbd48e1  sub rsp, 0x08
00007c454bbd48e5  push rax
00007c454bbd48e6  push rcx
00007c454bbd48e7  push rdx
00007c454bbd48e8  push rdi
00007c454bbd48e9  push rsi
00007c454bbd48ea  push r8
00007c454bbd48ec  push r9
00007c454bbd48ee  push r10
00007c454bbd48f0  push r11
00007c454bbd48f2  sub rsp, 0xF0
00007c454bbd48f9  vmovaps [rsp], xmm0
00007c454bbd48fe  vmovaps [rsp+0x10], xmm1
00007c454bbd4904  vmovaps [rsp+0x20], xmm2
00007c454bbd490a  vmovaps [rsp+0x30], xmm3
00007c454bbd4910  vmovaps [rsp+0x40], xmm4
00007c454bbd4916  vmovaps [rsp+0x50], xmm5
00007c454bbd491c  vmovaps [rsp+0x60], xmm6
00007c454bbd4922  vmovaps [rsp+0x70], xmm7
00007c454bbd4928  vmovaps [rsp+0x80], xmm8
00007c454bbd4931  vmovaps [rsp+0x90], xmm9
00007c454bbd493a  vmovaps [rsp+0xA0], xmm10
00007c454bbd4943  vmovaps [rsp+0xB0], xmm11
00007c454bbd494c  vmovaps [rsp+0xC0], xmm12
00007c454bbd4955  vmovaps [rsp+0xD0], xmm13
00007c454bbd495e  vmovaps [rsp+0xE0], xmm14
00007c454bbd4967  sub rsp, 0x30
00007c454bbd496b  movaps [rsp], xmm15
00007c454bbd4970  movaps [rsp+0x10], xmm2
00007c454bbd4975  movaps [rsp+0x20], xmm1
00007c454bbd497a  lea rdi, [rsp]
00007c454bbd497e  mov esi, 0x00
00007c454bbd4983  mov rax, 0x56A18AC54530
00007c454bbd498d  call rax
00007c454bbd498f  movaps xmm15, [rsp]
00007c454bbd4994  add rsp, 0x30
00007c454bbd4998  vmovaps xmm0, [rsp]
00007c454bbd499d  vmovaps xmm1, [rsp+0x10]
00007c454bbd49a3  vmovaps xmm2, [rsp+0x20]
00007c454bbd49a9  vmovaps xmm3, [rsp+0x30]
00007c454bbd49af  vmovaps xmm4, [rsp+0x40]
00007c454bbd49b5  vmovaps xmm5, [rsp+0x50]
00007c454bbd49bb  vmovaps xmm6, [rsp+0x60]
00007c454bbd49c1  vmovaps xmm7, [rsp+0x70]
00007c454bbd49c7  vmovaps xmm8, [rsp+0x80]
00007c454bbd49d0  vmovaps xmm9, [rsp+0x90]
00007c454bbd49d9  vmovaps xmm10, [rsp+0xA0]
00007c454bbd49e2  vmovaps xmm11, [rsp+0xB0]
00007c454bbd49eb  vmovaps xmm12, [rsp+0xC0]
00007c454bbd49f4  vmovaps xmm13, [rsp+0xD0]
00007c454bbd49fd  vmovaps xmm14, [rsp+0xE0]
00007c454bbd4a06  add rsp, 0xF0
00007c454bbd4a0d  pop r11
00007c454bbd4a0f  pop r10
00007c454bbd4a11  pop r9
00007c454bbd4a13  pop r8
00007c454bbd4a15  pop rsi
00007c454bbd4a16  pop rdi
00007c454bbd4a17  pop rdx
00007c454bbd4a18  pop rcx
00007c454bbd4a19  pop rax
00007c454bbd4a1a  add rsp, 0x08
00007c454bbd4a1e  jmp 0x00007C454BBD2B41
00007c454bbd4a23  call 0x00007C454B9FF430
00007c454bbd4a28  jmp 0x00007C454BBD2B4E
00007c454bbd4a2d  sub rsp, 0x08
00007c454bbd4a31  push rax
00007c454bbd4a32  push rcx
00007c454bbd4a33  push rdx
00007c454bbd4a34  push rdi
00007c454bbd4a35  push rsi
00007c454bbd4a36  push r8
00007c454bbd4a38  push r9
00007c454bbd4a3a  push r10
00007c454bbd4a3c  push r11
00007c454bbd4a3e  sub rsp, 0xF0
00007c454bbd4a45  vmovaps [rsp], xmm0
00007c454bbd4a4a  vmovaps [rsp+0x10], xmm1
00007c454bbd4a50  vmovaps [rsp+0x20], xmm3
00007c454bbd4a56  vmovaps [rsp+0x30], xmm4
00007c454bbd4a5c  vmovaps [rsp+0x40], xmm5
00007c454bbd4a62  vmovaps [rsp+0x50], xmm6
00007c454bbd4a68  vmovaps [rsp+0x60], xmm7
00007c454bbd4a6e  vmovaps [rsp+0x70], xmm8
00007c454bbd4a74  vmovaps [rsp+0x80], xmm9
00007c454bbd4a7d  vmovaps [rsp+0x90], xmm10
00007c454bbd4a86  vmovaps [rsp+0xA0], xmm11
00007c454bbd4a8f  vmovaps [rsp+0xB0], xmm12
00007c454bbd4a98  vmovaps [rsp+0xC0], xmm13
00007c454bbd4aa1  vmovaps [rsp+0xD0], xmm14
00007c454bbd4aaa  vmovaps [rsp+0xE0], xmm15
00007c454bbd4ab3  sub rsp, 0x30
00007c454bbd4ab7  movaps [rsp], xmm2
00007c454bbd4abb  movaps [rsp+0x10], xmm1
00007c454bbd4ac0  movaps [rsp+0x20], xmm14
00007c454bbd4ac6  lea rdi, [rsp]
00007c454bbd4aca  mov esi, 0x00
00007c454bbd4acf  mov rax, 0x56A18AC54530
00007c454bbd4ad9  call rax
00007c454bbd4adb  movaps xmm2, [rsp]
00007c454bbd4adf  add rsp, 0x30
00007c454bbd4ae3  vmovaps xmm0, [rsp]
00007c454bbd4ae8  vmovaps xmm1, [rsp+0x10]
00007c454bbd4aee  vmovaps xmm3, [rsp+0x20]
00007c454bbd4af4  vmovaps xmm4, [rsp+0x30]
00007c454bbd4afa  vmovaps xmm5, [rsp+0x40]
00007c454bbd4b00  vmovaps xmm6, [rsp+0x50]
00007c454bbd4b06  vmovaps xmm7, [rsp+0x60]
00007c454bbd4b0c  vmovaps xmm8, [rsp+0x70]
00007c454bbd4b12  vmovaps xmm9, [rsp+0x80]
00007c454bbd4b1b  vmovaps xmm10, [rsp+0x90]
00007c454bbd4b24  vmovaps xmm11, [rsp+0xA0]
00007c454bbd4b2d  vmovaps xmm12, [rsp+0xB0]
00007c454bbd4b36  vmovaps xmm13, [rsp+0xC0]
00007c454bbd4b3f  vmovaps xmm14, [rsp+0xD0]
00007c454bbd4b48  vmovaps xmm15, [rsp+0xE0]
00007c454bbd4b51  add rsp, 0xF0
00007c454bbd4b58  pop r11
00007c454bbd4b5a  pop r10
00007c454bbd4b5c  pop r9
00007c454bbd4b5e  pop r8
00007c454bbd4b60  pop rsi
00007c454bbd4b61  pop rdi
00007c454bbd4b62  pop rdx
00007c454bbd4b63  pop rcx
00007c454bbd4b64  pop rax
00007c454bbd4b65  add rsp, 0x08
00007c454bbd4b69  jmp 0x00007C454BBD2B8B
00007c454bbd4b6e  sub rsp, 0x08
00007c454bbd4b72  push rax
00007c454bbd4b73  push rcx
00007c454bbd4b74  push rdx
00007c454bbd4b75  push rdi
00007c454bbd4b76  push rsi
00007c454bbd4b77  push r8
00007c454bbd4b79  push r9
00007c454bbd4b7b  push r10
00007c454bbd4b7d  push r11
00007c454bbd4b7f  sub rsp, 0xF0
00007c454bbd4b86  vmovaps [rsp], xmm0
00007c454bbd4b8b  vmovaps [rsp+0x10], xmm1
00007c454bbd4b91  vmovaps [rsp+0x20], xmm2
00007c454bbd4b97  vmovaps [rsp+0x30], xmm3
00007c454bbd4b9d  vmovaps [rsp+0x40], xmm4
00007c454bbd4ba3  vmovaps [rsp+0x50], xmm5
00007c454bbd4ba9  vmovaps [rsp+0x60], xmm6
00007c454bbd4baf  vmovaps [rsp+0x70], xmm7
00007c454bbd4bb5  vmovaps [rsp+0x80], xmm8
00007c454bbd4bbe  vmovaps [rsp+0x90], xmm9
00007c454bbd4bc7  vmovaps [rsp+0xA0], xmm10
00007c454bbd4bd0  vmovaps [rsp+0xB0], xmm11
00007c454bbd4bd9  vmovaps [rsp+0xC0], xmm12
00007c454bbd4be2  vmovaps [rsp+0xD0], xmm13
00007c454bbd4beb  vmovaps [rsp+0xE0], xmm14
00007c454bbd4bf4  sub rsp, 0x30
00007c454bbd4bf8  movaps [rsp], xmm15
00007c454bbd4bfd  movaps [rsp+0x10], xmm14
00007c454bbd4c03  movaps [rsp+0x20], xmm1
00007c454bbd4c08  lea rdi, [rsp]
00007c454bbd4c0c  mov esi, 0x00
00007c454bbd4c11  mov rax, 0x56A18AC54530
00007c454bbd4c1b  call rax
00007c454bbd4c1d  movaps xmm15, [rsp]
00007c454bbd4c22  add rsp, 0x30
00007c454bbd4c26  vmovaps xmm0, [rsp]
00007c454bbd4c2b  vmovaps xmm1, [rsp+0x10]
00007c454bbd4c31  vmovaps xmm2, [rsp+0x20]
00007c454bbd4c37  vmovaps xmm3, [rsp+0x30]
00007c454bbd4c3d  vmovaps xmm4, [rsp+0x40]
00007c454bbd4c43  vmovaps xmm5, [rsp+0x50]
00007c454bbd4c49  vmovaps xmm6, [rsp+0x60]
00007c454bbd4c4f  vmovaps xmm7, [rsp+0x70]
00007c454bbd4c55  vmovaps xmm8, [rsp+0x80]
00007c454bbd4c5e  vmovaps xmm9, [rsp+0x90]
00007c454bbd4c67  vmovaps xmm10, [rsp+0xA0]
00007c454bbd4c70  vmovaps xmm11, [rsp+0xB0]
00007c454bbd4c79  vmovaps xmm12, [rsp+0xC0]
00007c454bbd4c82  vmovaps xmm13, [rsp+0xD0]
00007c454bbd4c8b  vmovaps xmm14, [rsp+0xE0]
00007c454bbd4c94  add rsp, 0xF0
00007c454bbd4c9b  pop r11
00007c454bbd4c9d  pop r10
00007c454bbd4c9f  pop r9
00007c454bbd4ca1  pop r8
00007c454bbd4ca3  pop rsi
00007c454bbd4ca4  pop rdi
00007c454bbd4ca5  pop rdx
00007c454bbd4ca6  pop rcx
00007c454bbd4ca7  pop rax
00007c454bbd4ca8  add rsp, 0x08
00007c454bbd4cac  jmp 0x00007C454BBD2C05
00007c454bbd4cb1  call 0x00007C454B9FF430
00007c454bbd4cb6  jmp 0x00007C454BBD2C12
00007c454bbd4cbb  sub rsp, 0x08
00007c454bbd4cbf  push rax
00007c454bbd4cc0  push rcx
00007c454bbd4cc1  push rdx
00007c454bbd4cc2  push rdi
00007c454bbd4cc3  push rsi
00007c454bbd4cc4  push r8
00007c454bbd4cc6  push r9
00007c454bbd4cc8  push r10
00007c454bbd4cca  push r11
00007c454bbd4ccc  sub rsp, 0xF0
00007c454bbd4cd3  vmovaps [rsp], xmm0
00007c454bbd4cd8  vmovaps [rsp+0x10], xmm1
00007c454bbd4cde  vmovaps [rsp+0x20], xmm2
00007c454bbd4ce4  vmovaps [rsp+0x30], xmm3
00007c454bbd4cea  vmovaps [rsp+0x40], xmm4
00007c454bbd4cf0  vmovaps [rsp+0x50], xmm5
00007c454bbd4cf6  vmovaps [rsp+0x60], xmm6
00007c454bbd4cfc  vmovaps [rsp+0x70], xmm7
00007c454bbd4d02  vmovaps [rsp+0x80], xmm8
00007c454bbd4d0b  vmovaps [rsp+0x90], xmm9
00007c454bbd4d14  vmovaps [rsp+0xA0], xmm10
00007c454bbd4d1d  vmovaps [rsp+0xB0], xmm11
00007c454bbd4d26  vmovaps [rsp+0xC0], xmm12
00007c454bbd4d2f  vmovaps [rsp+0xD0], xmm14
00007c454bbd4d38  vmovaps [rsp+0xE0], xmm15
00007c454bbd4d41  sub rsp, 0x30
00007c454bbd4d45  movaps [rsp], xmm13
00007c454bbd4d4a  movaps [rsp+0x10], xmm1
00007c454bbd4d4f  movaps [rsp+0x20], xmm15
00007c454bbd4d55  lea rdi, [rsp]
00007c454bbd4d59  mov esi, 0x00
00007c454bbd4d5e  mov rax, 0x56A18AC54530
00007c454bbd4d68  call rax
00007c454bbd4d6a  movaps xmm13, [rsp]
00007c454bbd4d6f  add rsp, 0x30
00007c454bbd4d73  vmovaps xmm0, [rsp]
00007c454bbd4d78  vmovaps xmm1, [rsp+0x10]
00007c454bbd4d7e  vmovaps xmm2, [rsp+0x20]
00007c454bbd4d84  vmovaps xmm3, [rsp+0x30]
00007c454bbd4d8a  vmovaps xmm4, [rsp+0x40]
00007c454bbd4d90  vmovaps xmm5, [rsp+0x50]
00007c454bbd4d96  vmovaps xmm6, [rsp+0x60]
00007c454bbd4d9c  vmovaps xmm7, [rsp+0x70]
00007c454bbd4da2  vmovaps xmm8, [rsp+0x80]
00007c454bbd4dab  vmovaps xmm9, [rsp+0x90]
00007c454bbd4db4  vmovaps xmm10, [rsp+0xA0]
00007c454bbd4dbd  vmovaps xmm11, [rsp+0xB0]
00007c454bbd4dc6  vmovaps xmm12, [rsp+0xC0]
00007c454bbd4dcf  vmovaps xmm14, [rsp+0xD0]
00007c454bbd4dd8  vmovaps xmm15, [rsp+0xE0]
00007c454bbd4de1  add rsp, 0xF0
00007c454bbd4de8  pop r11
00007c454bbd4dea  pop r10
00007c454bbd4dec  pop r9
00007c454bbd4dee  pop r8
00007c454bbd4df0  pop rsi
00007c454bbd4df1  pop rdi
00007c454bbd4df2  pop rdx
00007c454bbd4df3  pop rcx
00007c454bbd4df4  pop rax
00007c454bbd4df5  add rsp, 0x08
00007c454bbd4df9  jmp 0x00007C454BBD2CD6
00007c454bbd4dfe  sub rsp, 0x08
00007c454bbd4e02  push rax
00007c454bbd4e03  push rcx
00007c454bbd4e04  push rdx
00007c454bbd4e05  push rdi
00007c454bbd4e06  push rsi
00007c454bbd4e07  push r8
00007c454bbd4e09  push r9
00007c454bbd4e0b  push r10
00007c454bbd4e0d  push r11
00007c454bbd4e0f  sub rsp, 0xF0
00007c454bbd4e16  vmovaps [rsp], xmm0
00007c454bbd4e1b  vmovaps [rsp+0x10], xmm1
00007c454bbd4e21  vmovaps [rsp+0x20], xmm2
00007c454bbd4e27  vmovaps [rsp+0x30], xmm3
00007c454bbd4e2d  vmovaps [rsp+0x40], xmm4
00007c454bbd4e33  vmovaps [rsp+0x50], xmm5
00007c454bbd4e39  vmovaps [rsp+0x60], xmm6
00007c454bbd4e3f  vmovaps [rsp+0x70], xmm7
00007c454bbd4e45  vmovaps [rsp+0x80], xmm8
00007c454bbd4e4e  vmovaps [rsp+0x90], xmm9
00007c454bbd4e57  vmovaps [rsp+0xA0], xmm10
00007c454bbd4e60  vmovaps [rsp+0xB0], xmm11
00007c454bbd4e69  vmovaps [rsp+0xC0], xmm12
00007c454bbd4e72  vmovaps [rsp+0xD0], xmm13
00007c454bbd4e7b  vmovaps [rsp+0xE0], xmm14
00007c454bbd4e84  sub rsp, 0x30
00007c454bbd4e88  movaps [rsp], xmm15
00007c454bbd4e8d  movaps [rsp+0x10], xmm14
00007c454bbd4e93  movaps [rsp+0x20], xmm1
00007c454bbd4e98  lea rdi, [rsp]
00007c454bbd4e9c  mov esi, 0x00
00007c454bbd4ea1  mov rax, 0x56A18AC54530
00007c454bbd4eab  call rax
00007c454bbd4ead  movaps xmm15, [rsp]
00007c454bbd4eb2  add rsp, 0x30
00007c454bbd4eb6  vmovaps xmm0, [rsp]
00007c454bbd4ebb  vmovaps xmm1, [rsp+0x10]
00007c454bbd4ec1  vmovaps xmm2, [rsp+0x20]
00007c454bbd4ec7  vmovaps xmm3, [rsp+0x30]
00007c454bbd4ecd  vmovaps xmm4, [rsp+0x40]
00007c454bbd4ed3  vmovaps xmm5, [rsp+0x50]
00007c454bbd4ed9  vmovaps xmm6, [rsp+0x60]
00007c454bbd4edf  vmovaps xmm7, [rsp+0x70]
00007c454bbd4ee5  vmovaps xmm8, [rsp+0x80]
00007c454bbd4eee  vmovaps xmm9, [rsp+0x90]
00007c454bbd4ef7  vmovaps xmm10, [rsp+0xA0]
00007c454bbd4f00  vmovaps xmm11, [rsp+0xB0]
00007c454bbd4f09  vmovaps xmm12, [rsp+0xC0]
00007c454bbd4f12  vmovaps xmm13, [rsp+0xD0]
00007c454bbd4f1b  vmovaps xmm14, [rsp+0xE0]
00007c454bbd4f24  add rsp, 0xF0
00007c454bbd4f2b  pop r11
00007c454bbd4f2d  pop r10
00007c454bbd4f2f  pop r9
00007c454bbd4f31  pop r8
00007c454bbd4f33  pop rsi
00007c454bbd4f34  pop rdi
00007c454bbd4f35  pop rdx
00007c454bbd4f36  pop rcx
00007c454bbd4f37  pop rax
00007c454bbd4f38  add rsp, 0x08
00007c454bbd4f3c  jmp 0x00007C454BBD2D12
00007c454bbd4f41  call 0x00007C454B9FF430
00007c454bbd4f46  jmp 0x00007C454BBD2D1F
00007c454bbd4f4b  sub rsp, 0x08
00007c454bbd4f4f  push rax
00007c454bbd4f50  push rcx
00007c454bbd4f51  push rdx
00007c454bbd4f52  push rdi
00007c454bbd4f53  push rsi
00007c454bbd4f54  push r8
00007c454bbd4f56  push r9
00007c454bbd4f58  push r10
00007c454bbd4f5a  push r11
00007c454bbd4f5c  sub rsp, 0xF0
00007c454bbd4f63  vmovaps [rsp], xmm0
00007c454bbd4f68  vmovaps [rsp+0x10], xmm1
00007c454bbd4f6e  vmovaps [rsp+0x20], xmm2
00007c454bbd4f74  vmovaps [rsp+0x30], xmm3
00007c454bbd4f7a  vmovaps [rsp+0x40], xmm4
00007c454bbd4f80  vmovaps [rsp+0x50], xmm5
00007c454bbd4f86  vmovaps [rsp+0x60], xmm6
00007c454bbd4f8c  vmovaps [rsp+0x70], xmm7
00007c454bbd4f92  vmovaps [rsp+0x80], xmm8
00007c454bbd4f9b  vmovaps [rsp+0x90], xmm9
00007c454bbd4fa4  vmovaps [rsp+0xA0], xmm10
00007c454bbd4fad  vmovaps [rsp+0xB0], xmm11
00007c454bbd4fb6  vmovaps [rsp+0xC0], xmm12
00007c454bbd4fbf  vmovaps [rsp+0xD0], xmm13
00007c454bbd4fc8  vmovaps [rsp+0xE0], xmm15
00007c454bbd4fd1  sub rsp, 0x30
00007c454bbd4fd5  movaps [rsp], xmm14
00007c454bbd4fda  movaps [rsp+0x10], xmm13
00007c454bbd4fe0  movaps [rsp+0x20], xmm2
00007c454bbd4fe5  lea rdi, [rsp]
00007c454bbd4fe9  mov esi, 0x00
00007c454bbd4fee  mov rax, 0x56A18AC54530
00007c454bbd4ff8  call rax
00007c454bbd4ffa  movaps xmm14, [rsp]
00007c454bbd4fff  add rsp, 0x30
00007c454bbd5003  vmovaps xmm0, [rsp]
00007c454bbd5008  vmovaps xmm1, [rsp+0x10]
00007c454bbd500e  vmovaps xmm2, [rsp+0x20]
00007c454bbd5014  vmovaps xmm3, [rsp+0x30]
00007c454bbd501a  vmovaps xmm4, [rsp+0x40]
00007c454bbd5020  vmovaps xmm5, [rsp+0x50]
00007c454bbd5026  vmovaps xmm6, [rsp+0x60]
00007c454bbd502c  vmovaps xmm7, [rsp+0x70]
00007c454bbd5032  vmovaps xmm8, [rsp+0x80]
00007c454bbd503b  vmovaps xmm9, [rsp+0x90]
00007c454bbd5044  vmovaps xmm10, [rsp+0xA0]
00007c454bbd504d  vmovaps xmm11, [rsp+0xB0]
00007c454bbd5056  vmovaps xmm12, [rsp+0xC0]
00007c454bbd505f  vmovaps xmm13, [rsp+0xD0]
00007c454bbd5068  vmovaps xmm15, [rsp+0xE0]
00007c454bbd5071  add rsp, 0xF0
00007c454bbd5078  pop r11
00007c454bbd507a  pop r10
00007c454bbd507c  pop r9
00007c454bbd507e  pop r8
00007c454bbd5080  pop rsi
00007c454bbd5081  pop rdi
00007c454bbd5082  pop rdx
00007c454bbd5083  pop rcx
00007c454bbd5084  pop rax
00007c454bbd5085  add rsp, 0x08
00007c454bbd5089  jmp 0x00007C454BBD2D4B
00007c454bbd508e  sub rsp, 0x08
00007c454bbd5092  push rax
00007c454bbd5093  push rcx
00007c454bbd5094  push rdx
00007c454bbd5095  push rdi
00007c454bbd5096  push rsi
00007c454bbd5097  push r8
00007c454bbd5099  push r9
00007c454bbd509b  push r10
00007c454bbd509d  push r11
00007c454bbd509f  sub rsp, 0xF0
00007c454bbd50a6  vmovaps [rsp], xmm0
00007c454bbd50ab  vmovaps [rsp+0x10], xmm2
00007c454bbd50b1  vmovaps [rsp+0x20], xmm3
00007c454bbd50b7  vmovaps [rsp+0x30], xmm4
00007c454bbd50bd  vmovaps [rsp+0x40], xmm5
00007c454bbd50c3  vmovaps [rsp+0x50], xmm6
00007c454bbd50c9  vmovaps [rsp+0x60], xmm7
00007c454bbd50cf  vmovaps [rsp+0x70], xmm8
00007c454bbd50d5  vmovaps [rsp+0x80], xmm9
00007c454bbd50de  vmovaps [rsp+0x90], xmm10
00007c454bbd50e7  vmovaps [rsp+0xA0], xmm11
00007c454bbd50f0  vmovaps [rsp+0xB0], xmm12
00007c454bbd50f9  vmovaps [rsp+0xC0], xmm13
00007c454bbd5102  vmovaps [rsp+0xD0], xmm14
00007c454bbd510b  vmovaps [rsp+0xE0], xmm15
00007c454bbd5114  sub rsp, 0x30
00007c454bbd5118  movaps [rsp], xmm1
00007c454bbd511c  movaps [rsp+0x10], xmm13
00007c454bbd5122  movaps [rsp+0x20], xmm2
00007c454bbd5127  lea rdi, [rsp]
00007c454bbd512b  mov esi, 0x00
00007c454bbd5130  mov rax, 0x56A18AC54530
00007c454bbd513a  call rax
00007c454bbd513c  movaps xmm1, [rsp]
00007c454bbd5140  add rsp, 0x30
00007c454bbd5144  vmovaps xmm0, [rsp]
00007c454bbd5149  vmovaps xmm2, [rsp+0x10]
00007c454bbd514f  vmovaps xmm3, [rsp+0x20]
00007c454bbd5155  vmovaps xmm4, [rsp+0x30]
00007c454bbd515b  vmovaps xmm5, [rsp+0x40]
00007c454bbd5161  vmovaps xmm6, [rsp+0x50]
00007c454bbd5167  vmovaps xmm7, [rsp+0x60]
00007c454bbd516d  vmovaps xmm8, [rsp+0x70]
00007c454bbd5173  vmovaps xmm9, [rsp+0x80]
00007c454bbd517c  vmovaps xmm10, [rsp+0x90]
00007c454bbd5185  vmovaps xmm11, [rsp+0xA0]
00007c454bbd518e  vmovaps xmm12, [rsp+0xB0]
00007c454bbd5197  vmovaps xmm13, [rsp+0xC0]
00007c454bbd51a0  vmovaps xmm14, [rsp+0xD0]
00007c454bbd51a9  vmovaps xmm15, [rsp+0xE0]
00007c454bbd51b2  add rsp, 0xF0
00007c454bbd51b9  pop r11
00007c454bbd51bb  pop r10
00007c454bbd51bd  pop r9
00007c454bbd51bf  pop r8
00007c454bbd51c1  pop rsi
00007c454bbd51c2  pop rdi
00007c454bbd51c3  pop rdx
00007c454bbd51c4  pop rcx
00007c454bbd51c5  pop rax
00007c454bbd51c6  add rsp, 0x08
00007c454bbd51ca  jmp 0x00007C454BBD2D79
00007c454bbd51cf  sub rsp, 0x08
00007c454bbd51d3  push rax
00007c454bbd51d4  push rcx
00007c454bbd51d5  push rdx
00007c454bbd51d6  push rdi
00007c454bbd51d7  push rsi
00007c454bbd51d8  push r8
00007c454bbd51da  push r9
00007c454bbd51dc  push r10
00007c454bbd51de  push r11
00007c454bbd51e0  sub rsp, 0xF0
00007c454bbd51e7  vmovaps [rsp], xmm0
00007c454bbd51ec  vmovaps [rsp+0x10], xmm1
00007c454bbd51f2  vmovaps [rsp+0x20], xmm3
00007c454bbd51f8  vmovaps [rsp+0x30], xmm4
00007c454bbd51fe  vmovaps [rsp+0x40], xmm5
00007c454bbd5204  vmovaps [rsp+0x50], xmm6
00007c454bbd520a  vmovaps [rsp+0x60], xmm7
00007c454bbd5210  vmovaps [rsp+0x70], xmm8
00007c454bbd5216  vmovaps [rsp+0x80], xmm9
00007c454bbd521f  vmovaps [rsp+0x90], xmm10
00007c454bbd5228  vmovaps [rsp+0xA0], xmm11
00007c454bbd5231  vmovaps [rsp+0xB0], xmm12
00007c454bbd523a  vmovaps [rsp+0xC0], xmm13
00007c454bbd5243  vmovaps [rsp+0xD0], xmm14
00007c454bbd524c  vmovaps [rsp+0xE0], xmm15
00007c454bbd5255  sub rsp, 0x30
00007c454bbd5259  movaps [rsp], xmm2
00007c454bbd525d  movaps [rsp+0x10], xmm1
00007c454bbd5262  movaps [rsp+0x20], xmm13
00007c454bbd5268  lea rdi, [rsp]
00007c454bbd526c  mov esi, 0x00
00007c454bbd5271  mov rax, 0x56A18AC54530
00007c454bbd527b  call rax
00007c454bbd527d  movaps xmm2, [rsp]
00007c454bbd5281  add rsp, 0x30
00007c454bbd5285  vmovaps xmm0, [rsp]
00007c454bbd528a  vmovaps xmm1, [rsp+0x10]
00007c454bbd5290  vmovaps xmm3, [rsp+0x20]
00007c454bbd5296  vmovaps xmm4, [rsp+0x30]
00007c454bbd529c  vmovaps xmm5, [rsp+0x40]
00007c454bbd52a2  vmovaps xmm6, [rsp+0x50]
00007c454bbd52a8  vmovaps xmm7, [rsp+0x60]
00007c454bbd52ae  vmovaps xmm8, [rsp+0x70]
00007c454bbd52b4  vmovaps xmm9, [rsp+0x80]
00007c454bbd52bd  vmovaps xmm10, [rsp+0x90]
00007c454bbd52c6  vmovaps xmm11, [rsp+0xA0]
00007c454bbd52cf  vmovaps xmm12, [rsp+0xB0]
00007c454bbd52d8  vmovaps xmm13, [rsp+0xC0]
00007c454bbd52e1  vmovaps xmm14, [rsp+0xD0]
00007c454bbd52ea  vmovaps xmm15, [rsp+0xE0]
00007c454bbd52f3  add rsp, 0xF0
00007c454bbd52fa  pop r11
00007c454bbd52fc  pop r10
00007c454bbd52fe  pop r9
00007c454bbd5300  pop r8
00007c454bbd5302  pop rsi
00007c454bbd5303  pop rdi
00007c454bbd5304  pop rdx
00007c454bbd5305  pop rcx
00007c454bbd5306  pop rax
00007c454bbd5307  add rsp, 0x08
00007c454bbd530b  jmp 0x00007C454BBD2DD2
00007c454bbd5310  call 0x00007C454B9FF430
00007c454bbd5315  jmp 0x00007C454BBD2DDF
00007c454bbd531a  sub rsp, 0x08
00007c454bbd531e  push rax
00007c454bbd531f  push rcx
00007c454bbd5320  push rdx
00007c454bbd5321  push rdi
00007c454bbd5322  push rsi
00007c454bbd5323  push r8
00007c454bbd5325  push r9
00007c454bbd5327  push r10
00007c454bbd5329  push r11
00007c454bbd532b  sub rsp, 0xF0
00007c454bbd5332  vmovaps [rsp], xmm0
00007c454bbd5337  vmovaps [rsp+0x10], xmm1
00007c454bbd533d  vmovaps [rsp+0x20], xmm2
00007c454bbd5343  vmovaps [rsp+0x30], xmm3
00007c454bbd5349  vmovaps [rsp+0x40], xmm4
00007c454bbd534f  vmovaps [rsp+0x50], xmm5
00007c454bbd5355  vmovaps [rsp+0x60], xmm6
00007c454bbd535b  vmovaps [rsp+0x70], xmm7
00007c454bbd5361  vmovaps [rsp+0x80], xmm8
00007c454bbd536a  vmovaps [rsp+0x90], xmm9
00007c454bbd5373  vmovaps [rsp+0xA0], xmm10
00007c454bbd537c  vmovaps [rsp+0xB0], xmm11
00007c454bbd5385  vmovaps [rsp+0xC0], xmm12
00007c454bbd538e  vmovaps [rsp+0xD0], xmm13
00007c454bbd5397  vmovaps [rsp+0xE0], xmm14
00007c454bbd53a0  sub rsp, 0x30
00007c454bbd53a4  movaps [rsp], xmm15
00007c454bbd53a9  movaps [rsp+0x10], xmm13
00007c454bbd53af  movaps [rsp+0x20], xmm1
00007c454bbd53b4  lea rdi, [rsp]
00007c454bbd53b8  mov esi, 0x00
00007c454bbd53bd  mov rax, 0x56A18AC54530
00007c454bbd53c7  call rax
00007c454bbd53c9  movaps xmm15, [rsp]
00007c454bbd53ce  add rsp, 0x30
00007c454bbd53d2  vmovaps xmm0, [rsp]
00007c454bbd53d7  vmovaps xmm1, [rsp+0x10]
00007c454bbd53dd  vmovaps xmm2, [rsp+0x20]
00007c454bbd53e3  vmovaps xmm3, [rsp+0x30]
00007c454bbd53e9  vmovaps xmm4, [rsp+0x40]
00007c454bbd53ef  vmovaps xmm5, [rsp+0x50]
00007c454bbd53f5  vmovaps xmm6, [rsp+0x60]
00007c454bbd53fb  vmovaps xmm7, [rsp+0x70]
00007c454bbd5401  vmovaps xmm8, [rsp+0x80]
00007c454bbd540a  vmovaps xmm9, [rsp+0x90]
00007c454bbd5413  vmovaps xmm10, [rsp+0xA0]
00007c454bbd541c  vmovaps xmm11, [rsp+0xB0]
00007c454bbd5425  vmovaps xmm12, [rsp+0xC0]
00007c454bbd542e  vmovaps xmm13, [rsp+0xD0]
00007c454bbd5437  vmovaps xmm14, [rsp+0xE0]
00007c454bbd5440  add rsp, 0xF0
00007c454bbd5447  pop r11
00007c454bbd5449  pop r10
00007c454bbd544b  pop r9
00007c454bbd544d  pop r8
00007c454bbd544f  pop rsi
00007c454bbd5450  pop rdi
00007c454bbd5451  pop rdx
00007c454bbd5452  pop rcx
00007c454bbd5453  pop rax
00007c454bbd5454  add rsp, 0x08
00007c454bbd5458  jmp 0x00007C454BBD2E1E
00007c454bbd545d  sub rsp, 0x08
00007c454bbd5461  push rax
00007c454bbd5462  push rcx
00007c454bbd5463  push rdx
00007c454bbd5464  push rdi
00007c454bbd5465  push rsi
00007c454bbd5466  push r8
00007c454bbd5468  push r9
00007c454bbd546a  push r10
00007c454bbd546c  push r11
00007c454bbd546e  sub rsp, 0xF0
00007c454bbd5475  vmovaps [rsp], xmm0
00007c454bbd547a  vmovaps [rsp+0x10], xmm1
00007c454bbd5480  vmovaps [rsp+0x20], xmm2
00007c454bbd5486  vmovaps [rsp+0x30], xmm3
00007c454bbd548c  vmovaps [rsp+0x40], xmm4
00007c454bbd5492  vmovaps [rsp+0x50], xmm5
00007c454bbd5498  vmovaps [rsp+0x60], xmm6
00007c454bbd549e  vmovaps [rsp+0x70], xmm7
00007c454bbd54a4  vmovaps [rsp+0x80], xmm8
00007c454bbd54ad  vmovaps [rsp+0x90], xmm9
00007c454bbd54b6  vmovaps [rsp+0xA0], xmm10
00007c454bbd54bf  vmovaps [rsp+0xB0], xmm11
00007c454bbd54c8  vmovaps [rsp+0xC0], xmm12
00007c454bbd54d1  vmovaps [rsp+0xD0], xmm13
00007c454bbd54da  vmovaps [rsp+0xE0], xmm15
00007c454bbd54e3  sub rsp, 0x30
00007c454bbd54e7  movaps [rsp], xmm14
00007c454bbd54ec  movaps [rsp+0x10], xmm11
00007c454bbd54f2  movaps [rsp+0x20], xmm1
00007c454bbd54f7  lea rdi, [rsp]
00007c454bbd54fb  mov esi, 0x00
00007c454bbd5500  mov rax, 0x56A18AC54530
00007c454bbd550a  call rax
00007c454bbd550c  movaps xmm14, [rsp]
00007c454bbd5511  add rsp, 0x30
00007c454bbd5515  vmovaps xmm0, [rsp]
00007c454bbd551a  vmovaps xmm1, [rsp+0x10]
00007c454bbd5520  vmovaps xmm2, [rsp+0x20]
00007c454bbd5526  vmovaps xmm3, [rsp+0x30]
00007c454bbd552c  vmovaps xmm4, [rsp+0x40]
00007c454bbd5532  vmovaps xmm5, [rsp+0x50]
00007c454bbd5538  vmovaps xmm6, [rsp+0x60]
00007c454bbd553e  vmovaps xmm7, [rsp+0x70]
00007c454bbd5544  vmovaps xmm8, [rsp+0x80]
00007c454bbd554d  vmovaps xmm9, [rsp+0x90]
00007c454bbd5556  vmovaps xmm10, [rsp+0xA0]
00007c454bbd555f  vmovaps xmm11, [rsp+0xB0]
00007c454bbd5568  vmovaps xmm12, [rsp+0xC0]
00007c454bbd5571  vmovaps xmm13, [rsp+0xD0]
00007c454bbd557a  vmovaps xmm15, [rsp+0xE0]
00007c454bbd5583  add rsp, 0xF0
00007c454bbd558a  pop r11
00007c454bbd558c  pop r10
00007c454bbd558e  pop r9
00007c454bbd5590  pop r8
00007c454bbd5592  pop rsi
00007c454bbd5593  pop rdi
00007c454bbd5594  pop rdx
00007c454bbd5595  pop rcx
00007c454bbd5596  pop rax
00007c454bbd5597  add rsp, 0x08
00007c454bbd559b  jmp 0x00007C454BBD2E48
00007c454bbd55a0  sub rsp, 0x08
00007c454bbd55a4  push rax
00007c454bbd55a5  push rcx
00007c454bbd55a6  push rdx
00007c454bbd55a7  push rdi
00007c454bbd55a8  push rsi
00007c454bbd55a9  push r8
00007c454bbd55ab  push r9
00007c454bbd55ad  push r10
00007c454bbd55af  push r11
00007c454bbd55b1  sub rsp, 0xF0
00007c454bbd55b8  vmovaps [rsp], xmm0
00007c454bbd55bd  vmovaps [rsp+0x10], xmm1
00007c454bbd55c3  vmovaps [rsp+0x20], xmm2
00007c454bbd55c9  vmovaps [rsp+0x30], xmm3
00007c454bbd55cf  vmovaps [rsp+0x40], xmm4
00007c454bbd55d5  vmovaps [rsp+0x50], xmm5
00007c454bbd55db  vmovaps [rsp+0x60], xmm6
00007c454bbd55e1  vmovaps [rsp+0x70], xmm7
00007c454bbd55e7  vmovaps [rsp+0x80], xmm8
00007c454bbd55f0  vmovaps [rsp+0x90], xmm9
00007c454bbd55f9  vmovaps [rsp+0xA0], xmm10
00007c454bbd5602  vmovaps [rsp+0xB0], xmm11
00007c454bbd560b  vmovaps [rsp+0xC0], xmm12
00007c454bbd5614  vmovaps [rsp+0xD0], xmm14
00007c454bbd561d  vmovaps [rsp+0xE0], xmm15
00007c454bbd5626  sub rsp, 0x30
00007c454bbd562a  movaps [rsp], xmm13
00007c454bbd562f  movaps [rsp+0x10], xmm11
00007c454bbd5635  movaps [rsp+0x20], xmm1
00007c454bbd563a  lea rdi, [rsp]
00007c454bbd563e  mov esi, 0x00
00007c454bbd5643  mov rax, 0x56A18AC54530
00007c454bbd564d  call rax
00007c454bbd564f  movaps xmm13, [rsp]
00007c454bbd5654  add rsp, 0x30
00007c454bbd5658  vmovaps xmm0, [rsp]
00007c454bbd565d  vmovaps xmm1, [rsp+0x10]
00007c454bbd5663  vmovaps xmm2, [rsp+0x20]
00007c454bbd5669  vmovaps xmm3, [rsp+0x30]
00007c454bbd566f  vmovaps xmm4, [rsp+0x40]
00007c454bbd5675  vmovaps xmm5, [rsp+0x50]
00007c454bbd567b  vmovaps xmm6, [rsp+0x60]
00007c454bbd5681  vmovaps xmm7, [rsp+0x70]
00007c454bbd5687  vmovaps xmm8, [rsp+0x80]
00007c454bbd5690  vmovaps xmm9, [rsp+0x90]
00007c454bbd5699  vmovaps xmm10, [rsp+0xA0]
00007c454bbd56a2  vmovaps xmm11, [rsp+0xB0]
00007c454bbd56ab  vmovaps xmm12, [rsp+0xC0]
00007c454bbd56b4  vmovaps xmm14, [rsp+0xD0]
00007c454bbd56bd  vmovaps xmm15, [rsp+0xE0]
00007c454bbd56c6  add rsp, 0xF0
00007c454bbd56cd  pop r11
00007c454bbd56cf  pop r10
00007c454bbd56d1  pop r9
00007c454bbd56d3  pop r8
00007c454bbd56d5  pop rsi
00007c454bbd56d6  pop rdi
00007c454bbd56d7  pop rdx
00007c454bbd56d8  pop rcx
00007c454bbd56d9  pop rax
00007c454bbd56da  add rsp, 0x08
00007c454bbd56de  jmp 0x00007C454BBD2E9D
00007c454bbd56e3  call 0x00007C454B9FF430
00007c454bbd56e8  jmp 0x00007C454BBD2EAA
00007c454bbd56ed  sub rsp, 0x08
00007c454bbd56f1  push rax
00007c454bbd56f2  push rcx
00007c454bbd56f3  push rdx
00007c454bbd56f4  push rdi
00007c454bbd56f5  push rsi
00007c454bbd56f6  push r8
00007c454bbd56f8  push r9
00007c454bbd56fa  push r10
00007c454bbd56fc  push r11
00007c454bbd56fe  sub rsp, 0xF0
00007c454bbd5705  vmovaps [rsp], xmm0
00007c454bbd570a  vmovaps [rsp+0x10], xmm1
00007c454bbd5710  vmovaps [rsp+0x20], xmm2
00007c454bbd5716  vmovaps [rsp+0x30], xmm3
00007c454bbd571c  vmovaps [rsp+0x40], xmm4
00007c454bbd5722  vmovaps [rsp+0x50], xmm5
00007c454bbd5728  vmovaps [rsp+0x60], xmm6
00007c454bbd572e  vmovaps [rsp+0x70], xmm7
00007c454bbd5734  vmovaps [rsp+0x80], xmm8
00007c454bbd573d  vmovaps [rsp+0x90], xmm9
00007c454bbd5746  vmovaps [rsp+0xA0], xmm10
00007c454bbd574f  vmovaps [rsp+0xB0], xmm11
00007c454bbd5758  vmovaps [rsp+0xC0], xmm12
00007c454bbd5761  vmovaps [rsp+0xD0], xmm13
00007c454bbd576a  vmovaps [rsp+0xE0], xmm14
00007c454bbd5773  sub rsp, 0x30
00007c454bbd5777  movaps [rsp], xmm15
00007c454bbd577c  movaps [rsp+0x10], xmm11
00007c454bbd5782  movaps [rsp+0x20], xmm1
00007c454bbd5787  lea rdi, [rsp]
00007c454bbd578b  mov esi, 0x00
00007c454bbd5790  mov rax, 0x56A18AC54530
00007c454bbd579a  call rax
00007c454bbd579c  movaps xmm15, [rsp]
00007c454bbd57a1  add rsp, 0x30
00007c454bbd57a5  vmovaps xmm0, [rsp]
00007c454bbd57aa  vmovaps xmm1, [rsp+0x10]
00007c454bbd57b0  vmovaps xmm2, [rsp+0x20]
00007c454bbd57b6  vmovaps xmm3, [rsp+0x30]
00007c454bbd57bc  vmovaps xmm4, [rsp+0x40]
00007c454bbd57c2  vmovaps xmm5, [rsp+0x50]
00007c454bbd57c8  vmovaps xmm6, [rsp+0x60]
00007c454bbd57ce  vmovaps xmm7, [rsp+0x70]
00007c454bbd57d4  vmovaps xmm8, [rsp+0x80]
00007c454bbd57dd  vmovaps xmm9, [rsp+0x90]
00007c454bbd57e6  vmovaps xmm10, [rsp+0xA0]
00007c454bbd57ef  vmovaps xmm11, [rsp+0xB0]
00007c454bbd57f8  vmovaps xmm12, [rsp+0xC0]
00007c454bbd5801  vmovaps xmm13, [rsp+0xD0]
00007c454bbd580a  vmovaps xmm14, [rsp+0xE0]
00007c454bbd5813  add rsp, 0xF0
00007c454bbd581a  pop r11
00007c454bbd581c  pop r10
00007c454bbd581e  pop r9
00007c454bbd5820  pop r8
00007c454bbd5822  pop rsi
00007c454bbd5823  pop rdi
00007c454bbd5824  pop rdx
00007c454bbd5825  pop rcx
00007c454bbd5826  pop rax
00007c454bbd5827  add rsp, 0x08
00007c454bbd582b  jmp 0x00007C454BBD2EE3
00007c454bbd5830  sub rsp, 0x08
00007c454bbd5834  push rax
00007c454bbd5835  push rcx
00007c454bbd5836  push rdx
00007c454bbd5837  push rdi
00007c454bbd5838  push rsi
00007c454bbd5839  push r8
00007c454bbd583b  push r9
00007c454bbd583d  push r10
00007c454bbd583f  push r11
00007c454bbd5841  sub rsp, 0xF0
00007c454bbd5848  vmovaps [rsp], xmm0
00007c454bbd584d  vmovaps [rsp+0x10], xmm1
00007c454bbd5853  vmovaps [rsp+0x20], xmm2
00007c454bbd5859  vmovaps [rsp+0x30], xmm3
00007c454bbd585f  vmovaps [rsp+0x40], xmm4
00007c454bbd5865  vmovaps [rsp+0x50], xmm5
00007c454bbd586b  vmovaps [rsp+0x60], xmm6
00007c454bbd5871  vmovaps [rsp+0x70], xmm7
00007c454bbd5877  vmovaps [rsp+0x80], xmm8
00007c454bbd5880  vmovaps [rsp+0x90], xmm9
00007c454bbd5889  vmovaps [rsp+0xA0], xmm10
00007c454bbd5892  vmovaps [rsp+0xB0], xmm12
00007c454bbd589b  vmovaps [rsp+0xC0], xmm13
00007c454bbd58a4  vmovaps [rsp+0xD0], xmm14
00007c454bbd58ad  vmovaps [rsp+0xE0], xmm15
00007c454bbd58b6  sub rsp, 0x30
00007c454bbd58ba  movaps [rsp], xmm11
00007c454bbd58bf  movaps [rsp+0x10], xmm6
00007c454bbd58c4  movaps [rsp+0x20], xmm14
00007c454bbd58ca  lea rdi, [rsp]
00007c454bbd58ce  mov esi, 0x00
00007c454bbd58d3  mov rax, 0x56A18AC54530
00007c454bbd58dd  call rax
00007c454bbd58df  movaps xmm11, [rsp]
00007c454bbd58e4  add rsp, 0x30
00007c454bbd58e8  vmovaps xmm0, [rsp]
00007c454bbd58ed  vmovaps xmm1, [rsp+0x10]
00007c454bbd58f3  vmovaps xmm2, [rsp+0x20]
00007c454bbd58f9  vmovaps xmm3, [rsp+0x30]
00007c454bbd58ff  vmovaps xmm4, [rsp+0x40]
00007c454bbd5905  vmovaps xmm5, [rsp+0x50]
00007c454bbd590b  vmovaps xmm6, [rsp+0x60]
00007c454bbd5911  vmovaps xmm7, [rsp+0x70]
00007c454bbd5917  vmovaps xmm8, [rsp+0x80]
00007c454bbd5920  vmovaps xmm9, [rsp+0x90]
00007c454bbd5929  vmovaps xmm10, [rsp+0xA0]
00007c454bbd5932  vmovaps xmm12, [rsp+0xB0]
00007c454bbd593b  vmovaps xmm13, [rsp+0xC0]
00007c454bbd5944  vmovaps xmm14, [rsp+0xD0]
00007c454bbd594d  vmovaps xmm15, [rsp+0xE0]
00007c454bbd5956  add rsp, 0xF0
00007c454bbd595d  pop r11
00007c454bbd595f  pop r10
00007c454bbd5961  pop r9
00007c454bbd5963  pop r8
00007c454bbd5965  pop rsi
00007c454bbd5966  pop rdi
00007c454bbd5967  pop rdx
00007c454bbd5968  pop rcx
00007c454bbd5969  pop rax
00007c454bbd596a  add rsp, 0x08
00007c454bbd596e  jmp 0x00007C454BBD2F5B
00007c454bbd5973  call 0x00007C454B9FF430
00007c454bbd5978  jmp 0x00007C454BBD2F65
00007c454bbd597d  sub rsp, 0x08
00007c454bbd5981  push rax
00007c454bbd5982  push rcx
00007c454bbd5983  push rdx
00007c454bbd5984  push rdi
00007c454bbd5985  push rsi
00007c454bbd5986  push r8
00007c454bbd5988  push r9
00007c454bbd598a  push r10
00007c454bbd598c  push r11
00007c454bbd598e  sub rsp, 0xF0
00007c454bbd5995  vmovaps [rsp], xmm0
00007c454bbd599a  vmovaps [rsp+0x10], xmm1
00007c454bbd59a0  vmovaps [rsp+0x20], xmm2
00007c454bbd59a6  vmovaps [rsp+0x30], xmm3
00007c454bbd59ac  vmovaps [rsp+0x40], xmm4
00007c454bbd59b2  vmovaps [rsp+0x50], xmm5
00007c454bbd59b8  vmovaps [rsp+0x60], xmm6
00007c454bbd59be  vmovaps [rsp+0x70], xmm7
00007c454bbd59c4  vmovaps [rsp+0x80], xmm8
00007c454bbd59cd  vmovaps [rsp+0x90], xmm9
00007c454bbd59d6  vmovaps [rsp+0xA0], xmm10
00007c454bbd59df  vmovaps [rsp+0xB0], xmm11
00007c454bbd59e8  vmovaps [rsp+0xC0], xmm12
00007c454bbd59f1  vmovaps [rsp+0xD0], xmm13
00007c454bbd59fa  vmovaps [rsp+0xE0], xmm15
00007c454bbd5a03  sub rsp, 0x30
00007c454bbd5a07  movaps [rsp], xmm14
00007c454bbd5a0c  movaps [rsp+0x10], xmm6
00007c454bbd5a11  movaps [rsp+0x20], xmm2
00007c454bbd5a16  lea rdi, [rsp]
00007c454bbd5a1a  mov esi, 0x00
00007c454bbd5a1f  mov rax, 0x56A18AC54530
00007c454bbd5a29  call rax
00007c454bbd5a2b  movaps xmm14, [rsp]
00007c454bbd5a30  add rsp, 0x30
00007c454bbd5a34  vmovaps xmm0, [rsp]
00007c454bbd5a39  vmovaps xmm1, [rsp+0x10]
00007c454bbd5a3f  vmovaps xmm2, [rsp+0x20]
00007c454bbd5a45  vmovaps xmm3, [rsp+0x30]
00007c454bbd5a4b  vmovaps xmm4, [rsp+0x40]
00007c454bbd5a51  vmovaps xmm5, [rsp+0x50]
00007c454bbd5a57  vmovaps xmm6, [rsp+0x60]
00007c454bbd5a5d  vmovaps xmm7, [rsp+0x70]
00007c454bbd5a63  vmovaps xmm8, [rsp+0x80]
00007c454bbd5a6c  vmovaps xmm9, [rsp+0x90]
00007c454bbd5a75  vmovaps xmm10, [rsp+0xA0]
00007c454bbd5a7e  vmovaps xmm11, [rsp+0xB0]
00007c454bbd5a87  vmovaps xmm12, [rsp+0xC0]
00007c454bbd5a90  vmovaps xmm13, [rsp+0xD0]
00007c454bbd5a99  vmovaps xmm15, [rsp+0xE0]
00007c454bbd5aa2  add rsp, 0xF0
00007c454bbd5aa9  pop r11
00007c454bbd5aab  pop r10
00007c454bbd5aad  pop r9
00007c454bbd5aaf  pop r8
00007c454bbd5ab1  pop rsi
00007c454bbd5ab2  pop rdi
00007c454bbd5ab3  pop rdx
00007c454bbd5ab4  pop rcx
00007c454bbd5ab5  pop rax
00007c454bbd5ab6  add rsp, 0x08
00007c454bbd5aba  jmp 0x00007C454BBD2F99
00007c454bbd5abf  sub rsp, 0x08
00007c454bbd5ac3  push rax
00007c454bbd5ac4  push rcx
00007c454bbd5ac5  push rdx
00007c454bbd5ac6  push rdi
00007c454bbd5ac7  push rsi
00007c454bbd5ac8  push r8
00007c454bbd5aca  push r9
00007c454bbd5acc  push r10
00007c454bbd5ace  push r11
00007c454bbd5ad0  sub rsp, 0xF0
00007c454bbd5ad7  vmovaps [rsp], xmm0
00007c454bbd5adc  vmovaps [rsp+0x10], xmm1
00007c454bbd5ae2  vmovaps [rsp+0x20], xmm2
00007c454bbd5ae8  vmovaps [rsp+0x30], xmm3
00007c454bbd5aee  vmovaps [rsp+0x40], xmm4
00007c454bbd5af4  vmovaps [rsp+0x50], xmm5
00007c454bbd5afa  vmovaps [rsp+0x60], xmm7
00007c454bbd5b00  vmovaps [rsp+0x70], xmm8
00007c454bbd5b06  vmovaps [rsp+0x80], xmm9
00007c454bbd5b0f  vmovaps [rsp+0x90], xmm10
00007c454bbd5b18  vmovaps [rsp+0xA0], xmm11
00007c454bbd5b21  vmovaps [rsp+0xB0], xmm12
00007c454bbd5b2a  vmovaps [rsp+0xC0], xmm13
00007c454bbd5b33  vmovaps [rsp+0xD0], xmm14
00007c454bbd5b3c  vmovaps [rsp+0xE0], xmm15
00007c454bbd5b45  sub rsp, 0x30
00007c454bbd5b49  movaps [rsp], xmm6
00007c454bbd5b4d  movaps [rsp+0x10], xmm5
00007c454bbd5b52  movaps [rsp+0x20], xmm1
00007c454bbd5b57  lea rdi, [rsp]
00007c454bbd5b5b  mov esi, 0x00
00007c454bbd5b60  mov rax, 0x56A18AC54530
00007c454bbd5b6a  call rax
00007c454bbd5b6c  movaps xmm6, [rsp]
00007c454bbd5b70  add rsp, 0x30
00007c454bbd5b74  vmovaps xmm0, [rsp]
00007c454bbd5b79  vmovaps xmm1, [rsp+0x10]
00007c454bbd5b7f  vmovaps xmm2, [rsp+0x20]
00007c454bbd5b85  vmovaps xmm3, [rsp+0x30]
00007c454bbd5b8b  vmovaps xmm4, [rsp+0x40]
00007c454bbd5b91  vmovaps xmm5, [rsp+0x50]
00007c454bbd5b97  vmovaps xmm7, [rsp+0x60]
00007c454bbd5b9d  vmovaps xmm8, [rsp+0x70]
00007c454bbd5ba3  vmovaps xmm9, [rsp+0x80]
00007c454bbd5bac  vmovaps xmm10, [rsp+0x90]
00007c454bbd5bb5  vmovaps xmm11, [rsp+0xA0]
00007c454bbd5bbe  vmovaps xmm12, [rsp+0xB0]
00007c454bbd5bc7  vmovaps xmm13, [rsp+0xC0]
00007c454bbd5bd0  vmovaps xmm14, [rsp+0xD0]
00007c454bbd5bd9  vmovaps xmm15, [rsp+0xE0]
00007c454bbd5be2  add rsp, 0xF0
00007c454bbd5be9  pop r11
00007c454bbd5beb  pop r10
00007c454bbd5bed  pop r9
00007c454bbd5bef  pop r8
00007c454bbd5bf1  pop rsi
00007c454bbd5bf2  pop rdi
00007c454bbd5bf3  pop rdx
00007c454bbd5bf4  pop rcx
00007c454bbd5bf5  pop rax
00007c454bbd5bf6  add rsp, 0x08
00007c454bbd5bfa  jmp 0x00007C454BBD2FBF
00007c454bbd5bff  sub rsp, 0x08
00007c454bbd5c03  push rax
00007c454bbd5c04  push rcx
00007c454bbd5c05  push rdx
00007c454bbd5c06  push rdi
00007c454bbd5c07  push rsi
00007c454bbd5c08  push r8
00007c454bbd5c0a  push r9
00007c454bbd5c0c  push r10
00007c454bbd5c0e  push r11
00007c454bbd5c10  sub rsp, 0xF0
00007c454bbd5c17  vmovaps [rsp], xmm0
00007c454bbd5c1c  vmovaps [rsp+0x10], xmm2
00007c454bbd5c22  vmovaps [rsp+0x20], xmm3
00007c454bbd5c28  vmovaps [rsp+0x30], xmm4
00007c454bbd5c2e  vmovaps [rsp+0x40], xmm5
00007c454bbd5c34  vmovaps [rsp+0x50], xmm6
00007c454bbd5c3a  vmovaps [rsp+0x60], xmm7
00007c454bbd5c40  vmovaps [rsp+0x70], xmm8
00007c454bbd5c46  vmovaps [rsp+0x80], xmm9
00007c454bbd5c4f  vmovaps [rsp+0x90], xmm10
00007c454bbd5c58  vmovaps [rsp+0xA0], xmm11
00007c454bbd5c61  vmovaps [rsp+0xB0], xmm12
00007c454bbd5c6a  vmovaps [rsp+0xC0], xmm13
00007c454bbd5c73  vmovaps [rsp+0xD0], xmm14
00007c454bbd5c7c  vmovaps [rsp+0xE0], xmm15
00007c454bbd5c85  sub rsp, 0x30
00007c454bbd5c89  movaps [rsp], xmm1
00007c454bbd5c8d  movaps [rsp+0x10], xmm5
00007c454bbd5c92  movaps [rsp+0x20], xmm13
00007c454bbd5c98  lea rdi, [rsp]
00007c454bbd5c9c  mov esi, 0x00
00007c454bbd5ca1  mov rax, 0x56A18AC54530
00007c454bbd5cab  call rax
00007c454bbd5cad  movaps xmm1, [rsp]
00007c454bbd5cb1  add rsp, 0x30
00007c454bbd5cb5  vmovaps xmm0, [rsp]
00007c454bbd5cba  vmovaps xmm2, [rsp+0x10]
00007c454bbd5cc0  vmovaps xmm3, [rsp+0x20]
00007c454bbd5cc6  vmovaps xmm4, [rsp+0x30]
00007c454bbd5ccc  vmovaps xmm5, [rsp+0x40]
00007c454bbd5cd2  vmovaps xmm6, [rsp+0x50]
00007c454bbd5cd8  vmovaps xmm7, [rsp+0x60]
00007c454bbd5cde  vmovaps xmm8, [rsp+0x70]
00007c454bbd5ce4  vmovaps xmm9, [rsp+0x80]
00007c454bbd5ced  vmovaps xmm10, [rsp+0x90]
00007c454bbd5cf6  vmovaps xmm11, [rsp+0xA0]
00007c454bbd5cff  vmovaps xmm12, [rsp+0xB0]
00007c454bbd5d08  vmovaps xmm13, [rsp+0xC0]
00007c454bbd5d11  vmovaps xmm14, [rsp+0xD0]
00007c454bbd5d1a  vmovaps xmm15, [rsp+0xE0]
00007c454bbd5d23  add rsp, 0xF0
00007c454bbd5d2a  pop r11
00007c454bbd5d2c  pop r10
00007c454bbd5d2e  pop r9
00007c454bbd5d30  pop r8
00007c454bbd5d32  pop rsi
00007c454bbd5d33  pop rdi
00007c454bbd5d34  pop rdx
00007c454bbd5d35  pop rcx
00007c454bbd5d36  pop rax
00007c454bbd5d37  add rsp, 0x08
00007c454bbd5d3b  jmp 0x00007C454BBD2FDD
00007c454bbd5d40  sub rsp, 0x08
00007c454bbd5d44  push rax
00007c454bbd5d45  push rcx
00007c454bbd5d46  push rdx
00007c454bbd5d47  push rdi
00007c454bbd5d48  push rsi
00007c454bbd5d49  push r8
00007c454bbd5d4b  push r9
00007c454bbd5d4d  push r10
00007c454bbd5d4f  push r11
00007c454bbd5d51  sub rsp, 0xF0
00007c454bbd5d58  vmovaps [rsp], xmm0
00007c454bbd5d5d  vmovaps [rsp+0x10], xmm1
00007c454bbd5d63  vmovaps [rsp+0x20], xmm2
00007c454bbd5d69  vmovaps [rsp+0x30], xmm3
00007c454bbd5d6f  vmovaps [rsp+0x40], xmm4
00007c454bbd5d75  vmovaps [rsp+0x50], xmm6
00007c454bbd5d7b  vmovaps [rsp+0x60], xmm7
00007c454bbd5d81  vmovaps [rsp+0x70], xmm8
00007c454bbd5d87  vmovaps [rsp+0x80], xmm9
00007c454bbd5d90  vmovaps [rsp+0x90], xmm10
00007c454bbd5d99  vmovaps [rsp+0xA0], xmm11
00007c454bbd5da2  vmovaps [rsp+0xB0], xmm12
00007c454bbd5dab  vmovaps [rsp+0xC0], xmm13
00007c454bbd5db4  vmovaps [rsp+0xD0], xmm14
00007c454bbd5dbd  vmovaps [rsp+0xE0], xmm15
00007c454bbd5dc6  sub rsp, 0x30
00007c454bbd5dca  movaps [rsp], xmm5
00007c454bbd5dce  movaps [rsp+0x10], xmm2
00007c454bbd5dd3  movaps [rsp+0x20], xmm13
00007c454bbd5dd9  lea rdi, [rsp]
00007c454bbd5ddd  mov esi, 0x00
00007c454bbd5de2  mov rax, 0x56A18AC54530
00007c454bbd5dec  call rax
00007c454bbd5dee  movaps xmm5, [rsp]
00007c454bbd5df2  add rsp, 0x30
00007c454bbd5df6  vmovaps xmm0, [rsp]
00007c454bbd5dfb  vmovaps xmm1, [rsp+0x10]
00007c454bbd5e01  vmovaps xmm2, [rsp+0x20]
00007c454bbd5e07  vmovaps xmm3, [rsp+0x30]
00007c454bbd5e0d  vmovaps xmm4, [rsp+0x40]
00007c454bbd5e13  vmovaps xmm6, [rsp+0x50]
00007c454bbd5e19  vmovaps xmm7, [rsp+0x60]
00007c454bbd5e1f  vmovaps xmm8, [rsp+0x70]
00007c454bbd5e25  vmovaps xmm9, [rsp+0x80]
00007c454bbd5e2e  vmovaps xmm10, [rsp+0x90]
00007c454bbd5e37  vmovaps xmm11, [rsp+0xA0]
00007c454bbd5e40  vmovaps xmm12, [rsp+0xB0]
00007c454bbd5e49  vmovaps xmm13, [rsp+0xC0]
00007c454bbd5e52  vmovaps xmm14, [rsp+0xD0]
00007c454bbd5e5b  vmovaps xmm15, [rsp+0xE0]
00007c454bbd5e64  add rsp, 0xF0
00007c454bbd5e6b  pop r11
00007c454bbd5e6d  pop r10
00007c454bbd5e6f  pop r9
00007c454bbd5e71  pop r8
00007c454bbd5e73  pop rsi
00007c454bbd5e74  pop rdi
00007c454bbd5e75  pop rdx
00007c454bbd5e76  pop rcx
00007c454bbd5e77  pop rax
00007c454bbd5e78  add rsp, 0x08
00007c454bbd5e7c  jmp 0x00007C454BBD3013
00007c454bbd5e81  sub rsp, 0x08
00007c454bbd5e85  push rax
00007c454bbd5e86  push rcx
00007c454bbd5e87  push rdx
00007c454bbd5e88  push rdi
00007c454bbd5e89  push rsi
00007c454bbd5e8a  push r8
00007c454bbd5e8c  push r9
00007c454bbd5e8e  push r10
00007c454bbd5e90  push r11
00007c454bbd5e92  sub rsp, 0xF0
00007c454bbd5e99  vmovaps [rsp], xmm0
00007c454bbd5e9e  vmovaps [rsp+0x10], xmm1
00007c454bbd5ea4  vmovaps [rsp+0x20], xmm2
00007c454bbd5eaa  vmovaps [rsp+0x30], xmm3
00007c454bbd5eb0  vmovaps [rsp+0x40], xmm4
00007c454bbd5eb6  vmovaps [rsp+0x50], xmm5
00007c454bbd5ebc  vmovaps [rsp+0x60], xmm6
00007c454bbd5ec2  vmovaps [rsp+0x70], xmm7
00007c454bbd5ec8  vmovaps [rsp+0x80], xmm8
00007c454bbd5ed1  vmovaps [rsp+0x90], xmm9
00007c454bbd5eda  vmovaps [rsp+0xA0], xmm10
00007c454bbd5ee3  vmovaps [rsp+0xB0], xmm11
00007c454bbd5eec  vmovaps [rsp+0xC0], xmm12
00007c454bbd5ef5  vmovaps [rsp+0xD0], xmm14
00007c454bbd5efe  vmovaps [rsp+0xE0], xmm15
00007c454bbd5f07  sub rsp, 0x30
00007c454bbd5f0b  movaps [rsp], xmm13
00007c454bbd5f10  movaps [rsp+0x10], xmm10
00007c454bbd5f16  movaps [rsp+0x20], xmm1
00007c454bbd5f1b  lea rdi, [rsp]
00007c454bbd5f1f  mov esi, 0x00
00007c454bbd5f24  mov rax, 0x56A18AC54530
00007c454bbd5f2e  call rax
00007c454bbd5f30  movaps xmm13, [rsp]
00007c454bbd5f35  add rsp, 0x30
00007c454bbd5f39  vmovaps xmm0, [rsp]
00007c454bbd5f3e  vmovaps xmm1, [rsp+0x10]
00007c454bbd5f44  vmovaps xmm2, [rsp+0x20]
00007c454bbd5f4a  vmovaps xmm3, [rsp+0x30]
00007c454bbd5f50  vmovaps xmm4, [rsp+0x40]
00007c454bbd5f56  vmovaps xmm5, [rsp+0x50]
00007c454bbd5f5c  vmovaps xmm6, [rsp+0x60]
00007c454bbd5f62  vmovaps xmm7, [rsp+0x70]
00007c454bbd5f68  vmovaps xmm8, [rsp+0x80]
00007c454bbd5f71  vmovaps xmm9, [rsp+0x90]
00007c454bbd5f7a  vmovaps xmm10, [rsp+0xA0]
00007c454bbd5f83  vmovaps xmm11, [rsp+0xB0]
00007c454bbd5f8c  vmovaps xmm12, [rsp+0xC0]
00007c454bbd5f95  vmovaps xmm14, [rsp+0xD0]
00007c454bbd5f9e  vmovaps xmm15, [rsp+0xE0]
00007c454bbd5fa7  add rsp, 0xF0
00007c454bbd5fae  pop r11
00007c454bbd5fb0  pop r10
00007c454bbd5fb2  pop r9
00007c454bbd5fb4  pop r8
00007c454bbd5fb6  pop rsi
00007c454bbd5fb7  pop rdi
00007c454bbd5fb8  pop rdx
00007c454bbd5fb9  pop rcx
00007c454bbd5fba  pop rax
00007c454bbd5fbb  add rsp, 0x08
00007c454bbd5fbf  jmp 0x00007C454BBD303C
00007c454bbd5fc4  sub rsp, 0x08
00007c454bbd5fc8  push rax
00007c454bbd5fc9  push rcx
00007c454bbd5fca  push rdx
00007c454bbd5fcb  push rdi
00007c454bbd5fcc  push rsi
00007c454bbd5fcd  push r8
00007c454bbd5fcf  push r9
00007c454bbd5fd1  push r10
00007c454bbd5fd3  push r11
00007c454bbd5fd5  sub rsp, 0xF0
00007c454bbd5fdc  vmovaps [rsp], xmm0
00007c454bbd5fe1  vmovaps [rsp+0x10], xmm2
00007c454bbd5fe7  vmovaps [rsp+0x20], xmm3
00007c454bbd5fed  vmovaps [rsp+0x30], xmm4
00007c454bbd5ff3  vmovaps [rsp+0x40], xmm5
00007c454bbd5ff9  vmovaps [rsp+0x50], xmm6
00007c454bbd5fff  vmovaps [rsp+0x60], xmm7
00007c454bbd6005  vmovaps [rsp+0x70], xmm8
00007c454bbd600b  vmovaps [rsp+0x80], xmm9
00007c454bbd6014  vmovaps [rsp+0x90], xmm10
00007c454bbd601d  vmovaps [rsp+0xA0], xmm11
00007c454bbd6026  vmovaps [rsp+0xB0], xmm12
00007c454bbd602f  vmovaps [rsp+0xC0], xmm13
00007c454bbd6038  vmovaps [rsp+0xD0], xmm14
00007c454bbd6041  vmovaps [rsp+0xE0], xmm15
00007c454bbd604a  sub rsp, 0x30
00007c454bbd604e  movaps [rsp], xmm1
00007c454bbd6052  movaps [rsp+0x10], xmm15
00007c454bbd6058  movaps [rsp+0x20], xmm10
00007c454bbd605e  lea rdi, [rsp]
00007c454bbd6062  mov esi, 0x00
00007c454bbd6067  mov rax, 0x56A18AC54530
00007c454bbd6071  call rax
00007c454bbd6073  movaps xmm1, [rsp]
00007c454bbd6077  add rsp, 0x30
00007c454bbd607b  vmovaps xmm0, [rsp]
00007c454bbd6080  vmovaps xmm2, [rsp+0x10]
00007c454bbd6086  vmovaps xmm3, [rsp+0x20]
00007c454bbd608c  vmovaps xmm4, [rsp+0x30]
00007c454bbd6092  vmovaps xmm5, [rsp+0x40]
00007c454bbd6098  vmovaps xmm6, [rsp+0x50]
00007c454bbd609e  vmovaps xmm7, [rsp+0x60]
00007c454bbd60a4  vmovaps xmm8, [rsp+0x70]
00007c454bbd60aa  vmovaps xmm9, [rsp+0x80]
00007c454bbd60b3  vmovaps xmm10, [rsp+0x90]
00007c454bbd60bc  vmovaps xmm11, [rsp+0xA0]
00007c454bbd60c5  vmovaps xmm12, [rsp+0xB0]
00007c454bbd60ce  vmovaps xmm13, [rsp+0xC0]
00007c454bbd60d7  vmovaps xmm14, [rsp+0xD0]
00007c454bbd60e0  vmovaps xmm15, [rsp+0xE0]
00007c454bbd60e9  add rsp, 0xF0
00007c454bbd60f0  pop r11
00007c454bbd60f2  pop r10
00007c454bbd60f4  pop r9
00007c454bbd60f6  pop r8
00007c454bbd60f8  pop rsi
00007c454bbd60f9  pop rdi
00007c454bbd60fa  pop rdx
00007c454bbd60fb  pop rcx
00007c454bbd60fc  pop rax
00007c454bbd60fd  add rsp, 0x08
00007c454bbd6101  jmp 0x00007C454BBD305B
00007c454bbd6106  sub rsp, 0x08
00007c454bbd610a  push rax
00007c454bbd610b  push rcx
00007c454bbd610c  push rdx
00007c454bbd610d  push rdi
00007c454bbd610e  push rsi
00007c454bbd610f  push r8
00007c454bbd6111  push r9
00007c454bbd6113  push r10
00007c454bbd6115  push r11
00007c454bbd6117  sub rsp, 0xF0
00007c454bbd611e  vmovaps [rsp], xmm0
00007c454bbd6123  vmovaps [rsp+0x10], xmm1
00007c454bbd6129  vmovaps [rsp+0x20], xmm2
00007c454bbd612f  vmovaps [rsp+0x30], xmm3
00007c454bbd6135  vmovaps [rsp+0x40], xmm4
00007c454bbd613b  vmovaps [rsp+0x50], xmm5
00007c454bbd6141  vmovaps [rsp+0x60], xmm6
00007c454bbd6147  vmovaps [rsp+0x70], xmm7
00007c454bbd614d  vmovaps [rsp+0x80], xmm8
00007c454bbd6156  vmovaps [rsp+0x90], xmm9
00007c454bbd615f  vmovaps [rsp+0xA0], xmm10
00007c454bbd6168  vmovaps [rsp+0xB0], xmm11
00007c454bbd6171  vmovaps [rsp+0xC0], xmm12
00007c454bbd617a  vmovaps [rsp+0xD0], xmm13
00007c454bbd6183  vmovaps [rsp+0xE0], xmm14
00007c454bbd618c  sub rsp, 0x30
00007c454bbd6190  movaps [rsp], xmm15
00007c454bbd6195  movaps [rsp+0x10], xmm10
00007c454bbd619b  movaps [rsp+0x20], xmm11
00007c454bbd61a1  lea rdi, [rsp]
00007c454bbd61a5  mov esi, 0x00
00007c454bbd61aa  mov rax, 0x56A18AC54530
00007c454bbd61b4  call rax
00007c454bbd61b6  movaps xmm15, [rsp]
00007c454bbd61bb  add rsp, 0x30
00007c454bbd61bf  vmovaps xmm0, [rsp]
00007c454bbd61c4  vmovaps xmm1, [rsp+0x10]
00007c454bbd61ca  vmovaps xmm2, [rsp+0x20]
00007c454bbd61d0  vmovaps xmm3, [rsp+0x30]
00007c454bbd61d6  vmovaps xmm4, [rsp+0x40]
00007c454bbd61dc  vmovaps xmm5, [rsp+0x50]
00007c454bbd61e2  vmovaps xmm6, [rsp+0x60]
00007c454bbd61e8  vmovaps xmm7, [rsp+0x70]
00007c454bbd61ee  vmovaps xmm8, [rsp+0x80]
00007c454bbd61f7  vmovaps xmm9, [rsp+0x90]
00007c454bbd6200  vmovaps xmm10, [rsp+0xA0]
00007c454bbd6209  vmovaps xmm11, [rsp+0xB0]
00007c454bbd6212  vmovaps xmm12, [rsp+0xC0]
00007c454bbd621b  vmovaps xmm13, [rsp+0xD0]
00007c454bbd6224  vmovaps xmm14, [rsp+0xE0]
00007c454bbd622d  add rsp, 0xF0
00007c454bbd6234  pop r11
00007c454bbd6236  pop r10
00007c454bbd6238  pop r9
00007c454bbd623a  pop r8
00007c454bbd623c  pop rsi
00007c454bbd623d  pop rdi
00007c454bbd623e  pop rdx
00007c454bbd623f  pop rcx
00007c454bbd6240  pop rax
00007c454bbd6241  add rsp, 0x08
00007c454bbd6245  jmp 0x00007C454BBD307E
00007c454bbd624a  sub rsp, 0x08
00007c454bbd624e  push rax
00007c454bbd624f  push rcx
00007c454bbd6250  push rdx
00007c454bbd6251  push rdi
00007c454bbd6252  push rsi
00007c454bbd6253  push r8
00007c454bbd6255  push r9
00007c454bbd6257  push r10
00007c454bbd6259  push r11
00007c454bbd625b  sub rsp, 0xF0
00007c454bbd6262  vmovaps [rsp], xmm0
00007c454bbd6267  vmovaps [rsp+0x10], xmm1
00007c454bbd626d  vmovaps [rsp+0x20], xmm2
00007c454bbd6273  vmovaps [rsp+0x30], xmm3
00007c454bbd6279  vmovaps [rsp+0x40], xmm4
00007c454bbd627f  vmovaps [rsp+0x50], xmm5
00007c454bbd6285  vmovaps [rsp+0x60], xmm6
00007c454bbd628b  vmovaps [rsp+0x70], xmm7
00007c454bbd6291  vmovaps [rsp+0x80], xmm8
00007c454bbd629a  vmovaps [rsp+0x90], xmm9
00007c454bbd62a3  vmovaps [rsp+0xA0], xmm11
00007c454bbd62ac  vmovaps [rsp+0xB0], xmm12
00007c454bbd62b5  vmovaps [rsp+0xC0], xmm13
00007c454bbd62be  vmovaps [rsp+0xD0], xmm14
00007c454bbd62c7  vmovaps [rsp+0xE0], xmm15
00007c454bbd62d0  sub rsp, 0x30
00007c454bbd62d4  movaps [rsp], xmm10
00007c454bbd62d9  movaps [rsp+0x10], xmm2
00007c454bbd62de  movaps [rsp+0x20], xmm11
00007c454bbd62e4  lea rdi, [rsp]
00007c454bbd62e8  mov esi, 0x00
00007c454bbd62ed  mov rax, 0x56A18AC54530
00007c454bbd62f7  call rax
00007c454bbd62f9  movaps xmm10, [rsp]
00007c454bbd62fe  add rsp, 0x30
00007c454bbd6302  vmovaps xmm0, [rsp]
00007c454bbd6307  vmovaps xmm1, [rsp+0x10]
00007c454bbd630d  vmovaps xmm2, [rsp+0x20]
00007c454bbd6313  vmovaps xmm3, [rsp+0x30]
00007c454bbd6319  vmovaps xmm4, [rsp+0x40]
00007c454bbd631f  vmovaps xmm5, [rsp+0x50]
00007c454bbd6325  vmovaps xmm6, [rsp+0x60]
00007c454bbd632b  vmovaps xmm7, [rsp+0x70]
00007c454bbd6331  vmovaps xmm8, [rsp+0x80]
00007c454bbd633a  vmovaps xmm9, [rsp+0x90]
00007c454bbd6343  vmovaps xmm11, [rsp+0xA0]
00007c454bbd634c  vmovaps xmm12, [rsp+0xB0]
00007c454bbd6355  vmovaps xmm13, [rsp+0xC0]
00007c454bbd635e  vmovaps xmm14, [rsp+0xD0]
00007c454bbd6367  vmovaps xmm15, [rsp+0xE0]
00007c454bbd6370  add rsp, 0xF0
00007c454bbd6377  pop r11
00007c454bbd6379  pop r10
00007c454bbd637b  pop r9
00007c454bbd637d  pop r8
00007c454bbd637f  pop rsi
00007c454bbd6380  pop rdi
00007c454bbd6381  pop rdx
00007c454bbd6382  pop rcx
00007c454bbd6383  pop rax
00007c454bbd6384  add rsp, 0x08
00007c454bbd6388  jmp 0x00007C454BBD30B6
00007c454bbd638d  sub rsp, 0x08
00007c454bbd6391  push rax
00007c454bbd6392  push rcx
00007c454bbd6393  push rdx
00007c454bbd6394  push rdi
00007c454bbd6395  push rsi
00007c454bbd6396  push r8
00007c454bbd6398  push r9
00007c454bbd639a  push r10
00007c454bbd639c  push r11
00007c454bbd639e  sub rsp, 0xF0
00007c454bbd63a5  vmovaps [rsp], xmm0
00007c454bbd63aa  vmovaps [rsp+0x10], xmm1
00007c454bbd63b0  vmovaps [rsp+0x20], xmm2
00007c454bbd63b6  vmovaps [rsp+0x30], xmm3
00007c454bbd63bc  vmovaps [rsp+0x40], xmm4
00007c454bbd63c2  vmovaps [rsp+0x50], xmm5
00007c454bbd63c8  vmovaps [rsp+0x60], xmm6
00007c454bbd63ce  vmovaps [rsp+0x70], xmm7
00007c454bbd63d4  vmovaps [rsp+0x80], xmm8
00007c454bbd63dd  vmovaps [rsp+0x90], xmm9
00007c454bbd63e6  vmovaps [rsp+0xA0], xmm10
00007c454bbd63ef  vmovaps [rsp+0xB0], xmm12
00007c454bbd63f8  vmovaps [rsp+0xC0], xmm13
00007c454bbd6401  vmovaps [rsp+0xD0], xmm14
00007c454bbd640a  vmovaps [rsp+0xE0], xmm15
00007c454bbd6413  sub rsp, 0x30
00007c454bbd6417  movaps [rsp], xmm11
00007c454bbd641c  movaps [rsp+0x10], xmm2
00007c454bbd6421  movaps [rsp+0x20], xmm1
00007c454bbd6426  lea rdi, [rsp]
00007c454bbd642a  mov esi, 0x00
00007c454bbd642f  mov rax, 0x56A18AC54530
00007c454bbd6439  call rax
00007c454bbd643b  movaps xmm11, [rsp]
00007c454bbd6440  add rsp, 0x30
00007c454bbd6444  vmovaps xmm0, [rsp]
00007c454bbd6449  vmovaps xmm1, [rsp+0x10]
00007c454bbd644f  vmovaps xmm2, [rsp+0x20]
00007c454bbd6455  vmovaps xmm3, [rsp+0x30]
00007c454bbd645b  vmovaps xmm4, [rsp+0x40]
00007c454bbd6461  vmovaps xmm5, [rsp+0x50]
00007c454bbd6467  vmovaps xmm6, [rsp+0x60]
00007c454bbd646d  vmovaps xmm7, [rsp+0x70]
00007c454bbd6473  vmovaps xmm8, [rsp+0x80]
00007c454bbd647c  vmovaps xmm9, [rsp+0x90]
00007c454bbd6485  vmovaps xmm10, [rsp+0xA0]
00007c454bbd648e  vmovaps xmm12, [rsp+0xB0]
00007c454bbd6497  vmovaps xmm13, [rsp+0xC0]
00007c454bbd64a0  vmovaps xmm14, [rsp+0xD0]
00007c454bbd64a9  vmovaps xmm15, [rsp+0xE0]
00007c454bbd64b2  add rsp, 0xF0
00007c454bbd64b9  pop r11
00007c454bbd64bb  pop r10
00007c454bbd64bd  pop r9
00007c454bbd64bf  pop r8
00007c454bbd64c1  pop rsi
00007c454bbd64c2  pop rdi
00007c454bbd64c3  pop rdx
00007c454bbd64c4  pop rcx
00007c454bbd64c5  pop rax
00007c454bbd64c6  add rsp, 0x08
00007c454bbd64ca  jmp 0x00007C454BBD30F2
00007c454bbd64cf  sub rsp, 0x08
00007c454bbd64d3  push rax
00007c454bbd64d4  push rcx
00007c454bbd64d5  push rdx
00007c454bbd64d6  push rdi
00007c454bbd64d7  push rsi
00007c454bbd64d8  push r8
00007c454bbd64da  push r9
00007c454bbd64dc  push r10
00007c454bbd64de  push r11
00007c454bbd64e0  sub rsp, 0xF0
00007c454bbd64e7  vmovaps [rsp], xmm0
00007c454bbd64ec  vmovaps [rsp+0x10], xmm2
00007c454bbd64f2  vmovaps [rsp+0x20], xmm3
00007c454bbd64f8  vmovaps [rsp+0x30], xmm4
00007c454bbd64fe  vmovaps [rsp+0x40], xmm5
00007c454bbd6504  vmovaps [rsp+0x50], xmm6
00007c454bbd650a  vmovaps [rsp+0x60], xmm7
00007c454bbd6510  vmovaps [rsp+0x70], xmm8
00007c454bbd6516  vmovaps [rsp+0x80], xmm9
00007c454bbd651f  vmovaps [rsp+0x90], xmm10
00007c454bbd6528  vmovaps [rsp+0xA0], xmm11
00007c454bbd6531  vmovaps [rsp+0xB0], xmm12
00007c454bbd653a  vmovaps [rsp+0xC0], xmm13
00007c454bbd6543  vmovaps [rsp+0xD0], xmm14
00007c454bbd654c  vmovaps [rsp+0xE0], xmm15
00007c454bbd6555  sub rsp, 0x30
00007c454bbd6559  movaps [rsp], xmm1
00007c454bbd655d  movaps [rsp+0x10], xmm14
00007c454bbd6563  movaps [rsp+0x20], xmm6
00007c454bbd6568  lea rdi, [rsp]
00007c454bbd656c  mov esi, 0x00
00007c454bbd6571  mov rax, 0x56A18AC54530
00007c454bbd657b  call rax
00007c454bbd657d  movaps xmm1, [rsp]
00007c454bbd6581  add rsp, 0x30
00007c454bbd6585  vmovaps xmm0, [rsp]
00007c454bbd658a  vmovaps xmm2, [rsp+0x10]
00007c454bbd6590  vmovaps xmm3, [rsp+0x20]
00007c454bbd6596  vmovaps xmm4, [rsp+0x30]
00007c454bbd659c  vmovaps xmm5, [rsp+0x40]
00007c454bbd65a2  vmovaps xmm6, [rsp+0x50]
00007c454bbd65a8  vmovaps xmm7, [rsp+0x60]
00007c454bbd65ae  vmovaps xmm8, [rsp+0x70]
00007c454bbd65b4  vmovaps xmm9, [rsp+0x80]
00007c454bbd65bd  vmovaps xmm10, [rsp+0x90]
00007c454bbd65c6  vmovaps xmm11, [rsp+0xA0]
00007c454bbd65cf  vmovaps xmm12, [rsp+0xB0]
00007c454bbd65d8  vmovaps xmm13, [rsp+0xC0]
00007c454bbd65e1  vmovaps xmm14, [rsp+0xD0]
00007c454bbd65ea  vmovaps xmm15, [rsp+0xE0]
00007c454bbd65f3  add rsp, 0xF0
00007c454bbd65fa  pop r11
00007c454bbd65fc  pop r10
00007c454bbd65fe  pop r9
00007c454bbd6600  pop r8
00007c454bbd6602  pop rsi
00007c454bbd6603  pop rdi
00007c454bbd6604  pop rdx
00007c454bbd6605  pop rcx
00007c454bbd6606  pop rax
00007c454bbd6607  add rsp, 0x08
00007c454bbd660b  jmp 0x00007C454BBD310B
00007c454bbd6610  sub rsp, 0x08
00007c454bbd6614  push rax
00007c454bbd6615  push rcx
00007c454bbd6616  push rdx
00007c454bbd6617  push rdi
00007c454bbd6618  push rsi
00007c454bbd6619  push r8
00007c454bbd661b  push r9
00007c454bbd661d  push r10
00007c454bbd661f  push r11
00007c454bbd6621  sub rsp, 0xF0
00007c454bbd6628  vmovaps [rsp], xmm0
00007c454bbd662d  vmovaps [rsp+0x10], xmm1
00007c454bbd6633  vmovaps [rsp+0x20], xmm2
00007c454bbd6639  vmovaps [rsp+0x30], xmm3
00007c454bbd663f  vmovaps [rsp+0x40], xmm4
00007c454bbd6645  vmovaps [rsp+0x50], xmm5
00007c454bbd664b  vmovaps [rsp+0x60], xmm6
00007c454bbd6651  vmovaps [rsp+0x70], xmm7
00007c454bbd6657  vmovaps [rsp+0x80], xmm8
00007c454bbd6660  vmovaps [rsp+0x90], xmm9
00007c454bbd6669  vmovaps [rsp+0xA0], xmm10
00007c454bbd6672  vmovaps [rsp+0xB0], xmm11
00007c454bbd667b  vmovaps [rsp+0xC0], xmm12
00007c454bbd6684  vmovaps [rsp+0xD0], xmm13
00007c454bbd668d  vmovaps [rsp+0xE0], xmm14
00007c454bbd6696  sub rsp, 0x30
00007c454bbd669a  movaps [rsp], xmm15
00007c454bbd669f  movaps [rsp+0x10], xmm14
00007c454bbd66a5  movaps [rsp+0x20], xmm5
00007c454bbd66aa  lea rdi, [rsp]
00007c454bbd66ae  mov esi, 0x00
00007c454bbd66b3  mov rax, 0x56A18AC54530
00007c454bbd66bd  call rax
00007c454bbd66bf  movaps xmm15, [rsp]
00007c454bbd66c4  add rsp, 0x30
00007c454bbd66c8  vmovaps xmm0, [rsp]
00007c454bbd66cd  vmovaps xmm1, [rsp+0x10]
00007c454bbd66d3  vmovaps xmm2, [rsp+0x20]
00007c454bbd66d9  vmovaps xmm3, [rsp+0x30]
00007c454bbd66df  vmovaps xmm4, [rsp+0x40]
00007c454bbd66e5  vmovaps xmm5, [rsp+0x50]
00007c454bbd66eb  vmovaps xmm6, [rsp+0x60]
00007c454bbd66f1  vmovaps xmm7, [rsp+0x70]
00007c454bbd66f7  vmovaps xmm8, [rsp+0x80]
00007c454bbd6700  vmovaps xmm9, [rsp+0x90]
00007c454bbd6709  vmovaps xmm10, [rsp+0xA0]
00007c454bbd6712  vmovaps xmm11, [rsp+0xB0]
00007c454bbd671b  vmovaps xmm12, [rsp+0xC0]
00007c454bbd6724  vmovaps xmm13, [rsp+0xD0]
00007c454bbd672d  vmovaps xmm14, [rsp+0xE0]
00007c454bbd6736  add rsp, 0xF0
00007c454bbd673d  pop r11
00007c454bbd673f  pop r10
00007c454bbd6741  pop r9
00007c454bbd6743  pop r8
00007c454bbd6745  pop rsi
00007c454bbd6746  pop rdi
00007c454bbd6747  pop rdx
00007c454bbd6748  pop rcx
00007c454bbd6749  pop rax
00007c454bbd674a  add rsp, 0x08
00007c454bbd674e  jmp 0x00007C454BBD312B
00007c454bbd6753  sub rsp, 0x08
00007c454bbd6757  push rax
00007c454bbd6758  push rcx
00007c454bbd6759  push rdx
00007c454bbd675a  push rdi
00007c454bbd675b  push rsi
00007c454bbd675c  push r8
00007c454bbd675e  push r9
00007c454bbd6760  push r10
00007c454bbd6762  push r11
00007c454bbd6764  sub rsp, 0xF0
00007c454bbd676b  vmovaps [rsp], xmm0
00007c454bbd6770  vmovaps [rsp+0x10], xmm1
00007c454bbd6776  vmovaps [rsp+0x20], xmm2
00007c454bbd677c  vmovaps [rsp+0x30], xmm3
00007c454bbd6782  vmovaps [rsp+0x40], xmm4
00007c454bbd6788  vmovaps [rsp+0x50], xmm5
00007c454bbd678e  vmovaps [rsp+0x60], xmm7
00007c454bbd6794  vmovaps [rsp+0x70], xmm8
00007c454bbd679a  vmovaps [rsp+0x80], xmm9
00007c454bbd67a3  vmovaps [rsp+0x90], xmm10
00007c454bbd67ac  vmovaps [rsp+0xA0], xmm11
00007c454bbd67b5  vmovaps [rsp+0xB0], xmm12
00007c454bbd67be  vmovaps [rsp+0xC0], xmm13
00007c454bbd67c7  vmovaps [rsp+0xD0], xmm14
00007c454bbd67d0  vmovaps [rsp+0xE0], xmm15
00007c454bbd67d9  sub rsp, 0x30
00007c454bbd67dd  movaps [rsp], xmm6
00007c454bbd67e1  movaps [rsp+0x10], xmm9
00007c454bbd67e7  movaps [rsp+0x20], xmm14
00007c454bbd67ed  lea rdi, [rsp]
00007c454bbd67f1  mov esi, 0x00
00007c454bbd67f6  mov rax, 0x56A18AC54530
00007c454bbd6800  call rax
00007c454bbd6802  movaps xmm6, [rsp]
00007c454bbd6806  add rsp, 0x30
00007c454bbd680a  vmovaps xmm0, [rsp]
00007c454bbd680f  vmovaps xmm1, [rsp+0x10]
00007c454bbd6815  vmovaps xmm2, [rsp+0x20]
00007c454bbd681b  vmovaps xmm3, [rsp+0x30]
00007c454bbd6821  vmovaps xmm4, [rsp+0x40]
00007c454bbd6827  vmovaps xmm5, [rsp+0x50]
00007c454bbd682d  vmovaps xmm7, [rsp+0x60]
00007c454bbd6833  vmovaps xmm8, [rsp+0x70]
00007c454bbd6839  vmovaps xmm9, [rsp+0x80]
00007c454bbd6842  vmovaps xmm10, [rsp+0x90]
00007c454bbd684b  vmovaps xmm11, [rsp+0xA0]
00007c454bbd6854  vmovaps xmm12, [rsp+0xB0]
00007c454bbd685d  vmovaps xmm13, [rsp+0xC0]
00007c454bbd6866  vmovaps xmm14, [rsp+0xD0]
00007c454bbd686f  vmovaps xmm15, [rsp+0xE0]
00007c454bbd6878  add rsp, 0xF0
00007c454bbd687f  pop r11
00007c454bbd6881  pop r10
00007c454bbd6883  pop r9
00007c454bbd6885  pop r8
00007c454bbd6887  pop rsi
00007c454bbd6888  pop rdi
00007c454bbd6889  pop rdx
00007c454bbd688a  pop rcx
00007c454bbd688b  pop rax
00007c454bbd688c  add rsp, 0x08
00007c454bbd6890  jmp 0x00007C454BBD3153
00007c454bbd6895  sub rsp, 0x08
00007c454bbd6899  push rax
00007c454bbd689a  push rcx
00007c454bbd689b  push rdx
00007c454bbd689c  push rdi
00007c454bbd689d  push rsi
00007c454bbd689e  push r8
00007c454bbd68a0  push r9
00007c454bbd68a2  push r10
00007c454bbd68a4  push r11
00007c454bbd68a6  sub rsp, 0xF0
00007c454bbd68ad  vmovaps [rsp], xmm0
00007c454bbd68b2  vmovaps [rsp+0x10], xmm1
00007c454bbd68b8  vmovaps [rsp+0x20], xmm2
00007c454bbd68be  vmovaps [rsp+0x30], xmm3
00007c454bbd68c4  vmovaps [rsp+0x40], xmm4
00007c454bbd68ca  vmovaps [rsp+0x50], xmm5
00007c454bbd68d0  vmovaps [rsp+0x60], xmm6
00007c454bbd68d6  vmovaps [rsp+0x70], xmm7
00007c454bbd68dc  vmovaps [rsp+0x80], xmm8
00007c454bbd68e5  vmovaps [rsp+0x90], xmm9
00007c454bbd68ee  vmovaps [rsp+0xA0], xmm10
00007c454bbd68f7  vmovaps [rsp+0xB0], xmm11
00007c454bbd6900  vmovaps [rsp+0xC0], xmm12
00007c454bbd6909  vmovaps [rsp+0xD0], xmm13
00007c454bbd6912  vmovaps [rsp+0xE0], xmm15
00007c454bbd691b  sub rsp, 0x30
00007c454bbd691f  movaps [rsp], xmm14
00007c454bbd6924  movaps [rsp+0x10], xmm9
00007c454bbd692a  movaps [rsp+0x20], xmm13
00007c454bbd6930  lea rdi, [rsp]
00007c454bbd6934  mov esi, 0x00
00007c454bbd6939  mov rax, 0x56A18AC54530
00007c454bbd6943  call rax
00007c454bbd6945  movaps xmm14, [rsp]
00007c454bbd694a  add rsp, 0x30
00007c454bbd694e  vmovaps xmm0, [rsp]
00007c454bbd6953  vmovaps xmm1, [rsp+0x10]
00007c454bbd6959  vmovaps xmm2, [rsp+0x20]
00007c454bbd695f  vmovaps xmm3, [rsp+0x30]
00007c454bbd6965  vmovaps xmm4, [rsp+0x40]
00007c454bbd696b  vmovaps xmm5, [rsp+0x50]
00007c454bbd6971  vmovaps xmm6, [rsp+0x60]
00007c454bbd6977  vmovaps xmm7, [rsp+0x70]
00007c454bbd697d  vmovaps xmm8, [rsp+0x80]
00007c454bbd6986  vmovaps xmm9, [rsp+0x90]
00007c454bbd698f  vmovaps xmm10, [rsp+0xA0]
00007c454bbd6998  vmovaps xmm11, [rsp+0xB0]
00007c454bbd69a1  vmovaps xmm12, [rsp+0xC0]
00007c454bbd69aa  vmovaps xmm13, [rsp+0xD0]
00007c454bbd69b3  vmovaps xmm15, [rsp+0xE0]
00007c454bbd69bc  add rsp, 0xF0
00007c454bbd69c3  pop r11
00007c454bbd69c5  pop r10
00007c454bbd69c7  pop r9
00007c454bbd69c9  pop r8
00007c454bbd69cb  pop rsi
00007c454bbd69cc  pop rdi
00007c454bbd69cd  pop rdx
00007c454bbd69ce  pop rcx
00007c454bbd69cf  pop rax
00007c454bbd69d0  add rsp, 0x08
00007c454bbd69d4  jmp 0x00007C454BBD3176
00007c454bbd69d9  sub rsp, 0x08
00007c454bbd69dd  push rax
00007c454bbd69de  push rcx
00007c454bbd69df  push rdx
00007c454bbd69e0  push rdi
00007c454bbd69e1  push rsi
00007c454bbd69e2  push r8
00007c454bbd69e4  push r9
00007c454bbd69e6  push r10
00007c454bbd69e8  push r11
00007c454bbd69ea  sub rsp, 0xF0
00007c454bbd69f1  vmovaps [rsp], xmm0
00007c454bbd69f6  vmovaps [rsp+0x10], xmm1
00007c454bbd69fc  vmovaps [rsp+0x20], xmm2
00007c454bbd6a02  vmovaps [rsp+0x30], xmm3
00007c454bbd6a08  vmovaps [rsp+0x40], xmm4
00007c454bbd6a0e  vmovaps [rsp+0x50], xmm5
00007c454bbd6a14  vmovaps [rsp+0x60], xmm6
00007c454bbd6a1a  vmovaps [rsp+0x70], xmm7
00007c454bbd6a20  vmovaps [rsp+0x80], xmm8
00007c454bbd6a29  vmovaps [rsp+0x90], xmm9
00007c454bbd6a32  vmovaps [rsp+0xA0], xmm10
00007c454bbd6a3b  vmovaps [rsp+0xB0], xmm11
00007c454bbd6a44  vmovaps [rsp+0xC0], xmm12
00007c454bbd6a4d  vmovaps [rsp+0xD0], xmm14
00007c454bbd6a56  vmovaps [rsp+0xE0], xmm15
00007c454bbd6a5f  sub rsp, 0x30
00007c454bbd6a63  movaps [rsp], xmm13
00007c454bbd6a68  movaps [rsp+0x10], xmm9
00007c454bbd6a6e  movaps [rsp+0x20], xmm10
00007c454bbd6a74  lea rdi, [rsp]
00007c454bbd6a78  mov esi, 0x00
00007c454bbd6a7d  mov rax, 0x56A18AC54530
00007c454bbd6a87  call rax
00007c454bbd6a89  movaps xmm13, [rsp]
00007c454bbd6a8e  add rsp, 0x30
00007c454bbd6a92  vmovaps xmm0, [rsp]
00007c454bbd6a97  vmovaps xmm1, [rsp+0x10]
00007c454bbd6a9d  vmovaps xmm2, [rsp+0x20]
00007c454bbd6aa3  vmovaps xmm3, [rsp+0x30]
00007c454bbd6aa9  vmovaps xmm4, [rsp+0x40]
00007c454bbd6aaf  vmovaps xmm5, [rsp+0x50]
00007c454bbd6ab5  vmovaps xmm6, [rsp+0x60]
00007c454bbd6abb  vmovaps xmm7, [rsp+0x70]
00007c454bbd6ac1  vmovaps xmm8, [rsp+0x80]
00007c454bbd6aca  vmovaps xmm9, [rsp+0x90]
00007c454bbd6ad3  vmovaps xmm10, [rsp+0xA0]
00007c454bbd6adc  vmovaps xmm11, [rsp+0xB0]
00007c454bbd6ae5  vmovaps xmm12, [rsp+0xC0]
00007c454bbd6aee  vmovaps xmm14, [rsp+0xD0]
00007c454bbd6af7  vmovaps xmm15, [rsp+0xE0]
00007c454bbd6b00  add rsp, 0xF0
00007c454bbd6b07  pop r11
00007c454bbd6b09  pop r10
00007c454bbd6b0b  pop r9
00007c454bbd6b0d  pop r8
00007c454bbd6b0f  pop rsi
00007c454bbd6b10  pop rdi
00007c454bbd6b11  pop rdx
00007c454bbd6b12  pop rcx
00007c454bbd6b13  pop rax
00007c454bbd6b14  add rsp, 0x08
00007c454bbd6b18  jmp 0x00007C454BBD3196
00007c454bbd6b1d  call 0x00007C454BA0AFE0
00007c454bbd6b22  jmp 0x00007C454BBD31EB
00007c454bbd6b27  sub rsp, 0x08
00007c454bbd6b2b  push rax
00007c454bbd6b2c  push rcx
00007c454bbd6b2d  push rdx
00007c454bbd6b2e  push rdi
00007c454bbd6b2f  push rsi
00007c454bbd6b30  push r8
00007c454bbd6b32  push r9
00007c454bbd6b34  push r10
00007c454bbd6b36  push r11
00007c454bbd6b38  sub rsp, 0xF0
00007c454bbd6b3f  vmovaps [rsp], xmm0
00007c454bbd6b44  vmovaps [rsp+0x10], xmm1
00007c454bbd6b4a  vmovaps [rsp+0x20], xmm2
00007c454bbd6b50  vmovaps [rsp+0x30], xmm3
00007c454bbd6b56  vmovaps [rsp+0x40], xmm4
00007c454bbd6b5c  vmovaps [rsp+0x50], xmm5
00007c454bbd6b62  vmovaps [rsp+0x60], xmm6
00007c454bbd6b68  vmovaps [rsp+0x70], xmm7
00007c454bbd6b6e  vmovaps [rsp+0x80], xmm8
00007c454bbd6b77  vmovaps [rsp+0x90], xmm10
00007c454bbd6b80  vmovaps [rsp+0xA0], xmm11
00007c454bbd6b89  vmovaps [rsp+0xB0], xmm12
00007c454bbd6b92  vmovaps [rsp+0xC0], xmm13
00007c454bbd6b9b  vmovaps [rsp+0xD0], xmm14
00007c454bbd6ba4  vmovaps [rsp+0xE0], xmm15
00007c454bbd6bad  sub rsp, 0x30
00007c454bbd6bb1  movaps [rsp], xmm9
00007c454bbd6bb6  movaps [rsp+0x10], xmm8
00007c454bbd6bbc  movaps [rsp+0x20], xmm10
00007c454bbd6bc2  lea rdi, [rsp]
00007c454bbd6bc6  mov esi, 0x00
00007c454bbd6bcb  mov rax, 0x56A18AC54530
00007c454bbd6bd5  call rax
00007c454bbd6bd7  movaps xmm9, [rsp]
00007c454bbd6bdc  add rsp, 0x30
00007c454bbd6be0  vmovaps xmm0, [rsp]
00007c454bbd6be5  vmovaps xmm1, [rsp+0x10]
00007c454bbd6beb  vmovaps xmm2, [rsp+0x20]
00007c454bbd6bf1  vmovaps xmm3, [rsp+0x30]
00007c454bbd6bf7  vmovaps xmm4, [rsp+0x40]
00007c454bbd6bfd  vmovaps xmm5, [rsp+0x50]
00007c454bbd6c03  vmovaps xmm6, [rsp+0x60]
00007c454bbd6c09  vmovaps xmm7, [rsp+0x70]
00007c454bbd6c0f  vmovaps xmm8, [rsp+0x80]
00007c454bbd6c18  vmovaps xmm10, [rsp+0x90]
00007c454bbd6c21  vmovaps xmm11, [rsp+0xA0]
00007c454bbd6c2a  vmovaps xmm12, [rsp+0xB0]
00007c454bbd6c33  vmovaps xmm13, [rsp+0xC0]
00007c454bbd6c3c  vmovaps xmm14, [rsp+0xD0]
00007c454bbd6c45  vmovaps xmm15, [rsp+0xE0]
00007c454bbd6c4e  add rsp, 0xF0
00007c454bbd6c55  pop r11
00007c454bbd6c57  pop r10
00007c454bbd6c59  pop r9
00007c454bbd6c5b  pop r8
00007c454bbd6c5d  pop rsi
00007c454bbd6c5e  pop rdi
00007c454bbd6c5f  pop rdx
00007c454bbd6c60  pop rcx
00007c454bbd6c61  pop rax
00007c454bbd6c62  add rsp, 0x08
00007c454bbd6c66  jmp 0x00007C454BBD321C
00007c454bbd6c6b  sub rsp, 0x08
00007c454bbd6c6f  push rax
00007c454bbd6c70  push rcx
00007c454bbd6c71  push rdx
00007c454bbd6c72  push rdi
00007c454bbd6c73  push rsi
00007c454bbd6c74  push r8
00007c454bbd6c76  push r9
00007c454bbd6c78  push r10
00007c454bbd6c7a  push r11
00007c454bbd6c7c  sub rsp, 0xF0
00007c454bbd6c83  vmovaps [rsp], xmm0
00007c454bbd6c88  vmovaps [rsp+0x10], xmm1
00007c454bbd6c8e  vmovaps [rsp+0x20], xmm2
00007c454bbd6c94  vmovaps [rsp+0x30], xmm3
00007c454bbd6c9a  vmovaps [rsp+0x40], xmm4
00007c454bbd6ca0  vmovaps [rsp+0x50], xmm5
00007c454bbd6ca6  vmovaps [rsp+0x60], xmm6
00007c454bbd6cac  vmovaps [rsp+0x70], xmm7
00007c454bbd6cb2  vmovaps [rsp+0x80], xmm8
00007c454bbd6cbb  vmovaps [rsp+0x90], xmm9
00007c454bbd6cc4  vmovaps [rsp+0xA0], xmm11
00007c454bbd6ccd  vmovaps [rsp+0xB0], xmm12
00007c454bbd6cd6  vmovaps [rsp+0xC0], xmm13
00007c454bbd6cdf  vmovaps [rsp+0xD0], xmm14
00007c454bbd6ce8  vmovaps [rsp+0xE0], xmm15
00007c454bbd6cf1  sub rsp, 0x30
00007c454bbd6cf5  movaps [rsp], xmm10
00007c454bbd6cfa  movaps [rsp+0x10], xmm1
00007c454bbd6cff  movaps [rsp+0x20], xmm11
00007c454bbd6d05  lea rdi, [rsp]
00007c454bbd6d09  mov esi, 0x00
00007c454bbd6d0e  mov rax, 0x56A18AC54530
00007c454bbd6d18  call rax
00007c454bbd6d1a  movaps xmm10, [rsp]
00007c454bbd6d1f  add rsp, 0x30
00007c454bbd6d23  vmovaps xmm0, [rsp]
00007c454bbd6d28  vmovaps xmm1, [rsp+0x10]
00007c454bbd6d2e  vmovaps xmm2, [rsp+0x20]
00007c454bbd6d34  vmovaps xmm3, [rsp+0x30]
00007c454bbd6d3a  vmovaps xmm4, [rsp+0x40]
00007c454bbd6d40  vmovaps xmm5, [rsp+0x50]
00007c454bbd6d46  vmovaps xmm6, [rsp+0x60]
00007c454bbd6d4c  vmovaps xmm7, [rsp+0x70]
00007c454bbd6d52  vmovaps xmm8, [rsp+0x80]
00007c454bbd6d5b  vmovaps xmm9, [rsp+0x90]
00007c454bbd6d64  vmovaps xmm11, [rsp+0xA0]
00007c454bbd6d6d  vmovaps xmm12, [rsp+0xB0]
00007c454bbd6d76  vmovaps xmm13, [rsp+0xC0]
00007c454bbd6d7f  vmovaps xmm14, [rsp+0xD0]
00007c454bbd6d88  vmovaps xmm15, [rsp+0xE0]
00007c454bbd6d91  add rsp, 0xF0
00007c454bbd6d98  pop r11
00007c454bbd6d9a  pop r10
00007c454bbd6d9c  pop r9
00007c454bbd6d9e  pop r8
00007c454bbd6da0  pop rsi
00007c454bbd6da1  pop rdi
00007c454bbd6da2  pop rdx
00007c454bbd6da3  pop rcx
00007c454bbd6da4  pop rax
00007c454bbd6da5  add rsp, 0x08
00007c454bbd6da9  jmp 0x00007C454BBD3237
00007c454bbd6dae  sub rsp, 0x08
00007c454bbd6db2  push rax
00007c454bbd6db3  push rcx
00007c454bbd6db4  push rdx
00007c454bbd6db5  push rdi
00007c454bbd6db6  push rsi
00007c454bbd6db7  push r8
00007c454bbd6db9  push r9
00007c454bbd6dbb  push r10
00007c454bbd6dbd  push r11
00007c454bbd6dbf  sub rsp, 0xF0
00007c454bbd6dc6  vmovaps [rsp], xmm0
00007c454bbd6dcb  vmovaps [rsp+0x10], xmm2
00007c454bbd6dd1  vmovaps [rsp+0x20], xmm3
00007c454bbd6dd7  vmovaps [rsp+0x30], xmm4
00007c454bbd6ddd  vmovaps [rsp+0x40], xmm5
00007c454bbd6de3  vmovaps [rsp+0x50], xmm6
00007c454bbd6de9  vmovaps [rsp+0x60], xmm7
00007c454bbd6def  vmovaps [rsp+0x70], xmm8
00007c454bbd6df5  vmovaps [rsp+0x80], xmm9
00007c454bbd6dfe  vmovaps [rsp+0x90], xmm10
00007c454bbd6e07  vmovaps [rsp+0xA0], xmm11
00007c454bbd6e10  vmovaps [rsp+0xB0], xmm12
00007c454bbd6e19  vmovaps [rsp+0xC0], xmm13
00007c454bbd6e22  vmovaps [rsp+0xD0], xmm14
00007c454bbd6e2b  vmovaps [rsp+0xE0], xmm15
00007c454bbd6e34  sub rsp, 0x30
00007c454bbd6e38  movaps [rsp], xmm1
00007c454bbd6e3c  movaps [rsp+0x10], xmm15
00007c454bbd6e42  movaps [rsp+0x20], xmm6
00007c454bbd6e47  lea rdi, [rsp]
00007c454bbd6e4b  mov esi, 0x00
00007c454bbd6e50  mov rax, 0x56A18AC54530
00007c454bbd6e5a  call rax
00007c454bbd6e5c  movaps xmm1, [rsp]
00007c454bbd6e60  add rsp, 0x30
00007c454bbd6e64  vmovaps xmm0, [rsp]
00007c454bbd6e69  vmovaps xmm2, [rsp+0x10]
00007c454bbd6e6f  vmovaps xmm3, [rsp+0x20]
00007c454bbd6e75  vmovaps xmm4, [rsp+0x30]
00007c454bbd6e7b  vmovaps xmm5, [rsp+0x40]
00007c454bbd6e81  vmovaps xmm6, [rsp+0x50]
00007c454bbd6e87  vmovaps xmm7, [rsp+0x60]
00007c454bbd6e8d  vmovaps xmm8, [rsp+0x70]
00007c454bbd6e93  vmovaps xmm9, [rsp+0x80]
00007c454bbd6e9c  vmovaps xmm10, [rsp+0x90]
00007c454bbd6ea5  vmovaps xmm11, [rsp+0xA0]
00007c454bbd6eae  vmovaps xmm12, [rsp+0xB0]
00007c454bbd6eb7  vmovaps xmm13, [rsp+0xC0]
00007c454bbd6ec0  vmovaps xmm14, [rsp+0xD0]
00007c454bbd6ec9  vmovaps xmm15, [rsp+0xE0]
00007c454bbd6ed2  add rsp, 0xF0
00007c454bbd6ed9  pop r11
00007c454bbd6edb  pop r10
00007c454bbd6edd  pop r9
00007c454bbd6edf  pop r8
00007c454bbd6ee1  pop rsi
00007c454bbd6ee2  pop rdi
00007c454bbd6ee3  pop rdx
00007c454bbd6ee4  pop rcx
00007c454bbd6ee5  pop rax
00007c454bbd6ee6  add rsp, 0x08
00007c454bbd6eea  jmp 0x00007C454BBD3250
00007c454bbd6eef  sub rsp, 0x08
00007c454bbd6ef3  push rax
00007c454bbd6ef4  push rcx
00007c454bbd6ef5  push rdx
00007c454bbd6ef6  push rdi
00007c454bbd6ef7  push rsi
00007c454bbd6ef8  push r8
00007c454bbd6efa  push r9
00007c454bbd6efc  push r10
00007c454bbd6efe  push r11
00007c454bbd6f00  sub rsp, 0xF0
00007c454bbd6f07  vmovaps [rsp], xmm0
00007c454bbd6f0c  vmovaps [rsp+0x10], xmm1
00007c454bbd6f12  vmovaps [rsp+0x20], xmm2
00007c454bbd6f18  vmovaps [rsp+0x30], xmm3
00007c454bbd6f1e  vmovaps [rsp+0x40], xmm4
00007c454bbd6f24  vmovaps [rsp+0x50], xmm5
00007c454bbd6f2a  vmovaps [rsp+0x60], xmm6
00007c454bbd6f30  vmovaps [rsp+0x70], xmm7
00007c454bbd6f36  vmovaps [rsp+0x80], xmm8
00007c454bbd6f3f  vmovaps [rsp+0x90], xmm9
00007c454bbd6f48  vmovaps [rsp+0xA0], xmm10
00007c454bbd6f51  vmovaps [rsp+0xB0], xmm12
00007c454bbd6f5a  vmovaps [rsp+0xC0], xmm13
00007c454bbd6f63  vmovaps [rsp+0xD0], xmm14
00007c454bbd6f6c  vmovaps [rsp+0xE0], xmm15
00007c454bbd6f75  sub rsp, 0x30
00007c454bbd6f79  movaps [rsp], xmm11
00007c454bbd6f7e  movaps [rsp+0x10], xmm12
00007c454bbd6f84  movaps [rsp+0x20], xmm15
00007c454bbd6f8a  lea rdi, [rsp]
00007c454bbd6f8e  mov esi, 0x00
00007c454bbd6f93  mov rax, 0x56A18AC54530
00007c454bbd6f9d  call rax
00007c454bbd6f9f  movaps xmm11, [rsp]
00007c454bbd6fa4  add rsp, 0x30
00007c454bbd6fa8  vmovaps xmm0, [rsp]
00007c454bbd6fad  vmovaps xmm1, [rsp+0x10]
00007c454bbd6fb3  vmovaps xmm2, [rsp+0x20]
00007c454bbd6fb9  vmovaps xmm3, [rsp+0x30]
00007c454bbd6fbf  vmovaps xmm4, [rsp+0x40]
00007c454bbd6fc5  vmovaps xmm5, [rsp+0x50]
00007c454bbd6fcb  vmovaps xmm6, [rsp+0x60]
00007c454bbd6fd1  vmovaps xmm7, [rsp+0x70]
00007c454bbd6fd7  vmovaps xmm8, [rsp+0x80]
00007c454bbd6fe0  vmovaps xmm9, [rsp+0x90]
00007c454bbd6fe9  vmovaps xmm10, [rsp+0xA0]
00007c454bbd6ff2  vmovaps xmm12, [rsp+0xB0]
00007c454bbd6ffb  vmovaps xmm13, [rsp+0xC0]
00007c454bbd7004  vmovaps xmm14, [rsp+0xD0]
00007c454bbd700d  vmovaps xmm15, [rsp+0xE0]
00007c454bbd7016  add rsp, 0xF0
00007c454bbd701d  pop r11
00007c454bbd701f  pop r10
00007c454bbd7021  pop r9
00007c454bbd7023  pop r8
00007c454bbd7025  pop rsi
00007c454bbd7026  pop rdi
00007c454bbd7027  pop rdx
00007c454bbd7028  pop rcx
00007c454bbd7029  pop rax
00007c454bbd702a  add rsp, 0x08
00007c454bbd702e  jmp 0x00007C454BBD327A
00007c454bbd7033  sub rsp, 0x08
00007c454bbd7037  push rax
00007c454bbd7038  push rcx
00007c454bbd7039  push rdx
00007c454bbd703a  push rdi
00007c454bbd703b  push rsi
00007c454bbd703c  push r8
00007c454bbd703e  push r9
00007c454bbd7040  push r10
00007c454bbd7042  push r11
00007c454bbd7044  sub rsp, 0xF0
00007c454bbd704b  vmovaps [rsp], xmm0
00007c454bbd7050  vmovaps [rsp+0x10], xmm1
00007c454bbd7056  vmovaps [rsp+0x20], xmm2
00007c454bbd705c  vmovaps [rsp+0x30], xmm3
00007c454bbd7062  vmovaps [rsp+0x40], xmm4
00007c454bbd7068  vmovaps [rsp+0x50], xmm5
00007c454bbd706e  vmovaps [rsp+0x60], xmm6
00007c454bbd7074  vmovaps [rsp+0x70], xmm7
00007c454bbd707a  vmovaps [rsp+0x80], xmm8
00007c454bbd7083  vmovaps [rsp+0x90], xmm9
00007c454bbd708c  vmovaps [rsp+0xA0], xmm10
00007c454bbd7095  vmovaps [rsp+0xB0], xmm11
00007c454bbd709e  vmovaps [rsp+0xC0], xmm13
00007c454bbd70a7  vmovaps [rsp+0xD0], xmm14
00007c454bbd70b0  vmovaps [rsp+0xE0], xmm15
00007c454bbd70b9  sub rsp, 0x30
00007c454bbd70bd  movaps [rsp], xmm12
00007c454bbd70c2  movaps [rsp+0x10], xmm8
00007c454bbd70c8  movaps [rsp+0x20], xmm15
00007c454bbd70ce  lea rdi, [rsp]
00007c454bbd70d2  mov esi, 0x00
00007c454bbd70d7  mov rax, 0x56A18AC54530
00007c454bbd70e1  call rax
00007c454bbd70e3  movaps xmm12, [rsp]
00007c454bbd70e8  add rsp, 0x30
00007c454bbd70ec  vmovaps xmm0, [rsp]
00007c454bbd70f1  vmovaps xmm1, [rsp+0x10]
00007c454bbd70f7  vmovaps xmm2, [rsp+0x20]
00007c454bbd70fd  vmovaps xmm3, [rsp+0x30]
00007c454bbd7103  vmovaps xmm4, [rsp+0x40]
00007c454bbd7109  vmovaps xmm5, [rsp+0x50]
00007c454bbd710f  vmovaps xmm6, [rsp+0x60]
00007c454bbd7115  vmovaps xmm7, [rsp+0x70]
00007c454bbd711b  vmovaps xmm8, [rsp+0x80]
00007c454bbd7124  vmovaps xmm9, [rsp+0x90]
00007c454bbd712d  vmovaps xmm10, [rsp+0xA0]
00007c454bbd7136  vmovaps xmm11, [rsp+0xB0]
00007c454bbd713f  vmovaps xmm13, [rsp+0xC0]
00007c454bbd7148  vmovaps xmm14, [rsp+0xD0]
00007c454bbd7151  vmovaps xmm15, [rsp+0xE0]
00007c454bbd715a  add rsp, 0xF0
00007c454bbd7161  pop r11
00007c454bbd7163  pop r10
00007c454bbd7165  pop r9
00007c454bbd7167  pop r8
00007c454bbd7169  pop rsi
00007c454bbd716a  pop rdi
00007c454bbd716b  pop rdx
00007c454bbd716c  pop rcx
00007c454bbd716d  pop rax
00007c454bbd716e  add rsp, 0x08
00007c454bbd7172  jmp 0x00007C454BBD32A9
00007c454bbd7177  sub rsp, 0x08
00007c454bbd717b  push rax
00007c454bbd717c  push rcx
00007c454bbd717d  push rdx
00007c454bbd717e  push rdi
00007c454bbd717f  push rsi
00007c454bbd7180  push r8
00007c454bbd7182  push r9
00007c454bbd7184  push r10
00007c454bbd7186  push r11
00007c454bbd7188  sub rsp, 0xF0
00007c454bbd718f  vmovaps [rsp], xmm0
00007c454bbd7194  vmovaps [rsp+0x10], xmm1
00007c454bbd719a  vmovaps [rsp+0x20], xmm2
00007c454bbd71a0  vmovaps [rsp+0x30], xmm3
00007c454bbd71a6  vmovaps [rsp+0x40], xmm4
00007c454bbd71ac  vmovaps [rsp+0x50], xmm5
00007c454bbd71b2  vmovaps [rsp+0x60], xmm6
00007c454bbd71b8  vmovaps [rsp+0x70], xmm7
00007c454bbd71be  vmovaps [rsp+0x80], xmm9
00007c454bbd71c7  vmovaps [rsp+0x90], xmm10
00007c454bbd71d0  vmovaps [rsp+0xA0], xmm11
00007c454bbd71d9  vmovaps [rsp+0xB0], xmm12
00007c454bbd71e2  vmovaps [rsp+0xC0], xmm13
00007c454bbd71eb  vmovaps [rsp+0xD0], xmm14
00007c454bbd71f4  vmovaps [rsp+0xE0], xmm15
00007c454bbd71fd  sub rsp, 0x30
00007c454bbd7201  movaps [rsp], xmm8
00007c454bbd7206  movaps [rsp+0x10], xmm7
00007c454bbd720b  movaps [rsp+0x20], xmm15
00007c454bbd7211  lea rdi, [rsp]
00007c454bbd7215  mov esi, 0x00
00007c454bbd721a  mov rax, 0x56A18AC54530
00007c454bbd7224  call rax
00007c454bbd7226  movaps xmm8, [rsp]
00007c454bbd722b  add rsp, 0x30
00007c454bbd722f  vmovaps xmm0, [rsp]
00007c454bbd7234  vmovaps xmm1, [rsp+0x10]
00007c454bbd723a  vmovaps xmm2, [rsp+0x20]
00007c454bbd7240  vmovaps xmm3, [rsp+0x30]
00007c454bbd7246  vmovaps xmm4, [rsp+0x40]
00007c454bbd724c  vmovaps xmm5, [rsp+0x50]
00007c454bbd7252  vmovaps xmm6, [rsp+0x60]
00007c454bbd7258  vmovaps xmm7, [rsp+0x70]
00007c454bbd725e  vmovaps xmm9, [rsp+0x80]
00007c454bbd7267  vmovaps xmm10, [rsp+0x90]
00007c454bbd7270  vmovaps xmm11, [rsp+0xA0]
00007c454bbd7279  vmovaps xmm12, [rsp+0xB0]
00007c454bbd7282  vmovaps xmm13, [rsp+0xC0]
00007c454bbd728b  vmovaps xmm14, [rsp+0xD0]
00007c454bbd7294  vmovaps xmm15, [rsp+0xE0]
00007c454bbd729d  add rsp, 0xF0
00007c454bbd72a4  pop r11
00007c454bbd72a6  pop r10
00007c454bbd72a8  pop r9
00007c454bbd72aa  pop r8
00007c454bbd72ac  pop rsi
00007c454bbd72ad  pop rdi
00007c454bbd72ae  pop rdx
00007c454bbd72af  pop rcx
00007c454bbd72b0  pop rax
00007c454bbd72b1  add rsp, 0x08
00007c454bbd72b5  jmp 0x00007C454BBD32CF
00007c454bbd72ba  sub rsp, 0x08
00007c454bbd72be  push rax
00007c454bbd72bf  push rcx
00007c454bbd72c0  push rdx
00007c454bbd72c1  push rdi
00007c454bbd72c2  push rsi
00007c454bbd72c3  push r8
00007c454bbd72c5  push r9
00007c454bbd72c7  push r10
00007c454bbd72c9  push r11
00007c454bbd72cb  sub rsp, 0xF0
00007c454bbd72d2  vmovaps [rsp], xmm0
00007c454bbd72d7  vmovaps [rsp+0x10], xmm1
00007c454bbd72dd  vmovaps [rsp+0x20], xmm2
00007c454bbd72e3  vmovaps [rsp+0x30], xmm3
00007c454bbd72e9  vmovaps [rsp+0x40], xmm4
00007c454bbd72ef  vmovaps [rsp+0x50], xmm5
00007c454bbd72f5  vmovaps [rsp+0x60], xmm6
00007c454bbd72fb  vmovaps [rsp+0x70], xmm7
00007c454bbd7301  vmovaps [rsp+0x80], xmm8
00007c454bbd730a  vmovaps [rsp+0x90], xmm9
00007c454bbd7313  vmovaps [rsp+0xA0], xmm10
00007c454bbd731c  vmovaps [rsp+0xB0], xmm11
00007c454bbd7325  vmovaps [rsp+0xC0], xmm12
00007c454bbd732e  vmovaps [rsp+0xD0], xmm13
00007c454bbd7337  vmovaps [rsp+0xE0], xmm14
00007c454bbd7340  sub rsp, 0x30
00007c454bbd7344  movaps [rsp], xmm15
00007c454bbd7349  movaps [rsp+0x10], xmm14
00007c454bbd734f  movaps [rsp+0x20], xmm9
00007c454bbd7355  lea rdi, [rsp]
00007c454bbd7359  mov esi, 0x00
00007c454bbd735e  mov rax, 0x56A18AC54530
00007c454bbd7368  call rax
00007c454bbd736a  movaps xmm15, [rsp]
00007c454bbd736f  add rsp, 0x30
00007c454bbd7373  vmovaps xmm0, [rsp]
00007c454bbd7378  vmovaps xmm1, [rsp+0x10]
00007c454bbd737e  vmovaps xmm2, [rsp+0x20]
00007c454bbd7384  vmovaps xmm3, [rsp+0x30]
00007c454bbd738a  vmovaps xmm4, [rsp+0x40]
00007c454bbd7390  vmovaps xmm5, [rsp+0x50]
00007c454bbd7396  vmovaps xmm6, [rsp+0x60]
00007c454bbd739c  vmovaps xmm7, [rsp+0x70]
00007c454bbd73a2  vmovaps xmm8, [rsp+0x80]
00007c454bbd73ab  vmovaps xmm9, [rsp+0x90]
00007c454bbd73b4  vmovaps xmm10, [rsp+0xA0]
00007c454bbd73bd  vmovaps xmm11, [rsp+0xB0]
00007c454bbd73c6  vmovaps xmm12, [rsp+0xC0]
00007c454bbd73cf  vmovaps xmm13, [rsp+0xD0]
00007c454bbd73d8  vmovaps xmm14, [rsp+0xE0]
00007c454bbd73e1  add rsp, 0xF0
00007c454bbd73e8  pop r11
00007c454bbd73ea  pop r10
00007c454bbd73ec  pop r9
00007c454bbd73ee  pop r8
00007c454bbd73f0  pop rsi
00007c454bbd73f1  pop rdi
00007c454bbd73f2  pop rdx
00007c454bbd73f3  pop rcx
00007c454bbd73f4  pop rax
00007c454bbd73f5  add rsp, 0x08
00007c454bbd73f9  jmp 0x00007C454BBD32E9
00007c454bbd73fe  sub rsp, 0x08
00007c454bbd7402  push rax
00007c454bbd7403  push rcx
00007c454bbd7404  push rdx
00007c454bbd7405  push rdi
00007c454bbd7406  push rsi
00007c454bbd7407  push r8
00007c454bbd7409  push r9
00007c454bbd740b  push r10
00007c454bbd740d  push r11
00007c454bbd740f  sub rsp, 0xF0
00007c454bbd7416  vmovaps [rsp], xmm0
00007c454bbd741b  vmovaps [rsp+0x10], xmm1
00007c454bbd7421  vmovaps [rsp+0x20], xmm2
00007c454bbd7427  vmovaps [rsp+0x30], xmm3
00007c454bbd742d  vmovaps [rsp+0x40], xmm4
00007c454bbd7433  vmovaps [rsp+0x50], xmm5
00007c454bbd7439  vmovaps [rsp+0x60], xmm6
00007c454bbd743f  vmovaps [rsp+0x70], xmm7
00007c454bbd7445  vmovaps [rsp+0x80], xmm8
00007c454bbd744e  vmovaps [rsp+0x90], xmm10
00007c454bbd7457  vmovaps [rsp+0xA0], xmm11
00007c454bbd7460  vmovaps [rsp+0xB0], xmm12
00007c454bbd7469  vmovaps [rsp+0xC0], xmm13
00007c454bbd7472  vmovaps [rsp+0xD0], xmm14
00007c454bbd747b  vmovaps [rsp+0xE0], xmm15
00007c454bbd7484  sub rsp, 0x30
00007c454bbd7488  movaps [rsp], xmm9
00007c454bbd748d  movaps [rsp+0x10], xmm7
00007c454bbd7492  movaps [rsp+0x20], xmm14
00007c454bbd7498  lea rdi, [rsp]
00007c454bbd749c  mov esi, 0x00
00007c454bbd74a1  mov rax, 0x56A18AC54530
00007c454bbd74ab  call rax
00007c454bbd74ad  movaps xmm9, [rsp]
00007c454bbd74b2  add rsp, 0x30
00007c454bbd74b6  vmovaps xmm0, [rsp]
00007c454bbd74bb  vmovaps xmm1, [rsp+0x10]
00007c454bbd74c1  vmovaps xmm2, [rsp+0x20]
00007c454bbd74c7  vmovaps xmm3, [rsp+0x30]
00007c454bbd74cd  vmovaps xmm4, [rsp+0x40]
00007c454bbd74d3  vmovaps xmm5, [rsp+0x50]
00007c454bbd74d9  vmovaps xmm6, [rsp+0x60]
00007c454bbd74df  vmovaps xmm7, [rsp+0x70]
00007c454bbd74e5  vmovaps xmm8, [rsp+0x80]
00007c454bbd74ee  vmovaps xmm10, [rsp+0x90]
00007c454bbd74f7  vmovaps xmm11, [rsp+0xA0]
00007c454bbd7500  vmovaps xmm12, [rsp+0xB0]
00007c454bbd7509  vmovaps xmm13, [rsp+0xC0]
00007c454bbd7512  vmovaps xmm14, [rsp+0xD0]
00007c454bbd751b  vmovaps xmm15, [rsp+0xE0]
00007c454bbd7524  add rsp, 0xF0
00007c454bbd752b  pop r11
00007c454bbd752d  pop r10
00007c454bbd752f  pop r9
00007c454bbd7531  pop r8
00007c454bbd7533  pop rsi
00007c454bbd7534  pop rdi
00007c454bbd7535  pop rdx
00007c454bbd7536  pop rcx
00007c454bbd7537  pop rax
00007c454bbd7538  add rsp, 0x08
00007c454bbd753c  jmp 0x00007C454BBD3318
00007c454bbd7541  sub rsp, 0x08
00007c454bbd7545  push rax
00007c454bbd7546  push rcx
00007c454bbd7547  push rdx
00007c454bbd7548  push rdi
00007c454bbd7549  push rsi
00007c454bbd754a  push r8
00007c454bbd754c  push r9
00007c454bbd754e  push r10
00007c454bbd7550  push r11
00007c454bbd7552  sub rsp, 0xF0
00007c454bbd7559  vmovaps [rsp], xmm0
00007c454bbd755e  vmovaps [rsp+0x10], xmm1
00007c454bbd7564  vmovaps [rsp+0x20], xmm2
00007c454bbd756a  vmovaps [rsp+0x30], xmm3
00007c454bbd7570  vmovaps [rsp+0x40], xmm4
00007c454bbd7576  vmovaps [rsp+0x50], xmm5
00007c454bbd757c  vmovaps [rsp+0x60], xmm6
00007c454bbd7582  vmovaps [rsp+0x70], xmm7
00007c454bbd7588  vmovaps [rsp+0x80], xmm8
00007c454bbd7591  vmovaps [rsp+0x90], xmm9
00007c454bbd759a  vmovaps [rsp+0xA0], xmm10
00007c454bbd75a3  vmovaps [rsp+0xB0], xmm11
00007c454bbd75ac  vmovaps [rsp+0xC0], xmm12
00007c454bbd75b5  vmovaps [rsp+0xD0], xmm13
00007c454bbd75be  vmovaps [rsp+0xE0], xmm15
00007c454bbd75c7  sub rsp, 0x30
00007c454bbd75cb  movaps [rsp], xmm14
00007c454bbd75d0  movaps [rsp+0x10], xmm13
00007c454bbd75d6  movaps [rsp+0x20], xmm11
00007c454bbd75dc  lea rdi, [rsp]
00007c454bbd75e0  mov esi, 0x00
00007c454bbd75e5  mov rax, 0x56A18AC54530
00007c454bbd75ef  call rax
00007c454bbd75f1  movaps xmm14, [rsp]
00007c454bbd75f6  add rsp, 0x30
00007c454bbd75fa  vmovaps xmm0, [rsp]
00007c454bbd75ff  vmovaps xmm1, [rsp+0x10]
00007c454bbd7605  vmovaps xmm2, [rsp+0x20]
00007c454bbd760b  vmovaps xmm3, [rsp+0x30]
00007c454bbd7611  vmovaps xmm4, [rsp+0x40]
00007c454bbd7617  vmovaps xmm5, [rsp+0x50]
00007c454bbd761d  vmovaps xmm6, [rsp+0x60]
00007c454bbd7623  vmovaps xmm7, [rsp+0x70]
00007c454bbd7629  vmovaps xmm8, [rsp+0x80]
00007c454bbd7632  vmovaps xmm9, [rsp+0x90]
00007c454bbd763b  vmovaps xmm10, [rsp+0xA0]
00007c454bbd7644  vmovaps xmm11, [rsp+0xB0]
00007c454bbd764d  vmovaps xmm12, [rsp+0xC0]
00007c454bbd7656  vmovaps xmm13, [rsp+0xD0]
00007c454bbd765f  vmovaps xmm15, [rsp+0xE0]
00007c454bbd7668  add rsp, 0xF0
00007c454bbd766f  pop r11
00007c454bbd7671  pop r10
00007c454bbd7673  pop r9
00007c454bbd7675  pop r8
00007c454bbd7677  pop rsi
00007c454bbd7678  pop rdi
00007c454bbd7679  pop rdx
00007c454bbd767a  pop rcx
00007c454bbd767b  pop rax
00007c454bbd767c  add rsp, 0x08
00007c454bbd7680  jmp 0x00007C454BBD3332
00007c454bbd7685  sub rsp, 0x08
00007c454bbd7689  push rax
00007c454bbd768a  push rcx
00007c454bbd768b  push rdx
00007c454bbd768c  push rdi
00007c454bbd768d  push rsi
00007c454bbd768e  push r8
00007c454bbd7690  push r9
00007c454bbd7692  push r10
00007c454bbd7694  push r11
00007c454bbd7696  sub rsp, 0xF0
00007c454bbd769d  vmovaps [rsp], xmm0
00007c454bbd76a2  vmovaps [rsp+0x10], xmm1
00007c454bbd76a8  vmovaps [rsp+0x20], xmm2
00007c454bbd76ae  vmovaps [rsp+0x30], xmm3
00007c454bbd76b4  vmovaps [rsp+0x40], xmm4
00007c454bbd76ba  vmovaps [rsp+0x50], xmm5
00007c454bbd76c0  vmovaps [rsp+0x60], xmm6
00007c454bbd76c6  vmovaps [rsp+0x70], xmm7
00007c454bbd76cc  vmovaps [rsp+0x80], xmm8
00007c454bbd76d5  vmovaps [rsp+0x90], xmm9
00007c454bbd76de  vmovaps [rsp+0xA0], xmm10
00007c454bbd76e7  vmovaps [rsp+0xB0], xmm12
00007c454bbd76f0  vmovaps [rsp+0xC0], xmm13
00007c454bbd76f9  vmovaps [rsp+0xD0], xmm14
00007c454bbd7702  vmovaps [rsp+0xE0], xmm15
00007c454bbd770b  sub rsp, 0x30
00007c454bbd770f  movaps [rsp], xmm11
00007c454bbd7714  movaps [rsp+0x10], xmm7
00007c454bbd7719  movaps [rsp+0x20], xmm13
00007c454bbd771f  lea rdi, [rsp]
00007c454bbd7723  mov esi, 0x00
00007c454bbd7728  mov rax, 0x56A18AC54530
00007c454bbd7732  call rax
00007c454bbd7734  movaps xmm11, [rsp]
00007c454bbd7739  add rsp, 0x30
00007c454bbd773d  vmovaps xmm0, [rsp]
00007c454bbd7742  vmovaps xmm1, [rsp+0x10]
00007c454bbd7748  vmovaps xmm2, [rsp+0x20]
00007c454bbd774e  vmovaps xmm3, [rsp+0x30]
00007c454bbd7754  vmovaps xmm4, [rsp+0x40]
00007c454bbd775a  vmovaps xmm5, [rsp+0x50]
00007c454bbd7760  vmovaps xmm6, [rsp+0x60]
00007c454bbd7766  vmovaps xmm7, [rsp+0x70]
00007c454bbd776c  vmovaps xmm8, [rsp+0x80]
00007c454bbd7775  vmovaps xmm9, [rsp+0x90]
00007c454bbd777e  vmovaps xmm10, [rsp+0xA0]
00007c454bbd7787  vmovaps xmm12, [rsp+0xB0]
00007c454bbd7790  vmovaps xmm13, [rsp+0xC0]
00007c454bbd7799  vmovaps xmm14, [rsp+0xD0]
00007c454bbd77a2  vmovaps xmm15, [rsp+0xE0]
00007c454bbd77ab  add rsp, 0xF0
00007c454bbd77b2  pop r11
00007c454bbd77b4  pop r10
00007c454bbd77b6  pop r9
00007c454bbd77b8  pop r8
00007c454bbd77ba  pop rsi
00007c454bbd77bb  pop rdi
00007c454bbd77bc  pop rdx
00007c454bbd77bd  pop rcx
00007c454bbd77be  pop rax
00007c454bbd77bf  add rsp, 0x08
00007c454bbd77c3  jmp 0x00007C454BBD335E
00007c454bbd77c8  sub rsp, 0x08
00007c454bbd77cc  push rax
00007c454bbd77cd  push rcx
00007c454bbd77ce  push rdx
00007c454bbd77cf  push rdi
00007c454bbd77d0  push rsi
00007c454bbd77d1  push r8
00007c454bbd77d3  push r9
00007c454bbd77d5  push r10
00007c454bbd77d7  push r11
00007c454bbd77d9  sub rsp, 0xF0
00007c454bbd77e0  vmovaps [rsp], xmm0
00007c454bbd77e5  vmovaps [rsp+0x10], xmm1
00007c454bbd77eb  vmovaps [rsp+0x20], xmm2
00007c454bbd77f1  vmovaps [rsp+0x30], xmm3
00007c454bbd77f7  vmovaps [rsp+0x40], xmm4
00007c454bbd77fd  vmovaps [rsp+0x50], xmm5
00007c454bbd7803  vmovaps [rsp+0x60], xmm6
00007c454bbd7809  vmovaps [rsp+0x70], xmm7
00007c454bbd780f  vmovaps [rsp+0x80], xmm8
00007c454bbd7818  vmovaps [rsp+0x90], xmm9
00007c454bbd7821  vmovaps [rsp+0xA0], xmm10
00007c454bbd782a  vmovaps [rsp+0xB0], xmm11
00007c454bbd7833  vmovaps [rsp+0xC0], xmm12
00007c454bbd783c  vmovaps [rsp+0xD0], xmm14
00007c454bbd7845  vmovaps [rsp+0xE0], xmm15
00007c454bbd784e  sub rsp, 0x30
00007c454bbd7852  movaps [rsp], xmm13
00007c454bbd7857  movaps [rsp+0x10], xmm10
00007c454bbd785d  movaps [rsp+0x20], xmm12
00007c454bbd7863  lea rdi, [rsp]
00007c454bbd7867  mov esi, 0x00
00007c454bbd786c  mov rax, 0x56A18AC54530
00007c454bbd7876  call rax
00007c454bbd7878  movaps xmm13, [rsp]
00007c454bbd787d  add rsp, 0x30
00007c454bbd7881  vmovaps xmm0, [rsp]
00007c454bbd7886  vmovaps xmm1, [rsp+0x10]
00007c454bbd788c  vmovaps xmm2, [rsp+0x20]
00007c454bbd7892  vmovaps xmm3, [rsp+0x30]
00007c454bbd7898  vmovaps xmm4, [rsp+0x40]
00007c454bbd789e  vmovaps xmm5, [rsp+0x50]
00007c454bbd78a4  vmovaps xmm6, [rsp+0x60]
00007c454bbd78aa  vmovaps xmm7, [rsp+0x70]
00007c454bbd78b0  vmovaps xmm8, [rsp+0x80]
00007c454bbd78b9  vmovaps xmm9, [rsp+0x90]
00007c454bbd78c2  vmovaps xmm10, [rsp+0xA0]
00007c454bbd78cb  vmovaps xmm11, [rsp+0xB0]
00007c454bbd78d4  vmovaps xmm12, [rsp+0xC0]
00007c454bbd78dd  vmovaps xmm14, [rsp+0xD0]
00007c454bbd78e6  vmovaps xmm15, [rsp+0xE0]
00007c454bbd78ef  add rsp, 0xF0
00007c454bbd78f6  pop r11
00007c454bbd78f8  pop r10
00007c454bbd78fa  pop r9
00007c454bbd78fc  pop r8
00007c454bbd78fe  pop rsi
00007c454bbd78ff  pop rdi
00007c454bbd7900  pop rdx
00007c454bbd7901  pop rcx
00007c454bbd7902  pop rax
00007c454bbd7903  add rsp, 0x08
00007c454bbd7907  jmp 0x00007C454BBD3378
00007c454bbd790c  sub rsp, 0x08
00007c454bbd7910  push rax
00007c454bbd7911  push rcx
00007c454bbd7912  push rdx
00007c454bbd7913  push rdi
00007c454bbd7914  push rsi
00007c454bbd7915  push r8
00007c454bbd7917  push r9
00007c454bbd7919  push r10
00007c454bbd791b  push r11
00007c454bbd791d  sub rsp, 0xF0
00007c454bbd7924  vmovaps [rsp], xmm0
00007c454bbd7929  vmovaps [rsp+0x10], xmm1
00007c454bbd792f  vmovaps [rsp+0x20], xmm2
00007c454bbd7935  vmovaps [rsp+0x30], xmm3
00007c454bbd793b  vmovaps [rsp+0x40], xmm4
00007c454bbd7941  vmovaps [rsp+0x50], xmm5
00007c454bbd7947  vmovaps [rsp+0x60], xmm6
00007c454bbd794d  vmovaps [rsp+0x70], xmm7
00007c454bbd7953  vmovaps [rsp+0x80], xmm8
00007c454bbd795c  vmovaps [rsp+0x90], xmm9
00007c454bbd7965  vmovaps [rsp+0xA0], xmm11
00007c454bbd796e  vmovaps [rsp+0xB0], xmm12
00007c454bbd7977  vmovaps [rsp+0xC0], xmm13
00007c454bbd7980  vmovaps [rsp+0xD0], xmm14
00007c454bbd7989  vmovaps [rsp+0xE0], xmm15
00007c454bbd7992  sub rsp, 0x30
00007c454bbd7996  movaps [rsp], xmm10
00007c454bbd799b  movaps [rsp+0x10], xmm7
00007c454bbd79a0  movaps [rsp+0x20], xmm12
00007c454bbd79a6  lea rdi, [rsp]
00007c454bbd79aa  mov esi, 0x00
00007c454bbd79af  mov rax, 0x56A18AC54530
00007c454bbd79b9  call rax
00007c454bbd79bb  movaps xmm10, [rsp]
00007c454bbd79c0  add rsp, 0x30
00007c454bbd79c4  vmovaps xmm0, [rsp]
00007c454bbd79c9  vmovaps xmm1, [rsp+0x10]
00007c454bbd79cf  vmovaps xmm2, [rsp+0x20]
00007c454bbd79d5  vmovaps xmm3, [rsp+0x30]
00007c454bbd79db  vmovaps xmm4, [rsp+0x40]
00007c454bbd79e1  vmovaps xmm5, [rsp+0x50]
00007c454bbd79e7  vmovaps xmm6, [rsp+0x60]
00007c454bbd79ed  vmovaps xmm7, [rsp+0x70]
00007c454bbd79f3  vmovaps xmm8, [rsp+0x80]
00007c454bbd79fc  vmovaps xmm9, [rsp+0x90]
00007c454bbd7a05  vmovaps xmm11, [rsp+0xA0]
00007c454bbd7a0e  vmovaps xmm12, [rsp+0xB0]
00007c454bbd7a17  vmovaps xmm13, [rsp+0xC0]
00007c454bbd7a20  vmovaps xmm14, [rsp+0xD0]
00007c454bbd7a29  vmovaps xmm15, [rsp+0xE0]
00007c454bbd7a32  add rsp, 0xF0
00007c454bbd7a39  pop r11
00007c454bbd7a3b  pop r10
00007c454bbd7a3d  pop r9
00007c454bbd7a3f  pop r8
00007c454bbd7a41  pop rsi
00007c454bbd7a42  pop rdi
00007c454bbd7a43  pop rdx
00007c454bbd7a44  pop rcx
00007c454bbd7a45  pop rax
00007c454bbd7a46  add rsp, 0x08
00007c454bbd7a4a  jmp 0x00007C454BBD33A4
00007c454bbd7a4f  sub rsp, 0x08
00007c454bbd7a53  push rax
00007c454bbd7a54  push rcx
00007c454bbd7a55  push rdx
00007c454bbd7a56  push rdi
00007c454bbd7a57  push rsi
00007c454bbd7a58  push r8
00007c454bbd7a5a  push r9
00007c454bbd7a5c  push r10
00007c454bbd7a5e  push r11
00007c454bbd7a60  sub rsp, 0xF0
00007c454bbd7a67  vmovaps [rsp], xmm0
00007c454bbd7a6c  vmovaps [rsp+0x10], xmm1
00007c454bbd7a72  vmovaps [rsp+0x20], xmm2
00007c454bbd7a78  vmovaps [rsp+0x30], xmm3
00007c454bbd7a7e  vmovaps [rsp+0x40], xmm4
00007c454bbd7a84  vmovaps [rsp+0x50], xmm5
00007c454bbd7a8a  vmovaps [rsp+0x60], xmm6
00007c454bbd7a90  vmovaps [rsp+0x70], xmm7
00007c454bbd7a96  vmovaps [rsp+0x80], xmm8
00007c454bbd7a9f  vmovaps [rsp+0x90], xmm9
00007c454bbd7aa8  vmovaps [rsp+0xA0], xmm10
00007c454bbd7ab1  vmovaps [rsp+0xB0], xmm11
00007c454bbd7aba  vmovaps [rsp+0xC0], xmm13
00007c454bbd7ac3  vmovaps [rsp+0xD0], xmm14
00007c454bbd7acc  vmovaps [rsp+0xE0], xmm15
00007c454bbd7ad5  sub rsp, 0x30
00007c454bbd7ad9  movaps [rsp], xmm12
00007c454bbd7ade  movaps [rsp+0x10], xmm1
00007c454bbd7ae3  movaps [rsp+0x20], xmm8
00007c454bbd7ae9  lea rdi, [rsp]
00007c454bbd7aed  mov esi, 0x00
00007c454bbd7af2  mov rax, 0x56A18AC54530
00007c454bbd7afc  call rax
00007c454bbd7afe  movaps xmm12, [rsp]
00007c454bbd7b03  add rsp, 0x30
00007c454bbd7b07  vmovaps xmm0, [rsp]
00007c454bbd7b0c  vmovaps xmm1, [rsp+0x10]
00007c454bbd7b12  vmovaps xmm2, [rsp+0x20]
00007c454bbd7b18  vmovaps xmm3, [rsp+0x30]
00007c454bbd7b1e  vmovaps xmm4, [rsp+0x40]
00007c454bbd7b24  vmovaps xmm5, [rsp+0x50]
00007c454bbd7b2a  vmovaps xmm6, [rsp+0x60]
00007c454bbd7b30  vmovaps xmm7, [rsp+0x70]
00007c454bbd7b36  vmovaps xmm8, [rsp+0x80]
00007c454bbd7b3f  vmovaps xmm9, [rsp+0x90]
00007c454bbd7b48  vmovaps xmm10, [rsp+0xA0]
00007c454bbd7b51  vmovaps xmm11, [rsp+0xB0]
00007c454bbd7b5a  vmovaps xmm13, [rsp+0xC0]
00007c454bbd7b63  vmovaps xmm14, [rsp+0xD0]
00007c454bbd7b6c  vmovaps xmm15, [rsp+0xE0]
00007c454bbd7b75  add rsp, 0xF0
00007c454bbd7b7c  pop r11
00007c454bbd7b7e  pop r10
00007c454bbd7b80  pop r9
00007c454bbd7b82  pop r8
00007c454bbd7b84  pop rsi
00007c454bbd7b85  pop rdi
00007c454bbd7b86  pop rdx
00007c454bbd7b87  pop rcx
00007c454bbd7b88  pop rax
00007c454bbd7b89  add rsp, 0x08
00007c454bbd7b8d  jmp 0x00007C454BBD33BE
00007c454bbd7b92  call 0x00007C454B9FF430
00007c454bbd7b97  jmp 0x00007C454BBD33C8
00007c454bbd7b9c  sub rsp, 0x08
00007c454bbd7ba0  push rax
00007c454bbd7ba1  push rcx
00007c454bbd7ba2  push rdx
00007c454bbd7ba3  push rdi
00007c454bbd7ba4  push rsi
00007c454bbd7ba5  push r8
00007c454bbd7ba7  push r9
00007c454bbd7ba9  push r10
00007c454bbd7bab  push r11
00007c454bbd7bad  sub rsp, 0xF0
00007c454bbd7bb4  vmovaps [rsp], xmm0
00007c454bbd7bb9  vmovaps [rsp+0x10], xmm1
00007c454bbd7bbf  vmovaps [rsp+0x20], xmm2
00007c454bbd7bc5  vmovaps [rsp+0x30], xmm3
00007c454bbd7bcb  vmovaps [rsp+0x40], xmm4
00007c454bbd7bd1  vmovaps [rsp+0x50], xmm5
00007c454bbd7bd7  vmovaps [rsp+0x60], xmm6
00007c454bbd7bdd  vmovaps [rsp+0x70], xmm7
00007c454bbd7be3  vmovaps [rsp+0x80], xmm9
00007c454bbd7bec  vmovaps [rsp+0x90], xmm10
00007c454bbd7bf5  vmovaps [rsp+0xA0], xmm11
00007c454bbd7bfe  vmovaps [rsp+0xB0], xmm12
00007c454bbd7c07  vmovaps [rsp+0xC0], xmm13
00007c454bbd7c10  vmovaps [rsp+0xD0], xmm14
00007c454bbd7c19  vmovaps [rsp+0xE0], xmm15
00007c454bbd7c22  sub rsp, 0x30
00007c454bbd7c26  movaps [rsp], xmm8
00007c454bbd7c2b  movaps [rsp+0x10], xmm15
00007c454bbd7c31  movaps [rsp+0x20], xmm9
00007c454bbd7c37  lea rdi, [rsp]
00007c454bbd7c3b  mov esi, 0x00
00007c454bbd7c40  mov rax, 0x56A18AC54530
00007c454bbd7c4a  call rax
00007c454bbd7c4c  movaps xmm8, [rsp]
00007c454bbd7c51  add rsp, 0x30
00007c454bbd7c55  vmovaps xmm0, [rsp]
00007c454bbd7c5a  vmovaps xmm1, [rsp+0x10]
00007c454bbd7c60  vmovaps xmm2, [rsp+0x20]
00007c454bbd7c66  vmovaps xmm3, [rsp+0x30]
00007c454bbd7c6c  vmovaps xmm4, [rsp+0x40]
00007c454bbd7c72  vmovaps xmm5, [rsp+0x50]
00007c454bbd7c78  vmovaps xmm6, [rsp+0x60]
00007c454bbd7c7e  vmovaps xmm7, [rsp+0x70]
00007c454bbd7c84  vmovaps xmm9, [rsp+0x80]
00007c454bbd7c8d  vmovaps xmm10, [rsp+0x90]
00007c454bbd7c96  vmovaps xmm11, [rsp+0xA0]
00007c454bbd7c9f  vmovaps xmm12, [rsp+0xB0]
00007c454bbd7ca8  vmovaps xmm13, [rsp+0xC0]
00007c454bbd7cb1  vmovaps xmm14, [rsp+0xD0]
00007c454bbd7cba  vmovaps xmm15, [rsp+0xE0]
00007c454bbd7cc3  add rsp, 0xF0
00007c454bbd7cca  pop r11
00007c454bbd7ccc  pop r10
00007c454bbd7cce  pop r9
00007c454bbd7cd0  pop r8
00007c454bbd7cd2  pop rsi
00007c454bbd7cd3  pop rdi
00007c454bbd7cd4  pop rdx
00007c454bbd7cd5  pop rcx
00007c454bbd7cd6  pop rax
00007c454bbd7cd7  add rsp, 0x08
00007c454bbd7cdb  jmp 0x00007C454BBD33EA
00007c454bbd7ce0  sub rsp, 0x08
00007c454bbd7ce4  push rax
00007c454bbd7ce5  push rcx
00007c454bbd7ce6  push rdx
00007c454bbd7ce7  push rdi
00007c454bbd7ce8  push rsi
00007c454bbd7ce9  push r8
00007c454bbd7ceb  push r9
00007c454bbd7ced  push r10
00007c454bbd7cef  push r11
00007c454bbd7cf1  sub rsp, 0xF0
00007c454bbd7cf8  vmovaps [rsp], xmm0
00007c454bbd7cfd  vmovaps [rsp+0x10], xmm1
00007c454bbd7d03  vmovaps [rsp+0x20], xmm2
00007c454bbd7d09  vmovaps [rsp+0x30], xmm3
00007c454bbd7d0f  vmovaps [rsp+0x40], xmm4
00007c454bbd7d15  vmovaps [rsp+0x50], xmm5
00007c454bbd7d1b  vmovaps [rsp+0x60], xmm6
00007c454bbd7d21  vmovaps [rsp+0x70], xmm7
00007c454bbd7d27  vmovaps [rsp+0x80], xmm8
00007c454bbd7d30  vmovaps [rsp+0x90], xmm10
00007c454bbd7d39  vmovaps [rsp+0xA0], xmm11
00007c454bbd7d42  vmovaps [rsp+0xB0], xmm12
00007c454bbd7d4b  vmovaps [rsp+0xC0], xmm13
00007c454bbd7d54  vmovaps [rsp+0xD0], xmm14
00007c454bbd7d5d  vmovaps [rsp+0xE0], xmm15
00007c454bbd7d66  sub rsp, 0x30
00007c454bbd7d6a  movaps [rsp], xmm9
00007c454bbd7d6f  movaps [rsp+0x10], xmm1
00007c454bbd7d74  movaps [rsp+0x20], xmm15
00007c454bbd7d7a  lea rdi, [rsp]
00007c454bbd7d7e  mov esi, 0x00
00007c454bbd7d83  mov rax, 0x56A18AC54530
00007c454bbd7d8d  call rax
00007c454bbd7d8f  movaps xmm9, [rsp]
00007c454bbd7d94  add rsp, 0x30
00007c454bbd7d98  vmovaps xmm0, [rsp]
00007c454bbd7d9d  vmovaps xmm1, [rsp+0x10]
00007c454bbd7da3  vmovaps xmm2, [rsp+0x20]
00007c454bbd7da9  vmovaps xmm3, [rsp+0x30]
00007c454bbd7daf  vmovaps xmm4, [rsp+0x40]
00007c454bbd7db5  vmovaps xmm5, [rsp+0x50]
00007c454bbd7dbb  vmovaps xmm6, [rsp+0x60]
00007c454bbd7dc1  vmovaps xmm7, [rsp+0x70]
00007c454bbd7dc7  vmovaps xmm8, [rsp+0x80]
00007c454bbd7dd0  vmovaps xmm10, [rsp+0x90]
00007c454bbd7dd9  vmovaps xmm11, [rsp+0xA0]
00007c454bbd7de2  vmovaps xmm12, [rsp+0xB0]
00007c454bbd7deb  vmovaps xmm13, [rsp+0xC0]
00007c454bbd7df4  vmovaps xmm14, [rsp+0xD0]
00007c454bbd7dfd  vmovaps xmm15, [rsp+0xE0]
00007c454bbd7e06  add rsp, 0xF0
00007c454bbd7e0d  pop r11
00007c454bbd7e0f  pop r10
00007c454bbd7e11  pop r9
00007c454bbd7e13  pop r8
00007c454bbd7e15  pop rsi
00007c454bbd7e16  pop rdi
00007c454bbd7e17  pop rdx
00007c454bbd7e18  pop rcx
00007c454bbd7e19  pop rax
00007c454bbd7e1a  add rsp, 0x08
00007c454bbd7e1e  jmp 0x00007C454BBD3418
00007c454bbd7e23  sub rsp, 0x08
00007c454bbd7e27  push rax
00007c454bbd7e28  push rcx
00007c454bbd7e29  push rdx
00007c454bbd7e2a  push rdi
00007c454bbd7e2b  push rsi
00007c454bbd7e2c  push r8
00007c454bbd7e2e  push r9
00007c454bbd7e30  push r10
00007c454bbd7e32  push r11
00007c454bbd7e34  sub rsp, 0xF0
00007c454bbd7e3b  vmovaps [rsp], xmm0
00007c454bbd7e40  vmovaps [rsp+0x10], xmm1
00007c454bbd7e46  vmovaps [rsp+0x20], xmm2
00007c454bbd7e4c  vmovaps [rsp+0x30], xmm3
00007c454bbd7e52  vmovaps [rsp+0x40], xmm4
00007c454bbd7e58  vmovaps [rsp+0x50], xmm5
00007c454bbd7e5e  vmovaps [rsp+0x60], xmm6
00007c454bbd7e64  vmovaps [rsp+0x70], xmm7
00007c454bbd7e6a  vmovaps [rsp+0x80], xmm8
00007c454bbd7e73  vmovaps [rsp+0x90], xmm9
00007c454bbd7e7c  vmovaps [rsp+0xA0], xmm10
00007c454bbd7e85  vmovaps [rsp+0xB0], xmm11
00007c454bbd7e8e  vmovaps [rsp+0xC0], xmm12
00007c454bbd7e97  vmovaps [rsp+0xD0], xmm13
00007c454bbd7ea0  vmovaps [rsp+0xE0], xmm14
00007c454bbd7ea9  sub rsp, 0x30
00007c454bbd7ead  movaps [rsp], xmm15
00007c454bbd7eb2  movaps [rsp+0x10], xmm4
00007c454bbd7eb7  movaps [rsp+0x20], xmm1
00007c454bbd7ebc  lea rdi, [rsp]
00007c454bbd7ec0  mov esi, 0x00
00007c454bbd7ec5  mov rax, 0x56A18AC54530
00007c454bbd7ecf  call rax
00007c454bbd7ed1  movaps xmm15, [rsp]
00007c454bbd7ed6  add rsp, 0x30
00007c454bbd7eda  vmovaps xmm0, [rsp]
00007c454bbd7edf  vmovaps xmm1, [rsp+0x10]
00007c454bbd7ee5  vmovaps xmm2, [rsp+0x20]
00007c454bbd7eeb  vmovaps xmm3, [rsp+0x30]
00007c454bbd7ef1  vmovaps xmm4, [rsp+0x40]
00007c454bbd7ef7  vmovaps xmm5, [rsp+0x50]
00007c454bbd7efd  vmovaps xmm6, [rsp+0x60]
00007c454bbd7f03  vmovaps xmm7, [rsp+0x70]
00007c454bbd7f09  vmovaps xmm8, [rsp+0x80]
00007c454bbd7f12  vmovaps xmm9, [rsp+0x90]
00007c454bbd7f1b  vmovaps xmm10, [rsp+0xA0]
00007c454bbd7f24  vmovaps xmm11, [rsp+0xB0]
00007c454bbd7f2d  vmovaps xmm12, [rsp+0xC0]
00007c454bbd7f36  vmovaps xmm13, [rsp+0xD0]
00007c454bbd7f3f  vmovaps xmm14, [rsp+0xE0]
00007c454bbd7f48  add rsp, 0xF0
00007c454bbd7f4f  pop r11
00007c454bbd7f51  pop r10
00007c454bbd7f53  pop r9
00007c454bbd7f55  pop r8
00007c454bbd7f57  pop rsi
00007c454bbd7f58  pop rdi
00007c454bbd7f59  pop rdx
00007c454bbd7f5a  pop rcx
00007c454bbd7f5b  pop rax
00007c454bbd7f5c  add rsp, 0x08
00007c454bbd7f60  jmp 0x00007C454BBD343E
00007c454bbd7f65  sub rsp, 0x08
00007c454bbd7f69  push rax
00007c454bbd7f6a  push rcx
00007c454bbd7f6b  push rdx
00007c454bbd7f6c  push rdi
00007c454bbd7f6d  push rsi
00007c454bbd7f6e  push r8
00007c454bbd7f70  push r9
00007c454bbd7f72  push r10
00007c454bbd7f74  push r11
00007c454bbd7f76  sub rsp, 0xF0
00007c454bbd7f7d  vmovaps [rsp], xmm0
00007c454bbd7f82  vmovaps [rsp+0x10], xmm2
00007c454bbd7f88  vmovaps [rsp+0x20], xmm3
00007c454bbd7f8e  vmovaps [rsp+0x30], xmm4
00007c454bbd7f94  vmovaps [rsp+0x40], xmm5
00007c454bbd7f9a  vmovaps [rsp+0x50], xmm6
00007c454bbd7fa0  vmovaps [rsp+0x60], xmm7
00007c454bbd7fa6  vmovaps [rsp+0x70], xmm8
00007c454bbd7fac  vmovaps [rsp+0x80], xmm9
00007c454bbd7fb5  vmovaps [rsp+0x90], xmm10
00007c454bbd7fbe  vmovaps [rsp+0xA0], xmm11
00007c454bbd7fc7  vmovaps [rsp+0xB0], xmm12
00007c454bbd7fd0  vmovaps [rsp+0xC0], xmm13
00007c454bbd7fd9  vmovaps [rsp+0xD0], xmm14
00007c454bbd7fe2  vmovaps [rsp+0xE0], xmm15
00007c454bbd7feb  sub rsp, 0x30
00007c454bbd7fef  movaps [rsp], xmm1
00007c454bbd7ff3  movaps [rsp+0x10], xmm14
00007c454bbd7ff9  movaps [rsp+0x20], xmm11
00007c454bbd7fff  lea rdi, [rsp]
00007c454bbd8003  mov esi, 0x00
00007c454bbd8008  mov rax, 0x56A18AC54530
00007c454bbd8012  call rax
00007c454bbd8014  movaps xmm1, [rsp]
00007c454bbd8018  add rsp, 0x30
00007c454bbd801c  vmovaps xmm0, [rsp]
00007c454bbd8021  vmovaps xmm2, [rsp+0x10]
00007c454bbd8027  vmovaps xmm3, [rsp+0x20]
00007c454bbd802d  vmovaps xmm4, [rsp+0x30]
00007c454bbd8033  vmovaps xmm5, [rsp+0x40]
00007c454bbd8039  vmovaps xmm6, [rsp+0x50]
00007c454bbd803f  vmovaps xmm7, [rsp+0x60]
00007c454bbd8045  vmovaps xmm8, [rsp+0x70]
00007c454bbd804b  vmovaps xmm9, [rsp+0x80]
00007c454bbd8054  vmovaps xmm10, [rsp+0x90]
00007c454bbd805d  vmovaps xmm11, [rsp+0xA0]
00007c454bbd8066  vmovaps xmm12, [rsp+0xB0]
00007c454bbd806f  vmovaps xmm13, [rsp+0xC0]
00007c454bbd8078  vmovaps xmm14, [rsp+0xD0]
00007c454bbd8081  vmovaps xmm15, [rsp+0xE0]
00007c454bbd808a  add rsp, 0xF0
00007c454bbd8091  pop r11
00007c454bbd8093  pop r10
00007c454bbd8095  pop r9
00007c454bbd8097  pop r8
00007c454bbd8099  pop rsi
00007c454bbd809a  pop rdi
00007c454bbd809b  pop rdx
00007c454bbd809c  pop rcx
00007c454bbd809d  pop rax
00007c454bbd809e  add rsp, 0x08
00007c454bbd80a2  jmp 0x00007C454BBD345F
00007c454bbd80a7  call 0x00007C454BAE45A0
00007c454bbd80ac  jmp 0x00007C454BBD346D
00007c454bbd80b1  call 0x00007C454BA09D70
00007c454bbd80b6  jmp 0x00007C454BBD3477
00007c454bbd80bb  sub rsp, 0x08
00007c454bbd80bf  push rax
00007c454bbd80c0  push rcx
00007c454bbd80c1  push rdx
00007c454bbd80c2  push rdi
00007c454bbd80c3  push rsi
00007c454bbd80c4  push r8
00007c454bbd80c6  push r9
00007c454bbd80c8  push r10
00007c454bbd80ca  push r11
00007c454bbd80cc  sub rsp, 0xF0
00007c454bbd80d3  vmovaps [rsp], xmm0
00007c454bbd80d8  vmovaps [rsp+0x10], xmm1
00007c454bbd80de  vmovaps [rsp+0x20], xmm2
00007c454bbd80e4  vmovaps [rsp+0x30], xmm3
00007c454bbd80ea  vmovaps [rsp+0x40], xmm4
00007c454bbd80f0  vmovaps [rsp+0x50], xmm5
00007c454bbd80f6  vmovaps [rsp+0x60], xmm6
00007c454bbd80fc  vmovaps [rsp+0x70], xmm8
00007c454bbd8102  vmovaps [rsp+0x80], xmm9
00007c454bbd810b  vmovaps [rsp+0x90], xmm10
00007c454bbd8114  vmovaps [rsp+0xA0], xmm11
00007c454bbd811d  vmovaps [rsp+0xB0], xmm12
00007c454bbd8126  vmovaps [rsp+0xC0], xmm13
00007c454bbd812f  vmovaps [rsp+0xD0], xmm14
00007c454bbd8138  vmovaps [rsp+0xE0], xmm15
00007c454bbd8141  sub rsp, 0x30
00007c454bbd8145  movaps [rsp], xmm7
00007c454bbd8149  movaps [rsp+0x10], xmm13
00007c454bbd814f  movaps [rsp+0x20], xmm10
00007c454bbd8155  lea rdi, [rsp]
00007c454bbd8159  mov esi, 0x00
00007c454bbd815e  mov rax, 0x56A18AC54530
00007c454bbd8168  call rax
00007c454bbd816a  movaps xmm7, [rsp]
00007c454bbd816e  add rsp, 0x30
00007c454bbd8172  vmovaps xmm0, [rsp]
00007c454bbd8177  vmovaps xmm1, [rsp+0x10]
00007c454bbd817d  vmovaps xmm2, [rsp+0x20]
00007c454bbd8183  vmovaps xmm3, [rsp+0x30]
00007c454bbd8189  vmovaps xmm4, [rsp+0x40]
00007c454bbd818f  vmovaps xmm5, [rsp+0x50]
00007c454bbd8195  vmovaps xmm6, [rsp+0x60]
00007c454bbd819b  vmovaps xmm8, [rsp+0x70]
00007c454bbd81a1  vmovaps xmm9, [rsp+0x80]
00007c454bbd81aa  vmovaps xmm10, [rsp+0x90]
00007c454bbd81b3  vmovaps xmm11, [rsp+0xA0]
00007c454bbd81bc  vmovaps xmm12, [rsp+0xB0]
00007c454bbd81c5  vmovaps xmm13, [rsp+0xC0]
00007c454bbd81ce  vmovaps xmm14, [rsp+0xD0]
00007c454bbd81d7  vmovaps xmm15, [rsp+0xE0]
00007c454bbd81e0  add rsp, 0xF0
00007c454bbd81e7  pop r11
00007c454bbd81e9  pop r10
00007c454bbd81eb  pop r9
00007c454bbd81ed  pop r8
00007c454bbd81ef  pop rsi
00007c454bbd81f0  pop rdi
00007c454bbd81f1  pop rdx
00007c454bbd81f2  pop rcx
00007c454bbd81f3  pop rax
00007c454bbd81f4  add rsp, 0x08
00007c454bbd81f8  jmp 0x00007C454BBD3498
00007c454bbd81fd  sub rsp, 0x08
00007c454bbd8201  push rax
00007c454bbd8202  push rcx
00007c454bbd8203  push rdx
00007c454bbd8204  push rdi
00007c454bbd8205  push rsi
00007c454bbd8206  push r8
00007c454bbd8208  push r9
00007c454bbd820a  push r10
00007c454bbd820c  push r11
00007c454bbd820e  sub rsp, 0xF0
00007c454bbd8215  vmovaps [rsp], xmm0
00007c454bbd821a  vmovaps [rsp+0x10], xmm1
00007c454bbd8220  vmovaps [rsp+0x20], xmm2
00007c454bbd8226  vmovaps [rsp+0x30], xmm3
00007c454bbd822c  vmovaps [rsp+0x40], xmm4
00007c454bbd8232  vmovaps [rsp+0x50], xmm5
00007c454bbd8238  vmovaps [rsp+0x60], xmm6
00007c454bbd823e  vmovaps [rsp+0x70], xmm7
00007c454bbd8244  vmovaps [rsp+0x80], xmm8
00007c454bbd824d  vmovaps [rsp+0x90], xmm9
00007c454bbd8256  vmovaps [rsp+0xA0], xmm11
00007c454bbd825f  vmovaps [rsp+0xB0], xmm12
00007c454bbd8268  vmovaps [rsp+0xC0], xmm13
00007c454bbd8271  vmovaps [rsp+0xD0], xmm14
00007c454bbd827a  vmovaps [rsp+0xE0], xmm15
00007c454bbd8283  sub rsp, 0x30
00007c454bbd8287  movaps [rsp], xmm10
00007c454bbd828c  movaps [rsp+0x10], xmm11
00007c454bbd8292  movaps [rsp+0x20], xmm13
00007c454bbd8298  lea rdi, [rsp]
00007c454bbd829c  mov esi, 0x00
00007c454bbd82a1  mov rax, 0x56A18AC54530
00007c454bbd82ab  call rax
00007c454bbd82ad  movaps xmm10, [rsp]
00007c454bbd82b2  add rsp, 0x30
00007c454bbd82b6  vmovaps xmm0, [rsp]
00007c454bbd82bb  vmovaps xmm1, [rsp+0x10]
00007c454bbd82c1  vmovaps xmm2, [rsp+0x20]
00007c454bbd82c7  vmovaps xmm3, [rsp+0x30]
00007c454bbd82cd  vmovaps xmm4, [rsp+0x40]
00007c454bbd82d3  vmovaps xmm5, [rsp+0x50]
00007c454bbd82d9  vmovaps xmm6, [rsp+0x60]
00007c454bbd82df  vmovaps xmm7, [rsp+0x70]
00007c454bbd82e5  vmovaps xmm8, [rsp+0x80]
00007c454bbd82ee  vmovaps xmm9, [rsp+0x90]
00007c454bbd82f7  vmovaps xmm11, [rsp+0xA0]
00007c454bbd8300  vmovaps xmm12, [rsp+0xB0]
00007c454bbd8309  vmovaps xmm13, [rsp+0xC0]
00007c454bbd8312  vmovaps xmm14, [rsp+0xD0]
00007c454bbd831b  vmovaps xmm15, [rsp+0xE0]
00007c454bbd8324  add rsp, 0xF0
00007c454bbd832b  pop r11
00007c454bbd832d  pop r10
00007c454bbd832f  pop r9
00007c454bbd8331  pop r8
00007c454bbd8333  pop rsi
00007c454bbd8334  pop rdi
00007c454bbd8335  pop rdx
00007c454bbd8336  pop rcx
00007c454bbd8337  pop rax
00007c454bbd8338  add rsp, 0x08
00007c454bbd833c  jmp 0x00007C454BBD34C6
00007c454bbd8341  sub rsp, 0x08
00007c454bbd8345  push rax
00007c454bbd8346  push rcx
00007c454bbd8347  push rdx
00007c454bbd8348  push rdi
00007c454bbd8349  push rsi
00007c454bbd834a  push r8
00007c454bbd834c  push r9
00007c454bbd834e  push r10
00007c454bbd8350  push r11
00007c454bbd8352  sub rsp, 0xF0
00007c454bbd8359  vmovaps [rsp], xmm0
00007c454bbd835e  vmovaps [rsp+0x10], xmm1
00007c454bbd8364  vmovaps [rsp+0x20], xmm2
00007c454bbd836a  vmovaps [rsp+0x30], xmm3
00007c454bbd8370  vmovaps [rsp+0x40], xmm4
00007c454bbd8376  vmovaps [rsp+0x50], xmm5
00007c454bbd837c  vmovaps [rsp+0x60], xmm6
00007c454bbd8382  vmovaps [rsp+0x70], xmm7
00007c454bbd8388  vmovaps [rsp+0x80], xmm8
00007c454bbd8391  vmovaps [rsp+0x90], xmm9
00007c454bbd839a  vmovaps [rsp+0xA0], xmm10
00007c454bbd83a3  vmovaps [rsp+0xB0], xmm12
00007c454bbd83ac  vmovaps [rsp+0xC0], xmm13
00007c454bbd83b5  vmovaps [rsp+0xD0], xmm14
00007c454bbd83be  vmovaps [rsp+0xE0], xmm15
00007c454bbd83c7  sub rsp, 0x30
00007c454bbd83cb  movaps [rsp], xmm11
00007c454bbd83d0  movaps [rsp+0x10], xmm14
00007c454bbd83d6  movaps [rsp+0x20], xmm13
00007c454bbd83dc  lea rdi, [rsp]
00007c454bbd83e0  mov esi, 0x00
00007c454bbd83e5  mov rax, 0x56A18AC54530
00007c454bbd83ef  call rax
00007c454bbd83f1  movaps xmm11, [rsp]
00007c454bbd83f6  add rsp, 0x30
00007c454bbd83fa  vmovaps xmm0, [rsp]
00007c454bbd83ff  vmovaps xmm1, [rsp+0x10]
00007c454bbd8405  vmovaps xmm2, [rsp+0x20]
00007c454bbd840b  vmovaps xmm3, [rsp+0x30]
00007c454bbd8411  vmovaps xmm4, [rsp+0x40]
00007c454bbd8417  vmovaps xmm5, [rsp+0x50]
00007c454bbd841d  vmovaps xmm6, [rsp+0x60]
00007c454bbd8423  vmovaps xmm7, [rsp+0x70]
00007c454bbd8429  vmovaps xmm8, [rsp+0x80]
00007c454bbd8432  vmovaps xmm9, [rsp+0x90]
00007c454bbd843b  vmovaps xmm10, [rsp+0xA0]
00007c454bbd8444  vmovaps xmm12, [rsp+0xB0]
00007c454bbd844d  vmovaps xmm13, [rsp+0xC0]
00007c454bbd8456  vmovaps xmm14, [rsp+0xD0]
00007c454bbd845f  vmovaps xmm15, [rsp+0xE0]
00007c454bbd8468  add rsp, 0xF0
00007c454bbd846f  pop r11
00007c454bbd8471  pop r10
00007c454bbd8473  pop r9
00007c454bbd8475  pop r8
00007c454bbd8477  pop rsi
00007c454bbd8478  pop rdi
00007c454bbd8479  pop rdx
00007c454bbd847a  pop rcx
00007c454bbd847b  pop rax
00007c454bbd847c  add rsp, 0x08
00007c454bbd8480  jmp 0x00007C454BBD34F4
00007c454bbd8485  sub rsp, 0x08
00007c454bbd8489  push rax
00007c454bbd848a  push rcx
00007c454bbd848b  push rdx
00007c454bbd848c  push rdi
00007c454bbd848d  push rsi
00007c454bbd848e  push r8
00007c454bbd8490  push r9
00007c454bbd8492  push r10
00007c454bbd8494  push r11
00007c454bbd8496  sub rsp, 0xF0
00007c454bbd849d  vmovaps [rsp], xmm0
00007c454bbd84a2  vmovaps [rsp+0x10], xmm1
00007c454bbd84a8  vmovaps [rsp+0x20], xmm2
00007c454bbd84ae  vmovaps [rsp+0x30], xmm3
00007c454bbd84b4  vmovaps [rsp+0x40], xmm4
00007c454bbd84ba  vmovaps [rsp+0x50], xmm5
00007c454bbd84c0  vmovaps [rsp+0x60], xmm6
00007c454bbd84c6  vmovaps [rsp+0x70], xmm7
00007c454bbd84cc  vmovaps [rsp+0x80], xmm8
00007c454bbd84d5  vmovaps [rsp+0x90], xmm9
00007c454bbd84de  vmovaps [rsp+0xA0], xmm10
00007c454bbd84e7  vmovaps [rsp+0xB0], xmm11
00007c454bbd84f0  vmovaps [rsp+0xC0], xmm12
00007c454bbd84f9  vmovaps [rsp+0xD0], xmm13
00007c454bbd8502  vmovaps [rsp+0xE0], xmm15
00007c454bbd850b  sub rsp, 0x30
00007c454bbd850f  movaps [rsp], xmm14
00007c454bbd8514  movaps [rsp+0x10], xmm12
00007c454bbd851a  movaps [rsp+0x20], xmm9
00007c454bbd8520  lea rdi, [rsp]
00007c454bbd8524  mov esi, 0x00
00007c454bbd8529  mov rax, 0x56A18AC54530
00007c454bbd8533  call rax
00007c454bbd8535  movaps xmm14, [rsp]
00007c454bbd853a  add rsp, 0x30
00007c454bbd853e  vmovaps xmm0, [rsp]
00007c454bbd8543  vmovaps xmm1, [rsp+0x10]
00007c454bbd8549  vmovaps xmm2, [rsp+0x20]
00007c454bbd854f  vmovaps xmm3, [rsp+0x30]
00007c454bbd8555  vmovaps xmm4, [rsp+0x40]
00007c454bbd855b  vmovaps xmm5, [rsp+0x50]
00007c454bbd8561  vmovaps xmm6, [rsp+0x60]
00007c454bbd8567  vmovaps xmm7, [rsp+0x70]
00007c454bbd856d  vmovaps xmm8, [rsp+0x80]
00007c454bbd8576  vmovaps xmm9, [rsp+0x90]
00007c454bbd857f  vmovaps xmm10, [rsp+0xA0]
00007c454bbd8588  vmovaps xmm11, [rsp+0xB0]
00007c454bbd8591  vmovaps xmm12, [rsp+0xC0]
00007c454bbd859a  vmovaps xmm13, [rsp+0xD0]
00007c454bbd85a3  vmovaps xmm15, [rsp+0xE0]
00007c454bbd85ac  add rsp, 0xF0
00007c454bbd85b3  pop r11
00007c454bbd85b5  pop r10
00007c454bbd85b7  pop r9
00007c454bbd85b9  pop r8
00007c454bbd85bb  pop rsi
00007c454bbd85bc  pop rdi
00007c454bbd85bd  pop rdx
00007c454bbd85be  pop rcx
00007c454bbd85bf  pop rax
00007c454bbd85c0  add rsp, 0x08
00007c454bbd85c4  jmp 0x00007C454BBD350F
00007c454bbd85c9  sub rsp, 0x08
00007c454bbd85cd  push rax
00007c454bbd85ce  push rcx
00007c454bbd85cf  push rdx
00007c454bbd85d0  push rdi
00007c454bbd85d1  push rsi
00007c454bbd85d2  push r8
00007c454bbd85d4  push r9
00007c454bbd85d6  push r10
00007c454bbd85d8  push r11
00007c454bbd85da  sub rsp, 0xF0
00007c454bbd85e1  vmovaps [rsp], xmm0
00007c454bbd85e6  vmovaps [rsp+0x10], xmm1
00007c454bbd85ec  vmovaps [rsp+0x20], xmm2
00007c454bbd85f2  vmovaps [rsp+0x30], xmm3
00007c454bbd85f8  vmovaps [rsp+0x40], xmm4
00007c454bbd85fe  vmovaps [rsp+0x50], xmm5
00007c454bbd8604  vmovaps [rsp+0x60], xmm6
00007c454bbd860a  vmovaps [rsp+0x70], xmm7
00007c454bbd8610  vmovaps [rsp+0x80], xmm8
00007c454bbd8619  vmovaps [rsp+0x90], xmm9
00007c454bbd8622  vmovaps [rsp+0xA0], xmm10
00007c454bbd862b  vmovaps [rsp+0xB0], xmm11
00007c454bbd8634  vmovaps [rsp+0xC0], xmm12
00007c454bbd863d  vmovaps [rsp+0xD0], xmm14
00007c454bbd8646  vmovaps [rsp+0xE0], xmm15
00007c454bbd864f  sub rsp, 0x30
00007c454bbd8653  movaps [rsp], xmm13
00007c454bbd8658  movaps [rsp+0x10], xmm8
00007c454bbd865e  movaps [rsp+0x20], xmm15
00007c454bbd8664  lea rdi, [rsp]
00007c454bbd8668  mov esi, 0x00
00007c454bbd866d  mov rax, 0x56A18AC54530
00007c454bbd8677  call rax
00007c454bbd8679  movaps xmm13, [rsp]
00007c454bbd867e  add rsp, 0x30
00007c454bbd8682  vmovaps xmm0, [rsp]
00007c454bbd8687  vmovaps xmm1, [rsp+0x10]
00007c454bbd868d  vmovaps xmm2, [rsp+0x20]
00007c454bbd8693  vmovaps xmm3, [rsp+0x30]
00007c454bbd8699  vmovaps xmm4, [rsp+0x40]
00007c454bbd869f  vmovaps xmm5, [rsp+0x50]
00007c454bbd86a5  vmovaps xmm6, [rsp+0x60]
00007c454bbd86ab  vmovaps xmm7, [rsp+0x70]
00007c454bbd86b1  vmovaps xmm8, [rsp+0x80]
00007c454bbd86ba  vmovaps xmm9, [rsp+0x90]
00007c454bbd86c3  vmovaps xmm10, [rsp+0xA0]
00007c454bbd86cc  vmovaps xmm11, [rsp+0xB0]
00007c454bbd86d5  vmovaps xmm12, [rsp+0xC0]
00007c454bbd86de  vmovaps xmm14, [rsp+0xD0]
00007c454bbd86e7  vmovaps xmm15, [rsp+0xE0]
00007c454bbd86f0  add rsp, 0xF0
00007c454bbd86f7  pop r11
00007c454bbd86f9  pop r10
00007c454bbd86fb  pop r9
00007c454bbd86fd  pop r8
00007c454bbd86ff  pop rsi
00007c454bbd8700  pop rdi
00007c454bbd8701  pop rdx
00007c454bbd8702  pop rcx
00007c454bbd8703  pop rax
00007c454bbd8704  add rsp, 0x08
00007c454bbd8708  jmp 0x00007C454BBD3532
00007c454bbd870d  sub rsp, 0x08
00007c454bbd8711  push rax
00007c454bbd8712  push rcx
00007c454bbd8713  push rdx
00007c454bbd8714  push rdi
00007c454bbd8715  push rsi
00007c454bbd8716  push r8
00007c454bbd8718  push r9
00007c454bbd871a  push r10
00007c454bbd871c  push r11
00007c454bbd871e  sub rsp, 0xF0
00007c454bbd8725  vmovaps [rsp], xmm0
00007c454bbd872a  vmovaps [rsp+0x10], xmm1
00007c454bbd8730  vmovaps [rsp+0x20], xmm2
00007c454bbd8736  vmovaps [rsp+0x30], xmm3
00007c454bbd873c  vmovaps [rsp+0x40], xmm4
00007c454bbd8742  vmovaps [rsp+0x50], xmm5
00007c454bbd8748  vmovaps [rsp+0x60], xmm6
00007c454bbd874e  vmovaps [rsp+0x70], xmm7
00007c454bbd8754  vmovaps [rsp+0x80], xmm8
00007c454bbd875d  vmovaps [rsp+0x90], xmm9
00007c454bbd8766  vmovaps [rsp+0xA0], xmm10
00007c454bbd876f  vmovaps [rsp+0xB0], xmm11
00007c454bbd8778  vmovaps [rsp+0xC0], xmm12
00007c454bbd8781  vmovaps [rsp+0xD0], xmm13
00007c454bbd878a  vmovaps [rsp+0xE0], xmm14
00007c454bbd8793  sub rsp, 0x30
00007c454bbd8797  movaps [rsp], xmm15
00007c454bbd879c  movaps [rsp+0x10], xmm1
00007c454bbd87a1  movaps [rsp+0x20], xmm10
00007c454bbd87a7  lea rdi, [rsp]
00007c454bbd87ab  mov esi, 0x00
00007c454bbd87b0  mov rax, 0x56A18AC54530
00007c454bbd87ba  call rax
00007c454bbd87bc  movaps xmm15, [rsp]
00007c454bbd87c1  add rsp, 0x30
00007c454bbd87c5  vmovaps xmm0, [rsp]
00007c454bbd87ca  vmovaps xmm1, [rsp+0x10]
00007c454bbd87d0  vmovaps xmm2, [rsp+0x20]
00007c454bbd87d6  vmovaps xmm3, [rsp+0x30]
00007c454bbd87dc  vmovaps xmm4, [rsp+0x40]
00007c454bbd87e2  vmovaps xmm5, [rsp+0x50]
00007c454bbd87e8  vmovaps xmm6, [rsp+0x60]
00007c454bbd87ee  vmovaps xmm7, [rsp+0x70]
00007c454bbd87f4  vmovaps xmm8, [rsp+0x80]
00007c454bbd87fd  vmovaps xmm9, [rsp+0x90]
00007c454bbd8806  vmovaps xmm10, [rsp+0xA0]
00007c454bbd880f  vmovaps xmm11, [rsp+0xB0]
00007c454bbd8818  vmovaps xmm12, [rsp+0xC0]
00007c454bbd8821  vmovaps xmm13, [rsp+0xD0]
00007c454bbd882a  vmovaps xmm14, [rsp+0xE0]
00007c454bbd8833  add rsp, 0xF0
00007c454bbd883a  pop r11
00007c454bbd883c  pop r10
00007c454bbd883e  pop r9
00007c454bbd8840  pop r8
00007c454bbd8842  pop rsi
00007c454bbd8843  pop rdi
00007c454bbd8844  pop rdx
00007c454bbd8845  pop rcx
00007c454bbd8846  pop rax
00007c454bbd8847  add rsp, 0x08
00007c454bbd884b  jmp 0x00007C454BBD3555
00007c454bbd8850  sub rsp, 0x08
00007c454bbd8854  push rax
00007c454bbd8855  push rcx
00007c454bbd8856  push rdx
00007c454bbd8857  push rdi
00007c454bbd8858  push rsi
00007c454bbd8859  push r8
00007c454bbd885b  push r9
00007c454bbd885d  push r10
00007c454bbd885f  push r11
00007c454bbd8861  sub rsp, 0xF0
00007c454bbd8868  vmovaps [rsp], xmm0
00007c454bbd886d  vmovaps [rsp+0x10], xmm2
00007c454bbd8873  vmovaps [rsp+0x20], xmm3
00007c454bbd8879  vmovaps [rsp+0x30], xmm4
00007c454bbd887f  vmovaps [rsp+0x40], xmm5
00007c454bbd8885  vmovaps [rsp+0x50], xmm6
00007c454bbd888b  vmovaps [rsp+0x60], xmm7
00007c454bbd8891  vmovaps [rsp+0x70], xmm8
00007c454bbd8897  vmovaps [rsp+0x80], xmm9
00007c454bbd88a0  vmovaps [rsp+0x90], xmm10
00007c454bbd88a9  vmovaps [rsp+0xA0], xmm11
00007c454bbd88b2  vmovaps [rsp+0xB0], xmm12
00007c454bbd88bb  vmovaps [rsp+0xC0], xmm13
00007c454bbd88c4  vmovaps [rsp+0xD0], xmm14
00007c454bbd88cd  vmovaps [rsp+0xE0], xmm15
00007c454bbd88d6  sub rsp, 0x30
00007c454bbd88da  movaps [rsp], xmm1
00007c454bbd88de  movaps [rsp+0x10], xmm7
00007c454bbd88e3  movaps [rsp+0x20], xmm11
00007c454bbd88e9  lea rdi, [rsp]
00007c454bbd88ed  mov esi, 0x00
00007c454bbd88f2  mov rax, 0x56A18AC54530
00007c454bbd88fc  call rax
00007c454bbd88fe  movaps xmm1, [rsp]
00007c454bbd8902  add rsp, 0x30
00007c454bbd8906  vmovaps xmm0, [rsp]
00007c454bbd890b  vmovaps xmm2, [rsp+0x10]
00007c454bbd8911  vmovaps xmm3, [rsp+0x20]
00007c454bbd8917  vmovaps xmm4, [rsp+0x30]
00007c454bbd891d  vmovaps xmm5, [rsp+0x40]
00007c454bbd8923  vmovaps xmm6, [rsp+0x50]
00007c454bbd8929  vmovaps xmm7, [rsp+0x60]
00007c454bbd892f  vmovaps xmm8, [rsp+0x70]
00007c454bbd8935  vmovaps xmm9, [rsp+0x80]
00007c454bbd893e  vmovaps xmm10, [rsp+0x90]
00007c454bbd8947  vmovaps xmm11, [rsp+0xA0]
00007c454bbd8950  vmovaps xmm12, [rsp+0xB0]
00007c454bbd8959  vmovaps xmm13, [rsp+0xC0]
00007c454bbd8962  vmovaps xmm14, [rsp+0xD0]
00007c454bbd896b  vmovaps xmm15, [rsp+0xE0]
00007c454bbd8974  add rsp, 0xF0
00007c454bbd897b  pop r11
00007c454bbd897d  pop r10
00007c454bbd897f  pop r9
00007c454bbd8981  pop r8
00007c454bbd8983  pop rsi
00007c454bbd8984  pop rdi
00007c454bbd8985  pop rdx
00007c454bbd8986  pop rcx
00007c454bbd8987  pop rax
00007c454bbd8988  add rsp, 0x08
00007c454bbd898c  jmp 0x00007C454BBD3576
00007c454bbd8991  call 0x00007C454BA0D600
00007c454bbd8996  jmp 0x00007C454BBD3589
00007c454bbd899b  call 0x00007C454BA0C380
00007c454bbd89a0  jmp 0x00007C454BBD3594
00007c454bbd89a5  call 0x00007C454BA0E880
00007c454bbd89aa  jmp 0x00007C454BBD359F
00007c454bbd89af  call 0x00007C454B9FF540
00007c454bbd89b4  jmp 0x00007C454BBD35AA
00007c454bbd89b9  int3
00007c454bbd89ba  nop [rax+rax*1], ax
00007c454bbd89c0  mov rax, [r15+0x40]
00007c454bbd89c4  mov r14, [r15+0x58]
00007c454bbd89c8  lea r12, [rax+r14*1]
00007c454bbd89cc  movaps xmm1, [r15+0x1D0]
00007c454bbd89d4  vmovaps [rsp+0x10], xmm1
00007c454bbd89da  vmovaps xmm15, [rsp+0x10]
00007c454bbd89e0  por xmm1, xmm15
00007c454bbd89e5  movaps xmm14, [r15+0x1A0]
00007c454bbd89ed  vmovaps [rsp+0x10], xmm14
00007c454bbd89f3  vmovaps xmm13, [rsp+0x10]
00007c454bbd89f9  por xmm14, xmm13
00007c454bbd89fe  lea rax, [r12+0x30]
00007c454bbd8a03  mov r11, [r13+rax*1]
00007c454bbd8a08  lea rax, [r12+0x38]
00007c454bbd8a0d  mov r10, [r13+rax*1]
00007c454bbd8a12  movq xmm13, r11
00007c454bbd8a17  movq xmm12, r10
00007c454bbd8a1c  movq xmm13, xmm13
00007c454bbd8a21  vmovaps [rsp+0x10], xmm13
00007c454bbd8a27  movq xmm13, xmm13
00007c454bbd8a2c  movaps [r15+0x130], xmm13
00007c454bbd8a34  movq xmm12, xmm12
00007c454bbd8a39  vmovaps [rsp+0x20], xmm12
00007c454bbd8a3f  movq xmm12, xmm12
00007c454bbd8a44  movaps [r15+0x280], xmm12
00007c454bbd8a4c  movaps xmm13, [r15+0x270]
00007c454bbd8a54  vmovaps [rsp+0x30], xmm13
00007c454bbd8a5a  vmovaps xmm12, [rsp+0x30]
00007c454bbd8a60  por xmm13, xmm12
00007c454bbd8a65  lea rax, [r12+0x20]
00007c454bbd8a6a  mov r11, [r13+rax*1]
00007c454bbd8a6f  lea rax, [r12+0x28]
00007c454bbd8a74  mov r10, [r13+rax*1]
00007c454bbd8a79  movq xmm12, r11
00007c454bbd8a7e  movq xmm11, r10
00007c454bbd8a83  movq xmm12, xmm12
00007c454bbd8a88  vmovaps [rsp+0x30], xmm12
00007c454bbd8a8e  movq xmm12, xmm12
00007c454bbd8a93  movaps [r15+0x150], xmm12
00007c454bbd8a9b  movq xmm11, xmm11
00007c454bbd8aa0  vmovaps [rsp+0x40], xmm11
00007c454bbd8aa6  movq xmm11, xmm11
00007c454bbd8aab  movaps [r15+0x140], xmm11
00007c454bbd8ab3  lea rax, [r12+0x10]
00007c454bbd8ab8  mov r11, [r13+rax*1]
00007c454bbd8abd  lea rax, [r12+0x18]
00007c454bbd8ac2  mov r10, [r13+rax*1]
00007c454bbd8ac7  movq xmm12, r11
00007c454bbd8acc  movq xmm11, r10
00007c454bbd8ad1  movq xmm12, xmm12
00007c454bbd8ad6  vmovaps [rsp+0x50], xmm12
00007c454bbd8adc  movq xmm12, xmm12
00007c454bbd8ae1  movaps [r15+0x170], xmm12
00007c454bbd8ae9  movq xmm11, xmm11
00007c454bbd8aee  vmovaps [rsp+0x60], xmm11
00007c454bbd8af4  movq xmm11, xmm11
00007c454bbd8af9  movaps [r15+0x160], xmm11
00007c454bbd8b01  mov rax, [r13+r12*1]
00007c454bbd8b06  vmovq xmm12, rax
00007c454bbd8b0b  vpbroadcastq xmm12, xmm12
00007c454bbd8b10  lea rax, [r12+0x08]
00007c454bbd8b15  mov r12, [r13+rax*1]
00007c454bbd8b1a  movq xmm11, r12
00007c454bbd8b1f  movaps [r15+0x230], xmm11
00007c454bbd8b27  mov rax, [r15+0xF8]
00007c454bbd8b2e  lea r12, [rax+0x50]
00007c454bbd8b32  movups xmm11, [r13+r12*1]
00007c454bbd8b38  lea r12, [rax+0x60]
00007c454bbd8b3c  movups xmm10, [r13+r12*1]
00007c454bbd8b42  lea r12, [rax+0x30]
00007c454bbd8b46  movups xmm9, [r13+r12*1]
00007c454bbd8b4c  mov r12, [r15+0x50]
00007c454bbd8b50  lea r11, [r12+r14*1]
00007c454bbd8b54  mov [r15+0x60], r11
00007c454bbd8b58  lea r12, [r14+0x40]
00007c454bbd8b5c  mov [r15+0x58], r12
00007c454bbd8b60  movaps xmm8, xmm12
00007c454bbd8b64  mulpd xmm8, xmm15
00007c454bbd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007c454bbd8b6f  ptest xmm7, xmm7
00007c454bbd8b74  jnz 0x00007C454BBD9997
00007c454bbd8b7a  movq xmm15, qword ptr [r15+0x230]
00007c454bbd8b83  vmovaps [rsp+0x70], xmm15
00007c454bbd8b89  vpermilpd xmm15, xmm15, 0x00
00007c454bbd8b8f  movaps xmm7, xmm9
00007c454bbd8b93  mulpd xmm7, xmm15
00007c454bbd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007c454bbd8b9d  ptest xmm6, xmm6
00007c454bbd8ba2  jnz 0x00007C454BBD9ADB
00007c454bbd8ba8  vxorps xmm15, xmm15, xmm15
00007c454bbd8bad  vpbroadcastq xmm15, xmm15
00007c454bbd8bb2  movaps xmm9, xmm12
00007c454bbd8bb6  mulpd xmm9, xmm10
00007c454bbd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007c454bbd8bc1  ptest xmm6, xmm6
00007c454bbd8bc6  jnz 0x00007C454BBD9C1D
00007c454bbd8bcc  movaps xmm10, xmm12
00007c454bbd8bd0  mulpd xmm10, xmm11
00007c454bbd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007c454bbd8bdb  ptest xmm6, xmm6
00007c454bbd8be0  jnz 0x00007C454BBD9D61
00007c454bbd8be6  movaps xmm11, [r15+0x1F0]
00007c454bbd8bee  movaps xmm6, xmm12
00007c454bbd8bf2  mulpd xmm6, xmm11
00007c454bbd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007c454bbd8bfc  ptest xmm5, xmm5
00007c454bbd8c01  jnz 0x00007C454BBD9EA5
00007c454bbd8c07  movaps xmm12, [r15+0x2A0]
00007c454bbd8c0f  vmovaps [rsp+0x80], xmm12
00007c454bbd8c18  vmovaps xmm11, [rsp+0x80]
00007c454bbd8c21  por xmm12, xmm11
00007c454bbd8c26  movaps xmm11, [r15+0x250]
00007c454bbd8c2e  vmovaps [rsp+0x80], xmm11
00007c454bbd8c37  vmovaps xmm5, [rsp+0x80]
00007c454bbd8c40  por xmm11, xmm5
00007c454bbd8c45  vmovaps xmm4, [rsp+0x70]
00007c454bbd8c4b  vpermilpd xmm4, xmm4, 0x00
00007c454bbd8c51  movaps xmm3, xmm5
00007c454bbd8c54  mulpd xmm3, xmm4
00007c454bbd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007c454bbd8c5d  ptest xmm2, xmm2
00007c454bbd8c62  jnz 0x00007C454BBD9FE7
00007c454bbd8c68  mov [rsp+0x80], rax
00007c454bbd8c70  xor eax, eax
00007c454bbd8c72  mov r14d, 0x200
00007c454bbd8c78  cmp r12, r14
00007c454bbd8c7b  cmc
00007c454bbd8c7c  lahf
00007c454bbd8c7d  seto al
00007c454bbd8c80  mov [r15+0x108], eax
00007c454bbd8c87  movaps xmm5, xmm8
00007c454bbd8c8b  addpd xmm5, xmm15
00007c454bbd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007c454bbd8c95  ptest xmm4, xmm4
00007c454bbd8c9a  jnz 0x00007C454BBDA127
00007c454bbd8ca0  movaps xmm8, [r15+0x1B0]
00007c454bbd8ca8  movaps xmm4, xmm9
00007c454bbd8cac  addpd xmm4, xmm8
00007c454bbd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007c454bbd8cb6  ptest xmm2, xmm2
00007c454bbd8cbb  jnz 0x00007C454BBDA269
00007c454bbd8cc1  movaps xmm9, xmm10
00007c454bbd8cc5  addpd xmm9, xmm8
00007c454bbd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007c454bbd8cd0  ptest xmm2, xmm2
00007c454bbd8cd5  jnz 0x00007C454BBDA3AB
00007c454bbd8cdb  movaps xmm10, [r15+0x2F0]
00007c454bbd8ce3  vmovaps [rsp+0x90], xmm10
00007c454bbd8cec  vmovaps xmm8, [rsp+0x90]
00007c454bbd8cf5  por xmm10, xmm8
00007c454bbd8cfa  movaps xmm8, [r15+0x2E0]
00007c454bbd8d02  vmovaps [rsp+0x90], xmm8
00007c454bbd8d0b  vmovaps xmm2, [rsp+0x90]
00007c454bbd8d14  por xmm8, xmm2
00007c454bbd8d19  movaps xmm2, [r15+0x2D0]
00007c454bbd8d21  vmovaps [rsp+0x90], xmm2
00007c454bbd8d2a  vmovaps [rsp+0xA0], xmm1
00007c454bbd8d33  vmovaps xmm1, [rsp+0x90]
00007c454bbd8d3c  por xmm2, xmm1
00007c454bbd8d40  movaps xmm1, [r15+0x200]
00007c454bbd8d48  vmovaps [rsp+0x90], xmm1
00007c454bbd8d51  vmovaps [rsp+0xB0], xmm15
00007c454bbd8d5a  vmovaps xmm15, [rsp+0x90]
00007c454bbd8d63  por xmm1, xmm15
00007c454bbd8d68  movaps xmm15, [r15+0x1C0]
00007c454bbd8d70  vmovaps [rsp+0x90], xmm15
00007c454bbd8d79  vmovaps [rsp+0xC0], xmm1
00007c454bbd8d82  vmovaps xmm1, [rsp+0x90]
00007c454bbd8d8b  por xmm15, xmm1
00007c454bbd8d90  movaps xmm1, [r15+0x190]
00007c454bbd8d98  vmovaps [rsp+0x90], xmm1
00007c454bbd8da1  vmovaps [rsp+0xD0], xmm15
00007c454bbd8daa  vmovaps xmm15, [rsp+0x90]
00007c454bbd8db3  por xmm1, xmm15
00007c454bbd8db8  movaps xmm15, [r15+0x300]
00007c454bbd8dc0  vmovaps [rsp+0x90], xmm15
00007c454bbd8dc9  vmovaps [rsp+0xE0], xmm1
00007c454bbd8dd2  vmovaps xmm1, [rsp+0x90]
00007c454bbd8ddb  por xmm15, xmm1
00007c454bbd8de0  mov rax, [rsp+0x80]
00007c454bbd8de8  lea r14, [rax+0xA0]
00007c454bbd8def  movups xmm1, [r13+r14*1]
00007c454bbd8df5  lea r14, [rax+0xB0]
00007c454bbd8dfc  vmovaps [rsp+0x80], xmm1
00007c454bbd8e05  movups xmm1, [r13+r14*1]
00007c454bbd8e0b  vmovaps [rsp+0x90], xmm1
00007c454bbd8e14  vmovaps [rsp+0xF0], xmm15
00007c454bbd8e1d  vmovaps xmm15, [rsp+0xB0]
00007c454bbd8e26  vmovaps [rsp+0xB0], xmm14
00007c454bbd8e2f  movaps xmm1, xmm6
00007c454bbd8e32  addpd xmm1, xmm15
00007c454bbd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007c454bbd8e3c  ptest xmm14, xmm14
00007c454bbd8e42  jnz 0x00007C454BBDA503
00007c454bbd8e48  lea r14, [rax+0xF0]
00007c454bbd8e4f  movups xmm15, [r13+r14*1]
00007c454bbd8e55  movaps xmm14, xmm4
00007c454bbd8e59  addpd xmm14, xmm3
00007c454bbd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007c454bbd8e64  ptest xmm6, xmm6
00007c454bbd8e69  jnz 0x00007C454BBDA64E
00007c454bbd8e6f  movaps xmm6, xmm9
00007c454bbd8e73  addpd xmm6, xmm7
00007c454bbd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007c454bbd8e7c  ptest xmm4, xmm4
00007c454bbd8e81  jnz 0x00007C454BBDA790
00007c454bbd8e87  vmovaps xmm9, [rsp+0x70]
00007c454bbd8e8d  vpermilpd xmm9, xmm9, 0x00
00007c454bbd8e93  vmovaps xmm4, [rsp+0x90]
00007c454bbd8e9c  movaps xmm7, xmm4
00007c454bbd8e9f  mulpd xmm7, xmm9
00007c454bbd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007c454bbd8ea9  ptest xmm3, xmm3
00007c454bbd8eae  jnz 0x00007C454BBDA8D1
00007c454bbd8eb4  vmovaps xmm9, [rsp+0x50]
00007c454bbd8eba  vpermilpd xmm9, xmm9, 0x00
00007c454bbd8ec0  movaps xmm4, xmm15
00007c454bbd8ec4  mulpd xmm4, xmm9
00007c454bbd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007c454bbd8ece  ptest xmm3, xmm3
00007c454bbd8ed3  jnz 0x00007C454BBDAA12
00007c454bbd8ed9  lea r14, [rax+0xE0]
00007c454bbd8ee0  movups xmm15, [r13+r14*1]
00007c454bbd8ee6  vmovaps xmm9, [rsp+0x70]
00007c454bbd8eec  vpermilpd xmm9, xmm9, 0x00
00007c454bbd8ef2  vmovaps [rsp+0x70], xmm1
00007c454bbd8ef8  vmovaps xmm1, [rsp+0x80]
00007c454bbd8f01  vmovaps [rsp+0x80], xmm15
00007c454bbd8f0a  movaps xmm3, xmm1
00007c454bbd8f0d  mulpd xmm3, xmm9
00007c454bbd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007c454bbd8f17  ptest xmm15, xmm15
00007c454bbd8f1d  jnz 0x00007C454BBDAB5E
00007c454bbd8f23  vmovaps xmm1, [rsp+0xF0]
00007c454bbd8f2c  vmovaps xmm15, [rsp+0xF0]
00007c454bbd8f35  por xmm1, xmm15
00007c454bbd8f3a  movaps [r15+0x300], xmm1
00007c454bbd8f42  vmovaps xmm15, [rsp+0xE0]
00007c454bbd8f4b  vmovaps xmm9, [rsp+0xE0]
00007c454bbd8f54  por xmm15, xmm9
00007c454bbd8f59  movaps [r15+0x190], xmm15
00007c454bbd8f61  vmovaps xmm9, [rsp+0x50]
00007c454bbd8f67  vpermilpd xmm9, xmm9, 0x00
00007c454bbd8f6d  vmovaps [rsp+0x90], xmm1
00007c454bbd8f76  vmovaps [rsp+0xE0], xmm15
00007c454bbd8f7f  vmovaps xmm15, [rsp+0x80]
00007c454bbd8f88  vmovaps [rsp+0x80], xmm14
00007c454bbd8f91  movaps xmm1, xmm15
00007c454bbd8f95  mulpd xmm1, xmm9
00007c454bbd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007c454bbd8f9f  ptest xmm14, xmm14
00007c454bbd8fa5  jnz 0x00007C454BBDAC9F
00007c454bbd8fab  lea r14, [rax+0x90]
00007c454bbd8fb2  movups xmm15, [r13+r14*1]
00007c454bbd8fb8  vmovaps xmm14, [rsp+0xD0]
00007c454bbd8fc1  vmovaps xmm9, [rsp+0xD0]
00007c454bbd8fca  por xmm14, xmm9
00007c454bbd8fcf  movaps [r15+0x1C0], xmm14
00007c454bbd8fd7  vmovaps xmm9, [rsp+0xC0]
00007c454bbd8fe0  vmovaps [rsp+0xD0], xmm1
00007c454bbd8fe9  vmovaps xmm1, [rsp+0xC0]
00007c454bbd8ff2  por xmm9, xmm1
00007c454bbd8ff7  movaps [r15+0x200], xmm9
00007c454bbd8fff  vmovaps [rsp+0xC0], xmm2
00007c454bbd9008  vmovaps xmm1, [rsp+0xC0]
00007c454bbd9011  por xmm2, xmm1
00007c454bbd9015  movaps [r15+0x2D0], xmm2
00007c454bbd901d  vmovaps [rsp+0xC0], xmm8
00007c454bbd9026  vmovaps xmm1, [rsp+0xC0]
00007c454bbd902f  por xmm8, xmm1
00007c454bbd9034  movaps [r15+0x2E0], xmm8
00007c454bbd903c  vmovaps [rsp+0xC0], xmm15
00007c454bbd9045  movaps xmm1, xmm5
00007c454bbd9048  addpd xmm1, xmm7
00007c454bbd904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007c454bbd9051  ptest xmm15, xmm15
00007c454bbd9057  jnz 0x00007C454BBDADEB
00007c454bbd905d  vmovaps xmm15, [rsp+0x50]
00007c454bbd9063  vpermilpd xmm15, xmm15, 0x00
00007c454bbd9069  vmovaps xmm5, [rsp+0xC0]
00007c454bbd9072  vmovaps [rsp+0xC0], xmm1
00007c454bbd907b  movaps xmm7, xmm5
00007c454bbd907e  mulpd xmm7, xmm15
00007c454bbd9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007c454bbd9088  ptest xmm1, xmm1
00007c454bbd908d  jnz 0x00007C454BBDAF2B
00007c454bbd9093  lea r14, [rax+0x80]
00007c454bbd909a  movups xmm1, [r13+r14*1]
00007c454bbd90a0  vmovaps xmm5, [rsp+0x70]
00007c454bbd90a6  vmovaps [rsp+0x70], xmm1
00007c454bbd90ac  movaps xmm15, xmm5
00007c454bbd90b0  addpd xmm15, xmm3
00007c454bbd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007c454bbd90bb  ptest xmm1, xmm1
00007c454bbd90c0  jnz 0x00007C454BBDB076
00007c454bbd90c6  vmovaps xmm5, [rsp+0x80]
00007c454bbd90cf  movaps xmm1, xmm5
00007c454bbd90d2  addpd xmm1, xmm4
00007c454bbd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007c454bbd90db  ptest xmm3, xmm3
00007c454bbd90e0  jnz 0x00007C454BBDB1B8
00007c454bbd90e6  vmovaps [rsp+0x80], xmm10
00007c454bbd90ef  vmovaps xmm5, [rsp+0x80]
00007c454bbd90f8  por xmm10, xmm5
00007c454bbd90fd  movaps [r15+0x2F0], xmm10
00007c454bbd9105  vmovaps xmm5, [rsp+0x50]
00007c454bbd910b  vpermilpd xmm5, xmm5, 0x00
00007c454bbd9111  vmovaps xmm3, [rsp+0x70]
00007c454bbd9117  vmovaps [rsp+0x50], xmm1
00007c454bbd911d  movaps xmm4, xmm3
00007c454bbd9120  mulpd xmm4, xmm5
00007c454bbd9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007c454bbd9129  ptest xmm1, xmm1
00007c454bbd912e  jnz 0x00007C454BBDB2F8
00007c454bbd9134  lea r14, [rax+0xD0]
00007c454bbd913b  movups xmm1, [r13+r14*1]
00007c454bbd9141  vmovaps xmm3, [rsp+0xD0]
00007c454bbd914a  vmovaps [rsp+0x70], xmm1
00007c454bbd9150  movaps xmm5, xmm6
00007c454bbd9153  addpd xmm5, xmm3
00007c454bbd9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007c454bbd915c  ptest xmm1, xmm1
00007c454bbd9161  jnz 0x00007C454BBDB442
00007c454bbd9167  vmovaps xmm1, [rsp+0x60]
00007c454bbd916d  vpermilpd xmm1, xmm1, 0x00
00007c454bbd9173  movaps xmm6, xmm9
00007c454bbd9177  mulpd xmm6, xmm1
00007c454bbd917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007c454bbd9180  ptest xmm3, xmm3
00007c454bbd9185  jnz 0x00007C454BBDB582
00007c454bbd918b  movaps [r15+0x260], xmm6
00007c454bbd9193  vxorps xmm1, xmm1, xmm1
00007c454bbd9197  vpbroadcastq xmm1, xmm1
00007c454bbd919c  movaps [r15+0x1B0], xmm1
00007c454bbd91a4  vmovaps xmm1, [rsp+0x60]
00007c454bbd91aa  vpermilpd xmm1, xmm1, 0x00
00007c454bbd91b0  vmovaps xmm3, [rsp+0x70]
00007c454bbd91b6  vmovaps [rsp+0x70], xmm15
00007c454bbd91bc  movaps xmm9, xmm3
00007c454bbd91c0  mulpd xmm9, xmm1
00007c454bbd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007c454bbd91cb  ptest xmm15, xmm15
00007c454bbd91d1  jnz 0x00007C454BBDB6C3
00007c454bbd91d7  lea r14, [rax+0xC0]
00007c454bbd91de  movups xmm1, [r13+r14*1]
00007c454bbd91e4  vmovaps xmm3, [rsp+0xC0]
00007c454bbd91ed  vmovaps [rsp+0x80], xmm1
00007c454bbd91f6  movaps xmm15, xmm3
00007c454bbd91fa  addpd xmm15, xmm7
00007c454bbd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007c454bbd9205  ptest xmm1, xmm1
00007c454bbd920a  jnz 0x00007C454BBDB80F
00007c454bbd9210  vmovaps [rsp+0xC0], xmm13
00007c454bbd9219  vmovaps xmm1, [rsp+0xC0]
00007c454bbd9222  por xmm13, xmm1
00007c454bbd9227  movaps [r15+0x270], xmm13
00007c454bbd922f  vmovaps xmm1, [rsp+0xB0]
00007c454bbd9238  vmovaps xmm7, [rsp+0xB0]
00007c454bbd9241  por xmm1, xmm7
00007c454bbd9245  movaps [r15+0x1A0], xmm1
00007c454bbd924d  vmovaps xmm1, [rsp+0x60]
00007c454bbd9253  vpermilpd xmm1, xmm1, 0x00
00007c454bbd9259  vmovaps [rsp+0xB0], xmm1
00007c454bbd9262  vmovaps xmm1, [rsp+0x80]
00007c454bbd926b  vmovaps [rsp+0x80], xmm15
00007c454bbd9274  vmovaps xmm15, [rsp+0xB0]
00007c454bbd927d  vmovaps [rsp+0xB0], xmm14
00007c454bbd9286  movaps xmm3, xmm1
00007c454bbd9289  mulpd xmm3, xmm15
00007c454bbd928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007c454bbd9293  ptest xmm14, xmm14
00007c454bbd9299  jnz 0x00007C454BBDB951
00007c454bbd929f  lea r14, [rax+0x20]
00007c454bbd92a3  movups xmm1, [r13+r14*1]
00007c454bbd92a9  movaps [r15+0x110], xmm1
00007c454bbd92b1  vmovaps xmm14, [rsp+0x70]
00007c454bbd92b7  vmovaps [rsp+0x70], xmm1
00007c454bbd92bd  movaps xmm15, xmm14
00007c454bbd92c1  addpd xmm15, xmm4
00007c454bbd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007c454bbd92cc  ptest xmm1, xmm1
00007c454bbd92d1  jnz 0x00007C454BBDBA9C
00007c454bbd92d7  vmovaps xmm1, [rsp+0x60]
00007c454bbd92dd  vpermilpd xmm1, xmm1, 0x00
00007c454bbd92e3  movaps xmm14, xmm2
00007c454bbd92e7  mulpd xmm14, xmm1
00007c454bbd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007c454bbd92f2  ptest xmm4, xmm4
00007c454bbd92f7  jnz 0x00007C454BBDBBDF
00007c454bbd92fd  vmovaps xmm4, [rsp+0x50]
00007c454bbd9303  movaps xmm1, xmm4
00007c454bbd9306  addpd xmm1, xmm9
00007c454bbd930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007c454bbd9310  ptest xmm2, xmm2
00007c454bbd9315  jnz 0x00007C454BBDBD21
00007c454bbd931b  vmovaps xmm9, [rsp+0x30]
00007c454bbd9321  vpermilpd xmm9, xmm9, 0x00
00007c454bbd9327  vmovaps xmm2, [rsp+0x70]
00007c454bbd932d  vmovaps [rsp+0x50], xmm1
00007c454bbd9333  movaps xmm4, xmm2
00007c454bbd9336  mulpd xmm4, xmm9
00007c454bbd933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007c454bbd9340  ptest xmm1, xmm1
00007c454bbd9345  jnz 0x00007C454BBDBE62
00007c454bbd934b  vmovaps xmm1, [rsp+0x30]
00007c454bbd9351  vpermilpd xmm1, xmm1, 0x00
00007c454bbd9357  vmovaps xmm2, [rsp+0x90]
00007c454bbd9360  vmovaps [rsp+0x60], xmm15
00007c454bbd9366  movaps xmm9, xmm2
00007c454bbd936a  mulpd xmm9, xmm1
00007c454bbd936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007c454bbd9375  ptest xmm15, xmm15
00007c454bbd937b  jnz 0x00007C454BBDBFA3
00007c454bbd9381  vmovaps xmm15, [rsp+0x80]
00007c454bbd938a  movaps xmm1, xmm15
00007c454bbd938e  addpd xmm1, xmm6
00007c454bbd9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007c454bbd9397  ptest xmm2, xmm2
00007c454bbd939c  jnz 0x00007C454BBDC0E5
00007c454bbd93a2  movaps xmm15, xmm5
00007c454bbd93a6  addpd xmm15, xmm3
00007c454bbd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007c454bbd93b1  ptest xmm6, xmm6
00007c454bbd93b6  jnz 0x00007C454BBDC226
00007c454bbd93bc  vmovaps xmm6, [rsp+0x30]
00007c454bbd93c2  vpermilpd xmm6, xmm6, 0x00
00007c454bbd93c8  movaps xmm5, xmm8
00007c454bbd93cc  mulpd xmm5, xmm6
00007c454bbd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007c454bbd93d5  ptest xmm3, xmm3
00007c454bbd93da  jnz 0x00007C454BBDC368
00007c454bbd93e0  vmovaps xmm8, [rsp+0x30]
00007c454bbd93e6  vpermilpd xmm8, xmm8, 0x00
00007c454bbd93ec  movaps xmm6, xmm10
00007c454bbd93f0  mulpd xmm6, xmm8
00007c454bbd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007c454bbd93fa  ptest xmm3, xmm3
00007c454bbd93ff  jnz 0x00007C454BBDC4A9
00007c454bbd9405  vmovaps xmm8, [rsp+0x60]
00007c454bbd940b  movaps xmm10, xmm8
00007c454bbd940f  addpd xmm10, xmm14
00007c454bbd9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007c454bbd941a  ptest xmm3, xmm3
00007c454bbd941f  jnz 0x00007C454BBDC5EB
00007c454bbd9425  vmovaps xmm8, [rsp+0x50]
00007c454bbd942b  movaps xmm14, xmm8
00007c454bbd942f  addpd xmm14, xmm4
00007c454bbd9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007c454bbd943a  ptest xmm3, xmm3
00007c454bbd943f  jnz 0x00007C454BBDC72F
00007c454bbd9445  vmovaps xmm8, [rsp+0x40]
00007c454bbd944b  vpermilpd xmm8, xmm8, 0x00
00007c454bbd9451  movaps xmm4, xmm13
00007c454bbd9455  mulpd xmm4, xmm8
00007c454bbd945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007c454bbd945f  ptest xmm3, xmm3
00007c454bbd9464  jnz 0x00007C454BBDC872
00007c454bbd946a  movaps xmm13, xmm15
00007c454bbd946e  addpd xmm13, xmm9
00007c454bbd9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007c454bbd9479  ptest xmm8, xmm8
00007c454bbd947f  jnz 0x00007C454BBDC9B4
00007c454bbd9485  movaps xmm15, xmm1
00007c454bbd9489  addpd xmm15, xmm5
00007c454bbd948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007c454bbd9494  ptest xmm9, xmm9
00007c454bbd949a  jnz 0x00007C454BBDCAF8
00007c454bbd94a0  vmovaps [rsp+0x30], xmm11
00007c454bbd94a6  vmovaps xmm1, [rsp+0x30]
00007c454bbd94ac  por xmm11, xmm1
00007c454bbd94b1  movaps [r15+0x250], xmm11
00007c454bbd94b9  vmovaps [rsp+0x30], xmm12
00007c454bbd94bf  vmovaps xmm1, [rsp+0x30]
00007c454bbd94c5  por xmm12, xmm1
00007c454bbd94ca  movaps [r15+0x2A0], xmm12
00007c454bbd94d2  vmovaps xmm1, [rsp+0xA0]
00007c454bbd94db  vmovaps xmm11, [rsp+0xA0]
00007c454bbd94e4  por xmm1, xmm11
00007c454bbd94e9  movaps [r15+0x1D0], xmm1
00007c454bbd94f1  lea r14, [rax+0x40]
00007c454bbd94f5  movups xmm1, [r13+r14*1]
00007c454bbd94fb  movaps [r15+0x2C0], xmm1
00007c454bbd9503  vmovaps xmm11, [rsp+0x40]
00007c454bbd9509  vpermilpd xmm11, xmm11, 0x00
00007c454bbd950f  vmovaps xmm8, [rsp+0xE0]
00007c454bbd9518  movaps xmm9, xmm8
00007c454bbd951c  mulpd xmm9, xmm11
00007c454bbd9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007c454bbd9527  ptest xmm5, xmm5
00007c454bbd952c  jnz 0x00007C454BBDCC44
00007c454bbd9532  movaps xmm11, xmm10
00007c454bbd9536  addpd xmm11, xmm6
00007c454bbd953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007c454bbd9541  ptest xmm8, xmm8
00007c454bbd9547  jnz 0x00007C454BBDCD88
00007c454bbd954d  movaps xmm10, xmm14
00007c454bbd9551  addpd xmm10, xmm4
00007c454bbd9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007c454bbd955c  ptest xmm8, xmm8
00007c454bbd9562  jnz 0x00007C454BBDCECB
00007c454bbd9568  vmovaps xmm14, [rsp+0x40]
00007c454bbd956e  vpermilpd xmm14, xmm14, 0x00
00007c454bbd9574  movaps xmm8, xmm1
00007c454bbd9578  mulpd xmm8, xmm14
00007c454bbd957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007c454bbd9583  ptest xmm6, xmm6
00007c454bbd9588  jnz 0x00007C454BBDD00E
00007c454bbd958e  movaps xmm1, [r15+0x2B0]
00007c454bbd9596  vmovaps xmm14, [rsp+0x40]
00007c454bbd959c  vpermilpd xmm14, xmm14, 0x00
00007c454bbd95a2  movaps xmm6, xmm1
00007c454bbd95a5  mulpd xmm6, xmm14
00007c454bbd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007c454bbd95af  ptest xmm5, xmm5
00007c454bbd95b4  jnz 0x00007C454BBDD151
00007c454bbd95ba  vmovaps xmm1, [rsp+0x10]
00007c454bbd95c0  vpermilpd xmm1, xmm1, 0x00
00007c454bbd95c6  movaps xmm14, xmm12
00007c454bbd95ca  mulpd xmm14, xmm1
00007c454bbd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007c454bbd95d5  ptest xmm5, xmm5
00007c454bbd95da  jnz 0x00007C454BBDD292
00007c454bbd95e0  movaps xmm1, xmm13
00007c454bbd95e4  addpd xmm1, xmm9
00007c454bbd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007c454bbd95ee  ptest xmm12, xmm12
00007c454bbd95f4  jnz 0x00007C454BBDD3D5
00007c454bbd95fa  vmovaps xmm13, [rsp+0x10]
00007c454bbd9600  vpermilpd xmm13, xmm13, 0x00
00007c454bbd9606  movaps xmm12, xmm7
00007c454bbd960a  mulpd xmm12, xmm13
00007c454bbd960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007c454bbd9615  ptest xmm9, xmm9
00007c454bbd961b  jnz 0x00007C454BBDD517
00007c454bbd9621  movaps xmm13, xmm15
00007c454bbd9625  addpd xmm13, xmm8
00007c454bbd962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007c454bbd9630  ptest xmm9, xmm9
00007c454bbd9636  jnz 0x00007C454BBDD65A
00007c454bbd963c  movaps xmm15, [r15+0x290]
00007c454bbd9644  vmovaps xmm9, [rsp+0x10]
00007c454bbd964a  vpermilpd xmm9, xmm9, 0x00
00007c454bbd9650  movaps xmm8, xmm15
00007c454bbd9654  mulpd xmm8, xmm9
00007c454bbd9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007c454bbd965f  ptest xmm7, xmm7
00007c454bbd9664  jnz 0x00007C454BBDD79E
00007c454bbd966a  movaps xmm15, xmm11
00007c454bbd966e  addpd xmm15, xmm6
00007c454bbd9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007c454bbd9679  ptest xmm9, xmm9
00007c454bbd967f  jnz 0x00007C454BBDD8E2
00007c454bbd9685  movaps xmm11, [r15+0x1E0]
00007c454bbd968d  vmovaps xmm9, [rsp+0x10]
00007c454bbd9693  vpermilpd xmm9, xmm9, 0x00
00007c454bbd9699  movaps xmm7, xmm11
00007c454bbd969d  mulpd xmm7, xmm9
00007c454bbd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007c454bbd96a7  ptest xmm6, xmm6
00007c454bbd96ac  jnz 0x00007C454BBDDA25
00007c454bbd96b2  movaps xmm11, xmm10
00007c454bbd96b6  addpd xmm11, xmm14
00007c454bbd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007c454bbd96c1  ptest xmm9, xmm9
00007c454bbd96c7  jnz 0x00007C454BBDDB67
00007c454bbd96cd  lea r14, [rax+0x70]
00007c454bbd96d1  movups xmm14, [r13+r14*1]
00007c454bbd96d7  movaps [r15+0x240], xmm14
00007c454bbd96df  movaps xmm10, xmm1
00007c454bbd96e3  addpd xmm10, xmm12
00007c454bbd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007c454bbd96ee  ptest xmm9, xmm9
00007c454bbd96f4  jnz 0x00007C454BBDDCB5
00007c454bbd96fa  movaps [r15+0x170], xmm10
00007c454bbd9702  vmovaps xmm1, [rsp+0x20]
00007c454bbd9708  vpermilpd xmm1, xmm1, 0x00
00007c454bbd970e  movaps xmm12, xmm14
00007c454bbd9712  mulpd xmm12, xmm1
00007c454bbd9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007c454bbd971d  ptest xmm9, xmm9
00007c454bbd9723  jnz 0x00007C454BBDDDF8
00007c454bbd9729  vmovaps xmm1, [rsp+0x20]
00007c454bbd972f  vpermilpd xmm1, xmm1, 0x00
00007c454bbd9735  vmovaps xmm9, [rsp+0xB0]
00007c454bbd973e  movaps xmm14, xmm9
00007c454bbd9742  mulpd xmm14, xmm1
00007c454bbd9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007c454bbd974d  ptest xmm6, xmm6
00007c454bbd9752  jnz 0x00007C454BBDDF3B
00007c454bbd9758  movaps [r15+0x180], xmm14
00007c454bbd9760  movaps xmm1, xmm13
00007c454bbd9764  addpd xmm1, xmm8
00007c454bbd9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007c454bbd976e  ptest xmm9, xmm9
00007c454bbd9774  jnz 0x00007C454BBDE07E
00007c454bbd977a  movaps [r15+0x210], xmm1
00007c454bbd9782  movups xmm13, [r13+rax*1]
00007c454bbd9788  lea r14, [rax+0x10]
00007c454bbd978c  movups xmm9, [r13+r14*1]
00007c454bbd9792  movaps [r15+0x230], xmm9
00007c454bbd979a  movaps xmm8, xmm15
00007c454bbd979e  addpd xmm8, xmm7
00007c454bbd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007c454bbd97a9  ptest xmm6, xmm6
00007c454bbd97ae  jnz 0x00007C454BBDE1D4
00007c454bbd97b4  movaps [r15+0x130], xmm8
00007c454bbd97bc  vmovaps xmm15, [rsp+0x20]
00007c454bbd97c2  vpermilpd xmm15, xmm15, 0x00
00007c454bbd97c8  movaps xmm7, xmm9
00007c454bbd97cc  mulpd xmm7, xmm15
00007c454bbd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007c454bbd97d6  ptest xmm6, xmm6
00007c454bbd97db  jnz 0x00007C454BBDE317
00007c454bbd97e1  movaps [r15+0x220], xmm7
00007c454bbd97e9  vmovaps xmm15, [rsp+0x20]
00007c454bbd97ef  vpermilpd xmm15, xmm15, 0x00
00007c454bbd97f5  movaps xmm9, xmm13
00007c454bbd97f9  mulpd xmm9, xmm15
00007c454bbd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007c454bbd9804  ptest xmm6, xmm6
00007c454bbd9809  jnz 0x00007C454BBDE459
00007c454bbd980f  movaps xmm15, xmm11
00007c454bbd9813  addpd xmm15, xmm12
00007c454bbd9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007c454bbd981e  ptest xmm13, xmm13
00007c454bbd9824  jnz 0x00007C454BBDE59D
00007c454bbd982a  movaps [r15+0x140], xmm15
00007c454bbd9832  movaps xmm13, xmm10
00007c454bbd9836  addpd xmm13, xmm14
00007c454bbd983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007c454bbd9841  ptest xmm12, xmm12
00007c454bbd9847  jnz 0x00007C454BBDE6E1
00007c454bbd984d  movaps [r15+0x150], xmm13
00007c454bbd9855  movaps xmm14, xmm1
00007c454bbd9859  addpd xmm14, xmm7
00007c454bbd985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007c454bbd9864  ptest xmm12, xmm12
00007c454bbd986a  jnz 0x00007C454BBDE825
00007c454bbd9870  movaps [r15+0x160], xmm14
00007c454bbd9878  movaps xmm1, xmm8
00007c454bbd987c  addpd xmm1, xmm9
00007c454bbd9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007c454bbd9886  ptest xmm12, xmm12
00007c454bbd988c  jnz 0x00007C454BBDE967
00007c454bbd9892  movaps [r15+0x120], xmm1
00007c454bbd989a  movups [r13+r11*1], xmm15
00007c454bbd98a0  lea rax, [r11+0x10]
00007c454bbd98a4  movups [r13+rax*1], xmm13
00007c454bbd98aa  lea rax, [r11+0x20]
00007c454bbd98ae  movups [r13+rax*1], xmm14
00007c454bbd98b4  lea rax, [r11+0x30]
00007c454bbd98b8  movups [r13+rax*1], xmm1
00007c454bbd98be  mov eax, [r15+0x108]
00007c454bbd98c5  sahf
00007c454bbd98c6  jnz 0x00007C454BBD98F8
00007c454bbd98c8  cmp dword ptr [r15+0x318], 0x00
00007c454bbd98d0  jz 0x00007C454BBDEAE0
00007c454bbd98d6  nop [rax+rax*1], ax
00007c454bbd98df  nop [rax+rax*1], eax
00007c454bbd98e7  mov eax, 0x4106D0
00007c454bbd98ec  mov [r15+0x100], rax
00007c454bbd98f3  jmp 0x00007C454B9FE110
00007c454bbd98f8  cmp dword ptr [r15+0x318], 0x00
00007c454bbd9900  jz 0x00007C454BBD89C0
00007c454bbd9906  nop [rax+rax*1], ax
00007c454bbd990f  nop [rax+rax*1], eax
00007c454bbd9917  mov eax, 0x410504
00007c454bbd991c  mov [r15+0x100], rax
00007c454bbd9923  jmp 0x00007C454B9FE110
00007c454bbd9928  int3
00007c454bbd9929  call 0x00007C454BA0A4B0
00007c454bbd992e  jmp 0x00007C454BBD8A08
00007c454bbd9933  call 0x00007C454BA09240
00007c454bbd9938  jmp 0x00007C454BBD8A12
00007c454bbd993d  call 0x00007C454BA0A4B0
00007c454bbd9942  jmp 0x00007C454BBD8A6F
00007c454bbd9947  call 0x00007C454BA09240
00007c454bbd994c  jmp 0x00007C454BBD8A79
00007c454bbd9951  call 0x00007C454BA0A4B0
00007c454bbd9956  jmp 0x00007C454BBD8ABD
00007c454bbd995b  call 0x00007C454BA09240
00007c454bbd9960  jmp 0x00007C454BBD8AC7
00007c454bbd9965  call 0x00007C454BAB47C0
00007c454bbd996a  jmp 0x00007C454BBD8B06
00007c454bbd996f  call 0x00007C454BA0B720
00007c454bbd9974  jmp 0x00007C454BBD8B1A
00007c454bbd9979  call 0x00007C454BABFC30
00007c454bbd997e  jmp 0x00007C454BBD8B38
00007c454bbd9983  call 0x00007C454BABE9C0
00007c454bbd9988  jmp 0x00007C454BBD8B42
00007c454bbd998d  call 0x00007C454BABD750
00007c454bbd9992  jmp 0x00007C454BBD8B4C
00007c454bbd9997  sub rsp, 0x08
00007c454bbd999b  push rax
00007c454bbd999c  push rcx
00007c454bbd999d  push rdx
00007c454bbd999e  push rdi
00007c454bbd999f  push rsi
00007c454bbd99a0  push r8
00007c454bbd99a2  push r9
00007c454bbd99a4  push r10
00007c454bbd99a6  push r11
00007c454bbd99a8  sub rsp, 0xF0
00007c454bbd99af  vmovaps [rsp], xmm0
00007c454bbd99b4  vmovaps [rsp+0x10], xmm1
00007c454bbd99ba  vmovaps [rsp+0x20], xmm2
00007c454bbd99c0  vmovaps [rsp+0x30], xmm3
00007c454bbd99c6  vmovaps [rsp+0x40], xmm4
00007c454bbd99cc  vmovaps [rsp+0x50], xmm5
00007c454bbd99d2  vmovaps [rsp+0x60], xmm6
00007c454bbd99d8  vmovaps [rsp+0x70], xmm7
00007c454bbd99de  vmovaps [rsp+0x80], xmm9
00007c454bbd99e7  vmovaps [rsp+0x90], xmm10
00007c454bbd99f0  vmovaps [rsp+0xA0], xmm11
00007c454bbd99f9  vmovaps [rsp+0xB0], xmm12
00007c454bbd9a02  vmovaps [rsp+0xC0], xmm13
00007c454bbd9a0b  vmovaps [rsp+0xD0], xmm14
00007c454bbd9a14  vmovaps [rsp+0xE0], xmm15
00007c454bbd9a1d  sub rsp, 0x30
00007c454bbd9a21  movaps [rsp], xmm8
00007c454bbd9a26  movaps [rsp+0x10], xmm12
00007c454bbd9a2c  movaps [rsp+0x20], xmm15
00007c454bbd9a32  lea rdi, [rsp]
00007c454bbd9a36  mov esi, 0x00
00007c454bbd9a3b  mov rax, 0x56A18AC54530
00007c454bbd9a45  call rax
00007c454bbd9a47  movaps xmm8, [rsp]
00007c454bbd9a4c  add rsp, 0x30
00007c454bbd9a50  vmovaps xmm0, [rsp]
00007c454bbd9a55  vmovaps xmm1, [rsp+0x10]
00007c454bbd9a5b  vmovaps xmm2, [rsp+0x20]
00007c454bbd9a61  vmovaps xmm3, [rsp+0x30]
00007c454bbd9a67  vmovaps xmm4, [rsp+0x40]
00007c454bbd9a6d  vmovaps xmm5, [rsp+0x50]
00007c454bbd9a73  vmovaps xmm6, [rsp+0x60]
00007c454bbd9a79  vmovaps xmm7, [rsp+0x70]
00007c454bbd9a7f  vmovaps xmm9, [rsp+0x80]
00007c454bbd9a88  vmovaps xmm10, [rsp+0x90]
00007c454bbd9a91  vmovaps xmm11, [rsp+0xA0]
00007c454bbd9a9a  vmovaps xmm12, [rsp+0xB0]
00007c454bbd9aa3  vmovaps xmm13, [rsp+0xC0]
00007c454bbd9aac  vmovaps xmm14, [rsp+0xD0]
00007c454bbd9ab5  vmovaps xmm15, [rsp+0xE0]
00007c454bbd9abe  add rsp, 0xF0
00007c454bbd9ac5  pop r11
00007c454bbd9ac7  pop r10
00007c454bbd9ac9  pop r9
00007c454bbd9acb  pop r8
00007c454bbd9acd  pop rsi
00007c454bbd9ace  pop rdi
00007c454bbd9acf  pop rdx
00007c454bbd9ad0  pop rcx
00007c454bbd9ad1  pop rax
00007c454bbd9ad2  add rsp, 0x08
00007c454bbd9ad6  jmp 0x00007C454BBD8B7A
00007c454bbd9adb  sub rsp, 0x08
00007c454bbd9adf  push rax
00007c454bbd9ae0  push rcx
00007c454bbd9ae1  push rdx
00007c454bbd9ae2  push rdi
00007c454bbd9ae3  push rsi
00007c454bbd9ae4  push r8
00007c454bbd9ae6  push r9
00007c454bbd9ae8  push r10
00007c454bbd9aea  push r11
00007c454bbd9aec  sub rsp, 0xF0
00007c454bbd9af3  vmovaps [rsp], xmm0
00007c454bbd9af8  vmovaps [rsp+0x10], xmm1
00007c454bbd9afe  vmovaps [rsp+0x20], xmm2
00007c454bbd9b04  vmovaps [rsp+0x30], xmm3
00007c454bbd9b0a  vmovaps [rsp+0x40], xmm4
00007c454bbd9b10  vmovaps [rsp+0x50], xmm5
00007c454bbd9b16  vmovaps [rsp+0x60], xmm6
00007c454bbd9b1c  vmovaps [rsp+0x70], xmm8
00007c454bbd9b22  vmovaps [rsp+0x80], xmm9
00007c454bbd9b2b  vmovaps [rsp+0x90], xmm10
00007c454bbd9b34  vmovaps [rsp+0xA0], xmm11
00007c454bbd9b3d  vmovaps [rsp+0xB0], xmm12
00007c454bbd9b46  vmovaps [rsp+0xC0], xmm13
00007c454bbd9b4f  vmovaps [rsp+0xD0], xmm14
00007c454bbd9b58  vmovaps [rsp+0xE0], xmm15
00007c454bbd9b61  sub rsp, 0x30
00007c454bbd9b65  movaps [rsp], xmm7
00007c454bbd9b69  movaps [rsp+0x10], xmm9
00007c454bbd9b6f  movaps [rsp+0x20], xmm15
00007c454bbd9b75  lea rdi, [rsp]
00007c454bbd9b79  mov esi, 0x00
00007c454bbd9b7e  mov rax, 0x56A18AC54530
00007c454bbd9b88  call rax
00007c454bbd9b8a  movaps xmm7, [rsp]
00007c454bbd9b8e  add rsp, 0x30
00007c454bbd9b92  vmovaps xmm0, [rsp]
00007c454bbd9b97  vmovaps xmm1, [rsp+0x10]
00007c454bbd9b9d  vmovaps xmm2, [rsp+0x20]
00007c454bbd9ba3  vmovaps xmm3, [rsp+0x30]
00007c454bbd9ba9  vmovaps xmm4, [rsp+0x40]
00007c454bbd9baf  vmovaps xmm5, [rsp+0x50]
00007c454bbd9bb5  vmovaps xmm6, [rsp+0x60]
00007c454bbd9bbb  vmovaps xmm8, [rsp+0x70]
00007c454bbd9bc1  vmovaps xmm9, [rsp+0x80]
00007c454bbd9bca  vmovaps xmm10, [rsp+0x90]
00007c454bbd9bd3  vmovaps xmm11, [rsp+0xA0]
00007c454bbd9bdc  vmovaps xmm12, [rsp+0xB0]
00007c454bbd9be5  vmovaps xmm13, [rsp+0xC0]
00007c454bbd9bee  vmovaps xmm14, [rsp+0xD0]
00007c454bbd9bf7  vmovaps xmm15, [rsp+0xE0]
00007c454bbd9c00  add rsp, 0xF0
00007c454bbd9c07  pop r11
00007c454bbd9c09  pop r10
00007c454bbd9c0b  pop r9
00007c454bbd9c0d  pop r8
00007c454bbd9c0f  pop rsi
00007c454bbd9c10  pop rdi
00007c454bbd9c11  pop rdx
00007c454bbd9c12  pop rcx
00007c454bbd9c13  pop rax
00007c454bbd9c14  add rsp, 0x08
00007c454bbd9c18  jmp 0x00007C454BBD8BA8
00007c454bbd9c1d  sub rsp, 0x08
00007c454bbd9c21  push rax
00007c454bbd9c22  push rcx
00007c454bbd9c23  push rdx
00007c454bbd9c24  push rdi
00007c454bbd9c25  push rsi
00007c454bbd9c26  push r8
00007c454bbd9c28  push r9
00007c454bbd9c2a  push r10
00007c454bbd9c2c  push r11
00007c454bbd9c2e  sub rsp, 0xF0
00007c454bbd9c35  vmovaps [rsp], xmm0
00007c454bbd9c3a  vmovaps [rsp+0x10], xmm1
00007c454bbd9c40  vmovaps [rsp+0x20], xmm2
00007c454bbd9c46  vmovaps [rsp+0x30], xmm3
00007c454bbd9c4c  vmovaps [rsp+0x40], xmm4
00007c454bbd9c52  vmovaps [rsp+0x50], xmm5
00007c454bbd9c58  vmovaps [rsp+0x60], xmm6
00007c454bbd9c5e  vmovaps [rsp+0x70], xmm7
00007c454bbd9c64  vmovaps [rsp+0x80], xmm8
00007c454bbd9c6d  vmovaps [rsp+0x90], xmm10
00007c454bbd9c76  vmovaps [rsp+0xA0], xmm11
00007c454bbd9c7f  vmovaps [rsp+0xB0], xmm12
00007c454bbd9c88  vmovaps [rsp+0xC0], xmm13
00007c454bbd9c91  vmovaps [rsp+0xD0], xmm14
00007c454bbd9c9a  vmovaps [rsp+0xE0], xmm15
00007c454bbd9ca3  sub rsp, 0x30
00007c454bbd9ca7  movaps [rsp], xmm9
00007c454bbd9cac  movaps [rsp+0x10], xmm12
00007c454bbd9cb2  movaps [rsp+0x20], xmm10
00007c454bbd9cb8  lea rdi, [rsp]
00007c454bbd9cbc  mov esi, 0x00
00007c454bbd9cc1  mov rax, 0x56A18AC54530
00007c454bbd9ccb  call rax
00007c454bbd9ccd  movaps xmm9, [rsp]
00007c454bbd9cd2  add rsp, 0x30
00007c454bbd9cd6  vmovaps xmm0, [rsp]
00007c454bbd9cdb  vmovaps xmm1, [rsp+0x10]
00007c454bbd9ce1  vmovaps xmm2, [rsp+0x20]
00007c454bbd9ce7  vmovaps xmm3, [rsp+0x30]
00007c454bbd9ced  vmovaps xmm4, [rsp+0x40]
00007c454bbd9cf3  vmovaps xmm5, [rsp+0x50]
00007c454bbd9cf9  vmovaps xmm6, [rsp+0x60]
00007c454bbd9cff  vmovaps xmm7, [rsp+0x70]
00007c454bbd9d05  vmovaps xmm8, [rsp+0x80]
00007c454bbd9d0e  vmovaps xmm10, [rsp+0x90]
00007c454bbd9d17  vmovaps xmm11, [rsp+0xA0]
00007c454bbd9d20  vmovaps xmm12, [rsp+0xB0]
00007c454bbd9d29  vmovaps xmm13, [rsp+0xC0]
00007c454bbd9d32  vmovaps xmm14, [rsp+0xD0]
00007c454bbd9d3b  vmovaps xmm15, [rsp+0xE0]
00007c454bbd9d44  add rsp, 0xF0
00007c454bbd9d4b  pop r11
00007c454bbd9d4d  pop r10
00007c454bbd9d4f  pop r9
00007c454bbd9d51  pop r8
00007c454bbd9d53  pop rsi
00007c454bbd9d54  pop rdi
00007c454bbd9d55  pop rdx
00007c454bbd9d56  pop rcx
00007c454bbd9d57  pop rax
00007c454bbd9d58  add rsp, 0x08
00007c454bbd9d5c  jmp 0x00007C454BBD8BCC
00007c454bbd9d61  sub rsp, 0x08
00007c454bbd9d65  push rax
00007c454bbd9d66  push rcx
00007c454bbd9d67  push rdx
00007c454bbd9d68  push rdi
00007c454bbd9d69  push rsi
00007c454bbd9d6a  push r8
00007c454bbd9d6c  push r9
00007c454bbd9d6e  push r10
00007c454bbd9d70  push r11
00007c454bbd9d72  sub rsp, 0xF0
00007c454bbd9d79  vmovaps [rsp], xmm0
00007c454bbd9d7e  vmovaps [rsp+0x10], xmm1
00007c454bbd9d84  vmovaps [rsp+0x20], xmm2
00007c454bbd9d8a  vmovaps [rsp+0x30], xmm3
00007c454bbd9d90  vmovaps [rsp+0x40], xmm4
00007c454bbd9d96  vmovaps [rsp+0x50], xmm5
00007c454bbd9d9c  vmovaps [rsp+0x60], xmm6
00007c454bbd9da2  vmovaps [rsp+0x70], xmm7
00007c454bbd9da8  vmovaps [rsp+0x80], xmm8
00007c454bbd9db1  vmovaps [rsp+0x90], xmm9
00007c454bbd9dba  vmovaps [rsp+0xA0], xmm11
00007c454bbd9dc3  vmovaps [rsp+0xB0], xmm12
00007c454bbd9dcc  vmovaps [rsp+0xC0], xmm13
00007c454bbd9dd5  vmovaps [rsp+0xD0], xmm14
00007c454bbd9dde  vmovaps [rsp+0xE0], xmm15
00007c454bbd9de7  sub rsp, 0x30
00007c454bbd9deb  movaps [rsp], xmm10
00007c454bbd9df0  movaps [rsp+0x10], xmm12
00007c454bbd9df6  movaps [rsp+0x20], xmm11
00007c454bbd9dfc  lea rdi, [rsp]
00007c454bbd9e00  mov esi, 0x00
00007c454bbd9e05  mov rax, 0x56A18AC54530
00007c454bbd9e0f  call rax
00007c454bbd9e11  movaps xmm10, [rsp]
00007c454bbd9e16  add rsp, 0x30
00007c454bbd9e1a  vmovaps xmm0, [rsp]
00007c454bbd9e1f  vmovaps xmm1, [rsp+0x10]
00007c454bbd9e25  vmovaps xmm2, [rsp+0x20]
00007c454bbd9e2b  vmovaps xmm3, [rsp+0x30]
00007c454bbd9e31  vmovaps xmm4, [rsp+0x40]
00007c454bbd9e37  vmovaps xmm5, [rsp+0x50]
00007c454bbd9e3d  vmovaps xmm6, [rsp+0x60]
00007c454bbd9e43  vmovaps xmm7, [rsp+0x70]
00007c454bbd9e49  vmovaps xmm8, [rsp+0x80]
00007c454bbd9e52  vmovaps xmm9, [rsp+0x90]
00007c454bbd9e5b  vmovaps xmm11, [rsp+0xA0]
00007c454bbd9e64  vmovaps xmm12, [rsp+0xB0]
00007c454bbd9e6d  vmovaps xmm13, [rsp+0xC0]
00007c454bbd9e76  vmovaps xmm14, [rsp+0xD0]
00007c454bbd9e7f  vmovaps xmm15, [rsp+0xE0]
00007c454bbd9e88  add rsp, 0xF0
00007c454bbd9e8f  pop r11
00007c454bbd9e91  pop r10
00007c454bbd9e93  pop r9
00007c454bbd9e95  pop r8
00007c454bbd9e97  pop rsi
00007c454bbd9e98  pop rdi
00007c454bbd9e99  pop rdx
00007c454bbd9e9a  pop rcx
00007c454bbd9e9b  pop rax
00007c454bbd9e9c  add rsp, 0x08
00007c454bbd9ea0  jmp 0x00007C454BBD8BE6
00007c454bbd9ea5  sub rsp, 0x08
00007c454bbd9ea9  push rax
00007c454bbd9eaa  push rcx
00007c454bbd9eab  push rdx
00007c454bbd9eac  push rdi
00007c454bbd9ead  push rsi
00007c454bbd9eae  push r8
00007c454bbd9eb0  push r9
00007c454bbd9eb2  push r10
00007c454bbd9eb4  push r11
00007c454bbd9eb6  sub rsp, 0xF0
00007c454bbd9ebd  vmovaps [rsp], xmm0
00007c454bbd9ec2  vmovaps [rsp+0x10], xmm1
00007c454bbd9ec8  vmovaps [rsp+0x20], xmm2
00007c454bbd9ece  vmovaps [rsp+0x30], xmm3
00007c454bbd9ed4  vmovaps [rsp+0x40], xmm4
00007c454bbd9eda  vmovaps [rsp+0x50], xmm5
00007c454bbd9ee0  vmovaps [rsp+0x60], xmm7
00007c454bbd9ee6  vmovaps [rsp+0x70], xmm8
00007c454bbd9eec  vmovaps [rsp+0x80], xmm9
00007c454bbd9ef5  vmovaps [rsp+0x90], xmm10
00007c454bbd9efe  vmovaps [rsp+0xA0], xmm11
00007c454bbd9f07  vmovaps [rsp+0xB0], xmm12
00007c454bbd9f10  vmovaps [rsp+0xC0], xmm13
00007c454bbd9f19  vmovaps [rsp+0xD0], xmm14
00007c454bbd9f22  vmovaps [rsp+0xE0], xmm15
00007c454bbd9f2b  sub rsp, 0x30
00007c454bbd9f2f  movaps [rsp], xmm6
00007c454bbd9f33  movaps [rsp+0x10], xmm12
00007c454bbd9f39  movaps [rsp+0x20], xmm11
00007c454bbd9f3f  lea rdi, [rsp]
00007c454bbd9f43  mov esi, 0x00
00007c454bbd9f48  mov rax, 0x56A18AC54530
00007c454bbd9f52  call rax
00007c454bbd9f54  movaps xmm6, [rsp]
00007c454bbd9f58  add rsp, 0x30
00007c454bbd9f5c  vmovaps xmm0, [rsp]
00007c454bbd9f61  vmovaps xmm1, [rsp+0x10]
00007c454bbd9f67  vmovaps xmm2, [rsp+0x20]
00007c454bbd9f6d  vmovaps xmm3, [rsp+0x30]
00007c454bbd9f73  vmovaps xmm4, [rsp+0x40]
00007c454bbd9f79  vmovaps xmm5, [rsp+0x50]
00007c454bbd9f7f  vmovaps xmm7, [rsp+0x60]
00007c454bbd9f85  vmovaps xmm8, [rsp+0x70]
00007c454bbd9f8b  vmovaps xmm9, [rsp+0x80]
00007c454bbd9f94  vmovaps xmm10, [rsp+0x90]
00007c454bbd9f9d  vmovaps xmm11, [rsp+0xA0]
00007c454bbd9fa6  vmovaps xmm12, [rsp+0xB0]
00007c454bbd9faf  vmovaps xmm13, [rsp+0xC0]
00007c454bbd9fb8  vmovaps xmm14, [rsp+0xD0]
00007c454bbd9fc1  vmovaps xmm15, [rsp+0xE0]
00007c454bbd9fca  add rsp, 0xF0
00007c454bbd9fd1  pop r11
00007c454bbd9fd3  pop r10
00007c454bbd9fd5  pop r9
00007c454bbd9fd7  pop r8
00007c454bbd9fd9  pop rsi
00007c454bbd9fda  pop rdi
00007c454bbd9fdb  pop rdx
00007c454bbd9fdc  pop rcx
00007c454bbd9fdd  pop rax
00007c454bbd9fde  add rsp, 0x08
00007c454bbd9fe2  jmp 0x00007C454BBD8C07
00007c454bbd9fe7  sub rsp, 0x08
00007c454bbd9feb  push rax
00007c454bbd9fec  push rcx
00007c454bbd9fed  push rdx
00007c454bbd9fee  push rdi
00007c454bbd9fef  push rsi
00007c454bbd9ff0  push r8
00007c454bbd9ff2  push r9
00007c454bbd9ff4  push r10
00007c454bbd9ff6  push r11
00007c454bbd9ff8  sub rsp, 0xF0
00007c454bbd9fff  vmovaps [rsp], xmm0
00007c454bbda004  vmovaps [rsp+0x10], xmm1
00007c454bbda00a  vmovaps [rsp+0x20], xmm2
00007c454bbda010  vmovaps [rsp+0x30], xmm4
00007c454bbda016  vmovaps [rsp+0x40], xmm5
00007c454bbda01c  vmovaps [rsp+0x50], xmm6
00007c454bbda022  vmovaps [rsp+0x60], xmm7
00007c454bbda028  vmovaps [rsp+0x70], xmm8
00007c454bbda02e  vmovaps [rsp+0x80], xmm9
00007c454bbda037  vmovaps [rsp+0x90], xmm10
00007c454bbda040  vmovaps [rsp+0xA0], xmm11
00007c454bbda049  vmovaps [rsp+0xB0], xmm12
00007c454bbda052  vmovaps [rsp+0xC0], xmm13
00007c454bbda05b  vmovaps [rsp+0xD0], xmm14
00007c454bbda064  vmovaps [rsp+0xE0], xmm15
00007c454bbda06d  sub rsp, 0x30
00007c454bbda071  movaps [rsp], xmm3
00007c454bbda075  movaps [rsp+0x10], xmm5
00007c454bbda07a  movaps [rsp+0x20], xmm4
00007c454bbda07f  lea rdi, [rsp]
00007c454bbda083  mov esi, 0x00
00007c454bbda088  mov rax, 0x56A18AC54530
00007c454bbda092  call rax
00007c454bbda094  movaps xmm3, [rsp]
00007c454bbda098  add rsp, 0x30
00007c454bbda09c  vmovaps xmm0, [rsp]
00007c454bbda0a1  vmovaps xmm1, [rsp+0x10]
00007c454bbda0a7  vmovaps xmm2, [rsp+0x20]
00007c454bbda0ad  vmovaps xmm4, [rsp+0x30]
00007c454bbda0b3  vmovaps xmm5, [rsp+0x40]
00007c454bbda0b9  vmovaps xmm6, [rsp+0x50]
00007c454bbda0bf  vmovaps xmm7, [rsp+0x60]
00007c454bbda0c5  vmovaps xmm8, [rsp+0x70]
00007c454bbda0cb  vmovaps xmm9, [rsp+0x80]
00007c454bbda0d4  vmovaps xmm10, [rsp+0x90]
00007c454bbda0dd  vmovaps xmm11, [rsp+0xA0]
00007c454bbda0e6  vmovaps xmm12, [rsp+0xB0]
00007c454bbda0ef  vmovaps xmm13, [rsp+0xC0]
00007c454bbda0f8  vmovaps xmm14, [rsp+0xD0]
00007c454bbda101  vmovaps xmm15, [rsp+0xE0]
00007c454bbda10a  add rsp, 0xF0
00007c454bbda111  pop r11
00007c454bbda113  pop r10
00007c454bbda115  pop r9
00007c454bbda117  pop r8
00007c454bbda119  pop rsi
00007c454bbda11a  pop rdi
00007c454bbda11b  pop rdx
00007c454bbda11c  pop rcx
00007c454bbda11d  pop rax
00007c454bbda11e  add rsp, 0x08
00007c454bbda122  jmp 0x00007C454BBD8C68
00007c454bbda127  sub rsp, 0x08
00007c454bbda12b  push rax
00007c454bbda12c  push rcx
00007c454bbda12d  push rdx
00007c454bbda12e  push rdi
00007c454bbda12f  push rsi
00007c454bbda130  push r8
00007c454bbda132  push r9
00007c454bbda134  push r10
00007c454bbda136  push r11
00007c454bbda138  sub rsp, 0xF0
00007c454bbda13f  vmovaps [rsp], xmm0
00007c454bbda144  vmovaps [rsp+0x10], xmm1
00007c454bbda14a  vmovaps [rsp+0x20], xmm2
00007c454bbda150  vmovaps [rsp+0x30], xmm3
00007c454bbda156  vmovaps [rsp+0x40], xmm4
00007c454bbda15c  vmovaps [rsp+0x50], xmm6
00007c454bbda162  vmovaps [rsp+0x60], xmm7
00007c454bbda168  vmovaps [rsp+0x70], xmm8
00007c454bbda16e  vmovaps [rsp+0x80], xmm9
00007c454bbda177  vmovaps [rsp+0x90], xmm10
00007c454bbda180  vmovaps [rsp+0xA0], xmm11
00007c454bbda189  vmovaps [rsp+0xB0], xmm12
00007c454bbda192  vmovaps [rsp+0xC0], xmm13
00007c454bbda19b  vmovaps [rsp+0xD0], xmm14
00007c454bbda1a4  vmovaps [rsp+0xE0], xmm15
00007c454bbda1ad  sub rsp, 0x30
00007c454bbda1b1  movaps [rsp], xmm5
00007c454bbda1b5  movaps [rsp+0x10], xmm8
00007c454bbda1bb  movaps [rsp+0x20], xmm15
00007c454bbda1c1  lea rdi, [rsp]
00007c454bbda1c5  mov esi, 0x00
00007c454bbda1ca  mov rax, 0x56A18AC54530
00007c454bbda1d4  call rax
00007c454bbda1d6  movaps xmm5, [rsp]
00007c454bbda1da  add rsp, 0x30
00007c454bbda1de  vmovaps xmm0, [rsp]
00007c454bbda1e3  vmovaps xmm1, [rsp+0x10]
00007c454bbda1e9  vmovaps xmm2, [rsp+0x20]
00007c454bbda1ef  vmovaps xmm3, [rsp+0x30]
00007c454bbda1f5  vmovaps xmm4, [rsp+0x40]
00007c454bbda1fb  vmovaps xmm6, [rsp+0x50]
00007c454bbda201  vmovaps xmm7, [rsp+0x60]
00007c454bbda207  vmovaps xmm8, [rsp+0x70]
00007c454bbda20d  vmovaps xmm9, [rsp+0x80]
00007c454bbda216  vmovaps xmm10, [rsp+0x90]
00007c454bbda21f  vmovaps xmm11, [rsp+0xA0]
00007c454bbda228  vmovaps xmm12, [rsp+0xB0]
00007c454bbda231  vmovaps xmm13, [rsp+0xC0]
00007c454bbda23a  vmovaps xmm14, [rsp+0xD0]
00007c454bbda243  vmovaps xmm15, [rsp+0xE0]
00007c454bbda24c  add rsp, 0xF0
00007c454bbda253  pop r11
00007c454bbda255  pop r10
00007c454bbda257  pop r9
00007c454bbda259  pop r8
00007c454bbda25b  pop rsi
00007c454bbda25c  pop rdi
00007c454bbda25d  pop rdx
00007c454bbda25e  pop rcx
00007c454bbda25f  pop rax
00007c454bbda260  add rsp, 0x08
00007c454bbda264  jmp 0x00007C454BBD8CA0
00007c454bbda269  sub rsp, 0x08
00007c454bbda26d  push rax
00007c454bbda26e  push rcx
00007c454bbda26f  push rdx
00007c454bbda270  push rdi
00007c454bbda271  push rsi
00007c454bbda272  push r8
00007c454bbda274  push r9
00007c454bbda276  push r10
00007c454bbda278  push r11
00007c454bbda27a  sub rsp, 0xF0
00007c454bbda281  vmovaps [rsp], xmm0
00007c454bbda286  vmovaps [rsp+0x10], xmm1
00007c454bbda28c  vmovaps [rsp+0x20], xmm2
00007c454bbda292  vmovaps [rsp+0x30], xmm3
00007c454bbda298  vmovaps [rsp+0x40], xmm5
00007c454bbda29e  vmovaps [rsp+0x50], xmm6
00007c454bbda2a4  vmovaps [rsp+0x60], xmm7
00007c454bbda2aa  vmovaps [rsp+0x70], xmm8
00007c454bbda2b0  vmovaps [rsp+0x80], xmm9
00007c454bbda2b9  vmovaps [rsp+0x90], xmm10
00007c454bbda2c2  vmovaps [rsp+0xA0], xmm11
00007c454bbda2cb  vmovaps [rsp+0xB0], xmm12
00007c454bbda2d4  vmovaps [rsp+0xC0], xmm13
00007c454bbda2dd  vmovaps [rsp+0xD0], xmm14
00007c454bbda2e6  vmovaps [rsp+0xE0], xmm15
00007c454bbda2ef  sub rsp, 0x30
00007c454bbda2f3  movaps [rsp], xmm4
00007c454bbda2f7  movaps [rsp+0x10], xmm9
00007c454bbda2fd  movaps [rsp+0x20], xmm8
00007c454bbda303  lea rdi, [rsp]
00007c454bbda307  mov esi, 0x00
00007c454bbda30c  mov rax, 0x56A18AC54530
00007c454bbda316  call rax
00007c454bbda318  movaps xmm4, [rsp]
00007c454bbda31c  add rsp, 0x30
00007c454bbda320  vmovaps xmm0, [rsp]
00007c454bbda325  vmovaps xmm1, [rsp+0x10]
00007c454bbda32b  vmovaps xmm2, [rsp+0x20]
00007c454bbda331  vmovaps xmm3, [rsp+0x30]
00007c454bbda337  vmovaps xmm5, [rsp+0x40]
00007c454bbda33d  vmovaps xmm6, [rsp+0x50]
00007c454bbda343  vmovaps xmm7, [rsp+0x60]
00007c454bbda349  vmovaps xmm8, [rsp+0x70]
00007c454bbda34f  vmovaps xmm9, [rsp+0x80]
00007c454bbda358  vmovaps xmm10, [rsp+0x90]
00007c454bbda361  vmovaps xmm11, [rsp+0xA0]
00007c454bbda36a  vmovaps xmm12, [rsp+0xB0]
00007c454bbda373  vmovaps xmm13, [rsp+0xC0]
00007c454bbda37c  vmovaps xmm14, [rsp+0xD0]
00007c454bbda385  vmovaps xmm15, [rsp+0xE0]
00007c454bbda38e  add rsp, 0xF0
00007c454bbda395  pop r11
00007c454bbda397  pop r10
00007c454bbda399  pop r9
00007c454bbda39b  pop r8
00007c454bbda39d  pop rsi
00007c454bbda39e  pop rdi
00007c454bbda39f  pop rdx
00007c454bbda3a0  pop rcx
00007c454bbda3a1  pop rax
00007c454bbda3a2  add rsp, 0x08
00007c454bbda3a6  jmp 0x00007C454BBD8CC1
00007c454bbda3ab  sub rsp, 0x08
00007c454bbda3af  push rax
00007c454bbda3b0  push rcx
00007c454bbda3b1  push rdx
00007c454bbda3b2  push rdi
00007c454bbda3b3  push rsi
00007c454bbda3b4  push r8
00007c454bbda3b6  push r9
00007c454bbda3b8  push r10
00007c454bbda3ba  push r11
00007c454bbda3bc  sub rsp, 0xF0
00007c454bbda3c3  vmovaps [rsp], xmm0
00007c454bbda3c8  vmovaps [rsp+0x10], xmm1
00007c454bbda3ce  vmovaps [rsp+0x20], xmm2
00007c454bbda3d4  vmovaps [rsp+0x30], xmm3
00007c454bbda3da  vmovaps [rsp+0x40], xmm4
00007c454bbda3e0  vmovaps [rsp+0x50], xmm5
00007c454bbda3e6  vmovaps [rsp+0x60], xmm6
00007c454bbda3ec  vmovaps [rsp+0x70], xmm7
00007c454bbda3f2  vmovaps [rsp+0x80], xmm8
00007c454bbda3fb  vmovaps [rsp+0x90], xmm10
00007c454bbda404  vmovaps [rsp+0xA0], xmm11
00007c454bbda40d  vmovaps [rsp+0xB0], xmm12
00007c454bbda416  vmovaps [rsp+0xC0], xmm13
00007c454bbda41f  vmovaps [rsp+0xD0], xmm14
00007c454bbda428  vmovaps [rsp+0xE0], xmm15
00007c454bbda431  sub rsp, 0x30
00007c454bbda435  movaps [rsp], xmm9
00007c454bbda43a  movaps [rsp+0x10], xmm10
00007c454bbda440  movaps [rsp+0x20], xmm8
00007c454bbda446  lea rdi, [rsp]
00007c454bbda44a  mov esi, 0x00
00007c454bbda44f  mov rax, 0x56A18AC54530
00007c454bbda459  call rax
00007c454bbda45b  movaps xmm9, [rsp]
00007c454bbda460  add rsp, 0x30
00007c454bbda464  vmovaps xmm0, [rsp]
00007c454bbda469  vmovaps xmm1, [rsp+0x10]
00007c454bbda46f  vmovaps xmm2, [rsp+0x20]
00007c454bbda475  vmovaps xmm3, [rsp+0x30]
00007c454bbda47b  vmovaps xmm4, [rsp+0x40]
00007c454bbda481  vmovaps xmm5, [rsp+0x50]
00007c454bbda487  vmovaps xmm6, [rsp+0x60]
00007c454bbda48d  vmovaps xmm7, [rsp+0x70]
00007c454bbda493  vmovaps xmm8, [rsp+0x80]
00007c454bbda49c  vmovaps xmm10, [rsp+0x90]
00007c454bbda4a5  vmovaps xmm11, [rsp+0xA0]
00007c454bbda4ae  vmovaps xmm12, [rsp+0xB0]
00007c454bbda4b7  vmovaps xmm13, [rsp+0xC0]
00007c454bbda4c0  vmovaps xmm14, [rsp+0xD0]
00007c454bbda4c9  vmovaps xmm15, [rsp+0xE0]
00007c454bbda4d2  add rsp, 0xF0
00007c454bbda4d9  pop r11
00007c454bbda4db  pop r10
00007c454bbda4dd  pop r9
00007c454bbda4df  pop r8
00007c454bbda4e1  pop rsi
00007c454bbda4e2  pop rdi
00007c454bbda4e3  pop rdx
00007c454bbda4e4  pop rcx
00007c454bbda4e5  pop rax
00007c454bbda4e6  add rsp, 0x08
00007c454bbda4ea  jmp 0x00007C454BBD8CDB
00007c454bbda4ef  call 0x00007C454BAD64F0
00007c454bbda4f4  jmp 0x00007C454BBD8DF5
00007c454bbda4f9  call 0x00007C454BAD64F0
00007c454bbda4fe  jmp 0x00007C454BBD8E0B
00007c454bbda503  sub rsp, 0x08
00007c454bbda507  push rax
00007c454bbda508  push rcx
00007c454bbda509  push rdx
00007c454bbda50a  push rdi
00007c454bbda50b  push rsi
00007c454bbda50c  push r8
00007c454bbda50e  push r9
00007c454bbda510  push r10
00007c454bbda512  push r11
00007c454bbda514  sub rsp, 0xF0
00007c454bbda51b  vmovaps [rsp], xmm0
00007c454bbda520  vmovaps [rsp+0x10], xmm2
00007c454bbda526  vmovaps [rsp+0x20], xmm3
00007c454bbda52c  vmovaps [rsp+0x30], xmm4
00007c454bbda532  vmovaps [rsp+0x40], xmm5
00007c454bbda538  vmovaps [rsp+0x50], xmm6
00007c454bbda53e  vmovaps [rsp+0x60], xmm7
00007c454bbda544  vmovaps [rsp+0x70], xmm8
00007c454bbda54a  vmovaps [rsp+0x80], xmm9
00007c454bbda553  vmovaps [rsp+0x90], xmm10
00007c454bbda55c  vmovaps [rsp+0xA0], xmm11
00007c454bbda565  vmovaps [rsp+0xB0], xmm12
00007c454bbda56e  vmovaps [rsp+0xC0], xmm13
00007c454bbda577  vmovaps [rsp+0xD0], xmm14
00007c454bbda580  vmovaps [rsp+0xE0], xmm15
00007c454bbda589  sub rsp, 0x30
00007c454bbda58d  movaps [rsp], xmm1
00007c454bbda591  movaps [rsp+0x10], xmm6
00007c454bbda596  movaps [rsp+0x20], xmm15
00007c454bbda59c  lea rdi, [rsp]
00007c454bbda5a0  mov esi, 0x00
00007c454bbda5a5  mov rax, 0x56A18AC54530
00007c454bbda5af  call rax
00007c454bbda5b1  movaps xmm1, [rsp]
00007c454bbda5b5  add rsp, 0x30
00007c454bbda5b9  vmovaps xmm0, [rsp]
00007c454bbda5be  vmovaps xmm2, [rsp+0x10]
00007c454bbda5c4  vmovaps xmm3, [rsp+0x20]
00007c454bbda5ca  vmovaps xmm4, [rsp+0x30]
00007c454bbda5d0  vmovaps xmm5, [rsp+0x40]
00007c454bbda5d6  vmovaps xmm6, [rsp+0x50]
00007c454bbda5dc  vmovaps xmm7, [rsp+0x60]
00007c454bbda5e2  vmovaps xmm8, [rsp+0x70]
00007c454bbda5e8  vmovaps xmm9, [rsp+0x80]
00007c454bbda5f1  vmovaps xmm10, [rsp+0x90]
00007c454bbda5fa  vmovaps xmm11, [rsp+0xA0]
00007c454bbda603  vmovaps xmm12, [rsp+0xB0]
00007c454bbda60c  vmovaps xmm13, [rsp+0xC0]
00007c454bbda615  vmovaps xmm14, [rsp+0xD0]
00007c454bbda61e  vmovaps xmm15, [rsp+0xE0]
00007c454bbda627  add rsp, 0xF0
00007c454bbda62e  pop r11
00007c454bbda630  pop r10
00007c454bbda632  pop r9
00007c454bbda634  pop r8
00007c454bbda636  pop rsi
00007c454bbda637  pop rdi
00007c454bbda638  pop rdx
00007c454bbda639  pop rcx
00007c454bbda63a  pop rax
00007c454bbda63b  add rsp, 0x08
00007c454bbda63f  jmp 0x00007C454BBD8E48
00007c454bbda644  call 0x00007C454BAE5820
00007c454bbda649  jmp 0x00007C454BBD8E55
00007c454bbda64e  sub rsp, 0x08
00007c454bbda652  push rax
00007c454bbda653  push rcx
00007c454bbda654  push rdx
00007c454bbda655  push rdi
00007c454bbda656  push rsi
00007c454bbda657  push r8
00007c454bbda659  push r9
00007c454bbda65b  push r10
00007c454bbda65d  push r11
00007c454bbda65f  sub rsp, 0xF0
00007c454bbda666  vmovaps [rsp], xmm0
00007c454bbda66b  vmovaps [rsp+0x10], xmm1
00007c454bbda671  vmovaps [rsp+0x20], xmm2
00007c454bbda677  vmovaps [rsp+0x30], xmm3
00007c454bbda67d  vmovaps [rsp+0x40], xmm4
00007c454bbda683  vmovaps [rsp+0x50], xmm5
00007c454bbda689  vmovaps [rsp+0x60], xmm6
00007c454bbda68f  vmovaps [rsp+0x70], xmm7
00007c454bbda695  vmovaps [rsp+0x80], xmm8
00007c454bbda69e  vmovaps [rsp+0x90], xmm9
00007c454bbda6a7  vmovaps [rsp+0xA0], xmm10
00007c454bbda6b0  vmovaps [rsp+0xB0], xmm11
00007c454bbda6b9  vmovaps [rsp+0xC0], xmm12
00007c454bbda6c2  vmovaps [rsp+0xD0], xmm13
00007c454bbda6cb  vmovaps [rsp+0xE0], xmm15
00007c454bbda6d4  sub rsp, 0x30
00007c454bbda6d8  movaps [rsp], xmm14
00007c454bbda6dd  movaps [rsp+0x10], xmm4
00007c454bbda6e2  movaps [rsp+0x20], xmm3
00007c454bbda6e7  lea rdi, [rsp]
00007c454bbda6eb  mov esi, 0x00
00007c454bbda6f0  mov rax, 0x56A18AC54530
00007c454bbda6fa  call rax
00007c454bbda6fc  movaps xmm14, [rsp]
00007c454bbda701  add rsp, 0x30
00007c454bbda705  vmovaps xmm0, [rsp]
00007c454bbda70a  vmovaps xmm1, [rsp+0x10]
00007c454bbda710  vmovaps xmm2, [rsp+0x20]
00007c454bbda716  vmovaps xmm3, [rsp+0x30]
00007c454bbda71c  vmovaps xmm4, [rsp+0x40]
00007c454bbda722  vmovaps xmm5, [rsp+0x50]
00007c454bbda728  vmovaps xmm6, [rsp+0x60]
00007c454bbda72e  vmovaps xmm7, [rsp+0x70]
00007c454bbda734  vmovaps xmm8, [rsp+0x80]
00007c454bbda73d  vmovaps xmm9, [rsp+0x90]
00007c454bbda746  vmovaps xmm10, [rsp+0xA0]
00007c454bbda74f  vmovaps xmm11, [rsp+0xB0]
00007c454bbda758  vmovaps xmm12, [rsp+0xC0]
00007c454bbda761  vmovaps xmm13, [rsp+0xD0]
00007c454bbda76a  vmovaps xmm15, [rsp+0xE0]
00007c454bbda773  add rsp, 0xF0
00007c454bbda77a  pop r11
00007c454bbda77c  pop r10
00007c454bbda77e  pop r9
00007c454bbda780  pop r8
00007c454bbda782  pop rsi
00007c454bbda783  pop rdi
00007c454bbda784  pop rdx
00007c454bbda785  pop rcx
00007c454bbda786  pop rax
00007c454bbda787  add rsp, 0x08
00007c454bbda78b  jmp 0x00007C454BBD8E6F
00007c454bbda790  sub rsp, 0x08
00007c454bbda794  push rax
00007c454bbda795  push rcx
00007c454bbda796  push rdx
00007c454bbda797  push rdi
00007c454bbda798  push rsi
00007c454bbda799  push r8
00007c454bbda79b  push r9
00007c454bbda79d  push r10
00007c454bbda79f  push r11
00007c454bbda7a1  sub rsp, 0xF0
00007c454bbda7a8  vmovaps [rsp], xmm0
00007c454bbda7ad  vmovaps [rsp+0x10], xmm1
00007c454bbda7b3  vmovaps [rsp+0x20], xmm2
00007c454bbda7b9  vmovaps [rsp+0x30], xmm3
00007c454bbda7bf  vmovaps [rsp+0x40], xmm4
00007c454bbda7c5  vmovaps [rsp+0x50], xmm5
00007c454bbda7cb  vmovaps [rsp+0x60], xmm7
00007c454bbda7d1  vmovaps [rsp+0x70], xmm8
00007c454bbda7d7  vmovaps [rsp+0x80], xmm9
00007c454bbda7e0  vmovaps [rsp+0x90], xmm10
00007c454bbda7e9  vmovaps [rsp+0xA0], xmm11
00007c454bbda7f2  vmovaps [rsp+0xB0], xmm12
00007c454bbda7fb  vmovaps [rsp+0xC0], xmm13
00007c454bbda804  vmovaps [rsp+0xD0], xmm14
00007c454bbda80d  vmovaps [rsp+0xE0], xmm15
00007c454bbda816  sub rsp, 0x30
00007c454bbda81a  movaps [rsp], xmm6
00007c454bbda81e  movaps [rsp+0x10], xmm9
00007c454bbda824  movaps [rsp+0x20], xmm7
00007c454bbda829  lea rdi, [rsp]
00007c454bbda82d  mov esi, 0x00
00007c454bbda832  mov rax, 0x56A18AC54530
00007c454bbda83c  call rax
00007c454bbda83e  movaps xmm6, [rsp]
00007c454bbda842  add rsp, 0x30
00007c454bbda846  vmovaps xmm0, [rsp]
00007c454bbda84b  vmovaps xmm1, [rsp+0x10]
00007c454bbda851  vmovaps xmm2, [rsp+0x20]
00007c454bbda857  vmovaps xmm3, [rsp+0x30]
00007c454bbda85d  vmovaps xmm4, [rsp+0x40]
00007c454bbda863  vmovaps xmm5, [rsp+0x50]
00007c454bbda869  vmovaps xmm7, [rsp+0x60]
00007c454bbda86f  vmovaps xmm8, [rsp+0x70]
00007c454bbda875  vmovaps xmm9, [rsp+0x80]
00007c454bbda87e  vmovaps xmm10, [rsp+0x90]
00007c454bbda887  vmovaps xmm11, [rsp+0xA0]
00007c454bbda890  vmovaps xmm12, [rsp+0xB0]
00007c454bbda899  vmovaps xmm13, [rsp+0xC0]
00007c454bbda8a2  vmovaps xmm14, [rsp+0xD0]
00007c454bbda8ab  vmovaps xmm15, [rsp+0xE0]
00007c454bbda8b4  add rsp, 0xF0
00007c454bbda8bb  pop r11
00007c454bbda8bd  pop r10
00007c454bbda8bf  pop r9
00007c454bbda8c1  pop r8
00007c454bbda8c3  pop rsi
00007c454bbda8c4  pop rdi
00007c454bbda8c5  pop rdx
00007c454bbda8c6  pop rcx
00007c454bbda8c7  pop rax
00007c454bbda8c8  add rsp, 0x08
00007c454bbda8cc  jmp 0x00007C454BBD8E87
00007c454bbda8d1  sub rsp, 0x08
00007c454bbda8d5  push rax
00007c454bbda8d6  push rcx
00007c454bbda8d7  push rdx
00007c454bbda8d8  push rdi
00007c454bbda8d9  push rsi
00007c454bbda8da  push r8
00007c454bbda8dc  push r9
00007c454bbda8de  push r10
00007c454bbda8e0  push r11
00007c454bbda8e2  sub rsp, 0xF0
00007c454bbda8e9  vmovaps [rsp], xmm0
00007c454bbda8ee  vmovaps [rsp+0x10], xmm1
00007c454bbda8f4  vmovaps [rsp+0x20], xmm2
00007c454bbda8fa  vmovaps [rsp+0x30], xmm3
00007c454bbda900  vmovaps [rsp+0x40], xmm4
00007c454bbda906  vmovaps [rsp+0x50], xmm5
00007c454bbda90c  vmovaps [rsp+0x60], xmm6
00007c454bbda912  vmovaps [rsp+0x70], xmm8
00007c454bbda918  vmovaps [rsp+0x80], xmm9
00007c454bbda921  vmovaps [rsp+0x90], xmm10
00007c454bbda92a  vmovaps [rsp+0xA0], xmm11
00007c454bbda933  vmovaps [rsp+0xB0], xmm12
00007c454bbda93c  vmovaps [rsp+0xC0], xmm13
00007c454bbda945  vmovaps [rsp+0xD0], xmm14
00007c454bbda94e  vmovaps [rsp+0xE0], xmm15
00007c454bbda957  sub rsp, 0x30
00007c454bbda95b  movaps [rsp], xmm7
00007c454bbda95f  movaps [rsp+0x10], xmm4
00007c454bbda964  movaps [rsp+0x20], xmm9
00007c454bbda96a  lea rdi, [rsp]
00007c454bbda96e  mov esi, 0x00
00007c454bbda973  mov rax, 0x56A18AC54530
00007c454bbda97d  call rax
00007c454bbda97f  movaps xmm7, [rsp]
00007c454bbda983  add rsp, 0x30
00007c454bbda987  vmovaps xmm0, [rsp]
00007c454bbda98c  vmovaps xmm1, [rsp+0x10]
00007c454bbda992  vmovaps xmm2, [rsp+0x20]
00007c454bbda998  vmovaps xmm3, [rsp+0x30]
00007c454bbda99e  vmovaps xmm4, [rsp+0x40]
00007c454bbda9a4  vmovaps xmm5, [rsp+0x50]
00007c454bbda9aa  vmovaps xmm6, [rsp+0x60]
00007c454bbda9b0  vmovaps xmm8, [rsp+0x70]
00007c454bbda9b6  vmovaps xmm9, [rsp+0x80]
00007c454bbda9bf  vmovaps xmm10, [rsp+0x90]
00007c454bbda9c8  vmovaps xmm11, [rsp+0xA0]
00007c454bbda9d1  vmovaps xmm12, [rsp+0xB0]
00007c454bbda9da  vmovaps xmm13, [rsp+0xC0]
00007c454bbda9e3  vmovaps xmm14, [rsp+0xD0]
00007c454bbda9ec  vmovaps xmm15, [rsp+0xE0]
00007c454bbda9f5  add rsp, 0xF0
00007c454bbda9fc  pop r11
00007c454bbda9fe  pop r10
00007c454bbdaa00  pop r9
00007c454bbdaa02  pop r8
00007c454bbdaa04  pop rsi
00007c454bbdaa05  pop rdi
00007c454bbdaa06  pop rdx
00007c454bbdaa07  pop rcx
00007c454bbdaa08  pop rax
00007c454bbdaa09  add rsp, 0x08
00007c454bbdaa0d  jmp 0x00007C454BBD8EB4
00007c454bbdaa12  sub rsp, 0x08
00007c454bbdaa16  push rax
00007c454bbdaa17  push rcx
00007c454bbdaa18  push rdx
00007c454bbdaa19  push rdi
00007c454bbdaa1a  push rsi
00007c454bbdaa1b  push r8
00007c454bbdaa1d  push r9
00007c454bbdaa1f  push r10
00007c454bbdaa21  push r11
00007c454bbdaa23  sub rsp, 0xF0
00007c454bbdaa2a  vmovaps [rsp], xmm0
00007c454bbdaa2f  vmovaps [rsp+0x10], xmm1
00007c454bbdaa35  vmovaps [rsp+0x20], xmm2
00007c454bbdaa3b  vmovaps [rsp+0x30], xmm3
00007c454bbdaa41  vmovaps [rsp+0x40], xmm5
00007c454bbdaa47  vmovaps [rsp+0x50], xmm6
00007c454bbdaa4d  vmovaps [rsp+0x60], xmm7
00007c454bbdaa53  vmovaps [rsp+0x70], xmm8
00007c454bbdaa59  vmovaps [rsp+0x80], xmm9
00007c454bbdaa62  vmovaps [rsp+0x90], xmm10
00007c454bbdaa6b  vmovaps [rsp+0xA0], xmm11
00007c454bbdaa74  vmovaps [rsp+0xB0], xmm12
00007c454bbdaa7d  vmovaps [rsp+0xC0], xmm13
00007c454bbdaa86  vmovaps [rsp+0xD0], xmm14
00007c454bbdaa8f  vmovaps [rsp+0xE0], xmm15
00007c454bbdaa98  sub rsp, 0x30
00007c454bbdaa9c  movaps [rsp], xmm4
00007c454bbdaaa0  movaps [rsp+0x10], xmm15
00007c454bbdaaa6  movaps [rsp+0x20], xmm9
00007c454bbdaaac  lea rdi, [rsp]
00007c454bbdaab0  mov esi, 0x00
00007c454bbdaab5  mov rax, 0x56A18AC54530
00007c454bbdaabf  call rax
00007c454bbdaac1  movaps xmm4, [rsp]
00007c454bbdaac5  add rsp, 0x30
00007c454bbdaac9  vmovaps xmm0, [rsp]
00007c454bbdaace  vmovaps xmm1, [rsp+0x10]
00007c454bbdaad4  vmovaps xmm2, [rsp+0x20]
00007c454bbdaada  vmovaps xmm3, [rsp+0x30]
00007c454bbdaae0  vmovaps xmm5, [rsp+0x40]
00007c454bbdaae6  vmovaps xmm6, [rsp+0x50]
00007c454bbdaaec  vmovaps xmm7, [rsp+0x60]
00007c454bbdaaf2  vmovaps xmm8, [rsp+0x70]
00007c454bbdaaf8  vmovaps xmm9, [rsp+0x80]
00007c454bbdab01  vmovaps xmm10, [rsp+0x90]
00007c454bbdab0a  vmovaps xmm11, [rsp+0xA0]
00007c454bbdab13  vmovaps xmm12, [rsp+0xB0]
00007c454bbdab1c  vmovaps xmm13, [rsp+0xC0]
00007c454bbdab25  vmovaps xmm14, [rsp+0xD0]
00007c454bbdab2e  vmovaps xmm15, [rsp+0xE0]
00007c454bbdab37  add rsp, 0xF0
00007c454bbdab3e  pop r11
00007c454bbdab40  pop r10
00007c454bbdab42  pop r9
00007c454bbdab44  pop r8
00007c454bbdab46  pop rsi
00007c454bbdab47  pop rdi
00007c454bbdab48  pop rdx
00007c454bbdab49  pop rcx
00007c454bbdab4a  pop rax
00007c454bbdab4b  add rsp, 0x08
00007c454bbdab4f  jmp 0x00007C454BBD8ED9
00007c454bbdab54  call 0x00007C454BAE5820
00007c454bbdab59  jmp 0x00007C454BBD8EE6
00007c454bbdab5e  sub rsp, 0x08
00007c454bbdab62  push rax
00007c454bbdab63  push rcx
00007c454bbdab64  push rdx
00007c454bbdab65  push rdi
00007c454bbdab66  push rsi
00007c454bbdab67  push r8
00007c454bbdab69  push r9
00007c454bbdab6b  push r10
00007c454bbdab6d  push r11
00007c454bbdab6f  sub rsp, 0xF0
00007c454bbdab76  vmovaps [rsp], xmm0
00007c454bbdab7b  vmovaps [rsp+0x10], xmm1
00007c454bbdab81  vmovaps [rsp+0x20], xmm2
00007c454bbdab87  vmovaps [rsp+0x30], xmm4
00007c454bbdab8d  vmovaps [rsp+0x40], xmm5
00007c454bbdab93  vmovaps [rsp+0x50], xmm6
00007c454bbdab99  vmovaps [rsp+0x60], xmm7
00007c454bbdab9f  vmovaps [rsp+0x70], xmm8
00007c454bbdaba5  vmovaps [rsp+0x80], xmm9
00007c454bbdabae  vmovaps [rsp+0x90], xmm10
00007c454bbdabb7  vmovaps [rsp+0xA0], xmm11
00007c454bbdabc0  vmovaps [rsp+0xB0], xmm12
00007c454bbdabc9  vmovaps [rsp+0xC0], xmm13
00007c454bbdabd2  vmovaps [rsp+0xD0], xmm14
00007c454bbdabdb  vmovaps [rsp+0xE0], xmm15
00007c454bbdabe4  sub rsp, 0x30
00007c454bbdabe8  movaps [rsp], xmm3
00007c454bbdabec  movaps [rsp+0x10], xmm1
00007c454bbdabf1  movaps [rsp+0x20], xmm9
00007c454bbdabf7  lea rdi, [rsp]
00007c454bbdabfb  mov esi, 0x00
00007c454bbdac00  mov rax, 0x56A18AC54530
00007c454bbdac0a  call rax
00007c454bbdac0c  movaps xmm3, [rsp]
00007c454bbdac10  add rsp, 0x30
00007c454bbdac14  vmovaps xmm0, [rsp]
00007c454bbdac19  vmovaps xmm1, [rsp+0x10]
00007c454bbdac1f  vmovaps xmm2, [rsp+0x20]
00007c454bbdac25  vmovaps xmm4, [rsp+0x30]
00007c454bbdac2b  vmovaps xmm5, [rsp+0x40]
00007c454bbdac31  vmovaps xmm6, [rsp+0x50]
00007c454bbdac37  vmovaps xmm7, [rsp+0x60]
00007c454bbdac3d  vmovaps xmm8, [rsp+0x70]
00007c454bbdac43  vmovaps xmm9, [rsp+0x80]
00007c454bbdac4c  vmovaps xmm10, [rsp+0x90]
00007c454bbdac55  vmovaps xmm11, [rsp+0xA0]
00007c454bbdac5e  vmovaps xmm12, [rsp+0xB0]
00007c454bbdac67  vmovaps xmm13, [rsp+0xC0]
00007c454bbdac70  vmovaps xmm14, [rsp+0xD0]
00007c454bbdac79  vmovaps xmm15, [rsp+0xE0]
00007c454bbdac82  add rsp, 0xF0
00007c454bbdac89  pop r11
00007c454bbdac8b  pop r10
00007c454bbdac8d  pop r9
00007c454bbdac8f  pop r8
00007c454bbdac91  pop rsi
00007c454bbdac92  pop rdi
00007c454bbdac93  pop rdx
00007c454bbdac94  pop rcx
00007c454bbdac95  pop rax
00007c454bbdac96  add rsp, 0x08
00007c454bbdac9a  jmp 0x00007C454BBD8F23
00007c454bbdac9f  sub rsp, 0x08
00007c454bbdaca3  push rax
00007c454bbdaca4  push rcx
00007c454bbdaca5  push rdx
00007c454bbdaca6  push rdi
00007c454bbdaca7  push rsi
00007c454bbdaca8  push r8
00007c454bbdacaa  push r9
00007c454bbdacac  push r10
00007c454bbdacae  push r11
00007c454bbdacb0  sub rsp, 0xF0
00007c454bbdacb7  vmovaps [rsp], xmm0
00007c454bbdacbc  vmovaps [rsp+0x10], xmm2
00007c454bbdacc2  vmovaps [rsp+0x20], xmm3
00007c454bbdacc8  vmovaps [rsp+0x30], xmm4
00007c454bbdacce  vmovaps [rsp+0x40], xmm5
00007c454bbdacd4  vmovaps [rsp+0x50], xmm6
00007c454bbdacda  vmovaps [rsp+0x60], xmm7
00007c454bbdace0  vmovaps [rsp+0x70], xmm8
00007c454bbdace6  vmovaps [rsp+0x80], xmm9
00007c454bbdacef  vmovaps [rsp+0x90], xmm10
00007c454bbdacf8  vmovaps [rsp+0xA0], xmm11
00007c454bbdad01  vmovaps [rsp+0xB0], xmm12
00007c454bbdad0a  vmovaps [rsp+0xC0], xmm13
00007c454bbdad13  vmovaps [rsp+0xD0], xmm14
00007c454bbdad1c  vmovaps [rsp+0xE0], xmm15
00007c454bbdad25  sub rsp, 0x30
00007c454bbdad29  movaps [rsp], xmm1
00007c454bbdad2d  movaps [rsp+0x10], xmm15
00007c454bbdad33  movaps [rsp+0x20], xmm9
00007c454bbdad39  lea rdi, [rsp]
00007c454bbdad3d  mov esi, 0x00
00007c454bbdad42  mov rax, 0x56A18AC54530
00007c454bbdad4c  call rax
00007c454bbdad4e  movaps xmm1, [rsp]
00007c454bbdad52  add rsp, 0x30
00007c454bbdad56  vmovaps xmm0, [rsp]
00007c454bbdad5b  vmovaps xmm2, [rsp+0x10]
00007c454bbdad61  vmovaps xmm3, [rsp+0x20]
00007c454bbdad67  vmovaps xmm4, [rsp+0x30]
00007c454bbdad6d  vmovaps xmm5, [rsp+0x40]
00007c454bbdad73  vmovaps xmm6, [rsp+0x50]
00007c454bbdad79  vmovaps xmm7, [rsp+0x60]
00007c454bbdad7f  vmovaps xmm8, [rsp+0x70]
00007c454bbdad85  vmovaps xmm9, [rsp+0x80]
00007c454bbdad8e  vmovaps xmm10, [rsp+0x90]
00007c454bbdad97  vmovaps xmm11, [rsp+0xA0]
00007c454bbdada0  vmovaps xmm12, [rsp+0xB0]
00007c454bbdada9  vmovaps xmm13, [rsp+0xC0]
00007c454bbdadb2  vmovaps xmm14, [rsp+0xD0]
00007c454bbdadbb  vmovaps xmm15, [rsp+0xE0]
00007c454bbdadc4  add rsp, 0xF0
00007c454bbdadcb  pop r11
00007c454bbdadcd  pop r10
00007c454bbdadcf  pop r9
00007c454bbdadd1  pop r8
00007c454bbdadd3  pop rsi
00007c454bbdadd4  pop rdi
00007c454bbdadd5  pop rdx
00007c454bbdadd6  pop rcx
00007c454bbdadd7  pop rax
00007c454bbdadd8  add rsp, 0x08
00007c454bbdaddc  jmp 0x00007C454BBD8FAB
00007c454bbdade1  call 0x00007C454BAE5820
00007c454bbdade6  jmp 0x00007C454BBD8FB8
00007c454bbdadeb  sub rsp, 0x08
00007c454bbdadef  push rax
00007c454bbdadf0  push rcx
00007c454bbdadf1  push rdx
00007c454bbdadf2  push rdi
00007c454bbdadf3  push rsi
00007c454bbdadf4  push r8
00007c454bbdadf6  push r9
00007c454bbdadf8  push r10
00007c454bbdadfa  push r11
00007c454bbdadfc  sub rsp, 0xF0
00007c454bbdae03  vmovaps [rsp], xmm0
00007c454bbdae08  vmovaps [rsp+0x10], xmm2
00007c454bbdae0e  vmovaps [rsp+0x20], xmm3
00007c454bbdae14  vmovaps [rsp+0x30], xmm4
00007c454bbdae1a  vmovaps [rsp+0x40], xmm5
00007c454bbdae20  vmovaps [rsp+0x50], xmm6
00007c454bbdae26  vmovaps [rsp+0x60], xmm7
00007c454bbdae2c  vmovaps [rsp+0x70], xmm8
00007c454bbdae32  vmovaps [rsp+0x80], xmm9
00007c454bbdae3b  vmovaps [rsp+0x90], xmm10
00007c454bbdae44  vmovaps [rsp+0xA0], xmm11
00007c454bbdae4d  vmovaps [rsp+0xB0], xmm12
00007c454bbdae56  vmovaps [rsp+0xC0], xmm13
00007c454bbdae5f  vmovaps [rsp+0xD0], xmm14
00007c454bbdae68  vmovaps [rsp+0xE0], xmm15
00007c454bbdae71  sub rsp, 0x30
00007c454bbdae75  movaps [rsp], xmm1
00007c454bbdae79  movaps [rsp+0x10], xmm5
00007c454bbdae7e  movaps [rsp+0x20], xmm7
00007c454bbdae83  lea rdi, [rsp]
00007c454bbdae87  mov esi, 0x00
00007c454bbdae8c  mov rax, 0x56A18AC54530
00007c454bbdae96  call rax
00007c454bbdae98  movaps xmm1, [rsp]
00007c454bbdae9c  add rsp, 0x30
00007c454bbdaea0  vmovaps xmm0, [rsp]
00007c454bbdaea5  vmovaps xmm2, [rsp+0x10]
00007c454bbdaeab  vmovaps xmm3, [rsp+0x20]
00007c454bbdaeb1  vmovaps xmm4, [rsp+0x30]
00007c454bbdaeb7  vmovaps xmm5, [rsp+0x40]
00007c454bbdaebd  vmovaps xmm6, [rsp+0x50]
00007c454bbdaec3  vmovaps xmm7, [rsp+0x60]
00007c454bbdaec9  vmovaps xmm8, [rsp+0x70]
00007c454bbdaecf  vmovaps xmm9, [rsp+0x80]
00007c454bbdaed8  vmovaps xmm10, [rsp+0x90]
00007c454bbdaee1  vmovaps xmm11, [rsp+0xA0]
00007c454bbdaeea  vmovaps xmm12, [rsp+0xB0]
00007c454bbdaef3  vmovaps xmm13, [rsp+0xC0]
00007c454bbdaefc  vmovaps xmm14, [rsp+0xD0]
00007c454bbdaf05  vmovaps xmm15, [rsp+0xE0]
00007c454bbdaf0e  add rsp, 0xF0
00007c454bbdaf15  pop r11
00007c454bbdaf17  pop r10
00007c454bbdaf19  pop r9
00007c454bbdaf1b  pop r8
00007c454bbdaf1d  pop rsi
00007c454bbdaf1e  pop rdi
00007c454bbdaf1f  pop rdx
00007c454bbdaf20  pop rcx
00007c454bbdaf21  pop rax
00007c454bbdaf22  add rsp, 0x08
00007c454bbdaf26  jmp 0x00007C454BBD905D
00007c454bbdaf2b  sub rsp, 0x08
00007c454bbdaf2f  push rax
00007c454bbdaf30  push rcx
00007c454bbdaf31  push rdx
00007c454bbdaf32  push rdi
00007c454bbdaf33  push rsi
00007c454bbdaf34  push r8
00007c454bbdaf36  push r9
00007c454bbdaf38  push r10
00007c454bbdaf3a  push r11
00007c454bbdaf3c  sub rsp, 0xF0
00007c454bbdaf43  vmovaps [rsp], xmm0
00007c454bbdaf48  vmovaps [rsp+0x10], xmm1
00007c454bbdaf4e  vmovaps [rsp+0x20], xmm2
00007c454bbdaf54  vmovaps [rsp+0x30], xmm3
00007c454bbdaf5a  vmovaps [rsp+0x40], xmm4
00007c454bbdaf60  vmovaps [rsp+0x50], xmm5
00007c454bbdaf66  vmovaps [rsp+0x60], xmm6
00007c454bbdaf6c  vmovaps [rsp+0x70], xmm8
00007c454bbdaf72  vmovaps [rsp+0x80], xmm9
00007c454bbdaf7b  vmovaps [rsp+0x90], xmm10
00007c454bbdaf84  vmovaps [rsp+0xA0], xmm11
00007c454bbdaf8d  vmovaps [rsp+0xB0], xmm12
00007c454bbdaf96  vmovaps [rsp+0xC0], xmm13
00007c454bbdaf9f  vmovaps [rsp+0xD0], xmm14
00007c454bbdafa8  vmovaps [rsp+0xE0], xmm15
00007c454bbdafb1  sub rsp, 0x30
00007c454bbdafb5  movaps [rsp], xmm7
00007c454bbdafb9  movaps [rsp+0x10], xmm5
00007c454bbdafbe  movaps [rsp+0x20], xmm15
00007c454bbdafc4  lea rdi, [rsp]
00007c454bbdafc8  mov esi, 0x00
00007c454bbdafcd  mov rax, 0x56A18AC54530
00007c454bbdafd7  call rax
00007c454bbdafd9  movaps xmm7, [rsp]
00007c454bbdafdd  add rsp, 0x30
00007c454bbdafe1  vmovaps xmm0, [rsp]
00007c454bbdafe6  vmovaps xmm1, [rsp+0x10]
00007c454bbdafec  vmovaps xmm2, [rsp+0x20]
00007c454bbdaff2  vmovaps xmm3, [rsp+0x30]
00007c454bbdaff8  vmovaps xmm4, [rsp+0x40]
00007c454bbdaffe  vmovaps xmm5, [rsp+0x50]
00007c454bbdb004  vmovaps xmm6, [rsp+0x60]
00007c454bbdb00a  vmovaps xmm8, [rsp+0x70]
00007c454bbdb010  vmovaps xmm9, [rsp+0x80]
00007c454bbdb019  vmovaps xmm10, [rsp+0x90]
00007c454bbdb022  vmovaps xmm11, [rsp+0xA0]
00007c454bbdb02b  vmovaps xmm12, [rsp+0xB0]
00007c454bbdb034  vmovaps xmm13, [rsp+0xC0]
00007c454bbdb03d  vmovaps xmm14, [rsp+0xD0]
00007c454bbdb046  vmovaps xmm15, [rsp+0xE0]
00007c454bbdb04f  add rsp, 0xF0
00007c454bbdb056  pop r11
00007c454bbdb058  pop r10
00007c454bbdb05a  pop r9
00007c454bbdb05c  pop r8
00007c454bbdb05e  pop rsi
00007c454bbdb05f  pop rdi
00007c454bbdb060  pop rdx
00007c454bbdb061  pop rcx
00007c454bbdb062  pop rax
00007c454bbdb063  add rsp, 0x08
00007c454bbdb067  jmp 0x00007C454BBD9093
00007c454bbdb06c  call 0x00007C454BAD64F0
00007c454bbdb071  jmp 0x00007C454BBD90A0
00007c454bbdb076  sub rsp, 0x08
00007c454bbdb07a  push rax
00007c454bbdb07b  push rcx
00007c454bbdb07c  push rdx
00007c454bbdb07d  push rdi
00007c454bbdb07e  push rsi
00007c454bbdb07f  push r8
00007c454bbdb081  push r9
00007c454bbdb083  push r10
00007c454bbdb085  push r11
00007c454bbdb087  sub rsp, 0xF0
00007c454bbdb08e  vmovaps [rsp], xmm0
00007c454bbdb093  vmovaps [rsp+0x10], xmm1
00007c454bbdb099  vmovaps [rsp+0x20], xmm2
00007c454bbdb09f  vmovaps [rsp+0x30], xmm3
00007c454bbdb0a5  vmovaps [rsp+0x40], xmm4
00007c454bbdb0ab  vmovaps [rsp+0x50], xmm5
00007c454bbdb0b1  vmovaps [rsp+0x60], xmm6
00007c454bbdb0b7  vmovaps [rsp+0x70], xmm7
00007c454bbdb0bd  vmovaps [rsp+0x80], xmm8
00007c454bbdb0c6  vmovaps [rsp+0x90], xmm9
00007c454bbdb0cf  vmovaps [rsp+0xA0], xmm10
00007c454bbdb0d8  vmovaps [rsp+0xB0], xmm11
00007c454bbdb0e1  vmovaps [rsp+0xC0], xmm12
00007c454bbdb0ea  vmovaps [rsp+0xD0], xmm13
00007c454bbdb0f3  vmovaps [rsp+0xE0], xmm14
00007c454bbdb0fc  sub rsp, 0x30
00007c454bbdb100  movaps [rsp], xmm15
00007c454bbdb105  movaps [rsp+0x10], xmm5
00007c454bbdb10a  movaps [rsp+0x20], xmm3
00007c454bbdb10f  lea rdi, [rsp]
00007c454bbdb113  mov esi, 0x00
00007c454bbdb118  mov rax, 0x56A18AC54530
00007c454bbdb122  call rax
00007c454bbdb124  movaps xmm15, [rsp]
00007c454bbdb129  add rsp, 0x30
00007c454bbdb12d  vmovaps xmm0, [rsp]
00007c454bbdb132  vmovaps xmm1, [rsp+0x10]
00007c454bbdb138  vmovaps xmm2, [rsp+0x20]
00007c454bbdb13e  vmovaps xmm3, [rsp+0x30]
00007c454bbdb144  vmovaps xmm4, [rsp+0x40]
00007c454bbdb14a  vmovaps xmm5, [rsp+0x50]
00007c454bbdb150  vmovaps xmm6, [rsp+0x60]
00007c454bbdb156  vmovaps xmm7, [rsp+0x70]
00007c454bbdb15c  vmovaps xmm8, [rsp+0x80]
00007c454bbdb165  vmovaps xmm9, [rsp+0x90]
00007c454bbdb16e  vmovaps xmm10, [rsp+0xA0]
00007c454bbdb177  vmovaps xmm11, [rsp+0xB0]
00007c454bbdb180  vmovaps xmm12, [rsp+0xC0]
00007c454bbdb189  vmovaps xmm13, [rsp+0xD0]
00007c454bbdb192  vmovaps xmm14, [rsp+0xE0]
00007c454bbdb19b  add rsp, 0xF0
00007c454bbdb1a2  pop r11
00007c454bbdb1a4  pop r10
00007c454bbdb1a6  pop r9
00007c454bbdb1a8  pop r8
00007c454bbdb1aa  pop rsi
00007c454bbdb1ab  pop rdi
00007c454bbdb1ac  pop rdx
00007c454bbdb1ad  pop rcx
00007c454bbdb1ae  pop rax
00007c454bbdb1af  add rsp, 0x08
00007c454bbdb1b3  jmp 0x00007C454BBD90C6
00007c454bbdb1b8  sub rsp, 0x08
00007c454bbdb1bc  push rax
00007c454bbdb1bd  push rcx
00007c454bbdb1be  push rdx
00007c454bbdb1bf  push rdi
00007c454bbdb1c0  push rsi
00007c454bbdb1c1  push r8
00007c454bbdb1c3  push r9
00007c454bbdb1c5  push r10
00007c454bbdb1c7  push r11
00007c454bbdb1c9  sub rsp, 0xF0
00007c454bbdb1d0  vmovaps [rsp], xmm0
00007c454bbdb1d5  vmovaps [rsp+0x10], xmm2
00007c454bbdb1db  vmovaps [rsp+0x20], xmm3
00007c454bbdb1e1  vmovaps [rsp+0x30], xmm4
00007c454bbdb1e7  vmovaps [rsp+0x40], xmm5
00007c454bbdb1ed  vmovaps [rsp+0x50], xmm6
00007c454bbdb1f3  vmovaps [rsp+0x60], xmm7
00007c454bbdb1f9  vmovaps [rsp+0x70], xmm8
00007c454bbdb1ff  vmovaps [rsp+0x80], xmm9
00007c454bbdb208  vmovaps [rsp+0x90], xmm10
00007c454bbdb211  vmovaps [rsp+0xA0], xmm11
00007c454bbdb21a  vmovaps [rsp+0xB0], xmm12
00007c454bbdb223  vmovaps [rsp+0xC0], xmm13
00007c454bbdb22c  vmovaps [rsp+0xD0], xmm14
00007c454bbdb235  vmovaps [rsp+0xE0], xmm15
00007c454bbdb23e  sub rsp, 0x30
00007c454bbdb242  movaps [rsp], xmm1
00007c454bbdb246  movaps [rsp+0x10], xmm5
00007c454bbdb24b  movaps [rsp+0x20], xmm4
00007c454bbdb250  lea rdi, [rsp]
00007c454bbdb254  mov esi, 0x00
00007c454bbdb259  mov rax, 0x56A18AC54530
00007c454bbdb263  call rax
00007c454bbdb265  movaps xmm1, [rsp]
00007c454bbdb269  add rsp, 0x30
00007c454bbdb26d  vmovaps xmm0, [rsp]
00007c454bbdb272  vmovaps xmm2, [rsp+0x10]
00007c454bbdb278  vmovaps xmm3, [rsp+0x20]
00007c454bbdb27e  vmovaps xmm4, [rsp+0x30]
00007c454bbdb284  vmovaps xmm5, [rsp+0x40]
00007c454bbdb28a  vmovaps xmm6, [rsp+0x50]
00007c454bbdb290  vmovaps xmm7, [rsp+0x60]
00007c454bbdb296  vmovaps xmm8, [rsp+0x70]
00007c454bbdb29c  vmovaps xmm9, [rsp+0x80]
00007c454bbdb2a5  vmovaps xmm10, [rsp+0x90]
00007c454bbdb2ae  vmovaps xmm11, [rsp+0xA0]
00007c454bbdb2b7  vmovaps xmm12, [rsp+0xB0]
00007c454bbdb2c0  vmovaps xmm13, [rsp+0xC0]
00007c454bbdb2c9  vmovaps xmm14, [rsp+0xD0]
00007c454bbdb2d2  vmovaps xmm15, [rsp+0xE0]
00007c454bbdb2db  add rsp, 0xF0
00007c454bbdb2e2  pop r11
00007c454bbdb2e4  pop r10
00007c454bbdb2e6  pop r9
00007c454bbdb2e8  pop r8
00007c454bbdb2ea  pop rsi
00007c454bbdb2eb  pop rdi
00007c454bbdb2ec  pop rdx
00007c454bbdb2ed  pop rcx
00007c454bbdb2ee  pop rax
00007c454bbdb2ef  add rsp, 0x08
00007c454bbdb2f3  jmp 0x00007C454BBD90E6
00007c454bbdb2f8  sub rsp, 0x08
00007c454bbdb2fc  push rax
00007c454bbdb2fd  push rcx
00007c454bbdb2fe  push rdx
00007c454bbdb2ff  push rdi
00007c454bbdb300  push rsi
00007c454bbdb301  push r8
00007c454bbdb303  push r9
00007c454bbdb305  push r10
00007c454bbdb307  push r11
00007c454bbdb309  sub rsp, 0xF0
00007c454bbdb310  vmovaps [rsp], xmm0
00007c454bbdb315  vmovaps [rsp+0x10], xmm1
00007c454bbdb31b  vmovaps [rsp+0x20], xmm2
00007c454bbdb321  vmovaps [rsp+0x30], xmm3
00007c454bbdb327  vmovaps [rsp+0x40], xmm5
00007c454bbdb32d  vmovaps [rsp+0x50], xmm6
00007c454bbdb333  vmovaps [rsp+0x60], xmm7
00007c454bbdb339  vmovaps [rsp+0x70], xmm8
00007c454bbdb33f  vmovaps [rsp+0x80], xmm9
00007c454bbdb348  vmovaps [rsp+0x90], xmm10
00007c454bbdb351  vmovaps [rsp+0xA0], xmm11
00007c454bbdb35a  vmovaps [rsp+0xB0], xmm12
00007c454bbdb363  vmovaps [rsp+0xC0], xmm13
00007c454bbdb36c  vmovaps [rsp+0xD0], xmm14
00007c454bbdb375  vmovaps [rsp+0xE0], xmm15
00007c454bbdb37e  sub rsp, 0x30
00007c454bbdb382  movaps [rsp], xmm4
00007c454bbdb386  movaps [rsp+0x10], xmm3
00007c454bbdb38b  movaps [rsp+0x20], xmm5
00007c454bbdb390  lea rdi, [rsp]
00007c454bbdb394  mov esi, 0x00
00007c454bbdb399  mov rax, 0x56A18AC54530
00007c454bbdb3a3  call rax
00007c454bbdb3a5  movaps xmm4, [rsp]
00007c454bbdb3a9  add rsp, 0x30
00007c454bbdb3ad  vmovaps xmm0, [rsp]
00007c454bbdb3b2  vmovaps xmm1, [rsp+0x10]
00007c454bbdb3b8  vmovaps xmm2, [rsp+0x20]
00007c454bbdb3be  vmovaps xmm3, [rsp+0x30]
00007c454bbdb3c4  vmovaps xmm5, [rsp+0x40]
00007c454bbdb3ca  vmovaps xmm6, [rsp+0x50]
00007c454bbdb3d0  vmovaps xmm7, [rsp+0x60]
00007c454bbdb3d6  vmovaps xmm8, [rsp+0x70]
00007c454bbdb3dc  vmovaps xmm9, [rsp+0x80]
00007c454bbdb3e5  vmovaps xmm10, [rsp+0x90]
00007c454bbdb3ee  vmovaps xmm11, [rsp+0xA0]
00007c454bbdb3f7  vmovaps xmm12, [rsp+0xB0]
00007c454bbdb400  vmovaps xmm13, [rsp+0xC0]
00007c454bbdb409  vmovaps xmm14, [rsp+0xD0]
00007c454bbdb412  vmovaps xmm15, [rsp+0xE0]
00007c454bbdb41b  add rsp, 0xF0
00007c454bbdb422  pop r11
00007c454bbdb424  pop r10
00007c454bbdb426  pop r9
00007c454bbdb428  pop r8
00007c454bbdb42a  pop rsi
00007c454bbdb42b  pop rdi
00007c454bbdb42c  pop rdx
00007c454bbdb42d  pop rcx
00007c454bbdb42e  pop rax
00007c454bbdb42f  add rsp, 0x08
00007c454bbdb433  jmp 0x00007C454BBD9134
00007c454bbdb438  call 0x00007C454BAD64F0
00007c454bbdb43d  jmp 0x00007C454BBD9141
00007c454bbdb442  sub rsp, 0x08
00007c454bbdb446  push rax
00007c454bbdb447  push rcx
00007c454bbdb448  push rdx
00007c454bbdb449  push rdi
00007c454bbdb44a  push rsi
00007c454bbdb44b  push r8
00007c454bbdb44d  push r9
00007c454bbdb44f  push r10
00007c454bbdb451  push r11
00007c454bbdb453  sub rsp, 0xF0
00007c454bbdb45a  vmovaps [rsp], xmm0
00007c454bbdb45f  vmovaps [rsp+0x10], xmm1
00007c454bbdb465  vmovaps [rsp+0x20], xmm2
00007c454bbdb46b  vmovaps [rsp+0x30], xmm3
00007c454bbdb471  vmovaps [rsp+0x40], xmm4
00007c454bbdb477  vmovaps [rsp+0x50], xmm6
00007c454bbdb47d  vmovaps [rsp+0x60], xmm7
00007c454bbdb483  vmovaps [rsp+0x70], xmm8
00007c454bbdb489  vmovaps [rsp+0x80], xmm9
00007c454bbdb492  vmovaps [rsp+0x90], xmm10
00007c454bbdb49b  vmovaps [rsp+0xA0], xmm11
00007c454bbdb4a4  vmovaps [rsp+0xB0], xmm12
00007c454bbdb4ad  vmovaps [rsp+0xC0], xmm13
00007c454bbdb4b6  vmovaps [rsp+0xD0], xmm14
00007c454bbdb4bf  vmovaps [rsp+0xE0], xmm15
00007c454bbdb4c8  sub rsp, 0x30
00007c454bbdb4cc  movaps [rsp], xmm5
00007c454bbdb4d0  movaps [rsp+0x10], xmm6
00007c454bbdb4d5  movaps [rsp+0x20], xmm3
00007c454bbdb4da  lea rdi, [rsp]
00007c454bbdb4de  mov esi, 0x00
00007c454bbdb4e3  mov rax, 0x56A18AC54530
00007c454bbdb4ed  call rax
00007c454bbdb4ef  movaps xmm5, [rsp]
00007c454bbdb4f3  add rsp, 0x30
00007c454bbdb4f7  vmovaps xmm0, [rsp]
00007c454bbdb4fc  vmovaps xmm1, [rsp+0x10]
00007c454bbdb502  vmovaps xmm2, [rsp+0x20]
00007c454bbdb508  vmovaps xmm3, [rsp+0x30]
00007c454bbdb50e  vmovaps xmm4, [rsp+0x40]
00007c454bbdb514  vmovaps xmm6, [rsp+0x50]
00007c454bbdb51a  vmovaps xmm7, [rsp+0x60]
00007c454bbdb520  vmovaps xmm8, [rsp+0x70]
00007c454bbdb526  vmovaps xmm9, [rsp+0x80]
00007c454bbdb52f  vmovaps xmm10, [rsp+0x90]
00007c454bbdb538  vmovaps xmm11, [rsp+0xA0]
00007c454bbdb541  vmovaps xmm12, [rsp+0xB0]
00007c454bbdb54a  vmovaps xmm13, [rsp+0xC0]
00007c454bbdb553  vmovaps xmm14, [rsp+0xD0]
00007c454bbdb55c  vmovaps xmm15, [rsp+0xE0]
00007c454bbdb565  add rsp, 0xF0
00007c454bbdb56c  pop r11
00007c454bbdb56e  pop r10
00007c454bbdb570  pop r9
00007c454bbdb572  pop r8
00007c454bbdb574  pop rsi
00007c454bbdb575  pop rdi
00007c454bbdb576  pop rdx
00007c454bbdb577  pop rcx
00007c454bbdb578  pop rax
00007c454bbdb579  add rsp, 0x08
00007c454bbdb57d  jmp 0x00007C454BBD9167
00007c454bbdb582  sub rsp, 0x08
00007c454bbdb586  push rax
00007c454bbdb587  push rcx
00007c454bbdb588  push rdx
00007c454bbdb589  push rdi
00007c454bbdb58a  push rsi
00007c454bbdb58b  push r8
00007c454bbdb58d  push r9
00007c454bbdb58f  push r10
00007c454bbdb591  push r11
00007c454bbdb593  sub rsp, 0xF0
00007c454bbdb59a  vmovaps [rsp], xmm0
00007c454bbdb59f  vmovaps [rsp+0x10], xmm1
00007c454bbdb5a5  vmovaps [rsp+0x20], xmm2
00007c454bbdb5ab  vmovaps [rsp+0x30], xmm3
00007c454bbdb5b1  vmovaps [rsp+0x40], xmm4
00007c454bbdb5b7  vmovaps [rsp+0x50], xmm5
00007c454bbdb5bd  vmovaps [rsp+0x60], xmm7
00007c454bbdb5c3  vmovaps [rsp+0x70], xmm8
00007c454bbdb5c9  vmovaps [rsp+0x80], xmm9
00007c454bbdb5d2  vmovaps [rsp+0x90], xmm10
00007c454bbdb5db  vmovaps [rsp+0xA0], xmm11
00007c454bbdb5e4  vmovaps [rsp+0xB0], xmm12
00007c454bbdb5ed  vmovaps [rsp+0xC0], xmm13
00007c454bbdb5f6  vmovaps [rsp+0xD0], xmm14
00007c454bbdb5ff  vmovaps [rsp+0xE0], xmm15
00007c454bbdb608  sub rsp, 0x30
00007c454bbdb60c  movaps [rsp], xmm6
00007c454bbdb610  movaps [rsp+0x10], xmm9
00007c454bbdb616  movaps [rsp+0x20], xmm1
00007c454bbdb61b  lea rdi, [rsp]
00007c454bbdb61f  mov esi, 0x00
00007c454bbdb624  mov rax, 0x56A18AC54530
00007c454bbdb62e  call rax
00007c454bbdb630  movaps xmm6, [rsp]
00007c454bbdb634  add rsp, 0x30
00007c454bbdb638  vmovaps xmm0, [rsp]
00007c454bbdb63d  vmovaps xmm1, [rsp+0x10]
00007c454bbdb643  vmovaps xmm2, [rsp+0x20]
00007c454bbdb649  vmovaps xmm3, [rsp+0x30]
00007c454bbdb64f  vmovaps xmm4, [rsp+0x40]
00007c454bbdb655  vmovaps xmm5, [rsp+0x50]
00007c454bbdb65b  vmovaps xmm7, [rsp+0x60]
00007c454bbdb661  vmovaps xmm8, [rsp+0x70]
00007c454bbdb667  vmovaps xmm9, [rsp+0x80]
00007c454bbdb670  vmovaps xmm10, [rsp+0x90]
00007c454bbdb679  vmovaps xmm11, [rsp+0xA0]
00007c454bbdb682  vmovaps xmm12, [rsp+0xB0]
00007c454bbdb68b  vmovaps xmm13, [rsp+0xC0]
00007c454bbdb694  vmovaps xmm14, [rsp+0xD0]
00007c454bbdb69d  vmovaps xmm15, [rsp+0xE0]
00007c454bbdb6a6  add rsp, 0xF0
00007c454bbdb6ad  pop r11
00007c454bbdb6af  pop r10
00007c454bbdb6b1  pop r9
00007c454bbdb6b3  pop r8
00007c454bbdb6b5  pop rsi
00007c454bbdb6b6  pop rdi
00007c454bbdb6b7  pop rdx
00007c454bbdb6b8  pop rcx
00007c454bbdb6b9  pop rax
00007c454bbdb6ba  add rsp, 0x08
00007c454bbdb6be  jmp 0x00007C454BBD918B
00007c454bbdb6c3  sub rsp, 0x08
00007c454bbdb6c7  push rax
00007c454bbdb6c8  push rcx
00007c454bbdb6c9  push rdx
00007c454bbdb6ca  push rdi
00007c454bbdb6cb  push rsi
00007c454bbdb6cc  push r8
00007c454bbdb6ce  push r9
00007c454bbdb6d0  push r10
00007c454bbdb6d2  push r11
00007c454bbdb6d4  sub rsp, 0xF0
00007c454bbdb6db  vmovaps [rsp], xmm0
00007c454bbdb6e0  vmovaps [rsp+0x10], xmm1
00007c454bbdb6e6  vmovaps [rsp+0x20], xmm2
00007c454bbdb6ec  vmovaps [rsp+0x30], xmm3
00007c454bbdb6f2  vmovaps [rsp+0x40], xmm4
00007c454bbdb6f8  vmovaps [rsp+0x50], xmm5
00007c454bbdb6fe  vmovaps [rsp+0x60], xmm6
00007c454bbdb704  vmovaps [rsp+0x70], xmm7
00007c454bbdb70a  vmovaps [rsp+0x80], xmm8
00007c454bbdb713  vmovaps [rsp+0x90], xmm10
00007c454bbdb71c  vmovaps [rsp+0xA0], xmm11
00007c454bbdb725  vmovaps [rsp+0xB0], xmm12
00007c454bbdb72e  vmovaps [rsp+0xC0], xmm13
00007c454bbdb737  vmovaps [rsp+0xD0], xmm14
00007c454bbdb740  vmovaps [rsp+0xE0], xmm15
00007c454bbdb749  sub rsp, 0x30
00007c454bbdb74d  movaps [rsp], xmm9
00007c454bbdb752  movaps [rsp+0x10], xmm3
00007c454bbdb757  movaps [rsp+0x20], xmm1
00007c454bbdb75c  lea rdi, [rsp]
00007c454bbdb760  mov esi, 0x00
00007c454bbdb765  mov rax, 0x56A18AC54530
00007c454bbdb76f  call rax
00007c454bbdb771  movaps xmm9, [rsp]
00007c454bbdb776  add rsp, 0x30
00007c454bbdb77a  vmovaps xmm0, [rsp]
00007c454bbdb77f  vmovaps xmm1, [rsp+0x10]
00007c454bbdb785  vmovaps xmm2, [rsp+0x20]
00007c454bbdb78b  vmovaps xmm3, [rsp+0x30]
00007c454bbdb791  vmovaps xmm4, [rsp+0x40]
00007c454bbdb797  vmovaps xmm5, [rsp+0x50]
00007c454bbdb79d  vmovaps xmm6, [rsp+0x60]
00007c454bbdb7a3  vmovaps xmm7, [rsp+0x70]
00007c454bbdb7a9  vmovaps xmm8, [rsp+0x80]
00007c454bbdb7b2  vmovaps xmm10, [rsp+0x90]
00007c454bbdb7bb  vmovaps xmm11, [rsp+0xA0]
00007c454bbdb7c4  vmovaps xmm12, [rsp+0xB0]
00007c454bbdb7cd  vmovaps xmm13, [rsp+0xC0]
00007c454bbdb7d6  vmovaps xmm14, [rsp+0xD0]
00007c454bbdb7df  vmovaps xmm15, [rsp+0xE0]
00007c454bbdb7e8  add rsp, 0xF0
00007c454bbdb7ef  pop r11
00007c454bbdb7f1  pop r10
00007c454bbdb7f3  pop r9
00007c454bbdb7f5  pop r8
00007c454bbdb7f7  pop rsi
00007c454bbdb7f8  pop rdi
00007c454bbdb7f9  pop rdx
00007c454bbdb7fa  pop rcx
00007c454bbdb7fb  pop rax
00007c454bbdb7fc  add rsp, 0x08
00007c454bbdb800  jmp 0x00007C454BBD91D7
00007c454bbdb805  call 0x00007C454BAD64F0
00007c454bbdb80a  jmp 0x00007C454BBD91E4
00007c454bbdb80f  sub rsp, 0x08
00007c454bbdb813  push rax
00007c454bbdb814  push rcx
00007c454bbdb815  push rdx
00007c454bbdb816  push rdi
00007c454bbdb817  push rsi
00007c454bbdb818  push r8
00007c454bbdb81a  push r9
00007c454bbdb81c  push r10
00007c454bbdb81e  push r11
00007c454bbdb820  sub rsp, 0xF0
00007c454bbdb827  vmovaps [rsp], xmm0
00007c454bbdb82c  vmovaps [rsp+0x10], xmm1
00007c454bbdb832  vmovaps [rsp+0x20], xmm2
00007c454bbdb838  vmovaps [rsp+0x30], xmm3
00007c454bbdb83e  vmovaps [rsp+0x40], xmm4
00007c454bbdb844  vmovaps [rsp+0x50], xmm5
00007c454bbdb84a  vmovaps [rsp+0x60], xmm6
00007c454bbdb850  vmovaps [rsp+0x70], xmm7
00007c454bbdb856  vmovaps [rsp+0x80], xmm8
00007c454bbdb85f  vmovaps [rsp+0x90], xmm9
00007c454bbdb868  vmovaps [rsp+0xA0], xmm10
00007c454bbdb871  vmovaps [rsp+0xB0], xmm11
00007c454bbdb87a  vmovaps [rsp+0xC0], xmm12
00007c454bbdb883  vmovaps [rsp+0xD0], xmm13
00007c454bbdb88c  vmovaps [rsp+0xE0], xmm14
00007c454bbdb895  sub rsp, 0x30
00007c454bbdb899  movaps [rsp], xmm15
00007c454bbdb89e  movaps [rsp+0x10], xmm3
00007c454bbdb8a3  movaps [rsp+0x20], xmm7
00007c454bbdb8a8  lea rdi, [rsp]
00007c454bbdb8ac  mov esi, 0x00
00007c454bbdb8b1  mov rax, 0x56A18AC54530
00007c454bbdb8bb  call rax
00007c454bbdb8bd  movaps xmm15, [rsp]
00007c454bbdb8c2  add rsp, 0x30
00007c454bbdb8c6  vmovaps xmm0, [rsp]
00007c454bbdb8cb  vmovaps xmm1, [rsp+0x10]
00007c454bbdb8d1  vmovaps xmm2, [rsp+0x20]
00007c454bbdb8d7  vmovaps xmm3, [rsp+0x30]
00007c454bbdb8dd  vmovaps xmm4, [rsp+0x40]
00007c454bbdb8e3  vmovaps xmm5, [rsp+0x50]
00007c454bbdb8e9  vmovaps xmm6, [rsp+0x60]
00007c454bbdb8ef  vmovaps xmm7, [rsp+0x70]
00007c454bbdb8f5  vmovaps xmm8, [rsp+0x80]
00007c454bbdb8fe  vmovaps xmm9, [rsp+0x90]
00007c454bbdb907  vmovaps xmm10, [rsp+0xA0]
00007c454bbdb910  vmovaps xmm11, [rsp+0xB0]
00007c454bbdb919  vmovaps xmm12, [rsp+0xC0]
00007c454bbdb922  vmovaps xmm13, [rsp+0xD0]
00007c454bbdb92b  vmovaps xmm14, [rsp+0xE0]
00007c454bbdb934  add rsp, 0xF0
00007c454bbdb93b  pop r11
00007c454bbdb93d  pop r10
00007c454bbdb93f  pop r9
00007c454bbdb941  pop r8
00007c454bbdb943  pop rsi
00007c454bbdb944  pop rdi
00007c454bbdb945  pop rdx
00007c454bbdb946  pop rcx
00007c454bbdb947  pop rax
00007c454bbdb948  add rsp, 0x08
00007c454bbdb94c  jmp 0x00007C454BBD9210
00007c454bbdb951  sub rsp, 0x08
00007c454bbdb955  push rax
00007c454bbdb956  push rcx
00007c454bbdb957  push rdx
00007c454bbdb958  push rdi
00007c454bbdb959  push rsi
00007c454bbdb95a  push r8
00007c454bbdb95c  push r9
00007c454bbdb95e  push r10
00007c454bbdb960  push r11
00007c454bbdb962  sub rsp, 0xF0
00007c454bbdb969  vmovaps [rsp], xmm0
00007c454bbdb96e  vmovaps [rsp+0x10], xmm1
00007c454bbdb974  vmovaps [rsp+0x20], xmm2
00007c454bbdb97a  vmovaps [rsp+0x30], xmm4
00007c454bbdb980  vmovaps [rsp+0x40], xmm5
00007c454bbdb986  vmovaps [rsp+0x50], xmm6
00007c454bbdb98c  vmovaps [rsp+0x60], xmm7
00007c454bbdb992  vmovaps [rsp+0x70], xmm8
00007c454bbdb998  vmovaps [rsp+0x80], xmm9
00007c454bbdb9a1  vmovaps [rsp+0x90], xmm10
00007c454bbdb9aa  vmovaps [rsp+0xA0], xmm11
00007c454bbdb9b3  vmovaps [rsp+0xB0], xmm12
00007c454bbdb9bc  vmovaps [rsp+0xC0], xmm13
00007c454bbdb9c5  vmovaps [rsp+0xD0], xmm14
00007c454bbdb9ce  vmovaps [rsp+0xE0], xmm15
00007c454bbdb9d7  sub rsp, 0x30
00007c454bbdb9db  movaps [rsp], xmm3
00007c454bbdb9df  movaps [rsp+0x10], xmm1
00007c454bbdb9e4  movaps [rsp+0x20], xmm15
00007c454bbdb9ea  lea rdi, [rsp]
00007c454bbdb9ee  mov esi, 0x00
00007c454bbdb9f3  mov rax, 0x56A18AC54530
00007c454bbdb9fd  call rax
00007c454bbdb9ff  movaps xmm3, [rsp]
00007c454bbdba03  add rsp, 0x30
00007c454bbdba07  vmovaps xmm0, [rsp]
00007c454bbdba0c  vmovaps xmm1, [rsp+0x10]
00007c454bbdba12  vmovaps xmm2, [rsp+0x20]
00007c454bbdba18  vmovaps xmm4, [rsp+0x30]
00007c454bbdba1e  vmovaps xmm5, [rsp+0x40]
00007c454bbdba24  vmovaps xmm6, [rsp+0x50]
00007c454bbdba2a  vmovaps xmm7, [rsp+0x60]
00007c454bbdba30  vmovaps xmm8, [rsp+0x70]
00007c454bbdba36  vmovaps xmm9, [rsp+0x80]
00007c454bbdba3f  vmovaps xmm10, [rsp+0x90]
00007c454bbdba48  vmovaps xmm11, [rsp+0xA0]
00007c454bbdba51  vmovaps xmm12, [rsp+0xB0]
00007c454bbdba5a  vmovaps xmm13, [rsp+0xC0]
00007c454bbdba63  vmovaps xmm14, [rsp+0xD0]
00007c454bbdba6c  vmovaps xmm15, [rsp+0xE0]
00007c454bbdba75  add rsp, 0xF0
00007c454bbdba7c  pop r11
00007c454bbdba7e  pop r10
00007c454bbdba80  pop r9
00007c454bbdba82  pop r8
00007c454bbdba84  pop rsi
00007c454bbdba85  pop rdi
00007c454bbdba86  pop rdx
00007c454bbdba87  pop rcx
00007c454bbdba88  pop rax
00007c454bbdba89  add rsp, 0x08
00007c454bbdba8d  jmp 0x00007C454BBD929F
00007c454bbdba92  call 0x00007C454BAD64F0
00007c454bbdba97  jmp 0x00007C454BBD92A9
00007c454bbdba9c  sub rsp, 0x08
00007c454bbdbaa0  push rax
00007c454bbdbaa1  push rcx
00007c454bbdbaa2  push rdx
00007c454bbdbaa3  push rdi
00007c454bbdbaa4  push rsi
00007c454bbdbaa5  push r8
00007c454bbdbaa7  push r9
00007c454bbdbaa9  push r10
00007c454bbdbaab  push r11
00007c454bbdbaad  sub rsp, 0xF0
00007c454bbdbab4  vmovaps [rsp], xmm0
00007c454bbdbab9  vmovaps [rsp+0x10], xmm1
00007c454bbdbabf  vmovaps [rsp+0x20], xmm2
00007c454bbdbac5  vmovaps [rsp+0x30], xmm3
00007c454bbdbacb  vmovaps [rsp+0x40], xmm4
00007c454bbdbad1  vmovaps [rsp+0x50], xmm5
00007c454bbdbad7  vmovaps [rsp+0x60], xmm6
00007c454bbdbadd  vmovaps [rsp+0x70], xmm7
00007c454bbdbae3  vmovaps [rsp+0x80], xmm8
00007c454bbdbaec  vmovaps [rsp+0x90], xmm9
00007c454bbdbaf5  vmovaps [rsp+0xA0], xmm10
00007c454bbdbafe  vmovaps [rsp+0xB0], xmm11
00007c454bbdbb07  vmovaps [rsp+0xC0], xmm12
00007c454bbdbb10  vmovaps [rsp+0xD0], xmm13
00007c454bbdbb19  vmovaps [rsp+0xE0], xmm14
00007c454bbdbb22  sub rsp, 0x30
00007c454bbdbb26  movaps [rsp], xmm15
00007c454bbdbb2b  movaps [rsp+0x10], xmm14
00007c454bbdbb31  movaps [rsp+0x20], xmm4
00007c454bbdbb36  lea rdi, [rsp]
00007c454bbdbb3a  mov esi, 0x00
00007c454bbdbb3f  mov rax, 0x56A18AC54530
00007c454bbdbb49  call rax
00007c454bbdbb4b  movaps xmm15, [rsp]
00007c454bbdbb50  add rsp, 0x30
00007c454bbdbb54  vmovaps xmm0, [rsp]
00007c454bbdbb59  vmovaps xmm1, [rsp+0x10]
00007c454bbdbb5f  vmovaps xmm2, [rsp+0x20]
00007c454bbdbb65  vmovaps xmm3, [rsp+0x30]
00007c454bbdbb6b  vmovaps xmm4, [rsp+0x40]
00007c454bbdbb71  vmovaps xmm5, [rsp+0x50]
00007c454bbdbb77  vmovaps xmm6, [rsp+0x60]
00007c454bbdbb7d  vmovaps xmm7, [rsp+0x70]
00007c454bbdbb83  vmovaps xmm8, [rsp+0x80]
00007c454bbdbb8c  vmovaps xmm9, [rsp+0x90]
00007c454bbdbb95  vmovaps xmm10, [rsp+0xA0]
00007c454bbdbb9e  vmovaps xmm11, [rsp+0xB0]
00007c454bbdbba7  vmovaps xmm12, [rsp+0xC0]
00007c454bbdbbb0  vmovaps xmm13, [rsp+0xD0]
00007c454bbdbbb9  vmovaps xmm14, [rsp+0xE0]
00007c454bbdbbc2  add rsp, 0xF0
00007c454bbdbbc9  pop r11
00007c454bbdbbcb  pop r10
00007c454bbdbbcd  pop r9
00007c454bbdbbcf  pop r8
00007c454bbdbbd1  pop rsi
00007c454bbdbbd2  pop rdi
00007c454bbdbbd3  pop rdx
00007c454bbdbbd4  pop rcx
00007c454bbdbbd5  pop rax
00007c454bbdbbd6  add rsp, 0x08
00007c454bbdbbda  jmp 0x00007C454BBD92D7
00007c454bbdbbdf  sub rsp, 0x08
00007c454bbdbbe3  push rax
00007c454bbdbbe4  push rcx
00007c454bbdbbe5  push rdx
00007c454bbdbbe6  push rdi
00007c454bbdbbe7  push rsi
00007c454bbdbbe8  push r8
00007c454bbdbbea  push r9
00007c454bbdbbec  push r10
00007c454bbdbbee  push r11
00007c454bbdbbf0  sub rsp, 0xF0
00007c454bbdbbf7  vmovaps [rsp], xmm0
00007c454bbdbbfc  vmovaps [rsp+0x10], xmm1
00007c454bbdbc02  vmovaps [rsp+0x20], xmm2
00007c454bbdbc08  vmovaps [rsp+0x30], xmm3
00007c454bbdbc0e  vmovaps [rsp+0x40], xmm4
00007c454bbdbc14  vmovaps [rsp+0x50], xmm5
00007c454bbdbc1a  vmovaps [rsp+0x60], xmm6
00007c454bbdbc20  vmovaps [rsp+0x70], xmm7
00007c454bbdbc26  vmovaps [rsp+0x80], xmm8
00007c454bbdbc2f  vmovaps [rsp+0x90], xmm9
00007c454bbdbc38  vmovaps [rsp+0xA0], xmm10
00007c454bbdbc41  vmovaps [rsp+0xB0], xmm11
00007c454bbdbc4a  vmovaps [rsp+0xC0], xmm12
00007c454bbdbc53  vmovaps [rsp+0xD0], xmm13
00007c454bbdbc5c  vmovaps [rsp+0xE0], xmm15
00007c454bbdbc65  sub rsp, 0x30
00007c454bbdbc69  movaps [rsp], xmm14
00007c454bbdbc6e  movaps [rsp+0x10], xmm2
00007c454bbdbc73  movaps [rsp+0x20], xmm1
00007c454bbdbc78  lea rdi, [rsp]
00007c454bbdbc7c  mov esi, 0x00
00007c454bbdbc81  mov rax, 0x56A18AC54530
00007c454bbdbc8b  call rax
00007c454bbdbc8d  movaps xmm14, [rsp]
00007c454bbdbc92  add rsp, 0x30
00007c454bbdbc96  vmovaps xmm0, [rsp]
00007c454bbdbc9b  vmovaps xmm1, [rsp+0x10]
00007c454bbdbca1  vmovaps xmm2, [rsp+0x20]
00007c454bbdbca7  vmovaps xmm3, [rsp+0x30]
00007c454bbdbcad  vmovaps xmm4, [rsp+0x40]
00007c454bbdbcb3  vmovaps xmm5, [rsp+0x50]
00007c454bbdbcb9  vmovaps xmm6, [rsp+0x60]
00007c454bbdbcbf  vmovaps xmm7, [rsp+0x70]
00007c454bbdbcc5  vmovaps xmm8, [rsp+0x80]
00007c454bbdbcce  vmovaps xmm9, [rsp+0x90]
00007c454bbdbcd7  vmovaps xmm10, [rsp+0xA0]
00007c454bbdbce0  vmovaps xmm11, [rsp+0xB0]
00007c454bbdbce9  vmovaps xmm12, [rsp+0xC0]
00007c454bbdbcf2  vmovaps xmm13, [rsp+0xD0]
00007c454bbdbcfb  vmovaps xmm15, [rsp+0xE0]
00007c454bbdbd04  add rsp, 0xF0
00007c454bbdbd0b  pop r11
00007c454bbdbd0d  pop r10
00007c454bbdbd0f  pop r9
00007c454bbdbd11  pop r8
00007c454bbdbd13  pop rsi
00007c454bbdbd14  pop rdi
00007c454bbdbd15  pop rdx
00007c454bbdbd16  pop rcx
00007c454bbdbd17  pop rax
00007c454bbdbd18  add rsp, 0x08
00007c454bbdbd1c  jmp 0x00007C454BBD92FD
00007c454bbdbd21  sub rsp, 0x08
00007c454bbdbd25  push rax
00007c454bbdbd26  push rcx
00007c454bbdbd27  push rdx
00007c454bbdbd28  push rdi
00007c454bbdbd29  push rsi
00007c454bbdbd2a  push r8
00007c454bbdbd2c  push r9
00007c454bbdbd2e  push r10
00007c454bbdbd30  push r11
00007c454bbdbd32  sub rsp, 0xF0
00007c454bbdbd39  vmovaps [rsp], xmm0
00007c454bbdbd3e  vmovaps [rsp+0x10], xmm2
00007c454bbdbd44  vmovaps [rsp+0x20], xmm3
00007c454bbdbd4a  vmovaps [rsp+0x30], xmm4
00007c454bbdbd50  vmovaps [rsp+0x40], xmm5
00007c454bbdbd56  vmovaps [rsp+0x50], xmm6
00007c454bbdbd5c  vmovaps [rsp+0x60], xmm7
00007c454bbdbd62  vmovaps [rsp+0x70], xmm8
00007c454bbdbd68  vmovaps [rsp+0x80], xmm9
00007c454bbdbd71  vmovaps [rsp+0x90], xmm10
00007c454bbdbd7a  vmovaps [rsp+0xA0], xmm11
00007c454bbdbd83  vmovaps [rsp+0xB0], xmm12
00007c454bbdbd8c  vmovaps [rsp+0xC0], xmm13
00007c454bbdbd95  vmovaps [rsp+0xD0], xmm14
00007c454bbdbd9e  vmovaps [rsp+0xE0], xmm15
00007c454bbdbda7  sub rsp, 0x30
00007c454bbdbdab  movaps [rsp], xmm1
00007c454bbdbdaf  movaps [rsp+0x10], xmm4
00007c454bbdbdb4  movaps [rsp+0x20], xmm9
00007c454bbdbdba  lea rdi, [rsp]
00007c454bbdbdbe  mov esi, 0x00
00007c454bbdbdc3  mov rax, 0x56A18AC54530
00007c454bbdbdcd  call rax
00007c454bbdbdcf  movaps xmm1, [rsp]
00007c454bbdbdd3  add rsp, 0x30
00007c454bbdbdd7  vmovaps xmm0, [rsp]
00007c454bbdbddc  vmovaps xmm2, [rsp+0x10]
00007c454bbdbde2  vmovaps xmm3, [rsp+0x20]
00007c454bbdbde8  vmovaps xmm4, [rsp+0x30]
00007c454bbdbdee  vmovaps xmm5, [rsp+0x40]
00007c454bbdbdf4  vmovaps xmm6, [rsp+0x50]
00007c454bbdbdfa  vmovaps xmm7, [rsp+0x60]
00007c454bbdbe00  vmovaps xmm8, [rsp+0x70]
00007c454bbdbe06  vmovaps xmm9, [rsp+0x80]
00007c454bbdbe0f  vmovaps xmm10, [rsp+0x90]
00007c454bbdbe18  vmovaps xmm11, [rsp+0xA0]
00007c454bbdbe21  vmovaps xmm12, [rsp+0xB0]
00007c454bbdbe2a  vmovaps xmm13, [rsp+0xC0]
00007c454bbdbe33  vmovaps xmm14, [rsp+0xD0]
00007c454bbdbe3c  vmovaps xmm15, [rsp+0xE0]
00007c454bbdbe45  add rsp, 0xF0
00007c454bbdbe4c  pop r11
00007c454bbdbe4e  pop r10
00007c454bbdbe50  pop r9
00007c454bbdbe52  pop r8
00007c454bbdbe54  pop rsi
00007c454bbdbe55  pop rdi
00007c454bbdbe56  pop rdx
00007c454bbdbe57  pop rcx
00007c454bbdbe58  pop rax
00007c454bbdbe59  add rsp, 0x08
00007c454bbdbe5d  jmp 0x00007C454BBD931B
00007c454bbdbe62  sub rsp, 0x08
00007c454bbdbe66  push rax
00007c454bbdbe67  push rcx
00007c454bbdbe68  push rdx
00007c454bbdbe69  push rdi
00007c454bbdbe6a  push rsi
00007c454bbdbe6b  push r8
00007c454bbdbe6d  push r9
00007c454bbdbe6f  push r10
00007c454bbdbe71  push r11
00007c454bbdbe73  sub rsp, 0xF0
00007c454bbdbe7a  vmovaps [rsp], xmm0
00007c454bbdbe7f  vmovaps [rsp+0x10], xmm1
00007c454bbdbe85  vmovaps [rsp+0x20], xmm2
00007c454bbdbe8b  vmovaps [rsp+0x30], xmm3
00007c454bbdbe91  vmovaps [rsp+0x40], xmm5
00007c454bbdbe97  vmovaps [rsp+0x50], xmm6
00007c454bbdbe9d  vmovaps [rsp+0x60], xmm7
00007c454bbdbea3  vmovaps [rsp+0x70], xmm8
00007c454bbdbea9  vmovaps [rsp+0x80], xmm9
00007c454bbdbeb2  vmovaps [rsp+0x90], xmm10
00007c454bbdbebb  vmovaps [rsp+0xA0], xmm11
00007c454bbdbec4  vmovaps [rsp+0xB0], xmm12
00007c454bbdbecd  vmovaps [rsp+0xC0], xmm13
00007c454bbdbed6  vmovaps [rsp+0xD0], xmm14
00007c454bbdbedf  vmovaps [rsp+0xE0], xmm15
00007c454bbdbee8  sub rsp, 0x30
00007c454bbdbeec  movaps [rsp], xmm4
00007c454bbdbef0  movaps [rsp+0x10], xmm2
00007c454bbdbef5  movaps [rsp+0x20], xmm9
00007c454bbdbefb  lea rdi, [rsp]
00007c454bbdbeff  mov esi, 0x00
00007c454bbdbf04  mov rax, 0x56A18AC54530
00007c454bbdbf0e  call rax
00007c454bbdbf10  movaps xmm4, [rsp]
00007c454bbdbf14  add rsp, 0x30
00007c454bbdbf18  vmovaps xmm0, [rsp]
00007c454bbdbf1d  vmovaps xmm1, [rsp+0x10]
00007c454bbdbf23  vmovaps xmm2, [rsp+0x20]
00007c454bbdbf29  vmovaps xmm3, [rsp+0x30]
00007c454bbdbf2f  vmovaps xmm5, [rsp+0x40]
00007c454bbdbf35  vmovaps xmm6, [rsp+0x50]
00007c454bbdbf3b  vmovaps xmm7, [rsp+0x60]
00007c454bbdbf41  vmovaps xmm8, [rsp+0x70]
00007c454bbdbf47  vmovaps xmm9, [rsp+0x80]
00007c454bbdbf50  vmovaps xmm10, [rsp+0x90]
00007c454bbdbf59  vmovaps xmm11, [rsp+0xA0]
00007c454bbdbf62  vmovaps xmm12, [rsp+0xB0]
00007c454bbdbf6b  vmovaps xmm13, [rsp+0xC0]
00007c454bbdbf74  vmovaps xmm14, [rsp+0xD0]
00007c454bbdbf7d  vmovaps xmm15, [rsp+0xE0]
00007c454bbdbf86  add rsp, 0xF0
00007c454bbdbf8d  pop r11
00007c454bbdbf8f  pop r10
00007c454bbdbf91  pop r9
00007c454bbdbf93  pop r8
00007c454bbdbf95  pop rsi
00007c454bbdbf96  pop rdi
00007c454bbdbf97  pop rdx
00007c454bbdbf98  pop rcx
00007c454bbdbf99  pop rax
00007c454bbdbf9a  add rsp, 0x08
00007c454bbdbf9e  jmp 0x00007C454BBD934B
00007c454bbdbfa3  sub rsp, 0x08
00007c454bbdbfa7  push rax
00007c454bbdbfa8  push rcx
00007c454bbdbfa9  push rdx
00007c454bbdbfaa  push rdi
00007c454bbdbfab  push rsi
00007c454bbdbfac  push r8
00007c454bbdbfae  push r9
00007c454bbdbfb0  push r10
00007c454bbdbfb2  push r11
00007c454bbdbfb4  sub rsp, 0xF0
00007c454bbdbfbb  vmovaps [rsp], xmm0
00007c454bbdbfc0  vmovaps [rsp+0x10], xmm1
00007c454bbdbfc6  vmovaps [rsp+0x20], xmm2
00007c454bbdbfcc  vmovaps [rsp+0x30], xmm3
00007c454bbdbfd2  vmovaps [rsp+0x40], xmm4
00007c454bbdbfd8  vmovaps [rsp+0x50], xmm5
00007c454bbdbfde  vmovaps [rsp+0x60], xmm6
00007c454bbdbfe4  vmovaps [rsp+0x70], xmm7
00007c454bbdbfea  vmovaps [rsp+0x80], xmm8
00007c454bbdbff3  vmovaps [rsp+0x90], xmm10
00007c454bbdbffc  vmovaps [rsp+0xA0], xmm11
00007c454bbdc005  vmovaps [rsp+0xB0], xmm12
00007c454bbdc00e  vmovaps [rsp+0xC0], xmm13
00007c454bbdc017  vmovaps [rsp+0xD0], xmm14
00007c454bbdc020  vmovaps [rsp+0xE0], xmm15
00007c454bbdc029  sub rsp, 0x30
00007c454bbdc02d  movaps [rsp], xmm9
00007c454bbdc032  movaps [rsp+0x10], xmm2
00007c454bbdc037  movaps [rsp+0x20], xmm1
00007c454bbdc03c  lea rdi, [rsp]
00007c454bbdc040  mov esi, 0x00
00007c454bbdc045  mov rax, 0x56A18AC54530
00007c454bbdc04f  call rax
00007c454bbdc051  movaps xmm9, [rsp]
00007c454bbdc056  add rsp, 0x30
00007c454bbdc05a  vmovaps xmm0, [rsp]
00007c454bbdc05f  vmovaps xmm1, [rsp+0x10]
00007c454bbdc065  vmovaps xmm2, [rsp+0x20]
00007c454bbdc06b  vmovaps xmm3, [rsp+0x30]
00007c454bbdc071  vmovaps xmm4, [rsp+0x40]
00007c454bbdc077  vmovaps xmm5, [rsp+0x50]
00007c454bbdc07d  vmovaps xmm6, [rsp+0x60]
00007c454bbdc083  vmovaps xmm7, [rsp+0x70]
00007c454bbdc089  vmovaps xmm8, [rsp+0x80]
00007c454bbdc092  vmovaps xmm10, [rsp+0x90]
00007c454bbdc09b  vmovaps xmm11, [rsp+0xA0]
00007c454bbdc0a4  vmovaps xmm12, [rsp+0xB0]
00007c454bbdc0ad  vmovaps xmm13, [rsp+0xC0]
00007c454bbdc0b6  vmovaps xmm14, [rsp+0xD0]
00007c454bbdc0bf  vmovaps xmm15, [rsp+0xE0]
00007c454bbdc0c8  add rsp, 0xF0
00007c454bbdc0cf  pop r11
00007c454bbdc0d1  pop r10
00007c454bbdc0d3  pop r9
00007c454bbdc0d5  pop r8
00007c454bbdc0d7  pop rsi
00007c454bbdc0d8  pop rdi
00007c454bbdc0d9  pop rdx
00007c454bbdc0da  pop rcx
00007c454bbdc0db  pop rax
00007c454bbdc0dc  add rsp, 0x08
00007c454bbdc0e0  jmp 0x00007C454BBD9381
00007c454bbdc0e5  sub rsp, 0x08
00007c454bbdc0e9  push rax
00007c454bbdc0ea  push rcx
00007c454bbdc0eb  push rdx
00007c454bbdc0ec  push rdi
00007c454bbdc0ed  push rsi
00007c454bbdc0ee  push r8
00007c454bbdc0f0  push r9
00007c454bbdc0f2  push r10
00007c454bbdc0f4  push r11
00007c454bbdc0f6  sub rsp, 0xF0
00007c454bbdc0fd  vmovaps [rsp], xmm0
00007c454bbdc102  vmovaps [rsp+0x10], xmm2
00007c454bbdc108  vmovaps [rsp+0x20], xmm3
00007c454bbdc10e  vmovaps [rsp+0x30], xmm4
00007c454bbdc114  vmovaps [rsp+0x40], xmm5
00007c454bbdc11a  vmovaps [rsp+0x50], xmm6
00007c454bbdc120  vmovaps [rsp+0x60], xmm7
00007c454bbdc126  vmovaps [rsp+0x70], xmm8
00007c454bbdc12c  vmovaps [rsp+0x80], xmm9
00007c454bbdc135  vmovaps [rsp+0x90], xmm10
00007c454bbdc13e  vmovaps [rsp+0xA0], xmm11
00007c454bbdc147  vmovaps [rsp+0xB0], xmm12
00007c454bbdc150  vmovaps [rsp+0xC0], xmm13
00007c454bbdc159  vmovaps [rsp+0xD0], xmm14
00007c454bbdc162  vmovaps [rsp+0xE0], xmm15
00007c454bbdc16b  sub rsp, 0x30
00007c454bbdc16f  movaps [rsp], xmm1
00007c454bbdc173  movaps [rsp+0x10], xmm15
00007c454bbdc179  movaps [rsp+0x20], xmm6
00007c454bbdc17e  lea rdi, [rsp]
00007c454bbdc182  mov esi, 0x00
00007c454bbdc187  mov rax, 0x56A18AC54530
00007c454bbdc191  call rax
00007c454bbdc193  movaps xmm1, [rsp]
00007c454bbdc197  add rsp, 0x30
00007c454bbdc19b  vmovaps xmm0, [rsp]
00007c454bbdc1a0  vmovaps xmm2, [rsp+0x10]
00007c454bbdc1a6  vmovaps xmm3, [rsp+0x20]
00007c454bbdc1ac  vmovaps xmm4, [rsp+0x30]
00007c454bbdc1b2  vmovaps xmm5, [rsp+0x40]
00007c454bbdc1b8  vmovaps xmm6, [rsp+0x50]
00007c454bbdc1be  vmovaps xmm7, [rsp+0x60]
00007c454bbdc1c4  vmovaps xmm8, [rsp+0x70]
00007c454bbdc1ca  vmovaps xmm9, [rsp+0x80]
00007c454bbdc1d3  vmovaps xmm10, [rsp+0x90]
00007c454bbdc1dc  vmovaps xmm11, [rsp+0xA0]
00007c454bbdc1e5  vmovaps xmm12, [rsp+0xB0]
00007c454bbdc1ee  vmovaps xmm13, [rsp+0xC0]
00007c454bbdc1f7  vmovaps xmm14, [rsp+0xD0]
00007c454bbdc200  vmovaps xmm15, [rsp+0xE0]
00007c454bbdc209  add rsp, 0xF0
00007c454bbdc210  pop r11
00007c454bbdc212  pop r10
00007c454bbdc214  pop r9
00007c454bbdc216  pop r8
00007c454bbdc218  pop rsi
00007c454bbdc219  pop rdi
00007c454bbdc21a  pop rdx
00007c454bbdc21b  pop rcx
00007c454bbdc21c  pop rax
00007c454bbdc21d  add rsp, 0x08
00007c454bbdc221  jmp 0x00007C454BBD93A2
00007c454bbdc226  sub rsp, 0x08
00007c454bbdc22a  push rax
00007c454bbdc22b  push rcx
00007c454bbdc22c  push rdx
00007c454bbdc22d  push rdi
00007c454bbdc22e  push rsi
00007c454bbdc22f  push r8
00007c454bbdc231  push r9
00007c454bbdc233  push r10
00007c454bbdc235  push r11
00007c454bbdc237  sub rsp, 0xF0
00007c454bbdc23e  vmovaps [rsp], xmm0
00007c454bbdc243  vmovaps [rsp+0x10], xmm1
00007c454bbdc249  vmovaps [rsp+0x20], xmm2
00007c454bbdc24f  vmovaps [rsp+0x30], xmm3
00007c454bbdc255  vmovaps [rsp+0x40], xmm4
00007c454bbdc25b  vmovaps [rsp+0x50], xmm5
00007c454bbdc261  vmovaps [rsp+0x60], xmm6
00007c454bbdc267  vmovaps [rsp+0x70], xmm7
00007c454bbdc26d  vmovaps [rsp+0x80], xmm8
00007c454bbdc276  vmovaps [rsp+0x90], xmm9
00007c454bbdc27f  vmovaps [rsp+0xA0], xmm10
00007c454bbdc288  vmovaps [rsp+0xB0], xmm11
00007c454bbdc291  vmovaps [rsp+0xC0], xmm12
00007c454bbdc29a  vmovaps [rsp+0xD0], xmm13
00007c454bbdc2a3  vmovaps [rsp+0xE0], xmm14
00007c454bbdc2ac  sub rsp, 0x30
00007c454bbdc2b0  movaps [rsp], xmm15
00007c454bbdc2b5  movaps [rsp+0x10], xmm5
00007c454bbdc2ba  movaps [rsp+0x20], xmm3
00007c454bbdc2bf  lea rdi, [rsp]
00007c454bbdc2c3  mov esi, 0x00
00007c454bbdc2c8  mov rax, 0x56A18AC54530
00007c454bbdc2d2  call rax
00007c454bbdc2d4  movaps xmm15, [rsp]
00007c454bbdc2d9  add rsp, 0x30
00007c454bbdc2dd  vmovaps xmm0, [rsp]
00007c454bbdc2e2  vmovaps xmm1, [rsp+0x10]
00007c454bbdc2e8  vmovaps xmm2, [rsp+0x20]
00007c454bbdc2ee  vmovaps xmm3, [rsp+0x30]
00007c454bbdc2f4  vmovaps xmm4, [rsp+0x40]
00007c454bbdc2fa  vmovaps xmm5, [rsp+0x50]
00007c454bbdc300  vmovaps xmm6, [rsp+0x60]
00007c454bbdc306  vmovaps xmm7, [rsp+0x70]
00007c454bbdc30c  vmovaps xmm8, [rsp+0x80]
00007c454bbdc315  vmovaps xmm9, [rsp+0x90]
00007c454bbdc31e  vmovaps xmm10, [rsp+0xA0]
00007c454bbdc327  vmovaps xmm11, [rsp+0xB0]
00007c454bbdc330  vmovaps xmm12, [rsp+0xC0]
00007c454bbdc339  vmovaps xmm13, [rsp+0xD0]
00007c454bbdc342  vmovaps xmm14, [rsp+0xE0]
00007c454bbdc34b  add rsp, 0xF0
00007c454bbdc352  pop r11
00007c454bbdc354  pop r10
00007c454bbdc356  pop r9
00007c454bbdc358  pop r8
00007c454bbdc35a  pop rsi
00007c454bbdc35b  pop rdi
00007c454bbdc35c  pop rdx
00007c454bbdc35d  pop rcx
00007c454bbdc35e  pop rax
00007c454bbdc35f  add rsp, 0x08
00007c454bbdc363  jmp 0x00007C454BBD93BC
00007c454bbdc368  sub rsp, 0x08
00007c454bbdc36c  push rax
00007c454bbdc36d  push rcx
00007c454bbdc36e  push rdx
00007c454bbdc36f  push rdi
00007c454bbdc370  push rsi
00007c454bbdc371  push r8
00007c454bbdc373  push r9
00007c454bbdc375  push r10
00007c454bbdc377  push r11
00007c454bbdc379  sub rsp, 0xF0
00007c454bbdc380  vmovaps [rsp], xmm0
00007c454bbdc385  vmovaps [rsp+0x10], xmm1
00007c454bbdc38b  vmovaps [rsp+0x20], xmm2
00007c454bbdc391  vmovaps [rsp+0x30], xmm3
00007c454bbdc397  vmovaps [rsp+0x40], xmm4
00007c454bbdc39d  vmovaps [rsp+0x50], xmm6
00007c454bbdc3a3  vmovaps [rsp+0x60], xmm7
00007c454bbdc3a9  vmovaps [rsp+0x70], xmm8
00007c454bbdc3af  vmovaps [rsp+0x80], xmm9
00007c454bbdc3b8  vmovaps [rsp+0x90], xmm10
00007c454bbdc3c1  vmovaps [rsp+0xA0], xmm11
00007c454bbdc3ca  vmovaps [rsp+0xB0], xmm12
00007c454bbdc3d3  vmovaps [rsp+0xC0], xmm13
00007c454bbdc3dc  vmovaps [rsp+0xD0], xmm14
00007c454bbdc3e5  vmovaps [rsp+0xE0], xmm15
00007c454bbdc3ee  sub rsp, 0x30
00007c454bbdc3f2  movaps [rsp], xmm5
00007c454bbdc3f6  movaps [rsp+0x10], xmm8
00007c454bbdc3fc  movaps [rsp+0x20], xmm6
00007c454bbdc401  lea rdi, [rsp]
00007c454bbdc405  mov esi, 0x00
00007c454bbdc40a  mov rax, 0x56A18AC54530
00007c454bbdc414  call rax
00007c454bbdc416  movaps xmm5, [rsp]
00007c454bbdc41a  add rsp, 0x30
00007c454bbdc41e  vmovaps xmm0, [rsp]
00007c454bbdc423  vmovaps xmm1, [rsp+0x10]
00007c454bbdc429  vmovaps xmm2, [rsp+0x20]
00007c454bbdc42f  vmovaps xmm3, [rsp+0x30]
00007c454bbdc435  vmovaps xmm4, [rsp+0x40]
00007c454bbdc43b  vmovaps xmm6, [rsp+0x50]
00007c454bbdc441  vmovaps xmm7, [rsp+0x60]
00007c454bbdc447  vmovaps xmm8, [rsp+0x70]
00007c454bbdc44d  vmovaps xmm9, [rsp+0x80]
00007c454bbdc456  vmovaps xmm10, [rsp+0x90]
00007c454bbdc45f  vmovaps xmm11, [rsp+0xA0]
00007c454bbdc468  vmovaps xmm12, [rsp+0xB0]
00007c454bbdc471  vmovaps xmm13, [rsp+0xC0]
00007c454bbdc47a  vmovaps xmm14, [rsp+0xD0]
00007c454bbdc483  vmovaps xmm15, [rsp+0xE0]
00007c454bbdc48c  add rsp, 0xF0
00007c454bbdc493  pop r11
00007c454bbdc495  pop r10
00007c454bbdc497  pop r9
00007c454bbdc499  pop r8
00007c454bbdc49b  pop rsi
00007c454bbdc49c  pop rdi
00007c454bbdc49d  pop rdx
00007c454bbdc49e  pop rcx
00007c454bbdc49f  pop rax
00007c454bbdc4a0  add rsp, 0x08
00007c454bbdc4a4  jmp 0x00007C454BBD93E0
00007c454bbdc4a9  sub rsp, 0x08
00007c454bbdc4ad  push rax
00007c454bbdc4ae  push rcx
00007c454bbdc4af  push rdx
00007c454bbdc4b0  push rdi
00007c454bbdc4b1  push rsi
00007c454bbdc4b2  push r8
00007c454bbdc4b4  push r9
00007c454bbdc4b6  push r10
00007c454bbdc4b8  push r11
00007c454bbdc4ba  sub rsp, 0xF0
00007c454bbdc4c1  vmovaps [rsp], xmm0
00007c454bbdc4c6  vmovaps [rsp+0x10], xmm1
00007c454bbdc4cc  vmovaps [rsp+0x20], xmm2
00007c454bbdc4d2  vmovaps [rsp+0x30], xmm3
00007c454bbdc4d8  vmovaps [rsp+0x40], xmm4
00007c454bbdc4de  vmovaps [rsp+0x50], xmm5
00007c454bbdc4e4  vmovaps [rsp+0x60], xmm7
00007c454bbdc4ea  vmovaps [rsp+0x70], xmm8
00007c454bbdc4f0  vmovaps [rsp+0x80], xmm9
00007c454bbdc4f9  vmovaps [rsp+0x90], xmm10
00007c454bbdc502  vmovaps [rsp+0xA0], xmm11
00007c454bbdc50b  vmovaps [rsp+0xB0], xmm12
00007c454bbdc514  vmovaps [rsp+0xC0], xmm13
00007c454bbdc51d  vmovaps [rsp+0xD0], xmm14
00007c454bbdc526  vmovaps [rsp+0xE0], xmm15
00007c454bbdc52f  sub rsp, 0x30
00007c454bbdc533  movaps [rsp], xmm6
00007c454bbdc537  movaps [rsp+0x10], xmm10
00007c454bbdc53d  movaps [rsp+0x20], xmm8
00007c454bbdc543  lea rdi, [rsp]
00007c454bbdc547  mov esi, 0x00
00007c454bbdc54c  mov rax, 0x56A18AC54530
00007c454bbdc556  call rax
00007c454bbdc558  movaps xmm6, [rsp]
00007c454bbdc55c  add rsp, 0x30
00007c454bbdc560  vmovaps xmm0, [rsp]
00007c454bbdc565  vmovaps xmm1, [rsp+0x10]
00007c454bbdc56b  vmovaps xmm2, [rsp+0x20]
00007c454bbdc571  vmovaps xmm3, [rsp+0x30]
00007c454bbdc577  vmovaps xmm4, [rsp+0x40]
00007c454bbdc57d  vmovaps xmm5, [rsp+0x50]
00007c454bbdc583  vmovaps xmm7, [rsp+0x60]
00007c454bbdc589  vmovaps xmm8, [rsp+0x70]
00007c454bbdc58f  vmovaps xmm9, [rsp+0x80]
00007c454bbdc598  vmovaps xmm10, [rsp+0x90]
00007c454bbdc5a1  vmovaps xmm11, [rsp+0xA0]
00007c454bbdc5aa  vmovaps xmm12, [rsp+0xB0]
00007c454bbdc5b3  vmovaps xmm13, [rsp+0xC0]
00007c454bbdc5bc  vmovaps xmm14, [rsp+0xD0]
00007c454bbdc5c5  vmovaps xmm15, [rsp+0xE0]
00007c454bbdc5ce  add rsp, 0xF0
00007c454bbdc5d5  pop r11
00007c454bbdc5d7  pop r10
00007c454bbdc5d9  pop r9
00007c454bbdc5db  pop r8
00007c454bbdc5dd  pop rsi
00007c454bbdc5de  pop rdi
00007c454bbdc5df  pop rdx
00007c454bbdc5e0  pop rcx
00007c454bbdc5e1  pop rax
00007c454bbdc5e2  add rsp, 0x08
00007c454bbdc5e6  jmp 0x00007C454BBD9405
00007c454bbdc5eb  sub rsp, 0x08
00007c454bbdc5ef  push rax
00007c454bbdc5f0  push rcx
00007c454bbdc5f1  push rdx
00007c454bbdc5f2  push rdi
00007c454bbdc5f3  push rsi
00007c454bbdc5f4  push r8
00007c454bbdc5f6  push r9
00007c454bbdc5f8  push r10
00007c454bbdc5fa  push r11
00007c454bbdc5fc  sub rsp, 0xF0
00007c454bbdc603  vmovaps [rsp], xmm0
00007c454bbdc608  vmovaps [rsp+0x10], xmm1
00007c454bbdc60e  vmovaps [rsp+0x20], xmm2
00007c454bbdc614  vmovaps [rsp+0x30], xmm3
00007c454bbdc61a  vmovaps [rsp+0x40], xmm4
00007c454bbdc620  vmovaps [rsp+0x50], xmm5
00007c454bbdc626  vmovaps [rsp+0x60], xmm6
00007c454bbdc62c  vmovaps [rsp+0x70], xmm7
00007c454bbdc632  vmovaps [rsp+0x80], xmm8
00007c454bbdc63b  vmovaps [rsp+0x90], xmm9
00007c454bbdc644  vmovaps [rsp+0xA0], xmm11
00007c454bbdc64d  vmovaps [rsp+0xB0], xmm12
00007c454bbdc656  vmovaps [rsp+0xC0], xmm13
00007c454bbdc65f  vmovaps [rsp+0xD0], xmm14
00007c454bbdc668  vmovaps [rsp+0xE0], xmm15
00007c454bbdc671  sub rsp, 0x30
00007c454bbdc675  movaps [rsp], xmm10
00007c454bbdc67a  movaps [rsp+0x10], xmm8
00007c454bbdc680  movaps [rsp+0x20], xmm14
00007c454bbdc686  lea rdi, [rsp]
00007c454bbdc68a  mov esi, 0x00
00007c454bbdc68f  mov rax, 0x56A18AC54530
00007c454bbdc699  call rax
00007c454bbdc69b  movaps xmm10, [rsp]
00007c454bbdc6a0  add rsp, 0x30
00007c454bbdc6a4  vmovaps xmm0, [rsp]
00007c454bbdc6a9  vmovaps xmm1, [rsp+0x10]
00007c454bbdc6af  vmovaps xmm2, [rsp+0x20]
00007c454bbdc6b5  vmovaps xmm3, [rsp+0x30]
00007c454bbdc6bb  vmovaps xmm4, [rsp+0x40]
00007c454bbdc6c1  vmovaps xmm5, [rsp+0x50]
00007c454bbdc6c7  vmovaps xmm6, [rsp+0x60]
00007c454bbdc6cd  vmovaps xmm7, [rsp+0x70]
00007c454bbdc6d3  vmovaps xmm8, [rsp+0x80]
00007c454bbdc6dc  vmovaps xmm9, [rsp+0x90]
00007c454bbdc6e5  vmovaps xmm11, [rsp+0xA0]
00007c454bbdc6ee  vmovaps xmm12, [rsp+0xB0]
00007c454bbdc6f7  vmovaps xmm13, [rsp+0xC0]
00007c454bbdc700  vmovaps xmm14, [rsp+0xD0]
00007c454bbdc709  vmovaps xmm15, [rsp+0xE0]
00007c454bbdc712  add rsp, 0xF0
00007c454bbdc719  pop r11
00007c454bbdc71b  pop r10
00007c454bbdc71d  pop r9
00007c454bbdc71f  pop r8
00007c454bbdc721  pop rsi
00007c454bbdc722  pop rdi
00007c454bbdc723  pop rdx
00007c454bbdc724  pop rcx
00007c454bbdc725  pop rax
00007c454bbdc726  add rsp, 0x08
00007c454bbdc72a  jmp 0x00007C454BBD9425
00007c454bbdc72f  sub rsp, 0x08
00007c454bbdc733  push rax
00007c454bbdc734  push rcx
00007c454bbdc735  push rdx
00007c454bbdc736  push rdi
00007c454bbdc737  push rsi
00007c454bbdc738  push r8
00007c454bbdc73a  push r9
00007c454bbdc73c  push r10
00007c454bbdc73e  push r11
00007c454bbdc740  sub rsp, 0xF0
00007c454bbdc747  vmovaps [rsp], xmm0
00007c454bbdc74c  vmovaps [rsp+0x10], xmm1
00007c454bbdc752  vmovaps [rsp+0x20], xmm2
00007c454bbdc758  vmovaps [rsp+0x30], xmm3
00007c454bbdc75e  vmovaps [rsp+0x40], xmm4
00007c454bbdc764  vmovaps [rsp+0x50], xmm5
00007c454bbdc76a  vmovaps [rsp+0x60], xmm6
00007c454bbdc770  vmovaps [rsp+0x70], xmm7
00007c454bbdc776  vmovaps [rsp+0x80], xmm8
00007c454bbdc77f  vmovaps [rsp+0x90], xmm9
00007c454bbdc788  vmovaps [rsp+0xA0], xmm10
00007c454bbdc791  vmovaps [rsp+0xB0], xmm11
00007c454bbdc79a  vmovaps [rsp+0xC0], xmm12
00007c454bbdc7a3  vmovaps [rsp+0xD0], xmm13
00007c454bbdc7ac  vmovaps [rsp+0xE0], xmm15
00007c454bbdc7b5  sub rsp, 0x30
00007c454bbdc7b9  movaps [rsp], xmm14
00007c454bbdc7be  movaps [rsp+0x10], xmm8
00007c454bbdc7c4  movaps [rsp+0x20], xmm4
00007c454bbdc7c9  lea rdi, [rsp]
00007c454bbdc7cd  mov esi, 0x00
00007c454bbdc7d2  mov rax, 0x56A18AC54530
00007c454bbdc7dc  call rax
00007c454bbdc7de  movaps xmm14, [rsp]
00007c454bbdc7e3  add rsp, 0x30
00007c454bbdc7e7  vmovaps xmm0, [rsp]
00007c454bbdc7ec  vmovaps xmm1, [rsp+0x10]
00007c454bbdc7f2  vmovaps xmm2, [rsp+0x20]
00007c454bbdc7f8  vmovaps xmm3, [rsp+0x30]
00007c454bbdc7fe  vmovaps xmm4, [rsp+0x40]
00007c454bbdc804  vmovaps xmm5, [rsp+0x50]
00007c454bbdc80a  vmovaps xmm6, [rsp+0x60]
00007c454bbdc810  vmovaps xmm7, [rsp+0x70]
00007c454bbdc816  vmovaps xmm8, [rsp+0x80]
00007c454bbdc81f  vmovaps xmm9, [rsp+0x90]
00007c454bbdc828  vmovaps xmm10, [rsp+0xA0]
00007c454bbdc831  vmovaps xmm11, [rsp+0xB0]
00007c454bbdc83a  vmovaps xmm12, [rsp+0xC0]
00007c454bbdc843  vmovaps xmm13, [rsp+0xD0]
00007c454bbdc84c  vmovaps xmm15, [rsp+0xE0]
00007c454bbdc855  add rsp, 0xF0
00007c454bbdc85c  pop r11
00007c454bbdc85e  pop r10
00007c454bbdc860  pop r9
00007c454bbdc862  pop r8
00007c454bbdc864  pop rsi
00007c454bbdc865  pop rdi
00007c454bbdc866  pop rdx
00007c454bbdc867  pop rcx
00007c454bbdc868  pop rax
00007c454bbdc869  add rsp, 0x08
00007c454bbdc86d  jmp 0x00007C454BBD9445
00007c454bbdc872  sub rsp, 0x08
00007c454bbdc876  push rax
00007c454bbdc877  push rcx
00007c454bbdc878  push rdx
00007c454bbdc879  push rdi
00007c454bbdc87a  push rsi
00007c454bbdc87b  push r8
00007c454bbdc87d  push r9
00007c454bbdc87f  push r10
00007c454bbdc881  push r11
00007c454bbdc883  sub rsp, 0xF0
00007c454bbdc88a  vmovaps [rsp], xmm0
00007c454bbdc88f  vmovaps [rsp+0x10], xmm1
00007c454bbdc895  vmovaps [rsp+0x20], xmm2
00007c454bbdc89b  vmovaps [rsp+0x30], xmm3
00007c454bbdc8a1  vmovaps [rsp+0x40], xmm5
00007c454bbdc8a7  vmovaps [rsp+0x50], xmm6
00007c454bbdc8ad  vmovaps [rsp+0x60], xmm7
00007c454bbdc8b3  vmovaps [rsp+0x70], xmm8
00007c454bbdc8b9  vmovaps [rsp+0x80], xmm9
00007c454bbdc8c2  vmovaps [rsp+0x90], xmm10
00007c454bbdc8cb  vmovaps [rsp+0xA0], xmm11
00007c454bbdc8d4  vmovaps [rsp+0xB0], xmm12
00007c454bbdc8dd  vmovaps [rsp+0xC0], xmm13
00007c454bbdc8e6  vmovaps [rsp+0xD0], xmm14
00007c454bbdc8ef  vmovaps [rsp+0xE0], xmm15
00007c454bbdc8f8  sub rsp, 0x30
00007c454bbdc8fc  movaps [rsp], xmm4
00007c454bbdc900  movaps [rsp+0x10], xmm13
00007c454bbdc906  movaps [rsp+0x20], xmm8
00007c454bbdc90c  lea rdi, [rsp]
00007c454bbdc910  mov esi, 0x00
00007c454bbdc915  mov rax, 0x56A18AC54530
00007c454bbdc91f  call rax
00007c454bbdc921  movaps xmm4, [rsp]
00007c454bbdc925  add rsp, 0x30
00007c454bbdc929  vmovaps xmm0, [rsp]
00007c454bbdc92e  vmovaps xmm1, [rsp+0x10]
00007c454bbdc934  vmovaps xmm2, [rsp+0x20]
00007c454bbdc93a  vmovaps xmm3, [rsp+0x30]
00007c454bbdc940  vmovaps xmm5, [rsp+0x40]
00007c454bbdc946  vmovaps xmm6, [rsp+0x50]
00007c454bbdc94c  vmovaps xmm7, [rsp+0x60]
00007c454bbdc952  vmovaps xmm8, [rsp+0x70]
00007c454bbdc958  vmovaps xmm9, [rsp+0x80]
00007c454bbdc961  vmovaps xmm10, [rsp+0x90]
00007c454bbdc96a  vmovaps xmm11, [rsp+0xA0]
00007c454bbdc973  vmovaps xmm12, [rsp+0xB0]
00007c454bbdc97c  vmovaps xmm13, [rsp+0xC0]
00007c454bbdc985  vmovaps xmm14, [rsp+0xD0]
00007c454bbdc98e  vmovaps xmm15, [rsp+0xE0]
00007c454bbdc997  add rsp, 0xF0
00007c454bbdc99e  pop r11
00007c454bbdc9a0  pop r10
00007c454bbdc9a2  pop r9
00007c454bbdc9a4  pop r8
00007c454bbdc9a6  pop rsi
00007c454bbdc9a7  pop rdi
00007c454bbdc9a8  pop rdx
00007c454bbdc9a9  pop rcx
00007c454bbdc9aa  pop rax
00007c454bbdc9ab  add rsp, 0x08
00007c454bbdc9af  jmp 0x00007C454BBD946A
00007c454bbdc9b4  sub rsp, 0x08
00007c454bbdc9b8  push rax
00007c454bbdc9b9  push rcx
00007c454bbdc9ba  push rdx
00007c454bbdc9bb  push rdi
00007c454bbdc9bc  push rsi
00007c454bbdc9bd  push r8
00007c454bbdc9bf  push r9
00007c454bbdc9c1  push r10
00007c454bbdc9c3  push r11
00007c454bbdc9c5  sub rsp, 0xF0
00007c454bbdc9cc  vmovaps [rsp], xmm0
00007c454bbdc9d1  vmovaps [rsp+0x10], xmm1
00007c454bbdc9d7  vmovaps [rsp+0x20], xmm2
00007c454bbdc9dd  vmovaps [rsp+0x30], xmm3
00007c454bbdc9e3  vmovaps [rsp+0x40], xmm4
00007c454bbdc9e9  vmovaps [rsp+0x50], xmm5
00007c454bbdc9ef  vmovaps [rsp+0x60], xmm6
00007c454bbdc9f5  vmovaps [rsp+0x70], xmm7
00007c454bbdc9fb  vmovaps [rsp+0x80], xmm8
00007c454bbdca04  vmovaps [rsp+0x90], xmm9
00007c454bbdca0d  vmovaps [rsp+0xA0], xmm10
00007c454bbdca16  vmovaps [rsp+0xB0], xmm11
00007c454bbdca1f  vmovaps [rsp+0xC0], xmm12
00007c454bbdca28  vmovaps [rsp+0xD0], xmm14
00007c454bbdca31  vmovaps [rsp+0xE0], xmm15
00007c454bbdca3a  sub rsp, 0x30
00007c454bbdca3e  movaps [rsp], xmm13
00007c454bbdca43  movaps [rsp+0x10], xmm15
00007c454bbdca49  movaps [rsp+0x20], xmm9
00007c454bbdca4f  lea rdi, [rsp]
00007c454bbdca53  mov esi, 0x00
00007c454bbdca58  mov rax, 0x56A18AC54530
00007c454bbdca62  call rax
00007c454bbdca64  movaps xmm13, [rsp]
00007c454bbdca69  add rsp, 0x30
00007c454bbdca6d  vmovaps xmm0, [rsp]
00007c454bbdca72  vmovaps xmm1, [rsp+0x10]
00007c454bbdca78  vmovaps xmm2, [rsp+0x20]
00007c454bbdca7e  vmovaps xmm3, [rsp+0x30]
00007c454bbdca84  vmovaps xmm4, [rsp+0x40]
00007c454bbdca8a  vmovaps xmm5, [rsp+0x50]
00007c454bbdca90  vmovaps xmm6, [rsp+0x60]
00007c454bbdca96  vmovaps xmm7, [rsp+0x70]
00007c454bbdca9c  vmovaps xmm8, [rsp+0x80]
00007c454bbdcaa5  vmovaps xmm9, [rsp+0x90]
00007c454bbdcaae  vmovaps xmm10, [rsp+0xA0]
00007c454bbdcab7  vmovaps xmm11, [rsp+0xB0]
00007c454bbdcac0  vmovaps xmm12, [rsp+0xC0]
00007c454bbdcac9  vmovaps xmm14, [rsp+0xD0]
00007c454bbdcad2  vmovaps xmm15, [rsp+0xE0]
00007c454bbdcadb  add rsp, 0xF0
00007c454bbdcae2  pop r11
00007c454bbdcae4  pop r10
00007c454bbdcae6  pop r9
00007c454bbdcae8  pop r8
00007c454bbdcaea  pop rsi
00007c454bbdcaeb  pop rdi
00007c454bbdcaec  pop rdx
00007c454bbdcaed  pop rcx
00007c454bbdcaee  pop rax
00007c454bbdcaef  add rsp, 0x08
00007c454bbdcaf3  jmp 0x00007C454BBD9485
00007c454bbdcaf8  sub rsp, 0x08
00007c454bbdcafc  push rax
00007c454bbdcafd  push rcx
00007c454bbdcafe  push rdx
00007c454bbdcaff  push rdi
00007c454bbdcb00  push rsi
00007c454bbdcb01  push r8
00007c454bbdcb03  push r9
00007c454bbdcb05  push r10
00007c454bbdcb07  push r11
00007c454bbdcb09  sub rsp, 0xF0
00007c454bbdcb10  vmovaps [rsp], xmm0
00007c454bbdcb15  vmovaps [rsp+0x10], xmm1
00007c454bbdcb1b  vmovaps [rsp+0x20], xmm2
00007c454bbdcb21  vmovaps [rsp+0x30], xmm3
00007c454bbdcb27  vmovaps [rsp+0x40], xmm4
00007c454bbdcb2d  vmovaps [rsp+0x50], xmm5
00007c454bbdcb33  vmovaps [rsp+0x60], xmm6
00007c454bbdcb39  vmovaps [rsp+0x70], xmm7
00007c454bbdcb3f  vmovaps [rsp+0x80], xmm8
00007c454bbdcb48  vmovaps [rsp+0x90], xmm9
00007c454bbdcb51  vmovaps [rsp+0xA0], xmm10
00007c454bbdcb5a  vmovaps [rsp+0xB0], xmm11
00007c454bbdcb63  vmovaps [rsp+0xC0], xmm12
00007c454bbdcb6c  vmovaps [rsp+0xD0], xmm13
00007c454bbdcb75  vmovaps [rsp+0xE0], xmm14
00007c454bbdcb7e  sub rsp, 0x30
00007c454bbdcb82  movaps [rsp], xmm15
00007c454bbdcb87  movaps [rsp+0x10], xmm1
00007c454bbdcb8c  movaps [rsp+0x20], xmm5
00007c454bbdcb91  lea rdi, [rsp]
00007c454bbdcb95  mov esi, 0x00
00007c454bbdcb9a  mov rax, 0x56A18AC54530
00007c454bbdcba4  call rax
00007c454bbdcba6  movaps xmm15, [rsp]
00007c454bbdcbab  add rsp, 0x30
00007c454bbdcbaf  vmovaps xmm0, [rsp]
00007c454bbdcbb4  vmovaps xmm1, [rsp+0x10]
00007c454bbdcbba  vmovaps xmm2, [rsp+0x20]
00007c454bbdcbc0  vmovaps xmm3, [rsp+0x30]
00007c454bbdcbc6  vmovaps xmm4, [rsp+0x40]
00007c454bbdcbcc  vmovaps xmm5, [rsp+0x50]
00007c454bbdcbd2  vmovaps xmm6, [rsp+0x60]
00007c454bbdcbd8  vmovaps xmm7, [rsp+0x70]
00007c454bbdcbde  vmovaps xmm8, [rsp+0x80]
00007c454bbdcbe7  vmovaps xmm9, [rsp+0x90]
00007c454bbdcbf0  vmovaps xmm10, [rsp+0xA0]
00007c454bbdcbf9  vmovaps xmm11, [rsp+0xB0]
00007c454bbdcc02  vmovaps xmm12, [rsp+0xC0]
00007c454bbdcc0b  vmovaps xmm13, [rsp+0xD0]
00007c454bbdcc14  vmovaps xmm14, [rsp+0xE0]
00007c454bbdcc1d  add rsp, 0xF0
00007c454bbdcc24  pop r11
00007c454bbdcc26  pop r10
00007c454bbdcc28  pop r9
00007c454bbdcc2a  pop r8
00007c454bbdcc2c  pop rsi
00007c454bbdcc2d  pop rdi
00007c454bbdcc2e  pop rdx
00007c454bbdcc2f  pop rcx
00007c454bbdcc30  pop rax
00007c454bbdcc31  add rsp, 0x08
00007c454bbdcc35  jmp 0x00007C454BBD94A0
00007c454bbdcc3a  call 0x00007C454BAD64F0
00007c454bbdcc3f  jmp 0x00007C454BBD94FB
00007c454bbdcc44  sub rsp, 0x08
00007c454bbdcc48  push rax
00007c454bbdcc49  push rcx
00007c454bbdcc4a  push rdx
00007c454bbdcc4b  push rdi
00007c454bbdcc4c  push rsi
00007c454bbdcc4d  push r8
00007c454bbdcc4f  push r9
00007c454bbdcc51  push r10
00007c454bbdcc53  push r11
00007c454bbdcc55  sub rsp, 0xF0
00007c454bbdcc5c  vmovaps [rsp], xmm0
00007c454bbdcc61  vmovaps [rsp+0x10], xmm1
00007c454bbdcc67  vmovaps [rsp+0x20], xmm2
00007c454bbdcc6d  vmovaps [rsp+0x30], xmm3
00007c454bbdcc73  vmovaps [rsp+0x40], xmm4
00007c454bbdcc79  vmovaps [rsp+0x50], xmm5
00007c454bbdcc7f  vmovaps [rsp+0x60], xmm6
00007c454bbdcc85  vmovaps [rsp+0x70], xmm7
00007c454bbdcc8b  vmovaps [rsp+0x80], xmm8
00007c454bbdcc94  vmovaps [rsp+0x90], xmm10
00007c454bbdcc9d  vmovaps [rsp+0xA0], xmm11
00007c454bbdcca6  vmovaps [rsp+0xB0], xmm12
00007c454bbdccaf  vmovaps [rsp+0xC0], xmm13
00007c454bbdccb8  vmovaps [rsp+0xD0], xmm14
00007c454bbdccc1  vmovaps [rsp+0xE0], xmm15
00007c454bbdccca  sub rsp, 0x30
00007c454bbdccce  movaps [rsp], xmm9
00007c454bbdccd3  movaps [rsp+0x10], xmm8
00007c454bbdccd9  movaps [rsp+0x20], xmm11
00007c454bbdccdf  lea rdi, [rsp]
00007c454bbdcce3  mov esi, 0x00
00007c454bbdcce8  mov rax, 0x56A18AC54530
00007c454bbdccf2  call rax
00007c454bbdccf4  movaps xmm9, [rsp]
00007c454bbdccf9  add rsp, 0x30
00007c454bbdccfd  vmovaps xmm0, [rsp]
00007c454bbdcd02  vmovaps xmm1, [rsp+0x10]
00007c454bbdcd08  vmovaps xmm2, [rsp+0x20]
00007c454bbdcd0e  vmovaps xmm3, [rsp+0x30]
00007c454bbdcd14  vmovaps xmm4, [rsp+0x40]
00007c454bbdcd1a  vmovaps xmm5, [rsp+0x50]
00007c454bbdcd20  vmovaps xmm6, [rsp+0x60]
00007c454bbdcd26  vmovaps xmm7, [rsp+0x70]
00007c454bbdcd2c  vmovaps xmm8, [rsp+0x80]
00007c454bbdcd35  vmovaps xmm10, [rsp+0x90]
00007c454bbdcd3e  vmovaps xmm11, [rsp+0xA0]
00007c454bbdcd47  vmovaps xmm12, [rsp+0xB0]
00007c454bbdcd50  vmovaps xmm13, [rsp+0xC0]
00007c454bbdcd59  vmovaps xmm14, [rsp+0xD0]
00007c454bbdcd62  vmovaps xmm15, [rsp+0xE0]
00007c454bbdcd6b  add rsp, 0xF0
00007c454bbdcd72  pop r11
00007c454bbdcd74  pop r10
00007c454bbdcd76  pop r9
00007c454bbdcd78  pop r8
00007c454bbdcd7a  pop rsi
00007c454bbdcd7b  pop rdi
00007c454bbdcd7c  pop rdx
00007c454bbdcd7d  pop rcx
00007c454bbdcd7e  pop rax
00007c454bbdcd7f  add rsp, 0x08
00007c454bbdcd83  jmp 0x00007C454BBD9532
00007c454bbdcd88  sub rsp, 0x08
00007c454bbdcd8c  push rax
00007c454bbdcd8d  push rcx
00007c454bbdcd8e  push rdx
00007c454bbdcd8f  push rdi
00007c454bbdcd90  push rsi
00007c454bbdcd91  push r8
00007c454bbdcd93  push r9
00007c454bbdcd95  push r10
00007c454bbdcd97  push r11
00007c454bbdcd99  sub rsp, 0xF0
00007c454bbdcda0  vmovaps [rsp], xmm0
00007c454bbdcda5  vmovaps [rsp+0x10], xmm1
00007c454bbdcdab  vmovaps [rsp+0x20], xmm2
00007c454bbdcdb1  vmovaps [rsp+0x30], xmm3
00007c454bbdcdb7  vmovaps [rsp+0x40], xmm4
00007c454bbdcdbd  vmovaps [rsp+0x50], xmm5
00007c454bbdcdc3  vmovaps [rsp+0x60], xmm6
00007c454bbdcdc9  vmovaps [rsp+0x70], xmm7
00007c454bbdcdcf  vmovaps [rsp+0x80], xmm8
00007c454bbdcdd8  vmovaps [rsp+0x90], xmm9
00007c454bbdcde1  vmovaps [rsp+0xA0], xmm10
00007c454bbdcdea  vmovaps [rsp+0xB0], xmm12
00007c454bbdcdf3  vmovaps [rsp+0xC0], xmm13
00007c454bbdcdfc  vmovaps [rsp+0xD0], xmm14
00007c454bbdce05  vmovaps [rsp+0xE0], xmm15
00007c454bbdce0e  sub rsp, 0x30
00007c454bbdce12  movaps [rsp], xmm11
00007c454bbdce17  movaps [rsp+0x10], xmm10
00007c454bbdce1d  movaps [rsp+0x20], xmm6
00007c454bbdce22  lea rdi, [rsp]
00007c454bbdce26  mov esi, 0x00
00007c454bbdce2b  mov rax, 0x56A18AC54530
00007c454bbdce35  call rax
00007c454bbdce37  movaps xmm11, [rsp]
00007c454bbdce3c  add rsp, 0x30
00007c454bbdce40  vmovaps xmm0, [rsp]
00007c454bbdce45  vmovaps xmm1, [rsp+0x10]
00007c454bbdce4b  vmovaps xmm2, [rsp+0x20]
00007c454bbdce51  vmovaps xmm3, [rsp+0x30]
00007c454bbdce57  vmovaps xmm4, [rsp+0x40]
00007c454bbdce5d  vmovaps xmm5, [rsp+0x50]
00007c454bbdce63  vmovaps xmm6, [rsp+0x60]
00007c454bbdce69  vmovaps xmm7, [rsp+0x70]
00007c454bbdce6f  vmovaps xmm8, [rsp+0x80]
00007c454bbdce78  vmovaps xmm9, [rsp+0x90]
00007c454bbdce81  vmovaps xmm10, [rsp+0xA0]
00007c454bbdce8a  vmovaps xmm12, [rsp+0xB0]
00007c454bbdce93  vmovaps xmm13, [rsp+0xC0]
00007c454bbdce9c  vmovaps xmm14, [rsp+0xD0]
00007c454bbdcea5  vmovaps xmm15, [rsp+0xE0]
00007c454bbdceae  add rsp, 0xF0
00007c454bbdceb5  pop r11
00007c454bbdceb7  pop r10
00007c454bbdceb9  pop r9
00007c454bbdcebb  pop r8
00007c454bbdcebd  pop rsi
00007c454bbdcebe  pop rdi
00007c454bbdcebf  pop rdx
00007c454bbdcec0  pop rcx
00007c454bbdcec1  pop rax
00007c454bbdcec2  add rsp, 0x08
00007c454bbdcec6  jmp 0x00007C454BBD954D
00007c454bbdcecb  sub rsp, 0x08
00007c454bbdcecf  push rax
00007c454bbdced0  push rcx
00007c454bbdced1  push rdx
00007c454bbdced2  push rdi
00007c454bbdced3  push rsi
00007c454bbdced4  push r8
00007c454bbdced6  push r9
00007c454bbdced8  push r10
00007c454bbdceda  push r11
00007c454bbdcedc  sub rsp, 0xF0
00007c454bbdcee3  vmovaps [rsp], xmm0
00007c454bbdcee8  vmovaps [rsp+0x10], xmm1
00007c454bbdceee  vmovaps [rsp+0x20], xmm2
00007c454bbdcef4  vmovaps [rsp+0x30], xmm3
00007c454bbdcefa  vmovaps [rsp+0x40], xmm4
00007c454bbdcf00  vmovaps [rsp+0x50], xmm5
00007c454bbdcf06  vmovaps [rsp+0x60], xmm6
00007c454bbdcf0c  vmovaps [rsp+0x70], xmm7
00007c454bbdcf12  vmovaps [rsp+0x80], xmm8
00007c454bbdcf1b  vmovaps [rsp+0x90], xmm9
00007c454bbdcf24  vmovaps [rsp+0xA0], xmm11
00007c454bbdcf2d  vmovaps [rsp+0xB0], xmm12
00007c454bbdcf36  vmovaps [rsp+0xC0], xmm13
00007c454bbdcf3f  vmovaps [rsp+0xD0], xmm14
00007c454bbdcf48  vmovaps [rsp+0xE0], xmm15
00007c454bbdcf51  sub rsp, 0x30
00007c454bbdcf55  movaps [rsp], xmm10
00007c454bbdcf5a  movaps [rsp+0x10], xmm14
00007c454bbdcf60  movaps [rsp+0x20], xmm4
00007c454bbdcf65  lea rdi, [rsp]
00007c454bbdcf69  mov esi, 0x00
00007c454bbdcf6e  mov rax, 0x56A18AC54530
00007c454bbdcf78  call rax
00007c454bbdcf7a  movaps xmm10, [rsp]
00007c454bbdcf7f  add rsp, 0x30
00007c454bbdcf83  vmovaps xmm0, [rsp]
00007c454bbdcf88  vmovaps xmm1, [rsp+0x10]
00007c454bbdcf8e  vmovaps xmm2, [rsp+0x20]
00007c454bbdcf94  vmovaps xmm3, [rsp+0x30]
00007c454bbdcf9a  vmovaps xmm4, [rsp+0x40]
00007c454bbdcfa0  vmovaps xmm5, [rsp+0x50]
00007c454bbdcfa6  vmovaps xmm6, [rsp+0x60]
00007c454bbdcfac  vmovaps xmm7, [rsp+0x70]
00007c454bbdcfb2  vmovaps xmm8, [rsp+0x80]
00007c454bbdcfbb  vmovaps xmm9, [rsp+0x90]
00007c454bbdcfc4  vmovaps xmm11, [rsp+0xA0]
00007c454bbdcfcd  vmovaps xmm12, [rsp+0xB0]
00007c454bbdcfd6  vmovaps xmm13, [rsp+0xC0]
00007c454bbdcfdf  vmovaps xmm14, [rsp+0xD0]
00007c454bbdcfe8  vmovaps xmm15, [rsp+0xE0]
00007c454bbdcff1  add rsp, 0xF0
00007c454bbdcff8  pop r11
00007c454bbdcffa  pop r10
00007c454bbdcffc  pop r9
00007c454bbdcffe  pop r8
00007c454bbdd000  pop rsi
00007c454bbdd001  pop rdi
00007c454bbdd002  pop rdx
00007c454bbdd003  pop rcx
00007c454bbdd004  pop rax
00007c454bbdd005  add rsp, 0x08
00007c454bbdd009  jmp 0x00007C454BBD9568
00007c454bbdd00e  sub rsp, 0x08
00007c454bbdd012  push rax
00007c454bbdd013  push rcx
00007c454bbdd014  push rdx
00007c454bbdd015  push rdi
00007c454bbdd016  push rsi
00007c454bbdd017  push r8
00007c454bbdd019  push r9
00007c454bbdd01b  push r10
00007c454bbdd01d  push r11
00007c454bbdd01f  sub rsp, 0xF0
00007c454bbdd026  vmovaps [rsp], xmm0
00007c454bbdd02b  vmovaps [rsp+0x10], xmm1
00007c454bbdd031  vmovaps [rsp+0x20], xmm2
00007c454bbdd037  vmovaps [rsp+0x30], xmm3
00007c454bbdd03d  vmovaps [rsp+0x40], xmm4
00007c454bbdd043  vmovaps [rsp+0x50], xmm5
00007c454bbdd049  vmovaps [rsp+0x60], xmm6
00007c454bbdd04f  vmovaps [rsp+0x70], xmm7
00007c454bbdd055  vmovaps [rsp+0x80], xmm9
00007c454bbdd05e  vmovaps [rsp+0x90], xmm10
00007c454bbdd067  vmovaps [rsp+0xA0], xmm11
00007c454bbdd070  vmovaps [rsp+0xB0], xmm12
00007c454bbdd079  vmovaps [rsp+0xC0], xmm13
00007c454bbdd082  vmovaps [rsp+0xD0], xmm14
00007c454bbdd08b  vmovaps [rsp+0xE0], xmm15
00007c454bbdd094  sub rsp, 0x30
00007c454bbdd098  movaps [rsp], xmm8
00007c454bbdd09d  movaps [rsp+0x10], xmm1
00007c454bbdd0a2  movaps [rsp+0x20], xmm14
00007c454bbdd0a8  lea rdi, [rsp]
00007c454bbdd0ac  mov esi, 0x00
00007c454bbdd0b1  mov rax, 0x56A18AC54530
00007c454bbdd0bb  call rax
00007c454bbdd0bd  movaps xmm8, [rsp]
00007c454bbdd0c2  add rsp, 0x30
00007c454bbdd0c6  vmovaps xmm0, [rsp]
00007c454bbdd0cb  vmovaps xmm1, [rsp+0x10]
00007c454bbdd0d1  vmovaps xmm2, [rsp+0x20]
00007c454bbdd0d7  vmovaps xmm3, [rsp+0x30]
00007c454bbdd0dd  vmovaps xmm4, [rsp+0x40]
00007c454bbdd0e3  vmovaps xmm5, [rsp+0x50]
00007c454bbdd0e9  vmovaps xmm6, [rsp+0x60]
00007c454bbdd0ef  vmovaps xmm7, [rsp+0x70]
00007c454bbdd0f5  vmovaps xmm9, [rsp+0x80]
00007c454bbdd0fe  vmovaps xmm10, [rsp+0x90]
00007c454bbdd107  vmovaps xmm11, [rsp+0xA0]
00007c454bbdd110  vmovaps xmm12, [rsp+0xB0]
00007c454bbdd119  vmovaps xmm13, [rsp+0xC0]
00007c454bbdd122  vmovaps xmm14, [rsp+0xD0]
00007c454bbdd12b  vmovaps xmm15, [rsp+0xE0]
00007c454bbdd134  add rsp, 0xF0
00007c454bbdd13b  pop r11
00007c454bbdd13d  pop r10
00007c454bbdd13f  pop r9
00007c454bbdd141  pop r8
00007c454bbdd143  pop rsi
00007c454bbdd144  pop rdi
00007c454bbdd145  pop rdx
00007c454bbdd146  pop rcx
00007c454bbdd147  pop rax
00007c454bbdd148  add rsp, 0x08
00007c454bbdd14c  jmp 0x00007C454BBD958E
00007c454bbdd151  sub rsp, 0x08
00007c454bbdd155  push rax
00007c454bbdd156  push rcx
00007c454bbdd157  push rdx
00007c454bbdd158  push rdi
00007c454bbdd159  push rsi
00007c454bbdd15a  push r8
00007c454bbdd15c  push r9
00007c454bbdd15e  push r10
00007c454bbdd160  push r11
00007c454bbdd162  sub rsp, 0xF0
00007c454bbdd169  vmovaps [rsp], xmm0
00007c454bbdd16e  vmovaps [rsp+0x10], xmm1
00007c454bbdd174  vmovaps [rsp+0x20], xmm2
00007c454bbdd17a  vmovaps [rsp+0x30], xmm3
00007c454bbdd180  vmovaps [rsp+0x40], xmm4
00007c454bbdd186  vmovaps [rsp+0x50], xmm5
00007c454bbdd18c  vmovaps [rsp+0x60], xmm7
00007c454bbdd192  vmovaps [rsp+0x70], xmm8
00007c454bbdd198  vmovaps [rsp+0x80], xmm9
00007c454bbdd1a1  vmovaps [rsp+0x90], xmm10
00007c454bbdd1aa  vmovaps [rsp+0xA0], xmm11
00007c454bbdd1b3  vmovaps [rsp+0xB0], xmm12
00007c454bbdd1bc  vmovaps [rsp+0xC0], xmm13
00007c454bbdd1c5  vmovaps [rsp+0xD0], xmm14
00007c454bbdd1ce  vmovaps [rsp+0xE0], xmm15
00007c454bbdd1d7  sub rsp, 0x30
00007c454bbdd1db  movaps [rsp], xmm6
00007c454bbdd1df  movaps [rsp+0x10], xmm1
00007c454bbdd1e4  movaps [rsp+0x20], xmm14
00007c454bbdd1ea  lea rdi, [rsp]
00007c454bbdd1ee  mov esi, 0x00
00007c454bbdd1f3  mov rax, 0x56A18AC54530
00007c454bbdd1fd  call rax
00007c454bbdd1ff  movaps xmm6, [rsp]
00007c454bbdd203  add rsp, 0x30
00007c454bbdd207  vmovaps xmm0, [rsp]
00007c454bbdd20c  vmovaps xmm1, [rsp+0x10]
00007c454bbdd212  vmovaps xmm2, [rsp+0x20]
00007c454bbdd218  vmovaps xmm3, [rsp+0x30]
00007c454bbdd21e  vmovaps xmm4, [rsp+0x40]
00007c454bbdd224  vmovaps xmm5, [rsp+0x50]
00007c454bbdd22a  vmovaps xmm7, [rsp+0x60]
00007c454bbdd230  vmovaps xmm8, [rsp+0x70]
00007c454bbdd236  vmovaps xmm9, [rsp+0x80]
00007c454bbdd23f  vmovaps xmm10, [rsp+0x90]
00007c454bbdd248  vmovaps xmm11, [rsp+0xA0]
00007c454bbdd251  vmovaps xmm12, [rsp+0xB0]
00007c454bbdd25a  vmovaps xmm13, [rsp+0xC0]
00007c454bbdd263  vmovaps xmm14, [rsp+0xD0]
00007c454bbdd26c  vmovaps xmm15, [rsp+0xE0]
00007c454bbdd275  add rsp, 0xF0
00007c454bbdd27c  pop r11
00007c454bbdd27e  pop r10
00007c454bbdd280  pop r9
00007c454bbdd282  pop r8
00007c454bbdd284  pop rsi
00007c454bbdd285  pop rdi
00007c454bbdd286  pop rdx
00007c454bbdd287  pop rcx
00007c454bbdd288  pop rax
00007c454bbdd289  add rsp, 0x08
00007c454bbdd28d  jmp 0x00007C454BBD95BA
00007c454bbdd292  sub rsp, 0x08
00007c454bbdd296  push rax
00007c454bbdd297  push rcx
00007c454bbdd298  push rdx
00007c454bbdd299  push rdi
00007c454bbdd29a  push rsi
00007c454bbdd29b  push r8
00007c454bbdd29d  push r9
00007c454bbdd29f  push r10
00007c454bbdd2a1  push r11
00007c454bbdd2a3  sub rsp, 0xF0
00007c454bbdd2aa  vmovaps [rsp], xmm0
00007c454bbdd2af  vmovaps [rsp+0x10], xmm1
00007c454bbdd2b5  vmovaps [rsp+0x20], xmm2
00007c454bbdd2bb  vmovaps [rsp+0x30], xmm3
00007c454bbdd2c1  vmovaps [rsp+0x40], xmm4
00007c454bbdd2c7  vmovaps [rsp+0x50], xmm5
00007c454bbdd2cd  vmovaps [rsp+0x60], xmm6
00007c454bbdd2d3  vmovaps [rsp+0x70], xmm7
00007c454bbdd2d9  vmovaps [rsp+0x80], xmm8
00007c454bbdd2e2  vmovaps [rsp+0x90], xmm9
00007c454bbdd2eb  vmovaps [rsp+0xA0], xmm10
00007c454bbdd2f4  vmovaps [rsp+0xB0], xmm11
00007c454bbdd2fd  vmovaps [rsp+0xC0], xmm12
00007c454bbdd306  vmovaps [rsp+0xD0], xmm13
00007c454bbdd30f  vmovaps [rsp+0xE0], xmm15
00007c454bbdd318  sub rsp, 0x30
00007c454bbdd31c  movaps [rsp], xmm14
00007c454bbdd321  movaps [rsp+0x10], xmm12
00007c454bbdd327  movaps [rsp+0x20], xmm1
00007c454bbdd32c  lea rdi, [rsp]
00007c454bbdd330  mov esi, 0x00
00007c454bbdd335  mov rax, 0x56A18AC54530
00007c454bbdd33f  call rax
00007c454bbdd341  movaps xmm14, [rsp]
00007c454bbdd346  add rsp, 0x30
00007c454bbdd34a  vmovaps xmm0, [rsp]
00007c454bbdd34f  vmovaps xmm1, [rsp+0x10]
00007c454bbdd355  vmovaps xmm2, [rsp+0x20]
00007c454bbdd35b  vmovaps xmm3, [rsp+0x30]
00007c454bbdd361  vmovaps xmm4, [rsp+0x40]
00007c454bbdd367  vmovaps xmm5, [rsp+0x50]
00007c454bbdd36d  vmovaps xmm6, [rsp+0x60]
00007c454bbdd373  vmovaps xmm7, [rsp+0x70]
00007c454bbdd379  vmovaps xmm8, [rsp+0x80]
00007c454bbdd382  vmovaps xmm9, [rsp+0x90]
00007c454bbdd38b  vmovaps xmm10, [rsp+0xA0]
00007c454bbdd394  vmovaps xmm11, [rsp+0xB0]
00007c454bbdd39d  vmovaps xmm12, [rsp+0xC0]
00007c454bbdd3a6  vmovaps xmm13, [rsp+0xD0]
00007c454bbdd3af  vmovaps xmm15, [rsp+0xE0]
00007c454bbdd3b8  add rsp, 0xF0
00007c454bbdd3bf  pop r11
00007c454bbdd3c1  pop r10
00007c454bbdd3c3  pop r9
00007c454bbdd3c5  pop r8
00007c454bbdd3c7  pop rsi
00007c454bbdd3c8  pop rdi
00007c454bbdd3c9  pop rdx
00007c454bbdd3ca  pop rcx
00007c454bbdd3cb  pop rax
00007c454bbdd3cc  add rsp, 0x08
00007c454bbdd3d0  jmp 0x00007C454BBD95E0
00007c454bbdd3d5  sub rsp, 0x08
00007c454bbdd3d9  push rax
00007c454bbdd3da  push rcx
00007c454bbdd3db  push rdx
00007c454bbdd3dc  push rdi
00007c454bbdd3dd  push rsi
00007c454bbdd3de  push r8
00007c454bbdd3e0  push r9
00007c454bbdd3e2  push r10
00007c454bbdd3e4  push r11
00007c454bbdd3e6  sub rsp, 0xF0
00007c454bbdd3ed  vmovaps [rsp], xmm0
00007c454bbdd3f2  vmovaps [rsp+0x10], xmm2
00007c454bbdd3f8  vmovaps [rsp+0x20], xmm3
00007c454bbdd3fe  vmovaps [rsp+0x30], xmm4
00007c454bbdd404  vmovaps [rsp+0x40], xmm5
00007c454bbdd40a  vmovaps [rsp+0x50], xmm6
00007c454bbdd410  vmovaps [rsp+0x60], xmm7
00007c454bbdd416  vmovaps [rsp+0x70], xmm8
00007c454bbdd41c  vmovaps [rsp+0x80], xmm9
00007c454bbdd425  vmovaps [rsp+0x90], xmm10
00007c454bbdd42e  vmovaps [rsp+0xA0], xmm11
00007c454bbdd437  vmovaps [rsp+0xB0], xmm12
00007c454bbdd440  vmovaps [rsp+0xC0], xmm13
00007c454bbdd449  vmovaps [rsp+0xD0], xmm14
00007c454bbdd452  vmovaps [rsp+0xE0], xmm15
00007c454bbdd45b  sub rsp, 0x30
00007c454bbdd45f  movaps [rsp], xmm1
00007c454bbdd463  movaps [rsp+0x10], xmm13
00007c454bbdd469  movaps [rsp+0x20], xmm9
00007c454bbdd46f  lea rdi, [rsp]
00007c454bbdd473  mov esi, 0x00
00007c454bbdd478  mov rax, 0x56A18AC54530
00007c454bbdd482  call rax
00007c454bbdd484  movaps xmm1, [rsp]
00007c454bbdd488  add rsp, 0x30
00007c454bbdd48c  vmovaps xmm0, [rsp]
00007c454bbdd491  vmovaps xmm2, [rsp+0x10]
00007c454bbdd497  vmovaps xmm3, [rsp+0x20]
00007c454bbdd49d  vmovaps xmm4, [rsp+0x30]
00007c454bbdd4a3  vmovaps xmm5, [rsp+0x40]
00007c454bbdd4a9  vmovaps xmm6, [rsp+0x50]
00007c454bbdd4af  vmovaps xmm7, [rsp+0x60]
00007c454bbdd4b5  vmovaps xmm8, [rsp+0x70]
00007c454bbdd4bb  vmovaps xmm9, [rsp+0x80]
00007c454bbdd4c4  vmovaps xmm10, [rsp+0x90]
00007c454bbdd4cd  vmovaps xmm11, [rsp+0xA0]
00007c454bbdd4d6  vmovaps xmm12, [rsp+0xB0]
00007c454bbdd4df  vmovaps xmm13, [rsp+0xC0]
00007c454bbdd4e8  vmovaps xmm14, [rsp+0xD0]
00007c454bbdd4f1  vmovaps xmm15, [rsp+0xE0]
00007c454bbdd4fa  add rsp, 0xF0
00007c454bbdd501  pop r11
00007c454bbdd503  pop r10
00007c454bbdd505  pop r9
00007c454bbdd507  pop r8
00007c454bbdd509  pop rsi
00007c454bbdd50a  pop rdi
00007c454bbdd50b  pop rdx
00007c454bbdd50c  pop rcx
00007c454bbdd50d  pop rax
00007c454bbdd50e  add rsp, 0x08
00007c454bbdd512  jmp 0x00007C454BBD95FA
00007c454bbdd517  sub rsp, 0x08
00007c454bbdd51b  push rax
00007c454bbdd51c  push rcx
00007c454bbdd51d  push rdx
00007c454bbdd51e  push rdi
00007c454bbdd51f  push rsi
00007c454bbdd520  push r8
00007c454bbdd522  push r9
00007c454bbdd524  push r10
00007c454bbdd526  push r11
00007c454bbdd528  sub rsp, 0xF0
00007c454bbdd52f  vmovaps [rsp], xmm0
00007c454bbdd534  vmovaps [rsp+0x10], xmm1
00007c454bbdd53a  vmovaps [rsp+0x20], xmm2
00007c454bbdd540  vmovaps [rsp+0x30], xmm3
00007c454bbdd546  vmovaps [rsp+0x40], xmm4
00007c454bbdd54c  vmovaps [rsp+0x50], xmm5
00007c454bbdd552  vmovaps [rsp+0x60], xmm6
00007c454bbdd558  vmovaps [rsp+0x70], xmm7
00007c454bbdd55e  vmovaps [rsp+0x80], xmm8
00007c454bbdd567  vmovaps [rsp+0x90], xmm9
00007c454bbdd570  vmovaps [rsp+0xA0], xmm10
00007c454bbdd579  vmovaps [rsp+0xB0], xmm11
00007c454bbdd582  vmovaps [rsp+0xC0], xmm13
00007c454bbdd58b  vmovaps [rsp+0xD0], xmm14
00007c454bbdd594  vmovaps [rsp+0xE0], xmm15
00007c454bbdd59d  sub rsp, 0x30
00007c454bbdd5a1  movaps [rsp], xmm12
00007c454bbdd5a6  movaps [rsp+0x10], xmm7
00007c454bbdd5ab  movaps [rsp+0x20], xmm13
00007c454bbdd5b1  lea rdi, [rsp]
00007c454bbdd5b5  mov esi, 0x00
00007c454bbdd5ba  mov rax, 0x56A18AC54530
00007c454bbdd5c4  call rax
00007c454bbdd5c6  movaps xmm12, [rsp]
00007c454bbdd5cb  add rsp, 0x30
00007c454bbdd5cf  vmovaps xmm0, [rsp]
00007c454bbdd5d4  vmovaps xmm1, [rsp+0x10]
00007c454bbdd5da  vmovaps xmm2, [rsp+0x20]
00007c454bbdd5e0  vmovaps xmm3, [rsp+0x30]
00007c454bbdd5e6  vmovaps xmm4, [rsp+0x40]
00007c454bbdd5ec  vmovaps xmm5, [rsp+0x50]
00007c454bbdd5f2  vmovaps xmm6, [rsp+0x60]
00007c454bbdd5f8  vmovaps xmm7, [rsp+0x70]
00007c454bbdd5fe  vmovaps xmm8, [rsp+0x80]
00007c454bbdd607  vmovaps xmm9, [rsp+0x90]
00007c454bbdd610  vmovaps xmm10, [rsp+0xA0]
00007c454bbdd619  vmovaps xmm11, [rsp+0xB0]
00007c454bbdd622  vmovaps xmm13, [rsp+0xC0]
00007c454bbdd62b  vmovaps xmm14, [rsp+0xD0]
00007c454bbdd634  vmovaps xmm15, [rsp+0xE0]
00007c454bbdd63d  add rsp, 0xF0
00007c454bbdd644  pop r11
00007c454bbdd646  pop r10
00007c454bbdd648  pop r9
00007c454bbdd64a  pop r8
00007c454bbdd64c  pop rsi
00007c454bbdd64d  pop rdi
00007c454bbdd64e  pop rdx
00007c454bbdd64f  pop rcx
00007c454bbdd650  pop rax
00007c454bbdd651  add rsp, 0x08
00007c454bbdd655  jmp 0x00007C454BBD9621
00007c454bbdd65a  sub rsp, 0x08
00007c454bbdd65e  push rax
00007c454bbdd65f  push rcx
00007c454bbdd660  push rdx
00007c454bbdd661  push rdi
00007c454bbdd662  push rsi
00007c454bbdd663  push r8
00007c454bbdd665  push r9
00007c454bbdd667  push r10
00007c454bbdd669  push r11
00007c454bbdd66b  sub rsp, 0xF0
00007c454bbdd672  vmovaps [rsp], xmm0
00007c454bbdd677  vmovaps [rsp+0x10], xmm1
00007c454bbdd67d  vmovaps [rsp+0x20], xmm2
00007c454bbdd683  vmovaps [rsp+0x30], xmm3
00007c454bbdd689  vmovaps [rsp+0x40], xmm4
00007c454bbdd68f  vmovaps [rsp+0x50], xmm5
00007c454bbdd695  vmovaps [rsp+0x60], xmm6
00007c454bbdd69b  vmovaps [rsp+0x70], xmm7
00007c454bbdd6a1  vmovaps [rsp+0x80], xmm8
00007c454bbdd6aa  vmovaps [rsp+0x90], xmm9
00007c454bbdd6b3  vmovaps [rsp+0xA0], xmm10
00007c454bbdd6bc  vmovaps [rsp+0xB0], xmm11
00007c454bbdd6c5  vmovaps [rsp+0xC0], xmm12
00007c454bbdd6ce  vmovaps [rsp+0xD0], xmm14
00007c454bbdd6d7  vmovaps [rsp+0xE0], xmm15
00007c454bbdd6e0  sub rsp, 0x30
00007c454bbdd6e4  movaps [rsp], xmm13
00007c454bbdd6e9  movaps [rsp+0x10], xmm15
00007c454bbdd6ef  movaps [rsp+0x20], xmm8
00007c454bbdd6f5  lea rdi, [rsp]
00007c454bbdd6f9  mov esi, 0x00
00007c454bbdd6fe  mov rax, 0x56A18AC54530
00007c454bbdd708  call rax
00007c454bbdd70a  movaps xmm13, [rsp]
00007c454bbdd70f  add rsp, 0x30
00007c454bbdd713  vmovaps xmm0, [rsp]
00007c454bbdd718  vmovaps xmm1, [rsp+0x10]
00007c454bbdd71e  vmovaps xmm2, [rsp+0x20]
00007c454bbdd724  vmovaps xmm3, [rsp+0x30]
00007c454bbdd72a  vmovaps xmm4, [rsp+0x40]
00007c454bbdd730  vmovaps xmm5, [rsp+0x50]
00007c454bbdd736  vmovaps xmm6, [rsp+0x60]
00007c454bbdd73c  vmovaps xmm7, [rsp+0x70]
00007c454bbdd742  vmovaps xmm8, [rsp+0x80]
00007c454bbdd74b  vmovaps xmm9, [rsp+0x90]
00007c454bbdd754  vmovaps xmm10, [rsp+0xA0]
00007c454bbdd75d  vmovaps xmm11, [rsp+0xB0]
00007c454bbdd766  vmovaps xmm12, [rsp+0xC0]
00007c454bbdd76f  vmovaps xmm14, [rsp+0xD0]
00007c454bbdd778  vmovaps xmm15, [rsp+0xE0]
00007c454bbdd781  add rsp, 0xF0
00007c454bbdd788  pop r11
00007c454bbdd78a  pop r10
00007c454bbdd78c  pop r9
00007c454bbdd78e  pop r8
00007c454bbdd790  pop rsi
00007c454bbdd791  pop rdi
00007c454bbdd792  pop rdx
00007c454bbdd793  pop rcx
00007c454bbdd794  pop rax
00007c454bbdd795  add rsp, 0x08
00007c454bbdd799  jmp 0x00007C454BBD963C
00007c454bbdd79e  sub rsp, 0x08
00007c454bbdd7a2  push rax
00007c454bbdd7a3  push rcx
00007c454bbdd7a4  push rdx
00007c454bbdd7a5  push rdi
00007c454bbdd7a6  push rsi
00007c454bbdd7a7  push r8
00007c454bbdd7a9  push r9
00007c454bbdd7ab  push r10
00007c454bbdd7ad  push r11
00007c454bbdd7af  sub rsp, 0xF0
00007c454bbdd7b6  vmovaps [rsp], xmm0
00007c454bbdd7bb  vmovaps [rsp+0x10], xmm1
00007c454bbdd7c1  vmovaps [rsp+0x20], xmm2
00007c454bbdd7c7  vmovaps [rsp+0x30], xmm3
00007c454bbdd7cd  vmovaps [rsp+0x40], xmm4
00007c454bbdd7d3  vmovaps [rsp+0x50], xmm5
00007c454bbdd7d9  vmovaps [rsp+0x60], xmm6
00007c454bbdd7df  vmovaps [rsp+0x70], xmm7
00007c454bbdd7e5  vmovaps [rsp+0x80], xmm9
00007c454bbdd7ee  vmovaps [rsp+0x90], xmm10
00007c454bbdd7f7  vmovaps [rsp+0xA0], xmm11
00007c454bbdd800  vmovaps [rsp+0xB0], xmm12
00007c454bbdd809  vmovaps [rsp+0xC0], xmm13
00007c454bbdd812  vmovaps [rsp+0xD0], xmm14
00007c454bbdd81b  vmovaps [rsp+0xE0], xmm15
00007c454bbdd824  sub rsp, 0x30
00007c454bbdd828  movaps [rsp], xmm8
00007c454bbdd82d  movaps [rsp+0x10], xmm15
00007c454bbdd833  movaps [rsp+0x20], xmm9
00007c454bbdd839  lea rdi, [rsp]
00007c454bbdd83d  mov esi, 0x00
00007c454bbdd842  mov rax, 0x56A18AC54530
00007c454bbdd84c  call rax
00007c454bbdd84e  movaps xmm8, [rsp]
00007c454bbdd853  add rsp, 0x30
00007c454bbdd857  vmovaps xmm0, [rsp]
00007c454bbdd85c  vmovaps xmm1, [rsp+0x10]
00007c454bbdd862  vmovaps xmm2, [rsp+0x20]
00007c454bbdd868  vmovaps xmm3, [rsp+0x30]
00007c454bbdd86e  vmovaps xmm4, [rsp+0x40]
00007c454bbdd874  vmovaps xmm5, [rsp+0x50]
00007c454bbdd87a  vmovaps xmm6, [rsp+0x60]
00007c454bbdd880  vmovaps xmm7, [rsp+0x70]
00007c454bbdd886  vmovaps xmm9, [rsp+0x80]
00007c454bbdd88f  vmovaps xmm10, [rsp+0x90]
00007c454bbdd898  vmovaps xmm11, [rsp+0xA0]
00007c454bbdd8a1  vmovaps xmm12, [rsp+0xB0]
00007c454bbdd8aa  vmovaps xmm13, [rsp+0xC0]
00007c454bbdd8b3  vmovaps xmm14, [rsp+0xD0]
00007c454bbdd8bc  vmovaps xmm15, [rsp+0xE0]
00007c454bbdd8c5  add rsp, 0xF0
00007c454bbdd8cc  pop r11
00007c454bbdd8ce  pop r10
00007c454bbdd8d0  pop r9
00007c454bbdd8d2  pop r8
00007c454bbdd8d4  pop rsi
00007c454bbdd8d5  pop rdi
00007c454bbdd8d6  pop rdx
00007c454bbdd8d7  pop rcx
00007c454bbdd8d8  pop rax
00007c454bbdd8d9  add rsp, 0x08
00007c454bbdd8dd  jmp 0x00007C454BBD966A
00007c454bbdd8e2  sub rsp, 0x08
00007c454bbdd8e6  push rax
00007c454bbdd8e7  push rcx
00007c454bbdd8e8  push rdx
00007c454bbdd8e9  push rdi
00007c454bbdd8ea  push rsi
00007c454bbdd8eb  push r8
00007c454bbdd8ed  push r9
00007c454bbdd8ef  push r10
00007c454bbdd8f1  push r11
00007c454bbdd8f3  sub rsp, 0xF0
00007c454bbdd8fa  vmovaps [rsp], xmm0
00007c454bbdd8ff  vmovaps [rsp+0x10], xmm1
00007c454bbdd905  vmovaps [rsp+0x20], xmm2
00007c454bbdd90b  vmovaps [rsp+0x30], xmm3
00007c454bbdd911  vmovaps [rsp+0x40], xmm4
00007c454bbdd917  vmovaps [rsp+0x50], xmm5
00007c454bbdd91d  vmovaps [rsp+0x60], xmm6
00007c454bbdd923  vmovaps [rsp+0x70], xmm7
00007c454bbdd929  vmovaps [rsp+0x80], xmm8
00007c454bbdd932  vmovaps [rsp+0x90], xmm9
00007c454bbdd93b  vmovaps [rsp+0xA0], xmm10
00007c454bbdd944  vmovaps [rsp+0xB0], xmm11
00007c454bbdd94d  vmovaps [rsp+0xC0], xmm12
00007c454bbdd956  vmovaps [rsp+0xD0], xmm13
00007c454bbdd95f  vmovaps [rsp+0xE0], xmm14
00007c454bbdd968  sub rsp, 0x30
00007c454bbdd96c  movaps [rsp], xmm15
00007c454bbdd971  movaps [rsp+0x10], xmm11
00007c454bbdd977  movaps [rsp+0x20], xmm6
00007c454bbdd97c  lea rdi, [rsp]
00007c454bbdd980  mov esi, 0x00
00007c454bbdd985  mov rax, 0x56A18AC54530
00007c454bbdd98f  call rax
00007c454bbdd991  movaps xmm15, [rsp]
00007c454bbdd996  add rsp, 0x30
00007c454bbdd99a  vmovaps xmm0, [rsp]
00007c454bbdd99f  vmovaps xmm1, [rsp+0x10]
00007c454bbdd9a5  vmovaps xmm2, [rsp+0x20]
00007c454bbdd9ab  vmovaps xmm3, [rsp+0x30]
00007c454bbdd9b1  vmovaps xmm4, [rsp+0x40]
00007c454bbdd9b7  vmovaps xmm5, [rsp+0x50]
00007c454bbdd9bd  vmovaps xmm6, [rsp+0x60]
00007c454bbdd9c3  vmovaps xmm7, [rsp+0x70]
00007c454bbdd9c9  vmovaps xmm8, [rsp+0x80]
00007c454bbdd9d2  vmovaps xmm9, [rsp+0x90]
00007c454bbdd9db  vmovaps xmm10, [rsp+0xA0]
00007c454bbdd9e4  vmovaps xmm11, [rsp+0xB0]
00007c454bbdd9ed  vmovaps xmm12, [rsp+0xC0]
00007c454bbdd9f6  vmovaps xmm13, [rsp+0xD0]
00007c454bbdd9ff  vmovaps xmm14, [rsp+0xE0]
00007c454bbdda08  add rsp, 0xF0
00007c454bbdda0f  pop r11
00007c454bbdda11  pop r10
00007c454bbdda13  pop r9
00007c454bbdda15  pop r8
00007c454bbdda17  pop rsi
00007c454bbdda18  pop rdi
00007c454bbdda19  pop rdx
00007c454bbdda1a  pop rcx
00007c454bbdda1b  pop rax
00007c454bbdda1c  add rsp, 0x08
00007c454bbdda20  jmp 0x00007C454BBD9685
00007c454bbdda25  sub rsp, 0x08
00007c454bbdda29  push rax
00007c454bbdda2a  push rcx
00007c454bbdda2b  push rdx
00007c454bbdda2c  push rdi
00007c454bbdda2d  push rsi
00007c454bbdda2e  push r8
00007c454bbdda30  push r9
00007c454bbdda32  push r10
00007c454bbdda34  push r11
00007c454bbdda36  sub rsp, 0xF0
00007c454bbdda3d  vmovaps [rsp], xmm0
00007c454bbdda42  vmovaps [rsp+0x10], xmm1
00007c454bbdda48  vmovaps [rsp+0x20], xmm2
00007c454bbdda4e  vmovaps [rsp+0x30], xmm3
00007c454bbdda54  vmovaps [rsp+0x40], xmm4
00007c454bbdda5a  vmovaps [rsp+0x50], xmm5
00007c454bbdda60  vmovaps [rsp+0x60], xmm6
00007c454bbdda66  vmovaps [rsp+0x70], xmm8
00007c454bbdda6c  vmovaps [rsp+0x80], xmm9
00007c454bbdda75  vmovaps [rsp+0x90], xmm10
00007c454bbdda7e  vmovaps [rsp+0xA0], xmm11
00007c454bbdda87  vmovaps [rsp+0xB0], xmm12
00007c454bbdda90  vmovaps [rsp+0xC0], xmm13
00007c454bbdda99  vmovaps [rsp+0xD0], xmm14
00007c454bbddaa2  vmovaps [rsp+0xE0], xmm15
00007c454bbddaab  sub rsp, 0x30
00007c454bbddaaf  movaps [rsp], xmm7
00007c454bbddab3  movaps [rsp+0x10], xmm11
00007c454bbddab9  movaps [rsp+0x20], xmm9
00007c454bbddabf  lea rdi, [rsp]
00007c454bbddac3  mov esi, 0x00
00007c454bbddac8  mov rax, 0x56A18AC54530
00007c454bbddad2  call rax
00007c454bbddad4  movaps xmm7, [rsp]
00007c454bbddad8  add rsp, 0x30
00007c454bbddadc  vmovaps xmm0, [rsp]
00007c454bbddae1  vmovaps xmm1, [rsp+0x10]
00007c454bbddae7  vmovaps xmm2, [rsp+0x20]
00007c454bbddaed  vmovaps xmm3, [rsp+0x30]
00007c454bbddaf3  vmovaps xmm4, [rsp+0x40]
00007c454bbddaf9  vmovaps xmm5, [rsp+0x50]
00007c454bbddaff  vmovaps xmm6, [rsp+0x60]
00007c454bbddb05  vmovaps xmm8, [rsp+0x70]
00007c454bbddb0b  vmovaps xmm9, [rsp+0x80]
00007c454bbddb14  vmovaps xmm10, [rsp+0x90]
00007c454bbddb1d  vmovaps xmm11, [rsp+0xA0]
00007c454bbddb26  vmovaps xmm12, [rsp+0xB0]
00007c454bbddb2f  vmovaps xmm13, [rsp+0xC0]
00007c454bbddb38  vmovaps xmm14, [rsp+0xD0]
00007c454bbddb41  vmovaps xmm15, [rsp+0xE0]
00007c454bbddb4a  add rsp, 0xF0
00007c454bbddb51  pop r11
00007c454bbddb53  pop r10
00007c454bbddb55  pop r9
00007c454bbddb57  pop r8
00007c454bbddb59  pop rsi
00007c454bbddb5a  pop rdi
00007c454bbddb5b  pop rdx
00007c454bbddb5c  pop rcx
00007c454bbddb5d  pop rax
00007c454bbddb5e  add rsp, 0x08
00007c454bbddb62  jmp 0x00007C454BBD96B2
00007c454bbddb67  sub rsp, 0x08
00007c454bbddb6b  push rax
00007c454bbddb6c  push rcx
00007c454bbddb6d  push rdx
00007c454bbddb6e  push rdi
00007c454bbddb6f  push rsi
00007c454bbddb70  push r8
00007c454bbddb72  push r9
00007c454bbddb74  push r10
00007c454bbddb76  push r11
00007c454bbddb78  sub rsp, 0xF0
00007c454bbddb7f  vmovaps [rsp], xmm0
00007c454bbddb84  vmovaps [rsp+0x10], xmm1
00007c454bbddb8a  vmovaps [rsp+0x20], xmm2
00007c454bbddb90  vmovaps [rsp+0x30], xmm3
00007c454bbddb96  vmovaps [rsp+0x40], xmm4
00007c454bbddb9c  vmovaps [rsp+0x50], xmm5
00007c454bbddba2  vmovaps [rsp+0x60], xmm6
00007c454bbddba8  vmovaps [rsp+0x70], xmm7
00007c454bbddbae  vmovaps [rsp+0x80], xmm8
00007c454bbddbb7  vmovaps [rsp+0x90], xmm9
00007c454bbddbc0  vmovaps [rsp+0xA0], xmm10
00007c454bbddbc9  vmovaps [rsp+0xB0], xmm12
00007c454bbddbd2  vmovaps [rsp+0xC0], xmm13
00007c454bbddbdb  vmovaps [rsp+0xD0], xmm14
00007c454bbddbe4  vmovaps [rsp+0xE0], xmm15
00007c454bbddbed  sub rsp, 0x30
00007c454bbddbf1  movaps [rsp], xmm11
00007c454bbddbf6  movaps [rsp+0x10], xmm10
00007c454bbddbfc  movaps [rsp+0x20], xmm14
00007c454bbddc02  lea rdi, [rsp]
00007c454bbddc06  mov esi, 0x00
00007c454bbddc0b  mov rax, 0x56A18AC54530
00007c454bbddc15  call rax
00007c454bbddc17  movaps xmm11, [rsp]
00007c454bbddc1c  add rsp, 0x30
00007c454bbddc20  vmovaps xmm0, [rsp]
00007c454bbddc25  vmovaps xmm1, [rsp+0x10]
00007c454bbddc2b  vmovaps xmm2, [rsp+0x20]
00007c454bbddc31  vmovaps xmm3, [rsp+0x30]
00007c454bbddc37  vmovaps xmm4, [rsp+0x40]
00007c454bbddc3d  vmovaps xmm5, [rsp+0x50]
00007c454bbddc43  vmovaps xmm6, [rsp+0x60]
00007c454bbddc49  vmovaps xmm7, [rsp+0x70]
00007c454bbddc4f  vmovaps xmm8, [rsp+0x80]
00007c454bbddc58  vmovaps xmm9, [rsp+0x90]
00007c454bbddc61  vmovaps xmm10, [rsp+0xA0]
00007c454bbddc6a  vmovaps xmm12, [rsp+0xB0]
00007c454bbddc73  vmovaps xmm13, [rsp+0xC0]
00007c454bbddc7c  vmovaps xmm14, [rsp+0xD0]
00007c454bbddc85  vmovaps xmm15, [rsp+0xE0]
00007c454bbddc8e  add rsp, 0xF0
00007c454bbddc95  pop r11
00007c454bbddc97  pop r10
00007c454bbddc99  pop r9
00007c454bbddc9b  pop r8
00007c454bbddc9d  pop rsi
00007c454bbddc9e  pop rdi
00007c454bbddc9f  pop rdx
00007c454bbddca0  pop rcx
00007c454bbddca1  pop rax
00007c454bbddca2  add rsp, 0x08
00007c454bbddca6  jmp 0x00007C454BBD96CD
00007c454bbddcab  call 0x00007C454BAE45A0
00007c454bbddcb0  jmp 0x00007C454BBD96D7
00007c454bbddcb5  sub rsp, 0x08
00007c454bbddcb9  push rax
00007c454bbddcba  push rcx
00007c454bbddcbb  push rdx
00007c454bbddcbc  push rdi
00007c454bbddcbd  push rsi
00007c454bbddcbe  push r8
00007c454bbddcc0  push r9
00007c454bbddcc2  push r10
00007c454bbddcc4  push r11
00007c454bbddcc6  sub rsp, 0xF0
00007c454bbddccd  vmovaps [rsp], xmm0
00007c454bbddcd2  vmovaps [rsp+0x10], xmm1
00007c454bbddcd8  vmovaps [rsp+0x20], xmm2
00007c454bbddcde  vmovaps [rsp+0x30], xmm3
00007c454bbddce4  vmovaps [rsp+0x40], xmm4
00007c454bbddcea  vmovaps [rsp+0x50], xmm5
00007c454bbddcf0  vmovaps [rsp+0x60], xmm6
00007c454bbddcf6  vmovaps [rsp+0x70], xmm7
00007c454bbddcfc  vmovaps [rsp+0x80], xmm8
00007c454bbddd05  vmovaps [rsp+0x90], xmm9
00007c454bbddd0e  vmovaps [rsp+0xA0], xmm11
00007c454bbddd17  vmovaps [rsp+0xB0], xmm12
00007c454bbddd20  vmovaps [rsp+0xC0], xmm13
00007c454bbddd29  vmovaps [rsp+0xD0], xmm14
00007c454bbddd32  vmovaps [rsp+0xE0], xmm15
00007c454bbddd3b  sub rsp, 0x30
00007c454bbddd3f  movaps [rsp], xmm10
00007c454bbddd44  movaps [rsp+0x10], xmm1
00007c454bbddd49  movaps [rsp+0x20], xmm12
00007c454bbddd4f  lea rdi, [rsp]
00007c454bbddd53  mov esi, 0x00
00007c454bbddd58  mov rax, 0x56A18AC54530
00007c454bbddd62  call rax
00007c454bbddd64  movaps xmm10, [rsp]
00007c454bbddd69  add rsp, 0x30
00007c454bbddd6d  vmovaps xmm0, [rsp]
00007c454bbddd72  vmovaps xmm1, [rsp+0x10]
00007c454bbddd78  vmovaps xmm2, [rsp+0x20]
00007c454bbddd7e  vmovaps xmm3, [rsp+0x30]
00007c454bbddd84  vmovaps xmm4, [rsp+0x40]
00007c454bbddd8a  vmovaps xmm5, [rsp+0x50]
00007c454bbddd90  vmovaps xmm6, [rsp+0x60]
00007c454bbddd96  vmovaps xmm7, [rsp+0x70]
00007c454bbddd9c  vmovaps xmm8, [rsp+0x80]
00007c454bbddda5  vmovaps xmm9, [rsp+0x90]
00007c454bbdddae  vmovaps xmm11, [rsp+0xA0]
00007c454bbdddb7  vmovaps xmm12, [rsp+0xB0]
00007c454bbdddc0  vmovaps xmm13, [rsp+0xC0]
00007c454bbdddc9  vmovaps xmm14, [rsp+0xD0]
00007c454bbdddd2  vmovaps xmm15, [rsp+0xE0]
00007c454bbddddb  add rsp, 0xF0
00007c454bbddde2  pop r11
00007c454bbddde4  pop r10
00007c454bbddde6  pop r9
00007c454bbddde8  pop r8
00007c454bbdddea  pop rsi
00007c454bbdddeb  pop rdi
00007c454bbdddec  pop rdx
00007c454bbddded  pop rcx
00007c454bbdddee  pop rax
00007c454bbdddef  add rsp, 0x08
00007c454bbdddf3  jmp 0x00007C454BBD96FA
00007c454bbdddf8  sub rsp, 0x08
00007c454bbdddfc  push rax
00007c454bbdddfd  push rcx
00007c454bbdddfe  push rdx
00007c454bbdddff  push rdi
00007c454bbdde00  push rsi
00007c454bbdde01  push r8
00007c454bbdde03  push r9
00007c454bbdde05  push r10
00007c454bbdde07  push r11
00007c454bbdde09  sub rsp, 0xF0
00007c454bbdde10  vmovaps [rsp], xmm0
00007c454bbdde15  vmovaps [rsp+0x10], xmm1
00007c454bbdde1b  vmovaps [rsp+0x20], xmm2
00007c454bbdde21  vmovaps [rsp+0x30], xmm3
00007c454bbdde27  vmovaps [rsp+0x40], xmm4
00007c454bbdde2d  vmovaps [rsp+0x50], xmm5
00007c454bbdde33  vmovaps [rsp+0x60], xmm6
00007c454bbdde39  vmovaps [rsp+0x70], xmm7
00007c454bbdde3f  vmovaps [rsp+0x80], xmm8
00007c454bbdde48  vmovaps [rsp+0x90], xmm9
00007c454bbdde51  vmovaps [rsp+0xA0], xmm10
00007c454bbdde5a  vmovaps [rsp+0xB0], xmm11
00007c454bbdde63  vmovaps [rsp+0xC0], xmm13
00007c454bbdde6c  vmovaps [rsp+0xD0], xmm14
00007c454bbdde75  vmovaps [rsp+0xE0], xmm15
00007c454bbdde7e  sub rsp, 0x30
00007c454bbdde82  movaps [rsp], xmm12
00007c454bbdde87  movaps [rsp+0x10], xmm14
00007c454bbdde8d  movaps [rsp+0x20], xmm1
00007c454bbdde92  lea rdi, [rsp]
00007c454bbdde96  mov esi, 0x00
00007c454bbdde9b  mov rax, 0x56A18AC54530
00007c454bbddea5  call rax
00007c454bbddea7  movaps xmm12, [rsp]
00007c454bbddeac  add rsp, 0x30
00007c454bbddeb0  vmovaps xmm0, [rsp]
00007c454bbddeb5  vmovaps xmm1, [rsp+0x10]
00007c454bbddebb  vmovaps xmm2, [rsp+0x20]
00007c454bbddec1  vmovaps xmm3, [rsp+0x30]
00007c454bbddec7  vmovaps xmm4, [rsp+0x40]
00007c454bbddecd  vmovaps xmm5, [rsp+0x50]
00007c454bbdded3  vmovaps xmm6, [rsp+0x60]
00007c454bbdded9  vmovaps xmm7, [rsp+0x70]
00007c454bbddedf  vmovaps xmm8, [rsp+0x80]
00007c454bbddee8  vmovaps xmm9, [rsp+0x90]
00007c454bbddef1  vmovaps xmm10, [rsp+0xA0]
00007c454bbddefa  vmovaps xmm11, [rsp+0xB0]
00007c454bbddf03  vmovaps xmm13, [rsp+0xC0]
00007c454bbddf0c  vmovaps xmm14, [rsp+0xD0]
00007c454bbddf15  vmovaps xmm15, [rsp+0xE0]
00007c454bbddf1e  add rsp, 0xF0
00007c454bbddf25  pop r11
00007c454bbddf27  pop r10
00007c454bbddf29  pop r9
00007c454bbddf2b  pop r8
00007c454bbddf2d  pop rsi
00007c454bbddf2e  pop rdi
00007c454bbddf2f  pop rdx
00007c454bbddf30  pop rcx
00007c454bbddf31  pop rax
00007c454bbddf32  add rsp, 0x08
00007c454bbddf36  jmp 0x00007C454BBD9729
00007c454bbddf3b  sub rsp, 0x08
00007c454bbddf3f  push rax
00007c454bbddf40  push rcx
00007c454bbddf41  push rdx
00007c454bbddf42  push rdi
00007c454bbddf43  push rsi
00007c454bbddf44  push r8
00007c454bbddf46  push r9
00007c454bbddf48  push r10
00007c454bbddf4a  push r11
00007c454bbddf4c  sub rsp, 0xF0
00007c454bbddf53  vmovaps [rsp], xmm0
00007c454bbddf58  vmovaps [rsp+0x10], xmm1
00007c454bbddf5e  vmovaps [rsp+0x20], xmm2
00007c454bbddf64  vmovaps [rsp+0x30], xmm3
00007c454bbddf6a  vmovaps [rsp+0x40], xmm4
00007c454bbddf70  vmovaps [rsp+0x50], xmm5
00007c454bbddf76  vmovaps [rsp+0x60], xmm6
00007c454bbddf7c  vmovaps [rsp+0x70], xmm7
00007c454bbddf82  vmovaps [rsp+0x80], xmm8
00007c454bbddf8b  vmovaps [rsp+0x90], xmm9
00007c454bbddf94  vmovaps [rsp+0xA0], xmm10
00007c454bbddf9d  vmovaps [rsp+0xB0], xmm11
00007c454bbddfa6  vmovaps [rsp+0xC0], xmm12
00007c454bbddfaf  vmovaps [rsp+0xD0], xmm13
00007c454bbddfb8  vmovaps [rsp+0xE0], xmm15
00007c454bbddfc1  sub rsp, 0x30
00007c454bbddfc5  movaps [rsp], xmm14
00007c454bbddfca  movaps [rsp+0x10], xmm9
00007c454bbddfd0  movaps [rsp+0x20], xmm1
00007c454bbddfd5  lea rdi, [rsp]
00007c454bbddfd9  mov esi, 0x00
00007c454bbddfde  mov rax, 0x56A18AC54530
00007c454bbddfe8  call rax
00007c454bbddfea  movaps xmm14, [rsp]
00007c454bbddfef  add rsp, 0x30
00007c454bbddff3  vmovaps xmm0, [rsp]
00007c454bbddff8  vmovaps xmm1, [rsp+0x10]
00007c454bbddffe  vmovaps xmm2, [rsp+0x20]
00007c454bbde004  vmovaps xmm3, [rsp+0x30]
00007c454bbde00a  vmovaps xmm4, [rsp+0x40]
00007c454bbde010  vmovaps xmm5, [rsp+0x50]
00007c454bbde016  vmovaps xmm6, [rsp+0x60]
00007c454bbde01c  vmovaps xmm7, [rsp+0x70]
00007c454bbde022  vmovaps xmm8, [rsp+0x80]
00007c454bbde02b  vmovaps xmm9, [rsp+0x90]
00007c454bbde034  vmovaps xmm10, [rsp+0xA0]
00007c454bbde03d  vmovaps xmm11, [rsp+0xB0]
00007c454bbde046  vmovaps xmm12, [rsp+0xC0]
00007c454bbde04f  vmovaps xmm13, [rsp+0xD0]
00007c454bbde058  vmovaps xmm15, [rsp+0xE0]
00007c454bbde061  add rsp, 0xF0
00007c454bbde068  pop r11
00007c454bbde06a  pop r10
00007c454bbde06c  pop r9
00007c454bbde06e  pop r8
00007c454bbde070  pop rsi
00007c454bbde071  pop rdi
00007c454bbde072  pop rdx
00007c454bbde073  pop rcx
00007c454bbde074  pop rax
00007c454bbde075  add rsp, 0x08
00007c454bbde079  jmp 0x00007C454BBD9758
00007c454bbde07e  sub rsp, 0x08
00007c454bbde082  push rax
00007c454bbde083  push rcx
00007c454bbde084  push rdx
00007c454bbde085  push rdi
00007c454bbde086  push rsi
00007c454bbde087  push r8
00007c454bbde089  push r9
00007c454bbde08b  push r10
00007c454bbde08d  push r11
00007c454bbde08f  sub rsp, 0xF0
00007c454bbde096  vmovaps [rsp], xmm0
00007c454bbde09b  vmovaps [rsp+0x10], xmm2
00007c454bbde0a1  vmovaps [rsp+0x20], xmm3
00007c454bbde0a7  vmovaps [rsp+0x30], xmm4
00007c454bbde0ad  vmovaps [rsp+0x40], xmm5
00007c454bbde0b3  vmovaps [rsp+0x50], xmm6
00007c454bbde0b9  vmovaps [rsp+0x60], xmm7
00007c454bbde0bf  vmovaps [rsp+0x70], xmm8
00007c454bbde0c5  vmovaps [rsp+0x80], xmm9
00007c454bbde0ce  vmovaps [rsp+0x90], xmm10
00007c454bbde0d7  vmovaps [rsp+0xA0], xmm11
00007c454bbde0e0  vmovaps [rsp+0xB0], xmm12
00007c454bbde0e9  vmovaps [rsp+0xC0], xmm13
00007c454bbde0f2  vmovaps [rsp+0xD0], xmm14
00007c454bbde0fb  vmovaps [rsp+0xE0], xmm15
00007c454bbde104  sub rsp, 0x30
00007c454bbde108  movaps [rsp], xmm1
00007c454bbde10c  movaps [rsp+0x10], xmm13
00007c454bbde112  movaps [rsp+0x20], xmm8
00007c454bbde118  lea rdi, [rsp]
00007c454bbde11c  mov esi, 0x00
00007c454bbde121  mov rax, 0x56A18AC54530
00007c454bbde12b  call rax
00007c454bbde12d  movaps xmm1, [rsp]
00007c454bbde131  add rsp, 0x30
00007c454bbde135  vmovaps xmm0, [rsp]
00007c454bbde13a  vmovaps xmm2, [rsp+0x10]
00007c454bbde140  vmovaps xmm3, [rsp+0x20]
00007c454bbde146  vmovaps xmm4, [rsp+0x30]
00007c454bbde14c  vmovaps xmm5, [rsp+0x40]
00007c454bbde152  vmovaps xmm6, [rsp+0x50]
00007c454bbde158  vmovaps xmm7, [rsp+0x60]
00007c454bbde15e  vmovaps xmm8, [rsp+0x70]
00007c454bbde164  vmovaps xmm9, [rsp+0x80]
00007c454bbde16d  vmovaps xmm10, [rsp+0x90]
00007c454bbde176  vmovaps xmm11, [rsp+0xA0]
00007c454bbde17f  vmovaps xmm12, [rsp+0xB0]
00007c454bbde188  vmovaps xmm13, [rsp+0xC0]
00007c454bbde191  vmovaps xmm14, [rsp+0xD0]
00007c454bbde19a  vmovaps xmm15, [rsp+0xE0]
00007c454bbde1a3  add rsp, 0xF0
00007c454bbde1aa  pop r11
00007c454bbde1ac  pop r10
00007c454bbde1ae  pop r9
00007c454bbde1b0  pop r8
00007c454bbde1b2  pop rsi
00007c454bbde1b3  pop rdi
00007c454bbde1b4  pop rdx
00007c454bbde1b5  pop rcx
00007c454bbde1b6  pop rax
00007c454bbde1b7  add rsp, 0x08
00007c454bbde1bb  jmp 0x00007C454BBD977A
00007c454bbde1c0  call 0x00007C454BA0C260
00007c454bbde1c5  jmp 0x00007C454BBD9788
00007c454bbde1ca  call 0x00007C454BADE950
00007c454bbde1cf  jmp 0x00007C454BBD9792
00007c454bbde1d4  sub rsp, 0x08
00007c454bbde1d8  push rax
00007c454bbde1d9  push rcx
00007c454bbde1da  push rdx
00007c454bbde1db  push rdi
00007c454bbde1dc  push rsi
00007c454bbde1dd  push r8
00007c454bbde1df  push r9
00007c454bbde1e1  push r10
00007c454bbde1e3  push r11
00007c454bbde1e5  sub rsp, 0xF0
00007c454bbde1ec  vmovaps [rsp], xmm0
00007c454bbde1f1  vmovaps [rsp+0x10], xmm1
00007c454bbde1f7  vmovaps [rsp+0x20], xmm2
00007c454bbde1fd  vmovaps [rsp+0x30], xmm3
00007c454bbde203  vmovaps [rsp+0x40], xmm4
00007c454bbde209  vmovaps [rsp+0x50], xmm5
00007c454bbde20f  vmovaps [rsp+0x60], xmm6
00007c454bbde215  vmovaps [rsp+0x70], xmm7
00007c454bbde21b  vmovaps [rsp+0x80], xmm9
00007c454bbde224  vmovaps [rsp+0x90], xmm10
00007c454bbde22d  vmovaps [rsp+0xA0], xmm11
00007c454bbde236  vmovaps [rsp+0xB0], xmm12
00007c454bbde23f  vmovaps [rsp+0xC0], xmm13
00007c454bbde248  vmovaps [rsp+0xD0], xmm14
00007c454bbde251  vmovaps [rsp+0xE0], xmm15
00007c454bbde25a  sub rsp, 0x30
00007c454bbde25e  movaps [rsp], xmm8
00007c454bbde263  movaps [rsp+0x10], xmm15
00007c454bbde269  movaps [rsp+0x20], xmm7
00007c454bbde26e  lea rdi, [rsp]
00007c454bbde272  mov esi, 0x00
00007c454bbde277  mov rax, 0x56A18AC54530
00007c454bbde281  call rax
00007c454bbde283  movaps xmm8, [rsp]
00007c454bbde288  add rsp, 0x30
00007c454bbde28c  vmovaps xmm0, [rsp]
00007c454bbde291  vmovaps xmm1, [rsp+0x10]
00007c454bbde297  vmovaps xmm2, [rsp+0x20]
00007c454bbde29d  vmovaps xmm3, [rsp+0x30]
00007c454bbde2a3  vmovaps xmm4, [rsp+0x40]
00007c454bbde2a9  vmovaps xmm5, [rsp+0x50]
00007c454bbde2af  vmovaps xmm6, [rsp+0x60]
00007c454bbde2b5  vmovaps xmm7, [rsp+0x70]
00007c454bbde2bb  vmovaps xmm9, [rsp+0x80]
00007c454bbde2c4  vmovaps xmm10, [rsp+0x90]
00007c454bbde2cd  vmovaps xmm11, [rsp+0xA0]
00007c454bbde2d6  vmovaps xmm12, [rsp+0xB0]
00007c454bbde2df  vmovaps xmm13, [rsp+0xC0]
00007c454bbde2e8  vmovaps xmm14, [rsp+0xD0]
00007c454bbde2f1  vmovaps xmm15, [rsp+0xE0]
00007c454bbde2fa  add rsp, 0xF0
00007c454bbde301  pop r11
00007c454bbde303  pop r10
00007c454bbde305  pop r9
00007c454bbde307  pop r8
00007c454bbde309  pop rsi
00007c454bbde30a  pop rdi
00007c454bbde30b  pop rdx
00007c454bbde30c  pop rcx
00007c454bbde30d  pop rax
00007c454bbde30e  add rsp, 0x08
00007c454bbde312  jmp 0x00007C454BBD97B4
00007c454bbde317  sub rsp, 0x08
00007c454bbde31b  push rax
00007c454bbde31c  push rcx
00007c454bbde31d  push rdx
00007c454bbde31e  push rdi
00007c454bbde31f  push rsi
00007c454bbde320  push r8
00007c454bbde322  push r9
00007c454bbde324  push r10
00007c454bbde326  push r11
00007c454bbde328  sub rsp, 0xF0
00007c454bbde32f  vmovaps [rsp], xmm0
00007c454bbde334  vmovaps [rsp+0x10], xmm1
00007c454bbde33a  vmovaps [rsp+0x20], xmm2
00007c454bbde340  vmovaps [rsp+0x30], xmm3
00007c454bbde346  vmovaps [rsp+0x40], xmm4
00007c454bbde34c  vmovaps [rsp+0x50], xmm5
00007c454bbde352  vmovaps [rsp+0x60], xmm6
00007c454bbde358  vmovaps [rsp+0x70], xmm8
00007c454bbde35e  vmovaps [rsp+0x80], xmm9
00007c454bbde367  vmovaps [rsp+0x90], xmm10
00007c454bbde370  vmovaps [rsp+0xA0], xmm11
00007c454bbde379  vmovaps [rsp+0xB0], xmm12
00007c454bbde382  vmovaps [rsp+0xC0], xmm13
00007c454bbde38b  vmovaps [rsp+0xD0], xmm14
00007c454bbde394  vmovaps [rsp+0xE0], xmm15
00007c454bbde39d  sub rsp, 0x30
00007c454bbde3a1  movaps [rsp], xmm7
00007c454bbde3a5  movaps [rsp+0x10], xmm9
00007c454bbde3ab  movaps [rsp+0x20], xmm15
00007c454bbde3b1  lea rdi, [rsp]
00007c454bbde3b5  mov esi, 0x00
00007c454bbde3ba  mov rax, 0x56A18AC54530
00007c454bbde3c4  call rax
00007c454bbde3c6  movaps xmm7, [rsp]
00007c454bbde3ca  add rsp, 0x30
00007c454bbde3ce  vmovaps xmm0, [rsp]
00007c454bbde3d3  vmovaps xmm1, [rsp+0x10]
00007c454bbde3d9  vmovaps xmm2, [rsp+0x20]
00007c454bbde3df  vmovaps xmm3, [rsp+0x30]
00007c454bbde3e5  vmovaps xmm4, [rsp+0x40]
00007c454bbde3eb  vmovaps xmm5, [rsp+0x50]
00007c454bbde3f1  vmovaps xmm6, [rsp+0x60]
00007c454bbde3f7  vmovaps xmm8, [rsp+0x70]
00007c454bbde3fd  vmovaps xmm9, [rsp+0x80]
00007c454bbde406  vmovaps xmm10, [rsp+0x90]
00007c454bbde40f  vmovaps xmm11, [rsp+0xA0]
00007c454bbde418  vmovaps xmm12, [rsp+0xB0]
00007c454bbde421  vmovaps xmm13, [rsp+0xC0]
00007c454bbde42a  vmovaps xmm14, [rsp+0xD0]
00007c454bbde433  vmovaps xmm15, [rsp+0xE0]
00007c454bbde43c  add rsp, 0xF0
00007c454bbde443  pop r11
00007c454bbde445  pop r10
00007c454bbde447  pop r9
00007c454bbde449  pop r8
00007c454bbde44b  pop rsi
00007c454bbde44c  pop rdi
00007c454bbde44d  pop rdx
00007c454bbde44e  pop rcx
00007c454bbde44f  pop rax
00007c454bbde450  add rsp, 0x08
00007c454bbde454  jmp 0x00007C454BBD97E1
00007c454bbde459  sub rsp, 0x08
00007c454bbde45d  push rax
00007c454bbde45e  push rcx
00007c454bbde45f  push rdx
00007c454bbde460  push rdi
00007c454bbde461  push rsi
00007c454bbde462  push r8
00007c454bbde464  push r9
00007c454bbde466  push r10
00007c454bbde468  push r11
00007c454bbde46a  sub rsp, 0xF0
00007c454bbde471  vmovaps [rsp], xmm0
00007c454bbde476  vmovaps [rsp+0x10], xmm1
00007c454bbde47c  vmovaps [rsp+0x20], xmm2
00007c454bbde482  vmovaps [rsp+0x30], xmm3
00007c454bbde488  vmovaps [rsp+0x40], xmm4
00007c454bbde48e  vmovaps [rsp+0x50], xmm5
00007c454bbde494  vmovaps [rsp+0x60], xmm6
00007c454bbde49a  vmovaps [rsp+0x70], xmm7
00007c454bbde4a0  vmovaps [rsp+0x80], xmm8
00007c454bbde4a9  vmovaps [rsp+0x90], xmm10
00007c454bbde4b2  vmovaps [rsp+0xA0], xmm11
00007c454bbde4bb  vmovaps [rsp+0xB0], xmm12
00007c454bbde4c4  vmovaps [rsp+0xC0], xmm13
00007c454bbde4cd  vmovaps [rsp+0xD0], xmm14
00007c454bbde4d6  vmovaps [rsp+0xE0], xmm15
00007c454bbde4df  sub rsp, 0x30
00007c454bbde4e3  movaps [rsp], xmm9
00007c454bbde4e8  movaps [rsp+0x10], xmm13
00007c454bbde4ee  movaps [rsp+0x20], xmm15
00007c454bbde4f4  lea rdi, [rsp]
00007c454bbde4f8  mov esi, 0x00
00007c454bbde4fd  mov rax, 0x56A18AC54530
00007c454bbde507  call rax
00007c454bbde509  movaps xmm9, [rsp]
00007c454bbde50e  add rsp, 0x30
00007c454bbde512  vmovaps xmm0, [rsp]
00007c454bbde517  vmovaps xmm1, [rsp+0x10]
00007c454bbde51d  vmovaps xmm2, [rsp+0x20]
00007c454bbde523  vmovaps xmm3, [rsp+0x30]
00007c454bbde529  vmovaps xmm4, [rsp+0x40]
00007c454bbde52f  vmovaps xmm5, [rsp+0x50]
00007c454bbde535  vmovaps xmm6, [rsp+0x60]
00007c454bbde53b  vmovaps xmm7, [rsp+0x70]
00007c454bbde541  vmovaps xmm8, [rsp+0x80]
00007c454bbde54a  vmovaps xmm10, [rsp+0x90]
00007c454bbde553  vmovaps xmm11, [rsp+0xA0]
00007c454bbde55c  vmovaps xmm12, [rsp+0xB0]
00007c454bbde565  vmovaps xmm13, [rsp+0xC0]
00007c454bbde56e  vmovaps xmm14, [rsp+0xD0]
00007c454bbde577  vmovaps xmm15, [rsp+0xE0]
00007c454bbde580  add rsp, 0xF0
00007c454bbde587  pop r11
00007c454bbde589  pop r10
00007c454bbde58b  pop r9
00007c454bbde58d  pop r8
00007c454bbde58f  pop rsi
00007c454bbde590  pop rdi
00007c454bbde591  pop rdx
00007c454bbde592  pop rcx
00007c454bbde593  pop rax
00007c454bbde594  add rsp, 0x08
00007c454bbde598  jmp 0x00007C454BBD980F
00007c454bbde59d  sub rsp, 0x08
00007c454bbde5a1  push rax
00007c454bbde5a2  push rcx
00007c454bbde5a3  push rdx
00007c454bbde5a4  push rdi
00007c454bbde5a5  push rsi
00007c454bbde5a6  push r8
00007c454bbde5a8  push r9
00007c454bbde5aa  push r10
00007c454bbde5ac  push r11
00007c454bbde5ae  sub rsp, 0xF0
00007c454bbde5b5  vmovaps [rsp], xmm0
00007c454bbde5ba  vmovaps [rsp+0x10], xmm1
00007c454bbde5c0  vmovaps [rsp+0x20], xmm2
00007c454bbde5c6  vmovaps [rsp+0x30], xmm3
00007c454bbde5cc  vmovaps [rsp+0x40], xmm4
00007c454bbde5d2  vmovaps [rsp+0x50], xmm5
00007c454bbde5d8  vmovaps [rsp+0x60], xmm6
00007c454bbde5de  vmovaps [rsp+0x70], xmm7
00007c454bbde5e4  vmovaps [rsp+0x80], xmm8
00007c454bbde5ed  vmovaps [rsp+0x90], xmm9
00007c454bbde5f6  vmovaps [rsp+0xA0], xmm10
00007c454bbde5ff  vmovaps [rsp+0xB0], xmm11
00007c454bbde608  vmovaps [rsp+0xC0], xmm12
00007c454bbde611  vmovaps [rsp+0xD0], xmm13
00007c454bbde61a  vmovaps [rsp+0xE0], xmm14
00007c454bbde623  sub rsp, 0x30
00007c454bbde627  movaps [rsp], xmm15
00007c454bbde62c  movaps [rsp+0x10], xmm11
00007c454bbde632  movaps [rsp+0x20], xmm12
00007c454bbde638  lea rdi, [rsp]
00007c454bbde63c  mov esi, 0x00
00007c454bbde641  mov rax, 0x56A18AC54530
00007c454bbde64b  call rax
00007c454bbde64d  movaps xmm15, [rsp]
00007c454bbde652  add rsp, 0x30
00007c454bbde656  vmovaps xmm0, [rsp]
00007c454bbde65b  vmovaps xmm1, [rsp+0x10]
00007c454bbde661  vmovaps xmm2, [rsp+0x20]
00007c454bbde667  vmovaps xmm3, [rsp+0x30]
00007c454bbde66d  vmovaps xmm4, [rsp+0x40]
00007c454bbde673  vmovaps xmm5, [rsp+0x50]
00007c454bbde679  vmovaps xmm6, [rsp+0x60]
00007c454bbde67f  vmovaps xmm7, [rsp+0x70]
00007c454bbde685  vmovaps xmm8, [rsp+0x80]
00007c454bbde68e  vmovaps xmm9, [rsp+0x90]
00007c454bbde697  vmovaps xmm10, [rsp+0xA0]
00007c454bbde6a0  vmovaps xmm11, [rsp+0xB0]
00007c454bbde6a9  vmovaps xmm12, [rsp+0xC0]
00007c454bbde6b2  vmovaps xmm13, [rsp+0xD0]
00007c454bbde6bb  vmovaps xmm14, [rsp+0xE0]
00007c454bbde6c4  add rsp, 0xF0
00007c454bbde6cb  pop r11
00007c454bbde6cd  pop r10
00007c454bbde6cf  pop r9
00007c454bbde6d1  pop r8
00007c454bbde6d3  pop rsi
00007c454bbde6d4  pop rdi
00007c454bbde6d5  pop rdx
00007c454bbde6d6  pop rcx
00007c454bbde6d7  pop rax
00007c454bbde6d8  add rsp, 0x08
00007c454bbde6dc  jmp 0x00007C454BBD982A
00007c454bbde6e1  sub rsp, 0x08
00007c454bbde6e5  push rax
00007c454bbde6e6  push rcx
00007c454bbde6e7  push rdx
00007c454bbde6e8  push rdi
00007c454bbde6e9  push rsi
00007c454bbde6ea  push r8
00007c454bbde6ec  push r9
00007c454bbde6ee  push r10
00007c454bbde6f0  push r11
00007c454bbde6f2  sub rsp, 0xF0
00007c454bbde6f9  vmovaps [rsp], xmm0
00007c454bbde6fe  vmovaps [rsp+0x10], xmm1
00007c454bbde704  vmovaps [rsp+0x20], xmm2
00007c454bbde70a  vmovaps [rsp+0x30], xmm3
00007c454bbde710  vmovaps [rsp+0x40], xmm4
00007c454bbde716  vmovaps [rsp+0x50], xmm5
00007c454bbde71c  vmovaps [rsp+0x60], xmm6
00007c454bbde722  vmovaps [rsp+0x70], xmm7
00007c454bbde728  vmovaps [rsp+0x80], xmm8
00007c454bbde731  vmovaps [rsp+0x90], xmm9
00007c454bbde73a  vmovaps [rsp+0xA0], xmm10
00007c454bbde743  vmovaps [rsp+0xB0], xmm11
00007c454bbde74c  vmovaps [rsp+0xC0], xmm12
00007c454bbde755  vmovaps [rsp+0xD0], xmm14
00007c454bbde75e  vmovaps [rsp+0xE0], xmm15
00007c454bbde767  sub rsp, 0x30
00007c454bbde76b  movaps [rsp], xmm13
00007c454bbde770  movaps [rsp+0x10], xmm10
00007c454bbde776  movaps [rsp+0x20], xmm14
00007c454bbde77c  lea rdi, [rsp]
00007c454bbde780  mov esi, 0x00
00007c454bbde785  mov rax, 0x56A18AC54530
00007c454bbde78f  call rax
00007c454bbde791  movaps xmm13, [rsp]
00007c454bbde796  add rsp, 0x30
00007c454bbde79a  vmovaps xmm0, [rsp]
00007c454bbde79f  vmovaps xmm1, [rsp+0x10]
00007c454bbde7a5  vmovaps xmm2, [rsp+0x20]
00007c454bbde7ab  vmovaps xmm3, [rsp+0x30]
00007c454bbde7b1  vmovaps xmm4, [rsp+0x40]
00007c454bbde7b7  vmovaps xmm5, [rsp+0x50]
00007c454bbde7bd  vmovaps xmm6, [rsp+0x60]
00007c454bbde7c3  vmovaps xmm7, [rsp+0x70]
00007c454bbde7c9  vmovaps xmm8, [rsp+0x80]
00007c454bbde7d2  vmovaps xmm9, [rsp+0x90]
00007c454bbde7db  vmovaps xmm10, [rsp+0xA0]
00007c454bbde7e4  vmovaps xmm11, [rsp+0xB0]
00007c454bbde7ed  vmovaps xmm12, [rsp+0xC0]
00007c454bbde7f6  vmovaps xmm14, [rsp+0xD0]
00007c454bbde7ff  vmovaps xmm15, [rsp+0xE0]
00007c454bbde808  add rsp, 0xF0
00007c454bbde80f  pop r11
00007c454bbde811  pop r10
00007c454bbde813  pop r9
00007c454bbde815  pop r8
00007c454bbde817  pop rsi
00007c454bbde818  pop rdi
00007c454bbde819  pop rdx
00007c454bbde81a  pop rcx
00007c454bbde81b  pop rax
00007c454bbde81c  add rsp, 0x08
00007c454bbde820  jmp 0x00007C454BBD984D
00007c454bbde825  sub rsp, 0x08
00007c454bbde829  push rax
00007c454bbde82a  push rcx
00007c454bbde82b  push rdx
00007c454bbde82c  push rdi
00007c454bbde82d  push rsi
00007c454bbde82e  push r8
00007c454bbde830  push r9
00007c454bbde832  push r10
00007c454bbde834  push r11
00007c454bbde836  sub rsp, 0xF0
00007c454bbde83d  vmovaps [rsp], xmm0
00007c454bbde842  vmovaps [rsp+0x10], xmm1
00007c454bbde848  vmovaps [rsp+0x20], xmm2
00007c454bbde84e  vmovaps [rsp+0x30], xmm3
00007c454bbde854  vmovaps [rsp+0x40], xmm4
00007c454bbde85a  vmovaps [rsp+0x50], xmm5
00007c454bbde860  vmovaps [rsp+0x60], xmm6
00007c454bbde866  vmovaps [rsp+0x70], xmm7
00007c454bbde86c  vmovaps [rsp+0x80], xmm8
00007c454bbde875  vmovaps [rsp+0x90], xmm9
00007c454bbde87e  vmovaps [rsp+0xA0], xmm10
00007c454bbde887  vmovaps [rsp+0xB0], xmm11
00007c454bbde890  vmovaps [rsp+0xC0], xmm12
00007c454bbde899  vmovaps [rsp+0xD0], xmm13
00007c454bbde8a2  vmovaps [rsp+0xE0], xmm15
00007c454bbde8ab  sub rsp, 0x30
00007c454bbde8af  movaps [rsp], xmm14
00007c454bbde8b4  movaps [rsp+0x10], xmm1
00007c454bbde8b9  movaps [rsp+0x20], xmm7
00007c454bbde8be  lea rdi, [rsp]
00007c454bbde8c2  mov esi, 0x00
00007c454bbde8c7  mov rax, 0x56A18AC54530
00007c454bbde8d1  call rax
00007c454bbde8d3  movaps xmm14, [rsp]
00007c454bbde8d8  add rsp, 0x30
00007c454bbde8dc  vmovaps xmm0, [rsp]
00007c454bbde8e1  vmovaps xmm1, [rsp+0x10]
00007c454bbde8e7  vmovaps xmm2, [rsp+0x20]
00007c454bbde8ed  vmovaps xmm3, [rsp+0x30]
00007c454bbde8f3  vmovaps xmm4, [rsp+0x40]
00007c454bbde8f9  vmovaps xmm5, [rsp+0x50]
00007c454bbde8ff  vmovaps xmm6, [rsp+0x60]
00007c454bbde905  vmovaps xmm7, [rsp+0x70]
00007c454bbde90b  vmovaps xmm8, [rsp+0x80]
00007c454bbde914  vmovaps xmm9, [rsp+0x90]
00007c454bbde91d  vmovaps xmm10, [rsp+0xA0]
00007c454bbde926  vmovaps xmm11, [rsp+0xB0]
00007c454bbde92f  vmovaps xmm12, [rsp+0xC0]
00007c454bbde938  vmovaps xmm13, [rsp+0xD0]
00007c454bbde941  vmovaps xmm15, [rsp+0xE0]
00007c454bbde94a  add rsp, 0xF0
00007c454bbde951  pop r11
00007c454bbde953  pop r10
00007c454bbde955  pop r9
00007c454bbde957  pop r8
00007c454bbde959  pop rsi
00007c454bbde95a  pop rdi
00007c454bbde95b  pop rdx
00007c454bbde95c  pop rcx
00007c454bbde95d  pop rax
00007c454bbde95e  add rsp, 0x08
00007c454bbde962  jmp 0x00007C454BBD9870
00007c454bbde967  sub rsp, 0x08
00007c454bbde96b  push rax
00007c454bbde96c  push rcx
00007c454bbde96d  push rdx
00007c454bbde96e  push rdi
00007c454bbde96f  push rsi
00007c454bbde970  push r8
00007c454bbde972  push r9
00007c454bbde974  push r10
00007c454bbde976  push r11
00007c454bbde978  sub rsp, 0xF0
00007c454bbde97f  vmovaps [rsp], xmm0
00007c454bbde984  vmovaps [rsp+0x10], xmm2
00007c454bbde98a  vmovaps [rsp+0x20], xmm3
00007c454bbde990  vmovaps [rsp+0x30], xmm4
00007c454bbde996  vmovaps [rsp+0x40], xmm5
00007c454bbde99c  vmovaps [rsp+0x50], xmm6
00007c454bbde9a2  vmovaps [rsp+0x60], xmm7
00007c454bbde9a8  vmovaps [rsp+0x70], xmm8
00007c454bbde9ae  vmovaps [rsp+0x80], xmm9
00007c454bbde9b7  vmovaps [rsp+0x90], xmm10
00007c454bbde9c0  vmovaps [rsp+0xA0], xmm11
00007c454bbde9c9  vmovaps [rsp+0xB0], xmm12
00007c454bbde9d2  vmovaps [rsp+0xC0], xmm13
00007c454bbde9db  vmovaps [rsp+0xD0], xmm14
00007c454bbde9e4  vmovaps [rsp+0xE0], xmm15
00007c454bbde9ed  sub rsp, 0x30
00007c454bbde9f1  movaps [rsp], xmm1
00007c454bbde9f5  movaps [rsp+0x10], xmm8
00007c454bbde9fb  movaps [rsp+0x20], xmm9
00007c454bbdea01  lea rdi, [rsp]
00007c454bbdea05  mov esi, 0x00
00007c454bbdea0a  mov rax, 0x56A18AC54530
00007c454bbdea14  call rax
00007c454bbdea16  movaps xmm1, [rsp]
00007c454bbdea1a  add rsp, 0x30
00007c454bbdea1e  vmovaps xmm0, [rsp]
00007c454bbdea23  vmovaps xmm2, [rsp+0x10]
00007c454bbdea29  vmovaps xmm3, [rsp+0x20]
00007c454bbdea2f  vmovaps xmm4, [rsp+0x30]
00007c454bbdea35  vmovaps xmm5, [rsp+0x40]
00007c454bbdea3b  vmovaps xmm6, [rsp+0x50]
00007c454bbdea41  vmovaps xmm7, [rsp+0x60]
00007c454bbdea47  vmovaps xmm8, [rsp+0x70]
00007c454bbdea4d  vmovaps xmm9, [rsp+0x80]
00007c454bbdea56  vmovaps xmm10, [rsp+0x90]
00007c454bbdea5f  vmovaps xmm11, [rsp+0xA0]
00007c454bbdea68  vmovaps xmm12, [rsp+0xB0]
00007c454bbdea71  vmovaps xmm13, [rsp+0xC0]
00007c454bbdea7a  vmovaps xmm14, [rsp+0xD0]
00007c454bbdea83  vmovaps xmm15, [rsp+0xE0]
00007c454bbdea8c  add rsp, 0xF0
00007c454bbdea93  pop r11
00007c454bbdea95  pop r10
00007c454bbdea97  pop r9
00007c454bbdea99  pop r8
00007c454bbdea9b  pop rsi
00007c454bbdea9c  pop rdi
00007c454bbdea9d  pop rdx
00007c454bbdea9e  pop rcx
00007c454bbdea9f  pop rax
00007c454bbdeaa0  add rsp, 0x08
00007c454bbdeaa4  jmp 0x00007C454BBD9892
00007c454bbdeaa9  call 0x00007C454BAB3E40
00007c454bbdeaae  jmp 0x00007C454BBD98A0
00007c454bbdeab3  call 0x00007C454BA0C380
00007c454bbdeab8  jmp 0x00007C454BBD98AA
00007c454bbdeabd  call 0x00007C454BA0D600
00007c454bbdeac2  jmp 0x00007C454BBD98B4
00007c454bbdeac7  call 0x00007C454B9FF540
00007c454bbdeacc  jmp 0x00007C454BBD98BE
00007c454bbdead1  int3
00007c454bbdead2  nop [rax+rax*1], ax
00007c454bbdeadb  nop [rax+rax*1], eax
00007c454bbdeae0  mov eax, [r15+0x48]
00007c454bbdeae4  lea r14d, [eax+0x01]
00007c454bbdeae9  mov [rsp+0x10], r14d
00007c454bbdeaee  mov r14d, r14d
00007c454bbdeaf1  mov [r15+0x48], r14
00007c454bbdeaf5  xor eax, eax
00007c454bbdeaf7  mov r14d, [rsp+0x10]
00007c454bbdeafc  cmp r14d, 0x1F4
00007c454bbdeb03  cmc
00007c454bbdeb04  lahf
00007c454bbdeb05  seto al
00007c454bbdeb08  mov [r15+0x108], eax
00007c454bbdeb0f  mov eax, [r15+0x108]
00007c454bbdeb16  sahf
00007c454bbdeb17  jnz 0x00007C454BBDEB49
00007c454bbdeb19  cmp dword ptr [r15+0x318], 0x00
00007c454bbdeb21  jz 0x00007C454BBE4C90
00007c454bbdeb27  nop [rax+rax*1], ax
00007c454bbdeb30  nop [rax+rax*1], eax
00007c454bbdeb38  mov eax, 0x4106DC
00007c454bbdeb3d  mov [r15+0x100], rax
00007c454bbdeb44  jmp 0x00007C454B9FE110
00007c454bbdeb49  cmp dword ptr [r15+0x318], 0x00
00007c454bbdeb51  jz 0x00007C454BBDEB80
00007c454bbdeb57  nop [rax+rax*1], ax
00007c454bbdeb60  nop [rax+rax*1], eax
00007c454bbdeb68  mov eax, 0x410500
00007c454bbdeb6d  mov [r15+0x100], rax
00007c454bbdeb74  jmp 0x00007C454B9FE110
00007c454bbdeb79  int3
00007c454bbdeb7a  int3
00007c454bbdeb7b  nop [rax+rax*1], eax
00007c454bbdeb80  mov rax, [r15+0x40]
00007c454bbdeb84  movaps xmm1, [r15+0x1D0]
00007c454bbdeb8c  vmovaps [rsp+0x10], xmm1
00007c454bbdeb92  vmovaps xmm15, [rsp+0x10]
00007c454bbdeb98  por xmm1, xmm15
00007c454bbdeb9d  movaps xmm14, [r15+0x1A0]
00007c454bbdeba5  vmovaps [rsp+0x10], xmm14
00007c454bbdebab  vmovaps xmm13, [rsp+0x10]
00007c454bbdebb1  por xmm14, xmm13
00007c454bbdebb6  lea r14, [rax+0x30]
00007c454bbdebba  mov r12, [r13+r14*1]
00007c454bbdebbf  lea r14, [rax+0x38]
00007c454bbdebc3  mov r11, [r13+r14*1]
00007c454bbdebc8  movq xmm13, r12
00007c454bbdebcd  movq xmm12, r11
00007c454bbdebd2  movq xmm13, xmm13
00007c454bbdebd7  vmovaps [rsp+0x10], xmm13
00007c454bbdebdd  movq xmm13, xmm13
00007c454bbdebe2  movaps [r15+0x130], xmm13
00007c454bbdebea  movq xmm12, xmm12
00007c454bbdebef  vmovaps [rsp+0x20], xmm12
00007c454bbdebf5  movq xmm12, xmm12
00007c454bbdebfa  movaps [r15+0x280], xmm12
00007c454bbdec02  movaps xmm13, [r15+0x270]
00007c454bbdec0a  vmovaps [rsp+0x30], xmm13
00007c454bbdec10  vmovaps xmm12, [rsp+0x30]
00007c454bbdec16  por xmm13, xmm12
00007c454bbdec1b  lea r14, [rax+0x20]
00007c454bbdec1f  mov r12, [r13+r14*1]
00007c454bbdec24  lea r14, [rax+0x28]
00007c454bbdec28  mov r11, [r13+r14*1]
00007c454bbdec2d  movq xmm12, r12
00007c454bbdec32  movq xmm11, r11
00007c454bbdec37  movq xmm12, xmm12
00007c454bbdec3c  vmovaps [rsp+0x30], xmm12
00007c454bbdec42  movq xmm12, xmm12
00007c454bbdec47  movaps [r15+0x150], xmm12
00007c454bbdec4f  movq xmm11, xmm11
00007c454bbdec54  vmovaps [rsp+0x40], xmm11
00007c454bbdec5a  movq xmm11, xmm11
00007c454bbdec5f  movaps [r15+0x140], xmm11
00007c454bbdec67  lea r14, [rax+0x10]
00007c454bbdec6b  mov r12, [r13+r14*1]
00007c454bbdec70  lea r14, [rax+0x18]
00007c454bbdec74  mov r11, [r13+r14*1]
00007c454bbdec79  movq xmm12, r12
00007c454bbdec7e  movq xmm11, r11
00007c454bbdec83  movq xmm12, xmm12
00007c454bbdec88  vmovaps [rsp+0x50], xmm12
00007c454bbdec8e  movq xmm12, xmm12
00007c454bbdec93  movaps [r15+0x170], xmm12
00007c454bbdec9b  movq xmm11, xmm11
00007c454bbdeca0  vmovaps [rsp+0x60], xmm11
00007c454bbdeca6  movq xmm11, xmm11
00007c454bbdecab  movaps [r15+0x160], xmm11
00007c454bbdecb3  mov r14, [r13+rax*1]
00007c454bbdecb8  vmovq xmm12, r14
00007c454bbdecbd  vpbroadcastq xmm12, xmm12
00007c454bbdecc2  lea r14, [rax+0x08]
00007c454bbdecc6  mov rax, [r13+r14*1]
00007c454bbdeccb  movq xmm11, rax
00007c454bbdecd0  movaps [r15+0x230], xmm11
00007c454bbdecd8  mov rax, [r15+0xF8]
00007c454bbdecdf  lea r14, [rax+0x50]
00007c454bbdece3  movups xmm11, [r13+r14*1]
00007c454bbdece9  lea r14, [rax+0x60]
00007c454bbdeced  movups xmm10, [r13+r14*1]
00007c454bbdecf3  lea r14, [rax+0x30]
00007c454bbdecf7  movups xmm9, [r13+r14*1]
00007c454bbdecfd  mov r14, [r15+0x50]
00007c454bbded01  mov [r15+0x60], r14
00007c454bbded05  mov qword ptr [r15+0x58], 0x40
00007c454bbded0d  movaps xmm8, xmm12
00007c454bbded11  mulpd xmm8, xmm15
00007c454bbded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007c454bbded1c  ptest xmm7, xmm7
00007c454bbded21  jnz 0x00007C454BBDFB4A
00007c454bbded27  movq xmm15, qword ptr [r15+0x230]
00007c454bbded30  vmovaps [rsp+0x70], xmm15
00007c454bbded36  vpermilpd xmm15, xmm15, 0x00
00007c454bbded3c  movaps xmm7, xmm9
00007c454bbded40  mulpd xmm7, xmm15
00007c454bbded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007c454bbded4a  ptest xmm6, xmm6
00007c454bbded4f  jnz 0x00007C454BBDFC8E
00007c454bbded55  vxorps xmm15, xmm15, xmm15
00007c454bbded5a  vpbroadcastq xmm15, xmm15
00007c454bbded5f  movaps xmm9, xmm12
00007c454bbded63  mulpd xmm9, xmm10
00007c454bbded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007c454bbded6e  ptest xmm6, xmm6
00007c454bbded73  jnz 0x00007C454BBDFDD0
00007c454bbded79  movaps xmm10, xmm12
00007c454bbded7d  mulpd xmm10, xmm11
00007c454bbded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007c454bbded88  ptest xmm6, xmm6
00007c454bbded8d  jnz 0x00007C454BBDFF14
00007c454bbded93  movaps xmm11, [r15+0x1F0]
00007c454bbded9b  movaps xmm6, xmm12
00007c454bbded9f  mulpd xmm6, xmm11
00007c454bbdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007c454bbdeda9  ptest xmm5, xmm5
00007c454bbdedae  jnz 0x00007C454BBE0058
00007c454bbdedb4  movaps xmm12, [r15+0x2A0]
00007c454bbdedbc  vmovaps [rsp+0x80], xmm12
00007c454bbdedc5  vmovaps xmm11, [rsp+0x80]
00007c454bbdedce  por xmm12, xmm11
00007c454bbdedd3  movaps xmm11, [r15+0x250]
00007c454bbdeddb  vmovaps [rsp+0x80], xmm11
00007c454bbdede4  vmovaps xmm5, [rsp+0x80]
00007c454bbdeded  por xmm11, xmm5
00007c454bbdedf2  vmovaps xmm4, [rsp+0x70]
00007c454bbdedf8  vpermilpd xmm4, xmm4, 0x00
00007c454bbdedfe  movaps xmm3, xmm5
00007c454bbdee01  mulpd xmm3, xmm4
00007c454bbdee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007c454bbdee0a  ptest xmm2, xmm2
00007c454bbdee0f  jnz 0x00007C454BBE019A
00007c454bbdee15  mov [rsp+0x80], rax
00007c454bbdee1d  xor eax, eax
00007c454bbdee1f  mov r12d, 0x40
00007c454bbdee25  mov r11d, 0x200
00007c454bbdee2b  cmp r12, r11
00007c454bbdee2e  cmc
00007c454bbdee2f  lahf
00007c454bbdee30  seto al
00007c454bbdee33  mov [r15+0x108], eax
00007c454bbdee3a  movaps xmm5, xmm8
00007c454bbdee3e  addpd xmm5, xmm15
00007c454bbdee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007c454bbdee48  ptest xmm4, xmm4
00007c454bbdee4d  jnz 0x00007C454BBE02DA
00007c454bbdee53  movaps xmm8, [r15+0x1B0]
00007c454bbdee5b  movaps xmm4, xmm9
00007c454bbdee5f  addpd xmm4, xmm8
00007c454bbdee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007c454bbdee69  ptest xmm2, xmm2
00007c454bbdee6e  jnz 0x00007C454BBE041C
00007c454bbdee74  movaps xmm9, xmm10
00007c454bbdee78  addpd xmm9, xmm8
00007c454bbdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007c454bbdee83  ptest xmm2, xmm2
00007c454bbdee88  jnz 0x00007C454BBE055E
00007c454bbdee8e  movaps xmm10, [r15+0x2F0]
00007c454bbdee96  vmovaps [rsp+0x90], xmm10
00007c454bbdee9f  vmovaps xmm8, [rsp+0x90]
00007c454bbdeea8  por xmm10, xmm8
00007c454bbdeead  movaps xmm8, [r15+0x2E0]
00007c454bbdeeb5  vmovaps [rsp+0x90], xmm8
00007c454bbdeebe  vmovaps xmm2, [rsp+0x90]
00007c454bbdeec7  por xmm8, xmm2
00007c454bbdeecc  movaps xmm2, [r15+0x2D0]
00007c454bbdeed4  vmovaps [rsp+0x90], xmm2
00007c454bbdeedd  vmovaps [rsp+0xA0], xmm1
00007c454bbdeee6  vmovaps xmm1, [rsp+0x90]
00007c454bbdeeef  por xmm2, xmm1
00007c454bbdeef3  movaps xmm1, [r15+0x200]
00007c454bbdeefb  vmovaps [rsp+0x90], xmm1
00007c454bbdef04  vmovaps [rsp+0xB0], xmm15
00007c454bbdef0d  vmovaps xmm15, [rsp+0x90]
00007c454bbdef16  por xmm1, xmm15
00007c454bbdef1b  movaps xmm15, [r15+0x1C0]
00007c454bbdef23  vmovaps [rsp+0x90], xmm15
00007c454bbdef2c  vmovaps [rsp+0xC0], xmm1
00007c454bbdef35  vmovaps xmm1, [rsp+0x90]
00007c454bbdef3e  por xmm15, xmm1
00007c454bbdef43  movaps xmm1, [r15+0x190]
00007c454bbdef4b  vmovaps [rsp+0x90], xmm1
00007c454bbdef54  vmovaps [rsp+0xD0], xmm15
00007c454bbdef5d  vmovaps xmm15, [rsp+0x90]
00007c454bbdef66  por xmm1, xmm15
00007c454bbdef6b  movaps xmm15, [r15+0x300]
00007c454bbdef73  vmovaps [rsp+0x90], xmm15
00007c454bbdef7c  vmovaps [rsp+0xE0], xmm1
00007c454bbdef85  vmovaps xmm1, [rsp+0x90]
00007c454bbdef8e  por xmm15, xmm1
00007c454bbdef93  mov rax, [rsp+0x80]
00007c454bbdef9b  lea r12, [rax+0xA0]
00007c454bbdefa2  movups xmm1, [r13+r12*1]
00007c454bbdefa8  lea r12, [rax+0xB0]
00007c454bbdefaf  vmovaps [rsp+0x80], xmm1
00007c454bbdefb8  movups xmm1, [r13+r12*1]
00007c454bbdefbe  vmovaps [rsp+0x90], xmm1
00007c454bbdefc7  vmovaps [rsp+0xF0], xmm15
00007c454bbdefd0  vmovaps xmm15, [rsp+0xB0]
00007c454bbdefd9  vmovaps [rsp+0xB0], xmm14
00007c454bbdefe2  movaps xmm1, xmm6
00007c454bbdefe5  addpd xmm1, xmm15
00007c454bbdefea  vcmppd xmm14, xmm1, xmm1, 0x03
00007c454bbdefef  ptest xmm14, xmm14
00007c454bbdeff5  jnz 0x00007C454BBE06B6
00007c454bbdeffb  lea r12, [rax+0xF0]
00007c454bbdf002  movups xmm15, [r13+r12*1]
00007c454bbdf008  movaps xmm14, xmm4
00007c454bbdf00c  addpd xmm14, xmm3
00007c454bbdf011  vcmppd xmm6, xmm14, xmm14, 0x03
00007c454bbdf017  ptest xmm6, xmm6
00007c454bbdf01c  jnz 0x00007C454BBE0801
00007c454bbdf022  movaps xmm6, xmm9
00007c454bbdf026  addpd xmm6, xmm7
00007c454bbdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007c454bbdf02f  ptest xmm4, xmm4
00007c454bbdf034  jnz 0x00007C454BBE0943
00007c454bbdf03a  vmovaps xmm9, [rsp+0x70]
00007c454bbdf040  vpermilpd xmm9, xmm9, 0x00
00007c454bbdf046  vmovaps xmm4, [rsp+0x90]
00007c454bbdf04f  movaps xmm7, xmm4
00007c454bbdf052  mulpd xmm7, xmm9
00007c454bbdf057  vcmppd xmm3, xmm7, xmm7, 0x03
00007c454bbdf05c  ptest xmm3, xmm3
00007c454bbdf061  jnz 0x00007C454BBE0A84
00007c454bbdf067  vmovaps xmm9, [rsp+0x50]
00007c454bbdf06d  vpermilpd xmm9, xmm9, 0x00
00007c454bbdf073  movaps xmm4, xmm15
00007c454bbdf077  mulpd xmm4, xmm9
00007c454bbdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007c454bbdf081  ptest xmm3, xmm3
00007c454bbdf086  jnz 0x00007C454BBE0BC5
00007c454bbdf08c  lea r12, [rax+0xE0]
00007c454bbdf093  movups xmm15, [r13+r12*1]
00007c454bbdf099  vmovaps xmm9, [rsp+0x70]
00007c454bbdf09f  vpermilpd xmm9, xmm9, 0x00
00007c454bbdf0a5  vmovaps [rsp+0x70], xmm1
00007c454bbdf0ab  vmovaps xmm1, [rsp+0x80]
00007c454bbdf0b4  vmovaps [rsp+0x80], xmm15
00007c454bbdf0bd  movaps xmm3, xmm1
00007c454bbdf0c0  mulpd xmm3, xmm9
00007c454bbdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007c454bbdf0ca  ptest xmm15, xmm15
00007c454bbdf0d0  jnz 0x00007C454BBE0D11
00007c454bbdf0d6  vmovaps xmm1, [rsp+0xF0]
00007c454bbdf0df  vmovaps xmm15, [rsp+0xF0]
00007c454bbdf0e8  por xmm1, xmm15
00007c454bbdf0ed  movaps [r15+0x300], xmm1
00007c454bbdf0f5  vmovaps xmm15, [rsp+0xE0]
00007c454bbdf0fe  vmovaps xmm9, [rsp+0xE0]
00007c454bbdf107  por xmm15, xmm9
00007c454bbdf10c  movaps [r15+0x190], xmm15
00007c454bbdf114  vmovaps xmm9, [rsp+0x50]
00007c454bbdf11a  vpermilpd xmm9, xmm9, 0x00
00007c454bbdf120  vmovaps [rsp+0x90], xmm1
00007c454bbdf129  vmovaps [rsp+0xE0], xmm15
00007c454bbdf132  vmovaps xmm15, [rsp+0x80]
00007c454bbdf13b  vmovaps [rsp+0x80], xmm14
00007c454bbdf144  movaps xmm1, xmm15
00007c454bbdf148  mulpd xmm1, xmm9
00007c454bbdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007c454bbdf152  ptest xmm14, xmm14
00007c454bbdf158  jnz 0x00007C454BBE0E52
00007c454bbdf15e  lea r12, [rax+0x90]
00007c454bbdf165  movups xmm15, [r13+r12*1]
00007c454bbdf16b  vmovaps xmm14, [rsp+0xD0]
00007c454bbdf174  vmovaps xmm9, [rsp+0xD0]
00007c454bbdf17d  por xmm14, xmm9
00007c454bbdf182  movaps [r15+0x1C0], xmm14
00007c454bbdf18a  vmovaps xmm9, [rsp+0xC0]
00007c454bbdf193  vmovaps [rsp+0xD0], xmm1
00007c454bbdf19c  vmovaps xmm1, [rsp+0xC0]
00007c454bbdf1a5  por xmm9, xmm1
00007c454bbdf1aa  movaps [r15+0x200], xmm9
00007c454bbdf1b2  vmovaps [rsp+0xC0], xmm2
00007c454bbdf1bb  vmovaps xmm1, [rsp+0xC0]
00007c454bbdf1c4  por xmm2, xmm1
00007c454bbdf1c8  movaps [r15+0x2D0], xmm2
00007c454bbdf1d0  vmovaps [rsp+0xC0], xmm8
00007c454bbdf1d9  vmovaps xmm1, [rsp+0xC0]
00007c454bbdf1e2  por xmm8, xmm1
00007c454bbdf1e7  movaps [r15+0x2E0], xmm8
00007c454bbdf1ef  vmovaps [rsp+0xC0], xmm15
00007c454bbdf1f8  movaps xmm1, xmm5
00007c454bbdf1fb  addpd xmm1, xmm7
00007c454bbdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007c454bbdf204  ptest xmm15, xmm15
00007c454bbdf20a  jnz 0x00007C454BBE0F9E
00007c454bbdf210  vmovaps xmm15, [rsp+0x50]
00007c454bbdf216  vpermilpd xmm15, xmm15, 0x00
00007c454bbdf21c  vmovaps xmm5, [rsp+0xC0]
00007c454bbdf225  vmovaps [rsp+0xC0], xmm1
00007c454bbdf22e  movaps xmm7, xmm5
00007c454bbdf231  mulpd xmm7, xmm15
00007c454bbdf236  vcmppd xmm1, xmm7, xmm7, 0x03
00007c454bbdf23b  ptest xmm1, xmm1
00007c454bbdf240  jnz 0x00007C454BBE10DE
00007c454bbdf246  lea r12, [rax+0x80]
00007c454bbdf24d  movups xmm1, [r13+r12*1]
00007c454bbdf253  vmovaps xmm5, [rsp+0x70]
00007c454bbdf259  vmovaps [rsp+0x70], xmm1
00007c454bbdf25f  movaps xmm15, xmm5
00007c454bbdf263  addpd xmm15, xmm3
00007c454bbdf268  vcmppd xmm1, xmm15, xmm15, 0x03
00007c454bbdf26e  ptest xmm1, xmm1
00007c454bbdf273  jnz 0x00007C454BBE1229
00007c454bbdf279  vmovaps xmm5, [rsp+0x80]
00007c454bbdf282  movaps xmm1, xmm5
00007c454bbdf285  addpd xmm1, xmm4
00007c454bbdf289  vcmppd xmm3, xmm1, xmm1, 0x03
00007c454bbdf28e  ptest xmm3, xmm3
00007c454bbdf293  jnz 0x00007C454BBE136B
00007c454bbdf299  vmovaps [rsp+0x80], xmm10
00007c454bbdf2a2  vmovaps xmm5, [rsp+0x80]
00007c454bbdf2ab  por xmm10, xmm5
00007c454bbdf2b0  movaps [r15+0x2F0], xmm10
00007c454bbdf2b8  vmovaps xmm5, [rsp+0x50]
00007c454bbdf2be  vpermilpd xmm5, xmm5, 0x00
00007c454bbdf2c4  vmovaps xmm3, [rsp+0x70]
00007c454bbdf2ca  vmovaps [rsp+0x50], xmm1
00007c454bbdf2d0  movaps xmm4, xmm3
00007c454bbdf2d3  mulpd xmm4, xmm5
00007c454bbdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007c454bbdf2dc  ptest xmm1, xmm1
00007c454bbdf2e1  jnz 0x00007C454BBE14AB
00007c454bbdf2e7  lea r12, [rax+0xD0]
00007c454bbdf2ee  movups xmm1, [r13+r12*1]
00007c454bbdf2f4  vmovaps xmm3, [rsp+0xD0]
00007c454bbdf2fd  vmovaps [rsp+0x70], xmm1
00007c454bbdf303  movaps xmm5, xmm6
00007c454bbdf306  addpd xmm5, xmm3
00007c454bbdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007c454bbdf30f  ptest xmm1, xmm1
00007c454bbdf314  jnz 0x00007C454BBE15F5
00007c454bbdf31a  vmovaps xmm1, [rsp+0x60]
00007c454bbdf320  vpermilpd xmm1, xmm1, 0x00
00007c454bbdf326  movaps xmm6, xmm9
00007c454bbdf32a  mulpd xmm6, xmm1
00007c454bbdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007c454bbdf333  ptest xmm3, xmm3
00007c454bbdf338  jnz 0x00007C454BBE1735
00007c454bbdf33e  movaps [r15+0x260], xmm6
00007c454bbdf346  vxorps xmm1, xmm1, xmm1
00007c454bbdf34a  vpbroadcastq xmm1, xmm1
00007c454bbdf34f  movaps [r15+0x1B0], xmm1
00007c454bbdf357  vmovaps xmm1, [rsp+0x60]
00007c454bbdf35d  vpermilpd xmm1, xmm1, 0x00
00007c454bbdf363  vmovaps xmm3, [rsp+0x70]
00007c454bbdf369  vmovaps [rsp+0x70], xmm15
00007c454bbdf36f  movaps xmm9, xmm3
00007c454bbdf373  mulpd xmm9, xmm1
00007c454bbdf378  vcmppd xmm15, xmm9, xmm9, 0x03
00007c454bbdf37e  ptest xmm15, xmm15
00007c454bbdf384  jnz 0x00007C454BBE1876
00007c454bbdf38a  lea r12, [rax+0xC0]
00007c454bbdf391  movups xmm1, [r13+r12*1]
00007c454bbdf397  vmovaps xmm3, [rsp+0xC0]
00007c454bbdf3a0  vmovaps [rsp+0x80], xmm1
00007c454bbdf3a9  movaps xmm15, xmm3
00007c454bbdf3ad  addpd xmm15, xmm7
00007c454bbdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007c454bbdf3b8  ptest xmm1, xmm1
00007c454bbdf3bd  jnz 0x00007C454BBE19C2
00007c454bbdf3c3  vmovaps [rsp+0xC0], xmm13
00007c454bbdf3cc  vmovaps xmm1, [rsp+0xC0]
00007c454bbdf3d5  por xmm13, xmm1
00007c454bbdf3da  movaps [r15+0x270], xmm13
00007c454bbdf3e2  vmovaps xmm1, [rsp+0xB0]
00007c454bbdf3eb  vmovaps xmm7, [rsp+0xB0]
00007c454bbdf3f4  por xmm1, xmm7
00007c454bbdf3f8  movaps [r15+0x1A0], xmm1
00007c454bbdf400  vmovaps xmm1, [rsp+0x60]
00007c454bbdf406  vpermilpd xmm1, xmm1, 0x00
00007c454bbdf40c  vmovaps [rsp+0xB0], xmm1
00007c454bbdf415  vmovaps xmm1, [rsp+0x80]
00007c454bbdf41e  vmovaps [rsp+0x80], xmm15
00007c454bbdf427  vmovaps xmm15, [rsp+0xB0]
00007c454bbdf430  vmovaps [rsp+0xB0], xmm14
00007c454bbdf439  movaps xmm3, xmm1
00007c454bbdf43c  mulpd xmm3, xmm15
00007c454bbdf441  vcmppd xmm14, xmm3, xmm3, 0x03
00007c454bbdf446  ptest xmm14, xmm14
00007c454bbdf44c  jnz 0x00007C454BBE1B04
00007c454bbdf452  lea r12, [rax+0x20]
00007c454bbdf456  movups xmm1, [r13+r12*1]
00007c454bbdf45c  movaps [r15+0x110], xmm1
00007c454bbdf464  vmovaps xmm14, [rsp+0x70]
00007c454bbdf46a  vmovaps [rsp+0x70], xmm1
00007c454bbdf470  movaps xmm15, xmm14
00007c454bbdf474  addpd xmm15, xmm4
00007c454bbdf479  vcmppd xmm1, xmm15, xmm15, 0x03
00007c454bbdf47f  ptest xmm1, xmm1
00007c454bbdf484  jnz 0x00007C454BBE1C4F
00007c454bbdf48a  vmovaps xmm1, [rsp+0x60]
00007c454bbdf490  vpermilpd xmm1, xmm1, 0x00
00007c454bbdf496  movaps xmm14, xmm2
00007c454bbdf49a  mulpd xmm14, xmm1
00007c454bbdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007c454bbdf4a5  ptest xmm4, xmm4
00007c454bbdf4aa  jnz 0x00007C454BBE1D92
00007c454bbdf4b0  vmovaps xmm4, [rsp+0x50]
00007c454bbdf4b6  movaps xmm1, xmm4
00007c454bbdf4b9  addpd xmm1, xmm9
00007c454bbdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007c454bbdf4c3  ptest xmm2, xmm2
00007c454bbdf4c8  jnz 0x00007C454BBE1ED4
00007c454bbdf4ce  vmovaps xmm9, [rsp+0x30]
00007c454bbdf4d4  vpermilpd xmm9, xmm9, 0x00
00007c454bbdf4da  vmovaps xmm2, [rsp+0x70]
00007c454bbdf4e0  vmovaps [rsp+0x50], xmm1
00007c454bbdf4e6  movaps xmm4, xmm2
00007c454bbdf4e9  mulpd xmm4, xmm9
00007c454bbdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007c454bbdf4f3  ptest xmm1, xmm1
00007c454bbdf4f8  jnz 0x00007C454BBE2015
00007c454bbdf4fe  vmovaps xmm1, [rsp+0x30]
00007c454bbdf504  vpermilpd xmm1, xmm1, 0x00
00007c454bbdf50a  vmovaps xmm2, [rsp+0x90]
00007c454bbdf513  vmovaps [rsp+0x60], xmm15
00007c454bbdf519  movaps xmm9, xmm2
00007c454bbdf51d  mulpd xmm9, xmm1
00007c454bbdf522  vcmppd xmm15, xmm9, xmm9, 0x03
00007c454bbdf528  ptest xmm15, xmm15
00007c454bbdf52e  jnz 0x00007C454BBE2156
00007c454bbdf534  vmovaps xmm15, [rsp+0x80]
00007c454bbdf53d  movaps xmm1, xmm15
00007c454bbdf541  addpd xmm1, xmm6
00007c454bbdf545  vcmppd xmm2, xmm1, xmm1, 0x03
00007c454bbdf54a  ptest xmm2, xmm2
00007c454bbdf54f  jnz 0x00007C454BBE2298
00007c454bbdf555  movaps xmm15, xmm5
00007c454bbdf559  addpd xmm15, xmm3
00007c454bbdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007c454bbdf564  ptest xmm6, xmm6
00007c454bbdf569  jnz 0x00007C454BBE23D9
00007c454bbdf56f  vmovaps xmm6, [rsp+0x30]
00007c454bbdf575  vpermilpd xmm6, xmm6, 0x00
00007c454bbdf57b  movaps xmm5, xmm8
00007c454bbdf57f  mulpd xmm5, xmm6
00007c454bbdf583  vcmppd xmm3, xmm5, xmm5, 0x03
00007c454bbdf588  ptest xmm3, xmm3
00007c454bbdf58d  jnz 0x00007C454BBE251B
00007c454bbdf593  vmovaps xmm8, [rsp+0x30]
00007c454bbdf599  vpermilpd xmm8, xmm8, 0x00
00007c454bbdf59f  movaps xmm6, xmm10
00007c454bbdf5a3  mulpd xmm6, xmm8
00007c454bbdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007c454bbdf5ad  ptest xmm3, xmm3
00007c454bbdf5b2  jnz 0x00007C454BBE265C
00007c454bbdf5b8  vmovaps xmm8, [rsp+0x60]
00007c454bbdf5be  movaps xmm10, xmm8
00007c454bbdf5c2  addpd xmm10, xmm14
00007c454bbdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007c454bbdf5cd  ptest xmm3, xmm3
00007c454bbdf5d2  jnz 0x00007C454BBE279E
00007c454bbdf5d8  vmovaps xmm8, [rsp+0x50]
00007c454bbdf5de  movaps xmm14, xmm8
00007c454bbdf5e2  addpd xmm14, xmm4
00007c454bbdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007c454bbdf5ed  ptest xmm3, xmm3
00007c454bbdf5f2  jnz 0x00007C454BBE28E2
00007c454bbdf5f8  vmovaps xmm8, [rsp+0x40]
00007c454bbdf5fe  vpermilpd xmm8, xmm8, 0x00
00007c454bbdf604  movaps xmm4, xmm13
00007c454bbdf608  mulpd xmm4, xmm8
00007c454bbdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007c454bbdf612  ptest xmm3, xmm3
00007c454bbdf617  jnz 0x00007C454BBE2A25
00007c454bbdf61d  movaps xmm13, xmm15
00007c454bbdf621  addpd xmm13, xmm9
00007c454bbdf626  vcmppd xmm8, xmm13, xmm13, 0x03
00007c454bbdf62c  ptest xmm8, xmm8
00007c454bbdf632  jnz 0x00007C454BBE2B67
00007c454bbdf638  movaps xmm15, xmm1
00007c454bbdf63c  addpd xmm15, xmm5
00007c454bbdf641  vcmppd xmm9, xmm15, xmm15, 0x03
00007c454bbdf647  ptest xmm9, xmm9
00007c454bbdf64d  jnz 0x00007C454BBE2CAB
00007c454bbdf653  vmovaps [rsp+0x30], xmm11
00007c454bbdf659  vmovaps xmm1, [rsp+0x30]
00007c454bbdf65f  por xmm11, xmm1
00007c454bbdf664  movaps [r15+0x250], xmm11
00007c454bbdf66c  vmovaps [rsp+0x30], xmm12
00007c454bbdf672  vmovaps xmm1, [rsp+0x30]
00007c454bbdf678  por xmm12, xmm1
00007c454bbdf67d  movaps [r15+0x2A0], xmm12
00007c454bbdf685  vmovaps xmm1, [rsp+0xA0]
00007c454bbdf68e  vmovaps xmm11, [rsp+0xA0]
00007c454bbdf697  por xmm1, xmm11
00007c454bbdf69c  movaps [r15+0x1D0], xmm1
00007c454bbdf6a4  lea r12, [rax+0x40]
00007c454bbdf6a8  movups xmm1, [r13+r12*1]
00007c454bbdf6ae  movaps [r15+0x2C0], xmm1
00007c454bbdf6b6  vmovaps xmm11, [rsp+0x40]
00007c454bbdf6bc  vpermilpd xmm11, xmm11, 0x00
00007c454bbdf6c2  vmovaps xmm8, [rsp+0xE0]
00007c454bbdf6cb  movaps xmm9, xmm8
00007c454bbdf6cf  mulpd xmm9, xmm11
00007c454bbdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007c454bbdf6da  ptest xmm5, xmm5
00007c454bbdf6df  jnz 0x00007C454BBE2DF7
00007c454bbdf6e5  movaps xmm11, xmm10
00007c454bbdf6e9  addpd xmm11, xmm6
00007c454bbdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007c454bbdf6f4  ptest xmm8, xmm8
00007c454bbdf6fa  jnz 0x00007C454BBE2F3B
00007c454bbdf700  movaps xmm10, xmm14
00007c454bbdf704  addpd xmm10, xmm4
00007c454bbdf709  vcmppd xmm8, xmm10, xmm10, 0x03
00007c454bbdf70f  ptest xmm8, xmm8
00007c454bbdf715  jnz 0x00007C454BBE307E
00007c454bbdf71b  vmovaps xmm14, [rsp+0x40]
00007c454bbdf721  vpermilpd xmm14, xmm14, 0x00
00007c454bbdf727  movaps xmm8, xmm1
00007c454bbdf72b  mulpd xmm8, xmm14
00007c454bbdf730  vcmppd xmm6, xmm8, xmm8, 0x03
00007c454bbdf736  ptest xmm6, xmm6
00007c454bbdf73b  jnz 0x00007C454BBE31C1
00007c454bbdf741  movaps xmm1, [r15+0x2B0]
00007c454bbdf749  vmovaps xmm14, [rsp+0x40]
00007c454bbdf74f  vpermilpd xmm14, xmm14, 0x00
00007c454bbdf755  movaps xmm6, xmm1
00007c454bbdf758  mulpd xmm6, xmm14
00007c454bbdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007c454bbdf762  ptest xmm5, xmm5
00007c454bbdf767  jnz 0x00007C454BBE3304
00007c454bbdf76d  vmovaps xmm1, [rsp+0x10]
00007c454bbdf773  vpermilpd xmm1, xmm1, 0x00
00007c454bbdf779  movaps xmm14, xmm12
00007c454bbdf77d  mulpd xmm14, xmm1
00007c454bbdf782  vcmppd xmm5, xmm14, xmm14, 0x03
00007c454bbdf788  ptest xmm5, xmm5
00007c454bbdf78d  jnz 0x00007C454BBE3445
00007c454bbdf793  movaps xmm1, xmm13
00007c454bbdf797  addpd xmm1, xmm9
00007c454bbdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007c454bbdf7a1  ptest xmm12, xmm12
00007c454bbdf7a7  jnz 0x00007C454BBE3588
00007c454bbdf7ad  vmovaps xmm13, [rsp+0x10]
00007c454bbdf7b3  vpermilpd xmm13, xmm13, 0x00
00007c454bbdf7b9  movaps xmm12, xmm7
00007c454bbdf7bd  mulpd xmm12, xmm13
00007c454bbdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007c454bbdf7c8  ptest xmm9, xmm9
00007c454bbdf7ce  jnz 0x00007C454BBE36CA
00007c454bbdf7d4  movaps xmm13, xmm15
00007c454bbdf7d8  addpd xmm13, xmm8
00007c454bbdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007c454bbdf7e3  ptest xmm9, xmm9
00007c454bbdf7e9  jnz 0x00007C454BBE380D
00007c454bbdf7ef  movaps xmm15, [r15+0x290]
00007c454bbdf7f7  vmovaps xmm9, [rsp+0x10]
00007c454bbdf7fd  vpermilpd xmm9, xmm9, 0x00
00007c454bbdf803  movaps xmm8, xmm15
00007c454bbdf807  mulpd xmm8, xmm9
00007c454bbdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007c454bbdf812  ptest xmm7, xmm7
00007c454bbdf817  jnz 0x00007C454BBE3951
00007c454bbdf81d  movaps xmm15, xmm11
00007c454bbdf821  addpd xmm15, xmm6
00007c454bbdf826  vcmppd xmm9, xmm15, xmm15, 0x03
00007c454bbdf82c  ptest xmm9, xmm9
00007c454bbdf832  jnz 0x00007C454BBE3A95
00007c454bbdf838  movaps xmm11, [r15+0x1E0]
00007c454bbdf840  vmovaps xmm9, [rsp+0x10]
00007c454bbdf846  vpermilpd xmm9, xmm9, 0x00
00007c454bbdf84c  movaps xmm7, xmm11
00007c454bbdf850  mulpd xmm7, xmm9
00007c454bbdf855  vcmppd xmm6, xmm7, xmm7, 0x03
00007c454bbdf85a  ptest xmm6, xmm6
00007c454bbdf85f  jnz 0x00007C454BBE3BD8
00007c454bbdf865  movaps xmm11, xmm10
00007c454bbdf869  addpd xmm11, xmm14
00007c454bbdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007c454bbdf874  ptest xmm9, xmm9
00007c454bbdf87a  jnz 0x00007C454BBE3D1A
00007c454bbdf880  lea r12, [rax+0x70]
00007c454bbdf884  movups xmm14, [r13+r12*1]
00007c454bbdf88a  movaps [r15+0x240], xmm14
00007c454bbdf892  movaps xmm10, xmm1
00007c454bbdf896  addpd xmm10, xmm12
00007c454bbdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007c454bbdf8a1  ptest xmm9, xmm9
00007c454bbdf8a7  jnz 0x00007C454BBE3E68
00007c454bbdf8ad  movaps [r15+0x170], xmm10
00007c454bbdf8b5  vmovaps xmm1, [rsp+0x20]
00007c454bbdf8bb  vpermilpd xmm1, xmm1, 0x00
00007c454bbdf8c1  movaps xmm12, xmm14
00007c454bbdf8c5  mulpd xmm12, xmm1
00007c454bbdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007c454bbdf8d0  ptest xmm9, xmm9
00007c454bbdf8d6  jnz 0x00007C454BBE3FAB
00007c454bbdf8dc  vmovaps xmm1, [rsp+0x20]
00007c454bbdf8e2  vpermilpd xmm1, xmm1, 0x00
00007c454bbdf8e8  vmovaps xmm9, [rsp+0xB0]
00007c454bbdf8f1  movaps xmm14, xmm9
00007c454bbdf8f5  mulpd xmm14, xmm1
00007c454bbdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007c454bbdf900  ptest xmm6, xmm6
00007c454bbdf905  jnz 0x00007C454BBE40EE
00007c454bbdf90b  movaps [r15+0x180], xmm14
00007c454bbdf913  movaps xmm1, xmm13
00007c454bbdf917  addpd xmm1, xmm8
00007c454bbdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007c454bbdf921  ptest xmm9, xmm9
00007c454bbdf927  jnz 0x00007C454BBE4231
00007c454bbdf92d  movaps [r15+0x210], xmm1
00007c454bbdf935  movups xmm13, [r13+rax*1]
00007c454bbdf93b  lea r12, [rax+0x10]
00007c454bbdf93f  movups xmm9, [r13+r12*1]
00007c454bbdf945  movaps [r15+0x230], xmm9
00007c454bbdf94d  movaps xmm8, xmm15
00007c454bbdf951  addpd xmm8, xmm7
00007c454bbdf956  vcmppd xmm6, xmm8, xmm8, 0x03
00007c454bbdf95c  ptest xmm6, xmm6
00007c454bbdf961  jnz 0x00007C454BBE4387
00007c454bbdf967  movaps [r15+0x130], xmm8
00007c454bbdf96f  vmovaps xmm15, [rsp+0x20]
00007c454bbdf975  vpermilpd xmm15, xmm15, 0x00
00007c454bbdf97b  movaps xmm7, xmm9
00007c454bbdf97f  mulpd xmm7, xmm15
00007c454bbdf984  vcmppd xmm6, xmm7, xmm7, 0x03
00007c454bbdf989  ptest xmm6, xmm6
00007c454bbdf98e  jnz 0x00007C454BBE44CA
00007c454bbdf994  movaps [r15+0x220], xmm7
00007c454bbdf99c  vmovaps xmm15, [rsp+0x20]
00007c454bbdf9a2  vpermilpd xmm15, xmm15, 0x00
00007c454bbdf9a8  movaps xmm9, xmm13
00007c454bbdf9ac  mulpd xmm9, xmm15
00007c454bbdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007c454bbdf9b7  ptest xmm6, xmm6
00007c454bbdf9bc  jnz 0x00007C454BBE460C
00007c454bbdf9c2  movaps xmm15, xmm11
00007c454bbdf9c6  addpd xmm15, xmm12
00007c454bbdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007c454bbdf9d1  ptest xmm13, xmm13
00007c454bbdf9d7  jnz 0x00007C454BBE4750
00007c454bbdf9dd  movaps [r15+0x140], xmm15
00007c454bbdf9e5  movaps xmm13, xmm10
00007c454bbdf9e9  addpd xmm13, xmm14
00007c454bbdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007c454bbdf9f4  ptest xmm12, xmm12
00007c454bbdf9fa  jnz 0x00007C454BBE4894
00007c454bbdfa00  movaps [r15+0x150], xmm13
00007c454bbdfa08  movaps xmm14, xmm1
00007c454bbdfa0c  addpd xmm14, xmm7
00007c454bbdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007c454bbdfa17  ptest xmm12, xmm12
00007c454bbdfa1d  jnz 0x00007C454BBE49D8
00007c454bbdfa23  movaps [r15+0x160], xmm14
00007c454bbdfa2b  movaps xmm1, xmm8
00007c454bbdfa2f  addpd xmm1, xmm9
00007c454bbdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007c454bbdfa39  ptest xmm12, xmm12
00007c454bbdfa3f  jnz 0x00007C454BBE4B1A
00007c454bbdfa45  movaps [r15+0x120], xmm1
00007c454bbdfa4d  movups [r13+r14*1], xmm15
00007c454bbdfa53  lea rax, [r14+0x10]
00007c454bbdfa57  movups [r13+rax*1], xmm13
00007c454bbdfa5d  lea rax, [r14+0x20]
00007c454bbdfa61  movups [r13+rax*1], xmm14
00007c454bbdfa67  lea rax, [r14+0x30]
00007c454bbdfa6b  movups [r13+rax*1], xmm1
00007c454bbdfa71  mov eax, [r15+0x108]
00007c454bbdfa78  sahf
00007c454bbdfa79  jnz 0x00007C454BBDFAAB
00007c454bbdfa7b  cmp dword ptr [r15+0x318], 0x00
00007c454bbdfa83  jz 0x00007C454BBDEAE0
00007c454bbdfa89  nop [rax+rax*1], ax
00007c454bbdfa92  nop [rax+rax*1], eax
00007c454bbdfa9a  mov eax, 0x4106D0
00007c454bbdfa9f  mov [r15+0x100], rax
00007c454bbdfaa6  jmp 0x00007C454B9FE110
00007c454bbdfaab  cmp dword ptr [r15+0x318], 0x00
00007c454bbdfab3  jz 0x00007C454BBD89C0
00007c454bbdfab9  nop [rax+rax*1], ax
00007c454bbdfac2  nop [rax+rax*1], eax
00007c454bbdfaca  mov eax, 0x410504
00007c454bbdfacf  mov [r15+0x100], rax
00007c454bbdfad6  jmp 0x00007C454B9FE110
00007c454bbdfadb  int3
00007c454bbdfadc  call 0x00007C454BAE27E0
00007c454bbdfae1  jmp 0x00007C454BBDEBBF
00007c454bbdfae6  call 0x00007C454BAE1570
00007c454bbdfaeb  jmp 0x00007C454BBDEBC8
00007c454bbdfaf0  call 0x00007C454BAE27E0
00007c454bbdfaf5  jmp 0x00007C454BBDEC24
00007c454bbdfafa  call 0x00007C454BAE1570
00007c454bbdfaff  jmp 0x00007C454BBDEC2D
00007c454bbdfb04  call 0x00007C454BAE27E0
00007c454bbdfb09  jmp 0x00007C454BBDEC70
00007c454bbdfb0e  call 0x00007C454BAE1570
00007c454bbdfb13  jmp 0x00007C454BBDEC79
00007c454bbdfb18  call 0x00007C454BA0DC20
00007c454bbdfb1d  jmp 0x00007C454BBDECB8
00007c454bbdfb22  call 0x00007C454BAD59C0
00007c454bbdfb27  jmp 0x00007C454BBDECCB
00007c454bbdfb2c  call 0x00007C454BAE0E30
00007c454bbdfb31  jmp 0x00007C454BBDECE9
00007c454bbdfb36  call 0x00007C454BADFBC0
00007c454bbdfb3b  jmp 0x00007C454BBDECF3
00007c454bbdfb40  call 0x00007C454BADE950
00007c454bbdfb45  jmp 0x00007C454BBDECFD
00007c454bbdfb4a  sub rsp, 0x08
00007c454bbdfb4e  push rax
00007c454bbdfb4f  push rcx
00007c454bbdfb50  push rdx
00007c454bbdfb51  push rdi
00007c454bbdfb52  push rsi
00007c454bbdfb53  push r8
00007c454bbdfb55  push r9
00007c454bbdfb57  push r10
00007c454bbdfb59  push r11
00007c454bbdfb5b  sub rsp, 0xF0
00007c454bbdfb62  vmovaps [rsp], xmm0
00007c454bbdfb67  vmovaps [rsp+0x10], xmm1
00007c454bbdfb6d  vmovaps [rsp+0x20], xmm2
00007c454bbdfb73  vmovaps [rsp+0x30], xmm3
00007c454bbdfb79  vmovaps [rsp+0x40], xmm4
00007c454bbdfb7f  vmovaps [rsp+0x50], xmm5
00007c454bbdfb85  vmovaps [rsp+0x60], xmm6
00007c454bbdfb8b  vmovaps [rsp+0x70], xmm7
00007c454bbdfb91  vmovaps [rsp+0x80], xmm9
00007c454bbdfb9a  vmovaps [rsp+0x90], xmm10
00007c454bbdfba3  vmovaps [rsp+0xA0], xmm11
00007c454bbdfbac  vmovaps [rsp+0xB0], xmm12
00007c454bbdfbb5  vmovaps [rsp+0xC0], xmm13
00007c454bbdfbbe  vmovaps [rsp+0xD0], xmm14
00007c454bbdfbc7  vmovaps [rsp+0xE0], xmm15
00007c454bbdfbd0  sub rsp, 0x30
00007c454bbdfbd4  movaps [rsp], xmm8
00007c454bbdfbd9  movaps [rsp+0x10], xmm12
00007c454bbdfbdf  movaps [rsp+0x20], xmm15
00007c454bbdfbe5  lea rdi, [rsp]
00007c454bbdfbe9  mov esi, 0x00
00007c454bbdfbee  mov rax, 0x56A18AC54530
00007c454bbdfbf8  call rax
00007c454bbdfbfa  movaps xmm8, [rsp]
00007c454bbdfbff  add rsp, 0x30
00007c454bbdfc03  vmovaps xmm0, [rsp]
00007c454bbdfc08  vmovaps xmm1, [rsp+0x10]
00007c454bbdfc0e  vmovaps xmm2, [rsp+0x20]
00007c454bbdfc14  vmovaps xmm3, [rsp+0x30]
00007c454bbdfc1a  vmovaps xmm4, [rsp+0x40]
00007c454bbdfc20  vmovaps xmm5, [rsp+0x50]
00007c454bbdfc26  vmovaps xmm6, [rsp+0x60]
00007c454bbdfc2c  vmovaps xmm7, [rsp+0x70]
00007c454bbdfc32  vmovaps xmm9, [rsp+0x80]
00007c454bbdfc3b  vmovaps xmm10, [rsp+0x90]
00007c454bbdfc44  vmovaps xmm11, [rsp+0xA0]
00007c454bbdfc4d  vmovaps xmm12, [rsp+0xB0]
00007c454bbdfc56  vmovaps xmm13, [rsp+0xC0]
00007c454bbdfc5f  vmovaps xmm14, [rsp+0xD0]
00007c454bbdfc68  vmovaps xmm15, [rsp+0xE0]
00007c454bbdfc71  add rsp, 0xF0
00007c454bbdfc78  pop r11
00007c454bbdfc7a  pop r10
00007c454bbdfc7c  pop r9
00007c454bbdfc7e  pop r8
00007c454bbdfc80  pop rsi
00007c454bbdfc81  pop rdi
00007c454bbdfc82  pop rdx
00007c454bbdfc83  pop rcx
00007c454bbdfc84  pop rax
00007c454bbdfc85  add rsp, 0x08
00007c454bbdfc89  jmp 0x00007C454BBDED27
00007c454bbdfc8e  sub rsp, 0x08
00007c454bbdfc92  push rax
00007c454bbdfc93  push rcx
00007c454bbdfc94  push rdx
00007c454bbdfc95  push rdi
00007c454bbdfc96  push rsi
00007c454bbdfc97  push r8
00007c454bbdfc99  push r9
00007c454bbdfc9b  push r10
00007c454bbdfc9d  push r11
00007c454bbdfc9f  sub rsp, 0xF0
00007c454bbdfca6  vmovaps [rsp], xmm0
00007c454bbdfcab  vmovaps [rsp+0x10], xmm1
00007c454bbdfcb1  vmovaps [rsp+0x20], xmm2
00007c454bbdfcb7  vmovaps [rsp+0x30], xmm3
00007c454bbdfcbd  vmovaps [rsp+0x40], xmm4
00007c454bbdfcc3  vmovaps [rsp+0x50], xmm5
00007c454bbdfcc9  vmovaps [rsp+0x60], xmm6
00007c454bbdfccf  vmovaps [rsp+0x70], xmm8
00007c454bbdfcd5  vmovaps [rsp+0x80], xmm9
00007c454bbdfcde  vmovaps [rsp+0x90], xmm10
00007c454bbdfce7  vmovaps [rsp+0xA0], xmm11
00007c454bbdfcf0  vmovaps [rsp+0xB0], xmm12
00007c454bbdfcf9  vmovaps [rsp+0xC0], xmm13
00007c454bbdfd02  vmovaps [rsp+0xD0], xmm14
00007c454bbdfd0b  vmovaps [rsp+0xE0], xmm15
00007c454bbdfd14  sub rsp, 0x30
00007c454bbdfd18  movaps [rsp], xmm7
00007c454bbdfd1c  movaps [rsp+0x10], xmm9
00007c454bbdfd22  movaps [rsp+0x20], xmm15
00007c454bbdfd28  lea rdi, [rsp]
00007c454bbdfd2c  mov esi, 0x00
00007c454bbdfd31  mov rax, 0x56A18AC54530
00007c454bbdfd3b  call rax
00007c454bbdfd3d  movaps xmm7, [rsp]
00007c454bbdfd41  add rsp, 0x30
00007c454bbdfd45  vmovaps xmm0, [rsp]
00007c454bbdfd4a  vmovaps xmm1, [rsp+0x10]
00007c454bbdfd50  vmovaps xmm2, [rsp+0x20]
00007c454bbdfd56  vmovaps xmm3, [rsp+0x30]
00007c454bbdfd5c  vmovaps xmm4, [rsp+0x40]
00007c454bbdfd62  vmovaps xmm5, [rsp+0x50]
00007c454bbdfd68  vmovaps xmm6, [rsp+0x60]
00007c454bbdfd6e  vmovaps xmm8, [rsp+0x70]
00007c454bbdfd74  vmovaps xmm9, [rsp+0x80]
00007c454bbdfd7d  vmovaps xmm10, [rsp+0x90]
00007c454bbdfd86  vmovaps xmm11, [rsp+0xA0]
00007c454bbdfd8f  vmovaps xmm12, [rsp+0xB0]
00007c454bbdfd98  vmovaps xmm13, [rsp+0xC0]
00007c454bbdfda1  vmovaps xmm14, [rsp+0xD0]
00007c454bbdfdaa  vmovaps xmm15, [rsp+0xE0]
00007c454bbdfdb3  add rsp, 0xF0
00007c454bbdfdba  pop r11
00007c454bbdfdbc  pop r10
00007c454bbdfdbe  pop r9
00007c454bbdfdc0  pop r8
00007c454bbdfdc2  pop rsi
00007c454bbdfdc3  pop rdi
00007c454bbdfdc4  pop rdx
00007c454bbdfdc5  pop rcx
00007c454bbdfdc6  pop rax
00007c454bbdfdc7  add rsp, 0x08
00007c454bbdfdcb  jmp 0x00007C454BBDED55
00007c454bbdfdd0  sub rsp, 0x08
00007c454bbdfdd4  push rax
00007c454bbdfdd5  push rcx
00007c454bbdfdd6  push rdx
00007c454bbdfdd7  push rdi
00007c454bbdfdd8  push rsi
00007c454bbdfdd9  push r8
00007c454bbdfddb  push r9
00007c454bbdfddd  push r10
00007c454bbdfddf  push r11
00007c454bbdfde1  sub rsp, 0xF0
00007c454bbdfde8  vmovaps [rsp], xmm0
00007c454bbdfded  vmovaps [rsp+0x10], xmm1
00007c454bbdfdf3  vmovaps [rsp+0x20], xmm2
00007c454bbdfdf9  vmovaps [rsp+0x30], xmm3
00007c454bbdfdff  vmovaps [rsp+0x40], xmm4
00007c454bbdfe05  vmovaps [rsp+0x50], xmm5
00007c454bbdfe0b  vmovaps [rsp+0x60], xmm6
00007c454bbdfe11  vmovaps [rsp+0x70], xmm7
00007c454bbdfe17  vmovaps [rsp+0x80], xmm8
00007c454bbdfe20  vmovaps [rsp+0x90], xmm10
00007c454bbdfe29  vmovaps [rsp+0xA0], xmm11
00007c454bbdfe32  vmovaps [rsp+0xB0], xmm12
00007c454bbdfe3b  vmovaps [rsp+0xC0], xmm13
00007c454bbdfe44  vmovaps [rsp+0xD0], xmm14
00007c454bbdfe4d  vmovaps [rsp+0xE0], xmm15
00007c454bbdfe56  sub rsp, 0x30
00007c454bbdfe5a  movaps [rsp], xmm9
00007c454bbdfe5f  movaps [rsp+0x10], xmm12
00007c454bbdfe65  movaps [rsp+0x20], xmm10
00007c454bbdfe6b  lea rdi, [rsp]
00007c454bbdfe6f  mov esi, 0x00
00007c454bbdfe74  mov rax, 0x56A18AC54530
00007c454bbdfe7e  call rax
00007c454bbdfe80  movaps xmm9, [rsp]
00007c454bbdfe85  add rsp, 0x30
00007c454bbdfe89  vmovaps xmm0, [rsp]
00007c454bbdfe8e  vmovaps xmm1, [rsp+0x10]
00007c454bbdfe94  vmovaps xmm2, [rsp+0x20]
00007c454bbdfe9a  vmovaps xmm3, [rsp+0x30]
00007c454bbdfea0  vmovaps xmm4, [rsp+0x40]
00007c454bbdfea6  vmovaps xmm5, [rsp+0x50]
00007c454bbdfeac  vmovaps xmm6, [rsp+0x60]
00007c454bbdfeb2  vmovaps xmm7, [rsp+0x70]
00007c454bbdfeb8  vmovaps xmm8, [rsp+0x80]
00007c454bbdfec1  vmovaps xmm10, [rsp+0x90]
00007c454bbdfeca  vmovaps xmm11, [rsp+0xA0]
00007c454bbdfed3  vmovaps xmm12, [rsp+0xB0]
00007c454bbdfedc  vmovaps xmm13, [rsp+0xC0]
00007c454bbdfee5  vmovaps xmm14, [rsp+0xD0]
00007c454bbdfeee  vmovaps xmm15, [rsp+0xE0]
00007c454bbdfef7  add rsp, 0xF0
00007c454bbdfefe  pop r11
00007c454bbdff00  pop r10
00007c454bbdff02  pop r9
00007c454bbdff04  pop r8
00007c454bbdff06  pop rsi
00007c454bbdff07  pop rdi
00007c454bbdff08  pop rdx
00007c454bbdff09  pop rcx
00007c454bbdff0a  pop rax
00007c454bbdff0b  add rsp, 0x08
00007c454bbdff0f  jmp 0x00007C454BBDED79
00007c454bbdff14  sub rsp, 0x08
00007c454bbdff18  push rax
00007c454bbdff19  push rcx
00007c454bbdff1a  push rdx
00007c454bbdff1b  push rdi
00007c454bbdff1c  push rsi
00007c454bbdff1d  push r8
00007c454bbdff1f  push r9
00007c454bbdff21  push r10
00007c454bbdff23  push r11
00007c454bbdff25  sub rsp, 0xF0
00007c454bbdff2c  vmovaps [rsp], xmm0
00007c454bbdff31  vmovaps [rsp+0x10], xmm1
00007c454bbdff37  vmovaps [rsp+0x20], xmm2
00007c454bbdff3d  vmovaps [rsp+0x30], xmm3
00007c454bbdff43  vmovaps [rsp+0x40], xmm4
00007c454bbdff49  vmovaps [rsp+0x50], xmm5
00007c454bbdff4f  vmovaps [rsp+0x60], xmm6
00007c454bbdff55  vmovaps [rsp+0x70], xmm7
00007c454bbdff5b  vmovaps [rsp+0x80], xmm8
00007c454bbdff64  vmovaps [rsp+0x90], xmm9
00007c454bbdff6d  vmovaps [rsp+0xA0], xmm11
00007c454bbdff76  vmovaps [rsp+0xB0], xmm12
00007c454bbdff7f  vmovaps [rsp+0xC0], xmm13
00007c454bbdff88  vmovaps [rsp+0xD0], xmm14
00007c454bbdff91  vmovaps [rsp+0xE0], xmm15
00007c454bbdff9a  sub rsp, 0x30
00007c454bbdff9e  movaps [rsp], xmm10
00007c454bbdffa3  movaps [rsp+0x10], xmm12
00007c454bbdffa9  movaps [rsp+0x20], xmm11
00007c454bbdffaf  lea rdi, [rsp]
00007c454bbdffb3  mov esi, 0x00
00007c454bbdffb8  mov rax, 0x56A18AC54530
00007c454bbdffc2  call rax
00007c454bbdffc4  movaps xmm10, [rsp]
00007c454bbdffc9  add rsp, 0x30
00007c454bbdffcd  vmovaps xmm0, [rsp]
00007c454bbdffd2  vmovaps xmm1, [rsp+0x10]
00007c454bbdffd8  vmovaps xmm2, [rsp+0x20]
00007c454bbdffde  vmovaps xmm3, [rsp+0x30]
00007c454bbdffe4  vmovaps xmm4, [rsp+0x40]
00007c454bbdffea  vmovaps xmm5, [rsp+0x50]
00007c454bbdfff0  vmovaps xmm6, [rsp+0x60]
00007c454bbdfff6  vmovaps xmm7, [rsp+0x70]
00007c454bbdfffc  vmovaps xmm8, [rsp+0x80]
00007c454bbe0005  vmovaps xmm9, [rsp+0x90]
00007c454bbe000e  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0017  vmovaps xmm12, [rsp+0xB0]
00007c454bbe0020  vmovaps xmm13, [rsp+0xC0]
00007c454bbe0029  vmovaps xmm14, [rsp+0xD0]
00007c454bbe0032  vmovaps xmm15, [rsp+0xE0]
00007c454bbe003b  add rsp, 0xF0
00007c454bbe0042  pop r11
00007c454bbe0044  pop r10
00007c454bbe0046  pop r9
00007c454bbe0048  pop r8
00007c454bbe004a  pop rsi
00007c454bbe004b  pop rdi
00007c454bbe004c  pop rdx
00007c454bbe004d  pop rcx
00007c454bbe004e  pop rax
00007c454bbe004f  add rsp, 0x08
00007c454bbe0053  jmp 0x00007C454BBDED93
00007c454bbe0058  sub rsp, 0x08
00007c454bbe005c  push rax
00007c454bbe005d  push rcx
00007c454bbe005e  push rdx
00007c454bbe005f  push rdi
00007c454bbe0060  push rsi
00007c454bbe0061  push r8
00007c454bbe0063  push r9
00007c454bbe0065  push r10
00007c454bbe0067  push r11
00007c454bbe0069  sub rsp, 0xF0
00007c454bbe0070  vmovaps [rsp], xmm0
00007c454bbe0075  vmovaps [rsp+0x10], xmm1
00007c454bbe007b  vmovaps [rsp+0x20], xmm2
00007c454bbe0081  vmovaps [rsp+0x30], xmm3
00007c454bbe0087  vmovaps [rsp+0x40], xmm4
00007c454bbe008d  vmovaps [rsp+0x50], xmm5
00007c454bbe0093  vmovaps [rsp+0x60], xmm7
00007c454bbe0099  vmovaps [rsp+0x70], xmm8
00007c454bbe009f  vmovaps [rsp+0x80], xmm9
00007c454bbe00a8  vmovaps [rsp+0x90], xmm10
00007c454bbe00b1  vmovaps [rsp+0xA0], xmm11
00007c454bbe00ba  vmovaps [rsp+0xB0], xmm12
00007c454bbe00c3  vmovaps [rsp+0xC0], xmm13
00007c454bbe00cc  vmovaps [rsp+0xD0], xmm14
00007c454bbe00d5  vmovaps [rsp+0xE0], xmm15
00007c454bbe00de  sub rsp, 0x30
00007c454bbe00e2  movaps [rsp], xmm6
00007c454bbe00e6  movaps [rsp+0x10], xmm12
00007c454bbe00ec  movaps [rsp+0x20], xmm11
00007c454bbe00f2  lea rdi, [rsp]
00007c454bbe00f6  mov esi, 0x00
00007c454bbe00fb  mov rax, 0x56A18AC54530
00007c454bbe0105  call rax
00007c454bbe0107  movaps xmm6, [rsp]
00007c454bbe010b  add rsp, 0x30
00007c454bbe010f  vmovaps xmm0, [rsp]
00007c454bbe0114  vmovaps xmm1, [rsp+0x10]
00007c454bbe011a  vmovaps xmm2, [rsp+0x20]
00007c454bbe0120  vmovaps xmm3, [rsp+0x30]
00007c454bbe0126  vmovaps xmm4, [rsp+0x40]
00007c454bbe012c  vmovaps xmm5, [rsp+0x50]
00007c454bbe0132  vmovaps xmm7, [rsp+0x60]
00007c454bbe0138  vmovaps xmm8, [rsp+0x70]
00007c454bbe013e  vmovaps xmm9, [rsp+0x80]
00007c454bbe0147  vmovaps xmm10, [rsp+0x90]
00007c454bbe0150  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0159  vmovaps xmm12, [rsp+0xB0]
00007c454bbe0162  vmovaps xmm13, [rsp+0xC0]
00007c454bbe016b  vmovaps xmm14, [rsp+0xD0]
00007c454bbe0174  vmovaps xmm15, [rsp+0xE0]
00007c454bbe017d  add rsp, 0xF0
00007c454bbe0184  pop r11
00007c454bbe0186  pop r10
00007c454bbe0188  pop r9
00007c454bbe018a  pop r8
00007c454bbe018c  pop rsi
00007c454bbe018d  pop rdi
00007c454bbe018e  pop rdx
00007c454bbe018f  pop rcx
00007c454bbe0190  pop rax
00007c454bbe0191  add rsp, 0x08
00007c454bbe0195  jmp 0x00007C454BBDEDB4
00007c454bbe019a  sub rsp, 0x08
00007c454bbe019e  push rax
00007c454bbe019f  push rcx
00007c454bbe01a0  push rdx
00007c454bbe01a1  push rdi
00007c454bbe01a2  push rsi
00007c454bbe01a3  push r8
00007c454bbe01a5  push r9
00007c454bbe01a7  push r10
00007c454bbe01a9  push r11
00007c454bbe01ab  sub rsp, 0xF0
00007c454bbe01b2  vmovaps [rsp], xmm0
00007c454bbe01b7  vmovaps [rsp+0x10], xmm1
00007c454bbe01bd  vmovaps [rsp+0x20], xmm2
00007c454bbe01c3  vmovaps [rsp+0x30], xmm4
00007c454bbe01c9  vmovaps [rsp+0x40], xmm5
00007c454bbe01cf  vmovaps [rsp+0x50], xmm6
00007c454bbe01d5  vmovaps [rsp+0x60], xmm7
00007c454bbe01db  vmovaps [rsp+0x70], xmm8
00007c454bbe01e1  vmovaps [rsp+0x80], xmm9
00007c454bbe01ea  vmovaps [rsp+0x90], xmm10
00007c454bbe01f3  vmovaps [rsp+0xA0], xmm11
00007c454bbe01fc  vmovaps [rsp+0xB0], xmm12
00007c454bbe0205  vmovaps [rsp+0xC0], xmm13
00007c454bbe020e  vmovaps [rsp+0xD0], xmm14
00007c454bbe0217  vmovaps [rsp+0xE0], xmm15
00007c454bbe0220  sub rsp, 0x30
00007c454bbe0224  movaps [rsp], xmm3
00007c454bbe0228  movaps [rsp+0x10], xmm5
00007c454bbe022d  movaps [rsp+0x20], xmm4
00007c454bbe0232  lea rdi, [rsp]
00007c454bbe0236  mov esi, 0x00
00007c454bbe023b  mov rax, 0x56A18AC54530
00007c454bbe0245  call rax
00007c454bbe0247  movaps xmm3, [rsp]
00007c454bbe024b  add rsp, 0x30
00007c454bbe024f  vmovaps xmm0, [rsp]
00007c454bbe0254  vmovaps xmm1, [rsp+0x10]
00007c454bbe025a  vmovaps xmm2, [rsp+0x20]
00007c454bbe0260  vmovaps xmm4, [rsp+0x30]
00007c454bbe0266  vmovaps xmm5, [rsp+0x40]
00007c454bbe026c  vmovaps xmm6, [rsp+0x50]
00007c454bbe0272  vmovaps xmm7, [rsp+0x60]
00007c454bbe0278  vmovaps xmm8, [rsp+0x70]
00007c454bbe027e  vmovaps xmm9, [rsp+0x80]
00007c454bbe0287  vmovaps xmm10, [rsp+0x90]
00007c454bbe0290  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0299  vmovaps xmm12, [rsp+0xB0]
00007c454bbe02a2  vmovaps xmm13, [rsp+0xC0]
00007c454bbe02ab  vmovaps xmm14, [rsp+0xD0]
00007c454bbe02b4  vmovaps xmm15, [rsp+0xE0]
00007c454bbe02bd  add rsp, 0xF0
00007c454bbe02c4  pop r11
00007c454bbe02c6  pop r10
00007c454bbe02c8  pop r9
00007c454bbe02ca  pop r8
00007c454bbe02cc  pop rsi
00007c454bbe02cd  pop rdi
00007c454bbe02ce  pop rdx
00007c454bbe02cf  pop rcx
00007c454bbe02d0  pop rax
00007c454bbe02d1  add rsp, 0x08
00007c454bbe02d5  jmp 0x00007C454BBDEE15
00007c454bbe02da  sub rsp, 0x08
00007c454bbe02de  push rax
00007c454bbe02df  push rcx
00007c454bbe02e0  push rdx
00007c454bbe02e1  push rdi
00007c454bbe02e2  push rsi
00007c454bbe02e3  push r8
00007c454bbe02e5  push r9
00007c454bbe02e7  push r10
00007c454bbe02e9  push r11
00007c454bbe02eb  sub rsp, 0xF0
00007c454bbe02f2  vmovaps [rsp], xmm0
00007c454bbe02f7  vmovaps [rsp+0x10], xmm1
00007c454bbe02fd  vmovaps [rsp+0x20], xmm2
00007c454bbe0303  vmovaps [rsp+0x30], xmm3
00007c454bbe0309  vmovaps [rsp+0x40], xmm4
00007c454bbe030f  vmovaps [rsp+0x50], xmm6
00007c454bbe0315  vmovaps [rsp+0x60], xmm7
00007c454bbe031b  vmovaps [rsp+0x70], xmm8
00007c454bbe0321  vmovaps [rsp+0x80], xmm9
00007c454bbe032a  vmovaps [rsp+0x90], xmm10
00007c454bbe0333  vmovaps [rsp+0xA0], xmm11
00007c454bbe033c  vmovaps [rsp+0xB0], xmm12
00007c454bbe0345  vmovaps [rsp+0xC0], xmm13
00007c454bbe034e  vmovaps [rsp+0xD0], xmm14
00007c454bbe0357  vmovaps [rsp+0xE0], xmm15
00007c454bbe0360  sub rsp, 0x30
00007c454bbe0364  movaps [rsp], xmm5
00007c454bbe0368  movaps [rsp+0x10], xmm8
00007c454bbe036e  movaps [rsp+0x20], xmm15
00007c454bbe0374  lea rdi, [rsp]
00007c454bbe0378  mov esi, 0x00
00007c454bbe037d  mov rax, 0x56A18AC54530
00007c454bbe0387  call rax
00007c454bbe0389  movaps xmm5, [rsp]
00007c454bbe038d  add rsp, 0x30
00007c454bbe0391  vmovaps xmm0, [rsp]
00007c454bbe0396  vmovaps xmm1, [rsp+0x10]
00007c454bbe039c  vmovaps xmm2, [rsp+0x20]
00007c454bbe03a2  vmovaps xmm3, [rsp+0x30]
00007c454bbe03a8  vmovaps xmm4, [rsp+0x40]
00007c454bbe03ae  vmovaps xmm6, [rsp+0x50]
00007c454bbe03b4  vmovaps xmm7, [rsp+0x60]
00007c454bbe03ba  vmovaps xmm8, [rsp+0x70]
00007c454bbe03c0  vmovaps xmm9, [rsp+0x80]
00007c454bbe03c9  vmovaps xmm10, [rsp+0x90]
00007c454bbe03d2  vmovaps xmm11, [rsp+0xA0]
00007c454bbe03db  vmovaps xmm12, [rsp+0xB0]
00007c454bbe03e4  vmovaps xmm13, [rsp+0xC0]
00007c454bbe03ed  vmovaps xmm14, [rsp+0xD0]
00007c454bbe03f6  vmovaps xmm15, [rsp+0xE0]
00007c454bbe03ff  add rsp, 0xF0
00007c454bbe0406  pop r11
00007c454bbe0408  pop r10
00007c454bbe040a  pop r9
00007c454bbe040c  pop r8
00007c454bbe040e  pop rsi
00007c454bbe040f  pop rdi
00007c454bbe0410  pop rdx
00007c454bbe0411  pop rcx
00007c454bbe0412  pop rax
00007c454bbe0413  add rsp, 0x08
00007c454bbe0417  jmp 0x00007C454BBDEE53
00007c454bbe041c  sub rsp, 0x08
00007c454bbe0420  push rax
00007c454bbe0421  push rcx
00007c454bbe0422  push rdx
00007c454bbe0423  push rdi
00007c454bbe0424  push rsi
00007c454bbe0425  push r8
00007c454bbe0427  push r9
00007c454bbe0429  push r10
00007c454bbe042b  push r11
00007c454bbe042d  sub rsp, 0xF0
00007c454bbe0434  vmovaps [rsp], xmm0
00007c454bbe0439  vmovaps [rsp+0x10], xmm1
00007c454bbe043f  vmovaps [rsp+0x20], xmm2
00007c454bbe0445  vmovaps [rsp+0x30], xmm3
00007c454bbe044b  vmovaps [rsp+0x40], xmm5
00007c454bbe0451  vmovaps [rsp+0x50], xmm6
00007c454bbe0457  vmovaps [rsp+0x60], xmm7
00007c454bbe045d  vmovaps [rsp+0x70], xmm8
00007c454bbe0463  vmovaps [rsp+0x80], xmm9
00007c454bbe046c  vmovaps [rsp+0x90], xmm10
00007c454bbe0475  vmovaps [rsp+0xA0], xmm11
00007c454bbe047e  vmovaps [rsp+0xB0], xmm12
00007c454bbe0487  vmovaps [rsp+0xC0], xmm13
00007c454bbe0490  vmovaps [rsp+0xD0], xmm14
00007c454bbe0499  vmovaps [rsp+0xE0], xmm15
00007c454bbe04a2  sub rsp, 0x30
00007c454bbe04a6  movaps [rsp], xmm4
00007c454bbe04aa  movaps [rsp+0x10], xmm9
00007c454bbe04b0  movaps [rsp+0x20], xmm8
00007c454bbe04b6  lea rdi, [rsp]
00007c454bbe04ba  mov esi, 0x00
00007c454bbe04bf  mov rax, 0x56A18AC54530
00007c454bbe04c9  call rax
00007c454bbe04cb  movaps xmm4, [rsp]
00007c454bbe04cf  add rsp, 0x30
00007c454bbe04d3  vmovaps xmm0, [rsp]
00007c454bbe04d8  vmovaps xmm1, [rsp+0x10]
00007c454bbe04de  vmovaps xmm2, [rsp+0x20]
00007c454bbe04e4  vmovaps xmm3, [rsp+0x30]
00007c454bbe04ea  vmovaps xmm5, [rsp+0x40]
00007c454bbe04f0  vmovaps xmm6, [rsp+0x50]
00007c454bbe04f6  vmovaps xmm7, [rsp+0x60]
00007c454bbe04fc  vmovaps xmm8, [rsp+0x70]
00007c454bbe0502  vmovaps xmm9, [rsp+0x80]
00007c454bbe050b  vmovaps xmm10, [rsp+0x90]
00007c454bbe0514  vmovaps xmm11, [rsp+0xA0]
00007c454bbe051d  vmovaps xmm12, [rsp+0xB0]
00007c454bbe0526  vmovaps xmm13, [rsp+0xC0]
00007c454bbe052f  vmovaps xmm14, [rsp+0xD0]
00007c454bbe0538  vmovaps xmm15, [rsp+0xE0]
00007c454bbe0541  add rsp, 0xF0
00007c454bbe0548  pop r11
00007c454bbe054a  pop r10
00007c454bbe054c  pop r9
00007c454bbe054e  pop r8
00007c454bbe0550  pop rsi
00007c454bbe0551  pop rdi
00007c454bbe0552  pop rdx
00007c454bbe0553  pop rcx
00007c454bbe0554  pop rax
00007c454bbe0555  add rsp, 0x08
00007c454bbe0559  jmp 0x00007C454BBDEE74
00007c454bbe055e  sub rsp, 0x08
00007c454bbe0562  push rax
00007c454bbe0563  push rcx
00007c454bbe0564  push rdx
00007c454bbe0565  push rdi
00007c454bbe0566  push rsi
00007c454bbe0567  push r8
00007c454bbe0569  push r9
00007c454bbe056b  push r10
00007c454bbe056d  push r11
00007c454bbe056f  sub rsp, 0xF0
00007c454bbe0576  vmovaps [rsp], xmm0
00007c454bbe057b  vmovaps [rsp+0x10], xmm1
00007c454bbe0581  vmovaps [rsp+0x20], xmm2
00007c454bbe0587  vmovaps [rsp+0x30], xmm3
00007c454bbe058d  vmovaps [rsp+0x40], xmm4
00007c454bbe0593  vmovaps [rsp+0x50], xmm5
00007c454bbe0599  vmovaps [rsp+0x60], xmm6
00007c454bbe059f  vmovaps [rsp+0x70], xmm7
00007c454bbe05a5  vmovaps [rsp+0x80], xmm8
00007c454bbe05ae  vmovaps [rsp+0x90], xmm10
00007c454bbe05b7  vmovaps [rsp+0xA0], xmm11
00007c454bbe05c0  vmovaps [rsp+0xB0], xmm12
00007c454bbe05c9  vmovaps [rsp+0xC0], xmm13
00007c454bbe05d2  vmovaps [rsp+0xD0], xmm14
00007c454bbe05db  vmovaps [rsp+0xE0], xmm15
00007c454bbe05e4  sub rsp, 0x30
00007c454bbe05e8  movaps [rsp], xmm9
00007c454bbe05ed  movaps [rsp+0x10], xmm10
00007c454bbe05f3  movaps [rsp+0x20], xmm8
00007c454bbe05f9  lea rdi, [rsp]
00007c454bbe05fd  mov esi, 0x00
00007c454bbe0602  mov rax, 0x56A18AC54530
00007c454bbe060c  call rax
00007c454bbe060e  movaps xmm9, [rsp]
00007c454bbe0613  add rsp, 0x30
00007c454bbe0617  vmovaps xmm0, [rsp]
00007c454bbe061c  vmovaps xmm1, [rsp+0x10]
00007c454bbe0622  vmovaps xmm2, [rsp+0x20]
00007c454bbe0628  vmovaps xmm3, [rsp+0x30]
00007c454bbe062e  vmovaps xmm4, [rsp+0x40]
00007c454bbe0634  vmovaps xmm5, [rsp+0x50]
00007c454bbe063a  vmovaps xmm6, [rsp+0x60]
00007c454bbe0640  vmovaps xmm7, [rsp+0x70]
00007c454bbe0646  vmovaps xmm8, [rsp+0x80]
00007c454bbe064f  vmovaps xmm10, [rsp+0x90]
00007c454bbe0658  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0661  vmovaps xmm12, [rsp+0xB0]
00007c454bbe066a  vmovaps xmm13, [rsp+0xC0]
00007c454bbe0673  vmovaps xmm14, [rsp+0xD0]
00007c454bbe067c  vmovaps xmm15, [rsp+0xE0]
00007c454bbe0685  add rsp, 0xF0
00007c454bbe068c  pop r11
00007c454bbe068e  pop r10
00007c454bbe0690  pop r9
00007c454bbe0692  pop r8
00007c454bbe0694  pop rsi
00007c454bbe0695  pop rdi
00007c454bbe0696  pop rdx
00007c454bbe0697  pop rcx
00007c454bbe0698  pop rax
00007c454bbe0699  add rsp, 0x08
00007c454bbe069d  jmp 0x00007C454BBDEE8E
00007c454bbe06a2  call 0x00007C454BAB52F0
00007c454bbe06a7  jmp 0x00007C454BBDEFA8
00007c454bbe06ac  call 0x00007C454BAB52F0
00007c454bbe06b1  jmp 0x00007C454BBDEFBE
00007c454bbe06b6  sub rsp, 0x08
00007c454bbe06ba  push rax
00007c454bbe06bb  push rcx
00007c454bbe06bc  push rdx
00007c454bbe06bd  push rdi
00007c454bbe06be  push rsi
00007c454bbe06bf  push r8
00007c454bbe06c1  push r9
00007c454bbe06c3  push r10
00007c454bbe06c5  push r11
00007c454bbe06c7  sub rsp, 0xF0
00007c454bbe06ce  vmovaps [rsp], xmm0
00007c454bbe06d3  vmovaps [rsp+0x10], xmm2
00007c454bbe06d9  vmovaps [rsp+0x20], xmm3
00007c454bbe06df  vmovaps [rsp+0x30], xmm4
00007c454bbe06e5  vmovaps [rsp+0x40], xmm5
00007c454bbe06eb  vmovaps [rsp+0x50], xmm6
00007c454bbe06f1  vmovaps [rsp+0x60], xmm7
00007c454bbe06f7  vmovaps [rsp+0x70], xmm8
00007c454bbe06fd  vmovaps [rsp+0x80], xmm9
00007c454bbe0706  vmovaps [rsp+0x90], xmm10
00007c454bbe070f  vmovaps [rsp+0xA0], xmm11
00007c454bbe0718  vmovaps [rsp+0xB0], xmm12
00007c454bbe0721  vmovaps [rsp+0xC0], xmm13
00007c454bbe072a  vmovaps [rsp+0xD0], xmm14
00007c454bbe0733  vmovaps [rsp+0xE0], xmm15
00007c454bbe073c  sub rsp, 0x30
00007c454bbe0740  movaps [rsp], xmm1
00007c454bbe0744  movaps [rsp+0x10], xmm6
00007c454bbe0749  movaps [rsp+0x20], xmm15
00007c454bbe074f  lea rdi, [rsp]
00007c454bbe0753  mov esi, 0x00
00007c454bbe0758  mov rax, 0x56A18AC54530
00007c454bbe0762  call rax
00007c454bbe0764  movaps xmm1, [rsp]
00007c454bbe0768  add rsp, 0x30
00007c454bbe076c  vmovaps xmm0, [rsp]
00007c454bbe0771  vmovaps xmm2, [rsp+0x10]
00007c454bbe0777  vmovaps xmm3, [rsp+0x20]
00007c454bbe077d  vmovaps xmm4, [rsp+0x30]
00007c454bbe0783  vmovaps xmm5, [rsp+0x40]
00007c454bbe0789  vmovaps xmm6, [rsp+0x50]
00007c454bbe078f  vmovaps xmm7, [rsp+0x60]
00007c454bbe0795  vmovaps xmm8, [rsp+0x70]
00007c454bbe079b  vmovaps xmm9, [rsp+0x80]
00007c454bbe07a4  vmovaps xmm10, [rsp+0x90]
00007c454bbe07ad  vmovaps xmm11, [rsp+0xA0]
00007c454bbe07b6  vmovaps xmm12, [rsp+0xB0]
00007c454bbe07bf  vmovaps xmm13, [rsp+0xC0]
00007c454bbe07c8  vmovaps xmm14, [rsp+0xD0]
00007c454bbe07d1  vmovaps xmm15, [rsp+0xE0]
00007c454bbe07da  add rsp, 0xF0
00007c454bbe07e1  pop r11
00007c454bbe07e3  pop r10
00007c454bbe07e5  pop r9
00007c454bbe07e7  pop r8
00007c454bbe07e9  pop rsi
00007c454bbe07ea  pop rdi
00007c454bbe07eb  pop rdx
00007c454bbe07ec  pop rcx
00007c454bbe07ed  pop rax
00007c454bbe07ee  add rsp, 0x08
00007c454bbe07f2  jmp 0x00007C454BBDEFFB
00007c454bbe07f7  call 0x00007C454BAC4620
00007c454bbe07fc  jmp 0x00007C454BBDF008
00007c454bbe0801  sub rsp, 0x08
00007c454bbe0805  push rax
00007c454bbe0806  push rcx
00007c454bbe0807  push rdx
00007c454bbe0808  push rdi
00007c454bbe0809  push rsi
00007c454bbe080a  push r8
00007c454bbe080c  push r9
00007c454bbe080e  push r10
00007c454bbe0810  push r11
00007c454bbe0812  sub rsp, 0xF0
00007c454bbe0819  vmovaps [rsp], xmm0
00007c454bbe081e  vmovaps [rsp+0x10], xmm1
00007c454bbe0824  vmovaps [rsp+0x20], xmm2
00007c454bbe082a  vmovaps [rsp+0x30], xmm3
00007c454bbe0830  vmovaps [rsp+0x40], xmm4
00007c454bbe0836  vmovaps [rsp+0x50], xmm5
00007c454bbe083c  vmovaps [rsp+0x60], xmm6
00007c454bbe0842  vmovaps [rsp+0x70], xmm7
00007c454bbe0848  vmovaps [rsp+0x80], xmm8
00007c454bbe0851  vmovaps [rsp+0x90], xmm9
00007c454bbe085a  vmovaps [rsp+0xA0], xmm10
00007c454bbe0863  vmovaps [rsp+0xB0], xmm11
00007c454bbe086c  vmovaps [rsp+0xC0], xmm12
00007c454bbe0875  vmovaps [rsp+0xD0], xmm13
00007c454bbe087e  vmovaps [rsp+0xE0], xmm15
00007c454bbe0887  sub rsp, 0x30
00007c454bbe088b  movaps [rsp], xmm14
00007c454bbe0890  movaps [rsp+0x10], xmm4
00007c454bbe0895  movaps [rsp+0x20], xmm3
00007c454bbe089a  lea rdi, [rsp]
00007c454bbe089e  mov esi, 0x00
00007c454bbe08a3  mov rax, 0x56A18AC54530
00007c454bbe08ad  call rax
00007c454bbe08af  movaps xmm14, [rsp]
00007c454bbe08b4  add rsp, 0x30
00007c454bbe08b8  vmovaps xmm0, [rsp]
00007c454bbe08bd  vmovaps xmm1, [rsp+0x10]
00007c454bbe08c3  vmovaps xmm2, [rsp+0x20]
00007c454bbe08c9  vmovaps xmm3, [rsp+0x30]
00007c454bbe08cf  vmovaps xmm4, [rsp+0x40]
00007c454bbe08d5  vmovaps xmm5, [rsp+0x50]
00007c454bbe08db  vmovaps xmm6, [rsp+0x60]
00007c454bbe08e1  vmovaps xmm7, [rsp+0x70]
00007c454bbe08e7  vmovaps xmm8, [rsp+0x80]
00007c454bbe08f0  vmovaps xmm9, [rsp+0x90]
00007c454bbe08f9  vmovaps xmm10, [rsp+0xA0]
00007c454bbe0902  vmovaps xmm11, [rsp+0xB0]
00007c454bbe090b  vmovaps xmm12, [rsp+0xC0]
00007c454bbe0914  vmovaps xmm13, [rsp+0xD0]
00007c454bbe091d  vmovaps xmm15, [rsp+0xE0]
00007c454bbe0926  add rsp, 0xF0
00007c454bbe092d  pop r11
00007c454bbe092f  pop r10
00007c454bbe0931  pop r9
00007c454bbe0933  pop r8
00007c454bbe0935  pop rsi
00007c454bbe0936  pop rdi
00007c454bbe0937  pop rdx
00007c454bbe0938  pop rcx
00007c454bbe0939  pop rax
00007c454bbe093a  add rsp, 0x08
00007c454bbe093e  jmp 0x00007C454BBDF022
00007c454bbe0943  sub rsp, 0x08
00007c454bbe0947  push rax
00007c454bbe0948  push rcx
00007c454bbe0949  push rdx
00007c454bbe094a  push rdi
00007c454bbe094b  push rsi
00007c454bbe094c  push r8
00007c454bbe094e  push r9
00007c454bbe0950  push r10
00007c454bbe0952  push r11
00007c454bbe0954  sub rsp, 0xF0
00007c454bbe095b  vmovaps [rsp], xmm0
00007c454bbe0960  vmovaps [rsp+0x10], xmm1
00007c454bbe0966  vmovaps [rsp+0x20], xmm2
00007c454bbe096c  vmovaps [rsp+0x30], xmm3
00007c454bbe0972  vmovaps [rsp+0x40], xmm4
00007c454bbe0978  vmovaps [rsp+0x50], xmm5
00007c454bbe097e  vmovaps [rsp+0x60], xmm7
00007c454bbe0984  vmovaps [rsp+0x70], xmm8
00007c454bbe098a  vmovaps [rsp+0x80], xmm9
00007c454bbe0993  vmovaps [rsp+0x90], xmm10
00007c454bbe099c  vmovaps [rsp+0xA0], xmm11
00007c454bbe09a5  vmovaps [rsp+0xB0], xmm12
00007c454bbe09ae  vmovaps [rsp+0xC0], xmm13
00007c454bbe09b7  vmovaps [rsp+0xD0], xmm14
00007c454bbe09c0  vmovaps [rsp+0xE0], xmm15
00007c454bbe09c9  sub rsp, 0x30
00007c454bbe09cd  movaps [rsp], xmm6
00007c454bbe09d1  movaps [rsp+0x10], xmm9
00007c454bbe09d7  movaps [rsp+0x20], xmm7
00007c454bbe09dc  lea rdi, [rsp]
00007c454bbe09e0  mov esi, 0x00
00007c454bbe09e5  mov rax, 0x56A18AC54530
00007c454bbe09ef  call rax
00007c454bbe09f1  movaps xmm6, [rsp]
00007c454bbe09f5  add rsp, 0x30
00007c454bbe09f9  vmovaps xmm0, [rsp]
00007c454bbe09fe  vmovaps xmm1, [rsp+0x10]
00007c454bbe0a04  vmovaps xmm2, [rsp+0x20]
00007c454bbe0a0a  vmovaps xmm3, [rsp+0x30]
00007c454bbe0a10  vmovaps xmm4, [rsp+0x40]
00007c454bbe0a16  vmovaps xmm5, [rsp+0x50]
00007c454bbe0a1c  vmovaps xmm7, [rsp+0x60]
00007c454bbe0a22  vmovaps xmm8, [rsp+0x70]
00007c454bbe0a28  vmovaps xmm9, [rsp+0x80]
00007c454bbe0a31  vmovaps xmm10, [rsp+0x90]
00007c454bbe0a3a  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0a43  vmovaps xmm12, [rsp+0xB0]
00007c454bbe0a4c  vmovaps xmm13, [rsp+0xC0]
00007c454bbe0a55  vmovaps xmm14, [rsp+0xD0]
00007c454bbe0a5e  vmovaps xmm15, [rsp+0xE0]
00007c454bbe0a67  add rsp, 0xF0
00007c454bbe0a6e  pop r11
00007c454bbe0a70  pop r10
00007c454bbe0a72  pop r9
00007c454bbe0a74  pop r8
00007c454bbe0a76  pop rsi
00007c454bbe0a77  pop rdi
00007c454bbe0a78  pop rdx
00007c454bbe0a79  pop rcx
00007c454bbe0a7a  pop rax
00007c454bbe0a7b  add rsp, 0x08
00007c454bbe0a7f  jmp 0x00007C454BBDF03A
00007c454bbe0a84  sub rsp, 0x08
00007c454bbe0a88  push rax
00007c454bbe0a89  push rcx
00007c454bbe0a8a  push rdx
00007c454bbe0a8b  push rdi
00007c454bbe0a8c  push rsi
00007c454bbe0a8d  push r8
00007c454bbe0a8f  push r9
00007c454bbe0a91  push r10
00007c454bbe0a93  push r11
00007c454bbe0a95  sub rsp, 0xF0
00007c454bbe0a9c  vmovaps [rsp], xmm0
00007c454bbe0aa1  vmovaps [rsp+0x10], xmm1
00007c454bbe0aa7  vmovaps [rsp+0x20], xmm2
00007c454bbe0aad  vmovaps [rsp+0x30], xmm3
00007c454bbe0ab3  vmovaps [rsp+0x40], xmm4
00007c454bbe0ab9  vmovaps [rsp+0x50], xmm5
00007c454bbe0abf  vmovaps [rsp+0x60], xmm6
00007c454bbe0ac5  vmovaps [rsp+0x70], xmm8
00007c454bbe0acb  vmovaps [rsp+0x80], xmm9
00007c454bbe0ad4  vmovaps [rsp+0x90], xmm10
00007c454bbe0add  vmovaps [rsp+0xA0], xmm11
00007c454bbe0ae6  vmovaps [rsp+0xB0], xmm12
00007c454bbe0aef  vmovaps [rsp+0xC0], xmm13
00007c454bbe0af8  vmovaps [rsp+0xD0], xmm14
00007c454bbe0b01  vmovaps [rsp+0xE0], xmm15
00007c454bbe0b0a  sub rsp, 0x30
00007c454bbe0b0e  movaps [rsp], xmm7
00007c454bbe0b12  movaps [rsp+0x10], xmm4
00007c454bbe0b17  movaps [rsp+0x20], xmm9
00007c454bbe0b1d  lea rdi, [rsp]
00007c454bbe0b21  mov esi, 0x00
00007c454bbe0b26  mov rax, 0x56A18AC54530
00007c454bbe0b30  call rax
00007c454bbe0b32  movaps xmm7, [rsp]
00007c454bbe0b36  add rsp, 0x30
00007c454bbe0b3a  vmovaps xmm0, [rsp]
00007c454bbe0b3f  vmovaps xmm1, [rsp+0x10]
00007c454bbe0b45  vmovaps xmm2, [rsp+0x20]
00007c454bbe0b4b  vmovaps xmm3, [rsp+0x30]
00007c454bbe0b51  vmovaps xmm4, [rsp+0x40]
00007c454bbe0b57  vmovaps xmm5, [rsp+0x50]
00007c454bbe0b5d  vmovaps xmm6, [rsp+0x60]
00007c454bbe0b63  vmovaps xmm8, [rsp+0x70]
00007c454bbe0b69  vmovaps xmm9, [rsp+0x80]
00007c454bbe0b72  vmovaps xmm10, [rsp+0x90]
00007c454bbe0b7b  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0b84  vmovaps xmm12, [rsp+0xB0]
00007c454bbe0b8d  vmovaps xmm13, [rsp+0xC0]
00007c454bbe0b96  vmovaps xmm14, [rsp+0xD0]
00007c454bbe0b9f  vmovaps xmm15, [rsp+0xE0]
00007c454bbe0ba8  add rsp, 0xF0
00007c454bbe0baf  pop r11
00007c454bbe0bb1  pop r10
00007c454bbe0bb3  pop r9
00007c454bbe0bb5  pop r8
00007c454bbe0bb7  pop rsi
00007c454bbe0bb8  pop rdi
00007c454bbe0bb9  pop rdx
00007c454bbe0bba  pop rcx
00007c454bbe0bbb  pop rax
00007c454bbe0bbc  add rsp, 0x08
00007c454bbe0bc0  jmp 0x00007C454BBDF067
00007c454bbe0bc5  sub rsp, 0x08
00007c454bbe0bc9  push rax
00007c454bbe0bca  push rcx
00007c454bbe0bcb  push rdx
00007c454bbe0bcc  push rdi
00007c454bbe0bcd  push rsi
00007c454bbe0bce  push r8
00007c454bbe0bd0  push r9
00007c454bbe0bd2  push r10
00007c454bbe0bd4  push r11
00007c454bbe0bd6  sub rsp, 0xF0
00007c454bbe0bdd  vmovaps [rsp], xmm0
00007c454bbe0be2  vmovaps [rsp+0x10], xmm1
00007c454bbe0be8  vmovaps [rsp+0x20], xmm2
00007c454bbe0bee  vmovaps [rsp+0x30], xmm3
00007c454bbe0bf4  vmovaps [rsp+0x40], xmm5
00007c454bbe0bfa  vmovaps [rsp+0x50], xmm6
00007c454bbe0c00  vmovaps [rsp+0x60], xmm7
00007c454bbe0c06  vmovaps [rsp+0x70], xmm8
00007c454bbe0c0c  vmovaps [rsp+0x80], xmm9
00007c454bbe0c15  vmovaps [rsp+0x90], xmm10
00007c454bbe0c1e  vmovaps [rsp+0xA0], xmm11
00007c454bbe0c27  vmovaps [rsp+0xB0], xmm12
00007c454bbe0c30  vmovaps [rsp+0xC0], xmm13
00007c454bbe0c39  vmovaps [rsp+0xD0], xmm14
00007c454bbe0c42  vmovaps [rsp+0xE0], xmm15
00007c454bbe0c4b  sub rsp, 0x30
00007c454bbe0c4f  movaps [rsp], xmm4
00007c454bbe0c53  movaps [rsp+0x10], xmm15
00007c454bbe0c59  movaps [rsp+0x20], xmm9
00007c454bbe0c5f  lea rdi, [rsp]
00007c454bbe0c63  mov esi, 0x00
00007c454bbe0c68  mov rax, 0x56A18AC54530
00007c454bbe0c72  call rax
00007c454bbe0c74  movaps xmm4, [rsp]
00007c454bbe0c78  add rsp, 0x30
00007c454bbe0c7c  vmovaps xmm0, [rsp]
00007c454bbe0c81  vmovaps xmm1, [rsp+0x10]
00007c454bbe0c87  vmovaps xmm2, [rsp+0x20]
00007c454bbe0c8d  vmovaps xmm3, [rsp+0x30]
00007c454bbe0c93  vmovaps xmm5, [rsp+0x40]
00007c454bbe0c99  vmovaps xmm6, [rsp+0x50]
00007c454bbe0c9f  vmovaps xmm7, [rsp+0x60]
00007c454bbe0ca5  vmovaps xmm8, [rsp+0x70]
00007c454bbe0cab  vmovaps xmm9, [rsp+0x80]
00007c454bbe0cb4  vmovaps xmm10, [rsp+0x90]
00007c454bbe0cbd  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0cc6  vmovaps xmm12, [rsp+0xB0]
00007c454bbe0ccf  vmovaps xmm13, [rsp+0xC0]
00007c454bbe0cd8  vmovaps xmm14, [rsp+0xD0]
00007c454bbe0ce1  vmovaps xmm15, [rsp+0xE0]
00007c454bbe0cea  add rsp, 0xF0
00007c454bbe0cf1  pop r11
00007c454bbe0cf3  pop r10
00007c454bbe0cf5  pop r9
00007c454bbe0cf7  pop r8
00007c454bbe0cf9  pop rsi
00007c454bbe0cfa  pop rdi
00007c454bbe0cfb  pop rdx
00007c454bbe0cfc  pop rcx
00007c454bbe0cfd  pop rax
00007c454bbe0cfe  add rsp, 0x08
00007c454bbe0d02  jmp 0x00007C454BBDF08C
00007c454bbe0d07  call 0x00007C454BAC4620
00007c454bbe0d0c  jmp 0x00007C454BBDF099
00007c454bbe0d11  sub rsp, 0x08
00007c454bbe0d15  push rax
00007c454bbe0d16  push rcx
00007c454bbe0d17  push rdx
00007c454bbe0d18  push rdi
00007c454bbe0d19  push rsi
00007c454bbe0d1a  push r8
00007c454bbe0d1c  push r9
00007c454bbe0d1e  push r10
00007c454bbe0d20  push r11
00007c454bbe0d22  sub rsp, 0xF0
00007c454bbe0d29  vmovaps [rsp], xmm0
00007c454bbe0d2e  vmovaps [rsp+0x10], xmm1
00007c454bbe0d34  vmovaps [rsp+0x20], xmm2
00007c454bbe0d3a  vmovaps [rsp+0x30], xmm4
00007c454bbe0d40  vmovaps [rsp+0x40], xmm5
00007c454bbe0d46  vmovaps [rsp+0x50], xmm6
00007c454bbe0d4c  vmovaps [rsp+0x60], xmm7
00007c454bbe0d52  vmovaps [rsp+0x70], xmm8
00007c454bbe0d58  vmovaps [rsp+0x80], xmm9
00007c454bbe0d61  vmovaps [rsp+0x90], xmm10
00007c454bbe0d6a  vmovaps [rsp+0xA0], xmm11
00007c454bbe0d73  vmovaps [rsp+0xB0], xmm12
00007c454bbe0d7c  vmovaps [rsp+0xC0], xmm13
00007c454bbe0d85  vmovaps [rsp+0xD0], xmm14
00007c454bbe0d8e  vmovaps [rsp+0xE0], xmm15
00007c454bbe0d97  sub rsp, 0x30
00007c454bbe0d9b  movaps [rsp], xmm3
00007c454bbe0d9f  movaps [rsp+0x10], xmm1
00007c454bbe0da4  movaps [rsp+0x20], xmm9
00007c454bbe0daa  lea rdi, [rsp]
00007c454bbe0dae  mov esi, 0x00
00007c454bbe0db3  mov rax, 0x56A18AC54530
00007c454bbe0dbd  call rax
00007c454bbe0dbf  movaps xmm3, [rsp]
00007c454bbe0dc3  add rsp, 0x30
00007c454bbe0dc7  vmovaps xmm0, [rsp]
00007c454bbe0dcc  vmovaps xmm1, [rsp+0x10]
00007c454bbe0dd2  vmovaps xmm2, [rsp+0x20]
00007c454bbe0dd8  vmovaps xmm4, [rsp+0x30]
00007c454bbe0dde  vmovaps xmm5, [rsp+0x40]
00007c454bbe0de4  vmovaps xmm6, [rsp+0x50]
00007c454bbe0dea  vmovaps xmm7, [rsp+0x60]
00007c454bbe0df0  vmovaps xmm8, [rsp+0x70]
00007c454bbe0df6  vmovaps xmm9, [rsp+0x80]
00007c454bbe0dff  vmovaps xmm10, [rsp+0x90]
00007c454bbe0e08  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0e11  vmovaps xmm12, [rsp+0xB0]
00007c454bbe0e1a  vmovaps xmm13, [rsp+0xC0]
00007c454bbe0e23  vmovaps xmm14, [rsp+0xD0]
00007c454bbe0e2c  vmovaps xmm15, [rsp+0xE0]
00007c454bbe0e35  add rsp, 0xF0
00007c454bbe0e3c  pop r11
00007c454bbe0e3e  pop r10
00007c454bbe0e40  pop r9
00007c454bbe0e42  pop r8
00007c454bbe0e44  pop rsi
00007c454bbe0e45  pop rdi
00007c454bbe0e46  pop rdx
00007c454bbe0e47  pop rcx
00007c454bbe0e48  pop rax
00007c454bbe0e49  add rsp, 0x08
00007c454bbe0e4d  jmp 0x00007C454BBDF0D6
00007c454bbe0e52  sub rsp, 0x08
00007c454bbe0e56  push rax
00007c454bbe0e57  push rcx
00007c454bbe0e58  push rdx
00007c454bbe0e59  push rdi
00007c454bbe0e5a  push rsi
00007c454bbe0e5b  push r8
00007c454bbe0e5d  push r9
00007c454bbe0e5f  push r10
00007c454bbe0e61  push r11
00007c454bbe0e63  sub rsp, 0xF0
00007c454bbe0e6a  vmovaps [rsp], xmm0
00007c454bbe0e6f  vmovaps [rsp+0x10], xmm2
00007c454bbe0e75  vmovaps [rsp+0x20], xmm3
00007c454bbe0e7b  vmovaps [rsp+0x30], xmm4
00007c454bbe0e81  vmovaps [rsp+0x40], xmm5
00007c454bbe0e87  vmovaps [rsp+0x50], xmm6
00007c454bbe0e8d  vmovaps [rsp+0x60], xmm7
00007c454bbe0e93  vmovaps [rsp+0x70], xmm8
00007c454bbe0e99  vmovaps [rsp+0x80], xmm9
00007c454bbe0ea2  vmovaps [rsp+0x90], xmm10
00007c454bbe0eab  vmovaps [rsp+0xA0], xmm11
00007c454bbe0eb4  vmovaps [rsp+0xB0], xmm12
00007c454bbe0ebd  vmovaps [rsp+0xC0], xmm13
00007c454bbe0ec6  vmovaps [rsp+0xD0], xmm14
00007c454bbe0ecf  vmovaps [rsp+0xE0], xmm15
00007c454bbe0ed8  sub rsp, 0x30
00007c454bbe0edc  movaps [rsp], xmm1
00007c454bbe0ee0  movaps [rsp+0x10], xmm15
00007c454bbe0ee6  movaps [rsp+0x20], xmm9
00007c454bbe0eec  lea rdi, [rsp]
00007c454bbe0ef0  mov esi, 0x00
00007c454bbe0ef5  mov rax, 0x56A18AC54530
00007c454bbe0eff  call rax
00007c454bbe0f01  movaps xmm1, [rsp]
00007c454bbe0f05  add rsp, 0x30
00007c454bbe0f09  vmovaps xmm0, [rsp]
00007c454bbe0f0e  vmovaps xmm2, [rsp+0x10]
00007c454bbe0f14  vmovaps xmm3, [rsp+0x20]
00007c454bbe0f1a  vmovaps xmm4, [rsp+0x30]
00007c454bbe0f20  vmovaps xmm5, [rsp+0x40]
00007c454bbe0f26  vmovaps xmm6, [rsp+0x50]
00007c454bbe0f2c  vmovaps xmm7, [rsp+0x60]
00007c454bbe0f32  vmovaps xmm8, [rsp+0x70]
00007c454bbe0f38  vmovaps xmm9, [rsp+0x80]
00007c454bbe0f41  vmovaps xmm10, [rsp+0x90]
00007c454bbe0f4a  vmovaps xmm11, [rsp+0xA0]
00007c454bbe0f53  vmovaps xmm12, [rsp+0xB0]
00007c454bbe0f5c  vmovaps xmm13, [rsp+0xC0]
00007c454bbe0f65  vmovaps xmm14, [rsp+0xD0]
00007c454bbe0f6e  vmovaps xmm15, [rsp+0xE0]
00007c454bbe0f77  add rsp, 0xF0
00007c454bbe0f7e  pop r11
00007c454bbe0f80  pop r10
00007c454bbe0f82  pop r9
00007c454bbe0f84  pop r8
00007c454bbe0f86  pop rsi
00007c454bbe0f87  pop rdi
00007c454bbe0f88  pop rdx
00007c454bbe0f89  pop rcx
00007c454bbe0f8a  pop rax
00007c454bbe0f8b  add rsp, 0x08
00007c454bbe0f8f  jmp 0x00007C454BBDF15E
00007c454bbe0f94  call 0x00007C454BAC4620
00007c454bbe0f99  jmp 0x00007C454BBDF16B
00007c454bbe0f9e  sub rsp, 0x08
00007c454bbe0fa2  push rax
00007c454bbe0fa3  push rcx
00007c454bbe0fa4  push rdx
00007c454bbe0fa5  push rdi
00007c454bbe0fa6  push rsi
00007c454bbe0fa7  push r8
00007c454bbe0fa9  push r9
00007c454bbe0fab  push r10
00007c454bbe0fad  push r11
00007c454bbe0faf  sub rsp, 0xF0
00007c454bbe0fb6  vmovaps [rsp], xmm0
00007c454bbe0fbb  vmovaps [rsp+0x10], xmm2
00007c454bbe0fc1  vmovaps [rsp+0x20], xmm3
00007c454bbe0fc7  vmovaps [rsp+0x30], xmm4
00007c454bbe0fcd  vmovaps [rsp+0x40], xmm5
00007c454bbe0fd3  vmovaps [rsp+0x50], xmm6
00007c454bbe0fd9  vmovaps [rsp+0x60], xmm7
00007c454bbe0fdf  vmovaps [rsp+0x70], xmm8
00007c454bbe0fe5  vmovaps [rsp+0x80], xmm9
00007c454bbe0fee  vmovaps [rsp+0x90], xmm10
00007c454bbe0ff7  vmovaps [rsp+0xA0], xmm11
00007c454bbe1000  vmovaps [rsp+0xB0], xmm12
00007c454bbe1009  vmovaps [rsp+0xC0], xmm13
00007c454bbe1012  vmovaps [rsp+0xD0], xmm14
00007c454bbe101b  vmovaps [rsp+0xE0], xmm15
00007c454bbe1024  sub rsp, 0x30
00007c454bbe1028  movaps [rsp], xmm1
00007c454bbe102c  movaps [rsp+0x10], xmm5
00007c454bbe1031  movaps [rsp+0x20], xmm7
00007c454bbe1036  lea rdi, [rsp]
00007c454bbe103a  mov esi, 0x00
00007c454bbe103f  mov rax, 0x56A18AC54530
00007c454bbe1049  call rax
00007c454bbe104b  movaps xmm1, [rsp]
00007c454bbe104f  add rsp, 0x30
00007c454bbe1053  vmovaps xmm0, [rsp]
00007c454bbe1058  vmovaps xmm2, [rsp+0x10]
00007c454bbe105e  vmovaps xmm3, [rsp+0x20]
00007c454bbe1064  vmovaps xmm4, [rsp+0x30]
00007c454bbe106a  vmovaps xmm5, [rsp+0x40]
00007c454bbe1070  vmovaps xmm6, [rsp+0x50]
00007c454bbe1076  vmovaps xmm7, [rsp+0x60]
00007c454bbe107c  vmovaps xmm8, [rsp+0x70]
00007c454bbe1082  vmovaps xmm9, [rsp+0x80]
00007c454bbe108b  vmovaps xmm10, [rsp+0x90]
00007c454bbe1094  vmovaps xmm11, [rsp+0xA0]
00007c454bbe109d  vmovaps xmm12, [rsp+0xB0]
00007c454bbe10a6  vmovaps xmm13, [rsp+0xC0]
00007c454bbe10af  vmovaps xmm14, [rsp+0xD0]
00007c454bbe10b8  vmovaps xmm15, [rsp+0xE0]
00007c454bbe10c1  add rsp, 0xF0
00007c454bbe10c8  pop r11
00007c454bbe10ca  pop r10
00007c454bbe10cc  pop r9
00007c454bbe10ce  pop r8
00007c454bbe10d0  pop rsi
00007c454bbe10d1  pop rdi
00007c454bbe10d2  pop rdx
00007c454bbe10d3  pop rcx
00007c454bbe10d4  pop rax
00007c454bbe10d5  add rsp, 0x08
00007c454bbe10d9  jmp 0x00007C454BBDF210
00007c454bbe10de  sub rsp, 0x08
00007c454bbe10e2  push rax
00007c454bbe10e3  push rcx
00007c454bbe10e4  push rdx
00007c454bbe10e5  push rdi
00007c454bbe10e6  push rsi
00007c454bbe10e7  push r8
00007c454bbe10e9  push r9
00007c454bbe10eb  push r10
00007c454bbe10ed  push r11
00007c454bbe10ef  sub rsp, 0xF0
00007c454bbe10f6  vmovaps [rsp], xmm0
00007c454bbe10fb  vmovaps [rsp+0x10], xmm1
00007c454bbe1101  vmovaps [rsp+0x20], xmm2
00007c454bbe1107  vmovaps [rsp+0x30], xmm3
00007c454bbe110d  vmovaps [rsp+0x40], xmm4
00007c454bbe1113  vmovaps [rsp+0x50], xmm5
00007c454bbe1119  vmovaps [rsp+0x60], xmm6
00007c454bbe111f  vmovaps [rsp+0x70], xmm8
00007c454bbe1125  vmovaps [rsp+0x80], xmm9
00007c454bbe112e  vmovaps [rsp+0x90], xmm10
00007c454bbe1137  vmovaps [rsp+0xA0], xmm11
00007c454bbe1140  vmovaps [rsp+0xB0], xmm12
00007c454bbe1149  vmovaps [rsp+0xC0], xmm13
00007c454bbe1152  vmovaps [rsp+0xD0], xmm14
00007c454bbe115b  vmovaps [rsp+0xE0], xmm15
00007c454bbe1164  sub rsp, 0x30
00007c454bbe1168  movaps [rsp], xmm7
00007c454bbe116c  movaps [rsp+0x10], xmm5
00007c454bbe1171  movaps [rsp+0x20], xmm15
00007c454bbe1177  lea rdi, [rsp]
00007c454bbe117b  mov esi, 0x00
00007c454bbe1180  mov rax, 0x56A18AC54530
00007c454bbe118a  call rax
00007c454bbe118c  movaps xmm7, [rsp]
00007c454bbe1190  add rsp, 0x30
00007c454bbe1194  vmovaps xmm0, [rsp]
00007c454bbe1199  vmovaps xmm1, [rsp+0x10]
00007c454bbe119f  vmovaps xmm2, [rsp+0x20]
00007c454bbe11a5  vmovaps xmm3, [rsp+0x30]
00007c454bbe11ab  vmovaps xmm4, [rsp+0x40]
00007c454bbe11b1  vmovaps xmm5, [rsp+0x50]
00007c454bbe11b7  vmovaps xmm6, [rsp+0x60]
00007c454bbe11bd  vmovaps xmm8, [rsp+0x70]
00007c454bbe11c3  vmovaps xmm9, [rsp+0x80]
00007c454bbe11cc  vmovaps xmm10, [rsp+0x90]
00007c454bbe11d5  vmovaps xmm11, [rsp+0xA0]
00007c454bbe11de  vmovaps xmm12, [rsp+0xB0]
00007c454bbe11e7  vmovaps xmm13, [rsp+0xC0]
00007c454bbe11f0  vmovaps xmm14, [rsp+0xD0]
00007c454bbe11f9  vmovaps xmm15, [rsp+0xE0]
00007c454bbe1202  add rsp, 0xF0
00007c454bbe1209  pop r11
00007c454bbe120b  pop r10
00007c454bbe120d  pop r9
00007c454bbe120f  pop r8
00007c454bbe1211  pop rsi
00007c454bbe1212  pop rdi
00007c454bbe1213  pop rdx
00007c454bbe1214  pop rcx
00007c454bbe1215  pop rax
00007c454bbe1216  add rsp, 0x08
00007c454bbe121a  jmp 0x00007C454BBDF246
00007c454bbe121f  call 0x00007C454BAB52F0
00007c454bbe1224  jmp 0x00007C454BBDF253
00007c454bbe1229  sub rsp, 0x08
00007c454bbe122d  push rax
00007c454bbe122e  push rcx
00007c454bbe122f  push rdx
00007c454bbe1230  push rdi
00007c454bbe1231  push rsi
00007c454bbe1232  push r8
00007c454bbe1234  push r9
00007c454bbe1236  push r10
00007c454bbe1238  push r11
00007c454bbe123a  sub rsp, 0xF0
00007c454bbe1241  vmovaps [rsp], xmm0
00007c454bbe1246  vmovaps [rsp+0x10], xmm1
00007c454bbe124c  vmovaps [rsp+0x20], xmm2
00007c454bbe1252  vmovaps [rsp+0x30], xmm3
00007c454bbe1258  vmovaps [rsp+0x40], xmm4
00007c454bbe125e  vmovaps [rsp+0x50], xmm5
00007c454bbe1264  vmovaps [rsp+0x60], xmm6
00007c454bbe126a  vmovaps [rsp+0x70], xmm7
00007c454bbe1270  vmovaps [rsp+0x80], xmm8
00007c454bbe1279  vmovaps [rsp+0x90], xmm9
00007c454bbe1282  vmovaps [rsp+0xA0], xmm10
00007c454bbe128b  vmovaps [rsp+0xB0], xmm11
00007c454bbe1294  vmovaps [rsp+0xC0], xmm12
00007c454bbe129d  vmovaps [rsp+0xD0], xmm13
00007c454bbe12a6  vmovaps [rsp+0xE0], xmm14
00007c454bbe12af  sub rsp, 0x30
00007c454bbe12b3  movaps [rsp], xmm15
00007c454bbe12b8  movaps [rsp+0x10], xmm5
00007c454bbe12bd  movaps [rsp+0x20], xmm3
00007c454bbe12c2  lea rdi, [rsp]
00007c454bbe12c6  mov esi, 0x00
00007c454bbe12cb  mov rax, 0x56A18AC54530
00007c454bbe12d5  call rax
00007c454bbe12d7  movaps xmm15, [rsp]
00007c454bbe12dc  add rsp, 0x30
00007c454bbe12e0  vmovaps xmm0, [rsp]
00007c454bbe12e5  vmovaps xmm1, [rsp+0x10]
00007c454bbe12eb  vmovaps xmm2, [rsp+0x20]
00007c454bbe12f1  vmovaps xmm3, [rsp+0x30]
00007c454bbe12f7  vmovaps xmm4, [rsp+0x40]
00007c454bbe12fd  vmovaps xmm5, [rsp+0x50]
00007c454bbe1303  vmovaps xmm6, [rsp+0x60]
00007c454bbe1309  vmovaps xmm7, [rsp+0x70]
00007c454bbe130f  vmovaps xmm8, [rsp+0x80]
00007c454bbe1318  vmovaps xmm9, [rsp+0x90]
00007c454bbe1321  vmovaps xmm10, [rsp+0xA0]
00007c454bbe132a  vmovaps xmm11, [rsp+0xB0]
00007c454bbe1333  vmovaps xmm12, [rsp+0xC0]
00007c454bbe133c  vmovaps xmm13, [rsp+0xD0]
00007c454bbe1345  vmovaps xmm14, [rsp+0xE0]
00007c454bbe134e  add rsp, 0xF0
00007c454bbe1355  pop r11
00007c454bbe1357  pop r10
00007c454bbe1359  pop r9
00007c454bbe135b  pop r8
00007c454bbe135d  pop rsi
00007c454bbe135e  pop rdi
00007c454bbe135f  pop rdx
00007c454bbe1360  pop rcx
00007c454bbe1361  pop rax
00007c454bbe1362  add rsp, 0x08
00007c454bbe1366  jmp 0x00007C454BBDF279
00007c454bbe136b  sub rsp, 0x08
00007c454bbe136f  push rax
00007c454bbe1370  push rcx
00007c454bbe1371  push rdx
00007c454bbe1372  push rdi
00007c454bbe1373  push rsi
00007c454bbe1374  push r8
00007c454bbe1376  push r9
00007c454bbe1378  push r10
00007c454bbe137a  push r11
00007c454bbe137c  sub rsp, 0xF0
00007c454bbe1383  vmovaps [rsp], xmm0
00007c454bbe1388  vmovaps [rsp+0x10], xmm2
00007c454bbe138e  vmovaps [rsp+0x20], xmm3
00007c454bbe1394  vmovaps [rsp+0x30], xmm4
00007c454bbe139a  vmovaps [rsp+0x40], xmm5
00007c454bbe13a0  vmovaps [rsp+0x50], xmm6
00007c454bbe13a6  vmovaps [rsp+0x60], xmm7
00007c454bbe13ac  vmovaps [rsp+0x70], xmm8
00007c454bbe13b2  vmovaps [rsp+0x80], xmm9
00007c454bbe13bb  vmovaps [rsp+0x90], xmm10
00007c454bbe13c4  vmovaps [rsp+0xA0], xmm11
00007c454bbe13cd  vmovaps [rsp+0xB0], xmm12
00007c454bbe13d6  vmovaps [rsp+0xC0], xmm13
00007c454bbe13df  vmovaps [rsp+0xD0], xmm14
00007c454bbe13e8  vmovaps [rsp+0xE0], xmm15
00007c454bbe13f1  sub rsp, 0x30
00007c454bbe13f5  movaps [rsp], xmm1
00007c454bbe13f9  movaps [rsp+0x10], xmm5
00007c454bbe13fe  movaps [rsp+0x20], xmm4
00007c454bbe1403  lea rdi, [rsp]
00007c454bbe1407  mov esi, 0x00
00007c454bbe140c  mov rax, 0x56A18AC54530
00007c454bbe1416  call rax
00007c454bbe1418  movaps xmm1, [rsp]
00007c454bbe141c  add rsp, 0x30
00007c454bbe1420  vmovaps xmm0, [rsp]
00007c454bbe1425  vmovaps xmm2, [rsp+0x10]
00007c454bbe142b  vmovaps xmm3, [rsp+0x20]
00007c454bbe1431  vmovaps xmm4, [rsp+0x30]
00007c454bbe1437  vmovaps xmm5, [rsp+0x40]
00007c454bbe143d  vmovaps xmm6, [rsp+0x50]
00007c454bbe1443  vmovaps xmm7, [rsp+0x60]
00007c454bbe1449  vmovaps xmm8, [rsp+0x70]
00007c454bbe144f  vmovaps xmm9, [rsp+0x80]
00007c454bbe1458  vmovaps xmm10, [rsp+0x90]
00007c454bbe1461  vmovaps xmm11, [rsp+0xA0]
00007c454bbe146a  vmovaps xmm12, [rsp+0xB0]
00007c454bbe1473  vmovaps xmm13, [rsp+0xC0]
00007c454bbe147c  vmovaps xmm14, [rsp+0xD0]
00007c454bbe1485  vmovaps xmm15, [rsp+0xE0]
00007c454bbe148e  add rsp, 0xF0
00007c454bbe1495  pop r11
00007c454bbe1497  pop r10
00007c454bbe1499  pop r9
00007c454bbe149b  pop r8
00007c454bbe149d  pop rsi
00007c454bbe149e  pop rdi
00007c454bbe149f  pop rdx
00007c454bbe14a0  pop rcx
00007c454bbe14a1  pop rax
00007c454bbe14a2  add rsp, 0x08
00007c454bbe14a6  jmp 0x00007C454BBDF299
00007c454bbe14ab  sub rsp, 0x08
00007c454bbe14af  push rax
00007c454bbe14b0  push rcx
00007c454bbe14b1  push rdx
00007c454bbe14b2  push rdi
00007c454bbe14b3  push rsi
00007c454bbe14b4  push r8
00007c454bbe14b6  push r9
00007c454bbe14b8  push r10
00007c454bbe14ba  push r11
00007c454bbe14bc  sub rsp, 0xF0
00007c454bbe14c3  vmovaps [rsp], xmm0
00007c454bbe14c8  vmovaps [rsp+0x10], xmm1
00007c454bbe14ce  vmovaps [rsp+0x20], xmm2
00007c454bbe14d4  vmovaps [rsp+0x30], xmm3
00007c454bbe14da  vmovaps [rsp+0x40], xmm5
00007c454bbe14e0  vmovaps [rsp+0x50], xmm6
00007c454bbe14e6  vmovaps [rsp+0x60], xmm7
00007c454bbe14ec  vmovaps [rsp+0x70], xmm8
00007c454bbe14f2  vmovaps [rsp+0x80], xmm9
00007c454bbe14fb  vmovaps [rsp+0x90], xmm10
00007c454bbe1504  vmovaps [rsp+0xA0], xmm11
00007c454bbe150d  vmovaps [rsp+0xB0], xmm12
00007c454bbe1516  vmovaps [rsp+0xC0], xmm13
00007c454bbe151f  vmovaps [rsp+0xD0], xmm14
00007c454bbe1528  vmovaps [rsp+0xE0], xmm15
00007c454bbe1531  sub rsp, 0x30
00007c454bbe1535  movaps [rsp], xmm4
00007c454bbe1539  movaps [rsp+0x10], xmm3
00007c454bbe153e  movaps [rsp+0x20], xmm5
00007c454bbe1543  lea rdi, [rsp]
00007c454bbe1547  mov esi, 0x00
00007c454bbe154c  mov rax, 0x56A18AC54530
00007c454bbe1556  call rax
00007c454bbe1558  movaps xmm4, [rsp]
00007c454bbe155c  add rsp, 0x30
00007c454bbe1560  vmovaps xmm0, [rsp]
00007c454bbe1565  vmovaps xmm1, [rsp+0x10]
00007c454bbe156b  vmovaps xmm2, [rsp+0x20]
00007c454bbe1571  vmovaps xmm3, [rsp+0x30]
00007c454bbe1577  vmovaps xmm5, [rsp+0x40]
00007c454bbe157d  vmovaps xmm6, [rsp+0x50]
00007c454bbe1583  vmovaps xmm7, [rsp+0x60]
00007c454bbe1589  vmovaps xmm8, [rsp+0x70]
00007c454bbe158f  vmovaps xmm9, [rsp+0x80]
00007c454bbe1598  vmovaps xmm10, [rsp+0x90]
00007c454bbe15a1  vmovaps xmm11, [rsp+0xA0]
00007c454bbe15aa  vmovaps xmm12, [rsp+0xB0]
00007c454bbe15b3  vmovaps xmm13, [rsp+0xC0]
00007c454bbe15bc  vmovaps xmm14, [rsp+0xD0]
00007c454bbe15c5  vmovaps xmm15, [rsp+0xE0]
00007c454bbe15ce  add rsp, 0xF0
00007c454bbe15d5  pop r11
00007c454bbe15d7  pop r10
00007c454bbe15d9  pop r9
00007c454bbe15db  pop r8
00007c454bbe15dd  pop rsi
00007c454bbe15de  pop rdi
00007c454bbe15df  pop rdx
00007c454bbe15e0  pop rcx
00007c454bbe15e1  pop rax
00007c454bbe15e2  add rsp, 0x08
00007c454bbe15e6  jmp 0x00007C454BBDF2E7
00007c454bbe15eb  call 0x00007C454BAB52F0
00007c454bbe15f0  jmp 0x00007C454BBDF2F4
00007c454bbe15f5  sub rsp, 0x08
00007c454bbe15f9  push rax
00007c454bbe15fa  push rcx
00007c454bbe15fb  push rdx
00007c454bbe15fc  push rdi
00007c454bbe15fd  push rsi
00007c454bbe15fe  push r8
00007c454bbe1600  push r9
00007c454bbe1602  push r10
00007c454bbe1604  push r11
00007c454bbe1606  sub rsp, 0xF0
00007c454bbe160d  vmovaps [rsp], xmm0
00007c454bbe1612  vmovaps [rsp+0x10], xmm1
00007c454bbe1618  vmovaps [rsp+0x20], xmm2
00007c454bbe161e  vmovaps [rsp+0x30], xmm3
00007c454bbe1624  vmovaps [rsp+0x40], xmm4
00007c454bbe162a  vmovaps [rsp+0x50], xmm6
00007c454bbe1630  vmovaps [rsp+0x60], xmm7
00007c454bbe1636  vmovaps [rsp+0x70], xmm8
00007c454bbe163c  vmovaps [rsp+0x80], xmm9
00007c454bbe1645  vmovaps [rsp+0x90], xmm10
00007c454bbe164e  vmovaps [rsp+0xA0], xmm11
00007c454bbe1657  vmovaps [rsp+0xB0], xmm12
00007c454bbe1660  vmovaps [rsp+0xC0], xmm13
00007c454bbe1669  vmovaps [rsp+0xD0], xmm14
00007c454bbe1672  vmovaps [rsp+0xE0], xmm15
00007c454bbe167b  sub rsp, 0x30
00007c454bbe167f  movaps [rsp], xmm5
00007c454bbe1683  movaps [rsp+0x10], xmm6
00007c454bbe1688  movaps [rsp+0x20], xmm3
00007c454bbe168d  lea rdi, [rsp]
00007c454bbe1691  mov esi, 0x00
00007c454bbe1696  mov rax, 0x56A18AC54530
00007c454bbe16a0  call rax
00007c454bbe16a2  movaps xmm5, [rsp]
00007c454bbe16a6  add rsp, 0x30
00007c454bbe16aa  vmovaps xmm0, [rsp]
00007c454bbe16af  vmovaps xmm1, [rsp+0x10]
00007c454bbe16b5  vmovaps xmm2, [rsp+0x20]
00007c454bbe16bb  vmovaps xmm3, [rsp+0x30]
00007c454bbe16c1  vmovaps xmm4, [rsp+0x40]
00007c454bbe16c7  vmovaps xmm6, [rsp+0x50]
00007c454bbe16cd  vmovaps xmm7, [rsp+0x60]
00007c454bbe16d3  vmovaps xmm8, [rsp+0x70]
00007c454bbe16d9  vmovaps xmm9, [rsp+0x80]
00007c454bbe16e2  vmovaps xmm10, [rsp+0x90]
00007c454bbe16eb  vmovaps xmm11, [rsp+0xA0]
00007c454bbe16f4  vmovaps xmm12, [rsp+0xB0]
00007c454bbe16fd  vmovaps xmm13, [rsp+0xC0]
00007c454bbe1706  vmovaps xmm14, [rsp+0xD0]
00007c454bbe170f  vmovaps xmm15, [rsp+0xE0]
00007c454bbe1718  add rsp, 0xF0
00007c454bbe171f  pop r11
00007c454bbe1721  pop r10
00007c454bbe1723  pop r9
00007c454bbe1725  pop r8
00007c454bbe1727  pop rsi
00007c454bbe1728  pop rdi
00007c454bbe1729  pop rdx
00007c454bbe172a  pop rcx
00007c454bbe172b  pop rax
00007c454bbe172c  add rsp, 0x08
00007c454bbe1730  jmp 0x00007C454BBDF31A
00007c454bbe1735  sub rsp, 0x08
00007c454bbe1739  push rax
00007c454bbe173a  push rcx
00007c454bbe173b  push rdx
00007c454bbe173c  push rdi
00007c454bbe173d  push rsi
00007c454bbe173e  push r8
00007c454bbe1740  push r9
00007c454bbe1742  push r10
00007c454bbe1744  push r11
00007c454bbe1746  sub rsp, 0xF0
00007c454bbe174d  vmovaps [rsp], xmm0
00007c454bbe1752  vmovaps [rsp+0x10], xmm1
00007c454bbe1758  vmovaps [rsp+0x20], xmm2
00007c454bbe175e  vmovaps [rsp+0x30], xmm3
00007c454bbe1764  vmovaps [rsp+0x40], xmm4
00007c454bbe176a  vmovaps [rsp+0x50], xmm5
00007c454bbe1770  vmovaps [rsp+0x60], xmm7
00007c454bbe1776  vmovaps [rsp+0x70], xmm8
00007c454bbe177c  vmovaps [rsp+0x80], xmm9
00007c454bbe1785  vmovaps [rsp+0x90], xmm10
00007c454bbe178e  vmovaps [rsp+0xA0], xmm11
00007c454bbe1797  vmovaps [rsp+0xB0], xmm12
00007c454bbe17a0  vmovaps [rsp+0xC0], xmm13
00007c454bbe17a9  vmovaps [rsp+0xD0], xmm14
00007c454bbe17b2  vmovaps [rsp+0xE0], xmm15
00007c454bbe17bb  sub rsp, 0x30
00007c454bbe17bf  movaps [rsp], xmm6
00007c454bbe17c3  movaps [rsp+0x10], xmm9
00007c454bbe17c9  movaps [rsp+0x20], xmm1
00007c454bbe17ce  lea rdi, [rsp]
00007c454bbe17d2  mov esi, 0x00
00007c454bbe17d7  mov rax, 0x56A18AC54530
00007c454bbe17e1  call rax
00007c454bbe17e3  movaps xmm6, [rsp]
00007c454bbe17e7  add rsp, 0x30
00007c454bbe17eb  vmovaps xmm0, [rsp]
00007c454bbe17f0  vmovaps xmm1, [rsp+0x10]
00007c454bbe17f6  vmovaps xmm2, [rsp+0x20]
00007c454bbe17fc  vmovaps xmm3, [rsp+0x30]
00007c454bbe1802  vmovaps xmm4, [rsp+0x40]
00007c454bbe1808  vmovaps xmm5, [rsp+0x50]
00007c454bbe180e  vmovaps xmm7, [rsp+0x60]
00007c454bbe1814  vmovaps xmm8, [rsp+0x70]
00007c454bbe181a  vmovaps xmm9, [rsp+0x80]
00007c454bbe1823  vmovaps xmm10, [rsp+0x90]
00007c454bbe182c  vmovaps xmm11, [rsp+0xA0]
00007c454bbe1835  vmovaps xmm12, [rsp+0xB0]
00007c454bbe183e  vmovaps xmm13, [rsp+0xC0]
00007c454bbe1847  vmovaps xmm14, [rsp+0xD0]
00007c454bbe1850  vmovaps xmm15, [rsp+0xE0]
00007c454bbe1859  add rsp, 0xF0
00007c454bbe1860  pop r11
00007c454bbe1862  pop r10
00007c454bbe1864  pop r9
00007c454bbe1866  pop r8
00007c454bbe1868  pop rsi
00007c454bbe1869  pop rdi
00007c454bbe186a  pop rdx
00007c454bbe186b  pop rcx
00007c454bbe186c  pop rax
00007c454bbe186d  add rsp, 0x08
00007c454bbe1871  jmp 0x00007C454BBDF33E
00007c454bbe1876  sub rsp, 0x08
00007c454bbe187a  push rax
00007c454bbe187b  push rcx
00007c454bbe187c  push rdx
00007c454bbe187d  push rdi
00007c454bbe187e  push rsi
00007c454bbe187f  push r8
00007c454bbe1881  push r9
00007c454bbe1883  push r10
00007c454bbe1885  push r11
00007c454bbe1887  sub rsp, 0xF0
00007c454bbe188e  vmovaps [rsp], xmm0
00007c454bbe1893  vmovaps [rsp+0x10], xmm1
00007c454bbe1899  vmovaps [rsp+0x20], xmm2
00007c454bbe189f  vmovaps [rsp+0x30], xmm3
00007c454bbe18a5  vmovaps [rsp+0x40], xmm4
00007c454bbe18ab  vmovaps [rsp+0x50], xmm5
00007c454bbe18b1  vmovaps [rsp+0x60], xmm6
00007c454bbe18b7  vmovaps [rsp+0x70], xmm7
00007c454bbe18bd  vmovaps [rsp+0x80], xmm8
00007c454bbe18c6  vmovaps [rsp+0x90], xmm10
00007c454bbe18cf  vmovaps [rsp+0xA0], xmm11
00007c454bbe18d8  vmovaps [rsp+0xB0], xmm12
00007c454bbe18e1  vmovaps [rsp+0xC0], xmm13
00007c454bbe18ea  vmovaps [rsp+0xD0], xmm14
00007c454bbe18f3  vmovaps [rsp+0xE0], xmm15
00007c454bbe18fc  sub rsp, 0x30
00007c454bbe1900  movaps [rsp], xmm9
00007c454bbe1905  movaps [rsp+0x10], xmm3
00007c454bbe190a  movaps [rsp+0x20], xmm1
00007c454bbe190f  lea rdi, [rsp]
00007c454bbe1913  mov esi, 0x00
00007c454bbe1918  mov rax, 0x56A18AC54530
00007c454bbe1922  call rax
00007c454bbe1924  movaps xmm9, [rsp]
00007c454bbe1929  add rsp, 0x30
00007c454bbe192d  vmovaps xmm0, [rsp]
00007c454bbe1932  vmovaps xmm1, [rsp+0x10]
00007c454bbe1938  vmovaps xmm2, [rsp+0x20]
00007c454bbe193e  vmovaps xmm3, [rsp+0x30]
00007c454bbe1944  vmovaps xmm4, [rsp+0x40]
00007c454bbe194a  vmovaps xmm5, [rsp+0x50]
00007c454bbe1950  vmovaps xmm6, [rsp+0x60]
00007c454bbe1956  vmovaps xmm7, [rsp+0x70]
00007c454bbe195c  vmovaps xmm8, [rsp+0x80]
00007c454bbe1965  vmovaps xmm10, [rsp+0x90]
00007c454bbe196e  vmovaps xmm11, [rsp+0xA0]
00007c454bbe1977  vmovaps xmm12, [rsp+0xB0]
00007c454bbe1980  vmovaps xmm13, [rsp+0xC0]
00007c454bbe1989  vmovaps xmm14, [rsp+0xD0]
00007c454bbe1992  vmovaps xmm15, [rsp+0xE0]
00007c454bbe199b  add rsp, 0xF0
00007c454bbe19a2  pop r11
00007c454bbe19a4  pop r10
00007c454bbe19a6  pop r9
00007c454bbe19a8  pop r8
00007c454bbe19aa  pop rsi
00007c454bbe19ab  pop rdi
00007c454bbe19ac  pop rdx
00007c454bbe19ad  pop rcx
00007c454bbe19ae  pop rax
00007c454bbe19af  add rsp, 0x08
00007c454bbe19b3  jmp 0x00007C454BBDF38A
00007c454bbe19b8  call 0x00007C454BAB52F0
00007c454bbe19bd  jmp 0x00007C454BBDF397
00007c454bbe19c2  sub rsp, 0x08
00007c454bbe19c6  push rax
00007c454bbe19c7  push rcx
00007c454bbe19c8  push rdx
00007c454bbe19c9  push rdi
00007c454bbe19ca  push rsi
00007c454bbe19cb  push r8
00007c454bbe19cd  push r9
00007c454bbe19cf  push r10
00007c454bbe19d1  push r11
00007c454bbe19d3  sub rsp, 0xF0
00007c454bbe19da  vmovaps [rsp], xmm0
00007c454bbe19df  vmovaps [rsp+0x10], xmm1
00007c454bbe19e5  vmovaps [rsp+0x20], xmm2
00007c454bbe19eb  vmovaps [rsp+0x30], xmm3
00007c454bbe19f1  vmovaps [rsp+0x40], xmm4
00007c454bbe19f7  vmovaps [rsp+0x50], xmm5
00007c454bbe19fd  vmovaps [rsp+0x60], xmm6
00007c454bbe1a03  vmovaps [rsp+0x70], xmm7
00007c454bbe1a09  vmovaps [rsp+0x80], xmm8
00007c454bbe1a12  vmovaps [rsp+0x90], xmm9
00007c454bbe1a1b  vmovaps [rsp+0xA0], xmm10
00007c454bbe1a24  vmovaps [rsp+0xB0], xmm11
00007c454bbe1a2d  vmovaps [rsp+0xC0], xmm12
00007c454bbe1a36  vmovaps [rsp+0xD0], xmm13
00007c454bbe1a3f  vmovaps [rsp+0xE0], xmm14
00007c454bbe1a48  sub rsp, 0x30
00007c454bbe1a4c  movaps [rsp], xmm15
00007c454bbe1a51  movaps [rsp+0x10], xmm3
00007c454bbe1a56  movaps [rsp+0x20], xmm7
00007c454bbe1a5b  lea rdi, [rsp]
00007c454bbe1a5f  mov esi, 0x00
00007c454bbe1a64  mov rax, 0x56A18AC54530
00007c454bbe1a6e  call rax
00007c454bbe1a70  movaps xmm15, [rsp]
00007c454bbe1a75  add rsp, 0x30
00007c454bbe1a79  vmovaps xmm0, [rsp]
00007c454bbe1a7e  vmovaps xmm1, [rsp+0x10]
00007c454bbe1a84  vmovaps xmm2, [rsp+0x20]
00007c454bbe1a8a  vmovaps xmm3, [rsp+0x30]
00007c454bbe1a90  vmovaps xmm4, [rsp+0x40]
00007c454bbe1a96  vmovaps xmm5, [rsp+0x50]
00007c454bbe1a9c  vmovaps xmm6, [rsp+0x60]
00007c454bbe1aa2  vmovaps xmm7, [rsp+0x70]
00007c454bbe1aa8  vmovaps xmm8, [rsp+0x80]
00007c454bbe1ab1  vmovaps xmm9, [rsp+0x90]
00007c454bbe1aba  vmovaps xmm10, [rsp+0xA0]
00007c454bbe1ac3  vmovaps xmm11, [rsp+0xB0]
00007c454bbe1acc  vmovaps xmm12, [rsp+0xC0]
00007c454bbe1ad5  vmovaps xmm13, [rsp+0xD0]
00007c454bbe1ade  vmovaps xmm14, [rsp+0xE0]
00007c454bbe1ae7  add rsp, 0xF0
00007c454bbe1aee  pop r11
00007c454bbe1af0  pop r10
00007c454bbe1af2  pop r9
00007c454bbe1af4  pop r8
00007c454bbe1af6  pop rsi
00007c454bbe1af7  pop rdi
00007c454bbe1af8  pop rdx
00007c454bbe1af9  pop rcx
00007c454bbe1afa  pop rax
00007c454bbe1afb  add rsp, 0x08
00007c454bbe1aff  jmp 0x00007C454BBDF3C3
00007c454bbe1b04  sub rsp, 0x08
00007c454bbe1b08  push rax
00007c454bbe1b09  push rcx
00007c454bbe1b0a  push rdx
00007c454bbe1b0b  push rdi
00007c454bbe1b0c  push rsi
00007c454bbe1b0d  push r8
00007c454bbe1b0f  push r9
00007c454bbe1b11  push r10
00007c454bbe1b13  push r11
00007c454bbe1b15  sub rsp, 0xF0
00007c454bbe1b1c  vmovaps [rsp], xmm0
00007c454bbe1b21  vmovaps [rsp+0x10], xmm1
00007c454bbe1b27  vmovaps [rsp+0x20], xmm2
00007c454bbe1b2d  vmovaps [rsp+0x30], xmm4
00007c454bbe1b33  vmovaps [rsp+0x40], xmm5
00007c454bbe1b39  vmovaps [rsp+0x50], xmm6
00007c454bbe1b3f  vmovaps [rsp+0x60], xmm7
00007c454bbe1b45  vmovaps [rsp+0x70], xmm8
00007c454bbe1b4b  vmovaps [rsp+0x80], xmm9
00007c454bbe1b54  vmovaps [rsp+0x90], xmm10
00007c454bbe1b5d  vmovaps [rsp+0xA0], xmm11
00007c454bbe1b66  vmovaps [rsp+0xB0], xmm12
00007c454bbe1b6f  vmovaps [rsp+0xC0], xmm13
00007c454bbe1b78  vmovaps [rsp+0xD0], xmm14
00007c454bbe1b81  vmovaps [rsp+0xE0], xmm15
00007c454bbe1b8a  sub rsp, 0x30
00007c454bbe1b8e  movaps [rsp], xmm3
00007c454bbe1b92  movaps [rsp+0x10], xmm1
00007c454bbe1b97  movaps [rsp+0x20], xmm15
00007c454bbe1b9d  lea rdi, [rsp]
00007c454bbe1ba1  mov esi, 0x00
00007c454bbe1ba6  mov rax, 0x56A18AC54530
00007c454bbe1bb0  call rax
00007c454bbe1bb2  movaps xmm3, [rsp]
00007c454bbe1bb6  add rsp, 0x30
00007c454bbe1bba  vmovaps xmm0, [rsp]
00007c454bbe1bbf  vmovaps xmm1, [rsp+0x10]
00007c454bbe1bc5  vmovaps xmm2, [rsp+0x20]
00007c454bbe1bcb  vmovaps xmm4, [rsp+0x30]
00007c454bbe1bd1  vmovaps xmm5, [rsp+0x40]
00007c454bbe1bd7  vmovaps xmm6, [rsp+0x50]
00007c454bbe1bdd  vmovaps xmm7, [rsp+0x60]
00007c454bbe1be3  vmovaps xmm8, [rsp+0x70]
00007c454bbe1be9  vmovaps xmm9, [rsp+0x80]
00007c454bbe1bf2  vmovaps xmm10, [rsp+0x90]
00007c454bbe1bfb  vmovaps xmm11, [rsp+0xA0]
00007c454bbe1c04  vmovaps xmm12, [rsp+0xB0]
00007c454bbe1c0d  vmovaps xmm13, [rsp+0xC0]
00007c454bbe1c16  vmovaps xmm14, [rsp+0xD0]
00007c454bbe1c1f  vmovaps xmm15, [rsp+0xE0]
00007c454bbe1c28  add rsp, 0xF0
00007c454bbe1c2f  pop r11
00007c454bbe1c31  pop r10
00007c454bbe1c33  pop r9
00007c454bbe1c35  pop r8
00007c454bbe1c37  pop rsi
00007c454bbe1c38  pop rdi
00007c454bbe1c39  pop rdx
00007c454bbe1c3a  pop rcx
00007c454bbe1c3b  pop rax
00007c454bbe1c3c  add rsp, 0x08
00007c454bbe1c40  jmp 0x00007C454BBDF452
00007c454bbe1c45  call 0x00007C454BAB52F0
00007c454bbe1c4a  jmp 0x00007C454BBDF45C
00007c454bbe1c4f  sub rsp, 0x08
00007c454bbe1c53  push rax
00007c454bbe1c54  push rcx
00007c454bbe1c55  push rdx
00007c454bbe1c56  push rdi
00007c454bbe1c57  push rsi
00007c454bbe1c58  push r8
00007c454bbe1c5a  push r9
00007c454bbe1c5c  push r10
00007c454bbe1c5e  push r11
00007c454bbe1c60  sub rsp, 0xF0
00007c454bbe1c67  vmovaps [rsp], xmm0
00007c454bbe1c6c  vmovaps [rsp+0x10], xmm1
00007c454bbe1c72  vmovaps [rsp+0x20], xmm2
00007c454bbe1c78  vmovaps [rsp+0x30], xmm3
00007c454bbe1c7e  vmovaps [rsp+0x40], xmm4
00007c454bbe1c84  vmovaps [rsp+0x50], xmm5
00007c454bbe1c8a  vmovaps [rsp+0x60], xmm6
00007c454bbe1c90  vmovaps [rsp+0x70], xmm7
00007c454bbe1c96  vmovaps [rsp+0x80], xmm8
00007c454bbe1c9f  vmovaps [rsp+0x90], xmm9
00007c454bbe1ca8  vmovaps [rsp+0xA0], xmm10
00007c454bbe1cb1  vmovaps [rsp+0xB0], xmm11
00007c454bbe1cba  vmovaps [rsp+0xC0], xmm12
00007c454bbe1cc3  vmovaps [rsp+0xD0], xmm13
00007c454bbe1ccc  vmovaps [rsp+0xE0], xmm14
00007c454bbe1cd5  sub rsp, 0x30
00007c454bbe1cd9  movaps [rsp], xmm15
00007c454bbe1cde  movaps [rsp+0x10], xmm14
00007c454bbe1ce4  movaps [rsp+0x20], xmm4
00007c454bbe1ce9  lea rdi, [rsp]
00007c454bbe1ced  mov esi, 0x00
00007c454bbe1cf2  mov rax, 0x56A18AC54530
00007c454bbe1cfc  call rax
00007c454bbe1cfe  movaps xmm15, [rsp]
00007c454bbe1d03  add rsp, 0x30
00007c454bbe1d07  vmovaps xmm0, [rsp]
00007c454bbe1d0c  vmovaps xmm1, [rsp+0x10]
00007c454bbe1d12  vmovaps xmm2, [rsp+0x20]
00007c454bbe1d18  vmovaps xmm3, [rsp+0x30]
00007c454bbe1d1e  vmovaps xmm4, [rsp+0x40]
00007c454bbe1d24  vmovaps xmm5, [rsp+0x50]
00007c454bbe1d2a  vmovaps xmm6, [rsp+0x60]
00007c454bbe1d30  vmovaps xmm7, [rsp+0x70]
00007c454bbe1d36  vmovaps xmm8, [rsp+0x80]
00007c454bbe1d3f  vmovaps xmm9, [rsp+0x90]
00007c454bbe1d48  vmovaps xmm10, [rsp+0xA0]
00007c454bbe1d51  vmovaps xmm11, [rsp+0xB0]
00007c454bbe1d5a  vmovaps xmm12, [rsp+0xC0]
00007c454bbe1d63  vmovaps xmm13, [rsp+0xD0]
00007c454bbe1d6c  vmovaps xmm14, [rsp+0xE0]
00007c454bbe1d75  add rsp, 0xF0
00007c454bbe1d7c  pop r11
00007c454bbe1d7e  pop r10
00007c454bbe1d80  pop r9
00007c454bbe1d82  pop r8
00007c454bbe1d84  pop rsi
00007c454bbe1d85  pop rdi
00007c454bbe1d86  pop rdx
00007c454bbe1d87  pop rcx
00007c454bbe1d88  pop rax
00007c454bbe1d89  add rsp, 0x08
00007c454bbe1d8d  jmp 0x00007C454BBDF48A
00007c454bbe1d92  sub rsp, 0x08
00007c454bbe1d96  push rax
00007c454bbe1d97  push rcx
00007c454bbe1d98  push rdx
00007c454bbe1d99  push rdi
00007c454bbe1d9a  push rsi
00007c454bbe1d9b  push r8
00007c454bbe1d9d  push r9
00007c454bbe1d9f  push r10
00007c454bbe1da1  push r11
00007c454bbe1da3  sub rsp, 0xF0
00007c454bbe1daa  vmovaps [rsp], xmm0
00007c454bbe1daf  vmovaps [rsp+0x10], xmm1
00007c454bbe1db5  vmovaps [rsp+0x20], xmm2
00007c454bbe1dbb  vmovaps [rsp+0x30], xmm3
00007c454bbe1dc1  vmovaps [rsp+0x40], xmm4
00007c454bbe1dc7  vmovaps [rsp+0x50], xmm5
00007c454bbe1dcd  vmovaps [rsp+0x60], xmm6
00007c454bbe1dd3  vmovaps [rsp+0x70], xmm7
00007c454bbe1dd9  vmovaps [rsp+0x80], xmm8
00007c454bbe1de2  vmovaps [rsp+0x90], xmm9
00007c454bbe1deb  vmovaps [rsp+0xA0], xmm10
00007c454bbe1df4  vmovaps [rsp+0xB0], xmm11
00007c454bbe1dfd  vmovaps [rsp+0xC0], xmm12
00007c454bbe1e06  vmovaps [rsp+0xD0], xmm13
00007c454bbe1e0f  vmovaps [rsp+0xE0], xmm15
00007c454bbe1e18  sub rsp, 0x30
00007c454bbe1e1c  movaps [rsp], xmm14
00007c454bbe1e21  movaps [rsp+0x10], xmm2
00007c454bbe1e26  movaps [rsp+0x20], xmm1
00007c454bbe1e2b  lea rdi, [rsp]
00007c454bbe1e2f  mov esi, 0x00
00007c454bbe1e34  mov rax, 0x56A18AC54530
00007c454bbe1e3e  call rax
00007c454bbe1e40  movaps xmm14, [rsp]
00007c454bbe1e45  add rsp, 0x30
00007c454bbe1e49  vmovaps xmm0, [rsp]
00007c454bbe1e4e  vmovaps xmm1, [rsp+0x10]
00007c454bbe1e54  vmovaps xmm2, [rsp+0x20]
00007c454bbe1e5a  vmovaps xmm3, [rsp+0x30]
00007c454bbe1e60  vmovaps xmm4, [rsp+0x40]
00007c454bbe1e66  vmovaps xmm5, [rsp+0x50]
00007c454bbe1e6c  vmovaps xmm6, [rsp+0x60]
00007c454bbe1e72  vmovaps xmm7, [rsp+0x70]
00007c454bbe1e78  vmovaps xmm8, [rsp+0x80]
00007c454bbe1e81  vmovaps xmm9, [rsp+0x90]
00007c454bbe1e8a  vmovaps xmm10, [rsp+0xA0]
00007c454bbe1e93  vmovaps xmm11, [rsp+0xB0]
00007c454bbe1e9c  vmovaps xmm12, [rsp+0xC0]
00007c454bbe1ea5  vmovaps xmm13, [rsp+0xD0]
00007c454bbe1eae  vmovaps xmm15, [rsp+0xE0]
00007c454bbe1eb7  add rsp, 0xF0
00007c454bbe1ebe  pop r11
00007c454bbe1ec0  pop r10
00007c454bbe1ec2  pop r9
00007c454bbe1ec4  pop r8
00007c454bbe1ec6  pop rsi
00007c454bbe1ec7  pop rdi
00007c454bbe1ec8  pop rdx
00007c454bbe1ec9  pop rcx
00007c454bbe1eca  pop rax
00007c454bbe1ecb  add rsp, 0x08
00007c454bbe1ecf  jmp 0x00007C454BBDF4B0
00007c454bbe1ed4  sub rsp, 0x08
00007c454bbe1ed8  push rax
00007c454bbe1ed9  push rcx
00007c454bbe1eda  push rdx
00007c454bbe1edb  push rdi
00007c454bbe1edc  push rsi
00007c454bbe1edd  push r8
00007c454bbe1edf  push r9
00007c454bbe1ee1  push r10
00007c454bbe1ee3  push r11
00007c454bbe1ee5  sub rsp, 0xF0
00007c454bbe1eec  vmovaps [rsp], xmm0
00007c454bbe1ef1  vmovaps [rsp+0x10], xmm2
00007c454bbe1ef7  vmovaps [rsp+0x20], xmm3
00007c454bbe1efd  vmovaps [rsp+0x30], xmm4
00007c454bbe1f03  vmovaps [rsp+0x40], xmm5
00007c454bbe1f09  vmovaps [rsp+0x50], xmm6
00007c454bbe1f0f  vmovaps [rsp+0x60], xmm7
00007c454bbe1f15  vmovaps [rsp+0x70], xmm8
00007c454bbe1f1b  vmovaps [rsp+0x80], xmm9
00007c454bbe1f24  vmovaps [rsp+0x90], xmm10
00007c454bbe1f2d  vmovaps [rsp+0xA0], xmm11
00007c454bbe1f36  vmovaps [rsp+0xB0], xmm12
00007c454bbe1f3f  vmovaps [rsp+0xC0], xmm13
00007c454bbe1f48  vmovaps [rsp+0xD0], xmm14
00007c454bbe1f51  vmovaps [rsp+0xE0], xmm15
00007c454bbe1f5a  sub rsp, 0x30
00007c454bbe1f5e  movaps [rsp], xmm1
00007c454bbe1f62  movaps [rsp+0x10], xmm4
00007c454bbe1f67  movaps [rsp+0x20], xmm9
00007c454bbe1f6d  lea rdi, [rsp]
00007c454bbe1f71  mov esi, 0x00
00007c454bbe1f76  mov rax, 0x56A18AC54530
00007c454bbe1f80  call rax
00007c454bbe1f82  movaps xmm1, [rsp]
00007c454bbe1f86  add rsp, 0x30
00007c454bbe1f8a  vmovaps xmm0, [rsp]
00007c454bbe1f8f  vmovaps xmm2, [rsp+0x10]
00007c454bbe1f95  vmovaps xmm3, [rsp+0x20]
00007c454bbe1f9b  vmovaps xmm4, [rsp+0x30]
00007c454bbe1fa1  vmovaps xmm5, [rsp+0x40]
00007c454bbe1fa7  vmovaps xmm6, [rsp+0x50]
00007c454bbe1fad  vmovaps xmm7, [rsp+0x60]
00007c454bbe1fb3  vmovaps xmm8, [rsp+0x70]
00007c454bbe1fb9  vmovaps xmm9, [rsp+0x80]
00007c454bbe1fc2  vmovaps xmm10, [rsp+0x90]
00007c454bbe1fcb  vmovaps xmm11, [rsp+0xA0]
00007c454bbe1fd4  vmovaps xmm12, [rsp+0xB0]
00007c454bbe1fdd  vmovaps xmm13, [rsp+0xC0]
00007c454bbe1fe6  vmovaps xmm14, [rsp+0xD0]
00007c454bbe1fef  vmovaps xmm15, [rsp+0xE0]
00007c454bbe1ff8  add rsp, 0xF0
00007c454bbe1fff  pop r11
00007c454bbe2001  pop r10
00007c454bbe2003  pop r9
00007c454bbe2005  pop r8
00007c454bbe2007  pop rsi
00007c454bbe2008  pop rdi
00007c454bbe2009  pop rdx
00007c454bbe200a  pop rcx
00007c454bbe200b  pop rax
00007c454bbe200c  add rsp, 0x08
00007c454bbe2010  jmp 0x00007C454BBDF4CE
00007c454bbe2015  sub rsp, 0x08
00007c454bbe2019  push rax
00007c454bbe201a  push rcx
00007c454bbe201b  push rdx
00007c454bbe201c  push rdi
00007c454bbe201d  push rsi
00007c454bbe201e  push r8
00007c454bbe2020  push r9
00007c454bbe2022  push r10
00007c454bbe2024  push r11
00007c454bbe2026  sub rsp, 0xF0
00007c454bbe202d  vmovaps [rsp], xmm0
00007c454bbe2032  vmovaps [rsp+0x10], xmm1
00007c454bbe2038  vmovaps [rsp+0x20], xmm2
00007c454bbe203e  vmovaps [rsp+0x30], xmm3
00007c454bbe2044  vmovaps [rsp+0x40], xmm5
00007c454bbe204a  vmovaps [rsp+0x50], xmm6
00007c454bbe2050  vmovaps [rsp+0x60], xmm7
00007c454bbe2056  vmovaps [rsp+0x70], xmm8
00007c454bbe205c  vmovaps [rsp+0x80], xmm9
00007c454bbe2065  vmovaps [rsp+0x90], xmm10
00007c454bbe206e  vmovaps [rsp+0xA0], xmm11
00007c454bbe2077  vmovaps [rsp+0xB0], xmm12
00007c454bbe2080  vmovaps [rsp+0xC0], xmm13
00007c454bbe2089  vmovaps [rsp+0xD0], xmm14
00007c454bbe2092  vmovaps [rsp+0xE0], xmm15
00007c454bbe209b  sub rsp, 0x30
00007c454bbe209f  movaps [rsp], xmm4
00007c454bbe20a3  movaps [rsp+0x10], xmm2
00007c454bbe20a8  movaps [rsp+0x20], xmm9
00007c454bbe20ae  lea rdi, [rsp]
00007c454bbe20b2  mov esi, 0x00
00007c454bbe20b7  mov rax, 0x56A18AC54530
00007c454bbe20c1  call rax
00007c454bbe20c3  movaps xmm4, [rsp]
00007c454bbe20c7  add rsp, 0x30
00007c454bbe20cb  vmovaps xmm0, [rsp]
00007c454bbe20d0  vmovaps xmm1, [rsp+0x10]
00007c454bbe20d6  vmovaps xmm2, [rsp+0x20]
00007c454bbe20dc  vmovaps xmm3, [rsp+0x30]
00007c454bbe20e2  vmovaps xmm5, [rsp+0x40]
00007c454bbe20e8  vmovaps xmm6, [rsp+0x50]
00007c454bbe20ee  vmovaps xmm7, [rsp+0x60]
00007c454bbe20f4  vmovaps xmm8, [rsp+0x70]
00007c454bbe20fa  vmovaps xmm9, [rsp+0x80]
00007c454bbe2103  vmovaps xmm10, [rsp+0x90]
00007c454bbe210c  vmovaps xmm11, [rsp+0xA0]
00007c454bbe2115  vmovaps xmm12, [rsp+0xB0]
00007c454bbe211e  vmovaps xmm13, [rsp+0xC0]
00007c454bbe2127  vmovaps xmm14, [rsp+0xD0]
00007c454bbe2130  vmovaps xmm15, [rsp+0xE0]
00007c454bbe2139  add rsp, 0xF0
00007c454bbe2140  pop r11
00007c454bbe2142  pop r10
00007c454bbe2144  pop r9
00007c454bbe2146  pop r8
00007c454bbe2148  pop rsi
00007c454bbe2149  pop rdi
00007c454bbe214a  pop rdx
00007c454bbe214b  pop rcx
00007c454bbe214c  pop rax
00007c454bbe214d  add rsp, 0x08
00007c454bbe2151  jmp 0x00007C454BBDF4FE
00007c454bbe2156  sub rsp, 0x08
00007c454bbe215a  push rax
00007c454bbe215b  push rcx
00007c454bbe215c  push rdx
00007c454bbe215d  push rdi
00007c454bbe215e  push rsi
00007c454bbe215f  push r8
00007c454bbe2161  push r9
00007c454bbe2163  push r10
00007c454bbe2165  push r11
00007c454bbe2167  sub rsp, 0xF0
00007c454bbe216e  vmovaps [rsp], xmm0
00007c454bbe2173  vmovaps [rsp+0x10], xmm1
00007c454bbe2179  vmovaps [rsp+0x20], xmm2
00007c454bbe217f  vmovaps [rsp+0x30], xmm3
00007c454bbe2185  vmovaps [rsp+0x40], xmm4
00007c454bbe218b  vmovaps [rsp+0x50], xmm5
00007c454bbe2191  vmovaps [rsp+0x60], xmm6
00007c454bbe2197  vmovaps [rsp+0x70], xmm7
00007c454bbe219d  vmovaps [rsp+0x80], xmm8
00007c454bbe21a6  vmovaps [rsp+0x90], xmm10
00007c454bbe21af  vmovaps [rsp+0xA0], xmm11
00007c454bbe21b8  vmovaps [rsp+0xB0], xmm12
00007c454bbe21c1  vmovaps [rsp+0xC0], xmm13
00007c454bbe21ca  vmovaps [rsp+0xD0], xmm14
00007c454bbe21d3  vmovaps [rsp+0xE0], xmm15
00007c454bbe21dc  sub rsp, 0x30
00007c454bbe21e0  movaps [rsp], xmm9
00007c454bbe21e5  movaps [rsp+0x10], xmm2
00007c454bbe21ea  movaps [rsp+0x20], xmm1
00007c454bbe21ef  lea rdi, [rsp]
00007c454bbe21f3  mov esi, 0x00
00007c454bbe21f8  mov rax, 0x56A18AC54530
00007c454bbe2202  call rax
00007c454bbe2204  movaps xmm9, [rsp]
00007c454bbe2209  add rsp, 0x30
00007c454bbe220d  vmovaps xmm0, [rsp]
00007c454bbe2212  vmovaps xmm1, [rsp+0x10]
00007c454bbe2218  vmovaps xmm2, [rsp+0x20]
00007c454bbe221e  vmovaps xmm3, [rsp+0x30]
00007c454bbe2224  vmovaps xmm4, [rsp+0x40]
00007c454bbe222a  vmovaps xmm5, [rsp+0x50]
00007c454bbe2230  vmovaps xmm6, [rsp+0x60]
00007c454bbe2236  vmovaps xmm7, [rsp+0x70]
00007c454bbe223c  vmovaps xmm8, [rsp+0x80]
00007c454bbe2245  vmovaps xmm10, [rsp+0x90]
00007c454bbe224e  vmovaps xmm11, [rsp+0xA0]
00007c454bbe2257  vmovaps xmm12, [rsp+0xB0]
00007c454bbe2260  vmovaps xmm13, [rsp+0xC0]
00007c454bbe2269  vmovaps xmm14, [rsp+0xD0]
00007c454bbe2272  vmovaps xmm15, [rsp+0xE0]
00007c454bbe227b  add rsp, 0xF0
00007c454bbe2282  pop r11
00007c454bbe2284  pop r10
00007c454bbe2286  pop r9
00007c454bbe2288  pop r8
00007c454bbe228a  pop rsi
00007c454bbe228b  pop rdi
00007c454bbe228c  pop rdx
00007c454bbe228d  pop rcx
00007c454bbe228e  pop rax
00007c454bbe228f  add rsp, 0x08
00007c454bbe2293  jmp 0x00007C454BBDF534
00007c454bbe2298  sub rsp, 0x08
00007c454bbe229c  push rax
00007c454bbe229d  push rcx
00007c454bbe229e  push rdx
00007c454bbe229f  push rdi
00007c454bbe22a0  push rsi
00007c454bbe22a1  push r8
00007c454bbe22a3  push r9
00007c454bbe22a5  push r10
00007c454bbe22a7  push r11
00007c454bbe22a9  sub rsp, 0xF0
00007c454bbe22b0  vmovaps [rsp], xmm0
00007c454bbe22b5  vmovaps [rsp+0x10], xmm2
00007c454bbe22bb  vmovaps [rsp+0x20], xmm3
00007c454bbe22c1  vmovaps [rsp+0x30], xmm4
00007c454bbe22c7  vmovaps [rsp+0x40], xmm5
00007c454bbe22cd  vmovaps [rsp+0x50], xmm6
00007c454bbe22d3  vmovaps [rsp+0x60], xmm7
00007c454bbe22d9  vmovaps [rsp+0x70], xmm8
00007c454bbe22df  vmovaps [rsp+0x80], xmm9
00007c454bbe22e8  vmovaps [rsp+0x90], xmm10
00007c454bbe22f1  vmovaps [rsp+0xA0], xmm11
00007c454bbe22fa  vmovaps [rsp+0xB0], xmm12
00007c454bbe2303  vmovaps [rsp+0xC0], xmm13
00007c454bbe230c  vmovaps [rsp+0xD0], xmm14
00007c454bbe2315  vmovaps [rsp+0xE0], xmm15
00007c454bbe231e  sub rsp, 0x30
00007c454bbe2322  movaps [rsp], xmm1
00007c454bbe2326  movaps [rsp+0x10], xmm15
00007c454bbe232c  movaps [rsp+0x20], xmm6
00007c454bbe2331  lea rdi, [rsp]
00007c454bbe2335  mov esi, 0x00
00007c454bbe233a  mov rax, 0x56A18AC54530
00007c454bbe2344  call rax
00007c454bbe2346  movaps xmm1, [rsp]
00007c454bbe234a  add rsp, 0x30
00007c454bbe234e  vmovaps xmm0, [rsp]
00007c454bbe2353  vmovaps xmm2, [rsp+0x10]
00007c454bbe2359  vmovaps xmm3, [rsp+0x20]
00007c454bbe235f  vmovaps xmm4, [rsp+0x30]
00007c454bbe2365  vmovaps xmm5, [rsp+0x40]
00007c454bbe236b  vmovaps xmm6, [rsp+0x50]
00007c454bbe2371  vmovaps xmm7, [rsp+0x60]
00007c454bbe2377  vmovaps xmm8, [rsp+0x70]
00007c454bbe237d  vmovaps xmm9, [rsp+0x80]
00007c454bbe2386  vmovaps xmm10, [rsp+0x90]
00007c454bbe238f  vmovaps xmm11, [rsp+0xA0]
00007c454bbe2398  vmovaps xmm12, [rsp+0xB0]
00007c454bbe23a1  vmovaps xmm13, [rsp+0xC0]
00007c454bbe23aa  vmovaps xmm14, [rsp+0xD0]
00007c454bbe23b3  vmovaps xmm15, [rsp+0xE0]
00007c454bbe23bc  add rsp, 0xF0
00007c454bbe23c3  pop r11
00007c454bbe23c5  pop r10
00007c454bbe23c7  pop r9
00007c454bbe23c9  pop r8
00007c454bbe23cb  pop rsi
00007c454bbe23cc  pop rdi
00007c454bbe23cd  pop rdx
00007c454bbe23ce  pop rcx
00007c454bbe23cf  pop rax
00007c454bbe23d0  add rsp, 0x08
00007c454bbe23d4  jmp 0x00007C454BBDF555
00007c454bbe23d9  sub rsp, 0x08
00007c454bbe23dd  push rax
00007c454bbe23de  push rcx
00007c454bbe23df  push rdx
00007c454bbe23e0  push rdi
00007c454bbe23e1  push rsi
00007c454bbe23e2  push r8
00007c454bbe23e4  push r9
00007c454bbe23e6  push r10
00007c454bbe23e8  push r11
00007c454bbe23ea  sub rsp, 0xF0
00007c454bbe23f1  vmovaps [rsp], xmm0
00007c454bbe23f6  vmovaps [rsp+0x10], xmm1
00007c454bbe23fc  vmovaps [rsp+0x20], xmm2
00007c454bbe2402  vmovaps [rsp+0x30], xmm3
00007c454bbe2408  vmovaps [rsp+0x40], xmm4
00007c454bbe240e  vmovaps [rsp+0x50], xmm5
00007c454bbe2414  vmovaps [rsp+0x60], xmm6
00007c454bbe241a  vmovaps [rsp+0x70], xmm7
00007c454bbe2420  vmovaps [rsp+0x80], xmm8
00007c454bbe2429  vmovaps [rsp+0x90], xmm9
00007c454bbe2432  vmovaps [rsp+0xA0], xmm10
00007c454bbe243b  vmovaps [rsp+0xB0], xmm11
00007c454bbe2444  vmovaps [rsp+0xC0], xmm12
00007c454bbe244d  vmovaps [rsp+0xD0], xmm13
00007c454bbe2456  vmovaps [rsp+0xE0], xmm14
00007c454bbe245f  sub rsp, 0x30
00007c454bbe2463  movaps [rsp], xmm15
00007c454bbe2468  movaps [rsp+0x10], xmm5
00007c454bbe246d  movaps [rsp+0x20], xmm3
00007c454bbe2472  lea rdi, [rsp]
00007c454bbe2476  mov esi, 0x00
00007c454bbe247b  mov rax, 0x56A18AC54530
00007c454bbe2485  call rax
00007c454bbe2487  movaps xmm15, [rsp]
00007c454bbe248c  add rsp, 0x30
00007c454bbe2490  vmovaps xmm0, [rsp]
00007c454bbe2495  vmovaps xmm1, [rsp+0x10]
00007c454bbe249b  vmovaps xmm2, [rsp+0x20]
00007c454bbe24a1  vmovaps xmm3, [rsp+0x30]
00007c454bbe24a7  vmovaps xmm4, [rsp+0x40]
00007c454bbe24ad  vmovaps xmm5, [rsp+0x50]
00007c454bbe24b3  vmovaps xmm6, [rsp+0x60]
00007c454bbe24b9  vmovaps xmm7, [rsp+0x70]
00007c454bbe24bf  vmovaps xmm8, [rsp+0x80]
00007c454bbe24c8  vmovaps xmm9, [rsp+0x90]
00007c454bbe24d1  vmovaps xmm10, [rsp+0xA0]
00007c454bbe24da  vmovaps xmm11, [rsp+0xB0]
00007c454bbe24e3  vmovaps xmm12, [rsp+0xC0]
00007c454bbe24ec  vmovaps xmm13, [rsp+0xD0]
00007c454bbe24f5  vmovaps xmm14, [rsp+0xE0]
00007c454bbe24fe  add rsp, 0xF0
00007c454bbe2505  pop r11
00007c454bbe2507  pop r10
00007c454bbe2509  pop r9
00007c454bbe250b  pop r8
00007c454bbe250d  pop rsi
00007c454bbe250e  pop rdi
00007c454bbe250f  pop rdx
00007c454bbe2510  pop rcx
00007c454bbe2511  pop rax
00007c454bbe2512  add rsp, 0x08
00007c454bbe2516  jmp 0x00007C454BBDF56F
00007c454bbe251b  sub rsp, 0x08
00007c454bbe251f  push rax
00007c454bbe2520  push rcx
00007c454bbe2521  push rdx
00007c454bbe2522  push rdi
00007c454bbe2523  push rsi
00007c454bbe2524  push r8
00007c454bbe2526  push r9
00007c454bbe2528  push r10
00007c454bbe252a  push r11
00007c454bbe252c  sub rsp, 0xF0
00007c454bbe2533  vmovaps [rsp], xmm0
00007c454bbe2538  vmovaps [rsp+0x10], xmm1
00007c454bbe253e  vmovaps [rsp+0x20], xmm2
00007c454bbe2544  vmovaps [rsp+0x30], xmm3
00007c454bbe254a  vmovaps [rsp+0x40], xmm4
00007c454bbe2550  vmovaps [rsp+0x50], xmm6
00007c454bbe2556  vmovaps [rsp+0x60], xmm7
00007c454bbe255c  vmovaps [rsp+0x70], xmm8
00007c454bbe2562  vmovaps [rsp+0x80], xmm9
00007c454bbe256b  vmovaps [rsp+0x90], xmm10
00007c454bbe2574  vmovaps [rsp+0xA0], xmm11
00007c454bbe257d  vmovaps [rsp+0xB0], xmm12
00007c454bbe2586  vmovaps [rsp+0xC0], xmm13
00007c454bbe258f  vmovaps [rsp+0xD0], xmm14
00007c454bbe2598  vmovaps [rsp+0xE0], xmm15
00007c454bbe25a1  sub rsp, 0x30
00007c454bbe25a5  movaps [rsp], xmm5
00007c454bbe25a9  movaps [rsp+0x10], xmm8
00007c454bbe25af  movaps [rsp+0x20], xmm6
00007c454bbe25b4  lea rdi, [rsp]
00007c454bbe25b8  mov esi, 0x00
00007c454bbe25bd  mov rax, 0x56A18AC54530
00007c454bbe25c7  call rax
00007c454bbe25c9  movaps xmm5, [rsp]
00007c454bbe25cd  add rsp, 0x30
00007c454bbe25d1  vmovaps xmm0, [rsp]
00007c454bbe25d6  vmovaps xmm1, [rsp+0x10]
00007c454bbe25dc  vmovaps xmm2, [rsp+0x20]
00007c454bbe25e2  vmovaps xmm3, [rsp+0x30]
00007c454bbe25e8  vmovaps xmm4, [rsp+0x40]
00007c454bbe25ee  vmovaps xmm6, [rsp+0x50]
00007c454bbe25f4  vmovaps xmm7, [rsp+0x60]
00007c454bbe25fa  vmovaps xmm8, [rsp+0x70]
00007c454bbe2600  vmovaps xmm9, [rsp+0x80]
00007c454bbe2609  vmovaps xmm10, [rsp+0x90]
00007c454bbe2612  vmovaps xmm11, [rsp+0xA0]
00007c454bbe261b  vmovaps xmm12, [rsp+0xB0]
00007c454bbe2624  vmovaps xmm13, [rsp+0xC0]
00007c454bbe262d  vmovaps xmm14, [rsp+0xD0]
00007c454bbe2636  vmovaps xmm15, [rsp+0xE0]
00007c454bbe263f  add rsp, 0xF0
00007c454bbe2646  pop r11
00007c454bbe2648  pop r10
00007c454bbe264a  pop r9
00007c454bbe264c  pop r8
00007c454bbe264e  pop rsi
00007c454bbe264f  pop rdi
00007c454bbe2650  pop rdx
00007c454bbe2651  pop rcx
00007c454bbe2652  pop rax
00007c454bbe2653  add rsp, 0x08
00007c454bbe2657  jmp 0x00007C454BBDF593
00007c454bbe265c  sub rsp, 0x08
00007c454bbe2660  push rax
00007c454bbe2661  push rcx
00007c454bbe2662  push rdx
00007c454bbe2663  push rdi
00007c454bbe2664  push rsi
00007c454bbe2665  push r8
00007c454bbe2667  push r9
00007c454bbe2669  push r10
00007c454bbe266b  push r11
00007c454bbe266d  sub rsp, 0xF0
00007c454bbe2674  vmovaps [rsp], xmm0
00007c454bbe2679  vmovaps [rsp+0x10], xmm1
00007c454bbe267f  vmovaps [rsp+0x20], xmm2
00007c454bbe2685  vmovaps [rsp+0x30], xmm3
00007c454bbe268b  vmovaps [rsp+0x40], xmm4
00007c454bbe2691  vmovaps [rsp+0x50], xmm5
00007c454bbe2697  vmovaps [rsp+0x60], xmm7
00007c454bbe269d  vmovaps [rsp+0x70], xmm8
00007c454bbe26a3  vmovaps [rsp+0x80], xmm9
00007c454bbe26ac  vmovaps [rsp+0x90], xmm10
00007c454bbe26b5  vmovaps [rsp+0xA0], xmm11
00007c454bbe26be  vmovaps [rsp+0xB0], xmm12
00007c454bbe26c7  vmovaps [rsp+0xC0], xmm13
00007c454bbe26d0  vmovaps [rsp+0xD0], xmm14
00007c454bbe26d9  vmovaps [rsp+0xE0], xmm15
00007c454bbe26e2  sub rsp, 0x30
00007c454bbe26e6  movaps [rsp], xmm6
00007c454bbe26ea  movaps [rsp+0x10], xmm10
00007c454bbe26f0  movaps [rsp+0x20], xmm8
00007c454bbe26f6  lea rdi, [rsp]
00007c454bbe26fa  mov esi, 0x00
00007c454bbe26ff  mov rax, 0x56A18AC54530
00007c454bbe2709  call rax
00007c454bbe270b  movaps xmm6, [rsp]
00007c454bbe270f  add rsp, 0x30
00007c454bbe2713  vmovaps xmm0, [rsp]
00007c454bbe2718  vmovaps xmm1, [rsp+0x10]
00007c454bbe271e  vmovaps xmm2, [rsp+0x20]
00007c454bbe2724  vmovaps xmm3, [rsp+0x30]
00007c454bbe272a  vmovaps xmm4, [rsp+0x40]
00007c454bbe2730  vmovaps xmm5, [rsp+0x50]
00007c454bbe2736  vmovaps xmm7, [rsp+0x60]
00007c454bbe273c  vmovaps xmm8, [rsp+0x70]
00007c454bbe2742  vmovaps xmm9, [rsp+0x80]
00007c454bbe274b  vmovaps xmm10, [rsp+0x90]
00007c454bbe2754  vmovaps xmm11, [rsp+0xA0]
00007c454bbe275d  vmovaps xmm12, [rsp+0xB0]
00007c454bbe2766  vmovaps xmm13, [rsp+0xC0]
00007c454bbe276f  vmovaps xmm14, [rsp+0xD0]
00007c454bbe2778  vmovaps xmm15, [rsp+0xE0]
00007c454bbe2781  add rsp, 0xF0
00007c454bbe2788  pop r11
00007c454bbe278a  pop r10
00007c454bbe278c  pop r9
00007c454bbe278e  pop r8
00007c454bbe2790  pop rsi
00007c454bbe2791  pop rdi
00007c454bbe2792  pop rdx
00007c454bbe2793  pop rcx
00007c454bbe2794  pop rax
00007c454bbe2795  add rsp, 0x08
00007c454bbe2799  jmp 0x00007C454BBDF5B8
00007c454bbe279e  sub rsp, 0x08
00007c454bbe27a2  push rax
00007c454bbe27a3  push rcx
00007c454bbe27a4  push rdx
00007c454bbe27a5  push rdi
00007c454bbe27a6  push rsi
00007c454bbe27a7  push r8
00007c454bbe27a9  push r9
00007c454bbe27ab  push r10
00007c454bbe27ad  push r11
00007c454bbe27af  sub rsp, 0xF0
00007c454bbe27b6  vmovaps [rsp], xmm0
00007c454bbe27bb  vmovaps [rsp+0x10], xmm1
00007c454bbe27c1  vmovaps [rsp+0x20], xmm2
00007c454bbe27c7  vmovaps [rsp+0x30], xmm3
00007c454bbe27cd  vmovaps [rsp+0x40], xmm4
00007c454bbe27d3  vmovaps [rsp+0x50], xmm5
00007c454bbe27d9  vmovaps [rsp+0x60], xmm6
00007c454bbe27df  vmovaps [rsp+0x70], xmm7
00007c454bbe27e5  vmovaps [rsp+0x80], xmm8
00007c454bbe27ee  vmovaps [rsp+0x90], xmm9
00007c454bbe27f7  vmovaps [rsp+0xA0], xmm11
00007c454bbe2800  vmovaps [rsp+0xB0], xmm12
00007c454bbe2809  vmovaps [rsp+0xC0], xmm13
00007c454bbe2812  vmovaps [rsp+0xD0], xmm14
00007c454bbe281b  vmovaps [rsp+0xE0], xmm15
00007c454bbe2824  sub rsp, 0x30
00007c454bbe2828  movaps [rsp], xmm10
00007c454bbe282d  movaps [rsp+0x10], xmm8
00007c454bbe2833  movaps [rsp+0x20], xmm14
00007c454bbe2839  lea rdi, [rsp]
00007c454bbe283d  mov esi, 0x00
00007c454bbe2842  mov rax, 0x56A18AC54530
00007c454bbe284c  call rax
00007c454bbe284e  movaps xmm10, [rsp]
00007c454bbe2853  add rsp, 0x30
00007c454bbe2857  vmovaps xmm0, [rsp]
00007c454bbe285c  vmovaps xmm1, [rsp+0x10]
00007c454bbe2862  vmovaps xmm2, [rsp+0x20]
00007c454bbe2868  vmovaps xmm3, [rsp+0x30]
00007c454bbe286e  vmovaps xmm4, [rsp+0x40]
00007c454bbe2874  vmovaps xmm5, [rsp+0x50]
00007c454bbe287a  vmovaps xmm6, [rsp+0x60]
00007c454bbe2880  vmovaps xmm7, [rsp+0x70]
00007c454bbe2886  vmovaps xmm8, [rsp+0x80]
00007c454bbe288f  vmovaps xmm9, [rsp+0x90]
00007c454bbe2898  vmovaps xmm11, [rsp+0xA0]
00007c454bbe28a1  vmovaps xmm12, [rsp+0xB0]
00007c454bbe28aa  vmovaps xmm13, [rsp+0xC0]
00007c454bbe28b3  vmovaps xmm14, [rsp+0xD0]
00007c454bbe28bc  vmovaps xmm15, [rsp+0xE0]
00007c454bbe28c5  add rsp, 0xF0
00007c454bbe28cc  pop r11
00007c454bbe28ce  pop r10
00007c454bbe28d0  pop r9
00007c454bbe28d2  pop r8
00007c454bbe28d4  pop rsi
00007c454bbe28d5  pop rdi
00007c454bbe28d6  pop rdx
00007c454bbe28d7  pop rcx
00007c454bbe28d8  pop rax
00007c454bbe28d9  add rsp, 0x08
00007c454bbe28dd  jmp 0x00007C454BBDF5D8
00007c454bbe28e2  sub rsp, 0x08
00007c454bbe28e6  push rax
00007c454bbe28e7  push rcx
00007c454bbe28e8  push rdx
00007c454bbe28e9  push rdi
00007c454bbe28ea  push rsi
00007c454bbe28eb  push r8
00007c454bbe28ed  push r9
00007c454bbe28ef  push r10
00007c454bbe28f1  push r11
00007c454bbe28f3  sub rsp, 0xF0
00007c454bbe28fa  vmovaps [rsp], xmm0
00007c454bbe28ff  vmovaps [rsp+0x10], xmm1
00007c454bbe2905  vmovaps [rsp+0x20], xmm2
00007c454bbe290b  vmovaps [rsp+0x30], xmm3
00007c454bbe2911  vmovaps [rsp+0x40], xmm4
00007c454bbe2917  vmovaps [rsp+0x50], xmm5
00007c454bbe291d  vmovaps [rsp+0x60], xmm6
00007c454bbe2923  vmovaps [rsp+0x70], xmm7
00007c454bbe2929  vmovaps [rsp+0x80], xmm8
00007c454bbe2932  vmovaps [rsp+0x90], xmm9
00007c454bbe293b  vmovaps [rsp+0xA0], xmm10
00007c454bbe2944  vmovaps [rsp+0xB0], xmm11
00007c454bbe294d  vmovaps [rsp+0xC0], xmm12
00007c454bbe2956  vmovaps [rsp+0xD0], xmm13
00007c454bbe295f  vmovaps [rsp+0xE0], xmm15
00007c454bbe2968  sub rsp, 0x30
00007c454bbe296c  movaps [rsp], xmm14
00007c454bbe2971  movaps [rsp+0x10], xmm8
00007c454bbe2977  movaps [rsp+0x20], xmm4
00007c454bbe297c  lea rdi, [rsp]
00007c454bbe2980  mov esi, 0x00
00007c454bbe2985  mov rax, 0x56A18AC54530
00007c454bbe298f  call rax
00007c454bbe2991  movaps xmm14, [rsp]
00007c454bbe2996  add rsp, 0x30
00007c454bbe299a  vmovaps xmm0, [rsp]
00007c454bbe299f  vmovaps xmm1, [rsp+0x10]
00007c454bbe29a5  vmovaps xmm2, [rsp+0x20]
00007c454bbe29ab  vmovaps xmm3, [rsp+0x30]
00007c454bbe29b1  vmovaps xmm4, [rsp+0x40]
00007c454bbe29b7  vmovaps xmm5, [rsp+0x50]
00007c454bbe29bd  vmovaps xmm6, [rsp+0x60]
00007c454bbe29c3  vmovaps xmm7, [rsp+0x70]
00007c454bbe29c9  vmovaps xmm8, [rsp+0x80]
00007c454bbe29d2  vmovaps xmm9, [rsp+0x90]
00007c454bbe29db  vmovaps xmm10, [rsp+0xA0]
00007c454bbe29e4  vmovaps xmm11, [rsp+0xB0]
00007c454bbe29ed  vmovaps xmm12, [rsp+0xC0]
00007c454bbe29f6  vmovaps xmm13, [rsp+0xD0]
00007c454bbe29ff  vmovaps xmm15, [rsp+0xE0]
00007c454bbe2a08  add rsp, 0xF0
00007c454bbe2a0f  pop r11
00007c454bbe2a11  pop r10
00007c454bbe2a13  pop r9
00007c454bbe2a15  pop r8
00007c454bbe2a17  pop rsi
00007c454bbe2a18  pop rdi
00007c454bbe2a19  pop rdx
00007c454bbe2a1a  pop rcx
00007c454bbe2a1b  pop rax
00007c454bbe2a1c  add rsp, 0x08
00007c454bbe2a20  jmp 0x00007C454BBDF5F8
00007c454bbe2a25  sub rsp, 0x08
00007c454bbe2a29  push rax
00007c454bbe2a2a  push rcx
00007c454bbe2a2b  push rdx
00007c454bbe2a2c  push rdi
00007c454bbe2a2d  push rsi
00007c454bbe2a2e  push r8
00007c454bbe2a30  push r9
00007c454bbe2a32  push r10
00007c454bbe2a34  push r11
00007c454bbe2a36  sub rsp, 0xF0
00007c454bbe2a3d  vmovaps [rsp], xmm0
00007c454bbe2a42  vmovaps [rsp+0x10], xmm1
00007c454bbe2a48  vmovaps [rsp+0x20], xmm2
00007c454bbe2a4e  vmovaps [rsp+0x30], xmm3
00007c454bbe2a54  vmovaps [rsp+0x40], xmm5
00007c454bbe2a5a  vmovaps [rsp+0x50], xmm6
00007c454bbe2a60  vmovaps [rsp+0x60], xmm7
00007c454bbe2a66  vmovaps [rsp+0x70], xmm8
00007c454bbe2a6c  vmovaps [rsp+0x80], xmm9
00007c454bbe2a75  vmovaps [rsp+0x90], xmm10
00007c454bbe2a7e  vmovaps [rsp+0xA0], xmm11
00007c454bbe2a87  vmovaps [rsp+0xB0], xmm12
00007c454bbe2a90  vmovaps [rsp+0xC0], xmm13
00007c454bbe2a99  vmovaps [rsp+0xD0], xmm14
00007c454bbe2aa2  vmovaps [rsp+0xE0], xmm15
00007c454bbe2aab  sub rsp, 0x30
00007c454bbe2aaf  movaps [rsp], xmm4
00007c454bbe2ab3  movaps [rsp+0x10], xmm13
00007c454bbe2ab9  movaps [rsp+0x20], xmm8
00007c454bbe2abf  lea rdi, [rsp]
00007c454bbe2ac3  mov esi, 0x00
00007c454bbe2ac8  mov rax, 0x56A18AC54530
00007c454bbe2ad2  call rax
00007c454bbe2ad4  movaps xmm4, [rsp]
00007c454bbe2ad8  add rsp, 0x30
00007c454bbe2adc  vmovaps xmm0, [rsp]
00007c454bbe2ae1  vmovaps xmm1, [rsp+0x10]
00007c454bbe2ae7  vmovaps xmm2, [rsp+0x20]
00007c454bbe2aed  vmovaps xmm3, [rsp+0x30]
00007c454bbe2af3  vmovaps xmm5, [rsp+0x40]
00007c454bbe2af9  vmovaps xmm6, [rsp+0x50]
00007c454bbe2aff  vmovaps xmm7, [rsp+0x60]
00007c454bbe2b05  vmovaps xmm8, [rsp+0x70]
00007c454bbe2b0b  vmovaps xmm9, [rsp+0x80]
00007c454bbe2b14  vmovaps xmm10, [rsp+0x90]
00007c454bbe2b1d  vmovaps xmm11, [rsp+0xA0]
00007c454bbe2b26  vmovaps xmm12, [rsp+0xB0]
00007c454bbe2b2f  vmovaps xmm13, [rsp+0xC0]
00007c454bbe2b38  vmovaps xmm14, [rsp+0xD0]
00007c454bbe2b41  vmovaps xmm15, [rsp+0xE0]
00007c454bbe2b4a  add rsp, 0xF0
00007c454bbe2b51  pop r11
00007c454bbe2b53  pop r10
00007c454bbe2b55  pop r9
00007c454bbe2b57  pop r8
00007c454bbe2b59  pop rsi
00007c454bbe2b5a  pop rdi
00007c454bbe2b5b  pop rdx
00007c454bbe2b5c  pop rcx
00007c454bbe2b5d  pop rax
00007c454bbe2b5e  add rsp, 0x08
00007c454bbe2b62  jmp 0x00007C454BBDF61D
00007c454bbe2b67  sub rsp, 0x08
00007c454bbe2b6b  push rax
00007c454bbe2b6c  push rcx
00007c454bbe2b6d  push rdx
00007c454bbe2b6e  push rdi
00007c454bbe2b6f  push rsi
00007c454bbe2b70  push r8
00007c454bbe2b72  push r9
00007c454bbe2b74  push r10
00007c454bbe2b76  push r11
00007c454bbe2b78  sub rsp, 0xF0
00007c454bbe2b7f  vmovaps [rsp], xmm0
00007c454bbe2b84  vmovaps [rsp+0x10], xmm1
00007c454bbe2b8a  vmovaps [rsp+0x20], xmm2
00007c454bbe2b90  vmovaps [rsp+0x30], xmm3
00007c454bbe2b96  vmovaps [rsp+0x40], xmm4
00007c454bbe2b9c  vmovaps [rsp+0x50], xmm5
00007c454bbe2ba2  vmovaps [rsp+0x60], xmm6
00007c454bbe2ba8  vmovaps [rsp+0x70], xmm7
00007c454bbe2bae  vmovaps [rsp+0x80], xmm8
00007c454bbe2bb7  vmovaps [rsp+0x90], xmm9
00007c454bbe2bc0  vmovaps [rsp+0xA0], xmm10
00007c454bbe2bc9  vmovaps [rsp+0xB0], xmm11
00007c454bbe2bd2  vmovaps [rsp+0xC0], xmm12
00007c454bbe2bdb  vmovaps [rsp+0xD0], xmm14
00007c454bbe2be4  vmovaps [rsp+0xE0], xmm15
00007c454bbe2bed  sub rsp, 0x30
00007c454bbe2bf1  movaps [rsp], xmm13
00007c454bbe2bf6  movaps [rsp+0x10], xmm15
00007c454bbe2bfc  movaps [rsp+0x20], xmm9
00007c454bbe2c02  lea rdi, [rsp]
00007c454bbe2c06  mov esi, 0x00
00007c454bbe2c0b  mov rax, 0x56A18AC54530
00007c454bbe2c15  call rax
00007c454bbe2c17  movaps xmm13, [rsp]
00007c454bbe2c1c  add rsp, 0x30
00007c454bbe2c20  vmovaps xmm0, [rsp]
00007c454bbe2c25  vmovaps xmm1, [rsp+0x10]
00007c454bbe2c2b  vmovaps xmm2, [rsp+0x20]
00007c454bbe2c31  vmovaps xmm3, [rsp+0x30]
00007c454bbe2c37  vmovaps xmm4, [rsp+0x40]
00007c454bbe2c3d  vmovaps xmm5, [rsp+0x50]
00007c454bbe2c43  vmovaps xmm6, [rsp+0x60]
00007c454bbe2c49  vmovaps xmm7, [rsp+0x70]
00007c454bbe2c4f  vmovaps xmm8, [rsp+0x80]
00007c454bbe2c58  vmovaps xmm9, [rsp+0x90]
00007c454bbe2c61  vmovaps xmm10, [rsp+0xA0]
00007c454bbe2c6a  vmovaps xmm11, [rsp+0xB0]
00007c454bbe2c73  vmovaps xmm12, [rsp+0xC0]
00007c454bbe2c7c  vmovaps xmm14, [rsp+0xD0]
00007c454bbe2c85  vmovaps xmm15, [rsp+0xE0]
00007c454bbe2c8e  add rsp, 0xF0
00007c454bbe2c95  pop r11
00007c454bbe2c97  pop r10
00007c454bbe2c99  pop r9
00007c454bbe2c9b  pop r8
00007c454bbe2c9d  pop rsi
00007c454bbe2c9e  pop rdi
00007c454bbe2c9f  pop rdx
00007c454bbe2ca0  pop rcx
00007c454bbe2ca1  pop rax
00007c454bbe2ca2  add rsp, 0x08
00007c454bbe2ca6  jmp 0x00007C454BBDF638
00007c454bbe2cab  sub rsp, 0x08
00007c454bbe2caf  push rax
00007c454bbe2cb0  push rcx
00007c454bbe2cb1  push rdx
00007c454bbe2cb2  push rdi
00007c454bbe2cb3  push rsi
00007c454bbe2cb4  push r8
00007c454bbe2cb6  push r9
00007c454bbe2cb8  push r10
00007c454bbe2cba  push r11
00007c454bbe2cbc  sub rsp, 0xF0
00007c454bbe2cc3  vmovaps [rsp], xmm0
00007c454bbe2cc8  vmovaps [rsp+0x10], xmm1
00007c454bbe2cce  vmovaps [rsp+0x20], xmm2
00007c454bbe2cd4  vmovaps [rsp+0x30], xmm3
00007c454bbe2cda  vmovaps [rsp+0x40], xmm4
00007c454bbe2ce0  vmovaps [rsp+0x50], xmm5
00007c454bbe2ce6  vmovaps [rsp+0x60], xmm6
00007c454bbe2cec  vmovaps [rsp+0x70], xmm7
00007c454bbe2cf2  vmovaps [rsp+0x80], xmm8
00007c454bbe2cfb  vmovaps [rsp+0x90], xmm9
00007c454bbe2d04  vmovaps [rsp+0xA0], xmm10
00007c454bbe2d0d  vmovaps [rsp+0xB0], xmm11
00007c454bbe2d16  vmovaps [rsp+0xC0], xmm12
00007c454bbe2d1f  vmovaps [rsp+0xD0], xmm13
00007c454bbe2d28  vmovaps [rsp+0xE0], xmm14
00007c454bbe2d31  sub rsp, 0x30
00007c454bbe2d35  movaps [rsp], xmm15
00007c454bbe2d3a  movaps [rsp+0x10], xmm1
00007c454bbe2d3f  movaps [rsp+0x20], xmm5
00007c454bbe2d44  lea rdi, [rsp]
00007c454bbe2d48  mov esi, 0x00
00007c454bbe2d4d  mov rax, 0x56A18AC54530
00007c454bbe2d57  call rax
00007c454bbe2d59  movaps xmm15, [rsp]
00007c454bbe2d5e  add rsp, 0x30
00007c454bbe2d62  vmovaps xmm0, [rsp]
00007c454bbe2d67  vmovaps xmm1, [rsp+0x10]
00007c454bbe2d6d  vmovaps xmm2, [rsp+0x20]
00007c454bbe2d73  vmovaps xmm3, [rsp+0x30]
00007c454bbe2d79  vmovaps xmm4, [rsp+0x40]
00007c454bbe2d7f  vmovaps xmm5, [rsp+0x50]
00007c454bbe2d85  vmovaps xmm6, [rsp+0x60]
00007c454bbe2d8b  vmovaps xmm7, [rsp+0x70]
00007c454bbe2d91  vmovaps xmm8, [rsp+0x80]
00007c454bbe2d9a  vmovaps xmm9, [rsp+0x90]
00007c454bbe2da3  vmovaps xmm10, [rsp+0xA0]
00007c454bbe2dac  vmovaps xmm11, [rsp+0xB0]
00007c454bbe2db5  vmovaps xmm12, [rsp+0xC0]
00007c454bbe2dbe  vmovaps xmm13, [rsp+0xD0]
00007c454bbe2dc7  vmovaps xmm14, [rsp+0xE0]
00007c454bbe2dd0  add rsp, 0xF0
00007c454bbe2dd7  pop r11
00007c454bbe2dd9  pop r10
00007c454bbe2ddb  pop r9
00007c454bbe2ddd  pop r8
00007c454bbe2ddf  pop rsi
00007c454bbe2de0  pop rdi
00007c454bbe2de1  pop rdx
00007c454bbe2de2  pop rcx
00007c454bbe2de3  pop rax
00007c454bbe2de4  add rsp, 0x08
00007c454bbe2de8  jmp 0x00007C454BBDF653
00007c454bbe2ded  call 0x00007C454BAB52F0
00007c454bbe2df2  jmp 0x00007C454BBDF6AE
00007c454bbe2df7  sub rsp, 0x08
00007c454bbe2dfb  push rax
00007c454bbe2dfc  push rcx
00007c454bbe2dfd  push rdx
00007c454bbe2dfe  push rdi
00007c454bbe2dff  push rsi
00007c454bbe2e00  push r8
00007c454bbe2e02  push r9
00007c454bbe2e04  push r10
00007c454bbe2e06  push r11
00007c454bbe2e08  sub rsp, 0xF0
00007c454bbe2e0f  vmovaps [rsp], xmm0
00007c454bbe2e14  vmovaps [rsp+0x10], xmm1
00007c454bbe2e1a  vmovaps [rsp+0x20], xmm2
00007c454bbe2e20  vmovaps [rsp+0x30], xmm3
00007c454bbe2e26  vmovaps [rsp+0x40], xmm4
00007c454bbe2e2c  vmovaps [rsp+0x50], xmm5
00007c454bbe2e32  vmovaps [rsp+0x60], xmm6
00007c454bbe2e38  vmovaps [rsp+0x70], xmm7
00007c454bbe2e3e  vmovaps [rsp+0x80], xmm8
00007c454bbe2e47  vmovaps [rsp+0x90], xmm10
00007c454bbe2e50  vmovaps [rsp+0xA0], xmm11
00007c454bbe2e59  vmovaps [rsp+0xB0], xmm12
00007c454bbe2e62  vmovaps [rsp+0xC0], xmm13
00007c454bbe2e6b  vmovaps [rsp+0xD0], xmm14
00007c454bbe2e74  vmovaps [rsp+0xE0], xmm15
00007c454bbe2e7d  sub rsp, 0x30
00007c454bbe2e81  movaps [rsp], xmm9
00007c454bbe2e86  movaps [rsp+0x10], xmm8
00007c454bbe2e8c  movaps [rsp+0x20], xmm11
00007c454bbe2e92  lea rdi, [rsp]
00007c454bbe2e96  mov esi, 0x00
00007c454bbe2e9b  mov rax, 0x56A18AC54530
00007c454bbe2ea5  call rax
00007c454bbe2ea7  movaps xmm9, [rsp]
00007c454bbe2eac  add rsp, 0x30
00007c454bbe2eb0  vmovaps xmm0, [rsp]
00007c454bbe2eb5  vmovaps xmm1, [rsp+0x10]
00007c454bbe2ebb  vmovaps xmm2, [rsp+0x20]
00007c454bbe2ec1  vmovaps xmm3, [rsp+0x30]
00007c454bbe2ec7  vmovaps xmm4, [rsp+0x40]
00007c454bbe2ecd  vmovaps xmm5, [rsp+0x50]
00007c454bbe2ed3  vmovaps xmm6, [rsp+0x60]
00007c454bbe2ed9  vmovaps xmm7, [rsp+0x70]
00007c454bbe2edf  vmovaps xmm8, [rsp+0x80]
00007c454bbe2ee8  vmovaps xmm10, [rsp+0x90]
00007c454bbe2ef1  vmovaps xmm11, [rsp+0xA0]
00007c454bbe2efa  vmovaps xmm12, [rsp+0xB0]
00007c454bbe2f03  vmovaps xmm13, [rsp+0xC0]
00007c454bbe2f0c  vmovaps xmm14, [rsp+0xD0]
00007c454bbe2f15  vmovaps xmm15, [rsp+0xE0]
00007c454bbe2f1e  add rsp, 0xF0
00007c454bbe2f25  pop r11
00007c454bbe2f27  pop r10
00007c454bbe2f29  pop r9
00007c454bbe2f2b  pop r8
00007c454bbe2f2d  pop rsi
00007c454bbe2f2e  pop rdi
00007c454bbe2f2f  pop rdx
00007c454bbe2f30  pop rcx
00007c454bbe2f31  pop rax
00007c454bbe2f32  add rsp, 0x08
00007c454bbe2f36  jmp 0x00007C454BBDF6E5
00007c454bbe2f3b  sub rsp, 0x08
00007c454bbe2f3f  push rax
00007c454bbe2f40  push rcx
00007c454bbe2f41  push rdx
00007c454bbe2f42  push rdi
00007c454bbe2f43  push rsi
00007c454bbe2f44  push r8
00007c454bbe2f46  push r9
00007c454bbe2f48  push r10
00007c454bbe2f4a  push r11
00007c454bbe2f4c  sub rsp, 0xF0
00007c454bbe2f53  vmovaps [rsp], xmm0
00007c454bbe2f58  vmovaps [rsp+0x10], xmm1
00007c454bbe2f5e  vmovaps [rsp+0x20], xmm2
00007c454bbe2f64  vmovaps [rsp+0x30], xmm3
00007c454bbe2f6a  vmovaps [rsp+0x40], xmm4
00007c454bbe2f70  vmovaps [rsp+0x50], xmm5
00007c454bbe2f76  vmovaps [rsp+0x60], xmm6
00007c454bbe2f7c  vmovaps [rsp+0x70], xmm7
00007c454bbe2f82  vmovaps [rsp+0x80], xmm8
00007c454bbe2f8b  vmovaps [rsp+0x90], xmm9
00007c454bbe2f94  vmovaps [rsp+0xA0], xmm10
00007c454bbe2f9d  vmovaps [rsp+0xB0], xmm12
00007c454bbe2fa6  vmovaps [rsp+0xC0], xmm13
00007c454bbe2faf  vmovaps [rsp+0xD0], xmm14
00007c454bbe2fb8  vmovaps [rsp+0xE0], xmm15
00007c454bbe2fc1  sub rsp, 0x30
00007c454bbe2fc5  movaps [rsp], xmm11
00007c454bbe2fca  movaps [rsp+0x10], xmm10
00007c454bbe2fd0  movaps [rsp+0x20], xmm6
00007c454bbe2fd5  lea rdi, [rsp]
00007c454bbe2fd9  mov esi, 0x00
00007c454bbe2fde  mov rax, 0x56A18AC54530
00007c454bbe2fe8  call rax
00007c454bbe2fea  movaps xmm11, [rsp]
00007c454bbe2fef  add rsp, 0x30
00007c454bbe2ff3  vmovaps xmm0, [rsp]
00007c454bbe2ff8  vmovaps xmm1, [rsp+0x10]
00007c454bbe2ffe  vmovaps xmm2, [rsp+0x20]
00007c454bbe3004  vmovaps xmm3, [rsp+0x30]
00007c454bbe300a  vmovaps xmm4, [rsp+0x40]
00007c454bbe3010  vmovaps xmm5, [rsp+0x50]
00007c454bbe3016  vmovaps xmm6, [rsp+0x60]
00007c454bbe301c  vmovaps xmm7, [rsp+0x70]
00007c454bbe3022  vmovaps xmm8, [rsp+0x80]
00007c454bbe302b  vmovaps xmm9, [rsp+0x90]
00007c454bbe3034  vmovaps xmm10, [rsp+0xA0]
00007c454bbe303d  vmovaps xmm12, [rsp+0xB0]
00007c454bbe3046  vmovaps xmm13, [rsp+0xC0]
00007c454bbe304f  vmovaps xmm14, [rsp+0xD0]
00007c454bbe3058  vmovaps xmm15, [rsp+0xE0]
00007c454bbe3061  add rsp, 0xF0
00007c454bbe3068  pop r11
00007c454bbe306a  pop r10
00007c454bbe306c  pop r9
00007c454bbe306e  pop r8
00007c454bbe3070  pop rsi
00007c454bbe3071  pop rdi
00007c454bbe3072  pop rdx
00007c454bbe3073  pop rcx
00007c454bbe3074  pop rax
00007c454bbe3075  add rsp, 0x08
00007c454bbe3079  jmp 0x00007C454BBDF700
00007c454bbe307e  sub rsp, 0x08
00007c454bbe3082  push rax
00007c454bbe3083  push rcx
00007c454bbe3084  push rdx
00007c454bbe3085  push rdi
00007c454bbe3086  push rsi
00007c454bbe3087  push r8
00007c454bbe3089  push r9
00007c454bbe308b  push r10
00007c454bbe308d  push r11
00007c454bbe308f  sub rsp, 0xF0
00007c454bbe3096  vmovaps [rsp], xmm0
00007c454bbe309b  vmovaps [rsp+0x10], xmm1
00007c454bbe30a1  vmovaps [rsp+0x20], xmm2
00007c454bbe30a7  vmovaps [rsp+0x30], xmm3
00007c454bbe30ad  vmovaps [rsp+0x40], xmm4
00007c454bbe30b3  vmovaps [rsp+0x50], xmm5
00007c454bbe30b9  vmovaps [rsp+0x60], xmm6
00007c454bbe30bf  vmovaps [rsp+0x70], xmm7
00007c454bbe30c5  vmovaps [rsp+0x80], xmm8
00007c454bbe30ce  vmovaps [rsp+0x90], xmm9
00007c454bbe30d7  vmovaps [rsp+0xA0], xmm11
00007c454bbe30e0  vmovaps [rsp+0xB0], xmm12
00007c454bbe30e9  vmovaps [rsp+0xC0], xmm13
00007c454bbe30f2  vmovaps [rsp+0xD0], xmm14
00007c454bbe30fb  vmovaps [rsp+0xE0], xmm15
00007c454bbe3104  sub rsp, 0x30
00007c454bbe3108  movaps [rsp], xmm10
00007c454bbe310d  movaps [rsp+0x10], xmm14
00007c454bbe3113  movaps [rsp+0x20], xmm4
00007c454bbe3118  lea rdi, [rsp]
00007c454bbe311c  mov esi, 0x00
00007c454bbe3121  mov rax, 0x56A18AC54530
00007c454bbe312b  call rax
00007c454bbe312d  movaps xmm10, [rsp]
00007c454bbe3132  add rsp, 0x30
00007c454bbe3136  vmovaps xmm0, [rsp]
00007c454bbe313b  vmovaps xmm1, [rsp+0x10]
00007c454bbe3141  vmovaps xmm2, [rsp+0x20]
00007c454bbe3147  vmovaps xmm3, [rsp+0x30]
00007c454bbe314d  vmovaps xmm4, [rsp+0x40]
00007c454bbe3153  vmovaps xmm5, [rsp+0x50]
00007c454bbe3159  vmovaps xmm6, [rsp+0x60]
00007c454bbe315f  vmovaps xmm7, [rsp+0x70]
00007c454bbe3165  vmovaps xmm8, [rsp+0x80]
00007c454bbe316e  vmovaps xmm9, [rsp+0x90]
00007c454bbe3177  vmovaps xmm11, [rsp+0xA0]
00007c454bbe3180  vmovaps xmm12, [rsp+0xB0]
00007c454bbe3189  vmovaps xmm13, [rsp+0xC0]
00007c454bbe3192  vmovaps xmm14, [rsp+0xD0]
00007c454bbe319b  vmovaps xmm15, [rsp+0xE0]
00007c454bbe31a4  add rsp, 0xF0
00007c454bbe31ab  pop r11
00007c454bbe31ad  pop r10
00007c454bbe31af  pop r9
00007c454bbe31b1  pop r8
00007c454bbe31b3  pop rsi
00007c454bbe31b4  pop rdi
00007c454bbe31b5  pop rdx
00007c454bbe31b6  pop rcx
00007c454bbe31b7  pop rax
00007c454bbe31b8  add rsp, 0x08
00007c454bbe31bc  jmp 0x00007C454BBDF71B
00007c454bbe31c1  sub rsp, 0x08
00007c454bbe31c5  push rax
00007c454bbe31c6  push rcx
00007c454bbe31c7  push rdx
00007c454bbe31c8  push rdi
00007c454bbe31c9  push rsi
00007c454bbe31ca  push r8
00007c454bbe31cc  push r9
00007c454bbe31ce  push r10
00007c454bbe31d0  push r11
00007c454bbe31d2  sub rsp, 0xF0
00007c454bbe31d9  vmovaps [rsp], xmm0
00007c454bbe31de  vmovaps [rsp+0x10], xmm1
00007c454bbe31e4  vmovaps [rsp+0x20], xmm2
00007c454bbe31ea  vmovaps [rsp+0x30], xmm3
00007c454bbe31f0  vmovaps [rsp+0x40], xmm4
00007c454bbe31f6  vmovaps [rsp+0x50], xmm5
00007c454bbe31fc  vmovaps [rsp+0x60], xmm6
00007c454bbe3202  vmovaps [rsp+0x70], xmm7
00007c454bbe3208  vmovaps [rsp+0x80], xmm9
00007c454bbe3211  vmovaps [rsp+0x90], xmm10
00007c454bbe321a  vmovaps [rsp+0xA0], xmm11
00007c454bbe3223  vmovaps [rsp+0xB0], xmm12
00007c454bbe322c  vmovaps [rsp+0xC0], xmm13
00007c454bbe3235  vmovaps [rsp+0xD0], xmm14
00007c454bbe323e  vmovaps [rsp+0xE0], xmm15
00007c454bbe3247  sub rsp, 0x30
00007c454bbe324b  movaps [rsp], xmm8
00007c454bbe3250  movaps [rsp+0x10], xmm1
00007c454bbe3255  movaps [rsp+0x20], xmm14
00007c454bbe325b  lea rdi, [rsp]
00007c454bbe325f  mov esi, 0x00
00007c454bbe3264  mov rax, 0x56A18AC54530
00007c454bbe326e  call rax
00007c454bbe3270  movaps xmm8, [rsp]
00007c454bbe3275  add rsp, 0x30
00007c454bbe3279  vmovaps xmm0, [rsp]
00007c454bbe327e  vmovaps xmm1, [rsp+0x10]
00007c454bbe3284  vmovaps xmm2, [rsp+0x20]
00007c454bbe328a  vmovaps xmm3, [rsp+0x30]
00007c454bbe3290  vmovaps xmm4, [rsp+0x40]
00007c454bbe3296  vmovaps xmm5, [rsp+0x50]
00007c454bbe329c  vmovaps xmm6, [rsp+0x60]
00007c454bbe32a2  vmovaps xmm7, [rsp+0x70]
00007c454bbe32a8  vmovaps xmm9, [rsp+0x80]
00007c454bbe32b1  vmovaps xmm10, [rsp+0x90]
00007c454bbe32ba  vmovaps xmm11, [rsp+0xA0]
00007c454bbe32c3  vmovaps xmm12, [rsp+0xB0]
00007c454bbe32cc  vmovaps xmm13, [rsp+0xC0]
00007c454bbe32d5  vmovaps xmm14, [rsp+0xD0]
00007c454bbe32de  vmovaps xmm15, [rsp+0xE0]
00007c454bbe32e7  add rsp, 0xF0
00007c454bbe32ee  pop r11
00007c454bbe32f0  pop r10
00007c454bbe32f2  pop r9
00007c454bbe32f4  pop r8
00007c454bbe32f6  pop rsi
00007c454bbe32f7  pop rdi
00007c454bbe32f8  pop rdx
00007c454bbe32f9  pop rcx
00007c454bbe32fa  pop rax
00007c454bbe32fb  add rsp, 0x08
00007c454bbe32ff  jmp 0x00007C454BBDF741
00007c454bbe3304  sub rsp, 0x08
00007c454bbe3308  push rax
00007c454bbe3309  push rcx
00007c454bbe330a  push rdx
00007c454bbe330b  push rdi
00007c454bbe330c  push rsi
00007c454bbe330d  push r8
00007c454bbe330f  push r9
00007c454bbe3311  push r10
00007c454bbe3313  push r11
00007c454bbe3315  sub rsp, 0xF0
00007c454bbe331c  vmovaps [rsp], xmm0
00007c454bbe3321  vmovaps [rsp+0x10], xmm1
00007c454bbe3327  vmovaps [rsp+0x20], xmm2
00007c454bbe332d  vmovaps [rsp+0x30], xmm3
00007c454bbe3333  vmovaps [rsp+0x40], xmm4
00007c454bbe3339  vmovaps [rsp+0x50], xmm5
00007c454bbe333f  vmovaps [rsp+0x60], xmm7
00007c454bbe3345  vmovaps [rsp+0x70], xmm8
00007c454bbe334b  vmovaps [rsp+0x80], xmm9
00007c454bbe3354  vmovaps [rsp+0x90], xmm10
00007c454bbe335d  vmovaps [rsp+0xA0], xmm11
00007c454bbe3366  vmovaps [rsp+0xB0], xmm12
00007c454bbe336f  vmovaps [rsp+0xC0], xmm13
00007c454bbe3378  vmovaps [rsp+0xD0], xmm14
00007c454bbe3381  vmovaps [rsp+0xE0], xmm15
00007c454bbe338a  sub rsp, 0x30
00007c454bbe338e  movaps [rsp], xmm6
00007c454bbe3392  movaps [rsp+0x10], xmm1
00007c454bbe3397  movaps [rsp+0x20], xmm14
00007c454bbe339d  lea rdi, [rsp]
00007c454bbe33a1  mov esi, 0x00
00007c454bbe33a6  mov rax, 0x56A18AC54530
00007c454bbe33b0  call rax
00007c454bbe33b2  movaps xmm6, [rsp]
00007c454bbe33b6  add rsp, 0x30
00007c454bbe33ba  vmovaps xmm0, [rsp]
00007c454bbe33bf  vmovaps xmm1, [rsp+0x10]
00007c454bbe33c5  vmovaps xmm2, [rsp+0x20]
00007c454bbe33cb  vmovaps xmm3, [rsp+0x30]
00007c454bbe33d1  vmovaps xmm4, [rsp+0x40]
00007c454bbe33d7  vmovaps xmm5, [rsp+0x50]
00007c454bbe33dd  vmovaps xmm7, [rsp+0x60]
00007c454bbe33e3  vmovaps xmm8, [rsp+0x70]
00007c454bbe33e9  vmovaps xmm9, [rsp+0x80]
00007c454bbe33f2  vmovaps xmm10, [rsp+0x90]
00007c454bbe33fb  vmovaps xmm11, [rsp+0xA0]
00007c454bbe3404  vmovaps xmm12, [rsp+0xB0]
00007c454bbe340d  vmovaps xmm13, [rsp+0xC0]
00007c454bbe3416  vmovaps xmm14, [rsp+0xD0]
00007c454bbe341f  vmovaps xmm15, [rsp+0xE0]
00007c454bbe3428  add rsp, 0xF0
00007c454bbe342f  pop r11
00007c454bbe3431  pop r10
00007c454bbe3433  pop r9
00007c454bbe3435  pop r8
00007c454bbe3437  pop rsi
00007c454bbe3438  pop rdi
00007c454bbe3439  pop rdx
00007c454bbe343a  pop rcx
00007c454bbe343b  pop rax
00007c454bbe343c  add rsp, 0x08
00007c454bbe3440  jmp 0x00007C454BBDF76D
00007c454bbe3445  sub rsp, 0x08
00007c454bbe3449  push rax
00007c454bbe344a  push rcx
00007c454bbe344b  push rdx
00007c454bbe344c  push rdi
00007c454bbe344d  push rsi
00007c454bbe344e  push r8
00007c454bbe3450  push r9
00007c454bbe3452  push r10
00007c454bbe3454  push r11
00007c454bbe3456  sub rsp, 0xF0
00007c454bbe345d  vmovaps [rsp], xmm0
00007c454bbe3462  vmovaps [rsp+0x10], xmm1
00007c454bbe3468  vmovaps [rsp+0x20], xmm2
00007c454bbe346e  vmovaps [rsp+0x30], xmm3
00007c454bbe3474  vmovaps [rsp+0x40], xmm4
00007c454bbe347a  vmovaps [rsp+0x50], xmm5
00007c454bbe3480  vmovaps [rsp+0x60], xmm6
00007c454bbe3486  vmovaps [rsp+0x70], xmm7
00007c454bbe348c  vmovaps [rsp+0x80], xmm8
00007c454bbe3495  vmovaps [rsp+0x90], xmm9
00007c454bbe349e  vmovaps [rsp+0xA0], xmm10
00007c454bbe34a7  vmovaps [rsp+0xB0], xmm11
00007c454bbe34b0  vmovaps [rsp+0xC0], xmm12
00007c454bbe34b9  vmovaps [rsp+0xD0], xmm13
00007c454bbe34c2  vmovaps [rsp+0xE0], xmm15
00007c454bbe34cb  sub rsp, 0x30
00007c454bbe34cf  movaps [rsp], xmm14
00007c454bbe34d4  movaps [rsp+0x10], xmm12
00007c454bbe34da  movaps [rsp+0x20], xmm1
00007c454bbe34df  lea rdi, [rsp]
00007c454bbe34e3  mov esi, 0x00
00007c454bbe34e8  mov rax, 0x56A18AC54530
00007c454bbe34f2  call rax
00007c454bbe34f4  movaps xmm14, [rsp]
00007c454bbe34f9  add rsp, 0x30
00007c454bbe34fd  vmovaps xmm0, [rsp]
00007c454bbe3502  vmovaps xmm1, [rsp+0x10]
00007c454bbe3508  vmovaps xmm2, [rsp+0x20]
00007c454bbe350e  vmovaps xmm3, [rsp+0x30]
00007c454bbe3514  vmovaps xmm4, [rsp+0x40]
00007c454bbe351a  vmovaps xmm5, [rsp+0x50]
00007c454bbe3520  vmovaps xmm6, [rsp+0x60]
00007c454bbe3526  vmovaps xmm7, [rsp+0x70]
00007c454bbe352c  vmovaps xmm8, [rsp+0x80]
00007c454bbe3535  vmovaps xmm9, [rsp+0x90]
00007c454bbe353e  vmovaps xmm10, [rsp+0xA0]
00007c454bbe3547  vmovaps xmm11, [rsp+0xB0]
00007c454bbe3550  vmovaps xmm12, [rsp+0xC0]
00007c454bbe3559  vmovaps xmm13, [rsp+0xD0]
00007c454bbe3562  vmovaps xmm15, [rsp+0xE0]
00007c454bbe356b  add rsp, 0xF0
00007c454bbe3572  pop r11
00007c454bbe3574  pop r10
00007c454bbe3576  pop r9
00007c454bbe3578  pop r8
00007c454bbe357a  pop rsi
00007c454bbe357b  pop rdi
00007c454bbe357c  pop rdx
00007c454bbe357d  pop rcx
00007c454bbe357e  pop rax
00007c454bbe357f  add rsp, 0x08
00007c454bbe3583  jmp 0x00007C454BBDF793
00007c454bbe3588  sub rsp, 0x08
00007c454bbe358c  push rax
00007c454bbe358d  push rcx
00007c454bbe358e  push rdx
00007c454bbe358f  push rdi
00007c454bbe3590  push rsi
00007c454bbe3591  push r8
00007c454bbe3593  push r9
00007c454bbe3595  push r10
00007c454bbe3597  push r11
00007c454bbe3599  sub rsp, 0xF0
00007c454bbe35a0  vmovaps [rsp], xmm0
00007c454bbe35a5  vmovaps [rsp+0x10], xmm2
00007c454bbe35ab  vmovaps [rsp+0x20], xmm3
00007c454bbe35b1  vmovaps [rsp+0x30], xmm4
00007c454bbe35b7  vmovaps [rsp+0x40], xmm5
00007c454bbe35bd  vmovaps [rsp+0x50], xmm6
00007c454bbe35c3  vmovaps [rsp+0x60], xmm7
00007c454bbe35c9  vmovaps [rsp+0x70], xmm8
00007c454bbe35cf  vmovaps [rsp+0x80], xmm9
00007c454bbe35d8  vmovaps [rsp+0x90], xmm10
00007c454bbe35e1  vmovaps [rsp+0xA0], xmm11
00007c454bbe35ea  vmovaps [rsp+0xB0], xmm12
00007c454bbe35f3  vmovaps [rsp+0xC0], xmm13
00007c454bbe35fc  vmovaps [rsp+0xD0], xmm14
00007c454bbe3605  vmovaps [rsp+0xE0], xmm15
00007c454bbe360e  sub rsp, 0x30
00007c454bbe3612  movaps [rsp], xmm1
00007c454bbe3616  movaps [rsp+0x10], xmm13
00007c454bbe361c  movaps [rsp+0x20], xmm9
00007c454bbe3622  lea rdi, [rsp]
00007c454bbe3626  mov esi, 0x00
00007c454bbe362b  mov rax, 0x56A18AC54530
00007c454bbe3635  call rax
00007c454bbe3637  movaps xmm1, [rsp]
00007c454bbe363b  add rsp, 0x30
00007c454bbe363f  vmovaps xmm0, [rsp]
00007c454bbe3644  vmovaps xmm2, [rsp+0x10]
00007c454bbe364a  vmovaps xmm3, [rsp+0x20]
00007c454bbe3650  vmovaps xmm4, [rsp+0x30]
00007c454bbe3656  vmovaps xmm5, [rsp+0x40]
00007c454bbe365c  vmovaps xmm6, [rsp+0x50]
00007c454bbe3662  vmovaps xmm7, [rsp+0x60]
00007c454bbe3668  vmovaps xmm8, [rsp+0x70]
00007c454bbe366e  vmovaps xmm9, [rsp+0x80]
00007c454bbe3677  vmovaps xmm10, [rsp+0x90]
00007c454bbe3680  vmovaps xmm11, [rsp+0xA0]
00007c454bbe3689  vmovaps xmm12, [rsp+0xB0]
00007c454bbe3692  vmovaps xmm13, [rsp+0xC0]
00007c454bbe369b  vmovaps xmm14, [rsp+0xD0]
00007c454bbe36a4  vmovaps xmm15, [rsp+0xE0]
00007c454bbe36ad  add rsp, 0xF0
00007c454bbe36b4  pop r11
00007c454bbe36b6  pop r10
00007c454bbe36b8  pop r9
00007c454bbe36ba  pop r8
00007c454bbe36bc  pop rsi
00007c454bbe36bd  pop rdi
00007c454bbe36be  pop rdx
00007c454bbe36bf  pop rcx
00007c454bbe36c0  pop rax
00007c454bbe36c1  add rsp, 0x08
00007c454bbe36c5  jmp 0x00007C454BBDF7AD
00007c454bbe36ca  sub rsp, 0x08
00007c454bbe36ce  push rax
00007c454bbe36cf  push rcx
00007c454bbe36d0  push rdx
00007c454bbe36d1  push rdi
00007c454bbe36d2  push rsi
00007c454bbe36d3  push r8
00007c454bbe36d5  push r9
00007c454bbe36d7  push r10
00007c454bbe36d9  push r11
00007c454bbe36db  sub rsp, 0xF0
00007c454bbe36e2  vmovaps [rsp], xmm0
00007c454bbe36e7  vmovaps [rsp+0x10], xmm1
00007c454bbe36ed  vmovaps [rsp+0x20], xmm2
00007c454bbe36f3  vmovaps [rsp+0x30], xmm3
00007c454bbe36f9  vmovaps [rsp+0x40], xmm4
00007c454bbe36ff  vmovaps [rsp+0x50], xmm5
00007c454bbe3705  vmovaps [rsp+0x60], xmm6
00007c454bbe370b  vmovaps [rsp+0x70], xmm7
00007c454bbe3711  vmovaps [rsp+0x80], xmm8
00007c454bbe371a  vmovaps [rsp+0x90], xmm9
00007c454bbe3723  vmovaps [rsp+0xA0], xmm10
00007c454bbe372c  vmovaps [rsp+0xB0], xmm11
00007c454bbe3735  vmovaps [rsp+0xC0], xmm13
00007c454bbe373e  vmovaps [rsp+0xD0], xmm14
00007c454bbe3747  vmovaps [rsp+0xE0], xmm15
00007c454bbe3750  sub rsp, 0x30
00007c454bbe3754  movaps [rsp], xmm12
00007c454bbe3759  movaps [rsp+0x10], xmm7
00007c454bbe375e  movaps [rsp+0x20], xmm13
00007c454bbe3764  lea rdi, [rsp]
00007c454bbe3768  mov esi, 0x00
00007c454bbe376d  mov rax, 0x56A18AC54530
00007c454bbe3777  call rax
00007c454bbe3779  movaps xmm12, [rsp]
00007c454bbe377e  add rsp, 0x30
00007c454bbe3782  vmovaps xmm0, [rsp]
00007c454bbe3787  vmovaps xmm1, [rsp+0x10]
00007c454bbe378d  vmovaps xmm2, [rsp+0x20]
00007c454bbe3793  vmovaps xmm3, [rsp+0x30]
00007c454bbe3799  vmovaps xmm4, [rsp+0x40]
00007c454bbe379f  vmovaps xmm5, [rsp+0x50]
00007c454bbe37a5  vmovaps xmm6, [rsp+0x60]
00007c454bbe37ab  vmovaps xmm7, [rsp+0x70]
00007c454bbe37b1  vmovaps xmm8, [rsp+0x80]
00007c454bbe37ba  vmovaps xmm9, [rsp+0x90]
00007c454bbe37c3  vmovaps xmm10, [rsp+0xA0]
00007c454bbe37cc  vmovaps xmm11, [rsp+0xB0]
00007c454bbe37d5  vmovaps xmm13, [rsp+0xC0]
00007c454bbe37de  vmovaps xmm14, [rsp+0xD0]
00007c454bbe37e7  vmovaps xmm15, [rsp+0xE0]
00007c454bbe37f0  add rsp, 0xF0
00007c454bbe37f7  pop r11
00007c454bbe37f9  pop r10
00007c454bbe37fb  pop r9
00007c454bbe37fd  pop r8
00007c454bbe37ff  pop rsi
00007c454bbe3800  pop rdi
00007c454bbe3801  pop rdx
00007c454bbe3802  pop rcx
00007c454bbe3803  pop rax
00007c454bbe3804  add rsp, 0x08
00007c454bbe3808  jmp 0x00007C454BBDF7D4
00007c454bbe380d  sub rsp, 0x08
00007c454bbe3811  push rax
00007c454bbe3812  push rcx
00007c454bbe3813  push rdx
00007c454bbe3814  push rdi
00007c454bbe3815  push rsi
00007c454bbe3816  push r8
00007c454bbe3818  push r9
00007c454bbe381a  push r10
00007c454bbe381c  push r11
00007c454bbe381e  sub rsp, 0xF0
00007c454bbe3825  vmovaps [rsp], xmm0
00007c454bbe382a  vmovaps [rsp+0x10], xmm1
00007c454bbe3830  vmovaps [rsp+0x20], xmm2
00007c454bbe3836  vmovaps [rsp+0x30], xmm3
00007c454bbe383c  vmovaps [rsp+0x40], xmm4
00007c454bbe3842  vmovaps [rsp+0x50], xmm5
00007c454bbe3848  vmovaps [rsp+0x60], xmm6
00007c454bbe384e  vmovaps [rsp+0x70], xmm7
00007c454bbe3854  vmovaps [rsp+0x80], xmm8
00007c454bbe385d  vmovaps [rsp+0x90], xmm9
00007c454bbe3866  vmovaps [rsp+0xA0], xmm10
00007c454bbe386f  vmovaps [rsp+0xB0], xmm11
00007c454bbe3878  vmovaps [rsp+0xC0], xmm12
00007c454bbe3881  vmovaps [rsp+0xD0], xmm14
00007c454bbe388a  vmovaps [rsp+0xE0], xmm15
00007c454bbe3893  sub rsp, 0x30
00007c454bbe3897  movaps [rsp], xmm13
00007c454bbe389c  movaps [rsp+0x10], xmm15
00007c454bbe38a2  movaps [rsp+0x20], xmm8
00007c454bbe38a8  lea rdi, [rsp]
00007c454bbe38ac  mov esi, 0x00
00007c454bbe38b1  mov rax, 0x56A18AC54530
00007c454bbe38bb  call rax
00007c454bbe38bd  movaps xmm13, [rsp]
00007c454bbe38c2  add rsp, 0x30
00007c454bbe38c6  vmovaps xmm0, [rsp]
00007c454bbe38cb  vmovaps xmm1, [rsp+0x10]
00007c454bbe38d1  vmovaps xmm2, [rsp+0x20]
00007c454bbe38d7  vmovaps xmm3, [rsp+0x30]
00007c454bbe38dd  vmovaps xmm4, [rsp+0x40]
00007c454bbe38e3  vmovaps xmm5, [rsp+0x50]
00007c454bbe38e9  vmovaps xmm6, [rsp+0x60]
00007c454bbe38ef  vmovaps xmm7, [rsp+0x70]
00007c454bbe38f5  vmovaps xmm8, [rsp+0x80]
00007c454bbe38fe  vmovaps xmm9, [rsp+0x90]
00007c454bbe3907  vmovaps xmm10, [rsp+0xA0]
00007c454bbe3910  vmovaps xmm11, [rsp+0xB0]
00007c454bbe3919  vmovaps xmm12, [rsp+0xC0]
00007c454bbe3922  vmovaps xmm14, [rsp+0xD0]
00007c454bbe392b  vmovaps xmm15, [rsp+0xE0]
00007c454bbe3934  add rsp, 0xF0
00007c454bbe393b  pop r11
00007c454bbe393d  pop r10
00007c454bbe393f  pop r9
00007c454bbe3941  pop r8
00007c454bbe3943  pop rsi
00007c454bbe3944  pop rdi
00007c454bbe3945  pop rdx
00007c454bbe3946  pop rcx
00007c454bbe3947  pop rax
00007c454bbe3948  add rsp, 0x08
00007c454bbe394c  jmp 0x00007C454BBDF7EF
00007c454bbe3951  sub rsp, 0x08
00007c454bbe3955  push rax
00007c454bbe3956  push rcx
00007c454bbe3957  push rdx
00007c454bbe3958  push rdi
00007c454bbe3959  push rsi
00007c454bbe395a  push r8
00007c454bbe395c  push r9
00007c454bbe395e  push r10
00007c454bbe3960  push r11
00007c454bbe3962  sub rsp, 0xF0
00007c454bbe3969  vmovaps [rsp], xmm0
00007c454bbe396e  vmovaps [rsp+0x10], xmm1
00007c454bbe3974  vmovaps [rsp+0x20], xmm2
00007c454bbe397a  vmovaps [rsp+0x30], xmm3
00007c454bbe3980  vmovaps [rsp+0x40], xmm4
00007c454bbe3986  vmovaps [rsp+0x50], xmm5
00007c454bbe398c  vmovaps [rsp+0x60], xmm6
00007c454bbe3992  vmovaps [rsp+0x70], xmm7
00007c454bbe3998  vmovaps [rsp+0x80], xmm9
00007c454bbe39a1  vmovaps [rsp+0x90], xmm10
00007c454bbe39aa  vmovaps [rsp+0xA0], xmm11
00007c454bbe39b3  vmovaps [rsp+0xB0], xmm12
00007c454bbe39bc  vmovaps [rsp+0xC0], xmm13
00007c454bbe39c5  vmovaps [rsp+0xD0], xmm14
00007c454bbe39ce  vmovaps [rsp+0xE0], xmm15
00007c454bbe39d7  sub rsp, 0x30
00007c454bbe39db  movaps [rsp], xmm8
00007c454bbe39e0  movaps [rsp+0x10], xmm15
00007c454bbe39e6  movaps [rsp+0x20], xmm9
00007c454bbe39ec  lea rdi, [rsp]
00007c454bbe39f0  mov esi, 0x00
00007c454bbe39f5  mov rax, 0x56A18AC54530
00007c454bbe39ff  call rax
00007c454bbe3a01  movaps xmm8, [rsp]
00007c454bbe3a06  add rsp, 0x30
00007c454bbe3a0a  vmovaps xmm0, [rsp]
00007c454bbe3a0f  vmovaps xmm1, [rsp+0x10]
00007c454bbe3a15  vmovaps xmm2, [rsp+0x20]
00007c454bbe3a1b  vmovaps xmm3, [rsp+0x30]
00007c454bbe3a21  vmovaps xmm4, [rsp+0x40]
00007c454bbe3a27  vmovaps xmm5, [rsp+0x50]
00007c454bbe3a2d  vmovaps xmm6, [rsp+0x60]
00007c454bbe3a33  vmovaps xmm7, [rsp+0x70]
00007c454bbe3a39  vmovaps xmm9, [rsp+0x80]
00007c454bbe3a42  vmovaps xmm10, [rsp+0x90]
00007c454bbe3a4b  vmovaps xmm11, [rsp+0xA0]
00007c454bbe3a54  vmovaps xmm12, [rsp+0xB0]
00007c454bbe3a5d  vmovaps xmm13, [rsp+0xC0]
00007c454bbe3a66  vmovaps xmm14, [rsp+0xD0]
00007c454bbe3a6f  vmovaps xmm15, [rsp+0xE0]
00007c454bbe3a78  add rsp, 0xF0
00007c454bbe3a7f  pop r11
00007c454bbe3a81  pop r10
00007c454bbe3a83  pop r9
00007c454bbe3a85  pop r8
00007c454bbe3a87  pop rsi
00007c454bbe3a88  pop rdi
00007c454bbe3a89  pop rdx
00007c454bbe3a8a  pop rcx
00007c454bbe3a8b  pop rax
00007c454bbe3a8c  add rsp, 0x08
00007c454bbe3a90  jmp 0x00007C454BBDF81D
00007c454bbe3a95  sub rsp, 0x08
00007c454bbe3a99  push rax
00007c454bbe3a9a  push rcx
00007c454bbe3a9b  push rdx
00007c454bbe3a9c  push rdi
00007c454bbe3a9d  push rsi
00007c454bbe3a9e  push r8
00007c454bbe3aa0  push r9
00007c454bbe3aa2  push r10
00007c454bbe3aa4  push r11
00007c454bbe3aa6  sub rsp, 0xF0
00007c454bbe3aad  vmovaps [rsp], xmm0
00007c454bbe3ab2  vmovaps [rsp+0x10], xmm1
00007c454bbe3ab8  vmovaps [rsp+0x20], xmm2
00007c454bbe3abe  vmovaps [rsp+0x30], xmm3
00007c454bbe3ac4  vmovaps [rsp+0x40], xmm4
00007c454bbe3aca  vmovaps [rsp+0x50], xmm5
00007c454bbe3ad0  vmovaps [rsp+0x60], xmm6
00007c454bbe3ad6  vmovaps [rsp+0x70], xmm7
00007c454bbe3adc  vmovaps [rsp+0x80], xmm8
00007c454bbe3ae5  vmovaps [rsp+0x90], xmm9
00007c454bbe3aee  vmovaps [rsp+0xA0], xmm10
00007c454bbe3af7  vmovaps [rsp+0xB0], xmm11
00007c454bbe3b00  vmovaps [rsp+0xC0], xmm12
00007c454bbe3b09  vmovaps [rsp+0xD0], xmm13
00007c454bbe3b12  vmovaps [rsp+0xE0], xmm14
00007c454bbe3b1b  sub rsp, 0x30
00007c454bbe3b1f  movaps [rsp], xmm15
00007c454bbe3b24  movaps [rsp+0x10], xmm11
00007c454bbe3b2a  movaps [rsp+0x20], xmm6
00007c454bbe3b2f  lea rdi, [rsp]
00007c454bbe3b33  mov esi, 0x00
00007c454bbe3b38  mov rax, 0x56A18AC54530
00007c454bbe3b42  call rax
00007c454bbe3b44  movaps xmm15, [rsp]
00007c454bbe3b49  add rsp, 0x30
00007c454bbe3b4d  vmovaps xmm0, [rsp]
00007c454bbe3b52  vmovaps xmm1, [rsp+0x10]
00007c454bbe3b58  vmovaps xmm2, [rsp+0x20]
00007c454bbe3b5e  vmovaps xmm3, [rsp+0x30]
00007c454bbe3b64  vmovaps xmm4, [rsp+0x40]
00007c454bbe3b6a  vmovaps xmm5, [rsp+0x50]
00007c454bbe3b70  vmovaps xmm6, [rsp+0x60]
00007c454bbe3b76  vmovaps xmm7, [rsp+0x70]
00007c454bbe3b7c  vmovaps xmm8, [rsp+0x80]
00007c454bbe3b85  vmovaps xmm9, [rsp+0x90]
00007c454bbe3b8e  vmovaps xmm10, [rsp+0xA0]
00007c454bbe3b97  vmovaps xmm11, [rsp+0xB0]
00007c454bbe3ba0  vmovaps xmm12, [rsp+0xC0]
00007c454bbe3ba9  vmovaps xmm13, [rsp+0xD0]
00007c454bbe3bb2  vmovaps xmm14, [rsp+0xE0]
00007c454bbe3bbb  add rsp, 0xF0
00007c454bbe3bc2  pop r11
00007c454bbe3bc4  pop r10
00007c454bbe3bc6  pop r9
00007c454bbe3bc8  pop r8
00007c454bbe3bca  pop rsi
00007c454bbe3bcb  pop rdi
00007c454bbe3bcc  pop rdx
00007c454bbe3bcd  pop rcx
00007c454bbe3bce  pop rax
00007c454bbe3bcf  add rsp, 0x08
00007c454bbe3bd3  jmp 0x00007C454BBDF838
00007c454bbe3bd8  sub rsp, 0x08
00007c454bbe3bdc  push rax
00007c454bbe3bdd  push rcx
00007c454bbe3bde  push rdx
00007c454bbe3bdf  push rdi
00007c454bbe3be0  push rsi
00007c454bbe3be1  push r8
00007c454bbe3be3  push r9
00007c454bbe3be5  push r10
00007c454bbe3be7  push r11
00007c454bbe3be9  sub rsp, 0xF0
00007c454bbe3bf0  vmovaps [rsp], xmm0
00007c454bbe3bf5  vmovaps [rsp+0x10], xmm1
00007c454bbe3bfb  vmovaps [rsp+0x20], xmm2
00007c454bbe3c01  vmovaps [rsp+0x30], xmm3
00007c454bbe3c07  vmovaps [rsp+0x40], xmm4
00007c454bbe3c0d  vmovaps [rsp+0x50], xmm5
00007c454bbe3c13  vmovaps [rsp+0x60], xmm6
00007c454bbe3c19  vmovaps [rsp+0x70], xmm8
00007c454bbe3c1f  vmovaps [rsp+0x80], xmm9
00007c454bbe3c28  vmovaps [rsp+0x90], xmm10
00007c454bbe3c31  vmovaps [rsp+0xA0], xmm11
00007c454bbe3c3a  vmovaps [rsp+0xB0], xmm12
00007c454bbe3c43  vmovaps [rsp+0xC0], xmm13
00007c454bbe3c4c  vmovaps [rsp+0xD0], xmm14
00007c454bbe3c55  vmovaps [rsp+0xE0], xmm15
00007c454bbe3c5e  sub rsp, 0x30
00007c454bbe3c62  movaps [rsp], xmm7
00007c454bbe3c66  movaps [rsp+0x10], xmm11
00007c454bbe3c6c  movaps [rsp+0x20], xmm9
00007c454bbe3c72  lea rdi, [rsp]
00007c454bbe3c76  mov esi, 0x00
00007c454bbe3c7b  mov rax, 0x56A18AC54530
00007c454bbe3c85  call rax
00007c454bbe3c87  movaps xmm7, [rsp]
00007c454bbe3c8b  add rsp, 0x30
00007c454bbe3c8f  vmovaps xmm0, [rsp]
00007c454bbe3c94  vmovaps xmm1, [rsp+0x10]
00007c454bbe3c9a  vmovaps xmm2, [rsp+0x20]
00007c454bbe3ca0  vmovaps xmm3, [rsp+0x30]
00007c454bbe3ca6  vmovaps xmm4, [rsp+0x40]
00007c454bbe3cac  vmovaps xmm5, [rsp+0x50]
00007c454bbe3cb2  vmovaps xmm6, [rsp+0x60]
00007c454bbe3cb8  vmovaps xmm8, [rsp+0x70]
00007c454bbe3cbe  vmovaps xmm9, [rsp+0x80]
00007c454bbe3cc7  vmovaps xmm10, [rsp+0x90]
00007c454bbe3cd0  vmovaps xmm11, [rsp+0xA0]
00007c454bbe3cd9  vmovaps xmm12, [rsp+0xB0]
00007c454bbe3ce2  vmovaps xmm13, [rsp+0xC0]
00007c454bbe3ceb  vmovaps xmm14, [rsp+0xD0]
00007c454bbe3cf4  vmovaps xmm15, [rsp+0xE0]
00007c454bbe3cfd  add rsp, 0xF0
00007c454bbe3d04  pop r11
00007c454bbe3d06  pop r10
00007c454bbe3d08  pop r9
00007c454bbe3d0a  pop r8
00007c454bbe3d0c  pop rsi
00007c454bbe3d0d  pop rdi
00007c454bbe3d0e  pop rdx
00007c454bbe3d0f  pop rcx
00007c454bbe3d10  pop rax
00007c454bbe3d11  add rsp, 0x08
00007c454bbe3d15  jmp 0x00007C454BBDF865
00007c454bbe3d1a  sub rsp, 0x08
00007c454bbe3d1e  push rax
00007c454bbe3d1f  push rcx
00007c454bbe3d20  push rdx
00007c454bbe3d21  push rdi
00007c454bbe3d22  push rsi
00007c454bbe3d23  push r8
00007c454bbe3d25  push r9
00007c454bbe3d27  push r10
00007c454bbe3d29  push r11
00007c454bbe3d2b  sub rsp, 0xF0
00007c454bbe3d32  vmovaps [rsp], xmm0
00007c454bbe3d37  vmovaps [rsp+0x10], xmm1
00007c454bbe3d3d  vmovaps [rsp+0x20], xmm2
00007c454bbe3d43  vmovaps [rsp+0x30], xmm3
00007c454bbe3d49  vmovaps [rsp+0x40], xmm4
00007c454bbe3d4f  vmovaps [rsp+0x50], xmm5
00007c454bbe3d55  vmovaps [rsp+0x60], xmm6
00007c454bbe3d5b  vmovaps [rsp+0x70], xmm7
00007c454bbe3d61  vmovaps [rsp+0x80], xmm8
00007c454bbe3d6a  vmovaps [rsp+0x90], xmm9
00007c454bbe3d73  vmovaps [rsp+0xA0], xmm10
00007c454bbe3d7c  vmovaps [rsp+0xB0], xmm12
00007c454bbe3d85  vmovaps [rsp+0xC0], xmm13
00007c454bbe3d8e  vmovaps [rsp+0xD0], xmm14
00007c454bbe3d97  vmovaps [rsp+0xE0], xmm15
00007c454bbe3da0  sub rsp, 0x30
00007c454bbe3da4  movaps [rsp], xmm11
00007c454bbe3da9  movaps [rsp+0x10], xmm10
00007c454bbe3daf  movaps [rsp+0x20], xmm14
00007c454bbe3db5  lea rdi, [rsp]
00007c454bbe3db9  mov esi, 0x00
00007c454bbe3dbe  mov rax, 0x56A18AC54530
00007c454bbe3dc8  call rax
00007c454bbe3dca  movaps xmm11, [rsp]
00007c454bbe3dcf  add rsp, 0x30
00007c454bbe3dd3  vmovaps xmm0, [rsp]
00007c454bbe3dd8  vmovaps xmm1, [rsp+0x10]
00007c454bbe3dde  vmovaps xmm2, [rsp+0x20]
00007c454bbe3de4  vmovaps xmm3, [rsp+0x30]
00007c454bbe3dea  vmovaps xmm4, [rsp+0x40]
00007c454bbe3df0  vmovaps xmm5, [rsp+0x50]
00007c454bbe3df6  vmovaps xmm6, [rsp+0x60]
00007c454bbe3dfc  vmovaps xmm7, [rsp+0x70]
00007c454bbe3e02  vmovaps xmm8, [rsp+0x80]
00007c454bbe3e0b  vmovaps xmm9, [rsp+0x90]
00007c454bbe3e14  vmovaps xmm10, [rsp+0xA0]
00007c454bbe3e1d  vmovaps xmm12, [rsp+0xB0]
00007c454bbe3e26  vmovaps xmm13, [rsp+0xC0]
00007c454bbe3e2f  vmovaps xmm14, [rsp+0xD0]
00007c454bbe3e38  vmovaps xmm15, [rsp+0xE0]
00007c454bbe3e41  add rsp, 0xF0
00007c454bbe3e48  pop r11
00007c454bbe3e4a  pop r10
00007c454bbe3e4c  pop r9
00007c454bbe3e4e  pop r8
00007c454bbe3e50  pop rsi
00007c454bbe3e51  pop rdi
00007c454bbe3e52  pop rdx
00007c454bbe3e53  pop rcx
00007c454bbe3e54  pop rax
00007c454bbe3e55  add rsp, 0x08
00007c454bbe3e59  jmp 0x00007C454BBDF880
00007c454bbe3e5e  call 0x00007C454BAC33A0
00007c454bbe3e63  jmp 0x00007C454BBDF88A
00007c454bbe3e68  sub rsp, 0x08
00007c454bbe3e6c  push rax
00007c454bbe3e6d  push rcx
00007c454bbe3e6e  push rdx
00007c454bbe3e6f  push rdi
00007c454bbe3e70  push rsi
00007c454bbe3e71  push r8
00007c454bbe3e73  push r9
00007c454bbe3e75  push r10
00007c454bbe3e77  push r11
00007c454bbe3e79  sub rsp, 0xF0
00007c454bbe3e80  vmovaps [rsp], xmm0
00007c454bbe3e85  vmovaps [rsp+0x10], xmm1
00007c454bbe3e8b  vmovaps [rsp+0x20], xmm2
00007c454bbe3e91  vmovaps [rsp+0x30], xmm3
00007c454bbe3e97  vmovaps [rsp+0x40], xmm4
00007c454bbe3e9d  vmovaps [rsp+0x50], xmm5
00007c454bbe3ea3  vmovaps [rsp+0x60], xmm6
00007c454bbe3ea9  vmovaps [rsp+0x70], xmm7
00007c454bbe3eaf  vmovaps [rsp+0x80], xmm8
00007c454bbe3eb8  vmovaps [rsp+0x90], xmm9
00007c454bbe3ec1  vmovaps [rsp+0xA0], xmm11
00007c454bbe3eca  vmovaps [rsp+0xB0], xmm12
00007c454bbe3ed3  vmovaps [rsp+0xC0], xmm13
00007c454bbe3edc  vmovaps [rsp+0xD0], xmm14
00007c454bbe3ee5  vmovaps [rsp+0xE0], xmm15
00007c454bbe3eee  sub rsp, 0x30
00007c454bbe3ef2  movaps [rsp], xmm10
00007c454bbe3ef7  movaps [rsp+0x10], xmm1
00007c454bbe3efc  movaps [rsp+0x20], xmm12
00007c454bbe3f02  lea rdi, [rsp]
00007c454bbe3f06  mov esi, 0x00
00007c454bbe3f0b  mov rax, 0x56A18AC54530
00007c454bbe3f15  call rax
00007c454bbe3f17  movaps xmm10, [rsp]
00007c454bbe3f1c  add rsp, 0x30
00007c454bbe3f20  vmovaps xmm0, [rsp]
00007c454bbe3f25  vmovaps xmm1, [rsp+0x10]
00007c454bbe3f2b  vmovaps xmm2, [rsp+0x20]
00007c454bbe3f31  vmovaps xmm3, [rsp+0x30]
00007c454bbe3f37  vmovaps xmm4, [rsp+0x40]
00007c454bbe3f3d  vmovaps xmm5, [rsp+0x50]
00007c454bbe3f43  vmovaps xmm6, [rsp+0x60]
00007c454bbe3f49  vmovaps xmm7, [rsp+0x70]
00007c454bbe3f4f  vmovaps xmm8, [rsp+0x80]
00007c454bbe3f58  vmovaps xmm9, [rsp+0x90]
00007c454bbe3f61  vmovaps xmm11, [rsp+0xA0]
00007c454bbe3f6a  vmovaps xmm12, [rsp+0xB0]
00007c454bbe3f73  vmovaps xmm13, [rsp+0xC0]
00007c454bbe3f7c  vmovaps xmm14, [rsp+0xD0]
00007c454bbe3f85  vmovaps xmm15, [rsp+0xE0]
00007c454bbe3f8e  add rsp, 0xF0
00007c454bbe3f95  pop r11
00007c454bbe3f97  pop r10
00007c454bbe3f99  pop r9
00007c454bbe3f9b  pop r8
00007c454bbe3f9d  pop rsi
00007c454bbe3f9e  pop rdi
00007c454bbe3f9f  pop rdx
00007c454bbe3fa0  pop rcx
00007c454bbe3fa1  pop rax
00007c454bbe3fa2  add rsp, 0x08
00007c454bbe3fa6  jmp 0x00007C454BBDF8AD
00007c454bbe3fab  sub rsp, 0x08
00007c454bbe3faf  push rax
00007c454bbe3fb0  push rcx
00007c454bbe3fb1  push rdx
00007c454bbe3fb2  push rdi
00007c454bbe3fb3  push rsi
00007c454bbe3fb4  push r8
00007c454bbe3fb6  push r9
00007c454bbe3fb8  push r10
00007c454bbe3fba  push r11
00007c454bbe3fbc  sub rsp, 0xF0
00007c454bbe3fc3  vmovaps [rsp], xmm0
00007c454bbe3fc8  vmovaps [rsp+0x10], xmm1
00007c454bbe3fce  vmovaps [rsp+0x20], xmm2
00007c454bbe3fd4  vmovaps [rsp+0x30], xmm3
00007c454bbe3fda  vmovaps [rsp+0x40], xmm4
00007c454bbe3fe0  vmovaps [rsp+0x50], xmm5
00007c454bbe3fe6  vmovaps [rsp+0x60], xmm6
00007c454bbe3fec  vmovaps [rsp+0x70], xmm7
00007c454bbe3ff2  vmovaps [rsp+0x80], xmm8
00007c454bbe3ffb  vmovaps [rsp+0x90], xmm9
00007c454bbe4004  vmovaps [rsp+0xA0], xmm10
00007c454bbe400d  vmovaps [rsp+0xB0], xmm11
00007c454bbe4016  vmovaps [rsp+0xC0], xmm13
00007c454bbe401f  vmovaps [rsp+0xD0], xmm14
00007c454bbe4028  vmovaps [rsp+0xE0], xmm15
00007c454bbe4031  sub rsp, 0x30
00007c454bbe4035  movaps [rsp], xmm12
00007c454bbe403a  movaps [rsp+0x10], xmm14
00007c454bbe4040  movaps [rsp+0x20], xmm1
00007c454bbe4045  lea rdi, [rsp]
00007c454bbe4049  mov esi, 0x00
00007c454bbe404e  mov rax, 0x56A18AC54530
00007c454bbe4058  call rax
00007c454bbe405a  movaps xmm12, [rsp]
00007c454bbe405f  add rsp, 0x30
00007c454bbe4063  vmovaps xmm0, [rsp]
00007c454bbe4068  vmovaps xmm1, [rsp+0x10]
00007c454bbe406e  vmovaps xmm2, [rsp+0x20]
00007c454bbe4074  vmovaps xmm3, [rsp+0x30]
00007c454bbe407a  vmovaps xmm4, [rsp+0x40]
00007c454bbe4080  vmovaps xmm5, [rsp+0x50]
00007c454bbe4086  vmovaps xmm6, [rsp+0x60]
00007c454bbe408c  vmovaps xmm7, [rsp+0x70]
00007c454bbe4092  vmovaps xmm8, [rsp+0x80]
00007c454bbe409b  vmovaps xmm9, [rsp+0x90]
00007c454bbe40a4  vmovaps xmm10, [rsp+0xA0]
00007c454bbe40ad  vmovaps xmm11, [rsp+0xB0]
00007c454bbe40b6  vmovaps xmm13, [rsp+0xC0]
00007c454bbe40bf  vmovaps xmm14, [rsp+0xD0]
00007c454bbe40c8  vmovaps xmm15, [rsp+0xE0]
00007c454bbe40d1  add rsp, 0xF0
00007c454bbe40d8  pop r11
00007c454bbe40da  pop r10
00007c454bbe40dc  pop r9
00007c454bbe40de  pop r8
00007c454bbe40e0  pop rsi
00007c454bbe40e1  pop rdi
00007c454bbe40e2  pop rdx
00007c454bbe40e3  pop rcx
00007c454bbe40e4  pop rax
00007c454bbe40e5  add rsp, 0x08
00007c454bbe40e9  jmp 0x00007C454BBDF8DC
00007c454bbe40ee  sub rsp, 0x08
00007c454bbe40f2  push rax
00007c454bbe40f3  push rcx
00007c454bbe40f4  push rdx
00007c454bbe40f5  push rdi
00007c454bbe40f6  push rsi
00007c454bbe40f7  push r8
00007c454bbe40f9  push r9
00007c454bbe40fb  push r10
00007c454bbe40fd  push r11
00007c454bbe40ff  sub rsp, 0xF0
00007c454bbe4106  vmovaps [rsp], xmm0
00007c454bbe410b  vmovaps [rsp+0x10], xmm1
00007c454bbe4111  vmovaps [rsp+0x20], xmm2
00007c454bbe4117  vmovaps [rsp+0x30], xmm3
00007c454bbe411d  vmovaps [rsp+0x40], xmm4
00007c454bbe4123  vmovaps [rsp+0x50], xmm5
00007c454bbe4129  vmovaps [rsp+0x60], xmm6
00007c454bbe412f  vmovaps [rsp+0x70], xmm7
00007c454bbe4135  vmovaps [rsp+0x80], xmm8
00007c454bbe413e  vmovaps [rsp+0x90], xmm9
00007c454bbe4147  vmovaps [rsp+0xA0], xmm10
00007c454bbe4150  vmovaps [rsp+0xB0], xmm11
00007c454bbe4159  vmovaps [rsp+0xC0], xmm12
00007c454bbe4162  vmovaps [rsp+0xD0], xmm13
00007c454bbe416b  vmovaps [rsp+0xE0], xmm15
00007c454bbe4174  sub rsp, 0x30
00007c454bbe4178  movaps [rsp], xmm14
00007c454bbe417d  movaps [rsp+0x10], xmm9
00007c454bbe4183  movaps [rsp+0x20], xmm1
00007c454bbe4188  lea rdi, [rsp]
00007c454bbe418c  mov esi, 0x00
00007c454bbe4191  mov rax, 0x56A18AC54530
00007c454bbe419b  call rax
00007c454bbe419d  movaps xmm14, [rsp]
00007c454bbe41a2  add rsp, 0x30
00007c454bbe41a6  vmovaps xmm0, [rsp]
00007c454bbe41ab  vmovaps xmm1, [rsp+0x10]
00007c454bbe41b1  vmovaps xmm2, [rsp+0x20]
00007c454bbe41b7  vmovaps xmm3, [rsp+0x30]
00007c454bbe41bd  vmovaps xmm4, [rsp+0x40]
00007c454bbe41c3  vmovaps xmm5, [rsp+0x50]
00007c454bbe41c9  vmovaps xmm6, [rsp+0x60]
00007c454bbe41cf  vmovaps xmm7, [rsp+0x70]
00007c454bbe41d5  vmovaps xmm8, [rsp+0x80]
00007c454bbe41de  vmovaps xmm9, [rsp+0x90]
00007c454bbe41e7  vmovaps xmm10, [rsp+0xA0]
00007c454bbe41f0  vmovaps xmm11, [rsp+0xB0]
00007c454bbe41f9  vmovaps xmm12, [rsp+0xC0]
00007c454bbe4202  vmovaps xmm13, [rsp+0xD0]
00007c454bbe420b  vmovaps xmm15, [rsp+0xE0]
00007c454bbe4214  add rsp, 0xF0
00007c454bbe421b  pop r11
00007c454bbe421d  pop r10
00007c454bbe421f  pop r9
00007c454bbe4221  pop r8
00007c454bbe4223  pop rsi
00007c454bbe4224  pop rdi
00007c454bbe4225  pop rdx
00007c454bbe4226  pop rcx
00007c454bbe4227  pop rax
00007c454bbe4228  add rsp, 0x08
00007c454bbe422c  jmp 0x00007C454BBDF90B
00007c454bbe4231  sub rsp, 0x08
00007c454bbe4235  push rax
00007c454bbe4236  push rcx
00007c454bbe4237  push rdx
00007c454bbe4238  push rdi
00007c454bbe4239  push rsi
00007c454bbe423a  push r8
00007c454bbe423c  push r9
00007c454bbe423e  push r10
00007c454bbe4240  push r11
00007c454bbe4242  sub rsp, 0xF0
00007c454bbe4249  vmovaps [rsp], xmm0
00007c454bbe424e  vmovaps [rsp+0x10], xmm2
00007c454bbe4254  vmovaps [rsp+0x20], xmm3
00007c454bbe425a  vmovaps [rsp+0x30], xmm4
00007c454bbe4260  vmovaps [rsp+0x40], xmm5
00007c454bbe4266  vmovaps [rsp+0x50], xmm6
00007c454bbe426c  vmovaps [rsp+0x60], xmm7
00007c454bbe4272  vmovaps [rsp+0x70], xmm8
00007c454bbe4278  vmovaps [rsp+0x80], xmm9
00007c454bbe4281  vmovaps [rsp+0x90], xmm10
00007c454bbe428a  vmovaps [rsp+0xA0], xmm11
00007c454bbe4293  vmovaps [rsp+0xB0], xmm12
00007c454bbe429c  vmovaps [rsp+0xC0], xmm13
00007c454bbe42a5  vmovaps [rsp+0xD0], xmm14
00007c454bbe42ae  vmovaps [rsp+0xE0], xmm15
00007c454bbe42b7  sub rsp, 0x30
00007c454bbe42bb  movaps [rsp], xmm1
00007c454bbe42bf  movaps [rsp+0x10], xmm13
00007c454bbe42c5  movaps [rsp+0x20], xmm8
00007c454bbe42cb  lea rdi, [rsp]
00007c454bbe42cf  mov esi, 0x00
00007c454bbe42d4  mov rax, 0x56A18AC54530
00007c454bbe42de  call rax
00007c454bbe42e0  movaps xmm1, [rsp]
00007c454bbe42e4  add rsp, 0x30
00007c454bbe42e8  vmovaps xmm0, [rsp]
00007c454bbe42ed  vmovaps xmm2, [rsp+0x10]
00007c454bbe42f3  vmovaps xmm3, [rsp+0x20]
00007c454bbe42f9  vmovaps xmm4, [rsp+0x30]
00007c454bbe42ff  vmovaps xmm5, [rsp+0x40]
00007c454bbe4305  vmovaps xmm6, [rsp+0x50]
00007c454bbe430b  vmovaps xmm7, [rsp+0x60]
00007c454bbe4311  vmovaps xmm8, [rsp+0x70]
00007c454bbe4317  vmovaps xmm9, [rsp+0x80]
00007c454bbe4320  vmovaps xmm10, [rsp+0x90]
00007c454bbe4329  vmovaps xmm11, [rsp+0xA0]
00007c454bbe4332  vmovaps xmm12, [rsp+0xB0]
00007c454bbe433b  vmovaps xmm13, [rsp+0xC0]
00007c454bbe4344  vmovaps xmm14, [rsp+0xD0]
00007c454bbe434d  vmovaps xmm15, [rsp+0xE0]
00007c454bbe4356  add rsp, 0xF0
00007c454bbe435d  pop r11
00007c454bbe435f  pop r10
00007c454bbe4361  pop r9
00007c454bbe4363  pop r8
00007c454bbe4365  pop rsi
00007c454bbe4366  pop rdi
00007c454bbe4367  pop rdx
00007c454bbe4368  pop rcx
00007c454bbe4369  pop rax
00007c454bbe436a  add rsp, 0x08
00007c454bbe436e  jmp 0x00007C454BBDF92D
00007c454bbe4373  call 0x00007C454BA0C260
00007c454bbe4378  jmp 0x00007C454BBDF93B
00007c454bbe437d  call 0x00007C454BABD750
00007c454bbe4382  jmp 0x00007C454BBDF945
00007c454bbe4387  sub rsp, 0x08
00007c454bbe438b  push rax
00007c454bbe438c  push rcx
00007c454bbe438d  push rdx
00007c454bbe438e  push rdi
00007c454bbe438f  push rsi
00007c454bbe4390  push r8
00007c454bbe4392  push r9
00007c454bbe4394  push r10
00007c454bbe4396  push r11
00007c454bbe4398  sub rsp, 0xF0
00007c454bbe439f  vmovaps [rsp], xmm0
00007c454bbe43a4  vmovaps [rsp+0x10], xmm1
00007c454bbe43aa  vmovaps [rsp+0x20], xmm2
00007c454bbe43b0  vmovaps [rsp+0x30], xmm3
00007c454bbe43b6  vmovaps [rsp+0x40], xmm4
00007c454bbe43bc  vmovaps [rsp+0x50], xmm5
00007c454bbe43c2  vmovaps [rsp+0x60], xmm6
00007c454bbe43c8  vmovaps [rsp+0x70], xmm7
00007c454bbe43ce  vmovaps [rsp+0x80], xmm9
00007c454bbe43d7  vmovaps [rsp+0x90], xmm10
00007c454bbe43e0  vmovaps [rsp+0xA0], xmm11
00007c454bbe43e9  vmovaps [rsp+0xB0], xmm12
00007c454bbe43f2  vmovaps [rsp+0xC0], xmm13
00007c454bbe43fb  vmovaps [rsp+0xD0], xmm14
00007c454bbe4404  vmovaps [rsp+0xE0], xmm15
00007c454bbe440d  sub rsp, 0x30
00007c454bbe4411  movaps [rsp], xmm8
00007c454bbe4416  movaps [rsp+0x10], xmm15
00007c454bbe441c  movaps [rsp+0x20], xmm7
00007c454bbe4421  lea rdi, [rsp]
00007c454bbe4425  mov esi, 0x00
00007c454bbe442a  mov rax, 0x56A18AC54530
00007c454bbe4434  call rax
00007c454bbe4436  movaps xmm8, [rsp]
00007c454bbe443b  add rsp, 0x30
00007c454bbe443f  vmovaps xmm0, [rsp]
00007c454bbe4444  vmovaps xmm1, [rsp+0x10]
00007c454bbe444a  vmovaps xmm2, [rsp+0x20]
00007c454bbe4450  vmovaps xmm3, [rsp+0x30]
00007c454bbe4456  vmovaps xmm4, [rsp+0x40]
00007c454bbe445c  vmovaps xmm5, [rsp+0x50]
00007c454bbe4462  vmovaps xmm6, [rsp+0x60]
00007c454bbe4468  vmovaps xmm7, [rsp+0x70]
00007c454bbe446e  vmovaps xmm9, [rsp+0x80]
00007c454bbe4477  vmovaps xmm10, [rsp+0x90]
00007c454bbe4480  vmovaps xmm11, [rsp+0xA0]
00007c454bbe4489  vmovaps xmm12, [rsp+0xB0]
00007c454bbe4492  vmovaps xmm13, [rsp+0xC0]
00007c454bbe449b  vmovaps xmm14, [rsp+0xD0]
00007c454bbe44a4  vmovaps xmm15, [rsp+0xE0]
00007c454bbe44ad  add rsp, 0xF0
00007c454bbe44b4  pop r11
00007c454bbe44b6  pop r10
00007c454bbe44b8  pop r9
00007c454bbe44ba  pop r8
00007c454bbe44bc  pop rsi
00007c454bbe44bd  pop rdi
00007c454bbe44be  pop rdx
00007c454bbe44bf  pop rcx
00007c454bbe44c0  pop rax
00007c454bbe44c1  add rsp, 0x08
00007c454bbe44c5  jmp 0x00007C454BBDF967
00007c454bbe44ca  sub rsp, 0x08
00007c454bbe44ce  push rax
00007c454bbe44cf  push rcx
00007c454bbe44d0  push rdx
00007c454bbe44d1  push rdi
00007c454bbe44d2  push rsi
00007c454bbe44d3  push r8
00007c454bbe44d5  push r9
00007c454bbe44d7  push r10
00007c454bbe44d9  push r11
00007c454bbe44db  sub rsp, 0xF0
00007c454bbe44e2  vmovaps [rsp], xmm0
00007c454bbe44e7  vmovaps [rsp+0x10], xmm1
00007c454bbe44ed  vmovaps [rsp+0x20], xmm2
00007c454bbe44f3  vmovaps [rsp+0x30], xmm3
00007c454bbe44f9  vmovaps [rsp+0x40], xmm4
00007c454bbe44ff  vmovaps [rsp+0x50], xmm5
00007c454bbe4505  vmovaps [rsp+0x60], xmm6
00007c454bbe450b  vmovaps [rsp+0x70], xmm8
00007c454bbe4511  vmovaps [rsp+0x80], xmm9
00007c454bbe451a  vmovaps [rsp+0x90], xmm10
00007c454bbe4523  vmovaps [rsp+0xA0], xmm11
00007c454bbe452c  vmovaps [rsp+0xB0], xmm12
00007c454bbe4535  vmovaps [rsp+0xC0], xmm13
00007c454bbe453e  vmovaps [rsp+0xD0], xmm14
00007c454bbe4547  vmovaps [rsp+0xE0], xmm15
00007c454bbe4550  sub rsp, 0x30
00007c454bbe4554  movaps [rsp], xmm7
00007c454bbe4558  movaps [rsp+0x10], xmm9
00007c454bbe455e  movaps [rsp+0x20], xmm15
00007c454bbe4564  lea rdi, [rsp]
00007c454bbe4568  mov esi, 0x00
00007c454bbe456d  mov rax, 0x56A18AC54530
00007c454bbe4577  call rax
00007c454bbe4579  movaps xmm7, [rsp]
00007c454bbe457d  add rsp, 0x30
00007c454bbe4581  vmovaps xmm0, [rsp]
00007c454bbe4586  vmovaps xmm1, [rsp+0x10]
00007c454bbe458c  vmovaps xmm2, [rsp+0x20]
00007c454bbe4592  vmovaps xmm3, [rsp+0x30]
00007c454bbe4598  vmovaps xmm4, [rsp+0x40]
00007c454bbe459e  vmovaps xmm5, [rsp+0x50]
00007c454bbe45a4  vmovaps xmm6, [rsp+0x60]
00007c454bbe45aa  vmovaps xmm8, [rsp+0x70]
00007c454bbe45b0  vmovaps xmm9, [rsp+0x80]
00007c454bbe45b9  vmovaps xmm10, [rsp+0x90]
00007c454bbe45c2  vmovaps xmm11, [rsp+0xA0]
00007c454bbe45cb  vmovaps xmm12, [rsp+0xB0]
00007c454bbe45d4  vmovaps xmm13, [rsp+0xC0]
00007c454bbe45dd  vmovaps xmm14, [rsp+0xD0]
00007c454bbe45e6  vmovaps xmm15, [rsp+0xE0]
00007c454bbe45ef  add rsp, 0xF0
00007c454bbe45f6  pop r11
00007c454bbe45f8  pop r10
00007c454bbe45fa  pop r9
00007c454bbe45fc  pop r8
00007c454bbe45fe  pop rsi
00007c454bbe45ff  pop rdi
00007c454bbe4600  pop rdx
00007c454bbe4601  pop rcx
00007c454bbe4602  pop rax
00007c454bbe4603  add rsp, 0x08
00007c454bbe4607  jmp 0x00007C454BBDF994
00007c454bbe460c  sub rsp, 0x08
00007c454bbe4610  push rax
00007c454bbe4611  push rcx
00007c454bbe4612  push rdx
00007c454bbe4613  push rdi
00007c454bbe4614  push rsi
00007c454bbe4615  push r8
00007c454bbe4617  push r9
00007c454bbe4619  push r10
00007c454bbe461b  push r11
00007c454bbe461d  sub rsp, 0xF0
00007c454bbe4624  vmovaps [rsp], xmm0
00007c454bbe4629  vmovaps [rsp+0x10], xmm1
00007c454bbe462f  vmovaps [rsp+0x20], xmm2
00007c454bbe4635  vmovaps [rsp+0x30], xmm3
00007c454bbe463b  vmovaps [rsp+0x40], xmm4
00007c454bbe4641  vmovaps [rsp+0x50], xmm5
00007c454bbe4647  vmovaps [rsp+0x60], xmm6
00007c454bbe464d  vmovaps [rsp+0x70], xmm7
00007c454bbe4653  vmovaps [rsp+0x80], xmm8
00007c454bbe465c  vmovaps [rsp+0x90], xmm10
00007c454bbe4665  vmovaps [rsp+0xA0], xmm11
00007c454bbe466e  vmovaps [rsp+0xB0], xmm12
00007c454bbe4677  vmovaps [rsp+0xC0], xmm13
00007c454bbe4680  vmovaps [rsp+0xD0], xmm14
00007c454bbe4689  vmovaps [rsp+0xE0], xmm15
00007c454bbe4692  sub rsp, 0x30
00007c454bbe4696  movaps [rsp], xmm9
00007c454bbe469b  movaps [rsp+0x10], xmm13
00007c454bbe46a1  movaps [rsp+0x20], xmm15
00007c454bbe46a7  lea rdi, [rsp]
00007c454bbe46ab  mov esi, 0x00
00007c454bbe46b0  mov rax, 0x56A18AC54530
00007c454bbe46ba  call rax
00007c454bbe46bc  movaps xmm9, [rsp]
00007c454bbe46c1  add rsp, 0x30
00007c454bbe46c5  vmovaps xmm0, [rsp]
00007c454bbe46ca  vmovaps xmm1, [rsp+0x10]
00007c454bbe46d0  vmovaps xmm2, [rsp+0x20]
00007c454bbe46d6  vmovaps xmm3, [rsp+0x30]
00007c454bbe46dc  vmovaps xmm4, [rsp+0x40]
00007c454bbe46e2  vmovaps xmm5, [rsp+0x50]
00007c454bbe46e8  vmovaps xmm6, [rsp+0x60]
00007c454bbe46ee  vmovaps xmm7, [rsp+0x70]
00007c454bbe46f4  vmovaps xmm8, [rsp+0x80]
00007c454bbe46fd  vmovaps xmm10, [rsp+0x90]
00007c454bbe4706  vmovaps xmm11, [rsp+0xA0]
00007c454bbe470f  vmovaps xmm12, [rsp+0xB0]
00007c454bbe4718  vmovaps xmm13, [rsp+0xC0]
00007c454bbe4721  vmovaps xmm14, [rsp+0xD0]
00007c454bbe472a  vmovaps xmm15, [rsp+0xE0]
00007c454bbe4733  add rsp, 0xF0
00007c454bbe473a  pop r11
00007c454bbe473c  pop r10
00007c454bbe473e  pop r9
00007c454bbe4740  pop r8
00007c454bbe4742  pop rsi
00007c454bbe4743  pop rdi
00007c454bbe4744  pop rdx
00007c454bbe4745  pop rcx
00007c454bbe4746  pop rax
00007c454bbe4747  add rsp, 0x08
00007c454bbe474b  jmp 0x00007C454BBDF9C2
00007c454bbe4750  sub rsp, 0x08
00007c454bbe4754  push rax
00007c454bbe4755  push rcx
00007c454bbe4756  push rdx
00007c454bbe4757  push rdi
00007c454bbe4758  push rsi
00007c454bbe4759  push r8
00007c454bbe475b  push r9
00007c454bbe475d  push r10
00007c454bbe475f  push r11
00007c454bbe4761  sub rsp, 0xF0
00007c454bbe4768  vmovaps [rsp], xmm0
00007c454bbe476d  vmovaps [rsp+0x10], xmm1
00007c454bbe4773  vmovaps [rsp+0x20], xmm2
00007c454bbe4779  vmovaps [rsp+0x30], xmm3
00007c454bbe477f  vmovaps [rsp+0x40], xmm4
00007c454bbe4785  vmovaps [rsp+0x50], xmm5
00007c454bbe478b  vmovaps [rsp+0x60], xmm6
00007c454bbe4791  vmovaps [rsp+0x70], xmm7
00007c454bbe4797  vmovaps [rsp+0x80], xmm8
00007c454bbe47a0  vmovaps [rsp+0x90], xmm9
00007c454bbe47a9  vmovaps [rsp+0xA0], xmm10
00007c454bbe47b2  vmovaps [rsp+0xB0], xmm11
00007c454bbe47bb  vmovaps [rsp+0xC0], xmm12
00007c454bbe47c4  vmovaps [rsp+0xD0], xmm13
00007c454bbe47cd  vmovaps [rsp+0xE0], xmm14
00007c454bbe47d6  sub rsp, 0x30
00007c454bbe47da  movaps [rsp], xmm15
00007c454bbe47df  movaps [rsp+0x10], xmm11
00007c454bbe47e5  movaps [rsp+0x20], xmm12
00007c454bbe47eb  lea rdi, [rsp]
00007c454bbe47ef  mov esi, 0x00
00007c454bbe47f4  mov rax, 0x56A18AC54530
00007c454bbe47fe  call rax
00007c454bbe4800  movaps xmm15, [rsp]
00007c454bbe4805  add rsp, 0x30
00007c454bbe4809  vmovaps xmm0, [rsp]
00007c454bbe480e  vmovaps xmm1, [rsp+0x10]
00007c454bbe4814  vmovaps xmm2, [rsp+0x20]
00007c454bbe481a  vmovaps xmm3, [rsp+0x30]
00007c454bbe4820  vmovaps xmm4, [rsp+0x40]
00007c454bbe4826  vmovaps xmm5, [rsp+0x50]
00007c454bbe482c  vmovaps xmm6, [rsp+0x60]
00007c454bbe4832  vmovaps xmm7, [rsp+0x70]
00007c454bbe4838  vmovaps xmm8, [rsp+0x80]
00007c454bbe4841  vmovaps xmm9, [rsp+0x90]
00007c454bbe484a  vmovaps xmm10, [rsp+0xA0]
00007c454bbe4853  vmovaps xmm11, [rsp+0xB0]
00007c454bbe485c  vmovaps xmm12, [rsp+0xC0]
00007c454bbe4865  vmovaps xmm13, [rsp+0xD0]
00007c454bbe486e  vmovaps xmm14, [rsp+0xE0]
00007c454bbe4877  add rsp, 0xF0
00007c454bbe487e  pop r11
00007c454bbe4880  pop r10
00007c454bbe4882  pop r9
00007c454bbe4884  pop r8
00007c454bbe4886  pop rsi
00007c454bbe4887  pop rdi
00007c454bbe4888  pop rdx
00007c454bbe4889  pop rcx
00007c454bbe488a  pop rax
00007c454bbe488b  add rsp, 0x08
00007c454bbe488f  jmp 0x00007C454BBDF9DD
00007c454bbe4894  sub rsp, 0x08
00007c454bbe4898  push rax
00007c454bbe4899  push rcx
00007c454bbe489a  push rdx
00007c454bbe489b  push rdi
00007c454bbe489c  push rsi
00007c454bbe489d  push r8
00007c454bbe489f  push r9
00007c454bbe48a1  push r10
00007c454bbe48a3  push r11
00007c454bbe48a5  sub rsp, 0xF0
00007c454bbe48ac  vmovaps [rsp], xmm0
00007c454bbe48b1  vmovaps [rsp+0x10], xmm1
00007c454bbe48b7  vmovaps [rsp+0x20], xmm2
00007c454bbe48bd  vmovaps [rsp+0x30], xmm3
00007c454bbe48c3  vmovaps [rsp+0x40], xmm4
00007c454bbe48c9  vmovaps [rsp+0x50], xmm5
00007c454bbe48cf  vmovaps [rsp+0x60], xmm6
00007c454bbe48d5  vmovaps [rsp+0x70], xmm7
00007c454bbe48db  vmovaps [rsp+0x80], xmm8
00007c454bbe48e4  vmovaps [rsp+0x90], xmm9
00007c454bbe48ed  vmovaps [rsp+0xA0], xmm10
00007c454bbe48f6  vmovaps [rsp+0xB0], xmm11
00007c454bbe48ff  vmovaps [rsp+0xC0], xmm12
00007c454bbe4908  vmovaps [rsp+0xD0], xmm14
00007c454bbe4911  vmovaps [rsp+0xE0], xmm15
00007c454bbe491a  sub rsp, 0x30
00007c454bbe491e  movaps [rsp], xmm13
00007c454bbe4923  movaps [rsp+0x10], xmm10
00007c454bbe4929  movaps [rsp+0x20], xmm14
00007c454bbe492f  lea rdi, [rsp]
00007c454bbe4933  mov esi, 0x00
00007c454bbe4938  mov rax, 0x56A18AC54530
00007c454bbe4942  call rax
00007c454bbe4944  movaps xmm13, [rsp]
00007c454bbe4949  add rsp, 0x30
00007c454bbe494d  vmovaps xmm0, [rsp]
00007c454bbe4952  vmovaps xmm1, [rsp+0x10]
00007c454bbe4958  vmovaps xmm2, [rsp+0x20]
00007c454bbe495e  vmovaps xmm3, [rsp+0x30]
00007c454bbe4964  vmovaps xmm4, [rsp+0x40]
00007c454bbe496a  vmovaps xmm5, [rsp+0x50]
00007c454bbe4970  vmovaps xmm6, [rsp+0x60]
00007c454bbe4976  vmovaps xmm7, [rsp+0x70]
00007c454bbe497c  vmovaps xmm8, [rsp+0x80]
00007c454bbe4985  vmovaps xmm9, [rsp+0x90]
00007c454bbe498e  vmovaps xmm10, [rsp+0xA0]
00007c454bbe4997  vmovaps xmm11, [rsp+0xB0]
00007c454bbe49a0  vmovaps xmm12, [rsp+0xC0]
00007c454bbe49a9  vmovaps xmm14, [rsp+0xD0]
00007c454bbe49b2  vmovaps xmm15, [rsp+0xE0]
00007c454bbe49bb  add rsp, 0xF0
00007c454bbe49c2  pop r11
00007c454bbe49c4  pop r10
00007c454bbe49c6  pop r9
00007c454bbe49c8  pop r8
00007c454bbe49ca  pop rsi
00007c454bbe49cb  pop rdi
00007c454bbe49cc  pop rdx
00007c454bbe49cd  pop rcx
00007c454bbe49ce  pop rax
00007c454bbe49cf  add rsp, 0x08
00007c454bbe49d3  jmp 0x00007C454BBDFA00
00007c454bbe49d8  sub rsp, 0x08
00007c454bbe49dc  push rax
00007c454bbe49dd  push rcx
00007c454bbe49de  push rdx
00007c454bbe49df  push rdi
00007c454bbe49e0  push rsi
00007c454bbe49e1  push r8
00007c454bbe49e3  push r9
00007c454bbe49e5  push r10
00007c454bbe49e7  push r11
00007c454bbe49e9  sub rsp, 0xF0
00007c454bbe49f0  vmovaps [rsp], xmm0
00007c454bbe49f5  vmovaps [rsp+0x10], xmm1
00007c454bbe49fb  vmovaps [rsp+0x20], xmm2
00007c454bbe4a01  vmovaps [rsp+0x30], xmm3
00007c454bbe4a07  vmovaps [rsp+0x40], xmm4
00007c454bbe4a0d  vmovaps [rsp+0x50], xmm5
00007c454bbe4a13  vmovaps [rsp+0x60], xmm6
00007c454bbe4a19  vmovaps [rsp+0x70], xmm7
00007c454bbe4a1f  vmovaps [rsp+0x80], xmm8
00007c454bbe4a28  vmovaps [rsp+0x90], xmm9
00007c454bbe4a31  vmovaps [rsp+0xA0], xmm10
00007c454bbe4a3a  vmovaps [rsp+0xB0], xmm11
00007c454bbe4a43  vmovaps [rsp+0xC0], xmm12
00007c454bbe4a4c  vmovaps [rsp+0xD0], xmm13
00007c454bbe4a55  vmovaps [rsp+0xE0], xmm15
00007c454bbe4a5e  sub rsp, 0x30
00007c454bbe4a62  movaps [rsp], xmm14
00007c454bbe4a67  movaps [rsp+0x10], xmm1
00007c454bbe4a6c  movaps [rsp+0x20], xmm7
00007c454bbe4a71  lea rdi, [rsp]
00007c454bbe4a75  mov esi, 0x00
00007c454bbe4a7a  mov rax, 0x56A18AC54530
00007c454bbe4a84  call rax
00007c454bbe4a86  movaps xmm14, [rsp]
00007c454bbe4a8b  add rsp, 0x30
00007c454bbe4a8f  vmovaps xmm0, [rsp]
00007c454bbe4a94  vmovaps xmm1, [rsp+0x10]
00007c454bbe4a9a  vmovaps xmm2, [rsp+0x20]
00007c454bbe4aa0  vmovaps xmm3, [rsp+0x30]
00007c454bbe4aa6  vmovaps xmm4, [rsp+0x40]
00007c454bbe4aac  vmovaps xmm5, [rsp+0x50]
00007c454bbe4ab2  vmovaps xmm6, [rsp+0x60]
00007c454bbe4ab8  vmovaps xmm7, [rsp+0x70]
00007c454bbe4abe  vmovaps xmm8, [rsp+0x80]
00007c454bbe4ac7  vmovaps xmm9, [rsp+0x90]
00007c454bbe4ad0  vmovaps xmm10, [rsp+0xA0]
00007c454bbe4ad9  vmovaps xmm11, [rsp+0xB0]
00007c454bbe4ae2  vmovaps xmm12, [rsp+0xC0]
00007c454bbe4aeb  vmovaps xmm13, [rsp+0xD0]
00007c454bbe4af4  vmovaps xmm15, [rsp+0xE0]
00007c454bbe4afd  add rsp, 0xF0
00007c454bbe4b04  pop r11
00007c454bbe4b06  pop r10
00007c454bbe4b08  pop r9
00007c454bbe4b0a  pop r8
00007c454bbe4b0c  pop rsi
00007c454bbe4b0d  pop rdi
00007c454bbe4b0e  pop rdx
00007c454bbe4b0f  pop rcx
00007c454bbe4b10  pop rax
00007c454bbe4b11  add rsp, 0x08
00007c454bbe4b15  jmp 0x00007C454BBDFA23
00007c454bbe4b1a  sub rsp, 0x08
00007c454bbe4b1e  push rax
00007c454bbe4b1f  push rcx
00007c454bbe4b20  push rdx
00007c454bbe4b21  push rdi
00007c454bbe4b22  push rsi
00007c454bbe4b23  push r8
00007c454bbe4b25  push r9
00007c454bbe4b27  push r10
00007c454bbe4b29  push r11
00007c454bbe4b2b  sub rsp, 0xF0
00007c454bbe4b32  vmovaps [rsp], xmm0
00007c454bbe4b37  vmovaps [rsp+0x10], xmm2
00007c454bbe4b3d  vmovaps [rsp+0x20], xmm3
00007c454bbe4b43  vmovaps [rsp+0x30], xmm4
00007c454bbe4b49  vmovaps [rsp+0x40], xmm5
00007c454bbe4b4f  vmovaps [rsp+0x50], xmm6
00007c454bbe4b55  vmovaps [rsp+0x60], xmm7
00007c454bbe4b5b  vmovaps [rsp+0x70], xmm8
00007c454bbe4b61  vmovaps [rsp+0x80], xmm9
00007c454bbe4b6a  vmovaps [rsp+0x90], xmm10
00007c454bbe4b73  vmovaps [rsp+0xA0], xmm11
00007c454bbe4b7c  vmovaps [rsp+0xB0], xmm12
00007c454bbe4b85  vmovaps [rsp+0xC0], xmm13
00007c454bbe4b8e  vmovaps [rsp+0xD0], xmm14
00007c454bbe4b97  vmovaps [rsp+0xE0], xmm15
00007c454bbe4ba0  sub rsp, 0x30
00007c454bbe4ba4  movaps [rsp], xmm1
00007c454bbe4ba8  movaps [rsp+0x10], xmm8
00007c454bbe4bae  movaps [rsp+0x20], xmm9
00007c454bbe4bb4  lea rdi, [rsp]
00007c454bbe4bb8  mov esi, 0x00
00007c454bbe4bbd  mov rax, 0x56A18AC54530
00007c454bbe4bc7  call rax
00007c454bbe4bc9  movaps xmm1, [rsp]
00007c454bbe4bcd  add rsp, 0x30
00007c454bbe4bd1  vmovaps xmm0, [rsp]
00007c454bbe4bd6  vmovaps xmm2, [rsp+0x10]
00007c454bbe4bdc  vmovaps xmm3, [rsp+0x20]
00007c454bbe4be2  vmovaps xmm4, [rsp+0x30]
00007c454bbe4be8  vmovaps xmm5, [rsp+0x40]
00007c454bbe4bee  vmovaps xmm6, [rsp+0x50]
00007c454bbe4bf4  vmovaps xmm7, [rsp+0x60]
00007c454bbe4bfa  vmovaps xmm8, [rsp+0x70]
00007c454bbe4c00  vmovaps xmm9, [rsp+0x80]
00007c454bbe4c09  vmovaps xmm10, [rsp+0x90]
00007c454bbe4c12  vmovaps xmm11, [rsp+0xA0]
00007c454bbe4c1b  vmovaps xmm12, [rsp+0xB0]
00007c454bbe4c24  vmovaps xmm13, [rsp+0xC0]
00007c454bbe4c2d  vmovaps xmm14, [rsp+0xD0]
00007c454bbe4c36  vmovaps xmm15, [rsp+0xE0]
00007c454bbe4c3f  add rsp, 0xF0
00007c454bbe4c46  pop r11
00007c454bbe4c48  pop r10
00007c454bbe4c4a  pop r9
00007c454bbe4c4c  pop r8
00007c454bbe4c4e  pop rsi
00007c454bbe4c4f  pop rdi
00007c454bbe4c50  pop rdx
00007c454bbe4c51  pop rcx
00007c454bbe4c52  pop rax
00007c454bbe4c53  add rsp, 0x08
00007c454bbe4c57  jmp 0x00007C454BBDFA45
00007c454bbe4c5c  call 0x00007C454BAE5940
00007c454bbe4c61  jmp 0x00007C454BBDFA53
00007c454bbe4c66  call 0x00007C454BA0C380
00007c454bbe4c6b  jmp 0x00007C454BBDFA5D
00007c454bbe4c70  call 0x00007C454BA0D600
00007c454bbe4c75  jmp 0x00007C454BBDFA67
00007c454bbe4c7a  call 0x00007C454B9FF540
00007c454bbe4c7f  jmp 0x00007C454BBDFA71
00007c454bbe4c84  int3
00007c454bbe4c85  nop [rax+rax*1], ax
00007c454bbe4c8e  nop
00007c454bbe4c90  mov qword ptr [r15+0x40], 0x430000
00007c454bbe4c98  mov eax, 0x430CC0
00007c454bbe4c9d  mov r14, [r13+rax*1]
00007c454bbe4ca2  movq xmm1, r14
00007c454bbe4ca7  mov rax, [r15+0x50]
00007c454bbe4cab  movups xmm15, [r13+rax*1]
00007c454bbe4cb1  movaps [r15+0x120], xmm15
00007c454bbe4cb9  mov qword ptr [r15+0x48], 0x10
00007c454bbe4cc1  xor eax, eax
00007c454bbe4cc3  mov r14d, 0x10
00007c454bbe4cc9  mov r12d, 0x200
00007c454bbe4ccf  cmp r14, r12
00007c454bbe4cd2  cmc
00007c454bbe4cd3  lahf
00007c454bbe4cd4  seto al
00007c454bbe4cd7  mov [r15+0x108], eax
00007c454bbe4cde  pextrq rax, xmm15, 0x01
00007c454bbe4ce5  movq xmm14, rax
00007c454bbe4cea  movaps [r15+0x130], xmm14
00007c454bbe4cf2  movq rax, xmm1
00007c454bbe4cf7  movq r14, xmm15
00007c454bbe4cfc  vmovq xmm1, rax
00007c454bbe4d01  vmovq xmm15, r14
00007c454bbe4d06  movaps xmm13, xmm1
00007c454bbe4d0a  addsd xmm13, xmm15
00007c454bbe4d0f  ucomisd xmm13, xmm13
00007c454bbe4d14  jp 0x00007C454BBE4DD3
00007c454bbe4d1a  movq xmm13, xmm13
00007c454bbe4d1f  movq rax, xmm13
00007c454bbe4d24  movq r14, xmm14
00007c454bbe4d29  vmovq xmm1, rax
00007c454bbe4d2e  vmovq xmm15, r14
00007c454bbe4d33  movaps xmm14, xmm1
00007c454bbe4d37  addsd xmm14, xmm15
00007c454bbe4d3c  ucomisd xmm14, xmm14
00007c454bbe4d41  jp 0x00007C454BBE4E1B
00007c454bbe4d47  movq xmm14, xmm14
00007c454bbe4d4c  movaps [r15+0x110], xmm14
00007c454bbe4d54  mov eax, [r15+0x108]
00007c454bbe4d5b  sahf
00007c454bbe4d5c  jnz 0x00007C454BBE4D8E
00007c454bbe4d5e  cmp dword ptr [r15+0x318], 0x00
00007c454bbe4d66  jz 0x00007C454BBE5030
00007c454bbe4d6c  nop [rax+rax*1], ax
00007c454bbe4d75  nop [rax+rax*1], eax
00007c454bbe4d7d  mov eax, 0x410704
00007c454bbe4d82  mov [r15+0x100], rax
00007c454bbe4d89  jmp 0x00007C454B9FE110
00007c454bbe4d8e  cmp dword ptr [r15+0x318], 0x00
00007c454bbe4d96  jz 0x00007C454BBE4E70
00007c454bbe4d9c  nop [rax+rax*1], ax
00007c454bbe4da5  nop [rax+rax*1], eax
00007c454bbe4dad  mov eax, 0x4106E8
00007c454bbe4db2  mov [r15+0x100], rax
00007c454bbe4db9  jmp 0x00007C454B9FE110
00007c454bbe4dbe  int3
00007c454bbe4dbf  call 0x00007C454BA0DC20
00007c454bbe4dc4  jmp 0x00007C454BBE4CA2
00007c454bbe4dc9  call 0x00007C454BA0E760
00007c454bbe4dce  jmp 0x00007C454BBE4CB1
00007c454bbe4dd3  ucomisd xmm1, xmm15
00007c454bbe4dd8  jp 0x00007C454BBE4DE7
00007c454bbe4dda  movaps xmm13, [0x00007C454B7FE060]
00007c454bbe4de2  jmp 0x00007C454BBE4D1A
00007c454bbe4de7  vxorps xmm0, xmm1, xmm15
00007c454bbe4dec  pextrw eax, xmm0, 0x03
00007c454bbe4df1  and eax, 0x7FF8
00007c454bbe4df6  cmp eax, 0x08
00007c454bbe4df9  jnz 0x00007C454BBE4D1A
00007c454bbe4dff  movq rax, xmm15
00007c454bbe4e04  shl rax, 0x0D
00007c454bbe4e08  jbe 0x00007C454BBE4D1A
00007c454bbe4e0e  vorps xmm13, xmm15, [0x00007C454B7FE070]
00007c454bbe4e16  jmp 0x00007C454BBE4D1A
00007c454bbe4e1b  ucomisd xmm1, xmm15
00007c454bbe4e20  jp 0x00007C454BBE4E2F
00007c454bbe4e22  movaps xmm14, [0x00007C454B7FE060]
00007c454bbe4e2a  jmp 0x00007C454BBE4D47
00007c454bbe4e2f  vxorps xmm0, xmm1, xmm15
00007c454bbe4e34  pextrw eax, xmm0, 0x03
00007c454bbe4e39  and eax, 0x7FF8
00007c454bbe4e3e  cmp eax, 0x08
00007c454bbe4e41  jnz 0x00007C454BBE4D47
00007c454bbe4e47  movq rax, xmm15
00007c454bbe4e4c  shl rax, 0x0D
00007c454bbe4e50  jbe 0x00007C454BBE4D47
00007c454bbe4e56  vorps xmm14, xmm15, [0x00007C454B7FE070]
00007c454bbe4e5e  jmp 0x00007C454BBE4D47
00007c454bbe4e63  int3
00007c454bbe4e64  nop [rax+rax*1], ax
00007c454bbe4e6d  nop [rax], eax
00007c454bbe4e70  mov rax, [r15+0x48]
00007c454bbe4e74  mov r14, [r15+0x50]
00007c454bbe4e78  lea r12, [r14+rax*1]
00007c454bbe4e7c  movups xmm1, [r13+r12*1]
00007c454bbe4e82  movaps [r15+0x120], xmm1
00007c454bbe4e8a  lea r14, [rax+0x10]
00007c454bbe4e8e  mov [r15+0x48], r14
00007c454bbe4e92  xor eax, eax
00007c454bbe4e94  mov r12d, 0x200
00007c454bbe4e9a  cmp r14, r12
00007c454bbe4e9d  cmc
00007c454bbe4e9e  lahf
00007c454bbe4e9f  seto al
00007c454bbe4ea2  mov [r15+0x108], eax
00007c454bbe4ea9  pextrq rax, xmm1, 0x01
00007c454bbe4eb0  movq xmm15, rax
00007c454bbe4eb5  movaps [r15+0x130], xmm15
00007c454bbe4ebd  movaps xmm14, [r15+0x110]
00007c454bbe4ec5  movq rax, xmm14
00007c454bbe4eca  movq r14, xmm1
00007c454bbe4ecf  vmovq xmm1, rax
00007c454bbe4ed4  vmovq xmm14, r14
00007c454bbe4ed9  movaps xmm13, xmm1
00007c454bbe4edd  addsd xmm13, xmm14
00007c454bbe4ee2  ucomisd xmm13, xmm13
00007c454bbe4ee7  jp 0x00007C454BBE4F9C
00007c454bbe4eed  movq xmm13, xmm13
00007c454bbe4ef2  movq rax, xmm13
00007c454bbe4ef7  movq r14, xmm15
00007c454bbe4efc  vmovq xmm1, rax
00007c454bbe4f01  vmovq xmm15, r14
00007c454bbe4f06  movaps xmm14, xmm1
00007c454bbe4f0a  addsd xmm14, xmm15
00007c454bbe4f0f  ucomisd xmm14, xmm14
00007c454bbe4f14  jp 0x00007C454BBE4FE4
00007c454bbe4f1a  movq xmm14, xmm14
00007c454bbe4f1f  movaps [r15+0x110], xmm14
00007c454bbe4f27  mov eax, [r15+0x108]
00007c454bbe4f2e  sahf
00007c454bbe4f2f  jnz 0x00007C454BBE4F61
00007c454bbe4f31  cmp dword ptr [r15+0x318], 0x00
00007c454bbe4f39  jz 0x00007C454BBE5030
00007c454bbe4f3f  nop [rax+rax*1], ax
00007c454bbe4f48  nop [rax+rax*1], eax
00007c454bbe4f50  mov eax, 0x410704
00007c454bbe4f55  mov [r15+0x100], rax
00007c454bbe4f5c  jmp 0x00007C454B9FE110
00007c454bbe4f61  cmp dword ptr [r15+0x318], 0x00
00007c454bbe4f69  jz 0x00007C454BBE4E70
00007c454bbe4f6f  nop [rax+rax*1], ax
00007c454bbe4f78  nop [rax+rax*1], eax
00007c454bbe4f80  mov eax, 0x4106E8
00007c454bbe4f85  mov [r15+0x100], rax
00007c454bbe4f8c  jmp 0x00007C454B9FE110
00007c454bbe4f91  int3
00007c454bbe4f92  call 0x00007C454BAB52F0
00007c454bbe4f97  jmp 0x00007C454BBE4E82
00007c454bbe4f9c  ucomisd xmm1, xmm14
00007c454bbe4fa1  jp 0x00007C454BBE4FB0
00007c454bbe4fa3  movaps xmm13, [0x00007C454B7FE060]
00007c454bbe4fab  jmp 0x00007C454BBE4EED
00007c454bbe4fb0  vxorps xmm0, xmm1, xmm14
00007c454bbe4fb5  pextrw eax, xmm0, 0x03
00007c454bbe4fba  and eax, 0x7FF8
00007c454bbe4fbf  cmp eax, 0x08
00007c454bbe4fc2  jnz 0x00007C454BBE4EED
00007c454bbe4fc8  movq rax, xmm14
00007c454bbe4fcd  shl rax, 0x0D
00007c454bbe4fd1  jbe 0x00007C454BBE4EED
00007c454bbe4fd7  vorps xmm13, xmm14, [0x00007C454B7FE070]
00007c454bbe4fdf  jmp 0x00007C454BBE4EED
00007c454bbe4fe4  ucomisd xmm1, xmm15
00007c454bbe4fe9  jp 0x00007C454BBE4FF8
00007c454bbe4feb  movaps xmm14, [0x00007C454B7FE060]
00007c454bbe4ff3  jmp 0x00007C454BBE4F1A
00007c454bbe4ff8  vxorps xmm0, xmm1, xmm15
00007c454bbe4ffd  pextrw eax, xmm0, 0x03
00007c454bbe5002  and eax, 0x7FF8
00007c454bbe5007  cmp eax, 0x08
00007c454bbe500a  jnz 0x00007C454BBE4F1A
00007c454bbe5010  movq rax, xmm15
00007c454bbe5015  shl rax, 0x0D
00007c454bbe5019  jbe 0x00007C454BBE4F1A
00007c454bbe501f  vorps xmm14, xmm15, [0x00007C454B7FE070]
00007c454bbe5027  jmp 0x00007C454BBE4F1A
00007c454bbe502c  int3
00007c454bbe502d  nop [rax], eax
00007c454bbe5030  mov rax, [r15+0xF8]
00007c454bbe5037  lea r14, [rax+0x1D0]
00007c454bbe503e  mov r12, [r13+r14*1]
00007c454bbe5043  lea r14, [rax+0x1D8]
00007c454bbe504a  mov r11, [r13+r14*1]
00007c454bbe504f  mov [r15+0xA0], r12
00007c454bbe5056  mov [r15+0x98], r11
00007c454bbe505d  mov r14, [r15+0x40]
00007c454bbe5061  lea r12, [r14+0xCC0]
00007c454bbe5068  movaps xmm1, [r15+0x110]
00007c454bbe5070  movq r14, xmm1
00007c454bbe5075  mov [r13+r12*1], r14
00007c454bbe507a  lea r14, [rax+0x1C0]
00007c454bbe5081  mov r12, [r13+r14*1]
00007c454bbe5086  lea r14, [rax+0x1C8]
00007c454bbe508d  mov r11, [r13+r14*1]
00007c454bbe5092  mov [r15+0xE8], r12
00007c454bbe5099  mov [r15+0xF0], r11
00007c454bbe50a0  lea r14, [rax+0x1B0]
00007c454bbe50a7  mov r12, [r13+r14*1]
00007c454bbe50ac  lea r14, [rax+0x1B8]
00007c454bbe50b3  mov r10, [r13+r14*1]
00007c454bbe50b8  movq xmm1, r12
00007c454bbe50bd  movq xmm15, r10
00007c454bbe50c2  movq xmm1, xmm1
00007c454bbe50c6  movq xmm1, xmm1
00007c454bbe50ca  movaps [r15+0x1A0], xmm1
00007c454bbe50d2  movq xmm15, xmm15
00007c454bbe50d7  movq xmm15, xmm15
00007c454bbe50dc  movaps [r15+0x190], xmm15
00007c454bbe50e4  lea r14, [rax+0x1A0]
00007c454bbe50eb  mov r12, [r13+r14*1]
00007c454bbe50f0  lea r14, [rax+0x1A8]
00007c454bbe50f7  mov r10, [r13+r14*1]
00007c454bbe50fc  movq xmm1, r12
00007c454bbe5101  movq xmm15, r10
00007c454bbe5106  movq xmm1, xmm1
00007c454bbe510a  movq xmm1, xmm1
00007c454bbe510e  movaps [r15+0x1C0], xmm1
00007c454bbe5116  movq xmm15, xmm15
00007c454bbe511b  movq xmm15, xmm15
00007c454bbe5120  movaps [r15+0x1B0], xmm15
00007c454bbe5128  lea r14, [rax+0x190]
00007c454bbe512f  mov r12, [r13+r14*1]
00007c454bbe5134  lea r14, [rax+0x198]
00007c454bbe513b  mov r10, [r13+r14*1]
00007c454bbe5140  movq xmm1, r12
00007c454bbe5145  movq xmm15, r10
00007c454bbe514a  movq xmm1, xmm1
00007c454bbe514e  movq xmm1, xmm1
00007c454bbe5152  movaps [r15+0x1E0], xmm1
00007c454bbe515a  movq xmm15, xmm15
00007c454bbe515f  movq xmm15, xmm15
00007c454bbe5164  movaps [r15+0x1D0], xmm15
00007c454bbe516c  lea r14, [rax+0x180]
00007c454bbe5173  mov r12, [r13+r14*1]
00007c454bbe5178  lea r14, [rax+0x188]
00007c454bbe517f  mov r10, [r13+r14*1]
00007c454bbe5184  movq xmm1, r12
00007c454bbe5189  movq xmm15, r10
00007c454bbe518e  movq xmm1, xmm1
00007c454bbe5192  movq xmm1, xmm1
00007c454bbe5196  movaps [r15+0x200], xmm1
00007c454bbe519e  movq xmm15, xmm15
00007c454bbe51a3  movq xmm15, xmm15
00007c454bbe51a8  movaps [r15+0x1F0], xmm15
00007c454bbe51b0  lea r14, [rax+0x1E0]
00007c454bbe51b7  mov [r15+0xF8], r14
00007c454bbe51be  mov [r15+0x100], r11
00007c454bbe51c5  jmp 0x00007C454BBCE5C0
00007c454bbe51ca  int3
00007c454bbe51cb  call 0x00007C454BAE27E0
00007c454bbe51d0  jmp 0x00007C454BBE5043
00007c454bbe51d5  call 0x00007C454BAE1570
00007c454bbe51da  jmp 0x00007C454BBE504F
00007c454bbe51df  call 0x00007C454BAC3FE0
00007c454bbe51e4  jmp 0x00007C454BBE507A
00007c454bbe51e9  call 0x00007C454BAE27E0
00007c454bbe51ee  jmp 0x00007C454BBE5086
00007c454bbe51f3  call 0x00007C454BAE1570
00007c454bbe51f8  jmp 0x00007C454BBE5092
00007c454bbe51fd  call 0x00007C454BAE27E0
00007c454bbe5202  jmp 0x00007C454BBE50AC
00007c454bbe5207  call 0x00007C454BAE0300
00007c454bbe520c  jmp 0x00007C454BBE50B8
00007c454bbe5211  call 0x00007C454BAE27E0
00007c454bbe5216  jmp 0x00007C454BBE50F0
00007c454bbe521b  call 0x00007C454BAE0300
00007c454bbe5220  jmp 0x00007C454BBE50FC
00007c454bbe5225  call 0x00007C454BAE27E0
00007c454bbe522a  jmp 0x00007C454BBE5134
00007c454bbe522f  call 0x00007C454BAE0300
00007c454bbe5234  jmp 0x00007C454BBE5140
00007c454bbe5239  call 0x00007C454BAE27E0
00007c454bbe523e  jmp 0x00007C454BBE5178
00007c454bbe5243  call 0x00007C454BAE0300
00007c454bbe5248  jmp 0x00007C454BBE5184
00007c454bbe524d  int3
00007c454bbe524e  nop
00007c454bbe5250  mov qword ptr [r15+0x100], 0x04
00007c454bbe525b  mov esi, 0x00
00007c454bbe5260  mov edx, 0x09
00007c454bbe5265  mov rdi, 0x7FFD7E4939C0
00007c454bbe526f  mov rax, 0x56A18AAE7970
00007c454bbe5279  call rax
00007c454bbe527b  cmp dword ptr [r15+0x318], 0x00
00007c454bbe5283  jnz 0x00007C454B9FE110
00007c454bbe5289  jmp 0x00007C454B9FE0A0
00007c454bbe528e  int3
00007c454bbe528f  int3
