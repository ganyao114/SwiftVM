000073dfa87ce69b  nop [rax+rax*1], eax
000073dfa87ce6a0  mov rax, [r15+0xF8]
000073dfa87ce6a7  lea r14, [rax-0x1E0]
000073dfa87ce6ae  mov [r15+0xF8], r14
000073dfa87ce6b5  lea rax, [r14+0x1D0]
000073dfa87ce6bc  mov r12, [r15+0xA0]
000073dfa87ce6c3  mov r11, [r15+0x98]
000073dfa87ce6ca  mov [r13+rax*1], r12
000073dfa87ce6cf  lea rax, [r14+0x1D8]
000073dfa87ce6d6  mov [r13+rax*1], r11
000073dfa87ce6db  mov eax, 0x420AA0
000073dfa87ce6e0  movups xmm1, [r13+rax*1]
000073dfa87ce6e6  mov eax, 0x420A30
000073dfa87ce6eb  movups xmm15, [r13+rax*1]
000073dfa87ce6f1  mov eax, 0x420AC0
000073dfa87ce6f6  movups xmm14, [r13+rax*1]
000073dfa87ce6fc  mov eax, 0x420A60
000073dfa87ce701  movups xmm13, [r13+rax*1]
000073dfa87ce707  mov qword ptr [r15+0x98], 0x430CD0
000073dfa87ce712  mov eax, 0x420AD0
000073dfa87ce717  movups xmm12, [r13+rax*1]
000073dfa87ce71d  mov eax, 0x430CD0
000073dfa87ce722  movups [r13+rax*1], xmm1
000073dfa87ce728  mov eax, 0x430CE0
000073dfa87ce72d  movups [r13+rax*1], xmm15
000073dfa87ce733  mov eax, 0x430CF0
000073dfa87ce738  movups [r13+rax*1], xmm14
000073dfa87ce73e  mov eax, 0x430D00
000073dfa87ce743  movups [r13+rax*1], xmm13
000073dfa87ce749  mov eax, 0x420A20
000073dfa87ce74e  movups xmm14, [r13+rax*1]
000073dfa87ce754  mov eax, 0x420A10
000073dfa87ce759  movups xmm13, [r13+rax*1]
000073dfa87ce75f  mov eax, 0x430DD0
000073dfa87ce764  movups [r13+rax*1], xmm1
000073dfa87ce76a  mov eax, 0x430DE0
000073dfa87ce76f  movups [r13+rax*1], xmm15
000073dfa87ce775  mov eax, 0x430D10
000073dfa87ce77a  movups [r13+rax*1], xmm12
000073dfa87ce780  mov eax, 0x430D20
000073dfa87ce785  movups [r13+rax*1], xmm14
000073dfa87ce78b  mov eax, 0x420A00
000073dfa87ce790  movups xmm1, [r13+rax*1]
000073dfa87ce796  mov eax, 0x420A70
000073dfa87ce79b  movups xmm15, [r13+rax*1]
000073dfa87ce7a1  mov eax, 0x430D30
000073dfa87ce7a6  movups [r13+rax*1], xmm13
000073dfa87ce7ac  mov eax, 0x430D40
000073dfa87ce7b1  movups [r13+rax*1], xmm1
000073dfa87ce7b7  mov eax, 0x420A80
000073dfa87ce7bc  movups xmm1, [r13+rax*1]
000073dfa87ce7c2  mov eax, 0x420A50
000073dfa87ce7c7  movups xmm14, [r13+rax*1]
000073dfa87ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000073dfa87ce7d5  mov eax, 0x430D50
000073dfa87ce7da  movups [r13+rax*1], xmm15
000073dfa87ce7e0  mov eax, 0x430D60
000073dfa87ce7e5  movups [r13+rax*1], xmm1
000073dfa87ce7eb  mov eax, 0x420AF0
000073dfa87ce7f0  movups xmm1, [r13+rax*1]
000073dfa87ce7f6  mov eax, 0x420B00
000073dfa87ce7fb  movups xmm15, [r13+rax*1]
000073dfa87ce801  movaps [r15+0x150], xmm15
000073dfa87ce809  mov qword ptr [r15+0xA0], 0x3E8
000073dfa87ce814  mov eax, 0x430D70
000073dfa87ce819  movups [r13+rax*1], xmm14
000073dfa87ce81f  mov eax, 0x430D80
000073dfa87ce824  movups [r13+rax*1], xmm1
000073dfa87ce82a  mov eax, 0x420AE0
000073dfa87ce82f  movups xmm1, [r13+rax*1]
000073dfa87ce835  mov eax, 0x420A90
000073dfa87ce83a  movups xmm14, [r13+rax*1]
000073dfa87ce840  movaps [r15+0x140], xmm14
000073dfa87ce848  lea rax, [r14+0x180]
000073dfa87ce84f  movq xmm13, qword ptr [r15+0x200]
000073dfa87ce858  movq xmm12, qword ptr [r15+0x1F0]
000073dfa87ce861  movq r12, xmm13
000073dfa87ce866  movq r11, xmm12
000073dfa87ce86b  mov [r13+rax*1], r12
000073dfa87ce870  lea rax, [r14+0x188]
000073dfa87ce877  mov [r13+rax*1], r11
000073dfa87ce87c  mov eax, 0x430D90
000073dfa87ce881  movups [r13+rax*1], xmm15
000073dfa87ce887  mov eax, 0x430DA0
000073dfa87ce88c  movups [r13+rax*1], xmm1
000073dfa87ce892  mov eax, 0x420AB0
000073dfa87ce897  movups xmm1, [r13+rax*1]
000073dfa87ce89d  mov eax, 0x420B18
000073dfa87ce8a2  mov r12, [r13+rax*1]
000073dfa87ce8a7  movq xmm15, r12
000073dfa87ce8ac  mov qword ptr [r15+0x40], 0x420B20
000073dfa87ce8b4  mov eax, 0x430DB0
000073dfa87ce8b9  movups [r13+rax*1], xmm14
000073dfa87ce8bf  mov eax, 0x430DC0
000073dfa87ce8c4  movups [r13+rax*1], xmm1
000073dfa87ce8ca  mov eax, 0x420B80
000073dfa87ce8cf  movups xmm1, [r13+rax*1]
000073dfa87ce8d5  movq rax, xmm15
000073dfa87ce8da  mov r12d, 0x430DF0
000073dfa87ce8e0  mov [r13+r12*1], rax
000073dfa87ce8e5  mov eax, 0x420B60
000073dfa87ce8ea  movups xmm15, [r13+rax*1]
000073dfa87ce8f0  mov eax, 0x420B70
000073dfa87ce8f5  movups xmm14, [r13+rax*1]
000073dfa87ce8fb  lea rax, [r14+0x160]
000073dfa87ce902  movups [r13+rax*1], xmm1
000073dfa87ce908  lea rax, [r14+0x190]
000073dfa87ce90f  movq xmm1, qword ptr [r15+0x1E0]
000073dfa87ce918  movq xmm13, qword ptr [r15+0x1D0]
000073dfa87ce921  movq r12, xmm1
000073dfa87ce926  movq r11, xmm13
000073dfa87ce92b  mov [r13+rax*1], r12
000073dfa87ce930  lea rax, [r14+0x198]
000073dfa87ce937  mov [r13+rax*1], r11
000073dfa87ce93c  lea rax, [r14+0x140]
000073dfa87ce943  movups [r13+rax*1], xmm15
000073dfa87ce949  lea rax, [r14+0x150]
000073dfa87ce950  movups [r13+rax*1], xmm14
000073dfa87ce956  mov eax, 0x420B20
000073dfa87ce95b  movups xmm1, [r13+rax*1]
000073dfa87ce961  mov eax, 0x420B30
000073dfa87ce966  movups xmm15, [r13+rax*1]
000073dfa87ce96c  movaps [r15+0x120], xmm15
000073dfa87ce974  lea rax, [r14+0x1A0]
000073dfa87ce97b  movq xmm14, qword ptr [r15+0x1C0]
000073dfa87ce984  movq xmm13, qword ptr [r15+0x1B0]
000073dfa87ce98d  movq r12, xmm14
000073dfa87ce992  movq r11, xmm13
000073dfa87ce997  mov [r13+rax*1], r12
000073dfa87ce99c  lea rax, [r14+0x1A8]
000073dfa87ce9a3  mov [r13+rax*1], r11
000073dfa87ce9a8  lea rax, [r14+0x1B0]
000073dfa87ce9af  movq xmm14, qword ptr [r15+0x1A0]
000073dfa87ce9b8  movq xmm13, qword ptr [r15+0x190]
000073dfa87ce9c1  movq r12, xmm14
000073dfa87ce9c6  movq r11, xmm13
000073dfa87ce9cb  mov [r13+rax*1], r12
000073dfa87ce9d0  lea rax, [r14+0x1B8]
000073dfa87ce9d7  mov [r13+rax*1], r11
000073dfa87ce9dc  lea rax, [r14+0x100]
000073dfa87ce9e3  movups [r13+rax*1], xmm1
000073dfa87ce9e9  lea rax, [r14+0x110]
000073dfa87ce9f0  movups [r13+rax*1], xmm15
000073dfa87ce9f6  mov eax, 0x420B40
000073dfa87ce9fb  movups xmm1, [r13+rax*1]
000073dfa87cea01  mov eax, 0x420B50
000073dfa87cea06  movups xmm15, [r13+rax*1]
000073dfa87cea0c  movaps [r15+0x110], xmm1
000073dfa87cea14  movaps [r15+0x130], xmm15
000073dfa87cea1c  lea rax, [r14+0x1C0]
000073dfa87cea23  mov r12, [r15+0xE8]
000073dfa87cea2a  mov r11, [r15+0xF0]
000073dfa87cea31  mov [r13+rax*1], r12
000073dfa87cea36  lea rax, [r14+0x1C8]
000073dfa87cea3d  mov [r13+rax*1], r11
000073dfa87cea42  mov eax, 0x430DF8
000073dfa87cea47  mov r12d, 0x421DF8D3
000073dfa87cea4d  mov [r13+rax*1], r12d
000073dfa87cea52  lea rax, [r14+0x120]
000073dfa87cea59  movups [r13+rax*1], xmm1
000073dfa87cea5f  lea rax, [r14+0x130]
000073dfa87cea66  movups [r13+rax*1], xmm15
000073dfa87cea6c  lea rax, [r14+0x100]
000073dfa87cea73  mov [r15], rax
000073dfa87cea76  mov qword ptr [r15+0x08], 0x430CD0
000073dfa87cea7e  mov qword ptr [r15+0x10], 0x12C
000073dfa87cea86  mov qword ptr [r15+0xF0], 0x410284
000073dfa87cea91  mov r14d, [r15+0x320]
000073dfa87cea98  mov eax, 0x410284
000073dfa87cea9d  mov rcx, 0x73DFA87D07C0
000073dfa87ceaa7  mov [r15+r14*8+0x328], rax
000073dfa87ceaaf  mov [r15+r14*8+0x368], rcx
000073dfa87ceab7  add r14d, 0x01
000073dfa87ceabb  and r14d, 0x07
000073dfa87ceabf  mov [r15+0x320], r14d
000073dfa87ceac6  cmp dword ptr [r15+0x318], 0x00
000073dfa87ceace  jz 0x000073DFA87CED70
000073dfa87cead4  nop [rax+rax*1], ax
000073dfa87ceadd  nop [rax+rax*1], eax
000073dfa87ceae5  mov eax, 0x410728
000073dfa87ceaea  mov [r15+0x100], rax
000073dfa87ceaf1  jmp 0x000073DFA85FE110
000073dfa87ceaf6  int3
000073dfa87ceaf7  call 0x000073DFA860BC20
000073dfa87ceafc  jmp 0x000073DFA87CE6CF
000073dfa87ceb01  call 0x000073DFA860A9A0
000073dfa87ceb06  jmp 0x000073DFA87CE6DB
000073dfa87ceb0b  call 0x000073DFA85FF430
000073dfa87ceb10  jmp 0x000073DFA87CE6E6
000073dfa87ceb15  call 0x000073DFA860E760
000073dfa87ceb1a  jmp 0x000073DFA87CE6F1
000073dfa87ceb1f  call 0x000073DFA860D4E0
000073dfa87ceb24  jmp 0x000073DFA87CE6FC
000073dfa87ceb29  call 0x000073DFA860C260
000073dfa87ceb2e  jmp 0x000073DFA87CE707
000073dfa87ceb33  call 0x000073DFA860AFE0
000073dfa87ceb38  jmp 0x000073DFA87CE71D
000073dfa87ceb3d  call 0x000073DFA85FF540
000073dfa87ceb42  jmp 0x000073DFA87CE728
000073dfa87ceb47  call 0x000073DFA860E880
000073dfa87ceb4c  jmp 0x000073DFA87CE733
000073dfa87ceb51  call 0x000073DFA860D600
000073dfa87ceb56  jmp 0x000073DFA87CE73E
000073dfa87ceb5b  call 0x000073DFA860C380
000073dfa87ceb60  jmp 0x000073DFA87CE749
000073dfa87ceb65  call 0x000073DFA860D4E0
000073dfa87ceb6a  jmp 0x000073DFA87CE754
000073dfa87ceb6f  call 0x000073DFA860C260
000073dfa87ceb74  jmp 0x000073DFA87CE75F
000073dfa87ceb79  call 0x000073DFA85FF540
000073dfa87ceb7e  jmp 0x000073DFA87CE76A
000073dfa87ceb83  call 0x000073DFA860E880
000073dfa87ceb88  jmp 0x000073DFA87CE775
000073dfa87ceb8d  call 0x000073DFA860B100
000073dfa87ceb92  jmp 0x000073DFA87CE780
000073dfa87ceb97  call 0x000073DFA860D600
000073dfa87ceb9c  jmp 0x000073DFA87CE78B
000073dfa87ceba1  call 0x000073DFA85FF430
000073dfa87ceba6  jmp 0x000073DFA87CE796
000073dfa87cebab  call 0x000073DFA860E760
000073dfa87cebb0  jmp 0x000073DFA87CE7A1
000073dfa87cebb5  call 0x000073DFA860C380
000073dfa87cebba  jmp 0x000073DFA87CE7AC
000073dfa87cebbf  call 0x000073DFA85FF540
000073dfa87cebc4  jmp 0x000073DFA87CE7B7
000073dfa87cebc9  call 0x000073DFA85FF430
000073dfa87cebce  jmp 0x000073DFA87CE7C2
000073dfa87cebd3  call 0x000073DFA860D4E0
000073dfa87cebd8  jmp 0x000073DFA87CE7CD
000073dfa87cebdd  call 0x000073DFA860E880
000073dfa87cebe2  jmp 0x000073DFA87CE7E0
000073dfa87cebe7  call 0x000073DFA85FF540
000073dfa87cebec  jmp 0x000073DFA87CE7EB
000073dfa87cebf1  call 0x000073DFA85FF430
000073dfa87cebf6  jmp 0x000073DFA87CE7F6
000073dfa87cebfb  call 0x000073DFA860E760
000073dfa87cec00  jmp 0x000073DFA87CE801
000073dfa87cec05  call 0x000073DFA860D600
000073dfa87cec0a  jmp 0x000073DFA87CE81F
000073dfa87cec0f  call 0x000073DFA85FF540
000073dfa87cec14  jmp 0x000073DFA87CE82A
000073dfa87cec19  call 0x000073DFA85FF430
000073dfa87cec1e  jmp 0x000073DFA87CE835
000073dfa87cec23  call 0x000073DFA860D4E0
000073dfa87cec28  jmp 0x000073DFA87CE840
000073dfa87cec2d  call 0x000073DFA860BC20
000073dfa87cec32  jmp 0x000073DFA87CE870
000073dfa87cec37  call 0x000073DFA860A9A0
000073dfa87cec3c  jmp 0x000073DFA87CE87C
000073dfa87cec41  call 0x000073DFA860E880
000073dfa87cec46  jmp 0x000073DFA87CE887
000073dfa87cec4b  call 0x000073DFA85FF540
000073dfa87cec50  jmp 0x000073DFA87CE892
000073dfa87cec55  call 0x000073DFA85FF430
000073dfa87cec5a  jmp 0x000073DFA87CE89D
000073dfa87cec5f  call 0x000073DFA860B720
000073dfa87cec64  jmp 0x000073DFA87CE8A7
000073dfa87cec69  call 0x000073DFA860D600
000073dfa87cec6e  jmp 0x000073DFA87CE8BF
000073dfa87cec73  call 0x000073DFA85FF540
000073dfa87cec78  jmp 0x000073DFA87CE8CA
000073dfa87cec7d  call 0x000073DFA85FF430
000073dfa87cec82  jmp 0x000073DFA87CE8D5
000073dfa87cec87  call 0x000073DFA86B4CB0
000073dfa87cec8c  jmp 0x000073DFA87CE8E5
000073dfa87cec91  call 0x000073DFA860E760
000073dfa87cec96  jmp 0x000073DFA87CE8F0
000073dfa87cec9b  call 0x000073DFA860D4E0
000073dfa87ceca0  jmp 0x000073DFA87CE8FB
000073dfa87ceca5  call 0x000073DFA85FF540
000073dfa87cecaa  jmp 0x000073DFA87CE908
000073dfa87cecaf  call 0x000073DFA860BC20
000073dfa87cecb4  jmp 0x000073DFA87CE930
000073dfa87cecb9  call 0x000073DFA860A9A0
000073dfa87cecbe  jmp 0x000073DFA87CE93C
000073dfa87cecc3  call 0x000073DFA860E880
000073dfa87cecc8  jmp 0x000073DFA87CE949
000073dfa87ceccd  call 0x000073DFA860D600
000073dfa87cecd2  jmp 0x000073DFA87CE956
000073dfa87cecd7  call 0x000073DFA85FF430
000073dfa87cecdc  jmp 0x000073DFA87CE961
000073dfa87cece1  call 0x000073DFA860E760
000073dfa87cece6  jmp 0x000073DFA87CE96C
000073dfa87ceceb  call 0x000073DFA860BC20
000073dfa87cecf0  jmp 0x000073DFA87CE99C
000073dfa87cecf5  call 0x000073DFA860A9A0
000073dfa87cecfa  jmp 0x000073DFA87CE9A8
000073dfa87cecff  call 0x000073DFA860BC20
000073dfa87ced04  jmp 0x000073DFA87CE9D0
000073dfa87ced09  call 0x000073DFA860A9A0
000073dfa87ced0e  jmp 0x000073DFA87CE9DC
000073dfa87ced13  call 0x000073DFA85FF540
000073dfa87ced18  jmp 0x000073DFA87CE9E9
000073dfa87ced1d  call 0x000073DFA860E880
000073dfa87ced22  jmp 0x000073DFA87CE9F6
000073dfa87ced27  call 0x000073DFA85FF430
000073dfa87ced2c  jmp 0x000073DFA87CEA01
000073dfa87ced31  call 0x000073DFA860E760
000073dfa87ced36  jmp 0x000073DFA87CEA0C
000073dfa87ced3b  call 0x000073DFA860BC20
000073dfa87ced40  jmp 0x000073DFA87CEA36
000073dfa87ced45  call 0x000073DFA860A9A0
000073dfa87ced4a  jmp 0x000073DFA87CEA42
000073dfa87ced4f  call 0x000073DFA860BAE0
000073dfa87ced54  jmp 0x000073DFA87CEA52
000073dfa87ced59  call 0x000073DFA85FF540
000073dfa87ced5e  jmp 0x000073DFA87CEA5F
000073dfa87ced63  call 0x000073DFA860E880
000073dfa87ced68  jmp 0x000073DFA87CEA6C
000073dfa87ced6d  int3
000073dfa87ced6e  nop
000073dfa87ced70  mov rax, [r15]
000073dfa87ced73  lea r14, [rax+0x20]
000073dfa87ced77  mov r12, [r13+r14*1]
000073dfa87ced7c  mov r14, [r15+0x10]
000073dfa87ced80  lea r11, [r12+r14*1]
000073dfa87ced84  mov [r15+0x40], r11
000073dfa87ced88  lea r12, [rax+0x20]
000073dfa87ced8c  mov [r13+r12*1], r11
000073dfa87ced91  test r14, r14
000073dfa87ced94  setz r14b
000073dfa87ced98  movzx r14, r14b
000073dfa87ced9c  mov [rsp+0x414], r14b
000073dfa87ceda4  cmp byte ptr [rsp+0x414], 0x00
000073dfa87cedac  jz 0x000073DFA87CEDDE
000073dfa87cedae  cmp dword ptr [r15+0x318], 0x00
000073dfa87cedb6  mov eax, 0x4109A0
000073dfa87cedbb  mov [r15+0x100], rax
000073dfa87cedc2  jz 0x000073DFA85FE0A0
000073dfa87cedc8  nop [rax+rax*1], eax
000073dfa87cedcd  mov eax, 0x4109A0
000073dfa87cedd2  mov [r15+0x100], rax
000073dfa87cedd9  jmp 0x000073DFA85FE110
000073dfa87cedde  cmp dword ptr [r15+0x318], 0x00
000073dfa87cede6  jz 0x000073DFA87CEE30
000073dfa87cedec  nop [rax+rax*1], ax
000073dfa87cedf5  nop [rax+rax*1], eax
000073dfa87cedfd  mov eax, 0x410738
000073dfa87cee02  mov [r15+0x100], rax
000073dfa87cee09  jmp 0x000073DFA85FE110
000073dfa87cee0e  int3
000073dfa87cee0f  call 0x000073DFA86E27E0
000073dfa87cee14  jmp 0x000073DFA87CED7C
000073dfa87cee19  call 0x000073DFA86C0860
000073dfa87cee1e  jmp 0x000073DFA87CED91
000073dfa87cee23  int3
000073dfa87cee24  nop [rax+rax*1], ax
000073dfa87cee2d  nop [rax], eax
000073dfa87cee30  mov rax, [r15+0xF8]
000073dfa87cee37  lea r14, [rax-0x150]
000073dfa87cee3e  mov [r15+0xF8], r14
000073dfa87cee45  mov rax, [r15]
000073dfa87cee48  lea r12, [rax+0x68]
000073dfa87cee4c  mov r11, [r13+r12*1]
000073dfa87cee51  mov [r15+0x88], r11
000073dfa87cee58  lea r12, [rax+0x28]
000073dfa87cee5c  mov [r15+0x40], r12
000073dfa87cee60  mov [r15+0x48], r14
000073dfa87cee64  mov qword ptr [r15+0x50], 0x420B90
000073dfa87cee6c  lea rax, [r14+0x100]
000073dfa87cee73  mov r12, [r15+0xE8]
000073dfa87cee7a  mov r11, [r15+0xD8]
000073dfa87cee81  mov [r13+rax*1], r12
000073dfa87cee86  lea rax, [r14+0x108]
000073dfa87cee8d  mov [r13+rax*1], r11
000073dfa87cee92  lea rax, [r14+0x110]
000073dfa87cee99  mov r12, [r15+0xD0]
000073dfa87ceea0  mov r11, [r15+0xC8]
000073dfa87ceea7  mov [r13+rax*1], r12
000073dfa87ceeac  lea rax, [r14+0x118]
000073dfa87ceeb3  mov [r13+rax*1], r11
000073dfa87ceeb8  lea rax, [r14+0x120]
000073dfa87ceebf  mov r12, [r15+0xC0]
000073dfa87ceec6  mov r11, [r15+0xB8]
000073dfa87ceecd  mov [r13+rax*1], r12
000073dfa87ceed2  lea rax, [r14+0x128]
000073dfa87ceed9  mov [r13+rax*1], r11
000073dfa87ceede  lea rax, [r14+0x130]
000073dfa87ceee5  mov r12, [r15+0xB0]
000073dfa87ceeec  mov r11, [r15+0xA8]
000073dfa87ceef3  mov [r13+rax*1], r12
000073dfa87ceef8  lea rax, [r14+0x138]
000073dfa87ceeff  mov [r13+rax*1], r11
000073dfa87cef04  lea rax, [r14+0x140]
000073dfa87cef0b  mov r12, [r15+0xA0]
000073dfa87cef12  mov r11, [r15+0x98]
000073dfa87cef19  mov [r13+rax*1], r12
000073dfa87cef1e  lea rax, [r14+0x148]
000073dfa87cef25  mov [r13+rax*1], r11
000073dfa87cef2a  cmp dword ptr [r15+0x318], 0x00
000073dfa87cef32  jz 0x000073DFA87CEFD0
000073dfa87cef38  nop [rax+rax*1], ax
000073dfa87cef41  nop [rax+rax*1], eax
000073dfa87cef49  mov eax, 0x410770
000073dfa87cef4e  mov [r15+0x100], rax
000073dfa87cef55  jmp 0x000073DFA85FE110
000073dfa87cef5a  int3
000073dfa87cef5b  call 0x000073DFA86C0370
000073dfa87cef60  jmp 0x000073DFA87CEE51
000073dfa87cef65  call 0x000073DFA860BC20
000073dfa87cef6a  jmp 0x000073DFA87CEE86
000073dfa87cef6f  call 0x000073DFA860A9A0
000073dfa87cef74  jmp 0x000073DFA87CEE92
000073dfa87cef79  call 0x000073DFA860BC20
000073dfa87cef7e  jmp 0x000073DFA87CEEAC
000073dfa87cef83  call 0x000073DFA860A9A0
000073dfa87cef88  jmp 0x000073DFA87CEEB8
000073dfa87cef8d  call 0x000073DFA860BC20
000073dfa87cef92  jmp 0x000073DFA87CEED2
000073dfa87cef97  call 0x000073DFA860A9A0
000073dfa87cef9c  jmp 0x000073DFA87CEEDE
000073dfa87cefa1  call 0x000073DFA860BC20
000073dfa87cefa6  jmp 0x000073DFA87CEEF8
000073dfa87cefab  call 0x000073DFA860A9A0
000073dfa87cefb0  jmp 0x000073DFA87CEF04
000073dfa87cefb5  call 0x000073DFA860BC20
000073dfa87cefba  jmp 0x000073DFA87CEF1E
000073dfa87cefbf  call 0x000073DFA860A9A0
000073dfa87cefc4  jmp 0x000073DFA87CEF2A
000073dfa87cefc9  int3
000073dfa87cefca  nop [rax+rax*1], ax
000073dfa87cefd0  mov rax, [r15+0x08]
000073dfa87cefd4  movzx r14d, byte ptr [r13+rax*1]
000073dfa87cefda  movzx r14d, r14b
000073dfa87cefde  mov [rsp+0x10], r14d
000073dfa87cefe3  mov r14d, r14d
000073dfa87cefe6  mov [r15+0x58], r14
000073dfa87cefea  lea r14, [rax+0x01]
000073dfa87cefee  mov [r15+0x08], r14
000073dfa87ceff2  mov rax, [r15+0x88]
000073dfa87ceff9  lea r14, [rax+0x01]
000073dfa87ceffd  mov r12, [r15]
000073dfa87cf000  lea r11, [r12+0x68]
000073dfa87cf005  mov [r13+r11*1], r14
000073dfa87cf00a  lea r14, [r12+rax*1]
000073dfa87cf00e  mov [r15+0x60], r14
000073dfa87cf012  lea rax, [r14+0x28]
000073dfa87cf016  mov r11d, [rsp+0x10]
000073dfa87cf01b  movzx r14d, r11b
000073dfa87cf01f  mov [r13+rax*1], r14b
000073dfa87cf024  lea rax, [r12+0x68]
000073dfa87cf029  mov r14, [r13+rax*1]
000073dfa87cf02e  mov [r15+0x88], r14
000073dfa87cf035  xor eax, eax
000073dfa87cf037  mov r12d, 0x40
000073dfa87cf03d  cmp r14, r12
000073dfa87cf040  cmc
000073dfa87cf041  lahf
000073dfa87cf042  seto al
000073dfa87cf045  mov [r15+0x108], eax
000073dfa87cf04c  mov eax, [r15+0x108]
000073dfa87cf053  sahf
000073dfa87cf054  jnz 0x000073DFA87CF086
000073dfa87cf056  cmp dword ptr [r15+0x318], 0x00
000073dfa87cf05e  jz 0x000073DFA87CF170
000073dfa87cf064  nop [rax+rax*1], ax
000073dfa87cf06d  nop [rax+rax*1], eax
000073dfa87cf075  mov eax, 0x410790
000073dfa87cf07a  mov [r15+0x100], rax
000073dfa87cf081  jmp 0x000073DFA85FE110
000073dfa87cf086  cmp dword ptr [r15+0x318], 0x00
000073dfa87cf08e  jz 0x000073DFA87CF0E0
000073dfa87cf094  nop [rax+rax*1], ax
000073dfa87cf09d  nop [rax+rax*1], eax
000073dfa87cf0a5  mov eax, 0x410768
000073dfa87cf0aa  mov [r15+0x100], rax
000073dfa87cf0b1  jmp 0x000073DFA85FE110
000073dfa87cf0b6  int3
000073dfa87cf0b7  call 0x000073DFA860D860
000073dfa87cf0bc  jmp 0x000073DFA87CEFDA
000073dfa87cf0c1  call 0x000073DFA86B36E0
000073dfa87cf0c6  jmp 0x000073DFA87CF00A
000073dfa87cf0cb  call 0x000073DFA860DD60
000073dfa87cf0d0  jmp 0x000073DFA87CF024
000073dfa87cf0d5  call 0x000073DFA860DC20
000073dfa87cf0da  jmp 0x000073DFA87CF02E
000073dfa87cf0df  int3
000073dfa87cf0e0  mov rax, [r15+0x10]
000073dfa87cf0e4  lea r14, [rax-0x01]
000073dfa87cf0e8  mov [r15+0x10], r14
000073dfa87cf0ec  test r14, r14
000073dfa87cf0ef  setz r14b
000073dfa87cf0f3  movzx r14, r14b
000073dfa87cf0f7  mov [rsp+0x414], r14b
000073dfa87cf0ff  cmp byte ptr [rsp+0x414], 0x00
000073dfa87cf107  jz 0x000073DFA87CF139
000073dfa87cf109  cmp dword ptr [r15+0x318], 0x00
000073dfa87cf111  jz 0x000073DFA87D0670
000073dfa87cf117  nop [rax+rax*1], ax
000073dfa87cf120  nop [rax+rax*1], eax
000073dfa87cf128  mov eax, 0x410988
000073dfa87cf12d  mov [r15+0x100], rax
000073dfa87cf134  jmp 0x000073DFA85FE110
000073dfa87cf139  cmp dword ptr [r15+0x318], 0x00
000073dfa87cf141  jz 0x000073DFA87CEFD0
000073dfa87cf147  nop [rax+rax*1], ax
000073dfa87cf150  nop [rax+rax*1], eax
000073dfa87cf158  mov eax, 0x410770
000073dfa87cf15d  mov [r15+0x100], rax
000073dfa87cf164  jmp 0x000073DFA85FE110
000073dfa87cf169  int3
000073dfa87cf16a  int3
000073dfa87cf16b  nop [rax+rax*1], eax
000073dfa87cf170  mov rax, [r15+0x40]
000073dfa87cf174  movzx r14d, byte ptr [r13+rax*1]
000073dfa87cf17a  movaps xmm1, [r15+0x110]
000073dfa87cf182  pinsrb xmm1, r14d, 0x00
000073dfa87cf189  lea r14, [rax+0x01]
000073dfa87cf18d  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf193  movaps xmm15, [r15+0x120]
000073dfa87cf19b  pinsrb xmm15, r12d, 0x00
000073dfa87cf1a2  lea r14, [rax+0x02]
000073dfa87cf1a6  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf1ac  movaps xmm14, [r15+0x130]
000073dfa87cf1b4  pinsrb xmm14, r12d, 0x00
000073dfa87cf1bb  lea r14, [rax+0x03]
000073dfa87cf1bf  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf1c5  movaps xmm13, [r15+0x140]
000073dfa87cf1cd  pinsrb xmm13, r12d, 0x00
000073dfa87cf1d4  lea r14, [rax+0x04]
000073dfa87cf1d8  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf1de  pinsrb xmm1, r12d, 0x01
000073dfa87cf1e5  lea r14, [rax+0x05]
000073dfa87cf1e9  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf1ef  pinsrb xmm15, r12d, 0x01
000073dfa87cf1f6  lea r14, [rax+0x06]
000073dfa87cf1fa  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf200  pinsrb xmm14, r12d, 0x01
000073dfa87cf207  lea r14, [rax+0x07]
000073dfa87cf20b  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf211  pinsrb xmm13, r12d, 0x01
000073dfa87cf218  lea r14, [rax+0x08]
000073dfa87cf21c  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf222  pinsrb xmm1, r12d, 0x02
000073dfa87cf229  lea r14, [rax+0x09]
000073dfa87cf22d  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf233  pinsrb xmm15, r12d, 0x02
000073dfa87cf23a  lea r14, [rax+0x0A]
000073dfa87cf23e  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf244  pinsrb xmm14, r12d, 0x02
000073dfa87cf24b  lea r14, [rax+0x0B]
000073dfa87cf24f  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf255  pinsrb xmm13, r12d, 0x02
000073dfa87cf25c  lea r14, [rax+0x0C]
000073dfa87cf260  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf266  pinsrb xmm1, r12d, 0x03
000073dfa87cf26d  lea r14, [rax+0x0D]
000073dfa87cf271  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf277  pinsrb xmm15, r12d, 0x03
000073dfa87cf27e  lea r14, [rax+0x0E]
000073dfa87cf282  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf288  pinsrb xmm14, r12d, 0x03
000073dfa87cf28f  lea r14, [rax+0x0F]
000073dfa87cf293  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf299  pinsrb xmm13, r12d, 0x03
000073dfa87cf2a0  lea r14, [rax+0x10]
000073dfa87cf2a4  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf2aa  pinsrb xmm1, r12d, 0x04
000073dfa87cf2b1  lea r14, [rax+0x11]
000073dfa87cf2b5  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf2bb  pinsrb xmm15, r12d, 0x04
000073dfa87cf2c2  lea r14, [rax+0x12]
000073dfa87cf2c6  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf2cc  pinsrb xmm14, r12d, 0x04
000073dfa87cf2d3  lea r14, [rax+0x13]
000073dfa87cf2d7  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf2dd  pinsrb xmm13, r12d, 0x04
000073dfa87cf2e4  lea r14, [rax+0x14]
000073dfa87cf2e8  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf2ee  pinsrb xmm1, r12d, 0x05
000073dfa87cf2f5  lea r14, [rax+0x15]
000073dfa87cf2f9  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf2ff  pinsrb xmm15, r12d, 0x05
000073dfa87cf306  lea r14, [rax+0x16]
000073dfa87cf30a  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf310  pinsrb xmm14, r12d, 0x05
000073dfa87cf317  lea r14, [rax+0x17]
000073dfa87cf31b  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf321  pinsrb xmm13, r12d, 0x05
000073dfa87cf328  lea r14, [rax+0x18]
000073dfa87cf32c  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf332  pinsrb xmm1, r12d, 0x06
000073dfa87cf339  lea r14, [rax+0x19]
000073dfa87cf33d  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf343  pinsrb xmm15, r12d, 0x06
000073dfa87cf34a  lea r14, [rax+0x1A]
000073dfa87cf34e  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf354  pinsrb xmm14, r12d, 0x06
000073dfa87cf35b  lea r14, [rax+0x1B]
000073dfa87cf35f  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf365  pinsrb xmm13, r12d, 0x06
000073dfa87cf36c  lea r14, [rax+0x1C]
000073dfa87cf370  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf376  pinsrb xmm1, r12d, 0x07
000073dfa87cf37d  lea r14, [rax+0x1D]
000073dfa87cf381  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf387  pinsrb xmm15, r12d, 0x07
000073dfa87cf38e  lea r14, [rax+0x1E]
000073dfa87cf392  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf398  pinsrb xmm14, r12d, 0x07
000073dfa87cf39f  lea r14, [rax+0x1F]
000073dfa87cf3a3  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf3a9  pinsrb xmm13, r12d, 0x07
000073dfa87cf3b0  lea r14, [rax+0x20]
000073dfa87cf3b4  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf3ba  pinsrb xmm1, r12d, 0x08
000073dfa87cf3c1  lea r14, [rax+0x21]
000073dfa87cf3c5  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf3cb  pinsrb xmm15, r12d, 0x08
000073dfa87cf3d2  lea r14, [rax+0x22]
000073dfa87cf3d6  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf3dc  pinsrb xmm14, r12d, 0x08
000073dfa87cf3e3  lea r14, [rax+0x23]
000073dfa87cf3e7  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf3ed  pinsrb xmm13, r12d, 0x08
000073dfa87cf3f4  lea r14, [rax+0x24]
000073dfa87cf3f8  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf3fe  pinsrb xmm1, r12d, 0x09
000073dfa87cf405  lea r14, [rax+0x25]
000073dfa87cf409  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf40f  pinsrb xmm15, r12d, 0x09
000073dfa87cf416  lea r14, [rax+0x26]
000073dfa87cf41a  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf420  pinsrb xmm14, r12d, 0x09
000073dfa87cf427  lea r14, [rax+0x27]
000073dfa87cf42b  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf431  pinsrb xmm13, r12d, 0x09
000073dfa87cf438  lea r14, [rax+0x28]
000073dfa87cf43c  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf442  pinsrb xmm1, r12d, 0x0A
000073dfa87cf449  lea r14, [rax+0x29]
000073dfa87cf44d  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf453  pinsrb xmm15, r12d, 0x0A
000073dfa87cf45a  lea r14, [rax+0x2A]
000073dfa87cf45e  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf464  pinsrb xmm14, r12d, 0x0A
000073dfa87cf46b  lea r14, [rax+0x2B]
000073dfa87cf46f  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf475  pinsrb xmm13, r12d, 0x0A
000073dfa87cf47c  lea r14, [rax+0x2C]
000073dfa87cf480  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf486  pinsrb xmm1, r12d, 0x0B
000073dfa87cf48d  lea r14, [rax+0x2D]
000073dfa87cf491  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf497  pinsrb xmm15, r12d, 0x0B
000073dfa87cf49e  lea r14, [rax+0x2E]
000073dfa87cf4a2  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf4a8  pinsrb xmm14, r12d, 0x0B
000073dfa87cf4af  lea r14, [rax+0x2F]
000073dfa87cf4b3  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf4b9  pinsrb xmm13, r12d, 0x0B
000073dfa87cf4c0  lea r14, [rax+0x30]
000073dfa87cf4c4  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf4ca  pinsrb xmm1, r12d, 0x0C
000073dfa87cf4d1  lea r14, [rax+0x31]
000073dfa87cf4d5  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf4db  pinsrb xmm15, r12d, 0x0C
000073dfa87cf4e2  lea r14, [rax+0x32]
000073dfa87cf4e6  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf4ec  pinsrb xmm14, r12d, 0x0C
000073dfa87cf4f3  lea r14, [rax+0x33]
000073dfa87cf4f7  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf4fd  pinsrb xmm13, r12d, 0x0C
000073dfa87cf504  lea r14, [rax+0x34]
000073dfa87cf508  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf50e  pinsrb xmm1, r12d, 0x0D
000073dfa87cf515  lea r14, [rax+0x35]
000073dfa87cf519  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf51f  pinsrb xmm15, r12d, 0x0D
000073dfa87cf526  lea r14, [rax+0x36]
000073dfa87cf52a  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf530  pinsrb xmm14, r12d, 0x0D
000073dfa87cf537  lea r14, [rax+0x37]
000073dfa87cf53b  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf541  pinsrb xmm13, r12d, 0x0D
000073dfa87cf548  lea r14, [rax+0x38]
000073dfa87cf54c  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf552  pinsrb xmm1, r12d, 0x0E
000073dfa87cf559  lea r14, [rax+0x39]
000073dfa87cf55d  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf563  pinsrb xmm15, r12d, 0x0E
000073dfa87cf56a  lea r14, [rax+0x3A]
000073dfa87cf56e  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf574  pinsrb xmm14, r12d, 0x0E
000073dfa87cf57b  lea r14, [rax+0x3B]
000073dfa87cf57f  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf585  pinsrb xmm13, r12d, 0x0E
000073dfa87cf58c  lea r14, [rax+0x3C]
000073dfa87cf590  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf596  pinsrb xmm1, r12d, 0x0F
000073dfa87cf59d  movaps [r15+0x110], xmm1
000073dfa87cf5a5  lea r14, [rax+0x3D]
000073dfa87cf5a9  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf5af  pinsrb xmm15, r12d, 0x0F
000073dfa87cf5b6  movaps [r15+0x120], xmm15
000073dfa87cf5be  lea r14, [rax+0x3E]
000073dfa87cf5c2  movzx r12d, byte ptr [r13+r14*1]
000073dfa87cf5c8  pinsrb xmm14, r12d, 0x0F
000073dfa87cf5cf  movaps [r15+0x130], xmm14
000073dfa87cf5d7  lea r14, [rax+0x3F]
000073dfa87cf5db  movzx eax, byte ptr [r13+r14*1]
000073dfa87cf5e1  pinsrb xmm13, eax, 0x0F
000073dfa87cf5e8  movaps [r15+0x140], xmm13
000073dfa87cf5f0  movq xmm1, qword ptr [r15+0x120]
000073dfa87cf5f9  pmovzxbw xmm1, xmm1
000073dfa87cf5fe  psllw xmm1, 0x00
000073dfa87cf603  movaps [r15+0x150], xmm1
000073dfa87cf60b  movq xmm1, qword ptr [r15+0x130]
000073dfa87cf614  pmovzxbw xmm1, xmm1
000073dfa87cf619  psllw xmm1, 0x00
000073dfa87cf61e  movaps [r15+0x160], xmm1
000073dfa87cf626  movq xmm1, qword ptr [r15+0x110]
000073dfa87cf62f  pmovzxbw xmm1, xmm1
000073dfa87cf634  psllw xmm1, 0x00
000073dfa87cf639  movaps [r15+0x170], xmm1
000073dfa87cf641  movaps xmm15, [r15+0x110]
000073dfa87cf649  pextrq rax, xmm15, 0x01
000073dfa87cf650  movq xmm15, rax
000073dfa87cf655  pmovzxbw xmm15, xmm15
000073dfa87cf65b  psllw xmm15, 0x00
000073dfa87cf661  movaps [r15+0x180], xmm15
000073dfa87cf669  movaps xmm14, [r15+0x120]
000073dfa87cf671  pextrq rax, xmm14, 0x01
000073dfa87cf678  movq xmm14, rax
000073dfa87cf67d  pmovzxbw xmm14, xmm14
000073dfa87cf683  psllw xmm14, 0x00
000073dfa87cf689  movaps [r15+0x210], xmm14
000073dfa87cf691  movaps xmm13, [r15+0x130]
000073dfa87cf699  pextrq rax, xmm13, 0x01
000073dfa87cf6a0  movq xmm13, rax
000073dfa87cf6a5  pmovzxbw xmm13, xmm13
000073dfa87cf6ab  psllw xmm13, 0x00
000073dfa87cf6b1  movaps [r15+0x220], xmm13
000073dfa87cf6b9  movq xmm12, qword ptr [r15+0x140]
000073dfa87cf6c2  pmovzxbw xmm12, xmm12
000073dfa87cf6c8  psllw xmm12, 0x00
000073dfa87cf6ce  movaps [r15+0x250], xmm12
000073dfa87cf6d6  movaps xmm12, [r15+0x140]
000073dfa87cf6de  pextrq rax, xmm12, 0x01
000073dfa87cf6e5  movq xmm12, rax
000073dfa87cf6ea  pmovzxbw xmm12, xmm12
000073dfa87cf6f0  psllw xmm12, 0x00
000073dfa87cf6f6  movaps [r15+0x110], xmm12
000073dfa87cf6fe  movq xmm11, qword ptr [r15+0x150]
000073dfa87cf707  pmovzxwd xmm11, xmm11
000073dfa87cf70d  pslld xmm11, 0x10
000073dfa87cf713  movq xmm10, qword ptr [r15+0x160]
000073dfa87cf71c  pmovzxwd xmm10, xmm10
000073dfa87cf722  pslld xmm10, 0x08
000073dfa87cf728  pextrq rax, xmm1, 0x01
000073dfa87cf72f  movq xmm1, rax
000073dfa87cf734  pmovzxwd xmm1, xmm1
000073dfa87cf739  pslld xmm1, 0x00
000073dfa87cf73e  movaps [r15+0x260], xmm1
000073dfa87cf746  pextrq rax, xmm15, 0x01
000073dfa87cf74d  movq xmm15, rax
000073dfa87cf752  pmovzxwd xmm15, xmm15
000073dfa87cf758  pslld xmm15, 0x00
000073dfa87cf75e  movaps [r15+0x270], xmm15
000073dfa87cf766  movq xmm9, qword ptr [r15+0x170]
000073dfa87cf76f  pmovzxwd xmm9, xmm9
000073dfa87cf775  pslld xmm9, 0x00
000073dfa87cf77b  pextrq rax, xmm14, 0x01
000073dfa87cf782  movq xmm14, rax
000073dfa87cf787  pmovzxwd xmm14, xmm14
000073dfa87cf78d  pslld xmm14, 0x10
000073dfa87cf793  movaps [r15+0x280], xmm14
000073dfa87cf79b  movq xmm8, qword ptr [r15+0x180]
000073dfa87cf7a4  pmovzxwd xmm8, xmm8
000073dfa87cf7aa  pslld xmm8, 0x00
000073dfa87cf7b0  movq xmm7, qword ptr [r15+0x210]
000073dfa87cf7b9  pmovzxwd xmm7, xmm7
000073dfa87cf7be  pslld xmm7, 0x10
000073dfa87cf7c3  movaps xmm6, [r15+0x150]
000073dfa87cf7cb  pextrq rax, xmm6, 0x01
000073dfa87cf7d2  movq xmm6, rax
000073dfa87cf7d7  pmovzxwd xmm6, xmm6
000073dfa87cf7dc  pslld xmm6, 0x10
000073dfa87cf7e1  por xmm11, xmm10
000073dfa87cf7e6  movaps [r15+0x230], xmm11
000073dfa87cf7ee  pextrq rax, xmm13, 0x01
000073dfa87cf7f5  movq xmm13, rax
000073dfa87cf7fa  pmovzxwd xmm13, xmm13
000073dfa87cf800  pslld xmm13, 0x08
000073dfa87cf806  movaps [r15+0x240], xmm13
000073dfa87cf80e  movq xmm10, qword ptr [r15+0x220]
000073dfa87cf817  pmovzxwd xmm10, xmm10
000073dfa87cf81d  pslld xmm10, 0x08
000073dfa87cf823  movaps xmm5, [r15+0x160]
000073dfa87cf82b  pextrq rax, xmm5, 0x01
000073dfa87cf832  movq xmm5, rax
000073dfa87cf837  pmovzxwd xmm5, xmm5
000073dfa87cf83c  pslld xmm5, 0x08
000073dfa87cf841  pslld xmm9, 0x18
000073dfa87cf847  pslld xmm15, 0x18
000073dfa87cf84d  pslld xmm8, 0x18
000073dfa87cf853  movq xmm4, qword ptr [r15+0x250]
000073dfa87cf85c  pmovzxwd xmm4, xmm4
000073dfa87cf861  pslld xmm4, 0x00
000073dfa87cf866  por xmm14, xmm13
000073dfa87cf86b  por xmm7, xmm10
000073dfa87cf870  movaps [r15+0x210], xmm7
000073dfa87cf878  pslld xmm1, 0x18
000073dfa87cf87d  movaps [r15+0x220], xmm1
000073dfa87cf885  por xmm6, xmm5
000073dfa87cf889  por xmm11, xmm9
000073dfa87cf88e  movaps [r15+0x160], xmm11
000073dfa87cf896  pextrq rax, xmm12, 0x01
000073dfa87cf89d  movq xmm13, rax
000073dfa87cf8a2  pmovzxwd xmm13, xmm13
000073dfa87cf8a8  pslld xmm13, 0x00
000073dfa87cf8ae  movaps [r15+0x170], xmm13
000073dfa87cf8b6  movq xmm12, qword ptr [r15+0x110]
000073dfa87cf8bf  pmovzxwd xmm12, xmm12
000073dfa87cf8c5  pslld xmm12, 0x00
000073dfa87cf8cb  por xmm14, xmm15
000073dfa87cf8d0  por xmm7, xmm8
000073dfa87cf8d5  movaps xmm15, [r15+0x250]
000073dfa87cf8dd  pextrq rax, xmm15, 0x01
000073dfa87cf8e4  movq xmm15, rax
000073dfa87cf8e9  pmovzxwd xmm15, xmm15
000073dfa87cf8ef  pslld xmm15, 0x00
000073dfa87cf8f5  movaps [r15+0x180], xmm15
000073dfa87cf8fd  por xmm6, xmm1
000073dfa87cf901  movaps [r15+0x150], xmm6
000073dfa87cf909  por xmm11, xmm4
000073dfa87cf90e  movaps [r15+0x140], xmm11
000073dfa87cf916  por xmm7, xmm12
000073dfa87cf91b  movaps [r15+0x110], xmm7
000073dfa87cf923  por xmm14, xmm13
000073dfa87cf928  movaps [r15+0x120], xmm14
000073dfa87cf930  por xmm6, xmm15
000073dfa87cf935  movaps [r15+0x130], xmm6
000073dfa87cf93d  mov rax, [r15+0xF8]
000073dfa87cf944  lea r14, [rax+0x20]
000073dfa87cf948  movups [r13+r14*1], xmm7
000073dfa87cf94e  lea r14, [rax+0x30]
000073dfa87cf952  movups [r13+r14*1], xmm14
000073dfa87cf958  movups [r13+rax*1], xmm11
000073dfa87cf95e  lea r14, [rax+0x10]
000073dfa87cf962  movups [r13+r14*1], xmm6
000073dfa87cf968  mov r14d, [r13+rax*1]
000073dfa87cf96d  mov rax, [r15+0x48]
000073dfa87cf971  mov [r15+0x68], rax
000073dfa87cf975  mov qword ptr [r15+0x58], 0x04
000073dfa87cf97d  lea r12, [rax+0x04]
000073dfa87cf981  mov r11d, [r13+r12*1]
000073dfa87cf986  mov [rsp+0x10], r11d
000073dfa87cf98b  mov r11d, r11d
000073dfa87cf98e  mov [r15+0x70], r11
000073dfa87cf992  lea r12, [rax+0x38]
000073dfa87cf996  mov r11d, [r13+r12*1]
000073dfa87cf99b  lea r12, [rax+0x24]
000073dfa87cf99f  mov r10d, [r13+r12*1]
000073dfa87cf9a4  mov [rsp+0x20], r10d
000073dfa87cf9a9  mov r10d, r10d
000073dfa87cf9ac  mov [r15+0x90], r10
000073dfa87cf9b3  mov [rsp+0x30], rax
000073dfa87cf9b8  xor eax, eax
000073dfa87cf9ba  mov r12d, 0x04
000073dfa87cf9c0  mov r10d, 0xC0
000073dfa87cf9c6  cmp r12, r10
000073dfa87cf9c9  cmc
000073dfa87cf9ca  lahf
000073dfa87cf9cb  seto al
000073dfa87cf9ce  mov [r15+0x108], eax
000073dfa87cf9d5  mov eax, [rsp+0x10]
000073dfa87cf9d9  mov r12d, [rsp+0x10]
000073dfa87cf9de  shrd eax, r12d, 0x07
000073dfa87cf9e3  mov [rsp+0x10], r11d
000073dfa87cf9e8  mov r10d, [rsp+0x10]
000073dfa87cf9ed  shrd r11d, r10d, 0x11
000073dfa87cf9f2  mov r9d, [rsp+0x20]
000073dfa87cf9f7  lea r8d, [r9d+r14d*1]
000073dfa87cf9fc  rorx r14d, r12d, 0x12
000073dfa87cfa02  xor eax, r14d
000073dfa87cfa05  rorx r14d, r10d, 0x13
000073dfa87cfa0b  xor r11d, r14d
000073dfa87cfa0e  mov [rsp+0x10], r11d
000073dfa87cfa13  mov r11d, r11d
000073dfa87cfa16  mov [r15+0x88], r11
000073dfa87cfa1d  mov [rsp+0x20], r12d
000073dfa87cfa22  shr r12d, 0x03
000073dfa87cfa26  xor eax, r12d
000073dfa87cfa29  mov [rsp+0x40], eax
000073dfa87cfa2d  mov eax, eax
000073dfa87cfa2f  mov [r15+0x80], rax
000073dfa87cfa36  shr r10d, 0x0A
000073dfa87cfa3a  mov eax, [rsp+0x10]
000073dfa87cfa3e  xor eax, r10d
000073dfa87cfa41  mov [rsp+0x10], eax
000073dfa87cfa45  mov eax, eax
000073dfa87cfa47  mov [r15+0x78], rax
000073dfa87cfa4b  mov eax, [rsp+0x40]
000073dfa87cfa4f  lea r14d, [r8d+eax*1]
000073dfa87cfa54  mov eax, [rsp+0x10]
000073dfa87cfa58  lea r12d, [r14d+eax*1]
000073dfa87cfa5d  mov rax, [rsp+0x30]
000073dfa87cfa62  lea r14, [rax+0x40]
000073dfa87cfa66  mov [r13+r14*1], r12d
000073dfa87cfa6b  mov eax, [rsp+0x20]
000073dfa87cfa6f  mov eax, eax
000073dfa87cfa71  mov [r15+0x60], rax
000073dfa87cfa75  mov eax, [r15+0x108]
000073dfa87cfa7c  sahf
000073dfa87cfa7d  jnz 0x000073DFA87CFAAF
000073dfa87cfa7f  cmp dword ptr [r15+0x318], 0x00
000073dfa87cfa87  jz 0x000073DFA87CFF70
000073dfa87cfa8d  nop [rax+rax*1], ax
000073dfa87cfa96  nop [rax+rax*1], eax
000073dfa87cfa9e  mov eax, 0x41088C
000073dfa87cfaa3  mov [r15+0x100], rax
000073dfa87cfaaa  jmp 0x000073DFA85FE110
000073dfa87cfaaf  cmp dword ptr [r15+0x318], 0x00
000073dfa87cfab7  jz 0x000073DFA87CFDC0
000073dfa87cfabd  nop [rax+rax*1], ax
000073dfa87cfac6  nop [rax+rax*1], eax
000073dfa87cface  mov eax, 0x410844
000073dfa87cfad3  mov [r15+0x100], rax
000073dfa87cfada  jmp 0x000073DFA85FE110
000073dfa87cfadf  int3
000073dfa87cfae0  call 0x000073DFA860D860
000073dfa87cfae5  jmp 0x000073DFA87CF17A
000073dfa87cfaea  call 0x000073DFA86E2420
000073dfa87cfaef  jmp 0x000073DFA87CF193
000073dfa87cfaf4  call 0x000073DFA86E2420
000073dfa87cfaf9  jmp 0x000073DFA87CF1AC
000073dfa87cfafe  call 0x000073DFA86E2420
000073dfa87cfb03  jmp 0x000073DFA87CF1C5
000073dfa87cfb08  call 0x000073DFA86E2420
000073dfa87cfb0d  jmp 0x000073DFA87CF1DE
000073dfa87cfb12  call 0x000073DFA86E2420
000073dfa87cfb17  jmp 0x000073DFA87CF1EF
000073dfa87cfb1c  call 0x000073DFA86E2420
000073dfa87cfb21  jmp 0x000073DFA87CF200
000073dfa87cfb26  call 0x000073DFA86E2420
000073dfa87cfb2b  jmp 0x000073DFA87CF211
000073dfa87cfb30  call 0x000073DFA86E2420
000073dfa87cfb35  jmp 0x000073DFA87CF222
000073dfa87cfb3a  call 0x000073DFA86E2420
000073dfa87cfb3f  jmp 0x000073DFA87CF233
000073dfa87cfb44  call 0x000073DFA86E2420
000073dfa87cfb49  jmp 0x000073DFA87CF244
000073dfa87cfb4e  call 0x000073DFA86E2420
000073dfa87cfb53  jmp 0x000073DFA87CF255
000073dfa87cfb58  call 0x000073DFA86E2420
000073dfa87cfb5d  jmp 0x000073DFA87CF266
000073dfa87cfb62  call 0x000073DFA86E2420
000073dfa87cfb67  jmp 0x000073DFA87CF277
000073dfa87cfb6c  call 0x000073DFA86E2420
000073dfa87cfb71  jmp 0x000073DFA87CF288
000073dfa87cfb76  call 0x000073DFA86E2420
000073dfa87cfb7b  jmp 0x000073DFA87CF299
000073dfa87cfb80  call 0x000073DFA86E2420
000073dfa87cfb85  jmp 0x000073DFA87CF2AA
000073dfa87cfb8a  call 0x000073DFA86E2420
000073dfa87cfb8f  jmp 0x000073DFA87CF2BB
000073dfa87cfb94  call 0x000073DFA86E2420
000073dfa87cfb99  jmp 0x000073DFA87CF2CC
000073dfa87cfb9e  call 0x000073DFA86E2420
000073dfa87cfba3  jmp 0x000073DFA87CF2DD
000073dfa87cfba8  call 0x000073DFA86E2420
000073dfa87cfbad  jmp 0x000073DFA87CF2EE
000073dfa87cfbb2  call 0x000073DFA86E2420
000073dfa87cfbb7  jmp 0x000073DFA87CF2FF
000073dfa87cfbbc  call 0x000073DFA86E2420
000073dfa87cfbc1  jmp 0x000073DFA87CF310
000073dfa87cfbc6  call 0x000073DFA86E2420
000073dfa87cfbcb  jmp 0x000073DFA87CF321
000073dfa87cfbd0  call 0x000073DFA86E2420
000073dfa87cfbd5  jmp 0x000073DFA87CF332
000073dfa87cfbda  call 0x000073DFA86E2420
000073dfa87cfbdf  jmp 0x000073DFA87CF343
000073dfa87cfbe4  call 0x000073DFA86E2420
000073dfa87cfbe9  jmp 0x000073DFA87CF354
000073dfa87cfbee  call 0x000073DFA86E2420
000073dfa87cfbf3  jmp 0x000073DFA87CF365
000073dfa87cfbf8  call 0x000073DFA86E2420
000073dfa87cfbfd  jmp 0x000073DFA87CF376
000073dfa87cfc02  call 0x000073DFA86E2420
000073dfa87cfc07  jmp 0x000073DFA87CF387
000073dfa87cfc0c  call 0x000073DFA86E2420
000073dfa87cfc11  jmp 0x000073DFA87CF398
000073dfa87cfc16  call 0x000073DFA86E2420
000073dfa87cfc1b  jmp 0x000073DFA87CF3A9
000073dfa87cfc20  call 0x000073DFA86E2420
000073dfa87cfc25  jmp 0x000073DFA87CF3BA
000073dfa87cfc2a  call 0x000073DFA86E2420
000073dfa87cfc2f  jmp 0x000073DFA87CF3CB
000073dfa87cfc34  call 0x000073DFA86E2420
000073dfa87cfc39  jmp 0x000073DFA87CF3DC
000073dfa87cfc3e  call 0x000073DFA86E2420
000073dfa87cfc43  jmp 0x000073DFA87CF3ED
000073dfa87cfc48  call 0x000073DFA86E2420
000073dfa87cfc4d  jmp 0x000073DFA87CF3FE
000073dfa87cfc52  call 0x000073DFA86E2420
000073dfa87cfc57  jmp 0x000073DFA87CF40F
000073dfa87cfc5c  call 0x000073DFA86E2420
000073dfa87cfc61  jmp 0x000073DFA87CF420
000073dfa87cfc66  call 0x000073DFA86E2420
000073dfa87cfc6b  jmp 0x000073DFA87CF431
000073dfa87cfc70  call 0x000073DFA86E2420
000073dfa87cfc75  jmp 0x000073DFA87CF442
000073dfa87cfc7a  call 0x000073DFA86E2420
000073dfa87cfc7f  jmp 0x000073DFA87CF453
000073dfa87cfc84  call 0x000073DFA86E2420
000073dfa87cfc89  jmp 0x000073DFA87CF464
000073dfa87cfc8e  call 0x000073DFA86E2420
000073dfa87cfc93  jmp 0x000073DFA87CF475
000073dfa87cfc98  call 0x000073DFA86E2420
000073dfa87cfc9d  jmp 0x000073DFA87CF486
000073dfa87cfca2  call 0x000073DFA86E2420
000073dfa87cfca7  jmp 0x000073DFA87CF497
000073dfa87cfcac  call 0x000073DFA86E2420
000073dfa87cfcb1  jmp 0x000073DFA87CF4A8
000073dfa87cfcb6  call 0x000073DFA86E2420
000073dfa87cfcbb  jmp 0x000073DFA87CF4B9
000073dfa87cfcc0  call 0x000073DFA86E2420
000073dfa87cfcc5  jmp 0x000073DFA87CF4CA
000073dfa87cfcca  call 0x000073DFA86E2420
000073dfa87cfccf  jmp 0x000073DFA87CF4DB
000073dfa87cfcd4  call 0x000073DFA86E2420
000073dfa87cfcd9  jmp 0x000073DFA87CF4EC
000073dfa87cfcde  call 0x000073DFA86E2420
000073dfa87cfce3  jmp 0x000073DFA87CF4FD
000073dfa87cfce8  call 0x000073DFA86E2420
000073dfa87cfced  jmp 0x000073DFA87CF50E
000073dfa87cfcf2  call 0x000073DFA86E2420
000073dfa87cfcf7  jmp 0x000073DFA87CF51F
000073dfa87cfcfc  call 0x000073DFA86E2420
000073dfa87cfd01  jmp 0x000073DFA87CF530
000073dfa87cfd06  call 0x000073DFA86E2420
000073dfa87cfd0b  jmp 0x000073DFA87CF541
000073dfa87cfd10  call 0x000073DFA86E2420
000073dfa87cfd15  jmp 0x000073DFA87CF552
000073dfa87cfd1a  call 0x000073DFA86E2420
000073dfa87cfd1f  jmp 0x000073DFA87CF563
000073dfa87cfd24  call 0x000073DFA86E2420
000073dfa87cfd29  jmp 0x000073DFA87CF574
000073dfa87cfd2e  call 0x000073DFA86E2420
000073dfa87cfd33  jmp 0x000073DFA87CF585
000073dfa87cfd38  call 0x000073DFA86E2420
000073dfa87cfd3d  jmp 0x000073DFA87CF596
000073dfa87cfd42  call 0x000073DFA86E2420
000073dfa87cfd47  jmp 0x000073DFA87CF5AF
000073dfa87cfd4c  call 0x000073DFA86E2420
000073dfa87cfd51  jmp 0x000073DFA87CF5C8
000073dfa87cfd56  call 0x000073DFA86D5610
000073dfa87cfd5b  jmp 0x000073DFA87CF5E1
000073dfa87cfd60  call 0x000073DFA86DC580
000073dfa87cfd65  jmp 0x000073DFA87CF94E
000073dfa87cfd6a  call 0x000073DFA86E46C0
000073dfa87cfd6f  jmp 0x000073DFA87CF958
000073dfa87cfd74  call 0x000073DFA8609E90
000073dfa87cfd79  jmp 0x000073DFA87CF95E
000073dfa87cfd7e  call 0x000073DFA86DB310
000073dfa87cfd83  jmp 0x000073DFA87CF968
000073dfa87cfd88  call 0x000073DFA860DAE0
000073dfa87cfd8d  jmp 0x000073DFA87CF96D
000073dfa87cfd92  call 0x000073DFA86C0230
000073dfa87cfd97  jmp 0x000073DFA87CF986
000073dfa87cfd9c  call 0x000073DFA86C0230
000073dfa87cfda1  jmp 0x000073DFA87CF99B
000073dfa87cfda6  call 0x000073DFA86BEFC0
000073dfa87cfdab  jmp 0x000073DFA87CF9A4
000073dfa87cfdb0  call 0x000073DFA86E2BA0
000073dfa87cfdb5  jmp 0x000073DFA87CFA6B
000073dfa87cfdba  int3
000073dfa87cfdbb  nop [rax+rax*1], eax
000073dfa87cfdc0  mov rax, [r15+0x48]
000073dfa87cfdc4  mov r14, [r15+0x58]
000073dfa87cfdc8  lea r12, [rax+r14*1]
000073dfa87cfdcc  mov [r15+0x68], r12
000073dfa87cfdd0  lea rax, [r14+0x04]
000073dfa87cfdd4  mov [r15+0x58], rax
000073dfa87cfdd8  lea r14, [r12+0x04]
000073dfa87cfddd  mov r11d, [r13+r14*1]
000073dfa87cfde2  mov [rsp+0x10], r11d
000073dfa87cfde7  mov r11d, r11d
000073dfa87cfdea  mov [r15+0x70], r11
000073dfa87cfdee  lea r14, [r12+0x38]
000073dfa87cfdf3  mov r11d, [r13+r14*1]
000073dfa87cfdf8  lea r14, [r12+0x24]
000073dfa87cfdfd  mov r10d, [r13+r14*1]
000073dfa87cfe02  mov [rsp+0x20], r10d
000073dfa87cfe07  mov r10d, r10d
000073dfa87cfe0a  mov [r15+0x90], r10
000073dfa87cfe11  mov [rsp+0x30], rax
000073dfa87cfe16  xor eax, eax
000073dfa87cfe18  mov r14, [rsp+0x30]
000073dfa87cfe1d  mov r10d, 0xC0
000073dfa87cfe23  cmp r14, r10
000073dfa87cfe26  cmc
000073dfa87cfe27  lahf
000073dfa87cfe28  seto al
000073dfa87cfe2b  mov [r15+0x108], eax
000073dfa87cfe32  mov eax, [rsp+0x10]
000073dfa87cfe36  mov r14d, [rsp+0x10]
000073dfa87cfe3b  shrd eax, r14d, 0x07
000073dfa87cfe40  mov [rsp+0x10], r11d
000073dfa87cfe45  mov r10d, [rsp+0x10]
000073dfa87cfe4a  shrd r11d, r10d, 0x11
000073dfa87cfe4f  mov r9d, [r15+0x60]
000073dfa87cfe53  mov r8d, [rsp+0x20]
000073dfa87cfe58  lea ebp, [r8d+r9d*1]
000073dfa87cfe5d  rorx r9d, r14d, 0x12
000073dfa87cfe63  xor eax, r9d
000073dfa87cfe66  rorx r9d, r10d, 0x13
000073dfa87cfe6c  xor r11d, r9d
000073dfa87cfe6f  mov [rsp+0x10], r11d
000073dfa87cfe74  mov r11d, r11d
000073dfa87cfe77  mov [r15+0x88], r11
000073dfa87cfe7e  mov [rsp+0x20], r14d
000073dfa87cfe83  shr r14d, 0x03
000073dfa87cfe87  xor eax, r14d
000073dfa87cfe8a  mov [rsp+0x30], eax
000073dfa87cfe8e  mov eax, eax
000073dfa87cfe90  mov [r15+0x80], rax
000073dfa87cfe97  shr r10d, 0x0A
000073dfa87cfe9b  mov eax, [rsp+0x10]
000073dfa87cfe9f  xor eax, r10d
000073dfa87cfea2  mov [rsp+0x10], eax
000073dfa87cfea6  mov eax, eax
000073dfa87cfea8  mov [r15+0x78], rax
000073dfa87cfeac  mov eax, [rsp+0x30]
000073dfa87cfeb0  lea r14d, [ebp+eax*1]
000073dfa87cfeb6  mov eax, [rsp+0x10]
000073dfa87cfeba  lea r11d, [r14d+eax*1]
000073dfa87cfebf  lea rax, [r12+0x40]
000073dfa87cfec4  mov [r13+rax*1], r11d
000073dfa87cfec9  mov eax, [rsp+0x20]
000073dfa87cfecd  mov eax, eax
000073dfa87cfecf  mov [r15+0x60], rax
000073dfa87cfed3  mov eax, [r15+0x108]
000073dfa87cfeda  sahf
000073dfa87cfedb  jnz 0x000073DFA87CFF0D
000073dfa87cfedd  cmp dword ptr [r15+0x318], 0x00
000073dfa87cfee5  jz 0x000073DFA87CFF70
000073dfa87cfeeb  nop [rax+rax*1], ax
000073dfa87cfef4  nop [rax+rax*1], eax
000073dfa87cfefc  mov eax, 0x41088C
000073dfa87cff01  mov [r15+0x100], rax
000073dfa87cff08  jmp 0x000073DFA85FE110
000073dfa87cff0d  cmp dword ptr [r15+0x318], 0x00
000073dfa87cff15  jz 0x000073DFA87CFDC0
000073dfa87cff1b  nop [rax+rax*1], ax
000073dfa87cff24  nop [rax+rax*1], eax
000073dfa87cff2c  mov eax, 0x410844
000073dfa87cff31  mov [r15+0x100], rax
000073dfa87cff38  jmp 0x000073DFA85FE110
000073dfa87cff3d  int3
000073dfa87cff3e  call 0x000073DFA86E1430
000073dfa87cff43  jmp 0x000073DFA87CFDE2
000073dfa87cff48  call 0x000073DFA86E1430
000073dfa87cff4d  jmp 0x000073DFA87CFDF8
000073dfa87cff52  call 0x000073DFA86E01C0
000073dfa87cff57  jmp 0x000073DFA87CFE02
000073dfa87cff5c  call 0x000073DFA860A860
000073dfa87cff61  jmp 0x000073DFA87CFEC9
000073dfa87cff66  int3
000073dfa87cff67  nop [rax+rax*1], ax
000073dfa87cff70  mov rax, [r15]
000073dfa87cff73  mov r14d, [r13+rax*1]
000073dfa87cff78  lea r12, [rax+0x04]
000073dfa87cff7c  mov r11d, [r13+r12*1]
000073dfa87cff81  mov [rsp+0x10], r14d
000073dfa87cff86  mov r14d, r14d
000073dfa87cff89  mov [r15+0x78], r14
000073dfa87cff8d  mov [rsp+0x20], r11d
000073dfa87cff92  mov r11d, r11d
000073dfa87cff95  mov [r15+0x80], r11
000073dfa87cff9c  lea r14, [rax+0x08]
000073dfa87cffa0  mov r12d, [r13+r14*1]
000073dfa87cffa5  lea r14, [rax+0x0C]
000073dfa87cffa9  mov r11d, [r13+r14*1]
000073dfa87cffae  mov [rsp+0x30], r12d
000073dfa87cffb3  mov r12d, r12d
000073dfa87cffb6  mov [r15+0x70], r12
000073dfa87cffba  mov [rsp+0x40], r11d
000073dfa87cffbf  mov r11d, r11d
000073dfa87cffc2  mov [r15+0x68], r11
000073dfa87cffc6  lea r14, [rax+0x18]
000073dfa87cffca  mov r12d, [r13+r14*1]
000073dfa87cffcf  lea r14, [rax+0x1C]
000073dfa87cffd3  mov r11d, [r13+r14*1]
000073dfa87cffd8  mov [rsp+0x50], r12d
000073dfa87cffdd  mov r12d, r12d
000073dfa87cffe0  mov [r15+0x58], r12
000073dfa87cffe4  mov [rsp+0x60], r11d
000073dfa87cffe9  mov r11d, r11d
000073dfa87cffec  mov [r15+0x60], r11
000073dfa87cfff0  lea r14, [rax+0x10]
000073dfa87cfff4  mov r12d, [r13+r14*1]
000073dfa87cfff9  lea r14, [rax+0x14]
000073dfa87cfffd  mov eax, [r13+r14*1]
000073dfa87d0002  mov [rsp+0x70], r12d
000073dfa87d0007  mov r12d, r12d
000073dfa87d000a  mov [r15+0x18], r12
000073dfa87d000e  mov [rsp+0x80], eax
000073dfa87d0015  mov eax, eax
000073dfa87d0017  mov [r15+0x90], rax
000073dfa87d001e  mov eax, [rsp+0x70]
000073dfa87d0022  mov eax, eax
000073dfa87d0024  mov [r15+0x30], rax
000073dfa87d0028  mov eax, [rsp+0x50]
000073dfa87d002c  mov eax, eax
000073dfa87d002e  mov [r15+0xA0], rax
000073dfa87d0035  mov eax, [rsp+0x30]
000073dfa87d0039  mov eax, eax
000073dfa87d003b  mov [r15+0x28], rax
000073dfa87d003f  mov eax, [rsp+0x20]
000073dfa87d0043  mov eax, eax
000073dfa87d0045  mov [r15+0x98], rax
000073dfa87d004c  mov eax, [rsp+0x10]
000073dfa87d0050  mov eax, eax
000073dfa87d0052  mov [r15+0x38], rax
000073dfa87d0056  mov eax, [rsp+0x70]
000073dfa87d005a  mov r14d, [rsp+0x70]
000073dfa87d005f  shrd eax, r14d, 0x06
000073dfa87d0064  mov [rsp+0x70], r14d
000073dfa87d0069  mov r12d, [rsp+0x80]
000073dfa87d0071  and r14d, r12d
000073dfa87d0074  mov r11d, [rsp+0x10]
000073dfa87d0079  mov r10d, [rsp+0x10]
000073dfa87d007e  shrd r11d, r10d, 0x02
000073dfa87d0083  mov [rsp+0x10], r12d
000073dfa87d0088  mov r12d, r12d
000073dfa87d008b  mov [r15+0x20], r12
000073dfa87d008f  mov r12, [r15+0x50]
000073dfa87d0093  mov r9d, [r13+r12*1]
000073dfa87d0098  mov r12d, [rsp+0x50]
000073dfa87d009d  mov r8d, [rsp+0x70]
000073dfa87d00a2  andn ebp, r8d, r12d
000073dfa87d00a7  mov edi, [rsp+0x60]
000073dfa87d00ab  lea esi, [r14d+edi*1]
000073dfa87d00b0  rorx r14d, r8d, 0x0B
000073dfa87d00b6  xor eax, r14d
000073dfa87d00b9  rorx r14d, r10d, 0x0D
000073dfa87d00bf  xor r11d, r14d
000073dfa87d00c2  lea edi, [esi+ebp*1]
000073dfa87d00c6  mov r14, [r15+0x48]
000073dfa87d00ca  mov ebp, [r13+r14*1]
000073dfa87d00cf  mov r14d, [rsp+0x30]
000073dfa87d00d4  mov esi, [rsp+0x20]
000073dfa87d00d8  and r14d, esi
000073dfa87d00db  mov [rsp+0x20], r14d
000073dfa87d00e0  mov r14d, r14d
000073dfa87d00e3  mov [r15+0xD8], r14
000073dfa87d00ea  lea r14d, [edi+r9d*1]
000073dfa87d00ef  mov r9d, [rsp+0x30]
000073dfa87d00f4  xor r9d, esi
000073dfa87d00f7  rorx edi, r8d, 0x19
000073dfa87d00fd  xor eax, edi
000073dfa87d00ff  and r9d, r10d
000073dfa87d0102  rorx edi, r10d, 0x16
000073dfa87d0108  xor r11d, edi
000073dfa87d010b  mov [rsp+0x30], r11d
000073dfa87d0110  mov r11d, r11d
000073dfa87d0113  mov [r15+0xD0], r11
000073dfa87d011a  lea r11d, [r14d+ebp*1]
000073dfa87d011f  mov r10d, [rsp+0x20]
000073dfa87d0124  xor r9d, r10d
000073dfa87d0127  lea r14d, [r11d+eax*1]
000073dfa87d012c  mov qword ptr [r15+0x88], 0x04
000073dfa87d0137  mov eax, [rsp+0x30]
000073dfa87d013b  lea r11d, [r9d+eax*1]
000073dfa87d0140  mov eax, [rsp+0x40]
000073dfa87d0144  lea r10d, [r14d+eax*1]
000073dfa87d0149  mov r10d, r10d
000073dfa87d014c  mov [r15+0xB8], r10
000073dfa87d0153  xor eax, eax
000073dfa87d0155  mov r10d, 0x04
000073dfa87d015b  mov r9d, 0x100
000073dfa87d0161  cmp r10, r9
000073dfa87d0164  cmc
000073dfa87d0165  lahf
000073dfa87d0166  seto al
000073dfa87d0169  mov [r15+0x108], eax
000073dfa87d0170  lea eax, [r11d+r14d*1]
000073dfa87d0175  mov eax, eax
000073dfa87d0177  mov [r15+0xA8], rax
000073dfa87d017e  mov r12d, r12d
000073dfa87d0181  mov [r15+0xB0], r12
000073dfa87d0188  mov eax, [rsp+0x10]
000073dfa87d018c  mov eax, eax
000073dfa87d018e  mov [r15+0xC0], rax
000073dfa87d0195  mov r8d, r8d
000073dfa87d0198  mov [r15+0xC8], r8
000073dfa87d019f  mov eax, [r15+0x108]
000073dfa87d01a6  sahf
000073dfa87d01a7  jnz 0x000073DFA87D01D9
000073dfa87d01a9  cmp dword ptr [r15+0x318], 0x00
000073dfa87d01b1  jz 0x000073DFA87D04A0
000073dfa87d01b7  nop [rax+rax*1], ax
000073dfa87d01c0  nop [rax+rax*1], eax
000073dfa87d01c8  mov eax, 0x41094C
000073dfa87d01cd  mov [r15+0x100], rax
000073dfa87d01d4  jmp 0x000073DFA85FE110
000073dfa87d01d9  cmp dword ptr [r15+0x318], 0x00
000073dfa87d01e1  jz 0x000073DFA87D0270
000073dfa87d01e7  nop [rax+rax*1], ax
000073dfa87d01f0  nop [rax+rax*1], eax
000073dfa87d01f8  mov eax, 0x4108C0
000073dfa87d01fd  mov [r15+0x100], rax
000073dfa87d0204  jmp 0x000073DFA85FE110
000073dfa87d0209  int3
000073dfa87d020a  call 0x000073DFA860DAE0
000073dfa87d020f  jmp 0x000073DFA87CFF78
000073dfa87d0214  call 0x000073DFA86C0230
000073dfa87d0219  jmp 0x000073DFA87CFF81
000073dfa87d021e  call 0x000073DFA86E26A0
000073dfa87d0223  jmp 0x000073DFA87CFFA5
000073dfa87d0228  call 0x000073DFA86E1430
000073dfa87d022d  jmp 0x000073DFA87CFFAE
000073dfa87d0232  call 0x000073DFA86E26A0
000073dfa87d0237  jmp 0x000073DFA87CFFCF
000073dfa87d023c  call 0x000073DFA86E1430
000073dfa87d0241  jmp 0x000073DFA87CFFD8
000073dfa87d0246  call 0x000073DFA86E26A0
000073dfa87d024b  jmp 0x000073DFA87CFFF9
000073dfa87d0250  call 0x000073DFA86D5890
000073dfa87d0255  jmp 0x000073DFA87D0002
000073dfa87d025a  call 0x000073DFA86BDD50
000073dfa87d025f  jmp 0x000073DFA87D0098
000073dfa87d0264  call 0x000073DFA86DA580
000073dfa87d0269  jmp 0x000073DFA87D00CF
000073dfa87d026e  int3
000073dfa87d026f  nop
000073dfa87d0270  mov eax, [r15+0xB8]
000073dfa87d0277  mov [rsp+0x10], eax
000073dfa87d027b  mov eax, eax
000073dfa87d027d  mov [r15+0x30], rax
000073dfa87d0281  mov eax, [r15+0xC0]
000073dfa87d0288  mov [rsp+0x20], eax
000073dfa87d028c  mov eax, eax
000073dfa87d028e  mov [r15+0xA0], rax
000073dfa87d0295  mov eax, [r15+0x28]
000073dfa87d0299  mov r14d, [r15+0x98]
000073dfa87d02a0  mov [rsp+0x30], r14d
000073dfa87d02a5  mov r14d, r14d
000073dfa87d02a8  mov [r15+0x28], r14
000073dfa87d02ac  mov r14d, [r15+0x38]
000073dfa87d02b0  mov [rsp+0x40], r14d
000073dfa87d02b5  mov r14d, r14d
000073dfa87d02b8  mov [r15+0x98], r14
000073dfa87d02bf  mov r14d, [r15+0xA8]
000073dfa87d02c6  mov [rsp+0x50], r14d
000073dfa87d02cb  mov r14d, r14d
000073dfa87d02ce  mov [r15+0x38], r14
000073dfa87d02d2  mov r14d, [rsp+0x10]
000073dfa87d02d7  mov r12d, [rsp+0x10]
000073dfa87d02dc  shrd r14d, r12d, 0x06
000073dfa87d02e1  mov r11d, [r15+0xC8]
000073dfa87d02e8  mov [rsp+0x10], r12d
000073dfa87d02ed  and r12d, r11d
000073dfa87d02f0  mov r10d, [rsp+0x50]
000073dfa87d02f5  mov r9d, [rsp+0x50]
000073dfa87d02fa  shrd r10d, r9d, 0x02
000073dfa87d02ff  mov [rsp+0x50], r11d
000073dfa87d0304  mov r11d, r11d
000073dfa87d0307  mov [r15+0x20], r11
000073dfa87d030b  mov r11, [r15+0x88]
000073dfa87d0312  mov r8, [r15+0x50]
000073dfa87d0316  lea rbp, [r8+r11*1]
000073dfa87d031a  mov r8d, [r13+rbp*1]
000073dfa87d031f  mov ebp, [rsp+0x20]
000073dfa87d0323  mov edi, [rsp+0x10]
000073dfa87d0327  andn esi, edi, ebp
000073dfa87d032c  mov edx, [r15+0xB0]
000073dfa87d0333  lea ecx, [r12d+edx*1]
000073dfa87d0338  rorx r12d, edi, 0x0B
000073dfa87d033e  xor r14d, r12d
000073dfa87d0341  rorx r12d, r9d, 0x0D
000073dfa87d0347  xor r10d, r12d
000073dfa87d034a  lea r12d, [ecx+esi*1]
000073dfa87d034f  mov rsi, [r15+0x48]
000073dfa87d0353  lea rdx, [rsi+r11*1]
000073dfa87d0357  mov esi, [r13+rdx*1]
000073dfa87d035c  mov edx, [rsp+0x30]
000073dfa87d0360  mov ecx, [rsp+0x40]
000073dfa87d0364  and edx, ecx
000073dfa87d0366  mov [rsp+0x10], edx
000073dfa87d036a  mov edx, edx
000073dfa87d036c  mov [r15+0xD8], rdx
000073dfa87d0373  lea edx, [r12d+r8d*1]
000073dfa87d0378  mov r12d, [rsp+0x30]
000073dfa87d037d  xor r12d, ecx
000073dfa87d0380  rorx r8d, edi, 0x19
000073dfa87d0386  xor r14d, r8d
000073dfa87d0389  and r12d, r9d
000073dfa87d038c  rorx r8d, r9d, 0x16
000073dfa87d0392  xor r10d, r8d
000073dfa87d0395  mov [rsp+0x20], r10d
000073dfa87d039a  mov r10d, r10d
000073dfa87d039d  mov [r15+0xD0], r10
000073dfa87d03a4  lea r10d, [edx+esi*1]
000073dfa87d03a9  mov r9d, [rsp+0x10]
000073dfa87d03ae  xor r12d, r9d
000073dfa87d03b1  lea r9d, [r10d+r14d*1]
000073dfa87d03b6  lea r14, [r11+0x04]
000073dfa87d03ba  mov [r15+0x88], r14
000073dfa87d03c1  mov r11d, [rsp+0x20]
000073dfa87d03c6  lea r10d, [r12d+r11d*1]
000073dfa87d03cb  lea r11d, [r9d+eax*1]
000073dfa87d03d0  mov r11d, r11d
000073dfa87d03d3  mov [r15+0xB8], r11
000073dfa87d03da  xor eax, eax
000073dfa87d03dc  mov r12d, 0x100
000073dfa87d03e2  cmp r14, r12
000073dfa87d03e5  cmc
000073dfa87d03e6  lahf
000073dfa87d03e7  seto al
000073dfa87d03ea  mov [r15+0x108], eax
000073dfa87d03f1  lea eax, [r10d+r9d*1]
000073dfa87d03f6  mov eax, eax
000073dfa87d03f8  mov [r15+0xA8], rax
000073dfa87d03ff  mov ebp, ebp
000073dfa87d0401  mov [r15+0xB0], rbp
000073dfa87d0408  mov eax, [rsp+0x50]
000073dfa87d040c  mov eax, eax
000073dfa87d040e  mov [r15+0xC0], rax
000073dfa87d0415  mov edi, edi
000073dfa87d0417  mov [r15+0xC8], rdi
000073dfa87d041e  mov eax, [r15+0x108]
000073dfa87d0425  sahf
000073dfa87d0426  jnz 0x000073DFA87D0458
000073dfa87d0428  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0430  jz 0x000073DFA87D04A0
000073dfa87d0436  nop [rax+rax*1], ax
000073dfa87d043f  nop [rax+rax*1], eax
000073dfa87d0447  mov eax, 0x41094C
000073dfa87d044c  mov [r15+0x100], rax
000073dfa87d0453  jmp 0x000073DFA85FE110
000073dfa87d0458  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0460  jz 0x000073DFA87D0270
000073dfa87d0466  nop [rax+rax*1], ax
000073dfa87d046f  nop [rax+rax*1], eax
000073dfa87d0477  mov eax, 0x4108C0
000073dfa87d047c  mov [r15+0x100], rax
000073dfa87d0483  jmp 0x000073DFA85FE110
000073dfa87d0488  int3
000073dfa87d0489  call 0x000073DFA8649010
000073dfa87d048e  jmp 0x000073DFA87D031F
000073dfa87d0493  call 0x000073DFA8625930
000073dfa87d0498  jmp 0x000073DFA87D035C
000073dfa87d049d  int3
000073dfa87d049e  nop
000073dfa87d04a0  mov eax, [r15+0x98]
000073dfa87d04a7  mov r14d, [r15+0x70]
000073dfa87d04ab  lea r12d, [eax+r14d*1]
000073dfa87d04b0  mov eax, [r15+0x28]
000073dfa87d04b4  mov r14d, [r15+0x68]
000073dfa87d04b8  lea r11d, [eax+r14d*1]
000073dfa87d04bd  mov qword ptr [r15+0x88], 0x00
000073dfa87d04c8  mov eax, [r15+0xA8]
000073dfa87d04cf  mov r14d, [r15+0x78]
000073dfa87d04d3  lea r10d, [eax+r14d*1]
000073dfa87d04d8  mov [rsp+0x10], r10d
000073dfa87d04dd  mov r10d, r10d
000073dfa87d04e0  mov [r15+0x78], r10
000073dfa87d04e4  mov eax, [r15+0x38]
000073dfa87d04e8  mov r14d, [r15+0x80]
000073dfa87d04ef  lea r10d, [eax+r14d*1]
000073dfa87d04f4  mov [rsp+0x20], r10d
000073dfa87d04f9  mov r10d, r10d
000073dfa87d04fc  mov [r15+0x80], r10
000073dfa87d0503  mov rax, [r15]
000073dfa87d0506  lea r14, [rax+0x08]
000073dfa87d050a  mov [r13+r14*1], r12d
000073dfa87d050f  lea r14, [rax+0x0C]
000073dfa87d0513  mov [r13+r14*1], r11d
000073dfa87d0518  mov r14d, [r15+0xB8]
000073dfa87d051f  mov r12d, [r15+0x18]
000073dfa87d0523  lea r11d, [r14d+r12d*1]
000073dfa87d0528  mov [rsp+0x30], r11d
000073dfa87d052d  mov r11d, r11d
000073dfa87d0530  mov [r15+0x68], r11
000073dfa87d0534  mov r14d, [r15+0x30]
000073dfa87d0538  mov r12d, [r15+0x90]
000073dfa87d053f  lea r11d, [r14d+r12d*1]
000073dfa87d0544  mov [rsp+0x40], r11d
000073dfa87d0549  mov r11d, r11d
000073dfa87d054c  mov [r15+0x70], r11
000073dfa87d0550  mov r14d, [r15+0x20]
000073dfa87d0554  mov r12d, [r15+0x58]
000073dfa87d0558  lea r11d, [r14d+r12d*1]
000073dfa87d055d  mov [rsp+0x50], r11d
000073dfa87d0562  mov r11d, r11d
000073dfa87d0565  mov [r15+0x58], r11
000073dfa87d0569  mov r14d, [r15+0xA0]
000073dfa87d0570  mov r12d, [r15+0x60]
000073dfa87d0574  lea r11d, [r14d+r12d*1]
000073dfa87d0579  mov [rsp+0x60], r11d
000073dfa87d057e  mov r11d, r11d
000073dfa87d0581  mov [r15+0x60], r11
000073dfa87d0585  mov r14d, [rsp+0x10]
000073dfa87d058a  mov [r13+rax*1], r14d
000073dfa87d058f  lea r14, [rax+0x04]
000073dfa87d0593  mov r12d, [rsp+0x20]
000073dfa87d0598  mov [r13+r14*1], r12d
000073dfa87d059d  lea r14, [rax+0x10]
000073dfa87d05a1  mov r12d, [rsp+0x30]
000073dfa87d05a6  mov [r13+r14*1], r12d
000073dfa87d05ab  lea r14, [rax+0x14]
000073dfa87d05af  mov r12d, [rsp+0x40]
000073dfa87d05b4  mov [r13+r14*1], r12d
000073dfa87d05b9  lea r14, [rax+0x18]
000073dfa87d05bd  mov r12d, [rsp+0x50]
000073dfa87d05c2  mov [r13+r14*1], r12d
000073dfa87d05c7  lea r14, [rax+0x1C]
000073dfa87d05cb  mov r12d, [rsp+0x60]
000073dfa87d05d0  mov [r13+r14*1], r12d
000073dfa87d05d5  lea r14, [rax+0x68]
000073dfa87d05d9  xor eax, eax
000073dfa87d05db  mov [r13+r14*1], rax
000073dfa87d05e0  cmp dword ptr [r15+0x318], 0x00
000073dfa87d05e8  jz 0x000073DFA87CF0E0
000073dfa87d05ee  nop [rax+rax*1], ax
000073dfa87d05f7  nop [rax+rax*1], eax
000073dfa87d05ff  mov eax, 0x410768
000073dfa87d0604  mov [r15+0x100], rax
000073dfa87d060b  jmp 0x000073DFA85FE110
000073dfa87d0610  int3
000073dfa87d0611  call 0x000073DFA86E2BA0
000073dfa87d0616  jmp 0x000073DFA87D050F
000073dfa87d061b  call 0x000073DFA86E1920
000073dfa87d0620  jmp 0x000073DFA87D0518
000073dfa87d0625  call 0x000073DFA860DFE0
000073dfa87d062a  jmp 0x000073DFA87D058F
000073dfa87d062f  call 0x000073DFA86E2BA0
000073dfa87d0634  jmp 0x000073DFA87D059D
000073dfa87d0639  call 0x000073DFA86E2BA0
000073dfa87d063e  jmp 0x000073DFA87D05AB
000073dfa87d0643  call 0x000073DFA86E2BA0
000073dfa87d0648  jmp 0x000073DFA87D05B9
000073dfa87d064d  call 0x000073DFA86E2BA0
000073dfa87d0652  jmp 0x000073DFA87D05C7
000073dfa87d0657  call 0x000073DFA86E2BA0
000073dfa87d065c  jmp 0x000073DFA87D05D5
000073dfa87d0661  call 0x000073DFA86D5EB0
000073dfa87d0666  jmp 0x000073DFA87D05E0
000073dfa87d066b  int3
000073dfa87d066c  nop [rax], eax
000073dfa87d0670  mov rax, [r15+0xF8]
000073dfa87d0677  lea r14, [rax+0x140]
000073dfa87d067e  mov r12, [r13+r14*1]
000073dfa87d0683  lea r14, [rax+0x148]
000073dfa87d068a  mov r11, [r13+r14*1]
000073dfa87d068f  mov [r15+0xA0], r12
000073dfa87d0696  mov [r15+0x98], r11
000073dfa87d069d  lea r14, [rax+0x130]
000073dfa87d06a4  mov r12, [r13+r14*1]
000073dfa87d06a9  lea r14, [rax+0x138]
000073dfa87d06b0  mov r11, [r13+r14*1]
000073dfa87d06b5  mov [r15+0xB0], r12
000073dfa87d06bc  mov [r15+0xA8], r11
000073dfa87d06c3  lea r14, [rax+0x120]
000073dfa87d06ca  mov r12, [r13+r14*1]
000073dfa87d06cf  lea r14, [rax+0x128]
000073dfa87d06d6  mov r11, [r13+r14*1]
000073dfa87d06db  mov [r15+0xC0], r12
000073dfa87d06e2  mov [r15+0xB8], r11
000073dfa87d06e9  lea r14, [rax+0x110]
000073dfa87d06f0  mov r12, [r13+r14*1]
000073dfa87d06f5  lea r14, [rax+0x118]
000073dfa87d06fc  mov r11, [r13+r14*1]
000073dfa87d0701  mov [r15+0xD0], r12
000073dfa87d0708  mov [r15+0xC8], r11
000073dfa87d070f  lea r14, [rax+0x100]
000073dfa87d0716  mov r12, [r13+r14*1]
000073dfa87d071b  lea r14, [rax+0x108]
000073dfa87d0722  mov r11, [r13+r14*1]
000073dfa87d0727  mov [r15+0xE8], r12
000073dfa87d072e  mov [r15+0xD8], r11
000073dfa87d0735  lea r14, [rax+0x150]
000073dfa87d073c  mov [r15+0xF8], r14
000073dfa87d0743  mov rax, [r15+0xF0]
000073dfa87d074a  mov [r15+0x100], rax
000073dfa87d0751  jmp 0x000073DFA87CE5C0
000073dfa87d0756  int3
000073dfa87d0757  call 0x000073DFA86E27E0
000073dfa87d075c  jmp 0x000073DFA87D0683
000073dfa87d0761  call 0x000073DFA86E1570
000073dfa87d0766  jmp 0x000073DFA87D068F
000073dfa87d076b  call 0x000073DFA86E27E0
000073dfa87d0770  jmp 0x000073DFA87D06A9
000073dfa87d0775  call 0x000073DFA86E1570
000073dfa87d077a  jmp 0x000073DFA87D06B5
000073dfa87d077f  call 0x000073DFA86E27E0
000073dfa87d0784  jmp 0x000073DFA87D06CF
000073dfa87d0789  call 0x000073DFA86E1570
000073dfa87d078e  jmp 0x000073DFA87D06DB
000073dfa87d0793  call 0x000073DFA86E27E0
000073dfa87d0798  jmp 0x000073DFA87D06F5
000073dfa87d079d  call 0x000073DFA86E1570
000073dfa87d07a2  jmp 0x000073DFA87D0701
000073dfa87d07a7  call 0x000073DFA86E27E0
000073dfa87d07ac  jmp 0x000073DFA87D071B
000073dfa87d07b1  call 0x000073DFA86E1570
000073dfa87d07b6  jmp 0x000073DFA87D0727
000073dfa87d07bb  int3
000073dfa87d07bc  nop [rax], eax
000073dfa87d07c0  mov eax, [r15+0xA0]
000073dfa87d07c7  mov [rsp+0x10], eax
000073dfa87d07cb  xor eax, eax
000073dfa87d07cd  mov r14d, [rsp+0x10]
000073dfa87d07d2  sub r14d, 0x01
000073dfa87d07d6  cmc
000073dfa87d07d7  lahf
000073dfa87d07d8  seto al
000073dfa87d07db  mov [r15+0x108], eax
000073dfa87d07e2  mov r14d, r14d
000073dfa87d07e5  mov [r15+0xA0], r14
000073dfa87d07ec  mov eax, [r15+0x108]
000073dfa87d07f3  sahf
000073dfa87d07f4  jnz 0x000073DFA87D0826
000073dfa87d07f6  cmp dword ptr [r15+0x318], 0x00
000073dfa87d07fe  jz 0x000073DFA87D0900
000073dfa87d0804  nop [rax+rax*1], ax
000073dfa87d080d  nop [rax+rax*1], eax
000073dfa87d0815  mov eax, 0x41028C
000073dfa87d081a  mov [r15+0x100], rax
000073dfa87d0821  jmp 0x000073DFA85FE110
000073dfa87d0826  cmp dword ptr [r15+0x318], 0x00
000073dfa87d082e  jz 0x000073DFA87D0860
000073dfa87d0834  nop [rax+rax*1], ax
000073dfa87d083d  nop [rax+rax*1], eax
000073dfa87d0845  mov eax, 0x410274
000073dfa87d084a  mov [r15+0x100], rax
000073dfa87d0851  jmp 0x000073DFA85FE110
000073dfa87d0856  int3
000073dfa87d0857  int3
000073dfa87d0858  nop [rax+rax*1], eax
000073dfa87d0860  mov rax, [r15+0xF8]
000073dfa87d0867  lea r14, [rax+0x100]
000073dfa87d086e  mov [r15], r14
000073dfa87d0871  mov rax, [r15+0x98]
000073dfa87d0878  mov [r15+0x08], rax
000073dfa87d087c  mov qword ptr [r15+0x10], 0x12C
000073dfa87d0884  mov qword ptr [r15+0xF0], 0x410284
000073dfa87d088f  mov r14d, [r15+0x320]
000073dfa87d0896  mov eax, 0x410284
000073dfa87d089b  mov rcx, 0x73DFA87D07C0
000073dfa87d08a5  mov [r15+r14*8+0x328], rax
000073dfa87d08ad  mov [r15+r14*8+0x368], rcx
000073dfa87d08b5  add r14d, 0x01
000073dfa87d08b9  and r14d, 0x07
000073dfa87d08bd  mov [r15+0x320], r14d
000073dfa87d08c4  cmp dword ptr [r15+0x318], 0x00
000073dfa87d08cc  jz 0x000073DFA87CED70
000073dfa87d08d2  nop [rax+rax*1], ax
000073dfa87d08db  nop [rax+rax*1], eax
000073dfa87d08e3  mov eax, 0x410728
000073dfa87d08e8  mov [r15+0x100], rax
000073dfa87d08ef  jmp 0x000073DFA85FE110
000073dfa87d08f4  int3
000073dfa87d08f5  int3
000073dfa87d08f6  nop [rax+rax*1], ax
000073dfa87d08ff  nop
000073dfa87d0900  mov rax, [r15+0xF8]
000073dfa87d0907  lea r14, [rax+0x120]
000073dfa87d090e  mov r12, [r13+r14*1]
000073dfa87d0913  mov [r15+0x98], r12
000073dfa87d091a  mov qword ptr [r15+0x40], 0x80
000073dfa87d0922  lea r14, [rax+0x100]
000073dfa87d0929  mov [r15], r14
000073dfa87d092c  lea r14, [rax+0x17C]
000073dfa87d0933  mov [r15+0x08], r14
000073dfa87d0937  mov qword ptr [r15+0x10], 0x01
000073dfa87d093f  lea r14, [rax+0x17C]
000073dfa87d0946  mov eax, 0x80
000073dfa87d094b  mov [r13+r14*1], al
000073dfa87d0950  mov qword ptr [r15+0xF0], 0x4102A8
000073dfa87d095b  mov r14d, [r15+0x320]
000073dfa87d0962  mov eax, 0x4102A8
000073dfa87d0967  mov rcx, 0x73DFA87D09E0
000073dfa87d0971  mov [r15+r14*8+0x328], rax
000073dfa87d0979  mov [r15+r14*8+0x368], rcx
000073dfa87d0981  add r14d, 0x01
000073dfa87d0985  and r14d, 0x07
000073dfa87d0989  mov [r15+0x320], r14d
000073dfa87d0990  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0998  jz 0x000073DFA87CED70
000073dfa87d099e  nop [rax+rax*1], ax
000073dfa87d09a7  nop [rax+rax*1], eax
000073dfa87d09af  mov eax, 0x410728
000073dfa87d09b4  mov [r15+0x100], rax
000073dfa87d09bb  jmp 0x000073DFA85FE110
000073dfa87d09c0  int3
000073dfa87d09c1  call 0x000073DFA86E27E0
000073dfa87d09c6  jmp 0x000073DFA87D0913
000073dfa87d09cb  call 0x000073DFA86D5AF0
000073dfa87d09d0  jmp 0x000073DFA87D0950
000073dfa87d09d5  int3
000073dfa87d09d6  nop [rax+rax*1], ax
000073dfa87d09df  nop
000073dfa87d09e0  mov rax, [r15+0xF8]
000073dfa87d09e7  lea r14, [rax+0x168]
000073dfa87d09ee  mov r12, [r13+r14*1]
000073dfa87d09f3  mov [r15+0x40], r12
000073dfa87d09f7  lea r14, [rax+0x178]
000073dfa87d09fe  xor eax, eax
000073dfa87d0a00  mov [r13+r14*1], al
000073dfa87d0a05  xor eax, eax
000073dfa87d0a07  mov r14d, 0x38
000073dfa87d0a0d  cmp r12, r14
000073dfa87d0a10  cmc
000073dfa87d0a11  lahf
000073dfa87d0a12  seto al
000073dfa87d0a15  mov [r15+0x108], eax
000073dfa87d0a1c  mov eax, [r15+0x108]
000073dfa87d0a23  sahf
000073dfa87d0a24  jz 0x000073DFA87D0A56
000073dfa87d0a26  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0a2e  jz 0x000073DFA87D0AA0
000073dfa87d0a34  nop [rax+rax*1], ax
000073dfa87d0a3d  nop [rax+rax*1], eax
000073dfa87d0a45  mov eax, 0x4102B8
000073dfa87d0a4a  mov [r15+0x100], rax
000073dfa87d0a51  jmp 0x000073DFA85FE110
000073dfa87d0a56  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0a5e  jz 0x000073DFA87D0BF0
000073dfa87d0a64  nop [rax+rax*1], ax
000073dfa87d0a6d  nop [rax+rax*1], eax
000073dfa87d0a75  mov eax, 0x4102D4
000073dfa87d0a7a  mov [r15+0x100], rax
000073dfa87d0a81  jmp 0x000073DFA85FE110
000073dfa87d0a86  int3
000073dfa87d0a87  call 0x000073DFA86E27E0
000073dfa87d0a8c  jmp 0x000073DFA87D09F3
000073dfa87d0a91  call 0x000073DFA86D5AF0
000073dfa87d0a96  jmp 0x000073DFA87D0A05
000073dfa87d0a9b  int3
000073dfa87d0a9c  nop [rax], eax
000073dfa87d0aa0  mov rax, [r15+0xF8]
000073dfa87d0aa7  lea r14, [rax+0x100]
000073dfa87d0aae  mov [r15], r14
000073dfa87d0ab1  lea r14, [rax+0x178]
000073dfa87d0ab8  mov [r15+0x08], r14
000073dfa87d0abc  mov qword ptr [r15+0x10], 0x01
000073dfa87d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000073dfa87d0acf  mov r14d, [r15+0x320]
000073dfa87d0ad6  mov eax, 0x4102C8
000073dfa87d0adb  mov rcx, 0x73DFA87D0B40
000073dfa87d0ae5  mov [r15+r14*8+0x328], rax
000073dfa87d0aed  mov [r15+r14*8+0x368], rcx
000073dfa87d0af5  add r14d, 0x01
000073dfa87d0af9  and r14d, 0x07
000073dfa87d0afd  mov [r15+0x320], r14d
000073dfa87d0b04  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0b0c  jz 0x000073DFA87CED70
000073dfa87d0b12  nop [rax+rax*1], ax
000073dfa87d0b1b  nop [rax+rax*1], eax
000073dfa87d0b23  mov eax, 0x410728
000073dfa87d0b28  mov [r15+0x100], rax
000073dfa87d0b2f  jmp 0x000073DFA85FE110
000073dfa87d0b34  int3
000073dfa87d0b35  int3
000073dfa87d0b36  nop [rax+rax*1], ax
000073dfa87d0b3f  nop
000073dfa87d0b40  mov rax, [r15+0xF8]
000073dfa87d0b47  lea r14, [rax+0x168]
000073dfa87d0b4e  mov rax, [r13+r14*1]
000073dfa87d0b53  mov [r15+0x40], rax
000073dfa87d0b57  mov [rsp+0x10], rax
000073dfa87d0b5c  xor eax, eax
000073dfa87d0b5e  mov r14, [rsp+0x10]
000073dfa87d0b63  mov r12d, 0x38
000073dfa87d0b69  cmp r14, r12
000073dfa87d0b6c  cmc
000073dfa87d0b6d  lahf
000073dfa87d0b6e  seto al
000073dfa87d0b71  mov [r15+0x108], eax
000073dfa87d0b78  mov eax, [r15+0x108]
000073dfa87d0b7f  sahf
000073dfa87d0b80  jnz 0x000073DFA87D0BB2
000073dfa87d0b82  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0b8a  jz 0x000073DFA87D0BF0
000073dfa87d0b90  nop [rax+rax*1], ax
000073dfa87d0b99  nop [rax+rax*1], eax
000073dfa87d0ba1  mov eax, 0x4102D4
000073dfa87d0ba6  mov [r15+0x100], rax
000073dfa87d0bad  jmp 0x000073DFA85FE110
000073dfa87d0bb2  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0bba  jz 0x000073DFA87D0AA0
000073dfa87d0bc0  nop [rax+rax*1], ax
000073dfa87d0bc9  nop [rax+rax*1], eax
000073dfa87d0bd1  mov eax, 0x4102B8
000073dfa87d0bd6  mov [r15+0x100], rax
000073dfa87d0bdd  jmp 0x000073DFA85FE110
000073dfa87d0be2  int3
000073dfa87d0be3  call 0x000073DFA86D59C0
000073dfa87d0be8  jmp 0x000073DFA87D0B53
000073dfa87d0bed  int3
000073dfa87d0bee  nop
000073dfa87d0bf0  mov rax, [r15+0x98]
000073dfa87d0bf7  rorx r14, rax, 0x3D
000073dfa87d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000073dfa87d0c01  mov rax, [r15+0xF8]
000073dfa87d0c08  lea r12, [rax+0x100]
000073dfa87d0c0f  mov [r15], r12
000073dfa87d0c12  lea r12, [rax+0x170]
000073dfa87d0c19  mov [r15+0x08], r12
000073dfa87d0c1d  mov qword ptr [r15+0x10], 0x08
000073dfa87d0c25  bswap r14
000073dfa87d0c28  mov [r15+0x40], r14
000073dfa87d0c2c  lea r12, [rax+0x170]
000073dfa87d0c33  mov [r13+r12*1], r14
000073dfa87d0c38  mov qword ptr [r15+0xF0], 0x4102F0
000073dfa87d0c43  mov r14d, [r15+0x320]
000073dfa87d0c4a  mov eax, 0x4102F0
000073dfa87d0c4f  mov rcx, 0x73DFA87D0CC0
000073dfa87d0c59  mov [r15+r14*8+0x328], rax
000073dfa87d0c61  mov [r15+r14*8+0x368], rcx
000073dfa87d0c69  add r14d, 0x01
000073dfa87d0c6d  and r14d, 0x07
000073dfa87d0c71  mov [r15+0x320], r14d
000073dfa87d0c78  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0c80  jz 0x000073DFA87CED70
000073dfa87d0c86  nop [rax+rax*1], ax
000073dfa87d0c8f  nop [rax+rax*1], eax
000073dfa87d0c97  mov eax, 0x410728
000073dfa87d0c9c  mov [r15+0x100], rax
000073dfa87d0ca3  jmp 0x000073DFA85FE110
000073dfa87d0ca8  int3
000073dfa87d0ca9  call 0x000073DFA86C3FE0
000073dfa87d0cae  jmp 0x000073DFA87D0C38
000073dfa87d0cb3  int3
000073dfa87d0cb4  nop [rax+rax*1], ax
000073dfa87d0cbd  nop [rax], eax
000073dfa87d0cc0  mov rax, [r15+0xF8]
000073dfa87d0cc7  lea r14, [rax+0x100]
000073dfa87d0cce  mov r12d, [r13+r14*1]
000073dfa87d0cd3  lea r14, [rax+0x104]
000073dfa87d0cda  mov r11d, [r13+r14*1]
000073dfa87d0cdf  mov qword ptr [r15+0x48], 0x430C90
000073dfa87d0ce7  lea r14, [rax+0x108]
000073dfa87d0cee  mov r10d, [r13+r14*1]
000073dfa87d0cf3  lea r14, [rax+0x10C]
000073dfa87d0cfa  mov r9d, [r13+r14*1]
000073dfa87d0cff  bswap r12d
000073dfa87d0d02  bswap r11d
000073dfa87d0d05  mov qword ptr [r15+0xA0], 0x00
000073dfa87d0d10  mov r14d, 0x430C90
000073dfa87d0d16  mov [r13+r14*1], r12d
000073dfa87d0d1b  mov r14d, 0x430C94
000073dfa87d0d21  mov [r13+r14*1], r11d
000073dfa87d0d26  bswap r10d
000073dfa87d0d29  lea r14, [rax+0x110]
000073dfa87d0d30  mov r12d, [r13+r14*1]
000073dfa87d0d35  bswap r9d
000073dfa87d0d38  lea r14, [rax+0x114]
000073dfa87d0d3f  mov r11d, [r13+r14*1]
000073dfa87d0d44  mov qword ptr [r15+0x98], 0x430DFC
000073dfa87d0d4f  mov r14d, 0x430C98
000073dfa87d0d55  mov [r13+r14*1], r10d
000073dfa87d0d5a  mov r14d, 0x430C9C
000073dfa87d0d60  mov [r13+r14*1], r9d
000073dfa87d0d65  bswap r12d
000073dfa87d0d68  lea r14, [rax+0x118]
000073dfa87d0d6f  mov r10d, [r13+r14*1]
000073dfa87d0d74  bswap r11d
000073dfa87d0d77  mov [rsp+0x10], r11d
000073dfa87d0d7c  mov r11d, r11d
000073dfa87d0d7f  mov [r15+0x58], r11
000073dfa87d0d83  lea r14, [rax+0x11C]
000073dfa87d0d8a  mov eax, [r13+r14*1]
000073dfa87d0d8f  mov [rsp+0x20], eax
000073dfa87d0d93  mov eax, eax
000073dfa87d0d95  mov [r15+0x60], rax
000073dfa87d0d99  mov eax, 0x430CA0
000073dfa87d0d9e  mov [r13+rax*1], r12d
000073dfa87d0da3  mov eax, 0x430CA4
000073dfa87d0da8  mov r14d, [rsp+0x10]
000073dfa87d0dad  mov [r13+rax*1], r14d
000073dfa87d0db2  bswap r10d
000073dfa87d0db5  mov [rsp+0x10], r10d
000073dfa87d0dba  mov r10d, r10d
000073dfa87d0dbd  mov [r15+0x40], r10
000073dfa87d0dc1  mov eax, [rsp+0x20]
000073dfa87d0dc5  bswap eax
000073dfa87d0dc7  mov [rsp+0x20], eax
000073dfa87d0dcb  mov eax, eax
000073dfa87d0dcd  mov [r15+0x50], rax
000073dfa87d0dd1  mov eax, 0x430CA8
000073dfa87d0dd6  mov r14d, [rsp+0x10]
000073dfa87d0ddb  mov [r13+rax*1], r14d
000073dfa87d0de0  mov eax, 0x430CAC
000073dfa87d0de5  mov r14d, [rsp+0x20]
000073dfa87d0dea  mov [r13+rax*1], r14d
000073dfa87d0def  mov eax, [r15+0xA0]
000073dfa87d0df6  lea r14d, [eax+0x11]
000073dfa87d0dfb  mov r14d, r14d
000073dfa87d0dfe  mov [r15], r14
000073dfa87d0e01  mov qword ptr [r15+0xF0], 0x41035C
000073dfa87d0e0c  mov r14d, [r15+0x320]
000073dfa87d0e13  mov eax, 0x41035C
000073dfa87d0e18  mov rcx, 0x73DFA87D0F90
000073dfa87d0e22  mov [r15+r14*8+0x328], rax
000073dfa87d0e2a  mov [r15+r14*8+0x368], rcx
000073dfa87d0e32  add r14d, 0x01
000073dfa87d0e36  and r14d, 0x07
000073dfa87d0e3a  mov [r15+0x320], r14d
000073dfa87d0e41  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0e49  jz 0x000073DFA87D0F20
000073dfa87d0e4f  nop [rax+rax*1], ax
000073dfa87d0e58  nop [rax+rax*1], eax
000073dfa87d0e60  mov eax, 0x4109A4
000073dfa87d0e65  mov [r15+0x100], rax
000073dfa87d0e6c  jmp 0x000073DFA85FE110
000073dfa87d0e71  int3
000073dfa87d0e72  call 0x000073DFA86E26A0
000073dfa87d0e77  jmp 0x000073DFA87D0CD3
000073dfa87d0e7c  call 0x000073DFA86E1430
000073dfa87d0e81  jmp 0x000073DFA87D0CDF
000073dfa87d0e86  call 0x000073DFA86E01C0
000073dfa87d0e8b  jmp 0x000073DFA87D0CF3
000073dfa87d0e90  call 0x000073DFA86DEF50
000073dfa87d0e95  jmp 0x000073DFA87D0CFF
000073dfa87d0e9a  call 0x000073DFA86E2BA0
000073dfa87d0e9f  jmp 0x000073DFA87D0D1B
000073dfa87d0ea4  call 0x000073DFA86E1920
000073dfa87d0ea9  jmp 0x000073DFA87D0D26
000073dfa87d0eae  call 0x000073DFA86E26A0
000073dfa87d0eb3  jmp 0x000073DFA87D0D35
000073dfa87d0eb8  call 0x000073DFA86E1430
000073dfa87d0ebd  jmp 0x000073DFA87D0D44
000073dfa87d0ec2  call 0x000073DFA86E06B0
000073dfa87d0ec7  jmp 0x000073DFA87D0D5A
000073dfa87d0ecc  call 0x000073DFA86DF440
000073dfa87d0ed1  jmp 0x000073DFA87D0D65
000073dfa87d0ed6  call 0x000073DFA86E01C0
000073dfa87d0edb  jmp 0x000073DFA87D0D74
000073dfa87d0ee0  call 0x000073DFA86D5890
000073dfa87d0ee5  jmp 0x000073DFA87D0D8F
000073dfa87d0eea  call 0x000073DFA860BAE0
000073dfa87d0eef  jmp 0x000073DFA87D0DA3
000073dfa87d0ef4  call 0x000073DFA860DFE0
000073dfa87d0ef9  jmp 0x000073DFA87D0DB2
000073dfa87d0efe  call 0x000073DFA860DFE0
000073dfa87d0f03  jmp 0x000073DFA87D0DE0
000073dfa87d0f08  call 0x000073DFA860DFE0
000073dfa87d0f0d  jmp 0x000073DFA87D0DEF
000073dfa87d0f12  int3
000073dfa87d0f13  nop [rax+rax*1], ax
000073dfa87d0f1c  nop [rax], eax
000073dfa87d0f20  mov eax, [r15]
000073dfa87d0f23  mov [rsp+0x10], eax
000073dfa87d0f27  shr eax, 0x10
000073dfa87d0f2a  mov r14d, [rsp+0x10]
000073dfa87d0f2f  xor r14d, eax
000073dfa87d0f32  imul r14d, r14d, 0x7FEB352D
000073dfa87d0f39  mov eax, 0x846CA68B
000073dfa87d0f3e  mov eax, eax
000073dfa87d0f40  mov [r15+0x48], rax
000073dfa87d0f44  mov [rsp+0x10], r14d
000073dfa87d0f49  shr r14d, 0x0F
000073dfa87d0f4d  mov eax, [rsp+0x10]
000073dfa87d0f51  xor eax, r14d
000073dfa87d0f54  imul eax, eax, 0x846CA68B
000073dfa87d0f5a  mov [rsp+0x10], eax
000073dfa87d0f5e  mov eax, eax
000073dfa87d0f60  mov [r15+0x40], rax
000073dfa87d0f64  mov eax, [rsp+0x10]
000073dfa87d0f68  shr eax, 0x10
000073dfa87d0f6b  mov r14d, [rsp+0x10]
000073dfa87d0f70  xor r14d, eax
000073dfa87d0f73  mov r14d, r14d
000073dfa87d0f76  mov [r15], r14
000073dfa87d0f79  mov rax, [r15+0xF0]
000073dfa87d0f80  mov [r15+0x100], rax
000073dfa87d0f87  jmp 0x000073DFA87CE5C0
000073dfa87d0f8c  int3
000073dfa87d0f8d  int3
000073dfa87d0f8e  nop
000073dfa87d0f90  mov rax, [r15+0xA0]
000073dfa87d0f97  mov [rsp+0x10], rax
000073dfa87d0f9c  shl rax, 0x02
000073dfa87d0fa0  mov r14, [r15+0x98]
000073dfa87d0fa7  lea r12, [r14+rax*1]
000073dfa87d0fab  mov eax, [r15]
000073dfa87d0fae  mov [r13+r12*1], eax
000073dfa87d0fb3  mov rax, [rsp+0x10]
000073dfa87d0fb8  lea r14, [rax+0x01]
000073dfa87d0fbc  mov [r15+0xA0], r14
000073dfa87d0fc3  xor eax, eax
000073dfa87d0fc5  mov r12d, 0x400
000073dfa87d0fcb  cmp r14, r12
000073dfa87d0fce  cmc
000073dfa87d0fcf  lahf
000073dfa87d0fd0  seto al
000073dfa87d0fd3  mov [r15+0x108], eax
000073dfa87d0fda  mov eax, [r15+0x108]
000073dfa87d0fe1  sahf
000073dfa87d0fe2  jnz 0x000073DFA87D1014
000073dfa87d0fe4  cmp dword ptr [r15+0x318], 0x00
000073dfa87d0fec  jz 0x000073DFA87D10E0
000073dfa87d0ff2  nop [rax+rax*1], ax
000073dfa87d0ffb  nop [rax+rax*1], eax
000073dfa87d1003  mov eax, 0x41036C
000073dfa87d1008  mov [r15+0x100], rax
000073dfa87d100f  jmp 0x000073DFA85FE110
000073dfa87d1014  cmp dword ptr [r15+0x318], 0x00
000073dfa87d101c  jz 0x000073DFA87D1050
000073dfa87d1022  nop [rax+rax*1], ax
000073dfa87d102b  nop [rax+rax*1], eax
000073dfa87d1033  mov eax, 0x410354
000073dfa87d1038  mov [r15+0x100], rax
000073dfa87d103f  jmp 0x000073DFA85FE110
000073dfa87d1044  int3
000073dfa87d1045  call 0x000073DFA86B4B70
000073dfa87d104a  jmp 0x000073DFA87D0FB3
000073dfa87d104f  int3
000073dfa87d1050  mov eax, [r15+0xA0]
000073dfa87d1057  lea r14d, [eax+0x11]
000073dfa87d105c  mov r14d, r14d
000073dfa87d105f  mov [r15], r14
000073dfa87d1062  mov qword ptr [r15+0xF0], 0x41035C
000073dfa87d106d  mov r14d, [r15+0x320]
000073dfa87d1074  mov eax, 0x41035C
000073dfa87d1079  mov rcx, 0x73DFA87D0F90
000073dfa87d1083  mov [r15+r14*8+0x328], rax
000073dfa87d108b  mov [r15+r14*8+0x368], rcx
000073dfa87d1093  add r14d, 0x01
000073dfa87d1097  and r14d, 0x07
000073dfa87d109b  mov [r15+0x320], r14d
000073dfa87d10a2  cmp dword ptr [r15+0x318], 0x00
000073dfa87d10aa  jz 0x000073DFA87D0F20
000073dfa87d10b0  nop [rax+rax*1], ax
000073dfa87d10b9  nop [rax+rax*1], eax
000073dfa87d10c1  mov eax, 0x4109A4
000073dfa87d10c6  mov [r15+0x100], rax
000073dfa87d10cd  jmp 0x000073DFA85FE110
000073dfa87d10d2  int3
000073dfa87d10d3  int3
000073dfa87d10d4  nop [rax+rax*1], ax
000073dfa87d10dd  nop [rax], eax
000073dfa87d10e0  mov qword ptr [r15+0x40], 0x01
000073dfa87d10e8  cmp dword ptr [r15+0x318], 0x00
000073dfa87d10f0  jz 0x000073DFA87D1120
000073dfa87d10f6  nop [rax+rax*1], ax
000073dfa87d10ff  nop [rax+rax*1], eax
000073dfa87d1107  mov eax, 0x410388
000073dfa87d110c  mov [r15+0x100], rax
000073dfa87d1113  jmp 0x000073DFA85FE110
000073dfa87d1118  int3
000073dfa87d1119  int3
000073dfa87d111a  nop [rax+rax*1], ax
000073dfa87d1120  mov rax, [r15+0x40]
000073dfa87d1124  mov [rsp+0x10], rax
000073dfa87d1129  shl rax, 0x02
000073dfa87d112d  mov r14, [r15+0x98]
000073dfa87d1134  lea r12, [r14+rax*1]
000073dfa87d1138  mov eax, [r13+r12*1]
000073dfa87d113d  mov [rsp+0x20], eax
000073dfa87d1141  mov eax, eax
000073dfa87d1143  mov [r15+0x48], rax
000073dfa87d1147  mov rax, [rsp+0x10]
000073dfa87d114c  mov [r15+0x50], rax
000073dfa87d1150  mov eax, [r15+0x50]
000073dfa87d1154  lea r12d, [eax-0x01]
000073dfa87d1159  mov r12d, r12d
000073dfa87d115c  mov [r15+0x58], r12
000073dfa87d1160  mov rax, [r15+0x58]
000073dfa87d1164  mov r12d, eax
000073dfa87d1167  mov r12d, r12d
000073dfa87d116a  shl r12, 0x02
000073dfa87d116e  lea rax, [r14+r12*1]
000073dfa87d1172  mov r14d, [r13+rax*1]
000073dfa87d1177  mov [rsp+0x10], r14d
000073dfa87d117c  mov r14d, r14d
000073dfa87d117f  mov [r15+0x60], r14
000073dfa87d1183  xor eax, eax
000073dfa87d1185  mov r14d, [rsp+0x10]
000073dfa87d118a  mov r12d, [rsp+0x20]
000073dfa87d118f  cmp r14d, r12d
000073dfa87d1192  cmc
000073dfa87d1193  lahf
000073dfa87d1194  seto al
000073dfa87d1197  mov [r15+0x108], eax
000073dfa87d119e  mov eax, [r15+0x108]
000073dfa87d11a5  sahf
000073dfa87d11a6  cmc
000073dfa87d11a7  jbe 0x000073DFA87D11D9
000073dfa87d11a9  cmp dword ptr [r15+0x318], 0x00
000073dfa87d11b1  jz 0x000073DFA87D1220
000073dfa87d11b7  nop [rax+rax*1], ax
000073dfa87d11c0  nop [rax+rax*1], eax
000073dfa87d11c8  mov eax, 0x4103A0
000073dfa87d11cd  mov [r15+0x100], rax
000073dfa87d11d4  jmp 0x000073DFA85FE110
000073dfa87d11d9  cmp dword ptr [r15+0x318], 0x00
000073dfa87d11e1  jz 0x000073DFA87D14C0
000073dfa87d11e7  nop [rax+rax*1], ax
000073dfa87d11f0  nop [rax+rax*1], eax
000073dfa87d11f8  mov eax, 0x410378
000073dfa87d11fd  mov [r15+0x100], rax
000073dfa87d1204  jmp 0x000073DFA85FE110
000073dfa87d1209  int3
000073dfa87d120a  call 0x000073DFA86B4690
000073dfa87d120f  jmp 0x000073DFA87D113D
000073dfa87d1214  call 0x000073DFA860DAE0
000073dfa87d1219  jmp 0x000073DFA87D1177
000073dfa87d121e  int3
000073dfa87d121f  nop
000073dfa87d1220  mov rax, [r15+0x50]
000073dfa87d1224  mov [rsp+0x10], rax
000073dfa87d1229  shl rax, 0x02
000073dfa87d122d  mov r14, [r15+0x98]
000073dfa87d1234  lea r12, [r14+rax*1]
000073dfa87d1238  mov eax, [r15+0x60]
000073dfa87d123c  mov [r13+r12*1], eax
000073dfa87d1241  mov rax, [rsp+0x10]
000073dfa87d1246  lea r14, [rax-0x01]
000073dfa87d124a  mov [r15+0x50], r14
000073dfa87d124e  mov rax, [r15+0x58]
000073dfa87d1252  test rax, rax
000073dfa87d1255  setz al
000073dfa87d1258  movzx rax, al
000073dfa87d125c  mov [rsp+0x414], al
000073dfa87d1263  cmp byte ptr [rsp+0x414], 0x00
000073dfa87d126b  jz 0x000073DFA87D129D
000073dfa87d126d  cmp dword ptr [r15+0x318], 0x00
000073dfa87d1275  jz 0x000073DFA87D12E0
000073dfa87d127b  nop [rax+rax*1], ax
000073dfa87d1284  nop [rax+rax*1], eax
000073dfa87d128c  mov eax, 0x4103AC
000073dfa87d1291  mov [r15+0x100], rax
000073dfa87d1298  jmp 0x000073DFA85FE110
000073dfa87d129d  cmp dword ptr [r15+0x318], 0x00
000073dfa87d12a5  jz 0x000073DFA87D13E0
000073dfa87d12ab  nop [rax+rax*1], ax
000073dfa87d12b4  nop [rax+rax*1], eax
000073dfa87d12bc  mov eax, 0x410390
000073dfa87d12c1  mov [r15+0x100], rax
000073dfa87d12c8  jmp 0x000073DFA85FE110
000073dfa87d12cd  int3
000073dfa87d12ce  call 0x000073DFA86B4B70
000073dfa87d12d3  jmp 0x000073DFA87D1241
000073dfa87d12d8  int3
000073dfa87d12d9  nop [rax], eax
000073dfa87d12e0  cmp dword ptr [r15+0x318], 0x00
000073dfa87d12e8  jz 0x000073DFA87D1320
000073dfa87d12ee  nop [rax+rax*1], ax
000073dfa87d12f7  nop [rax+rax*1], eax
000073dfa87d12ff  mov eax, 0x410374
000073dfa87d1304  mov [r15+0x100], rax
000073dfa87d130b  jmp 0x000073DFA85FE110
000073dfa87d1310  int3
000073dfa87d1311  int3
000073dfa87d1312  nop [rax+rax*1], ax
000073dfa87d131b  nop [rax+rax*1], eax
000073dfa87d1320  mov qword ptr [r15+0x50], 0x00
000073dfa87d1328  mov rax, [r15+0x40]
000073dfa87d132c  lea r14, [rax+0x01]
000073dfa87d1330  mov [r15+0x40], r14
000073dfa87d1334  mov rax, [r15+0x98]
000073dfa87d133b  mov r12d, [r15+0x48]
000073dfa87d133f  mov [r13+rax*1], r12d
000073dfa87d1344  xor eax, eax
000073dfa87d1346  mov r12d, 0x400
000073dfa87d134c  cmp r14, r12
000073dfa87d134f  cmc
000073dfa87d1350  lahf
000073dfa87d1351  seto al
000073dfa87d1354  mov [r15+0x108], eax
000073dfa87d135b  mov eax, [r15+0x108]
000073dfa87d1362  sahf
000073dfa87d1363  jz 0x000073DFA87D1395
000073dfa87d1365  cmp dword ptr [r15+0x318], 0x00
000073dfa87d136d  jz 0x000073DFA87D1120
000073dfa87d1373  nop [rax+rax*1], ax
000073dfa87d137c  nop [rax+rax*1], eax
000073dfa87d1384  mov eax, 0x410388
000073dfa87d1389  mov [r15+0x100], rax
000073dfa87d1390  jmp 0x000073DFA85FE110
000073dfa87d1395  cmp dword ptr [r15+0x318], 0x00
000073dfa87d139d  jz 0x000073DFA87D1580
000073dfa87d13a3  nop [rax+rax*1], ax
000073dfa87d13ac  nop [rax+rax*1], eax
000073dfa87d13b4  mov eax, 0x4103B0
000073dfa87d13b9  mov [r15+0x100], rax
000073dfa87d13c0  jmp 0x000073DFA85FE110
000073dfa87d13c5  int3
000073dfa87d13c6  call 0x000073DFA860BAE0
000073dfa87d13cb  jmp 0x000073DFA87D1344
000073dfa87d13d0  int3
000073dfa87d13d1  nop [rax+rax*1], ax
000073dfa87d13da  nop [rax+rax*1], ax
000073dfa87d13e0  mov eax, [r15+0x50]
000073dfa87d13e4  lea r14d, [eax-0x01]
000073dfa87d13e9  mov r14d, r14d
000073dfa87d13ec  mov [r15+0x58], r14
000073dfa87d13f0  mov rax, [r15+0x58]
000073dfa87d13f4  mov r14d, eax
000073dfa87d13f7  mov r14d, r14d
000073dfa87d13fa  shl r14, 0x02
000073dfa87d13fe  mov rax, [r15+0x98]
000073dfa87d1405  lea r12, [rax+r14*1]
000073dfa87d1409  mov eax, [r13+r12*1]
000073dfa87d140e  mov [rsp+0x10], eax
000073dfa87d1412  mov eax, eax
000073dfa87d1414  mov [r15+0x60], rax
000073dfa87d1418  mov eax, [r15+0x48]
000073dfa87d141c  mov [rsp+0x20], eax
000073dfa87d1420  xor eax, eax
000073dfa87d1422  mov r14d, [rsp+0x10]
000073dfa87d1427  mov r12d, [rsp+0x20]
000073dfa87d142c  cmp r14d, r12d
000073dfa87d142f  cmc
000073dfa87d1430  lahf
000073dfa87d1431  seto al
000073dfa87d1434  mov [r15+0x108], eax
000073dfa87d143b  mov eax, [r15+0x108]
000073dfa87d1442  sahf
000073dfa87d1443  cmc
000073dfa87d1444  jbe 0x000073DFA87D1476
000073dfa87d1446  cmp dword ptr [r15+0x318], 0x00
000073dfa87d144e  jz 0x000073DFA87D1220
000073dfa87d1454  nop [rax+rax*1], ax
000073dfa87d145d  nop [rax+rax*1], eax
000073dfa87d1465  mov eax, 0x4103A0
000073dfa87d146a  mov [r15+0x100], rax
000073dfa87d1471  jmp 0x000073DFA85FE110
000073dfa87d1476  cmp dword ptr [r15+0x318], 0x00
000073dfa87d147e  jz 0x000073DFA87D14C0
000073dfa87d1484  nop [rax+rax*1], ax
000073dfa87d148d  nop [rax+rax*1], eax
000073dfa87d1495  mov eax, 0x410378
000073dfa87d149a  mov [r15+0x100], rax
000073dfa87d14a1  jmp 0x000073DFA85FE110
000073dfa87d14a6  int3
000073dfa87d14a7  call 0x000073DFA86B4690
000073dfa87d14ac  jmp 0x000073DFA87D140E
000073dfa87d14b1  int3
000073dfa87d14b2  nop [rax+rax*1], ax
000073dfa87d14bb  nop [rax+rax*1], eax
000073dfa87d14c0  mov rax, [r15+0x40]
000073dfa87d14c4  lea r14, [rax+0x01]
000073dfa87d14c8  mov [r15+0x40], r14
000073dfa87d14cc  mov rax, [r15+0x50]
000073dfa87d14d0  mov r12d, eax
000073dfa87d14d3  mov r12d, r12d
000073dfa87d14d6  shl r12, 0x02
000073dfa87d14da  mov rax, [r15+0x98]
000073dfa87d14e1  lea r11, [rax+r12*1]
000073dfa87d14e5  mov eax, [r15+0x48]
000073dfa87d14e9  mov [r13+r11*1], eax
000073dfa87d14ee  xor eax, eax
000073dfa87d14f0  mov r12d, 0x400
000073dfa87d14f6  cmp r14, r12
000073dfa87d14f9  cmc
000073dfa87d14fa  lahf
000073dfa87d14fb  seto al
000073dfa87d14fe  mov [r15+0x108], eax
000073dfa87d1505  mov eax, [r15+0x108]
000073dfa87d150c  sahf
000073dfa87d150d  jz 0x000073DFA87D153F
000073dfa87d150f  cmp dword ptr [r15+0x318], 0x00
000073dfa87d1517  jz 0x000073DFA87D1120
000073dfa87d151d  nop [rax+rax*1], ax
000073dfa87d1526  nop [rax+rax*1], eax
000073dfa87d152e  mov eax, 0x410388
000073dfa87d1533  mov [r15+0x100], rax
000073dfa87d153a  jmp 0x000073DFA85FE110
000073dfa87d153f  cmp dword ptr [r15+0x318], 0x00
000073dfa87d1547  jz 0x000073DFA87D1580
000073dfa87d154d  nop [rax+rax*1], ax
000073dfa87d1556  nop [rax+rax*1], eax
000073dfa87d155e  mov eax, 0x4103B0
000073dfa87d1563  mov [r15+0x100], rax
000073dfa87d156a  jmp 0x000073DFA85FE110
000073dfa87d156f  int3
000073dfa87d1570  call 0x000073DFA86A4270
000073dfa87d1575  jmp 0x000073DFA87D14EE
000073dfa87d157a  int3
000073dfa87d157b  nop [rax+rax*1], eax
000073dfa87d1580  mov qword ptr [r15+0x40], 0x430000
000073dfa87d1588  mov eax, 0x430CB0
000073dfa87d158d  mov r14, [r13+rax*1]
000073dfa87d1592  mov rax, [r15+0x98]
000073dfa87d1599  mov r12d, [r13+rax*1]
000073dfa87d159e  lea r11, [rax+0x04]
000073dfa87d15a2  mov eax, [r13+r11*1]
000073dfa87d15a7  mov r12d, r12d
000073dfa87d15aa  mov [r15+0x68], r12
000073dfa87d15ae  mov eax, eax
000073dfa87d15b0  mov [r15+0x60], rax
000073dfa87d15b4  mov rax, [r15+0x68]
000073dfa87d15b8  mov [r15+0x68], rax
000073dfa87d15bc  mov qword ptr [r15+0x58], 0x02
000073dfa87d15c4  mov [rsp+0x10], rax
000073dfa87d15c9  xor eax, eax
000073dfa87d15cb  mov r12d, 0x02
000073dfa87d15d1  mov r11d, 0x400
000073dfa87d15d7  cmp r12, r11
000073dfa87d15da  cmc
000073dfa87d15db  lahf
000073dfa87d15dc  seto al
000073dfa87d15df  mov [r15+0x108], eax
000073dfa87d15e6  mov rax, [r15+0x60]
000073dfa87d15ea  mov r12d, 0x02
000073dfa87d15f0  imul rax, r12
000073dfa87d15f4  mov [r15+0x50], rax
000073dfa87d15f8  mov rax, [rsp+0x10]
000073dfa87d15fd  lea r12, [rax+r14*1]
000073dfa87d1601  mov [r15+0x48], r12
000073dfa87d1605  mov eax, [r15+0x108]
000073dfa87d160c  sahf
000073dfa87d160d  jnz 0x000073DFA87D163F
000073dfa87d160f  cmp dword ptr [r15+0x318], 0x00
000073dfa87d1617  jz 0x000073DFA87D17B0
000073dfa87d161d  nop [rax+rax*1], ax
000073dfa87d1626  nop [rax+rax*1], eax
000073dfa87d162e  mov eax, 0x4103E0
000073dfa87d1633  mov [r15+0x100], rax
000073dfa87d163a  jmp 0x000073DFA85FE110
000073dfa87d163f  cmp dword ptr [r15+0x318], 0x00
000073dfa87d1647  jz 0x000073DFA87D1690
000073dfa87d164d  nop [rax+rax*1], ax
000073dfa87d1656  nop [rax+rax*1], eax
000073dfa87d165e  mov eax, 0x4103C0
000073dfa87d1663  mov [r15+0x100], rax
000073dfa87d166a  jmp 0x000073DFA85FE110
000073dfa87d166f  int3
000073dfa87d1670  call 0x000073DFA860DC20
000073dfa87d1675  jmp 0x000073DFA87D1592
000073dfa87d167a  call 0x000073DFA860B5E0
000073dfa87d167f  jmp 0x000073DFA87D159E
000073dfa87d1684  call 0x000073DFA86A3D90
000073dfa87d1689  jmp 0x000073DFA87D15A7
000073dfa87d168e  int3
000073dfa87d168f  nop
000073dfa87d1690  mov rax, [r15+0x98]
000073dfa87d1697  mov r14, [r15+0x58]
000073dfa87d169b  mov [rsp+0x10], r14
000073dfa87d16a0  shl r14, 0x02
000073dfa87d16a4  lea r12, [rax+r14*1]
000073dfa87d16a8  mov eax, [r13+r12*1]
000073dfa87d16ad  lea r14, [r12+0x04]
000073dfa87d16b2  mov r12d, [r13+r14*1]
000073dfa87d16b7  mov eax, eax
000073dfa87d16b9  mov [r15+0x68], rax
000073dfa87d16bd  mov r12d, r12d
000073dfa87d16c0  mov [r15+0x60], r12
000073dfa87d16c4  mov rax, [r15+0x68]
000073dfa87d16c8  mov [rsp+0x20], rax
000073dfa87d16cd  mov r14, [rsp+0x10]
000073dfa87d16d2  imul rax, r14
000073dfa87d16d6  mov r12, [rsp+0x20]
000073dfa87d16db  lea r11, [r12+rax*1]
000073dfa87d16df  mov [r15+0x68], r11
000073dfa87d16e3  lea rax, [r14+0x02]
000073dfa87d16e7  mov [r15+0x58], rax
000073dfa87d16eb  mov [rsp+0x10], rax
000073dfa87d16f0  xor eax, eax
000073dfa87d16f2  mov r14, [rsp+0x10]
000073dfa87d16f7  mov r12d, 0x400
000073dfa87d16fd  cmp r14, r12
000073dfa87d1700  cmc
000073dfa87d1701  lahf
000073dfa87d1702  seto al
000073dfa87d1705  mov [r15+0x108], eax
000073dfa87d170c  mov rax, [r15+0x50]
000073dfa87d1710  mov r12, [r15+0x60]
000073dfa87d1714  imul r14, r12
000073dfa87d1718  lea r12, [rax+r14*1]
000073dfa87d171c  mov [r15+0x50], r12
000073dfa87d1720  mov rax, [r15+0x48]
000073dfa87d1724  lea r14, [r11+rax*1]
000073dfa87d1728  mov [r15+0x48], r14
000073dfa87d172c  mov eax, [r15+0x108]
000073dfa87d1733  sahf
000073dfa87d1734  jnz 0x000073DFA87D1766
000073dfa87d1736  cmp dword ptr [r15+0x318], 0x00
000073dfa87d173e  jz 0x000073DFA87D17B0
000073dfa87d1744  nop [rax+rax*1], ax
000073dfa87d174d  nop [rax+rax*1], eax
000073dfa87d1755  mov eax, 0x4103E0
000073dfa87d175a  mov [r15+0x100], rax
000073dfa87d1761  jmp 0x000073DFA85FE110
000073dfa87d1766  cmp dword ptr [r15+0x318], 0x00
000073dfa87d176e  jz 0x000073DFA87D1690
000073dfa87d1774  nop [rax+rax*1], ax
000073dfa87d177d  nop [rax+rax*1], eax
000073dfa87d1785  mov eax, 0x4103C0
000073dfa87d178a  mov [r15+0x100], rax
000073dfa87d1791  jmp 0x000073DFA85FE110
000073dfa87d1796  int3
000073dfa87d1797  call 0x000073DFA86B4690
000073dfa87d179c  jmp 0x000073DFA87D16AD
000073dfa87d17a1  call 0x000073DFA86E26A0
000073dfa87d17a6  jmp 0x000073DFA87D16B7
000073dfa87d17ab  int3
000073dfa87d17ac  nop [rax], eax
000073dfa87d17b0  mov qword ptr [r15+0x98], 0x00
000073dfa87d17bb  mov rax, [r15+0x50]
000073dfa87d17bf  mov r14, [r15+0x48]
000073dfa87d17c3  lea r12, [rax+r14*1]
000073dfa87d17c7  mov [r15+0x48], r12
000073dfa87d17cb  mov rax, [r15+0x40]
000073dfa87d17cf  lea r14, [rax+0xCB0]
000073dfa87d17d6  mov [r13+r14*1], r12
000073dfa87d17db  mov qword ptr [r15], 0x01
000073dfa87d17e2  mov qword ptr [r15+0xF0], 0x4103F8
000073dfa87d17ed  mov r14d, [r15+0x320]
000073dfa87d17f4  mov eax, 0x4103F8
000073dfa87d17f9  mov rcx, 0x73DFA87D1860
000073dfa87d1803  mov [r15+r14*8+0x328], rax
000073dfa87d180b  mov [r15+r14*8+0x368], rcx
000073dfa87d1813  add r14d, 0x01
000073dfa87d1817  and r14d, 0x07
000073dfa87d181b  mov [r15+0x320], r14d
000073dfa87d1822  cmp dword ptr [r15+0x318], 0x00
000073dfa87d182a  jz 0x000073DFA87D0F20
000073dfa87d1830  nop [rax+rax*1], ax
000073dfa87d1839  nop [rax+rax*1], eax
000073dfa87d1841  mov eax, 0x4109A4
000073dfa87d1846  mov [r15+0x100], rax
000073dfa87d184d  jmp 0x000073DFA85FE110
000073dfa87d1852  int3
000073dfa87d1853  call 0x000073DFA86E2CE0
000073dfa87d1858  jmp 0x000073DFA87D17DB
000073dfa87d185d  int3
000073dfa87d185e  nop
000073dfa87d1860  mov eax, [r15+0x98]
000073dfa87d1867  lea r14d, [eax+0x01]
000073dfa87d186c  mov [rsp+0x10], r14d
000073dfa87d1871  mov r14d, r14d
000073dfa87d1874  mov [r15+0x98], r14
000073dfa87d187b  xor eax, eax
000073dfa87d187d  mov r14d, [rsp+0x10]
000073dfa87d1882  cmp r14d, 0x10000
000073dfa87d1889  cmc
000073dfa87d188a  lahf
000073dfa87d188b  seto al
000073dfa87d188e  mov [r15+0x108], eax
000073dfa87d1895  mov eax, [r15+0x108]
000073dfa87d189c  sahf
000073dfa87d189d  jnz 0x000073DFA87D18CF
000073dfa87d189f  cmp dword ptr [r15+0x318], 0x00
000073dfa87d18a7  jz 0x000073DFA87D19A0
000073dfa87d18ad  nop [rax+rax*1], ax
000073dfa87d18b6  nop [rax+rax*1], eax
000073dfa87d18be  mov eax, 0x410404
000073dfa87d18c3  mov [r15+0x100], rax
000073dfa87d18ca  jmp 0x000073DFA85FE110
000073dfa87d18cf  cmp dword ptr [r15+0x318], 0x00
000073dfa87d18d7  jz 0x000073DFA87D1910
000073dfa87d18dd  nop [rax+rax*1], ax
000073dfa87d18e6  nop [rax+rax*1], eax
000073dfa87d18ee  mov eax, 0x4103F0
000073dfa87d18f3  mov [r15+0x100], rax
000073dfa87d18fa  jmp 0x000073DFA85FE110
000073dfa87d18ff  int3
000073dfa87d1900  int3
000073dfa87d1901  nop [rax+rax*1], ax
000073dfa87d190a  nop [rax+rax*1], ax
000073dfa87d1910  mov eax, [r15]
000073dfa87d1913  mov r14d, [r15+0x98]
000073dfa87d191a  lea r12d, [eax+r14d*1]
000073dfa87d191f  mov r12d, r12d
000073dfa87d1922  mov [r15], r12
000073dfa87d1925  mov qword ptr [r15+0xF0], 0x4103F8
000073dfa87d1930  mov r14d, [r15+0x320]
000073dfa87d1937  mov eax, 0x4103F8
000073dfa87d193c  mov rcx, 0x73DFA87D1860
000073dfa87d1946  mov [r15+r14*8+0x328], rax
000073dfa87d194e  mov [r15+r14*8+0x368], rcx
000073dfa87d1956  add r14d, 0x01
000073dfa87d195a  and r14d, 0x07
000073dfa87d195e  mov [r15+0x320], r14d
000073dfa87d1965  cmp dword ptr [r15+0x318], 0x00
000073dfa87d196d  jz 0x000073DFA87D0F20
000073dfa87d1973  nop [rax+rax*1], ax
000073dfa87d197c  nop [rax+rax*1], eax
000073dfa87d1984  mov eax, 0x4109A4
000073dfa87d1989  mov [r15+0x100], rax
000073dfa87d1990  jmp 0x000073DFA85FE110
000073dfa87d1995  int3
000073dfa87d1996  int3
000073dfa87d1997  nop [rax+rax*1], ax
000073dfa87d19a0  vmovaps xmm1, [0x000073DFA83FE010]
000073dfa87d19a8  movq xmm1, xmm1
000073dfa87d19ac  movaps [r15+0x110], xmm1
000073dfa87d19b4  mov eax, 0x420B10
000073dfa87d19b9  mov r14, [r13+rax*1]
000073dfa87d19be  movq xmm1, r14
000073dfa87d19c3  movaps [r15+0x120], xmm1
000073dfa87d19cb  vmovaps xmm1, [0x000073DFA83FE020]
000073dfa87d19d3  movq xmm1, xmm1
000073dfa87d19d7  movaps [r15+0x140], xmm1
000073dfa87d19df  vmovaps xmm1, [0x000073DFA83FE030]
000073dfa87d19e7  vpbroadcastq xmm1, xmm1
000073dfa87d19ec  movaps [r15+0x150], xmm1
000073dfa87d19f4  mov qword ptr [r15+0x40], 0x02
000073dfa87d19fc  vmovaps xmm15, [0x000073DFA83FE040]
000073dfa87d1a04  movq xmm15, xmm15
000073dfa87d1a09  movaps [r15+0x160], xmm15
000073dfa87d1a11  vmovaps xmm15, [0x000073DFA83FE050]
000073dfa87d1a19  vpbroadcastq xmm15, xmm15
000073dfa87d1a1e  movaps [r15+0x130], xmm15
000073dfa87d1a26  mov rax, [r15+0x40]
000073dfa87d1a2a  vmovq xmm14, rax
000073dfa87d1a2f  vpbroadcastq xmm14, xmm14
000073dfa87d1a34  movaps [r15+0x170], xmm14
000073dfa87d1a3c  mov eax, 0x420A40
000073dfa87d1a41  movups xmm13, [r13+rax*1]
000073dfa87d1a47  mov qword ptr [r15+0x40], 0x431E00
000073dfa87d1a4f  mov eax, [r15]
000073dfa87d1a52  mov r14d, 0x430CB8
000073dfa87d1a58  mov [r13+r14*1], eax
000073dfa87d1a5d  mov qword ptr [r15+0x50], 0x432000
000073dfa87d1a65  vpmovqd xmm12, xmm13
000073dfa87d1a6b  pxor xmm11, xmm11
000073dfa87d1a70  punpcklqdq xmm12, xmm11
000073dfa87d1a75  movaps [r15+0x210], xmm12
000073dfa87d1a7d  movq xmm12, qword ptr [r15+0x140]
000073dfa87d1a86  movq xmm11, qword ptr [r15+0x120]
000073dfa87d1a8f  psubd xmm12, xmm11
000073dfa87d1a94  movq xmm12, xmm12
000073dfa87d1a99  paddq xmm13, xmm14
000073dfa87d1a9e  movaps [r15+0x180], xmm13
000073dfa87d1aa6  movq xmm14, qword ptr [r15+0x160]
000073dfa87d1aaf  paddd xmm11, xmm14
000073dfa87d1ab4  movq xmm11, xmm11
000073dfa87d1ab9  movq xmm11, xmm11
000073dfa87d1abe  movaps [r15+0x120], xmm11
000073dfa87d1ac6  pmovzxdq xmm12, xmm12
000073dfa87d1acc  psllq xmm12, 0x00
000073dfa87d1ad2  movq xmm14, qword ptr [r15+0x210]
000073dfa87d1adb  movq xmm13, qword ptr [r15+0x110]
000073dfa87d1ae4  paddd xmm14, xmm13
000073dfa87d1ae9  movq xmm14, xmm14
000073dfa87d1aee  vcvtuqq2pd xmm12, xmm12
000073dfa87d1af4  pmovzxdq xmm14, xmm14
000073dfa87d1afa  psllq xmm14, 0x00
000073dfa87d1b00  vcvtuqq2pd xmm14, xmm14
000073dfa87d1b06  movaps xmm13, xmm12
000073dfa87d1b0a  mulpd xmm13, xmm1
000073dfa87d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000073dfa87d1b15  ptest xmm11, xmm11
000073dfa87d1b1b  jnz 0x000073DFA87D1C0F
000073dfa87d1b21  movaps [r15+0x220], xmm13
000073dfa87d1b29  mov eax, 0x432000
000073dfa87d1b2e  movups [r13+rax*1], xmm13
000073dfa87d1b34  movaps xmm1, xmm14
000073dfa87d1b38  mulpd xmm1, xmm15
000073dfa87d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000073dfa87d1b42  ptest xmm13, xmm13
000073dfa87d1b48  jnz 0x000073DFA87D1D5C
000073dfa87d1b4e  movaps [r15+0x210], xmm1
000073dfa87d1b56  mov eax, 0x431E00
000073dfa87d1b5b  movups [r13+rax*1], xmm1
000073dfa87d1b61  mov qword ptr [r15+0x48], 0x10
000073dfa87d1b69  xor eax, eax
000073dfa87d1b6b  mov r14d, 0x10
000073dfa87d1b71  mov r12d, 0x200
000073dfa87d1b77  cmp r14, r12
000073dfa87d1b7a  cmc
000073dfa87d1b7b  lahf
000073dfa87d1b7c  seto al
000073dfa87d1b7f  mov [r15+0x108], eax
000073dfa87d1b86  mov eax, [r15+0x108]
000073dfa87d1b8d  sahf
000073dfa87d1b8e  jnz 0x000073DFA87D1BC0
000073dfa87d1b90  cmp dword ptr [r15+0x318], 0x00
000073dfa87d1b98  jz 0x000073DFA87D2300
000073dfa87d1b9e  nop [rax+rax*1], ax
000073dfa87d1ba7  nop [rax+rax*1], eax
000073dfa87d1baf  mov eax, 0x410490
000073dfa87d1bb4  mov [r15+0x100], rax
000073dfa87d1bbb  jmp 0x000073DFA85FE110
000073dfa87d1bc0  cmp dword ptr [r15+0x318], 0x00
000073dfa87d1bc8  jz 0x000073DFA87D1EB0
000073dfa87d1bce  nop [rax+rax*1], ax
000073dfa87d1bd7  nop [rax+rax*1], eax
000073dfa87d1bdf  mov eax, 0x410450
000073dfa87d1be4  mov [r15+0x100], rax
000073dfa87d1beb  jmp 0x000073DFA85FE110
000073dfa87d1bf0  int3
000073dfa87d1bf1  call 0x000073DFA860DC20
000073dfa87d1bf6  jmp 0x000073DFA87D19BE
000073dfa87d1bfb  call 0x000073DFA860C260
000073dfa87d1c00  jmp 0x000073DFA87D1A47
000073dfa87d1c05  call 0x000073DFA86D5D70
000073dfa87d1c0a  jmp 0x000073DFA87D1A5D
000073dfa87d1c0f  sub rsp, 0x08
000073dfa87d1c13  push rax
000073dfa87d1c14  push rcx
000073dfa87d1c15  push rdx
000073dfa87d1c16  push rdi
000073dfa87d1c17  push rsi
000073dfa87d1c18  push r8
000073dfa87d1c1a  push r9
000073dfa87d1c1c  push r10
000073dfa87d1c1e  push r11
000073dfa87d1c20  sub rsp, 0xF0
000073dfa87d1c27  vmovaps [rsp], xmm0
000073dfa87d1c2c  vmovaps [rsp+0x10], xmm1
000073dfa87d1c32  vmovaps [rsp+0x20], xmm2
000073dfa87d1c38  vmovaps [rsp+0x30], xmm3
000073dfa87d1c3e  vmovaps [rsp+0x40], xmm4
000073dfa87d1c44  vmovaps [rsp+0x50], xmm5
000073dfa87d1c4a  vmovaps [rsp+0x60], xmm6
000073dfa87d1c50  vmovaps [rsp+0x70], xmm7
000073dfa87d1c56  vmovaps [rsp+0x80], xmm8
000073dfa87d1c5f  vmovaps [rsp+0x90], xmm9
000073dfa87d1c68  vmovaps [rsp+0xA0], xmm10
000073dfa87d1c71  vmovaps [rsp+0xB0], xmm11
000073dfa87d1c7a  vmovaps [rsp+0xC0], xmm12
000073dfa87d1c83  vmovaps [rsp+0xD0], xmm14
000073dfa87d1c8c  vmovaps [rsp+0xE0], xmm15
000073dfa87d1c95  sub rsp, 0x30
000073dfa87d1c99  movaps [rsp], xmm13
000073dfa87d1c9e  movaps [rsp+0x10], xmm12
000073dfa87d1ca4  movaps [rsp+0x20], xmm1
000073dfa87d1ca9  lea rdi, [rsp]
000073dfa87d1cad  mov esi, 0x00
000073dfa87d1cb2  mov rax, 0x593AA1DA4530
000073dfa87d1cbc  call rax
000073dfa87d1cbe  movaps xmm13, [rsp]
000073dfa87d1cc3  add rsp, 0x30
000073dfa87d1cc7  vmovaps xmm0, [rsp]
000073dfa87d1ccc  vmovaps xmm1, [rsp+0x10]
000073dfa87d1cd2  vmovaps xmm2, [rsp+0x20]
000073dfa87d1cd8  vmovaps xmm3, [rsp+0x30]
000073dfa87d1cde  vmovaps xmm4, [rsp+0x40]
000073dfa87d1ce4  vmovaps xmm5, [rsp+0x50]
000073dfa87d1cea  vmovaps xmm6, [rsp+0x60]
000073dfa87d1cf0  vmovaps xmm7, [rsp+0x70]
000073dfa87d1cf6  vmovaps xmm8, [rsp+0x80]
000073dfa87d1cff  vmovaps xmm9, [rsp+0x90]
000073dfa87d1d08  vmovaps xmm10, [rsp+0xA0]
000073dfa87d1d11  vmovaps xmm11, [rsp+0xB0]
000073dfa87d1d1a  vmovaps xmm12, [rsp+0xC0]
000073dfa87d1d23  vmovaps xmm14, [rsp+0xD0]
000073dfa87d1d2c  vmovaps xmm15, [rsp+0xE0]
000073dfa87d1d35  add rsp, 0xF0
000073dfa87d1d3c  pop r11
000073dfa87d1d3e  pop r10
000073dfa87d1d40  pop r9
000073dfa87d1d42  pop r8
000073dfa87d1d44  pop rsi
000073dfa87d1d45  pop rdi
000073dfa87d1d46  pop rdx
000073dfa87d1d47  pop rcx
000073dfa87d1d48  pop rax
000073dfa87d1d49  add rsp, 0x08
000073dfa87d1d4d  jmp 0x000073DFA87D1B21
000073dfa87d1d52  call 0x000073DFA860C380
000073dfa87d1d57  jmp 0x000073DFA87D1B34
000073dfa87d1d5c  sub rsp, 0x08
000073dfa87d1d60  push rax
000073dfa87d1d61  push rcx
000073dfa87d1d62  push rdx
000073dfa87d1d63  push rdi
000073dfa87d1d64  push rsi
000073dfa87d1d65  push r8
000073dfa87d1d67  push r9
000073dfa87d1d69  push r10
000073dfa87d1d6b  push r11
000073dfa87d1d6d  sub rsp, 0xF0
000073dfa87d1d74  vmovaps [rsp], xmm0
000073dfa87d1d79  vmovaps [rsp+0x10], xmm2
000073dfa87d1d7f  vmovaps [rsp+0x20], xmm3
000073dfa87d1d85  vmovaps [rsp+0x30], xmm4
000073dfa87d1d8b  vmovaps [rsp+0x40], xmm5
000073dfa87d1d91  vmovaps [rsp+0x50], xmm6
000073dfa87d1d97  vmovaps [rsp+0x60], xmm7
000073dfa87d1d9d  vmovaps [rsp+0x70], xmm8
000073dfa87d1da3  vmovaps [rsp+0x80], xmm9
000073dfa87d1dac  vmovaps [rsp+0x90], xmm10
000073dfa87d1db5  vmovaps [rsp+0xA0], xmm11
000073dfa87d1dbe  vmovaps [rsp+0xB0], xmm12
000073dfa87d1dc7  vmovaps [rsp+0xC0], xmm13
000073dfa87d1dd0  vmovaps [rsp+0xD0], xmm14
000073dfa87d1dd9  vmovaps [rsp+0xE0], xmm15
000073dfa87d1de2  sub rsp, 0x30
000073dfa87d1de6  movaps [rsp], xmm1
000073dfa87d1dea  movaps [rsp+0x10], xmm14
000073dfa87d1df0  movaps [rsp+0x20], xmm15
000073dfa87d1df6  lea rdi, [rsp]
000073dfa87d1dfa  mov esi, 0x00
000073dfa87d1dff  mov rax, 0x593AA1DA4530
000073dfa87d1e09  call rax
000073dfa87d1e0b  movaps xmm1, [rsp]
000073dfa87d1e0f  add rsp, 0x30
000073dfa87d1e13  vmovaps xmm0, [rsp]
000073dfa87d1e18  vmovaps xmm2, [rsp+0x10]
000073dfa87d1e1e  vmovaps xmm3, [rsp+0x20]
000073dfa87d1e24  vmovaps xmm4, [rsp+0x30]
000073dfa87d1e2a  vmovaps xmm5, [rsp+0x40]
000073dfa87d1e30  vmovaps xmm6, [rsp+0x50]
000073dfa87d1e36  vmovaps xmm7, [rsp+0x60]
000073dfa87d1e3c  vmovaps xmm8, [rsp+0x70]
000073dfa87d1e42  vmovaps xmm9, [rsp+0x80]
000073dfa87d1e4b  vmovaps xmm10, [rsp+0x90]
000073dfa87d1e54  vmovaps xmm11, [rsp+0xA0]
000073dfa87d1e5d  vmovaps xmm12, [rsp+0xB0]
000073dfa87d1e66  vmovaps xmm13, [rsp+0xC0]
000073dfa87d1e6f  vmovaps xmm14, [rsp+0xD0]
000073dfa87d1e78  vmovaps xmm15, [rsp+0xE0]
000073dfa87d1e81  add rsp, 0xF0
000073dfa87d1e88  pop r11
000073dfa87d1e8a  pop r10
000073dfa87d1e8c  pop r9
000073dfa87d1e8e  pop r8
000073dfa87d1e90  pop rsi
000073dfa87d1e91  pop rdi
000073dfa87d1e92  pop rdx
000073dfa87d1e93  pop rcx
000073dfa87d1e94  pop rax
000073dfa87d1e95  add rsp, 0x08
000073dfa87d1e99  jmp 0x000073DFA87D1B4E
000073dfa87d1e9e  call 0x000073DFA85FF540
000073dfa87d1ea3  jmp 0x000073DFA87D1B61
000073dfa87d1ea8  int3
000073dfa87d1ea9  nop [rax], eax
000073dfa87d1eb0  movaps xmm1, [r15+0x180]
000073dfa87d1eb8  vpmovqd xmm15, xmm1
000073dfa87d1ebe  pxor xmm14, xmm14
000073dfa87d1ec3  punpcklqdq xmm15, xmm14
000073dfa87d1ec8  movaps [r15+0x210], xmm15
000073dfa87d1ed0  movq xmm15, qword ptr [r15+0x140]
000073dfa87d1ed9  movq xmm14, qword ptr [r15+0x120]
000073dfa87d1ee2  psubd xmm15, xmm14
000073dfa87d1ee7  movq xmm15, xmm15
000073dfa87d1eec  movaps xmm13, [r15+0x170]
000073dfa87d1ef4  paddq xmm1, xmm13
000073dfa87d1ef9  movaps [r15+0x180], xmm1
000073dfa87d1f01  movq xmm1, qword ptr [r15+0x160]
000073dfa87d1f0a  paddd xmm14, xmm1
000073dfa87d1f0f  movq xmm14, xmm14
000073dfa87d1f14  movq xmm14, xmm14
000073dfa87d1f19  movaps [r15+0x120], xmm14
000073dfa87d1f21  pmovzxdq xmm15, xmm15
000073dfa87d1f27  psllq xmm15, 0x00
000073dfa87d1f2d  movq xmm1, qword ptr [r15+0x210]
000073dfa87d1f36  movq xmm14, qword ptr [r15+0x110]
000073dfa87d1f3f  paddd xmm1, xmm14
000073dfa87d1f44  movq xmm1, xmm1
000073dfa87d1f48  vcvtuqq2pd xmm15, xmm15
000073dfa87d1f4e  pmovzxdq xmm1, xmm1
000073dfa87d1f53  psllq xmm1, 0x00
000073dfa87d1f58  vcvtuqq2pd xmm1, xmm1
000073dfa87d1f5e  movaps xmm14, [r15+0x150]
000073dfa87d1f66  movaps xmm13, xmm15
000073dfa87d1f6a  mulpd xmm13, xmm14
000073dfa87d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000073dfa87d1f75  ptest xmm12, xmm12
000073dfa87d1f7b  jnz 0x000073DFA87D205E
000073dfa87d1f81  movaps [r15+0x220], xmm13
000073dfa87d1f89  mov rax, [r15+0x48]
000073dfa87d1f8d  mov r14, [r15+0x50]
000073dfa87d1f91  lea r12, [r14+rax*1]
000073dfa87d1f95  movups [r13+r12*1], xmm13
000073dfa87d1f9b  movaps xmm15, [r15+0x130]
000073dfa87d1fa3  movaps xmm14, xmm1
000073dfa87d1fa7  mulpd xmm14, xmm15
000073dfa87d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000073dfa87d1fb2  ptest xmm13, xmm13
000073dfa87d1fb8  jnz 0x000073DFA87D21AC
000073dfa87d1fbe  movaps [r15+0x210], xmm14
000073dfa87d1fc6  mov r14, [r15+0x40]
000073dfa87d1fca  lea r12, [r14+rax*1]
000073dfa87d1fce  movups [r13+r12*1], xmm14
000073dfa87d1fd4  lea r14, [rax+0x10]
000073dfa87d1fd8  mov [r15+0x48], r14
000073dfa87d1fdc  xor eax, eax
000073dfa87d1fde  mov r12d, 0x200
000073dfa87d1fe4  cmp r14, r12
000073dfa87d1fe7  cmc
000073dfa87d1fe8  lahf
000073dfa87d1fe9  seto al
000073dfa87d1fec  mov [r15+0x108], eax
000073dfa87d1ff3  mov eax, [r15+0x108]
000073dfa87d1ffa  sahf
000073dfa87d1ffb  jnz 0x000073DFA87D202D
000073dfa87d1ffd  cmp dword ptr [r15+0x318], 0x00
000073dfa87d2005  jz 0x000073DFA87D2300
000073dfa87d200b  nop [rax+rax*1], ax
000073dfa87d2014  nop [rax+rax*1], eax
000073dfa87d201c  mov eax, 0x410490
000073dfa87d2021  mov [r15+0x100], rax
000073dfa87d2028  jmp 0x000073DFA85FE110
000073dfa87d202d  cmp dword ptr [r15+0x318], 0x00
000073dfa87d2035  jz 0x000073DFA87D1EB0
000073dfa87d203b  nop [rax+rax*1], ax
000073dfa87d2044  nop [rax+rax*1], eax
000073dfa87d204c  mov eax, 0x410450
000073dfa87d2051  mov [r15+0x100], rax
000073dfa87d2058  jmp 0x000073DFA85FE110
000073dfa87d205d  int3
000073dfa87d205e  sub rsp, 0x08
000073dfa87d2062  push rax
000073dfa87d2063  push rcx
000073dfa87d2064  push rdx
000073dfa87d2065  push rdi
000073dfa87d2066  push rsi
000073dfa87d2067  push r8
000073dfa87d2069  push r9
000073dfa87d206b  push r10
000073dfa87d206d  push r11
000073dfa87d206f  sub rsp, 0xF0
000073dfa87d2076  vmovaps [rsp], xmm0
000073dfa87d207b  vmovaps [rsp+0x10], xmm1
000073dfa87d2081  vmovaps [rsp+0x20], xmm2
000073dfa87d2087  vmovaps [rsp+0x30], xmm3
000073dfa87d208d  vmovaps [rsp+0x40], xmm4
000073dfa87d2093  vmovaps [rsp+0x50], xmm5
000073dfa87d2099  vmovaps [rsp+0x60], xmm6
000073dfa87d209f  vmovaps [rsp+0x70], xmm7
000073dfa87d20a5  vmovaps [rsp+0x80], xmm8
000073dfa87d20ae  vmovaps [rsp+0x90], xmm9
000073dfa87d20b7  vmovaps [rsp+0xA0], xmm10
000073dfa87d20c0  vmovaps [rsp+0xB0], xmm11
000073dfa87d20c9  vmovaps [rsp+0xC0], xmm12
000073dfa87d20d2  vmovaps [rsp+0xD0], xmm14
000073dfa87d20db  vmovaps [rsp+0xE0], xmm15
000073dfa87d20e4  sub rsp, 0x30
000073dfa87d20e8  movaps [rsp], xmm13
000073dfa87d20ed  movaps [rsp+0x10], xmm15
000073dfa87d20f3  movaps [rsp+0x20], xmm14
000073dfa87d20f9  lea rdi, [rsp]
000073dfa87d20fd  mov esi, 0x00
000073dfa87d2102  mov rax, 0x593AA1DA4530
000073dfa87d210c  call rax
000073dfa87d210e  movaps xmm13, [rsp]
000073dfa87d2113  add rsp, 0x30
000073dfa87d2117  vmovaps xmm0, [rsp]
000073dfa87d211c  vmovaps xmm1, [rsp+0x10]
000073dfa87d2122  vmovaps xmm2, [rsp+0x20]
000073dfa87d2128  vmovaps xmm3, [rsp+0x30]
000073dfa87d212e  vmovaps xmm4, [rsp+0x40]
000073dfa87d2134  vmovaps xmm5, [rsp+0x50]
000073dfa87d213a  vmovaps xmm6, [rsp+0x60]
000073dfa87d2140  vmovaps xmm7, [rsp+0x70]
000073dfa87d2146  vmovaps xmm8, [rsp+0x80]
000073dfa87d214f  vmovaps xmm9, [rsp+0x90]
000073dfa87d2158  vmovaps xmm10, [rsp+0xA0]
000073dfa87d2161  vmovaps xmm11, [rsp+0xB0]
000073dfa87d216a  vmovaps xmm12, [rsp+0xC0]
000073dfa87d2173  vmovaps xmm14, [rsp+0xD0]
000073dfa87d217c  vmovaps xmm15, [rsp+0xE0]
000073dfa87d2185  add rsp, 0xF0
000073dfa87d218c  pop r11
000073dfa87d218e  pop r10
000073dfa87d2190  pop r9
000073dfa87d2192  pop r8
000073dfa87d2194  pop rsi
000073dfa87d2195  pop rdi
000073dfa87d2196  pop rdx
000073dfa87d2197  pop rcx
000073dfa87d2198  pop rax
000073dfa87d2199  add rsp, 0x08
000073dfa87d219d  jmp 0x000073DFA87D1F81
000073dfa87d21a2  call 0x000073DFA86C2240
000073dfa87d21a7  jmp 0x000073DFA87D1F9B
000073dfa87d21ac  sub rsp, 0x08
000073dfa87d21b0  push rax
000073dfa87d21b1  push rcx
000073dfa87d21b2  push rdx
000073dfa87d21b3  push rdi
000073dfa87d21b4  push rsi
000073dfa87d21b5  push r8
000073dfa87d21b7  push r9
000073dfa87d21b9  push r10
000073dfa87d21bb  push r11
000073dfa87d21bd  sub rsp, 0xF0
000073dfa87d21c4  vmovaps [rsp], xmm0
000073dfa87d21c9  vmovaps [rsp+0x10], xmm1
000073dfa87d21cf  vmovaps [rsp+0x20], xmm2
000073dfa87d21d5  vmovaps [rsp+0x30], xmm3
000073dfa87d21db  vmovaps [rsp+0x40], xmm4
000073dfa87d21e1  vmovaps [rsp+0x50], xmm5
000073dfa87d21e7  vmovaps [rsp+0x60], xmm6
000073dfa87d21ed  vmovaps [rsp+0x70], xmm7
000073dfa87d21f3  vmovaps [rsp+0x80], xmm8
000073dfa87d21fc  vmovaps [rsp+0x90], xmm9
000073dfa87d2205  vmovaps [rsp+0xA0], xmm10
000073dfa87d220e  vmovaps [rsp+0xB0], xmm11
000073dfa87d2217  vmovaps [rsp+0xC0], xmm12
000073dfa87d2220  vmovaps [rsp+0xD0], xmm13
000073dfa87d2229  vmovaps [rsp+0xE0], xmm15
000073dfa87d2232  sub rsp, 0x30
000073dfa87d2236  movaps [rsp], xmm14
000073dfa87d223b  movaps [rsp+0x10], xmm1
000073dfa87d2240  movaps [rsp+0x20], xmm15
000073dfa87d2246  lea rdi, [rsp]
000073dfa87d224a  mov esi, 0x00
000073dfa87d224f  mov rax, 0x593AA1DA4530
000073dfa87d2259  call rax
000073dfa87d225b  movaps xmm14, [rsp]
000073dfa87d2260  add rsp, 0x30
000073dfa87d2264  vmovaps xmm0, [rsp]
000073dfa87d2269  vmovaps xmm1, [rsp+0x10]
000073dfa87d226f  vmovaps xmm2, [rsp+0x20]
000073dfa87d2275  vmovaps xmm3, [rsp+0x30]
000073dfa87d227b  vmovaps xmm4, [rsp+0x40]
000073dfa87d2281  vmovaps xmm5, [rsp+0x50]
000073dfa87d2287  vmovaps xmm6, [rsp+0x60]
000073dfa87d228d  vmovaps xmm7, [rsp+0x70]
000073dfa87d2293  vmovaps xmm8, [rsp+0x80]
000073dfa87d229c  vmovaps xmm9, [rsp+0x90]
000073dfa87d22a5  vmovaps xmm10, [rsp+0xA0]
000073dfa87d22ae  vmovaps xmm11, [rsp+0xB0]
000073dfa87d22b7  vmovaps xmm12, [rsp+0xC0]
000073dfa87d22c0  vmovaps xmm13, [rsp+0xD0]
000073dfa87d22c9  vmovaps xmm15, [rsp+0xE0]
000073dfa87d22d2  add rsp, 0xF0
000073dfa87d22d9  pop r11
000073dfa87d22db  pop r10
000073dfa87d22dd  pop r9
000073dfa87d22df  pop r8
000073dfa87d22e1  pop rsi
000073dfa87d22e2  pop rdi
000073dfa87d22e3  pop rdx
000073dfa87d22e4  pop rcx
000073dfa87d22e5  pop rax
000073dfa87d22e6  add rsp, 0x08
000073dfa87d22ea  jmp 0x000073DFA87D1FBE
000073dfa87d22ef  call 0x000073DFA86C34C0
000073dfa87d22f4  jmp 0x000073DFA87D1FD4
000073dfa87d22f9  int3
000073dfa87d22fa  nop [rax+rax*1], ax
000073dfa87d2300  mov rax, [r15+0x50]
000073dfa87d2304  lea r14, [rax+0x80]
000073dfa87d230b  movups xmm1, [r13+r14*1]
000073dfa87d2311  lea r14, [rax+0x90]
000073dfa87d2318  movups xmm15, [r13+r14*1]
000073dfa87d231e  vxorps xmm14, xmm14, xmm14
000073dfa87d2323  vpbroadcastq xmm14, xmm14
000073dfa87d2328  lea r14, [rax+0x40]
000073dfa87d232c  movups xmm13, [r13+r14*1]
000073dfa87d2332  lea r14, [rax+0x50]
000073dfa87d2336  movups xmm12, [r13+r14*1]
000073dfa87d233c  mov qword ptr [r15+0x48], 0x00
000073dfa87d2344  movups xmm11, [r13+rax*1]
000073dfa87d234a  lea r14, [rax+0x10]
000073dfa87d234e  movups xmm10, [r13+r14*1]
000073dfa87d2354  mov r14, [r15+0xF8]
000073dfa87d235b  lea r12, [r14+0xE0]
000073dfa87d2362  movups [r13+r12*1], xmm15
000073dfa87d2368  lea r12, [r14+0xF0]
000073dfa87d236f  movups [r13+r12*1], xmm1
000073dfa87d2375  lea r12, [rax+0xC0]
000073dfa87d237c  movups xmm1, [r13+r12*1]
000073dfa87d2382  lea r12, [rax+0xD0]
000073dfa87d2389  movups xmm15, [r13+r12*1]
000073dfa87d238f  lea r12, [rax+0x140]
000073dfa87d2396  movups xmm9, [r13+r12*1]
000073dfa87d239c  lea r12, [rax+0x150]
000073dfa87d23a3  movups xmm8, [r13+r12*1]
000073dfa87d23a9  lea r12, [rax+0x180]
000073dfa87d23b0  movups xmm7, [r13+r12*1]
000073dfa87d23b6  lea r12, [rax+0x190]
000073dfa87d23bd  movups xmm6, [r13+r12*1]
000073dfa87d23c3  lea r12, [r14+0xC0]
000073dfa87d23ca  movups [r13+r12*1], xmm15
000073dfa87d23d0  lea r12, [r14+0xD0]
000073dfa87d23d7  movups [r13+r12*1], xmm1
000073dfa87d23dd  lea r12, [rax+0x100]
000073dfa87d23e4  movups xmm1, [r13+r12*1]
000073dfa87d23ea  lea r12, [rax+0x110]
000073dfa87d23f1  movups xmm15, [r13+r12*1]
000073dfa87d23f7  lea r12, [rax+0x1C0]
000073dfa87d23fe  movups xmm5, [r13+r12*1]
000073dfa87d2404  lea r12, [rax+0x1D0]
000073dfa87d240b  movups xmm4, [r13+r12*1]
000073dfa87d2411  lea r12, [rax+0x20]
000073dfa87d2415  movups xmm3, [r13+r12*1]
000073dfa87d241b  lea r12, [rax+0x30]
000073dfa87d241f  movups xmm2, [r13+r12*1]
000073dfa87d2425  movaps [r15+0x1F0], xmm2
000073dfa87d242d  lea r12, [r14+0x20]
000073dfa87d2431  movups [r13+r12*1], xmm1
000073dfa87d2437  lea r12, [r14+0x30]
000073dfa87d243b  movups [r13+r12*1], xmm12
000073dfa87d2441  lea r12, [rax+0x60]
000073dfa87d2445  movups xmm1, [r13+r12*1]
000073dfa87d244b  lea r12, [rax+0x70]
000073dfa87d244f  movups xmm12, [r13+r12*1]
000073dfa87d2455  lea r12, [r14+0x60]
000073dfa87d2459  movups [r13+r12*1], xmm11
000073dfa87d245f  lea r12, [r14+0x70]
000073dfa87d2463  movups [r13+r12*1], xmm5
000073dfa87d2469  lea r12, [rax+0xE0]
000073dfa87d2470  movups xmm11, [r13+r12*1]
000073dfa87d2476  lea r12, [rax+0xF0]
000073dfa87d247d  movups xmm5, [r13+r12*1]
000073dfa87d2483  lea r12, [rax+0x120]
000073dfa87d248a  vmovaps [rsp+0x10], xmm1
000073dfa87d2490  movups xmm1, [r13+r12*1]
000073dfa87d2496  lea r12, [rax+0x130]
000073dfa87d249d  vmovaps [rsp+0x20], xmm1
000073dfa87d24a3  movups xmm1, [r13+r12*1]
000073dfa87d24a9  lea r12, [r14+0xA0]
000073dfa87d24b0  movups [r13+r12*1], xmm12
000073dfa87d24b6  lea r12, [r14+0xB0]
000073dfa87d24bd  vmovaps xmm12, [rsp+0x10]
000073dfa87d24c3  movups [r13+r12*1], xmm12
000073dfa87d24c9  lea r12, [rax+0xA0]
000073dfa87d24d0  movups xmm12, [r13+r12*1]
000073dfa87d24d6  lea r12, [rax+0xB0]
000073dfa87d24dd  vmovaps [rsp+0x10], xmm1
000073dfa87d24e3  movups xmm1, [r13+r12*1]
000073dfa87d24e9  lea r12, [rax+0x160]
000073dfa87d24f0  vmovaps [rsp+0x30], xmm1
000073dfa87d24f6  movups xmm1, [r13+r12*1]
000073dfa87d24fc  lea r12, [rax+0x170]
000073dfa87d2503  vmovaps [rsp+0x40], xmm1
000073dfa87d2509  movups xmm1, [r13+r12*1]
000073dfa87d250f  movaps [r15+0x2B0], xmm1
000073dfa87d2517  lea r12, [rax+0x1A0]
000073dfa87d251e  vmovaps [rsp+0x50], xmm1
000073dfa87d2524  movups xmm1, [r13+r12*1]
000073dfa87d252a  lea r12, [rax+0x1B0]
000073dfa87d2531  vmovaps [rsp+0x60], xmm1
000073dfa87d2537  movups xmm1, [r13+r12*1]
000073dfa87d253d  vmovaps [rsp+0x70], xmm1
000073dfa87d2543  vmovaps xmm1, [rsp+0x60]
000073dfa87d2549  movaps [r15+0x290], xmm1
000073dfa87d2551  vmovaps [rsp+0x60], xmm1
000073dfa87d2557  vmovaps xmm1, [rsp+0x70]
000073dfa87d255d  movaps [r15+0x1E0], xmm1
000073dfa87d2565  lea r12, [r14+0x80]
000073dfa87d256c  vmovaps [rsp+0x70], xmm1
000073dfa87d2572  vmovaps xmm1, [rsp+0x30]
000073dfa87d2578  movups [r13+r12*1], xmm1
000073dfa87d257e  lea r12, [r14+0x90]
000073dfa87d2585  movups [r13+r12*1], xmm12
000073dfa87d258b  lea r12, [rax+0x1E0]
000073dfa87d2592  movups xmm1, [r13+r12*1]
000073dfa87d2598  lea r12, [rax+0x1F0]
000073dfa87d259f  movups xmm12, [r13+r12*1]
000073dfa87d25a5  mov qword ptr [r15+0x50], 0x432200
000073dfa87d25ad  lea rax, [r14+0x40]
000073dfa87d25b1  vmovaps [rsp+0x30], xmm1
000073dfa87d25b7  vmovaps xmm1, [rsp+0x40]
000073dfa87d25bd  movups [r13+rax*1], xmm1
000073dfa87d25c3  lea rax, [r14+0x50]
000073dfa87d25c7  movups [r13+rax*1], xmm10
000073dfa87d25cd  movups [r13+r14*1], xmm12
000073dfa87d25d3  lea rax, [r14+0x10]
000073dfa87d25d7  vmovaps xmm1, [rsp+0x30]
000073dfa87d25dd  movups [r13+rax*1], xmm1
000073dfa87d25e3  mov rax, [r15+0x40]
000073dfa87d25e7  vmovaps [rsp+0x30], xmm3
000073dfa87d25ed  vmovaps xmm1, [rsp+0x30]
000073dfa87d25f3  por xmm3, xmm1
000073dfa87d25f7  vmovaps [rsp+0x30], xmm6
000073dfa87d25fd  vmovaps xmm12, [rsp+0x30]
000073dfa87d2603  por xmm6, xmm12
000073dfa87d2608  lea r12, [rax+0x30]
000073dfa87d260c  mov r11, [r13+r12*1]
000073dfa87d2611  lea r12, [rax+0x38]
000073dfa87d2615  mov r10, [r13+r12*1]
000073dfa87d261a  movq xmm12, r11
000073dfa87d261f  movq xmm10, r10
000073dfa87d2624  movq xmm12, xmm12
000073dfa87d2629  vmovaps [rsp+0x30], xmm12
000073dfa87d262f  movq xmm12, xmm12
000073dfa87d2634  movaps [r15+0x130], xmm12
000073dfa87d263c  movq xmm10, xmm10
000073dfa87d2641  vmovaps [rsp+0x40], xmm10
000073dfa87d2647  movq xmm10, xmm10
000073dfa87d264c  movaps [r15+0x280], xmm10
000073dfa87d2654  vmovaps [rsp+0x80], xmm9
000073dfa87d265d  vmovaps xmm12, [rsp+0x80]
000073dfa87d2666  por xmm9, xmm12
000073dfa87d266b  lea r12, [rax+0x20]
000073dfa87d266f  mov r11, [r13+r12*1]
000073dfa87d2674  lea r12, [rax+0x28]
000073dfa87d2678  mov r10, [r13+r12*1]
000073dfa87d267d  movq xmm12, r11
000073dfa87d2682  movq xmm10, r10
000073dfa87d2687  movq xmm12, xmm12
000073dfa87d268c  vmovaps [rsp+0x80], xmm12
000073dfa87d2695  movq xmm12, xmm12
000073dfa87d269a  movaps [r15+0x150], xmm12
000073dfa87d26a2  movq xmm10, xmm10
000073dfa87d26a7  vmovaps [rsp+0x90], xmm10
000073dfa87d26b0  movq xmm10, xmm10
000073dfa87d26b5  movaps [r15+0x140], xmm10
000073dfa87d26bd  lea r12, [rax+0x10]
000073dfa87d26c1  mov r11, [r13+r12*1]
000073dfa87d26c6  lea r12, [rax+0x18]
000073dfa87d26ca  mov r10, [r13+r12*1]
000073dfa87d26cf  movq xmm12, r11
000073dfa87d26d4  movq xmm10, r10
000073dfa87d26d9  movq xmm12, xmm12
000073dfa87d26de  vmovaps [rsp+0xA0], xmm12
000073dfa87d26e7  movq xmm12, xmm12
000073dfa87d26ec  movaps [r15+0x170], xmm12
000073dfa87d26f4  movq xmm10, xmm10
000073dfa87d26f9  vmovaps [rsp+0xB0], xmm10
000073dfa87d2702  movq xmm10, xmm10
000073dfa87d2707  movaps [r15+0x160], xmm10
000073dfa87d270f  mov r12, [r13+rax*1]
000073dfa87d2714  vmovq xmm12, r12
000073dfa87d2719  vpbroadcastq xmm12, xmm12
000073dfa87d271e  lea r12, [rax+0x08]
000073dfa87d2722  mov rax, [r13+r12*1]
000073dfa87d2727  movq xmm10, rax
000073dfa87d272c  movaps [r15+0x230], xmm10
000073dfa87d2734  lea rax, [r14+0x50]
000073dfa87d2738  movups xmm10, [r13+rax*1]
000073dfa87d273e  lea rax, [r14+0x60]
000073dfa87d2742  vmovaps [rsp+0xC0], xmm1
000073dfa87d274b  movups xmm1, [r13+rax*1]
000073dfa87d2751  lea rax, [r14+0x30]
000073dfa87d2755  vmovaps [rsp+0xD0], xmm1
000073dfa87d275e  movups xmm1, [r13+rax*1]
000073dfa87d2764  mov qword ptr [r15+0x60], 0x432200
000073dfa87d276c  mov qword ptr [r15+0x58], 0x40
000073dfa87d2774  vmovaps [rsp+0xE0], xmm1
000073dfa87d277d  vmovaps [rsp+0xF0], xmm15
000073dfa87d2786  vmovaps xmm15, [rsp+0xC0]
000073dfa87d278f  vmovaps [rsp+0xC0], xmm14
000073dfa87d2798  movaps xmm1, xmm12
000073dfa87d279c  mulpd xmm1, xmm15
000073dfa87d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000073dfa87d27a6  ptest xmm14, xmm14
000073dfa87d27ac  jnz 0x000073DFA87D3863
000073dfa87d27b2  movq xmm15, qword ptr [r15+0x230]
000073dfa87d27bb  vmovaps [rsp+0x100], xmm15
000073dfa87d27c4  vpermilpd xmm15, xmm15, 0x00
000073dfa87d27ca  vmovaps [rsp+0x110], xmm1
000073dfa87d27d3  vmovaps xmm1, [rsp+0xE0]
000073dfa87d27dc  vmovaps [rsp+0xE0], xmm13
000073dfa87d27e5  movaps xmm14, xmm1
000073dfa87d27e9  mulpd xmm14, xmm15
000073dfa87d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000073dfa87d27f4  ptest xmm13, xmm13
000073dfa87d27fa  jnz 0x000073DFA87D39A5
000073dfa87d2800  vxorps xmm1, xmm1, xmm1
000073dfa87d2804  vpbroadcastq xmm1, xmm1
000073dfa87d2809  vmovaps xmm13, [rsp+0xD0]
000073dfa87d2812  vmovaps [rsp+0xD0], xmm1
000073dfa87d281b  movaps xmm15, xmm12
000073dfa87d281f  mulpd xmm15, xmm13
000073dfa87d2824  vcmppd xmm1, xmm15, xmm15, 0x03
000073dfa87d282a  ptest xmm1, xmm1
000073dfa87d282f  jnz 0x000073DFA87D3AE8
000073dfa87d2835  movaps xmm1, xmm12
000073dfa87d2839  mulpd xmm1, xmm10
000073dfa87d283e  vcmppd xmm13, xmm1, xmm1, 0x03
000073dfa87d2843  ptest xmm13, xmm13
000073dfa87d2849  jnz 0x000073DFA87D3C2C
000073dfa87d284f  movaps xmm13, xmm12
000073dfa87d2853  mulpd xmm13, xmm2
000073dfa87d2858  vcmppd xmm10, xmm13, xmm13, 0x03
000073dfa87d285e  ptest xmm10, xmm10
000073dfa87d2864  jnz 0x000073DFA87D3D6E
000073dfa87d286a  vmovaps [rsp+0x120], xmm7
000073dfa87d2873  vmovaps xmm12, [rsp+0x120]
000073dfa87d287c  por xmm7, xmm12
000073dfa87d2881  vmovaps xmm12, [rsp+0xE0]
000073dfa87d288a  vmovaps xmm10, [rsp+0xE0]
000073dfa87d2893  por xmm12, xmm10
000073dfa87d2898  vmovaps xmm2, [rsp+0x100]
000073dfa87d28a1  vpermilpd xmm2, xmm2, 0x00
000073dfa87d28a7  vmovaps [rsp+0xE0], xmm1
000073dfa87d28b0  vmovaps [rsp+0x120], xmm15
000073dfa87d28b9  movaps xmm1, xmm10
000073dfa87d28bd  mulpd xmm1, xmm2
000073dfa87d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000073dfa87d28c6  ptest xmm15, xmm15
000073dfa87d28cc  jnz 0x000073DFA87D3EB1
000073dfa87d28d2  xor eax, eax
000073dfa87d28d4  mov r12d, 0x40
000073dfa87d28da  mov r11d, 0x200
000073dfa87d28e0  cmp r12, r11
000073dfa87d28e3  cmc
000073dfa87d28e4  lahf
000073dfa87d28e5  seto al
000073dfa87d28e8  mov [r15+0x108], eax
000073dfa87d28ef  vmovaps xmm10, [rsp+0x110]
000073dfa87d28f8  vmovaps xmm2, [rsp+0xD0]
000073dfa87d2901  vmovaps [rsp+0xD0], xmm1
000073dfa87d290a  movaps xmm15, xmm10
000073dfa87d290e  addpd xmm15, xmm2
000073dfa87d2913  vcmppd xmm1, xmm15, xmm15, 0x03
000073dfa87d2919  ptest xmm1, xmm1
000073dfa87d291e  jnz 0x000073DFA87D3FF2
000073dfa87d2924  vmovaps xmm10, [rsp+0x120]
000073dfa87d292d  vmovaps [rsp+0x110], xmm15
000073dfa87d2936  vmovaps xmm15, [rsp+0xC0]
000073dfa87d293f  vmovaps [rsp+0xC0], xmm14
000073dfa87d2948  movaps xmm1, xmm10
000073dfa87d294c  addpd xmm1, xmm15
000073dfa87d2951  vcmppd xmm14, xmm1, xmm1, 0x03
000073dfa87d2956  ptest xmm14, xmm14
000073dfa87d295c  jnz 0x000073DFA87D4135
000073dfa87d2962  vmovaps xmm10, [rsp+0xE0]
000073dfa87d296b  vmovaps [rsp+0xE0], xmm1
000073dfa87d2974  movaps xmm14, xmm10
000073dfa87d2978  addpd xmm14, xmm15
000073dfa87d297d  vcmppd xmm1, xmm14, xmm14, 0x03
000073dfa87d2983  ptest xmm1, xmm1
000073dfa87d2988  jnz 0x000073DFA87D4277
000073dfa87d298e  vmovaps xmm1, [rsp+0x10]
000073dfa87d2994  vmovaps xmm15, [rsp+0x10]
000073dfa87d299a  por xmm1, xmm15
000073dfa87d299f  vmovaps xmm15, [rsp+0x20]
000073dfa87d29a5  vmovaps xmm10, [rsp+0x20]
000073dfa87d29ab  por xmm15, xmm10
000073dfa87d29b0  vmovaps [rsp+0x10], xmm5
000073dfa87d29b6  vmovaps xmm10, [rsp+0x10]
000073dfa87d29bc  por xmm5, xmm10
000073dfa87d29c1  vmovaps [rsp+0x10], xmm11
000073dfa87d29c7  vmovaps xmm10, [rsp+0x10]
000073dfa87d29cd  por xmm11, xmm10
000073dfa87d29d2  vmovaps [rsp+0x10], xmm4
000073dfa87d29d8  vmovaps xmm10, [rsp+0x10]
000073dfa87d29de  por xmm4, xmm10
000073dfa87d29e3  vmovaps [rsp+0x10], xmm8
000073dfa87d29e9  vmovaps xmm10, [rsp+0x10]
000073dfa87d29ef  por xmm8, xmm10
000073dfa87d29f4  vmovaps xmm10, [rsp+0xF0]
000073dfa87d29fd  vmovaps [rsp+0x10], xmm1
000073dfa87d2a03  vmovaps xmm1, [rsp+0xF0]
000073dfa87d2a0c  por xmm10, xmm1
000073dfa87d2a11  lea rax, [r14+0xA0]
000073dfa87d2a18  movups xmm1, [r13+rax*1]
000073dfa87d2a1e  lea rax, [r14+0xB0]
000073dfa87d2a25  vmovaps [rsp+0x20], xmm1
000073dfa87d2a2b  movups xmm1, [r13+rax*1]
000073dfa87d2a31  vmovaps [rsp+0xF0], xmm1
000073dfa87d2a3a  vmovaps [rsp+0x120], xmm15
000073dfa87d2a43  movaps xmm1, xmm13
000073dfa87d2a47  addpd xmm1, xmm2
000073dfa87d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000073dfa87d2a50  ptest xmm15, xmm15
000073dfa87d2a56  jnz 0x000073DFA87D43CF
000073dfa87d2a5c  lea rax, [r14+0xF0]
000073dfa87d2a63  movups xmm15, [r13+rax*1]
000073dfa87d2a69  vmovaps xmm2, [rsp+0xE0]
000073dfa87d2a72  vmovaps [rsp+0xE0], xmm1
000073dfa87d2a7b  vmovaps xmm1, [rsp+0xD0]
000073dfa87d2a84  vmovaps [rsp+0xD0], xmm15
000073dfa87d2a8d  movaps xmm13, xmm2
000073dfa87d2a91  addpd xmm13, xmm1
000073dfa87d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000073dfa87d2a9c  ptest xmm15, xmm15
000073dfa87d2aa2  jnz 0x000073DFA87D451A
000073dfa87d2aa8  vmovaps xmm15, [rsp+0xC0]
000073dfa87d2ab1  movaps xmm1, xmm14
000073dfa87d2ab5  addpd xmm1, xmm15
000073dfa87d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000073dfa87d2abf  ptest xmm2, xmm2
000073dfa87d2ac4  jnz 0x000073DFA87D465C
000073dfa87d2aca  vmovaps xmm15, [rsp+0x100]
000073dfa87d2ad3  vpermilpd xmm15, xmm15, 0x00
000073dfa87d2ad9  vmovaps xmm2, [rsp+0xF0]
000073dfa87d2ae2  vmovaps [rsp+0xC0], xmm1
000073dfa87d2aeb  movaps xmm14, xmm2
000073dfa87d2aef  mulpd xmm14, xmm15
000073dfa87d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000073dfa87d2afa  ptest xmm1, xmm1
000073dfa87d2aff  jnz 0x000073DFA87D479E
000073dfa87d2b05  vmovaps xmm1, [rsp+0xA0]
000073dfa87d2b0e  vpermilpd xmm1, xmm1, 0x00
000073dfa87d2b14  vmovaps xmm2, [rsp+0xD0]
000073dfa87d2b1d  vmovaps [rsp+0xD0], xmm14
000073dfa87d2b26  movaps xmm15, xmm2
000073dfa87d2b2a  mulpd xmm15, xmm1
000073dfa87d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000073dfa87d2b35  ptest xmm14, xmm14
000073dfa87d2b3b  jnz 0x000073DFA87D48E1
000073dfa87d2b41  lea rax, [r14+0xE0]
000073dfa87d2b48  movups xmm1, [r13+rax*1]
000073dfa87d2b4e  vmovaps xmm14, [rsp+0x100]
000073dfa87d2b57  vpermilpd xmm14, xmm14, 0x00
000073dfa87d2b5d  vmovaps [rsp+0xF0], xmm1
000073dfa87d2b66  vmovaps xmm1, [rsp+0x20]
000073dfa87d2b6c  vmovaps [rsp+0x20], xmm15
000073dfa87d2b72  movaps xmm2, xmm1
000073dfa87d2b75  mulpd xmm2, xmm14
000073dfa87d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000073dfa87d2b7f  ptest xmm15, xmm15
000073dfa87d2b85  jnz 0x000073DFA87D4A2D
000073dfa87d2b8b  vmovaps [rsp+0x100], xmm10
000073dfa87d2b94  vmovaps xmm1, [rsp+0x100]
000073dfa87d2b9d  por xmm10, xmm1
000073dfa87d2ba2  movaps [r15+0x300], xmm10
000073dfa87d2baa  vmovaps [rsp+0x100], xmm8
000073dfa87d2bb3  vmovaps xmm1, [rsp+0x100]
000073dfa87d2bbc  por xmm8, xmm1
000073dfa87d2bc1  movaps [r15+0x190], xmm8
000073dfa87d2bc9  vmovaps xmm1, [rsp+0xA0]
000073dfa87d2bd2  vpermilpd xmm1, xmm1, 0x00
000073dfa87d2bd8  vmovaps xmm14, [rsp+0xF0]
000073dfa87d2be1  vmovaps [rsp+0xF0], xmm13
000073dfa87d2bea  movaps xmm15, xmm14
000073dfa87d2bee  mulpd xmm15, xmm1
000073dfa87d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000073dfa87d2bf9  ptest xmm13, xmm13
000073dfa87d2bff  jnz 0x000073DFA87D4B6E
000073dfa87d2c05  lea rax, [r14+0x90]
000073dfa87d2c0c  movups xmm1, [r13+rax*1]
000073dfa87d2c12  vmovaps [rsp+0x100], xmm4
000073dfa87d2c1b  vmovaps xmm14, [rsp+0x100]
000073dfa87d2c24  por xmm4, xmm14
000073dfa87d2c29  movaps [r15+0x1C0], xmm4
000073dfa87d2c31  vmovaps [rsp+0x100], xmm11
000073dfa87d2c3a  vmovaps xmm14, [rsp+0x100]
000073dfa87d2c43  por xmm11, xmm14
000073dfa87d2c48  movaps [r15+0x200], xmm11
000073dfa87d2c50  vmovaps [rsp+0x100], xmm5
000073dfa87d2c59  vmovaps xmm14, [rsp+0x100]
000073dfa87d2c62  por xmm5, xmm14
000073dfa87d2c67  movaps [r15+0x2D0], xmm5
000073dfa87d2c6f  vmovaps xmm14, [rsp+0x120]
000073dfa87d2c78  vmovaps xmm13, [rsp+0x120]
000073dfa87d2c81  por xmm14, xmm13
000073dfa87d2c86  movaps [r15+0x2E0], xmm14
000073dfa87d2c8e  vmovaps [rsp+0x100], xmm1
000073dfa87d2c97  vmovaps xmm1, [rsp+0x110]
000073dfa87d2ca0  vmovaps [rsp+0x110], xmm15
000073dfa87d2ca9  vmovaps xmm15, [rsp+0xD0]
000073dfa87d2cb2  vmovaps [rsp+0xD0], xmm14
000073dfa87d2cbb  movaps xmm13, xmm1
000073dfa87d2cbf  addpd xmm13, xmm15
000073dfa87d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000073dfa87d2cca  ptest xmm14, xmm14
000073dfa87d2cd0  jnz 0x000073DFA87D4CBB
000073dfa87d2cd6  vmovaps xmm1, [rsp+0xA0]
000073dfa87d2cdf  vpermilpd xmm1, xmm1, 0x00
000073dfa87d2ce5  vmovaps xmm14, [rsp+0x100]
000073dfa87d2cee  vmovaps [rsp+0x100], xmm13
000073dfa87d2cf7  movaps xmm15, xmm14
000073dfa87d2cfb  mulpd xmm15, xmm1
000073dfa87d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000073dfa87d2d06  ptest xmm13, xmm13
000073dfa87d2d0c  jnz 0x000073DFA87D4DFE
000073dfa87d2d12  lea rax, [r14+0x80]
000073dfa87d2d19  movups xmm1, [r13+rax*1]
000073dfa87d2d1f  vmovaps xmm13, [rsp+0xE0]
000073dfa87d2d28  vmovaps [rsp+0xE0], xmm1
000073dfa87d2d31  movaps xmm14, xmm13
000073dfa87d2d35  addpd xmm14, xmm2
000073dfa87d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000073dfa87d2d40  ptest xmm1, xmm1
000073dfa87d2d45  jnz 0x000073DFA87D4F4B
000073dfa87d2d4b  vmovaps xmm13, [rsp+0xF0]
000073dfa87d2d54  vmovaps xmm2, [rsp+0x20]
000073dfa87d2d5a  vmovaps [rsp+0x20], xmm15
000073dfa87d2d60  movaps xmm1, xmm13
000073dfa87d2d64  addpd xmm1, xmm2
000073dfa87d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000073dfa87d2d6d  ptest xmm15, xmm15
000073dfa87d2d73  jnz 0x000073DFA87D508E
000073dfa87d2d79  vmovaps xmm15, [rsp+0x10]
000073dfa87d2d7f  vmovaps xmm13, [rsp+0x10]
000073dfa87d2d85  por xmm15, xmm13
000073dfa87d2d8a  movaps [r15+0x2F0], xmm15
000073dfa87d2d92  vmovaps xmm13, [rsp+0xA0]
000073dfa87d2d9b  vpermilpd xmm13, xmm13, 0x00
000073dfa87d2da1  vmovaps [rsp+0x10], xmm1
000073dfa87d2da7  vmovaps xmm1, [rsp+0xE0]
000073dfa87d2db0  vmovaps [rsp+0xA0], xmm15
000073dfa87d2db9  movaps xmm2, xmm1
000073dfa87d2dbc  mulpd xmm2, xmm13
000073dfa87d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000073dfa87d2dc6  ptest xmm15, xmm15
000073dfa87d2dcc  jnz 0x000073DFA87D51CF
000073dfa87d2dd2  lea rax, [r14+0xD0]
000073dfa87d2dd9  movups xmm1, [r13+rax*1]
000073dfa87d2ddf  vmovaps xmm13, [rsp+0xC0]
000073dfa87d2de8  vmovaps [rsp+0xC0], xmm1
000073dfa87d2df1  vmovaps xmm1, [rsp+0x110]
000073dfa87d2dfa  vmovaps [rsp+0xE0], xmm14
000073dfa87d2e03  movaps xmm15, xmm13
000073dfa87d2e07  addpd xmm15, xmm1
000073dfa87d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000073dfa87d2e12  ptest xmm14, xmm14
000073dfa87d2e18  jnz 0x000073DFA87D531A
000073dfa87d2e1e  vmovaps xmm1, [rsp+0xB0]
000073dfa87d2e27  vpermilpd xmm1, xmm1, 0x00
000073dfa87d2e2d  movaps xmm14, xmm11
000073dfa87d2e31  mulpd xmm14, xmm1
000073dfa87d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000073dfa87d2e3c  ptest xmm13, xmm13
000073dfa87d2e42  jnz 0x000073DFA87D545D
000073dfa87d2e48  movaps [r15+0x260], xmm14
000073dfa87d2e50  vxorps xmm1, xmm1, xmm1
000073dfa87d2e54  vpbroadcastq xmm1, xmm1
000073dfa87d2e59  movaps [r15+0x1B0], xmm1
000073dfa87d2e61  vmovaps xmm1, [rsp+0xB0]
000073dfa87d2e6a  vpermilpd xmm1, xmm1, 0x00
000073dfa87d2e70  vmovaps xmm11, [rsp+0xC0]
000073dfa87d2e79  vmovaps [rsp+0xC0], xmm15
000073dfa87d2e82  movaps xmm13, xmm11
000073dfa87d2e86  mulpd xmm13, xmm1
000073dfa87d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000073dfa87d2e91  ptest xmm15, xmm15
000073dfa87d2e97  jnz 0x000073DFA87D55A0
000073dfa87d2e9d  lea rax, [r14+0xC0]
000073dfa87d2ea4  movups xmm1, [r13+rax*1]
000073dfa87d2eaa  vmovaps xmm11, [rsp+0x100]
000073dfa87d2eb3  vmovaps [rsp+0xF0], xmm1
000073dfa87d2ebc  vmovaps xmm1, [rsp+0x20]
000073dfa87d2ec2  vmovaps [rsp+0x20], xmm14
000073dfa87d2ec8  movaps xmm15, xmm11
000073dfa87d2ecc  addpd xmm15, xmm1
000073dfa87d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000073dfa87d2ed7  ptest xmm14, xmm14
000073dfa87d2edd  jnz 0x000073DFA87D56ED
000073dfa87d2ee3  vmovaps [rsp+0x100], xmm9
000073dfa87d2eec  vmovaps xmm1, [rsp+0x100]
000073dfa87d2ef5  por xmm9, xmm1
000073dfa87d2efa  movaps [r15+0x270], xmm9
000073dfa87d2f02  vmovaps [rsp+0x100], xmm6
000073dfa87d2f0b  vmovaps xmm1, [rsp+0x100]
000073dfa87d2f14  por xmm6, xmm1
000073dfa87d2f18  movaps [r15+0x1A0], xmm6
000073dfa87d2f20  vmovaps xmm14, [rsp+0xB0]
000073dfa87d2f29  vpermilpd xmm14, xmm14, 0x00
000073dfa87d2f2f  vmovaps xmm6, [rsp+0xF0]
000073dfa87d2f38  vmovaps [rsp+0xF0], xmm1
000073dfa87d2f41  movaps xmm11, xmm6
000073dfa87d2f45  mulpd xmm11, xmm14
000073dfa87d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000073dfa87d2f50  ptest xmm1, xmm1
000073dfa87d2f55  jnz 0x000073DFA87D5830
000073dfa87d2f5b  lea rax, [r14+0x20]
000073dfa87d2f5f  movups xmm1, [r13+rax*1]
000073dfa87d2f65  movaps [r15+0x110], xmm1
000073dfa87d2f6d  vmovaps xmm6, [rsp+0xE0]
000073dfa87d2f76  vmovaps [rsp+0xE0], xmm1
000073dfa87d2f7f  movaps xmm14, xmm6
000073dfa87d2f83  addpd xmm14, xmm2
000073dfa87d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000073dfa87d2f8e  ptest xmm1, xmm1
000073dfa87d2f93  jnz 0x000073DFA87D597D
000073dfa87d2f99  vmovaps xmm1, [rsp+0xB0]
000073dfa87d2fa2  vpermilpd xmm1, xmm1, 0x00
000073dfa87d2fa8  movaps xmm6, xmm5
000073dfa87d2fab  mulpd xmm6, xmm1
000073dfa87d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000073dfa87d2fb4  ptest xmm2, xmm2
000073dfa87d2fb9  jnz 0x000073DFA87D5ABF
000073dfa87d2fbf  vmovaps xmm5, [rsp+0x10]
000073dfa87d2fc5  movaps xmm1, xmm5
000073dfa87d2fc8  addpd xmm1, xmm13
000073dfa87d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000073dfa87d2fd2  ptest xmm2, xmm2
000073dfa87d2fd7  jnz 0x000073DFA87D5BFF
000073dfa87d2fdd  vmovaps xmm13, [rsp+0x80]
000073dfa87d2fe6  vpermilpd xmm13, xmm13, 0x00
000073dfa87d2fec  vmovaps xmm2, [rsp+0xE0]
000073dfa87d2ff5  vmovaps [rsp+0x10], xmm1
000073dfa87d2ffb  movaps xmm5, xmm2
000073dfa87d2ffe  mulpd xmm5, xmm13
000073dfa87d3003  vcmppd xmm1, xmm5, xmm5, 0x03
000073dfa87d3008  ptest xmm1, xmm1
000073dfa87d300d  jnz 0x000073DFA87D5D40
000073dfa87d3013  vmovaps xmm1, [rsp+0x80]
000073dfa87d301c  vpermilpd xmm1, xmm1, 0x00
000073dfa87d3022  movaps xmm13, xmm10
000073dfa87d3026  mulpd xmm13, xmm1
000073dfa87d302b  vcmppd xmm2, xmm13, xmm13, 0x03
000073dfa87d3031  ptest xmm2, xmm2
000073dfa87d3036  jnz 0x000073DFA87D5E81
000073dfa87d303c  vmovaps xmm10, [rsp+0x20]
000073dfa87d3042  movaps xmm1, xmm15
000073dfa87d3046  addpd xmm1, xmm10
000073dfa87d304b  vcmppd xmm2, xmm1, xmm1, 0x03
000073dfa87d3050  ptest xmm2, xmm2
000073dfa87d3055  jnz 0x000073DFA87D5FC4
000073dfa87d305b  vmovaps xmm10, [rsp+0xC0]
000073dfa87d3064  movaps xmm15, xmm10
000073dfa87d3068  addpd xmm15, xmm11
000073dfa87d306d  vcmppd xmm2, xmm15, xmm15, 0x03
000073dfa87d3073  ptest xmm2, xmm2
000073dfa87d3078  jnz 0x000073DFA87D6106
000073dfa87d307e  vmovaps xmm11, [rsp+0x80]
000073dfa87d3087  vpermilpd xmm11, xmm11, 0x00
000073dfa87d308d  vmovaps xmm2, [rsp+0xD0]
000073dfa87d3096  vmovaps [rsp+0x20], xmm1
000073dfa87d309c  movaps xmm10, xmm2
000073dfa87d30a0  mulpd xmm10, xmm11
000073dfa87d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000073dfa87d30ab  ptest xmm1, xmm1
000073dfa87d30b0  jnz 0x000073DFA87D624A
000073dfa87d30b6  vmovaps xmm1, [rsp+0x80]
000073dfa87d30bf  vpermilpd xmm1, xmm1, 0x00
000073dfa87d30c5  vmovaps xmm2, [rsp+0xA0]
000073dfa87d30ce  vmovaps [rsp+0x80], xmm15
000073dfa87d30d7  movaps xmm11, xmm2
000073dfa87d30db  mulpd xmm11, xmm1
000073dfa87d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000073dfa87d30e6  ptest xmm15, xmm15
000073dfa87d30ec  jnz 0x000073DFA87D638D
000073dfa87d30f2  movaps xmm1, xmm14
000073dfa87d30f6  addpd xmm1, xmm6
000073dfa87d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000073dfa87d30ff  ptest xmm15, xmm15
000073dfa87d3105  jnz 0x000073DFA87D64CF
000073dfa87d310b  vmovaps xmm14, [rsp+0x10]
000073dfa87d3111  movaps xmm15, xmm14
000073dfa87d3115  addpd xmm15, xmm5
000073dfa87d311a  vcmppd xmm6, xmm15, xmm15, 0x03
000073dfa87d3120  ptest xmm6, xmm6
000073dfa87d3125  jnz 0x000073DFA87D6610
000073dfa87d312b  vmovaps xmm14, [rsp+0x90]
000073dfa87d3134  vpermilpd xmm14, xmm14, 0x00
000073dfa87d313a  movaps xmm6, xmm9
000073dfa87d313e  mulpd xmm6, xmm14
000073dfa87d3143  vcmppd xmm5, xmm6, xmm6, 0x03
000073dfa87d3148  ptest xmm5, xmm5
000073dfa87d314d  jnz 0x000073DFA87D6753
000073dfa87d3153  vmovaps xmm9, [rsp+0x80]
000073dfa87d315c  movaps xmm14, xmm9
000073dfa87d3160  addpd xmm14, xmm13
000073dfa87d3165  vcmppd xmm5, xmm14, xmm14, 0x03
000073dfa87d316b  ptest xmm5, xmm5
000073dfa87d3170  jnz 0x000073DFA87D6895
000073dfa87d3176  vmovaps xmm9, [rsp+0x20]
000073dfa87d317c  movaps xmm13, xmm9
000073dfa87d3180  addpd xmm13, xmm10
000073dfa87d3185  vcmppd xmm5, xmm13, xmm13, 0x03
000073dfa87d318b  ptest xmm5, xmm5
000073dfa87d3190  jnz 0x000073DFA87D69D9
000073dfa87d3196  vmovaps [rsp+0x10], xmm12
000073dfa87d319c  vmovaps xmm10, [rsp+0x10]
000073dfa87d31a2  por xmm12, xmm10
000073dfa87d31a7  movaps [r15+0x250], xmm12
000073dfa87d31af  vmovaps [rsp+0x10], xmm7
000073dfa87d31b5  vmovaps xmm12, [rsp+0x10]
000073dfa87d31bb  por xmm7, xmm12
000073dfa87d31c0  movaps [r15+0x2A0], xmm7
000073dfa87d31c8  vmovaps [rsp+0x10], xmm3
000073dfa87d31ce  vmovaps xmm12, [rsp+0x10]
000073dfa87d31d4  por xmm3, xmm12
000073dfa87d31d9  movaps [r15+0x1D0], xmm3
000073dfa87d31e1  lea rax, [r14+0x40]
000073dfa87d31e5  movups xmm12, [r13+rax*1]
000073dfa87d31eb  movaps [r15+0x2C0], xmm12
000073dfa87d31f3  vmovaps xmm10, [rsp+0x90]
000073dfa87d31fc  vpermilpd xmm10, xmm10, 0x00
000073dfa87d3202  movaps xmm9, xmm8
000073dfa87d3206  mulpd xmm9, xmm10
000073dfa87d320b  vcmppd xmm5, xmm9, xmm9, 0x03
000073dfa87d3211  ptest xmm5, xmm5
000073dfa87d3216  jnz 0x000073DFA87D6B27
000073dfa87d321c  movaps xmm10, xmm1
000073dfa87d3220  addpd xmm10, xmm11
000073dfa87d3225  vcmppd xmm8, xmm10, xmm10, 0x03
000073dfa87d322b  ptest xmm8, xmm8
000073dfa87d3231  jnz 0x000073DFA87D6C6B
000073dfa87d3237  movaps xmm1, xmm15
000073dfa87d323b  addpd xmm1, xmm6
000073dfa87d323f  vcmppd xmm11, xmm1, xmm1, 0x03
000073dfa87d3244  ptest xmm11, xmm11
000073dfa87d324a  jnz 0x000073DFA87D6DAE
000073dfa87d3250  vmovaps xmm15, [rsp+0x90]
000073dfa87d3259  vpermilpd xmm15, xmm15, 0x00
000073dfa87d325f  movaps xmm11, xmm12
000073dfa87d3263  mulpd xmm11, xmm15
000073dfa87d3268  vcmppd xmm8, xmm11, xmm11, 0x03
000073dfa87d326e  ptest xmm8, xmm8
000073dfa87d3274  jnz 0x000073DFA87D6EEF
000073dfa87d327a  vmovaps xmm15, [rsp+0x90]
000073dfa87d3283  vpermilpd xmm15, xmm15, 0x00
000073dfa87d3289  vmovaps xmm8, [rsp+0x50]
000073dfa87d328f  movaps xmm12, xmm8
000073dfa87d3293  mulpd xmm12, xmm15
000073dfa87d3298  vcmppd xmm6, xmm12, xmm12, 0x03
000073dfa87d329e  ptest xmm6, xmm6
000073dfa87d32a3  jnz 0x000073DFA87D7033
000073dfa87d32a9  vmovaps xmm15, [rsp+0x30]
000073dfa87d32af  vpermilpd xmm15, xmm15, 0x00
000073dfa87d32b5  movaps xmm8, xmm7
000073dfa87d32b9  mulpd xmm8, xmm15
000073dfa87d32be  vcmppd xmm6, xmm8, xmm8, 0x03
000073dfa87d32c4  ptest xmm6, xmm6
000073dfa87d32c9  jnz 0x000073DFA87D7177
000073dfa87d32cf  movaps xmm15, xmm14
000073dfa87d32d3  addpd xmm15, xmm9
000073dfa87d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000073dfa87d32de  ptest xmm7, xmm7
000073dfa87d32e3  jnz 0x000073DFA87D72BA
000073dfa87d32e9  vmovaps xmm14, [rsp+0x30]
000073dfa87d32ef  vpermilpd xmm14, xmm14, 0x00
000073dfa87d32f5  vmovaps xmm7, [rsp+0xF0]
000073dfa87d32fe  movaps xmm9, xmm7
000073dfa87d3302  mulpd xmm9, xmm14
000073dfa87d3307  vcmppd xmm6, xmm9, xmm9, 0x03
000073dfa87d330d  ptest xmm6, xmm6
000073dfa87d3312  jnz 0x000073DFA87D73FE
000073dfa87d3318  movaps xmm14, xmm13
000073dfa87d331c  addpd xmm14, xmm11
000073dfa87d3321  vcmppd xmm7, xmm14, xmm14, 0x03
000073dfa87d3327  ptest xmm7, xmm7
000073dfa87d332c  jnz 0x000073DFA87D7541
000073dfa87d3332  vmovaps xmm13, [rsp+0x30]
000073dfa87d3338  vpermilpd xmm13, xmm13, 0x00
000073dfa87d333e  vmovaps xmm7, [rsp+0x60]
000073dfa87d3344  movaps xmm11, xmm7
000073dfa87d3348  mulpd xmm11, xmm13
000073dfa87d334d  vcmppd xmm6, xmm11, xmm11, 0x03
000073dfa87d3353  ptest xmm6, xmm6
000073dfa87d3358  jnz 0x000073DFA87D7685
000073dfa87d335e  movaps xmm13, xmm10
000073dfa87d3362  addpd xmm13, xmm12
000073dfa87d3367  vcmppd xmm7, xmm13, xmm13, 0x03
000073dfa87d336d  ptest xmm7, xmm7
000073dfa87d3372  jnz 0x000073DFA87D77C8
000073dfa87d3378  vmovaps xmm12, [rsp+0x30]
000073dfa87d337e  vpermilpd xmm12, xmm12, 0x00
000073dfa87d3384  vmovaps xmm7, [rsp+0x70]
000073dfa87d338a  movaps xmm10, xmm7
000073dfa87d338e  mulpd xmm10, xmm12
000073dfa87d3393  vcmppd xmm6, xmm10, xmm10, 0x03
000073dfa87d3399  ptest xmm6, xmm6
000073dfa87d339e  jnz 0x000073DFA87D790C
000073dfa87d33a4  movaps xmm12, xmm1
000073dfa87d33a8  addpd xmm12, xmm8
000073dfa87d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000073dfa87d33b3  ptest xmm7, xmm7
000073dfa87d33b8  jnz 0x000073DFA87D7A4F
000073dfa87d33be  lea rax, [r14+0x70]
000073dfa87d33c2  movups xmm1, [r13+rax*1]
000073dfa87d33c8  movaps [r15+0x240], xmm1
000073dfa87d33d0  movaps xmm8, xmm15
000073dfa87d33d4  addpd xmm8, xmm9
000073dfa87d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000073dfa87d33df  ptest xmm7, xmm7
000073dfa87d33e4  jnz 0x000073DFA87D7B9C
000073dfa87d33ea  movaps [r15+0x170], xmm8
000073dfa87d33f2  vmovaps xmm15, [rsp+0x40]
000073dfa87d33f8  vpermilpd xmm15, xmm15, 0x00
000073dfa87d33fe  movaps xmm9, xmm1
000073dfa87d3402  mulpd xmm9, xmm15
000073dfa87d3407  vcmppd xmm7, xmm9, xmm9, 0x03
000073dfa87d340d  ptest xmm7, xmm7
000073dfa87d3412  jnz 0x000073DFA87D7CE0
000073dfa87d3418  vmovaps xmm1, [rsp+0x40]
000073dfa87d341e  vpermilpd xmm1, xmm1, 0x00
000073dfa87d3424  movaps xmm15, xmm4
000073dfa87d3428  mulpd xmm15, xmm1
000073dfa87d342d  vcmppd xmm7, xmm15, xmm15, 0x03
000073dfa87d3433  ptest xmm7, xmm7
000073dfa87d3438  jnz 0x000073DFA87D7E23
000073dfa87d343e  movaps [r15+0x180], xmm15
000073dfa87d3446  movaps xmm1, xmm14
000073dfa87d344a  addpd xmm1, xmm11
000073dfa87d344f  vcmppd xmm7, xmm1, xmm1, 0x03
000073dfa87d3454  ptest xmm7, xmm7
000073dfa87d3459  jnz 0x000073DFA87D7F65
000073dfa87d345f  movaps [r15+0x210], xmm1
000073dfa87d3467  movups xmm14, [r13+r14*1]
000073dfa87d346d  lea rax, [r14+0x10]
000073dfa87d3471  movups xmm11, [r13+rax*1]
000073dfa87d3477  movaps [r15+0x230], xmm11
000073dfa87d347f  movaps xmm7, xmm13
000073dfa87d3483  addpd xmm7, xmm10
000073dfa87d3488  vcmppd xmm6, xmm7, xmm7, 0x03
000073dfa87d348d  ptest xmm6, xmm6
000073dfa87d3492  jnz 0x000073DFA87D80BB
000073dfa87d3498  movaps [r15+0x130], xmm7
000073dfa87d34a0  vmovaps xmm13, [rsp+0x40]
000073dfa87d34a6  vpermilpd xmm13, xmm13, 0x00
000073dfa87d34ac  movaps xmm10, xmm11
000073dfa87d34b0  mulpd xmm10, xmm13
000073dfa87d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000073dfa87d34bb  ptest xmm6, xmm6
000073dfa87d34c0  jnz 0x000073DFA87D81FD
000073dfa87d34c6  movaps [r15+0x220], xmm10
000073dfa87d34ce  vmovaps xmm13, [rsp+0x40]
000073dfa87d34d4  vpermilpd xmm13, xmm13, 0x00
000073dfa87d34da  movaps xmm11, xmm14
000073dfa87d34de  mulpd xmm11, xmm13
000073dfa87d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000073dfa87d34e9  ptest xmm6, xmm6
000073dfa87d34ee  jnz 0x000073DFA87D8341
000073dfa87d34f4  movaps xmm14, xmm12
000073dfa87d34f8  addpd xmm14, xmm9
000073dfa87d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000073dfa87d3503  ptest xmm13, xmm13
000073dfa87d3509  jnz 0x000073DFA87D8485
000073dfa87d350f  movaps [r15+0x140], xmm14
000073dfa87d3517  movaps xmm13, xmm8
000073dfa87d351b  addpd xmm13, xmm15
000073dfa87d3520  vcmppd xmm12, xmm13, xmm13, 0x03
000073dfa87d3526  ptest xmm12, xmm12
000073dfa87d352c  jnz 0x000073DFA87D85C9
000073dfa87d3532  movaps [r15+0x150], xmm13
000073dfa87d353a  movaps xmm15, xmm1
000073dfa87d353e  addpd xmm15, xmm10
000073dfa87d3543  vcmppd xmm12, xmm15, xmm15, 0x03
000073dfa87d3549  ptest xmm12, xmm12
000073dfa87d354f  jnz 0x000073DFA87D870D
000073dfa87d3555  movaps [r15+0x160], xmm15
000073dfa87d355d  movaps xmm1, xmm7
000073dfa87d3560  addpd xmm1, xmm11
000073dfa87d3565  vcmppd xmm12, xmm1, xmm1, 0x03
000073dfa87d356a  ptest xmm12, xmm12
000073dfa87d3570  jnz 0x000073DFA87D8850
000073dfa87d3576  movaps [r15+0x120], xmm1
000073dfa87d357e  mov eax, 0x432200
000073dfa87d3583  movups [r13+rax*1], xmm14
000073dfa87d3589  mov eax, 0x432210
000073dfa87d358e  movups [r13+rax*1], xmm13
000073dfa87d3594  mov eax, 0x432220
000073dfa87d3599  movups [r13+rax*1], xmm15
000073dfa87d359f  mov eax, 0x432230
000073dfa87d35a4  movups [r13+rax*1], xmm1
000073dfa87d35aa  mov eax, [r15+0x108]
000073dfa87d35b1  sahf
000073dfa87d35b2  jnz 0x000073DFA87D35E4
000073dfa87d35b4  cmp dword ptr [r15+0x318], 0x00
000073dfa87d35bc  jz 0x000073DFA87DEAE0
000073dfa87d35c2  nop [rax+rax*1], ax
000073dfa87d35cb  nop [rax+rax*1], eax
000073dfa87d35d3  mov eax, 0x4106D0
000073dfa87d35d8  mov [r15+0x100], rax
000073dfa87d35df  jmp 0x000073DFA85FE110
000073dfa87d35e4  cmp dword ptr [r15+0x318], 0x00
000073dfa87d35ec  jz 0x000073DFA87D89C0
000073dfa87d35f2  nop [rax+rax*1], ax
000073dfa87d35fb  nop [rax+rax*1], eax
000073dfa87d3603  mov eax, 0x410504
000073dfa87d3608  mov [r15+0x100], rax
000073dfa87d360f  jmp 0x000073DFA85FE110
000073dfa87d3614  int3
000073dfa87d3615  call 0x000073DFA86D64F0
000073dfa87d361a  jmp 0x000073DFA87D2311
000073dfa87d361f  call 0x000073DFA86E5820
000073dfa87d3624  jmp 0x000073DFA87D231E
000073dfa87d3629  call 0x000073DFA86E3320
000073dfa87d362e  jmp 0x000073DFA87D2332
000073dfa87d3633  call 0x000073DFA86E20A0
000073dfa87d3638  jmp 0x000073DFA87D233C
000073dfa87d363d  call 0x000073DFA8609D70
000073dfa87d3642  jmp 0x000073DFA87D234A
000073dfa87d3647  call 0x000073DFA86DFBC0
000073dfa87d364c  jmp 0x000073DFA87D2354
000073dfa87d3651  call 0x000073DFA86C4740
000073dfa87d3656  jmp 0x000073DFA87D2368
000073dfa87d365b  call 0x000073DFA86B5400
000073dfa87d3660  jmp 0x000073DFA87D2375
000073dfa87d3665  call 0x000073DFA86B52F0
000073dfa87d366a  jmp 0x000073DFA87D2382
000073dfa87d366f  call 0x000073DFA86C4620
000073dfa87d3674  jmp 0x000073DFA87D238F
000073dfa87d3679  call 0x000073DFA86BD750
000073dfa87d367e  jmp 0x000073DFA87D239C
000073dfa87d3683  call 0x000073DFA86BC4E0
000073dfa87d3688  jmp 0x000073DFA87D23A9
000073dfa87d368d  call 0x000073DFA86BB270
000073dfa87d3692  jmp 0x000073DFA87D23B6
000073dfa87d3697  call 0x000073DFA86BA000
000073dfa87d369c  jmp 0x000073DFA87D23C3
000073dfa87d36a1  call 0x000073DFA86C4740
000073dfa87d36a6  jmp 0x000073DFA87D23D0
000073dfa87d36ab  call 0x000073DFA86B5400
000073dfa87d36b0  jmp 0x000073DFA87D23DD
000073dfa87d36b5  call 0x000073DFA86B52F0
000073dfa87d36ba  jmp 0x000073DFA87D23EA
000073dfa87d36bf  call 0x000073DFA86C4620
000073dfa87d36c4  jmp 0x000073DFA87D23F7
000073dfa87d36c9  call 0x000073DFA86B8D90
000073dfa87d36ce  jmp 0x000073DFA87D2404
000073dfa87d36d3  call 0x000073DFA86B8A20
000073dfa87d36d8  jmp 0x000073DFA87D2411
000073dfa87d36dd  call 0x000073DFA86B77B0
000073dfa87d36e2  jmp 0x000073DFA87D241B
000073dfa87d36e7  call 0x000073DFA86B6550
000073dfa87d36ec  jmp 0x000073DFA87D2425
000073dfa87d36f1  call 0x000073DFA86B5400
000073dfa87d36f6  jmp 0x000073DFA87D2437
000073dfa87d36fb  call 0x000073DFA86C0FC0
000073dfa87d3700  jmp 0x000073DFA87D2441
000073dfa87d3705  call 0x000073DFA86B52F0
000073dfa87d370a  jmp 0x000073DFA87D244B
000073dfa87d370f  call 0x000073DFA86C0EA0
000073dfa87d3714  jmp 0x000073DFA87D2455
000073dfa87d3719  call 0x000073DFA86BFD50
000073dfa87d371e  jmp 0x000073DFA87D245F
000073dfa87d3723  call 0x000073DFA86B8EA0
000073dfa87d3728  jmp 0x000073DFA87D2469
000073dfa87d372d  call 0x000073DFA86BFC30
000073dfa87d3732  jmp 0x000073DFA87D2476
000073dfa87d3737  call 0x000073DFA86B8D90
000073dfa87d373c  jmp 0x000073DFA87D2483
000073dfa87d3741  call 0x000073DFA86B52F0
000073dfa87d3746  jmp 0x000073DFA87D2496
000073dfa87d374b  call 0x000073DFA86B52F0
000073dfa87d3750  jmp 0x000073DFA87D24A9
000073dfa87d3755  call 0x000073DFA86C0FC0
000073dfa87d375a  jmp 0x000073DFA87D24B6
000073dfa87d375f  call 0x000073DFA86C0FC0
000073dfa87d3764  jmp 0x000073DFA87D24C9
000073dfa87d3769  call 0x000073DFA86C0EA0
000073dfa87d376e  jmp 0x000073DFA87D24D6
000073dfa87d3773  call 0x000073DFA86B52F0
000073dfa87d3778  jmp 0x000073DFA87D24E9
000073dfa87d377d  call 0x000073DFA86B52F0
000073dfa87d3782  jmp 0x000073DFA87D24FC
000073dfa87d3787  call 0x000073DFA86B52F0
000073dfa87d378c  jmp 0x000073DFA87D250F
000073dfa87d3791  call 0x000073DFA86B52F0
000073dfa87d3796  jmp 0x000073DFA87D252A
000073dfa87d379b  call 0x000073DFA86B52F0
000073dfa87d37a0  jmp 0x000073DFA87D253D
000073dfa87d37a5  call 0x000073DFA86B5400
000073dfa87d37aa  jmp 0x000073DFA87D257E
000073dfa87d37af  call 0x000073DFA86C0FC0
000073dfa87d37b4  jmp 0x000073DFA87D258B
000073dfa87d37b9  call 0x000073DFA86B52F0
000073dfa87d37be  jmp 0x000073DFA87D2598
000073dfa87d37c3  call 0x000073DFA86C0EA0
000073dfa87d37c8  jmp 0x000073DFA87D25A5
000073dfa87d37cd  call 0x000073DFA85FF540
000073dfa87d37d2  jmp 0x000073DFA87D25C3
000073dfa87d37d7  call 0x000073DFA8608C20
000073dfa87d37dc  jmp 0x000073DFA87D25CD
000073dfa87d37e1  call 0x000073DFA86E21C0
000073dfa87d37e6  jmp 0x000073DFA87D25D3
000073dfa87d37eb  call 0x000073DFA85FF540
000073dfa87d37f0  jmp 0x000073DFA87D25E3
000073dfa87d37f5  call 0x000073DFA86C0370
000073dfa87d37fa  jmp 0x000073DFA87D2611
000073dfa87d37ff  call 0x000073DFA86BF100
000073dfa87d3804  jmp 0x000073DFA87D261A
000073dfa87d3809  call 0x000073DFA86C0370
000073dfa87d380e  jmp 0x000073DFA87D2674
000073dfa87d3813  call 0x000073DFA86BF100
000073dfa87d3818  jmp 0x000073DFA87D267D
000073dfa87d381d  call 0x000073DFA86C0370
000073dfa87d3822  jmp 0x000073DFA87D26C6
000073dfa87d3827  call 0x000073DFA86BF100
000073dfa87d382c  jmp 0x000073DFA87D26CF
000073dfa87d3831  call 0x000073DFA860B720
000073dfa87d3836  jmp 0x000073DFA87D2714
000073dfa87d383b  call 0x000073DFA86B47C0
000073dfa87d3840  jmp 0x000073DFA87D2727
000073dfa87d3845  call 0x000073DFA8608B00
000073dfa87d384a  jmp 0x000073DFA87D273E
000073dfa87d384f  call 0x000073DFA85FF430
000073dfa87d3854  jmp 0x000073DFA87D2751
000073dfa87d3859  call 0x000073DFA85FF430
000073dfa87d385e  jmp 0x000073DFA87D2764
000073dfa87d3863  sub rsp, 0x08
000073dfa87d3867  push rax
000073dfa87d3868  push rcx
000073dfa87d3869  push rdx
000073dfa87d386a  push rdi
000073dfa87d386b  push rsi
000073dfa87d386c  push r8
000073dfa87d386e  push r9
000073dfa87d3870  push r10
000073dfa87d3872  push r11
000073dfa87d3874  sub rsp, 0xF0
000073dfa87d387b  vmovaps [rsp], xmm0
000073dfa87d3880  vmovaps [rsp+0x10], xmm2
000073dfa87d3886  vmovaps [rsp+0x20], xmm3
000073dfa87d388c  vmovaps [rsp+0x30], xmm4
000073dfa87d3892  vmovaps [rsp+0x40], xmm5
000073dfa87d3898  vmovaps [rsp+0x50], xmm6
000073dfa87d389e  vmovaps [rsp+0x60], xmm7
000073dfa87d38a4  vmovaps [rsp+0x70], xmm8
000073dfa87d38aa  vmovaps [rsp+0x80], xmm9
000073dfa87d38b3  vmovaps [rsp+0x90], xmm10
000073dfa87d38bc  vmovaps [rsp+0xA0], xmm11
000073dfa87d38c5  vmovaps [rsp+0xB0], xmm12
000073dfa87d38ce  vmovaps [rsp+0xC0], xmm13
000073dfa87d38d7  vmovaps [rsp+0xD0], xmm14
000073dfa87d38e0  vmovaps [rsp+0xE0], xmm15
000073dfa87d38e9  sub rsp, 0x30
000073dfa87d38ed  movaps [rsp], xmm1
000073dfa87d38f1  movaps [rsp+0x10], xmm12
000073dfa87d38f7  movaps [rsp+0x20], xmm15
000073dfa87d38fd  lea rdi, [rsp]
000073dfa87d3901  mov esi, 0x00
000073dfa87d3906  mov rax, 0x593AA1DA4530
000073dfa87d3910  call rax
000073dfa87d3912  movaps xmm1, [rsp]
000073dfa87d3916  add rsp, 0x30
000073dfa87d391a  vmovaps xmm0, [rsp]
000073dfa87d391f  vmovaps xmm2, [rsp+0x10]
000073dfa87d3925  vmovaps xmm3, [rsp+0x20]
000073dfa87d392b  vmovaps xmm4, [rsp+0x30]
000073dfa87d3931  vmovaps xmm5, [rsp+0x40]
000073dfa87d3937  vmovaps xmm6, [rsp+0x50]
000073dfa87d393d  vmovaps xmm7, [rsp+0x60]
000073dfa87d3943  vmovaps xmm8, [rsp+0x70]
000073dfa87d3949  vmovaps xmm9, [rsp+0x80]
000073dfa87d3952  vmovaps xmm10, [rsp+0x90]
000073dfa87d395b  vmovaps xmm11, [rsp+0xA0]
000073dfa87d3964  vmovaps xmm12, [rsp+0xB0]
000073dfa87d396d  vmovaps xmm13, [rsp+0xC0]
000073dfa87d3976  vmovaps xmm14, [rsp+0xD0]
000073dfa87d397f  vmovaps xmm15, [rsp+0xE0]
000073dfa87d3988  add rsp, 0xF0
000073dfa87d398f  pop r11
000073dfa87d3991  pop r10
000073dfa87d3993  pop r9
000073dfa87d3995  pop r8
000073dfa87d3997  pop rsi
000073dfa87d3998  pop rdi
000073dfa87d3999  pop rdx
000073dfa87d399a  pop rcx
000073dfa87d399b  pop rax
000073dfa87d399c  add rsp, 0x08
000073dfa87d39a0  jmp 0x000073DFA87D27B2
000073dfa87d39a5  sub rsp, 0x08
000073dfa87d39a9  push rax
000073dfa87d39aa  push rcx
000073dfa87d39ab  push rdx
000073dfa87d39ac  push rdi
000073dfa87d39ad  push rsi
000073dfa87d39ae  push r8
000073dfa87d39b0  push r9
000073dfa87d39b2  push r10
000073dfa87d39b4  push r11
000073dfa87d39b6  sub rsp, 0xF0
000073dfa87d39bd  vmovaps [rsp], xmm0
000073dfa87d39c2  vmovaps [rsp+0x10], xmm1
000073dfa87d39c8  vmovaps [rsp+0x20], xmm2
000073dfa87d39ce  vmovaps [rsp+0x30], xmm3
000073dfa87d39d4  vmovaps [rsp+0x40], xmm4
000073dfa87d39da  vmovaps [rsp+0x50], xmm5
000073dfa87d39e0  vmovaps [rsp+0x60], xmm6
000073dfa87d39e6  vmovaps [rsp+0x70], xmm7
000073dfa87d39ec  vmovaps [rsp+0x80], xmm8
000073dfa87d39f5  vmovaps [rsp+0x90], xmm9
000073dfa87d39fe  vmovaps [rsp+0xA0], xmm10
000073dfa87d3a07  vmovaps [rsp+0xB0], xmm11
000073dfa87d3a10  vmovaps [rsp+0xC0], xmm12
000073dfa87d3a19  vmovaps [rsp+0xD0], xmm13
000073dfa87d3a22  vmovaps [rsp+0xE0], xmm15
000073dfa87d3a2b  sub rsp, 0x30
000073dfa87d3a2f  movaps [rsp], xmm14
000073dfa87d3a34  movaps [rsp+0x10], xmm1
000073dfa87d3a39  movaps [rsp+0x20], xmm15
000073dfa87d3a3f  lea rdi, [rsp]
000073dfa87d3a43  mov esi, 0x00
000073dfa87d3a48  mov rax, 0x593AA1DA4530
000073dfa87d3a52  call rax
000073dfa87d3a54  movaps xmm14, [rsp]
000073dfa87d3a59  add rsp, 0x30
000073dfa87d3a5d  vmovaps xmm0, [rsp]
000073dfa87d3a62  vmovaps xmm1, [rsp+0x10]
000073dfa87d3a68  vmovaps xmm2, [rsp+0x20]
000073dfa87d3a6e  vmovaps xmm3, [rsp+0x30]
000073dfa87d3a74  vmovaps xmm4, [rsp+0x40]
000073dfa87d3a7a  vmovaps xmm5, [rsp+0x50]
000073dfa87d3a80  vmovaps xmm6, [rsp+0x60]
000073dfa87d3a86  vmovaps xmm7, [rsp+0x70]
000073dfa87d3a8c  vmovaps xmm8, [rsp+0x80]
000073dfa87d3a95  vmovaps xmm9, [rsp+0x90]
000073dfa87d3a9e  vmovaps xmm10, [rsp+0xA0]
000073dfa87d3aa7  vmovaps xmm11, [rsp+0xB0]
000073dfa87d3ab0  vmovaps xmm12, [rsp+0xC0]
000073dfa87d3ab9  vmovaps xmm13, [rsp+0xD0]
000073dfa87d3ac2  vmovaps xmm15, [rsp+0xE0]
000073dfa87d3acb  add rsp, 0xF0
000073dfa87d3ad2  pop r11
000073dfa87d3ad4  pop r10
000073dfa87d3ad6  pop r9
000073dfa87d3ad8  pop r8
000073dfa87d3ada  pop rsi
000073dfa87d3adb  pop rdi
000073dfa87d3adc  pop rdx
000073dfa87d3add  pop rcx
000073dfa87d3ade  pop rax
000073dfa87d3adf  add rsp, 0x08
000073dfa87d3ae3  jmp 0x000073DFA87D2800
000073dfa87d3ae8  sub rsp, 0x08
000073dfa87d3aec  push rax
000073dfa87d3aed  push rcx
000073dfa87d3aee  push rdx
000073dfa87d3aef  push rdi
000073dfa87d3af0  push rsi
000073dfa87d3af1  push r8
000073dfa87d3af3  push r9
000073dfa87d3af5  push r10
000073dfa87d3af7  push r11
000073dfa87d3af9  sub rsp, 0xF0
000073dfa87d3b00  vmovaps [rsp], xmm0
000073dfa87d3b05  vmovaps [rsp+0x10], xmm1
000073dfa87d3b0b  vmovaps [rsp+0x20], xmm2
000073dfa87d3b11  vmovaps [rsp+0x30], xmm3
000073dfa87d3b17  vmovaps [rsp+0x40], xmm4
000073dfa87d3b1d  vmovaps [rsp+0x50], xmm5
000073dfa87d3b23  vmovaps [rsp+0x60], xmm6
000073dfa87d3b29  vmovaps [rsp+0x70], xmm7
000073dfa87d3b2f  vmovaps [rsp+0x80], xmm8
000073dfa87d3b38  vmovaps [rsp+0x90], xmm9
000073dfa87d3b41  vmovaps [rsp+0xA0], xmm10
000073dfa87d3b4a  vmovaps [rsp+0xB0], xmm11
000073dfa87d3b53  vmovaps [rsp+0xC0], xmm12
000073dfa87d3b5c  vmovaps [rsp+0xD0], xmm13
000073dfa87d3b65  vmovaps [rsp+0xE0], xmm14
000073dfa87d3b6e  sub rsp, 0x30
000073dfa87d3b72  movaps [rsp], xmm15
000073dfa87d3b77  movaps [rsp+0x10], xmm12
000073dfa87d3b7d  movaps [rsp+0x20], xmm13
000073dfa87d3b83  lea rdi, [rsp]
000073dfa87d3b87  mov esi, 0x00
000073dfa87d3b8c  mov rax, 0x593AA1DA4530
000073dfa87d3b96  call rax
000073dfa87d3b98  movaps xmm15, [rsp]
000073dfa87d3b9d  add rsp, 0x30
000073dfa87d3ba1  vmovaps xmm0, [rsp]
000073dfa87d3ba6  vmovaps xmm1, [rsp+0x10]
000073dfa87d3bac  vmovaps xmm2, [rsp+0x20]
000073dfa87d3bb2  vmovaps xmm3, [rsp+0x30]
000073dfa87d3bb8  vmovaps xmm4, [rsp+0x40]
000073dfa87d3bbe  vmovaps xmm5, [rsp+0x50]
000073dfa87d3bc4  vmovaps xmm6, [rsp+0x60]
000073dfa87d3bca  vmovaps xmm7, [rsp+0x70]
000073dfa87d3bd0  vmovaps xmm8, [rsp+0x80]
000073dfa87d3bd9  vmovaps xmm9, [rsp+0x90]
000073dfa87d3be2  vmovaps xmm10, [rsp+0xA0]
000073dfa87d3beb  vmovaps xmm11, [rsp+0xB0]
000073dfa87d3bf4  vmovaps xmm12, [rsp+0xC0]
000073dfa87d3bfd  vmovaps xmm13, [rsp+0xD0]
000073dfa87d3c06  vmovaps xmm14, [rsp+0xE0]
000073dfa87d3c0f  add rsp, 0xF0
000073dfa87d3c16  pop r11
000073dfa87d3c18  pop r10
000073dfa87d3c1a  pop r9
000073dfa87d3c1c  pop r8
000073dfa87d3c1e  pop rsi
000073dfa87d3c1f  pop rdi
000073dfa87d3c20  pop rdx
000073dfa87d3c21  pop rcx
000073dfa87d3c22  pop rax
000073dfa87d3c23  add rsp, 0x08
000073dfa87d3c27  jmp 0x000073DFA87D2835
000073dfa87d3c2c  sub rsp, 0x08
000073dfa87d3c30  push rax
000073dfa87d3c31  push rcx
000073dfa87d3c32  push rdx
000073dfa87d3c33  push rdi
000073dfa87d3c34  push rsi
000073dfa87d3c35  push r8
000073dfa87d3c37  push r9
000073dfa87d3c39  push r10
000073dfa87d3c3b  push r11
000073dfa87d3c3d  sub rsp, 0xF0
000073dfa87d3c44  vmovaps [rsp], xmm0
000073dfa87d3c49  vmovaps [rsp+0x10], xmm2
000073dfa87d3c4f  vmovaps [rsp+0x20], xmm3
000073dfa87d3c55  vmovaps [rsp+0x30], xmm4
000073dfa87d3c5b  vmovaps [rsp+0x40], xmm5
000073dfa87d3c61  vmovaps [rsp+0x50], xmm6
000073dfa87d3c67  vmovaps [rsp+0x60], xmm7
000073dfa87d3c6d  vmovaps [rsp+0x70], xmm8
000073dfa87d3c73  vmovaps [rsp+0x80], xmm9
000073dfa87d3c7c  vmovaps [rsp+0x90], xmm10
000073dfa87d3c85  vmovaps [rsp+0xA0], xmm11
000073dfa87d3c8e  vmovaps [rsp+0xB0], xmm12
000073dfa87d3c97  vmovaps [rsp+0xC0], xmm13
000073dfa87d3ca0  vmovaps [rsp+0xD0], xmm14
000073dfa87d3ca9  vmovaps [rsp+0xE0], xmm15
000073dfa87d3cb2  sub rsp, 0x30
000073dfa87d3cb6  movaps [rsp], xmm1
000073dfa87d3cba  movaps [rsp+0x10], xmm12
000073dfa87d3cc0  movaps [rsp+0x20], xmm10
000073dfa87d3cc6  lea rdi, [rsp]
000073dfa87d3cca  mov esi, 0x00
000073dfa87d3ccf  mov rax, 0x593AA1DA4530
000073dfa87d3cd9  call rax
000073dfa87d3cdb  movaps xmm1, [rsp]
000073dfa87d3cdf  add rsp, 0x30
000073dfa87d3ce3  vmovaps xmm0, [rsp]
000073dfa87d3ce8  vmovaps xmm2, [rsp+0x10]
000073dfa87d3cee  vmovaps xmm3, [rsp+0x20]
000073dfa87d3cf4  vmovaps xmm4, [rsp+0x30]
000073dfa87d3cfa  vmovaps xmm5, [rsp+0x40]
000073dfa87d3d00  vmovaps xmm6, [rsp+0x50]
000073dfa87d3d06  vmovaps xmm7, [rsp+0x60]
000073dfa87d3d0c  vmovaps xmm8, [rsp+0x70]
000073dfa87d3d12  vmovaps xmm9, [rsp+0x80]
000073dfa87d3d1b  vmovaps xmm10, [rsp+0x90]
000073dfa87d3d24  vmovaps xmm11, [rsp+0xA0]
000073dfa87d3d2d  vmovaps xmm12, [rsp+0xB0]
000073dfa87d3d36  vmovaps xmm13, [rsp+0xC0]
000073dfa87d3d3f  vmovaps xmm14, [rsp+0xD0]
000073dfa87d3d48  vmovaps xmm15, [rsp+0xE0]
000073dfa87d3d51  add rsp, 0xF0
000073dfa87d3d58  pop r11
000073dfa87d3d5a  pop r10
000073dfa87d3d5c  pop r9
000073dfa87d3d5e  pop r8
000073dfa87d3d60  pop rsi
000073dfa87d3d61  pop rdi
000073dfa87d3d62  pop rdx
000073dfa87d3d63  pop rcx
000073dfa87d3d64  pop rax
000073dfa87d3d65  add rsp, 0x08
000073dfa87d3d69  jmp 0x000073DFA87D284F
000073dfa87d3d6e  sub rsp, 0x08
000073dfa87d3d72  push rax
000073dfa87d3d73  push rcx
000073dfa87d3d74  push rdx
000073dfa87d3d75  push rdi
000073dfa87d3d76  push rsi
000073dfa87d3d77  push r8
000073dfa87d3d79  push r9
000073dfa87d3d7b  push r10
000073dfa87d3d7d  push r11
000073dfa87d3d7f  sub rsp, 0xF0
000073dfa87d3d86  vmovaps [rsp], xmm0
000073dfa87d3d8b  vmovaps [rsp+0x10], xmm1
000073dfa87d3d91  vmovaps [rsp+0x20], xmm2
000073dfa87d3d97  vmovaps [rsp+0x30], xmm3
000073dfa87d3d9d  vmovaps [rsp+0x40], xmm4
000073dfa87d3da3  vmovaps [rsp+0x50], xmm5
000073dfa87d3da9  vmovaps [rsp+0x60], xmm6
000073dfa87d3daf  vmovaps [rsp+0x70], xmm7
000073dfa87d3db5  vmovaps [rsp+0x80], xmm8
000073dfa87d3dbe  vmovaps [rsp+0x90], xmm9
000073dfa87d3dc7  vmovaps [rsp+0xA0], xmm10
000073dfa87d3dd0  vmovaps [rsp+0xB0], xmm11
000073dfa87d3dd9  vmovaps [rsp+0xC0], xmm12
000073dfa87d3de2  vmovaps [rsp+0xD0], xmm14
000073dfa87d3deb  vmovaps [rsp+0xE0], xmm15
000073dfa87d3df4  sub rsp, 0x30
000073dfa87d3df8  movaps [rsp], xmm13
000073dfa87d3dfd  movaps [rsp+0x10], xmm12
000073dfa87d3e03  movaps [rsp+0x20], xmm2
000073dfa87d3e08  lea rdi, [rsp]
000073dfa87d3e0c  mov esi, 0x00
000073dfa87d3e11  mov rax, 0x593AA1DA4530
000073dfa87d3e1b  call rax
000073dfa87d3e1d  movaps xmm13, [rsp]
000073dfa87d3e22  add rsp, 0x30
000073dfa87d3e26  vmovaps xmm0, [rsp]
000073dfa87d3e2b  vmovaps xmm1, [rsp+0x10]
000073dfa87d3e31  vmovaps xmm2, [rsp+0x20]
000073dfa87d3e37  vmovaps xmm3, [rsp+0x30]
000073dfa87d3e3d  vmovaps xmm4, [rsp+0x40]
000073dfa87d3e43  vmovaps xmm5, [rsp+0x50]
000073dfa87d3e49  vmovaps xmm6, [rsp+0x60]
000073dfa87d3e4f  vmovaps xmm7, [rsp+0x70]
000073dfa87d3e55  vmovaps xmm8, [rsp+0x80]
000073dfa87d3e5e  vmovaps xmm9, [rsp+0x90]
000073dfa87d3e67  vmovaps xmm10, [rsp+0xA0]
000073dfa87d3e70  vmovaps xmm11, [rsp+0xB0]
000073dfa87d3e79  vmovaps xmm12, [rsp+0xC0]
000073dfa87d3e82  vmovaps xmm14, [rsp+0xD0]
000073dfa87d3e8b  vmovaps xmm15, [rsp+0xE0]
000073dfa87d3e94  add rsp, 0xF0
000073dfa87d3e9b  pop r11
000073dfa87d3e9d  pop r10
000073dfa87d3e9f  pop r9
000073dfa87d3ea1  pop r8
000073dfa87d3ea3  pop rsi
000073dfa87d3ea4  pop rdi
000073dfa87d3ea5  pop rdx
000073dfa87d3ea6  pop rcx
000073dfa87d3ea7  pop rax
000073dfa87d3ea8  add rsp, 0x08
000073dfa87d3eac  jmp 0x000073DFA87D286A
000073dfa87d3eb1  sub rsp, 0x08
000073dfa87d3eb5  push rax
000073dfa87d3eb6  push rcx
000073dfa87d3eb7  push rdx
000073dfa87d3eb8  push rdi
000073dfa87d3eb9  push rsi
000073dfa87d3eba  push r8
000073dfa87d3ebc  push r9
000073dfa87d3ebe  push r10
000073dfa87d3ec0  push r11
000073dfa87d3ec2  sub rsp, 0xF0
000073dfa87d3ec9  vmovaps [rsp], xmm0
000073dfa87d3ece  vmovaps [rsp+0x10], xmm2
000073dfa87d3ed4  vmovaps [rsp+0x20], xmm3
000073dfa87d3eda  vmovaps [rsp+0x30], xmm4
000073dfa87d3ee0  vmovaps [rsp+0x40], xmm5
000073dfa87d3ee6  vmovaps [rsp+0x50], xmm6
000073dfa87d3eec  vmovaps [rsp+0x60], xmm7
000073dfa87d3ef2  vmovaps [rsp+0x70], xmm8
000073dfa87d3ef8  vmovaps [rsp+0x80], xmm9
000073dfa87d3f01  vmovaps [rsp+0x90], xmm10
000073dfa87d3f0a  vmovaps [rsp+0xA0], xmm11
000073dfa87d3f13  vmovaps [rsp+0xB0], xmm12
000073dfa87d3f1c  vmovaps [rsp+0xC0], xmm13
000073dfa87d3f25  vmovaps [rsp+0xD0], xmm14
000073dfa87d3f2e  vmovaps [rsp+0xE0], xmm15
000073dfa87d3f37  sub rsp, 0x30
000073dfa87d3f3b  movaps [rsp], xmm1
000073dfa87d3f3f  movaps [rsp+0x10], xmm10
000073dfa87d3f45  movaps [rsp+0x20], xmm2
000073dfa87d3f4a  lea rdi, [rsp]
000073dfa87d3f4e  mov esi, 0x00
000073dfa87d3f53  mov rax, 0x593AA1DA4530
000073dfa87d3f5d  call rax
000073dfa87d3f5f  movaps xmm1, [rsp]
000073dfa87d3f63  add rsp, 0x30
000073dfa87d3f67  vmovaps xmm0, [rsp]
000073dfa87d3f6c  vmovaps xmm2, [rsp+0x10]
000073dfa87d3f72  vmovaps xmm3, [rsp+0x20]
000073dfa87d3f78  vmovaps xmm4, [rsp+0x30]
000073dfa87d3f7e  vmovaps xmm5, [rsp+0x40]
000073dfa87d3f84  vmovaps xmm6, [rsp+0x50]
000073dfa87d3f8a  vmovaps xmm7, [rsp+0x60]
000073dfa87d3f90  vmovaps xmm8, [rsp+0x70]
000073dfa87d3f96  vmovaps xmm9, [rsp+0x80]
000073dfa87d3f9f  vmovaps xmm10, [rsp+0x90]
000073dfa87d3fa8  vmovaps xmm11, [rsp+0xA0]
000073dfa87d3fb1  vmovaps xmm12, [rsp+0xB0]
000073dfa87d3fba  vmovaps xmm13, [rsp+0xC0]
000073dfa87d3fc3  vmovaps xmm14, [rsp+0xD0]
000073dfa87d3fcc  vmovaps xmm15, [rsp+0xE0]
000073dfa87d3fd5  add rsp, 0xF0
000073dfa87d3fdc  pop r11
000073dfa87d3fde  pop r10
000073dfa87d3fe0  pop r9
000073dfa87d3fe2  pop r8
000073dfa87d3fe4  pop rsi
000073dfa87d3fe5  pop rdi
000073dfa87d3fe6  pop rdx
000073dfa87d3fe7  pop rcx
000073dfa87d3fe8  pop rax
000073dfa87d3fe9  add rsp, 0x08
000073dfa87d3fed  jmp 0x000073DFA87D28D2
000073dfa87d3ff2  sub rsp, 0x08
000073dfa87d3ff6  push rax
000073dfa87d3ff7  push rcx
000073dfa87d3ff8  push rdx
000073dfa87d3ff9  push rdi
000073dfa87d3ffa  push rsi
000073dfa87d3ffb  push r8
000073dfa87d3ffd  push r9
000073dfa87d3fff  push r10
000073dfa87d4001  push r11
000073dfa87d4003  sub rsp, 0xF0
000073dfa87d400a  vmovaps [rsp], xmm0
000073dfa87d400f  vmovaps [rsp+0x10], xmm1
000073dfa87d4015  vmovaps [rsp+0x20], xmm2
000073dfa87d401b  vmovaps [rsp+0x30], xmm3
000073dfa87d4021  vmovaps [rsp+0x40], xmm4
000073dfa87d4027  vmovaps [rsp+0x50], xmm5
000073dfa87d402d  vmovaps [rsp+0x60], xmm6
000073dfa87d4033  vmovaps [rsp+0x70], xmm7
000073dfa87d4039  vmovaps [rsp+0x80], xmm8
000073dfa87d4042  vmovaps [rsp+0x90], xmm9
000073dfa87d404b  vmovaps [rsp+0xA0], xmm10
000073dfa87d4054  vmovaps [rsp+0xB0], xmm11
000073dfa87d405d  vmovaps [rsp+0xC0], xmm12
000073dfa87d4066  vmovaps [rsp+0xD0], xmm13
000073dfa87d406f  vmovaps [rsp+0xE0], xmm14
000073dfa87d4078  sub rsp, 0x30
000073dfa87d407c  movaps [rsp], xmm15
000073dfa87d4081  movaps [rsp+0x10], xmm10
000073dfa87d4087  movaps [rsp+0x20], xmm2
000073dfa87d408c  lea rdi, [rsp]
000073dfa87d4090  mov esi, 0x00
000073dfa87d4095  mov rax, 0x593AA1DA4530
000073dfa87d409f  call rax
000073dfa87d40a1  movaps xmm15, [rsp]
000073dfa87d40a6  add rsp, 0x30
000073dfa87d40aa  vmovaps xmm0, [rsp]
000073dfa87d40af  vmovaps xmm1, [rsp+0x10]
000073dfa87d40b5  vmovaps xmm2, [rsp+0x20]
000073dfa87d40bb  vmovaps xmm3, [rsp+0x30]
000073dfa87d40c1  vmovaps xmm4, [rsp+0x40]
000073dfa87d40c7  vmovaps xmm5, [rsp+0x50]
000073dfa87d40cd  vmovaps xmm6, [rsp+0x60]
000073dfa87d40d3  vmovaps xmm7, [rsp+0x70]
000073dfa87d40d9  vmovaps xmm8, [rsp+0x80]
000073dfa87d40e2  vmovaps xmm9, [rsp+0x90]
000073dfa87d40eb  vmovaps xmm10, [rsp+0xA0]
000073dfa87d40f4  vmovaps xmm11, [rsp+0xB0]
000073dfa87d40fd  vmovaps xmm12, [rsp+0xC0]
000073dfa87d4106  vmovaps xmm13, [rsp+0xD0]
000073dfa87d410f  vmovaps xmm14, [rsp+0xE0]
000073dfa87d4118  add rsp, 0xF0
000073dfa87d411f  pop r11
000073dfa87d4121  pop r10
000073dfa87d4123  pop r9
000073dfa87d4125  pop r8
000073dfa87d4127  pop rsi
000073dfa87d4128  pop rdi
000073dfa87d4129  pop rdx
000073dfa87d412a  pop rcx
000073dfa87d412b  pop rax
000073dfa87d412c  add rsp, 0x08
000073dfa87d4130  jmp 0x000073DFA87D2924
000073dfa87d4135  sub rsp, 0x08
000073dfa87d4139  push rax
000073dfa87d413a  push rcx
000073dfa87d413b  push rdx
000073dfa87d413c  push rdi
000073dfa87d413d  push rsi
000073dfa87d413e  push r8
000073dfa87d4140  push r9
000073dfa87d4142  push r10
000073dfa87d4144  push r11
000073dfa87d4146  sub rsp, 0xF0
000073dfa87d414d  vmovaps [rsp], xmm0
000073dfa87d4152  vmovaps [rsp+0x10], xmm2
000073dfa87d4158  vmovaps [rsp+0x20], xmm3
000073dfa87d415e  vmovaps [rsp+0x30], xmm4
000073dfa87d4164  vmovaps [rsp+0x40], xmm5
000073dfa87d416a  vmovaps [rsp+0x50], xmm6
000073dfa87d4170  vmovaps [rsp+0x60], xmm7
000073dfa87d4176  vmovaps [rsp+0x70], xmm8
000073dfa87d417c  vmovaps [rsp+0x80], xmm9
000073dfa87d4185  vmovaps [rsp+0x90], xmm10
000073dfa87d418e  vmovaps [rsp+0xA0], xmm11
000073dfa87d4197  vmovaps [rsp+0xB0], xmm12
000073dfa87d41a0  vmovaps [rsp+0xC0], xmm13
000073dfa87d41a9  vmovaps [rsp+0xD0], xmm14
000073dfa87d41b2  vmovaps [rsp+0xE0], xmm15
000073dfa87d41bb  sub rsp, 0x30
000073dfa87d41bf  movaps [rsp], xmm1
000073dfa87d41c3  movaps [rsp+0x10], xmm10
000073dfa87d41c9  movaps [rsp+0x20], xmm15
000073dfa87d41cf  lea rdi, [rsp]
000073dfa87d41d3  mov esi, 0x00
000073dfa87d41d8  mov rax, 0x593AA1DA4530
000073dfa87d41e2  call rax
000073dfa87d41e4  movaps xmm1, [rsp]
000073dfa87d41e8  add rsp, 0x30
000073dfa87d41ec  vmovaps xmm0, [rsp]
000073dfa87d41f1  vmovaps xmm2, [rsp+0x10]
000073dfa87d41f7  vmovaps xmm3, [rsp+0x20]
000073dfa87d41fd  vmovaps xmm4, [rsp+0x30]
000073dfa87d4203  vmovaps xmm5, [rsp+0x40]
000073dfa87d4209  vmovaps xmm6, [rsp+0x50]
000073dfa87d420f  vmovaps xmm7, [rsp+0x60]
000073dfa87d4215  vmovaps xmm8, [rsp+0x70]
000073dfa87d421b  vmovaps xmm9, [rsp+0x80]
000073dfa87d4224  vmovaps xmm10, [rsp+0x90]
000073dfa87d422d  vmovaps xmm11, [rsp+0xA0]
000073dfa87d4236  vmovaps xmm12, [rsp+0xB0]
000073dfa87d423f  vmovaps xmm13, [rsp+0xC0]
000073dfa87d4248  vmovaps xmm14, [rsp+0xD0]
000073dfa87d4251  vmovaps xmm15, [rsp+0xE0]
000073dfa87d425a  add rsp, 0xF0
000073dfa87d4261  pop r11
000073dfa87d4263  pop r10
000073dfa87d4265  pop r9
000073dfa87d4267  pop r8
000073dfa87d4269  pop rsi
000073dfa87d426a  pop rdi
000073dfa87d426b  pop rdx
000073dfa87d426c  pop rcx
000073dfa87d426d  pop rax
000073dfa87d426e  add rsp, 0x08
000073dfa87d4272  jmp 0x000073DFA87D2962
000073dfa87d4277  sub rsp, 0x08
000073dfa87d427b  push rax
000073dfa87d427c  push rcx
000073dfa87d427d  push rdx
000073dfa87d427e  push rdi
000073dfa87d427f  push rsi
000073dfa87d4280  push r8
000073dfa87d4282  push r9
000073dfa87d4284  push r10
000073dfa87d4286  push r11
000073dfa87d4288  sub rsp, 0xF0
000073dfa87d428f  vmovaps [rsp], xmm0
000073dfa87d4294  vmovaps [rsp+0x10], xmm1
000073dfa87d429a  vmovaps [rsp+0x20], xmm2
000073dfa87d42a0  vmovaps [rsp+0x30], xmm3
000073dfa87d42a6  vmovaps [rsp+0x40], xmm4
000073dfa87d42ac  vmovaps [rsp+0x50], xmm5
000073dfa87d42b2  vmovaps [rsp+0x60], xmm6
000073dfa87d42b8  vmovaps [rsp+0x70], xmm7
000073dfa87d42be  vmovaps [rsp+0x80], xmm8
000073dfa87d42c7  vmovaps [rsp+0x90], xmm9
000073dfa87d42d0  vmovaps [rsp+0xA0], xmm10
000073dfa87d42d9  vmovaps [rsp+0xB0], xmm11
000073dfa87d42e2  vmovaps [rsp+0xC0], xmm12
000073dfa87d42eb  vmovaps [rsp+0xD0], xmm13
000073dfa87d42f4  vmovaps [rsp+0xE0], xmm15
000073dfa87d42fd  sub rsp, 0x30
000073dfa87d4301  movaps [rsp], xmm14
000073dfa87d4306  movaps [rsp+0x10], xmm10
000073dfa87d430c  movaps [rsp+0x20], xmm15
000073dfa87d4312  lea rdi, [rsp]
000073dfa87d4316  mov esi, 0x00
000073dfa87d431b  mov rax, 0x593AA1DA4530
000073dfa87d4325  call rax
000073dfa87d4327  movaps xmm14, [rsp]
000073dfa87d432c  add rsp, 0x30
000073dfa87d4330  vmovaps xmm0, [rsp]
000073dfa87d4335  vmovaps xmm1, [rsp+0x10]
000073dfa87d433b  vmovaps xmm2, [rsp+0x20]
000073dfa87d4341  vmovaps xmm3, [rsp+0x30]
000073dfa87d4347  vmovaps xmm4, [rsp+0x40]
000073dfa87d434d  vmovaps xmm5, [rsp+0x50]
000073dfa87d4353  vmovaps xmm6, [rsp+0x60]
000073dfa87d4359  vmovaps xmm7, [rsp+0x70]
000073dfa87d435f  vmovaps xmm8, [rsp+0x80]
000073dfa87d4368  vmovaps xmm9, [rsp+0x90]
000073dfa87d4371  vmovaps xmm10, [rsp+0xA0]
000073dfa87d437a  vmovaps xmm11, [rsp+0xB0]
000073dfa87d4383  vmovaps xmm12, [rsp+0xC0]
000073dfa87d438c  vmovaps xmm13, [rsp+0xD0]
000073dfa87d4395  vmovaps xmm15, [rsp+0xE0]
000073dfa87d439e  add rsp, 0xF0
000073dfa87d43a5  pop r11
000073dfa87d43a7  pop r10
000073dfa87d43a9  pop r9
000073dfa87d43ab  pop r8
000073dfa87d43ad  pop rsi
000073dfa87d43ae  pop rdi
000073dfa87d43af  pop rdx
000073dfa87d43b0  pop rcx
000073dfa87d43b1  pop rax
000073dfa87d43b2  add rsp, 0x08
000073dfa87d43b6  jmp 0x000073DFA87D298E
000073dfa87d43bb  call 0x000073DFA85FF430
000073dfa87d43c0  jmp 0x000073DFA87D2A1E
000073dfa87d43c5  call 0x000073DFA85FF430
000073dfa87d43ca  jmp 0x000073DFA87D2A31
000073dfa87d43cf  sub rsp, 0x08
000073dfa87d43d3  push rax
000073dfa87d43d4  push rcx
000073dfa87d43d5  push rdx
000073dfa87d43d6  push rdi
000073dfa87d43d7  push rsi
000073dfa87d43d8  push r8
000073dfa87d43da  push r9
000073dfa87d43dc  push r10
000073dfa87d43de  push r11
000073dfa87d43e0  sub rsp, 0xF0
000073dfa87d43e7  vmovaps [rsp], xmm0
000073dfa87d43ec  vmovaps [rsp+0x10], xmm2
000073dfa87d43f2  vmovaps [rsp+0x20], xmm3
000073dfa87d43f8  vmovaps [rsp+0x30], xmm4
000073dfa87d43fe  vmovaps [rsp+0x40], xmm5
000073dfa87d4404  vmovaps [rsp+0x50], xmm6
000073dfa87d440a  vmovaps [rsp+0x60], xmm7
000073dfa87d4410  vmovaps [rsp+0x70], xmm8
000073dfa87d4416  vmovaps [rsp+0x80], xmm9
000073dfa87d441f  vmovaps [rsp+0x90], xmm10
000073dfa87d4428  vmovaps [rsp+0xA0], xmm11
000073dfa87d4431  vmovaps [rsp+0xB0], xmm12
000073dfa87d443a  vmovaps [rsp+0xC0], xmm13
000073dfa87d4443  vmovaps [rsp+0xD0], xmm14
000073dfa87d444c  vmovaps [rsp+0xE0], xmm15
000073dfa87d4455  sub rsp, 0x30
000073dfa87d4459  movaps [rsp], xmm1
000073dfa87d445d  movaps [rsp+0x10], xmm13
000073dfa87d4463  movaps [rsp+0x20], xmm2
000073dfa87d4468  lea rdi, [rsp]
000073dfa87d446c  mov esi, 0x00
000073dfa87d4471  mov rax, 0x593AA1DA4530
000073dfa87d447b  call rax
000073dfa87d447d  movaps xmm1, [rsp]
000073dfa87d4481  add rsp, 0x30
000073dfa87d4485  vmovaps xmm0, [rsp]
000073dfa87d448a  vmovaps xmm2, [rsp+0x10]
000073dfa87d4490  vmovaps xmm3, [rsp+0x20]
000073dfa87d4496  vmovaps xmm4, [rsp+0x30]
000073dfa87d449c  vmovaps xmm5, [rsp+0x40]
000073dfa87d44a2  vmovaps xmm6, [rsp+0x50]
000073dfa87d44a8  vmovaps xmm7, [rsp+0x60]
000073dfa87d44ae  vmovaps xmm8, [rsp+0x70]
000073dfa87d44b4  vmovaps xmm9, [rsp+0x80]
000073dfa87d44bd  vmovaps xmm10, [rsp+0x90]
000073dfa87d44c6  vmovaps xmm11, [rsp+0xA0]
000073dfa87d44cf  vmovaps xmm12, [rsp+0xB0]
000073dfa87d44d8  vmovaps xmm13, [rsp+0xC0]
000073dfa87d44e1  vmovaps xmm14, [rsp+0xD0]
000073dfa87d44ea  vmovaps xmm15, [rsp+0xE0]
000073dfa87d44f3  add rsp, 0xF0
000073dfa87d44fa  pop r11
000073dfa87d44fc  pop r10
000073dfa87d44fe  pop r9
000073dfa87d4500  pop r8
000073dfa87d4502  pop rsi
000073dfa87d4503  pop rdi
000073dfa87d4504  pop rdx
000073dfa87d4505  pop rcx
000073dfa87d4506  pop rax
000073dfa87d4507  add rsp, 0x08
000073dfa87d450b  jmp 0x000073DFA87D2A5C
000073dfa87d4510  call 0x000073DFA860E760
000073dfa87d4515  jmp 0x000073DFA87D2A69
000073dfa87d451a  sub rsp, 0x08
000073dfa87d451e  push rax
000073dfa87d451f  push rcx
000073dfa87d4520  push rdx
000073dfa87d4521  push rdi
000073dfa87d4522  push rsi
000073dfa87d4523  push r8
000073dfa87d4525  push r9
000073dfa87d4527  push r10
000073dfa87d4529  push r11
000073dfa87d452b  sub rsp, 0xF0
000073dfa87d4532  vmovaps [rsp], xmm0
000073dfa87d4537  vmovaps [rsp+0x10], xmm1
000073dfa87d453d  vmovaps [rsp+0x20], xmm2
000073dfa87d4543  vmovaps [rsp+0x30], xmm3
000073dfa87d4549  vmovaps [rsp+0x40], xmm4
000073dfa87d454f  vmovaps [rsp+0x50], xmm5
000073dfa87d4555  vmovaps [rsp+0x60], xmm6
000073dfa87d455b  vmovaps [rsp+0x70], xmm7
000073dfa87d4561  vmovaps [rsp+0x80], xmm8
000073dfa87d456a  vmovaps [rsp+0x90], xmm9
000073dfa87d4573  vmovaps [rsp+0xA0], xmm10
000073dfa87d457c  vmovaps [rsp+0xB0], xmm11
000073dfa87d4585  vmovaps [rsp+0xC0], xmm12
000073dfa87d458e  vmovaps [rsp+0xD0], xmm14
000073dfa87d4597  vmovaps [rsp+0xE0], xmm15
000073dfa87d45a0  sub rsp, 0x30
000073dfa87d45a4  movaps [rsp], xmm13
000073dfa87d45a9  movaps [rsp+0x10], xmm2
000073dfa87d45ae  movaps [rsp+0x20], xmm1
000073dfa87d45b3  lea rdi, [rsp]
000073dfa87d45b7  mov esi, 0x00
000073dfa87d45bc  mov rax, 0x593AA1DA4530
000073dfa87d45c6  call rax
000073dfa87d45c8  movaps xmm13, [rsp]
000073dfa87d45cd  add rsp, 0x30
000073dfa87d45d1  vmovaps xmm0, [rsp]
000073dfa87d45d6  vmovaps xmm1, [rsp+0x10]
000073dfa87d45dc  vmovaps xmm2, [rsp+0x20]
000073dfa87d45e2  vmovaps xmm3, [rsp+0x30]
000073dfa87d45e8  vmovaps xmm4, [rsp+0x40]
000073dfa87d45ee  vmovaps xmm5, [rsp+0x50]
000073dfa87d45f4  vmovaps xmm6, [rsp+0x60]
000073dfa87d45fa  vmovaps xmm7, [rsp+0x70]
000073dfa87d4600  vmovaps xmm8, [rsp+0x80]
000073dfa87d4609  vmovaps xmm9, [rsp+0x90]
000073dfa87d4612  vmovaps xmm10, [rsp+0xA0]
000073dfa87d461b  vmovaps xmm11, [rsp+0xB0]
000073dfa87d4624  vmovaps xmm12, [rsp+0xC0]
000073dfa87d462d  vmovaps xmm14, [rsp+0xD0]
000073dfa87d4636  vmovaps xmm15, [rsp+0xE0]
000073dfa87d463f  add rsp, 0xF0
000073dfa87d4646  pop r11
000073dfa87d4648  pop r10
000073dfa87d464a  pop r9
000073dfa87d464c  pop r8
000073dfa87d464e  pop rsi
000073dfa87d464f  pop rdi
000073dfa87d4650  pop rdx
000073dfa87d4651  pop rcx
000073dfa87d4652  pop rax
000073dfa87d4653  add rsp, 0x08
000073dfa87d4657  jmp 0x000073DFA87D2AA8
000073dfa87d465c  sub rsp, 0x08
000073dfa87d4660  push rax
000073dfa87d4661  push rcx
000073dfa87d4662  push rdx
000073dfa87d4663  push rdi
000073dfa87d4664  push rsi
000073dfa87d4665  push r8
000073dfa87d4667  push r9
000073dfa87d4669  push r10
000073dfa87d466b  push r11
000073dfa87d466d  sub rsp, 0xF0
000073dfa87d4674  vmovaps [rsp], xmm0
000073dfa87d4679  vmovaps [rsp+0x10], xmm2
000073dfa87d467f  vmovaps [rsp+0x20], xmm3
000073dfa87d4685  vmovaps [rsp+0x30], xmm4
000073dfa87d468b  vmovaps [rsp+0x40], xmm5
000073dfa87d4691  vmovaps [rsp+0x50], xmm6
000073dfa87d4697  vmovaps [rsp+0x60], xmm7
000073dfa87d469d  vmovaps [rsp+0x70], xmm8
000073dfa87d46a3  vmovaps [rsp+0x80], xmm9
000073dfa87d46ac  vmovaps [rsp+0x90], xmm10
000073dfa87d46b5  vmovaps [rsp+0xA0], xmm11
000073dfa87d46be  vmovaps [rsp+0xB0], xmm12
000073dfa87d46c7  vmovaps [rsp+0xC0], xmm13
000073dfa87d46d0  vmovaps [rsp+0xD0], xmm14
000073dfa87d46d9  vmovaps [rsp+0xE0], xmm15
000073dfa87d46e2  sub rsp, 0x30
000073dfa87d46e6  movaps [rsp], xmm1
000073dfa87d46ea  movaps [rsp+0x10], xmm14
000073dfa87d46f0  movaps [rsp+0x20], xmm15
000073dfa87d46f6  lea rdi, [rsp]
000073dfa87d46fa  mov esi, 0x00
000073dfa87d46ff  mov rax, 0x593AA1DA4530
000073dfa87d4709  call rax
000073dfa87d470b  movaps xmm1, [rsp]
000073dfa87d470f  add rsp, 0x30
000073dfa87d4713  vmovaps xmm0, [rsp]
000073dfa87d4718  vmovaps xmm2, [rsp+0x10]
000073dfa87d471e  vmovaps xmm3, [rsp+0x20]
000073dfa87d4724  vmovaps xmm4, [rsp+0x30]
000073dfa87d472a  vmovaps xmm5, [rsp+0x40]
000073dfa87d4730  vmovaps xmm6, [rsp+0x50]
000073dfa87d4736  vmovaps xmm7, [rsp+0x60]
000073dfa87d473c  vmovaps xmm8, [rsp+0x70]
000073dfa87d4742  vmovaps xmm9, [rsp+0x80]
000073dfa87d474b  vmovaps xmm10, [rsp+0x90]
000073dfa87d4754  vmovaps xmm11, [rsp+0xA0]
000073dfa87d475d  vmovaps xmm12, [rsp+0xB0]
000073dfa87d4766  vmovaps xmm13, [rsp+0xC0]
000073dfa87d476f  vmovaps xmm14, [rsp+0xD0]
000073dfa87d4778  vmovaps xmm15, [rsp+0xE0]
000073dfa87d4781  add rsp, 0xF0
000073dfa87d4788  pop r11
000073dfa87d478a  pop r10
000073dfa87d478c  pop r9
000073dfa87d478e  pop r8
000073dfa87d4790  pop rsi
000073dfa87d4791  pop rdi
000073dfa87d4792  pop rdx
000073dfa87d4793  pop rcx
000073dfa87d4794  pop rax
000073dfa87d4795  add rsp, 0x08
000073dfa87d4799  jmp 0x000073DFA87D2ACA
000073dfa87d479e  sub rsp, 0x08
000073dfa87d47a2  push rax
000073dfa87d47a3  push rcx
000073dfa87d47a4  push rdx
000073dfa87d47a5  push rdi
000073dfa87d47a6  push rsi
000073dfa87d47a7  push r8
000073dfa87d47a9  push r9
000073dfa87d47ab  push r10
000073dfa87d47ad  push r11
000073dfa87d47af  sub rsp, 0xF0
000073dfa87d47b6  vmovaps [rsp], xmm0
000073dfa87d47bb  vmovaps [rsp+0x10], xmm1
000073dfa87d47c1  vmovaps [rsp+0x20], xmm2
000073dfa87d47c7  vmovaps [rsp+0x30], xmm3
000073dfa87d47cd  vmovaps [rsp+0x40], xmm4
000073dfa87d47d3  vmovaps [rsp+0x50], xmm5
000073dfa87d47d9  vmovaps [rsp+0x60], xmm6
000073dfa87d47df  vmovaps [rsp+0x70], xmm7
000073dfa87d47e5  vmovaps [rsp+0x80], xmm8
000073dfa87d47ee  vmovaps [rsp+0x90], xmm9
000073dfa87d47f7  vmovaps [rsp+0xA0], xmm10
000073dfa87d4800  vmovaps [rsp+0xB0], xmm11
000073dfa87d4809  vmovaps [rsp+0xC0], xmm12
000073dfa87d4812  vmovaps [rsp+0xD0], xmm13
000073dfa87d481b  vmovaps [rsp+0xE0], xmm15
000073dfa87d4824  sub rsp, 0x30
000073dfa87d4828  movaps [rsp], xmm14
000073dfa87d482d  movaps [rsp+0x10], xmm2
000073dfa87d4832  movaps [rsp+0x20], xmm15
000073dfa87d4838  lea rdi, [rsp]
000073dfa87d483c  mov esi, 0x00
000073dfa87d4841  mov rax, 0x593AA1DA4530
000073dfa87d484b  call rax
000073dfa87d484d  movaps xmm14, [rsp]
000073dfa87d4852  add rsp, 0x30
000073dfa87d4856  vmovaps xmm0, [rsp]
000073dfa87d485b  vmovaps xmm1, [rsp+0x10]
000073dfa87d4861  vmovaps xmm2, [rsp+0x20]
000073dfa87d4867  vmovaps xmm3, [rsp+0x30]
000073dfa87d486d  vmovaps xmm4, [rsp+0x40]
000073dfa87d4873  vmovaps xmm5, [rsp+0x50]
000073dfa87d4879  vmovaps xmm6, [rsp+0x60]
000073dfa87d487f  vmovaps xmm7, [rsp+0x70]
000073dfa87d4885  vmovaps xmm8, [rsp+0x80]
000073dfa87d488e  vmovaps xmm9, [rsp+0x90]
000073dfa87d4897  vmovaps xmm10, [rsp+0xA0]
000073dfa87d48a0  vmovaps xmm11, [rsp+0xB0]
000073dfa87d48a9  vmovaps xmm12, [rsp+0xC0]
000073dfa87d48b2  vmovaps xmm13, [rsp+0xD0]
000073dfa87d48bb  vmovaps xmm15, [rsp+0xE0]
000073dfa87d48c4  add rsp, 0xF0
000073dfa87d48cb  pop r11
000073dfa87d48cd  pop r10
000073dfa87d48cf  pop r9
000073dfa87d48d1  pop r8
000073dfa87d48d3  pop rsi
000073dfa87d48d4  pop rdi
000073dfa87d48d5  pop rdx
000073dfa87d48d6  pop rcx
000073dfa87d48d7  pop rax
000073dfa87d48d8  add rsp, 0x08
000073dfa87d48dc  jmp 0x000073DFA87D2B05
000073dfa87d48e1  sub rsp, 0x08
000073dfa87d48e5  push rax
000073dfa87d48e6  push rcx
000073dfa87d48e7  push rdx
000073dfa87d48e8  push rdi
000073dfa87d48e9  push rsi
000073dfa87d48ea  push r8
000073dfa87d48ec  push r9
000073dfa87d48ee  push r10
000073dfa87d48f0  push r11
000073dfa87d48f2  sub rsp, 0xF0
000073dfa87d48f9  vmovaps [rsp], xmm0
000073dfa87d48fe  vmovaps [rsp+0x10], xmm1
000073dfa87d4904  vmovaps [rsp+0x20], xmm2
000073dfa87d490a  vmovaps [rsp+0x30], xmm3
000073dfa87d4910  vmovaps [rsp+0x40], xmm4
000073dfa87d4916  vmovaps [rsp+0x50], xmm5
000073dfa87d491c  vmovaps [rsp+0x60], xmm6
000073dfa87d4922  vmovaps [rsp+0x70], xmm7
000073dfa87d4928  vmovaps [rsp+0x80], xmm8
000073dfa87d4931  vmovaps [rsp+0x90], xmm9
000073dfa87d493a  vmovaps [rsp+0xA0], xmm10
000073dfa87d4943  vmovaps [rsp+0xB0], xmm11
000073dfa87d494c  vmovaps [rsp+0xC0], xmm12
000073dfa87d4955  vmovaps [rsp+0xD0], xmm13
000073dfa87d495e  vmovaps [rsp+0xE0], xmm14
000073dfa87d4967  sub rsp, 0x30
000073dfa87d496b  movaps [rsp], xmm15
000073dfa87d4970  movaps [rsp+0x10], xmm2
000073dfa87d4975  movaps [rsp+0x20], xmm1
000073dfa87d497a  lea rdi, [rsp]
000073dfa87d497e  mov esi, 0x00
000073dfa87d4983  mov rax, 0x593AA1DA4530
000073dfa87d498d  call rax
000073dfa87d498f  movaps xmm15, [rsp]
000073dfa87d4994  add rsp, 0x30
000073dfa87d4998  vmovaps xmm0, [rsp]
000073dfa87d499d  vmovaps xmm1, [rsp+0x10]
000073dfa87d49a3  vmovaps xmm2, [rsp+0x20]
000073dfa87d49a9  vmovaps xmm3, [rsp+0x30]
000073dfa87d49af  vmovaps xmm4, [rsp+0x40]
000073dfa87d49b5  vmovaps xmm5, [rsp+0x50]
000073dfa87d49bb  vmovaps xmm6, [rsp+0x60]
000073dfa87d49c1  vmovaps xmm7, [rsp+0x70]
000073dfa87d49c7  vmovaps xmm8, [rsp+0x80]
000073dfa87d49d0  vmovaps xmm9, [rsp+0x90]
000073dfa87d49d9  vmovaps xmm10, [rsp+0xA0]
000073dfa87d49e2  vmovaps xmm11, [rsp+0xB0]
000073dfa87d49eb  vmovaps xmm12, [rsp+0xC0]
000073dfa87d49f4  vmovaps xmm13, [rsp+0xD0]
000073dfa87d49fd  vmovaps xmm14, [rsp+0xE0]
000073dfa87d4a06  add rsp, 0xF0
000073dfa87d4a0d  pop r11
000073dfa87d4a0f  pop r10
000073dfa87d4a11  pop r9
000073dfa87d4a13  pop r8
000073dfa87d4a15  pop rsi
000073dfa87d4a16  pop rdi
000073dfa87d4a17  pop rdx
000073dfa87d4a18  pop rcx
000073dfa87d4a19  pop rax
000073dfa87d4a1a  add rsp, 0x08
000073dfa87d4a1e  jmp 0x000073DFA87D2B41
000073dfa87d4a23  call 0x000073DFA85FF430
000073dfa87d4a28  jmp 0x000073DFA87D2B4E
000073dfa87d4a2d  sub rsp, 0x08
000073dfa87d4a31  push rax
000073dfa87d4a32  push rcx
000073dfa87d4a33  push rdx
000073dfa87d4a34  push rdi
000073dfa87d4a35  push rsi
000073dfa87d4a36  push r8
000073dfa87d4a38  push r9
000073dfa87d4a3a  push r10
000073dfa87d4a3c  push r11
000073dfa87d4a3e  sub rsp, 0xF0
000073dfa87d4a45  vmovaps [rsp], xmm0
000073dfa87d4a4a  vmovaps [rsp+0x10], xmm1
000073dfa87d4a50  vmovaps [rsp+0x20], xmm3
000073dfa87d4a56  vmovaps [rsp+0x30], xmm4
000073dfa87d4a5c  vmovaps [rsp+0x40], xmm5
000073dfa87d4a62  vmovaps [rsp+0x50], xmm6
000073dfa87d4a68  vmovaps [rsp+0x60], xmm7
000073dfa87d4a6e  vmovaps [rsp+0x70], xmm8
000073dfa87d4a74  vmovaps [rsp+0x80], xmm9
000073dfa87d4a7d  vmovaps [rsp+0x90], xmm10
000073dfa87d4a86  vmovaps [rsp+0xA0], xmm11
000073dfa87d4a8f  vmovaps [rsp+0xB0], xmm12
000073dfa87d4a98  vmovaps [rsp+0xC0], xmm13
000073dfa87d4aa1  vmovaps [rsp+0xD0], xmm14
000073dfa87d4aaa  vmovaps [rsp+0xE0], xmm15
000073dfa87d4ab3  sub rsp, 0x30
000073dfa87d4ab7  movaps [rsp], xmm2
000073dfa87d4abb  movaps [rsp+0x10], xmm1
000073dfa87d4ac0  movaps [rsp+0x20], xmm14
000073dfa87d4ac6  lea rdi, [rsp]
000073dfa87d4aca  mov esi, 0x00
000073dfa87d4acf  mov rax, 0x593AA1DA4530
000073dfa87d4ad9  call rax
000073dfa87d4adb  movaps xmm2, [rsp]
000073dfa87d4adf  add rsp, 0x30
000073dfa87d4ae3  vmovaps xmm0, [rsp]
000073dfa87d4ae8  vmovaps xmm1, [rsp+0x10]
000073dfa87d4aee  vmovaps xmm3, [rsp+0x20]
000073dfa87d4af4  vmovaps xmm4, [rsp+0x30]
000073dfa87d4afa  vmovaps xmm5, [rsp+0x40]
000073dfa87d4b00  vmovaps xmm6, [rsp+0x50]
000073dfa87d4b06  vmovaps xmm7, [rsp+0x60]
000073dfa87d4b0c  vmovaps xmm8, [rsp+0x70]
000073dfa87d4b12  vmovaps xmm9, [rsp+0x80]
000073dfa87d4b1b  vmovaps xmm10, [rsp+0x90]
000073dfa87d4b24  vmovaps xmm11, [rsp+0xA0]
000073dfa87d4b2d  vmovaps xmm12, [rsp+0xB0]
000073dfa87d4b36  vmovaps xmm13, [rsp+0xC0]
000073dfa87d4b3f  vmovaps xmm14, [rsp+0xD0]
000073dfa87d4b48  vmovaps xmm15, [rsp+0xE0]
000073dfa87d4b51  add rsp, 0xF0
000073dfa87d4b58  pop r11
000073dfa87d4b5a  pop r10
000073dfa87d4b5c  pop r9
000073dfa87d4b5e  pop r8
000073dfa87d4b60  pop rsi
000073dfa87d4b61  pop rdi
000073dfa87d4b62  pop rdx
000073dfa87d4b63  pop rcx
000073dfa87d4b64  pop rax
000073dfa87d4b65  add rsp, 0x08
000073dfa87d4b69  jmp 0x000073DFA87D2B8B
000073dfa87d4b6e  sub rsp, 0x08
000073dfa87d4b72  push rax
000073dfa87d4b73  push rcx
000073dfa87d4b74  push rdx
000073dfa87d4b75  push rdi
000073dfa87d4b76  push rsi
000073dfa87d4b77  push r8
000073dfa87d4b79  push r9
000073dfa87d4b7b  push r10
000073dfa87d4b7d  push r11
000073dfa87d4b7f  sub rsp, 0xF0
000073dfa87d4b86  vmovaps [rsp], xmm0
000073dfa87d4b8b  vmovaps [rsp+0x10], xmm1
000073dfa87d4b91  vmovaps [rsp+0x20], xmm2
000073dfa87d4b97  vmovaps [rsp+0x30], xmm3
000073dfa87d4b9d  vmovaps [rsp+0x40], xmm4
000073dfa87d4ba3  vmovaps [rsp+0x50], xmm5
000073dfa87d4ba9  vmovaps [rsp+0x60], xmm6
000073dfa87d4baf  vmovaps [rsp+0x70], xmm7
000073dfa87d4bb5  vmovaps [rsp+0x80], xmm8
000073dfa87d4bbe  vmovaps [rsp+0x90], xmm9
000073dfa87d4bc7  vmovaps [rsp+0xA0], xmm10
000073dfa87d4bd0  vmovaps [rsp+0xB0], xmm11
000073dfa87d4bd9  vmovaps [rsp+0xC0], xmm12
000073dfa87d4be2  vmovaps [rsp+0xD0], xmm13
000073dfa87d4beb  vmovaps [rsp+0xE0], xmm14
000073dfa87d4bf4  sub rsp, 0x30
000073dfa87d4bf8  movaps [rsp], xmm15
000073dfa87d4bfd  movaps [rsp+0x10], xmm14
000073dfa87d4c03  movaps [rsp+0x20], xmm1
000073dfa87d4c08  lea rdi, [rsp]
000073dfa87d4c0c  mov esi, 0x00
000073dfa87d4c11  mov rax, 0x593AA1DA4530
000073dfa87d4c1b  call rax
000073dfa87d4c1d  movaps xmm15, [rsp]
000073dfa87d4c22  add rsp, 0x30
000073dfa87d4c26  vmovaps xmm0, [rsp]
000073dfa87d4c2b  vmovaps xmm1, [rsp+0x10]
000073dfa87d4c31  vmovaps xmm2, [rsp+0x20]
000073dfa87d4c37  vmovaps xmm3, [rsp+0x30]
000073dfa87d4c3d  vmovaps xmm4, [rsp+0x40]
000073dfa87d4c43  vmovaps xmm5, [rsp+0x50]
000073dfa87d4c49  vmovaps xmm6, [rsp+0x60]
000073dfa87d4c4f  vmovaps xmm7, [rsp+0x70]
000073dfa87d4c55  vmovaps xmm8, [rsp+0x80]
000073dfa87d4c5e  vmovaps xmm9, [rsp+0x90]
000073dfa87d4c67  vmovaps xmm10, [rsp+0xA0]
000073dfa87d4c70  vmovaps xmm11, [rsp+0xB0]
000073dfa87d4c79  vmovaps xmm12, [rsp+0xC0]
000073dfa87d4c82  vmovaps xmm13, [rsp+0xD0]
000073dfa87d4c8b  vmovaps xmm14, [rsp+0xE0]
000073dfa87d4c94  add rsp, 0xF0
000073dfa87d4c9b  pop r11
000073dfa87d4c9d  pop r10
000073dfa87d4c9f  pop r9
000073dfa87d4ca1  pop r8
000073dfa87d4ca3  pop rsi
000073dfa87d4ca4  pop rdi
000073dfa87d4ca5  pop rdx
000073dfa87d4ca6  pop rcx
000073dfa87d4ca7  pop rax
000073dfa87d4ca8  add rsp, 0x08
000073dfa87d4cac  jmp 0x000073DFA87D2C05
000073dfa87d4cb1  call 0x000073DFA85FF430
000073dfa87d4cb6  jmp 0x000073DFA87D2C12
000073dfa87d4cbb  sub rsp, 0x08
000073dfa87d4cbf  push rax
000073dfa87d4cc0  push rcx
000073dfa87d4cc1  push rdx
000073dfa87d4cc2  push rdi
000073dfa87d4cc3  push rsi
000073dfa87d4cc4  push r8
000073dfa87d4cc6  push r9
000073dfa87d4cc8  push r10
000073dfa87d4cca  push r11
000073dfa87d4ccc  sub rsp, 0xF0
000073dfa87d4cd3  vmovaps [rsp], xmm0
000073dfa87d4cd8  vmovaps [rsp+0x10], xmm1
000073dfa87d4cde  vmovaps [rsp+0x20], xmm2
000073dfa87d4ce4  vmovaps [rsp+0x30], xmm3
000073dfa87d4cea  vmovaps [rsp+0x40], xmm4
000073dfa87d4cf0  vmovaps [rsp+0x50], xmm5
000073dfa87d4cf6  vmovaps [rsp+0x60], xmm6
000073dfa87d4cfc  vmovaps [rsp+0x70], xmm7
000073dfa87d4d02  vmovaps [rsp+0x80], xmm8
000073dfa87d4d0b  vmovaps [rsp+0x90], xmm9
000073dfa87d4d14  vmovaps [rsp+0xA0], xmm10
000073dfa87d4d1d  vmovaps [rsp+0xB0], xmm11
000073dfa87d4d26  vmovaps [rsp+0xC0], xmm12
000073dfa87d4d2f  vmovaps [rsp+0xD0], xmm14
000073dfa87d4d38  vmovaps [rsp+0xE0], xmm15
000073dfa87d4d41  sub rsp, 0x30
000073dfa87d4d45  movaps [rsp], xmm13
000073dfa87d4d4a  movaps [rsp+0x10], xmm1
000073dfa87d4d4f  movaps [rsp+0x20], xmm15
000073dfa87d4d55  lea rdi, [rsp]
000073dfa87d4d59  mov esi, 0x00
000073dfa87d4d5e  mov rax, 0x593AA1DA4530
000073dfa87d4d68  call rax
000073dfa87d4d6a  movaps xmm13, [rsp]
000073dfa87d4d6f  add rsp, 0x30
000073dfa87d4d73  vmovaps xmm0, [rsp]
000073dfa87d4d78  vmovaps xmm1, [rsp+0x10]
000073dfa87d4d7e  vmovaps xmm2, [rsp+0x20]
000073dfa87d4d84  vmovaps xmm3, [rsp+0x30]
000073dfa87d4d8a  vmovaps xmm4, [rsp+0x40]
000073dfa87d4d90  vmovaps xmm5, [rsp+0x50]
000073dfa87d4d96  vmovaps xmm6, [rsp+0x60]
000073dfa87d4d9c  vmovaps xmm7, [rsp+0x70]
000073dfa87d4da2  vmovaps xmm8, [rsp+0x80]
000073dfa87d4dab  vmovaps xmm9, [rsp+0x90]
000073dfa87d4db4  vmovaps xmm10, [rsp+0xA0]
000073dfa87d4dbd  vmovaps xmm11, [rsp+0xB0]
000073dfa87d4dc6  vmovaps xmm12, [rsp+0xC0]
000073dfa87d4dcf  vmovaps xmm14, [rsp+0xD0]
000073dfa87d4dd8  vmovaps xmm15, [rsp+0xE0]
000073dfa87d4de1  add rsp, 0xF0
000073dfa87d4de8  pop r11
000073dfa87d4dea  pop r10
000073dfa87d4dec  pop r9
000073dfa87d4dee  pop r8
000073dfa87d4df0  pop rsi
000073dfa87d4df1  pop rdi
000073dfa87d4df2  pop rdx
000073dfa87d4df3  pop rcx
000073dfa87d4df4  pop rax
000073dfa87d4df5  add rsp, 0x08
000073dfa87d4df9  jmp 0x000073DFA87D2CD6
000073dfa87d4dfe  sub rsp, 0x08
000073dfa87d4e02  push rax
000073dfa87d4e03  push rcx
000073dfa87d4e04  push rdx
000073dfa87d4e05  push rdi
000073dfa87d4e06  push rsi
000073dfa87d4e07  push r8
000073dfa87d4e09  push r9
000073dfa87d4e0b  push r10
000073dfa87d4e0d  push r11
000073dfa87d4e0f  sub rsp, 0xF0
000073dfa87d4e16  vmovaps [rsp], xmm0
000073dfa87d4e1b  vmovaps [rsp+0x10], xmm1
000073dfa87d4e21  vmovaps [rsp+0x20], xmm2
000073dfa87d4e27  vmovaps [rsp+0x30], xmm3
000073dfa87d4e2d  vmovaps [rsp+0x40], xmm4
000073dfa87d4e33  vmovaps [rsp+0x50], xmm5
000073dfa87d4e39  vmovaps [rsp+0x60], xmm6
000073dfa87d4e3f  vmovaps [rsp+0x70], xmm7
000073dfa87d4e45  vmovaps [rsp+0x80], xmm8
000073dfa87d4e4e  vmovaps [rsp+0x90], xmm9
000073dfa87d4e57  vmovaps [rsp+0xA0], xmm10
000073dfa87d4e60  vmovaps [rsp+0xB0], xmm11
000073dfa87d4e69  vmovaps [rsp+0xC0], xmm12
000073dfa87d4e72  vmovaps [rsp+0xD0], xmm13
000073dfa87d4e7b  vmovaps [rsp+0xE0], xmm14
000073dfa87d4e84  sub rsp, 0x30
000073dfa87d4e88  movaps [rsp], xmm15
000073dfa87d4e8d  movaps [rsp+0x10], xmm14
000073dfa87d4e93  movaps [rsp+0x20], xmm1
000073dfa87d4e98  lea rdi, [rsp]
000073dfa87d4e9c  mov esi, 0x00
000073dfa87d4ea1  mov rax, 0x593AA1DA4530
000073dfa87d4eab  call rax
000073dfa87d4ead  movaps xmm15, [rsp]
000073dfa87d4eb2  add rsp, 0x30
000073dfa87d4eb6  vmovaps xmm0, [rsp]
000073dfa87d4ebb  vmovaps xmm1, [rsp+0x10]
000073dfa87d4ec1  vmovaps xmm2, [rsp+0x20]
000073dfa87d4ec7  vmovaps xmm3, [rsp+0x30]
000073dfa87d4ecd  vmovaps xmm4, [rsp+0x40]
000073dfa87d4ed3  vmovaps xmm5, [rsp+0x50]
000073dfa87d4ed9  vmovaps xmm6, [rsp+0x60]
000073dfa87d4edf  vmovaps xmm7, [rsp+0x70]
000073dfa87d4ee5  vmovaps xmm8, [rsp+0x80]
000073dfa87d4eee  vmovaps xmm9, [rsp+0x90]
000073dfa87d4ef7  vmovaps xmm10, [rsp+0xA0]
000073dfa87d4f00  vmovaps xmm11, [rsp+0xB0]
000073dfa87d4f09  vmovaps xmm12, [rsp+0xC0]
000073dfa87d4f12  vmovaps xmm13, [rsp+0xD0]
000073dfa87d4f1b  vmovaps xmm14, [rsp+0xE0]
000073dfa87d4f24  add rsp, 0xF0
000073dfa87d4f2b  pop r11
000073dfa87d4f2d  pop r10
000073dfa87d4f2f  pop r9
000073dfa87d4f31  pop r8
000073dfa87d4f33  pop rsi
000073dfa87d4f34  pop rdi
000073dfa87d4f35  pop rdx
000073dfa87d4f36  pop rcx
000073dfa87d4f37  pop rax
000073dfa87d4f38  add rsp, 0x08
000073dfa87d4f3c  jmp 0x000073DFA87D2D12
000073dfa87d4f41  call 0x000073DFA85FF430
000073dfa87d4f46  jmp 0x000073DFA87D2D1F
000073dfa87d4f4b  sub rsp, 0x08
000073dfa87d4f4f  push rax
000073dfa87d4f50  push rcx
000073dfa87d4f51  push rdx
000073dfa87d4f52  push rdi
000073dfa87d4f53  push rsi
000073dfa87d4f54  push r8
000073dfa87d4f56  push r9
000073dfa87d4f58  push r10
000073dfa87d4f5a  push r11
000073dfa87d4f5c  sub rsp, 0xF0
000073dfa87d4f63  vmovaps [rsp], xmm0
000073dfa87d4f68  vmovaps [rsp+0x10], xmm1
000073dfa87d4f6e  vmovaps [rsp+0x20], xmm2
000073dfa87d4f74  vmovaps [rsp+0x30], xmm3
000073dfa87d4f7a  vmovaps [rsp+0x40], xmm4
000073dfa87d4f80  vmovaps [rsp+0x50], xmm5
000073dfa87d4f86  vmovaps [rsp+0x60], xmm6
000073dfa87d4f8c  vmovaps [rsp+0x70], xmm7
000073dfa87d4f92  vmovaps [rsp+0x80], xmm8
000073dfa87d4f9b  vmovaps [rsp+0x90], xmm9
000073dfa87d4fa4  vmovaps [rsp+0xA0], xmm10
000073dfa87d4fad  vmovaps [rsp+0xB0], xmm11
000073dfa87d4fb6  vmovaps [rsp+0xC0], xmm12
000073dfa87d4fbf  vmovaps [rsp+0xD0], xmm13
000073dfa87d4fc8  vmovaps [rsp+0xE0], xmm15
000073dfa87d4fd1  sub rsp, 0x30
000073dfa87d4fd5  movaps [rsp], xmm14
000073dfa87d4fda  movaps [rsp+0x10], xmm13
000073dfa87d4fe0  movaps [rsp+0x20], xmm2
000073dfa87d4fe5  lea rdi, [rsp]
000073dfa87d4fe9  mov esi, 0x00
000073dfa87d4fee  mov rax, 0x593AA1DA4530
000073dfa87d4ff8  call rax
000073dfa87d4ffa  movaps xmm14, [rsp]
000073dfa87d4fff  add rsp, 0x30
000073dfa87d5003  vmovaps xmm0, [rsp]
000073dfa87d5008  vmovaps xmm1, [rsp+0x10]
000073dfa87d500e  vmovaps xmm2, [rsp+0x20]
000073dfa87d5014  vmovaps xmm3, [rsp+0x30]
000073dfa87d501a  vmovaps xmm4, [rsp+0x40]
000073dfa87d5020  vmovaps xmm5, [rsp+0x50]
000073dfa87d5026  vmovaps xmm6, [rsp+0x60]
000073dfa87d502c  vmovaps xmm7, [rsp+0x70]
000073dfa87d5032  vmovaps xmm8, [rsp+0x80]
000073dfa87d503b  vmovaps xmm9, [rsp+0x90]
000073dfa87d5044  vmovaps xmm10, [rsp+0xA0]
000073dfa87d504d  vmovaps xmm11, [rsp+0xB0]
000073dfa87d5056  vmovaps xmm12, [rsp+0xC0]
000073dfa87d505f  vmovaps xmm13, [rsp+0xD0]
000073dfa87d5068  vmovaps xmm15, [rsp+0xE0]
000073dfa87d5071  add rsp, 0xF0
000073dfa87d5078  pop r11
000073dfa87d507a  pop r10
000073dfa87d507c  pop r9
000073dfa87d507e  pop r8
000073dfa87d5080  pop rsi
000073dfa87d5081  pop rdi
000073dfa87d5082  pop rdx
000073dfa87d5083  pop rcx
000073dfa87d5084  pop rax
000073dfa87d5085  add rsp, 0x08
000073dfa87d5089  jmp 0x000073DFA87D2D4B
000073dfa87d508e  sub rsp, 0x08
000073dfa87d5092  push rax
000073dfa87d5093  push rcx
000073dfa87d5094  push rdx
000073dfa87d5095  push rdi
000073dfa87d5096  push rsi
000073dfa87d5097  push r8
000073dfa87d5099  push r9
000073dfa87d509b  push r10
000073dfa87d509d  push r11
000073dfa87d509f  sub rsp, 0xF0
000073dfa87d50a6  vmovaps [rsp], xmm0
000073dfa87d50ab  vmovaps [rsp+0x10], xmm2
000073dfa87d50b1  vmovaps [rsp+0x20], xmm3
000073dfa87d50b7  vmovaps [rsp+0x30], xmm4
000073dfa87d50bd  vmovaps [rsp+0x40], xmm5
000073dfa87d50c3  vmovaps [rsp+0x50], xmm6
000073dfa87d50c9  vmovaps [rsp+0x60], xmm7
000073dfa87d50cf  vmovaps [rsp+0x70], xmm8
000073dfa87d50d5  vmovaps [rsp+0x80], xmm9
000073dfa87d50de  vmovaps [rsp+0x90], xmm10
000073dfa87d50e7  vmovaps [rsp+0xA0], xmm11
000073dfa87d50f0  vmovaps [rsp+0xB0], xmm12
000073dfa87d50f9  vmovaps [rsp+0xC0], xmm13
000073dfa87d5102  vmovaps [rsp+0xD0], xmm14
000073dfa87d510b  vmovaps [rsp+0xE0], xmm15
000073dfa87d5114  sub rsp, 0x30
000073dfa87d5118  movaps [rsp], xmm1
000073dfa87d511c  movaps [rsp+0x10], xmm13
000073dfa87d5122  movaps [rsp+0x20], xmm2
000073dfa87d5127  lea rdi, [rsp]
000073dfa87d512b  mov esi, 0x00
000073dfa87d5130  mov rax, 0x593AA1DA4530
000073dfa87d513a  call rax
000073dfa87d513c  movaps xmm1, [rsp]
000073dfa87d5140  add rsp, 0x30
000073dfa87d5144  vmovaps xmm0, [rsp]
000073dfa87d5149  vmovaps xmm2, [rsp+0x10]
000073dfa87d514f  vmovaps xmm3, [rsp+0x20]
000073dfa87d5155  vmovaps xmm4, [rsp+0x30]
000073dfa87d515b  vmovaps xmm5, [rsp+0x40]
000073dfa87d5161  vmovaps xmm6, [rsp+0x50]
000073dfa87d5167  vmovaps xmm7, [rsp+0x60]
000073dfa87d516d  vmovaps xmm8, [rsp+0x70]
000073dfa87d5173  vmovaps xmm9, [rsp+0x80]
000073dfa87d517c  vmovaps xmm10, [rsp+0x90]
000073dfa87d5185  vmovaps xmm11, [rsp+0xA0]
000073dfa87d518e  vmovaps xmm12, [rsp+0xB0]
000073dfa87d5197  vmovaps xmm13, [rsp+0xC0]
000073dfa87d51a0  vmovaps xmm14, [rsp+0xD0]
000073dfa87d51a9  vmovaps xmm15, [rsp+0xE0]
000073dfa87d51b2  add rsp, 0xF0
000073dfa87d51b9  pop r11
000073dfa87d51bb  pop r10
000073dfa87d51bd  pop r9
000073dfa87d51bf  pop r8
000073dfa87d51c1  pop rsi
000073dfa87d51c2  pop rdi
000073dfa87d51c3  pop rdx
000073dfa87d51c4  pop rcx
000073dfa87d51c5  pop rax
000073dfa87d51c6  add rsp, 0x08
000073dfa87d51ca  jmp 0x000073DFA87D2D79
000073dfa87d51cf  sub rsp, 0x08
000073dfa87d51d3  push rax
000073dfa87d51d4  push rcx
000073dfa87d51d5  push rdx
000073dfa87d51d6  push rdi
000073dfa87d51d7  push rsi
000073dfa87d51d8  push r8
000073dfa87d51da  push r9
000073dfa87d51dc  push r10
000073dfa87d51de  push r11
000073dfa87d51e0  sub rsp, 0xF0
000073dfa87d51e7  vmovaps [rsp], xmm0
000073dfa87d51ec  vmovaps [rsp+0x10], xmm1
000073dfa87d51f2  vmovaps [rsp+0x20], xmm3
000073dfa87d51f8  vmovaps [rsp+0x30], xmm4
000073dfa87d51fe  vmovaps [rsp+0x40], xmm5
000073dfa87d5204  vmovaps [rsp+0x50], xmm6
000073dfa87d520a  vmovaps [rsp+0x60], xmm7
000073dfa87d5210  vmovaps [rsp+0x70], xmm8
000073dfa87d5216  vmovaps [rsp+0x80], xmm9
000073dfa87d521f  vmovaps [rsp+0x90], xmm10
000073dfa87d5228  vmovaps [rsp+0xA0], xmm11
000073dfa87d5231  vmovaps [rsp+0xB0], xmm12
000073dfa87d523a  vmovaps [rsp+0xC0], xmm13
000073dfa87d5243  vmovaps [rsp+0xD0], xmm14
000073dfa87d524c  vmovaps [rsp+0xE0], xmm15
000073dfa87d5255  sub rsp, 0x30
000073dfa87d5259  movaps [rsp], xmm2
000073dfa87d525d  movaps [rsp+0x10], xmm1
000073dfa87d5262  movaps [rsp+0x20], xmm13
000073dfa87d5268  lea rdi, [rsp]
000073dfa87d526c  mov esi, 0x00
000073dfa87d5271  mov rax, 0x593AA1DA4530
000073dfa87d527b  call rax
000073dfa87d527d  movaps xmm2, [rsp]
000073dfa87d5281  add rsp, 0x30
000073dfa87d5285  vmovaps xmm0, [rsp]
000073dfa87d528a  vmovaps xmm1, [rsp+0x10]
000073dfa87d5290  vmovaps xmm3, [rsp+0x20]
000073dfa87d5296  vmovaps xmm4, [rsp+0x30]
000073dfa87d529c  vmovaps xmm5, [rsp+0x40]
000073dfa87d52a2  vmovaps xmm6, [rsp+0x50]
000073dfa87d52a8  vmovaps xmm7, [rsp+0x60]
000073dfa87d52ae  vmovaps xmm8, [rsp+0x70]
000073dfa87d52b4  vmovaps xmm9, [rsp+0x80]
000073dfa87d52bd  vmovaps xmm10, [rsp+0x90]
000073dfa87d52c6  vmovaps xmm11, [rsp+0xA0]
000073dfa87d52cf  vmovaps xmm12, [rsp+0xB0]
000073dfa87d52d8  vmovaps xmm13, [rsp+0xC0]
000073dfa87d52e1  vmovaps xmm14, [rsp+0xD0]
000073dfa87d52ea  vmovaps xmm15, [rsp+0xE0]
000073dfa87d52f3  add rsp, 0xF0
000073dfa87d52fa  pop r11
000073dfa87d52fc  pop r10
000073dfa87d52fe  pop r9
000073dfa87d5300  pop r8
000073dfa87d5302  pop rsi
000073dfa87d5303  pop rdi
000073dfa87d5304  pop rdx
000073dfa87d5305  pop rcx
000073dfa87d5306  pop rax
000073dfa87d5307  add rsp, 0x08
000073dfa87d530b  jmp 0x000073DFA87D2DD2
000073dfa87d5310  call 0x000073DFA85FF430
000073dfa87d5315  jmp 0x000073DFA87D2DDF
000073dfa87d531a  sub rsp, 0x08
000073dfa87d531e  push rax
000073dfa87d531f  push rcx
000073dfa87d5320  push rdx
000073dfa87d5321  push rdi
000073dfa87d5322  push rsi
000073dfa87d5323  push r8
000073dfa87d5325  push r9
000073dfa87d5327  push r10
000073dfa87d5329  push r11
000073dfa87d532b  sub rsp, 0xF0
000073dfa87d5332  vmovaps [rsp], xmm0
000073dfa87d5337  vmovaps [rsp+0x10], xmm1
000073dfa87d533d  vmovaps [rsp+0x20], xmm2
000073dfa87d5343  vmovaps [rsp+0x30], xmm3
000073dfa87d5349  vmovaps [rsp+0x40], xmm4
000073dfa87d534f  vmovaps [rsp+0x50], xmm5
000073dfa87d5355  vmovaps [rsp+0x60], xmm6
000073dfa87d535b  vmovaps [rsp+0x70], xmm7
000073dfa87d5361  vmovaps [rsp+0x80], xmm8
000073dfa87d536a  vmovaps [rsp+0x90], xmm9
000073dfa87d5373  vmovaps [rsp+0xA0], xmm10
000073dfa87d537c  vmovaps [rsp+0xB0], xmm11
000073dfa87d5385  vmovaps [rsp+0xC0], xmm12
000073dfa87d538e  vmovaps [rsp+0xD0], xmm13
000073dfa87d5397  vmovaps [rsp+0xE0], xmm14
000073dfa87d53a0  sub rsp, 0x30
000073dfa87d53a4  movaps [rsp], xmm15
000073dfa87d53a9  movaps [rsp+0x10], xmm13
000073dfa87d53af  movaps [rsp+0x20], xmm1
000073dfa87d53b4  lea rdi, [rsp]
000073dfa87d53b8  mov esi, 0x00
000073dfa87d53bd  mov rax, 0x593AA1DA4530
000073dfa87d53c7  call rax
000073dfa87d53c9  movaps xmm15, [rsp]
000073dfa87d53ce  add rsp, 0x30
000073dfa87d53d2  vmovaps xmm0, [rsp]
000073dfa87d53d7  vmovaps xmm1, [rsp+0x10]
000073dfa87d53dd  vmovaps xmm2, [rsp+0x20]
000073dfa87d53e3  vmovaps xmm3, [rsp+0x30]
000073dfa87d53e9  vmovaps xmm4, [rsp+0x40]
000073dfa87d53ef  vmovaps xmm5, [rsp+0x50]
000073dfa87d53f5  vmovaps xmm6, [rsp+0x60]
000073dfa87d53fb  vmovaps xmm7, [rsp+0x70]
000073dfa87d5401  vmovaps xmm8, [rsp+0x80]
000073dfa87d540a  vmovaps xmm9, [rsp+0x90]
000073dfa87d5413  vmovaps xmm10, [rsp+0xA0]
000073dfa87d541c  vmovaps xmm11, [rsp+0xB0]
000073dfa87d5425  vmovaps xmm12, [rsp+0xC0]
000073dfa87d542e  vmovaps xmm13, [rsp+0xD0]
000073dfa87d5437  vmovaps xmm14, [rsp+0xE0]
000073dfa87d5440  add rsp, 0xF0
000073dfa87d5447  pop r11
000073dfa87d5449  pop r10
000073dfa87d544b  pop r9
000073dfa87d544d  pop r8
000073dfa87d544f  pop rsi
000073dfa87d5450  pop rdi
000073dfa87d5451  pop rdx
000073dfa87d5452  pop rcx
000073dfa87d5453  pop rax
000073dfa87d5454  add rsp, 0x08
000073dfa87d5458  jmp 0x000073DFA87D2E1E
000073dfa87d545d  sub rsp, 0x08
000073dfa87d5461  push rax
000073dfa87d5462  push rcx
000073dfa87d5463  push rdx
000073dfa87d5464  push rdi
000073dfa87d5465  push rsi
000073dfa87d5466  push r8
000073dfa87d5468  push r9
000073dfa87d546a  push r10
000073dfa87d546c  push r11
000073dfa87d546e  sub rsp, 0xF0
000073dfa87d5475  vmovaps [rsp], xmm0
000073dfa87d547a  vmovaps [rsp+0x10], xmm1
000073dfa87d5480  vmovaps [rsp+0x20], xmm2
000073dfa87d5486  vmovaps [rsp+0x30], xmm3
000073dfa87d548c  vmovaps [rsp+0x40], xmm4
000073dfa87d5492  vmovaps [rsp+0x50], xmm5
000073dfa87d5498  vmovaps [rsp+0x60], xmm6
000073dfa87d549e  vmovaps [rsp+0x70], xmm7
000073dfa87d54a4  vmovaps [rsp+0x80], xmm8
000073dfa87d54ad  vmovaps [rsp+0x90], xmm9
000073dfa87d54b6  vmovaps [rsp+0xA0], xmm10
000073dfa87d54bf  vmovaps [rsp+0xB0], xmm11
000073dfa87d54c8  vmovaps [rsp+0xC0], xmm12
000073dfa87d54d1  vmovaps [rsp+0xD0], xmm13
000073dfa87d54da  vmovaps [rsp+0xE0], xmm15
000073dfa87d54e3  sub rsp, 0x30
000073dfa87d54e7  movaps [rsp], xmm14
000073dfa87d54ec  movaps [rsp+0x10], xmm11
000073dfa87d54f2  movaps [rsp+0x20], xmm1
000073dfa87d54f7  lea rdi, [rsp]
000073dfa87d54fb  mov esi, 0x00
000073dfa87d5500  mov rax, 0x593AA1DA4530
000073dfa87d550a  call rax
000073dfa87d550c  movaps xmm14, [rsp]
000073dfa87d5511  add rsp, 0x30
000073dfa87d5515  vmovaps xmm0, [rsp]
000073dfa87d551a  vmovaps xmm1, [rsp+0x10]
000073dfa87d5520  vmovaps xmm2, [rsp+0x20]
000073dfa87d5526  vmovaps xmm3, [rsp+0x30]
000073dfa87d552c  vmovaps xmm4, [rsp+0x40]
000073dfa87d5532  vmovaps xmm5, [rsp+0x50]
000073dfa87d5538  vmovaps xmm6, [rsp+0x60]
000073dfa87d553e  vmovaps xmm7, [rsp+0x70]
000073dfa87d5544  vmovaps xmm8, [rsp+0x80]
000073dfa87d554d  vmovaps xmm9, [rsp+0x90]
000073dfa87d5556  vmovaps xmm10, [rsp+0xA0]
000073dfa87d555f  vmovaps xmm11, [rsp+0xB0]
000073dfa87d5568  vmovaps xmm12, [rsp+0xC0]
000073dfa87d5571  vmovaps xmm13, [rsp+0xD0]
000073dfa87d557a  vmovaps xmm15, [rsp+0xE0]
000073dfa87d5583  add rsp, 0xF0
000073dfa87d558a  pop r11
000073dfa87d558c  pop r10
000073dfa87d558e  pop r9
000073dfa87d5590  pop r8
000073dfa87d5592  pop rsi
000073dfa87d5593  pop rdi
000073dfa87d5594  pop rdx
000073dfa87d5595  pop rcx
000073dfa87d5596  pop rax
000073dfa87d5597  add rsp, 0x08
000073dfa87d559b  jmp 0x000073DFA87D2E48
000073dfa87d55a0  sub rsp, 0x08
000073dfa87d55a4  push rax
000073dfa87d55a5  push rcx
000073dfa87d55a6  push rdx
000073dfa87d55a7  push rdi
000073dfa87d55a8  push rsi
000073dfa87d55a9  push r8
000073dfa87d55ab  push r9
000073dfa87d55ad  push r10
000073dfa87d55af  push r11
000073dfa87d55b1  sub rsp, 0xF0
000073dfa87d55b8  vmovaps [rsp], xmm0
000073dfa87d55bd  vmovaps [rsp+0x10], xmm1
000073dfa87d55c3  vmovaps [rsp+0x20], xmm2
000073dfa87d55c9  vmovaps [rsp+0x30], xmm3
000073dfa87d55cf  vmovaps [rsp+0x40], xmm4
000073dfa87d55d5  vmovaps [rsp+0x50], xmm5
000073dfa87d55db  vmovaps [rsp+0x60], xmm6
000073dfa87d55e1  vmovaps [rsp+0x70], xmm7
000073dfa87d55e7  vmovaps [rsp+0x80], xmm8
000073dfa87d55f0  vmovaps [rsp+0x90], xmm9
000073dfa87d55f9  vmovaps [rsp+0xA0], xmm10
000073dfa87d5602  vmovaps [rsp+0xB0], xmm11
000073dfa87d560b  vmovaps [rsp+0xC0], xmm12
000073dfa87d5614  vmovaps [rsp+0xD0], xmm14
000073dfa87d561d  vmovaps [rsp+0xE0], xmm15
000073dfa87d5626  sub rsp, 0x30
000073dfa87d562a  movaps [rsp], xmm13
000073dfa87d562f  movaps [rsp+0x10], xmm11
000073dfa87d5635  movaps [rsp+0x20], xmm1
000073dfa87d563a  lea rdi, [rsp]
000073dfa87d563e  mov esi, 0x00
000073dfa87d5643  mov rax, 0x593AA1DA4530
000073dfa87d564d  call rax
000073dfa87d564f  movaps xmm13, [rsp]
000073dfa87d5654  add rsp, 0x30
000073dfa87d5658  vmovaps xmm0, [rsp]
000073dfa87d565d  vmovaps xmm1, [rsp+0x10]
000073dfa87d5663  vmovaps xmm2, [rsp+0x20]
000073dfa87d5669  vmovaps xmm3, [rsp+0x30]
000073dfa87d566f  vmovaps xmm4, [rsp+0x40]
000073dfa87d5675  vmovaps xmm5, [rsp+0x50]
000073dfa87d567b  vmovaps xmm6, [rsp+0x60]
000073dfa87d5681  vmovaps xmm7, [rsp+0x70]
000073dfa87d5687  vmovaps xmm8, [rsp+0x80]
000073dfa87d5690  vmovaps xmm9, [rsp+0x90]
000073dfa87d5699  vmovaps xmm10, [rsp+0xA0]
000073dfa87d56a2  vmovaps xmm11, [rsp+0xB0]
000073dfa87d56ab  vmovaps xmm12, [rsp+0xC0]
000073dfa87d56b4  vmovaps xmm14, [rsp+0xD0]
000073dfa87d56bd  vmovaps xmm15, [rsp+0xE0]
000073dfa87d56c6  add rsp, 0xF0
000073dfa87d56cd  pop r11
000073dfa87d56cf  pop r10
000073dfa87d56d1  pop r9
000073dfa87d56d3  pop r8
000073dfa87d56d5  pop rsi
000073dfa87d56d6  pop rdi
000073dfa87d56d7  pop rdx
000073dfa87d56d8  pop rcx
000073dfa87d56d9  pop rax
000073dfa87d56da  add rsp, 0x08
000073dfa87d56de  jmp 0x000073DFA87D2E9D
000073dfa87d56e3  call 0x000073DFA85FF430
000073dfa87d56e8  jmp 0x000073DFA87D2EAA
000073dfa87d56ed  sub rsp, 0x08
000073dfa87d56f1  push rax
000073dfa87d56f2  push rcx
000073dfa87d56f3  push rdx
000073dfa87d56f4  push rdi
000073dfa87d56f5  push rsi
000073dfa87d56f6  push r8
000073dfa87d56f8  push r9
000073dfa87d56fa  push r10
000073dfa87d56fc  push r11
000073dfa87d56fe  sub rsp, 0xF0
000073dfa87d5705  vmovaps [rsp], xmm0
000073dfa87d570a  vmovaps [rsp+0x10], xmm1
000073dfa87d5710  vmovaps [rsp+0x20], xmm2
000073dfa87d5716  vmovaps [rsp+0x30], xmm3
000073dfa87d571c  vmovaps [rsp+0x40], xmm4
000073dfa87d5722  vmovaps [rsp+0x50], xmm5
000073dfa87d5728  vmovaps [rsp+0x60], xmm6
000073dfa87d572e  vmovaps [rsp+0x70], xmm7
000073dfa87d5734  vmovaps [rsp+0x80], xmm8
000073dfa87d573d  vmovaps [rsp+0x90], xmm9
000073dfa87d5746  vmovaps [rsp+0xA0], xmm10
000073dfa87d574f  vmovaps [rsp+0xB0], xmm11
000073dfa87d5758  vmovaps [rsp+0xC0], xmm12
000073dfa87d5761  vmovaps [rsp+0xD0], xmm13
000073dfa87d576a  vmovaps [rsp+0xE0], xmm14
000073dfa87d5773  sub rsp, 0x30
000073dfa87d5777  movaps [rsp], xmm15
000073dfa87d577c  movaps [rsp+0x10], xmm11
000073dfa87d5782  movaps [rsp+0x20], xmm1
000073dfa87d5787  lea rdi, [rsp]
000073dfa87d578b  mov esi, 0x00
000073dfa87d5790  mov rax, 0x593AA1DA4530
000073dfa87d579a  call rax
000073dfa87d579c  movaps xmm15, [rsp]
000073dfa87d57a1  add rsp, 0x30
000073dfa87d57a5  vmovaps xmm0, [rsp]
000073dfa87d57aa  vmovaps xmm1, [rsp+0x10]
000073dfa87d57b0  vmovaps xmm2, [rsp+0x20]
000073dfa87d57b6  vmovaps xmm3, [rsp+0x30]
000073dfa87d57bc  vmovaps xmm4, [rsp+0x40]
000073dfa87d57c2  vmovaps xmm5, [rsp+0x50]
000073dfa87d57c8  vmovaps xmm6, [rsp+0x60]
000073dfa87d57ce  vmovaps xmm7, [rsp+0x70]
000073dfa87d57d4  vmovaps xmm8, [rsp+0x80]
000073dfa87d57dd  vmovaps xmm9, [rsp+0x90]
000073dfa87d57e6  vmovaps xmm10, [rsp+0xA0]
000073dfa87d57ef  vmovaps xmm11, [rsp+0xB0]
000073dfa87d57f8  vmovaps xmm12, [rsp+0xC0]
000073dfa87d5801  vmovaps xmm13, [rsp+0xD0]
000073dfa87d580a  vmovaps xmm14, [rsp+0xE0]
000073dfa87d5813  add rsp, 0xF0
000073dfa87d581a  pop r11
000073dfa87d581c  pop r10
000073dfa87d581e  pop r9
000073dfa87d5820  pop r8
000073dfa87d5822  pop rsi
000073dfa87d5823  pop rdi
000073dfa87d5824  pop rdx
000073dfa87d5825  pop rcx
000073dfa87d5826  pop rax
000073dfa87d5827  add rsp, 0x08
000073dfa87d582b  jmp 0x000073DFA87D2EE3
000073dfa87d5830  sub rsp, 0x08
000073dfa87d5834  push rax
000073dfa87d5835  push rcx
000073dfa87d5836  push rdx
000073dfa87d5837  push rdi
000073dfa87d5838  push rsi
000073dfa87d5839  push r8
000073dfa87d583b  push r9
000073dfa87d583d  push r10
000073dfa87d583f  push r11
000073dfa87d5841  sub rsp, 0xF0
000073dfa87d5848  vmovaps [rsp], xmm0
000073dfa87d584d  vmovaps [rsp+0x10], xmm1
000073dfa87d5853  vmovaps [rsp+0x20], xmm2
000073dfa87d5859  vmovaps [rsp+0x30], xmm3
000073dfa87d585f  vmovaps [rsp+0x40], xmm4
000073dfa87d5865  vmovaps [rsp+0x50], xmm5
000073dfa87d586b  vmovaps [rsp+0x60], xmm6
000073dfa87d5871  vmovaps [rsp+0x70], xmm7
000073dfa87d5877  vmovaps [rsp+0x80], xmm8
000073dfa87d5880  vmovaps [rsp+0x90], xmm9
000073dfa87d5889  vmovaps [rsp+0xA0], xmm10
000073dfa87d5892  vmovaps [rsp+0xB0], xmm12
000073dfa87d589b  vmovaps [rsp+0xC0], xmm13
000073dfa87d58a4  vmovaps [rsp+0xD0], xmm14
000073dfa87d58ad  vmovaps [rsp+0xE0], xmm15
000073dfa87d58b6  sub rsp, 0x30
000073dfa87d58ba  movaps [rsp], xmm11
000073dfa87d58bf  movaps [rsp+0x10], xmm6
000073dfa87d58c4  movaps [rsp+0x20], xmm14
000073dfa87d58ca  lea rdi, [rsp]
000073dfa87d58ce  mov esi, 0x00
000073dfa87d58d3  mov rax, 0x593AA1DA4530
000073dfa87d58dd  call rax
000073dfa87d58df  movaps xmm11, [rsp]
000073dfa87d58e4  add rsp, 0x30
000073dfa87d58e8  vmovaps xmm0, [rsp]
000073dfa87d58ed  vmovaps xmm1, [rsp+0x10]
000073dfa87d58f3  vmovaps xmm2, [rsp+0x20]
000073dfa87d58f9  vmovaps xmm3, [rsp+0x30]
000073dfa87d58ff  vmovaps xmm4, [rsp+0x40]
000073dfa87d5905  vmovaps xmm5, [rsp+0x50]
000073dfa87d590b  vmovaps xmm6, [rsp+0x60]
000073dfa87d5911  vmovaps xmm7, [rsp+0x70]
000073dfa87d5917  vmovaps xmm8, [rsp+0x80]
000073dfa87d5920  vmovaps xmm9, [rsp+0x90]
000073dfa87d5929  vmovaps xmm10, [rsp+0xA0]
000073dfa87d5932  vmovaps xmm12, [rsp+0xB0]
000073dfa87d593b  vmovaps xmm13, [rsp+0xC0]
000073dfa87d5944  vmovaps xmm14, [rsp+0xD0]
000073dfa87d594d  vmovaps xmm15, [rsp+0xE0]
000073dfa87d5956  add rsp, 0xF0
000073dfa87d595d  pop r11
000073dfa87d595f  pop r10
000073dfa87d5961  pop r9
000073dfa87d5963  pop r8
000073dfa87d5965  pop rsi
000073dfa87d5966  pop rdi
000073dfa87d5967  pop rdx
000073dfa87d5968  pop rcx
000073dfa87d5969  pop rax
000073dfa87d596a  add rsp, 0x08
000073dfa87d596e  jmp 0x000073DFA87D2F5B
000073dfa87d5973  call 0x000073DFA85FF430
000073dfa87d5978  jmp 0x000073DFA87D2F65
000073dfa87d597d  sub rsp, 0x08
000073dfa87d5981  push rax
000073dfa87d5982  push rcx
000073dfa87d5983  push rdx
000073dfa87d5984  push rdi
000073dfa87d5985  push rsi
000073dfa87d5986  push r8
000073dfa87d5988  push r9
000073dfa87d598a  push r10
000073dfa87d598c  push r11
000073dfa87d598e  sub rsp, 0xF0
000073dfa87d5995  vmovaps [rsp], xmm0
000073dfa87d599a  vmovaps [rsp+0x10], xmm1
000073dfa87d59a0  vmovaps [rsp+0x20], xmm2
000073dfa87d59a6  vmovaps [rsp+0x30], xmm3
000073dfa87d59ac  vmovaps [rsp+0x40], xmm4
000073dfa87d59b2  vmovaps [rsp+0x50], xmm5
000073dfa87d59b8  vmovaps [rsp+0x60], xmm6
000073dfa87d59be  vmovaps [rsp+0x70], xmm7
000073dfa87d59c4  vmovaps [rsp+0x80], xmm8
000073dfa87d59cd  vmovaps [rsp+0x90], xmm9
000073dfa87d59d6  vmovaps [rsp+0xA0], xmm10
000073dfa87d59df  vmovaps [rsp+0xB0], xmm11
000073dfa87d59e8  vmovaps [rsp+0xC0], xmm12
000073dfa87d59f1  vmovaps [rsp+0xD0], xmm13
000073dfa87d59fa  vmovaps [rsp+0xE0], xmm15
000073dfa87d5a03  sub rsp, 0x30
000073dfa87d5a07  movaps [rsp], xmm14
000073dfa87d5a0c  movaps [rsp+0x10], xmm6
000073dfa87d5a11  movaps [rsp+0x20], xmm2
000073dfa87d5a16  lea rdi, [rsp]
000073dfa87d5a1a  mov esi, 0x00
000073dfa87d5a1f  mov rax, 0x593AA1DA4530
000073dfa87d5a29  call rax
000073dfa87d5a2b  movaps xmm14, [rsp]
000073dfa87d5a30  add rsp, 0x30
000073dfa87d5a34  vmovaps xmm0, [rsp]
000073dfa87d5a39  vmovaps xmm1, [rsp+0x10]
000073dfa87d5a3f  vmovaps xmm2, [rsp+0x20]
000073dfa87d5a45  vmovaps xmm3, [rsp+0x30]
000073dfa87d5a4b  vmovaps xmm4, [rsp+0x40]
000073dfa87d5a51  vmovaps xmm5, [rsp+0x50]
000073dfa87d5a57  vmovaps xmm6, [rsp+0x60]
000073dfa87d5a5d  vmovaps xmm7, [rsp+0x70]
000073dfa87d5a63  vmovaps xmm8, [rsp+0x80]
000073dfa87d5a6c  vmovaps xmm9, [rsp+0x90]
000073dfa87d5a75  vmovaps xmm10, [rsp+0xA0]
000073dfa87d5a7e  vmovaps xmm11, [rsp+0xB0]
000073dfa87d5a87  vmovaps xmm12, [rsp+0xC0]
000073dfa87d5a90  vmovaps xmm13, [rsp+0xD0]
000073dfa87d5a99  vmovaps xmm15, [rsp+0xE0]
000073dfa87d5aa2  add rsp, 0xF0
000073dfa87d5aa9  pop r11
000073dfa87d5aab  pop r10
000073dfa87d5aad  pop r9
000073dfa87d5aaf  pop r8
000073dfa87d5ab1  pop rsi
000073dfa87d5ab2  pop rdi
000073dfa87d5ab3  pop rdx
000073dfa87d5ab4  pop rcx
000073dfa87d5ab5  pop rax
000073dfa87d5ab6  add rsp, 0x08
000073dfa87d5aba  jmp 0x000073DFA87D2F99
000073dfa87d5abf  sub rsp, 0x08
000073dfa87d5ac3  push rax
000073dfa87d5ac4  push rcx
000073dfa87d5ac5  push rdx
000073dfa87d5ac6  push rdi
000073dfa87d5ac7  push rsi
000073dfa87d5ac8  push r8
000073dfa87d5aca  push r9
000073dfa87d5acc  push r10
000073dfa87d5ace  push r11
000073dfa87d5ad0  sub rsp, 0xF0
000073dfa87d5ad7  vmovaps [rsp], xmm0
000073dfa87d5adc  vmovaps [rsp+0x10], xmm1
000073dfa87d5ae2  vmovaps [rsp+0x20], xmm2
000073dfa87d5ae8  vmovaps [rsp+0x30], xmm3
000073dfa87d5aee  vmovaps [rsp+0x40], xmm4
000073dfa87d5af4  vmovaps [rsp+0x50], xmm5
000073dfa87d5afa  vmovaps [rsp+0x60], xmm7
000073dfa87d5b00  vmovaps [rsp+0x70], xmm8
000073dfa87d5b06  vmovaps [rsp+0x80], xmm9
000073dfa87d5b0f  vmovaps [rsp+0x90], xmm10
000073dfa87d5b18  vmovaps [rsp+0xA0], xmm11
000073dfa87d5b21  vmovaps [rsp+0xB0], xmm12
000073dfa87d5b2a  vmovaps [rsp+0xC0], xmm13
000073dfa87d5b33  vmovaps [rsp+0xD0], xmm14
000073dfa87d5b3c  vmovaps [rsp+0xE0], xmm15
000073dfa87d5b45  sub rsp, 0x30
000073dfa87d5b49  movaps [rsp], xmm6
000073dfa87d5b4d  movaps [rsp+0x10], xmm5
000073dfa87d5b52  movaps [rsp+0x20], xmm1
000073dfa87d5b57  lea rdi, [rsp]
000073dfa87d5b5b  mov esi, 0x00
000073dfa87d5b60  mov rax, 0x593AA1DA4530
000073dfa87d5b6a  call rax
000073dfa87d5b6c  movaps xmm6, [rsp]
000073dfa87d5b70  add rsp, 0x30
000073dfa87d5b74  vmovaps xmm0, [rsp]
000073dfa87d5b79  vmovaps xmm1, [rsp+0x10]
000073dfa87d5b7f  vmovaps xmm2, [rsp+0x20]
000073dfa87d5b85  vmovaps xmm3, [rsp+0x30]
000073dfa87d5b8b  vmovaps xmm4, [rsp+0x40]
000073dfa87d5b91  vmovaps xmm5, [rsp+0x50]
000073dfa87d5b97  vmovaps xmm7, [rsp+0x60]
000073dfa87d5b9d  vmovaps xmm8, [rsp+0x70]
000073dfa87d5ba3  vmovaps xmm9, [rsp+0x80]
000073dfa87d5bac  vmovaps xmm10, [rsp+0x90]
000073dfa87d5bb5  vmovaps xmm11, [rsp+0xA0]
000073dfa87d5bbe  vmovaps xmm12, [rsp+0xB0]
000073dfa87d5bc7  vmovaps xmm13, [rsp+0xC0]
000073dfa87d5bd0  vmovaps xmm14, [rsp+0xD0]
000073dfa87d5bd9  vmovaps xmm15, [rsp+0xE0]
000073dfa87d5be2  add rsp, 0xF0
000073dfa87d5be9  pop r11
000073dfa87d5beb  pop r10
000073dfa87d5bed  pop r9
000073dfa87d5bef  pop r8
000073dfa87d5bf1  pop rsi
000073dfa87d5bf2  pop rdi
000073dfa87d5bf3  pop rdx
000073dfa87d5bf4  pop rcx
000073dfa87d5bf5  pop rax
000073dfa87d5bf6  add rsp, 0x08
000073dfa87d5bfa  jmp 0x000073DFA87D2FBF
000073dfa87d5bff  sub rsp, 0x08
000073dfa87d5c03  push rax
000073dfa87d5c04  push rcx
000073dfa87d5c05  push rdx
000073dfa87d5c06  push rdi
000073dfa87d5c07  push rsi
000073dfa87d5c08  push r8
000073dfa87d5c0a  push r9
000073dfa87d5c0c  push r10
000073dfa87d5c0e  push r11
000073dfa87d5c10  sub rsp, 0xF0
000073dfa87d5c17  vmovaps [rsp], xmm0
000073dfa87d5c1c  vmovaps [rsp+0x10], xmm2
000073dfa87d5c22  vmovaps [rsp+0x20], xmm3
000073dfa87d5c28  vmovaps [rsp+0x30], xmm4
000073dfa87d5c2e  vmovaps [rsp+0x40], xmm5
000073dfa87d5c34  vmovaps [rsp+0x50], xmm6
000073dfa87d5c3a  vmovaps [rsp+0x60], xmm7
000073dfa87d5c40  vmovaps [rsp+0x70], xmm8
000073dfa87d5c46  vmovaps [rsp+0x80], xmm9
000073dfa87d5c4f  vmovaps [rsp+0x90], xmm10
000073dfa87d5c58  vmovaps [rsp+0xA0], xmm11
000073dfa87d5c61  vmovaps [rsp+0xB0], xmm12
000073dfa87d5c6a  vmovaps [rsp+0xC0], xmm13
000073dfa87d5c73  vmovaps [rsp+0xD0], xmm14
000073dfa87d5c7c  vmovaps [rsp+0xE0], xmm15
000073dfa87d5c85  sub rsp, 0x30
000073dfa87d5c89  movaps [rsp], xmm1
000073dfa87d5c8d  movaps [rsp+0x10], xmm5
000073dfa87d5c92  movaps [rsp+0x20], xmm13
000073dfa87d5c98  lea rdi, [rsp]
000073dfa87d5c9c  mov esi, 0x00
000073dfa87d5ca1  mov rax, 0x593AA1DA4530
000073dfa87d5cab  call rax
000073dfa87d5cad  movaps xmm1, [rsp]
000073dfa87d5cb1  add rsp, 0x30
000073dfa87d5cb5  vmovaps xmm0, [rsp]
000073dfa87d5cba  vmovaps xmm2, [rsp+0x10]
000073dfa87d5cc0  vmovaps xmm3, [rsp+0x20]
000073dfa87d5cc6  vmovaps xmm4, [rsp+0x30]
000073dfa87d5ccc  vmovaps xmm5, [rsp+0x40]
000073dfa87d5cd2  vmovaps xmm6, [rsp+0x50]
000073dfa87d5cd8  vmovaps xmm7, [rsp+0x60]
000073dfa87d5cde  vmovaps xmm8, [rsp+0x70]
000073dfa87d5ce4  vmovaps xmm9, [rsp+0x80]
000073dfa87d5ced  vmovaps xmm10, [rsp+0x90]
000073dfa87d5cf6  vmovaps xmm11, [rsp+0xA0]
000073dfa87d5cff  vmovaps xmm12, [rsp+0xB0]
000073dfa87d5d08  vmovaps xmm13, [rsp+0xC0]
000073dfa87d5d11  vmovaps xmm14, [rsp+0xD0]
000073dfa87d5d1a  vmovaps xmm15, [rsp+0xE0]
000073dfa87d5d23  add rsp, 0xF0
000073dfa87d5d2a  pop r11
000073dfa87d5d2c  pop r10
000073dfa87d5d2e  pop r9
000073dfa87d5d30  pop r8
000073dfa87d5d32  pop rsi
000073dfa87d5d33  pop rdi
000073dfa87d5d34  pop rdx
000073dfa87d5d35  pop rcx
000073dfa87d5d36  pop rax
000073dfa87d5d37  add rsp, 0x08
000073dfa87d5d3b  jmp 0x000073DFA87D2FDD
000073dfa87d5d40  sub rsp, 0x08
000073dfa87d5d44  push rax
000073dfa87d5d45  push rcx
000073dfa87d5d46  push rdx
000073dfa87d5d47  push rdi
000073dfa87d5d48  push rsi
000073dfa87d5d49  push r8
000073dfa87d5d4b  push r9
000073dfa87d5d4d  push r10
000073dfa87d5d4f  push r11
000073dfa87d5d51  sub rsp, 0xF0
000073dfa87d5d58  vmovaps [rsp], xmm0
000073dfa87d5d5d  vmovaps [rsp+0x10], xmm1
000073dfa87d5d63  vmovaps [rsp+0x20], xmm2
000073dfa87d5d69  vmovaps [rsp+0x30], xmm3
000073dfa87d5d6f  vmovaps [rsp+0x40], xmm4
000073dfa87d5d75  vmovaps [rsp+0x50], xmm6
000073dfa87d5d7b  vmovaps [rsp+0x60], xmm7
000073dfa87d5d81  vmovaps [rsp+0x70], xmm8
000073dfa87d5d87  vmovaps [rsp+0x80], xmm9
000073dfa87d5d90  vmovaps [rsp+0x90], xmm10
000073dfa87d5d99  vmovaps [rsp+0xA0], xmm11
000073dfa87d5da2  vmovaps [rsp+0xB0], xmm12
000073dfa87d5dab  vmovaps [rsp+0xC0], xmm13
000073dfa87d5db4  vmovaps [rsp+0xD0], xmm14
000073dfa87d5dbd  vmovaps [rsp+0xE0], xmm15
000073dfa87d5dc6  sub rsp, 0x30
000073dfa87d5dca  movaps [rsp], xmm5
000073dfa87d5dce  movaps [rsp+0x10], xmm2
000073dfa87d5dd3  movaps [rsp+0x20], xmm13
000073dfa87d5dd9  lea rdi, [rsp]
000073dfa87d5ddd  mov esi, 0x00
000073dfa87d5de2  mov rax, 0x593AA1DA4530
000073dfa87d5dec  call rax
000073dfa87d5dee  movaps xmm5, [rsp]
000073dfa87d5df2  add rsp, 0x30
000073dfa87d5df6  vmovaps xmm0, [rsp]
000073dfa87d5dfb  vmovaps xmm1, [rsp+0x10]
000073dfa87d5e01  vmovaps xmm2, [rsp+0x20]
000073dfa87d5e07  vmovaps xmm3, [rsp+0x30]
000073dfa87d5e0d  vmovaps xmm4, [rsp+0x40]
000073dfa87d5e13  vmovaps xmm6, [rsp+0x50]
000073dfa87d5e19  vmovaps xmm7, [rsp+0x60]
000073dfa87d5e1f  vmovaps xmm8, [rsp+0x70]
000073dfa87d5e25  vmovaps xmm9, [rsp+0x80]
000073dfa87d5e2e  vmovaps xmm10, [rsp+0x90]
000073dfa87d5e37  vmovaps xmm11, [rsp+0xA0]
000073dfa87d5e40  vmovaps xmm12, [rsp+0xB0]
000073dfa87d5e49  vmovaps xmm13, [rsp+0xC0]
000073dfa87d5e52  vmovaps xmm14, [rsp+0xD0]
000073dfa87d5e5b  vmovaps xmm15, [rsp+0xE0]
000073dfa87d5e64  add rsp, 0xF0
000073dfa87d5e6b  pop r11
000073dfa87d5e6d  pop r10
000073dfa87d5e6f  pop r9
000073dfa87d5e71  pop r8
000073dfa87d5e73  pop rsi
000073dfa87d5e74  pop rdi
000073dfa87d5e75  pop rdx
000073dfa87d5e76  pop rcx
000073dfa87d5e77  pop rax
000073dfa87d5e78  add rsp, 0x08
000073dfa87d5e7c  jmp 0x000073DFA87D3013
000073dfa87d5e81  sub rsp, 0x08
000073dfa87d5e85  push rax
000073dfa87d5e86  push rcx
000073dfa87d5e87  push rdx
000073dfa87d5e88  push rdi
000073dfa87d5e89  push rsi
000073dfa87d5e8a  push r8
000073dfa87d5e8c  push r9
000073dfa87d5e8e  push r10
000073dfa87d5e90  push r11
000073dfa87d5e92  sub rsp, 0xF0
000073dfa87d5e99  vmovaps [rsp], xmm0
000073dfa87d5e9e  vmovaps [rsp+0x10], xmm1
000073dfa87d5ea4  vmovaps [rsp+0x20], xmm2
000073dfa87d5eaa  vmovaps [rsp+0x30], xmm3
000073dfa87d5eb0  vmovaps [rsp+0x40], xmm4
000073dfa87d5eb6  vmovaps [rsp+0x50], xmm5
000073dfa87d5ebc  vmovaps [rsp+0x60], xmm6
000073dfa87d5ec2  vmovaps [rsp+0x70], xmm7
000073dfa87d5ec8  vmovaps [rsp+0x80], xmm8
000073dfa87d5ed1  vmovaps [rsp+0x90], xmm9
000073dfa87d5eda  vmovaps [rsp+0xA0], xmm10
000073dfa87d5ee3  vmovaps [rsp+0xB0], xmm11
000073dfa87d5eec  vmovaps [rsp+0xC0], xmm12
000073dfa87d5ef5  vmovaps [rsp+0xD0], xmm14
000073dfa87d5efe  vmovaps [rsp+0xE0], xmm15
000073dfa87d5f07  sub rsp, 0x30
000073dfa87d5f0b  movaps [rsp], xmm13
000073dfa87d5f10  movaps [rsp+0x10], xmm10
000073dfa87d5f16  movaps [rsp+0x20], xmm1
000073dfa87d5f1b  lea rdi, [rsp]
000073dfa87d5f1f  mov esi, 0x00
000073dfa87d5f24  mov rax, 0x593AA1DA4530
000073dfa87d5f2e  call rax
000073dfa87d5f30  movaps xmm13, [rsp]
000073dfa87d5f35  add rsp, 0x30
000073dfa87d5f39  vmovaps xmm0, [rsp]
000073dfa87d5f3e  vmovaps xmm1, [rsp+0x10]
000073dfa87d5f44  vmovaps xmm2, [rsp+0x20]
000073dfa87d5f4a  vmovaps xmm3, [rsp+0x30]
000073dfa87d5f50  vmovaps xmm4, [rsp+0x40]
000073dfa87d5f56  vmovaps xmm5, [rsp+0x50]
000073dfa87d5f5c  vmovaps xmm6, [rsp+0x60]
000073dfa87d5f62  vmovaps xmm7, [rsp+0x70]
000073dfa87d5f68  vmovaps xmm8, [rsp+0x80]
000073dfa87d5f71  vmovaps xmm9, [rsp+0x90]
000073dfa87d5f7a  vmovaps xmm10, [rsp+0xA0]
000073dfa87d5f83  vmovaps xmm11, [rsp+0xB0]
000073dfa87d5f8c  vmovaps xmm12, [rsp+0xC0]
000073dfa87d5f95  vmovaps xmm14, [rsp+0xD0]
000073dfa87d5f9e  vmovaps xmm15, [rsp+0xE0]
000073dfa87d5fa7  add rsp, 0xF0
000073dfa87d5fae  pop r11
000073dfa87d5fb0  pop r10
000073dfa87d5fb2  pop r9
000073dfa87d5fb4  pop r8
000073dfa87d5fb6  pop rsi
000073dfa87d5fb7  pop rdi
000073dfa87d5fb8  pop rdx
000073dfa87d5fb9  pop rcx
000073dfa87d5fba  pop rax
000073dfa87d5fbb  add rsp, 0x08
000073dfa87d5fbf  jmp 0x000073DFA87D303C
000073dfa87d5fc4  sub rsp, 0x08
000073dfa87d5fc8  push rax
000073dfa87d5fc9  push rcx
000073dfa87d5fca  push rdx
000073dfa87d5fcb  push rdi
000073dfa87d5fcc  push rsi
000073dfa87d5fcd  push r8
000073dfa87d5fcf  push r9
000073dfa87d5fd1  push r10
000073dfa87d5fd3  push r11
000073dfa87d5fd5  sub rsp, 0xF0
000073dfa87d5fdc  vmovaps [rsp], xmm0
000073dfa87d5fe1  vmovaps [rsp+0x10], xmm2
000073dfa87d5fe7  vmovaps [rsp+0x20], xmm3
000073dfa87d5fed  vmovaps [rsp+0x30], xmm4
000073dfa87d5ff3  vmovaps [rsp+0x40], xmm5
000073dfa87d5ff9  vmovaps [rsp+0x50], xmm6
000073dfa87d5fff  vmovaps [rsp+0x60], xmm7
000073dfa87d6005  vmovaps [rsp+0x70], xmm8
000073dfa87d600b  vmovaps [rsp+0x80], xmm9
000073dfa87d6014  vmovaps [rsp+0x90], xmm10
000073dfa87d601d  vmovaps [rsp+0xA0], xmm11
000073dfa87d6026  vmovaps [rsp+0xB0], xmm12
000073dfa87d602f  vmovaps [rsp+0xC0], xmm13
000073dfa87d6038  vmovaps [rsp+0xD0], xmm14
000073dfa87d6041  vmovaps [rsp+0xE0], xmm15
000073dfa87d604a  sub rsp, 0x30
000073dfa87d604e  movaps [rsp], xmm1
000073dfa87d6052  movaps [rsp+0x10], xmm15
000073dfa87d6058  movaps [rsp+0x20], xmm10
000073dfa87d605e  lea rdi, [rsp]
000073dfa87d6062  mov esi, 0x00
000073dfa87d6067  mov rax, 0x593AA1DA4530
000073dfa87d6071  call rax
000073dfa87d6073  movaps xmm1, [rsp]
000073dfa87d6077  add rsp, 0x30
000073dfa87d607b  vmovaps xmm0, [rsp]
000073dfa87d6080  vmovaps xmm2, [rsp+0x10]
000073dfa87d6086  vmovaps xmm3, [rsp+0x20]
000073dfa87d608c  vmovaps xmm4, [rsp+0x30]
000073dfa87d6092  vmovaps xmm5, [rsp+0x40]
000073dfa87d6098  vmovaps xmm6, [rsp+0x50]
000073dfa87d609e  vmovaps xmm7, [rsp+0x60]
000073dfa87d60a4  vmovaps xmm8, [rsp+0x70]
000073dfa87d60aa  vmovaps xmm9, [rsp+0x80]
000073dfa87d60b3  vmovaps xmm10, [rsp+0x90]
000073dfa87d60bc  vmovaps xmm11, [rsp+0xA0]
000073dfa87d60c5  vmovaps xmm12, [rsp+0xB0]
000073dfa87d60ce  vmovaps xmm13, [rsp+0xC0]
000073dfa87d60d7  vmovaps xmm14, [rsp+0xD0]
000073dfa87d60e0  vmovaps xmm15, [rsp+0xE0]
000073dfa87d60e9  add rsp, 0xF0
000073dfa87d60f0  pop r11
000073dfa87d60f2  pop r10
000073dfa87d60f4  pop r9
000073dfa87d60f6  pop r8
000073dfa87d60f8  pop rsi
000073dfa87d60f9  pop rdi
000073dfa87d60fa  pop rdx
000073dfa87d60fb  pop rcx
000073dfa87d60fc  pop rax
000073dfa87d60fd  add rsp, 0x08
000073dfa87d6101  jmp 0x000073DFA87D305B
000073dfa87d6106  sub rsp, 0x08
000073dfa87d610a  push rax
000073dfa87d610b  push rcx
000073dfa87d610c  push rdx
000073dfa87d610d  push rdi
000073dfa87d610e  push rsi
000073dfa87d610f  push r8
000073dfa87d6111  push r9
000073dfa87d6113  push r10
000073dfa87d6115  push r11
000073dfa87d6117  sub rsp, 0xF0
000073dfa87d611e  vmovaps [rsp], xmm0
000073dfa87d6123  vmovaps [rsp+0x10], xmm1
000073dfa87d6129  vmovaps [rsp+0x20], xmm2
000073dfa87d612f  vmovaps [rsp+0x30], xmm3
000073dfa87d6135  vmovaps [rsp+0x40], xmm4
000073dfa87d613b  vmovaps [rsp+0x50], xmm5
000073dfa87d6141  vmovaps [rsp+0x60], xmm6
000073dfa87d6147  vmovaps [rsp+0x70], xmm7
000073dfa87d614d  vmovaps [rsp+0x80], xmm8
000073dfa87d6156  vmovaps [rsp+0x90], xmm9
000073dfa87d615f  vmovaps [rsp+0xA0], xmm10
000073dfa87d6168  vmovaps [rsp+0xB0], xmm11
000073dfa87d6171  vmovaps [rsp+0xC0], xmm12
000073dfa87d617a  vmovaps [rsp+0xD0], xmm13
000073dfa87d6183  vmovaps [rsp+0xE0], xmm14
000073dfa87d618c  sub rsp, 0x30
000073dfa87d6190  movaps [rsp], xmm15
000073dfa87d6195  movaps [rsp+0x10], xmm10
000073dfa87d619b  movaps [rsp+0x20], xmm11
000073dfa87d61a1  lea rdi, [rsp]
000073dfa87d61a5  mov esi, 0x00
000073dfa87d61aa  mov rax, 0x593AA1DA4530
000073dfa87d61b4  call rax
000073dfa87d61b6  movaps xmm15, [rsp]
000073dfa87d61bb  add rsp, 0x30
000073dfa87d61bf  vmovaps xmm0, [rsp]
000073dfa87d61c4  vmovaps xmm1, [rsp+0x10]
000073dfa87d61ca  vmovaps xmm2, [rsp+0x20]
000073dfa87d61d0  vmovaps xmm3, [rsp+0x30]
000073dfa87d61d6  vmovaps xmm4, [rsp+0x40]
000073dfa87d61dc  vmovaps xmm5, [rsp+0x50]
000073dfa87d61e2  vmovaps xmm6, [rsp+0x60]
000073dfa87d61e8  vmovaps xmm7, [rsp+0x70]
000073dfa87d61ee  vmovaps xmm8, [rsp+0x80]
000073dfa87d61f7  vmovaps xmm9, [rsp+0x90]
000073dfa87d6200  vmovaps xmm10, [rsp+0xA0]
000073dfa87d6209  vmovaps xmm11, [rsp+0xB0]
000073dfa87d6212  vmovaps xmm12, [rsp+0xC0]
000073dfa87d621b  vmovaps xmm13, [rsp+0xD0]
000073dfa87d6224  vmovaps xmm14, [rsp+0xE0]
000073dfa87d622d  add rsp, 0xF0
000073dfa87d6234  pop r11
000073dfa87d6236  pop r10
000073dfa87d6238  pop r9
000073dfa87d623a  pop r8
000073dfa87d623c  pop rsi
000073dfa87d623d  pop rdi
000073dfa87d623e  pop rdx
000073dfa87d623f  pop rcx
000073dfa87d6240  pop rax
000073dfa87d6241  add rsp, 0x08
000073dfa87d6245  jmp 0x000073DFA87D307E
000073dfa87d624a  sub rsp, 0x08
000073dfa87d624e  push rax
000073dfa87d624f  push rcx
000073dfa87d6250  push rdx
000073dfa87d6251  push rdi
000073dfa87d6252  push rsi
000073dfa87d6253  push r8
000073dfa87d6255  push r9
000073dfa87d6257  push r10
000073dfa87d6259  push r11
000073dfa87d625b  sub rsp, 0xF0
000073dfa87d6262  vmovaps [rsp], xmm0
000073dfa87d6267  vmovaps [rsp+0x10], xmm1
000073dfa87d626d  vmovaps [rsp+0x20], xmm2
000073dfa87d6273  vmovaps [rsp+0x30], xmm3
000073dfa87d6279  vmovaps [rsp+0x40], xmm4
000073dfa87d627f  vmovaps [rsp+0x50], xmm5
000073dfa87d6285  vmovaps [rsp+0x60], xmm6
000073dfa87d628b  vmovaps [rsp+0x70], xmm7
000073dfa87d6291  vmovaps [rsp+0x80], xmm8
000073dfa87d629a  vmovaps [rsp+0x90], xmm9
000073dfa87d62a3  vmovaps [rsp+0xA0], xmm11
000073dfa87d62ac  vmovaps [rsp+0xB0], xmm12
000073dfa87d62b5  vmovaps [rsp+0xC0], xmm13
000073dfa87d62be  vmovaps [rsp+0xD0], xmm14
000073dfa87d62c7  vmovaps [rsp+0xE0], xmm15
000073dfa87d62d0  sub rsp, 0x30
000073dfa87d62d4  movaps [rsp], xmm10
000073dfa87d62d9  movaps [rsp+0x10], xmm2
000073dfa87d62de  movaps [rsp+0x20], xmm11
000073dfa87d62e4  lea rdi, [rsp]
000073dfa87d62e8  mov esi, 0x00
000073dfa87d62ed  mov rax, 0x593AA1DA4530
000073dfa87d62f7  call rax
000073dfa87d62f9  movaps xmm10, [rsp]
000073dfa87d62fe  add rsp, 0x30
000073dfa87d6302  vmovaps xmm0, [rsp]
000073dfa87d6307  vmovaps xmm1, [rsp+0x10]
000073dfa87d630d  vmovaps xmm2, [rsp+0x20]
000073dfa87d6313  vmovaps xmm3, [rsp+0x30]
000073dfa87d6319  vmovaps xmm4, [rsp+0x40]
000073dfa87d631f  vmovaps xmm5, [rsp+0x50]
000073dfa87d6325  vmovaps xmm6, [rsp+0x60]
000073dfa87d632b  vmovaps xmm7, [rsp+0x70]
000073dfa87d6331  vmovaps xmm8, [rsp+0x80]
000073dfa87d633a  vmovaps xmm9, [rsp+0x90]
000073dfa87d6343  vmovaps xmm11, [rsp+0xA0]
000073dfa87d634c  vmovaps xmm12, [rsp+0xB0]
000073dfa87d6355  vmovaps xmm13, [rsp+0xC0]
000073dfa87d635e  vmovaps xmm14, [rsp+0xD0]
000073dfa87d6367  vmovaps xmm15, [rsp+0xE0]
000073dfa87d6370  add rsp, 0xF0
000073dfa87d6377  pop r11
000073dfa87d6379  pop r10
000073dfa87d637b  pop r9
000073dfa87d637d  pop r8
000073dfa87d637f  pop rsi
000073dfa87d6380  pop rdi
000073dfa87d6381  pop rdx
000073dfa87d6382  pop rcx
000073dfa87d6383  pop rax
000073dfa87d6384  add rsp, 0x08
000073dfa87d6388  jmp 0x000073DFA87D30B6
000073dfa87d638d  sub rsp, 0x08
000073dfa87d6391  push rax
000073dfa87d6392  push rcx
000073dfa87d6393  push rdx
000073dfa87d6394  push rdi
000073dfa87d6395  push rsi
000073dfa87d6396  push r8
000073dfa87d6398  push r9
000073dfa87d639a  push r10
000073dfa87d639c  push r11
000073dfa87d639e  sub rsp, 0xF0
000073dfa87d63a5  vmovaps [rsp], xmm0
000073dfa87d63aa  vmovaps [rsp+0x10], xmm1
000073dfa87d63b0  vmovaps [rsp+0x20], xmm2
000073dfa87d63b6  vmovaps [rsp+0x30], xmm3
000073dfa87d63bc  vmovaps [rsp+0x40], xmm4
000073dfa87d63c2  vmovaps [rsp+0x50], xmm5
000073dfa87d63c8  vmovaps [rsp+0x60], xmm6
000073dfa87d63ce  vmovaps [rsp+0x70], xmm7
000073dfa87d63d4  vmovaps [rsp+0x80], xmm8
000073dfa87d63dd  vmovaps [rsp+0x90], xmm9
000073dfa87d63e6  vmovaps [rsp+0xA0], xmm10
000073dfa87d63ef  vmovaps [rsp+0xB0], xmm12
000073dfa87d63f8  vmovaps [rsp+0xC0], xmm13
000073dfa87d6401  vmovaps [rsp+0xD0], xmm14
000073dfa87d640a  vmovaps [rsp+0xE0], xmm15
000073dfa87d6413  sub rsp, 0x30
000073dfa87d6417  movaps [rsp], xmm11
000073dfa87d641c  movaps [rsp+0x10], xmm2
000073dfa87d6421  movaps [rsp+0x20], xmm1
000073dfa87d6426  lea rdi, [rsp]
000073dfa87d642a  mov esi, 0x00
000073dfa87d642f  mov rax, 0x593AA1DA4530
000073dfa87d6439  call rax
000073dfa87d643b  movaps xmm11, [rsp]
000073dfa87d6440  add rsp, 0x30
000073dfa87d6444  vmovaps xmm0, [rsp]
000073dfa87d6449  vmovaps xmm1, [rsp+0x10]
000073dfa87d644f  vmovaps xmm2, [rsp+0x20]
000073dfa87d6455  vmovaps xmm3, [rsp+0x30]
000073dfa87d645b  vmovaps xmm4, [rsp+0x40]
000073dfa87d6461  vmovaps xmm5, [rsp+0x50]
000073dfa87d6467  vmovaps xmm6, [rsp+0x60]
000073dfa87d646d  vmovaps xmm7, [rsp+0x70]
000073dfa87d6473  vmovaps xmm8, [rsp+0x80]
000073dfa87d647c  vmovaps xmm9, [rsp+0x90]
000073dfa87d6485  vmovaps xmm10, [rsp+0xA0]
000073dfa87d648e  vmovaps xmm12, [rsp+0xB0]
000073dfa87d6497  vmovaps xmm13, [rsp+0xC0]
000073dfa87d64a0  vmovaps xmm14, [rsp+0xD0]
000073dfa87d64a9  vmovaps xmm15, [rsp+0xE0]
000073dfa87d64b2  add rsp, 0xF0
000073dfa87d64b9  pop r11
000073dfa87d64bb  pop r10
000073dfa87d64bd  pop r9
000073dfa87d64bf  pop r8
000073dfa87d64c1  pop rsi
000073dfa87d64c2  pop rdi
000073dfa87d64c3  pop rdx
000073dfa87d64c4  pop rcx
000073dfa87d64c5  pop rax
000073dfa87d64c6  add rsp, 0x08
000073dfa87d64ca  jmp 0x000073DFA87D30F2
000073dfa87d64cf  sub rsp, 0x08
000073dfa87d64d3  push rax
000073dfa87d64d4  push rcx
000073dfa87d64d5  push rdx
000073dfa87d64d6  push rdi
000073dfa87d64d7  push rsi
000073dfa87d64d8  push r8
000073dfa87d64da  push r9
000073dfa87d64dc  push r10
000073dfa87d64de  push r11
000073dfa87d64e0  sub rsp, 0xF0
000073dfa87d64e7  vmovaps [rsp], xmm0
000073dfa87d64ec  vmovaps [rsp+0x10], xmm2
000073dfa87d64f2  vmovaps [rsp+0x20], xmm3
000073dfa87d64f8  vmovaps [rsp+0x30], xmm4
000073dfa87d64fe  vmovaps [rsp+0x40], xmm5
000073dfa87d6504  vmovaps [rsp+0x50], xmm6
000073dfa87d650a  vmovaps [rsp+0x60], xmm7
000073dfa87d6510  vmovaps [rsp+0x70], xmm8
000073dfa87d6516  vmovaps [rsp+0x80], xmm9
000073dfa87d651f  vmovaps [rsp+0x90], xmm10
000073dfa87d6528  vmovaps [rsp+0xA0], xmm11
000073dfa87d6531  vmovaps [rsp+0xB0], xmm12
000073dfa87d653a  vmovaps [rsp+0xC0], xmm13
000073dfa87d6543  vmovaps [rsp+0xD0], xmm14
000073dfa87d654c  vmovaps [rsp+0xE0], xmm15
000073dfa87d6555  sub rsp, 0x30
000073dfa87d6559  movaps [rsp], xmm1
000073dfa87d655d  movaps [rsp+0x10], xmm14
000073dfa87d6563  movaps [rsp+0x20], xmm6
000073dfa87d6568  lea rdi, [rsp]
000073dfa87d656c  mov esi, 0x00
000073dfa87d6571  mov rax, 0x593AA1DA4530
000073dfa87d657b  call rax
000073dfa87d657d  movaps xmm1, [rsp]
000073dfa87d6581  add rsp, 0x30
000073dfa87d6585  vmovaps xmm0, [rsp]
000073dfa87d658a  vmovaps xmm2, [rsp+0x10]
000073dfa87d6590  vmovaps xmm3, [rsp+0x20]
000073dfa87d6596  vmovaps xmm4, [rsp+0x30]
000073dfa87d659c  vmovaps xmm5, [rsp+0x40]
000073dfa87d65a2  vmovaps xmm6, [rsp+0x50]
000073dfa87d65a8  vmovaps xmm7, [rsp+0x60]
000073dfa87d65ae  vmovaps xmm8, [rsp+0x70]
000073dfa87d65b4  vmovaps xmm9, [rsp+0x80]
000073dfa87d65bd  vmovaps xmm10, [rsp+0x90]
000073dfa87d65c6  vmovaps xmm11, [rsp+0xA0]
000073dfa87d65cf  vmovaps xmm12, [rsp+0xB0]
000073dfa87d65d8  vmovaps xmm13, [rsp+0xC0]
000073dfa87d65e1  vmovaps xmm14, [rsp+0xD0]
000073dfa87d65ea  vmovaps xmm15, [rsp+0xE0]
000073dfa87d65f3  add rsp, 0xF0
000073dfa87d65fa  pop r11
000073dfa87d65fc  pop r10
000073dfa87d65fe  pop r9
000073dfa87d6600  pop r8
000073dfa87d6602  pop rsi
000073dfa87d6603  pop rdi
000073dfa87d6604  pop rdx
000073dfa87d6605  pop rcx
000073dfa87d6606  pop rax
000073dfa87d6607  add rsp, 0x08
000073dfa87d660b  jmp 0x000073DFA87D310B
000073dfa87d6610  sub rsp, 0x08
000073dfa87d6614  push rax
000073dfa87d6615  push rcx
000073dfa87d6616  push rdx
000073dfa87d6617  push rdi
000073dfa87d6618  push rsi
000073dfa87d6619  push r8
000073dfa87d661b  push r9
000073dfa87d661d  push r10
000073dfa87d661f  push r11
000073dfa87d6621  sub rsp, 0xF0
000073dfa87d6628  vmovaps [rsp], xmm0
000073dfa87d662d  vmovaps [rsp+0x10], xmm1
000073dfa87d6633  vmovaps [rsp+0x20], xmm2
000073dfa87d6639  vmovaps [rsp+0x30], xmm3
000073dfa87d663f  vmovaps [rsp+0x40], xmm4
000073dfa87d6645  vmovaps [rsp+0x50], xmm5
000073dfa87d664b  vmovaps [rsp+0x60], xmm6
000073dfa87d6651  vmovaps [rsp+0x70], xmm7
000073dfa87d6657  vmovaps [rsp+0x80], xmm8
000073dfa87d6660  vmovaps [rsp+0x90], xmm9
000073dfa87d6669  vmovaps [rsp+0xA0], xmm10
000073dfa87d6672  vmovaps [rsp+0xB0], xmm11
000073dfa87d667b  vmovaps [rsp+0xC0], xmm12
000073dfa87d6684  vmovaps [rsp+0xD0], xmm13
000073dfa87d668d  vmovaps [rsp+0xE0], xmm14
000073dfa87d6696  sub rsp, 0x30
000073dfa87d669a  movaps [rsp], xmm15
000073dfa87d669f  movaps [rsp+0x10], xmm14
000073dfa87d66a5  movaps [rsp+0x20], xmm5
000073dfa87d66aa  lea rdi, [rsp]
000073dfa87d66ae  mov esi, 0x00
000073dfa87d66b3  mov rax, 0x593AA1DA4530
000073dfa87d66bd  call rax
000073dfa87d66bf  movaps xmm15, [rsp]
000073dfa87d66c4  add rsp, 0x30
000073dfa87d66c8  vmovaps xmm0, [rsp]
000073dfa87d66cd  vmovaps xmm1, [rsp+0x10]
000073dfa87d66d3  vmovaps xmm2, [rsp+0x20]
000073dfa87d66d9  vmovaps xmm3, [rsp+0x30]
000073dfa87d66df  vmovaps xmm4, [rsp+0x40]
000073dfa87d66e5  vmovaps xmm5, [rsp+0x50]
000073dfa87d66eb  vmovaps xmm6, [rsp+0x60]
000073dfa87d66f1  vmovaps xmm7, [rsp+0x70]
000073dfa87d66f7  vmovaps xmm8, [rsp+0x80]
000073dfa87d6700  vmovaps xmm9, [rsp+0x90]
000073dfa87d6709  vmovaps xmm10, [rsp+0xA0]
000073dfa87d6712  vmovaps xmm11, [rsp+0xB0]
000073dfa87d671b  vmovaps xmm12, [rsp+0xC0]
000073dfa87d6724  vmovaps xmm13, [rsp+0xD0]
000073dfa87d672d  vmovaps xmm14, [rsp+0xE0]
000073dfa87d6736  add rsp, 0xF0
000073dfa87d673d  pop r11
000073dfa87d673f  pop r10
000073dfa87d6741  pop r9
000073dfa87d6743  pop r8
000073dfa87d6745  pop rsi
000073dfa87d6746  pop rdi
000073dfa87d6747  pop rdx
000073dfa87d6748  pop rcx
000073dfa87d6749  pop rax
000073dfa87d674a  add rsp, 0x08
000073dfa87d674e  jmp 0x000073DFA87D312B
000073dfa87d6753  sub rsp, 0x08
000073dfa87d6757  push rax
000073dfa87d6758  push rcx
000073dfa87d6759  push rdx
000073dfa87d675a  push rdi
000073dfa87d675b  push rsi
000073dfa87d675c  push r8
000073dfa87d675e  push r9
000073dfa87d6760  push r10
000073dfa87d6762  push r11
000073dfa87d6764  sub rsp, 0xF0
000073dfa87d676b  vmovaps [rsp], xmm0
000073dfa87d6770  vmovaps [rsp+0x10], xmm1
000073dfa87d6776  vmovaps [rsp+0x20], xmm2
000073dfa87d677c  vmovaps [rsp+0x30], xmm3
000073dfa87d6782  vmovaps [rsp+0x40], xmm4
000073dfa87d6788  vmovaps [rsp+0x50], xmm5
000073dfa87d678e  vmovaps [rsp+0x60], xmm7
000073dfa87d6794  vmovaps [rsp+0x70], xmm8
000073dfa87d679a  vmovaps [rsp+0x80], xmm9
000073dfa87d67a3  vmovaps [rsp+0x90], xmm10
000073dfa87d67ac  vmovaps [rsp+0xA0], xmm11
000073dfa87d67b5  vmovaps [rsp+0xB0], xmm12
000073dfa87d67be  vmovaps [rsp+0xC0], xmm13
000073dfa87d67c7  vmovaps [rsp+0xD0], xmm14
000073dfa87d67d0  vmovaps [rsp+0xE0], xmm15
000073dfa87d67d9  sub rsp, 0x30
000073dfa87d67dd  movaps [rsp], xmm6
000073dfa87d67e1  movaps [rsp+0x10], xmm9
000073dfa87d67e7  movaps [rsp+0x20], xmm14
000073dfa87d67ed  lea rdi, [rsp]
000073dfa87d67f1  mov esi, 0x00
000073dfa87d67f6  mov rax, 0x593AA1DA4530
000073dfa87d6800  call rax
000073dfa87d6802  movaps xmm6, [rsp]
000073dfa87d6806  add rsp, 0x30
000073dfa87d680a  vmovaps xmm0, [rsp]
000073dfa87d680f  vmovaps xmm1, [rsp+0x10]
000073dfa87d6815  vmovaps xmm2, [rsp+0x20]
000073dfa87d681b  vmovaps xmm3, [rsp+0x30]
000073dfa87d6821  vmovaps xmm4, [rsp+0x40]
000073dfa87d6827  vmovaps xmm5, [rsp+0x50]
000073dfa87d682d  vmovaps xmm7, [rsp+0x60]
000073dfa87d6833  vmovaps xmm8, [rsp+0x70]
000073dfa87d6839  vmovaps xmm9, [rsp+0x80]
000073dfa87d6842  vmovaps xmm10, [rsp+0x90]
000073dfa87d684b  vmovaps xmm11, [rsp+0xA0]
000073dfa87d6854  vmovaps xmm12, [rsp+0xB0]
000073dfa87d685d  vmovaps xmm13, [rsp+0xC0]
000073dfa87d6866  vmovaps xmm14, [rsp+0xD0]
000073dfa87d686f  vmovaps xmm15, [rsp+0xE0]
000073dfa87d6878  add rsp, 0xF0
000073dfa87d687f  pop r11
000073dfa87d6881  pop r10
000073dfa87d6883  pop r9
000073dfa87d6885  pop r8
000073dfa87d6887  pop rsi
000073dfa87d6888  pop rdi
000073dfa87d6889  pop rdx
000073dfa87d688a  pop rcx
000073dfa87d688b  pop rax
000073dfa87d688c  add rsp, 0x08
000073dfa87d6890  jmp 0x000073DFA87D3153
000073dfa87d6895  sub rsp, 0x08
000073dfa87d6899  push rax
000073dfa87d689a  push rcx
000073dfa87d689b  push rdx
000073dfa87d689c  push rdi
000073dfa87d689d  push rsi
000073dfa87d689e  push r8
000073dfa87d68a0  push r9
000073dfa87d68a2  push r10
000073dfa87d68a4  push r11
000073dfa87d68a6  sub rsp, 0xF0
000073dfa87d68ad  vmovaps [rsp], xmm0
000073dfa87d68b2  vmovaps [rsp+0x10], xmm1
000073dfa87d68b8  vmovaps [rsp+0x20], xmm2
000073dfa87d68be  vmovaps [rsp+0x30], xmm3
000073dfa87d68c4  vmovaps [rsp+0x40], xmm4
000073dfa87d68ca  vmovaps [rsp+0x50], xmm5
000073dfa87d68d0  vmovaps [rsp+0x60], xmm6
000073dfa87d68d6  vmovaps [rsp+0x70], xmm7
000073dfa87d68dc  vmovaps [rsp+0x80], xmm8
000073dfa87d68e5  vmovaps [rsp+0x90], xmm9
000073dfa87d68ee  vmovaps [rsp+0xA0], xmm10
000073dfa87d68f7  vmovaps [rsp+0xB0], xmm11
000073dfa87d6900  vmovaps [rsp+0xC0], xmm12
000073dfa87d6909  vmovaps [rsp+0xD0], xmm13
000073dfa87d6912  vmovaps [rsp+0xE0], xmm15
000073dfa87d691b  sub rsp, 0x30
000073dfa87d691f  movaps [rsp], xmm14
000073dfa87d6924  movaps [rsp+0x10], xmm9
000073dfa87d692a  movaps [rsp+0x20], xmm13
000073dfa87d6930  lea rdi, [rsp]
000073dfa87d6934  mov esi, 0x00
000073dfa87d6939  mov rax, 0x593AA1DA4530
000073dfa87d6943  call rax
000073dfa87d6945  movaps xmm14, [rsp]
000073dfa87d694a  add rsp, 0x30
000073dfa87d694e  vmovaps xmm0, [rsp]
000073dfa87d6953  vmovaps xmm1, [rsp+0x10]
000073dfa87d6959  vmovaps xmm2, [rsp+0x20]
000073dfa87d695f  vmovaps xmm3, [rsp+0x30]
000073dfa87d6965  vmovaps xmm4, [rsp+0x40]
000073dfa87d696b  vmovaps xmm5, [rsp+0x50]
000073dfa87d6971  vmovaps xmm6, [rsp+0x60]
000073dfa87d6977  vmovaps xmm7, [rsp+0x70]
000073dfa87d697d  vmovaps xmm8, [rsp+0x80]
000073dfa87d6986  vmovaps xmm9, [rsp+0x90]
000073dfa87d698f  vmovaps xmm10, [rsp+0xA0]
000073dfa87d6998  vmovaps xmm11, [rsp+0xB0]
000073dfa87d69a1  vmovaps xmm12, [rsp+0xC0]
000073dfa87d69aa  vmovaps xmm13, [rsp+0xD0]
000073dfa87d69b3  vmovaps xmm15, [rsp+0xE0]
000073dfa87d69bc  add rsp, 0xF0
000073dfa87d69c3  pop r11
000073dfa87d69c5  pop r10
000073dfa87d69c7  pop r9
000073dfa87d69c9  pop r8
000073dfa87d69cb  pop rsi
000073dfa87d69cc  pop rdi
000073dfa87d69cd  pop rdx
000073dfa87d69ce  pop rcx
000073dfa87d69cf  pop rax
000073dfa87d69d0  add rsp, 0x08
000073dfa87d69d4  jmp 0x000073DFA87D3176
000073dfa87d69d9  sub rsp, 0x08
000073dfa87d69dd  push rax
000073dfa87d69de  push rcx
000073dfa87d69df  push rdx
000073dfa87d69e0  push rdi
000073dfa87d69e1  push rsi
000073dfa87d69e2  push r8
000073dfa87d69e4  push r9
000073dfa87d69e6  push r10
000073dfa87d69e8  push r11
000073dfa87d69ea  sub rsp, 0xF0
000073dfa87d69f1  vmovaps [rsp], xmm0
000073dfa87d69f6  vmovaps [rsp+0x10], xmm1
000073dfa87d69fc  vmovaps [rsp+0x20], xmm2
000073dfa87d6a02  vmovaps [rsp+0x30], xmm3
000073dfa87d6a08  vmovaps [rsp+0x40], xmm4
000073dfa87d6a0e  vmovaps [rsp+0x50], xmm5
000073dfa87d6a14  vmovaps [rsp+0x60], xmm6
000073dfa87d6a1a  vmovaps [rsp+0x70], xmm7
000073dfa87d6a20  vmovaps [rsp+0x80], xmm8
000073dfa87d6a29  vmovaps [rsp+0x90], xmm9
000073dfa87d6a32  vmovaps [rsp+0xA0], xmm10
000073dfa87d6a3b  vmovaps [rsp+0xB0], xmm11
000073dfa87d6a44  vmovaps [rsp+0xC0], xmm12
000073dfa87d6a4d  vmovaps [rsp+0xD0], xmm14
000073dfa87d6a56  vmovaps [rsp+0xE0], xmm15
000073dfa87d6a5f  sub rsp, 0x30
000073dfa87d6a63  movaps [rsp], xmm13
000073dfa87d6a68  movaps [rsp+0x10], xmm9
000073dfa87d6a6e  movaps [rsp+0x20], xmm10
000073dfa87d6a74  lea rdi, [rsp]
000073dfa87d6a78  mov esi, 0x00
000073dfa87d6a7d  mov rax, 0x593AA1DA4530
000073dfa87d6a87  call rax
000073dfa87d6a89  movaps xmm13, [rsp]
000073dfa87d6a8e  add rsp, 0x30
000073dfa87d6a92  vmovaps xmm0, [rsp]
000073dfa87d6a97  vmovaps xmm1, [rsp+0x10]
000073dfa87d6a9d  vmovaps xmm2, [rsp+0x20]
000073dfa87d6aa3  vmovaps xmm3, [rsp+0x30]
000073dfa87d6aa9  vmovaps xmm4, [rsp+0x40]
000073dfa87d6aaf  vmovaps xmm5, [rsp+0x50]
000073dfa87d6ab5  vmovaps xmm6, [rsp+0x60]
000073dfa87d6abb  vmovaps xmm7, [rsp+0x70]
000073dfa87d6ac1  vmovaps xmm8, [rsp+0x80]
000073dfa87d6aca  vmovaps xmm9, [rsp+0x90]
000073dfa87d6ad3  vmovaps xmm10, [rsp+0xA0]
000073dfa87d6adc  vmovaps xmm11, [rsp+0xB0]
000073dfa87d6ae5  vmovaps xmm12, [rsp+0xC0]
000073dfa87d6aee  vmovaps xmm14, [rsp+0xD0]
000073dfa87d6af7  vmovaps xmm15, [rsp+0xE0]
000073dfa87d6b00  add rsp, 0xF0
000073dfa87d6b07  pop r11
000073dfa87d6b09  pop r10
000073dfa87d6b0b  pop r9
000073dfa87d6b0d  pop r8
000073dfa87d6b0f  pop rsi
000073dfa87d6b10  pop rdi
000073dfa87d6b11  pop rdx
000073dfa87d6b12  pop rcx
000073dfa87d6b13  pop rax
000073dfa87d6b14  add rsp, 0x08
000073dfa87d6b18  jmp 0x000073DFA87D3196
000073dfa87d6b1d  call 0x000073DFA860AFE0
000073dfa87d6b22  jmp 0x000073DFA87D31EB
000073dfa87d6b27  sub rsp, 0x08
000073dfa87d6b2b  push rax
000073dfa87d6b2c  push rcx
000073dfa87d6b2d  push rdx
000073dfa87d6b2e  push rdi
000073dfa87d6b2f  push rsi
000073dfa87d6b30  push r8
000073dfa87d6b32  push r9
000073dfa87d6b34  push r10
000073dfa87d6b36  push r11
000073dfa87d6b38  sub rsp, 0xF0
000073dfa87d6b3f  vmovaps [rsp], xmm0
000073dfa87d6b44  vmovaps [rsp+0x10], xmm1
000073dfa87d6b4a  vmovaps [rsp+0x20], xmm2
000073dfa87d6b50  vmovaps [rsp+0x30], xmm3
000073dfa87d6b56  vmovaps [rsp+0x40], xmm4
000073dfa87d6b5c  vmovaps [rsp+0x50], xmm5
000073dfa87d6b62  vmovaps [rsp+0x60], xmm6
000073dfa87d6b68  vmovaps [rsp+0x70], xmm7
000073dfa87d6b6e  vmovaps [rsp+0x80], xmm8
000073dfa87d6b77  vmovaps [rsp+0x90], xmm10
000073dfa87d6b80  vmovaps [rsp+0xA0], xmm11
000073dfa87d6b89  vmovaps [rsp+0xB0], xmm12
000073dfa87d6b92  vmovaps [rsp+0xC0], xmm13
000073dfa87d6b9b  vmovaps [rsp+0xD0], xmm14
000073dfa87d6ba4  vmovaps [rsp+0xE0], xmm15
000073dfa87d6bad  sub rsp, 0x30
000073dfa87d6bb1  movaps [rsp], xmm9
000073dfa87d6bb6  movaps [rsp+0x10], xmm8
000073dfa87d6bbc  movaps [rsp+0x20], xmm10
000073dfa87d6bc2  lea rdi, [rsp]
000073dfa87d6bc6  mov esi, 0x00
000073dfa87d6bcb  mov rax, 0x593AA1DA4530
000073dfa87d6bd5  call rax
000073dfa87d6bd7  movaps xmm9, [rsp]
000073dfa87d6bdc  add rsp, 0x30
000073dfa87d6be0  vmovaps xmm0, [rsp]
000073dfa87d6be5  vmovaps xmm1, [rsp+0x10]
000073dfa87d6beb  vmovaps xmm2, [rsp+0x20]
000073dfa87d6bf1  vmovaps xmm3, [rsp+0x30]
000073dfa87d6bf7  vmovaps xmm4, [rsp+0x40]
000073dfa87d6bfd  vmovaps xmm5, [rsp+0x50]
000073dfa87d6c03  vmovaps xmm6, [rsp+0x60]
000073dfa87d6c09  vmovaps xmm7, [rsp+0x70]
000073dfa87d6c0f  vmovaps xmm8, [rsp+0x80]
000073dfa87d6c18  vmovaps xmm10, [rsp+0x90]
000073dfa87d6c21  vmovaps xmm11, [rsp+0xA0]
000073dfa87d6c2a  vmovaps xmm12, [rsp+0xB0]
000073dfa87d6c33  vmovaps xmm13, [rsp+0xC0]
000073dfa87d6c3c  vmovaps xmm14, [rsp+0xD0]
000073dfa87d6c45  vmovaps xmm15, [rsp+0xE0]
000073dfa87d6c4e  add rsp, 0xF0
000073dfa87d6c55  pop r11
000073dfa87d6c57  pop r10
000073dfa87d6c59  pop r9
000073dfa87d6c5b  pop r8
000073dfa87d6c5d  pop rsi
000073dfa87d6c5e  pop rdi
000073dfa87d6c5f  pop rdx
000073dfa87d6c60  pop rcx
000073dfa87d6c61  pop rax
000073dfa87d6c62  add rsp, 0x08
000073dfa87d6c66  jmp 0x000073DFA87D321C
000073dfa87d6c6b  sub rsp, 0x08
000073dfa87d6c6f  push rax
000073dfa87d6c70  push rcx
000073dfa87d6c71  push rdx
000073dfa87d6c72  push rdi
000073dfa87d6c73  push rsi
000073dfa87d6c74  push r8
000073dfa87d6c76  push r9
000073dfa87d6c78  push r10
000073dfa87d6c7a  push r11
000073dfa87d6c7c  sub rsp, 0xF0
000073dfa87d6c83  vmovaps [rsp], xmm0
000073dfa87d6c88  vmovaps [rsp+0x10], xmm1
000073dfa87d6c8e  vmovaps [rsp+0x20], xmm2
000073dfa87d6c94  vmovaps [rsp+0x30], xmm3
000073dfa87d6c9a  vmovaps [rsp+0x40], xmm4
000073dfa87d6ca0  vmovaps [rsp+0x50], xmm5
000073dfa87d6ca6  vmovaps [rsp+0x60], xmm6
000073dfa87d6cac  vmovaps [rsp+0x70], xmm7
000073dfa87d6cb2  vmovaps [rsp+0x80], xmm8
000073dfa87d6cbb  vmovaps [rsp+0x90], xmm9
000073dfa87d6cc4  vmovaps [rsp+0xA0], xmm11
000073dfa87d6ccd  vmovaps [rsp+0xB0], xmm12
000073dfa87d6cd6  vmovaps [rsp+0xC0], xmm13
000073dfa87d6cdf  vmovaps [rsp+0xD0], xmm14
000073dfa87d6ce8  vmovaps [rsp+0xE0], xmm15
000073dfa87d6cf1  sub rsp, 0x30
000073dfa87d6cf5  movaps [rsp], xmm10
000073dfa87d6cfa  movaps [rsp+0x10], xmm1
000073dfa87d6cff  movaps [rsp+0x20], xmm11
000073dfa87d6d05  lea rdi, [rsp]
000073dfa87d6d09  mov esi, 0x00
000073dfa87d6d0e  mov rax, 0x593AA1DA4530
000073dfa87d6d18  call rax
000073dfa87d6d1a  movaps xmm10, [rsp]
000073dfa87d6d1f  add rsp, 0x30
000073dfa87d6d23  vmovaps xmm0, [rsp]
000073dfa87d6d28  vmovaps xmm1, [rsp+0x10]
000073dfa87d6d2e  vmovaps xmm2, [rsp+0x20]
000073dfa87d6d34  vmovaps xmm3, [rsp+0x30]
000073dfa87d6d3a  vmovaps xmm4, [rsp+0x40]
000073dfa87d6d40  vmovaps xmm5, [rsp+0x50]
000073dfa87d6d46  vmovaps xmm6, [rsp+0x60]
000073dfa87d6d4c  vmovaps xmm7, [rsp+0x70]
000073dfa87d6d52  vmovaps xmm8, [rsp+0x80]
000073dfa87d6d5b  vmovaps xmm9, [rsp+0x90]
000073dfa87d6d64  vmovaps xmm11, [rsp+0xA0]
000073dfa87d6d6d  vmovaps xmm12, [rsp+0xB0]
000073dfa87d6d76  vmovaps xmm13, [rsp+0xC0]
000073dfa87d6d7f  vmovaps xmm14, [rsp+0xD0]
000073dfa87d6d88  vmovaps xmm15, [rsp+0xE0]
000073dfa87d6d91  add rsp, 0xF0
000073dfa87d6d98  pop r11
000073dfa87d6d9a  pop r10
000073dfa87d6d9c  pop r9
000073dfa87d6d9e  pop r8
000073dfa87d6da0  pop rsi
000073dfa87d6da1  pop rdi
000073dfa87d6da2  pop rdx
000073dfa87d6da3  pop rcx
000073dfa87d6da4  pop rax
000073dfa87d6da5  add rsp, 0x08
000073dfa87d6da9  jmp 0x000073DFA87D3237
000073dfa87d6dae  sub rsp, 0x08
000073dfa87d6db2  push rax
000073dfa87d6db3  push rcx
000073dfa87d6db4  push rdx
000073dfa87d6db5  push rdi
000073dfa87d6db6  push rsi
000073dfa87d6db7  push r8
000073dfa87d6db9  push r9
000073dfa87d6dbb  push r10
000073dfa87d6dbd  push r11
000073dfa87d6dbf  sub rsp, 0xF0
000073dfa87d6dc6  vmovaps [rsp], xmm0
000073dfa87d6dcb  vmovaps [rsp+0x10], xmm2
000073dfa87d6dd1  vmovaps [rsp+0x20], xmm3
000073dfa87d6dd7  vmovaps [rsp+0x30], xmm4
000073dfa87d6ddd  vmovaps [rsp+0x40], xmm5
000073dfa87d6de3  vmovaps [rsp+0x50], xmm6
000073dfa87d6de9  vmovaps [rsp+0x60], xmm7
000073dfa87d6def  vmovaps [rsp+0x70], xmm8
000073dfa87d6df5  vmovaps [rsp+0x80], xmm9
000073dfa87d6dfe  vmovaps [rsp+0x90], xmm10
000073dfa87d6e07  vmovaps [rsp+0xA0], xmm11
000073dfa87d6e10  vmovaps [rsp+0xB0], xmm12
000073dfa87d6e19  vmovaps [rsp+0xC0], xmm13
000073dfa87d6e22  vmovaps [rsp+0xD0], xmm14
000073dfa87d6e2b  vmovaps [rsp+0xE0], xmm15
000073dfa87d6e34  sub rsp, 0x30
000073dfa87d6e38  movaps [rsp], xmm1
000073dfa87d6e3c  movaps [rsp+0x10], xmm15
000073dfa87d6e42  movaps [rsp+0x20], xmm6
000073dfa87d6e47  lea rdi, [rsp]
000073dfa87d6e4b  mov esi, 0x00
000073dfa87d6e50  mov rax, 0x593AA1DA4530
000073dfa87d6e5a  call rax
000073dfa87d6e5c  movaps xmm1, [rsp]
000073dfa87d6e60  add rsp, 0x30
000073dfa87d6e64  vmovaps xmm0, [rsp]
000073dfa87d6e69  vmovaps xmm2, [rsp+0x10]
000073dfa87d6e6f  vmovaps xmm3, [rsp+0x20]
000073dfa87d6e75  vmovaps xmm4, [rsp+0x30]
000073dfa87d6e7b  vmovaps xmm5, [rsp+0x40]
000073dfa87d6e81  vmovaps xmm6, [rsp+0x50]
000073dfa87d6e87  vmovaps xmm7, [rsp+0x60]
000073dfa87d6e8d  vmovaps xmm8, [rsp+0x70]
000073dfa87d6e93  vmovaps xmm9, [rsp+0x80]
000073dfa87d6e9c  vmovaps xmm10, [rsp+0x90]
000073dfa87d6ea5  vmovaps xmm11, [rsp+0xA0]
000073dfa87d6eae  vmovaps xmm12, [rsp+0xB0]
000073dfa87d6eb7  vmovaps xmm13, [rsp+0xC0]
000073dfa87d6ec0  vmovaps xmm14, [rsp+0xD0]
000073dfa87d6ec9  vmovaps xmm15, [rsp+0xE0]
000073dfa87d6ed2  add rsp, 0xF0
000073dfa87d6ed9  pop r11
000073dfa87d6edb  pop r10
000073dfa87d6edd  pop r9
000073dfa87d6edf  pop r8
000073dfa87d6ee1  pop rsi
000073dfa87d6ee2  pop rdi
000073dfa87d6ee3  pop rdx
000073dfa87d6ee4  pop rcx
000073dfa87d6ee5  pop rax
000073dfa87d6ee6  add rsp, 0x08
000073dfa87d6eea  jmp 0x000073DFA87D3250
000073dfa87d6eef  sub rsp, 0x08
000073dfa87d6ef3  push rax
000073dfa87d6ef4  push rcx
000073dfa87d6ef5  push rdx
000073dfa87d6ef6  push rdi
000073dfa87d6ef7  push rsi
000073dfa87d6ef8  push r8
000073dfa87d6efa  push r9
000073dfa87d6efc  push r10
000073dfa87d6efe  push r11
000073dfa87d6f00  sub rsp, 0xF0
000073dfa87d6f07  vmovaps [rsp], xmm0
000073dfa87d6f0c  vmovaps [rsp+0x10], xmm1
000073dfa87d6f12  vmovaps [rsp+0x20], xmm2
000073dfa87d6f18  vmovaps [rsp+0x30], xmm3
000073dfa87d6f1e  vmovaps [rsp+0x40], xmm4
000073dfa87d6f24  vmovaps [rsp+0x50], xmm5
000073dfa87d6f2a  vmovaps [rsp+0x60], xmm6
000073dfa87d6f30  vmovaps [rsp+0x70], xmm7
000073dfa87d6f36  vmovaps [rsp+0x80], xmm8
000073dfa87d6f3f  vmovaps [rsp+0x90], xmm9
000073dfa87d6f48  vmovaps [rsp+0xA0], xmm10
000073dfa87d6f51  vmovaps [rsp+0xB0], xmm12
000073dfa87d6f5a  vmovaps [rsp+0xC0], xmm13
000073dfa87d6f63  vmovaps [rsp+0xD0], xmm14
000073dfa87d6f6c  vmovaps [rsp+0xE0], xmm15
000073dfa87d6f75  sub rsp, 0x30
000073dfa87d6f79  movaps [rsp], xmm11
000073dfa87d6f7e  movaps [rsp+0x10], xmm12
000073dfa87d6f84  movaps [rsp+0x20], xmm15
000073dfa87d6f8a  lea rdi, [rsp]
000073dfa87d6f8e  mov esi, 0x00
000073dfa87d6f93  mov rax, 0x593AA1DA4530
000073dfa87d6f9d  call rax
000073dfa87d6f9f  movaps xmm11, [rsp]
000073dfa87d6fa4  add rsp, 0x30
000073dfa87d6fa8  vmovaps xmm0, [rsp]
000073dfa87d6fad  vmovaps xmm1, [rsp+0x10]
000073dfa87d6fb3  vmovaps xmm2, [rsp+0x20]
000073dfa87d6fb9  vmovaps xmm3, [rsp+0x30]
000073dfa87d6fbf  vmovaps xmm4, [rsp+0x40]
000073dfa87d6fc5  vmovaps xmm5, [rsp+0x50]
000073dfa87d6fcb  vmovaps xmm6, [rsp+0x60]
000073dfa87d6fd1  vmovaps xmm7, [rsp+0x70]
000073dfa87d6fd7  vmovaps xmm8, [rsp+0x80]
000073dfa87d6fe0  vmovaps xmm9, [rsp+0x90]
000073dfa87d6fe9  vmovaps xmm10, [rsp+0xA0]
000073dfa87d6ff2  vmovaps xmm12, [rsp+0xB0]
000073dfa87d6ffb  vmovaps xmm13, [rsp+0xC0]
000073dfa87d7004  vmovaps xmm14, [rsp+0xD0]
000073dfa87d700d  vmovaps xmm15, [rsp+0xE0]
000073dfa87d7016  add rsp, 0xF0
000073dfa87d701d  pop r11
000073dfa87d701f  pop r10
000073dfa87d7021  pop r9
000073dfa87d7023  pop r8
000073dfa87d7025  pop rsi
000073dfa87d7026  pop rdi
000073dfa87d7027  pop rdx
000073dfa87d7028  pop rcx
000073dfa87d7029  pop rax
000073dfa87d702a  add rsp, 0x08
000073dfa87d702e  jmp 0x000073DFA87D327A
000073dfa87d7033  sub rsp, 0x08
000073dfa87d7037  push rax
000073dfa87d7038  push rcx
000073dfa87d7039  push rdx
000073dfa87d703a  push rdi
000073dfa87d703b  push rsi
000073dfa87d703c  push r8
000073dfa87d703e  push r9
000073dfa87d7040  push r10
000073dfa87d7042  push r11
000073dfa87d7044  sub rsp, 0xF0
000073dfa87d704b  vmovaps [rsp], xmm0
000073dfa87d7050  vmovaps [rsp+0x10], xmm1
000073dfa87d7056  vmovaps [rsp+0x20], xmm2
000073dfa87d705c  vmovaps [rsp+0x30], xmm3
000073dfa87d7062  vmovaps [rsp+0x40], xmm4
000073dfa87d7068  vmovaps [rsp+0x50], xmm5
000073dfa87d706e  vmovaps [rsp+0x60], xmm6
000073dfa87d7074  vmovaps [rsp+0x70], xmm7
000073dfa87d707a  vmovaps [rsp+0x80], xmm8
000073dfa87d7083  vmovaps [rsp+0x90], xmm9
000073dfa87d708c  vmovaps [rsp+0xA0], xmm10
000073dfa87d7095  vmovaps [rsp+0xB0], xmm11
000073dfa87d709e  vmovaps [rsp+0xC0], xmm13
000073dfa87d70a7  vmovaps [rsp+0xD0], xmm14
000073dfa87d70b0  vmovaps [rsp+0xE0], xmm15
000073dfa87d70b9  sub rsp, 0x30
000073dfa87d70bd  movaps [rsp], xmm12
000073dfa87d70c2  movaps [rsp+0x10], xmm8
000073dfa87d70c8  movaps [rsp+0x20], xmm15
000073dfa87d70ce  lea rdi, [rsp]
000073dfa87d70d2  mov esi, 0x00
000073dfa87d70d7  mov rax, 0x593AA1DA4530
000073dfa87d70e1  call rax
000073dfa87d70e3  movaps xmm12, [rsp]
000073dfa87d70e8  add rsp, 0x30
000073dfa87d70ec  vmovaps xmm0, [rsp]
000073dfa87d70f1  vmovaps xmm1, [rsp+0x10]
000073dfa87d70f7  vmovaps xmm2, [rsp+0x20]
000073dfa87d70fd  vmovaps xmm3, [rsp+0x30]
000073dfa87d7103  vmovaps xmm4, [rsp+0x40]
000073dfa87d7109  vmovaps xmm5, [rsp+0x50]
000073dfa87d710f  vmovaps xmm6, [rsp+0x60]
000073dfa87d7115  vmovaps xmm7, [rsp+0x70]
000073dfa87d711b  vmovaps xmm8, [rsp+0x80]
000073dfa87d7124  vmovaps xmm9, [rsp+0x90]
000073dfa87d712d  vmovaps xmm10, [rsp+0xA0]
000073dfa87d7136  vmovaps xmm11, [rsp+0xB0]
000073dfa87d713f  vmovaps xmm13, [rsp+0xC0]
000073dfa87d7148  vmovaps xmm14, [rsp+0xD0]
000073dfa87d7151  vmovaps xmm15, [rsp+0xE0]
000073dfa87d715a  add rsp, 0xF0
000073dfa87d7161  pop r11
000073dfa87d7163  pop r10
000073dfa87d7165  pop r9
000073dfa87d7167  pop r8
000073dfa87d7169  pop rsi
000073dfa87d716a  pop rdi
000073dfa87d716b  pop rdx
000073dfa87d716c  pop rcx
000073dfa87d716d  pop rax
000073dfa87d716e  add rsp, 0x08
000073dfa87d7172  jmp 0x000073DFA87D32A9
000073dfa87d7177  sub rsp, 0x08
000073dfa87d717b  push rax
000073dfa87d717c  push rcx
000073dfa87d717d  push rdx
000073dfa87d717e  push rdi
000073dfa87d717f  push rsi
000073dfa87d7180  push r8
000073dfa87d7182  push r9
000073dfa87d7184  push r10
000073dfa87d7186  push r11
000073dfa87d7188  sub rsp, 0xF0
000073dfa87d718f  vmovaps [rsp], xmm0
000073dfa87d7194  vmovaps [rsp+0x10], xmm1
000073dfa87d719a  vmovaps [rsp+0x20], xmm2
000073dfa87d71a0  vmovaps [rsp+0x30], xmm3
000073dfa87d71a6  vmovaps [rsp+0x40], xmm4
000073dfa87d71ac  vmovaps [rsp+0x50], xmm5
000073dfa87d71b2  vmovaps [rsp+0x60], xmm6
000073dfa87d71b8  vmovaps [rsp+0x70], xmm7
000073dfa87d71be  vmovaps [rsp+0x80], xmm9
000073dfa87d71c7  vmovaps [rsp+0x90], xmm10
000073dfa87d71d0  vmovaps [rsp+0xA0], xmm11
000073dfa87d71d9  vmovaps [rsp+0xB0], xmm12
000073dfa87d71e2  vmovaps [rsp+0xC0], xmm13
000073dfa87d71eb  vmovaps [rsp+0xD0], xmm14
000073dfa87d71f4  vmovaps [rsp+0xE0], xmm15
000073dfa87d71fd  sub rsp, 0x30
000073dfa87d7201  movaps [rsp], xmm8
000073dfa87d7206  movaps [rsp+0x10], xmm7
000073dfa87d720b  movaps [rsp+0x20], xmm15
000073dfa87d7211  lea rdi, [rsp]
000073dfa87d7215  mov esi, 0x00
000073dfa87d721a  mov rax, 0x593AA1DA4530
000073dfa87d7224  call rax
000073dfa87d7226  movaps xmm8, [rsp]
000073dfa87d722b  add rsp, 0x30
000073dfa87d722f  vmovaps xmm0, [rsp]
000073dfa87d7234  vmovaps xmm1, [rsp+0x10]
000073dfa87d723a  vmovaps xmm2, [rsp+0x20]
000073dfa87d7240  vmovaps xmm3, [rsp+0x30]
000073dfa87d7246  vmovaps xmm4, [rsp+0x40]
000073dfa87d724c  vmovaps xmm5, [rsp+0x50]
000073dfa87d7252  vmovaps xmm6, [rsp+0x60]
000073dfa87d7258  vmovaps xmm7, [rsp+0x70]
000073dfa87d725e  vmovaps xmm9, [rsp+0x80]
000073dfa87d7267  vmovaps xmm10, [rsp+0x90]
000073dfa87d7270  vmovaps xmm11, [rsp+0xA0]
000073dfa87d7279  vmovaps xmm12, [rsp+0xB0]
000073dfa87d7282  vmovaps xmm13, [rsp+0xC0]
000073dfa87d728b  vmovaps xmm14, [rsp+0xD0]
000073dfa87d7294  vmovaps xmm15, [rsp+0xE0]
000073dfa87d729d  add rsp, 0xF0
000073dfa87d72a4  pop r11
000073dfa87d72a6  pop r10
000073dfa87d72a8  pop r9
000073dfa87d72aa  pop r8
000073dfa87d72ac  pop rsi
000073dfa87d72ad  pop rdi
000073dfa87d72ae  pop rdx
000073dfa87d72af  pop rcx
000073dfa87d72b0  pop rax
000073dfa87d72b1  add rsp, 0x08
000073dfa87d72b5  jmp 0x000073DFA87D32CF
000073dfa87d72ba  sub rsp, 0x08
000073dfa87d72be  push rax
000073dfa87d72bf  push rcx
000073dfa87d72c0  push rdx
000073dfa87d72c1  push rdi
000073dfa87d72c2  push rsi
000073dfa87d72c3  push r8
000073dfa87d72c5  push r9
000073dfa87d72c7  push r10
000073dfa87d72c9  push r11
000073dfa87d72cb  sub rsp, 0xF0
000073dfa87d72d2  vmovaps [rsp], xmm0
000073dfa87d72d7  vmovaps [rsp+0x10], xmm1
000073dfa87d72dd  vmovaps [rsp+0x20], xmm2
000073dfa87d72e3  vmovaps [rsp+0x30], xmm3
000073dfa87d72e9  vmovaps [rsp+0x40], xmm4
000073dfa87d72ef  vmovaps [rsp+0x50], xmm5
000073dfa87d72f5  vmovaps [rsp+0x60], xmm6
000073dfa87d72fb  vmovaps [rsp+0x70], xmm7
000073dfa87d7301  vmovaps [rsp+0x80], xmm8
000073dfa87d730a  vmovaps [rsp+0x90], xmm9
000073dfa87d7313  vmovaps [rsp+0xA0], xmm10
000073dfa87d731c  vmovaps [rsp+0xB0], xmm11
000073dfa87d7325  vmovaps [rsp+0xC0], xmm12
000073dfa87d732e  vmovaps [rsp+0xD0], xmm13
000073dfa87d7337  vmovaps [rsp+0xE0], xmm14
000073dfa87d7340  sub rsp, 0x30
000073dfa87d7344  movaps [rsp], xmm15
000073dfa87d7349  movaps [rsp+0x10], xmm14
000073dfa87d734f  movaps [rsp+0x20], xmm9
000073dfa87d7355  lea rdi, [rsp]
000073dfa87d7359  mov esi, 0x00
000073dfa87d735e  mov rax, 0x593AA1DA4530
000073dfa87d7368  call rax
000073dfa87d736a  movaps xmm15, [rsp]
000073dfa87d736f  add rsp, 0x30
000073dfa87d7373  vmovaps xmm0, [rsp]
000073dfa87d7378  vmovaps xmm1, [rsp+0x10]
000073dfa87d737e  vmovaps xmm2, [rsp+0x20]
000073dfa87d7384  vmovaps xmm3, [rsp+0x30]
000073dfa87d738a  vmovaps xmm4, [rsp+0x40]
000073dfa87d7390  vmovaps xmm5, [rsp+0x50]
000073dfa87d7396  vmovaps xmm6, [rsp+0x60]
000073dfa87d739c  vmovaps xmm7, [rsp+0x70]
000073dfa87d73a2  vmovaps xmm8, [rsp+0x80]
000073dfa87d73ab  vmovaps xmm9, [rsp+0x90]
000073dfa87d73b4  vmovaps xmm10, [rsp+0xA0]
000073dfa87d73bd  vmovaps xmm11, [rsp+0xB0]
000073dfa87d73c6  vmovaps xmm12, [rsp+0xC0]
000073dfa87d73cf  vmovaps xmm13, [rsp+0xD0]
000073dfa87d73d8  vmovaps xmm14, [rsp+0xE0]
000073dfa87d73e1  add rsp, 0xF0
000073dfa87d73e8  pop r11
000073dfa87d73ea  pop r10
000073dfa87d73ec  pop r9
000073dfa87d73ee  pop r8
000073dfa87d73f0  pop rsi
000073dfa87d73f1  pop rdi
000073dfa87d73f2  pop rdx
000073dfa87d73f3  pop rcx
000073dfa87d73f4  pop rax
000073dfa87d73f5  add rsp, 0x08
000073dfa87d73f9  jmp 0x000073DFA87D32E9
000073dfa87d73fe  sub rsp, 0x08
000073dfa87d7402  push rax
000073dfa87d7403  push rcx
000073dfa87d7404  push rdx
000073dfa87d7405  push rdi
000073dfa87d7406  push rsi
000073dfa87d7407  push r8
000073dfa87d7409  push r9
000073dfa87d740b  push r10
000073dfa87d740d  push r11
000073dfa87d740f  sub rsp, 0xF0
000073dfa87d7416  vmovaps [rsp], xmm0
000073dfa87d741b  vmovaps [rsp+0x10], xmm1
000073dfa87d7421  vmovaps [rsp+0x20], xmm2
000073dfa87d7427  vmovaps [rsp+0x30], xmm3
000073dfa87d742d  vmovaps [rsp+0x40], xmm4
000073dfa87d7433  vmovaps [rsp+0x50], xmm5
000073dfa87d7439  vmovaps [rsp+0x60], xmm6
000073dfa87d743f  vmovaps [rsp+0x70], xmm7
000073dfa87d7445  vmovaps [rsp+0x80], xmm8
000073dfa87d744e  vmovaps [rsp+0x90], xmm10
000073dfa87d7457  vmovaps [rsp+0xA0], xmm11
000073dfa87d7460  vmovaps [rsp+0xB0], xmm12
000073dfa87d7469  vmovaps [rsp+0xC0], xmm13
000073dfa87d7472  vmovaps [rsp+0xD0], xmm14
000073dfa87d747b  vmovaps [rsp+0xE0], xmm15
000073dfa87d7484  sub rsp, 0x30
000073dfa87d7488  movaps [rsp], xmm9
000073dfa87d748d  movaps [rsp+0x10], xmm7
000073dfa87d7492  movaps [rsp+0x20], xmm14
000073dfa87d7498  lea rdi, [rsp]
000073dfa87d749c  mov esi, 0x00
000073dfa87d74a1  mov rax, 0x593AA1DA4530
000073dfa87d74ab  call rax
000073dfa87d74ad  movaps xmm9, [rsp]
000073dfa87d74b2  add rsp, 0x30
000073dfa87d74b6  vmovaps xmm0, [rsp]
000073dfa87d74bb  vmovaps xmm1, [rsp+0x10]
000073dfa87d74c1  vmovaps xmm2, [rsp+0x20]
000073dfa87d74c7  vmovaps xmm3, [rsp+0x30]
000073dfa87d74cd  vmovaps xmm4, [rsp+0x40]
000073dfa87d74d3  vmovaps xmm5, [rsp+0x50]
000073dfa87d74d9  vmovaps xmm6, [rsp+0x60]
000073dfa87d74df  vmovaps xmm7, [rsp+0x70]
000073dfa87d74e5  vmovaps xmm8, [rsp+0x80]
000073dfa87d74ee  vmovaps xmm10, [rsp+0x90]
000073dfa87d74f7  vmovaps xmm11, [rsp+0xA0]
000073dfa87d7500  vmovaps xmm12, [rsp+0xB0]
000073dfa87d7509  vmovaps xmm13, [rsp+0xC0]
000073dfa87d7512  vmovaps xmm14, [rsp+0xD0]
000073dfa87d751b  vmovaps xmm15, [rsp+0xE0]
000073dfa87d7524  add rsp, 0xF0
000073dfa87d752b  pop r11
000073dfa87d752d  pop r10
000073dfa87d752f  pop r9
000073dfa87d7531  pop r8
000073dfa87d7533  pop rsi
000073dfa87d7534  pop rdi
000073dfa87d7535  pop rdx
000073dfa87d7536  pop rcx
000073dfa87d7537  pop rax
000073dfa87d7538  add rsp, 0x08
000073dfa87d753c  jmp 0x000073DFA87D3318
000073dfa87d7541  sub rsp, 0x08
000073dfa87d7545  push rax
000073dfa87d7546  push rcx
000073dfa87d7547  push rdx
000073dfa87d7548  push rdi
000073dfa87d7549  push rsi
000073dfa87d754a  push r8
000073dfa87d754c  push r9
000073dfa87d754e  push r10
000073dfa87d7550  push r11
000073dfa87d7552  sub rsp, 0xF0
000073dfa87d7559  vmovaps [rsp], xmm0
000073dfa87d755e  vmovaps [rsp+0x10], xmm1
000073dfa87d7564  vmovaps [rsp+0x20], xmm2
000073dfa87d756a  vmovaps [rsp+0x30], xmm3
000073dfa87d7570  vmovaps [rsp+0x40], xmm4
000073dfa87d7576  vmovaps [rsp+0x50], xmm5
000073dfa87d757c  vmovaps [rsp+0x60], xmm6
000073dfa87d7582  vmovaps [rsp+0x70], xmm7
000073dfa87d7588  vmovaps [rsp+0x80], xmm8
000073dfa87d7591  vmovaps [rsp+0x90], xmm9
000073dfa87d759a  vmovaps [rsp+0xA0], xmm10
000073dfa87d75a3  vmovaps [rsp+0xB0], xmm11
000073dfa87d75ac  vmovaps [rsp+0xC0], xmm12
000073dfa87d75b5  vmovaps [rsp+0xD0], xmm13
000073dfa87d75be  vmovaps [rsp+0xE0], xmm15
000073dfa87d75c7  sub rsp, 0x30
000073dfa87d75cb  movaps [rsp], xmm14
000073dfa87d75d0  movaps [rsp+0x10], xmm13
000073dfa87d75d6  movaps [rsp+0x20], xmm11
000073dfa87d75dc  lea rdi, [rsp]
000073dfa87d75e0  mov esi, 0x00
000073dfa87d75e5  mov rax, 0x593AA1DA4530
000073dfa87d75ef  call rax
000073dfa87d75f1  movaps xmm14, [rsp]
000073dfa87d75f6  add rsp, 0x30
000073dfa87d75fa  vmovaps xmm0, [rsp]
000073dfa87d75ff  vmovaps xmm1, [rsp+0x10]
000073dfa87d7605  vmovaps xmm2, [rsp+0x20]
000073dfa87d760b  vmovaps xmm3, [rsp+0x30]
000073dfa87d7611  vmovaps xmm4, [rsp+0x40]
000073dfa87d7617  vmovaps xmm5, [rsp+0x50]
000073dfa87d761d  vmovaps xmm6, [rsp+0x60]
000073dfa87d7623  vmovaps xmm7, [rsp+0x70]
000073dfa87d7629  vmovaps xmm8, [rsp+0x80]
000073dfa87d7632  vmovaps xmm9, [rsp+0x90]
000073dfa87d763b  vmovaps xmm10, [rsp+0xA0]
000073dfa87d7644  vmovaps xmm11, [rsp+0xB0]
000073dfa87d764d  vmovaps xmm12, [rsp+0xC0]
000073dfa87d7656  vmovaps xmm13, [rsp+0xD0]
000073dfa87d765f  vmovaps xmm15, [rsp+0xE0]
000073dfa87d7668  add rsp, 0xF0
000073dfa87d766f  pop r11
000073dfa87d7671  pop r10
000073dfa87d7673  pop r9
000073dfa87d7675  pop r8
000073dfa87d7677  pop rsi
000073dfa87d7678  pop rdi
000073dfa87d7679  pop rdx
000073dfa87d767a  pop rcx
000073dfa87d767b  pop rax
000073dfa87d767c  add rsp, 0x08
000073dfa87d7680  jmp 0x000073DFA87D3332
000073dfa87d7685  sub rsp, 0x08
000073dfa87d7689  push rax
000073dfa87d768a  push rcx
000073dfa87d768b  push rdx
000073dfa87d768c  push rdi
000073dfa87d768d  push rsi
000073dfa87d768e  push r8
000073dfa87d7690  push r9
000073dfa87d7692  push r10
000073dfa87d7694  push r11
000073dfa87d7696  sub rsp, 0xF0
000073dfa87d769d  vmovaps [rsp], xmm0
000073dfa87d76a2  vmovaps [rsp+0x10], xmm1
000073dfa87d76a8  vmovaps [rsp+0x20], xmm2
000073dfa87d76ae  vmovaps [rsp+0x30], xmm3
000073dfa87d76b4  vmovaps [rsp+0x40], xmm4
000073dfa87d76ba  vmovaps [rsp+0x50], xmm5
000073dfa87d76c0  vmovaps [rsp+0x60], xmm6
000073dfa87d76c6  vmovaps [rsp+0x70], xmm7
000073dfa87d76cc  vmovaps [rsp+0x80], xmm8
000073dfa87d76d5  vmovaps [rsp+0x90], xmm9
000073dfa87d76de  vmovaps [rsp+0xA0], xmm10
000073dfa87d76e7  vmovaps [rsp+0xB0], xmm12
000073dfa87d76f0  vmovaps [rsp+0xC0], xmm13
000073dfa87d76f9  vmovaps [rsp+0xD0], xmm14
000073dfa87d7702  vmovaps [rsp+0xE0], xmm15
000073dfa87d770b  sub rsp, 0x30
000073dfa87d770f  movaps [rsp], xmm11
000073dfa87d7714  movaps [rsp+0x10], xmm7
000073dfa87d7719  movaps [rsp+0x20], xmm13
000073dfa87d771f  lea rdi, [rsp]
000073dfa87d7723  mov esi, 0x00
000073dfa87d7728  mov rax, 0x593AA1DA4530
000073dfa87d7732  call rax
000073dfa87d7734  movaps xmm11, [rsp]
000073dfa87d7739  add rsp, 0x30
000073dfa87d773d  vmovaps xmm0, [rsp]
000073dfa87d7742  vmovaps xmm1, [rsp+0x10]
000073dfa87d7748  vmovaps xmm2, [rsp+0x20]
000073dfa87d774e  vmovaps xmm3, [rsp+0x30]
000073dfa87d7754  vmovaps xmm4, [rsp+0x40]
000073dfa87d775a  vmovaps xmm5, [rsp+0x50]
000073dfa87d7760  vmovaps xmm6, [rsp+0x60]
000073dfa87d7766  vmovaps xmm7, [rsp+0x70]
000073dfa87d776c  vmovaps xmm8, [rsp+0x80]
000073dfa87d7775  vmovaps xmm9, [rsp+0x90]
000073dfa87d777e  vmovaps xmm10, [rsp+0xA0]
000073dfa87d7787  vmovaps xmm12, [rsp+0xB0]
000073dfa87d7790  vmovaps xmm13, [rsp+0xC0]
000073dfa87d7799  vmovaps xmm14, [rsp+0xD0]
000073dfa87d77a2  vmovaps xmm15, [rsp+0xE0]
000073dfa87d77ab  add rsp, 0xF0
000073dfa87d77b2  pop r11
000073dfa87d77b4  pop r10
000073dfa87d77b6  pop r9
000073dfa87d77b8  pop r8
000073dfa87d77ba  pop rsi
000073dfa87d77bb  pop rdi
000073dfa87d77bc  pop rdx
000073dfa87d77bd  pop rcx
000073dfa87d77be  pop rax
000073dfa87d77bf  add rsp, 0x08
000073dfa87d77c3  jmp 0x000073DFA87D335E
000073dfa87d77c8  sub rsp, 0x08
000073dfa87d77cc  push rax
000073dfa87d77cd  push rcx
000073dfa87d77ce  push rdx
000073dfa87d77cf  push rdi
000073dfa87d77d0  push rsi
000073dfa87d77d1  push r8
000073dfa87d77d3  push r9
000073dfa87d77d5  push r10
000073dfa87d77d7  push r11
000073dfa87d77d9  sub rsp, 0xF0
000073dfa87d77e0  vmovaps [rsp], xmm0
000073dfa87d77e5  vmovaps [rsp+0x10], xmm1
000073dfa87d77eb  vmovaps [rsp+0x20], xmm2
000073dfa87d77f1  vmovaps [rsp+0x30], xmm3
000073dfa87d77f7  vmovaps [rsp+0x40], xmm4
000073dfa87d77fd  vmovaps [rsp+0x50], xmm5
000073dfa87d7803  vmovaps [rsp+0x60], xmm6
000073dfa87d7809  vmovaps [rsp+0x70], xmm7
000073dfa87d780f  vmovaps [rsp+0x80], xmm8
000073dfa87d7818  vmovaps [rsp+0x90], xmm9
000073dfa87d7821  vmovaps [rsp+0xA0], xmm10
000073dfa87d782a  vmovaps [rsp+0xB0], xmm11
000073dfa87d7833  vmovaps [rsp+0xC0], xmm12
000073dfa87d783c  vmovaps [rsp+0xD0], xmm14
000073dfa87d7845  vmovaps [rsp+0xE0], xmm15
000073dfa87d784e  sub rsp, 0x30
000073dfa87d7852  movaps [rsp], xmm13
000073dfa87d7857  movaps [rsp+0x10], xmm10
000073dfa87d785d  movaps [rsp+0x20], xmm12
000073dfa87d7863  lea rdi, [rsp]
000073dfa87d7867  mov esi, 0x00
000073dfa87d786c  mov rax, 0x593AA1DA4530
000073dfa87d7876  call rax
000073dfa87d7878  movaps xmm13, [rsp]
000073dfa87d787d  add rsp, 0x30
000073dfa87d7881  vmovaps xmm0, [rsp]
000073dfa87d7886  vmovaps xmm1, [rsp+0x10]
000073dfa87d788c  vmovaps xmm2, [rsp+0x20]
000073dfa87d7892  vmovaps xmm3, [rsp+0x30]
000073dfa87d7898  vmovaps xmm4, [rsp+0x40]
000073dfa87d789e  vmovaps xmm5, [rsp+0x50]
000073dfa87d78a4  vmovaps xmm6, [rsp+0x60]
000073dfa87d78aa  vmovaps xmm7, [rsp+0x70]
000073dfa87d78b0  vmovaps xmm8, [rsp+0x80]
000073dfa87d78b9  vmovaps xmm9, [rsp+0x90]
000073dfa87d78c2  vmovaps xmm10, [rsp+0xA0]
000073dfa87d78cb  vmovaps xmm11, [rsp+0xB0]
000073dfa87d78d4  vmovaps xmm12, [rsp+0xC0]
000073dfa87d78dd  vmovaps xmm14, [rsp+0xD0]
000073dfa87d78e6  vmovaps xmm15, [rsp+0xE0]
000073dfa87d78ef  add rsp, 0xF0
000073dfa87d78f6  pop r11
000073dfa87d78f8  pop r10
000073dfa87d78fa  pop r9
000073dfa87d78fc  pop r8
000073dfa87d78fe  pop rsi
000073dfa87d78ff  pop rdi
000073dfa87d7900  pop rdx
000073dfa87d7901  pop rcx
000073dfa87d7902  pop rax
000073dfa87d7903  add rsp, 0x08
000073dfa87d7907  jmp 0x000073DFA87D3378
000073dfa87d790c  sub rsp, 0x08
000073dfa87d7910  push rax
000073dfa87d7911  push rcx
000073dfa87d7912  push rdx
000073dfa87d7913  push rdi
000073dfa87d7914  push rsi
000073dfa87d7915  push r8
000073dfa87d7917  push r9
000073dfa87d7919  push r10
000073dfa87d791b  push r11
000073dfa87d791d  sub rsp, 0xF0
000073dfa87d7924  vmovaps [rsp], xmm0
000073dfa87d7929  vmovaps [rsp+0x10], xmm1
000073dfa87d792f  vmovaps [rsp+0x20], xmm2
000073dfa87d7935  vmovaps [rsp+0x30], xmm3
000073dfa87d793b  vmovaps [rsp+0x40], xmm4
000073dfa87d7941  vmovaps [rsp+0x50], xmm5
000073dfa87d7947  vmovaps [rsp+0x60], xmm6
000073dfa87d794d  vmovaps [rsp+0x70], xmm7
000073dfa87d7953  vmovaps [rsp+0x80], xmm8
000073dfa87d795c  vmovaps [rsp+0x90], xmm9
000073dfa87d7965  vmovaps [rsp+0xA0], xmm11
000073dfa87d796e  vmovaps [rsp+0xB0], xmm12
000073dfa87d7977  vmovaps [rsp+0xC0], xmm13
000073dfa87d7980  vmovaps [rsp+0xD0], xmm14
000073dfa87d7989  vmovaps [rsp+0xE0], xmm15
000073dfa87d7992  sub rsp, 0x30
000073dfa87d7996  movaps [rsp], xmm10
000073dfa87d799b  movaps [rsp+0x10], xmm7
000073dfa87d79a0  movaps [rsp+0x20], xmm12
000073dfa87d79a6  lea rdi, [rsp]
000073dfa87d79aa  mov esi, 0x00
000073dfa87d79af  mov rax, 0x593AA1DA4530
000073dfa87d79b9  call rax
000073dfa87d79bb  movaps xmm10, [rsp]
000073dfa87d79c0  add rsp, 0x30
000073dfa87d79c4  vmovaps xmm0, [rsp]
000073dfa87d79c9  vmovaps xmm1, [rsp+0x10]
000073dfa87d79cf  vmovaps xmm2, [rsp+0x20]
000073dfa87d79d5  vmovaps xmm3, [rsp+0x30]
000073dfa87d79db  vmovaps xmm4, [rsp+0x40]
000073dfa87d79e1  vmovaps xmm5, [rsp+0x50]
000073dfa87d79e7  vmovaps xmm6, [rsp+0x60]
000073dfa87d79ed  vmovaps xmm7, [rsp+0x70]
000073dfa87d79f3  vmovaps xmm8, [rsp+0x80]
000073dfa87d79fc  vmovaps xmm9, [rsp+0x90]
000073dfa87d7a05  vmovaps xmm11, [rsp+0xA0]
000073dfa87d7a0e  vmovaps xmm12, [rsp+0xB0]
000073dfa87d7a17  vmovaps xmm13, [rsp+0xC0]
000073dfa87d7a20  vmovaps xmm14, [rsp+0xD0]
000073dfa87d7a29  vmovaps xmm15, [rsp+0xE0]
000073dfa87d7a32  add rsp, 0xF0
000073dfa87d7a39  pop r11
000073dfa87d7a3b  pop r10
000073dfa87d7a3d  pop r9
000073dfa87d7a3f  pop r8
000073dfa87d7a41  pop rsi
000073dfa87d7a42  pop rdi
000073dfa87d7a43  pop rdx
000073dfa87d7a44  pop rcx
000073dfa87d7a45  pop rax
000073dfa87d7a46  add rsp, 0x08
000073dfa87d7a4a  jmp 0x000073DFA87D33A4
000073dfa87d7a4f  sub rsp, 0x08
000073dfa87d7a53  push rax
000073dfa87d7a54  push rcx
000073dfa87d7a55  push rdx
000073dfa87d7a56  push rdi
000073dfa87d7a57  push rsi
000073dfa87d7a58  push r8
000073dfa87d7a5a  push r9
000073dfa87d7a5c  push r10
000073dfa87d7a5e  push r11
000073dfa87d7a60  sub rsp, 0xF0
000073dfa87d7a67  vmovaps [rsp], xmm0
000073dfa87d7a6c  vmovaps [rsp+0x10], xmm1
000073dfa87d7a72  vmovaps [rsp+0x20], xmm2
000073dfa87d7a78  vmovaps [rsp+0x30], xmm3
000073dfa87d7a7e  vmovaps [rsp+0x40], xmm4
000073dfa87d7a84  vmovaps [rsp+0x50], xmm5
000073dfa87d7a8a  vmovaps [rsp+0x60], xmm6
000073dfa87d7a90  vmovaps [rsp+0x70], xmm7
000073dfa87d7a96  vmovaps [rsp+0x80], xmm8
000073dfa87d7a9f  vmovaps [rsp+0x90], xmm9
000073dfa87d7aa8  vmovaps [rsp+0xA0], xmm10
000073dfa87d7ab1  vmovaps [rsp+0xB0], xmm11
000073dfa87d7aba  vmovaps [rsp+0xC0], xmm13
000073dfa87d7ac3  vmovaps [rsp+0xD0], xmm14
000073dfa87d7acc  vmovaps [rsp+0xE0], xmm15
000073dfa87d7ad5  sub rsp, 0x30
000073dfa87d7ad9  movaps [rsp], xmm12
000073dfa87d7ade  movaps [rsp+0x10], xmm1
000073dfa87d7ae3  movaps [rsp+0x20], xmm8
000073dfa87d7ae9  lea rdi, [rsp]
000073dfa87d7aed  mov esi, 0x00
000073dfa87d7af2  mov rax, 0x593AA1DA4530
000073dfa87d7afc  call rax
000073dfa87d7afe  movaps xmm12, [rsp]
000073dfa87d7b03  add rsp, 0x30
000073dfa87d7b07  vmovaps xmm0, [rsp]
000073dfa87d7b0c  vmovaps xmm1, [rsp+0x10]
000073dfa87d7b12  vmovaps xmm2, [rsp+0x20]
000073dfa87d7b18  vmovaps xmm3, [rsp+0x30]
000073dfa87d7b1e  vmovaps xmm4, [rsp+0x40]
000073dfa87d7b24  vmovaps xmm5, [rsp+0x50]
000073dfa87d7b2a  vmovaps xmm6, [rsp+0x60]
000073dfa87d7b30  vmovaps xmm7, [rsp+0x70]
000073dfa87d7b36  vmovaps xmm8, [rsp+0x80]
000073dfa87d7b3f  vmovaps xmm9, [rsp+0x90]
000073dfa87d7b48  vmovaps xmm10, [rsp+0xA0]
000073dfa87d7b51  vmovaps xmm11, [rsp+0xB0]
000073dfa87d7b5a  vmovaps xmm13, [rsp+0xC0]
000073dfa87d7b63  vmovaps xmm14, [rsp+0xD0]
000073dfa87d7b6c  vmovaps xmm15, [rsp+0xE0]
000073dfa87d7b75  add rsp, 0xF0
000073dfa87d7b7c  pop r11
000073dfa87d7b7e  pop r10
000073dfa87d7b80  pop r9
000073dfa87d7b82  pop r8
000073dfa87d7b84  pop rsi
000073dfa87d7b85  pop rdi
000073dfa87d7b86  pop rdx
000073dfa87d7b87  pop rcx
000073dfa87d7b88  pop rax
000073dfa87d7b89  add rsp, 0x08
000073dfa87d7b8d  jmp 0x000073DFA87D33BE
000073dfa87d7b92  call 0x000073DFA85FF430
000073dfa87d7b97  jmp 0x000073DFA87D33C8
000073dfa87d7b9c  sub rsp, 0x08
000073dfa87d7ba0  push rax
000073dfa87d7ba1  push rcx
000073dfa87d7ba2  push rdx
000073dfa87d7ba3  push rdi
000073dfa87d7ba4  push rsi
000073dfa87d7ba5  push r8
000073dfa87d7ba7  push r9
000073dfa87d7ba9  push r10
000073dfa87d7bab  push r11
000073dfa87d7bad  sub rsp, 0xF0
000073dfa87d7bb4  vmovaps [rsp], xmm0
000073dfa87d7bb9  vmovaps [rsp+0x10], xmm1
000073dfa87d7bbf  vmovaps [rsp+0x20], xmm2
000073dfa87d7bc5  vmovaps [rsp+0x30], xmm3
000073dfa87d7bcb  vmovaps [rsp+0x40], xmm4
000073dfa87d7bd1  vmovaps [rsp+0x50], xmm5
000073dfa87d7bd7  vmovaps [rsp+0x60], xmm6
000073dfa87d7bdd  vmovaps [rsp+0x70], xmm7
000073dfa87d7be3  vmovaps [rsp+0x80], xmm9
000073dfa87d7bec  vmovaps [rsp+0x90], xmm10
000073dfa87d7bf5  vmovaps [rsp+0xA0], xmm11
000073dfa87d7bfe  vmovaps [rsp+0xB0], xmm12
000073dfa87d7c07  vmovaps [rsp+0xC0], xmm13
000073dfa87d7c10  vmovaps [rsp+0xD0], xmm14
000073dfa87d7c19  vmovaps [rsp+0xE0], xmm15
000073dfa87d7c22  sub rsp, 0x30
000073dfa87d7c26  movaps [rsp], xmm8
000073dfa87d7c2b  movaps [rsp+0x10], xmm15
000073dfa87d7c31  movaps [rsp+0x20], xmm9
000073dfa87d7c37  lea rdi, [rsp]
000073dfa87d7c3b  mov esi, 0x00
000073dfa87d7c40  mov rax, 0x593AA1DA4530
000073dfa87d7c4a  call rax
000073dfa87d7c4c  movaps xmm8, [rsp]
000073dfa87d7c51  add rsp, 0x30
000073dfa87d7c55  vmovaps xmm0, [rsp]
000073dfa87d7c5a  vmovaps xmm1, [rsp+0x10]
000073dfa87d7c60  vmovaps xmm2, [rsp+0x20]
000073dfa87d7c66  vmovaps xmm3, [rsp+0x30]
000073dfa87d7c6c  vmovaps xmm4, [rsp+0x40]
000073dfa87d7c72  vmovaps xmm5, [rsp+0x50]
000073dfa87d7c78  vmovaps xmm6, [rsp+0x60]
000073dfa87d7c7e  vmovaps xmm7, [rsp+0x70]
000073dfa87d7c84  vmovaps xmm9, [rsp+0x80]
000073dfa87d7c8d  vmovaps xmm10, [rsp+0x90]
000073dfa87d7c96  vmovaps xmm11, [rsp+0xA0]
000073dfa87d7c9f  vmovaps xmm12, [rsp+0xB0]
000073dfa87d7ca8  vmovaps xmm13, [rsp+0xC0]
000073dfa87d7cb1  vmovaps xmm14, [rsp+0xD0]
000073dfa87d7cba  vmovaps xmm15, [rsp+0xE0]
000073dfa87d7cc3  add rsp, 0xF0
000073dfa87d7cca  pop r11
000073dfa87d7ccc  pop r10
000073dfa87d7cce  pop r9
000073dfa87d7cd0  pop r8
000073dfa87d7cd2  pop rsi
000073dfa87d7cd3  pop rdi
000073dfa87d7cd4  pop rdx
000073dfa87d7cd5  pop rcx
000073dfa87d7cd6  pop rax
000073dfa87d7cd7  add rsp, 0x08
000073dfa87d7cdb  jmp 0x000073DFA87D33EA
000073dfa87d7ce0  sub rsp, 0x08
000073dfa87d7ce4  push rax
000073dfa87d7ce5  push rcx
000073dfa87d7ce6  push rdx
000073dfa87d7ce7  push rdi
000073dfa87d7ce8  push rsi
000073dfa87d7ce9  push r8
000073dfa87d7ceb  push r9
000073dfa87d7ced  push r10
000073dfa87d7cef  push r11
000073dfa87d7cf1  sub rsp, 0xF0
000073dfa87d7cf8  vmovaps [rsp], xmm0
000073dfa87d7cfd  vmovaps [rsp+0x10], xmm1
000073dfa87d7d03  vmovaps [rsp+0x20], xmm2
000073dfa87d7d09  vmovaps [rsp+0x30], xmm3
000073dfa87d7d0f  vmovaps [rsp+0x40], xmm4
000073dfa87d7d15  vmovaps [rsp+0x50], xmm5
000073dfa87d7d1b  vmovaps [rsp+0x60], xmm6
000073dfa87d7d21  vmovaps [rsp+0x70], xmm7
000073dfa87d7d27  vmovaps [rsp+0x80], xmm8
000073dfa87d7d30  vmovaps [rsp+0x90], xmm10
000073dfa87d7d39  vmovaps [rsp+0xA0], xmm11
000073dfa87d7d42  vmovaps [rsp+0xB0], xmm12
000073dfa87d7d4b  vmovaps [rsp+0xC0], xmm13
000073dfa87d7d54  vmovaps [rsp+0xD0], xmm14
000073dfa87d7d5d  vmovaps [rsp+0xE0], xmm15
000073dfa87d7d66  sub rsp, 0x30
000073dfa87d7d6a  movaps [rsp], xmm9
000073dfa87d7d6f  movaps [rsp+0x10], xmm1
000073dfa87d7d74  movaps [rsp+0x20], xmm15
000073dfa87d7d7a  lea rdi, [rsp]
000073dfa87d7d7e  mov esi, 0x00
000073dfa87d7d83  mov rax, 0x593AA1DA4530
000073dfa87d7d8d  call rax
000073dfa87d7d8f  movaps xmm9, [rsp]
000073dfa87d7d94  add rsp, 0x30
000073dfa87d7d98  vmovaps xmm0, [rsp]
000073dfa87d7d9d  vmovaps xmm1, [rsp+0x10]
000073dfa87d7da3  vmovaps xmm2, [rsp+0x20]
000073dfa87d7da9  vmovaps xmm3, [rsp+0x30]
000073dfa87d7daf  vmovaps xmm4, [rsp+0x40]
000073dfa87d7db5  vmovaps xmm5, [rsp+0x50]
000073dfa87d7dbb  vmovaps xmm6, [rsp+0x60]
000073dfa87d7dc1  vmovaps xmm7, [rsp+0x70]
000073dfa87d7dc7  vmovaps xmm8, [rsp+0x80]
000073dfa87d7dd0  vmovaps xmm10, [rsp+0x90]
000073dfa87d7dd9  vmovaps xmm11, [rsp+0xA0]
000073dfa87d7de2  vmovaps xmm12, [rsp+0xB0]
000073dfa87d7deb  vmovaps xmm13, [rsp+0xC0]
000073dfa87d7df4  vmovaps xmm14, [rsp+0xD0]
000073dfa87d7dfd  vmovaps xmm15, [rsp+0xE0]
000073dfa87d7e06  add rsp, 0xF0
000073dfa87d7e0d  pop r11
000073dfa87d7e0f  pop r10
000073dfa87d7e11  pop r9
000073dfa87d7e13  pop r8
000073dfa87d7e15  pop rsi
000073dfa87d7e16  pop rdi
000073dfa87d7e17  pop rdx
000073dfa87d7e18  pop rcx
000073dfa87d7e19  pop rax
000073dfa87d7e1a  add rsp, 0x08
000073dfa87d7e1e  jmp 0x000073DFA87D3418
000073dfa87d7e23  sub rsp, 0x08
000073dfa87d7e27  push rax
000073dfa87d7e28  push rcx
000073dfa87d7e29  push rdx
000073dfa87d7e2a  push rdi
000073dfa87d7e2b  push rsi
000073dfa87d7e2c  push r8
000073dfa87d7e2e  push r9
000073dfa87d7e30  push r10
000073dfa87d7e32  push r11
000073dfa87d7e34  sub rsp, 0xF0
000073dfa87d7e3b  vmovaps [rsp], xmm0
000073dfa87d7e40  vmovaps [rsp+0x10], xmm1
000073dfa87d7e46  vmovaps [rsp+0x20], xmm2
000073dfa87d7e4c  vmovaps [rsp+0x30], xmm3
000073dfa87d7e52  vmovaps [rsp+0x40], xmm4
000073dfa87d7e58  vmovaps [rsp+0x50], xmm5
000073dfa87d7e5e  vmovaps [rsp+0x60], xmm6
000073dfa87d7e64  vmovaps [rsp+0x70], xmm7
000073dfa87d7e6a  vmovaps [rsp+0x80], xmm8
000073dfa87d7e73  vmovaps [rsp+0x90], xmm9
000073dfa87d7e7c  vmovaps [rsp+0xA0], xmm10
000073dfa87d7e85  vmovaps [rsp+0xB0], xmm11
000073dfa87d7e8e  vmovaps [rsp+0xC0], xmm12
000073dfa87d7e97  vmovaps [rsp+0xD0], xmm13
000073dfa87d7ea0  vmovaps [rsp+0xE0], xmm14
000073dfa87d7ea9  sub rsp, 0x30
000073dfa87d7ead  movaps [rsp], xmm15
000073dfa87d7eb2  movaps [rsp+0x10], xmm4
000073dfa87d7eb7  movaps [rsp+0x20], xmm1
000073dfa87d7ebc  lea rdi, [rsp]
000073dfa87d7ec0  mov esi, 0x00
000073dfa87d7ec5  mov rax, 0x593AA1DA4530
000073dfa87d7ecf  call rax
000073dfa87d7ed1  movaps xmm15, [rsp]
000073dfa87d7ed6  add rsp, 0x30
000073dfa87d7eda  vmovaps xmm0, [rsp]
000073dfa87d7edf  vmovaps xmm1, [rsp+0x10]
000073dfa87d7ee5  vmovaps xmm2, [rsp+0x20]
000073dfa87d7eeb  vmovaps xmm3, [rsp+0x30]
000073dfa87d7ef1  vmovaps xmm4, [rsp+0x40]
000073dfa87d7ef7  vmovaps xmm5, [rsp+0x50]
000073dfa87d7efd  vmovaps xmm6, [rsp+0x60]
000073dfa87d7f03  vmovaps xmm7, [rsp+0x70]
000073dfa87d7f09  vmovaps xmm8, [rsp+0x80]
000073dfa87d7f12  vmovaps xmm9, [rsp+0x90]
000073dfa87d7f1b  vmovaps xmm10, [rsp+0xA0]
000073dfa87d7f24  vmovaps xmm11, [rsp+0xB0]
000073dfa87d7f2d  vmovaps xmm12, [rsp+0xC0]
000073dfa87d7f36  vmovaps xmm13, [rsp+0xD0]
000073dfa87d7f3f  vmovaps xmm14, [rsp+0xE0]
000073dfa87d7f48  add rsp, 0xF0
000073dfa87d7f4f  pop r11
000073dfa87d7f51  pop r10
000073dfa87d7f53  pop r9
000073dfa87d7f55  pop r8
000073dfa87d7f57  pop rsi
000073dfa87d7f58  pop rdi
000073dfa87d7f59  pop rdx
000073dfa87d7f5a  pop rcx
000073dfa87d7f5b  pop rax
000073dfa87d7f5c  add rsp, 0x08
000073dfa87d7f60  jmp 0x000073DFA87D343E
000073dfa87d7f65  sub rsp, 0x08
000073dfa87d7f69  push rax
000073dfa87d7f6a  push rcx
000073dfa87d7f6b  push rdx
000073dfa87d7f6c  push rdi
000073dfa87d7f6d  push rsi
000073dfa87d7f6e  push r8
000073dfa87d7f70  push r9
000073dfa87d7f72  push r10
000073dfa87d7f74  push r11
000073dfa87d7f76  sub rsp, 0xF0
000073dfa87d7f7d  vmovaps [rsp], xmm0
000073dfa87d7f82  vmovaps [rsp+0x10], xmm2
000073dfa87d7f88  vmovaps [rsp+0x20], xmm3
000073dfa87d7f8e  vmovaps [rsp+0x30], xmm4
000073dfa87d7f94  vmovaps [rsp+0x40], xmm5
000073dfa87d7f9a  vmovaps [rsp+0x50], xmm6
000073dfa87d7fa0  vmovaps [rsp+0x60], xmm7
000073dfa87d7fa6  vmovaps [rsp+0x70], xmm8
000073dfa87d7fac  vmovaps [rsp+0x80], xmm9
000073dfa87d7fb5  vmovaps [rsp+0x90], xmm10
000073dfa87d7fbe  vmovaps [rsp+0xA0], xmm11
000073dfa87d7fc7  vmovaps [rsp+0xB0], xmm12
000073dfa87d7fd0  vmovaps [rsp+0xC0], xmm13
000073dfa87d7fd9  vmovaps [rsp+0xD0], xmm14
000073dfa87d7fe2  vmovaps [rsp+0xE0], xmm15
000073dfa87d7feb  sub rsp, 0x30
000073dfa87d7fef  movaps [rsp], xmm1
000073dfa87d7ff3  movaps [rsp+0x10], xmm14
000073dfa87d7ff9  movaps [rsp+0x20], xmm11
000073dfa87d7fff  lea rdi, [rsp]
000073dfa87d8003  mov esi, 0x00
000073dfa87d8008  mov rax, 0x593AA1DA4530
000073dfa87d8012  call rax
000073dfa87d8014  movaps xmm1, [rsp]
000073dfa87d8018  add rsp, 0x30
000073dfa87d801c  vmovaps xmm0, [rsp]
000073dfa87d8021  vmovaps xmm2, [rsp+0x10]
000073dfa87d8027  vmovaps xmm3, [rsp+0x20]
000073dfa87d802d  vmovaps xmm4, [rsp+0x30]
000073dfa87d8033  vmovaps xmm5, [rsp+0x40]
000073dfa87d8039  vmovaps xmm6, [rsp+0x50]
000073dfa87d803f  vmovaps xmm7, [rsp+0x60]
000073dfa87d8045  vmovaps xmm8, [rsp+0x70]
000073dfa87d804b  vmovaps xmm9, [rsp+0x80]
000073dfa87d8054  vmovaps xmm10, [rsp+0x90]
000073dfa87d805d  vmovaps xmm11, [rsp+0xA0]
000073dfa87d8066  vmovaps xmm12, [rsp+0xB0]
000073dfa87d806f  vmovaps xmm13, [rsp+0xC0]
000073dfa87d8078  vmovaps xmm14, [rsp+0xD0]
000073dfa87d8081  vmovaps xmm15, [rsp+0xE0]
000073dfa87d808a  add rsp, 0xF0
000073dfa87d8091  pop r11
000073dfa87d8093  pop r10
000073dfa87d8095  pop r9
000073dfa87d8097  pop r8
000073dfa87d8099  pop rsi
000073dfa87d809a  pop rdi
000073dfa87d809b  pop rdx
000073dfa87d809c  pop rcx
000073dfa87d809d  pop rax
000073dfa87d809e  add rsp, 0x08
000073dfa87d80a2  jmp 0x000073DFA87D345F
000073dfa87d80a7  call 0x000073DFA86E45A0
000073dfa87d80ac  jmp 0x000073DFA87D346D
000073dfa87d80b1  call 0x000073DFA8609D70
000073dfa87d80b6  jmp 0x000073DFA87D3477
000073dfa87d80bb  sub rsp, 0x08
000073dfa87d80bf  push rax
000073dfa87d80c0  push rcx
000073dfa87d80c1  push rdx
000073dfa87d80c2  push rdi
000073dfa87d80c3  push rsi
000073dfa87d80c4  push r8
000073dfa87d80c6  push r9
000073dfa87d80c8  push r10
000073dfa87d80ca  push r11
000073dfa87d80cc  sub rsp, 0xF0
000073dfa87d80d3  vmovaps [rsp], xmm0
000073dfa87d80d8  vmovaps [rsp+0x10], xmm1
000073dfa87d80de  vmovaps [rsp+0x20], xmm2
000073dfa87d80e4  vmovaps [rsp+0x30], xmm3
000073dfa87d80ea  vmovaps [rsp+0x40], xmm4
000073dfa87d80f0  vmovaps [rsp+0x50], xmm5
000073dfa87d80f6  vmovaps [rsp+0x60], xmm6
000073dfa87d80fc  vmovaps [rsp+0x70], xmm8
000073dfa87d8102  vmovaps [rsp+0x80], xmm9
000073dfa87d810b  vmovaps [rsp+0x90], xmm10
000073dfa87d8114  vmovaps [rsp+0xA0], xmm11
000073dfa87d811d  vmovaps [rsp+0xB0], xmm12
000073dfa87d8126  vmovaps [rsp+0xC0], xmm13
000073dfa87d812f  vmovaps [rsp+0xD0], xmm14
000073dfa87d8138  vmovaps [rsp+0xE0], xmm15
000073dfa87d8141  sub rsp, 0x30
000073dfa87d8145  movaps [rsp], xmm7
000073dfa87d8149  movaps [rsp+0x10], xmm13
000073dfa87d814f  movaps [rsp+0x20], xmm10
000073dfa87d8155  lea rdi, [rsp]
000073dfa87d8159  mov esi, 0x00
000073dfa87d815e  mov rax, 0x593AA1DA4530
000073dfa87d8168  call rax
000073dfa87d816a  movaps xmm7, [rsp]
000073dfa87d816e  add rsp, 0x30
000073dfa87d8172  vmovaps xmm0, [rsp]
000073dfa87d8177  vmovaps xmm1, [rsp+0x10]
000073dfa87d817d  vmovaps xmm2, [rsp+0x20]
000073dfa87d8183  vmovaps xmm3, [rsp+0x30]
000073dfa87d8189  vmovaps xmm4, [rsp+0x40]
000073dfa87d818f  vmovaps xmm5, [rsp+0x50]
000073dfa87d8195  vmovaps xmm6, [rsp+0x60]
000073dfa87d819b  vmovaps xmm8, [rsp+0x70]
000073dfa87d81a1  vmovaps xmm9, [rsp+0x80]
000073dfa87d81aa  vmovaps xmm10, [rsp+0x90]
000073dfa87d81b3  vmovaps xmm11, [rsp+0xA0]
000073dfa87d81bc  vmovaps xmm12, [rsp+0xB0]
000073dfa87d81c5  vmovaps xmm13, [rsp+0xC0]
000073dfa87d81ce  vmovaps xmm14, [rsp+0xD0]
000073dfa87d81d7  vmovaps xmm15, [rsp+0xE0]
000073dfa87d81e0  add rsp, 0xF0
000073dfa87d81e7  pop r11
000073dfa87d81e9  pop r10
000073dfa87d81eb  pop r9
000073dfa87d81ed  pop r8
000073dfa87d81ef  pop rsi
000073dfa87d81f0  pop rdi
000073dfa87d81f1  pop rdx
000073dfa87d81f2  pop rcx
000073dfa87d81f3  pop rax
000073dfa87d81f4  add rsp, 0x08
000073dfa87d81f8  jmp 0x000073DFA87D3498
000073dfa87d81fd  sub rsp, 0x08
000073dfa87d8201  push rax
000073dfa87d8202  push rcx
000073dfa87d8203  push rdx
000073dfa87d8204  push rdi
000073dfa87d8205  push rsi
000073dfa87d8206  push r8
000073dfa87d8208  push r9
000073dfa87d820a  push r10
000073dfa87d820c  push r11
000073dfa87d820e  sub rsp, 0xF0
000073dfa87d8215  vmovaps [rsp], xmm0
000073dfa87d821a  vmovaps [rsp+0x10], xmm1
000073dfa87d8220  vmovaps [rsp+0x20], xmm2
000073dfa87d8226  vmovaps [rsp+0x30], xmm3
000073dfa87d822c  vmovaps [rsp+0x40], xmm4
000073dfa87d8232  vmovaps [rsp+0x50], xmm5
000073dfa87d8238  vmovaps [rsp+0x60], xmm6
000073dfa87d823e  vmovaps [rsp+0x70], xmm7
000073dfa87d8244  vmovaps [rsp+0x80], xmm8
000073dfa87d824d  vmovaps [rsp+0x90], xmm9
000073dfa87d8256  vmovaps [rsp+0xA0], xmm11
000073dfa87d825f  vmovaps [rsp+0xB0], xmm12
000073dfa87d8268  vmovaps [rsp+0xC0], xmm13
000073dfa87d8271  vmovaps [rsp+0xD0], xmm14
000073dfa87d827a  vmovaps [rsp+0xE0], xmm15
000073dfa87d8283  sub rsp, 0x30
000073dfa87d8287  movaps [rsp], xmm10
000073dfa87d828c  movaps [rsp+0x10], xmm11
000073dfa87d8292  movaps [rsp+0x20], xmm13
000073dfa87d8298  lea rdi, [rsp]
000073dfa87d829c  mov esi, 0x00
000073dfa87d82a1  mov rax, 0x593AA1DA4530
000073dfa87d82ab  call rax
000073dfa87d82ad  movaps xmm10, [rsp]
000073dfa87d82b2  add rsp, 0x30
000073dfa87d82b6  vmovaps xmm0, [rsp]
000073dfa87d82bb  vmovaps xmm1, [rsp+0x10]
000073dfa87d82c1  vmovaps xmm2, [rsp+0x20]
000073dfa87d82c7  vmovaps xmm3, [rsp+0x30]
000073dfa87d82cd  vmovaps xmm4, [rsp+0x40]
000073dfa87d82d3  vmovaps xmm5, [rsp+0x50]
000073dfa87d82d9  vmovaps xmm6, [rsp+0x60]
000073dfa87d82df  vmovaps xmm7, [rsp+0x70]
000073dfa87d82e5  vmovaps xmm8, [rsp+0x80]
000073dfa87d82ee  vmovaps xmm9, [rsp+0x90]
000073dfa87d82f7  vmovaps xmm11, [rsp+0xA0]
000073dfa87d8300  vmovaps xmm12, [rsp+0xB0]
000073dfa87d8309  vmovaps xmm13, [rsp+0xC0]
000073dfa87d8312  vmovaps xmm14, [rsp+0xD0]
000073dfa87d831b  vmovaps xmm15, [rsp+0xE0]
000073dfa87d8324  add rsp, 0xF0
000073dfa87d832b  pop r11
000073dfa87d832d  pop r10
000073dfa87d832f  pop r9
000073dfa87d8331  pop r8
000073dfa87d8333  pop rsi
000073dfa87d8334  pop rdi
000073dfa87d8335  pop rdx
000073dfa87d8336  pop rcx
000073dfa87d8337  pop rax
000073dfa87d8338  add rsp, 0x08
000073dfa87d833c  jmp 0x000073DFA87D34C6
000073dfa87d8341  sub rsp, 0x08
000073dfa87d8345  push rax
000073dfa87d8346  push rcx
000073dfa87d8347  push rdx
000073dfa87d8348  push rdi
000073dfa87d8349  push rsi
000073dfa87d834a  push r8
000073dfa87d834c  push r9
000073dfa87d834e  push r10
000073dfa87d8350  push r11
000073dfa87d8352  sub rsp, 0xF0
000073dfa87d8359  vmovaps [rsp], xmm0
000073dfa87d835e  vmovaps [rsp+0x10], xmm1
000073dfa87d8364  vmovaps [rsp+0x20], xmm2
000073dfa87d836a  vmovaps [rsp+0x30], xmm3
000073dfa87d8370  vmovaps [rsp+0x40], xmm4
000073dfa87d8376  vmovaps [rsp+0x50], xmm5
000073dfa87d837c  vmovaps [rsp+0x60], xmm6
000073dfa87d8382  vmovaps [rsp+0x70], xmm7
000073dfa87d8388  vmovaps [rsp+0x80], xmm8
000073dfa87d8391  vmovaps [rsp+0x90], xmm9
000073dfa87d839a  vmovaps [rsp+0xA0], xmm10
000073dfa87d83a3  vmovaps [rsp+0xB0], xmm12
000073dfa87d83ac  vmovaps [rsp+0xC0], xmm13
000073dfa87d83b5  vmovaps [rsp+0xD0], xmm14
000073dfa87d83be  vmovaps [rsp+0xE0], xmm15
000073dfa87d83c7  sub rsp, 0x30
000073dfa87d83cb  movaps [rsp], xmm11
000073dfa87d83d0  movaps [rsp+0x10], xmm14
000073dfa87d83d6  movaps [rsp+0x20], xmm13
000073dfa87d83dc  lea rdi, [rsp]
000073dfa87d83e0  mov esi, 0x00
000073dfa87d83e5  mov rax, 0x593AA1DA4530
000073dfa87d83ef  call rax
000073dfa87d83f1  movaps xmm11, [rsp]
000073dfa87d83f6  add rsp, 0x30
000073dfa87d83fa  vmovaps xmm0, [rsp]
000073dfa87d83ff  vmovaps xmm1, [rsp+0x10]
000073dfa87d8405  vmovaps xmm2, [rsp+0x20]
000073dfa87d840b  vmovaps xmm3, [rsp+0x30]
000073dfa87d8411  vmovaps xmm4, [rsp+0x40]
000073dfa87d8417  vmovaps xmm5, [rsp+0x50]
000073dfa87d841d  vmovaps xmm6, [rsp+0x60]
000073dfa87d8423  vmovaps xmm7, [rsp+0x70]
000073dfa87d8429  vmovaps xmm8, [rsp+0x80]
000073dfa87d8432  vmovaps xmm9, [rsp+0x90]
000073dfa87d843b  vmovaps xmm10, [rsp+0xA0]
000073dfa87d8444  vmovaps xmm12, [rsp+0xB0]
000073dfa87d844d  vmovaps xmm13, [rsp+0xC0]
000073dfa87d8456  vmovaps xmm14, [rsp+0xD0]
000073dfa87d845f  vmovaps xmm15, [rsp+0xE0]
000073dfa87d8468  add rsp, 0xF0
000073dfa87d846f  pop r11
000073dfa87d8471  pop r10
000073dfa87d8473  pop r9
000073dfa87d8475  pop r8
000073dfa87d8477  pop rsi
000073dfa87d8478  pop rdi
000073dfa87d8479  pop rdx
000073dfa87d847a  pop rcx
000073dfa87d847b  pop rax
000073dfa87d847c  add rsp, 0x08
000073dfa87d8480  jmp 0x000073DFA87D34F4
000073dfa87d8485  sub rsp, 0x08
000073dfa87d8489  push rax
000073dfa87d848a  push rcx
000073dfa87d848b  push rdx
000073dfa87d848c  push rdi
000073dfa87d848d  push rsi
000073dfa87d848e  push r8
000073dfa87d8490  push r9
000073dfa87d8492  push r10
000073dfa87d8494  push r11
000073dfa87d8496  sub rsp, 0xF0
000073dfa87d849d  vmovaps [rsp], xmm0
000073dfa87d84a2  vmovaps [rsp+0x10], xmm1
000073dfa87d84a8  vmovaps [rsp+0x20], xmm2
000073dfa87d84ae  vmovaps [rsp+0x30], xmm3
000073dfa87d84b4  vmovaps [rsp+0x40], xmm4
000073dfa87d84ba  vmovaps [rsp+0x50], xmm5
000073dfa87d84c0  vmovaps [rsp+0x60], xmm6
000073dfa87d84c6  vmovaps [rsp+0x70], xmm7
000073dfa87d84cc  vmovaps [rsp+0x80], xmm8
000073dfa87d84d5  vmovaps [rsp+0x90], xmm9
000073dfa87d84de  vmovaps [rsp+0xA0], xmm10
000073dfa87d84e7  vmovaps [rsp+0xB0], xmm11
000073dfa87d84f0  vmovaps [rsp+0xC0], xmm12
000073dfa87d84f9  vmovaps [rsp+0xD0], xmm13
000073dfa87d8502  vmovaps [rsp+0xE0], xmm15
000073dfa87d850b  sub rsp, 0x30
000073dfa87d850f  movaps [rsp], xmm14
000073dfa87d8514  movaps [rsp+0x10], xmm12
000073dfa87d851a  movaps [rsp+0x20], xmm9
000073dfa87d8520  lea rdi, [rsp]
000073dfa87d8524  mov esi, 0x00
000073dfa87d8529  mov rax, 0x593AA1DA4530
000073dfa87d8533  call rax
000073dfa87d8535  movaps xmm14, [rsp]
000073dfa87d853a  add rsp, 0x30
000073dfa87d853e  vmovaps xmm0, [rsp]
000073dfa87d8543  vmovaps xmm1, [rsp+0x10]
000073dfa87d8549  vmovaps xmm2, [rsp+0x20]
000073dfa87d854f  vmovaps xmm3, [rsp+0x30]
000073dfa87d8555  vmovaps xmm4, [rsp+0x40]
000073dfa87d855b  vmovaps xmm5, [rsp+0x50]
000073dfa87d8561  vmovaps xmm6, [rsp+0x60]
000073dfa87d8567  vmovaps xmm7, [rsp+0x70]
000073dfa87d856d  vmovaps xmm8, [rsp+0x80]
000073dfa87d8576  vmovaps xmm9, [rsp+0x90]
000073dfa87d857f  vmovaps xmm10, [rsp+0xA0]
000073dfa87d8588  vmovaps xmm11, [rsp+0xB0]
000073dfa87d8591  vmovaps xmm12, [rsp+0xC0]
000073dfa87d859a  vmovaps xmm13, [rsp+0xD0]
000073dfa87d85a3  vmovaps xmm15, [rsp+0xE0]
000073dfa87d85ac  add rsp, 0xF0
000073dfa87d85b3  pop r11
000073dfa87d85b5  pop r10
000073dfa87d85b7  pop r9
000073dfa87d85b9  pop r8
000073dfa87d85bb  pop rsi
000073dfa87d85bc  pop rdi
000073dfa87d85bd  pop rdx
000073dfa87d85be  pop rcx
000073dfa87d85bf  pop rax
000073dfa87d85c0  add rsp, 0x08
000073dfa87d85c4  jmp 0x000073DFA87D350F
000073dfa87d85c9  sub rsp, 0x08
000073dfa87d85cd  push rax
000073dfa87d85ce  push rcx
000073dfa87d85cf  push rdx
000073dfa87d85d0  push rdi
000073dfa87d85d1  push rsi
000073dfa87d85d2  push r8
000073dfa87d85d4  push r9
000073dfa87d85d6  push r10
000073dfa87d85d8  push r11
000073dfa87d85da  sub rsp, 0xF0
000073dfa87d85e1  vmovaps [rsp], xmm0
000073dfa87d85e6  vmovaps [rsp+0x10], xmm1
000073dfa87d85ec  vmovaps [rsp+0x20], xmm2
000073dfa87d85f2  vmovaps [rsp+0x30], xmm3
000073dfa87d85f8  vmovaps [rsp+0x40], xmm4
000073dfa87d85fe  vmovaps [rsp+0x50], xmm5
000073dfa87d8604  vmovaps [rsp+0x60], xmm6
000073dfa87d860a  vmovaps [rsp+0x70], xmm7
000073dfa87d8610  vmovaps [rsp+0x80], xmm8
000073dfa87d8619  vmovaps [rsp+0x90], xmm9
000073dfa87d8622  vmovaps [rsp+0xA0], xmm10
000073dfa87d862b  vmovaps [rsp+0xB0], xmm11
000073dfa87d8634  vmovaps [rsp+0xC0], xmm12
000073dfa87d863d  vmovaps [rsp+0xD0], xmm14
000073dfa87d8646  vmovaps [rsp+0xE0], xmm15
000073dfa87d864f  sub rsp, 0x30
000073dfa87d8653  movaps [rsp], xmm13
000073dfa87d8658  movaps [rsp+0x10], xmm8
000073dfa87d865e  movaps [rsp+0x20], xmm15
000073dfa87d8664  lea rdi, [rsp]
000073dfa87d8668  mov esi, 0x00
000073dfa87d866d  mov rax, 0x593AA1DA4530
000073dfa87d8677  call rax
000073dfa87d8679  movaps xmm13, [rsp]
000073dfa87d867e  add rsp, 0x30
000073dfa87d8682  vmovaps xmm0, [rsp]
000073dfa87d8687  vmovaps xmm1, [rsp+0x10]
000073dfa87d868d  vmovaps xmm2, [rsp+0x20]
000073dfa87d8693  vmovaps xmm3, [rsp+0x30]
000073dfa87d8699  vmovaps xmm4, [rsp+0x40]
000073dfa87d869f  vmovaps xmm5, [rsp+0x50]
000073dfa87d86a5  vmovaps xmm6, [rsp+0x60]
000073dfa87d86ab  vmovaps xmm7, [rsp+0x70]
000073dfa87d86b1  vmovaps xmm8, [rsp+0x80]
000073dfa87d86ba  vmovaps xmm9, [rsp+0x90]
000073dfa87d86c3  vmovaps xmm10, [rsp+0xA0]
000073dfa87d86cc  vmovaps xmm11, [rsp+0xB0]
000073dfa87d86d5  vmovaps xmm12, [rsp+0xC0]
000073dfa87d86de  vmovaps xmm14, [rsp+0xD0]
000073dfa87d86e7  vmovaps xmm15, [rsp+0xE0]
000073dfa87d86f0  add rsp, 0xF0
000073dfa87d86f7  pop r11
000073dfa87d86f9  pop r10
000073dfa87d86fb  pop r9
000073dfa87d86fd  pop r8
000073dfa87d86ff  pop rsi
000073dfa87d8700  pop rdi
000073dfa87d8701  pop rdx
000073dfa87d8702  pop rcx
000073dfa87d8703  pop rax
000073dfa87d8704  add rsp, 0x08
000073dfa87d8708  jmp 0x000073DFA87D3532
000073dfa87d870d  sub rsp, 0x08
000073dfa87d8711  push rax
000073dfa87d8712  push rcx
000073dfa87d8713  push rdx
000073dfa87d8714  push rdi
000073dfa87d8715  push rsi
000073dfa87d8716  push r8
000073dfa87d8718  push r9
000073dfa87d871a  push r10
000073dfa87d871c  push r11
000073dfa87d871e  sub rsp, 0xF0
000073dfa87d8725  vmovaps [rsp], xmm0
000073dfa87d872a  vmovaps [rsp+0x10], xmm1
000073dfa87d8730  vmovaps [rsp+0x20], xmm2
000073dfa87d8736  vmovaps [rsp+0x30], xmm3
000073dfa87d873c  vmovaps [rsp+0x40], xmm4
000073dfa87d8742  vmovaps [rsp+0x50], xmm5
000073dfa87d8748  vmovaps [rsp+0x60], xmm6
000073dfa87d874e  vmovaps [rsp+0x70], xmm7
000073dfa87d8754  vmovaps [rsp+0x80], xmm8
000073dfa87d875d  vmovaps [rsp+0x90], xmm9
000073dfa87d8766  vmovaps [rsp+0xA0], xmm10
000073dfa87d876f  vmovaps [rsp+0xB0], xmm11
000073dfa87d8778  vmovaps [rsp+0xC0], xmm12
000073dfa87d8781  vmovaps [rsp+0xD0], xmm13
000073dfa87d878a  vmovaps [rsp+0xE0], xmm14
000073dfa87d8793  sub rsp, 0x30
000073dfa87d8797  movaps [rsp], xmm15
000073dfa87d879c  movaps [rsp+0x10], xmm1
000073dfa87d87a1  movaps [rsp+0x20], xmm10
000073dfa87d87a7  lea rdi, [rsp]
000073dfa87d87ab  mov esi, 0x00
000073dfa87d87b0  mov rax, 0x593AA1DA4530
000073dfa87d87ba  call rax
000073dfa87d87bc  movaps xmm15, [rsp]
000073dfa87d87c1  add rsp, 0x30
000073dfa87d87c5  vmovaps xmm0, [rsp]
000073dfa87d87ca  vmovaps xmm1, [rsp+0x10]
000073dfa87d87d0  vmovaps xmm2, [rsp+0x20]
000073dfa87d87d6  vmovaps xmm3, [rsp+0x30]
000073dfa87d87dc  vmovaps xmm4, [rsp+0x40]
000073dfa87d87e2  vmovaps xmm5, [rsp+0x50]
000073dfa87d87e8  vmovaps xmm6, [rsp+0x60]
000073dfa87d87ee  vmovaps xmm7, [rsp+0x70]
000073dfa87d87f4  vmovaps xmm8, [rsp+0x80]
000073dfa87d87fd  vmovaps xmm9, [rsp+0x90]
000073dfa87d8806  vmovaps xmm10, [rsp+0xA0]
000073dfa87d880f  vmovaps xmm11, [rsp+0xB0]
000073dfa87d8818  vmovaps xmm12, [rsp+0xC0]
000073dfa87d8821  vmovaps xmm13, [rsp+0xD0]
000073dfa87d882a  vmovaps xmm14, [rsp+0xE0]
000073dfa87d8833  add rsp, 0xF0
000073dfa87d883a  pop r11
000073dfa87d883c  pop r10
000073dfa87d883e  pop r9
000073dfa87d8840  pop r8
000073dfa87d8842  pop rsi
000073dfa87d8843  pop rdi
000073dfa87d8844  pop rdx
000073dfa87d8845  pop rcx
000073dfa87d8846  pop rax
000073dfa87d8847  add rsp, 0x08
000073dfa87d884b  jmp 0x000073DFA87D3555
000073dfa87d8850  sub rsp, 0x08
000073dfa87d8854  push rax
000073dfa87d8855  push rcx
000073dfa87d8856  push rdx
000073dfa87d8857  push rdi
000073dfa87d8858  push rsi
000073dfa87d8859  push r8
000073dfa87d885b  push r9
000073dfa87d885d  push r10
000073dfa87d885f  push r11
000073dfa87d8861  sub rsp, 0xF0
000073dfa87d8868  vmovaps [rsp], xmm0
000073dfa87d886d  vmovaps [rsp+0x10], xmm2
000073dfa87d8873  vmovaps [rsp+0x20], xmm3
000073dfa87d8879  vmovaps [rsp+0x30], xmm4
000073dfa87d887f  vmovaps [rsp+0x40], xmm5
000073dfa87d8885  vmovaps [rsp+0x50], xmm6
000073dfa87d888b  vmovaps [rsp+0x60], xmm7
000073dfa87d8891  vmovaps [rsp+0x70], xmm8
000073dfa87d8897  vmovaps [rsp+0x80], xmm9
000073dfa87d88a0  vmovaps [rsp+0x90], xmm10
000073dfa87d88a9  vmovaps [rsp+0xA0], xmm11
000073dfa87d88b2  vmovaps [rsp+0xB0], xmm12
000073dfa87d88bb  vmovaps [rsp+0xC0], xmm13
000073dfa87d88c4  vmovaps [rsp+0xD0], xmm14
000073dfa87d88cd  vmovaps [rsp+0xE0], xmm15
000073dfa87d88d6  sub rsp, 0x30
000073dfa87d88da  movaps [rsp], xmm1
000073dfa87d88de  movaps [rsp+0x10], xmm7
000073dfa87d88e3  movaps [rsp+0x20], xmm11
000073dfa87d88e9  lea rdi, [rsp]
000073dfa87d88ed  mov esi, 0x00
000073dfa87d88f2  mov rax, 0x593AA1DA4530
000073dfa87d88fc  call rax
000073dfa87d88fe  movaps xmm1, [rsp]
000073dfa87d8902  add rsp, 0x30
000073dfa87d8906  vmovaps xmm0, [rsp]
000073dfa87d890b  vmovaps xmm2, [rsp+0x10]
000073dfa87d8911  vmovaps xmm3, [rsp+0x20]
000073dfa87d8917  vmovaps xmm4, [rsp+0x30]
000073dfa87d891d  vmovaps xmm5, [rsp+0x40]
000073dfa87d8923  vmovaps xmm6, [rsp+0x50]
000073dfa87d8929  vmovaps xmm7, [rsp+0x60]
000073dfa87d892f  vmovaps xmm8, [rsp+0x70]
000073dfa87d8935  vmovaps xmm9, [rsp+0x80]
000073dfa87d893e  vmovaps xmm10, [rsp+0x90]
000073dfa87d8947  vmovaps xmm11, [rsp+0xA0]
000073dfa87d8950  vmovaps xmm12, [rsp+0xB0]
000073dfa87d8959  vmovaps xmm13, [rsp+0xC0]
000073dfa87d8962  vmovaps xmm14, [rsp+0xD0]
000073dfa87d896b  vmovaps xmm15, [rsp+0xE0]
000073dfa87d8974  add rsp, 0xF0
000073dfa87d897b  pop r11
000073dfa87d897d  pop r10
000073dfa87d897f  pop r9
000073dfa87d8981  pop r8
000073dfa87d8983  pop rsi
000073dfa87d8984  pop rdi
000073dfa87d8985  pop rdx
000073dfa87d8986  pop rcx
000073dfa87d8987  pop rax
000073dfa87d8988  add rsp, 0x08
000073dfa87d898c  jmp 0x000073DFA87D3576
000073dfa87d8991  call 0x000073DFA860D600
000073dfa87d8996  jmp 0x000073DFA87D3589
000073dfa87d899b  call 0x000073DFA860C380
000073dfa87d89a0  jmp 0x000073DFA87D3594
000073dfa87d89a5  call 0x000073DFA860E880
000073dfa87d89aa  jmp 0x000073DFA87D359F
000073dfa87d89af  call 0x000073DFA85FF540
000073dfa87d89b4  jmp 0x000073DFA87D35AA
000073dfa87d89b9  int3
000073dfa87d89ba  nop [rax+rax*1], ax
000073dfa87d89c0  mov rax, [r15+0x40]
000073dfa87d89c4  mov r14, [r15+0x58]
000073dfa87d89c8  lea r12, [rax+r14*1]
000073dfa87d89cc  movaps xmm1, [r15+0x1D0]
000073dfa87d89d4  vmovaps [rsp+0x10], xmm1
000073dfa87d89da  vmovaps xmm15, [rsp+0x10]
000073dfa87d89e0  por xmm1, xmm15
000073dfa87d89e5  movaps xmm14, [r15+0x1A0]
000073dfa87d89ed  vmovaps [rsp+0x10], xmm14
000073dfa87d89f3  vmovaps xmm13, [rsp+0x10]
000073dfa87d89f9  por xmm14, xmm13
000073dfa87d89fe  lea rax, [r12+0x30]
000073dfa87d8a03  mov r11, [r13+rax*1]
000073dfa87d8a08  lea rax, [r12+0x38]
000073dfa87d8a0d  mov r10, [r13+rax*1]
000073dfa87d8a12  movq xmm13, r11
000073dfa87d8a17  movq xmm12, r10
000073dfa87d8a1c  movq xmm13, xmm13
000073dfa87d8a21  vmovaps [rsp+0x10], xmm13
000073dfa87d8a27  movq xmm13, xmm13
000073dfa87d8a2c  movaps [r15+0x130], xmm13
000073dfa87d8a34  movq xmm12, xmm12
000073dfa87d8a39  vmovaps [rsp+0x20], xmm12
000073dfa87d8a3f  movq xmm12, xmm12
000073dfa87d8a44  movaps [r15+0x280], xmm12
000073dfa87d8a4c  movaps xmm13, [r15+0x270]
000073dfa87d8a54  vmovaps [rsp+0x30], xmm13
000073dfa87d8a5a  vmovaps xmm12, [rsp+0x30]
000073dfa87d8a60  por xmm13, xmm12
000073dfa87d8a65  lea rax, [r12+0x20]
000073dfa87d8a6a  mov r11, [r13+rax*1]
000073dfa87d8a6f  lea rax, [r12+0x28]
000073dfa87d8a74  mov r10, [r13+rax*1]
000073dfa87d8a79  movq xmm12, r11
000073dfa87d8a7e  movq xmm11, r10
000073dfa87d8a83  movq xmm12, xmm12
000073dfa87d8a88  vmovaps [rsp+0x30], xmm12
000073dfa87d8a8e  movq xmm12, xmm12
000073dfa87d8a93  movaps [r15+0x150], xmm12
000073dfa87d8a9b  movq xmm11, xmm11
000073dfa87d8aa0  vmovaps [rsp+0x40], xmm11
000073dfa87d8aa6  movq xmm11, xmm11
000073dfa87d8aab  movaps [r15+0x140], xmm11
000073dfa87d8ab3  lea rax, [r12+0x10]
000073dfa87d8ab8  mov r11, [r13+rax*1]
000073dfa87d8abd  lea rax, [r12+0x18]
000073dfa87d8ac2  mov r10, [r13+rax*1]
000073dfa87d8ac7  movq xmm12, r11
000073dfa87d8acc  movq xmm11, r10
000073dfa87d8ad1  movq xmm12, xmm12
000073dfa87d8ad6  vmovaps [rsp+0x50], xmm12
000073dfa87d8adc  movq xmm12, xmm12
000073dfa87d8ae1  movaps [r15+0x170], xmm12
000073dfa87d8ae9  movq xmm11, xmm11
000073dfa87d8aee  vmovaps [rsp+0x60], xmm11
000073dfa87d8af4  movq xmm11, xmm11
000073dfa87d8af9  movaps [r15+0x160], xmm11
000073dfa87d8b01  mov rax, [r13+r12*1]
000073dfa87d8b06  vmovq xmm12, rax
000073dfa87d8b0b  vpbroadcastq xmm12, xmm12
000073dfa87d8b10  lea rax, [r12+0x08]
000073dfa87d8b15  mov r12, [r13+rax*1]
000073dfa87d8b1a  movq xmm11, r12
000073dfa87d8b1f  movaps [r15+0x230], xmm11
000073dfa87d8b27  mov rax, [r15+0xF8]
000073dfa87d8b2e  lea r12, [rax+0x50]
000073dfa87d8b32  movups xmm11, [r13+r12*1]
000073dfa87d8b38  lea r12, [rax+0x60]
000073dfa87d8b3c  movups xmm10, [r13+r12*1]
000073dfa87d8b42  lea r12, [rax+0x30]
000073dfa87d8b46  movups xmm9, [r13+r12*1]
000073dfa87d8b4c  mov r12, [r15+0x50]
000073dfa87d8b50  lea r11, [r12+r14*1]
000073dfa87d8b54  mov [r15+0x60], r11
000073dfa87d8b58  lea r12, [r14+0x40]
000073dfa87d8b5c  mov [r15+0x58], r12
000073dfa87d8b60  movaps xmm8, xmm12
000073dfa87d8b64  mulpd xmm8, xmm15
000073dfa87d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000073dfa87d8b6f  ptest xmm7, xmm7
000073dfa87d8b74  jnz 0x000073DFA87D9997
000073dfa87d8b7a  movq xmm15, qword ptr [r15+0x230]
000073dfa87d8b83  vmovaps [rsp+0x70], xmm15
000073dfa87d8b89  vpermilpd xmm15, xmm15, 0x00
000073dfa87d8b8f  movaps xmm7, xmm9
000073dfa87d8b93  mulpd xmm7, xmm15
000073dfa87d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000073dfa87d8b9d  ptest xmm6, xmm6
000073dfa87d8ba2  jnz 0x000073DFA87D9ADB
000073dfa87d8ba8  vxorps xmm15, xmm15, xmm15
000073dfa87d8bad  vpbroadcastq xmm15, xmm15
000073dfa87d8bb2  movaps xmm9, xmm12
000073dfa87d8bb6  mulpd xmm9, xmm10
000073dfa87d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000073dfa87d8bc1  ptest xmm6, xmm6
000073dfa87d8bc6  jnz 0x000073DFA87D9C1D
000073dfa87d8bcc  movaps xmm10, xmm12
000073dfa87d8bd0  mulpd xmm10, xmm11
000073dfa87d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000073dfa87d8bdb  ptest xmm6, xmm6
000073dfa87d8be0  jnz 0x000073DFA87D9D61
000073dfa87d8be6  movaps xmm11, [r15+0x1F0]
000073dfa87d8bee  movaps xmm6, xmm12
000073dfa87d8bf2  mulpd xmm6, xmm11
000073dfa87d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000073dfa87d8bfc  ptest xmm5, xmm5
000073dfa87d8c01  jnz 0x000073DFA87D9EA5
000073dfa87d8c07  movaps xmm12, [r15+0x2A0]
000073dfa87d8c0f  vmovaps [rsp+0x80], xmm12
000073dfa87d8c18  vmovaps xmm11, [rsp+0x80]
000073dfa87d8c21  por xmm12, xmm11
000073dfa87d8c26  movaps xmm11, [r15+0x250]
000073dfa87d8c2e  vmovaps [rsp+0x80], xmm11
000073dfa87d8c37  vmovaps xmm5, [rsp+0x80]
000073dfa87d8c40  por xmm11, xmm5
000073dfa87d8c45  vmovaps xmm4, [rsp+0x70]
000073dfa87d8c4b  vpermilpd xmm4, xmm4, 0x00
000073dfa87d8c51  movaps xmm3, xmm5
000073dfa87d8c54  mulpd xmm3, xmm4
000073dfa87d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000073dfa87d8c5d  ptest xmm2, xmm2
000073dfa87d8c62  jnz 0x000073DFA87D9FE7
000073dfa87d8c68  mov [rsp+0x80], rax
000073dfa87d8c70  xor eax, eax
000073dfa87d8c72  mov r14d, 0x200
000073dfa87d8c78  cmp r12, r14
000073dfa87d8c7b  cmc
000073dfa87d8c7c  lahf
000073dfa87d8c7d  seto al
000073dfa87d8c80  mov [r15+0x108], eax
000073dfa87d8c87  movaps xmm5, xmm8
000073dfa87d8c8b  addpd xmm5, xmm15
000073dfa87d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000073dfa87d8c95  ptest xmm4, xmm4
000073dfa87d8c9a  jnz 0x000073DFA87DA127
000073dfa87d8ca0  movaps xmm8, [r15+0x1B0]
000073dfa87d8ca8  movaps xmm4, xmm9
000073dfa87d8cac  addpd xmm4, xmm8
000073dfa87d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000073dfa87d8cb6  ptest xmm2, xmm2
000073dfa87d8cbb  jnz 0x000073DFA87DA269
000073dfa87d8cc1  movaps xmm9, xmm10
000073dfa87d8cc5  addpd xmm9, xmm8
000073dfa87d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000073dfa87d8cd0  ptest xmm2, xmm2
000073dfa87d8cd5  jnz 0x000073DFA87DA3AB
000073dfa87d8cdb  movaps xmm10, [r15+0x2F0]
000073dfa87d8ce3  vmovaps [rsp+0x90], xmm10
000073dfa87d8cec  vmovaps xmm8, [rsp+0x90]
000073dfa87d8cf5  por xmm10, xmm8
000073dfa87d8cfa  movaps xmm8, [r15+0x2E0]
000073dfa87d8d02  vmovaps [rsp+0x90], xmm8
000073dfa87d8d0b  vmovaps xmm2, [rsp+0x90]
000073dfa87d8d14  por xmm8, xmm2
000073dfa87d8d19  movaps xmm2, [r15+0x2D0]
000073dfa87d8d21  vmovaps [rsp+0x90], xmm2
000073dfa87d8d2a  vmovaps [rsp+0xA0], xmm1
000073dfa87d8d33  vmovaps xmm1, [rsp+0x90]
000073dfa87d8d3c  por xmm2, xmm1
000073dfa87d8d40  movaps xmm1, [r15+0x200]
000073dfa87d8d48  vmovaps [rsp+0x90], xmm1
000073dfa87d8d51  vmovaps [rsp+0xB0], xmm15
000073dfa87d8d5a  vmovaps xmm15, [rsp+0x90]
000073dfa87d8d63  por xmm1, xmm15
000073dfa87d8d68  movaps xmm15, [r15+0x1C0]
000073dfa87d8d70  vmovaps [rsp+0x90], xmm15
000073dfa87d8d79  vmovaps [rsp+0xC0], xmm1
000073dfa87d8d82  vmovaps xmm1, [rsp+0x90]
000073dfa87d8d8b  por xmm15, xmm1
000073dfa87d8d90  movaps xmm1, [r15+0x190]
000073dfa87d8d98  vmovaps [rsp+0x90], xmm1
000073dfa87d8da1  vmovaps [rsp+0xD0], xmm15
000073dfa87d8daa  vmovaps xmm15, [rsp+0x90]
000073dfa87d8db3  por xmm1, xmm15
000073dfa87d8db8  movaps xmm15, [r15+0x300]
000073dfa87d8dc0  vmovaps [rsp+0x90], xmm15
000073dfa87d8dc9  vmovaps [rsp+0xE0], xmm1
000073dfa87d8dd2  vmovaps xmm1, [rsp+0x90]
000073dfa87d8ddb  por xmm15, xmm1
000073dfa87d8de0  mov rax, [rsp+0x80]
000073dfa87d8de8  lea r14, [rax+0xA0]
000073dfa87d8def  movups xmm1, [r13+r14*1]
000073dfa87d8df5  lea r14, [rax+0xB0]
000073dfa87d8dfc  vmovaps [rsp+0x80], xmm1
000073dfa87d8e05  movups xmm1, [r13+r14*1]
000073dfa87d8e0b  vmovaps [rsp+0x90], xmm1
000073dfa87d8e14  vmovaps [rsp+0xF0], xmm15
000073dfa87d8e1d  vmovaps xmm15, [rsp+0xB0]
000073dfa87d8e26  vmovaps [rsp+0xB0], xmm14
000073dfa87d8e2f  movaps xmm1, xmm6
000073dfa87d8e32  addpd xmm1, xmm15
000073dfa87d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000073dfa87d8e3c  ptest xmm14, xmm14
000073dfa87d8e42  jnz 0x000073DFA87DA503
000073dfa87d8e48  lea r14, [rax+0xF0]
000073dfa87d8e4f  movups xmm15, [r13+r14*1]
000073dfa87d8e55  movaps xmm14, xmm4
000073dfa87d8e59  addpd xmm14, xmm3
000073dfa87d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000073dfa87d8e64  ptest xmm6, xmm6
000073dfa87d8e69  jnz 0x000073DFA87DA64E
000073dfa87d8e6f  movaps xmm6, xmm9
000073dfa87d8e73  addpd xmm6, xmm7
000073dfa87d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000073dfa87d8e7c  ptest xmm4, xmm4
000073dfa87d8e81  jnz 0x000073DFA87DA790
000073dfa87d8e87  vmovaps xmm9, [rsp+0x70]
000073dfa87d8e8d  vpermilpd xmm9, xmm9, 0x00
000073dfa87d8e93  vmovaps xmm4, [rsp+0x90]
000073dfa87d8e9c  movaps xmm7, xmm4
000073dfa87d8e9f  mulpd xmm7, xmm9
000073dfa87d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000073dfa87d8ea9  ptest xmm3, xmm3
000073dfa87d8eae  jnz 0x000073DFA87DA8D1
000073dfa87d8eb4  vmovaps xmm9, [rsp+0x50]
000073dfa87d8eba  vpermilpd xmm9, xmm9, 0x00
000073dfa87d8ec0  movaps xmm4, xmm15
000073dfa87d8ec4  mulpd xmm4, xmm9
000073dfa87d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000073dfa87d8ece  ptest xmm3, xmm3
000073dfa87d8ed3  jnz 0x000073DFA87DAA12
000073dfa87d8ed9  lea r14, [rax+0xE0]
000073dfa87d8ee0  movups xmm15, [r13+r14*1]
000073dfa87d8ee6  vmovaps xmm9, [rsp+0x70]
000073dfa87d8eec  vpermilpd xmm9, xmm9, 0x00
000073dfa87d8ef2  vmovaps [rsp+0x70], xmm1
000073dfa87d8ef8  vmovaps xmm1, [rsp+0x80]
000073dfa87d8f01  vmovaps [rsp+0x80], xmm15
000073dfa87d8f0a  movaps xmm3, xmm1
000073dfa87d8f0d  mulpd xmm3, xmm9
000073dfa87d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000073dfa87d8f17  ptest xmm15, xmm15
000073dfa87d8f1d  jnz 0x000073DFA87DAB5E
000073dfa87d8f23  vmovaps xmm1, [rsp+0xF0]
000073dfa87d8f2c  vmovaps xmm15, [rsp+0xF0]
000073dfa87d8f35  por xmm1, xmm15
000073dfa87d8f3a  movaps [r15+0x300], xmm1
000073dfa87d8f42  vmovaps xmm15, [rsp+0xE0]
000073dfa87d8f4b  vmovaps xmm9, [rsp+0xE0]
000073dfa87d8f54  por xmm15, xmm9
000073dfa87d8f59  movaps [r15+0x190], xmm15
000073dfa87d8f61  vmovaps xmm9, [rsp+0x50]
000073dfa87d8f67  vpermilpd xmm9, xmm9, 0x00
000073dfa87d8f6d  vmovaps [rsp+0x90], xmm1
000073dfa87d8f76  vmovaps [rsp+0xE0], xmm15
000073dfa87d8f7f  vmovaps xmm15, [rsp+0x80]
000073dfa87d8f88  vmovaps [rsp+0x80], xmm14
000073dfa87d8f91  movaps xmm1, xmm15
000073dfa87d8f95  mulpd xmm1, xmm9
000073dfa87d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000073dfa87d8f9f  ptest xmm14, xmm14
000073dfa87d8fa5  jnz 0x000073DFA87DAC9F
000073dfa87d8fab  lea r14, [rax+0x90]
000073dfa87d8fb2  movups xmm15, [r13+r14*1]
000073dfa87d8fb8  vmovaps xmm14, [rsp+0xD0]
000073dfa87d8fc1  vmovaps xmm9, [rsp+0xD0]
000073dfa87d8fca  por xmm14, xmm9
000073dfa87d8fcf  movaps [r15+0x1C0], xmm14
000073dfa87d8fd7  vmovaps xmm9, [rsp+0xC0]
000073dfa87d8fe0  vmovaps [rsp+0xD0], xmm1
000073dfa87d8fe9  vmovaps xmm1, [rsp+0xC0]
000073dfa87d8ff2  por xmm9, xmm1
000073dfa87d8ff7  movaps [r15+0x200], xmm9
000073dfa87d8fff  vmovaps [rsp+0xC0], xmm2
000073dfa87d9008  vmovaps xmm1, [rsp+0xC0]
000073dfa87d9011  por xmm2, xmm1
000073dfa87d9015  movaps [r15+0x2D0], xmm2
000073dfa87d901d  vmovaps [rsp+0xC0], xmm8
000073dfa87d9026  vmovaps xmm1, [rsp+0xC0]
000073dfa87d902f  por xmm8, xmm1
000073dfa87d9034  movaps [r15+0x2E0], xmm8
000073dfa87d903c  vmovaps [rsp+0xC0], xmm15
000073dfa87d9045  movaps xmm1, xmm5
000073dfa87d9048  addpd xmm1, xmm7
000073dfa87d904c  vcmppd xmm15, xmm1, xmm1, 0x03
000073dfa87d9051  ptest xmm15, xmm15
000073dfa87d9057  jnz 0x000073DFA87DADEB
000073dfa87d905d  vmovaps xmm15, [rsp+0x50]
000073dfa87d9063  vpermilpd xmm15, xmm15, 0x00
000073dfa87d9069  vmovaps xmm5, [rsp+0xC0]
000073dfa87d9072  vmovaps [rsp+0xC0], xmm1
000073dfa87d907b  movaps xmm7, xmm5
000073dfa87d907e  mulpd xmm7, xmm15
000073dfa87d9083  vcmppd xmm1, xmm7, xmm7, 0x03
000073dfa87d9088  ptest xmm1, xmm1
000073dfa87d908d  jnz 0x000073DFA87DAF2B
000073dfa87d9093  lea r14, [rax+0x80]
000073dfa87d909a  movups xmm1, [r13+r14*1]
000073dfa87d90a0  vmovaps xmm5, [rsp+0x70]
000073dfa87d90a6  vmovaps [rsp+0x70], xmm1
000073dfa87d90ac  movaps xmm15, xmm5
000073dfa87d90b0  addpd xmm15, xmm3
000073dfa87d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000073dfa87d90bb  ptest xmm1, xmm1
000073dfa87d90c0  jnz 0x000073DFA87DB076
000073dfa87d90c6  vmovaps xmm5, [rsp+0x80]
000073dfa87d90cf  movaps xmm1, xmm5
000073dfa87d90d2  addpd xmm1, xmm4
000073dfa87d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000073dfa87d90db  ptest xmm3, xmm3
000073dfa87d90e0  jnz 0x000073DFA87DB1B8
000073dfa87d90e6  vmovaps [rsp+0x80], xmm10
000073dfa87d90ef  vmovaps xmm5, [rsp+0x80]
000073dfa87d90f8  por xmm10, xmm5
000073dfa87d90fd  movaps [r15+0x2F0], xmm10
000073dfa87d9105  vmovaps xmm5, [rsp+0x50]
000073dfa87d910b  vpermilpd xmm5, xmm5, 0x00
000073dfa87d9111  vmovaps xmm3, [rsp+0x70]
000073dfa87d9117  vmovaps [rsp+0x50], xmm1
000073dfa87d911d  movaps xmm4, xmm3
000073dfa87d9120  mulpd xmm4, xmm5
000073dfa87d9124  vcmppd xmm1, xmm4, xmm4, 0x03
000073dfa87d9129  ptest xmm1, xmm1
000073dfa87d912e  jnz 0x000073DFA87DB2F8
000073dfa87d9134  lea r14, [rax+0xD0]
000073dfa87d913b  movups xmm1, [r13+r14*1]
000073dfa87d9141  vmovaps xmm3, [rsp+0xD0]
000073dfa87d914a  vmovaps [rsp+0x70], xmm1
000073dfa87d9150  movaps xmm5, xmm6
000073dfa87d9153  addpd xmm5, xmm3
000073dfa87d9157  vcmppd xmm1, xmm5, xmm5, 0x03
000073dfa87d915c  ptest xmm1, xmm1
000073dfa87d9161  jnz 0x000073DFA87DB442
000073dfa87d9167  vmovaps xmm1, [rsp+0x60]
000073dfa87d916d  vpermilpd xmm1, xmm1, 0x00
000073dfa87d9173  movaps xmm6, xmm9
000073dfa87d9177  mulpd xmm6, xmm1
000073dfa87d917b  vcmppd xmm3, xmm6, xmm6, 0x03
000073dfa87d9180  ptest xmm3, xmm3
000073dfa87d9185  jnz 0x000073DFA87DB582
000073dfa87d918b  movaps [r15+0x260], xmm6
000073dfa87d9193  vxorps xmm1, xmm1, xmm1
000073dfa87d9197  vpbroadcastq xmm1, xmm1
000073dfa87d919c  movaps [r15+0x1B0], xmm1
000073dfa87d91a4  vmovaps xmm1, [rsp+0x60]
000073dfa87d91aa  vpermilpd xmm1, xmm1, 0x00
000073dfa87d91b0  vmovaps xmm3, [rsp+0x70]
000073dfa87d91b6  vmovaps [rsp+0x70], xmm15
000073dfa87d91bc  movaps xmm9, xmm3
000073dfa87d91c0  mulpd xmm9, xmm1
000073dfa87d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000073dfa87d91cb  ptest xmm15, xmm15
000073dfa87d91d1  jnz 0x000073DFA87DB6C3
000073dfa87d91d7  lea r14, [rax+0xC0]
000073dfa87d91de  movups xmm1, [r13+r14*1]
000073dfa87d91e4  vmovaps xmm3, [rsp+0xC0]
000073dfa87d91ed  vmovaps [rsp+0x80], xmm1
000073dfa87d91f6  movaps xmm15, xmm3
000073dfa87d91fa  addpd xmm15, xmm7
000073dfa87d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000073dfa87d9205  ptest xmm1, xmm1
000073dfa87d920a  jnz 0x000073DFA87DB80F
000073dfa87d9210  vmovaps [rsp+0xC0], xmm13
000073dfa87d9219  vmovaps xmm1, [rsp+0xC0]
000073dfa87d9222  por xmm13, xmm1
000073dfa87d9227  movaps [r15+0x270], xmm13
000073dfa87d922f  vmovaps xmm1, [rsp+0xB0]
000073dfa87d9238  vmovaps xmm7, [rsp+0xB0]
000073dfa87d9241  por xmm1, xmm7
000073dfa87d9245  movaps [r15+0x1A0], xmm1
000073dfa87d924d  vmovaps xmm1, [rsp+0x60]
000073dfa87d9253  vpermilpd xmm1, xmm1, 0x00
000073dfa87d9259  vmovaps [rsp+0xB0], xmm1
000073dfa87d9262  vmovaps xmm1, [rsp+0x80]
000073dfa87d926b  vmovaps [rsp+0x80], xmm15
000073dfa87d9274  vmovaps xmm15, [rsp+0xB0]
000073dfa87d927d  vmovaps [rsp+0xB0], xmm14
000073dfa87d9286  movaps xmm3, xmm1
000073dfa87d9289  mulpd xmm3, xmm15
000073dfa87d928e  vcmppd xmm14, xmm3, xmm3, 0x03
000073dfa87d9293  ptest xmm14, xmm14
000073dfa87d9299  jnz 0x000073DFA87DB951
000073dfa87d929f  lea r14, [rax+0x20]
000073dfa87d92a3  movups xmm1, [r13+r14*1]
000073dfa87d92a9  movaps [r15+0x110], xmm1
000073dfa87d92b1  vmovaps xmm14, [rsp+0x70]
000073dfa87d92b7  vmovaps [rsp+0x70], xmm1
000073dfa87d92bd  movaps xmm15, xmm14
000073dfa87d92c1  addpd xmm15, xmm4
000073dfa87d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000073dfa87d92cc  ptest xmm1, xmm1
000073dfa87d92d1  jnz 0x000073DFA87DBA9C
000073dfa87d92d7  vmovaps xmm1, [rsp+0x60]
000073dfa87d92dd  vpermilpd xmm1, xmm1, 0x00
000073dfa87d92e3  movaps xmm14, xmm2
000073dfa87d92e7  mulpd xmm14, xmm1
000073dfa87d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000073dfa87d92f2  ptest xmm4, xmm4
000073dfa87d92f7  jnz 0x000073DFA87DBBDF
000073dfa87d92fd  vmovaps xmm4, [rsp+0x50]
000073dfa87d9303  movaps xmm1, xmm4
000073dfa87d9306  addpd xmm1, xmm9
000073dfa87d930b  vcmppd xmm2, xmm1, xmm1, 0x03
000073dfa87d9310  ptest xmm2, xmm2
000073dfa87d9315  jnz 0x000073DFA87DBD21
000073dfa87d931b  vmovaps xmm9, [rsp+0x30]
000073dfa87d9321  vpermilpd xmm9, xmm9, 0x00
000073dfa87d9327  vmovaps xmm2, [rsp+0x70]
000073dfa87d932d  vmovaps [rsp+0x50], xmm1
000073dfa87d9333  movaps xmm4, xmm2
000073dfa87d9336  mulpd xmm4, xmm9
000073dfa87d933b  vcmppd xmm1, xmm4, xmm4, 0x03
000073dfa87d9340  ptest xmm1, xmm1
000073dfa87d9345  jnz 0x000073DFA87DBE62
000073dfa87d934b  vmovaps xmm1, [rsp+0x30]
000073dfa87d9351  vpermilpd xmm1, xmm1, 0x00
000073dfa87d9357  vmovaps xmm2, [rsp+0x90]
000073dfa87d9360  vmovaps [rsp+0x60], xmm15
000073dfa87d9366  movaps xmm9, xmm2
000073dfa87d936a  mulpd xmm9, xmm1
000073dfa87d936f  vcmppd xmm15, xmm9, xmm9, 0x03
000073dfa87d9375  ptest xmm15, xmm15
000073dfa87d937b  jnz 0x000073DFA87DBFA3
000073dfa87d9381  vmovaps xmm15, [rsp+0x80]
000073dfa87d938a  movaps xmm1, xmm15
000073dfa87d938e  addpd xmm1, xmm6
000073dfa87d9392  vcmppd xmm2, xmm1, xmm1, 0x03
000073dfa87d9397  ptest xmm2, xmm2
000073dfa87d939c  jnz 0x000073DFA87DC0E5
000073dfa87d93a2  movaps xmm15, xmm5
000073dfa87d93a6  addpd xmm15, xmm3
000073dfa87d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000073dfa87d93b1  ptest xmm6, xmm6
000073dfa87d93b6  jnz 0x000073DFA87DC226
000073dfa87d93bc  vmovaps xmm6, [rsp+0x30]
000073dfa87d93c2  vpermilpd xmm6, xmm6, 0x00
000073dfa87d93c8  movaps xmm5, xmm8
000073dfa87d93cc  mulpd xmm5, xmm6
000073dfa87d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000073dfa87d93d5  ptest xmm3, xmm3
000073dfa87d93da  jnz 0x000073DFA87DC368
000073dfa87d93e0  vmovaps xmm8, [rsp+0x30]
000073dfa87d93e6  vpermilpd xmm8, xmm8, 0x00
000073dfa87d93ec  movaps xmm6, xmm10
000073dfa87d93f0  mulpd xmm6, xmm8
000073dfa87d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000073dfa87d93fa  ptest xmm3, xmm3
000073dfa87d93ff  jnz 0x000073DFA87DC4A9
000073dfa87d9405  vmovaps xmm8, [rsp+0x60]
000073dfa87d940b  movaps xmm10, xmm8
000073dfa87d940f  addpd xmm10, xmm14
000073dfa87d9414  vcmppd xmm3, xmm10, xmm10, 0x03
000073dfa87d941a  ptest xmm3, xmm3
000073dfa87d941f  jnz 0x000073DFA87DC5EB
000073dfa87d9425  vmovaps xmm8, [rsp+0x50]
000073dfa87d942b  movaps xmm14, xmm8
000073dfa87d942f  addpd xmm14, xmm4
000073dfa87d9434  vcmppd xmm3, xmm14, xmm14, 0x03
000073dfa87d943a  ptest xmm3, xmm3
000073dfa87d943f  jnz 0x000073DFA87DC72F
000073dfa87d9445  vmovaps xmm8, [rsp+0x40]
000073dfa87d944b  vpermilpd xmm8, xmm8, 0x00
000073dfa87d9451  movaps xmm4, xmm13
000073dfa87d9455  mulpd xmm4, xmm8
000073dfa87d945a  vcmppd xmm3, xmm4, xmm4, 0x03
000073dfa87d945f  ptest xmm3, xmm3
000073dfa87d9464  jnz 0x000073DFA87DC872
000073dfa87d946a  movaps xmm13, xmm15
000073dfa87d946e  addpd xmm13, xmm9
000073dfa87d9473  vcmppd xmm8, xmm13, xmm13, 0x03
000073dfa87d9479  ptest xmm8, xmm8
000073dfa87d947f  jnz 0x000073DFA87DC9B4
000073dfa87d9485  movaps xmm15, xmm1
000073dfa87d9489  addpd xmm15, xmm5
000073dfa87d948e  vcmppd xmm9, xmm15, xmm15, 0x03
000073dfa87d9494  ptest xmm9, xmm9
000073dfa87d949a  jnz 0x000073DFA87DCAF8
000073dfa87d94a0  vmovaps [rsp+0x30], xmm11
000073dfa87d94a6  vmovaps xmm1, [rsp+0x30]
000073dfa87d94ac  por xmm11, xmm1
000073dfa87d94b1  movaps [r15+0x250], xmm11
000073dfa87d94b9  vmovaps [rsp+0x30], xmm12
000073dfa87d94bf  vmovaps xmm1, [rsp+0x30]
000073dfa87d94c5  por xmm12, xmm1
000073dfa87d94ca  movaps [r15+0x2A0], xmm12
000073dfa87d94d2  vmovaps xmm1, [rsp+0xA0]
000073dfa87d94db  vmovaps xmm11, [rsp+0xA0]
000073dfa87d94e4  por xmm1, xmm11
000073dfa87d94e9  movaps [r15+0x1D0], xmm1
000073dfa87d94f1  lea r14, [rax+0x40]
000073dfa87d94f5  movups xmm1, [r13+r14*1]
000073dfa87d94fb  movaps [r15+0x2C0], xmm1
000073dfa87d9503  vmovaps xmm11, [rsp+0x40]
000073dfa87d9509  vpermilpd xmm11, xmm11, 0x00
000073dfa87d950f  vmovaps xmm8, [rsp+0xE0]
000073dfa87d9518  movaps xmm9, xmm8
000073dfa87d951c  mulpd xmm9, xmm11
000073dfa87d9521  vcmppd xmm5, xmm9, xmm9, 0x03
000073dfa87d9527  ptest xmm5, xmm5
000073dfa87d952c  jnz 0x000073DFA87DCC44
000073dfa87d9532  movaps xmm11, xmm10
000073dfa87d9536  addpd xmm11, xmm6
000073dfa87d953b  vcmppd xmm8, xmm11, xmm11, 0x03
000073dfa87d9541  ptest xmm8, xmm8
000073dfa87d9547  jnz 0x000073DFA87DCD88
000073dfa87d954d  movaps xmm10, xmm14
000073dfa87d9551  addpd xmm10, xmm4
000073dfa87d9556  vcmppd xmm8, xmm10, xmm10, 0x03
000073dfa87d955c  ptest xmm8, xmm8
000073dfa87d9562  jnz 0x000073DFA87DCECB
000073dfa87d9568  vmovaps xmm14, [rsp+0x40]
000073dfa87d956e  vpermilpd xmm14, xmm14, 0x00
000073dfa87d9574  movaps xmm8, xmm1
000073dfa87d9578  mulpd xmm8, xmm14
000073dfa87d957d  vcmppd xmm6, xmm8, xmm8, 0x03
000073dfa87d9583  ptest xmm6, xmm6
000073dfa87d9588  jnz 0x000073DFA87DD00E
000073dfa87d958e  movaps xmm1, [r15+0x2B0]
000073dfa87d9596  vmovaps xmm14, [rsp+0x40]
000073dfa87d959c  vpermilpd xmm14, xmm14, 0x00
000073dfa87d95a2  movaps xmm6, xmm1
000073dfa87d95a5  mulpd xmm6, xmm14
000073dfa87d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000073dfa87d95af  ptest xmm5, xmm5
000073dfa87d95b4  jnz 0x000073DFA87DD151
000073dfa87d95ba  vmovaps xmm1, [rsp+0x10]
000073dfa87d95c0  vpermilpd xmm1, xmm1, 0x00
000073dfa87d95c6  movaps xmm14, xmm12
000073dfa87d95ca  mulpd xmm14, xmm1
000073dfa87d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000073dfa87d95d5  ptest xmm5, xmm5
000073dfa87d95da  jnz 0x000073DFA87DD292
000073dfa87d95e0  movaps xmm1, xmm13
000073dfa87d95e4  addpd xmm1, xmm9
000073dfa87d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000073dfa87d95ee  ptest xmm12, xmm12
000073dfa87d95f4  jnz 0x000073DFA87DD3D5
000073dfa87d95fa  vmovaps xmm13, [rsp+0x10]
000073dfa87d9600  vpermilpd xmm13, xmm13, 0x00
000073dfa87d9606  movaps xmm12, xmm7
000073dfa87d960a  mulpd xmm12, xmm13
000073dfa87d960f  vcmppd xmm9, xmm12, xmm12, 0x03
000073dfa87d9615  ptest xmm9, xmm9
000073dfa87d961b  jnz 0x000073DFA87DD517
000073dfa87d9621  movaps xmm13, xmm15
000073dfa87d9625  addpd xmm13, xmm8
000073dfa87d962a  vcmppd xmm9, xmm13, xmm13, 0x03
000073dfa87d9630  ptest xmm9, xmm9
000073dfa87d9636  jnz 0x000073DFA87DD65A
000073dfa87d963c  movaps xmm15, [r15+0x290]
000073dfa87d9644  vmovaps xmm9, [rsp+0x10]
000073dfa87d964a  vpermilpd xmm9, xmm9, 0x00
000073dfa87d9650  movaps xmm8, xmm15
000073dfa87d9654  mulpd xmm8, xmm9
000073dfa87d9659  vcmppd xmm7, xmm8, xmm8, 0x03
000073dfa87d965f  ptest xmm7, xmm7
000073dfa87d9664  jnz 0x000073DFA87DD79E
000073dfa87d966a  movaps xmm15, xmm11
000073dfa87d966e  addpd xmm15, xmm6
000073dfa87d9673  vcmppd xmm9, xmm15, xmm15, 0x03
000073dfa87d9679  ptest xmm9, xmm9
000073dfa87d967f  jnz 0x000073DFA87DD8E2
000073dfa87d9685  movaps xmm11, [r15+0x1E0]
000073dfa87d968d  vmovaps xmm9, [rsp+0x10]
000073dfa87d9693  vpermilpd xmm9, xmm9, 0x00
000073dfa87d9699  movaps xmm7, xmm11
000073dfa87d969d  mulpd xmm7, xmm9
000073dfa87d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000073dfa87d96a7  ptest xmm6, xmm6
000073dfa87d96ac  jnz 0x000073DFA87DDA25
000073dfa87d96b2  movaps xmm11, xmm10
000073dfa87d96b6  addpd xmm11, xmm14
000073dfa87d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000073dfa87d96c1  ptest xmm9, xmm9
000073dfa87d96c7  jnz 0x000073DFA87DDB67
000073dfa87d96cd  lea r14, [rax+0x70]
000073dfa87d96d1  movups xmm14, [r13+r14*1]
000073dfa87d96d7  movaps [r15+0x240], xmm14
000073dfa87d96df  movaps xmm10, xmm1
000073dfa87d96e3  addpd xmm10, xmm12
000073dfa87d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000073dfa87d96ee  ptest xmm9, xmm9
000073dfa87d96f4  jnz 0x000073DFA87DDCB5
000073dfa87d96fa  movaps [r15+0x170], xmm10
000073dfa87d9702  vmovaps xmm1, [rsp+0x20]
000073dfa87d9708  vpermilpd xmm1, xmm1, 0x00
000073dfa87d970e  movaps xmm12, xmm14
000073dfa87d9712  mulpd xmm12, xmm1
000073dfa87d9717  vcmppd xmm9, xmm12, xmm12, 0x03
000073dfa87d971d  ptest xmm9, xmm9
000073dfa87d9723  jnz 0x000073DFA87DDDF8
000073dfa87d9729  vmovaps xmm1, [rsp+0x20]
000073dfa87d972f  vpermilpd xmm1, xmm1, 0x00
000073dfa87d9735  vmovaps xmm9, [rsp+0xB0]
000073dfa87d973e  movaps xmm14, xmm9
000073dfa87d9742  mulpd xmm14, xmm1
000073dfa87d9747  vcmppd xmm6, xmm14, xmm14, 0x03
000073dfa87d974d  ptest xmm6, xmm6
000073dfa87d9752  jnz 0x000073DFA87DDF3B
000073dfa87d9758  movaps [r15+0x180], xmm14
000073dfa87d9760  movaps xmm1, xmm13
000073dfa87d9764  addpd xmm1, xmm8
000073dfa87d9769  vcmppd xmm9, xmm1, xmm1, 0x03
000073dfa87d976e  ptest xmm9, xmm9
000073dfa87d9774  jnz 0x000073DFA87DE07E
000073dfa87d977a  movaps [r15+0x210], xmm1
000073dfa87d9782  movups xmm13, [r13+rax*1]
000073dfa87d9788  lea r14, [rax+0x10]
000073dfa87d978c  movups xmm9, [r13+r14*1]
000073dfa87d9792  movaps [r15+0x230], xmm9
000073dfa87d979a  movaps xmm8, xmm15
000073dfa87d979e  addpd xmm8, xmm7
000073dfa87d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000073dfa87d97a9  ptest xmm6, xmm6
000073dfa87d97ae  jnz 0x000073DFA87DE1D4
000073dfa87d97b4  movaps [r15+0x130], xmm8
000073dfa87d97bc  vmovaps xmm15, [rsp+0x20]
000073dfa87d97c2  vpermilpd xmm15, xmm15, 0x00
000073dfa87d97c8  movaps xmm7, xmm9
000073dfa87d97cc  mulpd xmm7, xmm15
000073dfa87d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000073dfa87d97d6  ptest xmm6, xmm6
000073dfa87d97db  jnz 0x000073DFA87DE317
000073dfa87d97e1  movaps [r15+0x220], xmm7
000073dfa87d97e9  vmovaps xmm15, [rsp+0x20]
000073dfa87d97ef  vpermilpd xmm15, xmm15, 0x00
000073dfa87d97f5  movaps xmm9, xmm13
000073dfa87d97f9  mulpd xmm9, xmm15
000073dfa87d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000073dfa87d9804  ptest xmm6, xmm6
000073dfa87d9809  jnz 0x000073DFA87DE459
000073dfa87d980f  movaps xmm15, xmm11
000073dfa87d9813  addpd xmm15, xmm12
000073dfa87d9818  vcmppd xmm13, xmm15, xmm15, 0x03
000073dfa87d981e  ptest xmm13, xmm13
000073dfa87d9824  jnz 0x000073DFA87DE59D
000073dfa87d982a  movaps [r15+0x140], xmm15
000073dfa87d9832  movaps xmm13, xmm10
000073dfa87d9836  addpd xmm13, xmm14
000073dfa87d983b  vcmppd xmm12, xmm13, xmm13, 0x03
000073dfa87d9841  ptest xmm12, xmm12
000073dfa87d9847  jnz 0x000073DFA87DE6E1
000073dfa87d984d  movaps [r15+0x150], xmm13
000073dfa87d9855  movaps xmm14, xmm1
000073dfa87d9859  addpd xmm14, xmm7
000073dfa87d985e  vcmppd xmm12, xmm14, xmm14, 0x03
000073dfa87d9864  ptest xmm12, xmm12
000073dfa87d986a  jnz 0x000073DFA87DE825
000073dfa87d9870  movaps [r15+0x160], xmm14
000073dfa87d9878  movaps xmm1, xmm8
000073dfa87d987c  addpd xmm1, xmm9
000073dfa87d9881  vcmppd xmm12, xmm1, xmm1, 0x03
000073dfa87d9886  ptest xmm12, xmm12
000073dfa87d988c  jnz 0x000073DFA87DE967
000073dfa87d9892  movaps [r15+0x120], xmm1
000073dfa87d989a  movups [r13+r11*1], xmm15
000073dfa87d98a0  lea rax, [r11+0x10]
000073dfa87d98a4  movups [r13+rax*1], xmm13
000073dfa87d98aa  lea rax, [r11+0x20]
000073dfa87d98ae  movups [r13+rax*1], xmm14
000073dfa87d98b4  lea rax, [r11+0x30]
000073dfa87d98b8  movups [r13+rax*1], xmm1
000073dfa87d98be  mov eax, [r15+0x108]
000073dfa87d98c5  sahf
000073dfa87d98c6  jnz 0x000073DFA87D98F8
000073dfa87d98c8  cmp dword ptr [r15+0x318], 0x00
000073dfa87d98d0  jz 0x000073DFA87DEAE0
000073dfa87d98d6  nop [rax+rax*1], ax
000073dfa87d98df  nop [rax+rax*1], eax
000073dfa87d98e7  mov eax, 0x4106D0
000073dfa87d98ec  mov [r15+0x100], rax
000073dfa87d98f3  jmp 0x000073DFA85FE110
000073dfa87d98f8  cmp dword ptr [r15+0x318], 0x00
000073dfa87d9900  jz 0x000073DFA87D89C0
000073dfa87d9906  nop [rax+rax*1], ax
000073dfa87d990f  nop [rax+rax*1], eax
000073dfa87d9917  mov eax, 0x410504
000073dfa87d991c  mov [r15+0x100], rax
000073dfa87d9923  jmp 0x000073DFA85FE110
000073dfa87d9928  int3
000073dfa87d9929  call 0x000073DFA860A4B0
000073dfa87d992e  jmp 0x000073DFA87D8A08
000073dfa87d9933  call 0x000073DFA8609240
000073dfa87d9938  jmp 0x000073DFA87D8A12
000073dfa87d993d  call 0x000073DFA860A4B0
000073dfa87d9942  jmp 0x000073DFA87D8A6F
000073dfa87d9947  call 0x000073DFA8609240
000073dfa87d994c  jmp 0x000073DFA87D8A79
000073dfa87d9951  call 0x000073DFA860A4B0
000073dfa87d9956  jmp 0x000073DFA87D8ABD
000073dfa87d995b  call 0x000073DFA8609240
000073dfa87d9960  jmp 0x000073DFA87D8AC7
000073dfa87d9965  call 0x000073DFA86B47C0
000073dfa87d996a  jmp 0x000073DFA87D8B06
000073dfa87d996f  call 0x000073DFA860B720
000073dfa87d9974  jmp 0x000073DFA87D8B1A
000073dfa87d9979  call 0x000073DFA86BFC30
000073dfa87d997e  jmp 0x000073DFA87D8B38
000073dfa87d9983  call 0x000073DFA86BE9C0
000073dfa87d9988  jmp 0x000073DFA87D8B42
000073dfa87d998d  call 0x000073DFA86BD750
000073dfa87d9992  jmp 0x000073DFA87D8B4C
000073dfa87d9997  sub rsp, 0x08
000073dfa87d999b  push rax
000073dfa87d999c  push rcx
000073dfa87d999d  push rdx
000073dfa87d999e  push rdi
000073dfa87d999f  push rsi
000073dfa87d99a0  push r8
000073dfa87d99a2  push r9
000073dfa87d99a4  push r10
000073dfa87d99a6  push r11
000073dfa87d99a8  sub rsp, 0xF0
000073dfa87d99af  vmovaps [rsp], xmm0
000073dfa87d99b4  vmovaps [rsp+0x10], xmm1
000073dfa87d99ba  vmovaps [rsp+0x20], xmm2
000073dfa87d99c0  vmovaps [rsp+0x30], xmm3
000073dfa87d99c6  vmovaps [rsp+0x40], xmm4
000073dfa87d99cc  vmovaps [rsp+0x50], xmm5
000073dfa87d99d2  vmovaps [rsp+0x60], xmm6
000073dfa87d99d8  vmovaps [rsp+0x70], xmm7
000073dfa87d99de  vmovaps [rsp+0x80], xmm9
000073dfa87d99e7  vmovaps [rsp+0x90], xmm10
000073dfa87d99f0  vmovaps [rsp+0xA0], xmm11
000073dfa87d99f9  vmovaps [rsp+0xB0], xmm12
000073dfa87d9a02  vmovaps [rsp+0xC0], xmm13
000073dfa87d9a0b  vmovaps [rsp+0xD0], xmm14
000073dfa87d9a14  vmovaps [rsp+0xE0], xmm15
000073dfa87d9a1d  sub rsp, 0x30
000073dfa87d9a21  movaps [rsp], xmm8
000073dfa87d9a26  movaps [rsp+0x10], xmm12
000073dfa87d9a2c  movaps [rsp+0x20], xmm15
000073dfa87d9a32  lea rdi, [rsp]
000073dfa87d9a36  mov esi, 0x00
000073dfa87d9a3b  mov rax, 0x593AA1DA4530
000073dfa87d9a45  call rax
000073dfa87d9a47  movaps xmm8, [rsp]
000073dfa87d9a4c  add rsp, 0x30
000073dfa87d9a50  vmovaps xmm0, [rsp]
000073dfa87d9a55  vmovaps xmm1, [rsp+0x10]
000073dfa87d9a5b  vmovaps xmm2, [rsp+0x20]
000073dfa87d9a61  vmovaps xmm3, [rsp+0x30]
000073dfa87d9a67  vmovaps xmm4, [rsp+0x40]
000073dfa87d9a6d  vmovaps xmm5, [rsp+0x50]
000073dfa87d9a73  vmovaps xmm6, [rsp+0x60]
000073dfa87d9a79  vmovaps xmm7, [rsp+0x70]
000073dfa87d9a7f  vmovaps xmm9, [rsp+0x80]
000073dfa87d9a88  vmovaps xmm10, [rsp+0x90]
000073dfa87d9a91  vmovaps xmm11, [rsp+0xA0]
000073dfa87d9a9a  vmovaps xmm12, [rsp+0xB0]
000073dfa87d9aa3  vmovaps xmm13, [rsp+0xC0]
000073dfa87d9aac  vmovaps xmm14, [rsp+0xD0]
000073dfa87d9ab5  vmovaps xmm15, [rsp+0xE0]
000073dfa87d9abe  add rsp, 0xF0
000073dfa87d9ac5  pop r11
000073dfa87d9ac7  pop r10
000073dfa87d9ac9  pop r9
000073dfa87d9acb  pop r8
000073dfa87d9acd  pop rsi
000073dfa87d9ace  pop rdi
000073dfa87d9acf  pop rdx
000073dfa87d9ad0  pop rcx
000073dfa87d9ad1  pop rax
000073dfa87d9ad2  add rsp, 0x08
000073dfa87d9ad6  jmp 0x000073DFA87D8B7A
000073dfa87d9adb  sub rsp, 0x08
000073dfa87d9adf  push rax
000073dfa87d9ae0  push rcx
000073dfa87d9ae1  push rdx
000073dfa87d9ae2  push rdi
000073dfa87d9ae3  push rsi
000073dfa87d9ae4  push r8
000073dfa87d9ae6  push r9
000073dfa87d9ae8  push r10
000073dfa87d9aea  push r11
000073dfa87d9aec  sub rsp, 0xF0
000073dfa87d9af3  vmovaps [rsp], xmm0
000073dfa87d9af8  vmovaps [rsp+0x10], xmm1
000073dfa87d9afe  vmovaps [rsp+0x20], xmm2
000073dfa87d9b04  vmovaps [rsp+0x30], xmm3
000073dfa87d9b0a  vmovaps [rsp+0x40], xmm4
000073dfa87d9b10  vmovaps [rsp+0x50], xmm5
000073dfa87d9b16  vmovaps [rsp+0x60], xmm6
000073dfa87d9b1c  vmovaps [rsp+0x70], xmm8
000073dfa87d9b22  vmovaps [rsp+0x80], xmm9
000073dfa87d9b2b  vmovaps [rsp+0x90], xmm10
000073dfa87d9b34  vmovaps [rsp+0xA0], xmm11
000073dfa87d9b3d  vmovaps [rsp+0xB0], xmm12
000073dfa87d9b46  vmovaps [rsp+0xC0], xmm13
000073dfa87d9b4f  vmovaps [rsp+0xD0], xmm14
000073dfa87d9b58  vmovaps [rsp+0xE0], xmm15
000073dfa87d9b61  sub rsp, 0x30
000073dfa87d9b65  movaps [rsp], xmm7
000073dfa87d9b69  movaps [rsp+0x10], xmm9
000073dfa87d9b6f  movaps [rsp+0x20], xmm15
000073dfa87d9b75  lea rdi, [rsp]
000073dfa87d9b79  mov esi, 0x00
000073dfa87d9b7e  mov rax, 0x593AA1DA4530
000073dfa87d9b88  call rax
000073dfa87d9b8a  movaps xmm7, [rsp]
000073dfa87d9b8e  add rsp, 0x30
000073dfa87d9b92  vmovaps xmm0, [rsp]
000073dfa87d9b97  vmovaps xmm1, [rsp+0x10]
000073dfa87d9b9d  vmovaps xmm2, [rsp+0x20]
000073dfa87d9ba3  vmovaps xmm3, [rsp+0x30]
000073dfa87d9ba9  vmovaps xmm4, [rsp+0x40]
000073dfa87d9baf  vmovaps xmm5, [rsp+0x50]
000073dfa87d9bb5  vmovaps xmm6, [rsp+0x60]
000073dfa87d9bbb  vmovaps xmm8, [rsp+0x70]
000073dfa87d9bc1  vmovaps xmm9, [rsp+0x80]
000073dfa87d9bca  vmovaps xmm10, [rsp+0x90]
000073dfa87d9bd3  vmovaps xmm11, [rsp+0xA0]
000073dfa87d9bdc  vmovaps xmm12, [rsp+0xB0]
000073dfa87d9be5  vmovaps xmm13, [rsp+0xC0]
000073dfa87d9bee  vmovaps xmm14, [rsp+0xD0]
000073dfa87d9bf7  vmovaps xmm15, [rsp+0xE0]
000073dfa87d9c00  add rsp, 0xF0
000073dfa87d9c07  pop r11
000073dfa87d9c09  pop r10
000073dfa87d9c0b  pop r9
000073dfa87d9c0d  pop r8
000073dfa87d9c0f  pop rsi
000073dfa87d9c10  pop rdi
000073dfa87d9c11  pop rdx
000073dfa87d9c12  pop rcx
000073dfa87d9c13  pop rax
000073dfa87d9c14  add rsp, 0x08
000073dfa87d9c18  jmp 0x000073DFA87D8BA8
000073dfa87d9c1d  sub rsp, 0x08
000073dfa87d9c21  push rax
000073dfa87d9c22  push rcx
000073dfa87d9c23  push rdx
000073dfa87d9c24  push rdi
000073dfa87d9c25  push rsi
000073dfa87d9c26  push r8
000073dfa87d9c28  push r9
000073dfa87d9c2a  push r10
000073dfa87d9c2c  push r11
000073dfa87d9c2e  sub rsp, 0xF0
000073dfa87d9c35  vmovaps [rsp], xmm0
000073dfa87d9c3a  vmovaps [rsp+0x10], xmm1
000073dfa87d9c40  vmovaps [rsp+0x20], xmm2
000073dfa87d9c46  vmovaps [rsp+0x30], xmm3
000073dfa87d9c4c  vmovaps [rsp+0x40], xmm4
000073dfa87d9c52  vmovaps [rsp+0x50], xmm5
000073dfa87d9c58  vmovaps [rsp+0x60], xmm6
000073dfa87d9c5e  vmovaps [rsp+0x70], xmm7
000073dfa87d9c64  vmovaps [rsp+0x80], xmm8
000073dfa87d9c6d  vmovaps [rsp+0x90], xmm10
000073dfa87d9c76  vmovaps [rsp+0xA0], xmm11
000073dfa87d9c7f  vmovaps [rsp+0xB0], xmm12
000073dfa87d9c88  vmovaps [rsp+0xC0], xmm13
000073dfa87d9c91  vmovaps [rsp+0xD0], xmm14
000073dfa87d9c9a  vmovaps [rsp+0xE0], xmm15
000073dfa87d9ca3  sub rsp, 0x30
000073dfa87d9ca7  movaps [rsp], xmm9
000073dfa87d9cac  movaps [rsp+0x10], xmm12
000073dfa87d9cb2  movaps [rsp+0x20], xmm10
000073dfa87d9cb8  lea rdi, [rsp]
000073dfa87d9cbc  mov esi, 0x00
000073dfa87d9cc1  mov rax, 0x593AA1DA4530
000073dfa87d9ccb  call rax
000073dfa87d9ccd  movaps xmm9, [rsp]
000073dfa87d9cd2  add rsp, 0x30
000073dfa87d9cd6  vmovaps xmm0, [rsp]
000073dfa87d9cdb  vmovaps xmm1, [rsp+0x10]
000073dfa87d9ce1  vmovaps xmm2, [rsp+0x20]
000073dfa87d9ce7  vmovaps xmm3, [rsp+0x30]
000073dfa87d9ced  vmovaps xmm4, [rsp+0x40]
000073dfa87d9cf3  vmovaps xmm5, [rsp+0x50]
000073dfa87d9cf9  vmovaps xmm6, [rsp+0x60]
000073dfa87d9cff  vmovaps xmm7, [rsp+0x70]
000073dfa87d9d05  vmovaps xmm8, [rsp+0x80]
000073dfa87d9d0e  vmovaps xmm10, [rsp+0x90]
000073dfa87d9d17  vmovaps xmm11, [rsp+0xA0]
000073dfa87d9d20  vmovaps xmm12, [rsp+0xB0]
000073dfa87d9d29  vmovaps xmm13, [rsp+0xC0]
000073dfa87d9d32  vmovaps xmm14, [rsp+0xD0]
000073dfa87d9d3b  vmovaps xmm15, [rsp+0xE0]
000073dfa87d9d44  add rsp, 0xF0
000073dfa87d9d4b  pop r11
000073dfa87d9d4d  pop r10
000073dfa87d9d4f  pop r9
000073dfa87d9d51  pop r8
000073dfa87d9d53  pop rsi
000073dfa87d9d54  pop rdi
000073dfa87d9d55  pop rdx
000073dfa87d9d56  pop rcx
000073dfa87d9d57  pop rax
000073dfa87d9d58  add rsp, 0x08
000073dfa87d9d5c  jmp 0x000073DFA87D8BCC
000073dfa87d9d61  sub rsp, 0x08
000073dfa87d9d65  push rax
000073dfa87d9d66  push rcx
000073dfa87d9d67  push rdx
000073dfa87d9d68  push rdi
000073dfa87d9d69  push rsi
000073dfa87d9d6a  push r8
000073dfa87d9d6c  push r9
000073dfa87d9d6e  push r10
000073dfa87d9d70  push r11
000073dfa87d9d72  sub rsp, 0xF0
000073dfa87d9d79  vmovaps [rsp], xmm0
000073dfa87d9d7e  vmovaps [rsp+0x10], xmm1
000073dfa87d9d84  vmovaps [rsp+0x20], xmm2
000073dfa87d9d8a  vmovaps [rsp+0x30], xmm3
000073dfa87d9d90  vmovaps [rsp+0x40], xmm4
000073dfa87d9d96  vmovaps [rsp+0x50], xmm5
000073dfa87d9d9c  vmovaps [rsp+0x60], xmm6
000073dfa87d9da2  vmovaps [rsp+0x70], xmm7
000073dfa87d9da8  vmovaps [rsp+0x80], xmm8
000073dfa87d9db1  vmovaps [rsp+0x90], xmm9
000073dfa87d9dba  vmovaps [rsp+0xA0], xmm11
000073dfa87d9dc3  vmovaps [rsp+0xB0], xmm12
000073dfa87d9dcc  vmovaps [rsp+0xC0], xmm13
000073dfa87d9dd5  vmovaps [rsp+0xD0], xmm14
000073dfa87d9dde  vmovaps [rsp+0xE0], xmm15
000073dfa87d9de7  sub rsp, 0x30
000073dfa87d9deb  movaps [rsp], xmm10
000073dfa87d9df0  movaps [rsp+0x10], xmm12
000073dfa87d9df6  movaps [rsp+0x20], xmm11
000073dfa87d9dfc  lea rdi, [rsp]
000073dfa87d9e00  mov esi, 0x00
000073dfa87d9e05  mov rax, 0x593AA1DA4530
000073dfa87d9e0f  call rax
000073dfa87d9e11  movaps xmm10, [rsp]
000073dfa87d9e16  add rsp, 0x30
000073dfa87d9e1a  vmovaps xmm0, [rsp]
000073dfa87d9e1f  vmovaps xmm1, [rsp+0x10]
000073dfa87d9e25  vmovaps xmm2, [rsp+0x20]
000073dfa87d9e2b  vmovaps xmm3, [rsp+0x30]
000073dfa87d9e31  vmovaps xmm4, [rsp+0x40]
000073dfa87d9e37  vmovaps xmm5, [rsp+0x50]
000073dfa87d9e3d  vmovaps xmm6, [rsp+0x60]
000073dfa87d9e43  vmovaps xmm7, [rsp+0x70]
000073dfa87d9e49  vmovaps xmm8, [rsp+0x80]
000073dfa87d9e52  vmovaps xmm9, [rsp+0x90]
000073dfa87d9e5b  vmovaps xmm11, [rsp+0xA0]
000073dfa87d9e64  vmovaps xmm12, [rsp+0xB0]
000073dfa87d9e6d  vmovaps xmm13, [rsp+0xC0]
000073dfa87d9e76  vmovaps xmm14, [rsp+0xD0]
000073dfa87d9e7f  vmovaps xmm15, [rsp+0xE0]
000073dfa87d9e88  add rsp, 0xF0
000073dfa87d9e8f  pop r11
000073dfa87d9e91  pop r10
000073dfa87d9e93  pop r9
000073dfa87d9e95  pop r8
000073dfa87d9e97  pop rsi
000073dfa87d9e98  pop rdi
000073dfa87d9e99  pop rdx
000073dfa87d9e9a  pop rcx
000073dfa87d9e9b  pop rax
000073dfa87d9e9c  add rsp, 0x08
000073dfa87d9ea0  jmp 0x000073DFA87D8BE6
000073dfa87d9ea5  sub rsp, 0x08
000073dfa87d9ea9  push rax
000073dfa87d9eaa  push rcx
000073dfa87d9eab  push rdx
000073dfa87d9eac  push rdi
000073dfa87d9ead  push rsi
000073dfa87d9eae  push r8
000073dfa87d9eb0  push r9
000073dfa87d9eb2  push r10
000073dfa87d9eb4  push r11
000073dfa87d9eb6  sub rsp, 0xF0
000073dfa87d9ebd  vmovaps [rsp], xmm0
000073dfa87d9ec2  vmovaps [rsp+0x10], xmm1
000073dfa87d9ec8  vmovaps [rsp+0x20], xmm2
000073dfa87d9ece  vmovaps [rsp+0x30], xmm3
000073dfa87d9ed4  vmovaps [rsp+0x40], xmm4
000073dfa87d9eda  vmovaps [rsp+0x50], xmm5
000073dfa87d9ee0  vmovaps [rsp+0x60], xmm7
000073dfa87d9ee6  vmovaps [rsp+0x70], xmm8
000073dfa87d9eec  vmovaps [rsp+0x80], xmm9
000073dfa87d9ef5  vmovaps [rsp+0x90], xmm10
000073dfa87d9efe  vmovaps [rsp+0xA0], xmm11
000073dfa87d9f07  vmovaps [rsp+0xB0], xmm12
000073dfa87d9f10  vmovaps [rsp+0xC0], xmm13
000073dfa87d9f19  vmovaps [rsp+0xD0], xmm14
000073dfa87d9f22  vmovaps [rsp+0xE0], xmm15
000073dfa87d9f2b  sub rsp, 0x30
000073dfa87d9f2f  movaps [rsp], xmm6
000073dfa87d9f33  movaps [rsp+0x10], xmm12
000073dfa87d9f39  movaps [rsp+0x20], xmm11
000073dfa87d9f3f  lea rdi, [rsp]
000073dfa87d9f43  mov esi, 0x00
000073dfa87d9f48  mov rax, 0x593AA1DA4530
000073dfa87d9f52  call rax
000073dfa87d9f54  movaps xmm6, [rsp]
000073dfa87d9f58  add rsp, 0x30
000073dfa87d9f5c  vmovaps xmm0, [rsp]
000073dfa87d9f61  vmovaps xmm1, [rsp+0x10]
000073dfa87d9f67  vmovaps xmm2, [rsp+0x20]
000073dfa87d9f6d  vmovaps xmm3, [rsp+0x30]
000073dfa87d9f73  vmovaps xmm4, [rsp+0x40]
000073dfa87d9f79  vmovaps xmm5, [rsp+0x50]
000073dfa87d9f7f  vmovaps xmm7, [rsp+0x60]
000073dfa87d9f85  vmovaps xmm8, [rsp+0x70]
000073dfa87d9f8b  vmovaps xmm9, [rsp+0x80]
000073dfa87d9f94  vmovaps xmm10, [rsp+0x90]
000073dfa87d9f9d  vmovaps xmm11, [rsp+0xA0]
000073dfa87d9fa6  vmovaps xmm12, [rsp+0xB0]
000073dfa87d9faf  vmovaps xmm13, [rsp+0xC0]
000073dfa87d9fb8  vmovaps xmm14, [rsp+0xD0]
000073dfa87d9fc1  vmovaps xmm15, [rsp+0xE0]
000073dfa87d9fca  add rsp, 0xF0
000073dfa87d9fd1  pop r11
000073dfa87d9fd3  pop r10
000073dfa87d9fd5  pop r9
000073dfa87d9fd7  pop r8
000073dfa87d9fd9  pop rsi
000073dfa87d9fda  pop rdi
000073dfa87d9fdb  pop rdx
000073dfa87d9fdc  pop rcx
000073dfa87d9fdd  pop rax
000073dfa87d9fde  add rsp, 0x08
000073dfa87d9fe2  jmp 0x000073DFA87D8C07
000073dfa87d9fe7  sub rsp, 0x08
000073dfa87d9feb  push rax
000073dfa87d9fec  push rcx
000073dfa87d9fed  push rdx
000073dfa87d9fee  push rdi
000073dfa87d9fef  push rsi
000073dfa87d9ff0  push r8
000073dfa87d9ff2  push r9
000073dfa87d9ff4  push r10
000073dfa87d9ff6  push r11
000073dfa87d9ff8  sub rsp, 0xF0
000073dfa87d9fff  vmovaps [rsp], xmm0
000073dfa87da004  vmovaps [rsp+0x10], xmm1
000073dfa87da00a  vmovaps [rsp+0x20], xmm2
000073dfa87da010  vmovaps [rsp+0x30], xmm4
000073dfa87da016  vmovaps [rsp+0x40], xmm5
000073dfa87da01c  vmovaps [rsp+0x50], xmm6
000073dfa87da022  vmovaps [rsp+0x60], xmm7
000073dfa87da028  vmovaps [rsp+0x70], xmm8
000073dfa87da02e  vmovaps [rsp+0x80], xmm9
000073dfa87da037  vmovaps [rsp+0x90], xmm10
000073dfa87da040  vmovaps [rsp+0xA0], xmm11
000073dfa87da049  vmovaps [rsp+0xB0], xmm12
000073dfa87da052  vmovaps [rsp+0xC0], xmm13
000073dfa87da05b  vmovaps [rsp+0xD0], xmm14
000073dfa87da064  vmovaps [rsp+0xE0], xmm15
000073dfa87da06d  sub rsp, 0x30
000073dfa87da071  movaps [rsp], xmm3
000073dfa87da075  movaps [rsp+0x10], xmm5
000073dfa87da07a  movaps [rsp+0x20], xmm4
000073dfa87da07f  lea rdi, [rsp]
000073dfa87da083  mov esi, 0x00
000073dfa87da088  mov rax, 0x593AA1DA4530
000073dfa87da092  call rax
000073dfa87da094  movaps xmm3, [rsp]
000073dfa87da098  add rsp, 0x30
000073dfa87da09c  vmovaps xmm0, [rsp]
000073dfa87da0a1  vmovaps xmm1, [rsp+0x10]
000073dfa87da0a7  vmovaps xmm2, [rsp+0x20]
000073dfa87da0ad  vmovaps xmm4, [rsp+0x30]
000073dfa87da0b3  vmovaps xmm5, [rsp+0x40]
000073dfa87da0b9  vmovaps xmm6, [rsp+0x50]
000073dfa87da0bf  vmovaps xmm7, [rsp+0x60]
000073dfa87da0c5  vmovaps xmm8, [rsp+0x70]
000073dfa87da0cb  vmovaps xmm9, [rsp+0x80]
000073dfa87da0d4  vmovaps xmm10, [rsp+0x90]
000073dfa87da0dd  vmovaps xmm11, [rsp+0xA0]
000073dfa87da0e6  vmovaps xmm12, [rsp+0xB0]
000073dfa87da0ef  vmovaps xmm13, [rsp+0xC0]
000073dfa87da0f8  vmovaps xmm14, [rsp+0xD0]
000073dfa87da101  vmovaps xmm15, [rsp+0xE0]
000073dfa87da10a  add rsp, 0xF0
000073dfa87da111  pop r11
000073dfa87da113  pop r10
000073dfa87da115  pop r9
000073dfa87da117  pop r8
000073dfa87da119  pop rsi
000073dfa87da11a  pop rdi
000073dfa87da11b  pop rdx
000073dfa87da11c  pop rcx
000073dfa87da11d  pop rax
000073dfa87da11e  add rsp, 0x08
000073dfa87da122  jmp 0x000073DFA87D8C68
000073dfa87da127  sub rsp, 0x08
000073dfa87da12b  push rax
000073dfa87da12c  push rcx
000073dfa87da12d  push rdx
000073dfa87da12e  push rdi
000073dfa87da12f  push rsi
000073dfa87da130  push r8
000073dfa87da132  push r9
000073dfa87da134  push r10
000073dfa87da136  push r11
000073dfa87da138  sub rsp, 0xF0
000073dfa87da13f  vmovaps [rsp], xmm0
000073dfa87da144  vmovaps [rsp+0x10], xmm1
000073dfa87da14a  vmovaps [rsp+0x20], xmm2
000073dfa87da150  vmovaps [rsp+0x30], xmm3
000073dfa87da156  vmovaps [rsp+0x40], xmm4
000073dfa87da15c  vmovaps [rsp+0x50], xmm6
000073dfa87da162  vmovaps [rsp+0x60], xmm7
000073dfa87da168  vmovaps [rsp+0x70], xmm8
000073dfa87da16e  vmovaps [rsp+0x80], xmm9
000073dfa87da177  vmovaps [rsp+0x90], xmm10
000073dfa87da180  vmovaps [rsp+0xA0], xmm11
000073dfa87da189  vmovaps [rsp+0xB0], xmm12
000073dfa87da192  vmovaps [rsp+0xC0], xmm13
000073dfa87da19b  vmovaps [rsp+0xD0], xmm14
000073dfa87da1a4  vmovaps [rsp+0xE0], xmm15
000073dfa87da1ad  sub rsp, 0x30
000073dfa87da1b1  movaps [rsp], xmm5
000073dfa87da1b5  movaps [rsp+0x10], xmm8
000073dfa87da1bb  movaps [rsp+0x20], xmm15
000073dfa87da1c1  lea rdi, [rsp]
000073dfa87da1c5  mov esi, 0x00
000073dfa87da1ca  mov rax, 0x593AA1DA4530
000073dfa87da1d4  call rax
000073dfa87da1d6  movaps xmm5, [rsp]
000073dfa87da1da  add rsp, 0x30
000073dfa87da1de  vmovaps xmm0, [rsp]
000073dfa87da1e3  vmovaps xmm1, [rsp+0x10]
000073dfa87da1e9  vmovaps xmm2, [rsp+0x20]
000073dfa87da1ef  vmovaps xmm3, [rsp+0x30]
000073dfa87da1f5  vmovaps xmm4, [rsp+0x40]
000073dfa87da1fb  vmovaps xmm6, [rsp+0x50]
000073dfa87da201  vmovaps xmm7, [rsp+0x60]
000073dfa87da207  vmovaps xmm8, [rsp+0x70]
000073dfa87da20d  vmovaps xmm9, [rsp+0x80]
000073dfa87da216  vmovaps xmm10, [rsp+0x90]
000073dfa87da21f  vmovaps xmm11, [rsp+0xA0]
000073dfa87da228  vmovaps xmm12, [rsp+0xB0]
000073dfa87da231  vmovaps xmm13, [rsp+0xC0]
000073dfa87da23a  vmovaps xmm14, [rsp+0xD0]
000073dfa87da243  vmovaps xmm15, [rsp+0xE0]
000073dfa87da24c  add rsp, 0xF0
000073dfa87da253  pop r11
000073dfa87da255  pop r10
000073dfa87da257  pop r9
000073dfa87da259  pop r8
000073dfa87da25b  pop rsi
000073dfa87da25c  pop rdi
000073dfa87da25d  pop rdx
000073dfa87da25e  pop rcx
000073dfa87da25f  pop rax
000073dfa87da260  add rsp, 0x08
000073dfa87da264  jmp 0x000073DFA87D8CA0
000073dfa87da269  sub rsp, 0x08
000073dfa87da26d  push rax
000073dfa87da26e  push rcx
000073dfa87da26f  push rdx
000073dfa87da270  push rdi
000073dfa87da271  push rsi
000073dfa87da272  push r8
000073dfa87da274  push r9
000073dfa87da276  push r10
000073dfa87da278  push r11
000073dfa87da27a  sub rsp, 0xF0
000073dfa87da281  vmovaps [rsp], xmm0
000073dfa87da286  vmovaps [rsp+0x10], xmm1
000073dfa87da28c  vmovaps [rsp+0x20], xmm2
000073dfa87da292  vmovaps [rsp+0x30], xmm3
000073dfa87da298  vmovaps [rsp+0x40], xmm5
000073dfa87da29e  vmovaps [rsp+0x50], xmm6
000073dfa87da2a4  vmovaps [rsp+0x60], xmm7
000073dfa87da2aa  vmovaps [rsp+0x70], xmm8
000073dfa87da2b0  vmovaps [rsp+0x80], xmm9
000073dfa87da2b9  vmovaps [rsp+0x90], xmm10
000073dfa87da2c2  vmovaps [rsp+0xA0], xmm11
000073dfa87da2cb  vmovaps [rsp+0xB0], xmm12
000073dfa87da2d4  vmovaps [rsp+0xC0], xmm13
000073dfa87da2dd  vmovaps [rsp+0xD0], xmm14
000073dfa87da2e6  vmovaps [rsp+0xE0], xmm15
000073dfa87da2ef  sub rsp, 0x30
000073dfa87da2f3  movaps [rsp], xmm4
000073dfa87da2f7  movaps [rsp+0x10], xmm9
000073dfa87da2fd  movaps [rsp+0x20], xmm8
000073dfa87da303  lea rdi, [rsp]
000073dfa87da307  mov esi, 0x00
000073dfa87da30c  mov rax, 0x593AA1DA4530
000073dfa87da316  call rax
000073dfa87da318  movaps xmm4, [rsp]
000073dfa87da31c  add rsp, 0x30
000073dfa87da320  vmovaps xmm0, [rsp]
000073dfa87da325  vmovaps xmm1, [rsp+0x10]
000073dfa87da32b  vmovaps xmm2, [rsp+0x20]
000073dfa87da331  vmovaps xmm3, [rsp+0x30]
000073dfa87da337  vmovaps xmm5, [rsp+0x40]
000073dfa87da33d  vmovaps xmm6, [rsp+0x50]
000073dfa87da343  vmovaps xmm7, [rsp+0x60]
000073dfa87da349  vmovaps xmm8, [rsp+0x70]
000073dfa87da34f  vmovaps xmm9, [rsp+0x80]
000073dfa87da358  vmovaps xmm10, [rsp+0x90]
000073dfa87da361  vmovaps xmm11, [rsp+0xA0]
000073dfa87da36a  vmovaps xmm12, [rsp+0xB0]
000073dfa87da373  vmovaps xmm13, [rsp+0xC0]
000073dfa87da37c  vmovaps xmm14, [rsp+0xD0]
000073dfa87da385  vmovaps xmm15, [rsp+0xE0]
000073dfa87da38e  add rsp, 0xF0
000073dfa87da395  pop r11
000073dfa87da397  pop r10
000073dfa87da399  pop r9
000073dfa87da39b  pop r8
000073dfa87da39d  pop rsi
000073dfa87da39e  pop rdi
000073dfa87da39f  pop rdx
000073dfa87da3a0  pop rcx
000073dfa87da3a1  pop rax
000073dfa87da3a2  add rsp, 0x08
000073dfa87da3a6  jmp 0x000073DFA87D8CC1
000073dfa87da3ab  sub rsp, 0x08
000073dfa87da3af  push rax
000073dfa87da3b0  push rcx
000073dfa87da3b1  push rdx
000073dfa87da3b2  push rdi
000073dfa87da3b3  push rsi
000073dfa87da3b4  push r8
000073dfa87da3b6  push r9
000073dfa87da3b8  push r10
000073dfa87da3ba  push r11
000073dfa87da3bc  sub rsp, 0xF0
000073dfa87da3c3  vmovaps [rsp], xmm0
000073dfa87da3c8  vmovaps [rsp+0x10], xmm1
000073dfa87da3ce  vmovaps [rsp+0x20], xmm2
000073dfa87da3d4  vmovaps [rsp+0x30], xmm3
000073dfa87da3da  vmovaps [rsp+0x40], xmm4
000073dfa87da3e0  vmovaps [rsp+0x50], xmm5
000073dfa87da3e6  vmovaps [rsp+0x60], xmm6
000073dfa87da3ec  vmovaps [rsp+0x70], xmm7
000073dfa87da3f2  vmovaps [rsp+0x80], xmm8
000073dfa87da3fb  vmovaps [rsp+0x90], xmm10
000073dfa87da404  vmovaps [rsp+0xA0], xmm11
000073dfa87da40d  vmovaps [rsp+0xB0], xmm12
000073dfa87da416  vmovaps [rsp+0xC0], xmm13
000073dfa87da41f  vmovaps [rsp+0xD0], xmm14
000073dfa87da428  vmovaps [rsp+0xE0], xmm15
000073dfa87da431  sub rsp, 0x30
000073dfa87da435  movaps [rsp], xmm9
000073dfa87da43a  movaps [rsp+0x10], xmm10
000073dfa87da440  movaps [rsp+0x20], xmm8
000073dfa87da446  lea rdi, [rsp]
000073dfa87da44a  mov esi, 0x00
000073dfa87da44f  mov rax, 0x593AA1DA4530
000073dfa87da459  call rax
000073dfa87da45b  movaps xmm9, [rsp]
000073dfa87da460  add rsp, 0x30
000073dfa87da464  vmovaps xmm0, [rsp]
000073dfa87da469  vmovaps xmm1, [rsp+0x10]
000073dfa87da46f  vmovaps xmm2, [rsp+0x20]
000073dfa87da475  vmovaps xmm3, [rsp+0x30]
000073dfa87da47b  vmovaps xmm4, [rsp+0x40]
000073dfa87da481  vmovaps xmm5, [rsp+0x50]
000073dfa87da487  vmovaps xmm6, [rsp+0x60]
000073dfa87da48d  vmovaps xmm7, [rsp+0x70]
000073dfa87da493  vmovaps xmm8, [rsp+0x80]
000073dfa87da49c  vmovaps xmm10, [rsp+0x90]
000073dfa87da4a5  vmovaps xmm11, [rsp+0xA0]
000073dfa87da4ae  vmovaps xmm12, [rsp+0xB0]
000073dfa87da4b7  vmovaps xmm13, [rsp+0xC0]
000073dfa87da4c0  vmovaps xmm14, [rsp+0xD0]
000073dfa87da4c9  vmovaps xmm15, [rsp+0xE0]
000073dfa87da4d2  add rsp, 0xF0
000073dfa87da4d9  pop r11
000073dfa87da4db  pop r10
000073dfa87da4dd  pop r9
000073dfa87da4df  pop r8
000073dfa87da4e1  pop rsi
000073dfa87da4e2  pop rdi
000073dfa87da4e3  pop rdx
000073dfa87da4e4  pop rcx
000073dfa87da4e5  pop rax
000073dfa87da4e6  add rsp, 0x08
000073dfa87da4ea  jmp 0x000073DFA87D8CDB
000073dfa87da4ef  call 0x000073DFA86D64F0
000073dfa87da4f4  jmp 0x000073DFA87D8DF5
000073dfa87da4f9  call 0x000073DFA86D64F0
000073dfa87da4fe  jmp 0x000073DFA87D8E0B
000073dfa87da503  sub rsp, 0x08
000073dfa87da507  push rax
000073dfa87da508  push rcx
000073dfa87da509  push rdx
000073dfa87da50a  push rdi
000073dfa87da50b  push rsi
000073dfa87da50c  push r8
000073dfa87da50e  push r9
000073dfa87da510  push r10
000073dfa87da512  push r11
000073dfa87da514  sub rsp, 0xF0
000073dfa87da51b  vmovaps [rsp], xmm0
000073dfa87da520  vmovaps [rsp+0x10], xmm2
000073dfa87da526  vmovaps [rsp+0x20], xmm3
000073dfa87da52c  vmovaps [rsp+0x30], xmm4
000073dfa87da532  vmovaps [rsp+0x40], xmm5
000073dfa87da538  vmovaps [rsp+0x50], xmm6
000073dfa87da53e  vmovaps [rsp+0x60], xmm7
000073dfa87da544  vmovaps [rsp+0x70], xmm8
000073dfa87da54a  vmovaps [rsp+0x80], xmm9
000073dfa87da553  vmovaps [rsp+0x90], xmm10
000073dfa87da55c  vmovaps [rsp+0xA0], xmm11
000073dfa87da565  vmovaps [rsp+0xB0], xmm12
000073dfa87da56e  vmovaps [rsp+0xC0], xmm13
000073dfa87da577  vmovaps [rsp+0xD0], xmm14
000073dfa87da580  vmovaps [rsp+0xE0], xmm15
000073dfa87da589  sub rsp, 0x30
000073dfa87da58d  movaps [rsp], xmm1
000073dfa87da591  movaps [rsp+0x10], xmm6
000073dfa87da596  movaps [rsp+0x20], xmm15
000073dfa87da59c  lea rdi, [rsp]
000073dfa87da5a0  mov esi, 0x00
000073dfa87da5a5  mov rax, 0x593AA1DA4530
000073dfa87da5af  call rax
000073dfa87da5b1  movaps xmm1, [rsp]
000073dfa87da5b5  add rsp, 0x30
000073dfa87da5b9  vmovaps xmm0, [rsp]
000073dfa87da5be  vmovaps xmm2, [rsp+0x10]
000073dfa87da5c4  vmovaps xmm3, [rsp+0x20]
000073dfa87da5ca  vmovaps xmm4, [rsp+0x30]
000073dfa87da5d0  vmovaps xmm5, [rsp+0x40]
000073dfa87da5d6  vmovaps xmm6, [rsp+0x50]
000073dfa87da5dc  vmovaps xmm7, [rsp+0x60]
000073dfa87da5e2  vmovaps xmm8, [rsp+0x70]
000073dfa87da5e8  vmovaps xmm9, [rsp+0x80]
000073dfa87da5f1  vmovaps xmm10, [rsp+0x90]
000073dfa87da5fa  vmovaps xmm11, [rsp+0xA0]
000073dfa87da603  vmovaps xmm12, [rsp+0xB0]
000073dfa87da60c  vmovaps xmm13, [rsp+0xC0]
000073dfa87da615  vmovaps xmm14, [rsp+0xD0]
000073dfa87da61e  vmovaps xmm15, [rsp+0xE0]
000073dfa87da627  add rsp, 0xF0
000073dfa87da62e  pop r11
000073dfa87da630  pop r10
000073dfa87da632  pop r9
000073dfa87da634  pop r8
000073dfa87da636  pop rsi
000073dfa87da637  pop rdi
000073dfa87da638  pop rdx
000073dfa87da639  pop rcx
000073dfa87da63a  pop rax
000073dfa87da63b  add rsp, 0x08
000073dfa87da63f  jmp 0x000073DFA87D8E48
000073dfa87da644  call 0x000073DFA86E5820
000073dfa87da649  jmp 0x000073DFA87D8E55
000073dfa87da64e  sub rsp, 0x08
000073dfa87da652  push rax
000073dfa87da653  push rcx
000073dfa87da654  push rdx
000073dfa87da655  push rdi
000073dfa87da656  push rsi
000073dfa87da657  push r8
000073dfa87da659  push r9
000073dfa87da65b  push r10
000073dfa87da65d  push r11
000073dfa87da65f  sub rsp, 0xF0
000073dfa87da666  vmovaps [rsp], xmm0
000073dfa87da66b  vmovaps [rsp+0x10], xmm1
000073dfa87da671  vmovaps [rsp+0x20], xmm2
000073dfa87da677  vmovaps [rsp+0x30], xmm3
000073dfa87da67d  vmovaps [rsp+0x40], xmm4
000073dfa87da683  vmovaps [rsp+0x50], xmm5
000073dfa87da689  vmovaps [rsp+0x60], xmm6
000073dfa87da68f  vmovaps [rsp+0x70], xmm7
000073dfa87da695  vmovaps [rsp+0x80], xmm8
000073dfa87da69e  vmovaps [rsp+0x90], xmm9
000073dfa87da6a7  vmovaps [rsp+0xA0], xmm10
000073dfa87da6b0  vmovaps [rsp+0xB0], xmm11
000073dfa87da6b9  vmovaps [rsp+0xC0], xmm12
000073dfa87da6c2  vmovaps [rsp+0xD0], xmm13
000073dfa87da6cb  vmovaps [rsp+0xE0], xmm15
000073dfa87da6d4  sub rsp, 0x30
000073dfa87da6d8  movaps [rsp], xmm14
000073dfa87da6dd  movaps [rsp+0x10], xmm4
000073dfa87da6e2  movaps [rsp+0x20], xmm3
000073dfa87da6e7  lea rdi, [rsp]
000073dfa87da6eb  mov esi, 0x00
000073dfa87da6f0  mov rax, 0x593AA1DA4530
000073dfa87da6fa  call rax
000073dfa87da6fc  movaps xmm14, [rsp]
000073dfa87da701  add rsp, 0x30
000073dfa87da705  vmovaps xmm0, [rsp]
000073dfa87da70a  vmovaps xmm1, [rsp+0x10]
000073dfa87da710  vmovaps xmm2, [rsp+0x20]
000073dfa87da716  vmovaps xmm3, [rsp+0x30]
000073dfa87da71c  vmovaps xmm4, [rsp+0x40]
000073dfa87da722  vmovaps xmm5, [rsp+0x50]
000073dfa87da728  vmovaps xmm6, [rsp+0x60]
000073dfa87da72e  vmovaps xmm7, [rsp+0x70]
000073dfa87da734  vmovaps xmm8, [rsp+0x80]
000073dfa87da73d  vmovaps xmm9, [rsp+0x90]
000073dfa87da746  vmovaps xmm10, [rsp+0xA0]
000073dfa87da74f  vmovaps xmm11, [rsp+0xB0]
000073dfa87da758  vmovaps xmm12, [rsp+0xC0]
000073dfa87da761  vmovaps xmm13, [rsp+0xD0]
000073dfa87da76a  vmovaps xmm15, [rsp+0xE0]
000073dfa87da773  add rsp, 0xF0
000073dfa87da77a  pop r11
000073dfa87da77c  pop r10
000073dfa87da77e  pop r9
000073dfa87da780  pop r8
000073dfa87da782  pop rsi
000073dfa87da783  pop rdi
000073dfa87da784  pop rdx
000073dfa87da785  pop rcx
000073dfa87da786  pop rax
000073dfa87da787  add rsp, 0x08
000073dfa87da78b  jmp 0x000073DFA87D8E6F
000073dfa87da790  sub rsp, 0x08
000073dfa87da794  push rax
000073dfa87da795  push rcx
000073dfa87da796  push rdx
000073dfa87da797  push rdi
000073dfa87da798  push rsi
000073dfa87da799  push r8
000073dfa87da79b  push r9
000073dfa87da79d  push r10
000073dfa87da79f  push r11
000073dfa87da7a1  sub rsp, 0xF0
000073dfa87da7a8  vmovaps [rsp], xmm0
000073dfa87da7ad  vmovaps [rsp+0x10], xmm1
000073dfa87da7b3  vmovaps [rsp+0x20], xmm2
000073dfa87da7b9  vmovaps [rsp+0x30], xmm3
000073dfa87da7bf  vmovaps [rsp+0x40], xmm4
000073dfa87da7c5  vmovaps [rsp+0x50], xmm5
000073dfa87da7cb  vmovaps [rsp+0x60], xmm7
000073dfa87da7d1  vmovaps [rsp+0x70], xmm8
000073dfa87da7d7  vmovaps [rsp+0x80], xmm9
000073dfa87da7e0  vmovaps [rsp+0x90], xmm10
000073dfa87da7e9  vmovaps [rsp+0xA0], xmm11
000073dfa87da7f2  vmovaps [rsp+0xB0], xmm12
000073dfa87da7fb  vmovaps [rsp+0xC0], xmm13
000073dfa87da804  vmovaps [rsp+0xD0], xmm14
000073dfa87da80d  vmovaps [rsp+0xE0], xmm15
000073dfa87da816  sub rsp, 0x30
000073dfa87da81a  movaps [rsp], xmm6
000073dfa87da81e  movaps [rsp+0x10], xmm9
000073dfa87da824  movaps [rsp+0x20], xmm7
000073dfa87da829  lea rdi, [rsp]
000073dfa87da82d  mov esi, 0x00
000073dfa87da832  mov rax, 0x593AA1DA4530
000073dfa87da83c  call rax
000073dfa87da83e  movaps xmm6, [rsp]
000073dfa87da842  add rsp, 0x30
000073dfa87da846  vmovaps xmm0, [rsp]
000073dfa87da84b  vmovaps xmm1, [rsp+0x10]
000073dfa87da851  vmovaps xmm2, [rsp+0x20]
000073dfa87da857  vmovaps xmm3, [rsp+0x30]
000073dfa87da85d  vmovaps xmm4, [rsp+0x40]
000073dfa87da863  vmovaps xmm5, [rsp+0x50]
000073dfa87da869  vmovaps xmm7, [rsp+0x60]
000073dfa87da86f  vmovaps xmm8, [rsp+0x70]
000073dfa87da875  vmovaps xmm9, [rsp+0x80]
000073dfa87da87e  vmovaps xmm10, [rsp+0x90]
000073dfa87da887  vmovaps xmm11, [rsp+0xA0]
000073dfa87da890  vmovaps xmm12, [rsp+0xB0]
000073dfa87da899  vmovaps xmm13, [rsp+0xC0]
000073dfa87da8a2  vmovaps xmm14, [rsp+0xD0]
000073dfa87da8ab  vmovaps xmm15, [rsp+0xE0]
000073dfa87da8b4  add rsp, 0xF0
000073dfa87da8bb  pop r11
000073dfa87da8bd  pop r10
000073dfa87da8bf  pop r9
000073dfa87da8c1  pop r8
000073dfa87da8c3  pop rsi
000073dfa87da8c4  pop rdi
000073dfa87da8c5  pop rdx
000073dfa87da8c6  pop rcx
000073dfa87da8c7  pop rax
000073dfa87da8c8  add rsp, 0x08
000073dfa87da8cc  jmp 0x000073DFA87D8E87
000073dfa87da8d1  sub rsp, 0x08
000073dfa87da8d5  push rax
000073dfa87da8d6  push rcx
000073dfa87da8d7  push rdx
000073dfa87da8d8  push rdi
000073dfa87da8d9  push rsi
000073dfa87da8da  push r8
000073dfa87da8dc  push r9
000073dfa87da8de  push r10
000073dfa87da8e0  push r11
000073dfa87da8e2  sub rsp, 0xF0
000073dfa87da8e9  vmovaps [rsp], xmm0
000073dfa87da8ee  vmovaps [rsp+0x10], xmm1
000073dfa87da8f4  vmovaps [rsp+0x20], xmm2
000073dfa87da8fa  vmovaps [rsp+0x30], xmm3
000073dfa87da900  vmovaps [rsp+0x40], xmm4
000073dfa87da906  vmovaps [rsp+0x50], xmm5
000073dfa87da90c  vmovaps [rsp+0x60], xmm6
000073dfa87da912  vmovaps [rsp+0x70], xmm8
000073dfa87da918  vmovaps [rsp+0x80], xmm9
000073dfa87da921  vmovaps [rsp+0x90], xmm10
000073dfa87da92a  vmovaps [rsp+0xA0], xmm11
000073dfa87da933  vmovaps [rsp+0xB0], xmm12
000073dfa87da93c  vmovaps [rsp+0xC0], xmm13
000073dfa87da945  vmovaps [rsp+0xD0], xmm14
000073dfa87da94e  vmovaps [rsp+0xE0], xmm15
000073dfa87da957  sub rsp, 0x30
000073dfa87da95b  movaps [rsp], xmm7
000073dfa87da95f  movaps [rsp+0x10], xmm4
000073dfa87da964  movaps [rsp+0x20], xmm9
000073dfa87da96a  lea rdi, [rsp]
000073dfa87da96e  mov esi, 0x00
000073dfa87da973  mov rax, 0x593AA1DA4530
000073dfa87da97d  call rax
000073dfa87da97f  movaps xmm7, [rsp]
000073dfa87da983  add rsp, 0x30
000073dfa87da987  vmovaps xmm0, [rsp]
000073dfa87da98c  vmovaps xmm1, [rsp+0x10]
000073dfa87da992  vmovaps xmm2, [rsp+0x20]
000073dfa87da998  vmovaps xmm3, [rsp+0x30]
000073dfa87da99e  vmovaps xmm4, [rsp+0x40]
000073dfa87da9a4  vmovaps xmm5, [rsp+0x50]
000073dfa87da9aa  vmovaps xmm6, [rsp+0x60]
000073dfa87da9b0  vmovaps xmm8, [rsp+0x70]
000073dfa87da9b6  vmovaps xmm9, [rsp+0x80]
000073dfa87da9bf  vmovaps xmm10, [rsp+0x90]
000073dfa87da9c8  vmovaps xmm11, [rsp+0xA0]
000073dfa87da9d1  vmovaps xmm12, [rsp+0xB0]
000073dfa87da9da  vmovaps xmm13, [rsp+0xC0]
000073dfa87da9e3  vmovaps xmm14, [rsp+0xD0]
000073dfa87da9ec  vmovaps xmm15, [rsp+0xE0]
000073dfa87da9f5  add rsp, 0xF0
000073dfa87da9fc  pop r11
000073dfa87da9fe  pop r10
000073dfa87daa00  pop r9
000073dfa87daa02  pop r8
000073dfa87daa04  pop rsi
000073dfa87daa05  pop rdi
000073dfa87daa06  pop rdx
000073dfa87daa07  pop rcx
000073dfa87daa08  pop rax
000073dfa87daa09  add rsp, 0x08
000073dfa87daa0d  jmp 0x000073DFA87D8EB4
000073dfa87daa12  sub rsp, 0x08
000073dfa87daa16  push rax
000073dfa87daa17  push rcx
000073dfa87daa18  push rdx
000073dfa87daa19  push rdi
000073dfa87daa1a  push rsi
000073dfa87daa1b  push r8
000073dfa87daa1d  push r9
000073dfa87daa1f  push r10
000073dfa87daa21  push r11
000073dfa87daa23  sub rsp, 0xF0
000073dfa87daa2a  vmovaps [rsp], xmm0
000073dfa87daa2f  vmovaps [rsp+0x10], xmm1
000073dfa87daa35  vmovaps [rsp+0x20], xmm2
000073dfa87daa3b  vmovaps [rsp+0x30], xmm3
000073dfa87daa41  vmovaps [rsp+0x40], xmm5
000073dfa87daa47  vmovaps [rsp+0x50], xmm6
000073dfa87daa4d  vmovaps [rsp+0x60], xmm7
000073dfa87daa53  vmovaps [rsp+0x70], xmm8
000073dfa87daa59  vmovaps [rsp+0x80], xmm9
000073dfa87daa62  vmovaps [rsp+0x90], xmm10
000073dfa87daa6b  vmovaps [rsp+0xA0], xmm11
000073dfa87daa74  vmovaps [rsp+0xB0], xmm12
000073dfa87daa7d  vmovaps [rsp+0xC0], xmm13
000073dfa87daa86  vmovaps [rsp+0xD0], xmm14
000073dfa87daa8f  vmovaps [rsp+0xE0], xmm15
000073dfa87daa98  sub rsp, 0x30
000073dfa87daa9c  movaps [rsp], xmm4
000073dfa87daaa0  movaps [rsp+0x10], xmm15
000073dfa87daaa6  movaps [rsp+0x20], xmm9
000073dfa87daaac  lea rdi, [rsp]
000073dfa87daab0  mov esi, 0x00
000073dfa87daab5  mov rax, 0x593AA1DA4530
000073dfa87daabf  call rax
000073dfa87daac1  movaps xmm4, [rsp]
000073dfa87daac5  add rsp, 0x30
000073dfa87daac9  vmovaps xmm0, [rsp]
000073dfa87daace  vmovaps xmm1, [rsp+0x10]
000073dfa87daad4  vmovaps xmm2, [rsp+0x20]
000073dfa87daada  vmovaps xmm3, [rsp+0x30]
000073dfa87daae0  vmovaps xmm5, [rsp+0x40]
000073dfa87daae6  vmovaps xmm6, [rsp+0x50]
000073dfa87daaec  vmovaps xmm7, [rsp+0x60]
000073dfa87daaf2  vmovaps xmm8, [rsp+0x70]
000073dfa87daaf8  vmovaps xmm9, [rsp+0x80]
000073dfa87dab01  vmovaps xmm10, [rsp+0x90]
000073dfa87dab0a  vmovaps xmm11, [rsp+0xA0]
000073dfa87dab13  vmovaps xmm12, [rsp+0xB0]
000073dfa87dab1c  vmovaps xmm13, [rsp+0xC0]
000073dfa87dab25  vmovaps xmm14, [rsp+0xD0]
000073dfa87dab2e  vmovaps xmm15, [rsp+0xE0]
000073dfa87dab37  add rsp, 0xF0
000073dfa87dab3e  pop r11
000073dfa87dab40  pop r10
000073dfa87dab42  pop r9
000073dfa87dab44  pop r8
000073dfa87dab46  pop rsi
000073dfa87dab47  pop rdi
000073dfa87dab48  pop rdx
000073dfa87dab49  pop rcx
000073dfa87dab4a  pop rax
000073dfa87dab4b  add rsp, 0x08
000073dfa87dab4f  jmp 0x000073DFA87D8ED9
000073dfa87dab54  call 0x000073DFA86E5820
000073dfa87dab59  jmp 0x000073DFA87D8EE6
000073dfa87dab5e  sub rsp, 0x08
000073dfa87dab62  push rax
000073dfa87dab63  push rcx
000073dfa87dab64  push rdx
000073dfa87dab65  push rdi
000073dfa87dab66  push rsi
000073dfa87dab67  push r8
000073dfa87dab69  push r9
000073dfa87dab6b  push r10
000073dfa87dab6d  push r11
000073dfa87dab6f  sub rsp, 0xF0
000073dfa87dab76  vmovaps [rsp], xmm0
000073dfa87dab7b  vmovaps [rsp+0x10], xmm1
000073dfa87dab81  vmovaps [rsp+0x20], xmm2
000073dfa87dab87  vmovaps [rsp+0x30], xmm4
000073dfa87dab8d  vmovaps [rsp+0x40], xmm5
000073dfa87dab93  vmovaps [rsp+0x50], xmm6
000073dfa87dab99  vmovaps [rsp+0x60], xmm7
000073dfa87dab9f  vmovaps [rsp+0x70], xmm8
000073dfa87daba5  vmovaps [rsp+0x80], xmm9
000073dfa87dabae  vmovaps [rsp+0x90], xmm10
000073dfa87dabb7  vmovaps [rsp+0xA0], xmm11
000073dfa87dabc0  vmovaps [rsp+0xB0], xmm12
000073dfa87dabc9  vmovaps [rsp+0xC0], xmm13
000073dfa87dabd2  vmovaps [rsp+0xD0], xmm14
000073dfa87dabdb  vmovaps [rsp+0xE0], xmm15
000073dfa87dabe4  sub rsp, 0x30
000073dfa87dabe8  movaps [rsp], xmm3
000073dfa87dabec  movaps [rsp+0x10], xmm1
000073dfa87dabf1  movaps [rsp+0x20], xmm9
000073dfa87dabf7  lea rdi, [rsp]
000073dfa87dabfb  mov esi, 0x00
000073dfa87dac00  mov rax, 0x593AA1DA4530
000073dfa87dac0a  call rax
000073dfa87dac0c  movaps xmm3, [rsp]
000073dfa87dac10  add rsp, 0x30
000073dfa87dac14  vmovaps xmm0, [rsp]
000073dfa87dac19  vmovaps xmm1, [rsp+0x10]
000073dfa87dac1f  vmovaps xmm2, [rsp+0x20]
000073dfa87dac25  vmovaps xmm4, [rsp+0x30]
000073dfa87dac2b  vmovaps xmm5, [rsp+0x40]
000073dfa87dac31  vmovaps xmm6, [rsp+0x50]
000073dfa87dac37  vmovaps xmm7, [rsp+0x60]
000073dfa87dac3d  vmovaps xmm8, [rsp+0x70]
000073dfa87dac43  vmovaps xmm9, [rsp+0x80]
000073dfa87dac4c  vmovaps xmm10, [rsp+0x90]
000073dfa87dac55  vmovaps xmm11, [rsp+0xA0]
000073dfa87dac5e  vmovaps xmm12, [rsp+0xB0]
000073dfa87dac67  vmovaps xmm13, [rsp+0xC0]
000073dfa87dac70  vmovaps xmm14, [rsp+0xD0]
000073dfa87dac79  vmovaps xmm15, [rsp+0xE0]
000073dfa87dac82  add rsp, 0xF0
000073dfa87dac89  pop r11
000073dfa87dac8b  pop r10
000073dfa87dac8d  pop r9
000073dfa87dac8f  pop r8
000073dfa87dac91  pop rsi
000073dfa87dac92  pop rdi
000073dfa87dac93  pop rdx
000073dfa87dac94  pop rcx
000073dfa87dac95  pop rax
000073dfa87dac96  add rsp, 0x08
000073dfa87dac9a  jmp 0x000073DFA87D8F23
000073dfa87dac9f  sub rsp, 0x08
000073dfa87daca3  push rax
000073dfa87daca4  push rcx
000073dfa87daca5  push rdx
000073dfa87daca6  push rdi
000073dfa87daca7  push rsi
000073dfa87daca8  push r8
000073dfa87dacaa  push r9
000073dfa87dacac  push r10
000073dfa87dacae  push r11
000073dfa87dacb0  sub rsp, 0xF0
000073dfa87dacb7  vmovaps [rsp], xmm0
000073dfa87dacbc  vmovaps [rsp+0x10], xmm2
000073dfa87dacc2  vmovaps [rsp+0x20], xmm3
000073dfa87dacc8  vmovaps [rsp+0x30], xmm4
000073dfa87dacce  vmovaps [rsp+0x40], xmm5
000073dfa87dacd4  vmovaps [rsp+0x50], xmm6
000073dfa87dacda  vmovaps [rsp+0x60], xmm7
000073dfa87dace0  vmovaps [rsp+0x70], xmm8
000073dfa87dace6  vmovaps [rsp+0x80], xmm9
000073dfa87dacef  vmovaps [rsp+0x90], xmm10
000073dfa87dacf8  vmovaps [rsp+0xA0], xmm11
000073dfa87dad01  vmovaps [rsp+0xB0], xmm12
000073dfa87dad0a  vmovaps [rsp+0xC0], xmm13
000073dfa87dad13  vmovaps [rsp+0xD0], xmm14
000073dfa87dad1c  vmovaps [rsp+0xE0], xmm15
000073dfa87dad25  sub rsp, 0x30
000073dfa87dad29  movaps [rsp], xmm1
000073dfa87dad2d  movaps [rsp+0x10], xmm15
000073dfa87dad33  movaps [rsp+0x20], xmm9
000073dfa87dad39  lea rdi, [rsp]
000073dfa87dad3d  mov esi, 0x00
000073dfa87dad42  mov rax, 0x593AA1DA4530
000073dfa87dad4c  call rax
000073dfa87dad4e  movaps xmm1, [rsp]
000073dfa87dad52  add rsp, 0x30
000073dfa87dad56  vmovaps xmm0, [rsp]
000073dfa87dad5b  vmovaps xmm2, [rsp+0x10]
000073dfa87dad61  vmovaps xmm3, [rsp+0x20]
000073dfa87dad67  vmovaps xmm4, [rsp+0x30]
000073dfa87dad6d  vmovaps xmm5, [rsp+0x40]
000073dfa87dad73  vmovaps xmm6, [rsp+0x50]
000073dfa87dad79  vmovaps xmm7, [rsp+0x60]
000073dfa87dad7f  vmovaps xmm8, [rsp+0x70]
000073dfa87dad85  vmovaps xmm9, [rsp+0x80]
000073dfa87dad8e  vmovaps xmm10, [rsp+0x90]
000073dfa87dad97  vmovaps xmm11, [rsp+0xA0]
000073dfa87dada0  vmovaps xmm12, [rsp+0xB0]
000073dfa87dada9  vmovaps xmm13, [rsp+0xC0]
000073dfa87dadb2  vmovaps xmm14, [rsp+0xD0]
000073dfa87dadbb  vmovaps xmm15, [rsp+0xE0]
000073dfa87dadc4  add rsp, 0xF0
000073dfa87dadcb  pop r11
000073dfa87dadcd  pop r10
000073dfa87dadcf  pop r9
000073dfa87dadd1  pop r8
000073dfa87dadd3  pop rsi
000073dfa87dadd4  pop rdi
000073dfa87dadd5  pop rdx
000073dfa87dadd6  pop rcx
000073dfa87dadd7  pop rax
000073dfa87dadd8  add rsp, 0x08
000073dfa87daddc  jmp 0x000073DFA87D8FAB
000073dfa87dade1  call 0x000073DFA86E5820
000073dfa87dade6  jmp 0x000073DFA87D8FB8
000073dfa87dadeb  sub rsp, 0x08
000073dfa87dadef  push rax
000073dfa87dadf0  push rcx
000073dfa87dadf1  push rdx
000073dfa87dadf2  push rdi
000073dfa87dadf3  push rsi
000073dfa87dadf4  push r8
000073dfa87dadf6  push r9
000073dfa87dadf8  push r10
000073dfa87dadfa  push r11
000073dfa87dadfc  sub rsp, 0xF0
000073dfa87dae03  vmovaps [rsp], xmm0
000073dfa87dae08  vmovaps [rsp+0x10], xmm2
000073dfa87dae0e  vmovaps [rsp+0x20], xmm3
000073dfa87dae14  vmovaps [rsp+0x30], xmm4
000073dfa87dae1a  vmovaps [rsp+0x40], xmm5
000073dfa87dae20  vmovaps [rsp+0x50], xmm6
000073dfa87dae26  vmovaps [rsp+0x60], xmm7
000073dfa87dae2c  vmovaps [rsp+0x70], xmm8
000073dfa87dae32  vmovaps [rsp+0x80], xmm9
000073dfa87dae3b  vmovaps [rsp+0x90], xmm10
000073dfa87dae44  vmovaps [rsp+0xA0], xmm11
000073dfa87dae4d  vmovaps [rsp+0xB0], xmm12
000073dfa87dae56  vmovaps [rsp+0xC0], xmm13
000073dfa87dae5f  vmovaps [rsp+0xD0], xmm14
000073dfa87dae68  vmovaps [rsp+0xE0], xmm15
000073dfa87dae71  sub rsp, 0x30
000073dfa87dae75  movaps [rsp], xmm1
000073dfa87dae79  movaps [rsp+0x10], xmm5
000073dfa87dae7e  movaps [rsp+0x20], xmm7
000073dfa87dae83  lea rdi, [rsp]
000073dfa87dae87  mov esi, 0x00
000073dfa87dae8c  mov rax, 0x593AA1DA4530
000073dfa87dae96  call rax
000073dfa87dae98  movaps xmm1, [rsp]
000073dfa87dae9c  add rsp, 0x30
000073dfa87daea0  vmovaps xmm0, [rsp]
000073dfa87daea5  vmovaps xmm2, [rsp+0x10]
000073dfa87daeab  vmovaps xmm3, [rsp+0x20]
000073dfa87daeb1  vmovaps xmm4, [rsp+0x30]
000073dfa87daeb7  vmovaps xmm5, [rsp+0x40]
000073dfa87daebd  vmovaps xmm6, [rsp+0x50]
000073dfa87daec3  vmovaps xmm7, [rsp+0x60]
000073dfa87daec9  vmovaps xmm8, [rsp+0x70]
000073dfa87daecf  vmovaps xmm9, [rsp+0x80]
000073dfa87daed8  vmovaps xmm10, [rsp+0x90]
000073dfa87daee1  vmovaps xmm11, [rsp+0xA0]
000073dfa87daeea  vmovaps xmm12, [rsp+0xB0]
000073dfa87daef3  vmovaps xmm13, [rsp+0xC0]
000073dfa87daefc  vmovaps xmm14, [rsp+0xD0]
000073dfa87daf05  vmovaps xmm15, [rsp+0xE0]
000073dfa87daf0e  add rsp, 0xF0
000073dfa87daf15  pop r11
000073dfa87daf17  pop r10
000073dfa87daf19  pop r9
000073dfa87daf1b  pop r8
000073dfa87daf1d  pop rsi
000073dfa87daf1e  pop rdi
000073dfa87daf1f  pop rdx
000073dfa87daf20  pop rcx
000073dfa87daf21  pop rax
000073dfa87daf22  add rsp, 0x08
000073dfa87daf26  jmp 0x000073DFA87D905D
000073dfa87daf2b  sub rsp, 0x08
000073dfa87daf2f  push rax
000073dfa87daf30  push rcx
000073dfa87daf31  push rdx
000073dfa87daf32  push rdi
000073dfa87daf33  push rsi
000073dfa87daf34  push r8
000073dfa87daf36  push r9
000073dfa87daf38  push r10
000073dfa87daf3a  push r11
000073dfa87daf3c  sub rsp, 0xF0
000073dfa87daf43  vmovaps [rsp], xmm0
000073dfa87daf48  vmovaps [rsp+0x10], xmm1
000073dfa87daf4e  vmovaps [rsp+0x20], xmm2
000073dfa87daf54  vmovaps [rsp+0x30], xmm3
000073dfa87daf5a  vmovaps [rsp+0x40], xmm4
000073dfa87daf60  vmovaps [rsp+0x50], xmm5
000073dfa87daf66  vmovaps [rsp+0x60], xmm6
000073dfa87daf6c  vmovaps [rsp+0x70], xmm8
000073dfa87daf72  vmovaps [rsp+0x80], xmm9
000073dfa87daf7b  vmovaps [rsp+0x90], xmm10
000073dfa87daf84  vmovaps [rsp+0xA0], xmm11
000073dfa87daf8d  vmovaps [rsp+0xB0], xmm12
000073dfa87daf96  vmovaps [rsp+0xC0], xmm13
000073dfa87daf9f  vmovaps [rsp+0xD0], xmm14
000073dfa87dafa8  vmovaps [rsp+0xE0], xmm15
000073dfa87dafb1  sub rsp, 0x30
000073dfa87dafb5  movaps [rsp], xmm7
000073dfa87dafb9  movaps [rsp+0x10], xmm5
000073dfa87dafbe  movaps [rsp+0x20], xmm15
000073dfa87dafc4  lea rdi, [rsp]
000073dfa87dafc8  mov esi, 0x00
000073dfa87dafcd  mov rax, 0x593AA1DA4530
000073dfa87dafd7  call rax
000073dfa87dafd9  movaps xmm7, [rsp]
000073dfa87dafdd  add rsp, 0x30
000073dfa87dafe1  vmovaps xmm0, [rsp]
000073dfa87dafe6  vmovaps xmm1, [rsp+0x10]
000073dfa87dafec  vmovaps xmm2, [rsp+0x20]
000073dfa87daff2  vmovaps xmm3, [rsp+0x30]
000073dfa87daff8  vmovaps xmm4, [rsp+0x40]
000073dfa87daffe  vmovaps xmm5, [rsp+0x50]
000073dfa87db004  vmovaps xmm6, [rsp+0x60]
000073dfa87db00a  vmovaps xmm8, [rsp+0x70]
000073dfa87db010  vmovaps xmm9, [rsp+0x80]
000073dfa87db019  vmovaps xmm10, [rsp+0x90]
000073dfa87db022  vmovaps xmm11, [rsp+0xA0]
000073dfa87db02b  vmovaps xmm12, [rsp+0xB0]
000073dfa87db034  vmovaps xmm13, [rsp+0xC0]
000073dfa87db03d  vmovaps xmm14, [rsp+0xD0]
000073dfa87db046  vmovaps xmm15, [rsp+0xE0]
000073dfa87db04f  add rsp, 0xF0
000073dfa87db056  pop r11
000073dfa87db058  pop r10
000073dfa87db05a  pop r9
000073dfa87db05c  pop r8
000073dfa87db05e  pop rsi
000073dfa87db05f  pop rdi
000073dfa87db060  pop rdx
000073dfa87db061  pop rcx
000073dfa87db062  pop rax
000073dfa87db063  add rsp, 0x08
000073dfa87db067  jmp 0x000073DFA87D9093
000073dfa87db06c  call 0x000073DFA86D64F0
000073dfa87db071  jmp 0x000073DFA87D90A0
000073dfa87db076  sub rsp, 0x08
000073dfa87db07a  push rax
000073dfa87db07b  push rcx
000073dfa87db07c  push rdx
000073dfa87db07d  push rdi
000073dfa87db07e  push rsi
000073dfa87db07f  push r8
000073dfa87db081  push r9
000073dfa87db083  push r10
000073dfa87db085  push r11
000073dfa87db087  sub rsp, 0xF0
000073dfa87db08e  vmovaps [rsp], xmm0
000073dfa87db093  vmovaps [rsp+0x10], xmm1
000073dfa87db099  vmovaps [rsp+0x20], xmm2
000073dfa87db09f  vmovaps [rsp+0x30], xmm3
000073dfa87db0a5  vmovaps [rsp+0x40], xmm4
000073dfa87db0ab  vmovaps [rsp+0x50], xmm5
000073dfa87db0b1  vmovaps [rsp+0x60], xmm6
000073dfa87db0b7  vmovaps [rsp+0x70], xmm7
000073dfa87db0bd  vmovaps [rsp+0x80], xmm8
000073dfa87db0c6  vmovaps [rsp+0x90], xmm9
000073dfa87db0cf  vmovaps [rsp+0xA0], xmm10
000073dfa87db0d8  vmovaps [rsp+0xB0], xmm11
000073dfa87db0e1  vmovaps [rsp+0xC0], xmm12
000073dfa87db0ea  vmovaps [rsp+0xD0], xmm13
000073dfa87db0f3  vmovaps [rsp+0xE0], xmm14
000073dfa87db0fc  sub rsp, 0x30
000073dfa87db100  movaps [rsp], xmm15
000073dfa87db105  movaps [rsp+0x10], xmm5
000073dfa87db10a  movaps [rsp+0x20], xmm3
000073dfa87db10f  lea rdi, [rsp]
000073dfa87db113  mov esi, 0x00
000073dfa87db118  mov rax, 0x593AA1DA4530
000073dfa87db122  call rax
000073dfa87db124  movaps xmm15, [rsp]
000073dfa87db129  add rsp, 0x30
000073dfa87db12d  vmovaps xmm0, [rsp]
000073dfa87db132  vmovaps xmm1, [rsp+0x10]
000073dfa87db138  vmovaps xmm2, [rsp+0x20]
000073dfa87db13e  vmovaps xmm3, [rsp+0x30]
000073dfa87db144  vmovaps xmm4, [rsp+0x40]
000073dfa87db14a  vmovaps xmm5, [rsp+0x50]
000073dfa87db150  vmovaps xmm6, [rsp+0x60]
000073dfa87db156  vmovaps xmm7, [rsp+0x70]
000073dfa87db15c  vmovaps xmm8, [rsp+0x80]
000073dfa87db165  vmovaps xmm9, [rsp+0x90]
000073dfa87db16e  vmovaps xmm10, [rsp+0xA0]
000073dfa87db177  vmovaps xmm11, [rsp+0xB0]
000073dfa87db180  vmovaps xmm12, [rsp+0xC0]
000073dfa87db189  vmovaps xmm13, [rsp+0xD0]
000073dfa87db192  vmovaps xmm14, [rsp+0xE0]
000073dfa87db19b  add rsp, 0xF0
000073dfa87db1a2  pop r11
000073dfa87db1a4  pop r10
000073dfa87db1a6  pop r9
000073dfa87db1a8  pop r8
000073dfa87db1aa  pop rsi
000073dfa87db1ab  pop rdi
000073dfa87db1ac  pop rdx
000073dfa87db1ad  pop rcx
000073dfa87db1ae  pop rax
000073dfa87db1af  add rsp, 0x08
000073dfa87db1b3  jmp 0x000073DFA87D90C6
000073dfa87db1b8  sub rsp, 0x08
000073dfa87db1bc  push rax
000073dfa87db1bd  push rcx
000073dfa87db1be  push rdx
000073dfa87db1bf  push rdi
000073dfa87db1c0  push rsi
000073dfa87db1c1  push r8
000073dfa87db1c3  push r9
000073dfa87db1c5  push r10
000073dfa87db1c7  push r11
000073dfa87db1c9  sub rsp, 0xF0
000073dfa87db1d0  vmovaps [rsp], xmm0
000073dfa87db1d5  vmovaps [rsp+0x10], xmm2
000073dfa87db1db  vmovaps [rsp+0x20], xmm3
000073dfa87db1e1  vmovaps [rsp+0x30], xmm4
000073dfa87db1e7  vmovaps [rsp+0x40], xmm5
000073dfa87db1ed  vmovaps [rsp+0x50], xmm6
000073dfa87db1f3  vmovaps [rsp+0x60], xmm7
000073dfa87db1f9  vmovaps [rsp+0x70], xmm8
000073dfa87db1ff  vmovaps [rsp+0x80], xmm9
000073dfa87db208  vmovaps [rsp+0x90], xmm10
000073dfa87db211  vmovaps [rsp+0xA0], xmm11
000073dfa87db21a  vmovaps [rsp+0xB0], xmm12
000073dfa87db223  vmovaps [rsp+0xC0], xmm13
000073dfa87db22c  vmovaps [rsp+0xD0], xmm14
000073dfa87db235  vmovaps [rsp+0xE0], xmm15
000073dfa87db23e  sub rsp, 0x30
000073dfa87db242  movaps [rsp], xmm1
000073dfa87db246  movaps [rsp+0x10], xmm5
000073dfa87db24b  movaps [rsp+0x20], xmm4
000073dfa87db250  lea rdi, [rsp]
000073dfa87db254  mov esi, 0x00
000073dfa87db259  mov rax, 0x593AA1DA4530
000073dfa87db263  call rax
000073dfa87db265  movaps xmm1, [rsp]
000073dfa87db269  add rsp, 0x30
000073dfa87db26d  vmovaps xmm0, [rsp]
000073dfa87db272  vmovaps xmm2, [rsp+0x10]
000073dfa87db278  vmovaps xmm3, [rsp+0x20]
000073dfa87db27e  vmovaps xmm4, [rsp+0x30]
000073dfa87db284  vmovaps xmm5, [rsp+0x40]
000073dfa87db28a  vmovaps xmm6, [rsp+0x50]
000073dfa87db290  vmovaps xmm7, [rsp+0x60]
000073dfa87db296  vmovaps xmm8, [rsp+0x70]
000073dfa87db29c  vmovaps xmm9, [rsp+0x80]
000073dfa87db2a5  vmovaps xmm10, [rsp+0x90]
000073dfa87db2ae  vmovaps xmm11, [rsp+0xA0]
000073dfa87db2b7  vmovaps xmm12, [rsp+0xB0]
000073dfa87db2c0  vmovaps xmm13, [rsp+0xC0]
000073dfa87db2c9  vmovaps xmm14, [rsp+0xD0]
000073dfa87db2d2  vmovaps xmm15, [rsp+0xE0]
000073dfa87db2db  add rsp, 0xF0
000073dfa87db2e2  pop r11
000073dfa87db2e4  pop r10
000073dfa87db2e6  pop r9
000073dfa87db2e8  pop r8
000073dfa87db2ea  pop rsi
000073dfa87db2eb  pop rdi
000073dfa87db2ec  pop rdx
000073dfa87db2ed  pop rcx
000073dfa87db2ee  pop rax
000073dfa87db2ef  add rsp, 0x08
000073dfa87db2f3  jmp 0x000073DFA87D90E6
000073dfa87db2f8  sub rsp, 0x08
000073dfa87db2fc  push rax
000073dfa87db2fd  push rcx
000073dfa87db2fe  push rdx
000073dfa87db2ff  push rdi
000073dfa87db300  push rsi
000073dfa87db301  push r8
000073dfa87db303  push r9
000073dfa87db305  push r10
000073dfa87db307  push r11
000073dfa87db309  sub rsp, 0xF0
000073dfa87db310  vmovaps [rsp], xmm0
000073dfa87db315  vmovaps [rsp+0x10], xmm1
000073dfa87db31b  vmovaps [rsp+0x20], xmm2
000073dfa87db321  vmovaps [rsp+0x30], xmm3
000073dfa87db327  vmovaps [rsp+0x40], xmm5
000073dfa87db32d  vmovaps [rsp+0x50], xmm6
000073dfa87db333  vmovaps [rsp+0x60], xmm7
000073dfa87db339  vmovaps [rsp+0x70], xmm8
000073dfa87db33f  vmovaps [rsp+0x80], xmm9
000073dfa87db348  vmovaps [rsp+0x90], xmm10
000073dfa87db351  vmovaps [rsp+0xA0], xmm11
000073dfa87db35a  vmovaps [rsp+0xB0], xmm12
000073dfa87db363  vmovaps [rsp+0xC0], xmm13
000073dfa87db36c  vmovaps [rsp+0xD0], xmm14
000073dfa87db375  vmovaps [rsp+0xE0], xmm15
000073dfa87db37e  sub rsp, 0x30
000073dfa87db382  movaps [rsp], xmm4
000073dfa87db386  movaps [rsp+0x10], xmm3
000073dfa87db38b  movaps [rsp+0x20], xmm5
000073dfa87db390  lea rdi, [rsp]
000073dfa87db394  mov esi, 0x00
000073dfa87db399  mov rax, 0x593AA1DA4530
000073dfa87db3a3  call rax
000073dfa87db3a5  movaps xmm4, [rsp]
000073dfa87db3a9  add rsp, 0x30
000073dfa87db3ad  vmovaps xmm0, [rsp]
000073dfa87db3b2  vmovaps xmm1, [rsp+0x10]
000073dfa87db3b8  vmovaps xmm2, [rsp+0x20]
000073dfa87db3be  vmovaps xmm3, [rsp+0x30]
000073dfa87db3c4  vmovaps xmm5, [rsp+0x40]
000073dfa87db3ca  vmovaps xmm6, [rsp+0x50]
000073dfa87db3d0  vmovaps xmm7, [rsp+0x60]
000073dfa87db3d6  vmovaps xmm8, [rsp+0x70]
000073dfa87db3dc  vmovaps xmm9, [rsp+0x80]
000073dfa87db3e5  vmovaps xmm10, [rsp+0x90]
000073dfa87db3ee  vmovaps xmm11, [rsp+0xA0]
000073dfa87db3f7  vmovaps xmm12, [rsp+0xB0]
000073dfa87db400  vmovaps xmm13, [rsp+0xC0]
000073dfa87db409  vmovaps xmm14, [rsp+0xD0]
000073dfa87db412  vmovaps xmm15, [rsp+0xE0]
000073dfa87db41b  add rsp, 0xF0
000073dfa87db422  pop r11
000073dfa87db424  pop r10
000073dfa87db426  pop r9
000073dfa87db428  pop r8
000073dfa87db42a  pop rsi
000073dfa87db42b  pop rdi
000073dfa87db42c  pop rdx
000073dfa87db42d  pop rcx
000073dfa87db42e  pop rax
000073dfa87db42f  add rsp, 0x08
000073dfa87db433  jmp 0x000073DFA87D9134
000073dfa87db438  call 0x000073DFA86D64F0
000073dfa87db43d  jmp 0x000073DFA87D9141
000073dfa87db442  sub rsp, 0x08
000073dfa87db446  push rax
000073dfa87db447  push rcx
000073dfa87db448  push rdx
000073dfa87db449  push rdi
000073dfa87db44a  push rsi
000073dfa87db44b  push r8
000073dfa87db44d  push r9
000073dfa87db44f  push r10
000073dfa87db451  push r11
000073dfa87db453  sub rsp, 0xF0
000073dfa87db45a  vmovaps [rsp], xmm0
000073dfa87db45f  vmovaps [rsp+0x10], xmm1
000073dfa87db465  vmovaps [rsp+0x20], xmm2
000073dfa87db46b  vmovaps [rsp+0x30], xmm3
000073dfa87db471  vmovaps [rsp+0x40], xmm4
000073dfa87db477  vmovaps [rsp+0x50], xmm6
000073dfa87db47d  vmovaps [rsp+0x60], xmm7
000073dfa87db483  vmovaps [rsp+0x70], xmm8
000073dfa87db489  vmovaps [rsp+0x80], xmm9
000073dfa87db492  vmovaps [rsp+0x90], xmm10
000073dfa87db49b  vmovaps [rsp+0xA0], xmm11
000073dfa87db4a4  vmovaps [rsp+0xB0], xmm12
000073dfa87db4ad  vmovaps [rsp+0xC0], xmm13
000073dfa87db4b6  vmovaps [rsp+0xD0], xmm14
000073dfa87db4bf  vmovaps [rsp+0xE0], xmm15
000073dfa87db4c8  sub rsp, 0x30
000073dfa87db4cc  movaps [rsp], xmm5
000073dfa87db4d0  movaps [rsp+0x10], xmm6
000073dfa87db4d5  movaps [rsp+0x20], xmm3
000073dfa87db4da  lea rdi, [rsp]
000073dfa87db4de  mov esi, 0x00
000073dfa87db4e3  mov rax, 0x593AA1DA4530
000073dfa87db4ed  call rax
000073dfa87db4ef  movaps xmm5, [rsp]
000073dfa87db4f3  add rsp, 0x30
000073dfa87db4f7  vmovaps xmm0, [rsp]
000073dfa87db4fc  vmovaps xmm1, [rsp+0x10]
000073dfa87db502  vmovaps xmm2, [rsp+0x20]
000073dfa87db508  vmovaps xmm3, [rsp+0x30]
000073dfa87db50e  vmovaps xmm4, [rsp+0x40]
000073dfa87db514  vmovaps xmm6, [rsp+0x50]
000073dfa87db51a  vmovaps xmm7, [rsp+0x60]
000073dfa87db520  vmovaps xmm8, [rsp+0x70]
000073dfa87db526  vmovaps xmm9, [rsp+0x80]
000073dfa87db52f  vmovaps xmm10, [rsp+0x90]
000073dfa87db538  vmovaps xmm11, [rsp+0xA0]
000073dfa87db541  vmovaps xmm12, [rsp+0xB0]
000073dfa87db54a  vmovaps xmm13, [rsp+0xC0]
000073dfa87db553  vmovaps xmm14, [rsp+0xD0]
000073dfa87db55c  vmovaps xmm15, [rsp+0xE0]
000073dfa87db565  add rsp, 0xF0
000073dfa87db56c  pop r11
000073dfa87db56e  pop r10
000073dfa87db570  pop r9
000073dfa87db572  pop r8
000073dfa87db574  pop rsi
000073dfa87db575  pop rdi
000073dfa87db576  pop rdx
000073dfa87db577  pop rcx
000073dfa87db578  pop rax
000073dfa87db579  add rsp, 0x08
000073dfa87db57d  jmp 0x000073DFA87D9167
000073dfa87db582  sub rsp, 0x08
000073dfa87db586  push rax
000073dfa87db587  push rcx
000073dfa87db588  push rdx
000073dfa87db589  push rdi
000073dfa87db58a  push rsi
000073dfa87db58b  push r8
000073dfa87db58d  push r9
000073dfa87db58f  push r10
000073dfa87db591  push r11
000073dfa87db593  sub rsp, 0xF0
000073dfa87db59a  vmovaps [rsp], xmm0
000073dfa87db59f  vmovaps [rsp+0x10], xmm1
000073dfa87db5a5  vmovaps [rsp+0x20], xmm2
000073dfa87db5ab  vmovaps [rsp+0x30], xmm3
000073dfa87db5b1  vmovaps [rsp+0x40], xmm4
000073dfa87db5b7  vmovaps [rsp+0x50], xmm5
000073dfa87db5bd  vmovaps [rsp+0x60], xmm7
000073dfa87db5c3  vmovaps [rsp+0x70], xmm8
000073dfa87db5c9  vmovaps [rsp+0x80], xmm9
000073dfa87db5d2  vmovaps [rsp+0x90], xmm10
000073dfa87db5db  vmovaps [rsp+0xA0], xmm11
000073dfa87db5e4  vmovaps [rsp+0xB0], xmm12
000073dfa87db5ed  vmovaps [rsp+0xC0], xmm13
000073dfa87db5f6  vmovaps [rsp+0xD0], xmm14
000073dfa87db5ff  vmovaps [rsp+0xE0], xmm15
000073dfa87db608  sub rsp, 0x30
000073dfa87db60c  movaps [rsp], xmm6
000073dfa87db610  movaps [rsp+0x10], xmm9
000073dfa87db616  movaps [rsp+0x20], xmm1
000073dfa87db61b  lea rdi, [rsp]
000073dfa87db61f  mov esi, 0x00
000073dfa87db624  mov rax, 0x593AA1DA4530
000073dfa87db62e  call rax
000073dfa87db630  movaps xmm6, [rsp]
000073dfa87db634  add rsp, 0x30
000073dfa87db638  vmovaps xmm0, [rsp]
000073dfa87db63d  vmovaps xmm1, [rsp+0x10]
000073dfa87db643  vmovaps xmm2, [rsp+0x20]
000073dfa87db649  vmovaps xmm3, [rsp+0x30]
000073dfa87db64f  vmovaps xmm4, [rsp+0x40]
000073dfa87db655  vmovaps xmm5, [rsp+0x50]
000073dfa87db65b  vmovaps xmm7, [rsp+0x60]
000073dfa87db661  vmovaps xmm8, [rsp+0x70]
000073dfa87db667  vmovaps xmm9, [rsp+0x80]
000073dfa87db670  vmovaps xmm10, [rsp+0x90]
000073dfa87db679  vmovaps xmm11, [rsp+0xA0]
000073dfa87db682  vmovaps xmm12, [rsp+0xB0]
000073dfa87db68b  vmovaps xmm13, [rsp+0xC0]
000073dfa87db694  vmovaps xmm14, [rsp+0xD0]
000073dfa87db69d  vmovaps xmm15, [rsp+0xE0]
000073dfa87db6a6  add rsp, 0xF0
000073dfa87db6ad  pop r11
000073dfa87db6af  pop r10
000073dfa87db6b1  pop r9
000073dfa87db6b3  pop r8
000073dfa87db6b5  pop rsi
000073dfa87db6b6  pop rdi
000073dfa87db6b7  pop rdx
000073dfa87db6b8  pop rcx
000073dfa87db6b9  pop rax
000073dfa87db6ba  add rsp, 0x08
000073dfa87db6be  jmp 0x000073DFA87D918B
000073dfa87db6c3  sub rsp, 0x08
000073dfa87db6c7  push rax
000073dfa87db6c8  push rcx
000073dfa87db6c9  push rdx
000073dfa87db6ca  push rdi
000073dfa87db6cb  push rsi
000073dfa87db6cc  push r8
000073dfa87db6ce  push r9
000073dfa87db6d0  push r10
000073dfa87db6d2  push r11
000073dfa87db6d4  sub rsp, 0xF0
000073dfa87db6db  vmovaps [rsp], xmm0
000073dfa87db6e0  vmovaps [rsp+0x10], xmm1
000073dfa87db6e6  vmovaps [rsp+0x20], xmm2
000073dfa87db6ec  vmovaps [rsp+0x30], xmm3
000073dfa87db6f2  vmovaps [rsp+0x40], xmm4
000073dfa87db6f8  vmovaps [rsp+0x50], xmm5
000073dfa87db6fe  vmovaps [rsp+0x60], xmm6
000073dfa87db704  vmovaps [rsp+0x70], xmm7
000073dfa87db70a  vmovaps [rsp+0x80], xmm8
000073dfa87db713  vmovaps [rsp+0x90], xmm10
000073dfa87db71c  vmovaps [rsp+0xA0], xmm11
000073dfa87db725  vmovaps [rsp+0xB0], xmm12
000073dfa87db72e  vmovaps [rsp+0xC0], xmm13
000073dfa87db737  vmovaps [rsp+0xD0], xmm14
000073dfa87db740  vmovaps [rsp+0xE0], xmm15
000073dfa87db749  sub rsp, 0x30
000073dfa87db74d  movaps [rsp], xmm9
000073dfa87db752  movaps [rsp+0x10], xmm3
000073dfa87db757  movaps [rsp+0x20], xmm1
000073dfa87db75c  lea rdi, [rsp]
000073dfa87db760  mov esi, 0x00
000073dfa87db765  mov rax, 0x593AA1DA4530
000073dfa87db76f  call rax
000073dfa87db771  movaps xmm9, [rsp]
000073dfa87db776  add rsp, 0x30
000073dfa87db77a  vmovaps xmm0, [rsp]
000073dfa87db77f  vmovaps xmm1, [rsp+0x10]
000073dfa87db785  vmovaps xmm2, [rsp+0x20]
000073dfa87db78b  vmovaps xmm3, [rsp+0x30]
000073dfa87db791  vmovaps xmm4, [rsp+0x40]
000073dfa87db797  vmovaps xmm5, [rsp+0x50]
000073dfa87db79d  vmovaps xmm6, [rsp+0x60]
000073dfa87db7a3  vmovaps xmm7, [rsp+0x70]
000073dfa87db7a9  vmovaps xmm8, [rsp+0x80]
000073dfa87db7b2  vmovaps xmm10, [rsp+0x90]
000073dfa87db7bb  vmovaps xmm11, [rsp+0xA0]
000073dfa87db7c4  vmovaps xmm12, [rsp+0xB0]
000073dfa87db7cd  vmovaps xmm13, [rsp+0xC0]
000073dfa87db7d6  vmovaps xmm14, [rsp+0xD0]
000073dfa87db7df  vmovaps xmm15, [rsp+0xE0]
000073dfa87db7e8  add rsp, 0xF0
000073dfa87db7ef  pop r11
000073dfa87db7f1  pop r10
000073dfa87db7f3  pop r9
000073dfa87db7f5  pop r8
000073dfa87db7f7  pop rsi
000073dfa87db7f8  pop rdi
000073dfa87db7f9  pop rdx
000073dfa87db7fa  pop rcx
000073dfa87db7fb  pop rax
000073dfa87db7fc  add rsp, 0x08
000073dfa87db800  jmp 0x000073DFA87D91D7
000073dfa87db805  call 0x000073DFA86D64F0
000073dfa87db80a  jmp 0x000073DFA87D91E4
000073dfa87db80f  sub rsp, 0x08
000073dfa87db813  push rax
000073dfa87db814  push rcx
000073dfa87db815  push rdx
000073dfa87db816  push rdi
000073dfa87db817  push rsi
000073dfa87db818  push r8
000073dfa87db81a  push r9
000073dfa87db81c  push r10
000073dfa87db81e  push r11
000073dfa87db820  sub rsp, 0xF0
000073dfa87db827  vmovaps [rsp], xmm0
000073dfa87db82c  vmovaps [rsp+0x10], xmm1
000073dfa87db832  vmovaps [rsp+0x20], xmm2
000073dfa87db838  vmovaps [rsp+0x30], xmm3
000073dfa87db83e  vmovaps [rsp+0x40], xmm4
000073dfa87db844  vmovaps [rsp+0x50], xmm5
000073dfa87db84a  vmovaps [rsp+0x60], xmm6
000073dfa87db850  vmovaps [rsp+0x70], xmm7
000073dfa87db856  vmovaps [rsp+0x80], xmm8
000073dfa87db85f  vmovaps [rsp+0x90], xmm9
000073dfa87db868  vmovaps [rsp+0xA0], xmm10
000073dfa87db871  vmovaps [rsp+0xB0], xmm11
000073dfa87db87a  vmovaps [rsp+0xC0], xmm12
000073dfa87db883  vmovaps [rsp+0xD0], xmm13
000073dfa87db88c  vmovaps [rsp+0xE0], xmm14
000073dfa87db895  sub rsp, 0x30
000073dfa87db899  movaps [rsp], xmm15
000073dfa87db89e  movaps [rsp+0x10], xmm3
000073dfa87db8a3  movaps [rsp+0x20], xmm7
000073dfa87db8a8  lea rdi, [rsp]
000073dfa87db8ac  mov esi, 0x00
000073dfa87db8b1  mov rax, 0x593AA1DA4530
000073dfa87db8bb  call rax
000073dfa87db8bd  movaps xmm15, [rsp]
000073dfa87db8c2  add rsp, 0x30
000073dfa87db8c6  vmovaps xmm0, [rsp]
000073dfa87db8cb  vmovaps xmm1, [rsp+0x10]
000073dfa87db8d1  vmovaps xmm2, [rsp+0x20]
000073dfa87db8d7  vmovaps xmm3, [rsp+0x30]
000073dfa87db8dd  vmovaps xmm4, [rsp+0x40]
000073dfa87db8e3  vmovaps xmm5, [rsp+0x50]
000073dfa87db8e9  vmovaps xmm6, [rsp+0x60]
000073dfa87db8ef  vmovaps xmm7, [rsp+0x70]
000073dfa87db8f5  vmovaps xmm8, [rsp+0x80]
000073dfa87db8fe  vmovaps xmm9, [rsp+0x90]
000073dfa87db907  vmovaps xmm10, [rsp+0xA0]
000073dfa87db910  vmovaps xmm11, [rsp+0xB0]
000073dfa87db919  vmovaps xmm12, [rsp+0xC0]
000073dfa87db922  vmovaps xmm13, [rsp+0xD0]
000073dfa87db92b  vmovaps xmm14, [rsp+0xE0]
000073dfa87db934  add rsp, 0xF0
000073dfa87db93b  pop r11
000073dfa87db93d  pop r10
000073dfa87db93f  pop r9
000073dfa87db941  pop r8
000073dfa87db943  pop rsi
000073dfa87db944  pop rdi
000073dfa87db945  pop rdx
000073dfa87db946  pop rcx
000073dfa87db947  pop rax
000073dfa87db948  add rsp, 0x08
000073dfa87db94c  jmp 0x000073DFA87D9210
000073dfa87db951  sub rsp, 0x08
000073dfa87db955  push rax
000073dfa87db956  push rcx
000073dfa87db957  push rdx
000073dfa87db958  push rdi
000073dfa87db959  push rsi
000073dfa87db95a  push r8
000073dfa87db95c  push r9
000073dfa87db95e  push r10
000073dfa87db960  push r11
000073dfa87db962  sub rsp, 0xF0
000073dfa87db969  vmovaps [rsp], xmm0
000073dfa87db96e  vmovaps [rsp+0x10], xmm1
000073dfa87db974  vmovaps [rsp+0x20], xmm2
000073dfa87db97a  vmovaps [rsp+0x30], xmm4
000073dfa87db980  vmovaps [rsp+0x40], xmm5
000073dfa87db986  vmovaps [rsp+0x50], xmm6
000073dfa87db98c  vmovaps [rsp+0x60], xmm7
000073dfa87db992  vmovaps [rsp+0x70], xmm8
000073dfa87db998  vmovaps [rsp+0x80], xmm9
000073dfa87db9a1  vmovaps [rsp+0x90], xmm10
000073dfa87db9aa  vmovaps [rsp+0xA0], xmm11
000073dfa87db9b3  vmovaps [rsp+0xB0], xmm12
000073dfa87db9bc  vmovaps [rsp+0xC0], xmm13
000073dfa87db9c5  vmovaps [rsp+0xD0], xmm14
000073dfa87db9ce  vmovaps [rsp+0xE0], xmm15
000073dfa87db9d7  sub rsp, 0x30
000073dfa87db9db  movaps [rsp], xmm3
000073dfa87db9df  movaps [rsp+0x10], xmm1
000073dfa87db9e4  movaps [rsp+0x20], xmm15
000073dfa87db9ea  lea rdi, [rsp]
000073dfa87db9ee  mov esi, 0x00
000073dfa87db9f3  mov rax, 0x593AA1DA4530
000073dfa87db9fd  call rax
000073dfa87db9ff  movaps xmm3, [rsp]
000073dfa87dba03  add rsp, 0x30
000073dfa87dba07  vmovaps xmm0, [rsp]
000073dfa87dba0c  vmovaps xmm1, [rsp+0x10]
000073dfa87dba12  vmovaps xmm2, [rsp+0x20]
000073dfa87dba18  vmovaps xmm4, [rsp+0x30]
000073dfa87dba1e  vmovaps xmm5, [rsp+0x40]
000073dfa87dba24  vmovaps xmm6, [rsp+0x50]
000073dfa87dba2a  vmovaps xmm7, [rsp+0x60]
000073dfa87dba30  vmovaps xmm8, [rsp+0x70]
000073dfa87dba36  vmovaps xmm9, [rsp+0x80]
000073dfa87dba3f  vmovaps xmm10, [rsp+0x90]
000073dfa87dba48  vmovaps xmm11, [rsp+0xA0]
000073dfa87dba51  vmovaps xmm12, [rsp+0xB0]
000073dfa87dba5a  vmovaps xmm13, [rsp+0xC0]
000073dfa87dba63  vmovaps xmm14, [rsp+0xD0]
000073dfa87dba6c  vmovaps xmm15, [rsp+0xE0]
000073dfa87dba75  add rsp, 0xF0
000073dfa87dba7c  pop r11
000073dfa87dba7e  pop r10
000073dfa87dba80  pop r9
000073dfa87dba82  pop r8
000073dfa87dba84  pop rsi
000073dfa87dba85  pop rdi
000073dfa87dba86  pop rdx
000073dfa87dba87  pop rcx
000073dfa87dba88  pop rax
000073dfa87dba89  add rsp, 0x08
000073dfa87dba8d  jmp 0x000073DFA87D929F
000073dfa87dba92  call 0x000073DFA86D64F0
000073dfa87dba97  jmp 0x000073DFA87D92A9
000073dfa87dba9c  sub rsp, 0x08
000073dfa87dbaa0  push rax
000073dfa87dbaa1  push rcx
000073dfa87dbaa2  push rdx
000073dfa87dbaa3  push rdi
000073dfa87dbaa4  push rsi
000073dfa87dbaa5  push r8
000073dfa87dbaa7  push r9
000073dfa87dbaa9  push r10
000073dfa87dbaab  push r11
000073dfa87dbaad  sub rsp, 0xF0
000073dfa87dbab4  vmovaps [rsp], xmm0
000073dfa87dbab9  vmovaps [rsp+0x10], xmm1
000073dfa87dbabf  vmovaps [rsp+0x20], xmm2
000073dfa87dbac5  vmovaps [rsp+0x30], xmm3
000073dfa87dbacb  vmovaps [rsp+0x40], xmm4
000073dfa87dbad1  vmovaps [rsp+0x50], xmm5
000073dfa87dbad7  vmovaps [rsp+0x60], xmm6
000073dfa87dbadd  vmovaps [rsp+0x70], xmm7
000073dfa87dbae3  vmovaps [rsp+0x80], xmm8
000073dfa87dbaec  vmovaps [rsp+0x90], xmm9
000073dfa87dbaf5  vmovaps [rsp+0xA0], xmm10
000073dfa87dbafe  vmovaps [rsp+0xB0], xmm11
000073dfa87dbb07  vmovaps [rsp+0xC0], xmm12
000073dfa87dbb10  vmovaps [rsp+0xD0], xmm13
000073dfa87dbb19  vmovaps [rsp+0xE0], xmm14
000073dfa87dbb22  sub rsp, 0x30
000073dfa87dbb26  movaps [rsp], xmm15
000073dfa87dbb2b  movaps [rsp+0x10], xmm14
000073dfa87dbb31  movaps [rsp+0x20], xmm4
000073dfa87dbb36  lea rdi, [rsp]
000073dfa87dbb3a  mov esi, 0x00
000073dfa87dbb3f  mov rax, 0x593AA1DA4530
000073dfa87dbb49  call rax
000073dfa87dbb4b  movaps xmm15, [rsp]
000073dfa87dbb50  add rsp, 0x30
000073dfa87dbb54  vmovaps xmm0, [rsp]
000073dfa87dbb59  vmovaps xmm1, [rsp+0x10]
000073dfa87dbb5f  vmovaps xmm2, [rsp+0x20]
000073dfa87dbb65  vmovaps xmm3, [rsp+0x30]
000073dfa87dbb6b  vmovaps xmm4, [rsp+0x40]
000073dfa87dbb71  vmovaps xmm5, [rsp+0x50]
000073dfa87dbb77  vmovaps xmm6, [rsp+0x60]
000073dfa87dbb7d  vmovaps xmm7, [rsp+0x70]
000073dfa87dbb83  vmovaps xmm8, [rsp+0x80]
000073dfa87dbb8c  vmovaps xmm9, [rsp+0x90]
000073dfa87dbb95  vmovaps xmm10, [rsp+0xA0]
000073dfa87dbb9e  vmovaps xmm11, [rsp+0xB0]
000073dfa87dbba7  vmovaps xmm12, [rsp+0xC0]
000073dfa87dbbb0  vmovaps xmm13, [rsp+0xD0]
000073dfa87dbbb9  vmovaps xmm14, [rsp+0xE0]
000073dfa87dbbc2  add rsp, 0xF0
000073dfa87dbbc9  pop r11
000073dfa87dbbcb  pop r10
000073dfa87dbbcd  pop r9
000073dfa87dbbcf  pop r8
000073dfa87dbbd1  pop rsi
000073dfa87dbbd2  pop rdi
000073dfa87dbbd3  pop rdx
000073dfa87dbbd4  pop rcx
000073dfa87dbbd5  pop rax
000073dfa87dbbd6  add rsp, 0x08
000073dfa87dbbda  jmp 0x000073DFA87D92D7
000073dfa87dbbdf  sub rsp, 0x08
000073dfa87dbbe3  push rax
000073dfa87dbbe4  push rcx
000073dfa87dbbe5  push rdx
000073dfa87dbbe6  push rdi
000073dfa87dbbe7  push rsi
000073dfa87dbbe8  push r8
000073dfa87dbbea  push r9
000073dfa87dbbec  push r10
000073dfa87dbbee  push r11
000073dfa87dbbf0  sub rsp, 0xF0
000073dfa87dbbf7  vmovaps [rsp], xmm0
000073dfa87dbbfc  vmovaps [rsp+0x10], xmm1
000073dfa87dbc02  vmovaps [rsp+0x20], xmm2
000073dfa87dbc08  vmovaps [rsp+0x30], xmm3
000073dfa87dbc0e  vmovaps [rsp+0x40], xmm4
000073dfa87dbc14  vmovaps [rsp+0x50], xmm5
000073dfa87dbc1a  vmovaps [rsp+0x60], xmm6
000073dfa87dbc20  vmovaps [rsp+0x70], xmm7
000073dfa87dbc26  vmovaps [rsp+0x80], xmm8
000073dfa87dbc2f  vmovaps [rsp+0x90], xmm9
000073dfa87dbc38  vmovaps [rsp+0xA0], xmm10
000073dfa87dbc41  vmovaps [rsp+0xB0], xmm11
000073dfa87dbc4a  vmovaps [rsp+0xC0], xmm12
000073dfa87dbc53  vmovaps [rsp+0xD0], xmm13
000073dfa87dbc5c  vmovaps [rsp+0xE0], xmm15
000073dfa87dbc65  sub rsp, 0x30
000073dfa87dbc69  movaps [rsp], xmm14
000073dfa87dbc6e  movaps [rsp+0x10], xmm2
000073dfa87dbc73  movaps [rsp+0x20], xmm1
000073dfa87dbc78  lea rdi, [rsp]
000073dfa87dbc7c  mov esi, 0x00
000073dfa87dbc81  mov rax, 0x593AA1DA4530
000073dfa87dbc8b  call rax
000073dfa87dbc8d  movaps xmm14, [rsp]
000073dfa87dbc92  add rsp, 0x30
000073dfa87dbc96  vmovaps xmm0, [rsp]
000073dfa87dbc9b  vmovaps xmm1, [rsp+0x10]
000073dfa87dbca1  vmovaps xmm2, [rsp+0x20]
000073dfa87dbca7  vmovaps xmm3, [rsp+0x30]
000073dfa87dbcad  vmovaps xmm4, [rsp+0x40]
000073dfa87dbcb3  vmovaps xmm5, [rsp+0x50]
000073dfa87dbcb9  vmovaps xmm6, [rsp+0x60]
000073dfa87dbcbf  vmovaps xmm7, [rsp+0x70]
000073dfa87dbcc5  vmovaps xmm8, [rsp+0x80]
000073dfa87dbcce  vmovaps xmm9, [rsp+0x90]
000073dfa87dbcd7  vmovaps xmm10, [rsp+0xA0]
000073dfa87dbce0  vmovaps xmm11, [rsp+0xB0]
000073dfa87dbce9  vmovaps xmm12, [rsp+0xC0]
000073dfa87dbcf2  vmovaps xmm13, [rsp+0xD0]
000073dfa87dbcfb  vmovaps xmm15, [rsp+0xE0]
000073dfa87dbd04  add rsp, 0xF0
000073dfa87dbd0b  pop r11
000073dfa87dbd0d  pop r10
000073dfa87dbd0f  pop r9
000073dfa87dbd11  pop r8
000073dfa87dbd13  pop rsi
000073dfa87dbd14  pop rdi
000073dfa87dbd15  pop rdx
000073dfa87dbd16  pop rcx
000073dfa87dbd17  pop rax
000073dfa87dbd18  add rsp, 0x08
000073dfa87dbd1c  jmp 0x000073DFA87D92FD
000073dfa87dbd21  sub rsp, 0x08
000073dfa87dbd25  push rax
000073dfa87dbd26  push rcx
000073dfa87dbd27  push rdx
000073dfa87dbd28  push rdi
000073dfa87dbd29  push rsi
000073dfa87dbd2a  push r8
000073dfa87dbd2c  push r9
000073dfa87dbd2e  push r10
000073dfa87dbd30  push r11
000073dfa87dbd32  sub rsp, 0xF0
000073dfa87dbd39  vmovaps [rsp], xmm0
000073dfa87dbd3e  vmovaps [rsp+0x10], xmm2
000073dfa87dbd44  vmovaps [rsp+0x20], xmm3
000073dfa87dbd4a  vmovaps [rsp+0x30], xmm4
000073dfa87dbd50  vmovaps [rsp+0x40], xmm5
000073dfa87dbd56  vmovaps [rsp+0x50], xmm6
000073dfa87dbd5c  vmovaps [rsp+0x60], xmm7
000073dfa87dbd62  vmovaps [rsp+0x70], xmm8
000073dfa87dbd68  vmovaps [rsp+0x80], xmm9
000073dfa87dbd71  vmovaps [rsp+0x90], xmm10
000073dfa87dbd7a  vmovaps [rsp+0xA0], xmm11
000073dfa87dbd83  vmovaps [rsp+0xB0], xmm12
000073dfa87dbd8c  vmovaps [rsp+0xC0], xmm13
000073dfa87dbd95  vmovaps [rsp+0xD0], xmm14
000073dfa87dbd9e  vmovaps [rsp+0xE0], xmm15
000073dfa87dbda7  sub rsp, 0x30
000073dfa87dbdab  movaps [rsp], xmm1
000073dfa87dbdaf  movaps [rsp+0x10], xmm4
000073dfa87dbdb4  movaps [rsp+0x20], xmm9
000073dfa87dbdba  lea rdi, [rsp]
000073dfa87dbdbe  mov esi, 0x00
000073dfa87dbdc3  mov rax, 0x593AA1DA4530
000073dfa87dbdcd  call rax
000073dfa87dbdcf  movaps xmm1, [rsp]
000073dfa87dbdd3  add rsp, 0x30
000073dfa87dbdd7  vmovaps xmm0, [rsp]
000073dfa87dbddc  vmovaps xmm2, [rsp+0x10]
000073dfa87dbde2  vmovaps xmm3, [rsp+0x20]
000073dfa87dbde8  vmovaps xmm4, [rsp+0x30]
000073dfa87dbdee  vmovaps xmm5, [rsp+0x40]
000073dfa87dbdf4  vmovaps xmm6, [rsp+0x50]
000073dfa87dbdfa  vmovaps xmm7, [rsp+0x60]
000073dfa87dbe00  vmovaps xmm8, [rsp+0x70]
000073dfa87dbe06  vmovaps xmm9, [rsp+0x80]
000073dfa87dbe0f  vmovaps xmm10, [rsp+0x90]
000073dfa87dbe18  vmovaps xmm11, [rsp+0xA0]
000073dfa87dbe21  vmovaps xmm12, [rsp+0xB0]
000073dfa87dbe2a  vmovaps xmm13, [rsp+0xC0]
000073dfa87dbe33  vmovaps xmm14, [rsp+0xD0]
000073dfa87dbe3c  vmovaps xmm15, [rsp+0xE0]
000073dfa87dbe45  add rsp, 0xF0
000073dfa87dbe4c  pop r11
000073dfa87dbe4e  pop r10
000073dfa87dbe50  pop r9
000073dfa87dbe52  pop r8
000073dfa87dbe54  pop rsi
000073dfa87dbe55  pop rdi
000073dfa87dbe56  pop rdx
000073dfa87dbe57  pop rcx
000073dfa87dbe58  pop rax
000073dfa87dbe59  add rsp, 0x08
000073dfa87dbe5d  jmp 0x000073DFA87D931B
000073dfa87dbe62  sub rsp, 0x08
000073dfa87dbe66  push rax
000073dfa87dbe67  push rcx
000073dfa87dbe68  push rdx
000073dfa87dbe69  push rdi
000073dfa87dbe6a  push rsi
000073dfa87dbe6b  push r8
000073dfa87dbe6d  push r9
000073dfa87dbe6f  push r10
000073dfa87dbe71  push r11
000073dfa87dbe73  sub rsp, 0xF0
000073dfa87dbe7a  vmovaps [rsp], xmm0
000073dfa87dbe7f  vmovaps [rsp+0x10], xmm1
000073dfa87dbe85  vmovaps [rsp+0x20], xmm2
000073dfa87dbe8b  vmovaps [rsp+0x30], xmm3
000073dfa87dbe91  vmovaps [rsp+0x40], xmm5
000073dfa87dbe97  vmovaps [rsp+0x50], xmm6
000073dfa87dbe9d  vmovaps [rsp+0x60], xmm7
000073dfa87dbea3  vmovaps [rsp+0x70], xmm8
000073dfa87dbea9  vmovaps [rsp+0x80], xmm9
000073dfa87dbeb2  vmovaps [rsp+0x90], xmm10
000073dfa87dbebb  vmovaps [rsp+0xA0], xmm11
000073dfa87dbec4  vmovaps [rsp+0xB0], xmm12
000073dfa87dbecd  vmovaps [rsp+0xC0], xmm13
000073dfa87dbed6  vmovaps [rsp+0xD0], xmm14
000073dfa87dbedf  vmovaps [rsp+0xE0], xmm15
000073dfa87dbee8  sub rsp, 0x30
000073dfa87dbeec  movaps [rsp], xmm4
000073dfa87dbef0  movaps [rsp+0x10], xmm2
000073dfa87dbef5  movaps [rsp+0x20], xmm9
000073dfa87dbefb  lea rdi, [rsp]
000073dfa87dbeff  mov esi, 0x00
000073dfa87dbf04  mov rax, 0x593AA1DA4530
000073dfa87dbf0e  call rax
000073dfa87dbf10  movaps xmm4, [rsp]
000073dfa87dbf14  add rsp, 0x30
000073dfa87dbf18  vmovaps xmm0, [rsp]
000073dfa87dbf1d  vmovaps xmm1, [rsp+0x10]
000073dfa87dbf23  vmovaps xmm2, [rsp+0x20]
000073dfa87dbf29  vmovaps xmm3, [rsp+0x30]
000073dfa87dbf2f  vmovaps xmm5, [rsp+0x40]
000073dfa87dbf35  vmovaps xmm6, [rsp+0x50]
000073dfa87dbf3b  vmovaps xmm7, [rsp+0x60]
000073dfa87dbf41  vmovaps xmm8, [rsp+0x70]
000073dfa87dbf47  vmovaps xmm9, [rsp+0x80]
000073dfa87dbf50  vmovaps xmm10, [rsp+0x90]
000073dfa87dbf59  vmovaps xmm11, [rsp+0xA0]
000073dfa87dbf62  vmovaps xmm12, [rsp+0xB0]
000073dfa87dbf6b  vmovaps xmm13, [rsp+0xC0]
000073dfa87dbf74  vmovaps xmm14, [rsp+0xD0]
000073dfa87dbf7d  vmovaps xmm15, [rsp+0xE0]
000073dfa87dbf86  add rsp, 0xF0
000073dfa87dbf8d  pop r11
000073dfa87dbf8f  pop r10
000073dfa87dbf91  pop r9
000073dfa87dbf93  pop r8
000073dfa87dbf95  pop rsi
000073dfa87dbf96  pop rdi
000073dfa87dbf97  pop rdx
000073dfa87dbf98  pop rcx
000073dfa87dbf99  pop rax
000073dfa87dbf9a  add rsp, 0x08
000073dfa87dbf9e  jmp 0x000073DFA87D934B
000073dfa87dbfa3  sub rsp, 0x08
000073dfa87dbfa7  push rax
000073dfa87dbfa8  push rcx
000073dfa87dbfa9  push rdx
000073dfa87dbfaa  push rdi
000073dfa87dbfab  push rsi
000073dfa87dbfac  push r8
000073dfa87dbfae  push r9
000073dfa87dbfb0  push r10
000073dfa87dbfb2  push r11
000073dfa87dbfb4  sub rsp, 0xF0
000073dfa87dbfbb  vmovaps [rsp], xmm0
000073dfa87dbfc0  vmovaps [rsp+0x10], xmm1
000073dfa87dbfc6  vmovaps [rsp+0x20], xmm2
000073dfa87dbfcc  vmovaps [rsp+0x30], xmm3
000073dfa87dbfd2  vmovaps [rsp+0x40], xmm4
000073dfa87dbfd8  vmovaps [rsp+0x50], xmm5
000073dfa87dbfde  vmovaps [rsp+0x60], xmm6
000073dfa87dbfe4  vmovaps [rsp+0x70], xmm7
000073dfa87dbfea  vmovaps [rsp+0x80], xmm8
000073dfa87dbff3  vmovaps [rsp+0x90], xmm10
000073dfa87dbffc  vmovaps [rsp+0xA0], xmm11
000073dfa87dc005  vmovaps [rsp+0xB0], xmm12
000073dfa87dc00e  vmovaps [rsp+0xC0], xmm13
000073dfa87dc017  vmovaps [rsp+0xD0], xmm14
000073dfa87dc020  vmovaps [rsp+0xE0], xmm15
000073dfa87dc029  sub rsp, 0x30
000073dfa87dc02d  movaps [rsp], xmm9
000073dfa87dc032  movaps [rsp+0x10], xmm2
000073dfa87dc037  movaps [rsp+0x20], xmm1
000073dfa87dc03c  lea rdi, [rsp]
000073dfa87dc040  mov esi, 0x00
000073dfa87dc045  mov rax, 0x593AA1DA4530
000073dfa87dc04f  call rax
000073dfa87dc051  movaps xmm9, [rsp]
000073dfa87dc056  add rsp, 0x30
000073dfa87dc05a  vmovaps xmm0, [rsp]
000073dfa87dc05f  vmovaps xmm1, [rsp+0x10]
000073dfa87dc065  vmovaps xmm2, [rsp+0x20]
000073dfa87dc06b  vmovaps xmm3, [rsp+0x30]
000073dfa87dc071  vmovaps xmm4, [rsp+0x40]
000073dfa87dc077  vmovaps xmm5, [rsp+0x50]
000073dfa87dc07d  vmovaps xmm6, [rsp+0x60]
000073dfa87dc083  vmovaps xmm7, [rsp+0x70]
000073dfa87dc089  vmovaps xmm8, [rsp+0x80]
000073dfa87dc092  vmovaps xmm10, [rsp+0x90]
000073dfa87dc09b  vmovaps xmm11, [rsp+0xA0]
000073dfa87dc0a4  vmovaps xmm12, [rsp+0xB0]
000073dfa87dc0ad  vmovaps xmm13, [rsp+0xC0]
000073dfa87dc0b6  vmovaps xmm14, [rsp+0xD0]
000073dfa87dc0bf  vmovaps xmm15, [rsp+0xE0]
000073dfa87dc0c8  add rsp, 0xF0
000073dfa87dc0cf  pop r11
000073dfa87dc0d1  pop r10
000073dfa87dc0d3  pop r9
000073dfa87dc0d5  pop r8
000073dfa87dc0d7  pop rsi
000073dfa87dc0d8  pop rdi
000073dfa87dc0d9  pop rdx
000073dfa87dc0da  pop rcx
000073dfa87dc0db  pop rax
000073dfa87dc0dc  add rsp, 0x08
000073dfa87dc0e0  jmp 0x000073DFA87D9381
000073dfa87dc0e5  sub rsp, 0x08
000073dfa87dc0e9  push rax
000073dfa87dc0ea  push rcx
000073dfa87dc0eb  push rdx
000073dfa87dc0ec  push rdi
000073dfa87dc0ed  push rsi
000073dfa87dc0ee  push r8
000073dfa87dc0f0  push r9
000073dfa87dc0f2  push r10
000073dfa87dc0f4  push r11
000073dfa87dc0f6  sub rsp, 0xF0
000073dfa87dc0fd  vmovaps [rsp], xmm0
000073dfa87dc102  vmovaps [rsp+0x10], xmm2
000073dfa87dc108  vmovaps [rsp+0x20], xmm3
000073dfa87dc10e  vmovaps [rsp+0x30], xmm4
000073dfa87dc114  vmovaps [rsp+0x40], xmm5
000073dfa87dc11a  vmovaps [rsp+0x50], xmm6
000073dfa87dc120  vmovaps [rsp+0x60], xmm7
000073dfa87dc126  vmovaps [rsp+0x70], xmm8
000073dfa87dc12c  vmovaps [rsp+0x80], xmm9
000073dfa87dc135  vmovaps [rsp+0x90], xmm10
000073dfa87dc13e  vmovaps [rsp+0xA0], xmm11
000073dfa87dc147  vmovaps [rsp+0xB0], xmm12
000073dfa87dc150  vmovaps [rsp+0xC0], xmm13
000073dfa87dc159  vmovaps [rsp+0xD0], xmm14
000073dfa87dc162  vmovaps [rsp+0xE0], xmm15
000073dfa87dc16b  sub rsp, 0x30
000073dfa87dc16f  movaps [rsp], xmm1
000073dfa87dc173  movaps [rsp+0x10], xmm15
000073dfa87dc179  movaps [rsp+0x20], xmm6
000073dfa87dc17e  lea rdi, [rsp]
000073dfa87dc182  mov esi, 0x00
000073dfa87dc187  mov rax, 0x593AA1DA4530
000073dfa87dc191  call rax
000073dfa87dc193  movaps xmm1, [rsp]
000073dfa87dc197  add rsp, 0x30
000073dfa87dc19b  vmovaps xmm0, [rsp]
000073dfa87dc1a0  vmovaps xmm2, [rsp+0x10]
000073dfa87dc1a6  vmovaps xmm3, [rsp+0x20]
000073dfa87dc1ac  vmovaps xmm4, [rsp+0x30]
000073dfa87dc1b2  vmovaps xmm5, [rsp+0x40]
000073dfa87dc1b8  vmovaps xmm6, [rsp+0x50]
000073dfa87dc1be  vmovaps xmm7, [rsp+0x60]
000073dfa87dc1c4  vmovaps xmm8, [rsp+0x70]
000073dfa87dc1ca  vmovaps xmm9, [rsp+0x80]
000073dfa87dc1d3  vmovaps xmm10, [rsp+0x90]
000073dfa87dc1dc  vmovaps xmm11, [rsp+0xA0]
000073dfa87dc1e5  vmovaps xmm12, [rsp+0xB0]
000073dfa87dc1ee  vmovaps xmm13, [rsp+0xC0]
000073dfa87dc1f7  vmovaps xmm14, [rsp+0xD0]
000073dfa87dc200  vmovaps xmm15, [rsp+0xE0]
000073dfa87dc209  add rsp, 0xF0
000073dfa87dc210  pop r11
000073dfa87dc212  pop r10
000073dfa87dc214  pop r9
000073dfa87dc216  pop r8
000073dfa87dc218  pop rsi
000073dfa87dc219  pop rdi
000073dfa87dc21a  pop rdx
000073dfa87dc21b  pop rcx
000073dfa87dc21c  pop rax
000073dfa87dc21d  add rsp, 0x08
000073dfa87dc221  jmp 0x000073DFA87D93A2
000073dfa87dc226  sub rsp, 0x08
000073dfa87dc22a  push rax
000073dfa87dc22b  push rcx
000073dfa87dc22c  push rdx
000073dfa87dc22d  push rdi
000073dfa87dc22e  push rsi
000073dfa87dc22f  push r8
000073dfa87dc231  push r9
000073dfa87dc233  push r10
000073dfa87dc235  push r11
000073dfa87dc237  sub rsp, 0xF0
000073dfa87dc23e  vmovaps [rsp], xmm0
000073dfa87dc243  vmovaps [rsp+0x10], xmm1
000073dfa87dc249  vmovaps [rsp+0x20], xmm2
000073dfa87dc24f  vmovaps [rsp+0x30], xmm3
000073dfa87dc255  vmovaps [rsp+0x40], xmm4
000073dfa87dc25b  vmovaps [rsp+0x50], xmm5
000073dfa87dc261  vmovaps [rsp+0x60], xmm6
000073dfa87dc267  vmovaps [rsp+0x70], xmm7
000073dfa87dc26d  vmovaps [rsp+0x80], xmm8
000073dfa87dc276  vmovaps [rsp+0x90], xmm9
000073dfa87dc27f  vmovaps [rsp+0xA0], xmm10
000073dfa87dc288  vmovaps [rsp+0xB0], xmm11
000073dfa87dc291  vmovaps [rsp+0xC0], xmm12
000073dfa87dc29a  vmovaps [rsp+0xD0], xmm13
000073dfa87dc2a3  vmovaps [rsp+0xE0], xmm14
000073dfa87dc2ac  sub rsp, 0x30
000073dfa87dc2b0  movaps [rsp], xmm15
000073dfa87dc2b5  movaps [rsp+0x10], xmm5
000073dfa87dc2ba  movaps [rsp+0x20], xmm3
000073dfa87dc2bf  lea rdi, [rsp]
000073dfa87dc2c3  mov esi, 0x00
000073dfa87dc2c8  mov rax, 0x593AA1DA4530
000073dfa87dc2d2  call rax
000073dfa87dc2d4  movaps xmm15, [rsp]
000073dfa87dc2d9  add rsp, 0x30
000073dfa87dc2dd  vmovaps xmm0, [rsp]
000073dfa87dc2e2  vmovaps xmm1, [rsp+0x10]
000073dfa87dc2e8  vmovaps xmm2, [rsp+0x20]
000073dfa87dc2ee  vmovaps xmm3, [rsp+0x30]
000073dfa87dc2f4  vmovaps xmm4, [rsp+0x40]
000073dfa87dc2fa  vmovaps xmm5, [rsp+0x50]
000073dfa87dc300  vmovaps xmm6, [rsp+0x60]
000073dfa87dc306  vmovaps xmm7, [rsp+0x70]
000073dfa87dc30c  vmovaps xmm8, [rsp+0x80]
000073dfa87dc315  vmovaps xmm9, [rsp+0x90]
000073dfa87dc31e  vmovaps xmm10, [rsp+0xA0]
000073dfa87dc327  vmovaps xmm11, [rsp+0xB0]
000073dfa87dc330  vmovaps xmm12, [rsp+0xC0]
000073dfa87dc339  vmovaps xmm13, [rsp+0xD0]
000073dfa87dc342  vmovaps xmm14, [rsp+0xE0]
000073dfa87dc34b  add rsp, 0xF0
000073dfa87dc352  pop r11
000073dfa87dc354  pop r10
000073dfa87dc356  pop r9
000073dfa87dc358  pop r8
000073dfa87dc35a  pop rsi
000073dfa87dc35b  pop rdi
000073dfa87dc35c  pop rdx
000073dfa87dc35d  pop rcx
000073dfa87dc35e  pop rax
000073dfa87dc35f  add rsp, 0x08
000073dfa87dc363  jmp 0x000073DFA87D93BC
000073dfa87dc368  sub rsp, 0x08
000073dfa87dc36c  push rax
000073dfa87dc36d  push rcx
000073dfa87dc36e  push rdx
000073dfa87dc36f  push rdi
000073dfa87dc370  push rsi
000073dfa87dc371  push r8
000073dfa87dc373  push r9
000073dfa87dc375  push r10
000073dfa87dc377  push r11
000073dfa87dc379  sub rsp, 0xF0
000073dfa87dc380  vmovaps [rsp], xmm0
000073dfa87dc385  vmovaps [rsp+0x10], xmm1
000073dfa87dc38b  vmovaps [rsp+0x20], xmm2
000073dfa87dc391  vmovaps [rsp+0x30], xmm3
000073dfa87dc397  vmovaps [rsp+0x40], xmm4
000073dfa87dc39d  vmovaps [rsp+0x50], xmm6
000073dfa87dc3a3  vmovaps [rsp+0x60], xmm7
000073dfa87dc3a9  vmovaps [rsp+0x70], xmm8
000073dfa87dc3af  vmovaps [rsp+0x80], xmm9
000073dfa87dc3b8  vmovaps [rsp+0x90], xmm10
000073dfa87dc3c1  vmovaps [rsp+0xA0], xmm11
000073dfa87dc3ca  vmovaps [rsp+0xB0], xmm12
000073dfa87dc3d3  vmovaps [rsp+0xC0], xmm13
000073dfa87dc3dc  vmovaps [rsp+0xD0], xmm14
000073dfa87dc3e5  vmovaps [rsp+0xE0], xmm15
000073dfa87dc3ee  sub rsp, 0x30
000073dfa87dc3f2  movaps [rsp], xmm5
000073dfa87dc3f6  movaps [rsp+0x10], xmm8
000073dfa87dc3fc  movaps [rsp+0x20], xmm6
000073dfa87dc401  lea rdi, [rsp]
000073dfa87dc405  mov esi, 0x00
000073dfa87dc40a  mov rax, 0x593AA1DA4530
000073dfa87dc414  call rax
000073dfa87dc416  movaps xmm5, [rsp]
000073dfa87dc41a  add rsp, 0x30
000073dfa87dc41e  vmovaps xmm0, [rsp]
000073dfa87dc423  vmovaps xmm1, [rsp+0x10]
000073dfa87dc429  vmovaps xmm2, [rsp+0x20]
000073dfa87dc42f  vmovaps xmm3, [rsp+0x30]
000073dfa87dc435  vmovaps xmm4, [rsp+0x40]
000073dfa87dc43b  vmovaps xmm6, [rsp+0x50]
000073dfa87dc441  vmovaps xmm7, [rsp+0x60]
000073dfa87dc447  vmovaps xmm8, [rsp+0x70]
000073dfa87dc44d  vmovaps xmm9, [rsp+0x80]
000073dfa87dc456  vmovaps xmm10, [rsp+0x90]
000073dfa87dc45f  vmovaps xmm11, [rsp+0xA0]
000073dfa87dc468  vmovaps xmm12, [rsp+0xB0]
000073dfa87dc471  vmovaps xmm13, [rsp+0xC0]
000073dfa87dc47a  vmovaps xmm14, [rsp+0xD0]
000073dfa87dc483  vmovaps xmm15, [rsp+0xE0]
000073dfa87dc48c  add rsp, 0xF0
000073dfa87dc493  pop r11
000073dfa87dc495  pop r10
000073dfa87dc497  pop r9
000073dfa87dc499  pop r8
000073dfa87dc49b  pop rsi
000073dfa87dc49c  pop rdi
000073dfa87dc49d  pop rdx
000073dfa87dc49e  pop rcx
000073dfa87dc49f  pop rax
000073dfa87dc4a0  add rsp, 0x08
000073dfa87dc4a4  jmp 0x000073DFA87D93E0
000073dfa87dc4a9  sub rsp, 0x08
000073dfa87dc4ad  push rax
000073dfa87dc4ae  push rcx
000073dfa87dc4af  push rdx
000073dfa87dc4b0  push rdi
000073dfa87dc4b1  push rsi
000073dfa87dc4b2  push r8
000073dfa87dc4b4  push r9
000073dfa87dc4b6  push r10
000073dfa87dc4b8  push r11
000073dfa87dc4ba  sub rsp, 0xF0
000073dfa87dc4c1  vmovaps [rsp], xmm0
000073dfa87dc4c6  vmovaps [rsp+0x10], xmm1
000073dfa87dc4cc  vmovaps [rsp+0x20], xmm2
000073dfa87dc4d2  vmovaps [rsp+0x30], xmm3
000073dfa87dc4d8  vmovaps [rsp+0x40], xmm4
000073dfa87dc4de  vmovaps [rsp+0x50], xmm5
000073dfa87dc4e4  vmovaps [rsp+0x60], xmm7
000073dfa87dc4ea  vmovaps [rsp+0x70], xmm8
000073dfa87dc4f0  vmovaps [rsp+0x80], xmm9
000073dfa87dc4f9  vmovaps [rsp+0x90], xmm10
000073dfa87dc502  vmovaps [rsp+0xA0], xmm11
000073dfa87dc50b  vmovaps [rsp+0xB0], xmm12
000073dfa87dc514  vmovaps [rsp+0xC0], xmm13
000073dfa87dc51d  vmovaps [rsp+0xD0], xmm14
000073dfa87dc526  vmovaps [rsp+0xE0], xmm15
000073dfa87dc52f  sub rsp, 0x30
000073dfa87dc533  movaps [rsp], xmm6
000073dfa87dc537  movaps [rsp+0x10], xmm10
000073dfa87dc53d  movaps [rsp+0x20], xmm8
000073dfa87dc543  lea rdi, [rsp]
000073dfa87dc547  mov esi, 0x00
000073dfa87dc54c  mov rax, 0x593AA1DA4530
000073dfa87dc556  call rax
000073dfa87dc558  movaps xmm6, [rsp]
000073dfa87dc55c  add rsp, 0x30
000073dfa87dc560  vmovaps xmm0, [rsp]
000073dfa87dc565  vmovaps xmm1, [rsp+0x10]
000073dfa87dc56b  vmovaps xmm2, [rsp+0x20]
000073dfa87dc571  vmovaps xmm3, [rsp+0x30]
000073dfa87dc577  vmovaps xmm4, [rsp+0x40]
000073dfa87dc57d  vmovaps xmm5, [rsp+0x50]
000073dfa87dc583  vmovaps xmm7, [rsp+0x60]
000073dfa87dc589  vmovaps xmm8, [rsp+0x70]
000073dfa87dc58f  vmovaps xmm9, [rsp+0x80]
000073dfa87dc598  vmovaps xmm10, [rsp+0x90]
000073dfa87dc5a1  vmovaps xmm11, [rsp+0xA0]
000073dfa87dc5aa  vmovaps xmm12, [rsp+0xB0]
000073dfa87dc5b3  vmovaps xmm13, [rsp+0xC0]
000073dfa87dc5bc  vmovaps xmm14, [rsp+0xD0]
000073dfa87dc5c5  vmovaps xmm15, [rsp+0xE0]
000073dfa87dc5ce  add rsp, 0xF0
000073dfa87dc5d5  pop r11
000073dfa87dc5d7  pop r10
000073dfa87dc5d9  pop r9
000073dfa87dc5db  pop r8
000073dfa87dc5dd  pop rsi
000073dfa87dc5de  pop rdi
000073dfa87dc5df  pop rdx
000073dfa87dc5e0  pop rcx
000073dfa87dc5e1  pop rax
000073dfa87dc5e2  add rsp, 0x08
000073dfa87dc5e6  jmp 0x000073DFA87D9405
000073dfa87dc5eb  sub rsp, 0x08
000073dfa87dc5ef  push rax
000073dfa87dc5f0  push rcx
000073dfa87dc5f1  push rdx
000073dfa87dc5f2  push rdi
000073dfa87dc5f3  push rsi
000073dfa87dc5f4  push r8
000073dfa87dc5f6  push r9
000073dfa87dc5f8  push r10
000073dfa87dc5fa  push r11
000073dfa87dc5fc  sub rsp, 0xF0
000073dfa87dc603  vmovaps [rsp], xmm0
000073dfa87dc608  vmovaps [rsp+0x10], xmm1
000073dfa87dc60e  vmovaps [rsp+0x20], xmm2
000073dfa87dc614  vmovaps [rsp+0x30], xmm3
000073dfa87dc61a  vmovaps [rsp+0x40], xmm4
000073dfa87dc620  vmovaps [rsp+0x50], xmm5
000073dfa87dc626  vmovaps [rsp+0x60], xmm6
000073dfa87dc62c  vmovaps [rsp+0x70], xmm7
000073dfa87dc632  vmovaps [rsp+0x80], xmm8
000073dfa87dc63b  vmovaps [rsp+0x90], xmm9
000073dfa87dc644  vmovaps [rsp+0xA0], xmm11
000073dfa87dc64d  vmovaps [rsp+0xB0], xmm12
000073dfa87dc656  vmovaps [rsp+0xC0], xmm13
000073dfa87dc65f  vmovaps [rsp+0xD0], xmm14
000073dfa87dc668  vmovaps [rsp+0xE0], xmm15
000073dfa87dc671  sub rsp, 0x30
000073dfa87dc675  movaps [rsp], xmm10
000073dfa87dc67a  movaps [rsp+0x10], xmm8
000073dfa87dc680  movaps [rsp+0x20], xmm14
000073dfa87dc686  lea rdi, [rsp]
000073dfa87dc68a  mov esi, 0x00
000073dfa87dc68f  mov rax, 0x593AA1DA4530
000073dfa87dc699  call rax
000073dfa87dc69b  movaps xmm10, [rsp]
000073dfa87dc6a0  add rsp, 0x30
000073dfa87dc6a4  vmovaps xmm0, [rsp]
000073dfa87dc6a9  vmovaps xmm1, [rsp+0x10]
000073dfa87dc6af  vmovaps xmm2, [rsp+0x20]
000073dfa87dc6b5  vmovaps xmm3, [rsp+0x30]
000073dfa87dc6bb  vmovaps xmm4, [rsp+0x40]
000073dfa87dc6c1  vmovaps xmm5, [rsp+0x50]
000073dfa87dc6c7  vmovaps xmm6, [rsp+0x60]
000073dfa87dc6cd  vmovaps xmm7, [rsp+0x70]
000073dfa87dc6d3  vmovaps xmm8, [rsp+0x80]
000073dfa87dc6dc  vmovaps xmm9, [rsp+0x90]
000073dfa87dc6e5  vmovaps xmm11, [rsp+0xA0]
000073dfa87dc6ee  vmovaps xmm12, [rsp+0xB0]
000073dfa87dc6f7  vmovaps xmm13, [rsp+0xC0]
000073dfa87dc700  vmovaps xmm14, [rsp+0xD0]
000073dfa87dc709  vmovaps xmm15, [rsp+0xE0]
000073dfa87dc712  add rsp, 0xF0
000073dfa87dc719  pop r11
000073dfa87dc71b  pop r10
000073dfa87dc71d  pop r9
000073dfa87dc71f  pop r8
000073dfa87dc721  pop rsi
000073dfa87dc722  pop rdi
000073dfa87dc723  pop rdx
000073dfa87dc724  pop rcx
000073dfa87dc725  pop rax
000073dfa87dc726  add rsp, 0x08
000073dfa87dc72a  jmp 0x000073DFA87D9425
000073dfa87dc72f  sub rsp, 0x08
000073dfa87dc733  push rax
000073dfa87dc734  push rcx
000073dfa87dc735  push rdx
000073dfa87dc736  push rdi
000073dfa87dc737  push rsi
000073dfa87dc738  push r8
000073dfa87dc73a  push r9
000073dfa87dc73c  push r10
000073dfa87dc73e  push r11
000073dfa87dc740  sub rsp, 0xF0
000073dfa87dc747  vmovaps [rsp], xmm0
000073dfa87dc74c  vmovaps [rsp+0x10], xmm1
000073dfa87dc752  vmovaps [rsp+0x20], xmm2
000073dfa87dc758  vmovaps [rsp+0x30], xmm3
000073dfa87dc75e  vmovaps [rsp+0x40], xmm4
000073dfa87dc764  vmovaps [rsp+0x50], xmm5
000073dfa87dc76a  vmovaps [rsp+0x60], xmm6
000073dfa87dc770  vmovaps [rsp+0x70], xmm7
000073dfa87dc776  vmovaps [rsp+0x80], xmm8
000073dfa87dc77f  vmovaps [rsp+0x90], xmm9
000073dfa87dc788  vmovaps [rsp+0xA0], xmm10
000073dfa87dc791  vmovaps [rsp+0xB0], xmm11
000073dfa87dc79a  vmovaps [rsp+0xC0], xmm12
000073dfa87dc7a3  vmovaps [rsp+0xD0], xmm13
000073dfa87dc7ac  vmovaps [rsp+0xE0], xmm15
000073dfa87dc7b5  sub rsp, 0x30
000073dfa87dc7b9  movaps [rsp], xmm14
000073dfa87dc7be  movaps [rsp+0x10], xmm8
000073dfa87dc7c4  movaps [rsp+0x20], xmm4
000073dfa87dc7c9  lea rdi, [rsp]
000073dfa87dc7cd  mov esi, 0x00
000073dfa87dc7d2  mov rax, 0x593AA1DA4530
000073dfa87dc7dc  call rax
000073dfa87dc7de  movaps xmm14, [rsp]
000073dfa87dc7e3  add rsp, 0x30
000073dfa87dc7e7  vmovaps xmm0, [rsp]
000073dfa87dc7ec  vmovaps xmm1, [rsp+0x10]
000073dfa87dc7f2  vmovaps xmm2, [rsp+0x20]
000073dfa87dc7f8  vmovaps xmm3, [rsp+0x30]
000073dfa87dc7fe  vmovaps xmm4, [rsp+0x40]
000073dfa87dc804  vmovaps xmm5, [rsp+0x50]
000073dfa87dc80a  vmovaps xmm6, [rsp+0x60]
000073dfa87dc810  vmovaps xmm7, [rsp+0x70]
000073dfa87dc816  vmovaps xmm8, [rsp+0x80]
000073dfa87dc81f  vmovaps xmm9, [rsp+0x90]
000073dfa87dc828  vmovaps xmm10, [rsp+0xA0]
000073dfa87dc831  vmovaps xmm11, [rsp+0xB0]
000073dfa87dc83a  vmovaps xmm12, [rsp+0xC0]
000073dfa87dc843  vmovaps xmm13, [rsp+0xD0]
000073dfa87dc84c  vmovaps xmm15, [rsp+0xE0]
000073dfa87dc855  add rsp, 0xF0
000073dfa87dc85c  pop r11
000073dfa87dc85e  pop r10
000073dfa87dc860  pop r9
000073dfa87dc862  pop r8
000073dfa87dc864  pop rsi
000073dfa87dc865  pop rdi
000073dfa87dc866  pop rdx
000073dfa87dc867  pop rcx
000073dfa87dc868  pop rax
000073dfa87dc869  add rsp, 0x08
000073dfa87dc86d  jmp 0x000073DFA87D9445
000073dfa87dc872  sub rsp, 0x08
000073dfa87dc876  push rax
000073dfa87dc877  push rcx
000073dfa87dc878  push rdx
000073dfa87dc879  push rdi
000073dfa87dc87a  push rsi
000073dfa87dc87b  push r8
000073dfa87dc87d  push r9
000073dfa87dc87f  push r10
000073dfa87dc881  push r11
000073dfa87dc883  sub rsp, 0xF0
000073dfa87dc88a  vmovaps [rsp], xmm0
000073dfa87dc88f  vmovaps [rsp+0x10], xmm1
000073dfa87dc895  vmovaps [rsp+0x20], xmm2
000073dfa87dc89b  vmovaps [rsp+0x30], xmm3
000073dfa87dc8a1  vmovaps [rsp+0x40], xmm5
000073dfa87dc8a7  vmovaps [rsp+0x50], xmm6
000073dfa87dc8ad  vmovaps [rsp+0x60], xmm7
000073dfa87dc8b3  vmovaps [rsp+0x70], xmm8
000073dfa87dc8b9  vmovaps [rsp+0x80], xmm9
000073dfa87dc8c2  vmovaps [rsp+0x90], xmm10
000073dfa87dc8cb  vmovaps [rsp+0xA0], xmm11
000073dfa87dc8d4  vmovaps [rsp+0xB0], xmm12
000073dfa87dc8dd  vmovaps [rsp+0xC0], xmm13
000073dfa87dc8e6  vmovaps [rsp+0xD0], xmm14
000073dfa87dc8ef  vmovaps [rsp+0xE0], xmm15
000073dfa87dc8f8  sub rsp, 0x30
000073dfa87dc8fc  movaps [rsp], xmm4
000073dfa87dc900  movaps [rsp+0x10], xmm13
000073dfa87dc906  movaps [rsp+0x20], xmm8
000073dfa87dc90c  lea rdi, [rsp]
000073dfa87dc910  mov esi, 0x00
000073dfa87dc915  mov rax, 0x593AA1DA4530
000073dfa87dc91f  call rax
000073dfa87dc921  movaps xmm4, [rsp]
000073dfa87dc925  add rsp, 0x30
000073dfa87dc929  vmovaps xmm0, [rsp]
000073dfa87dc92e  vmovaps xmm1, [rsp+0x10]
000073dfa87dc934  vmovaps xmm2, [rsp+0x20]
000073dfa87dc93a  vmovaps xmm3, [rsp+0x30]
000073dfa87dc940  vmovaps xmm5, [rsp+0x40]
000073dfa87dc946  vmovaps xmm6, [rsp+0x50]
000073dfa87dc94c  vmovaps xmm7, [rsp+0x60]
000073dfa87dc952  vmovaps xmm8, [rsp+0x70]
000073dfa87dc958  vmovaps xmm9, [rsp+0x80]
000073dfa87dc961  vmovaps xmm10, [rsp+0x90]
000073dfa87dc96a  vmovaps xmm11, [rsp+0xA0]
000073dfa87dc973  vmovaps xmm12, [rsp+0xB0]
000073dfa87dc97c  vmovaps xmm13, [rsp+0xC0]
000073dfa87dc985  vmovaps xmm14, [rsp+0xD0]
000073dfa87dc98e  vmovaps xmm15, [rsp+0xE0]
000073dfa87dc997  add rsp, 0xF0
000073dfa87dc99e  pop r11
000073dfa87dc9a0  pop r10
000073dfa87dc9a2  pop r9
000073dfa87dc9a4  pop r8
000073dfa87dc9a6  pop rsi
000073dfa87dc9a7  pop rdi
000073dfa87dc9a8  pop rdx
000073dfa87dc9a9  pop rcx
000073dfa87dc9aa  pop rax
000073dfa87dc9ab  add rsp, 0x08
000073dfa87dc9af  jmp 0x000073DFA87D946A
000073dfa87dc9b4  sub rsp, 0x08
000073dfa87dc9b8  push rax
000073dfa87dc9b9  push rcx
000073dfa87dc9ba  push rdx
000073dfa87dc9bb  push rdi
000073dfa87dc9bc  push rsi
000073dfa87dc9bd  push r8
000073dfa87dc9bf  push r9
000073dfa87dc9c1  push r10
000073dfa87dc9c3  push r11
000073dfa87dc9c5  sub rsp, 0xF0
000073dfa87dc9cc  vmovaps [rsp], xmm0
000073dfa87dc9d1  vmovaps [rsp+0x10], xmm1
000073dfa87dc9d7  vmovaps [rsp+0x20], xmm2
000073dfa87dc9dd  vmovaps [rsp+0x30], xmm3
000073dfa87dc9e3  vmovaps [rsp+0x40], xmm4
000073dfa87dc9e9  vmovaps [rsp+0x50], xmm5
000073dfa87dc9ef  vmovaps [rsp+0x60], xmm6
000073dfa87dc9f5  vmovaps [rsp+0x70], xmm7
000073dfa87dc9fb  vmovaps [rsp+0x80], xmm8
000073dfa87dca04  vmovaps [rsp+0x90], xmm9
000073dfa87dca0d  vmovaps [rsp+0xA0], xmm10
000073dfa87dca16  vmovaps [rsp+0xB0], xmm11
000073dfa87dca1f  vmovaps [rsp+0xC0], xmm12
000073dfa87dca28  vmovaps [rsp+0xD0], xmm14
000073dfa87dca31  vmovaps [rsp+0xE0], xmm15
000073dfa87dca3a  sub rsp, 0x30
000073dfa87dca3e  movaps [rsp], xmm13
000073dfa87dca43  movaps [rsp+0x10], xmm15
000073dfa87dca49  movaps [rsp+0x20], xmm9
000073dfa87dca4f  lea rdi, [rsp]
000073dfa87dca53  mov esi, 0x00
000073dfa87dca58  mov rax, 0x593AA1DA4530
000073dfa87dca62  call rax
000073dfa87dca64  movaps xmm13, [rsp]
000073dfa87dca69  add rsp, 0x30
000073dfa87dca6d  vmovaps xmm0, [rsp]
000073dfa87dca72  vmovaps xmm1, [rsp+0x10]
000073dfa87dca78  vmovaps xmm2, [rsp+0x20]
000073dfa87dca7e  vmovaps xmm3, [rsp+0x30]
000073dfa87dca84  vmovaps xmm4, [rsp+0x40]
000073dfa87dca8a  vmovaps xmm5, [rsp+0x50]
000073dfa87dca90  vmovaps xmm6, [rsp+0x60]
000073dfa87dca96  vmovaps xmm7, [rsp+0x70]
000073dfa87dca9c  vmovaps xmm8, [rsp+0x80]
000073dfa87dcaa5  vmovaps xmm9, [rsp+0x90]
000073dfa87dcaae  vmovaps xmm10, [rsp+0xA0]
000073dfa87dcab7  vmovaps xmm11, [rsp+0xB0]
000073dfa87dcac0  vmovaps xmm12, [rsp+0xC0]
000073dfa87dcac9  vmovaps xmm14, [rsp+0xD0]
000073dfa87dcad2  vmovaps xmm15, [rsp+0xE0]
000073dfa87dcadb  add rsp, 0xF0
000073dfa87dcae2  pop r11
000073dfa87dcae4  pop r10
000073dfa87dcae6  pop r9
000073dfa87dcae8  pop r8
000073dfa87dcaea  pop rsi
000073dfa87dcaeb  pop rdi
000073dfa87dcaec  pop rdx
000073dfa87dcaed  pop rcx
000073dfa87dcaee  pop rax
000073dfa87dcaef  add rsp, 0x08
000073dfa87dcaf3  jmp 0x000073DFA87D9485
000073dfa87dcaf8  sub rsp, 0x08
000073dfa87dcafc  push rax
000073dfa87dcafd  push rcx
000073dfa87dcafe  push rdx
000073dfa87dcaff  push rdi
000073dfa87dcb00  push rsi
000073dfa87dcb01  push r8
000073dfa87dcb03  push r9
000073dfa87dcb05  push r10
000073dfa87dcb07  push r11
000073dfa87dcb09  sub rsp, 0xF0
000073dfa87dcb10  vmovaps [rsp], xmm0
000073dfa87dcb15  vmovaps [rsp+0x10], xmm1
000073dfa87dcb1b  vmovaps [rsp+0x20], xmm2
000073dfa87dcb21  vmovaps [rsp+0x30], xmm3
000073dfa87dcb27  vmovaps [rsp+0x40], xmm4
000073dfa87dcb2d  vmovaps [rsp+0x50], xmm5
000073dfa87dcb33  vmovaps [rsp+0x60], xmm6
000073dfa87dcb39  vmovaps [rsp+0x70], xmm7
000073dfa87dcb3f  vmovaps [rsp+0x80], xmm8
000073dfa87dcb48  vmovaps [rsp+0x90], xmm9
000073dfa87dcb51  vmovaps [rsp+0xA0], xmm10
000073dfa87dcb5a  vmovaps [rsp+0xB0], xmm11
000073dfa87dcb63  vmovaps [rsp+0xC0], xmm12
000073dfa87dcb6c  vmovaps [rsp+0xD0], xmm13
000073dfa87dcb75  vmovaps [rsp+0xE0], xmm14
000073dfa87dcb7e  sub rsp, 0x30
000073dfa87dcb82  movaps [rsp], xmm15
000073dfa87dcb87  movaps [rsp+0x10], xmm1
000073dfa87dcb8c  movaps [rsp+0x20], xmm5
000073dfa87dcb91  lea rdi, [rsp]
000073dfa87dcb95  mov esi, 0x00
000073dfa87dcb9a  mov rax, 0x593AA1DA4530
000073dfa87dcba4  call rax
000073dfa87dcba6  movaps xmm15, [rsp]
000073dfa87dcbab  add rsp, 0x30
000073dfa87dcbaf  vmovaps xmm0, [rsp]
000073dfa87dcbb4  vmovaps xmm1, [rsp+0x10]
000073dfa87dcbba  vmovaps xmm2, [rsp+0x20]
000073dfa87dcbc0  vmovaps xmm3, [rsp+0x30]
000073dfa87dcbc6  vmovaps xmm4, [rsp+0x40]
000073dfa87dcbcc  vmovaps xmm5, [rsp+0x50]
000073dfa87dcbd2  vmovaps xmm6, [rsp+0x60]
000073dfa87dcbd8  vmovaps xmm7, [rsp+0x70]
000073dfa87dcbde  vmovaps xmm8, [rsp+0x80]
000073dfa87dcbe7  vmovaps xmm9, [rsp+0x90]
000073dfa87dcbf0  vmovaps xmm10, [rsp+0xA0]
000073dfa87dcbf9  vmovaps xmm11, [rsp+0xB0]
000073dfa87dcc02  vmovaps xmm12, [rsp+0xC0]
000073dfa87dcc0b  vmovaps xmm13, [rsp+0xD0]
000073dfa87dcc14  vmovaps xmm14, [rsp+0xE0]
000073dfa87dcc1d  add rsp, 0xF0
000073dfa87dcc24  pop r11
000073dfa87dcc26  pop r10
000073dfa87dcc28  pop r9
000073dfa87dcc2a  pop r8
000073dfa87dcc2c  pop rsi
000073dfa87dcc2d  pop rdi
000073dfa87dcc2e  pop rdx
000073dfa87dcc2f  pop rcx
000073dfa87dcc30  pop rax
000073dfa87dcc31  add rsp, 0x08
000073dfa87dcc35  jmp 0x000073DFA87D94A0
000073dfa87dcc3a  call 0x000073DFA86D64F0
000073dfa87dcc3f  jmp 0x000073DFA87D94FB
000073dfa87dcc44  sub rsp, 0x08
000073dfa87dcc48  push rax
000073dfa87dcc49  push rcx
000073dfa87dcc4a  push rdx
000073dfa87dcc4b  push rdi
000073dfa87dcc4c  push rsi
000073dfa87dcc4d  push r8
000073dfa87dcc4f  push r9
000073dfa87dcc51  push r10
000073dfa87dcc53  push r11
000073dfa87dcc55  sub rsp, 0xF0
000073dfa87dcc5c  vmovaps [rsp], xmm0
000073dfa87dcc61  vmovaps [rsp+0x10], xmm1
000073dfa87dcc67  vmovaps [rsp+0x20], xmm2
000073dfa87dcc6d  vmovaps [rsp+0x30], xmm3
000073dfa87dcc73  vmovaps [rsp+0x40], xmm4
000073dfa87dcc79  vmovaps [rsp+0x50], xmm5
000073dfa87dcc7f  vmovaps [rsp+0x60], xmm6
000073dfa87dcc85  vmovaps [rsp+0x70], xmm7
000073dfa87dcc8b  vmovaps [rsp+0x80], xmm8
000073dfa87dcc94  vmovaps [rsp+0x90], xmm10
000073dfa87dcc9d  vmovaps [rsp+0xA0], xmm11
000073dfa87dcca6  vmovaps [rsp+0xB0], xmm12
000073dfa87dccaf  vmovaps [rsp+0xC0], xmm13
000073dfa87dccb8  vmovaps [rsp+0xD0], xmm14
000073dfa87dccc1  vmovaps [rsp+0xE0], xmm15
000073dfa87dccca  sub rsp, 0x30
000073dfa87dccce  movaps [rsp], xmm9
000073dfa87dccd3  movaps [rsp+0x10], xmm8
000073dfa87dccd9  movaps [rsp+0x20], xmm11
000073dfa87dccdf  lea rdi, [rsp]
000073dfa87dcce3  mov esi, 0x00
000073dfa87dcce8  mov rax, 0x593AA1DA4530
000073dfa87dccf2  call rax
000073dfa87dccf4  movaps xmm9, [rsp]
000073dfa87dccf9  add rsp, 0x30
000073dfa87dccfd  vmovaps xmm0, [rsp]
000073dfa87dcd02  vmovaps xmm1, [rsp+0x10]
000073dfa87dcd08  vmovaps xmm2, [rsp+0x20]
000073dfa87dcd0e  vmovaps xmm3, [rsp+0x30]
000073dfa87dcd14  vmovaps xmm4, [rsp+0x40]
000073dfa87dcd1a  vmovaps xmm5, [rsp+0x50]
000073dfa87dcd20  vmovaps xmm6, [rsp+0x60]
000073dfa87dcd26  vmovaps xmm7, [rsp+0x70]
000073dfa87dcd2c  vmovaps xmm8, [rsp+0x80]
000073dfa87dcd35  vmovaps xmm10, [rsp+0x90]
000073dfa87dcd3e  vmovaps xmm11, [rsp+0xA0]
000073dfa87dcd47  vmovaps xmm12, [rsp+0xB0]
000073dfa87dcd50  vmovaps xmm13, [rsp+0xC0]
000073dfa87dcd59  vmovaps xmm14, [rsp+0xD0]
000073dfa87dcd62  vmovaps xmm15, [rsp+0xE0]
000073dfa87dcd6b  add rsp, 0xF0
000073dfa87dcd72  pop r11
000073dfa87dcd74  pop r10
000073dfa87dcd76  pop r9
000073dfa87dcd78  pop r8
000073dfa87dcd7a  pop rsi
000073dfa87dcd7b  pop rdi
000073dfa87dcd7c  pop rdx
000073dfa87dcd7d  pop rcx
000073dfa87dcd7e  pop rax
000073dfa87dcd7f  add rsp, 0x08
000073dfa87dcd83  jmp 0x000073DFA87D9532
000073dfa87dcd88  sub rsp, 0x08
000073dfa87dcd8c  push rax
000073dfa87dcd8d  push rcx
000073dfa87dcd8e  push rdx
000073dfa87dcd8f  push rdi
000073dfa87dcd90  push rsi
000073dfa87dcd91  push r8
000073dfa87dcd93  push r9
000073dfa87dcd95  push r10
000073dfa87dcd97  push r11
000073dfa87dcd99  sub rsp, 0xF0
000073dfa87dcda0  vmovaps [rsp], xmm0
000073dfa87dcda5  vmovaps [rsp+0x10], xmm1
000073dfa87dcdab  vmovaps [rsp+0x20], xmm2
000073dfa87dcdb1  vmovaps [rsp+0x30], xmm3
000073dfa87dcdb7  vmovaps [rsp+0x40], xmm4
000073dfa87dcdbd  vmovaps [rsp+0x50], xmm5
000073dfa87dcdc3  vmovaps [rsp+0x60], xmm6
000073dfa87dcdc9  vmovaps [rsp+0x70], xmm7
000073dfa87dcdcf  vmovaps [rsp+0x80], xmm8
000073dfa87dcdd8  vmovaps [rsp+0x90], xmm9
000073dfa87dcde1  vmovaps [rsp+0xA0], xmm10
000073dfa87dcdea  vmovaps [rsp+0xB0], xmm12
000073dfa87dcdf3  vmovaps [rsp+0xC0], xmm13
000073dfa87dcdfc  vmovaps [rsp+0xD0], xmm14
000073dfa87dce05  vmovaps [rsp+0xE0], xmm15
000073dfa87dce0e  sub rsp, 0x30
000073dfa87dce12  movaps [rsp], xmm11
000073dfa87dce17  movaps [rsp+0x10], xmm10
000073dfa87dce1d  movaps [rsp+0x20], xmm6
000073dfa87dce22  lea rdi, [rsp]
000073dfa87dce26  mov esi, 0x00
000073dfa87dce2b  mov rax, 0x593AA1DA4530
000073dfa87dce35  call rax
000073dfa87dce37  movaps xmm11, [rsp]
000073dfa87dce3c  add rsp, 0x30
000073dfa87dce40  vmovaps xmm0, [rsp]
000073dfa87dce45  vmovaps xmm1, [rsp+0x10]
000073dfa87dce4b  vmovaps xmm2, [rsp+0x20]
000073dfa87dce51  vmovaps xmm3, [rsp+0x30]
000073dfa87dce57  vmovaps xmm4, [rsp+0x40]
000073dfa87dce5d  vmovaps xmm5, [rsp+0x50]
000073dfa87dce63  vmovaps xmm6, [rsp+0x60]
000073dfa87dce69  vmovaps xmm7, [rsp+0x70]
000073dfa87dce6f  vmovaps xmm8, [rsp+0x80]
000073dfa87dce78  vmovaps xmm9, [rsp+0x90]
000073dfa87dce81  vmovaps xmm10, [rsp+0xA0]
000073dfa87dce8a  vmovaps xmm12, [rsp+0xB0]
000073dfa87dce93  vmovaps xmm13, [rsp+0xC0]
000073dfa87dce9c  vmovaps xmm14, [rsp+0xD0]
000073dfa87dcea5  vmovaps xmm15, [rsp+0xE0]
000073dfa87dceae  add rsp, 0xF0
000073dfa87dceb5  pop r11
000073dfa87dceb7  pop r10
000073dfa87dceb9  pop r9
000073dfa87dcebb  pop r8
000073dfa87dcebd  pop rsi
000073dfa87dcebe  pop rdi
000073dfa87dcebf  pop rdx
000073dfa87dcec0  pop rcx
000073dfa87dcec1  pop rax
000073dfa87dcec2  add rsp, 0x08
000073dfa87dcec6  jmp 0x000073DFA87D954D
000073dfa87dcecb  sub rsp, 0x08
000073dfa87dcecf  push rax
000073dfa87dced0  push rcx
000073dfa87dced1  push rdx
000073dfa87dced2  push rdi
000073dfa87dced3  push rsi
000073dfa87dced4  push r8
000073dfa87dced6  push r9
000073dfa87dced8  push r10
000073dfa87dceda  push r11
000073dfa87dcedc  sub rsp, 0xF0
000073dfa87dcee3  vmovaps [rsp], xmm0
000073dfa87dcee8  vmovaps [rsp+0x10], xmm1
000073dfa87dceee  vmovaps [rsp+0x20], xmm2
000073dfa87dcef4  vmovaps [rsp+0x30], xmm3
000073dfa87dcefa  vmovaps [rsp+0x40], xmm4
000073dfa87dcf00  vmovaps [rsp+0x50], xmm5
000073dfa87dcf06  vmovaps [rsp+0x60], xmm6
000073dfa87dcf0c  vmovaps [rsp+0x70], xmm7
000073dfa87dcf12  vmovaps [rsp+0x80], xmm8
000073dfa87dcf1b  vmovaps [rsp+0x90], xmm9
000073dfa87dcf24  vmovaps [rsp+0xA0], xmm11
000073dfa87dcf2d  vmovaps [rsp+0xB0], xmm12
000073dfa87dcf36  vmovaps [rsp+0xC0], xmm13
000073dfa87dcf3f  vmovaps [rsp+0xD0], xmm14
000073dfa87dcf48  vmovaps [rsp+0xE0], xmm15
000073dfa87dcf51  sub rsp, 0x30
000073dfa87dcf55  movaps [rsp], xmm10
000073dfa87dcf5a  movaps [rsp+0x10], xmm14
000073dfa87dcf60  movaps [rsp+0x20], xmm4
000073dfa87dcf65  lea rdi, [rsp]
000073dfa87dcf69  mov esi, 0x00
000073dfa87dcf6e  mov rax, 0x593AA1DA4530
000073dfa87dcf78  call rax
000073dfa87dcf7a  movaps xmm10, [rsp]
000073dfa87dcf7f  add rsp, 0x30
000073dfa87dcf83  vmovaps xmm0, [rsp]
000073dfa87dcf88  vmovaps xmm1, [rsp+0x10]
000073dfa87dcf8e  vmovaps xmm2, [rsp+0x20]
000073dfa87dcf94  vmovaps xmm3, [rsp+0x30]
000073dfa87dcf9a  vmovaps xmm4, [rsp+0x40]
000073dfa87dcfa0  vmovaps xmm5, [rsp+0x50]
000073dfa87dcfa6  vmovaps xmm6, [rsp+0x60]
000073dfa87dcfac  vmovaps xmm7, [rsp+0x70]
000073dfa87dcfb2  vmovaps xmm8, [rsp+0x80]
000073dfa87dcfbb  vmovaps xmm9, [rsp+0x90]
000073dfa87dcfc4  vmovaps xmm11, [rsp+0xA0]
000073dfa87dcfcd  vmovaps xmm12, [rsp+0xB0]
000073dfa87dcfd6  vmovaps xmm13, [rsp+0xC0]
000073dfa87dcfdf  vmovaps xmm14, [rsp+0xD0]
000073dfa87dcfe8  vmovaps xmm15, [rsp+0xE0]
000073dfa87dcff1  add rsp, 0xF0
000073dfa87dcff8  pop r11
000073dfa87dcffa  pop r10
000073dfa87dcffc  pop r9
000073dfa87dcffe  pop r8
000073dfa87dd000  pop rsi
000073dfa87dd001  pop rdi
000073dfa87dd002  pop rdx
000073dfa87dd003  pop rcx
000073dfa87dd004  pop rax
000073dfa87dd005  add rsp, 0x08
000073dfa87dd009  jmp 0x000073DFA87D9568
000073dfa87dd00e  sub rsp, 0x08
000073dfa87dd012  push rax
000073dfa87dd013  push rcx
000073dfa87dd014  push rdx
000073dfa87dd015  push rdi
000073dfa87dd016  push rsi
000073dfa87dd017  push r8
000073dfa87dd019  push r9
000073dfa87dd01b  push r10
000073dfa87dd01d  push r11
000073dfa87dd01f  sub rsp, 0xF0
000073dfa87dd026  vmovaps [rsp], xmm0
000073dfa87dd02b  vmovaps [rsp+0x10], xmm1
000073dfa87dd031  vmovaps [rsp+0x20], xmm2
000073dfa87dd037  vmovaps [rsp+0x30], xmm3
000073dfa87dd03d  vmovaps [rsp+0x40], xmm4
000073dfa87dd043  vmovaps [rsp+0x50], xmm5
000073dfa87dd049  vmovaps [rsp+0x60], xmm6
000073dfa87dd04f  vmovaps [rsp+0x70], xmm7
000073dfa87dd055  vmovaps [rsp+0x80], xmm9
000073dfa87dd05e  vmovaps [rsp+0x90], xmm10
000073dfa87dd067  vmovaps [rsp+0xA0], xmm11
000073dfa87dd070  vmovaps [rsp+0xB0], xmm12
000073dfa87dd079  vmovaps [rsp+0xC0], xmm13
000073dfa87dd082  vmovaps [rsp+0xD0], xmm14
000073dfa87dd08b  vmovaps [rsp+0xE0], xmm15
000073dfa87dd094  sub rsp, 0x30
000073dfa87dd098  movaps [rsp], xmm8
000073dfa87dd09d  movaps [rsp+0x10], xmm1
000073dfa87dd0a2  movaps [rsp+0x20], xmm14
000073dfa87dd0a8  lea rdi, [rsp]
000073dfa87dd0ac  mov esi, 0x00
000073dfa87dd0b1  mov rax, 0x593AA1DA4530
000073dfa87dd0bb  call rax
000073dfa87dd0bd  movaps xmm8, [rsp]
000073dfa87dd0c2  add rsp, 0x30
000073dfa87dd0c6  vmovaps xmm0, [rsp]
000073dfa87dd0cb  vmovaps xmm1, [rsp+0x10]
000073dfa87dd0d1  vmovaps xmm2, [rsp+0x20]
000073dfa87dd0d7  vmovaps xmm3, [rsp+0x30]
000073dfa87dd0dd  vmovaps xmm4, [rsp+0x40]
000073dfa87dd0e3  vmovaps xmm5, [rsp+0x50]
000073dfa87dd0e9  vmovaps xmm6, [rsp+0x60]
000073dfa87dd0ef  vmovaps xmm7, [rsp+0x70]
000073dfa87dd0f5  vmovaps xmm9, [rsp+0x80]
000073dfa87dd0fe  vmovaps xmm10, [rsp+0x90]
000073dfa87dd107  vmovaps xmm11, [rsp+0xA0]
000073dfa87dd110  vmovaps xmm12, [rsp+0xB0]
000073dfa87dd119  vmovaps xmm13, [rsp+0xC0]
000073dfa87dd122  vmovaps xmm14, [rsp+0xD0]
000073dfa87dd12b  vmovaps xmm15, [rsp+0xE0]
000073dfa87dd134  add rsp, 0xF0
000073dfa87dd13b  pop r11
000073dfa87dd13d  pop r10
000073dfa87dd13f  pop r9
000073dfa87dd141  pop r8
000073dfa87dd143  pop rsi
000073dfa87dd144  pop rdi
000073dfa87dd145  pop rdx
000073dfa87dd146  pop rcx
000073dfa87dd147  pop rax
000073dfa87dd148  add rsp, 0x08
000073dfa87dd14c  jmp 0x000073DFA87D958E
000073dfa87dd151  sub rsp, 0x08
000073dfa87dd155  push rax
000073dfa87dd156  push rcx
000073dfa87dd157  push rdx
000073dfa87dd158  push rdi
000073dfa87dd159  push rsi
000073dfa87dd15a  push r8
000073dfa87dd15c  push r9
000073dfa87dd15e  push r10
000073dfa87dd160  push r11
000073dfa87dd162  sub rsp, 0xF0
000073dfa87dd169  vmovaps [rsp], xmm0
000073dfa87dd16e  vmovaps [rsp+0x10], xmm1
000073dfa87dd174  vmovaps [rsp+0x20], xmm2
000073dfa87dd17a  vmovaps [rsp+0x30], xmm3
000073dfa87dd180  vmovaps [rsp+0x40], xmm4
000073dfa87dd186  vmovaps [rsp+0x50], xmm5
000073dfa87dd18c  vmovaps [rsp+0x60], xmm7
000073dfa87dd192  vmovaps [rsp+0x70], xmm8
000073dfa87dd198  vmovaps [rsp+0x80], xmm9
000073dfa87dd1a1  vmovaps [rsp+0x90], xmm10
000073dfa87dd1aa  vmovaps [rsp+0xA0], xmm11
000073dfa87dd1b3  vmovaps [rsp+0xB0], xmm12
000073dfa87dd1bc  vmovaps [rsp+0xC0], xmm13
000073dfa87dd1c5  vmovaps [rsp+0xD0], xmm14
000073dfa87dd1ce  vmovaps [rsp+0xE0], xmm15
000073dfa87dd1d7  sub rsp, 0x30
000073dfa87dd1db  movaps [rsp], xmm6
000073dfa87dd1df  movaps [rsp+0x10], xmm1
000073dfa87dd1e4  movaps [rsp+0x20], xmm14
000073dfa87dd1ea  lea rdi, [rsp]
000073dfa87dd1ee  mov esi, 0x00
000073dfa87dd1f3  mov rax, 0x593AA1DA4530
000073dfa87dd1fd  call rax
000073dfa87dd1ff  movaps xmm6, [rsp]
000073dfa87dd203  add rsp, 0x30
000073dfa87dd207  vmovaps xmm0, [rsp]
000073dfa87dd20c  vmovaps xmm1, [rsp+0x10]
000073dfa87dd212  vmovaps xmm2, [rsp+0x20]
000073dfa87dd218  vmovaps xmm3, [rsp+0x30]
000073dfa87dd21e  vmovaps xmm4, [rsp+0x40]
000073dfa87dd224  vmovaps xmm5, [rsp+0x50]
000073dfa87dd22a  vmovaps xmm7, [rsp+0x60]
000073dfa87dd230  vmovaps xmm8, [rsp+0x70]
000073dfa87dd236  vmovaps xmm9, [rsp+0x80]
000073dfa87dd23f  vmovaps xmm10, [rsp+0x90]
000073dfa87dd248  vmovaps xmm11, [rsp+0xA0]
000073dfa87dd251  vmovaps xmm12, [rsp+0xB0]
000073dfa87dd25a  vmovaps xmm13, [rsp+0xC0]
000073dfa87dd263  vmovaps xmm14, [rsp+0xD0]
000073dfa87dd26c  vmovaps xmm15, [rsp+0xE0]
000073dfa87dd275  add rsp, 0xF0
000073dfa87dd27c  pop r11
000073dfa87dd27e  pop r10
000073dfa87dd280  pop r9
000073dfa87dd282  pop r8
000073dfa87dd284  pop rsi
000073dfa87dd285  pop rdi
000073dfa87dd286  pop rdx
000073dfa87dd287  pop rcx
000073dfa87dd288  pop rax
000073dfa87dd289  add rsp, 0x08
000073dfa87dd28d  jmp 0x000073DFA87D95BA
000073dfa87dd292  sub rsp, 0x08
000073dfa87dd296  push rax
000073dfa87dd297  push rcx
000073dfa87dd298  push rdx
000073dfa87dd299  push rdi
000073dfa87dd29a  push rsi
000073dfa87dd29b  push r8
000073dfa87dd29d  push r9
000073dfa87dd29f  push r10
000073dfa87dd2a1  push r11
000073dfa87dd2a3  sub rsp, 0xF0
000073dfa87dd2aa  vmovaps [rsp], xmm0
000073dfa87dd2af  vmovaps [rsp+0x10], xmm1
000073dfa87dd2b5  vmovaps [rsp+0x20], xmm2
000073dfa87dd2bb  vmovaps [rsp+0x30], xmm3
000073dfa87dd2c1  vmovaps [rsp+0x40], xmm4
000073dfa87dd2c7  vmovaps [rsp+0x50], xmm5
000073dfa87dd2cd  vmovaps [rsp+0x60], xmm6
000073dfa87dd2d3  vmovaps [rsp+0x70], xmm7
000073dfa87dd2d9  vmovaps [rsp+0x80], xmm8
000073dfa87dd2e2  vmovaps [rsp+0x90], xmm9
000073dfa87dd2eb  vmovaps [rsp+0xA0], xmm10
000073dfa87dd2f4  vmovaps [rsp+0xB0], xmm11
000073dfa87dd2fd  vmovaps [rsp+0xC0], xmm12
000073dfa87dd306  vmovaps [rsp+0xD0], xmm13
000073dfa87dd30f  vmovaps [rsp+0xE0], xmm15
000073dfa87dd318  sub rsp, 0x30
000073dfa87dd31c  movaps [rsp], xmm14
000073dfa87dd321  movaps [rsp+0x10], xmm12
000073dfa87dd327  movaps [rsp+0x20], xmm1
000073dfa87dd32c  lea rdi, [rsp]
000073dfa87dd330  mov esi, 0x00
000073dfa87dd335  mov rax, 0x593AA1DA4530
000073dfa87dd33f  call rax
000073dfa87dd341  movaps xmm14, [rsp]
000073dfa87dd346  add rsp, 0x30
000073dfa87dd34a  vmovaps xmm0, [rsp]
000073dfa87dd34f  vmovaps xmm1, [rsp+0x10]
000073dfa87dd355  vmovaps xmm2, [rsp+0x20]
000073dfa87dd35b  vmovaps xmm3, [rsp+0x30]
000073dfa87dd361  vmovaps xmm4, [rsp+0x40]
000073dfa87dd367  vmovaps xmm5, [rsp+0x50]
000073dfa87dd36d  vmovaps xmm6, [rsp+0x60]
000073dfa87dd373  vmovaps xmm7, [rsp+0x70]
000073dfa87dd379  vmovaps xmm8, [rsp+0x80]
000073dfa87dd382  vmovaps xmm9, [rsp+0x90]
000073dfa87dd38b  vmovaps xmm10, [rsp+0xA0]
000073dfa87dd394  vmovaps xmm11, [rsp+0xB0]
000073dfa87dd39d  vmovaps xmm12, [rsp+0xC0]
000073dfa87dd3a6  vmovaps xmm13, [rsp+0xD0]
000073dfa87dd3af  vmovaps xmm15, [rsp+0xE0]
000073dfa87dd3b8  add rsp, 0xF0
000073dfa87dd3bf  pop r11
000073dfa87dd3c1  pop r10
000073dfa87dd3c3  pop r9
000073dfa87dd3c5  pop r8
000073dfa87dd3c7  pop rsi
000073dfa87dd3c8  pop rdi
000073dfa87dd3c9  pop rdx
000073dfa87dd3ca  pop rcx
000073dfa87dd3cb  pop rax
000073dfa87dd3cc  add rsp, 0x08
000073dfa87dd3d0  jmp 0x000073DFA87D95E0
000073dfa87dd3d5  sub rsp, 0x08
000073dfa87dd3d9  push rax
000073dfa87dd3da  push rcx
000073dfa87dd3db  push rdx
000073dfa87dd3dc  push rdi
000073dfa87dd3dd  push rsi
000073dfa87dd3de  push r8
000073dfa87dd3e0  push r9
000073dfa87dd3e2  push r10
000073dfa87dd3e4  push r11
000073dfa87dd3e6  sub rsp, 0xF0
000073dfa87dd3ed  vmovaps [rsp], xmm0
000073dfa87dd3f2  vmovaps [rsp+0x10], xmm2
000073dfa87dd3f8  vmovaps [rsp+0x20], xmm3
000073dfa87dd3fe  vmovaps [rsp+0x30], xmm4
000073dfa87dd404  vmovaps [rsp+0x40], xmm5
000073dfa87dd40a  vmovaps [rsp+0x50], xmm6
000073dfa87dd410  vmovaps [rsp+0x60], xmm7
000073dfa87dd416  vmovaps [rsp+0x70], xmm8
000073dfa87dd41c  vmovaps [rsp+0x80], xmm9
000073dfa87dd425  vmovaps [rsp+0x90], xmm10
000073dfa87dd42e  vmovaps [rsp+0xA0], xmm11
000073dfa87dd437  vmovaps [rsp+0xB0], xmm12
000073dfa87dd440  vmovaps [rsp+0xC0], xmm13
000073dfa87dd449  vmovaps [rsp+0xD0], xmm14
000073dfa87dd452  vmovaps [rsp+0xE0], xmm15
000073dfa87dd45b  sub rsp, 0x30
000073dfa87dd45f  movaps [rsp], xmm1
000073dfa87dd463  movaps [rsp+0x10], xmm13
000073dfa87dd469  movaps [rsp+0x20], xmm9
000073dfa87dd46f  lea rdi, [rsp]
000073dfa87dd473  mov esi, 0x00
000073dfa87dd478  mov rax, 0x593AA1DA4530
000073dfa87dd482  call rax
000073dfa87dd484  movaps xmm1, [rsp]
000073dfa87dd488  add rsp, 0x30
000073dfa87dd48c  vmovaps xmm0, [rsp]
000073dfa87dd491  vmovaps xmm2, [rsp+0x10]
000073dfa87dd497  vmovaps xmm3, [rsp+0x20]
000073dfa87dd49d  vmovaps xmm4, [rsp+0x30]
000073dfa87dd4a3  vmovaps xmm5, [rsp+0x40]
000073dfa87dd4a9  vmovaps xmm6, [rsp+0x50]
000073dfa87dd4af  vmovaps xmm7, [rsp+0x60]
000073dfa87dd4b5  vmovaps xmm8, [rsp+0x70]
000073dfa87dd4bb  vmovaps xmm9, [rsp+0x80]
000073dfa87dd4c4  vmovaps xmm10, [rsp+0x90]
000073dfa87dd4cd  vmovaps xmm11, [rsp+0xA0]
000073dfa87dd4d6  vmovaps xmm12, [rsp+0xB0]
000073dfa87dd4df  vmovaps xmm13, [rsp+0xC0]
000073dfa87dd4e8  vmovaps xmm14, [rsp+0xD0]
000073dfa87dd4f1  vmovaps xmm15, [rsp+0xE0]
000073dfa87dd4fa  add rsp, 0xF0
000073dfa87dd501  pop r11
000073dfa87dd503  pop r10
000073dfa87dd505  pop r9
000073dfa87dd507  pop r8
000073dfa87dd509  pop rsi
000073dfa87dd50a  pop rdi
000073dfa87dd50b  pop rdx
000073dfa87dd50c  pop rcx
000073dfa87dd50d  pop rax
000073dfa87dd50e  add rsp, 0x08
000073dfa87dd512  jmp 0x000073DFA87D95FA
000073dfa87dd517  sub rsp, 0x08
000073dfa87dd51b  push rax
000073dfa87dd51c  push rcx
000073dfa87dd51d  push rdx
000073dfa87dd51e  push rdi
000073dfa87dd51f  push rsi
000073dfa87dd520  push r8
000073dfa87dd522  push r9
000073dfa87dd524  push r10
000073dfa87dd526  push r11
000073dfa87dd528  sub rsp, 0xF0
000073dfa87dd52f  vmovaps [rsp], xmm0
000073dfa87dd534  vmovaps [rsp+0x10], xmm1
000073dfa87dd53a  vmovaps [rsp+0x20], xmm2
000073dfa87dd540  vmovaps [rsp+0x30], xmm3
000073dfa87dd546  vmovaps [rsp+0x40], xmm4
000073dfa87dd54c  vmovaps [rsp+0x50], xmm5
000073dfa87dd552  vmovaps [rsp+0x60], xmm6
000073dfa87dd558  vmovaps [rsp+0x70], xmm7
000073dfa87dd55e  vmovaps [rsp+0x80], xmm8
000073dfa87dd567  vmovaps [rsp+0x90], xmm9
000073dfa87dd570  vmovaps [rsp+0xA0], xmm10
000073dfa87dd579  vmovaps [rsp+0xB0], xmm11
000073dfa87dd582  vmovaps [rsp+0xC0], xmm13
000073dfa87dd58b  vmovaps [rsp+0xD0], xmm14
000073dfa87dd594  vmovaps [rsp+0xE0], xmm15
000073dfa87dd59d  sub rsp, 0x30
000073dfa87dd5a1  movaps [rsp], xmm12
000073dfa87dd5a6  movaps [rsp+0x10], xmm7
000073dfa87dd5ab  movaps [rsp+0x20], xmm13
000073dfa87dd5b1  lea rdi, [rsp]
000073dfa87dd5b5  mov esi, 0x00
000073dfa87dd5ba  mov rax, 0x593AA1DA4530
000073dfa87dd5c4  call rax
000073dfa87dd5c6  movaps xmm12, [rsp]
000073dfa87dd5cb  add rsp, 0x30
000073dfa87dd5cf  vmovaps xmm0, [rsp]
000073dfa87dd5d4  vmovaps xmm1, [rsp+0x10]
000073dfa87dd5da  vmovaps xmm2, [rsp+0x20]
000073dfa87dd5e0  vmovaps xmm3, [rsp+0x30]
000073dfa87dd5e6  vmovaps xmm4, [rsp+0x40]
000073dfa87dd5ec  vmovaps xmm5, [rsp+0x50]
000073dfa87dd5f2  vmovaps xmm6, [rsp+0x60]
000073dfa87dd5f8  vmovaps xmm7, [rsp+0x70]
000073dfa87dd5fe  vmovaps xmm8, [rsp+0x80]
000073dfa87dd607  vmovaps xmm9, [rsp+0x90]
000073dfa87dd610  vmovaps xmm10, [rsp+0xA0]
000073dfa87dd619  vmovaps xmm11, [rsp+0xB0]
000073dfa87dd622  vmovaps xmm13, [rsp+0xC0]
000073dfa87dd62b  vmovaps xmm14, [rsp+0xD0]
000073dfa87dd634  vmovaps xmm15, [rsp+0xE0]
000073dfa87dd63d  add rsp, 0xF0
000073dfa87dd644  pop r11
000073dfa87dd646  pop r10
000073dfa87dd648  pop r9
000073dfa87dd64a  pop r8
000073dfa87dd64c  pop rsi
000073dfa87dd64d  pop rdi
000073dfa87dd64e  pop rdx
000073dfa87dd64f  pop rcx
000073dfa87dd650  pop rax
000073dfa87dd651  add rsp, 0x08
000073dfa87dd655  jmp 0x000073DFA87D9621
000073dfa87dd65a  sub rsp, 0x08
000073dfa87dd65e  push rax
000073dfa87dd65f  push rcx
000073dfa87dd660  push rdx
000073dfa87dd661  push rdi
000073dfa87dd662  push rsi
000073dfa87dd663  push r8
000073dfa87dd665  push r9
000073dfa87dd667  push r10
000073dfa87dd669  push r11
000073dfa87dd66b  sub rsp, 0xF0
000073dfa87dd672  vmovaps [rsp], xmm0
000073dfa87dd677  vmovaps [rsp+0x10], xmm1
000073dfa87dd67d  vmovaps [rsp+0x20], xmm2
000073dfa87dd683  vmovaps [rsp+0x30], xmm3
000073dfa87dd689  vmovaps [rsp+0x40], xmm4
000073dfa87dd68f  vmovaps [rsp+0x50], xmm5
000073dfa87dd695  vmovaps [rsp+0x60], xmm6
000073dfa87dd69b  vmovaps [rsp+0x70], xmm7
000073dfa87dd6a1  vmovaps [rsp+0x80], xmm8
000073dfa87dd6aa  vmovaps [rsp+0x90], xmm9
000073dfa87dd6b3  vmovaps [rsp+0xA0], xmm10
000073dfa87dd6bc  vmovaps [rsp+0xB0], xmm11
000073dfa87dd6c5  vmovaps [rsp+0xC0], xmm12
000073dfa87dd6ce  vmovaps [rsp+0xD0], xmm14
000073dfa87dd6d7  vmovaps [rsp+0xE0], xmm15
000073dfa87dd6e0  sub rsp, 0x30
000073dfa87dd6e4  movaps [rsp], xmm13
000073dfa87dd6e9  movaps [rsp+0x10], xmm15
000073dfa87dd6ef  movaps [rsp+0x20], xmm8
000073dfa87dd6f5  lea rdi, [rsp]
000073dfa87dd6f9  mov esi, 0x00
000073dfa87dd6fe  mov rax, 0x593AA1DA4530
000073dfa87dd708  call rax
000073dfa87dd70a  movaps xmm13, [rsp]
000073dfa87dd70f  add rsp, 0x30
000073dfa87dd713  vmovaps xmm0, [rsp]
000073dfa87dd718  vmovaps xmm1, [rsp+0x10]
000073dfa87dd71e  vmovaps xmm2, [rsp+0x20]
000073dfa87dd724  vmovaps xmm3, [rsp+0x30]
000073dfa87dd72a  vmovaps xmm4, [rsp+0x40]
000073dfa87dd730  vmovaps xmm5, [rsp+0x50]
000073dfa87dd736  vmovaps xmm6, [rsp+0x60]
000073dfa87dd73c  vmovaps xmm7, [rsp+0x70]
000073dfa87dd742  vmovaps xmm8, [rsp+0x80]
000073dfa87dd74b  vmovaps xmm9, [rsp+0x90]
000073dfa87dd754  vmovaps xmm10, [rsp+0xA0]
000073dfa87dd75d  vmovaps xmm11, [rsp+0xB0]
000073dfa87dd766  vmovaps xmm12, [rsp+0xC0]
000073dfa87dd76f  vmovaps xmm14, [rsp+0xD0]
000073dfa87dd778  vmovaps xmm15, [rsp+0xE0]
000073dfa87dd781  add rsp, 0xF0
000073dfa87dd788  pop r11
000073dfa87dd78a  pop r10
000073dfa87dd78c  pop r9
000073dfa87dd78e  pop r8
000073dfa87dd790  pop rsi
000073dfa87dd791  pop rdi
000073dfa87dd792  pop rdx
000073dfa87dd793  pop rcx
000073dfa87dd794  pop rax
000073dfa87dd795  add rsp, 0x08
000073dfa87dd799  jmp 0x000073DFA87D963C
000073dfa87dd79e  sub rsp, 0x08
000073dfa87dd7a2  push rax
000073dfa87dd7a3  push rcx
000073dfa87dd7a4  push rdx
000073dfa87dd7a5  push rdi
000073dfa87dd7a6  push rsi
000073dfa87dd7a7  push r8
000073dfa87dd7a9  push r9
000073dfa87dd7ab  push r10
000073dfa87dd7ad  push r11
000073dfa87dd7af  sub rsp, 0xF0
000073dfa87dd7b6  vmovaps [rsp], xmm0
000073dfa87dd7bb  vmovaps [rsp+0x10], xmm1
000073dfa87dd7c1  vmovaps [rsp+0x20], xmm2
000073dfa87dd7c7  vmovaps [rsp+0x30], xmm3
000073dfa87dd7cd  vmovaps [rsp+0x40], xmm4
000073dfa87dd7d3  vmovaps [rsp+0x50], xmm5
000073dfa87dd7d9  vmovaps [rsp+0x60], xmm6
000073dfa87dd7df  vmovaps [rsp+0x70], xmm7
000073dfa87dd7e5  vmovaps [rsp+0x80], xmm9
000073dfa87dd7ee  vmovaps [rsp+0x90], xmm10
000073dfa87dd7f7  vmovaps [rsp+0xA0], xmm11
000073dfa87dd800  vmovaps [rsp+0xB0], xmm12
000073dfa87dd809  vmovaps [rsp+0xC0], xmm13
000073dfa87dd812  vmovaps [rsp+0xD0], xmm14
000073dfa87dd81b  vmovaps [rsp+0xE0], xmm15
000073dfa87dd824  sub rsp, 0x30
000073dfa87dd828  movaps [rsp], xmm8
000073dfa87dd82d  movaps [rsp+0x10], xmm15
000073dfa87dd833  movaps [rsp+0x20], xmm9
000073dfa87dd839  lea rdi, [rsp]
000073dfa87dd83d  mov esi, 0x00
000073dfa87dd842  mov rax, 0x593AA1DA4530
000073dfa87dd84c  call rax
000073dfa87dd84e  movaps xmm8, [rsp]
000073dfa87dd853  add rsp, 0x30
000073dfa87dd857  vmovaps xmm0, [rsp]
000073dfa87dd85c  vmovaps xmm1, [rsp+0x10]
000073dfa87dd862  vmovaps xmm2, [rsp+0x20]
000073dfa87dd868  vmovaps xmm3, [rsp+0x30]
000073dfa87dd86e  vmovaps xmm4, [rsp+0x40]
000073dfa87dd874  vmovaps xmm5, [rsp+0x50]
000073dfa87dd87a  vmovaps xmm6, [rsp+0x60]
000073dfa87dd880  vmovaps xmm7, [rsp+0x70]
000073dfa87dd886  vmovaps xmm9, [rsp+0x80]
000073dfa87dd88f  vmovaps xmm10, [rsp+0x90]
000073dfa87dd898  vmovaps xmm11, [rsp+0xA0]
000073dfa87dd8a1  vmovaps xmm12, [rsp+0xB0]
000073dfa87dd8aa  vmovaps xmm13, [rsp+0xC0]
000073dfa87dd8b3  vmovaps xmm14, [rsp+0xD0]
000073dfa87dd8bc  vmovaps xmm15, [rsp+0xE0]
000073dfa87dd8c5  add rsp, 0xF0
000073dfa87dd8cc  pop r11
000073dfa87dd8ce  pop r10
000073dfa87dd8d0  pop r9
000073dfa87dd8d2  pop r8
000073dfa87dd8d4  pop rsi
000073dfa87dd8d5  pop rdi
000073dfa87dd8d6  pop rdx
000073dfa87dd8d7  pop rcx
000073dfa87dd8d8  pop rax
000073dfa87dd8d9  add rsp, 0x08
000073dfa87dd8dd  jmp 0x000073DFA87D966A
000073dfa87dd8e2  sub rsp, 0x08
000073dfa87dd8e6  push rax
000073dfa87dd8e7  push rcx
000073dfa87dd8e8  push rdx
000073dfa87dd8e9  push rdi
000073dfa87dd8ea  push rsi
000073dfa87dd8eb  push r8
000073dfa87dd8ed  push r9
000073dfa87dd8ef  push r10
000073dfa87dd8f1  push r11
000073dfa87dd8f3  sub rsp, 0xF0
000073dfa87dd8fa  vmovaps [rsp], xmm0
000073dfa87dd8ff  vmovaps [rsp+0x10], xmm1
000073dfa87dd905  vmovaps [rsp+0x20], xmm2
000073dfa87dd90b  vmovaps [rsp+0x30], xmm3
000073dfa87dd911  vmovaps [rsp+0x40], xmm4
000073dfa87dd917  vmovaps [rsp+0x50], xmm5
000073dfa87dd91d  vmovaps [rsp+0x60], xmm6
000073dfa87dd923  vmovaps [rsp+0x70], xmm7
000073dfa87dd929  vmovaps [rsp+0x80], xmm8
000073dfa87dd932  vmovaps [rsp+0x90], xmm9
000073dfa87dd93b  vmovaps [rsp+0xA0], xmm10
000073dfa87dd944  vmovaps [rsp+0xB0], xmm11
000073dfa87dd94d  vmovaps [rsp+0xC0], xmm12
000073dfa87dd956  vmovaps [rsp+0xD0], xmm13
000073dfa87dd95f  vmovaps [rsp+0xE0], xmm14
000073dfa87dd968  sub rsp, 0x30
000073dfa87dd96c  movaps [rsp], xmm15
000073dfa87dd971  movaps [rsp+0x10], xmm11
000073dfa87dd977  movaps [rsp+0x20], xmm6
000073dfa87dd97c  lea rdi, [rsp]
000073dfa87dd980  mov esi, 0x00
000073dfa87dd985  mov rax, 0x593AA1DA4530
000073dfa87dd98f  call rax
000073dfa87dd991  movaps xmm15, [rsp]
000073dfa87dd996  add rsp, 0x30
000073dfa87dd99a  vmovaps xmm0, [rsp]
000073dfa87dd99f  vmovaps xmm1, [rsp+0x10]
000073dfa87dd9a5  vmovaps xmm2, [rsp+0x20]
000073dfa87dd9ab  vmovaps xmm3, [rsp+0x30]
000073dfa87dd9b1  vmovaps xmm4, [rsp+0x40]
000073dfa87dd9b7  vmovaps xmm5, [rsp+0x50]
000073dfa87dd9bd  vmovaps xmm6, [rsp+0x60]
000073dfa87dd9c3  vmovaps xmm7, [rsp+0x70]
000073dfa87dd9c9  vmovaps xmm8, [rsp+0x80]
000073dfa87dd9d2  vmovaps xmm9, [rsp+0x90]
000073dfa87dd9db  vmovaps xmm10, [rsp+0xA0]
000073dfa87dd9e4  vmovaps xmm11, [rsp+0xB0]
000073dfa87dd9ed  vmovaps xmm12, [rsp+0xC0]
000073dfa87dd9f6  vmovaps xmm13, [rsp+0xD0]
000073dfa87dd9ff  vmovaps xmm14, [rsp+0xE0]
000073dfa87dda08  add rsp, 0xF0
000073dfa87dda0f  pop r11
000073dfa87dda11  pop r10
000073dfa87dda13  pop r9
000073dfa87dda15  pop r8
000073dfa87dda17  pop rsi
000073dfa87dda18  pop rdi
000073dfa87dda19  pop rdx
000073dfa87dda1a  pop rcx
000073dfa87dda1b  pop rax
000073dfa87dda1c  add rsp, 0x08
000073dfa87dda20  jmp 0x000073DFA87D9685
000073dfa87dda25  sub rsp, 0x08
000073dfa87dda29  push rax
000073dfa87dda2a  push rcx
000073dfa87dda2b  push rdx
000073dfa87dda2c  push rdi
000073dfa87dda2d  push rsi
000073dfa87dda2e  push r8
000073dfa87dda30  push r9
000073dfa87dda32  push r10
000073dfa87dda34  push r11
000073dfa87dda36  sub rsp, 0xF0
000073dfa87dda3d  vmovaps [rsp], xmm0
000073dfa87dda42  vmovaps [rsp+0x10], xmm1
000073dfa87dda48  vmovaps [rsp+0x20], xmm2
000073dfa87dda4e  vmovaps [rsp+0x30], xmm3
000073dfa87dda54  vmovaps [rsp+0x40], xmm4
000073dfa87dda5a  vmovaps [rsp+0x50], xmm5
000073dfa87dda60  vmovaps [rsp+0x60], xmm6
000073dfa87dda66  vmovaps [rsp+0x70], xmm8
000073dfa87dda6c  vmovaps [rsp+0x80], xmm9
000073dfa87dda75  vmovaps [rsp+0x90], xmm10
000073dfa87dda7e  vmovaps [rsp+0xA0], xmm11
000073dfa87dda87  vmovaps [rsp+0xB0], xmm12
000073dfa87dda90  vmovaps [rsp+0xC0], xmm13
000073dfa87dda99  vmovaps [rsp+0xD0], xmm14
000073dfa87ddaa2  vmovaps [rsp+0xE0], xmm15
000073dfa87ddaab  sub rsp, 0x30
000073dfa87ddaaf  movaps [rsp], xmm7
000073dfa87ddab3  movaps [rsp+0x10], xmm11
000073dfa87ddab9  movaps [rsp+0x20], xmm9
000073dfa87ddabf  lea rdi, [rsp]
000073dfa87ddac3  mov esi, 0x00
000073dfa87ddac8  mov rax, 0x593AA1DA4530
000073dfa87ddad2  call rax
000073dfa87ddad4  movaps xmm7, [rsp]
000073dfa87ddad8  add rsp, 0x30
000073dfa87ddadc  vmovaps xmm0, [rsp]
000073dfa87ddae1  vmovaps xmm1, [rsp+0x10]
000073dfa87ddae7  vmovaps xmm2, [rsp+0x20]
000073dfa87ddaed  vmovaps xmm3, [rsp+0x30]
000073dfa87ddaf3  vmovaps xmm4, [rsp+0x40]
000073dfa87ddaf9  vmovaps xmm5, [rsp+0x50]
000073dfa87ddaff  vmovaps xmm6, [rsp+0x60]
000073dfa87ddb05  vmovaps xmm8, [rsp+0x70]
000073dfa87ddb0b  vmovaps xmm9, [rsp+0x80]
000073dfa87ddb14  vmovaps xmm10, [rsp+0x90]
000073dfa87ddb1d  vmovaps xmm11, [rsp+0xA0]
000073dfa87ddb26  vmovaps xmm12, [rsp+0xB0]
000073dfa87ddb2f  vmovaps xmm13, [rsp+0xC0]
000073dfa87ddb38  vmovaps xmm14, [rsp+0xD0]
000073dfa87ddb41  vmovaps xmm15, [rsp+0xE0]
000073dfa87ddb4a  add rsp, 0xF0
000073dfa87ddb51  pop r11
000073dfa87ddb53  pop r10
000073dfa87ddb55  pop r9
000073dfa87ddb57  pop r8
000073dfa87ddb59  pop rsi
000073dfa87ddb5a  pop rdi
000073dfa87ddb5b  pop rdx
000073dfa87ddb5c  pop rcx
000073dfa87ddb5d  pop rax
000073dfa87ddb5e  add rsp, 0x08
000073dfa87ddb62  jmp 0x000073DFA87D96B2
000073dfa87ddb67  sub rsp, 0x08
000073dfa87ddb6b  push rax
000073dfa87ddb6c  push rcx
000073dfa87ddb6d  push rdx
000073dfa87ddb6e  push rdi
000073dfa87ddb6f  push rsi
000073dfa87ddb70  push r8
000073dfa87ddb72  push r9
000073dfa87ddb74  push r10
000073dfa87ddb76  push r11
000073dfa87ddb78  sub rsp, 0xF0
000073dfa87ddb7f  vmovaps [rsp], xmm0
000073dfa87ddb84  vmovaps [rsp+0x10], xmm1
000073dfa87ddb8a  vmovaps [rsp+0x20], xmm2
000073dfa87ddb90  vmovaps [rsp+0x30], xmm3
000073dfa87ddb96  vmovaps [rsp+0x40], xmm4
000073dfa87ddb9c  vmovaps [rsp+0x50], xmm5
000073dfa87ddba2  vmovaps [rsp+0x60], xmm6
000073dfa87ddba8  vmovaps [rsp+0x70], xmm7
000073dfa87ddbae  vmovaps [rsp+0x80], xmm8
000073dfa87ddbb7  vmovaps [rsp+0x90], xmm9
000073dfa87ddbc0  vmovaps [rsp+0xA0], xmm10
000073dfa87ddbc9  vmovaps [rsp+0xB0], xmm12
000073dfa87ddbd2  vmovaps [rsp+0xC0], xmm13
000073dfa87ddbdb  vmovaps [rsp+0xD0], xmm14
000073dfa87ddbe4  vmovaps [rsp+0xE0], xmm15
000073dfa87ddbed  sub rsp, 0x30
000073dfa87ddbf1  movaps [rsp], xmm11
000073dfa87ddbf6  movaps [rsp+0x10], xmm10
000073dfa87ddbfc  movaps [rsp+0x20], xmm14
000073dfa87ddc02  lea rdi, [rsp]
000073dfa87ddc06  mov esi, 0x00
000073dfa87ddc0b  mov rax, 0x593AA1DA4530
000073dfa87ddc15  call rax
000073dfa87ddc17  movaps xmm11, [rsp]
000073dfa87ddc1c  add rsp, 0x30
000073dfa87ddc20  vmovaps xmm0, [rsp]
000073dfa87ddc25  vmovaps xmm1, [rsp+0x10]
000073dfa87ddc2b  vmovaps xmm2, [rsp+0x20]
000073dfa87ddc31  vmovaps xmm3, [rsp+0x30]
000073dfa87ddc37  vmovaps xmm4, [rsp+0x40]
000073dfa87ddc3d  vmovaps xmm5, [rsp+0x50]
000073dfa87ddc43  vmovaps xmm6, [rsp+0x60]
000073dfa87ddc49  vmovaps xmm7, [rsp+0x70]
000073dfa87ddc4f  vmovaps xmm8, [rsp+0x80]
000073dfa87ddc58  vmovaps xmm9, [rsp+0x90]
000073dfa87ddc61  vmovaps xmm10, [rsp+0xA0]
000073dfa87ddc6a  vmovaps xmm12, [rsp+0xB0]
000073dfa87ddc73  vmovaps xmm13, [rsp+0xC0]
000073dfa87ddc7c  vmovaps xmm14, [rsp+0xD0]
000073dfa87ddc85  vmovaps xmm15, [rsp+0xE0]
000073dfa87ddc8e  add rsp, 0xF0
000073dfa87ddc95  pop r11
000073dfa87ddc97  pop r10
000073dfa87ddc99  pop r9
000073dfa87ddc9b  pop r8
000073dfa87ddc9d  pop rsi
000073dfa87ddc9e  pop rdi
000073dfa87ddc9f  pop rdx
000073dfa87ddca0  pop rcx
000073dfa87ddca1  pop rax
000073dfa87ddca2  add rsp, 0x08
000073dfa87ddca6  jmp 0x000073DFA87D96CD
000073dfa87ddcab  call 0x000073DFA86E45A0
000073dfa87ddcb0  jmp 0x000073DFA87D96D7
000073dfa87ddcb5  sub rsp, 0x08
000073dfa87ddcb9  push rax
000073dfa87ddcba  push rcx
000073dfa87ddcbb  push rdx
000073dfa87ddcbc  push rdi
000073dfa87ddcbd  push rsi
000073dfa87ddcbe  push r8
000073dfa87ddcc0  push r9
000073dfa87ddcc2  push r10
000073dfa87ddcc4  push r11
000073dfa87ddcc6  sub rsp, 0xF0
000073dfa87ddccd  vmovaps [rsp], xmm0
000073dfa87ddcd2  vmovaps [rsp+0x10], xmm1
000073dfa87ddcd8  vmovaps [rsp+0x20], xmm2
000073dfa87ddcde  vmovaps [rsp+0x30], xmm3
000073dfa87ddce4  vmovaps [rsp+0x40], xmm4
000073dfa87ddcea  vmovaps [rsp+0x50], xmm5
000073dfa87ddcf0  vmovaps [rsp+0x60], xmm6
000073dfa87ddcf6  vmovaps [rsp+0x70], xmm7
000073dfa87ddcfc  vmovaps [rsp+0x80], xmm8
000073dfa87ddd05  vmovaps [rsp+0x90], xmm9
000073dfa87ddd0e  vmovaps [rsp+0xA0], xmm11
000073dfa87ddd17  vmovaps [rsp+0xB0], xmm12
000073dfa87ddd20  vmovaps [rsp+0xC0], xmm13
000073dfa87ddd29  vmovaps [rsp+0xD0], xmm14
000073dfa87ddd32  vmovaps [rsp+0xE0], xmm15
000073dfa87ddd3b  sub rsp, 0x30
000073dfa87ddd3f  movaps [rsp], xmm10
000073dfa87ddd44  movaps [rsp+0x10], xmm1
000073dfa87ddd49  movaps [rsp+0x20], xmm12
000073dfa87ddd4f  lea rdi, [rsp]
000073dfa87ddd53  mov esi, 0x00
000073dfa87ddd58  mov rax, 0x593AA1DA4530
000073dfa87ddd62  call rax
000073dfa87ddd64  movaps xmm10, [rsp]
000073dfa87ddd69  add rsp, 0x30
000073dfa87ddd6d  vmovaps xmm0, [rsp]
000073dfa87ddd72  vmovaps xmm1, [rsp+0x10]
000073dfa87ddd78  vmovaps xmm2, [rsp+0x20]
000073dfa87ddd7e  vmovaps xmm3, [rsp+0x30]
000073dfa87ddd84  vmovaps xmm4, [rsp+0x40]
000073dfa87ddd8a  vmovaps xmm5, [rsp+0x50]
000073dfa87ddd90  vmovaps xmm6, [rsp+0x60]
000073dfa87ddd96  vmovaps xmm7, [rsp+0x70]
000073dfa87ddd9c  vmovaps xmm8, [rsp+0x80]
000073dfa87ddda5  vmovaps xmm9, [rsp+0x90]
000073dfa87dddae  vmovaps xmm11, [rsp+0xA0]
000073dfa87dddb7  vmovaps xmm12, [rsp+0xB0]
000073dfa87dddc0  vmovaps xmm13, [rsp+0xC0]
000073dfa87dddc9  vmovaps xmm14, [rsp+0xD0]
000073dfa87dddd2  vmovaps xmm15, [rsp+0xE0]
000073dfa87ddddb  add rsp, 0xF0
000073dfa87ddde2  pop r11
000073dfa87ddde4  pop r10
000073dfa87ddde6  pop r9
000073dfa87ddde8  pop r8
000073dfa87dddea  pop rsi
000073dfa87dddeb  pop rdi
000073dfa87dddec  pop rdx
000073dfa87ddded  pop rcx
000073dfa87dddee  pop rax
000073dfa87dddef  add rsp, 0x08
000073dfa87dddf3  jmp 0x000073DFA87D96FA
000073dfa87dddf8  sub rsp, 0x08
000073dfa87dddfc  push rax
000073dfa87dddfd  push rcx
000073dfa87dddfe  push rdx
000073dfa87dddff  push rdi
000073dfa87dde00  push rsi
000073dfa87dde01  push r8
000073dfa87dde03  push r9
000073dfa87dde05  push r10
000073dfa87dde07  push r11
000073dfa87dde09  sub rsp, 0xF0
000073dfa87dde10  vmovaps [rsp], xmm0
000073dfa87dde15  vmovaps [rsp+0x10], xmm1
000073dfa87dde1b  vmovaps [rsp+0x20], xmm2
000073dfa87dde21  vmovaps [rsp+0x30], xmm3
000073dfa87dde27  vmovaps [rsp+0x40], xmm4
000073dfa87dde2d  vmovaps [rsp+0x50], xmm5
000073dfa87dde33  vmovaps [rsp+0x60], xmm6
000073dfa87dde39  vmovaps [rsp+0x70], xmm7
000073dfa87dde3f  vmovaps [rsp+0x80], xmm8
000073dfa87dde48  vmovaps [rsp+0x90], xmm9
000073dfa87dde51  vmovaps [rsp+0xA0], xmm10
000073dfa87dde5a  vmovaps [rsp+0xB0], xmm11
000073dfa87dde63  vmovaps [rsp+0xC0], xmm13
000073dfa87dde6c  vmovaps [rsp+0xD0], xmm14
000073dfa87dde75  vmovaps [rsp+0xE0], xmm15
000073dfa87dde7e  sub rsp, 0x30
000073dfa87dde82  movaps [rsp], xmm12
000073dfa87dde87  movaps [rsp+0x10], xmm14
000073dfa87dde8d  movaps [rsp+0x20], xmm1
000073dfa87dde92  lea rdi, [rsp]
000073dfa87dde96  mov esi, 0x00
000073dfa87dde9b  mov rax, 0x593AA1DA4530
000073dfa87ddea5  call rax
000073dfa87ddea7  movaps xmm12, [rsp]
000073dfa87ddeac  add rsp, 0x30
000073dfa87ddeb0  vmovaps xmm0, [rsp]
000073dfa87ddeb5  vmovaps xmm1, [rsp+0x10]
000073dfa87ddebb  vmovaps xmm2, [rsp+0x20]
000073dfa87ddec1  vmovaps xmm3, [rsp+0x30]
000073dfa87ddec7  vmovaps xmm4, [rsp+0x40]
000073dfa87ddecd  vmovaps xmm5, [rsp+0x50]
000073dfa87dded3  vmovaps xmm6, [rsp+0x60]
000073dfa87dded9  vmovaps xmm7, [rsp+0x70]
000073dfa87ddedf  vmovaps xmm8, [rsp+0x80]
000073dfa87ddee8  vmovaps xmm9, [rsp+0x90]
000073dfa87ddef1  vmovaps xmm10, [rsp+0xA0]
000073dfa87ddefa  vmovaps xmm11, [rsp+0xB0]
000073dfa87ddf03  vmovaps xmm13, [rsp+0xC0]
000073dfa87ddf0c  vmovaps xmm14, [rsp+0xD0]
000073dfa87ddf15  vmovaps xmm15, [rsp+0xE0]
000073dfa87ddf1e  add rsp, 0xF0
000073dfa87ddf25  pop r11
000073dfa87ddf27  pop r10
000073dfa87ddf29  pop r9
000073dfa87ddf2b  pop r8
000073dfa87ddf2d  pop rsi
000073dfa87ddf2e  pop rdi
000073dfa87ddf2f  pop rdx
000073dfa87ddf30  pop rcx
000073dfa87ddf31  pop rax
000073dfa87ddf32  add rsp, 0x08
000073dfa87ddf36  jmp 0x000073DFA87D9729
000073dfa87ddf3b  sub rsp, 0x08
000073dfa87ddf3f  push rax
000073dfa87ddf40  push rcx
000073dfa87ddf41  push rdx
000073dfa87ddf42  push rdi
000073dfa87ddf43  push rsi
000073dfa87ddf44  push r8
000073dfa87ddf46  push r9
000073dfa87ddf48  push r10
000073dfa87ddf4a  push r11
000073dfa87ddf4c  sub rsp, 0xF0
000073dfa87ddf53  vmovaps [rsp], xmm0
000073dfa87ddf58  vmovaps [rsp+0x10], xmm1
000073dfa87ddf5e  vmovaps [rsp+0x20], xmm2
000073dfa87ddf64  vmovaps [rsp+0x30], xmm3
000073dfa87ddf6a  vmovaps [rsp+0x40], xmm4
000073dfa87ddf70  vmovaps [rsp+0x50], xmm5
000073dfa87ddf76  vmovaps [rsp+0x60], xmm6
000073dfa87ddf7c  vmovaps [rsp+0x70], xmm7
000073dfa87ddf82  vmovaps [rsp+0x80], xmm8
000073dfa87ddf8b  vmovaps [rsp+0x90], xmm9
000073dfa87ddf94  vmovaps [rsp+0xA0], xmm10
000073dfa87ddf9d  vmovaps [rsp+0xB0], xmm11
000073dfa87ddfa6  vmovaps [rsp+0xC0], xmm12
000073dfa87ddfaf  vmovaps [rsp+0xD0], xmm13
000073dfa87ddfb8  vmovaps [rsp+0xE0], xmm15
000073dfa87ddfc1  sub rsp, 0x30
000073dfa87ddfc5  movaps [rsp], xmm14
000073dfa87ddfca  movaps [rsp+0x10], xmm9
000073dfa87ddfd0  movaps [rsp+0x20], xmm1
000073dfa87ddfd5  lea rdi, [rsp]
000073dfa87ddfd9  mov esi, 0x00
000073dfa87ddfde  mov rax, 0x593AA1DA4530
000073dfa87ddfe8  call rax
000073dfa87ddfea  movaps xmm14, [rsp]
000073dfa87ddfef  add rsp, 0x30
000073dfa87ddff3  vmovaps xmm0, [rsp]
000073dfa87ddff8  vmovaps xmm1, [rsp+0x10]
000073dfa87ddffe  vmovaps xmm2, [rsp+0x20]
000073dfa87de004  vmovaps xmm3, [rsp+0x30]
000073dfa87de00a  vmovaps xmm4, [rsp+0x40]
000073dfa87de010  vmovaps xmm5, [rsp+0x50]
000073dfa87de016  vmovaps xmm6, [rsp+0x60]
000073dfa87de01c  vmovaps xmm7, [rsp+0x70]
000073dfa87de022  vmovaps xmm8, [rsp+0x80]
000073dfa87de02b  vmovaps xmm9, [rsp+0x90]
000073dfa87de034  vmovaps xmm10, [rsp+0xA0]
000073dfa87de03d  vmovaps xmm11, [rsp+0xB0]
000073dfa87de046  vmovaps xmm12, [rsp+0xC0]
000073dfa87de04f  vmovaps xmm13, [rsp+0xD0]
000073dfa87de058  vmovaps xmm15, [rsp+0xE0]
000073dfa87de061  add rsp, 0xF0
000073dfa87de068  pop r11
000073dfa87de06a  pop r10
000073dfa87de06c  pop r9
000073dfa87de06e  pop r8
000073dfa87de070  pop rsi
000073dfa87de071  pop rdi
000073dfa87de072  pop rdx
000073dfa87de073  pop rcx
000073dfa87de074  pop rax
000073dfa87de075  add rsp, 0x08
000073dfa87de079  jmp 0x000073DFA87D9758
000073dfa87de07e  sub rsp, 0x08
000073dfa87de082  push rax
000073dfa87de083  push rcx
000073dfa87de084  push rdx
000073dfa87de085  push rdi
000073dfa87de086  push rsi
000073dfa87de087  push r8
000073dfa87de089  push r9
000073dfa87de08b  push r10
000073dfa87de08d  push r11
000073dfa87de08f  sub rsp, 0xF0
000073dfa87de096  vmovaps [rsp], xmm0
000073dfa87de09b  vmovaps [rsp+0x10], xmm2
000073dfa87de0a1  vmovaps [rsp+0x20], xmm3
000073dfa87de0a7  vmovaps [rsp+0x30], xmm4
000073dfa87de0ad  vmovaps [rsp+0x40], xmm5
000073dfa87de0b3  vmovaps [rsp+0x50], xmm6
000073dfa87de0b9  vmovaps [rsp+0x60], xmm7
000073dfa87de0bf  vmovaps [rsp+0x70], xmm8
000073dfa87de0c5  vmovaps [rsp+0x80], xmm9
000073dfa87de0ce  vmovaps [rsp+0x90], xmm10
000073dfa87de0d7  vmovaps [rsp+0xA0], xmm11
000073dfa87de0e0  vmovaps [rsp+0xB0], xmm12
000073dfa87de0e9  vmovaps [rsp+0xC0], xmm13
000073dfa87de0f2  vmovaps [rsp+0xD0], xmm14
000073dfa87de0fb  vmovaps [rsp+0xE0], xmm15
000073dfa87de104  sub rsp, 0x30
000073dfa87de108  movaps [rsp], xmm1
000073dfa87de10c  movaps [rsp+0x10], xmm13
000073dfa87de112  movaps [rsp+0x20], xmm8
000073dfa87de118  lea rdi, [rsp]
000073dfa87de11c  mov esi, 0x00
000073dfa87de121  mov rax, 0x593AA1DA4530
000073dfa87de12b  call rax
000073dfa87de12d  movaps xmm1, [rsp]
000073dfa87de131  add rsp, 0x30
000073dfa87de135  vmovaps xmm0, [rsp]
000073dfa87de13a  vmovaps xmm2, [rsp+0x10]
000073dfa87de140  vmovaps xmm3, [rsp+0x20]
000073dfa87de146  vmovaps xmm4, [rsp+0x30]
000073dfa87de14c  vmovaps xmm5, [rsp+0x40]
000073dfa87de152  vmovaps xmm6, [rsp+0x50]
000073dfa87de158  vmovaps xmm7, [rsp+0x60]
000073dfa87de15e  vmovaps xmm8, [rsp+0x70]
000073dfa87de164  vmovaps xmm9, [rsp+0x80]
000073dfa87de16d  vmovaps xmm10, [rsp+0x90]
000073dfa87de176  vmovaps xmm11, [rsp+0xA0]
000073dfa87de17f  vmovaps xmm12, [rsp+0xB0]
000073dfa87de188  vmovaps xmm13, [rsp+0xC0]
000073dfa87de191  vmovaps xmm14, [rsp+0xD0]
000073dfa87de19a  vmovaps xmm15, [rsp+0xE0]
000073dfa87de1a3  add rsp, 0xF0
000073dfa87de1aa  pop r11
000073dfa87de1ac  pop r10
000073dfa87de1ae  pop r9
000073dfa87de1b0  pop r8
000073dfa87de1b2  pop rsi
000073dfa87de1b3  pop rdi
000073dfa87de1b4  pop rdx
000073dfa87de1b5  pop rcx
000073dfa87de1b6  pop rax
000073dfa87de1b7  add rsp, 0x08
000073dfa87de1bb  jmp 0x000073DFA87D977A
000073dfa87de1c0  call 0x000073DFA860C260
000073dfa87de1c5  jmp 0x000073DFA87D9788
000073dfa87de1ca  call 0x000073DFA86DE950
000073dfa87de1cf  jmp 0x000073DFA87D9792
000073dfa87de1d4  sub rsp, 0x08
000073dfa87de1d8  push rax
000073dfa87de1d9  push rcx
000073dfa87de1da  push rdx
000073dfa87de1db  push rdi
000073dfa87de1dc  push rsi
000073dfa87de1dd  push r8
000073dfa87de1df  push r9
000073dfa87de1e1  push r10
000073dfa87de1e3  push r11
000073dfa87de1e5  sub rsp, 0xF0
000073dfa87de1ec  vmovaps [rsp], xmm0
000073dfa87de1f1  vmovaps [rsp+0x10], xmm1
000073dfa87de1f7  vmovaps [rsp+0x20], xmm2
000073dfa87de1fd  vmovaps [rsp+0x30], xmm3
000073dfa87de203  vmovaps [rsp+0x40], xmm4
000073dfa87de209  vmovaps [rsp+0x50], xmm5
000073dfa87de20f  vmovaps [rsp+0x60], xmm6
000073dfa87de215  vmovaps [rsp+0x70], xmm7
000073dfa87de21b  vmovaps [rsp+0x80], xmm9
000073dfa87de224  vmovaps [rsp+0x90], xmm10
000073dfa87de22d  vmovaps [rsp+0xA0], xmm11
000073dfa87de236  vmovaps [rsp+0xB0], xmm12
000073dfa87de23f  vmovaps [rsp+0xC0], xmm13
000073dfa87de248  vmovaps [rsp+0xD0], xmm14
000073dfa87de251  vmovaps [rsp+0xE0], xmm15
000073dfa87de25a  sub rsp, 0x30
000073dfa87de25e  movaps [rsp], xmm8
000073dfa87de263  movaps [rsp+0x10], xmm15
000073dfa87de269  movaps [rsp+0x20], xmm7
000073dfa87de26e  lea rdi, [rsp]
000073dfa87de272  mov esi, 0x00
000073dfa87de277  mov rax, 0x593AA1DA4530
000073dfa87de281  call rax
000073dfa87de283  movaps xmm8, [rsp]
000073dfa87de288  add rsp, 0x30
000073dfa87de28c  vmovaps xmm0, [rsp]
000073dfa87de291  vmovaps xmm1, [rsp+0x10]
000073dfa87de297  vmovaps xmm2, [rsp+0x20]
000073dfa87de29d  vmovaps xmm3, [rsp+0x30]
000073dfa87de2a3  vmovaps xmm4, [rsp+0x40]
000073dfa87de2a9  vmovaps xmm5, [rsp+0x50]
000073dfa87de2af  vmovaps xmm6, [rsp+0x60]
000073dfa87de2b5  vmovaps xmm7, [rsp+0x70]
000073dfa87de2bb  vmovaps xmm9, [rsp+0x80]
000073dfa87de2c4  vmovaps xmm10, [rsp+0x90]
000073dfa87de2cd  vmovaps xmm11, [rsp+0xA0]
000073dfa87de2d6  vmovaps xmm12, [rsp+0xB0]
000073dfa87de2df  vmovaps xmm13, [rsp+0xC0]
000073dfa87de2e8  vmovaps xmm14, [rsp+0xD0]
000073dfa87de2f1  vmovaps xmm15, [rsp+0xE0]
000073dfa87de2fa  add rsp, 0xF0
000073dfa87de301  pop r11
000073dfa87de303  pop r10
000073dfa87de305  pop r9
000073dfa87de307  pop r8
000073dfa87de309  pop rsi
000073dfa87de30a  pop rdi
000073dfa87de30b  pop rdx
000073dfa87de30c  pop rcx
000073dfa87de30d  pop rax
000073dfa87de30e  add rsp, 0x08
000073dfa87de312  jmp 0x000073DFA87D97B4
000073dfa87de317  sub rsp, 0x08
000073dfa87de31b  push rax
000073dfa87de31c  push rcx
000073dfa87de31d  push rdx
000073dfa87de31e  push rdi
000073dfa87de31f  push rsi
000073dfa87de320  push r8
000073dfa87de322  push r9
000073dfa87de324  push r10
000073dfa87de326  push r11
000073dfa87de328  sub rsp, 0xF0
000073dfa87de32f  vmovaps [rsp], xmm0
000073dfa87de334  vmovaps [rsp+0x10], xmm1
000073dfa87de33a  vmovaps [rsp+0x20], xmm2
000073dfa87de340  vmovaps [rsp+0x30], xmm3
000073dfa87de346  vmovaps [rsp+0x40], xmm4
000073dfa87de34c  vmovaps [rsp+0x50], xmm5
000073dfa87de352  vmovaps [rsp+0x60], xmm6
000073dfa87de358  vmovaps [rsp+0x70], xmm8
000073dfa87de35e  vmovaps [rsp+0x80], xmm9
000073dfa87de367  vmovaps [rsp+0x90], xmm10
000073dfa87de370  vmovaps [rsp+0xA0], xmm11
000073dfa87de379  vmovaps [rsp+0xB0], xmm12
000073dfa87de382  vmovaps [rsp+0xC0], xmm13
000073dfa87de38b  vmovaps [rsp+0xD0], xmm14
000073dfa87de394  vmovaps [rsp+0xE0], xmm15
000073dfa87de39d  sub rsp, 0x30
000073dfa87de3a1  movaps [rsp], xmm7
000073dfa87de3a5  movaps [rsp+0x10], xmm9
000073dfa87de3ab  movaps [rsp+0x20], xmm15
000073dfa87de3b1  lea rdi, [rsp]
000073dfa87de3b5  mov esi, 0x00
000073dfa87de3ba  mov rax, 0x593AA1DA4530
000073dfa87de3c4  call rax
000073dfa87de3c6  movaps xmm7, [rsp]
000073dfa87de3ca  add rsp, 0x30
000073dfa87de3ce  vmovaps xmm0, [rsp]
000073dfa87de3d3  vmovaps xmm1, [rsp+0x10]
000073dfa87de3d9  vmovaps xmm2, [rsp+0x20]
000073dfa87de3df  vmovaps xmm3, [rsp+0x30]
000073dfa87de3e5  vmovaps xmm4, [rsp+0x40]
000073dfa87de3eb  vmovaps xmm5, [rsp+0x50]
000073dfa87de3f1  vmovaps xmm6, [rsp+0x60]
000073dfa87de3f7  vmovaps xmm8, [rsp+0x70]
000073dfa87de3fd  vmovaps xmm9, [rsp+0x80]
000073dfa87de406  vmovaps xmm10, [rsp+0x90]
000073dfa87de40f  vmovaps xmm11, [rsp+0xA0]
000073dfa87de418  vmovaps xmm12, [rsp+0xB0]
000073dfa87de421  vmovaps xmm13, [rsp+0xC0]
000073dfa87de42a  vmovaps xmm14, [rsp+0xD0]
000073dfa87de433  vmovaps xmm15, [rsp+0xE0]
000073dfa87de43c  add rsp, 0xF0
000073dfa87de443  pop r11
000073dfa87de445  pop r10
000073dfa87de447  pop r9
000073dfa87de449  pop r8
000073dfa87de44b  pop rsi
000073dfa87de44c  pop rdi
000073dfa87de44d  pop rdx
000073dfa87de44e  pop rcx
000073dfa87de44f  pop rax
000073dfa87de450  add rsp, 0x08
000073dfa87de454  jmp 0x000073DFA87D97E1
000073dfa87de459  sub rsp, 0x08
000073dfa87de45d  push rax
000073dfa87de45e  push rcx
000073dfa87de45f  push rdx
000073dfa87de460  push rdi
000073dfa87de461  push rsi
000073dfa87de462  push r8
000073dfa87de464  push r9
000073dfa87de466  push r10
000073dfa87de468  push r11
000073dfa87de46a  sub rsp, 0xF0
000073dfa87de471  vmovaps [rsp], xmm0
000073dfa87de476  vmovaps [rsp+0x10], xmm1
000073dfa87de47c  vmovaps [rsp+0x20], xmm2
000073dfa87de482  vmovaps [rsp+0x30], xmm3
000073dfa87de488  vmovaps [rsp+0x40], xmm4
000073dfa87de48e  vmovaps [rsp+0x50], xmm5
000073dfa87de494  vmovaps [rsp+0x60], xmm6
000073dfa87de49a  vmovaps [rsp+0x70], xmm7
000073dfa87de4a0  vmovaps [rsp+0x80], xmm8
000073dfa87de4a9  vmovaps [rsp+0x90], xmm10
000073dfa87de4b2  vmovaps [rsp+0xA0], xmm11
000073dfa87de4bb  vmovaps [rsp+0xB0], xmm12
000073dfa87de4c4  vmovaps [rsp+0xC0], xmm13
000073dfa87de4cd  vmovaps [rsp+0xD0], xmm14
000073dfa87de4d6  vmovaps [rsp+0xE0], xmm15
000073dfa87de4df  sub rsp, 0x30
000073dfa87de4e3  movaps [rsp], xmm9
000073dfa87de4e8  movaps [rsp+0x10], xmm13
000073dfa87de4ee  movaps [rsp+0x20], xmm15
000073dfa87de4f4  lea rdi, [rsp]
000073dfa87de4f8  mov esi, 0x00
000073dfa87de4fd  mov rax, 0x593AA1DA4530
000073dfa87de507  call rax
000073dfa87de509  movaps xmm9, [rsp]
000073dfa87de50e  add rsp, 0x30
000073dfa87de512  vmovaps xmm0, [rsp]
000073dfa87de517  vmovaps xmm1, [rsp+0x10]
000073dfa87de51d  vmovaps xmm2, [rsp+0x20]
000073dfa87de523  vmovaps xmm3, [rsp+0x30]
000073dfa87de529  vmovaps xmm4, [rsp+0x40]
000073dfa87de52f  vmovaps xmm5, [rsp+0x50]
000073dfa87de535  vmovaps xmm6, [rsp+0x60]
000073dfa87de53b  vmovaps xmm7, [rsp+0x70]
000073dfa87de541  vmovaps xmm8, [rsp+0x80]
000073dfa87de54a  vmovaps xmm10, [rsp+0x90]
000073dfa87de553  vmovaps xmm11, [rsp+0xA0]
000073dfa87de55c  vmovaps xmm12, [rsp+0xB0]
000073dfa87de565  vmovaps xmm13, [rsp+0xC0]
000073dfa87de56e  vmovaps xmm14, [rsp+0xD0]
000073dfa87de577  vmovaps xmm15, [rsp+0xE0]
000073dfa87de580  add rsp, 0xF0
000073dfa87de587  pop r11
000073dfa87de589  pop r10
000073dfa87de58b  pop r9
000073dfa87de58d  pop r8
000073dfa87de58f  pop rsi
000073dfa87de590  pop rdi
000073dfa87de591  pop rdx
000073dfa87de592  pop rcx
000073dfa87de593  pop rax
000073dfa87de594  add rsp, 0x08
000073dfa87de598  jmp 0x000073DFA87D980F
000073dfa87de59d  sub rsp, 0x08
000073dfa87de5a1  push rax
000073dfa87de5a2  push rcx
000073dfa87de5a3  push rdx
000073dfa87de5a4  push rdi
000073dfa87de5a5  push rsi
000073dfa87de5a6  push r8
000073dfa87de5a8  push r9
000073dfa87de5aa  push r10
000073dfa87de5ac  push r11
000073dfa87de5ae  sub rsp, 0xF0
000073dfa87de5b5  vmovaps [rsp], xmm0
000073dfa87de5ba  vmovaps [rsp+0x10], xmm1
000073dfa87de5c0  vmovaps [rsp+0x20], xmm2
000073dfa87de5c6  vmovaps [rsp+0x30], xmm3
000073dfa87de5cc  vmovaps [rsp+0x40], xmm4
000073dfa87de5d2  vmovaps [rsp+0x50], xmm5
000073dfa87de5d8  vmovaps [rsp+0x60], xmm6
000073dfa87de5de  vmovaps [rsp+0x70], xmm7
000073dfa87de5e4  vmovaps [rsp+0x80], xmm8
000073dfa87de5ed  vmovaps [rsp+0x90], xmm9
000073dfa87de5f6  vmovaps [rsp+0xA0], xmm10
000073dfa87de5ff  vmovaps [rsp+0xB0], xmm11
000073dfa87de608  vmovaps [rsp+0xC0], xmm12
000073dfa87de611  vmovaps [rsp+0xD0], xmm13
000073dfa87de61a  vmovaps [rsp+0xE0], xmm14
000073dfa87de623  sub rsp, 0x30
000073dfa87de627  movaps [rsp], xmm15
000073dfa87de62c  movaps [rsp+0x10], xmm11
000073dfa87de632  movaps [rsp+0x20], xmm12
000073dfa87de638  lea rdi, [rsp]
000073dfa87de63c  mov esi, 0x00
000073dfa87de641  mov rax, 0x593AA1DA4530
000073dfa87de64b  call rax
000073dfa87de64d  movaps xmm15, [rsp]
000073dfa87de652  add rsp, 0x30
000073dfa87de656  vmovaps xmm0, [rsp]
000073dfa87de65b  vmovaps xmm1, [rsp+0x10]
000073dfa87de661  vmovaps xmm2, [rsp+0x20]
000073dfa87de667  vmovaps xmm3, [rsp+0x30]
000073dfa87de66d  vmovaps xmm4, [rsp+0x40]
000073dfa87de673  vmovaps xmm5, [rsp+0x50]
000073dfa87de679  vmovaps xmm6, [rsp+0x60]
000073dfa87de67f  vmovaps xmm7, [rsp+0x70]
000073dfa87de685  vmovaps xmm8, [rsp+0x80]
000073dfa87de68e  vmovaps xmm9, [rsp+0x90]
000073dfa87de697  vmovaps xmm10, [rsp+0xA0]
000073dfa87de6a0  vmovaps xmm11, [rsp+0xB0]
000073dfa87de6a9  vmovaps xmm12, [rsp+0xC0]
000073dfa87de6b2  vmovaps xmm13, [rsp+0xD0]
000073dfa87de6bb  vmovaps xmm14, [rsp+0xE0]
000073dfa87de6c4  add rsp, 0xF0
000073dfa87de6cb  pop r11
000073dfa87de6cd  pop r10
000073dfa87de6cf  pop r9
000073dfa87de6d1  pop r8
000073dfa87de6d3  pop rsi
000073dfa87de6d4  pop rdi
000073dfa87de6d5  pop rdx
000073dfa87de6d6  pop rcx
000073dfa87de6d7  pop rax
000073dfa87de6d8  add rsp, 0x08
000073dfa87de6dc  jmp 0x000073DFA87D982A
000073dfa87de6e1  sub rsp, 0x08
000073dfa87de6e5  push rax
000073dfa87de6e6  push rcx
000073dfa87de6e7  push rdx
000073dfa87de6e8  push rdi
000073dfa87de6e9  push rsi
000073dfa87de6ea  push r8
000073dfa87de6ec  push r9
000073dfa87de6ee  push r10
000073dfa87de6f0  push r11
000073dfa87de6f2  sub rsp, 0xF0
000073dfa87de6f9  vmovaps [rsp], xmm0
000073dfa87de6fe  vmovaps [rsp+0x10], xmm1
000073dfa87de704  vmovaps [rsp+0x20], xmm2
000073dfa87de70a  vmovaps [rsp+0x30], xmm3
000073dfa87de710  vmovaps [rsp+0x40], xmm4
000073dfa87de716  vmovaps [rsp+0x50], xmm5
000073dfa87de71c  vmovaps [rsp+0x60], xmm6
000073dfa87de722  vmovaps [rsp+0x70], xmm7
000073dfa87de728  vmovaps [rsp+0x80], xmm8
000073dfa87de731  vmovaps [rsp+0x90], xmm9
000073dfa87de73a  vmovaps [rsp+0xA0], xmm10
000073dfa87de743  vmovaps [rsp+0xB0], xmm11
000073dfa87de74c  vmovaps [rsp+0xC0], xmm12
000073dfa87de755  vmovaps [rsp+0xD0], xmm14
000073dfa87de75e  vmovaps [rsp+0xE0], xmm15
000073dfa87de767  sub rsp, 0x30
000073dfa87de76b  movaps [rsp], xmm13
000073dfa87de770  movaps [rsp+0x10], xmm10
000073dfa87de776  movaps [rsp+0x20], xmm14
000073dfa87de77c  lea rdi, [rsp]
000073dfa87de780  mov esi, 0x00
000073dfa87de785  mov rax, 0x593AA1DA4530
000073dfa87de78f  call rax
000073dfa87de791  movaps xmm13, [rsp]
000073dfa87de796  add rsp, 0x30
000073dfa87de79a  vmovaps xmm0, [rsp]
000073dfa87de79f  vmovaps xmm1, [rsp+0x10]
000073dfa87de7a5  vmovaps xmm2, [rsp+0x20]
000073dfa87de7ab  vmovaps xmm3, [rsp+0x30]
000073dfa87de7b1  vmovaps xmm4, [rsp+0x40]
000073dfa87de7b7  vmovaps xmm5, [rsp+0x50]
000073dfa87de7bd  vmovaps xmm6, [rsp+0x60]
000073dfa87de7c3  vmovaps xmm7, [rsp+0x70]
000073dfa87de7c9  vmovaps xmm8, [rsp+0x80]
000073dfa87de7d2  vmovaps xmm9, [rsp+0x90]
000073dfa87de7db  vmovaps xmm10, [rsp+0xA0]
000073dfa87de7e4  vmovaps xmm11, [rsp+0xB0]
000073dfa87de7ed  vmovaps xmm12, [rsp+0xC0]
000073dfa87de7f6  vmovaps xmm14, [rsp+0xD0]
000073dfa87de7ff  vmovaps xmm15, [rsp+0xE0]
000073dfa87de808  add rsp, 0xF0
000073dfa87de80f  pop r11
000073dfa87de811  pop r10
000073dfa87de813  pop r9
000073dfa87de815  pop r8
000073dfa87de817  pop rsi
000073dfa87de818  pop rdi
000073dfa87de819  pop rdx
000073dfa87de81a  pop rcx
000073dfa87de81b  pop rax
000073dfa87de81c  add rsp, 0x08
000073dfa87de820  jmp 0x000073DFA87D984D
000073dfa87de825  sub rsp, 0x08
000073dfa87de829  push rax
000073dfa87de82a  push rcx
000073dfa87de82b  push rdx
000073dfa87de82c  push rdi
000073dfa87de82d  push rsi
000073dfa87de82e  push r8
000073dfa87de830  push r9
000073dfa87de832  push r10
000073dfa87de834  push r11
000073dfa87de836  sub rsp, 0xF0
000073dfa87de83d  vmovaps [rsp], xmm0
000073dfa87de842  vmovaps [rsp+0x10], xmm1
000073dfa87de848  vmovaps [rsp+0x20], xmm2
000073dfa87de84e  vmovaps [rsp+0x30], xmm3
000073dfa87de854  vmovaps [rsp+0x40], xmm4
000073dfa87de85a  vmovaps [rsp+0x50], xmm5
000073dfa87de860  vmovaps [rsp+0x60], xmm6
000073dfa87de866  vmovaps [rsp+0x70], xmm7
000073dfa87de86c  vmovaps [rsp+0x80], xmm8
000073dfa87de875  vmovaps [rsp+0x90], xmm9
000073dfa87de87e  vmovaps [rsp+0xA0], xmm10
000073dfa87de887  vmovaps [rsp+0xB0], xmm11
000073dfa87de890  vmovaps [rsp+0xC0], xmm12
000073dfa87de899  vmovaps [rsp+0xD0], xmm13
000073dfa87de8a2  vmovaps [rsp+0xE0], xmm15
000073dfa87de8ab  sub rsp, 0x30
000073dfa87de8af  movaps [rsp], xmm14
000073dfa87de8b4  movaps [rsp+0x10], xmm1
000073dfa87de8b9  movaps [rsp+0x20], xmm7
000073dfa87de8be  lea rdi, [rsp]
000073dfa87de8c2  mov esi, 0x00
000073dfa87de8c7  mov rax, 0x593AA1DA4530
000073dfa87de8d1  call rax
000073dfa87de8d3  movaps xmm14, [rsp]
000073dfa87de8d8  add rsp, 0x30
000073dfa87de8dc  vmovaps xmm0, [rsp]
000073dfa87de8e1  vmovaps xmm1, [rsp+0x10]
000073dfa87de8e7  vmovaps xmm2, [rsp+0x20]
000073dfa87de8ed  vmovaps xmm3, [rsp+0x30]
000073dfa87de8f3  vmovaps xmm4, [rsp+0x40]
000073dfa87de8f9  vmovaps xmm5, [rsp+0x50]
000073dfa87de8ff  vmovaps xmm6, [rsp+0x60]
000073dfa87de905  vmovaps xmm7, [rsp+0x70]
000073dfa87de90b  vmovaps xmm8, [rsp+0x80]
000073dfa87de914  vmovaps xmm9, [rsp+0x90]
000073dfa87de91d  vmovaps xmm10, [rsp+0xA0]
000073dfa87de926  vmovaps xmm11, [rsp+0xB0]
000073dfa87de92f  vmovaps xmm12, [rsp+0xC0]
000073dfa87de938  vmovaps xmm13, [rsp+0xD0]
000073dfa87de941  vmovaps xmm15, [rsp+0xE0]
000073dfa87de94a  add rsp, 0xF0
000073dfa87de951  pop r11
000073dfa87de953  pop r10
000073dfa87de955  pop r9
000073dfa87de957  pop r8
000073dfa87de959  pop rsi
000073dfa87de95a  pop rdi
000073dfa87de95b  pop rdx
000073dfa87de95c  pop rcx
000073dfa87de95d  pop rax
000073dfa87de95e  add rsp, 0x08
000073dfa87de962  jmp 0x000073DFA87D9870
000073dfa87de967  sub rsp, 0x08
000073dfa87de96b  push rax
000073dfa87de96c  push rcx
000073dfa87de96d  push rdx
000073dfa87de96e  push rdi
000073dfa87de96f  push rsi
000073dfa87de970  push r8
000073dfa87de972  push r9
000073dfa87de974  push r10
000073dfa87de976  push r11
000073dfa87de978  sub rsp, 0xF0
000073dfa87de97f  vmovaps [rsp], xmm0
000073dfa87de984  vmovaps [rsp+0x10], xmm2
000073dfa87de98a  vmovaps [rsp+0x20], xmm3
000073dfa87de990  vmovaps [rsp+0x30], xmm4
000073dfa87de996  vmovaps [rsp+0x40], xmm5
000073dfa87de99c  vmovaps [rsp+0x50], xmm6
000073dfa87de9a2  vmovaps [rsp+0x60], xmm7
000073dfa87de9a8  vmovaps [rsp+0x70], xmm8
000073dfa87de9ae  vmovaps [rsp+0x80], xmm9
000073dfa87de9b7  vmovaps [rsp+0x90], xmm10
000073dfa87de9c0  vmovaps [rsp+0xA0], xmm11
000073dfa87de9c9  vmovaps [rsp+0xB0], xmm12
000073dfa87de9d2  vmovaps [rsp+0xC0], xmm13
000073dfa87de9db  vmovaps [rsp+0xD0], xmm14
000073dfa87de9e4  vmovaps [rsp+0xE0], xmm15
000073dfa87de9ed  sub rsp, 0x30
000073dfa87de9f1  movaps [rsp], xmm1
000073dfa87de9f5  movaps [rsp+0x10], xmm8
000073dfa87de9fb  movaps [rsp+0x20], xmm9
000073dfa87dea01  lea rdi, [rsp]
000073dfa87dea05  mov esi, 0x00
000073dfa87dea0a  mov rax, 0x593AA1DA4530
000073dfa87dea14  call rax
000073dfa87dea16  movaps xmm1, [rsp]
000073dfa87dea1a  add rsp, 0x30
000073dfa87dea1e  vmovaps xmm0, [rsp]
000073dfa87dea23  vmovaps xmm2, [rsp+0x10]
000073dfa87dea29  vmovaps xmm3, [rsp+0x20]
000073dfa87dea2f  vmovaps xmm4, [rsp+0x30]
000073dfa87dea35  vmovaps xmm5, [rsp+0x40]
000073dfa87dea3b  vmovaps xmm6, [rsp+0x50]
000073dfa87dea41  vmovaps xmm7, [rsp+0x60]
000073dfa87dea47  vmovaps xmm8, [rsp+0x70]
000073dfa87dea4d  vmovaps xmm9, [rsp+0x80]
000073dfa87dea56  vmovaps xmm10, [rsp+0x90]
000073dfa87dea5f  vmovaps xmm11, [rsp+0xA0]
000073dfa87dea68  vmovaps xmm12, [rsp+0xB0]
000073dfa87dea71  vmovaps xmm13, [rsp+0xC0]
000073dfa87dea7a  vmovaps xmm14, [rsp+0xD0]
000073dfa87dea83  vmovaps xmm15, [rsp+0xE0]
000073dfa87dea8c  add rsp, 0xF0
000073dfa87dea93  pop r11
000073dfa87dea95  pop r10
000073dfa87dea97  pop r9
000073dfa87dea99  pop r8
000073dfa87dea9b  pop rsi
000073dfa87dea9c  pop rdi
000073dfa87dea9d  pop rdx
000073dfa87dea9e  pop rcx
000073dfa87dea9f  pop rax
000073dfa87deaa0  add rsp, 0x08
000073dfa87deaa4  jmp 0x000073DFA87D9892
000073dfa87deaa9  call 0x000073DFA86B3E40
000073dfa87deaae  jmp 0x000073DFA87D98A0
000073dfa87deab3  call 0x000073DFA860C380
000073dfa87deab8  jmp 0x000073DFA87D98AA
000073dfa87deabd  call 0x000073DFA860D600
000073dfa87deac2  jmp 0x000073DFA87D98B4
000073dfa87deac7  call 0x000073DFA85FF540
000073dfa87deacc  jmp 0x000073DFA87D98BE
000073dfa87dead1  int3
000073dfa87dead2  nop [rax+rax*1], ax
000073dfa87deadb  nop [rax+rax*1], eax
000073dfa87deae0  mov eax, [r15+0x48]
000073dfa87deae4  lea r14d, [eax+0x01]
000073dfa87deae9  mov [rsp+0x10], r14d
000073dfa87deaee  mov r14d, r14d
000073dfa87deaf1  mov [r15+0x48], r14
000073dfa87deaf5  xor eax, eax
000073dfa87deaf7  mov r14d, [rsp+0x10]
000073dfa87deafc  cmp r14d, 0x1F4
000073dfa87deb03  cmc
000073dfa87deb04  lahf
000073dfa87deb05  seto al
000073dfa87deb08  mov [r15+0x108], eax
000073dfa87deb0f  mov eax, [r15+0x108]
000073dfa87deb16  sahf
000073dfa87deb17  jnz 0x000073DFA87DEB49
000073dfa87deb19  cmp dword ptr [r15+0x318], 0x00
000073dfa87deb21  jz 0x000073DFA87E4C90
000073dfa87deb27  nop [rax+rax*1], ax
000073dfa87deb30  nop [rax+rax*1], eax
000073dfa87deb38  mov eax, 0x4106DC
000073dfa87deb3d  mov [r15+0x100], rax
000073dfa87deb44  jmp 0x000073DFA85FE110
000073dfa87deb49  cmp dword ptr [r15+0x318], 0x00
000073dfa87deb51  jz 0x000073DFA87DEB80
000073dfa87deb57  nop [rax+rax*1], ax
000073dfa87deb60  nop [rax+rax*1], eax
000073dfa87deb68  mov eax, 0x410500
000073dfa87deb6d  mov [r15+0x100], rax
000073dfa87deb74  jmp 0x000073DFA85FE110
000073dfa87deb79  int3
000073dfa87deb7a  int3
000073dfa87deb7b  nop [rax+rax*1], eax
000073dfa87deb80  mov rax, [r15+0x40]
000073dfa87deb84  movaps xmm1, [r15+0x1D0]
000073dfa87deb8c  vmovaps [rsp+0x10], xmm1
000073dfa87deb92  vmovaps xmm15, [rsp+0x10]
000073dfa87deb98  por xmm1, xmm15
000073dfa87deb9d  movaps xmm14, [r15+0x1A0]
000073dfa87deba5  vmovaps [rsp+0x10], xmm14
000073dfa87debab  vmovaps xmm13, [rsp+0x10]
000073dfa87debb1  por xmm14, xmm13
000073dfa87debb6  lea r14, [rax+0x30]
000073dfa87debba  mov r12, [r13+r14*1]
000073dfa87debbf  lea r14, [rax+0x38]
000073dfa87debc3  mov r11, [r13+r14*1]
000073dfa87debc8  movq xmm13, r12
000073dfa87debcd  movq xmm12, r11
000073dfa87debd2  movq xmm13, xmm13
000073dfa87debd7  vmovaps [rsp+0x10], xmm13
000073dfa87debdd  movq xmm13, xmm13
000073dfa87debe2  movaps [r15+0x130], xmm13
000073dfa87debea  movq xmm12, xmm12
000073dfa87debef  vmovaps [rsp+0x20], xmm12
000073dfa87debf5  movq xmm12, xmm12
000073dfa87debfa  movaps [r15+0x280], xmm12
000073dfa87dec02  movaps xmm13, [r15+0x270]
000073dfa87dec0a  vmovaps [rsp+0x30], xmm13
000073dfa87dec10  vmovaps xmm12, [rsp+0x30]
000073dfa87dec16  por xmm13, xmm12
000073dfa87dec1b  lea r14, [rax+0x20]
000073dfa87dec1f  mov r12, [r13+r14*1]
000073dfa87dec24  lea r14, [rax+0x28]
000073dfa87dec28  mov r11, [r13+r14*1]
000073dfa87dec2d  movq xmm12, r12
000073dfa87dec32  movq xmm11, r11
000073dfa87dec37  movq xmm12, xmm12
000073dfa87dec3c  vmovaps [rsp+0x30], xmm12
000073dfa87dec42  movq xmm12, xmm12
000073dfa87dec47  movaps [r15+0x150], xmm12
000073dfa87dec4f  movq xmm11, xmm11
000073dfa87dec54  vmovaps [rsp+0x40], xmm11
000073dfa87dec5a  movq xmm11, xmm11
000073dfa87dec5f  movaps [r15+0x140], xmm11
000073dfa87dec67  lea r14, [rax+0x10]
000073dfa87dec6b  mov r12, [r13+r14*1]
000073dfa87dec70  lea r14, [rax+0x18]
000073dfa87dec74  mov r11, [r13+r14*1]
000073dfa87dec79  movq xmm12, r12
000073dfa87dec7e  movq xmm11, r11
000073dfa87dec83  movq xmm12, xmm12
000073dfa87dec88  vmovaps [rsp+0x50], xmm12
000073dfa87dec8e  movq xmm12, xmm12
000073dfa87dec93  movaps [r15+0x170], xmm12
000073dfa87dec9b  movq xmm11, xmm11
000073dfa87deca0  vmovaps [rsp+0x60], xmm11
000073dfa87deca6  movq xmm11, xmm11
000073dfa87decab  movaps [r15+0x160], xmm11
000073dfa87decb3  mov r14, [r13+rax*1]
000073dfa87decb8  vmovq xmm12, r14
000073dfa87decbd  vpbroadcastq xmm12, xmm12
000073dfa87decc2  lea r14, [rax+0x08]
000073dfa87decc6  mov rax, [r13+r14*1]
000073dfa87deccb  movq xmm11, rax
000073dfa87decd0  movaps [r15+0x230], xmm11
000073dfa87decd8  mov rax, [r15+0xF8]
000073dfa87decdf  lea r14, [rax+0x50]
000073dfa87dece3  movups xmm11, [r13+r14*1]
000073dfa87dece9  lea r14, [rax+0x60]
000073dfa87deced  movups xmm10, [r13+r14*1]
000073dfa87decf3  lea r14, [rax+0x30]
000073dfa87decf7  movups xmm9, [r13+r14*1]
000073dfa87decfd  mov r14, [r15+0x50]
000073dfa87ded01  mov [r15+0x60], r14
000073dfa87ded05  mov qword ptr [r15+0x58], 0x40
000073dfa87ded0d  movaps xmm8, xmm12
000073dfa87ded11  mulpd xmm8, xmm15
000073dfa87ded16  vcmppd xmm7, xmm8, xmm8, 0x03
000073dfa87ded1c  ptest xmm7, xmm7
000073dfa87ded21  jnz 0x000073DFA87DFB4A
000073dfa87ded27  movq xmm15, qword ptr [r15+0x230]
000073dfa87ded30  vmovaps [rsp+0x70], xmm15
000073dfa87ded36  vpermilpd xmm15, xmm15, 0x00
000073dfa87ded3c  movaps xmm7, xmm9
000073dfa87ded40  mulpd xmm7, xmm15
000073dfa87ded45  vcmppd xmm6, xmm7, xmm7, 0x03
000073dfa87ded4a  ptest xmm6, xmm6
000073dfa87ded4f  jnz 0x000073DFA87DFC8E
000073dfa87ded55  vxorps xmm15, xmm15, xmm15
000073dfa87ded5a  vpbroadcastq xmm15, xmm15
000073dfa87ded5f  movaps xmm9, xmm12
000073dfa87ded63  mulpd xmm9, xmm10
000073dfa87ded68  vcmppd xmm6, xmm9, xmm9, 0x03
000073dfa87ded6e  ptest xmm6, xmm6
000073dfa87ded73  jnz 0x000073DFA87DFDD0
000073dfa87ded79  movaps xmm10, xmm12
000073dfa87ded7d  mulpd xmm10, xmm11
000073dfa87ded82  vcmppd xmm6, xmm10, xmm10, 0x03
000073dfa87ded88  ptest xmm6, xmm6
000073dfa87ded8d  jnz 0x000073DFA87DFF14
000073dfa87ded93  movaps xmm11, [r15+0x1F0]
000073dfa87ded9b  movaps xmm6, xmm12
000073dfa87ded9f  mulpd xmm6, xmm11
000073dfa87deda4  vcmppd xmm5, xmm6, xmm6, 0x03
000073dfa87deda9  ptest xmm5, xmm5
000073dfa87dedae  jnz 0x000073DFA87E0058
000073dfa87dedb4  movaps xmm12, [r15+0x2A0]
000073dfa87dedbc  vmovaps [rsp+0x80], xmm12
000073dfa87dedc5  vmovaps xmm11, [rsp+0x80]
000073dfa87dedce  por xmm12, xmm11
000073dfa87dedd3  movaps xmm11, [r15+0x250]
000073dfa87deddb  vmovaps [rsp+0x80], xmm11
000073dfa87dede4  vmovaps xmm5, [rsp+0x80]
000073dfa87deded  por xmm11, xmm5
000073dfa87dedf2  vmovaps xmm4, [rsp+0x70]
000073dfa87dedf8  vpermilpd xmm4, xmm4, 0x00
000073dfa87dedfe  movaps xmm3, xmm5
000073dfa87dee01  mulpd xmm3, xmm4
000073dfa87dee05  vcmppd xmm2, xmm3, xmm3, 0x03
000073dfa87dee0a  ptest xmm2, xmm2
000073dfa87dee0f  jnz 0x000073DFA87E019A
000073dfa87dee15  mov [rsp+0x80], rax
000073dfa87dee1d  xor eax, eax
000073dfa87dee1f  mov r12d, 0x40
000073dfa87dee25  mov r11d, 0x200
000073dfa87dee2b  cmp r12, r11
000073dfa87dee2e  cmc
000073dfa87dee2f  lahf
000073dfa87dee30  seto al
000073dfa87dee33  mov [r15+0x108], eax
000073dfa87dee3a  movaps xmm5, xmm8
000073dfa87dee3e  addpd xmm5, xmm15
000073dfa87dee43  vcmppd xmm4, xmm5, xmm5, 0x03
000073dfa87dee48  ptest xmm4, xmm4
000073dfa87dee4d  jnz 0x000073DFA87E02DA
000073dfa87dee53  movaps xmm8, [r15+0x1B0]
000073dfa87dee5b  movaps xmm4, xmm9
000073dfa87dee5f  addpd xmm4, xmm8
000073dfa87dee64  vcmppd xmm2, xmm4, xmm4, 0x03
000073dfa87dee69  ptest xmm2, xmm2
000073dfa87dee6e  jnz 0x000073DFA87E041C
000073dfa87dee74  movaps xmm9, xmm10
000073dfa87dee78  addpd xmm9, xmm8
000073dfa87dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000073dfa87dee83  ptest xmm2, xmm2
000073dfa87dee88  jnz 0x000073DFA87E055E
000073dfa87dee8e  movaps xmm10, [r15+0x2F0]
000073dfa87dee96  vmovaps [rsp+0x90], xmm10
000073dfa87dee9f  vmovaps xmm8, [rsp+0x90]
000073dfa87deea8  por xmm10, xmm8
000073dfa87deead  movaps xmm8, [r15+0x2E0]
000073dfa87deeb5  vmovaps [rsp+0x90], xmm8
000073dfa87deebe  vmovaps xmm2, [rsp+0x90]
000073dfa87deec7  por xmm8, xmm2
000073dfa87deecc  movaps xmm2, [r15+0x2D0]
000073dfa87deed4  vmovaps [rsp+0x90], xmm2
000073dfa87deedd  vmovaps [rsp+0xA0], xmm1
000073dfa87deee6  vmovaps xmm1, [rsp+0x90]
000073dfa87deeef  por xmm2, xmm1
000073dfa87deef3  movaps xmm1, [r15+0x200]
000073dfa87deefb  vmovaps [rsp+0x90], xmm1
000073dfa87def04  vmovaps [rsp+0xB0], xmm15
000073dfa87def0d  vmovaps xmm15, [rsp+0x90]
000073dfa87def16  por xmm1, xmm15
000073dfa87def1b  movaps xmm15, [r15+0x1C0]
000073dfa87def23  vmovaps [rsp+0x90], xmm15
000073dfa87def2c  vmovaps [rsp+0xC0], xmm1
000073dfa87def35  vmovaps xmm1, [rsp+0x90]
000073dfa87def3e  por xmm15, xmm1
000073dfa87def43  movaps xmm1, [r15+0x190]
000073dfa87def4b  vmovaps [rsp+0x90], xmm1
000073dfa87def54  vmovaps [rsp+0xD0], xmm15
000073dfa87def5d  vmovaps xmm15, [rsp+0x90]
000073dfa87def66  por xmm1, xmm15
000073dfa87def6b  movaps xmm15, [r15+0x300]
000073dfa87def73  vmovaps [rsp+0x90], xmm15
000073dfa87def7c  vmovaps [rsp+0xE0], xmm1
000073dfa87def85  vmovaps xmm1, [rsp+0x90]
000073dfa87def8e  por xmm15, xmm1
000073dfa87def93  mov rax, [rsp+0x80]
000073dfa87def9b  lea r12, [rax+0xA0]
000073dfa87defa2  movups xmm1, [r13+r12*1]
000073dfa87defa8  lea r12, [rax+0xB0]
000073dfa87defaf  vmovaps [rsp+0x80], xmm1
000073dfa87defb8  movups xmm1, [r13+r12*1]
000073dfa87defbe  vmovaps [rsp+0x90], xmm1
000073dfa87defc7  vmovaps [rsp+0xF0], xmm15
000073dfa87defd0  vmovaps xmm15, [rsp+0xB0]
000073dfa87defd9  vmovaps [rsp+0xB0], xmm14
000073dfa87defe2  movaps xmm1, xmm6
000073dfa87defe5  addpd xmm1, xmm15
000073dfa87defea  vcmppd xmm14, xmm1, xmm1, 0x03
000073dfa87defef  ptest xmm14, xmm14
000073dfa87deff5  jnz 0x000073DFA87E06B6
000073dfa87deffb  lea r12, [rax+0xF0]
000073dfa87df002  movups xmm15, [r13+r12*1]
000073dfa87df008  movaps xmm14, xmm4
000073dfa87df00c  addpd xmm14, xmm3
000073dfa87df011  vcmppd xmm6, xmm14, xmm14, 0x03
000073dfa87df017  ptest xmm6, xmm6
000073dfa87df01c  jnz 0x000073DFA87E0801
000073dfa87df022  movaps xmm6, xmm9
000073dfa87df026  addpd xmm6, xmm7
000073dfa87df02a  vcmppd xmm4, xmm6, xmm6, 0x03
000073dfa87df02f  ptest xmm4, xmm4
000073dfa87df034  jnz 0x000073DFA87E0943
000073dfa87df03a  vmovaps xmm9, [rsp+0x70]
000073dfa87df040  vpermilpd xmm9, xmm9, 0x00
000073dfa87df046  vmovaps xmm4, [rsp+0x90]
000073dfa87df04f  movaps xmm7, xmm4
000073dfa87df052  mulpd xmm7, xmm9
000073dfa87df057  vcmppd xmm3, xmm7, xmm7, 0x03
000073dfa87df05c  ptest xmm3, xmm3
000073dfa87df061  jnz 0x000073DFA87E0A84
000073dfa87df067  vmovaps xmm9, [rsp+0x50]
000073dfa87df06d  vpermilpd xmm9, xmm9, 0x00
000073dfa87df073  movaps xmm4, xmm15
000073dfa87df077  mulpd xmm4, xmm9
000073dfa87df07c  vcmppd xmm3, xmm4, xmm4, 0x03
000073dfa87df081  ptest xmm3, xmm3
000073dfa87df086  jnz 0x000073DFA87E0BC5
000073dfa87df08c  lea r12, [rax+0xE0]
000073dfa87df093  movups xmm15, [r13+r12*1]
000073dfa87df099  vmovaps xmm9, [rsp+0x70]
000073dfa87df09f  vpermilpd xmm9, xmm9, 0x00
000073dfa87df0a5  vmovaps [rsp+0x70], xmm1
000073dfa87df0ab  vmovaps xmm1, [rsp+0x80]
000073dfa87df0b4  vmovaps [rsp+0x80], xmm15
000073dfa87df0bd  movaps xmm3, xmm1
000073dfa87df0c0  mulpd xmm3, xmm9
000073dfa87df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000073dfa87df0ca  ptest xmm15, xmm15
000073dfa87df0d0  jnz 0x000073DFA87E0D11
000073dfa87df0d6  vmovaps xmm1, [rsp+0xF0]
000073dfa87df0df  vmovaps xmm15, [rsp+0xF0]
000073dfa87df0e8  por xmm1, xmm15
000073dfa87df0ed  movaps [r15+0x300], xmm1
000073dfa87df0f5  vmovaps xmm15, [rsp+0xE0]
000073dfa87df0fe  vmovaps xmm9, [rsp+0xE0]
000073dfa87df107  por xmm15, xmm9
000073dfa87df10c  movaps [r15+0x190], xmm15
000073dfa87df114  vmovaps xmm9, [rsp+0x50]
000073dfa87df11a  vpermilpd xmm9, xmm9, 0x00
000073dfa87df120  vmovaps [rsp+0x90], xmm1
000073dfa87df129  vmovaps [rsp+0xE0], xmm15
000073dfa87df132  vmovaps xmm15, [rsp+0x80]
000073dfa87df13b  vmovaps [rsp+0x80], xmm14
000073dfa87df144  movaps xmm1, xmm15
000073dfa87df148  mulpd xmm1, xmm9
000073dfa87df14d  vcmppd xmm14, xmm1, xmm1, 0x03
000073dfa87df152  ptest xmm14, xmm14
000073dfa87df158  jnz 0x000073DFA87E0E52
000073dfa87df15e  lea r12, [rax+0x90]
000073dfa87df165  movups xmm15, [r13+r12*1]
000073dfa87df16b  vmovaps xmm14, [rsp+0xD0]
000073dfa87df174  vmovaps xmm9, [rsp+0xD0]
000073dfa87df17d  por xmm14, xmm9
000073dfa87df182  movaps [r15+0x1C0], xmm14
000073dfa87df18a  vmovaps xmm9, [rsp+0xC0]
000073dfa87df193  vmovaps [rsp+0xD0], xmm1
000073dfa87df19c  vmovaps xmm1, [rsp+0xC0]
000073dfa87df1a5  por xmm9, xmm1
000073dfa87df1aa  movaps [r15+0x200], xmm9
000073dfa87df1b2  vmovaps [rsp+0xC0], xmm2
000073dfa87df1bb  vmovaps xmm1, [rsp+0xC0]
000073dfa87df1c4  por xmm2, xmm1
000073dfa87df1c8  movaps [r15+0x2D0], xmm2
000073dfa87df1d0  vmovaps [rsp+0xC0], xmm8
000073dfa87df1d9  vmovaps xmm1, [rsp+0xC0]
000073dfa87df1e2  por xmm8, xmm1
000073dfa87df1e7  movaps [r15+0x2E0], xmm8
000073dfa87df1ef  vmovaps [rsp+0xC0], xmm15
000073dfa87df1f8  movaps xmm1, xmm5
000073dfa87df1fb  addpd xmm1, xmm7
000073dfa87df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000073dfa87df204  ptest xmm15, xmm15
000073dfa87df20a  jnz 0x000073DFA87E0F9E
000073dfa87df210  vmovaps xmm15, [rsp+0x50]
000073dfa87df216  vpermilpd xmm15, xmm15, 0x00
000073dfa87df21c  vmovaps xmm5, [rsp+0xC0]
000073dfa87df225  vmovaps [rsp+0xC0], xmm1
000073dfa87df22e  movaps xmm7, xmm5
000073dfa87df231  mulpd xmm7, xmm15
000073dfa87df236  vcmppd xmm1, xmm7, xmm7, 0x03
000073dfa87df23b  ptest xmm1, xmm1
000073dfa87df240  jnz 0x000073DFA87E10DE
000073dfa87df246  lea r12, [rax+0x80]
000073dfa87df24d  movups xmm1, [r13+r12*1]
000073dfa87df253  vmovaps xmm5, [rsp+0x70]
000073dfa87df259  vmovaps [rsp+0x70], xmm1
000073dfa87df25f  movaps xmm15, xmm5
000073dfa87df263  addpd xmm15, xmm3
000073dfa87df268  vcmppd xmm1, xmm15, xmm15, 0x03
000073dfa87df26e  ptest xmm1, xmm1
000073dfa87df273  jnz 0x000073DFA87E1229
000073dfa87df279  vmovaps xmm5, [rsp+0x80]
000073dfa87df282  movaps xmm1, xmm5
000073dfa87df285  addpd xmm1, xmm4
000073dfa87df289  vcmppd xmm3, xmm1, xmm1, 0x03
000073dfa87df28e  ptest xmm3, xmm3
000073dfa87df293  jnz 0x000073DFA87E136B
000073dfa87df299  vmovaps [rsp+0x80], xmm10
000073dfa87df2a2  vmovaps xmm5, [rsp+0x80]
000073dfa87df2ab  por xmm10, xmm5
000073dfa87df2b0  movaps [r15+0x2F0], xmm10
000073dfa87df2b8  vmovaps xmm5, [rsp+0x50]
000073dfa87df2be  vpermilpd xmm5, xmm5, 0x00
000073dfa87df2c4  vmovaps xmm3, [rsp+0x70]
000073dfa87df2ca  vmovaps [rsp+0x50], xmm1
000073dfa87df2d0  movaps xmm4, xmm3
000073dfa87df2d3  mulpd xmm4, xmm5
000073dfa87df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000073dfa87df2dc  ptest xmm1, xmm1
000073dfa87df2e1  jnz 0x000073DFA87E14AB
000073dfa87df2e7  lea r12, [rax+0xD0]
000073dfa87df2ee  movups xmm1, [r13+r12*1]
000073dfa87df2f4  vmovaps xmm3, [rsp+0xD0]
000073dfa87df2fd  vmovaps [rsp+0x70], xmm1
000073dfa87df303  movaps xmm5, xmm6
000073dfa87df306  addpd xmm5, xmm3
000073dfa87df30a  vcmppd xmm1, xmm5, xmm5, 0x03
000073dfa87df30f  ptest xmm1, xmm1
000073dfa87df314  jnz 0x000073DFA87E15F5
000073dfa87df31a  vmovaps xmm1, [rsp+0x60]
000073dfa87df320  vpermilpd xmm1, xmm1, 0x00
000073dfa87df326  movaps xmm6, xmm9
000073dfa87df32a  mulpd xmm6, xmm1
000073dfa87df32e  vcmppd xmm3, xmm6, xmm6, 0x03
000073dfa87df333  ptest xmm3, xmm3
000073dfa87df338  jnz 0x000073DFA87E1735
000073dfa87df33e  movaps [r15+0x260], xmm6
000073dfa87df346  vxorps xmm1, xmm1, xmm1
000073dfa87df34a  vpbroadcastq xmm1, xmm1
000073dfa87df34f  movaps [r15+0x1B0], xmm1
000073dfa87df357  vmovaps xmm1, [rsp+0x60]
000073dfa87df35d  vpermilpd xmm1, xmm1, 0x00
000073dfa87df363  vmovaps xmm3, [rsp+0x70]
000073dfa87df369  vmovaps [rsp+0x70], xmm15
000073dfa87df36f  movaps xmm9, xmm3
000073dfa87df373  mulpd xmm9, xmm1
000073dfa87df378  vcmppd xmm15, xmm9, xmm9, 0x03
000073dfa87df37e  ptest xmm15, xmm15
000073dfa87df384  jnz 0x000073DFA87E1876
000073dfa87df38a  lea r12, [rax+0xC0]
000073dfa87df391  movups xmm1, [r13+r12*1]
000073dfa87df397  vmovaps xmm3, [rsp+0xC0]
000073dfa87df3a0  vmovaps [rsp+0x80], xmm1
000073dfa87df3a9  movaps xmm15, xmm3
000073dfa87df3ad  addpd xmm15, xmm7
000073dfa87df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000073dfa87df3b8  ptest xmm1, xmm1
000073dfa87df3bd  jnz 0x000073DFA87E19C2
000073dfa87df3c3  vmovaps [rsp+0xC0], xmm13
000073dfa87df3cc  vmovaps xmm1, [rsp+0xC0]
000073dfa87df3d5  por xmm13, xmm1
000073dfa87df3da  movaps [r15+0x270], xmm13
000073dfa87df3e2  vmovaps xmm1, [rsp+0xB0]
000073dfa87df3eb  vmovaps xmm7, [rsp+0xB0]
000073dfa87df3f4  por xmm1, xmm7
000073dfa87df3f8  movaps [r15+0x1A0], xmm1
000073dfa87df400  vmovaps xmm1, [rsp+0x60]
000073dfa87df406  vpermilpd xmm1, xmm1, 0x00
000073dfa87df40c  vmovaps [rsp+0xB0], xmm1
000073dfa87df415  vmovaps xmm1, [rsp+0x80]
000073dfa87df41e  vmovaps [rsp+0x80], xmm15
000073dfa87df427  vmovaps xmm15, [rsp+0xB0]
000073dfa87df430  vmovaps [rsp+0xB0], xmm14
000073dfa87df439  movaps xmm3, xmm1
000073dfa87df43c  mulpd xmm3, xmm15
000073dfa87df441  vcmppd xmm14, xmm3, xmm3, 0x03
000073dfa87df446  ptest xmm14, xmm14
000073dfa87df44c  jnz 0x000073DFA87E1B04
000073dfa87df452  lea r12, [rax+0x20]
000073dfa87df456  movups xmm1, [r13+r12*1]
000073dfa87df45c  movaps [r15+0x110], xmm1
000073dfa87df464  vmovaps xmm14, [rsp+0x70]
000073dfa87df46a  vmovaps [rsp+0x70], xmm1
000073dfa87df470  movaps xmm15, xmm14
000073dfa87df474  addpd xmm15, xmm4
000073dfa87df479  vcmppd xmm1, xmm15, xmm15, 0x03
000073dfa87df47f  ptest xmm1, xmm1
000073dfa87df484  jnz 0x000073DFA87E1C4F
000073dfa87df48a  vmovaps xmm1, [rsp+0x60]
000073dfa87df490  vpermilpd xmm1, xmm1, 0x00
000073dfa87df496  movaps xmm14, xmm2
000073dfa87df49a  mulpd xmm14, xmm1
000073dfa87df49f  vcmppd xmm4, xmm14, xmm14, 0x03
000073dfa87df4a5  ptest xmm4, xmm4
000073dfa87df4aa  jnz 0x000073DFA87E1D92
000073dfa87df4b0  vmovaps xmm4, [rsp+0x50]
000073dfa87df4b6  movaps xmm1, xmm4
000073dfa87df4b9  addpd xmm1, xmm9
000073dfa87df4be  vcmppd xmm2, xmm1, xmm1, 0x03
000073dfa87df4c3  ptest xmm2, xmm2
000073dfa87df4c8  jnz 0x000073DFA87E1ED4
000073dfa87df4ce  vmovaps xmm9, [rsp+0x30]
000073dfa87df4d4  vpermilpd xmm9, xmm9, 0x00
000073dfa87df4da  vmovaps xmm2, [rsp+0x70]
000073dfa87df4e0  vmovaps [rsp+0x50], xmm1
000073dfa87df4e6  movaps xmm4, xmm2
000073dfa87df4e9  mulpd xmm4, xmm9
000073dfa87df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000073dfa87df4f3  ptest xmm1, xmm1
000073dfa87df4f8  jnz 0x000073DFA87E2015
000073dfa87df4fe  vmovaps xmm1, [rsp+0x30]
000073dfa87df504  vpermilpd xmm1, xmm1, 0x00
000073dfa87df50a  vmovaps xmm2, [rsp+0x90]
000073dfa87df513  vmovaps [rsp+0x60], xmm15
000073dfa87df519  movaps xmm9, xmm2
000073dfa87df51d  mulpd xmm9, xmm1
000073dfa87df522  vcmppd xmm15, xmm9, xmm9, 0x03
000073dfa87df528  ptest xmm15, xmm15
000073dfa87df52e  jnz 0x000073DFA87E2156
000073dfa87df534  vmovaps xmm15, [rsp+0x80]
000073dfa87df53d  movaps xmm1, xmm15
000073dfa87df541  addpd xmm1, xmm6
000073dfa87df545  vcmppd xmm2, xmm1, xmm1, 0x03
000073dfa87df54a  ptest xmm2, xmm2
000073dfa87df54f  jnz 0x000073DFA87E2298
000073dfa87df555  movaps xmm15, xmm5
000073dfa87df559  addpd xmm15, xmm3
000073dfa87df55e  vcmppd xmm6, xmm15, xmm15, 0x03
000073dfa87df564  ptest xmm6, xmm6
000073dfa87df569  jnz 0x000073DFA87E23D9
000073dfa87df56f  vmovaps xmm6, [rsp+0x30]
000073dfa87df575  vpermilpd xmm6, xmm6, 0x00
000073dfa87df57b  movaps xmm5, xmm8
000073dfa87df57f  mulpd xmm5, xmm6
000073dfa87df583  vcmppd xmm3, xmm5, xmm5, 0x03
000073dfa87df588  ptest xmm3, xmm3
000073dfa87df58d  jnz 0x000073DFA87E251B
000073dfa87df593  vmovaps xmm8, [rsp+0x30]
000073dfa87df599  vpermilpd xmm8, xmm8, 0x00
000073dfa87df59f  movaps xmm6, xmm10
000073dfa87df5a3  mulpd xmm6, xmm8
000073dfa87df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000073dfa87df5ad  ptest xmm3, xmm3
000073dfa87df5b2  jnz 0x000073DFA87E265C
000073dfa87df5b8  vmovaps xmm8, [rsp+0x60]
000073dfa87df5be  movaps xmm10, xmm8
000073dfa87df5c2  addpd xmm10, xmm14
000073dfa87df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000073dfa87df5cd  ptest xmm3, xmm3
000073dfa87df5d2  jnz 0x000073DFA87E279E
000073dfa87df5d8  vmovaps xmm8, [rsp+0x50]
000073dfa87df5de  movaps xmm14, xmm8
000073dfa87df5e2  addpd xmm14, xmm4
000073dfa87df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000073dfa87df5ed  ptest xmm3, xmm3
000073dfa87df5f2  jnz 0x000073DFA87E28E2
000073dfa87df5f8  vmovaps xmm8, [rsp+0x40]
000073dfa87df5fe  vpermilpd xmm8, xmm8, 0x00
000073dfa87df604  movaps xmm4, xmm13
000073dfa87df608  mulpd xmm4, xmm8
000073dfa87df60d  vcmppd xmm3, xmm4, xmm4, 0x03
000073dfa87df612  ptest xmm3, xmm3
000073dfa87df617  jnz 0x000073DFA87E2A25
000073dfa87df61d  movaps xmm13, xmm15
000073dfa87df621  addpd xmm13, xmm9
000073dfa87df626  vcmppd xmm8, xmm13, xmm13, 0x03
000073dfa87df62c  ptest xmm8, xmm8
000073dfa87df632  jnz 0x000073DFA87E2B67
000073dfa87df638  movaps xmm15, xmm1
000073dfa87df63c  addpd xmm15, xmm5
000073dfa87df641  vcmppd xmm9, xmm15, xmm15, 0x03
000073dfa87df647  ptest xmm9, xmm9
000073dfa87df64d  jnz 0x000073DFA87E2CAB
000073dfa87df653  vmovaps [rsp+0x30], xmm11
000073dfa87df659  vmovaps xmm1, [rsp+0x30]
000073dfa87df65f  por xmm11, xmm1
000073dfa87df664  movaps [r15+0x250], xmm11
000073dfa87df66c  vmovaps [rsp+0x30], xmm12
000073dfa87df672  vmovaps xmm1, [rsp+0x30]
000073dfa87df678  por xmm12, xmm1
000073dfa87df67d  movaps [r15+0x2A0], xmm12
000073dfa87df685  vmovaps xmm1, [rsp+0xA0]
000073dfa87df68e  vmovaps xmm11, [rsp+0xA0]
000073dfa87df697  por xmm1, xmm11
000073dfa87df69c  movaps [r15+0x1D0], xmm1
000073dfa87df6a4  lea r12, [rax+0x40]
000073dfa87df6a8  movups xmm1, [r13+r12*1]
000073dfa87df6ae  movaps [r15+0x2C0], xmm1
000073dfa87df6b6  vmovaps xmm11, [rsp+0x40]
000073dfa87df6bc  vpermilpd xmm11, xmm11, 0x00
000073dfa87df6c2  vmovaps xmm8, [rsp+0xE0]
000073dfa87df6cb  movaps xmm9, xmm8
000073dfa87df6cf  mulpd xmm9, xmm11
000073dfa87df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000073dfa87df6da  ptest xmm5, xmm5
000073dfa87df6df  jnz 0x000073DFA87E2DF7
000073dfa87df6e5  movaps xmm11, xmm10
000073dfa87df6e9  addpd xmm11, xmm6
000073dfa87df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000073dfa87df6f4  ptest xmm8, xmm8
000073dfa87df6fa  jnz 0x000073DFA87E2F3B
000073dfa87df700  movaps xmm10, xmm14
000073dfa87df704  addpd xmm10, xmm4
000073dfa87df709  vcmppd xmm8, xmm10, xmm10, 0x03
000073dfa87df70f  ptest xmm8, xmm8
000073dfa87df715  jnz 0x000073DFA87E307E
000073dfa87df71b  vmovaps xmm14, [rsp+0x40]
000073dfa87df721  vpermilpd xmm14, xmm14, 0x00
000073dfa87df727  movaps xmm8, xmm1
000073dfa87df72b  mulpd xmm8, xmm14
000073dfa87df730  vcmppd xmm6, xmm8, xmm8, 0x03
000073dfa87df736  ptest xmm6, xmm6
000073dfa87df73b  jnz 0x000073DFA87E31C1
000073dfa87df741  movaps xmm1, [r15+0x2B0]
000073dfa87df749  vmovaps xmm14, [rsp+0x40]
000073dfa87df74f  vpermilpd xmm14, xmm14, 0x00
000073dfa87df755  movaps xmm6, xmm1
000073dfa87df758  mulpd xmm6, xmm14
000073dfa87df75d  vcmppd xmm5, xmm6, xmm6, 0x03
000073dfa87df762  ptest xmm5, xmm5
000073dfa87df767  jnz 0x000073DFA87E3304
000073dfa87df76d  vmovaps xmm1, [rsp+0x10]
000073dfa87df773  vpermilpd xmm1, xmm1, 0x00
000073dfa87df779  movaps xmm14, xmm12
000073dfa87df77d  mulpd xmm14, xmm1
000073dfa87df782  vcmppd xmm5, xmm14, xmm14, 0x03
000073dfa87df788  ptest xmm5, xmm5
000073dfa87df78d  jnz 0x000073DFA87E3445
000073dfa87df793  movaps xmm1, xmm13
000073dfa87df797  addpd xmm1, xmm9
000073dfa87df79c  vcmppd xmm12, xmm1, xmm1, 0x03
000073dfa87df7a1  ptest xmm12, xmm12
000073dfa87df7a7  jnz 0x000073DFA87E3588
000073dfa87df7ad  vmovaps xmm13, [rsp+0x10]
000073dfa87df7b3  vpermilpd xmm13, xmm13, 0x00
000073dfa87df7b9  movaps xmm12, xmm7
000073dfa87df7bd  mulpd xmm12, xmm13
000073dfa87df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000073dfa87df7c8  ptest xmm9, xmm9
000073dfa87df7ce  jnz 0x000073DFA87E36CA
000073dfa87df7d4  movaps xmm13, xmm15
000073dfa87df7d8  addpd xmm13, xmm8
000073dfa87df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000073dfa87df7e3  ptest xmm9, xmm9
000073dfa87df7e9  jnz 0x000073DFA87E380D
000073dfa87df7ef  movaps xmm15, [r15+0x290]
000073dfa87df7f7  vmovaps xmm9, [rsp+0x10]
000073dfa87df7fd  vpermilpd xmm9, xmm9, 0x00
000073dfa87df803  movaps xmm8, xmm15
000073dfa87df807  mulpd xmm8, xmm9
000073dfa87df80c  vcmppd xmm7, xmm8, xmm8, 0x03
000073dfa87df812  ptest xmm7, xmm7
000073dfa87df817  jnz 0x000073DFA87E3951
000073dfa87df81d  movaps xmm15, xmm11
000073dfa87df821  addpd xmm15, xmm6
000073dfa87df826  vcmppd xmm9, xmm15, xmm15, 0x03
000073dfa87df82c  ptest xmm9, xmm9
000073dfa87df832  jnz 0x000073DFA87E3A95
000073dfa87df838  movaps xmm11, [r15+0x1E0]
000073dfa87df840  vmovaps xmm9, [rsp+0x10]
000073dfa87df846  vpermilpd xmm9, xmm9, 0x00
000073dfa87df84c  movaps xmm7, xmm11
000073dfa87df850  mulpd xmm7, xmm9
000073dfa87df855  vcmppd xmm6, xmm7, xmm7, 0x03
000073dfa87df85a  ptest xmm6, xmm6
000073dfa87df85f  jnz 0x000073DFA87E3BD8
000073dfa87df865  movaps xmm11, xmm10
000073dfa87df869  addpd xmm11, xmm14
000073dfa87df86e  vcmppd xmm9, xmm11, xmm11, 0x03
000073dfa87df874  ptest xmm9, xmm9
000073dfa87df87a  jnz 0x000073DFA87E3D1A
000073dfa87df880  lea r12, [rax+0x70]
000073dfa87df884  movups xmm14, [r13+r12*1]
000073dfa87df88a  movaps [r15+0x240], xmm14
000073dfa87df892  movaps xmm10, xmm1
000073dfa87df896  addpd xmm10, xmm12
000073dfa87df89b  vcmppd xmm9, xmm10, xmm10, 0x03
000073dfa87df8a1  ptest xmm9, xmm9
000073dfa87df8a7  jnz 0x000073DFA87E3E68
000073dfa87df8ad  movaps [r15+0x170], xmm10
000073dfa87df8b5  vmovaps xmm1, [rsp+0x20]
000073dfa87df8bb  vpermilpd xmm1, xmm1, 0x00
000073dfa87df8c1  movaps xmm12, xmm14
000073dfa87df8c5  mulpd xmm12, xmm1
000073dfa87df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000073dfa87df8d0  ptest xmm9, xmm9
000073dfa87df8d6  jnz 0x000073DFA87E3FAB
000073dfa87df8dc  vmovaps xmm1, [rsp+0x20]
000073dfa87df8e2  vpermilpd xmm1, xmm1, 0x00
000073dfa87df8e8  vmovaps xmm9, [rsp+0xB0]
000073dfa87df8f1  movaps xmm14, xmm9
000073dfa87df8f5  mulpd xmm14, xmm1
000073dfa87df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000073dfa87df900  ptest xmm6, xmm6
000073dfa87df905  jnz 0x000073DFA87E40EE
000073dfa87df90b  movaps [r15+0x180], xmm14
000073dfa87df913  movaps xmm1, xmm13
000073dfa87df917  addpd xmm1, xmm8
000073dfa87df91c  vcmppd xmm9, xmm1, xmm1, 0x03
000073dfa87df921  ptest xmm9, xmm9
000073dfa87df927  jnz 0x000073DFA87E4231
000073dfa87df92d  movaps [r15+0x210], xmm1
000073dfa87df935  movups xmm13, [r13+rax*1]
000073dfa87df93b  lea r12, [rax+0x10]
000073dfa87df93f  movups xmm9, [r13+r12*1]
000073dfa87df945  movaps [r15+0x230], xmm9
000073dfa87df94d  movaps xmm8, xmm15
000073dfa87df951  addpd xmm8, xmm7
000073dfa87df956  vcmppd xmm6, xmm8, xmm8, 0x03
000073dfa87df95c  ptest xmm6, xmm6
000073dfa87df961  jnz 0x000073DFA87E4387
000073dfa87df967  movaps [r15+0x130], xmm8
000073dfa87df96f  vmovaps xmm15, [rsp+0x20]
000073dfa87df975  vpermilpd xmm15, xmm15, 0x00
000073dfa87df97b  movaps xmm7, xmm9
000073dfa87df97f  mulpd xmm7, xmm15
000073dfa87df984  vcmppd xmm6, xmm7, xmm7, 0x03
000073dfa87df989  ptest xmm6, xmm6
000073dfa87df98e  jnz 0x000073DFA87E44CA
000073dfa87df994  movaps [r15+0x220], xmm7
000073dfa87df99c  vmovaps xmm15, [rsp+0x20]
000073dfa87df9a2  vpermilpd xmm15, xmm15, 0x00
000073dfa87df9a8  movaps xmm9, xmm13
000073dfa87df9ac  mulpd xmm9, xmm15
000073dfa87df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000073dfa87df9b7  ptest xmm6, xmm6
000073dfa87df9bc  jnz 0x000073DFA87E460C
000073dfa87df9c2  movaps xmm15, xmm11
000073dfa87df9c6  addpd xmm15, xmm12
000073dfa87df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000073dfa87df9d1  ptest xmm13, xmm13
000073dfa87df9d7  jnz 0x000073DFA87E4750
000073dfa87df9dd  movaps [r15+0x140], xmm15
000073dfa87df9e5  movaps xmm13, xmm10
000073dfa87df9e9  addpd xmm13, xmm14
000073dfa87df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000073dfa87df9f4  ptest xmm12, xmm12
000073dfa87df9fa  jnz 0x000073DFA87E4894
000073dfa87dfa00  movaps [r15+0x150], xmm13
000073dfa87dfa08  movaps xmm14, xmm1
000073dfa87dfa0c  addpd xmm14, xmm7
000073dfa87dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000073dfa87dfa17  ptest xmm12, xmm12
000073dfa87dfa1d  jnz 0x000073DFA87E49D8
000073dfa87dfa23  movaps [r15+0x160], xmm14
000073dfa87dfa2b  movaps xmm1, xmm8
000073dfa87dfa2f  addpd xmm1, xmm9
000073dfa87dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000073dfa87dfa39  ptest xmm12, xmm12
000073dfa87dfa3f  jnz 0x000073DFA87E4B1A
000073dfa87dfa45  movaps [r15+0x120], xmm1
000073dfa87dfa4d  movups [r13+r14*1], xmm15
000073dfa87dfa53  lea rax, [r14+0x10]
000073dfa87dfa57  movups [r13+rax*1], xmm13
000073dfa87dfa5d  lea rax, [r14+0x20]
000073dfa87dfa61  movups [r13+rax*1], xmm14
000073dfa87dfa67  lea rax, [r14+0x30]
000073dfa87dfa6b  movups [r13+rax*1], xmm1
000073dfa87dfa71  mov eax, [r15+0x108]
000073dfa87dfa78  sahf
000073dfa87dfa79  jnz 0x000073DFA87DFAAB
000073dfa87dfa7b  cmp dword ptr [r15+0x318], 0x00
000073dfa87dfa83  jz 0x000073DFA87DEAE0
000073dfa87dfa89  nop [rax+rax*1], ax
000073dfa87dfa92  nop [rax+rax*1], eax
000073dfa87dfa9a  mov eax, 0x4106D0
000073dfa87dfa9f  mov [r15+0x100], rax
000073dfa87dfaa6  jmp 0x000073DFA85FE110
000073dfa87dfaab  cmp dword ptr [r15+0x318], 0x00
000073dfa87dfab3  jz 0x000073DFA87D89C0
000073dfa87dfab9  nop [rax+rax*1], ax
000073dfa87dfac2  nop [rax+rax*1], eax
000073dfa87dfaca  mov eax, 0x410504
000073dfa87dfacf  mov [r15+0x100], rax
000073dfa87dfad6  jmp 0x000073DFA85FE110
000073dfa87dfadb  int3
000073dfa87dfadc  call 0x000073DFA86E27E0
000073dfa87dfae1  jmp 0x000073DFA87DEBBF
000073dfa87dfae6  call 0x000073DFA86E1570
000073dfa87dfaeb  jmp 0x000073DFA87DEBC8
000073dfa87dfaf0  call 0x000073DFA86E27E0
000073dfa87dfaf5  jmp 0x000073DFA87DEC24
000073dfa87dfafa  call 0x000073DFA86E1570
000073dfa87dfaff  jmp 0x000073DFA87DEC2D
000073dfa87dfb04  call 0x000073DFA86E27E0
000073dfa87dfb09  jmp 0x000073DFA87DEC70
000073dfa87dfb0e  call 0x000073DFA86E1570
000073dfa87dfb13  jmp 0x000073DFA87DEC79
000073dfa87dfb18  call 0x000073DFA860DC20
000073dfa87dfb1d  jmp 0x000073DFA87DECB8
000073dfa87dfb22  call 0x000073DFA86D59C0
000073dfa87dfb27  jmp 0x000073DFA87DECCB
000073dfa87dfb2c  call 0x000073DFA86E0E30
000073dfa87dfb31  jmp 0x000073DFA87DECE9
000073dfa87dfb36  call 0x000073DFA86DFBC0
000073dfa87dfb3b  jmp 0x000073DFA87DECF3
000073dfa87dfb40  call 0x000073DFA86DE950
000073dfa87dfb45  jmp 0x000073DFA87DECFD
000073dfa87dfb4a  sub rsp, 0x08
000073dfa87dfb4e  push rax
000073dfa87dfb4f  push rcx
000073dfa87dfb50  push rdx
000073dfa87dfb51  push rdi
000073dfa87dfb52  push rsi
000073dfa87dfb53  push r8
000073dfa87dfb55  push r9
000073dfa87dfb57  push r10
000073dfa87dfb59  push r11
000073dfa87dfb5b  sub rsp, 0xF0
000073dfa87dfb62  vmovaps [rsp], xmm0
000073dfa87dfb67  vmovaps [rsp+0x10], xmm1
000073dfa87dfb6d  vmovaps [rsp+0x20], xmm2
000073dfa87dfb73  vmovaps [rsp+0x30], xmm3
000073dfa87dfb79  vmovaps [rsp+0x40], xmm4
000073dfa87dfb7f  vmovaps [rsp+0x50], xmm5
000073dfa87dfb85  vmovaps [rsp+0x60], xmm6
000073dfa87dfb8b  vmovaps [rsp+0x70], xmm7
000073dfa87dfb91  vmovaps [rsp+0x80], xmm9
000073dfa87dfb9a  vmovaps [rsp+0x90], xmm10
000073dfa87dfba3  vmovaps [rsp+0xA0], xmm11
000073dfa87dfbac  vmovaps [rsp+0xB0], xmm12
000073dfa87dfbb5  vmovaps [rsp+0xC0], xmm13
000073dfa87dfbbe  vmovaps [rsp+0xD0], xmm14
000073dfa87dfbc7  vmovaps [rsp+0xE0], xmm15
000073dfa87dfbd0  sub rsp, 0x30
000073dfa87dfbd4  movaps [rsp], xmm8
000073dfa87dfbd9  movaps [rsp+0x10], xmm12
000073dfa87dfbdf  movaps [rsp+0x20], xmm15
000073dfa87dfbe5  lea rdi, [rsp]
000073dfa87dfbe9  mov esi, 0x00
000073dfa87dfbee  mov rax, 0x593AA1DA4530
000073dfa87dfbf8  call rax
000073dfa87dfbfa  movaps xmm8, [rsp]
000073dfa87dfbff  add rsp, 0x30
000073dfa87dfc03  vmovaps xmm0, [rsp]
000073dfa87dfc08  vmovaps xmm1, [rsp+0x10]
000073dfa87dfc0e  vmovaps xmm2, [rsp+0x20]
000073dfa87dfc14  vmovaps xmm3, [rsp+0x30]
000073dfa87dfc1a  vmovaps xmm4, [rsp+0x40]
000073dfa87dfc20  vmovaps xmm5, [rsp+0x50]
000073dfa87dfc26  vmovaps xmm6, [rsp+0x60]
000073dfa87dfc2c  vmovaps xmm7, [rsp+0x70]
000073dfa87dfc32  vmovaps xmm9, [rsp+0x80]
000073dfa87dfc3b  vmovaps xmm10, [rsp+0x90]
000073dfa87dfc44  vmovaps xmm11, [rsp+0xA0]
000073dfa87dfc4d  vmovaps xmm12, [rsp+0xB0]
000073dfa87dfc56  vmovaps xmm13, [rsp+0xC0]
000073dfa87dfc5f  vmovaps xmm14, [rsp+0xD0]
000073dfa87dfc68  vmovaps xmm15, [rsp+0xE0]
000073dfa87dfc71  add rsp, 0xF0
000073dfa87dfc78  pop r11
000073dfa87dfc7a  pop r10
000073dfa87dfc7c  pop r9
000073dfa87dfc7e  pop r8
000073dfa87dfc80  pop rsi
000073dfa87dfc81  pop rdi
000073dfa87dfc82  pop rdx
000073dfa87dfc83  pop rcx
000073dfa87dfc84  pop rax
000073dfa87dfc85  add rsp, 0x08
000073dfa87dfc89  jmp 0x000073DFA87DED27
000073dfa87dfc8e  sub rsp, 0x08
000073dfa87dfc92  push rax
000073dfa87dfc93  push rcx
000073dfa87dfc94  push rdx
000073dfa87dfc95  push rdi
000073dfa87dfc96  push rsi
000073dfa87dfc97  push r8
000073dfa87dfc99  push r9
000073dfa87dfc9b  push r10
000073dfa87dfc9d  push r11
000073dfa87dfc9f  sub rsp, 0xF0
000073dfa87dfca6  vmovaps [rsp], xmm0
000073dfa87dfcab  vmovaps [rsp+0x10], xmm1
000073dfa87dfcb1  vmovaps [rsp+0x20], xmm2
000073dfa87dfcb7  vmovaps [rsp+0x30], xmm3
000073dfa87dfcbd  vmovaps [rsp+0x40], xmm4
000073dfa87dfcc3  vmovaps [rsp+0x50], xmm5
000073dfa87dfcc9  vmovaps [rsp+0x60], xmm6
000073dfa87dfccf  vmovaps [rsp+0x70], xmm8
000073dfa87dfcd5  vmovaps [rsp+0x80], xmm9
000073dfa87dfcde  vmovaps [rsp+0x90], xmm10
000073dfa87dfce7  vmovaps [rsp+0xA0], xmm11
000073dfa87dfcf0  vmovaps [rsp+0xB0], xmm12
000073dfa87dfcf9  vmovaps [rsp+0xC0], xmm13
000073dfa87dfd02  vmovaps [rsp+0xD0], xmm14
000073dfa87dfd0b  vmovaps [rsp+0xE0], xmm15
000073dfa87dfd14  sub rsp, 0x30
000073dfa87dfd18  movaps [rsp], xmm7
000073dfa87dfd1c  movaps [rsp+0x10], xmm9
000073dfa87dfd22  movaps [rsp+0x20], xmm15
000073dfa87dfd28  lea rdi, [rsp]
000073dfa87dfd2c  mov esi, 0x00
000073dfa87dfd31  mov rax, 0x593AA1DA4530
000073dfa87dfd3b  call rax
000073dfa87dfd3d  movaps xmm7, [rsp]
000073dfa87dfd41  add rsp, 0x30
000073dfa87dfd45  vmovaps xmm0, [rsp]
000073dfa87dfd4a  vmovaps xmm1, [rsp+0x10]
000073dfa87dfd50  vmovaps xmm2, [rsp+0x20]
000073dfa87dfd56  vmovaps xmm3, [rsp+0x30]
000073dfa87dfd5c  vmovaps xmm4, [rsp+0x40]
000073dfa87dfd62  vmovaps xmm5, [rsp+0x50]
000073dfa87dfd68  vmovaps xmm6, [rsp+0x60]
000073dfa87dfd6e  vmovaps xmm8, [rsp+0x70]
000073dfa87dfd74  vmovaps xmm9, [rsp+0x80]
000073dfa87dfd7d  vmovaps xmm10, [rsp+0x90]
000073dfa87dfd86  vmovaps xmm11, [rsp+0xA0]
000073dfa87dfd8f  vmovaps xmm12, [rsp+0xB0]
000073dfa87dfd98  vmovaps xmm13, [rsp+0xC0]
000073dfa87dfda1  vmovaps xmm14, [rsp+0xD0]
000073dfa87dfdaa  vmovaps xmm15, [rsp+0xE0]
000073dfa87dfdb3  add rsp, 0xF0
000073dfa87dfdba  pop r11
000073dfa87dfdbc  pop r10
000073dfa87dfdbe  pop r9
000073dfa87dfdc0  pop r8
000073dfa87dfdc2  pop rsi
000073dfa87dfdc3  pop rdi
000073dfa87dfdc4  pop rdx
000073dfa87dfdc5  pop rcx
000073dfa87dfdc6  pop rax
000073dfa87dfdc7  add rsp, 0x08
000073dfa87dfdcb  jmp 0x000073DFA87DED55
000073dfa87dfdd0  sub rsp, 0x08
000073dfa87dfdd4  push rax
000073dfa87dfdd5  push rcx
000073dfa87dfdd6  push rdx
000073dfa87dfdd7  push rdi
000073dfa87dfdd8  push rsi
000073dfa87dfdd9  push r8
000073dfa87dfddb  push r9
000073dfa87dfddd  push r10
000073dfa87dfddf  push r11
000073dfa87dfde1  sub rsp, 0xF0
000073dfa87dfde8  vmovaps [rsp], xmm0
000073dfa87dfded  vmovaps [rsp+0x10], xmm1
000073dfa87dfdf3  vmovaps [rsp+0x20], xmm2
000073dfa87dfdf9  vmovaps [rsp+0x30], xmm3
000073dfa87dfdff  vmovaps [rsp+0x40], xmm4
000073dfa87dfe05  vmovaps [rsp+0x50], xmm5
000073dfa87dfe0b  vmovaps [rsp+0x60], xmm6
000073dfa87dfe11  vmovaps [rsp+0x70], xmm7
000073dfa87dfe17  vmovaps [rsp+0x80], xmm8
000073dfa87dfe20  vmovaps [rsp+0x90], xmm10
000073dfa87dfe29  vmovaps [rsp+0xA0], xmm11
000073dfa87dfe32  vmovaps [rsp+0xB0], xmm12
000073dfa87dfe3b  vmovaps [rsp+0xC0], xmm13
000073dfa87dfe44  vmovaps [rsp+0xD0], xmm14
000073dfa87dfe4d  vmovaps [rsp+0xE0], xmm15
000073dfa87dfe56  sub rsp, 0x30
000073dfa87dfe5a  movaps [rsp], xmm9
000073dfa87dfe5f  movaps [rsp+0x10], xmm12
000073dfa87dfe65  movaps [rsp+0x20], xmm10
000073dfa87dfe6b  lea rdi, [rsp]
000073dfa87dfe6f  mov esi, 0x00
000073dfa87dfe74  mov rax, 0x593AA1DA4530
000073dfa87dfe7e  call rax
000073dfa87dfe80  movaps xmm9, [rsp]
000073dfa87dfe85  add rsp, 0x30
000073dfa87dfe89  vmovaps xmm0, [rsp]
000073dfa87dfe8e  vmovaps xmm1, [rsp+0x10]
000073dfa87dfe94  vmovaps xmm2, [rsp+0x20]
000073dfa87dfe9a  vmovaps xmm3, [rsp+0x30]
000073dfa87dfea0  vmovaps xmm4, [rsp+0x40]
000073dfa87dfea6  vmovaps xmm5, [rsp+0x50]
000073dfa87dfeac  vmovaps xmm6, [rsp+0x60]
000073dfa87dfeb2  vmovaps xmm7, [rsp+0x70]
000073dfa87dfeb8  vmovaps xmm8, [rsp+0x80]
000073dfa87dfec1  vmovaps xmm10, [rsp+0x90]
000073dfa87dfeca  vmovaps xmm11, [rsp+0xA0]
000073dfa87dfed3  vmovaps xmm12, [rsp+0xB0]
000073dfa87dfedc  vmovaps xmm13, [rsp+0xC0]
000073dfa87dfee5  vmovaps xmm14, [rsp+0xD0]
000073dfa87dfeee  vmovaps xmm15, [rsp+0xE0]
000073dfa87dfef7  add rsp, 0xF0
000073dfa87dfefe  pop r11
000073dfa87dff00  pop r10
000073dfa87dff02  pop r9
000073dfa87dff04  pop r8
000073dfa87dff06  pop rsi
000073dfa87dff07  pop rdi
000073dfa87dff08  pop rdx
000073dfa87dff09  pop rcx
000073dfa87dff0a  pop rax
000073dfa87dff0b  add rsp, 0x08
000073dfa87dff0f  jmp 0x000073DFA87DED79
000073dfa87dff14  sub rsp, 0x08
000073dfa87dff18  push rax
000073dfa87dff19  push rcx
000073dfa87dff1a  push rdx
000073dfa87dff1b  push rdi
000073dfa87dff1c  push rsi
000073dfa87dff1d  push r8
000073dfa87dff1f  push r9
000073dfa87dff21  push r10
000073dfa87dff23  push r11
000073dfa87dff25  sub rsp, 0xF0
000073dfa87dff2c  vmovaps [rsp], xmm0
000073dfa87dff31  vmovaps [rsp+0x10], xmm1
000073dfa87dff37  vmovaps [rsp+0x20], xmm2
000073dfa87dff3d  vmovaps [rsp+0x30], xmm3
000073dfa87dff43  vmovaps [rsp+0x40], xmm4
000073dfa87dff49  vmovaps [rsp+0x50], xmm5
000073dfa87dff4f  vmovaps [rsp+0x60], xmm6
000073dfa87dff55  vmovaps [rsp+0x70], xmm7
000073dfa87dff5b  vmovaps [rsp+0x80], xmm8
000073dfa87dff64  vmovaps [rsp+0x90], xmm9
000073dfa87dff6d  vmovaps [rsp+0xA0], xmm11
000073dfa87dff76  vmovaps [rsp+0xB0], xmm12
000073dfa87dff7f  vmovaps [rsp+0xC0], xmm13
000073dfa87dff88  vmovaps [rsp+0xD0], xmm14
000073dfa87dff91  vmovaps [rsp+0xE0], xmm15
000073dfa87dff9a  sub rsp, 0x30
000073dfa87dff9e  movaps [rsp], xmm10
000073dfa87dffa3  movaps [rsp+0x10], xmm12
000073dfa87dffa9  movaps [rsp+0x20], xmm11
000073dfa87dffaf  lea rdi, [rsp]
000073dfa87dffb3  mov esi, 0x00
000073dfa87dffb8  mov rax, 0x593AA1DA4530
000073dfa87dffc2  call rax
000073dfa87dffc4  movaps xmm10, [rsp]
000073dfa87dffc9  add rsp, 0x30
000073dfa87dffcd  vmovaps xmm0, [rsp]
000073dfa87dffd2  vmovaps xmm1, [rsp+0x10]
000073dfa87dffd8  vmovaps xmm2, [rsp+0x20]
000073dfa87dffde  vmovaps xmm3, [rsp+0x30]
000073dfa87dffe4  vmovaps xmm4, [rsp+0x40]
000073dfa87dffea  vmovaps xmm5, [rsp+0x50]
000073dfa87dfff0  vmovaps xmm6, [rsp+0x60]
000073dfa87dfff6  vmovaps xmm7, [rsp+0x70]
000073dfa87dfffc  vmovaps xmm8, [rsp+0x80]
000073dfa87e0005  vmovaps xmm9, [rsp+0x90]
000073dfa87e000e  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0017  vmovaps xmm12, [rsp+0xB0]
000073dfa87e0020  vmovaps xmm13, [rsp+0xC0]
000073dfa87e0029  vmovaps xmm14, [rsp+0xD0]
000073dfa87e0032  vmovaps xmm15, [rsp+0xE0]
000073dfa87e003b  add rsp, 0xF0
000073dfa87e0042  pop r11
000073dfa87e0044  pop r10
000073dfa87e0046  pop r9
000073dfa87e0048  pop r8
000073dfa87e004a  pop rsi
000073dfa87e004b  pop rdi
000073dfa87e004c  pop rdx
000073dfa87e004d  pop rcx
000073dfa87e004e  pop rax
000073dfa87e004f  add rsp, 0x08
000073dfa87e0053  jmp 0x000073DFA87DED93
000073dfa87e0058  sub rsp, 0x08
000073dfa87e005c  push rax
000073dfa87e005d  push rcx
000073dfa87e005e  push rdx
000073dfa87e005f  push rdi
000073dfa87e0060  push rsi
000073dfa87e0061  push r8
000073dfa87e0063  push r9
000073dfa87e0065  push r10
000073dfa87e0067  push r11
000073dfa87e0069  sub rsp, 0xF0
000073dfa87e0070  vmovaps [rsp], xmm0
000073dfa87e0075  vmovaps [rsp+0x10], xmm1
000073dfa87e007b  vmovaps [rsp+0x20], xmm2
000073dfa87e0081  vmovaps [rsp+0x30], xmm3
000073dfa87e0087  vmovaps [rsp+0x40], xmm4
000073dfa87e008d  vmovaps [rsp+0x50], xmm5
000073dfa87e0093  vmovaps [rsp+0x60], xmm7
000073dfa87e0099  vmovaps [rsp+0x70], xmm8
000073dfa87e009f  vmovaps [rsp+0x80], xmm9
000073dfa87e00a8  vmovaps [rsp+0x90], xmm10
000073dfa87e00b1  vmovaps [rsp+0xA0], xmm11
000073dfa87e00ba  vmovaps [rsp+0xB0], xmm12
000073dfa87e00c3  vmovaps [rsp+0xC0], xmm13
000073dfa87e00cc  vmovaps [rsp+0xD0], xmm14
000073dfa87e00d5  vmovaps [rsp+0xE0], xmm15
000073dfa87e00de  sub rsp, 0x30
000073dfa87e00e2  movaps [rsp], xmm6
000073dfa87e00e6  movaps [rsp+0x10], xmm12
000073dfa87e00ec  movaps [rsp+0x20], xmm11
000073dfa87e00f2  lea rdi, [rsp]
000073dfa87e00f6  mov esi, 0x00
000073dfa87e00fb  mov rax, 0x593AA1DA4530
000073dfa87e0105  call rax
000073dfa87e0107  movaps xmm6, [rsp]
000073dfa87e010b  add rsp, 0x30
000073dfa87e010f  vmovaps xmm0, [rsp]
000073dfa87e0114  vmovaps xmm1, [rsp+0x10]
000073dfa87e011a  vmovaps xmm2, [rsp+0x20]
000073dfa87e0120  vmovaps xmm3, [rsp+0x30]
000073dfa87e0126  vmovaps xmm4, [rsp+0x40]
000073dfa87e012c  vmovaps xmm5, [rsp+0x50]
000073dfa87e0132  vmovaps xmm7, [rsp+0x60]
000073dfa87e0138  vmovaps xmm8, [rsp+0x70]
000073dfa87e013e  vmovaps xmm9, [rsp+0x80]
000073dfa87e0147  vmovaps xmm10, [rsp+0x90]
000073dfa87e0150  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0159  vmovaps xmm12, [rsp+0xB0]
000073dfa87e0162  vmovaps xmm13, [rsp+0xC0]
000073dfa87e016b  vmovaps xmm14, [rsp+0xD0]
000073dfa87e0174  vmovaps xmm15, [rsp+0xE0]
000073dfa87e017d  add rsp, 0xF0
000073dfa87e0184  pop r11
000073dfa87e0186  pop r10
000073dfa87e0188  pop r9
000073dfa87e018a  pop r8
000073dfa87e018c  pop rsi
000073dfa87e018d  pop rdi
000073dfa87e018e  pop rdx
000073dfa87e018f  pop rcx
000073dfa87e0190  pop rax
000073dfa87e0191  add rsp, 0x08
000073dfa87e0195  jmp 0x000073DFA87DEDB4
000073dfa87e019a  sub rsp, 0x08
000073dfa87e019e  push rax
000073dfa87e019f  push rcx
000073dfa87e01a0  push rdx
000073dfa87e01a1  push rdi
000073dfa87e01a2  push rsi
000073dfa87e01a3  push r8
000073dfa87e01a5  push r9
000073dfa87e01a7  push r10
000073dfa87e01a9  push r11
000073dfa87e01ab  sub rsp, 0xF0
000073dfa87e01b2  vmovaps [rsp], xmm0
000073dfa87e01b7  vmovaps [rsp+0x10], xmm1
000073dfa87e01bd  vmovaps [rsp+0x20], xmm2
000073dfa87e01c3  vmovaps [rsp+0x30], xmm4
000073dfa87e01c9  vmovaps [rsp+0x40], xmm5
000073dfa87e01cf  vmovaps [rsp+0x50], xmm6
000073dfa87e01d5  vmovaps [rsp+0x60], xmm7
000073dfa87e01db  vmovaps [rsp+0x70], xmm8
000073dfa87e01e1  vmovaps [rsp+0x80], xmm9
000073dfa87e01ea  vmovaps [rsp+0x90], xmm10
000073dfa87e01f3  vmovaps [rsp+0xA0], xmm11
000073dfa87e01fc  vmovaps [rsp+0xB0], xmm12
000073dfa87e0205  vmovaps [rsp+0xC0], xmm13
000073dfa87e020e  vmovaps [rsp+0xD0], xmm14
000073dfa87e0217  vmovaps [rsp+0xE0], xmm15
000073dfa87e0220  sub rsp, 0x30
000073dfa87e0224  movaps [rsp], xmm3
000073dfa87e0228  movaps [rsp+0x10], xmm5
000073dfa87e022d  movaps [rsp+0x20], xmm4
000073dfa87e0232  lea rdi, [rsp]
000073dfa87e0236  mov esi, 0x00
000073dfa87e023b  mov rax, 0x593AA1DA4530
000073dfa87e0245  call rax
000073dfa87e0247  movaps xmm3, [rsp]
000073dfa87e024b  add rsp, 0x30
000073dfa87e024f  vmovaps xmm0, [rsp]
000073dfa87e0254  vmovaps xmm1, [rsp+0x10]
000073dfa87e025a  vmovaps xmm2, [rsp+0x20]
000073dfa87e0260  vmovaps xmm4, [rsp+0x30]
000073dfa87e0266  vmovaps xmm5, [rsp+0x40]
000073dfa87e026c  vmovaps xmm6, [rsp+0x50]
000073dfa87e0272  vmovaps xmm7, [rsp+0x60]
000073dfa87e0278  vmovaps xmm8, [rsp+0x70]
000073dfa87e027e  vmovaps xmm9, [rsp+0x80]
000073dfa87e0287  vmovaps xmm10, [rsp+0x90]
000073dfa87e0290  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0299  vmovaps xmm12, [rsp+0xB0]
000073dfa87e02a2  vmovaps xmm13, [rsp+0xC0]
000073dfa87e02ab  vmovaps xmm14, [rsp+0xD0]
000073dfa87e02b4  vmovaps xmm15, [rsp+0xE0]
000073dfa87e02bd  add rsp, 0xF0
000073dfa87e02c4  pop r11
000073dfa87e02c6  pop r10
000073dfa87e02c8  pop r9
000073dfa87e02ca  pop r8
000073dfa87e02cc  pop rsi
000073dfa87e02cd  pop rdi
000073dfa87e02ce  pop rdx
000073dfa87e02cf  pop rcx
000073dfa87e02d0  pop rax
000073dfa87e02d1  add rsp, 0x08
000073dfa87e02d5  jmp 0x000073DFA87DEE15
000073dfa87e02da  sub rsp, 0x08
000073dfa87e02de  push rax
000073dfa87e02df  push rcx
000073dfa87e02e0  push rdx
000073dfa87e02e1  push rdi
000073dfa87e02e2  push rsi
000073dfa87e02e3  push r8
000073dfa87e02e5  push r9
000073dfa87e02e7  push r10
000073dfa87e02e9  push r11
000073dfa87e02eb  sub rsp, 0xF0
000073dfa87e02f2  vmovaps [rsp], xmm0
000073dfa87e02f7  vmovaps [rsp+0x10], xmm1
000073dfa87e02fd  vmovaps [rsp+0x20], xmm2
000073dfa87e0303  vmovaps [rsp+0x30], xmm3
000073dfa87e0309  vmovaps [rsp+0x40], xmm4
000073dfa87e030f  vmovaps [rsp+0x50], xmm6
000073dfa87e0315  vmovaps [rsp+0x60], xmm7
000073dfa87e031b  vmovaps [rsp+0x70], xmm8
000073dfa87e0321  vmovaps [rsp+0x80], xmm9
000073dfa87e032a  vmovaps [rsp+0x90], xmm10
000073dfa87e0333  vmovaps [rsp+0xA0], xmm11
000073dfa87e033c  vmovaps [rsp+0xB0], xmm12
000073dfa87e0345  vmovaps [rsp+0xC0], xmm13
000073dfa87e034e  vmovaps [rsp+0xD0], xmm14
000073dfa87e0357  vmovaps [rsp+0xE0], xmm15
000073dfa87e0360  sub rsp, 0x30
000073dfa87e0364  movaps [rsp], xmm5
000073dfa87e0368  movaps [rsp+0x10], xmm8
000073dfa87e036e  movaps [rsp+0x20], xmm15
000073dfa87e0374  lea rdi, [rsp]
000073dfa87e0378  mov esi, 0x00
000073dfa87e037d  mov rax, 0x593AA1DA4530
000073dfa87e0387  call rax
000073dfa87e0389  movaps xmm5, [rsp]
000073dfa87e038d  add rsp, 0x30
000073dfa87e0391  vmovaps xmm0, [rsp]
000073dfa87e0396  vmovaps xmm1, [rsp+0x10]
000073dfa87e039c  vmovaps xmm2, [rsp+0x20]
000073dfa87e03a2  vmovaps xmm3, [rsp+0x30]
000073dfa87e03a8  vmovaps xmm4, [rsp+0x40]
000073dfa87e03ae  vmovaps xmm6, [rsp+0x50]
000073dfa87e03b4  vmovaps xmm7, [rsp+0x60]
000073dfa87e03ba  vmovaps xmm8, [rsp+0x70]
000073dfa87e03c0  vmovaps xmm9, [rsp+0x80]
000073dfa87e03c9  vmovaps xmm10, [rsp+0x90]
000073dfa87e03d2  vmovaps xmm11, [rsp+0xA0]
000073dfa87e03db  vmovaps xmm12, [rsp+0xB0]
000073dfa87e03e4  vmovaps xmm13, [rsp+0xC0]
000073dfa87e03ed  vmovaps xmm14, [rsp+0xD0]
000073dfa87e03f6  vmovaps xmm15, [rsp+0xE0]
000073dfa87e03ff  add rsp, 0xF0
000073dfa87e0406  pop r11
000073dfa87e0408  pop r10
000073dfa87e040a  pop r9
000073dfa87e040c  pop r8
000073dfa87e040e  pop rsi
000073dfa87e040f  pop rdi
000073dfa87e0410  pop rdx
000073dfa87e0411  pop rcx
000073dfa87e0412  pop rax
000073dfa87e0413  add rsp, 0x08
000073dfa87e0417  jmp 0x000073DFA87DEE53
000073dfa87e041c  sub rsp, 0x08
000073dfa87e0420  push rax
000073dfa87e0421  push rcx
000073dfa87e0422  push rdx
000073dfa87e0423  push rdi
000073dfa87e0424  push rsi
000073dfa87e0425  push r8
000073dfa87e0427  push r9
000073dfa87e0429  push r10
000073dfa87e042b  push r11
000073dfa87e042d  sub rsp, 0xF0
000073dfa87e0434  vmovaps [rsp], xmm0
000073dfa87e0439  vmovaps [rsp+0x10], xmm1
000073dfa87e043f  vmovaps [rsp+0x20], xmm2
000073dfa87e0445  vmovaps [rsp+0x30], xmm3
000073dfa87e044b  vmovaps [rsp+0x40], xmm5
000073dfa87e0451  vmovaps [rsp+0x50], xmm6
000073dfa87e0457  vmovaps [rsp+0x60], xmm7
000073dfa87e045d  vmovaps [rsp+0x70], xmm8
000073dfa87e0463  vmovaps [rsp+0x80], xmm9
000073dfa87e046c  vmovaps [rsp+0x90], xmm10
000073dfa87e0475  vmovaps [rsp+0xA0], xmm11
000073dfa87e047e  vmovaps [rsp+0xB0], xmm12
000073dfa87e0487  vmovaps [rsp+0xC0], xmm13
000073dfa87e0490  vmovaps [rsp+0xD0], xmm14
000073dfa87e0499  vmovaps [rsp+0xE0], xmm15
000073dfa87e04a2  sub rsp, 0x30
000073dfa87e04a6  movaps [rsp], xmm4
000073dfa87e04aa  movaps [rsp+0x10], xmm9
000073dfa87e04b0  movaps [rsp+0x20], xmm8
000073dfa87e04b6  lea rdi, [rsp]
000073dfa87e04ba  mov esi, 0x00
000073dfa87e04bf  mov rax, 0x593AA1DA4530
000073dfa87e04c9  call rax
000073dfa87e04cb  movaps xmm4, [rsp]
000073dfa87e04cf  add rsp, 0x30
000073dfa87e04d3  vmovaps xmm0, [rsp]
000073dfa87e04d8  vmovaps xmm1, [rsp+0x10]
000073dfa87e04de  vmovaps xmm2, [rsp+0x20]
000073dfa87e04e4  vmovaps xmm3, [rsp+0x30]
000073dfa87e04ea  vmovaps xmm5, [rsp+0x40]
000073dfa87e04f0  vmovaps xmm6, [rsp+0x50]
000073dfa87e04f6  vmovaps xmm7, [rsp+0x60]
000073dfa87e04fc  vmovaps xmm8, [rsp+0x70]
000073dfa87e0502  vmovaps xmm9, [rsp+0x80]
000073dfa87e050b  vmovaps xmm10, [rsp+0x90]
000073dfa87e0514  vmovaps xmm11, [rsp+0xA0]
000073dfa87e051d  vmovaps xmm12, [rsp+0xB0]
000073dfa87e0526  vmovaps xmm13, [rsp+0xC0]
000073dfa87e052f  vmovaps xmm14, [rsp+0xD0]
000073dfa87e0538  vmovaps xmm15, [rsp+0xE0]
000073dfa87e0541  add rsp, 0xF0
000073dfa87e0548  pop r11
000073dfa87e054a  pop r10
000073dfa87e054c  pop r9
000073dfa87e054e  pop r8
000073dfa87e0550  pop rsi
000073dfa87e0551  pop rdi
000073dfa87e0552  pop rdx
000073dfa87e0553  pop rcx
000073dfa87e0554  pop rax
000073dfa87e0555  add rsp, 0x08
000073dfa87e0559  jmp 0x000073DFA87DEE74
000073dfa87e055e  sub rsp, 0x08
000073dfa87e0562  push rax
000073dfa87e0563  push rcx
000073dfa87e0564  push rdx
000073dfa87e0565  push rdi
000073dfa87e0566  push rsi
000073dfa87e0567  push r8
000073dfa87e0569  push r9
000073dfa87e056b  push r10
000073dfa87e056d  push r11
000073dfa87e056f  sub rsp, 0xF0
000073dfa87e0576  vmovaps [rsp], xmm0
000073dfa87e057b  vmovaps [rsp+0x10], xmm1
000073dfa87e0581  vmovaps [rsp+0x20], xmm2
000073dfa87e0587  vmovaps [rsp+0x30], xmm3
000073dfa87e058d  vmovaps [rsp+0x40], xmm4
000073dfa87e0593  vmovaps [rsp+0x50], xmm5
000073dfa87e0599  vmovaps [rsp+0x60], xmm6
000073dfa87e059f  vmovaps [rsp+0x70], xmm7
000073dfa87e05a5  vmovaps [rsp+0x80], xmm8
000073dfa87e05ae  vmovaps [rsp+0x90], xmm10
000073dfa87e05b7  vmovaps [rsp+0xA0], xmm11
000073dfa87e05c0  vmovaps [rsp+0xB0], xmm12
000073dfa87e05c9  vmovaps [rsp+0xC0], xmm13
000073dfa87e05d2  vmovaps [rsp+0xD0], xmm14
000073dfa87e05db  vmovaps [rsp+0xE0], xmm15
000073dfa87e05e4  sub rsp, 0x30
000073dfa87e05e8  movaps [rsp], xmm9
000073dfa87e05ed  movaps [rsp+0x10], xmm10
000073dfa87e05f3  movaps [rsp+0x20], xmm8
000073dfa87e05f9  lea rdi, [rsp]
000073dfa87e05fd  mov esi, 0x00
000073dfa87e0602  mov rax, 0x593AA1DA4530
000073dfa87e060c  call rax
000073dfa87e060e  movaps xmm9, [rsp]
000073dfa87e0613  add rsp, 0x30
000073dfa87e0617  vmovaps xmm0, [rsp]
000073dfa87e061c  vmovaps xmm1, [rsp+0x10]
000073dfa87e0622  vmovaps xmm2, [rsp+0x20]
000073dfa87e0628  vmovaps xmm3, [rsp+0x30]
000073dfa87e062e  vmovaps xmm4, [rsp+0x40]
000073dfa87e0634  vmovaps xmm5, [rsp+0x50]
000073dfa87e063a  vmovaps xmm6, [rsp+0x60]
000073dfa87e0640  vmovaps xmm7, [rsp+0x70]
000073dfa87e0646  vmovaps xmm8, [rsp+0x80]
000073dfa87e064f  vmovaps xmm10, [rsp+0x90]
000073dfa87e0658  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0661  vmovaps xmm12, [rsp+0xB0]
000073dfa87e066a  vmovaps xmm13, [rsp+0xC0]
000073dfa87e0673  vmovaps xmm14, [rsp+0xD0]
000073dfa87e067c  vmovaps xmm15, [rsp+0xE0]
000073dfa87e0685  add rsp, 0xF0
000073dfa87e068c  pop r11
000073dfa87e068e  pop r10
000073dfa87e0690  pop r9
000073dfa87e0692  pop r8
000073dfa87e0694  pop rsi
000073dfa87e0695  pop rdi
000073dfa87e0696  pop rdx
000073dfa87e0697  pop rcx
000073dfa87e0698  pop rax
000073dfa87e0699  add rsp, 0x08
000073dfa87e069d  jmp 0x000073DFA87DEE8E
000073dfa87e06a2  call 0x000073DFA86B52F0
000073dfa87e06a7  jmp 0x000073DFA87DEFA8
000073dfa87e06ac  call 0x000073DFA86B52F0
000073dfa87e06b1  jmp 0x000073DFA87DEFBE
000073dfa87e06b6  sub rsp, 0x08
000073dfa87e06ba  push rax
000073dfa87e06bb  push rcx
000073dfa87e06bc  push rdx
000073dfa87e06bd  push rdi
000073dfa87e06be  push rsi
000073dfa87e06bf  push r8
000073dfa87e06c1  push r9
000073dfa87e06c3  push r10
000073dfa87e06c5  push r11
000073dfa87e06c7  sub rsp, 0xF0
000073dfa87e06ce  vmovaps [rsp], xmm0
000073dfa87e06d3  vmovaps [rsp+0x10], xmm2
000073dfa87e06d9  vmovaps [rsp+0x20], xmm3
000073dfa87e06df  vmovaps [rsp+0x30], xmm4
000073dfa87e06e5  vmovaps [rsp+0x40], xmm5
000073dfa87e06eb  vmovaps [rsp+0x50], xmm6
000073dfa87e06f1  vmovaps [rsp+0x60], xmm7
000073dfa87e06f7  vmovaps [rsp+0x70], xmm8
000073dfa87e06fd  vmovaps [rsp+0x80], xmm9
000073dfa87e0706  vmovaps [rsp+0x90], xmm10
000073dfa87e070f  vmovaps [rsp+0xA0], xmm11
000073dfa87e0718  vmovaps [rsp+0xB0], xmm12
000073dfa87e0721  vmovaps [rsp+0xC0], xmm13
000073dfa87e072a  vmovaps [rsp+0xD0], xmm14
000073dfa87e0733  vmovaps [rsp+0xE0], xmm15
000073dfa87e073c  sub rsp, 0x30
000073dfa87e0740  movaps [rsp], xmm1
000073dfa87e0744  movaps [rsp+0x10], xmm6
000073dfa87e0749  movaps [rsp+0x20], xmm15
000073dfa87e074f  lea rdi, [rsp]
000073dfa87e0753  mov esi, 0x00
000073dfa87e0758  mov rax, 0x593AA1DA4530
000073dfa87e0762  call rax
000073dfa87e0764  movaps xmm1, [rsp]
000073dfa87e0768  add rsp, 0x30
000073dfa87e076c  vmovaps xmm0, [rsp]
000073dfa87e0771  vmovaps xmm2, [rsp+0x10]
000073dfa87e0777  vmovaps xmm3, [rsp+0x20]
000073dfa87e077d  vmovaps xmm4, [rsp+0x30]
000073dfa87e0783  vmovaps xmm5, [rsp+0x40]
000073dfa87e0789  vmovaps xmm6, [rsp+0x50]
000073dfa87e078f  vmovaps xmm7, [rsp+0x60]
000073dfa87e0795  vmovaps xmm8, [rsp+0x70]
000073dfa87e079b  vmovaps xmm9, [rsp+0x80]
000073dfa87e07a4  vmovaps xmm10, [rsp+0x90]
000073dfa87e07ad  vmovaps xmm11, [rsp+0xA0]
000073dfa87e07b6  vmovaps xmm12, [rsp+0xB0]
000073dfa87e07bf  vmovaps xmm13, [rsp+0xC0]
000073dfa87e07c8  vmovaps xmm14, [rsp+0xD0]
000073dfa87e07d1  vmovaps xmm15, [rsp+0xE0]
000073dfa87e07da  add rsp, 0xF0
000073dfa87e07e1  pop r11
000073dfa87e07e3  pop r10
000073dfa87e07e5  pop r9
000073dfa87e07e7  pop r8
000073dfa87e07e9  pop rsi
000073dfa87e07ea  pop rdi
000073dfa87e07eb  pop rdx
000073dfa87e07ec  pop rcx
000073dfa87e07ed  pop rax
000073dfa87e07ee  add rsp, 0x08
000073dfa87e07f2  jmp 0x000073DFA87DEFFB
000073dfa87e07f7  call 0x000073DFA86C4620
000073dfa87e07fc  jmp 0x000073DFA87DF008
000073dfa87e0801  sub rsp, 0x08
000073dfa87e0805  push rax
000073dfa87e0806  push rcx
000073dfa87e0807  push rdx
000073dfa87e0808  push rdi
000073dfa87e0809  push rsi
000073dfa87e080a  push r8
000073dfa87e080c  push r9
000073dfa87e080e  push r10
000073dfa87e0810  push r11
000073dfa87e0812  sub rsp, 0xF0
000073dfa87e0819  vmovaps [rsp], xmm0
000073dfa87e081e  vmovaps [rsp+0x10], xmm1
000073dfa87e0824  vmovaps [rsp+0x20], xmm2
000073dfa87e082a  vmovaps [rsp+0x30], xmm3
000073dfa87e0830  vmovaps [rsp+0x40], xmm4
000073dfa87e0836  vmovaps [rsp+0x50], xmm5
000073dfa87e083c  vmovaps [rsp+0x60], xmm6
000073dfa87e0842  vmovaps [rsp+0x70], xmm7
000073dfa87e0848  vmovaps [rsp+0x80], xmm8
000073dfa87e0851  vmovaps [rsp+0x90], xmm9
000073dfa87e085a  vmovaps [rsp+0xA0], xmm10
000073dfa87e0863  vmovaps [rsp+0xB0], xmm11
000073dfa87e086c  vmovaps [rsp+0xC0], xmm12
000073dfa87e0875  vmovaps [rsp+0xD0], xmm13
000073dfa87e087e  vmovaps [rsp+0xE0], xmm15
000073dfa87e0887  sub rsp, 0x30
000073dfa87e088b  movaps [rsp], xmm14
000073dfa87e0890  movaps [rsp+0x10], xmm4
000073dfa87e0895  movaps [rsp+0x20], xmm3
000073dfa87e089a  lea rdi, [rsp]
000073dfa87e089e  mov esi, 0x00
000073dfa87e08a3  mov rax, 0x593AA1DA4530
000073dfa87e08ad  call rax
000073dfa87e08af  movaps xmm14, [rsp]
000073dfa87e08b4  add rsp, 0x30
000073dfa87e08b8  vmovaps xmm0, [rsp]
000073dfa87e08bd  vmovaps xmm1, [rsp+0x10]
000073dfa87e08c3  vmovaps xmm2, [rsp+0x20]
000073dfa87e08c9  vmovaps xmm3, [rsp+0x30]
000073dfa87e08cf  vmovaps xmm4, [rsp+0x40]
000073dfa87e08d5  vmovaps xmm5, [rsp+0x50]
000073dfa87e08db  vmovaps xmm6, [rsp+0x60]
000073dfa87e08e1  vmovaps xmm7, [rsp+0x70]
000073dfa87e08e7  vmovaps xmm8, [rsp+0x80]
000073dfa87e08f0  vmovaps xmm9, [rsp+0x90]
000073dfa87e08f9  vmovaps xmm10, [rsp+0xA0]
000073dfa87e0902  vmovaps xmm11, [rsp+0xB0]
000073dfa87e090b  vmovaps xmm12, [rsp+0xC0]
000073dfa87e0914  vmovaps xmm13, [rsp+0xD0]
000073dfa87e091d  vmovaps xmm15, [rsp+0xE0]
000073dfa87e0926  add rsp, 0xF0
000073dfa87e092d  pop r11
000073dfa87e092f  pop r10
000073dfa87e0931  pop r9
000073dfa87e0933  pop r8
000073dfa87e0935  pop rsi
000073dfa87e0936  pop rdi
000073dfa87e0937  pop rdx
000073dfa87e0938  pop rcx
000073dfa87e0939  pop rax
000073dfa87e093a  add rsp, 0x08
000073dfa87e093e  jmp 0x000073DFA87DF022
000073dfa87e0943  sub rsp, 0x08
000073dfa87e0947  push rax
000073dfa87e0948  push rcx
000073dfa87e0949  push rdx
000073dfa87e094a  push rdi
000073dfa87e094b  push rsi
000073dfa87e094c  push r8
000073dfa87e094e  push r9
000073dfa87e0950  push r10
000073dfa87e0952  push r11
000073dfa87e0954  sub rsp, 0xF0
000073dfa87e095b  vmovaps [rsp], xmm0
000073dfa87e0960  vmovaps [rsp+0x10], xmm1
000073dfa87e0966  vmovaps [rsp+0x20], xmm2
000073dfa87e096c  vmovaps [rsp+0x30], xmm3
000073dfa87e0972  vmovaps [rsp+0x40], xmm4
000073dfa87e0978  vmovaps [rsp+0x50], xmm5
000073dfa87e097e  vmovaps [rsp+0x60], xmm7
000073dfa87e0984  vmovaps [rsp+0x70], xmm8
000073dfa87e098a  vmovaps [rsp+0x80], xmm9
000073dfa87e0993  vmovaps [rsp+0x90], xmm10
000073dfa87e099c  vmovaps [rsp+0xA0], xmm11
000073dfa87e09a5  vmovaps [rsp+0xB0], xmm12
000073dfa87e09ae  vmovaps [rsp+0xC0], xmm13
000073dfa87e09b7  vmovaps [rsp+0xD0], xmm14
000073dfa87e09c0  vmovaps [rsp+0xE0], xmm15
000073dfa87e09c9  sub rsp, 0x30
000073dfa87e09cd  movaps [rsp], xmm6
000073dfa87e09d1  movaps [rsp+0x10], xmm9
000073dfa87e09d7  movaps [rsp+0x20], xmm7
000073dfa87e09dc  lea rdi, [rsp]
000073dfa87e09e0  mov esi, 0x00
000073dfa87e09e5  mov rax, 0x593AA1DA4530
000073dfa87e09ef  call rax
000073dfa87e09f1  movaps xmm6, [rsp]
000073dfa87e09f5  add rsp, 0x30
000073dfa87e09f9  vmovaps xmm0, [rsp]
000073dfa87e09fe  vmovaps xmm1, [rsp+0x10]
000073dfa87e0a04  vmovaps xmm2, [rsp+0x20]
000073dfa87e0a0a  vmovaps xmm3, [rsp+0x30]
000073dfa87e0a10  vmovaps xmm4, [rsp+0x40]
000073dfa87e0a16  vmovaps xmm5, [rsp+0x50]
000073dfa87e0a1c  vmovaps xmm7, [rsp+0x60]
000073dfa87e0a22  vmovaps xmm8, [rsp+0x70]
000073dfa87e0a28  vmovaps xmm9, [rsp+0x80]
000073dfa87e0a31  vmovaps xmm10, [rsp+0x90]
000073dfa87e0a3a  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0a43  vmovaps xmm12, [rsp+0xB0]
000073dfa87e0a4c  vmovaps xmm13, [rsp+0xC0]
000073dfa87e0a55  vmovaps xmm14, [rsp+0xD0]
000073dfa87e0a5e  vmovaps xmm15, [rsp+0xE0]
000073dfa87e0a67  add rsp, 0xF0
000073dfa87e0a6e  pop r11
000073dfa87e0a70  pop r10
000073dfa87e0a72  pop r9
000073dfa87e0a74  pop r8
000073dfa87e0a76  pop rsi
000073dfa87e0a77  pop rdi
000073dfa87e0a78  pop rdx
000073dfa87e0a79  pop rcx
000073dfa87e0a7a  pop rax
000073dfa87e0a7b  add rsp, 0x08
000073dfa87e0a7f  jmp 0x000073DFA87DF03A
000073dfa87e0a84  sub rsp, 0x08
000073dfa87e0a88  push rax
000073dfa87e0a89  push rcx
000073dfa87e0a8a  push rdx
000073dfa87e0a8b  push rdi
000073dfa87e0a8c  push rsi
000073dfa87e0a8d  push r8
000073dfa87e0a8f  push r9
000073dfa87e0a91  push r10
000073dfa87e0a93  push r11
000073dfa87e0a95  sub rsp, 0xF0
000073dfa87e0a9c  vmovaps [rsp], xmm0
000073dfa87e0aa1  vmovaps [rsp+0x10], xmm1
000073dfa87e0aa7  vmovaps [rsp+0x20], xmm2
000073dfa87e0aad  vmovaps [rsp+0x30], xmm3
000073dfa87e0ab3  vmovaps [rsp+0x40], xmm4
000073dfa87e0ab9  vmovaps [rsp+0x50], xmm5
000073dfa87e0abf  vmovaps [rsp+0x60], xmm6
000073dfa87e0ac5  vmovaps [rsp+0x70], xmm8
000073dfa87e0acb  vmovaps [rsp+0x80], xmm9
000073dfa87e0ad4  vmovaps [rsp+0x90], xmm10
000073dfa87e0add  vmovaps [rsp+0xA0], xmm11
000073dfa87e0ae6  vmovaps [rsp+0xB0], xmm12
000073dfa87e0aef  vmovaps [rsp+0xC0], xmm13
000073dfa87e0af8  vmovaps [rsp+0xD0], xmm14
000073dfa87e0b01  vmovaps [rsp+0xE0], xmm15
000073dfa87e0b0a  sub rsp, 0x30
000073dfa87e0b0e  movaps [rsp], xmm7
000073dfa87e0b12  movaps [rsp+0x10], xmm4
000073dfa87e0b17  movaps [rsp+0x20], xmm9
000073dfa87e0b1d  lea rdi, [rsp]
000073dfa87e0b21  mov esi, 0x00
000073dfa87e0b26  mov rax, 0x593AA1DA4530
000073dfa87e0b30  call rax
000073dfa87e0b32  movaps xmm7, [rsp]
000073dfa87e0b36  add rsp, 0x30
000073dfa87e0b3a  vmovaps xmm0, [rsp]
000073dfa87e0b3f  vmovaps xmm1, [rsp+0x10]
000073dfa87e0b45  vmovaps xmm2, [rsp+0x20]
000073dfa87e0b4b  vmovaps xmm3, [rsp+0x30]
000073dfa87e0b51  vmovaps xmm4, [rsp+0x40]
000073dfa87e0b57  vmovaps xmm5, [rsp+0x50]
000073dfa87e0b5d  vmovaps xmm6, [rsp+0x60]
000073dfa87e0b63  vmovaps xmm8, [rsp+0x70]
000073dfa87e0b69  vmovaps xmm9, [rsp+0x80]
000073dfa87e0b72  vmovaps xmm10, [rsp+0x90]
000073dfa87e0b7b  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0b84  vmovaps xmm12, [rsp+0xB0]
000073dfa87e0b8d  vmovaps xmm13, [rsp+0xC0]
000073dfa87e0b96  vmovaps xmm14, [rsp+0xD0]
000073dfa87e0b9f  vmovaps xmm15, [rsp+0xE0]
000073dfa87e0ba8  add rsp, 0xF0
000073dfa87e0baf  pop r11
000073dfa87e0bb1  pop r10
000073dfa87e0bb3  pop r9
000073dfa87e0bb5  pop r8
000073dfa87e0bb7  pop rsi
000073dfa87e0bb8  pop rdi
000073dfa87e0bb9  pop rdx
000073dfa87e0bba  pop rcx
000073dfa87e0bbb  pop rax
000073dfa87e0bbc  add rsp, 0x08
000073dfa87e0bc0  jmp 0x000073DFA87DF067
000073dfa87e0bc5  sub rsp, 0x08
000073dfa87e0bc9  push rax
000073dfa87e0bca  push rcx
000073dfa87e0bcb  push rdx
000073dfa87e0bcc  push rdi
000073dfa87e0bcd  push rsi
000073dfa87e0bce  push r8
000073dfa87e0bd0  push r9
000073dfa87e0bd2  push r10
000073dfa87e0bd4  push r11
000073dfa87e0bd6  sub rsp, 0xF0
000073dfa87e0bdd  vmovaps [rsp], xmm0
000073dfa87e0be2  vmovaps [rsp+0x10], xmm1
000073dfa87e0be8  vmovaps [rsp+0x20], xmm2
000073dfa87e0bee  vmovaps [rsp+0x30], xmm3
000073dfa87e0bf4  vmovaps [rsp+0x40], xmm5
000073dfa87e0bfa  vmovaps [rsp+0x50], xmm6
000073dfa87e0c00  vmovaps [rsp+0x60], xmm7
000073dfa87e0c06  vmovaps [rsp+0x70], xmm8
000073dfa87e0c0c  vmovaps [rsp+0x80], xmm9
000073dfa87e0c15  vmovaps [rsp+0x90], xmm10
000073dfa87e0c1e  vmovaps [rsp+0xA0], xmm11
000073dfa87e0c27  vmovaps [rsp+0xB0], xmm12
000073dfa87e0c30  vmovaps [rsp+0xC0], xmm13
000073dfa87e0c39  vmovaps [rsp+0xD0], xmm14
000073dfa87e0c42  vmovaps [rsp+0xE0], xmm15
000073dfa87e0c4b  sub rsp, 0x30
000073dfa87e0c4f  movaps [rsp], xmm4
000073dfa87e0c53  movaps [rsp+0x10], xmm15
000073dfa87e0c59  movaps [rsp+0x20], xmm9
000073dfa87e0c5f  lea rdi, [rsp]
000073dfa87e0c63  mov esi, 0x00
000073dfa87e0c68  mov rax, 0x593AA1DA4530
000073dfa87e0c72  call rax
000073dfa87e0c74  movaps xmm4, [rsp]
000073dfa87e0c78  add rsp, 0x30
000073dfa87e0c7c  vmovaps xmm0, [rsp]
000073dfa87e0c81  vmovaps xmm1, [rsp+0x10]
000073dfa87e0c87  vmovaps xmm2, [rsp+0x20]
000073dfa87e0c8d  vmovaps xmm3, [rsp+0x30]
000073dfa87e0c93  vmovaps xmm5, [rsp+0x40]
000073dfa87e0c99  vmovaps xmm6, [rsp+0x50]
000073dfa87e0c9f  vmovaps xmm7, [rsp+0x60]
000073dfa87e0ca5  vmovaps xmm8, [rsp+0x70]
000073dfa87e0cab  vmovaps xmm9, [rsp+0x80]
000073dfa87e0cb4  vmovaps xmm10, [rsp+0x90]
000073dfa87e0cbd  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0cc6  vmovaps xmm12, [rsp+0xB0]
000073dfa87e0ccf  vmovaps xmm13, [rsp+0xC0]
000073dfa87e0cd8  vmovaps xmm14, [rsp+0xD0]
000073dfa87e0ce1  vmovaps xmm15, [rsp+0xE0]
000073dfa87e0cea  add rsp, 0xF0
000073dfa87e0cf1  pop r11
000073dfa87e0cf3  pop r10
000073dfa87e0cf5  pop r9
000073dfa87e0cf7  pop r8
000073dfa87e0cf9  pop rsi
000073dfa87e0cfa  pop rdi
000073dfa87e0cfb  pop rdx
000073dfa87e0cfc  pop rcx
000073dfa87e0cfd  pop rax
000073dfa87e0cfe  add rsp, 0x08
000073dfa87e0d02  jmp 0x000073DFA87DF08C
000073dfa87e0d07  call 0x000073DFA86C4620
000073dfa87e0d0c  jmp 0x000073DFA87DF099
000073dfa87e0d11  sub rsp, 0x08
000073dfa87e0d15  push rax
000073dfa87e0d16  push rcx
000073dfa87e0d17  push rdx
000073dfa87e0d18  push rdi
000073dfa87e0d19  push rsi
000073dfa87e0d1a  push r8
000073dfa87e0d1c  push r9
000073dfa87e0d1e  push r10
000073dfa87e0d20  push r11
000073dfa87e0d22  sub rsp, 0xF0
000073dfa87e0d29  vmovaps [rsp], xmm0
000073dfa87e0d2e  vmovaps [rsp+0x10], xmm1
000073dfa87e0d34  vmovaps [rsp+0x20], xmm2
000073dfa87e0d3a  vmovaps [rsp+0x30], xmm4
000073dfa87e0d40  vmovaps [rsp+0x40], xmm5
000073dfa87e0d46  vmovaps [rsp+0x50], xmm6
000073dfa87e0d4c  vmovaps [rsp+0x60], xmm7
000073dfa87e0d52  vmovaps [rsp+0x70], xmm8
000073dfa87e0d58  vmovaps [rsp+0x80], xmm9
000073dfa87e0d61  vmovaps [rsp+0x90], xmm10
000073dfa87e0d6a  vmovaps [rsp+0xA0], xmm11
000073dfa87e0d73  vmovaps [rsp+0xB0], xmm12
000073dfa87e0d7c  vmovaps [rsp+0xC0], xmm13
000073dfa87e0d85  vmovaps [rsp+0xD0], xmm14
000073dfa87e0d8e  vmovaps [rsp+0xE0], xmm15
000073dfa87e0d97  sub rsp, 0x30
000073dfa87e0d9b  movaps [rsp], xmm3
000073dfa87e0d9f  movaps [rsp+0x10], xmm1
000073dfa87e0da4  movaps [rsp+0x20], xmm9
000073dfa87e0daa  lea rdi, [rsp]
000073dfa87e0dae  mov esi, 0x00
000073dfa87e0db3  mov rax, 0x593AA1DA4530
000073dfa87e0dbd  call rax
000073dfa87e0dbf  movaps xmm3, [rsp]
000073dfa87e0dc3  add rsp, 0x30
000073dfa87e0dc7  vmovaps xmm0, [rsp]
000073dfa87e0dcc  vmovaps xmm1, [rsp+0x10]
000073dfa87e0dd2  vmovaps xmm2, [rsp+0x20]
000073dfa87e0dd8  vmovaps xmm4, [rsp+0x30]
000073dfa87e0dde  vmovaps xmm5, [rsp+0x40]
000073dfa87e0de4  vmovaps xmm6, [rsp+0x50]
000073dfa87e0dea  vmovaps xmm7, [rsp+0x60]
000073dfa87e0df0  vmovaps xmm8, [rsp+0x70]
000073dfa87e0df6  vmovaps xmm9, [rsp+0x80]
000073dfa87e0dff  vmovaps xmm10, [rsp+0x90]
000073dfa87e0e08  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0e11  vmovaps xmm12, [rsp+0xB0]
000073dfa87e0e1a  vmovaps xmm13, [rsp+0xC0]
000073dfa87e0e23  vmovaps xmm14, [rsp+0xD0]
000073dfa87e0e2c  vmovaps xmm15, [rsp+0xE0]
000073dfa87e0e35  add rsp, 0xF0
000073dfa87e0e3c  pop r11
000073dfa87e0e3e  pop r10
000073dfa87e0e40  pop r9
000073dfa87e0e42  pop r8
000073dfa87e0e44  pop rsi
000073dfa87e0e45  pop rdi
000073dfa87e0e46  pop rdx
000073dfa87e0e47  pop rcx
000073dfa87e0e48  pop rax
000073dfa87e0e49  add rsp, 0x08
000073dfa87e0e4d  jmp 0x000073DFA87DF0D6
000073dfa87e0e52  sub rsp, 0x08
000073dfa87e0e56  push rax
000073dfa87e0e57  push rcx
000073dfa87e0e58  push rdx
000073dfa87e0e59  push rdi
000073dfa87e0e5a  push rsi
000073dfa87e0e5b  push r8
000073dfa87e0e5d  push r9
000073dfa87e0e5f  push r10
000073dfa87e0e61  push r11
000073dfa87e0e63  sub rsp, 0xF0
000073dfa87e0e6a  vmovaps [rsp], xmm0
000073dfa87e0e6f  vmovaps [rsp+0x10], xmm2
000073dfa87e0e75  vmovaps [rsp+0x20], xmm3
000073dfa87e0e7b  vmovaps [rsp+0x30], xmm4
000073dfa87e0e81  vmovaps [rsp+0x40], xmm5
000073dfa87e0e87  vmovaps [rsp+0x50], xmm6
000073dfa87e0e8d  vmovaps [rsp+0x60], xmm7
000073dfa87e0e93  vmovaps [rsp+0x70], xmm8
000073dfa87e0e99  vmovaps [rsp+0x80], xmm9
000073dfa87e0ea2  vmovaps [rsp+0x90], xmm10
000073dfa87e0eab  vmovaps [rsp+0xA0], xmm11
000073dfa87e0eb4  vmovaps [rsp+0xB0], xmm12
000073dfa87e0ebd  vmovaps [rsp+0xC0], xmm13
000073dfa87e0ec6  vmovaps [rsp+0xD0], xmm14
000073dfa87e0ecf  vmovaps [rsp+0xE0], xmm15
000073dfa87e0ed8  sub rsp, 0x30
000073dfa87e0edc  movaps [rsp], xmm1
000073dfa87e0ee0  movaps [rsp+0x10], xmm15
000073dfa87e0ee6  movaps [rsp+0x20], xmm9
000073dfa87e0eec  lea rdi, [rsp]
000073dfa87e0ef0  mov esi, 0x00
000073dfa87e0ef5  mov rax, 0x593AA1DA4530
000073dfa87e0eff  call rax
000073dfa87e0f01  movaps xmm1, [rsp]
000073dfa87e0f05  add rsp, 0x30
000073dfa87e0f09  vmovaps xmm0, [rsp]
000073dfa87e0f0e  vmovaps xmm2, [rsp+0x10]
000073dfa87e0f14  vmovaps xmm3, [rsp+0x20]
000073dfa87e0f1a  vmovaps xmm4, [rsp+0x30]
000073dfa87e0f20  vmovaps xmm5, [rsp+0x40]
000073dfa87e0f26  vmovaps xmm6, [rsp+0x50]
000073dfa87e0f2c  vmovaps xmm7, [rsp+0x60]
000073dfa87e0f32  vmovaps xmm8, [rsp+0x70]
000073dfa87e0f38  vmovaps xmm9, [rsp+0x80]
000073dfa87e0f41  vmovaps xmm10, [rsp+0x90]
000073dfa87e0f4a  vmovaps xmm11, [rsp+0xA0]
000073dfa87e0f53  vmovaps xmm12, [rsp+0xB0]
000073dfa87e0f5c  vmovaps xmm13, [rsp+0xC0]
000073dfa87e0f65  vmovaps xmm14, [rsp+0xD0]
000073dfa87e0f6e  vmovaps xmm15, [rsp+0xE0]
000073dfa87e0f77  add rsp, 0xF0
000073dfa87e0f7e  pop r11
000073dfa87e0f80  pop r10
000073dfa87e0f82  pop r9
000073dfa87e0f84  pop r8
000073dfa87e0f86  pop rsi
000073dfa87e0f87  pop rdi
000073dfa87e0f88  pop rdx
000073dfa87e0f89  pop rcx
000073dfa87e0f8a  pop rax
000073dfa87e0f8b  add rsp, 0x08
000073dfa87e0f8f  jmp 0x000073DFA87DF15E
000073dfa87e0f94  call 0x000073DFA86C4620
000073dfa87e0f99  jmp 0x000073DFA87DF16B
000073dfa87e0f9e  sub rsp, 0x08
000073dfa87e0fa2  push rax
000073dfa87e0fa3  push rcx
000073dfa87e0fa4  push rdx
000073dfa87e0fa5  push rdi
000073dfa87e0fa6  push rsi
000073dfa87e0fa7  push r8
000073dfa87e0fa9  push r9
000073dfa87e0fab  push r10
000073dfa87e0fad  push r11
000073dfa87e0faf  sub rsp, 0xF0
000073dfa87e0fb6  vmovaps [rsp], xmm0
000073dfa87e0fbb  vmovaps [rsp+0x10], xmm2
000073dfa87e0fc1  vmovaps [rsp+0x20], xmm3
000073dfa87e0fc7  vmovaps [rsp+0x30], xmm4
000073dfa87e0fcd  vmovaps [rsp+0x40], xmm5
000073dfa87e0fd3  vmovaps [rsp+0x50], xmm6
000073dfa87e0fd9  vmovaps [rsp+0x60], xmm7
000073dfa87e0fdf  vmovaps [rsp+0x70], xmm8
000073dfa87e0fe5  vmovaps [rsp+0x80], xmm9
000073dfa87e0fee  vmovaps [rsp+0x90], xmm10
000073dfa87e0ff7  vmovaps [rsp+0xA0], xmm11
000073dfa87e1000  vmovaps [rsp+0xB0], xmm12
000073dfa87e1009  vmovaps [rsp+0xC0], xmm13
000073dfa87e1012  vmovaps [rsp+0xD0], xmm14
000073dfa87e101b  vmovaps [rsp+0xE0], xmm15
000073dfa87e1024  sub rsp, 0x30
000073dfa87e1028  movaps [rsp], xmm1
000073dfa87e102c  movaps [rsp+0x10], xmm5
000073dfa87e1031  movaps [rsp+0x20], xmm7
000073dfa87e1036  lea rdi, [rsp]
000073dfa87e103a  mov esi, 0x00
000073dfa87e103f  mov rax, 0x593AA1DA4530
000073dfa87e1049  call rax
000073dfa87e104b  movaps xmm1, [rsp]
000073dfa87e104f  add rsp, 0x30
000073dfa87e1053  vmovaps xmm0, [rsp]
000073dfa87e1058  vmovaps xmm2, [rsp+0x10]
000073dfa87e105e  vmovaps xmm3, [rsp+0x20]
000073dfa87e1064  vmovaps xmm4, [rsp+0x30]
000073dfa87e106a  vmovaps xmm5, [rsp+0x40]
000073dfa87e1070  vmovaps xmm6, [rsp+0x50]
000073dfa87e1076  vmovaps xmm7, [rsp+0x60]
000073dfa87e107c  vmovaps xmm8, [rsp+0x70]
000073dfa87e1082  vmovaps xmm9, [rsp+0x80]
000073dfa87e108b  vmovaps xmm10, [rsp+0x90]
000073dfa87e1094  vmovaps xmm11, [rsp+0xA0]
000073dfa87e109d  vmovaps xmm12, [rsp+0xB0]
000073dfa87e10a6  vmovaps xmm13, [rsp+0xC0]
000073dfa87e10af  vmovaps xmm14, [rsp+0xD0]
000073dfa87e10b8  vmovaps xmm15, [rsp+0xE0]
000073dfa87e10c1  add rsp, 0xF0
000073dfa87e10c8  pop r11
000073dfa87e10ca  pop r10
000073dfa87e10cc  pop r9
000073dfa87e10ce  pop r8
000073dfa87e10d0  pop rsi
000073dfa87e10d1  pop rdi
000073dfa87e10d2  pop rdx
000073dfa87e10d3  pop rcx
000073dfa87e10d4  pop rax
000073dfa87e10d5  add rsp, 0x08
000073dfa87e10d9  jmp 0x000073DFA87DF210
000073dfa87e10de  sub rsp, 0x08
000073dfa87e10e2  push rax
000073dfa87e10e3  push rcx
000073dfa87e10e4  push rdx
000073dfa87e10e5  push rdi
000073dfa87e10e6  push rsi
000073dfa87e10e7  push r8
000073dfa87e10e9  push r9
000073dfa87e10eb  push r10
000073dfa87e10ed  push r11
000073dfa87e10ef  sub rsp, 0xF0
000073dfa87e10f6  vmovaps [rsp], xmm0
000073dfa87e10fb  vmovaps [rsp+0x10], xmm1
000073dfa87e1101  vmovaps [rsp+0x20], xmm2
000073dfa87e1107  vmovaps [rsp+0x30], xmm3
000073dfa87e110d  vmovaps [rsp+0x40], xmm4
000073dfa87e1113  vmovaps [rsp+0x50], xmm5
000073dfa87e1119  vmovaps [rsp+0x60], xmm6
000073dfa87e111f  vmovaps [rsp+0x70], xmm8
000073dfa87e1125  vmovaps [rsp+0x80], xmm9
000073dfa87e112e  vmovaps [rsp+0x90], xmm10
000073dfa87e1137  vmovaps [rsp+0xA0], xmm11
000073dfa87e1140  vmovaps [rsp+0xB0], xmm12
000073dfa87e1149  vmovaps [rsp+0xC0], xmm13
000073dfa87e1152  vmovaps [rsp+0xD0], xmm14
000073dfa87e115b  vmovaps [rsp+0xE0], xmm15
000073dfa87e1164  sub rsp, 0x30
000073dfa87e1168  movaps [rsp], xmm7
000073dfa87e116c  movaps [rsp+0x10], xmm5
000073dfa87e1171  movaps [rsp+0x20], xmm15
000073dfa87e1177  lea rdi, [rsp]
000073dfa87e117b  mov esi, 0x00
000073dfa87e1180  mov rax, 0x593AA1DA4530
000073dfa87e118a  call rax
000073dfa87e118c  movaps xmm7, [rsp]
000073dfa87e1190  add rsp, 0x30
000073dfa87e1194  vmovaps xmm0, [rsp]
000073dfa87e1199  vmovaps xmm1, [rsp+0x10]
000073dfa87e119f  vmovaps xmm2, [rsp+0x20]
000073dfa87e11a5  vmovaps xmm3, [rsp+0x30]
000073dfa87e11ab  vmovaps xmm4, [rsp+0x40]
000073dfa87e11b1  vmovaps xmm5, [rsp+0x50]
000073dfa87e11b7  vmovaps xmm6, [rsp+0x60]
000073dfa87e11bd  vmovaps xmm8, [rsp+0x70]
000073dfa87e11c3  vmovaps xmm9, [rsp+0x80]
000073dfa87e11cc  vmovaps xmm10, [rsp+0x90]
000073dfa87e11d5  vmovaps xmm11, [rsp+0xA0]
000073dfa87e11de  vmovaps xmm12, [rsp+0xB0]
000073dfa87e11e7  vmovaps xmm13, [rsp+0xC0]
000073dfa87e11f0  vmovaps xmm14, [rsp+0xD0]
000073dfa87e11f9  vmovaps xmm15, [rsp+0xE0]
000073dfa87e1202  add rsp, 0xF0
000073dfa87e1209  pop r11
000073dfa87e120b  pop r10
000073dfa87e120d  pop r9
000073dfa87e120f  pop r8
000073dfa87e1211  pop rsi
000073dfa87e1212  pop rdi
000073dfa87e1213  pop rdx
000073dfa87e1214  pop rcx
000073dfa87e1215  pop rax
000073dfa87e1216  add rsp, 0x08
000073dfa87e121a  jmp 0x000073DFA87DF246
000073dfa87e121f  call 0x000073DFA86B52F0
000073dfa87e1224  jmp 0x000073DFA87DF253
000073dfa87e1229  sub rsp, 0x08
000073dfa87e122d  push rax
000073dfa87e122e  push rcx
000073dfa87e122f  push rdx
000073dfa87e1230  push rdi
000073dfa87e1231  push rsi
000073dfa87e1232  push r8
000073dfa87e1234  push r9
000073dfa87e1236  push r10
000073dfa87e1238  push r11
000073dfa87e123a  sub rsp, 0xF0
000073dfa87e1241  vmovaps [rsp], xmm0
000073dfa87e1246  vmovaps [rsp+0x10], xmm1
000073dfa87e124c  vmovaps [rsp+0x20], xmm2
000073dfa87e1252  vmovaps [rsp+0x30], xmm3
000073dfa87e1258  vmovaps [rsp+0x40], xmm4
000073dfa87e125e  vmovaps [rsp+0x50], xmm5
000073dfa87e1264  vmovaps [rsp+0x60], xmm6
000073dfa87e126a  vmovaps [rsp+0x70], xmm7
000073dfa87e1270  vmovaps [rsp+0x80], xmm8
000073dfa87e1279  vmovaps [rsp+0x90], xmm9
000073dfa87e1282  vmovaps [rsp+0xA0], xmm10
000073dfa87e128b  vmovaps [rsp+0xB0], xmm11
000073dfa87e1294  vmovaps [rsp+0xC0], xmm12
000073dfa87e129d  vmovaps [rsp+0xD0], xmm13
000073dfa87e12a6  vmovaps [rsp+0xE0], xmm14
000073dfa87e12af  sub rsp, 0x30
000073dfa87e12b3  movaps [rsp], xmm15
000073dfa87e12b8  movaps [rsp+0x10], xmm5
000073dfa87e12bd  movaps [rsp+0x20], xmm3
000073dfa87e12c2  lea rdi, [rsp]
000073dfa87e12c6  mov esi, 0x00
000073dfa87e12cb  mov rax, 0x593AA1DA4530
000073dfa87e12d5  call rax
000073dfa87e12d7  movaps xmm15, [rsp]
000073dfa87e12dc  add rsp, 0x30
000073dfa87e12e0  vmovaps xmm0, [rsp]
000073dfa87e12e5  vmovaps xmm1, [rsp+0x10]
000073dfa87e12eb  vmovaps xmm2, [rsp+0x20]
000073dfa87e12f1  vmovaps xmm3, [rsp+0x30]
000073dfa87e12f7  vmovaps xmm4, [rsp+0x40]
000073dfa87e12fd  vmovaps xmm5, [rsp+0x50]
000073dfa87e1303  vmovaps xmm6, [rsp+0x60]
000073dfa87e1309  vmovaps xmm7, [rsp+0x70]
000073dfa87e130f  vmovaps xmm8, [rsp+0x80]
000073dfa87e1318  vmovaps xmm9, [rsp+0x90]
000073dfa87e1321  vmovaps xmm10, [rsp+0xA0]
000073dfa87e132a  vmovaps xmm11, [rsp+0xB0]
000073dfa87e1333  vmovaps xmm12, [rsp+0xC0]
000073dfa87e133c  vmovaps xmm13, [rsp+0xD0]
000073dfa87e1345  vmovaps xmm14, [rsp+0xE0]
000073dfa87e134e  add rsp, 0xF0
000073dfa87e1355  pop r11
000073dfa87e1357  pop r10
000073dfa87e1359  pop r9
000073dfa87e135b  pop r8
000073dfa87e135d  pop rsi
000073dfa87e135e  pop rdi
000073dfa87e135f  pop rdx
000073dfa87e1360  pop rcx
000073dfa87e1361  pop rax
000073dfa87e1362  add rsp, 0x08
000073dfa87e1366  jmp 0x000073DFA87DF279
000073dfa87e136b  sub rsp, 0x08
000073dfa87e136f  push rax
000073dfa87e1370  push rcx
000073dfa87e1371  push rdx
000073dfa87e1372  push rdi
000073dfa87e1373  push rsi
000073dfa87e1374  push r8
000073dfa87e1376  push r9
000073dfa87e1378  push r10
000073dfa87e137a  push r11
000073dfa87e137c  sub rsp, 0xF0
000073dfa87e1383  vmovaps [rsp], xmm0
000073dfa87e1388  vmovaps [rsp+0x10], xmm2
000073dfa87e138e  vmovaps [rsp+0x20], xmm3
000073dfa87e1394  vmovaps [rsp+0x30], xmm4
000073dfa87e139a  vmovaps [rsp+0x40], xmm5
000073dfa87e13a0  vmovaps [rsp+0x50], xmm6
000073dfa87e13a6  vmovaps [rsp+0x60], xmm7
000073dfa87e13ac  vmovaps [rsp+0x70], xmm8
000073dfa87e13b2  vmovaps [rsp+0x80], xmm9
000073dfa87e13bb  vmovaps [rsp+0x90], xmm10
000073dfa87e13c4  vmovaps [rsp+0xA0], xmm11
000073dfa87e13cd  vmovaps [rsp+0xB0], xmm12
000073dfa87e13d6  vmovaps [rsp+0xC0], xmm13
000073dfa87e13df  vmovaps [rsp+0xD0], xmm14
000073dfa87e13e8  vmovaps [rsp+0xE0], xmm15
000073dfa87e13f1  sub rsp, 0x30
000073dfa87e13f5  movaps [rsp], xmm1
000073dfa87e13f9  movaps [rsp+0x10], xmm5
000073dfa87e13fe  movaps [rsp+0x20], xmm4
000073dfa87e1403  lea rdi, [rsp]
000073dfa87e1407  mov esi, 0x00
000073dfa87e140c  mov rax, 0x593AA1DA4530
000073dfa87e1416  call rax
000073dfa87e1418  movaps xmm1, [rsp]
000073dfa87e141c  add rsp, 0x30
000073dfa87e1420  vmovaps xmm0, [rsp]
000073dfa87e1425  vmovaps xmm2, [rsp+0x10]
000073dfa87e142b  vmovaps xmm3, [rsp+0x20]
000073dfa87e1431  vmovaps xmm4, [rsp+0x30]
000073dfa87e1437  vmovaps xmm5, [rsp+0x40]
000073dfa87e143d  vmovaps xmm6, [rsp+0x50]
000073dfa87e1443  vmovaps xmm7, [rsp+0x60]
000073dfa87e1449  vmovaps xmm8, [rsp+0x70]
000073dfa87e144f  vmovaps xmm9, [rsp+0x80]
000073dfa87e1458  vmovaps xmm10, [rsp+0x90]
000073dfa87e1461  vmovaps xmm11, [rsp+0xA0]
000073dfa87e146a  vmovaps xmm12, [rsp+0xB0]
000073dfa87e1473  vmovaps xmm13, [rsp+0xC0]
000073dfa87e147c  vmovaps xmm14, [rsp+0xD0]
000073dfa87e1485  vmovaps xmm15, [rsp+0xE0]
000073dfa87e148e  add rsp, 0xF0
000073dfa87e1495  pop r11
000073dfa87e1497  pop r10
000073dfa87e1499  pop r9
000073dfa87e149b  pop r8
000073dfa87e149d  pop rsi
000073dfa87e149e  pop rdi
000073dfa87e149f  pop rdx
000073dfa87e14a0  pop rcx
000073dfa87e14a1  pop rax
000073dfa87e14a2  add rsp, 0x08
000073dfa87e14a6  jmp 0x000073DFA87DF299
000073dfa87e14ab  sub rsp, 0x08
000073dfa87e14af  push rax
000073dfa87e14b0  push rcx
000073dfa87e14b1  push rdx
000073dfa87e14b2  push rdi
000073dfa87e14b3  push rsi
000073dfa87e14b4  push r8
000073dfa87e14b6  push r9
000073dfa87e14b8  push r10
000073dfa87e14ba  push r11
000073dfa87e14bc  sub rsp, 0xF0
000073dfa87e14c3  vmovaps [rsp], xmm0
000073dfa87e14c8  vmovaps [rsp+0x10], xmm1
000073dfa87e14ce  vmovaps [rsp+0x20], xmm2
000073dfa87e14d4  vmovaps [rsp+0x30], xmm3
000073dfa87e14da  vmovaps [rsp+0x40], xmm5
000073dfa87e14e0  vmovaps [rsp+0x50], xmm6
000073dfa87e14e6  vmovaps [rsp+0x60], xmm7
000073dfa87e14ec  vmovaps [rsp+0x70], xmm8
000073dfa87e14f2  vmovaps [rsp+0x80], xmm9
000073dfa87e14fb  vmovaps [rsp+0x90], xmm10
000073dfa87e1504  vmovaps [rsp+0xA0], xmm11
000073dfa87e150d  vmovaps [rsp+0xB0], xmm12
000073dfa87e1516  vmovaps [rsp+0xC0], xmm13
000073dfa87e151f  vmovaps [rsp+0xD0], xmm14
000073dfa87e1528  vmovaps [rsp+0xE0], xmm15
000073dfa87e1531  sub rsp, 0x30
000073dfa87e1535  movaps [rsp], xmm4
000073dfa87e1539  movaps [rsp+0x10], xmm3
000073dfa87e153e  movaps [rsp+0x20], xmm5
000073dfa87e1543  lea rdi, [rsp]
000073dfa87e1547  mov esi, 0x00
000073dfa87e154c  mov rax, 0x593AA1DA4530
000073dfa87e1556  call rax
000073dfa87e1558  movaps xmm4, [rsp]
000073dfa87e155c  add rsp, 0x30
000073dfa87e1560  vmovaps xmm0, [rsp]
000073dfa87e1565  vmovaps xmm1, [rsp+0x10]
000073dfa87e156b  vmovaps xmm2, [rsp+0x20]
000073dfa87e1571  vmovaps xmm3, [rsp+0x30]
000073dfa87e1577  vmovaps xmm5, [rsp+0x40]
000073dfa87e157d  vmovaps xmm6, [rsp+0x50]
000073dfa87e1583  vmovaps xmm7, [rsp+0x60]
000073dfa87e1589  vmovaps xmm8, [rsp+0x70]
000073dfa87e158f  vmovaps xmm9, [rsp+0x80]
000073dfa87e1598  vmovaps xmm10, [rsp+0x90]
000073dfa87e15a1  vmovaps xmm11, [rsp+0xA0]
000073dfa87e15aa  vmovaps xmm12, [rsp+0xB0]
000073dfa87e15b3  vmovaps xmm13, [rsp+0xC0]
000073dfa87e15bc  vmovaps xmm14, [rsp+0xD0]
000073dfa87e15c5  vmovaps xmm15, [rsp+0xE0]
000073dfa87e15ce  add rsp, 0xF0
000073dfa87e15d5  pop r11
000073dfa87e15d7  pop r10
000073dfa87e15d9  pop r9
000073dfa87e15db  pop r8
000073dfa87e15dd  pop rsi
000073dfa87e15de  pop rdi
000073dfa87e15df  pop rdx
000073dfa87e15e0  pop rcx
000073dfa87e15e1  pop rax
000073dfa87e15e2  add rsp, 0x08
000073dfa87e15e6  jmp 0x000073DFA87DF2E7
000073dfa87e15eb  call 0x000073DFA86B52F0
000073dfa87e15f0  jmp 0x000073DFA87DF2F4
000073dfa87e15f5  sub rsp, 0x08
000073dfa87e15f9  push rax
000073dfa87e15fa  push rcx
000073dfa87e15fb  push rdx
000073dfa87e15fc  push rdi
000073dfa87e15fd  push rsi
000073dfa87e15fe  push r8
000073dfa87e1600  push r9
000073dfa87e1602  push r10
000073dfa87e1604  push r11
000073dfa87e1606  sub rsp, 0xF0
000073dfa87e160d  vmovaps [rsp], xmm0
000073dfa87e1612  vmovaps [rsp+0x10], xmm1
000073dfa87e1618  vmovaps [rsp+0x20], xmm2
000073dfa87e161e  vmovaps [rsp+0x30], xmm3
000073dfa87e1624  vmovaps [rsp+0x40], xmm4
000073dfa87e162a  vmovaps [rsp+0x50], xmm6
000073dfa87e1630  vmovaps [rsp+0x60], xmm7
000073dfa87e1636  vmovaps [rsp+0x70], xmm8
000073dfa87e163c  vmovaps [rsp+0x80], xmm9
000073dfa87e1645  vmovaps [rsp+0x90], xmm10
000073dfa87e164e  vmovaps [rsp+0xA0], xmm11
000073dfa87e1657  vmovaps [rsp+0xB0], xmm12
000073dfa87e1660  vmovaps [rsp+0xC0], xmm13
000073dfa87e1669  vmovaps [rsp+0xD0], xmm14
000073dfa87e1672  vmovaps [rsp+0xE0], xmm15
000073dfa87e167b  sub rsp, 0x30
000073dfa87e167f  movaps [rsp], xmm5
000073dfa87e1683  movaps [rsp+0x10], xmm6
000073dfa87e1688  movaps [rsp+0x20], xmm3
000073dfa87e168d  lea rdi, [rsp]
000073dfa87e1691  mov esi, 0x00
000073dfa87e1696  mov rax, 0x593AA1DA4530
000073dfa87e16a0  call rax
000073dfa87e16a2  movaps xmm5, [rsp]
000073dfa87e16a6  add rsp, 0x30
000073dfa87e16aa  vmovaps xmm0, [rsp]
000073dfa87e16af  vmovaps xmm1, [rsp+0x10]
000073dfa87e16b5  vmovaps xmm2, [rsp+0x20]
000073dfa87e16bb  vmovaps xmm3, [rsp+0x30]
000073dfa87e16c1  vmovaps xmm4, [rsp+0x40]
000073dfa87e16c7  vmovaps xmm6, [rsp+0x50]
000073dfa87e16cd  vmovaps xmm7, [rsp+0x60]
000073dfa87e16d3  vmovaps xmm8, [rsp+0x70]
000073dfa87e16d9  vmovaps xmm9, [rsp+0x80]
000073dfa87e16e2  vmovaps xmm10, [rsp+0x90]
000073dfa87e16eb  vmovaps xmm11, [rsp+0xA0]
000073dfa87e16f4  vmovaps xmm12, [rsp+0xB0]
000073dfa87e16fd  vmovaps xmm13, [rsp+0xC0]
000073dfa87e1706  vmovaps xmm14, [rsp+0xD0]
000073dfa87e170f  vmovaps xmm15, [rsp+0xE0]
000073dfa87e1718  add rsp, 0xF0
000073dfa87e171f  pop r11
000073dfa87e1721  pop r10
000073dfa87e1723  pop r9
000073dfa87e1725  pop r8
000073dfa87e1727  pop rsi
000073dfa87e1728  pop rdi
000073dfa87e1729  pop rdx
000073dfa87e172a  pop rcx
000073dfa87e172b  pop rax
000073dfa87e172c  add rsp, 0x08
000073dfa87e1730  jmp 0x000073DFA87DF31A
000073dfa87e1735  sub rsp, 0x08
000073dfa87e1739  push rax
000073dfa87e173a  push rcx
000073dfa87e173b  push rdx
000073dfa87e173c  push rdi
000073dfa87e173d  push rsi
000073dfa87e173e  push r8
000073dfa87e1740  push r9
000073dfa87e1742  push r10
000073dfa87e1744  push r11
000073dfa87e1746  sub rsp, 0xF0
000073dfa87e174d  vmovaps [rsp], xmm0
000073dfa87e1752  vmovaps [rsp+0x10], xmm1
000073dfa87e1758  vmovaps [rsp+0x20], xmm2
000073dfa87e175e  vmovaps [rsp+0x30], xmm3
000073dfa87e1764  vmovaps [rsp+0x40], xmm4
000073dfa87e176a  vmovaps [rsp+0x50], xmm5
000073dfa87e1770  vmovaps [rsp+0x60], xmm7
000073dfa87e1776  vmovaps [rsp+0x70], xmm8
000073dfa87e177c  vmovaps [rsp+0x80], xmm9
000073dfa87e1785  vmovaps [rsp+0x90], xmm10
000073dfa87e178e  vmovaps [rsp+0xA0], xmm11
000073dfa87e1797  vmovaps [rsp+0xB0], xmm12
000073dfa87e17a0  vmovaps [rsp+0xC0], xmm13
000073dfa87e17a9  vmovaps [rsp+0xD0], xmm14
000073dfa87e17b2  vmovaps [rsp+0xE0], xmm15
000073dfa87e17bb  sub rsp, 0x30
000073dfa87e17bf  movaps [rsp], xmm6
000073dfa87e17c3  movaps [rsp+0x10], xmm9
000073dfa87e17c9  movaps [rsp+0x20], xmm1
000073dfa87e17ce  lea rdi, [rsp]
000073dfa87e17d2  mov esi, 0x00
000073dfa87e17d7  mov rax, 0x593AA1DA4530
000073dfa87e17e1  call rax
000073dfa87e17e3  movaps xmm6, [rsp]
000073dfa87e17e7  add rsp, 0x30
000073dfa87e17eb  vmovaps xmm0, [rsp]
000073dfa87e17f0  vmovaps xmm1, [rsp+0x10]
000073dfa87e17f6  vmovaps xmm2, [rsp+0x20]
000073dfa87e17fc  vmovaps xmm3, [rsp+0x30]
000073dfa87e1802  vmovaps xmm4, [rsp+0x40]
000073dfa87e1808  vmovaps xmm5, [rsp+0x50]
000073dfa87e180e  vmovaps xmm7, [rsp+0x60]
000073dfa87e1814  vmovaps xmm8, [rsp+0x70]
000073dfa87e181a  vmovaps xmm9, [rsp+0x80]
000073dfa87e1823  vmovaps xmm10, [rsp+0x90]
000073dfa87e182c  vmovaps xmm11, [rsp+0xA0]
000073dfa87e1835  vmovaps xmm12, [rsp+0xB0]
000073dfa87e183e  vmovaps xmm13, [rsp+0xC0]
000073dfa87e1847  vmovaps xmm14, [rsp+0xD0]
000073dfa87e1850  vmovaps xmm15, [rsp+0xE0]
000073dfa87e1859  add rsp, 0xF0
000073dfa87e1860  pop r11
000073dfa87e1862  pop r10
000073dfa87e1864  pop r9
000073dfa87e1866  pop r8
000073dfa87e1868  pop rsi
000073dfa87e1869  pop rdi
000073dfa87e186a  pop rdx
000073dfa87e186b  pop rcx
000073dfa87e186c  pop rax
000073dfa87e186d  add rsp, 0x08
000073dfa87e1871  jmp 0x000073DFA87DF33E
000073dfa87e1876  sub rsp, 0x08
000073dfa87e187a  push rax
000073dfa87e187b  push rcx
000073dfa87e187c  push rdx
000073dfa87e187d  push rdi
000073dfa87e187e  push rsi
000073dfa87e187f  push r8
000073dfa87e1881  push r9
000073dfa87e1883  push r10
000073dfa87e1885  push r11
000073dfa87e1887  sub rsp, 0xF0
000073dfa87e188e  vmovaps [rsp], xmm0
000073dfa87e1893  vmovaps [rsp+0x10], xmm1
000073dfa87e1899  vmovaps [rsp+0x20], xmm2
000073dfa87e189f  vmovaps [rsp+0x30], xmm3
000073dfa87e18a5  vmovaps [rsp+0x40], xmm4
000073dfa87e18ab  vmovaps [rsp+0x50], xmm5
000073dfa87e18b1  vmovaps [rsp+0x60], xmm6
000073dfa87e18b7  vmovaps [rsp+0x70], xmm7
000073dfa87e18bd  vmovaps [rsp+0x80], xmm8
000073dfa87e18c6  vmovaps [rsp+0x90], xmm10
000073dfa87e18cf  vmovaps [rsp+0xA0], xmm11
000073dfa87e18d8  vmovaps [rsp+0xB0], xmm12
000073dfa87e18e1  vmovaps [rsp+0xC0], xmm13
000073dfa87e18ea  vmovaps [rsp+0xD0], xmm14
000073dfa87e18f3  vmovaps [rsp+0xE0], xmm15
000073dfa87e18fc  sub rsp, 0x30
000073dfa87e1900  movaps [rsp], xmm9
000073dfa87e1905  movaps [rsp+0x10], xmm3
000073dfa87e190a  movaps [rsp+0x20], xmm1
000073dfa87e190f  lea rdi, [rsp]
000073dfa87e1913  mov esi, 0x00
000073dfa87e1918  mov rax, 0x593AA1DA4530
000073dfa87e1922  call rax
000073dfa87e1924  movaps xmm9, [rsp]
000073dfa87e1929  add rsp, 0x30
000073dfa87e192d  vmovaps xmm0, [rsp]
000073dfa87e1932  vmovaps xmm1, [rsp+0x10]
000073dfa87e1938  vmovaps xmm2, [rsp+0x20]
000073dfa87e193e  vmovaps xmm3, [rsp+0x30]
000073dfa87e1944  vmovaps xmm4, [rsp+0x40]
000073dfa87e194a  vmovaps xmm5, [rsp+0x50]
000073dfa87e1950  vmovaps xmm6, [rsp+0x60]
000073dfa87e1956  vmovaps xmm7, [rsp+0x70]
000073dfa87e195c  vmovaps xmm8, [rsp+0x80]
000073dfa87e1965  vmovaps xmm10, [rsp+0x90]
000073dfa87e196e  vmovaps xmm11, [rsp+0xA0]
000073dfa87e1977  vmovaps xmm12, [rsp+0xB0]
000073dfa87e1980  vmovaps xmm13, [rsp+0xC0]
000073dfa87e1989  vmovaps xmm14, [rsp+0xD0]
000073dfa87e1992  vmovaps xmm15, [rsp+0xE0]
000073dfa87e199b  add rsp, 0xF0
000073dfa87e19a2  pop r11
000073dfa87e19a4  pop r10
000073dfa87e19a6  pop r9
000073dfa87e19a8  pop r8
000073dfa87e19aa  pop rsi
000073dfa87e19ab  pop rdi
000073dfa87e19ac  pop rdx
000073dfa87e19ad  pop rcx
000073dfa87e19ae  pop rax
000073dfa87e19af  add rsp, 0x08
000073dfa87e19b3  jmp 0x000073DFA87DF38A
000073dfa87e19b8  call 0x000073DFA86B52F0
000073dfa87e19bd  jmp 0x000073DFA87DF397
000073dfa87e19c2  sub rsp, 0x08
000073dfa87e19c6  push rax
000073dfa87e19c7  push rcx
000073dfa87e19c8  push rdx
000073dfa87e19c9  push rdi
000073dfa87e19ca  push rsi
000073dfa87e19cb  push r8
000073dfa87e19cd  push r9
000073dfa87e19cf  push r10
000073dfa87e19d1  push r11
000073dfa87e19d3  sub rsp, 0xF0
000073dfa87e19da  vmovaps [rsp], xmm0
000073dfa87e19df  vmovaps [rsp+0x10], xmm1
000073dfa87e19e5  vmovaps [rsp+0x20], xmm2
000073dfa87e19eb  vmovaps [rsp+0x30], xmm3
000073dfa87e19f1  vmovaps [rsp+0x40], xmm4
000073dfa87e19f7  vmovaps [rsp+0x50], xmm5
000073dfa87e19fd  vmovaps [rsp+0x60], xmm6
000073dfa87e1a03  vmovaps [rsp+0x70], xmm7
000073dfa87e1a09  vmovaps [rsp+0x80], xmm8
000073dfa87e1a12  vmovaps [rsp+0x90], xmm9
000073dfa87e1a1b  vmovaps [rsp+0xA0], xmm10
000073dfa87e1a24  vmovaps [rsp+0xB0], xmm11
000073dfa87e1a2d  vmovaps [rsp+0xC0], xmm12
000073dfa87e1a36  vmovaps [rsp+0xD0], xmm13
000073dfa87e1a3f  vmovaps [rsp+0xE0], xmm14
000073dfa87e1a48  sub rsp, 0x30
000073dfa87e1a4c  movaps [rsp], xmm15
000073dfa87e1a51  movaps [rsp+0x10], xmm3
000073dfa87e1a56  movaps [rsp+0x20], xmm7
000073dfa87e1a5b  lea rdi, [rsp]
000073dfa87e1a5f  mov esi, 0x00
000073dfa87e1a64  mov rax, 0x593AA1DA4530
000073dfa87e1a6e  call rax
000073dfa87e1a70  movaps xmm15, [rsp]
000073dfa87e1a75  add rsp, 0x30
000073dfa87e1a79  vmovaps xmm0, [rsp]
000073dfa87e1a7e  vmovaps xmm1, [rsp+0x10]
000073dfa87e1a84  vmovaps xmm2, [rsp+0x20]
000073dfa87e1a8a  vmovaps xmm3, [rsp+0x30]
000073dfa87e1a90  vmovaps xmm4, [rsp+0x40]
000073dfa87e1a96  vmovaps xmm5, [rsp+0x50]
000073dfa87e1a9c  vmovaps xmm6, [rsp+0x60]
000073dfa87e1aa2  vmovaps xmm7, [rsp+0x70]
000073dfa87e1aa8  vmovaps xmm8, [rsp+0x80]
000073dfa87e1ab1  vmovaps xmm9, [rsp+0x90]
000073dfa87e1aba  vmovaps xmm10, [rsp+0xA0]
000073dfa87e1ac3  vmovaps xmm11, [rsp+0xB0]
000073dfa87e1acc  vmovaps xmm12, [rsp+0xC0]
000073dfa87e1ad5  vmovaps xmm13, [rsp+0xD0]
000073dfa87e1ade  vmovaps xmm14, [rsp+0xE0]
000073dfa87e1ae7  add rsp, 0xF0
000073dfa87e1aee  pop r11
000073dfa87e1af0  pop r10
000073dfa87e1af2  pop r9
000073dfa87e1af4  pop r8
000073dfa87e1af6  pop rsi
000073dfa87e1af7  pop rdi
000073dfa87e1af8  pop rdx
000073dfa87e1af9  pop rcx
000073dfa87e1afa  pop rax
000073dfa87e1afb  add rsp, 0x08
000073dfa87e1aff  jmp 0x000073DFA87DF3C3
000073dfa87e1b04  sub rsp, 0x08
000073dfa87e1b08  push rax
000073dfa87e1b09  push rcx
000073dfa87e1b0a  push rdx
000073dfa87e1b0b  push rdi
000073dfa87e1b0c  push rsi
000073dfa87e1b0d  push r8
000073dfa87e1b0f  push r9
000073dfa87e1b11  push r10
000073dfa87e1b13  push r11
000073dfa87e1b15  sub rsp, 0xF0
000073dfa87e1b1c  vmovaps [rsp], xmm0
000073dfa87e1b21  vmovaps [rsp+0x10], xmm1
000073dfa87e1b27  vmovaps [rsp+0x20], xmm2
000073dfa87e1b2d  vmovaps [rsp+0x30], xmm4
000073dfa87e1b33  vmovaps [rsp+0x40], xmm5
000073dfa87e1b39  vmovaps [rsp+0x50], xmm6
000073dfa87e1b3f  vmovaps [rsp+0x60], xmm7
000073dfa87e1b45  vmovaps [rsp+0x70], xmm8
000073dfa87e1b4b  vmovaps [rsp+0x80], xmm9
000073dfa87e1b54  vmovaps [rsp+0x90], xmm10
000073dfa87e1b5d  vmovaps [rsp+0xA0], xmm11
000073dfa87e1b66  vmovaps [rsp+0xB0], xmm12
000073dfa87e1b6f  vmovaps [rsp+0xC0], xmm13
000073dfa87e1b78  vmovaps [rsp+0xD0], xmm14
000073dfa87e1b81  vmovaps [rsp+0xE0], xmm15
000073dfa87e1b8a  sub rsp, 0x30
000073dfa87e1b8e  movaps [rsp], xmm3
000073dfa87e1b92  movaps [rsp+0x10], xmm1
000073dfa87e1b97  movaps [rsp+0x20], xmm15
000073dfa87e1b9d  lea rdi, [rsp]
000073dfa87e1ba1  mov esi, 0x00
000073dfa87e1ba6  mov rax, 0x593AA1DA4530
000073dfa87e1bb0  call rax
000073dfa87e1bb2  movaps xmm3, [rsp]
000073dfa87e1bb6  add rsp, 0x30
000073dfa87e1bba  vmovaps xmm0, [rsp]
000073dfa87e1bbf  vmovaps xmm1, [rsp+0x10]
000073dfa87e1bc5  vmovaps xmm2, [rsp+0x20]
000073dfa87e1bcb  vmovaps xmm4, [rsp+0x30]
000073dfa87e1bd1  vmovaps xmm5, [rsp+0x40]
000073dfa87e1bd7  vmovaps xmm6, [rsp+0x50]
000073dfa87e1bdd  vmovaps xmm7, [rsp+0x60]
000073dfa87e1be3  vmovaps xmm8, [rsp+0x70]
000073dfa87e1be9  vmovaps xmm9, [rsp+0x80]
000073dfa87e1bf2  vmovaps xmm10, [rsp+0x90]
000073dfa87e1bfb  vmovaps xmm11, [rsp+0xA0]
000073dfa87e1c04  vmovaps xmm12, [rsp+0xB0]
000073dfa87e1c0d  vmovaps xmm13, [rsp+0xC0]
000073dfa87e1c16  vmovaps xmm14, [rsp+0xD0]
000073dfa87e1c1f  vmovaps xmm15, [rsp+0xE0]
000073dfa87e1c28  add rsp, 0xF0
000073dfa87e1c2f  pop r11
000073dfa87e1c31  pop r10
000073dfa87e1c33  pop r9
000073dfa87e1c35  pop r8
000073dfa87e1c37  pop rsi
000073dfa87e1c38  pop rdi
000073dfa87e1c39  pop rdx
000073dfa87e1c3a  pop rcx
000073dfa87e1c3b  pop rax
000073dfa87e1c3c  add rsp, 0x08
000073dfa87e1c40  jmp 0x000073DFA87DF452
000073dfa87e1c45  call 0x000073DFA86B52F0
000073dfa87e1c4a  jmp 0x000073DFA87DF45C
000073dfa87e1c4f  sub rsp, 0x08
000073dfa87e1c53  push rax
000073dfa87e1c54  push rcx
000073dfa87e1c55  push rdx
000073dfa87e1c56  push rdi
000073dfa87e1c57  push rsi
000073dfa87e1c58  push r8
000073dfa87e1c5a  push r9
000073dfa87e1c5c  push r10
000073dfa87e1c5e  push r11
000073dfa87e1c60  sub rsp, 0xF0
000073dfa87e1c67  vmovaps [rsp], xmm0
000073dfa87e1c6c  vmovaps [rsp+0x10], xmm1
000073dfa87e1c72  vmovaps [rsp+0x20], xmm2
000073dfa87e1c78  vmovaps [rsp+0x30], xmm3
000073dfa87e1c7e  vmovaps [rsp+0x40], xmm4
000073dfa87e1c84  vmovaps [rsp+0x50], xmm5
000073dfa87e1c8a  vmovaps [rsp+0x60], xmm6
000073dfa87e1c90  vmovaps [rsp+0x70], xmm7
000073dfa87e1c96  vmovaps [rsp+0x80], xmm8
000073dfa87e1c9f  vmovaps [rsp+0x90], xmm9
000073dfa87e1ca8  vmovaps [rsp+0xA0], xmm10
000073dfa87e1cb1  vmovaps [rsp+0xB0], xmm11
000073dfa87e1cba  vmovaps [rsp+0xC0], xmm12
000073dfa87e1cc3  vmovaps [rsp+0xD0], xmm13
000073dfa87e1ccc  vmovaps [rsp+0xE0], xmm14
000073dfa87e1cd5  sub rsp, 0x30
000073dfa87e1cd9  movaps [rsp], xmm15
000073dfa87e1cde  movaps [rsp+0x10], xmm14
000073dfa87e1ce4  movaps [rsp+0x20], xmm4
000073dfa87e1ce9  lea rdi, [rsp]
000073dfa87e1ced  mov esi, 0x00
000073dfa87e1cf2  mov rax, 0x593AA1DA4530
000073dfa87e1cfc  call rax
000073dfa87e1cfe  movaps xmm15, [rsp]
000073dfa87e1d03  add rsp, 0x30
000073dfa87e1d07  vmovaps xmm0, [rsp]
000073dfa87e1d0c  vmovaps xmm1, [rsp+0x10]
000073dfa87e1d12  vmovaps xmm2, [rsp+0x20]
000073dfa87e1d18  vmovaps xmm3, [rsp+0x30]
000073dfa87e1d1e  vmovaps xmm4, [rsp+0x40]
000073dfa87e1d24  vmovaps xmm5, [rsp+0x50]
000073dfa87e1d2a  vmovaps xmm6, [rsp+0x60]
000073dfa87e1d30  vmovaps xmm7, [rsp+0x70]
000073dfa87e1d36  vmovaps xmm8, [rsp+0x80]
000073dfa87e1d3f  vmovaps xmm9, [rsp+0x90]
000073dfa87e1d48  vmovaps xmm10, [rsp+0xA0]
000073dfa87e1d51  vmovaps xmm11, [rsp+0xB0]
000073dfa87e1d5a  vmovaps xmm12, [rsp+0xC0]
000073dfa87e1d63  vmovaps xmm13, [rsp+0xD0]
000073dfa87e1d6c  vmovaps xmm14, [rsp+0xE0]
000073dfa87e1d75  add rsp, 0xF0
000073dfa87e1d7c  pop r11
000073dfa87e1d7e  pop r10
000073dfa87e1d80  pop r9
000073dfa87e1d82  pop r8
000073dfa87e1d84  pop rsi
000073dfa87e1d85  pop rdi
000073dfa87e1d86  pop rdx
000073dfa87e1d87  pop rcx
000073dfa87e1d88  pop rax
000073dfa87e1d89  add rsp, 0x08
000073dfa87e1d8d  jmp 0x000073DFA87DF48A
000073dfa87e1d92  sub rsp, 0x08
000073dfa87e1d96  push rax
000073dfa87e1d97  push rcx
000073dfa87e1d98  push rdx
000073dfa87e1d99  push rdi
000073dfa87e1d9a  push rsi
000073dfa87e1d9b  push r8
000073dfa87e1d9d  push r9
000073dfa87e1d9f  push r10
000073dfa87e1da1  push r11
000073dfa87e1da3  sub rsp, 0xF0
000073dfa87e1daa  vmovaps [rsp], xmm0
000073dfa87e1daf  vmovaps [rsp+0x10], xmm1
000073dfa87e1db5  vmovaps [rsp+0x20], xmm2
000073dfa87e1dbb  vmovaps [rsp+0x30], xmm3
000073dfa87e1dc1  vmovaps [rsp+0x40], xmm4
000073dfa87e1dc7  vmovaps [rsp+0x50], xmm5
000073dfa87e1dcd  vmovaps [rsp+0x60], xmm6
000073dfa87e1dd3  vmovaps [rsp+0x70], xmm7
000073dfa87e1dd9  vmovaps [rsp+0x80], xmm8
000073dfa87e1de2  vmovaps [rsp+0x90], xmm9
000073dfa87e1deb  vmovaps [rsp+0xA0], xmm10
000073dfa87e1df4  vmovaps [rsp+0xB0], xmm11
000073dfa87e1dfd  vmovaps [rsp+0xC0], xmm12
000073dfa87e1e06  vmovaps [rsp+0xD0], xmm13
000073dfa87e1e0f  vmovaps [rsp+0xE0], xmm15
000073dfa87e1e18  sub rsp, 0x30
000073dfa87e1e1c  movaps [rsp], xmm14
000073dfa87e1e21  movaps [rsp+0x10], xmm2
000073dfa87e1e26  movaps [rsp+0x20], xmm1
000073dfa87e1e2b  lea rdi, [rsp]
000073dfa87e1e2f  mov esi, 0x00
000073dfa87e1e34  mov rax, 0x593AA1DA4530
000073dfa87e1e3e  call rax
000073dfa87e1e40  movaps xmm14, [rsp]
000073dfa87e1e45  add rsp, 0x30
000073dfa87e1e49  vmovaps xmm0, [rsp]
000073dfa87e1e4e  vmovaps xmm1, [rsp+0x10]
000073dfa87e1e54  vmovaps xmm2, [rsp+0x20]
000073dfa87e1e5a  vmovaps xmm3, [rsp+0x30]
000073dfa87e1e60  vmovaps xmm4, [rsp+0x40]
000073dfa87e1e66  vmovaps xmm5, [rsp+0x50]
000073dfa87e1e6c  vmovaps xmm6, [rsp+0x60]
000073dfa87e1e72  vmovaps xmm7, [rsp+0x70]
000073dfa87e1e78  vmovaps xmm8, [rsp+0x80]
000073dfa87e1e81  vmovaps xmm9, [rsp+0x90]
000073dfa87e1e8a  vmovaps xmm10, [rsp+0xA0]
000073dfa87e1e93  vmovaps xmm11, [rsp+0xB0]
000073dfa87e1e9c  vmovaps xmm12, [rsp+0xC0]
000073dfa87e1ea5  vmovaps xmm13, [rsp+0xD0]
000073dfa87e1eae  vmovaps xmm15, [rsp+0xE0]
000073dfa87e1eb7  add rsp, 0xF0
000073dfa87e1ebe  pop r11
000073dfa87e1ec0  pop r10
000073dfa87e1ec2  pop r9
000073dfa87e1ec4  pop r8
000073dfa87e1ec6  pop rsi
000073dfa87e1ec7  pop rdi
000073dfa87e1ec8  pop rdx
000073dfa87e1ec9  pop rcx
000073dfa87e1eca  pop rax
000073dfa87e1ecb  add rsp, 0x08
000073dfa87e1ecf  jmp 0x000073DFA87DF4B0
000073dfa87e1ed4  sub rsp, 0x08
000073dfa87e1ed8  push rax
000073dfa87e1ed9  push rcx
000073dfa87e1eda  push rdx
000073dfa87e1edb  push rdi
000073dfa87e1edc  push rsi
000073dfa87e1edd  push r8
000073dfa87e1edf  push r9
000073dfa87e1ee1  push r10
000073dfa87e1ee3  push r11
000073dfa87e1ee5  sub rsp, 0xF0
000073dfa87e1eec  vmovaps [rsp], xmm0
000073dfa87e1ef1  vmovaps [rsp+0x10], xmm2
000073dfa87e1ef7  vmovaps [rsp+0x20], xmm3
000073dfa87e1efd  vmovaps [rsp+0x30], xmm4
000073dfa87e1f03  vmovaps [rsp+0x40], xmm5
000073dfa87e1f09  vmovaps [rsp+0x50], xmm6
000073dfa87e1f0f  vmovaps [rsp+0x60], xmm7
000073dfa87e1f15  vmovaps [rsp+0x70], xmm8
000073dfa87e1f1b  vmovaps [rsp+0x80], xmm9
000073dfa87e1f24  vmovaps [rsp+0x90], xmm10
000073dfa87e1f2d  vmovaps [rsp+0xA0], xmm11
000073dfa87e1f36  vmovaps [rsp+0xB0], xmm12
000073dfa87e1f3f  vmovaps [rsp+0xC0], xmm13
000073dfa87e1f48  vmovaps [rsp+0xD0], xmm14
000073dfa87e1f51  vmovaps [rsp+0xE0], xmm15
000073dfa87e1f5a  sub rsp, 0x30
000073dfa87e1f5e  movaps [rsp], xmm1
000073dfa87e1f62  movaps [rsp+0x10], xmm4
000073dfa87e1f67  movaps [rsp+0x20], xmm9
000073dfa87e1f6d  lea rdi, [rsp]
000073dfa87e1f71  mov esi, 0x00
000073dfa87e1f76  mov rax, 0x593AA1DA4530
000073dfa87e1f80  call rax
000073dfa87e1f82  movaps xmm1, [rsp]
000073dfa87e1f86  add rsp, 0x30
000073dfa87e1f8a  vmovaps xmm0, [rsp]
000073dfa87e1f8f  vmovaps xmm2, [rsp+0x10]
000073dfa87e1f95  vmovaps xmm3, [rsp+0x20]
000073dfa87e1f9b  vmovaps xmm4, [rsp+0x30]
000073dfa87e1fa1  vmovaps xmm5, [rsp+0x40]
000073dfa87e1fa7  vmovaps xmm6, [rsp+0x50]
000073dfa87e1fad  vmovaps xmm7, [rsp+0x60]
000073dfa87e1fb3  vmovaps xmm8, [rsp+0x70]
000073dfa87e1fb9  vmovaps xmm9, [rsp+0x80]
000073dfa87e1fc2  vmovaps xmm10, [rsp+0x90]
000073dfa87e1fcb  vmovaps xmm11, [rsp+0xA0]
000073dfa87e1fd4  vmovaps xmm12, [rsp+0xB0]
000073dfa87e1fdd  vmovaps xmm13, [rsp+0xC0]
000073dfa87e1fe6  vmovaps xmm14, [rsp+0xD0]
000073dfa87e1fef  vmovaps xmm15, [rsp+0xE0]
000073dfa87e1ff8  add rsp, 0xF0
000073dfa87e1fff  pop r11
000073dfa87e2001  pop r10
000073dfa87e2003  pop r9
000073dfa87e2005  pop r8
000073dfa87e2007  pop rsi
000073dfa87e2008  pop rdi
000073dfa87e2009  pop rdx
000073dfa87e200a  pop rcx
000073dfa87e200b  pop rax
000073dfa87e200c  add rsp, 0x08
000073dfa87e2010  jmp 0x000073DFA87DF4CE
000073dfa87e2015  sub rsp, 0x08
000073dfa87e2019  push rax
000073dfa87e201a  push rcx
000073dfa87e201b  push rdx
000073dfa87e201c  push rdi
000073dfa87e201d  push rsi
000073dfa87e201e  push r8
000073dfa87e2020  push r9
000073dfa87e2022  push r10
000073dfa87e2024  push r11
000073dfa87e2026  sub rsp, 0xF0
000073dfa87e202d  vmovaps [rsp], xmm0
000073dfa87e2032  vmovaps [rsp+0x10], xmm1
000073dfa87e2038  vmovaps [rsp+0x20], xmm2
000073dfa87e203e  vmovaps [rsp+0x30], xmm3
000073dfa87e2044  vmovaps [rsp+0x40], xmm5
000073dfa87e204a  vmovaps [rsp+0x50], xmm6
000073dfa87e2050  vmovaps [rsp+0x60], xmm7
000073dfa87e2056  vmovaps [rsp+0x70], xmm8
000073dfa87e205c  vmovaps [rsp+0x80], xmm9
000073dfa87e2065  vmovaps [rsp+0x90], xmm10
000073dfa87e206e  vmovaps [rsp+0xA0], xmm11
000073dfa87e2077  vmovaps [rsp+0xB0], xmm12
000073dfa87e2080  vmovaps [rsp+0xC0], xmm13
000073dfa87e2089  vmovaps [rsp+0xD0], xmm14
000073dfa87e2092  vmovaps [rsp+0xE0], xmm15
000073dfa87e209b  sub rsp, 0x30
000073dfa87e209f  movaps [rsp], xmm4
000073dfa87e20a3  movaps [rsp+0x10], xmm2
000073dfa87e20a8  movaps [rsp+0x20], xmm9
000073dfa87e20ae  lea rdi, [rsp]
000073dfa87e20b2  mov esi, 0x00
000073dfa87e20b7  mov rax, 0x593AA1DA4530
000073dfa87e20c1  call rax
000073dfa87e20c3  movaps xmm4, [rsp]
000073dfa87e20c7  add rsp, 0x30
000073dfa87e20cb  vmovaps xmm0, [rsp]
000073dfa87e20d0  vmovaps xmm1, [rsp+0x10]
000073dfa87e20d6  vmovaps xmm2, [rsp+0x20]
000073dfa87e20dc  vmovaps xmm3, [rsp+0x30]
000073dfa87e20e2  vmovaps xmm5, [rsp+0x40]
000073dfa87e20e8  vmovaps xmm6, [rsp+0x50]
000073dfa87e20ee  vmovaps xmm7, [rsp+0x60]
000073dfa87e20f4  vmovaps xmm8, [rsp+0x70]
000073dfa87e20fa  vmovaps xmm9, [rsp+0x80]
000073dfa87e2103  vmovaps xmm10, [rsp+0x90]
000073dfa87e210c  vmovaps xmm11, [rsp+0xA0]
000073dfa87e2115  vmovaps xmm12, [rsp+0xB0]
000073dfa87e211e  vmovaps xmm13, [rsp+0xC0]
000073dfa87e2127  vmovaps xmm14, [rsp+0xD0]
000073dfa87e2130  vmovaps xmm15, [rsp+0xE0]
000073dfa87e2139  add rsp, 0xF0
000073dfa87e2140  pop r11
000073dfa87e2142  pop r10
000073dfa87e2144  pop r9
000073dfa87e2146  pop r8
000073dfa87e2148  pop rsi
000073dfa87e2149  pop rdi
000073dfa87e214a  pop rdx
000073dfa87e214b  pop rcx
000073dfa87e214c  pop rax
000073dfa87e214d  add rsp, 0x08
000073dfa87e2151  jmp 0x000073DFA87DF4FE
000073dfa87e2156  sub rsp, 0x08
000073dfa87e215a  push rax
000073dfa87e215b  push rcx
000073dfa87e215c  push rdx
000073dfa87e215d  push rdi
000073dfa87e215e  push rsi
000073dfa87e215f  push r8
000073dfa87e2161  push r9
000073dfa87e2163  push r10
000073dfa87e2165  push r11
000073dfa87e2167  sub rsp, 0xF0
000073dfa87e216e  vmovaps [rsp], xmm0
000073dfa87e2173  vmovaps [rsp+0x10], xmm1
000073dfa87e2179  vmovaps [rsp+0x20], xmm2
000073dfa87e217f  vmovaps [rsp+0x30], xmm3
000073dfa87e2185  vmovaps [rsp+0x40], xmm4
000073dfa87e218b  vmovaps [rsp+0x50], xmm5
000073dfa87e2191  vmovaps [rsp+0x60], xmm6
000073dfa87e2197  vmovaps [rsp+0x70], xmm7
000073dfa87e219d  vmovaps [rsp+0x80], xmm8
000073dfa87e21a6  vmovaps [rsp+0x90], xmm10
000073dfa87e21af  vmovaps [rsp+0xA0], xmm11
000073dfa87e21b8  vmovaps [rsp+0xB0], xmm12
000073dfa87e21c1  vmovaps [rsp+0xC0], xmm13
000073dfa87e21ca  vmovaps [rsp+0xD0], xmm14
000073dfa87e21d3  vmovaps [rsp+0xE0], xmm15
000073dfa87e21dc  sub rsp, 0x30
000073dfa87e21e0  movaps [rsp], xmm9
000073dfa87e21e5  movaps [rsp+0x10], xmm2
000073dfa87e21ea  movaps [rsp+0x20], xmm1
000073dfa87e21ef  lea rdi, [rsp]
000073dfa87e21f3  mov esi, 0x00
000073dfa87e21f8  mov rax, 0x593AA1DA4530
000073dfa87e2202  call rax
000073dfa87e2204  movaps xmm9, [rsp]
000073dfa87e2209  add rsp, 0x30
000073dfa87e220d  vmovaps xmm0, [rsp]
000073dfa87e2212  vmovaps xmm1, [rsp+0x10]
000073dfa87e2218  vmovaps xmm2, [rsp+0x20]
000073dfa87e221e  vmovaps xmm3, [rsp+0x30]
000073dfa87e2224  vmovaps xmm4, [rsp+0x40]
000073dfa87e222a  vmovaps xmm5, [rsp+0x50]
000073dfa87e2230  vmovaps xmm6, [rsp+0x60]
000073dfa87e2236  vmovaps xmm7, [rsp+0x70]
000073dfa87e223c  vmovaps xmm8, [rsp+0x80]
000073dfa87e2245  vmovaps xmm10, [rsp+0x90]
000073dfa87e224e  vmovaps xmm11, [rsp+0xA0]
000073dfa87e2257  vmovaps xmm12, [rsp+0xB0]
000073dfa87e2260  vmovaps xmm13, [rsp+0xC0]
000073dfa87e2269  vmovaps xmm14, [rsp+0xD0]
000073dfa87e2272  vmovaps xmm15, [rsp+0xE0]
000073dfa87e227b  add rsp, 0xF0
000073dfa87e2282  pop r11
000073dfa87e2284  pop r10
000073dfa87e2286  pop r9
000073dfa87e2288  pop r8
000073dfa87e228a  pop rsi
000073dfa87e228b  pop rdi
000073dfa87e228c  pop rdx
000073dfa87e228d  pop rcx
000073dfa87e228e  pop rax
000073dfa87e228f  add rsp, 0x08
000073dfa87e2293  jmp 0x000073DFA87DF534
000073dfa87e2298  sub rsp, 0x08
000073dfa87e229c  push rax
000073dfa87e229d  push rcx
000073dfa87e229e  push rdx
000073dfa87e229f  push rdi
000073dfa87e22a0  push rsi
000073dfa87e22a1  push r8
000073dfa87e22a3  push r9
000073dfa87e22a5  push r10
000073dfa87e22a7  push r11
000073dfa87e22a9  sub rsp, 0xF0
000073dfa87e22b0  vmovaps [rsp], xmm0
000073dfa87e22b5  vmovaps [rsp+0x10], xmm2
000073dfa87e22bb  vmovaps [rsp+0x20], xmm3
000073dfa87e22c1  vmovaps [rsp+0x30], xmm4
000073dfa87e22c7  vmovaps [rsp+0x40], xmm5
000073dfa87e22cd  vmovaps [rsp+0x50], xmm6
000073dfa87e22d3  vmovaps [rsp+0x60], xmm7
000073dfa87e22d9  vmovaps [rsp+0x70], xmm8
000073dfa87e22df  vmovaps [rsp+0x80], xmm9
000073dfa87e22e8  vmovaps [rsp+0x90], xmm10
000073dfa87e22f1  vmovaps [rsp+0xA0], xmm11
000073dfa87e22fa  vmovaps [rsp+0xB0], xmm12
000073dfa87e2303  vmovaps [rsp+0xC0], xmm13
000073dfa87e230c  vmovaps [rsp+0xD0], xmm14
000073dfa87e2315  vmovaps [rsp+0xE0], xmm15
000073dfa87e231e  sub rsp, 0x30
000073dfa87e2322  movaps [rsp], xmm1
000073dfa87e2326  movaps [rsp+0x10], xmm15
000073dfa87e232c  movaps [rsp+0x20], xmm6
000073dfa87e2331  lea rdi, [rsp]
000073dfa87e2335  mov esi, 0x00
000073dfa87e233a  mov rax, 0x593AA1DA4530
000073dfa87e2344  call rax
000073dfa87e2346  movaps xmm1, [rsp]
000073dfa87e234a  add rsp, 0x30
000073dfa87e234e  vmovaps xmm0, [rsp]
000073dfa87e2353  vmovaps xmm2, [rsp+0x10]
000073dfa87e2359  vmovaps xmm3, [rsp+0x20]
000073dfa87e235f  vmovaps xmm4, [rsp+0x30]
000073dfa87e2365  vmovaps xmm5, [rsp+0x40]
000073dfa87e236b  vmovaps xmm6, [rsp+0x50]
000073dfa87e2371  vmovaps xmm7, [rsp+0x60]
000073dfa87e2377  vmovaps xmm8, [rsp+0x70]
000073dfa87e237d  vmovaps xmm9, [rsp+0x80]
000073dfa87e2386  vmovaps xmm10, [rsp+0x90]
000073dfa87e238f  vmovaps xmm11, [rsp+0xA0]
000073dfa87e2398  vmovaps xmm12, [rsp+0xB0]
000073dfa87e23a1  vmovaps xmm13, [rsp+0xC0]
000073dfa87e23aa  vmovaps xmm14, [rsp+0xD0]
000073dfa87e23b3  vmovaps xmm15, [rsp+0xE0]
000073dfa87e23bc  add rsp, 0xF0
000073dfa87e23c3  pop r11
000073dfa87e23c5  pop r10
000073dfa87e23c7  pop r9
000073dfa87e23c9  pop r8
000073dfa87e23cb  pop rsi
000073dfa87e23cc  pop rdi
000073dfa87e23cd  pop rdx
000073dfa87e23ce  pop rcx
000073dfa87e23cf  pop rax
000073dfa87e23d0  add rsp, 0x08
000073dfa87e23d4  jmp 0x000073DFA87DF555
000073dfa87e23d9  sub rsp, 0x08
000073dfa87e23dd  push rax
000073dfa87e23de  push rcx
000073dfa87e23df  push rdx
000073dfa87e23e0  push rdi
000073dfa87e23e1  push rsi
000073dfa87e23e2  push r8
000073dfa87e23e4  push r9
000073dfa87e23e6  push r10
000073dfa87e23e8  push r11
000073dfa87e23ea  sub rsp, 0xF0
000073dfa87e23f1  vmovaps [rsp], xmm0
000073dfa87e23f6  vmovaps [rsp+0x10], xmm1
000073dfa87e23fc  vmovaps [rsp+0x20], xmm2
000073dfa87e2402  vmovaps [rsp+0x30], xmm3
000073dfa87e2408  vmovaps [rsp+0x40], xmm4
000073dfa87e240e  vmovaps [rsp+0x50], xmm5
000073dfa87e2414  vmovaps [rsp+0x60], xmm6
000073dfa87e241a  vmovaps [rsp+0x70], xmm7
000073dfa87e2420  vmovaps [rsp+0x80], xmm8
000073dfa87e2429  vmovaps [rsp+0x90], xmm9
000073dfa87e2432  vmovaps [rsp+0xA0], xmm10
000073dfa87e243b  vmovaps [rsp+0xB0], xmm11
000073dfa87e2444  vmovaps [rsp+0xC0], xmm12
000073dfa87e244d  vmovaps [rsp+0xD0], xmm13
000073dfa87e2456  vmovaps [rsp+0xE0], xmm14
000073dfa87e245f  sub rsp, 0x30
000073dfa87e2463  movaps [rsp], xmm15
000073dfa87e2468  movaps [rsp+0x10], xmm5
000073dfa87e246d  movaps [rsp+0x20], xmm3
000073dfa87e2472  lea rdi, [rsp]
000073dfa87e2476  mov esi, 0x00
000073dfa87e247b  mov rax, 0x593AA1DA4530
000073dfa87e2485  call rax
000073dfa87e2487  movaps xmm15, [rsp]
000073dfa87e248c  add rsp, 0x30
000073dfa87e2490  vmovaps xmm0, [rsp]
000073dfa87e2495  vmovaps xmm1, [rsp+0x10]
000073dfa87e249b  vmovaps xmm2, [rsp+0x20]
000073dfa87e24a1  vmovaps xmm3, [rsp+0x30]
000073dfa87e24a7  vmovaps xmm4, [rsp+0x40]
000073dfa87e24ad  vmovaps xmm5, [rsp+0x50]
000073dfa87e24b3  vmovaps xmm6, [rsp+0x60]
000073dfa87e24b9  vmovaps xmm7, [rsp+0x70]
000073dfa87e24bf  vmovaps xmm8, [rsp+0x80]
000073dfa87e24c8  vmovaps xmm9, [rsp+0x90]
000073dfa87e24d1  vmovaps xmm10, [rsp+0xA0]
000073dfa87e24da  vmovaps xmm11, [rsp+0xB0]
000073dfa87e24e3  vmovaps xmm12, [rsp+0xC0]
000073dfa87e24ec  vmovaps xmm13, [rsp+0xD0]
000073dfa87e24f5  vmovaps xmm14, [rsp+0xE0]
000073dfa87e24fe  add rsp, 0xF0
000073dfa87e2505  pop r11
000073dfa87e2507  pop r10
000073dfa87e2509  pop r9
000073dfa87e250b  pop r8
000073dfa87e250d  pop rsi
000073dfa87e250e  pop rdi
000073dfa87e250f  pop rdx
000073dfa87e2510  pop rcx
000073dfa87e2511  pop rax
000073dfa87e2512  add rsp, 0x08
000073dfa87e2516  jmp 0x000073DFA87DF56F
000073dfa87e251b  sub rsp, 0x08
000073dfa87e251f  push rax
000073dfa87e2520  push rcx
000073dfa87e2521  push rdx
000073dfa87e2522  push rdi
000073dfa87e2523  push rsi
000073dfa87e2524  push r8
000073dfa87e2526  push r9
000073dfa87e2528  push r10
000073dfa87e252a  push r11
000073dfa87e252c  sub rsp, 0xF0
000073dfa87e2533  vmovaps [rsp], xmm0
000073dfa87e2538  vmovaps [rsp+0x10], xmm1
000073dfa87e253e  vmovaps [rsp+0x20], xmm2
000073dfa87e2544  vmovaps [rsp+0x30], xmm3
000073dfa87e254a  vmovaps [rsp+0x40], xmm4
000073dfa87e2550  vmovaps [rsp+0x50], xmm6
000073dfa87e2556  vmovaps [rsp+0x60], xmm7
000073dfa87e255c  vmovaps [rsp+0x70], xmm8
000073dfa87e2562  vmovaps [rsp+0x80], xmm9
000073dfa87e256b  vmovaps [rsp+0x90], xmm10
000073dfa87e2574  vmovaps [rsp+0xA0], xmm11
000073dfa87e257d  vmovaps [rsp+0xB0], xmm12
000073dfa87e2586  vmovaps [rsp+0xC0], xmm13
000073dfa87e258f  vmovaps [rsp+0xD0], xmm14
000073dfa87e2598  vmovaps [rsp+0xE0], xmm15
000073dfa87e25a1  sub rsp, 0x30
000073dfa87e25a5  movaps [rsp], xmm5
000073dfa87e25a9  movaps [rsp+0x10], xmm8
000073dfa87e25af  movaps [rsp+0x20], xmm6
000073dfa87e25b4  lea rdi, [rsp]
000073dfa87e25b8  mov esi, 0x00
000073dfa87e25bd  mov rax, 0x593AA1DA4530
000073dfa87e25c7  call rax
000073dfa87e25c9  movaps xmm5, [rsp]
000073dfa87e25cd  add rsp, 0x30
000073dfa87e25d1  vmovaps xmm0, [rsp]
000073dfa87e25d6  vmovaps xmm1, [rsp+0x10]
000073dfa87e25dc  vmovaps xmm2, [rsp+0x20]
000073dfa87e25e2  vmovaps xmm3, [rsp+0x30]
000073dfa87e25e8  vmovaps xmm4, [rsp+0x40]
000073dfa87e25ee  vmovaps xmm6, [rsp+0x50]
000073dfa87e25f4  vmovaps xmm7, [rsp+0x60]
000073dfa87e25fa  vmovaps xmm8, [rsp+0x70]
000073dfa87e2600  vmovaps xmm9, [rsp+0x80]
000073dfa87e2609  vmovaps xmm10, [rsp+0x90]
000073dfa87e2612  vmovaps xmm11, [rsp+0xA0]
000073dfa87e261b  vmovaps xmm12, [rsp+0xB0]
000073dfa87e2624  vmovaps xmm13, [rsp+0xC0]
000073dfa87e262d  vmovaps xmm14, [rsp+0xD0]
000073dfa87e2636  vmovaps xmm15, [rsp+0xE0]
000073dfa87e263f  add rsp, 0xF0
000073dfa87e2646  pop r11
000073dfa87e2648  pop r10
000073dfa87e264a  pop r9
000073dfa87e264c  pop r8
000073dfa87e264e  pop rsi
000073dfa87e264f  pop rdi
000073dfa87e2650  pop rdx
000073dfa87e2651  pop rcx
000073dfa87e2652  pop rax
000073dfa87e2653  add rsp, 0x08
000073dfa87e2657  jmp 0x000073DFA87DF593
000073dfa87e265c  sub rsp, 0x08
000073dfa87e2660  push rax
000073dfa87e2661  push rcx
000073dfa87e2662  push rdx
000073dfa87e2663  push rdi
000073dfa87e2664  push rsi
000073dfa87e2665  push r8
000073dfa87e2667  push r9
000073dfa87e2669  push r10
000073dfa87e266b  push r11
000073dfa87e266d  sub rsp, 0xF0
000073dfa87e2674  vmovaps [rsp], xmm0
000073dfa87e2679  vmovaps [rsp+0x10], xmm1
000073dfa87e267f  vmovaps [rsp+0x20], xmm2
000073dfa87e2685  vmovaps [rsp+0x30], xmm3
000073dfa87e268b  vmovaps [rsp+0x40], xmm4
000073dfa87e2691  vmovaps [rsp+0x50], xmm5
000073dfa87e2697  vmovaps [rsp+0x60], xmm7
000073dfa87e269d  vmovaps [rsp+0x70], xmm8
000073dfa87e26a3  vmovaps [rsp+0x80], xmm9
000073dfa87e26ac  vmovaps [rsp+0x90], xmm10
000073dfa87e26b5  vmovaps [rsp+0xA0], xmm11
000073dfa87e26be  vmovaps [rsp+0xB0], xmm12
000073dfa87e26c7  vmovaps [rsp+0xC0], xmm13
000073dfa87e26d0  vmovaps [rsp+0xD0], xmm14
000073dfa87e26d9  vmovaps [rsp+0xE0], xmm15
000073dfa87e26e2  sub rsp, 0x30
000073dfa87e26e6  movaps [rsp], xmm6
000073dfa87e26ea  movaps [rsp+0x10], xmm10
000073dfa87e26f0  movaps [rsp+0x20], xmm8
000073dfa87e26f6  lea rdi, [rsp]
000073dfa87e26fa  mov esi, 0x00
000073dfa87e26ff  mov rax, 0x593AA1DA4530
000073dfa87e2709  call rax
000073dfa87e270b  movaps xmm6, [rsp]
000073dfa87e270f  add rsp, 0x30
000073dfa87e2713  vmovaps xmm0, [rsp]
000073dfa87e2718  vmovaps xmm1, [rsp+0x10]
000073dfa87e271e  vmovaps xmm2, [rsp+0x20]
000073dfa87e2724  vmovaps xmm3, [rsp+0x30]
000073dfa87e272a  vmovaps xmm4, [rsp+0x40]
000073dfa87e2730  vmovaps xmm5, [rsp+0x50]
000073dfa87e2736  vmovaps xmm7, [rsp+0x60]
000073dfa87e273c  vmovaps xmm8, [rsp+0x70]
000073dfa87e2742  vmovaps xmm9, [rsp+0x80]
000073dfa87e274b  vmovaps xmm10, [rsp+0x90]
000073dfa87e2754  vmovaps xmm11, [rsp+0xA0]
000073dfa87e275d  vmovaps xmm12, [rsp+0xB0]
000073dfa87e2766  vmovaps xmm13, [rsp+0xC0]
000073dfa87e276f  vmovaps xmm14, [rsp+0xD0]
000073dfa87e2778  vmovaps xmm15, [rsp+0xE0]
000073dfa87e2781  add rsp, 0xF0
000073dfa87e2788  pop r11
000073dfa87e278a  pop r10
000073dfa87e278c  pop r9
000073dfa87e278e  pop r8
000073dfa87e2790  pop rsi
000073dfa87e2791  pop rdi
000073dfa87e2792  pop rdx
000073dfa87e2793  pop rcx
000073dfa87e2794  pop rax
000073dfa87e2795  add rsp, 0x08
000073dfa87e2799  jmp 0x000073DFA87DF5B8
000073dfa87e279e  sub rsp, 0x08
000073dfa87e27a2  push rax
000073dfa87e27a3  push rcx
000073dfa87e27a4  push rdx
000073dfa87e27a5  push rdi
000073dfa87e27a6  push rsi
000073dfa87e27a7  push r8
000073dfa87e27a9  push r9
000073dfa87e27ab  push r10
000073dfa87e27ad  push r11
000073dfa87e27af  sub rsp, 0xF0
000073dfa87e27b6  vmovaps [rsp], xmm0
000073dfa87e27bb  vmovaps [rsp+0x10], xmm1
000073dfa87e27c1  vmovaps [rsp+0x20], xmm2
000073dfa87e27c7  vmovaps [rsp+0x30], xmm3
000073dfa87e27cd  vmovaps [rsp+0x40], xmm4
000073dfa87e27d3  vmovaps [rsp+0x50], xmm5
000073dfa87e27d9  vmovaps [rsp+0x60], xmm6
000073dfa87e27df  vmovaps [rsp+0x70], xmm7
000073dfa87e27e5  vmovaps [rsp+0x80], xmm8
000073dfa87e27ee  vmovaps [rsp+0x90], xmm9
000073dfa87e27f7  vmovaps [rsp+0xA0], xmm11
000073dfa87e2800  vmovaps [rsp+0xB0], xmm12
000073dfa87e2809  vmovaps [rsp+0xC0], xmm13
000073dfa87e2812  vmovaps [rsp+0xD0], xmm14
000073dfa87e281b  vmovaps [rsp+0xE0], xmm15
000073dfa87e2824  sub rsp, 0x30
000073dfa87e2828  movaps [rsp], xmm10
000073dfa87e282d  movaps [rsp+0x10], xmm8
000073dfa87e2833  movaps [rsp+0x20], xmm14
000073dfa87e2839  lea rdi, [rsp]
000073dfa87e283d  mov esi, 0x00
000073dfa87e2842  mov rax, 0x593AA1DA4530
000073dfa87e284c  call rax
000073dfa87e284e  movaps xmm10, [rsp]
000073dfa87e2853  add rsp, 0x30
000073dfa87e2857  vmovaps xmm0, [rsp]
000073dfa87e285c  vmovaps xmm1, [rsp+0x10]
000073dfa87e2862  vmovaps xmm2, [rsp+0x20]
000073dfa87e2868  vmovaps xmm3, [rsp+0x30]
000073dfa87e286e  vmovaps xmm4, [rsp+0x40]
000073dfa87e2874  vmovaps xmm5, [rsp+0x50]
000073dfa87e287a  vmovaps xmm6, [rsp+0x60]
000073dfa87e2880  vmovaps xmm7, [rsp+0x70]
000073dfa87e2886  vmovaps xmm8, [rsp+0x80]
000073dfa87e288f  vmovaps xmm9, [rsp+0x90]
000073dfa87e2898  vmovaps xmm11, [rsp+0xA0]
000073dfa87e28a1  vmovaps xmm12, [rsp+0xB0]
000073dfa87e28aa  vmovaps xmm13, [rsp+0xC0]
000073dfa87e28b3  vmovaps xmm14, [rsp+0xD0]
000073dfa87e28bc  vmovaps xmm15, [rsp+0xE0]
000073dfa87e28c5  add rsp, 0xF0
000073dfa87e28cc  pop r11
000073dfa87e28ce  pop r10
000073dfa87e28d0  pop r9
000073dfa87e28d2  pop r8
000073dfa87e28d4  pop rsi
000073dfa87e28d5  pop rdi
000073dfa87e28d6  pop rdx
000073dfa87e28d7  pop rcx
000073dfa87e28d8  pop rax
000073dfa87e28d9  add rsp, 0x08
000073dfa87e28dd  jmp 0x000073DFA87DF5D8
000073dfa87e28e2  sub rsp, 0x08
000073dfa87e28e6  push rax
000073dfa87e28e7  push rcx
000073dfa87e28e8  push rdx
000073dfa87e28e9  push rdi
000073dfa87e28ea  push rsi
000073dfa87e28eb  push r8
000073dfa87e28ed  push r9
000073dfa87e28ef  push r10
000073dfa87e28f1  push r11
000073dfa87e28f3  sub rsp, 0xF0
000073dfa87e28fa  vmovaps [rsp], xmm0
000073dfa87e28ff  vmovaps [rsp+0x10], xmm1
000073dfa87e2905  vmovaps [rsp+0x20], xmm2
000073dfa87e290b  vmovaps [rsp+0x30], xmm3
000073dfa87e2911  vmovaps [rsp+0x40], xmm4
000073dfa87e2917  vmovaps [rsp+0x50], xmm5
000073dfa87e291d  vmovaps [rsp+0x60], xmm6
000073dfa87e2923  vmovaps [rsp+0x70], xmm7
000073dfa87e2929  vmovaps [rsp+0x80], xmm8
000073dfa87e2932  vmovaps [rsp+0x90], xmm9
000073dfa87e293b  vmovaps [rsp+0xA0], xmm10
000073dfa87e2944  vmovaps [rsp+0xB0], xmm11
000073dfa87e294d  vmovaps [rsp+0xC0], xmm12
000073dfa87e2956  vmovaps [rsp+0xD0], xmm13
000073dfa87e295f  vmovaps [rsp+0xE0], xmm15
000073dfa87e2968  sub rsp, 0x30
000073dfa87e296c  movaps [rsp], xmm14
000073dfa87e2971  movaps [rsp+0x10], xmm8
000073dfa87e2977  movaps [rsp+0x20], xmm4
000073dfa87e297c  lea rdi, [rsp]
000073dfa87e2980  mov esi, 0x00
000073dfa87e2985  mov rax, 0x593AA1DA4530
000073dfa87e298f  call rax
000073dfa87e2991  movaps xmm14, [rsp]
000073dfa87e2996  add rsp, 0x30
000073dfa87e299a  vmovaps xmm0, [rsp]
000073dfa87e299f  vmovaps xmm1, [rsp+0x10]
000073dfa87e29a5  vmovaps xmm2, [rsp+0x20]
000073dfa87e29ab  vmovaps xmm3, [rsp+0x30]
000073dfa87e29b1  vmovaps xmm4, [rsp+0x40]
000073dfa87e29b7  vmovaps xmm5, [rsp+0x50]
000073dfa87e29bd  vmovaps xmm6, [rsp+0x60]
000073dfa87e29c3  vmovaps xmm7, [rsp+0x70]
000073dfa87e29c9  vmovaps xmm8, [rsp+0x80]
000073dfa87e29d2  vmovaps xmm9, [rsp+0x90]
000073dfa87e29db  vmovaps xmm10, [rsp+0xA0]
000073dfa87e29e4  vmovaps xmm11, [rsp+0xB0]
000073dfa87e29ed  vmovaps xmm12, [rsp+0xC0]
000073dfa87e29f6  vmovaps xmm13, [rsp+0xD0]
000073dfa87e29ff  vmovaps xmm15, [rsp+0xE0]
000073dfa87e2a08  add rsp, 0xF0
000073dfa87e2a0f  pop r11
000073dfa87e2a11  pop r10
000073dfa87e2a13  pop r9
000073dfa87e2a15  pop r8
000073dfa87e2a17  pop rsi
000073dfa87e2a18  pop rdi
000073dfa87e2a19  pop rdx
000073dfa87e2a1a  pop rcx
000073dfa87e2a1b  pop rax
000073dfa87e2a1c  add rsp, 0x08
000073dfa87e2a20  jmp 0x000073DFA87DF5F8
000073dfa87e2a25  sub rsp, 0x08
000073dfa87e2a29  push rax
000073dfa87e2a2a  push rcx
000073dfa87e2a2b  push rdx
000073dfa87e2a2c  push rdi
000073dfa87e2a2d  push rsi
000073dfa87e2a2e  push r8
000073dfa87e2a30  push r9
000073dfa87e2a32  push r10
000073dfa87e2a34  push r11
000073dfa87e2a36  sub rsp, 0xF0
000073dfa87e2a3d  vmovaps [rsp], xmm0
000073dfa87e2a42  vmovaps [rsp+0x10], xmm1
000073dfa87e2a48  vmovaps [rsp+0x20], xmm2
000073dfa87e2a4e  vmovaps [rsp+0x30], xmm3
000073dfa87e2a54  vmovaps [rsp+0x40], xmm5
000073dfa87e2a5a  vmovaps [rsp+0x50], xmm6
000073dfa87e2a60  vmovaps [rsp+0x60], xmm7
000073dfa87e2a66  vmovaps [rsp+0x70], xmm8
000073dfa87e2a6c  vmovaps [rsp+0x80], xmm9
000073dfa87e2a75  vmovaps [rsp+0x90], xmm10
000073dfa87e2a7e  vmovaps [rsp+0xA0], xmm11
000073dfa87e2a87  vmovaps [rsp+0xB0], xmm12
000073dfa87e2a90  vmovaps [rsp+0xC0], xmm13
000073dfa87e2a99  vmovaps [rsp+0xD0], xmm14
000073dfa87e2aa2  vmovaps [rsp+0xE0], xmm15
000073dfa87e2aab  sub rsp, 0x30
000073dfa87e2aaf  movaps [rsp], xmm4
000073dfa87e2ab3  movaps [rsp+0x10], xmm13
000073dfa87e2ab9  movaps [rsp+0x20], xmm8
000073dfa87e2abf  lea rdi, [rsp]
000073dfa87e2ac3  mov esi, 0x00
000073dfa87e2ac8  mov rax, 0x593AA1DA4530
000073dfa87e2ad2  call rax
000073dfa87e2ad4  movaps xmm4, [rsp]
000073dfa87e2ad8  add rsp, 0x30
000073dfa87e2adc  vmovaps xmm0, [rsp]
000073dfa87e2ae1  vmovaps xmm1, [rsp+0x10]
000073dfa87e2ae7  vmovaps xmm2, [rsp+0x20]
000073dfa87e2aed  vmovaps xmm3, [rsp+0x30]
000073dfa87e2af3  vmovaps xmm5, [rsp+0x40]
000073dfa87e2af9  vmovaps xmm6, [rsp+0x50]
000073dfa87e2aff  vmovaps xmm7, [rsp+0x60]
000073dfa87e2b05  vmovaps xmm8, [rsp+0x70]
000073dfa87e2b0b  vmovaps xmm9, [rsp+0x80]
000073dfa87e2b14  vmovaps xmm10, [rsp+0x90]
000073dfa87e2b1d  vmovaps xmm11, [rsp+0xA0]
000073dfa87e2b26  vmovaps xmm12, [rsp+0xB0]
000073dfa87e2b2f  vmovaps xmm13, [rsp+0xC0]
000073dfa87e2b38  vmovaps xmm14, [rsp+0xD0]
000073dfa87e2b41  vmovaps xmm15, [rsp+0xE0]
000073dfa87e2b4a  add rsp, 0xF0
000073dfa87e2b51  pop r11
000073dfa87e2b53  pop r10
000073dfa87e2b55  pop r9
000073dfa87e2b57  pop r8
000073dfa87e2b59  pop rsi
000073dfa87e2b5a  pop rdi
000073dfa87e2b5b  pop rdx
000073dfa87e2b5c  pop rcx
000073dfa87e2b5d  pop rax
000073dfa87e2b5e  add rsp, 0x08
000073dfa87e2b62  jmp 0x000073DFA87DF61D
000073dfa87e2b67  sub rsp, 0x08
000073dfa87e2b6b  push rax
000073dfa87e2b6c  push rcx
000073dfa87e2b6d  push rdx
000073dfa87e2b6e  push rdi
000073dfa87e2b6f  push rsi
000073dfa87e2b70  push r8
000073dfa87e2b72  push r9
000073dfa87e2b74  push r10
000073dfa87e2b76  push r11
000073dfa87e2b78  sub rsp, 0xF0
000073dfa87e2b7f  vmovaps [rsp], xmm0
000073dfa87e2b84  vmovaps [rsp+0x10], xmm1
000073dfa87e2b8a  vmovaps [rsp+0x20], xmm2
000073dfa87e2b90  vmovaps [rsp+0x30], xmm3
000073dfa87e2b96  vmovaps [rsp+0x40], xmm4
000073dfa87e2b9c  vmovaps [rsp+0x50], xmm5
000073dfa87e2ba2  vmovaps [rsp+0x60], xmm6
000073dfa87e2ba8  vmovaps [rsp+0x70], xmm7
000073dfa87e2bae  vmovaps [rsp+0x80], xmm8
000073dfa87e2bb7  vmovaps [rsp+0x90], xmm9
000073dfa87e2bc0  vmovaps [rsp+0xA0], xmm10
000073dfa87e2bc9  vmovaps [rsp+0xB0], xmm11
000073dfa87e2bd2  vmovaps [rsp+0xC0], xmm12
000073dfa87e2bdb  vmovaps [rsp+0xD0], xmm14
000073dfa87e2be4  vmovaps [rsp+0xE0], xmm15
000073dfa87e2bed  sub rsp, 0x30
000073dfa87e2bf1  movaps [rsp], xmm13
000073dfa87e2bf6  movaps [rsp+0x10], xmm15
000073dfa87e2bfc  movaps [rsp+0x20], xmm9
000073dfa87e2c02  lea rdi, [rsp]
000073dfa87e2c06  mov esi, 0x00
000073dfa87e2c0b  mov rax, 0x593AA1DA4530
000073dfa87e2c15  call rax
000073dfa87e2c17  movaps xmm13, [rsp]
000073dfa87e2c1c  add rsp, 0x30
000073dfa87e2c20  vmovaps xmm0, [rsp]
000073dfa87e2c25  vmovaps xmm1, [rsp+0x10]
000073dfa87e2c2b  vmovaps xmm2, [rsp+0x20]
000073dfa87e2c31  vmovaps xmm3, [rsp+0x30]
000073dfa87e2c37  vmovaps xmm4, [rsp+0x40]
000073dfa87e2c3d  vmovaps xmm5, [rsp+0x50]
000073dfa87e2c43  vmovaps xmm6, [rsp+0x60]
000073dfa87e2c49  vmovaps xmm7, [rsp+0x70]
000073dfa87e2c4f  vmovaps xmm8, [rsp+0x80]
000073dfa87e2c58  vmovaps xmm9, [rsp+0x90]
000073dfa87e2c61  vmovaps xmm10, [rsp+0xA0]
000073dfa87e2c6a  vmovaps xmm11, [rsp+0xB0]
000073dfa87e2c73  vmovaps xmm12, [rsp+0xC0]
000073dfa87e2c7c  vmovaps xmm14, [rsp+0xD0]
000073dfa87e2c85  vmovaps xmm15, [rsp+0xE0]
000073dfa87e2c8e  add rsp, 0xF0
000073dfa87e2c95  pop r11
000073dfa87e2c97  pop r10
000073dfa87e2c99  pop r9
000073dfa87e2c9b  pop r8
000073dfa87e2c9d  pop rsi
000073dfa87e2c9e  pop rdi
000073dfa87e2c9f  pop rdx
000073dfa87e2ca0  pop rcx
000073dfa87e2ca1  pop rax
000073dfa87e2ca2  add rsp, 0x08
000073dfa87e2ca6  jmp 0x000073DFA87DF638
000073dfa87e2cab  sub rsp, 0x08
000073dfa87e2caf  push rax
000073dfa87e2cb0  push rcx
000073dfa87e2cb1  push rdx
000073dfa87e2cb2  push rdi
000073dfa87e2cb3  push rsi
000073dfa87e2cb4  push r8
000073dfa87e2cb6  push r9
000073dfa87e2cb8  push r10
000073dfa87e2cba  push r11
000073dfa87e2cbc  sub rsp, 0xF0
000073dfa87e2cc3  vmovaps [rsp], xmm0
000073dfa87e2cc8  vmovaps [rsp+0x10], xmm1
000073dfa87e2cce  vmovaps [rsp+0x20], xmm2
000073dfa87e2cd4  vmovaps [rsp+0x30], xmm3
000073dfa87e2cda  vmovaps [rsp+0x40], xmm4
000073dfa87e2ce0  vmovaps [rsp+0x50], xmm5
000073dfa87e2ce6  vmovaps [rsp+0x60], xmm6
000073dfa87e2cec  vmovaps [rsp+0x70], xmm7
000073dfa87e2cf2  vmovaps [rsp+0x80], xmm8
000073dfa87e2cfb  vmovaps [rsp+0x90], xmm9
000073dfa87e2d04  vmovaps [rsp+0xA0], xmm10
000073dfa87e2d0d  vmovaps [rsp+0xB0], xmm11
000073dfa87e2d16  vmovaps [rsp+0xC0], xmm12
000073dfa87e2d1f  vmovaps [rsp+0xD0], xmm13
000073dfa87e2d28  vmovaps [rsp+0xE0], xmm14
000073dfa87e2d31  sub rsp, 0x30
000073dfa87e2d35  movaps [rsp], xmm15
000073dfa87e2d3a  movaps [rsp+0x10], xmm1
000073dfa87e2d3f  movaps [rsp+0x20], xmm5
000073dfa87e2d44  lea rdi, [rsp]
000073dfa87e2d48  mov esi, 0x00
000073dfa87e2d4d  mov rax, 0x593AA1DA4530
000073dfa87e2d57  call rax
000073dfa87e2d59  movaps xmm15, [rsp]
000073dfa87e2d5e  add rsp, 0x30
000073dfa87e2d62  vmovaps xmm0, [rsp]
000073dfa87e2d67  vmovaps xmm1, [rsp+0x10]
000073dfa87e2d6d  vmovaps xmm2, [rsp+0x20]
000073dfa87e2d73  vmovaps xmm3, [rsp+0x30]
000073dfa87e2d79  vmovaps xmm4, [rsp+0x40]
000073dfa87e2d7f  vmovaps xmm5, [rsp+0x50]
000073dfa87e2d85  vmovaps xmm6, [rsp+0x60]
000073dfa87e2d8b  vmovaps xmm7, [rsp+0x70]
000073dfa87e2d91  vmovaps xmm8, [rsp+0x80]
000073dfa87e2d9a  vmovaps xmm9, [rsp+0x90]
000073dfa87e2da3  vmovaps xmm10, [rsp+0xA0]
000073dfa87e2dac  vmovaps xmm11, [rsp+0xB0]
000073dfa87e2db5  vmovaps xmm12, [rsp+0xC0]
000073dfa87e2dbe  vmovaps xmm13, [rsp+0xD0]
000073dfa87e2dc7  vmovaps xmm14, [rsp+0xE0]
000073dfa87e2dd0  add rsp, 0xF0
000073dfa87e2dd7  pop r11
000073dfa87e2dd9  pop r10
000073dfa87e2ddb  pop r9
000073dfa87e2ddd  pop r8
000073dfa87e2ddf  pop rsi
000073dfa87e2de0  pop rdi
000073dfa87e2de1  pop rdx
000073dfa87e2de2  pop rcx
000073dfa87e2de3  pop rax
000073dfa87e2de4  add rsp, 0x08
000073dfa87e2de8  jmp 0x000073DFA87DF653
000073dfa87e2ded  call 0x000073DFA86B52F0
000073dfa87e2df2  jmp 0x000073DFA87DF6AE
000073dfa87e2df7  sub rsp, 0x08
000073dfa87e2dfb  push rax
000073dfa87e2dfc  push rcx
000073dfa87e2dfd  push rdx
000073dfa87e2dfe  push rdi
000073dfa87e2dff  push rsi
000073dfa87e2e00  push r8
000073dfa87e2e02  push r9
000073dfa87e2e04  push r10
000073dfa87e2e06  push r11
000073dfa87e2e08  sub rsp, 0xF0
000073dfa87e2e0f  vmovaps [rsp], xmm0
000073dfa87e2e14  vmovaps [rsp+0x10], xmm1
000073dfa87e2e1a  vmovaps [rsp+0x20], xmm2
000073dfa87e2e20  vmovaps [rsp+0x30], xmm3
000073dfa87e2e26  vmovaps [rsp+0x40], xmm4
000073dfa87e2e2c  vmovaps [rsp+0x50], xmm5
000073dfa87e2e32  vmovaps [rsp+0x60], xmm6
000073dfa87e2e38  vmovaps [rsp+0x70], xmm7
000073dfa87e2e3e  vmovaps [rsp+0x80], xmm8
000073dfa87e2e47  vmovaps [rsp+0x90], xmm10
000073dfa87e2e50  vmovaps [rsp+0xA0], xmm11
000073dfa87e2e59  vmovaps [rsp+0xB0], xmm12
000073dfa87e2e62  vmovaps [rsp+0xC0], xmm13
000073dfa87e2e6b  vmovaps [rsp+0xD0], xmm14
000073dfa87e2e74  vmovaps [rsp+0xE0], xmm15
000073dfa87e2e7d  sub rsp, 0x30
000073dfa87e2e81  movaps [rsp], xmm9
000073dfa87e2e86  movaps [rsp+0x10], xmm8
000073dfa87e2e8c  movaps [rsp+0x20], xmm11
000073dfa87e2e92  lea rdi, [rsp]
000073dfa87e2e96  mov esi, 0x00
000073dfa87e2e9b  mov rax, 0x593AA1DA4530
000073dfa87e2ea5  call rax
000073dfa87e2ea7  movaps xmm9, [rsp]
000073dfa87e2eac  add rsp, 0x30
000073dfa87e2eb0  vmovaps xmm0, [rsp]
000073dfa87e2eb5  vmovaps xmm1, [rsp+0x10]
000073dfa87e2ebb  vmovaps xmm2, [rsp+0x20]
000073dfa87e2ec1  vmovaps xmm3, [rsp+0x30]
000073dfa87e2ec7  vmovaps xmm4, [rsp+0x40]
000073dfa87e2ecd  vmovaps xmm5, [rsp+0x50]
000073dfa87e2ed3  vmovaps xmm6, [rsp+0x60]
000073dfa87e2ed9  vmovaps xmm7, [rsp+0x70]
000073dfa87e2edf  vmovaps xmm8, [rsp+0x80]
000073dfa87e2ee8  vmovaps xmm10, [rsp+0x90]
000073dfa87e2ef1  vmovaps xmm11, [rsp+0xA0]
000073dfa87e2efa  vmovaps xmm12, [rsp+0xB0]
000073dfa87e2f03  vmovaps xmm13, [rsp+0xC0]
000073dfa87e2f0c  vmovaps xmm14, [rsp+0xD0]
000073dfa87e2f15  vmovaps xmm15, [rsp+0xE0]
000073dfa87e2f1e  add rsp, 0xF0
000073dfa87e2f25  pop r11
000073dfa87e2f27  pop r10
000073dfa87e2f29  pop r9
000073dfa87e2f2b  pop r8
000073dfa87e2f2d  pop rsi
000073dfa87e2f2e  pop rdi
000073dfa87e2f2f  pop rdx
000073dfa87e2f30  pop rcx
000073dfa87e2f31  pop rax
000073dfa87e2f32  add rsp, 0x08
000073dfa87e2f36  jmp 0x000073DFA87DF6E5
000073dfa87e2f3b  sub rsp, 0x08
000073dfa87e2f3f  push rax
000073dfa87e2f40  push rcx
000073dfa87e2f41  push rdx
000073dfa87e2f42  push rdi
000073dfa87e2f43  push rsi
000073dfa87e2f44  push r8
000073dfa87e2f46  push r9
000073dfa87e2f48  push r10
000073dfa87e2f4a  push r11
000073dfa87e2f4c  sub rsp, 0xF0
000073dfa87e2f53  vmovaps [rsp], xmm0
000073dfa87e2f58  vmovaps [rsp+0x10], xmm1
000073dfa87e2f5e  vmovaps [rsp+0x20], xmm2
000073dfa87e2f64  vmovaps [rsp+0x30], xmm3
000073dfa87e2f6a  vmovaps [rsp+0x40], xmm4
000073dfa87e2f70  vmovaps [rsp+0x50], xmm5
000073dfa87e2f76  vmovaps [rsp+0x60], xmm6
000073dfa87e2f7c  vmovaps [rsp+0x70], xmm7
000073dfa87e2f82  vmovaps [rsp+0x80], xmm8
000073dfa87e2f8b  vmovaps [rsp+0x90], xmm9
000073dfa87e2f94  vmovaps [rsp+0xA0], xmm10
000073dfa87e2f9d  vmovaps [rsp+0xB0], xmm12
000073dfa87e2fa6  vmovaps [rsp+0xC0], xmm13
000073dfa87e2faf  vmovaps [rsp+0xD0], xmm14
000073dfa87e2fb8  vmovaps [rsp+0xE0], xmm15
000073dfa87e2fc1  sub rsp, 0x30
000073dfa87e2fc5  movaps [rsp], xmm11
000073dfa87e2fca  movaps [rsp+0x10], xmm10
000073dfa87e2fd0  movaps [rsp+0x20], xmm6
000073dfa87e2fd5  lea rdi, [rsp]
000073dfa87e2fd9  mov esi, 0x00
000073dfa87e2fde  mov rax, 0x593AA1DA4530
000073dfa87e2fe8  call rax
000073dfa87e2fea  movaps xmm11, [rsp]
000073dfa87e2fef  add rsp, 0x30
000073dfa87e2ff3  vmovaps xmm0, [rsp]
000073dfa87e2ff8  vmovaps xmm1, [rsp+0x10]
000073dfa87e2ffe  vmovaps xmm2, [rsp+0x20]
000073dfa87e3004  vmovaps xmm3, [rsp+0x30]
000073dfa87e300a  vmovaps xmm4, [rsp+0x40]
000073dfa87e3010  vmovaps xmm5, [rsp+0x50]
000073dfa87e3016  vmovaps xmm6, [rsp+0x60]
000073dfa87e301c  vmovaps xmm7, [rsp+0x70]
000073dfa87e3022  vmovaps xmm8, [rsp+0x80]
000073dfa87e302b  vmovaps xmm9, [rsp+0x90]
000073dfa87e3034  vmovaps xmm10, [rsp+0xA0]
000073dfa87e303d  vmovaps xmm12, [rsp+0xB0]
000073dfa87e3046  vmovaps xmm13, [rsp+0xC0]
000073dfa87e304f  vmovaps xmm14, [rsp+0xD0]
000073dfa87e3058  vmovaps xmm15, [rsp+0xE0]
000073dfa87e3061  add rsp, 0xF0
000073dfa87e3068  pop r11
000073dfa87e306a  pop r10
000073dfa87e306c  pop r9
000073dfa87e306e  pop r8
000073dfa87e3070  pop rsi
000073dfa87e3071  pop rdi
000073dfa87e3072  pop rdx
000073dfa87e3073  pop rcx
000073dfa87e3074  pop rax
000073dfa87e3075  add rsp, 0x08
000073dfa87e3079  jmp 0x000073DFA87DF700
000073dfa87e307e  sub rsp, 0x08
000073dfa87e3082  push rax
000073dfa87e3083  push rcx
000073dfa87e3084  push rdx
000073dfa87e3085  push rdi
000073dfa87e3086  push rsi
000073dfa87e3087  push r8
000073dfa87e3089  push r9
000073dfa87e308b  push r10
000073dfa87e308d  push r11
000073dfa87e308f  sub rsp, 0xF0
000073dfa87e3096  vmovaps [rsp], xmm0
000073dfa87e309b  vmovaps [rsp+0x10], xmm1
000073dfa87e30a1  vmovaps [rsp+0x20], xmm2
000073dfa87e30a7  vmovaps [rsp+0x30], xmm3
000073dfa87e30ad  vmovaps [rsp+0x40], xmm4
000073dfa87e30b3  vmovaps [rsp+0x50], xmm5
000073dfa87e30b9  vmovaps [rsp+0x60], xmm6
000073dfa87e30bf  vmovaps [rsp+0x70], xmm7
000073dfa87e30c5  vmovaps [rsp+0x80], xmm8
000073dfa87e30ce  vmovaps [rsp+0x90], xmm9
000073dfa87e30d7  vmovaps [rsp+0xA0], xmm11
000073dfa87e30e0  vmovaps [rsp+0xB0], xmm12
000073dfa87e30e9  vmovaps [rsp+0xC0], xmm13
000073dfa87e30f2  vmovaps [rsp+0xD0], xmm14
000073dfa87e30fb  vmovaps [rsp+0xE0], xmm15
000073dfa87e3104  sub rsp, 0x30
000073dfa87e3108  movaps [rsp], xmm10
000073dfa87e310d  movaps [rsp+0x10], xmm14
000073dfa87e3113  movaps [rsp+0x20], xmm4
000073dfa87e3118  lea rdi, [rsp]
000073dfa87e311c  mov esi, 0x00
000073dfa87e3121  mov rax, 0x593AA1DA4530
000073dfa87e312b  call rax
000073dfa87e312d  movaps xmm10, [rsp]
000073dfa87e3132  add rsp, 0x30
000073dfa87e3136  vmovaps xmm0, [rsp]
000073dfa87e313b  vmovaps xmm1, [rsp+0x10]
000073dfa87e3141  vmovaps xmm2, [rsp+0x20]
000073dfa87e3147  vmovaps xmm3, [rsp+0x30]
000073dfa87e314d  vmovaps xmm4, [rsp+0x40]
000073dfa87e3153  vmovaps xmm5, [rsp+0x50]
000073dfa87e3159  vmovaps xmm6, [rsp+0x60]
000073dfa87e315f  vmovaps xmm7, [rsp+0x70]
000073dfa87e3165  vmovaps xmm8, [rsp+0x80]
000073dfa87e316e  vmovaps xmm9, [rsp+0x90]
000073dfa87e3177  vmovaps xmm11, [rsp+0xA0]
000073dfa87e3180  vmovaps xmm12, [rsp+0xB0]
000073dfa87e3189  vmovaps xmm13, [rsp+0xC0]
000073dfa87e3192  vmovaps xmm14, [rsp+0xD0]
000073dfa87e319b  vmovaps xmm15, [rsp+0xE0]
000073dfa87e31a4  add rsp, 0xF0
000073dfa87e31ab  pop r11
000073dfa87e31ad  pop r10
000073dfa87e31af  pop r9
000073dfa87e31b1  pop r8
000073dfa87e31b3  pop rsi
000073dfa87e31b4  pop rdi
000073dfa87e31b5  pop rdx
000073dfa87e31b6  pop rcx
000073dfa87e31b7  pop rax
000073dfa87e31b8  add rsp, 0x08
000073dfa87e31bc  jmp 0x000073DFA87DF71B
000073dfa87e31c1  sub rsp, 0x08
000073dfa87e31c5  push rax
000073dfa87e31c6  push rcx
000073dfa87e31c7  push rdx
000073dfa87e31c8  push rdi
000073dfa87e31c9  push rsi
000073dfa87e31ca  push r8
000073dfa87e31cc  push r9
000073dfa87e31ce  push r10
000073dfa87e31d0  push r11
000073dfa87e31d2  sub rsp, 0xF0
000073dfa87e31d9  vmovaps [rsp], xmm0
000073dfa87e31de  vmovaps [rsp+0x10], xmm1
000073dfa87e31e4  vmovaps [rsp+0x20], xmm2
000073dfa87e31ea  vmovaps [rsp+0x30], xmm3
000073dfa87e31f0  vmovaps [rsp+0x40], xmm4
000073dfa87e31f6  vmovaps [rsp+0x50], xmm5
000073dfa87e31fc  vmovaps [rsp+0x60], xmm6
000073dfa87e3202  vmovaps [rsp+0x70], xmm7
000073dfa87e3208  vmovaps [rsp+0x80], xmm9
000073dfa87e3211  vmovaps [rsp+0x90], xmm10
000073dfa87e321a  vmovaps [rsp+0xA0], xmm11
000073dfa87e3223  vmovaps [rsp+0xB0], xmm12
000073dfa87e322c  vmovaps [rsp+0xC0], xmm13
000073dfa87e3235  vmovaps [rsp+0xD0], xmm14
000073dfa87e323e  vmovaps [rsp+0xE0], xmm15
000073dfa87e3247  sub rsp, 0x30
000073dfa87e324b  movaps [rsp], xmm8
000073dfa87e3250  movaps [rsp+0x10], xmm1
000073dfa87e3255  movaps [rsp+0x20], xmm14
000073dfa87e325b  lea rdi, [rsp]
000073dfa87e325f  mov esi, 0x00
000073dfa87e3264  mov rax, 0x593AA1DA4530
000073dfa87e326e  call rax
000073dfa87e3270  movaps xmm8, [rsp]
000073dfa87e3275  add rsp, 0x30
000073dfa87e3279  vmovaps xmm0, [rsp]
000073dfa87e327e  vmovaps xmm1, [rsp+0x10]
000073dfa87e3284  vmovaps xmm2, [rsp+0x20]
000073dfa87e328a  vmovaps xmm3, [rsp+0x30]
000073dfa87e3290  vmovaps xmm4, [rsp+0x40]
000073dfa87e3296  vmovaps xmm5, [rsp+0x50]
000073dfa87e329c  vmovaps xmm6, [rsp+0x60]
000073dfa87e32a2  vmovaps xmm7, [rsp+0x70]
000073dfa87e32a8  vmovaps xmm9, [rsp+0x80]
000073dfa87e32b1  vmovaps xmm10, [rsp+0x90]
000073dfa87e32ba  vmovaps xmm11, [rsp+0xA0]
000073dfa87e32c3  vmovaps xmm12, [rsp+0xB0]
000073dfa87e32cc  vmovaps xmm13, [rsp+0xC0]
000073dfa87e32d5  vmovaps xmm14, [rsp+0xD0]
000073dfa87e32de  vmovaps xmm15, [rsp+0xE0]
000073dfa87e32e7  add rsp, 0xF0
000073dfa87e32ee  pop r11
000073dfa87e32f0  pop r10
000073dfa87e32f2  pop r9
000073dfa87e32f4  pop r8
000073dfa87e32f6  pop rsi
000073dfa87e32f7  pop rdi
000073dfa87e32f8  pop rdx
000073dfa87e32f9  pop rcx
000073dfa87e32fa  pop rax
000073dfa87e32fb  add rsp, 0x08
000073dfa87e32ff  jmp 0x000073DFA87DF741
000073dfa87e3304  sub rsp, 0x08
000073dfa87e3308  push rax
000073dfa87e3309  push rcx
000073dfa87e330a  push rdx
000073dfa87e330b  push rdi
000073dfa87e330c  push rsi
000073dfa87e330d  push r8
000073dfa87e330f  push r9
000073dfa87e3311  push r10
000073dfa87e3313  push r11
000073dfa87e3315  sub rsp, 0xF0
000073dfa87e331c  vmovaps [rsp], xmm0
000073dfa87e3321  vmovaps [rsp+0x10], xmm1
000073dfa87e3327  vmovaps [rsp+0x20], xmm2
000073dfa87e332d  vmovaps [rsp+0x30], xmm3
000073dfa87e3333  vmovaps [rsp+0x40], xmm4
000073dfa87e3339  vmovaps [rsp+0x50], xmm5
000073dfa87e333f  vmovaps [rsp+0x60], xmm7
000073dfa87e3345  vmovaps [rsp+0x70], xmm8
000073dfa87e334b  vmovaps [rsp+0x80], xmm9
000073dfa87e3354  vmovaps [rsp+0x90], xmm10
000073dfa87e335d  vmovaps [rsp+0xA0], xmm11
000073dfa87e3366  vmovaps [rsp+0xB0], xmm12
000073dfa87e336f  vmovaps [rsp+0xC0], xmm13
000073dfa87e3378  vmovaps [rsp+0xD0], xmm14
000073dfa87e3381  vmovaps [rsp+0xE0], xmm15
000073dfa87e338a  sub rsp, 0x30
000073dfa87e338e  movaps [rsp], xmm6
000073dfa87e3392  movaps [rsp+0x10], xmm1
000073dfa87e3397  movaps [rsp+0x20], xmm14
000073dfa87e339d  lea rdi, [rsp]
000073dfa87e33a1  mov esi, 0x00
000073dfa87e33a6  mov rax, 0x593AA1DA4530
000073dfa87e33b0  call rax
000073dfa87e33b2  movaps xmm6, [rsp]
000073dfa87e33b6  add rsp, 0x30
000073dfa87e33ba  vmovaps xmm0, [rsp]
000073dfa87e33bf  vmovaps xmm1, [rsp+0x10]
000073dfa87e33c5  vmovaps xmm2, [rsp+0x20]
000073dfa87e33cb  vmovaps xmm3, [rsp+0x30]
000073dfa87e33d1  vmovaps xmm4, [rsp+0x40]
000073dfa87e33d7  vmovaps xmm5, [rsp+0x50]
000073dfa87e33dd  vmovaps xmm7, [rsp+0x60]
000073dfa87e33e3  vmovaps xmm8, [rsp+0x70]
000073dfa87e33e9  vmovaps xmm9, [rsp+0x80]
000073dfa87e33f2  vmovaps xmm10, [rsp+0x90]
000073dfa87e33fb  vmovaps xmm11, [rsp+0xA0]
000073dfa87e3404  vmovaps xmm12, [rsp+0xB0]
000073dfa87e340d  vmovaps xmm13, [rsp+0xC0]
000073dfa87e3416  vmovaps xmm14, [rsp+0xD0]
000073dfa87e341f  vmovaps xmm15, [rsp+0xE0]
000073dfa87e3428  add rsp, 0xF0
000073dfa87e342f  pop r11
000073dfa87e3431  pop r10
000073dfa87e3433  pop r9
000073dfa87e3435  pop r8
000073dfa87e3437  pop rsi
000073dfa87e3438  pop rdi
000073dfa87e3439  pop rdx
000073dfa87e343a  pop rcx
000073dfa87e343b  pop rax
000073dfa87e343c  add rsp, 0x08
000073dfa87e3440  jmp 0x000073DFA87DF76D
000073dfa87e3445  sub rsp, 0x08
000073dfa87e3449  push rax
000073dfa87e344a  push rcx
000073dfa87e344b  push rdx
000073dfa87e344c  push rdi
000073dfa87e344d  push rsi
000073dfa87e344e  push r8
000073dfa87e3450  push r9
000073dfa87e3452  push r10
000073dfa87e3454  push r11
000073dfa87e3456  sub rsp, 0xF0
000073dfa87e345d  vmovaps [rsp], xmm0
000073dfa87e3462  vmovaps [rsp+0x10], xmm1
000073dfa87e3468  vmovaps [rsp+0x20], xmm2
000073dfa87e346e  vmovaps [rsp+0x30], xmm3
000073dfa87e3474  vmovaps [rsp+0x40], xmm4
000073dfa87e347a  vmovaps [rsp+0x50], xmm5
000073dfa87e3480  vmovaps [rsp+0x60], xmm6
000073dfa87e3486  vmovaps [rsp+0x70], xmm7
000073dfa87e348c  vmovaps [rsp+0x80], xmm8
000073dfa87e3495  vmovaps [rsp+0x90], xmm9
000073dfa87e349e  vmovaps [rsp+0xA0], xmm10
000073dfa87e34a7  vmovaps [rsp+0xB0], xmm11
000073dfa87e34b0  vmovaps [rsp+0xC0], xmm12
000073dfa87e34b9  vmovaps [rsp+0xD0], xmm13
000073dfa87e34c2  vmovaps [rsp+0xE0], xmm15
000073dfa87e34cb  sub rsp, 0x30
000073dfa87e34cf  movaps [rsp], xmm14
000073dfa87e34d4  movaps [rsp+0x10], xmm12
000073dfa87e34da  movaps [rsp+0x20], xmm1
000073dfa87e34df  lea rdi, [rsp]
000073dfa87e34e3  mov esi, 0x00
000073dfa87e34e8  mov rax, 0x593AA1DA4530
000073dfa87e34f2  call rax
000073dfa87e34f4  movaps xmm14, [rsp]
000073dfa87e34f9  add rsp, 0x30
000073dfa87e34fd  vmovaps xmm0, [rsp]
000073dfa87e3502  vmovaps xmm1, [rsp+0x10]
000073dfa87e3508  vmovaps xmm2, [rsp+0x20]
000073dfa87e350e  vmovaps xmm3, [rsp+0x30]
000073dfa87e3514  vmovaps xmm4, [rsp+0x40]
000073dfa87e351a  vmovaps xmm5, [rsp+0x50]
000073dfa87e3520  vmovaps xmm6, [rsp+0x60]
000073dfa87e3526  vmovaps xmm7, [rsp+0x70]
000073dfa87e352c  vmovaps xmm8, [rsp+0x80]
000073dfa87e3535  vmovaps xmm9, [rsp+0x90]
000073dfa87e353e  vmovaps xmm10, [rsp+0xA0]
000073dfa87e3547  vmovaps xmm11, [rsp+0xB0]
000073dfa87e3550  vmovaps xmm12, [rsp+0xC0]
000073dfa87e3559  vmovaps xmm13, [rsp+0xD0]
000073dfa87e3562  vmovaps xmm15, [rsp+0xE0]
000073dfa87e356b  add rsp, 0xF0
000073dfa87e3572  pop r11
000073dfa87e3574  pop r10
000073dfa87e3576  pop r9
000073dfa87e3578  pop r8
000073dfa87e357a  pop rsi
000073dfa87e357b  pop rdi
000073dfa87e357c  pop rdx
000073dfa87e357d  pop rcx
000073dfa87e357e  pop rax
000073dfa87e357f  add rsp, 0x08
000073dfa87e3583  jmp 0x000073DFA87DF793
000073dfa87e3588  sub rsp, 0x08
000073dfa87e358c  push rax
000073dfa87e358d  push rcx
000073dfa87e358e  push rdx
000073dfa87e358f  push rdi
000073dfa87e3590  push rsi
000073dfa87e3591  push r8
000073dfa87e3593  push r9
000073dfa87e3595  push r10
000073dfa87e3597  push r11
000073dfa87e3599  sub rsp, 0xF0
000073dfa87e35a0  vmovaps [rsp], xmm0
000073dfa87e35a5  vmovaps [rsp+0x10], xmm2
000073dfa87e35ab  vmovaps [rsp+0x20], xmm3
000073dfa87e35b1  vmovaps [rsp+0x30], xmm4
000073dfa87e35b7  vmovaps [rsp+0x40], xmm5
000073dfa87e35bd  vmovaps [rsp+0x50], xmm6
000073dfa87e35c3  vmovaps [rsp+0x60], xmm7
000073dfa87e35c9  vmovaps [rsp+0x70], xmm8
000073dfa87e35cf  vmovaps [rsp+0x80], xmm9
000073dfa87e35d8  vmovaps [rsp+0x90], xmm10
000073dfa87e35e1  vmovaps [rsp+0xA0], xmm11
000073dfa87e35ea  vmovaps [rsp+0xB0], xmm12
000073dfa87e35f3  vmovaps [rsp+0xC0], xmm13
000073dfa87e35fc  vmovaps [rsp+0xD0], xmm14
000073dfa87e3605  vmovaps [rsp+0xE0], xmm15
000073dfa87e360e  sub rsp, 0x30
000073dfa87e3612  movaps [rsp], xmm1
000073dfa87e3616  movaps [rsp+0x10], xmm13
000073dfa87e361c  movaps [rsp+0x20], xmm9
000073dfa87e3622  lea rdi, [rsp]
000073dfa87e3626  mov esi, 0x00
000073dfa87e362b  mov rax, 0x593AA1DA4530
000073dfa87e3635  call rax
000073dfa87e3637  movaps xmm1, [rsp]
000073dfa87e363b  add rsp, 0x30
000073dfa87e363f  vmovaps xmm0, [rsp]
000073dfa87e3644  vmovaps xmm2, [rsp+0x10]
000073dfa87e364a  vmovaps xmm3, [rsp+0x20]
000073dfa87e3650  vmovaps xmm4, [rsp+0x30]
000073dfa87e3656  vmovaps xmm5, [rsp+0x40]
000073dfa87e365c  vmovaps xmm6, [rsp+0x50]
000073dfa87e3662  vmovaps xmm7, [rsp+0x60]
000073dfa87e3668  vmovaps xmm8, [rsp+0x70]
000073dfa87e366e  vmovaps xmm9, [rsp+0x80]
000073dfa87e3677  vmovaps xmm10, [rsp+0x90]
000073dfa87e3680  vmovaps xmm11, [rsp+0xA0]
000073dfa87e3689  vmovaps xmm12, [rsp+0xB0]
000073dfa87e3692  vmovaps xmm13, [rsp+0xC0]
000073dfa87e369b  vmovaps xmm14, [rsp+0xD0]
000073dfa87e36a4  vmovaps xmm15, [rsp+0xE0]
000073dfa87e36ad  add rsp, 0xF0
000073dfa87e36b4  pop r11
000073dfa87e36b6  pop r10
000073dfa87e36b8  pop r9
000073dfa87e36ba  pop r8
000073dfa87e36bc  pop rsi
000073dfa87e36bd  pop rdi
000073dfa87e36be  pop rdx
000073dfa87e36bf  pop rcx
000073dfa87e36c0  pop rax
000073dfa87e36c1  add rsp, 0x08
000073dfa87e36c5  jmp 0x000073DFA87DF7AD
000073dfa87e36ca  sub rsp, 0x08
000073dfa87e36ce  push rax
000073dfa87e36cf  push rcx
000073dfa87e36d0  push rdx
000073dfa87e36d1  push rdi
000073dfa87e36d2  push rsi
000073dfa87e36d3  push r8
000073dfa87e36d5  push r9
000073dfa87e36d7  push r10
000073dfa87e36d9  push r11
000073dfa87e36db  sub rsp, 0xF0
000073dfa87e36e2  vmovaps [rsp], xmm0
000073dfa87e36e7  vmovaps [rsp+0x10], xmm1
000073dfa87e36ed  vmovaps [rsp+0x20], xmm2
000073dfa87e36f3  vmovaps [rsp+0x30], xmm3
000073dfa87e36f9  vmovaps [rsp+0x40], xmm4
000073dfa87e36ff  vmovaps [rsp+0x50], xmm5
000073dfa87e3705  vmovaps [rsp+0x60], xmm6
000073dfa87e370b  vmovaps [rsp+0x70], xmm7
000073dfa87e3711  vmovaps [rsp+0x80], xmm8
000073dfa87e371a  vmovaps [rsp+0x90], xmm9
000073dfa87e3723  vmovaps [rsp+0xA0], xmm10
000073dfa87e372c  vmovaps [rsp+0xB0], xmm11
000073dfa87e3735  vmovaps [rsp+0xC0], xmm13
000073dfa87e373e  vmovaps [rsp+0xD0], xmm14
000073dfa87e3747  vmovaps [rsp+0xE0], xmm15
000073dfa87e3750  sub rsp, 0x30
000073dfa87e3754  movaps [rsp], xmm12
000073dfa87e3759  movaps [rsp+0x10], xmm7
000073dfa87e375e  movaps [rsp+0x20], xmm13
000073dfa87e3764  lea rdi, [rsp]
000073dfa87e3768  mov esi, 0x00
000073dfa87e376d  mov rax, 0x593AA1DA4530
000073dfa87e3777  call rax
000073dfa87e3779  movaps xmm12, [rsp]
000073dfa87e377e  add rsp, 0x30
000073dfa87e3782  vmovaps xmm0, [rsp]
000073dfa87e3787  vmovaps xmm1, [rsp+0x10]
000073dfa87e378d  vmovaps xmm2, [rsp+0x20]
000073dfa87e3793  vmovaps xmm3, [rsp+0x30]
000073dfa87e3799  vmovaps xmm4, [rsp+0x40]
000073dfa87e379f  vmovaps xmm5, [rsp+0x50]
000073dfa87e37a5  vmovaps xmm6, [rsp+0x60]
000073dfa87e37ab  vmovaps xmm7, [rsp+0x70]
000073dfa87e37b1  vmovaps xmm8, [rsp+0x80]
000073dfa87e37ba  vmovaps xmm9, [rsp+0x90]
000073dfa87e37c3  vmovaps xmm10, [rsp+0xA0]
000073dfa87e37cc  vmovaps xmm11, [rsp+0xB0]
000073dfa87e37d5  vmovaps xmm13, [rsp+0xC0]
000073dfa87e37de  vmovaps xmm14, [rsp+0xD0]
000073dfa87e37e7  vmovaps xmm15, [rsp+0xE0]
000073dfa87e37f0  add rsp, 0xF0
000073dfa87e37f7  pop r11
000073dfa87e37f9  pop r10
000073dfa87e37fb  pop r9
000073dfa87e37fd  pop r8
000073dfa87e37ff  pop rsi
000073dfa87e3800  pop rdi
000073dfa87e3801  pop rdx
000073dfa87e3802  pop rcx
000073dfa87e3803  pop rax
000073dfa87e3804  add rsp, 0x08
000073dfa87e3808  jmp 0x000073DFA87DF7D4
000073dfa87e380d  sub rsp, 0x08
000073dfa87e3811  push rax
000073dfa87e3812  push rcx
000073dfa87e3813  push rdx
000073dfa87e3814  push rdi
000073dfa87e3815  push rsi
000073dfa87e3816  push r8
000073dfa87e3818  push r9
000073dfa87e381a  push r10
000073dfa87e381c  push r11
000073dfa87e381e  sub rsp, 0xF0
000073dfa87e3825  vmovaps [rsp], xmm0
000073dfa87e382a  vmovaps [rsp+0x10], xmm1
000073dfa87e3830  vmovaps [rsp+0x20], xmm2
000073dfa87e3836  vmovaps [rsp+0x30], xmm3
000073dfa87e383c  vmovaps [rsp+0x40], xmm4
000073dfa87e3842  vmovaps [rsp+0x50], xmm5
000073dfa87e3848  vmovaps [rsp+0x60], xmm6
000073dfa87e384e  vmovaps [rsp+0x70], xmm7
000073dfa87e3854  vmovaps [rsp+0x80], xmm8
000073dfa87e385d  vmovaps [rsp+0x90], xmm9
000073dfa87e3866  vmovaps [rsp+0xA0], xmm10
000073dfa87e386f  vmovaps [rsp+0xB0], xmm11
000073dfa87e3878  vmovaps [rsp+0xC0], xmm12
000073dfa87e3881  vmovaps [rsp+0xD0], xmm14
000073dfa87e388a  vmovaps [rsp+0xE0], xmm15
000073dfa87e3893  sub rsp, 0x30
000073dfa87e3897  movaps [rsp], xmm13
000073dfa87e389c  movaps [rsp+0x10], xmm15
000073dfa87e38a2  movaps [rsp+0x20], xmm8
000073dfa87e38a8  lea rdi, [rsp]
000073dfa87e38ac  mov esi, 0x00
000073dfa87e38b1  mov rax, 0x593AA1DA4530
000073dfa87e38bb  call rax
000073dfa87e38bd  movaps xmm13, [rsp]
000073dfa87e38c2  add rsp, 0x30
000073dfa87e38c6  vmovaps xmm0, [rsp]
000073dfa87e38cb  vmovaps xmm1, [rsp+0x10]
000073dfa87e38d1  vmovaps xmm2, [rsp+0x20]
000073dfa87e38d7  vmovaps xmm3, [rsp+0x30]
000073dfa87e38dd  vmovaps xmm4, [rsp+0x40]
000073dfa87e38e3  vmovaps xmm5, [rsp+0x50]
000073dfa87e38e9  vmovaps xmm6, [rsp+0x60]
000073dfa87e38ef  vmovaps xmm7, [rsp+0x70]
000073dfa87e38f5  vmovaps xmm8, [rsp+0x80]
000073dfa87e38fe  vmovaps xmm9, [rsp+0x90]
000073dfa87e3907  vmovaps xmm10, [rsp+0xA0]
000073dfa87e3910  vmovaps xmm11, [rsp+0xB0]
000073dfa87e3919  vmovaps xmm12, [rsp+0xC0]
000073dfa87e3922  vmovaps xmm14, [rsp+0xD0]
000073dfa87e392b  vmovaps xmm15, [rsp+0xE0]
000073dfa87e3934  add rsp, 0xF0
000073dfa87e393b  pop r11
000073dfa87e393d  pop r10
000073dfa87e393f  pop r9
000073dfa87e3941  pop r8
000073dfa87e3943  pop rsi
000073dfa87e3944  pop rdi
000073dfa87e3945  pop rdx
000073dfa87e3946  pop rcx
000073dfa87e3947  pop rax
000073dfa87e3948  add rsp, 0x08
000073dfa87e394c  jmp 0x000073DFA87DF7EF
000073dfa87e3951  sub rsp, 0x08
000073dfa87e3955  push rax
000073dfa87e3956  push rcx
000073dfa87e3957  push rdx
000073dfa87e3958  push rdi
000073dfa87e3959  push rsi
000073dfa87e395a  push r8
000073dfa87e395c  push r9
000073dfa87e395e  push r10
000073dfa87e3960  push r11
000073dfa87e3962  sub rsp, 0xF0
000073dfa87e3969  vmovaps [rsp], xmm0
000073dfa87e396e  vmovaps [rsp+0x10], xmm1
000073dfa87e3974  vmovaps [rsp+0x20], xmm2
000073dfa87e397a  vmovaps [rsp+0x30], xmm3
000073dfa87e3980  vmovaps [rsp+0x40], xmm4
000073dfa87e3986  vmovaps [rsp+0x50], xmm5
000073dfa87e398c  vmovaps [rsp+0x60], xmm6
000073dfa87e3992  vmovaps [rsp+0x70], xmm7
000073dfa87e3998  vmovaps [rsp+0x80], xmm9
000073dfa87e39a1  vmovaps [rsp+0x90], xmm10
000073dfa87e39aa  vmovaps [rsp+0xA0], xmm11
000073dfa87e39b3  vmovaps [rsp+0xB0], xmm12
000073dfa87e39bc  vmovaps [rsp+0xC0], xmm13
000073dfa87e39c5  vmovaps [rsp+0xD0], xmm14
000073dfa87e39ce  vmovaps [rsp+0xE0], xmm15
000073dfa87e39d7  sub rsp, 0x30
000073dfa87e39db  movaps [rsp], xmm8
000073dfa87e39e0  movaps [rsp+0x10], xmm15
000073dfa87e39e6  movaps [rsp+0x20], xmm9
000073dfa87e39ec  lea rdi, [rsp]
000073dfa87e39f0  mov esi, 0x00
000073dfa87e39f5  mov rax, 0x593AA1DA4530
000073dfa87e39ff  call rax
000073dfa87e3a01  movaps xmm8, [rsp]
000073dfa87e3a06  add rsp, 0x30
000073dfa87e3a0a  vmovaps xmm0, [rsp]
000073dfa87e3a0f  vmovaps xmm1, [rsp+0x10]
000073dfa87e3a15  vmovaps xmm2, [rsp+0x20]
000073dfa87e3a1b  vmovaps xmm3, [rsp+0x30]
000073dfa87e3a21  vmovaps xmm4, [rsp+0x40]
000073dfa87e3a27  vmovaps xmm5, [rsp+0x50]
000073dfa87e3a2d  vmovaps xmm6, [rsp+0x60]
000073dfa87e3a33  vmovaps xmm7, [rsp+0x70]
000073dfa87e3a39  vmovaps xmm9, [rsp+0x80]
000073dfa87e3a42  vmovaps xmm10, [rsp+0x90]
000073dfa87e3a4b  vmovaps xmm11, [rsp+0xA0]
000073dfa87e3a54  vmovaps xmm12, [rsp+0xB0]
000073dfa87e3a5d  vmovaps xmm13, [rsp+0xC0]
000073dfa87e3a66  vmovaps xmm14, [rsp+0xD0]
000073dfa87e3a6f  vmovaps xmm15, [rsp+0xE0]
000073dfa87e3a78  add rsp, 0xF0
000073dfa87e3a7f  pop r11
000073dfa87e3a81  pop r10
000073dfa87e3a83  pop r9
000073dfa87e3a85  pop r8
000073dfa87e3a87  pop rsi
000073dfa87e3a88  pop rdi
000073dfa87e3a89  pop rdx
000073dfa87e3a8a  pop rcx
000073dfa87e3a8b  pop rax
000073dfa87e3a8c  add rsp, 0x08
000073dfa87e3a90  jmp 0x000073DFA87DF81D
000073dfa87e3a95  sub rsp, 0x08
000073dfa87e3a99  push rax
000073dfa87e3a9a  push rcx
000073dfa87e3a9b  push rdx
000073dfa87e3a9c  push rdi
000073dfa87e3a9d  push rsi
000073dfa87e3a9e  push r8
000073dfa87e3aa0  push r9
000073dfa87e3aa2  push r10
000073dfa87e3aa4  push r11
000073dfa87e3aa6  sub rsp, 0xF0
000073dfa87e3aad  vmovaps [rsp], xmm0
000073dfa87e3ab2  vmovaps [rsp+0x10], xmm1
000073dfa87e3ab8  vmovaps [rsp+0x20], xmm2
000073dfa87e3abe  vmovaps [rsp+0x30], xmm3
000073dfa87e3ac4  vmovaps [rsp+0x40], xmm4
000073dfa87e3aca  vmovaps [rsp+0x50], xmm5
000073dfa87e3ad0  vmovaps [rsp+0x60], xmm6
000073dfa87e3ad6  vmovaps [rsp+0x70], xmm7
000073dfa87e3adc  vmovaps [rsp+0x80], xmm8
000073dfa87e3ae5  vmovaps [rsp+0x90], xmm9
000073dfa87e3aee  vmovaps [rsp+0xA0], xmm10
000073dfa87e3af7  vmovaps [rsp+0xB0], xmm11
000073dfa87e3b00  vmovaps [rsp+0xC0], xmm12
000073dfa87e3b09  vmovaps [rsp+0xD0], xmm13
000073dfa87e3b12  vmovaps [rsp+0xE0], xmm14
000073dfa87e3b1b  sub rsp, 0x30
000073dfa87e3b1f  movaps [rsp], xmm15
000073dfa87e3b24  movaps [rsp+0x10], xmm11
000073dfa87e3b2a  movaps [rsp+0x20], xmm6
000073dfa87e3b2f  lea rdi, [rsp]
000073dfa87e3b33  mov esi, 0x00
000073dfa87e3b38  mov rax, 0x593AA1DA4530
000073dfa87e3b42  call rax
000073dfa87e3b44  movaps xmm15, [rsp]
000073dfa87e3b49  add rsp, 0x30
000073dfa87e3b4d  vmovaps xmm0, [rsp]
000073dfa87e3b52  vmovaps xmm1, [rsp+0x10]
000073dfa87e3b58  vmovaps xmm2, [rsp+0x20]
000073dfa87e3b5e  vmovaps xmm3, [rsp+0x30]
000073dfa87e3b64  vmovaps xmm4, [rsp+0x40]
000073dfa87e3b6a  vmovaps xmm5, [rsp+0x50]
000073dfa87e3b70  vmovaps xmm6, [rsp+0x60]
000073dfa87e3b76  vmovaps xmm7, [rsp+0x70]
000073dfa87e3b7c  vmovaps xmm8, [rsp+0x80]
000073dfa87e3b85  vmovaps xmm9, [rsp+0x90]
000073dfa87e3b8e  vmovaps xmm10, [rsp+0xA0]
000073dfa87e3b97  vmovaps xmm11, [rsp+0xB0]
000073dfa87e3ba0  vmovaps xmm12, [rsp+0xC0]
000073dfa87e3ba9  vmovaps xmm13, [rsp+0xD0]
000073dfa87e3bb2  vmovaps xmm14, [rsp+0xE0]
000073dfa87e3bbb  add rsp, 0xF0
000073dfa87e3bc2  pop r11
000073dfa87e3bc4  pop r10
000073dfa87e3bc6  pop r9
000073dfa87e3bc8  pop r8
000073dfa87e3bca  pop rsi
000073dfa87e3bcb  pop rdi
000073dfa87e3bcc  pop rdx
000073dfa87e3bcd  pop rcx
000073dfa87e3bce  pop rax
000073dfa87e3bcf  add rsp, 0x08
000073dfa87e3bd3  jmp 0x000073DFA87DF838
000073dfa87e3bd8  sub rsp, 0x08
000073dfa87e3bdc  push rax
000073dfa87e3bdd  push rcx
000073dfa87e3bde  push rdx
000073dfa87e3bdf  push rdi
000073dfa87e3be0  push rsi
000073dfa87e3be1  push r8
000073dfa87e3be3  push r9
000073dfa87e3be5  push r10
000073dfa87e3be7  push r11
000073dfa87e3be9  sub rsp, 0xF0
000073dfa87e3bf0  vmovaps [rsp], xmm0
000073dfa87e3bf5  vmovaps [rsp+0x10], xmm1
000073dfa87e3bfb  vmovaps [rsp+0x20], xmm2
000073dfa87e3c01  vmovaps [rsp+0x30], xmm3
000073dfa87e3c07  vmovaps [rsp+0x40], xmm4
000073dfa87e3c0d  vmovaps [rsp+0x50], xmm5
000073dfa87e3c13  vmovaps [rsp+0x60], xmm6
000073dfa87e3c19  vmovaps [rsp+0x70], xmm8
000073dfa87e3c1f  vmovaps [rsp+0x80], xmm9
000073dfa87e3c28  vmovaps [rsp+0x90], xmm10
000073dfa87e3c31  vmovaps [rsp+0xA0], xmm11
000073dfa87e3c3a  vmovaps [rsp+0xB0], xmm12
000073dfa87e3c43  vmovaps [rsp+0xC0], xmm13
000073dfa87e3c4c  vmovaps [rsp+0xD0], xmm14
000073dfa87e3c55  vmovaps [rsp+0xE0], xmm15
000073dfa87e3c5e  sub rsp, 0x30
000073dfa87e3c62  movaps [rsp], xmm7
000073dfa87e3c66  movaps [rsp+0x10], xmm11
000073dfa87e3c6c  movaps [rsp+0x20], xmm9
000073dfa87e3c72  lea rdi, [rsp]
000073dfa87e3c76  mov esi, 0x00
000073dfa87e3c7b  mov rax, 0x593AA1DA4530
000073dfa87e3c85  call rax
000073dfa87e3c87  movaps xmm7, [rsp]
000073dfa87e3c8b  add rsp, 0x30
000073dfa87e3c8f  vmovaps xmm0, [rsp]
000073dfa87e3c94  vmovaps xmm1, [rsp+0x10]
000073dfa87e3c9a  vmovaps xmm2, [rsp+0x20]
000073dfa87e3ca0  vmovaps xmm3, [rsp+0x30]
000073dfa87e3ca6  vmovaps xmm4, [rsp+0x40]
000073dfa87e3cac  vmovaps xmm5, [rsp+0x50]
000073dfa87e3cb2  vmovaps xmm6, [rsp+0x60]
000073dfa87e3cb8  vmovaps xmm8, [rsp+0x70]
000073dfa87e3cbe  vmovaps xmm9, [rsp+0x80]
000073dfa87e3cc7  vmovaps xmm10, [rsp+0x90]
000073dfa87e3cd0  vmovaps xmm11, [rsp+0xA0]
000073dfa87e3cd9  vmovaps xmm12, [rsp+0xB0]
000073dfa87e3ce2  vmovaps xmm13, [rsp+0xC0]
000073dfa87e3ceb  vmovaps xmm14, [rsp+0xD0]
000073dfa87e3cf4  vmovaps xmm15, [rsp+0xE0]
000073dfa87e3cfd  add rsp, 0xF0
000073dfa87e3d04  pop r11
000073dfa87e3d06  pop r10
000073dfa87e3d08  pop r9
000073dfa87e3d0a  pop r8
000073dfa87e3d0c  pop rsi
000073dfa87e3d0d  pop rdi
000073dfa87e3d0e  pop rdx
000073dfa87e3d0f  pop rcx
000073dfa87e3d10  pop rax
000073dfa87e3d11  add rsp, 0x08
000073dfa87e3d15  jmp 0x000073DFA87DF865
000073dfa87e3d1a  sub rsp, 0x08
000073dfa87e3d1e  push rax
000073dfa87e3d1f  push rcx
000073dfa87e3d20  push rdx
000073dfa87e3d21  push rdi
000073dfa87e3d22  push rsi
000073dfa87e3d23  push r8
000073dfa87e3d25  push r9
000073dfa87e3d27  push r10
000073dfa87e3d29  push r11
000073dfa87e3d2b  sub rsp, 0xF0
000073dfa87e3d32  vmovaps [rsp], xmm0
000073dfa87e3d37  vmovaps [rsp+0x10], xmm1
000073dfa87e3d3d  vmovaps [rsp+0x20], xmm2
000073dfa87e3d43  vmovaps [rsp+0x30], xmm3
000073dfa87e3d49  vmovaps [rsp+0x40], xmm4
000073dfa87e3d4f  vmovaps [rsp+0x50], xmm5
000073dfa87e3d55  vmovaps [rsp+0x60], xmm6
000073dfa87e3d5b  vmovaps [rsp+0x70], xmm7
000073dfa87e3d61  vmovaps [rsp+0x80], xmm8
000073dfa87e3d6a  vmovaps [rsp+0x90], xmm9
000073dfa87e3d73  vmovaps [rsp+0xA0], xmm10
000073dfa87e3d7c  vmovaps [rsp+0xB0], xmm12
000073dfa87e3d85  vmovaps [rsp+0xC0], xmm13
000073dfa87e3d8e  vmovaps [rsp+0xD0], xmm14
000073dfa87e3d97  vmovaps [rsp+0xE0], xmm15
000073dfa87e3da0  sub rsp, 0x30
000073dfa87e3da4  movaps [rsp], xmm11
000073dfa87e3da9  movaps [rsp+0x10], xmm10
000073dfa87e3daf  movaps [rsp+0x20], xmm14
000073dfa87e3db5  lea rdi, [rsp]
000073dfa87e3db9  mov esi, 0x00
000073dfa87e3dbe  mov rax, 0x593AA1DA4530
000073dfa87e3dc8  call rax
000073dfa87e3dca  movaps xmm11, [rsp]
000073dfa87e3dcf  add rsp, 0x30
000073dfa87e3dd3  vmovaps xmm0, [rsp]
000073dfa87e3dd8  vmovaps xmm1, [rsp+0x10]
000073dfa87e3dde  vmovaps xmm2, [rsp+0x20]
000073dfa87e3de4  vmovaps xmm3, [rsp+0x30]
000073dfa87e3dea  vmovaps xmm4, [rsp+0x40]
000073dfa87e3df0  vmovaps xmm5, [rsp+0x50]
000073dfa87e3df6  vmovaps xmm6, [rsp+0x60]
000073dfa87e3dfc  vmovaps xmm7, [rsp+0x70]
000073dfa87e3e02  vmovaps xmm8, [rsp+0x80]
000073dfa87e3e0b  vmovaps xmm9, [rsp+0x90]
000073dfa87e3e14  vmovaps xmm10, [rsp+0xA0]
000073dfa87e3e1d  vmovaps xmm12, [rsp+0xB0]
000073dfa87e3e26  vmovaps xmm13, [rsp+0xC0]
000073dfa87e3e2f  vmovaps xmm14, [rsp+0xD0]
000073dfa87e3e38  vmovaps xmm15, [rsp+0xE0]
000073dfa87e3e41  add rsp, 0xF0
000073dfa87e3e48  pop r11
000073dfa87e3e4a  pop r10
000073dfa87e3e4c  pop r9
000073dfa87e3e4e  pop r8
000073dfa87e3e50  pop rsi
000073dfa87e3e51  pop rdi
000073dfa87e3e52  pop rdx
000073dfa87e3e53  pop rcx
000073dfa87e3e54  pop rax
000073dfa87e3e55  add rsp, 0x08
000073dfa87e3e59  jmp 0x000073DFA87DF880
000073dfa87e3e5e  call 0x000073DFA86C33A0
000073dfa87e3e63  jmp 0x000073DFA87DF88A
000073dfa87e3e68  sub rsp, 0x08
000073dfa87e3e6c  push rax
000073dfa87e3e6d  push rcx
000073dfa87e3e6e  push rdx
000073dfa87e3e6f  push rdi
000073dfa87e3e70  push rsi
000073dfa87e3e71  push r8
000073dfa87e3e73  push r9
000073dfa87e3e75  push r10
000073dfa87e3e77  push r11
000073dfa87e3e79  sub rsp, 0xF0
000073dfa87e3e80  vmovaps [rsp], xmm0
000073dfa87e3e85  vmovaps [rsp+0x10], xmm1
000073dfa87e3e8b  vmovaps [rsp+0x20], xmm2
000073dfa87e3e91  vmovaps [rsp+0x30], xmm3
000073dfa87e3e97  vmovaps [rsp+0x40], xmm4
000073dfa87e3e9d  vmovaps [rsp+0x50], xmm5
000073dfa87e3ea3  vmovaps [rsp+0x60], xmm6
000073dfa87e3ea9  vmovaps [rsp+0x70], xmm7
000073dfa87e3eaf  vmovaps [rsp+0x80], xmm8
000073dfa87e3eb8  vmovaps [rsp+0x90], xmm9
000073dfa87e3ec1  vmovaps [rsp+0xA0], xmm11
000073dfa87e3eca  vmovaps [rsp+0xB0], xmm12
000073dfa87e3ed3  vmovaps [rsp+0xC0], xmm13
000073dfa87e3edc  vmovaps [rsp+0xD0], xmm14
000073dfa87e3ee5  vmovaps [rsp+0xE0], xmm15
000073dfa87e3eee  sub rsp, 0x30
000073dfa87e3ef2  movaps [rsp], xmm10
000073dfa87e3ef7  movaps [rsp+0x10], xmm1
000073dfa87e3efc  movaps [rsp+0x20], xmm12
000073dfa87e3f02  lea rdi, [rsp]
000073dfa87e3f06  mov esi, 0x00
000073dfa87e3f0b  mov rax, 0x593AA1DA4530
000073dfa87e3f15  call rax
000073dfa87e3f17  movaps xmm10, [rsp]
000073dfa87e3f1c  add rsp, 0x30
000073dfa87e3f20  vmovaps xmm0, [rsp]
000073dfa87e3f25  vmovaps xmm1, [rsp+0x10]
000073dfa87e3f2b  vmovaps xmm2, [rsp+0x20]
000073dfa87e3f31  vmovaps xmm3, [rsp+0x30]
000073dfa87e3f37  vmovaps xmm4, [rsp+0x40]
000073dfa87e3f3d  vmovaps xmm5, [rsp+0x50]
000073dfa87e3f43  vmovaps xmm6, [rsp+0x60]
000073dfa87e3f49  vmovaps xmm7, [rsp+0x70]
000073dfa87e3f4f  vmovaps xmm8, [rsp+0x80]
000073dfa87e3f58  vmovaps xmm9, [rsp+0x90]
000073dfa87e3f61  vmovaps xmm11, [rsp+0xA0]
000073dfa87e3f6a  vmovaps xmm12, [rsp+0xB0]
000073dfa87e3f73  vmovaps xmm13, [rsp+0xC0]
000073dfa87e3f7c  vmovaps xmm14, [rsp+0xD0]
000073dfa87e3f85  vmovaps xmm15, [rsp+0xE0]
000073dfa87e3f8e  add rsp, 0xF0
000073dfa87e3f95  pop r11
000073dfa87e3f97  pop r10
000073dfa87e3f99  pop r9
000073dfa87e3f9b  pop r8
000073dfa87e3f9d  pop rsi
000073dfa87e3f9e  pop rdi
000073dfa87e3f9f  pop rdx
000073dfa87e3fa0  pop rcx
000073dfa87e3fa1  pop rax
000073dfa87e3fa2  add rsp, 0x08
000073dfa87e3fa6  jmp 0x000073DFA87DF8AD
000073dfa87e3fab  sub rsp, 0x08
000073dfa87e3faf  push rax
000073dfa87e3fb0  push rcx
000073dfa87e3fb1  push rdx
000073dfa87e3fb2  push rdi
000073dfa87e3fb3  push rsi
000073dfa87e3fb4  push r8
000073dfa87e3fb6  push r9
000073dfa87e3fb8  push r10
000073dfa87e3fba  push r11
000073dfa87e3fbc  sub rsp, 0xF0
000073dfa87e3fc3  vmovaps [rsp], xmm0
000073dfa87e3fc8  vmovaps [rsp+0x10], xmm1
000073dfa87e3fce  vmovaps [rsp+0x20], xmm2
000073dfa87e3fd4  vmovaps [rsp+0x30], xmm3
000073dfa87e3fda  vmovaps [rsp+0x40], xmm4
000073dfa87e3fe0  vmovaps [rsp+0x50], xmm5
000073dfa87e3fe6  vmovaps [rsp+0x60], xmm6
000073dfa87e3fec  vmovaps [rsp+0x70], xmm7
000073dfa87e3ff2  vmovaps [rsp+0x80], xmm8
000073dfa87e3ffb  vmovaps [rsp+0x90], xmm9
000073dfa87e4004  vmovaps [rsp+0xA0], xmm10
000073dfa87e400d  vmovaps [rsp+0xB0], xmm11
000073dfa87e4016  vmovaps [rsp+0xC0], xmm13
000073dfa87e401f  vmovaps [rsp+0xD0], xmm14
000073dfa87e4028  vmovaps [rsp+0xE0], xmm15
000073dfa87e4031  sub rsp, 0x30
000073dfa87e4035  movaps [rsp], xmm12
000073dfa87e403a  movaps [rsp+0x10], xmm14
000073dfa87e4040  movaps [rsp+0x20], xmm1
000073dfa87e4045  lea rdi, [rsp]
000073dfa87e4049  mov esi, 0x00
000073dfa87e404e  mov rax, 0x593AA1DA4530
000073dfa87e4058  call rax
000073dfa87e405a  movaps xmm12, [rsp]
000073dfa87e405f  add rsp, 0x30
000073dfa87e4063  vmovaps xmm0, [rsp]
000073dfa87e4068  vmovaps xmm1, [rsp+0x10]
000073dfa87e406e  vmovaps xmm2, [rsp+0x20]
000073dfa87e4074  vmovaps xmm3, [rsp+0x30]
000073dfa87e407a  vmovaps xmm4, [rsp+0x40]
000073dfa87e4080  vmovaps xmm5, [rsp+0x50]
000073dfa87e4086  vmovaps xmm6, [rsp+0x60]
000073dfa87e408c  vmovaps xmm7, [rsp+0x70]
000073dfa87e4092  vmovaps xmm8, [rsp+0x80]
000073dfa87e409b  vmovaps xmm9, [rsp+0x90]
000073dfa87e40a4  vmovaps xmm10, [rsp+0xA0]
000073dfa87e40ad  vmovaps xmm11, [rsp+0xB0]
000073dfa87e40b6  vmovaps xmm13, [rsp+0xC0]
000073dfa87e40bf  vmovaps xmm14, [rsp+0xD0]
000073dfa87e40c8  vmovaps xmm15, [rsp+0xE0]
000073dfa87e40d1  add rsp, 0xF0
000073dfa87e40d8  pop r11
000073dfa87e40da  pop r10
000073dfa87e40dc  pop r9
000073dfa87e40de  pop r8
000073dfa87e40e0  pop rsi
000073dfa87e40e1  pop rdi
000073dfa87e40e2  pop rdx
000073dfa87e40e3  pop rcx
000073dfa87e40e4  pop rax
000073dfa87e40e5  add rsp, 0x08
000073dfa87e40e9  jmp 0x000073DFA87DF8DC
000073dfa87e40ee  sub rsp, 0x08
000073dfa87e40f2  push rax
000073dfa87e40f3  push rcx
000073dfa87e40f4  push rdx
000073dfa87e40f5  push rdi
000073dfa87e40f6  push rsi
000073dfa87e40f7  push r8
000073dfa87e40f9  push r9
000073dfa87e40fb  push r10
000073dfa87e40fd  push r11
000073dfa87e40ff  sub rsp, 0xF0
000073dfa87e4106  vmovaps [rsp], xmm0
000073dfa87e410b  vmovaps [rsp+0x10], xmm1
000073dfa87e4111  vmovaps [rsp+0x20], xmm2
000073dfa87e4117  vmovaps [rsp+0x30], xmm3
000073dfa87e411d  vmovaps [rsp+0x40], xmm4
000073dfa87e4123  vmovaps [rsp+0x50], xmm5
000073dfa87e4129  vmovaps [rsp+0x60], xmm6
000073dfa87e412f  vmovaps [rsp+0x70], xmm7
000073dfa87e4135  vmovaps [rsp+0x80], xmm8
000073dfa87e413e  vmovaps [rsp+0x90], xmm9
000073dfa87e4147  vmovaps [rsp+0xA0], xmm10
000073dfa87e4150  vmovaps [rsp+0xB0], xmm11
000073dfa87e4159  vmovaps [rsp+0xC0], xmm12
000073dfa87e4162  vmovaps [rsp+0xD0], xmm13
000073dfa87e416b  vmovaps [rsp+0xE0], xmm15
000073dfa87e4174  sub rsp, 0x30
000073dfa87e4178  movaps [rsp], xmm14
000073dfa87e417d  movaps [rsp+0x10], xmm9
000073dfa87e4183  movaps [rsp+0x20], xmm1
000073dfa87e4188  lea rdi, [rsp]
000073dfa87e418c  mov esi, 0x00
000073dfa87e4191  mov rax, 0x593AA1DA4530
000073dfa87e419b  call rax
000073dfa87e419d  movaps xmm14, [rsp]
000073dfa87e41a2  add rsp, 0x30
000073dfa87e41a6  vmovaps xmm0, [rsp]
000073dfa87e41ab  vmovaps xmm1, [rsp+0x10]
000073dfa87e41b1  vmovaps xmm2, [rsp+0x20]
000073dfa87e41b7  vmovaps xmm3, [rsp+0x30]
000073dfa87e41bd  vmovaps xmm4, [rsp+0x40]
000073dfa87e41c3  vmovaps xmm5, [rsp+0x50]
000073dfa87e41c9  vmovaps xmm6, [rsp+0x60]
000073dfa87e41cf  vmovaps xmm7, [rsp+0x70]
000073dfa87e41d5  vmovaps xmm8, [rsp+0x80]
000073dfa87e41de  vmovaps xmm9, [rsp+0x90]
000073dfa87e41e7  vmovaps xmm10, [rsp+0xA0]
000073dfa87e41f0  vmovaps xmm11, [rsp+0xB0]
000073dfa87e41f9  vmovaps xmm12, [rsp+0xC0]
000073dfa87e4202  vmovaps xmm13, [rsp+0xD0]
000073dfa87e420b  vmovaps xmm15, [rsp+0xE0]
000073dfa87e4214  add rsp, 0xF0
000073dfa87e421b  pop r11
000073dfa87e421d  pop r10
000073dfa87e421f  pop r9
000073dfa87e4221  pop r8
000073dfa87e4223  pop rsi
000073dfa87e4224  pop rdi
000073dfa87e4225  pop rdx
000073dfa87e4226  pop rcx
000073dfa87e4227  pop rax
000073dfa87e4228  add rsp, 0x08
000073dfa87e422c  jmp 0x000073DFA87DF90B
000073dfa87e4231  sub rsp, 0x08
000073dfa87e4235  push rax
000073dfa87e4236  push rcx
000073dfa87e4237  push rdx
000073dfa87e4238  push rdi
000073dfa87e4239  push rsi
000073dfa87e423a  push r8
000073dfa87e423c  push r9
000073dfa87e423e  push r10
000073dfa87e4240  push r11
000073dfa87e4242  sub rsp, 0xF0
000073dfa87e4249  vmovaps [rsp], xmm0
000073dfa87e424e  vmovaps [rsp+0x10], xmm2
000073dfa87e4254  vmovaps [rsp+0x20], xmm3
000073dfa87e425a  vmovaps [rsp+0x30], xmm4
000073dfa87e4260  vmovaps [rsp+0x40], xmm5
000073dfa87e4266  vmovaps [rsp+0x50], xmm6
000073dfa87e426c  vmovaps [rsp+0x60], xmm7
000073dfa87e4272  vmovaps [rsp+0x70], xmm8
000073dfa87e4278  vmovaps [rsp+0x80], xmm9
000073dfa87e4281  vmovaps [rsp+0x90], xmm10
000073dfa87e428a  vmovaps [rsp+0xA0], xmm11
000073dfa87e4293  vmovaps [rsp+0xB0], xmm12
000073dfa87e429c  vmovaps [rsp+0xC0], xmm13
000073dfa87e42a5  vmovaps [rsp+0xD0], xmm14
000073dfa87e42ae  vmovaps [rsp+0xE0], xmm15
000073dfa87e42b7  sub rsp, 0x30
000073dfa87e42bb  movaps [rsp], xmm1
000073dfa87e42bf  movaps [rsp+0x10], xmm13
000073dfa87e42c5  movaps [rsp+0x20], xmm8
000073dfa87e42cb  lea rdi, [rsp]
000073dfa87e42cf  mov esi, 0x00
000073dfa87e42d4  mov rax, 0x593AA1DA4530
000073dfa87e42de  call rax
000073dfa87e42e0  movaps xmm1, [rsp]
000073dfa87e42e4  add rsp, 0x30
000073dfa87e42e8  vmovaps xmm0, [rsp]
000073dfa87e42ed  vmovaps xmm2, [rsp+0x10]
000073dfa87e42f3  vmovaps xmm3, [rsp+0x20]
000073dfa87e42f9  vmovaps xmm4, [rsp+0x30]
000073dfa87e42ff  vmovaps xmm5, [rsp+0x40]
000073dfa87e4305  vmovaps xmm6, [rsp+0x50]
000073dfa87e430b  vmovaps xmm7, [rsp+0x60]
000073dfa87e4311  vmovaps xmm8, [rsp+0x70]
000073dfa87e4317  vmovaps xmm9, [rsp+0x80]
000073dfa87e4320  vmovaps xmm10, [rsp+0x90]
000073dfa87e4329  vmovaps xmm11, [rsp+0xA0]
000073dfa87e4332  vmovaps xmm12, [rsp+0xB0]
000073dfa87e433b  vmovaps xmm13, [rsp+0xC0]
000073dfa87e4344  vmovaps xmm14, [rsp+0xD0]
000073dfa87e434d  vmovaps xmm15, [rsp+0xE0]
000073dfa87e4356  add rsp, 0xF0
000073dfa87e435d  pop r11
000073dfa87e435f  pop r10
000073dfa87e4361  pop r9
000073dfa87e4363  pop r8
000073dfa87e4365  pop rsi
000073dfa87e4366  pop rdi
000073dfa87e4367  pop rdx
000073dfa87e4368  pop rcx
000073dfa87e4369  pop rax
000073dfa87e436a  add rsp, 0x08
000073dfa87e436e  jmp 0x000073DFA87DF92D
000073dfa87e4373  call 0x000073DFA860C260
000073dfa87e4378  jmp 0x000073DFA87DF93B
000073dfa87e437d  call 0x000073DFA86BD750
000073dfa87e4382  jmp 0x000073DFA87DF945
000073dfa87e4387  sub rsp, 0x08
000073dfa87e438b  push rax
000073dfa87e438c  push rcx
000073dfa87e438d  push rdx
000073dfa87e438e  push rdi
000073dfa87e438f  push rsi
000073dfa87e4390  push r8
000073dfa87e4392  push r9
000073dfa87e4394  push r10
000073dfa87e4396  push r11
000073dfa87e4398  sub rsp, 0xF0
000073dfa87e439f  vmovaps [rsp], xmm0
000073dfa87e43a4  vmovaps [rsp+0x10], xmm1
000073dfa87e43aa  vmovaps [rsp+0x20], xmm2
000073dfa87e43b0  vmovaps [rsp+0x30], xmm3
000073dfa87e43b6  vmovaps [rsp+0x40], xmm4
000073dfa87e43bc  vmovaps [rsp+0x50], xmm5
000073dfa87e43c2  vmovaps [rsp+0x60], xmm6
000073dfa87e43c8  vmovaps [rsp+0x70], xmm7
000073dfa87e43ce  vmovaps [rsp+0x80], xmm9
000073dfa87e43d7  vmovaps [rsp+0x90], xmm10
000073dfa87e43e0  vmovaps [rsp+0xA0], xmm11
000073dfa87e43e9  vmovaps [rsp+0xB0], xmm12
000073dfa87e43f2  vmovaps [rsp+0xC0], xmm13
000073dfa87e43fb  vmovaps [rsp+0xD0], xmm14
000073dfa87e4404  vmovaps [rsp+0xE0], xmm15
000073dfa87e440d  sub rsp, 0x30
000073dfa87e4411  movaps [rsp], xmm8
000073dfa87e4416  movaps [rsp+0x10], xmm15
000073dfa87e441c  movaps [rsp+0x20], xmm7
000073dfa87e4421  lea rdi, [rsp]
000073dfa87e4425  mov esi, 0x00
000073dfa87e442a  mov rax, 0x593AA1DA4530
000073dfa87e4434  call rax
000073dfa87e4436  movaps xmm8, [rsp]
000073dfa87e443b  add rsp, 0x30
000073dfa87e443f  vmovaps xmm0, [rsp]
000073dfa87e4444  vmovaps xmm1, [rsp+0x10]
000073dfa87e444a  vmovaps xmm2, [rsp+0x20]
000073dfa87e4450  vmovaps xmm3, [rsp+0x30]
000073dfa87e4456  vmovaps xmm4, [rsp+0x40]
000073dfa87e445c  vmovaps xmm5, [rsp+0x50]
000073dfa87e4462  vmovaps xmm6, [rsp+0x60]
000073dfa87e4468  vmovaps xmm7, [rsp+0x70]
000073dfa87e446e  vmovaps xmm9, [rsp+0x80]
000073dfa87e4477  vmovaps xmm10, [rsp+0x90]
000073dfa87e4480  vmovaps xmm11, [rsp+0xA0]
000073dfa87e4489  vmovaps xmm12, [rsp+0xB0]
000073dfa87e4492  vmovaps xmm13, [rsp+0xC0]
000073dfa87e449b  vmovaps xmm14, [rsp+0xD0]
000073dfa87e44a4  vmovaps xmm15, [rsp+0xE0]
000073dfa87e44ad  add rsp, 0xF0
000073dfa87e44b4  pop r11
000073dfa87e44b6  pop r10
000073dfa87e44b8  pop r9
000073dfa87e44ba  pop r8
000073dfa87e44bc  pop rsi
000073dfa87e44bd  pop rdi
000073dfa87e44be  pop rdx
000073dfa87e44bf  pop rcx
000073dfa87e44c0  pop rax
000073dfa87e44c1  add rsp, 0x08
000073dfa87e44c5  jmp 0x000073DFA87DF967
000073dfa87e44ca  sub rsp, 0x08
000073dfa87e44ce  push rax
000073dfa87e44cf  push rcx
000073dfa87e44d0  push rdx
000073dfa87e44d1  push rdi
000073dfa87e44d2  push rsi
000073dfa87e44d3  push r8
000073dfa87e44d5  push r9
000073dfa87e44d7  push r10
000073dfa87e44d9  push r11
000073dfa87e44db  sub rsp, 0xF0
000073dfa87e44e2  vmovaps [rsp], xmm0
000073dfa87e44e7  vmovaps [rsp+0x10], xmm1
000073dfa87e44ed  vmovaps [rsp+0x20], xmm2
000073dfa87e44f3  vmovaps [rsp+0x30], xmm3
000073dfa87e44f9  vmovaps [rsp+0x40], xmm4
000073dfa87e44ff  vmovaps [rsp+0x50], xmm5
000073dfa87e4505  vmovaps [rsp+0x60], xmm6
000073dfa87e450b  vmovaps [rsp+0x70], xmm8
000073dfa87e4511  vmovaps [rsp+0x80], xmm9
000073dfa87e451a  vmovaps [rsp+0x90], xmm10
000073dfa87e4523  vmovaps [rsp+0xA0], xmm11
000073dfa87e452c  vmovaps [rsp+0xB0], xmm12
000073dfa87e4535  vmovaps [rsp+0xC0], xmm13
000073dfa87e453e  vmovaps [rsp+0xD0], xmm14
000073dfa87e4547  vmovaps [rsp+0xE0], xmm15
000073dfa87e4550  sub rsp, 0x30
000073dfa87e4554  movaps [rsp], xmm7
000073dfa87e4558  movaps [rsp+0x10], xmm9
000073dfa87e455e  movaps [rsp+0x20], xmm15
000073dfa87e4564  lea rdi, [rsp]
000073dfa87e4568  mov esi, 0x00
000073dfa87e456d  mov rax, 0x593AA1DA4530
000073dfa87e4577  call rax
000073dfa87e4579  movaps xmm7, [rsp]
000073dfa87e457d  add rsp, 0x30
000073dfa87e4581  vmovaps xmm0, [rsp]
000073dfa87e4586  vmovaps xmm1, [rsp+0x10]
000073dfa87e458c  vmovaps xmm2, [rsp+0x20]
000073dfa87e4592  vmovaps xmm3, [rsp+0x30]
000073dfa87e4598  vmovaps xmm4, [rsp+0x40]
000073dfa87e459e  vmovaps xmm5, [rsp+0x50]
000073dfa87e45a4  vmovaps xmm6, [rsp+0x60]
000073dfa87e45aa  vmovaps xmm8, [rsp+0x70]
000073dfa87e45b0  vmovaps xmm9, [rsp+0x80]
000073dfa87e45b9  vmovaps xmm10, [rsp+0x90]
000073dfa87e45c2  vmovaps xmm11, [rsp+0xA0]
000073dfa87e45cb  vmovaps xmm12, [rsp+0xB0]
000073dfa87e45d4  vmovaps xmm13, [rsp+0xC0]
000073dfa87e45dd  vmovaps xmm14, [rsp+0xD0]
000073dfa87e45e6  vmovaps xmm15, [rsp+0xE0]
000073dfa87e45ef  add rsp, 0xF0
000073dfa87e45f6  pop r11
000073dfa87e45f8  pop r10
000073dfa87e45fa  pop r9
000073dfa87e45fc  pop r8
000073dfa87e45fe  pop rsi
000073dfa87e45ff  pop rdi
000073dfa87e4600  pop rdx
000073dfa87e4601  pop rcx
000073dfa87e4602  pop rax
000073dfa87e4603  add rsp, 0x08
000073dfa87e4607  jmp 0x000073DFA87DF994
000073dfa87e460c  sub rsp, 0x08
000073dfa87e4610  push rax
000073dfa87e4611  push rcx
000073dfa87e4612  push rdx
000073dfa87e4613  push rdi
000073dfa87e4614  push rsi
000073dfa87e4615  push r8
000073dfa87e4617  push r9
000073dfa87e4619  push r10
000073dfa87e461b  push r11
000073dfa87e461d  sub rsp, 0xF0
000073dfa87e4624  vmovaps [rsp], xmm0
000073dfa87e4629  vmovaps [rsp+0x10], xmm1
000073dfa87e462f  vmovaps [rsp+0x20], xmm2
000073dfa87e4635  vmovaps [rsp+0x30], xmm3
000073dfa87e463b  vmovaps [rsp+0x40], xmm4
000073dfa87e4641  vmovaps [rsp+0x50], xmm5
000073dfa87e4647  vmovaps [rsp+0x60], xmm6
000073dfa87e464d  vmovaps [rsp+0x70], xmm7
000073dfa87e4653  vmovaps [rsp+0x80], xmm8
000073dfa87e465c  vmovaps [rsp+0x90], xmm10
000073dfa87e4665  vmovaps [rsp+0xA0], xmm11
000073dfa87e466e  vmovaps [rsp+0xB0], xmm12
000073dfa87e4677  vmovaps [rsp+0xC0], xmm13
000073dfa87e4680  vmovaps [rsp+0xD0], xmm14
000073dfa87e4689  vmovaps [rsp+0xE0], xmm15
000073dfa87e4692  sub rsp, 0x30
000073dfa87e4696  movaps [rsp], xmm9
000073dfa87e469b  movaps [rsp+0x10], xmm13
000073dfa87e46a1  movaps [rsp+0x20], xmm15
000073dfa87e46a7  lea rdi, [rsp]
000073dfa87e46ab  mov esi, 0x00
000073dfa87e46b0  mov rax, 0x593AA1DA4530
000073dfa87e46ba  call rax
000073dfa87e46bc  movaps xmm9, [rsp]
000073dfa87e46c1  add rsp, 0x30
000073dfa87e46c5  vmovaps xmm0, [rsp]
000073dfa87e46ca  vmovaps xmm1, [rsp+0x10]
000073dfa87e46d0  vmovaps xmm2, [rsp+0x20]
000073dfa87e46d6  vmovaps xmm3, [rsp+0x30]
000073dfa87e46dc  vmovaps xmm4, [rsp+0x40]
000073dfa87e46e2  vmovaps xmm5, [rsp+0x50]
000073dfa87e46e8  vmovaps xmm6, [rsp+0x60]
000073dfa87e46ee  vmovaps xmm7, [rsp+0x70]
000073dfa87e46f4  vmovaps xmm8, [rsp+0x80]
000073dfa87e46fd  vmovaps xmm10, [rsp+0x90]
000073dfa87e4706  vmovaps xmm11, [rsp+0xA0]
000073dfa87e470f  vmovaps xmm12, [rsp+0xB0]
000073dfa87e4718  vmovaps xmm13, [rsp+0xC0]
000073dfa87e4721  vmovaps xmm14, [rsp+0xD0]
000073dfa87e472a  vmovaps xmm15, [rsp+0xE0]
000073dfa87e4733  add rsp, 0xF0
000073dfa87e473a  pop r11
000073dfa87e473c  pop r10
000073dfa87e473e  pop r9
000073dfa87e4740  pop r8
000073dfa87e4742  pop rsi
000073dfa87e4743  pop rdi
000073dfa87e4744  pop rdx
000073dfa87e4745  pop rcx
000073dfa87e4746  pop rax
000073dfa87e4747  add rsp, 0x08
000073dfa87e474b  jmp 0x000073DFA87DF9C2
000073dfa87e4750  sub rsp, 0x08
000073dfa87e4754  push rax
000073dfa87e4755  push rcx
000073dfa87e4756  push rdx
000073dfa87e4757  push rdi
000073dfa87e4758  push rsi
000073dfa87e4759  push r8
000073dfa87e475b  push r9
000073dfa87e475d  push r10
000073dfa87e475f  push r11
000073dfa87e4761  sub rsp, 0xF0
000073dfa87e4768  vmovaps [rsp], xmm0
000073dfa87e476d  vmovaps [rsp+0x10], xmm1
000073dfa87e4773  vmovaps [rsp+0x20], xmm2
000073dfa87e4779  vmovaps [rsp+0x30], xmm3
000073dfa87e477f  vmovaps [rsp+0x40], xmm4
000073dfa87e4785  vmovaps [rsp+0x50], xmm5
000073dfa87e478b  vmovaps [rsp+0x60], xmm6
000073dfa87e4791  vmovaps [rsp+0x70], xmm7
000073dfa87e4797  vmovaps [rsp+0x80], xmm8
000073dfa87e47a0  vmovaps [rsp+0x90], xmm9
000073dfa87e47a9  vmovaps [rsp+0xA0], xmm10
000073dfa87e47b2  vmovaps [rsp+0xB0], xmm11
000073dfa87e47bb  vmovaps [rsp+0xC0], xmm12
000073dfa87e47c4  vmovaps [rsp+0xD0], xmm13
000073dfa87e47cd  vmovaps [rsp+0xE0], xmm14
000073dfa87e47d6  sub rsp, 0x30
000073dfa87e47da  movaps [rsp], xmm15
000073dfa87e47df  movaps [rsp+0x10], xmm11
000073dfa87e47e5  movaps [rsp+0x20], xmm12
000073dfa87e47eb  lea rdi, [rsp]
000073dfa87e47ef  mov esi, 0x00
000073dfa87e47f4  mov rax, 0x593AA1DA4530
000073dfa87e47fe  call rax
000073dfa87e4800  movaps xmm15, [rsp]
000073dfa87e4805  add rsp, 0x30
000073dfa87e4809  vmovaps xmm0, [rsp]
000073dfa87e480e  vmovaps xmm1, [rsp+0x10]
000073dfa87e4814  vmovaps xmm2, [rsp+0x20]
000073dfa87e481a  vmovaps xmm3, [rsp+0x30]
000073dfa87e4820  vmovaps xmm4, [rsp+0x40]
000073dfa87e4826  vmovaps xmm5, [rsp+0x50]
000073dfa87e482c  vmovaps xmm6, [rsp+0x60]
000073dfa87e4832  vmovaps xmm7, [rsp+0x70]
000073dfa87e4838  vmovaps xmm8, [rsp+0x80]
000073dfa87e4841  vmovaps xmm9, [rsp+0x90]
000073dfa87e484a  vmovaps xmm10, [rsp+0xA0]
000073dfa87e4853  vmovaps xmm11, [rsp+0xB0]
000073dfa87e485c  vmovaps xmm12, [rsp+0xC0]
000073dfa87e4865  vmovaps xmm13, [rsp+0xD0]
000073dfa87e486e  vmovaps xmm14, [rsp+0xE0]
000073dfa87e4877  add rsp, 0xF0
000073dfa87e487e  pop r11
000073dfa87e4880  pop r10
000073dfa87e4882  pop r9
000073dfa87e4884  pop r8
000073dfa87e4886  pop rsi
000073dfa87e4887  pop rdi
000073dfa87e4888  pop rdx
000073dfa87e4889  pop rcx
000073dfa87e488a  pop rax
000073dfa87e488b  add rsp, 0x08
000073dfa87e488f  jmp 0x000073DFA87DF9DD
000073dfa87e4894  sub rsp, 0x08
000073dfa87e4898  push rax
000073dfa87e4899  push rcx
000073dfa87e489a  push rdx
000073dfa87e489b  push rdi
000073dfa87e489c  push rsi
000073dfa87e489d  push r8
000073dfa87e489f  push r9
000073dfa87e48a1  push r10
000073dfa87e48a3  push r11
000073dfa87e48a5  sub rsp, 0xF0
000073dfa87e48ac  vmovaps [rsp], xmm0
000073dfa87e48b1  vmovaps [rsp+0x10], xmm1
000073dfa87e48b7  vmovaps [rsp+0x20], xmm2
000073dfa87e48bd  vmovaps [rsp+0x30], xmm3
000073dfa87e48c3  vmovaps [rsp+0x40], xmm4
000073dfa87e48c9  vmovaps [rsp+0x50], xmm5
000073dfa87e48cf  vmovaps [rsp+0x60], xmm6
000073dfa87e48d5  vmovaps [rsp+0x70], xmm7
000073dfa87e48db  vmovaps [rsp+0x80], xmm8
000073dfa87e48e4  vmovaps [rsp+0x90], xmm9
000073dfa87e48ed  vmovaps [rsp+0xA0], xmm10
000073dfa87e48f6  vmovaps [rsp+0xB0], xmm11
000073dfa87e48ff  vmovaps [rsp+0xC0], xmm12
000073dfa87e4908  vmovaps [rsp+0xD0], xmm14
000073dfa87e4911  vmovaps [rsp+0xE0], xmm15
000073dfa87e491a  sub rsp, 0x30
000073dfa87e491e  movaps [rsp], xmm13
000073dfa87e4923  movaps [rsp+0x10], xmm10
000073dfa87e4929  movaps [rsp+0x20], xmm14
000073dfa87e492f  lea rdi, [rsp]
000073dfa87e4933  mov esi, 0x00
000073dfa87e4938  mov rax, 0x593AA1DA4530
000073dfa87e4942  call rax
000073dfa87e4944  movaps xmm13, [rsp]
000073dfa87e4949  add rsp, 0x30
000073dfa87e494d  vmovaps xmm0, [rsp]
000073dfa87e4952  vmovaps xmm1, [rsp+0x10]
000073dfa87e4958  vmovaps xmm2, [rsp+0x20]
000073dfa87e495e  vmovaps xmm3, [rsp+0x30]
000073dfa87e4964  vmovaps xmm4, [rsp+0x40]
000073dfa87e496a  vmovaps xmm5, [rsp+0x50]
000073dfa87e4970  vmovaps xmm6, [rsp+0x60]
000073dfa87e4976  vmovaps xmm7, [rsp+0x70]
000073dfa87e497c  vmovaps xmm8, [rsp+0x80]
000073dfa87e4985  vmovaps xmm9, [rsp+0x90]
000073dfa87e498e  vmovaps xmm10, [rsp+0xA0]
000073dfa87e4997  vmovaps xmm11, [rsp+0xB0]
000073dfa87e49a0  vmovaps xmm12, [rsp+0xC0]
000073dfa87e49a9  vmovaps xmm14, [rsp+0xD0]
000073dfa87e49b2  vmovaps xmm15, [rsp+0xE0]
000073dfa87e49bb  add rsp, 0xF0
000073dfa87e49c2  pop r11
000073dfa87e49c4  pop r10
000073dfa87e49c6  pop r9
000073dfa87e49c8  pop r8
000073dfa87e49ca  pop rsi
000073dfa87e49cb  pop rdi
000073dfa87e49cc  pop rdx
000073dfa87e49cd  pop rcx
000073dfa87e49ce  pop rax
000073dfa87e49cf  add rsp, 0x08
000073dfa87e49d3  jmp 0x000073DFA87DFA00
000073dfa87e49d8  sub rsp, 0x08
000073dfa87e49dc  push rax
000073dfa87e49dd  push rcx
000073dfa87e49de  push rdx
000073dfa87e49df  push rdi
000073dfa87e49e0  push rsi
000073dfa87e49e1  push r8
000073dfa87e49e3  push r9
000073dfa87e49e5  push r10
000073dfa87e49e7  push r11
000073dfa87e49e9  sub rsp, 0xF0
000073dfa87e49f0  vmovaps [rsp], xmm0
000073dfa87e49f5  vmovaps [rsp+0x10], xmm1
000073dfa87e49fb  vmovaps [rsp+0x20], xmm2
000073dfa87e4a01  vmovaps [rsp+0x30], xmm3
000073dfa87e4a07  vmovaps [rsp+0x40], xmm4
000073dfa87e4a0d  vmovaps [rsp+0x50], xmm5
000073dfa87e4a13  vmovaps [rsp+0x60], xmm6
000073dfa87e4a19  vmovaps [rsp+0x70], xmm7
000073dfa87e4a1f  vmovaps [rsp+0x80], xmm8
000073dfa87e4a28  vmovaps [rsp+0x90], xmm9
000073dfa87e4a31  vmovaps [rsp+0xA0], xmm10
000073dfa87e4a3a  vmovaps [rsp+0xB0], xmm11
000073dfa87e4a43  vmovaps [rsp+0xC0], xmm12
000073dfa87e4a4c  vmovaps [rsp+0xD0], xmm13
000073dfa87e4a55  vmovaps [rsp+0xE0], xmm15
000073dfa87e4a5e  sub rsp, 0x30
000073dfa87e4a62  movaps [rsp], xmm14
000073dfa87e4a67  movaps [rsp+0x10], xmm1
000073dfa87e4a6c  movaps [rsp+0x20], xmm7
000073dfa87e4a71  lea rdi, [rsp]
000073dfa87e4a75  mov esi, 0x00
000073dfa87e4a7a  mov rax, 0x593AA1DA4530
000073dfa87e4a84  call rax
000073dfa87e4a86  movaps xmm14, [rsp]
000073dfa87e4a8b  add rsp, 0x30
000073dfa87e4a8f  vmovaps xmm0, [rsp]
000073dfa87e4a94  vmovaps xmm1, [rsp+0x10]
000073dfa87e4a9a  vmovaps xmm2, [rsp+0x20]
000073dfa87e4aa0  vmovaps xmm3, [rsp+0x30]
000073dfa87e4aa6  vmovaps xmm4, [rsp+0x40]
000073dfa87e4aac  vmovaps xmm5, [rsp+0x50]
000073dfa87e4ab2  vmovaps xmm6, [rsp+0x60]
000073dfa87e4ab8  vmovaps xmm7, [rsp+0x70]
000073dfa87e4abe  vmovaps xmm8, [rsp+0x80]
000073dfa87e4ac7  vmovaps xmm9, [rsp+0x90]
000073dfa87e4ad0  vmovaps xmm10, [rsp+0xA0]
000073dfa87e4ad9  vmovaps xmm11, [rsp+0xB0]
000073dfa87e4ae2  vmovaps xmm12, [rsp+0xC0]
000073dfa87e4aeb  vmovaps xmm13, [rsp+0xD0]
000073dfa87e4af4  vmovaps xmm15, [rsp+0xE0]
000073dfa87e4afd  add rsp, 0xF0
000073dfa87e4b04  pop r11
000073dfa87e4b06  pop r10
000073dfa87e4b08  pop r9
000073dfa87e4b0a  pop r8
000073dfa87e4b0c  pop rsi
000073dfa87e4b0d  pop rdi
000073dfa87e4b0e  pop rdx
000073dfa87e4b0f  pop rcx
000073dfa87e4b10  pop rax
000073dfa87e4b11  add rsp, 0x08
000073dfa87e4b15  jmp 0x000073DFA87DFA23
000073dfa87e4b1a  sub rsp, 0x08
000073dfa87e4b1e  push rax
000073dfa87e4b1f  push rcx
000073dfa87e4b20  push rdx
000073dfa87e4b21  push rdi
000073dfa87e4b22  push rsi
000073dfa87e4b23  push r8
000073dfa87e4b25  push r9
000073dfa87e4b27  push r10
000073dfa87e4b29  push r11
000073dfa87e4b2b  sub rsp, 0xF0
000073dfa87e4b32  vmovaps [rsp], xmm0
000073dfa87e4b37  vmovaps [rsp+0x10], xmm2
000073dfa87e4b3d  vmovaps [rsp+0x20], xmm3
000073dfa87e4b43  vmovaps [rsp+0x30], xmm4
000073dfa87e4b49  vmovaps [rsp+0x40], xmm5
000073dfa87e4b4f  vmovaps [rsp+0x50], xmm6
000073dfa87e4b55  vmovaps [rsp+0x60], xmm7
000073dfa87e4b5b  vmovaps [rsp+0x70], xmm8
000073dfa87e4b61  vmovaps [rsp+0x80], xmm9
000073dfa87e4b6a  vmovaps [rsp+0x90], xmm10
000073dfa87e4b73  vmovaps [rsp+0xA0], xmm11
000073dfa87e4b7c  vmovaps [rsp+0xB0], xmm12
000073dfa87e4b85  vmovaps [rsp+0xC0], xmm13
000073dfa87e4b8e  vmovaps [rsp+0xD0], xmm14
000073dfa87e4b97  vmovaps [rsp+0xE0], xmm15
000073dfa87e4ba0  sub rsp, 0x30
000073dfa87e4ba4  movaps [rsp], xmm1
000073dfa87e4ba8  movaps [rsp+0x10], xmm8
000073dfa87e4bae  movaps [rsp+0x20], xmm9
000073dfa87e4bb4  lea rdi, [rsp]
000073dfa87e4bb8  mov esi, 0x00
000073dfa87e4bbd  mov rax, 0x593AA1DA4530
000073dfa87e4bc7  call rax
000073dfa87e4bc9  movaps xmm1, [rsp]
000073dfa87e4bcd  add rsp, 0x30
000073dfa87e4bd1  vmovaps xmm0, [rsp]
000073dfa87e4bd6  vmovaps xmm2, [rsp+0x10]
000073dfa87e4bdc  vmovaps xmm3, [rsp+0x20]
000073dfa87e4be2  vmovaps xmm4, [rsp+0x30]
000073dfa87e4be8  vmovaps xmm5, [rsp+0x40]
000073dfa87e4bee  vmovaps xmm6, [rsp+0x50]
000073dfa87e4bf4  vmovaps xmm7, [rsp+0x60]
000073dfa87e4bfa  vmovaps xmm8, [rsp+0x70]
000073dfa87e4c00  vmovaps xmm9, [rsp+0x80]
000073dfa87e4c09  vmovaps xmm10, [rsp+0x90]
000073dfa87e4c12  vmovaps xmm11, [rsp+0xA0]
000073dfa87e4c1b  vmovaps xmm12, [rsp+0xB0]
000073dfa87e4c24  vmovaps xmm13, [rsp+0xC0]
000073dfa87e4c2d  vmovaps xmm14, [rsp+0xD0]
000073dfa87e4c36  vmovaps xmm15, [rsp+0xE0]
000073dfa87e4c3f  add rsp, 0xF0
000073dfa87e4c46  pop r11
000073dfa87e4c48  pop r10
000073dfa87e4c4a  pop r9
000073dfa87e4c4c  pop r8
000073dfa87e4c4e  pop rsi
000073dfa87e4c4f  pop rdi
000073dfa87e4c50  pop rdx
000073dfa87e4c51  pop rcx
000073dfa87e4c52  pop rax
000073dfa87e4c53  add rsp, 0x08
000073dfa87e4c57  jmp 0x000073DFA87DFA45
000073dfa87e4c5c  call 0x000073DFA86E5940
000073dfa87e4c61  jmp 0x000073DFA87DFA53
000073dfa87e4c66  call 0x000073DFA860C380
000073dfa87e4c6b  jmp 0x000073DFA87DFA5D
000073dfa87e4c70  call 0x000073DFA860D600
000073dfa87e4c75  jmp 0x000073DFA87DFA67
000073dfa87e4c7a  call 0x000073DFA85FF540
000073dfa87e4c7f  jmp 0x000073DFA87DFA71
000073dfa87e4c84  int3
000073dfa87e4c85  nop [rax+rax*1], ax
000073dfa87e4c8e  nop
000073dfa87e4c90  mov qword ptr [r15+0x40], 0x430000
000073dfa87e4c98  mov eax, 0x430CC0
000073dfa87e4c9d  mov r14, [r13+rax*1]
000073dfa87e4ca2  movq xmm1, r14
000073dfa87e4ca7  mov rax, [r15+0x50]
000073dfa87e4cab  movups xmm15, [r13+rax*1]
000073dfa87e4cb1  movaps [r15+0x120], xmm15
000073dfa87e4cb9  mov qword ptr [r15+0x48], 0x10
000073dfa87e4cc1  xor eax, eax
000073dfa87e4cc3  mov r14d, 0x10
000073dfa87e4cc9  mov r12d, 0x200
000073dfa87e4ccf  cmp r14, r12
000073dfa87e4cd2  cmc
000073dfa87e4cd3  lahf
000073dfa87e4cd4  seto al
000073dfa87e4cd7  mov [r15+0x108], eax
000073dfa87e4cde  pextrq rax, xmm15, 0x01
000073dfa87e4ce5  movq xmm14, rax
000073dfa87e4cea  movaps [r15+0x130], xmm14
000073dfa87e4cf2  movq rax, xmm1
000073dfa87e4cf7  movq r14, xmm15
000073dfa87e4cfc  vmovq xmm1, rax
000073dfa87e4d01  vmovq xmm15, r14
000073dfa87e4d06  movaps xmm13, xmm1
000073dfa87e4d0a  addsd xmm13, xmm15
000073dfa87e4d0f  ucomisd xmm13, xmm13
000073dfa87e4d14  jp 0x000073DFA87E4DD3
000073dfa87e4d1a  movq xmm13, xmm13
000073dfa87e4d1f  movq rax, xmm13
000073dfa87e4d24  movq r14, xmm14
000073dfa87e4d29  vmovq xmm1, rax
000073dfa87e4d2e  vmovq xmm15, r14
000073dfa87e4d33  movaps xmm14, xmm1
000073dfa87e4d37  addsd xmm14, xmm15
000073dfa87e4d3c  ucomisd xmm14, xmm14
000073dfa87e4d41  jp 0x000073DFA87E4E1B
000073dfa87e4d47  movq xmm14, xmm14
000073dfa87e4d4c  movaps [r15+0x110], xmm14
000073dfa87e4d54  mov eax, [r15+0x108]
000073dfa87e4d5b  sahf
000073dfa87e4d5c  jnz 0x000073DFA87E4D8E
000073dfa87e4d5e  cmp dword ptr [r15+0x318], 0x00
000073dfa87e4d66  jz 0x000073DFA87E5030
000073dfa87e4d6c  nop [rax+rax*1], ax
000073dfa87e4d75  nop [rax+rax*1], eax
000073dfa87e4d7d  mov eax, 0x410704
000073dfa87e4d82  mov [r15+0x100], rax
000073dfa87e4d89  jmp 0x000073DFA85FE110
000073dfa87e4d8e  cmp dword ptr [r15+0x318], 0x00
000073dfa87e4d96  jz 0x000073DFA87E4E70
000073dfa87e4d9c  nop [rax+rax*1], ax
000073dfa87e4da5  nop [rax+rax*1], eax
000073dfa87e4dad  mov eax, 0x4106E8
000073dfa87e4db2  mov [r15+0x100], rax
000073dfa87e4db9  jmp 0x000073DFA85FE110
000073dfa87e4dbe  int3
000073dfa87e4dbf  call 0x000073DFA860DC20
000073dfa87e4dc4  jmp 0x000073DFA87E4CA2
000073dfa87e4dc9  call 0x000073DFA860E760
000073dfa87e4dce  jmp 0x000073DFA87E4CB1
000073dfa87e4dd3  ucomisd xmm1, xmm15
000073dfa87e4dd8  jp 0x000073DFA87E4DE7
000073dfa87e4dda  movaps xmm13, [0x000073DFA83FE060]
000073dfa87e4de2  jmp 0x000073DFA87E4D1A
000073dfa87e4de7  vxorps xmm0, xmm1, xmm15
000073dfa87e4dec  pextrw eax, xmm0, 0x03
000073dfa87e4df1  and eax, 0x7FF8
000073dfa87e4df6  cmp eax, 0x08
000073dfa87e4df9  jnz 0x000073DFA87E4D1A
000073dfa87e4dff  movq rax, xmm15
000073dfa87e4e04  shl rax, 0x0D
000073dfa87e4e08  jbe 0x000073DFA87E4D1A
000073dfa87e4e0e  vorps xmm13, xmm15, [0x000073DFA83FE070]
000073dfa87e4e16  jmp 0x000073DFA87E4D1A
000073dfa87e4e1b  ucomisd xmm1, xmm15
000073dfa87e4e20  jp 0x000073DFA87E4E2F
000073dfa87e4e22  movaps xmm14, [0x000073DFA83FE060]
000073dfa87e4e2a  jmp 0x000073DFA87E4D47
000073dfa87e4e2f  vxorps xmm0, xmm1, xmm15
000073dfa87e4e34  pextrw eax, xmm0, 0x03
000073dfa87e4e39  and eax, 0x7FF8
000073dfa87e4e3e  cmp eax, 0x08
000073dfa87e4e41  jnz 0x000073DFA87E4D47
000073dfa87e4e47  movq rax, xmm15
000073dfa87e4e4c  shl rax, 0x0D
000073dfa87e4e50  jbe 0x000073DFA87E4D47
000073dfa87e4e56  vorps xmm14, xmm15, [0x000073DFA83FE070]
000073dfa87e4e5e  jmp 0x000073DFA87E4D47
000073dfa87e4e63  int3
000073dfa87e4e64  nop [rax+rax*1], ax
000073dfa87e4e6d  nop [rax], eax
000073dfa87e4e70  mov rax, [r15+0x48]
000073dfa87e4e74  mov r14, [r15+0x50]
000073dfa87e4e78  lea r12, [r14+rax*1]
000073dfa87e4e7c  movups xmm1, [r13+r12*1]
000073dfa87e4e82  movaps [r15+0x120], xmm1
000073dfa87e4e8a  lea r14, [rax+0x10]
000073dfa87e4e8e  mov [r15+0x48], r14
000073dfa87e4e92  xor eax, eax
000073dfa87e4e94  mov r12d, 0x200
000073dfa87e4e9a  cmp r14, r12
000073dfa87e4e9d  cmc
000073dfa87e4e9e  lahf
000073dfa87e4e9f  seto al
000073dfa87e4ea2  mov [r15+0x108], eax
000073dfa87e4ea9  pextrq rax, xmm1, 0x01
000073dfa87e4eb0  movq xmm15, rax
000073dfa87e4eb5  movaps [r15+0x130], xmm15
000073dfa87e4ebd  movaps xmm14, [r15+0x110]
000073dfa87e4ec5  movq rax, xmm14
000073dfa87e4eca  movq r14, xmm1
000073dfa87e4ecf  vmovq xmm1, rax
000073dfa87e4ed4  vmovq xmm14, r14
000073dfa87e4ed9  movaps xmm13, xmm1
000073dfa87e4edd  addsd xmm13, xmm14
000073dfa87e4ee2  ucomisd xmm13, xmm13
000073dfa87e4ee7  jp 0x000073DFA87E4F9C
000073dfa87e4eed  movq xmm13, xmm13
000073dfa87e4ef2  movq rax, xmm13
000073dfa87e4ef7  movq r14, xmm15
000073dfa87e4efc  vmovq xmm1, rax
000073dfa87e4f01  vmovq xmm15, r14
000073dfa87e4f06  movaps xmm14, xmm1
000073dfa87e4f0a  addsd xmm14, xmm15
000073dfa87e4f0f  ucomisd xmm14, xmm14
000073dfa87e4f14  jp 0x000073DFA87E4FE4
000073dfa87e4f1a  movq xmm14, xmm14
000073dfa87e4f1f  movaps [r15+0x110], xmm14
000073dfa87e4f27  mov eax, [r15+0x108]
000073dfa87e4f2e  sahf
000073dfa87e4f2f  jnz 0x000073DFA87E4F61
000073dfa87e4f31  cmp dword ptr [r15+0x318], 0x00
000073dfa87e4f39  jz 0x000073DFA87E5030
000073dfa87e4f3f  nop [rax+rax*1], ax
000073dfa87e4f48  nop [rax+rax*1], eax
000073dfa87e4f50  mov eax, 0x410704
000073dfa87e4f55  mov [r15+0x100], rax
000073dfa87e4f5c  jmp 0x000073DFA85FE110
000073dfa87e4f61  cmp dword ptr [r15+0x318], 0x00
000073dfa87e4f69  jz 0x000073DFA87E4E70
000073dfa87e4f6f  nop [rax+rax*1], ax
000073dfa87e4f78  nop [rax+rax*1], eax
000073dfa87e4f80  mov eax, 0x4106E8
000073dfa87e4f85  mov [r15+0x100], rax
000073dfa87e4f8c  jmp 0x000073DFA85FE110
000073dfa87e4f91  int3
000073dfa87e4f92  call 0x000073DFA86B52F0
000073dfa87e4f97  jmp 0x000073DFA87E4E82
000073dfa87e4f9c  ucomisd xmm1, xmm14
000073dfa87e4fa1  jp 0x000073DFA87E4FB0
000073dfa87e4fa3  movaps xmm13, [0x000073DFA83FE060]
000073dfa87e4fab  jmp 0x000073DFA87E4EED
000073dfa87e4fb0  vxorps xmm0, xmm1, xmm14
000073dfa87e4fb5  pextrw eax, xmm0, 0x03
000073dfa87e4fba  and eax, 0x7FF8
000073dfa87e4fbf  cmp eax, 0x08
000073dfa87e4fc2  jnz 0x000073DFA87E4EED
000073dfa87e4fc8  movq rax, xmm14
000073dfa87e4fcd  shl rax, 0x0D
000073dfa87e4fd1  jbe 0x000073DFA87E4EED
000073dfa87e4fd7  vorps xmm13, xmm14, [0x000073DFA83FE070]
000073dfa87e4fdf  jmp 0x000073DFA87E4EED
000073dfa87e4fe4  ucomisd xmm1, xmm15
000073dfa87e4fe9  jp 0x000073DFA87E4FF8
000073dfa87e4feb  movaps xmm14, [0x000073DFA83FE060]
000073dfa87e4ff3  jmp 0x000073DFA87E4F1A
000073dfa87e4ff8  vxorps xmm0, xmm1, xmm15
000073dfa87e4ffd  pextrw eax, xmm0, 0x03
000073dfa87e5002  and eax, 0x7FF8
000073dfa87e5007  cmp eax, 0x08
000073dfa87e500a  jnz 0x000073DFA87E4F1A
000073dfa87e5010  movq rax, xmm15
000073dfa87e5015  shl rax, 0x0D
000073dfa87e5019  jbe 0x000073DFA87E4F1A
000073dfa87e501f  vorps xmm14, xmm15, [0x000073DFA83FE070]
000073dfa87e5027  jmp 0x000073DFA87E4F1A
000073dfa87e502c  int3
000073dfa87e502d  nop [rax], eax
000073dfa87e5030  mov rax, [r15+0xF8]
000073dfa87e5037  lea r14, [rax+0x1D0]
000073dfa87e503e  mov r12, [r13+r14*1]
000073dfa87e5043  lea r14, [rax+0x1D8]
000073dfa87e504a  mov r11, [r13+r14*1]
000073dfa87e504f  mov [r15+0xA0], r12
000073dfa87e5056  mov [r15+0x98], r11
000073dfa87e505d  mov r14, [r15+0x40]
000073dfa87e5061  lea r12, [r14+0xCC0]
000073dfa87e5068  movaps xmm1, [r15+0x110]
000073dfa87e5070  movq r14, xmm1
000073dfa87e5075  mov [r13+r12*1], r14
000073dfa87e507a  lea r14, [rax+0x1C0]
000073dfa87e5081  mov r12, [r13+r14*1]
000073dfa87e5086  lea r14, [rax+0x1C8]
000073dfa87e508d  mov r11, [r13+r14*1]
000073dfa87e5092  mov [r15+0xE8], r12
000073dfa87e5099  mov [r15+0xF0], r11
000073dfa87e50a0  lea r14, [rax+0x1B0]
000073dfa87e50a7  mov r12, [r13+r14*1]
000073dfa87e50ac  lea r14, [rax+0x1B8]
000073dfa87e50b3  mov r10, [r13+r14*1]
000073dfa87e50b8  movq xmm1, r12
000073dfa87e50bd  movq xmm15, r10
000073dfa87e50c2  movq xmm1, xmm1
000073dfa87e50c6  movq xmm1, xmm1
000073dfa87e50ca  movaps [r15+0x1A0], xmm1
000073dfa87e50d2  movq xmm15, xmm15
000073dfa87e50d7  movq xmm15, xmm15
000073dfa87e50dc  movaps [r15+0x190], xmm15
000073dfa87e50e4  lea r14, [rax+0x1A0]
000073dfa87e50eb  mov r12, [r13+r14*1]
000073dfa87e50f0  lea r14, [rax+0x1A8]
000073dfa87e50f7  mov r10, [r13+r14*1]
000073dfa87e50fc  movq xmm1, r12
000073dfa87e5101  movq xmm15, r10
000073dfa87e5106  movq xmm1, xmm1
000073dfa87e510a  movq xmm1, xmm1
000073dfa87e510e  movaps [r15+0x1C0], xmm1
000073dfa87e5116  movq xmm15, xmm15
000073dfa87e511b  movq xmm15, xmm15
000073dfa87e5120  movaps [r15+0x1B0], xmm15
000073dfa87e5128  lea r14, [rax+0x190]
000073dfa87e512f  mov r12, [r13+r14*1]
000073dfa87e5134  lea r14, [rax+0x198]
000073dfa87e513b  mov r10, [r13+r14*1]
000073dfa87e5140  movq xmm1, r12
000073dfa87e5145  movq xmm15, r10
000073dfa87e514a  movq xmm1, xmm1
000073dfa87e514e  movq xmm1, xmm1
000073dfa87e5152  movaps [r15+0x1E0], xmm1
000073dfa87e515a  movq xmm15, xmm15
000073dfa87e515f  movq xmm15, xmm15
000073dfa87e5164  movaps [r15+0x1D0], xmm15
000073dfa87e516c  lea r14, [rax+0x180]
000073dfa87e5173  mov r12, [r13+r14*1]
000073dfa87e5178  lea r14, [rax+0x188]
000073dfa87e517f  mov r10, [r13+r14*1]
000073dfa87e5184  movq xmm1, r12
000073dfa87e5189  movq xmm15, r10
000073dfa87e518e  movq xmm1, xmm1
000073dfa87e5192  movq xmm1, xmm1
000073dfa87e5196  movaps [r15+0x200], xmm1
000073dfa87e519e  movq xmm15, xmm15
000073dfa87e51a3  movq xmm15, xmm15
000073dfa87e51a8  movaps [r15+0x1F0], xmm15
000073dfa87e51b0  lea r14, [rax+0x1E0]
000073dfa87e51b7  mov [r15+0xF8], r14
000073dfa87e51be  mov [r15+0x100], r11
000073dfa87e51c5  jmp 0x000073DFA87CE5C0
000073dfa87e51ca  int3
000073dfa87e51cb  call 0x000073DFA86E27E0
000073dfa87e51d0  jmp 0x000073DFA87E5043
000073dfa87e51d5  call 0x000073DFA86E1570
000073dfa87e51da  jmp 0x000073DFA87E504F
000073dfa87e51df  call 0x000073DFA86C3FE0
000073dfa87e51e4  jmp 0x000073DFA87E507A
000073dfa87e51e9  call 0x000073DFA86E27E0
000073dfa87e51ee  jmp 0x000073DFA87E5086
000073dfa87e51f3  call 0x000073DFA86E1570
000073dfa87e51f8  jmp 0x000073DFA87E5092
000073dfa87e51fd  call 0x000073DFA86E27E0
000073dfa87e5202  jmp 0x000073DFA87E50AC
000073dfa87e5207  call 0x000073DFA86E0300
000073dfa87e520c  jmp 0x000073DFA87E50B8
000073dfa87e5211  call 0x000073DFA86E27E0
000073dfa87e5216  jmp 0x000073DFA87E50F0
000073dfa87e521b  call 0x000073DFA86E0300
000073dfa87e5220  jmp 0x000073DFA87E50FC
000073dfa87e5225  call 0x000073DFA86E27E0
000073dfa87e522a  jmp 0x000073DFA87E5134
000073dfa87e522f  call 0x000073DFA86E0300
000073dfa87e5234  jmp 0x000073DFA87E5140
000073dfa87e5239  call 0x000073DFA86E27E0
000073dfa87e523e  jmp 0x000073DFA87E5178
000073dfa87e5243  call 0x000073DFA86E0300
000073dfa87e5248  jmp 0x000073DFA87E5184
000073dfa87e524d  int3
000073dfa87e524e  nop
000073dfa87e5250  mov qword ptr [r15+0x100], 0x04
000073dfa87e525b  mov esi, 0x00
000073dfa87e5260  mov edx, 0x09
000073dfa87e5265  mov rdi, 0x7FFF0BF6EC90
000073dfa87e526f  mov rax, 0x593AA1C37970
000073dfa87e5279  call rax
000073dfa87e527b  cmp dword ptr [r15+0x318], 0x00
000073dfa87e5283  jnz 0x000073DFA85FE110
000073dfa87e5289  jmp 0x000073DFA85FE0A0
000073dfa87e528e  int3
000073dfa87e528f  int3
