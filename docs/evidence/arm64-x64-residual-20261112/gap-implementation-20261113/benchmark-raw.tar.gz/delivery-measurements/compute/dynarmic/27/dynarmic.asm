000071ff71bce69b  nop [rax+rax*1], eax
000071ff71bce6a0  mov rax, [r15+0xF8]
000071ff71bce6a7  lea r14, [rax-0x1E0]
000071ff71bce6ae  mov [r15+0xF8], r14
000071ff71bce6b5  lea rax, [r14+0x1D0]
000071ff71bce6bc  mov r12, [r15+0xA0]
000071ff71bce6c3  mov r11, [r15+0x98]
000071ff71bce6ca  mov [r13+rax*1], r12
000071ff71bce6cf  lea rax, [r14+0x1D8]
000071ff71bce6d6  mov [r13+rax*1], r11
000071ff71bce6db  mov eax, 0x420AA0
000071ff71bce6e0  movups xmm1, [r13+rax*1]
000071ff71bce6e6  mov eax, 0x420A30
000071ff71bce6eb  movups xmm15, [r13+rax*1]
000071ff71bce6f1  mov eax, 0x420AC0
000071ff71bce6f6  movups xmm14, [r13+rax*1]
000071ff71bce6fc  mov eax, 0x420A60
000071ff71bce701  movups xmm13, [r13+rax*1]
000071ff71bce707  mov qword ptr [r15+0x98], 0x430CD0
000071ff71bce712  mov eax, 0x420AD0
000071ff71bce717  movups xmm12, [r13+rax*1]
000071ff71bce71d  mov eax, 0x430CD0
000071ff71bce722  movups [r13+rax*1], xmm1
000071ff71bce728  mov eax, 0x430CE0
000071ff71bce72d  movups [r13+rax*1], xmm15
000071ff71bce733  mov eax, 0x430CF0
000071ff71bce738  movups [r13+rax*1], xmm14
000071ff71bce73e  mov eax, 0x430D00
000071ff71bce743  movups [r13+rax*1], xmm13
000071ff71bce749  mov eax, 0x420A20
000071ff71bce74e  movups xmm14, [r13+rax*1]
000071ff71bce754  mov eax, 0x420A10
000071ff71bce759  movups xmm13, [r13+rax*1]
000071ff71bce75f  mov eax, 0x430DD0
000071ff71bce764  movups [r13+rax*1], xmm1
000071ff71bce76a  mov eax, 0x430DE0
000071ff71bce76f  movups [r13+rax*1], xmm15
000071ff71bce775  mov eax, 0x430D10
000071ff71bce77a  movups [r13+rax*1], xmm12
000071ff71bce780  mov eax, 0x430D20
000071ff71bce785  movups [r13+rax*1], xmm14
000071ff71bce78b  mov eax, 0x420A00
000071ff71bce790  movups xmm1, [r13+rax*1]
000071ff71bce796  mov eax, 0x420A70
000071ff71bce79b  movups xmm15, [r13+rax*1]
000071ff71bce7a1  mov eax, 0x430D30
000071ff71bce7a6  movups [r13+rax*1], xmm13
000071ff71bce7ac  mov eax, 0x430D40
000071ff71bce7b1  movups [r13+rax*1], xmm1
000071ff71bce7b7  mov eax, 0x420A80
000071ff71bce7bc  movups xmm1, [r13+rax*1]
000071ff71bce7c2  mov eax, 0x420A50
000071ff71bce7c7  movups xmm14, [r13+rax*1]
000071ff71bce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000071ff71bce7d5  mov eax, 0x430D50
000071ff71bce7da  movups [r13+rax*1], xmm15
000071ff71bce7e0  mov eax, 0x430D60
000071ff71bce7e5  movups [r13+rax*1], xmm1
000071ff71bce7eb  mov eax, 0x420AF0
000071ff71bce7f0  movups xmm1, [r13+rax*1]
000071ff71bce7f6  mov eax, 0x420B00
000071ff71bce7fb  movups xmm15, [r13+rax*1]
000071ff71bce801  movaps [r15+0x150], xmm15
000071ff71bce809  mov qword ptr [r15+0xA0], 0x3E8
000071ff71bce814  mov eax, 0x430D70
000071ff71bce819  movups [r13+rax*1], xmm14
000071ff71bce81f  mov eax, 0x430D80
000071ff71bce824  movups [r13+rax*1], xmm1
000071ff71bce82a  mov eax, 0x420AE0
000071ff71bce82f  movups xmm1, [r13+rax*1]
000071ff71bce835  mov eax, 0x420A90
000071ff71bce83a  movups xmm14, [r13+rax*1]
000071ff71bce840  movaps [r15+0x140], xmm14
000071ff71bce848  lea rax, [r14+0x180]
000071ff71bce84f  movq xmm13, qword ptr [r15+0x200]
000071ff71bce858  movq xmm12, qword ptr [r15+0x1F0]
000071ff71bce861  movq r12, xmm13
000071ff71bce866  movq r11, xmm12
000071ff71bce86b  mov [r13+rax*1], r12
000071ff71bce870  lea rax, [r14+0x188]
000071ff71bce877  mov [r13+rax*1], r11
000071ff71bce87c  mov eax, 0x430D90
000071ff71bce881  movups [r13+rax*1], xmm15
000071ff71bce887  mov eax, 0x430DA0
000071ff71bce88c  movups [r13+rax*1], xmm1
000071ff71bce892  mov eax, 0x420AB0
000071ff71bce897  movups xmm1, [r13+rax*1]
000071ff71bce89d  mov eax, 0x420B18
000071ff71bce8a2  mov r12, [r13+rax*1]
000071ff71bce8a7  movq xmm15, r12
000071ff71bce8ac  mov qword ptr [r15+0x40], 0x420B20
000071ff71bce8b4  mov eax, 0x430DB0
000071ff71bce8b9  movups [r13+rax*1], xmm14
000071ff71bce8bf  mov eax, 0x430DC0
000071ff71bce8c4  movups [r13+rax*1], xmm1
000071ff71bce8ca  mov eax, 0x420B80
000071ff71bce8cf  movups xmm1, [r13+rax*1]
000071ff71bce8d5  movq rax, xmm15
000071ff71bce8da  mov r12d, 0x430DF0
000071ff71bce8e0  mov [r13+r12*1], rax
000071ff71bce8e5  mov eax, 0x420B60
000071ff71bce8ea  movups xmm15, [r13+rax*1]
000071ff71bce8f0  mov eax, 0x420B70
000071ff71bce8f5  movups xmm14, [r13+rax*1]
000071ff71bce8fb  lea rax, [r14+0x160]
000071ff71bce902  movups [r13+rax*1], xmm1
000071ff71bce908  lea rax, [r14+0x190]
000071ff71bce90f  movq xmm1, qword ptr [r15+0x1E0]
000071ff71bce918  movq xmm13, qword ptr [r15+0x1D0]
000071ff71bce921  movq r12, xmm1
000071ff71bce926  movq r11, xmm13
000071ff71bce92b  mov [r13+rax*1], r12
000071ff71bce930  lea rax, [r14+0x198]
000071ff71bce937  mov [r13+rax*1], r11
000071ff71bce93c  lea rax, [r14+0x140]
000071ff71bce943  movups [r13+rax*1], xmm15
000071ff71bce949  lea rax, [r14+0x150]
000071ff71bce950  movups [r13+rax*1], xmm14
000071ff71bce956  mov eax, 0x420B20
000071ff71bce95b  movups xmm1, [r13+rax*1]
000071ff71bce961  mov eax, 0x420B30
000071ff71bce966  movups xmm15, [r13+rax*1]
000071ff71bce96c  movaps [r15+0x120], xmm15
000071ff71bce974  lea rax, [r14+0x1A0]
000071ff71bce97b  movq xmm14, qword ptr [r15+0x1C0]
000071ff71bce984  movq xmm13, qword ptr [r15+0x1B0]
000071ff71bce98d  movq r12, xmm14
000071ff71bce992  movq r11, xmm13
000071ff71bce997  mov [r13+rax*1], r12
000071ff71bce99c  lea rax, [r14+0x1A8]
000071ff71bce9a3  mov [r13+rax*1], r11
000071ff71bce9a8  lea rax, [r14+0x1B0]
000071ff71bce9af  movq xmm14, qword ptr [r15+0x1A0]
000071ff71bce9b8  movq xmm13, qword ptr [r15+0x190]
000071ff71bce9c1  movq r12, xmm14
000071ff71bce9c6  movq r11, xmm13
000071ff71bce9cb  mov [r13+rax*1], r12
000071ff71bce9d0  lea rax, [r14+0x1B8]
000071ff71bce9d7  mov [r13+rax*1], r11
000071ff71bce9dc  lea rax, [r14+0x100]
000071ff71bce9e3  movups [r13+rax*1], xmm1
000071ff71bce9e9  lea rax, [r14+0x110]
000071ff71bce9f0  movups [r13+rax*1], xmm15
000071ff71bce9f6  mov eax, 0x420B40
000071ff71bce9fb  movups xmm1, [r13+rax*1]
000071ff71bcea01  mov eax, 0x420B50
000071ff71bcea06  movups xmm15, [r13+rax*1]
000071ff71bcea0c  movaps [r15+0x110], xmm1
000071ff71bcea14  movaps [r15+0x130], xmm15
000071ff71bcea1c  lea rax, [r14+0x1C0]
000071ff71bcea23  mov r12, [r15+0xE8]
000071ff71bcea2a  mov r11, [r15+0xF0]
000071ff71bcea31  mov [r13+rax*1], r12
000071ff71bcea36  lea rax, [r14+0x1C8]
000071ff71bcea3d  mov [r13+rax*1], r11
000071ff71bcea42  mov eax, 0x430DF8
000071ff71bcea47  mov r12d, 0x421DF8D3
000071ff71bcea4d  mov [r13+rax*1], r12d
000071ff71bcea52  lea rax, [r14+0x120]
000071ff71bcea59  movups [r13+rax*1], xmm1
000071ff71bcea5f  lea rax, [r14+0x130]
000071ff71bcea66  movups [r13+rax*1], xmm15
000071ff71bcea6c  lea rax, [r14+0x100]
000071ff71bcea73  mov [r15], rax
000071ff71bcea76  mov qword ptr [r15+0x08], 0x430CD0
000071ff71bcea7e  mov qword ptr [r15+0x10], 0x12C
000071ff71bcea86  mov qword ptr [r15+0xF0], 0x410284
000071ff71bcea91  mov r14d, [r15+0x320]
000071ff71bcea98  mov eax, 0x410284
000071ff71bcea9d  mov rcx, 0x71FF71BD07C0
000071ff71bceaa7  mov [r15+r14*8+0x328], rax
000071ff71bceaaf  mov [r15+r14*8+0x368], rcx
000071ff71bceab7  add r14d, 0x01
000071ff71bceabb  and r14d, 0x07
000071ff71bceabf  mov [r15+0x320], r14d
000071ff71bceac6  cmp dword ptr [r15+0x318], 0x00
000071ff71bceace  jz 0x000071FF71BCED70
000071ff71bcead4  nop [rax+rax*1], ax
000071ff71bceadd  nop [rax+rax*1], eax
000071ff71bceae5  mov eax, 0x410728
000071ff71bceaea  mov [r15+0x100], rax
000071ff71bceaf1  jmp 0x000071FF719FE110
000071ff71bceaf6  int3
000071ff71bceaf7  call 0x000071FF71A0BC20
000071ff71bceafc  jmp 0x000071FF71BCE6CF
000071ff71bceb01  call 0x000071FF71A0A9A0
000071ff71bceb06  jmp 0x000071FF71BCE6DB
000071ff71bceb0b  call 0x000071FF719FF430
000071ff71bceb10  jmp 0x000071FF71BCE6E6
000071ff71bceb15  call 0x000071FF71A0E760
000071ff71bceb1a  jmp 0x000071FF71BCE6F1
000071ff71bceb1f  call 0x000071FF71A0D4E0
000071ff71bceb24  jmp 0x000071FF71BCE6FC
000071ff71bceb29  call 0x000071FF71A0C260
000071ff71bceb2e  jmp 0x000071FF71BCE707
000071ff71bceb33  call 0x000071FF71A0AFE0
000071ff71bceb38  jmp 0x000071FF71BCE71D
000071ff71bceb3d  call 0x000071FF719FF540
000071ff71bceb42  jmp 0x000071FF71BCE728
000071ff71bceb47  call 0x000071FF71A0E880
000071ff71bceb4c  jmp 0x000071FF71BCE733
000071ff71bceb51  call 0x000071FF71A0D600
000071ff71bceb56  jmp 0x000071FF71BCE73E
000071ff71bceb5b  call 0x000071FF71A0C380
000071ff71bceb60  jmp 0x000071FF71BCE749
000071ff71bceb65  call 0x000071FF71A0D4E0
000071ff71bceb6a  jmp 0x000071FF71BCE754
000071ff71bceb6f  call 0x000071FF71A0C260
000071ff71bceb74  jmp 0x000071FF71BCE75F
000071ff71bceb79  call 0x000071FF719FF540
000071ff71bceb7e  jmp 0x000071FF71BCE76A
000071ff71bceb83  call 0x000071FF71A0E880
000071ff71bceb88  jmp 0x000071FF71BCE775
000071ff71bceb8d  call 0x000071FF71A0B100
000071ff71bceb92  jmp 0x000071FF71BCE780
000071ff71bceb97  call 0x000071FF71A0D600
000071ff71bceb9c  jmp 0x000071FF71BCE78B
000071ff71bceba1  call 0x000071FF719FF430
000071ff71bceba6  jmp 0x000071FF71BCE796
000071ff71bcebab  call 0x000071FF71A0E760
000071ff71bcebb0  jmp 0x000071FF71BCE7A1
000071ff71bcebb5  call 0x000071FF71A0C380
000071ff71bcebba  jmp 0x000071FF71BCE7AC
000071ff71bcebbf  call 0x000071FF719FF540
000071ff71bcebc4  jmp 0x000071FF71BCE7B7
000071ff71bcebc9  call 0x000071FF719FF430
000071ff71bcebce  jmp 0x000071FF71BCE7C2
000071ff71bcebd3  call 0x000071FF71A0D4E0
000071ff71bcebd8  jmp 0x000071FF71BCE7CD
000071ff71bcebdd  call 0x000071FF71A0E880
000071ff71bcebe2  jmp 0x000071FF71BCE7E0
000071ff71bcebe7  call 0x000071FF719FF540
000071ff71bcebec  jmp 0x000071FF71BCE7EB
000071ff71bcebf1  call 0x000071FF719FF430
000071ff71bcebf6  jmp 0x000071FF71BCE7F6
000071ff71bcebfb  call 0x000071FF71A0E760
000071ff71bcec00  jmp 0x000071FF71BCE801
000071ff71bcec05  call 0x000071FF71A0D600
000071ff71bcec0a  jmp 0x000071FF71BCE81F
000071ff71bcec0f  call 0x000071FF719FF540
000071ff71bcec14  jmp 0x000071FF71BCE82A
000071ff71bcec19  call 0x000071FF719FF430
000071ff71bcec1e  jmp 0x000071FF71BCE835
000071ff71bcec23  call 0x000071FF71A0D4E0
000071ff71bcec28  jmp 0x000071FF71BCE840
000071ff71bcec2d  call 0x000071FF71A0BC20
000071ff71bcec32  jmp 0x000071FF71BCE870
000071ff71bcec37  call 0x000071FF71A0A9A0
000071ff71bcec3c  jmp 0x000071FF71BCE87C
000071ff71bcec41  call 0x000071FF71A0E880
000071ff71bcec46  jmp 0x000071FF71BCE887
000071ff71bcec4b  call 0x000071FF719FF540
000071ff71bcec50  jmp 0x000071FF71BCE892
000071ff71bcec55  call 0x000071FF719FF430
000071ff71bcec5a  jmp 0x000071FF71BCE89D
000071ff71bcec5f  call 0x000071FF71A0B720
000071ff71bcec64  jmp 0x000071FF71BCE8A7
000071ff71bcec69  call 0x000071FF71A0D600
000071ff71bcec6e  jmp 0x000071FF71BCE8BF
000071ff71bcec73  call 0x000071FF719FF540
000071ff71bcec78  jmp 0x000071FF71BCE8CA
000071ff71bcec7d  call 0x000071FF719FF430
000071ff71bcec82  jmp 0x000071FF71BCE8D5
000071ff71bcec87  call 0x000071FF71AB4CB0
000071ff71bcec8c  jmp 0x000071FF71BCE8E5
000071ff71bcec91  call 0x000071FF71A0E760
000071ff71bcec96  jmp 0x000071FF71BCE8F0
000071ff71bcec9b  call 0x000071FF71A0D4E0
000071ff71bceca0  jmp 0x000071FF71BCE8FB
000071ff71bceca5  call 0x000071FF719FF540
000071ff71bcecaa  jmp 0x000071FF71BCE908
000071ff71bcecaf  call 0x000071FF71A0BC20
000071ff71bcecb4  jmp 0x000071FF71BCE930
000071ff71bcecb9  call 0x000071FF71A0A9A0
000071ff71bcecbe  jmp 0x000071FF71BCE93C
000071ff71bcecc3  call 0x000071FF71A0E880
000071ff71bcecc8  jmp 0x000071FF71BCE949
000071ff71bceccd  call 0x000071FF71A0D600
000071ff71bcecd2  jmp 0x000071FF71BCE956
000071ff71bcecd7  call 0x000071FF719FF430
000071ff71bcecdc  jmp 0x000071FF71BCE961
000071ff71bcece1  call 0x000071FF71A0E760
000071ff71bcece6  jmp 0x000071FF71BCE96C
000071ff71bceceb  call 0x000071FF71A0BC20
000071ff71bcecf0  jmp 0x000071FF71BCE99C
000071ff71bcecf5  call 0x000071FF71A0A9A0
000071ff71bcecfa  jmp 0x000071FF71BCE9A8
000071ff71bcecff  call 0x000071FF71A0BC20
000071ff71bced04  jmp 0x000071FF71BCE9D0
000071ff71bced09  call 0x000071FF71A0A9A0
000071ff71bced0e  jmp 0x000071FF71BCE9DC
000071ff71bced13  call 0x000071FF719FF540
000071ff71bced18  jmp 0x000071FF71BCE9E9
000071ff71bced1d  call 0x000071FF71A0E880
000071ff71bced22  jmp 0x000071FF71BCE9F6
000071ff71bced27  call 0x000071FF719FF430
000071ff71bced2c  jmp 0x000071FF71BCEA01
000071ff71bced31  call 0x000071FF71A0E760
000071ff71bced36  jmp 0x000071FF71BCEA0C
000071ff71bced3b  call 0x000071FF71A0BC20
000071ff71bced40  jmp 0x000071FF71BCEA36
000071ff71bced45  call 0x000071FF71A0A9A0
000071ff71bced4a  jmp 0x000071FF71BCEA42
000071ff71bced4f  call 0x000071FF71A0BAE0
000071ff71bced54  jmp 0x000071FF71BCEA52
000071ff71bced59  call 0x000071FF719FF540
000071ff71bced5e  jmp 0x000071FF71BCEA5F
000071ff71bced63  call 0x000071FF71A0E880
000071ff71bced68  jmp 0x000071FF71BCEA6C
000071ff71bced6d  int3
000071ff71bced6e  nop
000071ff71bced70  mov rax, [r15]
000071ff71bced73  lea r14, [rax+0x20]
000071ff71bced77  mov r12, [r13+r14*1]
000071ff71bced7c  mov r14, [r15+0x10]
000071ff71bced80  lea r11, [r12+r14*1]
000071ff71bced84  mov [r15+0x40], r11
000071ff71bced88  lea r12, [rax+0x20]
000071ff71bced8c  mov [r13+r12*1], r11
000071ff71bced91  test r14, r14
000071ff71bced94  setz r14b
000071ff71bced98  movzx r14, r14b
000071ff71bced9c  mov [rsp+0x414], r14b
000071ff71bceda4  cmp byte ptr [rsp+0x414], 0x00
000071ff71bcedac  jz 0x000071FF71BCEDDE
000071ff71bcedae  cmp dword ptr [r15+0x318], 0x00
000071ff71bcedb6  mov eax, 0x4109A0
000071ff71bcedbb  mov [r15+0x100], rax
000071ff71bcedc2  jz 0x000071FF719FE0A0
000071ff71bcedc8  nop [rax+rax*1], eax
000071ff71bcedcd  mov eax, 0x4109A0
000071ff71bcedd2  mov [r15+0x100], rax
000071ff71bcedd9  jmp 0x000071FF719FE110
000071ff71bcedde  cmp dword ptr [r15+0x318], 0x00
000071ff71bcede6  jz 0x000071FF71BCEE30
000071ff71bcedec  nop [rax+rax*1], ax
000071ff71bcedf5  nop [rax+rax*1], eax
000071ff71bcedfd  mov eax, 0x410738
000071ff71bcee02  mov [r15+0x100], rax
000071ff71bcee09  jmp 0x000071FF719FE110
000071ff71bcee0e  int3
000071ff71bcee0f  call 0x000071FF71AE27E0
000071ff71bcee14  jmp 0x000071FF71BCED7C
000071ff71bcee19  call 0x000071FF71AC0860
000071ff71bcee1e  jmp 0x000071FF71BCED91
000071ff71bcee23  int3
000071ff71bcee24  nop [rax+rax*1], ax
000071ff71bcee2d  nop [rax], eax
000071ff71bcee30  mov rax, [r15+0xF8]
000071ff71bcee37  lea r14, [rax-0x150]
000071ff71bcee3e  mov [r15+0xF8], r14
000071ff71bcee45  mov rax, [r15]
000071ff71bcee48  lea r12, [rax+0x68]
000071ff71bcee4c  mov r11, [r13+r12*1]
000071ff71bcee51  mov [r15+0x88], r11
000071ff71bcee58  lea r12, [rax+0x28]
000071ff71bcee5c  mov [r15+0x40], r12
000071ff71bcee60  mov [r15+0x48], r14
000071ff71bcee64  mov qword ptr [r15+0x50], 0x420B90
000071ff71bcee6c  lea rax, [r14+0x100]
000071ff71bcee73  mov r12, [r15+0xE8]
000071ff71bcee7a  mov r11, [r15+0xD8]
000071ff71bcee81  mov [r13+rax*1], r12
000071ff71bcee86  lea rax, [r14+0x108]
000071ff71bcee8d  mov [r13+rax*1], r11
000071ff71bcee92  lea rax, [r14+0x110]
000071ff71bcee99  mov r12, [r15+0xD0]
000071ff71bceea0  mov r11, [r15+0xC8]
000071ff71bceea7  mov [r13+rax*1], r12
000071ff71bceeac  lea rax, [r14+0x118]
000071ff71bceeb3  mov [r13+rax*1], r11
000071ff71bceeb8  lea rax, [r14+0x120]
000071ff71bceebf  mov r12, [r15+0xC0]
000071ff71bceec6  mov r11, [r15+0xB8]
000071ff71bceecd  mov [r13+rax*1], r12
000071ff71bceed2  lea rax, [r14+0x128]
000071ff71bceed9  mov [r13+rax*1], r11
000071ff71bceede  lea rax, [r14+0x130]
000071ff71bceee5  mov r12, [r15+0xB0]
000071ff71bceeec  mov r11, [r15+0xA8]
000071ff71bceef3  mov [r13+rax*1], r12
000071ff71bceef8  lea rax, [r14+0x138]
000071ff71bceeff  mov [r13+rax*1], r11
000071ff71bcef04  lea rax, [r14+0x140]
000071ff71bcef0b  mov r12, [r15+0xA0]
000071ff71bcef12  mov r11, [r15+0x98]
000071ff71bcef19  mov [r13+rax*1], r12
000071ff71bcef1e  lea rax, [r14+0x148]
000071ff71bcef25  mov [r13+rax*1], r11
000071ff71bcef2a  cmp dword ptr [r15+0x318], 0x00
000071ff71bcef32  jz 0x000071FF71BCEFD0
000071ff71bcef38  nop [rax+rax*1], ax
000071ff71bcef41  nop [rax+rax*1], eax
000071ff71bcef49  mov eax, 0x410770
000071ff71bcef4e  mov [r15+0x100], rax
000071ff71bcef55  jmp 0x000071FF719FE110
000071ff71bcef5a  int3
000071ff71bcef5b  call 0x000071FF71AC0370
000071ff71bcef60  jmp 0x000071FF71BCEE51
000071ff71bcef65  call 0x000071FF71A0BC20
000071ff71bcef6a  jmp 0x000071FF71BCEE86
000071ff71bcef6f  call 0x000071FF71A0A9A0
000071ff71bcef74  jmp 0x000071FF71BCEE92
000071ff71bcef79  call 0x000071FF71A0BC20
000071ff71bcef7e  jmp 0x000071FF71BCEEAC
000071ff71bcef83  call 0x000071FF71A0A9A0
000071ff71bcef88  jmp 0x000071FF71BCEEB8
000071ff71bcef8d  call 0x000071FF71A0BC20
000071ff71bcef92  jmp 0x000071FF71BCEED2
000071ff71bcef97  call 0x000071FF71A0A9A0
000071ff71bcef9c  jmp 0x000071FF71BCEEDE
000071ff71bcefa1  call 0x000071FF71A0BC20
000071ff71bcefa6  jmp 0x000071FF71BCEEF8
000071ff71bcefab  call 0x000071FF71A0A9A0
000071ff71bcefb0  jmp 0x000071FF71BCEF04
000071ff71bcefb5  call 0x000071FF71A0BC20
000071ff71bcefba  jmp 0x000071FF71BCEF1E
000071ff71bcefbf  call 0x000071FF71A0A9A0
000071ff71bcefc4  jmp 0x000071FF71BCEF2A
000071ff71bcefc9  int3
000071ff71bcefca  nop [rax+rax*1], ax
000071ff71bcefd0  mov rax, [r15+0x08]
000071ff71bcefd4  movzx r14d, byte ptr [r13+rax*1]
000071ff71bcefda  movzx r14d, r14b
000071ff71bcefde  mov [rsp+0x10], r14d
000071ff71bcefe3  mov r14d, r14d
000071ff71bcefe6  mov [r15+0x58], r14
000071ff71bcefea  lea r14, [rax+0x01]
000071ff71bcefee  mov [r15+0x08], r14
000071ff71bceff2  mov rax, [r15+0x88]
000071ff71bceff9  lea r14, [rax+0x01]
000071ff71bceffd  mov r12, [r15]
000071ff71bcf000  lea r11, [r12+0x68]
000071ff71bcf005  mov [r13+r11*1], r14
000071ff71bcf00a  lea r14, [r12+rax*1]
000071ff71bcf00e  mov [r15+0x60], r14
000071ff71bcf012  lea rax, [r14+0x28]
000071ff71bcf016  mov r11d, [rsp+0x10]
000071ff71bcf01b  movzx r14d, r11b
000071ff71bcf01f  mov [r13+rax*1], r14b
000071ff71bcf024  lea rax, [r12+0x68]
000071ff71bcf029  mov r14, [r13+rax*1]
000071ff71bcf02e  mov [r15+0x88], r14
000071ff71bcf035  xor eax, eax
000071ff71bcf037  mov r12d, 0x40
000071ff71bcf03d  cmp r14, r12
000071ff71bcf040  cmc
000071ff71bcf041  lahf
000071ff71bcf042  seto al
000071ff71bcf045  mov [r15+0x108], eax
000071ff71bcf04c  mov eax, [r15+0x108]
000071ff71bcf053  sahf
000071ff71bcf054  jnz 0x000071FF71BCF086
000071ff71bcf056  cmp dword ptr [r15+0x318], 0x00
000071ff71bcf05e  jz 0x000071FF71BCF170
000071ff71bcf064  nop [rax+rax*1], ax
000071ff71bcf06d  nop [rax+rax*1], eax
000071ff71bcf075  mov eax, 0x410790
000071ff71bcf07a  mov [r15+0x100], rax
000071ff71bcf081  jmp 0x000071FF719FE110
000071ff71bcf086  cmp dword ptr [r15+0x318], 0x00
000071ff71bcf08e  jz 0x000071FF71BCF0E0
000071ff71bcf094  nop [rax+rax*1], ax
000071ff71bcf09d  nop [rax+rax*1], eax
000071ff71bcf0a5  mov eax, 0x410768
000071ff71bcf0aa  mov [r15+0x100], rax
000071ff71bcf0b1  jmp 0x000071FF719FE110
000071ff71bcf0b6  int3
000071ff71bcf0b7  call 0x000071FF71A0D860
000071ff71bcf0bc  jmp 0x000071FF71BCEFDA
000071ff71bcf0c1  call 0x000071FF71AB36E0
000071ff71bcf0c6  jmp 0x000071FF71BCF00A
000071ff71bcf0cb  call 0x000071FF71A0DD60
000071ff71bcf0d0  jmp 0x000071FF71BCF024
000071ff71bcf0d5  call 0x000071FF71A0DC20
000071ff71bcf0da  jmp 0x000071FF71BCF02E
000071ff71bcf0df  int3
000071ff71bcf0e0  mov rax, [r15+0x10]
000071ff71bcf0e4  lea r14, [rax-0x01]
000071ff71bcf0e8  mov [r15+0x10], r14
000071ff71bcf0ec  test r14, r14
000071ff71bcf0ef  setz r14b
000071ff71bcf0f3  movzx r14, r14b
000071ff71bcf0f7  mov [rsp+0x414], r14b
000071ff71bcf0ff  cmp byte ptr [rsp+0x414], 0x00
000071ff71bcf107  jz 0x000071FF71BCF139
000071ff71bcf109  cmp dword ptr [r15+0x318], 0x00
000071ff71bcf111  jz 0x000071FF71BD0670
000071ff71bcf117  nop [rax+rax*1], ax
000071ff71bcf120  nop [rax+rax*1], eax
000071ff71bcf128  mov eax, 0x410988
000071ff71bcf12d  mov [r15+0x100], rax
000071ff71bcf134  jmp 0x000071FF719FE110
000071ff71bcf139  cmp dword ptr [r15+0x318], 0x00
000071ff71bcf141  jz 0x000071FF71BCEFD0
000071ff71bcf147  nop [rax+rax*1], ax
000071ff71bcf150  nop [rax+rax*1], eax
000071ff71bcf158  mov eax, 0x410770
000071ff71bcf15d  mov [r15+0x100], rax
000071ff71bcf164  jmp 0x000071FF719FE110
000071ff71bcf169  int3
000071ff71bcf16a  int3
000071ff71bcf16b  nop [rax+rax*1], eax
000071ff71bcf170  mov rax, [r15+0x40]
000071ff71bcf174  movzx r14d, byte ptr [r13+rax*1]
000071ff71bcf17a  movaps xmm1, [r15+0x110]
000071ff71bcf182  pinsrb xmm1, r14d, 0x00
000071ff71bcf189  lea r14, [rax+0x01]
000071ff71bcf18d  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf193  movaps xmm15, [r15+0x120]
000071ff71bcf19b  pinsrb xmm15, r12d, 0x00
000071ff71bcf1a2  lea r14, [rax+0x02]
000071ff71bcf1a6  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf1ac  movaps xmm14, [r15+0x130]
000071ff71bcf1b4  pinsrb xmm14, r12d, 0x00
000071ff71bcf1bb  lea r14, [rax+0x03]
000071ff71bcf1bf  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf1c5  movaps xmm13, [r15+0x140]
000071ff71bcf1cd  pinsrb xmm13, r12d, 0x00
000071ff71bcf1d4  lea r14, [rax+0x04]
000071ff71bcf1d8  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf1de  pinsrb xmm1, r12d, 0x01
000071ff71bcf1e5  lea r14, [rax+0x05]
000071ff71bcf1e9  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf1ef  pinsrb xmm15, r12d, 0x01
000071ff71bcf1f6  lea r14, [rax+0x06]
000071ff71bcf1fa  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf200  pinsrb xmm14, r12d, 0x01
000071ff71bcf207  lea r14, [rax+0x07]
000071ff71bcf20b  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf211  pinsrb xmm13, r12d, 0x01
000071ff71bcf218  lea r14, [rax+0x08]
000071ff71bcf21c  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf222  pinsrb xmm1, r12d, 0x02
000071ff71bcf229  lea r14, [rax+0x09]
000071ff71bcf22d  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf233  pinsrb xmm15, r12d, 0x02
000071ff71bcf23a  lea r14, [rax+0x0A]
000071ff71bcf23e  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf244  pinsrb xmm14, r12d, 0x02
000071ff71bcf24b  lea r14, [rax+0x0B]
000071ff71bcf24f  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf255  pinsrb xmm13, r12d, 0x02
000071ff71bcf25c  lea r14, [rax+0x0C]
000071ff71bcf260  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf266  pinsrb xmm1, r12d, 0x03
000071ff71bcf26d  lea r14, [rax+0x0D]
000071ff71bcf271  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf277  pinsrb xmm15, r12d, 0x03
000071ff71bcf27e  lea r14, [rax+0x0E]
000071ff71bcf282  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf288  pinsrb xmm14, r12d, 0x03
000071ff71bcf28f  lea r14, [rax+0x0F]
000071ff71bcf293  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf299  pinsrb xmm13, r12d, 0x03
000071ff71bcf2a0  lea r14, [rax+0x10]
000071ff71bcf2a4  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf2aa  pinsrb xmm1, r12d, 0x04
000071ff71bcf2b1  lea r14, [rax+0x11]
000071ff71bcf2b5  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf2bb  pinsrb xmm15, r12d, 0x04
000071ff71bcf2c2  lea r14, [rax+0x12]
000071ff71bcf2c6  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf2cc  pinsrb xmm14, r12d, 0x04
000071ff71bcf2d3  lea r14, [rax+0x13]
000071ff71bcf2d7  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf2dd  pinsrb xmm13, r12d, 0x04
000071ff71bcf2e4  lea r14, [rax+0x14]
000071ff71bcf2e8  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf2ee  pinsrb xmm1, r12d, 0x05
000071ff71bcf2f5  lea r14, [rax+0x15]
000071ff71bcf2f9  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf2ff  pinsrb xmm15, r12d, 0x05
000071ff71bcf306  lea r14, [rax+0x16]
000071ff71bcf30a  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf310  pinsrb xmm14, r12d, 0x05
000071ff71bcf317  lea r14, [rax+0x17]
000071ff71bcf31b  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf321  pinsrb xmm13, r12d, 0x05
000071ff71bcf328  lea r14, [rax+0x18]
000071ff71bcf32c  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf332  pinsrb xmm1, r12d, 0x06
000071ff71bcf339  lea r14, [rax+0x19]
000071ff71bcf33d  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf343  pinsrb xmm15, r12d, 0x06
000071ff71bcf34a  lea r14, [rax+0x1A]
000071ff71bcf34e  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf354  pinsrb xmm14, r12d, 0x06
000071ff71bcf35b  lea r14, [rax+0x1B]
000071ff71bcf35f  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf365  pinsrb xmm13, r12d, 0x06
000071ff71bcf36c  lea r14, [rax+0x1C]
000071ff71bcf370  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf376  pinsrb xmm1, r12d, 0x07
000071ff71bcf37d  lea r14, [rax+0x1D]
000071ff71bcf381  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf387  pinsrb xmm15, r12d, 0x07
000071ff71bcf38e  lea r14, [rax+0x1E]
000071ff71bcf392  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf398  pinsrb xmm14, r12d, 0x07
000071ff71bcf39f  lea r14, [rax+0x1F]
000071ff71bcf3a3  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf3a9  pinsrb xmm13, r12d, 0x07
000071ff71bcf3b0  lea r14, [rax+0x20]
000071ff71bcf3b4  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf3ba  pinsrb xmm1, r12d, 0x08
000071ff71bcf3c1  lea r14, [rax+0x21]
000071ff71bcf3c5  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf3cb  pinsrb xmm15, r12d, 0x08
000071ff71bcf3d2  lea r14, [rax+0x22]
000071ff71bcf3d6  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf3dc  pinsrb xmm14, r12d, 0x08
000071ff71bcf3e3  lea r14, [rax+0x23]
000071ff71bcf3e7  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf3ed  pinsrb xmm13, r12d, 0x08
000071ff71bcf3f4  lea r14, [rax+0x24]
000071ff71bcf3f8  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf3fe  pinsrb xmm1, r12d, 0x09
000071ff71bcf405  lea r14, [rax+0x25]
000071ff71bcf409  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf40f  pinsrb xmm15, r12d, 0x09
000071ff71bcf416  lea r14, [rax+0x26]
000071ff71bcf41a  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf420  pinsrb xmm14, r12d, 0x09
000071ff71bcf427  lea r14, [rax+0x27]
000071ff71bcf42b  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf431  pinsrb xmm13, r12d, 0x09
000071ff71bcf438  lea r14, [rax+0x28]
000071ff71bcf43c  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf442  pinsrb xmm1, r12d, 0x0A
000071ff71bcf449  lea r14, [rax+0x29]
000071ff71bcf44d  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf453  pinsrb xmm15, r12d, 0x0A
000071ff71bcf45a  lea r14, [rax+0x2A]
000071ff71bcf45e  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf464  pinsrb xmm14, r12d, 0x0A
000071ff71bcf46b  lea r14, [rax+0x2B]
000071ff71bcf46f  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf475  pinsrb xmm13, r12d, 0x0A
000071ff71bcf47c  lea r14, [rax+0x2C]
000071ff71bcf480  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf486  pinsrb xmm1, r12d, 0x0B
000071ff71bcf48d  lea r14, [rax+0x2D]
000071ff71bcf491  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf497  pinsrb xmm15, r12d, 0x0B
000071ff71bcf49e  lea r14, [rax+0x2E]
000071ff71bcf4a2  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf4a8  pinsrb xmm14, r12d, 0x0B
000071ff71bcf4af  lea r14, [rax+0x2F]
000071ff71bcf4b3  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf4b9  pinsrb xmm13, r12d, 0x0B
000071ff71bcf4c0  lea r14, [rax+0x30]
000071ff71bcf4c4  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf4ca  pinsrb xmm1, r12d, 0x0C
000071ff71bcf4d1  lea r14, [rax+0x31]
000071ff71bcf4d5  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf4db  pinsrb xmm15, r12d, 0x0C
000071ff71bcf4e2  lea r14, [rax+0x32]
000071ff71bcf4e6  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf4ec  pinsrb xmm14, r12d, 0x0C
000071ff71bcf4f3  lea r14, [rax+0x33]
000071ff71bcf4f7  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf4fd  pinsrb xmm13, r12d, 0x0C
000071ff71bcf504  lea r14, [rax+0x34]
000071ff71bcf508  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf50e  pinsrb xmm1, r12d, 0x0D
000071ff71bcf515  lea r14, [rax+0x35]
000071ff71bcf519  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf51f  pinsrb xmm15, r12d, 0x0D
000071ff71bcf526  lea r14, [rax+0x36]
000071ff71bcf52a  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf530  pinsrb xmm14, r12d, 0x0D
000071ff71bcf537  lea r14, [rax+0x37]
000071ff71bcf53b  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf541  pinsrb xmm13, r12d, 0x0D
000071ff71bcf548  lea r14, [rax+0x38]
000071ff71bcf54c  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf552  pinsrb xmm1, r12d, 0x0E
000071ff71bcf559  lea r14, [rax+0x39]
000071ff71bcf55d  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf563  pinsrb xmm15, r12d, 0x0E
000071ff71bcf56a  lea r14, [rax+0x3A]
000071ff71bcf56e  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf574  pinsrb xmm14, r12d, 0x0E
000071ff71bcf57b  lea r14, [rax+0x3B]
000071ff71bcf57f  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf585  pinsrb xmm13, r12d, 0x0E
000071ff71bcf58c  lea r14, [rax+0x3C]
000071ff71bcf590  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf596  pinsrb xmm1, r12d, 0x0F
000071ff71bcf59d  movaps [r15+0x110], xmm1
000071ff71bcf5a5  lea r14, [rax+0x3D]
000071ff71bcf5a9  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf5af  pinsrb xmm15, r12d, 0x0F
000071ff71bcf5b6  movaps [r15+0x120], xmm15
000071ff71bcf5be  lea r14, [rax+0x3E]
000071ff71bcf5c2  movzx r12d, byte ptr [r13+r14*1]
000071ff71bcf5c8  pinsrb xmm14, r12d, 0x0F
000071ff71bcf5cf  movaps [r15+0x130], xmm14
000071ff71bcf5d7  lea r14, [rax+0x3F]
000071ff71bcf5db  movzx eax, byte ptr [r13+r14*1]
000071ff71bcf5e1  pinsrb xmm13, eax, 0x0F
000071ff71bcf5e8  movaps [r15+0x140], xmm13
000071ff71bcf5f0  movq xmm1, qword ptr [r15+0x120]
000071ff71bcf5f9  pmovzxbw xmm1, xmm1
000071ff71bcf5fe  psllw xmm1, 0x00
000071ff71bcf603  movaps [r15+0x150], xmm1
000071ff71bcf60b  movq xmm1, qword ptr [r15+0x130]
000071ff71bcf614  pmovzxbw xmm1, xmm1
000071ff71bcf619  psllw xmm1, 0x00
000071ff71bcf61e  movaps [r15+0x160], xmm1
000071ff71bcf626  movq xmm1, qword ptr [r15+0x110]
000071ff71bcf62f  pmovzxbw xmm1, xmm1
000071ff71bcf634  psllw xmm1, 0x00
000071ff71bcf639  movaps [r15+0x170], xmm1
000071ff71bcf641  movaps xmm15, [r15+0x110]
000071ff71bcf649  pextrq rax, xmm15, 0x01
000071ff71bcf650  movq xmm15, rax
000071ff71bcf655  pmovzxbw xmm15, xmm15
000071ff71bcf65b  psllw xmm15, 0x00
000071ff71bcf661  movaps [r15+0x180], xmm15
000071ff71bcf669  movaps xmm14, [r15+0x120]
000071ff71bcf671  pextrq rax, xmm14, 0x01
000071ff71bcf678  movq xmm14, rax
000071ff71bcf67d  pmovzxbw xmm14, xmm14
000071ff71bcf683  psllw xmm14, 0x00
000071ff71bcf689  movaps [r15+0x210], xmm14
000071ff71bcf691  movaps xmm13, [r15+0x130]
000071ff71bcf699  pextrq rax, xmm13, 0x01
000071ff71bcf6a0  movq xmm13, rax
000071ff71bcf6a5  pmovzxbw xmm13, xmm13
000071ff71bcf6ab  psllw xmm13, 0x00
000071ff71bcf6b1  movaps [r15+0x220], xmm13
000071ff71bcf6b9  movq xmm12, qword ptr [r15+0x140]
000071ff71bcf6c2  pmovzxbw xmm12, xmm12
000071ff71bcf6c8  psllw xmm12, 0x00
000071ff71bcf6ce  movaps [r15+0x250], xmm12
000071ff71bcf6d6  movaps xmm12, [r15+0x140]
000071ff71bcf6de  pextrq rax, xmm12, 0x01
000071ff71bcf6e5  movq xmm12, rax
000071ff71bcf6ea  pmovzxbw xmm12, xmm12
000071ff71bcf6f0  psllw xmm12, 0x00
000071ff71bcf6f6  movaps [r15+0x110], xmm12
000071ff71bcf6fe  movq xmm11, qword ptr [r15+0x150]
000071ff71bcf707  pmovzxwd xmm11, xmm11
000071ff71bcf70d  pslld xmm11, 0x10
000071ff71bcf713  movq xmm10, qword ptr [r15+0x160]
000071ff71bcf71c  pmovzxwd xmm10, xmm10
000071ff71bcf722  pslld xmm10, 0x08
000071ff71bcf728  pextrq rax, xmm1, 0x01
000071ff71bcf72f  movq xmm1, rax
000071ff71bcf734  pmovzxwd xmm1, xmm1
000071ff71bcf739  pslld xmm1, 0x00
000071ff71bcf73e  movaps [r15+0x260], xmm1
000071ff71bcf746  pextrq rax, xmm15, 0x01
000071ff71bcf74d  movq xmm15, rax
000071ff71bcf752  pmovzxwd xmm15, xmm15
000071ff71bcf758  pslld xmm15, 0x00
000071ff71bcf75e  movaps [r15+0x270], xmm15
000071ff71bcf766  movq xmm9, qword ptr [r15+0x170]
000071ff71bcf76f  pmovzxwd xmm9, xmm9
000071ff71bcf775  pslld xmm9, 0x00
000071ff71bcf77b  pextrq rax, xmm14, 0x01
000071ff71bcf782  movq xmm14, rax
000071ff71bcf787  pmovzxwd xmm14, xmm14
000071ff71bcf78d  pslld xmm14, 0x10
000071ff71bcf793  movaps [r15+0x280], xmm14
000071ff71bcf79b  movq xmm8, qword ptr [r15+0x180]
000071ff71bcf7a4  pmovzxwd xmm8, xmm8
000071ff71bcf7aa  pslld xmm8, 0x00
000071ff71bcf7b0  movq xmm7, qword ptr [r15+0x210]
000071ff71bcf7b9  pmovzxwd xmm7, xmm7
000071ff71bcf7be  pslld xmm7, 0x10
000071ff71bcf7c3  movaps xmm6, [r15+0x150]
000071ff71bcf7cb  pextrq rax, xmm6, 0x01
000071ff71bcf7d2  movq xmm6, rax
000071ff71bcf7d7  pmovzxwd xmm6, xmm6
000071ff71bcf7dc  pslld xmm6, 0x10
000071ff71bcf7e1  por xmm11, xmm10
000071ff71bcf7e6  movaps [r15+0x230], xmm11
000071ff71bcf7ee  pextrq rax, xmm13, 0x01
000071ff71bcf7f5  movq xmm13, rax
000071ff71bcf7fa  pmovzxwd xmm13, xmm13
000071ff71bcf800  pslld xmm13, 0x08
000071ff71bcf806  movaps [r15+0x240], xmm13
000071ff71bcf80e  movq xmm10, qword ptr [r15+0x220]
000071ff71bcf817  pmovzxwd xmm10, xmm10
000071ff71bcf81d  pslld xmm10, 0x08
000071ff71bcf823  movaps xmm5, [r15+0x160]
000071ff71bcf82b  pextrq rax, xmm5, 0x01
000071ff71bcf832  movq xmm5, rax
000071ff71bcf837  pmovzxwd xmm5, xmm5
000071ff71bcf83c  pslld xmm5, 0x08
000071ff71bcf841  pslld xmm9, 0x18
000071ff71bcf847  pslld xmm15, 0x18
000071ff71bcf84d  pslld xmm8, 0x18
000071ff71bcf853  movq xmm4, qword ptr [r15+0x250]
000071ff71bcf85c  pmovzxwd xmm4, xmm4
000071ff71bcf861  pslld xmm4, 0x00
000071ff71bcf866  por xmm14, xmm13
000071ff71bcf86b  por xmm7, xmm10
000071ff71bcf870  movaps [r15+0x210], xmm7
000071ff71bcf878  pslld xmm1, 0x18
000071ff71bcf87d  movaps [r15+0x220], xmm1
000071ff71bcf885  por xmm6, xmm5
000071ff71bcf889  por xmm11, xmm9
000071ff71bcf88e  movaps [r15+0x160], xmm11
000071ff71bcf896  pextrq rax, xmm12, 0x01
000071ff71bcf89d  movq xmm13, rax
000071ff71bcf8a2  pmovzxwd xmm13, xmm13
000071ff71bcf8a8  pslld xmm13, 0x00
000071ff71bcf8ae  movaps [r15+0x170], xmm13
000071ff71bcf8b6  movq xmm12, qword ptr [r15+0x110]
000071ff71bcf8bf  pmovzxwd xmm12, xmm12
000071ff71bcf8c5  pslld xmm12, 0x00
000071ff71bcf8cb  por xmm14, xmm15
000071ff71bcf8d0  por xmm7, xmm8
000071ff71bcf8d5  movaps xmm15, [r15+0x250]
000071ff71bcf8dd  pextrq rax, xmm15, 0x01
000071ff71bcf8e4  movq xmm15, rax
000071ff71bcf8e9  pmovzxwd xmm15, xmm15
000071ff71bcf8ef  pslld xmm15, 0x00
000071ff71bcf8f5  movaps [r15+0x180], xmm15
000071ff71bcf8fd  por xmm6, xmm1
000071ff71bcf901  movaps [r15+0x150], xmm6
000071ff71bcf909  por xmm11, xmm4
000071ff71bcf90e  movaps [r15+0x140], xmm11
000071ff71bcf916  por xmm7, xmm12
000071ff71bcf91b  movaps [r15+0x110], xmm7
000071ff71bcf923  por xmm14, xmm13
000071ff71bcf928  movaps [r15+0x120], xmm14
000071ff71bcf930  por xmm6, xmm15
000071ff71bcf935  movaps [r15+0x130], xmm6
000071ff71bcf93d  mov rax, [r15+0xF8]
000071ff71bcf944  lea r14, [rax+0x20]
000071ff71bcf948  movups [r13+r14*1], xmm7
000071ff71bcf94e  lea r14, [rax+0x30]
000071ff71bcf952  movups [r13+r14*1], xmm14
000071ff71bcf958  movups [r13+rax*1], xmm11
000071ff71bcf95e  lea r14, [rax+0x10]
000071ff71bcf962  movups [r13+r14*1], xmm6
000071ff71bcf968  mov r14d, [r13+rax*1]
000071ff71bcf96d  mov rax, [r15+0x48]
000071ff71bcf971  mov [r15+0x68], rax
000071ff71bcf975  mov qword ptr [r15+0x58], 0x04
000071ff71bcf97d  lea r12, [rax+0x04]
000071ff71bcf981  mov r11d, [r13+r12*1]
000071ff71bcf986  mov [rsp+0x10], r11d
000071ff71bcf98b  mov r11d, r11d
000071ff71bcf98e  mov [r15+0x70], r11
000071ff71bcf992  lea r12, [rax+0x38]
000071ff71bcf996  mov r11d, [r13+r12*1]
000071ff71bcf99b  lea r12, [rax+0x24]
000071ff71bcf99f  mov r10d, [r13+r12*1]
000071ff71bcf9a4  mov [rsp+0x20], r10d
000071ff71bcf9a9  mov r10d, r10d
000071ff71bcf9ac  mov [r15+0x90], r10
000071ff71bcf9b3  mov [rsp+0x30], rax
000071ff71bcf9b8  xor eax, eax
000071ff71bcf9ba  mov r12d, 0x04
000071ff71bcf9c0  mov r10d, 0xC0
000071ff71bcf9c6  cmp r12, r10
000071ff71bcf9c9  cmc
000071ff71bcf9ca  lahf
000071ff71bcf9cb  seto al
000071ff71bcf9ce  mov [r15+0x108], eax
000071ff71bcf9d5  mov eax, [rsp+0x10]
000071ff71bcf9d9  mov r12d, [rsp+0x10]
000071ff71bcf9de  shrd eax, r12d, 0x07
000071ff71bcf9e3  mov [rsp+0x10], r11d
000071ff71bcf9e8  mov r10d, [rsp+0x10]
000071ff71bcf9ed  shrd r11d, r10d, 0x11
000071ff71bcf9f2  mov r9d, [rsp+0x20]
000071ff71bcf9f7  lea r8d, [r9d+r14d*1]
000071ff71bcf9fc  rorx r14d, r12d, 0x12
000071ff71bcfa02  xor eax, r14d
000071ff71bcfa05  rorx r14d, r10d, 0x13
000071ff71bcfa0b  xor r11d, r14d
000071ff71bcfa0e  mov [rsp+0x10], r11d
000071ff71bcfa13  mov r11d, r11d
000071ff71bcfa16  mov [r15+0x88], r11
000071ff71bcfa1d  mov [rsp+0x20], r12d
000071ff71bcfa22  shr r12d, 0x03
000071ff71bcfa26  xor eax, r12d
000071ff71bcfa29  mov [rsp+0x40], eax
000071ff71bcfa2d  mov eax, eax
000071ff71bcfa2f  mov [r15+0x80], rax
000071ff71bcfa36  shr r10d, 0x0A
000071ff71bcfa3a  mov eax, [rsp+0x10]
000071ff71bcfa3e  xor eax, r10d
000071ff71bcfa41  mov [rsp+0x10], eax
000071ff71bcfa45  mov eax, eax
000071ff71bcfa47  mov [r15+0x78], rax
000071ff71bcfa4b  mov eax, [rsp+0x40]
000071ff71bcfa4f  lea r14d, [r8d+eax*1]
000071ff71bcfa54  mov eax, [rsp+0x10]
000071ff71bcfa58  lea r12d, [r14d+eax*1]
000071ff71bcfa5d  mov rax, [rsp+0x30]
000071ff71bcfa62  lea r14, [rax+0x40]
000071ff71bcfa66  mov [r13+r14*1], r12d
000071ff71bcfa6b  mov eax, [rsp+0x20]
000071ff71bcfa6f  mov eax, eax
000071ff71bcfa71  mov [r15+0x60], rax
000071ff71bcfa75  mov eax, [r15+0x108]
000071ff71bcfa7c  sahf
000071ff71bcfa7d  jnz 0x000071FF71BCFAAF
000071ff71bcfa7f  cmp dword ptr [r15+0x318], 0x00
000071ff71bcfa87  jz 0x000071FF71BCFF70
000071ff71bcfa8d  nop [rax+rax*1], ax
000071ff71bcfa96  nop [rax+rax*1], eax
000071ff71bcfa9e  mov eax, 0x41088C
000071ff71bcfaa3  mov [r15+0x100], rax
000071ff71bcfaaa  jmp 0x000071FF719FE110
000071ff71bcfaaf  cmp dword ptr [r15+0x318], 0x00
000071ff71bcfab7  jz 0x000071FF71BCFDC0
000071ff71bcfabd  nop [rax+rax*1], ax
000071ff71bcfac6  nop [rax+rax*1], eax
000071ff71bcface  mov eax, 0x410844
000071ff71bcfad3  mov [r15+0x100], rax
000071ff71bcfada  jmp 0x000071FF719FE110
000071ff71bcfadf  int3
000071ff71bcfae0  call 0x000071FF71A0D860
000071ff71bcfae5  jmp 0x000071FF71BCF17A
000071ff71bcfaea  call 0x000071FF71AE2420
000071ff71bcfaef  jmp 0x000071FF71BCF193
000071ff71bcfaf4  call 0x000071FF71AE2420
000071ff71bcfaf9  jmp 0x000071FF71BCF1AC
000071ff71bcfafe  call 0x000071FF71AE2420
000071ff71bcfb03  jmp 0x000071FF71BCF1C5
000071ff71bcfb08  call 0x000071FF71AE2420
000071ff71bcfb0d  jmp 0x000071FF71BCF1DE
000071ff71bcfb12  call 0x000071FF71AE2420
000071ff71bcfb17  jmp 0x000071FF71BCF1EF
000071ff71bcfb1c  call 0x000071FF71AE2420
000071ff71bcfb21  jmp 0x000071FF71BCF200
000071ff71bcfb26  call 0x000071FF71AE2420
000071ff71bcfb2b  jmp 0x000071FF71BCF211
000071ff71bcfb30  call 0x000071FF71AE2420
000071ff71bcfb35  jmp 0x000071FF71BCF222
000071ff71bcfb3a  call 0x000071FF71AE2420
000071ff71bcfb3f  jmp 0x000071FF71BCF233
000071ff71bcfb44  call 0x000071FF71AE2420
000071ff71bcfb49  jmp 0x000071FF71BCF244
000071ff71bcfb4e  call 0x000071FF71AE2420
000071ff71bcfb53  jmp 0x000071FF71BCF255
000071ff71bcfb58  call 0x000071FF71AE2420
000071ff71bcfb5d  jmp 0x000071FF71BCF266
000071ff71bcfb62  call 0x000071FF71AE2420
000071ff71bcfb67  jmp 0x000071FF71BCF277
000071ff71bcfb6c  call 0x000071FF71AE2420
000071ff71bcfb71  jmp 0x000071FF71BCF288
000071ff71bcfb76  call 0x000071FF71AE2420
000071ff71bcfb7b  jmp 0x000071FF71BCF299
000071ff71bcfb80  call 0x000071FF71AE2420
000071ff71bcfb85  jmp 0x000071FF71BCF2AA
000071ff71bcfb8a  call 0x000071FF71AE2420
000071ff71bcfb8f  jmp 0x000071FF71BCF2BB
000071ff71bcfb94  call 0x000071FF71AE2420
000071ff71bcfb99  jmp 0x000071FF71BCF2CC
000071ff71bcfb9e  call 0x000071FF71AE2420
000071ff71bcfba3  jmp 0x000071FF71BCF2DD
000071ff71bcfba8  call 0x000071FF71AE2420
000071ff71bcfbad  jmp 0x000071FF71BCF2EE
000071ff71bcfbb2  call 0x000071FF71AE2420
000071ff71bcfbb7  jmp 0x000071FF71BCF2FF
000071ff71bcfbbc  call 0x000071FF71AE2420
000071ff71bcfbc1  jmp 0x000071FF71BCF310
000071ff71bcfbc6  call 0x000071FF71AE2420
000071ff71bcfbcb  jmp 0x000071FF71BCF321
000071ff71bcfbd0  call 0x000071FF71AE2420
000071ff71bcfbd5  jmp 0x000071FF71BCF332
000071ff71bcfbda  call 0x000071FF71AE2420
000071ff71bcfbdf  jmp 0x000071FF71BCF343
000071ff71bcfbe4  call 0x000071FF71AE2420
000071ff71bcfbe9  jmp 0x000071FF71BCF354
000071ff71bcfbee  call 0x000071FF71AE2420
000071ff71bcfbf3  jmp 0x000071FF71BCF365
000071ff71bcfbf8  call 0x000071FF71AE2420
000071ff71bcfbfd  jmp 0x000071FF71BCF376
000071ff71bcfc02  call 0x000071FF71AE2420
000071ff71bcfc07  jmp 0x000071FF71BCF387
000071ff71bcfc0c  call 0x000071FF71AE2420
000071ff71bcfc11  jmp 0x000071FF71BCF398
000071ff71bcfc16  call 0x000071FF71AE2420
000071ff71bcfc1b  jmp 0x000071FF71BCF3A9
000071ff71bcfc20  call 0x000071FF71AE2420
000071ff71bcfc25  jmp 0x000071FF71BCF3BA
000071ff71bcfc2a  call 0x000071FF71AE2420
000071ff71bcfc2f  jmp 0x000071FF71BCF3CB
000071ff71bcfc34  call 0x000071FF71AE2420
000071ff71bcfc39  jmp 0x000071FF71BCF3DC
000071ff71bcfc3e  call 0x000071FF71AE2420
000071ff71bcfc43  jmp 0x000071FF71BCF3ED
000071ff71bcfc48  call 0x000071FF71AE2420
000071ff71bcfc4d  jmp 0x000071FF71BCF3FE
000071ff71bcfc52  call 0x000071FF71AE2420
000071ff71bcfc57  jmp 0x000071FF71BCF40F
000071ff71bcfc5c  call 0x000071FF71AE2420
000071ff71bcfc61  jmp 0x000071FF71BCF420
000071ff71bcfc66  call 0x000071FF71AE2420
000071ff71bcfc6b  jmp 0x000071FF71BCF431
000071ff71bcfc70  call 0x000071FF71AE2420
000071ff71bcfc75  jmp 0x000071FF71BCF442
000071ff71bcfc7a  call 0x000071FF71AE2420
000071ff71bcfc7f  jmp 0x000071FF71BCF453
000071ff71bcfc84  call 0x000071FF71AE2420
000071ff71bcfc89  jmp 0x000071FF71BCF464
000071ff71bcfc8e  call 0x000071FF71AE2420
000071ff71bcfc93  jmp 0x000071FF71BCF475
000071ff71bcfc98  call 0x000071FF71AE2420
000071ff71bcfc9d  jmp 0x000071FF71BCF486
000071ff71bcfca2  call 0x000071FF71AE2420
000071ff71bcfca7  jmp 0x000071FF71BCF497
000071ff71bcfcac  call 0x000071FF71AE2420
000071ff71bcfcb1  jmp 0x000071FF71BCF4A8
000071ff71bcfcb6  call 0x000071FF71AE2420
000071ff71bcfcbb  jmp 0x000071FF71BCF4B9
000071ff71bcfcc0  call 0x000071FF71AE2420
000071ff71bcfcc5  jmp 0x000071FF71BCF4CA
000071ff71bcfcca  call 0x000071FF71AE2420
000071ff71bcfccf  jmp 0x000071FF71BCF4DB
000071ff71bcfcd4  call 0x000071FF71AE2420
000071ff71bcfcd9  jmp 0x000071FF71BCF4EC
000071ff71bcfcde  call 0x000071FF71AE2420
000071ff71bcfce3  jmp 0x000071FF71BCF4FD
000071ff71bcfce8  call 0x000071FF71AE2420
000071ff71bcfced  jmp 0x000071FF71BCF50E
000071ff71bcfcf2  call 0x000071FF71AE2420
000071ff71bcfcf7  jmp 0x000071FF71BCF51F
000071ff71bcfcfc  call 0x000071FF71AE2420
000071ff71bcfd01  jmp 0x000071FF71BCF530
000071ff71bcfd06  call 0x000071FF71AE2420
000071ff71bcfd0b  jmp 0x000071FF71BCF541
000071ff71bcfd10  call 0x000071FF71AE2420
000071ff71bcfd15  jmp 0x000071FF71BCF552
000071ff71bcfd1a  call 0x000071FF71AE2420
000071ff71bcfd1f  jmp 0x000071FF71BCF563
000071ff71bcfd24  call 0x000071FF71AE2420
000071ff71bcfd29  jmp 0x000071FF71BCF574
000071ff71bcfd2e  call 0x000071FF71AE2420
000071ff71bcfd33  jmp 0x000071FF71BCF585
000071ff71bcfd38  call 0x000071FF71AE2420
000071ff71bcfd3d  jmp 0x000071FF71BCF596
000071ff71bcfd42  call 0x000071FF71AE2420
000071ff71bcfd47  jmp 0x000071FF71BCF5AF
000071ff71bcfd4c  call 0x000071FF71AE2420
000071ff71bcfd51  jmp 0x000071FF71BCF5C8
000071ff71bcfd56  call 0x000071FF71AD5610
000071ff71bcfd5b  jmp 0x000071FF71BCF5E1
000071ff71bcfd60  call 0x000071FF71ADC580
000071ff71bcfd65  jmp 0x000071FF71BCF94E
000071ff71bcfd6a  call 0x000071FF71AE46C0
000071ff71bcfd6f  jmp 0x000071FF71BCF958
000071ff71bcfd74  call 0x000071FF71A09E90
000071ff71bcfd79  jmp 0x000071FF71BCF95E
000071ff71bcfd7e  call 0x000071FF71ADB310
000071ff71bcfd83  jmp 0x000071FF71BCF968
000071ff71bcfd88  call 0x000071FF71A0DAE0
000071ff71bcfd8d  jmp 0x000071FF71BCF96D
000071ff71bcfd92  call 0x000071FF71AC0230
000071ff71bcfd97  jmp 0x000071FF71BCF986
000071ff71bcfd9c  call 0x000071FF71AC0230
000071ff71bcfda1  jmp 0x000071FF71BCF99B
000071ff71bcfda6  call 0x000071FF71ABEFC0
000071ff71bcfdab  jmp 0x000071FF71BCF9A4
000071ff71bcfdb0  call 0x000071FF71AE2BA0
000071ff71bcfdb5  jmp 0x000071FF71BCFA6B
000071ff71bcfdba  int3
000071ff71bcfdbb  nop [rax+rax*1], eax
000071ff71bcfdc0  mov rax, [r15+0x48]
000071ff71bcfdc4  mov r14, [r15+0x58]
000071ff71bcfdc8  lea r12, [rax+r14*1]
000071ff71bcfdcc  mov [r15+0x68], r12
000071ff71bcfdd0  lea rax, [r14+0x04]
000071ff71bcfdd4  mov [r15+0x58], rax
000071ff71bcfdd8  lea r14, [r12+0x04]
000071ff71bcfddd  mov r11d, [r13+r14*1]
000071ff71bcfde2  mov [rsp+0x10], r11d
000071ff71bcfde7  mov r11d, r11d
000071ff71bcfdea  mov [r15+0x70], r11
000071ff71bcfdee  lea r14, [r12+0x38]
000071ff71bcfdf3  mov r11d, [r13+r14*1]
000071ff71bcfdf8  lea r14, [r12+0x24]
000071ff71bcfdfd  mov r10d, [r13+r14*1]
000071ff71bcfe02  mov [rsp+0x20], r10d
000071ff71bcfe07  mov r10d, r10d
000071ff71bcfe0a  mov [r15+0x90], r10
000071ff71bcfe11  mov [rsp+0x30], rax
000071ff71bcfe16  xor eax, eax
000071ff71bcfe18  mov r14, [rsp+0x30]
000071ff71bcfe1d  mov r10d, 0xC0
000071ff71bcfe23  cmp r14, r10
000071ff71bcfe26  cmc
000071ff71bcfe27  lahf
000071ff71bcfe28  seto al
000071ff71bcfe2b  mov [r15+0x108], eax
000071ff71bcfe32  mov eax, [rsp+0x10]
000071ff71bcfe36  mov r14d, [rsp+0x10]
000071ff71bcfe3b  shrd eax, r14d, 0x07
000071ff71bcfe40  mov [rsp+0x10], r11d
000071ff71bcfe45  mov r10d, [rsp+0x10]
000071ff71bcfe4a  shrd r11d, r10d, 0x11
000071ff71bcfe4f  mov r9d, [r15+0x60]
000071ff71bcfe53  mov r8d, [rsp+0x20]
000071ff71bcfe58  lea ebp, [r8d+r9d*1]
000071ff71bcfe5d  rorx r9d, r14d, 0x12
000071ff71bcfe63  xor eax, r9d
000071ff71bcfe66  rorx r9d, r10d, 0x13
000071ff71bcfe6c  xor r11d, r9d
000071ff71bcfe6f  mov [rsp+0x10], r11d
000071ff71bcfe74  mov r11d, r11d
000071ff71bcfe77  mov [r15+0x88], r11
000071ff71bcfe7e  mov [rsp+0x20], r14d
000071ff71bcfe83  shr r14d, 0x03
000071ff71bcfe87  xor eax, r14d
000071ff71bcfe8a  mov [rsp+0x30], eax
000071ff71bcfe8e  mov eax, eax
000071ff71bcfe90  mov [r15+0x80], rax
000071ff71bcfe97  shr r10d, 0x0A
000071ff71bcfe9b  mov eax, [rsp+0x10]
000071ff71bcfe9f  xor eax, r10d
000071ff71bcfea2  mov [rsp+0x10], eax
000071ff71bcfea6  mov eax, eax
000071ff71bcfea8  mov [r15+0x78], rax
000071ff71bcfeac  mov eax, [rsp+0x30]
000071ff71bcfeb0  lea r14d, [ebp+eax*1]
000071ff71bcfeb6  mov eax, [rsp+0x10]
000071ff71bcfeba  lea r11d, [r14d+eax*1]
000071ff71bcfebf  lea rax, [r12+0x40]
000071ff71bcfec4  mov [r13+rax*1], r11d
000071ff71bcfec9  mov eax, [rsp+0x20]
000071ff71bcfecd  mov eax, eax
000071ff71bcfecf  mov [r15+0x60], rax
000071ff71bcfed3  mov eax, [r15+0x108]
000071ff71bcfeda  sahf
000071ff71bcfedb  jnz 0x000071FF71BCFF0D
000071ff71bcfedd  cmp dword ptr [r15+0x318], 0x00
000071ff71bcfee5  jz 0x000071FF71BCFF70
000071ff71bcfeeb  nop [rax+rax*1], ax
000071ff71bcfef4  nop [rax+rax*1], eax
000071ff71bcfefc  mov eax, 0x41088C
000071ff71bcff01  mov [r15+0x100], rax
000071ff71bcff08  jmp 0x000071FF719FE110
000071ff71bcff0d  cmp dword ptr [r15+0x318], 0x00
000071ff71bcff15  jz 0x000071FF71BCFDC0
000071ff71bcff1b  nop [rax+rax*1], ax
000071ff71bcff24  nop [rax+rax*1], eax
000071ff71bcff2c  mov eax, 0x410844
000071ff71bcff31  mov [r15+0x100], rax
000071ff71bcff38  jmp 0x000071FF719FE110
000071ff71bcff3d  int3
000071ff71bcff3e  call 0x000071FF71AE1430
000071ff71bcff43  jmp 0x000071FF71BCFDE2
000071ff71bcff48  call 0x000071FF71AE1430
000071ff71bcff4d  jmp 0x000071FF71BCFDF8
000071ff71bcff52  call 0x000071FF71AE01C0
000071ff71bcff57  jmp 0x000071FF71BCFE02
000071ff71bcff5c  call 0x000071FF71A0A860
000071ff71bcff61  jmp 0x000071FF71BCFEC9
000071ff71bcff66  int3
000071ff71bcff67  nop [rax+rax*1], ax
000071ff71bcff70  mov rax, [r15]
000071ff71bcff73  mov r14d, [r13+rax*1]
000071ff71bcff78  lea r12, [rax+0x04]
000071ff71bcff7c  mov r11d, [r13+r12*1]
000071ff71bcff81  mov [rsp+0x10], r14d
000071ff71bcff86  mov r14d, r14d
000071ff71bcff89  mov [r15+0x78], r14
000071ff71bcff8d  mov [rsp+0x20], r11d
000071ff71bcff92  mov r11d, r11d
000071ff71bcff95  mov [r15+0x80], r11
000071ff71bcff9c  lea r14, [rax+0x08]
000071ff71bcffa0  mov r12d, [r13+r14*1]
000071ff71bcffa5  lea r14, [rax+0x0C]
000071ff71bcffa9  mov r11d, [r13+r14*1]
000071ff71bcffae  mov [rsp+0x30], r12d
000071ff71bcffb3  mov r12d, r12d
000071ff71bcffb6  mov [r15+0x70], r12
000071ff71bcffba  mov [rsp+0x40], r11d
000071ff71bcffbf  mov r11d, r11d
000071ff71bcffc2  mov [r15+0x68], r11
000071ff71bcffc6  lea r14, [rax+0x18]
000071ff71bcffca  mov r12d, [r13+r14*1]
000071ff71bcffcf  lea r14, [rax+0x1C]
000071ff71bcffd3  mov r11d, [r13+r14*1]
000071ff71bcffd8  mov [rsp+0x50], r12d
000071ff71bcffdd  mov r12d, r12d
000071ff71bcffe0  mov [r15+0x58], r12
000071ff71bcffe4  mov [rsp+0x60], r11d
000071ff71bcffe9  mov r11d, r11d
000071ff71bcffec  mov [r15+0x60], r11
000071ff71bcfff0  lea r14, [rax+0x10]
000071ff71bcfff4  mov r12d, [r13+r14*1]
000071ff71bcfff9  lea r14, [rax+0x14]
000071ff71bcfffd  mov eax, [r13+r14*1]
000071ff71bd0002  mov [rsp+0x70], r12d
000071ff71bd0007  mov r12d, r12d
000071ff71bd000a  mov [r15+0x18], r12
000071ff71bd000e  mov [rsp+0x80], eax
000071ff71bd0015  mov eax, eax
000071ff71bd0017  mov [r15+0x90], rax
000071ff71bd001e  mov eax, [rsp+0x70]
000071ff71bd0022  mov eax, eax
000071ff71bd0024  mov [r15+0x30], rax
000071ff71bd0028  mov eax, [rsp+0x50]
000071ff71bd002c  mov eax, eax
000071ff71bd002e  mov [r15+0xA0], rax
000071ff71bd0035  mov eax, [rsp+0x30]
000071ff71bd0039  mov eax, eax
000071ff71bd003b  mov [r15+0x28], rax
000071ff71bd003f  mov eax, [rsp+0x20]
000071ff71bd0043  mov eax, eax
000071ff71bd0045  mov [r15+0x98], rax
000071ff71bd004c  mov eax, [rsp+0x10]
000071ff71bd0050  mov eax, eax
000071ff71bd0052  mov [r15+0x38], rax
000071ff71bd0056  mov eax, [rsp+0x70]
000071ff71bd005a  mov r14d, [rsp+0x70]
000071ff71bd005f  shrd eax, r14d, 0x06
000071ff71bd0064  mov [rsp+0x70], r14d
000071ff71bd0069  mov r12d, [rsp+0x80]
000071ff71bd0071  and r14d, r12d
000071ff71bd0074  mov r11d, [rsp+0x10]
000071ff71bd0079  mov r10d, [rsp+0x10]
000071ff71bd007e  shrd r11d, r10d, 0x02
000071ff71bd0083  mov [rsp+0x10], r12d
000071ff71bd0088  mov r12d, r12d
000071ff71bd008b  mov [r15+0x20], r12
000071ff71bd008f  mov r12, [r15+0x50]
000071ff71bd0093  mov r9d, [r13+r12*1]
000071ff71bd0098  mov r12d, [rsp+0x50]
000071ff71bd009d  mov r8d, [rsp+0x70]
000071ff71bd00a2  andn ebp, r8d, r12d
000071ff71bd00a7  mov edi, [rsp+0x60]
000071ff71bd00ab  lea esi, [r14d+edi*1]
000071ff71bd00b0  rorx r14d, r8d, 0x0B
000071ff71bd00b6  xor eax, r14d
000071ff71bd00b9  rorx r14d, r10d, 0x0D
000071ff71bd00bf  xor r11d, r14d
000071ff71bd00c2  lea edi, [esi+ebp*1]
000071ff71bd00c6  mov r14, [r15+0x48]
000071ff71bd00ca  mov ebp, [r13+r14*1]
000071ff71bd00cf  mov r14d, [rsp+0x30]
000071ff71bd00d4  mov esi, [rsp+0x20]
000071ff71bd00d8  and r14d, esi
000071ff71bd00db  mov [rsp+0x20], r14d
000071ff71bd00e0  mov r14d, r14d
000071ff71bd00e3  mov [r15+0xD8], r14
000071ff71bd00ea  lea r14d, [edi+r9d*1]
000071ff71bd00ef  mov r9d, [rsp+0x30]
000071ff71bd00f4  xor r9d, esi
000071ff71bd00f7  rorx edi, r8d, 0x19
000071ff71bd00fd  xor eax, edi
000071ff71bd00ff  and r9d, r10d
000071ff71bd0102  rorx edi, r10d, 0x16
000071ff71bd0108  xor r11d, edi
000071ff71bd010b  mov [rsp+0x30], r11d
000071ff71bd0110  mov r11d, r11d
000071ff71bd0113  mov [r15+0xD0], r11
000071ff71bd011a  lea r11d, [r14d+ebp*1]
000071ff71bd011f  mov r10d, [rsp+0x20]
000071ff71bd0124  xor r9d, r10d
000071ff71bd0127  lea r14d, [r11d+eax*1]
000071ff71bd012c  mov qword ptr [r15+0x88], 0x04
000071ff71bd0137  mov eax, [rsp+0x30]
000071ff71bd013b  lea r11d, [r9d+eax*1]
000071ff71bd0140  mov eax, [rsp+0x40]
000071ff71bd0144  lea r10d, [r14d+eax*1]
000071ff71bd0149  mov r10d, r10d
000071ff71bd014c  mov [r15+0xB8], r10
000071ff71bd0153  xor eax, eax
000071ff71bd0155  mov r10d, 0x04
000071ff71bd015b  mov r9d, 0x100
000071ff71bd0161  cmp r10, r9
000071ff71bd0164  cmc
000071ff71bd0165  lahf
000071ff71bd0166  seto al
000071ff71bd0169  mov [r15+0x108], eax
000071ff71bd0170  lea eax, [r11d+r14d*1]
000071ff71bd0175  mov eax, eax
000071ff71bd0177  mov [r15+0xA8], rax
000071ff71bd017e  mov r12d, r12d
000071ff71bd0181  mov [r15+0xB0], r12
000071ff71bd0188  mov eax, [rsp+0x10]
000071ff71bd018c  mov eax, eax
000071ff71bd018e  mov [r15+0xC0], rax
000071ff71bd0195  mov r8d, r8d
000071ff71bd0198  mov [r15+0xC8], r8
000071ff71bd019f  mov eax, [r15+0x108]
000071ff71bd01a6  sahf
000071ff71bd01a7  jnz 0x000071FF71BD01D9
000071ff71bd01a9  cmp dword ptr [r15+0x318], 0x00
000071ff71bd01b1  jz 0x000071FF71BD04A0
000071ff71bd01b7  nop [rax+rax*1], ax
000071ff71bd01c0  nop [rax+rax*1], eax
000071ff71bd01c8  mov eax, 0x41094C
000071ff71bd01cd  mov [r15+0x100], rax
000071ff71bd01d4  jmp 0x000071FF719FE110
000071ff71bd01d9  cmp dword ptr [r15+0x318], 0x00
000071ff71bd01e1  jz 0x000071FF71BD0270
000071ff71bd01e7  nop [rax+rax*1], ax
000071ff71bd01f0  nop [rax+rax*1], eax
000071ff71bd01f8  mov eax, 0x4108C0
000071ff71bd01fd  mov [r15+0x100], rax
000071ff71bd0204  jmp 0x000071FF719FE110
000071ff71bd0209  int3
000071ff71bd020a  call 0x000071FF71A0DAE0
000071ff71bd020f  jmp 0x000071FF71BCFF78
000071ff71bd0214  call 0x000071FF71AC0230
000071ff71bd0219  jmp 0x000071FF71BCFF81
000071ff71bd021e  call 0x000071FF71AE26A0
000071ff71bd0223  jmp 0x000071FF71BCFFA5
000071ff71bd0228  call 0x000071FF71AE1430
000071ff71bd022d  jmp 0x000071FF71BCFFAE
000071ff71bd0232  call 0x000071FF71AE26A0
000071ff71bd0237  jmp 0x000071FF71BCFFCF
000071ff71bd023c  call 0x000071FF71AE1430
000071ff71bd0241  jmp 0x000071FF71BCFFD8
000071ff71bd0246  call 0x000071FF71AE26A0
000071ff71bd024b  jmp 0x000071FF71BCFFF9
000071ff71bd0250  call 0x000071FF71AD5890
000071ff71bd0255  jmp 0x000071FF71BD0002
000071ff71bd025a  call 0x000071FF71ABDD50
000071ff71bd025f  jmp 0x000071FF71BD0098
000071ff71bd0264  call 0x000071FF71ADA580
000071ff71bd0269  jmp 0x000071FF71BD00CF
000071ff71bd026e  int3
000071ff71bd026f  nop
000071ff71bd0270  mov eax, [r15+0xB8]
000071ff71bd0277  mov [rsp+0x10], eax
000071ff71bd027b  mov eax, eax
000071ff71bd027d  mov [r15+0x30], rax
000071ff71bd0281  mov eax, [r15+0xC0]
000071ff71bd0288  mov [rsp+0x20], eax
000071ff71bd028c  mov eax, eax
000071ff71bd028e  mov [r15+0xA0], rax
000071ff71bd0295  mov eax, [r15+0x28]
000071ff71bd0299  mov r14d, [r15+0x98]
000071ff71bd02a0  mov [rsp+0x30], r14d
000071ff71bd02a5  mov r14d, r14d
000071ff71bd02a8  mov [r15+0x28], r14
000071ff71bd02ac  mov r14d, [r15+0x38]
000071ff71bd02b0  mov [rsp+0x40], r14d
000071ff71bd02b5  mov r14d, r14d
000071ff71bd02b8  mov [r15+0x98], r14
000071ff71bd02bf  mov r14d, [r15+0xA8]
000071ff71bd02c6  mov [rsp+0x50], r14d
000071ff71bd02cb  mov r14d, r14d
000071ff71bd02ce  mov [r15+0x38], r14
000071ff71bd02d2  mov r14d, [rsp+0x10]
000071ff71bd02d7  mov r12d, [rsp+0x10]
000071ff71bd02dc  shrd r14d, r12d, 0x06
000071ff71bd02e1  mov r11d, [r15+0xC8]
000071ff71bd02e8  mov [rsp+0x10], r12d
000071ff71bd02ed  and r12d, r11d
000071ff71bd02f0  mov r10d, [rsp+0x50]
000071ff71bd02f5  mov r9d, [rsp+0x50]
000071ff71bd02fa  shrd r10d, r9d, 0x02
000071ff71bd02ff  mov [rsp+0x50], r11d
000071ff71bd0304  mov r11d, r11d
000071ff71bd0307  mov [r15+0x20], r11
000071ff71bd030b  mov r11, [r15+0x88]
000071ff71bd0312  mov r8, [r15+0x50]
000071ff71bd0316  lea rbp, [r8+r11*1]
000071ff71bd031a  mov r8d, [r13+rbp*1]
000071ff71bd031f  mov ebp, [rsp+0x20]
000071ff71bd0323  mov edi, [rsp+0x10]
000071ff71bd0327  andn esi, edi, ebp
000071ff71bd032c  mov edx, [r15+0xB0]
000071ff71bd0333  lea ecx, [r12d+edx*1]
000071ff71bd0338  rorx r12d, edi, 0x0B
000071ff71bd033e  xor r14d, r12d
000071ff71bd0341  rorx r12d, r9d, 0x0D
000071ff71bd0347  xor r10d, r12d
000071ff71bd034a  lea r12d, [ecx+esi*1]
000071ff71bd034f  mov rsi, [r15+0x48]
000071ff71bd0353  lea rdx, [rsi+r11*1]
000071ff71bd0357  mov esi, [r13+rdx*1]
000071ff71bd035c  mov edx, [rsp+0x30]
000071ff71bd0360  mov ecx, [rsp+0x40]
000071ff71bd0364  and edx, ecx
000071ff71bd0366  mov [rsp+0x10], edx
000071ff71bd036a  mov edx, edx
000071ff71bd036c  mov [r15+0xD8], rdx
000071ff71bd0373  lea edx, [r12d+r8d*1]
000071ff71bd0378  mov r12d, [rsp+0x30]
000071ff71bd037d  xor r12d, ecx
000071ff71bd0380  rorx r8d, edi, 0x19
000071ff71bd0386  xor r14d, r8d
000071ff71bd0389  and r12d, r9d
000071ff71bd038c  rorx r8d, r9d, 0x16
000071ff71bd0392  xor r10d, r8d
000071ff71bd0395  mov [rsp+0x20], r10d
000071ff71bd039a  mov r10d, r10d
000071ff71bd039d  mov [r15+0xD0], r10
000071ff71bd03a4  lea r10d, [edx+esi*1]
000071ff71bd03a9  mov r9d, [rsp+0x10]
000071ff71bd03ae  xor r12d, r9d
000071ff71bd03b1  lea r9d, [r10d+r14d*1]
000071ff71bd03b6  lea r14, [r11+0x04]
000071ff71bd03ba  mov [r15+0x88], r14
000071ff71bd03c1  mov r11d, [rsp+0x20]
000071ff71bd03c6  lea r10d, [r12d+r11d*1]
000071ff71bd03cb  lea r11d, [r9d+eax*1]
000071ff71bd03d0  mov r11d, r11d
000071ff71bd03d3  mov [r15+0xB8], r11
000071ff71bd03da  xor eax, eax
000071ff71bd03dc  mov r12d, 0x100
000071ff71bd03e2  cmp r14, r12
000071ff71bd03e5  cmc
000071ff71bd03e6  lahf
000071ff71bd03e7  seto al
000071ff71bd03ea  mov [r15+0x108], eax
000071ff71bd03f1  lea eax, [r10d+r9d*1]
000071ff71bd03f6  mov eax, eax
000071ff71bd03f8  mov [r15+0xA8], rax
000071ff71bd03ff  mov ebp, ebp
000071ff71bd0401  mov [r15+0xB0], rbp
000071ff71bd0408  mov eax, [rsp+0x50]
000071ff71bd040c  mov eax, eax
000071ff71bd040e  mov [r15+0xC0], rax
000071ff71bd0415  mov edi, edi
000071ff71bd0417  mov [r15+0xC8], rdi
000071ff71bd041e  mov eax, [r15+0x108]
000071ff71bd0425  sahf
000071ff71bd0426  jnz 0x000071FF71BD0458
000071ff71bd0428  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0430  jz 0x000071FF71BD04A0
000071ff71bd0436  nop [rax+rax*1], ax
000071ff71bd043f  nop [rax+rax*1], eax
000071ff71bd0447  mov eax, 0x41094C
000071ff71bd044c  mov [r15+0x100], rax
000071ff71bd0453  jmp 0x000071FF719FE110
000071ff71bd0458  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0460  jz 0x000071FF71BD0270
000071ff71bd0466  nop [rax+rax*1], ax
000071ff71bd046f  nop [rax+rax*1], eax
000071ff71bd0477  mov eax, 0x4108C0
000071ff71bd047c  mov [r15+0x100], rax
000071ff71bd0483  jmp 0x000071FF719FE110
000071ff71bd0488  int3
000071ff71bd0489  call 0x000071FF71A49010
000071ff71bd048e  jmp 0x000071FF71BD031F
000071ff71bd0493  call 0x000071FF71A25930
000071ff71bd0498  jmp 0x000071FF71BD035C
000071ff71bd049d  int3
000071ff71bd049e  nop
000071ff71bd04a0  mov eax, [r15+0x98]
000071ff71bd04a7  mov r14d, [r15+0x70]
000071ff71bd04ab  lea r12d, [eax+r14d*1]
000071ff71bd04b0  mov eax, [r15+0x28]
000071ff71bd04b4  mov r14d, [r15+0x68]
000071ff71bd04b8  lea r11d, [eax+r14d*1]
000071ff71bd04bd  mov qword ptr [r15+0x88], 0x00
000071ff71bd04c8  mov eax, [r15+0xA8]
000071ff71bd04cf  mov r14d, [r15+0x78]
000071ff71bd04d3  lea r10d, [eax+r14d*1]
000071ff71bd04d8  mov [rsp+0x10], r10d
000071ff71bd04dd  mov r10d, r10d
000071ff71bd04e0  mov [r15+0x78], r10
000071ff71bd04e4  mov eax, [r15+0x38]
000071ff71bd04e8  mov r14d, [r15+0x80]
000071ff71bd04ef  lea r10d, [eax+r14d*1]
000071ff71bd04f4  mov [rsp+0x20], r10d
000071ff71bd04f9  mov r10d, r10d
000071ff71bd04fc  mov [r15+0x80], r10
000071ff71bd0503  mov rax, [r15]
000071ff71bd0506  lea r14, [rax+0x08]
000071ff71bd050a  mov [r13+r14*1], r12d
000071ff71bd050f  lea r14, [rax+0x0C]
000071ff71bd0513  mov [r13+r14*1], r11d
000071ff71bd0518  mov r14d, [r15+0xB8]
000071ff71bd051f  mov r12d, [r15+0x18]
000071ff71bd0523  lea r11d, [r14d+r12d*1]
000071ff71bd0528  mov [rsp+0x30], r11d
000071ff71bd052d  mov r11d, r11d
000071ff71bd0530  mov [r15+0x68], r11
000071ff71bd0534  mov r14d, [r15+0x30]
000071ff71bd0538  mov r12d, [r15+0x90]
000071ff71bd053f  lea r11d, [r14d+r12d*1]
000071ff71bd0544  mov [rsp+0x40], r11d
000071ff71bd0549  mov r11d, r11d
000071ff71bd054c  mov [r15+0x70], r11
000071ff71bd0550  mov r14d, [r15+0x20]
000071ff71bd0554  mov r12d, [r15+0x58]
000071ff71bd0558  lea r11d, [r14d+r12d*1]
000071ff71bd055d  mov [rsp+0x50], r11d
000071ff71bd0562  mov r11d, r11d
000071ff71bd0565  mov [r15+0x58], r11
000071ff71bd0569  mov r14d, [r15+0xA0]
000071ff71bd0570  mov r12d, [r15+0x60]
000071ff71bd0574  lea r11d, [r14d+r12d*1]
000071ff71bd0579  mov [rsp+0x60], r11d
000071ff71bd057e  mov r11d, r11d
000071ff71bd0581  mov [r15+0x60], r11
000071ff71bd0585  mov r14d, [rsp+0x10]
000071ff71bd058a  mov [r13+rax*1], r14d
000071ff71bd058f  lea r14, [rax+0x04]
000071ff71bd0593  mov r12d, [rsp+0x20]
000071ff71bd0598  mov [r13+r14*1], r12d
000071ff71bd059d  lea r14, [rax+0x10]
000071ff71bd05a1  mov r12d, [rsp+0x30]
000071ff71bd05a6  mov [r13+r14*1], r12d
000071ff71bd05ab  lea r14, [rax+0x14]
000071ff71bd05af  mov r12d, [rsp+0x40]
000071ff71bd05b4  mov [r13+r14*1], r12d
000071ff71bd05b9  lea r14, [rax+0x18]
000071ff71bd05bd  mov r12d, [rsp+0x50]
000071ff71bd05c2  mov [r13+r14*1], r12d
000071ff71bd05c7  lea r14, [rax+0x1C]
000071ff71bd05cb  mov r12d, [rsp+0x60]
000071ff71bd05d0  mov [r13+r14*1], r12d
000071ff71bd05d5  lea r14, [rax+0x68]
000071ff71bd05d9  xor eax, eax
000071ff71bd05db  mov [r13+r14*1], rax
000071ff71bd05e0  cmp dword ptr [r15+0x318], 0x00
000071ff71bd05e8  jz 0x000071FF71BCF0E0
000071ff71bd05ee  nop [rax+rax*1], ax
000071ff71bd05f7  nop [rax+rax*1], eax
000071ff71bd05ff  mov eax, 0x410768
000071ff71bd0604  mov [r15+0x100], rax
000071ff71bd060b  jmp 0x000071FF719FE110
000071ff71bd0610  int3
000071ff71bd0611  call 0x000071FF71AE2BA0
000071ff71bd0616  jmp 0x000071FF71BD050F
000071ff71bd061b  call 0x000071FF71AE1920
000071ff71bd0620  jmp 0x000071FF71BD0518
000071ff71bd0625  call 0x000071FF71A0DFE0
000071ff71bd062a  jmp 0x000071FF71BD058F
000071ff71bd062f  call 0x000071FF71AE2BA0
000071ff71bd0634  jmp 0x000071FF71BD059D
000071ff71bd0639  call 0x000071FF71AE2BA0
000071ff71bd063e  jmp 0x000071FF71BD05AB
000071ff71bd0643  call 0x000071FF71AE2BA0
000071ff71bd0648  jmp 0x000071FF71BD05B9
000071ff71bd064d  call 0x000071FF71AE2BA0
000071ff71bd0652  jmp 0x000071FF71BD05C7
000071ff71bd0657  call 0x000071FF71AE2BA0
000071ff71bd065c  jmp 0x000071FF71BD05D5
000071ff71bd0661  call 0x000071FF71AD5EB0
000071ff71bd0666  jmp 0x000071FF71BD05E0
000071ff71bd066b  int3
000071ff71bd066c  nop [rax], eax
000071ff71bd0670  mov rax, [r15+0xF8]
000071ff71bd0677  lea r14, [rax+0x140]
000071ff71bd067e  mov r12, [r13+r14*1]
000071ff71bd0683  lea r14, [rax+0x148]
000071ff71bd068a  mov r11, [r13+r14*1]
000071ff71bd068f  mov [r15+0xA0], r12
000071ff71bd0696  mov [r15+0x98], r11
000071ff71bd069d  lea r14, [rax+0x130]
000071ff71bd06a4  mov r12, [r13+r14*1]
000071ff71bd06a9  lea r14, [rax+0x138]
000071ff71bd06b0  mov r11, [r13+r14*1]
000071ff71bd06b5  mov [r15+0xB0], r12
000071ff71bd06bc  mov [r15+0xA8], r11
000071ff71bd06c3  lea r14, [rax+0x120]
000071ff71bd06ca  mov r12, [r13+r14*1]
000071ff71bd06cf  lea r14, [rax+0x128]
000071ff71bd06d6  mov r11, [r13+r14*1]
000071ff71bd06db  mov [r15+0xC0], r12
000071ff71bd06e2  mov [r15+0xB8], r11
000071ff71bd06e9  lea r14, [rax+0x110]
000071ff71bd06f0  mov r12, [r13+r14*1]
000071ff71bd06f5  lea r14, [rax+0x118]
000071ff71bd06fc  mov r11, [r13+r14*1]
000071ff71bd0701  mov [r15+0xD0], r12
000071ff71bd0708  mov [r15+0xC8], r11
000071ff71bd070f  lea r14, [rax+0x100]
000071ff71bd0716  mov r12, [r13+r14*1]
000071ff71bd071b  lea r14, [rax+0x108]
000071ff71bd0722  mov r11, [r13+r14*1]
000071ff71bd0727  mov [r15+0xE8], r12
000071ff71bd072e  mov [r15+0xD8], r11
000071ff71bd0735  lea r14, [rax+0x150]
000071ff71bd073c  mov [r15+0xF8], r14
000071ff71bd0743  mov rax, [r15+0xF0]
000071ff71bd074a  mov [r15+0x100], rax
000071ff71bd0751  jmp 0x000071FF71BCE5C0
000071ff71bd0756  int3
000071ff71bd0757  call 0x000071FF71AE27E0
000071ff71bd075c  jmp 0x000071FF71BD0683
000071ff71bd0761  call 0x000071FF71AE1570
000071ff71bd0766  jmp 0x000071FF71BD068F
000071ff71bd076b  call 0x000071FF71AE27E0
000071ff71bd0770  jmp 0x000071FF71BD06A9
000071ff71bd0775  call 0x000071FF71AE1570
000071ff71bd077a  jmp 0x000071FF71BD06B5
000071ff71bd077f  call 0x000071FF71AE27E0
000071ff71bd0784  jmp 0x000071FF71BD06CF
000071ff71bd0789  call 0x000071FF71AE1570
000071ff71bd078e  jmp 0x000071FF71BD06DB
000071ff71bd0793  call 0x000071FF71AE27E0
000071ff71bd0798  jmp 0x000071FF71BD06F5
000071ff71bd079d  call 0x000071FF71AE1570
000071ff71bd07a2  jmp 0x000071FF71BD0701
000071ff71bd07a7  call 0x000071FF71AE27E0
000071ff71bd07ac  jmp 0x000071FF71BD071B
000071ff71bd07b1  call 0x000071FF71AE1570
000071ff71bd07b6  jmp 0x000071FF71BD0727
000071ff71bd07bb  int3
000071ff71bd07bc  nop [rax], eax
000071ff71bd07c0  mov eax, [r15+0xA0]
000071ff71bd07c7  mov [rsp+0x10], eax
000071ff71bd07cb  xor eax, eax
000071ff71bd07cd  mov r14d, [rsp+0x10]
000071ff71bd07d2  sub r14d, 0x01
000071ff71bd07d6  cmc
000071ff71bd07d7  lahf
000071ff71bd07d8  seto al
000071ff71bd07db  mov [r15+0x108], eax
000071ff71bd07e2  mov r14d, r14d
000071ff71bd07e5  mov [r15+0xA0], r14
000071ff71bd07ec  mov eax, [r15+0x108]
000071ff71bd07f3  sahf
000071ff71bd07f4  jnz 0x000071FF71BD0826
000071ff71bd07f6  cmp dword ptr [r15+0x318], 0x00
000071ff71bd07fe  jz 0x000071FF71BD0900
000071ff71bd0804  nop [rax+rax*1], ax
000071ff71bd080d  nop [rax+rax*1], eax
000071ff71bd0815  mov eax, 0x41028C
000071ff71bd081a  mov [r15+0x100], rax
000071ff71bd0821  jmp 0x000071FF719FE110
000071ff71bd0826  cmp dword ptr [r15+0x318], 0x00
000071ff71bd082e  jz 0x000071FF71BD0860
000071ff71bd0834  nop [rax+rax*1], ax
000071ff71bd083d  nop [rax+rax*1], eax
000071ff71bd0845  mov eax, 0x410274
000071ff71bd084a  mov [r15+0x100], rax
000071ff71bd0851  jmp 0x000071FF719FE110
000071ff71bd0856  int3
000071ff71bd0857  int3
000071ff71bd0858  nop [rax+rax*1], eax
000071ff71bd0860  mov rax, [r15+0xF8]
000071ff71bd0867  lea r14, [rax+0x100]
000071ff71bd086e  mov [r15], r14
000071ff71bd0871  mov rax, [r15+0x98]
000071ff71bd0878  mov [r15+0x08], rax
000071ff71bd087c  mov qword ptr [r15+0x10], 0x12C
000071ff71bd0884  mov qword ptr [r15+0xF0], 0x410284
000071ff71bd088f  mov r14d, [r15+0x320]
000071ff71bd0896  mov eax, 0x410284
000071ff71bd089b  mov rcx, 0x71FF71BD07C0
000071ff71bd08a5  mov [r15+r14*8+0x328], rax
000071ff71bd08ad  mov [r15+r14*8+0x368], rcx
000071ff71bd08b5  add r14d, 0x01
000071ff71bd08b9  and r14d, 0x07
000071ff71bd08bd  mov [r15+0x320], r14d
000071ff71bd08c4  cmp dword ptr [r15+0x318], 0x00
000071ff71bd08cc  jz 0x000071FF71BCED70
000071ff71bd08d2  nop [rax+rax*1], ax
000071ff71bd08db  nop [rax+rax*1], eax
000071ff71bd08e3  mov eax, 0x410728
000071ff71bd08e8  mov [r15+0x100], rax
000071ff71bd08ef  jmp 0x000071FF719FE110
000071ff71bd08f4  int3
000071ff71bd08f5  int3
000071ff71bd08f6  nop [rax+rax*1], ax
000071ff71bd08ff  nop
000071ff71bd0900  mov rax, [r15+0xF8]
000071ff71bd0907  lea r14, [rax+0x120]
000071ff71bd090e  mov r12, [r13+r14*1]
000071ff71bd0913  mov [r15+0x98], r12
000071ff71bd091a  mov qword ptr [r15+0x40], 0x80
000071ff71bd0922  lea r14, [rax+0x100]
000071ff71bd0929  mov [r15], r14
000071ff71bd092c  lea r14, [rax+0x17C]
000071ff71bd0933  mov [r15+0x08], r14
000071ff71bd0937  mov qword ptr [r15+0x10], 0x01
000071ff71bd093f  lea r14, [rax+0x17C]
000071ff71bd0946  mov eax, 0x80
000071ff71bd094b  mov [r13+r14*1], al
000071ff71bd0950  mov qword ptr [r15+0xF0], 0x4102A8
000071ff71bd095b  mov r14d, [r15+0x320]
000071ff71bd0962  mov eax, 0x4102A8
000071ff71bd0967  mov rcx, 0x71FF71BD09E0
000071ff71bd0971  mov [r15+r14*8+0x328], rax
000071ff71bd0979  mov [r15+r14*8+0x368], rcx
000071ff71bd0981  add r14d, 0x01
000071ff71bd0985  and r14d, 0x07
000071ff71bd0989  mov [r15+0x320], r14d
000071ff71bd0990  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0998  jz 0x000071FF71BCED70
000071ff71bd099e  nop [rax+rax*1], ax
000071ff71bd09a7  nop [rax+rax*1], eax
000071ff71bd09af  mov eax, 0x410728
000071ff71bd09b4  mov [r15+0x100], rax
000071ff71bd09bb  jmp 0x000071FF719FE110
000071ff71bd09c0  int3
000071ff71bd09c1  call 0x000071FF71AE27E0
000071ff71bd09c6  jmp 0x000071FF71BD0913
000071ff71bd09cb  call 0x000071FF71AD5AF0
000071ff71bd09d0  jmp 0x000071FF71BD0950
000071ff71bd09d5  int3
000071ff71bd09d6  nop [rax+rax*1], ax
000071ff71bd09df  nop
000071ff71bd09e0  mov rax, [r15+0xF8]
000071ff71bd09e7  lea r14, [rax+0x168]
000071ff71bd09ee  mov r12, [r13+r14*1]
000071ff71bd09f3  mov [r15+0x40], r12
000071ff71bd09f7  lea r14, [rax+0x178]
000071ff71bd09fe  xor eax, eax
000071ff71bd0a00  mov [r13+r14*1], al
000071ff71bd0a05  xor eax, eax
000071ff71bd0a07  mov r14d, 0x38
000071ff71bd0a0d  cmp r12, r14
000071ff71bd0a10  cmc
000071ff71bd0a11  lahf
000071ff71bd0a12  seto al
000071ff71bd0a15  mov [r15+0x108], eax
000071ff71bd0a1c  mov eax, [r15+0x108]
000071ff71bd0a23  sahf
000071ff71bd0a24  jz 0x000071FF71BD0A56
000071ff71bd0a26  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0a2e  jz 0x000071FF71BD0AA0
000071ff71bd0a34  nop [rax+rax*1], ax
000071ff71bd0a3d  nop [rax+rax*1], eax
000071ff71bd0a45  mov eax, 0x4102B8
000071ff71bd0a4a  mov [r15+0x100], rax
000071ff71bd0a51  jmp 0x000071FF719FE110
000071ff71bd0a56  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0a5e  jz 0x000071FF71BD0BF0
000071ff71bd0a64  nop [rax+rax*1], ax
000071ff71bd0a6d  nop [rax+rax*1], eax
000071ff71bd0a75  mov eax, 0x4102D4
000071ff71bd0a7a  mov [r15+0x100], rax
000071ff71bd0a81  jmp 0x000071FF719FE110
000071ff71bd0a86  int3
000071ff71bd0a87  call 0x000071FF71AE27E0
000071ff71bd0a8c  jmp 0x000071FF71BD09F3
000071ff71bd0a91  call 0x000071FF71AD5AF0
000071ff71bd0a96  jmp 0x000071FF71BD0A05
000071ff71bd0a9b  int3
000071ff71bd0a9c  nop [rax], eax
000071ff71bd0aa0  mov rax, [r15+0xF8]
000071ff71bd0aa7  lea r14, [rax+0x100]
000071ff71bd0aae  mov [r15], r14
000071ff71bd0ab1  lea r14, [rax+0x178]
000071ff71bd0ab8  mov [r15+0x08], r14
000071ff71bd0abc  mov qword ptr [r15+0x10], 0x01
000071ff71bd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000071ff71bd0acf  mov r14d, [r15+0x320]
000071ff71bd0ad6  mov eax, 0x4102C8
000071ff71bd0adb  mov rcx, 0x71FF71BD0B40
000071ff71bd0ae5  mov [r15+r14*8+0x328], rax
000071ff71bd0aed  mov [r15+r14*8+0x368], rcx
000071ff71bd0af5  add r14d, 0x01
000071ff71bd0af9  and r14d, 0x07
000071ff71bd0afd  mov [r15+0x320], r14d
000071ff71bd0b04  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0b0c  jz 0x000071FF71BCED70
000071ff71bd0b12  nop [rax+rax*1], ax
000071ff71bd0b1b  nop [rax+rax*1], eax
000071ff71bd0b23  mov eax, 0x410728
000071ff71bd0b28  mov [r15+0x100], rax
000071ff71bd0b2f  jmp 0x000071FF719FE110
000071ff71bd0b34  int3
000071ff71bd0b35  int3
000071ff71bd0b36  nop [rax+rax*1], ax
000071ff71bd0b3f  nop
000071ff71bd0b40  mov rax, [r15+0xF8]
000071ff71bd0b47  lea r14, [rax+0x168]
000071ff71bd0b4e  mov rax, [r13+r14*1]
000071ff71bd0b53  mov [r15+0x40], rax
000071ff71bd0b57  mov [rsp+0x10], rax
000071ff71bd0b5c  xor eax, eax
000071ff71bd0b5e  mov r14, [rsp+0x10]
000071ff71bd0b63  mov r12d, 0x38
000071ff71bd0b69  cmp r14, r12
000071ff71bd0b6c  cmc
000071ff71bd0b6d  lahf
000071ff71bd0b6e  seto al
000071ff71bd0b71  mov [r15+0x108], eax
000071ff71bd0b78  mov eax, [r15+0x108]
000071ff71bd0b7f  sahf
000071ff71bd0b80  jnz 0x000071FF71BD0BB2
000071ff71bd0b82  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0b8a  jz 0x000071FF71BD0BF0
000071ff71bd0b90  nop [rax+rax*1], ax
000071ff71bd0b99  nop [rax+rax*1], eax
000071ff71bd0ba1  mov eax, 0x4102D4
000071ff71bd0ba6  mov [r15+0x100], rax
000071ff71bd0bad  jmp 0x000071FF719FE110
000071ff71bd0bb2  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0bba  jz 0x000071FF71BD0AA0
000071ff71bd0bc0  nop [rax+rax*1], ax
000071ff71bd0bc9  nop [rax+rax*1], eax
000071ff71bd0bd1  mov eax, 0x4102B8
000071ff71bd0bd6  mov [r15+0x100], rax
000071ff71bd0bdd  jmp 0x000071FF719FE110
000071ff71bd0be2  int3
000071ff71bd0be3  call 0x000071FF71AD59C0
000071ff71bd0be8  jmp 0x000071FF71BD0B53
000071ff71bd0bed  int3
000071ff71bd0bee  nop
000071ff71bd0bf0  mov rax, [r15+0x98]
000071ff71bd0bf7  rorx r14, rax, 0x3D
000071ff71bd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000071ff71bd0c01  mov rax, [r15+0xF8]
000071ff71bd0c08  lea r12, [rax+0x100]
000071ff71bd0c0f  mov [r15], r12
000071ff71bd0c12  lea r12, [rax+0x170]
000071ff71bd0c19  mov [r15+0x08], r12
000071ff71bd0c1d  mov qword ptr [r15+0x10], 0x08
000071ff71bd0c25  bswap r14
000071ff71bd0c28  mov [r15+0x40], r14
000071ff71bd0c2c  lea r12, [rax+0x170]
000071ff71bd0c33  mov [r13+r12*1], r14
000071ff71bd0c38  mov qword ptr [r15+0xF0], 0x4102F0
000071ff71bd0c43  mov r14d, [r15+0x320]
000071ff71bd0c4a  mov eax, 0x4102F0
000071ff71bd0c4f  mov rcx, 0x71FF71BD0CC0
000071ff71bd0c59  mov [r15+r14*8+0x328], rax
000071ff71bd0c61  mov [r15+r14*8+0x368], rcx
000071ff71bd0c69  add r14d, 0x01
000071ff71bd0c6d  and r14d, 0x07
000071ff71bd0c71  mov [r15+0x320], r14d
000071ff71bd0c78  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0c80  jz 0x000071FF71BCED70
000071ff71bd0c86  nop [rax+rax*1], ax
000071ff71bd0c8f  nop [rax+rax*1], eax
000071ff71bd0c97  mov eax, 0x410728
000071ff71bd0c9c  mov [r15+0x100], rax
000071ff71bd0ca3  jmp 0x000071FF719FE110
000071ff71bd0ca8  int3
000071ff71bd0ca9  call 0x000071FF71AC3FE0
000071ff71bd0cae  jmp 0x000071FF71BD0C38
000071ff71bd0cb3  int3
000071ff71bd0cb4  nop [rax+rax*1], ax
000071ff71bd0cbd  nop [rax], eax
000071ff71bd0cc0  mov rax, [r15+0xF8]
000071ff71bd0cc7  lea r14, [rax+0x100]
000071ff71bd0cce  mov r12d, [r13+r14*1]
000071ff71bd0cd3  lea r14, [rax+0x104]
000071ff71bd0cda  mov r11d, [r13+r14*1]
000071ff71bd0cdf  mov qword ptr [r15+0x48], 0x430C90
000071ff71bd0ce7  lea r14, [rax+0x108]
000071ff71bd0cee  mov r10d, [r13+r14*1]
000071ff71bd0cf3  lea r14, [rax+0x10C]
000071ff71bd0cfa  mov r9d, [r13+r14*1]
000071ff71bd0cff  bswap r12d
000071ff71bd0d02  bswap r11d
000071ff71bd0d05  mov qword ptr [r15+0xA0], 0x00
000071ff71bd0d10  mov r14d, 0x430C90
000071ff71bd0d16  mov [r13+r14*1], r12d
000071ff71bd0d1b  mov r14d, 0x430C94
000071ff71bd0d21  mov [r13+r14*1], r11d
000071ff71bd0d26  bswap r10d
000071ff71bd0d29  lea r14, [rax+0x110]
000071ff71bd0d30  mov r12d, [r13+r14*1]
000071ff71bd0d35  bswap r9d
000071ff71bd0d38  lea r14, [rax+0x114]
000071ff71bd0d3f  mov r11d, [r13+r14*1]
000071ff71bd0d44  mov qword ptr [r15+0x98], 0x430DFC
000071ff71bd0d4f  mov r14d, 0x430C98
000071ff71bd0d55  mov [r13+r14*1], r10d
000071ff71bd0d5a  mov r14d, 0x430C9C
000071ff71bd0d60  mov [r13+r14*1], r9d
000071ff71bd0d65  bswap r12d
000071ff71bd0d68  lea r14, [rax+0x118]
000071ff71bd0d6f  mov r10d, [r13+r14*1]
000071ff71bd0d74  bswap r11d
000071ff71bd0d77  mov [rsp+0x10], r11d
000071ff71bd0d7c  mov r11d, r11d
000071ff71bd0d7f  mov [r15+0x58], r11
000071ff71bd0d83  lea r14, [rax+0x11C]
000071ff71bd0d8a  mov eax, [r13+r14*1]
000071ff71bd0d8f  mov [rsp+0x20], eax
000071ff71bd0d93  mov eax, eax
000071ff71bd0d95  mov [r15+0x60], rax
000071ff71bd0d99  mov eax, 0x430CA0
000071ff71bd0d9e  mov [r13+rax*1], r12d
000071ff71bd0da3  mov eax, 0x430CA4
000071ff71bd0da8  mov r14d, [rsp+0x10]
000071ff71bd0dad  mov [r13+rax*1], r14d
000071ff71bd0db2  bswap r10d
000071ff71bd0db5  mov [rsp+0x10], r10d
000071ff71bd0dba  mov r10d, r10d
000071ff71bd0dbd  mov [r15+0x40], r10
000071ff71bd0dc1  mov eax, [rsp+0x20]
000071ff71bd0dc5  bswap eax
000071ff71bd0dc7  mov [rsp+0x20], eax
000071ff71bd0dcb  mov eax, eax
000071ff71bd0dcd  mov [r15+0x50], rax
000071ff71bd0dd1  mov eax, 0x430CA8
000071ff71bd0dd6  mov r14d, [rsp+0x10]
000071ff71bd0ddb  mov [r13+rax*1], r14d
000071ff71bd0de0  mov eax, 0x430CAC
000071ff71bd0de5  mov r14d, [rsp+0x20]
000071ff71bd0dea  mov [r13+rax*1], r14d
000071ff71bd0def  mov eax, [r15+0xA0]
000071ff71bd0df6  lea r14d, [eax+0x11]
000071ff71bd0dfb  mov r14d, r14d
000071ff71bd0dfe  mov [r15], r14
000071ff71bd0e01  mov qword ptr [r15+0xF0], 0x41035C
000071ff71bd0e0c  mov r14d, [r15+0x320]
000071ff71bd0e13  mov eax, 0x41035C
000071ff71bd0e18  mov rcx, 0x71FF71BD0F90
000071ff71bd0e22  mov [r15+r14*8+0x328], rax
000071ff71bd0e2a  mov [r15+r14*8+0x368], rcx
000071ff71bd0e32  add r14d, 0x01
000071ff71bd0e36  and r14d, 0x07
000071ff71bd0e3a  mov [r15+0x320], r14d
000071ff71bd0e41  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0e49  jz 0x000071FF71BD0F20
000071ff71bd0e4f  nop [rax+rax*1], ax
000071ff71bd0e58  nop [rax+rax*1], eax
000071ff71bd0e60  mov eax, 0x4109A4
000071ff71bd0e65  mov [r15+0x100], rax
000071ff71bd0e6c  jmp 0x000071FF719FE110
000071ff71bd0e71  int3
000071ff71bd0e72  call 0x000071FF71AE26A0
000071ff71bd0e77  jmp 0x000071FF71BD0CD3
000071ff71bd0e7c  call 0x000071FF71AE1430
000071ff71bd0e81  jmp 0x000071FF71BD0CDF
000071ff71bd0e86  call 0x000071FF71AE01C0
000071ff71bd0e8b  jmp 0x000071FF71BD0CF3
000071ff71bd0e90  call 0x000071FF71ADEF50
000071ff71bd0e95  jmp 0x000071FF71BD0CFF
000071ff71bd0e9a  call 0x000071FF71AE2BA0
000071ff71bd0e9f  jmp 0x000071FF71BD0D1B
000071ff71bd0ea4  call 0x000071FF71AE1920
000071ff71bd0ea9  jmp 0x000071FF71BD0D26
000071ff71bd0eae  call 0x000071FF71AE26A0
000071ff71bd0eb3  jmp 0x000071FF71BD0D35
000071ff71bd0eb8  call 0x000071FF71AE1430
000071ff71bd0ebd  jmp 0x000071FF71BD0D44
000071ff71bd0ec2  call 0x000071FF71AE06B0
000071ff71bd0ec7  jmp 0x000071FF71BD0D5A
000071ff71bd0ecc  call 0x000071FF71ADF440
000071ff71bd0ed1  jmp 0x000071FF71BD0D65
000071ff71bd0ed6  call 0x000071FF71AE01C0
000071ff71bd0edb  jmp 0x000071FF71BD0D74
000071ff71bd0ee0  call 0x000071FF71AD5890
000071ff71bd0ee5  jmp 0x000071FF71BD0D8F
000071ff71bd0eea  call 0x000071FF71A0BAE0
000071ff71bd0eef  jmp 0x000071FF71BD0DA3
000071ff71bd0ef4  call 0x000071FF71A0DFE0
000071ff71bd0ef9  jmp 0x000071FF71BD0DB2
000071ff71bd0efe  call 0x000071FF71A0DFE0
000071ff71bd0f03  jmp 0x000071FF71BD0DE0
000071ff71bd0f08  call 0x000071FF71A0DFE0
000071ff71bd0f0d  jmp 0x000071FF71BD0DEF
000071ff71bd0f12  int3
000071ff71bd0f13  nop [rax+rax*1], ax
000071ff71bd0f1c  nop [rax], eax
000071ff71bd0f20  mov eax, [r15]
000071ff71bd0f23  mov [rsp+0x10], eax
000071ff71bd0f27  shr eax, 0x10
000071ff71bd0f2a  mov r14d, [rsp+0x10]
000071ff71bd0f2f  xor r14d, eax
000071ff71bd0f32  imul r14d, r14d, 0x7FEB352D
000071ff71bd0f39  mov eax, 0x846CA68B
000071ff71bd0f3e  mov eax, eax
000071ff71bd0f40  mov [r15+0x48], rax
000071ff71bd0f44  mov [rsp+0x10], r14d
000071ff71bd0f49  shr r14d, 0x0F
000071ff71bd0f4d  mov eax, [rsp+0x10]
000071ff71bd0f51  xor eax, r14d
000071ff71bd0f54  imul eax, eax, 0x846CA68B
000071ff71bd0f5a  mov [rsp+0x10], eax
000071ff71bd0f5e  mov eax, eax
000071ff71bd0f60  mov [r15+0x40], rax
000071ff71bd0f64  mov eax, [rsp+0x10]
000071ff71bd0f68  shr eax, 0x10
000071ff71bd0f6b  mov r14d, [rsp+0x10]
000071ff71bd0f70  xor r14d, eax
000071ff71bd0f73  mov r14d, r14d
000071ff71bd0f76  mov [r15], r14
000071ff71bd0f79  mov rax, [r15+0xF0]
000071ff71bd0f80  mov [r15+0x100], rax
000071ff71bd0f87  jmp 0x000071FF71BCE5C0
000071ff71bd0f8c  int3
000071ff71bd0f8d  int3
000071ff71bd0f8e  nop
000071ff71bd0f90  mov rax, [r15+0xA0]
000071ff71bd0f97  mov [rsp+0x10], rax
000071ff71bd0f9c  shl rax, 0x02
000071ff71bd0fa0  mov r14, [r15+0x98]
000071ff71bd0fa7  lea r12, [r14+rax*1]
000071ff71bd0fab  mov eax, [r15]
000071ff71bd0fae  mov [r13+r12*1], eax
000071ff71bd0fb3  mov rax, [rsp+0x10]
000071ff71bd0fb8  lea r14, [rax+0x01]
000071ff71bd0fbc  mov [r15+0xA0], r14
000071ff71bd0fc3  xor eax, eax
000071ff71bd0fc5  mov r12d, 0x400
000071ff71bd0fcb  cmp r14, r12
000071ff71bd0fce  cmc
000071ff71bd0fcf  lahf
000071ff71bd0fd0  seto al
000071ff71bd0fd3  mov [r15+0x108], eax
000071ff71bd0fda  mov eax, [r15+0x108]
000071ff71bd0fe1  sahf
000071ff71bd0fe2  jnz 0x000071FF71BD1014
000071ff71bd0fe4  cmp dword ptr [r15+0x318], 0x00
000071ff71bd0fec  jz 0x000071FF71BD10E0
000071ff71bd0ff2  nop [rax+rax*1], ax
000071ff71bd0ffb  nop [rax+rax*1], eax
000071ff71bd1003  mov eax, 0x41036C
000071ff71bd1008  mov [r15+0x100], rax
000071ff71bd100f  jmp 0x000071FF719FE110
000071ff71bd1014  cmp dword ptr [r15+0x318], 0x00
000071ff71bd101c  jz 0x000071FF71BD1050
000071ff71bd1022  nop [rax+rax*1], ax
000071ff71bd102b  nop [rax+rax*1], eax
000071ff71bd1033  mov eax, 0x410354
000071ff71bd1038  mov [r15+0x100], rax
000071ff71bd103f  jmp 0x000071FF719FE110
000071ff71bd1044  int3
000071ff71bd1045  call 0x000071FF71AB4B70
000071ff71bd104a  jmp 0x000071FF71BD0FB3
000071ff71bd104f  int3
000071ff71bd1050  mov eax, [r15+0xA0]
000071ff71bd1057  lea r14d, [eax+0x11]
000071ff71bd105c  mov r14d, r14d
000071ff71bd105f  mov [r15], r14
000071ff71bd1062  mov qword ptr [r15+0xF0], 0x41035C
000071ff71bd106d  mov r14d, [r15+0x320]
000071ff71bd1074  mov eax, 0x41035C
000071ff71bd1079  mov rcx, 0x71FF71BD0F90
000071ff71bd1083  mov [r15+r14*8+0x328], rax
000071ff71bd108b  mov [r15+r14*8+0x368], rcx
000071ff71bd1093  add r14d, 0x01
000071ff71bd1097  and r14d, 0x07
000071ff71bd109b  mov [r15+0x320], r14d
000071ff71bd10a2  cmp dword ptr [r15+0x318], 0x00
000071ff71bd10aa  jz 0x000071FF71BD0F20
000071ff71bd10b0  nop [rax+rax*1], ax
000071ff71bd10b9  nop [rax+rax*1], eax
000071ff71bd10c1  mov eax, 0x4109A4
000071ff71bd10c6  mov [r15+0x100], rax
000071ff71bd10cd  jmp 0x000071FF719FE110
000071ff71bd10d2  int3
000071ff71bd10d3  int3
000071ff71bd10d4  nop [rax+rax*1], ax
000071ff71bd10dd  nop [rax], eax
000071ff71bd10e0  mov qword ptr [r15+0x40], 0x01
000071ff71bd10e8  cmp dword ptr [r15+0x318], 0x00
000071ff71bd10f0  jz 0x000071FF71BD1120
000071ff71bd10f6  nop [rax+rax*1], ax
000071ff71bd10ff  nop [rax+rax*1], eax
000071ff71bd1107  mov eax, 0x410388
000071ff71bd110c  mov [r15+0x100], rax
000071ff71bd1113  jmp 0x000071FF719FE110
000071ff71bd1118  int3
000071ff71bd1119  int3
000071ff71bd111a  nop [rax+rax*1], ax
000071ff71bd1120  mov rax, [r15+0x40]
000071ff71bd1124  mov [rsp+0x10], rax
000071ff71bd1129  shl rax, 0x02
000071ff71bd112d  mov r14, [r15+0x98]
000071ff71bd1134  lea r12, [r14+rax*1]
000071ff71bd1138  mov eax, [r13+r12*1]
000071ff71bd113d  mov [rsp+0x20], eax
000071ff71bd1141  mov eax, eax
000071ff71bd1143  mov [r15+0x48], rax
000071ff71bd1147  mov rax, [rsp+0x10]
000071ff71bd114c  mov [r15+0x50], rax
000071ff71bd1150  mov eax, [r15+0x50]
000071ff71bd1154  lea r12d, [eax-0x01]
000071ff71bd1159  mov r12d, r12d
000071ff71bd115c  mov [r15+0x58], r12
000071ff71bd1160  mov rax, [r15+0x58]
000071ff71bd1164  mov r12d, eax
000071ff71bd1167  mov r12d, r12d
000071ff71bd116a  shl r12, 0x02
000071ff71bd116e  lea rax, [r14+r12*1]
000071ff71bd1172  mov r14d, [r13+rax*1]
000071ff71bd1177  mov [rsp+0x10], r14d
000071ff71bd117c  mov r14d, r14d
000071ff71bd117f  mov [r15+0x60], r14
000071ff71bd1183  xor eax, eax
000071ff71bd1185  mov r14d, [rsp+0x10]
000071ff71bd118a  mov r12d, [rsp+0x20]
000071ff71bd118f  cmp r14d, r12d
000071ff71bd1192  cmc
000071ff71bd1193  lahf
000071ff71bd1194  seto al
000071ff71bd1197  mov [r15+0x108], eax
000071ff71bd119e  mov eax, [r15+0x108]
000071ff71bd11a5  sahf
000071ff71bd11a6  cmc
000071ff71bd11a7  jbe 0x000071FF71BD11D9
000071ff71bd11a9  cmp dword ptr [r15+0x318], 0x00
000071ff71bd11b1  jz 0x000071FF71BD1220
000071ff71bd11b7  nop [rax+rax*1], ax
000071ff71bd11c0  nop [rax+rax*1], eax
000071ff71bd11c8  mov eax, 0x4103A0
000071ff71bd11cd  mov [r15+0x100], rax
000071ff71bd11d4  jmp 0x000071FF719FE110
000071ff71bd11d9  cmp dword ptr [r15+0x318], 0x00
000071ff71bd11e1  jz 0x000071FF71BD14C0
000071ff71bd11e7  nop [rax+rax*1], ax
000071ff71bd11f0  nop [rax+rax*1], eax
000071ff71bd11f8  mov eax, 0x410378
000071ff71bd11fd  mov [r15+0x100], rax
000071ff71bd1204  jmp 0x000071FF719FE110
000071ff71bd1209  int3
000071ff71bd120a  call 0x000071FF71AB4690
000071ff71bd120f  jmp 0x000071FF71BD113D
000071ff71bd1214  call 0x000071FF71A0DAE0
000071ff71bd1219  jmp 0x000071FF71BD1177
000071ff71bd121e  int3
000071ff71bd121f  nop
000071ff71bd1220  mov rax, [r15+0x50]
000071ff71bd1224  mov [rsp+0x10], rax
000071ff71bd1229  shl rax, 0x02
000071ff71bd122d  mov r14, [r15+0x98]
000071ff71bd1234  lea r12, [r14+rax*1]
000071ff71bd1238  mov eax, [r15+0x60]
000071ff71bd123c  mov [r13+r12*1], eax
000071ff71bd1241  mov rax, [rsp+0x10]
000071ff71bd1246  lea r14, [rax-0x01]
000071ff71bd124a  mov [r15+0x50], r14
000071ff71bd124e  mov rax, [r15+0x58]
000071ff71bd1252  test rax, rax
000071ff71bd1255  setz al
000071ff71bd1258  movzx rax, al
000071ff71bd125c  mov [rsp+0x414], al
000071ff71bd1263  cmp byte ptr [rsp+0x414], 0x00
000071ff71bd126b  jz 0x000071FF71BD129D
000071ff71bd126d  cmp dword ptr [r15+0x318], 0x00
000071ff71bd1275  jz 0x000071FF71BD12E0
000071ff71bd127b  nop [rax+rax*1], ax
000071ff71bd1284  nop [rax+rax*1], eax
000071ff71bd128c  mov eax, 0x4103AC
000071ff71bd1291  mov [r15+0x100], rax
000071ff71bd1298  jmp 0x000071FF719FE110
000071ff71bd129d  cmp dword ptr [r15+0x318], 0x00
000071ff71bd12a5  jz 0x000071FF71BD13E0
000071ff71bd12ab  nop [rax+rax*1], ax
000071ff71bd12b4  nop [rax+rax*1], eax
000071ff71bd12bc  mov eax, 0x410390
000071ff71bd12c1  mov [r15+0x100], rax
000071ff71bd12c8  jmp 0x000071FF719FE110
000071ff71bd12cd  int3
000071ff71bd12ce  call 0x000071FF71AB4B70
000071ff71bd12d3  jmp 0x000071FF71BD1241
000071ff71bd12d8  int3
000071ff71bd12d9  nop [rax], eax
000071ff71bd12e0  cmp dword ptr [r15+0x318], 0x00
000071ff71bd12e8  jz 0x000071FF71BD1320
000071ff71bd12ee  nop [rax+rax*1], ax
000071ff71bd12f7  nop [rax+rax*1], eax
000071ff71bd12ff  mov eax, 0x410374
000071ff71bd1304  mov [r15+0x100], rax
000071ff71bd130b  jmp 0x000071FF719FE110
000071ff71bd1310  int3
000071ff71bd1311  int3
000071ff71bd1312  nop [rax+rax*1], ax
000071ff71bd131b  nop [rax+rax*1], eax
000071ff71bd1320  mov qword ptr [r15+0x50], 0x00
000071ff71bd1328  mov rax, [r15+0x40]
000071ff71bd132c  lea r14, [rax+0x01]
000071ff71bd1330  mov [r15+0x40], r14
000071ff71bd1334  mov rax, [r15+0x98]
000071ff71bd133b  mov r12d, [r15+0x48]
000071ff71bd133f  mov [r13+rax*1], r12d
000071ff71bd1344  xor eax, eax
000071ff71bd1346  mov r12d, 0x400
000071ff71bd134c  cmp r14, r12
000071ff71bd134f  cmc
000071ff71bd1350  lahf
000071ff71bd1351  seto al
000071ff71bd1354  mov [r15+0x108], eax
000071ff71bd135b  mov eax, [r15+0x108]
000071ff71bd1362  sahf
000071ff71bd1363  jz 0x000071FF71BD1395
000071ff71bd1365  cmp dword ptr [r15+0x318], 0x00
000071ff71bd136d  jz 0x000071FF71BD1120
000071ff71bd1373  nop [rax+rax*1], ax
000071ff71bd137c  nop [rax+rax*1], eax
000071ff71bd1384  mov eax, 0x410388
000071ff71bd1389  mov [r15+0x100], rax
000071ff71bd1390  jmp 0x000071FF719FE110
000071ff71bd1395  cmp dword ptr [r15+0x318], 0x00
000071ff71bd139d  jz 0x000071FF71BD1580
000071ff71bd13a3  nop [rax+rax*1], ax
000071ff71bd13ac  nop [rax+rax*1], eax
000071ff71bd13b4  mov eax, 0x4103B0
000071ff71bd13b9  mov [r15+0x100], rax
000071ff71bd13c0  jmp 0x000071FF719FE110
000071ff71bd13c5  int3
000071ff71bd13c6  call 0x000071FF71A0BAE0
000071ff71bd13cb  jmp 0x000071FF71BD1344
000071ff71bd13d0  int3
000071ff71bd13d1  nop [rax+rax*1], ax
000071ff71bd13da  nop [rax+rax*1], ax
000071ff71bd13e0  mov eax, [r15+0x50]
000071ff71bd13e4  lea r14d, [eax-0x01]
000071ff71bd13e9  mov r14d, r14d
000071ff71bd13ec  mov [r15+0x58], r14
000071ff71bd13f0  mov rax, [r15+0x58]
000071ff71bd13f4  mov r14d, eax
000071ff71bd13f7  mov r14d, r14d
000071ff71bd13fa  shl r14, 0x02
000071ff71bd13fe  mov rax, [r15+0x98]
000071ff71bd1405  lea r12, [rax+r14*1]
000071ff71bd1409  mov eax, [r13+r12*1]
000071ff71bd140e  mov [rsp+0x10], eax
000071ff71bd1412  mov eax, eax
000071ff71bd1414  mov [r15+0x60], rax
000071ff71bd1418  mov eax, [r15+0x48]
000071ff71bd141c  mov [rsp+0x20], eax
000071ff71bd1420  xor eax, eax
000071ff71bd1422  mov r14d, [rsp+0x10]
000071ff71bd1427  mov r12d, [rsp+0x20]
000071ff71bd142c  cmp r14d, r12d
000071ff71bd142f  cmc
000071ff71bd1430  lahf
000071ff71bd1431  seto al
000071ff71bd1434  mov [r15+0x108], eax
000071ff71bd143b  mov eax, [r15+0x108]
000071ff71bd1442  sahf
000071ff71bd1443  cmc
000071ff71bd1444  jbe 0x000071FF71BD1476
000071ff71bd1446  cmp dword ptr [r15+0x318], 0x00
000071ff71bd144e  jz 0x000071FF71BD1220
000071ff71bd1454  nop [rax+rax*1], ax
000071ff71bd145d  nop [rax+rax*1], eax
000071ff71bd1465  mov eax, 0x4103A0
000071ff71bd146a  mov [r15+0x100], rax
000071ff71bd1471  jmp 0x000071FF719FE110
000071ff71bd1476  cmp dword ptr [r15+0x318], 0x00
000071ff71bd147e  jz 0x000071FF71BD14C0
000071ff71bd1484  nop [rax+rax*1], ax
000071ff71bd148d  nop [rax+rax*1], eax
000071ff71bd1495  mov eax, 0x410378
000071ff71bd149a  mov [r15+0x100], rax
000071ff71bd14a1  jmp 0x000071FF719FE110
000071ff71bd14a6  int3
000071ff71bd14a7  call 0x000071FF71AB4690
000071ff71bd14ac  jmp 0x000071FF71BD140E
000071ff71bd14b1  int3
000071ff71bd14b2  nop [rax+rax*1], ax
000071ff71bd14bb  nop [rax+rax*1], eax
000071ff71bd14c0  mov rax, [r15+0x40]
000071ff71bd14c4  lea r14, [rax+0x01]
000071ff71bd14c8  mov [r15+0x40], r14
000071ff71bd14cc  mov rax, [r15+0x50]
000071ff71bd14d0  mov r12d, eax
000071ff71bd14d3  mov r12d, r12d
000071ff71bd14d6  shl r12, 0x02
000071ff71bd14da  mov rax, [r15+0x98]
000071ff71bd14e1  lea r11, [rax+r12*1]
000071ff71bd14e5  mov eax, [r15+0x48]
000071ff71bd14e9  mov [r13+r11*1], eax
000071ff71bd14ee  xor eax, eax
000071ff71bd14f0  mov r12d, 0x400
000071ff71bd14f6  cmp r14, r12
000071ff71bd14f9  cmc
000071ff71bd14fa  lahf
000071ff71bd14fb  seto al
000071ff71bd14fe  mov [r15+0x108], eax
000071ff71bd1505  mov eax, [r15+0x108]
000071ff71bd150c  sahf
000071ff71bd150d  jz 0x000071FF71BD153F
000071ff71bd150f  cmp dword ptr [r15+0x318], 0x00
000071ff71bd1517  jz 0x000071FF71BD1120
000071ff71bd151d  nop [rax+rax*1], ax
000071ff71bd1526  nop [rax+rax*1], eax
000071ff71bd152e  mov eax, 0x410388
000071ff71bd1533  mov [r15+0x100], rax
000071ff71bd153a  jmp 0x000071FF719FE110
000071ff71bd153f  cmp dword ptr [r15+0x318], 0x00
000071ff71bd1547  jz 0x000071FF71BD1580
000071ff71bd154d  nop [rax+rax*1], ax
000071ff71bd1556  nop [rax+rax*1], eax
000071ff71bd155e  mov eax, 0x4103B0
000071ff71bd1563  mov [r15+0x100], rax
000071ff71bd156a  jmp 0x000071FF719FE110
000071ff71bd156f  int3
000071ff71bd1570  call 0x000071FF71AA4270
000071ff71bd1575  jmp 0x000071FF71BD14EE
000071ff71bd157a  int3
000071ff71bd157b  nop [rax+rax*1], eax
000071ff71bd1580  mov qword ptr [r15+0x40], 0x430000
000071ff71bd1588  mov eax, 0x430CB0
000071ff71bd158d  mov r14, [r13+rax*1]
000071ff71bd1592  mov rax, [r15+0x98]
000071ff71bd1599  mov r12d, [r13+rax*1]
000071ff71bd159e  lea r11, [rax+0x04]
000071ff71bd15a2  mov eax, [r13+r11*1]
000071ff71bd15a7  mov r12d, r12d
000071ff71bd15aa  mov [r15+0x68], r12
000071ff71bd15ae  mov eax, eax
000071ff71bd15b0  mov [r15+0x60], rax
000071ff71bd15b4  mov rax, [r15+0x68]
000071ff71bd15b8  mov [r15+0x68], rax
000071ff71bd15bc  mov qword ptr [r15+0x58], 0x02
000071ff71bd15c4  mov [rsp+0x10], rax
000071ff71bd15c9  xor eax, eax
000071ff71bd15cb  mov r12d, 0x02
000071ff71bd15d1  mov r11d, 0x400
000071ff71bd15d7  cmp r12, r11
000071ff71bd15da  cmc
000071ff71bd15db  lahf
000071ff71bd15dc  seto al
000071ff71bd15df  mov [r15+0x108], eax
000071ff71bd15e6  mov rax, [r15+0x60]
000071ff71bd15ea  mov r12d, 0x02
000071ff71bd15f0  imul rax, r12
000071ff71bd15f4  mov [r15+0x50], rax
000071ff71bd15f8  mov rax, [rsp+0x10]
000071ff71bd15fd  lea r12, [rax+r14*1]
000071ff71bd1601  mov [r15+0x48], r12
000071ff71bd1605  mov eax, [r15+0x108]
000071ff71bd160c  sahf
000071ff71bd160d  jnz 0x000071FF71BD163F
000071ff71bd160f  cmp dword ptr [r15+0x318], 0x00
000071ff71bd1617  jz 0x000071FF71BD17B0
000071ff71bd161d  nop [rax+rax*1], ax
000071ff71bd1626  nop [rax+rax*1], eax
000071ff71bd162e  mov eax, 0x4103E0
000071ff71bd1633  mov [r15+0x100], rax
000071ff71bd163a  jmp 0x000071FF719FE110
000071ff71bd163f  cmp dword ptr [r15+0x318], 0x00
000071ff71bd1647  jz 0x000071FF71BD1690
000071ff71bd164d  nop [rax+rax*1], ax
000071ff71bd1656  nop [rax+rax*1], eax
000071ff71bd165e  mov eax, 0x4103C0
000071ff71bd1663  mov [r15+0x100], rax
000071ff71bd166a  jmp 0x000071FF719FE110
000071ff71bd166f  int3
000071ff71bd1670  call 0x000071FF71A0DC20
000071ff71bd1675  jmp 0x000071FF71BD1592
000071ff71bd167a  call 0x000071FF71A0B5E0
000071ff71bd167f  jmp 0x000071FF71BD159E
000071ff71bd1684  call 0x000071FF71AA3D90
000071ff71bd1689  jmp 0x000071FF71BD15A7
000071ff71bd168e  int3
000071ff71bd168f  nop
000071ff71bd1690  mov rax, [r15+0x98]
000071ff71bd1697  mov r14, [r15+0x58]
000071ff71bd169b  mov [rsp+0x10], r14
000071ff71bd16a0  shl r14, 0x02
000071ff71bd16a4  lea r12, [rax+r14*1]
000071ff71bd16a8  mov eax, [r13+r12*1]
000071ff71bd16ad  lea r14, [r12+0x04]
000071ff71bd16b2  mov r12d, [r13+r14*1]
000071ff71bd16b7  mov eax, eax
000071ff71bd16b9  mov [r15+0x68], rax
000071ff71bd16bd  mov r12d, r12d
000071ff71bd16c0  mov [r15+0x60], r12
000071ff71bd16c4  mov rax, [r15+0x68]
000071ff71bd16c8  mov [rsp+0x20], rax
000071ff71bd16cd  mov r14, [rsp+0x10]
000071ff71bd16d2  imul rax, r14
000071ff71bd16d6  mov r12, [rsp+0x20]
000071ff71bd16db  lea r11, [r12+rax*1]
000071ff71bd16df  mov [r15+0x68], r11
000071ff71bd16e3  lea rax, [r14+0x02]
000071ff71bd16e7  mov [r15+0x58], rax
000071ff71bd16eb  mov [rsp+0x10], rax
000071ff71bd16f0  xor eax, eax
000071ff71bd16f2  mov r14, [rsp+0x10]
000071ff71bd16f7  mov r12d, 0x400
000071ff71bd16fd  cmp r14, r12
000071ff71bd1700  cmc
000071ff71bd1701  lahf
000071ff71bd1702  seto al
000071ff71bd1705  mov [r15+0x108], eax
000071ff71bd170c  mov rax, [r15+0x50]
000071ff71bd1710  mov r12, [r15+0x60]
000071ff71bd1714  imul r14, r12
000071ff71bd1718  lea r12, [rax+r14*1]
000071ff71bd171c  mov [r15+0x50], r12
000071ff71bd1720  mov rax, [r15+0x48]
000071ff71bd1724  lea r14, [r11+rax*1]
000071ff71bd1728  mov [r15+0x48], r14
000071ff71bd172c  mov eax, [r15+0x108]
000071ff71bd1733  sahf
000071ff71bd1734  jnz 0x000071FF71BD1766
000071ff71bd1736  cmp dword ptr [r15+0x318], 0x00
000071ff71bd173e  jz 0x000071FF71BD17B0
000071ff71bd1744  nop [rax+rax*1], ax
000071ff71bd174d  nop [rax+rax*1], eax
000071ff71bd1755  mov eax, 0x4103E0
000071ff71bd175a  mov [r15+0x100], rax
000071ff71bd1761  jmp 0x000071FF719FE110
000071ff71bd1766  cmp dword ptr [r15+0x318], 0x00
000071ff71bd176e  jz 0x000071FF71BD1690
000071ff71bd1774  nop [rax+rax*1], ax
000071ff71bd177d  nop [rax+rax*1], eax
000071ff71bd1785  mov eax, 0x4103C0
000071ff71bd178a  mov [r15+0x100], rax
000071ff71bd1791  jmp 0x000071FF719FE110
000071ff71bd1796  int3
000071ff71bd1797  call 0x000071FF71AB4690
000071ff71bd179c  jmp 0x000071FF71BD16AD
000071ff71bd17a1  call 0x000071FF71AE26A0
000071ff71bd17a6  jmp 0x000071FF71BD16B7
000071ff71bd17ab  int3
000071ff71bd17ac  nop [rax], eax
000071ff71bd17b0  mov qword ptr [r15+0x98], 0x00
000071ff71bd17bb  mov rax, [r15+0x50]
000071ff71bd17bf  mov r14, [r15+0x48]
000071ff71bd17c3  lea r12, [rax+r14*1]
000071ff71bd17c7  mov [r15+0x48], r12
000071ff71bd17cb  mov rax, [r15+0x40]
000071ff71bd17cf  lea r14, [rax+0xCB0]
000071ff71bd17d6  mov [r13+r14*1], r12
000071ff71bd17db  mov qword ptr [r15], 0x01
000071ff71bd17e2  mov qword ptr [r15+0xF0], 0x4103F8
000071ff71bd17ed  mov r14d, [r15+0x320]
000071ff71bd17f4  mov eax, 0x4103F8
000071ff71bd17f9  mov rcx, 0x71FF71BD1860
000071ff71bd1803  mov [r15+r14*8+0x328], rax
000071ff71bd180b  mov [r15+r14*8+0x368], rcx
000071ff71bd1813  add r14d, 0x01
000071ff71bd1817  and r14d, 0x07
000071ff71bd181b  mov [r15+0x320], r14d
000071ff71bd1822  cmp dword ptr [r15+0x318], 0x00
000071ff71bd182a  jz 0x000071FF71BD0F20
000071ff71bd1830  nop [rax+rax*1], ax
000071ff71bd1839  nop [rax+rax*1], eax
000071ff71bd1841  mov eax, 0x4109A4
000071ff71bd1846  mov [r15+0x100], rax
000071ff71bd184d  jmp 0x000071FF719FE110
000071ff71bd1852  int3
000071ff71bd1853  call 0x000071FF71AE2CE0
000071ff71bd1858  jmp 0x000071FF71BD17DB
000071ff71bd185d  int3
000071ff71bd185e  nop
000071ff71bd1860  mov eax, [r15+0x98]
000071ff71bd1867  lea r14d, [eax+0x01]
000071ff71bd186c  mov [rsp+0x10], r14d
000071ff71bd1871  mov r14d, r14d
000071ff71bd1874  mov [r15+0x98], r14
000071ff71bd187b  xor eax, eax
000071ff71bd187d  mov r14d, [rsp+0x10]
000071ff71bd1882  cmp r14d, 0x10000
000071ff71bd1889  cmc
000071ff71bd188a  lahf
000071ff71bd188b  seto al
000071ff71bd188e  mov [r15+0x108], eax
000071ff71bd1895  mov eax, [r15+0x108]
000071ff71bd189c  sahf
000071ff71bd189d  jnz 0x000071FF71BD18CF
000071ff71bd189f  cmp dword ptr [r15+0x318], 0x00
000071ff71bd18a7  jz 0x000071FF71BD19A0
000071ff71bd18ad  nop [rax+rax*1], ax
000071ff71bd18b6  nop [rax+rax*1], eax
000071ff71bd18be  mov eax, 0x410404
000071ff71bd18c3  mov [r15+0x100], rax
000071ff71bd18ca  jmp 0x000071FF719FE110
000071ff71bd18cf  cmp dword ptr [r15+0x318], 0x00
000071ff71bd18d7  jz 0x000071FF71BD1910
000071ff71bd18dd  nop [rax+rax*1], ax
000071ff71bd18e6  nop [rax+rax*1], eax
000071ff71bd18ee  mov eax, 0x4103F0
000071ff71bd18f3  mov [r15+0x100], rax
000071ff71bd18fa  jmp 0x000071FF719FE110
000071ff71bd18ff  int3
000071ff71bd1900  int3
000071ff71bd1901  nop [rax+rax*1], ax
000071ff71bd190a  nop [rax+rax*1], ax
000071ff71bd1910  mov eax, [r15]
000071ff71bd1913  mov r14d, [r15+0x98]
000071ff71bd191a  lea r12d, [eax+r14d*1]
000071ff71bd191f  mov r12d, r12d
000071ff71bd1922  mov [r15], r12
000071ff71bd1925  mov qword ptr [r15+0xF0], 0x4103F8
000071ff71bd1930  mov r14d, [r15+0x320]
000071ff71bd1937  mov eax, 0x4103F8
000071ff71bd193c  mov rcx, 0x71FF71BD1860
000071ff71bd1946  mov [r15+r14*8+0x328], rax
000071ff71bd194e  mov [r15+r14*8+0x368], rcx
000071ff71bd1956  add r14d, 0x01
000071ff71bd195a  and r14d, 0x07
000071ff71bd195e  mov [r15+0x320], r14d
000071ff71bd1965  cmp dword ptr [r15+0x318], 0x00
000071ff71bd196d  jz 0x000071FF71BD0F20
000071ff71bd1973  nop [rax+rax*1], ax
000071ff71bd197c  nop [rax+rax*1], eax
000071ff71bd1984  mov eax, 0x4109A4
000071ff71bd1989  mov [r15+0x100], rax
000071ff71bd1990  jmp 0x000071FF719FE110
000071ff71bd1995  int3
000071ff71bd1996  int3
000071ff71bd1997  nop [rax+rax*1], ax
000071ff71bd19a0  vmovaps xmm1, [0x000071FF717FE010]
000071ff71bd19a8  movq xmm1, xmm1
000071ff71bd19ac  movaps [r15+0x110], xmm1
000071ff71bd19b4  mov eax, 0x420B10
000071ff71bd19b9  mov r14, [r13+rax*1]
000071ff71bd19be  movq xmm1, r14
000071ff71bd19c3  movaps [r15+0x120], xmm1
000071ff71bd19cb  vmovaps xmm1, [0x000071FF717FE020]
000071ff71bd19d3  movq xmm1, xmm1
000071ff71bd19d7  movaps [r15+0x140], xmm1
000071ff71bd19df  vmovaps xmm1, [0x000071FF717FE030]
000071ff71bd19e7  vpbroadcastq xmm1, xmm1
000071ff71bd19ec  movaps [r15+0x150], xmm1
000071ff71bd19f4  mov qword ptr [r15+0x40], 0x02
000071ff71bd19fc  vmovaps xmm15, [0x000071FF717FE040]
000071ff71bd1a04  movq xmm15, xmm15
000071ff71bd1a09  movaps [r15+0x160], xmm15
000071ff71bd1a11  vmovaps xmm15, [0x000071FF717FE050]
000071ff71bd1a19  vpbroadcastq xmm15, xmm15
000071ff71bd1a1e  movaps [r15+0x130], xmm15
000071ff71bd1a26  mov rax, [r15+0x40]
000071ff71bd1a2a  vmovq xmm14, rax
000071ff71bd1a2f  vpbroadcastq xmm14, xmm14
000071ff71bd1a34  movaps [r15+0x170], xmm14
000071ff71bd1a3c  mov eax, 0x420A40
000071ff71bd1a41  movups xmm13, [r13+rax*1]
000071ff71bd1a47  mov qword ptr [r15+0x40], 0x431E00
000071ff71bd1a4f  mov eax, [r15]
000071ff71bd1a52  mov r14d, 0x430CB8
000071ff71bd1a58  mov [r13+r14*1], eax
000071ff71bd1a5d  mov qword ptr [r15+0x50], 0x432000
000071ff71bd1a65  vpmovqd xmm12, xmm13
000071ff71bd1a6b  pxor xmm11, xmm11
000071ff71bd1a70  punpcklqdq xmm12, xmm11
000071ff71bd1a75  movaps [r15+0x210], xmm12
000071ff71bd1a7d  movq xmm12, qword ptr [r15+0x140]
000071ff71bd1a86  movq xmm11, qword ptr [r15+0x120]
000071ff71bd1a8f  psubd xmm12, xmm11
000071ff71bd1a94  movq xmm12, xmm12
000071ff71bd1a99  paddq xmm13, xmm14
000071ff71bd1a9e  movaps [r15+0x180], xmm13
000071ff71bd1aa6  movq xmm14, qword ptr [r15+0x160]
000071ff71bd1aaf  paddd xmm11, xmm14
000071ff71bd1ab4  movq xmm11, xmm11
000071ff71bd1ab9  movq xmm11, xmm11
000071ff71bd1abe  movaps [r15+0x120], xmm11
000071ff71bd1ac6  pmovzxdq xmm12, xmm12
000071ff71bd1acc  psllq xmm12, 0x00
000071ff71bd1ad2  movq xmm14, qword ptr [r15+0x210]
000071ff71bd1adb  movq xmm13, qword ptr [r15+0x110]
000071ff71bd1ae4  paddd xmm14, xmm13
000071ff71bd1ae9  movq xmm14, xmm14
000071ff71bd1aee  vcvtuqq2pd xmm12, xmm12
000071ff71bd1af4  pmovzxdq xmm14, xmm14
000071ff71bd1afa  psllq xmm14, 0x00
000071ff71bd1b00  vcvtuqq2pd xmm14, xmm14
000071ff71bd1b06  movaps xmm13, xmm12
000071ff71bd1b0a  mulpd xmm13, xmm1
000071ff71bd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000071ff71bd1b15  ptest xmm11, xmm11
000071ff71bd1b1b  jnz 0x000071FF71BD1C0F
000071ff71bd1b21  movaps [r15+0x220], xmm13
000071ff71bd1b29  mov eax, 0x432000
000071ff71bd1b2e  movups [r13+rax*1], xmm13
000071ff71bd1b34  movaps xmm1, xmm14
000071ff71bd1b38  mulpd xmm1, xmm15
000071ff71bd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000071ff71bd1b42  ptest xmm13, xmm13
000071ff71bd1b48  jnz 0x000071FF71BD1D5C
000071ff71bd1b4e  movaps [r15+0x210], xmm1
000071ff71bd1b56  mov eax, 0x431E00
000071ff71bd1b5b  movups [r13+rax*1], xmm1
000071ff71bd1b61  mov qword ptr [r15+0x48], 0x10
000071ff71bd1b69  xor eax, eax
000071ff71bd1b6b  mov r14d, 0x10
000071ff71bd1b71  mov r12d, 0x200
000071ff71bd1b77  cmp r14, r12
000071ff71bd1b7a  cmc
000071ff71bd1b7b  lahf
000071ff71bd1b7c  seto al
000071ff71bd1b7f  mov [r15+0x108], eax
000071ff71bd1b86  mov eax, [r15+0x108]
000071ff71bd1b8d  sahf
000071ff71bd1b8e  jnz 0x000071FF71BD1BC0
000071ff71bd1b90  cmp dword ptr [r15+0x318], 0x00
000071ff71bd1b98  jz 0x000071FF71BD2300
000071ff71bd1b9e  nop [rax+rax*1], ax
000071ff71bd1ba7  nop [rax+rax*1], eax
000071ff71bd1baf  mov eax, 0x410490
000071ff71bd1bb4  mov [r15+0x100], rax
000071ff71bd1bbb  jmp 0x000071FF719FE110
000071ff71bd1bc0  cmp dword ptr [r15+0x318], 0x00
000071ff71bd1bc8  jz 0x000071FF71BD1EB0
000071ff71bd1bce  nop [rax+rax*1], ax
000071ff71bd1bd7  nop [rax+rax*1], eax
000071ff71bd1bdf  mov eax, 0x410450
000071ff71bd1be4  mov [r15+0x100], rax
000071ff71bd1beb  jmp 0x000071FF719FE110
000071ff71bd1bf0  int3
000071ff71bd1bf1  call 0x000071FF71A0DC20
000071ff71bd1bf6  jmp 0x000071FF71BD19BE
000071ff71bd1bfb  call 0x000071FF71A0C260
000071ff71bd1c00  jmp 0x000071FF71BD1A47
000071ff71bd1c05  call 0x000071FF71AD5D70
000071ff71bd1c0a  jmp 0x000071FF71BD1A5D
000071ff71bd1c0f  sub rsp, 0x08
000071ff71bd1c13  push rax
000071ff71bd1c14  push rcx
000071ff71bd1c15  push rdx
000071ff71bd1c16  push rdi
000071ff71bd1c17  push rsi
000071ff71bd1c18  push r8
000071ff71bd1c1a  push r9
000071ff71bd1c1c  push r10
000071ff71bd1c1e  push r11
000071ff71bd1c20  sub rsp, 0xF0
000071ff71bd1c27  vmovaps [rsp], xmm0
000071ff71bd1c2c  vmovaps [rsp+0x10], xmm1
000071ff71bd1c32  vmovaps [rsp+0x20], xmm2
000071ff71bd1c38  vmovaps [rsp+0x30], xmm3
000071ff71bd1c3e  vmovaps [rsp+0x40], xmm4
000071ff71bd1c44  vmovaps [rsp+0x50], xmm5
000071ff71bd1c4a  vmovaps [rsp+0x60], xmm6
000071ff71bd1c50  vmovaps [rsp+0x70], xmm7
000071ff71bd1c56  vmovaps [rsp+0x80], xmm8
000071ff71bd1c5f  vmovaps [rsp+0x90], xmm9
000071ff71bd1c68  vmovaps [rsp+0xA0], xmm10
000071ff71bd1c71  vmovaps [rsp+0xB0], xmm11
000071ff71bd1c7a  vmovaps [rsp+0xC0], xmm12
000071ff71bd1c83  vmovaps [rsp+0xD0], xmm14
000071ff71bd1c8c  vmovaps [rsp+0xE0], xmm15
000071ff71bd1c95  sub rsp, 0x30
000071ff71bd1c99  movaps [rsp], xmm13
000071ff71bd1c9e  movaps [rsp+0x10], xmm12
000071ff71bd1ca4  movaps [rsp+0x20], xmm1
000071ff71bd1ca9  lea rdi, [rsp]
000071ff71bd1cad  mov esi, 0x00
000071ff71bd1cb2  mov rax, 0x5E6872E10530
000071ff71bd1cbc  call rax
000071ff71bd1cbe  movaps xmm13, [rsp]
000071ff71bd1cc3  add rsp, 0x30
000071ff71bd1cc7  vmovaps xmm0, [rsp]
000071ff71bd1ccc  vmovaps xmm1, [rsp+0x10]
000071ff71bd1cd2  vmovaps xmm2, [rsp+0x20]
000071ff71bd1cd8  vmovaps xmm3, [rsp+0x30]
000071ff71bd1cde  vmovaps xmm4, [rsp+0x40]
000071ff71bd1ce4  vmovaps xmm5, [rsp+0x50]
000071ff71bd1cea  vmovaps xmm6, [rsp+0x60]
000071ff71bd1cf0  vmovaps xmm7, [rsp+0x70]
000071ff71bd1cf6  vmovaps xmm8, [rsp+0x80]
000071ff71bd1cff  vmovaps xmm9, [rsp+0x90]
000071ff71bd1d08  vmovaps xmm10, [rsp+0xA0]
000071ff71bd1d11  vmovaps xmm11, [rsp+0xB0]
000071ff71bd1d1a  vmovaps xmm12, [rsp+0xC0]
000071ff71bd1d23  vmovaps xmm14, [rsp+0xD0]
000071ff71bd1d2c  vmovaps xmm15, [rsp+0xE0]
000071ff71bd1d35  add rsp, 0xF0
000071ff71bd1d3c  pop r11
000071ff71bd1d3e  pop r10
000071ff71bd1d40  pop r9
000071ff71bd1d42  pop r8
000071ff71bd1d44  pop rsi
000071ff71bd1d45  pop rdi
000071ff71bd1d46  pop rdx
000071ff71bd1d47  pop rcx
000071ff71bd1d48  pop rax
000071ff71bd1d49  add rsp, 0x08
000071ff71bd1d4d  jmp 0x000071FF71BD1B21
000071ff71bd1d52  call 0x000071FF71A0C380
000071ff71bd1d57  jmp 0x000071FF71BD1B34
000071ff71bd1d5c  sub rsp, 0x08
000071ff71bd1d60  push rax
000071ff71bd1d61  push rcx
000071ff71bd1d62  push rdx
000071ff71bd1d63  push rdi
000071ff71bd1d64  push rsi
000071ff71bd1d65  push r8
000071ff71bd1d67  push r9
000071ff71bd1d69  push r10
000071ff71bd1d6b  push r11
000071ff71bd1d6d  sub rsp, 0xF0
000071ff71bd1d74  vmovaps [rsp], xmm0
000071ff71bd1d79  vmovaps [rsp+0x10], xmm2
000071ff71bd1d7f  vmovaps [rsp+0x20], xmm3
000071ff71bd1d85  vmovaps [rsp+0x30], xmm4
000071ff71bd1d8b  vmovaps [rsp+0x40], xmm5
000071ff71bd1d91  vmovaps [rsp+0x50], xmm6
000071ff71bd1d97  vmovaps [rsp+0x60], xmm7
000071ff71bd1d9d  vmovaps [rsp+0x70], xmm8
000071ff71bd1da3  vmovaps [rsp+0x80], xmm9
000071ff71bd1dac  vmovaps [rsp+0x90], xmm10
000071ff71bd1db5  vmovaps [rsp+0xA0], xmm11
000071ff71bd1dbe  vmovaps [rsp+0xB0], xmm12
000071ff71bd1dc7  vmovaps [rsp+0xC0], xmm13
000071ff71bd1dd0  vmovaps [rsp+0xD0], xmm14
000071ff71bd1dd9  vmovaps [rsp+0xE0], xmm15
000071ff71bd1de2  sub rsp, 0x30
000071ff71bd1de6  movaps [rsp], xmm1
000071ff71bd1dea  movaps [rsp+0x10], xmm14
000071ff71bd1df0  movaps [rsp+0x20], xmm15
000071ff71bd1df6  lea rdi, [rsp]
000071ff71bd1dfa  mov esi, 0x00
000071ff71bd1dff  mov rax, 0x5E6872E10530
000071ff71bd1e09  call rax
000071ff71bd1e0b  movaps xmm1, [rsp]
000071ff71bd1e0f  add rsp, 0x30
000071ff71bd1e13  vmovaps xmm0, [rsp]
000071ff71bd1e18  vmovaps xmm2, [rsp+0x10]
000071ff71bd1e1e  vmovaps xmm3, [rsp+0x20]
000071ff71bd1e24  vmovaps xmm4, [rsp+0x30]
000071ff71bd1e2a  vmovaps xmm5, [rsp+0x40]
000071ff71bd1e30  vmovaps xmm6, [rsp+0x50]
000071ff71bd1e36  vmovaps xmm7, [rsp+0x60]
000071ff71bd1e3c  vmovaps xmm8, [rsp+0x70]
000071ff71bd1e42  vmovaps xmm9, [rsp+0x80]
000071ff71bd1e4b  vmovaps xmm10, [rsp+0x90]
000071ff71bd1e54  vmovaps xmm11, [rsp+0xA0]
000071ff71bd1e5d  vmovaps xmm12, [rsp+0xB0]
000071ff71bd1e66  vmovaps xmm13, [rsp+0xC0]
000071ff71bd1e6f  vmovaps xmm14, [rsp+0xD0]
000071ff71bd1e78  vmovaps xmm15, [rsp+0xE0]
000071ff71bd1e81  add rsp, 0xF0
000071ff71bd1e88  pop r11
000071ff71bd1e8a  pop r10
000071ff71bd1e8c  pop r9
000071ff71bd1e8e  pop r8
000071ff71bd1e90  pop rsi
000071ff71bd1e91  pop rdi
000071ff71bd1e92  pop rdx
000071ff71bd1e93  pop rcx
000071ff71bd1e94  pop rax
000071ff71bd1e95  add rsp, 0x08
000071ff71bd1e99  jmp 0x000071FF71BD1B4E
000071ff71bd1e9e  call 0x000071FF719FF540
000071ff71bd1ea3  jmp 0x000071FF71BD1B61
000071ff71bd1ea8  int3
000071ff71bd1ea9  nop [rax], eax
000071ff71bd1eb0  movaps xmm1, [r15+0x180]
000071ff71bd1eb8  vpmovqd xmm15, xmm1
000071ff71bd1ebe  pxor xmm14, xmm14
000071ff71bd1ec3  punpcklqdq xmm15, xmm14
000071ff71bd1ec8  movaps [r15+0x210], xmm15
000071ff71bd1ed0  movq xmm15, qword ptr [r15+0x140]
000071ff71bd1ed9  movq xmm14, qword ptr [r15+0x120]
000071ff71bd1ee2  psubd xmm15, xmm14
000071ff71bd1ee7  movq xmm15, xmm15
000071ff71bd1eec  movaps xmm13, [r15+0x170]
000071ff71bd1ef4  paddq xmm1, xmm13
000071ff71bd1ef9  movaps [r15+0x180], xmm1
000071ff71bd1f01  movq xmm1, qword ptr [r15+0x160]
000071ff71bd1f0a  paddd xmm14, xmm1
000071ff71bd1f0f  movq xmm14, xmm14
000071ff71bd1f14  movq xmm14, xmm14
000071ff71bd1f19  movaps [r15+0x120], xmm14
000071ff71bd1f21  pmovzxdq xmm15, xmm15
000071ff71bd1f27  psllq xmm15, 0x00
000071ff71bd1f2d  movq xmm1, qword ptr [r15+0x210]
000071ff71bd1f36  movq xmm14, qword ptr [r15+0x110]
000071ff71bd1f3f  paddd xmm1, xmm14
000071ff71bd1f44  movq xmm1, xmm1
000071ff71bd1f48  vcvtuqq2pd xmm15, xmm15
000071ff71bd1f4e  pmovzxdq xmm1, xmm1
000071ff71bd1f53  psllq xmm1, 0x00
000071ff71bd1f58  vcvtuqq2pd xmm1, xmm1
000071ff71bd1f5e  movaps xmm14, [r15+0x150]
000071ff71bd1f66  movaps xmm13, xmm15
000071ff71bd1f6a  mulpd xmm13, xmm14
000071ff71bd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000071ff71bd1f75  ptest xmm12, xmm12
000071ff71bd1f7b  jnz 0x000071FF71BD205E
000071ff71bd1f81  movaps [r15+0x220], xmm13
000071ff71bd1f89  mov rax, [r15+0x48]
000071ff71bd1f8d  mov r14, [r15+0x50]
000071ff71bd1f91  lea r12, [r14+rax*1]
000071ff71bd1f95  movups [r13+r12*1], xmm13
000071ff71bd1f9b  movaps xmm15, [r15+0x130]
000071ff71bd1fa3  movaps xmm14, xmm1
000071ff71bd1fa7  mulpd xmm14, xmm15
000071ff71bd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000071ff71bd1fb2  ptest xmm13, xmm13
000071ff71bd1fb8  jnz 0x000071FF71BD21AC
000071ff71bd1fbe  movaps [r15+0x210], xmm14
000071ff71bd1fc6  mov r14, [r15+0x40]
000071ff71bd1fca  lea r12, [r14+rax*1]
000071ff71bd1fce  movups [r13+r12*1], xmm14
000071ff71bd1fd4  lea r14, [rax+0x10]
000071ff71bd1fd8  mov [r15+0x48], r14
000071ff71bd1fdc  xor eax, eax
000071ff71bd1fde  mov r12d, 0x200
000071ff71bd1fe4  cmp r14, r12
000071ff71bd1fe7  cmc
000071ff71bd1fe8  lahf
000071ff71bd1fe9  seto al
000071ff71bd1fec  mov [r15+0x108], eax
000071ff71bd1ff3  mov eax, [r15+0x108]
000071ff71bd1ffa  sahf
000071ff71bd1ffb  jnz 0x000071FF71BD202D
000071ff71bd1ffd  cmp dword ptr [r15+0x318], 0x00
000071ff71bd2005  jz 0x000071FF71BD2300
000071ff71bd200b  nop [rax+rax*1], ax
000071ff71bd2014  nop [rax+rax*1], eax
000071ff71bd201c  mov eax, 0x410490
000071ff71bd2021  mov [r15+0x100], rax
000071ff71bd2028  jmp 0x000071FF719FE110
000071ff71bd202d  cmp dword ptr [r15+0x318], 0x00
000071ff71bd2035  jz 0x000071FF71BD1EB0
000071ff71bd203b  nop [rax+rax*1], ax
000071ff71bd2044  nop [rax+rax*1], eax
000071ff71bd204c  mov eax, 0x410450
000071ff71bd2051  mov [r15+0x100], rax
000071ff71bd2058  jmp 0x000071FF719FE110
000071ff71bd205d  int3
000071ff71bd205e  sub rsp, 0x08
000071ff71bd2062  push rax
000071ff71bd2063  push rcx
000071ff71bd2064  push rdx
000071ff71bd2065  push rdi
000071ff71bd2066  push rsi
000071ff71bd2067  push r8
000071ff71bd2069  push r9
000071ff71bd206b  push r10
000071ff71bd206d  push r11
000071ff71bd206f  sub rsp, 0xF0
000071ff71bd2076  vmovaps [rsp], xmm0
000071ff71bd207b  vmovaps [rsp+0x10], xmm1
000071ff71bd2081  vmovaps [rsp+0x20], xmm2
000071ff71bd2087  vmovaps [rsp+0x30], xmm3
000071ff71bd208d  vmovaps [rsp+0x40], xmm4
000071ff71bd2093  vmovaps [rsp+0x50], xmm5
000071ff71bd2099  vmovaps [rsp+0x60], xmm6
000071ff71bd209f  vmovaps [rsp+0x70], xmm7
000071ff71bd20a5  vmovaps [rsp+0x80], xmm8
000071ff71bd20ae  vmovaps [rsp+0x90], xmm9
000071ff71bd20b7  vmovaps [rsp+0xA0], xmm10
000071ff71bd20c0  vmovaps [rsp+0xB0], xmm11
000071ff71bd20c9  vmovaps [rsp+0xC0], xmm12
000071ff71bd20d2  vmovaps [rsp+0xD0], xmm14
000071ff71bd20db  vmovaps [rsp+0xE0], xmm15
000071ff71bd20e4  sub rsp, 0x30
000071ff71bd20e8  movaps [rsp], xmm13
000071ff71bd20ed  movaps [rsp+0x10], xmm15
000071ff71bd20f3  movaps [rsp+0x20], xmm14
000071ff71bd20f9  lea rdi, [rsp]
000071ff71bd20fd  mov esi, 0x00
000071ff71bd2102  mov rax, 0x5E6872E10530
000071ff71bd210c  call rax
000071ff71bd210e  movaps xmm13, [rsp]
000071ff71bd2113  add rsp, 0x30
000071ff71bd2117  vmovaps xmm0, [rsp]
000071ff71bd211c  vmovaps xmm1, [rsp+0x10]
000071ff71bd2122  vmovaps xmm2, [rsp+0x20]
000071ff71bd2128  vmovaps xmm3, [rsp+0x30]
000071ff71bd212e  vmovaps xmm4, [rsp+0x40]
000071ff71bd2134  vmovaps xmm5, [rsp+0x50]
000071ff71bd213a  vmovaps xmm6, [rsp+0x60]
000071ff71bd2140  vmovaps xmm7, [rsp+0x70]
000071ff71bd2146  vmovaps xmm8, [rsp+0x80]
000071ff71bd214f  vmovaps xmm9, [rsp+0x90]
000071ff71bd2158  vmovaps xmm10, [rsp+0xA0]
000071ff71bd2161  vmovaps xmm11, [rsp+0xB0]
000071ff71bd216a  vmovaps xmm12, [rsp+0xC0]
000071ff71bd2173  vmovaps xmm14, [rsp+0xD0]
000071ff71bd217c  vmovaps xmm15, [rsp+0xE0]
000071ff71bd2185  add rsp, 0xF0
000071ff71bd218c  pop r11
000071ff71bd218e  pop r10
000071ff71bd2190  pop r9
000071ff71bd2192  pop r8
000071ff71bd2194  pop rsi
000071ff71bd2195  pop rdi
000071ff71bd2196  pop rdx
000071ff71bd2197  pop rcx
000071ff71bd2198  pop rax
000071ff71bd2199  add rsp, 0x08
000071ff71bd219d  jmp 0x000071FF71BD1F81
000071ff71bd21a2  call 0x000071FF71AC2240
000071ff71bd21a7  jmp 0x000071FF71BD1F9B
000071ff71bd21ac  sub rsp, 0x08
000071ff71bd21b0  push rax
000071ff71bd21b1  push rcx
000071ff71bd21b2  push rdx
000071ff71bd21b3  push rdi
000071ff71bd21b4  push rsi
000071ff71bd21b5  push r8
000071ff71bd21b7  push r9
000071ff71bd21b9  push r10
000071ff71bd21bb  push r11
000071ff71bd21bd  sub rsp, 0xF0
000071ff71bd21c4  vmovaps [rsp], xmm0
000071ff71bd21c9  vmovaps [rsp+0x10], xmm1
000071ff71bd21cf  vmovaps [rsp+0x20], xmm2
000071ff71bd21d5  vmovaps [rsp+0x30], xmm3
000071ff71bd21db  vmovaps [rsp+0x40], xmm4
000071ff71bd21e1  vmovaps [rsp+0x50], xmm5
000071ff71bd21e7  vmovaps [rsp+0x60], xmm6
000071ff71bd21ed  vmovaps [rsp+0x70], xmm7
000071ff71bd21f3  vmovaps [rsp+0x80], xmm8
000071ff71bd21fc  vmovaps [rsp+0x90], xmm9
000071ff71bd2205  vmovaps [rsp+0xA0], xmm10
000071ff71bd220e  vmovaps [rsp+0xB0], xmm11
000071ff71bd2217  vmovaps [rsp+0xC0], xmm12
000071ff71bd2220  vmovaps [rsp+0xD0], xmm13
000071ff71bd2229  vmovaps [rsp+0xE0], xmm15
000071ff71bd2232  sub rsp, 0x30
000071ff71bd2236  movaps [rsp], xmm14
000071ff71bd223b  movaps [rsp+0x10], xmm1
000071ff71bd2240  movaps [rsp+0x20], xmm15
000071ff71bd2246  lea rdi, [rsp]
000071ff71bd224a  mov esi, 0x00
000071ff71bd224f  mov rax, 0x5E6872E10530
000071ff71bd2259  call rax
000071ff71bd225b  movaps xmm14, [rsp]
000071ff71bd2260  add rsp, 0x30
000071ff71bd2264  vmovaps xmm0, [rsp]
000071ff71bd2269  vmovaps xmm1, [rsp+0x10]
000071ff71bd226f  vmovaps xmm2, [rsp+0x20]
000071ff71bd2275  vmovaps xmm3, [rsp+0x30]
000071ff71bd227b  vmovaps xmm4, [rsp+0x40]
000071ff71bd2281  vmovaps xmm5, [rsp+0x50]
000071ff71bd2287  vmovaps xmm6, [rsp+0x60]
000071ff71bd228d  vmovaps xmm7, [rsp+0x70]
000071ff71bd2293  vmovaps xmm8, [rsp+0x80]
000071ff71bd229c  vmovaps xmm9, [rsp+0x90]
000071ff71bd22a5  vmovaps xmm10, [rsp+0xA0]
000071ff71bd22ae  vmovaps xmm11, [rsp+0xB0]
000071ff71bd22b7  vmovaps xmm12, [rsp+0xC0]
000071ff71bd22c0  vmovaps xmm13, [rsp+0xD0]
000071ff71bd22c9  vmovaps xmm15, [rsp+0xE0]
000071ff71bd22d2  add rsp, 0xF0
000071ff71bd22d9  pop r11
000071ff71bd22db  pop r10
000071ff71bd22dd  pop r9
000071ff71bd22df  pop r8
000071ff71bd22e1  pop rsi
000071ff71bd22e2  pop rdi
000071ff71bd22e3  pop rdx
000071ff71bd22e4  pop rcx
000071ff71bd22e5  pop rax
000071ff71bd22e6  add rsp, 0x08
000071ff71bd22ea  jmp 0x000071FF71BD1FBE
000071ff71bd22ef  call 0x000071FF71AC34C0
000071ff71bd22f4  jmp 0x000071FF71BD1FD4
000071ff71bd22f9  int3
000071ff71bd22fa  nop [rax+rax*1], ax
000071ff71bd2300  mov rax, [r15+0x50]
000071ff71bd2304  lea r14, [rax+0x80]
000071ff71bd230b  movups xmm1, [r13+r14*1]
000071ff71bd2311  lea r14, [rax+0x90]
000071ff71bd2318  movups xmm15, [r13+r14*1]
000071ff71bd231e  vxorps xmm14, xmm14, xmm14
000071ff71bd2323  vpbroadcastq xmm14, xmm14
000071ff71bd2328  lea r14, [rax+0x40]
000071ff71bd232c  movups xmm13, [r13+r14*1]
000071ff71bd2332  lea r14, [rax+0x50]
000071ff71bd2336  movups xmm12, [r13+r14*1]
000071ff71bd233c  mov qword ptr [r15+0x48], 0x00
000071ff71bd2344  movups xmm11, [r13+rax*1]
000071ff71bd234a  lea r14, [rax+0x10]
000071ff71bd234e  movups xmm10, [r13+r14*1]
000071ff71bd2354  mov r14, [r15+0xF8]
000071ff71bd235b  lea r12, [r14+0xE0]
000071ff71bd2362  movups [r13+r12*1], xmm15
000071ff71bd2368  lea r12, [r14+0xF0]
000071ff71bd236f  movups [r13+r12*1], xmm1
000071ff71bd2375  lea r12, [rax+0xC0]
000071ff71bd237c  movups xmm1, [r13+r12*1]
000071ff71bd2382  lea r12, [rax+0xD0]
000071ff71bd2389  movups xmm15, [r13+r12*1]
000071ff71bd238f  lea r12, [rax+0x140]
000071ff71bd2396  movups xmm9, [r13+r12*1]
000071ff71bd239c  lea r12, [rax+0x150]
000071ff71bd23a3  movups xmm8, [r13+r12*1]
000071ff71bd23a9  lea r12, [rax+0x180]
000071ff71bd23b0  movups xmm7, [r13+r12*1]
000071ff71bd23b6  lea r12, [rax+0x190]
000071ff71bd23bd  movups xmm6, [r13+r12*1]
000071ff71bd23c3  lea r12, [r14+0xC0]
000071ff71bd23ca  movups [r13+r12*1], xmm15
000071ff71bd23d0  lea r12, [r14+0xD0]
000071ff71bd23d7  movups [r13+r12*1], xmm1
000071ff71bd23dd  lea r12, [rax+0x100]
000071ff71bd23e4  movups xmm1, [r13+r12*1]
000071ff71bd23ea  lea r12, [rax+0x110]
000071ff71bd23f1  movups xmm15, [r13+r12*1]
000071ff71bd23f7  lea r12, [rax+0x1C0]
000071ff71bd23fe  movups xmm5, [r13+r12*1]
000071ff71bd2404  lea r12, [rax+0x1D0]
000071ff71bd240b  movups xmm4, [r13+r12*1]
000071ff71bd2411  lea r12, [rax+0x20]
000071ff71bd2415  movups xmm3, [r13+r12*1]
000071ff71bd241b  lea r12, [rax+0x30]
000071ff71bd241f  movups xmm2, [r13+r12*1]
000071ff71bd2425  movaps [r15+0x1F0], xmm2
000071ff71bd242d  lea r12, [r14+0x20]
000071ff71bd2431  movups [r13+r12*1], xmm1
000071ff71bd2437  lea r12, [r14+0x30]
000071ff71bd243b  movups [r13+r12*1], xmm12
000071ff71bd2441  lea r12, [rax+0x60]
000071ff71bd2445  movups xmm1, [r13+r12*1]
000071ff71bd244b  lea r12, [rax+0x70]
000071ff71bd244f  movups xmm12, [r13+r12*1]
000071ff71bd2455  lea r12, [r14+0x60]
000071ff71bd2459  movups [r13+r12*1], xmm11
000071ff71bd245f  lea r12, [r14+0x70]
000071ff71bd2463  movups [r13+r12*1], xmm5
000071ff71bd2469  lea r12, [rax+0xE0]
000071ff71bd2470  movups xmm11, [r13+r12*1]
000071ff71bd2476  lea r12, [rax+0xF0]
000071ff71bd247d  movups xmm5, [r13+r12*1]
000071ff71bd2483  lea r12, [rax+0x120]
000071ff71bd248a  vmovaps [rsp+0x10], xmm1
000071ff71bd2490  movups xmm1, [r13+r12*1]
000071ff71bd2496  lea r12, [rax+0x130]
000071ff71bd249d  vmovaps [rsp+0x20], xmm1
000071ff71bd24a3  movups xmm1, [r13+r12*1]
000071ff71bd24a9  lea r12, [r14+0xA0]
000071ff71bd24b0  movups [r13+r12*1], xmm12
000071ff71bd24b6  lea r12, [r14+0xB0]
000071ff71bd24bd  vmovaps xmm12, [rsp+0x10]
000071ff71bd24c3  movups [r13+r12*1], xmm12
000071ff71bd24c9  lea r12, [rax+0xA0]
000071ff71bd24d0  movups xmm12, [r13+r12*1]
000071ff71bd24d6  lea r12, [rax+0xB0]
000071ff71bd24dd  vmovaps [rsp+0x10], xmm1
000071ff71bd24e3  movups xmm1, [r13+r12*1]
000071ff71bd24e9  lea r12, [rax+0x160]
000071ff71bd24f0  vmovaps [rsp+0x30], xmm1
000071ff71bd24f6  movups xmm1, [r13+r12*1]
000071ff71bd24fc  lea r12, [rax+0x170]
000071ff71bd2503  vmovaps [rsp+0x40], xmm1
000071ff71bd2509  movups xmm1, [r13+r12*1]
000071ff71bd250f  movaps [r15+0x2B0], xmm1
000071ff71bd2517  lea r12, [rax+0x1A0]
000071ff71bd251e  vmovaps [rsp+0x50], xmm1
000071ff71bd2524  movups xmm1, [r13+r12*1]
000071ff71bd252a  lea r12, [rax+0x1B0]
000071ff71bd2531  vmovaps [rsp+0x60], xmm1
000071ff71bd2537  movups xmm1, [r13+r12*1]
000071ff71bd253d  vmovaps [rsp+0x70], xmm1
000071ff71bd2543  vmovaps xmm1, [rsp+0x60]
000071ff71bd2549  movaps [r15+0x290], xmm1
000071ff71bd2551  vmovaps [rsp+0x60], xmm1
000071ff71bd2557  vmovaps xmm1, [rsp+0x70]
000071ff71bd255d  movaps [r15+0x1E0], xmm1
000071ff71bd2565  lea r12, [r14+0x80]
000071ff71bd256c  vmovaps [rsp+0x70], xmm1
000071ff71bd2572  vmovaps xmm1, [rsp+0x30]
000071ff71bd2578  movups [r13+r12*1], xmm1
000071ff71bd257e  lea r12, [r14+0x90]
000071ff71bd2585  movups [r13+r12*1], xmm12
000071ff71bd258b  lea r12, [rax+0x1E0]
000071ff71bd2592  movups xmm1, [r13+r12*1]
000071ff71bd2598  lea r12, [rax+0x1F0]
000071ff71bd259f  movups xmm12, [r13+r12*1]
000071ff71bd25a5  mov qword ptr [r15+0x50], 0x432200
000071ff71bd25ad  lea rax, [r14+0x40]
000071ff71bd25b1  vmovaps [rsp+0x30], xmm1
000071ff71bd25b7  vmovaps xmm1, [rsp+0x40]
000071ff71bd25bd  movups [r13+rax*1], xmm1
000071ff71bd25c3  lea rax, [r14+0x50]
000071ff71bd25c7  movups [r13+rax*1], xmm10
000071ff71bd25cd  movups [r13+r14*1], xmm12
000071ff71bd25d3  lea rax, [r14+0x10]
000071ff71bd25d7  vmovaps xmm1, [rsp+0x30]
000071ff71bd25dd  movups [r13+rax*1], xmm1
000071ff71bd25e3  mov rax, [r15+0x40]
000071ff71bd25e7  vmovaps [rsp+0x30], xmm3
000071ff71bd25ed  vmovaps xmm1, [rsp+0x30]
000071ff71bd25f3  por xmm3, xmm1
000071ff71bd25f7  vmovaps [rsp+0x30], xmm6
000071ff71bd25fd  vmovaps xmm12, [rsp+0x30]
000071ff71bd2603  por xmm6, xmm12
000071ff71bd2608  lea r12, [rax+0x30]
000071ff71bd260c  mov r11, [r13+r12*1]
000071ff71bd2611  lea r12, [rax+0x38]
000071ff71bd2615  mov r10, [r13+r12*1]
000071ff71bd261a  movq xmm12, r11
000071ff71bd261f  movq xmm10, r10
000071ff71bd2624  movq xmm12, xmm12
000071ff71bd2629  vmovaps [rsp+0x30], xmm12
000071ff71bd262f  movq xmm12, xmm12
000071ff71bd2634  movaps [r15+0x130], xmm12
000071ff71bd263c  movq xmm10, xmm10
000071ff71bd2641  vmovaps [rsp+0x40], xmm10
000071ff71bd2647  movq xmm10, xmm10
000071ff71bd264c  movaps [r15+0x280], xmm10
000071ff71bd2654  vmovaps [rsp+0x80], xmm9
000071ff71bd265d  vmovaps xmm12, [rsp+0x80]
000071ff71bd2666  por xmm9, xmm12
000071ff71bd266b  lea r12, [rax+0x20]
000071ff71bd266f  mov r11, [r13+r12*1]
000071ff71bd2674  lea r12, [rax+0x28]
000071ff71bd2678  mov r10, [r13+r12*1]
000071ff71bd267d  movq xmm12, r11
000071ff71bd2682  movq xmm10, r10
000071ff71bd2687  movq xmm12, xmm12
000071ff71bd268c  vmovaps [rsp+0x80], xmm12
000071ff71bd2695  movq xmm12, xmm12
000071ff71bd269a  movaps [r15+0x150], xmm12
000071ff71bd26a2  movq xmm10, xmm10
000071ff71bd26a7  vmovaps [rsp+0x90], xmm10
000071ff71bd26b0  movq xmm10, xmm10
000071ff71bd26b5  movaps [r15+0x140], xmm10
000071ff71bd26bd  lea r12, [rax+0x10]
000071ff71bd26c1  mov r11, [r13+r12*1]
000071ff71bd26c6  lea r12, [rax+0x18]
000071ff71bd26ca  mov r10, [r13+r12*1]
000071ff71bd26cf  movq xmm12, r11
000071ff71bd26d4  movq xmm10, r10
000071ff71bd26d9  movq xmm12, xmm12
000071ff71bd26de  vmovaps [rsp+0xA0], xmm12
000071ff71bd26e7  movq xmm12, xmm12
000071ff71bd26ec  movaps [r15+0x170], xmm12
000071ff71bd26f4  movq xmm10, xmm10
000071ff71bd26f9  vmovaps [rsp+0xB0], xmm10
000071ff71bd2702  movq xmm10, xmm10
000071ff71bd2707  movaps [r15+0x160], xmm10
000071ff71bd270f  mov r12, [r13+rax*1]
000071ff71bd2714  vmovq xmm12, r12
000071ff71bd2719  vpbroadcastq xmm12, xmm12
000071ff71bd271e  lea r12, [rax+0x08]
000071ff71bd2722  mov rax, [r13+r12*1]
000071ff71bd2727  movq xmm10, rax
000071ff71bd272c  movaps [r15+0x230], xmm10
000071ff71bd2734  lea rax, [r14+0x50]
000071ff71bd2738  movups xmm10, [r13+rax*1]
000071ff71bd273e  lea rax, [r14+0x60]
000071ff71bd2742  vmovaps [rsp+0xC0], xmm1
000071ff71bd274b  movups xmm1, [r13+rax*1]
000071ff71bd2751  lea rax, [r14+0x30]
000071ff71bd2755  vmovaps [rsp+0xD0], xmm1
000071ff71bd275e  movups xmm1, [r13+rax*1]
000071ff71bd2764  mov qword ptr [r15+0x60], 0x432200
000071ff71bd276c  mov qword ptr [r15+0x58], 0x40
000071ff71bd2774  vmovaps [rsp+0xE0], xmm1
000071ff71bd277d  vmovaps [rsp+0xF0], xmm15
000071ff71bd2786  vmovaps xmm15, [rsp+0xC0]
000071ff71bd278f  vmovaps [rsp+0xC0], xmm14
000071ff71bd2798  movaps xmm1, xmm12
000071ff71bd279c  mulpd xmm1, xmm15
000071ff71bd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000071ff71bd27a6  ptest xmm14, xmm14
000071ff71bd27ac  jnz 0x000071FF71BD3863
000071ff71bd27b2  movq xmm15, qword ptr [r15+0x230]
000071ff71bd27bb  vmovaps [rsp+0x100], xmm15
000071ff71bd27c4  vpermilpd xmm15, xmm15, 0x00
000071ff71bd27ca  vmovaps [rsp+0x110], xmm1
000071ff71bd27d3  vmovaps xmm1, [rsp+0xE0]
000071ff71bd27dc  vmovaps [rsp+0xE0], xmm13
000071ff71bd27e5  movaps xmm14, xmm1
000071ff71bd27e9  mulpd xmm14, xmm15
000071ff71bd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000071ff71bd27f4  ptest xmm13, xmm13
000071ff71bd27fa  jnz 0x000071FF71BD39A5
000071ff71bd2800  vxorps xmm1, xmm1, xmm1
000071ff71bd2804  vpbroadcastq xmm1, xmm1
000071ff71bd2809  vmovaps xmm13, [rsp+0xD0]
000071ff71bd2812  vmovaps [rsp+0xD0], xmm1
000071ff71bd281b  movaps xmm15, xmm12
000071ff71bd281f  mulpd xmm15, xmm13
000071ff71bd2824  vcmppd xmm1, xmm15, xmm15, 0x03
000071ff71bd282a  ptest xmm1, xmm1
000071ff71bd282f  jnz 0x000071FF71BD3AE8
000071ff71bd2835  movaps xmm1, xmm12
000071ff71bd2839  mulpd xmm1, xmm10
000071ff71bd283e  vcmppd xmm13, xmm1, xmm1, 0x03
000071ff71bd2843  ptest xmm13, xmm13
000071ff71bd2849  jnz 0x000071FF71BD3C2C
000071ff71bd284f  movaps xmm13, xmm12
000071ff71bd2853  mulpd xmm13, xmm2
000071ff71bd2858  vcmppd xmm10, xmm13, xmm13, 0x03
000071ff71bd285e  ptest xmm10, xmm10
000071ff71bd2864  jnz 0x000071FF71BD3D6E
000071ff71bd286a  vmovaps [rsp+0x120], xmm7
000071ff71bd2873  vmovaps xmm12, [rsp+0x120]
000071ff71bd287c  por xmm7, xmm12
000071ff71bd2881  vmovaps xmm12, [rsp+0xE0]
000071ff71bd288a  vmovaps xmm10, [rsp+0xE0]
000071ff71bd2893  por xmm12, xmm10
000071ff71bd2898  vmovaps xmm2, [rsp+0x100]
000071ff71bd28a1  vpermilpd xmm2, xmm2, 0x00
000071ff71bd28a7  vmovaps [rsp+0xE0], xmm1
000071ff71bd28b0  vmovaps [rsp+0x120], xmm15
000071ff71bd28b9  movaps xmm1, xmm10
000071ff71bd28bd  mulpd xmm1, xmm2
000071ff71bd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000071ff71bd28c6  ptest xmm15, xmm15
000071ff71bd28cc  jnz 0x000071FF71BD3EB1
000071ff71bd28d2  xor eax, eax
000071ff71bd28d4  mov r12d, 0x40
000071ff71bd28da  mov r11d, 0x200
000071ff71bd28e0  cmp r12, r11
000071ff71bd28e3  cmc
000071ff71bd28e4  lahf
000071ff71bd28e5  seto al
000071ff71bd28e8  mov [r15+0x108], eax
000071ff71bd28ef  vmovaps xmm10, [rsp+0x110]
000071ff71bd28f8  vmovaps xmm2, [rsp+0xD0]
000071ff71bd2901  vmovaps [rsp+0xD0], xmm1
000071ff71bd290a  movaps xmm15, xmm10
000071ff71bd290e  addpd xmm15, xmm2
000071ff71bd2913  vcmppd xmm1, xmm15, xmm15, 0x03
000071ff71bd2919  ptest xmm1, xmm1
000071ff71bd291e  jnz 0x000071FF71BD3FF2
000071ff71bd2924  vmovaps xmm10, [rsp+0x120]
000071ff71bd292d  vmovaps [rsp+0x110], xmm15
000071ff71bd2936  vmovaps xmm15, [rsp+0xC0]
000071ff71bd293f  vmovaps [rsp+0xC0], xmm14
000071ff71bd2948  movaps xmm1, xmm10
000071ff71bd294c  addpd xmm1, xmm15
000071ff71bd2951  vcmppd xmm14, xmm1, xmm1, 0x03
000071ff71bd2956  ptest xmm14, xmm14
000071ff71bd295c  jnz 0x000071FF71BD4135
000071ff71bd2962  vmovaps xmm10, [rsp+0xE0]
000071ff71bd296b  vmovaps [rsp+0xE0], xmm1
000071ff71bd2974  movaps xmm14, xmm10
000071ff71bd2978  addpd xmm14, xmm15
000071ff71bd297d  vcmppd xmm1, xmm14, xmm14, 0x03
000071ff71bd2983  ptest xmm1, xmm1
000071ff71bd2988  jnz 0x000071FF71BD4277
000071ff71bd298e  vmovaps xmm1, [rsp+0x10]
000071ff71bd2994  vmovaps xmm15, [rsp+0x10]
000071ff71bd299a  por xmm1, xmm15
000071ff71bd299f  vmovaps xmm15, [rsp+0x20]
000071ff71bd29a5  vmovaps xmm10, [rsp+0x20]
000071ff71bd29ab  por xmm15, xmm10
000071ff71bd29b0  vmovaps [rsp+0x10], xmm5
000071ff71bd29b6  vmovaps xmm10, [rsp+0x10]
000071ff71bd29bc  por xmm5, xmm10
000071ff71bd29c1  vmovaps [rsp+0x10], xmm11
000071ff71bd29c7  vmovaps xmm10, [rsp+0x10]
000071ff71bd29cd  por xmm11, xmm10
000071ff71bd29d2  vmovaps [rsp+0x10], xmm4
000071ff71bd29d8  vmovaps xmm10, [rsp+0x10]
000071ff71bd29de  por xmm4, xmm10
000071ff71bd29e3  vmovaps [rsp+0x10], xmm8
000071ff71bd29e9  vmovaps xmm10, [rsp+0x10]
000071ff71bd29ef  por xmm8, xmm10
000071ff71bd29f4  vmovaps xmm10, [rsp+0xF0]
000071ff71bd29fd  vmovaps [rsp+0x10], xmm1
000071ff71bd2a03  vmovaps xmm1, [rsp+0xF0]
000071ff71bd2a0c  por xmm10, xmm1
000071ff71bd2a11  lea rax, [r14+0xA0]
000071ff71bd2a18  movups xmm1, [r13+rax*1]
000071ff71bd2a1e  lea rax, [r14+0xB0]
000071ff71bd2a25  vmovaps [rsp+0x20], xmm1
000071ff71bd2a2b  movups xmm1, [r13+rax*1]
000071ff71bd2a31  vmovaps [rsp+0xF0], xmm1
000071ff71bd2a3a  vmovaps [rsp+0x120], xmm15
000071ff71bd2a43  movaps xmm1, xmm13
000071ff71bd2a47  addpd xmm1, xmm2
000071ff71bd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000071ff71bd2a50  ptest xmm15, xmm15
000071ff71bd2a56  jnz 0x000071FF71BD43CF
000071ff71bd2a5c  lea rax, [r14+0xF0]
000071ff71bd2a63  movups xmm15, [r13+rax*1]
000071ff71bd2a69  vmovaps xmm2, [rsp+0xE0]
000071ff71bd2a72  vmovaps [rsp+0xE0], xmm1
000071ff71bd2a7b  vmovaps xmm1, [rsp+0xD0]
000071ff71bd2a84  vmovaps [rsp+0xD0], xmm15
000071ff71bd2a8d  movaps xmm13, xmm2
000071ff71bd2a91  addpd xmm13, xmm1
000071ff71bd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000071ff71bd2a9c  ptest xmm15, xmm15
000071ff71bd2aa2  jnz 0x000071FF71BD451A
000071ff71bd2aa8  vmovaps xmm15, [rsp+0xC0]
000071ff71bd2ab1  movaps xmm1, xmm14
000071ff71bd2ab5  addpd xmm1, xmm15
000071ff71bd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000071ff71bd2abf  ptest xmm2, xmm2
000071ff71bd2ac4  jnz 0x000071FF71BD465C
000071ff71bd2aca  vmovaps xmm15, [rsp+0x100]
000071ff71bd2ad3  vpermilpd xmm15, xmm15, 0x00
000071ff71bd2ad9  vmovaps xmm2, [rsp+0xF0]
000071ff71bd2ae2  vmovaps [rsp+0xC0], xmm1
000071ff71bd2aeb  movaps xmm14, xmm2
000071ff71bd2aef  mulpd xmm14, xmm15
000071ff71bd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000071ff71bd2afa  ptest xmm1, xmm1
000071ff71bd2aff  jnz 0x000071FF71BD479E
000071ff71bd2b05  vmovaps xmm1, [rsp+0xA0]
000071ff71bd2b0e  vpermilpd xmm1, xmm1, 0x00
000071ff71bd2b14  vmovaps xmm2, [rsp+0xD0]
000071ff71bd2b1d  vmovaps [rsp+0xD0], xmm14
000071ff71bd2b26  movaps xmm15, xmm2
000071ff71bd2b2a  mulpd xmm15, xmm1
000071ff71bd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000071ff71bd2b35  ptest xmm14, xmm14
000071ff71bd2b3b  jnz 0x000071FF71BD48E1
000071ff71bd2b41  lea rax, [r14+0xE0]
000071ff71bd2b48  movups xmm1, [r13+rax*1]
000071ff71bd2b4e  vmovaps xmm14, [rsp+0x100]
000071ff71bd2b57  vpermilpd xmm14, xmm14, 0x00
000071ff71bd2b5d  vmovaps [rsp+0xF0], xmm1
000071ff71bd2b66  vmovaps xmm1, [rsp+0x20]
000071ff71bd2b6c  vmovaps [rsp+0x20], xmm15
000071ff71bd2b72  movaps xmm2, xmm1
000071ff71bd2b75  mulpd xmm2, xmm14
000071ff71bd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000071ff71bd2b7f  ptest xmm15, xmm15
000071ff71bd2b85  jnz 0x000071FF71BD4A2D
000071ff71bd2b8b  vmovaps [rsp+0x100], xmm10
000071ff71bd2b94  vmovaps xmm1, [rsp+0x100]
000071ff71bd2b9d  por xmm10, xmm1
000071ff71bd2ba2  movaps [r15+0x300], xmm10
000071ff71bd2baa  vmovaps [rsp+0x100], xmm8
000071ff71bd2bb3  vmovaps xmm1, [rsp+0x100]
000071ff71bd2bbc  por xmm8, xmm1
000071ff71bd2bc1  movaps [r15+0x190], xmm8
000071ff71bd2bc9  vmovaps xmm1, [rsp+0xA0]
000071ff71bd2bd2  vpermilpd xmm1, xmm1, 0x00
000071ff71bd2bd8  vmovaps xmm14, [rsp+0xF0]
000071ff71bd2be1  vmovaps [rsp+0xF0], xmm13
000071ff71bd2bea  movaps xmm15, xmm14
000071ff71bd2bee  mulpd xmm15, xmm1
000071ff71bd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000071ff71bd2bf9  ptest xmm13, xmm13
000071ff71bd2bff  jnz 0x000071FF71BD4B6E
000071ff71bd2c05  lea rax, [r14+0x90]
000071ff71bd2c0c  movups xmm1, [r13+rax*1]
000071ff71bd2c12  vmovaps [rsp+0x100], xmm4
000071ff71bd2c1b  vmovaps xmm14, [rsp+0x100]
000071ff71bd2c24  por xmm4, xmm14
000071ff71bd2c29  movaps [r15+0x1C0], xmm4
000071ff71bd2c31  vmovaps [rsp+0x100], xmm11
000071ff71bd2c3a  vmovaps xmm14, [rsp+0x100]
000071ff71bd2c43  por xmm11, xmm14
000071ff71bd2c48  movaps [r15+0x200], xmm11
000071ff71bd2c50  vmovaps [rsp+0x100], xmm5
000071ff71bd2c59  vmovaps xmm14, [rsp+0x100]
000071ff71bd2c62  por xmm5, xmm14
000071ff71bd2c67  movaps [r15+0x2D0], xmm5
000071ff71bd2c6f  vmovaps xmm14, [rsp+0x120]
000071ff71bd2c78  vmovaps xmm13, [rsp+0x120]
000071ff71bd2c81  por xmm14, xmm13
000071ff71bd2c86  movaps [r15+0x2E0], xmm14
000071ff71bd2c8e  vmovaps [rsp+0x100], xmm1
000071ff71bd2c97  vmovaps xmm1, [rsp+0x110]
000071ff71bd2ca0  vmovaps [rsp+0x110], xmm15
000071ff71bd2ca9  vmovaps xmm15, [rsp+0xD0]
000071ff71bd2cb2  vmovaps [rsp+0xD0], xmm14
000071ff71bd2cbb  movaps xmm13, xmm1
000071ff71bd2cbf  addpd xmm13, xmm15
000071ff71bd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000071ff71bd2cca  ptest xmm14, xmm14
000071ff71bd2cd0  jnz 0x000071FF71BD4CBB
000071ff71bd2cd6  vmovaps xmm1, [rsp+0xA0]
000071ff71bd2cdf  vpermilpd xmm1, xmm1, 0x00
000071ff71bd2ce5  vmovaps xmm14, [rsp+0x100]
000071ff71bd2cee  vmovaps [rsp+0x100], xmm13
000071ff71bd2cf7  movaps xmm15, xmm14
000071ff71bd2cfb  mulpd xmm15, xmm1
000071ff71bd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000071ff71bd2d06  ptest xmm13, xmm13
000071ff71bd2d0c  jnz 0x000071FF71BD4DFE
000071ff71bd2d12  lea rax, [r14+0x80]
000071ff71bd2d19  movups xmm1, [r13+rax*1]
000071ff71bd2d1f  vmovaps xmm13, [rsp+0xE0]
000071ff71bd2d28  vmovaps [rsp+0xE0], xmm1
000071ff71bd2d31  movaps xmm14, xmm13
000071ff71bd2d35  addpd xmm14, xmm2
000071ff71bd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000071ff71bd2d40  ptest xmm1, xmm1
000071ff71bd2d45  jnz 0x000071FF71BD4F4B
000071ff71bd2d4b  vmovaps xmm13, [rsp+0xF0]
000071ff71bd2d54  vmovaps xmm2, [rsp+0x20]
000071ff71bd2d5a  vmovaps [rsp+0x20], xmm15
000071ff71bd2d60  movaps xmm1, xmm13
000071ff71bd2d64  addpd xmm1, xmm2
000071ff71bd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000071ff71bd2d6d  ptest xmm15, xmm15
000071ff71bd2d73  jnz 0x000071FF71BD508E
000071ff71bd2d79  vmovaps xmm15, [rsp+0x10]
000071ff71bd2d7f  vmovaps xmm13, [rsp+0x10]
000071ff71bd2d85  por xmm15, xmm13
000071ff71bd2d8a  movaps [r15+0x2F0], xmm15
000071ff71bd2d92  vmovaps xmm13, [rsp+0xA0]
000071ff71bd2d9b  vpermilpd xmm13, xmm13, 0x00
000071ff71bd2da1  vmovaps [rsp+0x10], xmm1
000071ff71bd2da7  vmovaps xmm1, [rsp+0xE0]
000071ff71bd2db0  vmovaps [rsp+0xA0], xmm15
000071ff71bd2db9  movaps xmm2, xmm1
000071ff71bd2dbc  mulpd xmm2, xmm13
000071ff71bd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000071ff71bd2dc6  ptest xmm15, xmm15
000071ff71bd2dcc  jnz 0x000071FF71BD51CF
000071ff71bd2dd2  lea rax, [r14+0xD0]
000071ff71bd2dd9  movups xmm1, [r13+rax*1]
000071ff71bd2ddf  vmovaps xmm13, [rsp+0xC0]
000071ff71bd2de8  vmovaps [rsp+0xC0], xmm1
000071ff71bd2df1  vmovaps xmm1, [rsp+0x110]
000071ff71bd2dfa  vmovaps [rsp+0xE0], xmm14
000071ff71bd2e03  movaps xmm15, xmm13
000071ff71bd2e07  addpd xmm15, xmm1
000071ff71bd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000071ff71bd2e12  ptest xmm14, xmm14
000071ff71bd2e18  jnz 0x000071FF71BD531A
000071ff71bd2e1e  vmovaps xmm1, [rsp+0xB0]
000071ff71bd2e27  vpermilpd xmm1, xmm1, 0x00
000071ff71bd2e2d  movaps xmm14, xmm11
000071ff71bd2e31  mulpd xmm14, xmm1
000071ff71bd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000071ff71bd2e3c  ptest xmm13, xmm13
000071ff71bd2e42  jnz 0x000071FF71BD545D
000071ff71bd2e48  movaps [r15+0x260], xmm14
000071ff71bd2e50  vxorps xmm1, xmm1, xmm1
000071ff71bd2e54  vpbroadcastq xmm1, xmm1
000071ff71bd2e59  movaps [r15+0x1B0], xmm1
000071ff71bd2e61  vmovaps xmm1, [rsp+0xB0]
000071ff71bd2e6a  vpermilpd xmm1, xmm1, 0x00
000071ff71bd2e70  vmovaps xmm11, [rsp+0xC0]
000071ff71bd2e79  vmovaps [rsp+0xC0], xmm15
000071ff71bd2e82  movaps xmm13, xmm11
000071ff71bd2e86  mulpd xmm13, xmm1
000071ff71bd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000071ff71bd2e91  ptest xmm15, xmm15
000071ff71bd2e97  jnz 0x000071FF71BD55A0
000071ff71bd2e9d  lea rax, [r14+0xC0]
000071ff71bd2ea4  movups xmm1, [r13+rax*1]
000071ff71bd2eaa  vmovaps xmm11, [rsp+0x100]
000071ff71bd2eb3  vmovaps [rsp+0xF0], xmm1
000071ff71bd2ebc  vmovaps xmm1, [rsp+0x20]
000071ff71bd2ec2  vmovaps [rsp+0x20], xmm14
000071ff71bd2ec8  movaps xmm15, xmm11
000071ff71bd2ecc  addpd xmm15, xmm1
000071ff71bd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000071ff71bd2ed7  ptest xmm14, xmm14
000071ff71bd2edd  jnz 0x000071FF71BD56ED
000071ff71bd2ee3  vmovaps [rsp+0x100], xmm9
000071ff71bd2eec  vmovaps xmm1, [rsp+0x100]
000071ff71bd2ef5  por xmm9, xmm1
000071ff71bd2efa  movaps [r15+0x270], xmm9
000071ff71bd2f02  vmovaps [rsp+0x100], xmm6
000071ff71bd2f0b  vmovaps xmm1, [rsp+0x100]
000071ff71bd2f14  por xmm6, xmm1
000071ff71bd2f18  movaps [r15+0x1A0], xmm6
000071ff71bd2f20  vmovaps xmm14, [rsp+0xB0]
000071ff71bd2f29  vpermilpd xmm14, xmm14, 0x00
000071ff71bd2f2f  vmovaps xmm6, [rsp+0xF0]
000071ff71bd2f38  vmovaps [rsp+0xF0], xmm1
000071ff71bd2f41  movaps xmm11, xmm6
000071ff71bd2f45  mulpd xmm11, xmm14
000071ff71bd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000071ff71bd2f50  ptest xmm1, xmm1
000071ff71bd2f55  jnz 0x000071FF71BD5830
000071ff71bd2f5b  lea rax, [r14+0x20]
000071ff71bd2f5f  movups xmm1, [r13+rax*1]
000071ff71bd2f65  movaps [r15+0x110], xmm1
000071ff71bd2f6d  vmovaps xmm6, [rsp+0xE0]
000071ff71bd2f76  vmovaps [rsp+0xE0], xmm1
000071ff71bd2f7f  movaps xmm14, xmm6
000071ff71bd2f83  addpd xmm14, xmm2
000071ff71bd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000071ff71bd2f8e  ptest xmm1, xmm1
000071ff71bd2f93  jnz 0x000071FF71BD597D
000071ff71bd2f99  vmovaps xmm1, [rsp+0xB0]
000071ff71bd2fa2  vpermilpd xmm1, xmm1, 0x00
000071ff71bd2fa8  movaps xmm6, xmm5
000071ff71bd2fab  mulpd xmm6, xmm1
000071ff71bd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000071ff71bd2fb4  ptest xmm2, xmm2
000071ff71bd2fb9  jnz 0x000071FF71BD5ABF
000071ff71bd2fbf  vmovaps xmm5, [rsp+0x10]
000071ff71bd2fc5  movaps xmm1, xmm5
000071ff71bd2fc8  addpd xmm1, xmm13
000071ff71bd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000071ff71bd2fd2  ptest xmm2, xmm2
000071ff71bd2fd7  jnz 0x000071FF71BD5BFF
000071ff71bd2fdd  vmovaps xmm13, [rsp+0x80]
000071ff71bd2fe6  vpermilpd xmm13, xmm13, 0x00
000071ff71bd2fec  vmovaps xmm2, [rsp+0xE0]
000071ff71bd2ff5  vmovaps [rsp+0x10], xmm1
000071ff71bd2ffb  movaps xmm5, xmm2
000071ff71bd2ffe  mulpd xmm5, xmm13
000071ff71bd3003  vcmppd xmm1, xmm5, xmm5, 0x03
000071ff71bd3008  ptest xmm1, xmm1
000071ff71bd300d  jnz 0x000071FF71BD5D40
000071ff71bd3013  vmovaps xmm1, [rsp+0x80]
000071ff71bd301c  vpermilpd xmm1, xmm1, 0x00
000071ff71bd3022  movaps xmm13, xmm10
000071ff71bd3026  mulpd xmm13, xmm1
000071ff71bd302b  vcmppd xmm2, xmm13, xmm13, 0x03
000071ff71bd3031  ptest xmm2, xmm2
000071ff71bd3036  jnz 0x000071FF71BD5E81
000071ff71bd303c  vmovaps xmm10, [rsp+0x20]
000071ff71bd3042  movaps xmm1, xmm15
000071ff71bd3046  addpd xmm1, xmm10
000071ff71bd304b  vcmppd xmm2, xmm1, xmm1, 0x03
000071ff71bd3050  ptest xmm2, xmm2
000071ff71bd3055  jnz 0x000071FF71BD5FC4
000071ff71bd305b  vmovaps xmm10, [rsp+0xC0]
000071ff71bd3064  movaps xmm15, xmm10
000071ff71bd3068  addpd xmm15, xmm11
000071ff71bd306d  vcmppd xmm2, xmm15, xmm15, 0x03
000071ff71bd3073  ptest xmm2, xmm2
000071ff71bd3078  jnz 0x000071FF71BD6106
000071ff71bd307e  vmovaps xmm11, [rsp+0x80]
000071ff71bd3087  vpermilpd xmm11, xmm11, 0x00
000071ff71bd308d  vmovaps xmm2, [rsp+0xD0]
000071ff71bd3096  vmovaps [rsp+0x20], xmm1
000071ff71bd309c  movaps xmm10, xmm2
000071ff71bd30a0  mulpd xmm10, xmm11
000071ff71bd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000071ff71bd30ab  ptest xmm1, xmm1
000071ff71bd30b0  jnz 0x000071FF71BD624A
000071ff71bd30b6  vmovaps xmm1, [rsp+0x80]
000071ff71bd30bf  vpermilpd xmm1, xmm1, 0x00
000071ff71bd30c5  vmovaps xmm2, [rsp+0xA0]
000071ff71bd30ce  vmovaps [rsp+0x80], xmm15
000071ff71bd30d7  movaps xmm11, xmm2
000071ff71bd30db  mulpd xmm11, xmm1
000071ff71bd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000071ff71bd30e6  ptest xmm15, xmm15
000071ff71bd30ec  jnz 0x000071FF71BD638D
000071ff71bd30f2  movaps xmm1, xmm14
000071ff71bd30f6  addpd xmm1, xmm6
000071ff71bd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000071ff71bd30ff  ptest xmm15, xmm15
000071ff71bd3105  jnz 0x000071FF71BD64CF
000071ff71bd310b  vmovaps xmm14, [rsp+0x10]
000071ff71bd3111  movaps xmm15, xmm14
000071ff71bd3115  addpd xmm15, xmm5
000071ff71bd311a  vcmppd xmm6, xmm15, xmm15, 0x03
000071ff71bd3120  ptest xmm6, xmm6
000071ff71bd3125  jnz 0x000071FF71BD6610
000071ff71bd312b  vmovaps xmm14, [rsp+0x90]
000071ff71bd3134  vpermilpd xmm14, xmm14, 0x00
000071ff71bd313a  movaps xmm6, xmm9
000071ff71bd313e  mulpd xmm6, xmm14
000071ff71bd3143  vcmppd xmm5, xmm6, xmm6, 0x03
000071ff71bd3148  ptest xmm5, xmm5
000071ff71bd314d  jnz 0x000071FF71BD6753
000071ff71bd3153  vmovaps xmm9, [rsp+0x80]
000071ff71bd315c  movaps xmm14, xmm9
000071ff71bd3160  addpd xmm14, xmm13
000071ff71bd3165  vcmppd xmm5, xmm14, xmm14, 0x03
000071ff71bd316b  ptest xmm5, xmm5
000071ff71bd3170  jnz 0x000071FF71BD6895
000071ff71bd3176  vmovaps xmm9, [rsp+0x20]
000071ff71bd317c  movaps xmm13, xmm9
000071ff71bd3180  addpd xmm13, xmm10
000071ff71bd3185  vcmppd xmm5, xmm13, xmm13, 0x03
000071ff71bd318b  ptest xmm5, xmm5
000071ff71bd3190  jnz 0x000071FF71BD69D9
000071ff71bd3196  vmovaps [rsp+0x10], xmm12
000071ff71bd319c  vmovaps xmm10, [rsp+0x10]
000071ff71bd31a2  por xmm12, xmm10
000071ff71bd31a7  movaps [r15+0x250], xmm12
000071ff71bd31af  vmovaps [rsp+0x10], xmm7
000071ff71bd31b5  vmovaps xmm12, [rsp+0x10]
000071ff71bd31bb  por xmm7, xmm12
000071ff71bd31c0  movaps [r15+0x2A0], xmm7
000071ff71bd31c8  vmovaps [rsp+0x10], xmm3
000071ff71bd31ce  vmovaps xmm12, [rsp+0x10]
000071ff71bd31d4  por xmm3, xmm12
000071ff71bd31d9  movaps [r15+0x1D0], xmm3
000071ff71bd31e1  lea rax, [r14+0x40]
000071ff71bd31e5  movups xmm12, [r13+rax*1]
000071ff71bd31eb  movaps [r15+0x2C0], xmm12
000071ff71bd31f3  vmovaps xmm10, [rsp+0x90]
000071ff71bd31fc  vpermilpd xmm10, xmm10, 0x00
000071ff71bd3202  movaps xmm9, xmm8
000071ff71bd3206  mulpd xmm9, xmm10
000071ff71bd320b  vcmppd xmm5, xmm9, xmm9, 0x03
000071ff71bd3211  ptest xmm5, xmm5
000071ff71bd3216  jnz 0x000071FF71BD6B27
000071ff71bd321c  movaps xmm10, xmm1
000071ff71bd3220  addpd xmm10, xmm11
000071ff71bd3225  vcmppd xmm8, xmm10, xmm10, 0x03
000071ff71bd322b  ptest xmm8, xmm8
000071ff71bd3231  jnz 0x000071FF71BD6C6B
000071ff71bd3237  movaps xmm1, xmm15
000071ff71bd323b  addpd xmm1, xmm6
000071ff71bd323f  vcmppd xmm11, xmm1, xmm1, 0x03
000071ff71bd3244  ptest xmm11, xmm11
000071ff71bd324a  jnz 0x000071FF71BD6DAE
000071ff71bd3250  vmovaps xmm15, [rsp+0x90]
000071ff71bd3259  vpermilpd xmm15, xmm15, 0x00
000071ff71bd325f  movaps xmm11, xmm12
000071ff71bd3263  mulpd xmm11, xmm15
000071ff71bd3268  vcmppd xmm8, xmm11, xmm11, 0x03
000071ff71bd326e  ptest xmm8, xmm8
000071ff71bd3274  jnz 0x000071FF71BD6EEF
000071ff71bd327a  vmovaps xmm15, [rsp+0x90]
000071ff71bd3283  vpermilpd xmm15, xmm15, 0x00
000071ff71bd3289  vmovaps xmm8, [rsp+0x50]
000071ff71bd328f  movaps xmm12, xmm8
000071ff71bd3293  mulpd xmm12, xmm15
000071ff71bd3298  vcmppd xmm6, xmm12, xmm12, 0x03
000071ff71bd329e  ptest xmm6, xmm6
000071ff71bd32a3  jnz 0x000071FF71BD7033
000071ff71bd32a9  vmovaps xmm15, [rsp+0x30]
000071ff71bd32af  vpermilpd xmm15, xmm15, 0x00
000071ff71bd32b5  movaps xmm8, xmm7
000071ff71bd32b9  mulpd xmm8, xmm15
000071ff71bd32be  vcmppd xmm6, xmm8, xmm8, 0x03
000071ff71bd32c4  ptest xmm6, xmm6
000071ff71bd32c9  jnz 0x000071FF71BD7177
000071ff71bd32cf  movaps xmm15, xmm14
000071ff71bd32d3  addpd xmm15, xmm9
000071ff71bd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000071ff71bd32de  ptest xmm7, xmm7
000071ff71bd32e3  jnz 0x000071FF71BD72BA
000071ff71bd32e9  vmovaps xmm14, [rsp+0x30]
000071ff71bd32ef  vpermilpd xmm14, xmm14, 0x00
000071ff71bd32f5  vmovaps xmm7, [rsp+0xF0]
000071ff71bd32fe  movaps xmm9, xmm7
000071ff71bd3302  mulpd xmm9, xmm14
000071ff71bd3307  vcmppd xmm6, xmm9, xmm9, 0x03
000071ff71bd330d  ptest xmm6, xmm6
000071ff71bd3312  jnz 0x000071FF71BD73FE
000071ff71bd3318  movaps xmm14, xmm13
000071ff71bd331c  addpd xmm14, xmm11
000071ff71bd3321  vcmppd xmm7, xmm14, xmm14, 0x03
000071ff71bd3327  ptest xmm7, xmm7
000071ff71bd332c  jnz 0x000071FF71BD7541
000071ff71bd3332  vmovaps xmm13, [rsp+0x30]
000071ff71bd3338  vpermilpd xmm13, xmm13, 0x00
000071ff71bd333e  vmovaps xmm7, [rsp+0x60]
000071ff71bd3344  movaps xmm11, xmm7
000071ff71bd3348  mulpd xmm11, xmm13
000071ff71bd334d  vcmppd xmm6, xmm11, xmm11, 0x03
000071ff71bd3353  ptest xmm6, xmm6
000071ff71bd3358  jnz 0x000071FF71BD7685
000071ff71bd335e  movaps xmm13, xmm10
000071ff71bd3362  addpd xmm13, xmm12
000071ff71bd3367  vcmppd xmm7, xmm13, xmm13, 0x03
000071ff71bd336d  ptest xmm7, xmm7
000071ff71bd3372  jnz 0x000071FF71BD77C8
000071ff71bd3378  vmovaps xmm12, [rsp+0x30]
000071ff71bd337e  vpermilpd xmm12, xmm12, 0x00
000071ff71bd3384  vmovaps xmm7, [rsp+0x70]
000071ff71bd338a  movaps xmm10, xmm7
000071ff71bd338e  mulpd xmm10, xmm12
000071ff71bd3393  vcmppd xmm6, xmm10, xmm10, 0x03
000071ff71bd3399  ptest xmm6, xmm6
000071ff71bd339e  jnz 0x000071FF71BD790C
000071ff71bd33a4  movaps xmm12, xmm1
000071ff71bd33a8  addpd xmm12, xmm8
000071ff71bd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000071ff71bd33b3  ptest xmm7, xmm7
000071ff71bd33b8  jnz 0x000071FF71BD7A4F
000071ff71bd33be  lea rax, [r14+0x70]
000071ff71bd33c2  movups xmm1, [r13+rax*1]
000071ff71bd33c8  movaps [r15+0x240], xmm1
000071ff71bd33d0  movaps xmm8, xmm15
000071ff71bd33d4  addpd xmm8, xmm9
000071ff71bd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000071ff71bd33df  ptest xmm7, xmm7
000071ff71bd33e4  jnz 0x000071FF71BD7B9C
000071ff71bd33ea  movaps [r15+0x170], xmm8
000071ff71bd33f2  vmovaps xmm15, [rsp+0x40]
000071ff71bd33f8  vpermilpd xmm15, xmm15, 0x00
000071ff71bd33fe  movaps xmm9, xmm1
000071ff71bd3402  mulpd xmm9, xmm15
000071ff71bd3407  vcmppd xmm7, xmm9, xmm9, 0x03
000071ff71bd340d  ptest xmm7, xmm7
000071ff71bd3412  jnz 0x000071FF71BD7CE0
000071ff71bd3418  vmovaps xmm1, [rsp+0x40]
000071ff71bd341e  vpermilpd xmm1, xmm1, 0x00
000071ff71bd3424  movaps xmm15, xmm4
000071ff71bd3428  mulpd xmm15, xmm1
000071ff71bd342d  vcmppd xmm7, xmm15, xmm15, 0x03
000071ff71bd3433  ptest xmm7, xmm7
000071ff71bd3438  jnz 0x000071FF71BD7E23
000071ff71bd343e  movaps [r15+0x180], xmm15
000071ff71bd3446  movaps xmm1, xmm14
000071ff71bd344a  addpd xmm1, xmm11
000071ff71bd344f  vcmppd xmm7, xmm1, xmm1, 0x03
000071ff71bd3454  ptest xmm7, xmm7
000071ff71bd3459  jnz 0x000071FF71BD7F65
000071ff71bd345f  movaps [r15+0x210], xmm1
000071ff71bd3467  movups xmm14, [r13+r14*1]
000071ff71bd346d  lea rax, [r14+0x10]
000071ff71bd3471  movups xmm11, [r13+rax*1]
000071ff71bd3477  movaps [r15+0x230], xmm11
000071ff71bd347f  movaps xmm7, xmm13
000071ff71bd3483  addpd xmm7, xmm10
000071ff71bd3488  vcmppd xmm6, xmm7, xmm7, 0x03
000071ff71bd348d  ptest xmm6, xmm6
000071ff71bd3492  jnz 0x000071FF71BD80BB
000071ff71bd3498  movaps [r15+0x130], xmm7
000071ff71bd34a0  vmovaps xmm13, [rsp+0x40]
000071ff71bd34a6  vpermilpd xmm13, xmm13, 0x00
000071ff71bd34ac  movaps xmm10, xmm11
000071ff71bd34b0  mulpd xmm10, xmm13
000071ff71bd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000071ff71bd34bb  ptest xmm6, xmm6
000071ff71bd34c0  jnz 0x000071FF71BD81FD
000071ff71bd34c6  movaps [r15+0x220], xmm10
000071ff71bd34ce  vmovaps xmm13, [rsp+0x40]
000071ff71bd34d4  vpermilpd xmm13, xmm13, 0x00
000071ff71bd34da  movaps xmm11, xmm14
000071ff71bd34de  mulpd xmm11, xmm13
000071ff71bd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000071ff71bd34e9  ptest xmm6, xmm6
000071ff71bd34ee  jnz 0x000071FF71BD8341
000071ff71bd34f4  movaps xmm14, xmm12
000071ff71bd34f8  addpd xmm14, xmm9
000071ff71bd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000071ff71bd3503  ptest xmm13, xmm13
000071ff71bd3509  jnz 0x000071FF71BD8485
000071ff71bd350f  movaps [r15+0x140], xmm14
000071ff71bd3517  movaps xmm13, xmm8
000071ff71bd351b  addpd xmm13, xmm15
000071ff71bd3520  vcmppd xmm12, xmm13, xmm13, 0x03
000071ff71bd3526  ptest xmm12, xmm12
000071ff71bd352c  jnz 0x000071FF71BD85C9
000071ff71bd3532  movaps [r15+0x150], xmm13
000071ff71bd353a  movaps xmm15, xmm1
000071ff71bd353e  addpd xmm15, xmm10
000071ff71bd3543  vcmppd xmm12, xmm15, xmm15, 0x03
000071ff71bd3549  ptest xmm12, xmm12
000071ff71bd354f  jnz 0x000071FF71BD870D
000071ff71bd3555  movaps [r15+0x160], xmm15
000071ff71bd355d  movaps xmm1, xmm7
000071ff71bd3560  addpd xmm1, xmm11
000071ff71bd3565  vcmppd xmm12, xmm1, xmm1, 0x03
000071ff71bd356a  ptest xmm12, xmm12
000071ff71bd3570  jnz 0x000071FF71BD8850
000071ff71bd3576  movaps [r15+0x120], xmm1
000071ff71bd357e  mov eax, 0x432200
000071ff71bd3583  movups [r13+rax*1], xmm14
000071ff71bd3589  mov eax, 0x432210
000071ff71bd358e  movups [r13+rax*1], xmm13
000071ff71bd3594  mov eax, 0x432220
000071ff71bd3599  movups [r13+rax*1], xmm15
000071ff71bd359f  mov eax, 0x432230
000071ff71bd35a4  movups [r13+rax*1], xmm1
000071ff71bd35aa  mov eax, [r15+0x108]
000071ff71bd35b1  sahf
000071ff71bd35b2  jnz 0x000071FF71BD35E4
000071ff71bd35b4  cmp dword ptr [r15+0x318], 0x00
000071ff71bd35bc  jz 0x000071FF71BDEAE0
000071ff71bd35c2  nop [rax+rax*1], ax
000071ff71bd35cb  nop [rax+rax*1], eax
000071ff71bd35d3  mov eax, 0x4106D0
000071ff71bd35d8  mov [r15+0x100], rax
000071ff71bd35df  jmp 0x000071FF719FE110
000071ff71bd35e4  cmp dword ptr [r15+0x318], 0x00
000071ff71bd35ec  jz 0x000071FF71BD89C0
000071ff71bd35f2  nop [rax+rax*1], ax
000071ff71bd35fb  nop [rax+rax*1], eax
000071ff71bd3603  mov eax, 0x410504
000071ff71bd3608  mov [r15+0x100], rax
000071ff71bd360f  jmp 0x000071FF719FE110
000071ff71bd3614  int3
000071ff71bd3615  call 0x000071FF71AD64F0
000071ff71bd361a  jmp 0x000071FF71BD2311
000071ff71bd361f  call 0x000071FF71AE5820
000071ff71bd3624  jmp 0x000071FF71BD231E
000071ff71bd3629  call 0x000071FF71AE3320
000071ff71bd362e  jmp 0x000071FF71BD2332
000071ff71bd3633  call 0x000071FF71AE20A0
000071ff71bd3638  jmp 0x000071FF71BD233C
000071ff71bd363d  call 0x000071FF71A09D70
000071ff71bd3642  jmp 0x000071FF71BD234A
000071ff71bd3647  call 0x000071FF71ADFBC0
000071ff71bd364c  jmp 0x000071FF71BD2354
000071ff71bd3651  call 0x000071FF71AC4740
000071ff71bd3656  jmp 0x000071FF71BD2368
000071ff71bd365b  call 0x000071FF71AB5400
000071ff71bd3660  jmp 0x000071FF71BD2375
000071ff71bd3665  call 0x000071FF71AB52F0
000071ff71bd366a  jmp 0x000071FF71BD2382
000071ff71bd366f  call 0x000071FF71AC4620
000071ff71bd3674  jmp 0x000071FF71BD238F
000071ff71bd3679  call 0x000071FF71ABD750
000071ff71bd367e  jmp 0x000071FF71BD239C
000071ff71bd3683  call 0x000071FF71ABC4E0
000071ff71bd3688  jmp 0x000071FF71BD23A9
000071ff71bd368d  call 0x000071FF71ABB270
000071ff71bd3692  jmp 0x000071FF71BD23B6
000071ff71bd3697  call 0x000071FF71ABA000
000071ff71bd369c  jmp 0x000071FF71BD23C3
000071ff71bd36a1  call 0x000071FF71AC4740
000071ff71bd36a6  jmp 0x000071FF71BD23D0
000071ff71bd36ab  call 0x000071FF71AB5400
000071ff71bd36b0  jmp 0x000071FF71BD23DD
000071ff71bd36b5  call 0x000071FF71AB52F0
000071ff71bd36ba  jmp 0x000071FF71BD23EA
000071ff71bd36bf  call 0x000071FF71AC4620
000071ff71bd36c4  jmp 0x000071FF71BD23F7
000071ff71bd36c9  call 0x000071FF71AB8D90
000071ff71bd36ce  jmp 0x000071FF71BD2404
000071ff71bd36d3  call 0x000071FF71AB8A20
000071ff71bd36d8  jmp 0x000071FF71BD2411
000071ff71bd36dd  call 0x000071FF71AB77B0
000071ff71bd36e2  jmp 0x000071FF71BD241B
000071ff71bd36e7  call 0x000071FF71AB6550
000071ff71bd36ec  jmp 0x000071FF71BD2425
000071ff71bd36f1  call 0x000071FF71AB5400
000071ff71bd36f6  jmp 0x000071FF71BD2437
000071ff71bd36fb  call 0x000071FF71AC0FC0
000071ff71bd3700  jmp 0x000071FF71BD2441
000071ff71bd3705  call 0x000071FF71AB52F0
000071ff71bd370a  jmp 0x000071FF71BD244B
000071ff71bd370f  call 0x000071FF71AC0EA0
000071ff71bd3714  jmp 0x000071FF71BD2455
000071ff71bd3719  call 0x000071FF71ABFD50
000071ff71bd371e  jmp 0x000071FF71BD245F
000071ff71bd3723  call 0x000071FF71AB8EA0
000071ff71bd3728  jmp 0x000071FF71BD2469
000071ff71bd372d  call 0x000071FF71ABFC30
000071ff71bd3732  jmp 0x000071FF71BD2476
000071ff71bd3737  call 0x000071FF71AB8D90
000071ff71bd373c  jmp 0x000071FF71BD2483
000071ff71bd3741  call 0x000071FF71AB52F0
000071ff71bd3746  jmp 0x000071FF71BD2496
000071ff71bd374b  call 0x000071FF71AB52F0
000071ff71bd3750  jmp 0x000071FF71BD24A9
000071ff71bd3755  call 0x000071FF71AC0FC0
000071ff71bd375a  jmp 0x000071FF71BD24B6
000071ff71bd375f  call 0x000071FF71AC0FC0
000071ff71bd3764  jmp 0x000071FF71BD24C9
000071ff71bd3769  call 0x000071FF71AC0EA0
000071ff71bd376e  jmp 0x000071FF71BD24D6
000071ff71bd3773  call 0x000071FF71AB52F0
000071ff71bd3778  jmp 0x000071FF71BD24E9
000071ff71bd377d  call 0x000071FF71AB52F0
000071ff71bd3782  jmp 0x000071FF71BD24FC
000071ff71bd3787  call 0x000071FF71AB52F0
000071ff71bd378c  jmp 0x000071FF71BD250F
000071ff71bd3791  call 0x000071FF71AB52F0
000071ff71bd3796  jmp 0x000071FF71BD252A
000071ff71bd379b  call 0x000071FF71AB52F0
000071ff71bd37a0  jmp 0x000071FF71BD253D
000071ff71bd37a5  call 0x000071FF71AB5400
000071ff71bd37aa  jmp 0x000071FF71BD257E
000071ff71bd37af  call 0x000071FF71AC0FC0
000071ff71bd37b4  jmp 0x000071FF71BD258B
000071ff71bd37b9  call 0x000071FF71AB52F0
000071ff71bd37be  jmp 0x000071FF71BD2598
000071ff71bd37c3  call 0x000071FF71AC0EA0
000071ff71bd37c8  jmp 0x000071FF71BD25A5
000071ff71bd37cd  call 0x000071FF719FF540
000071ff71bd37d2  jmp 0x000071FF71BD25C3
000071ff71bd37d7  call 0x000071FF71A08C20
000071ff71bd37dc  jmp 0x000071FF71BD25CD
000071ff71bd37e1  call 0x000071FF71AE21C0
000071ff71bd37e6  jmp 0x000071FF71BD25D3
000071ff71bd37eb  call 0x000071FF719FF540
000071ff71bd37f0  jmp 0x000071FF71BD25E3
000071ff71bd37f5  call 0x000071FF71AC0370
000071ff71bd37fa  jmp 0x000071FF71BD2611
000071ff71bd37ff  call 0x000071FF71ABF100
000071ff71bd3804  jmp 0x000071FF71BD261A
000071ff71bd3809  call 0x000071FF71AC0370
000071ff71bd380e  jmp 0x000071FF71BD2674
000071ff71bd3813  call 0x000071FF71ABF100
000071ff71bd3818  jmp 0x000071FF71BD267D
000071ff71bd381d  call 0x000071FF71AC0370
000071ff71bd3822  jmp 0x000071FF71BD26C6
000071ff71bd3827  call 0x000071FF71ABF100
000071ff71bd382c  jmp 0x000071FF71BD26CF
000071ff71bd3831  call 0x000071FF71A0B720
000071ff71bd3836  jmp 0x000071FF71BD2714
000071ff71bd383b  call 0x000071FF71AB47C0
000071ff71bd3840  jmp 0x000071FF71BD2727
000071ff71bd3845  call 0x000071FF71A08B00
000071ff71bd384a  jmp 0x000071FF71BD273E
000071ff71bd384f  call 0x000071FF719FF430
000071ff71bd3854  jmp 0x000071FF71BD2751
000071ff71bd3859  call 0x000071FF719FF430
000071ff71bd385e  jmp 0x000071FF71BD2764
000071ff71bd3863  sub rsp, 0x08
000071ff71bd3867  push rax
000071ff71bd3868  push rcx
000071ff71bd3869  push rdx
000071ff71bd386a  push rdi
000071ff71bd386b  push rsi
000071ff71bd386c  push r8
000071ff71bd386e  push r9
000071ff71bd3870  push r10
000071ff71bd3872  push r11
000071ff71bd3874  sub rsp, 0xF0
000071ff71bd387b  vmovaps [rsp], xmm0
000071ff71bd3880  vmovaps [rsp+0x10], xmm2
000071ff71bd3886  vmovaps [rsp+0x20], xmm3
000071ff71bd388c  vmovaps [rsp+0x30], xmm4
000071ff71bd3892  vmovaps [rsp+0x40], xmm5
000071ff71bd3898  vmovaps [rsp+0x50], xmm6
000071ff71bd389e  vmovaps [rsp+0x60], xmm7
000071ff71bd38a4  vmovaps [rsp+0x70], xmm8
000071ff71bd38aa  vmovaps [rsp+0x80], xmm9
000071ff71bd38b3  vmovaps [rsp+0x90], xmm10
000071ff71bd38bc  vmovaps [rsp+0xA0], xmm11
000071ff71bd38c5  vmovaps [rsp+0xB0], xmm12
000071ff71bd38ce  vmovaps [rsp+0xC0], xmm13
000071ff71bd38d7  vmovaps [rsp+0xD0], xmm14
000071ff71bd38e0  vmovaps [rsp+0xE0], xmm15
000071ff71bd38e9  sub rsp, 0x30
000071ff71bd38ed  movaps [rsp], xmm1
000071ff71bd38f1  movaps [rsp+0x10], xmm12
000071ff71bd38f7  movaps [rsp+0x20], xmm15
000071ff71bd38fd  lea rdi, [rsp]
000071ff71bd3901  mov esi, 0x00
000071ff71bd3906  mov rax, 0x5E6872E10530
000071ff71bd3910  call rax
000071ff71bd3912  movaps xmm1, [rsp]
000071ff71bd3916  add rsp, 0x30
000071ff71bd391a  vmovaps xmm0, [rsp]
000071ff71bd391f  vmovaps xmm2, [rsp+0x10]
000071ff71bd3925  vmovaps xmm3, [rsp+0x20]
000071ff71bd392b  vmovaps xmm4, [rsp+0x30]
000071ff71bd3931  vmovaps xmm5, [rsp+0x40]
000071ff71bd3937  vmovaps xmm6, [rsp+0x50]
000071ff71bd393d  vmovaps xmm7, [rsp+0x60]
000071ff71bd3943  vmovaps xmm8, [rsp+0x70]
000071ff71bd3949  vmovaps xmm9, [rsp+0x80]
000071ff71bd3952  vmovaps xmm10, [rsp+0x90]
000071ff71bd395b  vmovaps xmm11, [rsp+0xA0]
000071ff71bd3964  vmovaps xmm12, [rsp+0xB0]
000071ff71bd396d  vmovaps xmm13, [rsp+0xC0]
000071ff71bd3976  vmovaps xmm14, [rsp+0xD0]
000071ff71bd397f  vmovaps xmm15, [rsp+0xE0]
000071ff71bd3988  add rsp, 0xF0
000071ff71bd398f  pop r11
000071ff71bd3991  pop r10
000071ff71bd3993  pop r9
000071ff71bd3995  pop r8
000071ff71bd3997  pop rsi
000071ff71bd3998  pop rdi
000071ff71bd3999  pop rdx
000071ff71bd399a  pop rcx
000071ff71bd399b  pop rax
000071ff71bd399c  add rsp, 0x08
000071ff71bd39a0  jmp 0x000071FF71BD27B2
000071ff71bd39a5  sub rsp, 0x08
000071ff71bd39a9  push rax
000071ff71bd39aa  push rcx
000071ff71bd39ab  push rdx
000071ff71bd39ac  push rdi
000071ff71bd39ad  push rsi
000071ff71bd39ae  push r8
000071ff71bd39b0  push r9
000071ff71bd39b2  push r10
000071ff71bd39b4  push r11
000071ff71bd39b6  sub rsp, 0xF0
000071ff71bd39bd  vmovaps [rsp], xmm0
000071ff71bd39c2  vmovaps [rsp+0x10], xmm1
000071ff71bd39c8  vmovaps [rsp+0x20], xmm2
000071ff71bd39ce  vmovaps [rsp+0x30], xmm3
000071ff71bd39d4  vmovaps [rsp+0x40], xmm4
000071ff71bd39da  vmovaps [rsp+0x50], xmm5
000071ff71bd39e0  vmovaps [rsp+0x60], xmm6
000071ff71bd39e6  vmovaps [rsp+0x70], xmm7
000071ff71bd39ec  vmovaps [rsp+0x80], xmm8
000071ff71bd39f5  vmovaps [rsp+0x90], xmm9
000071ff71bd39fe  vmovaps [rsp+0xA0], xmm10
000071ff71bd3a07  vmovaps [rsp+0xB0], xmm11
000071ff71bd3a10  vmovaps [rsp+0xC0], xmm12
000071ff71bd3a19  vmovaps [rsp+0xD0], xmm13
000071ff71bd3a22  vmovaps [rsp+0xE0], xmm15
000071ff71bd3a2b  sub rsp, 0x30
000071ff71bd3a2f  movaps [rsp], xmm14
000071ff71bd3a34  movaps [rsp+0x10], xmm1
000071ff71bd3a39  movaps [rsp+0x20], xmm15
000071ff71bd3a3f  lea rdi, [rsp]
000071ff71bd3a43  mov esi, 0x00
000071ff71bd3a48  mov rax, 0x5E6872E10530
000071ff71bd3a52  call rax
000071ff71bd3a54  movaps xmm14, [rsp]
000071ff71bd3a59  add rsp, 0x30
000071ff71bd3a5d  vmovaps xmm0, [rsp]
000071ff71bd3a62  vmovaps xmm1, [rsp+0x10]
000071ff71bd3a68  vmovaps xmm2, [rsp+0x20]
000071ff71bd3a6e  vmovaps xmm3, [rsp+0x30]
000071ff71bd3a74  vmovaps xmm4, [rsp+0x40]
000071ff71bd3a7a  vmovaps xmm5, [rsp+0x50]
000071ff71bd3a80  vmovaps xmm6, [rsp+0x60]
000071ff71bd3a86  vmovaps xmm7, [rsp+0x70]
000071ff71bd3a8c  vmovaps xmm8, [rsp+0x80]
000071ff71bd3a95  vmovaps xmm9, [rsp+0x90]
000071ff71bd3a9e  vmovaps xmm10, [rsp+0xA0]
000071ff71bd3aa7  vmovaps xmm11, [rsp+0xB0]
000071ff71bd3ab0  vmovaps xmm12, [rsp+0xC0]
000071ff71bd3ab9  vmovaps xmm13, [rsp+0xD0]
000071ff71bd3ac2  vmovaps xmm15, [rsp+0xE0]
000071ff71bd3acb  add rsp, 0xF0
000071ff71bd3ad2  pop r11
000071ff71bd3ad4  pop r10
000071ff71bd3ad6  pop r9
000071ff71bd3ad8  pop r8
000071ff71bd3ada  pop rsi
000071ff71bd3adb  pop rdi
000071ff71bd3adc  pop rdx
000071ff71bd3add  pop rcx
000071ff71bd3ade  pop rax
000071ff71bd3adf  add rsp, 0x08
000071ff71bd3ae3  jmp 0x000071FF71BD2800
000071ff71bd3ae8  sub rsp, 0x08
000071ff71bd3aec  push rax
000071ff71bd3aed  push rcx
000071ff71bd3aee  push rdx
000071ff71bd3aef  push rdi
000071ff71bd3af0  push rsi
000071ff71bd3af1  push r8
000071ff71bd3af3  push r9
000071ff71bd3af5  push r10
000071ff71bd3af7  push r11
000071ff71bd3af9  sub rsp, 0xF0
000071ff71bd3b00  vmovaps [rsp], xmm0
000071ff71bd3b05  vmovaps [rsp+0x10], xmm1
000071ff71bd3b0b  vmovaps [rsp+0x20], xmm2
000071ff71bd3b11  vmovaps [rsp+0x30], xmm3
000071ff71bd3b17  vmovaps [rsp+0x40], xmm4
000071ff71bd3b1d  vmovaps [rsp+0x50], xmm5
000071ff71bd3b23  vmovaps [rsp+0x60], xmm6
000071ff71bd3b29  vmovaps [rsp+0x70], xmm7
000071ff71bd3b2f  vmovaps [rsp+0x80], xmm8
000071ff71bd3b38  vmovaps [rsp+0x90], xmm9
000071ff71bd3b41  vmovaps [rsp+0xA0], xmm10
000071ff71bd3b4a  vmovaps [rsp+0xB0], xmm11
000071ff71bd3b53  vmovaps [rsp+0xC0], xmm12
000071ff71bd3b5c  vmovaps [rsp+0xD0], xmm13
000071ff71bd3b65  vmovaps [rsp+0xE0], xmm14
000071ff71bd3b6e  sub rsp, 0x30
000071ff71bd3b72  movaps [rsp], xmm15
000071ff71bd3b77  movaps [rsp+0x10], xmm12
000071ff71bd3b7d  movaps [rsp+0x20], xmm13
000071ff71bd3b83  lea rdi, [rsp]
000071ff71bd3b87  mov esi, 0x00
000071ff71bd3b8c  mov rax, 0x5E6872E10530
000071ff71bd3b96  call rax
000071ff71bd3b98  movaps xmm15, [rsp]
000071ff71bd3b9d  add rsp, 0x30
000071ff71bd3ba1  vmovaps xmm0, [rsp]
000071ff71bd3ba6  vmovaps xmm1, [rsp+0x10]
000071ff71bd3bac  vmovaps xmm2, [rsp+0x20]
000071ff71bd3bb2  vmovaps xmm3, [rsp+0x30]
000071ff71bd3bb8  vmovaps xmm4, [rsp+0x40]
000071ff71bd3bbe  vmovaps xmm5, [rsp+0x50]
000071ff71bd3bc4  vmovaps xmm6, [rsp+0x60]
000071ff71bd3bca  vmovaps xmm7, [rsp+0x70]
000071ff71bd3bd0  vmovaps xmm8, [rsp+0x80]
000071ff71bd3bd9  vmovaps xmm9, [rsp+0x90]
000071ff71bd3be2  vmovaps xmm10, [rsp+0xA0]
000071ff71bd3beb  vmovaps xmm11, [rsp+0xB0]
000071ff71bd3bf4  vmovaps xmm12, [rsp+0xC0]
000071ff71bd3bfd  vmovaps xmm13, [rsp+0xD0]
000071ff71bd3c06  vmovaps xmm14, [rsp+0xE0]
000071ff71bd3c0f  add rsp, 0xF0
000071ff71bd3c16  pop r11
000071ff71bd3c18  pop r10
000071ff71bd3c1a  pop r9
000071ff71bd3c1c  pop r8
000071ff71bd3c1e  pop rsi
000071ff71bd3c1f  pop rdi
000071ff71bd3c20  pop rdx
000071ff71bd3c21  pop rcx
000071ff71bd3c22  pop rax
000071ff71bd3c23  add rsp, 0x08
000071ff71bd3c27  jmp 0x000071FF71BD2835
000071ff71bd3c2c  sub rsp, 0x08
000071ff71bd3c30  push rax
000071ff71bd3c31  push rcx
000071ff71bd3c32  push rdx
000071ff71bd3c33  push rdi
000071ff71bd3c34  push rsi
000071ff71bd3c35  push r8
000071ff71bd3c37  push r9
000071ff71bd3c39  push r10
000071ff71bd3c3b  push r11
000071ff71bd3c3d  sub rsp, 0xF0
000071ff71bd3c44  vmovaps [rsp], xmm0
000071ff71bd3c49  vmovaps [rsp+0x10], xmm2
000071ff71bd3c4f  vmovaps [rsp+0x20], xmm3
000071ff71bd3c55  vmovaps [rsp+0x30], xmm4
000071ff71bd3c5b  vmovaps [rsp+0x40], xmm5
000071ff71bd3c61  vmovaps [rsp+0x50], xmm6
000071ff71bd3c67  vmovaps [rsp+0x60], xmm7
000071ff71bd3c6d  vmovaps [rsp+0x70], xmm8
000071ff71bd3c73  vmovaps [rsp+0x80], xmm9
000071ff71bd3c7c  vmovaps [rsp+0x90], xmm10
000071ff71bd3c85  vmovaps [rsp+0xA0], xmm11
000071ff71bd3c8e  vmovaps [rsp+0xB0], xmm12
000071ff71bd3c97  vmovaps [rsp+0xC0], xmm13
000071ff71bd3ca0  vmovaps [rsp+0xD0], xmm14
000071ff71bd3ca9  vmovaps [rsp+0xE0], xmm15
000071ff71bd3cb2  sub rsp, 0x30
000071ff71bd3cb6  movaps [rsp], xmm1
000071ff71bd3cba  movaps [rsp+0x10], xmm12
000071ff71bd3cc0  movaps [rsp+0x20], xmm10
000071ff71bd3cc6  lea rdi, [rsp]
000071ff71bd3cca  mov esi, 0x00
000071ff71bd3ccf  mov rax, 0x5E6872E10530
000071ff71bd3cd9  call rax
000071ff71bd3cdb  movaps xmm1, [rsp]
000071ff71bd3cdf  add rsp, 0x30
000071ff71bd3ce3  vmovaps xmm0, [rsp]
000071ff71bd3ce8  vmovaps xmm2, [rsp+0x10]
000071ff71bd3cee  vmovaps xmm3, [rsp+0x20]
000071ff71bd3cf4  vmovaps xmm4, [rsp+0x30]
000071ff71bd3cfa  vmovaps xmm5, [rsp+0x40]
000071ff71bd3d00  vmovaps xmm6, [rsp+0x50]
000071ff71bd3d06  vmovaps xmm7, [rsp+0x60]
000071ff71bd3d0c  vmovaps xmm8, [rsp+0x70]
000071ff71bd3d12  vmovaps xmm9, [rsp+0x80]
000071ff71bd3d1b  vmovaps xmm10, [rsp+0x90]
000071ff71bd3d24  vmovaps xmm11, [rsp+0xA0]
000071ff71bd3d2d  vmovaps xmm12, [rsp+0xB0]
000071ff71bd3d36  vmovaps xmm13, [rsp+0xC0]
000071ff71bd3d3f  vmovaps xmm14, [rsp+0xD0]
000071ff71bd3d48  vmovaps xmm15, [rsp+0xE0]
000071ff71bd3d51  add rsp, 0xF0
000071ff71bd3d58  pop r11
000071ff71bd3d5a  pop r10
000071ff71bd3d5c  pop r9
000071ff71bd3d5e  pop r8
000071ff71bd3d60  pop rsi
000071ff71bd3d61  pop rdi
000071ff71bd3d62  pop rdx
000071ff71bd3d63  pop rcx
000071ff71bd3d64  pop rax
000071ff71bd3d65  add rsp, 0x08
000071ff71bd3d69  jmp 0x000071FF71BD284F
000071ff71bd3d6e  sub rsp, 0x08
000071ff71bd3d72  push rax
000071ff71bd3d73  push rcx
000071ff71bd3d74  push rdx
000071ff71bd3d75  push rdi
000071ff71bd3d76  push rsi
000071ff71bd3d77  push r8
000071ff71bd3d79  push r9
000071ff71bd3d7b  push r10
000071ff71bd3d7d  push r11
000071ff71bd3d7f  sub rsp, 0xF0
000071ff71bd3d86  vmovaps [rsp], xmm0
000071ff71bd3d8b  vmovaps [rsp+0x10], xmm1
000071ff71bd3d91  vmovaps [rsp+0x20], xmm2
000071ff71bd3d97  vmovaps [rsp+0x30], xmm3
000071ff71bd3d9d  vmovaps [rsp+0x40], xmm4
000071ff71bd3da3  vmovaps [rsp+0x50], xmm5
000071ff71bd3da9  vmovaps [rsp+0x60], xmm6
000071ff71bd3daf  vmovaps [rsp+0x70], xmm7
000071ff71bd3db5  vmovaps [rsp+0x80], xmm8
000071ff71bd3dbe  vmovaps [rsp+0x90], xmm9
000071ff71bd3dc7  vmovaps [rsp+0xA0], xmm10
000071ff71bd3dd0  vmovaps [rsp+0xB0], xmm11
000071ff71bd3dd9  vmovaps [rsp+0xC0], xmm12
000071ff71bd3de2  vmovaps [rsp+0xD0], xmm14
000071ff71bd3deb  vmovaps [rsp+0xE0], xmm15
000071ff71bd3df4  sub rsp, 0x30
000071ff71bd3df8  movaps [rsp], xmm13
000071ff71bd3dfd  movaps [rsp+0x10], xmm12
000071ff71bd3e03  movaps [rsp+0x20], xmm2
000071ff71bd3e08  lea rdi, [rsp]
000071ff71bd3e0c  mov esi, 0x00
000071ff71bd3e11  mov rax, 0x5E6872E10530
000071ff71bd3e1b  call rax
000071ff71bd3e1d  movaps xmm13, [rsp]
000071ff71bd3e22  add rsp, 0x30
000071ff71bd3e26  vmovaps xmm0, [rsp]
000071ff71bd3e2b  vmovaps xmm1, [rsp+0x10]
000071ff71bd3e31  vmovaps xmm2, [rsp+0x20]
000071ff71bd3e37  vmovaps xmm3, [rsp+0x30]
000071ff71bd3e3d  vmovaps xmm4, [rsp+0x40]
000071ff71bd3e43  vmovaps xmm5, [rsp+0x50]
000071ff71bd3e49  vmovaps xmm6, [rsp+0x60]
000071ff71bd3e4f  vmovaps xmm7, [rsp+0x70]
000071ff71bd3e55  vmovaps xmm8, [rsp+0x80]
000071ff71bd3e5e  vmovaps xmm9, [rsp+0x90]
000071ff71bd3e67  vmovaps xmm10, [rsp+0xA0]
000071ff71bd3e70  vmovaps xmm11, [rsp+0xB0]
000071ff71bd3e79  vmovaps xmm12, [rsp+0xC0]
000071ff71bd3e82  vmovaps xmm14, [rsp+0xD0]
000071ff71bd3e8b  vmovaps xmm15, [rsp+0xE0]
000071ff71bd3e94  add rsp, 0xF0
000071ff71bd3e9b  pop r11
000071ff71bd3e9d  pop r10
000071ff71bd3e9f  pop r9
000071ff71bd3ea1  pop r8
000071ff71bd3ea3  pop rsi
000071ff71bd3ea4  pop rdi
000071ff71bd3ea5  pop rdx
000071ff71bd3ea6  pop rcx
000071ff71bd3ea7  pop rax
000071ff71bd3ea8  add rsp, 0x08
000071ff71bd3eac  jmp 0x000071FF71BD286A
000071ff71bd3eb1  sub rsp, 0x08
000071ff71bd3eb5  push rax
000071ff71bd3eb6  push rcx
000071ff71bd3eb7  push rdx
000071ff71bd3eb8  push rdi
000071ff71bd3eb9  push rsi
000071ff71bd3eba  push r8
000071ff71bd3ebc  push r9
000071ff71bd3ebe  push r10
000071ff71bd3ec0  push r11
000071ff71bd3ec2  sub rsp, 0xF0
000071ff71bd3ec9  vmovaps [rsp], xmm0
000071ff71bd3ece  vmovaps [rsp+0x10], xmm2
000071ff71bd3ed4  vmovaps [rsp+0x20], xmm3
000071ff71bd3eda  vmovaps [rsp+0x30], xmm4
000071ff71bd3ee0  vmovaps [rsp+0x40], xmm5
000071ff71bd3ee6  vmovaps [rsp+0x50], xmm6
000071ff71bd3eec  vmovaps [rsp+0x60], xmm7
000071ff71bd3ef2  vmovaps [rsp+0x70], xmm8
000071ff71bd3ef8  vmovaps [rsp+0x80], xmm9
000071ff71bd3f01  vmovaps [rsp+0x90], xmm10
000071ff71bd3f0a  vmovaps [rsp+0xA0], xmm11
000071ff71bd3f13  vmovaps [rsp+0xB0], xmm12
000071ff71bd3f1c  vmovaps [rsp+0xC0], xmm13
000071ff71bd3f25  vmovaps [rsp+0xD0], xmm14
000071ff71bd3f2e  vmovaps [rsp+0xE0], xmm15
000071ff71bd3f37  sub rsp, 0x30
000071ff71bd3f3b  movaps [rsp], xmm1
000071ff71bd3f3f  movaps [rsp+0x10], xmm10
000071ff71bd3f45  movaps [rsp+0x20], xmm2
000071ff71bd3f4a  lea rdi, [rsp]
000071ff71bd3f4e  mov esi, 0x00
000071ff71bd3f53  mov rax, 0x5E6872E10530
000071ff71bd3f5d  call rax
000071ff71bd3f5f  movaps xmm1, [rsp]
000071ff71bd3f63  add rsp, 0x30
000071ff71bd3f67  vmovaps xmm0, [rsp]
000071ff71bd3f6c  vmovaps xmm2, [rsp+0x10]
000071ff71bd3f72  vmovaps xmm3, [rsp+0x20]
000071ff71bd3f78  vmovaps xmm4, [rsp+0x30]
000071ff71bd3f7e  vmovaps xmm5, [rsp+0x40]
000071ff71bd3f84  vmovaps xmm6, [rsp+0x50]
000071ff71bd3f8a  vmovaps xmm7, [rsp+0x60]
000071ff71bd3f90  vmovaps xmm8, [rsp+0x70]
000071ff71bd3f96  vmovaps xmm9, [rsp+0x80]
000071ff71bd3f9f  vmovaps xmm10, [rsp+0x90]
000071ff71bd3fa8  vmovaps xmm11, [rsp+0xA0]
000071ff71bd3fb1  vmovaps xmm12, [rsp+0xB0]
000071ff71bd3fba  vmovaps xmm13, [rsp+0xC0]
000071ff71bd3fc3  vmovaps xmm14, [rsp+0xD0]
000071ff71bd3fcc  vmovaps xmm15, [rsp+0xE0]
000071ff71bd3fd5  add rsp, 0xF0
000071ff71bd3fdc  pop r11
000071ff71bd3fde  pop r10
000071ff71bd3fe0  pop r9
000071ff71bd3fe2  pop r8
000071ff71bd3fe4  pop rsi
000071ff71bd3fe5  pop rdi
000071ff71bd3fe6  pop rdx
000071ff71bd3fe7  pop rcx
000071ff71bd3fe8  pop rax
000071ff71bd3fe9  add rsp, 0x08
000071ff71bd3fed  jmp 0x000071FF71BD28D2
000071ff71bd3ff2  sub rsp, 0x08
000071ff71bd3ff6  push rax
000071ff71bd3ff7  push rcx
000071ff71bd3ff8  push rdx
000071ff71bd3ff9  push rdi
000071ff71bd3ffa  push rsi
000071ff71bd3ffb  push r8
000071ff71bd3ffd  push r9
000071ff71bd3fff  push r10
000071ff71bd4001  push r11
000071ff71bd4003  sub rsp, 0xF0
000071ff71bd400a  vmovaps [rsp], xmm0
000071ff71bd400f  vmovaps [rsp+0x10], xmm1
000071ff71bd4015  vmovaps [rsp+0x20], xmm2
000071ff71bd401b  vmovaps [rsp+0x30], xmm3
000071ff71bd4021  vmovaps [rsp+0x40], xmm4
000071ff71bd4027  vmovaps [rsp+0x50], xmm5
000071ff71bd402d  vmovaps [rsp+0x60], xmm6
000071ff71bd4033  vmovaps [rsp+0x70], xmm7
000071ff71bd4039  vmovaps [rsp+0x80], xmm8
000071ff71bd4042  vmovaps [rsp+0x90], xmm9
000071ff71bd404b  vmovaps [rsp+0xA0], xmm10
000071ff71bd4054  vmovaps [rsp+0xB0], xmm11
000071ff71bd405d  vmovaps [rsp+0xC0], xmm12
000071ff71bd4066  vmovaps [rsp+0xD0], xmm13
000071ff71bd406f  vmovaps [rsp+0xE0], xmm14
000071ff71bd4078  sub rsp, 0x30
000071ff71bd407c  movaps [rsp], xmm15
000071ff71bd4081  movaps [rsp+0x10], xmm10
000071ff71bd4087  movaps [rsp+0x20], xmm2
000071ff71bd408c  lea rdi, [rsp]
000071ff71bd4090  mov esi, 0x00
000071ff71bd4095  mov rax, 0x5E6872E10530
000071ff71bd409f  call rax
000071ff71bd40a1  movaps xmm15, [rsp]
000071ff71bd40a6  add rsp, 0x30
000071ff71bd40aa  vmovaps xmm0, [rsp]
000071ff71bd40af  vmovaps xmm1, [rsp+0x10]
000071ff71bd40b5  vmovaps xmm2, [rsp+0x20]
000071ff71bd40bb  vmovaps xmm3, [rsp+0x30]
000071ff71bd40c1  vmovaps xmm4, [rsp+0x40]
000071ff71bd40c7  vmovaps xmm5, [rsp+0x50]
000071ff71bd40cd  vmovaps xmm6, [rsp+0x60]
000071ff71bd40d3  vmovaps xmm7, [rsp+0x70]
000071ff71bd40d9  vmovaps xmm8, [rsp+0x80]
000071ff71bd40e2  vmovaps xmm9, [rsp+0x90]
000071ff71bd40eb  vmovaps xmm10, [rsp+0xA0]
000071ff71bd40f4  vmovaps xmm11, [rsp+0xB0]
000071ff71bd40fd  vmovaps xmm12, [rsp+0xC0]
000071ff71bd4106  vmovaps xmm13, [rsp+0xD0]
000071ff71bd410f  vmovaps xmm14, [rsp+0xE0]
000071ff71bd4118  add rsp, 0xF0
000071ff71bd411f  pop r11
000071ff71bd4121  pop r10
000071ff71bd4123  pop r9
000071ff71bd4125  pop r8
000071ff71bd4127  pop rsi
000071ff71bd4128  pop rdi
000071ff71bd4129  pop rdx
000071ff71bd412a  pop rcx
000071ff71bd412b  pop rax
000071ff71bd412c  add rsp, 0x08
000071ff71bd4130  jmp 0x000071FF71BD2924
000071ff71bd4135  sub rsp, 0x08
000071ff71bd4139  push rax
000071ff71bd413a  push rcx
000071ff71bd413b  push rdx
000071ff71bd413c  push rdi
000071ff71bd413d  push rsi
000071ff71bd413e  push r8
000071ff71bd4140  push r9
000071ff71bd4142  push r10
000071ff71bd4144  push r11
000071ff71bd4146  sub rsp, 0xF0
000071ff71bd414d  vmovaps [rsp], xmm0
000071ff71bd4152  vmovaps [rsp+0x10], xmm2
000071ff71bd4158  vmovaps [rsp+0x20], xmm3
000071ff71bd415e  vmovaps [rsp+0x30], xmm4
000071ff71bd4164  vmovaps [rsp+0x40], xmm5
000071ff71bd416a  vmovaps [rsp+0x50], xmm6
000071ff71bd4170  vmovaps [rsp+0x60], xmm7
000071ff71bd4176  vmovaps [rsp+0x70], xmm8
000071ff71bd417c  vmovaps [rsp+0x80], xmm9
000071ff71bd4185  vmovaps [rsp+0x90], xmm10
000071ff71bd418e  vmovaps [rsp+0xA0], xmm11
000071ff71bd4197  vmovaps [rsp+0xB0], xmm12
000071ff71bd41a0  vmovaps [rsp+0xC0], xmm13
000071ff71bd41a9  vmovaps [rsp+0xD0], xmm14
000071ff71bd41b2  vmovaps [rsp+0xE0], xmm15
000071ff71bd41bb  sub rsp, 0x30
000071ff71bd41bf  movaps [rsp], xmm1
000071ff71bd41c3  movaps [rsp+0x10], xmm10
000071ff71bd41c9  movaps [rsp+0x20], xmm15
000071ff71bd41cf  lea rdi, [rsp]
000071ff71bd41d3  mov esi, 0x00
000071ff71bd41d8  mov rax, 0x5E6872E10530
000071ff71bd41e2  call rax
000071ff71bd41e4  movaps xmm1, [rsp]
000071ff71bd41e8  add rsp, 0x30
000071ff71bd41ec  vmovaps xmm0, [rsp]
000071ff71bd41f1  vmovaps xmm2, [rsp+0x10]
000071ff71bd41f7  vmovaps xmm3, [rsp+0x20]
000071ff71bd41fd  vmovaps xmm4, [rsp+0x30]
000071ff71bd4203  vmovaps xmm5, [rsp+0x40]
000071ff71bd4209  vmovaps xmm6, [rsp+0x50]
000071ff71bd420f  vmovaps xmm7, [rsp+0x60]
000071ff71bd4215  vmovaps xmm8, [rsp+0x70]
000071ff71bd421b  vmovaps xmm9, [rsp+0x80]
000071ff71bd4224  vmovaps xmm10, [rsp+0x90]
000071ff71bd422d  vmovaps xmm11, [rsp+0xA0]
000071ff71bd4236  vmovaps xmm12, [rsp+0xB0]
000071ff71bd423f  vmovaps xmm13, [rsp+0xC0]
000071ff71bd4248  vmovaps xmm14, [rsp+0xD0]
000071ff71bd4251  vmovaps xmm15, [rsp+0xE0]
000071ff71bd425a  add rsp, 0xF0
000071ff71bd4261  pop r11
000071ff71bd4263  pop r10
000071ff71bd4265  pop r9
000071ff71bd4267  pop r8
000071ff71bd4269  pop rsi
000071ff71bd426a  pop rdi
000071ff71bd426b  pop rdx
000071ff71bd426c  pop rcx
000071ff71bd426d  pop rax
000071ff71bd426e  add rsp, 0x08
000071ff71bd4272  jmp 0x000071FF71BD2962
000071ff71bd4277  sub rsp, 0x08
000071ff71bd427b  push rax
000071ff71bd427c  push rcx
000071ff71bd427d  push rdx
000071ff71bd427e  push rdi
000071ff71bd427f  push rsi
000071ff71bd4280  push r8
000071ff71bd4282  push r9
000071ff71bd4284  push r10
000071ff71bd4286  push r11
000071ff71bd4288  sub rsp, 0xF0
000071ff71bd428f  vmovaps [rsp], xmm0
000071ff71bd4294  vmovaps [rsp+0x10], xmm1
000071ff71bd429a  vmovaps [rsp+0x20], xmm2
000071ff71bd42a0  vmovaps [rsp+0x30], xmm3
000071ff71bd42a6  vmovaps [rsp+0x40], xmm4
000071ff71bd42ac  vmovaps [rsp+0x50], xmm5
000071ff71bd42b2  vmovaps [rsp+0x60], xmm6
000071ff71bd42b8  vmovaps [rsp+0x70], xmm7
000071ff71bd42be  vmovaps [rsp+0x80], xmm8
000071ff71bd42c7  vmovaps [rsp+0x90], xmm9
000071ff71bd42d0  vmovaps [rsp+0xA0], xmm10
000071ff71bd42d9  vmovaps [rsp+0xB0], xmm11
000071ff71bd42e2  vmovaps [rsp+0xC0], xmm12
000071ff71bd42eb  vmovaps [rsp+0xD0], xmm13
000071ff71bd42f4  vmovaps [rsp+0xE0], xmm15
000071ff71bd42fd  sub rsp, 0x30
000071ff71bd4301  movaps [rsp], xmm14
000071ff71bd4306  movaps [rsp+0x10], xmm10
000071ff71bd430c  movaps [rsp+0x20], xmm15
000071ff71bd4312  lea rdi, [rsp]
000071ff71bd4316  mov esi, 0x00
000071ff71bd431b  mov rax, 0x5E6872E10530
000071ff71bd4325  call rax
000071ff71bd4327  movaps xmm14, [rsp]
000071ff71bd432c  add rsp, 0x30
000071ff71bd4330  vmovaps xmm0, [rsp]
000071ff71bd4335  vmovaps xmm1, [rsp+0x10]
000071ff71bd433b  vmovaps xmm2, [rsp+0x20]
000071ff71bd4341  vmovaps xmm3, [rsp+0x30]
000071ff71bd4347  vmovaps xmm4, [rsp+0x40]
000071ff71bd434d  vmovaps xmm5, [rsp+0x50]
000071ff71bd4353  vmovaps xmm6, [rsp+0x60]
000071ff71bd4359  vmovaps xmm7, [rsp+0x70]
000071ff71bd435f  vmovaps xmm8, [rsp+0x80]
000071ff71bd4368  vmovaps xmm9, [rsp+0x90]
000071ff71bd4371  vmovaps xmm10, [rsp+0xA0]
000071ff71bd437a  vmovaps xmm11, [rsp+0xB0]
000071ff71bd4383  vmovaps xmm12, [rsp+0xC0]
000071ff71bd438c  vmovaps xmm13, [rsp+0xD0]
000071ff71bd4395  vmovaps xmm15, [rsp+0xE0]
000071ff71bd439e  add rsp, 0xF0
000071ff71bd43a5  pop r11
000071ff71bd43a7  pop r10
000071ff71bd43a9  pop r9
000071ff71bd43ab  pop r8
000071ff71bd43ad  pop rsi
000071ff71bd43ae  pop rdi
000071ff71bd43af  pop rdx
000071ff71bd43b0  pop rcx
000071ff71bd43b1  pop rax
000071ff71bd43b2  add rsp, 0x08
000071ff71bd43b6  jmp 0x000071FF71BD298E
000071ff71bd43bb  call 0x000071FF719FF430
000071ff71bd43c0  jmp 0x000071FF71BD2A1E
000071ff71bd43c5  call 0x000071FF719FF430
000071ff71bd43ca  jmp 0x000071FF71BD2A31
000071ff71bd43cf  sub rsp, 0x08
000071ff71bd43d3  push rax
000071ff71bd43d4  push rcx
000071ff71bd43d5  push rdx
000071ff71bd43d6  push rdi
000071ff71bd43d7  push rsi
000071ff71bd43d8  push r8
000071ff71bd43da  push r9
000071ff71bd43dc  push r10
000071ff71bd43de  push r11
000071ff71bd43e0  sub rsp, 0xF0
000071ff71bd43e7  vmovaps [rsp], xmm0
000071ff71bd43ec  vmovaps [rsp+0x10], xmm2
000071ff71bd43f2  vmovaps [rsp+0x20], xmm3
000071ff71bd43f8  vmovaps [rsp+0x30], xmm4
000071ff71bd43fe  vmovaps [rsp+0x40], xmm5
000071ff71bd4404  vmovaps [rsp+0x50], xmm6
000071ff71bd440a  vmovaps [rsp+0x60], xmm7
000071ff71bd4410  vmovaps [rsp+0x70], xmm8
000071ff71bd4416  vmovaps [rsp+0x80], xmm9
000071ff71bd441f  vmovaps [rsp+0x90], xmm10
000071ff71bd4428  vmovaps [rsp+0xA0], xmm11
000071ff71bd4431  vmovaps [rsp+0xB0], xmm12
000071ff71bd443a  vmovaps [rsp+0xC0], xmm13
000071ff71bd4443  vmovaps [rsp+0xD0], xmm14
000071ff71bd444c  vmovaps [rsp+0xE0], xmm15
000071ff71bd4455  sub rsp, 0x30
000071ff71bd4459  movaps [rsp], xmm1
000071ff71bd445d  movaps [rsp+0x10], xmm13
000071ff71bd4463  movaps [rsp+0x20], xmm2
000071ff71bd4468  lea rdi, [rsp]
000071ff71bd446c  mov esi, 0x00
000071ff71bd4471  mov rax, 0x5E6872E10530
000071ff71bd447b  call rax
000071ff71bd447d  movaps xmm1, [rsp]
000071ff71bd4481  add rsp, 0x30
000071ff71bd4485  vmovaps xmm0, [rsp]
000071ff71bd448a  vmovaps xmm2, [rsp+0x10]
000071ff71bd4490  vmovaps xmm3, [rsp+0x20]
000071ff71bd4496  vmovaps xmm4, [rsp+0x30]
000071ff71bd449c  vmovaps xmm5, [rsp+0x40]
000071ff71bd44a2  vmovaps xmm6, [rsp+0x50]
000071ff71bd44a8  vmovaps xmm7, [rsp+0x60]
000071ff71bd44ae  vmovaps xmm8, [rsp+0x70]
000071ff71bd44b4  vmovaps xmm9, [rsp+0x80]
000071ff71bd44bd  vmovaps xmm10, [rsp+0x90]
000071ff71bd44c6  vmovaps xmm11, [rsp+0xA0]
000071ff71bd44cf  vmovaps xmm12, [rsp+0xB0]
000071ff71bd44d8  vmovaps xmm13, [rsp+0xC0]
000071ff71bd44e1  vmovaps xmm14, [rsp+0xD0]
000071ff71bd44ea  vmovaps xmm15, [rsp+0xE0]
000071ff71bd44f3  add rsp, 0xF0
000071ff71bd44fa  pop r11
000071ff71bd44fc  pop r10
000071ff71bd44fe  pop r9
000071ff71bd4500  pop r8
000071ff71bd4502  pop rsi
000071ff71bd4503  pop rdi
000071ff71bd4504  pop rdx
000071ff71bd4505  pop rcx
000071ff71bd4506  pop rax
000071ff71bd4507  add rsp, 0x08
000071ff71bd450b  jmp 0x000071FF71BD2A5C
000071ff71bd4510  call 0x000071FF71A0E760
000071ff71bd4515  jmp 0x000071FF71BD2A69
000071ff71bd451a  sub rsp, 0x08
000071ff71bd451e  push rax
000071ff71bd451f  push rcx
000071ff71bd4520  push rdx
000071ff71bd4521  push rdi
000071ff71bd4522  push rsi
000071ff71bd4523  push r8
000071ff71bd4525  push r9
000071ff71bd4527  push r10
000071ff71bd4529  push r11
000071ff71bd452b  sub rsp, 0xF0
000071ff71bd4532  vmovaps [rsp], xmm0
000071ff71bd4537  vmovaps [rsp+0x10], xmm1
000071ff71bd453d  vmovaps [rsp+0x20], xmm2
000071ff71bd4543  vmovaps [rsp+0x30], xmm3
000071ff71bd4549  vmovaps [rsp+0x40], xmm4
000071ff71bd454f  vmovaps [rsp+0x50], xmm5
000071ff71bd4555  vmovaps [rsp+0x60], xmm6
000071ff71bd455b  vmovaps [rsp+0x70], xmm7
000071ff71bd4561  vmovaps [rsp+0x80], xmm8
000071ff71bd456a  vmovaps [rsp+0x90], xmm9
000071ff71bd4573  vmovaps [rsp+0xA0], xmm10
000071ff71bd457c  vmovaps [rsp+0xB0], xmm11
000071ff71bd4585  vmovaps [rsp+0xC0], xmm12
000071ff71bd458e  vmovaps [rsp+0xD0], xmm14
000071ff71bd4597  vmovaps [rsp+0xE0], xmm15
000071ff71bd45a0  sub rsp, 0x30
000071ff71bd45a4  movaps [rsp], xmm13
000071ff71bd45a9  movaps [rsp+0x10], xmm2
000071ff71bd45ae  movaps [rsp+0x20], xmm1
000071ff71bd45b3  lea rdi, [rsp]
000071ff71bd45b7  mov esi, 0x00
000071ff71bd45bc  mov rax, 0x5E6872E10530
000071ff71bd45c6  call rax
000071ff71bd45c8  movaps xmm13, [rsp]
000071ff71bd45cd  add rsp, 0x30
000071ff71bd45d1  vmovaps xmm0, [rsp]
000071ff71bd45d6  vmovaps xmm1, [rsp+0x10]
000071ff71bd45dc  vmovaps xmm2, [rsp+0x20]
000071ff71bd45e2  vmovaps xmm3, [rsp+0x30]
000071ff71bd45e8  vmovaps xmm4, [rsp+0x40]
000071ff71bd45ee  vmovaps xmm5, [rsp+0x50]
000071ff71bd45f4  vmovaps xmm6, [rsp+0x60]
000071ff71bd45fa  vmovaps xmm7, [rsp+0x70]
000071ff71bd4600  vmovaps xmm8, [rsp+0x80]
000071ff71bd4609  vmovaps xmm9, [rsp+0x90]
000071ff71bd4612  vmovaps xmm10, [rsp+0xA0]
000071ff71bd461b  vmovaps xmm11, [rsp+0xB0]
000071ff71bd4624  vmovaps xmm12, [rsp+0xC0]
000071ff71bd462d  vmovaps xmm14, [rsp+0xD0]
000071ff71bd4636  vmovaps xmm15, [rsp+0xE0]
000071ff71bd463f  add rsp, 0xF0
000071ff71bd4646  pop r11
000071ff71bd4648  pop r10
000071ff71bd464a  pop r9
000071ff71bd464c  pop r8
000071ff71bd464e  pop rsi
000071ff71bd464f  pop rdi
000071ff71bd4650  pop rdx
000071ff71bd4651  pop rcx
000071ff71bd4652  pop rax
000071ff71bd4653  add rsp, 0x08
000071ff71bd4657  jmp 0x000071FF71BD2AA8
000071ff71bd465c  sub rsp, 0x08
000071ff71bd4660  push rax
000071ff71bd4661  push rcx
000071ff71bd4662  push rdx
000071ff71bd4663  push rdi
000071ff71bd4664  push rsi
000071ff71bd4665  push r8
000071ff71bd4667  push r9
000071ff71bd4669  push r10
000071ff71bd466b  push r11
000071ff71bd466d  sub rsp, 0xF0
000071ff71bd4674  vmovaps [rsp], xmm0
000071ff71bd4679  vmovaps [rsp+0x10], xmm2
000071ff71bd467f  vmovaps [rsp+0x20], xmm3
000071ff71bd4685  vmovaps [rsp+0x30], xmm4
000071ff71bd468b  vmovaps [rsp+0x40], xmm5
000071ff71bd4691  vmovaps [rsp+0x50], xmm6
000071ff71bd4697  vmovaps [rsp+0x60], xmm7
000071ff71bd469d  vmovaps [rsp+0x70], xmm8
000071ff71bd46a3  vmovaps [rsp+0x80], xmm9
000071ff71bd46ac  vmovaps [rsp+0x90], xmm10
000071ff71bd46b5  vmovaps [rsp+0xA0], xmm11
000071ff71bd46be  vmovaps [rsp+0xB0], xmm12
000071ff71bd46c7  vmovaps [rsp+0xC0], xmm13
000071ff71bd46d0  vmovaps [rsp+0xD0], xmm14
000071ff71bd46d9  vmovaps [rsp+0xE0], xmm15
000071ff71bd46e2  sub rsp, 0x30
000071ff71bd46e6  movaps [rsp], xmm1
000071ff71bd46ea  movaps [rsp+0x10], xmm14
000071ff71bd46f0  movaps [rsp+0x20], xmm15
000071ff71bd46f6  lea rdi, [rsp]
000071ff71bd46fa  mov esi, 0x00
000071ff71bd46ff  mov rax, 0x5E6872E10530
000071ff71bd4709  call rax
000071ff71bd470b  movaps xmm1, [rsp]
000071ff71bd470f  add rsp, 0x30
000071ff71bd4713  vmovaps xmm0, [rsp]
000071ff71bd4718  vmovaps xmm2, [rsp+0x10]
000071ff71bd471e  vmovaps xmm3, [rsp+0x20]
000071ff71bd4724  vmovaps xmm4, [rsp+0x30]
000071ff71bd472a  vmovaps xmm5, [rsp+0x40]
000071ff71bd4730  vmovaps xmm6, [rsp+0x50]
000071ff71bd4736  vmovaps xmm7, [rsp+0x60]
000071ff71bd473c  vmovaps xmm8, [rsp+0x70]
000071ff71bd4742  vmovaps xmm9, [rsp+0x80]
000071ff71bd474b  vmovaps xmm10, [rsp+0x90]
000071ff71bd4754  vmovaps xmm11, [rsp+0xA0]
000071ff71bd475d  vmovaps xmm12, [rsp+0xB0]
000071ff71bd4766  vmovaps xmm13, [rsp+0xC0]
000071ff71bd476f  vmovaps xmm14, [rsp+0xD0]
000071ff71bd4778  vmovaps xmm15, [rsp+0xE0]
000071ff71bd4781  add rsp, 0xF0
000071ff71bd4788  pop r11
000071ff71bd478a  pop r10
000071ff71bd478c  pop r9
000071ff71bd478e  pop r8
000071ff71bd4790  pop rsi
000071ff71bd4791  pop rdi
000071ff71bd4792  pop rdx
000071ff71bd4793  pop rcx
000071ff71bd4794  pop rax
000071ff71bd4795  add rsp, 0x08
000071ff71bd4799  jmp 0x000071FF71BD2ACA
000071ff71bd479e  sub rsp, 0x08
000071ff71bd47a2  push rax
000071ff71bd47a3  push rcx
000071ff71bd47a4  push rdx
000071ff71bd47a5  push rdi
000071ff71bd47a6  push rsi
000071ff71bd47a7  push r8
000071ff71bd47a9  push r9
000071ff71bd47ab  push r10
000071ff71bd47ad  push r11
000071ff71bd47af  sub rsp, 0xF0
000071ff71bd47b6  vmovaps [rsp], xmm0
000071ff71bd47bb  vmovaps [rsp+0x10], xmm1
000071ff71bd47c1  vmovaps [rsp+0x20], xmm2
000071ff71bd47c7  vmovaps [rsp+0x30], xmm3
000071ff71bd47cd  vmovaps [rsp+0x40], xmm4
000071ff71bd47d3  vmovaps [rsp+0x50], xmm5
000071ff71bd47d9  vmovaps [rsp+0x60], xmm6
000071ff71bd47df  vmovaps [rsp+0x70], xmm7
000071ff71bd47e5  vmovaps [rsp+0x80], xmm8
000071ff71bd47ee  vmovaps [rsp+0x90], xmm9
000071ff71bd47f7  vmovaps [rsp+0xA0], xmm10
000071ff71bd4800  vmovaps [rsp+0xB0], xmm11
000071ff71bd4809  vmovaps [rsp+0xC0], xmm12
000071ff71bd4812  vmovaps [rsp+0xD0], xmm13
000071ff71bd481b  vmovaps [rsp+0xE0], xmm15
000071ff71bd4824  sub rsp, 0x30
000071ff71bd4828  movaps [rsp], xmm14
000071ff71bd482d  movaps [rsp+0x10], xmm2
000071ff71bd4832  movaps [rsp+0x20], xmm15
000071ff71bd4838  lea rdi, [rsp]
000071ff71bd483c  mov esi, 0x00
000071ff71bd4841  mov rax, 0x5E6872E10530
000071ff71bd484b  call rax
000071ff71bd484d  movaps xmm14, [rsp]
000071ff71bd4852  add rsp, 0x30
000071ff71bd4856  vmovaps xmm0, [rsp]
000071ff71bd485b  vmovaps xmm1, [rsp+0x10]
000071ff71bd4861  vmovaps xmm2, [rsp+0x20]
000071ff71bd4867  vmovaps xmm3, [rsp+0x30]
000071ff71bd486d  vmovaps xmm4, [rsp+0x40]
000071ff71bd4873  vmovaps xmm5, [rsp+0x50]
000071ff71bd4879  vmovaps xmm6, [rsp+0x60]
000071ff71bd487f  vmovaps xmm7, [rsp+0x70]
000071ff71bd4885  vmovaps xmm8, [rsp+0x80]
000071ff71bd488e  vmovaps xmm9, [rsp+0x90]
000071ff71bd4897  vmovaps xmm10, [rsp+0xA0]
000071ff71bd48a0  vmovaps xmm11, [rsp+0xB0]
000071ff71bd48a9  vmovaps xmm12, [rsp+0xC0]
000071ff71bd48b2  vmovaps xmm13, [rsp+0xD0]
000071ff71bd48bb  vmovaps xmm15, [rsp+0xE0]
000071ff71bd48c4  add rsp, 0xF0
000071ff71bd48cb  pop r11
000071ff71bd48cd  pop r10
000071ff71bd48cf  pop r9
000071ff71bd48d1  pop r8
000071ff71bd48d3  pop rsi
000071ff71bd48d4  pop rdi
000071ff71bd48d5  pop rdx
000071ff71bd48d6  pop rcx
000071ff71bd48d7  pop rax
000071ff71bd48d8  add rsp, 0x08
000071ff71bd48dc  jmp 0x000071FF71BD2B05
000071ff71bd48e1  sub rsp, 0x08
000071ff71bd48e5  push rax
000071ff71bd48e6  push rcx
000071ff71bd48e7  push rdx
000071ff71bd48e8  push rdi
000071ff71bd48e9  push rsi
000071ff71bd48ea  push r8
000071ff71bd48ec  push r9
000071ff71bd48ee  push r10
000071ff71bd48f0  push r11
000071ff71bd48f2  sub rsp, 0xF0
000071ff71bd48f9  vmovaps [rsp], xmm0
000071ff71bd48fe  vmovaps [rsp+0x10], xmm1
000071ff71bd4904  vmovaps [rsp+0x20], xmm2
000071ff71bd490a  vmovaps [rsp+0x30], xmm3
000071ff71bd4910  vmovaps [rsp+0x40], xmm4
000071ff71bd4916  vmovaps [rsp+0x50], xmm5
000071ff71bd491c  vmovaps [rsp+0x60], xmm6
000071ff71bd4922  vmovaps [rsp+0x70], xmm7
000071ff71bd4928  vmovaps [rsp+0x80], xmm8
000071ff71bd4931  vmovaps [rsp+0x90], xmm9
000071ff71bd493a  vmovaps [rsp+0xA0], xmm10
000071ff71bd4943  vmovaps [rsp+0xB0], xmm11
000071ff71bd494c  vmovaps [rsp+0xC0], xmm12
000071ff71bd4955  vmovaps [rsp+0xD0], xmm13
000071ff71bd495e  vmovaps [rsp+0xE0], xmm14
000071ff71bd4967  sub rsp, 0x30
000071ff71bd496b  movaps [rsp], xmm15
000071ff71bd4970  movaps [rsp+0x10], xmm2
000071ff71bd4975  movaps [rsp+0x20], xmm1
000071ff71bd497a  lea rdi, [rsp]
000071ff71bd497e  mov esi, 0x00
000071ff71bd4983  mov rax, 0x5E6872E10530
000071ff71bd498d  call rax
000071ff71bd498f  movaps xmm15, [rsp]
000071ff71bd4994  add rsp, 0x30
000071ff71bd4998  vmovaps xmm0, [rsp]
000071ff71bd499d  vmovaps xmm1, [rsp+0x10]
000071ff71bd49a3  vmovaps xmm2, [rsp+0x20]
000071ff71bd49a9  vmovaps xmm3, [rsp+0x30]
000071ff71bd49af  vmovaps xmm4, [rsp+0x40]
000071ff71bd49b5  vmovaps xmm5, [rsp+0x50]
000071ff71bd49bb  vmovaps xmm6, [rsp+0x60]
000071ff71bd49c1  vmovaps xmm7, [rsp+0x70]
000071ff71bd49c7  vmovaps xmm8, [rsp+0x80]
000071ff71bd49d0  vmovaps xmm9, [rsp+0x90]
000071ff71bd49d9  vmovaps xmm10, [rsp+0xA0]
000071ff71bd49e2  vmovaps xmm11, [rsp+0xB0]
000071ff71bd49eb  vmovaps xmm12, [rsp+0xC0]
000071ff71bd49f4  vmovaps xmm13, [rsp+0xD0]
000071ff71bd49fd  vmovaps xmm14, [rsp+0xE0]
000071ff71bd4a06  add rsp, 0xF0
000071ff71bd4a0d  pop r11
000071ff71bd4a0f  pop r10
000071ff71bd4a11  pop r9
000071ff71bd4a13  pop r8
000071ff71bd4a15  pop rsi
000071ff71bd4a16  pop rdi
000071ff71bd4a17  pop rdx
000071ff71bd4a18  pop rcx
000071ff71bd4a19  pop rax
000071ff71bd4a1a  add rsp, 0x08
000071ff71bd4a1e  jmp 0x000071FF71BD2B41
000071ff71bd4a23  call 0x000071FF719FF430
000071ff71bd4a28  jmp 0x000071FF71BD2B4E
000071ff71bd4a2d  sub rsp, 0x08
000071ff71bd4a31  push rax
000071ff71bd4a32  push rcx
000071ff71bd4a33  push rdx
000071ff71bd4a34  push rdi
000071ff71bd4a35  push rsi
000071ff71bd4a36  push r8
000071ff71bd4a38  push r9
000071ff71bd4a3a  push r10
000071ff71bd4a3c  push r11
000071ff71bd4a3e  sub rsp, 0xF0
000071ff71bd4a45  vmovaps [rsp], xmm0
000071ff71bd4a4a  vmovaps [rsp+0x10], xmm1
000071ff71bd4a50  vmovaps [rsp+0x20], xmm3
000071ff71bd4a56  vmovaps [rsp+0x30], xmm4
000071ff71bd4a5c  vmovaps [rsp+0x40], xmm5
000071ff71bd4a62  vmovaps [rsp+0x50], xmm6
000071ff71bd4a68  vmovaps [rsp+0x60], xmm7
000071ff71bd4a6e  vmovaps [rsp+0x70], xmm8
000071ff71bd4a74  vmovaps [rsp+0x80], xmm9
000071ff71bd4a7d  vmovaps [rsp+0x90], xmm10
000071ff71bd4a86  vmovaps [rsp+0xA0], xmm11
000071ff71bd4a8f  vmovaps [rsp+0xB0], xmm12
000071ff71bd4a98  vmovaps [rsp+0xC0], xmm13
000071ff71bd4aa1  vmovaps [rsp+0xD0], xmm14
000071ff71bd4aaa  vmovaps [rsp+0xE0], xmm15
000071ff71bd4ab3  sub rsp, 0x30
000071ff71bd4ab7  movaps [rsp], xmm2
000071ff71bd4abb  movaps [rsp+0x10], xmm1
000071ff71bd4ac0  movaps [rsp+0x20], xmm14
000071ff71bd4ac6  lea rdi, [rsp]
000071ff71bd4aca  mov esi, 0x00
000071ff71bd4acf  mov rax, 0x5E6872E10530
000071ff71bd4ad9  call rax
000071ff71bd4adb  movaps xmm2, [rsp]
000071ff71bd4adf  add rsp, 0x30
000071ff71bd4ae3  vmovaps xmm0, [rsp]
000071ff71bd4ae8  vmovaps xmm1, [rsp+0x10]
000071ff71bd4aee  vmovaps xmm3, [rsp+0x20]
000071ff71bd4af4  vmovaps xmm4, [rsp+0x30]
000071ff71bd4afa  vmovaps xmm5, [rsp+0x40]
000071ff71bd4b00  vmovaps xmm6, [rsp+0x50]
000071ff71bd4b06  vmovaps xmm7, [rsp+0x60]
000071ff71bd4b0c  vmovaps xmm8, [rsp+0x70]
000071ff71bd4b12  vmovaps xmm9, [rsp+0x80]
000071ff71bd4b1b  vmovaps xmm10, [rsp+0x90]
000071ff71bd4b24  vmovaps xmm11, [rsp+0xA0]
000071ff71bd4b2d  vmovaps xmm12, [rsp+0xB0]
000071ff71bd4b36  vmovaps xmm13, [rsp+0xC0]
000071ff71bd4b3f  vmovaps xmm14, [rsp+0xD0]
000071ff71bd4b48  vmovaps xmm15, [rsp+0xE0]
000071ff71bd4b51  add rsp, 0xF0
000071ff71bd4b58  pop r11
000071ff71bd4b5a  pop r10
000071ff71bd4b5c  pop r9
000071ff71bd4b5e  pop r8
000071ff71bd4b60  pop rsi
000071ff71bd4b61  pop rdi
000071ff71bd4b62  pop rdx
000071ff71bd4b63  pop rcx
000071ff71bd4b64  pop rax
000071ff71bd4b65  add rsp, 0x08
000071ff71bd4b69  jmp 0x000071FF71BD2B8B
000071ff71bd4b6e  sub rsp, 0x08
000071ff71bd4b72  push rax
000071ff71bd4b73  push rcx
000071ff71bd4b74  push rdx
000071ff71bd4b75  push rdi
000071ff71bd4b76  push rsi
000071ff71bd4b77  push r8
000071ff71bd4b79  push r9
000071ff71bd4b7b  push r10
000071ff71bd4b7d  push r11
000071ff71bd4b7f  sub rsp, 0xF0
000071ff71bd4b86  vmovaps [rsp], xmm0
000071ff71bd4b8b  vmovaps [rsp+0x10], xmm1
000071ff71bd4b91  vmovaps [rsp+0x20], xmm2
000071ff71bd4b97  vmovaps [rsp+0x30], xmm3
000071ff71bd4b9d  vmovaps [rsp+0x40], xmm4
000071ff71bd4ba3  vmovaps [rsp+0x50], xmm5
000071ff71bd4ba9  vmovaps [rsp+0x60], xmm6
000071ff71bd4baf  vmovaps [rsp+0x70], xmm7
000071ff71bd4bb5  vmovaps [rsp+0x80], xmm8
000071ff71bd4bbe  vmovaps [rsp+0x90], xmm9
000071ff71bd4bc7  vmovaps [rsp+0xA0], xmm10
000071ff71bd4bd0  vmovaps [rsp+0xB0], xmm11
000071ff71bd4bd9  vmovaps [rsp+0xC0], xmm12
000071ff71bd4be2  vmovaps [rsp+0xD0], xmm13
000071ff71bd4beb  vmovaps [rsp+0xE0], xmm14
000071ff71bd4bf4  sub rsp, 0x30
000071ff71bd4bf8  movaps [rsp], xmm15
000071ff71bd4bfd  movaps [rsp+0x10], xmm14
000071ff71bd4c03  movaps [rsp+0x20], xmm1
000071ff71bd4c08  lea rdi, [rsp]
000071ff71bd4c0c  mov esi, 0x00
000071ff71bd4c11  mov rax, 0x5E6872E10530
000071ff71bd4c1b  call rax
000071ff71bd4c1d  movaps xmm15, [rsp]
000071ff71bd4c22  add rsp, 0x30
000071ff71bd4c26  vmovaps xmm0, [rsp]
000071ff71bd4c2b  vmovaps xmm1, [rsp+0x10]
000071ff71bd4c31  vmovaps xmm2, [rsp+0x20]
000071ff71bd4c37  vmovaps xmm3, [rsp+0x30]
000071ff71bd4c3d  vmovaps xmm4, [rsp+0x40]
000071ff71bd4c43  vmovaps xmm5, [rsp+0x50]
000071ff71bd4c49  vmovaps xmm6, [rsp+0x60]
000071ff71bd4c4f  vmovaps xmm7, [rsp+0x70]
000071ff71bd4c55  vmovaps xmm8, [rsp+0x80]
000071ff71bd4c5e  vmovaps xmm9, [rsp+0x90]
000071ff71bd4c67  vmovaps xmm10, [rsp+0xA0]
000071ff71bd4c70  vmovaps xmm11, [rsp+0xB0]
000071ff71bd4c79  vmovaps xmm12, [rsp+0xC0]
000071ff71bd4c82  vmovaps xmm13, [rsp+0xD0]
000071ff71bd4c8b  vmovaps xmm14, [rsp+0xE0]
000071ff71bd4c94  add rsp, 0xF0
000071ff71bd4c9b  pop r11
000071ff71bd4c9d  pop r10
000071ff71bd4c9f  pop r9
000071ff71bd4ca1  pop r8
000071ff71bd4ca3  pop rsi
000071ff71bd4ca4  pop rdi
000071ff71bd4ca5  pop rdx
000071ff71bd4ca6  pop rcx
000071ff71bd4ca7  pop rax
000071ff71bd4ca8  add rsp, 0x08
000071ff71bd4cac  jmp 0x000071FF71BD2C05
000071ff71bd4cb1  call 0x000071FF719FF430
000071ff71bd4cb6  jmp 0x000071FF71BD2C12
000071ff71bd4cbb  sub rsp, 0x08
000071ff71bd4cbf  push rax
000071ff71bd4cc0  push rcx
000071ff71bd4cc1  push rdx
000071ff71bd4cc2  push rdi
000071ff71bd4cc3  push rsi
000071ff71bd4cc4  push r8
000071ff71bd4cc6  push r9
000071ff71bd4cc8  push r10
000071ff71bd4cca  push r11
000071ff71bd4ccc  sub rsp, 0xF0
000071ff71bd4cd3  vmovaps [rsp], xmm0
000071ff71bd4cd8  vmovaps [rsp+0x10], xmm1
000071ff71bd4cde  vmovaps [rsp+0x20], xmm2
000071ff71bd4ce4  vmovaps [rsp+0x30], xmm3
000071ff71bd4cea  vmovaps [rsp+0x40], xmm4
000071ff71bd4cf0  vmovaps [rsp+0x50], xmm5
000071ff71bd4cf6  vmovaps [rsp+0x60], xmm6
000071ff71bd4cfc  vmovaps [rsp+0x70], xmm7
000071ff71bd4d02  vmovaps [rsp+0x80], xmm8
000071ff71bd4d0b  vmovaps [rsp+0x90], xmm9
000071ff71bd4d14  vmovaps [rsp+0xA0], xmm10
000071ff71bd4d1d  vmovaps [rsp+0xB0], xmm11
000071ff71bd4d26  vmovaps [rsp+0xC0], xmm12
000071ff71bd4d2f  vmovaps [rsp+0xD0], xmm14
000071ff71bd4d38  vmovaps [rsp+0xE0], xmm15
000071ff71bd4d41  sub rsp, 0x30
000071ff71bd4d45  movaps [rsp], xmm13
000071ff71bd4d4a  movaps [rsp+0x10], xmm1
000071ff71bd4d4f  movaps [rsp+0x20], xmm15
000071ff71bd4d55  lea rdi, [rsp]
000071ff71bd4d59  mov esi, 0x00
000071ff71bd4d5e  mov rax, 0x5E6872E10530
000071ff71bd4d68  call rax
000071ff71bd4d6a  movaps xmm13, [rsp]
000071ff71bd4d6f  add rsp, 0x30
000071ff71bd4d73  vmovaps xmm0, [rsp]
000071ff71bd4d78  vmovaps xmm1, [rsp+0x10]
000071ff71bd4d7e  vmovaps xmm2, [rsp+0x20]
000071ff71bd4d84  vmovaps xmm3, [rsp+0x30]
000071ff71bd4d8a  vmovaps xmm4, [rsp+0x40]
000071ff71bd4d90  vmovaps xmm5, [rsp+0x50]
000071ff71bd4d96  vmovaps xmm6, [rsp+0x60]
000071ff71bd4d9c  vmovaps xmm7, [rsp+0x70]
000071ff71bd4da2  vmovaps xmm8, [rsp+0x80]
000071ff71bd4dab  vmovaps xmm9, [rsp+0x90]
000071ff71bd4db4  vmovaps xmm10, [rsp+0xA0]
000071ff71bd4dbd  vmovaps xmm11, [rsp+0xB0]
000071ff71bd4dc6  vmovaps xmm12, [rsp+0xC0]
000071ff71bd4dcf  vmovaps xmm14, [rsp+0xD0]
000071ff71bd4dd8  vmovaps xmm15, [rsp+0xE0]
000071ff71bd4de1  add rsp, 0xF0
000071ff71bd4de8  pop r11
000071ff71bd4dea  pop r10
000071ff71bd4dec  pop r9
000071ff71bd4dee  pop r8
000071ff71bd4df0  pop rsi
000071ff71bd4df1  pop rdi
000071ff71bd4df2  pop rdx
000071ff71bd4df3  pop rcx
000071ff71bd4df4  pop rax
000071ff71bd4df5  add rsp, 0x08
000071ff71bd4df9  jmp 0x000071FF71BD2CD6
000071ff71bd4dfe  sub rsp, 0x08
000071ff71bd4e02  push rax
000071ff71bd4e03  push rcx
000071ff71bd4e04  push rdx
000071ff71bd4e05  push rdi
000071ff71bd4e06  push rsi
000071ff71bd4e07  push r8
000071ff71bd4e09  push r9
000071ff71bd4e0b  push r10
000071ff71bd4e0d  push r11
000071ff71bd4e0f  sub rsp, 0xF0
000071ff71bd4e16  vmovaps [rsp], xmm0
000071ff71bd4e1b  vmovaps [rsp+0x10], xmm1
000071ff71bd4e21  vmovaps [rsp+0x20], xmm2
000071ff71bd4e27  vmovaps [rsp+0x30], xmm3
000071ff71bd4e2d  vmovaps [rsp+0x40], xmm4
000071ff71bd4e33  vmovaps [rsp+0x50], xmm5
000071ff71bd4e39  vmovaps [rsp+0x60], xmm6
000071ff71bd4e3f  vmovaps [rsp+0x70], xmm7
000071ff71bd4e45  vmovaps [rsp+0x80], xmm8
000071ff71bd4e4e  vmovaps [rsp+0x90], xmm9
000071ff71bd4e57  vmovaps [rsp+0xA0], xmm10
000071ff71bd4e60  vmovaps [rsp+0xB0], xmm11
000071ff71bd4e69  vmovaps [rsp+0xC0], xmm12
000071ff71bd4e72  vmovaps [rsp+0xD0], xmm13
000071ff71bd4e7b  vmovaps [rsp+0xE0], xmm14
000071ff71bd4e84  sub rsp, 0x30
000071ff71bd4e88  movaps [rsp], xmm15
000071ff71bd4e8d  movaps [rsp+0x10], xmm14
000071ff71bd4e93  movaps [rsp+0x20], xmm1
000071ff71bd4e98  lea rdi, [rsp]
000071ff71bd4e9c  mov esi, 0x00
000071ff71bd4ea1  mov rax, 0x5E6872E10530
000071ff71bd4eab  call rax
000071ff71bd4ead  movaps xmm15, [rsp]
000071ff71bd4eb2  add rsp, 0x30
000071ff71bd4eb6  vmovaps xmm0, [rsp]
000071ff71bd4ebb  vmovaps xmm1, [rsp+0x10]
000071ff71bd4ec1  vmovaps xmm2, [rsp+0x20]
000071ff71bd4ec7  vmovaps xmm3, [rsp+0x30]
000071ff71bd4ecd  vmovaps xmm4, [rsp+0x40]
000071ff71bd4ed3  vmovaps xmm5, [rsp+0x50]
000071ff71bd4ed9  vmovaps xmm6, [rsp+0x60]
000071ff71bd4edf  vmovaps xmm7, [rsp+0x70]
000071ff71bd4ee5  vmovaps xmm8, [rsp+0x80]
000071ff71bd4eee  vmovaps xmm9, [rsp+0x90]
000071ff71bd4ef7  vmovaps xmm10, [rsp+0xA0]
000071ff71bd4f00  vmovaps xmm11, [rsp+0xB0]
000071ff71bd4f09  vmovaps xmm12, [rsp+0xC0]
000071ff71bd4f12  vmovaps xmm13, [rsp+0xD0]
000071ff71bd4f1b  vmovaps xmm14, [rsp+0xE0]
000071ff71bd4f24  add rsp, 0xF0
000071ff71bd4f2b  pop r11
000071ff71bd4f2d  pop r10
000071ff71bd4f2f  pop r9
000071ff71bd4f31  pop r8
000071ff71bd4f33  pop rsi
000071ff71bd4f34  pop rdi
000071ff71bd4f35  pop rdx
000071ff71bd4f36  pop rcx
000071ff71bd4f37  pop rax
000071ff71bd4f38  add rsp, 0x08
000071ff71bd4f3c  jmp 0x000071FF71BD2D12
000071ff71bd4f41  call 0x000071FF719FF430
000071ff71bd4f46  jmp 0x000071FF71BD2D1F
000071ff71bd4f4b  sub rsp, 0x08
000071ff71bd4f4f  push rax
000071ff71bd4f50  push rcx
000071ff71bd4f51  push rdx
000071ff71bd4f52  push rdi
000071ff71bd4f53  push rsi
000071ff71bd4f54  push r8
000071ff71bd4f56  push r9
000071ff71bd4f58  push r10
000071ff71bd4f5a  push r11
000071ff71bd4f5c  sub rsp, 0xF0
000071ff71bd4f63  vmovaps [rsp], xmm0
000071ff71bd4f68  vmovaps [rsp+0x10], xmm1
000071ff71bd4f6e  vmovaps [rsp+0x20], xmm2
000071ff71bd4f74  vmovaps [rsp+0x30], xmm3
000071ff71bd4f7a  vmovaps [rsp+0x40], xmm4
000071ff71bd4f80  vmovaps [rsp+0x50], xmm5
000071ff71bd4f86  vmovaps [rsp+0x60], xmm6
000071ff71bd4f8c  vmovaps [rsp+0x70], xmm7
000071ff71bd4f92  vmovaps [rsp+0x80], xmm8
000071ff71bd4f9b  vmovaps [rsp+0x90], xmm9
000071ff71bd4fa4  vmovaps [rsp+0xA0], xmm10
000071ff71bd4fad  vmovaps [rsp+0xB0], xmm11
000071ff71bd4fb6  vmovaps [rsp+0xC0], xmm12
000071ff71bd4fbf  vmovaps [rsp+0xD0], xmm13
000071ff71bd4fc8  vmovaps [rsp+0xE0], xmm15
000071ff71bd4fd1  sub rsp, 0x30
000071ff71bd4fd5  movaps [rsp], xmm14
000071ff71bd4fda  movaps [rsp+0x10], xmm13
000071ff71bd4fe0  movaps [rsp+0x20], xmm2
000071ff71bd4fe5  lea rdi, [rsp]
000071ff71bd4fe9  mov esi, 0x00
000071ff71bd4fee  mov rax, 0x5E6872E10530
000071ff71bd4ff8  call rax
000071ff71bd4ffa  movaps xmm14, [rsp]
000071ff71bd4fff  add rsp, 0x30
000071ff71bd5003  vmovaps xmm0, [rsp]
000071ff71bd5008  vmovaps xmm1, [rsp+0x10]
000071ff71bd500e  vmovaps xmm2, [rsp+0x20]
000071ff71bd5014  vmovaps xmm3, [rsp+0x30]
000071ff71bd501a  vmovaps xmm4, [rsp+0x40]
000071ff71bd5020  vmovaps xmm5, [rsp+0x50]
000071ff71bd5026  vmovaps xmm6, [rsp+0x60]
000071ff71bd502c  vmovaps xmm7, [rsp+0x70]
000071ff71bd5032  vmovaps xmm8, [rsp+0x80]
000071ff71bd503b  vmovaps xmm9, [rsp+0x90]
000071ff71bd5044  vmovaps xmm10, [rsp+0xA0]
000071ff71bd504d  vmovaps xmm11, [rsp+0xB0]
000071ff71bd5056  vmovaps xmm12, [rsp+0xC0]
000071ff71bd505f  vmovaps xmm13, [rsp+0xD0]
000071ff71bd5068  vmovaps xmm15, [rsp+0xE0]
000071ff71bd5071  add rsp, 0xF0
000071ff71bd5078  pop r11
000071ff71bd507a  pop r10
000071ff71bd507c  pop r9
000071ff71bd507e  pop r8
000071ff71bd5080  pop rsi
000071ff71bd5081  pop rdi
000071ff71bd5082  pop rdx
000071ff71bd5083  pop rcx
000071ff71bd5084  pop rax
000071ff71bd5085  add rsp, 0x08
000071ff71bd5089  jmp 0x000071FF71BD2D4B
000071ff71bd508e  sub rsp, 0x08
000071ff71bd5092  push rax
000071ff71bd5093  push rcx
000071ff71bd5094  push rdx
000071ff71bd5095  push rdi
000071ff71bd5096  push rsi
000071ff71bd5097  push r8
000071ff71bd5099  push r9
000071ff71bd509b  push r10
000071ff71bd509d  push r11
000071ff71bd509f  sub rsp, 0xF0
000071ff71bd50a6  vmovaps [rsp], xmm0
000071ff71bd50ab  vmovaps [rsp+0x10], xmm2
000071ff71bd50b1  vmovaps [rsp+0x20], xmm3
000071ff71bd50b7  vmovaps [rsp+0x30], xmm4
000071ff71bd50bd  vmovaps [rsp+0x40], xmm5
000071ff71bd50c3  vmovaps [rsp+0x50], xmm6
000071ff71bd50c9  vmovaps [rsp+0x60], xmm7
000071ff71bd50cf  vmovaps [rsp+0x70], xmm8
000071ff71bd50d5  vmovaps [rsp+0x80], xmm9
000071ff71bd50de  vmovaps [rsp+0x90], xmm10
000071ff71bd50e7  vmovaps [rsp+0xA0], xmm11
000071ff71bd50f0  vmovaps [rsp+0xB0], xmm12
000071ff71bd50f9  vmovaps [rsp+0xC0], xmm13
000071ff71bd5102  vmovaps [rsp+0xD0], xmm14
000071ff71bd510b  vmovaps [rsp+0xE0], xmm15
000071ff71bd5114  sub rsp, 0x30
000071ff71bd5118  movaps [rsp], xmm1
000071ff71bd511c  movaps [rsp+0x10], xmm13
000071ff71bd5122  movaps [rsp+0x20], xmm2
000071ff71bd5127  lea rdi, [rsp]
000071ff71bd512b  mov esi, 0x00
000071ff71bd5130  mov rax, 0x5E6872E10530
000071ff71bd513a  call rax
000071ff71bd513c  movaps xmm1, [rsp]
000071ff71bd5140  add rsp, 0x30
000071ff71bd5144  vmovaps xmm0, [rsp]
000071ff71bd5149  vmovaps xmm2, [rsp+0x10]
000071ff71bd514f  vmovaps xmm3, [rsp+0x20]
000071ff71bd5155  vmovaps xmm4, [rsp+0x30]
000071ff71bd515b  vmovaps xmm5, [rsp+0x40]
000071ff71bd5161  vmovaps xmm6, [rsp+0x50]
000071ff71bd5167  vmovaps xmm7, [rsp+0x60]
000071ff71bd516d  vmovaps xmm8, [rsp+0x70]
000071ff71bd5173  vmovaps xmm9, [rsp+0x80]
000071ff71bd517c  vmovaps xmm10, [rsp+0x90]
000071ff71bd5185  vmovaps xmm11, [rsp+0xA0]
000071ff71bd518e  vmovaps xmm12, [rsp+0xB0]
000071ff71bd5197  vmovaps xmm13, [rsp+0xC0]
000071ff71bd51a0  vmovaps xmm14, [rsp+0xD0]
000071ff71bd51a9  vmovaps xmm15, [rsp+0xE0]
000071ff71bd51b2  add rsp, 0xF0
000071ff71bd51b9  pop r11
000071ff71bd51bb  pop r10
000071ff71bd51bd  pop r9
000071ff71bd51bf  pop r8
000071ff71bd51c1  pop rsi
000071ff71bd51c2  pop rdi
000071ff71bd51c3  pop rdx
000071ff71bd51c4  pop rcx
000071ff71bd51c5  pop rax
000071ff71bd51c6  add rsp, 0x08
000071ff71bd51ca  jmp 0x000071FF71BD2D79
000071ff71bd51cf  sub rsp, 0x08
000071ff71bd51d3  push rax
000071ff71bd51d4  push rcx
000071ff71bd51d5  push rdx
000071ff71bd51d6  push rdi
000071ff71bd51d7  push rsi
000071ff71bd51d8  push r8
000071ff71bd51da  push r9
000071ff71bd51dc  push r10
000071ff71bd51de  push r11
000071ff71bd51e0  sub rsp, 0xF0
000071ff71bd51e7  vmovaps [rsp], xmm0
000071ff71bd51ec  vmovaps [rsp+0x10], xmm1
000071ff71bd51f2  vmovaps [rsp+0x20], xmm3
000071ff71bd51f8  vmovaps [rsp+0x30], xmm4
000071ff71bd51fe  vmovaps [rsp+0x40], xmm5
000071ff71bd5204  vmovaps [rsp+0x50], xmm6
000071ff71bd520a  vmovaps [rsp+0x60], xmm7
000071ff71bd5210  vmovaps [rsp+0x70], xmm8
000071ff71bd5216  vmovaps [rsp+0x80], xmm9
000071ff71bd521f  vmovaps [rsp+0x90], xmm10
000071ff71bd5228  vmovaps [rsp+0xA0], xmm11
000071ff71bd5231  vmovaps [rsp+0xB0], xmm12
000071ff71bd523a  vmovaps [rsp+0xC0], xmm13
000071ff71bd5243  vmovaps [rsp+0xD0], xmm14
000071ff71bd524c  vmovaps [rsp+0xE0], xmm15
000071ff71bd5255  sub rsp, 0x30
000071ff71bd5259  movaps [rsp], xmm2
000071ff71bd525d  movaps [rsp+0x10], xmm1
000071ff71bd5262  movaps [rsp+0x20], xmm13
000071ff71bd5268  lea rdi, [rsp]
000071ff71bd526c  mov esi, 0x00
000071ff71bd5271  mov rax, 0x5E6872E10530
000071ff71bd527b  call rax
000071ff71bd527d  movaps xmm2, [rsp]
000071ff71bd5281  add rsp, 0x30
000071ff71bd5285  vmovaps xmm0, [rsp]
000071ff71bd528a  vmovaps xmm1, [rsp+0x10]
000071ff71bd5290  vmovaps xmm3, [rsp+0x20]
000071ff71bd5296  vmovaps xmm4, [rsp+0x30]
000071ff71bd529c  vmovaps xmm5, [rsp+0x40]
000071ff71bd52a2  vmovaps xmm6, [rsp+0x50]
000071ff71bd52a8  vmovaps xmm7, [rsp+0x60]
000071ff71bd52ae  vmovaps xmm8, [rsp+0x70]
000071ff71bd52b4  vmovaps xmm9, [rsp+0x80]
000071ff71bd52bd  vmovaps xmm10, [rsp+0x90]
000071ff71bd52c6  vmovaps xmm11, [rsp+0xA0]
000071ff71bd52cf  vmovaps xmm12, [rsp+0xB0]
000071ff71bd52d8  vmovaps xmm13, [rsp+0xC0]
000071ff71bd52e1  vmovaps xmm14, [rsp+0xD0]
000071ff71bd52ea  vmovaps xmm15, [rsp+0xE0]
000071ff71bd52f3  add rsp, 0xF0
000071ff71bd52fa  pop r11
000071ff71bd52fc  pop r10
000071ff71bd52fe  pop r9
000071ff71bd5300  pop r8
000071ff71bd5302  pop rsi
000071ff71bd5303  pop rdi
000071ff71bd5304  pop rdx
000071ff71bd5305  pop rcx
000071ff71bd5306  pop rax
000071ff71bd5307  add rsp, 0x08
000071ff71bd530b  jmp 0x000071FF71BD2DD2
000071ff71bd5310  call 0x000071FF719FF430
000071ff71bd5315  jmp 0x000071FF71BD2DDF
000071ff71bd531a  sub rsp, 0x08
000071ff71bd531e  push rax
000071ff71bd531f  push rcx
000071ff71bd5320  push rdx
000071ff71bd5321  push rdi
000071ff71bd5322  push rsi
000071ff71bd5323  push r8
000071ff71bd5325  push r9
000071ff71bd5327  push r10
000071ff71bd5329  push r11
000071ff71bd532b  sub rsp, 0xF0
000071ff71bd5332  vmovaps [rsp], xmm0
000071ff71bd5337  vmovaps [rsp+0x10], xmm1
000071ff71bd533d  vmovaps [rsp+0x20], xmm2
000071ff71bd5343  vmovaps [rsp+0x30], xmm3
000071ff71bd5349  vmovaps [rsp+0x40], xmm4
000071ff71bd534f  vmovaps [rsp+0x50], xmm5
000071ff71bd5355  vmovaps [rsp+0x60], xmm6
000071ff71bd535b  vmovaps [rsp+0x70], xmm7
000071ff71bd5361  vmovaps [rsp+0x80], xmm8
000071ff71bd536a  vmovaps [rsp+0x90], xmm9
000071ff71bd5373  vmovaps [rsp+0xA0], xmm10
000071ff71bd537c  vmovaps [rsp+0xB0], xmm11
000071ff71bd5385  vmovaps [rsp+0xC0], xmm12
000071ff71bd538e  vmovaps [rsp+0xD0], xmm13
000071ff71bd5397  vmovaps [rsp+0xE0], xmm14
000071ff71bd53a0  sub rsp, 0x30
000071ff71bd53a4  movaps [rsp], xmm15
000071ff71bd53a9  movaps [rsp+0x10], xmm13
000071ff71bd53af  movaps [rsp+0x20], xmm1
000071ff71bd53b4  lea rdi, [rsp]
000071ff71bd53b8  mov esi, 0x00
000071ff71bd53bd  mov rax, 0x5E6872E10530
000071ff71bd53c7  call rax
000071ff71bd53c9  movaps xmm15, [rsp]
000071ff71bd53ce  add rsp, 0x30
000071ff71bd53d2  vmovaps xmm0, [rsp]
000071ff71bd53d7  vmovaps xmm1, [rsp+0x10]
000071ff71bd53dd  vmovaps xmm2, [rsp+0x20]
000071ff71bd53e3  vmovaps xmm3, [rsp+0x30]
000071ff71bd53e9  vmovaps xmm4, [rsp+0x40]
000071ff71bd53ef  vmovaps xmm5, [rsp+0x50]
000071ff71bd53f5  vmovaps xmm6, [rsp+0x60]
000071ff71bd53fb  vmovaps xmm7, [rsp+0x70]
000071ff71bd5401  vmovaps xmm8, [rsp+0x80]
000071ff71bd540a  vmovaps xmm9, [rsp+0x90]
000071ff71bd5413  vmovaps xmm10, [rsp+0xA0]
000071ff71bd541c  vmovaps xmm11, [rsp+0xB0]
000071ff71bd5425  vmovaps xmm12, [rsp+0xC0]
000071ff71bd542e  vmovaps xmm13, [rsp+0xD0]
000071ff71bd5437  vmovaps xmm14, [rsp+0xE0]
000071ff71bd5440  add rsp, 0xF0
000071ff71bd5447  pop r11
000071ff71bd5449  pop r10
000071ff71bd544b  pop r9
000071ff71bd544d  pop r8
000071ff71bd544f  pop rsi
000071ff71bd5450  pop rdi
000071ff71bd5451  pop rdx
000071ff71bd5452  pop rcx
000071ff71bd5453  pop rax
000071ff71bd5454  add rsp, 0x08
000071ff71bd5458  jmp 0x000071FF71BD2E1E
000071ff71bd545d  sub rsp, 0x08
000071ff71bd5461  push rax
000071ff71bd5462  push rcx
000071ff71bd5463  push rdx
000071ff71bd5464  push rdi
000071ff71bd5465  push rsi
000071ff71bd5466  push r8
000071ff71bd5468  push r9
000071ff71bd546a  push r10
000071ff71bd546c  push r11
000071ff71bd546e  sub rsp, 0xF0
000071ff71bd5475  vmovaps [rsp], xmm0
000071ff71bd547a  vmovaps [rsp+0x10], xmm1
000071ff71bd5480  vmovaps [rsp+0x20], xmm2
000071ff71bd5486  vmovaps [rsp+0x30], xmm3
000071ff71bd548c  vmovaps [rsp+0x40], xmm4
000071ff71bd5492  vmovaps [rsp+0x50], xmm5
000071ff71bd5498  vmovaps [rsp+0x60], xmm6
000071ff71bd549e  vmovaps [rsp+0x70], xmm7
000071ff71bd54a4  vmovaps [rsp+0x80], xmm8
000071ff71bd54ad  vmovaps [rsp+0x90], xmm9
000071ff71bd54b6  vmovaps [rsp+0xA0], xmm10
000071ff71bd54bf  vmovaps [rsp+0xB0], xmm11
000071ff71bd54c8  vmovaps [rsp+0xC0], xmm12
000071ff71bd54d1  vmovaps [rsp+0xD0], xmm13
000071ff71bd54da  vmovaps [rsp+0xE0], xmm15
000071ff71bd54e3  sub rsp, 0x30
000071ff71bd54e7  movaps [rsp], xmm14
000071ff71bd54ec  movaps [rsp+0x10], xmm11
000071ff71bd54f2  movaps [rsp+0x20], xmm1
000071ff71bd54f7  lea rdi, [rsp]
000071ff71bd54fb  mov esi, 0x00
000071ff71bd5500  mov rax, 0x5E6872E10530
000071ff71bd550a  call rax
000071ff71bd550c  movaps xmm14, [rsp]
000071ff71bd5511  add rsp, 0x30
000071ff71bd5515  vmovaps xmm0, [rsp]
000071ff71bd551a  vmovaps xmm1, [rsp+0x10]
000071ff71bd5520  vmovaps xmm2, [rsp+0x20]
000071ff71bd5526  vmovaps xmm3, [rsp+0x30]
000071ff71bd552c  vmovaps xmm4, [rsp+0x40]
000071ff71bd5532  vmovaps xmm5, [rsp+0x50]
000071ff71bd5538  vmovaps xmm6, [rsp+0x60]
000071ff71bd553e  vmovaps xmm7, [rsp+0x70]
000071ff71bd5544  vmovaps xmm8, [rsp+0x80]
000071ff71bd554d  vmovaps xmm9, [rsp+0x90]
000071ff71bd5556  vmovaps xmm10, [rsp+0xA0]
000071ff71bd555f  vmovaps xmm11, [rsp+0xB0]
000071ff71bd5568  vmovaps xmm12, [rsp+0xC0]
000071ff71bd5571  vmovaps xmm13, [rsp+0xD0]
000071ff71bd557a  vmovaps xmm15, [rsp+0xE0]
000071ff71bd5583  add rsp, 0xF0
000071ff71bd558a  pop r11
000071ff71bd558c  pop r10
000071ff71bd558e  pop r9
000071ff71bd5590  pop r8
000071ff71bd5592  pop rsi
000071ff71bd5593  pop rdi
000071ff71bd5594  pop rdx
000071ff71bd5595  pop rcx
000071ff71bd5596  pop rax
000071ff71bd5597  add rsp, 0x08
000071ff71bd559b  jmp 0x000071FF71BD2E48
000071ff71bd55a0  sub rsp, 0x08
000071ff71bd55a4  push rax
000071ff71bd55a5  push rcx
000071ff71bd55a6  push rdx
000071ff71bd55a7  push rdi
000071ff71bd55a8  push rsi
000071ff71bd55a9  push r8
000071ff71bd55ab  push r9
000071ff71bd55ad  push r10
000071ff71bd55af  push r11
000071ff71bd55b1  sub rsp, 0xF0
000071ff71bd55b8  vmovaps [rsp], xmm0
000071ff71bd55bd  vmovaps [rsp+0x10], xmm1
000071ff71bd55c3  vmovaps [rsp+0x20], xmm2
000071ff71bd55c9  vmovaps [rsp+0x30], xmm3
000071ff71bd55cf  vmovaps [rsp+0x40], xmm4
000071ff71bd55d5  vmovaps [rsp+0x50], xmm5
000071ff71bd55db  vmovaps [rsp+0x60], xmm6
000071ff71bd55e1  vmovaps [rsp+0x70], xmm7
000071ff71bd55e7  vmovaps [rsp+0x80], xmm8
000071ff71bd55f0  vmovaps [rsp+0x90], xmm9
000071ff71bd55f9  vmovaps [rsp+0xA0], xmm10
000071ff71bd5602  vmovaps [rsp+0xB0], xmm11
000071ff71bd560b  vmovaps [rsp+0xC0], xmm12
000071ff71bd5614  vmovaps [rsp+0xD0], xmm14
000071ff71bd561d  vmovaps [rsp+0xE0], xmm15
000071ff71bd5626  sub rsp, 0x30
000071ff71bd562a  movaps [rsp], xmm13
000071ff71bd562f  movaps [rsp+0x10], xmm11
000071ff71bd5635  movaps [rsp+0x20], xmm1
000071ff71bd563a  lea rdi, [rsp]
000071ff71bd563e  mov esi, 0x00
000071ff71bd5643  mov rax, 0x5E6872E10530
000071ff71bd564d  call rax
000071ff71bd564f  movaps xmm13, [rsp]
000071ff71bd5654  add rsp, 0x30
000071ff71bd5658  vmovaps xmm0, [rsp]
000071ff71bd565d  vmovaps xmm1, [rsp+0x10]
000071ff71bd5663  vmovaps xmm2, [rsp+0x20]
000071ff71bd5669  vmovaps xmm3, [rsp+0x30]
000071ff71bd566f  vmovaps xmm4, [rsp+0x40]
000071ff71bd5675  vmovaps xmm5, [rsp+0x50]
000071ff71bd567b  vmovaps xmm6, [rsp+0x60]
000071ff71bd5681  vmovaps xmm7, [rsp+0x70]
000071ff71bd5687  vmovaps xmm8, [rsp+0x80]
000071ff71bd5690  vmovaps xmm9, [rsp+0x90]
000071ff71bd5699  vmovaps xmm10, [rsp+0xA0]
000071ff71bd56a2  vmovaps xmm11, [rsp+0xB0]
000071ff71bd56ab  vmovaps xmm12, [rsp+0xC0]
000071ff71bd56b4  vmovaps xmm14, [rsp+0xD0]
000071ff71bd56bd  vmovaps xmm15, [rsp+0xE0]
000071ff71bd56c6  add rsp, 0xF0
000071ff71bd56cd  pop r11
000071ff71bd56cf  pop r10
000071ff71bd56d1  pop r9
000071ff71bd56d3  pop r8
000071ff71bd56d5  pop rsi
000071ff71bd56d6  pop rdi
000071ff71bd56d7  pop rdx
000071ff71bd56d8  pop rcx
000071ff71bd56d9  pop rax
000071ff71bd56da  add rsp, 0x08
000071ff71bd56de  jmp 0x000071FF71BD2E9D
000071ff71bd56e3  call 0x000071FF719FF430
000071ff71bd56e8  jmp 0x000071FF71BD2EAA
000071ff71bd56ed  sub rsp, 0x08
000071ff71bd56f1  push rax
000071ff71bd56f2  push rcx
000071ff71bd56f3  push rdx
000071ff71bd56f4  push rdi
000071ff71bd56f5  push rsi
000071ff71bd56f6  push r8
000071ff71bd56f8  push r9
000071ff71bd56fa  push r10
000071ff71bd56fc  push r11
000071ff71bd56fe  sub rsp, 0xF0
000071ff71bd5705  vmovaps [rsp], xmm0
000071ff71bd570a  vmovaps [rsp+0x10], xmm1
000071ff71bd5710  vmovaps [rsp+0x20], xmm2
000071ff71bd5716  vmovaps [rsp+0x30], xmm3
000071ff71bd571c  vmovaps [rsp+0x40], xmm4
000071ff71bd5722  vmovaps [rsp+0x50], xmm5
000071ff71bd5728  vmovaps [rsp+0x60], xmm6
000071ff71bd572e  vmovaps [rsp+0x70], xmm7
000071ff71bd5734  vmovaps [rsp+0x80], xmm8
000071ff71bd573d  vmovaps [rsp+0x90], xmm9
000071ff71bd5746  vmovaps [rsp+0xA0], xmm10
000071ff71bd574f  vmovaps [rsp+0xB0], xmm11
000071ff71bd5758  vmovaps [rsp+0xC0], xmm12
000071ff71bd5761  vmovaps [rsp+0xD0], xmm13
000071ff71bd576a  vmovaps [rsp+0xE0], xmm14
000071ff71bd5773  sub rsp, 0x30
000071ff71bd5777  movaps [rsp], xmm15
000071ff71bd577c  movaps [rsp+0x10], xmm11
000071ff71bd5782  movaps [rsp+0x20], xmm1
000071ff71bd5787  lea rdi, [rsp]
000071ff71bd578b  mov esi, 0x00
000071ff71bd5790  mov rax, 0x5E6872E10530
000071ff71bd579a  call rax
000071ff71bd579c  movaps xmm15, [rsp]
000071ff71bd57a1  add rsp, 0x30
000071ff71bd57a5  vmovaps xmm0, [rsp]
000071ff71bd57aa  vmovaps xmm1, [rsp+0x10]
000071ff71bd57b0  vmovaps xmm2, [rsp+0x20]
000071ff71bd57b6  vmovaps xmm3, [rsp+0x30]
000071ff71bd57bc  vmovaps xmm4, [rsp+0x40]
000071ff71bd57c2  vmovaps xmm5, [rsp+0x50]
000071ff71bd57c8  vmovaps xmm6, [rsp+0x60]
000071ff71bd57ce  vmovaps xmm7, [rsp+0x70]
000071ff71bd57d4  vmovaps xmm8, [rsp+0x80]
000071ff71bd57dd  vmovaps xmm9, [rsp+0x90]
000071ff71bd57e6  vmovaps xmm10, [rsp+0xA0]
000071ff71bd57ef  vmovaps xmm11, [rsp+0xB0]
000071ff71bd57f8  vmovaps xmm12, [rsp+0xC0]
000071ff71bd5801  vmovaps xmm13, [rsp+0xD0]
000071ff71bd580a  vmovaps xmm14, [rsp+0xE0]
000071ff71bd5813  add rsp, 0xF0
000071ff71bd581a  pop r11
000071ff71bd581c  pop r10
000071ff71bd581e  pop r9
000071ff71bd5820  pop r8
000071ff71bd5822  pop rsi
000071ff71bd5823  pop rdi
000071ff71bd5824  pop rdx
000071ff71bd5825  pop rcx
000071ff71bd5826  pop rax
000071ff71bd5827  add rsp, 0x08
000071ff71bd582b  jmp 0x000071FF71BD2EE3
000071ff71bd5830  sub rsp, 0x08
000071ff71bd5834  push rax
000071ff71bd5835  push rcx
000071ff71bd5836  push rdx
000071ff71bd5837  push rdi
000071ff71bd5838  push rsi
000071ff71bd5839  push r8
000071ff71bd583b  push r9
000071ff71bd583d  push r10
000071ff71bd583f  push r11
000071ff71bd5841  sub rsp, 0xF0
000071ff71bd5848  vmovaps [rsp], xmm0
000071ff71bd584d  vmovaps [rsp+0x10], xmm1
000071ff71bd5853  vmovaps [rsp+0x20], xmm2
000071ff71bd5859  vmovaps [rsp+0x30], xmm3
000071ff71bd585f  vmovaps [rsp+0x40], xmm4
000071ff71bd5865  vmovaps [rsp+0x50], xmm5
000071ff71bd586b  vmovaps [rsp+0x60], xmm6
000071ff71bd5871  vmovaps [rsp+0x70], xmm7
000071ff71bd5877  vmovaps [rsp+0x80], xmm8
000071ff71bd5880  vmovaps [rsp+0x90], xmm9
000071ff71bd5889  vmovaps [rsp+0xA0], xmm10
000071ff71bd5892  vmovaps [rsp+0xB0], xmm12
000071ff71bd589b  vmovaps [rsp+0xC0], xmm13
000071ff71bd58a4  vmovaps [rsp+0xD0], xmm14
000071ff71bd58ad  vmovaps [rsp+0xE0], xmm15
000071ff71bd58b6  sub rsp, 0x30
000071ff71bd58ba  movaps [rsp], xmm11
000071ff71bd58bf  movaps [rsp+0x10], xmm6
000071ff71bd58c4  movaps [rsp+0x20], xmm14
000071ff71bd58ca  lea rdi, [rsp]
000071ff71bd58ce  mov esi, 0x00
000071ff71bd58d3  mov rax, 0x5E6872E10530
000071ff71bd58dd  call rax
000071ff71bd58df  movaps xmm11, [rsp]
000071ff71bd58e4  add rsp, 0x30
000071ff71bd58e8  vmovaps xmm0, [rsp]
000071ff71bd58ed  vmovaps xmm1, [rsp+0x10]
000071ff71bd58f3  vmovaps xmm2, [rsp+0x20]
000071ff71bd58f9  vmovaps xmm3, [rsp+0x30]
000071ff71bd58ff  vmovaps xmm4, [rsp+0x40]
000071ff71bd5905  vmovaps xmm5, [rsp+0x50]
000071ff71bd590b  vmovaps xmm6, [rsp+0x60]
000071ff71bd5911  vmovaps xmm7, [rsp+0x70]
000071ff71bd5917  vmovaps xmm8, [rsp+0x80]
000071ff71bd5920  vmovaps xmm9, [rsp+0x90]
000071ff71bd5929  vmovaps xmm10, [rsp+0xA0]
000071ff71bd5932  vmovaps xmm12, [rsp+0xB0]
000071ff71bd593b  vmovaps xmm13, [rsp+0xC0]
000071ff71bd5944  vmovaps xmm14, [rsp+0xD0]
000071ff71bd594d  vmovaps xmm15, [rsp+0xE0]
000071ff71bd5956  add rsp, 0xF0
000071ff71bd595d  pop r11
000071ff71bd595f  pop r10
000071ff71bd5961  pop r9
000071ff71bd5963  pop r8
000071ff71bd5965  pop rsi
000071ff71bd5966  pop rdi
000071ff71bd5967  pop rdx
000071ff71bd5968  pop rcx
000071ff71bd5969  pop rax
000071ff71bd596a  add rsp, 0x08
000071ff71bd596e  jmp 0x000071FF71BD2F5B
000071ff71bd5973  call 0x000071FF719FF430
000071ff71bd5978  jmp 0x000071FF71BD2F65
000071ff71bd597d  sub rsp, 0x08
000071ff71bd5981  push rax
000071ff71bd5982  push rcx
000071ff71bd5983  push rdx
000071ff71bd5984  push rdi
000071ff71bd5985  push rsi
000071ff71bd5986  push r8
000071ff71bd5988  push r9
000071ff71bd598a  push r10
000071ff71bd598c  push r11
000071ff71bd598e  sub rsp, 0xF0
000071ff71bd5995  vmovaps [rsp], xmm0
000071ff71bd599a  vmovaps [rsp+0x10], xmm1
000071ff71bd59a0  vmovaps [rsp+0x20], xmm2
000071ff71bd59a6  vmovaps [rsp+0x30], xmm3
000071ff71bd59ac  vmovaps [rsp+0x40], xmm4
000071ff71bd59b2  vmovaps [rsp+0x50], xmm5
000071ff71bd59b8  vmovaps [rsp+0x60], xmm6
000071ff71bd59be  vmovaps [rsp+0x70], xmm7
000071ff71bd59c4  vmovaps [rsp+0x80], xmm8
000071ff71bd59cd  vmovaps [rsp+0x90], xmm9
000071ff71bd59d6  vmovaps [rsp+0xA0], xmm10
000071ff71bd59df  vmovaps [rsp+0xB0], xmm11
000071ff71bd59e8  vmovaps [rsp+0xC0], xmm12
000071ff71bd59f1  vmovaps [rsp+0xD0], xmm13
000071ff71bd59fa  vmovaps [rsp+0xE0], xmm15
000071ff71bd5a03  sub rsp, 0x30
000071ff71bd5a07  movaps [rsp], xmm14
000071ff71bd5a0c  movaps [rsp+0x10], xmm6
000071ff71bd5a11  movaps [rsp+0x20], xmm2
000071ff71bd5a16  lea rdi, [rsp]
000071ff71bd5a1a  mov esi, 0x00
000071ff71bd5a1f  mov rax, 0x5E6872E10530
000071ff71bd5a29  call rax
000071ff71bd5a2b  movaps xmm14, [rsp]
000071ff71bd5a30  add rsp, 0x30
000071ff71bd5a34  vmovaps xmm0, [rsp]
000071ff71bd5a39  vmovaps xmm1, [rsp+0x10]
000071ff71bd5a3f  vmovaps xmm2, [rsp+0x20]
000071ff71bd5a45  vmovaps xmm3, [rsp+0x30]
000071ff71bd5a4b  vmovaps xmm4, [rsp+0x40]
000071ff71bd5a51  vmovaps xmm5, [rsp+0x50]
000071ff71bd5a57  vmovaps xmm6, [rsp+0x60]
000071ff71bd5a5d  vmovaps xmm7, [rsp+0x70]
000071ff71bd5a63  vmovaps xmm8, [rsp+0x80]
000071ff71bd5a6c  vmovaps xmm9, [rsp+0x90]
000071ff71bd5a75  vmovaps xmm10, [rsp+0xA0]
000071ff71bd5a7e  vmovaps xmm11, [rsp+0xB0]
000071ff71bd5a87  vmovaps xmm12, [rsp+0xC0]
000071ff71bd5a90  vmovaps xmm13, [rsp+0xD0]
000071ff71bd5a99  vmovaps xmm15, [rsp+0xE0]
000071ff71bd5aa2  add rsp, 0xF0
000071ff71bd5aa9  pop r11
000071ff71bd5aab  pop r10
000071ff71bd5aad  pop r9
000071ff71bd5aaf  pop r8
000071ff71bd5ab1  pop rsi
000071ff71bd5ab2  pop rdi
000071ff71bd5ab3  pop rdx
000071ff71bd5ab4  pop rcx
000071ff71bd5ab5  pop rax
000071ff71bd5ab6  add rsp, 0x08
000071ff71bd5aba  jmp 0x000071FF71BD2F99
000071ff71bd5abf  sub rsp, 0x08
000071ff71bd5ac3  push rax
000071ff71bd5ac4  push rcx
000071ff71bd5ac5  push rdx
000071ff71bd5ac6  push rdi
000071ff71bd5ac7  push rsi
000071ff71bd5ac8  push r8
000071ff71bd5aca  push r9
000071ff71bd5acc  push r10
000071ff71bd5ace  push r11
000071ff71bd5ad0  sub rsp, 0xF0
000071ff71bd5ad7  vmovaps [rsp], xmm0
000071ff71bd5adc  vmovaps [rsp+0x10], xmm1
000071ff71bd5ae2  vmovaps [rsp+0x20], xmm2
000071ff71bd5ae8  vmovaps [rsp+0x30], xmm3
000071ff71bd5aee  vmovaps [rsp+0x40], xmm4
000071ff71bd5af4  vmovaps [rsp+0x50], xmm5
000071ff71bd5afa  vmovaps [rsp+0x60], xmm7
000071ff71bd5b00  vmovaps [rsp+0x70], xmm8
000071ff71bd5b06  vmovaps [rsp+0x80], xmm9
000071ff71bd5b0f  vmovaps [rsp+0x90], xmm10
000071ff71bd5b18  vmovaps [rsp+0xA0], xmm11
000071ff71bd5b21  vmovaps [rsp+0xB0], xmm12
000071ff71bd5b2a  vmovaps [rsp+0xC0], xmm13
000071ff71bd5b33  vmovaps [rsp+0xD0], xmm14
000071ff71bd5b3c  vmovaps [rsp+0xE0], xmm15
000071ff71bd5b45  sub rsp, 0x30
000071ff71bd5b49  movaps [rsp], xmm6
000071ff71bd5b4d  movaps [rsp+0x10], xmm5
000071ff71bd5b52  movaps [rsp+0x20], xmm1
000071ff71bd5b57  lea rdi, [rsp]
000071ff71bd5b5b  mov esi, 0x00
000071ff71bd5b60  mov rax, 0x5E6872E10530
000071ff71bd5b6a  call rax
000071ff71bd5b6c  movaps xmm6, [rsp]
000071ff71bd5b70  add rsp, 0x30
000071ff71bd5b74  vmovaps xmm0, [rsp]
000071ff71bd5b79  vmovaps xmm1, [rsp+0x10]
000071ff71bd5b7f  vmovaps xmm2, [rsp+0x20]
000071ff71bd5b85  vmovaps xmm3, [rsp+0x30]
000071ff71bd5b8b  vmovaps xmm4, [rsp+0x40]
000071ff71bd5b91  vmovaps xmm5, [rsp+0x50]
000071ff71bd5b97  vmovaps xmm7, [rsp+0x60]
000071ff71bd5b9d  vmovaps xmm8, [rsp+0x70]
000071ff71bd5ba3  vmovaps xmm9, [rsp+0x80]
000071ff71bd5bac  vmovaps xmm10, [rsp+0x90]
000071ff71bd5bb5  vmovaps xmm11, [rsp+0xA0]
000071ff71bd5bbe  vmovaps xmm12, [rsp+0xB0]
000071ff71bd5bc7  vmovaps xmm13, [rsp+0xC0]
000071ff71bd5bd0  vmovaps xmm14, [rsp+0xD0]
000071ff71bd5bd9  vmovaps xmm15, [rsp+0xE0]
000071ff71bd5be2  add rsp, 0xF0
000071ff71bd5be9  pop r11
000071ff71bd5beb  pop r10
000071ff71bd5bed  pop r9
000071ff71bd5bef  pop r8
000071ff71bd5bf1  pop rsi
000071ff71bd5bf2  pop rdi
000071ff71bd5bf3  pop rdx
000071ff71bd5bf4  pop rcx
000071ff71bd5bf5  pop rax
000071ff71bd5bf6  add rsp, 0x08
000071ff71bd5bfa  jmp 0x000071FF71BD2FBF
000071ff71bd5bff  sub rsp, 0x08
000071ff71bd5c03  push rax
000071ff71bd5c04  push rcx
000071ff71bd5c05  push rdx
000071ff71bd5c06  push rdi
000071ff71bd5c07  push rsi
000071ff71bd5c08  push r8
000071ff71bd5c0a  push r9
000071ff71bd5c0c  push r10
000071ff71bd5c0e  push r11
000071ff71bd5c10  sub rsp, 0xF0
000071ff71bd5c17  vmovaps [rsp], xmm0
000071ff71bd5c1c  vmovaps [rsp+0x10], xmm2
000071ff71bd5c22  vmovaps [rsp+0x20], xmm3
000071ff71bd5c28  vmovaps [rsp+0x30], xmm4
000071ff71bd5c2e  vmovaps [rsp+0x40], xmm5
000071ff71bd5c34  vmovaps [rsp+0x50], xmm6
000071ff71bd5c3a  vmovaps [rsp+0x60], xmm7
000071ff71bd5c40  vmovaps [rsp+0x70], xmm8
000071ff71bd5c46  vmovaps [rsp+0x80], xmm9
000071ff71bd5c4f  vmovaps [rsp+0x90], xmm10
000071ff71bd5c58  vmovaps [rsp+0xA0], xmm11
000071ff71bd5c61  vmovaps [rsp+0xB0], xmm12
000071ff71bd5c6a  vmovaps [rsp+0xC0], xmm13
000071ff71bd5c73  vmovaps [rsp+0xD0], xmm14
000071ff71bd5c7c  vmovaps [rsp+0xE0], xmm15
000071ff71bd5c85  sub rsp, 0x30
000071ff71bd5c89  movaps [rsp], xmm1
000071ff71bd5c8d  movaps [rsp+0x10], xmm5
000071ff71bd5c92  movaps [rsp+0x20], xmm13
000071ff71bd5c98  lea rdi, [rsp]
000071ff71bd5c9c  mov esi, 0x00
000071ff71bd5ca1  mov rax, 0x5E6872E10530
000071ff71bd5cab  call rax
000071ff71bd5cad  movaps xmm1, [rsp]
000071ff71bd5cb1  add rsp, 0x30
000071ff71bd5cb5  vmovaps xmm0, [rsp]
000071ff71bd5cba  vmovaps xmm2, [rsp+0x10]
000071ff71bd5cc0  vmovaps xmm3, [rsp+0x20]
000071ff71bd5cc6  vmovaps xmm4, [rsp+0x30]
000071ff71bd5ccc  vmovaps xmm5, [rsp+0x40]
000071ff71bd5cd2  vmovaps xmm6, [rsp+0x50]
000071ff71bd5cd8  vmovaps xmm7, [rsp+0x60]
000071ff71bd5cde  vmovaps xmm8, [rsp+0x70]
000071ff71bd5ce4  vmovaps xmm9, [rsp+0x80]
000071ff71bd5ced  vmovaps xmm10, [rsp+0x90]
000071ff71bd5cf6  vmovaps xmm11, [rsp+0xA0]
000071ff71bd5cff  vmovaps xmm12, [rsp+0xB0]
000071ff71bd5d08  vmovaps xmm13, [rsp+0xC0]
000071ff71bd5d11  vmovaps xmm14, [rsp+0xD0]
000071ff71bd5d1a  vmovaps xmm15, [rsp+0xE0]
000071ff71bd5d23  add rsp, 0xF0
000071ff71bd5d2a  pop r11
000071ff71bd5d2c  pop r10
000071ff71bd5d2e  pop r9
000071ff71bd5d30  pop r8
000071ff71bd5d32  pop rsi
000071ff71bd5d33  pop rdi
000071ff71bd5d34  pop rdx
000071ff71bd5d35  pop rcx
000071ff71bd5d36  pop rax
000071ff71bd5d37  add rsp, 0x08
000071ff71bd5d3b  jmp 0x000071FF71BD2FDD
000071ff71bd5d40  sub rsp, 0x08
000071ff71bd5d44  push rax
000071ff71bd5d45  push rcx
000071ff71bd5d46  push rdx
000071ff71bd5d47  push rdi
000071ff71bd5d48  push rsi
000071ff71bd5d49  push r8
000071ff71bd5d4b  push r9
000071ff71bd5d4d  push r10
000071ff71bd5d4f  push r11
000071ff71bd5d51  sub rsp, 0xF0
000071ff71bd5d58  vmovaps [rsp], xmm0
000071ff71bd5d5d  vmovaps [rsp+0x10], xmm1
000071ff71bd5d63  vmovaps [rsp+0x20], xmm2
000071ff71bd5d69  vmovaps [rsp+0x30], xmm3
000071ff71bd5d6f  vmovaps [rsp+0x40], xmm4
000071ff71bd5d75  vmovaps [rsp+0x50], xmm6
000071ff71bd5d7b  vmovaps [rsp+0x60], xmm7
000071ff71bd5d81  vmovaps [rsp+0x70], xmm8
000071ff71bd5d87  vmovaps [rsp+0x80], xmm9
000071ff71bd5d90  vmovaps [rsp+0x90], xmm10
000071ff71bd5d99  vmovaps [rsp+0xA0], xmm11
000071ff71bd5da2  vmovaps [rsp+0xB0], xmm12
000071ff71bd5dab  vmovaps [rsp+0xC0], xmm13
000071ff71bd5db4  vmovaps [rsp+0xD0], xmm14
000071ff71bd5dbd  vmovaps [rsp+0xE0], xmm15
000071ff71bd5dc6  sub rsp, 0x30
000071ff71bd5dca  movaps [rsp], xmm5
000071ff71bd5dce  movaps [rsp+0x10], xmm2
000071ff71bd5dd3  movaps [rsp+0x20], xmm13
000071ff71bd5dd9  lea rdi, [rsp]
000071ff71bd5ddd  mov esi, 0x00
000071ff71bd5de2  mov rax, 0x5E6872E10530
000071ff71bd5dec  call rax
000071ff71bd5dee  movaps xmm5, [rsp]
000071ff71bd5df2  add rsp, 0x30
000071ff71bd5df6  vmovaps xmm0, [rsp]
000071ff71bd5dfb  vmovaps xmm1, [rsp+0x10]
000071ff71bd5e01  vmovaps xmm2, [rsp+0x20]
000071ff71bd5e07  vmovaps xmm3, [rsp+0x30]
000071ff71bd5e0d  vmovaps xmm4, [rsp+0x40]
000071ff71bd5e13  vmovaps xmm6, [rsp+0x50]
000071ff71bd5e19  vmovaps xmm7, [rsp+0x60]
000071ff71bd5e1f  vmovaps xmm8, [rsp+0x70]
000071ff71bd5e25  vmovaps xmm9, [rsp+0x80]
000071ff71bd5e2e  vmovaps xmm10, [rsp+0x90]
000071ff71bd5e37  vmovaps xmm11, [rsp+0xA0]
000071ff71bd5e40  vmovaps xmm12, [rsp+0xB0]
000071ff71bd5e49  vmovaps xmm13, [rsp+0xC0]
000071ff71bd5e52  vmovaps xmm14, [rsp+0xD0]
000071ff71bd5e5b  vmovaps xmm15, [rsp+0xE0]
000071ff71bd5e64  add rsp, 0xF0
000071ff71bd5e6b  pop r11
000071ff71bd5e6d  pop r10
000071ff71bd5e6f  pop r9
000071ff71bd5e71  pop r8
000071ff71bd5e73  pop rsi
000071ff71bd5e74  pop rdi
000071ff71bd5e75  pop rdx
000071ff71bd5e76  pop rcx
000071ff71bd5e77  pop rax
000071ff71bd5e78  add rsp, 0x08
000071ff71bd5e7c  jmp 0x000071FF71BD3013
000071ff71bd5e81  sub rsp, 0x08
000071ff71bd5e85  push rax
000071ff71bd5e86  push rcx
000071ff71bd5e87  push rdx
000071ff71bd5e88  push rdi
000071ff71bd5e89  push rsi
000071ff71bd5e8a  push r8
000071ff71bd5e8c  push r9
000071ff71bd5e8e  push r10
000071ff71bd5e90  push r11
000071ff71bd5e92  sub rsp, 0xF0
000071ff71bd5e99  vmovaps [rsp], xmm0
000071ff71bd5e9e  vmovaps [rsp+0x10], xmm1
000071ff71bd5ea4  vmovaps [rsp+0x20], xmm2
000071ff71bd5eaa  vmovaps [rsp+0x30], xmm3
000071ff71bd5eb0  vmovaps [rsp+0x40], xmm4
000071ff71bd5eb6  vmovaps [rsp+0x50], xmm5
000071ff71bd5ebc  vmovaps [rsp+0x60], xmm6
000071ff71bd5ec2  vmovaps [rsp+0x70], xmm7
000071ff71bd5ec8  vmovaps [rsp+0x80], xmm8
000071ff71bd5ed1  vmovaps [rsp+0x90], xmm9
000071ff71bd5eda  vmovaps [rsp+0xA0], xmm10
000071ff71bd5ee3  vmovaps [rsp+0xB0], xmm11
000071ff71bd5eec  vmovaps [rsp+0xC0], xmm12
000071ff71bd5ef5  vmovaps [rsp+0xD0], xmm14
000071ff71bd5efe  vmovaps [rsp+0xE0], xmm15
000071ff71bd5f07  sub rsp, 0x30
000071ff71bd5f0b  movaps [rsp], xmm13
000071ff71bd5f10  movaps [rsp+0x10], xmm10
000071ff71bd5f16  movaps [rsp+0x20], xmm1
000071ff71bd5f1b  lea rdi, [rsp]
000071ff71bd5f1f  mov esi, 0x00
000071ff71bd5f24  mov rax, 0x5E6872E10530
000071ff71bd5f2e  call rax
000071ff71bd5f30  movaps xmm13, [rsp]
000071ff71bd5f35  add rsp, 0x30
000071ff71bd5f39  vmovaps xmm0, [rsp]
000071ff71bd5f3e  vmovaps xmm1, [rsp+0x10]
000071ff71bd5f44  vmovaps xmm2, [rsp+0x20]
000071ff71bd5f4a  vmovaps xmm3, [rsp+0x30]
000071ff71bd5f50  vmovaps xmm4, [rsp+0x40]
000071ff71bd5f56  vmovaps xmm5, [rsp+0x50]
000071ff71bd5f5c  vmovaps xmm6, [rsp+0x60]
000071ff71bd5f62  vmovaps xmm7, [rsp+0x70]
000071ff71bd5f68  vmovaps xmm8, [rsp+0x80]
000071ff71bd5f71  vmovaps xmm9, [rsp+0x90]
000071ff71bd5f7a  vmovaps xmm10, [rsp+0xA0]
000071ff71bd5f83  vmovaps xmm11, [rsp+0xB0]
000071ff71bd5f8c  vmovaps xmm12, [rsp+0xC0]
000071ff71bd5f95  vmovaps xmm14, [rsp+0xD0]
000071ff71bd5f9e  vmovaps xmm15, [rsp+0xE0]
000071ff71bd5fa7  add rsp, 0xF0
000071ff71bd5fae  pop r11
000071ff71bd5fb0  pop r10
000071ff71bd5fb2  pop r9
000071ff71bd5fb4  pop r8
000071ff71bd5fb6  pop rsi
000071ff71bd5fb7  pop rdi
000071ff71bd5fb8  pop rdx
000071ff71bd5fb9  pop rcx
000071ff71bd5fba  pop rax
000071ff71bd5fbb  add rsp, 0x08
000071ff71bd5fbf  jmp 0x000071FF71BD303C
000071ff71bd5fc4  sub rsp, 0x08
000071ff71bd5fc8  push rax
000071ff71bd5fc9  push rcx
000071ff71bd5fca  push rdx
000071ff71bd5fcb  push rdi
000071ff71bd5fcc  push rsi
000071ff71bd5fcd  push r8
000071ff71bd5fcf  push r9
000071ff71bd5fd1  push r10
000071ff71bd5fd3  push r11
000071ff71bd5fd5  sub rsp, 0xF0
000071ff71bd5fdc  vmovaps [rsp], xmm0
000071ff71bd5fe1  vmovaps [rsp+0x10], xmm2
000071ff71bd5fe7  vmovaps [rsp+0x20], xmm3
000071ff71bd5fed  vmovaps [rsp+0x30], xmm4
000071ff71bd5ff3  vmovaps [rsp+0x40], xmm5
000071ff71bd5ff9  vmovaps [rsp+0x50], xmm6
000071ff71bd5fff  vmovaps [rsp+0x60], xmm7
000071ff71bd6005  vmovaps [rsp+0x70], xmm8
000071ff71bd600b  vmovaps [rsp+0x80], xmm9
000071ff71bd6014  vmovaps [rsp+0x90], xmm10
000071ff71bd601d  vmovaps [rsp+0xA0], xmm11
000071ff71bd6026  vmovaps [rsp+0xB0], xmm12
000071ff71bd602f  vmovaps [rsp+0xC0], xmm13
000071ff71bd6038  vmovaps [rsp+0xD0], xmm14
000071ff71bd6041  vmovaps [rsp+0xE0], xmm15
000071ff71bd604a  sub rsp, 0x30
000071ff71bd604e  movaps [rsp], xmm1
000071ff71bd6052  movaps [rsp+0x10], xmm15
000071ff71bd6058  movaps [rsp+0x20], xmm10
000071ff71bd605e  lea rdi, [rsp]
000071ff71bd6062  mov esi, 0x00
000071ff71bd6067  mov rax, 0x5E6872E10530
000071ff71bd6071  call rax
000071ff71bd6073  movaps xmm1, [rsp]
000071ff71bd6077  add rsp, 0x30
000071ff71bd607b  vmovaps xmm0, [rsp]
000071ff71bd6080  vmovaps xmm2, [rsp+0x10]
000071ff71bd6086  vmovaps xmm3, [rsp+0x20]
000071ff71bd608c  vmovaps xmm4, [rsp+0x30]
000071ff71bd6092  vmovaps xmm5, [rsp+0x40]
000071ff71bd6098  vmovaps xmm6, [rsp+0x50]
000071ff71bd609e  vmovaps xmm7, [rsp+0x60]
000071ff71bd60a4  vmovaps xmm8, [rsp+0x70]
000071ff71bd60aa  vmovaps xmm9, [rsp+0x80]
000071ff71bd60b3  vmovaps xmm10, [rsp+0x90]
000071ff71bd60bc  vmovaps xmm11, [rsp+0xA0]
000071ff71bd60c5  vmovaps xmm12, [rsp+0xB0]
000071ff71bd60ce  vmovaps xmm13, [rsp+0xC0]
000071ff71bd60d7  vmovaps xmm14, [rsp+0xD0]
000071ff71bd60e0  vmovaps xmm15, [rsp+0xE0]
000071ff71bd60e9  add rsp, 0xF0
000071ff71bd60f0  pop r11
000071ff71bd60f2  pop r10
000071ff71bd60f4  pop r9
000071ff71bd60f6  pop r8
000071ff71bd60f8  pop rsi
000071ff71bd60f9  pop rdi
000071ff71bd60fa  pop rdx
000071ff71bd60fb  pop rcx
000071ff71bd60fc  pop rax
000071ff71bd60fd  add rsp, 0x08
000071ff71bd6101  jmp 0x000071FF71BD305B
000071ff71bd6106  sub rsp, 0x08
000071ff71bd610a  push rax
000071ff71bd610b  push rcx
000071ff71bd610c  push rdx
000071ff71bd610d  push rdi
000071ff71bd610e  push rsi
000071ff71bd610f  push r8
000071ff71bd6111  push r9
000071ff71bd6113  push r10
000071ff71bd6115  push r11
000071ff71bd6117  sub rsp, 0xF0
000071ff71bd611e  vmovaps [rsp], xmm0
000071ff71bd6123  vmovaps [rsp+0x10], xmm1
000071ff71bd6129  vmovaps [rsp+0x20], xmm2
000071ff71bd612f  vmovaps [rsp+0x30], xmm3
000071ff71bd6135  vmovaps [rsp+0x40], xmm4
000071ff71bd613b  vmovaps [rsp+0x50], xmm5
000071ff71bd6141  vmovaps [rsp+0x60], xmm6
000071ff71bd6147  vmovaps [rsp+0x70], xmm7
000071ff71bd614d  vmovaps [rsp+0x80], xmm8
000071ff71bd6156  vmovaps [rsp+0x90], xmm9
000071ff71bd615f  vmovaps [rsp+0xA0], xmm10
000071ff71bd6168  vmovaps [rsp+0xB0], xmm11
000071ff71bd6171  vmovaps [rsp+0xC0], xmm12
000071ff71bd617a  vmovaps [rsp+0xD0], xmm13
000071ff71bd6183  vmovaps [rsp+0xE0], xmm14
000071ff71bd618c  sub rsp, 0x30
000071ff71bd6190  movaps [rsp], xmm15
000071ff71bd6195  movaps [rsp+0x10], xmm10
000071ff71bd619b  movaps [rsp+0x20], xmm11
000071ff71bd61a1  lea rdi, [rsp]
000071ff71bd61a5  mov esi, 0x00
000071ff71bd61aa  mov rax, 0x5E6872E10530
000071ff71bd61b4  call rax
000071ff71bd61b6  movaps xmm15, [rsp]
000071ff71bd61bb  add rsp, 0x30
000071ff71bd61bf  vmovaps xmm0, [rsp]
000071ff71bd61c4  vmovaps xmm1, [rsp+0x10]
000071ff71bd61ca  vmovaps xmm2, [rsp+0x20]
000071ff71bd61d0  vmovaps xmm3, [rsp+0x30]
000071ff71bd61d6  vmovaps xmm4, [rsp+0x40]
000071ff71bd61dc  vmovaps xmm5, [rsp+0x50]
000071ff71bd61e2  vmovaps xmm6, [rsp+0x60]
000071ff71bd61e8  vmovaps xmm7, [rsp+0x70]
000071ff71bd61ee  vmovaps xmm8, [rsp+0x80]
000071ff71bd61f7  vmovaps xmm9, [rsp+0x90]
000071ff71bd6200  vmovaps xmm10, [rsp+0xA0]
000071ff71bd6209  vmovaps xmm11, [rsp+0xB0]
000071ff71bd6212  vmovaps xmm12, [rsp+0xC0]
000071ff71bd621b  vmovaps xmm13, [rsp+0xD0]
000071ff71bd6224  vmovaps xmm14, [rsp+0xE0]
000071ff71bd622d  add rsp, 0xF0
000071ff71bd6234  pop r11
000071ff71bd6236  pop r10
000071ff71bd6238  pop r9
000071ff71bd623a  pop r8
000071ff71bd623c  pop rsi
000071ff71bd623d  pop rdi
000071ff71bd623e  pop rdx
000071ff71bd623f  pop rcx
000071ff71bd6240  pop rax
000071ff71bd6241  add rsp, 0x08
000071ff71bd6245  jmp 0x000071FF71BD307E
000071ff71bd624a  sub rsp, 0x08
000071ff71bd624e  push rax
000071ff71bd624f  push rcx
000071ff71bd6250  push rdx
000071ff71bd6251  push rdi
000071ff71bd6252  push rsi
000071ff71bd6253  push r8
000071ff71bd6255  push r9
000071ff71bd6257  push r10
000071ff71bd6259  push r11
000071ff71bd625b  sub rsp, 0xF0
000071ff71bd6262  vmovaps [rsp], xmm0
000071ff71bd6267  vmovaps [rsp+0x10], xmm1
000071ff71bd626d  vmovaps [rsp+0x20], xmm2
000071ff71bd6273  vmovaps [rsp+0x30], xmm3
000071ff71bd6279  vmovaps [rsp+0x40], xmm4
000071ff71bd627f  vmovaps [rsp+0x50], xmm5
000071ff71bd6285  vmovaps [rsp+0x60], xmm6
000071ff71bd628b  vmovaps [rsp+0x70], xmm7
000071ff71bd6291  vmovaps [rsp+0x80], xmm8
000071ff71bd629a  vmovaps [rsp+0x90], xmm9
000071ff71bd62a3  vmovaps [rsp+0xA0], xmm11
000071ff71bd62ac  vmovaps [rsp+0xB0], xmm12
000071ff71bd62b5  vmovaps [rsp+0xC0], xmm13
000071ff71bd62be  vmovaps [rsp+0xD0], xmm14
000071ff71bd62c7  vmovaps [rsp+0xE0], xmm15
000071ff71bd62d0  sub rsp, 0x30
000071ff71bd62d4  movaps [rsp], xmm10
000071ff71bd62d9  movaps [rsp+0x10], xmm2
000071ff71bd62de  movaps [rsp+0x20], xmm11
000071ff71bd62e4  lea rdi, [rsp]
000071ff71bd62e8  mov esi, 0x00
000071ff71bd62ed  mov rax, 0x5E6872E10530
000071ff71bd62f7  call rax
000071ff71bd62f9  movaps xmm10, [rsp]
000071ff71bd62fe  add rsp, 0x30
000071ff71bd6302  vmovaps xmm0, [rsp]
000071ff71bd6307  vmovaps xmm1, [rsp+0x10]
000071ff71bd630d  vmovaps xmm2, [rsp+0x20]
000071ff71bd6313  vmovaps xmm3, [rsp+0x30]
000071ff71bd6319  vmovaps xmm4, [rsp+0x40]
000071ff71bd631f  vmovaps xmm5, [rsp+0x50]
000071ff71bd6325  vmovaps xmm6, [rsp+0x60]
000071ff71bd632b  vmovaps xmm7, [rsp+0x70]
000071ff71bd6331  vmovaps xmm8, [rsp+0x80]
000071ff71bd633a  vmovaps xmm9, [rsp+0x90]
000071ff71bd6343  vmovaps xmm11, [rsp+0xA0]
000071ff71bd634c  vmovaps xmm12, [rsp+0xB0]
000071ff71bd6355  vmovaps xmm13, [rsp+0xC0]
000071ff71bd635e  vmovaps xmm14, [rsp+0xD0]
000071ff71bd6367  vmovaps xmm15, [rsp+0xE0]
000071ff71bd6370  add rsp, 0xF0
000071ff71bd6377  pop r11
000071ff71bd6379  pop r10
000071ff71bd637b  pop r9
000071ff71bd637d  pop r8
000071ff71bd637f  pop rsi
000071ff71bd6380  pop rdi
000071ff71bd6381  pop rdx
000071ff71bd6382  pop rcx
000071ff71bd6383  pop rax
000071ff71bd6384  add rsp, 0x08
000071ff71bd6388  jmp 0x000071FF71BD30B6
000071ff71bd638d  sub rsp, 0x08
000071ff71bd6391  push rax
000071ff71bd6392  push rcx
000071ff71bd6393  push rdx
000071ff71bd6394  push rdi
000071ff71bd6395  push rsi
000071ff71bd6396  push r8
000071ff71bd6398  push r9
000071ff71bd639a  push r10
000071ff71bd639c  push r11
000071ff71bd639e  sub rsp, 0xF0
000071ff71bd63a5  vmovaps [rsp], xmm0
000071ff71bd63aa  vmovaps [rsp+0x10], xmm1
000071ff71bd63b0  vmovaps [rsp+0x20], xmm2
000071ff71bd63b6  vmovaps [rsp+0x30], xmm3
000071ff71bd63bc  vmovaps [rsp+0x40], xmm4
000071ff71bd63c2  vmovaps [rsp+0x50], xmm5
000071ff71bd63c8  vmovaps [rsp+0x60], xmm6
000071ff71bd63ce  vmovaps [rsp+0x70], xmm7
000071ff71bd63d4  vmovaps [rsp+0x80], xmm8
000071ff71bd63dd  vmovaps [rsp+0x90], xmm9
000071ff71bd63e6  vmovaps [rsp+0xA0], xmm10
000071ff71bd63ef  vmovaps [rsp+0xB0], xmm12
000071ff71bd63f8  vmovaps [rsp+0xC0], xmm13
000071ff71bd6401  vmovaps [rsp+0xD0], xmm14
000071ff71bd640a  vmovaps [rsp+0xE0], xmm15
000071ff71bd6413  sub rsp, 0x30
000071ff71bd6417  movaps [rsp], xmm11
000071ff71bd641c  movaps [rsp+0x10], xmm2
000071ff71bd6421  movaps [rsp+0x20], xmm1
000071ff71bd6426  lea rdi, [rsp]
000071ff71bd642a  mov esi, 0x00
000071ff71bd642f  mov rax, 0x5E6872E10530
000071ff71bd6439  call rax
000071ff71bd643b  movaps xmm11, [rsp]
000071ff71bd6440  add rsp, 0x30
000071ff71bd6444  vmovaps xmm0, [rsp]
000071ff71bd6449  vmovaps xmm1, [rsp+0x10]
000071ff71bd644f  vmovaps xmm2, [rsp+0x20]
000071ff71bd6455  vmovaps xmm3, [rsp+0x30]
000071ff71bd645b  vmovaps xmm4, [rsp+0x40]
000071ff71bd6461  vmovaps xmm5, [rsp+0x50]
000071ff71bd6467  vmovaps xmm6, [rsp+0x60]
000071ff71bd646d  vmovaps xmm7, [rsp+0x70]
000071ff71bd6473  vmovaps xmm8, [rsp+0x80]
000071ff71bd647c  vmovaps xmm9, [rsp+0x90]
000071ff71bd6485  vmovaps xmm10, [rsp+0xA0]
000071ff71bd648e  vmovaps xmm12, [rsp+0xB0]
000071ff71bd6497  vmovaps xmm13, [rsp+0xC0]
000071ff71bd64a0  vmovaps xmm14, [rsp+0xD0]
000071ff71bd64a9  vmovaps xmm15, [rsp+0xE0]
000071ff71bd64b2  add rsp, 0xF0
000071ff71bd64b9  pop r11
000071ff71bd64bb  pop r10
000071ff71bd64bd  pop r9
000071ff71bd64bf  pop r8
000071ff71bd64c1  pop rsi
000071ff71bd64c2  pop rdi
000071ff71bd64c3  pop rdx
000071ff71bd64c4  pop rcx
000071ff71bd64c5  pop rax
000071ff71bd64c6  add rsp, 0x08
000071ff71bd64ca  jmp 0x000071FF71BD30F2
000071ff71bd64cf  sub rsp, 0x08
000071ff71bd64d3  push rax
000071ff71bd64d4  push rcx
000071ff71bd64d5  push rdx
000071ff71bd64d6  push rdi
000071ff71bd64d7  push rsi
000071ff71bd64d8  push r8
000071ff71bd64da  push r9
000071ff71bd64dc  push r10
000071ff71bd64de  push r11
000071ff71bd64e0  sub rsp, 0xF0
000071ff71bd64e7  vmovaps [rsp], xmm0
000071ff71bd64ec  vmovaps [rsp+0x10], xmm2
000071ff71bd64f2  vmovaps [rsp+0x20], xmm3
000071ff71bd64f8  vmovaps [rsp+0x30], xmm4
000071ff71bd64fe  vmovaps [rsp+0x40], xmm5
000071ff71bd6504  vmovaps [rsp+0x50], xmm6
000071ff71bd650a  vmovaps [rsp+0x60], xmm7
000071ff71bd6510  vmovaps [rsp+0x70], xmm8
000071ff71bd6516  vmovaps [rsp+0x80], xmm9
000071ff71bd651f  vmovaps [rsp+0x90], xmm10
000071ff71bd6528  vmovaps [rsp+0xA0], xmm11
000071ff71bd6531  vmovaps [rsp+0xB0], xmm12
000071ff71bd653a  vmovaps [rsp+0xC0], xmm13
000071ff71bd6543  vmovaps [rsp+0xD0], xmm14
000071ff71bd654c  vmovaps [rsp+0xE0], xmm15
000071ff71bd6555  sub rsp, 0x30
000071ff71bd6559  movaps [rsp], xmm1
000071ff71bd655d  movaps [rsp+0x10], xmm14
000071ff71bd6563  movaps [rsp+0x20], xmm6
000071ff71bd6568  lea rdi, [rsp]
000071ff71bd656c  mov esi, 0x00
000071ff71bd6571  mov rax, 0x5E6872E10530
000071ff71bd657b  call rax
000071ff71bd657d  movaps xmm1, [rsp]
000071ff71bd6581  add rsp, 0x30
000071ff71bd6585  vmovaps xmm0, [rsp]
000071ff71bd658a  vmovaps xmm2, [rsp+0x10]
000071ff71bd6590  vmovaps xmm3, [rsp+0x20]
000071ff71bd6596  vmovaps xmm4, [rsp+0x30]
000071ff71bd659c  vmovaps xmm5, [rsp+0x40]
000071ff71bd65a2  vmovaps xmm6, [rsp+0x50]
000071ff71bd65a8  vmovaps xmm7, [rsp+0x60]
000071ff71bd65ae  vmovaps xmm8, [rsp+0x70]
000071ff71bd65b4  vmovaps xmm9, [rsp+0x80]
000071ff71bd65bd  vmovaps xmm10, [rsp+0x90]
000071ff71bd65c6  vmovaps xmm11, [rsp+0xA0]
000071ff71bd65cf  vmovaps xmm12, [rsp+0xB0]
000071ff71bd65d8  vmovaps xmm13, [rsp+0xC0]
000071ff71bd65e1  vmovaps xmm14, [rsp+0xD0]
000071ff71bd65ea  vmovaps xmm15, [rsp+0xE0]
000071ff71bd65f3  add rsp, 0xF0
000071ff71bd65fa  pop r11
000071ff71bd65fc  pop r10
000071ff71bd65fe  pop r9
000071ff71bd6600  pop r8
000071ff71bd6602  pop rsi
000071ff71bd6603  pop rdi
000071ff71bd6604  pop rdx
000071ff71bd6605  pop rcx
000071ff71bd6606  pop rax
000071ff71bd6607  add rsp, 0x08
000071ff71bd660b  jmp 0x000071FF71BD310B
000071ff71bd6610  sub rsp, 0x08
000071ff71bd6614  push rax
000071ff71bd6615  push rcx
000071ff71bd6616  push rdx
000071ff71bd6617  push rdi
000071ff71bd6618  push rsi
000071ff71bd6619  push r8
000071ff71bd661b  push r9
000071ff71bd661d  push r10
000071ff71bd661f  push r11
000071ff71bd6621  sub rsp, 0xF0
000071ff71bd6628  vmovaps [rsp], xmm0
000071ff71bd662d  vmovaps [rsp+0x10], xmm1
000071ff71bd6633  vmovaps [rsp+0x20], xmm2
000071ff71bd6639  vmovaps [rsp+0x30], xmm3
000071ff71bd663f  vmovaps [rsp+0x40], xmm4
000071ff71bd6645  vmovaps [rsp+0x50], xmm5
000071ff71bd664b  vmovaps [rsp+0x60], xmm6
000071ff71bd6651  vmovaps [rsp+0x70], xmm7
000071ff71bd6657  vmovaps [rsp+0x80], xmm8
000071ff71bd6660  vmovaps [rsp+0x90], xmm9
000071ff71bd6669  vmovaps [rsp+0xA0], xmm10
000071ff71bd6672  vmovaps [rsp+0xB0], xmm11
000071ff71bd667b  vmovaps [rsp+0xC0], xmm12
000071ff71bd6684  vmovaps [rsp+0xD0], xmm13
000071ff71bd668d  vmovaps [rsp+0xE0], xmm14
000071ff71bd6696  sub rsp, 0x30
000071ff71bd669a  movaps [rsp], xmm15
000071ff71bd669f  movaps [rsp+0x10], xmm14
000071ff71bd66a5  movaps [rsp+0x20], xmm5
000071ff71bd66aa  lea rdi, [rsp]
000071ff71bd66ae  mov esi, 0x00
000071ff71bd66b3  mov rax, 0x5E6872E10530
000071ff71bd66bd  call rax
000071ff71bd66bf  movaps xmm15, [rsp]
000071ff71bd66c4  add rsp, 0x30
000071ff71bd66c8  vmovaps xmm0, [rsp]
000071ff71bd66cd  vmovaps xmm1, [rsp+0x10]
000071ff71bd66d3  vmovaps xmm2, [rsp+0x20]
000071ff71bd66d9  vmovaps xmm3, [rsp+0x30]
000071ff71bd66df  vmovaps xmm4, [rsp+0x40]
000071ff71bd66e5  vmovaps xmm5, [rsp+0x50]
000071ff71bd66eb  vmovaps xmm6, [rsp+0x60]
000071ff71bd66f1  vmovaps xmm7, [rsp+0x70]
000071ff71bd66f7  vmovaps xmm8, [rsp+0x80]
000071ff71bd6700  vmovaps xmm9, [rsp+0x90]
000071ff71bd6709  vmovaps xmm10, [rsp+0xA0]
000071ff71bd6712  vmovaps xmm11, [rsp+0xB0]
000071ff71bd671b  vmovaps xmm12, [rsp+0xC0]
000071ff71bd6724  vmovaps xmm13, [rsp+0xD0]
000071ff71bd672d  vmovaps xmm14, [rsp+0xE0]
000071ff71bd6736  add rsp, 0xF0
000071ff71bd673d  pop r11
000071ff71bd673f  pop r10
000071ff71bd6741  pop r9
000071ff71bd6743  pop r8
000071ff71bd6745  pop rsi
000071ff71bd6746  pop rdi
000071ff71bd6747  pop rdx
000071ff71bd6748  pop rcx
000071ff71bd6749  pop rax
000071ff71bd674a  add rsp, 0x08
000071ff71bd674e  jmp 0x000071FF71BD312B
000071ff71bd6753  sub rsp, 0x08
000071ff71bd6757  push rax
000071ff71bd6758  push rcx
000071ff71bd6759  push rdx
000071ff71bd675a  push rdi
000071ff71bd675b  push rsi
000071ff71bd675c  push r8
000071ff71bd675e  push r9
000071ff71bd6760  push r10
000071ff71bd6762  push r11
000071ff71bd6764  sub rsp, 0xF0
000071ff71bd676b  vmovaps [rsp], xmm0
000071ff71bd6770  vmovaps [rsp+0x10], xmm1
000071ff71bd6776  vmovaps [rsp+0x20], xmm2
000071ff71bd677c  vmovaps [rsp+0x30], xmm3
000071ff71bd6782  vmovaps [rsp+0x40], xmm4
000071ff71bd6788  vmovaps [rsp+0x50], xmm5
000071ff71bd678e  vmovaps [rsp+0x60], xmm7
000071ff71bd6794  vmovaps [rsp+0x70], xmm8
000071ff71bd679a  vmovaps [rsp+0x80], xmm9
000071ff71bd67a3  vmovaps [rsp+0x90], xmm10
000071ff71bd67ac  vmovaps [rsp+0xA0], xmm11
000071ff71bd67b5  vmovaps [rsp+0xB0], xmm12
000071ff71bd67be  vmovaps [rsp+0xC0], xmm13
000071ff71bd67c7  vmovaps [rsp+0xD0], xmm14
000071ff71bd67d0  vmovaps [rsp+0xE0], xmm15
000071ff71bd67d9  sub rsp, 0x30
000071ff71bd67dd  movaps [rsp], xmm6
000071ff71bd67e1  movaps [rsp+0x10], xmm9
000071ff71bd67e7  movaps [rsp+0x20], xmm14
000071ff71bd67ed  lea rdi, [rsp]
000071ff71bd67f1  mov esi, 0x00
000071ff71bd67f6  mov rax, 0x5E6872E10530
000071ff71bd6800  call rax
000071ff71bd6802  movaps xmm6, [rsp]
000071ff71bd6806  add rsp, 0x30
000071ff71bd680a  vmovaps xmm0, [rsp]
000071ff71bd680f  vmovaps xmm1, [rsp+0x10]
000071ff71bd6815  vmovaps xmm2, [rsp+0x20]
000071ff71bd681b  vmovaps xmm3, [rsp+0x30]
000071ff71bd6821  vmovaps xmm4, [rsp+0x40]
000071ff71bd6827  vmovaps xmm5, [rsp+0x50]
000071ff71bd682d  vmovaps xmm7, [rsp+0x60]
000071ff71bd6833  vmovaps xmm8, [rsp+0x70]
000071ff71bd6839  vmovaps xmm9, [rsp+0x80]
000071ff71bd6842  vmovaps xmm10, [rsp+0x90]
000071ff71bd684b  vmovaps xmm11, [rsp+0xA0]
000071ff71bd6854  vmovaps xmm12, [rsp+0xB0]
000071ff71bd685d  vmovaps xmm13, [rsp+0xC0]
000071ff71bd6866  vmovaps xmm14, [rsp+0xD0]
000071ff71bd686f  vmovaps xmm15, [rsp+0xE0]
000071ff71bd6878  add rsp, 0xF0
000071ff71bd687f  pop r11
000071ff71bd6881  pop r10
000071ff71bd6883  pop r9
000071ff71bd6885  pop r8
000071ff71bd6887  pop rsi
000071ff71bd6888  pop rdi
000071ff71bd6889  pop rdx
000071ff71bd688a  pop rcx
000071ff71bd688b  pop rax
000071ff71bd688c  add rsp, 0x08
000071ff71bd6890  jmp 0x000071FF71BD3153
000071ff71bd6895  sub rsp, 0x08
000071ff71bd6899  push rax
000071ff71bd689a  push rcx
000071ff71bd689b  push rdx
000071ff71bd689c  push rdi
000071ff71bd689d  push rsi
000071ff71bd689e  push r8
000071ff71bd68a0  push r9
000071ff71bd68a2  push r10
000071ff71bd68a4  push r11
000071ff71bd68a6  sub rsp, 0xF0
000071ff71bd68ad  vmovaps [rsp], xmm0
000071ff71bd68b2  vmovaps [rsp+0x10], xmm1
000071ff71bd68b8  vmovaps [rsp+0x20], xmm2
000071ff71bd68be  vmovaps [rsp+0x30], xmm3
000071ff71bd68c4  vmovaps [rsp+0x40], xmm4
000071ff71bd68ca  vmovaps [rsp+0x50], xmm5
000071ff71bd68d0  vmovaps [rsp+0x60], xmm6
000071ff71bd68d6  vmovaps [rsp+0x70], xmm7
000071ff71bd68dc  vmovaps [rsp+0x80], xmm8
000071ff71bd68e5  vmovaps [rsp+0x90], xmm9
000071ff71bd68ee  vmovaps [rsp+0xA0], xmm10
000071ff71bd68f7  vmovaps [rsp+0xB0], xmm11
000071ff71bd6900  vmovaps [rsp+0xC0], xmm12
000071ff71bd6909  vmovaps [rsp+0xD0], xmm13
000071ff71bd6912  vmovaps [rsp+0xE0], xmm15
000071ff71bd691b  sub rsp, 0x30
000071ff71bd691f  movaps [rsp], xmm14
000071ff71bd6924  movaps [rsp+0x10], xmm9
000071ff71bd692a  movaps [rsp+0x20], xmm13
000071ff71bd6930  lea rdi, [rsp]
000071ff71bd6934  mov esi, 0x00
000071ff71bd6939  mov rax, 0x5E6872E10530
000071ff71bd6943  call rax
000071ff71bd6945  movaps xmm14, [rsp]
000071ff71bd694a  add rsp, 0x30
000071ff71bd694e  vmovaps xmm0, [rsp]
000071ff71bd6953  vmovaps xmm1, [rsp+0x10]
000071ff71bd6959  vmovaps xmm2, [rsp+0x20]
000071ff71bd695f  vmovaps xmm3, [rsp+0x30]
000071ff71bd6965  vmovaps xmm4, [rsp+0x40]
000071ff71bd696b  vmovaps xmm5, [rsp+0x50]
000071ff71bd6971  vmovaps xmm6, [rsp+0x60]
000071ff71bd6977  vmovaps xmm7, [rsp+0x70]
000071ff71bd697d  vmovaps xmm8, [rsp+0x80]
000071ff71bd6986  vmovaps xmm9, [rsp+0x90]
000071ff71bd698f  vmovaps xmm10, [rsp+0xA0]
000071ff71bd6998  vmovaps xmm11, [rsp+0xB0]
000071ff71bd69a1  vmovaps xmm12, [rsp+0xC0]
000071ff71bd69aa  vmovaps xmm13, [rsp+0xD0]
000071ff71bd69b3  vmovaps xmm15, [rsp+0xE0]
000071ff71bd69bc  add rsp, 0xF0
000071ff71bd69c3  pop r11
000071ff71bd69c5  pop r10
000071ff71bd69c7  pop r9
000071ff71bd69c9  pop r8
000071ff71bd69cb  pop rsi
000071ff71bd69cc  pop rdi
000071ff71bd69cd  pop rdx
000071ff71bd69ce  pop rcx
000071ff71bd69cf  pop rax
000071ff71bd69d0  add rsp, 0x08
000071ff71bd69d4  jmp 0x000071FF71BD3176
000071ff71bd69d9  sub rsp, 0x08
000071ff71bd69dd  push rax
000071ff71bd69de  push rcx
000071ff71bd69df  push rdx
000071ff71bd69e0  push rdi
000071ff71bd69e1  push rsi
000071ff71bd69e2  push r8
000071ff71bd69e4  push r9
000071ff71bd69e6  push r10
000071ff71bd69e8  push r11
000071ff71bd69ea  sub rsp, 0xF0
000071ff71bd69f1  vmovaps [rsp], xmm0
000071ff71bd69f6  vmovaps [rsp+0x10], xmm1
000071ff71bd69fc  vmovaps [rsp+0x20], xmm2
000071ff71bd6a02  vmovaps [rsp+0x30], xmm3
000071ff71bd6a08  vmovaps [rsp+0x40], xmm4
000071ff71bd6a0e  vmovaps [rsp+0x50], xmm5
000071ff71bd6a14  vmovaps [rsp+0x60], xmm6
000071ff71bd6a1a  vmovaps [rsp+0x70], xmm7
000071ff71bd6a20  vmovaps [rsp+0x80], xmm8
000071ff71bd6a29  vmovaps [rsp+0x90], xmm9
000071ff71bd6a32  vmovaps [rsp+0xA0], xmm10
000071ff71bd6a3b  vmovaps [rsp+0xB0], xmm11
000071ff71bd6a44  vmovaps [rsp+0xC0], xmm12
000071ff71bd6a4d  vmovaps [rsp+0xD0], xmm14
000071ff71bd6a56  vmovaps [rsp+0xE0], xmm15
000071ff71bd6a5f  sub rsp, 0x30
000071ff71bd6a63  movaps [rsp], xmm13
000071ff71bd6a68  movaps [rsp+0x10], xmm9
000071ff71bd6a6e  movaps [rsp+0x20], xmm10
000071ff71bd6a74  lea rdi, [rsp]
000071ff71bd6a78  mov esi, 0x00
000071ff71bd6a7d  mov rax, 0x5E6872E10530
000071ff71bd6a87  call rax
000071ff71bd6a89  movaps xmm13, [rsp]
000071ff71bd6a8e  add rsp, 0x30
000071ff71bd6a92  vmovaps xmm0, [rsp]
000071ff71bd6a97  vmovaps xmm1, [rsp+0x10]
000071ff71bd6a9d  vmovaps xmm2, [rsp+0x20]
000071ff71bd6aa3  vmovaps xmm3, [rsp+0x30]
000071ff71bd6aa9  vmovaps xmm4, [rsp+0x40]
000071ff71bd6aaf  vmovaps xmm5, [rsp+0x50]
000071ff71bd6ab5  vmovaps xmm6, [rsp+0x60]
000071ff71bd6abb  vmovaps xmm7, [rsp+0x70]
000071ff71bd6ac1  vmovaps xmm8, [rsp+0x80]
000071ff71bd6aca  vmovaps xmm9, [rsp+0x90]
000071ff71bd6ad3  vmovaps xmm10, [rsp+0xA0]
000071ff71bd6adc  vmovaps xmm11, [rsp+0xB0]
000071ff71bd6ae5  vmovaps xmm12, [rsp+0xC0]
000071ff71bd6aee  vmovaps xmm14, [rsp+0xD0]
000071ff71bd6af7  vmovaps xmm15, [rsp+0xE0]
000071ff71bd6b00  add rsp, 0xF0
000071ff71bd6b07  pop r11
000071ff71bd6b09  pop r10
000071ff71bd6b0b  pop r9
000071ff71bd6b0d  pop r8
000071ff71bd6b0f  pop rsi
000071ff71bd6b10  pop rdi
000071ff71bd6b11  pop rdx
000071ff71bd6b12  pop rcx
000071ff71bd6b13  pop rax
000071ff71bd6b14  add rsp, 0x08
000071ff71bd6b18  jmp 0x000071FF71BD3196
000071ff71bd6b1d  call 0x000071FF71A0AFE0
000071ff71bd6b22  jmp 0x000071FF71BD31EB
000071ff71bd6b27  sub rsp, 0x08
000071ff71bd6b2b  push rax
000071ff71bd6b2c  push rcx
000071ff71bd6b2d  push rdx
000071ff71bd6b2e  push rdi
000071ff71bd6b2f  push rsi
000071ff71bd6b30  push r8
000071ff71bd6b32  push r9
000071ff71bd6b34  push r10
000071ff71bd6b36  push r11
000071ff71bd6b38  sub rsp, 0xF0
000071ff71bd6b3f  vmovaps [rsp], xmm0
000071ff71bd6b44  vmovaps [rsp+0x10], xmm1
000071ff71bd6b4a  vmovaps [rsp+0x20], xmm2
000071ff71bd6b50  vmovaps [rsp+0x30], xmm3
000071ff71bd6b56  vmovaps [rsp+0x40], xmm4
000071ff71bd6b5c  vmovaps [rsp+0x50], xmm5
000071ff71bd6b62  vmovaps [rsp+0x60], xmm6
000071ff71bd6b68  vmovaps [rsp+0x70], xmm7
000071ff71bd6b6e  vmovaps [rsp+0x80], xmm8
000071ff71bd6b77  vmovaps [rsp+0x90], xmm10
000071ff71bd6b80  vmovaps [rsp+0xA0], xmm11
000071ff71bd6b89  vmovaps [rsp+0xB0], xmm12
000071ff71bd6b92  vmovaps [rsp+0xC0], xmm13
000071ff71bd6b9b  vmovaps [rsp+0xD0], xmm14
000071ff71bd6ba4  vmovaps [rsp+0xE0], xmm15
000071ff71bd6bad  sub rsp, 0x30
000071ff71bd6bb1  movaps [rsp], xmm9
000071ff71bd6bb6  movaps [rsp+0x10], xmm8
000071ff71bd6bbc  movaps [rsp+0x20], xmm10
000071ff71bd6bc2  lea rdi, [rsp]
000071ff71bd6bc6  mov esi, 0x00
000071ff71bd6bcb  mov rax, 0x5E6872E10530
000071ff71bd6bd5  call rax
000071ff71bd6bd7  movaps xmm9, [rsp]
000071ff71bd6bdc  add rsp, 0x30
000071ff71bd6be0  vmovaps xmm0, [rsp]
000071ff71bd6be5  vmovaps xmm1, [rsp+0x10]
000071ff71bd6beb  vmovaps xmm2, [rsp+0x20]
000071ff71bd6bf1  vmovaps xmm3, [rsp+0x30]
000071ff71bd6bf7  vmovaps xmm4, [rsp+0x40]
000071ff71bd6bfd  vmovaps xmm5, [rsp+0x50]
000071ff71bd6c03  vmovaps xmm6, [rsp+0x60]
000071ff71bd6c09  vmovaps xmm7, [rsp+0x70]
000071ff71bd6c0f  vmovaps xmm8, [rsp+0x80]
000071ff71bd6c18  vmovaps xmm10, [rsp+0x90]
000071ff71bd6c21  vmovaps xmm11, [rsp+0xA0]
000071ff71bd6c2a  vmovaps xmm12, [rsp+0xB0]
000071ff71bd6c33  vmovaps xmm13, [rsp+0xC0]
000071ff71bd6c3c  vmovaps xmm14, [rsp+0xD0]
000071ff71bd6c45  vmovaps xmm15, [rsp+0xE0]
000071ff71bd6c4e  add rsp, 0xF0
000071ff71bd6c55  pop r11
000071ff71bd6c57  pop r10
000071ff71bd6c59  pop r9
000071ff71bd6c5b  pop r8
000071ff71bd6c5d  pop rsi
000071ff71bd6c5e  pop rdi
000071ff71bd6c5f  pop rdx
000071ff71bd6c60  pop rcx
000071ff71bd6c61  pop rax
000071ff71bd6c62  add rsp, 0x08
000071ff71bd6c66  jmp 0x000071FF71BD321C
000071ff71bd6c6b  sub rsp, 0x08
000071ff71bd6c6f  push rax
000071ff71bd6c70  push rcx
000071ff71bd6c71  push rdx
000071ff71bd6c72  push rdi
000071ff71bd6c73  push rsi
000071ff71bd6c74  push r8
000071ff71bd6c76  push r9
000071ff71bd6c78  push r10
000071ff71bd6c7a  push r11
000071ff71bd6c7c  sub rsp, 0xF0
000071ff71bd6c83  vmovaps [rsp], xmm0
000071ff71bd6c88  vmovaps [rsp+0x10], xmm1
000071ff71bd6c8e  vmovaps [rsp+0x20], xmm2
000071ff71bd6c94  vmovaps [rsp+0x30], xmm3
000071ff71bd6c9a  vmovaps [rsp+0x40], xmm4
000071ff71bd6ca0  vmovaps [rsp+0x50], xmm5
000071ff71bd6ca6  vmovaps [rsp+0x60], xmm6
000071ff71bd6cac  vmovaps [rsp+0x70], xmm7
000071ff71bd6cb2  vmovaps [rsp+0x80], xmm8
000071ff71bd6cbb  vmovaps [rsp+0x90], xmm9
000071ff71bd6cc4  vmovaps [rsp+0xA0], xmm11
000071ff71bd6ccd  vmovaps [rsp+0xB0], xmm12
000071ff71bd6cd6  vmovaps [rsp+0xC0], xmm13
000071ff71bd6cdf  vmovaps [rsp+0xD0], xmm14
000071ff71bd6ce8  vmovaps [rsp+0xE0], xmm15
000071ff71bd6cf1  sub rsp, 0x30
000071ff71bd6cf5  movaps [rsp], xmm10
000071ff71bd6cfa  movaps [rsp+0x10], xmm1
000071ff71bd6cff  movaps [rsp+0x20], xmm11
000071ff71bd6d05  lea rdi, [rsp]
000071ff71bd6d09  mov esi, 0x00
000071ff71bd6d0e  mov rax, 0x5E6872E10530
000071ff71bd6d18  call rax
000071ff71bd6d1a  movaps xmm10, [rsp]
000071ff71bd6d1f  add rsp, 0x30
000071ff71bd6d23  vmovaps xmm0, [rsp]
000071ff71bd6d28  vmovaps xmm1, [rsp+0x10]
000071ff71bd6d2e  vmovaps xmm2, [rsp+0x20]
000071ff71bd6d34  vmovaps xmm3, [rsp+0x30]
000071ff71bd6d3a  vmovaps xmm4, [rsp+0x40]
000071ff71bd6d40  vmovaps xmm5, [rsp+0x50]
000071ff71bd6d46  vmovaps xmm6, [rsp+0x60]
000071ff71bd6d4c  vmovaps xmm7, [rsp+0x70]
000071ff71bd6d52  vmovaps xmm8, [rsp+0x80]
000071ff71bd6d5b  vmovaps xmm9, [rsp+0x90]
000071ff71bd6d64  vmovaps xmm11, [rsp+0xA0]
000071ff71bd6d6d  vmovaps xmm12, [rsp+0xB0]
000071ff71bd6d76  vmovaps xmm13, [rsp+0xC0]
000071ff71bd6d7f  vmovaps xmm14, [rsp+0xD0]
000071ff71bd6d88  vmovaps xmm15, [rsp+0xE0]
000071ff71bd6d91  add rsp, 0xF0
000071ff71bd6d98  pop r11
000071ff71bd6d9a  pop r10
000071ff71bd6d9c  pop r9
000071ff71bd6d9e  pop r8
000071ff71bd6da0  pop rsi
000071ff71bd6da1  pop rdi
000071ff71bd6da2  pop rdx
000071ff71bd6da3  pop rcx
000071ff71bd6da4  pop rax
000071ff71bd6da5  add rsp, 0x08
000071ff71bd6da9  jmp 0x000071FF71BD3237
000071ff71bd6dae  sub rsp, 0x08
000071ff71bd6db2  push rax
000071ff71bd6db3  push rcx
000071ff71bd6db4  push rdx
000071ff71bd6db5  push rdi
000071ff71bd6db6  push rsi
000071ff71bd6db7  push r8
000071ff71bd6db9  push r9
000071ff71bd6dbb  push r10
000071ff71bd6dbd  push r11
000071ff71bd6dbf  sub rsp, 0xF0
000071ff71bd6dc6  vmovaps [rsp], xmm0
000071ff71bd6dcb  vmovaps [rsp+0x10], xmm2
000071ff71bd6dd1  vmovaps [rsp+0x20], xmm3
000071ff71bd6dd7  vmovaps [rsp+0x30], xmm4
000071ff71bd6ddd  vmovaps [rsp+0x40], xmm5
000071ff71bd6de3  vmovaps [rsp+0x50], xmm6
000071ff71bd6de9  vmovaps [rsp+0x60], xmm7
000071ff71bd6def  vmovaps [rsp+0x70], xmm8
000071ff71bd6df5  vmovaps [rsp+0x80], xmm9
000071ff71bd6dfe  vmovaps [rsp+0x90], xmm10
000071ff71bd6e07  vmovaps [rsp+0xA0], xmm11
000071ff71bd6e10  vmovaps [rsp+0xB0], xmm12
000071ff71bd6e19  vmovaps [rsp+0xC0], xmm13
000071ff71bd6e22  vmovaps [rsp+0xD0], xmm14
000071ff71bd6e2b  vmovaps [rsp+0xE0], xmm15
000071ff71bd6e34  sub rsp, 0x30
000071ff71bd6e38  movaps [rsp], xmm1
000071ff71bd6e3c  movaps [rsp+0x10], xmm15
000071ff71bd6e42  movaps [rsp+0x20], xmm6
000071ff71bd6e47  lea rdi, [rsp]
000071ff71bd6e4b  mov esi, 0x00
000071ff71bd6e50  mov rax, 0x5E6872E10530
000071ff71bd6e5a  call rax
000071ff71bd6e5c  movaps xmm1, [rsp]
000071ff71bd6e60  add rsp, 0x30
000071ff71bd6e64  vmovaps xmm0, [rsp]
000071ff71bd6e69  vmovaps xmm2, [rsp+0x10]
000071ff71bd6e6f  vmovaps xmm3, [rsp+0x20]
000071ff71bd6e75  vmovaps xmm4, [rsp+0x30]
000071ff71bd6e7b  vmovaps xmm5, [rsp+0x40]
000071ff71bd6e81  vmovaps xmm6, [rsp+0x50]
000071ff71bd6e87  vmovaps xmm7, [rsp+0x60]
000071ff71bd6e8d  vmovaps xmm8, [rsp+0x70]
000071ff71bd6e93  vmovaps xmm9, [rsp+0x80]
000071ff71bd6e9c  vmovaps xmm10, [rsp+0x90]
000071ff71bd6ea5  vmovaps xmm11, [rsp+0xA0]
000071ff71bd6eae  vmovaps xmm12, [rsp+0xB0]
000071ff71bd6eb7  vmovaps xmm13, [rsp+0xC0]
000071ff71bd6ec0  vmovaps xmm14, [rsp+0xD0]
000071ff71bd6ec9  vmovaps xmm15, [rsp+0xE0]
000071ff71bd6ed2  add rsp, 0xF0
000071ff71bd6ed9  pop r11
000071ff71bd6edb  pop r10
000071ff71bd6edd  pop r9
000071ff71bd6edf  pop r8
000071ff71bd6ee1  pop rsi
000071ff71bd6ee2  pop rdi
000071ff71bd6ee3  pop rdx
000071ff71bd6ee4  pop rcx
000071ff71bd6ee5  pop rax
000071ff71bd6ee6  add rsp, 0x08
000071ff71bd6eea  jmp 0x000071FF71BD3250
000071ff71bd6eef  sub rsp, 0x08
000071ff71bd6ef3  push rax
000071ff71bd6ef4  push rcx
000071ff71bd6ef5  push rdx
000071ff71bd6ef6  push rdi
000071ff71bd6ef7  push rsi
000071ff71bd6ef8  push r8
000071ff71bd6efa  push r9
000071ff71bd6efc  push r10
000071ff71bd6efe  push r11
000071ff71bd6f00  sub rsp, 0xF0
000071ff71bd6f07  vmovaps [rsp], xmm0
000071ff71bd6f0c  vmovaps [rsp+0x10], xmm1
000071ff71bd6f12  vmovaps [rsp+0x20], xmm2
000071ff71bd6f18  vmovaps [rsp+0x30], xmm3
000071ff71bd6f1e  vmovaps [rsp+0x40], xmm4
000071ff71bd6f24  vmovaps [rsp+0x50], xmm5
000071ff71bd6f2a  vmovaps [rsp+0x60], xmm6
000071ff71bd6f30  vmovaps [rsp+0x70], xmm7
000071ff71bd6f36  vmovaps [rsp+0x80], xmm8
000071ff71bd6f3f  vmovaps [rsp+0x90], xmm9
000071ff71bd6f48  vmovaps [rsp+0xA0], xmm10
000071ff71bd6f51  vmovaps [rsp+0xB0], xmm12
000071ff71bd6f5a  vmovaps [rsp+0xC0], xmm13
000071ff71bd6f63  vmovaps [rsp+0xD0], xmm14
000071ff71bd6f6c  vmovaps [rsp+0xE0], xmm15
000071ff71bd6f75  sub rsp, 0x30
000071ff71bd6f79  movaps [rsp], xmm11
000071ff71bd6f7e  movaps [rsp+0x10], xmm12
000071ff71bd6f84  movaps [rsp+0x20], xmm15
000071ff71bd6f8a  lea rdi, [rsp]
000071ff71bd6f8e  mov esi, 0x00
000071ff71bd6f93  mov rax, 0x5E6872E10530
000071ff71bd6f9d  call rax
000071ff71bd6f9f  movaps xmm11, [rsp]
000071ff71bd6fa4  add rsp, 0x30
000071ff71bd6fa8  vmovaps xmm0, [rsp]
000071ff71bd6fad  vmovaps xmm1, [rsp+0x10]
000071ff71bd6fb3  vmovaps xmm2, [rsp+0x20]
000071ff71bd6fb9  vmovaps xmm3, [rsp+0x30]
000071ff71bd6fbf  vmovaps xmm4, [rsp+0x40]
000071ff71bd6fc5  vmovaps xmm5, [rsp+0x50]
000071ff71bd6fcb  vmovaps xmm6, [rsp+0x60]
000071ff71bd6fd1  vmovaps xmm7, [rsp+0x70]
000071ff71bd6fd7  vmovaps xmm8, [rsp+0x80]
000071ff71bd6fe0  vmovaps xmm9, [rsp+0x90]
000071ff71bd6fe9  vmovaps xmm10, [rsp+0xA0]
000071ff71bd6ff2  vmovaps xmm12, [rsp+0xB0]
000071ff71bd6ffb  vmovaps xmm13, [rsp+0xC0]
000071ff71bd7004  vmovaps xmm14, [rsp+0xD0]
000071ff71bd700d  vmovaps xmm15, [rsp+0xE0]
000071ff71bd7016  add rsp, 0xF0
000071ff71bd701d  pop r11
000071ff71bd701f  pop r10
000071ff71bd7021  pop r9
000071ff71bd7023  pop r8
000071ff71bd7025  pop rsi
000071ff71bd7026  pop rdi
000071ff71bd7027  pop rdx
000071ff71bd7028  pop rcx
000071ff71bd7029  pop rax
000071ff71bd702a  add rsp, 0x08
000071ff71bd702e  jmp 0x000071FF71BD327A
000071ff71bd7033  sub rsp, 0x08
000071ff71bd7037  push rax
000071ff71bd7038  push rcx
000071ff71bd7039  push rdx
000071ff71bd703a  push rdi
000071ff71bd703b  push rsi
000071ff71bd703c  push r8
000071ff71bd703e  push r9
000071ff71bd7040  push r10
000071ff71bd7042  push r11
000071ff71bd7044  sub rsp, 0xF0
000071ff71bd704b  vmovaps [rsp], xmm0
000071ff71bd7050  vmovaps [rsp+0x10], xmm1
000071ff71bd7056  vmovaps [rsp+0x20], xmm2
000071ff71bd705c  vmovaps [rsp+0x30], xmm3
000071ff71bd7062  vmovaps [rsp+0x40], xmm4
000071ff71bd7068  vmovaps [rsp+0x50], xmm5
000071ff71bd706e  vmovaps [rsp+0x60], xmm6
000071ff71bd7074  vmovaps [rsp+0x70], xmm7
000071ff71bd707a  vmovaps [rsp+0x80], xmm8
000071ff71bd7083  vmovaps [rsp+0x90], xmm9
000071ff71bd708c  vmovaps [rsp+0xA0], xmm10
000071ff71bd7095  vmovaps [rsp+0xB0], xmm11
000071ff71bd709e  vmovaps [rsp+0xC0], xmm13
000071ff71bd70a7  vmovaps [rsp+0xD0], xmm14
000071ff71bd70b0  vmovaps [rsp+0xE0], xmm15
000071ff71bd70b9  sub rsp, 0x30
000071ff71bd70bd  movaps [rsp], xmm12
000071ff71bd70c2  movaps [rsp+0x10], xmm8
000071ff71bd70c8  movaps [rsp+0x20], xmm15
000071ff71bd70ce  lea rdi, [rsp]
000071ff71bd70d2  mov esi, 0x00
000071ff71bd70d7  mov rax, 0x5E6872E10530
000071ff71bd70e1  call rax
000071ff71bd70e3  movaps xmm12, [rsp]
000071ff71bd70e8  add rsp, 0x30
000071ff71bd70ec  vmovaps xmm0, [rsp]
000071ff71bd70f1  vmovaps xmm1, [rsp+0x10]
000071ff71bd70f7  vmovaps xmm2, [rsp+0x20]
000071ff71bd70fd  vmovaps xmm3, [rsp+0x30]
000071ff71bd7103  vmovaps xmm4, [rsp+0x40]
000071ff71bd7109  vmovaps xmm5, [rsp+0x50]
000071ff71bd710f  vmovaps xmm6, [rsp+0x60]
000071ff71bd7115  vmovaps xmm7, [rsp+0x70]
000071ff71bd711b  vmovaps xmm8, [rsp+0x80]
000071ff71bd7124  vmovaps xmm9, [rsp+0x90]
000071ff71bd712d  vmovaps xmm10, [rsp+0xA0]
000071ff71bd7136  vmovaps xmm11, [rsp+0xB0]
000071ff71bd713f  vmovaps xmm13, [rsp+0xC0]
000071ff71bd7148  vmovaps xmm14, [rsp+0xD0]
000071ff71bd7151  vmovaps xmm15, [rsp+0xE0]
000071ff71bd715a  add rsp, 0xF0
000071ff71bd7161  pop r11
000071ff71bd7163  pop r10
000071ff71bd7165  pop r9
000071ff71bd7167  pop r8
000071ff71bd7169  pop rsi
000071ff71bd716a  pop rdi
000071ff71bd716b  pop rdx
000071ff71bd716c  pop rcx
000071ff71bd716d  pop rax
000071ff71bd716e  add rsp, 0x08
000071ff71bd7172  jmp 0x000071FF71BD32A9
000071ff71bd7177  sub rsp, 0x08
000071ff71bd717b  push rax
000071ff71bd717c  push rcx
000071ff71bd717d  push rdx
000071ff71bd717e  push rdi
000071ff71bd717f  push rsi
000071ff71bd7180  push r8
000071ff71bd7182  push r9
000071ff71bd7184  push r10
000071ff71bd7186  push r11
000071ff71bd7188  sub rsp, 0xF0
000071ff71bd718f  vmovaps [rsp], xmm0
000071ff71bd7194  vmovaps [rsp+0x10], xmm1
000071ff71bd719a  vmovaps [rsp+0x20], xmm2
000071ff71bd71a0  vmovaps [rsp+0x30], xmm3
000071ff71bd71a6  vmovaps [rsp+0x40], xmm4
000071ff71bd71ac  vmovaps [rsp+0x50], xmm5
000071ff71bd71b2  vmovaps [rsp+0x60], xmm6
000071ff71bd71b8  vmovaps [rsp+0x70], xmm7
000071ff71bd71be  vmovaps [rsp+0x80], xmm9
000071ff71bd71c7  vmovaps [rsp+0x90], xmm10
000071ff71bd71d0  vmovaps [rsp+0xA0], xmm11
000071ff71bd71d9  vmovaps [rsp+0xB0], xmm12
000071ff71bd71e2  vmovaps [rsp+0xC0], xmm13
000071ff71bd71eb  vmovaps [rsp+0xD0], xmm14
000071ff71bd71f4  vmovaps [rsp+0xE0], xmm15
000071ff71bd71fd  sub rsp, 0x30
000071ff71bd7201  movaps [rsp], xmm8
000071ff71bd7206  movaps [rsp+0x10], xmm7
000071ff71bd720b  movaps [rsp+0x20], xmm15
000071ff71bd7211  lea rdi, [rsp]
000071ff71bd7215  mov esi, 0x00
000071ff71bd721a  mov rax, 0x5E6872E10530
000071ff71bd7224  call rax
000071ff71bd7226  movaps xmm8, [rsp]
000071ff71bd722b  add rsp, 0x30
000071ff71bd722f  vmovaps xmm0, [rsp]
000071ff71bd7234  vmovaps xmm1, [rsp+0x10]
000071ff71bd723a  vmovaps xmm2, [rsp+0x20]
000071ff71bd7240  vmovaps xmm3, [rsp+0x30]
000071ff71bd7246  vmovaps xmm4, [rsp+0x40]
000071ff71bd724c  vmovaps xmm5, [rsp+0x50]
000071ff71bd7252  vmovaps xmm6, [rsp+0x60]
000071ff71bd7258  vmovaps xmm7, [rsp+0x70]
000071ff71bd725e  vmovaps xmm9, [rsp+0x80]
000071ff71bd7267  vmovaps xmm10, [rsp+0x90]
000071ff71bd7270  vmovaps xmm11, [rsp+0xA0]
000071ff71bd7279  vmovaps xmm12, [rsp+0xB0]
000071ff71bd7282  vmovaps xmm13, [rsp+0xC0]
000071ff71bd728b  vmovaps xmm14, [rsp+0xD0]
000071ff71bd7294  vmovaps xmm15, [rsp+0xE0]
000071ff71bd729d  add rsp, 0xF0
000071ff71bd72a4  pop r11
000071ff71bd72a6  pop r10
000071ff71bd72a8  pop r9
000071ff71bd72aa  pop r8
000071ff71bd72ac  pop rsi
000071ff71bd72ad  pop rdi
000071ff71bd72ae  pop rdx
000071ff71bd72af  pop rcx
000071ff71bd72b0  pop rax
000071ff71bd72b1  add rsp, 0x08
000071ff71bd72b5  jmp 0x000071FF71BD32CF
000071ff71bd72ba  sub rsp, 0x08
000071ff71bd72be  push rax
000071ff71bd72bf  push rcx
000071ff71bd72c0  push rdx
000071ff71bd72c1  push rdi
000071ff71bd72c2  push rsi
000071ff71bd72c3  push r8
000071ff71bd72c5  push r9
000071ff71bd72c7  push r10
000071ff71bd72c9  push r11
000071ff71bd72cb  sub rsp, 0xF0
000071ff71bd72d2  vmovaps [rsp], xmm0
000071ff71bd72d7  vmovaps [rsp+0x10], xmm1
000071ff71bd72dd  vmovaps [rsp+0x20], xmm2
000071ff71bd72e3  vmovaps [rsp+0x30], xmm3
000071ff71bd72e9  vmovaps [rsp+0x40], xmm4
000071ff71bd72ef  vmovaps [rsp+0x50], xmm5
000071ff71bd72f5  vmovaps [rsp+0x60], xmm6
000071ff71bd72fb  vmovaps [rsp+0x70], xmm7
000071ff71bd7301  vmovaps [rsp+0x80], xmm8
000071ff71bd730a  vmovaps [rsp+0x90], xmm9
000071ff71bd7313  vmovaps [rsp+0xA0], xmm10
000071ff71bd731c  vmovaps [rsp+0xB0], xmm11
000071ff71bd7325  vmovaps [rsp+0xC0], xmm12
000071ff71bd732e  vmovaps [rsp+0xD0], xmm13
000071ff71bd7337  vmovaps [rsp+0xE0], xmm14
000071ff71bd7340  sub rsp, 0x30
000071ff71bd7344  movaps [rsp], xmm15
000071ff71bd7349  movaps [rsp+0x10], xmm14
000071ff71bd734f  movaps [rsp+0x20], xmm9
000071ff71bd7355  lea rdi, [rsp]
000071ff71bd7359  mov esi, 0x00
000071ff71bd735e  mov rax, 0x5E6872E10530
000071ff71bd7368  call rax
000071ff71bd736a  movaps xmm15, [rsp]
000071ff71bd736f  add rsp, 0x30
000071ff71bd7373  vmovaps xmm0, [rsp]
000071ff71bd7378  vmovaps xmm1, [rsp+0x10]
000071ff71bd737e  vmovaps xmm2, [rsp+0x20]
000071ff71bd7384  vmovaps xmm3, [rsp+0x30]
000071ff71bd738a  vmovaps xmm4, [rsp+0x40]
000071ff71bd7390  vmovaps xmm5, [rsp+0x50]
000071ff71bd7396  vmovaps xmm6, [rsp+0x60]
000071ff71bd739c  vmovaps xmm7, [rsp+0x70]
000071ff71bd73a2  vmovaps xmm8, [rsp+0x80]
000071ff71bd73ab  vmovaps xmm9, [rsp+0x90]
000071ff71bd73b4  vmovaps xmm10, [rsp+0xA0]
000071ff71bd73bd  vmovaps xmm11, [rsp+0xB0]
000071ff71bd73c6  vmovaps xmm12, [rsp+0xC0]
000071ff71bd73cf  vmovaps xmm13, [rsp+0xD0]
000071ff71bd73d8  vmovaps xmm14, [rsp+0xE0]
000071ff71bd73e1  add rsp, 0xF0
000071ff71bd73e8  pop r11
000071ff71bd73ea  pop r10
000071ff71bd73ec  pop r9
000071ff71bd73ee  pop r8
000071ff71bd73f0  pop rsi
000071ff71bd73f1  pop rdi
000071ff71bd73f2  pop rdx
000071ff71bd73f3  pop rcx
000071ff71bd73f4  pop rax
000071ff71bd73f5  add rsp, 0x08
000071ff71bd73f9  jmp 0x000071FF71BD32E9
000071ff71bd73fe  sub rsp, 0x08
000071ff71bd7402  push rax
000071ff71bd7403  push rcx
000071ff71bd7404  push rdx
000071ff71bd7405  push rdi
000071ff71bd7406  push rsi
000071ff71bd7407  push r8
000071ff71bd7409  push r9
000071ff71bd740b  push r10
000071ff71bd740d  push r11
000071ff71bd740f  sub rsp, 0xF0
000071ff71bd7416  vmovaps [rsp], xmm0
000071ff71bd741b  vmovaps [rsp+0x10], xmm1
000071ff71bd7421  vmovaps [rsp+0x20], xmm2
000071ff71bd7427  vmovaps [rsp+0x30], xmm3
000071ff71bd742d  vmovaps [rsp+0x40], xmm4
000071ff71bd7433  vmovaps [rsp+0x50], xmm5
000071ff71bd7439  vmovaps [rsp+0x60], xmm6
000071ff71bd743f  vmovaps [rsp+0x70], xmm7
000071ff71bd7445  vmovaps [rsp+0x80], xmm8
000071ff71bd744e  vmovaps [rsp+0x90], xmm10
000071ff71bd7457  vmovaps [rsp+0xA0], xmm11
000071ff71bd7460  vmovaps [rsp+0xB0], xmm12
000071ff71bd7469  vmovaps [rsp+0xC0], xmm13
000071ff71bd7472  vmovaps [rsp+0xD0], xmm14
000071ff71bd747b  vmovaps [rsp+0xE0], xmm15
000071ff71bd7484  sub rsp, 0x30
000071ff71bd7488  movaps [rsp], xmm9
000071ff71bd748d  movaps [rsp+0x10], xmm7
000071ff71bd7492  movaps [rsp+0x20], xmm14
000071ff71bd7498  lea rdi, [rsp]
000071ff71bd749c  mov esi, 0x00
000071ff71bd74a1  mov rax, 0x5E6872E10530
000071ff71bd74ab  call rax
000071ff71bd74ad  movaps xmm9, [rsp]
000071ff71bd74b2  add rsp, 0x30
000071ff71bd74b6  vmovaps xmm0, [rsp]
000071ff71bd74bb  vmovaps xmm1, [rsp+0x10]
000071ff71bd74c1  vmovaps xmm2, [rsp+0x20]
000071ff71bd74c7  vmovaps xmm3, [rsp+0x30]
000071ff71bd74cd  vmovaps xmm4, [rsp+0x40]
000071ff71bd74d3  vmovaps xmm5, [rsp+0x50]
000071ff71bd74d9  vmovaps xmm6, [rsp+0x60]
000071ff71bd74df  vmovaps xmm7, [rsp+0x70]
000071ff71bd74e5  vmovaps xmm8, [rsp+0x80]
000071ff71bd74ee  vmovaps xmm10, [rsp+0x90]
000071ff71bd74f7  vmovaps xmm11, [rsp+0xA0]
000071ff71bd7500  vmovaps xmm12, [rsp+0xB0]
000071ff71bd7509  vmovaps xmm13, [rsp+0xC0]
000071ff71bd7512  vmovaps xmm14, [rsp+0xD0]
000071ff71bd751b  vmovaps xmm15, [rsp+0xE0]
000071ff71bd7524  add rsp, 0xF0
000071ff71bd752b  pop r11
000071ff71bd752d  pop r10
000071ff71bd752f  pop r9
000071ff71bd7531  pop r8
000071ff71bd7533  pop rsi
000071ff71bd7534  pop rdi
000071ff71bd7535  pop rdx
000071ff71bd7536  pop rcx
000071ff71bd7537  pop rax
000071ff71bd7538  add rsp, 0x08
000071ff71bd753c  jmp 0x000071FF71BD3318
000071ff71bd7541  sub rsp, 0x08
000071ff71bd7545  push rax
000071ff71bd7546  push rcx
000071ff71bd7547  push rdx
000071ff71bd7548  push rdi
000071ff71bd7549  push rsi
000071ff71bd754a  push r8
000071ff71bd754c  push r9
000071ff71bd754e  push r10
000071ff71bd7550  push r11
000071ff71bd7552  sub rsp, 0xF0
000071ff71bd7559  vmovaps [rsp], xmm0
000071ff71bd755e  vmovaps [rsp+0x10], xmm1
000071ff71bd7564  vmovaps [rsp+0x20], xmm2
000071ff71bd756a  vmovaps [rsp+0x30], xmm3
000071ff71bd7570  vmovaps [rsp+0x40], xmm4
000071ff71bd7576  vmovaps [rsp+0x50], xmm5
000071ff71bd757c  vmovaps [rsp+0x60], xmm6
000071ff71bd7582  vmovaps [rsp+0x70], xmm7
000071ff71bd7588  vmovaps [rsp+0x80], xmm8
000071ff71bd7591  vmovaps [rsp+0x90], xmm9
000071ff71bd759a  vmovaps [rsp+0xA0], xmm10
000071ff71bd75a3  vmovaps [rsp+0xB0], xmm11
000071ff71bd75ac  vmovaps [rsp+0xC0], xmm12
000071ff71bd75b5  vmovaps [rsp+0xD0], xmm13
000071ff71bd75be  vmovaps [rsp+0xE0], xmm15
000071ff71bd75c7  sub rsp, 0x30
000071ff71bd75cb  movaps [rsp], xmm14
000071ff71bd75d0  movaps [rsp+0x10], xmm13
000071ff71bd75d6  movaps [rsp+0x20], xmm11
000071ff71bd75dc  lea rdi, [rsp]
000071ff71bd75e0  mov esi, 0x00
000071ff71bd75e5  mov rax, 0x5E6872E10530
000071ff71bd75ef  call rax
000071ff71bd75f1  movaps xmm14, [rsp]
000071ff71bd75f6  add rsp, 0x30
000071ff71bd75fa  vmovaps xmm0, [rsp]
000071ff71bd75ff  vmovaps xmm1, [rsp+0x10]
000071ff71bd7605  vmovaps xmm2, [rsp+0x20]
000071ff71bd760b  vmovaps xmm3, [rsp+0x30]
000071ff71bd7611  vmovaps xmm4, [rsp+0x40]
000071ff71bd7617  vmovaps xmm5, [rsp+0x50]
000071ff71bd761d  vmovaps xmm6, [rsp+0x60]
000071ff71bd7623  vmovaps xmm7, [rsp+0x70]
000071ff71bd7629  vmovaps xmm8, [rsp+0x80]
000071ff71bd7632  vmovaps xmm9, [rsp+0x90]
000071ff71bd763b  vmovaps xmm10, [rsp+0xA0]
000071ff71bd7644  vmovaps xmm11, [rsp+0xB0]
000071ff71bd764d  vmovaps xmm12, [rsp+0xC0]
000071ff71bd7656  vmovaps xmm13, [rsp+0xD0]
000071ff71bd765f  vmovaps xmm15, [rsp+0xE0]
000071ff71bd7668  add rsp, 0xF0
000071ff71bd766f  pop r11
000071ff71bd7671  pop r10
000071ff71bd7673  pop r9
000071ff71bd7675  pop r8
000071ff71bd7677  pop rsi
000071ff71bd7678  pop rdi
000071ff71bd7679  pop rdx
000071ff71bd767a  pop rcx
000071ff71bd767b  pop rax
000071ff71bd767c  add rsp, 0x08
000071ff71bd7680  jmp 0x000071FF71BD3332
000071ff71bd7685  sub rsp, 0x08
000071ff71bd7689  push rax
000071ff71bd768a  push rcx
000071ff71bd768b  push rdx
000071ff71bd768c  push rdi
000071ff71bd768d  push rsi
000071ff71bd768e  push r8
000071ff71bd7690  push r9
000071ff71bd7692  push r10
000071ff71bd7694  push r11
000071ff71bd7696  sub rsp, 0xF0
000071ff71bd769d  vmovaps [rsp], xmm0
000071ff71bd76a2  vmovaps [rsp+0x10], xmm1
000071ff71bd76a8  vmovaps [rsp+0x20], xmm2
000071ff71bd76ae  vmovaps [rsp+0x30], xmm3
000071ff71bd76b4  vmovaps [rsp+0x40], xmm4
000071ff71bd76ba  vmovaps [rsp+0x50], xmm5
000071ff71bd76c0  vmovaps [rsp+0x60], xmm6
000071ff71bd76c6  vmovaps [rsp+0x70], xmm7
000071ff71bd76cc  vmovaps [rsp+0x80], xmm8
000071ff71bd76d5  vmovaps [rsp+0x90], xmm9
000071ff71bd76de  vmovaps [rsp+0xA0], xmm10
000071ff71bd76e7  vmovaps [rsp+0xB0], xmm12
000071ff71bd76f0  vmovaps [rsp+0xC0], xmm13
000071ff71bd76f9  vmovaps [rsp+0xD0], xmm14
000071ff71bd7702  vmovaps [rsp+0xE0], xmm15
000071ff71bd770b  sub rsp, 0x30
000071ff71bd770f  movaps [rsp], xmm11
000071ff71bd7714  movaps [rsp+0x10], xmm7
000071ff71bd7719  movaps [rsp+0x20], xmm13
000071ff71bd771f  lea rdi, [rsp]
000071ff71bd7723  mov esi, 0x00
000071ff71bd7728  mov rax, 0x5E6872E10530
000071ff71bd7732  call rax
000071ff71bd7734  movaps xmm11, [rsp]
000071ff71bd7739  add rsp, 0x30
000071ff71bd773d  vmovaps xmm0, [rsp]
000071ff71bd7742  vmovaps xmm1, [rsp+0x10]
000071ff71bd7748  vmovaps xmm2, [rsp+0x20]
000071ff71bd774e  vmovaps xmm3, [rsp+0x30]
000071ff71bd7754  vmovaps xmm4, [rsp+0x40]
000071ff71bd775a  vmovaps xmm5, [rsp+0x50]
000071ff71bd7760  vmovaps xmm6, [rsp+0x60]
000071ff71bd7766  vmovaps xmm7, [rsp+0x70]
000071ff71bd776c  vmovaps xmm8, [rsp+0x80]
000071ff71bd7775  vmovaps xmm9, [rsp+0x90]
000071ff71bd777e  vmovaps xmm10, [rsp+0xA0]
000071ff71bd7787  vmovaps xmm12, [rsp+0xB0]
000071ff71bd7790  vmovaps xmm13, [rsp+0xC0]
000071ff71bd7799  vmovaps xmm14, [rsp+0xD0]
000071ff71bd77a2  vmovaps xmm15, [rsp+0xE0]
000071ff71bd77ab  add rsp, 0xF0
000071ff71bd77b2  pop r11
000071ff71bd77b4  pop r10
000071ff71bd77b6  pop r9
000071ff71bd77b8  pop r8
000071ff71bd77ba  pop rsi
000071ff71bd77bb  pop rdi
000071ff71bd77bc  pop rdx
000071ff71bd77bd  pop rcx
000071ff71bd77be  pop rax
000071ff71bd77bf  add rsp, 0x08
000071ff71bd77c3  jmp 0x000071FF71BD335E
000071ff71bd77c8  sub rsp, 0x08
000071ff71bd77cc  push rax
000071ff71bd77cd  push rcx
000071ff71bd77ce  push rdx
000071ff71bd77cf  push rdi
000071ff71bd77d0  push rsi
000071ff71bd77d1  push r8
000071ff71bd77d3  push r9
000071ff71bd77d5  push r10
000071ff71bd77d7  push r11
000071ff71bd77d9  sub rsp, 0xF0
000071ff71bd77e0  vmovaps [rsp], xmm0
000071ff71bd77e5  vmovaps [rsp+0x10], xmm1
000071ff71bd77eb  vmovaps [rsp+0x20], xmm2
000071ff71bd77f1  vmovaps [rsp+0x30], xmm3
000071ff71bd77f7  vmovaps [rsp+0x40], xmm4
000071ff71bd77fd  vmovaps [rsp+0x50], xmm5
000071ff71bd7803  vmovaps [rsp+0x60], xmm6
000071ff71bd7809  vmovaps [rsp+0x70], xmm7
000071ff71bd780f  vmovaps [rsp+0x80], xmm8
000071ff71bd7818  vmovaps [rsp+0x90], xmm9
000071ff71bd7821  vmovaps [rsp+0xA0], xmm10
000071ff71bd782a  vmovaps [rsp+0xB0], xmm11
000071ff71bd7833  vmovaps [rsp+0xC0], xmm12
000071ff71bd783c  vmovaps [rsp+0xD0], xmm14
000071ff71bd7845  vmovaps [rsp+0xE0], xmm15
000071ff71bd784e  sub rsp, 0x30
000071ff71bd7852  movaps [rsp], xmm13
000071ff71bd7857  movaps [rsp+0x10], xmm10
000071ff71bd785d  movaps [rsp+0x20], xmm12
000071ff71bd7863  lea rdi, [rsp]
000071ff71bd7867  mov esi, 0x00
000071ff71bd786c  mov rax, 0x5E6872E10530
000071ff71bd7876  call rax
000071ff71bd7878  movaps xmm13, [rsp]
000071ff71bd787d  add rsp, 0x30
000071ff71bd7881  vmovaps xmm0, [rsp]
000071ff71bd7886  vmovaps xmm1, [rsp+0x10]
000071ff71bd788c  vmovaps xmm2, [rsp+0x20]
000071ff71bd7892  vmovaps xmm3, [rsp+0x30]
000071ff71bd7898  vmovaps xmm4, [rsp+0x40]
000071ff71bd789e  vmovaps xmm5, [rsp+0x50]
000071ff71bd78a4  vmovaps xmm6, [rsp+0x60]
000071ff71bd78aa  vmovaps xmm7, [rsp+0x70]
000071ff71bd78b0  vmovaps xmm8, [rsp+0x80]
000071ff71bd78b9  vmovaps xmm9, [rsp+0x90]
000071ff71bd78c2  vmovaps xmm10, [rsp+0xA0]
000071ff71bd78cb  vmovaps xmm11, [rsp+0xB0]
000071ff71bd78d4  vmovaps xmm12, [rsp+0xC0]
000071ff71bd78dd  vmovaps xmm14, [rsp+0xD0]
000071ff71bd78e6  vmovaps xmm15, [rsp+0xE0]
000071ff71bd78ef  add rsp, 0xF0
000071ff71bd78f6  pop r11
000071ff71bd78f8  pop r10
000071ff71bd78fa  pop r9
000071ff71bd78fc  pop r8
000071ff71bd78fe  pop rsi
000071ff71bd78ff  pop rdi
000071ff71bd7900  pop rdx
000071ff71bd7901  pop rcx
000071ff71bd7902  pop rax
000071ff71bd7903  add rsp, 0x08
000071ff71bd7907  jmp 0x000071FF71BD3378
000071ff71bd790c  sub rsp, 0x08
000071ff71bd7910  push rax
000071ff71bd7911  push rcx
000071ff71bd7912  push rdx
000071ff71bd7913  push rdi
000071ff71bd7914  push rsi
000071ff71bd7915  push r8
000071ff71bd7917  push r9
000071ff71bd7919  push r10
000071ff71bd791b  push r11
000071ff71bd791d  sub rsp, 0xF0
000071ff71bd7924  vmovaps [rsp], xmm0
000071ff71bd7929  vmovaps [rsp+0x10], xmm1
000071ff71bd792f  vmovaps [rsp+0x20], xmm2
000071ff71bd7935  vmovaps [rsp+0x30], xmm3
000071ff71bd793b  vmovaps [rsp+0x40], xmm4
000071ff71bd7941  vmovaps [rsp+0x50], xmm5
000071ff71bd7947  vmovaps [rsp+0x60], xmm6
000071ff71bd794d  vmovaps [rsp+0x70], xmm7
000071ff71bd7953  vmovaps [rsp+0x80], xmm8
000071ff71bd795c  vmovaps [rsp+0x90], xmm9
000071ff71bd7965  vmovaps [rsp+0xA0], xmm11
000071ff71bd796e  vmovaps [rsp+0xB0], xmm12
000071ff71bd7977  vmovaps [rsp+0xC0], xmm13
000071ff71bd7980  vmovaps [rsp+0xD0], xmm14
000071ff71bd7989  vmovaps [rsp+0xE0], xmm15
000071ff71bd7992  sub rsp, 0x30
000071ff71bd7996  movaps [rsp], xmm10
000071ff71bd799b  movaps [rsp+0x10], xmm7
000071ff71bd79a0  movaps [rsp+0x20], xmm12
000071ff71bd79a6  lea rdi, [rsp]
000071ff71bd79aa  mov esi, 0x00
000071ff71bd79af  mov rax, 0x5E6872E10530
000071ff71bd79b9  call rax
000071ff71bd79bb  movaps xmm10, [rsp]
000071ff71bd79c0  add rsp, 0x30
000071ff71bd79c4  vmovaps xmm0, [rsp]
000071ff71bd79c9  vmovaps xmm1, [rsp+0x10]
000071ff71bd79cf  vmovaps xmm2, [rsp+0x20]
000071ff71bd79d5  vmovaps xmm3, [rsp+0x30]
000071ff71bd79db  vmovaps xmm4, [rsp+0x40]
000071ff71bd79e1  vmovaps xmm5, [rsp+0x50]
000071ff71bd79e7  vmovaps xmm6, [rsp+0x60]
000071ff71bd79ed  vmovaps xmm7, [rsp+0x70]
000071ff71bd79f3  vmovaps xmm8, [rsp+0x80]
000071ff71bd79fc  vmovaps xmm9, [rsp+0x90]
000071ff71bd7a05  vmovaps xmm11, [rsp+0xA0]
000071ff71bd7a0e  vmovaps xmm12, [rsp+0xB0]
000071ff71bd7a17  vmovaps xmm13, [rsp+0xC0]
000071ff71bd7a20  vmovaps xmm14, [rsp+0xD0]
000071ff71bd7a29  vmovaps xmm15, [rsp+0xE0]
000071ff71bd7a32  add rsp, 0xF0
000071ff71bd7a39  pop r11
000071ff71bd7a3b  pop r10
000071ff71bd7a3d  pop r9
000071ff71bd7a3f  pop r8
000071ff71bd7a41  pop rsi
000071ff71bd7a42  pop rdi
000071ff71bd7a43  pop rdx
000071ff71bd7a44  pop rcx
000071ff71bd7a45  pop rax
000071ff71bd7a46  add rsp, 0x08
000071ff71bd7a4a  jmp 0x000071FF71BD33A4
000071ff71bd7a4f  sub rsp, 0x08
000071ff71bd7a53  push rax
000071ff71bd7a54  push rcx
000071ff71bd7a55  push rdx
000071ff71bd7a56  push rdi
000071ff71bd7a57  push rsi
000071ff71bd7a58  push r8
000071ff71bd7a5a  push r9
000071ff71bd7a5c  push r10
000071ff71bd7a5e  push r11
000071ff71bd7a60  sub rsp, 0xF0
000071ff71bd7a67  vmovaps [rsp], xmm0
000071ff71bd7a6c  vmovaps [rsp+0x10], xmm1
000071ff71bd7a72  vmovaps [rsp+0x20], xmm2
000071ff71bd7a78  vmovaps [rsp+0x30], xmm3
000071ff71bd7a7e  vmovaps [rsp+0x40], xmm4
000071ff71bd7a84  vmovaps [rsp+0x50], xmm5
000071ff71bd7a8a  vmovaps [rsp+0x60], xmm6
000071ff71bd7a90  vmovaps [rsp+0x70], xmm7
000071ff71bd7a96  vmovaps [rsp+0x80], xmm8
000071ff71bd7a9f  vmovaps [rsp+0x90], xmm9
000071ff71bd7aa8  vmovaps [rsp+0xA0], xmm10
000071ff71bd7ab1  vmovaps [rsp+0xB0], xmm11
000071ff71bd7aba  vmovaps [rsp+0xC0], xmm13
000071ff71bd7ac3  vmovaps [rsp+0xD0], xmm14
000071ff71bd7acc  vmovaps [rsp+0xE0], xmm15
000071ff71bd7ad5  sub rsp, 0x30
000071ff71bd7ad9  movaps [rsp], xmm12
000071ff71bd7ade  movaps [rsp+0x10], xmm1
000071ff71bd7ae3  movaps [rsp+0x20], xmm8
000071ff71bd7ae9  lea rdi, [rsp]
000071ff71bd7aed  mov esi, 0x00
000071ff71bd7af2  mov rax, 0x5E6872E10530
000071ff71bd7afc  call rax
000071ff71bd7afe  movaps xmm12, [rsp]
000071ff71bd7b03  add rsp, 0x30
000071ff71bd7b07  vmovaps xmm0, [rsp]
000071ff71bd7b0c  vmovaps xmm1, [rsp+0x10]
000071ff71bd7b12  vmovaps xmm2, [rsp+0x20]
000071ff71bd7b18  vmovaps xmm3, [rsp+0x30]
000071ff71bd7b1e  vmovaps xmm4, [rsp+0x40]
000071ff71bd7b24  vmovaps xmm5, [rsp+0x50]
000071ff71bd7b2a  vmovaps xmm6, [rsp+0x60]
000071ff71bd7b30  vmovaps xmm7, [rsp+0x70]
000071ff71bd7b36  vmovaps xmm8, [rsp+0x80]
000071ff71bd7b3f  vmovaps xmm9, [rsp+0x90]
000071ff71bd7b48  vmovaps xmm10, [rsp+0xA0]
000071ff71bd7b51  vmovaps xmm11, [rsp+0xB0]
000071ff71bd7b5a  vmovaps xmm13, [rsp+0xC0]
000071ff71bd7b63  vmovaps xmm14, [rsp+0xD0]
000071ff71bd7b6c  vmovaps xmm15, [rsp+0xE0]
000071ff71bd7b75  add rsp, 0xF0
000071ff71bd7b7c  pop r11
000071ff71bd7b7e  pop r10
000071ff71bd7b80  pop r9
000071ff71bd7b82  pop r8
000071ff71bd7b84  pop rsi
000071ff71bd7b85  pop rdi
000071ff71bd7b86  pop rdx
000071ff71bd7b87  pop rcx
000071ff71bd7b88  pop rax
000071ff71bd7b89  add rsp, 0x08
000071ff71bd7b8d  jmp 0x000071FF71BD33BE
000071ff71bd7b92  call 0x000071FF719FF430
000071ff71bd7b97  jmp 0x000071FF71BD33C8
000071ff71bd7b9c  sub rsp, 0x08
000071ff71bd7ba0  push rax
000071ff71bd7ba1  push rcx
000071ff71bd7ba2  push rdx
000071ff71bd7ba3  push rdi
000071ff71bd7ba4  push rsi
000071ff71bd7ba5  push r8
000071ff71bd7ba7  push r9
000071ff71bd7ba9  push r10
000071ff71bd7bab  push r11
000071ff71bd7bad  sub rsp, 0xF0
000071ff71bd7bb4  vmovaps [rsp], xmm0
000071ff71bd7bb9  vmovaps [rsp+0x10], xmm1
000071ff71bd7bbf  vmovaps [rsp+0x20], xmm2
000071ff71bd7bc5  vmovaps [rsp+0x30], xmm3
000071ff71bd7bcb  vmovaps [rsp+0x40], xmm4
000071ff71bd7bd1  vmovaps [rsp+0x50], xmm5
000071ff71bd7bd7  vmovaps [rsp+0x60], xmm6
000071ff71bd7bdd  vmovaps [rsp+0x70], xmm7
000071ff71bd7be3  vmovaps [rsp+0x80], xmm9
000071ff71bd7bec  vmovaps [rsp+0x90], xmm10
000071ff71bd7bf5  vmovaps [rsp+0xA0], xmm11
000071ff71bd7bfe  vmovaps [rsp+0xB0], xmm12
000071ff71bd7c07  vmovaps [rsp+0xC0], xmm13
000071ff71bd7c10  vmovaps [rsp+0xD0], xmm14
000071ff71bd7c19  vmovaps [rsp+0xE0], xmm15
000071ff71bd7c22  sub rsp, 0x30
000071ff71bd7c26  movaps [rsp], xmm8
000071ff71bd7c2b  movaps [rsp+0x10], xmm15
000071ff71bd7c31  movaps [rsp+0x20], xmm9
000071ff71bd7c37  lea rdi, [rsp]
000071ff71bd7c3b  mov esi, 0x00
000071ff71bd7c40  mov rax, 0x5E6872E10530
000071ff71bd7c4a  call rax
000071ff71bd7c4c  movaps xmm8, [rsp]
000071ff71bd7c51  add rsp, 0x30
000071ff71bd7c55  vmovaps xmm0, [rsp]
000071ff71bd7c5a  vmovaps xmm1, [rsp+0x10]
000071ff71bd7c60  vmovaps xmm2, [rsp+0x20]
000071ff71bd7c66  vmovaps xmm3, [rsp+0x30]
000071ff71bd7c6c  vmovaps xmm4, [rsp+0x40]
000071ff71bd7c72  vmovaps xmm5, [rsp+0x50]
000071ff71bd7c78  vmovaps xmm6, [rsp+0x60]
000071ff71bd7c7e  vmovaps xmm7, [rsp+0x70]
000071ff71bd7c84  vmovaps xmm9, [rsp+0x80]
000071ff71bd7c8d  vmovaps xmm10, [rsp+0x90]
000071ff71bd7c96  vmovaps xmm11, [rsp+0xA0]
000071ff71bd7c9f  vmovaps xmm12, [rsp+0xB0]
000071ff71bd7ca8  vmovaps xmm13, [rsp+0xC0]
000071ff71bd7cb1  vmovaps xmm14, [rsp+0xD0]
000071ff71bd7cba  vmovaps xmm15, [rsp+0xE0]
000071ff71bd7cc3  add rsp, 0xF0
000071ff71bd7cca  pop r11
000071ff71bd7ccc  pop r10
000071ff71bd7cce  pop r9
000071ff71bd7cd0  pop r8
000071ff71bd7cd2  pop rsi
000071ff71bd7cd3  pop rdi
000071ff71bd7cd4  pop rdx
000071ff71bd7cd5  pop rcx
000071ff71bd7cd6  pop rax
000071ff71bd7cd7  add rsp, 0x08
000071ff71bd7cdb  jmp 0x000071FF71BD33EA
000071ff71bd7ce0  sub rsp, 0x08
000071ff71bd7ce4  push rax
000071ff71bd7ce5  push rcx
000071ff71bd7ce6  push rdx
000071ff71bd7ce7  push rdi
000071ff71bd7ce8  push rsi
000071ff71bd7ce9  push r8
000071ff71bd7ceb  push r9
000071ff71bd7ced  push r10
000071ff71bd7cef  push r11
000071ff71bd7cf1  sub rsp, 0xF0
000071ff71bd7cf8  vmovaps [rsp], xmm0
000071ff71bd7cfd  vmovaps [rsp+0x10], xmm1
000071ff71bd7d03  vmovaps [rsp+0x20], xmm2
000071ff71bd7d09  vmovaps [rsp+0x30], xmm3
000071ff71bd7d0f  vmovaps [rsp+0x40], xmm4
000071ff71bd7d15  vmovaps [rsp+0x50], xmm5
000071ff71bd7d1b  vmovaps [rsp+0x60], xmm6
000071ff71bd7d21  vmovaps [rsp+0x70], xmm7
000071ff71bd7d27  vmovaps [rsp+0x80], xmm8
000071ff71bd7d30  vmovaps [rsp+0x90], xmm10
000071ff71bd7d39  vmovaps [rsp+0xA0], xmm11
000071ff71bd7d42  vmovaps [rsp+0xB0], xmm12
000071ff71bd7d4b  vmovaps [rsp+0xC0], xmm13
000071ff71bd7d54  vmovaps [rsp+0xD0], xmm14
000071ff71bd7d5d  vmovaps [rsp+0xE0], xmm15
000071ff71bd7d66  sub rsp, 0x30
000071ff71bd7d6a  movaps [rsp], xmm9
000071ff71bd7d6f  movaps [rsp+0x10], xmm1
000071ff71bd7d74  movaps [rsp+0x20], xmm15
000071ff71bd7d7a  lea rdi, [rsp]
000071ff71bd7d7e  mov esi, 0x00
000071ff71bd7d83  mov rax, 0x5E6872E10530
000071ff71bd7d8d  call rax
000071ff71bd7d8f  movaps xmm9, [rsp]
000071ff71bd7d94  add rsp, 0x30
000071ff71bd7d98  vmovaps xmm0, [rsp]
000071ff71bd7d9d  vmovaps xmm1, [rsp+0x10]
000071ff71bd7da3  vmovaps xmm2, [rsp+0x20]
000071ff71bd7da9  vmovaps xmm3, [rsp+0x30]
000071ff71bd7daf  vmovaps xmm4, [rsp+0x40]
000071ff71bd7db5  vmovaps xmm5, [rsp+0x50]
000071ff71bd7dbb  vmovaps xmm6, [rsp+0x60]
000071ff71bd7dc1  vmovaps xmm7, [rsp+0x70]
000071ff71bd7dc7  vmovaps xmm8, [rsp+0x80]
000071ff71bd7dd0  vmovaps xmm10, [rsp+0x90]
000071ff71bd7dd9  vmovaps xmm11, [rsp+0xA0]
000071ff71bd7de2  vmovaps xmm12, [rsp+0xB0]
000071ff71bd7deb  vmovaps xmm13, [rsp+0xC0]
000071ff71bd7df4  vmovaps xmm14, [rsp+0xD0]
000071ff71bd7dfd  vmovaps xmm15, [rsp+0xE0]
000071ff71bd7e06  add rsp, 0xF0
000071ff71bd7e0d  pop r11
000071ff71bd7e0f  pop r10
000071ff71bd7e11  pop r9
000071ff71bd7e13  pop r8
000071ff71bd7e15  pop rsi
000071ff71bd7e16  pop rdi
000071ff71bd7e17  pop rdx
000071ff71bd7e18  pop rcx
000071ff71bd7e19  pop rax
000071ff71bd7e1a  add rsp, 0x08
000071ff71bd7e1e  jmp 0x000071FF71BD3418
000071ff71bd7e23  sub rsp, 0x08
000071ff71bd7e27  push rax
000071ff71bd7e28  push rcx
000071ff71bd7e29  push rdx
000071ff71bd7e2a  push rdi
000071ff71bd7e2b  push rsi
000071ff71bd7e2c  push r8
000071ff71bd7e2e  push r9
000071ff71bd7e30  push r10
000071ff71bd7e32  push r11
000071ff71bd7e34  sub rsp, 0xF0
000071ff71bd7e3b  vmovaps [rsp], xmm0
000071ff71bd7e40  vmovaps [rsp+0x10], xmm1
000071ff71bd7e46  vmovaps [rsp+0x20], xmm2
000071ff71bd7e4c  vmovaps [rsp+0x30], xmm3
000071ff71bd7e52  vmovaps [rsp+0x40], xmm4
000071ff71bd7e58  vmovaps [rsp+0x50], xmm5
000071ff71bd7e5e  vmovaps [rsp+0x60], xmm6
000071ff71bd7e64  vmovaps [rsp+0x70], xmm7
000071ff71bd7e6a  vmovaps [rsp+0x80], xmm8
000071ff71bd7e73  vmovaps [rsp+0x90], xmm9
000071ff71bd7e7c  vmovaps [rsp+0xA0], xmm10
000071ff71bd7e85  vmovaps [rsp+0xB0], xmm11
000071ff71bd7e8e  vmovaps [rsp+0xC0], xmm12
000071ff71bd7e97  vmovaps [rsp+0xD0], xmm13
000071ff71bd7ea0  vmovaps [rsp+0xE0], xmm14
000071ff71bd7ea9  sub rsp, 0x30
000071ff71bd7ead  movaps [rsp], xmm15
000071ff71bd7eb2  movaps [rsp+0x10], xmm4
000071ff71bd7eb7  movaps [rsp+0x20], xmm1
000071ff71bd7ebc  lea rdi, [rsp]
000071ff71bd7ec0  mov esi, 0x00
000071ff71bd7ec5  mov rax, 0x5E6872E10530
000071ff71bd7ecf  call rax
000071ff71bd7ed1  movaps xmm15, [rsp]
000071ff71bd7ed6  add rsp, 0x30
000071ff71bd7eda  vmovaps xmm0, [rsp]
000071ff71bd7edf  vmovaps xmm1, [rsp+0x10]
000071ff71bd7ee5  vmovaps xmm2, [rsp+0x20]
000071ff71bd7eeb  vmovaps xmm3, [rsp+0x30]
000071ff71bd7ef1  vmovaps xmm4, [rsp+0x40]
000071ff71bd7ef7  vmovaps xmm5, [rsp+0x50]
000071ff71bd7efd  vmovaps xmm6, [rsp+0x60]
000071ff71bd7f03  vmovaps xmm7, [rsp+0x70]
000071ff71bd7f09  vmovaps xmm8, [rsp+0x80]
000071ff71bd7f12  vmovaps xmm9, [rsp+0x90]
000071ff71bd7f1b  vmovaps xmm10, [rsp+0xA0]
000071ff71bd7f24  vmovaps xmm11, [rsp+0xB0]
000071ff71bd7f2d  vmovaps xmm12, [rsp+0xC0]
000071ff71bd7f36  vmovaps xmm13, [rsp+0xD0]
000071ff71bd7f3f  vmovaps xmm14, [rsp+0xE0]
000071ff71bd7f48  add rsp, 0xF0
000071ff71bd7f4f  pop r11
000071ff71bd7f51  pop r10
000071ff71bd7f53  pop r9
000071ff71bd7f55  pop r8
000071ff71bd7f57  pop rsi
000071ff71bd7f58  pop rdi
000071ff71bd7f59  pop rdx
000071ff71bd7f5a  pop rcx
000071ff71bd7f5b  pop rax
000071ff71bd7f5c  add rsp, 0x08
000071ff71bd7f60  jmp 0x000071FF71BD343E
000071ff71bd7f65  sub rsp, 0x08
000071ff71bd7f69  push rax
000071ff71bd7f6a  push rcx
000071ff71bd7f6b  push rdx
000071ff71bd7f6c  push rdi
000071ff71bd7f6d  push rsi
000071ff71bd7f6e  push r8
000071ff71bd7f70  push r9
000071ff71bd7f72  push r10
000071ff71bd7f74  push r11
000071ff71bd7f76  sub rsp, 0xF0
000071ff71bd7f7d  vmovaps [rsp], xmm0
000071ff71bd7f82  vmovaps [rsp+0x10], xmm2
000071ff71bd7f88  vmovaps [rsp+0x20], xmm3
000071ff71bd7f8e  vmovaps [rsp+0x30], xmm4
000071ff71bd7f94  vmovaps [rsp+0x40], xmm5
000071ff71bd7f9a  vmovaps [rsp+0x50], xmm6
000071ff71bd7fa0  vmovaps [rsp+0x60], xmm7
000071ff71bd7fa6  vmovaps [rsp+0x70], xmm8
000071ff71bd7fac  vmovaps [rsp+0x80], xmm9
000071ff71bd7fb5  vmovaps [rsp+0x90], xmm10
000071ff71bd7fbe  vmovaps [rsp+0xA0], xmm11
000071ff71bd7fc7  vmovaps [rsp+0xB0], xmm12
000071ff71bd7fd0  vmovaps [rsp+0xC0], xmm13
000071ff71bd7fd9  vmovaps [rsp+0xD0], xmm14
000071ff71bd7fe2  vmovaps [rsp+0xE0], xmm15
000071ff71bd7feb  sub rsp, 0x30
000071ff71bd7fef  movaps [rsp], xmm1
000071ff71bd7ff3  movaps [rsp+0x10], xmm14
000071ff71bd7ff9  movaps [rsp+0x20], xmm11
000071ff71bd7fff  lea rdi, [rsp]
000071ff71bd8003  mov esi, 0x00
000071ff71bd8008  mov rax, 0x5E6872E10530
000071ff71bd8012  call rax
000071ff71bd8014  movaps xmm1, [rsp]
000071ff71bd8018  add rsp, 0x30
000071ff71bd801c  vmovaps xmm0, [rsp]
000071ff71bd8021  vmovaps xmm2, [rsp+0x10]
000071ff71bd8027  vmovaps xmm3, [rsp+0x20]
000071ff71bd802d  vmovaps xmm4, [rsp+0x30]
000071ff71bd8033  vmovaps xmm5, [rsp+0x40]
000071ff71bd8039  vmovaps xmm6, [rsp+0x50]
000071ff71bd803f  vmovaps xmm7, [rsp+0x60]
000071ff71bd8045  vmovaps xmm8, [rsp+0x70]
000071ff71bd804b  vmovaps xmm9, [rsp+0x80]
000071ff71bd8054  vmovaps xmm10, [rsp+0x90]
000071ff71bd805d  vmovaps xmm11, [rsp+0xA0]
000071ff71bd8066  vmovaps xmm12, [rsp+0xB0]
000071ff71bd806f  vmovaps xmm13, [rsp+0xC0]
000071ff71bd8078  vmovaps xmm14, [rsp+0xD0]
000071ff71bd8081  vmovaps xmm15, [rsp+0xE0]
000071ff71bd808a  add rsp, 0xF0
000071ff71bd8091  pop r11
000071ff71bd8093  pop r10
000071ff71bd8095  pop r9
000071ff71bd8097  pop r8
000071ff71bd8099  pop rsi
000071ff71bd809a  pop rdi
000071ff71bd809b  pop rdx
000071ff71bd809c  pop rcx
000071ff71bd809d  pop rax
000071ff71bd809e  add rsp, 0x08
000071ff71bd80a2  jmp 0x000071FF71BD345F
000071ff71bd80a7  call 0x000071FF71AE45A0
000071ff71bd80ac  jmp 0x000071FF71BD346D
000071ff71bd80b1  call 0x000071FF71A09D70
000071ff71bd80b6  jmp 0x000071FF71BD3477
000071ff71bd80bb  sub rsp, 0x08
000071ff71bd80bf  push rax
000071ff71bd80c0  push rcx
000071ff71bd80c1  push rdx
000071ff71bd80c2  push rdi
000071ff71bd80c3  push rsi
000071ff71bd80c4  push r8
000071ff71bd80c6  push r9
000071ff71bd80c8  push r10
000071ff71bd80ca  push r11
000071ff71bd80cc  sub rsp, 0xF0
000071ff71bd80d3  vmovaps [rsp], xmm0
000071ff71bd80d8  vmovaps [rsp+0x10], xmm1
000071ff71bd80de  vmovaps [rsp+0x20], xmm2
000071ff71bd80e4  vmovaps [rsp+0x30], xmm3
000071ff71bd80ea  vmovaps [rsp+0x40], xmm4
000071ff71bd80f0  vmovaps [rsp+0x50], xmm5
000071ff71bd80f6  vmovaps [rsp+0x60], xmm6
000071ff71bd80fc  vmovaps [rsp+0x70], xmm8
000071ff71bd8102  vmovaps [rsp+0x80], xmm9
000071ff71bd810b  vmovaps [rsp+0x90], xmm10
000071ff71bd8114  vmovaps [rsp+0xA0], xmm11
000071ff71bd811d  vmovaps [rsp+0xB0], xmm12
000071ff71bd8126  vmovaps [rsp+0xC0], xmm13
000071ff71bd812f  vmovaps [rsp+0xD0], xmm14
000071ff71bd8138  vmovaps [rsp+0xE0], xmm15
000071ff71bd8141  sub rsp, 0x30
000071ff71bd8145  movaps [rsp], xmm7
000071ff71bd8149  movaps [rsp+0x10], xmm13
000071ff71bd814f  movaps [rsp+0x20], xmm10
000071ff71bd8155  lea rdi, [rsp]
000071ff71bd8159  mov esi, 0x00
000071ff71bd815e  mov rax, 0x5E6872E10530
000071ff71bd8168  call rax
000071ff71bd816a  movaps xmm7, [rsp]
000071ff71bd816e  add rsp, 0x30
000071ff71bd8172  vmovaps xmm0, [rsp]
000071ff71bd8177  vmovaps xmm1, [rsp+0x10]
000071ff71bd817d  vmovaps xmm2, [rsp+0x20]
000071ff71bd8183  vmovaps xmm3, [rsp+0x30]
000071ff71bd8189  vmovaps xmm4, [rsp+0x40]
000071ff71bd818f  vmovaps xmm5, [rsp+0x50]
000071ff71bd8195  vmovaps xmm6, [rsp+0x60]
000071ff71bd819b  vmovaps xmm8, [rsp+0x70]
000071ff71bd81a1  vmovaps xmm9, [rsp+0x80]
000071ff71bd81aa  vmovaps xmm10, [rsp+0x90]
000071ff71bd81b3  vmovaps xmm11, [rsp+0xA0]
000071ff71bd81bc  vmovaps xmm12, [rsp+0xB0]
000071ff71bd81c5  vmovaps xmm13, [rsp+0xC0]
000071ff71bd81ce  vmovaps xmm14, [rsp+0xD0]
000071ff71bd81d7  vmovaps xmm15, [rsp+0xE0]
000071ff71bd81e0  add rsp, 0xF0
000071ff71bd81e7  pop r11
000071ff71bd81e9  pop r10
000071ff71bd81eb  pop r9
000071ff71bd81ed  pop r8
000071ff71bd81ef  pop rsi
000071ff71bd81f0  pop rdi
000071ff71bd81f1  pop rdx
000071ff71bd81f2  pop rcx
000071ff71bd81f3  pop rax
000071ff71bd81f4  add rsp, 0x08
000071ff71bd81f8  jmp 0x000071FF71BD3498
000071ff71bd81fd  sub rsp, 0x08
000071ff71bd8201  push rax
000071ff71bd8202  push rcx
000071ff71bd8203  push rdx
000071ff71bd8204  push rdi
000071ff71bd8205  push rsi
000071ff71bd8206  push r8
000071ff71bd8208  push r9
000071ff71bd820a  push r10
000071ff71bd820c  push r11
000071ff71bd820e  sub rsp, 0xF0
000071ff71bd8215  vmovaps [rsp], xmm0
000071ff71bd821a  vmovaps [rsp+0x10], xmm1
000071ff71bd8220  vmovaps [rsp+0x20], xmm2
000071ff71bd8226  vmovaps [rsp+0x30], xmm3
000071ff71bd822c  vmovaps [rsp+0x40], xmm4
000071ff71bd8232  vmovaps [rsp+0x50], xmm5
000071ff71bd8238  vmovaps [rsp+0x60], xmm6
000071ff71bd823e  vmovaps [rsp+0x70], xmm7
000071ff71bd8244  vmovaps [rsp+0x80], xmm8
000071ff71bd824d  vmovaps [rsp+0x90], xmm9
000071ff71bd8256  vmovaps [rsp+0xA0], xmm11
000071ff71bd825f  vmovaps [rsp+0xB0], xmm12
000071ff71bd8268  vmovaps [rsp+0xC0], xmm13
000071ff71bd8271  vmovaps [rsp+0xD0], xmm14
000071ff71bd827a  vmovaps [rsp+0xE0], xmm15
000071ff71bd8283  sub rsp, 0x30
000071ff71bd8287  movaps [rsp], xmm10
000071ff71bd828c  movaps [rsp+0x10], xmm11
000071ff71bd8292  movaps [rsp+0x20], xmm13
000071ff71bd8298  lea rdi, [rsp]
000071ff71bd829c  mov esi, 0x00
000071ff71bd82a1  mov rax, 0x5E6872E10530
000071ff71bd82ab  call rax
000071ff71bd82ad  movaps xmm10, [rsp]
000071ff71bd82b2  add rsp, 0x30
000071ff71bd82b6  vmovaps xmm0, [rsp]
000071ff71bd82bb  vmovaps xmm1, [rsp+0x10]
000071ff71bd82c1  vmovaps xmm2, [rsp+0x20]
000071ff71bd82c7  vmovaps xmm3, [rsp+0x30]
000071ff71bd82cd  vmovaps xmm4, [rsp+0x40]
000071ff71bd82d3  vmovaps xmm5, [rsp+0x50]
000071ff71bd82d9  vmovaps xmm6, [rsp+0x60]
000071ff71bd82df  vmovaps xmm7, [rsp+0x70]
000071ff71bd82e5  vmovaps xmm8, [rsp+0x80]
000071ff71bd82ee  vmovaps xmm9, [rsp+0x90]
000071ff71bd82f7  vmovaps xmm11, [rsp+0xA0]
000071ff71bd8300  vmovaps xmm12, [rsp+0xB0]
000071ff71bd8309  vmovaps xmm13, [rsp+0xC0]
000071ff71bd8312  vmovaps xmm14, [rsp+0xD0]
000071ff71bd831b  vmovaps xmm15, [rsp+0xE0]
000071ff71bd8324  add rsp, 0xF0
000071ff71bd832b  pop r11
000071ff71bd832d  pop r10
000071ff71bd832f  pop r9
000071ff71bd8331  pop r8
000071ff71bd8333  pop rsi
000071ff71bd8334  pop rdi
000071ff71bd8335  pop rdx
000071ff71bd8336  pop rcx
000071ff71bd8337  pop rax
000071ff71bd8338  add rsp, 0x08
000071ff71bd833c  jmp 0x000071FF71BD34C6
000071ff71bd8341  sub rsp, 0x08
000071ff71bd8345  push rax
000071ff71bd8346  push rcx
000071ff71bd8347  push rdx
000071ff71bd8348  push rdi
000071ff71bd8349  push rsi
000071ff71bd834a  push r8
000071ff71bd834c  push r9
000071ff71bd834e  push r10
000071ff71bd8350  push r11
000071ff71bd8352  sub rsp, 0xF0
000071ff71bd8359  vmovaps [rsp], xmm0
000071ff71bd835e  vmovaps [rsp+0x10], xmm1
000071ff71bd8364  vmovaps [rsp+0x20], xmm2
000071ff71bd836a  vmovaps [rsp+0x30], xmm3
000071ff71bd8370  vmovaps [rsp+0x40], xmm4
000071ff71bd8376  vmovaps [rsp+0x50], xmm5
000071ff71bd837c  vmovaps [rsp+0x60], xmm6
000071ff71bd8382  vmovaps [rsp+0x70], xmm7
000071ff71bd8388  vmovaps [rsp+0x80], xmm8
000071ff71bd8391  vmovaps [rsp+0x90], xmm9
000071ff71bd839a  vmovaps [rsp+0xA0], xmm10
000071ff71bd83a3  vmovaps [rsp+0xB0], xmm12
000071ff71bd83ac  vmovaps [rsp+0xC0], xmm13
000071ff71bd83b5  vmovaps [rsp+0xD0], xmm14
000071ff71bd83be  vmovaps [rsp+0xE0], xmm15
000071ff71bd83c7  sub rsp, 0x30
000071ff71bd83cb  movaps [rsp], xmm11
000071ff71bd83d0  movaps [rsp+0x10], xmm14
000071ff71bd83d6  movaps [rsp+0x20], xmm13
000071ff71bd83dc  lea rdi, [rsp]
000071ff71bd83e0  mov esi, 0x00
000071ff71bd83e5  mov rax, 0x5E6872E10530
000071ff71bd83ef  call rax
000071ff71bd83f1  movaps xmm11, [rsp]
000071ff71bd83f6  add rsp, 0x30
000071ff71bd83fa  vmovaps xmm0, [rsp]
000071ff71bd83ff  vmovaps xmm1, [rsp+0x10]
000071ff71bd8405  vmovaps xmm2, [rsp+0x20]
000071ff71bd840b  vmovaps xmm3, [rsp+0x30]
000071ff71bd8411  vmovaps xmm4, [rsp+0x40]
000071ff71bd8417  vmovaps xmm5, [rsp+0x50]
000071ff71bd841d  vmovaps xmm6, [rsp+0x60]
000071ff71bd8423  vmovaps xmm7, [rsp+0x70]
000071ff71bd8429  vmovaps xmm8, [rsp+0x80]
000071ff71bd8432  vmovaps xmm9, [rsp+0x90]
000071ff71bd843b  vmovaps xmm10, [rsp+0xA0]
000071ff71bd8444  vmovaps xmm12, [rsp+0xB0]
000071ff71bd844d  vmovaps xmm13, [rsp+0xC0]
000071ff71bd8456  vmovaps xmm14, [rsp+0xD0]
000071ff71bd845f  vmovaps xmm15, [rsp+0xE0]
000071ff71bd8468  add rsp, 0xF0
000071ff71bd846f  pop r11
000071ff71bd8471  pop r10
000071ff71bd8473  pop r9
000071ff71bd8475  pop r8
000071ff71bd8477  pop rsi
000071ff71bd8478  pop rdi
000071ff71bd8479  pop rdx
000071ff71bd847a  pop rcx
000071ff71bd847b  pop rax
000071ff71bd847c  add rsp, 0x08
000071ff71bd8480  jmp 0x000071FF71BD34F4
000071ff71bd8485  sub rsp, 0x08
000071ff71bd8489  push rax
000071ff71bd848a  push rcx
000071ff71bd848b  push rdx
000071ff71bd848c  push rdi
000071ff71bd848d  push rsi
000071ff71bd848e  push r8
000071ff71bd8490  push r9
000071ff71bd8492  push r10
000071ff71bd8494  push r11
000071ff71bd8496  sub rsp, 0xF0
000071ff71bd849d  vmovaps [rsp], xmm0
000071ff71bd84a2  vmovaps [rsp+0x10], xmm1
000071ff71bd84a8  vmovaps [rsp+0x20], xmm2
000071ff71bd84ae  vmovaps [rsp+0x30], xmm3
000071ff71bd84b4  vmovaps [rsp+0x40], xmm4
000071ff71bd84ba  vmovaps [rsp+0x50], xmm5
000071ff71bd84c0  vmovaps [rsp+0x60], xmm6
000071ff71bd84c6  vmovaps [rsp+0x70], xmm7
000071ff71bd84cc  vmovaps [rsp+0x80], xmm8
000071ff71bd84d5  vmovaps [rsp+0x90], xmm9
000071ff71bd84de  vmovaps [rsp+0xA0], xmm10
000071ff71bd84e7  vmovaps [rsp+0xB0], xmm11
000071ff71bd84f0  vmovaps [rsp+0xC0], xmm12
000071ff71bd84f9  vmovaps [rsp+0xD0], xmm13
000071ff71bd8502  vmovaps [rsp+0xE0], xmm15
000071ff71bd850b  sub rsp, 0x30
000071ff71bd850f  movaps [rsp], xmm14
000071ff71bd8514  movaps [rsp+0x10], xmm12
000071ff71bd851a  movaps [rsp+0x20], xmm9
000071ff71bd8520  lea rdi, [rsp]
000071ff71bd8524  mov esi, 0x00
000071ff71bd8529  mov rax, 0x5E6872E10530
000071ff71bd8533  call rax
000071ff71bd8535  movaps xmm14, [rsp]
000071ff71bd853a  add rsp, 0x30
000071ff71bd853e  vmovaps xmm0, [rsp]
000071ff71bd8543  vmovaps xmm1, [rsp+0x10]
000071ff71bd8549  vmovaps xmm2, [rsp+0x20]
000071ff71bd854f  vmovaps xmm3, [rsp+0x30]
000071ff71bd8555  vmovaps xmm4, [rsp+0x40]
000071ff71bd855b  vmovaps xmm5, [rsp+0x50]
000071ff71bd8561  vmovaps xmm6, [rsp+0x60]
000071ff71bd8567  vmovaps xmm7, [rsp+0x70]
000071ff71bd856d  vmovaps xmm8, [rsp+0x80]
000071ff71bd8576  vmovaps xmm9, [rsp+0x90]
000071ff71bd857f  vmovaps xmm10, [rsp+0xA0]
000071ff71bd8588  vmovaps xmm11, [rsp+0xB0]
000071ff71bd8591  vmovaps xmm12, [rsp+0xC0]
000071ff71bd859a  vmovaps xmm13, [rsp+0xD0]
000071ff71bd85a3  vmovaps xmm15, [rsp+0xE0]
000071ff71bd85ac  add rsp, 0xF0
000071ff71bd85b3  pop r11
000071ff71bd85b5  pop r10
000071ff71bd85b7  pop r9
000071ff71bd85b9  pop r8
000071ff71bd85bb  pop rsi
000071ff71bd85bc  pop rdi
000071ff71bd85bd  pop rdx
000071ff71bd85be  pop rcx
000071ff71bd85bf  pop rax
000071ff71bd85c0  add rsp, 0x08
000071ff71bd85c4  jmp 0x000071FF71BD350F
000071ff71bd85c9  sub rsp, 0x08
000071ff71bd85cd  push rax
000071ff71bd85ce  push rcx
000071ff71bd85cf  push rdx
000071ff71bd85d0  push rdi
000071ff71bd85d1  push rsi
000071ff71bd85d2  push r8
000071ff71bd85d4  push r9
000071ff71bd85d6  push r10
000071ff71bd85d8  push r11
000071ff71bd85da  sub rsp, 0xF0
000071ff71bd85e1  vmovaps [rsp], xmm0
000071ff71bd85e6  vmovaps [rsp+0x10], xmm1
000071ff71bd85ec  vmovaps [rsp+0x20], xmm2
000071ff71bd85f2  vmovaps [rsp+0x30], xmm3
000071ff71bd85f8  vmovaps [rsp+0x40], xmm4
000071ff71bd85fe  vmovaps [rsp+0x50], xmm5
000071ff71bd8604  vmovaps [rsp+0x60], xmm6
000071ff71bd860a  vmovaps [rsp+0x70], xmm7
000071ff71bd8610  vmovaps [rsp+0x80], xmm8
000071ff71bd8619  vmovaps [rsp+0x90], xmm9
000071ff71bd8622  vmovaps [rsp+0xA0], xmm10
000071ff71bd862b  vmovaps [rsp+0xB0], xmm11
000071ff71bd8634  vmovaps [rsp+0xC0], xmm12
000071ff71bd863d  vmovaps [rsp+0xD0], xmm14
000071ff71bd8646  vmovaps [rsp+0xE0], xmm15
000071ff71bd864f  sub rsp, 0x30
000071ff71bd8653  movaps [rsp], xmm13
000071ff71bd8658  movaps [rsp+0x10], xmm8
000071ff71bd865e  movaps [rsp+0x20], xmm15
000071ff71bd8664  lea rdi, [rsp]
000071ff71bd8668  mov esi, 0x00
000071ff71bd866d  mov rax, 0x5E6872E10530
000071ff71bd8677  call rax
000071ff71bd8679  movaps xmm13, [rsp]
000071ff71bd867e  add rsp, 0x30
000071ff71bd8682  vmovaps xmm0, [rsp]
000071ff71bd8687  vmovaps xmm1, [rsp+0x10]
000071ff71bd868d  vmovaps xmm2, [rsp+0x20]
000071ff71bd8693  vmovaps xmm3, [rsp+0x30]
000071ff71bd8699  vmovaps xmm4, [rsp+0x40]
000071ff71bd869f  vmovaps xmm5, [rsp+0x50]
000071ff71bd86a5  vmovaps xmm6, [rsp+0x60]
000071ff71bd86ab  vmovaps xmm7, [rsp+0x70]
000071ff71bd86b1  vmovaps xmm8, [rsp+0x80]
000071ff71bd86ba  vmovaps xmm9, [rsp+0x90]
000071ff71bd86c3  vmovaps xmm10, [rsp+0xA0]
000071ff71bd86cc  vmovaps xmm11, [rsp+0xB0]
000071ff71bd86d5  vmovaps xmm12, [rsp+0xC0]
000071ff71bd86de  vmovaps xmm14, [rsp+0xD0]
000071ff71bd86e7  vmovaps xmm15, [rsp+0xE0]
000071ff71bd86f0  add rsp, 0xF0
000071ff71bd86f7  pop r11
000071ff71bd86f9  pop r10
000071ff71bd86fb  pop r9
000071ff71bd86fd  pop r8
000071ff71bd86ff  pop rsi
000071ff71bd8700  pop rdi
000071ff71bd8701  pop rdx
000071ff71bd8702  pop rcx
000071ff71bd8703  pop rax
000071ff71bd8704  add rsp, 0x08
000071ff71bd8708  jmp 0x000071FF71BD3532
000071ff71bd870d  sub rsp, 0x08
000071ff71bd8711  push rax
000071ff71bd8712  push rcx
000071ff71bd8713  push rdx
000071ff71bd8714  push rdi
000071ff71bd8715  push rsi
000071ff71bd8716  push r8
000071ff71bd8718  push r9
000071ff71bd871a  push r10
000071ff71bd871c  push r11
000071ff71bd871e  sub rsp, 0xF0
000071ff71bd8725  vmovaps [rsp], xmm0
000071ff71bd872a  vmovaps [rsp+0x10], xmm1
000071ff71bd8730  vmovaps [rsp+0x20], xmm2
000071ff71bd8736  vmovaps [rsp+0x30], xmm3
000071ff71bd873c  vmovaps [rsp+0x40], xmm4
000071ff71bd8742  vmovaps [rsp+0x50], xmm5
000071ff71bd8748  vmovaps [rsp+0x60], xmm6
000071ff71bd874e  vmovaps [rsp+0x70], xmm7
000071ff71bd8754  vmovaps [rsp+0x80], xmm8
000071ff71bd875d  vmovaps [rsp+0x90], xmm9
000071ff71bd8766  vmovaps [rsp+0xA0], xmm10
000071ff71bd876f  vmovaps [rsp+0xB0], xmm11
000071ff71bd8778  vmovaps [rsp+0xC0], xmm12
000071ff71bd8781  vmovaps [rsp+0xD0], xmm13
000071ff71bd878a  vmovaps [rsp+0xE0], xmm14
000071ff71bd8793  sub rsp, 0x30
000071ff71bd8797  movaps [rsp], xmm15
000071ff71bd879c  movaps [rsp+0x10], xmm1
000071ff71bd87a1  movaps [rsp+0x20], xmm10
000071ff71bd87a7  lea rdi, [rsp]
000071ff71bd87ab  mov esi, 0x00
000071ff71bd87b0  mov rax, 0x5E6872E10530
000071ff71bd87ba  call rax
000071ff71bd87bc  movaps xmm15, [rsp]
000071ff71bd87c1  add rsp, 0x30
000071ff71bd87c5  vmovaps xmm0, [rsp]
000071ff71bd87ca  vmovaps xmm1, [rsp+0x10]
000071ff71bd87d0  vmovaps xmm2, [rsp+0x20]
000071ff71bd87d6  vmovaps xmm3, [rsp+0x30]
000071ff71bd87dc  vmovaps xmm4, [rsp+0x40]
000071ff71bd87e2  vmovaps xmm5, [rsp+0x50]
000071ff71bd87e8  vmovaps xmm6, [rsp+0x60]
000071ff71bd87ee  vmovaps xmm7, [rsp+0x70]
000071ff71bd87f4  vmovaps xmm8, [rsp+0x80]
000071ff71bd87fd  vmovaps xmm9, [rsp+0x90]
000071ff71bd8806  vmovaps xmm10, [rsp+0xA0]
000071ff71bd880f  vmovaps xmm11, [rsp+0xB0]
000071ff71bd8818  vmovaps xmm12, [rsp+0xC0]
000071ff71bd8821  vmovaps xmm13, [rsp+0xD0]
000071ff71bd882a  vmovaps xmm14, [rsp+0xE0]
000071ff71bd8833  add rsp, 0xF0
000071ff71bd883a  pop r11
000071ff71bd883c  pop r10
000071ff71bd883e  pop r9
000071ff71bd8840  pop r8
000071ff71bd8842  pop rsi
000071ff71bd8843  pop rdi
000071ff71bd8844  pop rdx
000071ff71bd8845  pop rcx
000071ff71bd8846  pop rax
000071ff71bd8847  add rsp, 0x08
000071ff71bd884b  jmp 0x000071FF71BD3555
000071ff71bd8850  sub rsp, 0x08
000071ff71bd8854  push rax
000071ff71bd8855  push rcx
000071ff71bd8856  push rdx
000071ff71bd8857  push rdi
000071ff71bd8858  push rsi
000071ff71bd8859  push r8
000071ff71bd885b  push r9
000071ff71bd885d  push r10
000071ff71bd885f  push r11
000071ff71bd8861  sub rsp, 0xF0
000071ff71bd8868  vmovaps [rsp], xmm0
000071ff71bd886d  vmovaps [rsp+0x10], xmm2
000071ff71bd8873  vmovaps [rsp+0x20], xmm3
000071ff71bd8879  vmovaps [rsp+0x30], xmm4
000071ff71bd887f  vmovaps [rsp+0x40], xmm5
000071ff71bd8885  vmovaps [rsp+0x50], xmm6
000071ff71bd888b  vmovaps [rsp+0x60], xmm7
000071ff71bd8891  vmovaps [rsp+0x70], xmm8
000071ff71bd8897  vmovaps [rsp+0x80], xmm9
000071ff71bd88a0  vmovaps [rsp+0x90], xmm10
000071ff71bd88a9  vmovaps [rsp+0xA0], xmm11
000071ff71bd88b2  vmovaps [rsp+0xB0], xmm12
000071ff71bd88bb  vmovaps [rsp+0xC0], xmm13
000071ff71bd88c4  vmovaps [rsp+0xD0], xmm14
000071ff71bd88cd  vmovaps [rsp+0xE0], xmm15
000071ff71bd88d6  sub rsp, 0x30
000071ff71bd88da  movaps [rsp], xmm1
000071ff71bd88de  movaps [rsp+0x10], xmm7
000071ff71bd88e3  movaps [rsp+0x20], xmm11
000071ff71bd88e9  lea rdi, [rsp]
000071ff71bd88ed  mov esi, 0x00
000071ff71bd88f2  mov rax, 0x5E6872E10530
000071ff71bd88fc  call rax
000071ff71bd88fe  movaps xmm1, [rsp]
000071ff71bd8902  add rsp, 0x30
000071ff71bd8906  vmovaps xmm0, [rsp]
000071ff71bd890b  vmovaps xmm2, [rsp+0x10]
000071ff71bd8911  vmovaps xmm3, [rsp+0x20]
000071ff71bd8917  vmovaps xmm4, [rsp+0x30]
000071ff71bd891d  vmovaps xmm5, [rsp+0x40]
000071ff71bd8923  vmovaps xmm6, [rsp+0x50]
000071ff71bd8929  vmovaps xmm7, [rsp+0x60]
000071ff71bd892f  vmovaps xmm8, [rsp+0x70]
000071ff71bd8935  vmovaps xmm9, [rsp+0x80]
000071ff71bd893e  vmovaps xmm10, [rsp+0x90]
000071ff71bd8947  vmovaps xmm11, [rsp+0xA0]
000071ff71bd8950  vmovaps xmm12, [rsp+0xB0]
000071ff71bd8959  vmovaps xmm13, [rsp+0xC0]
000071ff71bd8962  vmovaps xmm14, [rsp+0xD0]
000071ff71bd896b  vmovaps xmm15, [rsp+0xE0]
000071ff71bd8974  add rsp, 0xF0
000071ff71bd897b  pop r11
000071ff71bd897d  pop r10
000071ff71bd897f  pop r9
000071ff71bd8981  pop r8
000071ff71bd8983  pop rsi
000071ff71bd8984  pop rdi
000071ff71bd8985  pop rdx
000071ff71bd8986  pop rcx
000071ff71bd8987  pop rax
000071ff71bd8988  add rsp, 0x08
000071ff71bd898c  jmp 0x000071FF71BD3576
000071ff71bd8991  call 0x000071FF71A0D600
000071ff71bd8996  jmp 0x000071FF71BD3589
000071ff71bd899b  call 0x000071FF71A0C380
000071ff71bd89a0  jmp 0x000071FF71BD3594
000071ff71bd89a5  call 0x000071FF71A0E880
000071ff71bd89aa  jmp 0x000071FF71BD359F
000071ff71bd89af  call 0x000071FF719FF540
000071ff71bd89b4  jmp 0x000071FF71BD35AA
000071ff71bd89b9  int3
000071ff71bd89ba  nop [rax+rax*1], ax
000071ff71bd89c0  mov rax, [r15+0x40]
000071ff71bd89c4  mov r14, [r15+0x58]
000071ff71bd89c8  lea r12, [rax+r14*1]
000071ff71bd89cc  movaps xmm1, [r15+0x1D0]
000071ff71bd89d4  vmovaps [rsp+0x10], xmm1
000071ff71bd89da  vmovaps xmm15, [rsp+0x10]
000071ff71bd89e0  por xmm1, xmm15
000071ff71bd89e5  movaps xmm14, [r15+0x1A0]
000071ff71bd89ed  vmovaps [rsp+0x10], xmm14
000071ff71bd89f3  vmovaps xmm13, [rsp+0x10]
000071ff71bd89f9  por xmm14, xmm13
000071ff71bd89fe  lea rax, [r12+0x30]
000071ff71bd8a03  mov r11, [r13+rax*1]
000071ff71bd8a08  lea rax, [r12+0x38]
000071ff71bd8a0d  mov r10, [r13+rax*1]
000071ff71bd8a12  movq xmm13, r11
000071ff71bd8a17  movq xmm12, r10
000071ff71bd8a1c  movq xmm13, xmm13
000071ff71bd8a21  vmovaps [rsp+0x10], xmm13
000071ff71bd8a27  movq xmm13, xmm13
000071ff71bd8a2c  movaps [r15+0x130], xmm13
000071ff71bd8a34  movq xmm12, xmm12
000071ff71bd8a39  vmovaps [rsp+0x20], xmm12
000071ff71bd8a3f  movq xmm12, xmm12
000071ff71bd8a44  movaps [r15+0x280], xmm12
000071ff71bd8a4c  movaps xmm13, [r15+0x270]
000071ff71bd8a54  vmovaps [rsp+0x30], xmm13
000071ff71bd8a5a  vmovaps xmm12, [rsp+0x30]
000071ff71bd8a60  por xmm13, xmm12
000071ff71bd8a65  lea rax, [r12+0x20]
000071ff71bd8a6a  mov r11, [r13+rax*1]
000071ff71bd8a6f  lea rax, [r12+0x28]
000071ff71bd8a74  mov r10, [r13+rax*1]
000071ff71bd8a79  movq xmm12, r11
000071ff71bd8a7e  movq xmm11, r10
000071ff71bd8a83  movq xmm12, xmm12
000071ff71bd8a88  vmovaps [rsp+0x30], xmm12
000071ff71bd8a8e  movq xmm12, xmm12
000071ff71bd8a93  movaps [r15+0x150], xmm12
000071ff71bd8a9b  movq xmm11, xmm11
000071ff71bd8aa0  vmovaps [rsp+0x40], xmm11
000071ff71bd8aa6  movq xmm11, xmm11
000071ff71bd8aab  movaps [r15+0x140], xmm11
000071ff71bd8ab3  lea rax, [r12+0x10]
000071ff71bd8ab8  mov r11, [r13+rax*1]
000071ff71bd8abd  lea rax, [r12+0x18]
000071ff71bd8ac2  mov r10, [r13+rax*1]
000071ff71bd8ac7  movq xmm12, r11
000071ff71bd8acc  movq xmm11, r10
000071ff71bd8ad1  movq xmm12, xmm12
000071ff71bd8ad6  vmovaps [rsp+0x50], xmm12
000071ff71bd8adc  movq xmm12, xmm12
000071ff71bd8ae1  movaps [r15+0x170], xmm12
000071ff71bd8ae9  movq xmm11, xmm11
000071ff71bd8aee  vmovaps [rsp+0x60], xmm11
000071ff71bd8af4  movq xmm11, xmm11
000071ff71bd8af9  movaps [r15+0x160], xmm11
000071ff71bd8b01  mov rax, [r13+r12*1]
000071ff71bd8b06  vmovq xmm12, rax
000071ff71bd8b0b  vpbroadcastq xmm12, xmm12
000071ff71bd8b10  lea rax, [r12+0x08]
000071ff71bd8b15  mov r12, [r13+rax*1]
000071ff71bd8b1a  movq xmm11, r12
000071ff71bd8b1f  movaps [r15+0x230], xmm11
000071ff71bd8b27  mov rax, [r15+0xF8]
000071ff71bd8b2e  lea r12, [rax+0x50]
000071ff71bd8b32  movups xmm11, [r13+r12*1]
000071ff71bd8b38  lea r12, [rax+0x60]
000071ff71bd8b3c  movups xmm10, [r13+r12*1]
000071ff71bd8b42  lea r12, [rax+0x30]
000071ff71bd8b46  movups xmm9, [r13+r12*1]
000071ff71bd8b4c  mov r12, [r15+0x50]
000071ff71bd8b50  lea r11, [r12+r14*1]
000071ff71bd8b54  mov [r15+0x60], r11
000071ff71bd8b58  lea r12, [r14+0x40]
000071ff71bd8b5c  mov [r15+0x58], r12
000071ff71bd8b60  movaps xmm8, xmm12
000071ff71bd8b64  mulpd xmm8, xmm15
000071ff71bd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000071ff71bd8b6f  ptest xmm7, xmm7
000071ff71bd8b74  jnz 0x000071FF71BD9997
000071ff71bd8b7a  movq xmm15, qword ptr [r15+0x230]
000071ff71bd8b83  vmovaps [rsp+0x70], xmm15
000071ff71bd8b89  vpermilpd xmm15, xmm15, 0x00
000071ff71bd8b8f  movaps xmm7, xmm9
000071ff71bd8b93  mulpd xmm7, xmm15
000071ff71bd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000071ff71bd8b9d  ptest xmm6, xmm6
000071ff71bd8ba2  jnz 0x000071FF71BD9ADB
000071ff71bd8ba8  vxorps xmm15, xmm15, xmm15
000071ff71bd8bad  vpbroadcastq xmm15, xmm15
000071ff71bd8bb2  movaps xmm9, xmm12
000071ff71bd8bb6  mulpd xmm9, xmm10
000071ff71bd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000071ff71bd8bc1  ptest xmm6, xmm6
000071ff71bd8bc6  jnz 0x000071FF71BD9C1D
000071ff71bd8bcc  movaps xmm10, xmm12
000071ff71bd8bd0  mulpd xmm10, xmm11
000071ff71bd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000071ff71bd8bdb  ptest xmm6, xmm6
000071ff71bd8be0  jnz 0x000071FF71BD9D61
000071ff71bd8be6  movaps xmm11, [r15+0x1F0]
000071ff71bd8bee  movaps xmm6, xmm12
000071ff71bd8bf2  mulpd xmm6, xmm11
000071ff71bd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000071ff71bd8bfc  ptest xmm5, xmm5
000071ff71bd8c01  jnz 0x000071FF71BD9EA5
000071ff71bd8c07  movaps xmm12, [r15+0x2A0]
000071ff71bd8c0f  vmovaps [rsp+0x80], xmm12
000071ff71bd8c18  vmovaps xmm11, [rsp+0x80]
000071ff71bd8c21  por xmm12, xmm11
000071ff71bd8c26  movaps xmm11, [r15+0x250]
000071ff71bd8c2e  vmovaps [rsp+0x80], xmm11
000071ff71bd8c37  vmovaps xmm5, [rsp+0x80]
000071ff71bd8c40  por xmm11, xmm5
000071ff71bd8c45  vmovaps xmm4, [rsp+0x70]
000071ff71bd8c4b  vpermilpd xmm4, xmm4, 0x00
000071ff71bd8c51  movaps xmm3, xmm5
000071ff71bd8c54  mulpd xmm3, xmm4
000071ff71bd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000071ff71bd8c5d  ptest xmm2, xmm2
000071ff71bd8c62  jnz 0x000071FF71BD9FE7
000071ff71bd8c68  mov [rsp+0x80], rax
000071ff71bd8c70  xor eax, eax
000071ff71bd8c72  mov r14d, 0x200
000071ff71bd8c78  cmp r12, r14
000071ff71bd8c7b  cmc
000071ff71bd8c7c  lahf
000071ff71bd8c7d  seto al
000071ff71bd8c80  mov [r15+0x108], eax
000071ff71bd8c87  movaps xmm5, xmm8
000071ff71bd8c8b  addpd xmm5, xmm15
000071ff71bd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000071ff71bd8c95  ptest xmm4, xmm4
000071ff71bd8c9a  jnz 0x000071FF71BDA127
000071ff71bd8ca0  movaps xmm8, [r15+0x1B0]
000071ff71bd8ca8  movaps xmm4, xmm9
000071ff71bd8cac  addpd xmm4, xmm8
000071ff71bd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000071ff71bd8cb6  ptest xmm2, xmm2
000071ff71bd8cbb  jnz 0x000071FF71BDA269
000071ff71bd8cc1  movaps xmm9, xmm10
000071ff71bd8cc5  addpd xmm9, xmm8
000071ff71bd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000071ff71bd8cd0  ptest xmm2, xmm2
000071ff71bd8cd5  jnz 0x000071FF71BDA3AB
000071ff71bd8cdb  movaps xmm10, [r15+0x2F0]
000071ff71bd8ce3  vmovaps [rsp+0x90], xmm10
000071ff71bd8cec  vmovaps xmm8, [rsp+0x90]
000071ff71bd8cf5  por xmm10, xmm8
000071ff71bd8cfa  movaps xmm8, [r15+0x2E0]
000071ff71bd8d02  vmovaps [rsp+0x90], xmm8
000071ff71bd8d0b  vmovaps xmm2, [rsp+0x90]
000071ff71bd8d14  por xmm8, xmm2
000071ff71bd8d19  movaps xmm2, [r15+0x2D0]
000071ff71bd8d21  vmovaps [rsp+0x90], xmm2
000071ff71bd8d2a  vmovaps [rsp+0xA0], xmm1
000071ff71bd8d33  vmovaps xmm1, [rsp+0x90]
000071ff71bd8d3c  por xmm2, xmm1
000071ff71bd8d40  movaps xmm1, [r15+0x200]
000071ff71bd8d48  vmovaps [rsp+0x90], xmm1
000071ff71bd8d51  vmovaps [rsp+0xB0], xmm15
000071ff71bd8d5a  vmovaps xmm15, [rsp+0x90]
000071ff71bd8d63  por xmm1, xmm15
000071ff71bd8d68  movaps xmm15, [r15+0x1C0]
000071ff71bd8d70  vmovaps [rsp+0x90], xmm15
000071ff71bd8d79  vmovaps [rsp+0xC0], xmm1
000071ff71bd8d82  vmovaps xmm1, [rsp+0x90]
000071ff71bd8d8b  por xmm15, xmm1
000071ff71bd8d90  movaps xmm1, [r15+0x190]
000071ff71bd8d98  vmovaps [rsp+0x90], xmm1
000071ff71bd8da1  vmovaps [rsp+0xD0], xmm15
000071ff71bd8daa  vmovaps xmm15, [rsp+0x90]
000071ff71bd8db3  por xmm1, xmm15
000071ff71bd8db8  movaps xmm15, [r15+0x300]
000071ff71bd8dc0  vmovaps [rsp+0x90], xmm15
000071ff71bd8dc9  vmovaps [rsp+0xE0], xmm1
000071ff71bd8dd2  vmovaps xmm1, [rsp+0x90]
000071ff71bd8ddb  por xmm15, xmm1
000071ff71bd8de0  mov rax, [rsp+0x80]
000071ff71bd8de8  lea r14, [rax+0xA0]
000071ff71bd8def  movups xmm1, [r13+r14*1]
000071ff71bd8df5  lea r14, [rax+0xB0]
000071ff71bd8dfc  vmovaps [rsp+0x80], xmm1
000071ff71bd8e05  movups xmm1, [r13+r14*1]
000071ff71bd8e0b  vmovaps [rsp+0x90], xmm1
000071ff71bd8e14  vmovaps [rsp+0xF0], xmm15
000071ff71bd8e1d  vmovaps xmm15, [rsp+0xB0]
000071ff71bd8e26  vmovaps [rsp+0xB0], xmm14
000071ff71bd8e2f  movaps xmm1, xmm6
000071ff71bd8e32  addpd xmm1, xmm15
000071ff71bd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000071ff71bd8e3c  ptest xmm14, xmm14
000071ff71bd8e42  jnz 0x000071FF71BDA503
000071ff71bd8e48  lea r14, [rax+0xF0]
000071ff71bd8e4f  movups xmm15, [r13+r14*1]
000071ff71bd8e55  movaps xmm14, xmm4
000071ff71bd8e59  addpd xmm14, xmm3
000071ff71bd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000071ff71bd8e64  ptest xmm6, xmm6
000071ff71bd8e69  jnz 0x000071FF71BDA64E
000071ff71bd8e6f  movaps xmm6, xmm9
000071ff71bd8e73  addpd xmm6, xmm7
000071ff71bd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000071ff71bd8e7c  ptest xmm4, xmm4
000071ff71bd8e81  jnz 0x000071FF71BDA790
000071ff71bd8e87  vmovaps xmm9, [rsp+0x70]
000071ff71bd8e8d  vpermilpd xmm9, xmm9, 0x00
000071ff71bd8e93  vmovaps xmm4, [rsp+0x90]
000071ff71bd8e9c  movaps xmm7, xmm4
000071ff71bd8e9f  mulpd xmm7, xmm9
000071ff71bd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000071ff71bd8ea9  ptest xmm3, xmm3
000071ff71bd8eae  jnz 0x000071FF71BDA8D1
000071ff71bd8eb4  vmovaps xmm9, [rsp+0x50]
000071ff71bd8eba  vpermilpd xmm9, xmm9, 0x00
000071ff71bd8ec0  movaps xmm4, xmm15
000071ff71bd8ec4  mulpd xmm4, xmm9
000071ff71bd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000071ff71bd8ece  ptest xmm3, xmm3
000071ff71bd8ed3  jnz 0x000071FF71BDAA12
000071ff71bd8ed9  lea r14, [rax+0xE0]
000071ff71bd8ee0  movups xmm15, [r13+r14*1]
000071ff71bd8ee6  vmovaps xmm9, [rsp+0x70]
000071ff71bd8eec  vpermilpd xmm9, xmm9, 0x00
000071ff71bd8ef2  vmovaps [rsp+0x70], xmm1
000071ff71bd8ef8  vmovaps xmm1, [rsp+0x80]
000071ff71bd8f01  vmovaps [rsp+0x80], xmm15
000071ff71bd8f0a  movaps xmm3, xmm1
000071ff71bd8f0d  mulpd xmm3, xmm9
000071ff71bd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000071ff71bd8f17  ptest xmm15, xmm15
000071ff71bd8f1d  jnz 0x000071FF71BDAB5E
000071ff71bd8f23  vmovaps xmm1, [rsp+0xF0]
000071ff71bd8f2c  vmovaps xmm15, [rsp+0xF0]
000071ff71bd8f35  por xmm1, xmm15
000071ff71bd8f3a  movaps [r15+0x300], xmm1
000071ff71bd8f42  vmovaps xmm15, [rsp+0xE0]
000071ff71bd8f4b  vmovaps xmm9, [rsp+0xE0]
000071ff71bd8f54  por xmm15, xmm9
000071ff71bd8f59  movaps [r15+0x190], xmm15
000071ff71bd8f61  vmovaps xmm9, [rsp+0x50]
000071ff71bd8f67  vpermilpd xmm9, xmm9, 0x00
000071ff71bd8f6d  vmovaps [rsp+0x90], xmm1
000071ff71bd8f76  vmovaps [rsp+0xE0], xmm15
000071ff71bd8f7f  vmovaps xmm15, [rsp+0x80]
000071ff71bd8f88  vmovaps [rsp+0x80], xmm14
000071ff71bd8f91  movaps xmm1, xmm15
000071ff71bd8f95  mulpd xmm1, xmm9
000071ff71bd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000071ff71bd8f9f  ptest xmm14, xmm14
000071ff71bd8fa5  jnz 0x000071FF71BDAC9F
000071ff71bd8fab  lea r14, [rax+0x90]
000071ff71bd8fb2  movups xmm15, [r13+r14*1]
000071ff71bd8fb8  vmovaps xmm14, [rsp+0xD0]
000071ff71bd8fc1  vmovaps xmm9, [rsp+0xD0]
000071ff71bd8fca  por xmm14, xmm9
000071ff71bd8fcf  movaps [r15+0x1C0], xmm14
000071ff71bd8fd7  vmovaps xmm9, [rsp+0xC0]
000071ff71bd8fe0  vmovaps [rsp+0xD0], xmm1
000071ff71bd8fe9  vmovaps xmm1, [rsp+0xC0]
000071ff71bd8ff2  por xmm9, xmm1
000071ff71bd8ff7  movaps [r15+0x200], xmm9
000071ff71bd8fff  vmovaps [rsp+0xC0], xmm2
000071ff71bd9008  vmovaps xmm1, [rsp+0xC0]
000071ff71bd9011  por xmm2, xmm1
000071ff71bd9015  movaps [r15+0x2D0], xmm2
000071ff71bd901d  vmovaps [rsp+0xC0], xmm8
000071ff71bd9026  vmovaps xmm1, [rsp+0xC0]
000071ff71bd902f  por xmm8, xmm1
000071ff71bd9034  movaps [r15+0x2E0], xmm8
000071ff71bd903c  vmovaps [rsp+0xC0], xmm15
000071ff71bd9045  movaps xmm1, xmm5
000071ff71bd9048  addpd xmm1, xmm7
000071ff71bd904c  vcmppd xmm15, xmm1, xmm1, 0x03
000071ff71bd9051  ptest xmm15, xmm15
000071ff71bd9057  jnz 0x000071FF71BDADEB
000071ff71bd905d  vmovaps xmm15, [rsp+0x50]
000071ff71bd9063  vpermilpd xmm15, xmm15, 0x00
000071ff71bd9069  vmovaps xmm5, [rsp+0xC0]
000071ff71bd9072  vmovaps [rsp+0xC0], xmm1
000071ff71bd907b  movaps xmm7, xmm5
000071ff71bd907e  mulpd xmm7, xmm15
000071ff71bd9083  vcmppd xmm1, xmm7, xmm7, 0x03
000071ff71bd9088  ptest xmm1, xmm1
000071ff71bd908d  jnz 0x000071FF71BDAF2B
000071ff71bd9093  lea r14, [rax+0x80]
000071ff71bd909a  movups xmm1, [r13+r14*1]
000071ff71bd90a0  vmovaps xmm5, [rsp+0x70]
000071ff71bd90a6  vmovaps [rsp+0x70], xmm1
000071ff71bd90ac  movaps xmm15, xmm5
000071ff71bd90b0  addpd xmm15, xmm3
000071ff71bd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000071ff71bd90bb  ptest xmm1, xmm1
000071ff71bd90c0  jnz 0x000071FF71BDB076
000071ff71bd90c6  vmovaps xmm5, [rsp+0x80]
000071ff71bd90cf  movaps xmm1, xmm5
000071ff71bd90d2  addpd xmm1, xmm4
000071ff71bd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000071ff71bd90db  ptest xmm3, xmm3
000071ff71bd90e0  jnz 0x000071FF71BDB1B8
000071ff71bd90e6  vmovaps [rsp+0x80], xmm10
000071ff71bd90ef  vmovaps xmm5, [rsp+0x80]
000071ff71bd90f8  por xmm10, xmm5
000071ff71bd90fd  movaps [r15+0x2F0], xmm10
000071ff71bd9105  vmovaps xmm5, [rsp+0x50]
000071ff71bd910b  vpermilpd xmm5, xmm5, 0x00
000071ff71bd9111  vmovaps xmm3, [rsp+0x70]
000071ff71bd9117  vmovaps [rsp+0x50], xmm1
000071ff71bd911d  movaps xmm4, xmm3
000071ff71bd9120  mulpd xmm4, xmm5
000071ff71bd9124  vcmppd xmm1, xmm4, xmm4, 0x03
000071ff71bd9129  ptest xmm1, xmm1
000071ff71bd912e  jnz 0x000071FF71BDB2F8
000071ff71bd9134  lea r14, [rax+0xD0]
000071ff71bd913b  movups xmm1, [r13+r14*1]
000071ff71bd9141  vmovaps xmm3, [rsp+0xD0]
000071ff71bd914a  vmovaps [rsp+0x70], xmm1
000071ff71bd9150  movaps xmm5, xmm6
000071ff71bd9153  addpd xmm5, xmm3
000071ff71bd9157  vcmppd xmm1, xmm5, xmm5, 0x03
000071ff71bd915c  ptest xmm1, xmm1
000071ff71bd9161  jnz 0x000071FF71BDB442
000071ff71bd9167  vmovaps xmm1, [rsp+0x60]
000071ff71bd916d  vpermilpd xmm1, xmm1, 0x00
000071ff71bd9173  movaps xmm6, xmm9
000071ff71bd9177  mulpd xmm6, xmm1
000071ff71bd917b  vcmppd xmm3, xmm6, xmm6, 0x03
000071ff71bd9180  ptest xmm3, xmm3
000071ff71bd9185  jnz 0x000071FF71BDB582
000071ff71bd918b  movaps [r15+0x260], xmm6
000071ff71bd9193  vxorps xmm1, xmm1, xmm1
000071ff71bd9197  vpbroadcastq xmm1, xmm1
000071ff71bd919c  movaps [r15+0x1B0], xmm1
000071ff71bd91a4  vmovaps xmm1, [rsp+0x60]
000071ff71bd91aa  vpermilpd xmm1, xmm1, 0x00
000071ff71bd91b0  vmovaps xmm3, [rsp+0x70]
000071ff71bd91b6  vmovaps [rsp+0x70], xmm15
000071ff71bd91bc  movaps xmm9, xmm3
000071ff71bd91c0  mulpd xmm9, xmm1
000071ff71bd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000071ff71bd91cb  ptest xmm15, xmm15
000071ff71bd91d1  jnz 0x000071FF71BDB6C3
000071ff71bd91d7  lea r14, [rax+0xC0]
000071ff71bd91de  movups xmm1, [r13+r14*1]
000071ff71bd91e4  vmovaps xmm3, [rsp+0xC0]
000071ff71bd91ed  vmovaps [rsp+0x80], xmm1
000071ff71bd91f6  movaps xmm15, xmm3
000071ff71bd91fa  addpd xmm15, xmm7
000071ff71bd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000071ff71bd9205  ptest xmm1, xmm1
000071ff71bd920a  jnz 0x000071FF71BDB80F
000071ff71bd9210  vmovaps [rsp+0xC0], xmm13
000071ff71bd9219  vmovaps xmm1, [rsp+0xC0]
000071ff71bd9222  por xmm13, xmm1
000071ff71bd9227  movaps [r15+0x270], xmm13
000071ff71bd922f  vmovaps xmm1, [rsp+0xB0]
000071ff71bd9238  vmovaps xmm7, [rsp+0xB0]
000071ff71bd9241  por xmm1, xmm7
000071ff71bd9245  movaps [r15+0x1A0], xmm1
000071ff71bd924d  vmovaps xmm1, [rsp+0x60]
000071ff71bd9253  vpermilpd xmm1, xmm1, 0x00
000071ff71bd9259  vmovaps [rsp+0xB0], xmm1
000071ff71bd9262  vmovaps xmm1, [rsp+0x80]
000071ff71bd926b  vmovaps [rsp+0x80], xmm15
000071ff71bd9274  vmovaps xmm15, [rsp+0xB0]
000071ff71bd927d  vmovaps [rsp+0xB0], xmm14
000071ff71bd9286  movaps xmm3, xmm1
000071ff71bd9289  mulpd xmm3, xmm15
000071ff71bd928e  vcmppd xmm14, xmm3, xmm3, 0x03
000071ff71bd9293  ptest xmm14, xmm14
000071ff71bd9299  jnz 0x000071FF71BDB951
000071ff71bd929f  lea r14, [rax+0x20]
000071ff71bd92a3  movups xmm1, [r13+r14*1]
000071ff71bd92a9  movaps [r15+0x110], xmm1
000071ff71bd92b1  vmovaps xmm14, [rsp+0x70]
000071ff71bd92b7  vmovaps [rsp+0x70], xmm1
000071ff71bd92bd  movaps xmm15, xmm14
000071ff71bd92c1  addpd xmm15, xmm4
000071ff71bd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000071ff71bd92cc  ptest xmm1, xmm1
000071ff71bd92d1  jnz 0x000071FF71BDBA9C
000071ff71bd92d7  vmovaps xmm1, [rsp+0x60]
000071ff71bd92dd  vpermilpd xmm1, xmm1, 0x00
000071ff71bd92e3  movaps xmm14, xmm2
000071ff71bd92e7  mulpd xmm14, xmm1
000071ff71bd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000071ff71bd92f2  ptest xmm4, xmm4
000071ff71bd92f7  jnz 0x000071FF71BDBBDF
000071ff71bd92fd  vmovaps xmm4, [rsp+0x50]
000071ff71bd9303  movaps xmm1, xmm4
000071ff71bd9306  addpd xmm1, xmm9
000071ff71bd930b  vcmppd xmm2, xmm1, xmm1, 0x03
000071ff71bd9310  ptest xmm2, xmm2
000071ff71bd9315  jnz 0x000071FF71BDBD21
000071ff71bd931b  vmovaps xmm9, [rsp+0x30]
000071ff71bd9321  vpermilpd xmm9, xmm9, 0x00
000071ff71bd9327  vmovaps xmm2, [rsp+0x70]
000071ff71bd932d  vmovaps [rsp+0x50], xmm1
000071ff71bd9333  movaps xmm4, xmm2
000071ff71bd9336  mulpd xmm4, xmm9
000071ff71bd933b  vcmppd xmm1, xmm4, xmm4, 0x03
000071ff71bd9340  ptest xmm1, xmm1
000071ff71bd9345  jnz 0x000071FF71BDBE62
000071ff71bd934b  vmovaps xmm1, [rsp+0x30]
000071ff71bd9351  vpermilpd xmm1, xmm1, 0x00
000071ff71bd9357  vmovaps xmm2, [rsp+0x90]
000071ff71bd9360  vmovaps [rsp+0x60], xmm15
000071ff71bd9366  movaps xmm9, xmm2
000071ff71bd936a  mulpd xmm9, xmm1
000071ff71bd936f  vcmppd xmm15, xmm9, xmm9, 0x03
000071ff71bd9375  ptest xmm15, xmm15
000071ff71bd937b  jnz 0x000071FF71BDBFA3
000071ff71bd9381  vmovaps xmm15, [rsp+0x80]
000071ff71bd938a  movaps xmm1, xmm15
000071ff71bd938e  addpd xmm1, xmm6
000071ff71bd9392  vcmppd xmm2, xmm1, xmm1, 0x03
000071ff71bd9397  ptest xmm2, xmm2
000071ff71bd939c  jnz 0x000071FF71BDC0E5
000071ff71bd93a2  movaps xmm15, xmm5
000071ff71bd93a6  addpd xmm15, xmm3
000071ff71bd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000071ff71bd93b1  ptest xmm6, xmm6
000071ff71bd93b6  jnz 0x000071FF71BDC226
000071ff71bd93bc  vmovaps xmm6, [rsp+0x30]
000071ff71bd93c2  vpermilpd xmm6, xmm6, 0x00
000071ff71bd93c8  movaps xmm5, xmm8
000071ff71bd93cc  mulpd xmm5, xmm6
000071ff71bd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000071ff71bd93d5  ptest xmm3, xmm3
000071ff71bd93da  jnz 0x000071FF71BDC368
000071ff71bd93e0  vmovaps xmm8, [rsp+0x30]
000071ff71bd93e6  vpermilpd xmm8, xmm8, 0x00
000071ff71bd93ec  movaps xmm6, xmm10
000071ff71bd93f0  mulpd xmm6, xmm8
000071ff71bd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000071ff71bd93fa  ptest xmm3, xmm3
000071ff71bd93ff  jnz 0x000071FF71BDC4A9
000071ff71bd9405  vmovaps xmm8, [rsp+0x60]
000071ff71bd940b  movaps xmm10, xmm8
000071ff71bd940f  addpd xmm10, xmm14
000071ff71bd9414  vcmppd xmm3, xmm10, xmm10, 0x03
000071ff71bd941a  ptest xmm3, xmm3
000071ff71bd941f  jnz 0x000071FF71BDC5EB
000071ff71bd9425  vmovaps xmm8, [rsp+0x50]
000071ff71bd942b  movaps xmm14, xmm8
000071ff71bd942f  addpd xmm14, xmm4
000071ff71bd9434  vcmppd xmm3, xmm14, xmm14, 0x03
000071ff71bd943a  ptest xmm3, xmm3
000071ff71bd943f  jnz 0x000071FF71BDC72F
000071ff71bd9445  vmovaps xmm8, [rsp+0x40]
000071ff71bd944b  vpermilpd xmm8, xmm8, 0x00
000071ff71bd9451  movaps xmm4, xmm13
000071ff71bd9455  mulpd xmm4, xmm8
000071ff71bd945a  vcmppd xmm3, xmm4, xmm4, 0x03
000071ff71bd945f  ptest xmm3, xmm3
000071ff71bd9464  jnz 0x000071FF71BDC872
000071ff71bd946a  movaps xmm13, xmm15
000071ff71bd946e  addpd xmm13, xmm9
000071ff71bd9473  vcmppd xmm8, xmm13, xmm13, 0x03
000071ff71bd9479  ptest xmm8, xmm8
000071ff71bd947f  jnz 0x000071FF71BDC9B4
000071ff71bd9485  movaps xmm15, xmm1
000071ff71bd9489  addpd xmm15, xmm5
000071ff71bd948e  vcmppd xmm9, xmm15, xmm15, 0x03
000071ff71bd9494  ptest xmm9, xmm9
000071ff71bd949a  jnz 0x000071FF71BDCAF8
000071ff71bd94a0  vmovaps [rsp+0x30], xmm11
000071ff71bd94a6  vmovaps xmm1, [rsp+0x30]
000071ff71bd94ac  por xmm11, xmm1
000071ff71bd94b1  movaps [r15+0x250], xmm11
000071ff71bd94b9  vmovaps [rsp+0x30], xmm12
000071ff71bd94bf  vmovaps xmm1, [rsp+0x30]
000071ff71bd94c5  por xmm12, xmm1
000071ff71bd94ca  movaps [r15+0x2A0], xmm12
000071ff71bd94d2  vmovaps xmm1, [rsp+0xA0]
000071ff71bd94db  vmovaps xmm11, [rsp+0xA0]
000071ff71bd94e4  por xmm1, xmm11
000071ff71bd94e9  movaps [r15+0x1D0], xmm1
000071ff71bd94f1  lea r14, [rax+0x40]
000071ff71bd94f5  movups xmm1, [r13+r14*1]
000071ff71bd94fb  movaps [r15+0x2C0], xmm1
000071ff71bd9503  vmovaps xmm11, [rsp+0x40]
000071ff71bd9509  vpermilpd xmm11, xmm11, 0x00
000071ff71bd950f  vmovaps xmm8, [rsp+0xE0]
000071ff71bd9518  movaps xmm9, xmm8
000071ff71bd951c  mulpd xmm9, xmm11
000071ff71bd9521  vcmppd xmm5, xmm9, xmm9, 0x03
000071ff71bd9527  ptest xmm5, xmm5
000071ff71bd952c  jnz 0x000071FF71BDCC44
000071ff71bd9532  movaps xmm11, xmm10
000071ff71bd9536  addpd xmm11, xmm6
000071ff71bd953b  vcmppd xmm8, xmm11, xmm11, 0x03
000071ff71bd9541  ptest xmm8, xmm8
000071ff71bd9547  jnz 0x000071FF71BDCD88
000071ff71bd954d  movaps xmm10, xmm14
000071ff71bd9551  addpd xmm10, xmm4
000071ff71bd9556  vcmppd xmm8, xmm10, xmm10, 0x03
000071ff71bd955c  ptest xmm8, xmm8
000071ff71bd9562  jnz 0x000071FF71BDCECB
000071ff71bd9568  vmovaps xmm14, [rsp+0x40]
000071ff71bd956e  vpermilpd xmm14, xmm14, 0x00
000071ff71bd9574  movaps xmm8, xmm1
000071ff71bd9578  mulpd xmm8, xmm14
000071ff71bd957d  vcmppd xmm6, xmm8, xmm8, 0x03
000071ff71bd9583  ptest xmm6, xmm6
000071ff71bd9588  jnz 0x000071FF71BDD00E
000071ff71bd958e  movaps xmm1, [r15+0x2B0]
000071ff71bd9596  vmovaps xmm14, [rsp+0x40]
000071ff71bd959c  vpermilpd xmm14, xmm14, 0x00
000071ff71bd95a2  movaps xmm6, xmm1
000071ff71bd95a5  mulpd xmm6, xmm14
000071ff71bd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000071ff71bd95af  ptest xmm5, xmm5
000071ff71bd95b4  jnz 0x000071FF71BDD151
000071ff71bd95ba  vmovaps xmm1, [rsp+0x10]
000071ff71bd95c0  vpermilpd xmm1, xmm1, 0x00
000071ff71bd95c6  movaps xmm14, xmm12
000071ff71bd95ca  mulpd xmm14, xmm1
000071ff71bd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000071ff71bd95d5  ptest xmm5, xmm5
000071ff71bd95da  jnz 0x000071FF71BDD292
000071ff71bd95e0  movaps xmm1, xmm13
000071ff71bd95e4  addpd xmm1, xmm9
000071ff71bd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000071ff71bd95ee  ptest xmm12, xmm12
000071ff71bd95f4  jnz 0x000071FF71BDD3D5
000071ff71bd95fa  vmovaps xmm13, [rsp+0x10]
000071ff71bd9600  vpermilpd xmm13, xmm13, 0x00
000071ff71bd9606  movaps xmm12, xmm7
000071ff71bd960a  mulpd xmm12, xmm13
000071ff71bd960f  vcmppd xmm9, xmm12, xmm12, 0x03
000071ff71bd9615  ptest xmm9, xmm9
000071ff71bd961b  jnz 0x000071FF71BDD517
000071ff71bd9621  movaps xmm13, xmm15
000071ff71bd9625  addpd xmm13, xmm8
000071ff71bd962a  vcmppd xmm9, xmm13, xmm13, 0x03
000071ff71bd9630  ptest xmm9, xmm9
000071ff71bd9636  jnz 0x000071FF71BDD65A
000071ff71bd963c  movaps xmm15, [r15+0x290]
000071ff71bd9644  vmovaps xmm9, [rsp+0x10]
000071ff71bd964a  vpermilpd xmm9, xmm9, 0x00
000071ff71bd9650  movaps xmm8, xmm15
000071ff71bd9654  mulpd xmm8, xmm9
000071ff71bd9659  vcmppd xmm7, xmm8, xmm8, 0x03
000071ff71bd965f  ptest xmm7, xmm7
000071ff71bd9664  jnz 0x000071FF71BDD79E
000071ff71bd966a  movaps xmm15, xmm11
000071ff71bd966e  addpd xmm15, xmm6
000071ff71bd9673  vcmppd xmm9, xmm15, xmm15, 0x03
000071ff71bd9679  ptest xmm9, xmm9
000071ff71bd967f  jnz 0x000071FF71BDD8E2
000071ff71bd9685  movaps xmm11, [r15+0x1E0]
000071ff71bd968d  vmovaps xmm9, [rsp+0x10]
000071ff71bd9693  vpermilpd xmm9, xmm9, 0x00
000071ff71bd9699  movaps xmm7, xmm11
000071ff71bd969d  mulpd xmm7, xmm9
000071ff71bd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000071ff71bd96a7  ptest xmm6, xmm6
000071ff71bd96ac  jnz 0x000071FF71BDDA25
000071ff71bd96b2  movaps xmm11, xmm10
000071ff71bd96b6  addpd xmm11, xmm14
000071ff71bd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000071ff71bd96c1  ptest xmm9, xmm9
000071ff71bd96c7  jnz 0x000071FF71BDDB67
000071ff71bd96cd  lea r14, [rax+0x70]
000071ff71bd96d1  movups xmm14, [r13+r14*1]
000071ff71bd96d7  movaps [r15+0x240], xmm14
000071ff71bd96df  movaps xmm10, xmm1
000071ff71bd96e3  addpd xmm10, xmm12
000071ff71bd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000071ff71bd96ee  ptest xmm9, xmm9
000071ff71bd96f4  jnz 0x000071FF71BDDCB5
000071ff71bd96fa  movaps [r15+0x170], xmm10
000071ff71bd9702  vmovaps xmm1, [rsp+0x20]
000071ff71bd9708  vpermilpd xmm1, xmm1, 0x00
000071ff71bd970e  movaps xmm12, xmm14
000071ff71bd9712  mulpd xmm12, xmm1
000071ff71bd9717  vcmppd xmm9, xmm12, xmm12, 0x03
000071ff71bd971d  ptest xmm9, xmm9
000071ff71bd9723  jnz 0x000071FF71BDDDF8
000071ff71bd9729  vmovaps xmm1, [rsp+0x20]
000071ff71bd972f  vpermilpd xmm1, xmm1, 0x00
000071ff71bd9735  vmovaps xmm9, [rsp+0xB0]
000071ff71bd973e  movaps xmm14, xmm9
000071ff71bd9742  mulpd xmm14, xmm1
000071ff71bd9747  vcmppd xmm6, xmm14, xmm14, 0x03
000071ff71bd974d  ptest xmm6, xmm6
000071ff71bd9752  jnz 0x000071FF71BDDF3B
000071ff71bd9758  movaps [r15+0x180], xmm14
000071ff71bd9760  movaps xmm1, xmm13
000071ff71bd9764  addpd xmm1, xmm8
000071ff71bd9769  vcmppd xmm9, xmm1, xmm1, 0x03
000071ff71bd976e  ptest xmm9, xmm9
000071ff71bd9774  jnz 0x000071FF71BDE07E
000071ff71bd977a  movaps [r15+0x210], xmm1
000071ff71bd9782  movups xmm13, [r13+rax*1]
000071ff71bd9788  lea r14, [rax+0x10]
000071ff71bd978c  movups xmm9, [r13+r14*1]
000071ff71bd9792  movaps [r15+0x230], xmm9
000071ff71bd979a  movaps xmm8, xmm15
000071ff71bd979e  addpd xmm8, xmm7
000071ff71bd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000071ff71bd97a9  ptest xmm6, xmm6
000071ff71bd97ae  jnz 0x000071FF71BDE1D4
000071ff71bd97b4  movaps [r15+0x130], xmm8
000071ff71bd97bc  vmovaps xmm15, [rsp+0x20]
000071ff71bd97c2  vpermilpd xmm15, xmm15, 0x00
000071ff71bd97c8  movaps xmm7, xmm9
000071ff71bd97cc  mulpd xmm7, xmm15
000071ff71bd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000071ff71bd97d6  ptest xmm6, xmm6
000071ff71bd97db  jnz 0x000071FF71BDE317
000071ff71bd97e1  movaps [r15+0x220], xmm7
000071ff71bd97e9  vmovaps xmm15, [rsp+0x20]
000071ff71bd97ef  vpermilpd xmm15, xmm15, 0x00
000071ff71bd97f5  movaps xmm9, xmm13
000071ff71bd97f9  mulpd xmm9, xmm15
000071ff71bd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000071ff71bd9804  ptest xmm6, xmm6
000071ff71bd9809  jnz 0x000071FF71BDE459
000071ff71bd980f  movaps xmm15, xmm11
000071ff71bd9813  addpd xmm15, xmm12
000071ff71bd9818  vcmppd xmm13, xmm15, xmm15, 0x03
000071ff71bd981e  ptest xmm13, xmm13
000071ff71bd9824  jnz 0x000071FF71BDE59D
000071ff71bd982a  movaps [r15+0x140], xmm15
000071ff71bd9832  movaps xmm13, xmm10
000071ff71bd9836  addpd xmm13, xmm14
000071ff71bd983b  vcmppd xmm12, xmm13, xmm13, 0x03
000071ff71bd9841  ptest xmm12, xmm12
000071ff71bd9847  jnz 0x000071FF71BDE6E1
000071ff71bd984d  movaps [r15+0x150], xmm13
000071ff71bd9855  movaps xmm14, xmm1
000071ff71bd9859  addpd xmm14, xmm7
000071ff71bd985e  vcmppd xmm12, xmm14, xmm14, 0x03
000071ff71bd9864  ptest xmm12, xmm12
000071ff71bd986a  jnz 0x000071FF71BDE825
000071ff71bd9870  movaps [r15+0x160], xmm14
000071ff71bd9878  movaps xmm1, xmm8
000071ff71bd987c  addpd xmm1, xmm9
000071ff71bd9881  vcmppd xmm12, xmm1, xmm1, 0x03
000071ff71bd9886  ptest xmm12, xmm12
000071ff71bd988c  jnz 0x000071FF71BDE967
000071ff71bd9892  movaps [r15+0x120], xmm1
000071ff71bd989a  movups [r13+r11*1], xmm15
000071ff71bd98a0  lea rax, [r11+0x10]
000071ff71bd98a4  movups [r13+rax*1], xmm13
000071ff71bd98aa  lea rax, [r11+0x20]
000071ff71bd98ae  movups [r13+rax*1], xmm14
000071ff71bd98b4  lea rax, [r11+0x30]
000071ff71bd98b8  movups [r13+rax*1], xmm1
000071ff71bd98be  mov eax, [r15+0x108]
000071ff71bd98c5  sahf
000071ff71bd98c6  jnz 0x000071FF71BD98F8
000071ff71bd98c8  cmp dword ptr [r15+0x318], 0x00
000071ff71bd98d0  jz 0x000071FF71BDEAE0
000071ff71bd98d6  nop [rax+rax*1], ax
000071ff71bd98df  nop [rax+rax*1], eax
000071ff71bd98e7  mov eax, 0x4106D0
000071ff71bd98ec  mov [r15+0x100], rax
000071ff71bd98f3  jmp 0x000071FF719FE110
000071ff71bd98f8  cmp dword ptr [r15+0x318], 0x00
000071ff71bd9900  jz 0x000071FF71BD89C0
000071ff71bd9906  nop [rax+rax*1], ax
000071ff71bd990f  nop [rax+rax*1], eax
000071ff71bd9917  mov eax, 0x410504
000071ff71bd991c  mov [r15+0x100], rax
000071ff71bd9923  jmp 0x000071FF719FE110
000071ff71bd9928  int3
000071ff71bd9929  call 0x000071FF71A0A4B0
000071ff71bd992e  jmp 0x000071FF71BD8A08
000071ff71bd9933  call 0x000071FF71A09240
000071ff71bd9938  jmp 0x000071FF71BD8A12
000071ff71bd993d  call 0x000071FF71A0A4B0
000071ff71bd9942  jmp 0x000071FF71BD8A6F
000071ff71bd9947  call 0x000071FF71A09240
000071ff71bd994c  jmp 0x000071FF71BD8A79
000071ff71bd9951  call 0x000071FF71A0A4B0
000071ff71bd9956  jmp 0x000071FF71BD8ABD
000071ff71bd995b  call 0x000071FF71A09240
000071ff71bd9960  jmp 0x000071FF71BD8AC7
000071ff71bd9965  call 0x000071FF71AB47C0
000071ff71bd996a  jmp 0x000071FF71BD8B06
000071ff71bd996f  call 0x000071FF71A0B720
000071ff71bd9974  jmp 0x000071FF71BD8B1A
000071ff71bd9979  call 0x000071FF71ABFC30
000071ff71bd997e  jmp 0x000071FF71BD8B38
000071ff71bd9983  call 0x000071FF71ABE9C0
000071ff71bd9988  jmp 0x000071FF71BD8B42
000071ff71bd998d  call 0x000071FF71ABD750
000071ff71bd9992  jmp 0x000071FF71BD8B4C
000071ff71bd9997  sub rsp, 0x08
000071ff71bd999b  push rax
000071ff71bd999c  push rcx
000071ff71bd999d  push rdx
000071ff71bd999e  push rdi
000071ff71bd999f  push rsi
000071ff71bd99a0  push r8
000071ff71bd99a2  push r9
000071ff71bd99a4  push r10
000071ff71bd99a6  push r11
000071ff71bd99a8  sub rsp, 0xF0
000071ff71bd99af  vmovaps [rsp], xmm0
000071ff71bd99b4  vmovaps [rsp+0x10], xmm1
000071ff71bd99ba  vmovaps [rsp+0x20], xmm2
000071ff71bd99c0  vmovaps [rsp+0x30], xmm3
000071ff71bd99c6  vmovaps [rsp+0x40], xmm4
000071ff71bd99cc  vmovaps [rsp+0x50], xmm5
000071ff71bd99d2  vmovaps [rsp+0x60], xmm6
000071ff71bd99d8  vmovaps [rsp+0x70], xmm7
000071ff71bd99de  vmovaps [rsp+0x80], xmm9
000071ff71bd99e7  vmovaps [rsp+0x90], xmm10
000071ff71bd99f0  vmovaps [rsp+0xA0], xmm11
000071ff71bd99f9  vmovaps [rsp+0xB0], xmm12
000071ff71bd9a02  vmovaps [rsp+0xC0], xmm13
000071ff71bd9a0b  vmovaps [rsp+0xD0], xmm14
000071ff71bd9a14  vmovaps [rsp+0xE0], xmm15
000071ff71bd9a1d  sub rsp, 0x30
000071ff71bd9a21  movaps [rsp], xmm8
000071ff71bd9a26  movaps [rsp+0x10], xmm12
000071ff71bd9a2c  movaps [rsp+0x20], xmm15
000071ff71bd9a32  lea rdi, [rsp]
000071ff71bd9a36  mov esi, 0x00
000071ff71bd9a3b  mov rax, 0x5E6872E10530
000071ff71bd9a45  call rax
000071ff71bd9a47  movaps xmm8, [rsp]
000071ff71bd9a4c  add rsp, 0x30
000071ff71bd9a50  vmovaps xmm0, [rsp]
000071ff71bd9a55  vmovaps xmm1, [rsp+0x10]
000071ff71bd9a5b  vmovaps xmm2, [rsp+0x20]
000071ff71bd9a61  vmovaps xmm3, [rsp+0x30]
000071ff71bd9a67  vmovaps xmm4, [rsp+0x40]
000071ff71bd9a6d  vmovaps xmm5, [rsp+0x50]
000071ff71bd9a73  vmovaps xmm6, [rsp+0x60]
000071ff71bd9a79  vmovaps xmm7, [rsp+0x70]
000071ff71bd9a7f  vmovaps xmm9, [rsp+0x80]
000071ff71bd9a88  vmovaps xmm10, [rsp+0x90]
000071ff71bd9a91  vmovaps xmm11, [rsp+0xA0]
000071ff71bd9a9a  vmovaps xmm12, [rsp+0xB0]
000071ff71bd9aa3  vmovaps xmm13, [rsp+0xC0]
000071ff71bd9aac  vmovaps xmm14, [rsp+0xD0]
000071ff71bd9ab5  vmovaps xmm15, [rsp+0xE0]
000071ff71bd9abe  add rsp, 0xF0
000071ff71bd9ac5  pop r11
000071ff71bd9ac7  pop r10
000071ff71bd9ac9  pop r9
000071ff71bd9acb  pop r8
000071ff71bd9acd  pop rsi
000071ff71bd9ace  pop rdi
000071ff71bd9acf  pop rdx
000071ff71bd9ad0  pop rcx
000071ff71bd9ad1  pop rax
000071ff71bd9ad2  add rsp, 0x08
000071ff71bd9ad6  jmp 0x000071FF71BD8B7A
000071ff71bd9adb  sub rsp, 0x08
000071ff71bd9adf  push rax
000071ff71bd9ae0  push rcx
000071ff71bd9ae1  push rdx
000071ff71bd9ae2  push rdi
000071ff71bd9ae3  push rsi
000071ff71bd9ae4  push r8
000071ff71bd9ae6  push r9
000071ff71bd9ae8  push r10
000071ff71bd9aea  push r11
000071ff71bd9aec  sub rsp, 0xF0
000071ff71bd9af3  vmovaps [rsp], xmm0
000071ff71bd9af8  vmovaps [rsp+0x10], xmm1
000071ff71bd9afe  vmovaps [rsp+0x20], xmm2
000071ff71bd9b04  vmovaps [rsp+0x30], xmm3
000071ff71bd9b0a  vmovaps [rsp+0x40], xmm4
000071ff71bd9b10  vmovaps [rsp+0x50], xmm5
000071ff71bd9b16  vmovaps [rsp+0x60], xmm6
000071ff71bd9b1c  vmovaps [rsp+0x70], xmm8
000071ff71bd9b22  vmovaps [rsp+0x80], xmm9
000071ff71bd9b2b  vmovaps [rsp+0x90], xmm10
000071ff71bd9b34  vmovaps [rsp+0xA0], xmm11
000071ff71bd9b3d  vmovaps [rsp+0xB0], xmm12
000071ff71bd9b46  vmovaps [rsp+0xC0], xmm13
000071ff71bd9b4f  vmovaps [rsp+0xD0], xmm14
000071ff71bd9b58  vmovaps [rsp+0xE0], xmm15
000071ff71bd9b61  sub rsp, 0x30
000071ff71bd9b65  movaps [rsp], xmm7
000071ff71bd9b69  movaps [rsp+0x10], xmm9
000071ff71bd9b6f  movaps [rsp+0x20], xmm15
000071ff71bd9b75  lea rdi, [rsp]
000071ff71bd9b79  mov esi, 0x00
000071ff71bd9b7e  mov rax, 0x5E6872E10530
000071ff71bd9b88  call rax
000071ff71bd9b8a  movaps xmm7, [rsp]
000071ff71bd9b8e  add rsp, 0x30
000071ff71bd9b92  vmovaps xmm0, [rsp]
000071ff71bd9b97  vmovaps xmm1, [rsp+0x10]
000071ff71bd9b9d  vmovaps xmm2, [rsp+0x20]
000071ff71bd9ba3  vmovaps xmm3, [rsp+0x30]
000071ff71bd9ba9  vmovaps xmm4, [rsp+0x40]
000071ff71bd9baf  vmovaps xmm5, [rsp+0x50]
000071ff71bd9bb5  vmovaps xmm6, [rsp+0x60]
000071ff71bd9bbb  vmovaps xmm8, [rsp+0x70]
000071ff71bd9bc1  vmovaps xmm9, [rsp+0x80]
000071ff71bd9bca  vmovaps xmm10, [rsp+0x90]
000071ff71bd9bd3  vmovaps xmm11, [rsp+0xA0]
000071ff71bd9bdc  vmovaps xmm12, [rsp+0xB0]
000071ff71bd9be5  vmovaps xmm13, [rsp+0xC0]
000071ff71bd9bee  vmovaps xmm14, [rsp+0xD0]
000071ff71bd9bf7  vmovaps xmm15, [rsp+0xE0]
000071ff71bd9c00  add rsp, 0xF0
000071ff71bd9c07  pop r11
000071ff71bd9c09  pop r10
000071ff71bd9c0b  pop r9
000071ff71bd9c0d  pop r8
000071ff71bd9c0f  pop rsi
000071ff71bd9c10  pop rdi
000071ff71bd9c11  pop rdx
000071ff71bd9c12  pop rcx
000071ff71bd9c13  pop rax
000071ff71bd9c14  add rsp, 0x08
000071ff71bd9c18  jmp 0x000071FF71BD8BA8
000071ff71bd9c1d  sub rsp, 0x08
000071ff71bd9c21  push rax
000071ff71bd9c22  push rcx
000071ff71bd9c23  push rdx
000071ff71bd9c24  push rdi
000071ff71bd9c25  push rsi
000071ff71bd9c26  push r8
000071ff71bd9c28  push r9
000071ff71bd9c2a  push r10
000071ff71bd9c2c  push r11
000071ff71bd9c2e  sub rsp, 0xF0
000071ff71bd9c35  vmovaps [rsp], xmm0
000071ff71bd9c3a  vmovaps [rsp+0x10], xmm1
000071ff71bd9c40  vmovaps [rsp+0x20], xmm2
000071ff71bd9c46  vmovaps [rsp+0x30], xmm3
000071ff71bd9c4c  vmovaps [rsp+0x40], xmm4
000071ff71bd9c52  vmovaps [rsp+0x50], xmm5
000071ff71bd9c58  vmovaps [rsp+0x60], xmm6
000071ff71bd9c5e  vmovaps [rsp+0x70], xmm7
000071ff71bd9c64  vmovaps [rsp+0x80], xmm8
000071ff71bd9c6d  vmovaps [rsp+0x90], xmm10
000071ff71bd9c76  vmovaps [rsp+0xA0], xmm11
000071ff71bd9c7f  vmovaps [rsp+0xB0], xmm12
000071ff71bd9c88  vmovaps [rsp+0xC0], xmm13
000071ff71bd9c91  vmovaps [rsp+0xD0], xmm14
000071ff71bd9c9a  vmovaps [rsp+0xE0], xmm15
000071ff71bd9ca3  sub rsp, 0x30
000071ff71bd9ca7  movaps [rsp], xmm9
000071ff71bd9cac  movaps [rsp+0x10], xmm12
000071ff71bd9cb2  movaps [rsp+0x20], xmm10
000071ff71bd9cb8  lea rdi, [rsp]
000071ff71bd9cbc  mov esi, 0x00
000071ff71bd9cc1  mov rax, 0x5E6872E10530
000071ff71bd9ccb  call rax
000071ff71bd9ccd  movaps xmm9, [rsp]
000071ff71bd9cd2  add rsp, 0x30
000071ff71bd9cd6  vmovaps xmm0, [rsp]
000071ff71bd9cdb  vmovaps xmm1, [rsp+0x10]
000071ff71bd9ce1  vmovaps xmm2, [rsp+0x20]
000071ff71bd9ce7  vmovaps xmm3, [rsp+0x30]
000071ff71bd9ced  vmovaps xmm4, [rsp+0x40]
000071ff71bd9cf3  vmovaps xmm5, [rsp+0x50]
000071ff71bd9cf9  vmovaps xmm6, [rsp+0x60]
000071ff71bd9cff  vmovaps xmm7, [rsp+0x70]
000071ff71bd9d05  vmovaps xmm8, [rsp+0x80]
000071ff71bd9d0e  vmovaps xmm10, [rsp+0x90]
000071ff71bd9d17  vmovaps xmm11, [rsp+0xA0]
000071ff71bd9d20  vmovaps xmm12, [rsp+0xB0]
000071ff71bd9d29  vmovaps xmm13, [rsp+0xC0]
000071ff71bd9d32  vmovaps xmm14, [rsp+0xD0]
000071ff71bd9d3b  vmovaps xmm15, [rsp+0xE0]
000071ff71bd9d44  add rsp, 0xF0
000071ff71bd9d4b  pop r11
000071ff71bd9d4d  pop r10
000071ff71bd9d4f  pop r9
000071ff71bd9d51  pop r8
000071ff71bd9d53  pop rsi
000071ff71bd9d54  pop rdi
000071ff71bd9d55  pop rdx
000071ff71bd9d56  pop rcx
000071ff71bd9d57  pop rax
000071ff71bd9d58  add rsp, 0x08
000071ff71bd9d5c  jmp 0x000071FF71BD8BCC
000071ff71bd9d61  sub rsp, 0x08
000071ff71bd9d65  push rax
000071ff71bd9d66  push rcx
000071ff71bd9d67  push rdx
000071ff71bd9d68  push rdi
000071ff71bd9d69  push rsi
000071ff71bd9d6a  push r8
000071ff71bd9d6c  push r9
000071ff71bd9d6e  push r10
000071ff71bd9d70  push r11
000071ff71bd9d72  sub rsp, 0xF0
000071ff71bd9d79  vmovaps [rsp], xmm0
000071ff71bd9d7e  vmovaps [rsp+0x10], xmm1
000071ff71bd9d84  vmovaps [rsp+0x20], xmm2
000071ff71bd9d8a  vmovaps [rsp+0x30], xmm3
000071ff71bd9d90  vmovaps [rsp+0x40], xmm4
000071ff71bd9d96  vmovaps [rsp+0x50], xmm5
000071ff71bd9d9c  vmovaps [rsp+0x60], xmm6
000071ff71bd9da2  vmovaps [rsp+0x70], xmm7
000071ff71bd9da8  vmovaps [rsp+0x80], xmm8
000071ff71bd9db1  vmovaps [rsp+0x90], xmm9
000071ff71bd9dba  vmovaps [rsp+0xA0], xmm11
000071ff71bd9dc3  vmovaps [rsp+0xB0], xmm12
000071ff71bd9dcc  vmovaps [rsp+0xC0], xmm13
000071ff71bd9dd5  vmovaps [rsp+0xD0], xmm14
000071ff71bd9dde  vmovaps [rsp+0xE0], xmm15
000071ff71bd9de7  sub rsp, 0x30
000071ff71bd9deb  movaps [rsp], xmm10
000071ff71bd9df0  movaps [rsp+0x10], xmm12
000071ff71bd9df6  movaps [rsp+0x20], xmm11
000071ff71bd9dfc  lea rdi, [rsp]
000071ff71bd9e00  mov esi, 0x00
000071ff71bd9e05  mov rax, 0x5E6872E10530
000071ff71bd9e0f  call rax
000071ff71bd9e11  movaps xmm10, [rsp]
000071ff71bd9e16  add rsp, 0x30
000071ff71bd9e1a  vmovaps xmm0, [rsp]
000071ff71bd9e1f  vmovaps xmm1, [rsp+0x10]
000071ff71bd9e25  vmovaps xmm2, [rsp+0x20]
000071ff71bd9e2b  vmovaps xmm3, [rsp+0x30]
000071ff71bd9e31  vmovaps xmm4, [rsp+0x40]
000071ff71bd9e37  vmovaps xmm5, [rsp+0x50]
000071ff71bd9e3d  vmovaps xmm6, [rsp+0x60]
000071ff71bd9e43  vmovaps xmm7, [rsp+0x70]
000071ff71bd9e49  vmovaps xmm8, [rsp+0x80]
000071ff71bd9e52  vmovaps xmm9, [rsp+0x90]
000071ff71bd9e5b  vmovaps xmm11, [rsp+0xA0]
000071ff71bd9e64  vmovaps xmm12, [rsp+0xB0]
000071ff71bd9e6d  vmovaps xmm13, [rsp+0xC0]
000071ff71bd9e76  vmovaps xmm14, [rsp+0xD0]
000071ff71bd9e7f  vmovaps xmm15, [rsp+0xE0]
000071ff71bd9e88  add rsp, 0xF0
000071ff71bd9e8f  pop r11
000071ff71bd9e91  pop r10
000071ff71bd9e93  pop r9
000071ff71bd9e95  pop r8
000071ff71bd9e97  pop rsi
000071ff71bd9e98  pop rdi
000071ff71bd9e99  pop rdx
000071ff71bd9e9a  pop rcx
000071ff71bd9e9b  pop rax
000071ff71bd9e9c  add rsp, 0x08
000071ff71bd9ea0  jmp 0x000071FF71BD8BE6
000071ff71bd9ea5  sub rsp, 0x08
000071ff71bd9ea9  push rax
000071ff71bd9eaa  push rcx
000071ff71bd9eab  push rdx
000071ff71bd9eac  push rdi
000071ff71bd9ead  push rsi
000071ff71bd9eae  push r8
000071ff71bd9eb0  push r9
000071ff71bd9eb2  push r10
000071ff71bd9eb4  push r11
000071ff71bd9eb6  sub rsp, 0xF0
000071ff71bd9ebd  vmovaps [rsp], xmm0
000071ff71bd9ec2  vmovaps [rsp+0x10], xmm1
000071ff71bd9ec8  vmovaps [rsp+0x20], xmm2
000071ff71bd9ece  vmovaps [rsp+0x30], xmm3
000071ff71bd9ed4  vmovaps [rsp+0x40], xmm4
000071ff71bd9eda  vmovaps [rsp+0x50], xmm5
000071ff71bd9ee0  vmovaps [rsp+0x60], xmm7
000071ff71bd9ee6  vmovaps [rsp+0x70], xmm8
000071ff71bd9eec  vmovaps [rsp+0x80], xmm9
000071ff71bd9ef5  vmovaps [rsp+0x90], xmm10
000071ff71bd9efe  vmovaps [rsp+0xA0], xmm11
000071ff71bd9f07  vmovaps [rsp+0xB0], xmm12
000071ff71bd9f10  vmovaps [rsp+0xC0], xmm13
000071ff71bd9f19  vmovaps [rsp+0xD0], xmm14
000071ff71bd9f22  vmovaps [rsp+0xE0], xmm15
000071ff71bd9f2b  sub rsp, 0x30
000071ff71bd9f2f  movaps [rsp], xmm6
000071ff71bd9f33  movaps [rsp+0x10], xmm12
000071ff71bd9f39  movaps [rsp+0x20], xmm11
000071ff71bd9f3f  lea rdi, [rsp]
000071ff71bd9f43  mov esi, 0x00
000071ff71bd9f48  mov rax, 0x5E6872E10530
000071ff71bd9f52  call rax
000071ff71bd9f54  movaps xmm6, [rsp]
000071ff71bd9f58  add rsp, 0x30
000071ff71bd9f5c  vmovaps xmm0, [rsp]
000071ff71bd9f61  vmovaps xmm1, [rsp+0x10]
000071ff71bd9f67  vmovaps xmm2, [rsp+0x20]
000071ff71bd9f6d  vmovaps xmm3, [rsp+0x30]
000071ff71bd9f73  vmovaps xmm4, [rsp+0x40]
000071ff71bd9f79  vmovaps xmm5, [rsp+0x50]
000071ff71bd9f7f  vmovaps xmm7, [rsp+0x60]
000071ff71bd9f85  vmovaps xmm8, [rsp+0x70]
000071ff71bd9f8b  vmovaps xmm9, [rsp+0x80]
000071ff71bd9f94  vmovaps xmm10, [rsp+0x90]
000071ff71bd9f9d  vmovaps xmm11, [rsp+0xA0]
000071ff71bd9fa6  vmovaps xmm12, [rsp+0xB0]
000071ff71bd9faf  vmovaps xmm13, [rsp+0xC0]
000071ff71bd9fb8  vmovaps xmm14, [rsp+0xD0]
000071ff71bd9fc1  vmovaps xmm15, [rsp+0xE0]
000071ff71bd9fca  add rsp, 0xF0
000071ff71bd9fd1  pop r11
000071ff71bd9fd3  pop r10
000071ff71bd9fd5  pop r9
000071ff71bd9fd7  pop r8
000071ff71bd9fd9  pop rsi
000071ff71bd9fda  pop rdi
000071ff71bd9fdb  pop rdx
000071ff71bd9fdc  pop rcx
000071ff71bd9fdd  pop rax
000071ff71bd9fde  add rsp, 0x08
000071ff71bd9fe2  jmp 0x000071FF71BD8C07
000071ff71bd9fe7  sub rsp, 0x08
000071ff71bd9feb  push rax
000071ff71bd9fec  push rcx
000071ff71bd9fed  push rdx
000071ff71bd9fee  push rdi
000071ff71bd9fef  push rsi
000071ff71bd9ff0  push r8
000071ff71bd9ff2  push r9
000071ff71bd9ff4  push r10
000071ff71bd9ff6  push r11
000071ff71bd9ff8  sub rsp, 0xF0
000071ff71bd9fff  vmovaps [rsp], xmm0
000071ff71bda004  vmovaps [rsp+0x10], xmm1
000071ff71bda00a  vmovaps [rsp+0x20], xmm2
000071ff71bda010  vmovaps [rsp+0x30], xmm4
000071ff71bda016  vmovaps [rsp+0x40], xmm5
000071ff71bda01c  vmovaps [rsp+0x50], xmm6
000071ff71bda022  vmovaps [rsp+0x60], xmm7
000071ff71bda028  vmovaps [rsp+0x70], xmm8
000071ff71bda02e  vmovaps [rsp+0x80], xmm9
000071ff71bda037  vmovaps [rsp+0x90], xmm10
000071ff71bda040  vmovaps [rsp+0xA0], xmm11
000071ff71bda049  vmovaps [rsp+0xB0], xmm12
000071ff71bda052  vmovaps [rsp+0xC0], xmm13
000071ff71bda05b  vmovaps [rsp+0xD0], xmm14
000071ff71bda064  vmovaps [rsp+0xE0], xmm15
000071ff71bda06d  sub rsp, 0x30
000071ff71bda071  movaps [rsp], xmm3
000071ff71bda075  movaps [rsp+0x10], xmm5
000071ff71bda07a  movaps [rsp+0x20], xmm4
000071ff71bda07f  lea rdi, [rsp]
000071ff71bda083  mov esi, 0x00
000071ff71bda088  mov rax, 0x5E6872E10530
000071ff71bda092  call rax
000071ff71bda094  movaps xmm3, [rsp]
000071ff71bda098  add rsp, 0x30
000071ff71bda09c  vmovaps xmm0, [rsp]
000071ff71bda0a1  vmovaps xmm1, [rsp+0x10]
000071ff71bda0a7  vmovaps xmm2, [rsp+0x20]
000071ff71bda0ad  vmovaps xmm4, [rsp+0x30]
000071ff71bda0b3  vmovaps xmm5, [rsp+0x40]
000071ff71bda0b9  vmovaps xmm6, [rsp+0x50]
000071ff71bda0bf  vmovaps xmm7, [rsp+0x60]
000071ff71bda0c5  vmovaps xmm8, [rsp+0x70]
000071ff71bda0cb  vmovaps xmm9, [rsp+0x80]
000071ff71bda0d4  vmovaps xmm10, [rsp+0x90]
000071ff71bda0dd  vmovaps xmm11, [rsp+0xA0]
000071ff71bda0e6  vmovaps xmm12, [rsp+0xB0]
000071ff71bda0ef  vmovaps xmm13, [rsp+0xC0]
000071ff71bda0f8  vmovaps xmm14, [rsp+0xD0]
000071ff71bda101  vmovaps xmm15, [rsp+0xE0]
000071ff71bda10a  add rsp, 0xF0
000071ff71bda111  pop r11
000071ff71bda113  pop r10
000071ff71bda115  pop r9
000071ff71bda117  pop r8
000071ff71bda119  pop rsi
000071ff71bda11a  pop rdi
000071ff71bda11b  pop rdx
000071ff71bda11c  pop rcx
000071ff71bda11d  pop rax
000071ff71bda11e  add rsp, 0x08
000071ff71bda122  jmp 0x000071FF71BD8C68
000071ff71bda127  sub rsp, 0x08
000071ff71bda12b  push rax
000071ff71bda12c  push rcx
000071ff71bda12d  push rdx
000071ff71bda12e  push rdi
000071ff71bda12f  push rsi
000071ff71bda130  push r8
000071ff71bda132  push r9
000071ff71bda134  push r10
000071ff71bda136  push r11
000071ff71bda138  sub rsp, 0xF0
000071ff71bda13f  vmovaps [rsp], xmm0
000071ff71bda144  vmovaps [rsp+0x10], xmm1
000071ff71bda14a  vmovaps [rsp+0x20], xmm2
000071ff71bda150  vmovaps [rsp+0x30], xmm3
000071ff71bda156  vmovaps [rsp+0x40], xmm4
000071ff71bda15c  vmovaps [rsp+0x50], xmm6
000071ff71bda162  vmovaps [rsp+0x60], xmm7
000071ff71bda168  vmovaps [rsp+0x70], xmm8
000071ff71bda16e  vmovaps [rsp+0x80], xmm9
000071ff71bda177  vmovaps [rsp+0x90], xmm10
000071ff71bda180  vmovaps [rsp+0xA0], xmm11
000071ff71bda189  vmovaps [rsp+0xB0], xmm12
000071ff71bda192  vmovaps [rsp+0xC0], xmm13
000071ff71bda19b  vmovaps [rsp+0xD0], xmm14
000071ff71bda1a4  vmovaps [rsp+0xE0], xmm15
000071ff71bda1ad  sub rsp, 0x30
000071ff71bda1b1  movaps [rsp], xmm5
000071ff71bda1b5  movaps [rsp+0x10], xmm8
000071ff71bda1bb  movaps [rsp+0x20], xmm15
000071ff71bda1c1  lea rdi, [rsp]
000071ff71bda1c5  mov esi, 0x00
000071ff71bda1ca  mov rax, 0x5E6872E10530
000071ff71bda1d4  call rax
000071ff71bda1d6  movaps xmm5, [rsp]
000071ff71bda1da  add rsp, 0x30
000071ff71bda1de  vmovaps xmm0, [rsp]
000071ff71bda1e3  vmovaps xmm1, [rsp+0x10]
000071ff71bda1e9  vmovaps xmm2, [rsp+0x20]
000071ff71bda1ef  vmovaps xmm3, [rsp+0x30]
000071ff71bda1f5  vmovaps xmm4, [rsp+0x40]
000071ff71bda1fb  vmovaps xmm6, [rsp+0x50]
000071ff71bda201  vmovaps xmm7, [rsp+0x60]
000071ff71bda207  vmovaps xmm8, [rsp+0x70]
000071ff71bda20d  vmovaps xmm9, [rsp+0x80]
000071ff71bda216  vmovaps xmm10, [rsp+0x90]
000071ff71bda21f  vmovaps xmm11, [rsp+0xA0]
000071ff71bda228  vmovaps xmm12, [rsp+0xB0]
000071ff71bda231  vmovaps xmm13, [rsp+0xC0]
000071ff71bda23a  vmovaps xmm14, [rsp+0xD0]
000071ff71bda243  vmovaps xmm15, [rsp+0xE0]
000071ff71bda24c  add rsp, 0xF0
000071ff71bda253  pop r11
000071ff71bda255  pop r10
000071ff71bda257  pop r9
000071ff71bda259  pop r8
000071ff71bda25b  pop rsi
000071ff71bda25c  pop rdi
000071ff71bda25d  pop rdx
000071ff71bda25e  pop rcx
000071ff71bda25f  pop rax
000071ff71bda260  add rsp, 0x08
000071ff71bda264  jmp 0x000071FF71BD8CA0
000071ff71bda269  sub rsp, 0x08
000071ff71bda26d  push rax
000071ff71bda26e  push rcx
000071ff71bda26f  push rdx
000071ff71bda270  push rdi
000071ff71bda271  push rsi
000071ff71bda272  push r8
000071ff71bda274  push r9
000071ff71bda276  push r10
000071ff71bda278  push r11
000071ff71bda27a  sub rsp, 0xF0
000071ff71bda281  vmovaps [rsp], xmm0
000071ff71bda286  vmovaps [rsp+0x10], xmm1
000071ff71bda28c  vmovaps [rsp+0x20], xmm2
000071ff71bda292  vmovaps [rsp+0x30], xmm3
000071ff71bda298  vmovaps [rsp+0x40], xmm5
000071ff71bda29e  vmovaps [rsp+0x50], xmm6
000071ff71bda2a4  vmovaps [rsp+0x60], xmm7
000071ff71bda2aa  vmovaps [rsp+0x70], xmm8
000071ff71bda2b0  vmovaps [rsp+0x80], xmm9
000071ff71bda2b9  vmovaps [rsp+0x90], xmm10
000071ff71bda2c2  vmovaps [rsp+0xA0], xmm11
000071ff71bda2cb  vmovaps [rsp+0xB0], xmm12
000071ff71bda2d4  vmovaps [rsp+0xC0], xmm13
000071ff71bda2dd  vmovaps [rsp+0xD0], xmm14
000071ff71bda2e6  vmovaps [rsp+0xE0], xmm15
000071ff71bda2ef  sub rsp, 0x30
000071ff71bda2f3  movaps [rsp], xmm4
000071ff71bda2f7  movaps [rsp+0x10], xmm9
000071ff71bda2fd  movaps [rsp+0x20], xmm8
000071ff71bda303  lea rdi, [rsp]
000071ff71bda307  mov esi, 0x00
000071ff71bda30c  mov rax, 0x5E6872E10530
000071ff71bda316  call rax
000071ff71bda318  movaps xmm4, [rsp]
000071ff71bda31c  add rsp, 0x30
000071ff71bda320  vmovaps xmm0, [rsp]
000071ff71bda325  vmovaps xmm1, [rsp+0x10]
000071ff71bda32b  vmovaps xmm2, [rsp+0x20]
000071ff71bda331  vmovaps xmm3, [rsp+0x30]
000071ff71bda337  vmovaps xmm5, [rsp+0x40]
000071ff71bda33d  vmovaps xmm6, [rsp+0x50]
000071ff71bda343  vmovaps xmm7, [rsp+0x60]
000071ff71bda349  vmovaps xmm8, [rsp+0x70]
000071ff71bda34f  vmovaps xmm9, [rsp+0x80]
000071ff71bda358  vmovaps xmm10, [rsp+0x90]
000071ff71bda361  vmovaps xmm11, [rsp+0xA0]
000071ff71bda36a  vmovaps xmm12, [rsp+0xB0]
000071ff71bda373  vmovaps xmm13, [rsp+0xC0]
000071ff71bda37c  vmovaps xmm14, [rsp+0xD0]
000071ff71bda385  vmovaps xmm15, [rsp+0xE0]
000071ff71bda38e  add rsp, 0xF0
000071ff71bda395  pop r11
000071ff71bda397  pop r10
000071ff71bda399  pop r9
000071ff71bda39b  pop r8
000071ff71bda39d  pop rsi
000071ff71bda39e  pop rdi
000071ff71bda39f  pop rdx
000071ff71bda3a0  pop rcx
000071ff71bda3a1  pop rax
000071ff71bda3a2  add rsp, 0x08
000071ff71bda3a6  jmp 0x000071FF71BD8CC1
000071ff71bda3ab  sub rsp, 0x08
000071ff71bda3af  push rax
000071ff71bda3b0  push rcx
000071ff71bda3b1  push rdx
000071ff71bda3b2  push rdi
000071ff71bda3b3  push rsi
000071ff71bda3b4  push r8
000071ff71bda3b6  push r9
000071ff71bda3b8  push r10
000071ff71bda3ba  push r11
000071ff71bda3bc  sub rsp, 0xF0
000071ff71bda3c3  vmovaps [rsp], xmm0
000071ff71bda3c8  vmovaps [rsp+0x10], xmm1
000071ff71bda3ce  vmovaps [rsp+0x20], xmm2
000071ff71bda3d4  vmovaps [rsp+0x30], xmm3
000071ff71bda3da  vmovaps [rsp+0x40], xmm4
000071ff71bda3e0  vmovaps [rsp+0x50], xmm5
000071ff71bda3e6  vmovaps [rsp+0x60], xmm6
000071ff71bda3ec  vmovaps [rsp+0x70], xmm7
000071ff71bda3f2  vmovaps [rsp+0x80], xmm8
000071ff71bda3fb  vmovaps [rsp+0x90], xmm10
000071ff71bda404  vmovaps [rsp+0xA0], xmm11
000071ff71bda40d  vmovaps [rsp+0xB0], xmm12
000071ff71bda416  vmovaps [rsp+0xC0], xmm13
000071ff71bda41f  vmovaps [rsp+0xD0], xmm14
000071ff71bda428  vmovaps [rsp+0xE0], xmm15
000071ff71bda431  sub rsp, 0x30
000071ff71bda435  movaps [rsp], xmm9
000071ff71bda43a  movaps [rsp+0x10], xmm10
000071ff71bda440  movaps [rsp+0x20], xmm8
000071ff71bda446  lea rdi, [rsp]
000071ff71bda44a  mov esi, 0x00
000071ff71bda44f  mov rax, 0x5E6872E10530
000071ff71bda459  call rax
000071ff71bda45b  movaps xmm9, [rsp]
000071ff71bda460  add rsp, 0x30
000071ff71bda464  vmovaps xmm0, [rsp]
000071ff71bda469  vmovaps xmm1, [rsp+0x10]
000071ff71bda46f  vmovaps xmm2, [rsp+0x20]
000071ff71bda475  vmovaps xmm3, [rsp+0x30]
000071ff71bda47b  vmovaps xmm4, [rsp+0x40]
000071ff71bda481  vmovaps xmm5, [rsp+0x50]
000071ff71bda487  vmovaps xmm6, [rsp+0x60]
000071ff71bda48d  vmovaps xmm7, [rsp+0x70]
000071ff71bda493  vmovaps xmm8, [rsp+0x80]
000071ff71bda49c  vmovaps xmm10, [rsp+0x90]
000071ff71bda4a5  vmovaps xmm11, [rsp+0xA0]
000071ff71bda4ae  vmovaps xmm12, [rsp+0xB0]
000071ff71bda4b7  vmovaps xmm13, [rsp+0xC0]
000071ff71bda4c0  vmovaps xmm14, [rsp+0xD0]
000071ff71bda4c9  vmovaps xmm15, [rsp+0xE0]
000071ff71bda4d2  add rsp, 0xF0
000071ff71bda4d9  pop r11
000071ff71bda4db  pop r10
000071ff71bda4dd  pop r9
000071ff71bda4df  pop r8
000071ff71bda4e1  pop rsi
000071ff71bda4e2  pop rdi
000071ff71bda4e3  pop rdx
000071ff71bda4e4  pop rcx
000071ff71bda4e5  pop rax
000071ff71bda4e6  add rsp, 0x08
000071ff71bda4ea  jmp 0x000071FF71BD8CDB
000071ff71bda4ef  call 0x000071FF71AD64F0
000071ff71bda4f4  jmp 0x000071FF71BD8DF5
000071ff71bda4f9  call 0x000071FF71AD64F0
000071ff71bda4fe  jmp 0x000071FF71BD8E0B
000071ff71bda503  sub rsp, 0x08
000071ff71bda507  push rax
000071ff71bda508  push rcx
000071ff71bda509  push rdx
000071ff71bda50a  push rdi
000071ff71bda50b  push rsi
000071ff71bda50c  push r8
000071ff71bda50e  push r9
000071ff71bda510  push r10
000071ff71bda512  push r11
000071ff71bda514  sub rsp, 0xF0
000071ff71bda51b  vmovaps [rsp], xmm0
000071ff71bda520  vmovaps [rsp+0x10], xmm2
000071ff71bda526  vmovaps [rsp+0x20], xmm3
000071ff71bda52c  vmovaps [rsp+0x30], xmm4
000071ff71bda532  vmovaps [rsp+0x40], xmm5
000071ff71bda538  vmovaps [rsp+0x50], xmm6
000071ff71bda53e  vmovaps [rsp+0x60], xmm7
000071ff71bda544  vmovaps [rsp+0x70], xmm8
000071ff71bda54a  vmovaps [rsp+0x80], xmm9
000071ff71bda553  vmovaps [rsp+0x90], xmm10
000071ff71bda55c  vmovaps [rsp+0xA0], xmm11
000071ff71bda565  vmovaps [rsp+0xB0], xmm12
000071ff71bda56e  vmovaps [rsp+0xC0], xmm13
000071ff71bda577  vmovaps [rsp+0xD0], xmm14
000071ff71bda580  vmovaps [rsp+0xE0], xmm15
000071ff71bda589  sub rsp, 0x30
000071ff71bda58d  movaps [rsp], xmm1
000071ff71bda591  movaps [rsp+0x10], xmm6
000071ff71bda596  movaps [rsp+0x20], xmm15
000071ff71bda59c  lea rdi, [rsp]
000071ff71bda5a0  mov esi, 0x00
000071ff71bda5a5  mov rax, 0x5E6872E10530
000071ff71bda5af  call rax
000071ff71bda5b1  movaps xmm1, [rsp]
000071ff71bda5b5  add rsp, 0x30
000071ff71bda5b9  vmovaps xmm0, [rsp]
000071ff71bda5be  vmovaps xmm2, [rsp+0x10]
000071ff71bda5c4  vmovaps xmm3, [rsp+0x20]
000071ff71bda5ca  vmovaps xmm4, [rsp+0x30]
000071ff71bda5d0  vmovaps xmm5, [rsp+0x40]
000071ff71bda5d6  vmovaps xmm6, [rsp+0x50]
000071ff71bda5dc  vmovaps xmm7, [rsp+0x60]
000071ff71bda5e2  vmovaps xmm8, [rsp+0x70]
000071ff71bda5e8  vmovaps xmm9, [rsp+0x80]
000071ff71bda5f1  vmovaps xmm10, [rsp+0x90]
000071ff71bda5fa  vmovaps xmm11, [rsp+0xA0]
000071ff71bda603  vmovaps xmm12, [rsp+0xB0]
000071ff71bda60c  vmovaps xmm13, [rsp+0xC0]
000071ff71bda615  vmovaps xmm14, [rsp+0xD0]
000071ff71bda61e  vmovaps xmm15, [rsp+0xE0]
000071ff71bda627  add rsp, 0xF0
000071ff71bda62e  pop r11
000071ff71bda630  pop r10
000071ff71bda632  pop r9
000071ff71bda634  pop r8
000071ff71bda636  pop rsi
000071ff71bda637  pop rdi
000071ff71bda638  pop rdx
000071ff71bda639  pop rcx
000071ff71bda63a  pop rax
000071ff71bda63b  add rsp, 0x08
000071ff71bda63f  jmp 0x000071FF71BD8E48
000071ff71bda644  call 0x000071FF71AE5820
000071ff71bda649  jmp 0x000071FF71BD8E55
000071ff71bda64e  sub rsp, 0x08
000071ff71bda652  push rax
000071ff71bda653  push rcx
000071ff71bda654  push rdx
000071ff71bda655  push rdi
000071ff71bda656  push rsi
000071ff71bda657  push r8
000071ff71bda659  push r9
000071ff71bda65b  push r10
000071ff71bda65d  push r11
000071ff71bda65f  sub rsp, 0xF0
000071ff71bda666  vmovaps [rsp], xmm0
000071ff71bda66b  vmovaps [rsp+0x10], xmm1
000071ff71bda671  vmovaps [rsp+0x20], xmm2
000071ff71bda677  vmovaps [rsp+0x30], xmm3
000071ff71bda67d  vmovaps [rsp+0x40], xmm4
000071ff71bda683  vmovaps [rsp+0x50], xmm5
000071ff71bda689  vmovaps [rsp+0x60], xmm6
000071ff71bda68f  vmovaps [rsp+0x70], xmm7
000071ff71bda695  vmovaps [rsp+0x80], xmm8
000071ff71bda69e  vmovaps [rsp+0x90], xmm9
000071ff71bda6a7  vmovaps [rsp+0xA0], xmm10
000071ff71bda6b0  vmovaps [rsp+0xB0], xmm11
000071ff71bda6b9  vmovaps [rsp+0xC0], xmm12
000071ff71bda6c2  vmovaps [rsp+0xD0], xmm13
000071ff71bda6cb  vmovaps [rsp+0xE0], xmm15
000071ff71bda6d4  sub rsp, 0x30
000071ff71bda6d8  movaps [rsp], xmm14
000071ff71bda6dd  movaps [rsp+0x10], xmm4
000071ff71bda6e2  movaps [rsp+0x20], xmm3
000071ff71bda6e7  lea rdi, [rsp]
000071ff71bda6eb  mov esi, 0x00
000071ff71bda6f0  mov rax, 0x5E6872E10530
000071ff71bda6fa  call rax
000071ff71bda6fc  movaps xmm14, [rsp]
000071ff71bda701  add rsp, 0x30
000071ff71bda705  vmovaps xmm0, [rsp]
000071ff71bda70a  vmovaps xmm1, [rsp+0x10]
000071ff71bda710  vmovaps xmm2, [rsp+0x20]
000071ff71bda716  vmovaps xmm3, [rsp+0x30]
000071ff71bda71c  vmovaps xmm4, [rsp+0x40]
000071ff71bda722  vmovaps xmm5, [rsp+0x50]
000071ff71bda728  vmovaps xmm6, [rsp+0x60]
000071ff71bda72e  vmovaps xmm7, [rsp+0x70]
000071ff71bda734  vmovaps xmm8, [rsp+0x80]
000071ff71bda73d  vmovaps xmm9, [rsp+0x90]
000071ff71bda746  vmovaps xmm10, [rsp+0xA0]
000071ff71bda74f  vmovaps xmm11, [rsp+0xB0]
000071ff71bda758  vmovaps xmm12, [rsp+0xC0]
000071ff71bda761  vmovaps xmm13, [rsp+0xD0]
000071ff71bda76a  vmovaps xmm15, [rsp+0xE0]
000071ff71bda773  add rsp, 0xF0
000071ff71bda77a  pop r11
000071ff71bda77c  pop r10
000071ff71bda77e  pop r9
000071ff71bda780  pop r8
000071ff71bda782  pop rsi
000071ff71bda783  pop rdi
000071ff71bda784  pop rdx
000071ff71bda785  pop rcx
000071ff71bda786  pop rax
000071ff71bda787  add rsp, 0x08
000071ff71bda78b  jmp 0x000071FF71BD8E6F
000071ff71bda790  sub rsp, 0x08
000071ff71bda794  push rax
000071ff71bda795  push rcx
000071ff71bda796  push rdx
000071ff71bda797  push rdi
000071ff71bda798  push rsi
000071ff71bda799  push r8
000071ff71bda79b  push r9
000071ff71bda79d  push r10
000071ff71bda79f  push r11
000071ff71bda7a1  sub rsp, 0xF0
000071ff71bda7a8  vmovaps [rsp], xmm0
000071ff71bda7ad  vmovaps [rsp+0x10], xmm1
000071ff71bda7b3  vmovaps [rsp+0x20], xmm2
000071ff71bda7b9  vmovaps [rsp+0x30], xmm3
000071ff71bda7bf  vmovaps [rsp+0x40], xmm4
000071ff71bda7c5  vmovaps [rsp+0x50], xmm5
000071ff71bda7cb  vmovaps [rsp+0x60], xmm7
000071ff71bda7d1  vmovaps [rsp+0x70], xmm8
000071ff71bda7d7  vmovaps [rsp+0x80], xmm9
000071ff71bda7e0  vmovaps [rsp+0x90], xmm10
000071ff71bda7e9  vmovaps [rsp+0xA0], xmm11
000071ff71bda7f2  vmovaps [rsp+0xB0], xmm12
000071ff71bda7fb  vmovaps [rsp+0xC0], xmm13
000071ff71bda804  vmovaps [rsp+0xD0], xmm14
000071ff71bda80d  vmovaps [rsp+0xE0], xmm15
000071ff71bda816  sub rsp, 0x30
000071ff71bda81a  movaps [rsp], xmm6
000071ff71bda81e  movaps [rsp+0x10], xmm9
000071ff71bda824  movaps [rsp+0x20], xmm7
000071ff71bda829  lea rdi, [rsp]
000071ff71bda82d  mov esi, 0x00
000071ff71bda832  mov rax, 0x5E6872E10530
000071ff71bda83c  call rax
000071ff71bda83e  movaps xmm6, [rsp]
000071ff71bda842  add rsp, 0x30
000071ff71bda846  vmovaps xmm0, [rsp]
000071ff71bda84b  vmovaps xmm1, [rsp+0x10]
000071ff71bda851  vmovaps xmm2, [rsp+0x20]
000071ff71bda857  vmovaps xmm3, [rsp+0x30]
000071ff71bda85d  vmovaps xmm4, [rsp+0x40]
000071ff71bda863  vmovaps xmm5, [rsp+0x50]
000071ff71bda869  vmovaps xmm7, [rsp+0x60]
000071ff71bda86f  vmovaps xmm8, [rsp+0x70]
000071ff71bda875  vmovaps xmm9, [rsp+0x80]
000071ff71bda87e  vmovaps xmm10, [rsp+0x90]
000071ff71bda887  vmovaps xmm11, [rsp+0xA0]
000071ff71bda890  vmovaps xmm12, [rsp+0xB0]
000071ff71bda899  vmovaps xmm13, [rsp+0xC0]
000071ff71bda8a2  vmovaps xmm14, [rsp+0xD0]
000071ff71bda8ab  vmovaps xmm15, [rsp+0xE0]
000071ff71bda8b4  add rsp, 0xF0
000071ff71bda8bb  pop r11
000071ff71bda8bd  pop r10
000071ff71bda8bf  pop r9
000071ff71bda8c1  pop r8
000071ff71bda8c3  pop rsi
000071ff71bda8c4  pop rdi
000071ff71bda8c5  pop rdx
000071ff71bda8c6  pop rcx
000071ff71bda8c7  pop rax
000071ff71bda8c8  add rsp, 0x08
000071ff71bda8cc  jmp 0x000071FF71BD8E87
000071ff71bda8d1  sub rsp, 0x08
000071ff71bda8d5  push rax
000071ff71bda8d6  push rcx
000071ff71bda8d7  push rdx
000071ff71bda8d8  push rdi
000071ff71bda8d9  push rsi
000071ff71bda8da  push r8
000071ff71bda8dc  push r9
000071ff71bda8de  push r10
000071ff71bda8e0  push r11
000071ff71bda8e2  sub rsp, 0xF0
000071ff71bda8e9  vmovaps [rsp], xmm0
000071ff71bda8ee  vmovaps [rsp+0x10], xmm1
000071ff71bda8f4  vmovaps [rsp+0x20], xmm2
000071ff71bda8fa  vmovaps [rsp+0x30], xmm3
000071ff71bda900  vmovaps [rsp+0x40], xmm4
000071ff71bda906  vmovaps [rsp+0x50], xmm5
000071ff71bda90c  vmovaps [rsp+0x60], xmm6
000071ff71bda912  vmovaps [rsp+0x70], xmm8
000071ff71bda918  vmovaps [rsp+0x80], xmm9
000071ff71bda921  vmovaps [rsp+0x90], xmm10
000071ff71bda92a  vmovaps [rsp+0xA0], xmm11
000071ff71bda933  vmovaps [rsp+0xB0], xmm12
000071ff71bda93c  vmovaps [rsp+0xC0], xmm13
000071ff71bda945  vmovaps [rsp+0xD0], xmm14
000071ff71bda94e  vmovaps [rsp+0xE0], xmm15
000071ff71bda957  sub rsp, 0x30
000071ff71bda95b  movaps [rsp], xmm7
000071ff71bda95f  movaps [rsp+0x10], xmm4
000071ff71bda964  movaps [rsp+0x20], xmm9
000071ff71bda96a  lea rdi, [rsp]
000071ff71bda96e  mov esi, 0x00
000071ff71bda973  mov rax, 0x5E6872E10530
000071ff71bda97d  call rax
000071ff71bda97f  movaps xmm7, [rsp]
000071ff71bda983  add rsp, 0x30
000071ff71bda987  vmovaps xmm0, [rsp]
000071ff71bda98c  vmovaps xmm1, [rsp+0x10]
000071ff71bda992  vmovaps xmm2, [rsp+0x20]
000071ff71bda998  vmovaps xmm3, [rsp+0x30]
000071ff71bda99e  vmovaps xmm4, [rsp+0x40]
000071ff71bda9a4  vmovaps xmm5, [rsp+0x50]
000071ff71bda9aa  vmovaps xmm6, [rsp+0x60]
000071ff71bda9b0  vmovaps xmm8, [rsp+0x70]
000071ff71bda9b6  vmovaps xmm9, [rsp+0x80]
000071ff71bda9bf  vmovaps xmm10, [rsp+0x90]
000071ff71bda9c8  vmovaps xmm11, [rsp+0xA0]
000071ff71bda9d1  vmovaps xmm12, [rsp+0xB0]
000071ff71bda9da  vmovaps xmm13, [rsp+0xC0]
000071ff71bda9e3  vmovaps xmm14, [rsp+0xD0]
000071ff71bda9ec  vmovaps xmm15, [rsp+0xE0]
000071ff71bda9f5  add rsp, 0xF0
000071ff71bda9fc  pop r11
000071ff71bda9fe  pop r10
000071ff71bdaa00  pop r9
000071ff71bdaa02  pop r8
000071ff71bdaa04  pop rsi
000071ff71bdaa05  pop rdi
000071ff71bdaa06  pop rdx
000071ff71bdaa07  pop rcx
000071ff71bdaa08  pop rax
000071ff71bdaa09  add rsp, 0x08
000071ff71bdaa0d  jmp 0x000071FF71BD8EB4
000071ff71bdaa12  sub rsp, 0x08
000071ff71bdaa16  push rax
000071ff71bdaa17  push rcx
000071ff71bdaa18  push rdx
000071ff71bdaa19  push rdi
000071ff71bdaa1a  push rsi
000071ff71bdaa1b  push r8
000071ff71bdaa1d  push r9
000071ff71bdaa1f  push r10
000071ff71bdaa21  push r11
000071ff71bdaa23  sub rsp, 0xF0
000071ff71bdaa2a  vmovaps [rsp], xmm0
000071ff71bdaa2f  vmovaps [rsp+0x10], xmm1
000071ff71bdaa35  vmovaps [rsp+0x20], xmm2
000071ff71bdaa3b  vmovaps [rsp+0x30], xmm3
000071ff71bdaa41  vmovaps [rsp+0x40], xmm5
000071ff71bdaa47  vmovaps [rsp+0x50], xmm6
000071ff71bdaa4d  vmovaps [rsp+0x60], xmm7
000071ff71bdaa53  vmovaps [rsp+0x70], xmm8
000071ff71bdaa59  vmovaps [rsp+0x80], xmm9
000071ff71bdaa62  vmovaps [rsp+0x90], xmm10
000071ff71bdaa6b  vmovaps [rsp+0xA0], xmm11
000071ff71bdaa74  vmovaps [rsp+0xB0], xmm12
000071ff71bdaa7d  vmovaps [rsp+0xC0], xmm13
000071ff71bdaa86  vmovaps [rsp+0xD0], xmm14
000071ff71bdaa8f  vmovaps [rsp+0xE0], xmm15
000071ff71bdaa98  sub rsp, 0x30
000071ff71bdaa9c  movaps [rsp], xmm4
000071ff71bdaaa0  movaps [rsp+0x10], xmm15
000071ff71bdaaa6  movaps [rsp+0x20], xmm9
000071ff71bdaaac  lea rdi, [rsp]
000071ff71bdaab0  mov esi, 0x00
000071ff71bdaab5  mov rax, 0x5E6872E10530
000071ff71bdaabf  call rax
000071ff71bdaac1  movaps xmm4, [rsp]
000071ff71bdaac5  add rsp, 0x30
000071ff71bdaac9  vmovaps xmm0, [rsp]
000071ff71bdaace  vmovaps xmm1, [rsp+0x10]
000071ff71bdaad4  vmovaps xmm2, [rsp+0x20]
000071ff71bdaada  vmovaps xmm3, [rsp+0x30]
000071ff71bdaae0  vmovaps xmm5, [rsp+0x40]
000071ff71bdaae6  vmovaps xmm6, [rsp+0x50]
000071ff71bdaaec  vmovaps xmm7, [rsp+0x60]
000071ff71bdaaf2  vmovaps xmm8, [rsp+0x70]
000071ff71bdaaf8  vmovaps xmm9, [rsp+0x80]
000071ff71bdab01  vmovaps xmm10, [rsp+0x90]
000071ff71bdab0a  vmovaps xmm11, [rsp+0xA0]
000071ff71bdab13  vmovaps xmm12, [rsp+0xB0]
000071ff71bdab1c  vmovaps xmm13, [rsp+0xC0]
000071ff71bdab25  vmovaps xmm14, [rsp+0xD0]
000071ff71bdab2e  vmovaps xmm15, [rsp+0xE0]
000071ff71bdab37  add rsp, 0xF0
000071ff71bdab3e  pop r11
000071ff71bdab40  pop r10
000071ff71bdab42  pop r9
000071ff71bdab44  pop r8
000071ff71bdab46  pop rsi
000071ff71bdab47  pop rdi
000071ff71bdab48  pop rdx
000071ff71bdab49  pop rcx
000071ff71bdab4a  pop rax
000071ff71bdab4b  add rsp, 0x08
000071ff71bdab4f  jmp 0x000071FF71BD8ED9
000071ff71bdab54  call 0x000071FF71AE5820
000071ff71bdab59  jmp 0x000071FF71BD8EE6
000071ff71bdab5e  sub rsp, 0x08
000071ff71bdab62  push rax
000071ff71bdab63  push rcx
000071ff71bdab64  push rdx
000071ff71bdab65  push rdi
000071ff71bdab66  push rsi
000071ff71bdab67  push r8
000071ff71bdab69  push r9
000071ff71bdab6b  push r10
000071ff71bdab6d  push r11
000071ff71bdab6f  sub rsp, 0xF0
000071ff71bdab76  vmovaps [rsp], xmm0
000071ff71bdab7b  vmovaps [rsp+0x10], xmm1
000071ff71bdab81  vmovaps [rsp+0x20], xmm2
000071ff71bdab87  vmovaps [rsp+0x30], xmm4
000071ff71bdab8d  vmovaps [rsp+0x40], xmm5
000071ff71bdab93  vmovaps [rsp+0x50], xmm6
000071ff71bdab99  vmovaps [rsp+0x60], xmm7
000071ff71bdab9f  vmovaps [rsp+0x70], xmm8
000071ff71bdaba5  vmovaps [rsp+0x80], xmm9
000071ff71bdabae  vmovaps [rsp+0x90], xmm10
000071ff71bdabb7  vmovaps [rsp+0xA0], xmm11
000071ff71bdabc0  vmovaps [rsp+0xB0], xmm12
000071ff71bdabc9  vmovaps [rsp+0xC0], xmm13
000071ff71bdabd2  vmovaps [rsp+0xD0], xmm14
000071ff71bdabdb  vmovaps [rsp+0xE0], xmm15
000071ff71bdabe4  sub rsp, 0x30
000071ff71bdabe8  movaps [rsp], xmm3
000071ff71bdabec  movaps [rsp+0x10], xmm1
000071ff71bdabf1  movaps [rsp+0x20], xmm9
000071ff71bdabf7  lea rdi, [rsp]
000071ff71bdabfb  mov esi, 0x00
000071ff71bdac00  mov rax, 0x5E6872E10530
000071ff71bdac0a  call rax
000071ff71bdac0c  movaps xmm3, [rsp]
000071ff71bdac10  add rsp, 0x30
000071ff71bdac14  vmovaps xmm0, [rsp]
000071ff71bdac19  vmovaps xmm1, [rsp+0x10]
000071ff71bdac1f  vmovaps xmm2, [rsp+0x20]
000071ff71bdac25  vmovaps xmm4, [rsp+0x30]
000071ff71bdac2b  vmovaps xmm5, [rsp+0x40]
000071ff71bdac31  vmovaps xmm6, [rsp+0x50]
000071ff71bdac37  vmovaps xmm7, [rsp+0x60]
000071ff71bdac3d  vmovaps xmm8, [rsp+0x70]
000071ff71bdac43  vmovaps xmm9, [rsp+0x80]
000071ff71bdac4c  vmovaps xmm10, [rsp+0x90]
000071ff71bdac55  vmovaps xmm11, [rsp+0xA0]
000071ff71bdac5e  vmovaps xmm12, [rsp+0xB0]
000071ff71bdac67  vmovaps xmm13, [rsp+0xC0]
000071ff71bdac70  vmovaps xmm14, [rsp+0xD0]
000071ff71bdac79  vmovaps xmm15, [rsp+0xE0]
000071ff71bdac82  add rsp, 0xF0
000071ff71bdac89  pop r11
000071ff71bdac8b  pop r10
000071ff71bdac8d  pop r9
000071ff71bdac8f  pop r8
000071ff71bdac91  pop rsi
000071ff71bdac92  pop rdi
000071ff71bdac93  pop rdx
000071ff71bdac94  pop rcx
000071ff71bdac95  pop rax
000071ff71bdac96  add rsp, 0x08
000071ff71bdac9a  jmp 0x000071FF71BD8F23
000071ff71bdac9f  sub rsp, 0x08
000071ff71bdaca3  push rax
000071ff71bdaca4  push rcx
000071ff71bdaca5  push rdx
000071ff71bdaca6  push rdi
000071ff71bdaca7  push rsi
000071ff71bdaca8  push r8
000071ff71bdacaa  push r9
000071ff71bdacac  push r10
000071ff71bdacae  push r11
000071ff71bdacb0  sub rsp, 0xF0
000071ff71bdacb7  vmovaps [rsp], xmm0
000071ff71bdacbc  vmovaps [rsp+0x10], xmm2
000071ff71bdacc2  vmovaps [rsp+0x20], xmm3
000071ff71bdacc8  vmovaps [rsp+0x30], xmm4
000071ff71bdacce  vmovaps [rsp+0x40], xmm5
000071ff71bdacd4  vmovaps [rsp+0x50], xmm6
000071ff71bdacda  vmovaps [rsp+0x60], xmm7
000071ff71bdace0  vmovaps [rsp+0x70], xmm8
000071ff71bdace6  vmovaps [rsp+0x80], xmm9
000071ff71bdacef  vmovaps [rsp+0x90], xmm10
000071ff71bdacf8  vmovaps [rsp+0xA0], xmm11
000071ff71bdad01  vmovaps [rsp+0xB0], xmm12
000071ff71bdad0a  vmovaps [rsp+0xC0], xmm13
000071ff71bdad13  vmovaps [rsp+0xD0], xmm14
000071ff71bdad1c  vmovaps [rsp+0xE0], xmm15
000071ff71bdad25  sub rsp, 0x30
000071ff71bdad29  movaps [rsp], xmm1
000071ff71bdad2d  movaps [rsp+0x10], xmm15
000071ff71bdad33  movaps [rsp+0x20], xmm9
000071ff71bdad39  lea rdi, [rsp]
000071ff71bdad3d  mov esi, 0x00
000071ff71bdad42  mov rax, 0x5E6872E10530
000071ff71bdad4c  call rax
000071ff71bdad4e  movaps xmm1, [rsp]
000071ff71bdad52  add rsp, 0x30
000071ff71bdad56  vmovaps xmm0, [rsp]
000071ff71bdad5b  vmovaps xmm2, [rsp+0x10]
000071ff71bdad61  vmovaps xmm3, [rsp+0x20]
000071ff71bdad67  vmovaps xmm4, [rsp+0x30]
000071ff71bdad6d  vmovaps xmm5, [rsp+0x40]
000071ff71bdad73  vmovaps xmm6, [rsp+0x50]
000071ff71bdad79  vmovaps xmm7, [rsp+0x60]
000071ff71bdad7f  vmovaps xmm8, [rsp+0x70]
000071ff71bdad85  vmovaps xmm9, [rsp+0x80]
000071ff71bdad8e  vmovaps xmm10, [rsp+0x90]
000071ff71bdad97  vmovaps xmm11, [rsp+0xA0]
000071ff71bdada0  vmovaps xmm12, [rsp+0xB0]
000071ff71bdada9  vmovaps xmm13, [rsp+0xC0]
000071ff71bdadb2  vmovaps xmm14, [rsp+0xD0]
000071ff71bdadbb  vmovaps xmm15, [rsp+0xE0]
000071ff71bdadc4  add rsp, 0xF0
000071ff71bdadcb  pop r11
000071ff71bdadcd  pop r10
000071ff71bdadcf  pop r9
000071ff71bdadd1  pop r8
000071ff71bdadd3  pop rsi
000071ff71bdadd4  pop rdi
000071ff71bdadd5  pop rdx
000071ff71bdadd6  pop rcx
000071ff71bdadd7  pop rax
000071ff71bdadd8  add rsp, 0x08
000071ff71bdaddc  jmp 0x000071FF71BD8FAB
000071ff71bdade1  call 0x000071FF71AE5820
000071ff71bdade6  jmp 0x000071FF71BD8FB8
000071ff71bdadeb  sub rsp, 0x08
000071ff71bdadef  push rax
000071ff71bdadf0  push rcx
000071ff71bdadf1  push rdx
000071ff71bdadf2  push rdi
000071ff71bdadf3  push rsi
000071ff71bdadf4  push r8
000071ff71bdadf6  push r9
000071ff71bdadf8  push r10
000071ff71bdadfa  push r11
000071ff71bdadfc  sub rsp, 0xF0
000071ff71bdae03  vmovaps [rsp], xmm0
000071ff71bdae08  vmovaps [rsp+0x10], xmm2
000071ff71bdae0e  vmovaps [rsp+0x20], xmm3
000071ff71bdae14  vmovaps [rsp+0x30], xmm4
000071ff71bdae1a  vmovaps [rsp+0x40], xmm5
000071ff71bdae20  vmovaps [rsp+0x50], xmm6
000071ff71bdae26  vmovaps [rsp+0x60], xmm7
000071ff71bdae2c  vmovaps [rsp+0x70], xmm8
000071ff71bdae32  vmovaps [rsp+0x80], xmm9
000071ff71bdae3b  vmovaps [rsp+0x90], xmm10
000071ff71bdae44  vmovaps [rsp+0xA0], xmm11
000071ff71bdae4d  vmovaps [rsp+0xB0], xmm12
000071ff71bdae56  vmovaps [rsp+0xC0], xmm13
000071ff71bdae5f  vmovaps [rsp+0xD0], xmm14
000071ff71bdae68  vmovaps [rsp+0xE0], xmm15
000071ff71bdae71  sub rsp, 0x30
000071ff71bdae75  movaps [rsp], xmm1
000071ff71bdae79  movaps [rsp+0x10], xmm5
000071ff71bdae7e  movaps [rsp+0x20], xmm7
000071ff71bdae83  lea rdi, [rsp]
000071ff71bdae87  mov esi, 0x00
000071ff71bdae8c  mov rax, 0x5E6872E10530
000071ff71bdae96  call rax
000071ff71bdae98  movaps xmm1, [rsp]
000071ff71bdae9c  add rsp, 0x30
000071ff71bdaea0  vmovaps xmm0, [rsp]
000071ff71bdaea5  vmovaps xmm2, [rsp+0x10]
000071ff71bdaeab  vmovaps xmm3, [rsp+0x20]
000071ff71bdaeb1  vmovaps xmm4, [rsp+0x30]
000071ff71bdaeb7  vmovaps xmm5, [rsp+0x40]
000071ff71bdaebd  vmovaps xmm6, [rsp+0x50]
000071ff71bdaec3  vmovaps xmm7, [rsp+0x60]
000071ff71bdaec9  vmovaps xmm8, [rsp+0x70]
000071ff71bdaecf  vmovaps xmm9, [rsp+0x80]
000071ff71bdaed8  vmovaps xmm10, [rsp+0x90]
000071ff71bdaee1  vmovaps xmm11, [rsp+0xA0]
000071ff71bdaeea  vmovaps xmm12, [rsp+0xB0]
000071ff71bdaef3  vmovaps xmm13, [rsp+0xC0]
000071ff71bdaefc  vmovaps xmm14, [rsp+0xD0]
000071ff71bdaf05  vmovaps xmm15, [rsp+0xE0]
000071ff71bdaf0e  add rsp, 0xF0
000071ff71bdaf15  pop r11
000071ff71bdaf17  pop r10
000071ff71bdaf19  pop r9
000071ff71bdaf1b  pop r8
000071ff71bdaf1d  pop rsi
000071ff71bdaf1e  pop rdi
000071ff71bdaf1f  pop rdx
000071ff71bdaf20  pop rcx
000071ff71bdaf21  pop rax
000071ff71bdaf22  add rsp, 0x08
000071ff71bdaf26  jmp 0x000071FF71BD905D
000071ff71bdaf2b  sub rsp, 0x08
000071ff71bdaf2f  push rax
000071ff71bdaf30  push rcx
000071ff71bdaf31  push rdx
000071ff71bdaf32  push rdi
000071ff71bdaf33  push rsi
000071ff71bdaf34  push r8
000071ff71bdaf36  push r9
000071ff71bdaf38  push r10
000071ff71bdaf3a  push r11
000071ff71bdaf3c  sub rsp, 0xF0
000071ff71bdaf43  vmovaps [rsp], xmm0
000071ff71bdaf48  vmovaps [rsp+0x10], xmm1
000071ff71bdaf4e  vmovaps [rsp+0x20], xmm2
000071ff71bdaf54  vmovaps [rsp+0x30], xmm3
000071ff71bdaf5a  vmovaps [rsp+0x40], xmm4
000071ff71bdaf60  vmovaps [rsp+0x50], xmm5
000071ff71bdaf66  vmovaps [rsp+0x60], xmm6
000071ff71bdaf6c  vmovaps [rsp+0x70], xmm8
000071ff71bdaf72  vmovaps [rsp+0x80], xmm9
000071ff71bdaf7b  vmovaps [rsp+0x90], xmm10
000071ff71bdaf84  vmovaps [rsp+0xA0], xmm11
000071ff71bdaf8d  vmovaps [rsp+0xB0], xmm12
000071ff71bdaf96  vmovaps [rsp+0xC0], xmm13
000071ff71bdaf9f  vmovaps [rsp+0xD0], xmm14
000071ff71bdafa8  vmovaps [rsp+0xE0], xmm15
000071ff71bdafb1  sub rsp, 0x30
000071ff71bdafb5  movaps [rsp], xmm7
000071ff71bdafb9  movaps [rsp+0x10], xmm5
000071ff71bdafbe  movaps [rsp+0x20], xmm15
000071ff71bdafc4  lea rdi, [rsp]
000071ff71bdafc8  mov esi, 0x00
000071ff71bdafcd  mov rax, 0x5E6872E10530
000071ff71bdafd7  call rax
000071ff71bdafd9  movaps xmm7, [rsp]
000071ff71bdafdd  add rsp, 0x30
000071ff71bdafe1  vmovaps xmm0, [rsp]
000071ff71bdafe6  vmovaps xmm1, [rsp+0x10]
000071ff71bdafec  vmovaps xmm2, [rsp+0x20]
000071ff71bdaff2  vmovaps xmm3, [rsp+0x30]
000071ff71bdaff8  vmovaps xmm4, [rsp+0x40]
000071ff71bdaffe  vmovaps xmm5, [rsp+0x50]
000071ff71bdb004  vmovaps xmm6, [rsp+0x60]
000071ff71bdb00a  vmovaps xmm8, [rsp+0x70]
000071ff71bdb010  vmovaps xmm9, [rsp+0x80]
000071ff71bdb019  vmovaps xmm10, [rsp+0x90]
000071ff71bdb022  vmovaps xmm11, [rsp+0xA0]
000071ff71bdb02b  vmovaps xmm12, [rsp+0xB0]
000071ff71bdb034  vmovaps xmm13, [rsp+0xC0]
000071ff71bdb03d  vmovaps xmm14, [rsp+0xD0]
000071ff71bdb046  vmovaps xmm15, [rsp+0xE0]
000071ff71bdb04f  add rsp, 0xF0
000071ff71bdb056  pop r11
000071ff71bdb058  pop r10
000071ff71bdb05a  pop r9
000071ff71bdb05c  pop r8
000071ff71bdb05e  pop rsi
000071ff71bdb05f  pop rdi
000071ff71bdb060  pop rdx
000071ff71bdb061  pop rcx
000071ff71bdb062  pop rax
000071ff71bdb063  add rsp, 0x08
000071ff71bdb067  jmp 0x000071FF71BD9093
000071ff71bdb06c  call 0x000071FF71AD64F0
000071ff71bdb071  jmp 0x000071FF71BD90A0
000071ff71bdb076  sub rsp, 0x08
000071ff71bdb07a  push rax
000071ff71bdb07b  push rcx
000071ff71bdb07c  push rdx
000071ff71bdb07d  push rdi
000071ff71bdb07e  push rsi
000071ff71bdb07f  push r8
000071ff71bdb081  push r9
000071ff71bdb083  push r10
000071ff71bdb085  push r11
000071ff71bdb087  sub rsp, 0xF0
000071ff71bdb08e  vmovaps [rsp], xmm0
000071ff71bdb093  vmovaps [rsp+0x10], xmm1
000071ff71bdb099  vmovaps [rsp+0x20], xmm2
000071ff71bdb09f  vmovaps [rsp+0x30], xmm3
000071ff71bdb0a5  vmovaps [rsp+0x40], xmm4
000071ff71bdb0ab  vmovaps [rsp+0x50], xmm5
000071ff71bdb0b1  vmovaps [rsp+0x60], xmm6
000071ff71bdb0b7  vmovaps [rsp+0x70], xmm7
000071ff71bdb0bd  vmovaps [rsp+0x80], xmm8
000071ff71bdb0c6  vmovaps [rsp+0x90], xmm9
000071ff71bdb0cf  vmovaps [rsp+0xA0], xmm10
000071ff71bdb0d8  vmovaps [rsp+0xB0], xmm11
000071ff71bdb0e1  vmovaps [rsp+0xC0], xmm12
000071ff71bdb0ea  vmovaps [rsp+0xD0], xmm13
000071ff71bdb0f3  vmovaps [rsp+0xE0], xmm14
000071ff71bdb0fc  sub rsp, 0x30
000071ff71bdb100  movaps [rsp], xmm15
000071ff71bdb105  movaps [rsp+0x10], xmm5
000071ff71bdb10a  movaps [rsp+0x20], xmm3
000071ff71bdb10f  lea rdi, [rsp]
000071ff71bdb113  mov esi, 0x00
000071ff71bdb118  mov rax, 0x5E6872E10530
000071ff71bdb122  call rax
000071ff71bdb124  movaps xmm15, [rsp]
000071ff71bdb129  add rsp, 0x30
000071ff71bdb12d  vmovaps xmm0, [rsp]
000071ff71bdb132  vmovaps xmm1, [rsp+0x10]
000071ff71bdb138  vmovaps xmm2, [rsp+0x20]
000071ff71bdb13e  vmovaps xmm3, [rsp+0x30]
000071ff71bdb144  vmovaps xmm4, [rsp+0x40]
000071ff71bdb14a  vmovaps xmm5, [rsp+0x50]
000071ff71bdb150  vmovaps xmm6, [rsp+0x60]
000071ff71bdb156  vmovaps xmm7, [rsp+0x70]
000071ff71bdb15c  vmovaps xmm8, [rsp+0x80]
000071ff71bdb165  vmovaps xmm9, [rsp+0x90]
000071ff71bdb16e  vmovaps xmm10, [rsp+0xA0]
000071ff71bdb177  vmovaps xmm11, [rsp+0xB0]
000071ff71bdb180  vmovaps xmm12, [rsp+0xC0]
000071ff71bdb189  vmovaps xmm13, [rsp+0xD0]
000071ff71bdb192  vmovaps xmm14, [rsp+0xE0]
000071ff71bdb19b  add rsp, 0xF0
000071ff71bdb1a2  pop r11
000071ff71bdb1a4  pop r10
000071ff71bdb1a6  pop r9
000071ff71bdb1a8  pop r8
000071ff71bdb1aa  pop rsi
000071ff71bdb1ab  pop rdi
000071ff71bdb1ac  pop rdx
000071ff71bdb1ad  pop rcx
000071ff71bdb1ae  pop rax
000071ff71bdb1af  add rsp, 0x08
000071ff71bdb1b3  jmp 0x000071FF71BD90C6
000071ff71bdb1b8  sub rsp, 0x08
000071ff71bdb1bc  push rax
000071ff71bdb1bd  push rcx
000071ff71bdb1be  push rdx
000071ff71bdb1bf  push rdi
000071ff71bdb1c0  push rsi
000071ff71bdb1c1  push r8
000071ff71bdb1c3  push r9
000071ff71bdb1c5  push r10
000071ff71bdb1c7  push r11
000071ff71bdb1c9  sub rsp, 0xF0
000071ff71bdb1d0  vmovaps [rsp], xmm0
000071ff71bdb1d5  vmovaps [rsp+0x10], xmm2
000071ff71bdb1db  vmovaps [rsp+0x20], xmm3
000071ff71bdb1e1  vmovaps [rsp+0x30], xmm4
000071ff71bdb1e7  vmovaps [rsp+0x40], xmm5
000071ff71bdb1ed  vmovaps [rsp+0x50], xmm6
000071ff71bdb1f3  vmovaps [rsp+0x60], xmm7
000071ff71bdb1f9  vmovaps [rsp+0x70], xmm8
000071ff71bdb1ff  vmovaps [rsp+0x80], xmm9
000071ff71bdb208  vmovaps [rsp+0x90], xmm10
000071ff71bdb211  vmovaps [rsp+0xA0], xmm11
000071ff71bdb21a  vmovaps [rsp+0xB0], xmm12
000071ff71bdb223  vmovaps [rsp+0xC0], xmm13
000071ff71bdb22c  vmovaps [rsp+0xD0], xmm14
000071ff71bdb235  vmovaps [rsp+0xE0], xmm15
000071ff71bdb23e  sub rsp, 0x30
000071ff71bdb242  movaps [rsp], xmm1
000071ff71bdb246  movaps [rsp+0x10], xmm5
000071ff71bdb24b  movaps [rsp+0x20], xmm4
000071ff71bdb250  lea rdi, [rsp]
000071ff71bdb254  mov esi, 0x00
000071ff71bdb259  mov rax, 0x5E6872E10530
000071ff71bdb263  call rax
000071ff71bdb265  movaps xmm1, [rsp]
000071ff71bdb269  add rsp, 0x30
000071ff71bdb26d  vmovaps xmm0, [rsp]
000071ff71bdb272  vmovaps xmm2, [rsp+0x10]
000071ff71bdb278  vmovaps xmm3, [rsp+0x20]
000071ff71bdb27e  vmovaps xmm4, [rsp+0x30]
000071ff71bdb284  vmovaps xmm5, [rsp+0x40]
000071ff71bdb28a  vmovaps xmm6, [rsp+0x50]
000071ff71bdb290  vmovaps xmm7, [rsp+0x60]
000071ff71bdb296  vmovaps xmm8, [rsp+0x70]
000071ff71bdb29c  vmovaps xmm9, [rsp+0x80]
000071ff71bdb2a5  vmovaps xmm10, [rsp+0x90]
000071ff71bdb2ae  vmovaps xmm11, [rsp+0xA0]
000071ff71bdb2b7  vmovaps xmm12, [rsp+0xB0]
000071ff71bdb2c0  vmovaps xmm13, [rsp+0xC0]
000071ff71bdb2c9  vmovaps xmm14, [rsp+0xD0]
000071ff71bdb2d2  vmovaps xmm15, [rsp+0xE0]
000071ff71bdb2db  add rsp, 0xF0
000071ff71bdb2e2  pop r11
000071ff71bdb2e4  pop r10
000071ff71bdb2e6  pop r9
000071ff71bdb2e8  pop r8
000071ff71bdb2ea  pop rsi
000071ff71bdb2eb  pop rdi
000071ff71bdb2ec  pop rdx
000071ff71bdb2ed  pop rcx
000071ff71bdb2ee  pop rax
000071ff71bdb2ef  add rsp, 0x08
000071ff71bdb2f3  jmp 0x000071FF71BD90E6
000071ff71bdb2f8  sub rsp, 0x08
000071ff71bdb2fc  push rax
000071ff71bdb2fd  push rcx
000071ff71bdb2fe  push rdx
000071ff71bdb2ff  push rdi
000071ff71bdb300  push rsi
000071ff71bdb301  push r8
000071ff71bdb303  push r9
000071ff71bdb305  push r10
000071ff71bdb307  push r11
000071ff71bdb309  sub rsp, 0xF0
000071ff71bdb310  vmovaps [rsp], xmm0
000071ff71bdb315  vmovaps [rsp+0x10], xmm1
000071ff71bdb31b  vmovaps [rsp+0x20], xmm2
000071ff71bdb321  vmovaps [rsp+0x30], xmm3
000071ff71bdb327  vmovaps [rsp+0x40], xmm5
000071ff71bdb32d  vmovaps [rsp+0x50], xmm6
000071ff71bdb333  vmovaps [rsp+0x60], xmm7
000071ff71bdb339  vmovaps [rsp+0x70], xmm8
000071ff71bdb33f  vmovaps [rsp+0x80], xmm9
000071ff71bdb348  vmovaps [rsp+0x90], xmm10
000071ff71bdb351  vmovaps [rsp+0xA0], xmm11
000071ff71bdb35a  vmovaps [rsp+0xB0], xmm12
000071ff71bdb363  vmovaps [rsp+0xC0], xmm13
000071ff71bdb36c  vmovaps [rsp+0xD0], xmm14
000071ff71bdb375  vmovaps [rsp+0xE0], xmm15
000071ff71bdb37e  sub rsp, 0x30
000071ff71bdb382  movaps [rsp], xmm4
000071ff71bdb386  movaps [rsp+0x10], xmm3
000071ff71bdb38b  movaps [rsp+0x20], xmm5
000071ff71bdb390  lea rdi, [rsp]
000071ff71bdb394  mov esi, 0x00
000071ff71bdb399  mov rax, 0x5E6872E10530
000071ff71bdb3a3  call rax
000071ff71bdb3a5  movaps xmm4, [rsp]
000071ff71bdb3a9  add rsp, 0x30
000071ff71bdb3ad  vmovaps xmm0, [rsp]
000071ff71bdb3b2  vmovaps xmm1, [rsp+0x10]
000071ff71bdb3b8  vmovaps xmm2, [rsp+0x20]
000071ff71bdb3be  vmovaps xmm3, [rsp+0x30]
000071ff71bdb3c4  vmovaps xmm5, [rsp+0x40]
000071ff71bdb3ca  vmovaps xmm6, [rsp+0x50]
000071ff71bdb3d0  vmovaps xmm7, [rsp+0x60]
000071ff71bdb3d6  vmovaps xmm8, [rsp+0x70]
000071ff71bdb3dc  vmovaps xmm9, [rsp+0x80]
000071ff71bdb3e5  vmovaps xmm10, [rsp+0x90]
000071ff71bdb3ee  vmovaps xmm11, [rsp+0xA0]
000071ff71bdb3f7  vmovaps xmm12, [rsp+0xB0]
000071ff71bdb400  vmovaps xmm13, [rsp+0xC0]
000071ff71bdb409  vmovaps xmm14, [rsp+0xD0]
000071ff71bdb412  vmovaps xmm15, [rsp+0xE0]
000071ff71bdb41b  add rsp, 0xF0
000071ff71bdb422  pop r11
000071ff71bdb424  pop r10
000071ff71bdb426  pop r9
000071ff71bdb428  pop r8
000071ff71bdb42a  pop rsi
000071ff71bdb42b  pop rdi
000071ff71bdb42c  pop rdx
000071ff71bdb42d  pop rcx
000071ff71bdb42e  pop rax
000071ff71bdb42f  add rsp, 0x08
000071ff71bdb433  jmp 0x000071FF71BD9134
000071ff71bdb438  call 0x000071FF71AD64F0
000071ff71bdb43d  jmp 0x000071FF71BD9141
000071ff71bdb442  sub rsp, 0x08
000071ff71bdb446  push rax
000071ff71bdb447  push rcx
000071ff71bdb448  push rdx
000071ff71bdb449  push rdi
000071ff71bdb44a  push rsi
000071ff71bdb44b  push r8
000071ff71bdb44d  push r9
000071ff71bdb44f  push r10
000071ff71bdb451  push r11
000071ff71bdb453  sub rsp, 0xF0
000071ff71bdb45a  vmovaps [rsp], xmm0
000071ff71bdb45f  vmovaps [rsp+0x10], xmm1
000071ff71bdb465  vmovaps [rsp+0x20], xmm2
000071ff71bdb46b  vmovaps [rsp+0x30], xmm3
000071ff71bdb471  vmovaps [rsp+0x40], xmm4
000071ff71bdb477  vmovaps [rsp+0x50], xmm6
000071ff71bdb47d  vmovaps [rsp+0x60], xmm7
000071ff71bdb483  vmovaps [rsp+0x70], xmm8
000071ff71bdb489  vmovaps [rsp+0x80], xmm9
000071ff71bdb492  vmovaps [rsp+0x90], xmm10
000071ff71bdb49b  vmovaps [rsp+0xA0], xmm11
000071ff71bdb4a4  vmovaps [rsp+0xB0], xmm12
000071ff71bdb4ad  vmovaps [rsp+0xC0], xmm13
000071ff71bdb4b6  vmovaps [rsp+0xD0], xmm14
000071ff71bdb4bf  vmovaps [rsp+0xE0], xmm15
000071ff71bdb4c8  sub rsp, 0x30
000071ff71bdb4cc  movaps [rsp], xmm5
000071ff71bdb4d0  movaps [rsp+0x10], xmm6
000071ff71bdb4d5  movaps [rsp+0x20], xmm3
000071ff71bdb4da  lea rdi, [rsp]
000071ff71bdb4de  mov esi, 0x00
000071ff71bdb4e3  mov rax, 0x5E6872E10530
000071ff71bdb4ed  call rax
000071ff71bdb4ef  movaps xmm5, [rsp]
000071ff71bdb4f3  add rsp, 0x30
000071ff71bdb4f7  vmovaps xmm0, [rsp]
000071ff71bdb4fc  vmovaps xmm1, [rsp+0x10]
000071ff71bdb502  vmovaps xmm2, [rsp+0x20]
000071ff71bdb508  vmovaps xmm3, [rsp+0x30]
000071ff71bdb50e  vmovaps xmm4, [rsp+0x40]
000071ff71bdb514  vmovaps xmm6, [rsp+0x50]
000071ff71bdb51a  vmovaps xmm7, [rsp+0x60]
000071ff71bdb520  vmovaps xmm8, [rsp+0x70]
000071ff71bdb526  vmovaps xmm9, [rsp+0x80]
000071ff71bdb52f  vmovaps xmm10, [rsp+0x90]
000071ff71bdb538  vmovaps xmm11, [rsp+0xA0]
000071ff71bdb541  vmovaps xmm12, [rsp+0xB0]
000071ff71bdb54a  vmovaps xmm13, [rsp+0xC0]
000071ff71bdb553  vmovaps xmm14, [rsp+0xD0]
000071ff71bdb55c  vmovaps xmm15, [rsp+0xE0]
000071ff71bdb565  add rsp, 0xF0
000071ff71bdb56c  pop r11
000071ff71bdb56e  pop r10
000071ff71bdb570  pop r9
000071ff71bdb572  pop r8
000071ff71bdb574  pop rsi
000071ff71bdb575  pop rdi
000071ff71bdb576  pop rdx
000071ff71bdb577  pop rcx
000071ff71bdb578  pop rax
000071ff71bdb579  add rsp, 0x08
000071ff71bdb57d  jmp 0x000071FF71BD9167
000071ff71bdb582  sub rsp, 0x08
000071ff71bdb586  push rax
000071ff71bdb587  push rcx
000071ff71bdb588  push rdx
000071ff71bdb589  push rdi
000071ff71bdb58a  push rsi
000071ff71bdb58b  push r8
000071ff71bdb58d  push r9
000071ff71bdb58f  push r10
000071ff71bdb591  push r11
000071ff71bdb593  sub rsp, 0xF0
000071ff71bdb59a  vmovaps [rsp], xmm0
000071ff71bdb59f  vmovaps [rsp+0x10], xmm1
000071ff71bdb5a5  vmovaps [rsp+0x20], xmm2
000071ff71bdb5ab  vmovaps [rsp+0x30], xmm3
000071ff71bdb5b1  vmovaps [rsp+0x40], xmm4
000071ff71bdb5b7  vmovaps [rsp+0x50], xmm5
000071ff71bdb5bd  vmovaps [rsp+0x60], xmm7
000071ff71bdb5c3  vmovaps [rsp+0x70], xmm8
000071ff71bdb5c9  vmovaps [rsp+0x80], xmm9
000071ff71bdb5d2  vmovaps [rsp+0x90], xmm10
000071ff71bdb5db  vmovaps [rsp+0xA0], xmm11
000071ff71bdb5e4  vmovaps [rsp+0xB0], xmm12
000071ff71bdb5ed  vmovaps [rsp+0xC0], xmm13
000071ff71bdb5f6  vmovaps [rsp+0xD0], xmm14
000071ff71bdb5ff  vmovaps [rsp+0xE0], xmm15
000071ff71bdb608  sub rsp, 0x30
000071ff71bdb60c  movaps [rsp], xmm6
000071ff71bdb610  movaps [rsp+0x10], xmm9
000071ff71bdb616  movaps [rsp+0x20], xmm1
000071ff71bdb61b  lea rdi, [rsp]
000071ff71bdb61f  mov esi, 0x00
000071ff71bdb624  mov rax, 0x5E6872E10530
000071ff71bdb62e  call rax
000071ff71bdb630  movaps xmm6, [rsp]
000071ff71bdb634  add rsp, 0x30
000071ff71bdb638  vmovaps xmm0, [rsp]
000071ff71bdb63d  vmovaps xmm1, [rsp+0x10]
000071ff71bdb643  vmovaps xmm2, [rsp+0x20]
000071ff71bdb649  vmovaps xmm3, [rsp+0x30]
000071ff71bdb64f  vmovaps xmm4, [rsp+0x40]
000071ff71bdb655  vmovaps xmm5, [rsp+0x50]
000071ff71bdb65b  vmovaps xmm7, [rsp+0x60]
000071ff71bdb661  vmovaps xmm8, [rsp+0x70]
000071ff71bdb667  vmovaps xmm9, [rsp+0x80]
000071ff71bdb670  vmovaps xmm10, [rsp+0x90]
000071ff71bdb679  vmovaps xmm11, [rsp+0xA0]
000071ff71bdb682  vmovaps xmm12, [rsp+0xB0]
000071ff71bdb68b  vmovaps xmm13, [rsp+0xC0]
000071ff71bdb694  vmovaps xmm14, [rsp+0xD0]
000071ff71bdb69d  vmovaps xmm15, [rsp+0xE0]
000071ff71bdb6a6  add rsp, 0xF0
000071ff71bdb6ad  pop r11
000071ff71bdb6af  pop r10
000071ff71bdb6b1  pop r9
000071ff71bdb6b3  pop r8
000071ff71bdb6b5  pop rsi
000071ff71bdb6b6  pop rdi
000071ff71bdb6b7  pop rdx
000071ff71bdb6b8  pop rcx
000071ff71bdb6b9  pop rax
000071ff71bdb6ba  add rsp, 0x08
000071ff71bdb6be  jmp 0x000071FF71BD918B
000071ff71bdb6c3  sub rsp, 0x08
000071ff71bdb6c7  push rax
000071ff71bdb6c8  push rcx
000071ff71bdb6c9  push rdx
000071ff71bdb6ca  push rdi
000071ff71bdb6cb  push rsi
000071ff71bdb6cc  push r8
000071ff71bdb6ce  push r9
000071ff71bdb6d0  push r10
000071ff71bdb6d2  push r11
000071ff71bdb6d4  sub rsp, 0xF0
000071ff71bdb6db  vmovaps [rsp], xmm0
000071ff71bdb6e0  vmovaps [rsp+0x10], xmm1
000071ff71bdb6e6  vmovaps [rsp+0x20], xmm2
000071ff71bdb6ec  vmovaps [rsp+0x30], xmm3
000071ff71bdb6f2  vmovaps [rsp+0x40], xmm4
000071ff71bdb6f8  vmovaps [rsp+0x50], xmm5
000071ff71bdb6fe  vmovaps [rsp+0x60], xmm6
000071ff71bdb704  vmovaps [rsp+0x70], xmm7
000071ff71bdb70a  vmovaps [rsp+0x80], xmm8
000071ff71bdb713  vmovaps [rsp+0x90], xmm10
000071ff71bdb71c  vmovaps [rsp+0xA0], xmm11
000071ff71bdb725  vmovaps [rsp+0xB0], xmm12
000071ff71bdb72e  vmovaps [rsp+0xC0], xmm13
000071ff71bdb737  vmovaps [rsp+0xD0], xmm14
000071ff71bdb740  vmovaps [rsp+0xE0], xmm15
000071ff71bdb749  sub rsp, 0x30
000071ff71bdb74d  movaps [rsp], xmm9
000071ff71bdb752  movaps [rsp+0x10], xmm3
000071ff71bdb757  movaps [rsp+0x20], xmm1
000071ff71bdb75c  lea rdi, [rsp]
000071ff71bdb760  mov esi, 0x00
000071ff71bdb765  mov rax, 0x5E6872E10530
000071ff71bdb76f  call rax
000071ff71bdb771  movaps xmm9, [rsp]
000071ff71bdb776  add rsp, 0x30
000071ff71bdb77a  vmovaps xmm0, [rsp]
000071ff71bdb77f  vmovaps xmm1, [rsp+0x10]
000071ff71bdb785  vmovaps xmm2, [rsp+0x20]
000071ff71bdb78b  vmovaps xmm3, [rsp+0x30]
000071ff71bdb791  vmovaps xmm4, [rsp+0x40]
000071ff71bdb797  vmovaps xmm5, [rsp+0x50]
000071ff71bdb79d  vmovaps xmm6, [rsp+0x60]
000071ff71bdb7a3  vmovaps xmm7, [rsp+0x70]
000071ff71bdb7a9  vmovaps xmm8, [rsp+0x80]
000071ff71bdb7b2  vmovaps xmm10, [rsp+0x90]
000071ff71bdb7bb  vmovaps xmm11, [rsp+0xA0]
000071ff71bdb7c4  vmovaps xmm12, [rsp+0xB0]
000071ff71bdb7cd  vmovaps xmm13, [rsp+0xC0]
000071ff71bdb7d6  vmovaps xmm14, [rsp+0xD0]
000071ff71bdb7df  vmovaps xmm15, [rsp+0xE0]
000071ff71bdb7e8  add rsp, 0xF0
000071ff71bdb7ef  pop r11
000071ff71bdb7f1  pop r10
000071ff71bdb7f3  pop r9
000071ff71bdb7f5  pop r8
000071ff71bdb7f7  pop rsi
000071ff71bdb7f8  pop rdi
000071ff71bdb7f9  pop rdx
000071ff71bdb7fa  pop rcx
000071ff71bdb7fb  pop rax
000071ff71bdb7fc  add rsp, 0x08
000071ff71bdb800  jmp 0x000071FF71BD91D7
000071ff71bdb805  call 0x000071FF71AD64F0
000071ff71bdb80a  jmp 0x000071FF71BD91E4
000071ff71bdb80f  sub rsp, 0x08
000071ff71bdb813  push rax
000071ff71bdb814  push rcx
000071ff71bdb815  push rdx
000071ff71bdb816  push rdi
000071ff71bdb817  push rsi
000071ff71bdb818  push r8
000071ff71bdb81a  push r9
000071ff71bdb81c  push r10
000071ff71bdb81e  push r11
000071ff71bdb820  sub rsp, 0xF0
000071ff71bdb827  vmovaps [rsp], xmm0
000071ff71bdb82c  vmovaps [rsp+0x10], xmm1
000071ff71bdb832  vmovaps [rsp+0x20], xmm2
000071ff71bdb838  vmovaps [rsp+0x30], xmm3
000071ff71bdb83e  vmovaps [rsp+0x40], xmm4
000071ff71bdb844  vmovaps [rsp+0x50], xmm5
000071ff71bdb84a  vmovaps [rsp+0x60], xmm6
000071ff71bdb850  vmovaps [rsp+0x70], xmm7
000071ff71bdb856  vmovaps [rsp+0x80], xmm8
000071ff71bdb85f  vmovaps [rsp+0x90], xmm9
000071ff71bdb868  vmovaps [rsp+0xA0], xmm10
000071ff71bdb871  vmovaps [rsp+0xB0], xmm11
000071ff71bdb87a  vmovaps [rsp+0xC0], xmm12
000071ff71bdb883  vmovaps [rsp+0xD0], xmm13
000071ff71bdb88c  vmovaps [rsp+0xE0], xmm14
000071ff71bdb895  sub rsp, 0x30
000071ff71bdb899  movaps [rsp], xmm15
000071ff71bdb89e  movaps [rsp+0x10], xmm3
000071ff71bdb8a3  movaps [rsp+0x20], xmm7
000071ff71bdb8a8  lea rdi, [rsp]
000071ff71bdb8ac  mov esi, 0x00
000071ff71bdb8b1  mov rax, 0x5E6872E10530
000071ff71bdb8bb  call rax
000071ff71bdb8bd  movaps xmm15, [rsp]
000071ff71bdb8c2  add rsp, 0x30
000071ff71bdb8c6  vmovaps xmm0, [rsp]
000071ff71bdb8cb  vmovaps xmm1, [rsp+0x10]
000071ff71bdb8d1  vmovaps xmm2, [rsp+0x20]
000071ff71bdb8d7  vmovaps xmm3, [rsp+0x30]
000071ff71bdb8dd  vmovaps xmm4, [rsp+0x40]
000071ff71bdb8e3  vmovaps xmm5, [rsp+0x50]
000071ff71bdb8e9  vmovaps xmm6, [rsp+0x60]
000071ff71bdb8ef  vmovaps xmm7, [rsp+0x70]
000071ff71bdb8f5  vmovaps xmm8, [rsp+0x80]
000071ff71bdb8fe  vmovaps xmm9, [rsp+0x90]
000071ff71bdb907  vmovaps xmm10, [rsp+0xA0]
000071ff71bdb910  vmovaps xmm11, [rsp+0xB0]
000071ff71bdb919  vmovaps xmm12, [rsp+0xC0]
000071ff71bdb922  vmovaps xmm13, [rsp+0xD0]
000071ff71bdb92b  vmovaps xmm14, [rsp+0xE0]
000071ff71bdb934  add rsp, 0xF0
000071ff71bdb93b  pop r11
000071ff71bdb93d  pop r10
000071ff71bdb93f  pop r9
000071ff71bdb941  pop r8
000071ff71bdb943  pop rsi
000071ff71bdb944  pop rdi
000071ff71bdb945  pop rdx
000071ff71bdb946  pop rcx
000071ff71bdb947  pop rax
000071ff71bdb948  add rsp, 0x08
000071ff71bdb94c  jmp 0x000071FF71BD9210
000071ff71bdb951  sub rsp, 0x08
000071ff71bdb955  push rax
000071ff71bdb956  push rcx
000071ff71bdb957  push rdx
000071ff71bdb958  push rdi
000071ff71bdb959  push rsi
000071ff71bdb95a  push r8
000071ff71bdb95c  push r9
000071ff71bdb95e  push r10
000071ff71bdb960  push r11
000071ff71bdb962  sub rsp, 0xF0
000071ff71bdb969  vmovaps [rsp], xmm0
000071ff71bdb96e  vmovaps [rsp+0x10], xmm1
000071ff71bdb974  vmovaps [rsp+0x20], xmm2
000071ff71bdb97a  vmovaps [rsp+0x30], xmm4
000071ff71bdb980  vmovaps [rsp+0x40], xmm5
000071ff71bdb986  vmovaps [rsp+0x50], xmm6
000071ff71bdb98c  vmovaps [rsp+0x60], xmm7
000071ff71bdb992  vmovaps [rsp+0x70], xmm8
000071ff71bdb998  vmovaps [rsp+0x80], xmm9
000071ff71bdb9a1  vmovaps [rsp+0x90], xmm10
000071ff71bdb9aa  vmovaps [rsp+0xA0], xmm11
000071ff71bdb9b3  vmovaps [rsp+0xB0], xmm12
000071ff71bdb9bc  vmovaps [rsp+0xC0], xmm13
000071ff71bdb9c5  vmovaps [rsp+0xD0], xmm14
000071ff71bdb9ce  vmovaps [rsp+0xE0], xmm15
000071ff71bdb9d7  sub rsp, 0x30
000071ff71bdb9db  movaps [rsp], xmm3
000071ff71bdb9df  movaps [rsp+0x10], xmm1
000071ff71bdb9e4  movaps [rsp+0x20], xmm15
000071ff71bdb9ea  lea rdi, [rsp]
000071ff71bdb9ee  mov esi, 0x00
000071ff71bdb9f3  mov rax, 0x5E6872E10530
000071ff71bdb9fd  call rax
000071ff71bdb9ff  movaps xmm3, [rsp]
000071ff71bdba03  add rsp, 0x30
000071ff71bdba07  vmovaps xmm0, [rsp]
000071ff71bdba0c  vmovaps xmm1, [rsp+0x10]
000071ff71bdba12  vmovaps xmm2, [rsp+0x20]
000071ff71bdba18  vmovaps xmm4, [rsp+0x30]
000071ff71bdba1e  vmovaps xmm5, [rsp+0x40]
000071ff71bdba24  vmovaps xmm6, [rsp+0x50]
000071ff71bdba2a  vmovaps xmm7, [rsp+0x60]
000071ff71bdba30  vmovaps xmm8, [rsp+0x70]
000071ff71bdba36  vmovaps xmm9, [rsp+0x80]
000071ff71bdba3f  vmovaps xmm10, [rsp+0x90]
000071ff71bdba48  vmovaps xmm11, [rsp+0xA0]
000071ff71bdba51  vmovaps xmm12, [rsp+0xB0]
000071ff71bdba5a  vmovaps xmm13, [rsp+0xC0]
000071ff71bdba63  vmovaps xmm14, [rsp+0xD0]
000071ff71bdba6c  vmovaps xmm15, [rsp+0xE0]
000071ff71bdba75  add rsp, 0xF0
000071ff71bdba7c  pop r11
000071ff71bdba7e  pop r10
000071ff71bdba80  pop r9
000071ff71bdba82  pop r8
000071ff71bdba84  pop rsi
000071ff71bdba85  pop rdi
000071ff71bdba86  pop rdx
000071ff71bdba87  pop rcx
000071ff71bdba88  pop rax
000071ff71bdba89  add rsp, 0x08
000071ff71bdba8d  jmp 0x000071FF71BD929F
000071ff71bdba92  call 0x000071FF71AD64F0
000071ff71bdba97  jmp 0x000071FF71BD92A9
000071ff71bdba9c  sub rsp, 0x08
000071ff71bdbaa0  push rax
000071ff71bdbaa1  push rcx
000071ff71bdbaa2  push rdx
000071ff71bdbaa3  push rdi
000071ff71bdbaa4  push rsi
000071ff71bdbaa5  push r8
000071ff71bdbaa7  push r9
000071ff71bdbaa9  push r10
000071ff71bdbaab  push r11
000071ff71bdbaad  sub rsp, 0xF0
000071ff71bdbab4  vmovaps [rsp], xmm0
000071ff71bdbab9  vmovaps [rsp+0x10], xmm1
000071ff71bdbabf  vmovaps [rsp+0x20], xmm2
000071ff71bdbac5  vmovaps [rsp+0x30], xmm3
000071ff71bdbacb  vmovaps [rsp+0x40], xmm4
000071ff71bdbad1  vmovaps [rsp+0x50], xmm5
000071ff71bdbad7  vmovaps [rsp+0x60], xmm6
000071ff71bdbadd  vmovaps [rsp+0x70], xmm7
000071ff71bdbae3  vmovaps [rsp+0x80], xmm8
000071ff71bdbaec  vmovaps [rsp+0x90], xmm9
000071ff71bdbaf5  vmovaps [rsp+0xA0], xmm10
000071ff71bdbafe  vmovaps [rsp+0xB0], xmm11
000071ff71bdbb07  vmovaps [rsp+0xC0], xmm12
000071ff71bdbb10  vmovaps [rsp+0xD0], xmm13
000071ff71bdbb19  vmovaps [rsp+0xE0], xmm14
000071ff71bdbb22  sub rsp, 0x30
000071ff71bdbb26  movaps [rsp], xmm15
000071ff71bdbb2b  movaps [rsp+0x10], xmm14
000071ff71bdbb31  movaps [rsp+0x20], xmm4
000071ff71bdbb36  lea rdi, [rsp]
000071ff71bdbb3a  mov esi, 0x00
000071ff71bdbb3f  mov rax, 0x5E6872E10530
000071ff71bdbb49  call rax
000071ff71bdbb4b  movaps xmm15, [rsp]
000071ff71bdbb50  add rsp, 0x30
000071ff71bdbb54  vmovaps xmm0, [rsp]
000071ff71bdbb59  vmovaps xmm1, [rsp+0x10]
000071ff71bdbb5f  vmovaps xmm2, [rsp+0x20]
000071ff71bdbb65  vmovaps xmm3, [rsp+0x30]
000071ff71bdbb6b  vmovaps xmm4, [rsp+0x40]
000071ff71bdbb71  vmovaps xmm5, [rsp+0x50]
000071ff71bdbb77  vmovaps xmm6, [rsp+0x60]
000071ff71bdbb7d  vmovaps xmm7, [rsp+0x70]
000071ff71bdbb83  vmovaps xmm8, [rsp+0x80]
000071ff71bdbb8c  vmovaps xmm9, [rsp+0x90]
000071ff71bdbb95  vmovaps xmm10, [rsp+0xA0]
000071ff71bdbb9e  vmovaps xmm11, [rsp+0xB0]
000071ff71bdbba7  vmovaps xmm12, [rsp+0xC0]
000071ff71bdbbb0  vmovaps xmm13, [rsp+0xD0]
000071ff71bdbbb9  vmovaps xmm14, [rsp+0xE0]
000071ff71bdbbc2  add rsp, 0xF0
000071ff71bdbbc9  pop r11
000071ff71bdbbcb  pop r10
000071ff71bdbbcd  pop r9
000071ff71bdbbcf  pop r8
000071ff71bdbbd1  pop rsi
000071ff71bdbbd2  pop rdi
000071ff71bdbbd3  pop rdx
000071ff71bdbbd4  pop rcx
000071ff71bdbbd5  pop rax
000071ff71bdbbd6  add rsp, 0x08
000071ff71bdbbda  jmp 0x000071FF71BD92D7
000071ff71bdbbdf  sub rsp, 0x08
000071ff71bdbbe3  push rax
000071ff71bdbbe4  push rcx
000071ff71bdbbe5  push rdx
000071ff71bdbbe6  push rdi
000071ff71bdbbe7  push rsi
000071ff71bdbbe8  push r8
000071ff71bdbbea  push r9
000071ff71bdbbec  push r10
000071ff71bdbbee  push r11
000071ff71bdbbf0  sub rsp, 0xF0
000071ff71bdbbf7  vmovaps [rsp], xmm0
000071ff71bdbbfc  vmovaps [rsp+0x10], xmm1
000071ff71bdbc02  vmovaps [rsp+0x20], xmm2
000071ff71bdbc08  vmovaps [rsp+0x30], xmm3
000071ff71bdbc0e  vmovaps [rsp+0x40], xmm4
000071ff71bdbc14  vmovaps [rsp+0x50], xmm5
000071ff71bdbc1a  vmovaps [rsp+0x60], xmm6
000071ff71bdbc20  vmovaps [rsp+0x70], xmm7
000071ff71bdbc26  vmovaps [rsp+0x80], xmm8
000071ff71bdbc2f  vmovaps [rsp+0x90], xmm9
000071ff71bdbc38  vmovaps [rsp+0xA0], xmm10
000071ff71bdbc41  vmovaps [rsp+0xB0], xmm11
000071ff71bdbc4a  vmovaps [rsp+0xC0], xmm12
000071ff71bdbc53  vmovaps [rsp+0xD0], xmm13
000071ff71bdbc5c  vmovaps [rsp+0xE0], xmm15
000071ff71bdbc65  sub rsp, 0x30
000071ff71bdbc69  movaps [rsp], xmm14
000071ff71bdbc6e  movaps [rsp+0x10], xmm2
000071ff71bdbc73  movaps [rsp+0x20], xmm1
000071ff71bdbc78  lea rdi, [rsp]
000071ff71bdbc7c  mov esi, 0x00
000071ff71bdbc81  mov rax, 0x5E6872E10530
000071ff71bdbc8b  call rax
000071ff71bdbc8d  movaps xmm14, [rsp]
000071ff71bdbc92  add rsp, 0x30
000071ff71bdbc96  vmovaps xmm0, [rsp]
000071ff71bdbc9b  vmovaps xmm1, [rsp+0x10]
000071ff71bdbca1  vmovaps xmm2, [rsp+0x20]
000071ff71bdbca7  vmovaps xmm3, [rsp+0x30]
000071ff71bdbcad  vmovaps xmm4, [rsp+0x40]
000071ff71bdbcb3  vmovaps xmm5, [rsp+0x50]
000071ff71bdbcb9  vmovaps xmm6, [rsp+0x60]
000071ff71bdbcbf  vmovaps xmm7, [rsp+0x70]
000071ff71bdbcc5  vmovaps xmm8, [rsp+0x80]
000071ff71bdbcce  vmovaps xmm9, [rsp+0x90]
000071ff71bdbcd7  vmovaps xmm10, [rsp+0xA0]
000071ff71bdbce0  vmovaps xmm11, [rsp+0xB0]
000071ff71bdbce9  vmovaps xmm12, [rsp+0xC0]
000071ff71bdbcf2  vmovaps xmm13, [rsp+0xD0]
000071ff71bdbcfb  vmovaps xmm15, [rsp+0xE0]
000071ff71bdbd04  add rsp, 0xF0
000071ff71bdbd0b  pop r11
000071ff71bdbd0d  pop r10
000071ff71bdbd0f  pop r9
000071ff71bdbd11  pop r8
000071ff71bdbd13  pop rsi
000071ff71bdbd14  pop rdi
000071ff71bdbd15  pop rdx
000071ff71bdbd16  pop rcx
000071ff71bdbd17  pop rax
000071ff71bdbd18  add rsp, 0x08
000071ff71bdbd1c  jmp 0x000071FF71BD92FD
000071ff71bdbd21  sub rsp, 0x08
000071ff71bdbd25  push rax
000071ff71bdbd26  push rcx
000071ff71bdbd27  push rdx
000071ff71bdbd28  push rdi
000071ff71bdbd29  push rsi
000071ff71bdbd2a  push r8
000071ff71bdbd2c  push r9
000071ff71bdbd2e  push r10
000071ff71bdbd30  push r11
000071ff71bdbd32  sub rsp, 0xF0
000071ff71bdbd39  vmovaps [rsp], xmm0
000071ff71bdbd3e  vmovaps [rsp+0x10], xmm2
000071ff71bdbd44  vmovaps [rsp+0x20], xmm3
000071ff71bdbd4a  vmovaps [rsp+0x30], xmm4
000071ff71bdbd50  vmovaps [rsp+0x40], xmm5
000071ff71bdbd56  vmovaps [rsp+0x50], xmm6
000071ff71bdbd5c  vmovaps [rsp+0x60], xmm7
000071ff71bdbd62  vmovaps [rsp+0x70], xmm8
000071ff71bdbd68  vmovaps [rsp+0x80], xmm9
000071ff71bdbd71  vmovaps [rsp+0x90], xmm10
000071ff71bdbd7a  vmovaps [rsp+0xA0], xmm11
000071ff71bdbd83  vmovaps [rsp+0xB0], xmm12
000071ff71bdbd8c  vmovaps [rsp+0xC0], xmm13
000071ff71bdbd95  vmovaps [rsp+0xD0], xmm14
000071ff71bdbd9e  vmovaps [rsp+0xE0], xmm15
000071ff71bdbda7  sub rsp, 0x30
000071ff71bdbdab  movaps [rsp], xmm1
000071ff71bdbdaf  movaps [rsp+0x10], xmm4
000071ff71bdbdb4  movaps [rsp+0x20], xmm9
000071ff71bdbdba  lea rdi, [rsp]
000071ff71bdbdbe  mov esi, 0x00
000071ff71bdbdc3  mov rax, 0x5E6872E10530
000071ff71bdbdcd  call rax
000071ff71bdbdcf  movaps xmm1, [rsp]
000071ff71bdbdd3  add rsp, 0x30
000071ff71bdbdd7  vmovaps xmm0, [rsp]
000071ff71bdbddc  vmovaps xmm2, [rsp+0x10]
000071ff71bdbde2  vmovaps xmm3, [rsp+0x20]
000071ff71bdbde8  vmovaps xmm4, [rsp+0x30]
000071ff71bdbdee  vmovaps xmm5, [rsp+0x40]
000071ff71bdbdf4  vmovaps xmm6, [rsp+0x50]
000071ff71bdbdfa  vmovaps xmm7, [rsp+0x60]
000071ff71bdbe00  vmovaps xmm8, [rsp+0x70]
000071ff71bdbe06  vmovaps xmm9, [rsp+0x80]
000071ff71bdbe0f  vmovaps xmm10, [rsp+0x90]
000071ff71bdbe18  vmovaps xmm11, [rsp+0xA0]
000071ff71bdbe21  vmovaps xmm12, [rsp+0xB0]
000071ff71bdbe2a  vmovaps xmm13, [rsp+0xC0]
000071ff71bdbe33  vmovaps xmm14, [rsp+0xD0]
000071ff71bdbe3c  vmovaps xmm15, [rsp+0xE0]
000071ff71bdbe45  add rsp, 0xF0
000071ff71bdbe4c  pop r11
000071ff71bdbe4e  pop r10
000071ff71bdbe50  pop r9
000071ff71bdbe52  pop r8
000071ff71bdbe54  pop rsi
000071ff71bdbe55  pop rdi
000071ff71bdbe56  pop rdx
000071ff71bdbe57  pop rcx
000071ff71bdbe58  pop rax
000071ff71bdbe59  add rsp, 0x08
000071ff71bdbe5d  jmp 0x000071FF71BD931B
000071ff71bdbe62  sub rsp, 0x08
000071ff71bdbe66  push rax
000071ff71bdbe67  push rcx
000071ff71bdbe68  push rdx
000071ff71bdbe69  push rdi
000071ff71bdbe6a  push rsi
000071ff71bdbe6b  push r8
000071ff71bdbe6d  push r9
000071ff71bdbe6f  push r10
000071ff71bdbe71  push r11
000071ff71bdbe73  sub rsp, 0xF0
000071ff71bdbe7a  vmovaps [rsp], xmm0
000071ff71bdbe7f  vmovaps [rsp+0x10], xmm1
000071ff71bdbe85  vmovaps [rsp+0x20], xmm2
000071ff71bdbe8b  vmovaps [rsp+0x30], xmm3
000071ff71bdbe91  vmovaps [rsp+0x40], xmm5
000071ff71bdbe97  vmovaps [rsp+0x50], xmm6
000071ff71bdbe9d  vmovaps [rsp+0x60], xmm7
000071ff71bdbea3  vmovaps [rsp+0x70], xmm8
000071ff71bdbea9  vmovaps [rsp+0x80], xmm9
000071ff71bdbeb2  vmovaps [rsp+0x90], xmm10
000071ff71bdbebb  vmovaps [rsp+0xA0], xmm11
000071ff71bdbec4  vmovaps [rsp+0xB0], xmm12
000071ff71bdbecd  vmovaps [rsp+0xC0], xmm13
000071ff71bdbed6  vmovaps [rsp+0xD0], xmm14
000071ff71bdbedf  vmovaps [rsp+0xE0], xmm15
000071ff71bdbee8  sub rsp, 0x30
000071ff71bdbeec  movaps [rsp], xmm4
000071ff71bdbef0  movaps [rsp+0x10], xmm2
000071ff71bdbef5  movaps [rsp+0x20], xmm9
000071ff71bdbefb  lea rdi, [rsp]
000071ff71bdbeff  mov esi, 0x00
000071ff71bdbf04  mov rax, 0x5E6872E10530
000071ff71bdbf0e  call rax
000071ff71bdbf10  movaps xmm4, [rsp]
000071ff71bdbf14  add rsp, 0x30
000071ff71bdbf18  vmovaps xmm0, [rsp]
000071ff71bdbf1d  vmovaps xmm1, [rsp+0x10]
000071ff71bdbf23  vmovaps xmm2, [rsp+0x20]
000071ff71bdbf29  vmovaps xmm3, [rsp+0x30]
000071ff71bdbf2f  vmovaps xmm5, [rsp+0x40]
000071ff71bdbf35  vmovaps xmm6, [rsp+0x50]
000071ff71bdbf3b  vmovaps xmm7, [rsp+0x60]
000071ff71bdbf41  vmovaps xmm8, [rsp+0x70]
000071ff71bdbf47  vmovaps xmm9, [rsp+0x80]
000071ff71bdbf50  vmovaps xmm10, [rsp+0x90]
000071ff71bdbf59  vmovaps xmm11, [rsp+0xA0]
000071ff71bdbf62  vmovaps xmm12, [rsp+0xB0]
000071ff71bdbf6b  vmovaps xmm13, [rsp+0xC0]
000071ff71bdbf74  vmovaps xmm14, [rsp+0xD0]
000071ff71bdbf7d  vmovaps xmm15, [rsp+0xE0]
000071ff71bdbf86  add rsp, 0xF0
000071ff71bdbf8d  pop r11
000071ff71bdbf8f  pop r10
000071ff71bdbf91  pop r9
000071ff71bdbf93  pop r8
000071ff71bdbf95  pop rsi
000071ff71bdbf96  pop rdi
000071ff71bdbf97  pop rdx
000071ff71bdbf98  pop rcx
000071ff71bdbf99  pop rax
000071ff71bdbf9a  add rsp, 0x08
000071ff71bdbf9e  jmp 0x000071FF71BD934B
000071ff71bdbfa3  sub rsp, 0x08
000071ff71bdbfa7  push rax
000071ff71bdbfa8  push rcx
000071ff71bdbfa9  push rdx
000071ff71bdbfaa  push rdi
000071ff71bdbfab  push rsi
000071ff71bdbfac  push r8
000071ff71bdbfae  push r9
000071ff71bdbfb0  push r10
000071ff71bdbfb2  push r11
000071ff71bdbfb4  sub rsp, 0xF0
000071ff71bdbfbb  vmovaps [rsp], xmm0
000071ff71bdbfc0  vmovaps [rsp+0x10], xmm1
000071ff71bdbfc6  vmovaps [rsp+0x20], xmm2
000071ff71bdbfcc  vmovaps [rsp+0x30], xmm3
000071ff71bdbfd2  vmovaps [rsp+0x40], xmm4
000071ff71bdbfd8  vmovaps [rsp+0x50], xmm5
000071ff71bdbfde  vmovaps [rsp+0x60], xmm6
000071ff71bdbfe4  vmovaps [rsp+0x70], xmm7
000071ff71bdbfea  vmovaps [rsp+0x80], xmm8
000071ff71bdbff3  vmovaps [rsp+0x90], xmm10
000071ff71bdbffc  vmovaps [rsp+0xA0], xmm11
000071ff71bdc005  vmovaps [rsp+0xB0], xmm12
000071ff71bdc00e  vmovaps [rsp+0xC0], xmm13
000071ff71bdc017  vmovaps [rsp+0xD0], xmm14
000071ff71bdc020  vmovaps [rsp+0xE0], xmm15
000071ff71bdc029  sub rsp, 0x30
000071ff71bdc02d  movaps [rsp], xmm9
000071ff71bdc032  movaps [rsp+0x10], xmm2
000071ff71bdc037  movaps [rsp+0x20], xmm1
000071ff71bdc03c  lea rdi, [rsp]
000071ff71bdc040  mov esi, 0x00
000071ff71bdc045  mov rax, 0x5E6872E10530
000071ff71bdc04f  call rax
000071ff71bdc051  movaps xmm9, [rsp]
000071ff71bdc056  add rsp, 0x30
000071ff71bdc05a  vmovaps xmm0, [rsp]
000071ff71bdc05f  vmovaps xmm1, [rsp+0x10]
000071ff71bdc065  vmovaps xmm2, [rsp+0x20]
000071ff71bdc06b  vmovaps xmm3, [rsp+0x30]
000071ff71bdc071  vmovaps xmm4, [rsp+0x40]
000071ff71bdc077  vmovaps xmm5, [rsp+0x50]
000071ff71bdc07d  vmovaps xmm6, [rsp+0x60]
000071ff71bdc083  vmovaps xmm7, [rsp+0x70]
000071ff71bdc089  vmovaps xmm8, [rsp+0x80]
000071ff71bdc092  vmovaps xmm10, [rsp+0x90]
000071ff71bdc09b  vmovaps xmm11, [rsp+0xA0]
000071ff71bdc0a4  vmovaps xmm12, [rsp+0xB0]
000071ff71bdc0ad  vmovaps xmm13, [rsp+0xC0]
000071ff71bdc0b6  vmovaps xmm14, [rsp+0xD0]
000071ff71bdc0bf  vmovaps xmm15, [rsp+0xE0]
000071ff71bdc0c8  add rsp, 0xF0
000071ff71bdc0cf  pop r11
000071ff71bdc0d1  pop r10
000071ff71bdc0d3  pop r9
000071ff71bdc0d5  pop r8
000071ff71bdc0d7  pop rsi
000071ff71bdc0d8  pop rdi
000071ff71bdc0d9  pop rdx
000071ff71bdc0da  pop rcx
000071ff71bdc0db  pop rax
000071ff71bdc0dc  add rsp, 0x08
000071ff71bdc0e0  jmp 0x000071FF71BD9381
000071ff71bdc0e5  sub rsp, 0x08
000071ff71bdc0e9  push rax
000071ff71bdc0ea  push rcx
000071ff71bdc0eb  push rdx
000071ff71bdc0ec  push rdi
000071ff71bdc0ed  push rsi
000071ff71bdc0ee  push r8
000071ff71bdc0f0  push r9
000071ff71bdc0f2  push r10
000071ff71bdc0f4  push r11
000071ff71bdc0f6  sub rsp, 0xF0
000071ff71bdc0fd  vmovaps [rsp], xmm0
000071ff71bdc102  vmovaps [rsp+0x10], xmm2
000071ff71bdc108  vmovaps [rsp+0x20], xmm3
000071ff71bdc10e  vmovaps [rsp+0x30], xmm4
000071ff71bdc114  vmovaps [rsp+0x40], xmm5
000071ff71bdc11a  vmovaps [rsp+0x50], xmm6
000071ff71bdc120  vmovaps [rsp+0x60], xmm7
000071ff71bdc126  vmovaps [rsp+0x70], xmm8
000071ff71bdc12c  vmovaps [rsp+0x80], xmm9
000071ff71bdc135  vmovaps [rsp+0x90], xmm10
000071ff71bdc13e  vmovaps [rsp+0xA0], xmm11
000071ff71bdc147  vmovaps [rsp+0xB0], xmm12
000071ff71bdc150  vmovaps [rsp+0xC0], xmm13
000071ff71bdc159  vmovaps [rsp+0xD0], xmm14
000071ff71bdc162  vmovaps [rsp+0xE0], xmm15
000071ff71bdc16b  sub rsp, 0x30
000071ff71bdc16f  movaps [rsp], xmm1
000071ff71bdc173  movaps [rsp+0x10], xmm15
000071ff71bdc179  movaps [rsp+0x20], xmm6
000071ff71bdc17e  lea rdi, [rsp]
000071ff71bdc182  mov esi, 0x00
000071ff71bdc187  mov rax, 0x5E6872E10530
000071ff71bdc191  call rax
000071ff71bdc193  movaps xmm1, [rsp]
000071ff71bdc197  add rsp, 0x30
000071ff71bdc19b  vmovaps xmm0, [rsp]
000071ff71bdc1a0  vmovaps xmm2, [rsp+0x10]
000071ff71bdc1a6  vmovaps xmm3, [rsp+0x20]
000071ff71bdc1ac  vmovaps xmm4, [rsp+0x30]
000071ff71bdc1b2  vmovaps xmm5, [rsp+0x40]
000071ff71bdc1b8  vmovaps xmm6, [rsp+0x50]
000071ff71bdc1be  vmovaps xmm7, [rsp+0x60]
000071ff71bdc1c4  vmovaps xmm8, [rsp+0x70]
000071ff71bdc1ca  vmovaps xmm9, [rsp+0x80]
000071ff71bdc1d3  vmovaps xmm10, [rsp+0x90]
000071ff71bdc1dc  vmovaps xmm11, [rsp+0xA0]
000071ff71bdc1e5  vmovaps xmm12, [rsp+0xB0]
000071ff71bdc1ee  vmovaps xmm13, [rsp+0xC0]
000071ff71bdc1f7  vmovaps xmm14, [rsp+0xD0]
000071ff71bdc200  vmovaps xmm15, [rsp+0xE0]
000071ff71bdc209  add rsp, 0xF0
000071ff71bdc210  pop r11
000071ff71bdc212  pop r10
000071ff71bdc214  pop r9
000071ff71bdc216  pop r8
000071ff71bdc218  pop rsi
000071ff71bdc219  pop rdi
000071ff71bdc21a  pop rdx
000071ff71bdc21b  pop rcx
000071ff71bdc21c  pop rax
000071ff71bdc21d  add rsp, 0x08
000071ff71bdc221  jmp 0x000071FF71BD93A2
000071ff71bdc226  sub rsp, 0x08
000071ff71bdc22a  push rax
000071ff71bdc22b  push rcx
000071ff71bdc22c  push rdx
000071ff71bdc22d  push rdi
000071ff71bdc22e  push rsi
000071ff71bdc22f  push r8
000071ff71bdc231  push r9
000071ff71bdc233  push r10
000071ff71bdc235  push r11
000071ff71bdc237  sub rsp, 0xF0
000071ff71bdc23e  vmovaps [rsp], xmm0
000071ff71bdc243  vmovaps [rsp+0x10], xmm1
000071ff71bdc249  vmovaps [rsp+0x20], xmm2
000071ff71bdc24f  vmovaps [rsp+0x30], xmm3
000071ff71bdc255  vmovaps [rsp+0x40], xmm4
000071ff71bdc25b  vmovaps [rsp+0x50], xmm5
000071ff71bdc261  vmovaps [rsp+0x60], xmm6
000071ff71bdc267  vmovaps [rsp+0x70], xmm7
000071ff71bdc26d  vmovaps [rsp+0x80], xmm8
000071ff71bdc276  vmovaps [rsp+0x90], xmm9
000071ff71bdc27f  vmovaps [rsp+0xA0], xmm10
000071ff71bdc288  vmovaps [rsp+0xB0], xmm11
000071ff71bdc291  vmovaps [rsp+0xC0], xmm12
000071ff71bdc29a  vmovaps [rsp+0xD0], xmm13
000071ff71bdc2a3  vmovaps [rsp+0xE0], xmm14
000071ff71bdc2ac  sub rsp, 0x30
000071ff71bdc2b0  movaps [rsp], xmm15
000071ff71bdc2b5  movaps [rsp+0x10], xmm5
000071ff71bdc2ba  movaps [rsp+0x20], xmm3
000071ff71bdc2bf  lea rdi, [rsp]
000071ff71bdc2c3  mov esi, 0x00
000071ff71bdc2c8  mov rax, 0x5E6872E10530
000071ff71bdc2d2  call rax
000071ff71bdc2d4  movaps xmm15, [rsp]
000071ff71bdc2d9  add rsp, 0x30
000071ff71bdc2dd  vmovaps xmm0, [rsp]
000071ff71bdc2e2  vmovaps xmm1, [rsp+0x10]
000071ff71bdc2e8  vmovaps xmm2, [rsp+0x20]
000071ff71bdc2ee  vmovaps xmm3, [rsp+0x30]
000071ff71bdc2f4  vmovaps xmm4, [rsp+0x40]
000071ff71bdc2fa  vmovaps xmm5, [rsp+0x50]
000071ff71bdc300  vmovaps xmm6, [rsp+0x60]
000071ff71bdc306  vmovaps xmm7, [rsp+0x70]
000071ff71bdc30c  vmovaps xmm8, [rsp+0x80]
000071ff71bdc315  vmovaps xmm9, [rsp+0x90]
000071ff71bdc31e  vmovaps xmm10, [rsp+0xA0]
000071ff71bdc327  vmovaps xmm11, [rsp+0xB0]
000071ff71bdc330  vmovaps xmm12, [rsp+0xC0]
000071ff71bdc339  vmovaps xmm13, [rsp+0xD0]
000071ff71bdc342  vmovaps xmm14, [rsp+0xE0]
000071ff71bdc34b  add rsp, 0xF0
000071ff71bdc352  pop r11
000071ff71bdc354  pop r10
000071ff71bdc356  pop r9
000071ff71bdc358  pop r8
000071ff71bdc35a  pop rsi
000071ff71bdc35b  pop rdi
000071ff71bdc35c  pop rdx
000071ff71bdc35d  pop rcx
000071ff71bdc35e  pop rax
000071ff71bdc35f  add rsp, 0x08
000071ff71bdc363  jmp 0x000071FF71BD93BC
000071ff71bdc368  sub rsp, 0x08
000071ff71bdc36c  push rax
000071ff71bdc36d  push rcx
000071ff71bdc36e  push rdx
000071ff71bdc36f  push rdi
000071ff71bdc370  push rsi
000071ff71bdc371  push r8
000071ff71bdc373  push r9
000071ff71bdc375  push r10
000071ff71bdc377  push r11
000071ff71bdc379  sub rsp, 0xF0
000071ff71bdc380  vmovaps [rsp], xmm0
000071ff71bdc385  vmovaps [rsp+0x10], xmm1
000071ff71bdc38b  vmovaps [rsp+0x20], xmm2
000071ff71bdc391  vmovaps [rsp+0x30], xmm3
000071ff71bdc397  vmovaps [rsp+0x40], xmm4
000071ff71bdc39d  vmovaps [rsp+0x50], xmm6
000071ff71bdc3a3  vmovaps [rsp+0x60], xmm7
000071ff71bdc3a9  vmovaps [rsp+0x70], xmm8
000071ff71bdc3af  vmovaps [rsp+0x80], xmm9
000071ff71bdc3b8  vmovaps [rsp+0x90], xmm10
000071ff71bdc3c1  vmovaps [rsp+0xA0], xmm11
000071ff71bdc3ca  vmovaps [rsp+0xB0], xmm12
000071ff71bdc3d3  vmovaps [rsp+0xC0], xmm13
000071ff71bdc3dc  vmovaps [rsp+0xD0], xmm14
000071ff71bdc3e5  vmovaps [rsp+0xE0], xmm15
000071ff71bdc3ee  sub rsp, 0x30
000071ff71bdc3f2  movaps [rsp], xmm5
000071ff71bdc3f6  movaps [rsp+0x10], xmm8
000071ff71bdc3fc  movaps [rsp+0x20], xmm6
000071ff71bdc401  lea rdi, [rsp]
000071ff71bdc405  mov esi, 0x00
000071ff71bdc40a  mov rax, 0x5E6872E10530
000071ff71bdc414  call rax
000071ff71bdc416  movaps xmm5, [rsp]
000071ff71bdc41a  add rsp, 0x30
000071ff71bdc41e  vmovaps xmm0, [rsp]
000071ff71bdc423  vmovaps xmm1, [rsp+0x10]
000071ff71bdc429  vmovaps xmm2, [rsp+0x20]
000071ff71bdc42f  vmovaps xmm3, [rsp+0x30]
000071ff71bdc435  vmovaps xmm4, [rsp+0x40]
000071ff71bdc43b  vmovaps xmm6, [rsp+0x50]
000071ff71bdc441  vmovaps xmm7, [rsp+0x60]
000071ff71bdc447  vmovaps xmm8, [rsp+0x70]
000071ff71bdc44d  vmovaps xmm9, [rsp+0x80]
000071ff71bdc456  vmovaps xmm10, [rsp+0x90]
000071ff71bdc45f  vmovaps xmm11, [rsp+0xA0]
000071ff71bdc468  vmovaps xmm12, [rsp+0xB0]
000071ff71bdc471  vmovaps xmm13, [rsp+0xC0]
000071ff71bdc47a  vmovaps xmm14, [rsp+0xD0]
000071ff71bdc483  vmovaps xmm15, [rsp+0xE0]
000071ff71bdc48c  add rsp, 0xF0
000071ff71bdc493  pop r11
000071ff71bdc495  pop r10
000071ff71bdc497  pop r9
000071ff71bdc499  pop r8
000071ff71bdc49b  pop rsi
000071ff71bdc49c  pop rdi
000071ff71bdc49d  pop rdx
000071ff71bdc49e  pop rcx
000071ff71bdc49f  pop rax
000071ff71bdc4a0  add rsp, 0x08
000071ff71bdc4a4  jmp 0x000071FF71BD93E0
000071ff71bdc4a9  sub rsp, 0x08
000071ff71bdc4ad  push rax
000071ff71bdc4ae  push rcx
000071ff71bdc4af  push rdx
000071ff71bdc4b0  push rdi
000071ff71bdc4b1  push rsi
000071ff71bdc4b2  push r8
000071ff71bdc4b4  push r9
000071ff71bdc4b6  push r10
000071ff71bdc4b8  push r11
000071ff71bdc4ba  sub rsp, 0xF0
000071ff71bdc4c1  vmovaps [rsp], xmm0
000071ff71bdc4c6  vmovaps [rsp+0x10], xmm1
000071ff71bdc4cc  vmovaps [rsp+0x20], xmm2
000071ff71bdc4d2  vmovaps [rsp+0x30], xmm3
000071ff71bdc4d8  vmovaps [rsp+0x40], xmm4
000071ff71bdc4de  vmovaps [rsp+0x50], xmm5
000071ff71bdc4e4  vmovaps [rsp+0x60], xmm7
000071ff71bdc4ea  vmovaps [rsp+0x70], xmm8
000071ff71bdc4f0  vmovaps [rsp+0x80], xmm9
000071ff71bdc4f9  vmovaps [rsp+0x90], xmm10
000071ff71bdc502  vmovaps [rsp+0xA0], xmm11
000071ff71bdc50b  vmovaps [rsp+0xB0], xmm12
000071ff71bdc514  vmovaps [rsp+0xC0], xmm13
000071ff71bdc51d  vmovaps [rsp+0xD0], xmm14
000071ff71bdc526  vmovaps [rsp+0xE0], xmm15
000071ff71bdc52f  sub rsp, 0x30
000071ff71bdc533  movaps [rsp], xmm6
000071ff71bdc537  movaps [rsp+0x10], xmm10
000071ff71bdc53d  movaps [rsp+0x20], xmm8
000071ff71bdc543  lea rdi, [rsp]
000071ff71bdc547  mov esi, 0x00
000071ff71bdc54c  mov rax, 0x5E6872E10530
000071ff71bdc556  call rax
000071ff71bdc558  movaps xmm6, [rsp]
000071ff71bdc55c  add rsp, 0x30
000071ff71bdc560  vmovaps xmm0, [rsp]
000071ff71bdc565  vmovaps xmm1, [rsp+0x10]
000071ff71bdc56b  vmovaps xmm2, [rsp+0x20]
000071ff71bdc571  vmovaps xmm3, [rsp+0x30]
000071ff71bdc577  vmovaps xmm4, [rsp+0x40]
000071ff71bdc57d  vmovaps xmm5, [rsp+0x50]
000071ff71bdc583  vmovaps xmm7, [rsp+0x60]
000071ff71bdc589  vmovaps xmm8, [rsp+0x70]
000071ff71bdc58f  vmovaps xmm9, [rsp+0x80]
000071ff71bdc598  vmovaps xmm10, [rsp+0x90]
000071ff71bdc5a1  vmovaps xmm11, [rsp+0xA0]
000071ff71bdc5aa  vmovaps xmm12, [rsp+0xB0]
000071ff71bdc5b3  vmovaps xmm13, [rsp+0xC0]
000071ff71bdc5bc  vmovaps xmm14, [rsp+0xD0]
000071ff71bdc5c5  vmovaps xmm15, [rsp+0xE0]
000071ff71bdc5ce  add rsp, 0xF0
000071ff71bdc5d5  pop r11
000071ff71bdc5d7  pop r10
000071ff71bdc5d9  pop r9
000071ff71bdc5db  pop r8
000071ff71bdc5dd  pop rsi
000071ff71bdc5de  pop rdi
000071ff71bdc5df  pop rdx
000071ff71bdc5e0  pop rcx
000071ff71bdc5e1  pop rax
000071ff71bdc5e2  add rsp, 0x08
000071ff71bdc5e6  jmp 0x000071FF71BD9405
000071ff71bdc5eb  sub rsp, 0x08
000071ff71bdc5ef  push rax
000071ff71bdc5f0  push rcx
000071ff71bdc5f1  push rdx
000071ff71bdc5f2  push rdi
000071ff71bdc5f3  push rsi
000071ff71bdc5f4  push r8
000071ff71bdc5f6  push r9
000071ff71bdc5f8  push r10
000071ff71bdc5fa  push r11
000071ff71bdc5fc  sub rsp, 0xF0
000071ff71bdc603  vmovaps [rsp], xmm0
000071ff71bdc608  vmovaps [rsp+0x10], xmm1
000071ff71bdc60e  vmovaps [rsp+0x20], xmm2
000071ff71bdc614  vmovaps [rsp+0x30], xmm3
000071ff71bdc61a  vmovaps [rsp+0x40], xmm4
000071ff71bdc620  vmovaps [rsp+0x50], xmm5
000071ff71bdc626  vmovaps [rsp+0x60], xmm6
000071ff71bdc62c  vmovaps [rsp+0x70], xmm7
000071ff71bdc632  vmovaps [rsp+0x80], xmm8
000071ff71bdc63b  vmovaps [rsp+0x90], xmm9
000071ff71bdc644  vmovaps [rsp+0xA0], xmm11
000071ff71bdc64d  vmovaps [rsp+0xB0], xmm12
000071ff71bdc656  vmovaps [rsp+0xC0], xmm13
000071ff71bdc65f  vmovaps [rsp+0xD0], xmm14
000071ff71bdc668  vmovaps [rsp+0xE0], xmm15
000071ff71bdc671  sub rsp, 0x30
000071ff71bdc675  movaps [rsp], xmm10
000071ff71bdc67a  movaps [rsp+0x10], xmm8
000071ff71bdc680  movaps [rsp+0x20], xmm14
000071ff71bdc686  lea rdi, [rsp]
000071ff71bdc68a  mov esi, 0x00
000071ff71bdc68f  mov rax, 0x5E6872E10530
000071ff71bdc699  call rax
000071ff71bdc69b  movaps xmm10, [rsp]
000071ff71bdc6a0  add rsp, 0x30
000071ff71bdc6a4  vmovaps xmm0, [rsp]
000071ff71bdc6a9  vmovaps xmm1, [rsp+0x10]
000071ff71bdc6af  vmovaps xmm2, [rsp+0x20]
000071ff71bdc6b5  vmovaps xmm3, [rsp+0x30]
000071ff71bdc6bb  vmovaps xmm4, [rsp+0x40]
000071ff71bdc6c1  vmovaps xmm5, [rsp+0x50]
000071ff71bdc6c7  vmovaps xmm6, [rsp+0x60]
000071ff71bdc6cd  vmovaps xmm7, [rsp+0x70]
000071ff71bdc6d3  vmovaps xmm8, [rsp+0x80]
000071ff71bdc6dc  vmovaps xmm9, [rsp+0x90]
000071ff71bdc6e5  vmovaps xmm11, [rsp+0xA0]
000071ff71bdc6ee  vmovaps xmm12, [rsp+0xB0]
000071ff71bdc6f7  vmovaps xmm13, [rsp+0xC0]
000071ff71bdc700  vmovaps xmm14, [rsp+0xD0]
000071ff71bdc709  vmovaps xmm15, [rsp+0xE0]
000071ff71bdc712  add rsp, 0xF0
000071ff71bdc719  pop r11
000071ff71bdc71b  pop r10
000071ff71bdc71d  pop r9
000071ff71bdc71f  pop r8
000071ff71bdc721  pop rsi
000071ff71bdc722  pop rdi
000071ff71bdc723  pop rdx
000071ff71bdc724  pop rcx
000071ff71bdc725  pop rax
000071ff71bdc726  add rsp, 0x08
000071ff71bdc72a  jmp 0x000071FF71BD9425
000071ff71bdc72f  sub rsp, 0x08
000071ff71bdc733  push rax
000071ff71bdc734  push rcx
000071ff71bdc735  push rdx
000071ff71bdc736  push rdi
000071ff71bdc737  push rsi
000071ff71bdc738  push r8
000071ff71bdc73a  push r9
000071ff71bdc73c  push r10
000071ff71bdc73e  push r11
000071ff71bdc740  sub rsp, 0xF0
000071ff71bdc747  vmovaps [rsp], xmm0
000071ff71bdc74c  vmovaps [rsp+0x10], xmm1
000071ff71bdc752  vmovaps [rsp+0x20], xmm2
000071ff71bdc758  vmovaps [rsp+0x30], xmm3
000071ff71bdc75e  vmovaps [rsp+0x40], xmm4
000071ff71bdc764  vmovaps [rsp+0x50], xmm5
000071ff71bdc76a  vmovaps [rsp+0x60], xmm6
000071ff71bdc770  vmovaps [rsp+0x70], xmm7
000071ff71bdc776  vmovaps [rsp+0x80], xmm8
000071ff71bdc77f  vmovaps [rsp+0x90], xmm9
000071ff71bdc788  vmovaps [rsp+0xA0], xmm10
000071ff71bdc791  vmovaps [rsp+0xB0], xmm11
000071ff71bdc79a  vmovaps [rsp+0xC0], xmm12
000071ff71bdc7a3  vmovaps [rsp+0xD0], xmm13
000071ff71bdc7ac  vmovaps [rsp+0xE0], xmm15
000071ff71bdc7b5  sub rsp, 0x30
000071ff71bdc7b9  movaps [rsp], xmm14
000071ff71bdc7be  movaps [rsp+0x10], xmm8
000071ff71bdc7c4  movaps [rsp+0x20], xmm4
000071ff71bdc7c9  lea rdi, [rsp]
000071ff71bdc7cd  mov esi, 0x00
000071ff71bdc7d2  mov rax, 0x5E6872E10530
000071ff71bdc7dc  call rax
000071ff71bdc7de  movaps xmm14, [rsp]
000071ff71bdc7e3  add rsp, 0x30
000071ff71bdc7e7  vmovaps xmm0, [rsp]
000071ff71bdc7ec  vmovaps xmm1, [rsp+0x10]
000071ff71bdc7f2  vmovaps xmm2, [rsp+0x20]
000071ff71bdc7f8  vmovaps xmm3, [rsp+0x30]
000071ff71bdc7fe  vmovaps xmm4, [rsp+0x40]
000071ff71bdc804  vmovaps xmm5, [rsp+0x50]
000071ff71bdc80a  vmovaps xmm6, [rsp+0x60]
000071ff71bdc810  vmovaps xmm7, [rsp+0x70]
000071ff71bdc816  vmovaps xmm8, [rsp+0x80]
000071ff71bdc81f  vmovaps xmm9, [rsp+0x90]
000071ff71bdc828  vmovaps xmm10, [rsp+0xA0]
000071ff71bdc831  vmovaps xmm11, [rsp+0xB0]
000071ff71bdc83a  vmovaps xmm12, [rsp+0xC0]
000071ff71bdc843  vmovaps xmm13, [rsp+0xD0]
000071ff71bdc84c  vmovaps xmm15, [rsp+0xE0]
000071ff71bdc855  add rsp, 0xF0
000071ff71bdc85c  pop r11
000071ff71bdc85e  pop r10
000071ff71bdc860  pop r9
000071ff71bdc862  pop r8
000071ff71bdc864  pop rsi
000071ff71bdc865  pop rdi
000071ff71bdc866  pop rdx
000071ff71bdc867  pop rcx
000071ff71bdc868  pop rax
000071ff71bdc869  add rsp, 0x08
000071ff71bdc86d  jmp 0x000071FF71BD9445
000071ff71bdc872  sub rsp, 0x08
000071ff71bdc876  push rax
000071ff71bdc877  push rcx
000071ff71bdc878  push rdx
000071ff71bdc879  push rdi
000071ff71bdc87a  push rsi
000071ff71bdc87b  push r8
000071ff71bdc87d  push r9
000071ff71bdc87f  push r10
000071ff71bdc881  push r11
000071ff71bdc883  sub rsp, 0xF0
000071ff71bdc88a  vmovaps [rsp], xmm0
000071ff71bdc88f  vmovaps [rsp+0x10], xmm1
000071ff71bdc895  vmovaps [rsp+0x20], xmm2
000071ff71bdc89b  vmovaps [rsp+0x30], xmm3
000071ff71bdc8a1  vmovaps [rsp+0x40], xmm5
000071ff71bdc8a7  vmovaps [rsp+0x50], xmm6
000071ff71bdc8ad  vmovaps [rsp+0x60], xmm7
000071ff71bdc8b3  vmovaps [rsp+0x70], xmm8
000071ff71bdc8b9  vmovaps [rsp+0x80], xmm9
000071ff71bdc8c2  vmovaps [rsp+0x90], xmm10
000071ff71bdc8cb  vmovaps [rsp+0xA0], xmm11
000071ff71bdc8d4  vmovaps [rsp+0xB0], xmm12
000071ff71bdc8dd  vmovaps [rsp+0xC0], xmm13
000071ff71bdc8e6  vmovaps [rsp+0xD0], xmm14
000071ff71bdc8ef  vmovaps [rsp+0xE0], xmm15
000071ff71bdc8f8  sub rsp, 0x30
000071ff71bdc8fc  movaps [rsp], xmm4
000071ff71bdc900  movaps [rsp+0x10], xmm13
000071ff71bdc906  movaps [rsp+0x20], xmm8
000071ff71bdc90c  lea rdi, [rsp]
000071ff71bdc910  mov esi, 0x00
000071ff71bdc915  mov rax, 0x5E6872E10530
000071ff71bdc91f  call rax
000071ff71bdc921  movaps xmm4, [rsp]
000071ff71bdc925  add rsp, 0x30
000071ff71bdc929  vmovaps xmm0, [rsp]
000071ff71bdc92e  vmovaps xmm1, [rsp+0x10]
000071ff71bdc934  vmovaps xmm2, [rsp+0x20]
000071ff71bdc93a  vmovaps xmm3, [rsp+0x30]
000071ff71bdc940  vmovaps xmm5, [rsp+0x40]
000071ff71bdc946  vmovaps xmm6, [rsp+0x50]
000071ff71bdc94c  vmovaps xmm7, [rsp+0x60]
000071ff71bdc952  vmovaps xmm8, [rsp+0x70]
000071ff71bdc958  vmovaps xmm9, [rsp+0x80]
000071ff71bdc961  vmovaps xmm10, [rsp+0x90]
000071ff71bdc96a  vmovaps xmm11, [rsp+0xA0]
000071ff71bdc973  vmovaps xmm12, [rsp+0xB0]
000071ff71bdc97c  vmovaps xmm13, [rsp+0xC0]
000071ff71bdc985  vmovaps xmm14, [rsp+0xD0]
000071ff71bdc98e  vmovaps xmm15, [rsp+0xE0]
000071ff71bdc997  add rsp, 0xF0
000071ff71bdc99e  pop r11
000071ff71bdc9a0  pop r10
000071ff71bdc9a2  pop r9
000071ff71bdc9a4  pop r8
000071ff71bdc9a6  pop rsi
000071ff71bdc9a7  pop rdi
000071ff71bdc9a8  pop rdx
000071ff71bdc9a9  pop rcx
000071ff71bdc9aa  pop rax
000071ff71bdc9ab  add rsp, 0x08
000071ff71bdc9af  jmp 0x000071FF71BD946A
000071ff71bdc9b4  sub rsp, 0x08
000071ff71bdc9b8  push rax
000071ff71bdc9b9  push rcx
000071ff71bdc9ba  push rdx
000071ff71bdc9bb  push rdi
000071ff71bdc9bc  push rsi
000071ff71bdc9bd  push r8
000071ff71bdc9bf  push r9
000071ff71bdc9c1  push r10
000071ff71bdc9c3  push r11
000071ff71bdc9c5  sub rsp, 0xF0
000071ff71bdc9cc  vmovaps [rsp], xmm0
000071ff71bdc9d1  vmovaps [rsp+0x10], xmm1
000071ff71bdc9d7  vmovaps [rsp+0x20], xmm2
000071ff71bdc9dd  vmovaps [rsp+0x30], xmm3
000071ff71bdc9e3  vmovaps [rsp+0x40], xmm4
000071ff71bdc9e9  vmovaps [rsp+0x50], xmm5
000071ff71bdc9ef  vmovaps [rsp+0x60], xmm6
000071ff71bdc9f5  vmovaps [rsp+0x70], xmm7
000071ff71bdc9fb  vmovaps [rsp+0x80], xmm8
000071ff71bdca04  vmovaps [rsp+0x90], xmm9
000071ff71bdca0d  vmovaps [rsp+0xA0], xmm10
000071ff71bdca16  vmovaps [rsp+0xB0], xmm11
000071ff71bdca1f  vmovaps [rsp+0xC0], xmm12
000071ff71bdca28  vmovaps [rsp+0xD0], xmm14
000071ff71bdca31  vmovaps [rsp+0xE0], xmm15
000071ff71bdca3a  sub rsp, 0x30
000071ff71bdca3e  movaps [rsp], xmm13
000071ff71bdca43  movaps [rsp+0x10], xmm15
000071ff71bdca49  movaps [rsp+0x20], xmm9
000071ff71bdca4f  lea rdi, [rsp]
000071ff71bdca53  mov esi, 0x00
000071ff71bdca58  mov rax, 0x5E6872E10530
000071ff71bdca62  call rax
000071ff71bdca64  movaps xmm13, [rsp]
000071ff71bdca69  add rsp, 0x30
000071ff71bdca6d  vmovaps xmm0, [rsp]
000071ff71bdca72  vmovaps xmm1, [rsp+0x10]
000071ff71bdca78  vmovaps xmm2, [rsp+0x20]
000071ff71bdca7e  vmovaps xmm3, [rsp+0x30]
000071ff71bdca84  vmovaps xmm4, [rsp+0x40]
000071ff71bdca8a  vmovaps xmm5, [rsp+0x50]
000071ff71bdca90  vmovaps xmm6, [rsp+0x60]
000071ff71bdca96  vmovaps xmm7, [rsp+0x70]
000071ff71bdca9c  vmovaps xmm8, [rsp+0x80]
000071ff71bdcaa5  vmovaps xmm9, [rsp+0x90]
000071ff71bdcaae  vmovaps xmm10, [rsp+0xA0]
000071ff71bdcab7  vmovaps xmm11, [rsp+0xB0]
000071ff71bdcac0  vmovaps xmm12, [rsp+0xC0]
000071ff71bdcac9  vmovaps xmm14, [rsp+0xD0]
000071ff71bdcad2  vmovaps xmm15, [rsp+0xE0]
000071ff71bdcadb  add rsp, 0xF0
000071ff71bdcae2  pop r11
000071ff71bdcae4  pop r10
000071ff71bdcae6  pop r9
000071ff71bdcae8  pop r8
000071ff71bdcaea  pop rsi
000071ff71bdcaeb  pop rdi
000071ff71bdcaec  pop rdx
000071ff71bdcaed  pop rcx
000071ff71bdcaee  pop rax
000071ff71bdcaef  add rsp, 0x08
000071ff71bdcaf3  jmp 0x000071FF71BD9485
000071ff71bdcaf8  sub rsp, 0x08
000071ff71bdcafc  push rax
000071ff71bdcafd  push rcx
000071ff71bdcafe  push rdx
000071ff71bdcaff  push rdi
000071ff71bdcb00  push rsi
000071ff71bdcb01  push r8
000071ff71bdcb03  push r9
000071ff71bdcb05  push r10
000071ff71bdcb07  push r11
000071ff71bdcb09  sub rsp, 0xF0
000071ff71bdcb10  vmovaps [rsp], xmm0
000071ff71bdcb15  vmovaps [rsp+0x10], xmm1
000071ff71bdcb1b  vmovaps [rsp+0x20], xmm2
000071ff71bdcb21  vmovaps [rsp+0x30], xmm3
000071ff71bdcb27  vmovaps [rsp+0x40], xmm4
000071ff71bdcb2d  vmovaps [rsp+0x50], xmm5
000071ff71bdcb33  vmovaps [rsp+0x60], xmm6
000071ff71bdcb39  vmovaps [rsp+0x70], xmm7
000071ff71bdcb3f  vmovaps [rsp+0x80], xmm8
000071ff71bdcb48  vmovaps [rsp+0x90], xmm9
000071ff71bdcb51  vmovaps [rsp+0xA0], xmm10
000071ff71bdcb5a  vmovaps [rsp+0xB0], xmm11
000071ff71bdcb63  vmovaps [rsp+0xC0], xmm12
000071ff71bdcb6c  vmovaps [rsp+0xD0], xmm13
000071ff71bdcb75  vmovaps [rsp+0xE0], xmm14
000071ff71bdcb7e  sub rsp, 0x30
000071ff71bdcb82  movaps [rsp], xmm15
000071ff71bdcb87  movaps [rsp+0x10], xmm1
000071ff71bdcb8c  movaps [rsp+0x20], xmm5
000071ff71bdcb91  lea rdi, [rsp]
000071ff71bdcb95  mov esi, 0x00
000071ff71bdcb9a  mov rax, 0x5E6872E10530
000071ff71bdcba4  call rax
000071ff71bdcba6  movaps xmm15, [rsp]
000071ff71bdcbab  add rsp, 0x30
000071ff71bdcbaf  vmovaps xmm0, [rsp]
000071ff71bdcbb4  vmovaps xmm1, [rsp+0x10]
000071ff71bdcbba  vmovaps xmm2, [rsp+0x20]
000071ff71bdcbc0  vmovaps xmm3, [rsp+0x30]
000071ff71bdcbc6  vmovaps xmm4, [rsp+0x40]
000071ff71bdcbcc  vmovaps xmm5, [rsp+0x50]
000071ff71bdcbd2  vmovaps xmm6, [rsp+0x60]
000071ff71bdcbd8  vmovaps xmm7, [rsp+0x70]
000071ff71bdcbde  vmovaps xmm8, [rsp+0x80]
000071ff71bdcbe7  vmovaps xmm9, [rsp+0x90]
000071ff71bdcbf0  vmovaps xmm10, [rsp+0xA0]
000071ff71bdcbf9  vmovaps xmm11, [rsp+0xB0]
000071ff71bdcc02  vmovaps xmm12, [rsp+0xC0]
000071ff71bdcc0b  vmovaps xmm13, [rsp+0xD0]
000071ff71bdcc14  vmovaps xmm14, [rsp+0xE0]
000071ff71bdcc1d  add rsp, 0xF0
000071ff71bdcc24  pop r11
000071ff71bdcc26  pop r10
000071ff71bdcc28  pop r9
000071ff71bdcc2a  pop r8
000071ff71bdcc2c  pop rsi
000071ff71bdcc2d  pop rdi
000071ff71bdcc2e  pop rdx
000071ff71bdcc2f  pop rcx
000071ff71bdcc30  pop rax
000071ff71bdcc31  add rsp, 0x08
000071ff71bdcc35  jmp 0x000071FF71BD94A0
000071ff71bdcc3a  call 0x000071FF71AD64F0
000071ff71bdcc3f  jmp 0x000071FF71BD94FB
000071ff71bdcc44  sub rsp, 0x08
000071ff71bdcc48  push rax
000071ff71bdcc49  push rcx
000071ff71bdcc4a  push rdx
000071ff71bdcc4b  push rdi
000071ff71bdcc4c  push rsi
000071ff71bdcc4d  push r8
000071ff71bdcc4f  push r9
000071ff71bdcc51  push r10
000071ff71bdcc53  push r11
000071ff71bdcc55  sub rsp, 0xF0
000071ff71bdcc5c  vmovaps [rsp], xmm0
000071ff71bdcc61  vmovaps [rsp+0x10], xmm1
000071ff71bdcc67  vmovaps [rsp+0x20], xmm2
000071ff71bdcc6d  vmovaps [rsp+0x30], xmm3
000071ff71bdcc73  vmovaps [rsp+0x40], xmm4
000071ff71bdcc79  vmovaps [rsp+0x50], xmm5
000071ff71bdcc7f  vmovaps [rsp+0x60], xmm6
000071ff71bdcc85  vmovaps [rsp+0x70], xmm7
000071ff71bdcc8b  vmovaps [rsp+0x80], xmm8
000071ff71bdcc94  vmovaps [rsp+0x90], xmm10
000071ff71bdcc9d  vmovaps [rsp+0xA0], xmm11
000071ff71bdcca6  vmovaps [rsp+0xB0], xmm12
000071ff71bdccaf  vmovaps [rsp+0xC0], xmm13
000071ff71bdccb8  vmovaps [rsp+0xD0], xmm14
000071ff71bdccc1  vmovaps [rsp+0xE0], xmm15
000071ff71bdccca  sub rsp, 0x30
000071ff71bdccce  movaps [rsp], xmm9
000071ff71bdccd3  movaps [rsp+0x10], xmm8
000071ff71bdccd9  movaps [rsp+0x20], xmm11
000071ff71bdccdf  lea rdi, [rsp]
000071ff71bdcce3  mov esi, 0x00
000071ff71bdcce8  mov rax, 0x5E6872E10530
000071ff71bdccf2  call rax
000071ff71bdccf4  movaps xmm9, [rsp]
000071ff71bdccf9  add rsp, 0x30
000071ff71bdccfd  vmovaps xmm0, [rsp]
000071ff71bdcd02  vmovaps xmm1, [rsp+0x10]
000071ff71bdcd08  vmovaps xmm2, [rsp+0x20]
000071ff71bdcd0e  vmovaps xmm3, [rsp+0x30]
000071ff71bdcd14  vmovaps xmm4, [rsp+0x40]
000071ff71bdcd1a  vmovaps xmm5, [rsp+0x50]
000071ff71bdcd20  vmovaps xmm6, [rsp+0x60]
000071ff71bdcd26  vmovaps xmm7, [rsp+0x70]
000071ff71bdcd2c  vmovaps xmm8, [rsp+0x80]
000071ff71bdcd35  vmovaps xmm10, [rsp+0x90]
000071ff71bdcd3e  vmovaps xmm11, [rsp+0xA0]
000071ff71bdcd47  vmovaps xmm12, [rsp+0xB0]
000071ff71bdcd50  vmovaps xmm13, [rsp+0xC0]
000071ff71bdcd59  vmovaps xmm14, [rsp+0xD0]
000071ff71bdcd62  vmovaps xmm15, [rsp+0xE0]
000071ff71bdcd6b  add rsp, 0xF0
000071ff71bdcd72  pop r11
000071ff71bdcd74  pop r10
000071ff71bdcd76  pop r9
000071ff71bdcd78  pop r8
000071ff71bdcd7a  pop rsi
000071ff71bdcd7b  pop rdi
000071ff71bdcd7c  pop rdx
000071ff71bdcd7d  pop rcx
000071ff71bdcd7e  pop rax
000071ff71bdcd7f  add rsp, 0x08
000071ff71bdcd83  jmp 0x000071FF71BD9532
000071ff71bdcd88  sub rsp, 0x08
000071ff71bdcd8c  push rax
000071ff71bdcd8d  push rcx
000071ff71bdcd8e  push rdx
000071ff71bdcd8f  push rdi
000071ff71bdcd90  push rsi
000071ff71bdcd91  push r8
000071ff71bdcd93  push r9
000071ff71bdcd95  push r10
000071ff71bdcd97  push r11
000071ff71bdcd99  sub rsp, 0xF0
000071ff71bdcda0  vmovaps [rsp], xmm0
000071ff71bdcda5  vmovaps [rsp+0x10], xmm1
000071ff71bdcdab  vmovaps [rsp+0x20], xmm2
000071ff71bdcdb1  vmovaps [rsp+0x30], xmm3
000071ff71bdcdb7  vmovaps [rsp+0x40], xmm4
000071ff71bdcdbd  vmovaps [rsp+0x50], xmm5
000071ff71bdcdc3  vmovaps [rsp+0x60], xmm6
000071ff71bdcdc9  vmovaps [rsp+0x70], xmm7
000071ff71bdcdcf  vmovaps [rsp+0x80], xmm8
000071ff71bdcdd8  vmovaps [rsp+0x90], xmm9
000071ff71bdcde1  vmovaps [rsp+0xA0], xmm10
000071ff71bdcdea  vmovaps [rsp+0xB0], xmm12
000071ff71bdcdf3  vmovaps [rsp+0xC0], xmm13
000071ff71bdcdfc  vmovaps [rsp+0xD0], xmm14
000071ff71bdce05  vmovaps [rsp+0xE0], xmm15
000071ff71bdce0e  sub rsp, 0x30
000071ff71bdce12  movaps [rsp], xmm11
000071ff71bdce17  movaps [rsp+0x10], xmm10
000071ff71bdce1d  movaps [rsp+0x20], xmm6
000071ff71bdce22  lea rdi, [rsp]
000071ff71bdce26  mov esi, 0x00
000071ff71bdce2b  mov rax, 0x5E6872E10530
000071ff71bdce35  call rax
000071ff71bdce37  movaps xmm11, [rsp]
000071ff71bdce3c  add rsp, 0x30
000071ff71bdce40  vmovaps xmm0, [rsp]
000071ff71bdce45  vmovaps xmm1, [rsp+0x10]
000071ff71bdce4b  vmovaps xmm2, [rsp+0x20]
000071ff71bdce51  vmovaps xmm3, [rsp+0x30]
000071ff71bdce57  vmovaps xmm4, [rsp+0x40]
000071ff71bdce5d  vmovaps xmm5, [rsp+0x50]
000071ff71bdce63  vmovaps xmm6, [rsp+0x60]
000071ff71bdce69  vmovaps xmm7, [rsp+0x70]
000071ff71bdce6f  vmovaps xmm8, [rsp+0x80]
000071ff71bdce78  vmovaps xmm9, [rsp+0x90]
000071ff71bdce81  vmovaps xmm10, [rsp+0xA0]
000071ff71bdce8a  vmovaps xmm12, [rsp+0xB0]
000071ff71bdce93  vmovaps xmm13, [rsp+0xC0]
000071ff71bdce9c  vmovaps xmm14, [rsp+0xD0]
000071ff71bdcea5  vmovaps xmm15, [rsp+0xE0]
000071ff71bdceae  add rsp, 0xF0
000071ff71bdceb5  pop r11
000071ff71bdceb7  pop r10
000071ff71bdceb9  pop r9
000071ff71bdcebb  pop r8
000071ff71bdcebd  pop rsi
000071ff71bdcebe  pop rdi
000071ff71bdcebf  pop rdx
000071ff71bdcec0  pop rcx
000071ff71bdcec1  pop rax
000071ff71bdcec2  add rsp, 0x08
000071ff71bdcec6  jmp 0x000071FF71BD954D
000071ff71bdcecb  sub rsp, 0x08
000071ff71bdcecf  push rax
000071ff71bdced0  push rcx
000071ff71bdced1  push rdx
000071ff71bdced2  push rdi
000071ff71bdced3  push rsi
000071ff71bdced4  push r8
000071ff71bdced6  push r9
000071ff71bdced8  push r10
000071ff71bdceda  push r11
000071ff71bdcedc  sub rsp, 0xF0
000071ff71bdcee3  vmovaps [rsp], xmm0
000071ff71bdcee8  vmovaps [rsp+0x10], xmm1
000071ff71bdceee  vmovaps [rsp+0x20], xmm2
000071ff71bdcef4  vmovaps [rsp+0x30], xmm3
000071ff71bdcefa  vmovaps [rsp+0x40], xmm4
000071ff71bdcf00  vmovaps [rsp+0x50], xmm5
000071ff71bdcf06  vmovaps [rsp+0x60], xmm6
000071ff71bdcf0c  vmovaps [rsp+0x70], xmm7
000071ff71bdcf12  vmovaps [rsp+0x80], xmm8
000071ff71bdcf1b  vmovaps [rsp+0x90], xmm9
000071ff71bdcf24  vmovaps [rsp+0xA0], xmm11
000071ff71bdcf2d  vmovaps [rsp+0xB0], xmm12
000071ff71bdcf36  vmovaps [rsp+0xC0], xmm13
000071ff71bdcf3f  vmovaps [rsp+0xD0], xmm14
000071ff71bdcf48  vmovaps [rsp+0xE0], xmm15
000071ff71bdcf51  sub rsp, 0x30
000071ff71bdcf55  movaps [rsp], xmm10
000071ff71bdcf5a  movaps [rsp+0x10], xmm14
000071ff71bdcf60  movaps [rsp+0x20], xmm4
000071ff71bdcf65  lea rdi, [rsp]
000071ff71bdcf69  mov esi, 0x00
000071ff71bdcf6e  mov rax, 0x5E6872E10530
000071ff71bdcf78  call rax
000071ff71bdcf7a  movaps xmm10, [rsp]
000071ff71bdcf7f  add rsp, 0x30
000071ff71bdcf83  vmovaps xmm0, [rsp]
000071ff71bdcf88  vmovaps xmm1, [rsp+0x10]
000071ff71bdcf8e  vmovaps xmm2, [rsp+0x20]
000071ff71bdcf94  vmovaps xmm3, [rsp+0x30]
000071ff71bdcf9a  vmovaps xmm4, [rsp+0x40]
000071ff71bdcfa0  vmovaps xmm5, [rsp+0x50]
000071ff71bdcfa6  vmovaps xmm6, [rsp+0x60]
000071ff71bdcfac  vmovaps xmm7, [rsp+0x70]
000071ff71bdcfb2  vmovaps xmm8, [rsp+0x80]
000071ff71bdcfbb  vmovaps xmm9, [rsp+0x90]
000071ff71bdcfc4  vmovaps xmm11, [rsp+0xA0]
000071ff71bdcfcd  vmovaps xmm12, [rsp+0xB0]
000071ff71bdcfd6  vmovaps xmm13, [rsp+0xC0]
000071ff71bdcfdf  vmovaps xmm14, [rsp+0xD0]
000071ff71bdcfe8  vmovaps xmm15, [rsp+0xE0]
000071ff71bdcff1  add rsp, 0xF0
000071ff71bdcff8  pop r11
000071ff71bdcffa  pop r10
000071ff71bdcffc  pop r9
000071ff71bdcffe  pop r8
000071ff71bdd000  pop rsi
000071ff71bdd001  pop rdi
000071ff71bdd002  pop rdx
000071ff71bdd003  pop rcx
000071ff71bdd004  pop rax
000071ff71bdd005  add rsp, 0x08
000071ff71bdd009  jmp 0x000071FF71BD9568
000071ff71bdd00e  sub rsp, 0x08
000071ff71bdd012  push rax
000071ff71bdd013  push rcx
000071ff71bdd014  push rdx
000071ff71bdd015  push rdi
000071ff71bdd016  push rsi
000071ff71bdd017  push r8
000071ff71bdd019  push r9
000071ff71bdd01b  push r10
000071ff71bdd01d  push r11
000071ff71bdd01f  sub rsp, 0xF0
000071ff71bdd026  vmovaps [rsp], xmm0
000071ff71bdd02b  vmovaps [rsp+0x10], xmm1
000071ff71bdd031  vmovaps [rsp+0x20], xmm2
000071ff71bdd037  vmovaps [rsp+0x30], xmm3
000071ff71bdd03d  vmovaps [rsp+0x40], xmm4
000071ff71bdd043  vmovaps [rsp+0x50], xmm5
000071ff71bdd049  vmovaps [rsp+0x60], xmm6
000071ff71bdd04f  vmovaps [rsp+0x70], xmm7
000071ff71bdd055  vmovaps [rsp+0x80], xmm9
000071ff71bdd05e  vmovaps [rsp+0x90], xmm10
000071ff71bdd067  vmovaps [rsp+0xA0], xmm11
000071ff71bdd070  vmovaps [rsp+0xB0], xmm12
000071ff71bdd079  vmovaps [rsp+0xC0], xmm13
000071ff71bdd082  vmovaps [rsp+0xD0], xmm14
000071ff71bdd08b  vmovaps [rsp+0xE0], xmm15
000071ff71bdd094  sub rsp, 0x30
000071ff71bdd098  movaps [rsp], xmm8
000071ff71bdd09d  movaps [rsp+0x10], xmm1
000071ff71bdd0a2  movaps [rsp+0x20], xmm14
000071ff71bdd0a8  lea rdi, [rsp]
000071ff71bdd0ac  mov esi, 0x00
000071ff71bdd0b1  mov rax, 0x5E6872E10530
000071ff71bdd0bb  call rax
000071ff71bdd0bd  movaps xmm8, [rsp]
000071ff71bdd0c2  add rsp, 0x30
000071ff71bdd0c6  vmovaps xmm0, [rsp]
000071ff71bdd0cb  vmovaps xmm1, [rsp+0x10]
000071ff71bdd0d1  vmovaps xmm2, [rsp+0x20]
000071ff71bdd0d7  vmovaps xmm3, [rsp+0x30]
000071ff71bdd0dd  vmovaps xmm4, [rsp+0x40]
000071ff71bdd0e3  vmovaps xmm5, [rsp+0x50]
000071ff71bdd0e9  vmovaps xmm6, [rsp+0x60]
000071ff71bdd0ef  vmovaps xmm7, [rsp+0x70]
000071ff71bdd0f5  vmovaps xmm9, [rsp+0x80]
000071ff71bdd0fe  vmovaps xmm10, [rsp+0x90]
000071ff71bdd107  vmovaps xmm11, [rsp+0xA0]
000071ff71bdd110  vmovaps xmm12, [rsp+0xB0]
000071ff71bdd119  vmovaps xmm13, [rsp+0xC0]
000071ff71bdd122  vmovaps xmm14, [rsp+0xD0]
000071ff71bdd12b  vmovaps xmm15, [rsp+0xE0]
000071ff71bdd134  add rsp, 0xF0
000071ff71bdd13b  pop r11
000071ff71bdd13d  pop r10
000071ff71bdd13f  pop r9
000071ff71bdd141  pop r8
000071ff71bdd143  pop rsi
000071ff71bdd144  pop rdi
000071ff71bdd145  pop rdx
000071ff71bdd146  pop rcx
000071ff71bdd147  pop rax
000071ff71bdd148  add rsp, 0x08
000071ff71bdd14c  jmp 0x000071FF71BD958E
000071ff71bdd151  sub rsp, 0x08
000071ff71bdd155  push rax
000071ff71bdd156  push rcx
000071ff71bdd157  push rdx
000071ff71bdd158  push rdi
000071ff71bdd159  push rsi
000071ff71bdd15a  push r8
000071ff71bdd15c  push r9
000071ff71bdd15e  push r10
000071ff71bdd160  push r11
000071ff71bdd162  sub rsp, 0xF0
000071ff71bdd169  vmovaps [rsp], xmm0
000071ff71bdd16e  vmovaps [rsp+0x10], xmm1
000071ff71bdd174  vmovaps [rsp+0x20], xmm2
000071ff71bdd17a  vmovaps [rsp+0x30], xmm3
000071ff71bdd180  vmovaps [rsp+0x40], xmm4
000071ff71bdd186  vmovaps [rsp+0x50], xmm5
000071ff71bdd18c  vmovaps [rsp+0x60], xmm7
000071ff71bdd192  vmovaps [rsp+0x70], xmm8
000071ff71bdd198  vmovaps [rsp+0x80], xmm9
000071ff71bdd1a1  vmovaps [rsp+0x90], xmm10
000071ff71bdd1aa  vmovaps [rsp+0xA0], xmm11
000071ff71bdd1b3  vmovaps [rsp+0xB0], xmm12
000071ff71bdd1bc  vmovaps [rsp+0xC0], xmm13
000071ff71bdd1c5  vmovaps [rsp+0xD0], xmm14
000071ff71bdd1ce  vmovaps [rsp+0xE0], xmm15
000071ff71bdd1d7  sub rsp, 0x30
000071ff71bdd1db  movaps [rsp], xmm6
000071ff71bdd1df  movaps [rsp+0x10], xmm1
000071ff71bdd1e4  movaps [rsp+0x20], xmm14
000071ff71bdd1ea  lea rdi, [rsp]
000071ff71bdd1ee  mov esi, 0x00
000071ff71bdd1f3  mov rax, 0x5E6872E10530
000071ff71bdd1fd  call rax
000071ff71bdd1ff  movaps xmm6, [rsp]
000071ff71bdd203  add rsp, 0x30
000071ff71bdd207  vmovaps xmm0, [rsp]
000071ff71bdd20c  vmovaps xmm1, [rsp+0x10]
000071ff71bdd212  vmovaps xmm2, [rsp+0x20]
000071ff71bdd218  vmovaps xmm3, [rsp+0x30]
000071ff71bdd21e  vmovaps xmm4, [rsp+0x40]
000071ff71bdd224  vmovaps xmm5, [rsp+0x50]
000071ff71bdd22a  vmovaps xmm7, [rsp+0x60]
000071ff71bdd230  vmovaps xmm8, [rsp+0x70]
000071ff71bdd236  vmovaps xmm9, [rsp+0x80]
000071ff71bdd23f  vmovaps xmm10, [rsp+0x90]
000071ff71bdd248  vmovaps xmm11, [rsp+0xA0]
000071ff71bdd251  vmovaps xmm12, [rsp+0xB0]
000071ff71bdd25a  vmovaps xmm13, [rsp+0xC0]
000071ff71bdd263  vmovaps xmm14, [rsp+0xD0]
000071ff71bdd26c  vmovaps xmm15, [rsp+0xE0]
000071ff71bdd275  add rsp, 0xF0
000071ff71bdd27c  pop r11
000071ff71bdd27e  pop r10
000071ff71bdd280  pop r9
000071ff71bdd282  pop r8
000071ff71bdd284  pop rsi
000071ff71bdd285  pop rdi
000071ff71bdd286  pop rdx
000071ff71bdd287  pop rcx
000071ff71bdd288  pop rax
000071ff71bdd289  add rsp, 0x08
000071ff71bdd28d  jmp 0x000071FF71BD95BA
000071ff71bdd292  sub rsp, 0x08
000071ff71bdd296  push rax
000071ff71bdd297  push rcx
000071ff71bdd298  push rdx
000071ff71bdd299  push rdi
000071ff71bdd29a  push rsi
000071ff71bdd29b  push r8
000071ff71bdd29d  push r9
000071ff71bdd29f  push r10
000071ff71bdd2a1  push r11
000071ff71bdd2a3  sub rsp, 0xF0
000071ff71bdd2aa  vmovaps [rsp], xmm0
000071ff71bdd2af  vmovaps [rsp+0x10], xmm1
000071ff71bdd2b5  vmovaps [rsp+0x20], xmm2
000071ff71bdd2bb  vmovaps [rsp+0x30], xmm3
000071ff71bdd2c1  vmovaps [rsp+0x40], xmm4
000071ff71bdd2c7  vmovaps [rsp+0x50], xmm5
000071ff71bdd2cd  vmovaps [rsp+0x60], xmm6
000071ff71bdd2d3  vmovaps [rsp+0x70], xmm7
000071ff71bdd2d9  vmovaps [rsp+0x80], xmm8
000071ff71bdd2e2  vmovaps [rsp+0x90], xmm9
000071ff71bdd2eb  vmovaps [rsp+0xA0], xmm10
000071ff71bdd2f4  vmovaps [rsp+0xB0], xmm11
000071ff71bdd2fd  vmovaps [rsp+0xC0], xmm12
000071ff71bdd306  vmovaps [rsp+0xD0], xmm13
000071ff71bdd30f  vmovaps [rsp+0xE0], xmm15
000071ff71bdd318  sub rsp, 0x30
000071ff71bdd31c  movaps [rsp], xmm14
000071ff71bdd321  movaps [rsp+0x10], xmm12
000071ff71bdd327  movaps [rsp+0x20], xmm1
000071ff71bdd32c  lea rdi, [rsp]
000071ff71bdd330  mov esi, 0x00
000071ff71bdd335  mov rax, 0x5E6872E10530
000071ff71bdd33f  call rax
000071ff71bdd341  movaps xmm14, [rsp]
000071ff71bdd346  add rsp, 0x30
000071ff71bdd34a  vmovaps xmm0, [rsp]
000071ff71bdd34f  vmovaps xmm1, [rsp+0x10]
000071ff71bdd355  vmovaps xmm2, [rsp+0x20]
000071ff71bdd35b  vmovaps xmm3, [rsp+0x30]
000071ff71bdd361  vmovaps xmm4, [rsp+0x40]
000071ff71bdd367  vmovaps xmm5, [rsp+0x50]
000071ff71bdd36d  vmovaps xmm6, [rsp+0x60]
000071ff71bdd373  vmovaps xmm7, [rsp+0x70]
000071ff71bdd379  vmovaps xmm8, [rsp+0x80]
000071ff71bdd382  vmovaps xmm9, [rsp+0x90]
000071ff71bdd38b  vmovaps xmm10, [rsp+0xA0]
000071ff71bdd394  vmovaps xmm11, [rsp+0xB0]
000071ff71bdd39d  vmovaps xmm12, [rsp+0xC0]
000071ff71bdd3a6  vmovaps xmm13, [rsp+0xD0]
000071ff71bdd3af  vmovaps xmm15, [rsp+0xE0]
000071ff71bdd3b8  add rsp, 0xF0
000071ff71bdd3bf  pop r11
000071ff71bdd3c1  pop r10
000071ff71bdd3c3  pop r9
000071ff71bdd3c5  pop r8
000071ff71bdd3c7  pop rsi
000071ff71bdd3c8  pop rdi
000071ff71bdd3c9  pop rdx
000071ff71bdd3ca  pop rcx
000071ff71bdd3cb  pop rax
000071ff71bdd3cc  add rsp, 0x08
000071ff71bdd3d0  jmp 0x000071FF71BD95E0
000071ff71bdd3d5  sub rsp, 0x08
000071ff71bdd3d9  push rax
000071ff71bdd3da  push rcx
000071ff71bdd3db  push rdx
000071ff71bdd3dc  push rdi
000071ff71bdd3dd  push rsi
000071ff71bdd3de  push r8
000071ff71bdd3e0  push r9
000071ff71bdd3e2  push r10
000071ff71bdd3e4  push r11
000071ff71bdd3e6  sub rsp, 0xF0
000071ff71bdd3ed  vmovaps [rsp], xmm0
000071ff71bdd3f2  vmovaps [rsp+0x10], xmm2
000071ff71bdd3f8  vmovaps [rsp+0x20], xmm3
000071ff71bdd3fe  vmovaps [rsp+0x30], xmm4
000071ff71bdd404  vmovaps [rsp+0x40], xmm5
000071ff71bdd40a  vmovaps [rsp+0x50], xmm6
000071ff71bdd410  vmovaps [rsp+0x60], xmm7
000071ff71bdd416  vmovaps [rsp+0x70], xmm8
000071ff71bdd41c  vmovaps [rsp+0x80], xmm9
000071ff71bdd425  vmovaps [rsp+0x90], xmm10
000071ff71bdd42e  vmovaps [rsp+0xA0], xmm11
000071ff71bdd437  vmovaps [rsp+0xB0], xmm12
000071ff71bdd440  vmovaps [rsp+0xC0], xmm13
000071ff71bdd449  vmovaps [rsp+0xD0], xmm14
000071ff71bdd452  vmovaps [rsp+0xE0], xmm15
000071ff71bdd45b  sub rsp, 0x30
000071ff71bdd45f  movaps [rsp], xmm1
000071ff71bdd463  movaps [rsp+0x10], xmm13
000071ff71bdd469  movaps [rsp+0x20], xmm9
000071ff71bdd46f  lea rdi, [rsp]
000071ff71bdd473  mov esi, 0x00
000071ff71bdd478  mov rax, 0x5E6872E10530
000071ff71bdd482  call rax
000071ff71bdd484  movaps xmm1, [rsp]
000071ff71bdd488  add rsp, 0x30
000071ff71bdd48c  vmovaps xmm0, [rsp]
000071ff71bdd491  vmovaps xmm2, [rsp+0x10]
000071ff71bdd497  vmovaps xmm3, [rsp+0x20]
000071ff71bdd49d  vmovaps xmm4, [rsp+0x30]
000071ff71bdd4a3  vmovaps xmm5, [rsp+0x40]
000071ff71bdd4a9  vmovaps xmm6, [rsp+0x50]
000071ff71bdd4af  vmovaps xmm7, [rsp+0x60]
000071ff71bdd4b5  vmovaps xmm8, [rsp+0x70]
000071ff71bdd4bb  vmovaps xmm9, [rsp+0x80]
000071ff71bdd4c4  vmovaps xmm10, [rsp+0x90]
000071ff71bdd4cd  vmovaps xmm11, [rsp+0xA0]
000071ff71bdd4d6  vmovaps xmm12, [rsp+0xB0]
000071ff71bdd4df  vmovaps xmm13, [rsp+0xC0]
000071ff71bdd4e8  vmovaps xmm14, [rsp+0xD0]
000071ff71bdd4f1  vmovaps xmm15, [rsp+0xE0]
000071ff71bdd4fa  add rsp, 0xF0
000071ff71bdd501  pop r11
000071ff71bdd503  pop r10
000071ff71bdd505  pop r9
000071ff71bdd507  pop r8
000071ff71bdd509  pop rsi
000071ff71bdd50a  pop rdi
000071ff71bdd50b  pop rdx
000071ff71bdd50c  pop rcx
000071ff71bdd50d  pop rax
000071ff71bdd50e  add rsp, 0x08
000071ff71bdd512  jmp 0x000071FF71BD95FA
000071ff71bdd517  sub rsp, 0x08
000071ff71bdd51b  push rax
000071ff71bdd51c  push rcx
000071ff71bdd51d  push rdx
000071ff71bdd51e  push rdi
000071ff71bdd51f  push rsi
000071ff71bdd520  push r8
000071ff71bdd522  push r9
000071ff71bdd524  push r10
000071ff71bdd526  push r11
000071ff71bdd528  sub rsp, 0xF0
000071ff71bdd52f  vmovaps [rsp], xmm0
000071ff71bdd534  vmovaps [rsp+0x10], xmm1
000071ff71bdd53a  vmovaps [rsp+0x20], xmm2
000071ff71bdd540  vmovaps [rsp+0x30], xmm3
000071ff71bdd546  vmovaps [rsp+0x40], xmm4
000071ff71bdd54c  vmovaps [rsp+0x50], xmm5
000071ff71bdd552  vmovaps [rsp+0x60], xmm6
000071ff71bdd558  vmovaps [rsp+0x70], xmm7
000071ff71bdd55e  vmovaps [rsp+0x80], xmm8
000071ff71bdd567  vmovaps [rsp+0x90], xmm9
000071ff71bdd570  vmovaps [rsp+0xA0], xmm10
000071ff71bdd579  vmovaps [rsp+0xB0], xmm11
000071ff71bdd582  vmovaps [rsp+0xC0], xmm13
000071ff71bdd58b  vmovaps [rsp+0xD0], xmm14
000071ff71bdd594  vmovaps [rsp+0xE0], xmm15
000071ff71bdd59d  sub rsp, 0x30
000071ff71bdd5a1  movaps [rsp], xmm12
000071ff71bdd5a6  movaps [rsp+0x10], xmm7
000071ff71bdd5ab  movaps [rsp+0x20], xmm13
000071ff71bdd5b1  lea rdi, [rsp]
000071ff71bdd5b5  mov esi, 0x00
000071ff71bdd5ba  mov rax, 0x5E6872E10530
000071ff71bdd5c4  call rax
000071ff71bdd5c6  movaps xmm12, [rsp]
000071ff71bdd5cb  add rsp, 0x30
000071ff71bdd5cf  vmovaps xmm0, [rsp]
000071ff71bdd5d4  vmovaps xmm1, [rsp+0x10]
000071ff71bdd5da  vmovaps xmm2, [rsp+0x20]
000071ff71bdd5e0  vmovaps xmm3, [rsp+0x30]
000071ff71bdd5e6  vmovaps xmm4, [rsp+0x40]
000071ff71bdd5ec  vmovaps xmm5, [rsp+0x50]
000071ff71bdd5f2  vmovaps xmm6, [rsp+0x60]
000071ff71bdd5f8  vmovaps xmm7, [rsp+0x70]
000071ff71bdd5fe  vmovaps xmm8, [rsp+0x80]
000071ff71bdd607  vmovaps xmm9, [rsp+0x90]
000071ff71bdd610  vmovaps xmm10, [rsp+0xA0]
000071ff71bdd619  vmovaps xmm11, [rsp+0xB0]
000071ff71bdd622  vmovaps xmm13, [rsp+0xC0]
000071ff71bdd62b  vmovaps xmm14, [rsp+0xD0]
000071ff71bdd634  vmovaps xmm15, [rsp+0xE0]
000071ff71bdd63d  add rsp, 0xF0
000071ff71bdd644  pop r11
000071ff71bdd646  pop r10
000071ff71bdd648  pop r9
000071ff71bdd64a  pop r8
000071ff71bdd64c  pop rsi
000071ff71bdd64d  pop rdi
000071ff71bdd64e  pop rdx
000071ff71bdd64f  pop rcx
000071ff71bdd650  pop rax
000071ff71bdd651  add rsp, 0x08
000071ff71bdd655  jmp 0x000071FF71BD9621
000071ff71bdd65a  sub rsp, 0x08
000071ff71bdd65e  push rax
000071ff71bdd65f  push rcx
000071ff71bdd660  push rdx
000071ff71bdd661  push rdi
000071ff71bdd662  push rsi
000071ff71bdd663  push r8
000071ff71bdd665  push r9
000071ff71bdd667  push r10
000071ff71bdd669  push r11
000071ff71bdd66b  sub rsp, 0xF0
000071ff71bdd672  vmovaps [rsp], xmm0
000071ff71bdd677  vmovaps [rsp+0x10], xmm1
000071ff71bdd67d  vmovaps [rsp+0x20], xmm2
000071ff71bdd683  vmovaps [rsp+0x30], xmm3
000071ff71bdd689  vmovaps [rsp+0x40], xmm4
000071ff71bdd68f  vmovaps [rsp+0x50], xmm5
000071ff71bdd695  vmovaps [rsp+0x60], xmm6
000071ff71bdd69b  vmovaps [rsp+0x70], xmm7
000071ff71bdd6a1  vmovaps [rsp+0x80], xmm8
000071ff71bdd6aa  vmovaps [rsp+0x90], xmm9
000071ff71bdd6b3  vmovaps [rsp+0xA0], xmm10
000071ff71bdd6bc  vmovaps [rsp+0xB0], xmm11
000071ff71bdd6c5  vmovaps [rsp+0xC0], xmm12
000071ff71bdd6ce  vmovaps [rsp+0xD0], xmm14
000071ff71bdd6d7  vmovaps [rsp+0xE0], xmm15
000071ff71bdd6e0  sub rsp, 0x30
000071ff71bdd6e4  movaps [rsp], xmm13
000071ff71bdd6e9  movaps [rsp+0x10], xmm15
000071ff71bdd6ef  movaps [rsp+0x20], xmm8
000071ff71bdd6f5  lea rdi, [rsp]
000071ff71bdd6f9  mov esi, 0x00
000071ff71bdd6fe  mov rax, 0x5E6872E10530
000071ff71bdd708  call rax
000071ff71bdd70a  movaps xmm13, [rsp]
000071ff71bdd70f  add rsp, 0x30
000071ff71bdd713  vmovaps xmm0, [rsp]
000071ff71bdd718  vmovaps xmm1, [rsp+0x10]
000071ff71bdd71e  vmovaps xmm2, [rsp+0x20]
000071ff71bdd724  vmovaps xmm3, [rsp+0x30]
000071ff71bdd72a  vmovaps xmm4, [rsp+0x40]
000071ff71bdd730  vmovaps xmm5, [rsp+0x50]
000071ff71bdd736  vmovaps xmm6, [rsp+0x60]
000071ff71bdd73c  vmovaps xmm7, [rsp+0x70]
000071ff71bdd742  vmovaps xmm8, [rsp+0x80]
000071ff71bdd74b  vmovaps xmm9, [rsp+0x90]
000071ff71bdd754  vmovaps xmm10, [rsp+0xA0]
000071ff71bdd75d  vmovaps xmm11, [rsp+0xB0]
000071ff71bdd766  vmovaps xmm12, [rsp+0xC0]
000071ff71bdd76f  vmovaps xmm14, [rsp+0xD0]
000071ff71bdd778  vmovaps xmm15, [rsp+0xE0]
000071ff71bdd781  add rsp, 0xF0
000071ff71bdd788  pop r11
000071ff71bdd78a  pop r10
000071ff71bdd78c  pop r9
000071ff71bdd78e  pop r8
000071ff71bdd790  pop rsi
000071ff71bdd791  pop rdi
000071ff71bdd792  pop rdx
000071ff71bdd793  pop rcx
000071ff71bdd794  pop rax
000071ff71bdd795  add rsp, 0x08
000071ff71bdd799  jmp 0x000071FF71BD963C
000071ff71bdd79e  sub rsp, 0x08
000071ff71bdd7a2  push rax
000071ff71bdd7a3  push rcx
000071ff71bdd7a4  push rdx
000071ff71bdd7a5  push rdi
000071ff71bdd7a6  push rsi
000071ff71bdd7a7  push r8
000071ff71bdd7a9  push r9
000071ff71bdd7ab  push r10
000071ff71bdd7ad  push r11
000071ff71bdd7af  sub rsp, 0xF0
000071ff71bdd7b6  vmovaps [rsp], xmm0
000071ff71bdd7bb  vmovaps [rsp+0x10], xmm1
000071ff71bdd7c1  vmovaps [rsp+0x20], xmm2
000071ff71bdd7c7  vmovaps [rsp+0x30], xmm3
000071ff71bdd7cd  vmovaps [rsp+0x40], xmm4
000071ff71bdd7d3  vmovaps [rsp+0x50], xmm5
000071ff71bdd7d9  vmovaps [rsp+0x60], xmm6
000071ff71bdd7df  vmovaps [rsp+0x70], xmm7
000071ff71bdd7e5  vmovaps [rsp+0x80], xmm9
000071ff71bdd7ee  vmovaps [rsp+0x90], xmm10
000071ff71bdd7f7  vmovaps [rsp+0xA0], xmm11
000071ff71bdd800  vmovaps [rsp+0xB0], xmm12
000071ff71bdd809  vmovaps [rsp+0xC0], xmm13
000071ff71bdd812  vmovaps [rsp+0xD0], xmm14
000071ff71bdd81b  vmovaps [rsp+0xE0], xmm15
000071ff71bdd824  sub rsp, 0x30
000071ff71bdd828  movaps [rsp], xmm8
000071ff71bdd82d  movaps [rsp+0x10], xmm15
000071ff71bdd833  movaps [rsp+0x20], xmm9
000071ff71bdd839  lea rdi, [rsp]
000071ff71bdd83d  mov esi, 0x00
000071ff71bdd842  mov rax, 0x5E6872E10530
000071ff71bdd84c  call rax
000071ff71bdd84e  movaps xmm8, [rsp]
000071ff71bdd853  add rsp, 0x30
000071ff71bdd857  vmovaps xmm0, [rsp]
000071ff71bdd85c  vmovaps xmm1, [rsp+0x10]
000071ff71bdd862  vmovaps xmm2, [rsp+0x20]
000071ff71bdd868  vmovaps xmm3, [rsp+0x30]
000071ff71bdd86e  vmovaps xmm4, [rsp+0x40]
000071ff71bdd874  vmovaps xmm5, [rsp+0x50]
000071ff71bdd87a  vmovaps xmm6, [rsp+0x60]
000071ff71bdd880  vmovaps xmm7, [rsp+0x70]
000071ff71bdd886  vmovaps xmm9, [rsp+0x80]
000071ff71bdd88f  vmovaps xmm10, [rsp+0x90]
000071ff71bdd898  vmovaps xmm11, [rsp+0xA0]
000071ff71bdd8a1  vmovaps xmm12, [rsp+0xB0]
000071ff71bdd8aa  vmovaps xmm13, [rsp+0xC0]
000071ff71bdd8b3  vmovaps xmm14, [rsp+0xD0]
000071ff71bdd8bc  vmovaps xmm15, [rsp+0xE0]
000071ff71bdd8c5  add rsp, 0xF0
000071ff71bdd8cc  pop r11
000071ff71bdd8ce  pop r10
000071ff71bdd8d0  pop r9
000071ff71bdd8d2  pop r8
000071ff71bdd8d4  pop rsi
000071ff71bdd8d5  pop rdi
000071ff71bdd8d6  pop rdx
000071ff71bdd8d7  pop rcx
000071ff71bdd8d8  pop rax
000071ff71bdd8d9  add rsp, 0x08
000071ff71bdd8dd  jmp 0x000071FF71BD966A
000071ff71bdd8e2  sub rsp, 0x08
000071ff71bdd8e6  push rax
000071ff71bdd8e7  push rcx
000071ff71bdd8e8  push rdx
000071ff71bdd8e9  push rdi
000071ff71bdd8ea  push rsi
000071ff71bdd8eb  push r8
000071ff71bdd8ed  push r9
000071ff71bdd8ef  push r10
000071ff71bdd8f1  push r11
000071ff71bdd8f3  sub rsp, 0xF0
000071ff71bdd8fa  vmovaps [rsp], xmm0
000071ff71bdd8ff  vmovaps [rsp+0x10], xmm1
000071ff71bdd905  vmovaps [rsp+0x20], xmm2
000071ff71bdd90b  vmovaps [rsp+0x30], xmm3
000071ff71bdd911  vmovaps [rsp+0x40], xmm4
000071ff71bdd917  vmovaps [rsp+0x50], xmm5
000071ff71bdd91d  vmovaps [rsp+0x60], xmm6
000071ff71bdd923  vmovaps [rsp+0x70], xmm7
000071ff71bdd929  vmovaps [rsp+0x80], xmm8
000071ff71bdd932  vmovaps [rsp+0x90], xmm9
000071ff71bdd93b  vmovaps [rsp+0xA0], xmm10
000071ff71bdd944  vmovaps [rsp+0xB0], xmm11
000071ff71bdd94d  vmovaps [rsp+0xC0], xmm12
000071ff71bdd956  vmovaps [rsp+0xD0], xmm13
000071ff71bdd95f  vmovaps [rsp+0xE0], xmm14
000071ff71bdd968  sub rsp, 0x30
000071ff71bdd96c  movaps [rsp], xmm15
000071ff71bdd971  movaps [rsp+0x10], xmm11
000071ff71bdd977  movaps [rsp+0x20], xmm6
000071ff71bdd97c  lea rdi, [rsp]
000071ff71bdd980  mov esi, 0x00
000071ff71bdd985  mov rax, 0x5E6872E10530
000071ff71bdd98f  call rax
000071ff71bdd991  movaps xmm15, [rsp]
000071ff71bdd996  add rsp, 0x30
000071ff71bdd99a  vmovaps xmm0, [rsp]
000071ff71bdd99f  vmovaps xmm1, [rsp+0x10]
000071ff71bdd9a5  vmovaps xmm2, [rsp+0x20]
000071ff71bdd9ab  vmovaps xmm3, [rsp+0x30]
000071ff71bdd9b1  vmovaps xmm4, [rsp+0x40]
000071ff71bdd9b7  vmovaps xmm5, [rsp+0x50]
000071ff71bdd9bd  vmovaps xmm6, [rsp+0x60]
000071ff71bdd9c3  vmovaps xmm7, [rsp+0x70]
000071ff71bdd9c9  vmovaps xmm8, [rsp+0x80]
000071ff71bdd9d2  vmovaps xmm9, [rsp+0x90]
000071ff71bdd9db  vmovaps xmm10, [rsp+0xA0]
000071ff71bdd9e4  vmovaps xmm11, [rsp+0xB0]
000071ff71bdd9ed  vmovaps xmm12, [rsp+0xC0]
000071ff71bdd9f6  vmovaps xmm13, [rsp+0xD0]
000071ff71bdd9ff  vmovaps xmm14, [rsp+0xE0]
000071ff71bdda08  add rsp, 0xF0
000071ff71bdda0f  pop r11
000071ff71bdda11  pop r10
000071ff71bdda13  pop r9
000071ff71bdda15  pop r8
000071ff71bdda17  pop rsi
000071ff71bdda18  pop rdi
000071ff71bdda19  pop rdx
000071ff71bdda1a  pop rcx
000071ff71bdda1b  pop rax
000071ff71bdda1c  add rsp, 0x08
000071ff71bdda20  jmp 0x000071FF71BD9685
000071ff71bdda25  sub rsp, 0x08
000071ff71bdda29  push rax
000071ff71bdda2a  push rcx
000071ff71bdda2b  push rdx
000071ff71bdda2c  push rdi
000071ff71bdda2d  push rsi
000071ff71bdda2e  push r8
000071ff71bdda30  push r9
000071ff71bdda32  push r10
000071ff71bdda34  push r11
000071ff71bdda36  sub rsp, 0xF0
000071ff71bdda3d  vmovaps [rsp], xmm0
000071ff71bdda42  vmovaps [rsp+0x10], xmm1
000071ff71bdda48  vmovaps [rsp+0x20], xmm2
000071ff71bdda4e  vmovaps [rsp+0x30], xmm3
000071ff71bdda54  vmovaps [rsp+0x40], xmm4
000071ff71bdda5a  vmovaps [rsp+0x50], xmm5
000071ff71bdda60  vmovaps [rsp+0x60], xmm6
000071ff71bdda66  vmovaps [rsp+0x70], xmm8
000071ff71bdda6c  vmovaps [rsp+0x80], xmm9
000071ff71bdda75  vmovaps [rsp+0x90], xmm10
000071ff71bdda7e  vmovaps [rsp+0xA0], xmm11
000071ff71bdda87  vmovaps [rsp+0xB0], xmm12
000071ff71bdda90  vmovaps [rsp+0xC0], xmm13
000071ff71bdda99  vmovaps [rsp+0xD0], xmm14
000071ff71bddaa2  vmovaps [rsp+0xE0], xmm15
000071ff71bddaab  sub rsp, 0x30
000071ff71bddaaf  movaps [rsp], xmm7
000071ff71bddab3  movaps [rsp+0x10], xmm11
000071ff71bddab9  movaps [rsp+0x20], xmm9
000071ff71bddabf  lea rdi, [rsp]
000071ff71bddac3  mov esi, 0x00
000071ff71bddac8  mov rax, 0x5E6872E10530
000071ff71bddad2  call rax
000071ff71bddad4  movaps xmm7, [rsp]
000071ff71bddad8  add rsp, 0x30
000071ff71bddadc  vmovaps xmm0, [rsp]
000071ff71bddae1  vmovaps xmm1, [rsp+0x10]
000071ff71bddae7  vmovaps xmm2, [rsp+0x20]
000071ff71bddaed  vmovaps xmm3, [rsp+0x30]
000071ff71bddaf3  vmovaps xmm4, [rsp+0x40]
000071ff71bddaf9  vmovaps xmm5, [rsp+0x50]
000071ff71bddaff  vmovaps xmm6, [rsp+0x60]
000071ff71bddb05  vmovaps xmm8, [rsp+0x70]
000071ff71bddb0b  vmovaps xmm9, [rsp+0x80]
000071ff71bddb14  vmovaps xmm10, [rsp+0x90]
000071ff71bddb1d  vmovaps xmm11, [rsp+0xA0]
000071ff71bddb26  vmovaps xmm12, [rsp+0xB0]
000071ff71bddb2f  vmovaps xmm13, [rsp+0xC0]
000071ff71bddb38  vmovaps xmm14, [rsp+0xD0]
000071ff71bddb41  vmovaps xmm15, [rsp+0xE0]
000071ff71bddb4a  add rsp, 0xF0
000071ff71bddb51  pop r11
000071ff71bddb53  pop r10
000071ff71bddb55  pop r9
000071ff71bddb57  pop r8
000071ff71bddb59  pop rsi
000071ff71bddb5a  pop rdi
000071ff71bddb5b  pop rdx
000071ff71bddb5c  pop rcx
000071ff71bddb5d  pop rax
000071ff71bddb5e  add rsp, 0x08
000071ff71bddb62  jmp 0x000071FF71BD96B2
000071ff71bddb67  sub rsp, 0x08
000071ff71bddb6b  push rax
000071ff71bddb6c  push rcx
000071ff71bddb6d  push rdx
000071ff71bddb6e  push rdi
000071ff71bddb6f  push rsi
000071ff71bddb70  push r8
000071ff71bddb72  push r9
000071ff71bddb74  push r10
000071ff71bddb76  push r11
000071ff71bddb78  sub rsp, 0xF0
000071ff71bddb7f  vmovaps [rsp], xmm0
000071ff71bddb84  vmovaps [rsp+0x10], xmm1
000071ff71bddb8a  vmovaps [rsp+0x20], xmm2
000071ff71bddb90  vmovaps [rsp+0x30], xmm3
000071ff71bddb96  vmovaps [rsp+0x40], xmm4
000071ff71bddb9c  vmovaps [rsp+0x50], xmm5
000071ff71bddba2  vmovaps [rsp+0x60], xmm6
000071ff71bddba8  vmovaps [rsp+0x70], xmm7
000071ff71bddbae  vmovaps [rsp+0x80], xmm8
000071ff71bddbb7  vmovaps [rsp+0x90], xmm9
000071ff71bddbc0  vmovaps [rsp+0xA0], xmm10
000071ff71bddbc9  vmovaps [rsp+0xB0], xmm12
000071ff71bddbd2  vmovaps [rsp+0xC0], xmm13
000071ff71bddbdb  vmovaps [rsp+0xD0], xmm14
000071ff71bddbe4  vmovaps [rsp+0xE0], xmm15
000071ff71bddbed  sub rsp, 0x30
000071ff71bddbf1  movaps [rsp], xmm11
000071ff71bddbf6  movaps [rsp+0x10], xmm10
000071ff71bddbfc  movaps [rsp+0x20], xmm14
000071ff71bddc02  lea rdi, [rsp]
000071ff71bddc06  mov esi, 0x00
000071ff71bddc0b  mov rax, 0x5E6872E10530
000071ff71bddc15  call rax
000071ff71bddc17  movaps xmm11, [rsp]
000071ff71bddc1c  add rsp, 0x30
000071ff71bddc20  vmovaps xmm0, [rsp]
000071ff71bddc25  vmovaps xmm1, [rsp+0x10]
000071ff71bddc2b  vmovaps xmm2, [rsp+0x20]
000071ff71bddc31  vmovaps xmm3, [rsp+0x30]
000071ff71bddc37  vmovaps xmm4, [rsp+0x40]
000071ff71bddc3d  vmovaps xmm5, [rsp+0x50]
000071ff71bddc43  vmovaps xmm6, [rsp+0x60]
000071ff71bddc49  vmovaps xmm7, [rsp+0x70]
000071ff71bddc4f  vmovaps xmm8, [rsp+0x80]
000071ff71bddc58  vmovaps xmm9, [rsp+0x90]
000071ff71bddc61  vmovaps xmm10, [rsp+0xA0]
000071ff71bddc6a  vmovaps xmm12, [rsp+0xB0]
000071ff71bddc73  vmovaps xmm13, [rsp+0xC0]
000071ff71bddc7c  vmovaps xmm14, [rsp+0xD0]
000071ff71bddc85  vmovaps xmm15, [rsp+0xE0]
000071ff71bddc8e  add rsp, 0xF0
000071ff71bddc95  pop r11
000071ff71bddc97  pop r10
000071ff71bddc99  pop r9
000071ff71bddc9b  pop r8
000071ff71bddc9d  pop rsi
000071ff71bddc9e  pop rdi
000071ff71bddc9f  pop rdx
000071ff71bddca0  pop rcx
000071ff71bddca1  pop rax
000071ff71bddca2  add rsp, 0x08
000071ff71bddca6  jmp 0x000071FF71BD96CD
000071ff71bddcab  call 0x000071FF71AE45A0
000071ff71bddcb0  jmp 0x000071FF71BD96D7
000071ff71bddcb5  sub rsp, 0x08
000071ff71bddcb9  push rax
000071ff71bddcba  push rcx
000071ff71bddcbb  push rdx
000071ff71bddcbc  push rdi
000071ff71bddcbd  push rsi
000071ff71bddcbe  push r8
000071ff71bddcc0  push r9
000071ff71bddcc2  push r10
000071ff71bddcc4  push r11
000071ff71bddcc6  sub rsp, 0xF0
000071ff71bddccd  vmovaps [rsp], xmm0
000071ff71bddcd2  vmovaps [rsp+0x10], xmm1
000071ff71bddcd8  vmovaps [rsp+0x20], xmm2
000071ff71bddcde  vmovaps [rsp+0x30], xmm3
000071ff71bddce4  vmovaps [rsp+0x40], xmm4
000071ff71bddcea  vmovaps [rsp+0x50], xmm5
000071ff71bddcf0  vmovaps [rsp+0x60], xmm6
000071ff71bddcf6  vmovaps [rsp+0x70], xmm7
000071ff71bddcfc  vmovaps [rsp+0x80], xmm8
000071ff71bddd05  vmovaps [rsp+0x90], xmm9
000071ff71bddd0e  vmovaps [rsp+0xA0], xmm11
000071ff71bddd17  vmovaps [rsp+0xB0], xmm12
000071ff71bddd20  vmovaps [rsp+0xC0], xmm13
000071ff71bddd29  vmovaps [rsp+0xD0], xmm14
000071ff71bddd32  vmovaps [rsp+0xE0], xmm15
000071ff71bddd3b  sub rsp, 0x30
000071ff71bddd3f  movaps [rsp], xmm10
000071ff71bddd44  movaps [rsp+0x10], xmm1
000071ff71bddd49  movaps [rsp+0x20], xmm12
000071ff71bddd4f  lea rdi, [rsp]
000071ff71bddd53  mov esi, 0x00
000071ff71bddd58  mov rax, 0x5E6872E10530
000071ff71bddd62  call rax
000071ff71bddd64  movaps xmm10, [rsp]
000071ff71bddd69  add rsp, 0x30
000071ff71bddd6d  vmovaps xmm0, [rsp]
000071ff71bddd72  vmovaps xmm1, [rsp+0x10]
000071ff71bddd78  vmovaps xmm2, [rsp+0x20]
000071ff71bddd7e  vmovaps xmm3, [rsp+0x30]
000071ff71bddd84  vmovaps xmm4, [rsp+0x40]
000071ff71bddd8a  vmovaps xmm5, [rsp+0x50]
000071ff71bddd90  vmovaps xmm6, [rsp+0x60]
000071ff71bddd96  vmovaps xmm7, [rsp+0x70]
000071ff71bddd9c  vmovaps xmm8, [rsp+0x80]
000071ff71bddda5  vmovaps xmm9, [rsp+0x90]
000071ff71bdddae  vmovaps xmm11, [rsp+0xA0]
000071ff71bdddb7  vmovaps xmm12, [rsp+0xB0]
000071ff71bdddc0  vmovaps xmm13, [rsp+0xC0]
000071ff71bdddc9  vmovaps xmm14, [rsp+0xD0]
000071ff71bdddd2  vmovaps xmm15, [rsp+0xE0]
000071ff71bddddb  add rsp, 0xF0
000071ff71bddde2  pop r11
000071ff71bddde4  pop r10
000071ff71bddde6  pop r9
000071ff71bddde8  pop r8
000071ff71bdddea  pop rsi
000071ff71bdddeb  pop rdi
000071ff71bdddec  pop rdx
000071ff71bddded  pop rcx
000071ff71bdddee  pop rax
000071ff71bdddef  add rsp, 0x08
000071ff71bdddf3  jmp 0x000071FF71BD96FA
000071ff71bdddf8  sub rsp, 0x08
000071ff71bdddfc  push rax
000071ff71bdddfd  push rcx
000071ff71bdddfe  push rdx
000071ff71bdddff  push rdi
000071ff71bdde00  push rsi
000071ff71bdde01  push r8
000071ff71bdde03  push r9
000071ff71bdde05  push r10
000071ff71bdde07  push r11
000071ff71bdde09  sub rsp, 0xF0
000071ff71bdde10  vmovaps [rsp], xmm0
000071ff71bdde15  vmovaps [rsp+0x10], xmm1
000071ff71bdde1b  vmovaps [rsp+0x20], xmm2
000071ff71bdde21  vmovaps [rsp+0x30], xmm3
000071ff71bdde27  vmovaps [rsp+0x40], xmm4
000071ff71bdde2d  vmovaps [rsp+0x50], xmm5
000071ff71bdde33  vmovaps [rsp+0x60], xmm6
000071ff71bdde39  vmovaps [rsp+0x70], xmm7
000071ff71bdde3f  vmovaps [rsp+0x80], xmm8
000071ff71bdde48  vmovaps [rsp+0x90], xmm9
000071ff71bdde51  vmovaps [rsp+0xA0], xmm10
000071ff71bdde5a  vmovaps [rsp+0xB0], xmm11
000071ff71bdde63  vmovaps [rsp+0xC0], xmm13
000071ff71bdde6c  vmovaps [rsp+0xD0], xmm14
000071ff71bdde75  vmovaps [rsp+0xE0], xmm15
000071ff71bdde7e  sub rsp, 0x30
000071ff71bdde82  movaps [rsp], xmm12
000071ff71bdde87  movaps [rsp+0x10], xmm14
000071ff71bdde8d  movaps [rsp+0x20], xmm1
000071ff71bdde92  lea rdi, [rsp]
000071ff71bdde96  mov esi, 0x00
000071ff71bdde9b  mov rax, 0x5E6872E10530
000071ff71bddea5  call rax
000071ff71bddea7  movaps xmm12, [rsp]
000071ff71bddeac  add rsp, 0x30
000071ff71bddeb0  vmovaps xmm0, [rsp]
000071ff71bddeb5  vmovaps xmm1, [rsp+0x10]
000071ff71bddebb  vmovaps xmm2, [rsp+0x20]
000071ff71bddec1  vmovaps xmm3, [rsp+0x30]
000071ff71bddec7  vmovaps xmm4, [rsp+0x40]
000071ff71bddecd  vmovaps xmm5, [rsp+0x50]
000071ff71bdded3  vmovaps xmm6, [rsp+0x60]
000071ff71bdded9  vmovaps xmm7, [rsp+0x70]
000071ff71bddedf  vmovaps xmm8, [rsp+0x80]
000071ff71bddee8  vmovaps xmm9, [rsp+0x90]
000071ff71bddef1  vmovaps xmm10, [rsp+0xA0]
000071ff71bddefa  vmovaps xmm11, [rsp+0xB0]
000071ff71bddf03  vmovaps xmm13, [rsp+0xC0]
000071ff71bddf0c  vmovaps xmm14, [rsp+0xD0]
000071ff71bddf15  vmovaps xmm15, [rsp+0xE0]
000071ff71bddf1e  add rsp, 0xF0
000071ff71bddf25  pop r11
000071ff71bddf27  pop r10
000071ff71bddf29  pop r9
000071ff71bddf2b  pop r8
000071ff71bddf2d  pop rsi
000071ff71bddf2e  pop rdi
000071ff71bddf2f  pop rdx
000071ff71bddf30  pop rcx
000071ff71bddf31  pop rax
000071ff71bddf32  add rsp, 0x08
000071ff71bddf36  jmp 0x000071FF71BD9729
000071ff71bddf3b  sub rsp, 0x08
000071ff71bddf3f  push rax
000071ff71bddf40  push rcx
000071ff71bddf41  push rdx
000071ff71bddf42  push rdi
000071ff71bddf43  push rsi
000071ff71bddf44  push r8
000071ff71bddf46  push r9
000071ff71bddf48  push r10
000071ff71bddf4a  push r11
000071ff71bddf4c  sub rsp, 0xF0
000071ff71bddf53  vmovaps [rsp], xmm0
000071ff71bddf58  vmovaps [rsp+0x10], xmm1
000071ff71bddf5e  vmovaps [rsp+0x20], xmm2
000071ff71bddf64  vmovaps [rsp+0x30], xmm3
000071ff71bddf6a  vmovaps [rsp+0x40], xmm4
000071ff71bddf70  vmovaps [rsp+0x50], xmm5
000071ff71bddf76  vmovaps [rsp+0x60], xmm6
000071ff71bddf7c  vmovaps [rsp+0x70], xmm7
000071ff71bddf82  vmovaps [rsp+0x80], xmm8
000071ff71bddf8b  vmovaps [rsp+0x90], xmm9
000071ff71bddf94  vmovaps [rsp+0xA0], xmm10
000071ff71bddf9d  vmovaps [rsp+0xB0], xmm11
000071ff71bddfa6  vmovaps [rsp+0xC0], xmm12
000071ff71bddfaf  vmovaps [rsp+0xD0], xmm13
000071ff71bddfb8  vmovaps [rsp+0xE0], xmm15
000071ff71bddfc1  sub rsp, 0x30
000071ff71bddfc5  movaps [rsp], xmm14
000071ff71bddfca  movaps [rsp+0x10], xmm9
000071ff71bddfd0  movaps [rsp+0x20], xmm1
000071ff71bddfd5  lea rdi, [rsp]
000071ff71bddfd9  mov esi, 0x00
000071ff71bddfde  mov rax, 0x5E6872E10530
000071ff71bddfe8  call rax
000071ff71bddfea  movaps xmm14, [rsp]
000071ff71bddfef  add rsp, 0x30
000071ff71bddff3  vmovaps xmm0, [rsp]
000071ff71bddff8  vmovaps xmm1, [rsp+0x10]
000071ff71bddffe  vmovaps xmm2, [rsp+0x20]
000071ff71bde004  vmovaps xmm3, [rsp+0x30]
000071ff71bde00a  vmovaps xmm4, [rsp+0x40]
000071ff71bde010  vmovaps xmm5, [rsp+0x50]
000071ff71bde016  vmovaps xmm6, [rsp+0x60]
000071ff71bde01c  vmovaps xmm7, [rsp+0x70]
000071ff71bde022  vmovaps xmm8, [rsp+0x80]
000071ff71bde02b  vmovaps xmm9, [rsp+0x90]
000071ff71bde034  vmovaps xmm10, [rsp+0xA0]
000071ff71bde03d  vmovaps xmm11, [rsp+0xB0]
000071ff71bde046  vmovaps xmm12, [rsp+0xC0]
000071ff71bde04f  vmovaps xmm13, [rsp+0xD0]
000071ff71bde058  vmovaps xmm15, [rsp+0xE0]
000071ff71bde061  add rsp, 0xF0
000071ff71bde068  pop r11
000071ff71bde06a  pop r10
000071ff71bde06c  pop r9
000071ff71bde06e  pop r8
000071ff71bde070  pop rsi
000071ff71bde071  pop rdi
000071ff71bde072  pop rdx
000071ff71bde073  pop rcx
000071ff71bde074  pop rax
000071ff71bde075  add rsp, 0x08
000071ff71bde079  jmp 0x000071FF71BD9758
000071ff71bde07e  sub rsp, 0x08
000071ff71bde082  push rax
000071ff71bde083  push rcx
000071ff71bde084  push rdx
000071ff71bde085  push rdi
000071ff71bde086  push rsi
000071ff71bde087  push r8
000071ff71bde089  push r9
000071ff71bde08b  push r10
000071ff71bde08d  push r11
000071ff71bde08f  sub rsp, 0xF0
000071ff71bde096  vmovaps [rsp], xmm0
000071ff71bde09b  vmovaps [rsp+0x10], xmm2
000071ff71bde0a1  vmovaps [rsp+0x20], xmm3
000071ff71bde0a7  vmovaps [rsp+0x30], xmm4
000071ff71bde0ad  vmovaps [rsp+0x40], xmm5
000071ff71bde0b3  vmovaps [rsp+0x50], xmm6
000071ff71bde0b9  vmovaps [rsp+0x60], xmm7
000071ff71bde0bf  vmovaps [rsp+0x70], xmm8
000071ff71bde0c5  vmovaps [rsp+0x80], xmm9
000071ff71bde0ce  vmovaps [rsp+0x90], xmm10
000071ff71bde0d7  vmovaps [rsp+0xA0], xmm11
000071ff71bde0e0  vmovaps [rsp+0xB0], xmm12
000071ff71bde0e9  vmovaps [rsp+0xC0], xmm13
000071ff71bde0f2  vmovaps [rsp+0xD0], xmm14
000071ff71bde0fb  vmovaps [rsp+0xE0], xmm15
000071ff71bde104  sub rsp, 0x30
000071ff71bde108  movaps [rsp], xmm1
000071ff71bde10c  movaps [rsp+0x10], xmm13
000071ff71bde112  movaps [rsp+0x20], xmm8
000071ff71bde118  lea rdi, [rsp]
000071ff71bde11c  mov esi, 0x00
000071ff71bde121  mov rax, 0x5E6872E10530
000071ff71bde12b  call rax
000071ff71bde12d  movaps xmm1, [rsp]
000071ff71bde131  add rsp, 0x30
000071ff71bde135  vmovaps xmm0, [rsp]
000071ff71bde13a  vmovaps xmm2, [rsp+0x10]
000071ff71bde140  vmovaps xmm3, [rsp+0x20]
000071ff71bde146  vmovaps xmm4, [rsp+0x30]
000071ff71bde14c  vmovaps xmm5, [rsp+0x40]
000071ff71bde152  vmovaps xmm6, [rsp+0x50]
000071ff71bde158  vmovaps xmm7, [rsp+0x60]
000071ff71bde15e  vmovaps xmm8, [rsp+0x70]
000071ff71bde164  vmovaps xmm9, [rsp+0x80]
000071ff71bde16d  vmovaps xmm10, [rsp+0x90]
000071ff71bde176  vmovaps xmm11, [rsp+0xA0]
000071ff71bde17f  vmovaps xmm12, [rsp+0xB0]
000071ff71bde188  vmovaps xmm13, [rsp+0xC0]
000071ff71bde191  vmovaps xmm14, [rsp+0xD0]
000071ff71bde19a  vmovaps xmm15, [rsp+0xE0]
000071ff71bde1a3  add rsp, 0xF0
000071ff71bde1aa  pop r11
000071ff71bde1ac  pop r10
000071ff71bde1ae  pop r9
000071ff71bde1b0  pop r8
000071ff71bde1b2  pop rsi
000071ff71bde1b3  pop rdi
000071ff71bde1b4  pop rdx
000071ff71bde1b5  pop rcx
000071ff71bde1b6  pop rax
000071ff71bde1b7  add rsp, 0x08
000071ff71bde1bb  jmp 0x000071FF71BD977A
000071ff71bde1c0  call 0x000071FF71A0C260
000071ff71bde1c5  jmp 0x000071FF71BD9788
000071ff71bde1ca  call 0x000071FF71ADE950
000071ff71bde1cf  jmp 0x000071FF71BD9792
000071ff71bde1d4  sub rsp, 0x08
000071ff71bde1d8  push rax
000071ff71bde1d9  push rcx
000071ff71bde1da  push rdx
000071ff71bde1db  push rdi
000071ff71bde1dc  push rsi
000071ff71bde1dd  push r8
000071ff71bde1df  push r9
000071ff71bde1e1  push r10
000071ff71bde1e3  push r11
000071ff71bde1e5  sub rsp, 0xF0
000071ff71bde1ec  vmovaps [rsp], xmm0
000071ff71bde1f1  vmovaps [rsp+0x10], xmm1
000071ff71bde1f7  vmovaps [rsp+0x20], xmm2
000071ff71bde1fd  vmovaps [rsp+0x30], xmm3
000071ff71bde203  vmovaps [rsp+0x40], xmm4
000071ff71bde209  vmovaps [rsp+0x50], xmm5
000071ff71bde20f  vmovaps [rsp+0x60], xmm6
000071ff71bde215  vmovaps [rsp+0x70], xmm7
000071ff71bde21b  vmovaps [rsp+0x80], xmm9
000071ff71bde224  vmovaps [rsp+0x90], xmm10
000071ff71bde22d  vmovaps [rsp+0xA0], xmm11
000071ff71bde236  vmovaps [rsp+0xB0], xmm12
000071ff71bde23f  vmovaps [rsp+0xC0], xmm13
000071ff71bde248  vmovaps [rsp+0xD0], xmm14
000071ff71bde251  vmovaps [rsp+0xE0], xmm15
000071ff71bde25a  sub rsp, 0x30
000071ff71bde25e  movaps [rsp], xmm8
000071ff71bde263  movaps [rsp+0x10], xmm15
000071ff71bde269  movaps [rsp+0x20], xmm7
000071ff71bde26e  lea rdi, [rsp]
000071ff71bde272  mov esi, 0x00
000071ff71bde277  mov rax, 0x5E6872E10530
000071ff71bde281  call rax
000071ff71bde283  movaps xmm8, [rsp]
000071ff71bde288  add rsp, 0x30
000071ff71bde28c  vmovaps xmm0, [rsp]
000071ff71bde291  vmovaps xmm1, [rsp+0x10]
000071ff71bde297  vmovaps xmm2, [rsp+0x20]
000071ff71bde29d  vmovaps xmm3, [rsp+0x30]
000071ff71bde2a3  vmovaps xmm4, [rsp+0x40]
000071ff71bde2a9  vmovaps xmm5, [rsp+0x50]
000071ff71bde2af  vmovaps xmm6, [rsp+0x60]
000071ff71bde2b5  vmovaps xmm7, [rsp+0x70]
000071ff71bde2bb  vmovaps xmm9, [rsp+0x80]
000071ff71bde2c4  vmovaps xmm10, [rsp+0x90]
000071ff71bde2cd  vmovaps xmm11, [rsp+0xA0]
000071ff71bde2d6  vmovaps xmm12, [rsp+0xB0]
000071ff71bde2df  vmovaps xmm13, [rsp+0xC0]
000071ff71bde2e8  vmovaps xmm14, [rsp+0xD0]
000071ff71bde2f1  vmovaps xmm15, [rsp+0xE0]
000071ff71bde2fa  add rsp, 0xF0
000071ff71bde301  pop r11
000071ff71bde303  pop r10
000071ff71bde305  pop r9
000071ff71bde307  pop r8
000071ff71bde309  pop rsi
000071ff71bde30a  pop rdi
000071ff71bde30b  pop rdx
000071ff71bde30c  pop rcx
000071ff71bde30d  pop rax
000071ff71bde30e  add rsp, 0x08
000071ff71bde312  jmp 0x000071FF71BD97B4
000071ff71bde317  sub rsp, 0x08
000071ff71bde31b  push rax
000071ff71bde31c  push rcx
000071ff71bde31d  push rdx
000071ff71bde31e  push rdi
000071ff71bde31f  push rsi
000071ff71bde320  push r8
000071ff71bde322  push r9
000071ff71bde324  push r10
000071ff71bde326  push r11
000071ff71bde328  sub rsp, 0xF0
000071ff71bde32f  vmovaps [rsp], xmm0
000071ff71bde334  vmovaps [rsp+0x10], xmm1
000071ff71bde33a  vmovaps [rsp+0x20], xmm2
000071ff71bde340  vmovaps [rsp+0x30], xmm3
000071ff71bde346  vmovaps [rsp+0x40], xmm4
000071ff71bde34c  vmovaps [rsp+0x50], xmm5
000071ff71bde352  vmovaps [rsp+0x60], xmm6
000071ff71bde358  vmovaps [rsp+0x70], xmm8
000071ff71bde35e  vmovaps [rsp+0x80], xmm9
000071ff71bde367  vmovaps [rsp+0x90], xmm10
000071ff71bde370  vmovaps [rsp+0xA0], xmm11
000071ff71bde379  vmovaps [rsp+0xB0], xmm12
000071ff71bde382  vmovaps [rsp+0xC0], xmm13
000071ff71bde38b  vmovaps [rsp+0xD0], xmm14
000071ff71bde394  vmovaps [rsp+0xE0], xmm15
000071ff71bde39d  sub rsp, 0x30
000071ff71bde3a1  movaps [rsp], xmm7
000071ff71bde3a5  movaps [rsp+0x10], xmm9
000071ff71bde3ab  movaps [rsp+0x20], xmm15
000071ff71bde3b1  lea rdi, [rsp]
000071ff71bde3b5  mov esi, 0x00
000071ff71bde3ba  mov rax, 0x5E6872E10530
000071ff71bde3c4  call rax
000071ff71bde3c6  movaps xmm7, [rsp]
000071ff71bde3ca  add rsp, 0x30
000071ff71bde3ce  vmovaps xmm0, [rsp]
000071ff71bde3d3  vmovaps xmm1, [rsp+0x10]
000071ff71bde3d9  vmovaps xmm2, [rsp+0x20]
000071ff71bde3df  vmovaps xmm3, [rsp+0x30]
000071ff71bde3e5  vmovaps xmm4, [rsp+0x40]
000071ff71bde3eb  vmovaps xmm5, [rsp+0x50]
000071ff71bde3f1  vmovaps xmm6, [rsp+0x60]
000071ff71bde3f7  vmovaps xmm8, [rsp+0x70]
000071ff71bde3fd  vmovaps xmm9, [rsp+0x80]
000071ff71bde406  vmovaps xmm10, [rsp+0x90]
000071ff71bde40f  vmovaps xmm11, [rsp+0xA0]
000071ff71bde418  vmovaps xmm12, [rsp+0xB0]
000071ff71bde421  vmovaps xmm13, [rsp+0xC0]
000071ff71bde42a  vmovaps xmm14, [rsp+0xD0]
000071ff71bde433  vmovaps xmm15, [rsp+0xE0]
000071ff71bde43c  add rsp, 0xF0
000071ff71bde443  pop r11
000071ff71bde445  pop r10
000071ff71bde447  pop r9
000071ff71bde449  pop r8
000071ff71bde44b  pop rsi
000071ff71bde44c  pop rdi
000071ff71bde44d  pop rdx
000071ff71bde44e  pop rcx
000071ff71bde44f  pop rax
000071ff71bde450  add rsp, 0x08
000071ff71bde454  jmp 0x000071FF71BD97E1
000071ff71bde459  sub rsp, 0x08
000071ff71bde45d  push rax
000071ff71bde45e  push rcx
000071ff71bde45f  push rdx
000071ff71bde460  push rdi
000071ff71bde461  push rsi
000071ff71bde462  push r8
000071ff71bde464  push r9
000071ff71bde466  push r10
000071ff71bde468  push r11
000071ff71bde46a  sub rsp, 0xF0
000071ff71bde471  vmovaps [rsp], xmm0
000071ff71bde476  vmovaps [rsp+0x10], xmm1
000071ff71bde47c  vmovaps [rsp+0x20], xmm2
000071ff71bde482  vmovaps [rsp+0x30], xmm3
000071ff71bde488  vmovaps [rsp+0x40], xmm4
000071ff71bde48e  vmovaps [rsp+0x50], xmm5
000071ff71bde494  vmovaps [rsp+0x60], xmm6
000071ff71bde49a  vmovaps [rsp+0x70], xmm7
000071ff71bde4a0  vmovaps [rsp+0x80], xmm8
000071ff71bde4a9  vmovaps [rsp+0x90], xmm10
000071ff71bde4b2  vmovaps [rsp+0xA0], xmm11
000071ff71bde4bb  vmovaps [rsp+0xB0], xmm12
000071ff71bde4c4  vmovaps [rsp+0xC0], xmm13
000071ff71bde4cd  vmovaps [rsp+0xD0], xmm14
000071ff71bde4d6  vmovaps [rsp+0xE0], xmm15
000071ff71bde4df  sub rsp, 0x30
000071ff71bde4e3  movaps [rsp], xmm9
000071ff71bde4e8  movaps [rsp+0x10], xmm13
000071ff71bde4ee  movaps [rsp+0x20], xmm15
000071ff71bde4f4  lea rdi, [rsp]
000071ff71bde4f8  mov esi, 0x00
000071ff71bde4fd  mov rax, 0x5E6872E10530
000071ff71bde507  call rax
000071ff71bde509  movaps xmm9, [rsp]
000071ff71bde50e  add rsp, 0x30
000071ff71bde512  vmovaps xmm0, [rsp]
000071ff71bde517  vmovaps xmm1, [rsp+0x10]
000071ff71bde51d  vmovaps xmm2, [rsp+0x20]
000071ff71bde523  vmovaps xmm3, [rsp+0x30]
000071ff71bde529  vmovaps xmm4, [rsp+0x40]
000071ff71bde52f  vmovaps xmm5, [rsp+0x50]
000071ff71bde535  vmovaps xmm6, [rsp+0x60]
000071ff71bde53b  vmovaps xmm7, [rsp+0x70]
000071ff71bde541  vmovaps xmm8, [rsp+0x80]
000071ff71bde54a  vmovaps xmm10, [rsp+0x90]
000071ff71bde553  vmovaps xmm11, [rsp+0xA0]
000071ff71bde55c  vmovaps xmm12, [rsp+0xB0]
000071ff71bde565  vmovaps xmm13, [rsp+0xC0]
000071ff71bde56e  vmovaps xmm14, [rsp+0xD0]
000071ff71bde577  vmovaps xmm15, [rsp+0xE0]
000071ff71bde580  add rsp, 0xF0
000071ff71bde587  pop r11
000071ff71bde589  pop r10
000071ff71bde58b  pop r9
000071ff71bde58d  pop r8
000071ff71bde58f  pop rsi
000071ff71bde590  pop rdi
000071ff71bde591  pop rdx
000071ff71bde592  pop rcx
000071ff71bde593  pop rax
000071ff71bde594  add rsp, 0x08
000071ff71bde598  jmp 0x000071FF71BD980F
000071ff71bde59d  sub rsp, 0x08
000071ff71bde5a1  push rax
000071ff71bde5a2  push rcx
000071ff71bde5a3  push rdx
000071ff71bde5a4  push rdi
000071ff71bde5a5  push rsi
000071ff71bde5a6  push r8
000071ff71bde5a8  push r9
000071ff71bde5aa  push r10
000071ff71bde5ac  push r11
000071ff71bde5ae  sub rsp, 0xF0
000071ff71bde5b5  vmovaps [rsp], xmm0
000071ff71bde5ba  vmovaps [rsp+0x10], xmm1
000071ff71bde5c0  vmovaps [rsp+0x20], xmm2
000071ff71bde5c6  vmovaps [rsp+0x30], xmm3
000071ff71bde5cc  vmovaps [rsp+0x40], xmm4
000071ff71bde5d2  vmovaps [rsp+0x50], xmm5
000071ff71bde5d8  vmovaps [rsp+0x60], xmm6
000071ff71bde5de  vmovaps [rsp+0x70], xmm7
000071ff71bde5e4  vmovaps [rsp+0x80], xmm8
000071ff71bde5ed  vmovaps [rsp+0x90], xmm9
000071ff71bde5f6  vmovaps [rsp+0xA0], xmm10
000071ff71bde5ff  vmovaps [rsp+0xB0], xmm11
000071ff71bde608  vmovaps [rsp+0xC0], xmm12
000071ff71bde611  vmovaps [rsp+0xD0], xmm13
000071ff71bde61a  vmovaps [rsp+0xE0], xmm14
000071ff71bde623  sub rsp, 0x30
000071ff71bde627  movaps [rsp], xmm15
000071ff71bde62c  movaps [rsp+0x10], xmm11
000071ff71bde632  movaps [rsp+0x20], xmm12
000071ff71bde638  lea rdi, [rsp]
000071ff71bde63c  mov esi, 0x00
000071ff71bde641  mov rax, 0x5E6872E10530
000071ff71bde64b  call rax
000071ff71bde64d  movaps xmm15, [rsp]
000071ff71bde652  add rsp, 0x30
000071ff71bde656  vmovaps xmm0, [rsp]
000071ff71bde65b  vmovaps xmm1, [rsp+0x10]
000071ff71bde661  vmovaps xmm2, [rsp+0x20]
000071ff71bde667  vmovaps xmm3, [rsp+0x30]
000071ff71bde66d  vmovaps xmm4, [rsp+0x40]
000071ff71bde673  vmovaps xmm5, [rsp+0x50]
000071ff71bde679  vmovaps xmm6, [rsp+0x60]
000071ff71bde67f  vmovaps xmm7, [rsp+0x70]
000071ff71bde685  vmovaps xmm8, [rsp+0x80]
000071ff71bde68e  vmovaps xmm9, [rsp+0x90]
000071ff71bde697  vmovaps xmm10, [rsp+0xA0]
000071ff71bde6a0  vmovaps xmm11, [rsp+0xB0]
000071ff71bde6a9  vmovaps xmm12, [rsp+0xC0]
000071ff71bde6b2  vmovaps xmm13, [rsp+0xD0]
000071ff71bde6bb  vmovaps xmm14, [rsp+0xE0]
000071ff71bde6c4  add rsp, 0xF0
000071ff71bde6cb  pop r11
000071ff71bde6cd  pop r10
000071ff71bde6cf  pop r9
000071ff71bde6d1  pop r8
000071ff71bde6d3  pop rsi
000071ff71bde6d4  pop rdi
000071ff71bde6d5  pop rdx
000071ff71bde6d6  pop rcx
000071ff71bde6d7  pop rax
000071ff71bde6d8  add rsp, 0x08
000071ff71bde6dc  jmp 0x000071FF71BD982A
000071ff71bde6e1  sub rsp, 0x08
000071ff71bde6e5  push rax
000071ff71bde6e6  push rcx
000071ff71bde6e7  push rdx
000071ff71bde6e8  push rdi
000071ff71bde6e9  push rsi
000071ff71bde6ea  push r8
000071ff71bde6ec  push r9
000071ff71bde6ee  push r10
000071ff71bde6f0  push r11
000071ff71bde6f2  sub rsp, 0xF0
000071ff71bde6f9  vmovaps [rsp], xmm0
000071ff71bde6fe  vmovaps [rsp+0x10], xmm1
000071ff71bde704  vmovaps [rsp+0x20], xmm2
000071ff71bde70a  vmovaps [rsp+0x30], xmm3
000071ff71bde710  vmovaps [rsp+0x40], xmm4
000071ff71bde716  vmovaps [rsp+0x50], xmm5
000071ff71bde71c  vmovaps [rsp+0x60], xmm6
000071ff71bde722  vmovaps [rsp+0x70], xmm7
000071ff71bde728  vmovaps [rsp+0x80], xmm8
000071ff71bde731  vmovaps [rsp+0x90], xmm9
000071ff71bde73a  vmovaps [rsp+0xA0], xmm10
000071ff71bde743  vmovaps [rsp+0xB0], xmm11
000071ff71bde74c  vmovaps [rsp+0xC0], xmm12
000071ff71bde755  vmovaps [rsp+0xD0], xmm14
000071ff71bde75e  vmovaps [rsp+0xE0], xmm15
000071ff71bde767  sub rsp, 0x30
000071ff71bde76b  movaps [rsp], xmm13
000071ff71bde770  movaps [rsp+0x10], xmm10
000071ff71bde776  movaps [rsp+0x20], xmm14
000071ff71bde77c  lea rdi, [rsp]
000071ff71bde780  mov esi, 0x00
000071ff71bde785  mov rax, 0x5E6872E10530
000071ff71bde78f  call rax
000071ff71bde791  movaps xmm13, [rsp]
000071ff71bde796  add rsp, 0x30
000071ff71bde79a  vmovaps xmm0, [rsp]
000071ff71bde79f  vmovaps xmm1, [rsp+0x10]
000071ff71bde7a5  vmovaps xmm2, [rsp+0x20]
000071ff71bde7ab  vmovaps xmm3, [rsp+0x30]
000071ff71bde7b1  vmovaps xmm4, [rsp+0x40]
000071ff71bde7b7  vmovaps xmm5, [rsp+0x50]
000071ff71bde7bd  vmovaps xmm6, [rsp+0x60]
000071ff71bde7c3  vmovaps xmm7, [rsp+0x70]
000071ff71bde7c9  vmovaps xmm8, [rsp+0x80]
000071ff71bde7d2  vmovaps xmm9, [rsp+0x90]
000071ff71bde7db  vmovaps xmm10, [rsp+0xA0]
000071ff71bde7e4  vmovaps xmm11, [rsp+0xB0]
000071ff71bde7ed  vmovaps xmm12, [rsp+0xC0]
000071ff71bde7f6  vmovaps xmm14, [rsp+0xD0]
000071ff71bde7ff  vmovaps xmm15, [rsp+0xE0]
000071ff71bde808  add rsp, 0xF0
000071ff71bde80f  pop r11
000071ff71bde811  pop r10
000071ff71bde813  pop r9
000071ff71bde815  pop r8
000071ff71bde817  pop rsi
000071ff71bde818  pop rdi
000071ff71bde819  pop rdx
000071ff71bde81a  pop rcx
000071ff71bde81b  pop rax
000071ff71bde81c  add rsp, 0x08
000071ff71bde820  jmp 0x000071FF71BD984D
000071ff71bde825  sub rsp, 0x08
000071ff71bde829  push rax
000071ff71bde82a  push rcx
000071ff71bde82b  push rdx
000071ff71bde82c  push rdi
000071ff71bde82d  push rsi
000071ff71bde82e  push r8
000071ff71bde830  push r9
000071ff71bde832  push r10
000071ff71bde834  push r11
000071ff71bde836  sub rsp, 0xF0
000071ff71bde83d  vmovaps [rsp], xmm0
000071ff71bde842  vmovaps [rsp+0x10], xmm1
000071ff71bde848  vmovaps [rsp+0x20], xmm2
000071ff71bde84e  vmovaps [rsp+0x30], xmm3
000071ff71bde854  vmovaps [rsp+0x40], xmm4
000071ff71bde85a  vmovaps [rsp+0x50], xmm5
000071ff71bde860  vmovaps [rsp+0x60], xmm6
000071ff71bde866  vmovaps [rsp+0x70], xmm7
000071ff71bde86c  vmovaps [rsp+0x80], xmm8
000071ff71bde875  vmovaps [rsp+0x90], xmm9
000071ff71bde87e  vmovaps [rsp+0xA0], xmm10
000071ff71bde887  vmovaps [rsp+0xB0], xmm11
000071ff71bde890  vmovaps [rsp+0xC0], xmm12
000071ff71bde899  vmovaps [rsp+0xD0], xmm13
000071ff71bde8a2  vmovaps [rsp+0xE0], xmm15
000071ff71bde8ab  sub rsp, 0x30
000071ff71bde8af  movaps [rsp], xmm14
000071ff71bde8b4  movaps [rsp+0x10], xmm1
000071ff71bde8b9  movaps [rsp+0x20], xmm7
000071ff71bde8be  lea rdi, [rsp]
000071ff71bde8c2  mov esi, 0x00
000071ff71bde8c7  mov rax, 0x5E6872E10530
000071ff71bde8d1  call rax
000071ff71bde8d3  movaps xmm14, [rsp]
000071ff71bde8d8  add rsp, 0x30
000071ff71bde8dc  vmovaps xmm0, [rsp]
000071ff71bde8e1  vmovaps xmm1, [rsp+0x10]
000071ff71bde8e7  vmovaps xmm2, [rsp+0x20]
000071ff71bde8ed  vmovaps xmm3, [rsp+0x30]
000071ff71bde8f3  vmovaps xmm4, [rsp+0x40]
000071ff71bde8f9  vmovaps xmm5, [rsp+0x50]
000071ff71bde8ff  vmovaps xmm6, [rsp+0x60]
000071ff71bde905  vmovaps xmm7, [rsp+0x70]
000071ff71bde90b  vmovaps xmm8, [rsp+0x80]
000071ff71bde914  vmovaps xmm9, [rsp+0x90]
000071ff71bde91d  vmovaps xmm10, [rsp+0xA0]
000071ff71bde926  vmovaps xmm11, [rsp+0xB0]
000071ff71bde92f  vmovaps xmm12, [rsp+0xC0]
000071ff71bde938  vmovaps xmm13, [rsp+0xD0]
000071ff71bde941  vmovaps xmm15, [rsp+0xE0]
000071ff71bde94a  add rsp, 0xF0
000071ff71bde951  pop r11
000071ff71bde953  pop r10
000071ff71bde955  pop r9
000071ff71bde957  pop r8
000071ff71bde959  pop rsi
000071ff71bde95a  pop rdi
000071ff71bde95b  pop rdx
000071ff71bde95c  pop rcx
000071ff71bde95d  pop rax
000071ff71bde95e  add rsp, 0x08
000071ff71bde962  jmp 0x000071FF71BD9870
000071ff71bde967  sub rsp, 0x08
000071ff71bde96b  push rax
000071ff71bde96c  push rcx
000071ff71bde96d  push rdx
000071ff71bde96e  push rdi
000071ff71bde96f  push rsi
000071ff71bde970  push r8
000071ff71bde972  push r9
000071ff71bde974  push r10
000071ff71bde976  push r11
000071ff71bde978  sub rsp, 0xF0
000071ff71bde97f  vmovaps [rsp], xmm0
000071ff71bde984  vmovaps [rsp+0x10], xmm2
000071ff71bde98a  vmovaps [rsp+0x20], xmm3
000071ff71bde990  vmovaps [rsp+0x30], xmm4
000071ff71bde996  vmovaps [rsp+0x40], xmm5
000071ff71bde99c  vmovaps [rsp+0x50], xmm6
000071ff71bde9a2  vmovaps [rsp+0x60], xmm7
000071ff71bde9a8  vmovaps [rsp+0x70], xmm8
000071ff71bde9ae  vmovaps [rsp+0x80], xmm9
000071ff71bde9b7  vmovaps [rsp+0x90], xmm10
000071ff71bde9c0  vmovaps [rsp+0xA0], xmm11
000071ff71bde9c9  vmovaps [rsp+0xB0], xmm12
000071ff71bde9d2  vmovaps [rsp+0xC0], xmm13
000071ff71bde9db  vmovaps [rsp+0xD0], xmm14
000071ff71bde9e4  vmovaps [rsp+0xE0], xmm15
000071ff71bde9ed  sub rsp, 0x30
000071ff71bde9f1  movaps [rsp], xmm1
000071ff71bde9f5  movaps [rsp+0x10], xmm8
000071ff71bde9fb  movaps [rsp+0x20], xmm9
000071ff71bdea01  lea rdi, [rsp]
000071ff71bdea05  mov esi, 0x00
000071ff71bdea0a  mov rax, 0x5E6872E10530
000071ff71bdea14  call rax
000071ff71bdea16  movaps xmm1, [rsp]
000071ff71bdea1a  add rsp, 0x30
000071ff71bdea1e  vmovaps xmm0, [rsp]
000071ff71bdea23  vmovaps xmm2, [rsp+0x10]
000071ff71bdea29  vmovaps xmm3, [rsp+0x20]
000071ff71bdea2f  vmovaps xmm4, [rsp+0x30]
000071ff71bdea35  vmovaps xmm5, [rsp+0x40]
000071ff71bdea3b  vmovaps xmm6, [rsp+0x50]
000071ff71bdea41  vmovaps xmm7, [rsp+0x60]
000071ff71bdea47  vmovaps xmm8, [rsp+0x70]
000071ff71bdea4d  vmovaps xmm9, [rsp+0x80]
000071ff71bdea56  vmovaps xmm10, [rsp+0x90]
000071ff71bdea5f  vmovaps xmm11, [rsp+0xA0]
000071ff71bdea68  vmovaps xmm12, [rsp+0xB0]
000071ff71bdea71  vmovaps xmm13, [rsp+0xC0]
000071ff71bdea7a  vmovaps xmm14, [rsp+0xD0]
000071ff71bdea83  vmovaps xmm15, [rsp+0xE0]
000071ff71bdea8c  add rsp, 0xF0
000071ff71bdea93  pop r11
000071ff71bdea95  pop r10
000071ff71bdea97  pop r9
000071ff71bdea99  pop r8
000071ff71bdea9b  pop rsi
000071ff71bdea9c  pop rdi
000071ff71bdea9d  pop rdx
000071ff71bdea9e  pop rcx
000071ff71bdea9f  pop rax
000071ff71bdeaa0  add rsp, 0x08
000071ff71bdeaa4  jmp 0x000071FF71BD9892
000071ff71bdeaa9  call 0x000071FF71AB3E40
000071ff71bdeaae  jmp 0x000071FF71BD98A0
000071ff71bdeab3  call 0x000071FF71A0C380
000071ff71bdeab8  jmp 0x000071FF71BD98AA
000071ff71bdeabd  call 0x000071FF71A0D600
000071ff71bdeac2  jmp 0x000071FF71BD98B4
000071ff71bdeac7  call 0x000071FF719FF540
000071ff71bdeacc  jmp 0x000071FF71BD98BE
000071ff71bdead1  int3
000071ff71bdead2  nop [rax+rax*1], ax
000071ff71bdeadb  nop [rax+rax*1], eax
000071ff71bdeae0  mov eax, [r15+0x48]
000071ff71bdeae4  lea r14d, [eax+0x01]
000071ff71bdeae9  mov [rsp+0x10], r14d
000071ff71bdeaee  mov r14d, r14d
000071ff71bdeaf1  mov [r15+0x48], r14
000071ff71bdeaf5  xor eax, eax
000071ff71bdeaf7  mov r14d, [rsp+0x10]
000071ff71bdeafc  cmp r14d, 0x1F4
000071ff71bdeb03  cmc
000071ff71bdeb04  lahf
000071ff71bdeb05  seto al
000071ff71bdeb08  mov [r15+0x108], eax
000071ff71bdeb0f  mov eax, [r15+0x108]
000071ff71bdeb16  sahf
000071ff71bdeb17  jnz 0x000071FF71BDEB49
000071ff71bdeb19  cmp dword ptr [r15+0x318], 0x00
000071ff71bdeb21  jz 0x000071FF71BE4C90
000071ff71bdeb27  nop [rax+rax*1], ax
000071ff71bdeb30  nop [rax+rax*1], eax
000071ff71bdeb38  mov eax, 0x4106DC
000071ff71bdeb3d  mov [r15+0x100], rax
000071ff71bdeb44  jmp 0x000071FF719FE110
000071ff71bdeb49  cmp dword ptr [r15+0x318], 0x00
000071ff71bdeb51  jz 0x000071FF71BDEB80
000071ff71bdeb57  nop [rax+rax*1], ax
000071ff71bdeb60  nop [rax+rax*1], eax
000071ff71bdeb68  mov eax, 0x410500
000071ff71bdeb6d  mov [r15+0x100], rax
000071ff71bdeb74  jmp 0x000071FF719FE110
000071ff71bdeb79  int3
000071ff71bdeb7a  int3
000071ff71bdeb7b  nop [rax+rax*1], eax
000071ff71bdeb80  mov rax, [r15+0x40]
000071ff71bdeb84  movaps xmm1, [r15+0x1D0]
000071ff71bdeb8c  vmovaps [rsp+0x10], xmm1
000071ff71bdeb92  vmovaps xmm15, [rsp+0x10]
000071ff71bdeb98  por xmm1, xmm15
000071ff71bdeb9d  movaps xmm14, [r15+0x1A0]
000071ff71bdeba5  vmovaps [rsp+0x10], xmm14
000071ff71bdebab  vmovaps xmm13, [rsp+0x10]
000071ff71bdebb1  por xmm14, xmm13
000071ff71bdebb6  lea r14, [rax+0x30]
000071ff71bdebba  mov r12, [r13+r14*1]
000071ff71bdebbf  lea r14, [rax+0x38]
000071ff71bdebc3  mov r11, [r13+r14*1]
000071ff71bdebc8  movq xmm13, r12
000071ff71bdebcd  movq xmm12, r11
000071ff71bdebd2  movq xmm13, xmm13
000071ff71bdebd7  vmovaps [rsp+0x10], xmm13
000071ff71bdebdd  movq xmm13, xmm13
000071ff71bdebe2  movaps [r15+0x130], xmm13
000071ff71bdebea  movq xmm12, xmm12
000071ff71bdebef  vmovaps [rsp+0x20], xmm12
000071ff71bdebf5  movq xmm12, xmm12
000071ff71bdebfa  movaps [r15+0x280], xmm12
000071ff71bdec02  movaps xmm13, [r15+0x270]
000071ff71bdec0a  vmovaps [rsp+0x30], xmm13
000071ff71bdec10  vmovaps xmm12, [rsp+0x30]
000071ff71bdec16  por xmm13, xmm12
000071ff71bdec1b  lea r14, [rax+0x20]
000071ff71bdec1f  mov r12, [r13+r14*1]
000071ff71bdec24  lea r14, [rax+0x28]
000071ff71bdec28  mov r11, [r13+r14*1]
000071ff71bdec2d  movq xmm12, r12
000071ff71bdec32  movq xmm11, r11
000071ff71bdec37  movq xmm12, xmm12
000071ff71bdec3c  vmovaps [rsp+0x30], xmm12
000071ff71bdec42  movq xmm12, xmm12
000071ff71bdec47  movaps [r15+0x150], xmm12
000071ff71bdec4f  movq xmm11, xmm11
000071ff71bdec54  vmovaps [rsp+0x40], xmm11
000071ff71bdec5a  movq xmm11, xmm11
000071ff71bdec5f  movaps [r15+0x140], xmm11
000071ff71bdec67  lea r14, [rax+0x10]
000071ff71bdec6b  mov r12, [r13+r14*1]
000071ff71bdec70  lea r14, [rax+0x18]
000071ff71bdec74  mov r11, [r13+r14*1]
000071ff71bdec79  movq xmm12, r12
000071ff71bdec7e  movq xmm11, r11
000071ff71bdec83  movq xmm12, xmm12
000071ff71bdec88  vmovaps [rsp+0x50], xmm12
000071ff71bdec8e  movq xmm12, xmm12
000071ff71bdec93  movaps [r15+0x170], xmm12
000071ff71bdec9b  movq xmm11, xmm11
000071ff71bdeca0  vmovaps [rsp+0x60], xmm11
000071ff71bdeca6  movq xmm11, xmm11
000071ff71bdecab  movaps [r15+0x160], xmm11
000071ff71bdecb3  mov r14, [r13+rax*1]
000071ff71bdecb8  vmovq xmm12, r14
000071ff71bdecbd  vpbroadcastq xmm12, xmm12
000071ff71bdecc2  lea r14, [rax+0x08]
000071ff71bdecc6  mov rax, [r13+r14*1]
000071ff71bdeccb  movq xmm11, rax
000071ff71bdecd0  movaps [r15+0x230], xmm11
000071ff71bdecd8  mov rax, [r15+0xF8]
000071ff71bdecdf  lea r14, [rax+0x50]
000071ff71bdece3  movups xmm11, [r13+r14*1]
000071ff71bdece9  lea r14, [rax+0x60]
000071ff71bdeced  movups xmm10, [r13+r14*1]
000071ff71bdecf3  lea r14, [rax+0x30]
000071ff71bdecf7  movups xmm9, [r13+r14*1]
000071ff71bdecfd  mov r14, [r15+0x50]
000071ff71bded01  mov [r15+0x60], r14
000071ff71bded05  mov qword ptr [r15+0x58], 0x40
000071ff71bded0d  movaps xmm8, xmm12
000071ff71bded11  mulpd xmm8, xmm15
000071ff71bded16  vcmppd xmm7, xmm8, xmm8, 0x03
000071ff71bded1c  ptest xmm7, xmm7
000071ff71bded21  jnz 0x000071FF71BDFB4A
000071ff71bded27  movq xmm15, qword ptr [r15+0x230]
000071ff71bded30  vmovaps [rsp+0x70], xmm15
000071ff71bded36  vpermilpd xmm15, xmm15, 0x00
000071ff71bded3c  movaps xmm7, xmm9
000071ff71bded40  mulpd xmm7, xmm15
000071ff71bded45  vcmppd xmm6, xmm7, xmm7, 0x03
000071ff71bded4a  ptest xmm6, xmm6
000071ff71bded4f  jnz 0x000071FF71BDFC8E
000071ff71bded55  vxorps xmm15, xmm15, xmm15
000071ff71bded5a  vpbroadcastq xmm15, xmm15
000071ff71bded5f  movaps xmm9, xmm12
000071ff71bded63  mulpd xmm9, xmm10
000071ff71bded68  vcmppd xmm6, xmm9, xmm9, 0x03
000071ff71bded6e  ptest xmm6, xmm6
000071ff71bded73  jnz 0x000071FF71BDFDD0
000071ff71bded79  movaps xmm10, xmm12
000071ff71bded7d  mulpd xmm10, xmm11
000071ff71bded82  vcmppd xmm6, xmm10, xmm10, 0x03
000071ff71bded88  ptest xmm6, xmm6
000071ff71bded8d  jnz 0x000071FF71BDFF14
000071ff71bded93  movaps xmm11, [r15+0x1F0]
000071ff71bded9b  movaps xmm6, xmm12
000071ff71bded9f  mulpd xmm6, xmm11
000071ff71bdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
000071ff71bdeda9  ptest xmm5, xmm5
000071ff71bdedae  jnz 0x000071FF71BE0058
000071ff71bdedb4  movaps xmm12, [r15+0x2A0]
000071ff71bdedbc  vmovaps [rsp+0x80], xmm12
000071ff71bdedc5  vmovaps xmm11, [rsp+0x80]
000071ff71bdedce  por xmm12, xmm11
000071ff71bdedd3  movaps xmm11, [r15+0x250]
000071ff71bdeddb  vmovaps [rsp+0x80], xmm11
000071ff71bdede4  vmovaps xmm5, [rsp+0x80]
000071ff71bdeded  por xmm11, xmm5
000071ff71bdedf2  vmovaps xmm4, [rsp+0x70]
000071ff71bdedf8  vpermilpd xmm4, xmm4, 0x00
000071ff71bdedfe  movaps xmm3, xmm5
000071ff71bdee01  mulpd xmm3, xmm4
000071ff71bdee05  vcmppd xmm2, xmm3, xmm3, 0x03
000071ff71bdee0a  ptest xmm2, xmm2
000071ff71bdee0f  jnz 0x000071FF71BE019A
000071ff71bdee15  mov [rsp+0x80], rax
000071ff71bdee1d  xor eax, eax
000071ff71bdee1f  mov r12d, 0x40
000071ff71bdee25  mov r11d, 0x200
000071ff71bdee2b  cmp r12, r11
000071ff71bdee2e  cmc
000071ff71bdee2f  lahf
000071ff71bdee30  seto al
000071ff71bdee33  mov [r15+0x108], eax
000071ff71bdee3a  movaps xmm5, xmm8
000071ff71bdee3e  addpd xmm5, xmm15
000071ff71bdee43  vcmppd xmm4, xmm5, xmm5, 0x03
000071ff71bdee48  ptest xmm4, xmm4
000071ff71bdee4d  jnz 0x000071FF71BE02DA
000071ff71bdee53  movaps xmm8, [r15+0x1B0]
000071ff71bdee5b  movaps xmm4, xmm9
000071ff71bdee5f  addpd xmm4, xmm8
000071ff71bdee64  vcmppd xmm2, xmm4, xmm4, 0x03
000071ff71bdee69  ptest xmm2, xmm2
000071ff71bdee6e  jnz 0x000071FF71BE041C
000071ff71bdee74  movaps xmm9, xmm10
000071ff71bdee78  addpd xmm9, xmm8
000071ff71bdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000071ff71bdee83  ptest xmm2, xmm2
000071ff71bdee88  jnz 0x000071FF71BE055E
000071ff71bdee8e  movaps xmm10, [r15+0x2F0]
000071ff71bdee96  vmovaps [rsp+0x90], xmm10
000071ff71bdee9f  vmovaps xmm8, [rsp+0x90]
000071ff71bdeea8  por xmm10, xmm8
000071ff71bdeead  movaps xmm8, [r15+0x2E0]
000071ff71bdeeb5  vmovaps [rsp+0x90], xmm8
000071ff71bdeebe  vmovaps xmm2, [rsp+0x90]
000071ff71bdeec7  por xmm8, xmm2
000071ff71bdeecc  movaps xmm2, [r15+0x2D0]
000071ff71bdeed4  vmovaps [rsp+0x90], xmm2
000071ff71bdeedd  vmovaps [rsp+0xA0], xmm1
000071ff71bdeee6  vmovaps xmm1, [rsp+0x90]
000071ff71bdeeef  por xmm2, xmm1
000071ff71bdeef3  movaps xmm1, [r15+0x200]
000071ff71bdeefb  vmovaps [rsp+0x90], xmm1
000071ff71bdef04  vmovaps [rsp+0xB0], xmm15
000071ff71bdef0d  vmovaps xmm15, [rsp+0x90]
000071ff71bdef16  por xmm1, xmm15
000071ff71bdef1b  movaps xmm15, [r15+0x1C0]
000071ff71bdef23  vmovaps [rsp+0x90], xmm15
000071ff71bdef2c  vmovaps [rsp+0xC0], xmm1
000071ff71bdef35  vmovaps xmm1, [rsp+0x90]
000071ff71bdef3e  por xmm15, xmm1
000071ff71bdef43  movaps xmm1, [r15+0x190]
000071ff71bdef4b  vmovaps [rsp+0x90], xmm1
000071ff71bdef54  vmovaps [rsp+0xD0], xmm15
000071ff71bdef5d  vmovaps xmm15, [rsp+0x90]
000071ff71bdef66  por xmm1, xmm15
000071ff71bdef6b  movaps xmm15, [r15+0x300]
000071ff71bdef73  vmovaps [rsp+0x90], xmm15
000071ff71bdef7c  vmovaps [rsp+0xE0], xmm1
000071ff71bdef85  vmovaps xmm1, [rsp+0x90]
000071ff71bdef8e  por xmm15, xmm1
000071ff71bdef93  mov rax, [rsp+0x80]
000071ff71bdef9b  lea r12, [rax+0xA0]
000071ff71bdefa2  movups xmm1, [r13+r12*1]
000071ff71bdefa8  lea r12, [rax+0xB0]
000071ff71bdefaf  vmovaps [rsp+0x80], xmm1
000071ff71bdefb8  movups xmm1, [r13+r12*1]
000071ff71bdefbe  vmovaps [rsp+0x90], xmm1
000071ff71bdefc7  vmovaps [rsp+0xF0], xmm15
000071ff71bdefd0  vmovaps xmm15, [rsp+0xB0]
000071ff71bdefd9  vmovaps [rsp+0xB0], xmm14
000071ff71bdefe2  movaps xmm1, xmm6
000071ff71bdefe5  addpd xmm1, xmm15
000071ff71bdefea  vcmppd xmm14, xmm1, xmm1, 0x03
000071ff71bdefef  ptest xmm14, xmm14
000071ff71bdeff5  jnz 0x000071FF71BE06B6
000071ff71bdeffb  lea r12, [rax+0xF0]
000071ff71bdf002  movups xmm15, [r13+r12*1]
000071ff71bdf008  movaps xmm14, xmm4
000071ff71bdf00c  addpd xmm14, xmm3
000071ff71bdf011  vcmppd xmm6, xmm14, xmm14, 0x03
000071ff71bdf017  ptest xmm6, xmm6
000071ff71bdf01c  jnz 0x000071FF71BE0801
000071ff71bdf022  movaps xmm6, xmm9
000071ff71bdf026  addpd xmm6, xmm7
000071ff71bdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
000071ff71bdf02f  ptest xmm4, xmm4
000071ff71bdf034  jnz 0x000071FF71BE0943
000071ff71bdf03a  vmovaps xmm9, [rsp+0x70]
000071ff71bdf040  vpermilpd xmm9, xmm9, 0x00
000071ff71bdf046  vmovaps xmm4, [rsp+0x90]
000071ff71bdf04f  movaps xmm7, xmm4
000071ff71bdf052  mulpd xmm7, xmm9
000071ff71bdf057  vcmppd xmm3, xmm7, xmm7, 0x03
000071ff71bdf05c  ptest xmm3, xmm3
000071ff71bdf061  jnz 0x000071FF71BE0A84
000071ff71bdf067  vmovaps xmm9, [rsp+0x50]
000071ff71bdf06d  vpermilpd xmm9, xmm9, 0x00
000071ff71bdf073  movaps xmm4, xmm15
000071ff71bdf077  mulpd xmm4, xmm9
000071ff71bdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
000071ff71bdf081  ptest xmm3, xmm3
000071ff71bdf086  jnz 0x000071FF71BE0BC5
000071ff71bdf08c  lea r12, [rax+0xE0]
000071ff71bdf093  movups xmm15, [r13+r12*1]
000071ff71bdf099  vmovaps xmm9, [rsp+0x70]
000071ff71bdf09f  vpermilpd xmm9, xmm9, 0x00
000071ff71bdf0a5  vmovaps [rsp+0x70], xmm1
000071ff71bdf0ab  vmovaps xmm1, [rsp+0x80]
000071ff71bdf0b4  vmovaps [rsp+0x80], xmm15
000071ff71bdf0bd  movaps xmm3, xmm1
000071ff71bdf0c0  mulpd xmm3, xmm9
000071ff71bdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000071ff71bdf0ca  ptest xmm15, xmm15
000071ff71bdf0d0  jnz 0x000071FF71BE0D11
000071ff71bdf0d6  vmovaps xmm1, [rsp+0xF0]
000071ff71bdf0df  vmovaps xmm15, [rsp+0xF0]
000071ff71bdf0e8  por xmm1, xmm15
000071ff71bdf0ed  movaps [r15+0x300], xmm1
000071ff71bdf0f5  vmovaps xmm15, [rsp+0xE0]
000071ff71bdf0fe  vmovaps xmm9, [rsp+0xE0]
000071ff71bdf107  por xmm15, xmm9
000071ff71bdf10c  movaps [r15+0x190], xmm15
000071ff71bdf114  vmovaps xmm9, [rsp+0x50]
000071ff71bdf11a  vpermilpd xmm9, xmm9, 0x00
000071ff71bdf120  vmovaps [rsp+0x90], xmm1
000071ff71bdf129  vmovaps [rsp+0xE0], xmm15
000071ff71bdf132  vmovaps xmm15, [rsp+0x80]
000071ff71bdf13b  vmovaps [rsp+0x80], xmm14
000071ff71bdf144  movaps xmm1, xmm15
000071ff71bdf148  mulpd xmm1, xmm9
000071ff71bdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
000071ff71bdf152  ptest xmm14, xmm14
000071ff71bdf158  jnz 0x000071FF71BE0E52
000071ff71bdf15e  lea r12, [rax+0x90]
000071ff71bdf165  movups xmm15, [r13+r12*1]
000071ff71bdf16b  vmovaps xmm14, [rsp+0xD0]
000071ff71bdf174  vmovaps xmm9, [rsp+0xD0]
000071ff71bdf17d  por xmm14, xmm9
000071ff71bdf182  movaps [r15+0x1C0], xmm14
000071ff71bdf18a  vmovaps xmm9, [rsp+0xC0]
000071ff71bdf193  vmovaps [rsp+0xD0], xmm1
000071ff71bdf19c  vmovaps xmm1, [rsp+0xC0]
000071ff71bdf1a5  por xmm9, xmm1
000071ff71bdf1aa  movaps [r15+0x200], xmm9
000071ff71bdf1b2  vmovaps [rsp+0xC0], xmm2
000071ff71bdf1bb  vmovaps xmm1, [rsp+0xC0]
000071ff71bdf1c4  por xmm2, xmm1
000071ff71bdf1c8  movaps [r15+0x2D0], xmm2
000071ff71bdf1d0  vmovaps [rsp+0xC0], xmm8
000071ff71bdf1d9  vmovaps xmm1, [rsp+0xC0]
000071ff71bdf1e2  por xmm8, xmm1
000071ff71bdf1e7  movaps [r15+0x2E0], xmm8
000071ff71bdf1ef  vmovaps [rsp+0xC0], xmm15
000071ff71bdf1f8  movaps xmm1, xmm5
000071ff71bdf1fb  addpd xmm1, xmm7
000071ff71bdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000071ff71bdf204  ptest xmm15, xmm15
000071ff71bdf20a  jnz 0x000071FF71BE0F9E
000071ff71bdf210  vmovaps xmm15, [rsp+0x50]
000071ff71bdf216  vpermilpd xmm15, xmm15, 0x00
000071ff71bdf21c  vmovaps xmm5, [rsp+0xC0]
000071ff71bdf225  vmovaps [rsp+0xC0], xmm1
000071ff71bdf22e  movaps xmm7, xmm5
000071ff71bdf231  mulpd xmm7, xmm15
000071ff71bdf236  vcmppd xmm1, xmm7, xmm7, 0x03
000071ff71bdf23b  ptest xmm1, xmm1
000071ff71bdf240  jnz 0x000071FF71BE10DE
000071ff71bdf246  lea r12, [rax+0x80]
000071ff71bdf24d  movups xmm1, [r13+r12*1]
000071ff71bdf253  vmovaps xmm5, [rsp+0x70]
000071ff71bdf259  vmovaps [rsp+0x70], xmm1
000071ff71bdf25f  movaps xmm15, xmm5
000071ff71bdf263  addpd xmm15, xmm3
000071ff71bdf268  vcmppd xmm1, xmm15, xmm15, 0x03
000071ff71bdf26e  ptest xmm1, xmm1
000071ff71bdf273  jnz 0x000071FF71BE1229
000071ff71bdf279  vmovaps xmm5, [rsp+0x80]
000071ff71bdf282  movaps xmm1, xmm5
000071ff71bdf285  addpd xmm1, xmm4
000071ff71bdf289  vcmppd xmm3, xmm1, xmm1, 0x03
000071ff71bdf28e  ptest xmm3, xmm3
000071ff71bdf293  jnz 0x000071FF71BE136B
000071ff71bdf299  vmovaps [rsp+0x80], xmm10
000071ff71bdf2a2  vmovaps xmm5, [rsp+0x80]
000071ff71bdf2ab  por xmm10, xmm5
000071ff71bdf2b0  movaps [r15+0x2F0], xmm10
000071ff71bdf2b8  vmovaps xmm5, [rsp+0x50]
000071ff71bdf2be  vpermilpd xmm5, xmm5, 0x00
000071ff71bdf2c4  vmovaps xmm3, [rsp+0x70]
000071ff71bdf2ca  vmovaps [rsp+0x50], xmm1
000071ff71bdf2d0  movaps xmm4, xmm3
000071ff71bdf2d3  mulpd xmm4, xmm5
000071ff71bdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000071ff71bdf2dc  ptest xmm1, xmm1
000071ff71bdf2e1  jnz 0x000071FF71BE14AB
000071ff71bdf2e7  lea r12, [rax+0xD0]
000071ff71bdf2ee  movups xmm1, [r13+r12*1]
000071ff71bdf2f4  vmovaps xmm3, [rsp+0xD0]
000071ff71bdf2fd  vmovaps [rsp+0x70], xmm1
000071ff71bdf303  movaps xmm5, xmm6
000071ff71bdf306  addpd xmm5, xmm3
000071ff71bdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
000071ff71bdf30f  ptest xmm1, xmm1
000071ff71bdf314  jnz 0x000071FF71BE15F5
000071ff71bdf31a  vmovaps xmm1, [rsp+0x60]
000071ff71bdf320  vpermilpd xmm1, xmm1, 0x00
000071ff71bdf326  movaps xmm6, xmm9
000071ff71bdf32a  mulpd xmm6, xmm1
000071ff71bdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
000071ff71bdf333  ptest xmm3, xmm3
000071ff71bdf338  jnz 0x000071FF71BE1735
000071ff71bdf33e  movaps [r15+0x260], xmm6
000071ff71bdf346  vxorps xmm1, xmm1, xmm1
000071ff71bdf34a  vpbroadcastq xmm1, xmm1
000071ff71bdf34f  movaps [r15+0x1B0], xmm1
000071ff71bdf357  vmovaps xmm1, [rsp+0x60]
000071ff71bdf35d  vpermilpd xmm1, xmm1, 0x00
000071ff71bdf363  vmovaps xmm3, [rsp+0x70]
000071ff71bdf369  vmovaps [rsp+0x70], xmm15
000071ff71bdf36f  movaps xmm9, xmm3
000071ff71bdf373  mulpd xmm9, xmm1
000071ff71bdf378  vcmppd xmm15, xmm9, xmm9, 0x03
000071ff71bdf37e  ptest xmm15, xmm15
000071ff71bdf384  jnz 0x000071FF71BE1876
000071ff71bdf38a  lea r12, [rax+0xC0]
000071ff71bdf391  movups xmm1, [r13+r12*1]
000071ff71bdf397  vmovaps xmm3, [rsp+0xC0]
000071ff71bdf3a0  vmovaps [rsp+0x80], xmm1
000071ff71bdf3a9  movaps xmm15, xmm3
000071ff71bdf3ad  addpd xmm15, xmm7
000071ff71bdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000071ff71bdf3b8  ptest xmm1, xmm1
000071ff71bdf3bd  jnz 0x000071FF71BE19C2
000071ff71bdf3c3  vmovaps [rsp+0xC0], xmm13
000071ff71bdf3cc  vmovaps xmm1, [rsp+0xC0]
000071ff71bdf3d5  por xmm13, xmm1
000071ff71bdf3da  movaps [r15+0x270], xmm13
000071ff71bdf3e2  vmovaps xmm1, [rsp+0xB0]
000071ff71bdf3eb  vmovaps xmm7, [rsp+0xB0]
000071ff71bdf3f4  por xmm1, xmm7
000071ff71bdf3f8  movaps [r15+0x1A0], xmm1
000071ff71bdf400  vmovaps xmm1, [rsp+0x60]
000071ff71bdf406  vpermilpd xmm1, xmm1, 0x00
000071ff71bdf40c  vmovaps [rsp+0xB0], xmm1
000071ff71bdf415  vmovaps xmm1, [rsp+0x80]
000071ff71bdf41e  vmovaps [rsp+0x80], xmm15
000071ff71bdf427  vmovaps xmm15, [rsp+0xB0]
000071ff71bdf430  vmovaps [rsp+0xB0], xmm14
000071ff71bdf439  movaps xmm3, xmm1
000071ff71bdf43c  mulpd xmm3, xmm15
000071ff71bdf441  vcmppd xmm14, xmm3, xmm3, 0x03
000071ff71bdf446  ptest xmm14, xmm14
000071ff71bdf44c  jnz 0x000071FF71BE1B04
000071ff71bdf452  lea r12, [rax+0x20]
000071ff71bdf456  movups xmm1, [r13+r12*1]
000071ff71bdf45c  movaps [r15+0x110], xmm1
000071ff71bdf464  vmovaps xmm14, [rsp+0x70]
000071ff71bdf46a  vmovaps [rsp+0x70], xmm1
000071ff71bdf470  movaps xmm15, xmm14
000071ff71bdf474  addpd xmm15, xmm4
000071ff71bdf479  vcmppd xmm1, xmm15, xmm15, 0x03
000071ff71bdf47f  ptest xmm1, xmm1
000071ff71bdf484  jnz 0x000071FF71BE1C4F
000071ff71bdf48a  vmovaps xmm1, [rsp+0x60]
000071ff71bdf490  vpermilpd xmm1, xmm1, 0x00
000071ff71bdf496  movaps xmm14, xmm2
000071ff71bdf49a  mulpd xmm14, xmm1
000071ff71bdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
000071ff71bdf4a5  ptest xmm4, xmm4
000071ff71bdf4aa  jnz 0x000071FF71BE1D92
000071ff71bdf4b0  vmovaps xmm4, [rsp+0x50]
000071ff71bdf4b6  movaps xmm1, xmm4
000071ff71bdf4b9  addpd xmm1, xmm9
000071ff71bdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
000071ff71bdf4c3  ptest xmm2, xmm2
000071ff71bdf4c8  jnz 0x000071FF71BE1ED4
000071ff71bdf4ce  vmovaps xmm9, [rsp+0x30]
000071ff71bdf4d4  vpermilpd xmm9, xmm9, 0x00
000071ff71bdf4da  vmovaps xmm2, [rsp+0x70]
000071ff71bdf4e0  vmovaps [rsp+0x50], xmm1
000071ff71bdf4e6  movaps xmm4, xmm2
000071ff71bdf4e9  mulpd xmm4, xmm9
000071ff71bdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000071ff71bdf4f3  ptest xmm1, xmm1
000071ff71bdf4f8  jnz 0x000071FF71BE2015
000071ff71bdf4fe  vmovaps xmm1, [rsp+0x30]
000071ff71bdf504  vpermilpd xmm1, xmm1, 0x00
000071ff71bdf50a  vmovaps xmm2, [rsp+0x90]
000071ff71bdf513  vmovaps [rsp+0x60], xmm15
000071ff71bdf519  movaps xmm9, xmm2
000071ff71bdf51d  mulpd xmm9, xmm1
000071ff71bdf522  vcmppd xmm15, xmm9, xmm9, 0x03
000071ff71bdf528  ptest xmm15, xmm15
000071ff71bdf52e  jnz 0x000071FF71BE2156
000071ff71bdf534  vmovaps xmm15, [rsp+0x80]
000071ff71bdf53d  movaps xmm1, xmm15
000071ff71bdf541  addpd xmm1, xmm6
000071ff71bdf545  vcmppd xmm2, xmm1, xmm1, 0x03
000071ff71bdf54a  ptest xmm2, xmm2
000071ff71bdf54f  jnz 0x000071FF71BE2298
000071ff71bdf555  movaps xmm15, xmm5
000071ff71bdf559  addpd xmm15, xmm3
000071ff71bdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
000071ff71bdf564  ptest xmm6, xmm6
000071ff71bdf569  jnz 0x000071FF71BE23D9
000071ff71bdf56f  vmovaps xmm6, [rsp+0x30]
000071ff71bdf575  vpermilpd xmm6, xmm6, 0x00
000071ff71bdf57b  movaps xmm5, xmm8
000071ff71bdf57f  mulpd xmm5, xmm6
000071ff71bdf583  vcmppd xmm3, xmm5, xmm5, 0x03
000071ff71bdf588  ptest xmm3, xmm3
000071ff71bdf58d  jnz 0x000071FF71BE251B
000071ff71bdf593  vmovaps xmm8, [rsp+0x30]
000071ff71bdf599  vpermilpd xmm8, xmm8, 0x00
000071ff71bdf59f  movaps xmm6, xmm10
000071ff71bdf5a3  mulpd xmm6, xmm8
000071ff71bdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000071ff71bdf5ad  ptest xmm3, xmm3
000071ff71bdf5b2  jnz 0x000071FF71BE265C
000071ff71bdf5b8  vmovaps xmm8, [rsp+0x60]
000071ff71bdf5be  movaps xmm10, xmm8
000071ff71bdf5c2  addpd xmm10, xmm14
000071ff71bdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000071ff71bdf5cd  ptest xmm3, xmm3
000071ff71bdf5d2  jnz 0x000071FF71BE279E
000071ff71bdf5d8  vmovaps xmm8, [rsp+0x50]
000071ff71bdf5de  movaps xmm14, xmm8
000071ff71bdf5e2  addpd xmm14, xmm4
000071ff71bdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000071ff71bdf5ed  ptest xmm3, xmm3
000071ff71bdf5f2  jnz 0x000071FF71BE28E2
000071ff71bdf5f8  vmovaps xmm8, [rsp+0x40]
000071ff71bdf5fe  vpermilpd xmm8, xmm8, 0x00
000071ff71bdf604  movaps xmm4, xmm13
000071ff71bdf608  mulpd xmm4, xmm8
000071ff71bdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
000071ff71bdf612  ptest xmm3, xmm3
000071ff71bdf617  jnz 0x000071FF71BE2A25
000071ff71bdf61d  movaps xmm13, xmm15
000071ff71bdf621  addpd xmm13, xmm9
000071ff71bdf626  vcmppd xmm8, xmm13, xmm13, 0x03
000071ff71bdf62c  ptest xmm8, xmm8
000071ff71bdf632  jnz 0x000071FF71BE2B67
000071ff71bdf638  movaps xmm15, xmm1
000071ff71bdf63c  addpd xmm15, xmm5
000071ff71bdf641  vcmppd xmm9, xmm15, xmm15, 0x03
000071ff71bdf647  ptest xmm9, xmm9
000071ff71bdf64d  jnz 0x000071FF71BE2CAB
000071ff71bdf653  vmovaps [rsp+0x30], xmm11
000071ff71bdf659  vmovaps xmm1, [rsp+0x30]
000071ff71bdf65f  por xmm11, xmm1
000071ff71bdf664  movaps [r15+0x250], xmm11
000071ff71bdf66c  vmovaps [rsp+0x30], xmm12
000071ff71bdf672  vmovaps xmm1, [rsp+0x30]
000071ff71bdf678  por xmm12, xmm1
000071ff71bdf67d  movaps [r15+0x2A0], xmm12
000071ff71bdf685  vmovaps xmm1, [rsp+0xA0]
000071ff71bdf68e  vmovaps xmm11, [rsp+0xA0]
000071ff71bdf697  por xmm1, xmm11
000071ff71bdf69c  movaps [r15+0x1D0], xmm1
000071ff71bdf6a4  lea r12, [rax+0x40]
000071ff71bdf6a8  movups xmm1, [r13+r12*1]
000071ff71bdf6ae  movaps [r15+0x2C0], xmm1
000071ff71bdf6b6  vmovaps xmm11, [rsp+0x40]
000071ff71bdf6bc  vpermilpd xmm11, xmm11, 0x00
000071ff71bdf6c2  vmovaps xmm8, [rsp+0xE0]
000071ff71bdf6cb  movaps xmm9, xmm8
000071ff71bdf6cf  mulpd xmm9, xmm11
000071ff71bdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000071ff71bdf6da  ptest xmm5, xmm5
000071ff71bdf6df  jnz 0x000071FF71BE2DF7
000071ff71bdf6e5  movaps xmm11, xmm10
000071ff71bdf6e9  addpd xmm11, xmm6
000071ff71bdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000071ff71bdf6f4  ptest xmm8, xmm8
000071ff71bdf6fa  jnz 0x000071FF71BE2F3B
000071ff71bdf700  movaps xmm10, xmm14
000071ff71bdf704  addpd xmm10, xmm4
000071ff71bdf709  vcmppd xmm8, xmm10, xmm10, 0x03
000071ff71bdf70f  ptest xmm8, xmm8
000071ff71bdf715  jnz 0x000071FF71BE307E
000071ff71bdf71b  vmovaps xmm14, [rsp+0x40]
000071ff71bdf721  vpermilpd xmm14, xmm14, 0x00
000071ff71bdf727  movaps xmm8, xmm1
000071ff71bdf72b  mulpd xmm8, xmm14
000071ff71bdf730  vcmppd xmm6, xmm8, xmm8, 0x03
000071ff71bdf736  ptest xmm6, xmm6
000071ff71bdf73b  jnz 0x000071FF71BE31C1
000071ff71bdf741  movaps xmm1, [r15+0x2B0]
000071ff71bdf749  vmovaps xmm14, [rsp+0x40]
000071ff71bdf74f  vpermilpd xmm14, xmm14, 0x00
000071ff71bdf755  movaps xmm6, xmm1
000071ff71bdf758  mulpd xmm6, xmm14
000071ff71bdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
000071ff71bdf762  ptest xmm5, xmm5
000071ff71bdf767  jnz 0x000071FF71BE3304
000071ff71bdf76d  vmovaps xmm1, [rsp+0x10]
000071ff71bdf773  vpermilpd xmm1, xmm1, 0x00
000071ff71bdf779  movaps xmm14, xmm12
000071ff71bdf77d  mulpd xmm14, xmm1
000071ff71bdf782  vcmppd xmm5, xmm14, xmm14, 0x03
000071ff71bdf788  ptest xmm5, xmm5
000071ff71bdf78d  jnz 0x000071FF71BE3445
000071ff71bdf793  movaps xmm1, xmm13
000071ff71bdf797  addpd xmm1, xmm9
000071ff71bdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
000071ff71bdf7a1  ptest xmm12, xmm12
000071ff71bdf7a7  jnz 0x000071FF71BE3588
000071ff71bdf7ad  vmovaps xmm13, [rsp+0x10]
000071ff71bdf7b3  vpermilpd xmm13, xmm13, 0x00
000071ff71bdf7b9  movaps xmm12, xmm7
000071ff71bdf7bd  mulpd xmm12, xmm13
000071ff71bdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000071ff71bdf7c8  ptest xmm9, xmm9
000071ff71bdf7ce  jnz 0x000071FF71BE36CA
000071ff71bdf7d4  movaps xmm13, xmm15
000071ff71bdf7d8  addpd xmm13, xmm8
000071ff71bdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000071ff71bdf7e3  ptest xmm9, xmm9
000071ff71bdf7e9  jnz 0x000071FF71BE380D
000071ff71bdf7ef  movaps xmm15, [r15+0x290]
000071ff71bdf7f7  vmovaps xmm9, [rsp+0x10]
000071ff71bdf7fd  vpermilpd xmm9, xmm9, 0x00
000071ff71bdf803  movaps xmm8, xmm15
000071ff71bdf807  mulpd xmm8, xmm9
000071ff71bdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
000071ff71bdf812  ptest xmm7, xmm7
000071ff71bdf817  jnz 0x000071FF71BE3951
000071ff71bdf81d  movaps xmm15, xmm11
000071ff71bdf821  addpd xmm15, xmm6
000071ff71bdf826  vcmppd xmm9, xmm15, xmm15, 0x03
000071ff71bdf82c  ptest xmm9, xmm9
000071ff71bdf832  jnz 0x000071FF71BE3A95
000071ff71bdf838  movaps xmm11, [r15+0x1E0]
000071ff71bdf840  vmovaps xmm9, [rsp+0x10]
000071ff71bdf846  vpermilpd xmm9, xmm9, 0x00
000071ff71bdf84c  movaps xmm7, xmm11
000071ff71bdf850  mulpd xmm7, xmm9
000071ff71bdf855  vcmppd xmm6, xmm7, xmm7, 0x03
000071ff71bdf85a  ptest xmm6, xmm6
000071ff71bdf85f  jnz 0x000071FF71BE3BD8
000071ff71bdf865  movaps xmm11, xmm10
000071ff71bdf869  addpd xmm11, xmm14
000071ff71bdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
000071ff71bdf874  ptest xmm9, xmm9
000071ff71bdf87a  jnz 0x000071FF71BE3D1A
000071ff71bdf880  lea r12, [rax+0x70]
000071ff71bdf884  movups xmm14, [r13+r12*1]
000071ff71bdf88a  movaps [r15+0x240], xmm14
000071ff71bdf892  movaps xmm10, xmm1
000071ff71bdf896  addpd xmm10, xmm12
000071ff71bdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
000071ff71bdf8a1  ptest xmm9, xmm9
000071ff71bdf8a7  jnz 0x000071FF71BE3E68
000071ff71bdf8ad  movaps [r15+0x170], xmm10
000071ff71bdf8b5  vmovaps xmm1, [rsp+0x20]
000071ff71bdf8bb  vpermilpd xmm1, xmm1, 0x00
000071ff71bdf8c1  movaps xmm12, xmm14
000071ff71bdf8c5  mulpd xmm12, xmm1
000071ff71bdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000071ff71bdf8d0  ptest xmm9, xmm9
000071ff71bdf8d6  jnz 0x000071FF71BE3FAB
000071ff71bdf8dc  vmovaps xmm1, [rsp+0x20]
000071ff71bdf8e2  vpermilpd xmm1, xmm1, 0x00
000071ff71bdf8e8  vmovaps xmm9, [rsp+0xB0]
000071ff71bdf8f1  movaps xmm14, xmm9
000071ff71bdf8f5  mulpd xmm14, xmm1
000071ff71bdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000071ff71bdf900  ptest xmm6, xmm6
000071ff71bdf905  jnz 0x000071FF71BE40EE
000071ff71bdf90b  movaps [r15+0x180], xmm14
000071ff71bdf913  movaps xmm1, xmm13
000071ff71bdf917  addpd xmm1, xmm8
000071ff71bdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
000071ff71bdf921  ptest xmm9, xmm9
000071ff71bdf927  jnz 0x000071FF71BE4231
000071ff71bdf92d  movaps [r15+0x210], xmm1
000071ff71bdf935  movups xmm13, [r13+rax*1]
000071ff71bdf93b  lea r12, [rax+0x10]
000071ff71bdf93f  movups xmm9, [r13+r12*1]
000071ff71bdf945  movaps [r15+0x230], xmm9
000071ff71bdf94d  movaps xmm8, xmm15
000071ff71bdf951  addpd xmm8, xmm7
000071ff71bdf956  vcmppd xmm6, xmm8, xmm8, 0x03
000071ff71bdf95c  ptest xmm6, xmm6
000071ff71bdf961  jnz 0x000071FF71BE4387
000071ff71bdf967  movaps [r15+0x130], xmm8
000071ff71bdf96f  vmovaps xmm15, [rsp+0x20]
000071ff71bdf975  vpermilpd xmm15, xmm15, 0x00
000071ff71bdf97b  movaps xmm7, xmm9
000071ff71bdf97f  mulpd xmm7, xmm15
000071ff71bdf984  vcmppd xmm6, xmm7, xmm7, 0x03
000071ff71bdf989  ptest xmm6, xmm6
000071ff71bdf98e  jnz 0x000071FF71BE44CA
000071ff71bdf994  movaps [r15+0x220], xmm7
000071ff71bdf99c  vmovaps xmm15, [rsp+0x20]
000071ff71bdf9a2  vpermilpd xmm15, xmm15, 0x00
000071ff71bdf9a8  movaps xmm9, xmm13
000071ff71bdf9ac  mulpd xmm9, xmm15
000071ff71bdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000071ff71bdf9b7  ptest xmm6, xmm6
000071ff71bdf9bc  jnz 0x000071FF71BE460C
000071ff71bdf9c2  movaps xmm15, xmm11
000071ff71bdf9c6  addpd xmm15, xmm12
000071ff71bdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000071ff71bdf9d1  ptest xmm13, xmm13
000071ff71bdf9d7  jnz 0x000071FF71BE4750
000071ff71bdf9dd  movaps [r15+0x140], xmm15
000071ff71bdf9e5  movaps xmm13, xmm10
000071ff71bdf9e9  addpd xmm13, xmm14
000071ff71bdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000071ff71bdf9f4  ptest xmm12, xmm12
000071ff71bdf9fa  jnz 0x000071FF71BE4894
000071ff71bdfa00  movaps [r15+0x150], xmm13
000071ff71bdfa08  movaps xmm14, xmm1
000071ff71bdfa0c  addpd xmm14, xmm7
000071ff71bdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000071ff71bdfa17  ptest xmm12, xmm12
000071ff71bdfa1d  jnz 0x000071FF71BE49D8
000071ff71bdfa23  movaps [r15+0x160], xmm14
000071ff71bdfa2b  movaps xmm1, xmm8
000071ff71bdfa2f  addpd xmm1, xmm9
000071ff71bdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000071ff71bdfa39  ptest xmm12, xmm12
000071ff71bdfa3f  jnz 0x000071FF71BE4B1A
000071ff71bdfa45  movaps [r15+0x120], xmm1
000071ff71bdfa4d  movups [r13+r14*1], xmm15
000071ff71bdfa53  lea rax, [r14+0x10]
000071ff71bdfa57  movups [r13+rax*1], xmm13
000071ff71bdfa5d  lea rax, [r14+0x20]
000071ff71bdfa61  movups [r13+rax*1], xmm14
000071ff71bdfa67  lea rax, [r14+0x30]
000071ff71bdfa6b  movups [r13+rax*1], xmm1
000071ff71bdfa71  mov eax, [r15+0x108]
000071ff71bdfa78  sahf
000071ff71bdfa79  jnz 0x000071FF71BDFAAB
000071ff71bdfa7b  cmp dword ptr [r15+0x318], 0x00
000071ff71bdfa83  jz 0x000071FF71BDEAE0
000071ff71bdfa89  nop [rax+rax*1], ax
000071ff71bdfa92  nop [rax+rax*1], eax
000071ff71bdfa9a  mov eax, 0x4106D0
000071ff71bdfa9f  mov [r15+0x100], rax
000071ff71bdfaa6  jmp 0x000071FF719FE110
000071ff71bdfaab  cmp dword ptr [r15+0x318], 0x00
000071ff71bdfab3  jz 0x000071FF71BD89C0
000071ff71bdfab9  nop [rax+rax*1], ax
000071ff71bdfac2  nop [rax+rax*1], eax
000071ff71bdfaca  mov eax, 0x410504
000071ff71bdfacf  mov [r15+0x100], rax
000071ff71bdfad6  jmp 0x000071FF719FE110
000071ff71bdfadb  int3
000071ff71bdfadc  call 0x000071FF71AE27E0
000071ff71bdfae1  jmp 0x000071FF71BDEBBF
000071ff71bdfae6  call 0x000071FF71AE1570
000071ff71bdfaeb  jmp 0x000071FF71BDEBC8
000071ff71bdfaf0  call 0x000071FF71AE27E0
000071ff71bdfaf5  jmp 0x000071FF71BDEC24
000071ff71bdfafa  call 0x000071FF71AE1570
000071ff71bdfaff  jmp 0x000071FF71BDEC2D
000071ff71bdfb04  call 0x000071FF71AE27E0
000071ff71bdfb09  jmp 0x000071FF71BDEC70
000071ff71bdfb0e  call 0x000071FF71AE1570
000071ff71bdfb13  jmp 0x000071FF71BDEC79
000071ff71bdfb18  call 0x000071FF71A0DC20
000071ff71bdfb1d  jmp 0x000071FF71BDECB8
000071ff71bdfb22  call 0x000071FF71AD59C0
000071ff71bdfb27  jmp 0x000071FF71BDECCB
000071ff71bdfb2c  call 0x000071FF71AE0E30
000071ff71bdfb31  jmp 0x000071FF71BDECE9
000071ff71bdfb36  call 0x000071FF71ADFBC0
000071ff71bdfb3b  jmp 0x000071FF71BDECF3
000071ff71bdfb40  call 0x000071FF71ADE950
000071ff71bdfb45  jmp 0x000071FF71BDECFD
000071ff71bdfb4a  sub rsp, 0x08
000071ff71bdfb4e  push rax
000071ff71bdfb4f  push rcx
000071ff71bdfb50  push rdx
000071ff71bdfb51  push rdi
000071ff71bdfb52  push rsi
000071ff71bdfb53  push r8
000071ff71bdfb55  push r9
000071ff71bdfb57  push r10
000071ff71bdfb59  push r11
000071ff71bdfb5b  sub rsp, 0xF0
000071ff71bdfb62  vmovaps [rsp], xmm0
000071ff71bdfb67  vmovaps [rsp+0x10], xmm1
000071ff71bdfb6d  vmovaps [rsp+0x20], xmm2
000071ff71bdfb73  vmovaps [rsp+0x30], xmm3
000071ff71bdfb79  vmovaps [rsp+0x40], xmm4
000071ff71bdfb7f  vmovaps [rsp+0x50], xmm5
000071ff71bdfb85  vmovaps [rsp+0x60], xmm6
000071ff71bdfb8b  vmovaps [rsp+0x70], xmm7
000071ff71bdfb91  vmovaps [rsp+0x80], xmm9
000071ff71bdfb9a  vmovaps [rsp+0x90], xmm10
000071ff71bdfba3  vmovaps [rsp+0xA0], xmm11
000071ff71bdfbac  vmovaps [rsp+0xB0], xmm12
000071ff71bdfbb5  vmovaps [rsp+0xC0], xmm13
000071ff71bdfbbe  vmovaps [rsp+0xD0], xmm14
000071ff71bdfbc7  vmovaps [rsp+0xE0], xmm15
000071ff71bdfbd0  sub rsp, 0x30
000071ff71bdfbd4  movaps [rsp], xmm8
000071ff71bdfbd9  movaps [rsp+0x10], xmm12
000071ff71bdfbdf  movaps [rsp+0x20], xmm15
000071ff71bdfbe5  lea rdi, [rsp]
000071ff71bdfbe9  mov esi, 0x00
000071ff71bdfbee  mov rax, 0x5E6872E10530
000071ff71bdfbf8  call rax
000071ff71bdfbfa  movaps xmm8, [rsp]
000071ff71bdfbff  add rsp, 0x30
000071ff71bdfc03  vmovaps xmm0, [rsp]
000071ff71bdfc08  vmovaps xmm1, [rsp+0x10]
000071ff71bdfc0e  vmovaps xmm2, [rsp+0x20]
000071ff71bdfc14  vmovaps xmm3, [rsp+0x30]
000071ff71bdfc1a  vmovaps xmm4, [rsp+0x40]
000071ff71bdfc20  vmovaps xmm5, [rsp+0x50]
000071ff71bdfc26  vmovaps xmm6, [rsp+0x60]
000071ff71bdfc2c  vmovaps xmm7, [rsp+0x70]
000071ff71bdfc32  vmovaps xmm9, [rsp+0x80]
000071ff71bdfc3b  vmovaps xmm10, [rsp+0x90]
000071ff71bdfc44  vmovaps xmm11, [rsp+0xA0]
000071ff71bdfc4d  vmovaps xmm12, [rsp+0xB0]
000071ff71bdfc56  vmovaps xmm13, [rsp+0xC0]
000071ff71bdfc5f  vmovaps xmm14, [rsp+0xD0]
000071ff71bdfc68  vmovaps xmm15, [rsp+0xE0]
000071ff71bdfc71  add rsp, 0xF0
000071ff71bdfc78  pop r11
000071ff71bdfc7a  pop r10
000071ff71bdfc7c  pop r9
000071ff71bdfc7e  pop r8
000071ff71bdfc80  pop rsi
000071ff71bdfc81  pop rdi
000071ff71bdfc82  pop rdx
000071ff71bdfc83  pop rcx
000071ff71bdfc84  pop rax
000071ff71bdfc85  add rsp, 0x08
000071ff71bdfc89  jmp 0x000071FF71BDED27
000071ff71bdfc8e  sub rsp, 0x08
000071ff71bdfc92  push rax
000071ff71bdfc93  push rcx
000071ff71bdfc94  push rdx
000071ff71bdfc95  push rdi
000071ff71bdfc96  push rsi
000071ff71bdfc97  push r8
000071ff71bdfc99  push r9
000071ff71bdfc9b  push r10
000071ff71bdfc9d  push r11
000071ff71bdfc9f  sub rsp, 0xF0
000071ff71bdfca6  vmovaps [rsp], xmm0
000071ff71bdfcab  vmovaps [rsp+0x10], xmm1
000071ff71bdfcb1  vmovaps [rsp+0x20], xmm2
000071ff71bdfcb7  vmovaps [rsp+0x30], xmm3
000071ff71bdfcbd  vmovaps [rsp+0x40], xmm4
000071ff71bdfcc3  vmovaps [rsp+0x50], xmm5
000071ff71bdfcc9  vmovaps [rsp+0x60], xmm6
000071ff71bdfccf  vmovaps [rsp+0x70], xmm8
000071ff71bdfcd5  vmovaps [rsp+0x80], xmm9
000071ff71bdfcde  vmovaps [rsp+0x90], xmm10
000071ff71bdfce7  vmovaps [rsp+0xA0], xmm11
000071ff71bdfcf0  vmovaps [rsp+0xB0], xmm12
000071ff71bdfcf9  vmovaps [rsp+0xC0], xmm13
000071ff71bdfd02  vmovaps [rsp+0xD0], xmm14
000071ff71bdfd0b  vmovaps [rsp+0xE0], xmm15
000071ff71bdfd14  sub rsp, 0x30
000071ff71bdfd18  movaps [rsp], xmm7
000071ff71bdfd1c  movaps [rsp+0x10], xmm9
000071ff71bdfd22  movaps [rsp+0x20], xmm15
000071ff71bdfd28  lea rdi, [rsp]
000071ff71bdfd2c  mov esi, 0x00
000071ff71bdfd31  mov rax, 0x5E6872E10530
000071ff71bdfd3b  call rax
000071ff71bdfd3d  movaps xmm7, [rsp]
000071ff71bdfd41  add rsp, 0x30
000071ff71bdfd45  vmovaps xmm0, [rsp]
000071ff71bdfd4a  vmovaps xmm1, [rsp+0x10]
000071ff71bdfd50  vmovaps xmm2, [rsp+0x20]
000071ff71bdfd56  vmovaps xmm3, [rsp+0x30]
000071ff71bdfd5c  vmovaps xmm4, [rsp+0x40]
000071ff71bdfd62  vmovaps xmm5, [rsp+0x50]
000071ff71bdfd68  vmovaps xmm6, [rsp+0x60]
000071ff71bdfd6e  vmovaps xmm8, [rsp+0x70]
000071ff71bdfd74  vmovaps xmm9, [rsp+0x80]
000071ff71bdfd7d  vmovaps xmm10, [rsp+0x90]
000071ff71bdfd86  vmovaps xmm11, [rsp+0xA0]
000071ff71bdfd8f  vmovaps xmm12, [rsp+0xB0]
000071ff71bdfd98  vmovaps xmm13, [rsp+0xC0]
000071ff71bdfda1  vmovaps xmm14, [rsp+0xD0]
000071ff71bdfdaa  vmovaps xmm15, [rsp+0xE0]
000071ff71bdfdb3  add rsp, 0xF0
000071ff71bdfdba  pop r11
000071ff71bdfdbc  pop r10
000071ff71bdfdbe  pop r9
000071ff71bdfdc0  pop r8
000071ff71bdfdc2  pop rsi
000071ff71bdfdc3  pop rdi
000071ff71bdfdc4  pop rdx
000071ff71bdfdc5  pop rcx
000071ff71bdfdc6  pop rax
000071ff71bdfdc7  add rsp, 0x08
000071ff71bdfdcb  jmp 0x000071FF71BDED55
000071ff71bdfdd0  sub rsp, 0x08
000071ff71bdfdd4  push rax
000071ff71bdfdd5  push rcx
000071ff71bdfdd6  push rdx
000071ff71bdfdd7  push rdi
000071ff71bdfdd8  push rsi
000071ff71bdfdd9  push r8
000071ff71bdfddb  push r9
000071ff71bdfddd  push r10
000071ff71bdfddf  push r11
000071ff71bdfde1  sub rsp, 0xF0
000071ff71bdfde8  vmovaps [rsp], xmm0
000071ff71bdfded  vmovaps [rsp+0x10], xmm1
000071ff71bdfdf3  vmovaps [rsp+0x20], xmm2
000071ff71bdfdf9  vmovaps [rsp+0x30], xmm3
000071ff71bdfdff  vmovaps [rsp+0x40], xmm4
000071ff71bdfe05  vmovaps [rsp+0x50], xmm5
000071ff71bdfe0b  vmovaps [rsp+0x60], xmm6
000071ff71bdfe11  vmovaps [rsp+0x70], xmm7
000071ff71bdfe17  vmovaps [rsp+0x80], xmm8
000071ff71bdfe20  vmovaps [rsp+0x90], xmm10
000071ff71bdfe29  vmovaps [rsp+0xA0], xmm11
000071ff71bdfe32  vmovaps [rsp+0xB0], xmm12
000071ff71bdfe3b  vmovaps [rsp+0xC0], xmm13
000071ff71bdfe44  vmovaps [rsp+0xD0], xmm14
000071ff71bdfe4d  vmovaps [rsp+0xE0], xmm15
000071ff71bdfe56  sub rsp, 0x30
000071ff71bdfe5a  movaps [rsp], xmm9
000071ff71bdfe5f  movaps [rsp+0x10], xmm12
000071ff71bdfe65  movaps [rsp+0x20], xmm10
000071ff71bdfe6b  lea rdi, [rsp]
000071ff71bdfe6f  mov esi, 0x00
000071ff71bdfe74  mov rax, 0x5E6872E10530
000071ff71bdfe7e  call rax
000071ff71bdfe80  movaps xmm9, [rsp]
000071ff71bdfe85  add rsp, 0x30
000071ff71bdfe89  vmovaps xmm0, [rsp]
000071ff71bdfe8e  vmovaps xmm1, [rsp+0x10]
000071ff71bdfe94  vmovaps xmm2, [rsp+0x20]
000071ff71bdfe9a  vmovaps xmm3, [rsp+0x30]
000071ff71bdfea0  vmovaps xmm4, [rsp+0x40]
000071ff71bdfea6  vmovaps xmm5, [rsp+0x50]
000071ff71bdfeac  vmovaps xmm6, [rsp+0x60]
000071ff71bdfeb2  vmovaps xmm7, [rsp+0x70]
000071ff71bdfeb8  vmovaps xmm8, [rsp+0x80]
000071ff71bdfec1  vmovaps xmm10, [rsp+0x90]
000071ff71bdfeca  vmovaps xmm11, [rsp+0xA0]
000071ff71bdfed3  vmovaps xmm12, [rsp+0xB0]
000071ff71bdfedc  vmovaps xmm13, [rsp+0xC0]
000071ff71bdfee5  vmovaps xmm14, [rsp+0xD0]
000071ff71bdfeee  vmovaps xmm15, [rsp+0xE0]
000071ff71bdfef7  add rsp, 0xF0
000071ff71bdfefe  pop r11
000071ff71bdff00  pop r10
000071ff71bdff02  pop r9
000071ff71bdff04  pop r8
000071ff71bdff06  pop rsi
000071ff71bdff07  pop rdi
000071ff71bdff08  pop rdx
000071ff71bdff09  pop rcx
000071ff71bdff0a  pop rax
000071ff71bdff0b  add rsp, 0x08
000071ff71bdff0f  jmp 0x000071FF71BDED79
000071ff71bdff14  sub rsp, 0x08
000071ff71bdff18  push rax
000071ff71bdff19  push rcx
000071ff71bdff1a  push rdx
000071ff71bdff1b  push rdi
000071ff71bdff1c  push rsi
000071ff71bdff1d  push r8
000071ff71bdff1f  push r9
000071ff71bdff21  push r10
000071ff71bdff23  push r11
000071ff71bdff25  sub rsp, 0xF0
000071ff71bdff2c  vmovaps [rsp], xmm0
000071ff71bdff31  vmovaps [rsp+0x10], xmm1
000071ff71bdff37  vmovaps [rsp+0x20], xmm2
000071ff71bdff3d  vmovaps [rsp+0x30], xmm3
000071ff71bdff43  vmovaps [rsp+0x40], xmm4
000071ff71bdff49  vmovaps [rsp+0x50], xmm5
000071ff71bdff4f  vmovaps [rsp+0x60], xmm6
000071ff71bdff55  vmovaps [rsp+0x70], xmm7
000071ff71bdff5b  vmovaps [rsp+0x80], xmm8
000071ff71bdff64  vmovaps [rsp+0x90], xmm9
000071ff71bdff6d  vmovaps [rsp+0xA0], xmm11
000071ff71bdff76  vmovaps [rsp+0xB0], xmm12
000071ff71bdff7f  vmovaps [rsp+0xC0], xmm13
000071ff71bdff88  vmovaps [rsp+0xD0], xmm14
000071ff71bdff91  vmovaps [rsp+0xE0], xmm15
000071ff71bdff9a  sub rsp, 0x30
000071ff71bdff9e  movaps [rsp], xmm10
000071ff71bdffa3  movaps [rsp+0x10], xmm12
000071ff71bdffa9  movaps [rsp+0x20], xmm11
000071ff71bdffaf  lea rdi, [rsp]
000071ff71bdffb3  mov esi, 0x00
000071ff71bdffb8  mov rax, 0x5E6872E10530
000071ff71bdffc2  call rax
000071ff71bdffc4  movaps xmm10, [rsp]
000071ff71bdffc9  add rsp, 0x30
000071ff71bdffcd  vmovaps xmm0, [rsp]
000071ff71bdffd2  vmovaps xmm1, [rsp+0x10]
000071ff71bdffd8  vmovaps xmm2, [rsp+0x20]
000071ff71bdffde  vmovaps xmm3, [rsp+0x30]
000071ff71bdffe4  vmovaps xmm4, [rsp+0x40]
000071ff71bdffea  vmovaps xmm5, [rsp+0x50]
000071ff71bdfff0  vmovaps xmm6, [rsp+0x60]
000071ff71bdfff6  vmovaps xmm7, [rsp+0x70]
000071ff71bdfffc  vmovaps xmm8, [rsp+0x80]
000071ff71be0005  vmovaps xmm9, [rsp+0x90]
000071ff71be000e  vmovaps xmm11, [rsp+0xA0]
000071ff71be0017  vmovaps xmm12, [rsp+0xB0]
000071ff71be0020  vmovaps xmm13, [rsp+0xC0]
000071ff71be0029  vmovaps xmm14, [rsp+0xD0]
000071ff71be0032  vmovaps xmm15, [rsp+0xE0]
000071ff71be003b  add rsp, 0xF0
000071ff71be0042  pop r11
000071ff71be0044  pop r10
000071ff71be0046  pop r9
000071ff71be0048  pop r8
000071ff71be004a  pop rsi
000071ff71be004b  pop rdi
000071ff71be004c  pop rdx
000071ff71be004d  pop rcx
000071ff71be004e  pop rax
000071ff71be004f  add rsp, 0x08
000071ff71be0053  jmp 0x000071FF71BDED93
000071ff71be0058  sub rsp, 0x08
000071ff71be005c  push rax
000071ff71be005d  push rcx
000071ff71be005e  push rdx
000071ff71be005f  push rdi
000071ff71be0060  push rsi
000071ff71be0061  push r8
000071ff71be0063  push r9
000071ff71be0065  push r10
000071ff71be0067  push r11
000071ff71be0069  sub rsp, 0xF0
000071ff71be0070  vmovaps [rsp], xmm0
000071ff71be0075  vmovaps [rsp+0x10], xmm1
000071ff71be007b  vmovaps [rsp+0x20], xmm2
000071ff71be0081  vmovaps [rsp+0x30], xmm3
000071ff71be0087  vmovaps [rsp+0x40], xmm4
000071ff71be008d  vmovaps [rsp+0x50], xmm5
000071ff71be0093  vmovaps [rsp+0x60], xmm7
000071ff71be0099  vmovaps [rsp+0x70], xmm8
000071ff71be009f  vmovaps [rsp+0x80], xmm9
000071ff71be00a8  vmovaps [rsp+0x90], xmm10
000071ff71be00b1  vmovaps [rsp+0xA0], xmm11
000071ff71be00ba  vmovaps [rsp+0xB0], xmm12
000071ff71be00c3  vmovaps [rsp+0xC0], xmm13
000071ff71be00cc  vmovaps [rsp+0xD0], xmm14
000071ff71be00d5  vmovaps [rsp+0xE0], xmm15
000071ff71be00de  sub rsp, 0x30
000071ff71be00e2  movaps [rsp], xmm6
000071ff71be00e6  movaps [rsp+0x10], xmm12
000071ff71be00ec  movaps [rsp+0x20], xmm11
000071ff71be00f2  lea rdi, [rsp]
000071ff71be00f6  mov esi, 0x00
000071ff71be00fb  mov rax, 0x5E6872E10530
000071ff71be0105  call rax
000071ff71be0107  movaps xmm6, [rsp]
000071ff71be010b  add rsp, 0x30
000071ff71be010f  vmovaps xmm0, [rsp]
000071ff71be0114  vmovaps xmm1, [rsp+0x10]
000071ff71be011a  vmovaps xmm2, [rsp+0x20]
000071ff71be0120  vmovaps xmm3, [rsp+0x30]
000071ff71be0126  vmovaps xmm4, [rsp+0x40]
000071ff71be012c  vmovaps xmm5, [rsp+0x50]
000071ff71be0132  vmovaps xmm7, [rsp+0x60]
000071ff71be0138  vmovaps xmm8, [rsp+0x70]
000071ff71be013e  vmovaps xmm9, [rsp+0x80]
000071ff71be0147  vmovaps xmm10, [rsp+0x90]
000071ff71be0150  vmovaps xmm11, [rsp+0xA0]
000071ff71be0159  vmovaps xmm12, [rsp+0xB0]
000071ff71be0162  vmovaps xmm13, [rsp+0xC0]
000071ff71be016b  vmovaps xmm14, [rsp+0xD0]
000071ff71be0174  vmovaps xmm15, [rsp+0xE0]
000071ff71be017d  add rsp, 0xF0
000071ff71be0184  pop r11
000071ff71be0186  pop r10
000071ff71be0188  pop r9
000071ff71be018a  pop r8
000071ff71be018c  pop rsi
000071ff71be018d  pop rdi
000071ff71be018e  pop rdx
000071ff71be018f  pop rcx
000071ff71be0190  pop rax
000071ff71be0191  add rsp, 0x08
000071ff71be0195  jmp 0x000071FF71BDEDB4
000071ff71be019a  sub rsp, 0x08
000071ff71be019e  push rax
000071ff71be019f  push rcx
000071ff71be01a0  push rdx
000071ff71be01a1  push rdi
000071ff71be01a2  push rsi
000071ff71be01a3  push r8
000071ff71be01a5  push r9
000071ff71be01a7  push r10
000071ff71be01a9  push r11
000071ff71be01ab  sub rsp, 0xF0
000071ff71be01b2  vmovaps [rsp], xmm0
000071ff71be01b7  vmovaps [rsp+0x10], xmm1
000071ff71be01bd  vmovaps [rsp+0x20], xmm2
000071ff71be01c3  vmovaps [rsp+0x30], xmm4
000071ff71be01c9  vmovaps [rsp+0x40], xmm5
000071ff71be01cf  vmovaps [rsp+0x50], xmm6
000071ff71be01d5  vmovaps [rsp+0x60], xmm7
000071ff71be01db  vmovaps [rsp+0x70], xmm8
000071ff71be01e1  vmovaps [rsp+0x80], xmm9
000071ff71be01ea  vmovaps [rsp+0x90], xmm10
000071ff71be01f3  vmovaps [rsp+0xA0], xmm11
000071ff71be01fc  vmovaps [rsp+0xB0], xmm12
000071ff71be0205  vmovaps [rsp+0xC0], xmm13
000071ff71be020e  vmovaps [rsp+0xD0], xmm14
000071ff71be0217  vmovaps [rsp+0xE0], xmm15
000071ff71be0220  sub rsp, 0x30
000071ff71be0224  movaps [rsp], xmm3
000071ff71be0228  movaps [rsp+0x10], xmm5
000071ff71be022d  movaps [rsp+0x20], xmm4
000071ff71be0232  lea rdi, [rsp]
000071ff71be0236  mov esi, 0x00
000071ff71be023b  mov rax, 0x5E6872E10530
000071ff71be0245  call rax
000071ff71be0247  movaps xmm3, [rsp]
000071ff71be024b  add rsp, 0x30
000071ff71be024f  vmovaps xmm0, [rsp]
000071ff71be0254  vmovaps xmm1, [rsp+0x10]
000071ff71be025a  vmovaps xmm2, [rsp+0x20]
000071ff71be0260  vmovaps xmm4, [rsp+0x30]
000071ff71be0266  vmovaps xmm5, [rsp+0x40]
000071ff71be026c  vmovaps xmm6, [rsp+0x50]
000071ff71be0272  vmovaps xmm7, [rsp+0x60]
000071ff71be0278  vmovaps xmm8, [rsp+0x70]
000071ff71be027e  vmovaps xmm9, [rsp+0x80]
000071ff71be0287  vmovaps xmm10, [rsp+0x90]
000071ff71be0290  vmovaps xmm11, [rsp+0xA0]
000071ff71be0299  vmovaps xmm12, [rsp+0xB0]
000071ff71be02a2  vmovaps xmm13, [rsp+0xC0]
000071ff71be02ab  vmovaps xmm14, [rsp+0xD0]
000071ff71be02b4  vmovaps xmm15, [rsp+0xE0]
000071ff71be02bd  add rsp, 0xF0
000071ff71be02c4  pop r11
000071ff71be02c6  pop r10
000071ff71be02c8  pop r9
000071ff71be02ca  pop r8
000071ff71be02cc  pop rsi
000071ff71be02cd  pop rdi
000071ff71be02ce  pop rdx
000071ff71be02cf  pop rcx
000071ff71be02d0  pop rax
000071ff71be02d1  add rsp, 0x08
000071ff71be02d5  jmp 0x000071FF71BDEE15
000071ff71be02da  sub rsp, 0x08
000071ff71be02de  push rax
000071ff71be02df  push rcx
000071ff71be02e0  push rdx
000071ff71be02e1  push rdi
000071ff71be02e2  push rsi
000071ff71be02e3  push r8
000071ff71be02e5  push r9
000071ff71be02e7  push r10
000071ff71be02e9  push r11
000071ff71be02eb  sub rsp, 0xF0
000071ff71be02f2  vmovaps [rsp], xmm0
000071ff71be02f7  vmovaps [rsp+0x10], xmm1
000071ff71be02fd  vmovaps [rsp+0x20], xmm2
000071ff71be0303  vmovaps [rsp+0x30], xmm3
000071ff71be0309  vmovaps [rsp+0x40], xmm4
000071ff71be030f  vmovaps [rsp+0x50], xmm6
000071ff71be0315  vmovaps [rsp+0x60], xmm7
000071ff71be031b  vmovaps [rsp+0x70], xmm8
000071ff71be0321  vmovaps [rsp+0x80], xmm9
000071ff71be032a  vmovaps [rsp+0x90], xmm10
000071ff71be0333  vmovaps [rsp+0xA0], xmm11
000071ff71be033c  vmovaps [rsp+0xB0], xmm12
000071ff71be0345  vmovaps [rsp+0xC0], xmm13
000071ff71be034e  vmovaps [rsp+0xD0], xmm14
000071ff71be0357  vmovaps [rsp+0xE0], xmm15
000071ff71be0360  sub rsp, 0x30
000071ff71be0364  movaps [rsp], xmm5
000071ff71be0368  movaps [rsp+0x10], xmm8
000071ff71be036e  movaps [rsp+0x20], xmm15
000071ff71be0374  lea rdi, [rsp]
000071ff71be0378  mov esi, 0x00
000071ff71be037d  mov rax, 0x5E6872E10530
000071ff71be0387  call rax
000071ff71be0389  movaps xmm5, [rsp]
000071ff71be038d  add rsp, 0x30
000071ff71be0391  vmovaps xmm0, [rsp]
000071ff71be0396  vmovaps xmm1, [rsp+0x10]
000071ff71be039c  vmovaps xmm2, [rsp+0x20]
000071ff71be03a2  vmovaps xmm3, [rsp+0x30]
000071ff71be03a8  vmovaps xmm4, [rsp+0x40]
000071ff71be03ae  vmovaps xmm6, [rsp+0x50]
000071ff71be03b4  vmovaps xmm7, [rsp+0x60]
000071ff71be03ba  vmovaps xmm8, [rsp+0x70]
000071ff71be03c0  vmovaps xmm9, [rsp+0x80]
000071ff71be03c9  vmovaps xmm10, [rsp+0x90]
000071ff71be03d2  vmovaps xmm11, [rsp+0xA0]
000071ff71be03db  vmovaps xmm12, [rsp+0xB0]
000071ff71be03e4  vmovaps xmm13, [rsp+0xC0]
000071ff71be03ed  vmovaps xmm14, [rsp+0xD0]
000071ff71be03f6  vmovaps xmm15, [rsp+0xE0]
000071ff71be03ff  add rsp, 0xF0
000071ff71be0406  pop r11
000071ff71be0408  pop r10
000071ff71be040a  pop r9
000071ff71be040c  pop r8
000071ff71be040e  pop rsi
000071ff71be040f  pop rdi
000071ff71be0410  pop rdx
000071ff71be0411  pop rcx
000071ff71be0412  pop rax
000071ff71be0413  add rsp, 0x08
000071ff71be0417  jmp 0x000071FF71BDEE53
000071ff71be041c  sub rsp, 0x08
000071ff71be0420  push rax
000071ff71be0421  push rcx
000071ff71be0422  push rdx
000071ff71be0423  push rdi
000071ff71be0424  push rsi
000071ff71be0425  push r8
000071ff71be0427  push r9
000071ff71be0429  push r10
000071ff71be042b  push r11
000071ff71be042d  sub rsp, 0xF0
000071ff71be0434  vmovaps [rsp], xmm0
000071ff71be0439  vmovaps [rsp+0x10], xmm1
000071ff71be043f  vmovaps [rsp+0x20], xmm2
000071ff71be0445  vmovaps [rsp+0x30], xmm3
000071ff71be044b  vmovaps [rsp+0x40], xmm5
000071ff71be0451  vmovaps [rsp+0x50], xmm6
000071ff71be0457  vmovaps [rsp+0x60], xmm7
000071ff71be045d  vmovaps [rsp+0x70], xmm8
000071ff71be0463  vmovaps [rsp+0x80], xmm9
000071ff71be046c  vmovaps [rsp+0x90], xmm10
000071ff71be0475  vmovaps [rsp+0xA0], xmm11
000071ff71be047e  vmovaps [rsp+0xB0], xmm12
000071ff71be0487  vmovaps [rsp+0xC0], xmm13
000071ff71be0490  vmovaps [rsp+0xD0], xmm14
000071ff71be0499  vmovaps [rsp+0xE0], xmm15
000071ff71be04a2  sub rsp, 0x30
000071ff71be04a6  movaps [rsp], xmm4
000071ff71be04aa  movaps [rsp+0x10], xmm9
000071ff71be04b0  movaps [rsp+0x20], xmm8
000071ff71be04b6  lea rdi, [rsp]
000071ff71be04ba  mov esi, 0x00
000071ff71be04bf  mov rax, 0x5E6872E10530
000071ff71be04c9  call rax
000071ff71be04cb  movaps xmm4, [rsp]
000071ff71be04cf  add rsp, 0x30
000071ff71be04d3  vmovaps xmm0, [rsp]
000071ff71be04d8  vmovaps xmm1, [rsp+0x10]
000071ff71be04de  vmovaps xmm2, [rsp+0x20]
000071ff71be04e4  vmovaps xmm3, [rsp+0x30]
000071ff71be04ea  vmovaps xmm5, [rsp+0x40]
000071ff71be04f0  vmovaps xmm6, [rsp+0x50]
000071ff71be04f6  vmovaps xmm7, [rsp+0x60]
000071ff71be04fc  vmovaps xmm8, [rsp+0x70]
000071ff71be0502  vmovaps xmm9, [rsp+0x80]
000071ff71be050b  vmovaps xmm10, [rsp+0x90]
000071ff71be0514  vmovaps xmm11, [rsp+0xA0]
000071ff71be051d  vmovaps xmm12, [rsp+0xB0]
000071ff71be0526  vmovaps xmm13, [rsp+0xC0]
000071ff71be052f  vmovaps xmm14, [rsp+0xD0]
000071ff71be0538  vmovaps xmm15, [rsp+0xE0]
000071ff71be0541  add rsp, 0xF0
000071ff71be0548  pop r11
000071ff71be054a  pop r10
000071ff71be054c  pop r9
000071ff71be054e  pop r8
000071ff71be0550  pop rsi
000071ff71be0551  pop rdi
000071ff71be0552  pop rdx
000071ff71be0553  pop rcx
000071ff71be0554  pop rax
000071ff71be0555  add rsp, 0x08
000071ff71be0559  jmp 0x000071FF71BDEE74
000071ff71be055e  sub rsp, 0x08
000071ff71be0562  push rax
000071ff71be0563  push rcx
000071ff71be0564  push rdx
000071ff71be0565  push rdi
000071ff71be0566  push rsi
000071ff71be0567  push r8
000071ff71be0569  push r9
000071ff71be056b  push r10
000071ff71be056d  push r11
000071ff71be056f  sub rsp, 0xF0
000071ff71be0576  vmovaps [rsp], xmm0
000071ff71be057b  vmovaps [rsp+0x10], xmm1
000071ff71be0581  vmovaps [rsp+0x20], xmm2
000071ff71be0587  vmovaps [rsp+0x30], xmm3
000071ff71be058d  vmovaps [rsp+0x40], xmm4
000071ff71be0593  vmovaps [rsp+0x50], xmm5
000071ff71be0599  vmovaps [rsp+0x60], xmm6
000071ff71be059f  vmovaps [rsp+0x70], xmm7
000071ff71be05a5  vmovaps [rsp+0x80], xmm8
000071ff71be05ae  vmovaps [rsp+0x90], xmm10
000071ff71be05b7  vmovaps [rsp+0xA0], xmm11
000071ff71be05c0  vmovaps [rsp+0xB0], xmm12
000071ff71be05c9  vmovaps [rsp+0xC0], xmm13
000071ff71be05d2  vmovaps [rsp+0xD0], xmm14
000071ff71be05db  vmovaps [rsp+0xE0], xmm15
000071ff71be05e4  sub rsp, 0x30
000071ff71be05e8  movaps [rsp], xmm9
000071ff71be05ed  movaps [rsp+0x10], xmm10
000071ff71be05f3  movaps [rsp+0x20], xmm8
000071ff71be05f9  lea rdi, [rsp]
000071ff71be05fd  mov esi, 0x00
000071ff71be0602  mov rax, 0x5E6872E10530
000071ff71be060c  call rax
000071ff71be060e  movaps xmm9, [rsp]
000071ff71be0613  add rsp, 0x30
000071ff71be0617  vmovaps xmm0, [rsp]
000071ff71be061c  vmovaps xmm1, [rsp+0x10]
000071ff71be0622  vmovaps xmm2, [rsp+0x20]
000071ff71be0628  vmovaps xmm3, [rsp+0x30]
000071ff71be062e  vmovaps xmm4, [rsp+0x40]
000071ff71be0634  vmovaps xmm5, [rsp+0x50]
000071ff71be063a  vmovaps xmm6, [rsp+0x60]
000071ff71be0640  vmovaps xmm7, [rsp+0x70]
000071ff71be0646  vmovaps xmm8, [rsp+0x80]
000071ff71be064f  vmovaps xmm10, [rsp+0x90]
000071ff71be0658  vmovaps xmm11, [rsp+0xA0]
000071ff71be0661  vmovaps xmm12, [rsp+0xB0]
000071ff71be066a  vmovaps xmm13, [rsp+0xC0]
000071ff71be0673  vmovaps xmm14, [rsp+0xD0]
000071ff71be067c  vmovaps xmm15, [rsp+0xE0]
000071ff71be0685  add rsp, 0xF0
000071ff71be068c  pop r11
000071ff71be068e  pop r10
000071ff71be0690  pop r9
000071ff71be0692  pop r8
000071ff71be0694  pop rsi
000071ff71be0695  pop rdi
000071ff71be0696  pop rdx
000071ff71be0697  pop rcx
000071ff71be0698  pop rax
000071ff71be0699  add rsp, 0x08
000071ff71be069d  jmp 0x000071FF71BDEE8E
000071ff71be06a2  call 0x000071FF71AB52F0
000071ff71be06a7  jmp 0x000071FF71BDEFA8
000071ff71be06ac  call 0x000071FF71AB52F0
000071ff71be06b1  jmp 0x000071FF71BDEFBE
000071ff71be06b6  sub rsp, 0x08
000071ff71be06ba  push rax
000071ff71be06bb  push rcx
000071ff71be06bc  push rdx
000071ff71be06bd  push rdi
000071ff71be06be  push rsi
000071ff71be06bf  push r8
000071ff71be06c1  push r9
000071ff71be06c3  push r10
000071ff71be06c5  push r11
000071ff71be06c7  sub rsp, 0xF0
000071ff71be06ce  vmovaps [rsp], xmm0
000071ff71be06d3  vmovaps [rsp+0x10], xmm2
000071ff71be06d9  vmovaps [rsp+0x20], xmm3
000071ff71be06df  vmovaps [rsp+0x30], xmm4
000071ff71be06e5  vmovaps [rsp+0x40], xmm5
000071ff71be06eb  vmovaps [rsp+0x50], xmm6
000071ff71be06f1  vmovaps [rsp+0x60], xmm7
000071ff71be06f7  vmovaps [rsp+0x70], xmm8
000071ff71be06fd  vmovaps [rsp+0x80], xmm9
000071ff71be0706  vmovaps [rsp+0x90], xmm10
000071ff71be070f  vmovaps [rsp+0xA0], xmm11
000071ff71be0718  vmovaps [rsp+0xB0], xmm12
000071ff71be0721  vmovaps [rsp+0xC0], xmm13
000071ff71be072a  vmovaps [rsp+0xD0], xmm14
000071ff71be0733  vmovaps [rsp+0xE0], xmm15
000071ff71be073c  sub rsp, 0x30
000071ff71be0740  movaps [rsp], xmm1
000071ff71be0744  movaps [rsp+0x10], xmm6
000071ff71be0749  movaps [rsp+0x20], xmm15
000071ff71be074f  lea rdi, [rsp]
000071ff71be0753  mov esi, 0x00
000071ff71be0758  mov rax, 0x5E6872E10530
000071ff71be0762  call rax
000071ff71be0764  movaps xmm1, [rsp]
000071ff71be0768  add rsp, 0x30
000071ff71be076c  vmovaps xmm0, [rsp]
000071ff71be0771  vmovaps xmm2, [rsp+0x10]
000071ff71be0777  vmovaps xmm3, [rsp+0x20]
000071ff71be077d  vmovaps xmm4, [rsp+0x30]
000071ff71be0783  vmovaps xmm5, [rsp+0x40]
000071ff71be0789  vmovaps xmm6, [rsp+0x50]
000071ff71be078f  vmovaps xmm7, [rsp+0x60]
000071ff71be0795  vmovaps xmm8, [rsp+0x70]
000071ff71be079b  vmovaps xmm9, [rsp+0x80]
000071ff71be07a4  vmovaps xmm10, [rsp+0x90]
000071ff71be07ad  vmovaps xmm11, [rsp+0xA0]
000071ff71be07b6  vmovaps xmm12, [rsp+0xB0]
000071ff71be07bf  vmovaps xmm13, [rsp+0xC0]
000071ff71be07c8  vmovaps xmm14, [rsp+0xD0]
000071ff71be07d1  vmovaps xmm15, [rsp+0xE0]
000071ff71be07da  add rsp, 0xF0
000071ff71be07e1  pop r11
000071ff71be07e3  pop r10
000071ff71be07e5  pop r9
000071ff71be07e7  pop r8
000071ff71be07e9  pop rsi
000071ff71be07ea  pop rdi
000071ff71be07eb  pop rdx
000071ff71be07ec  pop rcx
000071ff71be07ed  pop rax
000071ff71be07ee  add rsp, 0x08
000071ff71be07f2  jmp 0x000071FF71BDEFFB
000071ff71be07f7  call 0x000071FF71AC4620
000071ff71be07fc  jmp 0x000071FF71BDF008
000071ff71be0801  sub rsp, 0x08
000071ff71be0805  push rax
000071ff71be0806  push rcx
000071ff71be0807  push rdx
000071ff71be0808  push rdi
000071ff71be0809  push rsi
000071ff71be080a  push r8
000071ff71be080c  push r9
000071ff71be080e  push r10
000071ff71be0810  push r11
000071ff71be0812  sub rsp, 0xF0
000071ff71be0819  vmovaps [rsp], xmm0
000071ff71be081e  vmovaps [rsp+0x10], xmm1
000071ff71be0824  vmovaps [rsp+0x20], xmm2
000071ff71be082a  vmovaps [rsp+0x30], xmm3
000071ff71be0830  vmovaps [rsp+0x40], xmm4
000071ff71be0836  vmovaps [rsp+0x50], xmm5
000071ff71be083c  vmovaps [rsp+0x60], xmm6
000071ff71be0842  vmovaps [rsp+0x70], xmm7
000071ff71be0848  vmovaps [rsp+0x80], xmm8
000071ff71be0851  vmovaps [rsp+0x90], xmm9
000071ff71be085a  vmovaps [rsp+0xA0], xmm10
000071ff71be0863  vmovaps [rsp+0xB0], xmm11
000071ff71be086c  vmovaps [rsp+0xC0], xmm12
000071ff71be0875  vmovaps [rsp+0xD0], xmm13
000071ff71be087e  vmovaps [rsp+0xE0], xmm15
000071ff71be0887  sub rsp, 0x30
000071ff71be088b  movaps [rsp], xmm14
000071ff71be0890  movaps [rsp+0x10], xmm4
000071ff71be0895  movaps [rsp+0x20], xmm3
000071ff71be089a  lea rdi, [rsp]
000071ff71be089e  mov esi, 0x00
000071ff71be08a3  mov rax, 0x5E6872E10530
000071ff71be08ad  call rax
000071ff71be08af  movaps xmm14, [rsp]
000071ff71be08b4  add rsp, 0x30
000071ff71be08b8  vmovaps xmm0, [rsp]
000071ff71be08bd  vmovaps xmm1, [rsp+0x10]
000071ff71be08c3  vmovaps xmm2, [rsp+0x20]
000071ff71be08c9  vmovaps xmm3, [rsp+0x30]
000071ff71be08cf  vmovaps xmm4, [rsp+0x40]
000071ff71be08d5  vmovaps xmm5, [rsp+0x50]
000071ff71be08db  vmovaps xmm6, [rsp+0x60]
000071ff71be08e1  vmovaps xmm7, [rsp+0x70]
000071ff71be08e7  vmovaps xmm8, [rsp+0x80]
000071ff71be08f0  vmovaps xmm9, [rsp+0x90]
000071ff71be08f9  vmovaps xmm10, [rsp+0xA0]
000071ff71be0902  vmovaps xmm11, [rsp+0xB0]
000071ff71be090b  vmovaps xmm12, [rsp+0xC0]
000071ff71be0914  vmovaps xmm13, [rsp+0xD0]
000071ff71be091d  vmovaps xmm15, [rsp+0xE0]
000071ff71be0926  add rsp, 0xF0
000071ff71be092d  pop r11
000071ff71be092f  pop r10
000071ff71be0931  pop r9
000071ff71be0933  pop r8
000071ff71be0935  pop rsi
000071ff71be0936  pop rdi
000071ff71be0937  pop rdx
000071ff71be0938  pop rcx
000071ff71be0939  pop rax
000071ff71be093a  add rsp, 0x08
000071ff71be093e  jmp 0x000071FF71BDF022
000071ff71be0943  sub rsp, 0x08
000071ff71be0947  push rax
000071ff71be0948  push rcx
000071ff71be0949  push rdx
000071ff71be094a  push rdi
000071ff71be094b  push rsi
000071ff71be094c  push r8
000071ff71be094e  push r9
000071ff71be0950  push r10
000071ff71be0952  push r11
000071ff71be0954  sub rsp, 0xF0
000071ff71be095b  vmovaps [rsp], xmm0
000071ff71be0960  vmovaps [rsp+0x10], xmm1
000071ff71be0966  vmovaps [rsp+0x20], xmm2
000071ff71be096c  vmovaps [rsp+0x30], xmm3
000071ff71be0972  vmovaps [rsp+0x40], xmm4
000071ff71be0978  vmovaps [rsp+0x50], xmm5
000071ff71be097e  vmovaps [rsp+0x60], xmm7
000071ff71be0984  vmovaps [rsp+0x70], xmm8
000071ff71be098a  vmovaps [rsp+0x80], xmm9
000071ff71be0993  vmovaps [rsp+0x90], xmm10
000071ff71be099c  vmovaps [rsp+0xA0], xmm11
000071ff71be09a5  vmovaps [rsp+0xB0], xmm12
000071ff71be09ae  vmovaps [rsp+0xC0], xmm13
000071ff71be09b7  vmovaps [rsp+0xD0], xmm14
000071ff71be09c0  vmovaps [rsp+0xE0], xmm15
000071ff71be09c9  sub rsp, 0x30
000071ff71be09cd  movaps [rsp], xmm6
000071ff71be09d1  movaps [rsp+0x10], xmm9
000071ff71be09d7  movaps [rsp+0x20], xmm7
000071ff71be09dc  lea rdi, [rsp]
000071ff71be09e0  mov esi, 0x00
000071ff71be09e5  mov rax, 0x5E6872E10530
000071ff71be09ef  call rax
000071ff71be09f1  movaps xmm6, [rsp]
000071ff71be09f5  add rsp, 0x30
000071ff71be09f9  vmovaps xmm0, [rsp]
000071ff71be09fe  vmovaps xmm1, [rsp+0x10]
000071ff71be0a04  vmovaps xmm2, [rsp+0x20]
000071ff71be0a0a  vmovaps xmm3, [rsp+0x30]
000071ff71be0a10  vmovaps xmm4, [rsp+0x40]
000071ff71be0a16  vmovaps xmm5, [rsp+0x50]
000071ff71be0a1c  vmovaps xmm7, [rsp+0x60]
000071ff71be0a22  vmovaps xmm8, [rsp+0x70]
000071ff71be0a28  vmovaps xmm9, [rsp+0x80]
000071ff71be0a31  vmovaps xmm10, [rsp+0x90]
000071ff71be0a3a  vmovaps xmm11, [rsp+0xA0]
000071ff71be0a43  vmovaps xmm12, [rsp+0xB0]
000071ff71be0a4c  vmovaps xmm13, [rsp+0xC0]
000071ff71be0a55  vmovaps xmm14, [rsp+0xD0]
000071ff71be0a5e  vmovaps xmm15, [rsp+0xE0]
000071ff71be0a67  add rsp, 0xF0
000071ff71be0a6e  pop r11
000071ff71be0a70  pop r10
000071ff71be0a72  pop r9
000071ff71be0a74  pop r8
000071ff71be0a76  pop rsi
000071ff71be0a77  pop rdi
000071ff71be0a78  pop rdx
000071ff71be0a79  pop rcx
000071ff71be0a7a  pop rax
000071ff71be0a7b  add rsp, 0x08
000071ff71be0a7f  jmp 0x000071FF71BDF03A
000071ff71be0a84  sub rsp, 0x08
000071ff71be0a88  push rax
000071ff71be0a89  push rcx
000071ff71be0a8a  push rdx
000071ff71be0a8b  push rdi
000071ff71be0a8c  push rsi
000071ff71be0a8d  push r8
000071ff71be0a8f  push r9
000071ff71be0a91  push r10
000071ff71be0a93  push r11
000071ff71be0a95  sub rsp, 0xF0
000071ff71be0a9c  vmovaps [rsp], xmm0
000071ff71be0aa1  vmovaps [rsp+0x10], xmm1
000071ff71be0aa7  vmovaps [rsp+0x20], xmm2
000071ff71be0aad  vmovaps [rsp+0x30], xmm3
000071ff71be0ab3  vmovaps [rsp+0x40], xmm4
000071ff71be0ab9  vmovaps [rsp+0x50], xmm5
000071ff71be0abf  vmovaps [rsp+0x60], xmm6
000071ff71be0ac5  vmovaps [rsp+0x70], xmm8
000071ff71be0acb  vmovaps [rsp+0x80], xmm9
000071ff71be0ad4  vmovaps [rsp+0x90], xmm10
000071ff71be0add  vmovaps [rsp+0xA0], xmm11
000071ff71be0ae6  vmovaps [rsp+0xB0], xmm12
000071ff71be0aef  vmovaps [rsp+0xC0], xmm13
000071ff71be0af8  vmovaps [rsp+0xD0], xmm14
000071ff71be0b01  vmovaps [rsp+0xE0], xmm15
000071ff71be0b0a  sub rsp, 0x30
000071ff71be0b0e  movaps [rsp], xmm7
000071ff71be0b12  movaps [rsp+0x10], xmm4
000071ff71be0b17  movaps [rsp+0x20], xmm9
000071ff71be0b1d  lea rdi, [rsp]
000071ff71be0b21  mov esi, 0x00
000071ff71be0b26  mov rax, 0x5E6872E10530
000071ff71be0b30  call rax
000071ff71be0b32  movaps xmm7, [rsp]
000071ff71be0b36  add rsp, 0x30
000071ff71be0b3a  vmovaps xmm0, [rsp]
000071ff71be0b3f  vmovaps xmm1, [rsp+0x10]
000071ff71be0b45  vmovaps xmm2, [rsp+0x20]
000071ff71be0b4b  vmovaps xmm3, [rsp+0x30]
000071ff71be0b51  vmovaps xmm4, [rsp+0x40]
000071ff71be0b57  vmovaps xmm5, [rsp+0x50]
000071ff71be0b5d  vmovaps xmm6, [rsp+0x60]
000071ff71be0b63  vmovaps xmm8, [rsp+0x70]
000071ff71be0b69  vmovaps xmm9, [rsp+0x80]
000071ff71be0b72  vmovaps xmm10, [rsp+0x90]
000071ff71be0b7b  vmovaps xmm11, [rsp+0xA0]
000071ff71be0b84  vmovaps xmm12, [rsp+0xB0]
000071ff71be0b8d  vmovaps xmm13, [rsp+0xC0]
000071ff71be0b96  vmovaps xmm14, [rsp+0xD0]
000071ff71be0b9f  vmovaps xmm15, [rsp+0xE0]
000071ff71be0ba8  add rsp, 0xF0
000071ff71be0baf  pop r11
000071ff71be0bb1  pop r10
000071ff71be0bb3  pop r9
000071ff71be0bb5  pop r8
000071ff71be0bb7  pop rsi
000071ff71be0bb8  pop rdi
000071ff71be0bb9  pop rdx
000071ff71be0bba  pop rcx
000071ff71be0bbb  pop rax
000071ff71be0bbc  add rsp, 0x08
000071ff71be0bc0  jmp 0x000071FF71BDF067
000071ff71be0bc5  sub rsp, 0x08
000071ff71be0bc9  push rax
000071ff71be0bca  push rcx
000071ff71be0bcb  push rdx
000071ff71be0bcc  push rdi
000071ff71be0bcd  push rsi
000071ff71be0bce  push r8
000071ff71be0bd0  push r9
000071ff71be0bd2  push r10
000071ff71be0bd4  push r11
000071ff71be0bd6  sub rsp, 0xF0
000071ff71be0bdd  vmovaps [rsp], xmm0
000071ff71be0be2  vmovaps [rsp+0x10], xmm1
000071ff71be0be8  vmovaps [rsp+0x20], xmm2
000071ff71be0bee  vmovaps [rsp+0x30], xmm3
000071ff71be0bf4  vmovaps [rsp+0x40], xmm5
000071ff71be0bfa  vmovaps [rsp+0x50], xmm6
000071ff71be0c00  vmovaps [rsp+0x60], xmm7
000071ff71be0c06  vmovaps [rsp+0x70], xmm8
000071ff71be0c0c  vmovaps [rsp+0x80], xmm9
000071ff71be0c15  vmovaps [rsp+0x90], xmm10
000071ff71be0c1e  vmovaps [rsp+0xA0], xmm11
000071ff71be0c27  vmovaps [rsp+0xB0], xmm12
000071ff71be0c30  vmovaps [rsp+0xC0], xmm13
000071ff71be0c39  vmovaps [rsp+0xD0], xmm14
000071ff71be0c42  vmovaps [rsp+0xE0], xmm15
000071ff71be0c4b  sub rsp, 0x30
000071ff71be0c4f  movaps [rsp], xmm4
000071ff71be0c53  movaps [rsp+0x10], xmm15
000071ff71be0c59  movaps [rsp+0x20], xmm9
000071ff71be0c5f  lea rdi, [rsp]
000071ff71be0c63  mov esi, 0x00
000071ff71be0c68  mov rax, 0x5E6872E10530
000071ff71be0c72  call rax
000071ff71be0c74  movaps xmm4, [rsp]
000071ff71be0c78  add rsp, 0x30
000071ff71be0c7c  vmovaps xmm0, [rsp]
000071ff71be0c81  vmovaps xmm1, [rsp+0x10]
000071ff71be0c87  vmovaps xmm2, [rsp+0x20]
000071ff71be0c8d  vmovaps xmm3, [rsp+0x30]
000071ff71be0c93  vmovaps xmm5, [rsp+0x40]
000071ff71be0c99  vmovaps xmm6, [rsp+0x50]
000071ff71be0c9f  vmovaps xmm7, [rsp+0x60]
000071ff71be0ca5  vmovaps xmm8, [rsp+0x70]
000071ff71be0cab  vmovaps xmm9, [rsp+0x80]
000071ff71be0cb4  vmovaps xmm10, [rsp+0x90]
000071ff71be0cbd  vmovaps xmm11, [rsp+0xA0]
000071ff71be0cc6  vmovaps xmm12, [rsp+0xB0]
000071ff71be0ccf  vmovaps xmm13, [rsp+0xC0]
000071ff71be0cd8  vmovaps xmm14, [rsp+0xD0]
000071ff71be0ce1  vmovaps xmm15, [rsp+0xE0]
000071ff71be0cea  add rsp, 0xF0
000071ff71be0cf1  pop r11
000071ff71be0cf3  pop r10
000071ff71be0cf5  pop r9
000071ff71be0cf7  pop r8
000071ff71be0cf9  pop rsi
000071ff71be0cfa  pop rdi
000071ff71be0cfb  pop rdx
000071ff71be0cfc  pop rcx
000071ff71be0cfd  pop rax
000071ff71be0cfe  add rsp, 0x08
000071ff71be0d02  jmp 0x000071FF71BDF08C
000071ff71be0d07  call 0x000071FF71AC4620
000071ff71be0d0c  jmp 0x000071FF71BDF099
000071ff71be0d11  sub rsp, 0x08
000071ff71be0d15  push rax
000071ff71be0d16  push rcx
000071ff71be0d17  push rdx
000071ff71be0d18  push rdi
000071ff71be0d19  push rsi
000071ff71be0d1a  push r8
000071ff71be0d1c  push r9
000071ff71be0d1e  push r10
000071ff71be0d20  push r11
000071ff71be0d22  sub rsp, 0xF0
000071ff71be0d29  vmovaps [rsp], xmm0
000071ff71be0d2e  vmovaps [rsp+0x10], xmm1
000071ff71be0d34  vmovaps [rsp+0x20], xmm2
000071ff71be0d3a  vmovaps [rsp+0x30], xmm4
000071ff71be0d40  vmovaps [rsp+0x40], xmm5
000071ff71be0d46  vmovaps [rsp+0x50], xmm6
000071ff71be0d4c  vmovaps [rsp+0x60], xmm7
000071ff71be0d52  vmovaps [rsp+0x70], xmm8
000071ff71be0d58  vmovaps [rsp+0x80], xmm9
000071ff71be0d61  vmovaps [rsp+0x90], xmm10
000071ff71be0d6a  vmovaps [rsp+0xA0], xmm11
000071ff71be0d73  vmovaps [rsp+0xB0], xmm12
000071ff71be0d7c  vmovaps [rsp+0xC0], xmm13
000071ff71be0d85  vmovaps [rsp+0xD0], xmm14
000071ff71be0d8e  vmovaps [rsp+0xE0], xmm15
000071ff71be0d97  sub rsp, 0x30
000071ff71be0d9b  movaps [rsp], xmm3
000071ff71be0d9f  movaps [rsp+0x10], xmm1
000071ff71be0da4  movaps [rsp+0x20], xmm9
000071ff71be0daa  lea rdi, [rsp]
000071ff71be0dae  mov esi, 0x00
000071ff71be0db3  mov rax, 0x5E6872E10530
000071ff71be0dbd  call rax
000071ff71be0dbf  movaps xmm3, [rsp]
000071ff71be0dc3  add rsp, 0x30
000071ff71be0dc7  vmovaps xmm0, [rsp]
000071ff71be0dcc  vmovaps xmm1, [rsp+0x10]
000071ff71be0dd2  vmovaps xmm2, [rsp+0x20]
000071ff71be0dd8  vmovaps xmm4, [rsp+0x30]
000071ff71be0dde  vmovaps xmm5, [rsp+0x40]
000071ff71be0de4  vmovaps xmm6, [rsp+0x50]
000071ff71be0dea  vmovaps xmm7, [rsp+0x60]
000071ff71be0df0  vmovaps xmm8, [rsp+0x70]
000071ff71be0df6  vmovaps xmm9, [rsp+0x80]
000071ff71be0dff  vmovaps xmm10, [rsp+0x90]
000071ff71be0e08  vmovaps xmm11, [rsp+0xA0]
000071ff71be0e11  vmovaps xmm12, [rsp+0xB0]
000071ff71be0e1a  vmovaps xmm13, [rsp+0xC0]
000071ff71be0e23  vmovaps xmm14, [rsp+0xD0]
000071ff71be0e2c  vmovaps xmm15, [rsp+0xE0]
000071ff71be0e35  add rsp, 0xF0
000071ff71be0e3c  pop r11
000071ff71be0e3e  pop r10
000071ff71be0e40  pop r9
000071ff71be0e42  pop r8
000071ff71be0e44  pop rsi
000071ff71be0e45  pop rdi
000071ff71be0e46  pop rdx
000071ff71be0e47  pop rcx
000071ff71be0e48  pop rax
000071ff71be0e49  add rsp, 0x08
000071ff71be0e4d  jmp 0x000071FF71BDF0D6
000071ff71be0e52  sub rsp, 0x08
000071ff71be0e56  push rax
000071ff71be0e57  push rcx
000071ff71be0e58  push rdx
000071ff71be0e59  push rdi
000071ff71be0e5a  push rsi
000071ff71be0e5b  push r8
000071ff71be0e5d  push r9
000071ff71be0e5f  push r10
000071ff71be0e61  push r11
000071ff71be0e63  sub rsp, 0xF0
000071ff71be0e6a  vmovaps [rsp], xmm0
000071ff71be0e6f  vmovaps [rsp+0x10], xmm2
000071ff71be0e75  vmovaps [rsp+0x20], xmm3
000071ff71be0e7b  vmovaps [rsp+0x30], xmm4
000071ff71be0e81  vmovaps [rsp+0x40], xmm5
000071ff71be0e87  vmovaps [rsp+0x50], xmm6
000071ff71be0e8d  vmovaps [rsp+0x60], xmm7
000071ff71be0e93  vmovaps [rsp+0x70], xmm8
000071ff71be0e99  vmovaps [rsp+0x80], xmm9
000071ff71be0ea2  vmovaps [rsp+0x90], xmm10
000071ff71be0eab  vmovaps [rsp+0xA0], xmm11
000071ff71be0eb4  vmovaps [rsp+0xB0], xmm12
000071ff71be0ebd  vmovaps [rsp+0xC0], xmm13
000071ff71be0ec6  vmovaps [rsp+0xD0], xmm14
000071ff71be0ecf  vmovaps [rsp+0xE0], xmm15
000071ff71be0ed8  sub rsp, 0x30
000071ff71be0edc  movaps [rsp], xmm1
000071ff71be0ee0  movaps [rsp+0x10], xmm15
000071ff71be0ee6  movaps [rsp+0x20], xmm9
000071ff71be0eec  lea rdi, [rsp]
000071ff71be0ef0  mov esi, 0x00
000071ff71be0ef5  mov rax, 0x5E6872E10530
000071ff71be0eff  call rax
000071ff71be0f01  movaps xmm1, [rsp]
000071ff71be0f05  add rsp, 0x30
000071ff71be0f09  vmovaps xmm0, [rsp]
000071ff71be0f0e  vmovaps xmm2, [rsp+0x10]
000071ff71be0f14  vmovaps xmm3, [rsp+0x20]
000071ff71be0f1a  vmovaps xmm4, [rsp+0x30]
000071ff71be0f20  vmovaps xmm5, [rsp+0x40]
000071ff71be0f26  vmovaps xmm6, [rsp+0x50]
000071ff71be0f2c  vmovaps xmm7, [rsp+0x60]
000071ff71be0f32  vmovaps xmm8, [rsp+0x70]
000071ff71be0f38  vmovaps xmm9, [rsp+0x80]
000071ff71be0f41  vmovaps xmm10, [rsp+0x90]
000071ff71be0f4a  vmovaps xmm11, [rsp+0xA0]
000071ff71be0f53  vmovaps xmm12, [rsp+0xB0]
000071ff71be0f5c  vmovaps xmm13, [rsp+0xC0]
000071ff71be0f65  vmovaps xmm14, [rsp+0xD0]
000071ff71be0f6e  vmovaps xmm15, [rsp+0xE0]
000071ff71be0f77  add rsp, 0xF0
000071ff71be0f7e  pop r11
000071ff71be0f80  pop r10
000071ff71be0f82  pop r9
000071ff71be0f84  pop r8
000071ff71be0f86  pop rsi
000071ff71be0f87  pop rdi
000071ff71be0f88  pop rdx
000071ff71be0f89  pop rcx
000071ff71be0f8a  pop rax
000071ff71be0f8b  add rsp, 0x08
000071ff71be0f8f  jmp 0x000071FF71BDF15E
000071ff71be0f94  call 0x000071FF71AC4620
000071ff71be0f99  jmp 0x000071FF71BDF16B
000071ff71be0f9e  sub rsp, 0x08
000071ff71be0fa2  push rax
000071ff71be0fa3  push rcx
000071ff71be0fa4  push rdx
000071ff71be0fa5  push rdi
000071ff71be0fa6  push rsi
000071ff71be0fa7  push r8
000071ff71be0fa9  push r9
000071ff71be0fab  push r10
000071ff71be0fad  push r11
000071ff71be0faf  sub rsp, 0xF0
000071ff71be0fb6  vmovaps [rsp], xmm0
000071ff71be0fbb  vmovaps [rsp+0x10], xmm2
000071ff71be0fc1  vmovaps [rsp+0x20], xmm3
000071ff71be0fc7  vmovaps [rsp+0x30], xmm4
000071ff71be0fcd  vmovaps [rsp+0x40], xmm5
000071ff71be0fd3  vmovaps [rsp+0x50], xmm6
000071ff71be0fd9  vmovaps [rsp+0x60], xmm7
000071ff71be0fdf  vmovaps [rsp+0x70], xmm8
000071ff71be0fe5  vmovaps [rsp+0x80], xmm9
000071ff71be0fee  vmovaps [rsp+0x90], xmm10
000071ff71be0ff7  vmovaps [rsp+0xA0], xmm11
000071ff71be1000  vmovaps [rsp+0xB0], xmm12
000071ff71be1009  vmovaps [rsp+0xC0], xmm13
000071ff71be1012  vmovaps [rsp+0xD0], xmm14
000071ff71be101b  vmovaps [rsp+0xE0], xmm15
000071ff71be1024  sub rsp, 0x30
000071ff71be1028  movaps [rsp], xmm1
000071ff71be102c  movaps [rsp+0x10], xmm5
000071ff71be1031  movaps [rsp+0x20], xmm7
000071ff71be1036  lea rdi, [rsp]
000071ff71be103a  mov esi, 0x00
000071ff71be103f  mov rax, 0x5E6872E10530
000071ff71be1049  call rax
000071ff71be104b  movaps xmm1, [rsp]
000071ff71be104f  add rsp, 0x30
000071ff71be1053  vmovaps xmm0, [rsp]
000071ff71be1058  vmovaps xmm2, [rsp+0x10]
000071ff71be105e  vmovaps xmm3, [rsp+0x20]
000071ff71be1064  vmovaps xmm4, [rsp+0x30]
000071ff71be106a  vmovaps xmm5, [rsp+0x40]
000071ff71be1070  vmovaps xmm6, [rsp+0x50]
000071ff71be1076  vmovaps xmm7, [rsp+0x60]
000071ff71be107c  vmovaps xmm8, [rsp+0x70]
000071ff71be1082  vmovaps xmm9, [rsp+0x80]
000071ff71be108b  vmovaps xmm10, [rsp+0x90]
000071ff71be1094  vmovaps xmm11, [rsp+0xA0]
000071ff71be109d  vmovaps xmm12, [rsp+0xB0]
000071ff71be10a6  vmovaps xmm13, [rsp+0xC0]
000071ff71be10af  vmovaps xmm14, [rsp+0xD0]
000071ff71be10b8  vmovaps xmm15, [rsp+0xE0]
000071ff71be10c1  add rsp, 0xF0
000071ff71be10c8  pop r11
000071ff71be10ca  pop r10
000071ff71be10cc  pop r9
000071ff71be10ce  pop r8
000071ff71be10d0  pop rsi
000071ff71be10d1  pop rdi
000071ff71be10d2  pop rdx
000071ff71be10d3  pop rcx
000071ff71be10d4  pop rax
000071ff71be10d5  add rsp, 0x08
000071ff71be10d9  jmp 0x000071FF71BDF210
000071ff71be10de  sub rsp, 0x08
000071ff71be10e2  push rax
000071ff71be10e3  push rcx
000071ff71be10e4  push rdx
000071ff71be10e5  push rdi
000071ff71be10e6  push rsi
000071ff71be10e7  push r8
000071ff71be10e9  push r9
000071ff71be10eb  push r10
000071ff71be10ed  push r11
000071ff71be10ef  sub rsp, 0xF0
000071ff71be10f6  vmovaps [rsp], xmm0
000071ff71be10fb  vmovaps [rsp+0x10], xmm1
000071ff71be1101  vmovaps [rsp+0x20], xmm2
000071ff71be1107  vmovaps [rsp+0x30], xmm3
000071ff71be110d  vmovaps [rsp+0x40], xmm4
000071ff71be1113  vmovaps [rsp+0x50], xmm5
000071ff71be1119  vmovaps [rsp+0x60], xmm6
000071ff71be111f  vmovaps [rsp+0x70], xmm8
000071ff71be1125  vmovaps [rsp+0x80], xmm9
000071ff71be112e  vmovaps [rsp+0x90], xmm10
000071ff71be1137  vmovaps [rsp+0xA0], xmm11
000071ff71be1140  vmovaps [rsp+0xB0], xmm12
000071ff71be1149  vmovaps [rsp+0xC0], xmm13
000071ff71be1152  vmovaps [rsp+0xD0], xmm14
000071ff71be115b  vmovaps [rsp+0xE0], xmm15
000071ff71be1164  sub rsp, 0x30
000071ff71be1168  movaps [rsp], xmm7
000071ff71be116c  movaps [rsp+0x10], xmm5
000071ff71be1171  movaps [rsp+0x20], xmm15
000071ff71be1177  lea rdi, [rsp]
000071ff71be117b  mov esi, 0x00
000071ff71be1180  mov rax, 0x5E6872E10530
000071ff71be118a  call rax
000071ff71be118c  movaps xmm7, [rsp]
000071ff71be1190  add rsp, 0x30
000071ff71be1194  vmovaps xmm0, [rsp]
000071ff71be1199  vmovaps xmm1, [rsp+0x10]
000071ff71be119f  vmovaps xmm2, [rsp+0x20]
000071ff71be11a5  vmovaps xmm3, [rsp+0x30]
000071ff71be11ab  vmovaps xmm4, [rsp+0x40]
000071ff71be11b1  vmovaps xmm5, [rsp+0x50]
000071ff71be11b7  vmovaps xmm6, [rsp+0x60]
000071ff71be11bd  vmovaps xmm8, [rsp+0x70]
000071ff71be11c3  vmovaps xmm9, [rsp+0x80]
000071ff71be11cc  vmovaps xmm10, [rsp+0x90]
000071ff71be11d5  vmovaps xmm11, [rsp+0xA0]
000071ff71be11de  vmovaps xmm12, [rsp+0xB0]
000071ff71be11e7  vmovaps xmm13, [rsp+0xC0]
000071ff71be11f0  vmovaps xmm14, [rsp+0xD0]
000071ff71be11f9  vmovaps xmm15, [rsp+0xE0]
000071ff71be1202  add rsp, 0xF0
000071ff71be1209  pop r11
000071ff71be120b  pop r10
000071ff71be120d  pop r9
000071ff71be120f  pop r8
000071ff71be1211  pop rsi
000071ff71be1212  pop rdi
000071ff71be1213  pop rdx
000071ff71be1214  pop rcx
000071ff71be1215  pop rax
000071ff71be1216  add rsp, 0x08
000071ff71be121a  jmp 0x000071FF71BDF246
000071ff71be121f  call 0x000071FF71AB52F0
000071ff71be1224  jmp 0x000071FF71BDF253
000071ff71be1229  sub rsp, 0x08
000071ff71be122d  push rax
000071ff71be122e  push rcx
000071ff71be122f  push rdx
000071ff71be1230  push rdi
000071ff71be1231  push rsi
000071ff71be1232  push r8
000071ff71be1234  push r9
000071ff71be1236  push r10
000071ff71be1238  push r11
000071ff71be123a  sub rsp, 0xF0
000071ff71be1241  vmovaps [rsp], xmm0
000071ff71be1246  vmovaps [rsp+0x10], xmm1
000071ff71be124c  vmovaps [rsp+0x20], xmm2
000071ff71be1252  vmovaps [rsp+0x30], xmm3
000071ff71be1258  vmovaps [rsp+0x40], xmm4
000071ff71be125e  vmovaps [rsp+0x50], xmm5
000071ff71be1264  vmovaps [rsp+0x60], xmm6
000071ff71be126a  vmovaps [rsp+0x70], xmm7
000071ff71be1270  vmovaps [rsp+0x80], xmm8
000071ff71be1279  vmovaps [rsp+0x90], xmm9
000071ff71be1282  vmovaps [rsp+0xA0], xmm10
000071ff71be128b  vmovaps [rsp+0xB0], xmm11
000071ff71be1294  vmovaps [rsp+0xC0], xmm12
000071ff71be129d  vmovaps [rsp+0xD0], xmm13
000071ff71be12a6  vmovaps [rsp+0xE0], xmm14
000071ff71be12af  sub rsp, 0x30
000071ff71be12b3  movaps [rsp], xmm15
000071ff71be12b8  movaps [rsp+0x10], xmm5
000071ff71be12bd  movaps [rsp+0x20], xmm3
000071ff71be12c2  lea rdi, [rsp]
000071ff71be12c6  mov esi, 0x00
000071ff71be12cb  mov rax, 0x5E6872E10530
000071ff71be12d5  call rax
000071ff71be12d7  movaps xmm15, [rsp]
000071ff71be12dc  add rsp, 0x30
000071ff71be12e0  vmovaps xmm0, [rsp]
000071ff71be12e5  vmovaps xmm1, [rsp+0x10]
000071ff71be12eb  vmovaps xmm2, [rsp+0x20]
000071ff71be12f1  vmovaps xmm3, [rsp+0x30]
000071ff71be12f7  vmovaps xmm4, [rsp+0x40]
000071ff71be12fd  vmovaps xmm5, [rsp+0x50]
000071ff71be1303  vmovaps xmm6, [rsp+0x60]
000071ff71be1309  vmovaps xmm7, [rsp+0x70]
000071ff71be130f  vmovaps xmm8, [rsp+0x80]
000071ff71be1318  vmovaps xmm9, [rsp+0x90]
000071ff71be1321  vmovaps xmm10, [rsp+0xA0]
000071ff71be132a  vmovaps xmm11, [rsp+0xB0]
000071ff71be1333  vmovaps xmm12, [rsp+0xC0]
000071ff71be133c  vmovaps xmm13, [rsp+0xD0]
000071ff71be1345  vmovaps xmm14, [rsp+0xE0]
000071ff71be134e  add rsp, 0xF0
000071ff71be1355  pop r11
000071ff71be1357  pop r10
000071ff71be1359  pop r9
000071ff71be135b  pop r8
000071ff71be135d  pop rsi
000071ff71be135e  pop rdi
000071ff71be135f  pop rdx
000071ff71be1360  pop rcx
000071ff71be1361  pop rax
000071ff71be1362  add rsp, 0x08
000071ff71be1366  jmp 0x000071FF71BDF279
000071ff71be136b  sub rsp, 0x08
000071ff71be136f  push rax
000071ff71be1370  push rcx
000071ff71be1371  push rdx
000071ff71be1372  push rdi
000071ff71be1373  push rsi
000071ff71be1374  push r8
000071ff71be1376  push r9
000071ff71be1378  push r10
000071ff71be137a  push r11
000071ff71be137c  sub rsp, 0xF0
000071ff71be1383  vmovaps [rsp], xmm0
000071ff71be1388  vmovaps [rsp+0x10], xmm2
000071ff71be138e  vmovaps [rsp+0x20], xmm3
000071ff71be1394  vmovaps [rsp+0x30], xmm4
000071ff71be139a  vmovaps [rsp+0x40], xmm5
000071ff71be13a0  vmovaps [rsp+0x50], xmm6
000071ff71be13a6  vmovaps [rsp+0x60], xmm7
000071ff71be13ac  vmovaps [rsp+0x70], xmm8
000071ff71be13b2  vmovaps [rsp+0x80], xmm9
000071ff71be13bb  vmovaps [rsp+0x90], xmm10
000071ff71be13c4  vmovaps [rsp+0xA0], xmm11
000071ff71be13cd  vmovaps [rsp+0xB0], xmm12
000071ff71be13d6  vmovaps [rsp+0xC0], xmm13
000071ff71be13df  vmovaps [rsp+0xD0], xmm14
000071ff71be13e8  vmovaps [rsp+0xE0], xmm15
000071ff71be13f1  sub rsp, 0x30
000071ff71be13f5  movaps [rsp], xmm1
000071ff71be13f9  movaps [rsp+0x10], xmm5
000071ff71be13fe  movaps [rsp+0x20], xmm4
000071ff71be1403  lea rdi, [rsp]
000071ff71be1407  mov esi, 0x00
000071ff71be140c  mov rax, 0x5E6872E10530
000071ff71be1416  call rax
000071ff71be1418  movaps xmm1, [rsp]
000071ff71be141c  add rsp, 0x30
000071ff71be1420  vmovaps xmm0, [rsp]
000071ff71be1425  vmovaps xmm2, [rsp+0x10]
000071ff71be142b  vmovaps xmm3, [rsp+0x20]
000071ff71be1431  vmovaps xmm4, [rsp+0x30]
000071ff71be1437  vmovaps xmm5, [rsp+0x40]
000071ff71be143d  vmovaps xmm6, [rsp+0x50]
000071ff71be1443  vmovaps xmm7, [rsp+0x60]
000071ff71be1449  vmovaps xmm8, [rsp+0x70]
000071ff71be144f  vmovaps xmm9, [rsp+0x80]
000071ff71be1458  vmovaps xmm10, [rsp+0x90]
000071ff71be1461  vmovaps xmm11, [rsp+0xA0]
000071ff71be146a  vmovaps xmm12, [rsp+0xB0]
000071ff71be1473  vmovaps xmm13, [rsp+0xC0]
000071ff71be147c  vmovaps xmm14, [rsp+0xD0]
000071ff71be1485  vmovaps xmm15, [rsp+0xE0]
000071ff71be148e  add rsp, 0xF0
000071ff71be1495  pop r11
000071ff71be1497  pop r10
000071ff71be1499  pop r9
000071ff71be149b  pop r8
000071ff71be149d  pop rsi
000071ff71be149e  pop rdi
000071ff71be149f  pop rdx
000071ff71be14a0  pop rcx
000071ff71be14a1  pop rax
000071ff71be14a2  add rsp, 0x08
000071ff71be14a6  jmp 0x000071FF71BDF299
000071ff71be14ab  sub rsp, 0x08
000071ff71be14af  push rax
000071ff71be14b0  push rcx
000071ff71be14b1  push rdx
000071ff71be14b2  push rdi
000071ff71be14b3  push rsi
000071ff71be14b4  push r8
000071ff71be14b6  push r9
000071ff71be14b8  push r10
000071ff71be14ba  push r11
000071ff71be14bc  sub rsp, 0xF0
000071ff71be14c3  vmovaps [rsp], xmm0
000071ff71be14c8  vmovaps [rsp+0x10], xmm1
000071ff71be14ce  vmovaps [rsp+0x20], xmm2
000071ff71be14d4  vmovaps [rsp+0x30], xmm3
000071ff71be14da  vmovaps [rsp+0x40], xmm5
000071ff71be14e0  vmovaps [rsp+0x50], xmm6
000071ff71be14e6  vmovaps [rsp+0x60], xmm7
000071ff71be14ec  vmovaps [rsp+0x70], xmm8
000071ff71be14f2  vmovaps [rsp+0x80], xmm9
000071ff71be14fb  vmovaps [rsp+0x90], xmm10
000071ff71be1504  vmovaps [rsp+0xA0], xmm11
000071ff71be150d  vmovaps [rsp+0xB0], xmm12
000071ff71be1516  vmovaps [rsp+0xC0], xmm13
000071ff71be151f  vmovaps [rsp+0xD0], xmm14
000071ff71be1528  vmovaps [rsp+0xE0], xmm15
000071ff71be1531  sub rsp, 0x30
000071ff71be1535  movaps [rsp], xmm4
000071ff71be1539  movaps [rsp+0x10], xmm3
000071ff71be153e  movaps [rsp+0x20], xmm5
000071ff71be1543  lea rdi, [rsp]
000071ff71be1547  mov esi, 0x00
000071ff71be154c  mov rax, 0x5E6872E10530
000071ff71be1556  call rax
000071ff71be1558  movaps xmm4, [rsp]
000071ff71be155c  add rsp, 0x30
000071ff71be1560  vmovaps xmm0, [rsp]
000071ff71be1565  vmovaps xmm1, [rsp+0x10]
000071ff71be156b  vmovaps xmm2, [rsp+0x20]
000071ff71be1571  vmovaps xmm3, [rsp+0x30]
000071ff71be1577  vmovaps xmm5, [rsp+0x40]
000071ff71be157d  vmovaps xmm6, [rsp+0x50]
000071ff71be1583  vmovaps xmm7, [rsp+0x60]
000071ff71be1589  vmovaps xmm8, [rsp+0x70]
000071ff71be158f  vmovaps xmm9, [rsp+0x80]
000071ff71be1598  vmovaps xmm10, [rsp+0x90]
000071ff71be15a1  vmovaps xmm11, [rsp+0xA0]
000071ff71be15aa  vmovaps xmm12, [rsp+0xB0]
000071ff71be15b3  vmovaps xmm13, [rsp+0xC0]
000071ff71be15bc  vmovaps xmm14, [rsp+0xD0]
000071ff71be15c5  vmovaps xmm15, [rsp+0xE0]
000071ff71be15ce  add rsp, 0xF0
000071ff71be15d5  pop r11
000071ff71be15d7  pop r10
000071ff71be15d9  pop r9
000071ff71be15db  pop r8
000071ff71be15dd  pop rsi
000071ff71be15de  pop rdi
000071ff71be15df  pop rdx
000071ff71be15e0  pop rcx
000071ff71be15e1  pop rax
000071ff71be15e2  add rsp, 0x08
000071ff71be15e6  jmp 0x000071FF71BDF2E7
000071ff71be15eb  call 0x000071FF71AB52F0
000071ff71be15f0  jmp 0x000071FF71BDF2F4
000071ff71be15f5  sub rsp, 0x08
000071ff71be15f9  push rax
000071ff71be15fa  push rcx
000071ff71be15fb  push rdx
000071ff71be15fc  push rdi
000071ff71be15fd  push rsi
000071ff71be15fe  push r8
000071ff71be1600  push r9
000071ff71be1602  push r10
000071ff71be1604  push r11
000071ff71be1606  sub rsp, 0xF0
000071ff71be160d  vmovaps [rsp], xmm0
000071ff71be1612  vmovaps [rsp+0x10], xmm1
000071ff71be1618  vmovaps [rsp+0x20], xmm2
000071ff71be161e  vmovaps [rsp+0x30], xmm3
000071ff71be1624  vmovaps [rsp+0x40], xmm4
000071ff71be162a  vmovaps [rsp+0x50], xmm6
000071ff71be1630  vmovaps [rsp+0x60], xmm7
000071ff71be1636  vmovaps [rsp+0x70], xmm8
000071ff71be163c  vmovaps [rsp+0x80], xmm9
000071ff71be1645  vmovaps [rsp+0x90], xmm10
000071ff71be164e  vmovaps [rsp+0xA0], xmm11
000071ff71be1657  vmovaps [rsp+0xB0], xmm12
000071ff71be1660  vmovaps [rsp+0xC0], xmm13
000071ff71be1669  vmovaps [rsp+0xD0], xmm14
000071ff71be1672  vmovaps [rsp+0xE0], xmm15
000071ff71be167b  sub rsp, 0x30
000071ff71be167f  movaps [rsp], xmm5
000071ff71be1683  movaps [rsp+0x10], xmm6
000071ff71be1688  movaps [rsp+0x20], xmm3
000071ff71be168d  lea rdi, [rsp]
000071ff71be1691  mov esi, 0x00
000071ff71be1696  mov rax, 0x5E6872E10530
000071ff71be16a0  call rax
000071ff71be16a2  movaps xmm5, [rsp]
000071ff71be16a6  add rsp, 0x30
000071ff71be16aa  vmovaps xmm0, [rsp]
000071ff71be16af  vmovaps xmm1, [rsp+0x10]
000071ff71be16b5  vmovaps xmm2, [rsp+0x20]
000071ff71be16bb  vmovaps xmm3, [rsp+0x30]
000071ff71be16c1  vmovaps xmm4, [rsp+0x40]
000071ff71be16c7  vmovaps xmm6, [rsp+0x50]
000071ff71be16cd  vmovaps xmm7, [rsp+0x60]
000071ff71be16d3  vmovaps xmm8, [rsp+0x70]
000071ff71be16d9  vmovaps xmm9, [rsp+0x80]
000071ff71be16e2  vmovaps xmm10, [rsp+0x90]
000071ff71be16eb  vmovaps xmm11, [rsp+0xA0]
000071ff71be16f4  vmovaps xmm12, [rsp+0xB0]
000071ff71be16fd  vmovaps xmm13, [rsp+0xC0]
000071ff71be1706  vmovaps xmm14, [rsp+0xD0]
000071ff71be170f  vmovaps xmm15, [rsp+0xE0]
000071ff71be1718  add rsp, 0xF0
000071ff71be171f  pop r11
000071ff71be1721  pop r10
000071ff71be1723  pop r9
000071ff71be1725  pop r8
000071ff71be1727  pop rsi
000071ff71be1728  pop rdi
000071ff71be1729  pop rdx
000071ff71be172a  pop rcx
000071ff71be172b  pop rax
000071ff71be172c  add rsp, 0x08
000071ff71be1730  jmp 0x000071FF71BDF31A
000071ff71be1735  sub rsp, 0x08
000071ff71be1739  push rax
000071ff71be173a  push rcx
000071ff71be173b  push rdx
000071ff71be173c  push rdi
000071ff71be173d  push rsi
000071ff71be173e  push r8
000071ff71be1740  push r9
000071ff71be1742  push r10
000071ff71be1744  push r11
000071ff71be1746  sub rsp, 0xF0
000071ff71be174d  vmovaps [rsp], xmm0
000071ff71be1752  vmovaps [rsp+0x10], xmm1
000071ff71be1758  vmovaps [rsp+0x20], xmm2
000071ff71be175e  vmovaps [rsp+0x30], xmm3
000071ff71be1764  vmovaps [rsp+0x40], xmm4
000071ff71be176a  vmovaps [rsp+0x50], xmm5
000071ff71be1770  vmovaps [rsp+0x60], xmm7
000071ff71be1776  vmovaps [rsp+0x70], xmm8
000071ff71be177c  vmovaps [rsp+0x80], xmm9
000071ff71be1785  vmovaps [rsp+0x90], xmm10
000071ff71be178e  vmovaps [rsp+0xA0], xmm11
000071ff71be1797  vmovaps [rsp+0xB0], xmm12
000071ff71be17a0  vmovaps [rsp+0xC0], xmm13
000071ff71be17a9  vmovaps [rsp+0xD0], xmm14
000071ff71be17b2  vmovaps [rsp+0xE0], xmm15
000071ff71be17bb  sub rsp, 0x30
000071ff71be17bf  movaps [rsp], xmm6
000071ff71be17c3  movaps [rsp+0x10], xmm9
000071ff71be17c9  movaps [rsp+0x20], xmm1
000071ff71be17ce  lea rdi, [rsp]
000071ff71be17d2  mov esi, 0x00
000071ff71be17d7  mov rax, 0x5E6872E10530
000071ff71be17e1  call rax
000071ff71be17e3  movaps xmm6, [rsp]
000071ff71be17e7  add rsp, 0x30
000071ff71be17eb  vmovaps xmm0, [rsp]
000071ff71be17f0  vmovaps xmm1, [rsp+0x10]
000071ff71be17f6  vmovaps xmm2, [rsp+0x20]
000071ff71be17fc  vmovaps xmm3, [rsp+0x30]
000071ff71be1802  vmovaps xmm4, [rsp+0x40]
000071ff71be1808  vmovaps xmm5, [rsp+0x50]
000071ff71be180e  vmovaps xmm7, [rsp+0x60]
000071ff71be1814  vmovaps xmm8, [rsp+0x70]
000071ff71be181a  vmovaps xmm9, [rsp+0x80]
000071ff71be1823  vmovaps xmm10, [rsp+0x90]
000071ff71be182c  vmovaps xmm11, [rsp+0xA0]
000071ff71be1835  vmovaps xmm12, [rsp+0xB0]
000071ff71be183e  vmovaps xmm13, [rsp+0xC0]
000071ff71be1847  vmovaps xmm14, [rsp+0xD0]
000071ff71be1850  vmovaps xmm15, [rsp+0xE0]
000071ff71be1859  add rsp, 0xF0
000071ff71be1860  pop r11
000071ff71be1862  pop r10
000071ff71be1864  pop r9
000071ff71be1866  pop r8
000071ff71be1868  pop rsi
000071ff71be1869  pop rdi
000071ff71be186a  pop rdx
000071ff71be186b  pop rcx
000071ff71be186c  pop rax
000071ff71be186d  add rsp, 0x08
000071ff71be1871  jmp 0x000071FF71BDF33E
000071ff71be1876  sub rsp, 0x08
000071ff71be187a  push rax
000071ff71be187b  push rcx
000071ff71be187c  push rdx
000071ff71be187d  push rdi
000071ff71be187e  push rsi
000071ff71be187f  push r8
000071ff71be1881  push r9
000071ff71be1883  push r10
000071ff71be1885  push r11
000071ff71be1887  sub rsp, 0xF0
000071ff71be188e  vmovaps [rsp], xmm0
000071ff71be1893  vmovaps [rsp+0x10], xmm1
000071ff71be1899  vmovaps [rsp+0x20], xmm2
000071ff71be189f  vmovaps [rsp+0x30], xmm3
000071ff71be18a5  vmovaps [rsp+0x40], xmm4
000071ff71be18ab  vmovaps [rsp+0x50], xmm5
000071ff71be18b1  vmovaps [rsp+0x60], xmm6
000071ff71be18b7  vmovaps [rsp+0x70], xmm7
000071ff71be18bd  vmovaps [rsp+0x80], xmm8
000071ff71be18c6  vmovaps [rsp+0x90], xmm10
000071ff71be18cf  vmovaps [rsp+0xA0], xmm11
000071ff71be18d8  vmovaps [rsp+0xB0], xmm12
000071ff71be18e1  vmovaps [rsp+0xC0], xmm13
000071ff71be18ea  vmovaps [rsp+0xD0], xmm14
000071ff71be18f3  vmovaps [rsp+0xE0], xmm15
000071ff71be18fc  sub rsp, 0x30
000071ff71be1900  movaps [rsp], xmm9
000071ff71be1905  movaps [rsp+0x10], xmm3
000071ff71be190a  movaps [rsp+0x20], xmm1
000071ff71be190f  lea rdi, [rsp]
000071ff71be1913  mov esi, 0x00
000071ff71be1918  mov rax, 0x5E6872E10530
000071ff71be1922  call rax
000071ff71be1924  movaps xmm9, [rsp]
000071ff71be1929  add rsp, 0x30
000071ff71be192d  vmovaps xmm0, [rsp]
000071ff71be1932  vmovaps xmm1, [rsp+0x10]
000071ff71be1938  vmovaps xmm2, [rsp+0x20]
000071ff71be193e  vmovaps xmm3, [rsp+0x30]
000071ff71be1944  vmovaps xmm4, [rsp+0x40]
000071ff71be194a  vmovaps xmm5, [rsp+0x50]
000071ff71be1950  vmovaps xmm6, [rsp+0x60]
000071ff71be1956  vmovaps xmm7, [rsp+0x70]
000071ff71be195c  vmovaps xmm8, [rsp+0x80]
000071ff71be1965  vmovaps xmm10, [rsp+0x90]
000071ff71be196e  vmovaps xmm11, [rsp+0xA0]
000071ff71be1977  vmovaps xmm12, [rsp+0xB0]
000071ff71be1980  vmovaps xmm13, [rsp+0xC0]
000071ff71be1989  vmovaps xmm14, [rsp+0xD0]
000071ff71be1992  vmovaps xmm15, [rsp+0xE0]
000071ff71be199b  add rsp, 0xF0
000071ff71be19a2  pop r11
000071ff71be19a4  pop r10
000071ff71be19a6  pop r9
000071ff71be19a8  pop r8
000071ff71be19aa  pop rsi
000071ff71be19ab  pop rdi
000071ff71be19ac  pop rdx
000071ff71be19ad  pop rcx
000071ff71be19ae  pop rax
000071ff71be19af  add rsp, 0x08
000071ff71be19b3  jmp 0x000071FF71BDF38A
000071ff71be19b8  call 0x000071FF71AB52F0
000071ff71be19bd  jmp 0x000071FF71BDF397
000071ff71be19c2  sub rsp, 0x08
000071ff71be19c6  push rax
000071ff71be19c7  push rcx
000071ff71be19c8  push rdx
000071ff71be19c9  push rdi
000071ff71be19ca  push rsi
000071ff71be19cb  push r8
000071ff71be19cd  push r9
000071ff71be19cf  push r10
000071ff71be19d1  push r11
000071ff71be19d3  sub rsp, 0xF0
000071ff71be19da  vmovaps [rsp], xmm0
000071ff71be19df  vmovaps [rsp+0x10], xmm1
000071ff71be19e5  vmovaps [rsp+0x20], xmm2
000071ff71be19eb  vmovaps [rsp+0x30], xmm3
000071ff71be19f1  vmovaps [rsp+0x40], xmm4
000071ff71be19f7  vmovaps [rsp+0x50], xmm5
000071ff71be19fd  vmovaps [rsp+0x60], xmm6
000071ff71be1a03  vmovaps [rsp+0x70], xmm7
000071ff71be1a09  vmovaps [rsp+0x80], xmm8
000071ff71be1a12  vmovaps [rsp+0x90], xmm9
000071ff71be1a1b  vmovaps [rsp+0xA0], xmm10
000071ff71be1a24  vmovaps [rsp+0xB0], xmm11
000071ff71be1a2d  vmovaps [rsp+0xC0], xmm12
000071ff71be1a36  vmovaps [rsp+0xD0], xmm13
000071ff71be1a3f  vmovaps [rsp+0xE0], xmm14
000071ff71be1a48  sub rsp, 0x30
000071ff71be1a4c  movaps [rsp], xmm15
000071ff71be1a51  movaps [rsp+0x10], xmm3
000071ff71be1a56  movaps [rsp+0x20], xmm7
000071ff71be1a5b  lea rdi, [rsp]
000071ff71be1a5f  mov esi, 0x00
000071ff71be1a64  mov rax, 0x5E6872E10530
000071ff71be1a6e  call rax
000071ff71be1a70  movaps xmm15, [rsp]
000071ff71be1a75  add rsp, 0x30
000071ff71be1a79  vmovaps xmm0, [rsp]
000071ff71be1a7e  vmovaps xmm1, [rsp+0x10]
000071ff71be1a84  vmovaps xmm2, [rsp+0x20]
000071ff71be1a8a  vmovaps xmm3, [rsp+0x30]
000071ff71be1a90  vmovaps xmm4, [rsp+0x40]
000071ff71be1a96  vmovaps xmm5, [rsp+0x50]
000071ff71be1a9c  vmovaps xmm6, [rsp+0x60]
000071ff71be1aa2  vmovaps xmm7, [rsp+0x70]
000071ff71be1aa8  vmovaps xmm8, [rsp+0x80]
000071ff71be1ab1  vmovaps xmm9, [rsp+0x90]
000071ff71be1aba  vmovaps xmm10, [rsp+0xA0]
000071ff71be1ac3  vmovaps xmm11, [rsp+0xB0]
000071ff71be1acc  vmovaps xmm12, [rsp+0xC0]
000071ff71be1ad5  vmovaps xmm13, [rsp+0xD0]
000071ff71be1ade  vmovaps xmm14, [rsp+0xE0]
000071ff71be1ae7  add rsp, 0xF0
000071ff71be1aee  pop r11
000071ff71be1af0  pop r10
000071ff71be1af2  pop r9
000071ff71be1af4  pop r8
000071ff71be1af6  pop rsi
000071ff71be1af7  pop rdi
000071ff71be1af8  pop rdx
000071ff71be1af9  pop rcx
000071ff71be1afa  pop rax
000071ff71be1afb  add rsp, 0x08
000071ff71be1aff  jmp 0x000071FF71BDF3C3
000071ff71be1b04  sub rsp, 0x08
000071ff71be1b08  push rax
000071ff71be1b09  push rcx
000071ff71be1b0a  push rdx
000071ff71be1b0b  push rdi
000071ff71be1b0c  push rsi
000071ff71be1b0d  push r8
000071ff71be1b0f  push r9
000071ff71be1b11  push r10
000071ff71be1b13  push r11
000071ff71be1b15  sub rsp, 0xF0
000071ff71be1b1c  vmovaps [rsp], xmm0
000071ff71be1b21  vmovaps [rsp+0x10], xmm1
000071ff71be1b27  vmovaps [rsp+0x20], xmm2
000071ff71be1b2d  vmovaps [rsp+0x30], xmm4
000071ff71be1b33  vmovaps [rsp+0x40], xmm5
000071ff71be1b39  vmovaps [rsp+0x50], xmm6
000071ff71be1b3f  vmovaps [rsp+0x60], xmm7
000071ff71be1b45  vmovaps [rsp+0x70], xmm8
000071ff71be1b4b  vmovaps [rsp+0x80], xmm9
000071ff71be1b54  vmovaps [rsp+0x90], xmm10
000071ff71be1b5d  vmovaps [rsp+0xA0], xmm11
000071ff71be1b66  vmovaps [rsp+0xB0], xmm12
000071ff71be1b6f  vmovaps [rsp+0xC0], xmm13
000071ff71be1b78  vmovaps [rsp+0xD0], xmm14
000071ff71be1b81  vmovaps [rsp+0xE0], xmm15
000071ff71be1b8a  sub rsp, 0x30
000071ff71be1b8e  movaps [rsp], xmm3
000071ff71be1b92  movaps [rsp+0x10], xmm1
000071ff71be1b97  movaps [rsp+0x20], xmm15
000071ff71be1b9d  lea rdi, [rsp]
000071ff71be1ba1  mov esi, 0x00
000071ff71be1ba6  mov rax, 0x5E6872E10530
000071ff71be1bb0  call rax
000071ff71be1bb2  movaps xmm3, [rsp]
000071ff71be1bb6  add rsp, 0x30
000071ff71be1bba  vmovaps xmm0, [rsp]
000071ff71be1bbf  vmovaps xmm1, [rsp+0x10]
000071ff71be1bc5  vmovaps xmm2, [rsp+0x20]
000071ff71be1bcb  vmovaps xmm4, [rsp+0x30]
000071ff71be1bd1  vmovaps xmm5, [rsp+0x40]
000071ff71be1bd7  vmovaps xmm6, [rsp+0x50]
000071ff71be1bdd  vmovaps xmm7, [rsp+0x60]
000071ff71be1be3  vmovaps xmm8, [rsp+0x70]
000071ff71be1be9  vmovaps xmm9, [rsp+0x80]
000071ff71be1bf2  vmovaps xmm10, [rsp+0x90]
000071ff71be1bfb  vmovaps xmm11, [rsp+0xA0]
000071ff71be1c04  vmovaps xmm12, [rsp+0xB0]
000071ff71be1c0d  vmovaps xmm13, [rsp+0xC0]
000071ff71be1c16  vmovaps xmm14, [rsp+0xD0]
000071ff71be1c1f  vmovaps xmm15, [rsp+0xE0]
000071ff71be1c28  add rsp, 0xF0
000071ff71be1c2f  pop r11
000071ff71be1c31  pop r10
000071ff71be1c33  pop r9
000071ff71be1c35  pop r8
000071ff71be1c37  pop rsi
000071ff71be1c38  pop rdi
000071ff71be1c39  pop rdx
000071ff71be1c3a  pop rcx
000071ff71be1c3b  pop rax
000071ff71be1c3c  add rsp, 0x08
000071ff71be1c40  jmp 0x000071FF71BDF452
000071ff71be1c45  call 0x000071FF71AB52F0
000071ff71be1c4a  jmp 0x000071FF71BDF45C
000071ff71be1c4f  sub rsp, 0x08
000071ff71be1c53  push rax
000071ff71be1c54  push rcx
000071ff71be1c55  push rdx
000071ff71be1c56  push rdi
000071ff71be1c57  push rsi
000071ff71be1c58  push r8
000071ff71be1c5a  push r9
000071ff71be1c5c  push r10
000071ff71be1c5e  push r11
000071ff71be1c60  sub rsp, 0xF0
000071ff71be1c67  vmovaps [rsp], xmm0
000071ff71be1c6c  vmovaps [rsp+0x10], xmm1
000071ff71be1c72  vmovaps [rsp+0x20], xmm2
000071ff71be1c78  vmovaps [rsp+0x30], xmm3
000071ff71be1c7e  vmovaps [rsp+0x40], xmm4
000071ff71be1c84  vmovaps [rsp+0x50], xmm5
000071ff71be1c8a  vmovaps [rsp+0x60], xmm6
000071ff71be1c90  vmovaps [rsp+0x70], xmm7
000071ff71be1c96  vmovaps [rsp+0x80], xmm8
000071ff71be1c9f  vmovaps [rsp+0x90], xmm9
000071ff71be1ca8  vmovaps [rsp+0xA0], xmm10
000071ff71be1cb1  vmovaps [rsp+0xB0], xmm11
000071ff71be1cba  vmovaps [rsp+0xC0], xmm12
000071ff71be1cc3  vmovaps [rsp+0xD0], xmm13
000071ff71be1ccc  vmovaps [rsp+0xE0], xmm14
000071ff71be1cd5  sub rsp, 0x30
000071ff71be1cd9  movaps [rsp], xmm15
000071ff71be1cde  movaps [rsp+0x10], xmm14
000071ff71be1ce4  movaps [rsp+0x20], xmm4
000071ff71be1ce9  lea rdi, [rsp]
000071ff71be1ced  mov esi, 0x00
000071ff71be1cf2  mov rax, 0x5E6872E10530
000071ff71be1cfc  call rax
000071ff71be1cfe  movaps xmm15, [rsp]
000071ff71be1d03  add rsp, 0x30
000071ff71be1d07  vmovaps xmm0, [rsp]
000071ff71be1d0c  vmovaps xmm1, [rsp+0x10]
000071ff71be1d12  vmovaps xmm2, [rsp+0x20]
000071ff71be1d18  vmovaps xmm3, [rsp+0x30]
000071ff71be1d1e  vmovaps xmm4, [rsp+0x40]
000071ff71be1d24  vmovaps xmm5, [rsp+0x50]
000071ff71be1d2a  vmovaps xmm6, [rsp+0x60]
000071ff71be1d30  vmovaps xmm7, [rsp+0x70]
000071ff71be1d36  vmovaps xmm8, [rsp+0x80]
000071ff71be1d3f  vmovaps xmm9, [rsp+0x90]
000071ff71be1d48  vmovaps xmm10, [rsp+0xA0]
000071ff71be1d51  vmovaps xmm11, [rsp+0xB0]
000071ff71be1d5a  vmovaps xmm12, [rsp+0xC0]
000071ff71be1d63  vmovaps xmm13, [rsp+0xD0]
000071ff71be1d6c  vmovaps xmm14, [rsp+0xE0]
000071ff71be1d75  add rsp, 0xF0
000071ff71be1d7c  pop r11
000071ff71be1d7e  pop r10
000071ff71be1d80  pop r9
000071ff71be1d82  pop r8
000071ff71be1d84  pop rsi
000071ff71be1d85  pop rdi
000071ff71be1d86  pop rdx
000071ff71be1d87  pop rcx
000071ff71be1d88  pop rax
000071ff71be1d89  add rsp, 0x08
000071ff71be1d8d  jmp 0x000071FF71BDF48A
000071ff71be1d92  sub rsp, 0x08
000071ff71be1d96  push rax
000071ff71be1d97  push rcx
000071ff71be1d98  push rdx
000071ff71be1d99  push rdi
000071ff71be1d9a  push rsi
000071ff71be1d9b  push r8
000071ff71be1d9d  push r9
000071ff71be1d9f  push r10
000071ff71be1da1  push r11
000071ff71be1da3  sub rsp, 0xF0
000071ff71be1daa  vmovaps [rsp], xmm0
000071ff71be1daf  vmovaps [rsp+0x10], xmm1
000071ff71be1db5  vmovaps [rsp+0x20], xmm2
000071ff71be1dbb  vmovaps [rsp+0x30], xmm3
000071ff71be1dc1  vmovaps [rsp+0x40], xmm4
000071ff71be1dc7  vmovaps [rsp+0x50], xmm5
000071ff71be1dcd  vmovaps [rsp+0x60], xmm6
000071ff71be1dd3  vmovaps [rsp+0x70], xmm7
000071ff71be1dd9  vmovaps [rsp+0x80], xmm8
000071ff71be1de2  vmovaps [rsp+0x90], xmm9
000071ff71be1deb  vmovaps [rsp+0xA0], xmm10
000071ff71be1df4  vmovaps [rsp+0xB0], xmm11
000071ff71be1dfd  vmovaps [rsp+0xC0], xmm12
000071ff71be1e06  vmovaps [rsp+0xD0], xmm13
000071ff71be1e0f  vmovaps [rsp+0xE0], xmm15
000071ff71be1e18  sub rsp, 0x30
000071ff71be1e1c  movaps [rsp], xmm14
000071ff71be1e21  movaps [rsp+0x10], xmm2
000071ff71be1e26  movaps [rsp+0x20], xmm1
000071ff71be1e2b  lea rdi, [rsp]
000071ff71be1e2f  mov esi, 0x00
000071ff71be1e34  mov rax, 0x5E6872E10530
000071ff71be1e3e  call rax
000071ff71be1e40  movaps xmm14, [rsp]
000071ff71be1e45  add rsp, 0x30
000071ff71be1e49  vmovaps xmm0, [rsp]
000071ff71be1e4e  vmovaps xmm1, [rsp+0x10]
000071ff71be1e54  vmovaps xmm2, [rsp+0x20]
000071ff71be1e5a  vmovaps xmm3, [rsp+0x30]
000071ff71be1e60  vmovaps xmm4, [rsp+0x40]
000071ff71be1e66  vmovaps xmm5, [rsp+0x50]
000071ff71be1e6c  vmovaps xmm6, [rsp+0x60]
000071ff71be1e72  vmovaps xmm7, [rsp+0x70]
000071ff71be1e78  vmovaps xmm8, [rsp+0x80]
000071ff71be1e81  vmovaps xmm9, [rsp+0x90]
000071ff71be1e8a  vmovaps xmm10, [rsp+0xA0]
000071ff71be1e93  vmovaps xmm11, [rsp+0xB0]
000071ff71be1e9c  vmovaps xmm12, [rsp+0xC0]
000071ff71be1ea5  vmovaps xmm13, [rsp+0xD0]
000071ff71be1eae  vmovaps xmm15, [rsp+0xE0]
000071ff71be1eb7  add rsp, 0xF0
000071ff71be1ebe  pop r11
000071ff71be1ec0  pop r10
000071ff71be1ec2  pop r9
000071ff71be1ec4  pop r8
000071ff71be1ec6  pop rsi
000071ff71be1ec7  pop rdi
000071ff71be1ec8  pop rdx
000071ff71be1ec9  pop rcx
000071ff71be1eca  pop rax
000071ff71be1ecb  add rsp, 0x08
000071ff71be1ecf  jmp 0x000071FF71BDF4B0
000071ff71be1ed4  sub rsp, 0x08
000071ff71be1ed8  push rax
000071ff71be1ed9  push rcx
000071ff71be1eda  push rdx
000071ff71be1edb  push rdi
000071ff71be1edc  push rsi
000071ff71be1edd  push r8
000071ff71be1edf  push r9
000071ff71be1ee1  push r10
000071ff71be1ee3  push r11
000071ff71be1ee5  sub rsp, 0xF0
000071ff71be1eec  vmovaps [rsp], xmm0
000071ff71be1ef1  vmovaps [rsp+0x10], xmm2
000071ff71be1ef7  vmovaps [rsp+0x20], xmm3
000071ff71be1efd  vmovaps [rsp+0x30], xmm4
000071ff71be1f03  vmovaps [rsp+0x40], xmm5
000071ff71be1f09  vmovaps [rsp+0x50], xmm6
000071ff71be1f0f  vmovaps [rsp+0x60], xmm7
000071ff71be1f15  vmovaps [rsp+0x70], xmm8
000071ff71be1f1b  vmovaps [rsp+0x80], xmm9
000071ff71be1f24  vmovaps [rsp+0x90], xmm10
000071ff71be1f2d  vmovaps [rsp+0xA0], xmm11
000071ff71be1f36  vmovaps [rsp+0xB0], xmm12
000071ff71be1f3f  vmovaps [rsp+0xC0], xmm13
000071ff71be1f48  vmovaps [rsp+0xD0], xmm14
000071ff71be1f51  vmovaps [rsp+0xE0], xmm15
000071ff71be1f5a  sub rsp, 0x30
000071ff71be1f5e  movaps [rsp], xmm1
000071ff71be1f62  movaps [rsp+0x10], xmm4
000071ff71be1f67  movaps [rsp+0x20], xmm9
000071ff71be1f6d  lea rdi, [rsp]
000071ff71be1f71  mov esi, 0x00
000071ff71be1f76  mov rax, 0x5E6872E10530
000071ff71be1f80  call rax
000071ff71be1f82  movaps xmm1, [rsp]
000071ff71be1f86  add rsp, 0x30
000071ff71be1f8a  vmovaps xmm0, [rsp]
000071ff71be1f8f  vmovaps xmm2, [rsp+0x10]
000071ff71be1f95  vmovaps xmm3, [rsp+0x20]
000071ff71be1f9b  vmovaps xmm4, [rsp+0x30]
000071ff71be1fa1  vmovaps xmm5, [rsp+0x40]
000071ff71be1fa7  vmovaps xmm6, [rsp+0x50]
000071ff71be1fad  vmovaps xmm7, [rsp+0x60]
000071ff71be1fb3  vmovaps xmm8, [rsp+0x70]
000071ff71be1fb9  vmovaps xmm9, [rsp+0x80]
000071ff71be1fc2  vmovaps xmm10, [rsp+0x90]
000071ff71be1fcb  vmovaps xmm11, [rsp+0xA0]
000071ff71be1fd4  vmovaps xmm12, [rsp+0xB0]
000071ff71be1fdd  vmovaps xmm13, [rsp+0xC0]
000071ff71be1fe6  vmovaps xmm14, [rsp+0xD0]
000071ff71be1fef  vmovaps xmm15, [rsp+0xE0]
000071ff71be1ff8  add rsp, 0xF0
000071ff71be1fff  pop r11
000071ff71be2001  pop r10
000071ff71be2003  pop r9
000071ff71be2005  pop r8
000071ff71be2007  pop rsi
000071ff71be2008  pop rdi
000071ff71be2009  pop rdx
000071ff71be200a  pop rcx
000071ff71be200b  pop rax
000071ff71be200c  add rsp, 0x08
000071ff71be2010  jmp 0x000071FF71BDF4CE
000071ff71be2015  sub rsp, 0x08
000071ff71be2019  push rax
000071ff71be201a  push rcx
000071ff71be201b  push rdx
000071ff71be201c  push rdi
000071ff71be201d  push rsi
000071ff71be201e  push r8
000071ff71be2020  push r9
000071ff71be2022  push r10
000071ff71be2024  push r11
000071ff71be2026  sub rsp, 0xF0
000071ff71be202d  vmovaps [rsp], xmm0
000071ff71be2032  vmovaps [rsp+0x10], xmm1
000071ff71be2038  vmovaps [rsp+0x20], xmm2
000071ff71be203e  vmovaps [rsp+0x30], xmm3
000071ff71be2044  vmovaps [rsp+0x40], xmm5
000071ff71be204a  vmovaps [rsp+0x50], xmm6
000071ff71be2050  vmovaps [rsp+0x60], xmm7
000071ff71be2056  vmovaps [rsp+0x70], xmm8
000071ff71be205c  vmovaps [rsp+0x80], xmm9
000071ff71be2065  vmovaps [rsp+0x90], xmm10
000071ff71be206e  vmovaps [rsp+0xA0], xmm11
000071ff71be2077  vmovaps [rsp+0xB0], xmm12
000071ff71be2080  vmovaps [rsp+0xC0], xmm13
000071ff71be2089  vmovaps [rsp+0xD0], xmm14
000071ff71be2092  vmovaps [rsp+0xE0], xmm15
000071ff71be209b  sub rsp, 0x30
000071ff71be209f  movaps [rsp], xmm4
000071ff71be20a3  movaps [rsp+0x10], xmm2
000071ff71be20a8  movaps [rsp+0x20], xmm9
000071ff71be20ae  lea rdi, [rsp]
000071ff71be20b2  mov esi, 0x00
000071ff71be20b7  mov rax, 0x5E6872E10530
000071ff71be20c1  call rax
000071ff71be20c3  movaps xmm4, [rsp]
000071ff71be20c7  add rsp, 0x30
000071ff71be20cb  vmovaps xmm0, [rsp]
000071ff71be20d0  vmovaps xmm1, [rsp+0x10]
000071ff71be20d6  vmovaps xmm2, [rsp+0x20]
000071ff71be20dc  vmovaps xmm3, [rsp+0x30]
000071ff71be20e2  vmovaps xmm5, [rsp+0x40]
000071ff71be20e8  vmovaps xmm6, [rsp+0x50]
000071ff71be20ee  vmovaps xmm7, [rsp+0x60]
000071ff71be20f4  vmovaps xmm8, [rsp+0x70]
000071ff71be20fa  vmovaps xmm9, [rsp+0x80]
000071ff71be2103  vmovaps xmm10, [rsp+0x90]
000071ff71be210c  vmovaps xmm11, [rsp+0xA0]
000071ff71be2115  vmovaps xmm12, [rsp+0xB0]
000071ff71be211e  vmovaps xmm13, [rsp+0xC0]
000071ff71be2127  vmovaps xmm14, [rsp+0xD0]
000071ff71be2130  vmovaps xmm15, [rsp+0xE0]
000071ff71be2139  add rsp, 0xF0
000071ff71be2140  pop r11
000071ff71be2142  pop r10
000071ff71be2144  pop r9
000071ff71be2146  pop r8
000071ff71be2148  pop rsi
000071ff71be2149  pop rdi
000071ff71be214a  pop rdx
000071ff71be214b  pop rcx
000071ff71be214c  pop rax
000071ff71be214d  add rsp, 0x08
000071ff71be2151  jmp 0x000071FF71BDF4FE
000071ff71be2156  sub rsp, 0x08
000071ff71be215a  push rax
000071ff71be215b  push rcx
000071ff71be215c  push rdx
000071ff71be215d  push rdi
000071ff71be215e  push rsi
000071ff71be215f  push r8
000071ff71be2161  push r9
000071ff71be2163  push r10
000071ff71be2165  push r11
000071ff71be2167  sub rsp, 0xF0
000071ff71be216e  vmovaps [rsp], xmm0
000071ff71be2173  vmovaps [rsp+0x10], xmm1
000071ff71be2179  vmovaps [rsp+0x20], xmm2
000071ff71be217f  vmovaps [rsp+0x30], xmm3
000071ff71be2185  vmovaps [rsp+0x40], xmm4
000071ff71be218b  vmovaps [rsp+0x50], xmm5
000071ff71be2191  vmovaps [rsp+0x60], xmm6
000071ff71be2197  vmovaps [rsp+0x70], xmm7
000071ff71be219d  vmovaps [rsp+0x80], xmm8
000071ff71be21a6  vmovaps [rsp+0x90], xmm10
000071ff71be21af  vmovaps [rsp+0xA0], xmm11
000071ff71be21b8  vmovaps [rsp+0xB0], xmm12
000071ff71be21c1  vmovaps [rsp+0xC0], xmm13
000071ff71be21ca  vmovaps [rsp+0xD0], xmm14
000071ff71be21d3  vmovaps [rsp+0xE0], xmm15
000071ff71be21dc  sub rsp, 0x30
000071ff71be21e0  movaps [rsp], xmm9
000071ff71be21e5  movaps [rsp+0x10], xmm2
000071ff71be21ea  movaps [rsp+0x20], xmm1
000071ff71be21ef  lea rdi, [rsp]
000071ff71be21f3  mov esi, 0x00
000071ff71be21f8  mov rax, 0x5E6872E10530
000071ff71be2202  call rax
000071ff71be2204  movaps xmm9, [rsp]
000071ff71be2209  add rsp, 0x30
000071ff71be220d  vmovaps xmm0, [rsp]
000071ff71be2212  vmovaps xmm1, [rsp+0x10]
000071ff71be2218  vmovaps xmm2, [rsp+0x20]
000071ff71be221e  vmovaps xmm3, [rsp+0x30]
000071ff71be2224  vmovaps xmm4, [rsp+0x40]
000071ff71be222a  vmovaps xmm5, [rsp+0x50]
000071ff71be2230  vmovaps xmm6, [rsp+0x60]
000071ff71be2236  vmovaps xmm7, [rsp+0x70]
000071ff71be223c  vmovaps xmm8, [rsp+0x80]
000071ff71be2245  vmovaps xmm10, [rsp+0x90]
000071ff71be224e  vmovaps xmm11, [rsp+0xA0]
000071ff71be2257  vmovaps xmm12, [rsp+0xB0]
000071ff71be2260  vmovaps xmm13, [rsp+0xC0]
000071ff71be2269  vmovaps xmm14, [rsp+0xD0]
000071ff71be2272  vmovaps xmm15, [rsp+0xE0]
000071ff71be227b  add rsp, 0xF0
000071ff71be2282  pop r11
000071ff71be2284  pop r10
000071ff71be2286  pop r9
000071ff71be2288  pop r8
000071ff71be228a  pop rsi
000071ff71be228b  pop rdi
000071ff71be228c  pop rdx
000071ff71be228d  pop rcx
000071ff71be228e  pop rax
000071ff71be228f  add rsp, 0x08
000071ff71be2293  jmp 0x000071FF71BDF534
000071ff71be2298  sub rsp, 0x08
000071ff71be229c  push rax
000071ff71be229d  push rcx
000071ff71be229e  push rdx
000071ff71be229f  push rdi
000071ff71be22a0  push rsi
000071ff71be22a1  push r8
000071ff71be22a3  push r9
000071ff71be22a5  push r10
000071ff71be22a7  push r11
000071ff71be22a9  sub rsp, 0xF0
000071ff71be22b0  vmovaps [rsp], xmm0
000071ff71be22b5  vmovaps [rsp+0x10], xmm2
000071ff71be22bb  vmovaps [rsp+0x20], xmm3
000071ff71be22c1  vmovaps [rsp+0x30], xmm4
000071ff71be22c7  vmovaps [rsp+0x40], xmm5
000071ff71be22cd  vmovaps [rsp+0x50], xmm6
000071ff71be22d3  vmovaps [rsp+0x60], xmm7
000071ff71be22d9  vmovaps [rsp+0x70], xmm8
000071ff71be22df  vmovaps [rsp+0x80], xmm9
000071ff71be22e8  vmovaps [rsp+0x90], xmm10
000071ff71be22f1  vmovaps [rsp+0xA0], xmm11
000071ff71be22fa  vmovaps [rsp+0xB0], xmm12
000071ff71be2303  vmovaps [rsp+0xC0], xmm13
000071ff71be230c  vmovaps [rsp+0xD0], xmm14
000071ff71be2315  vmovaps [rsp+0xE0], xmm15
000071ff71be231e  sub rsp, 0x30
000071ff71be2322  movaps [rsp], xmm1
000071ff71be2326  movaps [rsp+0x10], xmm15
000071ff71be232c  movaps [rsp+0x20], xmm6
000071ff71be2331  lea rdi, [rsp]
000071ff71be2335  mov esi, 0x00
000071ff71be233a  mov rax, 0x5E6872E10530
000071ff71be2344  call rax
000071ff71be2346  movaps xmm1, [rsp]
000071ff71be234a  add rsp, 0x30
000071ff71be234e  vmovaps xmm0, [rsp]
000071ff71be2353  vmovaps xmm2, [rsp+0x10]
000071ff71be2359  vmovaps xmm3, [rsp+0x20]
000071ff71be235f  vmovaps xmm4, [rsp+0x30]
000071ff71be2365  vmovaps xmm5, [rsp+0x40]
000071ff71be236b  vmovaps xmm6, [rsp+0x50]
000071ff71be2371  vmovaps xmm7, [rsp+0x60]
000071ff71be2377  vmovaps xmm8, [rsp+0x70]
000071ff71be237d  vmovaps xmm9, [rsp+0x80]
000071ff71be2386  vmovaps xmm10, [rsp+0x90]
000071ff71be238f  vmovaps xmm11, [rsp+0xA0]
000071ff71be2398  vmovaps xmm12, [rsp+0xB0]
000071ff71be23a1  vmovaps xmm13, [rsp+0xC0]
000071ff71be23aa  vmovaps xmm14, [rsp+0xD0]
000071ff71be23b3  vmovaps xmm15, [rsp+0xE0]
000071ff71be23bc  add rsp, 0xF0
000071ff71be23c3  pop r11
000071ff71be23c5  pop r10
000071ff71be23c7  pop r9
000071ff71be23c9  pop r8
000071ff71be23cb  pop rsi
000071ff71be23cc  pop rdi
000071ff71be23cd  pop rdx
000071ff71be23ce  pop rcx
000071ff71be23cf  pop rax
000071ff71be23d0  add rsp, 0x08
000071ff71be23d4  jmp 0x000071FF71BDF555
000071ff71be23d9  sub rsp, 0x08
000071ff71be23dd  push rax
000071ff71be23de  push rcx
000071ff71be23df  push rdx
000071ff71be23e0  push rdi
000071ff71be23e1  push rsi
000071ff71be23e2  push r8
000071ff71be23e4  push r9
000071ff71be23e6  push r10
000071ff71be23e8  push r11
000071ff71be23ea  sub rsp, 0xF0
000071ff71be23f1  vmovaps [rsp], xmm0
000071ff71be23f6  vmovaps [rsp+0x10], xmm1
000071ff71be23fc  vmovaps [rsp+0x20], xmm2
000071ff71be2402  vmovaps [rsp+0x30], xmm3
000071ff71be2408  vmovaps [rsp+0x40], xmm4
000071ff71be240e  vmovaps [rsp+0x50], xmm5
000071ff71be2414  vmovaps [rsp+0x60], xmm6
000071ff71be241a  vmovaps [rsp+0x70], xmm7
000071ff71be2420  vmovaps [rsp+0x80], xmm8
000071ff71be2429  vmovaps [rsp+0x90], xmm9
000071ff71be2432  vmovaps [rsp+0xA0], xmm10
000071ff71be243b  vmovaps [rsp+0xB0], xmm11
000071ff71be2444  vmovaps [rsp+0xC0], xmm12
000071ff71be244d  vmovaps [rsp+0xD0], xmm13
000071ff71be2456  vmovaps [rsp+0xE0], xmm14
000071ff71be245f  sub rsp, 0x30
000071ff71be2463  movaps [rsp], xmm15
000071ff71be2468  movaps [rsp+0x10], xmm5
000071ff71be246d  movaps [rsp+0x20], xmm3
000071ff71be2472  lea rdi, [rsp]
000071ff71be2476  mov esi, 0x00
000071ff71be247b  mov rax, 0x5E6872E10530
000071ff71be2485  call rax
000071ff71be2487  movaps xmm15, [rsp]
000071ff71be248c  add rsp, 0x30
000071ff71be2490  vmovaps xmm0, [rsp]
000071ff71be2495  vmovaps xmm1, [rsp+0x10]
000071ff71be249b  vmovaps xmm2, [rsp+0x20]
000071ff71be24a1  vmovaps xmm3, [rsp+0x30]
000071ff71be24a7  vmovaps xmm4, [rsp+0x40]
000071ff71be24ad  vmovaps xmm5, [rsp+0x50]
000071ff71be24b3  vmovaps xmm6, [rsp+0x60]
000071ff71be24b9  vmovaps xmm7, [rsp+0x70]
000071ff71be24bf  vmovaps xmm8, [rsp+0x80]
000071ff71be24c8  vmovaps xmm9, [rsp+0x90]
000071ff71be24d1  vmovaps xmm10, [rsp+0xA0]
000071ff71be24da  vmovaps xmm11, [rsp+0xB0]
000071ff71be24e3  vmovaps xmm12, [rsp+0xC0]
000071ff71be24ec  vmovaps xmm13, [rsp+0xD0]
000071ff71be24f5  vmovaps xmm14, [rsp+0xE0]
000071ff71be24fe  add rsp, 0xF0
000071ff71be2505  pop r11
000071ff71be2507  pop r10
000071ff71be2509  pop r9
000071ff71be250b  pop r8
000071ff71be250d  pop rsi
000071ff71be250e  pop rdi
000071ff71be250f  pop rdx
000071ff71be2510  pop rcx
000071ff71be2511  pop rax
000071ff71be2512  add rsp, 0x08
000071ff71be2516  jmp 0x000071FF71BDF56F
000071ff71be251b  sub rsp, 0x08
000071ff71be251f  push rax
000071ff71be2520  push rcx
000071ff71be2521  push rdx
000071ff71be2522  push rdi
000071ff71be2523  push rsi
000071ff71be2524  push r8
000071ff71be2526  push r9
000071ff71be2528  push r10
000071ff71be252a  push r11
000071ff71be252c  sub rsp, 0xF0
000071ff71be2533  vmovaps [rsp], xmm0
000071ff71be2538  vmovaps [rsp+0x10], xmm1
000071ff71be253e  vmovaps [rsp+0x20], xmm2
000071ff71be2544  vmovaps [rsp+0x30], xmm3
000071ff71be254a  vmovaps [rsp+0x40], xmm4
000071ff71be2550  vmovaps [rsp+0x50], xmm6
000071ff71be2556  vmovaps [rsp+0x60], xmm7
000071ff71be255c  vmovaps [rsp+0x70], xmm8
000071ff71be2562  vmovaps [rsp+0x80], xmm9
000071ff71be256b  vmovaps [rsp+0x90], xmm10
000071ff71be2574  vmovaps [rsp+0xA0], xmm11
000071ff71be257d  vmovaps [rsp+0xB0], xmm12
000071ff71be2586  vmovaps [rsp+0xC0], xmm13
000071ff71be258f  vmovaps [rsp+0xD0], xmm14
000071ff71be2598  vmovaps [rsp+0xE0], xmm15
000071ff71be25a1  sub rsp, 0x30
000071ff71be25a5  movaps [rsp], xmm5
000071ff71be25a9  movaps [rsp+0x10], xmm8
000071ff71be25af  movaps [rsp+0x20], xmm6
000071ff71be25b4  lea rdi, [rsp]
000071ff71be25b8  mov esi, 0x00
000071ff71be25bd  mov rax, 0x5E6872E10530
000071ff71be25c7  call rax
000071ff71be25c9  movaps xmm5, [rsp]
000071ff71be25cd  add rsp, 0x30
000071ff71be25d1  vmovaps xmm0, [rsp]
000071ff71be25d6  vmovaps xmm1, [rsp+0x10]
000071ff71be25dc  vmovaps xmm2, [rsp+0x20]
000071ff71be25e2  vmovaps xmm3, [rsp+0x30]
000071ff71be25e8  vmovaps xmm4, [rsp+0x40]
000071ff71be25ee  vmovaps xmm6, [rsp+0x50]
000071ff71be25f4  vmovaps xmm7, [rsp+0x60]
000071ff71be25fa  vmovaps xmm8, [rsp+0x70]
000071ff71be2600  vmovaps xmm9, [rsp+0x80]
000071ff71be2609  vmovaps xmm10, [rsp+0x90]
000071ff71be2612  vmovaps xmm11, [rsp+0xA0]
000071ff71be261b  vmovaps xmm12, [rsp+0xB0]
000071ff71be2624  vmovaps xmm13, [rsp+0xC0]
000071ff71be262d  vmovaps xmm14, [rsp+0xD0]
000071ff71be2636  vmovaps xmm15, [rsp+0xE0]
000071ff71be263f  add rsp, 0xF0
000071ff71be2646  pop r11
000071ff71be2648  pop r10
000071ff71be264a  pop r9
000071ff71be264c  pop r8
000071ff71be264e  pop rsi
000071ff71be264f  pop rdi
000071ff71be2650  pop rdx
000071ff71be2651  pop rcx
000071ff71be2652  pop rax
000071ff71be2653  add rsp, 0x08
000071ff71be2657  jmp 0x000071FF71BDF593
000071ff71be265c  sub rsp, 0x08
000071ff71be2660  push rax
000071ff71be2661  push rcx
000071ff71be2662  push rdx
000071ff71be2663  push rdi
000071ff71be2664  push rsi
000071ff71be2665  push r8
000071ff71be2667  push r9
000071ff71be2669  push r10
000071ff71be266b  push r11
000071ff71be266d  sub rsp, 0xF0
000071ff71be2674  vmovaps [rsp], xmm0
000071ff71be2679  vmovaps [rsp+0x10], xmm1
000071ff71be267f  vmovaps [rsp+0x20], xmm2
000071ff71be2685  vmovaps [rsp+0x30], xmm3
000071ff71be268b  vmovaps [rsp+0x40], xmm4
000071ff71be2691  vmovaps [rsp+0x50], xmm5
000071ff71be2697  vmovaps [rsp+0x60], xmm7
000071ff71be269d  vmovaps [rsp+0x70], xmm8
000071ff71be26a3  vmovaps [rsp+0x80], xmm9
000071ff71be26ac  vmovaps [rsp+0x90], xmm10
000071ff71be26b5  vmovaps [rsp+0xA0], xmm11
000071ff71be26be  vmovaps [rsp+0xB0], xmm12
000071ff71be26c7  vmovaps [rsp+0xC0], xmm13
000071ff71be26d0  vmovaps [rsp+0xD0], xmm14
000071ff71be26d9  vmovaps [rsp+0xE0], xmm15
000071ff71be26e2  sub rsp, 0x30
000071ff71be26e6  movaps [rsp], xmm6
000071ff71be26ea  movaps [rsp+0x10], xmm10
000071ff71be26f0  movaps [rsp+0x20], xmm8
000071ff71be26f6  lea rdi, [rsp]
000071ff71be26fa  mov esi, 0x00
000071ff71be26ff  mov rax, 0x5E6872E10530
000071ff71be2709  call rax
000071ff71be270b  movaps xmm6, [rsp]
000071ff71be270f  add rsp, 0x30
000071ff71be2713  vmovaps xmm0, [rsp]
000071ff71be2718  vmovaps xmm1, [rsp+0x10]
000071ff71be271e  vmovaps xmm2, [rsp+0x20]
000071ff71be2724  vmovaps xmm3, [rsp+0x30]
000071ff71be272a  vmovaps xmm4, [rsp+0x40]
000071ff71be2730  vmovaps xmm5, [rsp+0x50]
000071ff71be2736  vmovaps xmm7, [rsp+0x60]
000071ff71be273c  vmovaps xmm8, [rsp+0x70]
000071ff71be2742  vmovaps xmm9, [rsp+0x80]
000071ff71be274b  vmovaps xmm10, [rsp+0x90]
000071ff71be2754  vmovaps xmm11, [rsp+0xA0]
000071ff71be275d  vmovaps xmm12, [rsp+0xB0]
000071ff71be2766  vmovaps xmm13, [rsp+0xC0]
000071ff71be276f  vmovaps xmm14, [rsp+0xD0]
000071ff71be2778  vmovaps xmm15, [rsp+0xE0]
000071ff71be2781  add rsp, 0xF0
000071ff71be2788  pop r11
000071ff71be278a  pop r10
000071ff71be278c  pop r9
000071ff71be278e  pop r8
000071ff71be2790  pop rsi
000071ff71be2791  pop rdi
000071ff71be2792  pop rdx
000071ff71be2793  pop rcx
000071ff71be2794  pop rax
000071ff71be2795  add rsp, 0x08
000071ff71be2799  jmp 0x000071FF71BDF5B8
000071ff71be279e  sub rsp, 0x08
000071ff71be27a2  push rax
000071ff71be27a3  push rcx
000071ff71be27a4  push rdx
000071ff71be27a5  push rdi
000071ff71be27a6  push rsi
000071ff71be27a7  push r8
000071ff71be27a9  push r9
000071ff71be27ab  push r10
000071ff71be27ad  push r11
000071ff71be27af  sub rsp, 0xF0
000071ff71be27b6  vmovaps [rsp], xmm0
000071ff71be27bb  vmovaps [rsp+0x10], xmm1
000071ff71be27c1  vmovaps [rsp+0x20], xmm2
000071ff71be27c7  vmovaps [rsp+0x30], xmm3
000071ff71be27cd  vmovaps [rsp+0x40], xmm4
000071ff71be27d3  vmovaps [rsp+0x50], xmm5
000071ff71be27d9  vmovaps [rsp+0x60], xmm6
000071ff71be27df  vmovaps [rsp+0x70], xmm7
000071ff71be27e5  vmovaps [rsp+0x80], xmm8
000071ff71be27ee  vmovaps [rsp+0x90], xmm9
000071ff71be27f7  vmovaps [rsp+0xA0], xmm11
000071ff71be2800  vmovaps [rsp+0xB0], xmm12
000071ff71be2809  vmovaps [rsp+0xC0], xmm13
000071ff71be2812  vmovaps [rsp+0xD0], xmm14
000071ff71be281b  vmovaps [rsp+0xE0], xmm15
000071ff71be2824  sub rsp, 0x30
000071ff71be2828  movaps [rsp], xmm10
000071ff71be282d  movaps [rsp+0x10], xmm8
000071ff71be2833  movaps [rsp+0x20], xmm14
000071ff71be2839  lea rdi, [rsp]
000071ff71be283d  mov esi, 0x00
000071ff71be2842  mov rax, 0x5E6872E10530
000071ff71be284c  call rax
000071ff71be284e  movaps xmm10, [rsp]
000071ff71be2853  add rsp, 0x30
000071ff71be2857  vmovaps xmm0, [rsp]
000071ff71be285c  vmovaps xmm1, [rsp+0x10]
000071ff71be2862  vmovaps xmm2, [rsp+0x20]
000071ff71be2868  vmovaps xmm3, [rsp+0x30]
000071ff71be286e  vmovaps xmm4, [rsp+0x40]
000071ff71be2874  vmovaps xmm5, [rsp+0x50]
000071ff71be287a  vmovaps xmm6, [rsp+0x60]
000071ff71be2880  vmovaps xmm7, [rsp+0x70]
000071ff71be2886  vmovaps xmm8, [rsp+0x80]
000071ff71be288f  vmovaps xmm9, [rsp+0x90]
000071ff71be2898  vmovaps xmm11, [rsp+0xA0]
000071ff71be28a1  vmovaps xmm12, [rsp+0xB0]
000071ff71be28aa  vmovaps xmm13, [rsp+0xC0]
000071ff71be28b3  vmovaps xmm14, [rsp+0xD0]
000071ff71be28bc  vmovaps xmm15, [rsp+0xE0]
000071ff71be28c5  add rsp, 0xF0
000071ff71be28cc  pop r11
000071ff71be28ce  pop r10
000071ff71be28d0  pop r9
000071ff71be28d2  pop r8
000071ff71be28d4  pop rsi
000071ff71be28d5  pop rdi
000071ff71be28d6  pop rdx
000071ff71be28d7  pop rcx
000071ff71be28d8  pop rax
000071ff71be28d9  add rsp, 0x08
000071ff71be28dd  jmp 0x000071FF71BDF5D8
000071ff71be28e2  sub rsp, 0x08
000071ff71be28e6  push rax
000071ff71be28e7  push rcx
000071ff71be28e8  push rdx
000071ff71be28e9  push rdi
000071ff71be28ea  push rsi
000071ff71be28eb  push r8
000071ff71be28ed  push r9
000071ff71be28ef  push r10
000071ff71be28f1  push r11
000071ff71be28f3  sub rsp, 0xF0
000071ff71be28fa  vmovaps [rsp], xmm0
000071ff71be28ff  vmovaps [rsp+0x10], xmm1
000071ff71be2905  vmovaps [rsp+0x20], xmm2
000071ff71be290b  vmovaps [rsp+0x30], xmm3
000071ff71be2911  vmovaps [rsp+0x40], xmm4
000071ff71be2917  vmovaps [rsp+0x50], xmm5
000071ff71be291d  vmovaps [rsp+0x60], xmm6
000071ff71be2923  vmovaps [rsp+0x70], xmm7
000071ff71be2929  vmovaps [rsp+0x80], xmm8
000071ff71be2932  vmovaps [rsp+0x90], xmm9
000071ff71be293b  vmovaps [rsp+0xA0], xmm10
000071ff71be2944  vmovaps [rsp+0xB0], xmm11
000071ff71be294d  vmovaps [rsp+0xC0], xmm12
000071ff71be2956  vmovaps [rsp+0xD0], xmm13
000071ff71be295f  vmovaps [rsp+0xE0], xmm15
000071ff71be2968  sub rsp, 0x30
000071ff71be296c  movaps [rsp], xmm14
000071ff71be2971  movaps [rsp+0x10], xmm8
000071ff71be2977  movaps [rsp+0x20], xmm4
000071ff71be297c  lea rdi, [rsp]
000071ff71be2980  mov esi, 0x00
000071ff71be2985  mov rax, 0x5E6872E10530
000071ff71be298f  call rax
000071ff71be2991  movaps xmm14, [rsp]
000071ff71be2996  add rsp, 0x30
000071ff71be299a  vmovaps xmm0, [rsp]
000071ff71be299f  vmovaps xmm1, [rsp+0x10]
000071ff71be29a5  vmovaps xmm2, [rsp+0x20]
000071ff71be29ab  vmovaps xmm3, [rsp+0x30]
000071ff71be29b1  vmovaps xmm4, [rsp+0x40]
000071ff71be29b7  vmovaps xmm5, [rsp+0x50]
000071ff71be29bd  vmovaps xmm6, [rsp+0x60]
000071ff71be29c3  vmovaps xmm7, [rsp+0x70]
000071ff71be29c9  vmovaps xmm8, [rsp+0x80]
000071ff71be29d2  vmovaps xmm9, [rsp+0x90]
000071ff71be29db  vmovaps xmm10, [rsp+0xA0]
000071ff71be29e4  vmovaps xmm11, [rsp+0xB0]
000071ff71be29ed  vmovaps xmm12, [rsp+0xC0]
000071ff71be29f6  vmovaps xmm13, [rsp+0xD0]
000071ff71be29ff  vmovaps xmm15, [rsp+0xE0]
000071ff71be2a08  add rsp, 0xF0
000071ff71be2a0f  pop r11
000071ff71be2a11  pop r10
000071ff71be2a13  pop r9
000071ff71be2a15  pop r8
000071ff71be2a17  pop rsi
000071ff71be2a18  pop rdi
000071ff71be2a19  pop rdx
000071ff71be2a1a  pop rcx
000071ff71be2a1b  pop rax
000071ff71be2a1c  add rsp, 0x08
000071ff71be2a20  jmp 0x000071FF71BDF5F8
000071ff71be2a25  sub rsp, 0x08
000071ff71be2a29  push rax
000071ff71be2a2a  push rcx
000071ff71be2a2b  push rdx
000071ff71be2a2c  push rdi
000071ff71be2a2d  push rsi
000071ff71be2a2e  push r8
000071ff71be2a30  push r9
000071ff71be2a32  push r10
000071ff71be2a34  push r11
000071ff71be2a36  sub rsp, 0xF0
000071ff71be2a3d  vmovaps [rsp], xmm0
000071ff71be2a42  vmovaps [rsp+0x10], xmm1
000071ff71be2a48  vmovaps [rsp+0x20], xmm2
000071ff71be2a4e  vmovaps [rsp+0x30], xmm3
000071ff71be2a54  vmovaps [rsp+0x40], xmm5
000071ff71be2a5a  vmovaps [rsp+0x50], xmm6
000071ff71be2a60  vmovaps [rsp+0x60], xmm7
000071ff71be2a66  vmovaps [rsp+0x70], xmm8
000071ff71be2a6c  vmovaps [rsp+0x80], xmm9
000071ff71be2a75  vmovaps [rsp+0x90], xmm10
000071ff71be2a7e  vmovaps [rsp+0xA0], xmm11
000071ff71be2a87  vmovaps [rsp+0xB0], xmm12
000071ff71be2a90  vmovaps [rsp+0xC0], xmm13
000071ff71be2a99  vmovaps [rsp+0xD0], xmm14
000071ff71be2aa2  vmovaps [rsp+0xE0], xmm15
000071ff71be2aab  sub rsp, 0x30
000071ff71be2aaf  movaps [rsp], xmm4
000071ff71be2ab3  movaps [rsp+0x10], xmm13
000071ff71be2ab9  movaps [rsp+0x20], xmm8
000071ff71be2abf  lea rdi, [rsp]
000071ff71be2ac3  mov esi, 0x00
000071ff71be2ac8  mov rax, 0x5E6872E10530
000071ff71be2ad2  call rax
000071ff71be2ad4  movaps xmm4, [rsp]
000071ff71be2ad8  add rsp, 0x30
000071ff71be2adc  vmovaps xmm0, [rsp]
000071ff71be2ae1  vmovaps xmm1, [rsp+0x10]
000071ff71be2ae7  vmovaps xmm2, [rsp+0x20]
000071ff71be2aed  vmovaps xmm3, [rsp+0x30]
000071ff71be2af3  vmovaps xmm5, [rsp+0x40]
000071ff71be2af9  vmovaps xmm6, [rsp+0x50]
000071ff71be2aff  vmovaps xmm7, [rsp+0x60]
000071ff71be2b05  vmovaps xmm8, [rsp+0x70]
000071ff71be2b0b  vmovaps xmm9, [rsp+0x80]
000071ff71be2b14  vmovaps xmm10, [rsp+0x90]
000071ff71be2b1d  vmovaps xmm11, [rsp+0xA0]
000071ff71be2b26  vmovaps xmm12, [rsp+0xB0]
000071ff71be2b2f  vmovaps xmm13, [rsp+0xC0]
000071ff71be2b38  vmovaps xmm14, [rsp+0xD0]
000071ff71be2b41  vmovaps xmm15, [rsp+0xE0]
000071ff71be2b4a  add rsp, 0xF0
000071ff71be2b51  pop r11
000071ff71be2b53  pop r10
000071ff71be2b55  pop r9
000071ff71be2b57  pop r8
000071ff71be2b59  pop rsi
000071ff71be2b5a  pop rdi
000071ff71be2b5b  pop rdx
000071ff71be2b5c  pop rcx
000071ff71be2b5d  pop rax
000071ff71be2b5e  add rsp, 0x08
000071ff71be2b62  jmp 0x000071FF71BDF61D
000071ff71be2b67  sub rsp, 0x08
000071ff71be2b6b  push rax
000071ff71be2b6c  push rcx
000071ff71be2b6d  push rdx
000071ff71be2b6e  push rdi
000071ff71be2b6f  push rsi
000071ff71be2b70  push r8
000071ff71be2b72  push r9
000071ff71be2b74  push r10
000071ff71be2b76  push r11
000071ff71be2b78  sub rsp, 0xF0
000071ff71be2b7f  vmovaps [rsp], xmm0
000071ff71be2b84  vmovaps [rsp+0x10], xmm1
000071ff71be2b8a  vmovaps [rsp+0x20], xmm2
000071ff71be2b90  vmovaps [rsp+0x30], xmm3
000071ff71be2b96  vmovaps [rsp+0x40], xmm4
000071ff71be2b9c  vmovaps [rsp+0x50], xmm5
000071ff71be2ba2  vmovaps [rsp+0x60], xmm6
000071ff71be2ba8  vmovaps [rsp+0x70], xmm7
000071ff71be2bae  vmovaps [rsp+0x80], xmm8
000071ff71be2bb7  vmovaps [rsp+0x90], xmm9
000071ff71be2bc0  vmovaps [rsp+0xA0], xmm10
000071ff71be2bc9  vmovaps [rsp+0xB0], xmm11
000071ff71be2bd2  vmovaps [rsp+0xC0], xmm12
000071ff71be2bdb  vmovaps [rsp+0xD0], xmm14
000071ff71be2be4  vmovaps [rsp+0xE0], xmm15
000071ff71be2bed  sub rsp, 0x30
000071ff71be2bf1  movaps [rsp], xmm13
000071ff71be2bf6  movaps [rsp+0x10], xmm15
000071ff71be2bfc  movaps [rsp+0x20], xmm9
000071ff71be2c02  lea rdi, [rsp]
000071ff71be2c06  mov esi, 0x00
000071ff71be2c0b  mov rax, 0x5E6872E10530
000071ff71be2c15  call rax
000071ff71be2c17  movaps xmm13, [rsp]
000071ff71be2c1c  add rsp, 0x30
000071ff71be2c20  vmovaps xmm0, [rsp]
000071ff71be2c25  vmovaps xmm1, [rsp+0x10]
000071ff71be2c2b  vmovaps xmm2, [rsp+0x20]
000071ff71be2c31  vmovaps xmm3, [rsp+0x30]
000071ff71be2c37  vmovaps xmm4, [rsp+0x40]
000071ff71be2c3d  vmovaps xmm5, [rsp+0x50]
000071ff71be2c43  vmovaps xmm6, [rsp+0x60]
000071ff71be2c49  vmovaps xmm7, [rsp+0x70]
000071ff71be2c4f  vmovaps xmm8, [rsp+0x80]
000071ff71be2c58  vmovaps xmm9, [rsp+0x90]
000071ff71be2c61  vmovaps xmm10, [rsp+0xA0]
000071ff71be2c6a  vmovaps xmm11, [rsp+0xB0]
000071ff71be2c73  vmovaps xmm12, [rsp+0xC0]
000071ff71be2c7c  vmovaps xmm14, [rsp+0xD0]
000071ff71be2c85  vmovaps xmm15, [rsp+0xE0]
000071ff71be2c8e  add rsp, 0xF0
000071ff71be2c95  pop r11
000071ff71be2c97  pop r10
000071ff71be2c99  pop r9
000071ff71be2c9b  pop r8
000071ff71be2c9d  pop rsi
000071ff71be2c9e  pop rdi
000071ff71be2c9f  pop rdx
000071ff71be2ca0  pop rcx
000071ff71be2ca1  pop rax
000071ff71be2ca2  add rsp, 0x08
000071ff71be2ca6  jmp 0x000071FF71BDF638
000071ff71be2cab  sub rsp, 0x08
000071ff71be2caf  push rax
000071ff71be2cb0  push rcx
000071ff71be2cb1  push rdx
000071ff71be2cb2  push rdi
000071ff71be2cb3  push rsi
000071ff71be2cb4  push r8
000071ff71be2cb6  push r9
000071ff71be2cb8  push r10
000071ff71be2cba  push r11
000071ff71be2cbc  sub rsp, 0xF0
000071ff71be2cc3  vmovaps [rsp], xmm0
000071ff71be2cc8  vmovaps [rsp+0x10], xmm1
000071ff71be2cce  vmovaps [rsp+0x20], xmm2
000071ff71be2cd4  vmovaps [rsp+0x30], xmm3
000071ff71be2cda  vmovaps [rsp+0x40], xmm4
000071ff71be2ce0  vmovaps [rsp+0x50], xmm5
000071ff71be2ce6  vmovaps [rsp+0x60], xmm6
000071ff71be2cec  vmovaps [rsp+0x70], xmm7
000071ff71be2cf2  vmovaps [rsp+0x80], xmm8
000071ff71be2cfb  vmovaps [rsp+0x90], xmm9
000071ff71be2d04  vmovaps [rsp+0xA0], xmm10
000071ff71be2d0d  vmovaps [rsp+0xB0], xmm11
000071ff71be2d16  vmovaps [rsp+0xC0], xmm12
000071ff71be2d1f  vmovaps [rsp+0xD0], xmm13
000071ff71be2d28  vmovaps [rsp+0xE0], xmm14
000071ff71be2d31  sub rsp, 0x30
000071ff71be2d35  movaps [rsp], xmm15
000071ff71be2d3a  movaps [rsp+0x10], xmm1
000071ff71be2d3f  movaps [rsp+0x20], xmm5
000071ff71be2d44  lea rdi, [rsp]
000071ff71be2d48  mov esi, 0x00
000071ff71be2d4d  mov rax, 0x5E6872E10530
000071ff71be2d57  call rax
000071ff71be2d59  movaps xmm15, [rsp]
000071ff71be2d5e  add rsp, 0x30
000071ff71be2d62  vmovaps xmm0, [rsp]
000071ff71be2d67  vmovaps xmm1, [rsp+0x10]
000071ff71be2d6d  vmovaps xmm2, [rsp+0x20]
000071ff71be2d73  vmovaps xmm3, [rsp+0x30]
000071ff71be2d79  vmovaps xmm4, [rsp+0x40]
000071ff71be2d7f  vmovaps xmm5, [rsp+0x50]
000071ff71be2d85  vmovaps xmm6, [rsp+0x60]
000071ff71be2d8b  vmovaps xmm7, [rsp+0x70]
000071ff71be2d91  vmovaps xmm8, [rsp+0x80]
000071ff71be2d9a  vmovaps xmm9, [rsp+0x90]
000071ff71be2da3  vmovaps xmm10, [rsp+0xA0]
000071ff71be2dac  vmovaps xmm11, [rsp+0xB0]
000071ff71be2db5  vmovaps xmm12, [rsp+0xC0]
000071ff71be2dbe  vmovaps xmm13, [rsp+0xD0]
000071ff71be2dc7  vmovaps xmm14, [rsp+0xE0]
000071ff71be2dd0  add rsp, 0xF0
000071ff71be2dd7  pop r11
000071ff71be2dd9  pop r10
000071ff71be2ddb  pop r9
000071ff71be2ddd  pop r8
000071ff71be2ddf  pop rsi
000071ff71be2de0  pop rdi
000071ff71be2de1  pop rdx
000071ff71be2de2  pop rcx
000071ff71be2de3  pop rax
000071ff71be2de4  add rsp, 0x08
000071ff71be2de8  jmp 0x000071FF71BDF653
000071ff71be2ded  call 0x000071FF71AB52F0
000071ff71be2df2  jmp 0x000071FF71BDF6AE
000071ff71be2df7  sub rsp, 0x08
000071ff71be2dfb  push rax
000071ff71be2dfc  push rcx
000071ff71be2dfd  push rdx
000071ff71be2dfe  push rdi
000071ff71be2dff  push rsi
000071ff71be2e00  push r8
000071ff71be2e02  push r9
000071ff71be2e04  push r10
000071ff71be2e06  push r11
000071ff71be2e08  sub rsp, 0xF0
000071ff71be2e0f  vmovaps [rsp], xmm0
000071ff71be2e14  vmovaps [rsp+0x10], xmm1
000071ff71be2e1a  vmovaps [rsp+0x20], xmm2
000071ff71be2e20  vmovaps [rsp+0x30], xmm3
000071ff71be2e26  vmovaps [rsp+0x40], xmm4
000071ff71be2e2c  vmovaps [rsp+0x50], xmm5
000071ff71be2e32  vmovaps [rsp+0x60], xmm6
000071ff71be2e38  vmovaps [rsp+0x70], xmm7
000071ff71be2e3e  vmovaps [rsp+0x80], xmm8
000071ff71be2e47  vmovaps [rsp+0x90], xmm10
000071ff71be2e50  vmovaps [rsp+0xA0], xmm11
000071ff71be2e59  vmovaps [rsp+0xB0], xmm12
000071ff71be2e62  vmovaps [rsp+0xC0], xmm13
000071ff71be2e6b  vmovaps [rsp+0xD0], xmm14
000071ff71be2e74  vmovaps [rsp+0xE0], xmm15
000071ff71be2e7d  sub rsp, 0x30
000071ff71be2e81  movaps [rsp], xmm9
000071ff71be2e86  movaps [rsp+0x10], xmm8
000071ff71be2e8c  movaps [rsp+0x20], xmm11
000071ff71be2e92  lea rdi, [rsp]
000071ff71be2e96  mov esi, 0x00
000071ff71be2e9b  mov rax, 0x5E6872E10530
000071ff71be2ea5  call rax
000071ff71be2ea7  movaps xmm9, [rsp]
000071ff71be2eac  add rsp, 0x30
000071ff71be2eb0  vmovaps xmm0, [rsp]
000071ff71be2eb5  vmovaps xmm1, [rsp+0x10]
000071ff71be2ebb  vmovaps xmm2, [rsp+0x20]
000071ff71be2ec1  vmovaps xmm3, [rsp+0x30]
000071ff71be2ec7  vmovaps xmm4, [rsp+0x40]
000071ff71be2ecd  vmovaps xmm5, [rsp+0x50]
000071ff71be2ed3  vmovaps xmm6, [rsp+0x60]
000071ff71be2ed9  vmovaps xmm7, [rsp+0x70]
000071ff71be2edf  vmovaps xmm8, [rsp+0x80]
000071ff71be2ee8  vmovaps xmm10, [rsp+0x90]
000071ff71be2ef1  vmovaps xmm11, [rsp+0xA0]
000071ff71be2efa  vmovaps xmm12, [rsp+0xB0]
000071ff71be2f03  vmovaps xmm13, [rsp+0xC0]
000071ff71be2f0c  vmovaps xmm14, [rsp+0xD0]
000071ff71be2f15  vmovaps xmm15, [rsp+0xE0]
000071ff71be2f1e  add rsp, 0xF0
000071ff71be2f25  pop r11
000071ff71be2f27  pop r10
000071ff71be2f29  pop r9
000071ff71be2f2b  pop r8
000071ff71be2f2d  pop rsi
000071ff71be2f2e  pop rdi
000071ff71be2f2f  pop rdx
000071ff71be2f30  pop rcx
000071ff71be2f31  pop rax
000071ff71be2f32  add rsp, 0x08
000071ff71be2f36  jmp 0x000071FF71BDF6E5
000071ff71be2f3b  sub rsp, 0x08
000071ff71be2f3f  push rax
000071ff71be2f40  push rcx
000071ff71be2f41  push rdx
000071ff71be2f42  push rdi
000071ff71be2f43  push rsi
000071ff71be2f44  push r8
000071ff71be2f46  push r9
000071ff71be2f48  push r10
000071ff71be2f4a  push r11
000071ff71be2f4c  sub rsp, 0xF0
000071ff71be2f53  vmovaps [rsp], xmm0
000071ff71be2f58  vmovaps [rsp+0x10], xmm1
000071ff71be2f5e  vmovaps [rsp+0x20], xmm2
000071ff71be2f64  vmovaps [rsp+0x30], xmm3
000071ff71be2f6a  vmovaps [rsp+0x40], xmm4
000071ff71be2f70  vmovaps [rsp+0x50], xmm5
000071ff71be2f76  vmovaps [rsp+0x60], xmm6
000071ff71be2f7c  vmovaps [rsp+0x70], xmm7
000071ff71be2f82  vmovaps [rsp+0x80], xmm8
000071ff71be2f8b  vmovaps [rsp+0x90], xmm9
000071ff71be2f94  vmovaps [rsp+0xA0], xmm10
000071ff71be2f9d  vmovaps [rsp+0xB0], xmm12
000071ff71be2fa6  vmovaps [rsp+0xC0], xmm13
000071ff71be2faf  vmovaps [rsp+0xD0], xmm14
000071ff71be2fb8  vmovaps [rsp+0xE0], xmm15
000071ff71be2fc1  sub rsp, 0x30
000071ff71be2fc5  movaps [rsp], xmm11
000071ff71be2fca  movaps [rsp+0x10], xmm10
000071ff71be2fd0  movaps [rsp+0x20], xmm6
000071ff71be2fd5  lea rdi, [rsp]
000071ff71be2fd9  mov esi, 0x00
000071ff71be2fde  mov rax, 0x5E6872E10530
000071ff71be2fe8  call rax
000071ff71be2fea  movaps xmm11, [rsp]
000071ff71be2fef  add rsp, 0x30
000071ff71be2ff3  vmovaps xmm0, [rsp]
000071ff71be2ff8  vmovaps xmm1, [rsp+0x10]
000071ff71be2ffe  vmovaps xmm2, [rsp+0x20]
000071ff71be3004  vmovaps xmm3, [rsp+0x30]
000071ff71be300a  vmovaps xmm4, [rsp+0x40]
000071ff71be3010  vmovaps xmm5, [rsp+0x50]
000071ff71be3016  vmovaps xmm6, [rsp+0x60]
000071ff71be301c  vmovaps xmm7, [rsp+0x70]
000071ff71be3022  vmovaps xmm8, [rsp+0x80]
000071ff71be302b  vmovaps xmm9, [rsp+0x90]
000071ff71be3034  vmovaps xmm10, [rsp+0xA0]
000071ff71be303d  vmovaps xmm12, [rsp+0xB0]
000071ff71be3046  vmovaps xmm13, [rsp+0xC0]
000071ff71be304f  vmovaps xmm14, [rsp+0xD0]
000071ff71be3058  vmovaps xmm15, [rsp+0xE0]
000071ff71be3061  add rsp, 0xF0
000071ff71be3068  pop r11
000071ff71be306a  pop r10
000071ff71be306c  pop r9
000071ff71be306e  pop r8
000071ff71be3070  pop rsi
000071ff71be3071  pop rdi
000071ff71be3072  pop rdx
000071ff71be3073  pop rcx
000071ff71be3074  pop rax
000071ff71be3075  add rsp, 0x08
000071ff71be3079  jmp 0x000071FF71BDF700
000071ff71be307e  sub rsp, 0x08
000071ff71be3082  push rax
000071ff71be3083  push rcx
000071ff71be3084  push rdx
000071ff71be3085  push rdi
000071ff71be3086  push rsi
000071ff71be3087  push r8
000071ff71be3089  push r9
000071ff71be308b  push r10
000071ff71be308d  push r11
000071ff71be308f  sub rsp, 0xF0
000071ff71be3096  vmovaps [rsp], xmm0
000071ff71be309b  vmovaps [rsp+0x10], xmm1
000071ff71be30a1  vmovaps [rsp+0x20], xmm2
000071ff71be30a7  vmovaps [rsp+0x30], xmm3
000071ff71be30ad  vmovaps [rsp+0x40], xmm4
000071ff71be30b3  vmovaps [rsp+0x50], xmm5
000071ff71be30b9  vmovaps [rsp+0x60], xmm6
000071ff71be30bf  vmovaps [rsp+0x70], xmm7
000071ff71be30c5  vmovaps [rsp+0x80], xmm8
000071ff71be30ce  vmovaps [rsp+0x90], xmm9
000071ff71be30d7  vmovaps [rsp+0xA0], xmm11
000071ff71be30e0  vmovaps [rsp+0xB0], xmm12
000071ff71be30e9  vmovaps [rsp+0xC0], xmm13
000071ff71be30f2  vmovaps [rsp+0xD0], xmm14
000071ff71be30fb  vmovaps [rsp+0xE0], xmm15
000071ff71be3104  sub rsp, 0x30
000071ff71be3108  movaps [rsp], xmm10
000071ff71be310d  movaps [rsp+0x10], xmm14
000071ff71be3113  movaps [rsp+0x20], xmm4
000071ff71be3118  lea rdi, [rsp]
000071ff71be311c  mov esi, 0x00
000071ff71be3121  mov rax, 0x5E6872E10530
000071ff71be312b  call rax
000071ff71be312d  movaps xmm10, [rsp]
000071ff71be3132  add rsp, 0x30
000071ff71be3136  vmovaps xmm0, [rsp]
000071ff71be313b  vmovaps xmm1, [rsp+0x10]
000071ff71be3141  vmovaps xmm2, [rsp+0x20]
000071ff71be3147  vmovaps xmm3, [rsp+0x30]
000071ff71be314d  vmovaps xmm4, [rsp+0x40]
000071ff71be3153  vmovaps xmm5, [rsp+0x50]
000071ff71be3159  vmovaps xmm6, [rsp+0x60]
000071ff71be315f  vmovaps xmm7, [rsp+0x70]
000071ff71be3165  vmovaps xmm8, [rsp+0x80]
000071ff71be316e  vmovaps xmm9, [rsp+0x90]
000071ff71be3177  vmovaps xmm11, [rsp+0xA0]
000071ff71be3180  vmovaps xmm12, [rsp+0xB0]
000071ff71be3189  vmovaps xmm13, [rsp+0xC0]
000071ff71be3192  vmovaps xmm14, [rsp+0xD0]
000071ff71be319b  vmovaps xmm15, [rsp+0xE0]
000071ff71be31a4  add rsp, 0xF0
000071ff71be31ab  pop r11
000071ff71be31ad  pop r10
000071ff71be31af  pop r9
000071ff71be31b1  pop r8
000071ff71be31b3  pop rsi
000071ff71be31b4  pop rdi
000071ff71be31b5  pop rdx
000071ff71be31b6  pop rcx
000071ff71be31b7  pop rax
000071ff71be31b8  add rsp, 0x08
000071ff71be31bc  jmp 0x000071FF71BDF71B
000071ff71be31c1  sub rsp, 0x08
000071ff71be31c5  push rax
000071ff71be31c6  push rcx
000071ff71be31c7  push rdx
000071ff71be31c8  push rdi
000071ff71be31c9  push rsi
000071ff71be31ca  push r8
000071ff71be31cc  push r9
000071ff71be31ce  push r10
000071ff71be31d0  push r11
000071ff71be31d2  sub rsp, 0xF0
000071ff71be31d9  vmovaps [rsp], xmm0
000071ff71be31de  vmovaps [rsp+0x10], xmm1
000071ff71be31e4  vmovaps [rsp+0x20], xmm2
000071ff71be31ea  vmovaps [rsp+0x30], xmm3
000071ff71be31f0  vmovaps [rsp+0x40], xmm4
000071ff71be31f6  vmovaps [rsp+0x50], xmm5
000071ff71be31fc  vmovaps [rsp+0x60], xmm6
000071ff71be3202  vmovaps [rsp+0x70], xmm7
000071ff71be3208  vmovaps [rsp+0x80], xmm9
000071ff71be3211  vmovaps [rsp+0x90], xmm10
000071ff71be321a  vmovaps [rsp+0xA0], xmm11
000071ff71be3223  vmovaps [rsp+0xB0], xmm12
000071ff71be322c  vmovaps [rsp+0xC0], xmm13
000071ff71be3235  vmovaps [rsp+0xD0], xmm14
000071ff71be323e  vmovaps [rsp+0xE0], xmm15
000071ff71be3247  sub rsp, 0x30
000071ff71be324b  movaps [rsp], xmm8
000071ff71be3250  movaps [rsp+0x10], xmm1
000071ff71be3255  movaps [rsp+0x20], xmm14
000071ff71be325b  lea rdi, [rsp]
000071ff71be325f  mov esi, 0x00
000071ff71be3264  mov rax, 0x5E6872E10530
000071ff71be326e  call rax
000071ff71be3270  movaps xmm8, [rsp]
000071ff71be3275  add rsp, 0x30
000071ff71be3279  vmovaps xmm0, [rsp]
000071ff71be327e  vmovaps xmm1, [rsp+0x10]
000071ff71be3284  vmovaps xmm2, [rsp+0x20]
000071ff71be328a  vmovaps xmm3, [rsp+0x30]
000071ff71be3290  vmovaps xmm4, [rsp+0x40]
000071ff71be3296  vmovaps xmm5, [rsp+0x50]
000071ff71be329c  vmovaps xmm6, [rsp+0x60]
000071ff71be32a2  vmovaps xmm7, [rsp+0x70]
000071ff71be32a8  vmovaps xmm9, [rsp+0x80]
000071ff71be32b1  vmovaps xmm10, [rsp+0x90]
000071ff71be32ba  vmovaps xmm11, [rsp+0xA0]
000071ff71be32c3  vmovaps xmm12, [rsp+0xB0]
000071ff71be32cc  vmovaps xmm13, [rsp+0xC0]
000071ff71be32d5  vmovaps xmm14, [rsp+0xD0]
000071ff71be32de  vmovaps xmm15, [rsp+0xE0]
000071ff71be32e7  add rsp, 0xF0
000071ff71be32ee  pop r11
000071ff71be32f0  pop r10
000071ff71be32f2  pop r9
000071ff71be32f4  pop r8
000071ff71be32f6  pop rsi
000071ff71be32f7  pop rdi
000071ff71be32f8  pop rdx
000071ff71be32f9  pop rcx
000071ff71be32fa  pop rax
000071ff71be32fb  add rsp, 0x08
000071ff71be32ff  jmp 0x000071FF71BDF741
000071ff71be3304  sub rsp, 0x08
000071ff71be3308  push rax
000071ff71be3309  push rcx
000071ff71be330a  push rdx
000071ff71be330b  push rdi
000071ff71be330c  push rsi
000071ff71be330d  push r8
000071ff71be330f  push r9
000071ff71be3311  push r10
000071ff71be3313  push r11
000071ff71be3315  sub rsp, 0xF0
000071ff71be331c  vmovaps [rsp], xmm0
000071ff71be3321  vmovaps [rsp+0x10], xmm1
000071ff71be3327  vmovaps [rsp+0x20], xmm2
000071ff71be332d  vmovaps [rsp+0x30], xmm3
000071ff71be3333  vmovaps [rsp+0x40], xmm4
000071ff71be3339  vmovaps [rsp+0x50], xmm5
000071ff71be333f  vmovaps [rsp+0x60], xmm7
000071ff71be3345  vmovaps [rsp+0x70], xmm8
000071ff71be334b  vmovaps [rsp+0x80], xmm9
000071ff71be3354  vmovaps [rsp+0x90], xmm10
000071ff71be335d  vmovaps [rsp+0xA0], xmm11
000071ff71be3366  vmovaps [rsp+0xB0], xmm12
000071ff71be336f  vmovaps [rsp+0xC0], xmm13
000071ff71be3378  vmovaps [rsp+0xD0], xmm14
000071ff71be3381  vmovaps [rsp+0xE0], xmm15
000071ff71be338a  sub rsp, 0x30
000071ff71be338e  movaps [rsp], xmm6
000071ff71be3392  movaps [rsp+0x10], xmm1
000071ff71be3397  movaps [rsp+0x20], xmm14
000071ff71be339d  lea rdi, [rsp]
000071ff71be33a1  mov esi, 0x00
000071ff71be33a6  mov rax, 0x5E6872E10530
000071ff71be33b0  call rax
000071ff71be33b2  movaps xmm6, [rsp]
000071ff71be33b6  add rsp, 0x30
000071ff71be33ba  vmovaps xmm0, [rsp]
000071ff71be33bf  vmovaps xmm1, [rsp+0x10]
000071ff71be33c5  vmovaps xmm2, [rsp+0x20]
000071ff71be33cb  vmovaps xmm3, [rsp+0x30]
000071ff71be33d1  vmovaps xmm4, [rsp+0x40]
000071ff71be33d7  vmovaps xmm5, [rsp+0x50]
000071ff71be33dd  vmovaps xmm7, [rsp+0x60]
000071ff71be33e3  vmovaps xmm8, [rsp+0x70]
000071ff71be33e9  vmovaps xmm9, [rsp+0x80]
000071ff71be33f2  vmovaps xmm10, [rsp+0x90]
000071ff71be33fb  vmovaps xmm11, [rsp+0xA0]
000071ff71be3404  vmovaps xmm12, [rsp+0xB0]
000071ff71be340d  vmovaps xmm13, [rsp+0xC0]
000071ff71be3416  vmovaps xmm14, [rsp+0xD0]
000071ff71be341f  vmovaps xmm15, [rsp+0xE0]
000071ff71be3428  add rsp, 0xF0
000071ff71be342f  pop r11
000071ff71be3431  pop r10
000071ff71be3433  pop r9
000071ff71be3435  pop r8
000071ff71be3437  pop rsi
000071ff71be3438  pop rdi
000071ff71be3439  pop rdx
000071ff71be343a  pop rcx
000071ff71be343b  pop rax
000071ff71be343c  add rsp, 0x08
000071ff71be3440  jmp 0x000071FF71BDF76D
000071ff71be3445  sub rsp, 0x08
000071ff71be3449  push rax
000071ff71be344a  push rcx
000071ff71be344b  push rdx
000071ff71be344c  push rdi
000071ff71be344d  push rsi
000071ff71be344e  push r8
000071ff71be3450  push r9
000071ff71be3452  push r10
000071ff71be3454  push r11
000071ff71be3456  sub rsp, 0xF0
000071ff71be345d  vmovaps [rsp], xmm0
000071ff71be3462  vmovaps [rsp+0x10], xmm1
000071ff71be3468  vmovaps [rsp+0x20], xmm2
000071ff71be346e  vmovaps [rsp+0x30], xmm3
000071ff71be3474  vmovaps [rsp+0x40], xmm4
000071ff71be347a  vmovaps [rsp+0x50], xmm5
000071ff71be3480  vmovaps [rsp+0x60], xmm6
000071ff71be3486  vmovaps [rsp+0x70], xmm7
000071ff71be348c  vmovaps [rsp+0x80], xmm8
000071ff71be3495  vmovaps [rsp+0x90], xmm9
000071ff71be349e  vmovaps [rsp+0xA0], xmm10
000071ff71be34a7  vmovaps [rsp+0xB0], xmm11
000071ff71be34b0  vmovaps [rsp+0xC0], xmm12
000071ff71be34b9  vmovaps [rsp+0xD0], xmm13
000071ff71be34c2  vmovaps [rsp+0xE0], xmm15
000071ff71be34cb  sub rsp, 0x30
000071ff71be34cf  movaps [rsp], xmm14
000071ff71be34d4  movaps [rsp+0x10], xmm12
000071ff71be34da  movaps [rsp+0x20], xmm1
000071ff71be34df  lea rdi, [rsp]
000071ff71be34e3  mov esi, 0x00
000071ff71be34e8  mov rax, 0x5E6872E10530
000071ff71be34f2  call rax
000071ff71be34f4  movaps xmm14, [rsp]
000071ff71be34f9  add rsp, 0x30
000071ff71be34fd  vmovaps xmm0, [rsp]
000071ff71be3502  vmovaps xmm1, [rsp+0x10]
000071ff71be3508  vmovaps xmm2, [rsp+0x20]
000071ff71be350e  vmovaps xmm3, [rsp+0x30]
000071ff71be3514  vmovaps xmm4, [rsp+0x40]
000071ff71be351a  vmovaps xmm5, [rsp+0x50]
000071ff71be3520  vmovaps xmm6, [rsp+0x60]
000071ff71be3526  vmovaps xmm7, [rsp+0x70]
000071ff71be352c  vmovaps xmm8, [rsp+0x80]
000071ff71be3535  vmovaps xmm9, [rsp+0x90]
000071ff71be353e  vmovaps xmm10, [rsp+0xA0]
000071ff71be3547  vmovaps xmm11, [rsp+0xB0]
000071ff71be3550  vmovaps xmm12, [rsp+0xC0]
000071ff71be3559  vmovaps xmm13, [rsp+0xD0]
000071ff71be3562  vmovaps xmm15, [rsp+0xE0]
000071ff71be356b  add rsp, 0xF0
000071ff71be3572  pop r11
000071ff71be3574  pop r10
000071ff71be3576  pop r9
000071ff71be3578  pop r8
000071ff71be357a  pop rsi
000071ff71be357b  pop rdi
000071ff71be357c  pop rdx
000071ff71be357d  pop rcx
000071ff71be357e  pop rax
000071ff71be357f  add rsp, 0x08
000071ff71be3583  jmp 0x000071FF71BDF793
000071ff71be3588  sub rsp, 0x08
000071ff71be358c  push rax
000071ff71be358d  push rcx
000071ff71be358e  push rdx
000071ff71be358f  push rdi
000071ff71be3590  push rsi
000071ff71be3591  push r8
000071ff71be3593  push r9
000071ff71be3595  push r10
000071ff71be3597  push r11
000071ff71be3599  sub rsp, 0xF0
000071ff71be35a0  vmovaps [rsp], xmm0
000071ff71be35a5  vmovaps [rsp+0x10], xmm2
000071ff71be35ab  vmovaps [rsp+0x20], xmm3
000071ff71be35b1  vmovaps [rsp+0x30], xmm4
000071ff71be35b7  vmovaps [rsp+0x40], xmm5
000071ff71be35bd  vmovaps [rsp+0x50], xmm6
000071ff71be35c3  vmovaps [rsp+0x60], xmm7
000071ff71be35c9  vmovaps [rsp+0x70], xmm8
000071ff71be35cf  vmovaps [rsp+0x80], xmm9
000071ff71be35d8  vmovaps [rsp+0x90], xmm10
000071ff71be35e1  vmovaps [rsp+0xA0], xmm11
000071ff71be35ea  vmovaps [rsp+0xB0], xmm12
000071ff71be35f3  vmovaps [rsp+0xC0], xmm13
000071ff71be35fc  vmovaps [rsp+0xD0], xmm14
000071ff71be3605  vmovaps [rsp+0xE0], xmm15
000071ff71be360e  sub rsp, 0x30
000071ff71be3612  movaps [rsp], xmm1
000071ff71be3616  movaps [rsp+0x10], xmm13
000071ff71be361c  movaps [rsp+0x20], xmm9
000071ff71be3622  lea rdi, [rsp]
000071ff71be3626  mov esi, 0x00
000071ff71be362b  mov rax, 0x5E6872E10530
000071ff71be3635  call rax
000071ff71be3637  movaps xmm1, [rsp]
000071ff71be363b  add rsp, 0x30
000071ff71be363f  vmovaps xmm0, [rsp]
000071ff71be3644  vmovaps xmm2, [rsp+0x10]
000071ff71be364a  vmovaps xmm3, [rsp+0x20]
000071ff71be3650  vmovaps xmm4, [rsp+0x30]
000071ff71be3656  vmovaps xmm5, [rsp+0x40]
000071ff71be365c  vmovaps xmm6, [rsp+0x50]
000071ff71be3662  vmovaps xmm7, [rsp+0x60]
000071ff71be3668  vmovaps xmm8, [rsp+0x70]
000071ff71be366e  vmovaps xmm9, [rsp+0x80]
000071ff71be3677  vmovaps xmm10, [rsp+0x90]
000071ff71be3680  vmovaps xmm11, [rsp+0xA0]
000071ff71be3689  vmovaps xmm12, [rsp+0xB0]
000071ff71be3692  vmovaps xmm13, [rsp+0xC0]
000071ff71be369b  vmovaps xmm14, [rsp+0xD0]
000071ff71be36a4  vmovaps xmm15, [rsp+0xE0]
000071ff71be36ad  add rsp, 0xF0
000071ff71be36b4  pop r11
000071ff71be36b6  pop r10
000071ff71be36b8  pop r9
000071ff71be36ba  pop r8
000071ff71be36bc  pop rsi
000071ff71be36bd  pop rdi
000071ff71be36be  pop rdx
000071ff71be36bf  pop rcx
000071ff71be36c0  pop rax
000071ff71be36c1  add rsp, 0x08
000071ff71be36c5  jmp 0x000071FF71BDF7AD
000071ff71be36ca  sub rsp, 0x08
000071ff71be36ce  push rax
000071ff71be36cf  push rcx
000071ff71be36d0  push rdx
000071ff71be36d1  push rdi
000071ff71be36d2  push rsi
000071ff71be36d3  push r8
000071ff71be36d5  push r9
000071ff71be36d7  push r10
000071ff71be36d9  push r11
000071ff71be36db  sub rsp, 0xF0
000071ff71be36e2  vmovaps [rsp], xmm0
000071ff71be36e7  vmovaps [rsp+0x10], xmm1
000071ff71be36ed  vmovaps [rsp+0x20], xmm2
000071ff71be36f3  vmovaps [rsp+0x30], xmm3
000071ff71be36f9  vmovaps [rsp+0x40], xmm4
000071ff71be36ff  vmovaps [rsp+0x50], xmm5
000071ff71be3705  vmovaps [rsp+0x60], xmm6
000071ff71be370b  vmovaps [rsp+0x70], xmm7
000071ff71be3711  vmovaps [rsp+0x80], xmm8
000071ff71be371a  vmovaps [rsp+0x90], xmm9
000071ff71be3723  vmovaps [rsp+0xA0], xmm10
000071ff71be372c  vmovaps [rsp+0xB0], xmm11
000071ff71be3735  vmovaps [rsp+0xC0], xmm13
000071ff71be373e  vmovaps [rsp+0xD0], xmm14
000071ff71be3747  vmovaps [rsp+0xE0], xmm15
000071ff71be3750  sub rsp, 0x30
000071ff71be3754  movaps [rsp], xmm12
000071ff71be3759  movaps [rsp+0x10], xmm7
000071ff71be375e  movaps [rsp+0x20], xmm13
000071ff71be3764  lea rdi, [rsp]
000071ff71be3768  mov esi, 0x00
000071ff71be376d  mov rax, 0x5E6872E10530
000071ff71be3777  call rax
000071ff71be3779  movaps xmm12, [rsp]
000071ff71be377e  add rsp, 0x30
000071ff71be3782  vmovaps xmm0, [rsp]
000071ff71be3787  vmovaps xmm1, [rsp+0x10]
000071ff71be378d  vmovaps xmm2, [rsp+0x20]
000071ff71be3793  vmovaps xmm3, [rsp+0x30]
000071ff71be3799  vmovaps xmm4, [rsp+0x40]
000071ff71be379f  vmovaps xmm5, [rsp+0x50]
000071ff71be37a5  vmovaps xmm6, [rsp+0x60]
000071ff71be37ab  vmovaps xmm7, [rsp+0x70]
000071ff71be37b1  vmovaps xmm8, [rsp+0x80]
000071ff71be37ba  vmovaps xmm9, [rsp+0x90]
000071ff71be37c3  vmovaps xmm10, [rsp+0xA0]
000071ff71be37cc  vmovaps xmm11, [rsp+0xB0]
000071ff71be37d5  vmovaps xmm13, [rsp+0xC0]
000071ff71be37de  vmovaps xmm14, [rsp+0xD0]
000071ff71be37e7  vmovaps xmm15, [rsp+0xE0]
000071ff71be37f0  add rsp, 0xF0
000071ff71be37f7  pop r11
000071ff71be37f9  pop r10
000071ff71be37fb  pop r9
000071ff71be37fd  pop r8
000071ff71be37ff  pop rsi
000071ff71be3800  pop rdi
000071ff71be3801  pop rdx
000071ff71be3802  pop rcx
000071ff71be3803  pop rax
000071ff71be3804  add rsp, 0x08
000071ff71be3808  jmp 0x000071FF71BDF7D4
000071ff71be380d  sub rsp, 0x08
000071ff71be3811  push rax
000071ff71be3812  push rcx
000071ff71be3813  push rdx
000071ff71be3814  push rdi
000071ff71be3815  push rsi
000071ff71be3816  push r8
000071ff71be3818  push r9
000071ff71be381a  push r10
000071ff71be381c  push r11
000071ff71be381e  sub rsp, 0xF0
000071ff71be3825  vmovaps [rsp], xmm0
000071ff71be382a  vmovaps [rsp+0x10], xmm1
000071ff71be3830  vmovaps [rsp+0x20], xmm2
000071ff71be3836  vmovaps [rsp+0x30], xmm3
000071ff71be383c  vmovaps [rsp+0x40], xmm4
000071ff71be3842  vmovaps [rsp+0x50], xmm5
000071ff71be3848  vmovaps [rsp+0x60], xmm6
000071ff71be384e  vmovaps [rsp+0x70], xmm7
000071ff71be3854  vmovaps [rsp+0x80], xmm8
000071ff71be385d  vmovaps [rsp+0x90], xmm9
000071ff71be3866  vmovaps [rsp+0xA0], xmm10
000071ff71be386f  vmovaps [rsp+0xB0], xmm11
000071ff71be3878  vmovaps [rsp+0xC0], xmm12
000071ff71be3881  vmovaps [rsp+0xD0], xmm14
000071ff71be388a  vmovaps [rsp+0xE0], xmm15
000071ff71be3893  sub rsp, 0x30
000071ff71be3897  movaps [rsp], xmm13
000071ff71be389c  movaps [rsp+0x10], xmm15
000071ff71be38a2  movaps [rsp+0x20], xmm8
000071ff71be38a8  lea rdi, [rsp]
000071ff71be38ac  mov esi, 0x00
000071ff71be38b1  mov rax, 0x5E6872E10530
000071ff71be38bb  call rax
000071ff71be38bd  movaps xmm13, [rsp]
000071ff71be38c2  add rsp, 0x30
000071ff71be38c6  vmovaps xmm0, [rsp]
000071ff71be38cb  vmovaps xmm1, [rsp+0x10]
000071ff71be38d1  vmovaps xmm2, [rsp+0x20]
000071ff71be38d7  vmovaps xmm3, [rsp+0x30]
000071ff71be38dd  vmovaps xmm4, [rsp+0x40]
000071ff71be38e3  vmovaps xmm5, [rsp+0x50]
000071ff71be38e9  vmovaps xmm6, [rsp+0x60]
000071ff71be38ef  vmovaps xmm7, [rsp+0x70]
000071ff71be38f5  vmovaps xmm8, [rsp+0x80]
000071ff71be38fe  vmovaps xmm9, [rsp+0x90]
000071ff71be3907  vmovaps xmm10, [rsp+0xA0]
000071ff71be3910  vmovaps xmm11, [rsp+0xB0]
000071ff71be3919  vmovaps xmm12, [rsp+0xC0]
000071ff71be3922  vmovaps xmm14, [rsp+0xD0]
000071ff71be392b  vmovaps xmm15, [rsp+0xE0]
000071ff71be3934  add rsp, 0xF0
000071ff71be393b  pop r11
000071ff71be393d  pop r10
000071ff71be393f  pop r9
000071ff71be3941  pop r8
000071ff71be3943  pop rsi
000071ff71be3944  pop rdi
000071ff71be3945  pop rdx
000071ff71be3946  pop rcx
000071ff71be3947  pop rax
000071ff71be3948  add rsp, 0x08
000071ff71be394c  jmp 0x000071FF71BDF7EF
000071ff71be3951  sub rsp, 0x08
000071ff71be3955  push rax
000071ff71be3956  push rcx
000071ff71be3957  push rdx
000071ff71be3958  push rdi
000071ff71be3959  push rsi
000071ff71be395a  push r8
000071ff71be395c  push r9
000071ff71be395e  push r10
000071ff71be3960  push r11
000071ff71be3962  sub rsp, 0xF0
000071ff71be3969  vmovaps [rsp], xmm0
000071ff71be396e  vmovaps [rsp+0x10], xmm1
000071ff71be3974  vmovaps [rsp+0x20], xmm2
000071ff71be397a  vmovaps [rsp+0x30], xmm3
000071ff71be3980  vmovaps [rsp+0x40], xmm4
000071ff71be3986  vmovaps [rsp+0x50], xmm5
000071ff71be398c  vmovaps [rsp+0x60], xmm6
000071ff71be3992  vmovaps [rsp+0x70], xmm7
000071ff71be3998  vmovaps [rsp+0x80], xmm9
000071ff71be39a1  vmovaps [rsp+0x90], xmm10
000071ff71be39aa  vmovaps [rsp+0xA0], xmm11
000071ff71be39b3  vmovaps [rsp+0xB0], xmm12
000071ff71be39bc  vmovaps [rsp+0xC0], xmm13
000071ff71be39c5  vmovaps [rsp+0xD0], xmm14
000071ff71be39ce  vmovaps [rsp+0xE0], xmm15
000071ff71be39d7  sub rsp, 0x30
000071ff71be39db  movaps [rsp], xmm8
000071ff71be39e0  movaps [rsp+0x10], xmm15
000071ff71be39e6  movaps [rsp+0x20], xmm9
000071ff71be39ec  lea rdi, [rsp]
000071ff71be39f0  mov esi, 0x00
000071ff71be39f5  mov rax, 0x5E6872E10530
000071ff71be39ff  call rax
000071ff71be3a01  movaps xmm8, [rsp]
000071ff71be3a06  add rsp, 0x30
000071ff71be3a0a  vmovaps xmm0, [rsp]
000071ff71be3a0f  vmovaps xmm1, [rsp+0x10]
000071ff71be3a15  vmovaps xmm2, [rsp+0x20]
000071ff71be3a1b  vmovaps xmm3, [rsp+0x30]
000071ff71be3a21  vmovaps xmm4, [rsp+0x40]
000071ff71be3a27  vmovaps xmm5, [rsp+0x50]
000071ff71be3a2d  vmovaps xmm6, [rsp+0x60]
000071ff71be3a33  vmovaps xmm7, [rsp+0x70]
000071ff71be3a39  vmovaps xmm9, [rsp+0x80]
000071ff71be3a42  vmovaps xmm10, [rsp+0x90]
000071ff71be3a4b  vmovaps xmm11, [rsp+0xA0]
000071ff71be3a54  vmovaps xmm12, [rsp+0xB0]
000071ff71be3a5d  vmovaps xmm13, [rsp+0xC0]
000071ff71be3a66  vmovaps xmm14, [rsp+0xD0]
000071ff71be3a6f  vmovaps xmm15, [rsp+0xE0]
000071ff71be3a78  add rsp, 0xF0
000071ff71be3a7f  pop r11
000071ff71be3a81  pop r10
000071ff71be3a83  pop r9
000071ff71be3a85  pop r8
000071ff71be3a87  pop rsi
000071ff71be3a88  pop rdi
000071ff71be3a89  pop rdx
000071ff71be3a8a  pop rcx
000071ff71be3a8b  pop rax
000071ff71be3a8c  add rsp, 0x08
000071ff71be3a90  jmp 0x000071FF71BDF81D
000071ff71be3a95  sub rsp, 0x08
000071ff71be3a99  push rax
000071ff71be3a9a  push rcx
000071ff71be3a9b  push rdx
000071ff71be3a9c  push rdi
000071ff71be3a9d  push rsi
000071ff71be3a9e  push r8
000071ff71be3aa0  push r9
000071ff71be3aa2  push r10
000071ff71be3aa4  push r11
000071ff71be3aa6  sub rsp, 0xF0
000071ff71be3aad  vmovaps [rsp], xmm0
000071ff71be3ab2  vmovaps [rsp+0x10], xmm1
000071ff71be3ab8  vmovaps [rsp+0x20], xmm2
000071ff71be3abe  vmovaps [rsp+0x30], xmm3
000071ff71be3ac4  vmovaps [rsp+0x40], xmm4
000071ff71be3aca  vmovaps [rsp+0x50], xmm5
000071ff71be3ad0  vmovaps [rsp+0x60], xmm6
000071ff71be3ad6  vmovaps [rsp+0x70], xmm7
000071ff71be3adc  vmovaps [rsp+0x80], xmm8
000071ff71be3ae5  vmovaps [rsp+0x90], xmm9
000071ff71be3aee  vmovaps [rsp+0xA0], xmm10
000071ff71be3af7  vmovaps [rsp+0xB0], xmm11
000071ff71be3b00  vmovaps [rsp+0xC0], xmm12
000071ff71be3b09  vmovaps [rsp+0xD0], xmm13
000071ff71be3b12  vmovaps [rsp+0xE0], xmm14
000071ff71be3b1b  sub rsp, 0x30
000071ff71be3b1f  movaps [rsp], xmm15
000071ff71be3b24  movaps [rsp+0x10], xmm11
000071ff71be3b2a  movaps [rsp+0x20], xmm6
000071ff71be3b2f  lea rdi, [rsp]
000071ff71be3b33  mov esi, 0x00
000071ff71be3b38  mov rax, 0x5E6872E10530
000071ff71be3b42  call rax
000071ff71be3b44  movaps xmm15, [rsp]
000071ff71be3b49  add rsp, 0x30
000071ff71be3b4d  vmovaps xmm0, [rsp]
000071ff71be3b52  vmovaps xmm1, [rsp+0x10]
000071ff71be3b58  vmovaps xmm2, [rsp+0x20]
000071ff71be3b5e  vmovaps xmm3, [rsp+0x30]
000071ff71be3b64  vmovaps xmm4, [rsp+0x40]
000071ff71be3b6a  vmovaps xmm5, [rsp+0x50]
000071ff71be3b70  vmovaps xmm6, [rsp+0x60]
000071ff71be3b76  vmovaps xmm7, [rsp+0x70]
000071ff71be3b7c  vmovaps xmm8, [rsp+0x80]
000071ff71be3b85  vmovaps xmm9, [rsp+0x90]
000071ff71be3b8e  vmovaps xmm10, [rsp+0xA0]
000071ff71be3b97  vmovaps xmm11, [rsp+0xB0]
000071ff71be3ba0  vmovaps xmm12, [rsp+0xC0]
000071ff71be3ba9  vmovaps xmm13, [rsp+0xD0]
000071ff71be3bb2  vmovaps xmm14, [rsp+0xE0]
000071ff71be3bbb  add rsp, 0xF0
000071ff71be3bc2  pop r11
000071ff71be3bc4  pop r10
000071ff71be3bc6  pop r9
000071ff71be3bc8  pop r8
000071ff71be3bca  pop rsi
000071ff71be3bcb  pop rdi
000071ff71be3bcc  pop rdx
000071ff71be3bcd  pop rcx
000071ff71be3bce  pop rax
000071ff71be3bcf  add rsp, 0x08
000071ff71be3bd3  jmp 0x000071FF71BDF838
000071ff71be3bd8  sub rsp, 0x08
000071ff71be3bdc  push rax
000071ff71be3bdd  push rcx
000071ff71be3bde  push rdx
000071ff71be3bdf  push rdi
000071ff71be3be0  push rsi
000071ff71be3be1  push r8
000071ff71be3be3  push r9
000071ff71be3be5  push r10
000071ff71be3be7  push r11
000071ff71be3be9  sub rsp, 0xF0
000071ff71be3bf0  vmovaps [rsp], xmm0
000071ff71be3bf5  vmovaps [rsp+0x10], xmm1
000071ff71be3bfb  vmovaps [rsp+0x20], xmm2
000071ff71be3c01  vmovaps [rsp+0x30], xmm3
000071ff71be3c07  vmovaps [rsp+0x40], xmm4
000071ff71be3c0d  vmovaps [rsp+0x50], xmm5
000071ff71be3c13  vmovaps [rsp+0x60], xmm6
000071ff71be3c19  vmovaps [rsp+0x70], xmm8
000071ff71be3c1f  vmovaps [rsp+0x80], xmm9
000071ff71be3c28  vmovaps [rsp+0x90], xmm10
000071ff71be3c31  vmovaps [rsp+0xA0], xmm11
000071ff71be3c3a  vmovaps [rsp+0xB0], xmm12
000071ff71be3c43  vmovaps [rsp+0xC0], xmm13
000071ff71be3c4c  vmovaps [rsp+0xD0], xmm14
000071ff71be3c55  vmovaps [rsp+0xE0], xmm15
000071ff71be3c5e  sub rsp, 0x30
000071ff71be3c62  movaps [rsp], xmm7
000071ff71be3c66  movaps [rsp+0x10], xmm11
000071ff71be3c6c  movaps [rsp+0x20], xmm9
000071ff71be3c72  lea rdi, [rsp]
000071ff71be3c76  mov esi, 0x00
000071ff71be3c7b  mov rax, 0x5E6872E10530
000071ff71be3c85  call rax
000071ff71be3c87  movaps xmm7, [rsp]
000071ff71be3c8b  add rsp, 0x30
000071ff71be3c8f  vmovaps xmm0, [rsp]
000071ff71be3c94  vmovaps xmm1, [rsp+0x10]
000071ff71be3c9a  vmovaps xmm2, [rsp+0x20]
000071ff71be3ca0  vmovaps xmm3, [rsp+0x30]
000071ff71be3ca6  vmovaps xmm4, [rsp+0x40]
000071ff71be3cac  vmovaps xmm5, [rsp+0x50]
000071ff71be3cb2  vmovaps xmm6, [rsp+0x60]
000071ff71be3cb8  vmovaps xmm8, [rsp+0x70]
000071ff71be3cbe  vmovaps xmm9, [rsp+0x80]
000071ff71be3cc7  vmovaps xmm10, [rsp+0x90]
000071ff71be3cd0  vmovaps xmm11, [rsp+0xA0]
000071ff71be3cd9  vmovaps xmm12, [rsp+0xB0]
000071ff71be3ce2  vmovaps xmm13, [rsp+0xC0]
000071ff71be3ceb  vmovaps xmm14, [rsp+0xD0]
000071ff71be3cf4  vmovaps xmm15, [rsp+0xE0]
000071ff71be3cfd  add rsp, 0xF0
000071ff71be3d04  pop r11
000071ff71be3d06  pop r10
000071ff71be3d08  pop r9
000071ff71be3d0a  pop r8
000071ff71be3d0c  pop rsi
000071ff71be3d0d  pop rdi
000071ff71be3d0e  pop rdx
000071ff71be3d0f  pop rcx
000071ff71be3d10  pop rax
000071ff71be3d11  add rsp, 0x08
000071ff71be3d15  jmp 0x000071FF71BDF865
000071ff71be3d1a  sub rsp, 0x08
000071ff71be3d1e  push rax
000071ff71be3d1f  push rcx
000071ff71be3d20  push rdx
000071ff71be3d21  push rdi
000071ff71be3d22  push rsi
000071ff71be3d23  push r8
000071ff71be3d25  push r9
000071ff71be3d27  push r10
000071ff71be3d29  push r11
000071ff71be3d2b  sub rsp, 0xF0
000071ff71be3d32  vmovaps [rsp], xmm0
000071ff71be3d37  vmovaps [rsp+0x10], xmm1
000071ff71be3d3d  vmovaps [rsp+0x20], xmm2
000071ff71be3d43  vmovaps [rsp+0x30], xmm3
000071ff71be3d49  vmovaps [rsp+0x40], xmm4
000071ff71be3d4f  vmovaps [rsp+0x50], xmm5
000071ff71be3d55  vmovaps [rsp+0x60], xmm6
000071ff71be3d5b  vmovaps [rsp+0x70], xmm7
000071ff71be3d61  vmovaps [rsp+0x80], xmm8
000071ff71be3d6a  vmovaps [rsp+0x90], xmm9
000071ff71be3d73  vmovaps [rsp+0xA0], xmm10
000071ff71be3d7c  vmovaps [rsp+0xB0], xmm12
000071ff71be3d85  vmovaps [rsp+0xC0], xmm13
000071ff71be3d8e  vmovaps [rsp+0xD0], xmm14
000071ff71be3d97  vmovaps [rsp+0xE0], xmm15
000071ff71be3da0  sub rsp, 0x30
000071ff71be3da4  movaps [rsp], xmm11
000071ff71be3da9  movaps [rsp+0x10], xmm10
000071ff71be3daf  movaps [rsp+0x20], xmm14
000071ff71be3db5  lea rdi, [rsp]
000071ff71be3db9  mov esi, 0x00
000071ff71be3dbe  mov rax, 0x5E6872E10530
000071ff71be3dc8  call rax
000071ff71be3dca  movaps xmm11, [rsp]
000071ff71be3dcf  add rsp, 0x30
000071ff71be3dd3  vmovaps xmm0, [rsp]
000071ff71be3dd8  vmovaps xmm1, [rsp+0x10]
000071ff71be3dde  vmovaps xmm2, [rsp+0x20]
000071ff71be3de4  vmovaps xmm3, [rsp+0x30]
000071ff71be3dea  vmovaps xmm4, [rsp+0x40]
000071ff71be3df0  vmovaps xmm5, [rsp+0x50]
000071ff71be3df6  vmovaps xmm6, [rsp+0x60]
000071ff71be3dfc  vmovaps xmm7, [rsp+0x70]
000071ff71be3e02  vmovaps xmm8, [rsp+0x80]
000071ff71be3e0b  vmovaps xmm9, [rsp+0x90]
000071ff71be3e14  vmovaps xmm10, [rsp+0xA0]
000071ff71be3e1d  vmovaps xmm12, [rsp+0xB0]
000071ff71be3e26  vmovaps xmm13, [rsp+0xC0]
000071ff71be3e2f  vmovaps xmm14, [rsp+0xD0]
000071ff71be3e38  vmovaps xmm15, [rsp+0xE0]
000071ff71be3e41  add rsp, 0xF0
000071ff71be3e48  pop r11
000071ff71be3e4a  pop r10
000071ff71be3e4c  pop r9
000071ff71be3e4e  pop r8
000071ff71be3e50  pop rsi
000071ff71be3e51  pop rdi
000071ff71be3e52  pop rdx
000071ff71be3e53  pop rcx
000071ff71be3e54  pop rax
000071ff71be3e55  add rsp, 0x08
000071ff71be3e59  jmp 0x000071FF71BDF880
000071ff71be3e5e  call 0x000071FF71AC33A0
000071ff71be3e63  jmp 0x000071FF71BDF88A
000071ff71be3e68  sub rsp, 0x08
000071ff71be3e6c  push rax
000071ff71be3e6d  push rcx
000071ff71be3e6e  push rdx
000071ff71be3e6f  push rdi
000071ff71be3e70  push rsi
000071ff71be3e71  push r8
000071ff71be3e73  push r9
000071ff71be3e75  push r10
000071ff71be3e77  push r11
000071ff71be3e79  sub rsp, 0xF0
000071ff71be3e80  vmovaps [rsp], xmm0
000071ff71be3e85  vmovaps [rsp+0x10], xmm1
000071ff71be3e8b  vmovaps [rsp+0x20], xmm2
000071ff71be3e91  vmovaps [rsp+0x30], xmm3
000071ff71be3e97  vmovaps [rsp+0x40], xmm4
000071ff71be3e9d  vmovaps [rsp+0x50], xmm5
000071ff71be3ea3  vmovaps [rsp+0x60], xmm6
000071ff71be3ea9  vmovaps [rsp+0x70], xmm7
000071ff71be3eaf  vmovaps [rsp+0x80], xmm8
000071ff71be3eb8  vmovaps [rsp+0x90], xmm9
000071ff71be3ec1  vmovaps [rsp+0xA0], xmm11
000071ff71be3eca  vmovaps [rsp+0xB0], xmm12
000071ff71be3ed3  vmovaps [rsp+0xC0], xmm13
000071ff71be3edc  vmovaps [rsp+0xD0], xmm14
000071ff71be3ee5  vmovaps [rsp+0xE0], xmm15
000071ff71be3eee  sub rsp, 0x30
000071ff71be3ef2  movaps [rsp], xmm10
000071ff71be3ef7  movaps [rsp+0x10], xmm1
000071ff71be3efc  movaps [rsp+0x20], xmm12
000071ff71be3f02  lea rdi, [rsp]
000071ff71be3f06  mov esi, 0x00
000071ff71be3f0b  mov rax, 0x5E6872E10530
000071ff71be3f15  call rax
000071ff71be3f17  movaps xmm10, [rsp]
000071ff71be3f1c  add rsp, 0x30
000071ff71be3f20  vmovaps xmm0, [rsp]
000071ff71be3f25  vmovaps xmm1, [rsp+0x10]
000071ff71be3f2b  vmovaps xmm2, [rsp+0x20]
000071ff71be3f31  vmovaps xmm3, [rsp+0x30]
000071ff71be3f37  vmovaps xmm4, [rsp+0x40]
000071ff71be3f3d  vmovaps xmm5, [rsp+0x50]
000071ff71be3f43  vmovaps xmm6, [rsp+0x60]
000071ff71be3f49  vmovaps xmm7, [rsp+0x70]
000071ff71be3f4f  vmovaps xmm8, [rsp+0x80]
000071ff71be3f58  vmovaps xmm9, [rsp+0x90]
000071ff71be3f61  vmovaps xmm11, [rsp+0xA0]
000071ff71be3f6a  vmovaps xmm12, [rsp+0xB0]
000071ff71be3f73  vmovaps xmm13, [rsp+0xC0]
000071ff71be3f7c  vmovaps xmm14, [rsp+0xD0]
000071ff71be3f85  vmovaps xmm15, [rsp+0xE0]
000071ff71be3f8e  add rsp, 0xF0
000071ff71be3f95  pop r11
000071ff71be3f97  pop r10
000071ff71be3f99  pop r9
000071ff71be3f9b  pop r8
000071ff71be3f9d  pop rsi
000071ff71be3f9e  pop rdi
000071ff71be3f9f  pop rdx
000071ff71be3fa0  pop rcx
000071ff71be3fa1  pop rax
000071ff71be3fa2  add rsp, 0x08
000071ff71be3fa6  jmp 0x000071FF71BDF8AD
000071ff71be3fab  sub rsp, 0x08
000071ff71be3faf  push rax
000071ff71be3fb0  push rcx
000071ff71be3fb1  push rdx
000071ff71be3fb2  push rdi
000071ff71be3fb3  push rsi
000071ff71be3fb4  push r8
000071ff71be3fb6  push r9
000071ff71be3fb8  push r10
000071ff71be3fba  push r11
000071ff71be3fbc  sub rsp, 0xF0
000071ff71be3fc3  vmovaps [rsp], xmm0
000071ff71be3fc8  vmovaps [rsp+0x10], xmm1
000071ff71be3fce  vmovaps [rsp+0x20], xmm2
000071ff71be3fd4  vmovaps [rsp+0x30], xmm3
000071ff71be3fda  vmovaps [rsp+0x40], xmm4
000071ff71be3fe0  vmovaps [rsp+0x50], xmm5
000071ff71be3fe6  vmovaps [rsp+0x60], xmm6
000071ff71be3fec  vmovaps [rsp+0x70], xmm7
000071ff71be3ff2  vmovaps [rsp+0x80], xmm8
000071ff71be3ffb  vmovaps [rsp+0x90], xmm9
000071ff71be4004  vmovaps [rsp+0xA0], xmm10
000071ff71be400d  vmovaps [rsp+0xB0], xmm11
000071ff71be4016  vmovaps [rsp+0xC0], xmm13
000071ff71be401f  vmovaps [rsp+0xD0], xmm14
000071ff71be4028  vmovaps [rsp+0xE0], xmm15
000071ff71be4031  sub rsp, 0x30
000071ff71be4035  movaps [rsp], xmm12
000071ff71be403a  movaps [rsp+0x10], xmm14
000071ff71be4040  movaps [rsp+0x20], xmm1
000071ff71be4045  lea rdi, [rsp]
000071ff71be4049  mov esi, 0x00
000071ff71be404e  mov rax, 0x5E6872E10530
000071ff71be4058  call rax
000071ff71be405a  movaps xmm12, [rsp]
000071ff71be405f  add rsp, 0x30
000071ff71be4063  vmovaps xmm0, [rsp]
000071ff71be4068  vmovaps xmm1, [rsp+0x10]
000071ff71be406e  vmovaps xmm2, [rsp+0x20]
000071ff71be4074  vmovaps xmm3, [rsp+0x30]
000071ff71be407a  vmovaps xmm4, [rsp+0x40]
000071ff71be4080  vmovaps xmm5, [rsp+0x50]
000071ff71be4086  vmovaps xmm6, [rsp+0x60]
000071ff71be408c  vmovaps xmm7, [rsp+0x70]
000071ff71be4092  vmovaps xmm8, [rsp+0x80]
000071ff71be409b  vmovaps xmm9, [rsp+0x90]
000071ff71be40a4  vmovaps xmm10, [rsp+0xA0]
000071ff71be40ad  vmovaps xmm11, [rsp+0xB0]
000071ff71be40b6  vmovaps xmm13, [rsp+0xC0]
000071ff71be40bf  vmovaps xmm14, [rsp+0xD0]
000071ff71be40c8  vmovaps xmm15, [rsp+0xE0]
000071ff71be40d1  add rsp, 0xF0
000071ff71be40d8  pop r11
000071ff71be40da  pop r10
000071ff71be40dc  pop r9
000071ff71be40de  pop r8
000071ff71be40e0  pop rsi
000071ff71be40e1  pop rdi
000071ff71be40e2  pop rdx
000071ff71be40e3  pop rcx
000071ff71be40e4  pop rax
000071ff71be40e5  add rsp, 0x08
000071ff71be40e9  jmp 0x000071FF71BDF8DC
000071ff71be40ee  sub rsp, 0x08
000071ff71be40f2  push rax
000071ff71be40f3  push rcx
000071ff71be40f4  push rdx
000071ff71be40f5  push rdi
000071ff71be40f6  push rsi
000071ff71be40f7  push r8
000071ff71be40f9  push r9
000071ff71be40fb  push r10
000071ff71be40fd  push r11
000071ff71be40ff  sub rsp, 0xF0
000071ff71be4106  vmovaps [rsp], xmm0
000071ff71be410b  vmovaps [rsp+0x10], xmm1
000071ff71be4111  vmovaps [rsp+0x20], xmm2
000071ff71be4117  vmovaps [rsp+0x30], xmm3
000071ff71be411d  vmovaps [rsp+0x40], xmm4
000071ff71be4123  vmovaps [rsp+0x50], xmm5
000071ff71be4129  vmovaps [rsp+0x60], xmm6
000071ff71be412f  vmovaps [rsp+0x70], xmm7
000071ff71be4135  vmovaps [rsp+0x80], xmm8
000071ff71be413e  vmovaps [rsp+0x90], xmm9
000071ff71be4147  vmovaps [rsp+0xA0], xmm10
000071ff71be4150  vmovaps [rsp+0xB0], xmm11
000071ff71be4159  vmovaps [rsp+0xC0], xmm12
000071ff71be4162  vmovaps [rsp+0xD0], xmm13
000071ff71be416b  vmovaps [rsp+0xE0], xmm15
000071ff71be4174  sub rsp, 0x30
000071ff71be4178  movaps [rsp], xmm14
000071ff71be417d  movaps [rsp+0x10], xmm9
000071ff71be4183  movaps [rsp+0x20], xmm1
000071ff71be4188  lea rdi, [rsp]
000071ff71be418c  mov esi, 0x00
000071ff71be4191  mov rax, 0x5E6872E10530
000071ff71be419b  call rax
000071ff71be419d  movaps xmm14, [rsp]
000071ff71be41a2  add rsp, 0x30
000071ff71be41a6  vmovaps xmm0, [rsp]
000071ff71be41ab  vmovaps xmm1, [rsp+0x10]
000071ff71be41b1  vmovaps xmm2, [rsp+0x20]
000071ff71be41b7  vmovaps xmm3, [rsp+0x30]
000071ff71be41bd  vmovaps xmm4, [rsp+0x40]
000071ff71be41c3  vmovaps xmm5, [rsp+0x50]
000071ff71be41c9  vmovaps xmm6, [rsp+0x60]
000071ff71be41cf  vmovaps xmm7, [rsp+0x70]
000071ff71be41d5  vmovaps xmm8, [rsp+0x80]
000071ff71be41de  vmovaps xmm9, [rsp+0x90]
000071ff71be41e7  vmovaps xmm10, [rsp+0xA0]
000071ff71be41f0  vmovaps xmm11, [rsp+0xB0]
000071ff71be41f9  vmovaps xmm12, [rsp+0xC0]
000071ff71be4202  vmovaps xmm13, [rsp+0xD0]
000071ff71be420b  vmovaps xmm15, [rsp+0xE0]
000071ff71be4214  add rsp, 0xF0
000071ff71be421b  pop r11
000071ff71be421d  pop r10
000071ff71be421f  pop r9
000071ff71be4221  pop r8
000071ff71be4223  pop rsi
000071ff71be4224  pop rdi
000071ff71be4225  pop rdx
000071ff71be4226  pop rcx
000071ff71be4227  pop rax
000071ff71be4228  add rsp, 0x08
000071ff71be422c  jmp 0x000071FF71BDF90B
000071ff71be4231  sub rsp, 0x08
000071ff71be4235  push rax
000071ff71be4236  push rcx
000071ff71be4237  push rdx
000071ff71be4238  push rdi
000071ff71be4239  push rsi
000071ff71be423a  push r8
000071ff71be423c  push r9
000071ff71be423e  push r10
000071ff71be4240  push r11
000071ff71be4242  sub rsp, 0xF0
000071ff71be4249  vmovaps [rsp], xmm0
000071ff71be424e  vmovaps [rsp+0x10], xmm2
000071ff71be4254  vmovaps [rsp+0x20], xmm3
000071ff71be425a  vmovaps [rsp+0x30], xmm4
000071ff71be4260  vmovaps [rsp+0x40], xmm5
000071ff71be4266  vmovaps [rsp+0x50], xmm6
000071ff71be426c  vmovaps [rsp+0x60], xmm7
000071ff71be4272  vmovaps [rsp+0x70], xmm8
000071ff71be4278  vmovaps [rsp+0x80], xmm9
000071ff71be4281  vmovaps [rsp+0x90], xmm10
000071ff71be428a  vmovaps [rsp+0xA0], xmm11
000071ff71be4293  vmovaps [rsp+0xB0], xmm12
000071ff71be429c  vmovaps [rsp+0xC0], xmm13
000071ff71be42a5  vmovaps [rsp+0xD0], xmm14
000071ff71be42ae  vmovaps [rsp+0xE0], xmm15
000071ff71be42b7  sub rsp, 0x30
000071ff71be42bb  movaps [rsp], xmm1
000071ff71be42bf  movaps [rsp+0x10], xmm13
000071ff71be42c5  movaps [rsp+0x20], xmm8
000071ff71be42cb  lea rdi, [rsp]
000071ff71be42cf  mov esi, 0x00
000071ff71be42d4  mov rax, 0x5E6872E10530
000071ff71be42de  call rax
000071ff71be42e0  movaps xmm1, [rsp]
000071ff71be42e4  add rsp, 0x30
000071ff71be42e8  vmovaps xmm0, [rsp]
000071ff71be42ed  vmovaps xmm2, [rsp+0x10]
000071ff71be42f3  vmovaps xmm3, [rsp+0x20]
000071ff71be42f9  vmovaps xmm4, [rsp+0x30]
000071ff71be42ff  vmovaps xmm5, [rsp+0x40]
000071ff71be4305  vmovaps xmm6, [rsp+0x50]
000071ff71be430b  vmovaps xmm7, [rsp+0x60]
000071ff71be4311  vmovaps xmm8, [rsp+0x70]
000071ff71be4317  vmovaps xmm9, [rsp+0x80]
000071ff71be4320  vmovaps xmm10, [rsp+0x90]
000071ff71be4329  vmovaps xmm11, [rsp+0xA0]
000071ff71be4332  vmovaps xmm12, [rsp+0xB0]
000071ff71be433b  vmovaps xmm13, [rsp+0xC0]
000071ff71be4344  vmovaps xmm14, [rsp+0xD0]
000071ff71be434d  vmovaps xmm15, [rsp+0xE0]
000071ff71be4356  add rsp, 0xF0
000071ff71be435d  pop r11
000071ff71be435f  pop r10
000071ff71be4361  pop r9
000071ff71be4363  pop r8
000071ff71be4365  pop rsi
000071ff71be4366  pop rdi
000071ff71be4367  pop rdx
000071ff71be4368  pop rcx
000071ff71be4369  pop rax
000071ff71be436a  add rsp, 0x08
000071ff71be436e  jmp 0x000071FF71BDF92D
000071ff71be4373  call 0x000071FF71A0C260
000071ff71be4378  jmp 0x000071FF71BDF93B
000071ff71be437d  call 0x000071FF71ABD750
000071ff71be4382  jmp 0x000071FF71BDF945
000071ff71be4387  sub rsp, 0x08
000071ff71be438b  push rax
000071ff71be438c  push rcx
000071ff71be438d  push rdx
000071ff71be438e  push rdi
000071ff71be438f  push rsi
000071ff71be4390  push r8
000071ff71be4392  push r9
000071ff71be4394  push r10
000071ff71be4396  push r11
000071ff71be4398  sub rsp, 0xF0
000071ff71be439f  vmovaps [rsp], xmm0
000071ff71be43a4  vmovaps [rsp+0x10], xmm1
000071ff71be43aa  vmovaps [rsp+0x20], xmm2
000071ff71be43b0  vmovaps [rsp+0x30], xmm3
000071ff71be43b6  vmovaps [rsp+0x40], xmm4
000071ff71be43bc  vmovaps [rsp+0x50], xmm5
000071ff71be43c2  vmovaps [rsp+0x60], xmm6
000071ff71be43c8  vmovaps [rsp+0x70], xmm7
000071ff71be43ce  vmovaps [rsp+0x80], xmm9
000071ff71be43d7  vmovaps [rsp+0x90], xmm10
000071ff71be43e0  vmovaps [rsp+0xA0], xmm11
000071ff71be43e9  vmovaps [rsp+0xB0], xmm12
000071ff71be43f2  vmovaps [rsp+0xC0], xmm13
000071ff71be43fb  vmovaps [rsp+0xD0], xmm14
000071ff71be4404  vmovaps [rsp+0xE0], xmm15
000071ff71be440d  sub rsp, 0x30
000071ff71be4411  movaps [rsp], xmm8
000071ff71be4416  movaps [rsp+0x10], xmm15
000071ff71be441c  movaps [rsp+0x20], xmm7
000071ff71be4421  lea rdi, [rsp]
000071ff71be4425  mov esi, 0x00
000071ff71be442a  mov rax, 0x5E6872E10530
000071ff71be4434  call rax
000071ff71be4436  movaps xmm8, [rsp]
000071ff71be443b  add rsp, 0x30
000071ff71be443f  vmovaps xmm0, [rsp]
000071ff71be4444  vmovaps xmm1, [rsp+0x10]
000071ff71be444a  vmovaps xmm2, [rsp+0x20]
000071ff71be4450  vmovaps xmm3, [rsp+0x30]
000071ff71be4456  vmovaps xmm4, [rsp+0x40]
000071ff71be445c  vmovaps xmm5, [rsp+0x50]
000071ff71be4462  vmovaps xmm6, [rsp+0x60]
000071ff71be4468  vmovaps xmm7, [rsp+0x70]
000071ff71be446e  vmovaps xmm9, [rsp+0x80]
000071ff71be4477  vmovaps xmm10, [rsp+0x90]
000071ff71be4480  vmovaps xmm11, [rsp+0xA0]
000071ff71be4489  vmovaps xmm12, [rsp+0xB0]
000071ff71be4492  vmovaps xmm13, [rsp+0xC0]
000071ff71be449b  vmovaps xmm14, [rsp+0xD0]
000071ff71be44a4  vmovaps xmm15, [rsp+0xE0]
000071ff71be44ad  add rsp, 0xF0
000071ff71be44b4  pop r11
000071ff71be44b6  pop r10
000071ff71be44b8  pop r9
000071ff71be44ba  pop r8
000071ff71be44bc  pop rsi
000071ff71be44bd  pop rdi
000071ff71be44be  pop rdx
000071ff71be44bf  pop rcx
000071ff71be44c0  pop rax
000071ff71be44c1  add rsp, 0x08
000071ff71be44c5  jmp 0x000071FF71BDF967
000071ff71be44ca  sub rsp, 0x08
000071ff71be44ce  push rax
000071ff71be44cf  push rcx
000071ff71be44d0  push rdx
000071ff71be44d1  push rdi
000071ff71be44d2  push rsi
000071ff71be44d3  push r8
000071ff71be44d5  push r9
000071ff71be44d7  push r10
000071ff71be44d9  push r11
000071ff71be44db  sub rsp, 0xF0
000071ff71be44e2  vmovaps [rsp], xmm0
000071ff71be44e7  vmovaps [rsp+0x10], xmm1
000071ff71be44ed  vmovaps [rsp+0x20], xmm2
000071ff71be44f3  vmovaps [rsp+0x30], xmm3
000071ff71be44f9  vmovaps [rsp+0x40], xmm4
000071ff71be44ff  vmovaps [rsp+0x50], xmm5
000071ff71be4505  vmovaps [rsp+0x60], xmm6
000071ff71be450b  vmovaps [rsp+0x70], xmm8
000071ff71be4511  vmovaps [rsp+0x80], xmm9
000071ff71be451a  vmovaps [rsp+0x90], xmm10
000071ff71be4523  vmovaps [rsp+0xA0], xmm11
000071ff71be452c  vmovaps [rsp+0xB0], xmm12
000071ff71be4535  vmovaps [rsp+0xC0], xmm13
000071ff71be453e  vmovaps [rsp+0xD0], xmm14
000071ff71be4547  vmovaps [rsp+0xE0], xmm15
000071ff71be4550  sub rsp, 0x30
000071ff71be4554  movaps [rsp], xmm7
000071ff71be4558  movaps [rsp+0x10], xmm9
000071ff71be455e  movaps [rsp+0x20], xmm15
000071ff71be4564  lea rdi, [rsp]
000071ff71be4568  mov esi, 0x00
000071ff71be456d  mov rax, 0x5E6872E10530
000071ff71be4577  call rax
000071ff71be4579  movaps xmm7, [rsp]
000071ff71be457d  add rsp, 0x30
000071ff71be4581  vmovaps xmm0, [rsp]
000071ff71be4586  vmovaps xmm1, [rsp+0x10]
000071ff71be458c  vmovaps xmm2, [rsp+0x20]
000071ff71be4592  vmovaps xmm3, [rsp+0x30]
000071ff71be4598  vmovaps xmm4, [rsp+0x40]
000071ff71be459e  vmovaps xmm5, [rsp+0x50]
000071ff71be45a4  vmovaps xmm6, [rsp+0x60]
000071ff71be45aa  vmovaps xmm8, [rsp+0x70]
000071ff71be45b0  vmovaps xmm9, [rsp+0x80]
000071ff71be45b9  vmovaps xmm10, [rsp+0x90]
000071ff71be45c2  vmovaps xmm11, [rsp+0xA0]
000071ff71be45cb  vmovaps xmm12, [rsp+0xB0]
000071ff71be45d4  vmovaps xmm13, [rsp+0xC0]
000071ff71be45dd  vmovaps xmm14, [rsp+0xD0]
000071ff71be45e6  vmovaps xmm15, [rsp+0xE0]
000071ff71be45ef  add rsp, 0xF0
000071ff71be45f6  pop r11
000071ff71be45f8  pop r10
000071ff71be45fa  pop r9
000071ff71be45fc  pop r8
000071ff71be45fe  pop rsi
000071ff71be45ff  pop rdi
000071ff71be4600  pop rdx
000071ff71be4601  pop rcx
000071ff71be4602  pop rax
000071ff71be4603  add rsp, 0x08
000071ff71be4607  jmp 0x000071FF71BDF994
000071ff71be460c  sub rsp, 0x08
000071ff71be4610  push rax
000071ff71be4611  push rcx
000071ff71be4612  push rdx
000071ff71be4613  push rdi
000071ff71be4614  push rsi
000071ff71be4615  push r8
000071ff71be4617  push r9
000071ff71be4619  push r10
000071ff71be461b  push r11
000071ff71be461d  sub rsp, 0xF0
000071ff71be4624  vmovaps [rsp], xmm0
000071ff71be4629  vmovaps [rsp+0x10], xmm1
000071ff71be462f  vmovaps [rsp+0x20], xmm2
000071ff71be4635  vmovaps [rsp+0x30], xmm3
000071ff71be463b  vmovaps [rsp+0x40], xmm4
000071ff71be4641  vmovaps [rsp+0x50], xmm5
000071ff71be4647  vmovaps [rsp+0x60], xmm6
000071ff71be464d  vmovaps [rsp+0x70], xmm7
000071ff71be4653  vmovaps [rsp+0x80], xmm8
000071ff71be465c  vmovaps [rsp+0x90], xmm10
000071ff71be4665  vmovaps [rsp+0xA0], xmm11
000071ff71be466e  vmovaps [rsp+0xB0], xmm12
000071ff71be4677  vmovaps [rsp+0xC0], xmm13
000071ff71be4680  vmovaps [rsp+0xD0], xmm14
000071ff71be4689  vmovaps [rsp+0xE0], xmm15
000071ff71be4692  sub rsp, 0x30
000071ff71be4696  movaps [rsp], xmm9
000071ff71be469b  movaps [rsp+0x10], xmm13
000071ff71be46a1  movaps [rsp+0x20], xmm15
000071ff71be46a7  lea rdi, [rsp]
000071ff71be46ab  mov esi, 0x00
000071ff71be46b0  mov rax, 0x5E6872E10530
000071ff71be46ba  call rax
000071ff71be46bc  movaps xmm9, [rsp]
000071ff71be46c1  add rsp, 0x30
000071ff71be46c5  vmovaps xmm0, [rsp]
000071ff71be46ca  vmovaps xmm1, [rsp+0x10]
000071ff71be46d0  vmovaps xmm2, [rsp+0x20]
000071ff71be46d6  vmovaps xmm3, [rsp+0x30]
000071ff71be46dc  vmovaps xmm4, [rsp+0x40]
000071ff71be46e2  vmovaps xmm5, [rsp+0x50]
000071ff71be46e8  vmovaps xmm6, [rsp+0x60]
000071ff71be46ee  vmovaps xmm7, [rsp+0x70]
000071ff71be46f4  vmovaps xmm8, [rsp+0x80]
000071ff71be46fd  vmovaps xmm10, [rsp+0x90]
000071ff71be4706  vmovaps xmm11, [rsp+0xA0]
000071ff71be470f  vmovaps xmm12, [rsp+0xB0]
000071ff71be4718  vmovaps xmm13, [rsp+0xC0]
000071ff71be4721  vmovaps xmm14, [rsp+0xD0]
000071ff71be472a  vmovaps xmm15, [rsp+0xE0]
000071ff71be4733  add rsp, 0xF0
000071ff71be473a  pop r11
000071ff71be473c  pop r10
000071ff71be473e  pop r9
000071ff71be4740  pop r8
000071ff71be4742  pop rsi
000071ff71be4743  pop rdi
000071ff71be4744  pop rdx
000071ff71be4745  pop rcx
000071ff71be4746  pop rax
000071ff71be4747  add rsp, 0x08
000071ff71be474b  jmp 0x000071FF71BDF9C2
000071ff71be4750  sub rsp, 0x08
000071ff71be4754  push rax
000071ff71be4755  push rcx
000071ff71be4756  push rdx
000071ff71be4757  push rdi
000071ff71be4758  push rsi
000071ff71be4759  push r8
000071ff71be475b  push r9
000071ff71be475d  push r10
000071ff71be475f  push r11
000071ff71be4761  sub rsp, 0xF0
000071ff71be4768  vmovaps [rsp], xmm0
000071ff71be476d  vmovaps [rsp+0x10], xmm1
000071ff71be4773  vmovaps [rsp+0x20], xmm2
000071ff71be4779  vmovaps [rsp+0x30], xmm3
000071ff71be477f  vmovaps [rsp+0x40], xmm4
000071ff71be4785  vmovaps [rsp+0x50], xmm5
000071ff71be478b  vmovaps [rsp+0x60], xmm6
000071ff71be4791  vmovaps [rsp+0x70], xmm7
000071ff71be4797  vmovaps [rsp+0x80], xmm8
000071ff71be47a0  vmovaps [rsp+0x90], xmm9
000071ff71be47a9  vmovaps [rsp+0xA0], xmm10
000071ff71be47b2  vmovaps [rsp+0xB0], xmm11
000071ff71be47bb  vmovaps [rsp+0xC0], xmm12
000071ff71be47c4  vmovaps [rsp+0xD0], xmm13
000071ff71be47cd  vmovaps [rsp+0xE0], xmm14
000071ff71be47d6  sub rsp, 0x30
000071ff71be47da  movaps [rsp], xmm15
000071ff71be47df  movaps [rsp+0x10], xmm11
000071ff71be47e5  movaps [rsp+0x20], xmm12
000071ff71be47eb  lea rdi, [rsp]
000071ff71be47ef  mov esi, 0x00
000071ff71be47f4  mov rax, 0x5E6872E10530
000071ff71be47fe  call rax
000071ff71be4800  movaps xmm15, [rsp]
000071ff71be4805  add rsp, 0x30
000071ff71be4809  vmovaps xmm0, [rsp]
000071ff71be480e  vmovaps xmm1, [rsp+0x10]
000071ff71be4814  vmovaps xmm2, [rsp+0x20]
000071ff71be481a  vmovaps xmm3, [rsp+0x30]
000071ff71be4820  vmovaps xmm4, [rsp+0x40]
000071ff71be4826  vmovaps xmm5, [rsp+0x50]
000071ff71be482c  vmovaps xmm6, [rsp+0x60]
000071ff71be4832  vmovaps xmm7, [rsp+0x70]
000071ff71be4838  vmovaps xmm8, [rsp+0x80]
000071ff71be4841  vmovaps xmm9, [rsp+0x90]
000071ff71be484a  vmovaps xmm10, [rsp+0xA0]
000071ff71be4853  vmovaps xmm11, [rsp+0xB0]
000071ff71be485c  vmovaps xmm12, [rsp+0xC0]
000071ff71be4865  vmovaps xmm13, [rsp+0xD0]
000071ff71be486e  vmovaps xmm14, [rsp+0xE0]
000071ff71be4877  add rsp, 0xF0
000071ff71be487e  pop r11
000071ff71be4880  pop r10
000071ff71be4882  pop r9
000071ff71be4884  pop r8
000071ff71be4886  pop rsi
000071ff71be4887  pop rdi
000071ff71be4888  pop rdx
000071ff71be4889  pop rcx
000071ff71be488a  pop rax
000071ff71be488b  add rsp, 0x08
000071ff71be488f  jmp 0x000071FF71BDF9DD
000071ff71be4894  sub rsp, 0x08
000071ff71be4898  push rax
000071ff71be4899  push rcx
000071ff71be489a  push rdx
000071ff71be489b  push rdi
000071ff71be489c  push rsi
000071ff71be489d  push r8
000071ff71be489f  push r9
000071ff71be48a1  push r10
000071ff71be48a3  push r11
000071ff71be48a5  sub rsp, 0xF0
000071ff71be48ac  vmovaps [rsp], xmm0
000071ff71be48b1  vmovaps [rsp+0x10], xmm1
000071ff71be48b7  vmovaps [rsp+0x20], xmm2
000071ff71be48bd  vmovaps [rsp+0x30], xmm3
000071ff71be48c3  vmovaps [rsp+0x40], xmm4
000071ff71be48c9  vmovaps [rsp+0x50], xmm5
000071ff71be48cf  vmovaps [rsp+0x60], xmm6
000071ff71be48d5  vmovaps [rsp+0x70], xmm7
000071ff71be48db  vmovaps [rsp+0x80], xmm8
000071ff71be48e4  vmovaps [rsp+0x90], xmm9
000071ff71be48ed  vmovaps [rsp+0xA0], xmm10
000071ff71be48f6  vmovaps [rsp+0xB0], xmm11
000071ff71be48ff  vmovaps [rsp+0xC0], xmm12
000071ff71be4908  vmovaps [rsp+0xD0], xmm14
000071ff71be4911  vmovaps [rsp+0xE0], xmm15
000071ff71be491a  sub rsp, 0x30
000071ff71be491e  movaps [rsp], xmm13
000071ff71be4923  movaps [rsp+0x10], xmm10
000071ff71be4929  movaps [rsp+0x20], xmm14
000071ff71be492f  lea rdi, [rsp]
000071ff71be4933  mov esi, 0x00
000071ff71be4938  mov rax, 0x5E6872E10530
000071ff71be4942  call rax
000071ff71be4944  movaps xmm13, [rsp]
000071ff71be4949  add rsp, 0x30
000071ff71be494d  vmovaps xmm0, [rsp]
000071ff71be4952  vmovaps xmm1, [rsp+0x10]
000071ff71be4958  vmovaps xmm2, [rsp+0x20]
000071ff71be495e  vmovaps xmm3, [rsp+0x30]
000071ff71be4964  vmovaps xmm4, [rsp+0x40]
000071ff71be496a  vmovaps xmm5, [rsp+0x50]
000071ff71be4970  vmovaps xmm6, [rsp+0x60]
000071ff71be4976  vmovaps xmm7, [rsp+0x70]
000071ff71be497c  vmovaps xmm8, [rsp+0x80]
000071ff71be4985  vmovaps xmm9, [rsp+0x90]
000071ff71be498e  vmovaps xmm10, [rsp+0xA0]
000071ff71be4997  vmovaps xmm11, [rsp+0xB0]
000071ff71be49a0  vmovaps xmm12, [rsp+0xC0]
000071ff71be49a9  vmovaps xmm14, [rsp+0xD0]
000071ff71be49b2  vmovaps xmm15, [rsp+0xE0]
000071ff71be49bb  add rsp, 0xF0
000071ff71be49c2  pop r11
000071ff71be49c4  pop r10
000071ff71be49c6  pop r9
000071ff71be49c8  pop r8
000071ff71be49ca  pop rsi
000071ff71be49cb  pop rdi
000071ff71be49cc  pop rdx
000071ff71be49cd  pop rcx
000071ff71be49ce  pop rax
000071ff71be49cf  add rsp, 0x08
000071ff71be49d3  jmp 0x000071FF71BDFA00
000071ff71be49d8  sub rsp, 0x08
000071ff71be49dc  push rax
000071ff71be49dd  push rcx
000071ff71be49de  push rdx
000071ff71be49df  push rdi
000071ff71be49e0  push rsi
000071ff71be49e1  push r8
000071ff71be49e3  push r9
000071ff71be49e5  push r10
000071ff71be49e7  push r11
000071ff71be49e9  sub rsp, 0xF0
000071ff71be49f0  vmovaps [rsp], xmm0
000071ff71be49f5  vmovaps [rsp+0x10], xmm1
000071ff71be49fb  vmovaps [rsp+0x20], xmm2
000071ff71be4a01  vmovaps [rsp+0x30], xmm3
000071ff71be4a07  vmovaps [rsp+0x40], xmm4
000071ff71be4a0d  vmovaps [rsp+0x50], xmm5
000071ff71be4a13  vmovaps [rsp+0x60], xmm6
000071ff71be4a19  vmovaps [rsp+0x70], xmm7
000071ff71be4a1f  vmovaps [rsp+0x80], xmm8
000071ff71be4a28  vmovaps [rsp+0x90], xmm9
000071ff71be4a31  vmovaps [rsp+0xA0], xmm10
000071ff71be4a3a  vmovaps [rsp+0xB0], xmm11
000071ff71be4a43  vmovaps [rsp+0xC0], xmm12
000071ff71be4a4c  vmovaps [rsp+0xD0], xmm13
000071ff71be4a55  vmovaps [rsp+0xE0], xmm15
000071ff71be4a5e  sub rsp, 0x30
000071ff71be4a62  movaps [rsp], xmm14
000071ff71be4a67  movaps [rsp+0x10], xmm1
000071ff71be4a6c  movaps [rsp+0x20], xmm7
000071ff71be4a71  lea rdi, [rsp]
000071ff71be4a75  mov esi, 0x00
000071ff71be4a7a  mov rax, 0x5E6872E10530
000071ff71be4a84  call rax
000071ff71be4a86  movaps xmm14, [rsp]
000071ff71be4a8b  add rsp, 0x30
000071ff71be4a8f  vmovaps xmm0, [rsp]
000071ff71be4a94  vmovaps xmm1, [rsp+0x10]
000071ff71be4a9a  vmovaps xmm2, [rsp+0x20]
000071ff71be4aa0  vmovaps xmm3, [rsp+0x30]
000071ff71be4aa6  vmovaps xmm4, [rsp+0x40]
000071ff71be4aac  vmovaps xmm5, [rsp+0x50]
000071ff71be4ab2  vmovaps xmm6, [rsp+0x60]
000071ff71be4ab8  vmovaps xmm7, [rsp+0x70]
000071ff71be4abe  vmovaps xmm8, [rsp+0x80]
000071ff71be4ac7  vmovaps xmm9, [rsp+0x90]
000071ff71be4ad0  vmovaps xmm10, [rsp+0xA0]
000071ff71be4ad9  vmovaps xmm11, [rsp+0xB0]
000071ff71be4ae2  vmovaps xmm12, [rsp+0xC0]
000071ff71be4aeb  vmovaps xmm13, [rsp+0xD0]
000071ff71be4af4  vmovaps xmm15, [rsp+0xE0]
000071ff71be4afd  add rsp, 0xF0
000071ff71be4b04  pop r11
000071ff71be4b06  pop r10
000071ff71be4b08  pop r9
000071ff71be4b0a  pop r8
000071ff71be4b0c  pop rsi
000071ff71be4b0d  pop rdi
000071ff71be4b0e  pop rdx
000071ff71be4b0f  pop rcx
000071ff71be4b10  pop rax
000071ff71be4b11  add rsp, 0x08
000071ff71be4b15  jmp 0x000071FF71BDFA23
000071ff71be4b1a  sub rsp, 0x08
000071ff71be4b1e  push rax
000071ff71be4b1f  push rcx
000071ff71be4b20  push rdx
000071ff71be4b21  push rdi
000071ff71be4b22  push rsi
000071ff71be4b23  push r8
000071ff71be4b25  push r9
000071ff71be4b27  push r10
000071ff71be4b29  push r11
000071ff71be4b2b  sub rsp, 0xF0
000071ff71be4b32  vmovaps [rsp], xmm0
000071ff71be4b37  vmovaps [rsp+0x10], xmm2
000071ff71be4b3d  vmovaps [rsp+0x20], xmm3
000071ff71be4b43  vmovaps [rsp+0x30], xmm4
000071ff71be4b49  vmovaps [rsp+0x40], xmm5
000071ff71be4b4f  vmovaps [rsp+0x50], xmm6
000071ff71be4b55  vmovaps [rsp+0x60], xmm7
000071ff71be4b5b  vmovaps [rsp+0x70], xmm8
000071ff71be4b61  vmovaps [rsp+0x80], xmm9
000071ff71be4b6a  vmovaps [rsp+0x90], xmm10
000071ff71be4b73  vmovaps [rsp+0xA0], xmm11
000071ff71be4b7c  vmovaps [rsp+0xB0], xmm12
000071ff71be4b85  vmovaps [rsp+0xC0], xmm13
000071ff71be4b8e  vmovaps [rsp+0xD0], xmm14
000071ff71be4b97  vmovaps [rsp+0xE0], xmm15
000071ff71be4ba0  sub rsp, 0x30
000071ff71be4ba4  movaps [rsp], xmm1
000071ff71be4ba8  movaps [rsp+0x10], xmm8
000071ff71be4bae  movaps [rsp+0x20], xmm9
000071ff71be4bb4  lea rdi, [rsp]
000071ff71be4bb8  mov esi, 0x00
000071ff71be4bbd  mov rax, 0x5E6872E10530
000071ff71be4bc7  call rax
000071ff71be4bc9  movaps xmm1, [rsp]
000071ff71be4bcd  add rsp, 0x30
000071ff71be4bd1  vmovaps xmm0, [rsp]
000071ff71be4bd6  vmovaps xmm2, [rsp+0x10]
000071ff71be4bdc  vmovaps xmm3, [rsp+0x20]
000071ff71be4be2  vmovaps xmm4, [rsp+0x30]
000071ff71be4be8  vmovaps xmm5, [rsp+0x40]
000071ff71be4bee  vmovaps xmm6, [rsp+0x50]
000071ff71be4bf4  vmovaps xmm7, [rsp+0x60]
000071ff71be4bfa  vmovaps xmm8, [rsp+0x70]
000071ff71be4c00  vmovaps xmm9, [rsp+0x80]
000071ff71be4c09  vmovaps xmm10, [rsp+0x90]
000071ff71be4c12  vmovaps xmm11, [rsp+0xA0]
000071ff71be4c1b  vmovaps xmm12, [rsp+0xB0]
000071ff71be4c24  vmovaps xmm13, [rsp+0xC0]
000071ff71be4c2d  vmovaps xmm14, [rsp+0xD0]
000071ff71be4c36  vmovaps xmm15, [rsp+0xE0]
000071ff71be4c3f  add rsp, 0xF0
000071ff71be4c46  pop r11
000071ff71be4c48  pop r10
000071ff71be4c4a  pop r9
000071ff71be4c4c  pop r8
000071ff71be4c4e  pop rsi
000071ff71be4c4f  pop rdi
000071ff71be4c50  pop rdx
000071ff71be4c51  pop rcx
000071ff71be4c52  pop rax
000071ff71be4c53  add rsp, 0x08
000071ff71be4c57  jmp 0x000071FF71BDFA45
000071ff71be4c5c  call 0x000071FF71AE5940
000071ff71be4c61  jmp 0x000071FF71BDFA53
000071ff71be4c66  call 0x000071FF71A0C380
000071ff71be4c6b  jmp 0x000071FF71BDFA5D
000071ff71be4c70  call 0x000071FF71A0D600
000071ff71be4c75  jmp 0x000071FF71BDFA67
000071ff71be4c7a  call 0x000071FF719FF540
000071ff71be4c7f  jmp 0x000071FF71BDFA71
000071ff71be4c84  int3
000071ff71be4c85  nop [rax+rax*1], ax
000071ff71be4c8e  nop
000071ff71be4c90  mov qword ptr [r15+0x40], 0x430000
000071ff71be4c98  mov eax, 0x430CC0
000071ff71be4c9d  mov r14, [r13+rax*1]
000071ff71be4ca2  movq xmm1, r14
000071ff71be4ca7  mov rax, [r15+0x50]
000071ff71be4cab  movups xmm15, [r13+rax*1]
000071ff71be4cb1  movaps [r15+0x120], xmm15
000071ff71be4cb9  mov qword ptr [r15+0x48], 0x10
000071ff71be4cc1  xor eax, eax
000071ff71be4cc3  mov r14d, 0x10
000071ff71be4cc9  mov r12d, 0x200
000071ff71be4ccf  cmp r14, r12
000071ff71be4cd2  cmc
000071ff71be4cd3  lahf
000071ff71be4cd4  seto al
000071ff71be4cd7  mov [r15+0x108], eax
000071ff71be4cde  pextrq rax, xmm15, 0x01
000071ff71be4ce5  movq xmm14, rax
000071ff71be4cea  movaps [r15+0x130], xmm14
000071ff71be4cf2  movq rax, xmm1
000071ff71be4cf7  movq r14, xmm15
000071ff71be4cfc  vmovq xmm1, rax
000071ff71be4d01  vmovq xmm15, r14
000071ff71be4d06  movaps xmm13, xmm1
000071ff71be4d0a  addsd xmm13, xmm15
000071ff71be4d0f  ucomisd xmm13, xmm13
000071ff71be4d14  jp 0x000071FF71BE4DD3
000071ff71be4d1a  movq xmm13, xmm13
000071ff71be4d1f  movq rax, xmm13
000071ff71be4d24  movq r14, xmm14
000071ff71be4d29  vmovq xmm1, rax
000071ff71be4d2e  vmovq xmm15, r14
000071ff71be4d33  movaps xmm14, xmm1
000071ff71be4d37  addsd xmm14, xmm15
000071ff71be4d3c  ucomisd xmm14, xmm14
000071ff71be4d41  jp 0x000071FF71BE4E1B
000071ff71be4d47  movq xmm14, xmm14
000071ff71be4d4c  movaps [r15+0x110], xmm14
000071ff71be4d54  mov eax, [r15+0x108]
000071ff71be4d5b  sahf
000071ff71be4d5c  jnz 0x000071FF71BE4D8E
000071ff71be4d5e  cmp dword ptr [r15+0x318], 0x00
000071ff71be4d66  jz 0x000071FF71BE5030
000071ff71be4d6c  nop [rax+rax*1], ax
000071ff71be4d75  nop [rax+rax*1], eax
000071ff71be4d7d  mov eax, 0x410704
000071ff71be4d82  mov [r15+0x100], rax
000071ff71be4d89  jmp 0x000071FF719FE110
000071ff71be4d8e  cmp dword ptr [r15+0x318], 0x00
000071ff71be4d96  jz 0x000071FF71BE4E70
000071ff71be4d9c  nop [rax+rax*1], ax
000071ff71be4da5  nop [rax+rax*1], eax
000071ff71be4dad  mov eax, 0x4106E8
000071ff71be4db2  mov [r15+0x100], rax
000071ff71be4db9  jmp 0x000071FF719FE110
000071ff71be4dbe  int3
000071ff71be4dbf  call 0x000071FF71A0DC20
000071ff71be4dc4  jmp 0x000071FF71BE4CA2
000071ff71be4dc9  call 0x000071FF71A0E760
000071ff71be4dce  jmp 0x000071FF71BE4CB1
000071ff71be4dd3  ucomisd xmm1, xmm15
000071ff71be4dd8  jp 0x000071FF71BE4DE7
000071ff71be4dda  movaps xmm13, [0x000071FF717FE060]
000071ff71be4de2  jmp 0x000071FF71BE4D1A
000071ff71be4de7  vxorps xmm0, xmm1, xmm15
000071ff71be4dec  pextrw eax, xmm0, 0x03
000071ff71be4df1  and eax, 0x7FF8
000071ff71be4df6  cmp eax, 0x08
000071ff71be4df9  jnz 0x000071FF71BE4D1A
000071ff71be4dff  movq rax, xmm15
000071ff71be4e04  shl rax, 0x0D
000071ff71be4e08  jbe 0x000071FF71BE4D1A
000071ff71be4e0e  vorps xmm13, xmm15, [0x000071FF717FE070]
000071ff71be4e16  jmp 0x000071FF71BE4D1A
000071ff71be4e1b  ucomisd xmm1, xmm15
000071ff71be4e20  jp 0x000071FF71BE4E2F
000071ff71be4e22  movaps xmm14, [0x000071FF717FE060]
000071ff71be4e2a  jmp 0x000071FF71BE4D47
000071ff71be4e2f  vxorps xmm0, xmm1, xmm15
000071ff71be4e34  pextrw eax, xmm0, 0x03
000071ff71be4e39  and eax, 0x7FF8
000071ff71be4e3e  cmp eax, 0x08
000071ff71be4e41  jnz 0x000071FF71BE4D47
000071ff71be4e47  movq rax, xmm15
000071ff71be4e4c  shl rax, 0x0D
000071ff71be4e50  jbe 0x000071FF71BE4D47
000071ff71be4e56  vorps xmm14, xmm15, [0x000071FF717FE070]
000071ff71be4e5e  jmp 0x000071FF71BE4D47
000071ff71be4e63  int3
000071ff71be4e64  nop [rax+rax*1], ax
000071ff71be4e6d  nop [rax], eax
000071ff71be4e70  mov rax, [r15+0x48]
000071ff71be4e74  mov r14, [r15+0x50]
000071ff71be4e78  lea r12, [r14+rax*1]
000071ff71be4e7c  movups xmm1, [r13+r12*1]
000071ff71be4e82  movaps [r15+0x120], xmm1
000071ff71be4e8a  lea r14, [rax+0x10]
000071ff71be4e8e  mov [r15+0x48], r14
000071ff71be4e92  xor eax, eax
000071ff71be4e94  mov r12d, 0x200
000071ff71be4e9a  cmp r14, r12
000071ff71be4e9d  cmc
000071ff71be4e9e  lahf
000071ff71be4e9f  seto al
000071ff71be4ea2  mov [r15+0x108], eax
000071ff71be4ea9  pextrq rax, xmm1, 0x01
000071ff71be4eb0  movq xmm15, rax
000071ff71be4eb5  movaps [r15+0x130], xmm15
000071ff71be4ebd  movaps xmm14, [r15+0x110]
000071ff71be4ec5  movq rax, xmm14
000071ff71be4eca  movq r14, xmm1
000071ff71be4ecf  vmovq xmm1, rax
000071ff71be4ed4  vmovq xmm14, r14
000071ff71be4ed9  movaps xmm13, xmm1
000071ff71be4edd  addsd xmm13, xmm14
000071ff71be4ee2  ucomisd xmm13, xmm13
000071ff71be4ee7  jp 0x000071FF71BE4F9C
000071ff71be4eed  movq xmm13, xmm13
000071ff71be4ef2  movq rax, xmm13
000071ff71be4ef7  movq r14, xmm15
000071ff71be4efc  vmovq xmm1, rax
000071ff71be4f01  vmovq xmm15, r14
000071ff71be4f06  movaps xmm14, xmm1
000071ff71be4f0a  addsd xmm14, xmm15
000071ff71be4f0f  ucomisd xmm14, xmm14
000071ff71be4f14  jp 0x000071FF71BE4FE4
000071ff71be4f1a  movq xmm14, xmm14
000071ff71be4f1f  movaps [r15+0x110], xmm14
000071ff71be4f27  mov eax, [r15+0x108]
000071ff71be4f2e  sahf
000071ff71be4f2f  jnz 0x000071FF71BE4F61
000071ff71be4f31  cmp dword ptr [r15+0x318], 0x00
000071ff71be4f39  jz 0x000071FF71BE5030
000071ff71be4f3f  nop [rax+rax*1], ax
000071ff71be4f48  nop [rax+rax*1], eax
000071ff71be4f50  mov eax, 0x410704
000071ff71be4f55  mov [r15+0x100], rax
000071ff71be4f5c  jmp 0x000071FF719FE110
000071ff71be4f61  cmp dword ptr [r15+0x318], 0x00
000071ff71be4f69  jz 0x000071FF71BE4E70
000071ff71be4f6f  nop [rax+rax*1], ax
000071ff71be4f78  nop [rax+rax*1], eax
000071ff71be4f80  mov eax, 0x4106E8
000071ff71be4f85  mov [r15+0x100], rax
000071ff71be4f8c  jmp 0x000071FF719FE110
000071ff71be4f91  int3
000071ff71be4f92  call 0x000071FF71AB52F0
000071ff71be4f97  jmp 0x000071FF71BE4E82
000071ff71be4f9c  ucomisd xmm1, xmm14
000071ff71be4fa1  jp 0x000071FF71BE4FB0
000071ff71be4fa3  movaps xmm13, [0x000071FF717FE060]
000071ff71be4fab  jmp 0x000071FF71BE4EED
000071ff71be4fb0  vxorps xmm0, xmm1, xmm14
000071ff71be4fb5  pextrw eax, xmm0, 0x03
000071ff71be4fba  and eax, 0x7FF8
000071ff71be4fbf  cmp eax, 0x08
000071ff71be4fc2  jnz 0x000071FF71BE4EED
000071ff71be4fc8  movq rax, xmm14
000071ff71be4fcd  shl rax, 0x0D
000071ff71be4fd1  jbe 0x000071FF71BE4EED
000071ff71be4fd7  vorps xmm13, xmm14, [0x000071FF717FE070]
000071ff71be4fdf  jmp 0x000071FF71BE4EED
000071ff71be4fe4  ucomisd xmm1, xmm15
000071ff71be4fe9  jp 0x000071FF71BE4FF8
000071ff71be4feb  movaps xmm14, [0x000071FF717FE060]
000071ff71be4ff3  jmp 0x000071FF71BE4F1A
000071ff71be4ff8  vxorps xmm0, xmm1, xmm15
000071ff71be4ffd  pextrw eax, xmm0, 0x03
000071ff71be5002  and eax, 0x7FF8
000071ff71be5007  cmp eax, 0x08
000071ff71be500a  jnz 0x000071FF71BE4F1A
000071ff71be5010  movq rax, xmm15
000071ff71be5015  shl rax, 0x0D
000071ff71be5019  jbe 0x000071FF71BE4F1A
000071ff71be501f  vorps xmm14, xmm15, [0x000071FF717FE070]
000071ff71be5027  jmp 0x000071FF71BE4F1A
000071ff71be502c  int3
000071ff71be502d  nop [rax], eax
000071ff71be5030  mov rax, [r15+0xF8]
000071ff71be5037  lea r14, [rax+0x1D0]
000071ff71be503e  mov r12, [r13+r14*1]
000071ff71be5043  lea r14, [rax+0x1D8]
000071ff71be504a  mov r11, [r13+r14*1]
000071ff71be504f  mov [r15+0xA0], r12
000071ff71be5056  mov [r15+0x98], r11
000071ff71be505d  mov r14, [r15+0x40]
000071ff71be5061  lea r12, [r14+0xCC0]
000071ff71be5068  movaps xmm1, [r15+0x110]
000071ff71be5070  movq r14, xmm1
000071ff71be5075  mov [r13+r12*1], r14
000071ff71be507a  lea r14, [rax+0x1C0]
000071ff71be5081  mov r12, [r13+r14*1]
000071ff71be5086  lea r14, [rax+0x1C8]
000071ff71be508d  mov r11, [r13+r14*1]
000071ff71be5092  mov [r15+0xE8], r12
000071ff71be5099  mov [r15+0xF0], r11
000071ff71be50a0  lea r14, [rax+0x1B0]
000071ff71be50a7  mov r12, [r13+r14*1]
000071ff71be50ac  lea r14, [rax+0x1B8]
000071ff71be50b3  mov r10, [r13+r14*1]
000071ff71be50b8  movq xmm1, r12
000071ff71be50bd  movq xmm15, r10
000071ff71be50c2  movq xmm1, xmm1
000071ff71be50c6  movq xmm1, xmm1
000071ff71be50ca  movaps [r15+0x1A0], xmm1
000071ff71be50d2  movq xmm15, xmm15
000071ff71be50d7  movq xmm15, xmm15
000071ff71be50dc  movaps [r15+0x190], xmm15
000071ff71be50e4  lea r14, [rax+0x1A0]
000071ff71be50eb  mov r12, [r13+r14*1]
000071ff71be50f0  lea r14, [rax+0x1A8]
000071ff71be50f7  mov r10, [r13+r14*1]
000071ff71be50fc  movq xmm1, r12
000071ff71be5101  movq xmm15, r10
000071ff71be5106  movq xmm1, xmm1
000071ff71be510a  movq xmm1, xmm1
000071ff71be510e  movaps [r15+0x1C0], xmm1
000071ff71be5116  movq xmm15, xmm15
000071ff71be511b  movq xmm15, xmm15
000071ff71be5120  movaps [r15+0x1B0], xmm15
000071ff71be5128  lea r14, [rax+0x190]
000071ff71be512f  mov r12, [r13+r14*1]
000071ff71be5134  lea r14, [rax+0x198]
000071ff71be513b  mov r10, [r13+r14*1]
000071ff71be5140  movq xmm1, r12
000071ff71be5145  movq xmm15, r10
000071ff71be514a  movq xmm1, xmm1
000071ff71be514e  movq xmm1, xmm1
000071ff71be5152  movaps [r15+0x1E0], xmm1
000071ff71be515a  movq xmm15, xmm15
000071ff71be515f  movq xmm15, xmm15
000071ff71be5164  movaps [r15+0x1D0], xmm15
000071ff71be516c  lea r14, [rax+0x180]
000071ff71be5173  mov r12, [r13+r14*1]
000071ff71be5178  lea r14, [rax+0x188]
000071ff71be517f  mov r10, [r13+r14*1]
000071ff71be5184  movq xmm1, r12
000071ff71be5189  movq xmm15, r10
000071ff71be518e  movq xmm1, xmm1
000071ff71be5192  movq xmm1, xmm1
000071ff71be5196  movaps [r15+0x200], xmm1
000071ff71be519e  movq xmm15, xmm15
000071ff71be51a3  movq xmm15, xmm15
000071ff71be51a8  movaps [r15+0x1F0], xmm15
000071ff71be51b0  lea r14, [rax+0x1E0]
000071ff71be51b7  mov [r15+0xF8], r14
000071ff71be51be  mov [r15+0x100], r11
000071ff71be51c5  jmp 0x000071FF71BCE5C0
000071ff71be51ca  int3
000071ff71be51cb  call 0x000071FF71AE27E0
000071ff71be51d0  jmp 0x000071FF71BE5043
000071ff71be51d5  call 0x000071FF71AE1570
000071ff71be51da  jmp 0x000071FF71BE504F
000071ff71be51df  call 0x000071FF71AC3FE0
000071ff71be51e4  jmp 0x000071FF71BE507A
000071ff71be51e9  call 0x000071FF71AE27E0
000071ff71be51ee  jmp 0x000071FF71BE5086
000071ff71be51f3  call 0x000071FF71AE1570
000071ff71be51f8  jmp 0x000071FF71BE5092
000071ff71be51fd  call 0x000071FF71AE27E0
000071ff71be5202  jmp 0x000071FF71BE50AC
000071ff71be5207  call 0x000071FF71AE0300
000071ff71be520c  jmp 0x000071FF71BE50B8
000071ff71be5211  call 0x000071FF71AE27E0
000071ff71be5216  jmp 0x000071FF71BE50F0
000071ff71be521b  call 0x000071FF71AE0300
000071ff71be5220  jmp 0x000071FF71BE50FC
000071ff71be5225  call 0x000071FF71AE27E0
000071ff71be522a  jmp 0x000071FF71BE5134
000071ff71be522f  call 0x000071FF71AE0300
000071ff71be5234  jmp 0x000071FF71BE5140
000071ff71be5239  call 0x000071FF71AE27E0
000071ff71be523e  jmp 0x000071FF71BE5178
000071ff71be5243  call 0x000071FF71AE0300
000071ff71be5248  jmp 0x000071FF71BE5184
000071ff71be524d  int3
000071ff71be524e  nop
000071ff71be5250  mov qword ptr [r15+0x100], 0x04
000071ff71be525b  mov esi, 0x00
000071ff71be5260  mov edx, 0x09
000071ff71be5265  mov rdi, 0x7FFE4C3C5560
000071ff71be526f  mov rax, 0x5E6872CA3970
000071ff71be5279  call rax
000071ff71be527b  cmp dword ptr [r15+0x318], 0x00
000071ff71be5283  jnz 0x000071FF719FE110
000071ff71be5289  jmp 0x000071FF719FE0A0
000071ff71be528e  int3
000071ff71be528f  int3
