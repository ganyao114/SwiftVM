00007aa9b5fce69b  nop [rax+rax*1], eax
00007aa9b5fce6a0  mov rax, [r15+0xF8]
00007aa9b5fce6a7  lea r14, [rax-0x1E0]
00007aa9b5fce6ae  mov [r15+0xF8], r14
00007aa9b5fce6b5  lea rax, [r14+0x1D0]
00007aa9b5fce6bc  mov r12, [r15+0xA0]
00007aa9b5fce6c3  mov r11, [r15+0x98]
00007aa9b5fce6ca  mov [r13+rax*1], r12
00007aa9b5fce6cf  lea rax, [r14+0x1D8]
00007aa9b5fce6d6  mov [r13+rax*1], r11
00007aa9b5fce6db  mov eax, 0x420AA0
00007aa9b5fce6e0  movups xmm1, [r13+rax*1]
00007aa9b5fce6e6  mov eax, 0x420A30
00007aa9b5fce6eb  movups xmm15, [r13+rax*1]
00007aa9b5fce6f1  mov eax, 0x420AC0
00007aa9b5fce6f6  movups xmm14, [r13+rax*1]
00007aa9b5fce6fc  mov eax, 0x420A60
00007aa9b5fce701  movups xmm13, [r13+rax*1]
00007aa9b5fce707  mov qword ptr [r15+0x98], 0x430CD0
00007aa9b5fce712  mov eax, 0x420AD0
00007aa9b5fce717  movups xmm12, [r13+rax*1]
00007aa9b5fce71d  mov eax, 0x430CD0
00007aa9b5fce722  movups [r13+rax*1], xmm1
00007aa9b5fce728  mov eax, 0x430CE0
00007aa9b5fce72d  movups [r13+rax*1], xmm15
00007aa9b5fce733  mov eax, 0x430CF0
00007aa9b5fce738  movups [r13+rax*1], xmm14
00007aa9b5fce73e  mov eax, 0x430D00
00007aa9b5fce743  movups [r13+rax*1], xmm13
00007aa9b5fce749  mov eax, 0x420A20
00007aa9b5fce74e  movups xmm14, [r13+rax*1]
00007aa9b5fce754  mov eax, 0x420A10
00007aa9b5fce759  movups xmm13, [r13+rax*1]
00007aa9b5fce75f  mov eax, 0x430DD0
00007aa9b5fce764  movups [r13+rax*1], xmm1
00007aa9b5fce76a  mov eax, 0x430DE0
00007aa9b5fce76f  movups [r13+rax*1], xmm15
00007aa9b5fce775  mov eax, 0x430D10
00007aa9b5fce77a  movups [r13+rax*1], xmm12
00007aa9b5fce780  mov eax, 0x430D20
00007aa9b5fce785  movups [r13+rax*1], xmm14
00007aa9b5fce78b  mov eax, 0x420A00
00007aa9b5fce790  movups xmm1, [r13+rax*1]
00007aa9b5fce796  mov eax, 0x420A70
00007aa9b5fce79b  movups xmm15, [r13+rax*1]
00007aa9b5fce7a1  mov eax, 0x430D30
00007aa9b5fce7a6  movups [r13+rax*1], xmm13
00007aa9b5fce7ac  mov eax, 0x430D40
00007aa9b5fce7b1  movups [r13+rax*1], xmm1
00007aa9b5fce7b7  mov eax, 0x420A80
00007aa9b5fce7bc  movups xmm1, [r13+rax*1]
00007aa9b5fce7c2  mov eax, 0x420A50
00007aa9b5fce7c7  movups xmm14, [r13+rax*1]
00007aa9b5fce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007aa9b5fce7d5  mov eax, 0x430D50
00007aa9b5fce7da  movups [r13+rax*1], xmm15
00007aa9b5fce7e0  mov eax, 0x430D60
00007aa9b5fce7e5  movups [r13+rax*1], xmm1
00007aa9b5fce7eb  mov eax, 0x420AF0
00007aa9b5fce7f0  movups xmm1, [r13+rax*1]
00007aa9b5fce7f6  mov eax, 0x420B00
00007aa9b5fce7fb  movups xmm15, [r13+rax*1]
00007aa9b5fce801  movaps [r15+0x150], xmm15
00007aa9b5fce809  mov qword ptr [r15+0xA0], 0x3E8
00007aa9b5fce814  mov eax, 0x430D70
00007aa9b5fce819  movups [r13+rax*1], xmm14
00007aa9b5fce81f  mov eax, 0x430D80
00007aa9b5fce824  movups [r13+rax*1], xmm1
00007aa9b5fce82a  mov eax, 0x420AE0
00007aa9b5fce82f  movups xmm1, [r13+rax*1]
00007aa9b5fce835  mov eax, 0x420A90
00007aa9b5fce83a  movups xmm14, [r13+rax*1]
00007aa9b5fce840  movaps [r15+0x140], xmm14
00007aa9b5fce848  lea rax, [r14+0x180]
00007aa9b5fce84f  movq xmm13, qword ptr [r15+0x200]
00007aa9b5fce858  movq xmm12, qword ptr [r15+0x1F0]
00007aa9b5fce861  movq r12, xmm13
00007aa9b5fce866  movq r11, xmm12
00007aa9b5fce86b  mov [r13+rax*1], r12
00007aa9b5fce870  lea rax, [r14+0x188]
00007aa9b5fce877  mov [r13+rax*1], r11
00007aa9b5fce87c  mov eax, 0x430D90
00007aa9b5fce881  movups [r13+rax*1], xmm15
00007aa9b5fce887  mov eax, 0x430DA0
00007aa9b5fce88c  movups [r13+rax*1], xmm1
00007aa9b5fce892  mov eax, 0x420AB0
00007aa9b5fce897  movups xmm1, [r13+rax*1]
00007aa9b5fce89d  mov eax, 0x420B18
00007aa9b5fce8a2  mov r12, [r13+rax*1]
00007aa9b5fce8a7  movq xmm15, r12
00007aa9b5fce8ac  mov qword ptr [r15+0x40], 0x420B20
00007aa9b5fce8b4  mov eax, 0x430DB0
00007aa9b5fce8b9  movups [r13+rax*1], xmm14
00007aa9b5fce8bf  mov eax, 0x430DC0
00007aa9b5fce8c4  movups [r13+rax*1], xmm1
00007aa9b5fce8ca  mov eax, 0x420B80
00007aa9b5fce8cf  movups xmm1, [r13+rax*1]
00007aa9b5fce8d5  movq rax, xmm15
00007aa9b5fce8da  mov r12d, 0x430DF0
00007aa9b5fce8e0  mov [r13+r12*1], rax
00007aa9b5fce8e5  mov eax, 0x420B60
00007aa9b5fce8ea  movups xmm15, [r13+rax*1]
00007aa9b5fce8f0  mov eax, 0x420B70
00007aa9b5fce8f5  movups xmm14, [r13+rax*1]
00007aa9b5fce8fb  lea rax, [r14+0x160]
00007aa9b5fce902  movups [r13+rax*1], xmm1
00007aa9b5fce908  lea rax, [r14+0x190]
00007aa9b5fce90f  movq xmm1, qword ptr [r15+0x1E0]
00007aa9b5fce918  movq xmm13, qword ptr [r15+0x1D0]
00007aa9b5fce921  movq r12, xmm1
00007aa9b5fce926  movq r11, xmm13
00007aa9b5fce92b  mov [r13+rax*1], r12
00007aa9b5fce930  lea rax, [r14+0x198]
00007aa9b5fce937  mov [r13+rax*1], r11
00007aa9b5fce93c  lea rax, [r14+0x140]
00007aa9b5fce943  movups [r13+rax*1], xmm15
00007aa9b5fce949  lea rax, [r14+0x150]
00007aa9b5fce950  movups [r13+rax*1], xmm14
00007aa9b5fce956  mov eax, 0x420B20
00007aa9b5fce95b  movups xmm1, [r13+rax*1]
00007aa9b5fce961  mov eax, 0x420B30
00007aa9b5fce966  movups xmm15, [r13+rax*1]
00007aa9b5fce96c  movaps [r15+0x120], xmm15
00007aa9b5fce974  lea rax, [r14+0x1A0]
00007aa9b5fce97b  movq xmm14, qword ptr [r15+0x1C0]
00007aa9b5fce984  movq xmm13, qword ptr [r15+0x1B0]
00007aa9b5fce98d  movq r12, xmm14
00007aa9b5fce992  movq r11, xmm13
00007aa9b5fce997  mov [r13+rax*1], r12
00007aa9b5fce99c  lea rax, [r14+0x1A8]
00007aa9b5fce9a3  mov [r13+rax*1], r11
00007aa9b5fce9a8  lea rax, [r14+0x1B0]
00007aa9b5fce9af  movq xmm14, qword ptr [r15+0x1A0]
00007aa9b5fce9b8  movq xmm13, qword ptr [r15+0x190]
00007aa9b5fce9c1  movq r12, xmm14
00007aa9b5fce9c6  movq r11, xmm13
00007aa9b5fce9cb  mov [r13+rax*1], r12
00007aa9b5fce9d0  lea rax, [r14+0x1B8]
00007aa9b5fce9d7  mov [r13+rax*1], r11
00007aa9b5fce9dc  lea rax, [r14+0x100]
00007aa9b5fce9e3  movups [r13+rax*1], xmm1
00007aa9b5fce9e9  lea rax, [r14+0x110]
00007aa9b5fce9f0  movups [r13+rax*1], xmm15
00007aa9b5fce9f6  mov eax, 0x420B40
00007aa9b5fce9fb  movups xmm1, [r13+rax*1]
00007aa9b5fcea01  mov eax, 0x420B50
00007aa9b5fcea06  movups xmm15, [r13+rax*1]
00007aa9b5fcea0c  movaps [r15+0x110], xmm1
00007aa9b5fcea14  movaps [r15+0x130], xmm15
00007aa9b5fcea1c  lea rax, [r14+0x1C0]
00007aa9b5fcea23  mov r12, [r15+0xE8]
00007aa9b5fcea2a  mov r11, [r15+0xF0]
00007aa9b5fcea31  mov [r13+rax*1], r12
00007aa9b5fcea36  lea rax, [r14+0x1C8]
00007aa9b5fcea3d  mov [r13+rax*1], r11
00007aa9b5fcea42  mov eax, 0x430DF8
00007aa9b5fcea47  mov r12d, 0x421DF8D3
00007aa9b5fcea4d  mov [r13+rax*1], r12d
00007aa9b5fcea52  lea rax, [r14+0x120]
00007aa9b5fcea59  movups [r13+rax*1], xmm1
00007aa9b5fcea5f  lea rax, [r14+0x130]
00007aa9b5fcea66  movups [r13+rax*1], xmm15
00007aa9b5fcea6c  lea rax, [r14+0x100]
00007aa9b5fcea73  mov [r15], rax
00007aa9b5fcea76  mov qword ptr [r15+0x08], 0x430CD0
00007aa9b5fcea7e  mov qword ptr [r15+0x10], 0x12C
00007aa9b5fcea86  mov qword ptr [r15+0xF0], 0x410284
00007aa9b5fcea91  mov r14d, [r15+0x320]
00007aa9b5fcea98  mov eax, 0x410284
00007aa9b5fcea9d  mov rcx, 0x7AA9B5FD07C0
00007aa9b5fceaa7  mov [r15+r14*8+0x328], rax
00007aa9b5fceaaf  mov [r15+r14*8+0x368], rcx
00007aa9b5fceab7  add r14d, 0x01
00007aa9b5fceabb  and r14d, 0x07
00007aa9b5fceabf  mov [r15+0x320], r14d
00007aa9b5fceac6  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fceace  jz 0x00007AA9B5FCED70
00007aa9b5fcead4  nop [rax+rax*1], ax
00007aa9b5fceadd  nop [rax+rax*1], eax
00007aa9b5fceae5  mov eax, 0x410728
00007aa9b5fceaea  mov [r15+0x100], rax
00007aa9b5fceaf1  jmp 0x00007AA9B5DFE110
00007aa9b5fceaf6  int3
00007aa9b5fceaf7  call 0x00007AA9B5E0BC20
00007aa9b5fceafc  jmp 0x00007AA9B5FCE6CF
00007aa9b5fceb01  call 0x00007AA9B5E0A9A0
00007aa9b5fceb06  jmp 0x00007AA9B5FCE6DB
00007aa9b5fceb0b  call 0x00007AA9B5DFF430
00007aa9b5fceb10  jmp 0x00007AA9B5FCE6E6
00007aa9b5fceb15  call 0x00007AA9B5E0E760
00007aa9b5fceb1a  jmp 0x00007AA9B5FCE6F1
00007aa9b5fceb1f  call 0x00007AA9B5E0D4E0
00007aa9b5fceb24  jmp 0x00007AA9B5FCE6FC
00007aa9b5fceb29  call 0x00007AA9B5E0C260
00007aa9b5fceb2e  jmp 0x00007AA9B5FCE707
00007aa9b5fceb33  call 0x00007AA9B5E0AFE0
00007aa9b5fceb38  jmp 0x00007AA9B5FCE71D
00007aa9b5fceb3d  call 0x00007AA9B5DFF540
00007aa9b5fceb42  jmp 0x00007AA9B5FCE728
00007aa9b5fceb47  call 0x00007AA9B5E0E880
00007aa9b5fceb4c  jmp 0x00007AA9B5FCE733
00007aa9b5fceb51  call 0x00007AA9B5E0D600
00007aa9b5fceb56  jmp 0x00007AA9B5FCE73E
00007aa9b5fceb5b  call 0x00007AA9B5E0C380
00007aa9b5fceb60  jmp 0x00007AA9B5FCE749
00007aa9b5fceb65  call 0x00007AA9B5E0D4E0
00007aa9b5fceb6a  jmp 0x00007AA9B5FCE754
00007aa9b5fceb6f  call 0x00007AA9B5E0C260
00007aa9b5fceb74  jmp 0x00007AA9B5FCE75F
00007aa9b5fceb79  call 0x00007AA9B5DFF540
00007aa9b5fceb7e  jmp 0x00007AA9B5FCE76A
00007aa9b5fceb83  call 0x00007AA9B5E0E880
00007aa9b5fceb88  jmp 0x00007AA9B5FCE775
00007aa9b5fceb8d  call 0x00007AA9B5E0B100
00007aa9b5fceb92  jmp 0x00007AA9B5FCE780
00007aa9b5fceb97  call 0x00007AA9B5E0D600
00007aa9b5fceb9c  jmp 0x00007AA9B5FCE78B
00007aa9b5fceba1  call 0x00007AA9B5DFF430
00007aa9b5fceba6  jmp 0x00007AA9B5FCE796
00007aa9b5fcebab  call 0x00007AA9B5E0E760
00007aa9b5fcebb0  jmp 0x00007AA9B5FCE7A1
00007aa9b5fcebb5  call 0x00007AA9B5E0C380
00007aa9b5fcebba  jmp 0x00007AA9B5FCE7AC
00007aa9b5fcebbf  call 0x00007AA9B5DFF540
00007aa9b5fcebc4  jmp 0x00007AA9B5FCE7B7
00007aa9b5fcebc9  call 0x00007AA9B5DFF430
00007aa9b5fcebce  jmp 0x00007AA9B5FCE7C2
00007aa9b5fcebd3  call 0x00007AA9B5E0D4E0
00007aa9b5fcebd8  jmp 0x00007AA9B5FCE7CD
00007aa9b5fcebdd  call 0x00007AA9B5E0E880
00007aa9b5fcebe2  jmp 0x00007AA9B5FCE7E0
00007aa9b5fcebe7  call 0x00007AA9B5DFF540
00007aa9b5fcebec  jmp 0x00007AA9B5FCE7EB
00007aa9b5fcebf1  call 0x00007AA9B5DFF430
00007aa9b5fcebf6  jmp 0x00007AA9B5FCE7F6
00007aa9b5fcebfb  call 0x00007AA9B5E0E760
00007aa9b5fcec00  jmp 0x00007AA9B5FCE801
00007aa9b5fcec05  call 0x00007AA9B5E0D600
00007aa9b5fcec0a  jmp 0x00007AA9B5FCE81F
00007aa9b5fcec0f  call 0x00007AA9B5DFF540
00007aa9b5fcec14  jmp 0x00007AA9B5FCE82A
00007aa9b5fcec19  call 0x00007AA9B5DFF430
00007aa9b5fcec1e  jmp 0x00007AA9B5FCE835
00007aa9b5fcec23  call 0x00007AA9B5E0D4E0
00007aa9b5fcec28  jmp 0x00007AA9B5FCE840
00007aa9b5fcec2d  call 0x00007AA9B5E0BC20
00007aa9b5fcec32  jmp 0x00007AA9B5FCE870
00007aa9b5fcec37  call 0x00007AA9B5E0A9A0
00007aa9b5fcec3c  jmp 0x00007AA9B5FCE87C
00007aa9b5fcec41  call 0x00007AA9B5E0E880
00007aa9b5fcec46  jmp 0x00007AA9B5FCE887
00007aa9b5fcec4b  call 0x00007AA9B5DFF540
00007aa9b5fcec50  jmp 0x00007AA9B5FCE892
00007aa9b5fcec55  call 0x00007AA9B5DFF430
00007aa9b5fcec5a  jmp 0x00007AA9B5FCE89D
00007aa9b5fcec5f  call 0x00007AA9B5E0B720
00007aa9b5fcec64  jmp 0x00007AA9B5FCE8A7
00007aa9b5fcec69  call 0x00007AA9B5E0D600
00007aa9b5fcec6e  jmp 0x00007AA9B5FCE8BF
00007aa9b5fcec73  call 0x00007AA9B5DFF540
00007aa9b5fcec78  jmp 0x00007AA9B5FCE8CA
00007aa9b5fcec7d  call 0x00007AA9B5DFF430
00007aa9b5fcec82  jmp 0x00007AA9B5FCE8D5
00007aa9b5fcec87  call 0x00007AA9B5EB4CB0
00007aa9b5fcec8c  jmp 0x00007AA9B5FCE8E5
00007aa9b5fcec91  call 0x00007AA9B5E0E760
00007aa9b5fcec96  jmp 0x00007AA9B5FCE8F0
00007aa9b5fcec9b  call 0x00007AA9B5E0D4E0
00007aa9b5fceca0  jmp 0x00007AA9B5FCE8FB
00007aa9b5fceca5  call 0x00007AA9B5DFF540
00007aa9b5fcecaa  jmp 0x00007AA9B5FCE908
00007aa9b5fcecaf  call 0x00007AA9B5E0BC20
00007aa9b5fcecb4  jmp 0x00007AA9B5FCE930
00007aa9b5fcecb9  call 0x00007AA9B5E0A9A0
00007aa9b5fcecbe  jmp 0x00007AA9B5FCE93C
00007aa9b5fcecc3  call 0x00007AA9B5E0E880
00007aa9b5fcecc8  jmp 0x00007AA9B5FCE949
00007aa9b5fceccd  call 0x00007AA9B5E0D600
00007aa9b5fcecd2  jmp 0x00007AA9B5FCE956
00007aa9b5fcecd7  call 0x00007AA9B5DFF430
00007aa9b5fcecdc  jmp 0x00007AA9B5FCE961
00007aa9b5fcece1  call 0x00007AA9B5E0E760
00007aa9b5fcece6  jmp 0x00007AA9B5FCE96C
00007aa9b5fceceb  call 0x00007AA9B5E0BC20
00007aa9b5fcecf0  jmp 0x00007AA9B5FCE99C
00007aa9b5fcecf5  call 0x00007AA9B5E0A9A0
00007aa9b5fcecfa  jmp 0x00007AA9B5FCE9A8
00007aa9b5fcecff  call 0x00007AA9B5E0BC20
00007aa9b5fced04  jmp 0x00007AA9B5FCE9D0
00007aa9b5fced09  call 0x00007AA9B5E0A9A0
00007aa9b5fced0e  jmp 0x00007AA9B5FCE9DC
00007aa9b5fced13  call 0x00007AA9B5DFF540
00007aa9b5fced18  jmp 0x00007AA9B5FCE9E9
00007aa9b5fced1d  call 0x00007AA9B5E0E880
00007aa9b5fced22  jmp 0x00007AA9B5FCE9F6
00007aa9b5fced27  call 0x00007AA9B5DFF430
00007aa9b5fced2c  jmp 0x00007AA9B5FCEA01
00007aa9b5fced31  call 0x00007AA9B5E0E760
00007aa9b5fced36  jmp 0x00007AA9B5FCEA0C
00007aa9b5fced3b  call 0x00007AA9B5E0BC20
00007aa9b5fced40  jmp 0x00007AA9B5FCEA36
00007aa9b5fced45  call 0x00007AA9B5E0A9A0
00007aa9b5fced4a  jmp 0x00007AA9B5FCEA42
00007aa9b5fced4f  call 0x00007AA9B5E0BAE0
00007aa9b5fced54  jmp 0x00007AA9B5FCEA52
00007aa9b5fced59  call 0x00007AA9B5DFF540
00007aa9b5fced5e  jmp 0x00007AA9B5FCEA5F
00007aa9b5fced63  call 0x00007AA9B5E0E880
00007aa9b5fced68  jmp 0x00007AA9B5FCEA6C
00007aa9b5fced6d  int3
00007aa9b5fced6e  nop
00007aa9b5fced70  mov rax, [r15]
00007aa9b5fced73  lea r14, [rax+0x20]
00007aa9b5fced77  mov r12, [r13+r14*1]
00007aa9b5fced7c  mov r14, [r15+0x10]
00007aa9b5fced80  lea r11, [r12+r14*1]
00007aa9b5fced84  mov [r15+0x40], r11
00007aa9b5fced88  lea r12, [rax+0x20]
00007aa9b5fced8c  mov [r13+r12*1], r11
00007aa9b5fced91  test r14, r14
00007aa9b5fced94  setz r14b
00007aa9b5fced98  movzx r14, r14b
00007aa9b5fced9c  mov [rsp+0x414], r14b
00007aa9b5fceda4  cmp byte ptr [rsp+0x414], 0x00
00007aa9b5fcedac  jz 0x00007AA9B5FCEDDE
00007aa9b5fcedae  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcedb6  mov eax, 0x4109A0
00007aa9b5fcedbb  mov [r15+0x100], rax
00007aa9b5fcedc2  jz 0x00007AA9B5DFE0A0
00007aa9b5fcedc8  nop [rax+rax*1], eax
00007aa9b5fcedcd  mov eax, 0x4109A0
00007aa9b5fcedd2  mov [r15+0x100], rax
00007aa9b5fcedd9  jmp 0x00007AA9B5DFE110
00007aa9b5fcedde  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcede6  jz 0x00007AA9B5FCEE30
00007aa9b5fcedec  nop [rax+rax*1], ax
00007aa9b5fcedf5  nop [rax+rax*1], eax
00007aa9b5fcedfd  mov eax, 0x410738
00007aa9b5fcee02  mov [r15+0x100], rax
00007aa9b5fcee09  jmp 0x00007AA9B5DFE110
00007aa9b5fcee0e  int3
00007aa9b5fcee0f  call 0x00007AA9B5EE27E0
00007aa9b5fcee14  jmp 0x00007AA9B5FCED7C
00007aa9b5fcee19  call 0x00007AA9B5EC0860
00007aa9b5fcee1e  jmp 0x00007AA9B5FCED91
00007aa9b5fcee23  int3
00007aa9b5fcee24  nop [rax+rax*1], ax
00007aa9b5fcee2d  nop [rax], eax
00007aa9b5fcee30  mov rax, [r15+0xF8]
00007aa9b5fcee37  lea r14, [rax-0x150]
00007aa9b5fcee3e  mov [r15+0xF8], r14
00007aa9b5fcee45  mov rax, [r15]
00007aa9b5fcee48  lea r12, [rax+0x68]
00007aa9b5fcee4c  mov r11, [r13+r12*1]
00007aa9b5fcee51  mov [r15+0x88], r11
00007aa9b5fcee58  lea r12, [rax+0x28]
00007aa9b5fcee5c  mov [r15+0x40], r12
00007aa9b5fcee60  mov [r15+0x48], r14
00007aa9b5fcee64  mov qword ptr [r15+0x50], 0x420B90
00007aa9b5fcee6c  lea rax, [r14+0x100]
00007aa9b5fcee73  mov r12, [r15+0xE8]
00007aa9b5fcee7a  mov r11, [r15+0xD8]
00007aa9b5fcee81  mov [r13+rax*1], r12
00007aa9b5fcee86  lea rax, [r14+0x108]
00007aa9b5fcee8d  mov [r13+rax*1], r11
00007aa9b5fcee92  lea rax, [r14+0x110]
00007aa9b5fcee99  mov r12, [r15+0xD0]
00007aa9b5fceea0  mov r11, [r15+0xC8]
00007aa9b5fceea7  mov [r13+rax*1], r12
00007aa9b5fceeac  lea rax, [r14+0x118]
00007aa9b5fceeb3  mov [r13+rax*1], r11
00007aa9b5fceeb8  lea rax, [r14+0x120]
00007aa9b5fceebf  mov r12, [r15+0xC0]
00007aa9b5fceec6  mov r11, [r15+0xB8]
00007aa9b5fceecd  mov [r13+rax*1], r12
00007aa9b5fceed2  lea rax, [r14+0x128]
00007aa9b5fceed9  mov [r13+rax*1], r11
00007aa9b5fceede  lea rax, [r14+0x130]
00007aa9b5fceee5  mov r12, [r15+0xB0]
00007aa9b5fceeec  mov r11, [r15+0xA8]
00007aa9b5fceef3  mov [r13+rax*1], r12
00007aa9b5fceef8  lea rax, [r14+0x138]
00007aa9b5fceeff  mov [r13+rax*1], r11
00007aa9b5fcef04  lea rax, [r14+0x140]
00007aa9b5fcef0b  mov r12, [r15+0xA0]
00007aa9b5fcef12  mov r11, [r15+0x98]
00007aa9b5fcef19  mov [r13+rax*1], r12
00007aa9b5fcef1e  lea rax, [r14+0x148]
00007aa9b5fcef25  mov [r13+rax*1], r11
00007aa9b5fcef2a  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcef32  jz 0x00007AA9B5FCEFD0
00007aa9b5fcef38  nop [rax+rax*1], ax
00007aa9b5fcef41  nop [rax+rax*1], eax
00007aa9b5fcef49  mov eax, 0x410770
00007aa9b5fcef4e  mov [r15+0x100], rax
00007aa9b5fcef55  jmp 0x00007AA9B5DFE110
00007aa9b5fcef5a  int3
00007aa9b5fcef5b  call 0x00007AA9B5EC0370
00007aa9b5fcef60  jmp 0x00007AA9B5FCEE51
00007aa9b5fcef65  call 0x00007AA9B5E0BC20
00007aa9b5fcef6a  jmp 0x00007AA9B5FCEE86
00007aa9b5fcef6f  call 0x00007AA9B5E0A9A0
00007aa9b5fcef74  jmp 0x00007AA9B5FCEE92
00007aa9b5fcef79  call 0x00007AA9B5E0BC20
00007aa9b5fcef7e  jmp 0x00007AA9B5FCEEAC
00007aa9b5fcef83  call 0x00007AA9B5E0A9A0
00007aa9b5fcef88  jmp 0x00007AA9B5FCEEB8
00007aa9b5fcef8d  call 0x00007AA9B5E0BC20
00007aa9b5fcef92  jmp 0x00007AA9B5FCEED2
00007aa9b5fcef97  call 0x00007AA9B5E0A9A0
00007aa9b5fcef9c  jmp 0x00007AA9B5FCEEDE
00007aa9b5fcefa1  call 0x00007AA9B5E0BC20
00007aa9b5fcefa6  jmp 0x00007AA9B5FCEEF8
00007aa9b5fcefab  call 0x00007AA9B5E0A9A0
00007aa9b5fcefb0  jmp 0x00007AA9B5FCEF04
00007aa9b5fcefb5  call 0x00007AA9B5E0BC20
00007aa9b5fcefba  jmp 0x00007AA9B5FCEF1E
00007aa9b5fcefbf  call 0x00007AA9B5E0A9A0
00007aa9b5fcefc4  jmp 0x00007AA9B5FCEF2A
00007aa9b5fcefc9  int3
00007aa9b5fcefca  nop [rax+rax*1], ax
00007aa9b5fcefd0  mov rax, [r15+0x08]
00007aa9b5fcefd4  movzx r14d, byte ptr [r13+rax*1]
00007aa9b5fcefda  movzx r14d, r14b
00007aa9b5fcefde  mov [rsp+0x10], r14d
00007aa9b5fcefe3  mov r14d, r14d
00007aa9b5fcefe6  mov [r15+0x58], r14
00007aa9b5fcefea  lea r14, [rax+0x01]
00007aa9b5fcefee  mov [r15+0x08], r14
00007aa9b5fceff2  mov rax, [r15+0x88]
00007aa9b5fceff9  lea r14, [rax+0x01]
00007aa9b5fceffd  mov r12, [r15]
00007aa9b5fcf000  lea r11, [r12+0x68]
00007aa9b5fcf005  mov [r13+r11*1], r14
00007aa9b5fcf00a  lea r14, [r12+rax*1]
00007aa9b5fcf00e  mov [r15+0x60], r14
00007aa9b5fcf012  lea rax, [r14+0x28]
00007aa9b5fcf016  mov r11d, [rsp+0x10]
00007aa9b5fcf01b  movzx r14d, r11b
00007aa9b5fcf01f  mov [r13+rax*1], r14b
00007aa9b5fcf024  lea rax, [r12+0x68]
00007aa9b5fcf029  mov r14, [r13+rax*1]
00007aa9b5fcf02e  mov [r15+0x88], r14
00007aa9b5fcf035  xor eax, eax
00007aa9b5fcf037  mov r12d, 0x40
00007aa9b5fcf03d  cmp r14, r12
00007aa9b5fcf040  cmc
00007aa9b5fcf041  lahf
00007aa9b5fcf042  seto al
00007aa9b5fcf045  mov [r15+0x108], eax
00007aa9b5fcf04c  mov eax, [r15+0x108]
00007aa9b5fcf053  sahf
00007aa9b5fcf054  jnz 0x00007AA9B5FCF086
00007aa9b5fcf056  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcf05e  jz 0x00007AA9B5FCF170
00007aa9b5fcf064  nop [rax+rax*1], ax
00007aa9b5fcf06d  nop [rax+rax*1], eax
00007aa9b5fcf075  mov eax, 0x410790
00007aa9b5fcf07a  mov [r15+0x100], rax
00007aa9b5fcf081  jmp 0x00007AA9B5DFE110
00007aa9b5fcf086  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcf08e  jz 0x00007AA9B5FCF0E0
00007aa9b5fcf094  nop [rax+rax*1], ax
00007aa9b5fcf09d  nop [rax+rax*1], eax
00007aa9b5fcf0a5  mov eax, 0x410768
00007aa9b5fcf0aa  mov [r15+0x100], rax
00007aa9b5fcf0b1  jmp 0x00007AA9B5DFE110
00007aa9b5fcf0b6  int3
00007aa9b5fcf0b7  call 0x00007AA9B5E0D860
00007aa9b5fcf0bc  jmp 0x00007AA9B5FCEFDA
00007aa9b5fcf0c1  call 0x00007AA9B5EB36E0
00007aa9b5fcf0c6  jmp 0x00007AA9B5FCF00A
00007aa9b5fcf0cb  call 0x00007AA9B5E0DD60
00007aa9b5fcf0d0  jmp 0x00007AA9B5FCF024
00007aa9b5fcf0d5  call 0x00007AA9B5E0DC20
00007aa9b5fcf0da  jmp 0x00007AA9B5FCF02E
00007aa9b5fcf0df  int3
00007aa9b5fcf0e0  mov rax, [r15+0x10]
00007aa9b5fcf0e4  lea r14, [rax-0x01]
00007aa9b5fcf0e8  mov [r15+0x10], r14
00007aa9b5fcf0ec  test r14, r14
00007aa9b5fcf0ef  setz r14b
00007aa9b5fcf0f3  movzx r14, r14b
00007aa9b5fcf0f7  mov [rsp+0x414], r14b
00007aa9b5fcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007aa9b5fcf107  jz 0x00007AA9B5FCF139
00007aa9b5fcf109  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcf111  jz 0x00007AA9B5FD0670
00007aa9b5fcf117  nop [rax+rax*1], ax
00007aa9b5fcf120  nop [rax+rax*1], eax
00007aa9b5fcf128  mov eax, 0x410988
00007aa9b5fcf12d  mov [r15+0x100], rax
00007aa9b5fcf134  jmp 0x00007AA9B5DFE110
00007aa9b5fcf139  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcf141  jz 0x00007AA9B5FCEFD0
00007aa9b5fcf147  nop [rax+rax*1], ax
00007aa9b5fcf150  nop [rax+rax*1], eax
00007aa9b5fcf158  mov eax, 0x410770
00007aa9b5fcf15d  mov [r15+0x100], rax
00007aa9b5fcf164  jmp 0x00007AA9B5DFE110
00007aa9b5fcf169  int3
00007aa9b5fcf16a  int3
00007aa9b5fcf16b  nop [rax+rax*1], eax
00007aa9b5fcf170  mov rax, [r15+0x40]
00007aa9b5fcf174  movzx r14d, byte ptr [r13+rax*1]
00007aa9b5fcf17a  movaps xmm1, [r15+0x110]
00007aa9b5fcf182  pinsrb xmm1, r14d, 0x00
00007aa9b5fcf189  lea r14, [rax+0x01]
00007aa9b5fcf18d  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf193  movaps xmm15, [r15+0x120]
00007aa9b5fcf19b  pinsrb xmm15, r12d, 0x00
00007aa9b5fcf1a2  lea r14, [rax+0x02]
00007aa9b5fcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf1ac  movaps xmm14, [r15+0x130]
00007aa9b5fcf1b4  pinsrb xmm14, r12d, 0x00
00007aa9b5fcf1bb  lea r14, [rax+0x03]
00007aa9b5fcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf1c5  movaps xmm13, [r15+0x140]
00007aa9b5fcf1cd  pinsrb xmm13, r12d, 0x00
00007aa9b5fcf1d4  lea r14, [rax+0x04]
00007aa9b5fcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf1de  pinsrb xmm1, r12d, 0x01
00007aa9b5fcf1e5  lea r14, [rax+0x05]
00007aa9b5fcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf1ef  pinsrb xmm15, r12d, 0x01
00007aa9b5fcf1f6  lea r14, [rax+0x06]
00007aa9b5fcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf200  pinsrb xmm14, r12d, 0x01
00007aa9b5fcf207  lea r14, [rax+0x07]
00007aa9b5fcf20b  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf211  pinsrb xmm13, r12d, 0x01
00007aa9b5fcf218  lea r14, [rax+0x08]
00007aa9b5fcf21c  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf222  pinsrb xmm1, r12d, 0x02
00007aa9b5fcf229  lea r14, [rax+0x09]
00007aa9b5fcf22d  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf233  pinsrb xmm15, r12d, 0x02
00007aa9b5fcf23a  lea r14, [rax+0x0A]
00007aa9b5fcf23e  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf244  pinsrb xmm14, r12d, 0x02
00007aa9b5fcf24b  lea r14, [rax+0x0B]
00007aa9b5fcf24f  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf255  pinsrb xmm13, r12d, 0x02
00007aa9b5fcf25c  lea r14, [rax+0x0C]
00007aa9b5fcf260  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf266  pinsrb xmm1, r12d, 0x03
00007aa9b5fcf26d  lea r14, [rax+0x0D]
00007aa9b5fcf271  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf277  pinsrb xmm15, r12d, 0x03
00007aa9b5fcf27e  lea r14, [rax+0x0E]
00007aa9b5fcf282  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf288  pinsrb xmm14, r12d, 0x03
00007aa9b5fcf28f  lea r14, [rax+0x0F]
00007aa9b5fcf293  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf299  pinsrb xmm13, r12d, 0x03
00007aa9b5fcf2a0  lea r14, [rax+0x10]
00007aa9b5fcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf2aa  pinsrb xmm1, r12d, 0x04
00007aa9b5fcf2b1  lea r14, [rax+0x11]
00007aa9b5fcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf2bb  pinsrb xmm15, r12d, 0x04
00007aa9b5fcf2c2  lea r14, [rax+0x12]
00007aa9b5fcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf2cc  pinsrb xmm14, r12d, 0x04
00007aa9b5fcf2d3  lea r14, [rax+0x13]
00007aa9b5fcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf2dd  pinsrb xmm13, r12d, 0x04
00007aa9b5fcf2e4  lea r14, [rax+0x14]
00007aa9b5fcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf2ee  pinsrb xmm1, r12d, 0x05
00007aa9b5fcf2f5  lea r14, [rax+0x15]
00007aa9b5fcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf2ff  pinsrb xmm15, r12d, 0x05
00007aa9b5fcf306  lea r14, [rax+0x16]
00007aa9b5fcf30a  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf310  pinsrb xmm14, r12d, 0x05
00007aa9b5fcf317  lea r14, [rax+0x17]
00007aa9b5fcf31b  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf321  pinsrb xmm13, r12d, 0x05
00007aa9b5fcf328  lea r14, [rax+0x18]
00007aa9b5fcf32c  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf332  pinsrb xmm1, r12d, 0x06
00007aa9b5fcf339  lea r14, [rax+0x19]
00007aa9b5fcf33d  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf343  pinsrb xmm15, r12d, 0x06
00007aa9b5fcf34a  lea r14, [rax+0x1A]
00007aa9b5fcf34e  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf354  pinsrb xmm14, r12d, 0x06
00007aa9b5fcf35b  lea r14, [rax+0x1B]
00007aa9b5fcf35f  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf365  pinsrb xmm13, r12d, 0x06
00007aa9b5fcf36c  lea r14, [rax+0x1C]
00007aa9b5fcf370  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf376  pinsrb xmm1, r12d, 0x07
00007aa9b5fcf37d  lea r14, [rax+0x1D]
00007aa9b5fcf381  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf387  pinsrb xmm15, r12d, 0x07
00007aa9b5fcf38e  lea r14, [rax+0x1E]
00007aa9b5fcf392  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf398  pinsrb xmm14, r12d, 0x07
00007aa9b5fcf39f  lea r14, [rax+0x1F]
00007aa9b5fcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf3a9  pinsrb xmm13, r12d, 0x07
00007aa9b5fcf3b0  lea r14, [rax+0x20]
00007aa9b5fcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf3ba  pinsrb xmm1, r12d, 0x08
00007aa9b5fcf3c1  lea r14, [rax+0x21]
00007aa9b5fcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf3cb  pinsrb xmm15, r12d, 0x08
00007aa9b5fcf3d2  lea r14, [rax+0x22]
00007aa9b5fcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf3dc  pinsrb xmm14, r12d, 0x08
00007aa9b5fcf3e3  lea r14, [rax+0x23]
00007aa9b5fcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf3ed  pinsrb xmm13, r12d, 0x08
00007aa9b5fcf3f4  lea r14, [rax+0x24]
00007aa9b5fcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf3fe  pinsrb xmm1, r12d, 0x09
00007aa9b5fcf405  lea r14, [rax+0x25]
00007aa9b5fcf409  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf40f  pinsrb xmm15, r12d, 0x09
00007aa9b5fcf416  lea r14, [rax+0x26]
00007aa9b5fcf41a  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf420  pinsrb xmm14, r12d, 0x09
00007aa9b5fcf427  lea r14, [rax+0x27]
00007aa9b5fcf42b  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf431  pinsrb xmm13, r12d, 0x09
00007aa9b5fcf438  lea r14, [rax+0x28]
00007aa9b5fcf43c  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf442  pinsrb xmm1, r12d, 0x0A
00007aa9b5fcf449  lea r14, [rax+0x29]
00007aa9b5fcf44d  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf453  pinsrb xmm15, r12d, 0x0A
00007aa9b5fcf45a  lea r14, [rax+0x2A]
00007aa9b5fcf45e  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf464  pinsrb xmm14, r12d, 0x0A
00007aa9b5fcf46b  lea r14, [rax+0x2B]
00007aa9b5fcf46f  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf475  pinsrb xmm13, r12d, 0x0A
00007aa9b5fcf47c  lea r14, [rax+0x2C]
00007aa9b5fcf480  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf486  pinsrb xmm1, r12d, 0x0B
00007aa9b5fcf48d  lea r14, [rax+0x2D]
00007aa9b5fcf491  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf497  pinsrb xmm15, r12d, 0x0B
00007aa9b5fcf49e  lea r14, [rax+0x2E]
00007aa9b5fcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf4a8  pinsrb xmm14, r12d, 0x0B
00007aa9b5fcf4af  lea r14, [rax+0x2F]
00007aa9b5fcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf4b9  pinsrb xmm13, r12d, 0x0B
00007aa9b5fcf4c0  lea r14, [rax+0x30]
00007aa9b5fcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf4ca  pinsrb xmm1, r12d, 0x0C
00007aa9b5fcf4d1  lea r14, [rax+0x31]
00007aa9b5fcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf4db  pinsrb xmm15, r12d, 0x0C
00007aa9b5fcf4e2  lea r14, [rax+0x32]
00007aa9b5fcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf4ec  pinsrb xmm14, r12d, 0x0C
00007aa9b5fcf4f3  lea r14, [rax+0x33]
00007aa9b5fcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf4fd  pinsrb xmm13, r12d, 0x0C
00007aa9b5fcf504  lea r14, [rax+0x34]
00007aa9b5fcf508  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf50e  pinsrb xmm1, r12d, 0x0D
00007aa9b5fcf515  lea r14, [rax+0x35]
00007aa9b5fcf519  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf51f  pinsrb xmm15, r12d, 0x0D
00007aa9b5fcf526  lea r14, [rax+0x36]
00007aa9b5fcf52a  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf530  pinsrb xmm14, r12d, 0x0D
00007aa9b5fcf537  lea r14, [rax+0x37]
00007aa9b5fcf53b  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf541  pinsrb xmm13, r12d, 0x0D
00007aa9b5fcf548  lea r14, [rax+0x38]
00007aa9b5fcf54c  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf552  pinsrb xmm1, r12d, 0x0E
00007aa9b5fcf559  lea r14, [rax+0x39]
00007aa9b5fcf55d  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf563  pinsrb xmm15, r12d, 0x0E
00007aa9b5fcf56a  lea r14, [rax+0x3A]
00007aa9b5fcf56e  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf574  pinsrb xmm14, r12d, 0x0E
00007aa9b5fcf57b  lea r14, [rax+0x3B]
00007aa9b5fcf57f  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf585  pinsrb xmm13, r12d, 0x0E
00007aa9b5fcf58c  lea r14, [rax+0x3C]
00007aa9b5fcf590  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf596  pinsrb xmm1, r12d, 0x0F
00007aa9b5fcf59d  movaps [r15+0x110], xmm1
00007aa9b5fcf5a5  lea r14, [rax+0x3D]
00007aa9b5fcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf5af  pinsrb xmm15, r12d, 0x0F
00007aa9b5fcf5b6  movaps [r15+0x120], xmm15
00007aa9b5fcf5be  lea r14, [rax+0x3E]
00007aa9b5fcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007aa9b5fcf5c8  pinsrb xmm14, r12d, 0x0F
00007aa9b5fcf5cf  movaps [r15+0x130], xmm14
00007aa9b5fcf5d7  lea r14, [rax+0x3F]
00007aa9b5fcf5db  movzx eax, byte ptr [r13+r14*1]
00007aa9b5fcf5e1  pinsrb xmm13, eax, 0x0F
00007aa9b5fcf5e8  movaps [r15+0x140], xmm13
00007aa9b5fcf5f0  movq xmm1, qword ptr [r15+0x120]
00007aa9b5fcf5f9  pmovzxbw xmm1, xmm1
00007aa9b5fcf5fe  psllw xmm1, 0x00
00007aa9b5fcf603  movaps [r15+0x150], xmm1
00007aa9b5fcf60b  movq xmm1, qword ptr [r15+0x130]
00007aa9b5fcf614  pmovzxbw xmm1, xmm1
00007aa9b5fcf619  psllw xmm1, 0x00
00007aa9b5fcf61e  movaps [r15+0x160], xmm1
00007aa9b5fcf626  movq xmm1, qword ptr [r15+0x110]
00007aa9b5fcf62f  pmovzxbw xmm1, xmm1
00007aa9b5fcf634  psllw xmm1, 0x00
00007aa9b5fcf639  movaps [r15+0x170], xmm1
00007aa9b5fcf641  movaps xmm15, [r15+0x110]
00007aa9b5fcf649  pextrq rax, xmm15, 0x01
00007aa9b5fcf650  movq xmm15, rax
00007aa9b5fcf655  pmovzxbw xmm15, xmm15
00007aa9b5fcf65b  psllw xmm15, 0x00
00007aa9b5fcf661  movaps [r15+0x180], xmm15
00007aa9b5fcf669  movaps xmm14, [r15+0x120]
00007aa9b5fcf671  pextrq rax, xmm14, 0x01
00007aa9b5fcf678  movq xmm14, rax
00007aa9b5fcf67d  pmovzxbw xmm14, xmm14
00007aa9b5fcf683  psllw xmm14, 0x00
00007aa9b5fcf689  movaps [r15+0x210], xmm14
00007aa9b5fcf691  movaps xmm13, [r15+0x130]
00007aa9b5fcf699  pextrq rax, xmm13, 0x01
00007aa9b5fcf6a0  movq xmm13, rax
00007aa9b5fcf6a5  pmovzxbw xmm13, xmm13
00007aa9b5fcf6ab  psllw xmm13, 0x00
00007aa9b5fcf6b1  movaps [r15+0x220], xmm13
00007aa9b5fcf6b9  movq xmm12, qword ptr [r15+0x140]
00007aa9b5fcf6c2  pmovzxbw xmm12, xmm12
00007aa9b5fcf6c8  psllw xmm12, 0x00
00007aa9b5fcf6ce  movaps [r15+0x250], xmm12
00007aa9b5fcf6d6  movaps xmm12, [r15+0x140]
00007aa9b5fcf6de  pextrq rax, xmm12, 0x01
00007aa9b5fcf6e5  movq xmm12, rax
00007aa9b5fcf6ea  pmovzxbw xmm12, xmm12
00007aa9b5fcf6f0  psllw xmm12, 0x00
00007aa9b5fcf6f6  movaps [r15+0x110], xmm12
00007aa9b5fcf6fe  movq xmm11, qword ptr [r15+0x150]
00007aa9b5fcf707  pmovzxwd xmm11, xmm11
00007aa9b5fcf70d  pslld xmm11, 0x10
00007aa9b5fcf713  movq xmm10, qword ptr [r15+0x160]
00007aa9b5fcf71c  pmovzxwd xmm10, xmm10
00007aa9b5fcf722  pslld xmm10, 0x08
00007aa9b5fcf728  pextrq rax, xmm1, 0x01
00007aa9b5fcf72f  movq xmm1, rax
00007aa9b5fcf734  pmovzxwd xmm1, xmm1
00007aa9b5fcf739  pslld xmm1, 0x00
00007aa9b5fcf73e  movaps [r15+0x260], xmm1
00007aa9b5fcf746  pextrq rax, xmm15, 0x01
00007aa9b5fcf74d  movq xmm15, rax
00007aa9b5fcf752  pmovzxwd xmm15, xmm15
00007aa9b5fcf758  pslld xmm15, 0x00
00007aa9b5fcf75e  movaps [r15+0x270], xmm15
00007aa9b5fcf766  movq xmm9, qword ptr [r15+0x170]
00007aa9b5fcf76f  pmovzxwd xmm9, xmm9
00007aa9b5fcf775  pslld xmm9, 0x00
00007aa9b5fcf77b  pextrq rax, xmm14, 0x01
00007aa9b5fcf782  movq xmm14, rax
00007aa9b5fcf787  pmovzxwd xmm14, xmm14
00007aa9b5fcf78d  pslld xmm14, 0x10
00007aa9b5fcf793  movaps [r15+0x280], xmm14
00007aa9b5fcf79b  movq xmm8, qword ptr [r15+0x180]
00007aa9b5fcf7a4  pmovzxwd xmm8, xmm8
00007aa9b5fcf7aa  pslld xmm8, 0x00
00007aa9b5fcf7b0  movq xmm7, qword ptr [r15+0x210]
00007aa9b5fcf7b9  pmovzxwd xmm7, xmm7
00007aa9b5fcf7be  pslld xmm7, 0x10
00007aa9b5fcf7c3  movaps xmm6, [r15+0x150]
00007aa9b5fcf7cb  pextrq rax, xmm6, 0x01
00007aa9b5fcf7d2  movq xmm6, rax
00007aa9b5fcf7d7  pmovzxwd xmm6, xmm6
00007aa9b5fcf7dc  pslld xmm6, 0x10
00007aa9b5fcf7e1  por xmm11, xmm10
00007aa9b5fcf7e6  movaps [r15+0x230], xmm11
00007aa9b5fcf7ee  pextrq rax, xmm13, 0x01
00007aa9b5fcf7f5  movq xmm13, rax
00007aa9b5fcf7fa  pmovzxwd xmm13, xmm13
00007aa9b5fcf800  pslld xmm13, 0x08
00007aa9b5fcf806  movaps [r15+0x240], xmm13
00007aa9b5fcf80e  movq xmm10, qword ptr [r15+0x220]
00007aa9b5fcf817  pmovzxwd xmm10, xmm10
00007aa9b5fcf81d  pslld xmm10, 0x08
00007aa9b5fcf823  movaps xmm5, [r15+0x160]
00007aa9b5fcf82b  pextrq rax, xmm5, 0x01
00007aa9b5fcf832  movq xmm5, rax
00007aa9b5fcf837  pmovzxwd xmm5, xmm5
00007aa9b5fcf83c  pslld xmm5, 0x08
00007aa9b5fcf841  pslld xmm9, 0x18
00007aa9b5fcf847  pslld xmm15, 0x18
00007aa9b5fcf84d  pslld xmm8, 0x18
00007aa9b5fcf853  movq xmm4, qword ptr [r15+0x250]
00007aa9b5fcf85c  pmovzxwd xmm4, xmm4
00007aa9b5fcf861  pslld xmm4, 0x00
00007aa9b5fcf866  por xmm14, xmm13
00007aa9b5fcf86b  por xmm7, xmm10
00007aa9b5fcf870  movaps [r15+0x210], xmm7
00007aa9b5fcf878  pslld xmm1, 0x18
00007aa9b5fcf87d  movaps [r15+0x220], xmm1
00007aa9b5fcf885  por xmm6, xmm5
00007aa9b5fcf889  por xmm11, xmm9
00007aa9b5fcf88e  movaps [r15+0x160], xmm11
00007aa9b5fcf896  pextrq rax, xmm12, 0x01
00007aa9b5fcf89d  movq xmm13, rax
00007aa9b5fcf8a2  pmovzxwd xmm13, xmm13
00007aa9b5fcf8a8  pslld xmm13, 0x00
00007aa9b5fcf8ae  movaps [r15+0x170], xmm13
00007aa9b5fcf8b6  movq xmm12, qword ptr [r15+0x110]
00007aa9b5fcf8bf  pmovzxwd xmm12, xmm12
00007aa9b5fcf8c5  pslld xmm12, 0x00
00007aa9b5fcf8cb  por xmm14, xmm15
00007aa9b5fcf8d0  por xmm7, xmm8
00007aa9b5fcf8d5  movaps xmm15, [r15+0x250]
00007aa9b5fcf8dd  pextrq rax, xmm15, 0x01
00007aa9b5fcf8e4  movq xmm15, rax
00007aa9b5fcf8e9  pmovzxwd xmm15, xmm15
00007aa9b5fcf8ef  pslld xmm15, 0x00
00007aa9b5fcf8f5  movaps [r15+0x180], xmm15
00007aa9b5fcf8fd  por xmm6, xmm1
00007aa9b5fcf901  movaps [r15+0x150], xmm6
00007aa9b5fcf909  por xmm11, xmm4
00007aa9b5fcf90e  movaps [r15+0x140], xmm11
00007aa9b5fcf916  por xmm7, xmm12
00007aa9b5fcf91b  movaps [r15+0x110], xmm7
00007aa9b5fcf923  por xmm14, xmm13
00007aa9b5fcf928  movaps [r15+0x120], xmm14
00007aa9b5fcf930  por xmm6, xmm15
00007aa9b5fcf935  movaps [r15+0x130], xmm6
00007aa9b5fcf93d  mov rax, [r15+0xF8]
00007aa9b5fcf944  lea r14, [rax+0x20]
00007aa9b5fcf948  movups [r13+r14*1], xmm7
00007aa9b5fcf94e  lea r14, [rax+0x30]
00007aa9b5fcf952  movups [r13+r14*1], xmm14
00007aa9b5fcf958  movups [r13+rax*1], xmm11
00007aa9b5fcf95e  lea r14, [rax+0x10]
00007aa9b5fcf962  movups [r13+r14*1], xmm6
00007aa9b5fcf968  mov r14d, [r13+rax*1]
00007aa9b5fcf96d  mov rax, [r15+0x48]
00007aa9b5fcf971  mov [r15+0x68], rax
00007aa9b5fcf975  mov qword ptr [r15+0x58], 0x04
00007aa9b5fcf97d  lea r12, [rax+0x04]
00007aa9b5fcf981  mov r11d, [r13+r12*1]
00007aa9b5fcf986  mov [rsp+0x10], r11d
00007aa9b5fcf98b  mov r11d, r11d
00007aa9b5fcf98e  mov [r15+0x70], r11
00007aa9b5fcf992  lea r12, [rax+0x38]
00007aa9b5fcf996  mov r11d, [r13+r12*1]
00007aa9b5fcf99b  lea r12, [rax+0x24]
00007aa9b5fcf99f  mov r10d, [r13+r12*1]
00007aa9b5fcf9a4  mov [rsp+0x20], r10d
00007aa9b5fcf9a9  mov r10d, r10d
00007aa9b5fcf9ac  mov [r15+0x90], r10
00007aa9b5fcf9b3  mov [rsp+0x30], rax
00007aa9b5fcf9b8  xor eax, eax
00007aa9b5fcf9ba  mov r12d, 0x04
00007aa9b5fcf9c0  mov r10d, 0xC0
00007aa9b5fcf9c6  cmp r12, r10
00007aa9b5fcf9c9  cmc
00007aa9b5fcf9ca  lahf
00007aa9b5fcf9cb  seto al
00007aa9b5fcf9ce  mov [r15+0x108], eax
00007aa9b5fcf9d5  mov eax, [rsp+0x10]
00007aa9b5fcf9d9  mov r12d, [rsp+0x10]
00007aa9b5fcf9de  shrd eax, r12d, 0x07
00007aa9b5fcf9e3  mov [rsp+0x10], r11d
00007aa9b5fcf9e8  mov r10d, [rsp+0x10]
00007aa9b5fcf9ed  shrd r11d, r10d, 0x11
00007aa9b5fcf9f2  mov r9d, [rsp+0x20]
00007aa9b5fcf9f7  lea r8d, [r9d+r14d*1]
00007aa9b5fcf9fc  rorx r14d, r12d, 0x12
00007aa9b5fcfa02  xor eax, r14d
00007aa9b5fcfa05  rorx r14d, r10d, 0x13
00007aa9b5fcfa0b  xor r11d, r14d
00007aa9b5fcfa0e  mov [rsp+0x10], r11d
00007aa9b5fcfa13  mov r11d, r11d
00007aa9b5fcfa16  mov [r15+0x88], r11
00007aa9b5fcfa1d  mov [rsp+0x20], r12d
00007aa9b5fcfa22  shr r12d, 0x03
00007aa9b5fcfa26  xor eax, r12d
00007aa9b5fcfa29  mov [rsp+0x40], eax
00007aa9b5fcfa2d  mov eax, eax
00007aa9b5fcfa2f  mov [r15+0x80], rax
00007aa9b5fcfa36  shr r10d, 0x0A
00007aa9b5fcfa3a  mov eax, [rsp+0x10]
00007aa9b5fcfa3e  xor eax, r10d
00007aa9b5fcfa41  mov [rsp+0x10], eax
00007aa9b5fcfa45  mov eax, eax
00007aa9b5fcfa47  mov [r15+0x78], rax
00007aa9b5fcfa4b  mov eax, [rsp+0x40]
00007aa9b5fcfa4f  lea r14d, [r8d+eax*1]
00007aa9b5fcfa54  mov eax, [rsp+0x10]
00007aa9b5fcfa58  lea r12d, [r14d+eax*1]
00007aa9b5fcfa5d  mov rax, [rsp+0x30]
00007aa9b5fcfa62  lea r14, [rax+0x40]
00007aa9b5fcfa66  mov [r13+r14*1], r12d
00007aa9b5fcfa6b  mov eax, [rsp+0x20]
00007aa9b5fcfa6f  mov eax, eax
00007aa9b5fcfa71  mov [r15+0x60], rax
00007aa9b5fcfa75  mov eax, [r15+0x108]
00007aa9b5fcfa7c  sahf
00007aa9b5fcfa7d  jnz 0x00007AA9B5FCFAAF
00007aa9b5fcfa7f  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcfa87  jz 0x00007AA9B5FCFF70
00007aa9b5fcfa8d  nop [rax+rax*1], ax
00007aa9b5fcfa96  nop [rax+rax*1], eax
00007aa9b5fcfa9e  mov eax, 0x41088C
00007aa9b5fcfaa3  mov [r15+0x100], rax
00007aa9b5fcfaaa  jmp 0x00007AA9B5DFE110
00007aa9b5fcfaaf  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcfab7  jz 0x00007AA9B5FCFDC0
00007aa9b5fcfabd  nop [rax+rax*1], ax
00007aa9b5fcfac6  nop [rax+rax*1], eax
00007aa9b5fcface  mov eax, 0x410844
00007aa9b5fcfad3  mov [r15+0x100], rax
00007aa9b5fcfada  jmp 0x00007AA9B5DFE110
00007aa9b5fcfadf  int3
00007aa9b5fcfae0  call 0x00007AA9B5E0D860
00007aa9b5fcfae5  jmp 0x00007AA9B5FCF17A
00007aa9b5fcfaea  call 0x00007AA9B5EE2420
00007aa9b5fcfaef  jmp 0x00007AA9B5FCF193
00007aa9b5fcfaf4  call 0x00007AA9B5EE2420
00007aa9b5fcfaf9  jmp 0x00007AA9B5FCF1AC
00007aa9b5fcfafe  call 0x00007AA9B5EE2420
00007aa9b5fcfb03  jmp 0x00007AA9B5FCF1C5
00007aa9b5fcfb08  call 0x00007AA9B5EE2420
00007aa9b5fcfb0d  jmp 0x00007AA9B5FCF1DE
00007aa9b5fcfb12  call 0x00007AA9B5EE2420
00007aa9b5fcfb17  jmp 0x00007AA9B5FCF1EF
00007aa9b5fcfb1c  call 0x00007AA9B5EE2420
00007aa9b5fcfb21  jmp 0x00007AA9B5FCF200
00007aa9b5fcfb26  call 0x00007AA9B5EE2420
00007aa9b5fcfb2b  jmp 0x00007AA9B5FCF211
00007aa9b5fcfb30  call 0x00007AA9B5EE2420
00007aa9b5fcfb35  jmp 0x00007AA9B5FCF222
00007aa9b5fcfb3a  call 0x00007AA9B5EE2420
00007aa9b5fcfb3f  jmp 0x00007AA9B5FCF233
00007aa9b5fcfb44  call 0x00007AA9B5EE2420
00007aa9b5fcfb49  jmp 0x00007AA9B5FCF244
00007aa9b5fcfb4e  call 0x00007AA9B5EE2420
00007aa9b5fcfb53  jmp 0x00007AA9B5FCF255
00007aa9b5fcfb58  call 0x00007AA9B5EE2420
00007aa9b5fcfb5d  jmp 0x00007AA9B5FCF266
00007aa9b5fcfb62  call 0x00007AA9B5EE2420
00007aa9b5fcfb67  jmp 0x00007AA9B5FCF277
00007aa9b5fcfb6c  call 0x00007AA9B5EE2420
00007aa9b5fcfb71  jmp 0x00007AA9B5FCF288
00007aa9b5fcfb76  call 0x00007AA9B5EE2420
00007aa9b5fcfb7b  jmp 0x00007AA9B5FCF299
00007aa9b5fcfb80  call 0x00007AA9B5EE2420
00007aa9b5fcfb85  jmp 0x00007AA9B5FCF2AA
00007aa9b5fcfb8a  call 0x00007AA9B5EE2420
00007aa9b5fcfb8f  jmp 0x00007AA9B5FCF2BB
00007aa9b5fcfb94  call 0x00007AA9B5EE2420
00007aa9b5fcfb99  jmp 0x00007AA9B5FCF2CC
00007aa9b5fcfb9e  call 0x00007AA9B5EE2420
00007aa9b5fcfba3  jmp 0x00007AA9B5FCF2DD
00007aa9b5fcfba8  call 0x00007AA9B5EE2420
00007aa9b5fcfbad  jmp 0x00007AA9B5FCF2EE
00007aa9b5fcfbb2  call 0x00007AA9B5EE2420
00007aa9b5fcfbb7  jmp 0x00007AA9B5FCF2FF
00007aa9b5fcfbbc  call 0x00007AA9B5EE2420
00007aa9b5fcfbc1  jmp 0x00007AA9B5FCF310
00007aa9b5fcfbc6  call 0x00007AA9B5EE2420
00007aa9b5fcfbcb  jmp 0x00007AA9B5FCF321
00007aa9b5fcfbd0  call 0x00007AA9B5EE2420
00007aa9b5fcfbd5  jmp 0x00007AA9B5FCF332
00007aa9b5fcfbda  call 0x00007AA9B5EE2420
00007aa9b5fcfbdf  jmp 0x00007AA9B5FCF343
00007aa9b5fcfbe4  call 0x00007AA9B5EE2420
00007aa9b5fcfbe9  jmp 0x00007AA9B5FCF354
00007aa9b5fcfbee  call 0x00007AA9B5EE2420
00007aa9b5fcfbf3  jmp 0x00007AA9B5FCF365
00007aa9b5fcfbf8  call 0x00007AA9B5EE2420
00007aa9b5fcfbfd  jmp 0x00007AA9B5FCF376
00007aa9b5fcfc02  call 0x00007AA9B5EE2420
00007aa9b5fcfc07  jmp 0x00007AA9B5FCF387
00007aa9b5fcfc0c  call 0x00007AA9B5EE2420
00007aa9b5fcfc11  jmp 0x00007AA9B5FCF398
00007aa9b5fcfc16  call 0x00007AA9B5EE2420
00007aa9b5fcfc1b  jmp 0x00007AA9B5FCF3A9
00007aa9b5fcfc20  call 0x00007AA9B5EE2420
00007aa9b5fcfc25  jmp 0x00007AA9B5FCF3BA
00007aa9b5fcfc2a  call 0x00007AA9B5EE2420
00007aa9b5fcfc2f  jmp 0x00007AA9B5FCF3CB
00007aa9b5fcfc34  call 0x00007AA9B5EE2420
00007aa9b5fcfc39  jmp 0x00007AA9B5FCF3DC
00007aa9b5fcfc3e  call 0x00007AA9B5EE2420
00007aa9b5fcfc43  jmp 0x00007AA9B5FCF3ED
00007aa9b5fcfc48  call 0x00007AA9B5EE2420
00007aa9b5fcfc4d  jmp 0x00007AA9B5FCF3FE
00007aa9b5fcfc52  call 0x00007AA9B5EE2420
00007aa9b5fcfc57  jmp 0x00007AA9B5FCF40F
00007aa9b5fcfc5c  call 0x00007AA9B5EE2420
00007aa9b5fcfc61  jmp 0x00007AA9B5FCF420
00007aa9b5fcfc66  call 0x00007AA9B5EE2420
00007aa9b5fcfc6b  jmp 0x00007AA9B5FCF431
00007aa9b5fcfc70  call 0x00007AA9B5EE2420
00007aa9b5fcfc75  jmp 0x00007AA9B5FCF442
00007aa9b5fcfc7a  call 0x00007AA9B5EE2420
00007aa9b5fcfc7f  jmp 0x00007AA9B5FCF453
00007aa9b5fcfc84  call 0x00007AA9B5EE2420
00007aa9b5fcfc89  jmp 0x00007AA9B5FCF464
00007aa9b5fcfc8e  call 0x00007AA9B5EE2420
00007aa9b5fcfc93  jmp 0x00007AA9B5FCF475
00007aa9b5fcfc98  call 0x00007AA9B5EE2420
00007aa9b5fcfc9d  jmp 0x00007AA9B5FCF486
00007aa9b5fcfca2  call 0x00007AA9B5EE2420
00007aa9b5fcfca7  jmp 0x00007AA9B5FCF497
00007aa9b5fcfcac  call 0x00007AA9B5EE2420
00007aa9b5fcfcb1  jmp 0x00007AA9B5FCF4A8
00007aa9b5fcfcb6  call 0x00007AA9B5EE2420
00007aa9b5fcfcbb  jmp 0x00007AA9B5FCF4B9
00007aa9b5fcfcc0  call 0x00007AA9B5EE2420
00007aa9b5fcfcc5  jmp 0x00007AA9B5FCF4CA
00007aa9b5fcfcca  call 0x00007AA9B5EE2420
00007aa9b5fcfccf  jmp 0x00007AA9B5FCF4DB
00007aa9b5fcfcd4  call 0x00007AA9B5EE2420
00007aa9b5fcfcd9  jmp 0x00007AA9B5FCF4EC
00007aa9b5fcfcde  call 0x00007AA9B5EE2420
00007aa9b5fcfce3  jmp 0x00007AA9B5FCF4FD
00007aa9b5fcfce8  call 0x00007AA9B5EE2420
00007aa9b5fcfced  jmp 0x00007AA9B5FCF50E
00007aa9b5fcfcf2  call 0x00007AA9B5EE2420
00007aa9b5fcfcf7  jmp 0x00007AA9B5FCF51F
00007aa9b5fcfcfc  call 0x00007AA9B5EE2420
00007aa9b5fcfd01  jmp 0x00007AA9B5FCF530
00007aa9b5fcfd06  call 0x00007AA9B5EE2420
00007aa9b5fcfd0b  jmp 0x00007AA9B5FCF541
00007aa9b5fcfd10  call 0x00007AA9B5EE2420
00007aa9b5fcfd15  jmp 0x00007AA9B5FCF552
00007aa9b5fcfd1a  call 0x00007AA9B5EE2420
00007aa9b5fcfd1f  jmp 0x00007AA9B5FCF563
00007aa9b5fcfd24  call 0x00007AA9B5EE2420
00007aa9b5fcfd29  jmp 0x00007AA9B5FCF574
00007aa9b5fcfd2e  call 0x00007AA9B5EE2420
00007aa9b5fcfd33  jmp 0x00007AA9B5FCF585
00007aa9b5fcfd38  call 0x00007AA9B5EE2420
00007aa9b5fcfd3d  jmp 0x00007AA9B5FCF596
00007aa9b5fcfd42  call 0x00007AA9B5EE2420
00007aa9b5fcfd47  jmp 0x00007AA9B5FCF5AF
00007aa9b5fcfd4c  call 0x00007AA9B5EE2420
00007aa9b5fcfd51  jmp 0x00007AA9B5FCF5C8
00007aa9b5fcfd56  call 0x00007AA9B5ED5610
00007aa9b5fcfd5b  jmp 0x00007AA9B5FCF5E1
00007aa9b5fcfd60  call 0x00007AA9B5EDC580
00007aa9b5fcfd65  jmp 0x00007AA9B5FCF94E
00007aa9b5fcfd6a  call 0x00007AA9B5EE46C0
00007aa9b5fcfd6f  jmp 0x00007AA9B5FCF958
00007aa9b5fcfd74  call 0x00007AA9B5E09E90
00007aa9b5fcfd79  jmp 0x00007AA9B5FCF95E
00007aa9b5fcfd7e  call 0x00007AA9B5EDB310
00007aa9b5fcfd83  jmp 0x00007AA9B5FCF968
00007aa9b5fcfd88  call 0x00007AA9B5E0DAE0
00007aa9b5fcfd8d  jmp 0x00007AA9B5FCF96D
00007aa9b5fcfd92  call 0x00007AA9B5EC0230
00007aa9b5fcfd97  jmp 0x00007AA9B5FCF986
00007aa9b5fcfd9c  call 0x00007AA9B5EC0230
00007aa9b5fcfda1  jmp 0x00007AA9B5FCF99B
00007aa9b5fcfda6  call 0x00007AA9B5EBEFC0
00007aa9b5fcfdab  jmp 0x00007AA9B5FCF9A4
00007aa9b5fcfdb0  call 0x00007AA9B5EE2BA0
00007aa9b5fcfdb5  jmp 0x00007AA9B5FCFA6B
00007aa9b5fcfdba  int3
00007aa9b5fcfdbb  nop [rax+rax*1], eax
00007aa9b5fcfdc0  mov rax, [r15+0x48]
00007aa9b5fcfdc4  mov r14, [r15+0x58]
00007aa9b5fcfdc8  lea r12, [rax+r14*1]
00007aa9b5fcfdcc  mov [r15+0x68], r12
00007aa9b5fcfdd0  lea rax, [r14+0x04]
00007aa9b5fcfdd4  mov [r15+0x58], rax
00007aa9b5fcfdd8  lea r14, [r12+0x04]
00007aa9b5fcfddd  mov r11d, [r13+r14*1]
00007aa9b5fcfde2  mov [rsp+0x10], r11d
00007aa9b5fcfde7  mov r11d, r11d
00007aa9b5fcfdea  mov [r15+0x70], r11
00007aa9b5fcfdee  lea r14, [r12+0x38]
00007aa9b5fcfdf3  mov r11d, [r13+r14*1]
00007aa9b5fcfdf8  lea r14, [r12+0x24]
00007aa9b5fcfdfd  mov r10d, [r13+r14*1]
00007aa9b5fcfe02  mov [rsp+0x20], r10d
00007aa9b5fcfe07  mov r10d, r10d
00007aa9b5fcfe0a  mov [r15+0x90], r10
00007aa9b5fcfe11  mov [rsp+0x30], rax
00007aa9b5fcfe16  xor eax, eax
00007aa9b5fcfe18  mov r14, [rsp+0x30]
00007aa9b5fcfe1d  mov r10d, 0xC0
00007aa9b5fcfe23  cmp r14, r10
00007aa9b5fcfe26  cmc
00007aa9b5fcfe27  lahf
00007aa9b5fcfe28  seto al
00007aa9b5fcfe2b  mov [r15+0x108], eax
00007aa9b5fcfe32  mov eax, [rsp+0x10]
00007aa9b5fcfe36  mov r14d, [rsp+0x10]
00007aa9b5fcfe3b  shrd eax, r14d, 0x07
00007aa9b5fcfe40  mov [rsp+0x10], r11d
00007aa9b5fcfe45  mov r10d, [rsp+0x10]
00007aa9b5fcfe4a  shrd r11d, r10d, 0x11
00007aa9b5fcfe4f  mov r9d, [r15+0x60]
00007aa9b5fcfe53  mov r8d, [rsp+0x20]
00007aa9b5fcfe58  lea ebp, [r8d+r9d*1]
00007aa9b5fcfe5d  rorx r9d, r14d, 0x12
00007aa9b5fcfe63  xor eax, r9d
00007aa9b5fcfe66  rorx r9d, r10d, 0x13
00007aa9b5fcfe6c  xor r11d, r9d
00007aa9b5fcfe6f  mov [rsp+0x10], r11d
00007aa9b5fcfe74  mov r11d, r11d
00007aa9b5fcfe77  mov [r15+0x88], r11
00007aa9b5fcfe7e  mov [rsp+0x20], r14d
00007aa9b5fcfe83  shr r14d, 0x03
00007aa9b5fcfe87  xor eax, r14d
00007aa9b5fcfe8a  mov [rsp+0x30], eax
00007aa9b5fcfe8e  mov eax, eax
00007aa9b5fcfe90  mov [r15+0x80], rax
00007aa9b5fcfe97  shr r10d, 0x0A
00007aa9b5fcfe9b  mov eax, [rsp+0x10]
00007aa9b5fcfe9f  xor eax, r10d
00007aa9b5fcfea2  mov [rsp+0x10], eax
00007aa9b5fcfea6  mov eax, eax
00007aa9b5fcfea8  mov [r15+0x78], rax
00007aa9b5fcfeac  mov eax, [rsp+0x30]
00007aa9b5fcfeb0  lea r14d, [ebp+eax*1]
00007aa9b5fcfeb6  mov eax, [rsp+0x10]
00007aa9b5fcfeba  lea r11d, [r14d+eax*1]
00007aa9b5fcfebf  lea rax, [r12+0x40]
00007aa9b5fcfec4  mov [r13+rax*1], r11d
00007aa9b5fcfec9  mov eax, [rsp+0x20]
00007aa9b5fcfecd  mov eax, eax
00007aa9b5fcfecf  mov [r15+0x60], rax
00007aa9b5fcfed3  mov eax, [r15+0x108]
00007aa9b5fcfeda  sahf
00007aa9b5fcfedb  jnz 0x00007AA9B5FCFF0D
00007aa9b5fcfedd  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcfee5  jz 0x00007AA9B5FCFF70
00007aa9b5fcfeeb  nop [rax+rax*1], ax
00007aa9b5fcfef4  nop [rax+rax*1], eax
00007aa9b5fcfefc  mov eax, 0x41088C
00007aa9b5fcff01  mov [r15+0x100], rax
00007aa9b5fcff08  jmp 0x00007AA9B5DFE110
00007aa9b5fcff0d  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fcff15  jz 0x00007AA9B5FCFDC0
00007aa9b5fcff1b  nop [rax+rax*1], ax
00007aa9b5fcff24  nop [rax+rax*1], eax
00007aa9b5fcff2c  mov eax, 0x410844
00007aa9b5fcff31  mov [r15+0x100], rax
00007aa9b5fcff38  jmp 0x00007AA9B5DFE110
00007aa9b5fcff3d  int3
00007aa9b5fcff3e  call 0x00007AA9B5EE1430
00007aa9b5fcff43  jmp 0x00007AA9B5FCFDE2
00007aa9b5fcff48  call 0x00007AA9B5EE1430
00007aa9b5fcff4d  jmp 0x00007AA9B5FCFDF8
00007aa9b5fcff52  call 0x00007AA9B5EE01C0
00007aa9b5fcff57  jmp 0x00007AA9B5FCFE02
00007aa9b5fcff5c  call 0x00007AA9B5E0A860
00007aa9b5fcff61  jmp 0x00007AA9B5FCFEC9
00007aa9b5fcff66  int3
00007aa9b5fcff67  nop [rax+rax*1], ax
00007aa9b5fcff70  mov rax, [r15]
00007aa9b5fcff73  mov r14d, [r13+rax*1]
00007aa9b5fcff78  lea r12, [rax+0x04]
00007aa9b5fcff7c  mov r11d, [r13+r12*1]
00007aa9b5fcff81  mov [rsp+0x10], r14d
00007aa9b5fcff86  mov r14d, r14d
00007aa9b5fcff89  mov [r15+0x78], r14
00007aa9b5fcff8d  mov [rsp+0x20], r11d
00007aa9b5fcff92  mov r11d, r11d
00007aa9b5fcff95  mov [r15+0x80], r11
00007aa9b5fcff9c  lea r14, [rax+0x08]
00007aa9b5fcffa0  mov r12d, [r13+r14*1]
00007aa9b5fcffa5  lea r14, [rax+0x0C]
00007aa9b5fcffa9  mov r11d, [r13+r14*1]
00007aa9b5fcffae  mov [rsp+0x30], r12d
00007aa9b5fcffb3  mov r12d, r12d
00007aa9b5fcffb6  mov [r15+0x70], r12
00007aa9b5fcffba  mov [rsp+0x40], r11d
00007aa9b5fcffbf  mov r11d, r11d
00007aa9b5fcffc2  mov [r15+0x68], r11
00007aa9b5fcffc6  lea r14, [rax+0x18]
00007aa9b5fcffca  mov r12d, [r13+r14*1]
00007aa9b5fcffcf  lea r14, [rax+0x1C]
00007aa9b5fcffd3  mov r11d, [r13+r14*1]
00007aa9b5fcffd8  mov [rsp+0x50], r12d
00007aa9b5fcffdd  mov r12d, r12d
00007aa9b5fcffe0  mov [r15+0x58], r12
00007aa9b5fcffe4  mov [rsp+0x60], r11d
00007aa9b5fcffe9  mov r11d, r11d
00007aa9b5fcffec  mov [r15+0x60], r11
00007aa9b5fcfff0  lea r14, [rax+0x10]
00007aa9b5fcfff4  mov r12d, [r13+r14*1]
00007aa9b5fcfff9  lea r14, [rax+0x14]
00007aa9b5fcfffd  mov eax, [r13+r14*1]
00007aa9b5fd0002  mov [rsp+0x70], r12d
00007aa9b5fd0007  mov r12d, r12d
00007aa9b5fd000a  mov [r15+0x18], r12
00007aa9b5fd000e  mov [rsp+0x80], eax
00007aa9b5fd0015  mov eax, eax
00007aa9b5fd0017  mov [r15+0x90], rax
00007aa9b5fd001e  mov eax, [rsp+0x70]
00007aa9b5fd0022  mov eax, eax
00007aa9b5fd0024  mov [r15+0x30], rax
00007aa9b5fd0028  mov eax, [rsp+0x50]
00007aa9b5fd002c  mov eax, eax
00007aa9b5fd002e  mov [r15+0xA0], rax
00007aa9b5fd0035  mov eax, [rsp+0x30]
00007aa9b5fd0039  mov eax, eax
00007aa9b5fd003b  mov [r15+0x28], rax
00007aa9b5fd003f  mov eax, [rsp+0x20]
00007aa9b5fd0043  mov eax, eax
00007aa9b5fd0045  mov [r15+0x98], rax
00007aa9b5fd004c  mov eax, [rsp+0x10]
00007aa9b5fd0050  mov eax, eax
00007aa9b5fd0052  mov [r15+0x38], rax
00007aa9b5fd0056  mov eax, [rsp+0x70]
00007aa9b5fd005a  mov r14d, [rsp+0x70]
00007aa9b5fd005f  shrd eax, r14d, 0x06
00007aa9b5fd0064  mov [rsp+0x70], r14d
00007aa9b5fd0069  mov r12d, [rsp+0x80]
00007aa9b5fd0071  and r14d, r12d
00007aa9b5fd0074  mov r11d, [rsp+0x10]
00007aa9b5fd0079  mov r10d, [rsp+0x10]
00007aa9b5fd007e  shrd r11d, r10d, 0x02
00007aa9b5fd0083  mov [rsp+0x10], r12d
00007aa9b5fd0088  mov r12d, r12d
00007aa9b5fd008b  mov [r15+0x20], r12
00007aa9b5fd008f  mov r12, [r15+0x50]
00007aa9b5fd0093  mov r9d, [r13+r12*1]
00007aa9b5fd0098  mov r12d, [rsp+0x50]
00007aa9b5fd009d  mov r8d, [rsp+0x70]
00007aa9b5fd00a2  andn ebp, r8d, r12d
00007aa9b5fd00a7  mov edi, [rsp+0x60]
00007aa9b5fd00ab  lea esi, [r14d+edi*1]
00007aa9b5fd00b0  rorx r14d, r8d, 0x0B
00007aa9b5fd00b6  xor eax, r14d
00007aa9b5fd00b9  rorx r14d, r10d, 0x0D
00007aa9b5fd00bf  xor r11d, r14d
00007aa9b5fd00c2  lea edi, [esi+ebp*1]
00007aa9b5fd00c6  mov r14, [r15+0x48]
00007aa9b5fd00ca  mov ebp, [r13+r14*1]
00007aa9b5fd00cf  mov r14d, [rsp+0x30]
00007aa9b5fd00d4  mov esi, [rsp+0x20]
00007aa9b5fd00d8  and r14d, esi
00007aa9b5fd00db  mov [rsp+0x20], r14d
00007aa9b5fd00e0  mov r14d, r14d
00007aa9b5fd00e3  mov [r15+0xD8], r14
00007aa9b5fd00ea  lea r14d, [edi+r9d*1]
00007aa9b5fd00ef  mov r9d, [rsp+0x30]
00007aa9b5fd00f4  xor r9d, esi
00007aa9b5fd00f7  rorx edi, r8d, 0x19
00007aa9b5fd00fd  xor eax, edi
00007aa9b5fd00ff  and r9d, r10d
00007aa9b5fd0102  rorx edi, r10d, 0x16
00007aa9b5fd0108  xor r11d, edi
00007aa9b5fd010b  mov [rsp+0x30], r11d
00007aa9b5fd0110  mov r11d, r11d
00007aa9b5fd0113  mov [r15+0xD0], r11
00007aa9b5fd011a  lea r11d, [r14d+ebp*1]
00007aa9b5fd011f  mov r10d, [rsp+0x20]
00007aa9b5fd0124  xor r9d, r10d
00007aa9b5fd0127  lea r14d, [r11d+eax*1]
00007aa9b5fd012c  mov qword ptr [r15+0x88], 0x04
00007aa9b5fd0137  mov eax, [rsp+0x30]
00007aa9b5fd013b  lea r11d, [r9d+eax*1]
00007aa9b5fd0140  mov eax, [rsp+0x40]
00007aa9b5fd0144  lea r10d, [r14d+eax*1]
00007aa9b5fd0149  mov r10d, r10d
00007aa9b5fd014c  mov [r15+0xB8], r10
00007aa9b5fd0153  xor eax, eax
00007aa9b5fd0155  mov r10d, 0x04
00007aa9b5fd015b  mov r9d, 0x100
00007aa9b5fd0161  cmp r10, r9
00007aa9b5fd0164  cmc
00007aa9b5fd0165  lahf
00007aa9b5fd0166  seto al
00007aa9b5fd0169  mov [r15+0x108], eax
00007aa9b5fd0170  lea eax, [r11d+r14d*1]
00007aa9b5fd0175  mov eax, eax
00007aa9b5fd0177  mov [r15+0xA8], rax
00007aa9b5fd017e  mov r12d, r12d
00007aa9b5fd0181  mov [r15+0xB0], r12
00007aa9b5fd0188  mov eax, [rsp+0x10]
00007aa9b5fd018c  mov eax, eax
00007aa9b5fd018e  mov [r15+0xC0], rax
00007aa9b5fd0195  mov r8d, r8d
00007aa9b5fd0198  mov [r15+0xC8], r8
00007aa9b5fd019f  mov eax, [r15+0x108]
00007aa9b5fd01a6  sahf
00007aa9b5fd01a7  jnz 0x00007AA9B5FD01D9
00007aa9b5fd01a9  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd01b1  jz 0x00007AA9B5FD04A0
00007aa9b5fd01b7  nop [rax+rax*1], ax
00007aa9b5fd01c0  nop [rax+rax*1], eax
00007aa9b5fd01c8  mov eax, 0x41094C
00007aa9b5fd01cd  mov [r15+0x100], rax
00007aa9b5fd01d4  jmp 0x00007AA9B5DFE110
00007aa9b5fd01d9  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd01e1  jz 0x00007AA9B5FD0270
00007aa9b5fd01e7  nop [rax+rax*1], ax
00007aa9b5fd01f0  nop [rax+rax*1], eax
00007aa9b5fd01f8  mov eax, 0x4108C0
00007aa9b5fd01fd  mov [r15+0x100], rax
00007aa9b5fd0204  jmp 0x00007AA9B5DFE110
00007aa9b5fd0209  int3
00007aa9b5fd020a  call 0x00007AA9B5E0DAE0
00007aa9b5fd020f  jmp 0x00007AA9B5FCFF78
00007aa9b5fd0214  call 0x00007AA9B5EC0230
00007aa9b5fd0219  jmp 0x00007AA9B5FCFF81
00007aa9b5fd021e  call 0x00007AA9B5EE26A0
00007aa9b5fd0223  jmp 0x00007AA9B5FCFFA5
00007aa9b5fd0228  call 0x00007AA9B5EE1430
00007aa9b5fd022d  jmp 0x00007AA9B5FCFFAE
00007aa9b5fd0232  call 0x00007AA9B5EE26A0
00007aa9b5fd0237  jmp 0x00007AA9B5FCFFCF
00007aa9b5fd023c  call 0x00007AA9B5EE1430
00007aa9b5fd0241  jmp 0x00007AA9B5FCFFD8
00007aa9b5fd0246  call 0x00007AA9B5EE26A0
00007aa9b5fd024b  jmp 0x00007AA9B5FCFFF9
00007aa9b5fd0250  call 0x00007AA9B5ED5890
00007aa9b5fd0255  jmp 0x00007AA9B5FD0002
00007aa9b5fd025a  call 0x00007AA9B5EBDD50
00007aa9b5fd025f  jmp 0x00007AA9B5FD0098
00007aa9b5fd0264  call 0x00007AA9B5EDA580
00007aa9b5fd0269  jmp 0x00007AA9B5FD00CF
00007aa9b5fd026e  int3
00007aa9b5fd026f  nop
00007aa9b5fd0270  mov eax, [r15+0xB8]
00007aa9b5fd0277  mov [rsp+0x10], eax
00007aa9b5fd027b  mov eax, eax
00007aa9b5fd027d  mov [r15+0x30], rax
00007aa9b5fd0281  mov eax, [r15+0xC0]
00007aa9b5fd0288  mov [rsp+0x20], eax
00007aa9b5fd028c  mov eax, eax
00007aa9b5fd028e  mov [r15+0xA0], rax
00007aa9b5fd0295  mov eax, [r15+0x28]
00007aa9b5fd0299  mov r14d, [r15+0x98]
00007aa9b5fd02a0  mov [rsp+0x30], r14d
00007aa9b5fd02a5  mov r14d, r14d
00007aa9b5fd02a8  mov [r15+0x28], r14
00007aa9b5fd02ac  mov r14d, [r15+0x38]
00007aa9b5fd02b0  mov [rsp+0x40], r14d
00007aa9b5fd02b5  mov r14d, r14d
00007aa9b5fd02b8  mov [r15+0x98], r14
00007aa9b5fd02bf  mov r14d, [r15+0xA8]
00007aa9b5fd02c6  mov [rsp+0x50], r14d
00007aa9b5fd02cb  mov r14d, r14d
00007aa9b5fd02ce  mov [r15+0x38], r14
00007aa9b5fd02d2  mov r14d, [rsp+0x10]
00007aa9b5fd02d7  mov r12d, [rsp+0x10]
00007aa9b5fd02dc  shrd r14d, r12d, 0x06
00007aa9b5fd02e1  mov r11d, [r15+0xC8]
00007aa9b5fd02e8  mov [rsp+0x10], r12d
00007aa9b5fd02ed  and r12d, r11d
00007aa9b5fd02f0  mov r10d, [rsp+0x50]
00007aa9b5fd02f5  mov r9d, [rsp+0x50]
00007aa9b5fd02fa  shrd r10d, r9d, 0x02
00007aa9b5fd02ff  mov [rsp+0x50], r11d
00007aa9b5fd0304  mov r11d, r11d
00007aa9b5fd0307  mov [r15+0x20], r11
00007aa9b5fd030b  mov r11, [r15+0x88]
00007aa9b5fd0312  mov r8, [r15+0x50]
00007aa9b5fd0316  lea rbp, [r8+r11*1]
00007aa9b5fd031a  mov r8d, [r13+rbp*1]
00007aa9b5fd031f  mov ebp, [rsp+0x20]
00007aa9b5fd0323  mov edi, [rsp+0x10]
00007aa9b5fd0327  andn esi, edi, ebp
00007aa9b5fd032c  mov edx, [r15+0xB0]
00007aa9b5fd0333  lea ecx, [r12d+edx*1]
00007aa9b5fd0338  rorx r12d, edi, 0x0B
00007aa9b5fd033e  xor r14d, r12d
00007aa9b5fd0341  rorx r12d, r9d, 0x0D
00007aa9b5fd0347  xor r10d, r12d
00007aa9b5fd034a  lea r12d, [ecx+esi*1]
00007aa9b5fd034f  mov rsi, [r15+0x48]
00007aa9b5fd0353  lea rdx, [rsi+r11*1]
00007aa9b5fd0357  mov esi, [r13+rdx*1]
00007aa9b5fd035c  mov edx, [rsp+0x30]
00007aa9b5fd0360  mov ecx, [rsp+0x40]
00007aa9b5fd0364  and edx, ecx
00007aa9b5fd0366  mov [rsp+0x10], edx
00007aa9b5fd036a  mov edx, edx
00007aa9b5fd036c  mov [r15+0xD8], rdx
00007aa9b5fd0373  lea edx, [r12d+r8d*1]
00007aa9b5fd0378  mov r12d, [rsp+0x30]
00007aa9b5fd037d  xor r12d, ecx
00007aa9b5fd0380  rorx r8d, edi, 0x19
00007aa9b5fd0386  xor r14d, r8d
00007aa9b5fd0389  and r12d, r9d
00007aa9b5fd038c  rorx r8d, r9d, 0x16
00007aa9b5fd0392  xor r10d, r8d
00007aa9b5fd0395  mov [rsp+0x20], r10d
00007aa9b5fd039a  mov r10d, r10d
00007aa9b5fd039d  mov [r15+0xD0], r10
00007aa9b5fd03a4  lea r10d, [edx+esi*1]
00007aa9b5fd03a9  mov r9d, [rsp+0x10]
00007aa9b5fd03ae  xor r12d, r9d
00007aa9b5fd03b1  lea r9d, [r10d+r14d*1]
00007aa9b5fd03b6  lea r14, [r11+0x04]
00007aa9b5fd03ba  mov [r15+0x88], r14
00007aa9b5fd03c1  mov r11d, [rsp+0x20]
00007aa9b5fd03c6  lea r10d, [r12d+r11d*1]
00007aa9b5fd03cb  lea r11d, [r9d+eax*1]
00007aa9b5fd03d0  mov r11d, r11d
00007aa9b5fd03d3  mov [r15+0xB8], r11
00007aa9b5fd03da  xor eax, eax
00007aa9b5fd03dc  mov r12d, 0x100
00007aa9b5fd03e2  cmp r14, r12
00007aa9b5fd03e5  cmc
00007aa9b5fd03e6  lahf
00007aa9b5fd03e7  seto al
00007aa9b5fd03ea  mov [r15+0x108], eax
00007aa9b5fd03f1  lea eax, [r10d+r9d*1]
00007aa9b5fd03f6  mov eax, eax
00007aa9b5fd03f8  mov [r15+0xA8], rax
00007aa9b5fd03ff  mov ebp, ebp
00007aa9b5fd0401  mov [r15+0xB0], rbp
00007aa9b5fd0408  mov eax, [rsp+0x50]
00007aa9b5fd040c  mov eax, eax
00007aa9b5fd040e  mov [r15+0xC0], rax
00007aa9b5fd0415  mov edi, edi
00007aa9b5fd0417  mov [r15+0xC8], rdi
00007aa9b5fd041e  mov eax, [r15+0x108]
00007aa9b5fd0425  sahf
00007aa9b5fd0426  jnz 0x00007AA9B5FD0458
00007aa9b5fd0428  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0430  jz 0x00007AA9B5FD04A0
00007aa9b5fd0436  nop [rax+rax*1], ax
00007aa9b5fd043f  nop [rax+rax*1], eax
00007aa9b5fd0447  mov eax, 0x41094C
00007aa9b5fd044c  mov [r15+0x100], rax
00007aa9b5fd0453  jmp 0x00007AA9B5DFE110
00007aa9b5fd0458  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0460  jz 0x00007AA9B5FD0270
00007aa9b5fd0466  nop [rax+rax*1], ax
00007aa9b5fd046f  nop [rax+rax*1], eax
00007aa9b5fd0477  mov eax, 0x4108C0
00007aa9b5fd047c  mov [r15+0x100], rax
00007aa9b5fd0483  jmp 0x00007AA9B5DFE110
00007aa9b5fd0488  int3
00007aa9b5fd0489  call 0x00007AA9B5E49010
00007aa9b5fd048e  jmp 0x00007AA9B5FD031F
00007aa9b5fd0493  call 0x00007AA9B5E25930
00007aa9b5fd0498  jmp 0x00007AA9B5FD035C
00007aa9b5fd049d  int3
00007aa9b5fd049e  nop
00007aa9b5fd04a0  mov eax, [r15+0x98]
00007aa9b5fd04a7  mov r14d, [r15+0x70]
00007aa9b5fd04ab  lea r12d, [eax+r14d*1]
00007aa9b5fd04b0  mov eax, [r15+0x28]
00007aa9b5fd04b4  mov r14d, [r15+0x68]
00007aa9b5fd04b8  lea r11d, [eax+r14d*1]
00007aa9b5fd04bd  mov qword ptr [r15+0x88], 0x00
00007aa9b5fd04c8  mov eax, [r15+0xA8]
00007aa9b5fd04cf  mov r14d, [r15+0x78]
00007aa9b5fd04d3  lea r10d, [eax+r14d*1]
00007aa9b5fd04d8  mov [rsp+0x10], r10d
00007aa9b5fd04dd  mov r10d, r10d
00007aa9b5fd04e0  mov [r15+0x78], r10
00007aa9b5fd04e4  mov eax, [r15+0x38]
00007aa9b5fd04e8  mov r14d, [r15+0x80]
00007aa9b5fd04ef  lea r10d, [eax+r14d*1]
00007aa9b5fd04f4  mov [rsp+0x20], r10d
00007aa9b5fd04f9  mov r10d, r10d
00007aa9b5fd04fc  mov [r15+0x80], r10
00007aa9b5fd0503  mov rax, [r15]
00007aa9b5fd0506  lea r14, [rax+0x08]
00007aa9b5fd050a  mov [r13+r14*1], r12d
00007aa9b5fd050f  lea r14, [rax+0x0C]
00007aa9b5fd0513  mov [r13+r14*1], r11d
00007aa9b5fd0518  mov r14d, [r15+0xB8]
00007aa9b5fd051f  mov r12d, [r15+0x18]
00007aa9b5fd0523  lea r11d, [r14d+r12d*1]
00007aa9b5fd0528  mov [rsp+0x30], r11d
00007aa9b5fd052d  mov r11d, r11d
00007aa9b5fd0530  mov [r15+0x68], r11
00007aa9b5fd0534  mov r14d, [r15+0x30]
00007aa9b5fd0538  mov r12d, [r15+0x90]
00007aa9b5fd053f  lea r11d, [r14d+r12d*1]
00007aa9b5fd0544  mov [rsp+0x40], r11d
00007aa9b5fd0549  mov r11d, r11d
00007aa9b5fd054c  mov [r15+0x70], r11
00007aa9b5fd0550  mov r14d, [r15+0x20]
00007aa9b5fd0554  mov r12d, [r15+0x58]
00007aa9b5fd0558  lea r11d, [r14d+r12d*1]
00007aa9b5fd055d  mov [rsp+0x50], r11d
00007aa9b5fd0562  mov r11d, r11d
00007aa9b5fd0565  mov [r15+0x58], r11
00007aa9b5fd0569  mov r14d, [r15+0xA0]
00007aa9b5fd0570  mov r12d, [r15+0x60]
00007aa9b5fd0574  lea r11d, [r14d+r12d*1]
00007aa9b5fd0579  mov [rsp+0x60], r11d
00007aa9b5fd057e  mov r11d, r11d
00007aa9b5fd0581  mov [r15+0x60], r11
00007aa9b5fd0585  mov r14d, [rsp+0x10]
00007aa9b5fd058a  mov [r13+rax*1], r14d
00007aa9b5fd058f  lea r14, [rax+0x04]
00007aa9b5fd0593  mov r12d, [rsp+0x20]
00007aa9b5fd0598  mov [r13+r14*1], r12d
00007aa9b5fd059d  lea r14, [rax+0x10]
00007aa9b5fd05a1  mov r12d, [rsp+0x30]
00007aa9b5fd05a6  mov [r13+r14*1], r12d
00007aa9b5fd05ab  lea r14, [rax+0x14]
00007aa9b5fd05af  mov r12d, [rsp+0x40]
00007aa9b5fd05b4  mov [r13+r14*1], r12d
00007aa9b5fd05b9  lea r14, [rax+0x18]
00007aa9b5fd05bd  mov r12d, [rsp+0x50]
00007aa9b5fd05c2  mov [r13+r14*1], r12d
00007aa9b5fd05c7  lea r14, [rax+0x1C]
00007aa9b5fd05cb  mov r12d, [rsp+0x60]
00007aa9b5fd05d0  mov [r13+r14*1], r12d
00007aa9b5fd05d5  lea r14, [rax+0x68]
00007aa9b5fd05d9  xor eax, eax
00007aa9b5fd05db  mov [r13+r14*1], rax
00007aa9b5fd05e0  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd05e8  jz 0x00007AA9B5FCF0E0
00007aa9b5fd05ee  nop [rax+rax*1], ax
00007aa9b5fd05f7  nop [rax+rax*1], eax
00007aa9b5fd05ff  mov eax, 0x410768
00007aa9b5fd0604  mov [r15+0x100], rax
00007aa9b5fd060b  jmp 0x00007AA9B5DFE110
00007aa9b5fd0610  int3
00007aa9b5fd0611  call 0x00007AA9B5EE2BA0
00007aa9b5fd0616  jmp 0x00007AA9B5FD050F
00007aa9b5fd061b  call 0x00007AA9B5EE1920
00007aa9b5fd0620  jmp 0x00007AA9B5FD0518
00007aa9b5fd0625  call 0x00007AA9B5E0DFE0
00007aa9b5fd062a  jmp 0x00007AA9B5FD058F
00007aa9b5fd062f  call 0x00007AA9B5EE2BA0
00007aa9b5fd0634  jmp 0x00007AA9B5FD059D
00007aa9b5fd0639  call 0x00007AA9B5EE2BA0
00007aa9b5fd063e  jmp 0x00007AA9B5FD05AB
00007aa9b5fd0643  call 0x00007AA9B5EE2BA0
00007aa9b5fd0648  jmp 0x00007AA9B5FD05B9
00007aa9b5fd064d  call 0x00007AA9B5EE2BA0
00007aa9b5fd0652  jmp 0x00007AA9B5FD05C7
00007aa9b5fd0657  call 0x00007AA9B5EE2BA0
00007aa9b5fd065c  jmp 0x00007AA9B5FD05D5
00007aa9b5fd0661  call 0x00007AA9B5ED5EB0
00007aa9b5fd0666  jmp 0x00007AA9B5FD05E0
00007aa9b5fd066b  int3
00007aa9b5fd066c  nop [rax], eax
00007aa9b5fd0670  mov rax, [r15+0xF8]
00007aa9b5fd0677  lea r14, [rax+0x140]
00007aa9b5fd067e  mov r12, [r13+r14*1]
00007aa9b5fd0683  lea r14, [rax+0x148]
00007aa9b5fd068a  mov r11, [r13+r14*1]
00007aa9b5fd068f  mov [r15+0xA0], r12
00007aa9b5fd0696  mov [r15+0x98], r11
00007aa9b5fd069d  lea r14, [rax+0x130]
00007aa9b5fd06a4  mov r12, [r13+r14*1]
00007aa9b5fd06a9  lea r14, [rax+0x138]
00007aa9b5fd06b0  mov r11, [r13+r14*1]
00007aa9b5fd06b5  mov [r15+0xB0], r12
00007aa9b5fd06bc  mov [r15+0xA8], r11
00007aa9b5fd06c3  lea r14, [rax+0x120]
00007aa9b5fd06ca  mov r12, [r13+r14*1]
00007aa9b5fd06cf  lea r14, [rax+0x128]
00007aa9b5fd06d6  mov r11, [r13+r14*1]
00007aa9b5fd06db  mov [r15+0xC0], r12
00007aa9b5fd06e2  mov [r15+0xB8], r11
00007aa9b5fd06e9  lea r14, [rax+0x110]
00007aa9b5fd06f0  mov r12, [r13+r14*1]
00007aa9b5fd06f5  lea r14, [rax+0x118]
00007aa9b5fd06fc  mov r11, [r13+r14*1]
00007aa9b5fd0701  mov [r15+0xD0], r12
00007aa9b5fd0708  mov [r15+0xC8], r11
00007aa9b5fd070f  lea r14, [rax+0x100]
00007aa9b5fd0716  mov r12, [r13+r14*1]
00007aa9b5fd071b  lea r14, [rax+0x108]
00007aa9b5fd0722  mov r11, [r13+r14*1]
00007aa9b5fd0727  mov [r15+0xE8], r12
00007aa9b5fd072e  mov [r15+0xD8], r11
00007aa9b5fd0735  lea r14, [rax+0x150]
00007aa9b5fd073c  mov [r15+0xF8], r14
00007aa9b5fd0743  mov rax, [r15+0xF0]
00007aa9b5fd074a  mov [r15+0x100], rax
00007aa9b5fd0751  jmp 0x00007AA9B5FCE5C0
00007aa9b5fd0756  int3
00007aa9b5fd0757  call 0x00007AA9B5EE27E0
00007aa9b5fd075c  jmp 0x00007AA9B5FD0683
00007aa9b5fd0761  call 0x00007AA9B5EE1570
00007aa9b5fd0766  jmp 0x00007AA9B5FD068F
00007aa9b5fd076b  call 0x00007AA9B5EE27E0
00007aa9b5fd0770  jmp 0x00007AA9B5FD06A9
00007aa9b5fd0775  call 0x00007AA9B5EE1570
00007aa9b5fd077a  jmp 0x00007AA9B5FD06B5
00007aa9b5fd077f  call 0x00007AA9B5EE27E0
00007aa9b5fd0784  jmp 0x00007AA9B5FD06CF
00007aa9b5fd0789  call 0x00007AA9B5EE1570
00007aa9b5fd078e  jmp 0x00007AA9B5FD06DB
00007aa9b5fd0793  call 0x00007AA9B5EE27E0
00007aa9b5fd0798  jmp 0x00007AA9B5FD06F5
00007aa9b5fd079d  call 0x00007AA9B5EE1570
00007aa9b5fd07a2  jmp 0x00007AA9B5FD0701
00007aa9b5fd07a7  call 0x00007AA9B5EE27E0
00007aa9b5fd07ac  jmp 0x00007AA9B5FD071B
00007aa9b5fd07b1  call 0x00007AA9B5EE1570
00007aa9b5fd07b6  jmp 0x00007AA9B5FD0727
00007aa9b5fd07bb  int3
00007aa9b5fd07bc  nop [rax], eax
00007aa9b5fd07c0  mov eax, [r15+0xA0]
00007aa9b5fd07c7  mov [rsp+0x10], eax
00007aa9b5fd07cb  xor eax, eax
00007aa9b5fd07cd  mov r14d, [rsp+0x10]
00007aa9b5fd07d2  sub r14d, 0x01
00007aa9b5fd07d6  cmc
00007aa9b5fd07d7  lahf
00007aa9b5fd07d8  seto al
00007aa9b5fd07db  mov [r15+0x108], eax
00007aa9b5fd07e2  mov r14d, r14d
00007aa9b5fd07e5  mov [r15+0xA0], r14
00007aa9b5fd07ec  mov eax, [r15+0x108]
00007aa9b5fd07f3  sahf
00007aa9b5fd07f4  jnz 0x00007AA9B5FD0826
00007aa9b5fd07f6  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd07fe  jz 0x00007AA9B5FD0900
00007aa9b5fd0804  nop [rax+rax*1], ax
00007aa9b5fd080d  nop [rax+rax*1], eax
00007aa9b5fd0815  mov eax, 0x41028C
00007aa9b5fd081a  mov [r15+0x100], rax
00007aa9b5fd0821  jmp 0x00007AA9B5DFE110
00007aa9b5fd0826  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd082e  jz 0x00007AA9B5FD0860
00007aa9b5fd0834  nop [rax+rax*1], ax
00007aa9b5fd083d  nop [rax+rax*1], eax
00007aa9b5fd0845  mov eax, 0x410274
00007aa9b5fd084a  mov [r15+0x100], rax
00007aa9b5fd0851  jmp 0x00007AA9B5DFE110
00007aa9b5fd0856  int3
00007aa9b5fd0857  int3
00007aa9b5fd0858  nop [rax+rax*1], eax
00007aa9b5fd0860  mov rax, [r15+0xF8]
00007aa9b5fd0867  lea r14, [rax+0x100]
00007aa9b5fd086e  mov [r15], r14
00007aa9b5fd0871  mov rax, [r15+0x98]
00007aa9b5fd0878  mov [r15+0x08], rax
00007aa9b5fd087c  mov qword ptr [r15+0x10], 0x12C
00007aa9b5fd0884  mov qword ptr [r15+0xF0], 0x410284
00007aa9b5fd088f  mov r14d, [r15+0x320]
00007aa9b5fd0896  mov eax, 0x410284
00007aa9b5fd089b  mov rcx, 0x7AA9B5FD07C0
00007aa9b5fd08a5  mov [r15+r14*8+0x328], rax
00007aa9b5fd08ad  mov [r15+r14*8+0x368], rcx
00007aa9b5fd08b5  add r14d, 0x01
00007aa9b5fd08b9  and r14d, 0x07
00007aa9b5fd08bd  mov [r15+0x320], r14d
00007aa9b5fd08c4  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd08cc  jz 0x00007AA9B5FCED70
00007aa9b5fd08d2  nop [rax+rax*1], ax
00007aa9b5fd08db  nop [rax+rax*1], eax
00007aa9b5fd08e3  mov eax, 0x410728
00007aa9b5fd08e8  mov [r15+0x100], rax
00007aa9b5fd08ef  jmp 0x00007AA9B5DFE110
00007aa9b5fd08f4  int3
00007aa9b5fd08f5  int3
00007aa9b5fd08f6  nop [rax+rax*1], ax
00007aa9b5fd08ff  nop
00007aa9b5fd0900  mov rax, [r15+0xF8]
00007aa9b5fd0907  lea r14, [rax+0x120]
00007aa9b5fd090e  mov r12, [r13+r14*1]
00007aa9b5fd0913  mov [r15+0x98], r12
00007aa9b5fd091a  mov qword ptr [r15+0x40], 0x80
00007aa9b5fd0922  lea r14, [rax+0x100]
00007aa9b5fd0929  mov [r15], r14
00007aa9b5fd092c  lea r14, [rax+0x17C]
00007aa9b5fd0933  mov [r15+0x08], r14
00007aa9b5fd0937  mov qword ptr [r15+0x10], 0x01
00007aa9b5fd093f  lea r14, [rax+0x17C]
00007aa9b5fd0946  mov eax, 0x80
00007aa9b5fd094b  mov [r13+r14*1], al
00007aa9b5fd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007aa9b5fd095b  mov r14d, [r15+0x320]
00007aa9b5fd0962  mov eax, 0x4102A8
00007aa9b5fd0967  mov rcx, 0x7AA9B5FD09E0
00007aa9b5fd0971  mov [r15+r14*8+0x328], rax
00007aa9b5fd0979  mov [r15+r14*8+0x368], rcx
00007aa9b5fd0981  add r14d, 0x01
00007aa9b5fd0985  and r14d, 0x07
00007aa9b5fd0989  mov [r15+0x320], r14d
00007aa9b5fd0990  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0998  jz 0x00007AA9B5FCED70
00007aa9b5fd099e  nop [rax+rax*1], ax
00007aa9b5fd09a7  nop [rax+rax*1], eax
00007aa9b5fd09af  mov eax, 0x410728
00007aa9b5fd09b4  mov [r15+0x100], rax
00007aa9b5fd09bb  jmp 0x00007AA9B5DFE110
00007aa9b5fd09c0  int3
00007aa9b5fd09c1  call 0x00007AA9B5EE27E0
00007aa9b5fd09c6  jmp 0x00007AA9B5FD0913
00007aa9b5fd09cb  call 0x00007AA9B5ED5AF0
00007aa9b5fd09d0  jmp 0x00007AA9B5FD0950
00007aa9b5fd09d5  int3
00007aa9b5fd09d6  nop [rax+rax*1], ax
00007aa9b5fd09df  nop
00007aa9b5fd09e0  mov rax, [r15+0xF8]
00007aa9b5fd09e7  lea r14, [rax+0x168]
00007aa9b5fd09ee  mov r12, [r13+r14*1]
00007aa9b5fd09f3  mov [r15+0x40], r12
00007aa9b5fd09f7  lea r14, [rax+0x178]
00007aa9b5fd09fe  xor eax, eax
00007aa9b5fd0a00  mov [r13+r14*1], al
00007aa9b5fd0a05  xor eax, eax
00007aa9b5fd0a07  mov r14d, 0x38
00007aa9b5fd0a0d  cmp r12, r14
00007aa9b5fd0a10  cmc
00007aa9b5fd0a11  lahf
00007aa9b5fd0a12  seto al
00007aa9b5fd0a15  mov [r15+0x108], eax
00007aa9b5fd0a1c  mov eax, [r15+0x108]
00007aa9b5fd0a23  sahf
00007aa9b5fd0a24  jz 0x00007AA9B5FD0A56
00007aa9b5fd0a26  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0a2e  jz 0x00007AA9B5FD0AA0
00007aa9b5fd0a34  nop [rax+rax*1], ax
00007aa9b5fd0a3d  nop [rax+rax*1], eax
00007aa9b5fd0a45  mov eax, 0x4102B8
00007aa9b5fd0a4a  mov [r15+0x100], rax
00007aa9b5fd0a51  jmp 0x00007AA9B5DFE110
00007aa9b5fd0a56  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0a5e  jz 0x00007AA9B5FD0BF0
00007aa9b5fd0a64  nop [rax+rax*1], ax
00007aa9b5fd0a6d  nop [rax+rax*1], eax
00007aa9b5fd0a75  mov eax, 0x4102D4
00007aa9b5fd0a7a  mov [r15+0x100], rax
00007aa9b5fd0a81  jmp 0x00007AA9B5DFE110
00007aa9b5fd0a86  int3
00007aa9b5fd0a87  call 0x00007AA9B5EE27E0
00007aa9b5fd0a8c  jmp 0x00007AA9B5FD09F3
00007aa9b5fd0a91  call 0x00007AA9B5ED5AF0
00007aa9b5fd0a96  jmp 0x00007AA9B5FD0A05
00007aa9b5fd0a9b  int3
00007aa9b5fd0a9c  nop [rax], eax
00007aa9b5fd0aa0  mov rax, [r15+0xF8]
00007aa9b5fd0aa7  lea r14, [rax+0x100]
00007aa9b5fd0aae  mov [r15], r14
00007aa9b5fd0ab1  lea r14, [rax+0x178]
00007aa9b5fd0ab8  mov [r15+0x08], r14
00007aa9b5fd0abc  mov qword ptr [r15+0x10], 0x01
00007aa9b5fd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007aa9b5fd0acf  mov r14d, [r15+0x320]
00007aa9b5fd0ad6  mov eax, 0x4102C8
00007aa9b5fd0adb  mov rcx, 0x7AA9B5FD0B40
00007aa9b5fd0ae5  mov [r15+r14*8+0x328], rax
00007aa9b5fd0aed  mov [r15+r14*8+0x368], rcx
00007aa9b5fd0af5  add r14d, 0x01
00007aa9b5fd0af9  and r14d, 0x07
00007aa9b5fd0afd  mov [r15+0x320], r14d
00007aa9b5fd0b04  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0b0c  jz 0x00007AA9B5FCED70
00007aa9b5fd0b12  nop [rax+rax*1], ax
00007aa9b5fd0b1b  nop [rax+rax*1], eax
00007aa9b5fd0b23  mov eax, 0x410728
00007aa9b5fd0b28  mov [r15+0x100], rax
00007aa9b5fd0b2f  jmp 0x00007AA9B5DFE110
00007aa9b5fd0b34  int3
00007aa9b5fd0b35  int3
00007aa9b5fd0b36  nop [rax+rax*1], ax
00007aa9b5fd0b3f  nop
00007aa9b5fd0b40  mov rax, [r15+0xF8]
00007aa9b5fd0b47  lea r14, [rax+0x168]
00007aa9b5fd0b4e  mov rax, [r13+r14*1]
00007aa9b5fd0b53  mov [r15+0x40], rax
00007aa9b5fd0b57  mov [rsp+0x10], rax
00007aa9b5fd0b5c  xor eax, eax
00007aa9b5fd0b5e  mov r14, [rsp+0x10]
00007aa9b5fd0b63  mov r12d, 0x38
00007aa9b5fd0b69  cmp r14, r12
00007aa9b5fd0b6c  cmc
00007aa9b5fd0b6d  lahf
00007aa9b5fd0b6e  seto al
00007aa9b5fd0b71  mov [r15+0x108], eax
00007aa9b5fd0b78  mov eax, [r15+0x108]
00007aa9b5fd0b7f  sahf
00007aa9b5fd0b80  jnz 0x00007AA9B5FD0BB2
00007aa9b5fd0b82  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0b8a  jz 0x00007AA9B5FD0BF0
00007aa9b5fd0b90  nop [rax+rax*1], ax
00007aa9b5fd0b99  nop [rax+rax*1], eax
00007aa9b5fd0ba1  mov eax, 0x4102D4
00007aa9b5fd0ba6  mov [r15+0x100], rax
00007aa9b5fd0bad  jmp 0x00007AA9B5DFE110
00007aa9b5fd0bb2  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0bba  jz 0x00007AA9B5FD0AA0
00007aa9b5fd0bc0  nop [rax+rax*1], ax
00007aa9b5fd0bc9  nop [rax+rax*1], eax
00007aa9b5fd0bd1  mov eax, 0x4102B8
00007aa9b5fd0bd6  mov [r15+0x100], rax
00007aa9b5fd0bdd  jmp 0x00007AA9B5DFE110
00007aa9b5fd0be2  int3
00007aa9b5fd0be3  call 0x00007AA9B5ED59C0
00007aa9b5fd0be8  jmp 0x00007AA9B5FD0B53
00007aa9b5fd0bed  int3
00007aa9b5fd0bee  nop
00007aa9b5fd0bf0  mov rax, [r15+0x98]
00007aa9b5fd0bf7  rorx r14, rax, 0x3D
00007aa9b5fd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007aa9b5fd0c01  mov rax, [r15+0xF8]
00007aa9b5fd0c08  lea r12, [rax+0x100]
00007aa9b5fd0c0f  mov [r15], r12
00007aa9b5fd0c12  lea r12, [rax+0x170]
00007aa9b5fd0c19  mov [r15+0x08], r12
00007aa9b5fd0c1d  mov qword ptr [r15+0x10], 0x08
00007aa9b5fd0c25  bswap r14
00007aa9b5fd0c28  mov [r15+0x40], r14
00007aa9b5fd0c2c  lea r12, [rax+0x170]
00007aa9b5fd0c33  mov [r13+r12*1], r14
00007aa9b5fd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007aa9b5fd0c43  mov r14d, [r15+0x320]
00007aa9b5fd0c4a  mov eax, 0x4102F0
00007aa9b5fd0c4f  mov rcx, 0x7AA9B5FD0CC0
00007aa9b5fd0c59  mov [r15+r14*8+0x328], rax
00007aa9b5fd0c61  mov [r15+r14*8+0x368], rcx
00007aa9b5fd0c69  add r14d, 0x01
00007aa9b5fd0c6d  and r14d, 0x07
00007aa9b5fd0c71  mov [r15+0x320], r14d
00007aa9b5fd0c78  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0c80  jz 0x00007AA9B5FCED70
00007aa9b5fd0c86  nop [rax+rax*1], ax
00007aa9b5fd0c8f  nop [rax+rax*1], eax
00007aa9b5fd0c97  mov eax, 0x410728
00007aa9b5fd0c9c  mov [r15+0x100], rax
00007aa9b5fd0ca3  jmp 0x00007AA9B5DFE110
00007aa9b5fd0ca8  int3
00007aa9b5fd0ca9  call 0x00007AA9B5EC3FE0
00007aa9b5fd0cae  jmp 0x00007AA9B5FD0C38
00007aa9b5fd0cb3  int3
00007aa9b5fd0cb4  nop [rax+rax*1], ax
00007aa9b5fd0cbd  nop [rax], eax
00007aa9b5fd0cc0  mov rax, [r15+0xF8]
00007aa9b5fd0cc7  lea r14, [rax+0x100]
00007aa9b5fd0cce  mov r12d, [r13+r14*1]
00007aa9b5fd0cd3  lea r14, [rax+0x104]
00007aa9b5fd0cda  mov r11d, [r13+r14*1]
00007aa9b5fd0cdf  mov qword ptr [r15+0x48], 0x430C90
00007aa9b5fd0ce7  lea r14, [rax+0x108]
00007aa9b5fd0cee  mov r10d, [r13+r14*1]
00007aa9b5fd0cf3  lea r14, [rax+0x10C]
00007aa9b5fd0cfa  mov r9d, [r13+r14*1]
00007aa9b5fd0cff  bswap r12d
00007aa9b5fd0d02  bswap r11d
00007aa9b5fd0d05  mov qword ptr [r15+0xA0], 0x00
00007aa9b5fd0d10  mov r14d, 0x430C90
00007aa9b5fd0d16  mov [r13+r14*1], r12d
00007aa9b5fd0d1b  mov r14d, 0x430C94
00007aa9b5fd0d21  mov [r13+r14*1], r11d
00007aa9b5fd0d26  bswap r10d
00007aa9b5fd0d29  lea r14, [rax+0x110]
00007aa9b5fd0d30  mov r12d, [r13+r14*1]
00007aa9b5fd0d35  bswap r9d
00007aa9b5fd0d38  lea r14, [rax+0x114]
00007aa9b5fd0d3f  mov r11d, [r13+r14*1]
00007aa9b5fd0d44  mov qword ptr [r15+0x98], 0x430DFC
00007aa9b5fd0d4f  mov r14d, 0x430C98
00007aa9b5fd0d55  mov [r13+r14*1], r10d
00007aa9b5fd0d5a  mov r14d, 0x430C9C
00007aa9b5fd0d60  mov [r13+r14*1], r9d
00007aa9b5fd0d65  bswap r12d
00007aa9b5fd0d68  lea r14, [rax+0x118]
00007aa9b5fd0d6f  mov r10d, [r13+r14*1]
00007aa9b5fd0d74  bswap r11d
00007aa9b5fd0d77  mov [rsp+0x10], r11d
00007aa9b5fd0d7c  mov r11d, r11d
00007aa9b5fd0d7f  mov [r15+0x58], r11
00007aa9b5fd0d83  lea r14, [rax+0x11C]
00007aa9b5fd0d8a  mov eax, [r13+r14*1]
00007aa9b5fd0d8f  mov [rsp+0x20], eax
00007aa9b5fd0d93  mov eax, eax
00007aa9b5fd0d95  mov [r15+0x60], rax
00007aa9b5fd0d99  mov eax, 0x430CA0
00007aa9b5fd0d9e  mov [r13+rax*1], r12d
00007aa9b5fd0da3  mov eax, 0x430CA4
00007aa9b5fd0da8  mov r14d, [rsp+0x10]
00007aa9b5fd0dad  mov [r13+rax*1], r14d
00007aa9b5fd0db2  bswap r10d
00007aa9b5fd0db5  mov [rsp+0x10], r10d
00007aa9b5fd0dba  mov r10d, r10d
00007aa9b5fd0dbd  mov [r15+0x40], r10
00007aa9b5fd0dc1  mov eax, [rsp+0x20]
00007aa9b5fd0dc5  bswap eax
00007aa9b5fd0dc7  mov [rsp+0x20], eax
00007aa9b5fd0dcb  mov eax, eax
00007aa9b5fd0dcd  mov [r15+0x50], rax
00007aa9b5fd0dd1  mov eax, 0x430CA8
00007aa9b5fd0dd6  mov r14d, [rsp+0x10]
00007aa9b5fd0ddb  mov [r13+rax*1], r14d
00007aa9b5fd0de0  mov eax, 0x430CAC
00007aa9b5fd0de5  mov r14d, [rsp+0x20]
00007aa9b5fd0dea  mov [r13+rax*1], r14d
00007aa9b5fd0def  mov eax, [r15+0xA0]
00007aa9b5fd0df6  lea r14d, [eax+0x11]
00007aa9b5fd0dfb  mov r14d, r14d
00007aa9b5fd0dfe  mov [r15], r14
00007aa9b5fd0e01  mov qword ptr [r15+0xF0], 0x41035C
00007aa9b5fd0e0c  mov r14d, [r15+0x320]
00007aa9b5fd0e13  mov eax, 0x41035C
00007aa9b5fd0e18  mov rcx, 0x7AA9B5FD0F90
00007aa9b5fd0e22  mov [r15+r14*8+0x328], rax
00007aa9b5fd0e2a  mov [r15+r14*8+0x368], rcx
00007aa9b5fd0e32  add r14d, 0x01
00007aa9b5fd0e36  and r14d, 0x07
00007aa9b5fd0e3a  mov [r15+0x320], r14d
00007aa9b5fd0e41  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0e49  jz 0x00007AA9B5FD0F20
00007aa9b5fd0e4f  nop [rax+rax*1], ax
00007aa9b5fd0e58  nop [rax+rax*1], eax
00007aa9b5fd0e60  mov eax, 0x4109A4
00007aa9b5fd0e65  mov [r15+0x100], rax
00007aa9b5fd0e6c  jmp 0x00007AA9B5DFE110
00007aa9b5fd0e71  int3
00007aa9b5fd0e72  call 0x00007AA9B5EE26A0
00007aa9b5fd0e77  jmp 0x00007AA9B5FD0CD3
00007aa9b5fd0e7c  call 0x00007AA9B5EE1430
00007aa9b5fd0e81  jmp 0x00007AA9B5FD0CDF
00007aa9b5fd0e86  call 0x00007AA9B5EE01C0
00007aa9b5fd0e8b  jmp 0x00007AA9B5FD0CF3
00007aa9b5fd0e90  call 0x00007AA9B5EDEF50
00007aa9b5fd0e95  jmp 0x00007AA9B5FD0CFF
00007aa9b5fd0e9a  call 0x00007AA9B5EE2BA0
00007aa9b5fd0e9f  jmp 0x00007AA9B5FD0D1B
00007aa9b5fd0ea4  call 0x00007AA9B5EE1920
00007aa9b5fd0ea9  jmp 0x00007AA9B5FD0D26
00007aa9b5fd0eae  call 0x00007AA9B5EE26A0
00007aa9b5fd0eb3  jmp 0x00007AA9B5FD0D35
00007aa9b5fd0eb8  call 0x00007AA9B5EE1430
00007aa9b5fd0ebd  jmp 0x00007AA9B5FD0D44
00007aa9b5fd0ec2  call 0x00007AA9B5EE06B0
00007aa9b5fd0ec7  jmp 0x00007AA9B5FD0D5A
00007aa9b5fd0ecc  call 0x00007AA9B5EDF440
00007aa9b5fd0ed1  jmp 0x00007AA9B5FD0D65
00007aa9b5fd0ed6  call 0x00007AA9B5EE01C0
00007aa9b5fd0edb  jmp 0x00007AA9B5FD0D74
00007aa9b5fd0ee0  call 0x00007AA9B5ED5890
00007aa9b5fd0ee5  jmp 0x00007AA9B5FD0D8F
00007aa9b5fd0eea  call 0x00007AA9B5E0BAE0
00007aa9b5fd0eef  jmp 0x00007AA9B5FD0DA3
00007aa9b5fd0ef4  call 0x00007AA9B5E0DFE0
00007aa9b5fd0ef9  jmp 0x00007AA9B5FD0DB2
00007aa9b5fd0efe  call 0x00007AA9B5E0DFE0
00007aa9b5fd0f03  jmp 0x00007AA9B5FD0DE0
00007aa9b5fd0f08  call 0x00007AA9B5E0DFE0
00007aa9b5fd0f0d  jmp 0x00007AA9B5FD0DEF
00007aa9b5fd0f12  int3
00007aa9b5fd0f13  nop [rax+rax*1], ax
00007aa9b5fd0f1c  nop [rax], eax
00007aa9b5fd0f20  mov eax, [r15]
00007aa9b5fd0f23  mov [rsp+0x10], eax
00007aa9b5fd0f27  shr eax, 0x10
00007aa9b5fd0f2a  mov r14d, [rsp+0x10]
00007aa9b5fd0f2f  xor r14d, eax
00007aa9b5fd0f32  imul r14d, r14d, 0x7FEB352D
00007aa9b5fd0f39  mov eax, 0x846CA68B
00007aa9b5fd0f3e  mov eax, eax
00007aa9b5fd0f40  mov [r15+0x48], rax
00007aa9b5fd0f44  mov [rsp+0x10], r14d
00007aa9b5fd0f49  shr r14d, 0x0F
00007aa9b5fd0f4d  mov eax, [rsp+0x10]
00007aa9b5fd0f51  xor eax, r14d
00007aa9b5fd0f54  imul eax, eax, 0x846CA68B
00007aa9b5fd0f5a  mov [rsp+0x10], eax
00007aa9b5fd0f5e  mov eax, eax
00007aa9b5fd0f60  mov [r15+0x40], rax
00007aa9b5fd0f64  mov eax, [rsp+0x10]
00007aa9b5fd0f68  shr eax, 0x10
00007aa9b5fd0f6b  mov r14d, [rsp+0x10]
00007aa9b5fd0f70  xor r14d, eax
00007aa9b5fd0f73  mov r14d, r14d
00007aa9b5fd0f76  mov [r15], r14
00007aa9b5fd0f79  mov rax, [r15+0xF0]
00007aa9b5fd0f80  mov [r15+0x100], rax
00007aa9b5fd0f87  jmp 0x00007AA9B5FCE5C0
00007aa9b5fd0f8c  int3
00007aa9b5fd0f8d  int3
00007aa9b5fd0f8e  nop
00007aa9b5fd0f90  mov rax, [r15+0xA0]
00007aa9b5fd0f97  mov [rsp+0x10], rax
00007aa9b5fd0f9c  shl rax, 0x02
00007aa9b5fd0fa0  mov r14, [r15+0x98]
00007aa9b5fd0fa7  lea r12, [r14+rax*1]
00007aa9b5fd0fab  mov eax, [r15]
00007aa9b5fd0fae  mov [r13+r12*1], eax
00007aa9b5fd0fb3  mov rax, [rsp+0x10]
00007aa9b5fd0fb8  lea r14, [rax+0x01]
00007aa9b5fd0fbc  mov [r15+0xA0], r14
00007aa9b5fd0fc3  xor eax, eax
00007aa9b5fd0fc5  mov r12d, 0x400
00007aa9b5fd0fcb  cmp r14, r12
00007aa9b5fd0fce  cmc
00007aa9b5fd0fcf  lahf
00007aa9b5fd0fd0  seto al
00007aa9b5fd0fd3  mov [r15+0x108], eax
00007aa9b5fd0fda  mov eax, [r15+0x108]
00007aa9b5fd0fe1  sahf
00007aa9b5fd0fe2  jnz 0x00007AA9B5FD1014
00007aa9b5fd0fe4  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd0fec  jz 0x00007AA9B5FD10E0
00007aa9b5fd0ff2  nop [rax+rax*1], ax
00007aa9b5fd0ffb  nop [rax+rax*1], eax
00007aa9b5fd1003  mov eax, 0x41036C
00007aa9b5fd1008  mov [r15+0x100], rax
00007aa9b5fd100f  jmp 0x00007AA9B5DFE110
00007aa9b5fd1014  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd101c  jz 0x00007AA9B5FD1050
00007aa9b5fd1022  nop [rax+rax*1], ax
00007aa9b5fd102b  nop [rax+rax*1], eax
00007aa9b5fd1033  mov eax, 0x410354
00007aa9b5fd1038  mov [r15+0x100], rax
00007aa9b5fd103f  jmp 0x00007AA9B5DFE110
00007aa9b5fd1044  int3
00007aa9b5fd1045  call 0x00007AA9B5EB4B70
00007aa9b5fd104a  jmp 0x00007AA9B5FD0FB3
00007aa9b5fd104f  int3
00007aa9b5fd1050  mov eax, [r15+0xA0]
00007aa9b5fd1057  lea r14d, [eax+0x11]
00007aa9b5fd105c  mov r14d, r14d
00007aa9b5fd105f  mov [r15], r14
00007aa9b5fd1062  mov qword ptr [r15+0xF0], 0x41035C
00007aa9b5fd106d  mov r14d, [r15+0x320]
00007aa9b5fd1074  mov eax, 0x41035C
00007aa9b5fd1079  mov rcx, 0x7AA9B5FD0F90
00007aa9b5fd1083  mov [r15+r14*8+0x328], rax
00007aa9b5fd108b  mov [r15+r14*8+0x368], rcx
00007aa9b5fd1093  add r14d, 0x01
00007aa9b5fd1097  and r14d, 0x07
00007aa9b5fd109b  mov [r15+0x320], r14d
00007aa9b5fd10a2  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd10aa  jz 0x00007AA9B5FD0F20
00007aa9b5fd10b0  nop [rax+rax*1], ax
00007aa9b5fd10b9  nop [rax+rax*1], eax
00007aa9b5fd10c1  mov eax, 0x4109A4
00007aa9b5fd10c6  mov [r15+0x100], rax
00007aa9b5fd10cd  jmp 0x00007AA9B5DFE110
00007aa9b5fd10d2  int3
00007aa9b5fd10d3  int3
00007aa9b5fd10d4  nop [rax+rax*1], ax
00007aa9b5fd10dd  nop [rax], eax
00007aa9b5fd10e0  mov qword ptr [r15+0x40], 0x01
00007aa9b5fd10e8  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd10f0  jz 0x00007AA9B5FD1120
00007aa9b5fd10f6  nop [rax+rax*1], ax
00007aa9b5fd10ff  nop [rax+rax*1], eax
00007aa9b5fd1107  mov eax, 0x410388
00007aa9b5fd110c  mov [r15+0x100], rax
00007aa9b5fd1113  jmp 0x00007AA9B5DFE110
00007aa9b5fd1118  int3
00007aa9b5fd1119  int3
00007aa9b5fd111a  nop [rax+rax*1], ax
00007aa9b5fd1120  mov rax, [r15+0x40]
00007aa9b5fd1124  mov [rsp+0x10], rax
00007aa9b5fd1129  shl rax, 0x02
00007aa9b5fd112d  mov r14, [r15+0x98]
00007aa9b5fd1134  lea r12, [r14+rax*1]
00007aa9b5fd1138  mov eax, [r13+r12*1]
00007aa9b5fd113d  mov [rsp+0x20], eax
00007aa9b5fd1141  mov eax, eax
00007aa9b5fd1143  mov [r15+0x48], rax
00007aa9b5fd1147  mov rax, [rsp+0x10]
00007aa9b5fd114c  mov [r15+0x50], rax
00007aa9b5fd1150  mov eax, [r15+0x50]
00007aa9b5fd1154  lea r12d, [eax-0x01]
00007aa9b5fd1159  mov r12d, r12d
00007aa9b5fd115c  mov [r15+0x58], r12
00007aa9b5fd1160  mov rax, [r15+0x58]
00007aa9b5fd1164  mov r12d, eax
00007aa9b5fd1167  mov r12d, r12d
00007aa9b5fd116a  shl r12, 0x02
00007aa9b5fd116e  lea rax, [r14+r12*1]
00007aa9b5fd1172  mov r14d, [r13+rax*1]
00007aa9b5fd1177  mov [rsp+0x10], r14d
00007aa9b5fd117c  mov r14d, r14d
00007aa9b5fd117f  mov [r15+0x60], r14
00007aa9b5fd1183  xor eax, eax
00007aa9b5fd1185  mov r14d, [rsp+0x10]
00007aa9b5fd118a  mov r12d, [rsp+0x20]
00007aa9b5fd118f  cmp r14d, r12d
00007aa9b5fd1192  cmc
00007aa9b5fd1193  lahf
00007aa9b5fd1194  seto al
00007aa9b5fd1197  mov [r15+0x108], eax
00007aa9b5fd119e  mov eax, [r15+0x108]
00007aa9b5fd11a5  sahf
00007aa9b5fd11a6  cmc
00007aa9b5fd11a7  jbe 0x00007AA9B5FD11D9
00007aa9b5fd11a9  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd11b1  jz 0x00007AA9B5FD1220
00007aa9b5fd11b7  nop [rax+rax*1], ax
00007aa9b5fd11c0  nop [rax+rax*1], eax
00007aa9b5fd11c8  mov eax, 0x4103A0
00007aa9b5fd11cd  mov [r15+0x100], rax
00007aa9b5fd11d4  jmp 0x00007AA9B5DFE110
00007aa9b5fd11d9  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd11e1  jz 0x00007AA9B5FD14C0
00007aa9b5fd11e7  nop [rax+rax*1], ax
00007aa9b5fd11f0  nop [rax+rax*1], eax
00007aa9b5fd11f8  mov eax, 0x410378
00007aa9b5fd11fd  mov [r15+0x100], rax
00007aa9b5fd1204  jmp 0x00007AA9B5DFE110
00007aa9b5fd1209  int3
00007aa9b5fd120a  call 0x00007AA9B5EB4690
00007aa9b5fd120f  jmp 0x00007AA9B5FD113D
00007aa9b5fd1214  call 0x00007AA9B5E0DAE0
00007aa9b5fd1219  jmp 0x00007AA9B5FD1177
00007aa9b5fd121e  int3
00007aa9b5fd121f  nop
00007aa9b5fd1220  mov rax, [r15+0x50]
00007aa9b5fd1224  mov [rsp+0x10], rax
00007aa9b5fd1229  shl rax, 0x02
00007aa9b5fd122d  mov r14, [r15+0x98]
00007aa9b5fd1234  lea r12, [r14+rax*1]
00007aa9b5fd1238  mov eax, [r15+0x60]
00007aa9b5fd123c  mov [r13+r12*1], eax
00007aa9b5fd1241  mov rax, [rsp+0x10]
00007aa9b5fd1246  lea r14, [rax-0x01]
00007aa9b5fd124a  mov [r15+0x50], r14
00007aa9b5fd124e  mov rax, [r15+0x58]
00007aa9b5fd1252  test rax, rax
00007aa9b5fd1255  setz al
00007aa9b5fd1258  movzx rax, al
00007aa9b5fd125c  mov [rsp+0x414], al
00007aa9b5fd1263  cmp byte ptr [rsp+0x414], 0x00
00007aa9b5fd126b  jz 0x00007AA9B5FD129D
00007aa9b5fd126d  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd1275  jz 0x00007AA9B5FD12E0
00007aa9b5fd127b  nop [rax+rax*1], ax
00007aa9b5fd1284  nop [rax+rax*1], eax
00007aa9b5fd128c  mov eax, 0x4103AC
00007aa9b5fd1291  mov [r15+0x100], rax
00007aa9b5fd1298  jmp 0x00007AA9B5DFE110
00007aa9b5fd129d  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd12a5  jz 0x00007AA9B5FD13E0
00007aa9b5fd12ab  nop [rax+rax*1], ax
00007aa9b5fd12b4  nop [rax+rax*1], eax
00007aa9b5fd12bc  mov eax, 0x410390
00007aa9b5fd12c1  mov [r15+0x100], rax
00007aa9b5fd12c8  jmp 0x00007AA9B5DFE110
00007aa9b5fd12cd  int3
00007aa9b5fd12ce  call 0x00007AA9B5EB4B70
00007aa9b5fd12d3  jmp 0x00007AA9B5FD1241
00007aa9b5fd12d8  int3
00007aa9b5fd12d9  nop [rax], eax
00007aa9b5fd12e0  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd12e8  jz 0x00007AA9B5FD1320
00007aa9b5fd12ee  nop [rax+rax*1], ax
00007aa9b5fd12f7  nop [rax+rax*1], eax
00007aa9b5fd12ff  mov eax, 0x410374
00007aa9b5fd1304  mov [r15+0x100], rax
00007aa9b5fd130b  jmp 0x00007AA9B5DFE110
00007aa9b5fd1310  int3
00007aa9b5fd1311  int3
00007aa9b5fd1312  nop [rax+rax*1], ax
00007aa9b5fd131b  nop [rax+rax*1], eax
00007aa9b5fd1320  mov qword ptr [r15+0x50], 0x00
00007aa9b5fd1328  mov rax, [r15+0x40]
00007aa9b5fd132c  lea r14, [rax+0x01]
00007aa9b5fd1330  mov [r15+0x40], r14
00007aa9b5fd1334  mov rax, [r15+0x98]
00007aa9b5fd133b  mov r12d, [r15+0x48]
00007aa9b5fd133f  mov [r13+rax*1], r12d
00007aa9b5fd1344  xor eax, eax
00007aa9b5fd1346  mov r12d, 0x400
00007aa9b5fd134c  cmp r14, r12
00007aa9b5fd134f  cmc
00007aa9b5fd1350  lahf
00007aa9b5fd1351  seto al
00007aa9b5fd1354  mov [r15+0x108], eax
00007aa9b5fd135b  mov eax, [r15+0x108]
00007aa9b5fd1362  sahf
00007aa9b5fd1363  jz 0x00007AA9B5FD1395
00007aa9b5fd1365  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd136d  jz 0x00007AA9B5FD1120
00007aa9b5fd1373  nop [rax+rax*1], ax
00007aa9b5fd137c  nop [rax+rax*1], eax
00007aa9b5fd1384  mov eax, 0x410388
00007aa9b5fd1389  mov [r15+0x100], rax
00007aa9b5fd1390  jmp 0x00007AA9B5DFE110
00007aa9b5fd1395  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd139d  jz 0x00007AA9B5FD1580
00007aa9b5fd13a3  nop [rax+rax*1], ax
00007aa9b5fd13ac  nop [rax+rax*1], eax
00007aa9b5fd13b4  mov eax, 0x4103B0
00007aa9b5fd13b9  mov [r15+0x100], rax
00007aa9b5fd13c0  jmp 0x00007AA9B5DFE110
00007aa9b5fd13c5  int3
00007aa9b5fd13c6  call 0x00007AA9B5E0BAE0
00007aa9b5fd13cb  jmp 0x00007AA9B5FD1344
00007aa9b5fd13d0  int3
00007aa9b5fd13d1  nop [rax+rax*1], ax
00007aa9b5fd13da  nop [rax+rax*1], ax
00007aa9b5fd13e0  mov eax, [r15+0x50]
00007aa9b5fd13e4  lea r14d, [eax-0x01]
00007aa9b5fd13e9  mov r14d, r14d
00007aa9b5fd13ec  mov [r15+0x58], r14
00007aa9b5fd13f0  mov rax, [r15+0x58]
00007aa9b5fd13f4  mov r14d, eax
00007aa9b5fd13f7  mov r14d, r14d
00007aa9b5fd13fa  shl r14, 0x02
00007aa9b5fd13fe  mov rax, [r15+0x98]
00007aa9b5fd1405  lea r12, [rax+r14*1]
00007aa9b5fd1409  mov eax, [r13+r12*1]
00007aa9b5fd140e  mov [rsp+0x10], eax
00007aa9b5fd1412  mov eax, eax
00007aa9b5fd1414  mov [r15+0x60], rax
00007aa9b5fd1418  mov eax, [r15+0x48]
00007aa9b5fd141c  mov [rsp+0x20], eax
00007aa9b5fd1420  xor eax, eax
00007aa9b5fd1422  mov r14d, [rsp+0x10]
00007aa9b5fd1427  mov r12d, [rsp+0x20]
00007aa9b5fd142c  cmp r14d, r12d
00007aa9b5fd142f  cmc
00007aa9b5fd1430  lahf
00007aa9b5fd1431  seto al
00007aa9b5fd1434  mov [r15+0x108], eax
00007aa9b5fd143b  mov eax, [r15+0x108]
00007aa9b5fd1442  sahf
00007aa9b5fd1443  cmc
00007aa9b5fd1444  jbe 0x00007AA9B5FD1476
00007aa9b5fd1446  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd144e  jz 0x00007AA9B5FD1220
00007aa9b5fd1454  nop [rax+rax*1], ax
00007aa9b5fd145d  nop [rax+rax*1], eax
00007aa9b5fd1465  mov eax, 0x4103A0
00007aa9b5fd146a  mov [r15+0x100], rax
00007aa9b5fd1471  jmp 0x00007AA9B5DFE110
00007aa9b5fd1476  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd147e  jz 0x00007AA9B5FD14C0
00007aa9b5fd1484  nop [rax+rax*1], ax
00007aa9b5fd148d  nop [rax+rax*1], eax
00007aa9b5fd1495  mov eax, 0x410378
00007aa9b5fd149a  mov [r15+0x100], rax
00007aa9b5fd14a1  jmp 0x00007AA9B5DFE110
00007aa9b5fd14a6  int3
00007aa9b5fd14a7  call 0x00007AA9B5EB4690
00007aa9b5fd14ac  jmp 0x00007AA9B5FD140E
00007aa9b5fd14b1  int3
00007aa9b5fd14b2  nop [rax+rax*1], ax
00007aa9b5fd14bb  nop [rax+rax*1], eax
00007aa9b5fd14c0  mov rax, [r15+0x40]
00007aa9b5fd14c4  lea r14, [rax+0x01]
00007aa9b5fd14c8  mov [r15+0x40], r14
00007aa9b5fd14cc  mov rax, [r15+0x50]
00007aa9b5fd14d0  mov r12d, eax
00007aa9b5fd14d3  mov r12d, r12d
00007aa9b5fd14d6  shl r12, 0x02
00007aa9b5fd14da  mov rax, [r15+0x98]
00007aa9b5fd14e1  lea r11, [rax+r12*1]
00007aa9b5fd14e5  mov eax, [r15+0x48]
00007aa9b5fd14e9  mov [r13+r11*1], eax
00007aa9b5fd14ee  xor eax, eax
00007aa9b5fd14f0  mov r12d, 0x400
00007aa9b5fd14f6  cmp r14, r12
00007aa9b5fd14f9  cmc
00007aa9b5fd14fa  lahf
00007aa9b5fd14fb  seto al
00007aa9b5fd14fe  mov [r15+0x108], eax
00007aa9b5fd1505  mov eax, [r15+0x108]
00007aa9b5fd150c  sahf
00007aa9b5fd150d  jz 0x00007AA9B5FD153F
00007aa9b5fd150f  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd1517  jz 0x00007AA9B5FD1120
00007aa9b5fd151d  nop [rax+rax*1], ax
00007aa9b5fd1526  nop [rax+rax*1], eax
00007aa9b5fd152e  mov eax, 0x410388
00007aa9b5fd1533  mov [r15+0x100], rax
00007aa9b5fd153a  jmp 0x00007AA9B5DFE110
00007aa9b5fd153f  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd1547  jz 0x00007AA9B5FD1580
00007aa9b5fd154d  nop [rax+rax*1], ax
00007aa9b5fd1556  nop [rax+rax*1], eax
00007aa9b5fd155e  mov eax, 0x4103B0
00007aa9b5fd1563  mov [r15+0x100], rax
00007aa9b5fd156a  jmp 0x00007AA9B5DFE110
00007aa9b5fd156f  int3
00007aa9b5fd1570  call 0x00007AA9B5EA4270
00007aa9b5fd1575  jmp 0x00007AA9B5FD14EE
00007aa9b5fd157a  int3
00007aa9b5fd157b  nop [rax+rax*1], eax
00007aa9b5fd1580  mov qword ptr [r15+0x40], 0x430000
00007aa9b5fd1588  mov eax, 0x430CB0
00007aa9b5fd158d  mov r14, [r13+rax*1]
00007aa9b5fd1592  mov rax, [r15+0x98]
00007aa9b5fd1599  mov r12d, [r13+rax*1]
00007aa9b5fd159e  lea r11, [rax+0x04]
00007aa9b5fd15a2  mov eax, [r13+r11*1]
00007aa9b5fd15a7  mov r12d, r12d
00007aa9b5fd15aa  mov [r15+0x68], r12
00007aa9b5fd15ae  mov eax, eax
00007aa9b5fd15b0  mov [r15+0x60], rax
00007aa9b5fd15b4  mov rax, [r15+0x68]
00007aa9b5fd15b8  mov [r15+0x68], rax
00007aa9b5fd15bc  mov qword ptr [r15+0x58], 0x02
00007aa9b5fd15c4  mov [rsp+0x10], rax
00007aa9b5fd15c9  xor eax, eax
00007aa9b5fd15cb  mov r12d, 0x02
00007aa9b5fd15d1  mov r11d, 0x400
00007aa9b5fd15d7  cmp r12, r11
00007aa9b5fd15da  cmc
00007aa9b5fd15db  lahf
00007aa9b5fd15dc  seto al
00007aa9b5fd15df  mov [r15+0x108], eax
00007aa9b5fd15e6  mov rax, [r15+0x60]
00007aa9b5fd15ea  mov r12d, 0x02
00007aa9b5fd15f0  imul rax, r12
00007aa9b5fd15f4  mov [r15+0x50], rax
00007aa9b5fd15f8  mov rax, [rsp+0x10]
00007aa9b5fd15fd  lea r12, [rax+r14*1]
00007aa9b5fd1601  mov [r15+0x48], r12
00007aa9b5fd1605  mov eax, [r15+0x108]
00007aa9b5fd160c  sahf
00007aa9b5fd160d  jnz 0x00007AA9B5FD163F
00007aa9b5fd160f  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd1617  jz 0x00007AA9B5FD17B0
00007aa9b5fd161d  nop [rax+rax*1], ax
00007aa9b5fd1626  nop [rax+rax*1], eax
00007aa9b5fd162e  mov eax, 0x4103E0
00007aa9b5fd1633  mov [r15+0x100], rax
00007aa9b5fd163a  jmp 0x00007AA9B5DFE110
00007aa9b5fd163f  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd1647  jz 0x00007AA9B5FD1690
00007aa9b5fd164d  nop [rax+rax*1], ax
00007aa9b5fd1656  nop [rax+rax*1], eax
00007aa9b5fd165e  mov eax, 0x4103C0
00007aa9b5fd1663  mov [r15+0x100], rax
00007aa9b5fd166a  jmp 0x00007AA9B5DFE110
00007aa9b5fd166f  int3
00007aa9b5fd1670  call 0x00007AA9B5E0DC20
00007aa9b5fd1675  jmp 0x00007AA9B5FD1592
00007aa9b5fd167a  call 0x00007AA9B5E0B5E0
00007aa9b5fd167f  jmp 0x00007AA9B5FD159E
00007aa9b5fd1684  call 0x00007AA9B5EA3D90
00007aa9b5fd1689  jmp 0x00007AA9B5FD15A7
00007aa9b5fd168e  int3
00007aa9b5fd168f  nop
00007aa9b5fd1690  mov rax, [r15+0x98]
00007aa9b5fd1697  mov r14, [r15+0x58]
00007aa9b5fd169b  mov [rsp+0x10], r14
00007aa9b5fd16a0  shl r14, 0x02
00007aa9b5fd16a4  lea r12, [rax+r14*1]
00007aa9b5fd16a8  mov eax, [r13+r12*1]
00007aa9b5fd16ad  lea r14, [r12+0x04]
00007aa9b5fd16b2  mov r12d, [r13+r14*1]
00007aa9b5fd16b7  mov eax, eax
00007aa9b5fd16b9  mov [r15+0x68], rax
00007aa9b5fd16bd  mov r12d, r12d
00007aa9b5fd16c0  mov [r15+0x60], r12
00007aa9b5fd16c4  mov rax, [r15+0x68]
00007aa9b5fd16c8  mov [rsp+0x20], rax
00007aa9b5fd16cd  mov r14, [rsp+0x10]
00007aa9b5fd16d2  imul rax, r14
00007aa9b5fd16d6  mov r12, [rsp+0x20]
00007aa9b5fd16db  lea r11, [r12+rax*1]
00007aa9b5fd16df  mov [r15+0x68], r11
00007aa9b5fd16e3  lea rax, [r14+0x02]
00007aa9b5fd16e7  mov [r15+0x58], rax
00007aa9b5fd16eb  mov [rsp+0x10], rax
00007aa9b5fd16f0  xor eax, eax
00007aa9b5fd16f2  mov r14, [rsp+0x10]
00007aa9b5fd16f7  mov r12d, 0x400
00007aa9b5fd16fd  cmp r14, r12
00007aa9b5fd1700  cmc
00007aa9b5fd1701  lahf
00007aa9b5fd1702  seto al
00007aa9b5fd1705  mov [r15+0x108], eax
00007aa9b5fd170c  mov rax, [r15+0x50]
00007aa9b5fd1710  mov r12, [r15+0x60]
00007aa9b5fd1714  imul r14, r12
00007aa9b5fd1718  lea r12, [rax+r14*1]
00007aa9b5fd171c  mov [r15+0x50], r12
00007aa9b5fd1720  mov rax, [r15+0x48]
00007aa9b5fd1724  lea r14, [r11+rax*1]
00007aa9b5fd1728  mov [r15+0x48], r14
00007aa9b5fd172c  mov eax, [r15+0x108]
00007aa9b5fd1733  sahf
00007aa9b5fd1734  jnz 0x00007AA9B5FD1766
00007aa9b5fd1736  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd173e  jz 0x00007AA9B5FD17B0
00007aa9b5fd1744  nop [rax+rax*1], ax
00007aa9b5fd174d  nop [rax+rax*1], eax
00007aa9b5fd1755  mov eax, 0x4103E0
00007aa9b5fd175a  mov [r15+0x100], rax
00007aa9b5fd1761  jmp 0x00007AA9B5DFE110
00007aa9b5fd1766  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd176e  jz 0x00007AA9B5FD1690
00007aa9b5fd1774  nop [rax+rax*1], ax
00007aa9b5fd177d  nop [rax+rax*1], eax
00007aa9b5fd1785  mov eax, 0x4103C0
00007aa9b5fd178a  mov [r15+0x100], rax
00007aa9b5fd1791  jmp 0x00007AA9B5DFE110
00007aa9b5fd1796  int3
00007aa9b5fd1797  call 0x00007AA9B5EB4690
00007aa9b5fd179c  jmp 0x00007AA9B5FD16AD
00007aa9b5fd17a1  call 0x00007AA9B5EE26A0
00007aa9b5fd17a6  jmp 0x00007AA9B5FD16B7
00007aa9b5fd17ab  int3
00007aa9b5fd17ac  nop [rax], eax
00007aa9b5fd17b0  mov qword ptr [r15+0x98], 0x00
00007aa9b5fd17bb  mov rax, [r15+0x50]
00007aa9b5fd17bf  mov r14, [r15+0x48]
00007aa9b5fd17c3  lea r12, [rax+r14*1]
00007aa9b5fd17c7  mov [r15+0x48], r12
00007aa9b5fd17cb  mov rax, [r15+0x40]
00007aa9b5fd17cf  lea r14, [rax+0xCB0]
00007aa9b5fd17d6  mov [r13+r14*1], r12
00007aa9b5fd17db  mov qword ptr [r15], 0x01
00007aa9b5fd17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007aa9b5fd17ed  mov r14d, [r15+0x320]
00007aa9b5fd17f4  mov eax, 0x4103F8
00007aa9b5fd17f9  mov rcx, 0x7AA9B5FD1860
00007aa9b5fd1803  mov [r15+r14*8+0x328], rax
00007aa9b5fd180b  mov [r15+r14*8+0x368], rcx
00007aa9b5fd1813  add r14d, 0x01
00007aa9b5fd1817  and r14d, 0x07
00007aa9b5fd181b  mov [r15+0x320], r14d
00007aa9b5fd1822  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd182a  jz 0x00007AA9B5FD0F20
00007aa9b5fd1830  nop [rax+rax*1], ax
00007aa9b5fd1839  nop [rax+rax*1], eax
00007aa9b5fd1841  mov eax, 0x4109A4
00007aa9b5fd1846  mov [r15+0x100], rax
00007aa9b5fd184d  jmp 0x00007AA9B5DFE110
00007aa9b5fd1852  int3
00007aa9b5fd1853  call 0x00007AA9B5EE2CE0
00007aa9b5fd1858  jmp 0x00007AA9B5FD17DB
00007aa9b5fd185d  int3
00007aa9b5fd185e  nop
00007aa9b5fd1860  mov eax, [r15+0x98]
00007aa9b5fd1867  lea r14d, [eax+0x01]
00007aa9b5fd186c  mov [rsp+0x10], r14d
00007aa9b5fd1871  mov r14d, r14d
00007aa9b5fd1874  mov [r15+0x98], r14
00007aa9b5fd187b  xor eax, eax
00007aa9b5fd187d  mov r14d, [rsp+0x10]
00007aa9b5fd1882  cmp r14d, 0x10000
00007aa9b5fd1889  cmc
00007aa9b5fd188a  lahf
00007aa9b5fd188b  seto al
00007aa9b5fd188e  mov [r15+0x108], eax
00007aa9b5fd1895  mov eax, [r15+0x108]
00007aa9b5fd189c  sahf
00007aa9b5fd189d  jnz 0x00007AA9B5FD18CF
00007aa9b5fd189f  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd18a7  jz 0x00007AA9B5FD19A0
00007aa9b5fd18ad  nop [rax+rax*1], ax
00007aa9b5fd18b6  nop [rax+rax*1], eax
00007aa9b5fd18be  mov eax, 0x410404
00007aa9b5fd18c3  mov [r15+0x100], rax
00007aa9b5fd18ca  jmp 0x00007AA9B5DFE110
00007aa9b5fd18cf  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd18d7  jz 0x00007AA9B5FD1910
00007aa9b5fd18dd  nop [rax+rax*1], ax
00007aa9b5fd18e6  nop [rax+rax*1], eax
00007aa9b5fd18ee  mov eax, 0x4103F0
00007aa9b5fd18f3  mov [r15+0x100], rax
00007aa9b5fd18fa  jmp 0x00007AA9B5DFE110
00007aa9b5fd18ff  int3
00007aa9b5fd1900  int3
00007aa9b5fd1901  nop [rax+rax*1], ax
00007aa9b5fd190a  nop [rax+rax*1], ax
00007aa9b5fd1910  mov eax, [r15]
00007aa9b5fd1913  mov r14d, [r15+0x98]
00007aa9b5fd191a  lea r12d, [eax+r14d*1]
00007aa9b5fd191f  mov r12d, r12d
00007aa9b5fd1922  mov [r15], r12
00007aa9b5fd1925  mov qword ptr [r15+0xF0], 0x4103F8
00007aa9b5fd1930  mov r14d, [r15+0x320]
00007aa9b5fd1937  mov eax, 0x4103F8
00007aa9b5fd193c  mov rcx, 0x7AA9B5FD1860
00007aa9b5fd1946  mov [r15+r14*8+0x328], rax
00007aa9b5fd194e  mov [r15+r14*8+0x368], rcx
00007aa9b5fd1956  add r14d, 0x01
00007aa9b5fd195a  and r14d, 0x07
00007aa9b5fd195e  mov [r15+0x320], r14d
00007aa9b5fd1965  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd196d  jz 0x00007AA9B5FD0F20
00007aa9b5fd1973  nop [rax+rax*1], ax
00007aa9b5fd197c  nop [rax+rax*1], eax
00007aa9b5fd1984  mov eax, 0x4109A4
00007aa9b5fd1989  mov [r15+0x100], rax
00007aa9b5fd1990  jmp 0x00007AA9B5DFE110
00007aa9b5fd1995  int3
00007aa9b5fd1996  int3
00007aa9b5fd1997  nop [rax+rax*1], ax
00007aa9b5fd19a0  vmovaps xmm1, [0x00007AA9B5BFE010]
00007aa9b5fd19a8  movq xmm1, xmm1
00007aa9b5fd19ac  movaps [r15+0x110], xmm1
00007aa9b5fd19b4  mov eax, 0x420B10
00007aa9b5fd19b9  mov r14, [r13+rax*1]
00007aa9b5fd19be  movq xmm1, r14
00007aa9b5fd19c3  movaps [r15+0x120], xmm1
00007aa9b5fd19cb  vmovaps xmm1, [0x00007AA9B5BFE020]
00007aa9b5fd19d3  movq xmm1, xmm1
00007aa9b5fd19d7  movaps [r15+0x140], xmm1
00007aa9b5fd19df  vmovaps xmm1, [0x00007AA9B5BFE030]
00007aa9b5fd19e7  vpbroadcastq xmm1, xmm1
00007aa9b5fd19ec  movaps [r15+0x150], xmm1
00007aa9b5fd19f4  mov qword ptr [r15+0x40], 0x02
00007aa9b5fd19fc  vmovaps xmm15, [0x00007AA9B5BFE040]
00007aa9b5fd1a04  movq xmm15, xmm15
00007aa9b5fd1a09  movaps [r15+0x160], xmm15
00007aa9b5fd1a11  vmovaps xmm15, [0x00007AA9B5BFE050]
00007aa9b5fd1a19  vpbroadcastq xmm15, xmm15
00007aa9b5fd1a1e  movaps [r15+0x130], xmm15
00007aa9b5fd1a26  mov rax, [r15+0x40]
00007aa9b5fd1a2a  vmovq xmm14, rax
00007aa9b5fd1a2f  vpbroadcastq xmm14, xmm14
00007aa9b5fd1a34  movaps [r15+0x170], xmm14
00007aa9b5fd1a3c  mov eax, 0x420A40
00007aa9b5fd1a41  movups xmm13, [r13+rax*1]
00007aa9b5fd1a47  mov qword ptr [r15+0x40], 0x431E00
00007aa9b5fd1a4f  mov eax, [r15]
00007aa9b5fd1a52  mov r14d, 0x430CB8
00007aa9b5fd1a58  mov [r13+r14*1], eax
00007aa9b5fd1a5d  mov qword ptr [r15+0x50], 0x432000
00007aa9b5fd1a65  vpmovqd xmm12, xmm13
00007aa9b5fd1a6b  pxor xmm11, xmm11
00007aa9b5fd1a70  punpcklqdq xmm12, xmm11
00007aa9b5fd1a75  movaps [r15+0x210], xmm12
00007aa9b5fd1a7d  movq xmm12, qword ptr [r15+0x140]
00007aa9b5fd1a86  movq xmm11, qword ptr [r15+0x120]
00007aa9b5fd1a8f  psubd xmm12, xmm11
00007aa9b5fd1a94  movq xmm12, xmm12
00007aa9b5fd1a99  paddq xmm13, xmm14
00007aa9b5fd1a9e  movaps [r15+0x180], xmm13
00007aa9b5fd1aa6  movq xmm14, qword ptr [r15+0x160]
00007aa9b5fd1aaf  paddd xmm11, xmm14
00007aa9b5fd1ab4  movq xmm11, xmm11
00007aa9b5fd1ab9  movq xmm11, xmm11
00007aa9b5fd1abe  movaps [r15+0x120], xmm11
00007aa9b5fd1ac6  pmovzxdq xmm12, xmm12
00007aa9b5fd1acc  psllq xmm12, 0x00
00007aa9b5fd1ad2  movq xmm14, qword ptr [r15+0x210]
00007aa9b5fd1adb  movq xmm13, qword ptr [r15+0x110]
00007aa9b5fd1ae4  paddd xmm14, xmm13
00007aa9b5fd1ae9  movq xmm14, xmm14
00007aa9b5fd1aee  vcvtuqq2pd xmm12, xmm12
00007aa9b5fd1af4  pmovzxdq xmm14, xmm14
00007aa9b5fd1afa  psllq xmm14, 0x00
00007aa9b5fd1b00  vcvtuqq2pd xmm14, xmm14
00007aa9b5fd1b06  movaps xmm13, xmm12
00007aa9b5fd1b0a  mulpd xmm13, xmm1
00007aa9b5fd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007aa9b5fd1b15  ptest xmm11, xmm11
00007aa9b5fd1b1b  jnz 0x00007AA9B5FD1C0F
00007aa9b5fd1b21  movaps [r15+0x220], xmm13
00007aa9b5fd1b29  mov eax, 0x432000
00007aa9b5fd1b2e  movups [r13+rax*1], xmm13
00007aa9b5fd1b34  movaps xmm1, xmm14
00007aa9b5fd1b38  mulpd xmm1, xmm15
00007aa9b5fd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007aa9b5fd1b42  ptest xmm13, xmm13
00007aa9b5fd1b48  jnz 0x00007AA9B5FD1D5C
00007aa9b5fd1b4e  movaps [r15+0x210], xmm1
00007aa9b5fd1b56  mov eax, 0x431E00
00007aa9b5fd1b5b  movups [r13+rax*1], xmm1
00007aa9b5fd1b61  mov qword ptr [r15+0x48], 0x10
00007aa9b5fd1b69  xor eax, eax
00007aa9b5fd1b6b  mov r14d, 0x10
00007aa9b5fd1b71  mov r12d, 0x200
00007aa9b5fd1b77  cmp r14, r12
00007aa9b5fd1b7a  cmc
00007aa9b5fd1b7b  lahf
00007aa9b5fd1b7c  seto al
00007aa9b5fd1b7f  mov [r15+0x108], eax
00007aa9b5fd1b86  mov eax, [r15+0x108]
00007aa9b5fd1b8d  sahf
00007aa9b5fd1b8e  jnz 0x00007AA9B5FD1BC0
00007aa9b5fd1b90  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd1b98  jz 0x00007AA9B5FD2300
00007aa9b5fd1b9e  nop [rax+rax*1], ax
00007aa9b5fd1ba7  nop [rax+rax*1], eax
00007aa9b5fd1baf  mov eax, 0x410490
00007aa9b5fd1bb4  mov [r15+0x100], rax
00007aa9b5fd1bbb  jmp 0x00007AA9B5DFE110
00007aa9b5fd1bc0  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd1bc8  jz 0x00007AA9B5FD1EB0
00007aa9b5fd1bce  nop [rax+rax*1], ax
00007aa9b5fd1bd7  nop [rax+rax*1], eax
00007aa9b5fd1bdf  mov eax, 0x410450
00007aa9b5fd1be4  mov [r15+0x100], rax
00007aa9b5fd1beb  jmp 0x00007AA9B5DFE110
00007aa9b5fd1bf0  int3
00007aa9b5fd1bf1  call 0x00007AA9B5E0DC20
00007aa9b5fd1bf6  jmp 0x00007AA9B5FD19BE
00007aa9b5fd1bfb  call 0x00007AA9B5E0C260
00007aa9b5fd1c00  jmp 0x00007AA9B5FD1A47
00007aa9b5fd1c05  call 0x00007AA9B5ED5D70
00007aa9b5fd1c0a  jmp 0x00007AA9B5FD1A5D
00007aa9b5fd1c0f  sub rsp, 0x08
00007aa9b5fd1c13  push rax
00007aa9b5fd1c14  push rcx
00007aa9b5fd1c15  push rdx
00007aa9b5fd1c16  push rdi
00007aa9b5fd1c17  push rsi
00007aa9b5fd1c18  push r8
00007aa9b5fd1c1a  push r9
00007aa9b5fd1c1c  push r10
00007aa9b5fd1c1e  push r11
00007aa9b5fd1c20  sub rsp, 0xF0
00007aa9b5fd1c27  vmovaps [rsp], xmm0
00007aa9b5fd1c2c  vmovaps [rsp+0x10], xmm1
00007aa9b5fd1c32  vmovaps [rsp+0x20], xmm2
00007aa9b5fd1c38  vmovaps [rsp+0x30], xmm3
00007aa9b5fd1c3e  vmovaps [rsp+0x40], xmm4
00007aa9b5fd1c44  vmovaps [rsp+0x50], xmm5
00007aa9b5fd1c4a  vmovaps [rsp+0x60], xmm6
00007aa9b5fd1c50  vmovaps [rsp+0x70], xmm7
00007aa9b5fd1c56  vmovaps [rsp+0x80], xmm8
00007aa9b5fd1c5f  vmovaps [rsp+0x90], xmm9
00007aa9b5fd1c68  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd1c71  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd1c7a  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd1c83  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd1c8c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd1c95  sub rsp, 0x30
00007aa9b5fd1c99  movaps [rsp], xmm13
00007aa9b5fd1c9e  movaps [rsp+0x10], xmm12
00007aa9b5fd1ca4  movaps [rsp+0x20], xmm1
00007aa9b5fd1ca9  lea rdi, [rsp]
00007aa9b5fd1cad  mov esi, 0x00
00007aa9b5fd1cb2  mov rax, 0x63E0217C9530
00007aa9b5fd1cbc  call rax
00007aa9b5fd1cbe  movaps xmm13, [rsp]
00007aa9b5fd1cc3  add rsp, 0x30
00007aa9b5fd1cc7  vmovaps xmm0, [rsp]
00007aa9b5fd1ccc  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd1cd2  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd1cd8  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd1cde  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd1ce4  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd1cea  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd1cf0  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd1cf6  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd1cff  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd1d08  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd1d11  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd1d1a  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd1d23  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd1d2c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd1d35  add rsp, 0xF0
00007aa9b5fd1d3c  pop r11
00007aa9b5fd1d3e  pop r10
00007aa9b5fd1d40  pop r9
00007aa9b5fd1d42  pop r8
00007aa9b5fd1d44  pop rsi
00007aa9b5fd1d45  pop rdi
00007aa9b5fd1d46  pop rdx
00007aa9b5fd1d47  pop rcx
00007aa9b5fd1d48  pop rax
00007aa9b5fd1d49  add rsp, 0x08
00007aa9b5fd1d4d  jmp 0x00007AA9B5FD1B21
00007aa9b5fd1d52  call 0x00007AA9B5E0C380
00007aa9b5fd1d57  jmp 0x00007AA9B5FD1B34
00007aa9b5fd1d5c  sub rsp, 0x08
00007aa9b5fd1d60  push rax
00007aa9b5fd1d61  push rcx
00007aa9b5fd1d62  push rdx
00007aa9b5fd1d63  push rdi
00007aa9b5fd1d64  push rsi
00007aa9b5fd1d65  push r8
00007aa9b5fd1d67  push r9
00007aa9b5fd1d69  push r10
00007aa9b5fd1d6b  push r11
00007aa9b5fd1d6d  sub rsp, 0xF0
00007aa9b5fd1d74  vmovaps [rsp], xmm0
00007aa9b5fd1d79  vmovaps [rsp+0x10], xmm2
00007aa9b5fd1d7f  vmovaps [rsp+0x20], xmm3
00007aa9b5fd1d85  vmovaps [rsp+0x30], xmm4
00007aa9b5fd1d8b  vmovaps [rsp+0x40], xmm5
00007aa9b5fd1d91  vmovaps [rsp+0x50], xmm6
00007aa9b5fd1d97  vmovaps [rsp+0x60], xmm7
00007aa9b5fd1d9d  vmovaps [rsp+0x70], xmm8
00007aa9b5fd1da3  vmovaps [rsp+0x80], xmm9
00007aa9b5fd1dac  vmovaps [rsp+0x90], xmm10
00007aa9b5fd1db5  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd1dbe  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd1dc7  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd1dd0  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd1dd9  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd1de2  sub rsp, 0x30
00007aa9b5fd1de6  movaps [rsp], xmm1
00007aa9b5fd1dea  movaps [rsp+0x10], xmm14
00007aa9b5fd1df0  movaps [rsp+0x20], xmm15
00007aa9b5fd1df6  lea rdi, [rsp]
00007aa9b5fd1dfa  mov esi, 0x00
00007aa9b5fd1dff  mov rax, 0x63E0217C9530
00007aa9b5fd1e09  call rax
00007aa9b5fd1e0b  movaps xmm1, [rsp]
00007aa9b5fd1e0f  add rsp, 0x30
00007aa9b5fd1e13  vmovaps xmm0, [rsp]
00007aa9b5fd1e18  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd1e1e  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd1e24  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd1e2a  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd1e30  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd1e36  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd1e3c  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd1e42  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd1e4b  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd1e54  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd1e5d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd1e66  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd1e6f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd1e78  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd1e81  add rsp, 0xF0
00007aa9b5fd1e88  pop r11
00007aa9b5fd1e8a  pop r10
00007aa9b5fd1e8c  pop r9
00007aa9b5fd1e8e  pop r8
00007aa9b5fd1e90  pop rsi
00007aa9b5fd1e91  pop rdi
00007aa9b5fd1e92  pop rdx
00007aa9b5fd1e93  pop rcx
00007aa9b5fd1e94  pop rax
00007aa9b5fd1e95  add rsp, 0x08
00007aa9b5fd1e99  jmp 0x00007AA9B5FD1B4E
00007aa9b5fd1e9e  call 0x00007AA9B5DFF540
00007aa9b5fd1ea3  jmp 0x00007AA9B5FD1B61
00007aa9b5fd1ea8  int3
00007aa9b5fd1ea9  nop [rax], eax
00007aa9b5fd1eb0  movaps xmm1, [r15+0x180]
00007aa9b5fd1eb8  vpmovqd xmm15, xmm1
00007aa9b5fd1ebe  pxor xmm14, xmm14
00007aa9b5fd1ec3  punpcklqdq xmm15, xmm14
00007aa9b5fd1ec8  movaps [r15+0x210], xmm15
00007aa9b5fd1ed0  movq xmm15, qword ptr [r15+0x140]
00007aa9b5fd1ed9  movq xmm14, qword ptr [r15+0x120]
00007aa9b5fd1ee2  psubd xmm15, xmm14
00007aa9b5fd1ee7  movq xmm15, xmm15
00007aa9b5fd1eec  movaps xmm13, [r15+0x170]
00007aa9b5fd1ef4  paddq xmm1, xmm13
00007aa9b5fd1ef9  movaps [r15+0x180], xmm1
00007aa9b5fd1f01  movq xmm1, qword ptr [r15+0x160]
00007aa9b5fd1f0a  paddd xmm14, xmm1
00007aa9b5fd1f0f  movq xmm14, xmm14
00007aa9b5fd1f14  movq xmm14, xmm14
00007aa9b5fd1f19  movaps [r15+0x120], xmm14
00007aa9b5fd1f21  pmovzxdq xmm15, xmm15
00007aa9b5fd1f27  psllq xmm15, 0x00
00007aa9b5fd1f2d  movq xmm1, qword ptr [r15+0x210]
00007aa9b5fd1f36  movq xmm14, qword ptr [r15+0x110]
00007aa9b5fd1f3f  paddd xmm1, xmm14
00007aa9b5fd1f44  movq xmm1, xmm1
00007aa9b5fd1f48  vcvtuqq2pd xmm15, xmm15
00007aa9b5fd1f4e  pmovzxdq xmm1, xmm1
00007aa9b5fd1f53  psllq xmm1, 0x00
00007aa9b5fd1f58  vcvtuqq2pd xmm1, xmm1
00007aa9b5fd1f5e  movaps xmm14, [r15+0x150]
00007aa9b5fd1f66  movaps xmm13, xmm15
00007aa9b5fd1f6a  mulpd xmm13, xmm14
00007aa9b5fd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007aa9b5fd1f75  ptest xmm12, xmm12
00007aa9b5fd1f7b  jnz 0x00007AA9B5FD205E
00007aa9b5fd1f81  movaps [r15+0x220], xmm13
00007aa9b5fd1f89  mov rax, [r15+0x48]
00007aa9b5fd1f8d  mov r14, [r15+0x50]
00007aa9b5fd1f91  lea r12, [r14+rax*1]
00007aa9b5fd1f95  movups [r13+r12*1], xmm13
00007aa9b5fd1f9b  movaps xmm15, [r15+0x130]
00007aa9b5fd1fa3  movaps xmm14, xmm1
00007aa9b5fd1fa7  mulpd xmm14, xmm15
00007aa9b5fd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007aa9b5fd1fb2  ptest xmm13, xmm13
00007aa9b5fd1fb8  jnz 0x00007AA9B5FD21AC
00007aa9b5fd1fbe  movaps [r15+0x210], xmm14
00007aa9b5fd1fc6  mov r14, [r15+0x40]
00007aa9b5fd1fca  lea r12, [r14+rax*1]
00007aa9b5fd1fce  movups [r13+r12*1], xmm14
00007aa9b5fd1fd4  lea r14, [rax+0x10]
00007aa9b5fd1fd8  mov [r15+0x48], r14
00007aa9b5fd1fdc  xor eax, eax
00007aa9b5fd1fde  mov r12d, 0x200
00007aa9b5fd1fe4  cmp r14, r12
00007aa9b5fd1fe7  cmc
00007aa9b5fd1fe8  lahf
00007aa9b5fd1fe9  seto al
00007aa9b5fd1fec  mov [r15+0x108], eax
00007aa9b5fd1ff3  mov eax, [r15+0x108]
00007aa9b5fd1ffa  sahf
00007aa9b5fd1ffb  jnz 0x00007AA9B5FD202D
00007aa9b5fd1ffd  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd2005  jz 0x00007AA9B5FD2300
00007aa9b5fd200b  nop [rax+rax*1], ax
00007aa9b5fd2014  nop [rax+rax*1], eax
00007aa9b5fd201c  mov eax, 0x410490
00007aa9b5fd2021  mov [r15+0x100], rax
00007aa9b5fd2028  jmp 0x00007AA9B5DFE110
00007aa9b5fd202d  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd2035  jz 0x00007AA9B5FD1EB0
00007aa9b5fd203b  nop [rax+rax*1], ax
00007aa9b5fd2044  nop [rax+rax*1], eax
00007aa9b5fd204c  mov eax, 0x410450
00007aa9b5fd2051  mov [r15+0x100], rax
00007aa9b5fd2058  jmp 0x00007AA9B5DFE110
00007aa9b5fd205d  int3
00007aa9b5fd205e  sub rsp, 0x08
00007aa9b5fd2062  push rax
00007aa9b5fd2063  push rcx
00007aa9b5fd2064  push rdx
00007aa9b5fd2065  push rdi
00007aa9b5fd2066  push rsi
00007aa9b5fd2067  push r8
00007aa9b5fd2069  push r9
00007aa9b5fd206b  push r10
00007aa9b5fd206d  push r11
00007aa9b5fd206f  sub rsp, 0xF0
00007aa9b5fd2076  vmovaps [rsp], xmm0
00007aa9b5fd207b  vmovaps [rsp+0x10], xmm1
00007aa9b5fd2081  vmovaps [rsp+0x20], xmm2
00007aa9b5fd2087  vmovaps [rsp+0x30], xmm3
00007aa9b5fd208d  vmovaps [rsp+0x40], xmm4
00007aa9b5fd2093  vmovaps [rsp+0x50], xmm5
00007aa9b5fd2099  vmovaps [rsp+0x60], xmm6
00007aa9b5fd209f  vmovaps [rsp+0x70], xmm7
00007aa9b5fd20a5  vmovaps [rsp+0x80], xmm8
00007aa9b5fd20ae  vmovaps [rsp+0x90], xmm9
00007aa9b5fd20b7  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd20c0  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd20c9  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd20d2  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd20db  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd20e4  sub rsp, 0x30
00007aa9b5fd20e8  movaps [rsp], xmm13
00007aa9b5fd20ed  movaps [rsp+0x10], xmm15
00007aa9b5fd20f3  movaps [rsp+0x20], xmm14
00007aa9b5fd20f9  lea rdi, [rsp]
00007aa9b5fd20fd  mov esi, 0x00
00007aa9b5fd2102  mov rax, 0x63E0217C9530
00007aa9b5fd210c  call rax
00007aa9b5fd210e  movaps xmm13, [rsp]
00007aa9b5fd2113  add rsp, 0x30
00007aa9b5fd2117  vmovaps xmm0, [rsp]
00007aa9b5fd211c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd2122  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd2128  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd212e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd2134  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd213a  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd2140  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd2146  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd214f  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd2158  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd2161  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd216a  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd2173  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd217c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd2185  add rsp, 0xF0
00007aa9b5fd218c  pop r11
00007aa9b5fd218e  pop r10
00007aa9b5fd2190  pop r9
00007aa9b5fd2192  pop r8
00007aa9b5fd2194  pop rsi
00007aa9b5fd2195  pop rdi
00007aa9b5fd2196  pop rdx
00007aa9b5fd2197  pop rcx
00007aa9b5fd2198  pop rax
00007aa9b5fd2199  add rsp, 0x08
00007aa9b5fd219d  jmp 0x00007AA9B5FD1F81
00007aa9b5fd21a2  call 0x00007AA9B5EC2240
00007aa9b5fd21a7  jmp 0x00007AA9B5FD1F9B
00007aa9b5fd21ac  sub rsp, 0x08
00007aa9b5fd21b0  push rax
00007aa9b5fd21b1  push rcx
00007aa9b5fd21b2  push rdx
00007aa9b5fd21b3  push rdi
00007aa9b5fd21b4  push rsi
00007aa9b5fd21b5  push r8
00007aa9b5fd21b7  push r9
00007aa9b5fd21b9  push r10
00007aa9b5fd21bb  push r11
00007aa9b5fd21bd  sub rsp, 0xF0
00007aa9b5fd21c4  vmovaps [rsp], xmm0
00007aa9b5fd21c9  vmovaps [rsp+0x10], xmm1
00007aa9b5fd21cf  vmovaps [rsp+0x20], xmm2
00007aa9b5fd21d5  vmovaps [rsp+0x30], xmm3
00007aa9b5fd21db  vmovaps [rsp+0x40], xmm4
00007aa9b5fd21e1  vmovaps [rsp+0x50], xmm5
00007aa9b5fd21e7  vmovaps [rsp+0x60], xmm6
00007aa9b5fd21ed  vmovaps [rsp+0x70], xmm7
00007aa9b5fd21f3  vmovaps [rsp+0x80], xmm8
00007aa9b5fd21fc  vmovaps [rsp+0x90], xmm9
00007aa9b5fd2205  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd220e  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd2217  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd2220  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd2229  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd2232  sub rsp, 0x30
00007aa9b5fd2236  movaps [rsp], xmm14
00007aa9b5fd223b  movaps [rsp+0x10], xmm1
00007aa9b5fd2240  movaps [rsp+0x20], xmm15
00007aa9b5fd2246  lea rdi, [rsp]
00007aa9b5fd224a  mov esi, 0x00
00007aa9b5fd224f  mov rax, 0x63E0217C9530
00007aa9b5fd2259  call rax
00007aa9b5fd225b  movaps xmm14, [rsp]
00007aa9b5fd2260  add rsp, 0x30
00007aa9b5fd2264  vmovaps xmm0, [rsp]
00007aa9b5fd2269  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd226f  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd2275  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd227b  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd2281  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd2287  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd228d  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd2293  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd229c  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd22a5  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd22ae  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd22b7  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd22c0  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd22c9  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd22d2  add rsp, 0xF0
00007aa9b5fd22d9  pop r11
00007aa9b5fd22db  pop r10
00007aa9b5fd22dd  pop r9
00007aa9b5fd22df  pop r8
00007aa9b5fd22e1  pop rsi
00007aa9b5fd22e2  pop rdi
00007aa9b5fd22e3  pop rdx
00007aa9b5fd22e4  pop rcx
00007aa9b5fd22e5  pop rax
00007aa9b5fd22e6  add rsp, 0x08
00007aa9b5fd22ea  jmp 0x00007AA9B5FD1FBE
00007aa9b5fd22ef  call 0x00007AA9B5EC34C0
00007aa9b5fd22f4  jmp 0x00007AA9B5FD1FD4
00007aa9b5fd22f9  int3
00007aa9b5fd22fa  nop [rax+rax*1], ax
00007aa9b5fd2300  mov rax, [r15+0x50]
00007aa9b5fd2304  lea r14, [rax+0x80]
00007aa9b5fd230b  movups xmm1, [r13+r14*1]
00007aa9b5fd2311  lea r14, [rax+0x90]
00007aa9b5fd2318  movups xmm15, [r13+r14*1]
00007aa9b5fd231e  vxorps xmm14, xmm14, xmm14
00007aa9b5fd2323  vpbroadcastq xmm14, xmm14
00007aa9b5fd2328  lea r14, [rax+0x40]
00007aa9b5fd232c  movups xmm13, [r13+r14*1]
00007aa9b5fd2332  lea r14, [rax+0x50]
00007aa9b5fd2336  movups xmm12, [r13+r14*1]
00007aa9b5fd233c  mov qword ptr [r15+0x48], 0x00
00007aa9b5fd2344  movups xmm11, [r13+rax*1]
00007aa9b5fd234a  lea r14, [rax+0x10]
00007aa9b5fd234e  movups xmm10, [r13+r14*1]
00007aa9b5fd2354  mov r14, [r15+0xF8]
00007aa9b5fd235b  lea r12, [r14+0xE0]
00007aa9b5fd2362  movups [r13+r12*1], xmm15
00007aa9b5fd2368  lea r12, [r14+0xF0]
00007aa9b5fd236f  movups [r13+r12*1], xmm1
00007aa9b5fd2375  lea r12, [rax+0xC0]
00007aa9b5fd237c  movups xmm1, [r13+r12*1]
00007aa9b5fd2382  lea r12, [rax+0xD0]
00007aa9b5fd2389  movups xmm15, [r13+r12*1]
00007aa9b5fd238f  lea r12, [rax+0x140]
00007aa9b5fd2396  movups xmm9, [r13+r12*1]
00007aa9b5fd239c  lea r12, [rax+0x150]
00007aa9b5fd23a3  movups xmm8, [r13+r12*1]
00007aa9b5fd23a9  lea r12, [rax+0x180]
00007aa9b5fd23b0  movups xmm7, [r13+r12*1]
00007aa9b5fd23b6  lea r12, [rax+0x190]
00007aa9b5fd23bd  movups xmm6, [r13+r12*1]
00007aa9b5fd23c3  lea r12, [r14+0xC0]
00007aa9b5fd23ca  movups [r13+r12*1], xmm15
00007aa9b5fd23d0  lea r12, [r14+0xD0]
00007aa9b5fd23d7  movups [r13+r12*1], xmm1
00007aa9b5fd23dd  lea r12, [rax+0x100]
00007aa9b5fd23e4  movups xmm1, [r13+r12*1]
00007aa9b5fd23ea  lea r12, [rax+0x110]
00007aa9b5fd23f1  movups xmm15, [r13+r12*1]
00007aa9b5fd23f7  lea r12, [rax+0x1C0]
00007aa9b5fd23fe  movups xmm5, [r13+r12*1]
00007aa9b5fd2404  lea r12, [rax+0x1D0]
00007aa9b5fd240b  movups xmm4, [r13+r12*1]
00007aa9b5fd2411  lea r12, [rax+0x20]
00007aa9b5fd2415  movups xmm3, [r13+r12*1]
00007aa9b5fd241b  lea r12, [rax+0x30]
00007aa9b5fd241f  movups xmm2, [r13+r12*1]
00007aa9b5fd2425  movaps [r15+0x1F0], xmm2
00007aa9b5fd242d  lea r12, [r14+0x20]
00007aa9b5fd2431  movups [r13+r12*1], xmm1
00007aa9b5fd2437  lea r12, [r14+0x30]
00007aa9b5fd243b  movups [r13+r12*1], xmm12
00007aa9b5fd2441  lea r12, [rax+0x60]
00007aa9b5fd2445  movups xmm1, [r13+r12*1]
00007aa9b5fd244b  lea r12, [rax+0x70]
00007aa9b5fd244f  movups xmm12, [r13+r12*1]
00007aa9b5fd2455  lea r12, [r14+0x60]
00007aa9b5fd2459  movups [r13+r12*1], xmm11
00007aa9b5fd245f  lea r12, [r14+0x70]
00007aa9b5fd2463  movups [r13+r12*1], xmm5
00007aa9b5fd2469  lea r12, [rax+0xE0]
00007aa9b5fd2470  movups xmm11, [r13+r12*1]
00007aa9b5fd2476  lea r12, [rax+0xF0]
00007aa9b5fd247d  movups xmm5, [r13+r12*1]
00007aa9b5fd2483  lea r12, [rax+0x120]
00007aa9b5fd248a  vmovaps [rsp+0x10], xmm1
00007aa9b5fd2490  movups xmm1, [r13+r12*1]
00007aa9b5fd2496  lea r12, [rax+0x130]
00007aa9b5fd249d  vmovaps [rsp+0x20], xmm1
00007aa9b5fd24a3  movups xmm1, [r13+r12*1]
00007aa9b5fd24a9  lea r12, [r14+0xA0]
00007aa9b5fd24b0  movups [r13+r12*1], xmm12
00007aa9b5fd24b6  lea r12, [r14+0xB0]
00007aa9b5fd24bd  vmovaps xmm12, [rsp+0x10]
00007aa9b5fd24c3  movups [r13+r12*1], xmm12
00007aa9b5fd24c9  lea r12, [rax+0xA0]
00007aa9b5fd24d0  movups xmm12, [r13+r12*1]
00007aa9b5fd24d6  lea r12, [rax+0xB0]
00007aa9b5fd24dd  vmovaps [rsp+0x10], xmm1
00007aa9b5fd24e3  movups xmm1, [r13+r12*1]
00007aa9b5fd24e9  lea r12, [rax+0x160]
00007aa9b5fd24f0  vmovaps [rsp+0x30], xmm1
00007aa9b5fd24f6  movups xmm1, [r13+r12*1]
00007aa9b5fd24fc  lea r12, [rax+0x170]
00007aa9b5fd2503  vmovaps [rsp+0x40], xmm1
00007aa9b5fd2509  movups xmm1, [r13+r12*1]
00007aa9b5fd250f  movaps [r15+0x2B0], xmm1
00007aa9b5fd2517  lea r12, [rax+0x1A0]
00007aa9b5fd251e  vmovaps [rsp+0x50], xmm1
00007aa9b5fd2524  movups xmm1, [r13+r12*1]
00007aa9b5fd252a  lea r12, [rax+0x1B0]
00007aa9b5fd2531  vmovaps [rsp+0x60], xmm1
00007aa9b5fd2537  movups xmm1, [r13+r12*1]
00007aa9b5fd253d  vmovaps [rsp+0x70], xmm1
00007aa9b5fd2543  vmovaps xmm1, [rsp+0x60]
00007aa9b5fd2549  movaps [r15+0x290], xmm1
00007aa9b5fd2551  vmovaps [rsp+0x60], xmm1
00007aa9b5fd2557  vmovaps xmm1, [rsp+0x70]
00007aa9b5fd255d  movaps [r15+0x1E0], xmm1
00007aa9b5fd2565  lea r12, [r14+0x80]
00007aa9b5fd256c  vmovaps [rsp+0x70], xmm1
00007aa9b5fd2572  vmovaps xmm1, [rsp+0x30]
00007aa9b5fd2578  movups [r13+r12*1], xmm1
00007aa9b5fd257e  lea r12, [r14+0x90]
00007aa9b5fd2585  movups [r13+r12*1], xmm12
00007aa9b5fd258b  lea r12, [rax+0x1E0]
00007aa9b5fd2592  movups xmm1, [r13+r12*1]
00007aa9b5fd2598  lea r12, [rax+0x1F0]
00007aa9b5fd259f  movups xmm12, [r13+r12*1]
00007aa9b5fd25a5  mov qword ptr [r15+0x50], 0x432200
00007aa9b5fd25ad  lea rax, [r14+0x40]
00007aa9b5fd25b1  vmovaps [rsp+0x30], xmm1
00007aa9b5fd25b7  vmovaps xmm1, [rsp+0x40]
00007aa9b5fd25bd  movups [r13+rax*1], xmm1
00007aa9b5fd25c3  lea rax, [r14+0x50]
00007aa9b5fd25c7  movups [r13+rax*1], xmm10
00007aa9b5fd25cd  movups [r13+r14*1], xmm12
00007aa9b5fd25d3  lea rax, [r14+0x10]
00007aa9b5fd25d7  vmovaps xmm1, [rsp+0x30]
00007aa9b5fd25dd  movups [r13+rax*1], xmm1
00007aa9b5fd25e3  mov rax, [r15+0x40]
00007aa9b5fd25e7  vmovaps [rsp+0x30], xmm3
00007aa9b5fd25ed  vmovaps xmm1, [rsp+0x30]
00007aa9b5fd25f3  por xmm3, xmm1
00007aa9b5fd25f7  vmovaps [rsp+0x30], xmm6
00007aa9b5fd25fd  vmovaps xmm12, [rsp+0x30]
00007aa9b5fd2603  por xmm6, xmm12
00007aa9b5fd2608  lea r12, [rax+0x30]
00007aa9b5fd260c  mov r11, [r13+r12*1]
00007aa9b5fd2611  lea r12, [rax+0x38]
00007aa9b5fd2615  mov r10, [r13+r12*1]
00007aa9b5fd261a  movq xmm12, r11
00007aa9b5fd261f  movq xmm10, r10
00007aa9b5fd2624  movq xmm12, xmm12
00007aa9b5fd2629  vmovaps [rsp+0x30], xmm12
00007aa9b5fd262f  movq xmm12, xmm12
00007aa9b5fd2634  movaps [r15+0x130], xmm12
00007aa9b5fd263c  movq xmm10, xmm10
00007aa9b5fd2641  vmovaps [rsp+0x40], xmm10
00007aa9b5fd2647  movq xmm10, xmm10
00007aa9b5fd264c  movaps [r15+0x280], xmm10
00007aa9b5fd2654  vmovaps [rsp+0x80], xmm9
00007aa9b5fd265d  vmovaps xmm12, [rsp+0x80]
00007aa9b5fd2666  por xmm9, xmm12
00007aa9b5fd266b  lea r12, [rax+0x20]
00007aa9b5fd266f  mov r11, [r13+r12*1]
00007aa9b5fd2674  lea r12, [rax+0x28]
00007aa9b5fd2678  mov r10, [r13+r12*1]
00007aa9b5fd267d  movq xmm12, r11
00007aa9b5fd2682  movq xmm10, r10
00007aa9b5fd2687  movq xmm12, xmm12
00007aa9b5fd268c  vmovaps [rsp+0x80], xmm12
00007aa9b5fd2695  movq xmm12, xmm12
00007aa9b5fd269a  movaps [r15+0x150], xmm12
00007aa9b5fd26a2  movq xmm10, xmm10
00007aa9b5fd26a7  vmovaps [rsp+0x90], xmm10
00007aa9b5fd26b0  movq xmm10, xmm10
00007aa9b5fd26b5  movaps [r15+0x140], xmm10
00007aa9b5fd26bd  lea r12, [rax+0x10]
00007aa9b5fd26c1  mov r11, [r13+r12*1]
00007aa9b5fd26c6  lea r12, [rax+0x18]
00007aa9b5fd26ca  mov r10, [r13+r12*1]
00007aa9b5fd26cf  movq xmm12, r11
00007aa9b5fd26d4  movq xmm10, r10
00007aa9b5fd26d9  movq xmm12, xmm12
00007aa9b5fd26de  vmovaps [rsp+0xA0], xmm12
00007aa9b5fd26e7  movq xmm12, xmm12
00007aa9b5fd26ec  movaps [r15+0x170], xmm12
00007aa9b5fd26f4  movq xmm10, xmm10
00007aa9b5fd26f9  vmovaps [rsp+0xB0], xmm10
00007aa9b5fd2702  movq xmm10, xmm10
00007aa9b5fd2707  movaps [r15+0x160], xmm10
00007aa9b5fd270f  mov r12, [r13+rax*1]
00007aa9b5fd2714  vmovq xmm12, r12
00007aa9b5fd2719  vpbroadcastq xmm12, xmm12
00007aa9b5fd271e  lea r12, [rax+0x08]
00007aa9b5fd2722  mov rax, [r13+r12*1]
00007aa9b5fd2727  movq xmm10, rax
00007aa9b5fd272c  movaps [r15+0x230], xmm10
00007aa9b5fd2734  lea rax, [r14+0x50]
00007aa9b5fd2738  movups xmm10, [r13+rax*1]
00007aa9b5fd273e  lea rax, [r14+0x60]
00007aa9b5fd2742  vmovaps [rsp+0xC0], xmm1
00007aa9b5fd274b  movups xmm1, [r13+rax*1]
00007aa9b5fd2751  lea rax, [r14+0x30]
00007aa9b5fd2755  vmovaps [rsp+0xD0], xmm1
00007aa9b5fd275e  movups xmm1, [r13+rax*1]
00007aa9b5fd2764  mov qword ptr [r15+0x60], 0x432200
00007aa9b5fd276c  mov qword ptr [r15+0x58], 0x40
00007aa9b5fd2774  vmovaps [rsp+0xE0], xmm1
00007aa9b5fd277d  vmovaps [rsp+0xF0], xmm15
00007aa9b5fd2786  vmovaps xmm15, [rsp+0xC0]
00007aa9b5fd278f  vmovaps [rsp+0xC0], xmm14
00007aa9b5fd2798  movaps xmm1, xmm12
00007aa9b5fd279c  mulpd xmm1, xmm15
00007aa9b5fd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa9b5fd27a6  ptest xmm14, xmm14
00007aa9b5fd27ac  jnz 0x00007AA9B5FD3863
00007aa9b5fd27b2  movq xmm15, qword ptr [r15+0x230]
00007aa9b5fd27bb  vmovaps [rsp+0x100], xmm15
00007aa9b5fd27c4  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd27ca  vmovaps [rsp+0x110], xmm1
00007aa9b5fd27d3  vmovaps xmm1, [rsp+0xE0]
00007aa9b5fd27dc  vmovaps [rsp+0xE0], xmm13
00007aa9b5fd27e5  movaps xmm14, xmm1
00007aa9b5fd27e9  mulpd xmm14, xmm15
00007aa9b5fd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007aa9b5fd27f4  ptest xmm13, xmm13
00007aa9b5fd27fa  jnz 0x00007AA9B5FD39A5
00007aa9b5fd2800  vxorps xmm1, xmm1, xmm1
00007aa9b5fd2804  vpbroadcastq xmm1, xmm1
00007aa9b5fd2809  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd2812  vmovaps [rsp+0xD0], xmm1
00007aa9b5fd281b  movaps xmm15, xmm12
00007aa9b5fd281f  mulpd xmm15, xmm13
00007aa9b5fd2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa9b5fd282a  ptest xmm1, xmm1
00007aa9b5fd282f  jnz 0x00007AA9B5FD3AE8
00007aa9b5fd2835  movaps xmm1, xmm12
00007aa9b5fd2839  mulpd xmm1, xmm10
00007aa9b5fd283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007aa9b5fd2843  ptest xmm13, xmm13
00007aa9b5fd2849  jnz 0x00007AA9B5FD3C2C
00007aa9b5fd284f  movaps xmm13, xmm12
00007aa9b5fd2853  mulpd xmm13, xmm2
00007aa9b5fd2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007aa9b5fd285e  ptest xmm10, xmm10
00007aa9b5fd2864  jnz 0x00007AA9B5FD3D6E
00007aa9b5fd286a  vmovaps [rsp+0x120], xmm7
00007aa9b5fd2873  vmovaps xmm12, [rsp+0x120]
00007aa9b5fd287c  por xmm7, xmm12
00007aa9b5fd2881  vmovaps xmm12, [rsp+0xE0]
00007aa9b5fd288a  vmovaps xmm10, [rsp+0xE0]
00007aa9b5fd2893  por xmm12, xmm10
00007aa9b5fd2898  vmovaps xmm2, [rsp+0x100]
00007aa9b5fd28a1  vpermilpd xmm2, xmm2, 0x00
00007aa9b5fd28a7  vmovaps [rsp+0xE0], xmm1
00007aa9b5fd28b0  vmovaps [rsp+0x120], xmm15
00007aa9b5fd28b9  movaps xmm1, xmm10
00007aa9b5fd28bd  mulpd xmm1, xmm2
00007aa9b5fd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa9b5fd28c6  ptest xmm15, xmm15
00007aa9b5fd28cc  jnz 0x00007AA9B5FD3EB1
00007aa9b5fd28d2  xor eax, eax
00007aa9b5fd28d4  mov r12d, 0x40
00007aa9b5fd28da  mov r11d, 0x200
00007aa9b5fd28e0  cmp r12, r11
00007aa9b5fd28e3  cmc
00007aa9b5fd28e4  lahf
00007aa9b5fd28e5  seto al
00007aa9b5fd28e8  mov [r15+0x108], eax
00007aa9b5fd28ef  vmovaps xmm10, [rsp+0x110]
00007aa9b5fd28f8  vmovaps xmm2, [rsp+0xD0]
00007aa9b5fd2901  vmovaps [rsp+0xD0], xmm1
00007aa9b5fd290a  movaps xmm15, xmm10
00007aa9b5fd290e  addpd xmm15, xmm2
00007aa9b5fd2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa9b5fd2919  ptest xmm1, xmm1
00007aa9b5fd291e  jnz 0x00007AA9B5FD3FF2
00007aa9b5fd2924  vmovaps xmm10, [rsp+0x120]
00007aa9b5fd292d  vmovaps [rsp+0x110], xmm15
00007aa9b5fd2936  vmovaps xmm15, [rsp+0xC0]
00007aa9b5fd293f  vmovaps [rsp+0xC0], xmm14
00007aa9b5fd2948  movaps xmm1, xmm10
00007aa9b5fd294c  addpd xmm1, xmm15
00007aa9b5fd2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa9b5fd2956  ptest xmm14, xmm14
00007aa9b5fd295c  jnz 0x00007AA9B5FD4135
00007aa9b5fd2962  vmovaps xmm10, [rsp+0xE0]
00007aa9b5fd296b  vmovaps [rsp+0xE0], xmm1
00007aa9b5fd2974  movaps xmm14, xmm10
00007aa9b5fd2978  addpd xmm14, xmm15
00007aa9b5fd297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007aa9b5fd2983  ptest xmm1, xmm1
00007aa9b5fd2988  jnz 0x00007AA9B5FD4277
00007aa9b5fd298e  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd2994  vmovaps xmm15, [rsp+0x10]
00007aa9b5fd299a  por xmm1, xmm15
00007aa9b5fd299f  vmovaps xmm15, [rsp+0x20]
00007aa9b5fd29a5  vmovaps xmm10, [rsp+0x20]
00007aa9b5fd29ab  por xmm15, xmm10
00007aa9b5fd29b0  vmovaps [rsp+0x10], xmm5
00007aa9b5fd29b6  vmovaps xmm10, [rsp+0x10]
00007aa9b5fd29bc  por xmm5, xmm10
00007aa9b5fd29c1  vmovaps [rsp+0x10], xmm11
00007aa9b5fd29c7  vmovaps xmm10, [rsp+0x10]
00007aa9b5fd29cd  por xmm11, xmm10
00007aa9b5fd29d2  vmovaps [rsp+0x10], xmm4
00007aa9b5fd29d8  vmovaps xmm10, [rsp+0x10]
00007aa9b5fd29de  por xmm4, xmm10
00007aa9b5fd29e3  vmovaps [rsp+0x10], xmm8
00007aa9b5fd29e9  vmovaps xmm10, [rsp+0x10]
00007aa9b5fd29ef  por xmm8, xmm10
00007aa9b5fd29f4  vmovaps xmm10, [rsp+0xF0]
00007aa9b5fd29fd  vmovaps [rsp+0x10], xmm1
00007aa9b5fd2a03  vmovaps xmm1, [rsp+0xF0]
00007aa9b5fd2a0c  por xmm10, xmm1
00007aa9b5fd2a11  lea rax, [r14+0xA0]
00007aa9b5fd2a18  movups xmm1, [r13+rax*1]
00007aa9b5fd2a1e  lea rax, [r14+0xB0]
00007aa9b5fd2a25  vmovaps [rsp+0x20], xmm1
00007aa9b5fd2a2b  movups xmm1, [r13+rax*1]
00007aa9b5fd2a31  vmovaps [rsp+0xF0], xmm1
00007aa9b5fd2a3a  vmovaps [rsp+0x120], xmm15
00007aa9b5fd2a43  movaps xmm1, xmm13
00007aa9b5fd2a47  addpd xmm1, xmm2
00007aa9b5fd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa9b5fd2a50  ptest xmm15, xmm15
00007aa9b5fd2a56  jnz 0x00007AA9B5FD43CF
00007aa9b5fd2a5c  lea rax, [r14+0xF0]
00007aa9b5fd2a63  movups xmm15, [r13+rax*1]
00007aa9b5fd2a69  vmovaps xmm2, [rsp+0xE0]
00007aa9b5fd2a72  vmovaps [rsp+0xE0], xmm1
00007aa9b5fd2a7b  vmovaps xmm1, [rsp+0xD0]
00007aa9b5fd2a84  vmovaps [rsp+0xD0], xmm15
00007aa9b5fd2a8d  movaps xmm13, xmm2
00007aa9b5fd2a91  addpd xmm13, xmm1
00007aa9b5fd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007aa9b5fd2a9c  ptest xmm15, xmm15
00007aa9b5fd2aa2  jnz 0x00007AA9B5FD451A
00007aa9b5fd2aa8  vmovaps xmm15, [rsp+0xC0]
00007aa9b5fd2ab1  movaps xmm1, xmm14
00007aa9b5fd2ab5  addpd xmm1, xmm15
00007aa9b5fd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa9b5fd2abf  ptest xmm2, xmm2
00007aa9b5fd2ac4  jnz 0x00007AA9B5FD465C
00007aa9b5fd2aca  vmovaps xmm15, [rsp+0x100]
00007aa9b5fd2ad3  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd2ad9  vmovaps xmm2, [rsp+0xF0]
00007aa9b5fd2ae2  vmovaps [rsp+0xC0], xmm1
00007aa9b5fd2aeb  movaps xmm14, xmm2
00007aa9b5fd2aef  mulpd xmm14, xmm15
00007aa9b5fd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007aa9b5fd2afa  ptest xmm1, xmm1
00007aa9b5fd2aff  jnz 0x00007AA9B5FD479E
00007aa9b5fd2b05  vmovaps xmm1, [rsp+0xA0]
00007aa9b5fd2b0e  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd2b14  vmovaps xmm2, [rsp+0xD0]
00007aa9b5fd2b1d  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd2b26  movaps xmm15, xmm2
00007aa9b5fd2b2a  mulpd xmm15, xmm1
00007aa9b5fd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007aa9b5fd2b35  ptest xmm14, xmm14
00007aa9b5fd2b3b  jnz 0x00007AA9B5FD48E1
00007aa9b5fd2b41  lea rax, [r14+0xE0]
00007aa9b5fd2b48  movups xmm1, [r13+rax*1]
00007aa9b5fd2b4e  vmovaps xmm14, [rsp+0x100]
00007aa9b5fd2b57  vpermilpd xmm14, xmm14, 0x00
00007aa9b5fd2b5d  vmovaps [rsp+0xF0], xmm1
00007aa9b5fd2b66  vmovaps xmm1, [rsp+0x20]
00007aa9b5fd2b6c  vmovaps [rsp+0x20], xmm15
00007aa9b5fd2b72  movaps xmm2, xmm1
00007aa9b5fd2b75  mulpd xmm2, xmm14
00007aa9b5fd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007aa9b5fd2b7f  ptest xmm15, xmm15
00007aa9b5fd2b85  jnz 0x00007AA9B5FD4A2D
00007aa9b5fd2b8b  vmovaps [rsp+0x100], xmm10
00007aa9b5fd2b94  vmovaps xmm1, [rsp+0x100]
00007aa9b5fd2b9d  por xmm10, xmm1
00007aa9b5fd2ba2  movaps [r15+0x300], xmm10
00007aa9b5fd2baa  vmovaps [rsp+0x100], xmm8
00007aa9b5fd2bb3  vmovaps xmm1, [rsp+0x100]
00007aa9b5fd2bbc  por xmm8, xmm1
00007aa9b5fd2bc1  movaps [r15+0x190], xmm8
00007aa9b5fd2bc9  vmovaps xmm1, [rsp+0xA0]
00007aa9b5fd2bd2  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd2bd8  vmovaps xmm14, [rsp+0xF0]
00007aa9b5fd2be1  vmovaps [rsp+0xF0], xmm13
00007aa9b5fd2bea  movaps xmm15, xmm14
00007aa9b5fd2bee  mulpd xmm15, xmm1
00007aa9b5fd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007aa9b5fd2bf9  ptest xmm13, xmm13
00007aa9b5fd2bff  jnz 0x00007AA9B5FD4B6E
00007aa9b5fd2c05  lea rax, [r14+0x90]
00007aa9b5fd2c0c  movups xmm1, [r13+rax*1]
00007aa9b5fd2c12  vmovaps [rsp+0x100], xmm4
00007aa9b5fd2c1b  vmovaps xmm14, [rsp+0x100]
00007aa9b5fd2c24  por xmm4, xmm14
00007aa9b5fd2c29  movaps [r15+0x1C0], xmm4
00007aa9b5fd2c31  vmovaps [rsp+0x100], xmm11
00007aa9b5fd2c3a  vmovaps xmm14, [rsp+0x100]
00007aa9b5fd2c43  por xmm11, xmm14
00007aa9b5fd2c48  movaps [r15+0x200], xmm11
00007aa9b5fd2c50  vmovaps [rsp+0x100], xmm5
00007aa9b5fd2c59  vmovaps xmm14, [rsp+0x100]
00007aa9b5fd2c62  por xmm5, xmm14
00007aa9b5fd2c67  movaps [r15+0x2D0], xmm5
00007aa9b5fd2c6f  vmovaps xmm14, [rsp+0x120]
00007aa9b5fd2c78  vmovaps xmm13, [rsp+0x120]
00007aa9b5fd2c81  por xmm14, xmm13
00007aa9b5fd2c86  movaps [r15+0x2E0], xmm14
00007aa9b5fd2c8e  vmovaps [rsp+0x100], xmm1
00007aa9b5fd2c97  vmovaps xmm1, [rsp+0x110]
00007aa9b5fd2ca0  vmovaps [rsp+0x110], xmm15
00007aa9b5fd2ca9  vmovaps xmm15, [rsp+0xD0]
00007aa9b5fd2cb2  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd2cbb  movaps xmm13, xmm1
00007aa9b5fd2cbf  addpd xmm13, xmm15
00007aa9b5fd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007aa9b5fd2cca  ptest xmm14, xmm14
00007aa9b5fd2cd0  jnz 0x00007AA9B5FD4CBB
00007aa9b5fd2cd6  vmovaps xmm1, [rsp+0xA0]
00007aa9b5fd2cdf  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd2ce5  vmovaps xmm14, [rsp+0x100]
00007aa9b5fd2cee  vmovaps [rsp+0x100], xmm13
00007aa9b5fd2cf7  movaps xmm15, xmm14
00007aa9b5fd2cfb  mulpd xmm15, xmm1
00007aa9b5fd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007aa9b5fd2d06  ptest xmm13, xmm13
00007aa9b5fd2d0c  jnz 0x00007AA9B5FD4DFE
00007aa9b5fd2d12  lea rax, [r14+0x80]
00007aa9b5fd2d19  movups xmm1, [r13+rax*1]
00007aa9b5fd2d1f  vmovaps xmm13, [rsp+0xE0]
00007aa9b5fd2d28  vmovaps [rsp+0xE0], xmm1
00007aa9b5fd2d31  movaps xmm14, xmm13
00007aa9b5fd2d35  addpd xmm14, xmm2
00007aa9b5fd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007aa9b5fd2d40  ptest xmm1, xmm1
00007aa9b5fd2d45  jnz 0x00007AA9B5FD4F4B
00007aa9b5fd2d4b  vmovaps xmm13, [rsp+0xF0]
00007aa9b5fd2d54  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd2d5a  vmovaps [rsp+0x20], xmm15
00007aa9b5fd2d60  movaps xmm1, xmm13
00007aa9b5fd2d64  addpd xmm1, xmm2
00007aa9b5fd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa9b5fd2d6d  ptest xmm15, xmm15
00007aa9b5fd2d73  jnz 0x00007AA9B5FD508E
00007aa9b5fd2d79  vmovaps xmm15, [rsp+0x10]
00007aa9b5fd2d7f  vmovaps xmm13, [rsp+0x10]
00007aa9b5fd2d85  por xmm15, xmm13
00007aa9b5fd2d8a  movaps [r15+0x2F0], xmm15
00007aa9b5fd2d92  vmovaps xmm13, [rsp+0xA0]
00007aa9b5fd2d9b  vpermilpd xmm13, xmm13, 0x00
00007aa9b5fd2da1  vmovaps [rsp+0x10], xmm1
00007aa9b5fd2da7  vmovaps xmm1, [rsp+0xE0]
00007aa9b5fd2db0  vmovaps [rsp+0xA0], xmm15
00007aa9b5fd2db9  movaps xmm2, xmm1
00007aa9b5fd2dbc  mulpd xmm2, xmm13
00007aa9b5fd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007aa9b5fd2dc6  ptest xmm15, xmm15
00007aa9b5fd2dcc  jnz 0x00007AA9B5FD51CF
00007aa9b5fd2dd2  lea rax, [r14+0xD0]
00007aa9b5fd2dd9  movups xmm1, [r13+rax*1]
00007aa9b5fd2ddf  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd2de8  vmovaps [rsp+0xC0], xmm1
00007aa9b5fd2df1  vmovaps xmm1, [rsp+0x110]
00007aa9b5fd2dfa  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd2e03  movaps xmm15, xmm13
00007aa9b5fd2e07  addpd xmm15, xmm1
00007aa9b5fd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007aa9b5fd2e12  ptest xmm14, xmm14
00007aa9b5fd2e18  jnz 0x00007AA9B5FD531A
00007aa9b5fd2e1e  vmovaps xmm1, [rsp+0xB0]
00007aa9b5fd2e27  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd2e2d  movaps xmm14, xmm11
00007aa9b5fd2e31  mulpd xmm14, xmm1
00007aa9b5fd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007aa9b5fd2e3c  ptest xmm13, xmm13
00007aa9b5fd2e42  jnz 0x00007AA9B5FD545D
00007aa9b5fd2e48  movaps [r15+0x260], xmm14
00007aa9b5fd2e50  vxorps xmm1, xmm1, xmm1
00007aa9b5fd2e54  vpbroadcastq xmm1, xmm1
00007aa9b5fd2e59  movaps [r15+0x1B0], xmm1
00007aa9b5fd2e61  vmovaps xmm1, [rsp+0xB0]
00007aa9b5fd2e6a  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd2e70  vmovaps xmm11, [rsp+0xC0]
00007aa9b5fd2e79  vmovaps [rsp+0xC0], xmm15
00007aa9b5fd2e82  movaps xmm13, xmm11
00007aa9b5fd2e86  mulpd xmm13, xmm1
00007aa9b5fd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007aa9b5fd2e91  ptest xmm15, xmm15
00007aa9b5fd2e97  jnz 0x00007AA9B5FD55A0
00007aa9b5fd2e9d  lea rax, [r14+0xC0]
00007aa9b5fd2ea4  movups xmm1, [r13+rax*1]
00007aa9b5fd2eaa  vmovaps xmm11, [rsp+0x100]
00007aa9b5fd2eb3  vmovaps [rsp+0xF0], xmm1
00007aa9b5fd2ebc  vmovaps xmm1, [rsp+0x20]
00007aa9b5fd2ec2  vmovaps [rsp+0x20], xmm14
00007aa9b5fd2ec8  movaps xmm15, xmm11
00007aa9b5fd2ecc  addpd xmm15, xmm1
00007aa9b5fd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007aa9b5fd2ed7  ptest xmm14, xmm14
00007aa9b5fd2edd  jnz 0x00007AA9B5FD56ED
00007aa9b5fd2ee3  vmovaps [rsp+0x100], xmm9
00007aa9b5fd2eec  vmovaps xmm1, [rsp+0x100]
00007aa9b5fd2ef5  por xmm9, xmm1
00007aa9b5fd2efa  movaps [r15+0x270], xmm9
00007aa9b5fd2f02  vmovaps [rsp+0x100], xmm6
00007aa9b5fd2f0b  vmovaps xmm1, [rsp+0x100]
00007aa9b5fd2f14  por xmm6, xmm1
00007aa9b5fd2f18  movaps [r15+0x1A0], xmm6
00007aa9b5fd2f20  vmovaps xmm14, [rsp+0xB0]
00007aa9b5fd2f29  vpermilpd xmm14, xmm14, 0x00
00007aa9b5fd2f2f  vmovaps xmm6, [rsp+0xF0]
00007aa9b5fd2f38  vmovaps [rsp+0xF0], xmm1
00007aa9b5fd2f41  movaps xmm11, xmm6
00007aa9b5fd2f45  mulpd xmm11, xmm14
00007aa9b5fd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007aa9b5fd2f50  ptest xmm1, xmm1
00007aa9b5fd2f55  jnz 0x00007AA9B5FD5830
00007aa9b5fd2f5b  lea rax, [r14+0x20]
00007aa9b5fd2f5f  movups xmm1, [r13+rax*1]
00007aa9b5fd2f65  movaps [r15+0x110], xmm1
00007aa9b5fd2f6d  vmovaps xmm6, [rsp+0xE0]
00007aa9b5fd2f76  vmovaps [rsp+0xE0], xmm1
00007aa9b5fd2f7f  movaps xmm14, xmm6
00007aa9b5fd2f83  addpd xmm14, xmm2
00007aa9b5fd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007aa9b5fd2f8e  ptest xmm1, xmm1
00007aa9b5fd2f93  jnz 0x00007AA9B5FD597D
00007aa9b5fd2f99  vmovaps xmm1, [rsp+0xB0]
00007aa9b5fd2fa2  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd2fa8  movaps xmm6, xmm5
00007aa9b5fd2fab  mulpd xmm6, xmm1
00007aa9b5fd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007aa9b5fd2fb4  ptest xmm2, xmm2
00007aa9b5fd2fb9  jnz 0x00007AA9B5FD5ABF
00007aa9b5fd2fbf  vmovaps xmm5, [rsp+0x10]
00007aa9b5fd2fc5  movaps xmm1, xmm5
00007aa9b5fd2fc8  addpd xmm1, xmm13
00007aa9b5fd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa9b5fd2fd2  ptest xmm2, xmm2
00007aa9b5fd2fd7  jnz 0x00007AA9B5FD5BFF
00007aa9b5fd2fdd  vmovaps xmm13, [rsp+0x80]
00007aa9b5fd2fe6  vpermilpd xmm13, xmm13, 0x00
00007aa9b5fd2fec  vmovaps xmm2, [rsp+0xE0]
00007aa9b5fd2ff5  vmovaps [rsp+0x10], xmm1
00007aa9b5fd2ffb  movaps xmm5, xmm2
00007aa9b5fd2ffe  mulpd xmm5, xmm13
00007aa9b5fd3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007aa9b5fd3008  ptest xmm1, xmm1
00007aa9b5fd300d  jnz 0x00007AA9B5FD5D40
00007aa9b5fd3013  vmovaps xmm1, [rsp+0x80]
00007aa9b5fd301c  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd3022  movaps xmm13, xmm10
00007aa9b5fd3026  mulpd xmm13, xmm1
00007aa9b5fd302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007aa9b5fd3031  ptest xmm2, xmm2
00007aa9b5fd3036  jnz 0x00007AA9B5FD5E81
00007aa9b5fd303c  vmovaps xmm10, [rsp+0x20]
00007aa9b5fd3042  movaps xmm1, xmm15
00007aa9b5fd3046  addpd xmm1, xmm10
00007aa9b5fd304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa9b5fd3050  ptest xmm2, xmm2
00007aa9b5fd3055  jnz 0x00007AA9B5FD5FC4
00007aa9b5fd305b  vmovaps xmm10, [rsp+0xC0]
00007aa9b5fd3064  movaps xmm15, xmm10
00007aa9b5fd3068  addpd xmm15, xmm11
00007aa9b5fd306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007aa9b5fd3073  ptest xmm2, xmm2
00007aa9b5fd3078  jnz 0x00007AA9B5FD6106
00007aa9b5fd307e  vmovaps xmm11, [rsp+0x80]
00007aa9b5fd3087  vpermilpd xmm11, xmm11, 0x00
00007aa9b5fd308d  vmovaps xmm2, [rsp+0xD0]
00007aa9b5fd3096  vmovaps [rsp+0x20], xmm1
00007aa9b5fd309c  movaps xmm10, xmm2
00007aa9b5fd30a0  mulpd xmm10, xmm11
00007aa9b5fd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007aa9b5fd30ab  ptest xmm1, xmm1
00007aa9b5fd30b0  jnz 0x00007AA9B5FD624A
00007aa9b5fd30b6  vmovaps xmm1, [rsp+0x80]
00007aa9b5fd30bf  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd30c5  vmovaps xmm2, [rsp+0xA0]
00007aa9b5fd30ce  vmovaps [rsp+0x80], xmm15
00007aa9b5fd30d7  movaps xmm11, xmm2
00007aa9b5fd30db  mulpd xmm11, xmm1
00007aa9b5fd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007aa9b5fd30e6  ptest xmm15, xmm15
00007aa9b5fd30ec  jnz 0x00007AA9B5FD638D
00007aa9b5fd30f2  movaps xmm1, xmm14
00007aa9b5fd30f6  addpd xmm1, xmm6
00007aa9b5fd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa9b5fd30ff  ptest xmm15, xmm15
00007aa9b5fd3105  jnz 0x00007AA9B5FD64CF
00007aa9b5fd310b  vmovaps xmm14, [rsp+0x10]
00007aa9b5fd3111  movaps xmm15, xmm14
00007aa9b5fd3115  addpd xmm15, xmm5
00007aa9b5fd311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007aa9b5fd3120  ptest xmm6, xmm6
00007aa9b5fd3125  jnz 0x00007AA9B5FD6610
00007aa9b5fd312b  vmovaps xmm14, [rsp+0x90]
00007aa9b5fd3134  vpermilpd xmm14, xmm14, 0x00
00007aa9b5fd313a  movaps xmm6, xmm9
00007aa9b5fd313e  mulpd xmm6, xmm14
00007aa9b5fd3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa9b5fd3148  ptest xmm5, xmm5
00007aa9b5fd314d  jnz 0x00007AA9B5FD6753
00007aa9b5fd3153  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd315c  movaps xmm14, xmm9
00007aa9b5fd3160  addpd xmm14, xmm13
00007aa9b5fd3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007aa9b5fd316b  ptest xmm5, xmm5
00007aa9b5fd3170  jnz 0x00007AA9B5FD6895
00007aa9b5fd3176  vmovaps xmm9, [rsp+0x20]
00007aa9b5fd317c  movaps xmm13, xmm9
00007aa9b5fd3180  addpd xmm13, xmm10
00007aa9b5fd3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007aa9b5fd318b  ptest xmm5, xmm5
00007aa9b5fd3190  jnz 0x00007AA9B5FD69D9
00007aa9b5fd3196  vmovaps [rsp+0x10], xmm12
00007aa9b5fd319c  vmovaps xmm10, [rsp+0x10]
00007aa9b5fd31a2  por xmm12, xmm10
00007aa9b5fd31a7  movaps [r15+0x250], xmm12
00007aa9b5fd31af  vmovaps [rsp+0x10], xmm7
00007aa9b5fd31b5  vmovaps xmm12, [rsp+0x10]
00007aa9b5fd31bb  por xmm7, xmm12
00007aa9b5fd31c0  movaps [r15+0x2A0], xmm7
00007aa9b5fd31c8  vmovaps [rsp+0x10], xmm3
00007aa9b5fd31ce  vmovaps xmm12, [rsp+0x10]
00007aa9b5fd31d4  por xmm3, xmm12
00007aa9b5fd31d9  movaps [r15+0x1D0], xmm3
00007aa9b5fd31e1  lea rax, [r14+0x40]
00007aa9b5fd31e5  movups xmm12, [r13+rax*1]
00007aa9b5fd31eb  movaps [r15+0x2C0], xmm12
00007aa9b5fd31f3  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd31fc  vpermilpd xmm10, xmm10, 0x00
00007aa9b5fd3202  movaps xmm9, xmm8
00007aa9b5fd3206  mulpd xmm9, xmm10
00007aa9b5fd320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007aa9b5fd3211  ptest xmm5, xmm5
00007aa9b5fd3216  jnz 0x00007AA9B5FD6B27
00007aa9b5fd321c  movaps xmm10, xmm1
00007aa9b5fd3220  addpd xmm10, xmm11
00007aa9b5fd3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007aa9b5fd322b  ptest xmm8, xmm8
00007aa9b5fd3231  jnz 0x00007AA9B5FD6C6B
00007aa9b5fd3237  movaps xmm1, xmm15
00007aa9b5fd323b  addpd xmm1, xmm6
00007aa9b5fd323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007aa9b5fd3244  ptest xmm11, xmm11
00007aa9b5fd324a  jnz 0x00007AA9B5FD6DAE
00007aa9b5fd3250  vmovaps xmm15, [rsp+0x90]
00007aa9b5fd3259  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd325f  movaps xmm11, xmm12
00007aa9b5fd3263  mulpd xmm11, xmm15
00007aa9b5fd3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007aa9b5fd326e  ptest xmm8, xmm8
00007aa9b5fd3274  jnz 0x00007AA9B5FD6EEF
00007aa9b5fd327a  vmovaps xmm15, [rsp+0x90]
00007aa9b5fd3283  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd3289  vmovaps xmm8, [rsp+0x50]
00007aa9b5fd328f  movaps xmm12, xmm8
00007aa9b5fd3293  mulpd xmm12, xmm15
00007aa9b5fd3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007aa9b5fd329e  ptest xmm6, xmm6
00007aa9b5fd32a3  jnz 0x00007AA9B5FD7033
00007aa9b5fd32a9  vmovaps xmm15, [rsp+0x30]
00007aa9b5fd32af  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd32b5  movaps xmm8, xmm7
00007aa9b5fd32b9  mulpd xmm8, xmm15
00007aa9b5fd32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa9b5fd32c4  ptest xmm6, xmm6
00007aa9b5fd32c9  jnz 0x00007AA9B5FD7177
00007aa9b5fd32cf  movaps xmm15, xmm14
00007aa9b5fd32d3  addpd xmm15, xmm9
00007aa9b5fd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007aa9b5fd32de  ptest xmm7, xmm7
00007aa9b5fd32e3  jnz 0x00007AA9B5FD72BA
00007aa9b5fd32e9  vmovaps xmm14, [rsp+0x30]
00007aa9b5fd32ef  vpermilpd xmm14, xmm14, 0x00
00007aa9b5fd32f5  vmovaps xmm7, [rsp+0xF0]
00007aa9b5fd32fe  movaps xmm9, xmm7
00007aa9b5fd3302  mulpd xmm9, xmm14
00007aa9b5fd3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa9b5fd330d  ptest xmm6, xmm6
00007aa9b5fd3312  jnz 0x00007AA9B5FD73FE
00007aa9b5fd3318  movaps xmm14, xmm13
00007aa9b5fd331c  addpd xmm14, xmm11
00007aa9b5fd3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007aa9b5fd3327  ptest xmm7, xmm7
00007aa9b5fd332c  jnz 0x00007AA9B5FD7541
00007aa9b5fd3332  vmovaps xmm13, [rsp+0x30]
00007aa9b5fd3338  vpermilpd xmm13, xmm13, 0x00
00007aa9b5fd333e  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd3344  movaps xmm11, xmm7
00007aa9b5fd3348  mulpd xmm11, xmm13
00007aa9b5fd334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007aa9b5fd3353  ptest xmm6, xmm6
00007aa9b5fd3358  jnz 0x00007AA9B5FD7685
00007aa9b5fd335e  movaps xmm13, xmm10
00007aa9b5fd3362  addpd xmm13, xmm12
00007aa9b5fd3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007aa9b5fd336d  ptest xmm7, xmm7
00007aa9b5fd3372  jnz 0x00007AA9B5FD77C8
00007aa9b5fd3378  vmovaps xmm12, [rsp+0x30]
00007aa9b5fd337e  vpermilpd xmm12, xmm12, 0x00
00007aa9b5fd3384  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd338a  movaps xmm10, xmm7
00007aa9b5fd338e  mulpd xmm10, xmm12
00007aa9b5fd3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007aa9b5fd3399  ptest xmm6, xmm6
00007aa9b5fd339e  jnz 0x00007AA9B5FD790C
00007aa9b5fd33a4  movaps xmm12, xmm1
00007aa9b5fd33a8  addpd xmm12, xmm8
00007aa9b5fd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007aa9b5fd33b3  ptest xmm7, xmm7
00007aa9b5fd33b8  jnz 0x00007AA9B5FD7A4F
00007aa9b5fd33be  lea rax, [r14+0x70]
00007aa9b5fd33c2  movups xmm1, [r13+rax*1]
00007aa9b5fd33c8  movaps [r15+0x240], xmm1
00007aa9b5fd33d0  movaps xmm8, xmm15
00007aa9b5fd33d4  addpd xmm8, xmm9
00007aa9b5fd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa9b5fd33df  ptest xmm7, xmm7
00007aa9b5fd33e4  jnz 0x00007AA9B5FD7B9C
00007aa9b5fd33ea  movaps [r15+0x170], xmm8
00007aa9b5fd33f2  vmovaps xmm15, [rsp+0x40]
00007aa9b5fd33f8  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd33fe  movaps xmm9, xmm1
00007aa9b5fd3402  mulpd xmm9, xmm15
00007aa9b5fd3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007aa9b5fd340d  ptest xmm7, xmm7
00007aa9b5fd3412  jnz 0x00007AA9B5FD7CE0
00007aa9b5fd3418  vmovaps xmm1, [rsp+0x40]
00007aa9b5fd341e  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd3424  movaps xmm15, xmm4
00007aa9b5fd3428  mulpd xmm15, xmm1
00007aa9b5fd342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007aa9b5fd3433  ptest xmm7, xmm7
00007aa9b5fd3438  jnz 0x00007AA9B5FD7E23
00007aa9b5fd343e  movaps [r15+0x180], xmm15
00007aa9b5fd3446  movaps xmm1, xmm14
00007aa9b5fd344a  addpd xmm1, xmm11
00007aa9b5fd344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007aa9b5fd3454  ptest xmm7, xmm7
00007aa9b5fd3459  jnz 0x00007AA9B5FD7F65
00007aa9b5fd345f  movaps [r15+0x210], xmm1
00007aa9b5fd3467  movups xmm14, [r13+r14*1]
00007aa9b5fd346d  lea rax, [r14+0x10]
00007aa9b5fd3471  movups xmm11, [r13+rax*1]
00007aa9b5fd3477  movaps [r15+0x230], xmm11
00007aa9b5fd347f  movaps xmm7, xmm13
00007aa9b5fd3483  addpd xmm7, xmm10
00007aa9b5fd3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa9b5fd348d  ptest xmm6, xmm6
00007aa9b5fd3492  jnz 0x00007AA9B5FD80BB
00007aa9b5fd3498  movaps [r15+0x130], xmm7
00007aa9b5fd34a0  vmovaps xmm13, [rsp+0x40]
00007aa9b5fd34a6  vpermilpd xmm13, xmm13, 0x00
00007aa9b5fd34ac  movaps xmm10, xmm11
00007aa9b5fd34b0  mulpd xmm10, xmm13
00007aa9b5fd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007aa9b5fd34bb  ptest xmm6, xmm6
00007aa9b5fd34c0  jnz 0x00007AA9B5FD81FD
00007aa9b5fd34c6  movaps [r15+0x220], xmm10
00007aa9b5fd34ce  vmovaps xmm13, [rsp+0x40]
00007aa9b5fd34d4  vpermilpd xmm13, xmm13, 0x00
00007aa9b5fd34da  movaps xmm11, xmm14
00007aa9b5fd34de  mulpd xmm11, xmm13
00007aa9b5fd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007aa9b5fd34e9  ptest xmm6, xmm6
00007aa9b5fd34ee  jnz 0x00007AA9B5FD8341
00007aa9b5fd34f4  movaps xmm14, xmm12
00007aa9b5fd34f8  addpd xmm14, xmm9
00007aa9b5fd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007aa9b5fd3503  ptest xmm13, xmm13
00007aa9b5fd3509  jnz 0x00007AA9B5FD8485
00007aa9b5fd350f  movaps [r15+0x140], xmm14
00007aa9b5fd3517  movaps xmm13, xmm8
00007aa9b5fd351b  addpd xmm13, xmm15
00007aa9b5fd3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007aa9b5fd3526  ptest xmm12, xmm12
00007aa9b5fd352c  jnz 0x00007AA9B5FD85C9
00007aa9b5fd3532  movaps [r15+0x150], xmm13
00007aa9b5fd353a  movaps xmm15, xmm1
00007aa9b5fd353e  addpd xmm15, xmm10
00007aa9b5fd3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007aa9b5fd3549  ptest xmm12, xmm12
00007aa9b5fd354f  jnz 0x00007AA9B5FD870D
00007aa9b5fd3555  movaps [r15+0x160], xmm15
00007aa9b5fd355d  movaps xmm1, xmm7
00007aa9b5fd3560  addpd xmm1, xmm11
00007aa9b5fd3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa9b5fd356a  ptest xmm12, xmm12
00007aa9b5fd3570  jnz 0x00007AA9B5FD8850
00007aa9b5fd3576  movaps [r15+0x120], xmm1
00007aa9b5fd357e  mov eax, 0x432200
00007aa9b5fd3583  movups [r13+rax*1], xmm14
00007aa9b5fd3589  mov eax, 0x432210
00007aa9b5fd358e  movups [r13+rax*1], xmm13
00007aa9b5fd3594  mov eax, 0x432220
00007aa9b5fd3599  movups [r13+rax*1], xmm15
00007aa9b5fd359f  mov eax, 0x432230
00007aa9b5fd35a4  movups [r13+rax*1], xmm1
00007aa9b5fd35aa  mov eax, [r15+0x108]
00007aa9b5fd35b1  sahf
00007aa9b5fd35b2  jnz 0x00007AA9B5FD35E4
00007aa9b5fd35b4  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd35bc  jz 0x00007AA9B5FDEAE0
00007aa9b5fd35c2  nop [rax+rax*1], ax
00007aa9b5fd35cb  nop [rax+rax*1], eax
00007aa9b5fd35d3  mov eax, 0x4106D0
00007aa9b5fd35d8  mov [r15+0x100], rax
00007aa9b5fd35df  jmp 0x00007AA9B5DFE110
00007aa9b5fd35e4  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd35ec  jz 0x00007AA9B5FD89C0
00007aa9b5fd35f2  nop [rax+rax*1], ax
00007aa9b5fd35fb  nop [rax+rax*1], eax
00007aa9b5fd3603  mov eax, 0x410504
00007aa9b5fd3608  mov [r15+0x100], rax
00007aa9b5fd360f  jmp 0x00007AA9B5DFE110
00007aa9b5fd3614  int3
00007aa9b5fd3615  call 0x00007AA9B5ED64F0
00007aa9b5fd361a  jmp 0x00007AA9B5FD2311
00007aa9b5fd361f  call 0x00007AA9B5EE5820
00007aa9b5fd3624  jmp 0x00007AA9B5FD231E
00007aa9b5fd3629  call 0x00007AA9B5EE3320
00007aa9b5fd362e  jmp 0x00007AA9B5FD2332
00007aa9b5fd3633  call 0x00007AA9B5EE20A0
00007aa9b5fd3638  jmp 0x00007AA9B5FD233C
00007aa9b5fd363d  call 0x00007AA9B5E09D70
00007aa9b5fd3642  jmp 0x00007AA9B5FD234A
00007aa9b5fd3647  call 0x00007AA9B5EDFBC0
00007aa9b5fd364c  jmp 0x00007AA9B5FD2354
00007aa9b5fd3651  call 0x00007AA9B5EC4740
00007aa9b5fd3656  jmp 0x00007AA9B5FD2368
00007aa9b5fd365b  call 0x00007AA9B5EB5400
00007aa9b5fd3660  jmp 0x00007AA9B5FD2375
00007aa9b5fd3665  call 0x00007AA9B5EB52F0
00007aa9b5fd366a  jmp 0x00007AA9B5FD2382
00007aa9b5fd366f  call 0x00007AA9B5EC4620
00007aa9b5fd3674  jmp 0x00007AA9B5FD238F
00007aa9b5fd3679  call 0x00007AA9B5EBD750
00007aa9b5fd367e  jmp 0x00007AA9B5FD239C
00007aa9b5fd3683  call 0x00007AA9B5EBC4E0
00007aa9b5fd3688  jmp 0x00007AA9B5FD23A9
00007aa9b5fd368d  call 0x00007AA9B5EBB270
00007aa9b5fd3692  jmp 0x00007AA9B5FD23B6
00007aa9b5fd3697  call 0x00007AA9B5EBA000
00007aa9b5fd369c  jmp 0x00007AA9B5FD23C3
00007aa9b5fd36a1  call 0x00007AA9B5EC4740
00007aa9b5fd36a6  jmp 0x00007AA9B5FD23D0
00007aa9b5fd36ab  call 0x00007AA9B5EB5400
00007aa9b5fd36b0  jmp 0x00007AA9B5FD23DD
00007aa9b5fd36b5  call 0x00007AA9B5EB52F0
00007aa9b5fd36ba  jmp 0x00007AA9B5FD23EA
00007aa9b5fd36bf  call 0x00007AA9B5EC4620
00007aa9b5fd36c4  jmp 0x00007AA9B5FD23F7
00007aa9b5fd36c9  call 0x00007AA9B5EB8D90
00007aa9b5fd36ce  jmp 0x00007AA9B5FD2404
00007aa9b5fd36d3  call 0x00007AA9B5EB8A20
00007aa9b5fd36d8  jmp 0x00007AA9B5FD2411
00007aa9b5fd36dd  call 0x00007AA9B5EB77B0
00007aa9b5fd36e2  jmp 0x00007AA9B5FD241B
00007aa9b5fd36e7  call 0x00007AA9B5EB6550
00007aa9b5fd36ec  jmp 0x00007AA9B5FD2425
00007aa9b5fd36f1  call 0x00007AA9B5EB5400
00007aa9b5fd36f6  jmp 0x00007AA9B5FD2437
00007aa9b5fd36fb  call 0x00007AA9B5EC0FC0
00007aa9b5fd3700  jmp 0x00007AA9B5FD2441
00007aa9b5fd3705  call 0x00007AA9B5EB52F0
00007aa9b5fd370a  jmp 0x00007AA9B5FD244B
00007aa9b5fd370f  call 0x00007AA9B5EC0EA0
00007aa9b5fd3714  jmp 0x00007AA9B5FD2455
00007aa9b5fd3719  call 0x00007AA9B5EBFD50
00007aa9b5fd371e  jmp 0x00007AA9B5FD245F
00007aa9b5fd3723  call 0x00007AA9B5EB8EA0
00007aa9b5fd3728  jmp 0x00007AA9B5FD2469
00007aa9b5fd372d  call 0x00007AA9B5EBFC30
00007aa9b5fd3732  jmp 0x00007AA9B5FD2476
00007aa9b5fd3737  call 0x00007AA9B5EB8D90
00007aa9b5fd373c  jmp 0x00007AA9B5FD2483
00007aa9b5fd3741  call 0x00007AA9B5EB52F0
00007aa9b5fd3746  jmp 0x00007AA9B5FD2496
00007aa9b5fd374b  call 0x00007AA9B5EB52F0
00007aa9b5fd3750  jmp 0x00007AA9B5FD24A9
00007aa9b5fd3755  call 0x00007AA9B5EC0FC0
00007aa9b5fd375a  jmp 0x00007AA9B5FD24B6
00007aa9b5fd375f  call 0x00007AA9B5EC0FC0
00007aa9b5fd3764  jmp 0x00007AA9B5FD24C9
00007aa9b5fd3769  call 0x00007AA9B5EC0EA0
00007aa9b5fd376e  jmp 0x00007AA9B5FD24D6
00007aa9b5fd3773  call 0x00007AA9B5EB52F0
00007aa9b5fd3778  jmp 0x00007AA9B5FD24E9
00007aa9b5fd377d  call 0x00007AA9B5EB52F0
00007aa9b5fd3782  jmp 0x00007AA9B5FD24FC
00007aa9b5fd3787  call 0x00007AA9B5EB52F0
00007aa9b5fd378c  jmp 0x00007AA9B5FD250F
00007aa9b5fd3791  call 0x00007AA9B5EB52F0
00007aa9b5fd3796  jmp 0x00007AA9B5FD252A
00007aa9b5fd379b  call 0x00007AA9B5EB52F0
00007aa9b5fd37a0  jmp 0x00007AA9B5FD253D
00007aa9b5fd37a5  call 0x00007AA9B5EB5400
00007aa9b5fd37aa  jmp 0x00007AA9B5FD257E
00007aa9b5fd37af  call 0x00007AA9B5EC0FC0
00007aa9b5fd37b4  jmp 0x00007AA9B5FD258B
00007aa9b5fd37b9  call 0x00007AA9B5EB52F0
00007aa9b5fd37be  jmp 0x00007AA9B5FD2598
00007aa9b5fd37c3  call 0x00007AA9B5EC0EA0
00007aa9b5fd37c8  jmp 0x00007AA9B5FD25A5
00007aa9b5fd37cd  call 0x00007AA9B5DFF540
00007aa9b5fd37d2  jmp 0x00007AA9B5FD25C3
00007aa9b5fd37d7  call 0x00007AA9B5E08C20
00007aa9b5fd37dc  jmp 0x00007AA9B5FD25CD
00007aa9b5fd37e1  call 0x00007AA9B5EE21C0
00007aa9b5fd37e6  jmp 0x00007AA9B5FD25D3
00007aa9b5fd37eb  call 0x00007AA9B5DFF540
00007aa9b5fd37f0  jmp 0x00007AA9B5FD25E3
00007aa9b5fd37f5  call 0x00007AA9B5EC0370
00007aa9b5fd37fa  jmp 0x00007AA9B5FD2611
00007aa9b5fd37ff  call 0x00007AA9B5EBF100
00007aa9b5fd3804  jmp 0x00007AA9B5FD261A
00007aa9b5fd3809  call 0x00007AA9B5EC0370
00007aa9b5fd380e  jmp 0x00007AA9B5FD2674
00007aa9b5fd3813  call 0x00007AA9B5EBF100
00007aa9b5fd3818  jmp 0x00007AA9B5FD267D
00007aa9b5fd381d  call 0x00007AA9B5EC0370
00007aa9b5fd3822  jmp 0x00007AA9B5FD26C6
00007aa9b5fd3827  call 0x00007AA9B5EBF100
00007aa9b5fd382c  jmp 0x00007AA9B5FD26CF
00007aa9b5fd3831  call 0x00007AA9B5E0B720
00007aa9b5fd3836  jmp 0x00007AA9B5FD2714
00007aa9b5fd383b  call 0x00007AA9B5EB47C0
00007aa9b5fd3840  jmp 0x00007AA9B5FD2727
00007aa9b5fd3845  call 0x00007AA9B5E08B00
00007aa9b5fd384a  jmp 0x00007AA9B5FD273E
00007aa9b5fd384f  call 0x00007AA9B5DFF430
00007aa9b5fd3854  jmp 0x00007AA9B5FD2751
00007aa9b5fd3859  call 0x00007AA9B5DFF430
00007aa9b5fd385e  jmp 0x00007AA9B5FD2764
00007aa9b5fd3863  sub rsp, 0x08
00007aa9b5fd3867  push rax
00007aa9b5fd3868  push rcx
00007aa9b5fd3869  push rdx
00007aa9b5fd386a  push rdi
00007aa9b5fd386b  push rsi
00007aa9b5fd386c  push r8
00007aa9b5fd386e  push r9
00007aa9b5fd3870  push r10
00007aa9b5fd3872  push r11
00007aa9b5fd3874  sub rsp, 0xF0
00007aa9b5fd387b  vmovaps [rsp], xmm0
00007aa9b5fd3880  vmovaps [rsp+0x10], xmm2
00007aa9b5fd3886  vmovaps [rsp+0x20], xmm3
00007aa9b5fd388c  vmovaps [rsp+0x30], xmm4
00007aa9b5fd3892  vmovaps [rsp+0x40], xmm5
00007aa9b5fd3898  vmovaps [rsp+0x50], xmm6
00007aa9b5fd389e  vmovaps [rsp+0x60], xmm7
00007aa9b5fd38a4  vmovaps [rsp+0x70], xmm8
00007aa9b5fd38aa  vmovaps [rsp+0x80], xmm9
00007aa9b5fd38b3  vmovaps [rsp+0x90], xmm10
00007aa9b5fd38bc  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd38c5  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd38ce  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd38d7  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd38e0  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd38e9  sub rsp, 0x30
00007aa9b5fd38ed  movaps [rsp], xmm1
00007aa9b5fd38f1  movaps [rsp+0x10], xmm12
00007aa9b5fd38f7  movaps [rsp+0x20], xmm15
00007aa9b5fd38fd  lea rdi, [rsp]
00007aa9b5fd3901  mov esi, 0x00
00007aa9b5fd3906  mov rax, 0x63E0217C9530
00007aa9b5fd3910  call rax
00007aa9b5fd3912  movaps xmm1, [rsp]
00007aa9b5fd3916  add rsp, 0x30
00007aa9b5fd391a  vmovaps xmm0, [rsp]
00007aa9b5fd391f  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd3925  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd392b  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd3931  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd3937  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd393d  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd3943  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd3949  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd3952  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd395b  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd3964  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd396d  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd3976  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd397f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd3988  add rsp, 0xF0
00007aa9b5fd398f  pop r11
00007aa9b5fd3991  pop r10
00007aa9b5fd3993  pop r9
00007aa9b5fd3995  pop r8
00007aa9b5fd3997  pop rsi
00007aa9b5fd3998  pop rdi
00007aa9b5fd3999  pop rdx
00007aa9b5fd399a  pop rcx
00007aa9b5fd399b  pop rax
00007aa9b5fd399c  add rsp, 0x08
00007aa9b5fd39a0  jmp 0x00007AA9B5FD27B2
00007aa9b5fd39a5  sub rsp, 0x08
00007aa9b5fd39a9  push rax
00007aa9b5fd39aa  push rcx
00007aa9b5fd39ab  push rdx
00007aa9b5fd39ac  push rdi
00007aa9b5fd39ad  push rsi
00007aa9b5fd39ae  push r8
00007aa9b5fd39b0  push r9
00007aa9b5fd39b2  push r10
00007aa9b5fd39b4  push r11
00007aa9b5fd39b6  sub rsp, 0xF0
00007aa9b5fd39bd  vmovaps [rsp], xmm0
00007aa9b5fd39c2  vmovaps [rsp+0x10], xmm1
00007aa9b5fd39c8  vmovaps [rsp+0x20], xmm2
00007aa9b5fd39ce  vmovaps [rsp+0x30], xmm3
00007aa9b5fd39d4  vmovaps [rsp+0x40], xmm4
00007aa9b5fd39da  vmovaps [rsp+0x50], xmm5
00007aa9b5fd39e0  vmovaps [rsp+0x60], xmm6
00007aa9b5fd39e6  vmovaps [rsp+0x70], xmm7
00007aa9b5fd39ec  vmovaps [rsp+0x80], xmm8
00007aa9b5fd39f5  vmovaps [rsp+0x90], xmm9
00007aa9b5fd39fe  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd3a07  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd3a10  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd3a19  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd3a22  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd3a2b  sub rsp, 0x30
00007aa9b5fd3a2f  movaps [rsp], xmm14
00007aa9b5fd3a34  movaps [rsp+0x10], xmm1
00007aa9b5fd3a39  movaps [rsp+0x20], xmm15
00007aa9b5fd3a3f  lea rdi, [rsp]
00007aa9b5fd3a43  mov esi, 0x00
00007aa9b5fd3a48  mov rax, 0x63E0217C9530
00007aa9b5fd3a52  call rax
00007aa9b5fd3a54  movaps xmm14, [rsp]
00007aa9b5fd3a59  add rsp, 0x30
00007aa9b5fd3a5d  vmovaps xmm0, [rsp]
00007aa9b5fd3a62  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd3a68  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd3a6e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd3a74  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd3a7a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd3a80  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd3a86  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd3a8c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd3a95  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd3a9e  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd3aa7  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd3ab0  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd3ab9  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd3ac2  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd3acb  add rsp, 0xF0
00007aa9b5fd3ad2  pop r11
00007aa9b5fd3ad4  pop r10
00007aa9b5fd3ad6  pop r9
00007aa9b5fd3ad8  pop r8
00007aa9b5fd3ada  pop rsi
00007aa9b5fd3adb  pop rdi
00007aa9b5fd3adc  pop rdx
00007aa9b5fd3add  pop rcx
00007aa9b5fd3ade  pop rax
00007aa9b5fd3adf  add rsp, 0x08
00007aa9b5fd3ae3  jmp 0x00007AA9B5FD2800
00007aa9b5fd3ae8  sub rsp, 0x08
00007aa9b5fd3aec  push rax
00007aa9b5fd3aed  push rcx
00007aa9b5fd3aee  push rdx
00007aa9b5fd3aef  push rdi
00007aa9b5fd3af0  push rsi
00007aa9b5fd3af1  push r8
00007aa9b5fd3af3  push r9
00007aa9b5fd3af5  push r10
00007aa9b5fd3af7  push r11
00007aa9b5fd3af9  sub rsp, 0xF0
00007aa9b5fd3b00  vmovaps [rsp], xmm0
00007aa9b5fd3b05  vmovaps [rsp+0x10], xmm1
00007aa9b5fd3b0b  vmovaps [rsp+0x20], xmm2
00007aa9b5fd3b11  vmovaps [rsp+0x30], xmm3
00007aa9b5fd3b17  vmovaps [rsp+0x40], xmm4
00007aa9b5fd3b1d  vmovaps [rsp+0x50], xmm5
00007aa9b5fd3b23  vmovaps [rsp+0x60], xmm6
00007aa9b5fd3b29  vmovaps [rsp+0x70], xmm7
00007aa9b5fd3b2f  vmovaps [rsp+0x80], xmm8
00007aa9b5fd3b38  vmovaps [rsp+0x90], xmm9
00007aa9b5fd3b41  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd3b4a  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd3b53  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd3b5c  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd3b65  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd3b6e  sub rsp, 0x30
00007aa9b5fd3b72  movaps [rsp], xmm15
00007aa9b5fd3b77  movaps [rsp+0x10], xmm12
00007aa9b5fd3b7d  movaps [rsp+0x20], xmm13
00007aa9b5fd3b83  lea rdi, [rsp]
00007aa9b5fd3b87  mov esi, 0x00
00007aa9b5fd3b8c  mov rax, 0x63E0217C9530
00007aa9b5fd3b96  call rax
00007aa9b5fd3b98  movaps xmm15, [rsp]
00007aa9b5fd3b9d  add rsp, 0x30
00007aa9b5fd3ba1  vmovaps xmm0, [rsp]
00007aa9b5fd3ba6  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd3bac  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd3bb2  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd3bb8  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd3bbe  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd3bc4  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd3bca  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd3bd0  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd3bd9  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd3be2  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd3beb  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd3bf4  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd3bfd  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd3c06  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd3c0f  add rsp, 0xF0
00007aa9b5fd3c16  pop r11
00007aa9b5fd3c18  pop r10
00007aa9b5fd3c1a  pop r9
00007aa9b5fd3c1c  pop r8
00007aa9b5fd3c1e  pop rsi
00007aa9b5fd3c1f  pop rdi
00007aa9b5fd3c20  pop rdx
00007aa9b5fd3c21  pop rcx
00007aa9b5fd3c22  pop rax
00007aa9b5fd3c23  add rsp, 0x08
00007aa9b5fd3c27  jmp 0x00007AA9B5FD2835
00007aa9b5fd3c2c  sub rsp, 0x08
00007aa9b5fd3c30  push rax
00007aa9b5fd3c31  push rcx
00007aa9b5fd3c32  push rdx
00007aa9b5fd3c33  push rdi
00007aa9b5fd3c34  push rsi
00007aa9b5fd3c35  push r8
00007aa9b5fd3c37  push r9
00007aa9b5fd3c39  push r10
00007aa9b5fd3c3b  push r11
00007aa9b5fd3c3d  sub rsp, 0xF0
00007aa9b5fd3c44  vmovaps [rsp], xmm0
00007aa9b5fd3c49  vmovaps [rsp+0x10], xmm2
00007aa9b5fd3c4f  vmovaps [rsp+0x20], xmm3
00007aa9b5fd3c55  vmovaps [rsp+0x30], xmm4
00007aa9b5fd3c5b  vmovaps [rsp+0x40], xmm5
00007aa9b5fd3c61  vmovaps [rsp+0x50], xmm6
00007aa9b5fd3c67  vmovaps [rsp+0x60], xmm7
00007aa9b5fd3c6d  vmovaps [rsp+0x70], xmm8
00007aa9b5fd3c73  vmovaps [rsp+0x80], xmm9
00007aa9b5fd3c7c  vmovaps [rsp+0x90], xmm10
00007aa9b5fd3c85  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd3c8e  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd3c97  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd3ca0  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd3ca9  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd3cb2  sub rsp, 0x30
00007aa9b5fd3cb6  movaps [rsp], xmm1
00007aa9b5fd3cba  movaps [rsp+0x10], xmm12
00007aa9b5fd3cc0  movaps [rsp+0x20], xmm10
00007aa9b5fd3cc6  lea rdi, [rsp]
00007aa9b5fd3cca  mov esi, 0x00
00007aa9b5fd3ccf  mov rax, 0x63E0217C9530
00007aa9b5fd3cd9  call rax
00007aa9b5fd3cdb  movaps xmm1, [rsp]
00007aa9b5fd3cdf  add rsp, 0x30
00007aa9b5fd3ce3  vmovaps xmm0, [rsp]
00007aa9b5fd3ce8  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd3cee  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd3cf4  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd3cfa  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd3d00  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd3d06  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd3d0c  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd3d12  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd3d1b  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd3d24  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd3d2d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd3d36  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd3d3f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd3d48  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd3d51  add rsp, 0xF0
00007aa9b5fd3d58  pop r11
00007aa9b5fd3d5a  pop r10
00007aa9b5fd3d5c  pop r9
00007aa9b5fd3d5e  pop r8
00007aa9b5fd3d60  pop rsi
00007aa9b5fd3d61  pop rdi
00007aa9b5fd3d62  pop rdx
00007aa9b5fd3d63  pop rcx
00007aa9b5fd3d64  pop rax
00007aa9b5fd3d65  add rsp, 0x08
00007aa9b5fd3d69  jmp 0x00007AA9B5FD284F
00007aa9b5fd3d6e  sub rsp, 0x08
00007aa9b5fd3d72  push rax
00007aa9b5fd3d73  push rcx
00007aa9b5fd3d74  push rdx
00007aa9b5fd3d75  push rdi
00007aa9b5fd3d76  push rsi
00007aa9b5fd3d77  push r8
00007aa9b5fd3d79  push r9
00007aa9b5fd3d7b  push r10
00007aa9b5fd3d7d  push r11
00007aa9b5fd3d7f  sub rsp, 0xF0
00007aa9b5fd3d86  vmovaps [rsp], xmm0
00007aa9b5fd3d8b  vmovaps [rsp+0x10], xmm1
00007aa9b5fd3d91  vmovaps [rsp+0x20], xmm2
00007aa9b5fd3d97  vmovaps [rsp+0x30], xmm3
00007aa9b5fd3d9d  vmovaps [rsp+0x40], xmm4
00007aa9b5fd3da3  vmovaps [rsp+0x50], xmm5
00007aa9b5fd3da9  vmovaps [rsp+0x60], xmm6
00007aa9b5fd3daf  vmovaps [rsp+0x70], xmm7
00007aa9b5fd3db5  vmovaps [rsp+0x80], xmm8
00007aa9b5fd3dbe  vmovaps [rsp+0x90], xmm9
00007aa9b5fd3dc7  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd3dd0  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd3dd9  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd3de2  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd3deb  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd3df4  sub rsp, 0x30
00007aa9b5fd3df8  movaps [rsp], xmm13
00007aa9b5fd3dfd  movaps [rsp+0x10], xmm12
00007aa9b5fd3e03  movaps [rsp+0x20], xmm2
00007aa9b5fd3e08  lea rdi, [rsp]
00007aa9b5fd3e0c  mov esi, 0x00
00007aa9b5fd3e11  mov rax, 0x63E0217C9530
00007aa9b5fd3e1b  call rax
00007aa9b5fd3e1d  movaps xmm13, [rsp]
00007aa9b5fd3e22  add rsp, 0x30
00007aa9b5fd3e26  vmovaps xmm0, [rsp]
00007aa9b5fd3e2b  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd3e31  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd3e37  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd3e3d  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd3e43  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd3e49  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd3e4f  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd3e55  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd3e5e  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd3e67  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd3e70  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd3e79  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd3e82  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd3e8b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd3e94  add rsp, 0xF0
00007aa9b5fd3e9b  pop r11
00007aa9b5fd3e9d  pop r10
00007aa9b5fd3e9f  pop r9
00007aa9b5fd3ea1  pop r8
00007aa9b5fd3ea3  pop rsi
00007aa9b5fd3ea4  pop rdi
00007aa9b5fd3ea5  pop rdx
00007aa9b5fd3ea6  pop rcx
00007aa9b5fd3ea7  pop rax
00007aa9b5fd3ea8  add rsp, 0x08
00007aa9b5fd3eac  jmp 0x00007AA9B5FD286A
00007aa9b5fd3eb1  sub rsp, 0x08
00007aa9b5fd3eb5  push rax
00007aa9b5fd3eb6  push rcx
00007aa9b5fd3eb7  push rdx
00007aa9b5fd3eb8  push rdi
00007aa9b5fd3eb9  push rsi
00007aa9b5fd3eba  push r8
00007aa9b5fd3ebc  push r9
00007aa9b5fd3ebe  push r10
00007aa9b5fd3ec0  push r11
00007aa9b5fd3ec2  sub rsp, 0xF0
00007aa9b5fd3ec9  vmovaps [rsp], xmm0
00007aa9b5fd3ece  vmovaps [rsp+0x10], xmm2
00007aa9b5fd3ed4  vmovaps [rsp+0x20], xmm3
00007aa9b5fd3eda  vmovaps [rsp+0x30], xmm4
00007aa9b5fd3ee0  vmovaps [rsp+0x40], xmm5
00007aa9b5fd3ee6  vmovaps [rsp+0x50], xmm6
00007aa9b5fd3eec  vmovaps [rsp+0x60], xmm7
00007aa9b5fd3ef2  vmovaps [rsp+0x70], xmm8
00007aa9b5fd3ef8  vmovaps [rsp+0x80], xmm9
00007aa9b5fd3f01  vmovaps [rsp+0x90], xmm10
00007aa9b5fd3f0a  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd3f13  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd3f1c  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd3f25  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd3f2e  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd3f37  sub rsp, 0x30
00007aa9b5fd3f3b  movaps [rsp], xmm1
00007aa9b5fd3f3f  movaps [rsp+0x10], xmm10
00007aa9b5fd3f45  movaps [rsp+0x20], xmm2
00007aa9b5fd3f4a  lea rdi, [rsp]
00007aa9b5fd3f4e  mov esi, 0x00
00007aa9b5fd3f53  mov rax, 0x63E0217C9530
00007aa9b5fd3f5d  call rax
00007aa9b5fd3f5f  movaps xmm1, [rsp]
00007aa9b5fd3f63  add rsp, 0x30
00007aa9b5fd3f67  vmovaps xmm0, [rsp]
00007aa9b5fd3f6c  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd3f72  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd3f78  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd3f7e  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd3f84  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd3f8a  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd3f90  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd3f96  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd3f9f  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd3fa8  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd3fb1  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd3fba  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd3fc3  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd3fcc  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd3fd5  add rsp, 0xF0
00007aa9b5fd3fdc  pop r11
00007aa9b5fd3fde  pop r10
00007aa9b5fd3fe0  pop r9
00007aa9b5fd3fe2  pop r8
00007aa9b5fd3fe4  pop rsi
00007aa9b5fd3fe5  pop rdi
00007aa9b5fd3fe6  pop rdx
00007aa9b5fd3fe7  pop rcx
00007aa9b5fd3fe8  pop rax
00007aa9b5fd3fe9  add rsp, 0x08
00007aa9b5fd3fed  jmp 0x00007AA9B5FD28D2
00007aa9b5fd3ff2  sub rsp, 0x08
00007aa9b5fd3ff6  push rax
00007aa9b5fd3ff7  push rcx
00007aa9b5fd3ff8  push rdx
00007aa9b5fd3ff9  push rdi
00007aa9b5fd3ffa  push rsi
00007aa9b5fd3ffb  push r8
00007aa9b5fd3ffd  push r9
00007aa9b5fd3fff  push r10
00007aa9b5fd4001  push r11
00007aa9b5fd4003  sub rsp, 0xF0
00007aa9b5fd400a  vmovaps [rsp], xmm0
00007aa9b5fd400f  vmovaps [rsp+0x10], xmm1
00007aa9b5fd4015  vmovaps [rsp+0x20], xmm2
00007aa9b5fd401b  vmovaps [rsp+0x30], xmm3
00007aa9b5fd4021  vmovaps [rsp+0x40], xmm4
00007aa9b5fd4027  vmovaps [rsp+0x50], xmm5
00007aa9b5fd402d  vmovaps [rsp+0x60], xmm6
00007aa9b5fd4033  vmovaps [rsp+0x70], xmm7
00007aa9b5fd4039  vmovaps [rsp+0x80], xmm8
00007aa9b5fd4042  vmovaps [rsp+0x90], xmm9
00007aa9b5fd404b  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd4054  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd405d  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd4066  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd406f  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd4078  sub rsp, 0x30
00007aa9b5fd407c  movaps [rsp], xmm15
00007aa9b5fd4081  movaps [rsp+0x10], xmm10
00007aa9b5fd4087  movaps [rsp+0x20], xmm2
00007aa9b5fd408c  lea rdi, [rsp]
00007aa9b5fd4090  mov esi, 0x00
00007aa9b5fd4095  mov rax, 0x63E0217C9530
00007aa9b5fd409f  call rax
00007aa9b5fd40a1  movaps xmm15, [rsp]
00007aa9b5fd40a6  add rsp, 0x30
00007aa9b5fd40aa  vmovaps xmm0, [rsp]
00007aa9b5fd40af  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd40b5  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd40bb  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd40c1  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd40c7  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd40cd  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd40d3  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd40d9  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd40e2  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd40eb  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd40f4  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd40fd  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd4106  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd410f  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd4118  add rsp, 0xF0
00007aa9b5fd411f  pop r11
00007aa9b5fd4121  pop r10
00007aa9b5fd4123  pop r9
00007aa9b5fd4125  pop r8
00007aa9b5fd4127  pop rsi
00007aa9b5fd4128  pop rdi
00007aa9b5fd4129  pop rdx
00007aa9b5fd412a  pop rcx
00007aa9b5fd412b  pop rax
00007aa9b5fd412c  add rsp, 0x08
00007aa9b5fd4130  jmp 0x00007AA9B5FD2924
00007aa9b5fd4135  sub rsp, 0x08
00007aa9b5fd4139  push rax
00007aa9b5fd413a  push rcx
00007aa9b5fd413b  push rdx
00007aa9b5fd413c  push rdi
00007aa9b5fd413d  push rsi
00007aa9b5fd413e  push r8
00007aa9b5fd4140  push r9
00007aa9b5fd4142  push r10
00007aa9b5fd4144  push r11
00007aa9b5fd4146  sub rsp, 0xF0
00007aa9b5fd414d  vmovaps [rsp], xmm0
00007aa9b5fd4152  vmovaps [rsp+0x10], xmm2
00007aa9b5fd4158  vmovaps [rsp+0x20], xmm3
00007aa9b5fd415e  vmovaps [rsp+0x30], xmm4
00007aa9b5fd4164  vmovaps [rsp+0x40], xmm5
00007aa9b5fd416a  vmovaps [rsp+0x50], xmm6
00007aa9b5fd4170  vmovaps [rsp+0x60], xmm7
00007aa9b5fd4176  vmovaps [rsp+0x70], xmm8
00007aa9b5fd417c  vmovaps [rsp+0x80], xmm9
00007aa9b5fd4185  vmovaps [rsp+0x90], xmm10
00007aa9b5fd418e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd4197  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd41a0  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd41a9  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd41b2  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd41bb  sub rsp, 0x30
00007aa9b5fd41bf  movaps [rsp], xmm1
00007aa9b5fd41c3  movaps [rsp+0x10], xmm10
00007aa9b5fd41c9  movaps [rsp+0x20], xmm15
00007aa9b5fd41cf  lea rdi, [rsp]
00007aa9b5fd41d3  mov esi, 0x00
00007aa9b5fd41d8  mov rax, 0x63E0217C9530
00007aa9b5fd41e2  call rax
00007aa9b5fd41e4  movaps xmm1, [rsp]
00007aa9b5fd41e8  add rsp, 0x30
00007aa9b5fd41ec  vmovaps xmm0, [rsp]
00007aa9b5fd41f1  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd41f7  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd41fd  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd4203  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd4209  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd420f  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd4215  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd421b  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd4224  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd422d  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd4236  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd423f  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd4248  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd4251  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd425a  add rsp, 0xF0
00007aa9b5fd4261  pop r11
00007aa9b5fd4263  pop r10
00007aa9b5fd4265  pop r9
00007aa9b5fd4267  pop r8
00007aa9b5fd4269  pop rsi
00007aa9b5fd426a  pop rdi
00007aa9b5fd426b  pop rdx
00007aa9b5fd426c  pop rcx
00007aa9b5fd426d  pop rax
00007aa9b5fd426e  add rsp, 0x08
00007aa9b5fd4272  jmp 0x00007AA9B5FD2962
00007aa9b5fd4277  sub rsp, 0x08
00007aa9b5fd427b  push rax
00007aa9b5fd427c  push rcx
00007aa9b5fd427d  push rdx
00007aa9b5fd427e  push rdi
00007aa9b5fd427f  push rsi
00007aa9b5fd4280  push r8
00007aa9b5fd4282  push r9
00007aa9b5fd4284  push r10
00007aa9b5fd4286  push r11
00007aa9b5fd4288  sub rsp, 0xF0
00007aa9b5fd428f  vmovaps [rsp], xmm0
00007aa9b5fd4294  vmovaps [rsp+0x10], xmm1
00007aa9b5fd429a  vmovaps [rsp+0x20], xmm2
00007aa9b5fd42a0  vmovaps [rsp+0x30], xmm3
00007aa9b5fd42a6  vmovaps [rsp+0x40], xmm4
00007aa9b5fd42ac  vmovaps [rsp+0x50], xmm5
00007aa9b5fd42b2  vmovaps [rsp+0x60], xmm6
00007aa9b5fd42b8  vmovaps [rsp+0x70], xmm7
00007aa9b5fd42be  vmovaps [rsp+0x80], xmm8
00007aa9b5fd42c7  vmovaps [rsp+0x90], xmm9
00007aa9b5fd42d0  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd42d9  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd42e2  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd42eb  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd42f4  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd42fd  sub rsp, 0x30
00007aa9b5fd4301  movaps [rsp], xmm14
00007aa9b5fd4306  movaps [rsp+0x10], xmm10
00007aa9b5fd430c  movaps [rsp+0x20], xmm15
00007aa9b5fd4312  lea rdi, [rsp]
00007aa9b5fd4316  mov esi, 0x00
00007aa9b5fd431b  mov rax, 0x63E0217C9530
00007aa9b5fd4325  call rax
00007aa9b5fd4327  movaps xmm14, [rsp]
00007aa9b5fd432c  add rsp, 0x30
00007aa9b5fd4330  vmovaps xmm0, [rsp]
00007aa9b5fd4335  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd433b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd4341  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd4347  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd434d  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd4353  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd4359  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd435f  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd4368  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd4371  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd437a  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd4383  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd438c  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd4395  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd439e  add rsp, 0xF0
00007aa9b5fd43a5  pop r11
00007aa9b5fd43a7  pop r10
00007aa9b5fd43a9  pop r9
00007aa9b5fd43ab  pop r8
00007aa9b5fd43ad  pop rsi
00007aa9b5fd43ae  pop rdi
00007aa9b5fd43af  pop rdx
00007aa9b5fd43b0  pop rcx
00007aa9b5fd43b1  pop rax
00007aa9b5fd43b2  add rsp, 0x08
00007aa9b5fd43b6  jmp 0x00007AA9B5FD298E
00007aa9b5fd43bb  call 0x00007AA9B5DFF430
00007aa9b5fd43c0  jmp 0x00007AA9B5FD2A1E
00007aa9b5fd43c5  call 0x00007AA9B5DFF430
00007aa9b5fd43ca  jmp 0x00007AA9B5FD2A31
00007aa9b5fd43cf  sub rsp, 0x08
00007aa9b5fd43d3  push rax
00007aa9b5fd43d4  push rcx
00007aa9b5fd43d5  push rdx
00007aa9b5fd43d6  push rdi
00007aa9b5fd43d7  push rsi
00007aa9b5fd43d8  push r8
00007aa9b5fd43da  push r9
00007aa9b5fd43dc  push r10
00007aa9b5fd43de  push r11
00007aa9b5fd43e0  sub rsp, 0xF0
00007aa9b5fd43e7  vmovaps [rsp], xmm0
00007aa9b5fd43ec  vmovaps [rsp+0x10], xmm2
00007aa9b5fd43f2  vmovaps [rsp+0x20], xmm3
00007aa9b5fd43f8  vmovaps [rsp+0x30], xmm4
00007aa9b5fd43fe  vmovaps [rsp+0x40], xmm5
00007aa9b5fd4404  vmovaps [rsp+0x50], xmm6
00007aa9b5fd440a  vmovaps [rsp+0x60], xmm7
00007aa9b5fd4410  vmovaps [rsp+0x70], xmm8
00007aa9b5fd4416  vmovaps [rsp+0x80], xmm9
00007aa9b5fd441f  vmovaps [rsp+0x90], xmm10
00007aa9b5fd4428  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd4431  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd443a  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd4443  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd444c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd4455  sub rsp, 0x30
00007aa9b5fd4459  movaps [rsp], xmm1
00007aa9b5fd445d  movaps [rsp+0x10], xmm13
00007aa9b5fd4463  movaps [rsp+0x20], xmm2
00007aa9b5fd4468  lea rdi, [rsp]
00007aa9b5fd446c  mov esi, 0x00
00007aa9b5fd4471  mov rax, 0x63E0217C9530
00007aa9b5fd447b  call rax
00007aa9b5fd447d  movaps xmm1, [rsp]
00007aa9b5fd4481  add rsp, 0x30
00007aa9b5fd4485  vmovaps xmm0, [rsp]
00007aa9b5fd448a  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd4490  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd4496  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd449c  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd44a2  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd44a8  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd44ae  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd44b4  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd44bd  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd44c6  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd44cf  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd44d8  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd44e1  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd44ea  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd44f3  add rsp, 0xF0
00007aa9b5fd44fa  pop r11
00007aa9b5fd44fc  pop r10
00007aa9b5fd44fe  pop r9
00007aa9b5fd4500  pop r8
00007aa9b5fd4502  pop rsi
00007aa9b5fd4503  pop rdi
00007aa9b5fd4504  pop rdx
00007aa9b5fd4505  pop rcx
00007aa9b5fd4506  pop rax
00007aa9b5fd4507  add rsp, 0x08
00007aa9b5fd450b  jmp 0x00007AA9B5FD2A5C
00007aa9b5fd4510  call 0x00007AA9B5E0E760
00007aa9b5fd4515  jmp 0x00007AA9B5FD2A69
00007aa9b5fd451a  sub rsp, 0x08
00007aa9b5fd451e  push rax
00007aa9b5fd451f  push rcx
00007aa9b5fd4520  push rdx
00007aa9b5fd4521  push rdi
00007aa9b5fd4522  push rsi
00007aa9b5fd4523  push r8
00007aa9b5fd4525  push r9
00007aa9b5fd4527  push r10
00007aa9b5fd4529  push r11
00007aa9b5fd452b  sub rsp, 0xF0
00007aa9b5fd4532  vmovaps [rsp], xmm0
00007aa9b5fd4537  vmovaps [rsp+0x10], xmm1
00007aa9b5fd453d  vmovaps [rsp+0x20], xmm2
00007aa9b5fd4543  vmovaps [rsp+0x30], xmm3
00007aa9b5fd4549  vmovaps [rsp+0x40], xmm4
00007aa9b5fd454f  vmovaps [rsp+0x50], xmm5
00007aa9b5fd4555  vmovaps [rsp+0x60], xmm6
00007aa9b5fd455b  vmovaps [rsp+0x70], xmm7
00007aa9b5fd4561  vmovaps [rsp+0x80], xmm8
00007aa9b5fd456a  vmovaps [rsp+0x90], xmm9
00007aa9b5fd4573  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd457c  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd4585  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd458e  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd4597  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd45a0  sub rsp, 0x30
00007aa9b5fd45a4  movaps [rsp], xmm13
00007aa9b5fd45a9  movaps [rsp+0x10], xmm2
00007aa9b5fd45ae  movaps [rsp+0x20], xmm1
00007aa9b5fd45b3  lea rdi, [rsp]
00007aa9b5fd45b7  mov esi, 0x00
00007aa9b5fd45bc  mov rax, 0x63E0217C9530
00007aa9b5fd45c6  call rax
00007aa9b5fd45c8  movaps xmm13, [rsp]
00007aa9b5fd45cd  add rsp, 0x30
00007aa9b5fd45d1  vmovaps xmm0, [rsp]
00007aa9b5fd45d6  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd45dc  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd45e2  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd45e8  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd45ee  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd45f4  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd45fa  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd4600  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd4609  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd4612  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd461b  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd4624  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd462d  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd4636  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd463f  add rsp, 0xF0
00007aa9b5fd4646  pop r11
00007aa9b5fd4648  pop r10
00007aa9b5fd464a  pop r9
00007aa9b5fd464c  pop r8
00007aa9b5fd464e  pop rsi
00007aa9b5fd464f  pop rdi
00007aa9b5fd4650  pop rdx
00007aa9b5fd4651  pop rcx
00007aa9b5fd4652  pop rax
00007aa9b5fd4653  add rsp, 0x08
00007aa9b5fd4657  jmp 0x00007AA9B5FD2AA8
00007aa9b5fd465c  sub rsp, 0x08
00007aa9b5fd4660  push rax
00007aa9b5fd4661  push rcx
00007aa9b5fd4662  push rdx
00007aa9b5fd4663  push rdi
00007aa9b5fd4664  push rsi
00007aa9b5fd4665  push r8
00007aa9b5fd4667  push r9
00007aa9b5fd4669  push r10
00007aa9b5fd466b  push r11
00007aa9b5fd466d  sub rsp, 0xF0
00007aa9b5fd4674  vmovaps [rsp], xmm0
00007aa9b5fd4679  vmovaps [rsp+0x10], xmm2
00007aa9b5fd467f  vmovaps [rsp+0x20], xmm3
00007aa9b5fd4685  vmovaps [rsp+0x30], xmm4
00007aa9b5fd468b  vmovaps [rsp+0x40], xmm5
00007aa9b5fd4691  vmovaps [rsp+0x50], xmm6
00007aa9b5fd4697  vmovaps [rsp+0x60], xmm7
00007aa9b5fd469d  vmovaps [rsp+0x70], xmm8
00007aa9b5fd46a3  vmovaps [rsp+0x80], xmm9
00007aa9b5fd46ac  vmovaps [rsp+0x90], xmm10
00007aa9b5fd46b5  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd46be  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd46c7  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd46d0  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd46d9  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd46e2  sub rsp, 0x30
00007aa9b5fd46e6  movaps [rsp], xmm1
00007aa9b5fd46ea  movaps [rsp+0x10], xmm14
00007aa9b5fd46f0  movaps [rsp+0x20], xmm15
00007aa9b5fd46f6  lea rdi, [rsp]
00007aa9b5fd46fa  mov esi, 0x00
00007aa9b5fd46ff  mov rax, 0x63E0217C9530
00007aa9b5fd4709  call rax
00007aa9b5fd470b  movaps xmm1, [rsp]
00007aa9b5fd470f  add rsp, 0x30
00007aa9b5fd4713  vmovaps xmm0, [rsp]
00007aa9b5fd4718  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd471e  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd4724  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd472a  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd4730  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd4736  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd473c  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd4742  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd474b  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd4754  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd475d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd4766  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd476f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd4778  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd4781  add rsp, 0xF0
00007aa9b5fd4788  pop r11
00007aa9b5fd478a  pop r10
00007aa9b5fd478c  pop r9
00007aa9b5fd478e  pop r8
00007aa9b5fd4790  pop rsi
00007aa9b5fd4791  pop rdi
00007aa9b5fd4792  pop rdx
00007aa9b5fd4793  pop rcx
00007aa9b5fd4794  pop rax
00007aa9b5fd4795  add rsp, 0x08
00007aa9b5fd4799  jmp 0x00007AA9B5FD2ACA
00007aa9b5fd479e  sub rsp, 0x08
00007aa9b5fd47a2  push rax
00007aa9b5fd47a3  push rcx
00007aa9b5fd47a4  push rdx
00007aa9b5fd47a5  push rdi
00007aa9b5fd47a6  push rsi
00007aa9b5fd47a7  push r8
00007aa9b5fd47a9  push r9
00007aa9b5fd47ab  push r10
00007aa9b5fd47ad  push r11
00007aa9b5fd47af  sub rsp, 0xF0
00007aa9b5fd47b6  vmovaps [rsp], xmm0
00007aa9b5fd47bb  vmovaps [rsp+0x10], xmm1
00007aa9b5fd47c1  vmovaps [rsp+0x20], xmm2
00007aa9b5fd47c7  vmovaps [rsp+0x30], xmm3
00007aa9b5fd47cd  vmovaps [rsp+0x40], xmm4
00007aa9b5fd47d3  vmovaps [rsp+0x50], xmm5
00007aa9b5fd47d9  vmovaps [rsp+0x60], xmm6
00007aa9b5fd47df  vmovaps [rsp+0x70], xmm7
00007aa9b5fd47e5  vmovaps [rsp+0x80], xmm8
00007aa9b5fd47ee  vmovaps [rsp+0x90], xmm9
00007aa9b5fd47f7  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd4800  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd4809  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd4812  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd481b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd4824  sub rsp, 0x30
00007aa9b5fd4828  movaps [rsp], xmm14
00007aa9b5fd482d  movaps [rsp+0x10], xmm2
00007aa9b5fd4832  movaps [rsp+0x20], xmm15
00007aa9b5fd4838  lea rdi, [rsp]
00007aa9b5fd483c  mov esi, 0x00
00007aa9b5fd4841  mov rax, 0x63E0217C9530
00007aa9b5fd484b  call rax
00007aa9b5fd484d  movaps xmm14, [rsp]
00007aa9b5fd4852  add rsp, 0x30
00007aa9b5fd4856  vmovaps xmm0, [rsp]
00007aa9b5fd485b  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd4861  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd4867  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd486d  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd4873  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd4879  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd487f  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd4885  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd488e  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd4897  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd48a0  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd48a9  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd48b2  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd48bb  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd48c4  add rsp, 0xF0
00007aa9b5fd48cb  pop r11
00007aa9b5fd48cd  pop r10
00007aa9b5fd48cf  pop r9
00007aa9b5fd48d1  pop r8
00007aa9b5fd48d3  pop rsi
00007aa9b5fd48d4  pop rdi
00007aa9b5fd48d5  pop rdx
00007aa9b5fd48d6  pop rcx
00007aa9b5fd48d7  pop rax
00007aa9b5fd48d8  add rsp, 0x08
00007aa9b5fd48dc  jmp 0x00007AA9B5FD2B05
00007aa9b5fd48e1  sub rsp, 0x08
00007aa9b5fd48e5  push rax
00007aa9b5fd48e6  push rcx
00007aa9b5fd48e7  push rdx
00007aa9b5fd48e8  push rdi
00007aa9b5fd48e9  push rsi
00007aa9b5fd48ea  push r8
00007aa9b5fd48ec  push r9
00007aa9b5fd48ee  push r10
00007aa9b5fd48f0  push r11
00007aa9b5fd48f2  sub rsp, 0xF0
00007aa9b5fd48f9  vmovaps [rsp], xmm0
00007aa9b5fd48fe  vmovaps [rsp+0x10], xmm1
00007aa9b5fd4904  vmovaps [rsp+0x20], xmm2
00007aa9b5fd490a  vmovaps [rsp+0x30], xmm3
00007aa9b5fd4910  vmovaps [rsp+0x40], xmm4
00007aa9b5fd4916  vmovaps [rsp+0x50], xmm5
00007aa9b5fd491c  vmovaps [rsp+0x60], xmm6
00007aa9b5fd4922  vmovaps [rsp+0x70], xmm7
00007aa9b5fd4928  vmovaps [rsp+0x80], xmm8
00007aa9b5fd4931  vmovaps [rsp+0x90], xmm9
00007aa9b5fd493a  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd4943  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd494c  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd4955  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd495e  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd4967  sub rsp, 0x30
00007aa9b5fd496b  movaps [rsp], xmm15
00007aa9b5fd4970  movaps [rsp+0x10], xmm2
00007aa9b5fd4975  movaps [rsp+0x20], xmm1
00007aa9b5fd497a  lea rdi, [rsp]
00007aa9b5fd497e  mov esi, 0x00
00007aa9b5fd4983  mov rax, 0x63E0217C9530
00007aa9b5fd498d  call rax
00007aa9b5fd498f  movaps xmm15, [rsp]
00007aa9b5fd4994  add rsp, 0x30
00007aa9b5fd4998  vmovaps xmm0, [rsp]
00007aa9b5fd499d  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd49a3  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd49a9  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd49af  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd49b5  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd49bb  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd49c1  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd49c7  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd49d0  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd49d9  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd49e2  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd49eb  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd49f4  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd49fd  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd4a06  add rsp, 0xF0
00007aa9b5fd4a0d  pop r11
00007aa9b5fd4a0f  pop r10
00007aa9b5fd4a11  pop r9
00007aa9b5fd4a13  pop r8
00007aa9b5fd4a15  pop rsi
00007aa9b5fd4a16  pop rdi
00007aa9b5fd4a17  pop rdx
00007aa9b5fd4a18  pop rcx
00007aa9b5fd4a19  pop rax
00007aa9b5fd4a1a  add rsp, 0x08
00007aa9b5fd4a1e  jmp 0x00007AA9B5FD2B41
00007aa9b5fd4a23  call 0x00007AA9B5DFF430
00007aa9b5fd4a28  jmp 0x00007AA9B5FD2B4E
00007aa9b5fd4a2d  sub rsp, 0x08
00007aa9b5fd4a31  push rax
00007aa9b5fd4a32  push rcx
00007aa9b5fd4a33  push rdx
00007aa9b5fd4a34  push rdi
00007aa9b5fd4a35  push rsi
00007aa9b5fd4a36  push r8
00007aa9b5fd4a38  push r9
00007aa9b5fd4a3a  push r10
00007aa9b5fd4a3c  push r11
00007aa9b5fd4a3e  sub rsp, 0xF0
00007aa9b5fd4a45  vmovaps [rsp], xmm0
00007aa9b5fd4a4a  vmovaps [rsp+0x10], xmm1
00007aa9b5fd4a50  vmovaps [rsp+0x20], xmm3
00007aa9b5fd4a56  vmovaps [rsp+0x30], xmm4
00007aa9b5fd4a5c  vmovaps [rsp+0x40], xmm5
00007aa9b5fd4a62  vmovaps [rsp+0x50], xmm6
00007aa9b5fd4a68  vmovaps [rsp+0x60], xmm7
00007aa9b5fd4a6e  vmovaps [rsp+0x70], xmm8
00007aa9b5fd4a74  vmovaps [rsp+0x80], xmm9
00007aa9b5fd4a7d  vmovaps [rsp+0x90], xmm10
00007aa9b5fd4a86  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd4a8f  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd4a98  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd4aa1  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd4aaa  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd4ab3  sub rsp, 0x30
00007aa9b5fd4ab7  movaps [rsp], xmm2
00007aa9b5fd4abb  movaps [rsp+0x10], xmm1
00007aa9b5fd4ac0  movaps [rsp+0x20], xmm14
00007aa9b5fd4ac6  lea rdi, [rsp]
00007aa9b5fd4aca  mov esi, 0x00
00007aa9b5fd4acf  mov rax, 0x63E0217C9530
00007aa9b5fd4ad9  call rax
00007aa9b5fd4adb  movaps xmm2, [rsp]
00007aa9b5fd4adf  add rsp, 0x30
00007aa9b5fd4ae3  vmovaps xmm0, [rsp]
00007aa9b5fd4ae8  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd4aee  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd4af4  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd4afa  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd4b00  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd4b06  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd4b0c  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd4b12  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd4b1b  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd4b24  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd4b2d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd4b36  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd4b3f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd4b48  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd4b51  add rsp, 0xF0
00007aa9b5fd4b58  pop r11
00007aa9b5fd4b5a  pop r10
00007aa9b5fd4b5c  pop r9
00007aa9b5fd4b5e  pop r8
00007aa9b5fd4b60  pop rsi
00007aa9b5fd4b61  pop rdi
00007aa9b5fd4b62  pop rdx
00007aa9b5fd4b63  pop rcx
00007aa9b5fd4b64  pop rax
00007aa9b5fd4b65  add rsp, 0x08
00007aa9b5fd4b69  jmp 0x00007AA9B5FD2B8B
00007aa9b5fd4b6e  sub rsp, 0x08
00007aa9b5fd4b72  push rax
00007aa9b5fd4b73  push rcx
00007aa9b5fd4b74  push rdx
00007aa9b5fd4b75  push rdi
00007aa9b5fd4b76  push rsi
00007aa9b5fd4b77  push r8
00007aa9b5fd4b79  push r9
00007aa9b5fd4b7b  push r10
00007aa9b5fd4b7d  push r11
00007aa9b5fd4b7f  sub rsp, 0xF0
00007aa9b5fd4b86  vmovaps [rsp], xmm0
00007aa9b5fd4b8b  vmovaps [rsp+0x10], xmm1
00007aa9b5fd4b91  vmovaps [rsp+0x20], xmm2
00007aa9b5fd4b97  vmovaps [rsp+0x30], xmm3
00007aa9b5fd4b9d  vmovaps [rsp+0x40], xmm4
00007aa9b5fd4ba3  vmovaps [rsp+0x50], xmm5
00007aa9b5fd4ba9  vmovaps [rsp+0x60], xmm6
00007aa9b5fd4baf  vmovaps [rsp+0x70], xmm7
00007aa9b5fd4bb5  vmovaps [rsp+0x80], xmm8
00007aa9b5fd4bbe  vmovaps [rsp+0x90], xmm9
00007aa9b5fd4bc7  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd4bd0  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd4bd9  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd4be2  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd4beb  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd4bf4  sub rsp, 0x30
00007aa9b5fd4bf8  movaps [rsp], xmm15
00007aa9b5fd4bfd  movaps [rsp+0x10], xmm14
00007aa9b5fd4c03  movaps [rsp+0x20], xmm1
00007aa9b5fd4c08  lea rdi, [rsp]
00007aa9b5fd4c0c  mov esi, 0x00
00007aa9b5fd4c11  mov rax, 0x63E0217C9530
00007aa9b5fd4c1b  call rax
00007aa9b5fd4c1d  movaps xmm15, [rsp]
00007aa9b5fd4c22  add rsp, 0x30
00007aa9b5fd4c26  vmovaps xmm0, [rsp]
00007aa9b5fd4c2b  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd4c31  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd4c37  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd4c3d  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd4c43  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd4c49  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd4c4f  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd4c55  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd4c5e  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd4c67  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd4c70  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd4c79  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd4c82  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd4c8b  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd4c94  add rsp, 0xF0
00007aa9b5fd4c9b  pop r11
00007aa9b5fd4c9d  pop r10
00007aa9b5fd4c9f  pop r9
00007aa9b5fd4ca1  pop r8
00007aa9b5fd4ca3  pop rsi
00007aa9b5fd4ca4  pop rdi
00007aa9b5fd4ca5  pop rdx
00007aa9b5fd4ca6  pop rcx
00007aa9b5fd4ca7  pop rax
00007aa9b5fd4ca8  add rsp, 0x08
00007aa9b5fd4cac  jmp 0x00007AA9B5FD2C05
00007aa9b5fd4cb1  call 0x00007AA9B5DFF430
00007aa9b5fd4cb6  jmp 0x00007AA9B5FD2C12
00007aa9b5fd4cbb  sub rsp, 0x08
00007aa9b5fd4cbf  push rax
00007aa9b5fd4cc0  push rcx
00007aa9b5fd4cc1  push rdx
00007aa9b5fd4cc2  push rdi
00007aa9b5fd4cc3  push rsi
00007aa9b5fd4cc4  push r8
00007aa9b5fd4cc6  push r9
00007aa9b5fd4cc8  push r10
00007aa9b5fd4cca  push r11
00007aa9b5fd4ccc  sub rsp, 0xF0
00007aa9b5fd4cd3  vmovaps [rsp], xmm0
00007aa9b5fd4cd8  vmovaps [rsp+0x10], xmm1
00007aa9b5fd4cde  vmovaps [rsp+0x20], xmm2
00007aa9b5fd4ce4  vmovaps [rsp+0x30], xmm3
00007aa9b5fd4cea  vmovaps [rsp+0x40], xmm4
00007aa9b5fd4cf0  vmovaps [rsp+0x50], xmm5
00007aa9b5fd4cf6  vmovaps [rsp+0x60], xmm6
00007aa9b5fd4cfc  vmovaps [rsp+0x70], xmm7
00007aa9b5fd4d02  vmovaps [rsp+0x80], xmm8
00007aa9b5fd4d0b  vmovaps [rsp+0x90], xmm9
00007aa9b5fd4d14  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd4d1d  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd4d26  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd4d2f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd4d38  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd4d41  sub rsp, 0x30
00007aa9b5fd4d45  movaps [rsp], xmm13
00007aa9b5fd4d4a  movaps [rsp+0x10], xmm1
00007aa9b5fd4d4f  movaps [rsp+0x20], xmm15
00007aa9b5fd4d55  lea rdi, [rsp]
00007aa9b5fd4d59  mov esi, 0x00
00007aa9b5fd4d5e  mov rax, 0x63E0217C9530
00007aa9b5fd4d68  call rax
00007aa9b5fd4d6a  movaps xmm13, [rsp]
00007aa9b5fd4d6f  add rsp, 0x30
00007aa9b5fd4d73  vmovaps xmm0, [rsp]
00007aa9b5fd4d78  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd4d7e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd4d84  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd4d8a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd4d90  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd4d96  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd4d9c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd4da2  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd4dab  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd4db4  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd4dbd  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd4dc6  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd4dcf  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd4dd8  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd4de1  add rsp, 0xF0
00007aa9b5fd4de8  pop r11
00007aa9b5fd4dea  pop r10
00007aa9b5fd4dec  pop r9
00007aa9b5fd4dee  pop r8
00007aa9b5fd4df0  pop rsi
00007aa9b5fd4df1  pop rdi
00007aa9b5fd4df2  pop rdx
00007aa9b5fd4df3  pop rcx
00007aa9b5fd4df4  pop rax
00007aa9b5fd4df5  add rsp, 0x08
00007aa9b5fd4df9  jmp 0x00007AA9B5FD2CD6
00007aa9b5fd4dfe  sub rsp, 0x08
00007aa9b5fd4e02  push rax
00007aa9b5fd4e03  push rcx
00007aa9b5fd4e04  push rdx
00007aa9b5fd4e05  push rdi
00007aa9b5fd4e06  push rsi
00007aa9b5fd4e07  push r8
00007aa9b5fd4e09  push r9
00007aa9b5fd4e0b  push r10
00007aa9b5fd4e0d  push r11
00007aa9b5fd4e0f  sub rsp, 0xF0
00007aa9b5fd4e16  vmovaps [rsp], xmm0
00007aa9b5fd4e1b  vmovaps [rsp+0x10], xmm1
00007aa9b5fd4e21  vmovaps [rsp+0x20], xmm2
00007aa9b5fd4e27  vmovaps [rsp+0x30], xmm3
00007aa9b5fd4e2d  vmovaps [rsp+0x40], xmm4
00007aa9b5fd4e33  vmovaps [rsp+0x50], xmm5
00007aa9b5fd4e39  vmovaps [rsp+0x60], xmm6
00007aa9b5fd4e3f  vmovaps [rsp+0x70], xmm7
00007aa9b5fd4e45  vmovaps [rsp+0x80], xmm8
00007aa9b5fd4e4e  vmovaps [rsp+0x90], xmm9
00007aa9b5fd4e57  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd4e60  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd4e69  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd4e72  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd4e7b  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd4e84  sub rsp, 0x30
00007aa9b5fd4e88  movaps [rsp], xmm15
00007aa9b5fd4e8d  movaps [rsp+0x10], xmm14
00007aa9b5fd4e93  movaps [rsp+0x20], xmm1
00007aa9b5fd4e98  lea rdi, [rsp]
00007aa9b5fd4e9c  mov esi, 0x00
00007aa9b5fd4ea1  mov rax, 0x63E0217C9530
00007aa9b5fd4eab  call rax
00007aa9b5fd4ead  movaps xmm15, [rsp]
00007aa9b5fd4eb2  add rsp, 0x30
00007aa9b5fd4eb6  vmovaps xmm0, [rsp]
00007aa9b5fd4ebb  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd4ec1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd4ec7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd4ecd  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd4ed3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd4ed9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd4edf  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd4ee5  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd4eee  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd4ef7  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd4f00  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd4f09  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd4f12  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd4f1b  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd4f24  add rsp, 0xF0
00007aa9b5fd4f2b  pop r11
00007aa9b5fd4f2d  pop r10
00007aa9b5fd4f2f  pop r9
00007aa9b5fd4f31  pop r8
00007aa9b5fd4f33  pop rsi
00007aa9b5fd4f34  pop rdi
00007aa9b5fd4f35  pop rdx
00007aa9b5fd4f36  pop rcx
00007aa9b5fd4f37  pop rax
00007aa9b5fd4f38  add rsp, 0x08
00007aa9b5fd4f3c  jmp 0x00007AA9B5FD2D12
00007aa9b5fd4f41  call 0x00007AA9B5DFF430
00007aa9b5fd4f46  jmp 0x00007AA9B5FD2D1F
00007aa9b5fd4f4b  sub rsp, 0x08
00007aa9b5fd4f4f  push rax
00007aa9b5fd4f50  push rcx
00007aa9b5fd4f51  push rdx
00007aa9b5fd4f52  push rdi
00007aa9b5fd4f53  push rsi
00007aa9b5fd4f54  push r8
00007aa9b5fd4f56  push r9
00007aa9b5fd4f58  push r10
00007aa9b5fd4f5a  push r11
00007aa9b5fd4f5c  sub rsp, 0xF0
00007aa9b5fd4f63  vmovaps [rsp], xmm0
00007aa9b5fd4f68  vmovaps [rsp+0x10], xmm1
00007aa9b5fd4f6e  vmovaps [rsp+0x20], xmm2
00007aa9b5fd4f74  vmovaps [rsp+0x30], xmm3
00007aa9b5fd4f7a  vmovaps [rsp+0x40], xmm4
00007aa9b5fd4f80  vmovaps [rsp+0x50], xmm5
00007aa9b5fd4f86  vmovaps [rsp+0x60], xmm6
00007aa9b5fd4f8c  vmovaps [rsp+0x70], xmm7
00007aa9b5fd4f92  vmovaps [rsp+0x80], xmm8
00007aa9b5fd4f9b  vmovaps [rsp+0x90], xmm9
00007aa9b5fd4fa4  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd4fad  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd4fb6  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd4fbf  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd4fc8  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd4fd1  sub rsp, 0x30
00007aa9b5fd4fd5  movaps [rsp], xmm14
00007aa9b5fd4fda  movaps [rsp+0x10], xmm13
00007aa9b5fd4fe0  movaps [rsp+0x20], xmm2
00007aa9b5fd4fe5  lea rdi, [rsp]
00007aa9b5fd4fe9  mov esi, 0x00
00007aa9b5fd4fee  mov rax, 0x63E0217C9530
00007aa9b5fd4ff8  call rax
00007aa9b5fd4ffa  movaps xmm14, [rsp]
00007aa9b5fd4fff  add rsp, 0x30
00007aa9b5fd5003  vmovaps xmm0, [rsp]
00007aa9b5fd5008  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd500e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd5014  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd501a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd5020  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd5026  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd502c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd5032  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd503b  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd5044  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd504d  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd5056  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd505f  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd5068  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd5071  add rsp, 0xF0
00007aa9b5fd5078  pop r11
00007aa9b5fd507a  pop r10
00007aa9b5fd507c  pop r9
00007aa9b5fd507e  pop r8
00007aa9b5fd5080  pop rsi
00007aa9b5fd5081  pop rdi
00007aa9b5fd5082  pop rdx
00007aa9b5fd5083  pop rcx
00007aa9b5fd5084  pop rax
00007aa9b5fd5085  add rsp, 0x08
00007aa9b5fd5089  jmp 0x00007AA9B5FD2D4B
00007aa9b5fd508e  sub rsp, 0x08
00007aa9b5fd5092  push rax
00007aa9b5fd5093  push rcx
00007aa9b5fd5094  push rdx
00007aa9b5fd5095  push rdi
00007aa9b5fd5096  push rsi
00007aa9b5fd5097  push r8
00007aa9b5fd5099  push r9
00007aa9b5fd509b  push r10
00007aa9b5fd509d  push r11
00007aa9b5fd509f  sub rsp, 0xF0
00007aa9b5fd50a6  vmovaps [rsp], xmm0
00007aa9b5fd50ab  vmovaps [rsp+0x10], xmm2
00007aa9b5fd50b1  vmovaps [rsp+0x20], xmm3
00007aa9b5fd50b7  vmovaps [rsp+0x30], xmm4
00007aa9b5fd50bd  vmovaps [rsp+0x40], xmm5
00007aa9b5fd50c3  vmovaps [rsp+0x50], xmm6
00007aa9b5fd50c9  vmovaps [rsp+0x60], xmm7
00007aa9b5fd50cf  vmovaps [rsp+0x70], xmm8
00007aa9b5fd50d5  vmovaps [rsp+0x80], xmm9
00007aa9b5fd50de  vmovaps [rsp+0x90], xmm10
00007aa9b5fd50e7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd50f0  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd50f9  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd5102  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd510b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd5114  sub rsp, 0x30
00007aa9b5fd5118  movaps [rsp], xmm1
00007aa9b5fd511c  movaps [rsp+0x10], xmm13
00007aa9b5fd5122  movaps [rsp+0x20], xmm2
00007aa9b5fd5127  lea rdi, [rsp]
00007aa9b5fd512b  mov esi, 0x00
00007aa9b5fd5130  mov rax, 0x63E0217C9530
00007aa9b5fd513a  call rax
00007aa9b5fd513c  movaps xmm1, [rsp]
00007aa9b5fd5140  add rsp, 0x30
00007aa9b5fd5144  vmovaps xmm0, [rsp]
00007aa9b5fd5149  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd514f  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd5155  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd515b  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd5161  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd5167  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd516d  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd5173  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd517c  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd5185  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd518e  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd5197  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd51a0  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd51a9  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd51b2  add rsp, 0xF0
00007aa9b5fd51b9  pop r11
00007aa9b5fd51bb  pop r10
00007aa9b5fd51bd  pop r9
00007aa9b5fd51bf  pop r8
00007aa9b5fd51c1  pop rsi
00007aa9b5fd51c2  pop rdi
00007aa9b5fd51c3  pop rdx
00007aa9b5fd51c4  pop rcx
00007aa9b5fd51c5  pop rax
00007aa9b5fd51c6  add rsp, 0x08
00007aa9b5fd51ca  jmp 0x00007AA9B5FD2D79
00007aa9b5fd51cf  sub rsp, 0x08
00007aa9b5fd51d3  push rax
00007aa9b5fd51d4  push rcx
00007aa9b5fd51d5  push rdx
00007aa9b5fd51d6  push rdi
00007aa9b5fd51d7  push rsi
00007aa9b5fd51d8  push r8
00007aa9b5fd51da  push r9
00007aa9b5fd51dc  push r10
00007aa9b5fd51de  push r11
00007aa9b5fd51e0  sub rsp, 0xF0
00007aa9b5fd51e7  vmovaps [rsp], xmm0
00007aa9b5fd51ec  vmovaps [rsp+0x10], xmm1
00007aa9b5fd51f2  vmovaps [rsp+0x20], xmm3
00007aa9b5fd51f8  vmovaps [rsp+0x30], xmm4
00007aa9b5fd51fe  vmovaps [rsp+0x40], xmm5
00007aa9b5fd5204  vmovaps [rsp+0x50], xmm6
00007aa9b5fd520a  vmovaps [rsp+0x60], xmm7
00007aa9b5fd5210  vmovaps [rsp+0x70], xmm8
00007aa9b5fd5216  vmovaps [rsp+0x80], xmm9
00007aa9b5fd521f  vmovaps [rsp+0x90], xmm10
00007aa9b5fd5228  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd5231  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd523a  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd5243  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd524c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd5255  sub rsp, 0x30
00007aa9b5fd5259  movaps [rsp], xmm2
00007aa9b5fd525d  movaps [rsp+0x10], xmm1
00007aa9b5fd5262  movaps [rsp+0x20], xmm13
00007aa9b5fd5268  lea rdi, [rsp]
00007aa9b5fd526c  mov esi, 0x00
00007aa9b5fd5271  mov rax, 0x63E0217C9530
00007aa9b5fd527b  call rax
00007aa9b5fd527d  movaps xmm2, [rsp]
00007aa9b5fd5281  add rsp, 0x30
00007aa9b5fd5285  vmovaps xmm0, [rsp]
00007aa9b5fd528a  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd5290  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd5296  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd529c  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd52a2  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd52a8  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd52ae  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd52b4  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd52bd  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd52c6  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd52cf  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd52d8  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd52e1  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd52ea  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd52f3  add rsp, 0xF0
00007aa9b5fd52fa  pop r11
00007aa9b5fd52fc  pop r10
00007aa9b5fd52fe  pop r9
00007aa9b5fd5300  pop r8
00007aa9b5fd5302  pop rsi
00007aa9b5fd5303  pop rdi
00007aa9b5fd5304  pop rdx
00007aa9b5fd5305  pop rcx
00007aa9b5fd5306  pop rax
00007aa9b5fd5307  add rsp, 0x08
00007aa9b5fd530b  jmp 0x00007AA9B5FD2DD2
00007aa9b5fd5310  call 0x00007AA9B5DFF430
00007aa9b5fd5315  jmp 0x00007AA9B5FD2DDF
00007aa9b5fd531a  sub rsp, 0x08
00007aa9b5fd531e  push rax
00007aa9b5fd531f  push rcx
00007aa9b5fd5320  push rdx
00007aa9b5fd5321  push rdi
00007aa9b5fd5322  push rsi
00007aa9b5fd5323  push r8
00007aa9b5fd5325  push r9
00007aa9b5fd5327  push r10
00007aa9b5fd5329  push r11
00007aa9b5fd532b  sub rsp, 0xF0
00007aa9b5fd5332  vmovaps [rsp], xmm0
00007aa9b5fd5337  vmovaps [rsp+0x10], xmm1
00007aa9b5fd533d  vmovaps [rsp+0x20], xmm2
00007aa9b5fd5343  vmovaps [rsp+0x30], xmm3
00007aa9b5fd5349  vmovaps [rsp+0x40], xmm4
00007aa9b5fd534f  vmovaps [rsp+0x50], xmm5
00007aa9b5fd5355  vmovaps [rsp+0x60], xmm6
00007aa9b5fd535b  vmovaps [rsp+0x70], xmm7
00007aa9b5fd5361  vmovaps [rsp+0x80], xmm8
00007aa9b5fd536a  vmovaps [rsp+0x90], xmm9
00007aa9b5fd5373  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd537c  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd5385  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd538e  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd5397  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd53a0  sub rsp, 0x30
00007aa9b5fd53a4  movaps [rsp], xmm15
00007aa9b5fd53a9  movaps [rsp+0x10], xmm13
00007aa9b5fd53af  movaps [rsp+0x20], xmm1
00007aa9b5fd53b4  lea rdi, [rsp]
00007aa9b5fd53b8  mov esi, 0x00
00007aa9b5fd53bd  mov rax, 0x63E0217C9530
00007aa9b5fd53c7  call rax
00007aa9b5fd53c9  movaps xmm15, [rsp]
00007aa9b5fd53ce  add rsp, 0x30
00007aa9b5fd53d2  vmovaps xmm0, [rsp]
00007aa9b5fd53d7  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd53dd  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd53e3  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd53e9  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd53ef  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd53f5  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd53fb  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd5401  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd540a  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd5413  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd541c  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd5425  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd542e  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd5437  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd5440  add rsp, 0xF0
00007aa9b5fd5447  pop r11
00007aa9b5fd5449  pop r10
00007aa9b5fd544b  pop r9
00007aa9b5fd544d  pop r8
00007aa9b5fd544f  pop rsi
00007aa9b5fd5450  pop rdi
00007aa9b5fd5451  pop rdx
00007aa9b5fd5452  pop rcx
00007aa9b5fd5453  pop rax
00007aa9b5fd5454  add rsp, 0x08
00007aa9b5fd5458  jmp 0x00007AA9B5FD2E1E
00007aa9b5fd545d  sub rsp, 0x08
00007aa9b5fd5461  push rax
00007aa9b5fd5462  push rcx
00007aa9b5fd5463  push rdx
00007aa9b5fd5464  push rdi
00007aa9b5fd5465  push rsi
00007aa9b5fd5466  push r8
00007aa9b5fd5468  push r9
00007aa9b5fd546a  push r10
00007aa9b5fd546c  push r11
00007aa9b5fd546e  sub rsp, 0xF0
00007aa9b5fd5475  vmovaps [rsp], xmm0
00007aa9b5fd547a  vmovaps [rsp+0x10], xmm1
00007aa9b5fd5480  vmovaps [rsp+0x20], xmm2
00007aa9b5fd5486  vmovaps [rsp+0x30], xmm3
00007aa9b5fd548c  vmovaps [rsp+0x40], xmm4
00007aa9b5fd5492  vmovaps [rsp+0x50], xmm5
00007aa9b5fd5498  vmovaps [rsp+0x60], xmm6
00007aa9b5fd549e  vmovaps [rsp+0x70], xmm7
00007aa9b5fd54a4  vmovaps [rsp+0x80], xmm8
00007aa9b5fd54ad  vmovaps [rsp+0x90], xmm9
00007aa9b5fd54b6  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd54bf  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd54c8  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd54d1  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd54da  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd54e3  sub rsp, 0x30
00007aa9b5fd54e7  movaps [rsp], xmm14
00007aa9b5fd54ec  movaps [rsp+0x10], xmm11
00007aa9b5fd54f2  movaps [rsp+0x20], xmm1
00007aa9b5fd54f7  lea rdi, [rsp]
00007aa9b5fd54fb  mov esi, 0x00
00007aa9b5fd5500  mov rax, 0x63E0217C9530
00007aa9b5fd550a  call rax
00007aa9b5fd550c  movaps xmm14, [rsp]
00007aa9b5fd5511  add rsp, 0x30
00007aa9b5fd5515  vmovaps xmm0, [rsp]
00007aa9b5fd551a  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd5520  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd5526  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd552c  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd5532  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd5538  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd553e  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd5544  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd554d  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd5556  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd555f  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd5568  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd5571  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd557a  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd5583  add rsp, 0xF0
00007aa9b5fd558a  pop r11
00007aa9b5fd558c  pop r10
00007aa9b5fd558e  pop r9
00007aa9b5fd5590  pop r8
00007aa9b5fd5592  pop rsi
00007aa9b5fd5593  pop rdi
00007aa9b5fd5594  pop rdx
00007aa9b5fd5595  pop rcx
00007aa9b5fd5596  pop rax
00007aa9b5fd5597  add rsp, 0x08
00007aa9b5fd559b  jmp 0x00007AA9B5FD2E48
00007aa9b5fd55a0  sub rsp, 0x08
00007aa9b5fd55a4  push rax
00007aa9b5fd55a5  push rcx
00007aa9b5fd55a6  push rdx
00007aa9b5fd55a7  push rdi
00007aa9b5fd55a8  push rsi
00007aa9b5fd55a9  push r8
00007aa9b5fd55ab  push r9
00007aa9b5fd55ad  push r10
00007aa9b5fd55af  push r11
00007aa9b5fd55b1  sub rsp, 0xF0
00007aa9b5fd55b8  vmovaps [rsp], xmm0
00007aa9b5fd55bd  vmovaps [rsp+0x10], xmm1
00007aa9b5fd55c3  vmovaps [rsp+0x20], xmm2
00007aa9b5fd55c9  vmovaps [rsp+0x30], xmm3
00007aa9b5fd55cf  vmovaps [rsp+0x40], xmm4
00007aa9b5fd55d5  vmovaps [rsp+0x50], xmm5
00007aa9b5fd55db  vmovaps [rsp+0x60], xmm6
00007aa9b5fd55e1  vmovaps [rsp+0x70], xmm7
00007aa9b5fd55e7  vmovaps [rsp+0x80], xmm8
00007aa9b5fd55f0  vmovaps [rsp+0x90], xmm9
00007aa9b5fd55f9  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd5602  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd560b  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd5614  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd561d  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd5626  sub rsp, 0x30
00007aa9b5fd562a  movaps [rsp], xmm13
00007aa9b5fd562f  movaps [rsp+0x10], xmm11
00007aa9b5fd5635  movaps [rsp+0x20], xmm1
00007aa9b5fd563a  lea rdi, [rsp]
00007aa9b5fd563e  mov esi, 0x00
00007aa9b5fd5643  mov rax, 0x63E0217C9530
00007aa9b5fd564d  call rax
00007aa9b5fd564f  movaps xmm13, [rsp]
00007aa9b5fd5654  add rsp, 0x30
00007aa9b5fd5658  vmovaps xmm0, [rsp]
00007aa9b5fd565d  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd5663  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd5669  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd566f  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd5675  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd567b  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd5681  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd5687  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd5690  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd5699  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd56a2  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd56ab  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd56b4  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd56bd  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd56c6  add rsp, 0xF0
00007aa9b5fd56cd  pop r11
00007aa9b5fd56cf  pop r10
00007aa9b5fd56d1  pop r9
00007aa9b5fd56d3  pop r8
00007aa9b5fd56d5  pop rsi
00007aa9b5fd56d6  pop rdi
00007aa9b5fd56d7  pop rdx
00007aa9b5fd56d8  pop rcx
00007aa9b5fd56d9  pop rax
00007aa9b5fd56da  add rsp, 0x08
00007aa9b5fd56de  jmp 0x00007AA9B5FD2E9D
00007aa9b5fd56e3  call 0x00007AA9B5DFF430
00007aa9b5fd56e8  jmp 0x00007AA9B5FD2EAA
00007aa9b5fd56ed  sub rsp, 0x08
00007aa9b5fd56f1  push rax
00007aa9b5fd56f2  push rcx
00007aa9b5fd56f3  push rdx
00007aa9b5fd56f4  push rdi
00007aa9b5fd56f5  push rsi
00007aa9b5fd56f6  push r8
00007aa9b5fd56f8  push r9
00007aa9b5fd56fa  push r10
00007aa9b5fd56fc  push r11
00007aa9b5fd56fe  sub rsp, 0xF0
00007aa9b5fd5705  vmovaps [rsp], xmm0
00007aa9b5fd570a  vmovaps [rsp+0x10], xmm1
00007aa9b5fd5710  vmovaps [rsp+0x20], xmm2
00007aa9b5fd5716  vmovaps [rsp+0x30], xmm3
00007aa9b5fd571c  vmovaps [rsp+0x40], xmm4
00007aa9b5fd5722  vmovaps [rsp+0x50], xmm5
00007aa9b5fd5728  vmovaps [rsp+0x60], xmm6
00007aa9b5fd572e  vmovaps [rsp+0x70], xmm7
00007aa9b5fd5734  vmovaps [rsp+0x80], xmm8
00007aa9b5fd573d  vmovaps [rsp+0x90], xmm9
00007aa9b5fd5746  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd574f  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd5758  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd5761  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd576a  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd5773  sub rsp, 0x30
00007aa9b5fd5777  movaps [rsp], xmm15
00007aa9b5fd577c  movaps [rsp+0x10], xmm11
00007aa9b5fd5782  movaps [rsp+0x20], xmm1
00007aa9b5fd5787  lea rdi, [rsp]
00007aa9b5fd578b  mov esi, 0x00
00007aa9b5fd5790  mov rax, 0x63E0217C9530
00007aa9b5fd579a  call rax
00007aa9b5fd579c  movaps xmm15, [rsp]
00007aa9b5fd57a1  add rsp, 0x30
00007aa9b5fd57a5  vmovaps xmm0, [rsp]
00007aa9b5fd57aa  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd57b0  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd57b6  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd57bc  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd57c2  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd57c8  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd57ce  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd57d4  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd57dd  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd57e6  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd57ef  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd57f8  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd5801  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd580a  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd5813  add rsp, 0xF0
00007aa9b5fd581a  pop r11
00007aa9b5fd581c  pop r10
00007aa9b5fd581e  pop r9
00007aa9b5fd5820  pop r8
00007aa9b5fd5822  pop rsi
00007aa9b5fd5823  pop rdi
00007aa9b5fd5824  pop rdx
00007aa9b5fd5825  pop rcx
00007aa9b5fd5826  pop rax
00007aa9b5fd5827  add rsp, 0x08
00007aa9b5fd582b  jmp 0x00007AA9B5FD2EE3
00007aa9b5fd5830  sub rsp, 0x08
00007aa9b5fd5834  push rax
00007aa9b5fd5835  push rcx
00007aa9b5fd5836  push rdx
00007aa9b5fd5837  push rdi
00007aa9b5fd5838  push rsi
00007aa9b5fd5839  push r8
00007aa9b5fd583b  push r9
00007aa9b5fd583d  push r10
00007aa9b5fd583f  push r11
00007aa9b5fd5841  sub rsp, 0xF0
00007aa9b5fd5848  vmovaps [rsp], xmm0
00007aa9b5fd584d  vmovaps [rsp+0x10], xmm1
00007aa9b5fd5853  vmovaps [rsp+0x20], xmm2
00007aa9b5fd5859  vmovaps [rsp+0x30], xmm3
00007aa9b5fd585f  vmovaps [rsp+0x40], xmm4
00007aa9b5fd5865  vmovaps [rsp+0x50], xmm5
00007aa9b5fd586b  vmovaps [rsp+0x60], xmm6
00007aa9b5fd5871  vmovaps [rsp+0x70], xmm7
00007aa9b5fd5877  vmovaps [rsp+0x80], xmm8
00007aa9b5fd5880  vmovaps [rsp+0x90], xmm9
00007aa9b5fd5889  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd5892  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd589b  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd58a4  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd58ad  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd58b6  sub rsp, 0x30
00007aa9b5fd58ba  movaps [rsp], xmm11
00007aa9b5fd58bf  movaps [rsp+0x10], xmm6
00007aa9b5fd58c4  movaps [rsp+0x20], xmm14
00007aa9b5fd58ca  lea rdi, [rsp]
00007aa9b5fd58ce  mov esi, 0x00
00007aa9b5fd58d3  mov rax, 0x63E0217C9530
00007aa9b5fd58dd  call rax
00007aa9b5fd58df  movaps xmm11, [rsp]
00007aa9b5fd58e4  add rsp, 0x30
00007aa9b5fd58e8  vmovaps xmm0, [rsp]
00007aa9b5fd58ed  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd58f3  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd58f9  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd58ff  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd5905  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd590b  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd5911  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd5917  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd5920  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd5929  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd5932  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd593b  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd5944  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd594d  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd5956  add rsp, 0xF0
00007aa9b5fd595d  pop r11
00007aa9b5fd595f  pop r10
00007aa9b5fd5961  pop r9
00007aa9b5fd5963  pop r8
00007aa9b5fd5965  pop rsi
00007aa9b5fd5966  pop rdi
00007aa9b5fd5967  pop rdx
00007aa9b5fd5968  pop rcx
00007aa9b5fd5969  pop rax
00007aa9b5fd596a  add rsp, 0x08
00007aa9b5fd596e  jmp 0x00007AA9B5FD2F5B
00007aa9b5fd5973  call 0x00007AA9B5DFF430
00007aa9b5fd5978  jmp 0x00007AA9B5FD2F65
00007aa9b5fd597d  sub rsp, 0x08
00007aa9b5fd5981  push rax
00007aa9b5fd5982  push rcx
00007aa9b5fd5983  push rdx
00007aa9b5fd5984  push rdi
00007aa9b5fd5985  push rsi
00007aa9b5fd5986  push r8
00007aa9b5fd5988  push r9
00007aa9b5fd598a  push r10
00007aa9b5fd598c  push r11
00007aa9b5fd598e  sub rsp, 0xF0
00007aa9b5fd5995  vmovaps [rsp], xmm0
00007aa9b5fd599a  vmovaps [rsp+0x10], xmm1
00007aa9b5fd59a0  vmovaps [rsp+0x20], xmm2
00007aa9b5fd59a6  vmovaps [rsp+0x30], xmm3
00007aa9b5fd59ac  vmovaps [rsp+0x40], xmm4
00007aa9b5fd59b2  vmovaps [rsp+0x50], xmm5
00007aa9b5fd59b8  vmovaps [rsp+0x60], xmm6
00007aa9b5fd59be  vmovaps [rsp+0x70], xmm7
00007aa9b5fd59c4  vmovaps [rsp+0x80], xmm8
00007aa9b5fd59cd  vmovaps [rsp+0x90], xmm9
00007aa9b5fd59d6  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd59df  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd59e8  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd59f1  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd59fa  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd5a03  sub rsp, 0x30
00007aa9b5fd5a07  movaps [rsp], xmm14
00007aa9b5fd5a0c  movaps [rsp+0x10], xmm6
00007aa9b5fd5a11  movaps [rsp+0x20], xmm2
00007aa9b5fd5a16  lea rdi, [rsp]
00007aa9b5fd5a1a  mov esi, 0x00
00007aa9b5fd5a1f  mov rax, 0x63E0217C9530
00007aa9b5fd5a29  call rax
00007aa9b5fd5a2b  movaps xmm14, [rsp]
00007aa9b5fd5a30  add rsp, 0x30
00007aa9b5fd5a34  vmovaps xmm0, [rsp]
00007aa9b5fd5a39  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd5a3f  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd5a45  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd5a4b  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd5a51  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd5a57  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd5a5d  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd5a63  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd5a6c  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd5a75  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd5a7e  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd5a87  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd5a90  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd5a99  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd5aa2  add rsp, 0xF0
00007aa9b5fd5aa9  pop r11
00007aa9b5fd5aab  pop r10
00007aa9b5fd5aad  pop r9
00007aa9b5fd5aaf  pop r8
00007aa9b5fd5ab1  pop rsi
00007aa9b5fd5ab2  pop rdi
00007aa9b5fd5ab3  pop rdx
00007aa9b5fd5ab4  pop rcx
00007aa9b5fd5ab5  pop rax
00007aa9b5fd5ab6  add rsp, 0x08
00007aa9b5fd5aba  jmp 0x00007AA9B5FD2F99
00007aa9b5fd5abf  sub rsp, 0x08
00007aa9b5fd5ac3  push rax
00007aa9b5fd5ac4  push rcx
00007aa9b5fd5ac5  push rdx
00007aa9b5fd5ac6  push rdi
00007aa9b5fd5ac7  push rsi
00007aa9b5fd5ac8  push r8
00007aa9b5fd5aca  push r9
00007aa9b5fd5acc  push r10
00007aa9b5fd5ace  push r11
00007aa9b5fd5ad0  sub rsp, 0xF0
00007aa9b5fd5ad7  vmovaps [rsp], xmm0
00007aa9b5fd5adc  vmovaps [rsp+0x10], xmm1
00007aa9b5fd5ae2  vmovaps [rsp+0x20], xmm2
00007aa9b5fd5ae8  vmovaps [rsp+0x30], xmm3
00007aa9b5fd5aee  vmovaps [rsp+0x40], xmm4
00007aa9b5fd5af4  vmovaps [rsp+0x50], xmm5
00007aa9b5fd5afa  vmovaps [rsp+0x60], xmm7
00007aa9b5fd5b00  vmovaps [rsp+0x70], xmm8
00007aa9b5fd5b06  vmovaps [rsp+0x80], xmm9
00007aa9b5fd5b0f  vmovaps [rsp+0x90], xmm10
00007aa9b5fd5b18  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd5b21  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd5b2a  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd5b33  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd5b3c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd5b45  sub rsp, 0x30
00007aa9b5fd5b49  movaps [rsp], xmm6
00007aa9b5fd5b4d  movaps [rsp+0x10], xmm5
00007aa9b5fd5b52  movaps [rsp+0x20], xmm1
00007aa9b5fd5b57  lea rdi, [rsp]
00007aa9b5fd5b5b  mov esi, 0x00
00007aa9b5fd5b60  mov rax, 0x63E0217C9530
00007aa9b5fd5b6a  call rax
00007aa9b5fd5b6c  movaps xmm6, [rsp]
00007aa9b5fd5b70  add rsp, 0x30
00007aa9b5fd5b74  vmovaps xmm0, [rsp]
00007aa9b5fd5b79  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd5b7f  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd5b85  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd5b8b  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd5b91  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd5b97  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd5b9d  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd5ba3  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd5bac  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd5bb5  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd5bbe  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd5bc7  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd5bd0  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd5bd9  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd5be2  add rsp, 0xF0
00007aa9b5fd5be9  pop r11
00007aa9b5fd5beb  pop r10
00007aa9b5fd5bed  pop r9
00007aa9b5fd5bef  pop r8
00007aa9b5fd5bf1  pop rsi
00007aa9b5fd5bf2  pop rdi
00007aa9b5fd5bf3  pop rdx
00007aa9b5fd5bf4  pop rcx
00007aa9b5fd5bf5  pop rax
00007aa9b5fd5bf6  add rsp, 0x08
00007aa9b5fd5bfa  jmp 0x00007AA9B5FD2FBF
00007aa9b5fd5bff  sub rsp, 0x08
00007aa9b5fd5c03  push rax
00007aa9b5fd5c04  push rcx
00007aa9b5fd5c05  push rdx
00007aa9b5fd5c06  push rdi
00007aa9b5fd5c07  push rsi
00007aa9b5fd5c08  push r8
00007aa9b5fd5c0a  push r9
00007aa9b5fd5c0c  push r10
00007aa9b5fd5c0e  push r11
00007aa9b5fd5c10  sub rsp, 0xF0
00007aa9b5fd5c17  vmovaps [rsp], xmm0
00007aa9b5fd5c1c  vmovaps [rsp+0x10], xmm2
00007aa9b5fd5c22  vmovaps [rsp+0x20], xmm3
00007aa9b5fd5c28  vmovaps [rsp+0x30], xmm4
00007aa9b5fd5c2e  vmovaps [rsp+0x40], xmm5
00007aa9b5fd5c34  vmovaps [rsp+0x50], xmm6
00007aa9b5fd5c3a  vmovaps [rsp+0x60], xmm7
00007aa9b5fd5c40  vmovaps [rsp+0x70], xmm8
00007aa9b5fd5c46  vmovaps [rsp+0x80], xmm9
00007aa9b5fd5c4f  vmovaps [rsp+0x90], xmm10
00007aa9b5fd5c58  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd5c61  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd5c6a  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd5c73  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd5c7c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd5c85  sub rsp, 0x30
00007aa9b5fd5c89  movaps [rsp], xmm1
00007aa9b5fd5c8d  movaps [rsp+0x10], xmm5
00007aa9b5fd5c92  movaps [rsp+0x20], xmm13
00007aa9b5fd5c98  lea rdi, [rsp]
00007aa9b5fd5c9c  mov esi, 0x00
00007aa9b5fd5ca1  mov rax, 0x63E0217C9530
00007aa9b5fd5cab  call rax
00007aa9b5fd5cad  movaps xmm1, [rsp]
00007aa9b5fd5cb1  add rsp, 0x30
00007aa9b5fd5cb5  vmovaps xmm0, [rsp]
00007aa9b5fd5cba  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd5cc0  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd5cc6  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd5ccc  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd5cd2  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd5cd8  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd5cde  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd5ce4  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd5ced  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd5cf6  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd5cff  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd5d08  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd5d11  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd5d1a  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd5d23  add rsp, 0xF0
00007aa9b5fd5d2a  pop r11
00007aa9b5fd5d2c  pop r10
00007aa9b5fd5d2e  pop r9
00007aa9b5fd5d30  pop r8
00007aa9b5fd5d32  pop rsi
00007aa9b5fd5d33  pop rdi
00007aa9b5fd5d34  pop rdx
00007aa9b5fd5d35  pop rcx
00007aa9b5fd5d36  pop rax
00007aa9b5fd5d37  add rsp, 0x08
00007aa9b5fd5d3b  jmp 0x00007AA9B5FD2FDD
00007aa9b5fd5d40  sub rsp, 0x08
00007aa9b5fd5d44  push rax
00007aa9b5fd5d45  push rcx
00007aa9b5fd5d46  push rdx
00007aa9b5fd5d47  push rdi
00007aa9b5fd5d48  push rsi
00007aa9b5fd5d49  push r8
00007aa9b5fd5d4b  push r9
00007aa9b5fd5d4d  push r10
00007aa9b5fd5d4f  push r11
00007aa9b5fd5d51  sub rsp, 0xF0
00007aa9b5fd5d58  vmovaps [rsp], xmm0
00007aa9b5fd5d5d  vmovaps [rsp+0x10], xmm1
00007aa9b5fd5d63  vmovaps [rsp+0x20], xmm2
00007aa9b5fd5d69  vmovaps [rsp+0x30], xmm3
00007aa9b5fd5d6f  vmovaps [rsp+0x40], xmm4
00007aa9b5fd5d75  vmovaps [rsp+0x50], xmm6
00007aa9b5fd5d7b  vmovaps [rsp+0x60], xmm7
00007aa9b5fd5d81  vmovaps [rsp+0x70], xmm8
00007aa9b5fd5d87  vmovaps [rsp+0x80], xmm9
00007aa9b5fd5d90  vmovaps [rsp+0x90], xmm10
00007aa9b5fd5d99  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd5da2  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd5dab  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd5db4  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd5dbd  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd5dc6  sub rsp, 0x30
00007aa9b5fd5dca  movaps [rsp], xmm5
00007aa9b5fd5dce  movaps [rsp+0x10], xmm2
00007aa9b5fd5dd3  movaps [rsp+0x20], xmm13
00007aa9b5fd5dd9  lea rdi, [rsp]
00007aa9b5fd5ddd  mov esi, 0x00
00007aa9b5fd5de2  mov rax, 0x63E0217C9530
00007aa9b5fd5dec  call rax
00007aa9b5fd5dee  movaps xmm5, [rsp]
00007aa9b5fd5df2  add rsp, 0x30
00007aa9b5fd5df6  vmovaps xmm0, [rsp]
00007aa9b5fd5dfb  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd5e01  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd5e07  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd5e0d  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd5e13  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd5e19  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd5e1f  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd5e25  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd5e2e  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd5e37  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd5e40  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd5e49  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd5e52  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd5e5b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd5e64  add rsp, 0xF0
00007aa9b5fd5e6b  pop r11
00007aa9b5fd5e6d  pop r10
00007aa9b5fd5e6f  pop r9
00007aa9b5fd5e71  pop r8
00007aa9b5fd5e73  pop rsi
00007aa9b5fd5e74  pop rdi
00007aa9b5fd5e75  pop rdx
00007aa9b5fd5e76  pop rcx
00007aa9b5fd5e77  pop rax
00007aa9b5fd5e78  add rsp, 0x08
00007aa9b5fd5e7c  jmp 0x00007AA9B5FD3013
00007aa9b5fd5e81  sub rsp, 0x08
00007aa9b5fd5e85  push rax
00007aa9b5fd5e86  push rcx
00007aa9b5fd5e87  push rdx
00007aa9b5fd5e88  push rdi
00007aa9b5fd5e89  push rsi
00007aa9b5fd5e8a  push r8
00007aa9b5fd5e8c  push r9
00007aa9b5fd5e8e  push r10
00007aa9b5fd5e90  push r11
00007aa9b5fd5e92  sub rsp, 0xF0
00007aa9b5fd5e99  vmovaps [rsp], xmm0
00007aa9b5fd5e9e  vmovaps [rsp+0x10], xmm1
00007aa9b5fd5ea4  vmovaps [rsp+0x20], xmm2
00007aa9b5fd5eaa  vmovaps [rsp+0x30], xmm3
00007aa9b5fd5eb0  vmovaps [rsp+0x40], xmm4
00007aa9b5fd5eb6  vmovaps [rsp+0x50], xmm5
00007aa9b5fd5ebc  vmovaps [rsp+0x60], xmm6
00007aa9b5fd5ec2  vmovaps [rsp+0x70], xmm7
00007aa9b5fd5ec8  vmovaps [rsp+0x80], xmm8
00007aa9b5fd5ed1  vmovaps [rsp+0x90], xmm9
00007aa9b5fd5eda  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd5ee3  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd5eec  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd5ef5  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd5efe  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd5f07  sub rsp, 0x30
00007aa9b5fd5f0b  movaps [rsp], xmm13
00007aa9b5fd5f10  movaps [rsp+0x10], xmm10
00007aa9b5fd5f16  movaps [rsp+0x20], xmm1
00007aa9b5fd5f1b  lea rdi, [rsp]
00007aa9b5fd5f1f  mov esi, 0x00
00007aa9b5fd5f24  mov rax, 0x63E0217C9530
00007aa9b5fd5f2e  call rax
00007aa9b5fd5f30  movaps xmm13, [rsp]
00007aa9b5fd5f35  add rsp, 0x30
00007aa9b5fd5f39  vmovaps xmm0, [rsp]
00007aa9b5fd5f3e  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd5f44  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd5f4a  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd5f50  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd5f56  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd5f5c  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd5f62  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd5f68  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd5f71  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd5f7a  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd5f83  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd5f8c  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd5f95  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd5f9e  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd5fa7  add rsp, 0xF0
00007aa9b5fd5fae  pop r11
00007aa9b5fd5fb0  pop r10
00007aa9b5fd5fb2  pop r9
00007aa9b5fd5fb4  pop r8
00007aa9b5fd5fb6  pop rsi
00007aa9b5fd5fb7  pop rdi
00007aa9b5fd5fb8  pop rdx
00007aa9b5fd5fb9  pop rcx
00007aa9b5fd5fba  pop rax
00007aa9b5fd5fbb  add rsp, 0x08
00007aa9b5fd5fbf  jmp 0x00007AA9B5FD303C
00007aa9b5fd5fc4  sub rsp, 0x08
00007aa9b5fd5fc8  push rax
00007aa9b5fd5fc9  push rcx
00007aa9b5fd5fca  push rdx
00007aa9b5fd5fcb  push rdi
00007aa9b5fd5fcc  push rsi
00007aa9b5fd5fcd  push r8
00007aa9b5fd5fcf  push r9
00007aa9b5fd5fd1  push r10
00007aa9b5fd5fd3  push r11
00007aa9b5fd5fd5  sub rsp, 0xF0
00007aa9b5fd5fdc  vmovaps [rsp], xmm0
00007aa9b5fd5fe1  vmovaps [rsp+0x10], xmm2
00007aa9b5fd5fe7  vmovaps [rsp+0x20], xmm3
00007aa9b5fd5fed  vmovaps [rsp+0x30], xmm4
00007aa9b5fd5ff3  vmovaps [rsp+0x40], xmm5
00007aa9b5fd5ff9  vmovaps [rsp+0x50], xmm6
00007aa9b5fd5fff  vmovaps [rsp+0x60], xmm7
00007aa9b5fd6005  vmovaps [rsp+0x70], xmm8
00007aa9b5fd600b  vmovaps [rsp+0x80], xmm9
00007aa9b5fd6014  vmovaps [rsp+0x90], xmm10
00007aa9b5fd601d  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd6026  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd602f  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd6038  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd6041  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd604a  sub rsp, 0x30
00007aa9b5fd604e  movaps [rsp], xmm1
00007aa9b5fd6052  movaps [rsp+0x10], xmm15
00007aa9b5fd6058  movaps [rsp+0x20], xmm10
00007aa9b5fd605e  lea rdi, [rsp]
00007aa9b5fd6062  mov esi, 0x00
00007aa9b5fd6067  mov rax, 0x63E0217C9530
00007aa9b5fd6071  call rax
00007aa9b5fd6073  movaps xmm1, [rsp]
00007aa9b5fd6077  add rsp, 0x30
00007aa9b5fd607b  vmovaps xmm0, [rsp]
00007aa9b5fd6080  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd6086  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd608c  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd6092  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd6098  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd609e  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd60a4  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd60aa  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd60b3  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd60bc  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd60c5  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd60ce  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd60d7  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd60e0  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd60e9  add rsp, 0xF0
00007aa9b5fd60f0  pop r11
00007aa9b5fd60f2  pop r10
00007aa9b5fd60f4  pop r9
00007aa9b5fd60f6  pop r8
00007aa9b5fd60f8  pop rsi
00007aa9b5fd60f9  pop rdi
00007aa9b5fd60fa  pop rdx
00007aa9b5fd60fb  pop rcx
00007aa9b5fd60fc  pop rax
00007aa9b5fd60fd  add rsp, 0x08
00007aa9b5fd6101  jmp 0x00007AA9B5FD305B
00007aa9b5fd6106  sub rsp, 0x08
00007aa9b5fd610a  push rax
00007aa9b5fd610b  push rcx
00007aa9b5fd610c  push rdx
00007aa9b5fd610d  push rdi
00007aa9b5fd610e  push rsi
00007aa9b5fd610f  push r8
00007aa9b5fd6111  push r9
00007aa9b5fd6113  push r10
00007aa9b5fd6115  push r11
00007aa9b5fd6117  sub rsp, 0xF0
00007aa9b5fd611e  vmovaps [rsp], xmm0
00007aa9b5fd6123  vmovaps [rsp+0x10], xmm1
00007aa9b5fd6129  vmovaps [rsp+0x20], xmm2
00007aa9b5fd612f  vmovaps [rsp+0x30], xmm3
00007aa9b5fd6135  vmovaps [rsp+0x40], xmm4
00007aa9b5fd613b  vmovaps [rsp+0x50], xmm5
00007aa9b5fd6141  vmovaps [rsp+0x60], xmm6
00007aa9b5fd6147  vmovaps [rsp+0x70], xmm7
00007aa9b5fd614d  vmovaps [rsp+0x80], xmm8
00007aa9b5fd6156  vmovaps [rsp+0x90], xmm9
00007aa9b5fd615f  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd6168  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd6171  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd617a  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd6183  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd618c  sub rsp, 0x30
00007aa9b5fd6190  movaps [rsp], xmm15
00007aa9b5fd6195  movaps [rsp+0x10], xmm10
00007aa9b5fd619b  movaps [rsp+0x20], xmm11
00007aa9b5fd61a1  lea rdi, [rsp]
00007aa9b5fd61a5  mov esi, 0x00
00007aa9b5fd61aa  mov rax, 0x63E0217C9530
00007aa9b5fd61b4  call rax
00007aa9b5fd61b6  movaps xmm15, [rsp]
00007aa9b5fd61bb  add rsp, 0x30
00007aa9b5fd61bf  vmovaps xmm0, [rsp]
00007aa9b5fd61c4  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd61ca  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd61d0  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd61d6  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd61dc  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd61e2  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd61e8  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd61ee  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd61f7  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd6200  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd6209  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd6212  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd621b  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd6224  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd622d  add rsp, 0xF0
00007aa9b5fd6234  pop r11
00007aa9b5fd6236  pop r10
00007aa9b5fd6238  pop r9
00007aa9b5fd623a  pop r8
00007aa9b5fd623c  pop rsi
00007aa9b5fd623d  pop rdi
00007aa9b5fd623e  pop rdx
00007aa9b5fd623f  pop rcx
00007aa9b5fd6240  pop rax
00007aa9b5fd6241  add rsp, 0x08
00007aa9b5fd6245  jmp 0x00007AA9B5FD307E
00007aa9b5fd624a  sub rsp, 0x08
00007aa9b5fd624e  push rax
00007aa9b5fd624f  push rcx
00007aa9b5fd6250  push rdx
00007aa9b5fd6251  push rdi
00007aa9b5fd6252  push rsi
00007aa9b5fd6253  push r8
00007aa9b5fd6255  push r9
00007aa9b5fd6257  push r10
00007aa9b5fd6259  push r11
00007aa9b5fd625b  sub rsp, 0xF0
00007aa9b5fd6262  vmovaps [rsp], xmm0
00007aa9b5fd6267  vmovaps [rsp+0x10], xmm1
00007aa9b5fd626d  vmovaps [rsp+0x20], xmm2
00007aa9b5fd6273  vmovaps [rsp+0x30], xmm3
00007aa9b5fd6279  vmovaps [rsp+0x40], xmm4
00007aa9b5fd627f  vmovaps [rsp+0x50], xmm5
00007aa9b5fd6285  vmovaps [rsp+0x60], xmm6
00007aa9b5fd628b  vmovaps [rsp+0x70], xmm7
00007aa9b5fd6291  vmovaps [rsp+0x80], xmm8
00007aa9b5fd629a  vmovaps [rsp+0x90], xmm9
00007aa9b5fd62a3  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd62ac  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd62b5  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd62be  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd62c7  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd62d0  sub rsp, 0x30
00007aa9b5fd62d4  movaps [rsp], xmm10
00007aa9b5fd62d9  movaps [rsp+0x10], xmm2
00007aa9b5fd62de  movaps [rsp+0x20], xmm11
00007aa9b5fd62e4  lea rdi, [rsp]
00007aa9b5fd62e8  mov esi, 0x00
00007aa9b5fd62ed  mov rax, 0x63E0217C9530
00007aa9b5fd62f7  call rax
00007aa9b5fd62f9  movaps xmm10, [rsp]
00007aa9b5fd62fe  add rsp, 0x30
00007aa9b5fd6302  vmovaps xmm0, [rsp]
00007aa9b5fd6307  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd630d  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd6313  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd6319  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd631f  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd6325  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd632b  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd6331  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd633a  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd6343  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd634c  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd6355  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd635e  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd6367  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd6370  add rsp, 0xF0
00007aa9b5fd6377  pop r11
00007aa9b5fd6379  pop r10
00007aa9b5fd637b  pop r9
00007aa9b5fd637d  pop r8
00007aa9b5fd637f  pop rsi
00007aa9b5fd6380  pop rdi
00007aa9b5fd6381  pop rdx
00007aa9b5fd6382  pop rcx
00007aa9b5fd6383  pop rax
00007aa9b5fd6384  add rsp, 0x08
00007aa9b5fd6388  jmp 0x00007AA9B5FD30B6
00007aa9b5fd638d  sub rsp, 0x08
00007aa9b5fd6391  push rax
00007aa9b5fd6392  push rcx
00007aa9b5fd6393  push rdx
00007aa9b5fd6394  push rdi
00007aa9b5fd6395  push rsi
00007aa9b5fd6396  push r8
00007aa9b5fd6398  push r9
00007aa9b5fd639a  push r10
00007aa9b5fd639c  push r11
00007aa9b5fd639e  sub rsp, 0xF0
00007aa9b5fd63a5  vmovaps [rsp], xmm0
00007aa9b5fd63aa  vmovaps [rsp+0x10], xmm1
00007aa9b5fd63b0  vmovaps [rsp+0x20], xmm2
00007aa9b5fd63b6  vmovaps [rsp+0x30], xmm3
00007aa9b5fd63bc  vmovaps [rsp+0x40], xmm4
00007aa9b5fd63c2  vmovaps [rsp+0x50], xmm5
00007aa9b5fd63c8  vmovaps [rsp+0x60], xmm6
00007aa9b5fd63ce  vmovaps [rsp+0x70], xmm7
00007aa9b5fd63d4  vmovaps [rsp+0x80], xmm8
00007aa9b5fd63dd  vmovaps [rsp+0x90], xmm9
00007aa9b5fd63e6  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd63ef  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd63f8  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd6401  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd640a  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd6413  sub rsp, 0x30
00007aa9b5fd6417  movaps [rsp], xmm11
00007aa9b5fd641c  movaps [rsp+0x10], xmm2
00007aa9b5fd6421  movaps [rsp+0x20], xmm1
00007aa9b5fd6426  lea rdi, [rsp]
00007aa9b5fd642a  mov esi, 0x00
00007aa9b5fd642f  mov rax, 0x63E0217C9530
00007aa9b5fd6439  call rax
00007aa9b5fd643b  movaps xmm11, [rsp]
00007aa9b5fd6440  add rsp, 0x30
00007aa9b5fd6444  vmovaps xmm0, [rsp]
00007aa9b5fd6449  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd644f  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd6455  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd645b  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd6461  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd6467  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd646d  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd6473  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd647c  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd6485  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd648e  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd6497  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd64a0  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd64a9  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd64b2  add rsp, 0xF0
00007aa9b5fd64b9  pop r11
00007aa9b5fd64bb  pop r10
00007aa9b5fd64bd  pop r9
00007aa9b5fd64bf  pop r8
00007aa9b5fd64c1  pop rsi
00007aa9b5fd64c2  pop rdi
00007aa9b5fd64c3  pop rdx
00007aa9b5fd64c4  pop rcx
00007aa9b5fd64c5  pop rax
00007aa9b5fd64c6  add rsp, 0x08
00007aa9b5fd64ca  jmp 0x00007AA9B5FD30F2
00007aa9b5fd64cf  sub rsp, 0x08
00007aa9b5fd64d3  push rax
00007aa9b5fd64d4  push rcx
00007aa9b5fd64d5  push rdx
00007aa9b5fd64d6  push rdi
00007aa9b5fd64d7  push rsi
00007aa9b5fd64d8  push r8
00007aa9b5fd64da  push r9
00007aa9b5fd64dc  push r10
00007aa9b5fd64de  push r11
00007aa9b5fd64e0  sub rsp, 0xF0
00007aa9b5fd64e7  vmovaps [rsp], xmm0
00007aa9b5fd64ec  vmovaps [rsp+0x10], xmm2
00007aa9b5fd64f2  vmovaps [rsp+0x20], xmm3
00007aa9b5fd64f8  vmovaps [rsp+0x30], xmm4
00007aa9b5fd64fe  vmovaps [rsp+0x40], xmm5
00007aa9b5fd6504  vmovaps [rsp+0x50], xmm6
00007aa9b5fd650a  vmovaps [rsp+0x60], xmm7
00007aa9b5fd6510  vmovaps [rsp+0x70], xmm8
00007aa9b5fd6516  vmovaps [rsp+0x80], xmm9
00007aa9b5fd651f  vmovaps [rsp+0x90], xmm10
00007aa9b5fd6528  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd6531  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd653a  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd6543  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd654c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd6555  sub rsp, 0x30
00007aa9b5fd6559  movaps [rsp], xmm1
00007aa9b5fd655d  movaps [rsp+0x10], xmm14
00007aa9b5fd6563  movaps [rsp+0x20], xmm6
00007aa9b5fd6568  lea rdi, [rsp]
00007aa9b5fd656c  mov esi, 0x00
00007aa9b5fd6571  mov rax, 0x63E0217C9530
00007aa9b5fd657b  call rax
00007aa9b5fd657d  movaps xmm1, [rsp]
00007aa9b5fd6581  add rsp, 0x30
00007aa9b5fd6585  vmovaps xmm0, [rsp]
00007aa9b5fd658a  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd6590  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd6596  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd659c  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd65a2  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd65a8  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd65ae  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd65b4  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd65bd  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd65c6  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd65cf  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd65d8  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd65e1  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd65ea  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd65f3  add rsp, 0xF0
00007aa9b5fd65fa  pop r11
00007aa9b5fd65fc  pop r10
00007aa9b5fd65fe  pop r9
00007aa9b5fd6600  pop r8
00007aa9b5fd6602  pop rsi
00007aa9b5fd6603  pop rdi
00007aa9b5fd6604  pop rdx
00007aa9b5fd6605  pop rcx
00007aa9b5fd6606  pop rax
00007aa9b5fd6607  add rsp, 0x08
00007aa9b5fd660b  jmp 0x00007AA9B5FD310B
00007aa9b5fd6610  sub rsp, 0x08
00007aa9b5fd6614  push rax
00007aa9b5fd6615  push rcx
00007aa9b5fd6616  push rdx
00007aa9b5fd6617  push rdi
00007aa9b5fd6618  push rsi
00007aa9b5fd6619  push r8
00007aa9b5fd661b  push r9
00007aa9b5fd661d  push r10
00007aa9b5fd661f  push r11
00007aa9b5fd6621  sub rsp, 0xF0
00007aa9b5fd6628  vmovaps [rsp], xmm0
00007aa9b5fd662d  vmovaps [rsp+0x10], xmm1
00007aa9b5fd6633  vmovaps [rsp+0x20], xmm2
00007aa9b5fd6639  vmovaps [rsp+0x30], xmm3
00007aa9b5fd663f  vmovaps [rsp+0x40], xmm4
00007aa9b5fd6645  vmovaps [rsp+0x50], xmm5
00007aa9b5fd664b  vmovaps [rsp+0x60], xmm6
00007aa9b5fd6651  vmovaps [rsp+0x70], xmm7
00007aa9b5fd6657  vmovaps [rsp+0x80], xmm8
00007aa9b5fd6660  vmovaps [rsp+0x90], xmm9
00007aa9b5fd6669  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd6672  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd667b  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd6684  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd668d  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd6696  sub rsp, 0x30
00007aa9b5fd669a  movaps [rsp], xmm15
00007aa9b5fd669f  movaps [rsp+0x10], xmm14
00007aa9b5fd66a5  movaps [rsp+0x20], xmm5
00007aa9b5fd66aa  lea rdi, [rsp]
00007aa9b5fd66ae  mov esi, 0x00
00007aa9b5fd66b3  mov rax, 0x63E0217C9530
00007aa9b5fd66bd  call rax
00007aa9b5fd66bf  movaps xmm15, [rsp]
00007aa9b5fd66c4  add rsp, 0x30
00007aa9b5fd66c8  vmovaps xmm0, [rsp]
00007aa9b5fd66cd  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd66d3  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd66d9  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd66df  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd66e5  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd66eb  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd66f1  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd66f7  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd6700  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd6709  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd6712  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd671b  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd6724  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd672d  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd6736  add rsp, 0xF0
00007aa9b5fd673d  pop r11
00007aa9b5fd673f  pop r10
00007aa9b5fd6741  pop r9
00007aa9b5fd6743  pop r8
00007aa9b5fd6745  pop rsi
00007aa9b5fd6746  pop rdi
00007aa9b5fd6747  pop rdx
00007aa9b5fd6748  pop rcx
00007aa9b5fd6749  pop rax
00007aa9b5fd674a  add rsp, 0x08
00007aa9b5fd674e  jmp 0x00007AA9B5FD312B
00007aa9b5fd6753  sub rsp, 0x08
00007aa9b5fd6757  push rax
00007aa9b5fd6758  push rcx
00007aa9b5fd6759  push rdx
00007aa9b5fd675a  push rdi
00007aa9b5fd675b  push rsi
00007aa9b5fd675c  push r8
00007aa9b5fd675e  push r9
00007aa9b5fd6760  push r10
00007aa9b5fd6762  push r11
00007aa9b5fd6764  sub rsp, 0xF0
00007aa9b5fd676b  vmovaps [rsp], xmm0
00007aa9b5fd6770  vmovaps [rsp+0x10], xmm1
00007aa9b5fd6776  vmovaps [rsp+0x20], xmm2
00007aa9b5fd677c  vmovaps [rsp+0x30], xmm3
00007aa9b5fd6782  vmovaps [rsp+0x40], xmm4
00007aa9b5fd6788  vmovaps [rsp+0x50], xmm5
00007aa9b5fd678e  vmovaps [rsp+0x60], xmm7
00007aa9b5fd6794  vmovaps [rsp+0x70], xmm8
00007aa9b5fd679a  vmovaps [rsp+0x80], xmm9
00007aa9b5fd67a3  vmovaps [rsp+0x90], xmm10
00007aa9b5fd67ac  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd67b5  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd67be  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd67c7  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd67d0  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd67d9  sub rsp, 0x30
00007aa9b5fd67dd  movaps [rsp], xmm6
00007aa9b5fd67e1  movaps [rsp+0x10], xmm9
00007aa9b5fd67e7  movaps [rsp+0x20], xmm14
00007aa9b5fd67ed  lea rdi, [rsp]
00007aa9b5fd67f1  mov esi, 0x00
00007aa9b5fd67f6  mov rax, 0x63E0217C9530
00007aa9b5fd6800  call rax
00007aa9b5fd6802  movaps xmm6, [rsp]
00007aa9b5fd6806  add rsp, 0x30
00007aa9b5fd680a  vmovaps xmm0, [rsp]
00007aa9b5fd680f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd6815  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd681b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd6821  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd6827  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd682d  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd6833  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd6839  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd6842  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd684b  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd6854  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd685d  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd6866  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd686f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd6878  add rsp, 0xF0
00007aa9b5fd687f  pop r11
00007aa9b5fd6881  pop r10
00007aa9b5fd6883  pop r9
00007aa9b5fd6885  pop r8
00007aa9b5fd6887  pop rsi
00007aa9b5fd6888  pop rdi
00007aa9b5fd6889  pop rdx
00007aa9b5fd688a  pop rcx
00007aa9b5fd688b  pop rax
00007aa9b5fd688c  add rsp, 0x08
00007aa9b5fd6890  jmp 0x00007AA9B5FD3153
00007aa9b5fd6895  sub rsp, 0x08
00007aa9b5fd6899  push rax
00007aa9b5fd689a  push rcx
00007aa9b5fd689b  push rdx
00007aa9b5fd689c  push rdi
00007aa9b5fd689d  push rsi
00007aa9b5fd689e  push r8
00007aa9b5fd68a0  push r9
00007aa9b5fd68a2  push r10
00007aa9b5fd68a4  push r11
00007aa9b5fd68a6  sub rsp, 0xF0
00007aa9b5fd68ad  vmovaps [rsp], xmm0
00007aa9b5fd68b2  vmovaps [rsp+0x10], xmm1
00007aa9b5fd68b8  vmovaps [rsp+0x20], xmm2
00007aa9b5fd68be  vmovaps [rsp+0x30], xmm3
00007aa9b5fd68c4  vmovaps [rsp+0x40], xmm4
00007aa9b5fd68ca  vmovaps [rsp+0x50], xmm5
00007aa9b5fd68d0  vmovaps [rsp+0x60], xmm6
00007aa9b5fd68d6  vmovaps [rsp+0x70], xmm7
00007aa9b5fd68dc  vmovaps [rsp+0x80], xmm8
00007aa9b5fd68e5  vmovaps [rsp+0x90], xmm9
00007aa9b5fd68ee  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd68f7  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd6900  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd6909  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd6912  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd691b  sub rsp, 0x30
00007aa9b5fd691f  movaps [rsp], xmm14
00007aa9b5fd6924  movaps [rsp+0x10], xmm9
00007aa9b5fd692a  movaps [rsp+0x20], xmm13
00007aa9b5fd6930  lea rdi, [rsp]
00007aa9b5fd6934  mov esi, 0x00
00007aa9b5fd6939  mov rax, 0x63E0217C9530
00007aa9b5fd6943  call rax
00007aa9b5fd6945  movaps xmm14, [rsp]
00007aa9b5fd694a  add rsp, 0x30
00007aa9b5fd694e  vmovaps xmm0, [rsp]
00007aa9b5fd6953  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd6959  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd695f  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd6965  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd696b  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd6971  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd6977  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd697d  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd6986  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd698f  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd6998  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd69a1  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd69aa  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd69b3  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd69bc  add rsp, 0xF0
00007aa9b5fd69c3  pop r11
00007aa9b5fd69c5  pop r10
00007aa9b5fd69c7  pop r9
00007aa9b5fd69c9  pop r8
00007aa9b5fd69cb  pop rsi
00007aa9b5fd69cc  pop rdi
00007aa9b5fd69cd  pop rdx
00007aa9b5fd69ce  pop rcx
00007aa9b5fd69cf  pop rax
00007aa9b5fd69d0  add rsp, 0x08
00007aa9b5fd69d4  jmp 0x00007AA9B5FD3176
00007aa9b5fd69d9  sub rsp, 0x08
00007aa9b5fd69dd  push rax
00007aa9b5fd69de  push rcx
00007aa9b5fd69df  push rdx
00007aa9b5fd69e0  push rdi
00007aa9b5fd69e1  push rsi
00007aa9b5fd69e2  push r8
00007aa9b5fd69e4  push r9
00007aa9b5fd69e6  push r10
00007aa9b5fd69e8  push r11
00007aa9b5fd69ea  sub rsp, 0xF0
00007aa9b5fd69f1  vmovaps [rsp], xmm0
00007aa9b5fd69f6  vmovaps [rsp+0x10], xmm1
00007aa9b5fd69fc  vmovaps [rsp+0x20], xmm2
00007aa9b5fd6a02  vmovaps [rsp+0x30], xmm3
00007aa9b5fd6a08  vmovaps [rsp+0x40], xmm4
00007aa9b5fd6a0e  vmovaps [rsp+0x50], xmm5
00007aa9b5fd6a14  vmovaps [rsp+0x60], xmm6
00007aa9b5fd6a1a  vmovaps [rsp+0x70], xmm7
00007aa9b5fd6a20  vmovaps [rsp+0x80], xmm8
00007aa9b5fd6a29  vmovaps [rsp+0x90], xmm9
00007aa9b5fd6a32  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd6a3b  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd6a44  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd6a4d  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd6a56  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd6a5f  sub rsp, 0x30
00007aa9b5fd6a63  movaps [rsp], xmm13
00007aa9b5fd6a68  movaps [rsp+0x10], xmm9
00007aa9b5fd6a6e  movaps [rsp+0x20], xmm10
00007aa9b5fd6a74  lea rdi, [rsp]
00007aa9b5fd6a78  mov esi, 0x00
00007aa9b5fd6a7d  mov rax, 0x63E0217C9530
00007aa9b5fd6a87  call rax
00007aa9b5fd6a89  movaps xmm13, [rsp]
00007aa9b5fd6a8e  add rsp, 0x30
00007aa9b5fd6a92  vmovaps xmm0, [rsp]
00007aa9b5fd6a97  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd6a9d  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd6aa3  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd6aa9  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd6aaf  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd6ab5  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd6abb  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd6ac1  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd6aca  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd6ad3  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd6adc  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd6ae5  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd6aee  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd6af7  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd6b00  add rsp, 0xF0
00007aa9b5fd6b07  pop r11
00007aa9b5fd6b09  pop r10
00007aa9b5fd6b0b  pop r9
00007aa9b5fd6b0d  pop r8
00007aa9b5fd6b0f  pop rsi
00007aa9b5fd6b10  pop rdi
00007aa9b5fd6b11  pop rdx
00007aa9b5fd6b12  pop rcx
00007aa9b5fd6b13  pop rax
00007aa9b5fd6b14  add rsp, 0x08
00007aa9b5fd6b18  jmp 0x00007AA9B5FD3196
00007aa9b5fd6b1d  call 0x00007AA9B5E0AFE0
00007aa9b5fd6b22  jmp 0x00007AA9B5FD31EB
00007aa9b5fd6b27  sub rsp, 0x08
00007aa9b5fd6b2b  push rax
00007aa9b5fd6b2c  push rcx
00007aa9b5fd6b2d  push rdx
00007aa9b5fd6b2e  push rdi
00007aa9b5fd6b2f  push rsi
00007aa9b5fd6b30  push r8
00007aa9b5fd6b32  push r9
00007aa9b5fd6b34  push r10
00007aa9b5fd6b36  push r11
00007aa9b5fd6b38  sub rsp, 0xF0
00007aa9b5fd6b3f  vmovaps [rsp], xmm0
00007aa9b5fd6b44  vmovaps [rsp+0x10], xmm1
00007aa9b5fd6b4a  vmovaps [rsp+0x20], xmm2
00007aa9b5fd6b50  vmovaps [rsp+0x30], xmm3
00007aa9b5fd6b56  vmovaps [rsp+0x40], xmm4
00007aa9b5fd6b5c  vmovaps [rsp+0x50], xmm5
00007aa9b5fd6b62  vmovaps [rsp+0x60], xmm6
00007aa9b5fd6b68  vmovaps [rsp+0x70], xmm7
00007aa9b5fd6b6e  vmovaps [rsp+0x80], xmm8
00007aa9b5fd6b77  vmovaps [rsp+0x90], xmm10
00007aa9b5fd6b80  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd6b89  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd6b92  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd6b9b  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd6ba4  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd6bad  sub rsp, 0x30
00007aa9b5fd6bb1  movaps [rsp], xmm9
00007aa9b5fd6bb6  movaps [rsp+0x10], xmm8
00007aa9b5fd6bbc  movaps [rsp+0x20], xmm10
00007aa9b5fd6bc2  lea rdi, [rsp]
00007aa9b5fd6bc6  mov esi, 0x00
00007aa9b5fd6bcb  mov rax, 0x63E0217C9530
00007aa9b5fd6bd5  call rax
00007aa9b5fd6bd7  movaps xmm9, [rsp]
00007aa9b5fd6bdc  add rsp, 0x30
00007aa9b5fd6be0  vmovaps xmm0, [rsp]
00007aa9b5fd6be5  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd6beb  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd6bf1  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd6bf7  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd6bfd  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd6c03  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd6c09  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd6c0f  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd6c18  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd6c21  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd6c2a  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd6c33  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd6c3c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd6c45  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd6c4e  add rsp, 0xF0
00007aa9b5fd6c55  pop r11
00007aa9b5fd6c57  pop r10
00007aa9b5fd6c59  pop r9
00007aa9b5fd6c5b  pop r8
00007aa9b5fd6c5d  pop rsi
00007aa9b5fd6c5e  pop rdi
00007aa9b5fd6c5f  pop rdx
00007aa9b5fd6c60  pop rcx
00007aa9b5fd6c61  pop rax
00007aa9b5fd6c62  add rsp, 0x08
00007aa9b5fd6c66  jmp 0x00007AA9B5FD321C
00007aa9b5fd6c6b  sub rsp, 0x08
00007aa9b5fd6c6f  push rax
00007aa9b5fd6c70  push rcx
00007aa9b5fd6c71  push rdx
00007aa9b5fd6c72  push rdi
00007aa9b5fd6c73  push rsi
00007aa9b5fd6c74  push r8
00007aa9b5fd6c76  push r9
00007aa9b5fd6c78  push r10
00007aa9b5fd6c7a  push r11
00007aa9b5fd6c7c  sub rsp, 0xF0
00007aa9b5fd6c83  vmovaps [rsp], xmm0
00007aa9b5fd6c88  vmovaps [rsp+0x10], xmm1
00007aa9b5fd6c8e  vmovaps [rsp+0x20], xmm2
00007aa9b5fd6c94  vmovaps [rsp+0x30], xmm3
00007aa9b5fd6c9a  vmovaps [rsp+0x40], xmm4
00007aa9b5fd6ca0  vmovaps [rsp+0x50], xmm5
00007aa9b5fd6ca6  vmovaps [rsp+0x60], xmm6
00007aa9b5fd6cac  vmovaps [rsp+0x70], xmm7
00007aa9b5fd6cb2  vmovaps [rsp+0x80], xmm8
00007aa9b5fd6cbb  vmovaps [rsp+0x90], xmm9
00007aa9b5fd6cc4  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd6ccd  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd6cd6  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd6cdf  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd6ce8  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd6cf1  sub rsp, 0x30
00007aa9b5fd6cf5  movaps [rsp], xmm10
00007aa9b5fd6cfa  movaps [rsp+0x10], xmm1
00007aa9b5fd6cff  movaps [rsp+0x20], xmm11
00007aa9b5fd6d05  lea rdi, [rsp]
00007aa9b5fd6d09  mov esi, 0x00
00007aa9b5fd6d0e  mov rax, 0x63E0217C9530
00007aa9b5fd6d18  call rax
00007aa9b5fd6d1a  movaps xmm10, [rsp]
00007aa9b5fd6d1f  add rsp, 0x30
00007aa9b5fd6d23  vmovaps xmm0, [rsp]
00007aa9b5fd6d28  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd6d2e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd6d34  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd6d3a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd6d40  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd6d46  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd6d4c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd6d52  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd6d5b  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd6d64  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd6d6d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd6d76  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd6d7f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd6d88  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd6d91  add rsp, 0xF0
00007aa9b5fd6d98  pop r11
00007aa9b5fd6d9a  pop r10
00007aa9b5fd6d9c  pop r9
00007aa9b5fd6d9e  pop r8
00007aa9b5fd6da0  pop rsi
00007aa9b5fd6da1  pop rdi
00007aa9b5fd6da2  pop rdx
00007aa9b5fd6da3  pop rcx
00007aa9b5fd6da4  pop rax
00007aa9b5fd6da5  add rsp, 0x08
00007aa9b5fd6da9  jmp 0x00007AA9B5FD3237
00007aa9b5fd6dae  sub rsp, 0x08
00007aa9b5fd6db2  push rax
00007aa9b5fd6db3  push rcx
00007aa9b5fd6db4  push rdx
00007aa9b5fd6db5  push rdi
00007aa9b5fd6db6  push rsi
00007aa9b5fd6db7  push r8
00007aa9b5fd6db9  push r9
00007aa9b5fd6dbb  push r10
00007aa9b5fd6dbd  push r11
00007aa9b5fd6dbf  sub rsp, 0xF0
00007aa9b5fd6dc6  vmovaps [rsp], xmm0
00007aa9b5fd6dcb  vmovaps [rsp+0x10], xmm2
00007aa9b5fd6dd1  vmovaps [rsp+0x20], xmm3
00007aa9b5fd6dd7  vmovaps [rsp+0x30], xmm4
00007aa9b5fd6ddd  vmovaps [rsp+0x40], xmm5
00007aa9b5fd6de3  vmovaps [rsp+0x50], xmm6
00007aa9b5fd6de9  vmovaps [rsp+0x60], xmm7
00007aa9b5fd6def  vmovaps [rsp+0x70], xmm8
00007aa9b5fd6df5  vmovaps [rsp+0x80], xmm9
00007aa9b5fd6dfe  vmovaps [rsp+0x90], xmm10
00007aa9b5fd6e07  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd6e10  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd6e19  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd6e22  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd6e2b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd6e34  sub rsp, 0x30
00007aa9b5fd6e38  movaps [rsp], xmm1
00007aa9b5fd6e3c  movaps [rsp+0x10], xmm15
00007aa9b5fd6e42  movaps [rsp+0x20], xmm6
00007aa9b5fd6e47  lea rdi, [rsp]
00007aa9b5fd6e4b  mov esi, 0x00
00007aa9b5fd6e50  mov rax, 0x63E0217C9530
00007aa9b5fd6e5a  call rax
00007aa9b5fd6e5c  movaps xmm1, [rsp]
00007aa9b5fd6e60  add rsp, 0x30
00007aa9b5fd6e64  vmovaps xmm0, [rsp]
00007aa9b5fd6e69  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd6e6f  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd6e75  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd6e7b  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd6e81  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd6e87  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd6e8d  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd6e93  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd6e9c  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd6ea5  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd6eae  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd6eb7  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd6ec0  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd6ec9  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd6ed2  add rsp, 0xF0
00007aa9b5fd6ed9  pop r11
00007aa9b5fd6edb  pop r10
00007aa9b5fd6edd  pop r9
00007aa9b5fd6edf  pop r8
00007aa9b5fd6ee1  pop rsi
00007aa9b5fd6ee2  pop rdi
00007aa9b5fd6ee3  pop rdx
00007aa9b5fd6ee4  pop rcx
00007aa9b5fd6ee5  pop rax
00007aa9b5fd6ee6  add rsp, 0x08
00007aa9b5fd6eea  jmp 0x00007AA9B5FD3250
00007aa9b5fd6eef  sub rsp, 0x08
00007aa9b5fd6ef3  push rax
00007aa9b5fd6ef4  push rcx
00007aa9b5fd6ef5  push rdx
00007aa9b5fd6ef6  push rdi
00007aa9b5fd6ef7  push rsi
00007aa9b5fd6ef8  push r8
00007aa9b5fd6efa  push r9
00007aa9b5fd6efc  push r10
00007aa9b5fd6efe  push r11
00007aa9b5fd6f00  sub rsp, 0xF0
00007aa9b5fd6f07  vmovaps [rsp], xmm0
00007aa9b5fd6f0c  vmovaps [rsp+0x10], xmm1
00007aa9b5fd6f12  vmovaps [rsp+0x20], xmm2
00007aa9b5fd6f18  vmovaps [rsp+0x30], xmm3
00007aa9b5fd6f1e  vmovaps [rsp+0x40], xmm4
00007aa9b5fd6f24  vmovaps [rsp+0x50], xmm5
00007aa9b5fd6f2a  vmovaps [rsp+0x60], xmm6
00007aa9b5fd6f30  vmovaps [rsp+0x70], xmm7
00007aa9b5fd6f36  vmovaps [rsp+0x80], xmm8
00007aa9b5fd6f3f  vmovaps [rsp+0x90], xmm9
00007aa9b5fd6f48  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd6f51  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd6f5a  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd6f63  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd6f6c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd6f75  sub rsp, 0x30
00007aa9b5fd6f79  movaps [rsp], xmm11
00007aa9b5fd6f7e  movaps [rsp+0x10], xmm12
00007aa9b5fd6f84  movaps [rsp+0x20], xmm15
00007aa9b5fd6f8a  lea rdi, [rsp]
00007aa9b5fd6f8e  mov esi, 0x00
00007aa9b5fd6f93  mov rax, 0x63E0217C9530
00007aa9b5fd6f9d  call rax
00007aa9b5fd6f9f  movaps xmm11, [rsp]
00007aa9b5fd6fa4  add rsp, 0x30
00007aa9b5fd6fa8  vmovaps xmm0, [rsp]
00007aa9b5fd6fad  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd6fb3  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd6fb9  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd6fbf  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd6fc5  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd6fcb  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd6fd1  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd6fd7  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd6fe0  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd6fe9  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd6ff2  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd6ffb  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd7004  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd700d  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd7016  add rsp, 0xF0
00007aa9b5fd701d  pop r11
00007aa9b5fd701f  pop r10
00007aa9b5fd7021  pop r9
00007aa9b5fd7023  pop r8
00007aa9b5fd7025  pop rsi
00007aa9b5fd7026  pop rdi
00007aa9b5fd7027  pop rdx
00007aa9b5fd7028  pop rcx
00007aa9b5fd7029  pop rax
00007aa9b5fd702a  add rsp, 0x08
00007aa9b5fd702e  jmp 0x00007AA9B5FD327A
00007aa9b5fd7033  sub rsp, 0x08
00007aa9b5fd7037  push rax
00007aa9b5fd7038  push rcx
00007aa9b5fd7039  push rdx
00007aa9b5fd703a  push rdi
00007aa9b5fd703b  push rsi
00007aa9b5fd703c  push r8
00007aa9b5fd703e  push r9
00007aa9b5fd7040  push r10
00007aa9b5fd7042  push r11
00007aa9b5fd7044  sub rsp, 0xF0
00007aa9b5fd704b  vmovaps [rsp], xmm0
00007aa9b5fd7050  vmovaps [rsp+0x10], xmm1
00007aa9b5fd7056  vmovaps [rsp+0x20], xmm2
00007aa9b5fd705c  vmovaps [rsp+0x30], xmm3
00007aa9b5fd7062  vmovaps [rsp+0x40], xmm4
00007aa9b5fd7068  vmovaps [rsp+0x50], xmm5
00007aa9b5fd706e  vmovaps [rsp+0x60], xmm6
00007aa9b5fd7074  vmovaps [rsp+0x70], xmm7
00007aa9b5fd707a  vmovaps [rsp+0x80], xmm8
00007aa9b5fd7083  vmovaps [rsp+0x90], xmm9
00007aa9b5fd708c  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd7095  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd709e  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd70a7  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd70b0  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd70b9  sub rsp, 0x30
00007aa9b5fd70bd  movaps [rsp], xmm12
00007aa9b5fd70c2  movaps [rsp+0x10], xmm8
00007aa9b5fd70c8  movaps [rsp+0x20], xmm15
00007aa9b5fd70ce  lea rdi, [rsp]
00007aa9b5fd70d2  mov esi, 0x00
00007aa9b5fd70d7  mov rax, 0x63E0217C9530
00007aa9b5fd70e1  call rax
00007aa9b5fd70e3  movaps xmm12, [rsp]
00007aa9b5fd70e8  add rsp, 0x30
00007aa9b5fd70ec  vmovaps xmm0, [rsp]
00007aa9b5fd70f1  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd70f7  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd70fd  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7103  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd7109  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd710f  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd7115  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd711b  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd7124  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd712d  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd7136  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd713f  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd7148  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd7151  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd715a  add rsp, 0xF0
00007aa9b5fd7161  pop r11
00007aa9b5fd7163  pop r10
00007aa9b5fd7165  pop r9
00007aa9b5fd7167  pop r8
00007aa9b5fd7169  pop rsi
00007aa9b5fd716a  pop rdi
00007aa9b5fd716b  pop rdx
00007aa9b5fd716c  pop rcx
00007aa9b5fd716d  pop rax
00007aa9b5fd716e  add rsp, 0x08
00007aa9b5fd7172  jmp 0x00007AA9B5FD32A9
00007aa9b5fd7177  sub rsp, 0x08
00007aa9b5fd717b  push rax
00007aa9b5fd717c  push rcx
00007aa9b5fd717d  push rdx
00007aa9b5fd717e  push rdi
00007aa9b5fd717f  push rsi
00007aa9b5fd7180  push r8
00007aa9b5fd7182  push r9
00007aa9b5fd7184  push r10
00007aa9b5fd7186  push r11
00007aa9b5fd7188  sub rsp, 0xF0
00007aa9b5fd718f  vmovaps [rsp], xmm0
00007aa9b5fd7194  vmovaps [rsp+0x10], xmm1
00007aa9b5fd719a  vmovaps [rsp+0x20], xmm2
00007aa9b5fd71a0  vmovaps [rsp+0x30], xmm3
00007aa9b5fd71a6  vmovaps [rsp+0x40], xmm4
00007aa9b5fd71ac  vmovaps [rsp+0x50], xmm5
00007aa9b5fd71b2  vmovaps [rsp+0x60], xmm6
00007aa9b5fd71b8  vmovaps [rsp+0x70], xmm7
00007aa9b5fd71be  vmovaps [rsp+0x80], xmm9
00007aa9b5fd71c7  vmovaps [rsp+0x90], xmm10
00007aa9b5fd71d0  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd71d9  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd71e2  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd71eb  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd71f4  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd71fd  sub rsp, 0x30
00007aa9b5fd7201  movaps [rsp], xmm8
00007aa9b5fd7206  movaps [rsp+0x10], xmm7
00007aa9b5fd720b  movaps [rsp+0x20], xmm15
00007aa9b5fd7211  lea rdi, [rsp]
00007aa9b5fd7215  mov esi, 0x00
00007aa9b5fd721a  mov rax, 0x63E0217C9530
00007aa9b5fd7224  call rax
00007aa9b5fd7226  movaps xmm8, [rsp]
00007aa9b5fd722b  add rsp, 0x30
00007aa9b5fd722f  vmovaps xmm0, [rsp]
00007aa9b5fd7234  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd723a  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd7240  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7246  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd724c  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd7252  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd7258  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd725e  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd7267  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd7270  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd7279  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd7282  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd728b  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd7294  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd729d  add rsp, 0xF0
00007aa9b5fd72a4  pop r11
00007aa9b5fd72a6  pop r10
00007aa9b5fd72a8  pop r9
00007aa9b5fd72aa  pop r8
00007aa9b5fd72ac  pop rsi
00007aa9b5fd72ad  pop rdi
00007aa9b5fd72ae  pop rdx
00007aa9b5fd72af  pop rcx
00007aa9b5fd72b0  pop rax
00007aa9b5fd72b1  add rsp, 0x08
00007aa9b5fd72b5  jmp 0x00007AA9B5FD32CF
00007aa9b5fd72ba  sub rsp, 0x08
00007aa9b5fd72be  push rax
00007aa9b5fd72bf  push rcx
00007aa9b5fd72c0  push rdx
00007aa9b5fd72c1  push rdi
00007aa9b5fd72c2  push rsi
00007aa9b5fd72c3  push r8
00007aa9b5fd72c5  push r9
00007aa9b5fd72c7  push r10
00007aa9b5fd72c9  push r11
00007aa9b5fd72cb  sub rsp, 0xF0
00007aa9b5fd72d2  vmovaps [rsp], xmm0
00007aa9b5fd72d7  vmovaps [rsp+0x10], xmm1
00007aa9b5fd72dd  vmovaps [rsp+0x20], xmm2
00007aa9b5fd72e3  vmovaps [rsp+0x30], xmm3
00007aa9b5fd72e9  vmovaps [rsp+0x40], xmm4
00007aa9b5fd72ef  vmovaps [rsp+0x50], xmm5
00007aa9b5fd72f5  vmovaps [rsp+0x60], xmm6
00007aa9b5fd72fb  vmovaps [rsp+0x70], xmm7
00007aa9b5fd7301  vmovaps [rsp+0x80], xmm8
00007aa9b5fd730a  vmovaps [rsp+0x90], xmm9
00007aa9b5fd7313  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd731c  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd7325  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd732e  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd7337  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd7340  sub rsp, 0x30
00007aa9b5fd7344  movaps [rsp], xmm15
00007aa9b5fd7349  movaps [rsp+0x10], xmm14
00007aa9b5fd734f  movaps [rsp+0x20], xmm9
00007aa9b5fd7355  lea rdi, [rsp]
00007aa9b5fd7359  mov esi, 0x00
00007aa9b5fd735e  mov rax, 0x63E0217C9530
00007aa9b5fd7368  call rax
00007aa9b5fd736a  movaps xmm15, [rsp]
00007aa9b5fd736f  add rsp, 0x30
00007aa9b5fd7373  vmovaps xmm0, [rsp]
00007aa9b5fd7378  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd737e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd7384  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd738a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd7390  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd7396  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd739c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd73a2  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd73ab  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd73b4  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd73bd  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd73c6  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd73cf  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd73d8  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd73e1  add rsp, 0xF0
00007aa9b5fd73e8  pop r11
00007aa9b5fd73ea  pop r10
00007aa9b5fd73ec  pop r9
00007aa9b5fd73ee  pop r8
00007aa9b5fd73f0  pop rsi
00007aa9b5fd73f1  pop rdi
00007aa9b5fd73f2  pop rdx
00007aa9b5fd73f3  pop rcx
00007aa9b5fd73f4  pop rax
00007aa9b5fd73f5  add rsp, 0x08
00007aa9b5fd73f9  jmp 0x00007AA9B5FD32E9
00007aa9b5fd73fe  sub rsp, 0x08
00007aa9b5fd7402  push rax
00007aa9b5fd7403  push rcx
00007aa9b5fd7404  push rdx
00007aa9b5fd7405  push rdi
00007aa9b5fd7406  push rsi
00007aa9b5fd7407  push r8
00007aa9b5fd7409  push r9
00007aa9b5fd740b  push r10
00007aa9b5fd740d  push r11
00007aa9b5fd740f  sub rsp, 0xF0
00007aa9b5fd7416  vmovaps [rsp], xmm0
00007aa9b5fd741b  vmovaps [rsp+0x10], xmm1
00007aa9b5fd7421  vmovaps [rsp+0x20], xmm2
00007aa9b5fd7427  vmovaps [rsp+0x30], xmm3
00007aa9b5fd742d  vmovaps [rsp+0x40], xmm4
00007aa9b5fd7433  vmovaps [rsp+0x50], xmm5
00007aa9b5fd7439  vmovaps [rsp+0x60], xmm6
00007aa9b5fd743f  vmovaps [rsp+0x70], xmm7
00007aa9b5fd7445  vmovaps [rsp+0x80], xmm8
00007aa9b5fd744e  vmovaps [rsp+0x90], xmm10
00007aa9b5fd7457  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd7460  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd7469  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd7472  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd747b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd7484  sub rsp, 0x30
00007aa9b5fd7488  movaps [rsp], xmm9
00007aa9b5fd748d  movaps [rsp+0x10], xmm7
00007aa9b5fd7492  movaps [rsp+0x20], xmm14
00007aa9b5fd7498  lea rdi, [rsp]
00007aa9b5fd749c  mov esi, 0x00
00007aa9b5fd74a1  mov rax, 0x63E0217C9530
00007aa9b5fd74ab  call rax
00007aa9b5fd74ad  movaps xmm9, [rsp]
00007aa9b5fd74b2  add rsp, 0x30
00007aa9b5fd74b6  vmovaps xmm0, [rsp]
00007aa9b5fd74bb  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd74c1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd74c7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd74cd  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd74d3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd74d9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd74df  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd74e5  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd74ee  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd74f7  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd7500  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd7509  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd7512  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd751b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd7524  add rsp, 0xF0
00007aa9b5fd752b  pop r11
00007aa9b5fd752d  pop r10
00007aa9b5fd752f  pop r9
00007aa9b5fd7531  pop r8
00007aa9b5fd7533  pop rsi
00007aa9b5fd7534  pop rdi
00007aa9b5fd7535  pop rdx
00007aa9b5fd7536  pop rcx
00007aa9b5fd7537  pop rax
00007aa9b5fd7538  add rsp, 0x08
00007aa9b5fd753c  jmp 0x00007AA9B5FD3318
00007aa9b5fd7541  sub rsp, 0x08
00007aa9b5fd7545  push rax
00007aa9b5fd7546  push rcx
00007aa9b5fd7547  push rdx
00007aa9b5fd7548  push rdi
00007aa9b5fd7549  push rsi
00007aa9b5fd754a  push r8
00007aa9b5fd754c  push r9
00007aa9b5fd754e  push r10
00007aa9b5fd7550  push r11
00007aa9b5fd7552  sub rsp, 0xF0
00007aa9b5fd7559  vmovaps [rsp], xmm0
00007aa9b5fd755e  vmovaps [rsp+0x10], xmm1
00007aa9b5fd7564  vmovaps [rsp+0x20], xmm2
00007aa9b5fd756a  vmovaps [rsp+0x30], xmm3
00007aa9b5fd7570  vmovaps [rsp+0x40], xmm4
00007aa9b5fd7576  vmovaps [rsp+0x50], xmm5
00007aa9b5fd757c  vmovaps [rsp+0x60], xmm6
00007aa9b5fd7582  vmovaps [rsp+0x70], xmm7
00007aa9b5fd7588  vmovaps [rsp+0x80], xmm8
00007aa9b5fd7591  vmovaps [rsp+0x90], xmm9
00007aa9b5fd759a  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd75a3  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd75ac  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd75b5  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd75be  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd75c7  sub rsp, 0x30
00007aa9b5fd75cb  movaps [rsp], xmm14
00007aa9b5fd75d0  movaps [rsp+0x10], xmm13
00007aa9b5fd75d6  movaps [rsp+0x20], xmm11
00007aa9b5fd75dc  lea rdi, [rsp]
00007aa9b5fd75e0  mov esi, 0x00
00007aa9b5fd75e5  mov rax, 0x63E0217C9530
00007aa9b5fd75ef  call rax
00007aa9b5fd75f1  movaps xmm14, [rsp]
00007aa9b5fd75f6  add rsp, 0x30
00007aa9b5fd75fa  vmovaps xmm0, [rsp]
00007aa9b5fd75ff  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd7605  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd760b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7611  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd7617  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd761d  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd7623  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd7629  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd7632  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd763b  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd7644  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd764d  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd7656  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd765f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd7668  add rsp, 0xF0
00007aa9b5fd766f  pop r11
00007aa9b5fd7671  pop r10
00007aa9b5fd7673  pop r9
00007aa9b5fd7675  pop r8
00007aa9b5fd7677  pop rsi
00007aa9b5fd7678  pop rdi
00007aa9b5fd7679  pop rdx
00007aa9b5fd767a  pop rcx
00007aa9b5fd767b  pop rax
00007aa9b5fd767c  add rsp, 0x08
00007aa9b5fd7680  jmp 0x00007AA9B5FD3332
00007aa9b5fd7685  sub rsp, 0x08
00007aa9b5fd7689  push rax
00007aa9b5fd768a  push rcx
00007aa9b5fd768b  push rdx
00007aa9b5fd768c  push rdi
00007aa9b5fd768d  push rsi
00007aa9b5fd768e  push r8
00007aa9b5fd7690  push r9
00007aa9b5fd7692  push r10
00007aa9b5fd7694  push r11
00007aa9b5fd7696  sub rsp, 0xF0
00007aa9b5fd769d  vmovaps [rsp], xmm0
00007aa9b5fd76a2  vmovaps [rsp+0x10], xmm1
00007aa9b5fd76a8  vmovaps [rsp+0x20], xmm2
00007aa9b5fd76ae  vmovaps [rsp+0x30], xmm3
00007aa9b5fd76b4  vmovaps [rsp+0x40], xmm4
00007aa9b5fd76ba  vmovaps [rsp+0x50], xmm5
00007aa9b5fd76c0  vmovaps [rsp+0x60], xmm6
00007aa9b5fd76c6  vmovaps [rsp+0x70], xmm7
00007aa9b5fd76cc  vmovaps [rsp+0x80], xmm8
00007aa9b5fd76d5  vmovaps [rsp+0x90], xmm9
00007aa9b5fd76de  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd76e7  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd76f0  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd76f9  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd7702  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd770b  sub rsp, 0x30
00007aa9b5fd770f  movaps [rsp], xmm11
00007aa9b5fd7714  movaps [rsp+0x10], xmm7
00007aa9b5fd7719  movaps [rsp+0x20], xmm13
00007aa9b5fd771f  lea rdi, [rsp]
00007aa9b5fd7723  mov esi, 0x00
00007aa9b5fd7728  mov rax, 0x63E0217C9530
00007aa9b5fd7732  call rax
00007aa9b5fd7734  movaps xmm11, [rsp]
00007aa9b5fd7739  add rsp, 0x30
00007aa9b5fd773d  vmovaps xmm0, [rsp]
00007aa9b5fd7742  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd7748  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd774e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7754  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd775a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd7760  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd7766  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd776c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd7775  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd777e  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd7787  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd7790  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd7799  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd77a2  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd77ab  add rsp, 0xF0
00007aa9b5fd77b2  pop r11
00007aa9b5fd77b4  pop r10
00007aa9b5fd77b6  pop r9
00007aa9b5fd77b8  pop r8
00007aa9b5fd77ba  pop rsi
00007aa9b5fd77bb  pop rdi
00007aa9b5fd77bc  pop rdx
00007aa9b5fd77bd  pop rcx
00007aa9b5fd77be  pop rax
00007aa9b5fd77bf  add rsp, 0x08
00007aa9b5fd77c3  jmp 0x00007AA9B5FD335E
00007aa9b5fd77c8  sub rsp, 0x08
00007aa9b5fd77cc  push rax
00007aa9b5fd77cd  push rcx
00007aa9b5fd77ce  push rdx
00007aa9b5fd77cf  push rdi
00007aa9b5fd77d0  push rsi
00007aa9b5fd77d1  push r8
00007aa9b5fd77d3  push r9
00007aa9b5fd77d5  push r10
00007aa9b5fd77d7  push r11
00007aa9b5fd77d9  sub rsp, 0xF0
00007aa9b5fd77e0  vmovaps [rsp], xmm0
00007aa9b5fd77e5  vmovaps [rsp+0x10], xmm1
00007aa9b5fd77eb  vmovaps [rsp+0x20], xmm2
00007aa9b5fd77f1  vmovaps [rsp+0x30], xmm3
00007aa9b5fd77f7  vmovaps [rsp+0x40], xmm4
00007aa9b5fd77fd  vmovaps [rsp+0x50], xmm5
00007aa9b5fd7803  vmovaps [rsp+0x60], xmm6
00007aa9b5fd7809  vmovaps [rsp+0x70], xmm7
00007aa9b5fd780f  vmovaps [rsp+0x80], xmm8
00007aa9b5fd7818  vmovaps [rsp+0x90], xmm9
00007aa9b5fd7821  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd782a  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd7833  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd783c  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd7845  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd784e  sub rsp, 0x30
00007aa9b5fd7852  movaps [rsp], xmm13
00007aa9b5fd7857  movaps [rsp+0x10], xmm10
00007aa9b5fd785d  movaps [rsp+0x20], xmm12
00007aa9b5fd7863  lea rdi, [rsp]
00007aa9b5fd7867  mov esi, 0x00
00007aa9b5fd786c  mov rax, 0x63E0217C9530
00007aa9b5fd7876  call rax
00007aa9b5fd7878  movaps xmm13, [rsp]
00007aa9b5fd787d  add rsp, 0x30
00007aa9b5fd7881  vmovaps xmm0, [rsp]
00007aa9b5fd7886  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd788c  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd7892  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7898  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd789e  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd78a4  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd78aa  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd78b0  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd78b9  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd78c2  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd78cb  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd78d4  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd78dd  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd78e6  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd78ef  add rsp, 0xF0
00007aa9b5fd78f6  pop r11
00007aa9b5fd78f8  pop r10
00007aa9b5fd78fa  pop r9
00007aa9b5fd78fc  pop r8
00007aa9b5fd78fe  pop rsi
00007aa9b5fd78ff  pop rdi
00007aa9b5fd7900  pop rdx
00007aa9b5fd7901  pop rcx
00007aa9b5fd7902  pop rax
00007aa9b5fd7903  add rsp, 0x08
00007aa9b5fd7907  jmp 0x00007AA9B5FD3378
00007aa9b5fd790c  sub rsp, 0x08
00007aa9b5fd7910  push rax
00007aa9b5fd7911  push rcx
00007aa9b5fd7912  push rdx
00007aa9b5fd7913  push rdi
00007aa9b5fd7914  push rsi
00007aa9b5fd7915  push r8
00007aa9b5fd7917  push r9
00007aa9b5fd7919  push r10
00007aa9b5fd791b  push r11
00007aa9b5fd791d  sub rsp, 0xF0
00007aa9b5fd7924  vmovaps [rsp], xmm0
00007aa9b5fd7929  vmovaps [rsp+0x10], xmm1
00007aa9b5fd792f  vmovaps [rsp+0x20], xmm2
00007aa9b5fd7935  vmovaps [rsp+0x30], xmm3
00007aa9b5fd793b  vmovaps [rsp+0x40], xmm4
00007aa9b5fd7941  vmovaps [rsp+0x50], xmm5
00007aa9b5fd7947  vmovaps [rsp+0x60], xmm6
00007aa9b5fd794d  vmovaps [rsp+0x70], xmm7
00007aa9b5fd7953  vmovaps [rsp+0x80], xmm8
00007aa9b5fd795c  vmovaps [rsp+0x90], xmm9
00007aa9b5fd7965  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd796e  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd7977  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd7980  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd7989  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd7992  sub rsp, 0x30
00007aa9b5fd7996  movaps [rsp], xmm10
00007aa9b5fd799b  movaps [rsp+0x10], xmm7
00007aa9b5fd79a0  movaps [rsp+0x20], xmm12
00007aa9b5fd79a6  lea rdi, [rsp]
00007aa9b5fd79aa  mov esi, 0x00
00007aa9b5fd79af  mov rax, 0x63E0217C9530
00007aa9b5fd79b9  call rax
00007aa9b5fd79bb  movaps xmm10, [rsp]
00007aa9b5fd79c0  add rsp, 0x30
00007aa9b5fd79c4  vmovaps xmm0, [rsp]
00007aa9b5fd79c9  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd79cf  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd79d5  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd79db  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd79e1  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd79e7  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd79ed  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd79f3  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd79fc  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd7a05  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd7a0e  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd7a17  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd7a20  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd7a29  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd7a32  add rsp, 0xF0
00007aa9b5fd7a39  pop r11
00007aa9b5fd7a3b  pop r10
00007aa9b5fd7a3d  pop r9
00007aa9b5fd7a3f  pop r8
00007aa9b5fd7a41  pop rsi
00007aa9b5fd7a42  pop rdi
00007aa9b5fd7a43  pop rdx
00007aa9b5fd7a44  pop rcx
00007aa9b5fd7a45  pop rax
00007aa9b5fd7a46  add rsp, 0x08
00007aa9b5fd7a4a  jmp 0x00007AA9B5FD33A4
00007aa9b5fd7a4f  sub rsp, 0x08
00007aa9b5fd7a53  push rax
00007aa9b5fd7a54  push rcx
00007aa9b5fd7a55  push rdx
00007aa9b5fd7a56  push rdi
00007aa9b5fd7a57  push rsi
00007aa9b5fd7a58  push r8
00007aa9b5fd7a5a  push r9
00007aa9b5fd7a5c  push r10
00007aa9b5fd7a5e  push r11
00007aa9b5fd7a60  sub rsp, 0xF0
00007aa9b5fd7a67  vmovaps [rsp], xmm0
00007aa9b5fd7a6c  vmovaps [rsp+0x10], xmm1
00007aa9b5fd7a72  vmovaps [rsp+0x20], xmm2
00007aa9b5fd7a78  vmovaps [rsp+0x30], xmm3
00007aa9b5fd7a7e  vmovaps [rsp+0x40], xmm4
00007aa9b5fd7a84  vmovaps [rsp+0x50], xmm5
00007aa9b5fd7a8a  vmovaps [rsp+0x60], xmm6
00007aa9b5fd7a90  vmovaps [rsp+0x70], xmm7
00007aa9b5fd7a96  vmovaps [rsp+0x80], xmm8
00007aa9b5fd7a9f  vmovaps [rsp+0x90], xmm9
00007aa9b5fd7aa8  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd7ab1  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd7aba  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd7ac3  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd7acc  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd7ad5  sub rsp, 0x30
00007aa9b5fd7ad9  movaps [rsp], xmm12
00007aa9b5fd7ade  movaps [rsp+0x10], xmm1
00007aa9b5fd7ae3  movaps [rsp+0x20], xmm8
00007aa9b5fd7ae9  lea rdi, [rsp]
00007aa9b5fd7aed  mov esi, 0x00
00007aa9b5fd7af2  mov rax, 0x63E0217C9530
00007aa9b5fd7afc  call rax
00007aa9b5fd7afe  movaps xmm12, [rsp]
00007aa9b5fd7b03  add rsp, 0x30
00007aa9b5fd7b07  vmovaps xmm0, [rsp]
00007aa9b5fd7b0c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd7b12  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd7b18  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7b1e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd7b24  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd7b2a  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd7b30  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd7b36  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd7b3f  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd7b48  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd7b51  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd7b5a  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd7b63  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd7b6c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd7b75  add rsp, 0xF0
00007aa9b5fd7b7c  pop r11
00007aa9b5fd7b7e  pop r10
00007aa9b5fd7b80  pop r9
00007aa9b5fd7b82  pop r8
00007aa9b5fd7b84  pop rsi
00007aa9b5fd7b85  pop rdi
00007aa9b5fd7b86  pop rdx
00007aa9b5fd7b87  pop rcx
00007aa9b5fd7b88  pop rax
00007aa9b5fd7b89  add rsp, 0x08
00007aa9b5fd7b8d  jmp 0x00007AA9B5FD33BE
00007aa9b5fd7b92  call 0x00007AA9B5DFF430
00007aa9b5fd7b97  jmp 0x00007AA9B5FD33C8
00007aa9b5fd7b9c  sub rsp, 0x08
00007aa9b5fd7ba0  push rax
00007aa9b5fd7ba1  push rcx
00007aa9b5fd7ba2  push rdx
00007aa9b5fd7ba3  push rdi
00007aa9b5fd7ba4  push rsi
00007aa9b5fd7ba5  push r8
00007aa9b5fd7ba7  push r9
00007aa9b5fd7ba9  push r10
00007aa9b5fd7bab  push r11
00007aa9b5fd7bad  sub rsp, 0xF0
00007aa9b5fd7bb4  vmovaps [rsp], xmm0
00007aa9b5fd7bb9  vmovaps [rsp+0x10], xmm1
00007aa9b5fd7bbf  vmovaps [rsp+0x20], xmm2
00007aa9b5fd7bc5  vmovaps [rsp+0x30], xmm3
00007aa9b5fd7bcb  vmovaps [rsp+0x40], xmm4
00007aa9b5fd7bd1  vmovaps [rsp+0x50], xmm5
00007aa9b5fd7bd7  vmovaps [rsp+0x60], xmm6
00007aa9b5fd7bdd  vmovaps [rsp+0x70], xmm7
00007aa9b5fd7be3  vmovaps [rsp+0x80], xmm9
00007aa9b5fd7bec  vmovaps [rsp+0x90], xmm10
00007aa9b5fd7bf5  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd7bfe  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd7c07  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd7c10  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd7c19  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd7c22  sub rsp, 0x30
00007aa9b5fd7c26  movaps [rsp], xmm8
00007aa9b5fd7c2b  movaps [rsp+0x10], xmm15
00007aa9b5fd7c31  movaps [rsp+0x20], xmm9
00007aa9b5fd7c37  lea rdi, [rsp]
00007aa9b5fd7c3b  mov esi, 0x00
00007aa9b5fd7c40  mov rax, 0x63E0217C9530
00007aa9b5fd7c4a  call rax
00007aa9b5fd7c4c  movaps xmm8, [rsp]
00007aa9b5fd7c51  add rsp, 0x30
00007aa9b5fd7c55  vmovaps xmm0, [rsp]
00007aa9b5fd7c5a  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd7c60  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd7c66  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7c6c  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd7c72  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd7c78  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd7c7e  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd7c84  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd7c8d  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd7c96  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd7c9f  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd7ca8  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd7cb1  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd7cba  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd7cc3  add rsp, 0xF0
00007aa9b5fd7cca  pop r11
00007aa9b5fd7ccc  pop r10
00007aa9b5fd7cce  pop r9
00007aa9b5fd7cd0  pop r8
00007aa9b5fd7cd2  pop rsi
00007aa9b5fd7cd3  pop rdi
00007aa9b5fd7cd4  pop rdx
00007aa9b5fd7cd5  pop rcx
00007aa9b5fd7cd6  pop rax
00007aa9b5fd7cd7  add rsp, 0x08
00007aa9b5fd7cdb  jmp 0x00007AA9B5FD33EA
00007aa9b5fd7ce0  sub rsp, 0x08
00007aa9b5fd7ce4  push rax
00007aa9b5fd7ce5  push rcx
00007aa9b5fd7ce6  push rdx
00007aa9b5fd7ce7  push rdi
00007aa9b5fd7ce8  push rsi
00007aa9b5fd7ce9  push r8
00007aa9b5fd7ceb  push r9
00007aa9b5fd7ced  push r10
00007aa9b5fd7cef  push r11
00007aa9b5fd7cf1  sub rsp, 0xF0
00007aa9b5fd7cf8  vmovaps [rsp], xmm0
00007aa9b5fd7cfd  vmovaps [rsp+0x10], xmm1
00007aa9b5fd7d03  vmovaps [rsp+0x20], xmm2
00007aa9b5fd7d09  vmovaps [rsp+0x30], xmm3
00007aa9b5fd7d0f  vmovaps [rsp+0x40], xmm4
00007aa9b5fd7d15  vmovaps [rsp+0x50], xmm5
00007aa9b5fd7d1b  vmovaps [rsp+0x60], xmm6
00007aa9b5fd7d21  vmovaps [rsp+0x70], xmm7
00007aa9b5fd7d27  vmovaps [rsp+0x80], xmm8
00007aa9b5fd7d30  vmovaps [rsp+0x90], xmm10
00007aa9b5fd7d39  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd7d42  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd7d4b  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd7d54  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd7d5d  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd7d66  sub rsp, 0x30
00007aa9b5fd7d6a  movaps [rsp], xmm9
00007aa9b5fd7d6f  movaps [rsp+0x10], xmm1
00007aa9b5fd7d74  movaps [rsp+0x20], xmm15
00007aa9b5fd7d7a  lea rdi, [rsp]
00007aa9b5fd7d7e  mov esi, 0x00
00007aa9b5fd7d83  mov rax, 0x63E0217C9530
00007aa9b5fd7d8d  call rax
00007aa9b5fd7d8f  movaps xmm9, [rsp]
00007aa9b5fd7d94  add rsp, 0x30
00007aa9b5fd7d98  vmovaps xmm0, [rsp]
00007aa9b5fd7d9d  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd7da3  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd7da9  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7daf  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd7db5  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd7dbb  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd7dc1  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd7dc7  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd7dd0  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd7dd9  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd7de2  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd7deb  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd7df4  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd7dfd  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd7e06  add rsp, 0xF0
00007aa9b5fd7e0d  pop r11
00007aa9b5fd7e0f  pop r10
00007aa9b5fd7e11  pop r9
00007aa9b5fd7e13  pop r8
00007aa9b5fd7e15  pop rsi
00007aa9b5fd7e16  pop rdi
00007aa9b5fd7e17  pop rdx
00007aa9b5fd7e18  pop rcx
00007aa9b5fd7e19  pop rax
00007aa9b5fd7e1a  add rsp, 0x08
00007aa9b5fd7e1e  jmp 0x00007AA9B5FD3418
00007aa9b5fd7e23  sub rsp, 0x08
00007aa9b5fd7e27  push rax
00007aa9b5fd7e28  push rcx
00007aa9b5fd7e29  push rdx
00007aa9b5fd7e2a  push rdi
00007aa9b5fd7e2b  push rsi
00007aa9b5fd7e2c  push r8
00007aa9b5fd7e2e  push r9
00007aa9b5fd7e30  push r10
00007aa9b5fd7e32  push r11
00007aa9b5fd7e34  sub rsp, 0xF0
00007aa9b5fd7e3b  vmovaps [rsp], xmm0
00007aa9b5fd7e40  vmovaps [rsp+0x10], xmm1
00007aa9b5fd7e46  vmovaps [rsp+0x20], xmm2
00007aa9b5fd7e4c  vmovaps [rsp+0x30], xmm3
00007aa9b5fd7e52  vmovaps [rsp+0x40], xmm4
00007aa9b5fd7e58  vmovaps [rsp+0x50], xmm5
00007aa9b5fd7e5e  vmovaps [rsp+0x60], xmm6
00007aa9b5fd7e64  vmovaps [rsp+0x70], xmm7
00007aa9b5fd7e6a  vmovaps [rsp+0x80], xmm8
00007aa9b5fd7e73  vmovaps [rsp+0x90], xmm9
00007aa9b5fd7e7c  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd7e85  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd7e8e  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd7e97  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd7ea0  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd7ea9  sub rsp, 0x30
00007aa9b5fd7ead  movaps [rsp], xmm15
00007aa9b5fd7eb2  movaps [rsp+0x10], xmm4
00007aa9b5fd7eb7  movaps [rsp+0x20], xmm1
00007aa9b5fd7ebc  lea rdi, [rsp]
00007aa9b5fd7ec0  mov esi, 0x00
00007aa9b5fd7ec5  mov rax, 0x63E0217C9530
00007aa9b5fd7ecf  call rax
00007aa9b5fd7ed1  movaps xmm15, [rsp]
00007aa9b5fd7ed6  add rsp, 0x30
00007aa9b5fd7eda  vmovaps xmm0, [rsp]
00007aa9b5fd7edf  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd7ee5  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd7eeb  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd7ef1  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd7ef7  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd7efd  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd7f03  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd7f09  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd7f12  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd7f1b  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd7f24  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd7f2d  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd7f36  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd7f3f  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd7f48  add rsp, 0xF0
00007aa9b5fd7f4f  pop r11
00007aa9b5fd7f51  pop r10
00007aa9b5fd7f53  pop r9
00007aa9b5fd7f55  pop r8
00007aa9b5fd7f57  pop rsi
00007aa9b5fd7f58  pop rdi
00007aa9b5fd7f59  pop rdx
00007aa9b5fd7f5a  pop rcx
00007aa9b5fd7f5b  pop rax
00007aa9b5fd7f5c  add rsp, 0x08
00007aa9b5fd7f60  jmp 0x00007AA9B5FD343E
00007aa9b5fd7f65  sub rsp, 0x08
00007aa9b5fd7f69  push rax
00007aa9b5fd7f6a  push rcx
00007aa9b5fd7f6b  push rdx
00007aa9b5fd7f6c  push rdi
00007aa9b5fd7f6d  push rsi
00007aa9b5fd7f6e  push r8
00007aa9b5fd7f70  push r9
00007aa9b5fd7f72  push r10
00007aa9b5fd7f74  push r11
00007aa9b5fd7f76  sub rsp, 0xF0
00007aa9b5fd7f7d  vmovaps [rsp], xmm0
00007aa9b5fd7f82  vmovaps [rsp+0x10], xmm2
00007aa9b5fd7f88  vmovaps [rsp+0x20], xmm3
00007aa9b5fd7f8e  vmovaps [rsp+0x30], xmm4
00007aa9b5fd7f94  vmovaps [rsp+0x40], xmm5
00007aa9b5fd7f9a  vmovaps [rsp+0x50], xmm6
00007aa9b5fd7fa0  vmovaps [rsp+0x60], xmm7
00007aa9b5fd7fa6  vmovaps [rsp+0x70], xmm8
00007aa9b5fd7fac  vmovaps [rsp+0x80], xmm9
00007aa9b5fd7fb5  vmovaps [rsp+0x90], xmm10
00007aa9b5fd7fbe  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd7fc7  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd7fd0  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd7fd9  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd7fe2  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd7feb  sub rsp, 0x30
00007aa9b5fd7fef  movaps [rsp], xmm1
00007aa9b5fd7ff3  movaps [rsp+0x10], xmm14
00007aa9b5fd7ff9  movaps [rsp+0x20], xmm11
00007aa9b5fd7fff  lea rdi, [rsp]
00007aa9b5fd8003  mov esi, 0x00
00007aa9b5fd8008  mov rax, 0x63E0217C9530
00007aa9b5fd8012  call rax
00007aa9b5fd8014  movaps xmm1, [rsp]
00007aa9b5fd8018  add rsp, 0x30
00007aa9b5fd801c  vmovaps xmm0, [rsp]
00007aa9b5fd8021  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd8027  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd802d  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd8033  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd8039  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd803f  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd8045  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd804b  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd8054  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd805d  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd8066  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd806f  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd8078  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd8081  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd808a  add rsp, 0xF0
00007aa9b5fd8091  pop r11
00007aa9b5fd8093  pop r10
00007aa9b5fd8095  pop r9
00007aa9b5fd8097  pop r8
00007aa9b5fd8099  pop rsi
00007aa9b5fd809a  pop rdi
00007aa9b5fd809b  pop rdx
00007aa9b5fd809c  pop rcx
00007aa9b5fd809d  pop rax
00007aa9b5fd809e  add rsp, 0x08
00007aa9b5fd80a2  jmp 0x00007AA9B5FD345F
00007aa9b5fd80a7  call 0x00007AA9B5EE45A0
00007aa9b5fd80ac  jmp 0x00007AA9B5FD346D
00007aa9b5fd80b1  call 0x00007AA9B5E09D70
00007aa9b5fd80b6  jmp 0x00007AA9B5FD3477
00007aa9b5fd80bb  sub rsp, 0x08
00007aa9b5fd80bf  push rax
00007aa9b5fd80c0  push rcx
00007aa9b5fd80c1  push rdx
00007aa9b5fd80c2  push rdi
00007aa9b5fd80c3  push rsi
00007aa9b5fd80c4  push r8
00007aa9b5fd80c6  push r9
00007aa9b5fd80c8  push r10
00007aa9b5fd80ca  push r11
00007aa9b5fd80cc  sub rsp, 0xF0
00007aa9b5fd80d3  vmovaps [rsp], xmm0
00007aa9b5fd80d8  vmovaps [rsp+0x10], xmm1
00007aa9b5fd80de  vmovaps [rsp+0x20], xmm2
00007aa9b5fd80e4  vmovaps [rsp+0x30], xmm3
00007aa9b5fd80ea  vmovaps [rsp+0x40], xmm4
00007aa9b5fd80f0  vmovaps [rsp+0x50], xmm5
00007aa9b5fd80f6  vmovaps [rsp+0x60], xmm6
00007aa9b5fd80fc  vmovaps [rsp+0x70], xmm8
00007aa9b5fd8102  vmovaps [rsp+0x80], xmm9
00007aa9b5fd810b  vmovaps [rsp+0x90], xmm10
00007aa9b5fd8114  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd811d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd8126  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd812f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd8138  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd8141  sub rsp, 0x30
00007aa9b5fd8145  movaps [rsp], xmm7
00007aa9b5fd8149  movaps [rsp+0x10], xmm13
00007aa9b5fd814f  movaps [rsp+0x20], xmm10
00007aa9b5fd8155  lea rdi, [rsp]
00007aa9b5fd8159  mov esi, 0x00
00007aa9b5fd815e  mov rax, 0x63E0217C9530
00007aa9b5fd8168  call rax
00007aa9b5fd816a  movaps xmm7, [rsp]
00007aa9b5fd816e  add rsp, 0x30
00007aa9b5fd8172  vmovaps xmm0, [rsp]
00007aa9b5fd8177  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd817d  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd8183  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd8189  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd818f  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd8195  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd819b  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd81a1  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd81aa  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd81b3  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd81bc  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd81c5  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd81ce  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd81d7  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd81e0  add rsp, 0xF0
00007aa9b5fd81e7  pop r11
00007aa9b5fd81e9  pop r10
00007aa9b5fd81eb  pop r9
00007aa9b5fd81ed  pop r8
00007aa9b5fd81ef  pop rsi
00007aa9b5fd81f0  pop rdi
00007aa9b5fd81f1  pop rdx
00007aa9b5fd81f2  pop rcx
00007aa9b5fd81f3  pop rax
00007aa9b5fd81f4  add rsp, 0x08
00007aa9b5fd81f8  jmp 0x00007AA9B5FD3498
00007aa9b5fd81fd  sub rsp, 0x08
00007aa9b5fd8201  push rax
00007aa9b5fd8202  push rcx
00007aa9b5fd8203  push rdx
00007aa9b5fd8204  push rdi
00007aa9b5fd8205  push rsi
00007aa9b5fd8206  push r8
00007aa9b5fd8208  push r9
00007aa9b5fd820a  push r10
00007aa9b5fd820c  push r11
00007aa9b5fd820e  sub rsp, 0xF0
00007aa9b5fd8215  vmovaps [rsp], xmm0
00007aa9b5fd821a  vmovaps [rsp+0x10], xmm1
00007aa9b5fd8220  vmovaps [rsp+0x20], xmm2
00007aa9b5fd8226  vmovaps [rsp+0x30], xmm3
00007aa9b5fd822c  vmovaps [rsp+0x40], xmm4
00007aa9b5fd8232  vmovaps [rsp+0x50], xmm5
00007aa9b5fd8238  vmovaps [rsp+0x60], xmm6
00007aa9b5fd823e  vmovaps [rsp+0x70], xmm7
00007aa9b5fd8244  vmovaps [rsp+0x80], xmm8
00007aa9b5fd824d  vmovaps [rsp+0x90], xmm9
00007aa9b5fd8256  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd825f  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd8268  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd8271  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd827a  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd8283  sub rsp, 0x30
00007aa9b5fd8287  movaps [rsp], xmm10
00007aa9b5fd828c  movaps [rsp+0x10], xmm11
00007aa9b5fd8292  movaps [rsp+0x20], xmm13
00007aa9b5fd8298  lea rdi, [rsp]
00007aa9b5fd829c  mov esi, 0x00
00007aa9b5fd82a1  mov rax, 0x63E0217C9530
00007aa9b5fd82ab  call rax
00007aa9b5fd82ad  movaps xmm10, [rsp]
00007aa9b5fd82b2  add rsp, 0x30
00007aa9b5fd82b6  vmovaps xmm0, [rsp]
00007aa9b5fd82bb  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd82c1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd82c7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd82cd  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd82d3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd82d9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd82df  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd82e5  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd82ee  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd82f7  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd8300  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd8309  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd8312  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd831b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd8324  add rsp, 0xF0
00007aa9b5fd832b  pop r11
00007aa9b5fd832d  pop r10
00007aa9b5fd832f  pop r9
00007aa9b5fd8331  pop r8
00007aa9b5fd8333  pop rsi
00007aa9b5fd8334  pop rdi
00007aa9b5fd8335  pop rdx
00007aa9b5fd8336  pop rcx
00007aa9b5fd8337  pop rax
00007aa9b5fd8338  add rsp, 0x08
00007aa9b5fd833c  jmp 0x00007AA9B5FD34C6
00007aa9b5fd8341  sub rsp, 0x08
00007aa9b5fd8345  push rax
00007aa9b5fd8346  push rcx
00007aa9b5fd8347  push rdx
00007aa9b5fd8348  push rdi
00007aa9b5fd8349  push rsi
00007aa9b5fd834a  push r8
00007aa9b5fd834c  push r9
00007aa9b5fd834e  push r10
00007aa9b5fd8350  push r11
00007aa9b5fd8352  sub rsp, 0xF0
00007aa9b5fd8359  vmovaps [rsp], xmm0
00007aa9b5fd835e  vmovaps [rsp+0x10], xmm1
00007aa9b5fd8364  vmovaps [rsp+0x20], xmm2
00007aa9b5fd836a  vmovaps [rsp+0x30], xmm3
00007aa9b5fd8370  vmovaps [rsp+0x40], xmm4
00007aa9b5fd8376  vmovaps [rsp+0x50], xmm5
00007aa9b5fd837c  vmovaps [rsp+0x60], xmm6
00007aa9b5fd8382  vmovaps [rsp+0x70], xmm7
00007aa9b5fd8388  vmovaps [rsp+0x80], xmm8
00007aa9b5fd8391  vmovaps [rsp+0x90], xmm9
00007aa9b5fd839a  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd83a3  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd83ac  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd83b5  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd83be  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd83c7  sub rsp, 0x30
00007aa9b5fd83cb  movaps [rsp], xmm11
00007aa9b5fd83d0  movaps [rsp+0x10], xmm14
00007aa9b5fd83d6  movaps [rsp+0x20], xmm13
00007aa9b5fd83dc  lea rdi, [rsp]
00007aa9b5fd83e0  mov esi, 0x00
00007aa9b5fd83e5  mov rax, 0x63E0217C9530
00007aa9b5fd83ef  call rax
00007aa9b5fd83f1  movaps xmm11, [rsp]
00007aa9b5fd83f6  add rsp, 0x30
00007aa9b5fd83fa  vmovaps xmm0, [rsp]
00007aa9b5fd83ff  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd8405  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd840b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd8411  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd8417  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd841d  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd8423  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd8429  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd8432  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd843b  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd8444  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd844d  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd8456  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd845f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd8468  add rsp, 0xF0
00007aa9b5fd846f  pop r11
00007aa9b5fd8471  pop r10
00007aa9b5fd8473  pop r9
00007aa9b5fd8475  pop r8
00007aa9b5fd8477  pop rsi
00007aa9b5fd8478  pop rdi
00007aa9b5fd8479  pop rdx
00007aa9b5fd847a  pop rcx
00007aa9b5fd847b  pop rax
00007aa9b5fd847c  add rsp, 0x08
00007aa9b5fd8480  jmp 0x00007AA9B5FD34F4
00007aa9b5fd8485  sub rsp, 0x08
00007aa9b5fd8489  push rax
00007aa9b5fd848a  push rcx
00007aa9b5fd848b  push rdx
00007aa9b5fd848c  push rdi
00007aa9b5fd848d  push rsi
00007aa9b5fd848e  push r8
00007aa9b5fd8490  push r9
00007aa9b5fd8492  push r10
00007aa9b5fd8494  push r11
00007aa9b5fd8496  sub rsp, 0xF0
00007aa9b5fd849d  vmovaps [rsp], xmm0
00007aa9b5fd84a2  vmovaps [rsp+0x10], xmm1
00007aa9b5fd84a8  vmovaps [rsp+0x20], xmm2
00007aa9b5fd84ae  vmovaps [rsp+0x30], xmm3
00007aa9b5fd84b4  vmovaps [rsp+0x40], xmm4
00007aa9b5fd84ba  vmovaps [rsp+0x50], xmm5
00007aa9b5fd84c0  vmovaps [rsp+0x60], xmm6
00007aa9b5fd84c6  vmovaps [rsp+0x70], xmm7
00007aa9b5fd84cc  vmovaps [rsp+0x80], xmm8
00007aa9b5fd84d5  vmovaps [rsp+0x90], xmm9
00007aa9b5fd84de  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd84e7  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd84f0  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd84f9  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd8502  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd850b  sub rsp, 0x30
00007aa9b5fd850f  movaps [rsp], xmm14
00007aa9b5fd8514  movaps [rsp+0x10], xmm12
00007aa9b5fd851a  movaps [rsp+0x20], xmm9
00007aa9b5fd8520  lea rdi, [rsp]
00007aa9b5fd8524  mov esi, 0x00
00007aa9b5fd8529  mov rax, 0x63E0217C9530
00007aa9b5fd8533  call rax
00007aa9b5fd8535  movaps xmm14, [rsp]
00007aa9b5fd853a  add rsp, 0x30
00007aa9b5fd853e  vmovaps xmm0, [rsp]
00007aa9b5fd8543  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd8549  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd854f  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd8555  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd855b  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd8561  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd8567  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd856d  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd8576  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd857f  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd8588  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd8591  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd859a  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd85a3  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd85ac  add rsp, 0xF0
00007aa9b5fd85b3  pop r11
00007aa9b5fd85b5  pop r10
00007aa9b5fd85b7  pop r9
00007aa9b5fd85b9  pop r8
00007aa9b5fd85bb  pop rsi
00007aa9b5fd85bc  pop rdi
00007aa9b5fd85bd  pop rdx
00007aa9b5fd85be  pop rcx
00007aa9b5fd85bf  pop rax
00007aa9b5fd85c0  add rsp, 0x08
00007aa9b5fd85c4  jmp 0x00007AA9B5FD350F
00007aa9b5fd85c9  sub rsp, 0x08
00007aa9b5fd85cd  push rax
00007aa9b5fd85ce  push rcx
00007aa9b5fd85cf  push rdx
00007aa9b5fd85d0  push rdi
00007aa9b5fd85d1  push rsi
00007aa9b5fd85d2  push r8
00007aa9b5fd85d4  push r9
00007aa9b5fd85d6  push r10
00007aa9b5fd85d8  push r11
00007aa9b5fd85da  sub rsp, 0xF0
00007aa9b5fd85e1  vmovaps [rsp], xmm0
00007aa9b5fd85e6  vmovaps [rsp+0x10], xmm1
00007aa9b5fd85ec  vmovaps [rsp+0x20], xmm2
00007aa9b5fd85f2  vmovaps [rsp+0x30], xmm3
00007aa9b5fd85f8  vmovaps [rsp+0x40], xmm4
00007aa9b5fd85fe  vmovaps [rsp+0x50], xmm5
00007aa9b5fd8604  vmovaps [rsp+0x60], xmm6
00007aa9b5fd860a  vmovaps [rsp+0x70], xmm7
00007aa9b5fd8610  vmovaps [rsp+0x80], xmm8
00007aa9b5fd8619  vmovaps [rsp+0x90], xmm9
00007aa9b5fd8622  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd862b  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd8634  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd863d  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd8646  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd864f  sub rsp, 0x30
00007aa9b5fd8653  movaps [rsp], xmm13
00007aa9b5fd8658  movaps [rsp+0x10], xmm8
00007aa9b5fd865e  movaps [rsp+0x20], xmm15
00007aa9b5fd8664  lea rdi, [rsp]
00007aa9b5fd8668  mov esi, 0x00
00007aa9b5fd866d  mov rax, 0x63E0217C9530
00007aa9b5fd8677  call rax
00007aa9b5fd8679  movaps xmm13, [rsp]
00007aa9b5fd867e  add rsp, 0x30
00007aa9b5fd8682  vmovaps xmm0, [rsp]
00007aa9b5fd8687  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd868d  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd8693  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd8699  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd869f  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd86a5  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd86ab  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd86b1  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd86ba  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd86c3  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd86cc  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd86d5  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd86de  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd86e7  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd86f0  add rsp, 0xF0
00007aa9b5fd86f7  pop r11
00007aa9b5fd86f9  pop r10
00007aa9b5fd86fb  pop r9
00007aa9b5fd86fd  pop r8
00007aa9b5fd86ff  pop rsi
00007aa9b5fd8700  pop rdi
00007aa9b5fd8701  pop rdx
00007aa9b5fd8702  pop rcx
00007aa9b5fd8703  pop rax
00007aa9b5fd8704  add rsp, 0x08
00007aa9b5fd8708  jmp 0x00007AA9B5FD3532
00007aa9b5fd870d  sub rsp, 0x08
00007aa9b5fd8711  push rax
00007aa9b5fd8712  push rcx
00007aa9b5fd8713  push rdx
00007aa9b5fd8714  push rdi
00007aa9b5fd8715  push rsi
00007aa9b5fd8716  push r8
00007aa9b5fd8718  push r9
00007aa9b5fd871a  push r10
00007aa9b5fd871c  push r11
00007aa9b5fd871e  sub rsp, 0xF0
00007aa9b5fd8725  vmovaps [rsp], xmm0
00007aa9b5fd872a  vmovaps [rsp+0x10], xmm1
00007aa9b5fd8730  vmovaps [rsp+0x20], xmm2
00007aa9b5fd8736  vmovaps [rsp+0x30], xmm3
00007aa9b5fd873c  vmovaps [rsp+0x40], xmm4
00007aa9b5fd8742  vmovaps [rsp+0x50], xmm5
00007aa9b5fd8748  vmovaps [rsp+0x60], xmm6
00007aa9b5fd874e  vmovaps [rsp+0x70], xmm7
00007aa9b5fd8754  vmovaps [rsp+0x80], xmm8
00007aa9b5fd875d  vmovaps [rsp+0x90], xmm9
00007aa9b5fd8766  vmovaps [rsp+0xA0], xmm10
00007aa9b5fd876f  vmovaps [rsp+0xB0], xmm11
00007aa9b5fd8778  vmovaps [rsp+0xC0], xmm12
00007aa9b5fd8781  vmovaps [rsp+0xD0], xmm13
00007aa9b5fd878a  vmovaps [rsp+0xE0], xmm14
00007aa9b5fd8793  sub rsp, 0x30
00007aa9b5fd8797  movaps [rsp], xmm15
00007aa9b5fd879c  movaps [rsp+0x10], xmm1
00007aa9b5fd87a1  movaps [rsp+0x20], xmm10
00007aa9b5fd87a7  lea rdi, [rsp]
00007aa9b5fd87ab  mov esi, 0x00
00007aa9b5fd87b0  mov rax, 0x63E0217C9530
00007aa9b5fd87ba  call rax
00007aa9b5fd87bc  movaps xmm15, [rsp]
00007aa9b5fd87c1  add rsp, 0x30
00007aa9b5fd87c5  vmovaps xmm0, [rsp]
00007aa9b5fd87ca  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd87d0  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd87d6  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd87dc  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd87e2  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd87e8  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd87ee  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd87f4  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd87fd  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd8806  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fd880f  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fd8818  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fd8821  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fd882a  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fd8833  add rsp, 0xF0
00007aa9b5fd883a  pop r11
00007aa9b5fd883c  pop r10
00007aa9b5fd883e  pop r9
00007aa9b5fd8840  pop r8
00007aa9b5fd8842  pop rsi
00007aa9b5fd8843  pop rdi
00007aa9b5fd8844  pop rdx
00007aa9b5fd8845  pop rcx
00007aa9b5fd8846  pop rax
00007aa9b5fd8847  add rsp, 0x08
00007aa9b5fd884b  jmp 0x00007AA9B5FD3555
00007aa9b5fd8850  sub rsp, 0x08
00007aa9b5fd8854  push rax
00007aa9b5fd8855  push rcx
00007aa9b5fd8856  push rdx
00007aa9b5fd8857  push rdi
00007aa9b5fd8858  push rsi
00007aa9b5fd8859  push r8
00007aa9b5fd885b  push r9
00007aa9b5fd885d  push r10
00007aa9b5fd885f  push r11
00007aa9b5fd8861  sub rsp, 0xF0
00007aa9b5fd8868  vmovaps [rsp], xmm0
00007aa9b5fd886d  vmovaps [rsp+0x10], xmm2
00007aa9b5fd8873  vmovaps [rsp+0x20], xmm3
00007aa9b5fd8879  vmovaps [rsp+0x30], xmm4
00007aa9b5fd887f  vmovaps [rsp+0x40], xmm5
00007aa9b5fd8885  vmovaps [rsp+0x50], xmm6
00007aa9b5fd888b  vmovaps [rsp+0x60], xmm7
00007aa9b5fd8891  vmovaps [rsp+0x70], xmm8
00007aa9b5fd8897  vmovaps [rsp+0x80], xmm9
00007aa9b5fd88a0  vmovaps [rsp+0x90], xmm10
00007aa9b5fd88a9  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd88b2  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd88bb  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd88c4  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd88cd  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd88d6  sub rsp, 0x30
00007aa9b5fd88da  movaps [rsp], xmm1
00007aa9b5fd88de  movaps [rsp+0x10], xmm7
00007aa9b5fd88e3  movaps [rsp+0x20], xmm11
00007aa9b5fd88e9  lea rdi, [rsp]
00007aa9b5fd88ed  mov esi, 0x00
00007aa9b5fd88f2  mov rax, 0x63E0217C9530
00007aa9b5fd88fc  call rax
00007aa9b5fd88fe  movaps xmm1, [rsp]
00007aa9b5fd8902  add rsp, 0x30
00007aa9b5fd8906  vmovaps xmm0, [rsp]
00007aa9b5fd890b  vmovaps xmm2, [rsp+0x10]
00007aa9b5fd8911  vmovaps xmm3, [rsp+0x20]
00007aa9b5fd8917  vmovaps xmm4, [rsp+0x30]
00007aa9b5fd891d  vmovaps xmm5, [rsp+0x40]
00007aa9b5fd8923  vmovaps xmm6, [rsp+0x50]
00007aa9b5fd8929  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd892f  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd8935  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd893e  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd8947  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd8950  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd8959  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd8962  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd896b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd8974  add rsp, 0xF0
00007aa9b5fd897b  pop r11
00007aa9b5fd897d  pop r10
00007aa9b5fd897f  pop r9
00007aa9b5fd8981  pop r8
00007aa9b5fd8983  pop rsi
00007aa9b5fd8984  pop rdi
00007aa9b5fd8985  pop rdx
00007aa9b5fd8986  pop rcx
00007aa9b5fd8987  pop rax
00007aa9b5fd8988  add rsp, 0x08
00007aa9b5fd898c  jmp 0x00007AA9B5FD3576
00007aa9b5fd8991  call 0x00007AA9B5E0D600
00007aa9b5fd8996  jmp 0x00007AA9B5FD3589
00007aa9b5fd899b  call 0x00007AA9B5E0C380
00007aa9b5fd89a0  jmp 0x00007AA9B5FD3594
00007aa9b5fd89a5  call 0x00007AA9B5E0E880
00007aa9b5fd89aa  jmp 0x00007AA9B5FD359F
00007aa9b5fd89af  call 0x00007AA9B5DFF540
00007aa9b5fd89b4  jmp 0x00007AA9B5FD35AA
00007aa9b5fd89b9  int3
00007aa9b5fd89ba  nop [rax+rax*1], ax
00007aa9b5fd89c0  mov rax, [r15+0x40]
00007aa9b5fd89c4  mov r14, [r15+0x58]
00007aa9b5fd89c8  lea r12, [rax+r14*1]
00007aa9b5fd89cc  movaps xmm1, [r15+0x1D0]
00007aa9b5fd89d4  vmovaps [rsp+0x10], xmm1
00007aa9b5fd89da  vmovaps xmm15, [rsp+0x10]
00007aa9b5fd89e0  por xmm1, xmm15
00007aa9b5fd89e5  movaps xmm14, [r15+0x1A0]
00007aa9b5fd89ed  vmovaps [rsp+0x10], xmm14
00007aa9b5fd89f3  vmovaps xmm13, [rsp+0x10]
00007aa9b5fd89f9  por xmm14, xmm13
00007aa9b5fd89fe  lea rax, [r12+0x30]
00007aa9b5fd8a03  mov r11, [r13+rax*1]
00007aa9b5fd8a08  lea rax, [r12+0x38]
00007aa9b5fd8a0d  mov r10, [r13+rax*1]
00007aa9b5fd8a12  movq xmm13, r11
00007aa9b5fd8a17  movq xmm12, r10
00007aa9b5fd8a1c  movq xmm13, xmm13
00007aa9b5fd8a21  vmovaps [rsp+0x10], xmm13
00007aa9b5fd8a27  movq xmm13, xmm13
00007aa9b5fd8a2c  movaps [r15+0x130], xmm13
00007aa9b5fd8a34  movq xmm12, xmm12
00007aa9b5fd8a39  vmovaps [rsp+0x20], xmm12
00007aa9b5fd8a3f  movq xmm12, xmm12
00007aa9b5fd8a44  movaps [r15+0x280], xmm12
00007aa9b5fd8a4c  movaps xmm13, [r15+0x270]
00007aa9b5fd8a54  vmovaps [rsp+0x30], xmm13
00007aa9b5fd8a5a  vmovaps xmm12, [rsp+0x30]
00007aa9b5fd8a60  por xmm13, xmm12
00007aa9b5fd8a65  lea rax, [r12+0x20]
00007aa9b5fd8a6a  mov r11, [r13+rax*1]
00007aa9b5fd8a6f  lea rax, [r12+0x28]
00007aa9b5fd8a74  mov r10, [r13+rax*1]
00007aa9b5fd8a79  movq xmm12, r11
00007aa9b5fd8a7e  movq xmm11, r10
00007aa9b5fd8a83  movq xmm12, xmm12
00007aa9b5fd8a88  vmovaps [rsp+0x30], xmm12
00007aa9b5fd8a8e  movq xmm12, xmm12
00007aa9b5fd8a93  movaps [r15+0x150], xmm12
00007aa9b5fd8a9b  movq xmm11, xmm11
00007aa9b5fd8aa0  vmovaps [rsp+0x40], xmm11
00007aa9b5fd8aa6  movq xmm11, xmm11
00007aa9b5fd8aab  movaps [r15+0x140], xmm11
00007aa9b5fd8ab3  lea rax, [r12+0x10]
00007aa9b5fd8ab8  mov r11, [r13+rax*1]
00007aa9b5fd8abd  lea rax, [r12+0x18]
00007aa9b5fd8ac2  mov r10, [r13+rax*1]
00007aa9b5fd8ac7  movq xmm12, r11
00007aa9b5fd8acc  movq xmm11, r10
00007aa9b5fd8ad1  movq xmm12, xmm12
00007aa9b5fd8ad6  vmovaps [rsp+0x50], xmm12
00007aa9b5fd8adc  movq xmm12, xmm12
00007aa9b5fd8ae1  movaps [r15+0x170], xmm12
00007aa9b5fd8ae9  movq xmm11, xmm11
00007aa9b5fd8aee  vmovaps [rsp+0x60], xmm11
00007aa9b5fd8af4  movq xmm11, xmm11
00007aa9b5fd8af9  movaps [r15+0x160], xmm11
00007aa9b5fd8b01  mov rax, [r13+r12*1]
00007aa9b5fd8b06  vmovq xmm12, rax
00007aa9b5fd8b0b  vpbroadcastq xmm12, xmm12
00007aa9b5fd8b10  lea rax, [r12+0x08]
00007aa9b5fd8b15  mov r12, [r13+rax*1]
00007aa9b5fd8b1a  movq xmm11, r12
00007aa9b5fd8b1f  movaps [r15+0x230], xmm11
00007aa9b5fd8b27  mov rax, [r15+0xF8]
00007aa9b5fd8b2e  lea r12, [rax+0x50]
00007aa9b5fd8b32  movups xmm11, [r13+r12*1]
00007aa9b5fd8b38  lea r12, [rax+0x60]
00007aa9b5fd8b3c  movups xmm10, [r13+r12*1]
00007aa9b5fd8b42  lea r12, [rax+0x30]
00007aa9b5fd8b46  movups xmm9, [r13+r12*1]
00007aa9b5fd8b4c  mov r12, [r15+0x50]
00007aa9b5fd8b50  lea r11, [r12+r14*1]
00007aa9b5fd8b54  mov [r15+0x60], r11
00007aa9b5fd8b58  lea r12, [r14+0x40]
00007aa9b5fd8b5c  mov [r15+0x58], r12
00007aa9b5fd8b60  movaps xmm8, xmm12
00007aa9b5fd8b64  mulpd xmm8, xmm15
00007aa9b5fd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa9b5fd8b6f  ptest xmm7, xmm7
00007aa9b5fd8b74  jnz 0x00007AA9B5FD9997
00007aa9b5fd8b7a  movq xmm15, qword ptr [r15+0x230]
00007aa9b5fd8b83  vmovaps [rsp+0x70], xmm15
00007aa9b5fd8b89  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd8b8f  movaps xmm7, xmm9
00007aa9b5fd8b93  mulpd xmm7, xmm15
00007aa9b5fd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa9b5fd8b9d  ptest xmm6, xmm6
00007aa9b5fd8ba2  jnz 0x00007AA9B5FD9ADB
00007aa9b5fd8ba8  vxorps xmm15, xmm15, xmm15
00007aa9b5fd8bad  vpbroadcastq xmm15, xmm15
00007aa9b5fd8bb2  movaps xmm9, xmm12
00007aa9b5fd8bb6  mulpd xmm9, xmm10
00007aa9b5fd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa9b5fd8bc1  ptest xmm6, xmm6
00007aa9b5fd8bc6  jnz 0x00007AA9B5FD9C1D
00007aa9b5fd8bcc  movaps xmm10, xmm12
00007aa9b5fd8bd0  mulpd xmm10, xmm11
00007aa9b5fd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007aa9b5fd8bdb  ptest xmm6, xmm6
00007aa9b5fd8be0  jnz 0x00007AA9B5FD9D61
00007aa9b5fd8be6  movaps xmm11, [r15+0x1F0]
00007aa9b5fd8bee  movaps xmm6, xmm12
00007aa9b5fd8bf2  mulpd xmm6, xmm11
00007aa9b5fd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa9b5fd8bfc  ptest xmm5, xmm5
00007aa9b5fd8c01  jnz 0x00007AA9B5FD9EA5
00007aa9b5fd8c07  movaps xmm12, [r15+0x2A0]
00007aa9b5fd8c0f  vmovaps [rsp+0x80], xmm12
00007aa9b5fd8c18  vmovaps xmm11, [rsp+0x80]
00007aa9b5fd8c21  por xmm12, xmm11
00007aa9b5fd8c26  movaps xmm11, [r15+0x250]
00007aa9b5fd8c2e  vmovaps [rsp+0x80], xmm11
00007aa9b5fd8c37  vmovaps xmm5, [rsp+0x80]
00007aa9b5fd8c40  por xmm11, xmm5
00007aa9b5fd8c45  vmovaps xmm4, [rsp+0x70]
00007aa9b5fd8c4b  vpermilpd xmm4, xmm4, 0x00
00007aa9b5fd8c51  movaps xmm3, xmm5
00007aa9b5fd8c54  mulpd xmm3, xmm4
00007aa9b5fd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007aa9b5fd8c5d  ptest xmm2, xmm2
00007aa9b5fd8c62  jnz 0x00007AA9B5FD9FE7
00007aa9b5fd8c68  mov [rsp+0x80], rax
00007aa9b5fd8c70  xor eax, eax
00007aa9b5fd8c72  mov r14d, 0x200
00007aa9b5fd8c78  cmp r12, r14
00007aa9b5fd8c7b  cmc
00007aa9b5fd8c7c  lahf
00007aa9b5fd8c7d  seto al
00007aa9b5fd8c80  mov [r15+0x108], eax
00007aa9b5fd8c87  movaps xmm5, xmm8
00007aa9b5fd8c8b  addpd xmm5, xmm15
00007aa9b5fd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007aa9b5fd8c95  ptest xmm4, xmm4
00007aa9b5fd8c9a  jnz 0x00007AA9B5FDA127
00007aa9b5fd8ca0  movaps xmm8, [r15+0x1B0]
00007aa9b5fd8ca8  movaps xmm4, xmm9
00007aa9b5fd8cac  addpd xmm4, xmm8
00007aa9b5fd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007aa9b5fd8cb6  ptest xmm2, xmm2
00007aa9b5fd8cbb  jnz 0x00007AA9B5FDA269
00007aa9b5fd8cc1  movaps xmm9, xmm10
00007aa9b5fd8cc5  addpd xmm9, xmm8
00007aa9b5fd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007aa9b5fd8cd0  ptest xmm2, xmm2
00007aa9b5fd8cd5  jnz 0x00007AA9B5FDA3AB
00007aa9b5fd8cdb  movaps xmm10, [r15+0x2F0]
00007aa9b5fd8ce3  vmovaps [rsp+0x90], xmm10
00007aa9b5fd8cec  vmovaps xmm8, [rsp+0x90]
00007aa9b5fd8cf5  por xmm10, xmm8
00007aa9b5fd8cfa  movaps xmm8, [r15+0x2E0]
00007aa9b5fd8d02  vmovaps [rsp+0x90], xmm8
00007aa9b5fd8d0b  vmovaps xmm2, [rsp+0x90]
00007aa9b5fd8d14  por xmm8, xmm2
00007aa9b5fd8d19  movaps xmm2, [r15+0x2D0]
00007aa9b5fd8d21  vmovaps [rsp+0x90], xmm2
00007aa9b5fd8d2a  vmovaps [rsp+0xA0], xmm1
00007aa9b5fd8d33  vmovaps xmm1, [rsp+0x90]
00007aa9b5fd8d3c  por xmm2, xmm1
00007aa9b5fd8d40  movaps xmm1, [r15+0x200]
00007aa9b5fd8d48  vmovaps [rsp+0x90], xmm1
00007aa9b5fd8d51  vmovaps [rsp+0xB0], xmm15
00007aa9b5fd8d5a  vmovaps xmm15, [rsp+0x90]
00007aa9b5fd8d63  por xmm1, xmm15
00007aa9b5fd8d68  movaps xmm15, [r15+0x1C0]
00007aa9b5fd8d70  vmovaps [rsp+0x90], xmm15
00007aa9b5fd8d79  vmovaps [rsp+0xC0], xmm1
00007aa9b5fd8d82  vmovaps xmm1, [rsp+0x90]
00007aa9b5fd8d8b  por xmm15, xmm1
00007aa9b5fd8d90  movaps xmm1, [r15+0x190]
00007aa9b5fd8d98  vmovaps [rsp+0x90], xmm1
00007aa9b5fd8da1  vmovaps [rsp+0xD0], xmm15
00007aa9b5fd8daa  vmovaps xmm15, [rsp+0x90]
00007aa9b5fd8db3  por xmm1, xmm15
00007aa9b5fd8db8  movaps xmm15, [r15+0x300]
00007aa9b5fd8dc0  vmovaps [rsp+0x90], xmm15
00007aa9b5fd8dc9  vmovaps [rsp+0xE0], xmm1
00007aa9b5fd8dd2  vmovaps xmm1, [rsp+0x90]
00007aa9b5fd8ddb  por xmm15, xmm1
00007aa9b5fd8de0  mov rax, [rsp+0x80]
00007aa9b5fd8de8  lea r14, [rax+0xA0]
00007aa9b5fd8def  movups xmm1, [r13+r14*1]
00007aa9b5fd8df5  lea r14, [rax+0xB0]
00007aa9b5fd8dfc  vmovaps [rsp+0x80], xmm1
00007aa9b5fd8e05  movups xmm1, [r13+r14*1]
00007aa9b5fd8e0b  vmovaps [rsp+0x90], xmm1
00007aa9b5fd8e14  vmovaps [rsp+0xF0], xmm15
00007aa9b5fd8e1d  vmovaps xmm15, [rsp+0xB0]
00007aa9b5fd8e26  vmovaps [rsp+0xB0], xmm14
00007aa9b5fd8e2f  movaps xmm1, xmm6
00007aa9b5fd8e32  addpd xmm1, xmm15
00007aa9b5fd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa9b5fd8e3c  ptest xmm14, xmm14
00007aa9b5fd8e42  jnz 0x00007AA9B5FDA503
00007aa9b5fd8e48  lea r14, [rax+0xF0]
00007aa9b5fd8e4f  movups xmm15, [r13+r14*1]
00007aa9b5fd8e55  movaps xmm14, xmm4
00007aa9b5fd8e59  addpd xmm14, xmm3
00007aa9b5fd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa9b5fd8e64  ptest xmm6, xmm6
00007aa9b5fd8e69  jnz 0x00007AA9B5FDA64E
00007aa9b5fd8e6f  movaps xmm6, xmm9
00007aa9b5fd8e73  addpd xmm6, xmm7
00007aa9b5fd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007aa9b5fd8e7c  ptest xmm4, xmm4
00007aa9b5fd8e81  jnz 0x00007AA9B5FDA790
00007aa9b5fd8e87  vmovaps xmm9, [rsp+0x70]
00007aa9b5fd8e8d  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fd8e93  vmovaps xmm4, [rsp+0x90]
00007aa9b5fd8e9c  movaps xmm7, xmm4
00007aa9b5fd8e9f  mulpd xmm7, xmm9
00007aa9b5fd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007aa9b5fd8ea9  ptest xmm3, xmm3
00007aa9b5fd8eae  jnz 0x00007AA9B5FDA8D1
00007aa9b5fd8eb4  vmovaps xmm9, [rsp+0x50]
00007aa9b5fd8eba  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fd8ec0  movaps xmm4, xmm15
00007aa9b5fd8ec4  mulpd xmm4, xmm9
00007aa9b5fd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007aa9b5fd8ece  ptest xmm3, xmm3
00007aa9b5fd8ed3  jnz 0x00007AA9B5FDAA12
00007aa9b5fd8ed9  lea r14, [rax+0xE0]
00007aa9b5fd8ee0  movups xmm15, [r13+r14*1]
00007aa9b5fd8ee6  vmovaps xmm9, [rsp+0x70]
00007aa9b5fd8eec  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fd8ef2  vmovaps [rsp+0x70], xmm1
00007aa9b5fd8ef8  vmovaps xmm1, [rsp+0x80]
00007aa9b5fd8f01  vmovaps [rsp+0x80], xmm15
00007aa9b5fd8f0a  movaps xmm3, xmm1
00007aa9b5fd8f0d  mulpd xmm3, xmm9
00007aa9b5fd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007aa9b5fd8f17  ptest xmm15, xmm15
00007aa9b5fd8f1d  jnz 0x00007AA9B5FDAB5E
00007aa9b5fd8f23  vmovaps xmm1, [rsp+0xF0]
00007aa9b5fd8f2c  vmovaps xmm15, [rsp+0xF0]
00007aa9b5fd8f35  por xmm1, xmm15
00007aa9b5fd8f3a  movaps [r15+0x300], xmm1
00007aa9b5fd8f42  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd8f4b  vmovaps xmm9, [rsp+0xE0]
00007aa9b5fd8f54  por xmm15, xmm9
00007aa9b5fd8f59  movaps [r15+0x190], xmm15
00007aa9b5fd8f61  vmovaps xmm9, [rsp+0x50]
00007aa9b5fd8f67  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fd8f6d  vmovaps [rsp+0x90], xmm1
00007aa9b5fd8f76  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd8f7f  vmovaps xmm15, [rsp+0x80]
00007aa9b5fd8f88  vmovaps [rsp+0x80], xmm14
00007aa9b5fd8f91  movaps xmm1, xmm15
00007aa9b5fd8f95  mulpd xmm1, xmm9
00007aa9b5fd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa9b5fd8f9f  ptest xmm14, xmm14
00007aa9b5fd8fa5  jnz 0x00007AA9B5FDAC9F
00007aa9b5fd8fab  lea r14, [rax+0x90]
00007aa9b5fd8fb2  movups xmm15, [r13+r14*1]
00007aa9b5fd8fb8  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd8fc1  vmovaps xmm9, [rsp+0xD0]
00007aa9b5fd8fca  por xmm14, xmm9
00007aa9b5fd8fcf  movaps [r15+0x1C0], xmm14
00007aa9b5fd8fd7  vmovaps xmm9, [rsp+0xC0]
00007aa9b5fd8fe0  vmovaps [rsp+0xD0], xmm1
00007aa9b5fd8fe9  vmovaps xmm1, [rsp+0xC0]
00007aa9b5fd8ff2  por xmm9, xmm1
00007aa9b5fd8ff7  movaps [r15+0x200], xmm9
00007aa9b5fd8fff  vmovaps [rsp+0xC0], xmm2
00007aa9b5fd9008  vmovaps xmm1, [rsp+0xC0]
00007aa9b5fd9011  por xmm2, xmm1
00007aa9b5fd9015  movaps [r15+0x2D0], xmm2
00007aa9b5fd901d  vmovaps [rsp+0xC0], xmm8
00007aa9b5fd9026  vmovaps xmm1, [rsp+0xC0]
00007aa9b5fd902f  por xmm8, xmm1
00007aa9b5fd9034  movaps [r15+0x2E0], xmm8
00007aa9b5fd903c  vmovaps [rsp+0xC0], xmm15
00007aa9b5fd9045  movaps xmm1, xmm5
00007aa9b5fd9048  addpd xmm1, xmm7
00007aa9b5fd904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa9b5fd9051  ptest xmm15, xmm15
00007aa9b5fd9057  jnz 0x00007AA9B5FDADEB
00007aa9b5fd905d  vmovaps xmm15, [rsp+0x50]
00007aa9b5fd9063  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd9069  vmovaps xmm5, [rsp+0xC0]
00007aa9b5fd9072  vmovaps [rsp+0xC0], xmm1
00007aa9b5fd907b  movaps xmm7, xmm5
00007aa9b5fd907e  mulpd xmm7, xmm15
00007aa9b5fd9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007aa9b5fd9088  ptest xmm1, xmm1
00007aa9b5fd908d  jnz 0x00007AA9B5FDAF2B
00007aa9b5fd9093  lea r14, [rax+0x80]
00007aa9b5fd909a  movups xmm1, [r13+r14*1]
00007aa9b5fd90a0  vmovaps xmm5, [rsp+0x70]
00007aa9b5fd90a6  vmovaps [rsp+0x70], xmm1
00007aa9b5fd90ac  movaps xmm15, xmm5
00007aa9b5fd90b0  addpd xmm15, xmm3
00007aa9b5fd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa9b5fd90bb  ptest xmm1, xmm1
00007aa9b5fd90c0  jnz 0x00007AA9B5FDB076
00007aa9b5fd90c6  vmovaps xmm5, [rsp+0x80]
00007aa9b5fd90cf  movaps xmm1, xmm5
00007aa9b5fd90d2  addpd xmm1, xmm4
00007aa9b5fd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007aa9b5fd90db  ptest xmm3, xmm3
00007aa9b5fd90e0  jnz 0x00007AA9B5FDB1B8
00007aa9b5fd90e6  vmovaps [rsp+0x80], xmm10
00007aa9b5fd90ef  vmovaps xmm5, [rsp+0x80]
00007aa9b5fd90f8  por xmm10, xmm5
00007aa9b5fd90fd  movaps [r15+0x2F0], xmm10
00007aa9b5fd9105  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd910b  vpermilpd xmm5, xmm5, 0x00
00007aa9b5fd9111  vmovaps xmm3, [rsp+0x70]
00007aa9b5fd9117  vmovaps [rsp+0x50], xmm1
00007aa9b5fd911d  movaps xmm4, xmm3
00007aa9b5fd9120  mulpd xmm4, xmm5
00007aa9b5fd9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007aa9b5fd9129  ptest xmm1, xmm1
00007aa9b5fd912e  jnz 0x00007AA9B5FDB2F8
00007aa9b5fd9134  lea r14, [rax+0xD0]
00007aa9b5fd913b  movups xmm1, [r13+r14*1]
00007aa9b5fd9141  vmovaps xmm3, [rsp+0xD0]
00007aa9b5fd914a  vmovaps [rsp+0x70], xmm1
00007aa9b5fd9150  movaps xmm5, xmm6
00007aa9b5fd9153  addpd xmm5, xmm3
00007aa9b5fd9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007aa9b5fd915c  ptest xmm1, xmm1
00007aa9b5fd9161  jnz 0x00007AA9B5FDB442
00007aa9b5fd9167  vmovaps xmm1, [rsp+0x60]
00007aa9b5fd916d  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd9173  movaps xmm6, xmm9
00007aa9b5fd9177  mulpd xmm6, xmm1
00007aa9b5fd917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007aa9b5fd9180  ptest xmm3, xmm3
00007aa9b5fd9185  jnz 0x00007AA9B5FDB582
00007aa9b5fd918b  movaps [r15+0x260], xmm6
00007aa9b5fd9193  vxorps xmm1, xmm1, xmm1
00007aa9b5fd9197  vpbroadcastq xmm1, xmm1
00007aa9b5fd919c  movaps [r15+0x1B0], xmm1
00007aa9b5fd91a4  vmovaps xmm1, [rsp+0x60]
00007aa9b5fd91aa  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd91b0  vmovaps xmm3, [rsp+0x70]
00007aa9b5fd91b6  vmovaps [rsp+0x70], xmm15
00007aa9b5fd91bc  movaps xmm9, xmm3
00007aa9b5fd91c0  mulpd xmm9, xmm1
00007aa9b5fd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007aa9b5fd91cb  ptest xmm15, xmm15
00007aa9b5fd91d1  jnz 0x00007AA9B5FDB6C3
00007aa9b5fd91d7  lea r14, [rax+0xC0]
00007aa9b5fd91de  movups xmm1, [r13+r14*1]
00007aa9b5fd91e4  vmovaps xmm3, [rsp+0xC0]
00007aa9b5fd91ed  vmovaps [rsp+0x80], xmm1
00007aa9b5fd91f6  movaps xmm15, xmm3
00007aa9b5fd91fa  addpd xmm15, xmm7
00007aa9b5fd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa9b5fd9205  ptest xmm1, xmm1
00007aa9b5fd920a  jnz 0x00007AA9B5FDB80F
00007aa9b5fd9210  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd9219  vmovaps xmm1, [rsp+0xC0]
00007aa9b5fd9222  por xmm13, xmm1
00007aa9b5fd9227  movaps [r15+0x270], xmm13
00007aa9b5fd922f  vmovaps xmm1, [rsp+0xB0]
00007aa9b5fd9238  vmovaps xmm7, [rsp+0xB0]
00007aa9b5fd9241  por xmm1, xmm7
00007aa9b5fd9245  movaps [r15+0x1A0], xmm1
00007aa9b5fd924d  vmovaps xmm1, [rsp+0x60]
00007aa9b5fd9253  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd9259  vmovaps [rsp+0xB0], xmm1
00007aa9b5fd9262  vmovaps xmm1, [rsp+0x80]
00007aa9b5fd926b  vmovaps [rsp+0x80], xmm15
00007aa9b5fd9274  vmovaps xmm15, [rsp+0xB0]
00007aa9b5fd927d  vmovaps [rsp+0xB0], xmm14
00007aa9b5fd9286  movaps xmm3, xmm1
00007aa9b5fd9289  mulpd xmm3, xmm15
00007aa9b5fd928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007aa9b5fd9293  ptest xmm14, xmm14
00007aa9b5fd9299  jnz 0x00007AA9B5FDB951
00007aa9b5fd929f  lea r14, [rax+0x20]
00007aa9b5fd92a3  movups xmm1, [r13+r14*1]
00007aa9b5fd92a9  movaps [r15+0x110], xmm1
00007aa9b5fd92b1  vmovaps xmm14, [rsp+0x70]
00007aa9b5fd92b7  vmovaps [rsp+0x70], xmm1
00007aa9b5fd92bd  movaps xmm15, xmm14
00007aa9b5fd92c1  addpd xmm15, xmm4
00007aa9b5fd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa9b5fd92cc  ptest xmm1, xmm1
00007aa9b5fd92d1  jnz 0x00007AA9B5FDBA9C
00007aa9b5fd92d7  vmovaps xmm1, [rsp+0x60]
00007aa9b5fd92dd  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd92e3  movaps xmm14, xmm2
00007aa9b5fd92e7  mulpd xmm14, xmm1
00007aa9b5fd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007aa9b5fd92f2  ptest xmm4, xmm4
00007aa9b5fd92f7  jnz 0x00007AA9B5FDBBDF
00007aa9b5fd92fd  vmovaps xmm4, [rsp+0x50]
00007aa9b5fd9303  movaps xmm1, xmm4
00007aa9b5fd9306  addpd xmm1, xmm9
00007aa9b5fd930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa9b5fd9310  ptest xmm2, xmm2
00007aa9b5fd9315  jnz 0x00007AA9B5FDBD21
00007aa9b5fd931b  vmovaps xmm9, [rsp+0x30]
00007aa9b5fd9321  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fd9327  vmovaps xmm2, [rsp+0x70]
00007aa9b5fd932d  vmovaps [rsp+0x50], xmm1
00007aa9b5fd9333  movaps xmm4, xmm2
00007aa9b5fd9336  mulpd xmm4, xmm9
00007aa9b5fd933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007aa9b5fd9340  ptest xmm1, xmm1
00007aa9b5fd9345  jnz 0x00007AA9B5FDBE62
00007aa9b5fd934b  vmovaps xmm1, [rsp+0x30]
00007aa9b5fd9351  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd9357  vmovaps xmm2, [rsp+0x90]
00007aa9b5fd9360  vmovaps [rsp+0x60], xmm15
00007aa9b5fd9366  movaps xmm9, xmm2
00007aa9b5fd936a  mulpd xmm9, xmm1
00007aa9b5fd936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007aa9b5fd9375  ptest xmm15, xmm15
00007aa9b5fd937b  jnz 0x00007AA9B5FDBFA3
00007aa9b5fd9381  vmovaps xmm15, [rsp+0x80]
00007aa9b5fd938a  movaps xmm1, xmm15
00007aa9b5fd938e  addpd xmm1, xmm6
00007aa9b5fd9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa9b5fd9397  ptest xmm2, xmm2
00007aa9b5fd939c  jnz 0x00007AA9B5FDC0E5
00007aa9b5fd93a2  movaps xmm15, xmm5
00007aa9b5fd93a6  addpd xmm15, xmm3
00007aa9b5fd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007aa9b5fd93b1  ptest xmm6, xmm6
00007aa9b5fd93b6  jnz 0x00007AA9B5FDC226
00007aa9b5fd93bc  vmovaps xmm6, [rsp+0x30]
00007aa9b5fd93c2  vpermilpd xmm6, xmm6, 0x00
00007aa9b5fd93c8  movaps xmm5, xmm8
00007aa9b5fd93cc  mulpd xmm5, xmm6
00007aa9b5fd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007aa9b5fd93d5  ptest xmm3, xmm3
00007aa9b5fd93da  jnz 0x00007AA9B5FDC368
00007aa9b5fd93e0  vmovaps xmm8, [rsp+0x30]
00007aa9b5fd93e6  vpermilpd xmm8, xmm8, 0x00
00007aa9b5fd93ec  movaps xmm6, xmm10
00007aa9b5fd93f0  mulpd xmm6, xmm8
00007aa9b5fd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007aa9b5fd93fa  ptest xmm3, xmm3
00007aa9b5fd93ff  jnz 0x00007AA9B5FDC4A9
00007aa9b5fd9405  vmovaps xmm8, [rsp+0x60]
00007aa9b5fd940b  movaps xmm10, xmm8
00007aa9b5fd940f  addpd xmm10, xmm14
00007aa9b5fd9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007aa9b5fd941a  ptest xmm3, xmm3
00007aa9b5fd941f  jnz 0x00007AA9B5FDC5EB
00007aa9b5fd9425  vmovaps xmm8, [rsp+0x50]
00007aa9b5fd942b  movaps xmm14, xmm8
00007aa9b5fd942f  addpd xmm14, xmm4
00007aa9b5fd9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007aa9b5fd943a  ptest xmm3, xmm3
00007aa9b5fd943f  jnz 0x00007AA9B5FDC72F
00007aa9b5fd9445  vmovaps xmm8, [rsp+0x40]
00007aa9b5fd944b  vpermilpd xmm8, xmm8, 0x00
00007aa9b5fd9451  movaps xmm4, xmm13
00007aa9b5fd9455  mulpd xmm4, xmm8
00007aa9b5fd945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007aa9b5fd945f  ptest xmm3, xmm3
00007aa9b5fd9464  jnz 0x00007AA9B5FDC872
00007aa9b5fd946a  movaps xmm13, xmm15
00007aa9b5fd946e  addpd xmm13, xmm9
00007aa9b5fd9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007aa9b5fd9479  ptest xmm8, xmm8
00007aa9b5fd947f  jnz 0x00007AA9B5FDC9B4
00007aa9b5fd9485  movaps xmm15, xmm1
00007aa9b5fd9489  addpd xmm15, xmm5
00007aa9b5fd948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa9b5fd9494  ptest xmm9, xmm9
00007aa9b5fd949a  jnz 0x00007AA9B5FDCAF8
00007aa9b5fd94a0  vmovaps [rsp+0x30], xmm11
00007aa9b5fd94a6  vmovaps xmm1, [rsp+0x30]
00007aa9b5fd94ac  por xmm11, xmm1
00007aa9b5fd94b1  movaps [r15+0x250], xmm11
00007aa9b5fd94b9  vmovaps [rsp+0x30], xmm12
00007aa9b5fd94bf  vmovaps xmm1, [rsp+0x30]
00007aa9b5fd94c5  por xmm12, xmm1
00007aa9b5fd94ca  movaps [r15+0x2A0], xmm12
00007aa9b5fd94d2  vmovaps xmm1, [rsp+0xA0]
00007aa9b5fd94db  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd94e4  por xmm1, xmm11
00007aa9b5fd94e9  movaps [r15+0x1D0], xmm1
00007aa9b5fd94f1  lea r14, [rax+0x40]
00007aa9b5fd94f5  movups xmm1, [r13+r14*1]
00007aa9b5fd94fb  movaps [r15+0x2C0], xmm1
00007aa9b5fd9503  vmovaps xmm11, [rsp+0x40]
00007aa9b5fd9509  vpermilpd xmm11, xmm11, 0x00
00007aa9b5fd950f  vmovaps xmm8, [rsp+0xE0]
00007aa9b5fd9518  movaps xmm9, xmm8
00007aa9b5fd951c  mulpd xmm9, xmm11
00007aa9b5fd9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007aa9b5fd9527  ptest xmm5, xmm5
00007aa9b5fd952c  jnz 0x00007AA9B5FDCC44
00007aa9b5fd9532  movaps xmm11, xmm10
00007aa9b5fd9536  addpd xmm11, xmm6
00007aa9b5fd953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007aa9b5fd9541  ptest xmm8, xmm8
00007aa9b5fd9547  jnz 0x00007AA9B5FDCD88
00007aa9b5fd954d  movaps xmm10, xmm14
00007aa9b5fd9551  addpd xmm10, xmm4
00007aa9b5fd9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007aa9b5fd955c  ptest xmm8, xmm8
00007aa9b5fd9562  jnz 0x00007AA9B5FDCECB
00007aa9b5fd9568  vmovaps xmm14, [rsp+0x40]
00007aa9b5fd956e  vpermilpd xmm14, xmm14, 0x00
00007aa9b5fd9574  movaps xmm8, xmm1
00007aa9b5fd9578  mulpd xmm8, xmm14
00007aa9b5fd957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa9b5fd9583  ptest xmm6, xmm6
00007aa9b5fd9588  jnz 0x00007AA9B5FDD00E
00007aa9b5fd958e  movaps xmm1, [r15+0x2B0]
00007aa9b5fd9596  vmovaps xmm14, [rsp+0x40]
00007aa9b5fd959c  vpermilpd xmm14, xmm14, 0x00
00007aa9b5fd95a2  movaps xmm6, xmm1
00007aa9b5fd95a5  mulpd xmm6, xmm14
00007aa9b5fd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa9b5fd95af  ptest xmm5, xmm5
00007aa9b5fd95b4  jnz 0x00007AA9B5FDD151
00007aa9b5fd95ba  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd95c0  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd95c6  movaps xmm14, xmm12
00007aa9b5fd95ca  mulpd xmm14, xmm1
00007aa9b5fd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007aa9b5fd95d5  ptest xmm5, xmm5
00007aa9b5fd95da  jnz 0x00007AA9B5FDD292
00007aa9b5fd95e0  movaps xmm1, xmm13
00007aa9b5fd95e4  addpd xmm1, xmm9
00007aa9b5fd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa9b5fd95ee  ptest xmm12, xmm12
00007aa9b5fd95f4  jnz 0x00007AA9B5FDD3D5
00007aa9b5fd95fa  vmovaps xmm13, [rsp+0x10]
00007aa9b5fd9600  vpermilpd xmm13, xmm13, 0x00
00007aa9b5fd9606  movaps xmm12, xmm7
00007aa9b5fd960a  mulpd xmm12, xmm13
00007aa9b5fd960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa9b5fd9615  ptest xmm9, xmm9
00007aa9b5fd961b  jnz 0x00007AA9B5FDD517
00007aa9b5fd9621  movaps xmm13, xmm15
00007aa9b5fd9625  addpd xmm13, xmm8
00007aa9b5fd962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007aa9b5fd9630  ptest xmm9, xmm9
00007aa9b5fd9636  jnz 0x00007AA9B5FDD65A
00007aa9b5fd963c  movaps xmm15, [r15+0x290]
00007aa9b5fd9644  vmovaps xmm9, [rsp+0x10]
00007aa9b5fd964a  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fd9650  movaps xmm8, xmm15
00007aa9b5fd9654  mulpd xmm8, xmm9
00007aa9b5fd9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa9b5fd965f  ptest xmm7, xmm7
00007aa9b5fd9664  jnz 0x00007AA9B5FDD79E
00007aa9b5fd966a  movaps xmm15, xmm11
00007aa9b5fd966e  addpd xmm15, xmm6
00007aa9b5fd9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa9b5fd9679  ptest xmm9, xmm9
00007aa9b5fd967f  jnz 0x00007AA9B5FDD8E2
00007aa9b5fd9685  movaps xmm11, [r15+0x1E0]
00007aa9b5fd968d  vmovaps xmm9, [rsp+0x10]
00007aa9b5fd9693  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fd9699  movaps xmm7, xmm11
00007aa9b5fd969d  mulpd xmm7, xmm9
00007aa9b5fd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa9b5fd96a7  ptest xmm6, xmm6
00007aa9b5fd96ac  jnz 0x00007AA9B5FDDA25
00007aa9b5fd96b2  movaps xmm11, xmm10
00007aa9b5fd96b6  addpd xmm11, xmm14
00007aa9b5fd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007aa9b5fd96c1  ptest xmm9, xmm9
00007aa9b5fd96c7  jnz 0x00007AA9B5FDDB67
00007aa9b5fd96cd  lea r14, [rax+0x70]
00007aa9b5fd96d1  movups xmm14, [r13+r14*1]
00007aa9b5fd96d7  movaps [r15+0x240], xmm14
00007aa9b5fd96df  movaps xmm10, xmm1
00007aa9b5fd96e3  addpd xmm10, xmm12
00007aa9b5fd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007aa9b5fd96ee  ptest xmm9, xmm9
00007aa9b5fd96f4  jnz 0x00007AA9B5FDDCB5
00007aa9b5fd96fa  movaps [r15+0x170], xmm10
00007aa9b5fd9702  vmovaps xmm1, [rsp+0x20]
00007aa9b5fd9708  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd970e  movaps xmm12, xmm14
00007aa9b5fd9712  mulpd xmm12, xmm1
00007aa9b5fd9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa9b5fd971d  ptest xmm9, xmm9
00007aa9b5fd9723  jnz 0x00007AA9B5FDDDF8
00007aa9b5fd9729  vmovaps xmm1, [rsp+0x20]
00007aa9b5fd972f  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fd9735  vmovaps xmm9, [rsp+0xB0]
00007aa9b5fd973e  movaps xmm14, xmm9
00007aa9b5fd9742  mulpd xmm14, xmm1
00007aa9b5fd9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa9b5fd974d  ptest xmm6, xmm6
00007aa9b5fd9752  jnz 0x00007AA9B5FDDF3B
00007aa9b5fd9758  movaps [r15+0x180], xmm14
00007aa9b5fd9760  movaps xmm1, xmm13
00007aa9b5fd9764  addpd xmm1, xmm8
00007aa9b5fd9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007aa9b5fd976e  ptest xmm9, xmm9
00007aa9b5fd9774  jnz 0x00007AA9B5FDE07E
00007aa9b5fd977a  movaps [r15+0x210], xmm1
00007aa9b5fd9782  movups xmm13, [r13+rax*1]
00007aa9b5fd9788  lea r14, [rax+0x10]
00007aa9b5fd978c  movups xmm9, [r13+r14*1]
00007aa9b5fd9792  movaps [r15+0x230], xmm9
00007aa9b5fd979a  movaps xmm8, xmm15
00007aa9b5fd979e  addpd xmm8, xmm7
00007aa9b5fd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa9b5fd97a9  ptest xmm6, xmm6
00007aa9b5fd97ae  jnz 0x00007AA9B5FDE1D4
00007aa9b5fd97b4  movaps [r15+0x130], xmm8
00007aa9b5fd97bc  vmovaps xmm15, [rsp+0x20]
00007aa9b5fd97c2  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd97c8  movaps xmm7, xmm9
00007aa9b5fd97cc  mulpd xmm7, xmm15
00007aa9b5fd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa9b5fd97d6  ptest xmm6, xmm6
00007aa9b5fd97db  jnz 0x00007AA9B5FDE317
00007aa9b5fd97e1  movaps [r15+0x220], xmm7
00007aa9b5fd97e9  vmovaps xmm15, [rsp+0x20]
00007aa9b5fd97ef  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fd97f5  movaps xmm9, xmm13
00007aa9b5fd97f9  mulpd xmm9, xmm15
00007aa9b5fd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa9b5fd9804  ptest xmm6, xmm6
00007aa9b5fd9809  jnz 0x00007AA9B5FDE459
00007aa9b5fd980f  movaps xmm15, xmm11
00007aa9b5fd9813  addpd xmm15, xmm12
00007aa9b5fd9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007aa9b5fd981e  ptest xmm13, xmm13
00007aa9b5fd9824  jnz 0x00007AA9B5FDE59D
00007aa9b5fd982a  movaps [r15+0x140], xmm15
00007aa9b5fd9832  movaps xmm13, xmm10
00007aa9b5fd9836  addpd xmm13, xmm14
00007aa9b5fd983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007aa9b5fd9841  ptest xmm12, xmm12
00007aa9b5fd9847  jnz 0x00007AA9B5FDE6E1
00007aa9b5fd984d  movaps [r15+0x150], xmm13
00007aa9b5fd9855  movaps xmm14, xmm1
00007aa9b5fd9859  addpd xmm14, xmm7
00007aa9b5fd985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007aa9b5fd9864  ptest xmm12, xmm12
00007aa9b5fd986a  jnz 0x00007AA9B5FDE825
00007aa9b5fd9870  movaps [r15+0x160], xmm14
00007aa9b5fd9878  movaps xmm1, xmm8
00007aa9b5fd987c  addpd xmm1, xmm9
00007aa9b5fd9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa9b5fd9886  ptest xmm12, xmm12
00007aa9b5fd988c  jnz 0x00007AA9B5FDE967
00007aa9b5fd9892  movaps [r15+0x120], xmm1
00007aa9b5fd989a  movups [r13+r11*1], xmm15
00007aa9b5fd98a0  lea rax, [r11+0x10]
00007aa9b5fd98a4  movups [r13+rax*1], xmm13
00007aa9b5fd98aa  lea rax, [r11+0x20]
00007aa9b5fd98ae  movups [r13+rax*1], xmm14
00007aa9b5fd98b4  lea rax, [r11+0x30]
00007aa9b5fd98b8  movups [r13+rax*1], xmm1
00007aa9b5fd98be  mov eax, [r15+0x108]
00007aa9b5fd98c5  sahf
00007aa9b5fd98c6  jnz 0x00007AA9B5FD98F8
00007aa9b5fd98c8  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd98d0  jz 0x00007AA9B5FDEAE0
00007aa9b5fd98d6  nop [rax+rax*1], ax
00007aa9b5fd98df  nop [rax+rax*1], eax
00007aa9b5fd98e7  mov eax, 0x4106D0
00007aa9b5fd98ec  mov [r15+0x100], rax
00007aa9b5fd98f3  jmp 0x00007AA9B5DFE110
00007aa9b5fd98f8  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fd9900  jz 0x00007AA9B5FD89C0
00007aa9b5fd9906  nop [rax+rax*1], ax
00007aa9b5fd990f  nop [rax+rax*1], eax
00007aa9b5fd9917  mov eax, 0x410504
00007aa9b5fd991c  mov [r15+0x100], rax
00007aa9b5fd9923  jmp 0x00007AA9B5DFE110
00007aa9b5fd9928  int3
00007aa9b5fd9929  call 0x00007AA9B5E0A4B0
00007aa9b5fd992e  jmp 0x00007AA9B5FD8A08
00007aa9b5fd9933  call 0x00007AA9B5E09240
00007aa9b5fd9938  jmp 0x00007AA9B5FD8A12
00007aa9b5fd993d  call 0x00007AA9B5E0A4B0
00007aa9b5fd9942  jmp 0x00007AA9B5FD8A6F
00007aa9b5fd9947  call 0x00007AA9B5E09240
00007aa9b5fd994c  jmp 0x00007AA9B5FD8A79
00007aa9b5fd9951  call 0x00007AA9B5E0A4B0
00007aa9b5fd9956  jmp 0x00007AA9B5FD8ABD
00007aa9b5fd995b  call 0x00007AA9B5E09240
00007aa9b5fd9960  jmp 0x00007AA9B5FD8AC7
00007aa9b5fd9965  call 0x00007AA9B5EB47C0
00007aa9b5fd996a  jmp 0x00007AA9B5FD8B06
00007aa9b5fd996f  call 0x00007AA9B5E0B720
00007aa9b5fd9974  jmp 0x00007AA9B5FD8B1A
00007aa9b5fd9979  call 0x00007AA9B5EBFC30
00007aa9b5fd997e  jmp 0x00007AA9B5FD8B38
00007aa9b5fd9983  call 0x00007AA9B5EBE9C0
00007aa9b5fd9988  jmp 0x00007AA9B5FD8B42
00007aa9b5fd998d  call 0x00007AA9B5EBD750
00007aa9b5fd9992  jmp 0x00007AA9B5FD8B4C
00007aa9b5fd9997  sub rsp, 0x08
00007aa9b5fd999b  push rax
00007aa9b5fd999c  push rcx
00007aa9b5fd999d  push rdx
00007aa9b5fd999e  push rdi
00007aa9b5fd999f  push rsi
00007aa9b5fd99a0  push r8
00007aa9b5fd99a2  push r9
00007aa9b5fd99a4  push r10
00007aa9b5fd99a6  push r11
00007aa9b5fd99a8  sub rsp, 0xF0
00007aa9b5fd99af  vmovaps [rsp], xmm0
00007aa9b5fd99b4  vmovaps [rsp+0x10], xmm1
00007aa9b5fd99ba  vmovaps [rsp+0x20], xmm2
00007aa9b5fd99c0  vmovaps [rsp+0x30], xmm3
00007aa9b5fd99c6  vmovaps [rsp+0x40], xmm4
00007aa9b5fd99cc  vmovaps [rsp+0x50], xmm5
00007aa9b5fd99d2  vmovaps [rsp+0x60], xmm6
00007aa9b5fd99d8  vmovaps [rsp+0x70], xmm7
00007aa9b5fd99de  vmovaps [rsp+0x80], xmm9
00007aa9b5fd99e7  vmovaps [rsp+0x90], xmm10
00007aa9b5fd99f0  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd99f9  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd9a02  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd9a0b  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd9a14  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd9a1d  sub rsp, 0x30
00007aa9b5fd9a21  movaps [rsp], xmm8
00007aa9b5fd9a26  movaps [rsp+0x10], xmm12
00007aa9b5fd9a2c  movaps [rsp+0x20], xmm15
00007aa9b5fd9a32  lea rdi, [rsp]
00007aa9b5fd9a36  mov esi, 0x00
00007aa9b5fd9a3b  mov rax, 0x63E0217C9530
00007aa9b5fd9a45  call rax
00007aa9b5fd9a47  movaps xmm8, [rsp]
00007aa9b5fd9a4c  add rsp, 0x30
00007aa9b5fd9a50  vmovaps xmm0, [rsp]
00007aa9b5fd9a55  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd9a5b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd9a61  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd9a67  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd9a6d  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd9a73  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd9a79  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd9a7f  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd9a88  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd9a91  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd9a9a  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd9aa3  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd9aac  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd9ab5  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd9abe  add rsp, 0xF0
00007aa9b5fd9ac5  pop r11
00007aa9b5fd9ac7  pop r10
00007aa9b5fd9ac9  pop r9
00007aa9b5fd9acb  pop r8
00007aa9b5fd9acd  pop rsi
00007aa9b5fd9ace  pop rdi
00007aa9b5fd9acf  pop rdx
00007aa9b5fd9ad0  pop rcx
00007aa9b5fd9ad1  pop rax
00007aa9b5fd9ad2  add rsp, 0x08
00007aa9b5fd9ad6  jmp 0x00007AA9B5FD8B7A
00007aa9b5fd9adb  sub rsp, 0x08
00007aa9b5fd9adf  push rax
00007aa9b5fd9ae0  push rcx
00007aa9b5fd9ae1  push rdx
00007aa9b5fd9ae2  push rdi
00007aa9b5fd9ae3  push rsi
00007aa9b5fd9ae4  push r8
00007aa9b5fd9ae6  push r9
00007aa9b5fd9ae8  push r10
00007aa9b5fd9aea  push r11
00007aa9b5fd9aec  sub rsp, 0xF0
00007aa9b5fd9af3  vmovaps [rsp], xmm0
00007aa9b5fd9af8  vmovaps [rsp+0x10], xmm1
00007aa9b5fd9afe  vmovaps [rsp+0x20], xmm2
00007aa9b5fd9b04  vmovaps [rsp+0x30], xmm3
00007aa9b5fd9b0a  vmovaps [rsp+0x40], xmm4
00007aa9b5fd9b10  vmovaps [rsp+0x50], xmm5
00007aa9b5fd9b16  vmovaps [rsp+0x60], xmm6
00007aa9b5fd9b1c  vmovaps [rsp+0x70], xmm8
00007aa9b5fd9b22  vmovaps [rsp+0x80], xmm9
00007aa9b5fd9b2b  vmovaps [rsp+0x90], xmm10
00007aa9b5fd9b34  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd9b3d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd9b46  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd9b4f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd9b58  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd9b61  sub rsp, 0x30
00007aa9b5fd9b65  movaps [rsp], xmm7
00007aa9b5fd9b69  movaps [rsp+0x10], xmm9
00007aa9b5fd9b6f  movaps [rsp+0x20], xmm15
00007aa9b5fd9b75  lea rdi, [rsp]
00007aa9b5fd9b79  mov esi, 0x00
00007aa9b5fd9b7e  mov rax, 0x63E0217C9530
00007aa9b5fd9b88  call rax
00007aa9b5fd9b8a  movaps xmm7, [rsp]
00007aa9b5fd9b8e  add rsp, 0x30
00007aa9b5fd9b92  vmovaps xmm0, [rsp]
00007aa9b5fd9b97  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd9b9d  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd9ba3  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd9ba9  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd9baf  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd9bb5  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd9bbb  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd9bc1  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd9bca  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd9bd3  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd9bdc  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd9be5  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd9bee  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd9bf7  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd9c00  add rsp, 0xF0
00007aa9b5fd9c07  pop r11
00007aa9b5fd9c09  pop r10
00007aa9b5fd9c0b  pop r9
00007aa9b5fd9c0d  pop r8
00007aa9b5fd9c0f  pop rsi
00007aa9b5fd9c10  pop rdi
00007aa9b5fd9c11  pop rdx
00007aa9b5fd9c12  pop rcx
00007aa9b5fd9c13  pop rax
00007aa9b5fd9c14  add rsp, 0x08
00007aa9b5fd9c18  jmp 0x00007AA9B5FD8BA8
00007aa9b5fd9c1d  sub rsp, 0x08
00007aa9b5fd9c21  push rax
00007aa9b5fd9c22  push rcx
00007aa9b5fd9c23  push rdx
00007aa9b5fd9c24  push rdi
00007aa9b5fd9c25  push rsi
00007aa9b5fd9c26  push r8
00007aa9b5fd9c28  push r9
00007aa9b5fd9c2a  push r10
00007aa9b5fd9c2c  push r11
00007aa9b5fd9c2e  sub rsp, 0xF0
00007aa9b5fd9c35  vmovaps [rsp], xmm0
00007aa9b5fd9c3a  vmovaps [rsp+0x10], xmm1
00007aa9b5fd9c40  vmovaps [rsp+0x20], xmm2
00007aa9b5fd9c46  vmovaps [rsp+0x30], xmm3
00007aa9b5fd9c4c  vmovaps [rsp+0x40], xmm4
00007aa9b5fd9c52  vmovaps [rsp+0x50], xmm5
00007aa9b5fd9c58  vmovaps [rsp+0x60], xmm6
00007aa9b5fd9c5e  vmovaps [rsp+0x70], xmm7
00007aa9b5fd9c64  vmovaps [rsp+0x80], xmm8
00007aa9b5fd9c6d  vmovaps [rsp+0x90], xmm10
00007aa9b5fd9c76  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd9c7f  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd9c88  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd9c91  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd9c9a  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd9ca3  sub rsp, 0x30
00007aa9b5fd9ca7  movaps [rsp], xmm9
00007aa9b5fd9cac  movaps [rsp+0x10], xmm12
00007aa9b5fd9cb2  movaps [rsp+0x20], xmm10
00007aa9b5fd9cb8  lea rdi, [rsp]
00007aa9b5fd9cbc  mov esi, 0x00
00007aa9b5fd9cc1  mov rax, 0x63E0217C9530
00007aa9b5fd9ccb  call rax
00007aa9b5fd9ccd  movaps xmm9, [rsp]
00007aa9b5fd9cd2  add rsp, 0x30
00007aa9b5fd9cd6  vmovaps xmm0, [rsp]
00007aa9b5fd9cdb  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd9ce1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd9ce7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd9ced  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd9cf3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd9cf9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd9cff  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd9d05  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd9d0e  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd9d17  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd9d20  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd9d29  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd9d32  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd9d3b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd9d44  add rsp, 0xF0
00007aa9b5fd9d4b  pop r11
00007aa9b5fd9d4d  pop r10
00007aa9b5fd9d4f  pop r9
00007aa9b5fd9d51  pop r8
00007aa9b5fd9d53  pop rsi
00007aa9b5fd9d54  pop rdi
00007aa9b5fd9d55  pop rdx
00007aa9b5fd9d56  pop rcx
00007aa9b5fd9d57  pop rax
00007aa9b5fd9d58  add rsp, 0x08
00007aa9b5fd9d5c  jmp 0x00007AA9B5FD8BCC
00007aa9b5fd9d61  sub rsp, 0x08
00007aa9b5fd9d65  push rax
00007aa9b5fd9d66  push rcx
00007aa9b5fd9d67  push rdx
00007aa9b5fd9d68  push rdi
00007aa9b5fd9d69  push rsi
00007aa9b5fd9d6a  push r8
00007aa9b5fd9d6c  push r9
00007aa9b5fd9d6e  push r10
00007aa9b5fd9d70  push r11
00007aa9b5fd9d72  sub rsp, 0xF0
00007aa9b5fd9d79  vmovaps [rsp], xmm0
00007aa9b5fd9d7e  vmovaps [rsp+0x10], xmm1
00007aa9b5fd9d84  vmovaps [rsp+0x20], xmm2
00007aa9b5fd9d8a  vmovaps [rsp+0x30], xmm3
00007aa9b5fd9d90  vmovaps [rsp+0x40], xmm4
00007aa9b5fd9d96  vmovaps [rsp+0x50], xmm5
00007aa9b5fd9d9c  vmovaps [rsp+0x60], xmm6
00007aa9b5fd9da2  vmovaps [rsp+0x70], xmm7
00007aa9b5fd9da8  vmovaps [rsp+0x80], xmm8
00007aa9b5fd9db1  vmovaps [rsp+0x90], xmm9
00007aa9b5fd9dba  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd9dc3  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd9dcc  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd9dd5  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd9dde  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd9de7  sub rsp, 0x30
00007aa9b5fd9deb  movaps [rsp], xmm10
00007aa9b5fd9df0  movaps [rsp+0x10], xmm12
00007aa9b5fd9df6  movaps [rsp+0x20], xmm11
00007aa9b5fd9dfc  lea rdi, [rsp]
00007aa9b5fd9e00  mov esi, 0x00
00007aa9b5fd9e05  mov rax, 0x63E0217C9530
00007aa9b5fd9e0f  call rax
00007aa9b5fd9e11  movaps xmm10, [rsp]
00007aa9b5fd9e16  add rsp, 0x30
00007aa9b5fd9e1a  vmovaps xmm0, [rsp]
00007aa9b5fd9e1f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd9e25  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd9e2b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd9e31  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd9e37  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd9e3d  vmovaps xmm6, [rsp+0x60]
00007aa9b5fd9e43  vmovaps xmm7, [rsp+0x70]
00007aa9b5fd9e49  vmovaps xmm8, [rsp+0x80]
00007aa9b5fd9e52  vmovaps xmm9, [rsp+0x90]
00007aa9b5fd9e5b  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd9e64  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd9e6d  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd9e76  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd9e7f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd9e88  add rsp, 0xF0
00007aa9b5fd9e8f  pop r11
00007aa9b5fd9e91  pop r10
00007aa9b5fd9e93  pop r9
00007aa9b5fd9e95  pop r8
00007aa9b5fd9e97  pop rsi
00007aa9b5fd9e98  pop rdi
00007aa9b5fd9e99  pop rdx
00007aa9b5fd9e9a  pop rcx
00007aa9b5fd9e9b  pop rax
00007aa9b5fd9e9c  add rsp, 0x08
00007aa9b5fd9ea0  jmp 0x00007AA9B5FD8BE6
00007aa9b5fd9ea5  sub rsp, 0x08
00007aa9b5fd9ea9  push rax
00007aa9b5fd9eaa  push rcx
00007aa9b5fd9eab  push rdx
00007aa9b5fd9eac  push rdi
00007aa9b5fd9ead  push rsi
00007aa9b5fd9eae  push r8
00007aa9b5fd9eb0  push r9
00007aa9b5fd9eb2  push r10
00007aa9b5fd9eb4  push r11
00007aa9b5fd9eb6  sub rsp, 0xF0
00007aa9b5fd9ebd  vmovaps [rsp], xmm0
00007aa9b5fd9ec2  vmovaps [rsp+0x10], xmm1
00007aa9b5fd9ec8  vmovaps [rsp+0x20], xmm2
00007aa9b5fd9ece  vmovaps [rsp+0x30], xmm3
00007aa9b5fd9ed4  vmovaps [rsp+0x40], xmm4
00007aa9b5fd9eda  vmovaps [rsp+0x50], xmm5
00007aa9b5fd9ee0  vmovaps [rsp+0x60], xmm7
00007aa9b5fd9ee6  vmovaps [rsp+0x70], xmm8
00007aa9b5fd9eec  vmovaps [rsp+0x80], xmm9
00007aa9b5fd9ef5  vmovaps [rsp+0x90], xmm10
00007aa9b5fd9efe  vmovaps [rsp+0xA0], xmm11
00007aa9b5fd9f07  vmovaps [rsp+0xB0], xmm12
00007aa9b5fd9f10  vmovaps [rsp+0xC0], xmm13
00007aa9b5fd9f19  vmovaps [rsp+0xD0], xmm14
00007aa9b5fd9f22  vmovaps [rsp+0xE0], xmm15
00007aa9b5fd9f2b  sub rsp, 0x30
00007aa9b5fd9f2f  movaps [rsp], xmm6
00007aa9b5fd9f33  movaps [rsp+0x10], xmm12
00007aa9b5fd9f39  movaps [rsp+0x20], xmm11
00007aa9b5fd9f3f  lea rdi, [rsp]
00007aa9b5fd9f43  mov esi, 0x00
00007aa9b5fd9f48  mov rax, 0x63E0217C9530
00007aa9b5fd9f52  call rax
00007aa9b5fd9f54  movaps xmm6, [rsp]
00007aa9b5fd9f58  add rsp, 0x30
00007aa9b5fd9f5c  vmovaps xmm0, [rsp]
00007aa9b5fd9f61  vmovaps xmm1, [rsp+0x10]
00007aa9b5fd9f67  vmovaps xmm2, [rsp+0x20]
00007aa9b5fd9f6d  vmovaps xmm3, [rsp+0x30]
00007aa9b5fd9f73  vmovaps xmm4, [rsp+0x40]
00007aa9b5fd9f79  vmovaps xmm5, [rsp+0x50]
00007aa9b5fd9f7f  vmovaps xmm7, [rsp+0x60]
00007aa9b5fd9f85  vmovaps xmm8, [rsp+0x70]
00007aa9b5fd9f8b  vmovaps xmm9, [rsp+0x80]
00007aa9b5fd9f94  vmovaps xmm10, [rsp+0x90]
00007aa9b5fd9f9d  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fd9fa6  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fd9faf  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fd9fb8  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fd9fc1  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fd9fca  add rsp, 0xF0
00007aa9b5fd9fd1  pop r11
00007aa9b5fd9fd3  pop r10
00007aa9b5fd9fd5  pop r9
00007aa9b5fd9fd7  pop r8
00007aa9b5fd9fd9  pop rsi
00007aa9b5fd9fda  pop rdi
00007aa9b5fd9fdb  pop rdx
00007aa9b5fd9fdc  pop rcx
00007aa9b5fd9fdd  pop rax
00007aa9b5fd9fde  add rsp, 0x08
00007aa9b5fd9fe2  jmp 0x00007AA9B5FD8C07
00007aa9b5fd9fe7  sub rsp, 0x08
00007aa9b5fd9feb  push rax
00007aa9b5fd9fec  push rcx
00007aa9b5fd9fed  push rdx
00007aa9b5fd9fee  push rdi
00007aa9b5fd9fef  push rsi
00007aa9b5fd9ff0  push r8
00007aa9b5fd9ff2  push r9
00007aa9b5fd9ff4  push r10
00007aa9b5fd9ff6  push r11
00007aa9b5fd9ff8  sub rsp, 0xF0
00007aa9b5fd9fff  vmovaps [rsp], xmm0
00007aa9b5fda004  vmovaps [rsp+0x10], xmm1
00007aa9b5fda00a  vmovaps [rsp+0x20], xmm2
00007aa9b5fda010  vmovaps [rsp+0x30], xmm4
00007aa9b5fda016  vmovaps [rsp+0x40], xmm5
00007aa9b5fda01c  vmovaps [rsp+0x50], xmm6
00007aa9b5fda022  vmovaps [rsp+0x60], xmm7
00007aa9b5fda028  vmovaps [rsp+0x70], xmm8
00007aa9b5fda02e  vmovaps [rsp+0x80], xmm9
00007aa9b5fda037  vmovaps [rsp+0x90], xmm10
00007aa9b5fda040  vmovaps [rsp+0xA0], xmm11
00007aa9b5fda049  vmovaps [rsp+0xB0], xmm12
00007aa9b5fda052  vmovaps [rsp+0xC0], xmm13
00007aa9b5fda05b  vmovaps [rsp+0xD0], xmm14
00007aa9b5fda064  vmovaps [rsp+0xE0], xmm15
00007aa9b5fda06d  sub rsp, 0x30
00007aa9b5fda071  movaps [rsp], xmm3
00007aa9b5fda075  movaps [rsp+0x10], xmm5
00007aa9b5fda07a  movaps [rsp+0x20], xmm4
00007aa9b5fda07f  lea rdi, [rsp]
00007aa9b5fda083  mov esi, 0x00
00007aa9b5fda088  mov rax, 0x63E0217C9530
00007aa9b5fda092  call rax
00007aa9b5fda094  movaps xmm3, [rsp]
00007aa9b5fda098  add rsp, 0x30
00007aa9b5fda09c  vmovaps xmm0, [rsp]
00007aa9b5fda0a1  vmovaps xmm1, [rsp+0x10]
00007aa9b5fda0a7  vmovaps xmm2, [rsp+0x20]
00007aa9b5fda0ad  vmovaps xmm4, [rsp+0x30]
00007aa9b5fda0b3  vmovaps xmm5, [rsp+0x40]
00007aa9b5fda0b9  vmovaps xmm6, [rsp+0x50]
00007aa9b5fda0bf  vmovaps xmm7, [rsp+0x60]
00007aa9b5fda0c5  vmovaps xmm8, [rsp+0x70]
00007aa9b5fda0cb  vmovaps xmm9, [rsp+0x80]
00007aa9b5fda0d4  vmovaps xmm10, [rsp+0x90]
00007aa9b5fda0dd  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fda0e6  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fda0ef  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fda0f8  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fda101  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fda10a  add rsp, 0xF0
00007aa9b5fda111  pop r11
00007aa9b5fda113  pop r10
00007aa9b5fda115  pop r9
00007aa9b5fda117  pop r8
00007aa9b5fda119  pop rsi
00007aa9b5fda11a  pop rdi
00007aa9b5fda11b  pop rdx
00007aa9b5fda11c  pop rcx
00007aa9b5fda11d  pop rax
00007aa9b5fda11e  add rsp, 0x08
00007aa9b5fda122  jmp 0x00007AA9B5FD8C68
00007aa9b5fda127  sub rsp, 0x08
00007aa9b5fda12b  push rax
00007aa9b5fda12c  push rcx
00007aa9b5fda12d  push rdx
00007aa9b5fda12e  push rdi
00007aa9b5fda12f  push rsi
00007aa9b5fda130  push r8
00007aa9b5fda132  push r9
00007aa9b5fda134  push r10
00007aa9b5fda136  push r11
00007aa9b5fda138  sub rsp, 0xF0
00007aa9b5fda13f  vmovaps [rsp], xmm0
00007aa9b5fda144  vmovaps [rsp+0x10], xmm1
00007aa9b5fda14a  vmovaps [rsp+0x20], xmm2
00007aa9b5fda150  vmovaps [rsp+0x30], xmm3
00007aa9b5fda156  vmovaps [rsp+0x40], xmm4
00007aa9b5fda15c  vmovaps [rsp+0x50], xmm6
00007aa9b5fda162  vmovaps [rsp+0x60], xmm7
00007aa9b5fda168  vmovaps [rsp+0x70], xmm8
00007aa9b5fda16e  vmovaps [rsp+0x80], xmm9
00007aa9b5fda177  vmovaps [rsp+0x90], xmm10
00007aa9b5fda180  vmovaps [rsp+0xA0], xmm11
00007aa9b5fda189  vmovaps [rsp+0xB0], xmm12
00007aa9b5fda192  vmovaps [rsp+0xC0], xmm13
00007aa9b5fda19b  vmovaps [rsp+0xD0], xmm14
00007aa9b5fda1a4  vmovaps [rsp+0xE0], xmm15
00007aa9b5fda1ad  sub rsp, 0x30
00007aa9b5fda1b1  movaps [rsp], xmm5
00007aa9b5fda1b5  movaps [rsp+0x10], xmm8
00007aa9b5fda1bb  movaps [rsp+0x20], xmm15
00007aa9b5fda1c1  lea rdi, [rsp]
00007aa9b5fda1c5  mov esi, 0x00
00007aa9b5fda1ca  mov rax, 0x63E0217C9530
00007aa9b5fda1d4  call rax
00007aa9b5fda1d6  movaps xmm5, [rsp]
00007aa9b5fda1da  add rsp, 0x30
00007aa9b5fda1de  vmovaps xmm0, [rsp]
00007aa9b5fda1e3  vmovaps xmm1, [rsp+0x10]
00007aa9b5fda1e9  vmovaps xmm2, [rsp+0x20]
00007aa9b5fda1ef  vmovaps xmm3, [rsp+0x30]
00007aa9b5fda1f5  vmovaps xmm4, [rsp+0x40]
00007aa9b5fda1fb  vmovaps xmm6, [rsp+0x50]
00007aa9b5fda201  vmovaps xmm7, [rsp+0x60]
00007aa9b5fda207  vmovaps xmm8, [rsp+0x70]
00007aa9b5fda20d  vmovaps xmm9, [rsp+0x80]
00007aa9b5fda216  vmovaps xmm10, [rsp+0x90]
00007aa9b5fda21f  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fda228  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fda231  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fda23a  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fda243  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fda24c  add rsp, 0xF0
00007aa9b5fda253  pop r11
00007aa9b5fda255  pop r10
00007aa9b5fda257  pop r9
00007aa9b5fda259  pop r8
00007aa9b5fda25b  pop rsi
00007aa9b5fda25c  pop rdi
00007aa9b5fda25d  pop rdx
00007aa9b5fda25e  pop rcx
00007aa9b5fda25f  pop rax
00007aa9b5fda260  add rsp, 0x08
00007aa9b5fda264  jmp 0x00007AA9B5FD8CA0
00007aa9b5fda269  sub rsp, 0x08
00007aa9b5fda26d  push rax
00007aa9b5fda26e  push rcx
00007aa9b5fda26f  push rdx
00007aa9b5fda270  push rdi
00007aa9b5fda271  push rsi
00007aa9b5fda272  push r8
00007aa9b5fda274  push r9
00007aa9b5fda276  push r10
00007aa9b5fda278  push r11
00007aa9b5fda27a  sub rsp, 0xF0
00007aa9b5fda281  vmovaps [rsp], xmm0
00007aa9b5fda286  vmovaps [rsp+0x10], xmm1
00007aa9b5fda28c  vmovaps [rsp+0x20], xmm2
00007aa9b5fda292  vmovaps [rsp+0x30], xmm3
00007aa9b5fda298  vmovaps [rsp+0x40], xmm5
00007aa9b5fda29e  vmovaps [rsp+0x50], xmm6
00007aa9b5fda2a4  vmovaps [rsp+0x60], xmm7
00007aa9b5fda2aa  vmovaps [rsp+0x70], xmm8
00007aa9b5fda2b0  vmovaps [rsp+0x80], xmm9
00007aa9b5fda2b9  vmovaps [rsp+0x90], xmm10
00007aa9b5fda2c2  vmovaps [rsp+0xA0], xmm11
00007aa9b5fda2cb  vmovaps [rsp+0xB0], xmm12
00007aa9b5fda2d4  vmovaps [rsp+0xC0], xmm13
00007aa9b5fda2dd  vmovaps [rsp+0xD0], xmm14
00007aa9b5fda2e6  vmovaps [rsp+0xE0], xmm15
00007aa9b5fda2ef  sub rsp, 0x30
00007aa9b5fda2f3  movaps [rsp], xmm4
00007aa9b5fda2f7  movaps [rsp+0x10], xmm9
00007aa9b5fda2fd  movaps [rsp+0x20], xmm8
00007aa9b5fda303  lea rdi, [rsp]
00007aa9b5fda307  mov esi, 0x00
00007aa9b5fda30c  mov rax, 0x63E0217C9530
00007aa9b5fda316  call rax
00007aa9b5fda318  movaps xmm4, [rsp]
00007aa9b5fda31c  add rsp, 0x30
00007aa9b5fda320  vmovaps xmm0, [rsp]
00007aa9b5fda325  vmovaps xmm1, [rsp+0x10]
00007aa9b5fda32b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fda331  vmovaps xmm3, [rsp+0x30]
00007aa9b5fda337  vmovaps xmm5, [rsp+0x40]
00007aa9b5fda33d  vmovaps xmm6, [rsp+0x50]
00007aa9b5fda343  vmovaps xmm7, [rsp+0x60]
00007aa9b5fda349  vmovaps xmm8, [rsp+0x70]
00007aa9b5fda34f  vmovaps xmm9, [rsp+0x80]
00007aa9b5fda358  vmovaps xmm10, [rsp+0x90]
00007aa9b5fda361  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fda36a  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fda373  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fda37c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fda385  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fda38e  add rsp, 0xF0
00007aa9b5fda395  pop r11
00007aa9b5fda397  pop r10
00007aa9b5fda399  pop r9
00007aa9b5fda39b  pop r8
00007aa9b5fda39d  pop rsi
00007aa9b5fda39e  pop rdi
00007aa9b5fda39f  pop rdx
00007aa9b5fda3a0  pop rcx
00007aa9b5fda3a1  pop rax
00007aa9b5fda3a2  add rsp, 0x08
00007aa9b5fda3a6  jmp 0x00007AA9B5FD8CC1
00007aa9b5fda3ab  sub rsp, 0x08
00007aa9b5fda3af  push rax
00007aa9b5fda3b0  push rcx
00007aa9b5fda3b1  push rdx
00007aa9b5fda3b2  push rdi
00007aa9b5fda3b3  push rsi
00007aa9b5fda3b4  push r8
00007aa9b5fda3b6  push r9
00007aa9b5fda3b8  push r10
00007aa9b5fda3ba  push r11
00007aa9b5fda3bc  sub rsp, 0xF0
00007aa9b5fda3c3  vmovaps [rsp], xmm0
00007aa9b5fda3c8  vmovaps [rsp+0x10], xmm1
00007aa9b5fda3ce  vmovaps [rsp+0x20], xmm2
00007aa9b5fda3d4  vmovaps [rsp+0x30], xmm3
00007aa9b5fda3da  vmovaps [rsp+0x40], xmm4
00007aa9b5fda3e0  vmovaps [rsp+0x50], xmm5
00007aa9b5fda3e6  vmovaps [rsp+0x60], xmm6
00007aa9b5fda3ec  vmovaps [rsp+0x70], xmm7
00007aa9b5fda3f2  vmovaps [rsp+0x80], xmm8
00007aa9b5fda3fb  vmovaps [rsp+0x90], xmm10
00007aa9b5fda404  vmovaps [rsp+0xA0], xmm11
00007aa9b5fda40d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fda416  vmovaps [rsp+0xC0], xmm13
00007aa9b5fda41f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fda428  vmovaps [rsp+0xE0], xmm15
00007aa9b5fda431  sub rsp, 0x30
00007aa9b5fda435  movaps [rsp], xmm9
00007aa9b5fda43a  movaps [rsp+0x10], xmm10
00007aa9b5fda440  movaps [rsp+0x20], xmm8
00007aa9b5fda446  lea rdi, [rsp]
00007aa9b5fda44a  mov esi, 0x00
00007aa9b5fda44f  mov rax, 0x63E0217C9530
00007aa9b5fda459  call rax
00007aa9b5fda45b  movaps xmm9, [rsp]
00007aa9b5fda460  add rsp, 0x30
00007aa9b5fda464  vmovaps xmm0, [rsp]
00007aa9b5fda469  vmovaps xmm1, [rsp+0x10]
00007aa9b5fda46f  vmovaps xmm2, [rsp+0x20]
00007aa9b5fda475  vmovaps xmm3, [rsp+0x30]
00007aa9b5fda47b  vmovaps xmm4, [rsp+0x40]
00007aa9b5fda481  vmovaps xmm5, [rsp+0x50]
00007aa9b5fda487  vmovaps xmm6, [rsp+0x60]
00007aa9b5fda48d  vmovaps xmm7, [rsp+0x70]
00007aa9b5fda493  vmovaps xmm8, [rsp+0x80]
00007aa9b5fda49c  vmovaps xmm10, [rsp+0x90]
00007aa9b5fda4a5  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fda4ae  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fda4b7  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fda4c0  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fda4c9  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fda4d2  add rsp, 0xF0
00007aa9b5fda4d9  pop r11
00007aa9b5fda4db  pop r10
00007aa9b5fda4dd  pop r9
00007aa9b5fda4df  pop r8
00007aa9b5fda4e1  pop rsi
00007aa9b5fda4e2  pop rdi
00007aa9b5fda4e3  pop rdx
00007aa9b5fda4e4  pop rcx
00007aa9b5fda4e5  pop rax
00007aa9b5fda4e6  add rsp, 0x08
00007aa9b5fda4ea  jmp 0x00007AA9B5FD8CDB
00007aa9b5fda4ef  call 0x00007AA9B5ED64F0
00007aa9b5fda4f4  jmp 0x00007AA9B5FD8DF5
00007aa9b5fda4f9  call 0x00007AA9B5ED64F0
00007aa9b5fda4fe  jmp 0x00007AA9B5FD8E0B
00007aa9b5fda503  sub rsp, 0x08
00007aa9b5fda507  push rax
00007aa9b5fda508  push rcx
00007aa9b5fda509  push rdx
00007aa9b5fda50a  push rdi
00007aa9b5fda50b  push rsi
00007aa9b5fda50c  push r8
00007aa9b5fda50e  push r9
00007aa9b5fda510  push r10
00007aa9b5fda512  push r11
00007aa9b5fda514  sub rsp, 0xF0
00007aa9b5fda51b  vmovaps [rsp], xmm0
00007aa9b5fda520  vmovaps [rsp+0x10], xmm2
00007aa9b5fda526  vmovaps [rsp+0x20], xmm3
00007aa9b5fda52c  vmovaps [rsp+0x30], xmm4
00007aa9b5fda532  vmovaps [rsp+0x40], xmm5
00007aa9b5fda538  vmovaps [rsp+0x50], xmm6
00007aa9b5fda53e  vmovaps [rsp+0x60], xmm7
00007aa9b5fda544  vmovaps [rsp+0x70], xmm8
00007aa9b5fda54a  vmovaps [rsp+0x80], xmm9
00007aa9b5fda553  vmovaps [rsp+0x90], xmm10
00007aa9b5fda55c  vmovaps [rsp+0xA0], xmm11
00007aa9b5fda565  vmovaps [rsp+0xB0], xmm12
00007aa9b5fda56e  vmovaps [rsp+0xC0], xmm13
00007aa9b5fda577  vmovaps [rsp+0xD0], xmm14
00007aa9b5fda580  vmovaps [rsp+0xE0], xmm15
00007aa9b5fda589  sub rsp, 0x30
00007aa9b5fda58d  movaps [rsp], xmm1
00007aa9b5fda591  movaps [rsp+0x10], xmm6
00007aa9b5fda596  movaps [rsp+0x20], xmm15
00007aa9b5fda59c  lea rdi, [rsp]
00007aa9b5fda5a0  mov esi, 0x00
00007aa9b5fda5a5  mov rax, 0x63E0217C9530
00007aa9b5fda5af  call rax
00007aa9b5fda5b1  movaps xmm1, [rsp]
00007aa9b5fda5b5  add rsp, 0x30
00007aa9b5fda5b9  vmovaps xmm0, [rsp]
00007aa9b5fda5be  vmovaps xmm2, [rsp+0x10]
00007aa9b5fda5c4  vmovaps xmm3, [rsp+0x20]
00007aa9b5fda5ca  vmovaps xmm4, [rsp+0x30]
00007aa9b5fda5d0  vmovaps xmm5, [rsp+0x40]
00007aa9b5fda5d6  vmovaps xmm6, [rsp+0x50]
00007aa9b5fda5dc  vmovaps xmm7, [rsp+0x60]
00007aa9b5fda5e2  vmovaps xmm8, [rsp+0x70]
00007aa9b5fda5e8  vmovaps xmm9, [rsp+0x80]
00007aa9b5fda5f1  vmovaps xmm10, [rsp+0x90]
00007aa9b5fda5fa  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fda603  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fda60c  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fda615  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fda61e  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fda627  add rsp, 0xF0
00007aa9b5fda62e  pop r11
00007aa9b5fda630  pop r10
00007aa9b5fda632  pop r9
00007aa9b5fda634  pop r8
00007aa9b5fda636  pop rsi
00007aa9b5fda637  pop rdi
00007aa9b5fda638  pop rdx
00007aa9b5fda639  pop rcx
00007aa9b5fda63a  pop rax
00007aa9b5fda63b  add rsp, 0x08
00007aa9b5fda63f  jmp 0x00007AA9B5FD8E48
00007aa9b5fda644  call 0x00007AA9B5EE5820
00007aa9b5fda649  jmp 0x00007AA9B5FD8E55
00007aa9b5fda64e  sub rsp, 0x08
00007aa9b5fda652  push rax
00007aa9b5fda653  push rcx
00007aa9b5fda654  push rdx
00007aa9b5fda655  push rdi
00007aa9b5fda656  push rsi
00007aa9b5fda657  push r8
00007aa9b5fda659  push r9
00007aa9b5fda65b  push r10
00007aa9b5fda65d  push r11
00007aa9b5fda65f  sub rsp, 0xF0
00007aa9b5fda666  vmovaps [rsp], xmm0
00007aa9b5fda66b  vmovaps [rsp+0x10], xmm1
00007aa9b5fda671  vmovaps [rsp+0x20], xmm2
00007aa9b5fda677  vmovaps [rsp+0x30], xmm3
00007aa9b5fda67d  vmovaps [rsp+0x40], xmm4
00007aa9b5fda683  vmovaps [rsp+0x50], xmm5
00007aa9b5fda689  vmovaps [rsp+0x60], xmm6
00007aa9b5fda68f  vmovaps [rsp+0x70], xmm7
00007aa9b5fda695  vmovaps [rsp+0x80], xmm8
00007aa9b5fda69e  vmovaps [rsp+0x90], xmm9
00007aa9b5fda6a7  vmovaps [rsp+0xA0], xmm10
00007aa9b5fda6b0  vmovaps [rsp+0xB0], xmm11
00007aa9b5fda6b9  vmovaps [rsp+0xC0], xmm12
00007aa9b5fda6c2  vmovaps [rsp+0xD0], xmm13
00007aa9b5fda6cb  vmovaps [rsp+0xE0], xmm15
00007aa9b5fda6d4  sub rsp, 0x30
00007aa9b5fda6d8  movaps [rsp], xmm14
00007aa9b5fda6dd  movaps [rsp+0x10], xmm4
00007aa9b5fda6e2  movaps [rsp+0x20], xmm3
00007aa9b5fda6e7  lea rdi, [rsp]
00007aa9b5fda6eb  mov esi, 0x00
00007aa9b5fda6f0  mov rax, 0x63E0217C9530
00007aa9b5fda6fa  call rax
00007aa9b5fda6fc  movaps xmm14, [rsp]
00007aa9b5fda701  add rsp, 0x30
00007aa9b5fda705  vmovaps xmm0, [rsp]
00007aa9b5fda70a  vmovaps xmm1, [rsp+0x10]
00007aa9b5fda710  vmovaps xmm2, [rsp+0x20]
00007aa9b5fda716  vmovaps xmm3, [rsp+0x30]
00007aa9b5fda71c  vmovaps xmm4, [rsp+0x40]
00007aa9b5fda722  vmovaps xmm5, [rsp+0x50]
00007aa9b5fda728  vmovaps xmm6, [rsp+0x60]
00007aa9b5fda72e  vmovaps xmm7, [rsp+0x70]
00007aa9b5fda734  vmovaps xmm8, [rsp+0x80]
00007aa9b5fda73d  vmovaps xmm9, [rsp+0x90]
00007aa9b5fda746  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fda74f  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fda758  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fda761  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fda76a  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fda773  add rsp, 0xF0
00007aa9b5fda77a  pop r11
00007aa9b5fda77c  pop r10
00007aa9b5fda77e  pop r9
00007aa9b5fda780  pop r8
00007aa9b5fda782  pop rsi
00007aa9b5fda783  pop rdi
00007aa9b5fda784  pop rdx
00007aa9b5fda785  pop rcx
00007aa9b5fda786  pop rax
00007aa9b5fda787  add rsp, 0x08
00007aa9b5fda78b  jmp 0x00007AA9B5FD8E6F
00007aa9b5fda790  sub rsp, 0x08
00007aa9b5fda794  push rax
00007aa9b5fda795  push rcx
00007aa9b5fda796  push rdx
00007aa9b5fda797  push rdi
00007aa9b5fda798  push rsi
00007aa9b5fda799  push r8
00007aa9b5fda79b  push r9
00007aa9b5fda79d  push r10
00007aa9b5fda79f  push r11
00007aa9b5fda7a1  sub rsp, 0xF0
00007aa9b5fda7a8  vmovaps [rsp], xmm0
00007aa9b5fda7ad  vmovaps [rsp+0x10], xmm1
00007aa9b5fda7b3  vmovaps [rsp+0x20], xmm2
00007aa9b5fda7b9  vmovaps [rsp+0x30], xmm3
00007aa9b5fda7bf  vmovaps [rsp+0x40], xmm4
00007aa9b5fda7c5  vmovaps [rsp+0x50], xmm5
00007aa9b5fda7cb  vmovaps [rsp+0x60], xmm7
00007aa9b5fda7d1  vmovaps [rsp+0x70], xmm8
00007aa9b5fda7d7  vmovaps [rsp+0x80], xmm9
00007aa9b5fda7e0  vmovaps [rsp+0x90], xmm10
00007aa9b5fda7e9  vmovaps [rsp+0xA0], xmm11
00007aa9b5fda7f2  vmovaps [rsp+0xB0], xmm12
00007aa9b5fda7fb  vmovaps [rsp+0xC0], xmm13
00007aa9b5fda804  vmovaps [rsp+0xD0], xmm14
00007aa9b5fda80d  vmovaps [rsp+0xE0], xmm15
00007aa9b5fda816  sub rsp, 0x30
00007aa9b5fda81a  movaps [rsp], xmm6
00007aa9b5fda81e  movaps [rsp+0x10], xmm9
00007aa9b5fda824  movaps [rsp+0x20], xmm7
00007aa9b5fda829  lea rdi, [rsp]
00007aa9b5fda82d  mov esi, 0x00
00007aa9b5fda832  mov rax, 0x63E0217C9530
00007aa9b5fda83c  call rax
00007aa9b5fda83e  movaps xmm6, [rsp]
00007aa9b5fda842  add rsp, 0x30
00007aa9b5fda846  vmovaps xmm0, [rsp]
00007aa9b5fda84b  vmovaps xmm1, [rsp+0x10]
00007aa9b5fda851  vmovaps xmm2, [rsp+0x20]
00007aa9b5fda857  vmovaps xmm3, [rsp+0x30]
00007aa9b5fda85d  vmovaps xmm4, [rsp+0x40]
00007aa9b5fda863  vmovaps xmm5, [rsp+0x50]
00007aa9b5fda869  vmovaps xmm7, [rsp+0x60]
00007aa9b5fda86f  vmovaps xmm8, [rsp+0x70]
00007aa9b5fda875  vmovaps xmm9, [rsp+0x80]
00007aa9b5fda87e  vmovaps xmm10, [rsp+0x90]
00007aa9b5fda887  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fda890  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fda899  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fda8a2  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fda8ab  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fda8b4  add rsp, 0xF0
00007aa9b5fda8bb  pop r11
00007aa9b5fda8bd  pop r10
00007aa9b5fda8bf  pop r9
00007aa9b5fda8c1  pop r8
00007aa9b5fda8c3  pop rsi
00007aa9b5fda8c4  pop rdi
00007aa9b5fda8c5  pop rdx
00007aa9b5fda8c6  pop rcx
00007aa9b5fda8c7  pop rax
00007aa9b5fda8c8  add rsp, 0x08
00007aa9b5fda8cc  jmp 0x00007AA9B5FD8E87
00007aa9b5fda8d1  sub rsp, 0x08
00007aa9b5fda8d5  push rax
00007aa9b5fda8d6  push rcx
00007aa9b5fda8d7  push rdx
00007aa9b5fda8d8  push rdi
00007aa9b5fda8d9  push rsi
00007aa9b5fda8da  push r8
00007aa9b5fda8dc  push r9
00007aa9b5fda8de  push r10
00007aa9b5fda8e0  push r11
00007aa9b5fda8e2  sub rsp, 0xF0
00007aa9b5fda8e9  vmovaps [rsp], xmm0
00007aa9b5fda8ee  vmovaps [rsp+0x10], xmm1
00007aa9b5fda8f4  vmovaps [rsp+0x20], xmm2
00007aa9b5fda8fa  vmovaps [rsp+0x30], xmm3
00007aa9b5fda900  vmovaps [rsp+0x40], xmm4
00007aa9b5fda906  vmovaps [rsp+0x50], xmm5
00007aa9b5fda90c  vmovaps [rsp+0x60], xmm6
00007aa9b5fda912  vmovaps [rsp+0x70], xmm8
00007aa9b5fda918  vmovaps [rsp+0x80], xmm9
00007aa9b5fda921  vmovaps [rsp+0x90], xmm10
00007aa9b5fda92a  vmovaps [rsp+0xA0], xmm11
00007aa9b5fda933  vmovaps [rsp+0xB0], xmm12
00007aa9b5fda93c  vmovaps [rsp+0xC0], xmm13
00007aa9b5fda945  vmovaps [rsp+0xD0], xmm14
00007aa9b5fda94e  vmovaps [rsp+0xE0], xmm15
00007aa9b5fda957  sub rsp, 0x30
00007aa9b5fda95b  movaps [rsp], xmm7
00007aa9b5fda95f  movaps [rsp+0x10], xmm4
00007aa9b5fda964  movaps [rsp+0x20], xmm9
00007aa9b5fda96a  lea rdi, [rsp]
00007aa9b5fda96e  mov esi, 0x00
00007aa9b5fda973  mov rax, 0x63E0217C9530
00007aa9b5fda97d  call rax
00007aa9b5fda97f  movaps xmm7, [rsp]
00007aa9b5fda983  add rsp, 0x30
00007aa9b5fda987  vmovaps xmm0, [rsp]
00007aa9b5fda98c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fda992  vmovaps xmm2, [rsp+0x20]
00007aa9b5fda998  vmovaps xmm3, [rsp+0x30]
00007aa9b5fda99e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fda9a4  vmovaps xmm5, [rsp+0x50]
00007aa9b5fda9aa  vmovaps xmm6, [rsp+0x60]
00007aa9b5fda9b0  vmovaps xmm8, [rsp+0x70]
00007aa9b5fda9b6  vmovaps xmm9, [rsp+0x80]
00007aa9b5fda9bf  vmovaps xmm10, [rsp+0x90]
00007aa9b5fda9c8  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fda9d1  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fda9da  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fda9e3  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fda9ec  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fda9f5  add rsp, 0xF0
00007aa9b5fda9fc  pop r11
00007aa9b5fda9fe  pop r10
00007aa9b5fdaa00  pop r9
00007aa9b5fdaa02  pop r8
00007aa9b5fdaa04  pop rsi
00007aa9b5fdaa05  pop rdi
00007aa9b5fdaa06  pop rdx
00007aa9b5fdaa07  pop rcx
00007aa9b5fdaa08  pop rax
00007aa9b5fdaa09  add rsp, 0x08
00007aa9b5fdaa0d  jmp 0x00007AA9B5FD8EB4
00007aa9b5fdaa12  sub rsp, 0x08
00007aa9b5fdaa16  push rax
00007aa9b5fdaa17  push rcx
00007aa9b5fdaa18  push rdx
00007aa9b5fdaa19  push rdi
00007aa9b5fdaa1a  push rsi
00007aa9b5fdaa1b  push r8
00007aa9b5fdaa1d  push r9
00007aa9b5fdaa1f  push r10
00007aa9b5fdaa21  push r11
00007aa9b5fdaa23  sub rsp, 0xF0
00007aa9b5fdaa2a  vmovaps [rsp], xmm0
00007aa9b5fdaa2f  vmovaps [rsp+0x10], xmm1
00007aa9b5fdaa35  vmovaps [rsp+0x20], xmm2
00007aa9b5fdaa3b  vmovaps [rsp+0x30], xmm3
00007aa9b5fdaa41  vmovaps [rsp+0x40], xmm5
00007aa9b5fdaa47  vmovaps [rsp+0x50], xmm6
00007aa9b5fdaa4d  vmovaps [rsp+0x60], xmm7
00007aa9b5fdaa53  vmovaps [rsp+0x70], xmm8
00007aa9b5fdaa59  vmovaps [rsp+0x80], xmm9
00007aa9b5fdaa62  vmovaps [rsp+0x90], xmm10
00007aa9b5fdaa6b  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdaa74  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdaa7d  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdaa86  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdaa8f  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdaa98  sub rsp, 0x30
00007aa9b5fdaa9c  movaps [rsp], xmm4
00007aa9b5fdaaa0  movaps [rsp+0x10], xmm15
00007aa9b5fdaaa6  movaps [rsp+0x20], xmm9
00007aa9b5fdaaac  lea rdi, [rsp]
00007aa9b5fdaab0  mov esi, 0x00
00007aa9b5fdaab5  mov rax, 0x63E0217C9530
00007aa9b5fdaabf  call rax
00007aa9b5fdaac1  movaps xmm4, [rsp]
00007aa9b5fdaac5  add rsp, 0x30
00007aa9b5fdaac9  vmovaps xmm0, [rsp]
00007aa9b5fdaace  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdaad4  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdaada  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdaae0  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdaae6  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdaaec  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdaaf2  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdaaf8  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdab01  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdab0a  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdab13  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdab1c  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdab25  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdab2e  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdab37  add rsp, 0xF0
00007aa9b5fdab3e  pop r11
00007aa9b5fdab40  pop r10
00007aa9b5fdab42  pop r9
00007aa9b5fdab44  pop r8
00007aa9b5fdab46  pop rsi
00007aa9b5fdab47  pop rdi
00007aa9b5fdab48  pop rdx
00007aa9b5fdab49  pop rcx
00007aa9b5fdab4a  pop rax
00007aa9b5fdab4b  add rsp, 0x08
00007aa9b5fdab4f  jmp 0x00007AA9B5FD8ED9
00007aa9b5fdab54  call 0x00007AA9B5EE5820
00007aa9b5fdab59  jmp 0x00007AA9B5FD8EE6
00007aa9b5fdab5e  sub rsp, 0x08
00007aa9b5fdab62  push rax
00007aa9b5fdab63  push rcx
00007aa9b5fdab64  push rdx
00007aa9b5fdab65  push rdi
00007aa9b5fdab66  push rsi
00007aa9b5fdab67  push r8
00007aa9b5fdab69  push r9
00007aa9b5fdab6b  push r10
00007aa9b5fdab6d  push r11
00007aa9b5fdab6f  sub rsp, 0xF0
00007aa9b5fdab76  vmovaps [rsp], xmm0
00007aa9b5fdab7b  vmovaps [rsp+0x10], xmm1
00007aa9b5fdab81  vmovaps [rsp+0x20], xmm2
00007aa9b5fdab87  vmovaps [rsp+0x30], xmm4
00007aa9b5fdab8d  vmovaps [rsp+0x40], xmm5
00007aa9b5fdab93  vmovaps [rsp+0x50], xmm6
00007aa9b5fdab99  vmovaps [rsp+0x60], xmm7
00007aa9b5fdab9f  vmovaps [rsp+0x70], xmm8
00007aa9b5fdaba5  vmovaps [rsp+0x80], xmm9
00007aa9b5fdabae  vmovaps [rsp+0x90], xmm10
00007aa9b5fdabb7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdabc0  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdabc9  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdabd2  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdabdb  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdabe4  sub rsp, 0x30
00007aa9b5fdabe8  movaps [rsp], xmm3
00007aa9b5fdabec  movaps [rsp+0x10], xmm1
00007aa9b5fdabf1  movaps [rsp+0x20], xmm9
00007aa9b5fdabf7  lea rdi, [rsp]
00007aa9b5fdabfb  mov esi, 0x00
00007aa9b5fdac00  mov rax, 0x63E0217C9530
00007aa9b5fdac0a  call rax
00007aa9b5fdac0c  movaps xmm3, [rsp]
00007aa9b5fdac10  add rsp, 0x30
00007aa9b5fdac14  vmovaps xmm0, [rsp]
00007aa9b5fdac19  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdac1f  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdac25  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdac2b  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdac31  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdac37  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdac3d  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdac43  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdac4c  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdac55  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdac5e  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdac67  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdac70  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdac79  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdac82  add rsp, 0xF0
00007aa9b5fdac89  pop r11
00007aa9b5fdac8b  pop r10
00007aa9b5fdac8d  pop r9
00007aa9b5fdac8f  pop r8
00007aa9b5fdac91  pop rsi
00007aa9b5fdac92  pop rdi
00007aa9b5fdac93  pop rdx
00007aa9b5fdac94  pop rcx
00007aa9b5fdac95  pop rax
00007aa9b5fdac96  add rsp, 0x08
00007aa9b5fdac9a  jmp 0x00007AA9B5FD8F23
00007aa9b5fdac9f  sub rsp, 0x08
00007aa9b5fdaca3  push rax
00007aa9b5fdaca4  push rcx
00007aa9b5fdaca5  push rdx
00007aa9b5fdaca6  push rdi
00007aa9b5fdaca7  push rsi
00007aa9b5fdaca8  push r8
00007aa9b5fdacaa  push r9
00007aa9b5fdacac  push r10
00007aa9b5fdacae  push r11
00007aa9b5fdacb0  sub rsp, 0xF0
00007aa9b5fdacb7  vmovaps [rsp], xmm0
00007aa9b5fdacbc  vmovaps [rsp+0x10], xmm2
00007aa9b5fdacc2  vmovaps [rsp+0x20], xmm3
00007aa9b5fdacc8  vmovaps [rsp+0x30], xmm4
00007aa9b5fdacce  vmovaps [rsp+0x40], xmm5
00007aa9b5fdacd4  vmovaps [rsp+0x50], xmm6
00007aa9b5fdacda  vmovaps [rsp+0x60], xmm7
00007aa9b5fdace0  vmovaps [rsp+0x70], xmm8
00007aa9b5fdace6  vmovaps [rsp+0x80], xmm9
00007aa9b5fdacef  vmovaps [rsp+0x90], xmm10
00007aa9b5fdacf8  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdad01  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdad0a  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdad13  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdad1c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdad25  sub rsp, 0x30
00007aa9b5fdad29  movaps [rsp], xmm1
00007aa9b5fdad2d  movaps [rsp+0x10], xmm15
00007aa9b5fdad33  movaps [rsp+0x20], xmm9
00007aa9b5fdad39  lea rdi, [rsp]
00007aa9b5fdad3d  mov esi, 0x00
00007aa9b5fdad42  mov rax, 0x63E0217C9530
00007aa9b5fdad4c  call rax
00007aa9b5fdad4e  movaps xmm1, [rsp]
00007aa9b5fdad52  add rsp, 0x30
00007aa9b5fdad56  vmovaps xmm0, [rsp]
00007aa9b5fdad5b  vmovaps xmm2, [rsp+0x10]
00007aa9b5fdad61  vmovaps xmm3, [rsp+0x20]
00007aa9b5fdad67  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdad6d  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdad73  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdad79  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdad7f  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdad85  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdad8e  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdad97  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdada0  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdada9  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdadb2  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdadbb  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdadc4  add rsp, 0xF0
00007aa9b5fdadcb  pop r11
00007aa9b5fdadcd  pop r10
00007aa9b5fdadcf  pop r9
00007aa9b5fdadd1  pop r8
00007aa9b5fdadd3  pop rsi
00007aa9b5fdadd4  pop rdi
00007aa9b5fdadd5  pop rdx
00007aa9b5fdadd6  pop rcx
00007aa9b5fdadd7  pop rax
00007aa9b5fdadd8  add rsp, 0x08
00007aa9b5fdaddc  jmp 0x00007AA9B5FD8FAB
00007aa9b5fdade1  call 0x00007AA9B5EE5820
00007aa9b5fdade6  jmp 0x00007AA9B5FD8FB8
00007aa9b5fdadeb  sub rsp, 0x08
00007aa9b5fdadef  push rax
00007aa9b5fdadf0  push rcx
00007aa9b5fdadf1  push rdx
00007aa9b5fdadf2  push rdi
00007aa9b5fdadf3  push rsi
00007aa9b5fdadf4  push r8
00007aa9b5fdadf6  push r9
00007aa9b5fdadf8  push r10
00007aa9b5fdadfa  push r11
00007aa9b5fdadfc  sub rsp, 0xF0
00007aa9b5fdae03  vmovaps [rsp], xmm0
00007aa9b5fdae08  vmovaps [rsp+0x10], xmm2
00007aa9b5fdae0e  vmovaps [rsp+0x20], xmm3
00007aa9b5fdae14  vmovaps [rsp+0x30], xmm4
00007aa9b5fdae1a  vmovaps [rsp+0x40], xmm5
00007aa9b5fdae20  vmovaps [rsp+0x50], xmm6
00007aa9b5fdae26  vmovaps [rsp+0x60], xmm7
00007aa9b5fdae2c  vmovaps [rsp+0x70], xmm8
00007aa9b5fdae32  vmovaps [rsp+0x80], xmm9
00007aa9b5fdae3b  vmovaps [rsp+0x90], xmm10
00007aa9b5fdae44  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdae4d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdae56  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdae5f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdae68  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdae71  sub rsp, 0x30
00007aa9b5fdae75  movaps [rsp], xmm1
00007aa9b5fdae79  movaps [rsp+0x10], xmm5
00007aa9b5fdae7e  movaps [rsp+0x20], xmm7
00007aa9b5fdae83  lea rdi, [rsp]
00007aa9b5fdae87  mov esi, 0x00
00007aa9b5fdae8c  mov rax, 0x63E0217C9530
00007aa9b5fdae96  call rax
00007aa9b5fdae98  movaps xmm1, [rsp]
00007aa9b5fdae9c  add rsp, 0x30
00007aa9b5fdaea0  vmovaps xmm0, [rsp]
00007aa9b5fdaea5  vmovaps xmm2, [rsp+0x10]
00007aa9b5fdaeab  vmovaps xmm3, [rsp+0x20]
00007aa9b5fdaeb1  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdaeb7  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdaebd  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdaec3  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdaec9  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdaecf  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdaed8  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdaee1  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdaeea  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdaef3  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdaefc  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdaf05  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdaf0e  add rsp, 0xF0
00007aa9b5fdaf15  pop r11
00007aa9b5fdaf17  pop r10
00007aa9b5fdaf19  pop r9
00007aa9b5fdaf1b  pop r8
00007aa9b5fdaf1d  pop rsi
00007aa9b5fdaf1e  pop rdi
00007aa9b5fdaf1f  pop rdx
00007aa9b5fdaf20  pop rcx
00007aa9b5fdaf21  pop rax
00007aa9b5fdaf22  add rsp, 0x08
00007aa9b5fdaf26  jmp 0x00007AA9B5FD905D
00007aa9b5fdaf2b  sub rsp, 0x08
00007aa9b5fdaf2f  push rax
00007aa9b5fdaf30  push rcx
00007aa9b5fdaf31  push rdx
00007aa9b5fdaf32  push rdi
00007aa9b5fdaf33  push rsi
00007aa9b5fdaf34  push r8
00007aa9b5fdaf36  push r9
00007aa9b5fdaf38  push r10
00007aa9b5fdaf3a  push r11
00007aa9b5fdaf3c  sub rsp, 0xF0
00007aa9b5fdaf43  vmovaps [rsp], xmm0
00007aa9b5fdaf48  vmovaps [rsp+0x10], xmm1
00007aa9b5fdaf4e  vmovaps [rsp+0x20], xmm2
00007aa9b5fdaf54  vmovaps [rsp+0x30], xmm3
00007aa9b5fdaf5a  vmovaps [rsp+0x40], xmm4
00007aa9b5fdaf60  vmovaps [rsp+0x50], xmm5
00007aa9b5fdaf66  vmovaps [rsp+0x60], xmm6
00007aa9b5fdaf6c  vmovaps [rsp+0x70], xmm8
00007aa9b5fdaf72  vmovaps [rsp+0x80], xmm9
00007aa9b5fdaf7b  vmovaps [rsp+0x90], xmm10
00007aa9b5fdaf84  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdaf8d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdaf96  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdaf9f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdafa8  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdafb1  sub rsp, 0x30
00007aa9b5fdafb5  movaps [rsp], xmm7
00007aa9b5fdafb9  movaps [rsp+0x10], xmm5
00007aa9b5fdafbe  movaps [rsp+0x20], xmm15
00007aa9b5fdafc4  lea rdi, [rsp]
00007aa9b5fdafc8  mov esi, 0x00
00007aa9b5fdafcd  mov rax, 0x63E0217C9530
00007aa9b5fdafd7  call rax
00007aa9b5fdafd9  movaps xmm7, [rsp]
00007aa9b5fdafdd  add rsp, 0x30
00007aa9b5fdafe1  vmovaps xmm0, [rsp]
00007aa9b5fdafe6  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdafec  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdaff2  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdaff8  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdaffe  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdb004  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdb00a  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdb010  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdb019  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdb022  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdb02b  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdb034  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdb03d  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdb046  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdb04f  add rsp, 0xF0
00007aa9b5fdb056  pop r11
00007aa9b5fdb058  pop r10
00007aa9b5fdb05a  pop r9
00007aa9b5fdb05c  pop r8
00007aa9b5fdb05e  pop rsi
00007aa9b5fdb05f  pop rdi
00007aa9b5fdb060  pop rdx
00007aa9b5fdb061  pop rcx
00007aa9b5fdb062  pop rax
00007aa9b5fdb063  add rsp, 0x08
00007aa9b5fdb067  jmp 0x00007AA9B5FD9093
00007aa9b5fdb06c  call 0x00007AA9B5ED64F0
00007aa9b5fdb071  jmp 0x00007AA9B5FD90A0
00007aa9b5fdb076  sub rsp, 0x08
00007aa9b5fdb07a  push rax
00007aa9b5fdb07b  push rcx
00007aa9b5fdb07c  push rdx
00007aa9b5fdb07d  push rdi
00007aa9b5fdb07e  push rsi
00007aa9b5fdb07f  push r8
00007aa9b5fdb081  push r9
00007aa9b5fdb083  push r10
00007aa9b5fdb085  push r11
00007aa9b5fdb087  sub rsp, 0xF0
00007aa9b5fdb08e  vmovaps [rsp], xmm0
00007aa9b5fdb093  vmovaps [rsp+0x10], xmm1
00007aa9b5fdb099  vmovaps [rsp+0x20], xmm2
00007aa9b5fdb09f  vmovaps [rsp+0x30], xmm3
00007aa9b5fdb0a5  vmovaps [rsp+0x40], xmm4
00007aa9b5fdb0ab  vmovaps [rsp+0x50], xmm5
00007aa9b5fdb0b1  vmovaps [rsp+0x60], xmm6
00007aa9b5fdb0b7  vmovaps [rsp+0x70], xmm7
00007aa9b5fdb0bd  vmovaps [rsp+0x80], xmm8
00007aa9b5fdb0c6  vmovaps [rsp+0x90], xmm9
00007aa9b5fdb0cf  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdb0d8  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdb0e1  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdb0ea  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdb0f3  vmovaps [rsp+0xE0], xmm14
00007aa9b5fdb0fc  sub rsp, 0x30
00007aa9b5fdb100  movaps [rsp], xmm15
00007aa9b5fdb105  movaps [rsp+0x10], xmm5
00007aa9b5fdb10a  movaps [rsp+0x20], xmm3
00007aa9b5fdb10f  lea rdi, [rsp]
00007aa9b5fdb113  mov esi, 0x00
00007aa9b5fdb118  mov rax, 0x63E0217C9530
00007aa9b5fdb122  call rax
00007aa9b5fdb124  movaps xmm15, [rsp]
00007aa9b5fdb129  add rsp, 0x30
00007aa9b5fdb12d  vmovaps xmm0, [rsp]
00007aa9b5fdb132  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdb138  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdb13e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdb144  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdb14a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdb150  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdb156  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdb15c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdb165  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdb16e  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdb177  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdb180  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdb189  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdb192  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fdb19b  add rsp, 0xF0
00007aa9b5fdb1a2  pop r11
00007aa9b5fdb1a4  pop r10
00007aa9b5fdb1a6  pop r9
00007aa9b5fdb1a8  pop r8
00007aa9b5fdb1aa  pop rsi
00007aa9b5fdb1ab  pop rdi
00007aa9b5fdb1ac  pop rdx
00007aa9b5fdb1ad  pop rcx
00007aa9b5fdb1ae  pop rax
00007aa9b5fdb1af  add rsp, 0x08
00007aa9b5fdb1b3  jmp 0x00007AA9B5FD90C6
00007aa9b5fdb1b8  sub rsp, 0x08
00007aa9b5fdb1bc  push rax
00007aa9b5fdb1bd  push rcx
00007aa9b5fdb1be  push rdx
00007aa9b5fdb1bf  push rdi
00007aa9b5fdb1c0  push rsi
00007aa9b5fdb1c1  push r8
00007aa9b5fdb1c3  push r9
00007aa9b5fdb1c5  push r10
00007aa9b5fdb1c7  push r11
00007aa9b5fdb1c9  sub rsp, 0xF0
00007aa9b5fdb1d0  vmovaps [rsp], xmm0
00007aa9b5fdb1d5  vmovaps [rsp+0x10], xmm2
00007aa9b5fdb1db  vmovaps [rsp+0x20], xmm3
00007aa9b5fdb1e1  vmovaps [rsp+0x30], xmm4
00007aa9b5fdb1e7  vmovaps [rsp+0x40], xmm5
00007aa9b5fdb1ed  vmovaps [rsp+0x50], xmm6
00007aa9b5fdb1f3  vmovaps [rsp+0x60], xmm7
00007aa9b5fdb1f9  vmovaps [rsp+0x70], xmm8
00007aa9b5fdb1ff  vmovaps [rsp+0x80], xmm9
00007aa9b5fdb208  vmovaps [rsp+0x90], xmm10
00007aa9b5fdb211  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdb21a  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdb223  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdb22c  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdb235  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdb23e  sub rsp, 0x30
00007aa9b5fdb242  movaps [rsp], xmm1
00007aa9b5fdb246  movaps [rsp+0x10], xmm5
00007aa9b5fdb24b  movaps [rsp+0x20], xmm4
00007aa9b5fdb250  lea rdi, [rsp]
00007aa9b5fdb254  mov esi, 0x00
00007aa9b5fdb259  mov rax, 0x63E0217C9530
00007aa9b5fdb263  call rax
00007aa9b5fdb265  movaps xmm1, [rsp]
00007aa9b5fdb269  add rsp, 0x30
00007aa9b5fdb26d  vmovaps xmm0, [rsp]
00007aa9b5fdb272  vmovaps xmm2, [rsp+0x10]
00007aa9b5fdb278  vmovaps xmm3, [rsp+0x20]
00007aa9b5fdb27e  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdb284  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdb28a  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdb290  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdb296  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdb29c  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdb2a5  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdb2ae  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdb2b7  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdb2c0  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdb2c9  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdb2d2  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdb2db  add rsp, 0xF0
00007aa9b5fdb2e2  pop r11
00007aa9b5fdb2e4  pop r10
00007aa9b5fdb2e6  pop r9
00007aa9b5fdb2e8  pop r8
00007aa9b5fdb2ea  pop rsi
00007aa9b5fdb2eb  pop rdi
00007aa9b5fdb2ec  pop rdx
00007aa9b5fdb2ed  pop rcx
00007aa9b5fdb2ee  pop rax
00007aa9b5fdb2ef  add rsp, 0x08
00007aa9b5fdb2f3  jmp 0x00007AA9B5FD90E6
00007aa9b5fdb2f8  sub rsp, 0x08
00007aa9b5fdb2fc  push rax
00007aa9b5fdb2fd  push rcx
00007aa9b5fdb2fe  push rdx
00007aa9b5fdb2ff  push rdi
00007aa9b5fdb300  push rsi
00007aa9b5fdb301  push r8
00007aa9b5fdb303  push r9
00007aa9b5fdb305  push r10
00007aa9b5fdb307  push r11
00007aa9b5fdb309  sub rsp, 0xF0
00007aa9b5fdb310  vmovaps [rsp], xmm0
00007aa9b5fdb315  vmovaps [rsp+0x10], xmm1
00007aa9b5fdb31b  vmovaps [rsp+0x20], xmm2
00007aa9b5fdb321  vmovaps [rsp+0x30], xmm3
00007aa9b5fdb327  vmovaps [rsp+0x40], xmm5
00007aa9b5fdb32d  vmovaps [rsp+0x50], xmm6
00007aa9b5fdb333  vmovaps [rsp+0x60], xmm7
00007aa9b5fdb339  vmovaps [rsp+0x70], xmm8
00007aa9b5fdb33f  vmovaps [rsp+0x80], xmm9
00007aa9b5fdb348  vmovaps [rsp+0x90], xmm10
00007aa9b5fdb351  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdb35a  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdb363  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdb36c  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdb375  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdb37e  sub rsp, 0x30
00007aa9b5fdb382  movaps [rsp], xmm4
00007aa9b5fdb386  movaps [rsp+0x10], xmm3
00007aa9b5fdb38b  movaps [rsp+0x20], xmm5
00007aa9b5fdb390  lea rdi, [rsp]
00007aa9b5fdb394  mov esi, 0x00
00007aa9b5fdb399  mov rax, 0x63E0217C9530
00007aa9b5fdb3a3  call rax
00007aa9b5fdb3a5  movaps xmm4, [rsp]
00007aa9b5fdb3a9  add rsp, 0x30
00007aa9b5fdb3ad  vmovaps xmm0, [rsp]
00007aa9b5fdb3b2  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdb3b8  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdb3be  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdb3c4  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdb3ca  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdb3d0  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdb3d6  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdb3dc  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdb3e5  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdb3ee  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdb3f7  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdb400  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdb409  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdb412  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdb41b  add rsp, 0xF0
00007aa9b5fdb422  pop r11
00007aa9b5fdb424  pop r10
00007aa9b5fdb426  pop r9
00007aa9b5fdb428  pop r8
00007aa9b5fdb42a  pop rsi
00007aa9b5fdb42b  pop rdi
00007aa9b5fdb42c  pop rdx
00007aa9b5fdb42d  pop rcx
00007aa9b5fdb42e  pop rax
00007aa9b5fdb42f  add rsp, 0x08
00007aa9b5fdb433  jmp 0x00007AA9B5FD9134
00007aa9b5fdb438  call 0x00007AA9B5ED64F0
00007aa9b5fdb43d  jmp 0x00007AA9B5FD9141
00007aa9b5fdb442  sub rsp, 0x08
00007aa9b5fdb446  push rax
00007aa9b5fdb447  push rcx
00007aa9b5fdb448  push rdx
00007aa9b5fdb449  push rdi
00007aa9b5fdb44a  push rsi
00007aa9b5fdb44b  push r8
00007aa9b5fdb44d  push r9
00007aa9b5fdb44f  push r10
00007aa9b5fdb451  push r11
00007aa9b5fdb453  sub rsp, 0xF0
00007aa9b5fdb45a  vmovaps [rsp], xmm0
00007aa9b5fdb45f  vmovaps [rsp+0x10], xmm1
00007aa9b5fdb465  vmovaps [rsp+0x20], xmm2
00007aa9b5fdb46b  vmovaps [rsp+0x30], xmm3
00007aa9b5fdb471  vmovaps [rsp+0x40], xmm4
00007aa9b5fdb477  vmovaps [rsp+0x50], xmm6
00007aa9b5fdb47d  vmovaps [rsp+0x60], xmm7
00007aa9b5fdb483  vmovaps [rsp+0x70], xmm8
00007aa9b5fdb489  vmovaps [rsp+0x80], xmm9
00007aa9b5fdb492  vmovaps [rsp+0x90], xmm10
00007aa9b5fdb49b  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdb4a4  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdb4ad  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdb4b6  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdb4bf  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdb4c8  sub rsp, 0x30
00007aa9b5fdb4cc  movaps [rsp], xmm5
00007aa9b5fdb4d0  movaps [rsp+0x10], xmm6
00007aa9b5fdb4d5  movaps [rsp+0x20], xmm3
00007aa9b5fdb4da  lea rdi, [rsp]
00007aa9b5fdb4de  mov esi, 0x00
00007aa9b5fdb4e3  mov rax, 0x63E0217C9530
00007aa9b5fdb4ed  call rax
00007aa9b5fdb4ef  movaps xmm5, [rsp]
00007aa9b5fdb4f3  add rsp, 0x30
00007aa9b5fdb4f7  vmovaps xmm0, [rsp]
00007aa9b5fdb4fc  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdb502  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdb508  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdb50e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdb514  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdb51a  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdb520  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdb526  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdb52f  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdb538  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdb541  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdb54a  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdb553  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdb55c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdb565  add rsp, 0xF0
00007aa9b5fdb56c  pop r11
00007aa9b5fdb56e  pop r10
00007aa9b5fdb570  pop r9
00007aa9b5fdb572  pop r8
00007aa9b5fdb574  pop rsi
00007aa9b5fdb575  pop rdi
00007aa9b5fdb576  pop rdx
00007aa9b5fdb577  pop rcx
00007aa9b5fdb578  pop rax
00007aa9b5fdb579  add rsp, 0x08
00007aa9b5fdb57d  jmp 0x00007AA9B5FD9167
00007aa9b5fdb582  sub rsp, 0x08
00007aa9b5fdb586  push rax
00007aa9b5fdb587  push rcx
00007aa9b5fdb588  push rdx
00007aa9b5fdb589  push rdi
00007aa9b5fdb58a  push rsi
00007aa9b5fdb58b  push r8
00007aa9b5fdb58d  push r9
00007aa9b5fdb58f  push r10
00007aa9b5fdb591  push r11
00007aa9b5fdb593  sub rsp, 0xF0
00007aa9b5fdb59a  vmovaps [rsp], xmm0
00007aa9b5fdb59f  vmovaps [rsp+0x10], xmm1
00007aa9b5fdb5a5  vmovaps [rsp+0x20], xmm2
00007aa9b5fdb5ab  vmovaps [rsp+0x30], xmm3
00007aa9b5fdb5b1  vmovaps [rsp+0x40], xmm4
00007aa9b5fdb5b7  vmovaps [rsp+0x50], xmm5
00007aa9b5fdb5bd  vmovaps [rsp+0x60], xmm7
00007aa9b5fdb5c3  vmovaps [rsp+0x70], xmm8
00007aa9b5fdb5c9  vmovaps [rsp+0x80], xmm9
00007aa9b5fdb5d2  vmovaps [rsp+0x90], xmm10
00007aa9b5fdb5db  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdb5e4  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdb5ed  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdb5f6  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdb5ff  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdb608  sub rsp, 0x30
00007aa9b5fdb60c  movaps [rsp], xmm6
00007aa9b5fdb610  movaps [rsp+0x10], xmm9
00007aa9b5fdb616  movaps [rsp+0x20], xmm1
00007aa9b5fdb61b  lea rdi, [rsp]
00007aa9b5fdb61f  mov esi, 0x00
00007aa9b5fdb624  mov rax, 0x63E0217C9530
00007aa9b5fdb62e  call rax
00007aa9b5fdb630  movaps xmm6, [rsp]
00007aa9b5fdb634  add rsp, 0x30
00007aa9b5fdb638  vmovaps xmm0, [rsp]
00007aa9b5fdb63d  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdb643  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdb649  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdb64f  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdb655  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdb65b  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdb661  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdb667  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdb670  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdb679  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdb682  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdb68b  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdb694  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdb69d  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdb6a6  add rsp, 0xF0
00007aa9b5fdb6ad  pop r11
00007aa9b5fdb6af  pop r10
00007aa9b5fdb6b1  pop r9
00007aa9b5fdb6b3  pop r8
00007aa9b5fdb6b5  pop rsi
00007aa9b5fdb6b6  pop rdi
00007aa9b5fdb6b7  pop rdx
00007aa9b5fdb6b8  pop rcx
00007aa9b5fdb6b9  pop rax
00007aa9b5fdb6ba  add rsp, 0x08
00007aa9b5fdb6be  jmp 0x00007AA9B5FD918B
00007aa9b5fdb6c3  sub rsp, 0x08
00007aa9b5fdb6c7  push rax
00007aa9b5fdb6c8  push rcx
00007aa9b5fdb6c9  push rdx
00007aa9b5fdb6ca  push rdi
00007aa9b5fdb6cb  push rsi
00007aa9b5fdb6cc  push r8
00007aa9b5fdb6ce  push r9
00007aa9b5fdb6d0  push r10
00007aa9b5fdb6d2  push r11
00007aa9b5fdb6d4  sub rsp, 0xF0
00007aa9b5fdb6db  vmovaps [rsp], xmm0
00007aa9b5fdb6e0  vmovaps [rsp+0x10], xmm1
00007aa9b5fdb6e6  vmovaps [rsp+0x20], xmm2
00007aa9b5fdb6ec  vmovaps [rsp+0x30], xmm3
00007aa9b5fdb6f2  vmovaps [rsp+0x40], xmm4
00007aa9b5fdb6f8  vmovaps [rsp+0x50], xmm5
00007aa9b5fdb6fe  vmovaps [rsp+0x60], xmm6
00007aa9b5fdb704  vmovaps [rsp+0x70], xmm7
00007aa9b5fdb70a  vmovaps [rsp+0x80], xmm8
00007aa9b5fdb713  vmovaps [rsp+0x90], xmm10
00007aa9b5fdb71c  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdb725  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdb72e  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdb737  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdb740  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdb749  sub rsp, 0x30
00007aa9b5fdb74d  movaps [rsp], xmm9
00007aa9b5fdb752  movaps [rsp+0x10], xmm3
00007aa9b5fdb757  movaps [rsp+0x20], xmm1
00007aa9b5fdb75c  lea rdi, [rsp]
00007aa9b5fdb760  mov esi, 0x00
00007aa9b5fdb765  mov rax, 0x63E0217C9530
00007aa9b5fdb76f  call rax
00007aa9b5fdb771  movaps xmm9, [rsp]
00007aa9b5fdb776  add rsp, 0x30
00007aa9b5fdb77a  vmovaps xmm0, [rsp]
00007aa9b5fdb77f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdb785  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdb78b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdb791  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdb797  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdb79d  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdb7a3  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdb7a9  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdb7b2  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdb7bb  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdb7c4  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdb7cd  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdb7d6  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdb7df  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdb7e8  add rsp, 0xF0
00007aa9b5fdb7ef  pop r11
00007aa9b5fdb7f1  pop r10
00007aa9b5fdb7f3  pop r9
00007aa9b5fdb7f5  pop r8
00007aa9b5fdb7f7  pop rsi
00007aa9b5fdb7f8  pop rdi
00007aa9b5fdb7f9  pop rdx
00007aa9b5fdb7fa  pop rcx
00007aa9b5fdb7fb  pop rax
00007aa9b5fdb7fc  add rsp, 0x08
00007aa9b5fdb800  jmp 0x00007AA9B5FD91D7
00007aa9b5fdb805  call 0x00007AA9B5ED64F0
00007aa9b5fdb80a  jmp 0x00007AA9B5FD91E4
00007aa9b5fdb80f  sub rsp, 0x08
00007aa9b5fdb813  push rax
00007aa9b5fdb814  push rcx
00007aa9b5fdb815  push rdx
00007aa9b5fdb816  push rdi
00007aa9b5fdb817  push rsi
00007aa9b5fdb818  push r8
00007aa9b5fdb81a  push r9
00007aa9b5fdb81c  push r10
00007aa9b5fdb81e  push r11
00007aa9b5fdb820  sub rsp, 0xF0
00007aa9b5fdb827  vmovaps [rsp], xmm0
00007aa9b5fdb82c  vmovaps [rsp+0x10], xmm1
00007aa9b5fdb832  vmovaps [rsp+0x20], xmm2
00007aa9b5fdb838  vmovaps [rsp+0x30], xmm3
00007aa9b5fdb83e  vmovaps [rsp+0x40], xmm4
00007aa9b5fdb844  vmovaps [rsp+0x50], xmm5
00007aa9b5fdb84a  vmovaps [rsp+0x60], xmm6
00007aa9b5fdb850  vmovaps [rsp+0x70], xmm7
00007aa9b5fdb856  vmovaps [rsp+0x80], xmm8
00007aa9b5fdb85f  vmovaps [rsp+0x90], xmm9
00007aa9b5fdb868  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdb871  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdb87a  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdb883  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdb88c  vmovaps [rsp+0xE0], xmm14
00007aa9b5fdb895  sub rsp, 0x30
00007aa9b5fdb899  movaps [rsp], xmm15
00007aa9b5fdb89e  movaps [rsp+0x10], xmm3
00007aa9b5fdb8a3  movaps [rsp+0x20], xmm7
00007aa9b5fdb8a8  lea rdi, [rsp]
00007aa9b5fdb8ac  mov esi, 0x00
00007aa9b5fdb8b1  mov rax, 0x63E0217C9530
00007aa9b5fdb8bb  call rax
00007aa9b5fdb8bd  movaps xmm15, [rsp]
00007aa9b5fdb8c2  add rsp, 0x30
00007aa9b5fdb8c6  vmovaps xmm0, [rsp]
00007aa9b5fdb8cb  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdb8d1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdb8d7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdb8dd  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdb8e3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdb8e9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdb8ef  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdb8f5  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdb8fe  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdb907  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdb910  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdb919  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdb922  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdb92b  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fdb934  add rsp, 0xF0
00007aa9b5fdb93b  pop r11
00007aa9b5fdb93d  pop r10
00007aa9b5fdb93f  pop r9
00007aa9b5fdb941  pop r8
00007aa9b5fdb943  pop rsi
00007aa9b5fdb944  pop rdi
00007aa9b5fdb945  pop rdx
00007aa9b5fdb946  pop rcx
00007aa9b5fdb947  pop rax
00007aa9b5fdb948  add rsp, 0x08
00007aa9b5fdb94c  jmp 0x00007AA9B5FD9210
00007aa9b5fdb951  sub rsp, 0x08
00007aa9b5fdb955  push rax
00007aa9b5fdb956  push rcx
00007aa9b5fdb957  push rdx
00007aa9b5fdb958  push rdi
00007aa9b5fdb959  push rsi
00007aa9b5fdb95a  push r8
00007aa9b5fdb95c  push r9
00007aa9b5fdb95e  push r10
00007aa9b5fdb960  push r11
00007aa9b5fdb962  sub rsp, 0xF0
00007aa9b5fdb969  vmovaps [rsp], xmm0
00007aa9b5fdb96e  vmovaps [rsp+0x10], xmm1
00007aa9b5fdb974  vmovaps [rsp+0x20], xmm2
00007aa9b5fdb97a  vmovaps [rsp+0x30], xmm4
00007aa9b5fdb980  vmovaps [rsp+0x40], xmm5
00007aa9b5fdb986  vmovaps [rsp+0x50], xmm6
00007aa9b5fdb98c  vmovaps [rsp+0x60], xmm7
00007aa9b5fdb992  vmovaps [rsp+0x70], xmm8
00007aa9b5fdb998  vmovaps [rsp+0x80], xmm9
00007aa9b5fdb9a1  vmovaps [rsp+0x90], xmm10
00007aa9b5fdb9aa  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdb9b3  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdb9bc  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdb9c5  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdb9ce  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdb9d7  sub rsp, 0x30
00007aa9b5fdb9db  movaps [rsp], xmm3
00007aa9b5fdb9df  movaps [rsp+0x10], xmm1
00007aa9b5fdb9e4  movaps [rsp+0x20], xmm15
00007aa9b5fdb9ea  lea rdi, [rsp]
00007aa9b5fdb9ee  mov esi, 0x00
00007aa9b5fdb9f3  mov rax, 0x63E0217C9530
00007aa9b5fdb9fd  call rax
00007aa9b5fdb9ff  movaps xmm3, [rsp]
00007aa9b5fdba03  add rsp, 0x30
00007aa9b5fdba07  vmovaps xmm0, [rsp]
00007aa9b5fdba0c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdba12  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdba18  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdba1e  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdba24  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdba2a  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdba30  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdba36  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdba3f  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdba48  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdba51  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdba5a  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdba63  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdba6c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdba75  add rsp, 0xF0
00007aa9b5fdba7c  pop r11
00007aa9b5fdba7e  pop r10
00007aa9b5fdba80  pop r9
00007aa9b5fdba82  pop r8
00007aa9b5fdba84  pop rsi
00007aa9b5fdba85  pop rdi
00007aa9b5fdba86  pop rdx
00007aa9b5fdba87  pop rcx
00007aa9b5fdba88  pop rax
00007aa9b5fdba89  add rsp, 0x08
00007aa9b5fdba8d  jmp 0x00007AA9B5FD929F
00007aa9b5fdba92  call 0x00007AA9B5ED64F0
00007aa9b5fdba97  jmp 0x00007AA9B5FD92A9
00007aa9b5fdba9c  sub rsp, 0x08
00007aa9b5fdbaa0  push rax
00007aa9b5fdbaa1  push rcx
00007aa9b5fdbaa2  push rdx
00007aa9b5fdbaa3  push rdi
00007aa9b5fdbaa4  push rsi
00007aa9b5fdbaa5  push r8
00007aa9b5fdbaa7  push r9
00007aa9b5fdbaa9  push r10
00007aa9b5fdbaab  push r11
00007aa9b5fdbaad  sub rsp, 0xF0
00007aa9b5fdbab4  vmovaps [rsp], xmm0
00007aa9b5fdbab9  vmovaps [rsp+0x10], xmm1
00007aa9b5fdbabf  vmovaps [rsp+0x20], xmm2
00007aa9b5fdbac5  vmovaps [rsp+0x30], xmm3
00007aa9b5fdbacb  vmovaps [rsp+0x40], xmm4
00007aa9b5fdbad1  vmovaps [rsp+0x50], xmm5
00007aa9b5fdbad7  vmovaps [rsp+0x60], xmm6
00007aa9b5fdbadd  vmovaps [rsp+0x70], xmm7
00007aa9b5fdbae3  vmovaps [rsp+0x80], xmm8
00007aa9b5fdbaec  vmovaps [rsp+0x90], xmm9
00007aa9b5fdbaf5  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdbafe  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdbb07  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdbb10  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdbb19  vmovaps [rsp+0xE0], xmm14
00007aa9b5fdbb22  sub rsp, 0x30
00007aa9b5fdbb26  movaps [rsp], xmm15
00007aa9b5fdbb2b  movaps [rsp+0x10], xmm14
00007aa9b5fdbb31  movaps [rsp+0x20], xmm4
00007aa9b5fdbb36  lea rdi, [rsp]
00007aa9b5fdbb3a  mov esi, 0x00
00007aa9b5fdbb3f  mov rax, 0x63E0217C9530
00007aa9b5fdbb49  call rax
00007aa9b5fdbb4b  movaps xmm15, [rsp]
00007aa9b5fdbb50  add rsp, 0x30
00007aa9b5fdbb54  vmovaps xmm0, [rsp]
00007aa9b5fdbb59  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdbb5f  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdbb65  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdbb6b  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdbb71  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdbb77  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdbb7d  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdbb83  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdbb8c  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdbb95  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdbb9e  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdbba7  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdbbb0  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdbbb9  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fdbbc2  add rsp, 0xF0
00007aa9b5fdbbc9  pop r11
00007aa9b5fdbbcb  pop r10
00007aa9b5fdbbcd  pop r9
00007aa9b5fdbbcf  pop r8
00007aa9b5fdbbd1  pop rsi
00007aa9b5fdbbd2  pop rdi
00007aa9b5fdbbd3  pop rdx
00007aa9b5fdbbd4  pop rcx
00007aa9b5fdbbd5  pop rax
00007aa9b5fdbbd6  add rsp, 0x08
00007aa9b5fdbbda  jmp 0x00007AA9B5FD92D7
00007aa9b5fdbbdf  sub rsp, 0x08
00007aa9b5fdbbe3  push rax
00007aa9b5fdbbe4  push rcx
00007aa9b5fdbbe5  push rdx
00007aa9b5fdbbe6  push rdi
00007aa9b5fdbbe7  push rsi
00007aa9b5fdbbe8  push r8
00007aa9b5fdbbea  push r9
00007aa9b5fdbbec  push r10
00007aa9b5fdbbee  push r11
00007aa9b5fdbbf0  sub rsp, 0xF0
00007aa9b5fdbbf7  vmovaps [rsp], xmm0
00007aa9b5fdbbfc  vmovaps [rsp+0x10], xmm1
00007aa9b5fdbc02  vmovaps [rsp+0x20], xmm2
00007aa9b5fdbc08  vmovaps [rsp+0x30], xmm3
00007aa9b5fdbc0e  vmovaps [rsp+0x40], xmm4
00007aa9b5fdbc14  vmovaps [rsp+0x50], xmm5
00007aa9b5fdbc1a  vmovaps [rsp+0x60], xmm6
00007aa9b5fdbc20  vmovaps [rsp+0x70], xmm7
00007aa9b5fdbc26  vmovaps [rsp+0x80], xmm8
00007aa9b5fdbc2f  vmovaps [rsp+0x90], xmm9
00007aa9b5fdbc38  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdbc41  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdbc4a  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdbc53  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdbc5c  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdbc65  sub rsp, 0x30
00007aa9b5fdbc69  movaps [rsp], xmm14
00007aa9b5fdbc6e  movaps [rsp+0x10], xmm2
00007aa9b5fdbc73  movaps [rsp+0x20], xmm1
00007aa9b5fdbc78  lea rdi, [rsp]
00007aa9b5fdbc7c  mov esi, 0x00
00007aa9b5fdbc81  mov rax, 0x63E0217C9530
00007aa9b5fdbc8b  call rax
00007aa9b5fdbc8d  movaps xmm14, [rsp]
00007aa9b5fdbc92  add rsp, 0x30
00007aa9b5fdbc96  vmovaps xmm0, [rsp]
00007aa9b5fdbc9b  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdbca1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdbca7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdbcad  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdbcb3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdbcb9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdbcbf  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdbcc5  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdbcce  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdbcd7  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdbce0  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdbce9  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdbcf2  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdbcfb  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdbd04  add rsp, 0xF0
00007aa9b5fdbd0b  pop r11
00007aa9b5fdbd0d  pop r10
00007aa9b5fdbd0f  pop r9
00007aa9b5fdbd11  pop r8
00007aa9b5fdbd13  pop rsi
00007aa9b5fdbd14  pop rdi
00007aa9b5fdbd15  pop rdx
00007aa9b5fdbd16  pop rcx
00007aa9b5fdbd17  pop rax
00007aa9b5fdbd18  add rsp, 0x08
00007aa9b5fdbd1c  jmp 0x00007AA9B5FD92FD
00007aa9b5fdbd21  sub rsp, 0x08
00007aa9b5fdbd25  push rax
00007aa9b5fdbd26  push rcx
00007aa9b5fdbd27  push rdx
00007aa9b5fdbd28  push rdi
00007aa9b5fdbd29  push rsi
00007aa9b5fdbd2a  push r8
00007aa9b5fdbd2c  push r9
00007aa9b5fdbd2e  push r10
00007aa9b5fdbd30  push r11
00007aa9b5fdbd32  sub rsp, 0xF0
00007aa9b5fdbd39  vmovaps [rsp], xmm0
00007aa9b5fdbd3e  vmovaps [rsp+0x10], xmm2
00007aa9b5fdbd44  vmovaps [rsp+0x20], xmm3
00007aa9b5fdbd4a  vmovaps [rsp+0x30], xmm4
00007aa9b5fdbd50  vmovaps [rsp+0x40], xmm5
00007aa9b5fdbd56  vmovaps [rsp+0x50], xmm6
00007aa9b5fdbd5c  vmovaps [rsp+0x60], xmm7
00007aa9b5fdbd62  vmovaps [rsp+0x70], xmm8
00007aa9b5fdbd68  vmovaps [rsp+0x80], xmm9
00007aa9b5fdbd71  vmovaps [rsp+0x90], xmm10
00007aa9b5fdbd7a  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdbd83  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdbd8c  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdbd95  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdbd9e  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdbda7  sub rsp, 0x30
00007aa9b5fdbdab  movaps [rsp], xmm1
00007aa9b5fdbdaf  movaps [rsp+0x10], xmm4
00007aa9b5fdbdb4  movaps [rsp+0x20], xmm9
00007aa9b5fdbdba  lea rdi, [rsp]
00007aa9b5fdbdbe  mov esi, 0x00
00007aa9b5fdbdc3  mov rax, 0x63E0217C9530
00007aa9b5fdbdcd  call rax
00007aa9b5fdbdcf  movaps xmm1, [rsp]
00007aa9b5fdbdd3  add rsp, 0x30
00007aa9b5fdbdd7  vmovaps xmm0, [rsp]
00007aa9b5fdbddc  vmovaps xmm2, [rsp+0x10]
00007aa9b5fdbde2  vmovaps xmm3, [rsp+0x20]
00007aa9b5fdbde8  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdbdee  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdbdf4  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdbdfa  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdbe00  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdbe06  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdbe0f  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdbe18  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdbe21  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdbe2a  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdbe33  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdbe3c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdbe45  add rsp, 0xF0
00007aa9b5fdbe4c  pop r11
00007aa9b5fdbe4e  pop r10
00007aa9b5fdbe50  pop r9
00007aa9b5fdbe52  pop r8
00007aa9b5fdbe54  pop rsi
00007aa9b5fdbe55  pop rdi
00007aa9b5fdbe56  pop rdx
00007aa9b5fdbe57  pop rcx
00007aa9b5fdbe58  pop rax
00007aa9b5fdbe59  add rsp, 0x08
00007aa9b5fdbe5d  jmp 0x00007AA9B5FD931B
00007aa9b5fdbe62  sub rsp, 0x08
00007aa9b5fdbe66  push rax
00007aa9b5fdbe67  push rcx
00007aa9b5fdbe68  push rdx
00007aa9b5fdbe69  push rdi
00007aa9b5fdbe6a  push rsi
00007aa9b5fdbe6b  push r8
00007aa9b5fdbe6d  push r9
00007aa9b5fdbe6f  push r10
00007aa9b5fdbe71  push r11
00007aa9b5fdbe73  sub rsp, 0xF0
00007aa9b5fdbe7a  vmovaps [rsp], xmm0
00007aa9b5fdbe7f  vmovaps [rsp+0x10], xmm1
00007aa9b5fdbe85  vmovaps [rsp+0x20], xmm2
00007aa9b5fdbe8b  vmovaps [rsp+0x30], xmm3
00007aa9b5fdbe91  vmovaps [rsp+0x40], xmm5
00007aa9b5fdbe97  vmovaps [rsp+0x50], xmm6
00007aa9b5fdbe9d  vmovaps [rsp+0x60], xmm7
00007aa9b5fdbea3  vmovaps [rsp+0x70], xmm8
00007aa9b5fdbea9  vmovaps [rsp+0x80], xmm9
00007aa9b5fdbeb2  vmovaps [rsp+0x90], xmm10
00007aa9b5fdbebb  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdbec4  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdbecd  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdbed6  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdbedf  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdbee8  sub rsp, 0x30
00007aa9b5fdbeec  movaps [rsp], xmm4
00007aa9b5fdbef0  movaps [rsp+0x10], xmm2
00007aa9b5fdbef5  movaps [rsp+0x20], xmm9
00007aa9b5fdbefb  lea rdi, [rsp]
00007aa9b5fdbeff  mov esi, 0x00
00007aa9b5fdbf04  mov rax, 0x63E0217C9530
00007aa9b5fdbf0e  call rax
00007aa9b5fdbf10  movaps xmm4, [rsp]
00007aa9b5fdbf14  add rsp, 0x30
00007aa9b5fdbf18  vmovaps xmm0, [rsp]
00007aa9b5fdbf1d  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdbf23  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdbf29  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdbf2f  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdbf35  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdbf3b  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdbf41  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdbf47  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdbf50  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdbf59  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdbf62  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdbf6b  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdbf74  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdbf7d  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdbf86  add rsp, 0xF0
00007aa9b5fdbf8d  pop r11
00007aa9b5fdbf8f  pop r10
00007aa9b5fdbf91  pop r9
00007aa9b5fdbf93  pop r8
00007aa9b5fdbf95  pop rsi
00007aa9b5fdbf96  pop rdi
00007aa9b5fdbf97  pop rdx
00007aa9b5fdbf98  pop rcx
00007aa9b5fdbf99  pop rax
00007aa9b5fdbf9a  add rsp, 0x08
00007aa9b5fdbf9e  jmp 0x00007AA9B5FD934B
00007aa9b5fdbfa3  sub rsp, 0x08
00007aa9b5fdbfa7  push rax
00007aa9b5fdbfa8  push rcx
00007aa9b5fdbfa9  push rdx
00007aa9b5fdbfaa  push rdi
00007aa9b5fdbfab  push rsi
00007aa9b5fdbfac  push r8
00007aa9b5fdbfae  push r9
00007aa9b5fdbfb0  push r10
00007aa9b5fdbfb2  push r11
00007aa9b5fdbfb4  sub rsp, 0xF0
00007aa9b5fdbfbb  vmovaps [rsp], xmm0
00007aa9b5fdbfc0  vmovaps [rsp+0x10], xmm1
00007aa9b5fdbfc6  vmovaps [rsp+0x20], xmm2
00007aa9b5fdbfcc  vmovaps [rsp+0x30], xmm3
00007aa9b5fdbfd2  vmovaps [rsp+0x40], xmm4
00007aa9b5fdbfd8  vmovaps [rsp+0x50], xmm5
00007aa9b5fdbfde  vmovaps [rsp+0x60], xmm6
00007aa9b5fdbfe4  vmovaps [rsp+0x70], xmm7
00007aa9b5fdbfea  vmovaps [rsp+0x80], xmm8
00007aa9b5fdbff3  vmovaps [rsp+0x90], xmm10
00007aa9b5fdbffc  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdc005  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdc00e  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdc017  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdc020  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdc029  sub rsp, 0x30
00007aa9b5fdc02d  movaps [rsp], xmm9
00007aa9b5fdc032  movaps [rsp+0x10], xmm2
00007aa9b5fdc037  movaps [rsp+0x20], xmm1
00007aa9b5fdc03c  lea rdi, [rsp]
00007aa9b5fdc040  mov esi, 0x00
00007aa9b5fdc045  mov rax, 0x63E0217C9530
00007aa9b5fdc04f  call rax
00007aa9b5fdc051  movaps xmm9, [rsp]
00007aa9b5fdc056  add rsp, 0x30
00007aa9b5fdc05a  vmovaps xmm0, [rsp]
00007aa9b5fdc05f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdc065  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdc06b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdc071  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdc077  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdc07d  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdc083  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdc089  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdc092  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdc09b  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdc0a4  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdc0ad  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdc0b6  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdc0bf  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdc0c8  add rsp, 0xF0
00007aa9b5fdc0cf  pop r11
00007aa9b5fdc0d1  pop r10
00007aa9b5fdc0d3  pop r9
00007aa9b5fdc0d5  pop r8
00007aa9b5fdc0d7  pop rsi
00007aa9b5fdc0d8  pop rdi
00007aa9b5fdc0d9  pop rdx
00007aa9b5fdc0da  pop rcx
00007aa9b5fdc0db  pop rax
00007aa9b5fdc0dc  add rsp, 0x08
00007aa9b5fdc0e0  jmp 0x00007AA9B5FD9381
00007aa9b5fdc0e5  sub rsp, 0x08
00007aa9b5fdc0e9  push rax
00007aa9b5fdc0ea  push rcx
00007aa9b5fdc0eb  push rdx
00007aa9b5fdc0ec  push rdi
00007aa9b5fdc0ed  push rsi
00007aa9b5fdc0ee  push r8
00007aa9b5fdc0f0  push r9
00007aa9b5fdc0f2  push r10
00007aa9b5fdc0f4  push r11
00007aa9b5fdc0f6  sub rsp, 0xF0
00007aa9b5fdc0fd  vmovaps [rsp], xmm0
00007aa9b5fdc102  vmovaps [rsp+0x10], xmm2
00007aa9b5fdc108  vmovaps [rsp+0x20], xmm3
00007aa9b5fdc10e  vmovaps [rsp+0x30], xmm4
00007aa9b5fdc114  vmovaps [rsp+0x40], xmm5
00007aa9b5fdc11a  vmovaps [rsp+0x50], xmm6
00007aa9b5fdc120  vmovaps [rsp+0x60], xmm7
00007aa9b5fdc126  vmovaps [rsp+0x70], xmm8
00007aa9b5fdc12c  vmovaps [rsp+0x80], xmm9
00007aa9b5fdc135  vmovaps [rsp+0x90], xmm10
00007aa9b5fdc13e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdc147  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdc150  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdc159  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdc162  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdc16b  sub rsp, 0x30
00007aa9b5fdc16f  movaps [rsp], xmm1
00007aa9b5fdc173  movaps [rsp+0x10], xmm15
00007aa9b5fdc179  movaps [rsp+0x20], xmm6
00007aa9b5fdc17e  lea rdi, [rsp]
00007aa9b5fdc182  mov esi, 0x00
00007aa9b5fdc187  mov rax, 0x63E0217C9530
00007aa9b5fdc191  call rax
00007aa9b5fdc193  movaps xmm1, [rsp]
00007aa9b5fdc197  add rsp, 0x30
00007aa9b5fdc19b  vmovaps xmm0, [rsp]
00007aa9b5fdc1a0  vmovaps xmm2, [rsp+0x10]
00007aa9b5fdc1a6  vmovaps xmm3, [rsp+0x20]
00007aa9b5fdc1ac  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdc1b2  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdc1b8  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdc1be  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdc1c4  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdc1ca  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdc1d3  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdc1dc  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdc1e5  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdc1ee  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdc1f7  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdc200  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdc209  add rsp, 0xF0
00007aa9b5fdc210  pop r11
00007aa9b5fdc212  pop r10
00007aa9b5fdc214  pop r9
00007aa9b5fdc216  pop r8
00007aa9b5fdc218  pop rsi
00007aa9b5fdc219  pop rdi
00007aa9b5fdc21a  pop rdx
00007aa9b5fdc21b  pop rcx
00007aa9b5fdc21c  pop rax
00007aa9b5fdc21d  add rsp, 0x08
00007aa9b5fdc221  jmp 0x00007AA9B5FD93A2
00007aa9b5fdc226  sub rsp, 0x08
00007aa9b5fdc22a  push rax
00007aa9b5fdc22b  push rcx
00007aa9b5fdc22c  push rdx
00007aa9b5fdc22d  push rdi
00007aa9b5fdc22e  push rsi
00007aa9b5fdc22f  push r8
00007aa9b5fdc231  push r9
00007aa9b5fdc233  push r10
00007aa9b5fdc235  push r11
00007aa9b5fdc237  sub rsp, 0xF0
00007aa9b5fdc23e  vmovaps [rsp], xmm0
00007aa9b5fdc243  vmovaps [rsp+0x10], xmm1
00007aa9b5fdc249  vmovaps [rsp+0x20], xmm2
00007aa9b5fdc24f  vmovaps [rsp+0x30], xmm3
00007aa9b5fdc255  vmovaps [rsp+0x40], xmm4
00007aa9b5fdc25b  vmovaps [rsp+0x50], xmm5
00007aa9b5fdc261  vmovaps [rsp+0x60], xmm6
00007aa9b5fdc267  vmovaps [rsp+0x70], xmm7
00007aa9b5fdc26d  vmovaps [rsp+0x80], xmm8
00007aa9b5fdc276  vmovaps [rsp+0x90], xmm9
00007aa9b5fdc27f  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdc288  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdc291  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdc29a  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdc2a3  vmovaps [rsp+0xE0], xmm14
00007aa9b5fdc2ac  sub rsp, 0x30
00007aa9b5fdc2b0  movaps [rsp], xmm15
00007aa9b5fdc2b5  movaps [rsp+0x10], xmm5
00007aa9b5fdc2ba  movaps [rsp+0x20], xmm3
00007aa9b5fdc2bf  lea rdi, [rsp]
00007aa9b5fdc2c3  mov esi, 0x00
00007aa9b5fdc2c8  mov rax, 0x63E0217C9530
00007aa9b5fdc2d2  call rax
00007aa9b5fdc2d4  movaps xmm15, [rsp]
00007aa9b5fdc2d9  add rsp, 0x30
00007aa9b5fdc2dd  vmovaps xmm0, [rsp]
00007aa9b5fdc2e2  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdc2e8  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdc2ee  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdc2f4  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdc2fa  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdc300  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdc306  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdc30c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdc315  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdc31e  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdc327  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdc330  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdc339  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdc342  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fdc34b  add rsp, 0xF0
00007aa9b5fdc352  pop r11
00007aa9b5fdc354  pop r10
00007aa9b5fdc356  pop r9
00007aa9b5fdc358  pop r8
00007aa9b5fdc35a  pop rsi
00007aa9b5fdc35b  pop rdi
00007aa9b5fdc35c  pop rdx
00007aa9b5fdc35d  pop rcx
00007aa9b5fdc35e  pop rax
00007aa9b5fdc35f  add rsp, 0x08
00007aa9b5fdc363  jmp 0x00007AA9B5FD93BC
00007aa9b5fdc368  sub rsp, 0x08
00007aa9b5fdc36c  push rax
00007aa9b5fdc36d  push rcx
00007aa9b5fdc36e  push rdx
00007aa9b5fdc36f  push rdi
00007aa9b5fdc370  push rsi
00007aa9b5fdc371  push r8
00007aa9b5fdc373  push r9
00007aa9b5fdc375  push r10
00007aa9b5fdc377  push r11
00007aa9b5fdc379  sub rsp, 0xF0
00007aa9b5fdc380  vmovaps [rsp], xmm0
00007aa9b5fdc385  vmovaps [rsp+0x10], xmm1
00007aa9b5fdc38b  vmovaps [rsp+0x20], xmm2
00007aa9b5fdc391  vmovaps [rsp+0x30], xmm3
00007aa9b5fdc397  vmovaps [rsp+0x40], xmm4
00007aa9b5fdc39d  vmovaps [rsp+0x50], xmm6
00007aa9b5fdc3a3  vmovaps [rsp+0x60], xmm7
00007aa9b5fdc3a9  vmovaps [rsp+0x70], xmm8
00007aa9b5fdc3af  vmovaps [rsp+0x80], xmm9
00007aa9b5fdc3b8  vmovaps [rsp+0x90], xmm10
00007aa9b5fdc3c1  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdc3ca  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdc3d3  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdc3dc  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdc3e5  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdc3ee  sub rsp, 0x30
00007aa9b5fdc3f2  movaps [rsp], xmm5
00007aa9b5fdc3f6  movaps [rsp+0x10], xmm8
00007aa9b5fdc3fc  movaps [rsp+0x20], xmm6
00007aa9b5fdc401  lea rdi, [rsp]
00007aa9b5fdc405  mov esi, 0x00
00007aa9b5fdc40a  mov rax, 0x63E0217C9530
00007aa9b5fdc414  call rax
00007aa9b5fdc416  movaps xmm5, [rsp]
00007aa9b5fdc41a  add rsp, 0x30
00007aa9b5fdc41e  vmovaps xmm0, [rsp]
00007aa9b5fdc423  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdc429  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdc42f  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdc435  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdc43b  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdc441  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdc447  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdc44d  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdc456  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdc45f  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdc468  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdc471  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdc47a  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdc483  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdc48c  add rsp, 0xF0
00007aa9b5fdc493  pop r11
00007aa9b5fdc495  pop r10
00007aa9b5fdc497  pop r9
00007aa9b5fdc499  pop r8
00007aa9b5fdc49b  pop rsi
00007aa9b5fdc49c  pop rdi
00007aa9b5fdc49d  pop rdx
00007aa9b5fdc49e  pop rcx
00007aa9b5fdc49f  pop rax
00007aa9b5fdc4a0  add rsp, 0x08
00007aa9b5fdc4a4  jmp 0x00007AA9B5FD93E0
00007aa9b5fdc4a9  sub rsp, 0x08
00007aa9b5fdc4ad  push rax
00007aa9b5fdc4ae  push rcx
00007aa9b5fdc4af  push rdx
00007aa9b5fdc4b0  push rdi
00007aa9b5fdc4b1  push rsi
00007aa9b5fdc4b2  push r8
00007aa9b5fdc4b4  push r9
00007aa9b5fdc4b6  push r10
00007aa9b5fdc4b8  push r11
00007aa9b5fdc4ba  sub rsp, 0xF0
00007aa9b5fdc4c1  vmovaps [rsp], xmm0
00007aa9b5fdc4c6  vmovaps [rsp+0x10], xmm1
00007aa9b5fdc4cc  vmovaps [rsp+0x20], xmm2
00007aa9b5fdc4d2  vmovaps [rsp+0x30], xmm3
00007aa9b5fdc4d8  vmovaps [rsp+0x40], xmm4
00007aa9b5fdc4de  vmovaps [rsp+0x50], xmm5
00007aa9b5fdc4e4  vmovaps [rsp+0x60], xmm7
00007aa9b5fdc4ea  vmovaps [rsp+0x70], xmm8
00007aa9b5fdc4f0  vmovaps [rsp+0x80], xmm9
00007aa9b5fdc4f9  vmovaps [rsp+0x90], xmm10
00007aa9b5fdc502  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdc50b  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdc514  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdc51d  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdc526  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdc52f  sub rsp, 0x30
00007aa9b5fdc533  movaps [rsp], xmm6
00007aa9b5fdc537  movaps [rsp+0x10], xmm10
00007aa9b5fdc53d  movaps [rsp+0x20], xmm8
00007aa9b5fdc543  lea rdi, [rsp]
00007aa9b5fdc547  mov esi, 0x00
00007aa9b5fdc54c  mov rax, 0x63E0217C9530
00007aa9b5fdc556  call rax
00007aa9b5fdc558  movaps xmm6, [rsp]
00007aa9b5fdc55c  add rsp, 0x30
00007aa9b5fdc560  vmovaps xmm0, [rsp]
00007aa9b5fdc565  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdc56b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdc571  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdc577  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdc57d  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdc583  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdc589  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdc58f  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdc598  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdc5a1  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdc5aa  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdc5b3  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdc5bc  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdc5c5  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdc5ce  add rsp, 0xF0
00007aa9b5fdc5d5  pop r11
00007aa9b5fdc5d7  pop r10
00007aa9b5fdc5d9  pop r9
00007aa9b5fdc5db  pop r8
00007aa9b5fdc5dd  pop rsi
00007aa9b5fdc5de  pop rdi
00007aa9b5fdc5df  pop rdx
00007aa9b5fdc5e0  pop rcx
00007aa9b5fdc5e1  pop rax
00007aa9b5fdc5e2  add rsp, 0x08
00007aa9b5fdc5e6  jmp 0x00007AA9B5FD9405
00007aa9b5fdc5eb  sub rsp, 0x08
00007aa9b5fdc5ef  push rax
00007aa9b5fdc5f0  push rcx
00007aa9b5fdc5f1  push rdx
00007aa9b5fdc5f2  push rdi
00007aa9b5fdc5f3  push rsi
00007aa9b5fdc5f4  push r8
00007aa9b5fdc5f6  push r9
00007aa9b5fdc5f8  push r10
00007aa9b5fdc5fa  push r11
00007aa9b5fdc5fc  sub rsp, 0xF0
00007aa9b5fdc603  vmovaps [rsp], xmm0
00007aa9b5fdc608  vmovaps [rsp+0x10], xmm1
00007aa9b5fdc60e  vmovaps [rsp+0x20], xmm2
00007aa9b5fdc614  vmovaps [rsp+0x30], xmm3
00007aa9b5fdc61a  vmovaps [rsp+0x40], xmm4
00007aa9b5fdc620  vmovaps [rsp+0x50], xmm5
00007aa9b5fdc626  vmovaps [rsp+0x60], xmm6
00007aa9b5fdc62c  vmovaps [rsp+0x70], xmm7
00007aa9b5fdc632  vmovaps [rsp+0x80], xmm8
00007aa9b5fdc63b  vmovaps [rsp+0x90], xmm9
00007aa9b5fdc644  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdc64d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdc656  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdc65f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdc668  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdc671  sub rsp, 0x30
00007aa9b5fdc675  movaps [rsp], xmm10
00007aa9b5fdc67a  movaps [rsp+0x10], xmm8
00007aa9b5fdc680  movaps [rsp+0x20], xmm14
00007aa9b5fdc686  lea rdi, [rsp]
00007aa9b5fdc68a  mov esi, 0x00
00007aa9b5fdc68f  mov rax, 0x63E0217C9530
00007aa9b5fdc699  call rax
00007aa9b5fdc69b  movaps xmm10, [rsp]
00007aa9b5fdc6a0  add rsp, 0x30
00007aa9b5fdc6a4  vmovaps xmm0, [rsp]
00007aa9b5fdc6a9  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdc6af  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdc6b5  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdc6bb  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdc6c1  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdc6c7  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdc6cd  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdc6d3  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdc6dc  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdc6e5  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdc6ee  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdc6f7  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdc700  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdc709  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdc712  add rsp, 0xF0
00007aa9b5fdc719  pop r11
00007aa9b5fdc71b  pop r10
00007aa9b5fdc71d  pop r9
00007aa9b5fdc71f  pop r8
00007aa9b5fdc721  pop rsi
00007aa9b5fdc722  pop rdi
00007aa9b5fdc723  pop rdx
00007aa9b5fdc724  pop rcx
00007aa9b5fdc725  pop rax
00007aa9b5fdc726  add rsp, 0x08
00007aa9b5fdc72a  jmp 0x00007AA9B5FD9425
00007aa9b5fdc72f  sub rsp, 0x08
00007aa9b5fdc733  push rax
00007aa9b5fdc734  push rcx
00007aa9b5fdc735  push rdx
00007aa9b5fdc736  push rdi
00007aa9b5fdc737  push rsi
00007aa9b5fdc738  push r8
00007aa9b5fdc73a  push r9
00007aa9b5fdc73c  push r10
00007aa9b5fdc73e  push r11
00007aa9b5fdc740  sub rsp, 0xF0
00007aa9b5fdc747  vmovaps [rsp], xmm0
00007aa9b5fdc74c  vmovaps [rsp+0x10], xmm1
00007aa9b5fdc752  vmovaps [rsp+0x20], xmm2
00007aa9b5fdc758  vmovaps [rsp+0x30], xmm3
00007aa9b5fdc75e  vmovaps [rsp+0x40], xmm4
00007aa9b5fdc764  vmovaps [rsp+0x50], xmm5
00007aa9b5fdc76a  vmovaps [rsp+0x60], xmm6
00007aa9b5fdc770  vmovaps [rsp+0x70], xmm7
00007aa9b5fdc776  vmovaps [rsp+0x80], xmm8
00007aa9b5fdc77f  vmovaps [rsp+0x90], xmm9
00007aa9b5fdc788  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdc791  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdc79a  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdc7a3  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdc7ac  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdc7b5  sub rsp, 0x30
00007aa9b5fdc7b9  movaps [rsp], xmm14
00007aa9b5fdc7be  movaps [rsp+0x10], xmm8
00007aa9b5fdc7c4  movaps [rsp+0x20], xmm4
00007aa9b5fdc7c9  lea rdi, [rsp]
00007aa9b5fdc7cd  mov esi, 0x00
00007aa9b5fdc7d2  mov rax, 0x63E0217C9530
00007aa9b5fdc7dc  call rax
00007aa9b5fdc7de  movaps xmm14, [rsp]
00007aa9b5fdc7e3  add rsp, 0x30
00007aa9b5fdc7e7  vmovaps xmm0, [rsp]
00007aa9b5fdc7ec  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdc7f2  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdc7f8  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdc7fe  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdc804  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdc80a  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdc810  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdc816  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdc81f  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdc828  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdc831  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdc83a  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdc843  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdc84c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdc855  add rsp, 0xF0
00007aa9b5fdc85c  pop r11
00007aa9b5fdc85e  pop r10
00007aa9b5fdc860  pop r9
00007aa9b5fdc862  pop r8
00007aa9b5fdc864  pop rsi
00007aa9b5fdc865  pop rdi
00007aa9b5fdc866  pop rdx
00007aa9b5fdc867  pop rcx
00007aa9b5fdc868  pop rax
00007aa9b5fdc869  add rsp, 0x08
00007aa9b5fdc86d  jmp 0x00007AA9B5FD9445
00007aa9b5fdc872  sub rsp, 0x08
00007aa9b5fdc876  push rax
00007aa9b5fdc877  push rcx
00007aa9b5fdc878  push rdx
00007aa9b5fdc879  push rdi
00007aa9b5fdc87a  push rsi
00007aa9b5fdc87b  push r8
00007aa9b5fdc87d  push r9
00007aa9b5fdc87f  push r10
00007aa9b5fdc881  push r11
00007aa9b5fdc883  sub rsp, 0xF0
00007aa9b5fdc88a  vmovaps [rsp], xmm0
00007aa9b5fdc88f  vmovaps [rsp+0x10], xmm1
00007aa9b5fdc895  vmovaps [rsp+0x20], xmm2
00007aa9b5fdc89b  vmovaps [rsp+0x30], xmm3
00007aa9b5fdc8a1  vmovaps [rsp+0x40], xmm5
00007aa9b5fdc8a7  vmovaps [rsp+0x50], xmm6
00007aa9b5fdc8ad  vmovaps [rsp+0x60], xmm7
00007aa9b5fdc8b3  vmovaps [rsp+0x70], xmm8
00007aa9b5fdc8b9  vmovaps [rsp+0x80], xmm9
00007aa9b5fdc8c2  vmovaps [rsp+0x90], xmm10
00007aa9b5fdc8cb  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdc8d4  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdc8dd  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdc8e6  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdc8ef  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdc8f8  sub rsp, 0x30
00007aa9b5fdc8fc  movaps [rsp], xmm4
00007aa9b5fdc900  movaps [rsp+0x10], xmm13
00007aa9b5fdc906  movaps [rsp+0x20], xmm8
00007aa9b5fdc90c  lea rdi, [rsp]
00007aa9b5fdc910  mov esi, 0x00
00007aa9b5fdc915  mov rax, 0x63E0217C9530
00007aa9b5fdc91f  call rax
00007aa9b5fdc921  movaps xmm4, [rsp]
00007aa9b5fdc925  add rsp, 0x30
00007aa9b5fdc929  vmovaps xmm0, [rsp]
00007aa9b5fdc92e  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdc934  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdc93a  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdc940  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdc946  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdc94c  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdc952  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdc958  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdc961  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdc96a  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdc973  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdc97c  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdc985  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdc98e  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdc997  add rsp, 0xF0
00007aa9b5fdc99e  pop r11
00007aa9b5fdc9a0  pop r10
00007aa9b5fdc9a2  pop r9
00007aa9b5fdc9a4  pop r8
00007aa9b5fdc9a6  pop rsi
00007aa9b5fdc9a7  pop rdi
00007aa9b5fdc9a8  pop rdx
00007aa9b5fdc9a9  pop rcx
00007aa9b5fdc9aa  pop rax
00007aa9b5fdc9ab  add rsp, 0x08
00007aa9b5fdc9af  jmp 0x00007AA9B5FD946A
00007aa9b5fdc9b4  sub rsp, 0x08
00007aa9b5fdc9b8  push rax
00007aa9b5fdc9b9  push rcx
00007aa9b5fdc9ba  push rdx
00007aa9b5fdc9bb  push rdi
00007aa9b5fdc9bc  push rsi
00007aa9b5fdc9bd  push r8
00007aa9b5fdc9bf  push r9
00007aa9b5fdc9c1  push r10
00007aa9b5fdc9c3  push r11
00007aa9b5fdc9c5  sub rsp, 0xF0
00007aa9b5fdc9cc  vmovaps [rsp], xmm0
00007aa9b5fdc9d1  vmovaps [rsp+0x10], xmm1
00007aa9b5fdc9d7  vmovaps [rsp+0x20], xmm2
00007aa9b5fdc9dd  vmovaps [rsp+0x30], xmm3
00007aa9b5fdc9e3  vmovaps [rsp+0x40], xmm4
00007aa9b5fdc9e9  vmovaps [rsp+0x50], xmm5
00007aa9b5fdc9ef  vmovaps [rsp+0x60], xmm6
00007aa9b5fdc9f5  vmovaps [rsp+0x70], xmm7
00007aa9b5fdc9fb  vmovaps [rsp+0x80], xmm8
00007aa9b5fdca04  vmovaps [rsp+0x90], xmm9
00007aa9b5fdca0d  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdca16  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdca1f  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdca28  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdca31  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdca3a  sub rsp, 0x30
00007aa9b5fdca3e  movaps [rsp], xmm13
00007aa9b5fdca43  movaps [rsp+0x10], xmm15
00007aa9b5fdca49  movaps [rsp+0x20], xmm9
00007aa9b5fdca4f  lea rdi, [rsp]
00007aa9b5fdca53  mov esi, 0x00
00007aa9b5fdca58  mov rax, 0x63E0217C9530
00007aa9b5fdca62  call rax
00007aa9b5fdca64  movaps xmm13, [rsp]
00007aa9b5fdca69  add rsp, 0x30
00007aa9b5fdca6d  vmovaps xmm0, [rsp]
00007aa9b5fdca72  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdca78  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdca7e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdca84  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdca8a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdca90  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdca96  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdca9c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdcaa5  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdcaae  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdcab7  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdcac0  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdcac9  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdcad2  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdcadb  add rsp, 0xF0
00007aa9b5fdcae2  pop r11
00007aa9b5fdcae4  pop r10
00007aa9b5fdcae6  pop r9
00007aa9b5fdcae8  pop r8
00007aa9b5fdcaea  pop rsi
00007aa9b5fdcaeb  pop rdi
00007aa9b5fdcaec  pop rdx
00007aa9b5fdcaed  pop rcx
00007aa9b5fdcaee  pop rax
00007aa9b5fdcaef  add rsp, 0x08
00007aa9b5fdcaf3  jmp 0x00007AA9B5FD9485
00007aa9b5fdcaf8  sub rsp, 0x08
00007aa9b5fdcafc  push rax
00007aa9b5fdcafd  push rcx
00007aa9b5fdcafe  push rdx
00007aa9b5fdcaff  push rdi
00007aa9b5fdcb00  push rsi
00007aa9b5fdcb01  push r8
00007aa9b5fdcb03  push r9
00007aa9b5fdcb05  push r10
00007aa9b5fdcb07  push r11
00007aa9b5fdcb09  sub rsp, 0xF0
00007aa9b5fdcb10  vmovaps [rsp], xmm0
00007aa9b5fdcb15  vmovaps [rsp+0x10], xmm1
00007aa9b5fdcb1b  vmovaps [rsp+0x20], xmm2
00007aa9b5fdcb21  vmovaps [rsp+0x30], xmm3
00007aa9b5fdcb27  vmovaps [rsp+0x40], xmm4
00007aa9b5fdcb2d  vmovaps [rsp+0x50], xmm5
00007aa9b5fdcb33  vmovaps [rsp+0x60], xmm6
00007aa9b5fdcb39  vmovaps [rsp+0x70], xmm7
00007aa9b5fdcb3f  vmovaps [rsp+0x80], xmm8
00007aa9b5fdcb48  vmovaps [rsp+0x90], xmm9
00007aa9b5fdcb51  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdcb5a  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdcb63  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdcb6c  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdcb75  vmovaps [rsp+0xE0], xmm14
00007aa9b5fdcb7e  sub rsp, 0x30
00007aa9b5fdcb82  movaps [rsp], xmm15
00007aa9b5fdcb87  movaps [rsp+0x10], xmm1
00007aa9b5fdcb8c  movaps [rsp+0x20], xmm5
00007aa9b5fdcb91  lea rdi, [rsp]
00007aa9b5fdcb95  mov esi, 0x00
00007aa9b5fdcb9a  mov rax, 0x63E0217C9530
00007aa9b5fdcba4  call rax
00007aa9b5fdcba6  movaps xmm15, [rsp]
00007aa9b5fdcbab  add rsp, 0x30
00007aa9b5fdcbaf  vmovaps xmm0, [rsp]
00007aa9b5fdcbb4  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdcbba  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdcbc0  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdcbc6  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdcbcc  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdcbd2  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdcbd8  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdcbde  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdcbe7  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdcbf0  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdcbf9  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdcc02  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdcc0b  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdcc14  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fdcc1d  add rsp, 0xF0
00007aa9b5fdcc24  pop r11
00007aa9b5fdcc26  pop r10
00007aa9b5fdcc28  pop r9
00007aa9b5fdcc2a  pop r8
00007aa9b5fdcc2c  pop rsi
00007aa9b5fdcc2d  pop rdi
00007aa9b5fdcc2e  pop rdx
00007aa9b5fdcc2f  pop rcx
00007aa9b5fdcc30  pop rax
00007aa9b5fdcc31  add rsp, 0x08
00007aa9b5fdcc35  jmp 0x00007AA9B5FD94A0
00007aa9b5fdcc3a  call 0x00007AA9B5ED64F0
00007aa9b5fdcc3f  jmp 0x00007AA9B5FD94FB
00007aa9b5fdcc44  sub rsp, 0x08
00007aa9b5fdcc48  push rax
00007aa9b5fdcc49  push rcx
00007aa9b5fdcc4a  push rdx
00007aa9b5fdcc4b  push rdi
00007aa9b5fdcc4c  push rsi
00007aa9b5fdcc4d  push r8
00007aa9b5fdcc4f  push r9
00007aa9b5fdcc51  push r10
00007aa9b5fdcc53  push r11
00007aa9b5fdcc55  sub rsp, 0xF0
00007aa9b5fdcc5c  vmovaps [rsp], xmm0
00007aa9b5fdcc61  vmovaps [rsp+0x10], xmm1
00007aa9b5fdcc67  vmovaps [rsp+0x20], xmm2
00007aa9b5fdcc6d  vmovaps [rsp+0x30], xmm3
00007aa9b5fdcc73  vmovaps [rsp+0x40], xmm4
00007aa9b5fdcc79  vmovaps [rsp+0x50], xmm5
00007aa9b5fdcc7f  vmovaps [rsp+0x60], xmm6
00007aa9b5fdcc85  vmovaps [rsp+0x70], xmm7
00007aa9b5fdcc8b  vmovaps [rsp+0x80], xmm8
00007aa9b5fdcc94  vmovaps [rsp+0x90], xmm10
00007aa9b5fdcc9d  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdcca6  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdccaf  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdccb8  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdccc1  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdccca  sub rsp, 0x30
00007aa9b5fdccce  movaps [rsp], xmm9
00007aa9b5fdccd3  movaps [rsp+0x10], xmm8
00007aa9b5fdccd9  movaps [rsp+0x20], xmm11
00007aa9b5fdccdf  lea rdi, [rsp]
00007aa9b5fdcce3  mov esi, 0x00
00007aa9b5fdcce8  mov rax, 0x63E0217C9530
00007aa9b5fdccf2  call rax
00007aa9b5fdccf4  movaps xmm9, [rsp]
00007aa9b5fdccf9  add rsp, 0x30
00007aa9b5fdccfd  vmovaps xmm0, [rsp]
00007aa9b5fdcd02  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdcd08  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdcd0e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdcd14  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdcd1a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdcd20  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdcd26  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdcd2c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdcd35  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdcd3e  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdcd47  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdcd50  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdcd59  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdcd62  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdcd6b  add rsp, 0xF0
00007aa9b5fdcd72  pop r11
00007aa9b5fdcd74  pop r10
00007aa9b5fdcd76  pop r9
00007aa9b5fdcd78  pop r8
00007aa9b5fdcd7a  pop rsi
00007aa9b5fdcd7b  pop rdi
00007aa9b5fdcd7c  pop rdx
00007aa9b5fdcd7d  pop rcx
00007aa9b5fdcd7e  pop rax
00007aa9b5fdcd7f  add rsp, 0x08
00007aa9b5fdcd83  jmp 0x00007AA9B5FD9532
00007aa9b5fdcd88  sub rsp, 0x08
00007aa9b5fdcd8c  push rax
00007aa9b5fdcd8d  push rcx
00007aa9b5fdcd8e  push rdx
00007aa9b5fdcd8f  push rdi
00007aa9b5fdcd90  push rsi
00007aa9b5fdcd91  push r8
00007aa9b5fdcd93  push r9
00007aa9b5fdcd95  push r10
00007aa9b5fdcd97  push r11
00007aa9b5fdcd99  sub rsp, 0xF0
00007aa9b5fdcda0  vmovaps [rsp], xmm0
00007aa9b5fdcda5  vmovaps [rsp+0x10], xmm1
00007aa9b5fdcdab  vmovaps [rsp+0x20], xmm2
00007aa9b5fdcdb1  vmovaps [rsp+0x30], xmm3
00007aa9b5fdcdb7  vmovaps [rsp+0x40], xmm4
00007aa9b5fdcdbd  vmovaps [rsp+0x50], xmm5
00007aa9b5fdcdc3  vmovaps [rsp+0x60], xmm6
00007aa9b5fdcdc9  vmovaps [rsp+0x70], xmm7
00007aa9b5fdcdcf  vmovaps [rsp+0x80], xmm8
00007aa9b5fdcdd8  vmovaps [rsp+0x90], xmm9
00007aa9b5fdcde1  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdcdea  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdcdf3  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdcdfc  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdce05  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdce0e  sub rsp, 0x30
00007aa9b5fdce12  movaps [rsp], xmm11
00007aa9b5fdce17  movaps [rsp+0x10], xmm10
00007aa9b5fdce1d  movaps [rsp+0x20], xmm6
00007aa9b5fdce22  lea rdi, [rsp]
00007aa9b5fdce26  mov esi, 0x00
00007aa9b5fdce2b  mov rax, 0x63E0217C9530
00007aa9b5fdce35  call rax
00007aa9b5fdce37  movaps xmm11, [rsp]
00007aa9b5fdce3c  add rsp, 0x30
00007aa9b5fdce40  vmovaps xmm0, [rsp]
00007aa9b5fdce45  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdce4b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdce51  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdce57  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdce5d  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdce63  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdce69  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdce6f  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdce78  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdce81  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdce8a  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdce93  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdce9c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdcea5  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdceae  add rsp, 0xF0
00007aa9b5fdceb5  pop r11
00007aa9b5fdceb7  pop r10
00007aa9b5fdceb9  pop r9
00007aa9b5fdcebb  pop r8
00007aa9b5fdcebd  pop rsi
00007aa9b5fdcebe  pop rdi
00007aa9b5fdcebf  pop rdx
00007aa9b5fdcec0  pop rcx
00007aa9b5fdcec1  pop rax
00007aa9b5fdcec2  add rsp, 0x08
00007aa9b5fdcec6  jmp 0x00007AA9B5FD954D
00007aa9b5fdcecb  sub rsp, 0x08
00007aa9b5fdcecf  push rax
00007aa9b5fdced0  push rcx
00007aa9b5fdced1  push rdx
00007aa9b5fdced2  push rdi
00007aa9b5fdced3  push rsi
00007aa9b5fdced4  push r8
00007aa9b5fdced6  push r9
00007aa9b5fdced8  push r10
00007aa9b5fdceda  push r11
00007aa9b5fdcedc  sub rsp, 0xF0
00007aa9b5fdcee3  vmovaps [rsp], xmm0
00007aa9b5fdcee8  vmovaps [rsp+0x10], xmm1
00007aa9b5fdceee  vmovaps [rsp+0x20], xmm2
00007aa9b5fdcef4  vmovaps [rsp+0x30], xmm3
00007aa9b5fdcefa  vmovaps [rsp+0x40], xmm4
00007aa9b5fdcf00  vmovaps [rsp+0x50], xmm5
00007aa9b5fdcf06  vmovaps [rsp+0x60], xmm6
00007aa9b5fdcf0c  vmovaps [rsp+0x70], xmm7
00007aa9b5fdcf12  vmovaps [rsp+0x80], xmm8
00007aa9b5fdcf1b  vmovaps [rsp+0x90], xmm9
00007aa9b5fdcf24  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdcf2d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdcf36  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdcf3f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdcf48  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdcf51  sub rsp, 0x30
00007aa9b5fdcf55  movaps [rsp], xmm10
00007aa9b5fdcf5a  movaps [rsp+0x10], xmm14
00007aa9b5fdcf60  movaps [rsp+0x20], xmm4
00007aa9b5fdcf65  lea rdi, [rsp]
00007aa9b5fdcf69  mov esi, 0x00
00007aa9b5fdcf6e  mov rax, 0x63E0217C9530
00007aa9b5fdcf78  call rax
00007aa9b5fdcf7a  movaps xmm10, [rsp]
00007aa9b5fdcf7f  add rsp, 0x30
00007aa9b5fdcf83  vmovaps xmm0, [rsp]
00007aa9b5fdcf88  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdcf8e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdcf94  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdcf9a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdcfa0  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdcfa6  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdcfac  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdcfb2  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdcfbb  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdcfc4  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdcfcd  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdcfd6  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdcfdf  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdcfe8  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdcff1  add rsp, 0xF0
00007aa9b5fdcff8  pop r11
00007aa9b5fdcffa  pop r10
00007aa9b5fdcffc  pop r9
00007aa9b5fdcffe  pop r8
00007aa9b5fdd000  pop rsi
00007aa9b5fdd001  pop rdi
00007aa9b5fdd002  pop rdx
00007aa9b5fdd003  pop rcx
00007aa9b5fdd004  pop rax
00007aa9b5fdd005  add rsp, 0x08
00007aa9b5fdd009  jmp 0x00007AA9B5FD9568
00007aa9b5fdd00e  sub rsp, 0x08
00007aa9b5fdd012  push rax
00007aa9b5fdd013  push rcx
00007aa9b5fdd014  push rdx
00007aa9b5fdd015  push rdi
00007aa9b5fdd016  push rsi
00007aa9b5fdd017  push r8
00007aa9b5fdd019  push r9
00007aa9b5fdd01b  push r10
00007aa9b5fdd01d  push r11
00007aa9b5fdd01f  sub rsp, 0xF0
00007aa9b5fdd026  vmovaps [rsp], xmm0
00007aa9b5fdd02b  vmovaps [rsp+0x10], xmm1
00007aa9b5fdd031  vmovaps [rsp+0x20], xmm2
00007aa9b5fdd037  vmovaps [rsp+0x30], xmm3
00007aa9b5fdd03d  vmovaps [rsp+0x40], xmm4
00007aa9b5fdd043  vmovaps [rsp+0x50], xmm5
00007aa9b5fdd049  vmovaps [rsp+0x60], xmm6
00007aa9b5fdd04f  vmovaps [rsp+0x70], xmm7
00007aa9b5fdd055  vmovaps [rsp+0x80], xmm9
00007aa9b5fdd05e  vmovaps [rsp+0x90], xmm10
00007aa9b5fdd067  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdd070  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdd079  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdd082  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdd08b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdd094  sub rsp, 0x30
00007aa9b5fdd098  movaps [rsp], xmm8
00007aa9b5fdd09d  movaps [rsp+0x10], xmm1
00007aa9b5fdd0a2  movaps [rsp+0x20], xmm14
00007aa9b5fdd0a8  lea rdi, [rsp]
00007aa9b5fdd0ac  mov esi, 0x00
00007aa9b5fdd0b1  mov rax, 0x63E0217C9530
00007aa9b5fdd0bb  call rax
00007aa9b5fdd0bd  movaps xmm8, [rsp]
00007aa9b5fdd0c2  add rsp, 0x30
00007aa9b5fdd0c6  vmovaps xmm0, [rsp]
00007aa9b5fdd0cb  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdd0d1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdd0d7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdd0dd  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdd0e3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdd0e9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdd0ef  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdd0f5  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdd0fe  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdd107  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdd110  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdd119  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdd122  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdd12b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdd134  add rsp, 0xF0
00007aa9b5fdd13b  pop r11
00007aa9b5fdd13d  pop r10
00007aa9b5fdd13f  pop r9
00007aa9b5fdd141  pop r8
00007aa9b5fdd143  pop rsi
00007aa9b5fdd144  pop rdi
00007aa9b5fdd145  pop rdx
00007aa9b5fdd146  pop rcx
00007aa9b5fdd147  pop rax
00007aa9b5fdd148  add rsp, 0x08
00007aa9b5fdd14c  jmp 0x00007AA9B5FD958E
00007aa9b5fdd151  sub rsp, 0x08
00007aa9b5fdd155  push rax
00007aa9b5fdd156  push rcx
00007aa9b5fdd157  push rdx
00007aa9b5fdd158  push rdi
00007aa9b5fdd159  push rsi
00007aa9b5fdd15a  push r8
00007aa9b5fdd15c  push r9
00007aa9b5fdd15e  push r10
00007aa9b5fdd160  push r11
00007aa9b5fdd162  sub rsp, 0xF0
00007aa9b5fdd169  vmovaps [rsp], xmm0
00007aa9b5fdd16e  vmovaps [rsp+0x10], xmm1
00007aa9b5fdd174  vmovaps [rsp+0x20], xmm2
00007aa9b5fdd17a  vmovaps [rsp+0x30], xmm3
00007aa9b5fdd180  vmovaps [rsp+0x40], xmm4
00007aa9b5fdd186  vmovaps [rsp+0x50], xmm5
00007aa9b5fdd18c  vmovaps [rsp+0x60], xmm7
00007aa9b5fdd192  vmovaps [rsp+0x70], xmm8
00007aa9b5fdd198  vmovaps [rsp+0x80], xmm9
00007aa9b5fdd1a1  vmovaps [rsp+0x90], xmm10
00007aa9b5fdd1aa  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdd1b3  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdd1bc  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdd1c5  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdd1ce  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdd1d7  sub rsp, 0x30
00007aa9b5fdd1db  movaps [rsp], xmm6
00007aa9b5fdd1df  movaps [rsp+0x10], xmm1
00007aa9b5fdd1e4  movaps [rsp+0x20], xmm14
00007aa9b5fdd1ea  lea rdi, [rsp]
00007aa9b5fdd1ee  mov esi, 0x00
00007aa9b5fdd1f3  mov rax, 0x63E0217C9530
00007aa9b5fdd1fd  call rax
00007aa9b5fdd1ff  movaps xmm6, [rsp]
00007aa9b5fdd203  add rsp, 0x30
00007aa9b5fdd207  vmovaps xmm0, [rsp]
00007aa9b5fdd20c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdd212  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdd218  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdd21e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdd224  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdd22a  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdd230  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdd236  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdd23f  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdd248  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdd251  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdd25a  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdd263  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdd26c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdd275  add rsp, 0xF0
00007aa9b5fdd27c  pop r11
00007aa9b5fdd27e  pop r10
00007aa9b5fdd280  pop r9
00007aa9b5fdd282  pop r8
00007aa9b5fdd284  pop rsi
00007aa9b5fdd285  pop rdi
00007aa9b5fdd286  pop rdx
00007aa9b5fdd287  pop rcx
00007aa9b5fdd288  pop rax
00007aa9b5fdd289  add rsp, 0x08
00007aa9b5fdd28d  jmp 0x00007AA9B5FD95BA
00007aa9b5fdd292  sub rsp, 0x08
00007aa9b5fdd296  push rax
00007aa9b5fdd297  push rcx
00007aa9b5fdd298  push rdx
00007aa9b5fdd299  push rdi
00007aa9b5fdd29a  push rsi
00007aa9b5fdd29b  push r8
00007aa9b5fdd29d  push r9
00007aa9b5fdd29f  push r10
00007aa9b5fdd2a1  push r11
00007aa9b5fdd2a3  sub rsp, 0xF0
00007aa9b5fdd2aa  vmovaps [rsp], xmm0
00007aa9b5fdd2af  vmovaps [rsp+0x10], xmm1
00007aa9b5fdd2b5  vmovaps [rsp+0x20], xmm2
00007aa9b5fdd2bb  vmovaps [rsp+0x30], xmm3
00007aa9b5fdd2c1  vmovaps [rsp+0x40], xmm4
00007aa9b5fdd2c7  vmovaps [rsp+0x50], xmm5
00007aa9b5fdd2cd  vmovaps [rsp+0x60], xmm6
00007aa9b5fdd2d3  vmovaps [rsp+0x70], xmm7
00007aa9b5fdd2d9  vmovaps [rsp+0x80], xmm8
00007aa9b5fdd2e2  vmovaps [rsp+0x90], xmm9
00007aa9b5fdd2eb  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdd2f4  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdd2fd  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdd306  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdd30f  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdd318  sub rsp, 0x30
00007aa9b5fdd31c  movaps [rsp], xmm14
00007aa9b5fdd321  movaps [rsp+0x10], xmm12
00007aa9b5fdd327  movaps [rsp+0x20], xmm1
00007aa9b5fdd32c  lea rdi, [rsp]
00007aa9b5fdd330  mov esi, 0x00
00007aa9b5fdd335  mov rax, 0x63E0217C9530
00007aa9b5fdd33f  call rax
00007aa9b5fdd341  movaps xmm14, [rsp]
00007aa9b5fdd346  add rsp, 0x30
00007aa9b5fdd34a  vmovaps xmm0, [rsp]
00007aa9b5fdd34f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdd355  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdd35b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdd361  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdd367  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdd36d  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdd373  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdd379  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdd382  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdd38b  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdd394  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdd39d  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdd3a6  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdd3af  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdd3b8  add rsp, 0xF0
00007aa9b5fdd3bf  pop r11
00007aa9b5fdd3c1  pop r10
00007aa9b5fdd3c3  pop r9
00007aa9b5fdd3c5  pop r8
00007aa9b5fdd3c7  pop rsi
00007aa9b5fdd3c8  pop rdi
00007aa9b5fdd3c9  pop rdx
00007aa9b5fdd3ca  pop rcx
00007aa9b5fdd3cb  pop rax
00007aa9b5fdd3cc  add rsp, 0x08
00007aa9b5fdd3d0  jmp 0x00007AA9B5FD95E0
00007aa9b5fdd3d5  sub rsp, 0x08
00007aa9b5fdd3d9  push rax
00007aa9b5fdd3da  push rcx
00007aa9b5fdd3db  push rdx
00007aa9b5fdd3dc  push rdi
00007aa9b5fdd3dd  push rsi
00007aa9b5fdd3de  push r8
00007aa9b5fdd3e0  push r9
00007aa9b5fdd3e2  push r10
00007aa9b5fdd3e4  push r11
00007aa9b5fdd3e6  sub rsp, 0xF0
00007aa9b5fdd3ed  vmovaps [rsp], xmm0
00007aa9b5fdd3f2  vmovaps [rsp+0x10], xmm2
00007aa9b5fdd3f8  vmovaps [rsp+0x20], xmm3
00007aa9b5fdd3fe  vmovaps [rsp+0x30], xmm4
00007aa9b5fdd404  vmovaps [rsp+0x40], xmm5
00007aa9b5fdd40a  vmovaps [rsp+0x50], xmm6
00007aa9b5fdd410  vmovaps [rsp+0x60], xmm7
00007aa9b5fdd416  vmovaps [rsp+0x70], xmm8
00007aa9b5fdd41c  vmovaps [rsp+0x80], xmm9
00007aa9b5fdd425  vmovaps [rsp+0x90], xmm10
00007aa9b5fdd42e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdd437  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdd440  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdd449  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdd452  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdd45b  sub rsp, 0x30
00007aa9b5fdd45f  movaps [rsp], xmm1
00007aa9b5fdd463  movaps [rsp+0x10], xmm13
00007aa9b5fdd469  movaps [rsp+0x20], xmm9
00007aa9b5fdd46f  lea rdi, [rsp]
00007aa9b5fdd473  mov esi, 0x00
00007aa9b5fdd478  mov rax, 0x63E0217C9530
00007aa9b5fdd482  call rax
00007aa9b5fdd484  movaps xmm1, [rsp]
00007aa9b5fdd488  add rsp, 0x30
00007aa9b5fdd48c  vmovaps xmm0, [rsp]
00007aa9b5fdd491  vmovaps xmm2, [rsp+0x10]
00007aa9b5fdd497  vmovaps xmm3, [rsp+0x20]
00007aa9b5fdd49d  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdd4a3  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdd4a9  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdd4af  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdd4b5  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdd4bb  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdd4c4  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdd4cd  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdd4d6  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdd4df  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdd4e8  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdd4f1  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdd4fa  add rsp, 0xF0
00007aa9b5fdd501  pop r11
00007aa9b5fdd503  pop r10
00007aa9b5fdd505  pop r9
00007aa9b5fdd507  pop r8
00007aa9b5fdd509  pop rsi
00007aa9b5fdd50a  pop rdi
00007aa9b5fdd50b  pop rdx
00007aa9b5fdd50c  pop rcx
00007aa9b5fdd50d  pop rax
00007aa9b5fdd50e  add rsp, 0x08
00007aa9b5fdd512  jmp 0x00007AA9B5FD95FA
00007aa9b5fdd517  sub rsp, 0x08
00007aa9b5fdd51b  push rax
00007aa9b5fdd51c  push rcx
00007aa9b5fdd51d  push rdx
00007aa9b5fdd51e  push rdi
00007aa9b5fdd51f  push rsi
00007aa9b5fdd520  push r8
00007aa9b5fdd522  push r9
00007aa9b5fdd524  push r10
00007aa9b5fdd526  push r11
00007aa9b5fdd528  sub rsp, 0xF0
00007aa9b5fdd52f  vmovaps [rsp], xmm0
00007aa9b5fdd534  vmovaps [rsp+0x10], xmm1
00007aa9b5fdd53a  vmovaps [rsp+0x20], xmm2
00007aa9b5fdd540  vmovaps [rsp+0x30], xmm3
00007aa9b5fdd546  vmovaps [rsp+0x40], xmm4
00007aa9b5fdd54c  vmovaps [rsp+0x50], xmm5
00007aa9b5fdd552  vmovaps [rsp+0x60], xmm6
00007aa9b5fdd558  vmovaps [rsp+0x70], xmm7
00007aa9b5fdd55e  vmovaps [rsp+0x80], xmm8
00007aa9b5fdd567  vmovaps [rsp+0x90], xmm9
00007aa9b5fdd570  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdd579  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdd582  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdd58b  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdd594  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdd59d  sub rsp, 0x30
00007aa9b5fdd5a1  movaps [rsp], xmm12
00007aa9b5fdd5a6  movaps [rsp+0x10], xmm7
00007aa9b5fdd5ab  movaps [rsp+0x20], xmm13
00007aa9b5fdd5b1  lea rdi, [rsp]
00007aa9b5fdd5b5  mov esi, 0x00
00007aa9b5fdd5ba  mov rax, 0x63E0217C9530
00007aa9b5fdd5c4  call rax
00007aa9b5fdd5c6  movaps xmm12, [rsp]
00007aa9b5fdd5cb  add rsp, 0x30
00007aa9b5fdd5cf  vmovaps xmm0, [rsp]
00007aa9b5fdd5d4  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdd5da  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdd5e0  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdd5e6  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdd5ec  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdd5f2  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdd5f8  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdd5fe  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdd607  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdd610  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdd619  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdd622  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdd62b  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdd634  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdd63d  add rsp, 0xF0
00007aa9b5fdd644  pop r11
00007aa9b5fdd646  pop r10
00007aa9b5fdd648  pop r9
00007aa9b5fdd64a  pop r8
00007aa9b5fdd64c  pop rsi
00007aa9b5fdd64d  pop rdi
00007aa9b5fdd64e  pop rdx
00007aa9b5fdd64f  pop rcx
00007aa9b5fdd650  pop rax
00007aa9b5fdd651  add rsp, 0x08
00007aa9b5fdd655  jmp 0x00007AA9B5FD9621
00007aa9b5fdd65a  sub rsp, 0x08
00007aa9b5fdd65e  push rax
00007aa9b5fdd65f  push rcx
00007aa9b5fdd660  push rdx
00007aa9b5fdd661  push rdi
00007aa9b5fdd662  push rsi
00007aa9b5fdd663  push r8
00007aa9b5fdd665  push r9
00007aa9b5fdd667  push r10
00007aa9b5fdd669  push r11
00007aa9b5fdd66b  sub rsp, 0xF0
00007aa9b5fdd672  vmovaps [rsp], xmm0
00007aa9b5fdd677  vmovaps [rsp+0x10], xmm1
00007aa9b5fdd67d  vmovaps [rsp+0x20], xmm2
00007aa9b5fdd683  vmovaps [rsp+0x30], xmm3
00007aa9b5fdd689  vmovaps [rsp+0x40], xmm4
00007aa9b5fdd68f  vmovaps [rsp+0x50], xmm5
00007aa9b5fdd695  vmovaps [rsp+0x60], xmm6
00007aa9b5fdd69b  vmovaps [rsp+0x70], xmm7
00007aa9b5fdd6a1  vmovaps [rsp+0x80], xmm8
00007aa9b5fdd6aa  vmovaps [rsp+0x90], xmm9
00007aa9b5fdd6b3  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdd6bc  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdd6c5  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdd6ce  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdd6d7  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdd6e0  sub rsp, 0x30
00007aa9b5fdd6e4  movaps [rsp], xmm13
00007aa9b5fdd6e9  movaps [rsp+0x10], xmm15
00007aa9b5fdd6ef  movaps [rsp+0x20], xmm8
00007aa9b5fdd6f5  lea rdi, [rsp]
00007aa9b5fdd6f9  mov esi, 0x00
00007aa9b5fdd6fe  mov rax, 0x63E0217C9530
00007aa9b5fdd708  call rax
00007aa9b5fdd70a  movaps xmm13, [rsp]
00007aa9b5fdd70f  add rsp, 0x30
00007aa9b5fdd713  vmovaps xmm0, [rsp]
00007aa9b5fdd718  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdd71e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdd724  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdd72a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdd730  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdd736  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdd73c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdd742  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdd74b  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdd754  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdd75d  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdd766  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdd76f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdd778  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdd781  add rsp, 0xF0
00007aa9b5fdd788  pop r11
00007aa9b5fdd78a  pop r10
00007aa9b5fdd78c  pop r9
00007aa9b5fdd78e  pop r8
00007aa9b5fdd790  pop rsi
00007aa9b5fdd791  pop rdi
00007aa9b5fdd792  pop rdx
00007aa9b5fdd793  pop rcx
00007aa9b5fdd794  pop rax
00007aa9b5fdd795  add rsp, 0x08
00007aa9b5fdd799  jmp 0x00007AA9B5FD963C
00007aa9b5fdd79e  sub rsp, 0x08
00007aa9b5fdd7a2  push rax
00007aa9b5fdd7a3  push rcx
00007aa9b5fdd7a4  push rdx
00007aa9b5fdd7a5  push rdi
00007aa9b5fdd7a6  push rsi
00007aa9b5fdd7a7  push r8
00007aa9b5fdd7a9  push r9
00007aa9b5fdd7ab  push r10
00007aa9b5fdd7ad  push r11
00007aa9b5fdd7af  sub rsp, 0xF0
00007aa9b5fdd7b6  vmovaps [rsp], xmm0
00007aa9b5fdd7bb  vmovaps [rsp+0x10], xmm1
00007aa9b5fdd7c1  vmovaps [rsp+0x20], xmm2
00007aa9b5fdd7c7  vmovaps [rsp+0x30], xmm3
00007aa9b5fdd7cd  vmovaps [rsp+0x40], xmm4
00007aa9b5fdd7d3  vmovaps [rsp+0x50], xmm5
00007aa9b5fdd7d9  vmovaps [rsp+0x60], xmm6
00007aa9b5fdd7df  vmovaps [rsp+0x70], xmm7
00007aa9b5fdd7e5  vmovaps [rsp+0x80], xmm9
00007aa9b5fdd7ee  vmovaps [rsp+0x90], xmm10
00007aa9b5fdd7f7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdd800  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdd809  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdd812  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdd81b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdd824  sub rsp, 0x30
00007aa9b5fdd828  movaps [rsp], xmm8
00007aa9b5fdd82d  movaps [rsp+0x10], xmm15
00007aa9b5fdd833  movaps [rsp+0x20], xmm9
00007aa9b5fdd839  lea rdi, [rsp]
00007aa9b5fdd83d  mov esi, 0x00
00007aa9b5fdd842  mov rax, 0x63E0217C9530
00007aa9b5fdd84c  call rax
00007aa9b5fdd84e  movaps xmm8, [rsp]
00007aa9b5fdd853  add rsp, 0x30
00007aa9b5fdd857  vmovaps xmm0, [rsp]
00007aa9b5fdd85c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdd862  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdd868  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdd86e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdd874  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdd87a  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdd880  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdd886  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdd88f  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdd898  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdd8a1  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdd8aa  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdd8b3  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdd8bc  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdd8c5  add rsp, 0xF0
00007aa9b5fdd8cc  pop r11
00007aa9b5fdd8ce  pop r10
00007aa9b5fdd8d0  pop r9
00007aa9b5fdd8d2  pop r8
00007aa9b5fdd8d4  pop rsi
00007aa9b5fdd8d5  pop rdi
00007aa9b5fdd8d6  pop rdx
00007aa9b5fdd8d7  pop rcx
00007aa9b5fdd8d8  pop rax
00007aa9b5fdd8d9  add rsp, 0x08
00007aa9b5fdd8dd  jmp 0x00007AA9B5FD966A
00007aa9b5fdd8e2  sub rsp, 0x08
00007aa9b5fdd8e6  push rax
00007aa9b5fdd8e7  push rcx
00007aa9b5fdd8e8  push rdx
00007aa9b5fdd8e9  push rdi
00007aa9b5fdd8ea  push rsi
00007aa9b5fdd8eb  push r8
00007aa9b5fdd8ed  push r9
00007aa9b5fdd8ef  push r10
00007aa9b5fdd8f1  push r11
00007aa9b5fdd8f3  sub rsp, 0xF0
00007aa9b5fdd8fa  vmovaps [rsp], xmm0
00007aa9b5fdd8ff  vmovaps [rsp+0x10], xmm1
00007aa9b5fdd905  vmovaps [rsp+0x20], xmm2
00007aa9b5fdd90b  vmovaps [rsp+0x30], xmm3
00007aa9b5fdd911  vmovaps [rsp+0x40], xmm4
00007aa9b5fdd917  vmovaps [rsp+0x50], xmm5
00007aa9b5fdd91d  vmovaps [rsp+0x60], xmm6
00007aa9b5fdd923  vmovaps [rsp+0x70], xmm7
00007aa9b5fdd929  vmovaps [rsp+0x80], xmm8
00007aa9b5fdd932  vmovaps [rsp+0x90], xmm9
00007aa9b5fdd93b  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdd944  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdd94d  vmovaps [rsp+0xC0], xmm12
00007aa9b5fdd956  vmovaps [rsp+0xD0], xmm13
00007aa9b5fdd95f  vmovaps [rsp+0xE0], xmm14
00007aa9b5fdd968  sub rsp, 0x30
00007aa9b5fdd96c  movaps [rsp], xmm15
00007aa9b5fdd971  movaps [rsp+0x10], xmm11
00007aa9b5fdd977  movaps [rsp+0x20], xmm6
00007aa9b5fdd97c  lea rdi, [rsp]
00007aa9b5fdd980  mov esi, 0x00
00007aa9b5fdd985  mov rax, 0x63E0217C9530
00007aa9b5fdd98f  call rax
00007aa9b5fdd991  movaps xmm15, [rsp]
00007aa9b5fdd996  add rsp, 0x30
00007aa9b5fdd99a  vmovaps xmm0, [rsp]
00007aa9b5fdd99f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdd9a5  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdd9ab  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdd9b1  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdd9b7  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdd9bd  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdd9c3  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdd9c9  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdd9d2  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdd9db  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fdd9e4  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fdd9ed  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fdd9f6  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fdd9ff  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fdda08  add rsp, 0xF0
00007aa9b5fdda0f  pop r11
00007aa9b5fdda11  pop r10
00007aa9b5fdda13  pop r9
00007aa9b5fdda15  pop r8
00007aa9b5fdda17  pop rsi
00007aa9b5fdda18  pop rdi
00007aa9b5fdda19  pop rdx
00007aa9b5fdda1a  pop rcx
00007aa9b5fdda1b  pop rax
00007aa9b5fdda1c  add rsp, 0x08
00007aa9b5fdda20  jmp 0x00007AA9B5FD9685
00007aa9b5fdda25  sub rsp, 0x08
00007aa9b5fdda29  push rax
00007aa9b5fdda2a  push rcx
00007aa9b5fdda2b  push rdx
00007aa9b5fdda2c  push rdi
00007aa9b5fdda2d  push rsi
00007aa9b5fdda2e  push r8
00007aa9b5fdda30  push r9
00007aa9b5fdda32  push r10
00007aa9b5fdda34  push r11
00007aa9b5fdda36  sub rsp, 0xF0
00007aa9b5fdda3d  vmovaps [rsp], xmm0
00007aa9b5fdda42  vmovaps [rsp+0x10], xmm1
00007aa9b5fdda48  vmovaps [rsp+0x20], xmm2
00007aa9b5fdda4e  vmovaps [rsp+0x30], xmm3
00007aa9b5fdda54  vmovaps [rsp+0x40], xmm4
00007aa9b5fdda5a  vmovaps [rsp+0x50], xmm5
00007aa9b5fdda60  vmovaps [rsp+0x60], xmm6
00007aa9b5fdda66  vmovaps [rsp+0x70], xmm8
00007aa9b5fdda6c  vmovaps [rsp+0x80], xmm9
00007aa9b5fdda75  vmovaps [rsp+0x90], xmm10
00007aa9b5fdda7e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdda87  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdda90  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdda99  vmovaps [rsp+0xD0], xmm14
00007aa9b5fddaa2  vmovaps [rsp+0xE0], xmm15
00007aa9b5fddaab  sub rsp, 0x30
00007aa9b5fddaaf  movaps [rsp], xmm7
00007aa9b5fddab3  movaps [rsp+0x10], xmm11
00007aa9b5fddab9  movaps [rsp+0x20], xmm9
00007aa9b5fddabf  lea rdi, [rsp]
00007aa9b5fddac3  mov esi, 0x00
00007aa9b5fddac8  mov rax, 0x63E0217C9530
00007aa9b5fddad2  call rax
00007aa9b5fddad4  movaps xmm7, [rsp]
00007aa9b5fddad8  add rsp, 0x30
00007aa9b5fddadc  vmovaps xmm0, [rsp]
00007aa9b5fddae1  vmovaps xmm1, [rsp+0x10]
00007aa9b5fddae7  vmovaps xmm2, [rsp+0x20]
00007aa9b5fddaed  vmovaps xmm3, [rsp+0x30]
00007aa9b5fddaf3  vmovaps xmm4, [rsp+0x40]
00007aa9b5fddaf9  vmovaps xmm5, [rsp+0x50]
00007aa9b5fddaff  vmovaps xmm6, [rsp+0x60]
00007aa9b5fddb05  vmovaps xmm8, [rsp+0x70]
00007aa9b5fddb0b  vmovaps xmm9, [rsp+0x80]
00007aa9b5fddb14  vmovaps xmm10, [rsp+0x90]
00007aa9b5fddb1d  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fddb26  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fddb2f  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fddb38  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fddb41  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fddb4a  add rsp, 0xF0
00007aa9b5fddb51  pop r11
00007aa9b5fddb53  pop r10
00007aa9b5fddb55  pop r9
00007aa9b5fddb57  pop r8
00007aa9b5fddb59  pop rsi
00007aa9b5fddb5a  pop rdi
00007aa9b5fddb5b  pop rdx
00007aa9b5fddb5c  pop rcx
00007aa9b5fddb5d  pop rax
00007aa9b5fddb5e  add rsp, 0x08
00007aa9b5fddb62  jmp 0x00007AA9B5FD96B2
00007aa9b5fddb67  sub rsp, 0x08
00007aa9b5fddb6b  push rax
00007aa9b5fddb6c  push rcx
00007aa9b5fddb6d  push rdx
00007aa9b5fddb6e  push rdi
00007aa9b5fddb6f  push rsi
00007aa9b5fddb70  push r8
00007aa9b5fddb72  push r9
00007aa9b5fddb74  push r10
00007aa9b5fddb76  push r11
00007aa9b5fddb78  sub rsp, 0xF0
00007aa9b5fddb7f  vmovaps [rsp], xmm0
00007aa9b5fddb84  vmovaps [rsp+0x10], xmm1
00007aa9b5fddb8a  vmovaps [rsp+0x20], xmm2
00007aa9b5fddb90  vmovaps [rsp+0x30], xmm3
00007aa9b5fddb96  vmovaps [rsp+0x40], xmm4
00007aa9b5fddb9c  vmovaps [rsp+0x50], xmm5
00007aa9b5fddba2  vmovaps [rsp+0x60], xmm6
00007aa9b5fddba8  vmovaps [rsp+0x70], xmm7
00007aa9b5fddbae  vmovaps [rsp+0x80], xmm8
00007aa9b5fddbb7  vmovaps [rsp+0x90], xmm9
00007aa9b5fddbc0  vmovaps [rsp+0xA0], xmm10
00007aa9b5fddbc9  vmovaps [rsp+0xB0], xmm12
00007aa9b5fddbd2  vmovaps [rsp+0xC0], xmm13
00007aa9b5fddbdb  vmovaps [rsp+0xD0], xmm14
00007aa9b5fddbe4  vmovaps [rsp+0xE0], xmm15
00007aa9b5fddbed  sub rsp, 0x30
00007aa9b5fddbf1  movaps [rsp], xmm11
00007aa9b5fddbf6  movaps [rsp+0x10], xmm10
00007aa9b5fddbfc  movaps [rsp+0x20], xmm14
00007aa9b5fddc02  lea rdi, [rsp]
00007aa9b5fddc06  mov esi, 0x00
00007aa9b5fddc0b  mov rax, 0x63E0217C9530
00007aa9b5fddc15  call rax
00007aa9b5fddc17  movaps xmm11, [rsp]
00007aa9b5fddc1c  add rsp, 0x30
00007aa9b5fddc20  vmovaps xmm0, [rsp]
00007aa9b5fddc25  vmovaps xmm1, [rsp+0x10]
00007aa9b5fddc2b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fddc31  vmovaps xmm3, [rsp+0x30]
00007aa9b5fddc37  vmovaps xmm4, [rsp+0x40]
00007aa9b5fddc3d  vmovaps xmm5, [rsp+0x50]
00007aa9b5fddc43  vmovaps xmm6, [rsp+0x60]
00007aa9b5fddc49  vmovaps xmm7, [rsp+0x70]
00007aa9b5fddc4f  vmovaps xmm8, [rsp+0x80]
00007aa9b5fddc58  vmovaps xmm9, [rsp+0x90]
00007aa9b5fddc61  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fddc6a  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fddc73  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fddc7c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fddc85  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fddc8e  add rsp, 0xF0
00007aa9b5fddc95  pop r11
00007aa9b5fddc97  pop r10
00007aa9b5fddc99  pop r9
00007aa9b5fddc9b  pop r8
00007aa9b5fddc9d  pop rsi
00007aa9b5fddc9e  pop rdi
00007aa9b5fddc9f  pop rdx
00007aa9b5fddca0  pop rcx
00007aa9b5fddca1  pop rax
00007aa9b5fddca2  add rsp, 0x08
00007aa9b5fddca6  jmp 0x00007AA9B5FD96CD
00007aa9b5fddcab  call 0x00007AA9B5EE45A0
00007aa9b5fddcb0  jmp 0x00007AA9B5FD96D7
00007aa9b5fddcb5  sub rsp, 0x08
00007aa9b5fddcb9  push rax
00007aa9b5fddcba  push rcx
00007aa9b5fddcbb  push rdx
00007aa9b5fddcbc  push rdi
00007aa9b5fddcbd  push rsi
00007aa9b5fddcbe  push r8
00007aa9b5fddcc0  push r9
00007aa9b5fddcc2  push r10
00007aa9b5fddcc4  push r11
00007aa9b5fddcc6  sub rsp, 0xF0
00007aa9b5fddccd  vmovaps [rsp], xmm0
00007aa9b5fddcd2  vmovaps [rsp+0x10], xmm1
00007aa9b5fddcd8  vmovaps [rsp+0x20], xmm2
00007aa9b5fddcde  vmovaps [rsp+0x30], xmm3
00007aa9b5fddce4  vmovaps [rsp+0x40], xmm4
00007aa9b5fddcea  vmovaps [rsp+0x50], xmm5
00007aa9b5fddcf0  vmovaps [rsp+0x60], xmm6
00007aa9b5fddcf6  vmovaps [rsp+0x70], xmm7
00007aa9b5fddcfc  vmovaps [rsp+0x80], xmm8
00007aa9b5fddd05  vmovaps [rsp+0x90], xmm9
00007aa9b5fddd0e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fddd17  vmovaps [rsp+0xB0], xmm12
00007aa9b5fddd20  vmovaps [rsp+0xC0], xmm13
00007aa9b5fddd29  vmovaps [rsp+0xD0], xmm14
00007aa9b5fddd32  vmovaps [rsp+0xE0], xmm15
00007aa9b5fddd3b  sub rsp, 0x30
00007aa9b5fddd3f  movaps [rsp], xmm10
00007aa9b5fddd44  movaps [rsp+0x10], xmm1
00007aa9b5fddd49  movaps [rsp+0x20], xmm12
00007aa9b5fddd4f  lea rdi, [rsp]
00007aa9b5fddd53  mov esi, 0x00
00007aa9b5fddd58  mov rax, 0x63E0217C9530
00007aa9b5fddd62  call rax
00007aa9b5fddd64  movaps xmm10, [rsp]
00007aa9b5fddd69  add rsp, 0x30
00007aa9b5fddd6d  vmovaps xmm0, [rsp]
00007aa9b5fddd72  vmovaps xmm1, [rsp+0x10]
00007aa9b5fddd78  vmovaps xmm2, [rsp+0x20]
00007aa9b5fddd7e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fddd84  vmovaps xmm4, [rsp+0x40]
00007aa9b5fddd8a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fddd90  vmovaps xmm6, [rsp+0x60]
00007aa9b5fddd96  vmovaps xmm7, [rsp+0x70]
00007aa9b5fddd9c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fddda5  vmovaps xmm9, [rsp+0x90]
00007aa9b5fdddae  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdddb7  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdddc0  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdddc9  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdddd2  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fddddb  add rsp, 0xF0
00007aa9b5fddde2  pop r11
00007aa9b5fddde4  pop r10
00007aa9b5fddde6  pop r9
00007aa9b5fddde8  pop r8
00007aa9b5fdddea  pop rsi
00007aa9b5fdddeb  pop rdi
00007aa9b5fdddec  pop rdx
00007aa9b5fddded  pop rcx
00007aa9b5fdddee  pop rax
00007aa9b5fdddef  add rsp, 0x08
00007aa9b5fdddf3  jmp 0x00007AA9B5FD96FA
00007aa9b5fdddf8  sub rsp, 0x08
00007aa9b5fdddfc  push rax
00007aa9b5fdddfd  push rcx
00007aa9b5fdddfe  push rdx
00007aa9b5fdddff  push rdi
00007aa9b5fdde00  push rsi
00007aa9b5fdde01  push r8
00007aa9b5fdde03  push r9
00007aa9b5fdde05  push r10
00007aa9b5fdde07  push r11
00007aa9b5fdde09  sub rsp, 0xF0
00007aa9b5fdde10  vmovaps [rsp], xmm0
00007aa9b5fdde15  vmovaps [rsp+0x10], xmm1
00007aa9b5fdde1b  vmovaps [rsp+0x20], xmm2
00007aa9b5fdde21  vmovaps [rsp+0x30], xmm3
00007aa9b5fdde27  vmovaps [rsp+0x40], xmm4
00007aa9b5fdde2d  vmovaps [rsp+0x50], xmm5
00007aa9b5fdde33  vmovaps [rsp+0x60], xmm6
00007aa9b5fdde39  vmovaps [rsp+0x70], xmm7
00007aa9b5fdde3f  vmovaps [rsp+0x80], xmm8
00007aa9b5fdde48  vmovaps [rsp+0x90], xmm9
00007aa9b5fdde51  vmovaps [rsp+0xA0], xmm10
00007aa9b5fdde5a  vmovaps [rsp+0xB0], xmm11
00007aa9b5fdde63  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdde6c  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdde75  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdde7e  sub rsp, 0x30
00007aa9b5fdde82  movaps [rsp], xmm12
00007aa9b5fdde87  movaps [rsp+0x10], xmm14
00007aa9b5fdde8d  movaps [rsp+0x20], xmm1
00007aa9b5fdde92  lea rdi, [rsp]
00007aa9b5fdde96  mov esi, 0x00
00007aa9b5fdde9b  mov rax, 0x63E0217C9530
00007aa9b5fddea5  call rax
00007aa9b5fddea7  movaps xmm12, [rsp]
00007aa9b5fddeac  add rsp, 0x30
00007aa9b5fddeb0  vmovaps xmm0, [rsp]
00007aa9b5fddeb5  vmovaps xmm1, [rsp+0x10]
00007aa9b5fddebb  vmovaps xmm2, [rsp+0x20]
00007aa9b5fddec1  vmovaps xmm3, [rsp+0x30]
00007aa9b5fddec7  vmovaps xmm4, [rsp+0x40]
00007aa9b5fddecd  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdded3  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdded9  vmovaps xmm7, [rsp+0x70]
00007aa9b5fddedf  vmovaps xmm8, [rsp+0x80]
00007aa9b5fddee8  vmovaps xmm9, [rsp+0x90]
00007aa9b5fddef1  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fddefa  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fddf03  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fddf0c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fddf15  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fddf1e  add rsp, 0xF0
00007aa9b5fddf25  pop r11
00007aa9b5fddf27  pop r10
00007aa9b5fddf29  pop r9
00007aa9b5fddf2b  pop r8
00007aa9b5fddf2d  pop rsi
00007aa9b5fddf2e  pop rdi
00007aa9b5fddf2f  pop rdx
00007aa9b5fddf30  pop rcx
00007aa9b5fddf31  pop rax
00007aa9b5fddf32  add rsp, 0x08
00007aa9b5fddf36  jmp 0x00007AA9B5FD9729
00007aa9b5fddf3b  sub rsp, 0x08
00007aa9b5fddf3f  push rax
00007aa9b5fddf40  push rcx
00007aa9b5fddf41  push rdx
00007aa9b5fddf42  push rdi
00007aa9b5fddf43  push rsi
00007aa9b5fddf44  push r8
00007aa9b5fddf46  push r9
00007aa9b5fddf48  push r10
00007aa9b5fddf4a  push r11
00007aa9b5fddf4c  sub rsp, 0xF0
00007aa9b5fddf53  vmovaps [rsp], xmm0
00007aa9b5fddf58  vmovaps [rsp+0x10], xmm1
00007aa9b5fddf5e  vmovaps [rsp+0x20], xmm2
00007aa9b5fddf64  vmovaps [rsp+0x30], xmm3
00007aa9b5fddf6a  vmovaps [rsp+0x40], xmm4
00007aa9b5fddf70  vmovaps [rsp+0x50], xmm5
00007aa9b5fddf76  vmovaps [rsp+0x60], xmm6
00007aa9b5fddf7c  vmovaps [rsp+0x70], xmm7
00007aa9b5fddf82  vmovaps [rsp+0x80], xmm8
00007aa9b5fddf8b  vmovaps [rsp+0x90], xmm9
00007aa9b5fddf94  vmovaps [rsp+0xA0], xmm10
00007aa9b5fddf9d  vmovaps [rsp+0xB0], xmm11
00007aa9b5fddfa6  vmovaps [rsp+0xC0], xmm12
00007aa9b5fddfaf  vmovaps [rsp+0xD0], xmm13
00007aa9b5fddfb8  vmovaps [rsp+0xE0], xmm15
00007aa9b5fddfc1  sub rsp, 0x30
00007aa9b5fddfc5  movaps [rsp], xmm14
00007aa9b5fddfca  movaps [rsp+0x10], xmm9
00007aa9b5fddfd0  movaps [rsp+0x20], xmm1
00007aa9b5fddfd5  lea rdi, [rsp]
00007aa9b5fddfd9  mov esi, 0x00
00007aa9b5fddfde  mov rax, 0x63E0217C9530
00007aa9b5fddfe8  call rax
00007aa9b5fddfea  movaps xmm14, [rsp]
00007aa9b5fddfef  add rsp, 0x30
00007aa9b5fddff3  vmovaps xmm0, [rsp]
00007aa9b5fddff8  vmovaps xmm1, [rsp+0x10]
00007aa9b5fddffe  vmovaps xmm2, [rsp+0x20]
00007aa9b5fde004  vmovaps xmm3, [rsp+0x30]
00007aa9b5fde00a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fde010  vmovaps xmm5, [rsp+0x50]
00007aa9b5fde016  vmovaps xmm6, [rsp+0x60]
00007aa9b5fde01c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fde022  vmovaps xmm8, [rsp+0x80]
00007aa9b5fde02b  vmovaps xmm9, [rsp+0x90]
00007aa9b5fde034  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fde03d  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fde046  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fde04f  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fde058  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fde061  add rsp, 0xF0
00007aa9b5fde068  pop r11
00007aa9b5fde06a  pop r10
00007aa9b5fde06c  pop r9
00007aa9b5fde06e  pop r8
00007aa9b5fde070  pop rsi
00007aa9b5fde071  pop rdi
00007aa9b5fde072  pop rdx
00007aa9b5fde073  pop rcx
00007aa9b5fde074  pop rax
00007aa9b5fde075  add rsp, 0x08
00007aa9b5fde079  jmp 0x00007AA9B5FD9758
00007aa9b5fde07e  sub rsp, 0x08
00007aa9b5fde082  push rax
00007aa9b5fde083  push rcx
00007aa9b5fde084  push rdx
00007aa9b5fde085  push rdi
00007aa9b5fde086  push rsi
00007aa9b5fde087  push r8
00007aa9b5fde089  push r9
00007aa9b5fde08b  push r10
00007aa9b5fde08d  push r11
00007aa9b5fde08f  sub rsp, 0xF0
00007aa9b5fde096  vmovaps [rsp], xmm0
00007aa9b5fde09b  vmovaps [rsp+0x10], xmm2
00007aa9b5fde0a1  vmovaps [rsp+0x20], xmm3
00007aa9b5fde0a7  vmovaps [rsp+0x30], xmm4
00007aa9b5fde0ad  vmovaps [rsp+0x40], xmm5
00007aa9b5fde0b3  vmovaps [rsp+0x50], xmm6
00007aa9b5fde0b9  vmovaps [rsp+0x60], xmm7
00007aa9b5fde0bf  vmovaps [rsp+0x70], xmm8
00007aa9b5fde0c5  vmovaps [rsp+0x80], xmm9
00007aa9b5fde0ce  vmovaps [rsp+0x90], xmm10
00007aa9b5fde0d7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fde0e0  vmovaps [rsp+0xB0], xmm12
00007aa9b5fde0e9  vmovaps [rsp+0xC0], xmm13
00007aa9b5fde0f2  vmovaps [rsp+0xD0], xmm14
00007aa9b5fde0fb  vmovaps [rsp+0xE0], xmm15
00007aa9b5fde104  sub rsp, 0x30
00007aa9b5fde108  movaps [rsp], xmm1
00007aa9b5fde10c  movaps [rsp+0x10], xmm13
00007aa9b5fde112  movaps [rsp+0x20], xmm8
00007aa9b5fde118  lea rdi, [rsp]
00007aa9b5fde11c  mov esi, 0x00
00007aa9b5fde121  mov rax, 0x63E0217C9530
00007aa9b5fde12b  call rax
00007aa9b5fde12d  movaps xmm1, [rsp]
00007aa9b5fde131  add rsp, 0x30
00007aa9b5fde135  vmovaps xmm0, [rsp]
00007aa9b5fde13a  vmovaps xmm2, [rsp+0x10]
00007aa9b5fde140  vmovaps xmm3, [rsp+0x20]
00007aa9b5fde146  vmovaps xmm4, [rsp+0x30]
00007aa9b5fde14c  vmovaps xmm5, [rsp+0x40]
00007aa9b5fde152  vmovaps xmm6, [rsp+0x50]
00007aa9b5fde158  vmovaps xmm7, [rsp+0x60]
00007aa9b5fde15e  vmovaps xmm8, [rsp+0x70]
00007aa9b5fde164  vmovaps xmm9, [rsp+0x80]
00007aa9b5fde16d  vmovaps xmm10, [rsp+0x90]
00007aa9b5fde176  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fde17f  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fde188  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fde191  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fde19a  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fde1a3  add rsp, 0xF0
00007aa9b5fde1aa  pop r11
00007aa9b5fde1ac  pop r10
00007aa9b5fde1ae  pop r9
00007aa9b5fde1b0  pop r8
00007aa9b5fde1b2  pop rsi
00007aa9b5fde1b3  pop rdi
00007aa9b5fde1b4  pop rdx
00007aa9b5fde1b5  pop rcx
00007aa9b5fde1b6  pop rax
00007aa9b5fde1b7  add rsp, 0x08
00007aa9b5fde1bb  jmp 0x00007AA9B5FD977A
00007aa9b5fde1c0  call 0x00007AA9B5E0C260
00007aa9b5fde1c5  jmp 0x00007AA9B5FD9788
00007aa9b5fde1ca  call 0x00007AA9B5EDE950
00007aa9b5fde1cf  jmp 0x00007AA9B5FD9792
00007aa9b5fde1d4  sub rsp, 0x08
00007aa9b5fde1d8  push rax
00007aa9b5fde1d9  push rcx
00007aa9b5fde1da  push rdx
00007aa9b5fde1db  push rdi
00007aa9b5fde1dc  push rsi
00007aa9b5fde1dd  push r8
00007aa9b5fde1df  push r9
00007aa9b5fde1e1  push r10
00007aa9b5fde1e3  push r11
00007aa9b5fde1e5  sub rsp, 0xF0
00007aa9b5fde1ec  vmovaps [rsp], xmm0
00007aa9b5fde1f1  vmovaps [rsp+0x10], xmm1
00007aa9b5fde1f7  vmovaps [rsp+0x20], xmm2
00007aa9b5fde1fd  vmovaps [rsp+0x30], xmm3
00007aa9b5fde203  vmovaps [rsp+0x40], xmm4
00007aa9b5fde209  vmovaps [rsp+0x50], xmm5
00007aa9b5fde20f  vmovaps [rsp+0x60], xmm6
00007aa9b5fde215  vmovaps [rsp+0x70], xmm7
00007aa9b5fde21b  vmovaps [rsp+0x80], xmm9
00007aa9b5fde224  vmovaps [rsp+0x90], xmm10
00007aa9b5fde22d  vmovaps [rsp+0xA0], xmm11
00007aa9b5fde236  vmovaps [rsp+0xB0], xmm12
00007aa9b5fde23f  vmovaps [rsp+0xC0], xmm13
00007aa9b5fde248  vmovaps [rsp+0xD0], xmm14
00007aa9b5fde251  vmovaps [rsp+0xE0], xmm15
00007aa9b5fde25a  sub rsp, 0x30
00007aa9b5fde25e  movaps [rsp], xmm8
00007aa9b5fde263  movaps [rsp+0x10], xmm15
00007aa9b5fde269  movaps [rsp+0x20], xmm7
00007aa9b5fde26e  lea rdi, [rsp]
00007aa9b5fde272  mov esi, 0x00
00007aa9b5fde277  mov rax, 0x63E0217C9530
00007aa9b5fde281  call rax
00007aa9b5fde283  movaps xmm8, [rsp]
00007aa9b5fde288  add rsp, 0x30
00007aa9b5fde28c  vmovaps xmm0, [rsp]
00007aa9b5fde291  vmovaps xmm1, [rsp+0x10]
00007aa9b5fde297  vmovaps xmm2, [rsp+0x20]
00007aa9b5fde29d  vmovaps xmm3, [rsp+0x30]
00007aa9b5fde2a3  vmovaps xmm4, [rsp+0x40]
00007aa9b5fde2a9  vmovaps xmm5, [rsp+0x50]
00007aa9b5fde2af  vmovaps xmm6, [rsp+0x60]
00007aa9b5fde2b5  vmovaps xmm7, [rsp+0x70]
00007aa9b5fde2bb  vmovaps xmm9, [rsp+0x80]
00007aa9b5fde2c4  vmovaps xmm10, [rsp+0x90]
00007aa9b5fde2cd  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fde2d6  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fde2df  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fde2e8  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fde2f1  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fde2fa  add rsp, 0xF0
00007aa9b5fde301  pop r11
00007aa9b5fde303  pop r10
00007aa9b5fde305  pop r9
00007aa9b5fde307  pop r8
00007aa9b5fde309  pop rsi
00007aa9b5fde30a  pop rdi
00007aa9b5fde30b  pop rdx
00007aa9b5fde30c  pop rcx
00007aa9b5fde30d  pop rax
00007aa9b5fde30e  add rsp, 0x08
00007aa9b5fde312  jmp 0x00007AA9B5FD97B4
00007aa9b5fde317  sub rsp, 0x08
00007aa9b5fde31b  push rax
00007aa9b5fde31c  push rcx
00007aa9b5fde31d  push rdx
00007aa9b5fde31e  push rdi
00007aa9b5fde31f  push rsi
00007aa9b5fde320  push r8
00007aa9b5fde322  push r9
00007aa9b5fde324  push r10
00007aa9b5fde326  push r11
00007aa9b5fde328  sub rsp, 0xF0
00007aa9b5fde32f  vmovaps [rsp], xmm0
00007aa9b5fde334  vmovaps [rsp+0x10], xmm1
00007aa9b5fde33a  vmovaps [rsp+0x20], xmm2
00007aa9b5fde340  vmovaps [rsp+0x30], xmm3
00007aa9b5fde346  vmovaps [rsp+0x40], xmm4
00007aa9b5fde34c  vmovaps [rsp+0x50], xmm5
00007aa9b5fde352  vmovaps [rsp+0x60], xmm6
00007aa9b5fde358  vmovaps [rsp+0x70], xmm8
00007aa9b5fde35e  vmovaps [rsp+0x80], xmm9
00007aa9b5fde367  vmovaps [rsp+0x90], xmm10
00007aa9b5fde370  vmovaps [rsp+0xA0], xmm11
00007aa9b5fde379  vmovaps [rsp+0xB0], xmm12
00007aa9b5fde382  vmovaps [rsp+0xC0], xmm13
00007aa9b5fde38b  vmovaps [rsp+0xD0], xmm14
00007aa9b5fde394  vmovaps [rsp+0xE0], xmm15
00007aa9b5fde39d  sub rsp, 0x30
00007aa9b5fde3a1  movaps [rsp], xmm7
00007aa9b5fde3a5  movaps [rsp+0x10], xmm9
00007aa9b5fde3ab  movaps [rsp+0x20], xmm15
00007aa9b5fde3b1  lea rdi, [rsp]
00007aa9b5fde3b5  mov esi, 0x00
00007aa9b5fde3ba  mov rax, 0x63E0217C9530
00007aa9b5fde3c4  call rax
00007aa9b5fde3c6  movaps xmm7, [rsp]
00007aa9b5fde3ca  add rsp, 0x30
00007aa9b5fde3ce  vmovaps xmm0, [rsp]
00007aa9b5fde3d3  vmovaps xmm1, [rsp+0x10]
00007aa9b5fde3d9  vmovaps xmm2, [rsp+0x20]
00007aa9b5fde3df  vmovaps xmm3, [rsp+0x30]
00007aa9b5fde3e5  vmovaps xmm4, [rsp+0x40]
00007aa9b5fde3eb  vmovaps xmm5, [rsp+0x50]
00007aa9b5fde3f1  vmovaps xmm6, [rsp+0x60]
00007aa9b5fde3f7  vmovaps xmm8, [rsp+0x70]
00007aa9b5fde3fd  vmovaps xmm9, [rsp+0x80]
00007aa9b5fde406  vmovaps xmm10, [rsp+0x90]
00007aa9b5fde40f  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fde418  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fde421  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fde42a  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fde433  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fde43c  add rsp, 0xF0
00007aa9b5fde443  pop r11
00007aa9b5fde445  pop r10
00007aa9b5fde447  pop r9
00007aa9b5fde449  pop r8
00007aa9b5fde44b  pop rsi
00007aa9b5fde44c  pop rdi
00007aa9b5fde44d  pop rdx
00007aa9b5fde44e  pop rcx
00007aa9b5fde44f  pop rax
00007aa9b5fde450  add rsp, 0x08
00007aa9b5fde454  jmp 0x00007AA9B5FD97E1
00007aa9b5fde459  sub rsp, 0x08
00007aa9b5fde45d  push rax
00007aa9b5fde45e  push rcx
00007aa9b5fde45f  push rdx
00007aa9b5fde460  push rdi
00007aa9b5fde461  push rsi
00007aa9b5fde462  push r8
00007aa9b5fde464  push r9
00007aa9b5fde466  push r10
00007aa9b5fde468  push r11
00007aa9b5fde46a  sub rsp, 0xF0
00007aa9b5fde471  vmovaps [rsp], xmm0
00007aa9b5fde476  vmovaps [rsp+0x10], xmm1
00007aa9b5fde47c  vmovaps [rsp+0x20], xmm2
00007aa9b5fde482  vmovaps [rsp+0x30], xmm3
00007aa9b5fde488  vmovaps [rsp+0x40], xmm4
00007aa9b5fde48e  vmovaps [rsp+0x50], xmm5
00007aa9b5fde494  vmovaps [rsp+0x60], xmm6
00007aa9b5fde49a  vmovaps [rsp+0x70], xmm7
00007aa9b5fde4a0  vmovaps [rsp+0x80], xmm8
00007aa9b5fde4a9  vmovaps [rsp+0x90], xmm10
00007aa9b5fde4b2  vmovaps [rsp+0xA0], xmm11
00007aa9b5fde4bb  vmovaps [rsp+0xB0], xmm12
00007aa9b5fde4c4  vmovaps [rsp+0xC0], xmm13
00007aa9b5fde4cd  vmovaps [rsp+0xD0], xmm14
00007aa9b5fde4d6  vmovaps [rsp+0xE0], xmm15
00007aa9b5fde4df  sub rsp, 0x30
00007aa9b5fde4e3  movaps [rsp], xmm9
00007aa9b5fde4e8  movaps [rsp+0x10], xmm13
00007aa9b5fde4ee  movaps [rsp+0x20], xmm15
00007aa9b5fde4f4  lea rdi, [rsp]
00007aa9b5fde4f8  mov esi, 0x00
00007aa9b5fde4fd  mov rax, 0x63E0217C9530
00007aa9b5fde507  call rax
00007aa9b5fde509  movaps xmm9, [rsp]
00007aa9b5fde50e  add rsp, 0x30
00007aa9b5fde512  vmovaps xmm0, [rsp]
00007aa9b5fde517  vmovaps xmm1, [rsp+0x10]
00007aa9b5fde51d  vmovaps xmm2, [rsp+0x20]
00007aa9b5fde523  vmovaps xmm3, [rsp+0x30]
00007aa9b5fde529  vmovaps xmm4, [rsp+0x40]
00007aa9b5fde52f  vmovaps xmm5, [rsp+0x50]
00007aa9b5fde535  vmovaps xmm6, [rsp+0x60]
00007aa9b5fde53b  vmovaps xmm7, [rsp+0x70]
00007aa9b5fde541  vmovaps xmm8, [rsp+0x80]
00007aa9b5fde54a  vmovaps xmm10, [rsp+0x90]
00007aa9b5fde553  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fde55c  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fde565  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fde56e  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fde577  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fde580  add rsp, 0xF0
00007aa9b5fde587  pop r11
00007aa9b5fde589  pop r10
00007aa9b5fde58b  pop r9
00007aa9b5fde58d  pop r8
00007aa9b5fde58f  pop rsi
00007aa9b5fde590  pop rdi
00007aa9b5fde591  pop rdx
00007aa9b5fde592  pop rcx
00007aa9b5fde593  pop rax
00007aa9b5fde594  add rsp, 0x08
00007aa9b5fde598  jmp 0x00007AA9B5FD980F
00007aa9b5fde59d  sub rsp, 0x08
00007aa9b5fde5a1  push rax
00007aa9b5fde5a2  push rcx
00007aa9b5fde5a3  push rdx
00007aa9b5fde5a4  push rdi
00007aa9b5fde5a5  push rsi
00007aa9b5fde5a6  push r8
00007aa9b5fde5a8  push r9
00007aa9b5fde5aa  push r10
00007aa9b5fde5ac  push r11
00007aa9b5fde5ae  sub rsp, 0xF0
00007aa9b5fde5b5  vmovaps [rsp], xmm0
00007aa9b5fde5ba  vmovaps [rsp+0x10], xmm1
00007aa9b5fde5c0  vmovaps [rsp+0x20], xmm2
00007aa9b5fde5c6  vmovaps [rsp+0x30], xmm3
00007aa9b5fde5cc  vmovaps [rsp+0x40], xmm4
00007aa9b5fde5d2  vmovaps [rsp+0x50], xmm5
00007aa9b5fde5d8  vmovaps [rsp+0x60], xmm6
00007aa9b5fde5de  vmovaps [rsp+0x70], xmm7
00007aa9b5fde5e4  vmovaps [rsp+0x80], xmm8
00007aa9b5fde5ed  vmovaps [rsp+0x90], xmm9
00007aa9b5fde5f6  vmovaps [rsp+0xA0], xmm10
00007aa9b5fde5ff  vmovaps [rsp+0xB0], xmm11
00007aa9b5fde608  vmovaps [rsp+0xC0], xmm12
00007aa9b5fde611  vmovaps [rsp+0xD0], xmm13
00007aa9b5fde61a  vmovaps [rsp+0xE0], xmm14
00007aa9b5fde623  sub rsp, 0x30
00007aa9b5fde627  movaps [rsp], xmm15
00007aa9b5fde62c  movaps [rsp+0x10], xmm11
00007aa9b5fde632  movaps [rsp+0x20], xmm12
00007aa9b5fde638  lea rdi, [rsp]
00007aa9b5fde63c  mov esi, 0x00
00007aa9b5fde641  mov rax, 0x63E0217C9530
00007aa9b5fde64b  call rax
00007aa9b5fde64d  movaps xmm15, [rsp]
00007aa9b5fde652  add rsp, 0x30
00007aa9b5fde656  vmovaps xmm0, [rsp]
00007aa9b5fde65b  vmovaps xmm1, [rsp+0x10]
00007aa9b5fde661  vmovaps xmm2, [rsp+0x20]
00007aa9b5fde667  vmovaps xmm3, [rsp+0x30]
00007aa9b5fde66d  vmovaps xmm4, [rsp+0x40]
00007aa9b5fde673  vmovaps xmm5, [rsp+0x50]
00007aa9b5fde679  vmovaps xmm6, [rsp+0x60]
00007aa9b5fde67f  vmovaps xmm7, [rsp+0x70]
00007aa9b5fde685  vmovaps xmm8, [rsp+0x80]
00007aa9b5fde68e  vmovaps xmm9, [rsp+0x90]
00007aa9b5fde697  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fde6a0  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fde6a9  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fde6b2  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fde6bb  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fde6c4  add rsp, 0xF0
00007aa9b5fde6cb  pop r11
00007aa9b5fde6cd  pop r10
00007aa9b5fde6cf  pop r9
00007aa9b5fde6d1  pop r8
00007aa9b5fde6d3  pop rsi
00007aa9b5fde6d4  pop rdi
00007aa9b5fde6d5  pop rdx
00007aa9b5fde6d6  pop rcx
00007aa9b5fde6d7  pop rax
00007aa9b5fde6d8  add rsp, 0x08
00007aa9b5fde6dc  jmp 0x00007AA9B5FD982A
00007aa9b5fde6e1  sub rsp, 0x08
00007aa9b5fde6e5  push rax
00007aa9b5fde6e6  push rcx
00007aa9b5fde6e7  push rdx
00007aa9b5fde6e8  push rdi
00007aa9b5fde6e9  push rsi
00007aa9b5fde6ea  push r8
00007aa9b5fde6ec  push r9
00007aa9b5fde6ee  push r10
00007aa9b5fde6f0  push r11
00007aa9b5fde6f2  sub rsp, 0xF0
00007aa9b5fde6f9  vmovaps [rsp], xmm0
00007aa9b5fde6fe  vmovaps [rsp+0x10], xmm1
00007aa9b5fde704  vmovaps [rsp+0x20], xmm2
00007aa9b5fde70a  vmovaps [rsp+0x30], xmm3
00007aa9b5fde710  vmovaps [rsp+0x40], xmm4
00007aa9b5fde716  vmovaps [rsp+0x50], xmm5
00007aa9b5fde71c  vmovaps [rsp+0x60], xmm6
00007aa9b5fde722  vmovaps [rsp+0x70], xmm7
00007aa9b5fde728  vmovaps [rsp+0x80], xmm8
00007aa9b5fde731  vmovaps [rsp+0x90], xmm9
00007aa9b5fde73a  vmovaps [rsp+0xA0], xmm10
00007aa9b5fde743  vmovaps [rsp+0xB0], xmm11
00007aa9b5fde74c  vmovaps [rsp+0xC0], xmm12
00007aa9b5fde755  vmovaps [rsp+0xD0], xmm14
00007aa9b5fde75e  vmovaps [rsp+0xE0], xmm15
00007aa9b5fde767  sub rsp, 0x30
00007aa9b5fde76b  movaps [rsp], xmm13
00007aa9b5fde770  movaps [rsp+0x10], xmm10
00007aa9b5fde776  movaps [rsp+0x20], xmm14
00007aa9b5fde77c  lea rdi, [rsp]
00007aa9b5fde780  mov esi, 0x00
00007aa9b5fde785  mov rax, 0x63E0217C9530
00007aa9b5fde78f  call rax
00007aa9b5fde791  movaps xmm13, [rsp]
00007aa9b5fde796  add rsp, 0x30
00007aa9b5fde79a  vmovaps xmm0, [rsp]
00007aa9b5fde79f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fde7a5  vmovaps xmm2, [rsp+0x20]
00007aa9b5fde7ab  vmovaps xmm3, [rsp+0x30]
00007aa9b5fde7b1  vmovaps xmm4, [rsp+0x40]
00007aa9b5fde7b7  vmovaps xmm5, [rsp+0x50]
00007aa9b5fde7bd  vmovaps xmm6, [rsp+0x60]
00007aa9b5fde7c3  vmovaps xmm7, [rsp+0x70]
00007aa9b5fde7c9  vmovaps xmm8, [rsp+0x80]
00007aa9b5fde7d2  vmovaps xmm9, [rsp+0x90]
00007aa9b5fde7db  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fde7e4  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fde7ed  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fde7f6  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fde7ff  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fde808  add rsp, 0xF0
00007aa9b5fde80f  pop r11
00007aa9b5fde811  pop r10
00007aa9b5fde813  pop r9
00007aa9b5fde815  pop r8
00007aa9b5fde817  pop rsi
00007aa9b5fde818  pop rdi
00007aa9b5fde819  pop rdx
00007aa9b5fde81a  pop rcx
00007aa9b5fde81b  pop rax
00007aa9b5fde81c  add rsp, 0x08
00007aa9b5fde820  jmp 0x00007AA9B5FD984D
00007aa9b5fde825  sub rsp, 0x08
00007aa9b5fde829  push rax
00007aa9b5fde82a  push rcx
00007aa9b5fde82b  push rdx
00007aa9b5fde82c  push rdi
00007aa9b5fde82d  push rsi
00007aa9b5fde82e  push r8
00007aa9b5fde830  push r9
00007aa9b5fde832  push r10
00007aa9b5fde834  push r11
00007aa9b5fde836  sub rsp, 0xF0
00007aa9b5fde83d  vmovaps [rsp], xmm0
00007aa9b5fde842  vmovaps [rsp+0x10], xmm1
00007aa9b5fde848  vmovaps [rsp+0x20], xmm2
00007aa9b5fde84e  vmovaps [rsp+0x30], xmm3
00007aa9b5fde854  vmovaps [rsp+0x40], xmm4
00007aa9b5fde85a  vmovaps [rsp+0x50], xmm5
00007aa9b5fde860  vmovaps [rsp+0x60], xmm6
00007aa9b5fde866  vmovaps [rsp+0x70], xmm7
00007aa9b5fde86c  vmovaps [rsp+0x80], xmm8
00007aa9b5fde875  vmovaps [rsp+0x90], xmm9
00007aa9b5fde87e  vmovaps [rsp+0xA0], xmm10
00007aa9b5fde887  vmovaps [rsp+0xB0], xmm11
00007aa9b5fde890  vmovaps [rsp+0xC0], xmm12
00007aa9b5fde899  vmovaps [rsp+0xD0], xmm13
00007aa9b5fde8a2  vmovaps [rsp+0xE0], xmm15
00007aa9b5fde8ab  sub rsp, 0x30
00007aa9b5fde8af  movaps [rsp], xmm14
00007aa9b5fde8b4  movaps [rsp+0x10], xmm1
00007aa9b5fde8b9  movaps [rsp+0x20], xmm7
00007aa9b5fde8be  lea rdi, [rsp]
00007aa9b5fde8c2  mov esi, 0x00
00007aa9b5fde8c7  mov rax, 0x63E0217C9530
00007aa9b5fde8d1  call rax
00007aa9b5fde8d3  movaps xmm14, [rsp]
00007aa9b5fde8d8  add rsp, 0x30
00007aa9b5fde8dc  vmovaps xmm0, [rsp]
00007aa9b5fde8e1  vmovaps xmm1, [rsp+0x10]
00007aa9b5fde8e7  vmovaps xmm2, [rsp+0x20]
00007aa9b5fde8ed  vmovaps xmm3, [rsp+0x30]
00007aa9b5fde8f3  vmovaps xmm4, [rsp+0x40]
00007aa9b5fde8f9  vmovaps xmm5, [rsp+0x50]
00007aa9b5fde8ff  vmovaps xmm6, [rsp+0x60]
00007aa9b5fde905  vmovaps xmm7, [rsp+0x70]
00007aa9b5fde90b  vmovaps xmm8, [rsp+0x80]
00007aa9b5fde914  vmovaps xmm9, [rsp+0x90]
00007aa9b5fde91d  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fde926  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fde92f  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fde938  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fde941  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fde94a  add rsp, 0xF0
00007aa9b5fde951  pop r11
00007aa9b5fde953  pop r10
00007aa9b5fde955  pop r9
00007aa9b5fde957  pop r8
00007aa9b5fde959  pop rsi
00007aa9b5fde95a  pop rdi
00007aa9b5fde95b  pop rdx
00007aa9b5fde95c  pop rcx
00007aa9b5fde95d  pop rax
00007aa9b5fde95e  add rsp, 0x08
00007aa9b5fde962  jmp 0x00007AA9B5FD9870
00007aa9b5fde967  sub rsp, 0x08
00007aa9b5fde96b  push rax
00007aa9b5fde96c  push rcx
00007aa9b5fde96d  push rdx
00007aa9b5fde96e  push rdi
00007aa9b5fde96f  push rsi
00007aa9b5fde970  push r8
00007aa9b5fde972  push r9
00007aa9b5fde974  push r10
00007aa9b5fde976  push r11
00007aa9b5fde978  sub rsp, 0xF0
00007aa9b5fde97f  vmovaps [rsp], xmm0
00007aa9b5fde984  vmovaps [rsp+0x10], xmm2
00007aa9b5fde98a  vmovaps [rsp+0x20], xmm3
00007aa9b5fde990  vmovaps [rsp+0x30], xmm4
00007aa9b5fde996  vmovaps [rsp+0x40], xmm5
00007aa9b5fde99c  vmovaps [rsp+0x50], xmm6
00007aa9b5fde9a2  vmovaps [rsp+0x60], xmm7
00007aa9b5fde9a8  vmovaps [rsp+0x70], xmm8
00007aa9b5fde9ae  vmovaps [rsp+0x80], xmm9
00007aa9b5fde9b7  vmovaps [rsp+0x90], xmm10
00007aa9b5fde9c0  vmovaps [rsp+0xA0], xmm11
00007aa9b5fde9c9  vmovaps [rsp+0xB0], xmm12
00007aa9b5fde9d2  vmovaps [rsp+0xC0], xmm13
00007aa9b5fde9db  vmovaps [rsp+0xD0], xmm14
00007aa9b5fde9e4  vmovaps [rsp+0xE0], xmm15
00007aa9b5fde9ed  sub rsp, 0x30
00007aa9b5fde9f1  movaps [rsp], xmm1
00007aa9b5fde9f5  movaps [rsp+0x10], xmm8
00007aa9b5fde9fb  movaps [rsp+0x20], xmm9
00007aa9b5fdea01  lea rdi, [rsp]
00007aa9b5fdea05  mov esi, 0x00
00007aa9b5fdea0a  mov rax, 0x63E0217C9530
00007aa9b5fdea14  call rax
00007aa9b5fdea16  movaps xmm1, [rsp]
00007aa9b5fdea1a  add rsp, 0x30
00007aa9b5fdea1e  vmovaps xmm0, [rsp]
00007aa9b5fdea23  vmovaps xmm2, [rsp+0x10]
00007aa9b5fdea29  vmovaps xmm3, [rsp+0x20]
00007aa9b5fdea2f  vmovaps xmm4, [rsp+0x30]
00007aa9b5fdea35  vmovaps xmm5, [rsp+0x40]
00007aa9b5fdea3b  vmovaps xmm6, [rsp+0x50]
00007aa9b5fdea41  vmovaps xmm7, [rsp+0x60]
00007aa9b5fdea47  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdea4d  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdea56  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdea5f  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdea68  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdea71  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdea7a  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdea83  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdea8c  add rsp, 0xF0
00007aa9b5fdea93  pop r11
00007aa9b5fdea95  pop r10
00007aa9b5fdea97  pop r9
00007aa9b5fdea99  pop r8
00007aa9b5fdea9b  pop rsi
00007aa9b5fdea9c  pop rdi
00007aa9b5fdea9d  pop rdx
00007aa9b5fdea9e  pop rcx
00007aa9b5fdea9f  pop rax
00007aa9b5fdeaa0  add rsp, 0x08
00007aa9b5fdeaa4  jmp 0x00007AA9B5FD9892
00007aa9b5fdeaa9  call 0x00007AA9B5EB3E40
00007aa9b5fdeaae  jmp 0x00007AA9B5FD98A0
00007aa9b5fdeab3  call 0x00007AA9B5E0C380
00007aa9b5fdeab8  jmp 0x00007AA9B5FD98AA
00007aa9b5fdeabd  call 0x00007AA9B5E0D600
00007aa9b5fdeac2  jmp 0x00007AA9B5FD98B4
00007aa9b5fdeac7  call 0x00007AA9B5DFF540
00007aa9b5fdeacc  jmp 0x00007AA9B5FD98BE
00007aa9b5fdead1  int3
00007aa9b5fdead2  nop [rax+rax*1], ax
00007aa9b5fdeadb  nop [rax+rax*1], eax
00007aa9b5fdeae0  mov eax, [r15+0x48]
00007aa9b5fdeae4  lea r14d, [eax+0x01]
00007aa9b5fdeae9  mov [rsp+0x10], r14d
00007aa9b5fdeaee  mov r14d, r14d
00007aa9b5fdeaf1  mov [r15+0x48], r14
00007aa9b5fdeaf5  xor eax, eax
00007aa9b5fdeaf7  mov r14d, [rsp+0x10]
00007aa9b5fdeafc  cmp r14d, 0x1F4
00007aa9b5fdeb03  cmc
00007aa9b5fdeb04  lahf
00007aa9b5fdeb05  seto al
00007aa9b5fdeb08  mov [r15+0x108], eax
00007aa9b5fdeb0f  mov eax, [r15+0x108]
00007aa9b5fdeb16  sahf
00007aa9b5fdeb17  jnz 0x00007AA9B5FDEB49
00007aa9b5fdeb19  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fdeb21  jz 0x00007AA9B5FE4C90
00007aa9b5fdeb27  nop [rax+rax*1], ax
00007aa9b5fdeb30  nop [rax+rax*1], eax
00007aa9b5fdeb38  mov eax, 0x4106DC
00007aa9b5fdeb3d  mov [r15+0x100], rax
00007aa9b5fdeb44  jmp 0x00007AA9B5DFE110
00007aa9b5fdeb49  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fdeb51  jz 0x00007AA9B5FDEB80
00007aa9b5fdeb57  nop [rax+rax*1], ax
00007aa9b5fdeb60  nop [rax+rax*1], eax
00007aa9b5fdeb68  mov eax, 0x410500
00007aa9b5fdeb6d  mov [r15+0x100], rax
00007aa9b5fdeb74  jmp 0x00007AA9B5DFE110
00007aa9b5fdeb79  int3
00007aa9b5fdeb7a  int3
00007aa9b5fdeb7b  nop [rax+rax*1], eax
00007aa9b5fdeb80  mov rax, [r15+0x40]
00007aa9b5fdeb84  movaps xmm1, [r15+0x1D0]
00007aa9b5fdeb8c  vmovaps [rsp+0x10], xmm1
00007aa9b5fdeb92  vmovaps xmm15, [rsp+0x10]
00007aa9b5fdeb98  por xmm1, xmm15
00007aa9b5fdeb9d  movaps xmm14, [r15+0x1A0]
00007aa9b5fdeba5  vmovaps [rsp+0x10], xmm14
00007aa9b5fdebab  vmovaps xmm13, [rsp+0x10]
00007aa9b5fdebb1  por xmm14, xmm13
00007aa9b5fdebb6  lea r14, [rax+0x30]
00007aa9b5fdebba  mov r12, [r13+r14*1]
00007aa9b5fdebbf  lea r14, [rax+0x38]
00007aa9b5fdebc3  mov r11, [r13+r14*1]
00007aa9b5fdebc8  movq xmm13, r12
00007aa9b5fdebcd  movq xmm12, r11
00007aa9b5fdebd2  movq xmm13, xmm13
00007aa9b5fdebd7  vmovaps [rsp+0x10], xmm13
00007aa9b5fdebdd  movq xmm13, xmm13
00007aa9b5fdebe2  movaps [r15+0x130], xmm13
00007aa9b5fdebea  movq xmm12, xmm12
00007aa9b5fdebef  vmovaps [rsp+0x20], xmm12
00007aa9b5fdebf5  movq xmm12, xmm12
00007aa9b5fdebfa  movaps [r15+0x280], xmm12
00007aa9b5fdec02  movaps xmm13, [r15+0x270]
00007aa9b5fdec0a  vmovaps [rsp+0x30], xmm13
00007aa9b5fdec10  vmovaps xmm12, [rsp+0x30]
00007aa9b5fdec16  por xmm13, xmm12
00007aa9b5fdec1b  lea r14, [rax+0x20]
00007aa9b5fdec1f  mov r12, [r13+r14*1]
00007aa9b5fdec24  lea r14, [rax+0x28]
00007aa9b5fdec28  mov r11, [r13+r14*1]
00007aa9b5fdec2d  movq xmm12, r12
00007aa9b5fdec32  movq xmm11, r11
00007aa9b5fdec37  movq xmm12, xmm12
00007aa9b5fdec3c  vmovaps [rsp+0x30], xmm12
00007aa9b5fdec42  movq xmm12, xmm12
00007aa9b5fdec47  movaps [r15+0x150], xmm12
00007aa9b5fdec4f  movq xmm11, xmm11
00007aa9b5fdec54  vmovaps [rsp+0x40], xmm11
00007aa9b5fdec5a  movq xmm11, xmm11
00007aa9b5fdec5f  movaps [r15+0x140], xmm11
00007aa9b5fdec67  lea r14, [rax+0x10]
00007aa9b5fdec6b  mov r12, [r13+r14*1]
00007aa9b5fdec70  lea r14, [rax+0x18]
00007aa9b5fdec74  mov r11, [r13+r14*1]
00007aa9b5fdec79  movq xmm12, r12
00007aa9b5fdec7e  movq xmm11, r11
00007aa9b5fdec83  movq xmm12, xmm12
00007aa9b5fdec88  vmovaps [rsp+0x50], xmm12
00007aa9b5fdec8e  movq xmm12, xmm12
00007aa9b5fdec93  movaps [r15+0x170], xmm12
00007aa9b5fdec9b  movq xmm11, xmm11
00007aa9b5fdeca0  vmovaps [rsp+0x60], xmm11
00007aa9b5fdeca6  movq xmm11, xmm11
00007aa9b5fdecab  movaps [r15+0x160], xmm11
00007aa9b5fdecb3  mov r14, [r13+rax*1]
00007aa9b5fdecb8  vmovq xmm12, r14
00007aa9b5fdecbd  vpbroadcastq xmm12, xmm12
00007aa9b5fdecc2  lea r14, [rax+0x08]
00007aa9b5fdecc6  mov rax, [r13+r14*1]
00007aa9b5fdeccb  movq xmm11, rax
00007aa9b5fdecd0  movaps [r15+0x230], xmm11
00007aa9b5fdecd8  mov rax, [r15+0xF8]
00007aa9b5fdecdf  lea r14, [rax+0x50]
00007aa9b5fdece3  movups xmm11, [r13+r14*1]
00007aa9b5fdece9  lea r14, [rax+0x60]
00007aa9b5fdeced  movups xmm10, [r13+r14*1]
00007aa9b5fdecf3  lea r14, [rax+0x30]
00007aa9b5fdecf7  movups xmm9, [r13+r14*1]
00007aa9b5fdecfd  mov r14, [r15+0x50]
00007aa9b5fded01  mov [r15+0x60], r14
00007aa9b5fded05  mov qword ptr [r15+0x58], 0x40
00007aa9b5fded0d  movaps xmm8, xmm12
00007aa9b5fded11  mulpd xmm8, xmm15
00007aa9b5fded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa9b5fded1c  ptest xmm7, xmm7
00007aa9b5fded21  jnz 0x00007AA9B5FDFB4A
00007aa9b5fded27  movq xmm15, qword ptr [r15+0x230]
00007aa9b5fded30  vmovaps [rsp+0x70], xmm15
00007aa9b5fded36  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fded3c  movaps xmm7, xmm9
00007aa9b5fded40  mulpd xmm7, xmm15
00007aa9b5fded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa9b5fded4a  ptest xmm6, xmm6
00007aa9b5fded4f  jnz 0x00007AA9B5FDFC8E
00007aa9b5fded55  vxorps xmm15, xmm15, xmm15
00007aa9b5fded5a  vpbroadcastq xmm15, xmm15
00007aa9b5fded5f  movaps xmm9, xmm12
00007aa9b5fded63  mulpd xmm9, xmm10
00007aa9b5fded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa9b5fded6e  ptest xmm6, xmm6
00007aa9b5fded73  jnz 0x00007AA9B5FDFDD0
00007aa9b5fded79  movaps xmm10, xmm12
00007aa9b5fded7d  mulpd xmm10, xmm11
00007aa9b5fded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007aa9b5fded88  ptest xmm6, xmm6
00007aa9b5fded8d  jnz 0x00007AA9B5FDFF14
00007aa9b5fded93  movaps xmm11, [r15+0x1F0]
00007aa9b5fded9b  movaps xmm6, xmm12
00007aa9b5fded9f  mulpd xmm6, xmm11
00007aa9b5fdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa9b5fdeda9  ptest xmm5, xmm5
00007aa9b5fdedae  jnz 0x00007AA9B5FE0058
00007aa9b5fdedb4  movaps xmm12, [r15+0x2A0]
00007aa9b5fdedbc  vmovaps [rsp+0x80], xmm12
00007aa9b5fdedc5  vmovaps xmm11, [rsp+0x80]
00007aa9b5fdedce  por xmm12, xmm11
00007aa9b5fdedd3  movaps xmm11, [r15+0x250]
00007aa9b5fdeddb  vmovaps [rsp+0x80], xmm11
00007aa9b5fdede4  vmovaps xmm5, [rsp+0x80]
00007aa9b5fdeded  por xmm11, xmm5
00007aa9b5fdedf2  vmovaps xmm4, [rsp+0x70]
00007aa9b5fdedf8  vpermilpd xmm4, xmm4, 0x00
00007aa9b5fdedfe  movaps xmm3, xmm5
00007aa9b5fdee01  mulpd xmm3, xmm4
00007aa9b5fdee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007aa9b5fdee0a  ptest xmm2, xmm2
00007aa9b5fdee0f  jnz 0x00007AA9B5FE019A
00007aa9b5fdee15  mov [rsp+0x80], rax
00007aa9b5fdee1d  xor eax, eax
00007aa9b5fdee1f  mov r12d, 0x40
00007aa9b5fdee25  mov r11d, 0x200
00007aa9b5fdee2b  cmp r12, r11
00007aa9b5fdee2e  cmc
00007aa9b5fdee2f  lahf
00007aa9b5fdee30  seto al
00007aa9b5fdee33  mov [r15+0x108], eax
00007aa9b5fdee3a  movaps xmm5, xmm8
00007aa9b5fdee3e  addpd xmm5, xmm15
00007aa9b5fdee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007aa9b5fdee48  ptest xmm4, xmm4
00007aa9b5fdee4d  jnz 0x00007AA9B5FE02DA
00007aa9b5fdee53  movaps xmm8, [r15+0x1B0]
00007aa9b5fdee5b  movaps xmm4, xmm9
00007aa9b5fdee5f  addpd xmm4, xmm8
00007aa9b5fdee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007aa9b5fdee69  ptest xmm2, xmm2
00007aa9b5fdee6e  jnz 0x00007AA9B5FE041C
00007aa9b5fdee74  movaps xmm9, xmm10
00007aa9b5fdee78  addpd xmm9, xmm8
00007aa9b5fdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007aa9b5fdee83  ptest xmm2, xmm2
00007aa9b5fdee88  jnz 0x00007AA9B5FE055E
00007aa9b5fdee8e  movaps xmm10, [r15+0x2F0]
00007aa9b5fdee96  vmovaps [rsp+0x90], xmm10
00007aa9b5fdee9f  vmovaps xmm8, [rsp+0x90]
00007aa9b5fdeea8  por xmm10, xmm8
00007aa9b5fdeead  movaps xmm8, [r15+0x2E0]
00007aa9b5fdeeb5  vmovaps [rsp+0x90], xmm8
00007aa9b5fdeebe  vmovaps xmm2, [rsp+0x90]
00007aa9b5fdeec7  por xmm8, xmm2
00007aa9b5fdeecc  movaps xmm2, [r15+0x2D0]
00007aa9b5fdeed4  vmovaps [rsp+0x90], xmm2
00007aa9b5fdeedd  vmovaps [rsp+0xA0], xmm1
00007aa9b5fdeee6  vmovaps xmm1, [rsp+0x90]
00007aa9b5fdeeef  por xmm2, xmm1
00007aa9b5fdeef3  movaps xmm1, [r15+0x200]
00007aa9b5fdeefb  vmovaps [rsp+0x90], xmm1
00007aa9b5fdef04  vmovaps [rsp+0xB0], xmm15
00007aa9b5fdef0d  vmovaps xmm15, [rsp+0x90]
00007aa9b5fdef16  por xmm1, xmm15
00007aa9b5fdef1b  movaps xmm15, [r15+0x1C0]
00007aa9b5fdef23  vmovaps [rsp+0x90], xmm15
00007aa9b5fdef2c  vmovaps [rsp+0xC0], xmm1
00007aa9b5fdef35  vmovaps xmm1, [rsp+0x90]
00007aa9b5fdef3e  por xmm15, xmm1
00007aa9b5fdef43  movaps xmm1, [r15+0x190]
00007aa9b5fdef4b  vmovaps [rsp+0x90], xmm1
00007aa9b5fdef54  vmovaps [rsp+0xD0], xmm15
00007aa9b5fdef5d  vmovaps xmm15, [rsp+0x90]
00007aa9b5fdef66  por xmm1, xmm15
00007aa9b5fdef6b  movaps xmm15, [r15+0x300]
00007aa9b5fdef73  vmovaps [rsp+0x90], xmm15
00007aa9b5fdef7c  vmovaps [rsp+0xE0], xmm1
00007aa9b5fdef85  vmovaps xmm1, [rsp+0x90]
00007aa9b5fdef8e  por xmm15, xmm1
00007aa9b5fdef93  mov rax, [rsp+0x80]
00007aa9b5fdef9b  lea r12, [rax+0xA0]
00007aa9b5fdefa2  movups xmm1, [r13+r12*1]
00007aa9b5fdefa8  lea r12, [rax+0xB0]
00007aa9b5fdefaf  vmovaps [rsp+0x80], xmm1
00007aa9b5fdefb8  movups xmm1, [r13+r12*1]
00007aa9b5fdefbe  vmovaps [rsp+0x90], xmm1
00007aa9b5fdefc7  vmovaps [rsp+0xF0], xmm15
00007aa9b5fdefd0  vmovaps xmm15, [rsp+0xB0]
00007aa9b5fdefd9  vmovaps [rsp+0xB0], xmm14
00007aa9b5fdefe2  movaps xmm1, xmm6
00007aa9b5fdefe5  addpd xmm1, xmm15
00007aa9b5fdefea  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa9b5fdefef  ptest xmm14, xmm14
00007aa9b5fdeff5  jnz 0x00007AA9B5FE06B6
00007aa9b5fdeffb  lea r12, [rax+0xF0]
00007aa9b5fdf002  movups xmm15, [r13+r12*1]
00007aa9b5fdf008  movaps xmm14, xmm4
00007aa9b5fdf00c  addpd xmm14, xmm3
00007aa9b5fdf011  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa9b5fdf017  ptest xmm6, xmm6
00007aa9b5fdf01c  jnz 0x00007AA9B5FE0801
00007aa9b5fdf022  movaps xmm6, xmm9
00007aa9b5fdf026  addpd xmm6, xmm7
00007aa9b5fdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007aa9b5fdf02f  ptest xmm4, xmm4
00007aa9b5fdf034  jnz 0x00007AA9B5FE0943
00007aa9b5fdf03a  vmovaps xmm9, [rsp+0x70]
00007aa9b5fdf040  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fdf046  vmovaps xmm4, [rsp+0x90]
00007aa9b5fdf04f  movaps xmm7, xmm4
00007aa9b5fdf052  mulpd xmm7, xmm9
00007aa9b5fdf057  vcmppd xmm3, xmm7, xmm7, 0x03
00007aa9b5fdf05c  ptest xmm3, xmm3
00007aa9b5fdf061  jnz 0x00007AA9B5FE0A84
00007aa9b5fdf067  vmovaps xmm9, [rsp+0x50]
00007aa9b5fdf06d  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fdf073  movaps xmm4, xmm15
00007aa9b5fdf077  mulpd xmm4, xmm9
00007aa9b5fdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007aa9b5fdf081  ptest xmm3, xmm3
00007aa9b5fdf086  jnz 0x00007AA9B5FE0BC5
00007aa9b5fdf08c  lea r12, [rax+0xE0]
00007aa9b5fdf093  movups xmm15, [r13+r12*1]
00007aa9b5fdf099  vmovaps xmm9, [rsp+0x70]
00007aa9b5fdf09f  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fdf0a5  vmovaps [rsp+0x70], xmm1
00007aa9b5fdf0ab  vmovaps xmm1, [rsp+0x80]
00007aa9b5fdf0b4  vmovaps [rsp+0x80], xmm15
00007aa9b5fdf0bd  movaps xmm3, xmm1
00007aa9b5fdf0c0  mulpd xmm3, xmm9
00007aa9b5fdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007aa9b5fdf0ca  ptest xmm15, xmm15
00007aa9b5fdf0d0  jnz 0x00007AA9B5FE0D11
00007aa9b5fdf0d6  vmovaps xmm1, [rsp+0xF0]
00007aa9b5fdf0df  vmovaps xmm15, [rsp+0xF0]
00007aa9b5fdf0e8  por xmm1, xmm15
00007aa9b5fdf0ed  movaps [r15+0x300], xmm1
00007aa9b5fdf0f5  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdf0fe  vmovaps xmm9, [rsp+0xE0]
00007aa9b5fdf107  por xmm15, xmm9
00007aa9b5fdf10c  movaps [r15+0x190], xmm15
00007aa9b5fdf114  vmovaps xmm9, [rsp+0x50]
00007aa9b5fdf11a  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fdf120  vmovaps [rsp+0x90], xmm1
00007aa9b5fdf129  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdf132  vmovaps xmm15, [rsp+0x80]
00007aa9b5fdf13b  vmovaps [rsp+0x80], xmm14
00007aa9b5fdf144  movaps xmm1, xmm15
00007aa9b5fdf148  mulpd xmm1, xmm9
00007aa9b5fdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa9b5fdf152  ptest xmm14, xmm14
00007aa9b5fdf158  jnz 0x00007AA9B5FE0E52
00007aa9b5fdf15e  lea r12, [rax+0x90]
00007aa9b5fdf165  movups xmm15, [r13+r12*1]
00007aa9b5fdf16b  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdf174  vmovaps xmm9, [rsp+0xD0]
00007aa9b5fdf17d  por xmm14, xmm9
00007aa9b5fdf182  movaps [r15+0x1C0], xmm14
00007aa9b5fdf18a  vmovaps xmm9, [rsp+0xC0]
00007aa9b5fdf193  vmovaps [rsp+0xD0], xmm1
00007aa9b5fdf19c  vmovaps xmm1, [rsp+0xC0]
00007aa9b5fdf1a5  por xmm9, xmm1
00007aa9b5fdf1aa  movaps [r15+0x200], xmm9
00007aa9b5fdf1b2  vmovaps [rsp+0xC0], xmm2
00007aa9b5fdf1bb  vmovaps xmm1, [rsp+0xC0]
00007aa9b5fdf1c4  por xmm2, xmm1
00007aa9b5fdf1c8  movaps [r15+0x2D0], xmm2
00007aa9b5fdf1d0  vmovaps [rsp+0xC0], xmm8
00007aa9b5fdf1d9  vmovaps xmm1, [rsp+0xC0]
00007aa9b5fdf1e2  por xmm8, xmm1
00007aa9b5fdf1e7  movaps [r15+0x2E0], xmm8
00007aa9b5fdf1ef  vmovaps [rsp+0xC0], xmm15
00007aa9b5fdf1f8  movaps xmm1, xmm5
00007aa9b5fdf1fb  addpd xmm1, xmm7
00007aa9b5fdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa9b5fdf204  ptest xmm15, xmm15
00007aa9b5fdf20a  jnz 0x00007AA9B5FE0F9E
00007aa9b5fdf210  vmovaps xmm15, [rsp+0x50]
00007aa9b5fdf216  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fdf21c  vmovaps xmm5, [rsp+0xC0]
00007aa9b5fdf225  vmovaps [rsp+0xC0], xmm1
00007aa9b5fdf22e  movaps xmm7, xmm5
00007aa9b5fdf231  mulpd xmm7, xmm15
00007aa9b5fdf236  vcmppd xmm1, xmm7, xmm7, 0x03
00007aa9b5fdf23b  ptest xmm1, xmm1
00007aa9b5fdf240  jnz 0x00007AA9B5FE10DE
00007aa9b5fdf246  lea r12, [rax+0x80]
00007aa9b5fdf24d  movups xmm1, [r13+r12*1]
00007aa9b5fdf253  vmovaps xmm5, [rsp+0x70]
00007aa9b5fdf259  vmovaps [rsp+0x70], xmm1
00007aa9b5fdf25f  movaps xmm15, xmm5
00007aa9b5fdf263  addpd xmm15, xmm3
00007aa9b5fdf268  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa9b5fdf26e  ptest xmm1, xmm1
00007aa9b5fdf273  jnz 0x00007AA9B5FE1229
00007aa9b5fdf279  vmovaps xmm5, [rsp+0x80]
00007aa9b5fdf282  movaps xmm1, xmm5
00007aa9b5fdf285  addpd xmm1, xmm4
00007aa9b5fdf289  vcmppd xmm3, xmm1, xmm1, 0x03
00007aa9b5fdf28e  ptest xmm3, xmm3
00007aa9b5fdf293  jnz 0x00007AA9B5FE136B
00007aa9b5fdf299  vmovaps [rsp+0x80], xmm10
00007aa9b5fdf2a2  vmovaps xmm5, [rsp+0x80]
00007aa9b5fdf2ab  por xmm10, xmm5
00007aa9b5fdf2b0  movaps [r15+0x2F0], xmm10
00007aa9b5fdf2b8  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdf2be  vpermilpd xmm5, xmm5, 0x00
00007aa9b5fdf2c4  vmovaps xmm3, [rsp+0x70]
00007aa9b5fdf2ca  vmovaps [rsp+0x50], xmm1
00007aa9b5fdf2d0  movaps xmm4, xmm3
00007aa9b5fdf2d3  mulpd xmm4, xmm5
00007aa9b5fdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007aa9b5fdf2dc  ptest xmm1, xmm1
00007aa9b5fdf2e1  jnz 0x00007AA9B5FE14AB
00007aa9b5fdf2e7  lea r12, [rax+0xD0]
00007aa9b5fdf2ee  movups xmm1, [r13+r12*1]
00007aa9b5fdf2f4  vmovaps xmm3, [rsp+0xD0]
00007aa9b5fdf2fd  vmovaps [rsp+0x70], xmm1
00007aa9b5fdf303  movaps xmm5, xmm6
00007aa9b5fdf306  addpd xmm5, xmm3
00007aa9b5fdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007aa9b5fdf30f  ptest xmm1, xmm1
00007aa9b5fdf314  jnz 0x00007AA9B5FE15F5
00007aa9b5fdf31a  vmovaps xmm1, [rsp+0x60]
00007aa9b5fdf320  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fdf326  movaps xmm6, xmm9
00007aa9b5fdf32a  mulpd xmm6, xmm1
00007aa9b5fdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007aa9b5fdf333  ptest xmm3, xmm3
00007aa9b5fdf338  jnz 0x00007AA9B5FE1735
00007aa9b5fdf33e  movaps [r15+0x260], xmm6
00007aa9b5fdf346  vxorps xmm1, xmm1, xmm1
00007aa9b5fdf34a  vpbroadcastq xmm1, xmm1
00007aa9b5fdf34f  movaps [r15+0x1B0], xmm1
00007aa9b5fdf357  vmovaps xmm1, [rsp+0x60]
00007aa9b5fdf35d  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fdf363  vmovaps xmm3, [rsp+0x70]
00007aa9b5fdf369  vmovaps [rsp+0x70], xmm15
00007aa9b5fdf36f  movaps xmm9, xmm3
00007aa9b5fdf373  mulpd xmm9, xmm1
00007aa9b5fdf378  vcmppd xmm15, xmm9, xmm9, 0x03
00007aa9b5fdf37e  ptest xmm15, xmm15
00007aa9b5fdf384  jnz 0x00007AA9B5FE1876
00007aa9b5fdf38a  lea r12, [rax+0xC0]
00007aa9b5fdf391  movups xmm1, [r13+r12*1]
00007aa9b5fdf397  vmovaps xmm3, [rsp+0xC0]
00007aa9b5fdf3a0  vmovaps [rsp+0x80], xmm1
00007aa9b5fdf3a9  movaps xmm15, xmm3
00007aa9b5fdf3ad  addpd xmm15, xmm7
00007aa9b5fdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa9b5fdf3b8  ptest xmm1, xmm1
00007aa9b5fdf3bd  jnz 0x00007AA9B5FE19C2
00007aa9b5fdf3c3  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdf3cc  vmovaps xmm1, [rsp+0xC0]
00007aa9b5fdf3d5  por xmm13, xmm1
00007aa9b5fdf3da  movaps [r15+0x270], xmm13
00007aa9b5fdf3e2  vmovaps xmm1, [rsp+0xB0]
00007aa9b5fdf3eb  vmovaps xmm7, [rsp+0xB0]
00007aa9b5fdf3f4  por xmm1, xmm7
00007aa9b5fdf3f8  movaps [r15+0x1A0], xmm1
00007aa9b5fdf400  vmovaps xmm1, [rsp+0x60]
00007aa9b5fdf406  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fdf40c  vmovaps [rsp+0xB0], xmm1
00007aa9b5fdf415  vmovaps xmm1, [rsp+0x80]
00007aa9b5fdf41e  vmovaps [rsp+0x80], xmm15
00007aa9b5fdf427  vmovaps xmm15, [rsp+0xB0]
00007aa9b5fdf430  vmovaps [rsp+0xB0], xmm14
00007aa9b5fdf439  movaps xmm3, xmm1
00007aa9b5fdf43c  mulpd xmm3, xmm15
00007aa9b5fdf441  vcmppd xmm14, xmm3, xmm3, 0x03
00007aa9b5fdf446  ptest xmm14, xmm14
00007aa9b5fdf44c  jnz 0x00007AA9B5FE1B04
00007aa9b5fdf452  lea r12, [rax+0x20]
00007aa9b5fdf456  movups xmm1, [r13+r12*1]
00007aa9b5fdf45c  movaps [r15+0x110], xmm1
00007aa9b5fdf464  vmovaps xmm14, [rsp+0x70]
00007aa9b5fdf46a  vmovaps [rsp+0x70], xmm1
00007aa9b5fdf470  movaps xmm15, xmm14
00007aa9b5fdf474  addpd xmm15, xmm4
00007aa9b5fdf479  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa9b5fdf47f  ptest xmm1, xmm1
00007aa9b5fdf484  jnz 0x00007AA9B5FE1C4F
00007aa9b5fdf48a  vmovaps xmm1, [rsp+0x60]
00007aa9b5fdf490  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fdf496  movaps xmm14, xmm2
00007aa9b5fdf49a  mulpd xmm14, xmm1
00007aa9b5fdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007aa9b5fdf4a5  ptest xmm4, xmm4
00007aa9b5fdf4aa  jnz 0x00007AA9B5FE1D92
00007aa9b5fdf4b0  vmovaps xmm4, [rsp+0x50]
00007aa9b5fdf4b6  movaps xmm1, xmm4
00007aa9b5fdf4b9  addpd xmm1, xmm9
00007aa9b5fdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa9b5fdf4c3  ptest xmm2, xmm2
00007aa9b5fdf4c8  jnz 0x00007AA9B5FE1ED4
00007aa9b5fdf4ce  vmovaps xmm9, [rsp+0x30]
00007aa9b5fdf4d4  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fdf4da  vmovaps xmm2, [rsp+0x70]
00007aa9b5fdf4e0  vmovaps [rsp+0x50], xmm1
00007aa9b5fdf4e6  movaps xmm4, xmm2
00007aa9b5fdf4e9  mulpd xmm4, xmm9
00007aa9b5fdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007aa9b5fdf4f3  ptest xmm1, xmm1
00007aa9b5fdf4f8  jnz 0x00007AA9B5FE2015
00007aa9b5fdf4fe  vmovaps xmm1, [rsp+0x30]
00007aa9b5fdf504  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fdf50a  vmovaps xmm2, [rsp+0x90]
00007aa9b5fdf513  vmovaps [rsp+0x60], xmm15
00007aa9b5fdf519  movaps xmm9, xmm2
00007aa9b5fdf51d  mulpd xmm9, xmm1
00007aa9b5fdf522  vcmppd xmm15, xmm9, xmm9, 0x03
00007aa9b5fdf528  ptest xmm15, xmm15
00007aa9b5fdf52e  jnz 0x00007AA9B5FE2156
00007aa9b5fdf534  vmovaps xmm15, [rsp+0x80]
00007aa9b5fdf53d  movaps xmm1, xmm15
00007aa9b5fdf541  addpd xmm1, xmm6
00007aa9b5fdf545  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa9b5fdf54a  ptest xmm2, xmm2
00007aa9b5fdf54f  jnz 0x00007AA9B5FE2298
00007aa9b5fdf555  movaps xmm15, xmm5
00007aa9b5fdf559  addpd xmm15, xmm3
00007aa9b5fdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007aa9b5fdf564  ptest xmm6, xmm6
00007aa9b5fdf569  jnz 0x00007AA9B5FE23D9
00007aa9b5fdf56f  vmovaps xmm6, [rsp+0x30]
00007aa9b5fdf575  vpermilpd xmm6, xmm6, 0x00
00007aa9b5fdf57b  movaps xmm5, xmm8
00007aa9b5fdf57f  mulpd xmm5, xmm6
00007aa9b5fdf583  vcmppd xmm3, xmm5, xmm5, 0x03
00007aa9b5fdf588  ptest xmm3, xmm3
00007aa9b5fdf58d  jnz 0x00007AA9B5FE251B
00007aa9b5fdf593  vmovaps xmm8, [rsp+0x30]
00007aa9b5fdf599  vpermilpd xmm8, xmm8, 0x00
00007aa9b5fdf59f  movaps xmm6, xmm10
00007aa9b5fdf5a3  mulpd xmm6, xmm8
00007aa9b5fdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007aa9b5fdf5ad  ptest xmm3, xmm3
00007aa9b5fdf5b2  jnz 0x00007AA9B5FE265C
00007aa9b5fdf5b8  vmovaps xmm8, [rsp+0x60]
00007aa9b5fdf5be  movaps xmm10, xmm8
00007aa9b5fdf5c2  addpd xmm10, xmm14
00007aa9b5fdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007aa9b5fdf5cd  ptest xmm3, xmm3
00007aa9b5fdf5d2  jnz 0x00007AA9B5FE279E
00007aa9b5fdf5d8  vmovaps xmm8, [rsp+0x50]
00007aa9b5fdf5de  movaps xmm14, xmm8
00007aa9b5fdf5e2  addpd xmm14, xmm4
00007aa9b5fdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007aa9b5fdf5ed  ptest xmm3, xmm3
00007aa9b5fdf5f2  jnz 0x00007AA9B5FE28E2
00007aa9b5fdf5f8  vmovaps xmm8, [rsp+0x40]
00007aa9b5fdf5fe  vpermilpd xmm8, xmm8, 0x00
00007aa9b5fdf604  movaps xmm4, xmm13
00007aa9b5fdf608  mulpd xmm4, xmm8
00007aa9b5fdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007aa9b5fdf612  ptest xmm3, xmm3
00007aa9b5fdf617  jnz 0x00007AA9B5FE2A25
00007aa9b5fdf61d  movaps xmm13, xmm15
00007aa9b5fdf621  addpd xmm13, xmm9
00007aa9b5fdf626  vcmppd xmm8, xmm13, xmm13, 0x03
00007aa9b5fdf62c  ptest xmm8, xmm8
00007aa9b5fdf632  jnz 0x00007AA9B5FE2B67
00007aa9b5fdf638  movaps xmm15, xmm1
00007aa9b5fdf63c  addpd xmm15, xmm5
00007aa9b5fdf641  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa9b5fdf647  ptest xmm9, xmm9
00007aa9b5fdf64d  jnz 0x00007AA9B5FE2CAB
00007aa9b5fdf653  vmovaps [rsp+0x30], xmm11
00007aa9b5fdf659  vmovaps xmm1, [rsp+0x30]
00007aa9b5fdf65f  por xmm11, xmm1
00007aa9b5fdf664  movaps [r15+0x250], xmm11
00007aa9b5fdf66c  vmovaps [rsp+0x30], xmm12
00007aa9b5fdf672  vmovaps xmm1, [rsp+0x30]
00007aa9b5fdf678  por xmm12, xmm1
00007aa9b5fdf67d  movaps [r15+0x2A0], xmm12
00007aa9b5fdf685  vmovaps xmm1, [rsp+0xA0]
00007aa9b5fdf68e  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdf697  por xmm1, xmm11
00007aa9b5fdf69c  movaps [r15+0x1D0], xmm1
00007aa9b5fdf6a4  lea r12, [rax+0x40]
00007aa9b5fdf6a8  movups xmm1, [r13+r12*1]
00007aa9b5fdf6ae  movaps [r15+0x2C0], xmm1
00007aa9b5fdf6b6  vmovaps xmm11, [rsp+0x40]
00007aa9b5fdf6bc  vpermilpd xmm11, xmm11, 0x00
00007aa9b5fdf6c2  vmovaps xmm8, [rsp+0xE0]
00007aa9b5fdf6cb  movaps xmm9, xmm8
00007aa9b5fdf6cf  mulpd xmm9, xmm11
00007aa9b5fdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007aa9b5fdf6da  ptest xmm5, xmm5
00007aa9b5fdf6df  jnz 0x00007AA9B5FE2DF7
00007aa9b5fdf6e5  movaps xmm11, xmm10
00007aa9b5fdf6e9  addpd xmm11, xmm6
00007aa9b5fdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007aa9b5fdf6f4  ptest xmm8, xmm8
00007aa9b5fdf6fa  jnz 0x00007AA9B5FE2F3B
00007aa9b5fdf700  movaps xmm10, xmm14
00007aa9b5fdf704  addpd xmm10, xmm4
00007aa9b5fdf709  vcmppd xmm8, xmm10, xmm10, 0x03
00007aa9b5fdf70f  ptest xmm8, xmm8
00007aa9b5fdf715  jnz 0x00007AA9B5FE307E
00007aa9b5fdf71b  vmovaps xmm14, [rsp+0x40]
00007aa9b5fdf721  vpermilpd xmm14, xmm14, 0x00
00007aa9b5fdf727  movaps xmm8, xmm1
00007aa9b5fdf72b  mulpd xmm8, xmm14
00007aa9b5fdf730  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa9b5fdf736  ptest xmm6, xmm6
00007aa9b5fdf73b  jnz 0x00007AA9B5FE31C1
00007aa9b5fdf741  movaps xmm1, [r15+0x2B0]
00007aa9b5fdf749  vmovaps xmm14, [rsp+0x40]
00007aa9b5fdf74f  vpermilpd xmm14, xmm14, 0x00
00007aa9b5fdf755  movaps xmm6, xmm1
00007aa9b5fdf758  mulpd xmm6, xmm14
00007aa9b5fdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa9b5fdf762  ptest xmm5, xmm5
00007aa9b5fdf767  jnz 0x00007AA9B5FE3304
00007aa9b5fdf76d  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdf773  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fdf779  movaps xmm14, xmm12
00007aa9b5fdf77d  mulpd xmm14, xmm1
00007aa9b5fdf782  vcmppd xmm5, xmm14, xmm14, 0x03
00007aa9b5fdf788  ptest xmm5, xmm5
00007aa9b5fdf78d  jnz 0x00007AA9B5FE3445
00007aa9b5fdf793  movaps xmm1, xmm13
00007aa9b5fdf797  addpd xmm1, xmm9
00007aa9b5fdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa9b5fdf7a1  ptest xmm12, xmm12
00007aa9b5fdf7a7  jnz 0x00007AA9B5FE3588
00007aa9b5fdf7ad  vmovaps xmm13, [rsp+0x10]
00007aa9b5fdf7b3  vpermilpd xmm13, xmm13, 0x00
00007aa9b5fdf7b9  movaps xmm12, xmm7
00007aa9b5fdf7bd  mulpd xmm12, xmm13
00007aa9b5fdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa9b5fdf7c8  ptest xmm9, xmm9
00007aa9b5fdf7ce  jnz 0x00007AA9B5FE36CA
00007aa9b5fdf7d4  movaps xmm13, xmm15
00007aa9b5fdf7d8  addpd xmm13, xmm8
00007aa9b5fdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007aa9b5fdf7e3  ptest xmm9, xmm9
00007aa9b5fdf7e9  jnz 0x00007AA9B5FE380D
00007aa9b5fdf7ef  movaps xmm15, [r15+0x290]
00007aa9b5fdf7f7  vmovaps xmm9, [rsp+0x10]
00007aa9b5fdf7fd  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fdf803  movaps xmm8, xmm15
00007aa9b5fdf807  mulpd xmm8, xmm9
00007aa9b5fdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa9b5fdf812  ptest xmm7, xmm7
00007aa9b5fdf817  jnz 0x00007AA9B5FE3951
00007aa9b5fdf81d  movaps xmm15, xmm11
00007aa9b5fdf821  addpd xmm15, xmm6
00007aa9b5fdf826  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa9b5fdf82c  ptest xmm9, xmm9
00007aa9b5fdf832  jnz 0x00007AA9B5FE3A95
00007aa9b5fdf838  movaps xmm11, [r15+0x1E0]
00007aa9b5fdf840  vmovaps xmm9, [rsp+0x10]
00007aa9b5fdf846  vpermilpd xmm9, xmm9, 0x00
00007aa9b5fdf84c  movaps xmm7, xmm11
00007aa9b5fdf850  mulpd xmm7, xmm9
00007aa9b5fdf855  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa9b5fdf85a  ptest xmm6, xmm6
00007aa9b5fdf85f  jnz 0x00007AA9B5FE3BD8
00007aa9b5fdf865  movaps xmm11, xmm10
00007aa9b5fdf869  addpd xmm11, xmm14
00007aa9b5fdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007aa9b5fdf874  ptest xmm9, xmm9
00007aa9b5fdf87a  jnz 0x00007AA9B5FE3D1A
00007aa9b5fdf880  lea r12, [rax+0x70]
00007aa9b5fdf884  movups xmm14, [r13+r12*1]
00007aa9b5fdf88a  movaps [r15+0x240], xmm14
00007aa9b5fdf892  movaps xmm10, xmm1
00007aa9b5fdf896  addpd xmm10, xmm12
00007aa9b5fdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007aa9b5fdf8a1  ptest xmm9, xmm9
00007aa9b5fdf8a7  jnz 0x00007AA9B5FE3E68
00007aa9b5fdf8ad  movaps [r15+0x170], xmm10
00007aa9b5fdf8b5  vmovaps xmm1, [rsp+0x20]
00007aa9b5fdf8bb  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fdf8c1  movaps xmm12, xmm14
00007aa9b5fdf8c5  mulpd xmm12, xmm1
00007aa9b5fdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa9b5fdf8d0  ptest xmm9, xmm9
00007aa9b5fdf8d6  jnz 0x00007AA9B5FE3FAB
00007aa9b5fdf8dc  vmovaps xmm1, [rsp+0x20]
00007aa9b5fdf8e2  vpermilpd xmm1, xmm1, 0x00
00007aa9b5fdf8e8  vmovaps xmm9, [rsp+0xB0]
00007aa9b5fdf8f1  movaps xmm14, xmm9
00007aa9b5fdf8f5  mulpd xmm14, xmm1
00007aa9b5fdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa9b5fdf900  ptest xmm6, xmm6
00007aa9b5fdf905  jnz 0x00007AA9B5FE40EE
00007aa9b5fdf90b  movaps [r15+0x180], xmm14
00007aa9b5fdf913  movaps xmm1, xmm13
00007aa9b5fdf917  addpd xmm1, xmm8
00007aa9b5fdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007aa9b5fdf921  ptest xmm9, xmm9
00007aa9b5fdf927  jnz 0x00007AA9B5FE4231
00007aa9b5fdf92d  movaps [r15+0x210], xmm1
00007aa9b5fdf935  movups xmm13, [r13+rax*1]
00007aa9b5fdf93b  lea r12, [rax+0x10]
00007aa9b5fdf93f  movups xmm9, [r13+r12*1]
00007aa9b5fdf945  movaps [r15+0x230], xmm9
00007aa9b5fdf94d  movaps xmm8, xmm15
00007aa9b5fdf951  addpd xmm8, xmm7
00007aa9b5fdf956  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa9b5fdf95c  ptest xmm6, xmm6
00007aa9b5fdf961  jnz 0x00007AA9B5FE4387
00007aa9b5fdf967  movaps [r15+0x130], xmm8
00007aa9b5fdf96f  vmovaps xmm15, [rsp+0x20]
00007aa9b5fdf975  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fdf97b  movaps xmm7, xmm9
00007aa9b5fdf97f  mulpd xmm7, xmm15
00007aa9b5fdf984  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa9b5fdf989  ptest xmm6, xmm6
00007aa9b5fdf98e  jnz 0x00007AA9B5FE44CA
00007aa9b5fdf994  movaps [r15+0x220], xmm7
00007aa9b5fdf99c  vmovaps xmm15, [rsp+0x20]
00007aa9b5fdf9a2  vpermilpd xmm15, xmm15, 0x00
00007aa9b5fdf9a8  movaps xmm9, xmm13
00007aa9b5fdf9ac  mulpd xmm9, xmm15
00007aa9b5fdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa9b5fdf9b7  ptest xmm6, xmm6
00007aa9b5fdf9bc  jnz 0x00007AA9B5FE460C
00007aa9b5fdf9c2  movaps xmm15, xmm11
00007aa9b5fdf9c6  addpd xmm15, xmm12
00007aa9b5fdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007aa9b5fdf9d1  ptest xmm13, xmm13
00007aa9b5fdf9d7  jnz 0x00007AA9B5FE4750
00007aa9b5fdf9dd  movaps [r15+0x140], xmm15
00007aa9b5fdf9e5  movaps xmm13, xmm10
00007aa9b5fdf9e9  addpd xmm13, xmm14
00007aa9b5fdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007aa9b5fdf9f4  ptest xmm12, xmm12
00007aa9b5fdf9fa  jnz 0x00007AA9B5FE4894
00007aa9b5fdfa00  movaps [r15+0x150], xmm13
00007aa9b5fdfa08  movaps xmm14, xmm1
00007aa9b5fdfa0c  addpd xmm14, xmm7
00007aa9b5fdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007aa9b5fdfa17  ptest xmm12, xmm12
00007aa9b5fdfa1d  jnz 0x00007AA9B5FE49D8
00007aa9b5fdfa23  movaps [r15+0x160], xmm14
00007aa9b5fdfa2b  movaps xmm1, xmm8
00007aa9b5fdfa2f  addpd xmm1, xmm9
00007aa9b5fdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa9b5fdfa39  ptest xmm12, xmm12
00007aa9b5fdfa3f  jnz 0x00007AA9B5FE4B1A
00007aa9b5fdfa45  movaps [r15+0x120], xmm1
00007aa9b5fdfa4d  movups [r13+r14*1], xmm15
00007aa9b5fdfa53  lea rax, [r14+0x10]
00007aa9b5fdfa57  movups [r13+rax*1], xmm13
00007aa9b5fdfa5d  lea rax, [r14+0x20]
00007aa9b5fdfa61  movups [r13+rax*1], xmm14
00007aa9b5fdfa67  lea rax, [r14+0x30]
00007aa9b5fdfa6b  movups [r13+rax*1], xmm1
00007aa9b5fdfa71  mov eax, [r15+0x108]
00007aa9b5fdfa78  sahf
00007aa9b5fdfa79  jnz 0x00007AA9B5FDFAAB
00007aa9b5fdfa7b  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fdfa83  jz 0x00007AA9B5FDEAE0
00007aa9b5fdfa89  nop [rax+rax*1], ax
00007aa9b5fdfa92  nop [rax+rax*1], eax
00007aa9b5fdfa9a  mov eax, 0x4106D0
00007aa9b5fdfa9f  mov [r15+0x100], rax
00007aa9b5fdfaa6  jmp 0x00007AA9B5DFE110
00007aa9b5fdfaab  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fdfab3  jz 0x00007AA9B5FD89C0
00007aa9b5fdfab9  nop [rax+rax*1], ax
00007aa9b5fdfac2  nop [rax+rax*1], eax
00007aa9b5fdfaca  mov eax, 0x410504
00007aa9b5fdfacf  mov [r15+0x100], rax
00007aa9b5fdfad6  jmp 0x00007AA9B5DFE110
00007aa9b5fdfadb  int3
00007aa9b5fdfadc  call 0x00007AA9B5EE27E0
00007aa9b5fdfae1  jmp 0x00007AA9B5FDEBBF
00007aa9b5fdfae6  call 0x00007AA9B5EE1570
00007aa9b5fdfaeb  jmp 0x00007AA9B5FDEBC8
00007aa9b5fdfaf0  call 0x00007AA9B5EE27E0
00007aa9b5fdfaf5  jmp 0x00007AA9B5FDEC24
00007aa9b5fdfafa  call 0x00007AA9B5EE1570
00007aa9b5fdfaff  jmp 0x00007AA9B5FDEC2D
00007aa9b5fdfb04  call 0x00007AA9B5EE27E0
00007aa9b5fdfb09  jmp 0x00007AA9B5FDEC70
00007aa9b5fdfb0e  call 0x00007AA9B5EE1570
00007aa9b5fdfb13  jmp 0x00007AA9B5FDEC79
00007aa9b5fdfb18  call 0x00007AA9B5E0DC20
00007aa9b5fdfb1d  jmp 0x00007AA9B5FDECB8
00007aa9b5fdfb22  call 0x00007AA9B5ED59C0
00007aa9b5fdfb27  jmp 0x00007AA9B5FDECCB
00007aa9b5fdfb2c  call 0x00007AA9B5EE0E30
00007aa9b5fdfb31  jmp 0x00007AA9B5FDECE9
00007aa9b5fdfb36  call 0x00007AA9B5EDFBC0
00007aa9b5fdfb3b  jmp 0x00007AA9B5FDECF3
00007aa9b5fdfb40  call 0x00007AA9B5EDE950
00007aa9b5fdfb45  jmp 0x00007AA9B5FDECFD
00007aa9b5fdfb4a  sub rsp, 0x08
00007aa9b5fdfb4e  push rax
00007aa9b5fdfb4f  push rcx
00007aa9b5fdfb50  push rdx
00007aa9b5fdfb51  push rdi
00007aa9b5fdfb52  push rsi
00007aa9b5fdfb53  push r8
00007aa9b5fdfb55  push r9
00007aa9b5fdfb57  push r10
00007aa9b5fdfb59  push r11
00007aa9b5fdfb5b  sub rsp, 0xF0
00007aa9b5fdfb62  vmovaps [rsp], xmm0
00007aa9b5fdfb67  vmovaps [rsp+0x10], xmm1
00007aa9b5fdfb6d  vmovaps [rsp+0x20], xmm2
00007aa9b5fdfb73  vmovaps [rsp+0x30], xmm3
00007aa9b5fdfb79  vmovaps [rsp+0x40], xmm4
00007aa9b5fdfb7f  vmovaps [rsp+0x50], xmm5
00007aa9b5fdfb85  vmovaps [rsp+0x60], xmm6
00007aa9b5fdfb8b  vmovaps [rsp+0x70], xmm7
00007aa9b5fdfb91  vmovaps [rsp+0x80], xmm9
00007aa9b5fdfb9a  vmovaps [rsp+0x90], xmm10
00007aa9b5fdfba3  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdfbac  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdfbb5  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdfbbe  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdfbc7  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdfbd0  sub rsp, 0x30
00007aa9b5fdfbd4  movaps [rsp], xmm8
00007aa9b5fdfbd9  movaps [rsp+0x10], xmm12
00007aa9b5fdfbdf  movaps [rsp+0x20], xmm15
00007aa9b5fdfbe5  lea rdi, [rsp]
00007aa9b5fdfbe9  mov esi, 0x00
00007aa9b5fdfbee  mov rax, 0x63E0217C9530
00007aa9b5fdfbf8  call rax
00007aa9b5fdfbfa  movaps xmm8, [rsp]
00007aa9b5fdfbff  add rsp, 0x30
00007aa9b5fdfc03  vmovaps xmm0, [rsp]
00007aa9b5fdfc08  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdfc0e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdfc14  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdfc1a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdfc20  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdfc26  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdfc2c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdfc32  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdfc3b  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdfc44  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdfc4d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdfc56  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdfc5f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdfc68  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdfc71  add rsp, 0xF0
00007aa9b5fdfc78  pop r11
00007aa9b5fdfc7a  pop r10
00007aa9b5fdfc7c  pop r9
00007aa9b5fdfc7e  pop r8
00007aa9b5fdfc80  pop rsi
00007aa9b5fdfc81  pop rdi
00007aa9b5fdfc82  pop rdx
00007aa9b5fdfc83  pop rcx
00007aa9b5fdfc84  pop rax
00007aa9b5fdfc85  add rsp, 0x08
00007aa9b5fdfc89  jmp 0x00007AA9B5FDED27
00007aa9b5fdfc8e  sub rsp, 0x08
00007aa9b5fdfc92  push rax
00007aa9b5fdfc93  push rcx
00007aa9b5fdfc94  push rdx
00007aa9b5fdfc95  push rdi
00007aa9b5fdfc96  push rsi
00007aa9b5fdfc97  push r8
00007aa9b5fdfc99  push r9
00007aa9b5fdfc9b  push r10
00007aa9b5fdfc9d  push r11
00007aa9b5fdfc9f  sub rsp, 0xF0
00007aa9b5fdfca6  vmovaps [rsp], xmm0
00007aa9b5fdfcab  vmovaps [rsp+0x10], xmm1
00007aa9b5fdfcb1  vmovaps [rsp+0x20], xmm2
00007aa9b5fdfcb7  vmovaps [rsp+0x30], xmm3
00007aa9b5fdfcbd  vmovaps [rsp+0x40], xmm4
00007aa9b5fdfcc3  vmovaps [rsp+0x50], xmm5
00007aa9b5fdfcc9  vmovaps [rsp+0x60], xmm6
00007aa9b5fdfccf  vmovaps [rsp+0x70], xmm8
00007aa9b5fdfcd5  vmovaps [rsp+0x80], xmm9
00007aa9b5fdfcde  vmovaps [rsp+0x90], xmm10
00007aa9b5fdfce7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdfcf0  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdfcf9  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdfd02  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdfd0b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdfd14  sub rsp, 0x30
00007aa9b5fdfd18  movaps [rsp], xmm7
00007aa9b5fdfd1c  movaps [rsp+0x10], xmm9
00007aa9b5fdfd22  movaps [rsp+0x20], xmm15
00007aa9b5fdfd28  lea rdi, [rsp]
00007aa9b5fdfd2c  mov esi, 0x00
00007aa9b5fdfd31  mov rax, 0x63E0217C9530
00007aa9b5fdfd3b  call rax
00007aa9b5fdfd3d  movaps xmm7, [rsp]
00007aa9b5fdfd41  add rsp, 0x30
00007aa9b5fdfd45  vmovaps xmm0, [rsp]
00007aa9b5fdfd4a  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdfd50  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdfd56  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdfd5c  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdfd62  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdfd68  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdfd6e  vmovaps xmm8, [rsp+0x70]
00007aa9b5fdfd74  vmovaps xmm9, [rsp+0x80]
00007aa9b5fdfd7d  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdfd86  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdfd8f  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdfd98  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdfda1  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdfdaa  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdfdb3  add rsp, 0xF0
00007aa9b5fdfdba  pop r11
00007aa9b5fdfdbc  pop r10
00007aa9b5fdfdbe  pop r9
00007aa9b5fdfdc0  pop r8
00007aa9b5fdfdc2  pop rsi
00007aa9b5fdfdc3  pop rdi
00007aa9b5fdfdc4  pop rdx
00007aa9b5fdfdc5  pop rcx
00007aa9b5fdfdc6  pop rax
00007aa9b5fdfdc7  add rsp, 0x08
00007aa9b5fdfdcb  jmp 0x00007AA9B5FDED55
00007aa9b5fdfdd0  sub rsp, 0x08
00007aa9b5fdfdd4  push rax
00007aa9b5fdfdd5  push rcx
00007aa9b5fdfdd6  push rdx
00007aa9b5fdfdd7  push rdi
00007aa9b5fdfdd8  push rsi
00007aa9b5fdfdd9  push r8
00007aa9b5fdfddb  push r9
00007aa9b5fdfddd  push r10
00007aa9b5fdfddf  push r11
00007aa9b5fdfde1  sub rsp, 0xF0
00007aa9b5fdfde8  vmovaps [rsp], xmm0
00007aa9b5fdfded  vmovaps [rsp+0x10], xmm1
00007aa9b5fdfdf3  vmovaps [rsp+0x20], xmm2
00007aa9b5fdfdf9  vmovaps [rsp+0x30], xmm3
00007aa9b5fdfdff  vmovaps [rsp+0x40], xmm4
00007aa9b5fdfe05  vmovaps [rsp+0x50], xmm5
00007aa9b5fdfe0b  vmovaps [rsp+0x60], xmm6
00007aa9b5fdfe11  vmovaps [rsp+0x70], xmm7
00007aa9b5fdfe17  vmovaps [rsp+0x80], xmm8
00007aa9b5fdfe20  vmovaps [rsp+0x90], xmm10
00007aa9b5fdfe29  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdfe32  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdfe3b  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdfe44  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdfe4d  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdfe56  sub rsp, 0x30
00007aa9b5fdfe5a  movaps [rsp], xmm9
00007aa9b5fdfe5f  movaps [rsp+0x10], xmm12
00007aa9b5fdfe65  movaps [rsp+0x20], xmm10
00007aa9b5fdfe6b  lea rdi, [rsp]
00007aa9b5fdfe6f  mov esi, 0x00
00007aa9b5fdfe74  mov rax, 0x63E0217C9530
00007aa9b5fdfe7e  call rax
00007aa9b5fdfe80  movaps xmm9, [rsp]
00007aa9b5fdfe85  add rsp, 0x30
00007aa9b5fdfe89  vmovaps xmm0, [rsp]
00007aa9b5fdfe8e  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdfe94  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdfe9a  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdfea0  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdfea6  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdfeac  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdfeb2  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdfeb8  vmovaps xmm8, [rsp+0x80]
00007aa9b5fdfec1  vmovaps xmm10, [rsp+0x90]
00007aa9b5fdfeca  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fdfed3  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fdfedc  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fdfee5  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fdfeee  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fdfef7  add rsp, 0xF0
00007aa9b5fdfefe  pop r11
00007aa9b5fdff00  pop r10
00007aa9b5fdff02  pop r9
00007aa9b5fdff04  pop r8
00007aa9b5fdff06  pop rsi
00007aa9b5fdff07  pop rdi
00007aa9b5fdff08  pop rdx
00007aa9b5fdff09  pop rcx
00007aa9b5fdff0a  pop rax
00007aa9b5fdff0b  add rsp, 0x08
00007aa9b5fdff0f  jmp 0x00007AA9B5FDED79
00007aa9b5fdff14  sub rsp, 0x08
00007aa9b5fdff18  push rax
00007aa9b5fdff19  push rcx
00007aa9b5fdff1a  push rdx
00007aa9b5fdff1b  push rdi
00007aa9b5fdff1c  push rsi
00007aa9b5fdff1d  push r8
00007aa9b5fdff1f  push r9
00007aa9b5fdff21  push r10
00007aa9b5fdff23  push r11
00007aa9b5fdff25  sub rsp, 0xF0
00007aa9b5fdff2c  vmovaps [rsp], xmm0
00007aa9b5fdff31  vmovaps [rsp+0x10], xmm1
00007aa9b5fdff37  vmovaps [rsp+0x20], xmm2
00007aa9b5fdff3d  vmovaps [rsp+0x30], xmm3
00007aa9b5fdff43  vmovaps [rsp+0x40], xmm4
00007aa9b5fdff49  vmovaps [rsp+0x50], xmm5
00007aa9b5fdff4f  vmovaps [rsp+0x60], xmm6
00007aa9b5fdff55  vmovaps [rsp+0x70], xmm7
00007aa9b5fdff5b  vmovaps [rsp+0x80], xmm8
00007aa9b5fdff64  vmovaps [rsp+0x90], xmm9
00007aa9b5fdff6d  vmovaps [rsp+0xA0], xmm11
00007aa9b5fdff76  vmovaps [rsp+0xB0], xmm12
00007aa9b5fdff7f  vmovaps [rsp+0xC0], xmm13
00007aa9b5fdff88  vmovaps [rsp+0xD0], xmm14
00007aa9b5fdff91  vmovaps [rsp+0xE0], xmm15
00007aa9b5fdff9a  sub rsp, 0x30
00007aa9b5fdff9e  movaps [rsp], xmm10
00007aa9b5fdffa3  movaps [rsp+0x10], xmm12
00007aa9b5fdffa9  movaps [rsp+0x20], xmm11
00007aa9b5fdffaf  lea rdi, [rsp]
00007aa9b5fdffb3  mov esi, 0x00
00007aa9b5fdffb8  mov rax, 0x63E0217C9530
00007aa9b5fdffc2  call rax
00007aa9b5fdffc4  movaps xmm10, [rsp]
00007aa9b5fdffc9  add rsp, 0x30
00007aa9b5fdffcd  vmovaps xmm0, [rsp]
00007aa9b5fdffd2  vmovaps xmm1, [rsp+0x10]
00007aa9b5fdffd8  vmovaps xmm2, [rsp+0x20]
00007aa9b5fdffde  vmovaps xmm3, [rsp+0x30]
00007aa9b5fdffe4  vmovaps xmm4, [rsp+0x40]
00007aa9b5fdffea  vmovaps xmm5, [rsp+0x50]
00007aa9b5fdfff0  vmovaps xmm6, [rsp+0x60]
00007aa9b5fdfff6  vmovaps xmm7, [rsp+0x70]
00007aa9b5fdfffc  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe0005  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe000e  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0017  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe0020  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe0029  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe0032  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe003b  add rsp, 0xF0
00007aa9b5fe0042  pop r11
00007aa9b5fe0044  pop r10
00007aa9b5fe0046  pop r9
00007aa9b5fe0048  pop r8
00007aa9b5fe004a  pop rsi
00007aa9b5fe004b  pop rdi
00007aa9b5fe004c  pop rdx
00007aa9b5fe004d  pop rcx
00007aa9b5fe004e  pop rax
00007aa9b5fe004f  add rsp, 0x08
00007aa9b5fe0053  jmp 0x00007AA9B5FDED93
00007aa9b5fe0058  sub rsp, 0x08
00007aa9b5fe005c  push rax
00007aa9b5fe005d  push rcx
00007aa9b5fe005e  push rdx
00007aa9b5fe005f  push rdi
00007aa9b5fe0060  push rsi
00007aa9b5fe0061  push r8
00007aa9b5fe0063  push r9
00007aa9b5fe0065  push r10
00007aa9b5fe0067  push r11
00007aa9b5fe0069  sub rsp, 0xF0
00007aa9b5fe0070  vmovaps [rsp], xmm0
00007aa9b5fe0075  vmovaps [rsp+0x10], xmm1
00007aa9b5fe007b  vmovaps [rsp+0x20], xmm2
00007aa9b5fe0081  vmovaps [rsp+0x30], xmm3
00007aa9b5fe0087  vmovaps [rsp+0x40], xmm4
00007aa9b5fe008d  vmovaps [rsp+0x50], xmm5
00007aa9b5fe0093  vmovaps [rsp+0x60], xmm7
00007aa9b5fe0099  vmovaps [rsp+0x70], xmm8
00007aa9b5fe009f  vmovaps [rsp+0x80], xmm9
00007aa9b5fe00a8  vmovaps [rsp+0x90], xmm10
00007aa9b5fe00b1  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe00ba  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe00c3  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe00cc  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe00d5  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe00de  sub rsp, 0x30
00007aa9b5fe00e2  movaps [rsp], xmm6
00007aa9b5fe00e6  movaps [rsp+0x10], xmm12
00007aa9b5fe00ec  movaps [rsp+0x20], xmm11
00007aa9b5fe00f2  lea rdi, [rsp]
00007aa9b5fe00f6  mov esi, 0x00
00007aa9b5fe00fb  mov rax, 0x63E0217C9530
00007aa9b5fe0105  call rax
00007aa9b5fe0107  movaps xmm6, [rsp]
00007aa9b5fe010b  add rsp, 0x30
00007aa9b5fe010f  vmovaps xmm0, [rsp]
00007aa9b5fe0114  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe011a  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe0120  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe0126  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe012c  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe0132  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe0138  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe013e  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe0147  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0150  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0159  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe0162  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe016b  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe0174  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe017d  add rsp, 0xF0
00007aa9b5fe0184  pop r11
00007aa9b5fe0186  pop r10
00007aa9b5fe0188  pop r9
00007aa9b5fe018a  pop r8
00007aa9b5fe018c  pop rsi
00007aa9b5fe018d  pop rdi
00007aa9b5fe018e  pop rdx
00007aa9b5fe018f  pop rcx
00007aa9b5fe0190  pop rax
00007aa9b5fe0191  add rsp, 0x08
00007aa9b5fe0195  jmp 0x00007AA9B5FDEDB4
00007aa9b5fe019a  sub rsp, 0x08
00007aa9b5fe019e  push rax
00007aa9b5fe019f  push rcx
00007aa9b5fe01a0  push rdx
00007aa9b5fe01a1  push rdi
00007aa9b5fe01a2  push rsi
00007aa9b5fe01a3  push r8
00007aa9b5fe01a5  push r9
00007aa9b5fe01a7  push r10
00007aa9b5fe01a9  push r11
00007aa9b5fe01ab  sub rsp, 0xF0
00007aa9b5fe01b2  vmovaps [rsp], xmm0
00007aa9b5fe01b7  vmovaps [rsp+0x10], xmm1
00007aa9b5fe01bd  vmovaps [rsp+0x20], xmm2
00007aa9b5fe01c3  vmovaps [rsp+0x30], xmm4
00007aa9b5fe01c9  vmovaps [rsp+0x40], xmm5
00007aa9b5fe01cf  vmovaps [rsp+0x50], xmm6
00007aa9b5fe01d5  vmovaps [rsp+0x60], xmm7
00007aa9b5fe01db  vmovaps [rsp+0x70], xmm8
00007aa9b5fe01e1  vmovaps [rsp+0x80], xmm9
00007aa9b5fe01ea  vmovaps [rsp+0x90], xmm10
00007aa9b5fe01f3  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe01fc  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe0205  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe020e  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe0217  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe0220  sub rsp, 0x30
00007aa9b5fe0224  movaps [rsp], xmm3
00007aa9b5fe0228  movaps [rsp+0x10], xmm5
00007aa9b5fe022d  movaps [rsp+0x20], xmm4
00007aa9b5fe0232  lea rdi, [rsp]
00007aa9b5fe0236  mov esi, 0x00
00007aa9b5fe023b  mov rax, 0x63E0217C9530
00007aa9b5fe0245  call rax
00007aa9b5fe0247  movaps xmm3, [rsp]
00007aa9b5fe024b  add rsp, 0x30
00007aa9b5fe024f  vmovaps xmm0, [rsp]
00007aa9b5fe0254  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe025a  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe0260  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe0266  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe026c  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe0272  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe0278  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe027e  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe0287  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0290  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0299  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe02a2  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe02ab  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe02b4  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe02bd  add rsp, 0xF0
00007aa9b5fe02c4  pop r11
00007aa9b5fe02c6  pop r10
00007aa9b5fe02c8  pop r9
00007aa9b5fe02ca  pop r8
00007aa9b5fe02cc  pop rsi
00007aa9b5fe02cd  pop rdi
00007aa9b5fe02ce  pop rdx
00007aa9b5fe02cf  pop rcx
00007aa9b5fe02d0  pop rax
00007aa9b5fe02d1  add rsp, 0x08
00007aa9b5fe02d5  jmp 0x00007AA9B5FDEE15
00007aa9b5fe02da  sub rsp, 0x08
00007aa9b5fe02de  push rax
00007aa9b5fe02df  push rcx
00007aa9b5fe02e0  push rdx
00007aa9b5fe02e1  push rdi
00007aa9b5fe02e2  push rsi
00007aa9b5fe02e3  push r8
00007aa9b5fe02e5  push r9
00007aa9b5fe02e7  push r10
00007aa9b5fe02e9  push r11
00007aa9b5fe02eb  sub rsp, 0xF0
00007aa9b5fe02f2  vmovaps [rsp], xmm0
00007aa9b5fe02f7  vmovaps [rsp+0x10], xmm1
00007aa9b5fe02fd  vmovaps [rsp+0x20], xmm2
00007aa9b5fe0303  vmovaps [rsp+0x30], xmm3
00007aa9b5fe0309  vmovaps [rsp+0x40], xmm4
00007aa9b5fe030f  vmovaps [rsp+0x50], xmm6
00007aa9b5fe0315  vmovaps [rsp+0x60], xmm7
00007aa9b5fe031b  vmovaps [rsp+0x70], xmm8
00007aa9b5fe0321  vmovaps [rsp+0x80], xmm9
00007aa9b5fe032a  vmovaps [rsp+0x90], xmm10
00007aa9b5fe0333  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe033c  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe0345  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe034e  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe0357  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe0360  sub rsp, 0x30
00007aa9b5fe0364  movaps [rsp], xmm5
00007aa9b5fe0368  movaps [rsp+0x10], xmm8
00007aa9b5fe036e  movaps [rsp+0x20], xmm15
00007aa9b5fe0374  lea rdi, [rsp]
00007aa9b5fe0378  mov esi, 0x00
00007aa9b5fe037d  mov rax, 0x63E0217C9530
00007aa9b5fe0387  call rax
00007aa9b5fe0389  movaps xmm5, [rsp]
00007aa9b5fe038d  add rsp, 0x30
00007aa9b5fe0391  vmovaps xmm0, [rsp]
00007aa9b5fe0396  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe039c  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe03a2  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe03a8  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe03ae  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe03b4  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe03ba  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe03c0  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe03c9  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe03d2  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe03db  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe03e4  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe03ed  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe03f6  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe03ff  add rsp, 0xF0
00007aa9b5fe0406  pop r11
00007aa9b5fe0408  pop r10
00007aa9b5fe040a  pop r9
00007aa9b5fe040c  pop r8
00007aa9b5fe040e  pop rsi
00007aa9b5fe040f  pop rdi
00007aa9b5fe0410  pop rdx
00007aa9b5fe0411  pop rcx
00007aa9b5fe0412  pop rax
00007aa9b5fe0413  add rsp, 0x08
00007aa9b5fe0417  jmp 0x00007AA9B5FDEE53
00007aa9b5fe041c  sub rsp, 0x08
00007aa9b5fe0420  push rax
00007aa9b5fe0421  push rcx
00007aa9b5fe0422  push rdx
00007aa9b5fe0423  push rdi
00007aa9b5fe0424  push rsi
00007aa9b5fe0425  push r8
00007aa9b5fe0427  push r9
00007aa9b5fe0429  push r10
00007aa9b5fe042b  push r11
00007aa9b5fe042d  sub rsp, 0xF0
00007aa9b5fe0434  vmovaps [rsp], xmm0
00007aa9b5fe0439  vmovaps [rsp+0x10], xmm1
00007aa9b5fe043f  vmovaps [rsp+0x20], xmm2
00007aa9b5fe0445  vmovaps [rsp+0x30], xmm3
00007aa9b5fe044b  vmovaps [rsp+0x40], xmm5
00007aa9b5fe0451  vmovaps [rsp+0x50], xmm6
00007aa9b5fe0457  vmovaps [rsp+0x60], xmm7
00007aa9b5fe045d  vmovaps [rsp+0x70], xmm8
00007aa9b5fe0463  vmovaps [rsp+0x80], xmm9
00007aa9b5fe046c  vmovaps [rsp+0x90], xmm10
00007aa9b5fe0475  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe047e  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe0487  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe0490  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe0499  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe04a2  sub rsp, 0x30
00007aa9b5fe04a6  movaps [rsp], xmm4
00007aa9b5fe04aa  movaps [rsp+0x10], xmm9
00007aa9b5fe04b0  movaps [rsp+0x20], xmm8
00007aa9b5fe04b6  lea rdi, [rsp]
00007aa9b5fe04ba  mov esi, 0x00
00007aa9b5fe04bf  mov rax, 0x63E0217C9530
00007aa9b5fe04c9  call rax
00007aa9b5fe04cb  movaps xmm4, [rsp]
00007aa9b5fe04cf  add rsp, 0x30
00007aa9b5fe04d3  vmovaps xmm0, [rsp]
00007aa9b5fe04d8  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe04de  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe04e4  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe04ea  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe04f0  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe04f6  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe04fc  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe0502  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe050b  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0514  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe051d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe0526  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe052f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe0538  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe0541  add rsp, 0xF0
00007aa9b5fe0548  pop r11
00007aa9b5fe054a  pop r10
00007aa9b5fe054c  pop r9
00007aa9b5fe054e  pop r8
00007aa9b5fe0550  pop rsi
00007aa9b5fe0551  pop rdi
00007aa9b5fe0552  pop rdx
00007aa9b5fe0553  pop rcx
00007aa9b5fe0554  pop rax
00007aa9b5fe0555  add rsp, 0x08
00007aa9b5fe0559  jmp 0x00007AA9B5FDEE74
00007aa9b5fe055e  sub rsp, 0x08
00007aa9b5fe0562  push rax
00007aa9b5fe0563  push rcx
00007aa9b5fe0564  push rdx
00007aa9b5fe0565  push rdi
00007aa9b5fe0566  push rsi
00007aa9b5fe0567  push r8
00007aa9b5fe0569  push r9
00007aa9b5fe056b  push r10
00007aa9b5fe056d  push r11
00007aa9b5fe056f  sub rsp, 0xF0
00007aa9b5fe0576  vmovaps [rsp], xmm0
00007aa9b5fe057b  vmovaps [rsp+0x10], xmm1
00007aa9b5fe0581  vmovaps [rsp+0x20], xmm2
00007aa9b5fe0587  vmovaps [rsp+0x30], xmm3
00007aa9b5fe058d  vmovaps [rsp+0x40], xmm4
00007aa9b5fe0593  vmovaps [rsp+0x50], xmm5
00007aa9b5fe0599  vmovaps [rsp+0x60], xmm6
00007aa9b5fe059f  vmovaps [rsp+0x70], xmm7
00007aa9b5fe05a5  vmovaps [rsp+0x80], xmm8
00007aa9b5fe05ae  vmovaps [rsp+0x90], xmm10
00007aa9b5fe05b7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe05c0  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe05c9  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe05d2  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe05db  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe05e4  sub rsp, 0x30
00007aa9b5fe05e8  movaps [rsp], xmm9
00007aa9b5fe05ed  movaps [rsp+0x10], xmm10
00007aa9b5fe05f3  movaps [rsp+0x20], xmm8
00007aa9b5fe05f9  lea rdi, [rsp]
00007aa9b5fe05fd  mov esi, 0x00
00007aa9b5fe0602  mov rax, 0x63E0217C9530
00007aa9b5fe060c  call rax
00007aa9b5fe060e  movaps xmm9, [rsp]
00007aa9b5fe0613  add rsp, 0x30
00007aa9b5fe0617  vmovaps xmm0, [rsp]
00007aa9b5fe061c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe0622  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe0628  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe062e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe0634  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe063a  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe0640  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe0646  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe064f  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0658  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0661  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe066a  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe0673  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe067c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe0685  add rsp, 0xF0
00007aa9b5fe068c  pop r11
00007aa9b5fe068e  pop r10
00007aa9b5fe0690  pop r9
00007aa9b5fe0692  pop r8
00007aa9b5fe0694  pop rsi
00007aa9b5fe0695  pop rdi
00007aa9b5fe0696  pop rdx
00007aa9b5fe0697  pop rcx
00007aa9b5fe0698  pop rax
00007aa9b5fe0699  add rsp, 0x08
00007aa9b5fe069d  jmp 0x00007AA9B5FDEE8E
00007aa9b5fe06a2  call 0x00007AA9B5EB52F0
00007aa9b5fe06a7  jmp 0x00007AA9B5FDEFA8
00007aa9b5fe06ac  call 0x00007AA9B5EB52F0
00007aa9b5fe06b1  jmp 0x00007AA9B5FDEFBE
00007aa9b5fe06b6  sub rsp, 0x08
00007aa9b5fe06ba  push rax
00007aa9b5fe06bb  push rcx
00007aa9b5fe06bc  push rdx
00007aa9b5fe06bd  push rdi
00007aa9b5fe06be  push rsi
00007aa9b5fe06bf  push r8
00007aa9b5fe06c1  push r9
00007aa9b5fe06c3  push r10
00007aa9b5fe06c5  push r11
00007aa9b5fe06c7  sub rsp, 0xF0
00007aa9b5fe06ce  vmovaps [rsp], xmm0
00007aa9b5fe06d3  vmovaps [rsp+0x10], xmm2
00007aa9b5fe06d9  vmovaps [rsp+0x20], xmm3
00007aa9b5fe06df  vmovaps [rsp+0x30], xmm4
00007aa9b5fe06e5  vmovaps [rsp+0x40], xmm5
00007aa9b5fe06eb  vmovaps [rsp+0x50], xmm6
00007aa9b5fe06f1  vmovaps [rsp+0x60], xmm7
00007aa9b5fe06f7  vmovaps [rsp+0x70], xmm8
00007aa9b5fe06fd  vmovaps [rsp+0x80], xmm9
00007aa9b5fe0706  vmovaps [rsp+0x90], xmm10
00007aa9b5fe070f  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe0718  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe0721  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe072a  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe0733  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe073c  sub rsp, 0x30
00007aa9b5fe0740  movaps [rsp], xmm1
00007aa9b5fe0744  movaps [rsp+0x10], xmm6
00007aa9b5fe0749  movaps [rsp+0x20], xmm15
00007aa9b5fe074f  lea rdi, [rsp]
00007aa9b5fe0753  mov esi, 0x00
00007aa9b5fe0758  mov rax, 0x63E0217C9530
00007aa9b5fe0762  call rax
00007aa9b5fe0764  movaps xmm1, [rsp]
00007aa9b5fe0768  add rsp, 0x30
00007aa9b5fe076c  vmovaps xmm0, [rsp]
00007aa9b5fe0771  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe0777  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe077d  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe0783  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe0789  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe078f  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe0795  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe079b  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe07a4  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe07ad  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe07b6  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe07bf  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe07c8  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe07d1  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe07da  add rsp, 0xF0
00007aa9b5fe07e1  pop r11
00007aa9b5fe07e3  pop r10
00007aa9b5fe07e5  pop r9
00007aa9b5fe07e7  pop r8
00007aa9b5fe07e9  pop rsi
00007aa9b5fe07ea  pop rdi
00007aa9b5fe07eb  pop rdx
00007aa9b5fe07ec  pop rcx
00007aa9b5fe07ed  pop rax
00007aa9b5fe07ee  add rsp, 0x08
00007aa9b5fe07f2  jmp 0x00007AA9B5FDEFFB
00007aa9b5fe07f7  call 0x00007AA9B5EC4620
00007aa9b5fe07fc  jmp 0x00007AA9B5FDF008
00007aa9b5fe0801  sub rsp, 0x08
00007aa9b5fe0805  push rax
00007aa9b5fe0806  push rcx
00007aa9b5fe0807  push rdx
00007aa9b5fe0808  push rdi
00007aa9b5fe0809  push rsi
00007aa9b5fe080a  push r8
00007aa9b5fe080c  push r9
00007aa9b5fe080e  push r10
00007aa9b5fe0810  push r11
00007aa9b5fe0812  sub rsp, 0xF0
00007aa9b5fe0819  vmovaps [rsp], xmm0
00007aa9b5fe081e  vmovaps [rsp+0x10], xmm1
00007aa9b5fe0824  vmovaps [rsp+0x20], xmm2
00007aa9b5fe082a  vmovaps [rsp+0x30], xmm3
00007aa9b5fe0830  vmovaps [rsp+0x40], xmm4
00007aa9b5fe0836  vmovaps [rsp+0x50], xmm5
00007aa9b5fe083c  vmovaps [rsp+0x60], xmm6
00007aa9b5fe0842  vmovaps [rsp+0x70], xmm7
00007aa9b5fe0848  vmovaps [rsp+0x80], xmm8
00007aa9b5fe0851  vmovaps [rsp+0x90], xmm9
00007aa9b5fe085a  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe0863  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe086c  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe0875  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe087e  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe0887  sub rsp, 0x30
00007aa9b5fe088b  movaps [rsp], xmm14
00007aa9b5fe0890  movaps [rsp+0x10], xmm4
00007aa9b5fe0895  movaps [rsp+0x20], xmm3
00007aa9b5fe089a  lea rdi, [rsp]
00007aa9b5fe089e  mov esi, 0x00
00007aa9b5fe08a3  mov rax, 0x63E0217C9530
00007aa9b5fe08ad  call rax
00007aa9b5fe08af  movaps xmm14, [rsp]
00007aa9b5fe08b4  add rsp, 0x30
00007aa9b5fe08b8  vmovaps xmm0, [rsp]
00007aa9b5fe08bd  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe08c3  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe08c9  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe08cf  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe08d5  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe08db  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe08e1  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe08e7  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe08f0  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe08f9  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe0902  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe090b  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe0914  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe091d  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe0926  add rsp, 0xF0
00007aa9b5fe092d  pop r11
00007aa9b5fe092f  pop r10
00007aa9b5fe0931  pop r9
00007aa9b5fe0933  pop r8
00007aa9b5fe0935  pop rsi
00007aa9b5fe0936  pop rdi
00007aa9b5fe0937  pop rdx
00007aa9b5fe0938  pop rcx
00007aa9b5fe0939  pop rax
00007aa9b5fe093a  add rsp, 0x08
00007aa9b5fe093e  jmp 0x00007AA9B5FDF022
00007aa9b5fe0943  sub rsp, 0x08
00007aa9b5fe0947  push rax
00007aa9b5fe0948  push rcx
00007aa9b5fe0949  push rdx
00007aa9b5fe094a  push rdi
00007aa9b5fe094b  push rsi
00007aa9b5fe094c  push r8
00007aa9b5fe094e  push r9
00007aa9b5fe0950  push r10
00007aa9b5fe0952  push r11
00007aa9b5fe0954  sub rsp, 0xF0
00007aa9b5fe095b  vmovaps [rsp], xmm0
00007aa9b5fe0960  vmovaps [rsp+0x10], xmm1
00007aa9b5fe0966  vmovaps [rsp+0x20], xmm2
00007aa9b5fe096c  vmovaps [rsp+0x30], xmm3
00007aa9b5fe0972  vmovaps [rsp+0x40], xmm4
00007aa9b5fe0978  vmovaps [rsp+0x50], xmm5
00007aa9b5fe097e  vmovaps [rsp+0x60], xmm7
00007aa9b5fe0984  vmovaps [rsp+0x70], xmm8
00007aa9b5fe098a  vmovaps [rsp+0x80], xmm9
00007aa9b5fe0993  vmovaps [rsp+0x90], xmm10
00007aa9b5fe099c  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe09a5  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe09ae  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe09b7  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe09c0  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe09c9  sub rsp, 0x30
00007aa9b5fe09cd  movaps [rsp], xmm6
00007aa9b5fe09d1  movaps [rsp+0x10], xmm9
00007aa9b5fe09d7  movaps [rsp+0x20], xmm7
00007aa9b5fe09dc  lea rdi, [rsp]
00007aa9b5fe09e0  mov esi, 0x00
00007aa9b5fe09e5  mov rax, 0x63E0217C9530
00007aa9b5fe09ef  call rax
00007aa9b5fe09f1  movaps xmm6, [rsp]
00007aa9b5fe09f5  add rsp, 0x30
00007aa9b5fe09f9  vmovaps xmm0, [rsp]
00007aa9b5fe09fe  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe0a04  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe0a0a  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe0a10  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe0a16  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe0a1c  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe0a22  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe0a28  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe0a31  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0a3a  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0a43  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe0a4c  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe0a55  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe0a5e  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe0a67  add rsp, 0xF0
00007aa9b5fe0a6e  pop r11
00007aa9b5fe0a70  pop r10
00007aa9b5fe0a72  pop r9
00007aa9b5fe0a74  pop r8
00007aa9b5fe0a76  pop rsi
00007aa9b5fe0a77  pop rdi
00007aa9b5fe0a78  pop rdx
00007aa9b5fe0a79  pop rcx
00007aa9b5fe0a7a  pop rax
00007aa9b5fe0a7b  add rsp, 0x08
00007aa9b5fe0a7f  jmp 0x00007AA9B5FDF03A
00007aa9b5fe0a84  sub rsp, 0x08
00007aa9b5fe0a88  push rax
00007aa9b5fe0a89  push rcx
00007aa9b5fe0a8a  push rdx
00007aa9b5fe0a8b  push rdi
00007aa9b5fe0a8c  push rsi
00007aa9b5fe0a8d  push r8
00007aa9b5fe0a8f  push r9
00007aa9b5fe0a91  push r10
00007aa9b5fe0a93  push r11
00007aa9b5fe0a95  sub rsp, 0xF0
00007aa9b5fe0a9c  vmovaps [rsp], xmm0
00007aa9b5fe0aa1  vmovaps [rsp+0x10], xmm1
00007aa9b5fe0aa7  vmovaps [rsp+0x20], xmm2
00007aa9b5fe0aad  vmovaps [rsp+0x30], xmm3
00007aa9b5fe0ab3  vmovaps [rsp+0x40], xmm4
00007aa9b5fe0ab9  vmovaps [rsp+0x50], xmm5
00007aa9b5fe0abf  vmovaps [rsp+0x60], xmm6
00007aa9b5fe0ac5  vmovaps [rsp+0x70], xmm8
00007aa9b5fe0acb  vmovaps [rsp+0x80], xmm9
00007aa9b5fe0ad4  vmovaps [rsp+0x90], xmm10
00007aa9b5fe0add  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe0ae6  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe0aef  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe0af8  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe0b01  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe0b0a  sub rsp, 0x30
00007aa9b5fe0b0e  movaps [rsp], xmm7
00007aa9b5fe0b12  movaps [rsp+0x10], xmm4
00007aa9b5fe0b17  movaps [rsp+0x20], xmm9
00007aa9b5fe0b1d  lea rdi, [rsp]
00007aa9b5fe0b21  mov esi, 0x00
00007aa9b5fe0b26  mov rax, 0x63E0217C9530
00007aa9b5fe0b30  call rax
00007aa9b5fe0b32  movaps xmm7, [rsp]
00007aa9b5fe0b36  add rsp, 0x30
00007aa9b5fe0b3a  vmovaps xmm0, [rsp]
00007aa9b5fe0b3f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe0b45  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe0b4b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe0b51  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe0b57  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe0b5d  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe0b63  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe0b69  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe0b72  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0b7b  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0b84  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe0b8d  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe0b96  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe0b9f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe0ba8  add rsp, 0xF0
00007aa9b5fe0baf  pop r11
00007aa9b5fe0bb1  pop r10
00007aa9b5fe0bb3  pop r9
00007aa9b5fe0bb5  pop r8
00007aa9b5fe0bb7  pop rsi
00007aa9b5fe0bb8  pop rdi
00007aa9b5fe0bb9  pop rdx
00007aa9b5fe0bba  pop rcx
00007aa9b5fe0bbb  pop rax
00007aa9b5fe0bbc  add rsp, 0x08
00007aa9b5fe0bc0  jmp 0x00007AA9B5FDF067
00007aa9b5fe0bc5  sub rsp, 0x08
00007aa9b5fe0bc9  push rax
00007aa9b5fe0bca  push rcx
00007aa9b5fe0bcb  push rdx
00007aa9b5fe0bcc  push rdi
00007aa9b5fe0bcd  push rsi
00007aa9b5fe0bce  push r8
00007aa9b5fe0bd0  push r9
00007aa9b5fe0bd2  push r10
00007aa9b5fe0bd4  push r11
00007aa9b5fe0bd6  sub rsp, 0xF0
00007aa9b5fe0bdd  vmovaps [rsp], xmm0
00007aa9b5fe0be2  vmovaps [rsp+0x10], xmm1
00007aa9b5fe0be8  vmovaps [rsp+0x20], xmm2
00007aa9b5fe0bee  vmovaps [rsp+0x30], xmm3
00007aa9b5fe0bf4  vmovaps [rsp+0x40], xmm5
00007aa9b5fe0bfa  vmovaps [rsp+0x50], xmm6
00007aa9b5fe0c00  vmovaps [rsp+0x60], xmm7
00007aa9b5fe0c06  vmovaps [rsp+0x70], xmm8
00007aa9b5fe0c0c  vmovaps [rsp+0x80], xmm9
00007aa9b5fe0c15  vmovaps [rsp+0x90], xmm10
00007aa9b5fe0c1e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe0c27  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe0c30  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe0c39  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe0c42  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe0c4b  sub rsp, 0x30
00007aa9b5fe0c4f  movaps [rsp], xmm4
00007aa9b5fe0c53  movaps [rsp+0x10], xmm15
00007aa9b5fe0c59  movaps [rsp+0x20], xmm9
00007aa9b5fe0c5f  lea rdi, [rsp]
00007aa9b5fe0c63  mov esi, 0x00
00007aa9b5fe0c68  mov rax, 0x63E0217C9530
00007aa9b5fe0c72  call rax
00007aa9b5fe0c74  movaps xmm4, [rsp]
00007aa9b5fe0c78  add rsp, 0x30
00007aa9b5fe0c7c  vmovaps xmm0, [rsp]
00007aa9b5fe0c81  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe0c87  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe0c8d  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe0c93  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe0c99  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe0c9f  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe0ca5  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe0cab  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe0cb4  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0cbd  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0cc6  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe0ccf  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe0cd8  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe0ce1  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe0cea  add rsp, 0xF0
00007aa9b5fe0cf1  pop r11
00007aa9b5fe0cf3  pop r10
00007aa9b5fe0cf5  pop r9
00007aa9b5fe0cf7  pop r8
00007aa9b5fe0cf9  pop rsi
00007aa9b5fe0cfa  pop rdi
00007aa9b5fe0cfb  pop rdx
00007aa9b5fe0cfc  pop rcx
00007aa9b5fe0cfd  pop rax
00007aa9b5fe0cfe  add rsp, 0x08
00007aa9b5fe0d02  jmp 0x00007AA9B5FDF08C
00007aa9b5fe0d07  call 0x00007AA9B5EC4620
00007aa9b5fe0d0c  jmp 0x00007AA9B5FDF099
00007aa9b5fe0d11  sub rsp, 0x08
00007aa9b5fe0d15  push rax
00007aa9b5fe0d16  push rcx
00007aa9b5fe0d17  push rdx
00007aa9b5fe0d18  push rdi
00007aa9b5fe0d19  push rsi
00007aa9b5fe0d1a  push r8
00007aa9b5fe0d1c  push r9
00007aa9b5fe0d1e  push r10
00007aa9b5fe0d20  push r11
00007aa9b5fe0d22  sub rsp, 0xF0
00007aa9b5fe0d29  vmovaps [rsp], xmm0
00007aa9b5fe0d2e  vmovaps [rsp+0x10], xmm1
00007aa9b5fe0d34  vmovaps [rsp+0x20], xmm2
00007aa9b5fe0d3a  vmovaps [rsp+0x30], xmm4
00007aa9b5fe0d40  vmovaps [rsp+0x40], xmm5
00007aa9b5fe0d46  vmovaps [rsp+0x50], xmm6
00007aa9b5fe0d4c  vmovaps [rsp+0x60], xmm7
00007aa9b5fe0d52  vmovaps [rsp+0x70], xmm8
00007aa9b5fe0d58  vmovaps [rsp+0x80], xmm9
00007aa9b5fe0d61  vmovaps [rsp+0x90], xmm10
00007aa9b5fe0d6a  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe0d73  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe0d7c  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe0d85  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe0d8e  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe0d97  sub rsp, 0x30
00007aa9b5fe0d9b  movaps [rsp], xmm3
00007aa9b5fe0d9f  movaps [rsp+0x10], xmm1
00007aa9b5fe0da4  movaps [rsp+0x20], xmm9
00007aa9b5fe0daa  lea rdi, [rsp]
00007aa9b5fe0dae  mov esi, 0x00
00007aa9b5fe0db3  mov rax, 0x63E0217C9530
00007aa9b5fe0dbd  call rax
00007aa9b5fe0dbf  movaps xmm3, [rsp]
00007aa9b5fe0dc3  add rsp, 0x30
00007aa9b5fe0dc7  vmovaps xmm0, [rsp]
00007aa9b5fe0dcc  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe0dd2  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe0dd8  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe0dde  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe0de4  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe0dea  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe0df0  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe0df6  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe0dff  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0e08  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0e11  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe0e1a  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe0e23  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe0e2c  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe0e35  add rsp, 0xF0
00007aa9b5fe0e3c  pop r11
00007aa9b5fe0e3e  pop r10
00007aa9b5fe0e40  pop r9
00007aa9b5fe0e42  pop r8
00007aa9b5fe0e44  pop rsi
00007aa9b5fe0e45  pop rdi
00007aa9b5fe0e46  pop rdx
00007aa9b5fe0e47  pop rcx
00007aa9b5fe0e48  pop rax
00007aa9b5fe0e49  add rsp, 0x08
00007aa9b5fe0e4d  jmp 0x00007AA9B5FDF0D6
00007aa9b5fe0e52  sub rsp, 0x08
00007aa9b5fe0e56  push rax
00007aa9b5fe0e57  push rcx
00007aa9b5fe0e58  push rdx
00007aa9b5fe0e59  push rdi
00007aa9b5fe0e5a  push rsi
00007aa9b5fe0e5b  push r8
00007aa9b5fe0e5d  push r9
00007aa9b5fe0e5f  push r10
00007aa9b5fe0e61  push r11
00007aa9b5fe0e63  sub rsp, 0xF0
00007aa9b5fe0e6a  vmovaps [rsp], xmm0
00007aa9b5fe0e6f  vmovaps [rsp+0x10], xmm2
00007aa9b5fe0e75  vmovaps [rsp+0x20], xmm3
00007aa9b5fe0e7b  vmovaps [rsp+0x30], xmm4
00007aa9b5fe0e81  vmovaps [rsp+0x40], xmm5
00007aa9b5fe0e87  vmovaps [rsp+0x50], xmm6
00007aa9b5fe0e8d  vmovaps [rsp+0x60], xmm7
00007aa9b5fe0e93  vmovaps [rsp+0x70], xmm8
00007aa9b5fe0e99  vmovaps [rsp+0x80], xmm9
00007aa9b5fe0ea2  vmovaps [rsp+0x90], xmm10
00007aa9b5fe0eab  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe0eb4  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe0ebd  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe0ec6  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe0ecf  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe0ed8  sub rsp, 0x30
00007aa9b5fe0edc  movaps [rsp], xmm1
00007aa9b5fe0ee0  movaps [rsp+0x10], xmm15
00007aa9b5fe0ee6  movaps [rsp+0x20], xmm9
00007aa9b5fe0eec  lea rdi, [rsp]
00007aa9b5fe0ef0  mov esi, 0x00
00007aa9b5fe0ef5  mov rax, 0x63E0217C9530
00007aa9b5fe0eff  call rax
00007aa9b5fe0f01  movaps xmm1, [rsp]
00007aa9b5fe0f05  add rsp, 0x30
00007aa9b5fe0f09  vmovaps xmm0, [rsp]
00007aa9b5fe0f0e  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe0f14  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe0f1a  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe0f20  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe0f26  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe0f2c  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe0f32  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe0f38  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe0f41  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe0f4a  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe0f53  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe0f5c  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe0f65  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe0f6e  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe0f77  add rsp, 0xF0
00007aa9b5fe0f7e  pop r11
00007aa9b5fe0f80  pop r10
00007aa9b5fe0f82  pop r9
00007aa9b5fe0f84  pop r8
00007aa9b5fe0f86  pop rsi
00007aa9b5fe0f87  pop rdi
00007aa9b5fe0f88  pop rdx
00007aa9b5fe0f89  pop rcx
00007aa9b5fe0f8a  pop rax
00007aa9b5fe0f8b  add rsp, 0x08
00007aa9b5fe0f8f  jmp 0x00007AA9B5FDF15E
00007aa9b5fe0f94  call 0x00007AA9B5EC4620
00007aa9b5fe0f99  jmp 0x00007AA9B5FDF16B
00007aa9b5fe0f9e  sub rsp, 0x08
00007aa9b5fe0fa2  push rax
00007aa9b5fe0fa3  push rcx
00007aa9b5fe0fa4  push rdx
00007aa9b5fe0fa5  push rdi
00007aa9b5fe0fa6  push rsi
00007aa9b5fe0fa7  push r8
00007aa9b5fe0fa9  push r9
00007aa9b5fe0fab  push r10
00007aa9b5fe0fad  push r11
00007aa9b5fe0faf  sub rsp, 0xF0
00007aa9b5fe0fb6  vmovaps [rsp], xmm0
00007aa9b5fe0fbb  vmovaps [rsp+0x10], xmm2
00007aa9b5fe0fc1  vmovaps [rsp+0x20], xmm3
00007aa9b5fe0fc7  vmovaps [rsp+0x30], xmm4
00007aa9b5fe0fcd  vmovaps [rsp+0x40], xmm5
00007aa9b5fe0fd3  vmovaps [rsp+0x50], xmm6
00007aa9b5fe0fd9  vmovaps [rsp+0x60], xmm7
00007aa9b5fe0fdf  vmovaps [rsp+0x70], xmm8
00007aa9b5fe0fe5  vmovaps [rsp+0x80], xmm9
00007aa9b5fe0fee  vmovaps [rsp+0x90], xmm10
00007aa9b5fe0ff7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe1000  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe1009  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe1012  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe101b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe1024  sub rsp, 0x30
00007aa9b5fe1028  movaps [rsp], xmm1
00007aa9b5fe102c  movaps [rsp+0x10], xmm5
00007aa9b5fe1031  movaps [rsp+0x20], xmm7
00007aa9b5fe1036  lea rdi, [rsp]
00007aa9b5fe103a  mov esi, 0x00
00007aa9b5fe103f  mov rax, 0x63E0217C9530
00007aa9b5fe1049  call rax
00007aa9b5fe104b  movaps xmm1, [rsp]
00007aa9b5fe104f  add rsp, 0x30
00007aa9b5fe1053  vmovaps xmm0, [rsp]
00007aa9b5fe1058  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe105e  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe1064  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe106a  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe1070  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe1076  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe107c  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe1082  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe108b  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe1094  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe109d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe10a6  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe10af  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe10b8  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe10c1  add rsp, 0xF0
00007aa9b5fe10c8  pop r11
00007aa9b5fe10ca  pop r10
00007aa9b5fe10cc  pop r9
00007aa9b5fe10ce  pop r8
00007aa9b5fe10d0  pop rsi
00007aa9b5fe10d1  pop rdi
00007aa9b5fe10d2  pop rdx
00007aa9b5fe10d3  pop rcx
00007aa9b5fe10d4  pop rax
00007aa9b5fe10d5  add rsp, 0x08
00007aa9b5fe10d9  jmp 0x00007AA9B5FDF210
00007aa9b5fe10de  sub rsp, 0x08
00007aa9b5fe10e2  push rax
00007aa9b5fe10e3  push rcx
00007aa9b5fe10e4  push rdx
00007aa9b5fe10e5  push rdi
00007aa9b5fe10e6  push rsi
00007aa9b5fe10e7  push r8
00007aa9b5fe10e9  push r9
00007aa9b5fe10eb  push r10
00007aa9b5fe10ed  push r11
00007aa9b5fe10ef  sub rsp, 0xF0
00007aa9b5fe10f6  vmovaps [rsp], xmm0
00007aa9b5fe10fb  vmovaps [rsp+0x10], xmm1
00007aa9b5fe1101  vmovaps [rsp+0x20], xmm2
00007aa9b5fe1107  vmovaps [rsp+0x30], xmm3
00007aa9b5fe110d  vmovaps [rsp+0x40], xmm4
00007aa9b5fe1113  vmovaps [rsp+0x50], xmm5
00007aa9b5fe1119  vmovaps [rsp+0x60], xmm6
00007aa9b5fe111f  vmovaps [rsp+0x70], xmm8
00007aa9b5fe1125  vmovaps [rsp+0x80], xmm9
00007aa9b5fe112e  vmovaps [rsp+0x90], xmm10
00007aa9b5fe1137  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe1140  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe1149  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe1152  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe115b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe1164  sub rsp, 0x30
00007aa9b5fe1168  movaps [rsp], xmm7
00007aa9b5fe116c  movaps [rsp+0x10], xmm5
00007aa9b5fe1171  movaps [rsp+0x20], xmm15
00007aa9b5fe1177  lea rdi, [rsp]
00007aa9b5fe117b  mov esi, 0x00
00007aa9b5fe1180  mov rax, 0x63E0217C9530
00007aa9b5fe118a  call rax
00007aa9b5fe118c  movaps xmm7, [rsp]
00007aa9b5fe1190  add rsp, 0x30
00007aa9b5fe1194  vmovaps xmm0, [rsp]
00007aa9b5fe1199  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe119f  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe11a5  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe11ab  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe11b1  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe11b7  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe11bd  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe11c3  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe11cc  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe11d5  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe11de  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe11e7  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe11f0  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe11f9  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe1202  add rsp, 0xF0
00007aa9b5fe1209  pop r11
00007aa9b5fe120b  pop r10
00007aa9b5fe120d  pop r9
00007aa9b5fe120f  pop r8
00007aa9b5fe1211  pop rsi
00007aa9b5fe1212  pop rdi
00007aa9b5fe1213  pop rdx
00007aa9b5fe1214  pop rcx
00007aa9b5fe1215  pop rax
00007aa9b5fe1216  add rsp, 0x08
00007aa9b5fe121a  jmp 0x00007AA9B5FDF246
00007aa9b5fe121f  call 0x00007AA9B5EB52F0
00007aa9b5fe1224  jmp 0x00007AA9B5FDF253
00007aa9b5fe1229  sub rsp, 0x08
00007aa9b5fe122d  push rax
00007aa9b5fe122e  push rcx
00007aa9b5fe122f  push rdx
00007aa9b5fe1230  push rdi
00007aa9b5fe1231  push rsi
00007aa9b5fe1232  push r8
00007aa9b5fe1234  push r9
00007aa9b5fe1236  push r10
00007aa9b5fe1238  push r11
00007aa9b5fe123a  sub rsp, 0xF0
00007aa9b5fe1241  vmovaps [rsp], xmm0
00007aa9b5fe1246  vmovaps [rsp+0x10], xmm1
00007aa9b5fe124c  vmovaps [rsp+0x20], xmm2
00007aa9b5fe1252  vmovaps [rsp+0x30], xmm3
00007aa9b5fe1258  vmovaps [rsp+0x40], xmm4
00007aa9b5fe125e  vmovaps [rsp+0x50], xmm5
00007aa9b5fe1264  vmovaps [rsp+0x60], xmm6
00007aa9b5fe126a  vmovaps [rsp+0x70], xmm7
00007aa9b5fe1270  vmovaps [rsp+0x80], xmm8
00007aa9b5fe1279  vmovaps [rsp+0x90], xmm9
00007aa9b5fe1282  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe128b  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe1294  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe129d  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe12a6  vmovaps [rsp+0xE0], xmm14
00007aa9b5fe12af  sub rsp, 0x30
00007aa9b5fe12b3  movaps [rsp], xmm15
00007aa9b5fe12b8  movaps [rsp+0x10], xmm5
00007aa9b5fe12bd  movaps [rsp+0x20], xmm3
00007aa9b5fe12c2  lea rdi, [rsp]
00007aa9b5fe12c6  mov esi, 0x00
00007aa9b5fe12cb  mov rax, 0x63E0217C9530
00007aa9b5fe12d5  call rax
00007aa9b5fe12d7  movaps xmm15, [rsp]
00007aa9b5fe12dc  add rsp, 0x30
00007aa9b5fe12e0  vmovaps xmm0, [rsp]
00007aa9b5fe12e5  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe12eb  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe12f1  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe12f7  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe12fd  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe1303  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe1309  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe130f  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe1318  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe1321  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe132a  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe1333  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe133c  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe1345  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fe134e  add rsp, 0xF0
00007aa9b5fe1355  pop r11
00007aa9b5fe1357  pop r10
00007aa9b5fe1359  pop r9
00007aa9b5fe135b  pop r8
00007aa9b5fe135d  pop rsi
00007aa9b5fe135e  pop rdi
00007aa9b5fe135f  pop rdx
00007aa9b5fe1360  pop rcx
00007aa9b5fe1361  pop rax
00007aa9b5fe1362  add rsp, 0x08
00007aa9b5fe1366  jmp 0x00007AA9B5FDF279
00007aa9b5fe136b  sub rsp, 0x08
00007aa9b5fe136f  push rax
00007aa9b5fe1370  push rcx
00007aa9b5fe1371  push rdx
00007aa9b5fe1372  push rdi
00007aa9b5fe1373  push rsi
00007aa9b5fe1374  push r8
00007aa9b5fe1376  push r9
00007aa9b5fe1378  push r10
00007aa9b5fe137a  push r11
00007aa9b5fe137c  sub rsp, 0xF0
00007aa9b5fe1383  vmovaps [rsp], xmm0
00007aa9b5fe1388  vmovaps [rsp+0x10], xmm2
00007aa9b5fe138e  vmovaps [rsp+0x20], xmm3
00007aa9b5fe1394  vmovaps [rsp+0x30], xmm4
00007aa9b5fe139a  vmovaps [rsp+0x40], xmm5
00007aa9b5fe13a0  vmovaps [rsp+0x50], xmm6
00007aa9b5fe13a6  vmovaps [rsp+0x60], xmm7
00007aa9b5fe13ac  vmovaps [rsp+0x70], xmm8
00007aa9b5fe13b2  vmovaps [rsp+0x80], xmm9
00007aa9b5fe13bb  vmovaps [rsp+0x90], xmm10
00007aa9b5fe13c4  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe13cd  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe13d6  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe13df  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe13e8  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe13f1  sub rsp, 0x30
00007aa9b5fe13f5  movaps [rsp], xmm1
00007aa9b5fe13f9  movaps [rsp+0x10], xmm5
00007aa9b5fe13fe  movaps [rsp+0x20], xmm4
00007aa9b5fe1403  lea rdi, [rsp]
00007aa9b5fe1407  mov esi, 0x00
00007aa9b5fe140c  mov rax, 0x63E0217C9530
00007aa9b5fe1416  call rax
00007aa9b5fe1418  movaps xmm1, [rsp]
00007aa9b5fe141c  add rsp, 0x30
00007aa9b5fe1420  vmovaps xmm0, [rsp]
00007aa9b5fe1425  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe142b  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe1431  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe1437  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe143d  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe1443  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe1449  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe144f  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe1458  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe1461  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe146a  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe1473  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe147c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe1485  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe148e  add rsp, 0xF0
00007aa9b5fe1495  pop r11
00007aa9b5fe1497  pop r10
00007aa9b5fe1499  pop r9
00007aa9b5fe149b  pop r8
00007aa9b5fe149d  pop rsi
00007aa9b5fe149e  pop rdi
00007aa9b5fe149f  pop rdx
00007aa9b5fe14a0  pop rcx
00007aa9b5fe14a1  pop rax
00007aa9b5fe14a2  add rsp, 0x08
00007aa9b5fe14a6  jmp 0x00007AA9B5FDF299
00007aa9b5fe14ab  sub rsp, 0x08
00007aa9b5fe14af  push rax
00007aa9b5fe14b0  push rcx
00007aa9b5fe14b1  push rdx
00007aa9b5fe14b2  push rdi
00007aa9b5fe14b3  push rsi
00007aa9b5fe14b4  push r8
00007aa9b5fe14b6  push r9
00007aa9b5fe14b8  push r10
00007aa9b5fe14ba  push r11
00007aa9b5fe14bc  sub rsp, 0xF0
00007aa9b5fe14c3  vmovaps [rsp], xmm0
00007aa9b5fe14c8  vmovaps [rsp+0x10], xmm1
00007aa9b5fe14ce  vmovaps [rsp+0x20], xmm2
00007aa9b5fe14d4  vmovaps [rsp+0x30], xmm3
00007aa9b5fe14da  vmovaps [rsp+0x40], xmm5
00007aa9b5fe14e0  vmovaps [rsp+0x50], xmm6
00007aa9b5fe14e6  vmovaps [rsp+0x60], xmm7
00007aa9b5fe14ec  vmovaps [rsp+0x70], xmm8
00007aa9b5fe14f2  vmovaps [rsp+0x80], xmm9
00007aa9b5fe14fb  vmovaps [rsp+0x90], xmm10
00007aa9b5fe1504  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe150d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe1516  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe151f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe1528  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe1531  sub rsp, 0x30
00007aa9b5fe1535  movaps [rsp], xmm4
00007aa9b5fe1539  movaps [rsp+0x10], xmm3
00007aa9b5fe153e  movaps [rsp+0x20], xmm5
00007aa9b5fe1543  lea rdi, [rsp]
00007aa9b5fe1547  mov esi, 0x00
00007aa9b5fe154c  mov rax, 0x63E0217C9530
00007aa9b5fe1556  call rax
00007aa9b5fe1558  movaps xmm4, [rsp]
00007aa9b5fe155c  add rsp, 0x30
00007aa9b5fe1560  vmovaps xmm0, [rsp]
00007aa9b5fe1565  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe156b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe1571  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe1577  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe157d  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe1583  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe1589  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe158f  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe1598  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe15a1  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe15aa  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe15b3  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe15bc  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe15c5  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe15ce  add rsp, 0xF0
00007aa9b5fe15d5  pop r11
00007aa9b5fe15d7  pop r10
00007aa9b5fe15d9  pop r9
00007aa9b5fe15db  pop r8
00007aa9b5fe15dd  pop rsi
00007aa9b5fe15de  pop rdi
00007aa9b5fe15df  pop rdx
00007aa9b5fe15e0  pop rcx
00007aa9b5fe15e1  pop rax
00007aa9b5fe15e2  add rsp, 0x08
00007aa9b5fe15e6  jmp 0x00007AA9B5FDF2E7
00007aa9b5fe15eb  call 0x00007AA9B5EB52F0
00007aa9b5fe15f0  jmp 0x00007AA9B5FDF2F4
00007aa9b5fe15f5  sub rsp, 0x08
00007aa9b5fe15f9  push rax
00007aa9b5fe15fa  push rcx
00007aa9b5fe15fb  push rdx
00007aa9b5fe15fc  push rdi
00007aa9b5fe15fd  push rsi
00007aa9b5fe15fe  push r8
00007aa9b5fe1600  push r9
00007aa9b5fe1602  push r10
00007aa9b5fe1604  push r11
00007aa9b5fe1606  sub rsp, 0xF0
00007aa9b5fe160d  vmovaps [rsp], xmm0
00007aa9b5fe1612  vmovaps [rsp+0x10], xmm1
00007aa9b5fe1618  vmovaps [rsp+0x20], xmm2
00007aa9b5fe161e  vmovaps [rsp+0x30], xmm3
00007aa9b5fe1624  vmovaps [rsp+0x40], xmm4
00007aa9b5fe162a  vmovaps [rsp+0x50], xmm6
00007aa9b5fe1630  vmovaps [rsp+0x60], xmm7
00007aa9b5fe1636  vmovaps [rsp+0x70], xmm8
00007aa9b5fe163c  vmovaps [rsp+0x80], xmm9
00007aa9b5fe1645  vmovaps [rsp+0x90], xmm10
00007aa9b5fe164e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe1657  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe1660  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe1669  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe1672  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe167b  sub rsp, 0x30
00007aa9b5fe167f  movaps [rsp], xmm5
00007aa9b5fe1683  movaps [rsp+0x10], xmm6
00007aa9b5fe1688  movaps [rsp+0x20], xmm3
00007aa9b5fe168d  lea rdi, [rsp]
00007aa9b5fe1691  mov esi, 0x00
00007aa9b5fe1696  mov rax, 0x63E0217C9530
00007aa9b5fe16a0  call rax
00007aa9b5fe16a2  movaps xmm5, [rsp]
00007aa9b5fe16a6  add rsp, 0x30
00007aa9b5fe16aa  vmovaps xmm0, [rsp]
00007aa9b5fe16af  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe16b5  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe16bb  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe16c1  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe16c7  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe16cd  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe16d3  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe16d9  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe16e2  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe16eb  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe16f4  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe16fd  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe1706  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe170f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe1718  add rsp, 0xF0
00007aa9b5fe171f  pop r11
00007aa9b5fe1721  pop r10
00007aa9b5fe1723  pop r9
00007aa9b5fe1725  pop r8
00007aa9b5fe1727  pop rsi
00007aa9b5fe1728  pop rdi
00007aa9b5fe1729  pop rdx
00007aa9b5fe172a  pop rcx
00007aa9b5fe172b  pop rax
00007aa9b5fe172c  add rsp, 0x08
00007aa9b5fe1730  jmp 0x00007AA9B5FDF31A
00007aa9b5fe1735  sub rsp, 0x08
00007aa9b5fe1739  push rax
00007aa9b5fe173a  push rcx
00007aa9b5fe173b  push rdx
00007aa9b5fe173c  push rdi
00007aa9b5fe173d  push rsi
00007aa9b5fe173e  push r8
00007aa9b5fe1740  push r9
00007aa9b5fe1742  push r10
00007aa9b5fe1744  push r11
00007aa9b5fe1746  sub rsp, 0xF0
00007aa9b5fe174d  vmovaps [rsp], xmm0
00007aa9b5fe1752  vmovaps [rsp+0x10], xmm1
00007aa9b5fe1758  vmovaps [rsp+0x20], xmm2
00007aa9b5fe175e  vmovaps [rsp+0x30], xmm3
00007aa9b5fe1764  vmovaps [rsp+0x40], xmm4
00007aa9b5fe176a  vmovaps [rsp+0x50], xmm5
00007aa9b5fe1770  vmovaps [rsp+0x60], xmm7
00007aa9b5fe1776  vmovaps [rsp+0x70], xmm8
00007aa9b5fe177c  vmovaps [rsp+0x80], xmm9
00007aa9b5fe1785  vmovaps [rsp+0x90], xmm10
00007aa9b5fe178e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe1797  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe17a0  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe17a9  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe17b2  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe17bb  sub rsp, 0x30
00007aa9b5fe17bf  movaps [rsp], xmm6
00007aa9b5fe17c3  movaps [rsp+0x10], xmm9
00007aa9b5fe17c9  movaps [rsp+0x20], xmm1
00007aa9b5fe17ce  lea rdi, [rsp]
00007aa9b5fe17d2  mov esi, 0x00
00007aa9b5fe17d7  mov rax, 0x63E0217C9530
00007aa9b5fe17e1  call rax
00007aa9b5fe17e3  movaps xmm6, [rsp]
00007aa9b5fe17e7  add rsp, 0x30
00007aa9b5fe17eb  vmovaps xmm0, [rsp]
00007aa9b5fe17f0  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe17f6  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe17fc  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe1802  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe1808  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe180e  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe1814  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe181a  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe1823  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe182c  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe1835  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe183e  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe1847  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe1850  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe1859  add rsp, 0xF0
00007aa9b5fe1860  pop r11
00007aa9b5fe1862  pop r10
00007aa9b5fe1864  pop r9
00007aa9b5fe1866  pop r8
00007aa9b5fe1868  pop rsi
00007aa9b5fe1869  pop rdi
00007aa9b5fe186a  pop rdx
00007aa9b5fe186b  pop rcx
00007aa9b5fe186c  pop rax
00007aa9b5fe186d  add rsp, 0x08
00007aa9b5fe1871  jmp 0x00007AA9B5FDF33E
00007aa9b5fe1876  sub rsp, 0x08
00007aa9b5fe187a  push rax
00007aa9b5fe187b  push rcx
00007aa9b5fe187c  push rdx
00007aa9b5fe187d  push rdi
00007aa9b5fe187e  push rsi
00007aa9b5fe187f  push r8
00007aa9b5fe1881  push r9
00007aa9b5fe1883  push r10
00007aa9b5fe1885  push r11
00007aa9b5fe1887  sub rsp, 0xF0
00007aa9b5fe188e  vmovaps [rsp], xmm0
00007aa9b5fe1893  vmovaps [rsp+0x10], xmm1
00007aa9b5fe1899  vmovaps [rsp+0x20], xmm2
00007aa9b5fe189f  vmovaps [rsp+0x30], xmm3
00007aa9b5fe18a5  vmovaps [rsp+0x40], xmm4
00007aa9b5fe18ab  vmovaps [rsp+0x50], xmm5
00007aa9b5fe18b1  vmovaps [rsp+0x60], xmm6
00007aa9b5fe18b7  vmovaps [rsp+0x70], xmm7
00007aa9b5fe18bd  vmovaps [rsp+0x80], xmm8
00007aa9b5fe18c6  vmovaps [rsp+0x90], xmm10
00007aa9b5fe18cf  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe18d8  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe18e1  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe18ea  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe18f3  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe18fc  sub rsp, 0x30
00007aa9b5fe1900  movaps [rsp], xmm9
00007aa9b5fe1905  movaps [rsp+0x10], xmm3
00007aa9b5fe190a  movaps [rsp+0x20], xmm1
00007aa9b5fe190f  lea rdi, [rsp]
00007aa9b5fe1913  mov esi, 0x00
00007aa9b5fe1918  mov rax, 0x63E0217C9530
00007aa9b5fe1922  call rax
00007aa9b5fe1924  movaps xmm9, [rsp]
00007aa9b5fe1929  add rsp, 0x30
00007aa9b5fe192d  vmovaps xmm0, [rsp]
00007aa9b5fe1932  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe1938  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe193e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe1944  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe194a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe1950  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe1956  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe195c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe1965  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe196e  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe1977  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe1980  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe1989  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe1992  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe199b  add rsp, 0xF0
00007aa9b5fe19a2  pop r11
00007aa9b5fe19a4  pop r10
00007aa9b5fe19a6  pop r9
00007aa9b5fe19a8  pop r8
00007aa9b5fe19aa  pop rsi
00007aa9b5fe19ab  pop rdi
00007aa9b5fe19ac  pop rdx
00007aa9b5fe19ad  pop rcx
00007aa9b5fe19ae  pop rax
00007aa9b5fe19af  add rsp, 0x08
00007aa9b5fe19b3  jmp 0x00007AA9B5FDF38A
00007aa9b5fe19b8  call 0x00007AA9B5EB52F0
00007aa9b5fe19bd  jmp 0x00007AA9B5FDF397
00007aa9b5fe19c2  sub rsp, 0x08
00007aa9b5fe19c6  push rax
00007aa9b5fe19c7  push rcx
00007aa9b5fe19c8  push rdx
00007aa9b5fe19c9  push rdi
00007aa9b5fe19ca  push rsi
00007aa9b5fe19cb  push r8
00007aa9b5fe19cd  push r9
00007aa9b5fe19cf  push r10
00007aa9b5fe19d1  push r11
00007aa9b5fe19d3  sub rsp, 0xF0
00007aa9b5fe19da  vmovaps [rsp], xmm0
00007aa9b5fe19df  vmovaps [rsp+0x10], xmm1
00007aa9b5fe19e5  vmovaps [rsp+0x20], xmm2
00007aa9b5fe19eb  vmovaps [rsp+0x30], xmm3
00007aa9b5fe19f1  vmovaps [rsp+0x40], xmm4
00007aa9b5fe19f7  vmovaps [rsp+0x50], xmm5
00007aa9b5fe19fd  vmovaps [rsp+0x60], xmm6
00007aa9b5fe1a03  vmovaps [rsp+0x70], xmm7
00007aa9b5fe1a09  vmovaps [rsp+0x80], xmm8
00007aa9b5fe1a12  vmovaps [rsp+0x90], xmm9
00007aa9b5fe1a1b  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe1a24  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe1a2d  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe1a36  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe1a3f  vmovaps [rsp+0xE0], xmm14
00007aa9b5fe1a48  sub rsp, 0x30
00007aa9b5fe1a4c  movaps [rsp], xmm15
00007aa9b5fe1a51  movaps [rsp+0x10], xmm3
00007aa9b5fe1a56  movaps [rsp+0x20], xmm7
00007aa9b5fe1a5b  lea rdi, [rsp]
00007aa9b5fe1a5f  mov esi, 0x00
00007aa9b5fe1a64  mov rax, 0x63E0217C9530
00007aa9b5fe1a6e  call rax
00007aa9b5fe1a70  movaps xmm15, [rsp]
00007aa9b5fe1a75  add rsp, 0x30
00007aa9b5fe1a79  vmovaps xmm0, [rsp]
00007aa9b5fe1a7e  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe1a84  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe1a8a  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe1a90  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe1a96  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe1a9c  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe1aa2  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe1aa8  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe1ab1  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe1aba  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe1ac3  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe1acc  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe1ad5  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe1ade  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fe1ae7  add rsp, 0xF0
00007aa9b5fe1aee  pop r11
00007aa9b5fe1af0  pop r10
00007aa9b5fe1af2  pop r9
00007aa9b5fe1af4  pop r8
00007aa9b5fe1af6  pop rsi
00007aa9b5fe1af7  pop rdi
00007aa9b5fe1af8  pop rdx
00007aa9b5fe1af9  pop rcx
00007aa9b5fe1afa  pop rax
00007aa9b5fe1afb  add rsp, 0x08
00007aa9b5fe1aff  jmp 0x00007AA9B5FDF3C3
00007aa9b5fe1b04  sub rsp, 0x08
00007aa9b5fe1b08  push rax
00007aa9b5fe1b09  push rcx
00007aa9b5fe1b0a  push rdx
00007aa9b5fe1b0b  push rdi
00007aa9b5fe1b0c  push rsi
00007aa9b5fe1b0d  push r8
00007aa9b5fe1b0f  push r9
00007aa9b5fe1b11  push r10
00007aa9b5fe1b13  push r11
00007aa9b5fe1b15  sub rsp, 0xF0
00007aa9b5fe1b1c  vmovaps [rsp], xmm0
00007aa9b5fe1b21  vmovaps [rsp+0x10], xmm1
00007aa9b5fe1b27  vmovaps [rsp+0x20], xmm2
00007aa9b5fe1b2d  vmovaps [rsp+0x30], xmm4
00007aa9b5fe1b33  vmovaps [rsp+0x40], xmm5
00007aa9b5fe1b39  vmovaps [rsp+0x50], xmm6
00007aa9b5fe1b3f  vmovaps [rsp+0x60], xmm7
00007aa9b5fe1b45  vmovaps [rsp+0x70], xmm8
00007aa9b5fe1b4b  vmovaps [rsp+0x80], xmm9
00007aa9b5fe1b54  vmovaps [rsp+0x90], xmm10
00007aa9b5fe1b5d  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe1b66  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe1b6f  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe1b78  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe1b81  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe1b8a  sub rsp, 0x30
00007aa9b5fe1b8e  movaps [rsp], xmm3
00007aa9b5fe1b92  movaps [rsp+0x10], xmm1
00007aa9b5fe1b97  movaps [rsp+0x20], xmm15
00007aa9b5fe1b9d  lea rdi, [rsp]
00007aa9b5fe1ba1  mov esi, 0x00
00007aa9b5fe1ba6  mov rax, 0x63E0217C9530
00007aa9b5fe1bb0  call rax
00007aa9b5fe1bb2  movaps xmm3, [rsp]
00007aa9b5fe1bb6  add rsp, 0x30
00007aa9b5fe1bba  vmovaps xmm0, [rsp]
00007aa9b5fe1bbf  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe1bc5  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe1bcb  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe1bd1  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe1bd7  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe1bdd  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe1be3  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe1be9  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe1bf2  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe1bfb  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe1c04  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe1c0d  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe1c16  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe1c1f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe1c28  add rsp, 0xF0
00007aa9b5fe1c2f  pop r11
00007aa9b5fe1c31  pop r10
00007aa9b5fe1c33  pop r9
00007aa9b5fe1c35  pop r8
00007aa9b5fe1c37  pop rsi
00007aa9b5fe1c38  pop rdi
00007aa9b5fe1c39  pop rdx
00007aa9b5fe1c3a  pop rcx
00007aa9b5fe1c3b  pop rax
00007aa9b5fe1c3c  add rsp, 0x08
00007aa9b5fe1c40  jmp 0x00007AA9B5FDF452
00007aa9b5fe1c45  call 0x00007AA9B5EB52F0
00007aa9b5fe1c4a  jmp 0x00007AA9B5FDF45C
00007aa9b5fe1c4f  sub rsp, 0x08
00007aa9b5fe1c53  push rax
00007aa9b5fe1c54  push rcx
00007aa9b5fe1c55  push rdx
00007aa9b5fe1c56  push rdi
00007aa9b5fe1c57  push rsi
00007aa9b5fe1c58  push r8
00007aa9b5fe1c5a  push r9
00007aa9b5fe1c5c  push r10
00007aa9b5fe1c5e  push r11
00007aa9b5fe1c60  sub rsp, 0xF0
00007aa9b5fe1c67  vmovaps [rsp], xmm0
00007aa9b5fe1c6c  vmovaps [rsp+0x10], xmm1
00007aa9b5fe1c72  vmovaps [rsp+0x20], xmm2
00007aa9b5fe1c78  vmovaps [rsp+0x30], xmm3
00007aa9b5fe1c7e  vmovaps [rsp+0x40], xmm4
00007aa9b5fe1c84  vmovaps [rsp+0x50], xmm5
00007aa9b5fe1c8a  vmovaps [rsp+0x60], xmm6
00007aa9b5fe1c90  vmovaps [rsp+0x70], xmm7
00007aa9b5fe1c96  vmovaps [rsp+0x80], xmm8
00007aa9b5fe1c9f  vmovaps [rsp+0x90], xmm9
00007aa9b5fe1ca8  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe1cb1  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe1cba  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe1cc3  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe1ccc  vmovaps [rsp+0xE0], xmm14
00007aa9b5fe1cd5  sub rsp, 0x30
00007aa9b5fe1cd9  movaps [rsp], xmm15
00007aa9b5fe1cde  movaps [rsp+0x10], xmm14
00007aa9b5fe1ce4  movaps [rsp+0x20], xmm4
00007aa9b5fe1ce9  lea rdi, [rsp]
00007aa9b5fe1ced  mov esi, 0x00
00007aa9b5fe1cf2  mov rax, 0x63E0217C9530
00007aa9b5fe1cfc  call rax
00007aa9b5fe1cfe  movaps xmm15, [rsp]
00007aa9b5fe1d03  add rsp, 0x30
00007aa9b5fe1d07  vmovaps xmm0, [rsp]
00007aa9b5fe1d0c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe1d12  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe1d18  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe1d1e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe1d24  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe1d2a  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe1d30  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe1d36  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe1d3f  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe1d48  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe1d51  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe1d5a  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe1d63  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe1d6c  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fe1d75  add rsp, 0xF0
00007aa9b5fe1d7c  pop r11
00007aa9b5fe1d7e  pop r10
00007aa9b5fe1d80  pop r9
00007aa9b5fe1d82  pop r8
00007aa9b5fe1d84  pop rsi
00007aa9b5fe1d85  pop rdi
00007aa9b5fe1d86  pop rdx
00007aa9b5fe1d87  pop rcx
00007aa9b5fe1d88  pop rax
00007aa9b5fe1d89  add rsp, 0x08
00007aa9b5fe1d8d  jmp 0x00007AA9B5FDF48A
00007aa9b5fe1d92  sub rsp, 0x08
00007aa9b5fe1d96  push rax
00007aa9b5fe1d97  push rcx
00007aa9b5fe1d98  push rdx
00007aa9b5fe1d99  push rdi
00007aa9b5fe1d9a  push rsi
00007aa9b5fe1d9b  push r8
00007aa9b5fe1d9d  push r9
00007aa9b5fe1d9f  push r10
00007aa9b5fe1da1  push r11
00007aa9b5fe1da3  sub rsp, 0xF0
00007aa9b5fe1daa  vmovaps [rsp], xmm0
00007aa9b5fe1daf  vmovaps [rsp+0x10], xmm1
00007aa9b5fe1db5  vmovaps [rsp+0x20], xmm2
00007aa9b5fe1dbb  vmovaps [rsp+0x30], xmm3
00007aa9b5fe1dc1  vmovaps [rsp+0x40], xmm4
00007aa9b5fe1dc7  vmovaps [rsp+0x50], xmm5
00007aa9b5fe1dcd  vmovaps [rsp+0x60], xmm6
00007aa9b5fe1dd3  vmovaps [rsp+0x70], xmm7
00007aa9b5fe1dd9  vmovaps [rsp+0x80], xmm8
00007aa9b5fe1de2  vmovaps [rsp+0x90], xmm9
00007aa9b5fe1deb  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe1df4  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe1dfd  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe1e06  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe1e0f  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe1e18  sub rsp, 0x30
00007aa9b5fe1e1c  movaps [rsp], xmm14
00007aa9b5fe1e21  movaps [rsp+0x10], xmm2
00007aa9b5fe1e26  movaps [rsp+0x20], xmm1
00007aa9b5fe1e2b  lea rdi, [rsp]
00007aa9b5fe1e2f  mov esi, 0x00
00007aa9b5fe1e34  mov rax, 0x63E0217C9530
00007aa9b5fe1e3e  call rax
00007aa9b5fe1e40  movaps xmm14, [rsp]
00007aa9b5fe1e45  add rsp, 0x30
00007aa9b5fe1e49  vmovaps xmm0, [rsp]
00007aa9b5fe1e4e  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe1e54  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe1e5a  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe1e60  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe1e66  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe1e6c  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe1e72  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe1e78  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe1e81  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe1e8a  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe1e93  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe1e9c  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe1ea5  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe1eae  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe1eb7  add rsp, 0xF0
00007aa9b5fe1ebe  pop r11
00007aa9b5fe1ec0  pop r10
00007aa9b5fe1ec2  pop r9
00007aa9b5fe1ec4  pop r8
00007aa9b5fe1ec6  pop rsi
00007aa9b5fe1ec7  pop rdi
00007aa9b5fe1ec8  pop rdx
00007aa9b5fe1ec9  pop rcx
00007aa9b5fe1eca  pop rax
00007aa9b5fe1ecb  add rsp, 0x08
00007aa9b5fe1ecf  jmp 0x00007AA9B5FDF4B0
00007aa9b5fe1ed4  sub rsp, 0x08
00007aa9b5fe1ed8  push rax
00007aa9b5fe1ed9  push rcx
00007aa9b5fe1eda  push rdx
00007aa9b5fe1edb  push rdi
00007aa9b5fe1edc  push rsi
00007aa9b5fe1edd  push r8
00007aa9b5fe1edf  push r9
00007aa9b5fe1ee1  push r10
00007aa9b5fe1ee3  push r11
00007aa9b5fe1ee5  sub rsp, 0xF0
00007aa9b5fe1eec  vmovaps [rsp], xmm0
00007aa9b5fe1ef1  vmovaps [rsp+0x10], xmm2
00007aa9b5fe1ef7  vmovaps [rsp+0x20], xmm3
00007aa9b5fe1efd  vmovaps [rsp+0x30], xmm4
00007aa9b5fe1f03  vmovaps [rsp+0x40], xmm5
00007aa9b5fe1f09  vmovaps [rsp+0x50], xmm6
00007aa9b5fe1f0f  vmovaps [rsp+0x60], xmm7
00007aa9b5fe1f15  vmovaps [rsp+0x70], xmm8
00007aa9b5fe1f1b  vmovaps [rsp+0x80], xmm9
00007aa9b5fe1f24  vmovaps [rsp+0x90], xmm10
00007aa9b5fe1f2d  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe1f36  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe1f3f  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe1f48  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe1f51  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe1f5a  sub rsp, 0x30
00007aa9b5fe1f5e  movaps [rsp], xmm1
00007aa9b5fe1f62  movaps [rsp+0x10], xmm4
00007aa9b5fe1f67  movaps [rsp+0x20], xmm9
00007aa9b5fe1f6d  lea rdi, [rsp]
00007aa9b5fe1f71  mov esi, 0x00
00007aa9b5fe1f76  mov rax, 0x63E0217C9530
00007aa9b5fe1f80  call rax
00007aa9b5fe1f82  movaps xmm1, [rsp]
00007aa9b5fe1f86  add rsp, 0x30
00007aa9b5fe1f8a  vmovaps xmm0, [rsp]
00007aa9b5fe1f8f  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe1f95  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe1f9b  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe1fa1  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe1fa7  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe1fad  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe1fb3  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe1fb9  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe1fc2  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe1fcb  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe1fd4  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe1fdd  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe1fe6  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe1fef  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe1ff8  add rsp, 0xF0
00007aa9b5fe1fff  pop r11
00007aa9b5fe2001  pop r10
00007aa9b5fe2003  pop r9
00007aa9b5fe2005  pop r8
00007aa9b5fe2007  pop rsi
00007aa9b5fe2008  pop rdi
00007aa9b5fe2009  pop rdx
00007aa9b5fe200a  pop rcx
00007aa9b5fe200b  pop rax
00007aa9b5fe200c  add rsp, 0x08
00007aa9b5fe2010  jmp 0x00007AA9B5FDF4CE
00007aa9b5fe2015  sub rsp, 0x08
00007aa9b5fe2019  push rax
00007aa9b5fe201a  push rcx
00007aa9b5fe201b  push rdx
00007aa9b5fe201c  push rdi
00007aa9b5fe201d  push rsi
00007aa9b5fe201e  push r8
00007aa9b5fe2020  push r9
00007aa9b5fe2022  push r10
00007aa9b5fe2024  push r11
00007aa9b5fe2026  sub rsp, 0xF0
00007aa9b5fe202d  vmovaps [rsp], xmm0
00007aa9b5fe2032  vmovaps [rsp+0x10], xmm1
00007aa9b5fe2038  vmovaps [rsp+0x20], xmm2
00007aa9b5fe203e  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2044  vmovaps [rsp+0x40], xmm5
00007aa9b5fe204a  vmovaps [rsp+0x50], xmm6
00007aa9b5fe2050  vmovaps [rsp+0x60], xmm7
00007aa9b5fe2056  vmovaps [rsp+0x70], xmm8
00007aa9b5fe205c  vmovaps [rsp+0x80], xmm9
00007aa9b5fe2065  vmovaps [rsp+0x90], xmm10
00007aa9b5fe206e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe2077  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe2080  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe2089  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe2092  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe209b  sub rsp, 0x30
00007aa9b5fe209f  movaps [rsp], xmm4
00007aa9b5fe20a3  movaps [rsp+0x10], xmm2
00007aa9b5fe20a8  movaps [rsp+0x20], xmm9
00007aa9b5fe20ae  lea rdi, [rsp]
00007aa9b5fe20b2  mov esi, 0x00
00007aa9b5fe20b7  mov rax, 0x63E0217C9530
00007aa9b5fe20c1  call rax
00007aa9b5fe20c3  movaps xmm4, [rsp]
00007aa9b5fe20c7  add rsp, 0x30
00007aa9b5fe20cb  vmovaps xmm0, [rsp]
00007aa9b5fe20d0  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe20d6  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe20dc  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe20e2  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe20e8  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe20ee  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe20f4  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe20fa  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe2103  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe210c  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe2115  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe211e  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe2127  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe2130  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe2139  add rsp, 0xF0
00007aa9b5fe2140  pop r11
00007aa9b5fe2142  pop r10
00007aa9b5fe2144  pop r9
00007aa9b5fe2146  pop r8
00007aa9b5fe2148  pop rsi
00007aa9b5fe2149  pop rdi
00007aa9b5fe214a  pop rdx
00007aa9b5fe214b  pop rcx
00007aa9b5fe214c  pop rax
00007aa9b5fe214d  add rsp, 0x08
00007aa9b5fe2151  jmp 0x00007AA9B5FDF4FE
00007aa9b5fe2156  sub rsp, 0x08
00007aa9b5fe215a  push rax
00007aa9b5fe215b  push rcx
00007aa9b5fe215c  push rdx
00007aa9b5fe215d  push rdi
00007aa9b5fe215e  push rsi
00007aa9b5fe215f  push r8
00007aa9b5fe2161  push r9
00007aa9b5fe2163  push r10
00007aa9b5fe2165  push r11
00007aa9b5fe2167  sub rsp, 0xF0
00007aa9b5fe216e  vmovaps [rsp], xmm0
00007aa9b5fe2173  vmovaps [rsp+0x10], xmm1
00007aa9b5fe2179  vmovaps [rsp+0x20], xmm2
00007aa9b5fe217f  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2185  vmovaps [rsp+0x40], xmm4
00007aa9b5fe218b  vmovaps [rsp+0x50], xmm5
00007aa9b5fe2191  vmovaps [rsp+0x60], xmm6
00007aa9b5fe2197  vmovaps [rsp+0x70], xmm7
00007aa9b5fe219d  vmovaps [rsp+0x80], xmm8
00007aa9b5fe21a6  vmovaps [rsp+0x90], xmm10
00007aa9b5fe21af  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe21b8  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe21c1  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe21ca  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe21d3  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe21dc  sub rsp, 0x30
00007aa9b5fe21e0  movaps [rsp], xmm9
00007aa9b5fe21e5  movaps [rsp+0x10], xmm2
00007aa9b5fe21ea  movaps [rsp+0x20], xmm1
00007aa9b5fe21ef  lea rdi, [rsp]
00007aa9b5fe21f3  mov esi, 0x00
00007aa9b5fe21f8  mov rax, 0x63E0217C9530
00007aa9b5fe2202  call rax
00007aa9b5fe2204  movaps xmm9, [rsp]
00007aa9b5fe2209  add rsp, 0x30
00007aa9b5fe220d  vmovaps xmm0, [rsp]
00007aa9b5fe2212  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe2218  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe221e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe2224  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe222a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe2230  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe2236  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe223c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe2245  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe224e  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe2257  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe2260  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe2269  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe2272  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe227b  add rsp, 0xF0
00007aa9b5fe2282  pop r11
00007aa9b5fe2284  pop r10
00007aa9b5fe2286  pop r9
00007aa9b5fe2288  pop r8
00007aa9b5fe228a  pop rsi
00007aa9b5fe228b  pop rdi
00007aa9b5fe228c  pop rdx
00007aa9b5fe228d  pop rcx
00007aa9b5fe228e  pop rax
00007aa9b5fe228f  add rsp, 0x08
00007aa9b5fe2293  jmp 0x00007AA9B5FDF534
00007aa9b5fe2298  sub rsp, 0x08
00007aa9b5fe229c  push rax
00007aa9b5fe229d  push rcx
00007aa9b5fe229e  push rdx
00007aa9b5fe229f  push rdi
00007aa9b5fe22a0  push rsi
00007aa9b5fe22a1  push r8
00007aa9b5fe22a3  push r9
00007aa9b5fe22a5  push r10
00007aa9b5fe22a7  push r11
00007aa9b5fe22a9  sub rsp, 0xF0
00007aa9b5fe22b0  vmovaps [rsp], xmm0
00007aa9b5fe22b5  vmovaps [rsp+0x10], xmm2
00007aa9b5fe22bb  vmovaps [rsp+0x20], xmm3
00007aa9b5fe22c1  vmovaps [rsp+0x30], xmm4
00007aa9b5fe22c7  vmovaps [rsp+0x40], xmm5
00007aa9b5fe22cd  vmovaps [rsp+0x50], xmm6
00007aa9b5fe22d3  vmovaps [rsp+0x60], xmm7
00007aa9b5fe22d9  vmovaps [rsp+0x70], xmm8
00007aa9b5fe22df  vmovaps [rsp+0x80], xmm9
00007aa9b5fe22e8  vmovaps [rsp+0x90], xmm10
00007aa9b5fe22f1  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe22fa  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe2303  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe230c  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe2315  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe231e  sub rsp, 0x30
00007aa9b5fe2322  movaps [rsp], xmm1
00007aa9b5fe2326  movaps [rsp+0x10], xmm15
00007aa9b5fe232c  movaps [rsp+0x20], xmm6
00007aa9b5fe2331  lea rdi, [rsp]
00007aa9b5fe2335  mov esi, 0x00
00007aa9b5fe233a  mov rax, 0x63E0217C9530
00007aa9b5fe2344  call rax
00007aa9b5fe2346  movaps xmm1, [rsp]
00007aa9b5fe234a  add rsp, 0x30
00007aa9b5fe234e  vmovaps xmm0, [rsp]
00007aa9b5fe2353  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe2359  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe235f  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe2365  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe236b  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe2371  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe2377  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe237d  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe2386  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe238f  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe2398  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe23a1  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe23aa  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe23b3  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe23bc  add rsp, 0xF0
00007aa9b5fe23c3  pop r11
00007aa9b5fe23c5  pop r10
00007aa9b5fe23c7  pop r9
00007aa9b5fe23c9  pop r8
00007aa9b5fe23cb  pop rsi
00007aa9b5fe23cc  pop rdi
00007aa9b5fe23cd  pop rdx
00007aa9b5fe23ce  pop rcx
00007aa9b5fe23cf  pop rax
00007aa9b5fe23d0  add rsp, 0x08
00007aa9b5fe23d4  jmp 0x00007AA9B5FDF555
00007aa9b5fe23d9  sub rsp, 0x08
00007aa9b5fe23dd  push rax
00007aa9b5fe23de  push rcx
00007aa9b5fe23df  push rdx
00007aa9b5fe23e0  push rdi
00007aa9b5fe23e1  push rsi
00007aa9b5fe23e2  push r8
00007aa9b5fe23e4  push r9
00007aa9b5fe23e6  push r10
00007aa9b5fe23e8  push r11
00007aa9b5fe23ea  sub rsp, 0xF0
00007aa9b5fe23f1  vmovaps [rsp], xmm0
00007aa9b5fe23f6  vmovaps [rsp+0x10], xmm1
00007aa9b5fe23fc  vmovaps [rsp+0x20], xmm2
00007aa9b5fe2402  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2408  vmovaps [rsp+0x40], xmm4
00007aa9b5fe240e  vmovaps [rsp+0x50], xmm5
00007aa9b5fe2414  vmovaps [rsp+0x60], xmm6
00007aa9b5fe241a  vmovaps [rsp+0x70], xmm7
00007aa9b5fe2420  vmovaps [rsp+0x80], xmm8
00007aa9b5fe2429  vmovaps [rsp+0x90], xmm9
00007aa9b5fe2432  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe243b  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe2444  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe244d  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe2456  vmovaps [rsp+0xE0], xmm14
00007aa9b5fe245f  sub rsp, 0x30
00007aa9b5fe2463  movaps [rsp], xmm15
00007aa9b5fe2468  movaps [rsp+0x10], xmm5
00007aa9b5fe246d  movaps [rsp+0x20], xmm3
00007aa9b5fe2472  lea rdi, [rsp]
00007aa9b5fe2476  mov esi, 0x00
00007aa9b5fe247b  mov rax, 0x63E0217C9530
00007aa9b5fe2485  call rax
00007aa9b5fe2487  movaps xmm15, [rsp]
00007aa9b5fe248c  add rsp, 0x30
00007aa9b5fe2490  vmovaps xmm0, [rsp]
00007aa9b5fe2495  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe249b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe24a1  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe24a7  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe24ad  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe24b3  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe24b9  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe24bf  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe24c8  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe24d1  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe24da  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe24e3  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe24ec  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe24f5  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fe24fe  add rsp, 0xF0
00007aa9b5fe2505  pop r11
00007aa9b5fe2507  pop r10
00007aa9b5fe2509  pop r9
00007aa9b5fe250b  pop r8
00007aa9b5fe250d  pop rsi
00007aa9b5fe250e  pop rdi
00007aa9b5fe250f  pop rdx
00007aa9b5fe2510  pop rcx
00007aa9b5fe2511  pop rax
00007aa9b5fe2512  add rsp, 0x08
00007aa9b5fe2516  jmp 0x00007AA9B5FDF56F
00007aa9b5fe251b  sub rsp, 0x08
00007aa9b5fe251f  push rax
00007aa9b5fe2520  push rcx
00007aa9b5fe2521  push rdx
00007aa9b5fe2522  push rdi
00007aa9b5fe2523  push rsi
00007aa9b5fe2524  push r8
00007aa9b5fe2526  push r9
00007aa9b5fe2528  push r10
00007aa9b5fe252a  push r11
00007aa9b5fe252c  sub rsp, 0xF0
00007aa9b5fe2533  vmovaps [rsp], xmm0
00007aa9b5fe2538  vmovaps [rsp+0x10], xmm1
00007aa9b5fe253e  vmovaps [rsp+0x20], xmm2
00007aa9b5fe2544  vmovaps [rsp+0x30], xmm3
00007aa9b5fe254a  vmovaps [rsp+0x40], xmm4
00007aa9b5fe2550  vmovaps [rsp+0x50], xmm6
00007aa9b5fe2556  vmovaps [rsp+0x60], xmm7
00007aa9b5fe255c  vmovaps [rsp+0x70], xmm8
00007aa9b5fe2562  vmovaps [rsp+0x80], xmm9
00007aa9b5fe256b  vmovaps [rsp+0x90], xmm10
00007aa9b5fe2574  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe257d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe2586  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe258f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe2598  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe25a1  sub rsp, 0x30
00007aa9b5fe25a5  movaps [rsp], xmm5
00007aa9b5fe25a9  movaps [rsp+0x10], xmm8
00007aa9b5fe25af  movaps [rsp+0x20], xmm6
00007aa9b5fe25b4  lea rdi, [rsp]
00007aa9b5fe25b8  mov esi, 0x00
00007aa9b5fe25bd  mov rax, 0x63E0217C9530
00007aa9b5fe25c7  call rax
00007aa9b5fe25c9  movaps xmm5, [rsp]
00007aa9b5fe25cd  add rsp, 0x30
00007aa9b5fe25d1  vmovaps xmm0, [rsp]
00007aa9b5fe25d6  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe25dc  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe25e2  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe25e8  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe25ee  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe25f4  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe25fa  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe2600  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe2609  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe2612  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe261b  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe2624  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe262d  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe2636  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe263f  add rsp, 0xF0
00007aa9b5fe2646  pop r11
00007aa9b5fe2648  pop r10
00007aa9b5fe264a  pop r9
00007aa9b5fe264c  pop r8
00007aa9b5fe264e  pop rsi
00007aa9b5fe264f  pop rdi
00007aa9b5fe2650  pop rdx
00007aa9b5fe2651  pop rcx
00007aa9b5fe2652  pop rax
00007aa9b5fe2653  add rsp, 0x08
00007aa9b5fe2657  jmp 0x00007AA9B5FDF593
00007aa9b5fe265c  sub rsp, 0x08
00007aa9b5fe2660  push rax
00007aa9b5fe2661  push rcx
00007aa9b5fe2662  push rdx
00007aa9b5fe2663  push rdi
00007aa9b5fe2664  push rsi
00007aa9b5fe2665  push r8
00007aa9b5fe2667  push r9
00007aa9b5fe2669  push r10
00007aa9b5fe266b  push r11
00007aa9b5fe266d  sub rsp, 0xF0
00007aa9b5fe2674  vmovaps [rsp], xmm0
00007aa9b5fe2679  vmovaps [rsp+0x10], xmm1
00007aa9b5fe267f  vmovaps [rsp+0x20], xmm2
00007aa9b5fe2685  vmovaps [rsp+0x30], xmm3
00007aa9b5fe268b  vmovaps [rsp+0x40], xmm4
00007aa9b5fe2691  vmovaps [rsp+0x50], xmm5
00007aa9b5fe2697  vmovaps [rsp+0x60], xmm7
00007aa9b5fe269d  vmovaps [rsp+0x70], xmm8
00007aa9b5fe26a3  vmovaps [rsp+0x80], xmm9
00007aa9b5fe26ac  vmovaps [rsp+0x90], xmm10
00007aa9b5fe26b5  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe26be  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe26c7  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe26d0  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe26d9  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe26e2  sub rsp, 0x30
00007aa9b5fe26e6  movaps [rsp], xmm6
00007aa9b5fe26ea  movaps [rsp+0x10], xmm10
00007aa9b5fe26f0  movaps [rsp+0x20], xmm8
00007aa9b5fe26f6  lea rdi, [rsp]
00007aa9b5fe26fa  mov esi, 0x00
00007aa9b5fe26ff  mov rax, 0x63E0217C9530
00007aa9b5fe2709  call rax
00007aa9b5fe270b  movaps xmm6, [rsp]
00007aa9b5fe270f  add rsp, 0x30
00007aa9b5fe2713  vmovaps xmm0, [rsp]
00007aa9b5fe2718  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe271e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe2724  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe272a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe2730  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe2736  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe273c  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe2742  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe274b  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe2754  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe275d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe2766  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe276f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe2778  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe2781  add rsp, 0xF0
00007aa9b5fe2788  pop r11
00007aa9b5fe278a  pop r10
00007aa9b5fe278c  pop r9
00007aa9b5fe278e  pop r8
00007aa9b5fe2790  pop rsi
00007aa9b5fe2791  pop rdi
00007aa9b5fe2792  pop rdx
00007aa9b5fe2793  pop rcx
00007aa9b5fe2794  pop rax
00007aa9b5fe2795  add rsp, 0x08
00007aa9b5fe2799  jmp 0x00007AA9B5FDF5B8
00007aa9b5fe279e  sub rsp, 0x08
00007aa9b5fe27a2  push rax
00007aa9b5fe27a3  push rcx
00007aa9b5fe27a4  push rdx
00007aa9b5fe27a5  push rdi
00007aa9b5fe27a6  push rsi
00007aa9b5fe27a7  push r8
00007aa9b5fe27a9  push r9
00007aa9b5fe27ab  push r10
00007aa9b5fe27ad  push r11
00007aa9b5fe27af  sub rsp, 0xF0
00007aa9b5fe27b6  vmovaps [rsp], xmm0
00007aa9b5fe27bb  vmovaps [rsp+0x10], xmm1
00007aa9b5fe27c1  vmovaps [rsp+0x20], xmm2
00007aa9b5fe27c7  vmovaps [rsp+0x30], xmm3
00007aa9b5fe27cd  vmovaps [rsp+0x40], xmm4
00007aa9b5fe27d3  vmovaps [rsp+0x50], xmm5
00007aa9b5fe27d9  vmovaps [rsp+0x60], xmm6
00007aa9b5fe27df  vmovaps [rsp+0x70], xmm7
00007aa9b5fe27e5  vmovaps [rsp+0x80], xmm8
00007aa9b5fe27ee  vmovaps [rsp+0x90], xmm9
00007aa9b5fe27f7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe2800  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe2809  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe2812  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe281b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe2824  sub rsp, 0x30
00007aa9b5fe2828  movaps [rsp], xmm10
00007aa9b5fe282d  movaps [rsp+0x10], xmm8
00007aa9b5fe2833  movaps [rsp+0x20], xmm14
00007aa9b5fe2839  lea rdi, [rsp]
00007aa9b5fe283d  mov esi, 0x00
00007aa9b5fe2842  mov rax, 0x63E0217C9530
00007aa9b5fe284c  call rax
00007aa9b5fe284e  movaps xmm10, [rsp]
00007aa9b5fe2853  add rsp, 0x30
00007aa9b5fe2857  vmovaps xmm0, [rsp]
00007aa9b5fe285c  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe2862  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe2868  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe286e  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe2874  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe287a  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe2880  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe2886  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe288f  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe2898  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe28a1  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe28aa  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe28b3  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe28bc  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe28c5  add rsp, 0xF0
00007aa9b5fe28cc  pop r11
00007aa9b5fe28ce  pop r10
00007aa9b5fe28d0  pop r9
00007aa9b5fe28d2  pop r8
00007aa9b5fe28d4  pop rsi
00007aa9b5fe28d5  pop rdi
00007aa9b5fe28d6  pop rdx
00007aa9b5fe28d7  pop rcx
00007aa9b5fe28d8  pop rax
00007aa9b5fe28d9  add rsp, 0x08
00007aa9b5fe28dd  jmp 0x00007AA9B5FDF5D8
00007aa9b5fe28e2  sub rsp, 0x08
00007aa9b5fe28e6  push rax
00007aa9b5fe28e7  push rcx
00007aa9b5fe28e8  push rdx
00007aa9b5fe28e9  push rdi
00007aa9b5fe28ea  push rsi
00007aa9b5fe28eb  push r8
00007aa9b5fe28ed  push r9
00007aa9b5fe28ef  push r10
00007aa9b5fe28f1  push r11
00007aa9b5fe28f3  sub rsp, 0xF0
00007aa9b5fe28fa  vmovaps [rsp], xmm0
00007aa9b5fe28ff  vmovaps [rsp+0x10], xmm1
00007aa9b5fe2905  vmovaps [rsp+0x20], xmm2
00007aa9b5fe290b  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2911  vmovaps [rsp+0x40], xmm4
00007aa9b5fe2917  vmovaps [rsp+0x50], xmm5
00007aa9b5fe291d  vmovaps [rsp+0x60], xmm6
00007aa9b5fe2923  vmovaps [rsp+0x70], xmm7
00007aa9b5fe2929  vmovaps [rsp+0x80], xmm8
00007aa9b5fe2932  vmovaps [rsp+0x90], xmm9
00007aa9b5fe293b  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe2944  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe294d  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe2956  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe295f  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe2968  sub rsp, 0x30
00007aa9b5fe296c  movaps [rsp], xmm14
00007aa9b5fe2971  movaps [rsp+0x10], xmm8
00007aa9b5fe2977  movaps [rsp+0x20], xmm4
00007aa9b5fe297c  lea rdi, [rsp]
00007aa9b5fe2980  mov esi, 0x00
00007aa9b5fe2985  mov rax, 0x63E0217C9530
00007aa9b5fe298f  call rax
00007aa9b5fe2991  movaps xmm14, [rsp]
00007aa9b5fe2996  add rsp, 0x30
00007aa9b5fe299a  vmovaps xmm0, [rsp]
00007aa9b5fe299f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe29a5  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe29ab  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe29b1  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe29b7  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe29bd  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe29c3  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe29c9  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe29d2  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe29db  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe29e4  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe29ed  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe29f6  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe29ff  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe2a08  add rsp, 0xF0
00007aa9b5fe2a0f  pop r11
00007aa9b5fe2a11  pop r10
00007aa9b5fe2a13  pop r9
00007aa9b5fe2a15  pop r8
00007aa9b5fe2a17  pop rsi
00007aa9b5fe2a18  pop rdi
00007aa9b5fe2a19  pop rdx
00007aa9b5fe2a1a  pop rcx
00007aa9b5fe2a1b  pop rax
00007aa9b5fe2a1c  add rsp, 0x08
00007aa9b5fe2a20  jmp 0x00007AA9B5FDF5F8
00007aa9b5fe2a25  sub rsp, 0x08
00007aa9b5fe2a29  push rax
00007aa9b5fe2a2a  push rcx
00007aa9b5fe2a2b  push rdx
00007aa9b5fe2a2c  push rdi
00007aa9b5fe2a2d  push rsi
00007aa9b5fe2a2e  push r8
00007aa9b5fe2a30  push r9
00007aa9b5fe2a32  push r10
00007aa9b5fe2a34  push r11
00007aa9b5fe2a36  sub rsp, 0xF0
00007aa9b5fe2a3d  vmovaps [rsp], xmm0
00007aa9b5fe2a42  vmovaps [rsp+0x10], xmm1
00007aa9b5fe2a48  vmovaps [rsp+0x20], xmm2
00007aa9b5fe2a4e  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2a54  vmovaps [rsp+0x40], xmm5
00007aa9b5fe2a5a  vmovaps [rsp+0x50], xmm6
00007aa9b5fe2a60  vmovaps [rsp+0x60], xmm7
00007aa9b5fe2a66  vmovaps [rsp+0x70], xmm8
00007aa9b5fe2a6c  vmovaps [rsp+0x80], xmm9
00007aa9b5fe2a75  vmovaps [rsp+0x90], xmm10
00007aa9b5fe2a7e  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe2a87  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe2a90  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe2a99  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe2aa2  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe2aab  sub rsp, 0x30
00007aa9b5fe2aaf  movaps [rsp], xmm4
00007aa9b5fe2ab3  movaps [rsp+0x10], xmm13
00007aa9b5fe2ab9  movaps [rsp+0x20], xmm8
00007aa9b5fe2abf  lea rdi, [rsp]
00007aa9b5fe2ac3  mov esi, 0x00
00007aa9b5fe2ac8  mov rax, 0x63E0217C9530
00007aa9b5fe2ad2  call rax
00007aa9b5fe2ad4  movaps xmm4, [rsp]
00007aa9b5fe2ad8  add rsp, 0x30
00007aa9b5fe2adc  vmovaps xmm0, [rsp]
00007aa9b5fe2ae1  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe2ae7  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe2aed  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe2af3  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe2af9  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe2aff  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe2b05  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe2b0b  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe2b14  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe2b1d  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe2b26  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe2b2f  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe2b38  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe2b41  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe2b4a  add rsp, 0xF0
00007aa9b5fe2b51  pop r11
00007aa9b5fe2b53  pop r10
00007aa9b5fe2b55  pop r9
00007aa9b5fe2b57  pop r8
00007aa9b5fe2b59  pop rsi
00007aa9b5fe2b5a  pop rdi
00007aa9b5fe2b5b  pop rdx
00007aa9b5fe2b5c  pop rcx
00007aa9b5fe2b5d  pop rax
00007aa9b5fe2b5e  add rsp, 0x08
00007aa9b5fe2b62  jmp 0x00007AA9B5FDF61D
00007aa9b5fe2b67  sub rsp, 0x08
00007aa9b5fe2b6b  push rax
00007aa9b5fe2b6c  push rcx
00007aa9b5fe2b6d  push rdx
00007aa9b5fe2b6e  push rdi
00007aa9b5fe2b6f  push rsi
00007aa9b5fe2b70  push r8
00007aa9b5fe2b72  push r9
00007aa9b5fe2b74  push r10
00007aa9b5fe2b76  push r11
00007aa9b5fe2b78  sub rsp, 0xF0
00007aa9b5fe2b7f  vmovaps [rsp], xmm0
00007aa9b5fe2b84  vmovaps [rsp+0x10], xmm1
00007aa9b5fe2b8a  vmovaps [rsp+0x20], xmm2
00007aa9b5fe2b90  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2b96  vmovaps [rsp+0x40], xmm4
00007aa9b5fe2b9c  vmovaps [rsp+0x50], xmm5
00007aa9b5fe2ba2  vmovaps [rsp+0x60], xmm6
00007aa9b5fe2ba8  vmovaps [rsp+0x70], xmm7
00007aa9b5fe2bae  vmovaps [rsp+0x80], xmm8
00007aa9b5fe2bb7  vmovaps [rsp+0x90], xmm9
00007aa9b5fe2bc0  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe2bc9  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe2bd2  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe2bdb  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe2be4  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe2bed  sub rsp, 0x30
00007aa9b5fe2bf1  movaps [rsp], xmm13
00007aa9b5fe2bf6  movaps [rsp+0x10], xmm15
00007aa9b5fe2bfc  movaps [rsp+0x20], xmm9
00007aa9b5fe2c02  lea rdi, [rsp]
00007aa9b5fe2c06  mov esi, 0x00
00007aa9b5fe2c0b  mov rax, 0x63E0217C9530
00007aa9b5fe2c15  call rax
00007aa9b5fe2c17  movaps xmm13, [rsp]
00007aa9b5fe2c1c  add rsp, 0x30
00007aa9b5fe2c20  vmovaps xmm0, [rsp]
00007aa9b5fe2c25  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe2c2b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe2c31  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe2c37  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe2c3d  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe2c43  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe2c49  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe2c4f  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe2c58  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe2c61  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe2c6a  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe2c73  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe2c7c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe2c85  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe2c8e  add rsp, 0xF0
00007aa9b5fe2c95  pop r11
00007aa9b5fe2c97  pop r10
00007aa9b5fe2c99  pop r9
00007aa9b5fe2c9b  pop r8
00007aa9b5fe2c9d  pop rsi
00007aa9b5fe2c9e  pop rdi
00007aa9b5fe2c9f  pop rdx
00007aa9b5fe2ca0  pop rcx
00007aa9b5fe2ca1  pop rax
00007aa9b5fe2ca2  add rsp, 0x08
00007aa9b5fe2ca6  jmp 0x00007AA9B5FDF638
00007aa9b5fe2cab  sub rsp, 0x08
00007aa9b5fe2caf  push rax
00007aa9b5fe2cb0  push rcx
00007aa9b5fe2cb1  push rdx
00007aa9b5fe2cb2  push rdi
00007aa9b5fe2cb3  push rsi
00007aa9b5fe2cb4  push r8
00007aa9b5fe2cb6  push r9
00007aa9b5fe2cb8  push r10
00007aa9b5fe2cba  push r11
00007aa9b5fe2cbc  sub rsp, 0xF0
00007aa9b5fe2cc3  vmovaps [rsp], xmm0
00007aa9b5fe2cc8  vmovaps [rsp+0x10], xmm1
00007aa9b5fe2cce  vmovaps [rsp+0x20], xmm2
00007aa9b5fe2cd4  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2cda  vmovaps [rsp+0x40], xmm4
00007aa9b5fe2ce0  vmovaps [rsp+0x50], xmm5
00007aa9b5fe2ce6  vmovaps [rsp+0x60], xmm6
00007aa9b5fe2cec  vmovaps [rsp+0x70], xmm7
00007aa9b5fe2cf2  vmovaps [rsp+0x80], xmm8
00007aa9b5fe2cfb  vmovaps [rsp+0x90], xmm9
00007aa9b5fe2d04  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe2d0d  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe2d16  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe2d1f  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe2d28  vmovaps [rsp+0xE0], xmm14
00007aa9b5fe2d31  sub rsp, 0x30
00007aa9b5fe2d35  movaps [rsp], xmm15
00007aa9b5fe2d3a  movaps [rsp+0x10], xmm1
00007aa9b5fe2d3f  movaps [rsp+0x20], xmm5
00007aa9b5fe2d44  lea rdi, [rsp]
00007aa9b5fe2d48  mov esi, 0x00
00007aa9b5fe2d4d  mov rax, 0x63E0217C9530
00007aa9b5fe2d57  call rax
00007aa9b5fe2d59  movaps xmm15, [rsp]
00007aa9b5fe2d5e  add rsp, 0x30
00007aa9b5fe2d62  vmovaps xmm0, [rsp]
00007aa9b5fe2d67  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe2d6d  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe2d73  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe2d79  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe2d7f  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe2d85  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe2d8b  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe2d91  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe2d9a  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe2da3  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe2dac  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe2db5  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe2dbe  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe2dc7  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fe2dd0  add rsp, 0xF0
00007aa9b5fe2dd7  pop r11
00007aa9b5fe2dd9  pop r10
00007aa9b5fe2ddb  pop r9
00007aa9b5fe2ddd  pop r8
00007aa9b5fe2ddf  pop rsi
00007aa9b5fe2de0  pop rdi
00007aa9b5fe2de1  pop rdx
00007aa9b5fe2de2  pop rcx
00007aa9b5fe2de3  pop rax
00007aa9b5fe2de4  add rsp, 0x08
00007aa9b5fe2de8  jmp 0x00007AA9B5FDF653
00007aa9b5fe2ded  call 0x00007AA9B5EB52F0
00007aa9b5fe2df2  jmp 0x00007AA9B5FDF6AE
00007aa9b5fe2df7  sub rsp, 0x08
00007aa9b5fe2dfb  push rax
00007aa9b5fe2dfc  push rcx
00007aa9b5fe2dfd  push rdx
00007aa9b5fe2dfe  push rdi
00007aa9b5fe2dff  push rsi
00007aa9b5fe2e00  push r8
00007aa9b5fe2e02  push r9
00007aa9b5fe2e04  push r10
00007aa9b5fe2e06  push r11
00007aa9b5fe2e08  sub rsp, 0xF0
00007aa9b5fe2e0f  vmovaps [rsp], xmm0
00007aa9b5fe2e14  vmovaps [rsp+0x10], xmm1
00007aa9b5fe2e1a  vmovaps [rsp+0x20], xmm2
00007aa9b5fe2e20  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2e26  vmovaps [rsp+0x40], xmm4
00007aa9b5fe2e2c  vmovaps [rsp+0x50], xmm5
00007aa9b5fe2e32  vmovaps [rsp+0x60], xmm6
00007aa9b5fe2e38  vmovaps [rsp+0x70], xmm7
00007aa9b5fe2e3e  vmovaps [rsp+0x80], xmm8
00007aa9b5fe2e47  vmovaps [rsp+0x90], xmm10
00007aa9b5fe2e50  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe2e59  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe2e62  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe2e6b  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe2e74  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe2e7d  sub rsp, 0x30
00007aa9b5fe2e81  movaps [rsp], xmm9
00007aa9b5fe2e86  movaps [rsp+0x10], xmm8
00007aa9b5fe2e8c  movaps [rsp+0x20], xmm11
00007aa9b5fe2e92  lea rdi, [rsp]
00007aa9b5fe2e96  mov esi, 0x00
00007aa9b5fe2e9b  mov rax, 0x63E0217C9530
00007aa9b5fe2ea5  call rax
00007aa9b5fe2ea7  movaps xmm9, [rsp]
00007aa9b5fe2eac  add rsp, 0x30
00007aa9b5fe2eb0  vmovaps xmm0, [rsp]
00007aa9b5fe2eb5  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe2ebb  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe2ec1  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe2ec7  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe2ecd  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe2ed3  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe2ed9  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe2edf  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe2ee8  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe2ef1  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe2efa  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe2f03  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe2f0c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe2f15  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe2f1e  add rsp, 0xF0
00007aa9b5fe2f25  pop r11
00007aa9b5fe2f27  pop r10
00007aa9b5fe2f29  pop r9
00007aa9b5fe2f2b  pop r8
00007aa9b5fe2f2d  pop rsi
00007aa9b5fe2f2e  pop rdi
00007aa9b5fe2f2f  pop rdx
00007aa9b5fe2f30  pop rcx
00007aa9b5fe2f31  pop rax
00007aa9b5fe2f32  add rsp, 0x08
00007aa9b5fe2f36  jmp 0x00007AA9B5FDF6E5
00007aa9b5fe2f3b  sub rsp, 0x08
00007aa9b5fe2f3f  push rax
00007aa9b5fe2f40  push rcx
00007aa9b5fe2f41  push rdx
00007aa9b5fe2f42  push rdi
00007aa9b5fe2f43  push rsi
00007aa9b5fe2f44  push r8
00007aa9b5fe2f46  push r9
00007aa9b5fe2f48  push r10
00007aa9b5fe2f4a  push r11
00007aa9b5fe2f4c  sub rsp, 0xF0
00007aa9b5fe2f53  vmovaps [rsp], xmm0
00007aa9b5fe2f58  vmovaps [rsp+0x10], xmm1
00007aa9b5fe2f5e  vmovaps [rsp+0x20], xmm2
00007aa9b5fe2f64  vmovaps [rsp+0x30], xmm3
00007aa9b5fe2f6a  vmovaps [rsp+0x40], xmm4
00007aa9b5fe2f70  vmovaps [rsp+0x50], xmm5
00007aa9b5fe2f76  vmovaps [rsp+0x60], xmm6
00007aa9b5fe2f7c  vmovaps [rsp+0x70], xmm7
00007aa9b5fe2f82  vmovaps [rsp+0x80], xmm8
00007aa9b5fe2f8b  vmovaps [rsp+0x90], xmm9
00007aa9b5fe2f94  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe2f9d  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe2fa6  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe2faf  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe2fb8  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe2fc1  sub rsp, 0x30
00007aa9b5fe2fc5  movaps [rsp], xmm11
00007aa9b5fe2fca  movaps [rsp+0x10], xmm10
00007aa9b5fe2fd0  movaps [rsp+0x20], xmm6
00007aa9b5fe2fd5  lea rdi, [rsp]
00007aa9b5fe2fd9  mov esi, 0x00
00007aa9b5fe2fde  mov rax, 0x63E0217C9530
00007aa9b5fe2fe8  call rax
00007aa9b5fe2fea  movaps xmm11, [rsp]
00007aa9b5fe2fef  add rsp, 0x30
00007aa9b5fe2ff3  vmovaps xmm0, [rsp]
00007aa9b5fe2ff8  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe2ffe  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe3004  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe300a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe3010  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe3016  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe301c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe3022  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe302b  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe3034  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe303d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe3046  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe304f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe3058  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe3061  add rsp, 0xF0
00007aa9b5fe3068  pop r11
00007aa9b5fe306a  pop r10
00007aa9b5fe306c  pop r9
00007aa9b5fe306e  pop r8
00007aa9b5fe3070  pop rsi
00007aa9b5fe3071  pop rdi
00007aa9b5fe3072  pop rdx
00007aa9b5fe3073  pop rcx
00007aa9b5fe3074  pop rax
00007aa9b5fe3075  add rsp, 0x08
00007aa9b5fe3079  jmp 0x00007AA9B5FDF700
00007aa9b5fe307e  sub rsp, 0x08
00007aa9b5fe3082  push rax
00007aa9b5fe3083  push rcx
00007aa9b5fe3084  push rdx
00007aa9b5fe3085  push rdi
00007aa9b5fe3086  push rsi
00007aa9b5fe3087  push r8
00007aa9b5fe3089  push r9
00007aa9b5fe308b  push r10
00007aa9b5fe308d  push r11
00007aa9b5fe308f  sub rsp, 0xF0
00007aa9b5fe3096  vmovaps [rsp], xmm0
00007aa9b5fe309b  vmovaps [rsp+0x10], xmm1
00007aa9b5fe30a1  vmovaps [rsp+0x20], xmm2
00007aa9b5fe30a7  vmovaps [rsp+0x30], xmm3
00007aa9b5fe30ad  vmovaps [rsp+0x40], xmm4
00007aa9b5fe30b3  vmovaps [rsp+0x50], xmm5
00007aa9b5fe30b9  vmovaps [rsp+0x60], xmm6
00007aa9b5fe30bf  vmovaps [rsp+0x70], xmm7
00007aa9b5fe30c5  vmovaps [rsp+0x80], xmm8
00007aa9b5fe30ce  vmovaps [rsp+0x90], xmm9
00007aa9b5fe30d7  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe30e0  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe30e9  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe30f2  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe30fb  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe3104  sub rsp, 0x30
00007aa9b5fe3108  movaps [rsp], xmm10
00007aa9b5fe310d  movaps [rsp+0x10], xmm14
00007aa9b5fe3113  movaps [rsp+0x20], xmm4
00007aa9b5fe3118  lea rdi, [rsp]
00007aa9b5fe311c  mov esi, 0x00
00007aa9b5fe3121  mov rax, 0x63E0217C9530
00007aa9b5fe312b  call rax
00007aa9b5fe312d  movaps xmm10, [rsp]
00007aa9b5fe3132  add rsp, 0x30
00007aa9b5fe3136  vmovaps xmm0, [rsp]
00007aa9b5fe313b  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe3141  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe3147  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe314d  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe3153  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe3159  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe315f  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe3165  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe316e  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe3177  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe3180  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe3189  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe3192  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe319b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe31a4  add rsp, 0xF0
00007aa9b5fe31ab  pop r11
00007aa9b5fe31ad  pop r10
00007aa9b5fe31af  pop r9
00007aa9b5fe31b1  pop r8
00007aa9b5fe31b3  pop rsi
00007aa9b5fe31b4  pop rdi
00007aa9b5fe31b5  pop rdx
00007aa9b5fe31b6  pop rcx
00007aa9b5fe31b7  pop rax
00007aa9b5fe31b8  add rsp, 0x08
00007aa9b5fe31bc  jmp 0x00007AA9B5FDF71B
00007aa9b5fe31c1  sub rsp, 0x08
00007aa9b5fe31c5  push rax
00007aa9b5fe31c6  push rcx
00007aa9b5fe31c7  push rdx
00007aa9b5fe31c8  push rdi
00007aa9b5fe31c9  push rsi
00007aa9b5fe31ca  push r8
00007aa9b5fe31cc  push r9
00007aa9b5fe31ce  push r10
00007aa9b5fe31d0  push r11
00007aa9b5fe31d2  sub rsp, 0xF0
00007aa9b5fe31d9  vmovaps [rsp], xmm0
00007aa9b5fe31de  vmovaps [rsp+0x10], xmm1
00007aa9b5fe31e4  vmovaps [rsp+0x20], xmm2
00007aa9b5fe31ea  vmovaps [rsp+0x30], xmm3
00007aa9b5fe31f0  vmovaps [rsp+0x40], xmm4
00007aa9b5fe31f6  vmovaps [rsp+0x50], xmm5
00007aa9b5fe31fc  vmovaps [rsp+0x60], xmm6
00007aa9b5fe3202  vmovaps [rsp+0x70], xmm7
00007aa9b5fe3208  vmovaps [rsp+0x80], xmm9
00007aa9b5fe3211  vmovaps [rsp+0x90], xmm10
00007aa9b5fe321a  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe3223  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe322c  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe3235  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe323e  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe3247  sub rsp, 0x30
00007aa9b5fe324b  movaps [rsp], xmm8
00007aa9b5fe3250  movaps [rsp+0x10], xmm1
00007aa9b5fe3255  movaps [rsp+0x20], xmm14
00007aa9b5fe325b  lea rdi, [rsp]
00007aa9b5fe325f  mov esi, 0x00
00007aa9b5fe3264  mov rax, 0x63E0217C9530
00007aa9b5fe326e  call rax
00007aa9b5fe3270  movaps xmm8, [rsp]
00007aa9b5fe3275  add rsp, 0x30
00007aa9b5fe3279  vmovaps xmm0, [rsp]
00007aa9b5fe327e  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe3284  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe328a  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe3290  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe3296  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe329c  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe32a2  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe32a8  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe32b1  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe32ba  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe32c3  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe32cc  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe32d5  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe32de  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe32e7  add rsp, 0xF0
00007aa9b5fe32ee  pop r11
00007aa9b5fe32f0  pop r10
00007aa9b5fe32f2  pop r9
00007aa9b5fe32f4  pop r8
00007aa9b5fe32f6  pop rsi
00007aa9b5fe32f7  pop rdi
00007aa9b5fe32f8  pop rdx
00007aa9b5fe32f9  pop rcx
00007aa9b5fe32fa  pop rax
00007aa9b5fe32fb  add rsp, 0x08
00007aa9b5fe32ff  jmp 0x00007AA9B5FDF741
00007aa9b5fe3304  sub rsp, 0x08
00007aa9b5fe3308  push rax
00007aa9b5fe3309  push rcx
00007aa9b5fe330a  push rdx
00007aa9b5fe330b  push rdi
00007aa9b5fe330c  push rsi
00007aa9b5fe330d  push r8
00007aa9b5fe330f  push r9
00007aa9b5fe3311  push r10
00007aa9b5fe3313  push r11
00007aa9b5fe3315  sub rsp, 0xF0
00007aa9b5fe331c  vmovaps [rsp], xmm0
00007aa9b5fe3321  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3327  vmovaps [rsp+0x20], xmm2
00007aa9b5fe332d  vmovaps [rsp+0x30], xmm3
00007aa9b5fe3333  vmovaps [rsp+0x40], xmm4
00007aa9b5fe3339  vmovaps [rsp+0x50], xmm5
00007aa9b5fe333f  vmovaps [rsp+0x60], xmm7
00007aa9b5fe3345  vmovaps [rsp+0x70], xmm8
00007aa9b5fe334b  vmovaps [rsp+0x80], xmm9
00007aa9b5fe3354  vmovaps [rsp+0x90], xmm10
00007aa9b5fe335d  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe3366  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe336f  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe3378  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe3381  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe338a  sub rsp, 0x30
00007aa9b5fe338e  movaps [rsp], xmm6
00007aa9b5fe3392  movaps [rsp+0x10], xmm1
00007aa9b5fe3397  movaps [rsp+0x20], xmm14
00007aa9b5fe339d  lea rdi, [rsp]
00007aa9b5fe33a1  mov esi, 0x00
00007aa9b5fe33a6  mov rax, 0x63E0217C9530
00007aa9b5fe33b0  call rax
00007aa9b5fe33b2  movaps xmm6, [rsp]
00007aa9b5fe33b6  add rsp, 0x30
00007aa9b5fe33ba  vmovaps xmm0, [rsp]
00007aa9b5fe33bf  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe33c5  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe33cb  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe33d1  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe33d7  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe33dd  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe33e3  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe33e9  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe33f2  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe33fb  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe3404  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe340d  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe3416  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe341f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe3428  add rsp, 0xF0
00007aa9b5fe342f  pop r11
00007aa9b5fe3431  pop r10
00007aa9b5fe3433  pop r9
00007aa9b5fe3435  pop r8
00007aa9b5fe3437  pop rsi
00007aa9b5fe3438  pop rdi
00007aa9b5fe3439  pop rdx
00007aa9b5fe343a  pop rcx
00007aa9b5fe343b  pop rax
00007aa9b5fe343c  add rsp, 0x08
00007aa9b5fe3440  jmp 0x00007AA9B5FDF76D
00007aa9b5fe3445  sub rsp, 0x08
00007aa9b5fe3449  push rax
00007aa9b5fe344a  push rcx
00007aa9b5fe344b  push rdx
00007aa9b5fe344c  push rdi
00007aa9b5fe344d  push rsi
00007aa9b5fe344e  push r8
00007aa9b5fe3450  push r9
00007aa9b5fe3452  push r10
00007aa9b5fe3454  push r11
00007aa9b5fe3456  sub rsp, 0xF0
00007aa9b5fe345d  vmovaps [rsp], xmm0
00007aa9b5fe3462  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3468  vmovaps [rsp+0x20], xmm2
00007aa9b5fe346e  vmovaps [rsp+0x30], xmm3
00007aa9b5fe3474  vmovaps [rsp+0x40], xmm4
00007aa9b5fe347a  vmovaps [rsp+0x50], xmm5
00007aa9b5fe3480  vmovaps [rsp+0x60], xmm6
00007aa9b5fe3486  vmovaps [rsp+0x70], xmm7
00007aa9b5fe348c  vmovaps [rsp+0x80], xmm8
00007aa9b5fe3495  vmovaps [rsp+0x90], xmm9
00007aa9b5fe349e  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe34a7  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe34b0  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe34b9  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe34c2  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe34cb  sub rsp, 0x30
00007aa9b5fe34cf  movaps [rsp], xmm14
00007aa9b5fe34d4  movaps [rsp+0x10], xmm12
00007aa9b5fe34da  movaps [rsp+0x20], xmm1
00007aa9b5fe34df  lea rdi, [rsp]
00007aa9b5fe34e3  mov esi, 0x00
00007aa9b5fe34e8  mov rax, 0x63E0217C9530
00007aa9b5fe34f2  call rax
00007aa9b5fe34f4  movaps xmm14, [rsp]
00007aa9b5fe34f9  add rsp, 0x30
00007aa9b5fe34fd  vmovaps xmm0, [rsp]
00007aa9b5fe3502  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe3508  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe350e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe3514  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe351a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe3520  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe3526  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe352c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe3535  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe353e  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe3547  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe3550  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe3559  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe3562  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe356b  add rsp, 0xF0
00007aa9b5fe3572  pop r11
00007aa9b5fe3574  pop r10
00007aa9b5fe3576  pop r9
00007aa9b5fe3578  pop r8
00007aa9b5fe357a  pop rsi
00007aa9b5fe357b  pop rdi
00007aa9b5fe357c  pop rdx
00007aa9b5fe357d  pop rcx
00007aa9b5fe357e  pop rax
00007aa9b5fe357f  add rsp, 0x08
00007aa9b5fe3583  jmp 0x00007AA9B5FDF793
00007aa9b5fe3588  sub rsp, 0x08
00007aa9b5fe358c  push rax
00007aa9b5fe358d  push rcx
00007aa9b5fe358e  push rdx
00007aa9b5fe358f  push rdi
00007aa9b5fe3590  push rsi
00007aa9b5fe3591  push r8
00007aa9b5fe3593  push r9
00007aa9b5fe3595  push r10
00007aa9b5fe3597  push r11
00007aa9b5fe3599  sub rsp, 0xF0
00007aa9b5fe35a0  vmovaps [rsp], xmm0
00007aa9b5fe35a5  vmovaps [rsp+0x10], xmm2
00007aa9b5fe35ab  vmovaps [rsp+0x20], xmm3
00007aa9b5fe35b1  vmovaps [rsp+0x30], xmm4
00007aa9b5fe35b7  vmovaps [rsp+0x40], xmm5
00007aa9b5fe35bd  vmovaps [rsp+0x50], xmm6
00007aa9b5fe35c3  vmovaps [rsp+0x60], xmm7
00007aa9b5fe35c9  vmovaps [rsp+0x70], xmm8
00007aa9b5fe35cf  vmovaps [rsp+0x80], xmm9
00007aa9b5fe35d8  vmovaps [rsp+0x90], xmm10
00007aa9b5fe35e1  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe35ea  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe35f3  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe35fc  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe3605  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe360e  sub rsp, 0x30
00007aa9b5fe3612  movaps [rsp], xmm1
00007aa9b5fe3616  movaps [rsp+0x10], xmm13
00007aa9b5fe361c  movaps [rsp+0x20], xmm9
00007aa9b5fe3622  lea rdi, [rsp]
00007aa9b5fe3626  mov esi, 0x00
00007aa9b5fe362b  mov rax, 0x63E0217C9530
00007aa9b5fe3635  call rax
00007aa9b5fe3637  movaps xmm1, [rsp]
00007aa9b5fe363b  add rsp, 0x30
00007aa9b5fe363f  vmovaps xmm0, [rsp]
00007aa9b5fe3644  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe364a  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe3650  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe3656  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe365c  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe3662  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe3668  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe366e  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe3677  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe3680  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe3689  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe3692  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe369b  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe36a4  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe36ad  add rsp, 0xF0
00007aa9b5fe36b4  pop r11
00007aa9b5fe36b6  pop r10
00007aa9b5fe36b8  pop r9
00007aa9b5fe36ba  pop r8
00007aa9b5fe36bc  pop rsi
00007aa9b5fe36bd  pop rdi
00007aa9b5fe36be  pop rdx
00007aa9b5fe36bf  pop rcx
00007aa9b5fe36c0  pop rax
00007aa9b5fe36c1  add rsp, 0x08
00007aa9b5fe36c5  jmp 0x00007AA9B5FDF7AD
00007aa9b5fe36ca  sub rsp, 0x08
00007aa9b5fe36ce  push rax
00007aa9b5fe36cf  push rcx
00007aa9b5fe36d0  push rdx
00007aa9b5fe36d1  push rdi
00007aa9b5fe36d2  push rsi
00007aa9b5fe36d3  push r8
00007aa9b5fe36d5  push r9
00007aa9b5fe36d7  push r10
00007aa9b5fe36d9  push r11
00007aa9b5fe36db  sub rsp, 0xF0
00007aa9b5fe36e2  vmovaps [rsp], xmm0
00007aa9b5fe36e7  vmovaps [rsp+0x10], xmm1
00007aa9b5fe36ed  vmovaps [rsp+0x20], xmm2
00007aa9b5fe36f3  vmovaps [rsp+0x30], xmm3
00007aa9b5fe36f9  vmovaps [rsp+0x40], xmm4
00007aa9b5fe36ff  vmovaps [rsp+0x50], xmm5
00007aa9b5fe3705  vmovaps [rsp+0x60], xmm6
00007aa9b5fe370b  vmovaps [rsp+0x70], xmm7
00007aa9b5fe3711  vmovaps [rsp+0x80], xmm8
00007aa9b5fe371a  vmovaps [rsp+0x90], xmm9
00007aa9b5fe3723  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe372c  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe3735  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe373e  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe3747  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe3750  sub rsp, 0x30
00007aa9b5fe3754  movaps [rsp], xmm12
00007aa9b5fe3759  movaps [rsp+0x10], xmm7
00007aa9b5fe375e  movaps [rsp+0x20], xmm13
00007aa9b5fe3764  lea rdi, [rsp]
00007aa9b5fe3768  mov esi, 0x00
00007aa9b5fe376d  mov rax, 0x63E0217C9530
00007aa9b5fe3777  call rax
00007aa9b5fe3779  movaps xmm12, [rsp]
00007aa9b5fe377e  add rsp, 0x30
00007aa9b5fe3782  vmovaps xmm0, [rsp]
00007aa9b5fe3787  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe378d  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe3793  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe3799  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe379f  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe37a5  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe37ab  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe37b1  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe37ba  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe37c3  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe37cc  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe37d5  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe37de  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe37e7  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe37f0  add rsp, 0xF0
00007aa9b5fe37f7  pop r11
00007aa9b5fe37f9  pop r10
00007aa9b5fe37fb  pop r9
00007aa9b5fe37fd  pop r8
00007aa9b5fe37ff  pop rsi
00007aa9b5fe3800  pop rdi
00007aa9b5fe3801  pop rdx
00007aa9b5fe3802  pop rcx
00007aa9b5fe3803  pop rax
00007aa9b5fe3804  add rsp, 0x08
00007aa9b5fe3808  jmp 0x00007AA9B5FDF7D4
00007aa9b5fe380d  sub rsp, 0x08
00007aa9b5fe3811  push rax
00007aa9b5fe3812  push rcx
00007aa9b5fe3813  push rdx
00007aa9b5fe3814  push rdi
00007aa9b5fe3815  push rsi
00007aa9b5fe3816  push r8
00007aa9b5fe3818  push r9
00007aa9b5fe381a  push r10
00007aa9b5fe381c  push r11
00007aa9b5fe381e  sub rsp, 0xF0
00007aa9b5fe3825  vmovaps [rsp], xmm0
00007aa9b5fe382a  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3830  vmovaps [rsp+0x20], xmm2
00007aa9b5fe3836  vmovaps [rsp+0x30], xmm3
00007aa9b5fe383c  vmovaps [rsp+0x40], xmm4
00007aa9b5fe3842  vmovaps [rsp+0x50], xmm5
00007aa9b5fe3848  vmovaps [rsp+0x60], xmm6
00007aa9b5fe384e  vmovaps [rsp+0x70], xmm7
00007aa9b5fe3854  vmovaps [rsp+0x80], xmm8
00007aa9b5fe385d  vmovaps [rsp+0x90], xmm9
00007aa9b5fe3866  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe386f  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe3878  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe3881  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe388a  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe3893  sub rsp, 0x30
00007aa9b5fe3897  movaps [rsp], xmm13
00007aa9b5fe389c  movaps [rsp+0x10], xmm15
00007aa9b5fe38a2  movaps [rsp+0x20], xmm8
00007aa9b5fe38a8  lea rdi, [rsp]
00007aa9b5fe38ac  mov esi, 0x00
00007aa9b5fe38b1  mov rax, 0x63E0217C9530
00007aa9b5fe38bb  call rax
00007aa9b5fe38bd  movaps xmm13, [rsp]
00007aa9b5fe38c2  add rsp, 0x30
00007aa9b5fe38c6  vmovaps xmm0, [rsp]
00007aa9b5fe38cb  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe38d1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe38d7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe38dd  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe38e3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe38e9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe38ef  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe38f5  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe38fe  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe3907  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe3910  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe3919  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe3922  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe392b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe3934  add rsp, 0xF0
00007aa9b5fe393b  pop r11
00007aa9b5fe393d  pop r10
00007aa9b5fe393f  pop r9
00007aa9b5fe3941  pop r8
00007aa9b5fe3943  pop rsi
00007aa9b5fe3944  pop rdi
00007aa9b5fe3945  pop rdx
00007aa9b5fe3946  pop rcx
00007aa9b5fe3947  pop rax
00007aa9b5fe3948  add rsp, 0x08
00007aa9b5fe394c  jmp 0x00007AA9B5FDF7EF
00007aa9b5fe3951  sub rsp, 0x08
00007aa9b5fe3955  push rax
00007aa9b5fe3956  push rcx
00007aa9b5fe3957  push rdx
00007aa9b5fe3958  push rdi
00007aa9b5fe3959  push rsi
00007aa9b5fe395a  push r8
00007aa9b5fe395c  push r9
00007aa9b5fe395e  push r10
00007aa9b5fe3960  push r11
00007aa9b5fe3962  sub rsp, 0xF0
00007aa9b5fe3969  vmovaps [rsp], xmm0
00007aa9b5fe396e  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3974  vmovaps [rsp+0x20], xmm2
00007aa9b5fe397a  vmovaps [rsp+0x30], xmm3
00007aa9b5fe3980  vmovaps [rsp+0x40], xmm4
00007aa9b5fe3986  vmovaps [rsp+0x50], xmm5
00007aa9b5fe398c  vmovaps [rsp+0x60], xmm6
00007aa9b5fe3992  vmovaps [rsp+0x70], xmm7
00007aa9b5fe3998  vmovaps [rsp+0x80], xmm9
00007aa9b5fe39a1  vmovaps [rsp+0x90], xmm10
00007aa9b5fe39aa  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe39b3  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe39bc  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe39c5  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe39ce  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe39d7  sub rsp, 0x30
00007aa9b5fe39db  movaps [rsp], xmm8
00007aa9b5fe39e0  movaps [rsp+0x10], xmm15
00007aa9b5fe39e6  movaps [rsp+0x20], xmm9
00007aa9b5fe39ec  lea rdi, [rsp]
00007aa9b5fe39f0  mov esi, 0x00
00007aa9b5fe39f5  mov rax, 0x63E0217C9530
00007aa9b5fe39ff  call rax
00007aa9b5fe3a01  movaps xmm8, [rsp]
00007aa9b5fe3a06  add rsp, 0x30
00007aa9b5fe3a0a  vmovaps xmm0, [rsp]
00007aa9b5fe3a0f  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe3a15  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe3a1b  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe3a21  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe3a27  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe3a2d  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe3a33  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe3a39  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe3a42  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe3a4b  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe3a54  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe3a5d  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe3a66  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe3a6f  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe3a78  add rsp, 0xF0
00007aa9b5fe3a7f  pop r11
00007aa9b5fe3a81  pop r10
00007aa9b5fe3a83  pop r9
00007aa9b5fe3a85  pop r8
00007aa9b5fe3a87  pop rsi
00007aa9b5fe3a88  pop rdi
00007aa9b5fe3a89  pop rdx
00007aa9b5fe3a8a  pop rcx
00007aa9b5fe3a8b  pop rax
00007aa9b5fe3a8c  add rsp, 0x08
00007aa9b5fe3a90  jmp 0x00007AA9B5FDF81D
00007aa9b5fe3a95  sub rsp, 0x08
00007aa9b5fe3a99  push rax
00007aa9b5fe3a9a  push rcx
00007aa9b5fe3a9b  push rdx
00007aa9b5fe3a9c  push rdi
00007aa9b5fe3a9d  push rsi
00007aa9b5fe3a9e  push r8
00007aa9b5fe3aa0  push r9
00007aa9b5fe3aa2  push r10
00007aa9b5fe3aa4  push r11
00007aa9b5fe3aa6  sub rsp, 0xF0
00007aa9b5fe3aad  vmovaps [rsp], xmm0
00007aa9b5fe3ab2  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3ab8  vmovaps [rsp+0x20], xmm2
00007aa9b5fe3abe  vmovaps [rsp+0x30], xmm3
00007aa9b5fe3ac4  vmovaps [rsp+0x40], xmm4
00007aa9b5fe3aca  vmovaps [rsp+0x50], xmm5
00007aa9b5fe3ad0  vmovaps [rsp+0x60], xmm6
00007aa9b5fe3ad6  vmovaps [rsp+0x70], xmm7
00007aa9b5fe3adc  vmovaps [rsp+0x80], xmm8
00007aa9b5fe3ae5  vmovaps [rsp+0x90], xmm9
00007aa9b5fe3aee  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe3af7  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe3b00  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe3b09  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe3b12  vmovaps [rsp+0xE0], xmm14
00007aa9b5fe3b1b  sub rsp, 0x30
00007aa9b5fe3b1f  movaps [rsp], xmm15
00007aa9b5fe3b24  movaps [rsp+0x10], xmm11
00007aa9b5fe3b2a  movaps [rsp+0x20], xmm6
00007aa9b5fe3b2f  lea rdi, [rsp]
00007aa9b5fe3b33  mov esi, 0x00
00007aa9b5fe3b38  mov rax, 0x63E0217C9530
00007aa9b5fe3b42  call rax
00007aa9b5fe3b44  movaps xmm15, [rsp]
00007aa9b5fe3b49  add rsp, 0x30
00007aa9b5fe3b4d  vmovaps xmm0, [rsp]
00007aa9b5fe3b52  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe3b58  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe3b5e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe3b64  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe3b6a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe3b70  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe3b76  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe3b7c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe3b85  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe3b8e  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe3b97  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe3ba0  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe3ba9  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe3bb2  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fe3bbb  add rsp, 0xF0
00007aa9b5fe3bc2  pop r11
00007aa9b5fe3bc4  pop r10
00007aa9b5fe3bc6  pop r9
00007aa9b5fe3bc8  pop r8
00007aa9b5fe3bca  pop rsi
00007aa9b5fe3bcb  pop rdi
00007aa9b5fe3bcc  pop rdx
00007aa9b5fe3bcd  pop rcx
00007aa9b5fe3bce  pop rax
00007aa9b5fe3bcf  add rsp, 0x08
00007aa9b5fe3bd3  jmp 0x00007AA9B5FDF838
00007aa9b5fe3bd8  sub rsp, 0x08
00007aa9b5fe3bdc  push rax
00007aa9b5fe3bdd  push rcx
00007aa9b5fe3bde  push rdx
00007aa9b5fe3bdf  push rdi
00007aa9b5fe3be0  push rsi
00007aa9b5fe3be1  push r8
00007aa9b5fe3be3  push r9
00007aa9b5fe3be5  push r10
00007aa9b5fe3be7  push r11
00007aa9b5fe3be9  sub rsp, 0xF0
00007aa9b5fe3bf0  vmovaps [rsp], xmm0
00007aa9b5fe3bf5  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3bfb  vmovaps [rsp+0x20], xmm2
00007aa9b5fe3c01  vmovaps [rsp+0x30], xmm3
00007aa9b5fe3c07  vmovaps [rsp+0x40], xmm4
00007aa9b5fe3c0d  vmovaps [rsp+0x50], xmm5
00007aa9b5fe3c13  vmovaps [rsp+0x60], xmm6
00007aa9b5fe3c19  vmovaps [rsp+0x70], xmm8
00007aa9b5fe3c1f  vmovaps [rsp+0x80], xmm9
00007aa9b5fe3c28  vmovaps [rsp+0x90], xmm10
00007aa9b5fe3c31  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe3c3a  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe3c43  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe3c4c  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe3c55  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe3c5e  sub rsp, 0x30
00007aa9b5fe3c62  movaps [rsp], xmm7
00007aa9b5fe3c66  movaps [rsp+0x10], xmm11
00007aa9b5fe3c6c  movaps [rsp+0x20], xmm9
00007aa9b5fe3c72  lea rdi, [rsp]
00007aa9b5fe3c76  mov esi, 0x00
00007aa9b5fe3c7b  mov rax, 0x63E0217C9530
00007aa9b5fe3c85  call rax
00007aa9b5fe3c87  movaps xmm7, [rsp]
00007aa9b5fe3c8b  add rsp, 0x30
00007aa9b5fe3c8f  vmovaps xmm0, [rsp]
00007aa9b5fe3c94  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe3c9a  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe3ca0  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe3ca6  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe3cac  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe3cb2  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe3cb8  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe3cbe  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe3cc7  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe3cd0  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe3cd9  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe3ce2  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe3ceb  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe3cf4  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe3cfd  add rsp, 0xF0
00007aa9b5fe3d04  pop r11
00007aa9b5fe3d06  pop r10
00007aa9b5fe3d08  pop r9
00007aa9b5fe3d0a  pop r8
00007aa9b5fe3d0c  pop rsi
00007aa9b5fe3d0d  pop rdi
00007aa9b5fe3d0e  pop rdx
00007aa9b5fe3d0f  pop rcx
00007aa9b5fe3d10  pop rax
00007aa9b5fe3d11  add rsp, 0x08
00007aa9b5fe3d15  jmp 0x00007AA9B5FDF865
00007aa9b5fe3d1a  sub rsp, 0x08
00007aa9b5fe3d1e  push rax
00007aa9b5fe3d1f  push rcx
00007aa9b5fe3d20  push rdx
00007aa9b5fe3d21  push rdi
00007aa9b5fe3d22  push rsi
00007aa9b5fe3d23  push r8
00007aa9b5fe3d25  push r9
00007aa9b5fe3d27  push r10
00007aa9b5fe3d29  push r11
00007aa9b5fe3d2b  sub rsp, 0xF0
00007aa9b5fe3d32  vmovaps [rsp], xmm0
00007aa9b5fe3d37  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3d3d  vmovaps [rsp+0x20], xmm2
00007aa9b5fe3d43  vmovaps [rsp+0x30], xmm3
00007aa9b5fe3d49  vmovaps [rsp+0x40], xmm4
00007aa9b5fe3d4f  vmovaps [rsp+0x50], xmm5
00007aa9b5fe3d55  vmovaps [rsp+0x60], xmm6
00007aa9b5fe3d5b  vmovaps [rsp+0x70], xmm7
00007aa9b5fe3d61  vmovaps [rsp+0x80], xmm8
00007aa9b5fe3d6a  vmovaps [rsp+0x90], xmm9
00007aa9b5fe3d73  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe3d7c  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe3d85  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe3d8e  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe3d97  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe3da0  sub rsp, 0x30
00007aa9b5fe3da4  movaps [rsp], xmm11
00007aa9b5fe3da9  movaps [rsp+0x10], xmm10
00007aa9b5fe3daf  movaps [rsp+0x20], xmm14
00007aa9b5fe3db5  lea rdi, [rsp]
00007aa9b5fe3db9  mov esi, 0x00
00007aa9b5fe3dbe  mov rax, 0x63E0217C9530
00007aa9b5fe3dc8  call rax
00007aa9b5fe3dca  movaps xmm11, [rsp]
00007aa9b5fe3dcf  add rsp, 0x30
00007aa9b5fe3dd3  vmovaps xmm0, [rsp]
00007aa9b5fe3dd8  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe3dde  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe3de4  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe3dea  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe3df0  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe3df6  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe3dfc  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe3e02  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe3e0b  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe3e14  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe3e1d  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe3e26  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe3e2f  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe3e38  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe3e41  add rsp, 0xF0
00007aa9b5fe3e48  pop r11
00007aa9b5fe3e4a  pop r10
00007aa9b5fe3e4c  pop r9
00007aa9b5fe3e4e  pop r8
00007aa9b5fe3e50  pop rsi
00007aa9b5fe3e51  pop rdi
00007aa9b5fe3e52  pop rdx
00007aa9b5fe3e53  pop rcx
00007aa9b5fe3e54  pop rax
00007aa9b5fe3e55  add rsp, 0x08
00007aa9b5fe3e59  jmp 0x00007AA9B5FDF880
00007aa9b5fe3e5e  call 0x00007AA9B5EC33A0
00007aa9b5fe3e63  jmp 0x00007AA9B5FDF88A
00007aa9b5fe3e68  sub rsp, 0x08
00007aa9b5fe3e6c  push rax
00007aa9b5fe3e6d  push rcx
00007aa9b5fe3e6e  push rdx
00007aa9b5fe3e6f  push rdi
00007aa9b5fe3e70  push rsi
00007aa9b5fe3e71  push r8
00007aa9b5fe3e73  push r9
00007aa9b5fe3e75  push r10
00007aa9b5fe3e77  push r11
00007aa9b5fe3e79  sub rsp, 0xF0
00007aa9b5fe3e80  vmovaps [rsp], xmm0
00007aa9b5fe3e85  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3e8b  vmovaps [rsp+0x20], xmm2
00007aa9b5fe3e91  vmovaps [rsp+0x30], xmm3
00007aa9b5fe3e97  vmovaps [rsp+0x40], xmm4
00007aa9b5fe3e9d  vmovaps [rsp+0x50], xmm5
00007aa9b5fe3ea3  vmovaps [rsp+0x60], xmm6
00007aa9b5fe3ea9  vmovaps [rsp+0x70], xmm7
00007aa9b5fe3eaf  vmovaps [rsp+0x80], xmm8
00007aa9b5fe3eb8  vmovaps [rsp+0x90], xmm9
00007aa9b5fe3ec1  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe3eca  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe3ed3  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe3edc  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe3ee5  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe3eee  sub rsp, 0x30
00007aa9b5fe3ef2  movaps [rsp], xmm10
00007aa9b5fe3ef7  movaps [rsp+0x10], xmm1
00007aa9b5fe3efc  movaps [rsp+0x20], xmm12
00007aa9b5fe3f02  lea rdi, [rsp]
00007aa9b5fe3f06  mov esi, 0x00
00007aa9b5fe3f0b  mov rax, 0x63E0217C9530
00007aa9b5fe3f15  call rax
00007aa9b5fe3f17  movaps xmm10, [rsp]
00007aa9b5fe3f1c  add rsp, 0x30
00007aa9b5fe3f20  vmovaps xmm0, [rsp]
00007aa9b5fe3f25  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe3f2b  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe3f31  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe3f37  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe3f3d  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe3f43  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe3f49  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe3f4f  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe3f58  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe3f61  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe3f6a  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe3f73  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe3f7c  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe3f85  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe3f8e  add rsp, 0xF0
00007aa9b5fe3f95  pop r11
00007aa9b5fe3f97  pop r10
00007aa9b5fe3f99  pop r9
00007aa9b5fe3f9b  pop r8
00007aa9b5fe3f9d  pop rsi
00007aa9b5fe3f9e  pop rdi
00007aa9b5fe3f9f  pop rdx
00007aa9b5fe3fa0  pop rcx
00007aa9b5fe3fa1  pop rax
00007aa9b5fe3fa2  add rsp, 0x08
00007aa9b5fe3fa6  jmp 0x00007AA9B5FDF8AD
00007aa9b5fe3fab  sub rsp, 0x08
00007aa9b5fe3faf  push rax
00007aa9b5fe3fb0  push rcx
00007aa9b5fe3fb1  push rdx
00007aa9b5fe3fb2  push rdi
00007aa9b5fe3fb3  push rsi
00007aa9b5fe3fb4  push r8
00007aa9b5fe3fb6  push r9
00007aa9b5fe3fb8  push r10
00007aa9b5fe3fba  push r11
00007aa9b5fe3fbc  sub rsp, 0xF0
00007aa9b5fe3fc3  vmovaps [rsp], xmm0
00007aa9b5fe3fc8  vmovaps [rsp+0x10], xmm1
00007aa9b5fe3fce  vmovaps [rsp+0x20], xmm2
00007aa9b5fe3fd4  vmovaps [rsp+0x30], xmm3
00007aa9b5fe3fda  vmovaps [rsp+0x40], xmm4
00007aa9b5fe3fe0  vmovaps [rsp+0x50], xmm5
00007aa9b5fe3fe6  vmovaps [rsp+0x60], xmm6
00007aa9b5fe3fec  vmovaps [rsp+0x70], xmm7
00007aa9b5fe3ff2  vmovaps [rsp+0x80], xmm8
00007aa9b5fe3ffb  vmovaps [rsp+0x90], xmm9
00007aa9b5fe4004  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe400d  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe4016  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe401f  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe4028  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe4031  sub rsp, 0x30
00007aa9b5fe4035  movaps [rsp], xmm12
00007aa9b5fe403a  movaps [rsp+0x10], xmm14
00007aa9b5fe4040  movaps [rsp+0x20], xmm1
00007aa9b5fe4045  lea rdi, [rsp]
00007aa9b5fe4049  mov esi, 0x00
00007aa9b5fe404e  mov rax, 0x63E0217C9530
00007aa9b5fe4058  call rax
00007aa9b5fe405a  movaps xmm12, [rsp]
00007aa9b5fe405f  add rsp, 0x30
00007aa9b5fe4063  vmovaps xmm0, [rsp]
00007aa9b5fe4068  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe406e  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe4074  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe407a  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe4080  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe4086  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe408c  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe4092  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe409b  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe40a4  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe40ad  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe40b6  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe40bf  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe40c8  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe40d1  add rsp, 0xF0
00007aa9b5fe40d8  pop r11
00007aa9b5fe40da  pop r10
00007aa9b5fe40dc  pop r9
00007aa9b5fe40de  pop r8
00007aa9b5fe40e0  pop rsi
00007aa9b5fe40e1  pop rdi
00007aa9b5fe40e2  pop rdx
00007aa9b5fe40e3  pop rcx
00007aa9b5fe40e4  pop rax
00007aa9b5fe40e5  add rsp, 0x08
00007aa9b5fe40e9  jmp 0x00007AA9B5FDF8DC
00007aa9b5fe40ee  sub rsp, 0x08
00007aa9b5fe40f2  push rax
00007aa9b5fe40f3  push rcx
00007aa9b5fe40f4  push rdx
00007aa9b5fe40f5  push rdi
00007aa9b5fe40f6  push rsi
00007aa9b5fe40f7  push r8
00007aa9b5fe40f9  push r9
00007aa9b5fe40fb  push r10
00007aa9b5fe40fd  push r11
00007aa9b5fe40ff  sub rsp, 0xF0
00007aa9b5fe4106  vmovaps [rsp], xmm0
00007aa9b5fe410b  vmovaps [rsp+0x10], xmm1
00007aa9b5fe4111  vmovaps [rsp+0x20], xmm2
00007aa9b5fe4117  vmovaps [rsp+0x30], xmm3
00007aa9b5fe411d  vmovaps [rsp+0x40], xmm4
00007aa9b5fe4123  vmovaps [rsp+0x50], xmm5
00007aa9b5fe4129  vmovaps [rsp+0x60], xmm6
00007aa9b5fe412f  vmovaps [rsp+0x70], xmm7
00007aa9b5fe4135  vmovaps [rsp+0x80], xmm8
00007aa9b5fe413e  vmovaps [rsp+0x90], xmm9
00007aa9b5fe4147  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe4150  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe4159  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe4162  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe416b  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe4174  sub rsp, 0x30
00007aa9b5fe4178  movaps [rsp], xmm14
00007aa9b5fe417d  movaps [rsp+0x10], xmm9
00007aa9b5fe4183  movaps [rsp+0x20], xmm1
00007aa9b5fe4188  lea rdi, [rsp]
00007aa9b5fe418c  mov esi, 0x00
00007aa9b5fe4191  mov rax, 0x63E0217C9530
00007aa9b5fe419b  call rax
00007aa9b5fe419d  movaps xmm14, [rsp]
00007aa9b5fe41a2  add rsp, 0x30
00007aa9b5fe41a6  vmovaps xmm0, [rsp]
00007aa9b5fe41ab  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe41b1  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe41b7  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe41bd  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe41c3  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe41c9  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe41cf  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe41d5  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe41de  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe41e7  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe41f0  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe41f9  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe4202  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe420b  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe4214  add rsp, 0xF0
00007aa9b5fe421b  pop r11
00007aa9b5fe421d  pop r10
00007aa9b5fe421f  pop r9
00007aa9b5fe4221  pop r8
00007aa9b5fe4223  pop rsi
00007aa9b5fe4224  pop rdi
00007aa9b5fe4225  pop rdx
00007aa9b5fe4226  pop rcx
00007aa9b5fe4227  pop rax
00007aa9b5fe4228  add rsp, 0x08
00007aa9b5fe422c  jmp 0x00007AA9B5FDF90B
00007aa9b5fe4231  sub rsp, 0x08
00007aa9b5fe4235  push rax
00007aa9b5fe4236  push rcx
00007aa9b5fe4237  push rdx
00007aa9b5fe4238  push rdi
00007aa9b5fe4239  push rsi
00007aa9b5fe423a  push r8
00007aa9b5fe423c  push r9
00007aa9b5fe423e  push r10
00007aa9b5fe4240  push r11
00007aa9b5fe4242  sub rsp, 0xF0
00007aa9b5fe4249  vmovaps [rsp], xmm0
00007aa9b5fe424e  vmovaps [rsp+0x10], xmm2
00007aa9b5fe4254  vmovaps [rsp+0x20], xmm3
00007aa9b5fe425a  vmovaps [rsp+0x30], xmm4
00007aa9b5fe4260  vmovaps [rsp+0x40], xmm5
00007aa9b5fe4266  vmovaps [rsp+0x50], xmm6
00007aa9b5fe426c  vmovaps [rsp+0x60], xmm7
00007aa9b5fe4272  vmovaps [rsp+0x70], xmm8
00007aa9b5fe4278  vmovaps [rsp+0x80], xmm9
00007aa9b5fe4281  vmovaps [rsp+0x90], xmm10
00007aa9b5fe428a  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe4293  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe429c  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe42a5  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe42ae  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe42b7  sub rsp, 0x30
00007aa9b5fe42bb  movaps [rsp], xmm1
00007aa9b5fe42bf  movaps [rsp+0x10], xmm13
00007aa9b5fe42c5  movaps [rsp+0x20], xmm8
00007aa9b5fe42cb  lea rdi, [rsp]
00007aa9b5fe42cf  mov esi, 0x00
00007aa9b5fe42d4  mov rax, 0x63E0217C9530
00007aa9b5fe42de  call rax
00007aa9b5fe42e0  movaps xmm1, [rsp]
00007aa9b5fe42e4  add rsp, 0x30
00007aa9b5fe42e8  vmovaps xmm0, [rsp]
00007aa9b5fe42ed  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe42f3  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe42f9  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe42ff  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe4305  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe430b  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe4311  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe4317  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe4320  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe4329  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe4332  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe433b  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe4344  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe434d  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe4356  add rsp, 0xF0
00007aa9b5fe435d  pop r11
00007aa9b5fe435f  pop r10
00007aa9b5fe4361  pop r9
00007aa9b5fe4363  pop r8
00007aa9b5fe4365  pop rsi
00007aa9b5fe4366  pop rdi
00007aa9b5fe4367  pop rdx
00007aa9b5fe4368  pop rcx
00007aa9b5fe4369  pop rax
00007aa9b5fe436a  add rsp, 0x08
00007aa9b5fe436e  jmp 0x00007AA9B5FDF92D
00007aa9b5fe4373  call 0x00007AA9B5E0C260
00007aa9b5fe4378  jmp 0x00007AA9B5FDF93B
00007aa9b5fe437d  call 0x00007AA9B5EBD750
00007aa9b5fe4382  jmp 0x00007AA9B5FDF945
00007aa9b5fe4387  sub rsp, 0x08
00007aa9b5fe438b  push rax
00007aa9b5fe438c  push rcx
00007aa9b5fe438d  push rdx
00007aa9b5fe438e  push rdi
00007aa9b5fe438f  push rsi
00007aa9b5fe4390  push r8
00007aa9b5fe4392  push r9
00007aa9b5fe4394  push r10
00007aa9b5fe4396  push r11
00007aa9b5fe4398  sub rsp, 0xF0
00007aa9b5fe439f  vmovaps [rsp], xmm0
00007aa9b5fe43a4  vmovaps [rsp+0x10], xmm1
00007aa9b5fe43aa  vmovaps [rsp+0x20], xmm2
00007aa9b5fe43b0  vmovaps [rsp+0x30], xmm3
00007aa9b5fe43b6  vmovaps [rsp+0x40], xmm4
00007aa9b5fe43bc  vmovaps [rsp+0x50], xmm5
00007aa9b5fe43c2  vmovaps [rsp+0x60], xmm6
00007aa9b5fe43c8  vmovaps [rsp+0x70], xmm7
00007aa9b5fe43ce  vmovaps [rsp+0x80], xmm9
00007aa9b5fe43d7  vmovaps [rsp+0x90], xmm10
00007aa9b5fe43e0  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe43e9  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe43f2  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe43fb  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe4404  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe440d  sub rsp, 0x30
00007aa9b5fe4411  movaps [rsp], xmm8
00007aa9b5fe4416  movaps [rsp+0x10], xmm15
00007aa9b5fe441c  movaps [rsp+0x20], xmm7
00007aa9b5fe4421  lea rdi, [rsp]
00007aa9b5fe4425  mov esi, 0x00
00007aa9b5fe442a  mov rax, 0x63E0217C9530
00007aa9b5fe4434  call rax
00007aa9b5fe4436  movaps xmm8, [rsp]
00007aa9b5fe443b  add rsp, 0x30
00007aa9b5fe443f  vmovaps xmm0, [rsp]
00007aa9b5fe4444  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe444a  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe4450  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe4456  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe445c  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe4462  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe4468  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe446e  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe4477  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe4480  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe4489  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe4492  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe449b  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe44a4  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe44ad  add rsp, 0xF0
00007aa9b5fe44b4  pop r11
00007aa9b5fe44b6  pop r10
00007aa9b5fe44b8  pop r9
00007aa9b5fe44ba  pop r8
00007aa9b5fe44bc  pop rsi
00007aa9b5fe44bd  pop rdi
00007aa9b5fe44be  pop rdx
00007aa9b5fe44bf  pop rcx
00007aa9b5fe44c0  pop rax
00007aa9b5fe44c1  add rsp, 0x08
00007aa9b5fe44c5  jmp 0x00007AA9B5FDF967
00007aa9b5fe44ca  sub rsp, 0x08
00007aa9b5fe44ce  push rax
00007aa9b5fe44cf  push rcx
00007aa9b5fe44d0  push rdx
00007aa9b5fe44d1  push rdi
00007aa9b5fe44d2  push rsi
00007aa9b5fe44d3  push r8
00007aa9b5fe44d5  push r9
00007aa9b5fe44d7  push r10
00007aa9b5fe44d9  push r11
00007aa9b5fe44db  sub rsp, 0xF0
00007aa9b5fe44e2  vmovaps [rsp], xmm0
00007aa9b5fe44e7  vmovaps [rsp+0x10], xmm1
00007aa9b5fe44ed  vmovaps [rsp+0x20], xmm2
00007aa9b5fe44f3  vmovaps [rsp+0x30], xmm3
00007aa9b5fe44f9  vmovaps [rsp+0x40], xmm4
00007aa9b5fe44ff  vmovaps [rsp+0x50], xmm5
00007aa9b5fe4505  vmovaps [rsp+0x60], xmm6
00007aa9b5fe450b  vmovaps [rsp+0x70], xmm8
00007aa9b5fe4511  vmovaps [rsp+0x80], xmm9
00007aa9b5fe451a  vmovaps [rsp+0x90], xmm10
00007aa9b5fe4523  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe452c  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe4535  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe453e  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe4547  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe4550  sub rsp, 0x30
00007aa9b5fe4554  movaps [rsp], xmm7
00007aa9b5fe4558  movaps [rsp+0x10], xmm9
00007aa9b5fe455e  movaps [rsp+0x20], xmm15
00007aa9b5fe4564  lea rdi, [rsp]
00007aa9b5fe4568  mov esi, 0x00
00007aa9b5fe456d  mov rax, 0x63E0217C9530
00007aa9b5fe4577  call rax
00007aa9b5fe4579  movaps xmm7, [rsp]
00007aa9b5fe457d  add rsp, 0x30
00007aa9b5fe4581  vmovaps xmm0, [rsp]
00007aa9b5fe4586  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe458c  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe4592  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe4598  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe459e  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe45a4  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe45aa  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe45b0  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe45b9  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe45c2  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe45cb  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe45d4  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe45dd  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe45e6  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe45ef  add rsp, 0xF0
00007aa9b5fe45f6  pop r11
00007aa9b5fe45f8  pop r10
00007aa9b5fe45fa  pop r9
00007aa9b5fe45fc  pop r8
00007aa9b5fe45fe  pop rsi
00007aa9b5fe45ff  pop rdi
00007aa9b5fe4600  pop rdx
00007aa9b5fe4601  pop rcx
00007aa9b5fe4602  pop rax
00007aa9b5fe4603  add rsp, 0x08
00007aa9b5fe4607  jmp 0x00007AA9B5FDF994
00007aa9b5fe460c  sub rsp, 0x08
00007aa9b5fe4610  push rax
00007aa9b5fe4611  push rcx
00007aa9b5fe4612  push rdx
00007aa9b5fe4613  push rdi
00007aa9b5fe4614  push rsi
00007aa9b5fe4615  push r8
00007aa9b5fe4617  push r9
00007aa9b5fe4619  push r10
00007aa9b5fe461b  push r11
00007aa9b5fe461d  sub rsp, 0xF0
00007aa9b5fe4624  vmovaps [rsp], xmm0
00007aa9b5fe4629  vmovaps [rsp+0x10], xmm1
00007aa9b5fe462f  vmovaps [rsp+0x20], xmm2
00007aa9b5fe4635  vmovaps [rsp+0x30], xmm3
00007aa9b5fe463b  vmovaps [rsp+0x40], xmm4
00007aa9b5fe4641  vmovaps [rsp+0x50], xmm5
00007aa9b5fe4647  vmovaps [rsp+0x60], xmm6
00007aa9b5fe464d  vmovaps [rsp+0x70], xmm7
00007aa9b5fe4653  vmovaps [rsp+0x80], xmm8
00007aa9b5fe465c  vmovaps [rsp+0x90], xmm10
00007aa9b5fe4665  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe466e  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe4677  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe4680  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe4689  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe4692  sub rsp, 0x30
00007aa9b5fe4696  movaps [rsp], xmm9
00007aa9b5fe469b  movaps [rsp+0x10], xmm13
00007aa9b5fe46a1  movaps [rsp+0x20], xmm15
00007aa9b5fe46a7  lea rdi, [rsp]
00007aa9b5fe46ab  mov esi, 0x00
00007aa9b5fe46b0  mov rax, 0x63E0217C9530
00007aa9b5fe46ba  call rax
00007aa9b5fe46bc  movaps xmm9, [rsp]
00007aa9b5fe46c1  add rsp, 0x30
00007aa9b5fe46c5  vmovaps xmm0, [rsp]
00007aa9b5fe46ca  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe46d0  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe46d6  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe46dc  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe46e2  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe46e8  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe46ee  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe46f4  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe46fd  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe4706  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe470f  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe4718  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe4721  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe472a  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe4733  add rsp, 0xF0
00007aa9b5fe473a  pop r11
00007aa9b5fe473c  pop r10
00007aa9b5fe473e  pop r9
00007aa9b5fe4740  pop r8
00007aa9b5fe4742  pop rsi
00007aa9b5fe4743  pop rdi
00007aa9b5fe4744  pop rdx
00007aa9b5fe4745  pop rcx
00007aa9b5fe4746  pop rax
00007aa9b5fe4747  add rsp, 0x08
00007aa9b5fe474b  jmp 0x00007AA9B5FDF9C2
00007aa9b5fe4750  sub rsp, 0x08
00007aa9b5fe4754  push rax
00007aa9b5fe4755  push rcx
00007aa9b5fe4756  push rdx
00007aa9b5fe4757  push rdi
00007aa9b5fe4758  push rsi
00007aa9b5fe4759  push r8
00007aa9b5fe475b  push r9
00007aa9b5fe475d  push r10
00007aa9b5fe475f  push r11
00007aa9b5fe4761  sub rsp, 0xF0
00007aa9b5fe4768  vmovaps [rsp], xmm0
00007aa9b5fe476d  vmovaps [rsp+0x10], xmm1
00007aa9b5fe4773  vmovaps [rsp+0x20], xmm2
00007aa9b5fe4779  vmovaps [rsp+0x30], xmm3
00007aa9b5fe477f  vmovaps [rsp+0x40], xmm4
00007aa9b5fe4785  vmovaps [rsp+0x50], xmm5
00007aa9b5fe478b  vmovaps [rsp+0x60], xmm6
00007aa9b5fe4791  vmovaps [rsp+0x70], xmm7
00007aa9b5fe4797  vmovaps [rsp+0x80], xmm8
00007aa9b5fe47a0  vmovaps [rsp+0x90], xmm9
00007aa9b5fe47a9  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe47b2  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe47bb  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe47c4  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe47cd  vmovaps [rsp+0xE0], xmm14
00007aa9b5fe47d6  sub rsp, 0x30
00007aa9b5fe47da  movaps [rsp], xmm15
00007aa9b5fe47df  movaps [rsp+0x10], xmm11
00007aa9b5fe47e5  movaps [rsp+0x20], xmm12
00007aa9b5fe47eb  lea rdi, [rsp]
00007aa9b5fe47ef  mov esi, 0x00
00007aa9b5fe47f4  mov rax, 0x63E0217C9530
00007aa9b5fe47fe  call rax
00007aa9b5fe4800  movaps xmm15, [rsp]
00007aa9b5fe4805  add rsp, 0x30
00007aa9b5fe4809  vmovaps xmm0, [rsp]
00007aa9b5fe480e  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe4814  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe481a  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe4820  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe4826  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe482c  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe4832  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe4838  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe4841  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe484a  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe4853  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe485c  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe4865  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe486e  vmovaps xmm14, [rsp+0xE0]
00007aa9b5fe4877  add rsp, 0xF0
00007aa9b5fe487e  pop r11
00007aa9b5fe4880  pop r10
00007aa9b5fe4882  pop r9
00007aa9b5fe4884  pop r8
00007aa9b5fe4886  pop rsi
00007aa9b5fe4887  pop rdi
00007aa9b5fe4888  pop rdx
00007aa9b5fe4889  pop rcx
00007aa9b5fe488a  pop rax
00007aa9b5fe488b  add rsp, 0x08
00007aa9b5fe488f  jmp 0x00007AA9B5FDF9DD
00007aa9b5fe4894  sub rsp, 0x08
00007aa9b5fe4898  push rax
00007aa9b5fe4899  push rcx
00007aa9b5fe489a  push rdx
00007aa9b5fe489b  push rdi
00007aa9b5fe489c  push rsi
00007aa9b5fe489d  push r8
00007aa9b5fe489f  push r9
00007aa9b5fe48a1  push r10
00007aa9b5fe48a3  push r11
00007aa9b5fe48a5  sub rsp, 0xF0
00007aa9b5fe48ac  vmovaps [rsp], xmm0
00007aa9b5fe48b1  vmovaps [rsp+0x10], xmm1
00007aa9b5fe48b7  vmovaps [rsp+0x20], xmm2
00007aa9b5fe48bd  vmovaps [rsp+0x30], xmm3
00007aa9b5fe48c3  vmovaps [rsp+0x40], xmm4
00007aa9b5fe48c9  vmovaps [rsp+0x50], xmm5
00007aa9b5fe48cf  vmovaps [rsp+0x60], xmm6
00007aa9b5fe48d5  vmovaps [rsp+0x70], xmm7
00007aa9b5fe48db  vmovaps [rsp+0x80], xmm8
00007aa9b5fe48e4  vmovaps [rsp+0x90], xmm9
00007aa9b5fe48ed  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe48f6  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe48ff  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe4908  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe4911  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe491a  sub rsp, 0x30
00007aa9b5fe491e  movaps [rsp], xmm13
00007aa9b5fe4923  movaps [rsp+0x10], xmm10
00007aa9b5fe4929  movaps [rsp+0x20], xmm14
00007aa9b5fe492f  lea rdi, [rsp]
00007aa9b5fe4933  mov esi, 0x00
00007aa9b5fe4938  mov rax, 0x63E0217C9530
00007aa9b5fe4942  call rax
00007aa9b5fe4944  movaps xmm13, [rsp]
00007aa9b5fe4949  add rsp, 0x30
00007aa9b5fe494d  vmovaps xmm0, [rsp]
00007aa9b5fe4952  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe4958  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe495e  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe4964  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe496a  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe4970  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe4976  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe497c  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe4985  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe498e  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe4997  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe49a0  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe49a9  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe49b2  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe49bb  add rsp, 0xF0
00007aa9b5fe49c2  pop r11
00007aa9b5fe49c4  pop r10
00007aa9b5fe49c6  pop r9
00007aa9b5fe49c8  pop r8
00007aa9b5fe49ca  pop rsi
00007aa9b5fe49cb  pop rdi
00007aa9b5fe49cc  pop rdx
00007aa9b5fe49cd  pop rcx
00007aa9b5fe49ce  pop rax
00007aa9b5fe49cf  add rsp, 0x08
00007aa9b5fe49d3  jmp 0x00007AA9B5FDFA00
00007aa9b5fe49d8  sub rsp, 0x08
00007aa9b5fe49dc  push rax
00007aa9b5fe49dd  push rcx
00007aa9b5fe49de  push rdx
00007aa9b5fe49df  push rdi
00007aa9b5fe49e0  push rsi
00007aa9b5fe49e1  push r8
00007aa9b5fe49e3  push r9
00007aa9b5fe49e5  push r10
00007aa9b5fe49e7  push r11
00007aa9b5fe49e9  sub rsp, 0xF0
00007aa9b5fe49f0  vmovaps [rsp], xmm0
00007aa9b5fe49f5  vmovaps [rsp+0x10], xmm1
00007aa9b5fe49fb  vmovaps [rsp+0x20], xmm2
00007aa9b5fe4a01  vmovaps [rsp+0x30], xmm3
00007aa9b5fe4a07  vmovaps [rsp+0x40], xmm4
00007aa9b5fe4a0d  vmovaps [rsp+0x50], xmm5
00007aa9b5fe4a13  vmovaps [rsp+0x60], xmm6
00007aa9b5fe4a19  vmovaps [rsp+0x70], xmm7
00007aa9b5fe4a1f  vmovaps [rsp+0x80], xmm8
00007aa9b5fe4a28  vmovaps [rsp+0x90], xmm9
00007aa9b5fe4a31  vmovaps [rsp+0xA0], xmm10
00007aa9b5fe4a3a  vmovaps [rsp+0xB0], xmm11
00007aa9b5fe4a43  vmovaps [rsp+0xC0], xmm12
00007aa9b5fe4a4c  vmovaps [rsp+0xD0], xmm13
00007aa9b5fe4a55  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe4a5e  sub rsp, 0x30
00007aa9b5fe4a62  movaps [rsp], xmm14
00007aa9b5fe4a67  movaps [rsp+0x10], xmm1
00007aa9b5fe4a6c  movaps [rsp+0x20], xmm7
00007aa9b5fe4a71  lea rdi, [rsp]
00007aa9b5fe4a75  mov esi, 0x00
00007aa9b5fe4a7a  mov rax, 0x63E0217C9530
00007aa9b5fe4a84  call rax
00007aa9b5fe4a86  movaps xmm14, [rsp]
00007aa9b5fe4a8b  add rsp, 0x30
00007aa9b5fe4a8f  vmovaps xmm0, [rsp]
00007aa9b5fe4a94  vmovaps xmm1, [rsp+0x10]
00007aa9b5fe4a9a  vmovaps xmm2, [rsp+0x20]
00007aa9b5fe4aa0  vmovaps xmm3, [rsp+0x30]
00007aa9b5fe4aa6  vmovaps xmm4, [rsp+0x40]
00007aa9b5fe4aac  vmovaps xmm5, [rsp+0x50]
00007aa9b5fe4ab2  vmovaps xmm6, [rsp+0x60]
00007aa9b5fe4ab8  vmovaps xmm7, [rsp+0x70]
00007aa9b5fe4abe  vmovaps xmm8, [rsp+0x80]
00007aa9b5fe4ac7  vmovaps xmm9, [rsp+0x90]
00007aa9b5fe4ad0  vmovaps xmm10, [rsp+0xA0]
00007aa9b5fe4ad9  vmovaps xmm11, [rsp+0xB0]
00007aa9b5fe4ae2  vmovaps xmm12, [rsp+0xC0]
00007aa9b5fe4aeb  vmovaps xmm13, [rsp+0xD0]
00007aa9b5fe4af4  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe4afd  add rsp, 0xF0
00007aa9b5fe4b04  pop r11
00007aa9b5fe4b06  pop r10
00007aa9b5fe4b08  pop r9
00007aa9b5fe4b0a  pop r8
00007aa9b5fe4b0c  pop rsi
00007aa9b5fe4b0d  pop rdi
00007aa9b5fe4b0e  pop rdx
00007aa9b5fe4b0f  pop rcx
00007aa9b5fe4b10  pop rax
00007aa9b5fe4b11  add rsp, 0x08
00007aa9b5fe4b15  jmp 0x00007AA9B5FDFA23
00007aa9b5fe4b1a  sub rsp, 0x08
00007aa9b5fe4b1e  push rax
00007aa9b5fe4b1f  push rcx
00007aa9b5fe4b20  push rdx
00007aa9b5fe4b21  push rdi
00007aa9b5fe4b22  push rsi
00007aa9b5fe4b23  push r8
00007aa9b5fe4b25  push r9
00007aa9b5fe4b27  push r10
00007aa9b5fe4b29  push r11
00007aa9b5fe4b2b  sub rsp, 0xF0
00007aa9b5fe4b32  vmovaps [rsp], xmm0
00007aa9b5fe4b37  vmovaps [rsp+0x10], xmm2
00007aa9b5fe4b3d  vmovaps [rsp+0x20], xmm3
00007aa9b5fe4b43  vmovaps [rsp+0x30], xmm4
00007aa9b5fe4b49  vmovaps [rsp+0x40], xmm5
00007aa9b5fe4b4f  vmovaps [rsp+0x50], xmm6
00007aa9b5fe4b55  vmovaps [rsp+0x60], xmm7
00007aa9b5fe4b5b  vmovaps [rsp+0x70], xmm8
00007aa9b5fe4b61  vmovaps [rsp+0x80], xmm9
00007aa9b5fe4b6a  vmovaps [rsp+0x90], xmm10
00007aa9b5fe4b73  vmovaps [rsp+0xA0], xmm11
00007aa9b5fe4b7c  vmovaps [rsp+0xB0], xmm12
00007aa9b5fe4b85  vmovaps [rsp+0xC0], xmm13
00007aa9b5fe4b8e  vmovaps [rsp+0xD0], xmm14
00007aa9b5fe4b97  vmovaps [rsp+0xE0], xmm15
00007aa9b5fe4ba0  sub rsp, 0x30
00007aa9b5fe4ba4  movaps [rsp], xmm1
00007aa9b5fe4ba8  movaps [rsp+0x10], xmm8
00007aa9b5fe4bae  movaps [rsp+0x20], xmm9
00007aa9b5fe4bb4  lea rdi, [rsp]
00007aa9b5fe4bb8  mov esi, 0x00
00007aa9b5fe4bbd  mov rax, 0x63E0217C9530
00007aa9b5fe4bc7  call rax
00007aa9b5fe4bc9  movaps xmm1, [rsp]
00007aa9b5fe4bcd  add rsp, 0x30
00007aa9b5fe4bd1  vmovaps xmm0, [rsp]
00007aa9b5fe4bd6  vmovaps xmm2, [rsp+0x10]
00007aa9b5fe4bdc  vmovaps xmm3, [rsp+0x20]
00007aa9b5fe4be2  vmovaps xmm4, [rsp+0x30]
00007aa9b5fe4be8  vmovaps xmm5, [rsp+0x40]
00007aa9b5fe4bee  vmovaps xmm6, [rsp+0x50]
00007aa9b5fe4bf4  vmovaps xmm7, [rsp+0x60]
00007aa9b5fe4bfa  vmovaps xmm8, [rsp+0x70]
00007aa9b5fe4c00  vmovaps xmm9, [rsp+0x80]
00007aa9b5fe4c09  vmovaps xmm10, [rsp+0x90]
00007aa9b5fe4c12  vmovaps xmm11, [rsp+0xA0]
00007aa9b5fe4c1b  vmovaps xmm12, [rsp+0xB0]
00007aa9b5fe4c24  vmovaps xmm13, [rsp+0xC0]
00007aa9b5fe4c2d  vmovaps xmm14, [rsp+0xD0]
00007aa9b5fe4c36  vmovaps xmm15, [rsp+0xE0]
00007aa9b5fe4c3f  add rsp, 0xF0
00007aa9b5fe4c46  pop r11
00007aa9b5fe4c48  pop r10
00007aa9b5fe4c4a  pop r9
00007aa9b5fe4c4c  pop r8
00007aa9b5fe4c4e  pop rsi
00007aa9b5fe4c4f  pop rdi
00007aa9b5fe4c50  pop rdx
00007aa9b5fe4c51  pop rcx
00007aa9b5fe4c52  pop rax
00007aa9b5fe4c53  add rsp, 0x08
00007aa9b5fe4c57  jmp 0x00007AA9B5FDFA45
00007aa9b5fe4c5c  call 0x00007AA9B5EE5940
00007aa9b5fe4c61  jmp 0x00007AA9B5FDFA53
00007aa9b5fe4c66  call 0x00007AA9B5E0C380
00007aa9b5fe4c6b  jmp 0x00007AA9B5FDFA5D
00007aa9b5fe4c70  call 0x00007AA9B5E0D600
00007aa9b5fe4c75  jmp 0x00007AA9B5FDFA67
00007aa9b5fe4c7a  call 0x00007AA9B5DFF540
00007aa9b5fe4c7f  jmp 0x00007AA9B5FDFA71
00007aa9b5fe4c84  int3
00007aa9b5fe4c85  nop [rax+rax*1], ax
00007aa9b5fe4c8e  nop
00007aa9b5fe4c90  mov qword ptr [r15+0x40], 0x430000
00007aa9b5fe4c98  mov eax, 0x430CC0
00007aa9b5fe4c9d  mov r14, [r13+rax*1]
00007aa9b5fe4ca2  movq xmm1, r14
00007aa9b5fe4ca7  mov rax, [r15+0x50]
00007aa9b5fe4cab  movups xmm15, [r13+rax*1]
00007aa9b5fe4cb1  movaps [r15+0x120], xmm15
00007aa9b5fe4cb9  mov qword ptr [r15+0x48], 0x10
00007aa9b5fe4cc1  xor eax, eax
00007aa9b5fe4cc3  mov r14d, 0x10
00007aa9b5fe4cc9  mov r12d, 0x200
00007aa9b5fe4ccf  cmp r14, r12
00007aa9b5fe4cd2  cmc
00007aa9b5fe4cd3  lahf
00007aa9b5fe4cd4  seto al
00007aa9b5fe4cd7  mov [r15+0x108], eax
00007aa9b5fe4cde  pextrq rax, xmm15, 0x01
00007aa9b5fe4ce5  movq xmm14, rax
00007aa9b5fe4cea  movaps [r15+0x130], xmm14
00007aa9b5fe4cf2  movq rax, xmm1
00007aa9b5fe4cf7  movq r14, xmm15
00007aa9b5fe4cfc  vmovq xmm1, rax
00007aa9b5fe4d01  vmovq xmm15, r14
00007aa9b5fe4d06  movaps xmm13, xmm1
00007aa9b5fe4d0a  addsd xmm13, xmm15
00007aa9b5fe4d0f  ucomisd xmm13, xmm13
00007aa9b5fe4d14  jp 0x00007AA9B5FE4DD3
00007aa9b5fe4d1a  movq xmm13, xmm13
00007aa9b5fe4d1f  movq rax, xmm13
00007aa9b5fe4d24  movq r14, xmm14
00007aa9b5fe4d29  vmovq xmm1, rax
00007aa9b5fe4d2e  vmovq xmm15, r14
00007aa9b5fe4d33  movaps xmm14, xmm1
00007aa9b5fe4d37  addsd xmm14, xmm15
00007aa9b5fe4d3c  ucomisd xmm14, xmm14
00007aa9b5fe4d41  jp 0x00007AA9B5FE4E1B
00007aa9b5fe4d47  movq xmm14, xmm14
00007aa9b5fe4d4c  movaps [r15+0x110], xmm14
00007aa9b5fe4d54  mov eax, [r15+0x108]
00007aa9b5fe4d5b  sahf
00007aa9b5fe4d5c  jnz 0x00007AA9B5FE4D8E
00007aa9b5fe4d5e  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fe4d66  jz 0x00007AA9B5FE5030
00007aa9b5fe4d6c  nop [rax+rax*1], ax
00007aa9b5fe4d75  nop [rax+rax*1], eax
00007aa9b5fe4d7d  mov eax, 0x410704
00007aa9b5fe4d82  mov [r15+0x100], rax
00007aa9b5fe4d89  jmp 0x00007AA9B5DFE110
00007aa9b5fe4d8e  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fe4d96  jz 0x00007AA9B5FE4E70
00007aa9b5fe4d9c  nop [rax+rax*1], ax
00007aa9b5fe4da5  nop [rax+rax*1], eax
00007aa9b5fe4dad  mov eax, 0x4106E8
00007aa9b5fe4db2  mov [r15+0x100], rax
00007aa9b5fe4db9  jmp 0x00007AA9B5DFE110
00007aa9b5fe4dbe  int3
00007aa9b5fe4dbf  call 0x00007AA9B5E0DC20
00007aa9b5fe4dc4  jmp 0x00007AA9B5FE4CA2
00007aa9b5fe4dc9  call 0x00007AA9B5E0E760
00007aa9b5fe4dce  jmp 0x00007AA9B5FE4CB1
00007aa9b5fe4dd3  ucomisd xmm1, xmm15
00007aa9b5fe4dd8  jp 0x00007AA9B5FE4DE7
00007aa9b5fe4dda  movaps xmm13, [0x00007AA9B5BFE060]
00007aa9b5fe4de2  jmp 0x00007AA9B5FE4D1A
00007aa9b5fe4de7  vxorps xmm0, xmm1, xmm15
00007aa9b5fe4dec  pextrw eax, xmm0, 0x03
00007aa9b5fe4df1  and eax, 0x7FF8
00007aa9b5fe4df6  cmp eax, 0x08
00007aa9b5fe4df9  jnz 0x00007AA9B5FE4D1A
00007aa9b5fe4dff  movq rax, xmm15
00007aa9b5fe4e04  shl rax, 0x0D
00007aa9b5fe4e08  jbe 0x00007AA9B5FE4D1A
00007aa9b5fe4e0e  vorps xmm13, xmm15, [0x00007AA9B5BFE070]
00007aa9b5fe4e16  jmp 0x00007AA9B5FE4D1A
00007aa9b5fe4e1b  ucomisd xmm1, xmm15
00007aa9b5fe4e20  jp 0x00007AA9B5FE4E2F
00007aa9b5fe4e22  movaps xmm14, [0x00007AA9B5BFE060]
00007aa9b5fe4e2a  jmp 0x00007AA9B5FE4D47
00007aa9b5fe4e2f  vxorps xmm0, xmm1, xmm15
00007aa9b5fe4e34  pextrw eax, xmm0, 0x03
00007aa9b5fe4e39  and eax, 0x7FF8
00007aa9b5fe4e3e  cmp eax, 0x08
00007aa9b5fe4e41  jnz 0x00007AA9B5FE4D47
00007aa9b5fe4e47  movq rax, xmm15
00007aa9b5fe4e4c  shl rax, 0x0D
00007aa9b5fe4e50  jbe 0x00007AA9B5FE4D47
00007aa9b5fe4e56  vorps xmm14, xmm15, [0x00007AA9B5BFE070]
00007aa9b5fe4e5e  jmp 0x00007AA9B5FE4D47
00007aa9b5fe4e63  int3
00007aa9b5fe4e64  nop [rax+rax*1], ax
00007aa9b5fe4e6d  nop [rax], eax
00007aa9b5fe4e70  mov rax, [r15+0x48]
00007aa9b5fe4e74  mov r14, [r15+0x50]
00007aa9b5fe4e78  lea r12, [r14+rax*1]
00007aa9b5fe4e7c  movups xmm1, [r13+r12*1]
00007aa9b5fe4e82  movaps [r15+0x120], xmm1
00007aa9b5fe4e8a  lea r14, [rax+0x10]
00007aa9b5fe4e8e  mov [r15+0x48], r14
00007aa9b5fe4e92  xor eax, eax
00007aa9b5fe4e94  mov r12d, 0x200
00007aa9b5fe4e9a  cmp r14, r12
00007aa9b5fe4e9d  cmc
00007aa9b5fe4e9e  lahf
00007aa9b5fe4e9f  seto al
00007aa9b5fe4ea2  mov [r15+0x108], eax
00007aa9b5fe4ea9  pextrq rax, xmm1, 0x01
00007aa9b5fe4eb0  movq xmm15, rax
00007aa9b5fe4eb5  movaps [r15+0x130], xmm15
00007aa9b5fe4ebd  movaps xmm14, [r15+0x110]
00007aa9b5fe4ec5  movq rax, xmm14
00007aa9b5fe4eca  movq r14, xmm1
00007aa9b5fe4ecf  vmovq xmm1, rax
00007aa9b5fe4ed4  vmovq xmm14, r14
00007aa9b5fe4ed9  movaps xmm13, xmm1
00007aa9b5fe4edd  addsd xmm13, xmm14
00007aa9b5fe4ee2  ucomisd xmm13, xmm13
00007aa9b5fe4ee7  jp 0x00007AA9B5FE4F9C
00007aa9b5fe4eed  movq xmm13, xmm13
00007aa9b5fe4ef2  movq rax, xmm13
00007aa9b5fe4ef7  movq r14, xmm15
00007aa9b5fe4efc  vmovq xmm1, rax
00007aa9b5fe4f01  vmovq xmm15, r14
00007aa9b5fe4f06  movaps xmm14, xmm1
00007aa9b5fe4f0a  addsd xmm14, xmm15
00007aa9b5fe4f0f  ucomisd xmm14, xmm14
00007aa9b5fe4f14  jp 0x00007AA9B5FE4FE4
00007aa9b5fe4f1a  movq xmm14, xmm14
00007aa9b5fe4f1f  movaps [r15+0x110], xmm14
00007aa9b5fe4f27  mov eax, [r15+0x108]
00007aa9b5fe4f2e  sahf
00007aa9b5fe4f2f  jnz 0x00007AA9B5FE4F61
00007aa9b5fe4f31  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fe4f39  jz 0x00007AA9B5FE5030
00007aa9b5fe4f3f  nop [rax+rax*1], ax
00007aa9b5fe4f48  nop [rax+rax*1], eax
00007aa9b5fe4f50  mov eax, 0x410704
00007aa9b5fe4f55  mov [r15+0x100], rax
00007aa9b5fe4f5c  jmp 0x00007AA9B5DFE110
00007aa9b5fe4f61  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fe4f69  jz 0x00007AA9B5FE4E70
00007aa9b5fe4f6f  nop [rax+rax*1], ax
00007aa9b5fe4f78  nop [rax+rax*1], eax
00007aa9b5fe4f80  mov eax, 0x4106E8
00007aa9b5fe4f85  mov [r15+0x100], rax
00007aa9b5fe4f8c  jmp 0x00007AA9B5DFE110
00007aa9b5fe4f91  int3
00007aa9b5fe4f92  call 0x00007AA9B5EB52F0
00007aa9b5fe4f97  jmp 0x00007AA9B5FE4E82
00007aa9b5fe4f9c  ucomisd xmm1, xmm14
00007aa9b5fe4fa1  jp 0x00007AA9B5FE4FB0
00007aa9b5fe4fa3  movaps xmm13, [0x00007AA9B5BFE060]
00007aa9b5fe4fab  jmp 0x00007AA9B5FE4EED
00007aa9b5fe4fb0  vxorps xmm0, xmm1, xmm14
00007aa9b5fe4fb5  pextrw eax, xmm0, 0x03
00007aa9b5fe4fba  and eax, 0x7FF8
00007aa9b5fe4fbf  cmp eax, 0x08
00007aa9b5fe4fc2  jnz 0x00007AA9B5FE4EED
00007aa9b5fe4fc8  movq rax, xmm14
00007aa9b5fe4fcd  shl rax, 0x0D
00007aa9b5fe4fd1  jbe 0x00007AA9B5FE4EED
00007aa9b5fe4fd7  vorps xmm13, xmm14, [0x00007AA9B5BFE070]
00007aa9b5fe4fdf  jmp 0x00007AA9B5FE4EED
00007aa9b5fe4fe4  ucomisd xmm1, xmm15
00007aa9b5fe4fe9  jp 0x00007AA9B5FE4FF8
00007aa9b5fe4feb  movaps xmm14, [0x00007AA9B5BFE060]
00007aa9b5fe4ff3  jmp 0x00007AA9B5FE4F1A
00007aa9b5fe4ff8  vxorps xmm0, xmm1, xmm15
00007aa9b5fe4ffd  pextrw eax, xmm0, 0x03
00007aa9b5fe5002  and eax, 0x7FF8
00007aa9b5fe5007  cmp eax, 0x08
00007aa9b5fe500a  jnz 0x00007AA9B5FE4F1A
00007aa9b5fe5010  movq rax, xmm15
00007aa9b5fe5015  shl rax, 0x0D
00007aa9b5fe5019  jbe 0x00007AA9B5FE4F1A
00007aa9b5fe501f  vorps xmm14, xmm15, [0x00007AA9B5BFE070]
00007aa9b5fe5027  jmp 0x00007AA9B5FE4F1A
00007aa9b5fe502c  int3
00007aa9b5fe502d  nop [rax], eax
00007aa9b5fe5030  mov rax, [r15+0xF8]
00007aa9b5fe5037  lea r14, [rax+0x1D0]
00007aa9b5fe503e  mov r12, [r13+r14*1]
00007aa9b5fe5043  lea r14, [rax+0x1D8]
00007aa9b5fe504a  mov r11, [r13+r14*1]
00007aa9b5fe504f  mov [r15+0xA0], r12
00007aa9b5fe5056  mov [r15+0x98], r11
00007aa9b5fe505d  mov r14, [r15+0x40]
00007aa9b5fe5061  lea r12, [r14+0xCC0]
00007aa9b5fe5068  movaps xmm1, [r15+0x110]
00007aa9b5fe5070  movq r14, xmm1
00007aa9b5fe5075  mov [r13+r12*1], r14
00007aa9b5fe507a  lea r14, [rax+0x1C0]
00007aa9b5fe5081  mov r12, [r13+r14*1]
00007aa9b5fe5086  lea r14, [rax+0x1C8]
00007aa9b5fe508d  mov r11, [r13+r14*1]
00007aa9b5fe5092  mov [r15+0xE8], r12
00007aa9b5fe5099  mov [r15+0xF0], r11
00007aa9b5fe50a0  lea r14, [rax+0x1B0]
00007aa9b5fe50a7  mov r12, [r13+r14*1]
00007aa9b5fe50ac  lea r14, [rax+0x1B8]
00007aa9b5fe50b3  mov r10, [r13+r14*1]
00007aa9b5fe50b8  movq xmm1, r12
00007aa9b5fe50bd  movq xmm15, r10
00007aa9b5fe50c2  movq xmm1, xmm1
00007aa9b5fe50c6  movq xmm1, xmm1
00007aa9b5fe50ca  movaps [r15+0x1A0], xmm1
00007aa9b5fe50d2  movq xmm15, xmm15
00007aa9b5fe50d7  movq xmm15, xmm15
00007aa9b5fe50dc  movaps [r15+0x190], xmm15
00007aa9b5fe50e4  lea r14, [rax+0x1A0]
00007aa9b5fe50eb  mov r12, [r13+r14*1]
00007aa9b5fe50f0  lea r14, [rax+0x1A8]
00007aa9b5fe50f7  mov r10, [r13+r14*1]
00007aa9b5fe50fc  movq xmm1, r12
00007aa9b5fe5101  movq xmm15, r10
00007aa9b5fe5106  movq xmm1, xmm1
00007aa9b5fe510a  movq xmm1, xmm1
00007aa9b5fe510e  movaps [r15+0x1C0], xmm1
00007aa9b5fe5116  movq xmm15, xmm15
00007aa9b5fe511b  movq xmm15, xmm15
00007aa9b5fe5120  movaps [r15+0x1B0], xmm15
00007aa9b5fe5128  lea r14, [rax+0x190]
00007aa9b5fe512f  mov r12, [r13+r14*1]
00007aa9b5fe5134  lea r14, [rax+0x198]
00007aa9b5fe513b  mov r10, [r13+r14*1]
00007aa9b5fe5140  movq xmm1, r12
00007aa9b5fe5145  movq xmm15, r10
00007aa9b5fe514a  movq xmm1, xmm1
00007aa9b5fe514e  movq xmm1, xmm1
00007aa9b5fe5152  movaps [r15+0x1E0], xmm1
00007aa9b5fe515a  movq xmm15, xmm15
00007aa9b5fe515f  movq xmm15, xmm15
00007aa9b5fe5164  movaps [r15+0x1D0], xmm15
00007aa9b5fe516c  lea r14, [rax+0x180]
00007aa9b5fe5173  mov r12, [r13+r14*1]
00007aa9b5fe5178  lea r14, [rax+0x188]
00007aa9b5fe517f  mov r10, [r13+r14*1]
00007aa9b5fe5184  movq xmm1, r12
00007aa9b5fe5189  movq xmm15, r10
00007aa9b5fe518e  movq xmm1, xmm1
00007aa9b5fe5192  movq xmm1, xmm1
00007aa9b5fe5196  movaps [r15+0x200], xmm1
00007aa9b5fe519e  movq xmm15, xmm15
00007aa9b5fe51a3  movq xmm15, xmm15
00007aa9b5fe51a8  movaps [r15+0x1F0], xmm15
00007aa9b5fe51b0  lea r14, [rax+0x1E0]
00007aa9b5fe51b7  mov [r15+0xF8], r14
00007aa9b5fe51be  mov [r15+0x100], r11
00007aa9b5fe51c5  jmp 0x00007AA9B5FCE5C0
00007aa9b5fe51ca  int3
00007aa9b5fe51cb  call 0x00007AA9B5EE27E0
00007aa9b5fe51d0  jmp 0x00007AA9B5FE5043
00007aa9b5fe51d5  call 0x00007AA9B5EE1570
00007aa9b5fe51da  jmp 0x00007AA9B5FE504F
00007aa9b5fe51df  call 0x00007AA9B5EC3FE0
00007aa9b5fe51e4  jmp 0x00007AA9B5FE507A
00007aa9b5fe51e9  call 0x00007AA9B5EE27E0
00007aa9b5fe51ee  jmp 0x00007AA9B5FE5086
00007aa9b5fe51f3  call 0x00007AA9B5EE1570
00007aa9b5fe51f8  jmp 0x00007AA9B5FE5092
00007aa9b5fe51fd  call 0x00007AA9B5EE27E0
00007aa9b5fe5202  jmp 0x00007AA9B5FE50AC
00007aa9b5fe5207  call 0x00007AA9B5EE0300
00007aa9b5fe520c  jmp 0x00007AA9B5FE50B8
00007aa9b5fe5211  call 0x00007AA9B5EE27E0
00007aa9b5fe5216  jmp 0x00007AA9B5FE50F0
00007aa9b5fe521b  call 0x00007AA9B5EE0300
00007aa9b5fe5220  jmp 0x00007AA9B5FE50FC
00007aa9b5fe5225  call 0x00007AA9B5EE27E0
00007aa9b5fe522a  jmp 0x00007AA9B5FE5134
00007aa9b5fe522f  call 0x00007AA9B5EE0300
00007aa9b5fe5234  jmp 0x00007AA9B5FE5140
00007aa9b5fe5239  call 0x00007AA9B5EE27E0
00007aa9b5fe523e  jmp 0x00007AA9B5FE5178
00007aa9b5fe5243  call 0x00007AA9B5EE0300
00007aa9b5fe5248  jmp 0x00007AA9B5FE5184
00007aa9b5fe524d  int3
00007aa9b5fe524e  nop
00007aa9b5fe5250  mov qword ptr [r15+0x100], 0x04
00007aa9b5fe525b  mov esi, 0x00
00007aa9b5fe5260  mov edx, 0x09
00007aa9b5fe5265  mov rdi, 0x7FFCF02F61E0
00007aa9b5fe526f  mov rax, 0x63E02165C970
00007aa9b5fe5279  call rax
00007aa9b5fe527b  cmp dword ptr [r15+0x318], 0x00
00007aa9b5fe5283  jnz 0x00007AA9B5DFE110
00007aa9b5fe5289  jmp 0x00007AA9B5DFE0A0
00007aa9b5fe528e  int3
00007aa9b5fe528f  int3
