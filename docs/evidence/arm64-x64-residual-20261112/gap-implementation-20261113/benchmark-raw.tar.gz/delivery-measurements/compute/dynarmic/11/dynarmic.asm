00007cc2f47ce69b  nop [rax+rax*1], eax
00007cc2f47ce6a0  mov rax, [r15+0xF8]
00007cc2f47ce6a7  lea r14, [rax-0x1E0]
00007cc2f47ce6ae  mov [r15+0xF8], r14
00007cc2f47ce6b5  lea rax, [r14+0x1D0]
00007cc2f47ce6bc  mov r12, [r15+0xA0]
00007cc2f47ce6c3  mov r11, [r15+0x98]
00007cc2f47ce6ca  mov [r13+rax*1], r12
00007cc2f47ce6cf  lea rax, [r14+0x1D8]
00007cc2f47ce6d6  mov [r13+rax*1], r11
00007cc2f47ce6db  mov eax, 0x420AA0
00007cc2f47ce6e0  movups xmm1, [r13+rax*1]
00007cc2f47ce6e6  mov eax, 0x420A30
00007cc2f47ce6eb  movups xmm15, [r13+rax*1]
00007cc2f47ce6f1  mov eax, 0x420AC0
00007cc2f47ce6f6  movups xmm14, [r13+rax*1]
00007cc2f47ce6fc  mov eax, 0x420A60
00007cc2f47ce701  movups xmm13, [r13+rax*1]
00007cc2f47ce707  mov qword ptr [r15+0x98], 0x430CD0
00007cc2f47ce712  mov eax, 0x420AD0
00007cc2f47ce717  movups xmm12, [r13+rax*1]
00007cc2f47ce71d  mov eax, 0x430CD0
00007cc2f47ce722  movups [r13+rax*1], xmm1
00007cc2f47ce728  mov eax, 0x430CE0
00007cc2f47ce72d  movups [r13+rax*1], xmm15
00007cc2f47ce733  mov eax, 0x430CF0
00007cc2f47ce738  movups [r13+rax*1], xmm14
00007cc2f47ce73e  mov eax, 0x430D00
00007cc2f47ce743  movups [r13+rax*1], xmm13
00007cc2f47ce749  mov eax, 0x420A20
00007cc2f47ce74e  movups xmm14, [r13+rax*1]
00007cc2f47ce754  mov eax, 0x420A10
00007cc2f47ce759  movups xmm13, [r13+rax*1]
00007cc2f47ce75f  mov eax, 0x430DD0
00007cc2f47ce764  movups [r13+rax*1], xmm1
00007cc2f47ce76a  mov eax, 0x430DE0
00007cc2f47ce76f  movups [r13+rax*1], xmm15
00007cc2f47ce775  mov eax, 0x430D10
00007cc2f47ce77a  movups [r13+rax*1], xmm12
00007cc2f47ce780  mov eax, 0x430D20
00007cc2f47ce785  movups [r13+rax*1], xmm14
00007cc2f47ce78b  mov eax, 0x420A00
00007cc2f47ce790  movups xmm1, [r13+rax*1]
00007cc2f47ce796  mov eax, 0x420A70
00007cc2f47ce79b  movups xmm15, [r13+rax*1]
00007cc2f47ce7a1  mov eax, 0x430D30
00007cc2f47ce7a6  movups [r13+rax*1], xmm13
00007cc2f47ce7ac  mov eax, 0x430D40
00007cc2f47ce7b1  movups [r13+rax*1], xmm1
00007cc2f47ce7b7  mov eax, 0x420A80
00007cc2f47ce7bc  movups xmm1, [r13+rax*1]
00007cc2f47ce7c2  mov eax, 0x420A50
00007cc2f47ce7c7  movups xmm14, [r13+rax*1]
00007cc2f47ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007cc2f47ce7d5  mov eax, 0x430D50
00007cc2f47ce7da  movups [r13+rax*1], xmm15
00007cc2f47ce7e0  mov eax, 0x430D60
00007cc2f47ce7e5  movups [r13+rax*1], xmm1
00007cc2f47ce7eb  mov eax, 0x420AF0
00007cc2f47ce7f0  movups xmm1, [r13+rax*1]
00007cc2f47ce7f6  mov eax, 0x420B00
00007cc2f47ce7fb  movups xmm15, [r13+rax*1]
00007cc2f47ce801  movaps [r15+0x150], xmm15
00007cc2f47ce809  mov qword ptr [r15+0xA0], 0x3E8
00007cc2f47ce814  mov eax, 0x430D70
00007cc2f47ce819  movups [r13+rax*1], xmm14
00007cc2f47ce81f  mov eax, 0x430D80
00007cc2f47ce824  movups [r13+rax*1], xmm1
00007cc2f47ce82a  mov eax, 0x420AE0
00007cc2f47ce82f  movups xmm1, [r13+rax*1]
00007cc2f47ce835  mov eax, 0x420A90
00007cc2f47ce83a  movups xmm14, [r13+rax*1]
00007cc2f47ce840  movaps [r15+0x140], xmm14
00007cc2f47ce848  lea rax, [r14+0x180]
00007cc2f47ce84f  movq xmm13, qword ptr [r15+0x200]
00007cc2f47ce858  movq xmm12, qword ptr [r15+0x1F0]
00007cc2f47ce861  movq r12, xmm13
00007cc2f47ce866  movq r11, xmm12
00007cc2f47ce86b  mov [r13+rax*1], r12
00007cc2f47ce870  lea rax, [r14+0x188]
00007cc2f47ce877  mov [r13+rax*1], r11
00007cc2f47ce87c  mov eax, 0x430D90
00007cc2f47ce881  movups [r13+rax*1], xmm15
00007cc2f47ce887  mov eax, 0x430DA0
00007cc2f47ce88c  movups [r13+rax*1], xmm1
00007cc2f47ce892  mov eax, 0x420AB0
00007cc2f47ce897  movups xmm1, [r13+rax*1]
00007cc2f47ce89d  mov eax, 0x420B18
00007cc2f47ce8a2  mov r12, [r13+rax*1]
00007cc2f47ce8a7  movq xmm15, r12
00007cc2f47ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007cc2f47ce8b4  mov eax, 0x430DB0
00007cc2f47ce8b9  movups [r13+rax*1], xmm14
00007cc2f47ce8bf  mov eax, 0x430DC0
00007cc2f47ce8c4  movups [r13+rax*1], xmm1
00007cc2f47ce8ca  mov eax, 0x420B80
00007cc2f47ce8cf  movups xmm1, [r13+rax*1]
00007cc2f47ce8d5  movq rax, xmm15
00007cc2f47ce8da  mov r12d, 0x430DF0
00007cc2f47ce8e0  mov [r13+r12*1], rax
00007cc2f47ce8e5  mov eax, 0x420B60
00007cc2f47ce8ea  movups xmm15, [r13+rax*1]
00007cc2f47ce8f0  mov eax, 0x420B70
00007cc2f47ce8f5  movups xmm14, [r13+rax*1]
00007cc2f47ce8fb  lea rax, [r14+0x160]
00007cc2f47ce902  movups [r13+rax*1], xmm1
00007cc2f47ce908  lea rax, [r14+0x190]
00007cc2f47ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007cc2f47ce918  movq xmm13, qword ptr [r15+0x1D0]
00007cc2f47ce921  movq r12, xmm1
00007cc2f47ce926  movq r11, xmm13
00007cc2f47ce92b  mov [r13+rax*1], r12
00007cc2f47ce930  lea rax, [r14+0x198]
00007cc2f47ce937  mov [r13+rax*1], r11
00007cc2f47ce93c  lea rax, [r14+0x140]
00007cc2f47ce943  movups [r13+rax*1], xmm15
00007cc2f47ce949  lea rax, [r14+0x150]
00007cc2f47ce950  movups [r13+rax*1], xmm14
00007cc2f47ce956  mov eax, 0x420B20
00007cc2f47ce95b  movups xmm1, [r13+rax*1]
00007cc2f47ce961  mov eax, 0x420B30
00007cc2f47ce966  movups xmm15, [r13+rax*1]
00007cc2f47ce96c  movaps [r15+0x120], xmm15
00007cc2f47ce974  lea rax, [r14+0x1A0]
00007cc2f47ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007cc2f47ce984  movq xmm13, qword ptr [r15+0x1B0]
00007cc2f47ce98d  movq r12, xmm14
00007cc2f47ce992  movq r11, xmm13
00007cc2f47ce997  mov [r13+rax*1], r12
00007cc2f47ce99c  lea rax, [r14+0x1A8]
00007cc2f47ce9a3  mov [r13+rax*1], r11
00007cc2f47ce9a8  lea rax, [r14+0x1B0]
00007cc2f47ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007cc2f47ce9b8  movq xmm13, qword ptr [r15+0x190]
00007cc2f47ce9c1  movq r12, xmm14
00007cc2f47ce9c6  movq r11, xmm13
00007cc2f47ce9cb  mov [r13+rax*1], r12
00007cc2f47ce9d0  lea rax, [r14+0x1B8]
00007cc2f47ce9d7  mov [r13+rax*1], r11
00007cc2f47ce9dc  lea rax, [r14+0x100]
00007cc2f47ce9e3  movups [r13+rax*1], xmm1
00007cc2f47ce9e9  lea rax, [r14+0x110]
00007cc2f47ce9f0  movups [r13+rax*1], xmm15
00007cc2f47ce9f6  mov eax, 0x420B40
00007cc2f47ce9fb  movups xmm1, [r13+rax*1]
00007cc2f47cea01  mov eax, 0x420B50
00007cc2f47cea06  movups xmm15, [r13+rax*1]
00007cc2f47cea0c  movaps [r15+0x110], xmm1
00007cc2f47cea14  movaps [r15+0x130], xmm15
00007cc2f47cea1c  lea rax, [r14+0x1C0]
00007cc2f47cea23  mov r12, [r15+0xE8]
00007cc2f47cea2a  mov r11, [r15+0xF0]
00007cc2f47cea31  mov [r13+rax*1], r12
00007cc2f47cea36  lea rax, [r14+0x1C8]
00007cc2f47cea3d  mov [r13+rax*1], r11
00007cc2f47cea42  mov eax, 0x430DF8
00007cc2f47cea47  mov r12d, 0x421DF8D3
00007cc2f47cea4d  mov [r13+rax*1], r12d
00007cc2f47cea52  lea rax, [r14+0x120]
00007cc2f47cea59  movups [r13+rax*1], xmm1
00007cc2f47cea5f  lea rax, [r14+0x130]
00007cc2f47cea66  movups [r13+rax*1], xmm15
00007cc2f47cea6c  lea rax, [r14+0x100]
00007cc2f47cea73  mov [r15], rax
00007cc2f47cea76  mov qword ptr [r15+0x08], 0x430CD0
00007cc2f47cea7e  mov qword ptr [r15+0x10], 0x12C
00007cc2f47cea86  mov qword ptr [r15+0xF0], 0x410284
00007cc2f47cea91  mov r14d, [r15+0x320]
00007cc2f47cea98  mov eax, 0x410284
00007cc2f47cea9d  mov rcx, 0x7CC2F47D07C0
00007cc2f47ceaa7  mov [r15+r14*8+0x328], rax
00007cc2f47ceaaf  mov [r15+r14*8+0x368], rcx
00007cc2f47ceab7  add r14d, 0x01
00007cc2f47ceabb  and r14d, 0x07
00007cc2f47ceabf  mov [r15+0x320], r14d
00007cc2f47ceac6  cmp dword ptr [r15+0x318], 0x00
00007cc2f47ceace  jz 0x00007CC2F47CED70
00007cc2f47cead4  nop [rax+rax*1], ax
00007cc2f47ceadd  nop [rax+rax*1], eax
00007cc2f47ceae5  mov eax, 0x410728
00007cc2f47ceaea  mov [r15+0x100], rax
00007cc2f47ceaf1  jmp 0x00007CC2F45FE110
00007cc2f47ceaf6  int3
00007cc2f47ceaf7  call 0x00007CC2F460BC20
00007cc2f47ceafc  jmp 0x00007CC2F47CE6CF
00007cc2f47ceb01  call 0x00007CC2F460A9A0
00007cc2f47ceb06  jmp 0x00007CC2F47CE6DB
00007cc2f47ceb0b  call 0x00007CC2F45FF430
00007cc2f47ceb10  jmp 0x00007CC2F47CE6E6
00007cc2f47ceb15  call 0x00007CC2F460E760
00007cc2f47ceb1a  jmp 0x00007CC2F47CE6F1
00007cc2f47ceb1f  call 0x00007CC2F460D4E0
00007cc2f47ceb24  jmp 0x00007CC2F47CE6FC
00007cc2f47ceb29  call 0x00007CC2F460C260
00007cc2f47ceb2e  jmp 0x00007CC2F47CE707
00007cc2f47ceb33  call 0x00007CC2F460AFE0
00007cc2f47ceb38  jmp 0x00007CC2F47CE71D
00007cc2f47ceb3d  call 0x00007CC2F45FF540
00007cc2f47ceb42  jmp 0x00007CC2F47CE728
00007cc2f47ceb47  call 0x00007CC2F460E880
00007cc2f47ceb4c  jmp 0x00007CC2F47CE733
00007cc2f47ceb51  call 0x00007CC2F460D600
00007cc2f47ceb56  jmp 0x00007CC2F47CE73E
00007cc2f47ceb5b  call 0x00007CC2F460C380
00007cc2f47ceb60  jmp 0x00007CC2F47CE749
00007cc2f47ceb65  call 0x00007CC2F460D4E0
00007cc2f47ceb6a  jmp 0x00007CC2F47CE754
00007cc2f47ceb6f  call 0x00007CC2F460C260
00007cc2f47ceb74  jmp 0x00007CC2F47CE75F
00007cc2f47ceb79  call 0x00007CC2F45FF540
00007cc2f47ceb7e  jmp 0x00007CC2F47CE76A
00007cc2f47ceb83  call 0x00007CC2F460E880
00007cc2f47ceb88  jmp 0x00007CC2F47CE775
00007cc2f47ceb8d  call 0x00007CC2F460B100
00007cc2f47ceb92  jmp 0x00007CC2F47CE780
00007cc2f47ceb97  call 0x00007CC2F460D600
00007cc2f47ceb9c  jmp 0x00007CC2F47CE78B
00007cc2f47ceba1  call 0x00007CC2F45FF430
00007cc2f47ceba6  jmp 0x00007CC2F47CE796
00007cc2f47cebab  call 0x00007CC2F460E760
00007cc2f47cebb0  jmp 0x00007CC2F47CE7A1
00007cc2f47cebb5  call 0x00007CC2F460C380
00007cc2f47cebba  jmp 0x00007CC2F47CE7AC
00007cc2f47cebbf  call 0x00007CC2F45FF540
00007cc2f47cebc4  jmp 0x00007CC2F47CE7B7
00007cc2f47cebc9  call 0x00007CC2F45FF430
00007cc2f47cebce  jmp 0x00007CC2F47CE7C2
00007cc2f47cebd3  call 0x00007CC2F460D4E0
00007cc2f47cebd8  jmp 0x00007CC2F47CE7CD
00007cc2f47cebdd  call 0x00007CC2F460E880
00007cc2f47cebe2  jmp 0x00007CC2F47CE7E0
00007cc2f47cebe7  call 0x00007CC2F45FF540
00007cc2f47cebec  jmp 0x00007CC2F47CE7EB
00007cc2f47cebf1  call 0x00007CC2F45FF430
00007cc2f47cebf6  jmp 0x00007CC2F47CE7F6
00007cc2f47cebfb  call 0x00007CC2F460E760
00007cc2f47cec00  jmp 0x00007CC2F47CE801
00007cc2f47cec05  call 0x00007CC2F460D600
00007cc2f47cec0a  jmp 0x00007CC2F47CE81F
00007cc2f47cec0f  call 0x00007CC2F45FF540
00007cc2f47cec14  jmp 0x00007CC2F47CE82A
00007cc2f47cec19  call 0x00007CC2F45FF430
00007cc2f47cec1e  jmp 0x00007CC2F47CE835
00007cc2f47cec23  call 0x00007CC2F460D4E0
00007cc2f47cec28  jmp 0x00007CC2F47CE840
00007cc2f47cec2d  call 0x00007CC2F460BC20
00007cc2f47cec32  jmp 0x00007CC2F47CE870
00007cc2f47cec37  call 0x00007CC2F460A9A0
00007cc2f47cec3c  jmp 0x00007CC2F47CE87C
00007cc2f47cec41  call 0x00007CC2F460E880
00007cc2f47cec46  jmp 0x00007CC2F47CE887
00007cc2f47cec4b  call 0x00007CC2F45FF540
00007cc2f47cec50  jmp 0x00007CC2F47CE892
00007cc2f47cec55  call 0x00007CC2F45FF430
00007cc2f47cec5a  jmp 0x00007CC2F47CE89D
00007cc2f47cec5f  call 0x00007CC2F460B720
00007cc2f47cec64  jmp 0x00007CC2F47CE8A7
00007cc2f47cec69  call 0x00007CC2F460D600
00007cc2f47cec6e  jmp 0x00007CC2F47CE8BF
00007cc2f47cec73  call 0x00007CC2F45FF540
00007cc2f47cec78  jmp 0x00007CC2F47CE8CA
00007cc2f47cec7d  call 0x00007CC2F45FF430
00007cc2f47cec82  jmp 0x00007CC2F47CE8D5
00007cc2f47cec87  call 0x00007CC2F46B4CB0
00007cc2f47cec8c  jmp 0x00007CC2F47CE8E5
00007cc2f47cec91  call 0x00007CC2F460E760
00007cc2f47cec96  jmp 0x00007CC2F47CE8F0
00007cc2f47cec9b  call 0x00007CC2F460D4E0
00007cc2f47ceca0  jmp 0x00007CC2F47CE8FB
00007cc2f47ceca5  call 0x00007CC2F45FF540
00007cc2f47cecaa  jmp 0x00007CC2F47CE908
00007cc2f47cecaf  call 0x00007CC2F460BC20
00007cc2f47cecb4  jmp 0x00007CC2F47CE930
00007cc2f47cecb9  call 0x00007CC2F460A9A0
00007cc2f47cecbe  jmp 0x00007CC2F47CE93C
00007cc2f47cecc3  call 0x00007CC2F460E880
00007cc2f47cecc8  jmp 0x00007CC2F47CE949
00007cc2f47ceccd  call 0x00007CC2F460D600
00007cc2f47cecd2  jmp 0x00007CC2F47CE956
00007cc2f47cecd7  call 0x00007CC2F45FF430
00007cc2f47cecdc  jmp 0x00007CC2F47CE961
00007cc2f47cece1  call 0x00007CC2F460E760
00007cc2f47cece6  jmp 0x00007CC2F47CE96C
00007cc2f47ceceb  call 0x00007CC2F460BC20
00007cc2f47cecf0  jmp 0x00007CC2F47CE99C
00007cc2f47cecf5  call 0x00007CC2F460A9A0
00007cc2f47cecfa  jmp 0x00007CC2F47CE9A8
00007cc2f47cecff  call 0x00007CC2F460BC20
00007cc2f47ced04  jmp 0x00007CC2F47CE9D0
00007cc2f47ced09  call 0x00007CC2F460A9A0
00007cc2f47ced0e  jmp 0x00007CC2F47CE9DC
00007cc2f47ced13  call 0x00007CC2F45FF540
00007cc2f47ced18  jmp 0x00007CC2F47CE9E9
00007cc2f47ced1d  call 0x00007CC2F460E880
00007cc2f47ced22  jmp 0x00007CC2F47CE9F6
00007cc2f47ced27  call 0x00007CC2F45FF430
00007cc2f47ced2c  jmp 0x00007CC2F47CEA01
00007cc2f47ced31  call 0x00007CC2F460E760
00007cc2f47ced36  jmp 0x00007CC2F47CEA0C
00007cc2f47ced3b  call 0x00007CC2F460BC20
00007cc2f47ced40  jmp 0x00007CC2F47CEA36
00007cc2f47ced45  call 0x00007CC2F460A9A0
00007cc2f47ced4a  jmp 0x00007CC2F47CEA42
00007cc2f47ced4f  call 0x00007CC2F460BAE0
00007cc2f47ced54  jmp 0x00007CC2F47CEA52
00007cc2f47ced59  call 0x00007CC2F45FF540
00007cc2f47ced5e  jmp 0x00007CC2F47CEA5F
00007cc2f47ced63  call 0x00007CC2F460E880
00007cc2f47ced68  jmp 0x00007CC2F47CEA6C
00007cc2f47ced6d  int3
00007cc2f47ced6e  nop
00007cc2f47ced70  mov rax, [r15]
00007cc2f47ced73  lea r14, [rax+0x20]
00007cc2f47ced77  mov r12, [r13+r14*1]
00007cc2f47ced7c  mov r14, [r15+0x10]
00007cc2f47ced80  lea r11, [r12+r14*1]
00007cc2f47ced84  mov [r15+0x40], r11
00007cc2f47ced88  lea r12, [rax+0x20]
00007cc2f47ced8c  mov [r13+r12*1], r11
00007cc2f47ced91  test r14, r14
00007cc2f47ced94  setz r14b
00007cc2f47ced98  movzx r14, r14b
00007cc2f47ced9c  mov [rsp+0x414], r14b
00007cc2f47ceda4  cmp byte ptr [rsp+0x414], 0x00
00007cc2f47cedac  jz 0x00007CC2F47CEDDE
00007cc2f47cedae  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cedb6  mov eax, 0x4109A0
00007cc2f47cedbb  mov [r15+0x100], rax
00007cc2f47cedc2  jz 0x00007CC2F45FE0A0
00007cc2f47cedc8  nop [rax+rax*1], eax
00007cc2f47cedcd  mov eax, 0x4109A0
00007cc2f47cedd2  mov [r15+0x100], rax
00007cc2f47cedd9  jmp 0x00007CC2F45FE110
00007cc2f47cedde  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cede6  jz 0x00007CC2F47CEE30
00007cc2f47cedec  nop [rax+rax*1], ax
00007cc2f47cedf5  nop [rax+rax*1], eax
00007cc2f47cedfd  mov eax, 0x410738
00007cc2f47cee02  mov [r15+0x100], rax
00007cc2f47cee09  jmp 0x00007CC2F45FE110
00007cc2f47cee0e  int3
00007cc2f47cee0f  call 0x00007CC2F46E27E0
00007cc2f47cee14  jmp 0x00007CC2F47CED7C
00007cc2f47cee19  call 0x00007CC2F46C0860
00007cc2f47cee1e  jmp 0x00007CC2F47CED91
00007cc2f47cee23  int3
00007cc2f47cee24  nop [rax+rax*1], ax
00007cc2f47cee2d  nop [rax], eax
00007cc2f47cee30  mov rax, [r15+0xF8]
00007cc2f47cee37  lea r14, [rax-0x150]
00007cc2f47cee3e  mov [r15+0xF8], r14
00007cc2f47cee45  mov rax, [r15]
00007cc2f47cee48  lea r12, [rax+0x68]
00007cc2f47cee4c  mov r11, [r13+r12*1]
00007cc2f47cee51  mov [r15+0x88], r11
00007cc2f47cee58  lea r12, [rax+0x28]
00007cc2f47cee5c  mov [r15+0x40], r12
00007cc2f47cee60  mov [r15+0x48], r14
00007cc2f47cee64  mov qword ptr [r15+0x50], 0x420B90
00007cc2f47cee6c  lea rax, [r14+0x100]
00007cc2f47cee73  mov r12, [r15+0xE8]
00007cc2f47cee7a  mov r11, [r15+0xD8]
00007cc2f47cee81  mov [r13+rax*1], r12
00007cc2f47cee86  lea rax, [r14+0x108]
00007cc2f47cee8d  mov [r13+rax*1], r11
00007cc2f47cee92  lea rax, [r14+0x110]
00007cc2f47cee99  mov r12, [r15+0xD0]
00007cc2f47ceea0  mov r11, [r15+0xC8]
00007cc2f47ceea7  mov [r13+rax*1], r12
00007cc2f47ceeac  lea rax, [r14+0x118]
00007cc2f47ceeb3  mov [r13+rax*1], r11
00007cc2f47ceeb8  lea rax, [r14+0x120]
00007cc2f47ceebf  mov r12, [r15+0xC0]
00007cc2f47ceec6  mov r11, [r15+0xB8]
00007cc2f47ceecd  mov [r13+rax*1], r12
00007cc2f47ceed2  lea rax, [r14+0x128]
00007cc2f47ceed9  mov [r13+rax*1], r11
00007cc2f47ceede  lea rax, [r14+0x130]
00007cc2f47ceee5  mov r12, [r15+0xB0]
00007cc2f47ceeec  mov r11, [r15+0xA8]
00007cc2f47ceef3  mov [r13+rax*1], r12
00007cc2f47ceef8  lea rax, [r14+0x138]
00007cc2f47ceeff  mov [r13+rax*1], r11
00007cc2f47cef04  lea rax, [r14+0x140]
00007cc2f47cef0b  mov r12, [r15+0xA0]
00007cc2f47cef12  mov r11, [r15+0x98]
00007cc2f47cef19  mov [r13+rax*1], r12
00007cc2f47cef1e  lea rax, [r14+0x148]
00007cc2f47cef25  mov [r13+rax*1], r11
00007cc2f47cef2a  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cef32  jz 0x00007CC2F47CEFD0
00007cc2f47cef38  nop [rax+rax*1], ax
00007cc2f47cef41  nop [rax+rax*1], eax
00007cc2f47cef49  mov eax, 0x410770
00007cc2f47cef4e  mov [r15+0x100], rax
00007cc2f47cef55  jmp 0x00007CC2F45FE110
00007cc2f47cef5a  int3
00007cc2f47cef5b  call 0x00007CC2F46C0370
00007cc2f47cef60  jmp 0x00007CC2F47CEE51
00007cc2f47cef65  call 0x00007CC2F460BC20
00007cc2f47cef6a  jmp 0x00007CC2F47CEE86
00007cc2f47cef6f  call 0x00007CC2F460A9A0
00007cc2f47cef74  jmp 0x00007CC2F47CEE92
00007cc2f47cef79  call 0x00007CC2F460BC20
00007cc2f47cef7e  jmp 0x00007CC2F47CEEAC
00007cc2f47cef83  call 0x00007CC2F460A9A0
00007cc2f47cef88  jmp 0x00007CC2F47CEEB8
00007cc2f47cef8d  call 0x00007CC2F460BC20
00007cc2f47cef92  jmp 0x00007CC2F47CEED2
00007cc2f47cef97  call 0x00007CC2F460A9A0
00007cc2f47cef9c  jmp 0x00007CC2F47CEEDE
00007cc2f47cefa1  call 0x00007CC2F460BC20
00007cc2f47cefa6  jmp 0x00007CC2F47CEEF8
00007cc2f47cefab  call 0x00007CC2F460A9A0
00007cc2f47cefb0  jmp 0x00007CC2F47CEF04
00007cc2f47cefb5  call 0x00007CC2F460BC20
00007cc2f47cefba  jmp 0x00007CC2F47CEF1E
00007cc2f47cefbf  call 0x00007CC2F460A9A0
00007cc2f47cefc4  jmp 0x00007CC2F47CEF2A
00007cc2f47cefc9  int3
00007cc2f47cefca  nop [rax+rax*1], ax
00007cc2f47cefd0  mov rax, [r15+0x08]
00007cc2f47cefd4  movzx r14d, byte ptr [r13+rax*1]
00007cc2f47cefda  movzx r14d, r14b
00007cc2f47cefde  mov [rsp+0x10], r14d
00007cc2f47cefe3  mov r14d, r14d
00007cc2f47cefe6  mov [r15+0x58], r14
00007cc2f47cefea  lea r14, [rax+0x01]
00007cc2f47cefee  mov [r15+0x08], r14
00007cc2f47ceff2  mov rax, [r15+0x88]
00007cc2f47ceff9  lea r14, [rax+0x01]
00007cc2f47ceffd  mov r12, [r15]
00007cc2f47cf000  lea r11, [r12+0x68]
00007cc2f47cf005  mov [r13+r11*1], r14
00007cc2f47cf00a  lea r14, [r12+rax*1]
00007cc2f47cf00e  mov [r15+0x60], r14
00007cc2f47cf012  lea rax, [r14+0x28]
00007cc2f47cf016  mov r11d, [rsp+0x10]
00007cc2f47cf01b  movzx r14d, r11b
00007cc2f47cf01f  mov [r13+rax*1], r14b
00007cc2f47cf024  lea rax, [r12+0x68]
00007cc2f47cf029  mov r14, [r13+rax*1]
00007cc2f47cf02e  mov [r15+0x88], r14
00007cc2f47cf035  xor eax, eax
00007cc2f47cf037  mov r12d, 0x40
00007cc2f47cf03d  cmp r14, r12
00007cc2f47cf040  cmc
00007cc2f47cf041  lahf
00007cc2f47cf042  seto al
00007cc2f47cf045  mov [r15+0x108], eax
00007cc2f47cf04c  mov eax, [r15+0x108]
00007cc2f47cf053  sahf
00007cc2f47cf054  jnz 0x00007CC2F47CF086
00007cc2f47cf056  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cf05e  jz 0x00007CC2F47CF170
00007cc2f47cf064  nop [rax+rax*1], ax
00007cc2f47cf06d  nop [rax+rax*1], eax
00007cc2f47cf075  mov eax, 0x410790
00007cc2f47cf07a  mov [r15+0x100], rax
00007cc2f47cf081  jmp 0x00007CC2F45FE110
00007cc2f47cf086  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cf08e  jz 0x00007CC2F47CF0E0
00007cc2f47cf094  nop [rax+rax*1], ax
00007cc2f47cf09d  nop [rax+rax*1], eax
00007cc2f47cf0a5  mov eax, 0x410768
00007cc2f47cf0aa  mov [r15+0x100], rax
00007cc2f47cf0b1  jmp 0x00007CC2F45FE110
00007cc2f47cf0b6  int3
00007cc2f47cf0b7  call 0x00007CC2F460D860
00007cc2f47cf0bc  jmp 0x00007CC2F47CEFDA
00007cc2f47cf0c1  call 0x00007CC2F46B36E0
00007cc2f47cf0c6  jmp 0x00007CC2F47CF00A
00007cc2f47cf0cb  call 0x00007CC2F460DD60
00007cc2f47cf0d0  jmp 0x00007CC2F47CF024
00007cc2f47cf0d5  call 0x00007CC2F460DC20
00007cc2f47cf0da  jmp 0x00007CC2F47CF02E
00007cc2f47cf0df  int3
00007cc2f47cf0e0  mov rax, [r15+0x10]
00007cc2f47cf0e4  lea r14, [rax-0x01]
00007cc2f47cf0e8  mov [r15+0x10], r14
00007cc2f47cf0ec  test r14, r14
00007cc2f47cf0ef  setz r14b
00007cc2f47cf0f3  movzx r14, r14b
00007cc2f47cf0f7  mov [rsp+0x414], r14b
00007cc2f47cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007cc2f47cf107  jz 0x00007CC2F47CF139
00007cc2f47cf109  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cf111  jz 0x00007CC2F47D0670
00007cc2f47cf117  nop [rax+rax*1], ax
00007cc2f47cf120  nop [rax+rax*1], eax
00007cc2f47cf128  mov eax, 0x410988
00007cc2f47cf12d  mov [r15+0x100], rax
00007cc2f47cf134  jmp 0x00007CC2F45FE110
00007cc2f47cf139  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cf141  jz 0x00007CC2F47CEFD0
00007cc2f47cf147  nop [rax+rax*1], ax
00007cc2f47cf150  nop [rax+rax*1], eax
00007cc2f47cf158  mov eax, 0x410770
00007cc2f47cf15d  mov [r15+0x100], rax
00007cc2f47cf164  jmp 0x00007CC2F45FE110
00007cc2f47cf169  int3
00007cc2f47cf16a  int3
00007cc2f47cf16b  nop [rax+rax*1], eax
00007cc2f47cf170  mov rax, [r15+0x40]
00007cc2f47cf174  movzx r14d, byte ptr [r13+rax*1]
00007cc2f47cf17a  movaps xmm1, [r15+0x110]
00007cc2f47cf182  pinsrb xmm1, r14d, 0x00
00007cc2f47cf189  lea r14, [rax+0x01]
00007cc2f47cf18d  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf193  movaps xmm15, [r15+0x120]
00007cc2f47cf19b  pinsrb xmm15, r12d, 0x00
00007cc2f47cf1a2  lea r14, [rax+0x02]
00007cc2f47cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf1ac  movaps xmm14, [r15+0x130]
00007cc2f47cf1b4  pinsrb xmm14, r12d, 0x00
00007cc2f47cf1bb  lea r14, [rax+0x03]
00007cc2f47cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf1c5  movaps xmm13, [r15+0x140]
00007cc2f47cf1cd  pinsrb xmm13, r12d, 0x00
00007cc2f47cf1d4  lea r14, [rax+0x04]
00007cc2f47cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf1de  pinsrb xmm1, r12d, 0x01
00007cc2f47cf1e5  lea r14, [rax+0x05]
00007cc2f47cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf1ef  pinsrb xmm15, r12d, 0x01
00007cc2f47cf1f6  lea r14, [rax+0x06]
00007cc2f47cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf200  pinsrb xmm14, r12d, 0x01
00007cc2f47cf207  lea r14, [rax+0x07]
00007cc2f47cf20b  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf211  pinsrb xmm13, r12d, 0x01
00007cc2f47cf218  lea r14, [rax+0x08]
00007cc2f47cf21c  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf222  pinsrb xmm1, r12d, 0x02
00007cc2f47cf229  lea r14, [rax+0x09]
00007cc2f47cf22d  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf233  pinsrb xmm15, r12d, 0x02
00007cc2f47cf23a  lea r14, [rax+0x0A]
00007cc2f47cf23e  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf244  pinsrb xmm14, r12d, 0x02
00007cc2f47cf24b  lea r14, [rax+0x0B]
00007cc2f47cf24f  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf255  pinsrb xmm13, r12d, 0x02
00007cc2f47cf25c  lea r14, [rax+0x0C]
00007cc2f47cf260  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf266  pinsrb xmm1, r12d, 0x03
00007cc2f47cf26d  lea r14, [rax+0x0D]
00007cc2f47cf271  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf277  pinsrb xmm15, r12d, 0x03
00007cc2f47cf27e  lea r14, [rax+0x0E]
00007cc2f47cf282  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf288  pinsrb xmm14, r12d, 0x03
00007cc2f47cf28f  lea r14, [rax+0x0F]
00007cc2f47cf293  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf299  pinsrb xmm13, r12d, 0x03
00007cc2f47cf2a0  lea r14, [rax+0x10]
00007cc2f47cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf2aa  pinsrb xmm1, r12d, 0x04
00007cc2f47cf2b1  lea r14, [rax+0x11]
00007cc2f47cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf2bb  pinsrb xmm15, r12d, 0x04
00007cc2f47cf2c2  lea r14, [rax+0x12]
00007cc2f47cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf2cc  pinsrb xmm14, r12d, 0x04
00007cc2f47cf2d3  lea r14, [rax+0x13]
00007cc2f47cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf2dd  pinsrb xmm13, r12d, 0x04
00007cc2f47cf2e4  lea r14, [rax+0x14]
00007cc2f47cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf2ee  pinsrb xmm1, r12d, 0x05
00007cc2f47cf2f5  lea r14, [rax+0x15]
00007cc2f47cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf2ff  pinsrb xmm15, r12d, 0x05
00007cc2f47cf306  lea r14, [rax+0x16]
00007cc2f47cf30a  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf310  pinsrb xmm14, r12d, 0x05
00007cc2f47cf317  lea r14, [rax+0x17]
00007cc2f47cf31b  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf321  pinsrb xmm13, r12d, 0x05
00007cc2f47cf328  lea r14, [rax+0x18]
00007cc2f47cf32c  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf332  pinsrb xmm1, r12d, 0x06
00007cc2f47cf339  lea r14, [rax+0x19]
00007cc2f47cf33d  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf343  pinsrb xmm15, r12d, 0x06
00007cc2f47cf34a  lea r14, [rax+0x1A]
00007cc2f47cf34e  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf354  pinsrb xmm14, r12d, 0x06
00007cc2f47cf35b  lea r14, [rax+0x1B]
00007cc2f47cf35f  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf365  pinsrb xmm13, r12d, 0x06
00007cc2f47cf36c  lea r14, [rax+0x1C]
00007cc2f47cf370  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf376  pinsrb xmm1, r12d, 0x07
00007cc2f47cf37d  lea r14, [rax+0x1D]
00007cc2f47cf381  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf387  pinsrb xmm15, r12d, 0x07
00007cc2f47cf38e  lea r14, [rax+0x1E]
00007cc2f47cf392  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf398  pinsrb xmm14, r12d, 0x07
00007cc2f47cf39f  lea r14, [rax+0x1F]
00007cc2f47cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf3a9  pinsrb xmm13, r12d, 0x07
00007cc2f47cf3b0  lea r14, [rax+0x20]
00007cc2f47cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf3ba  pinsrb xmm1, r12d, 0x08
00007cc2f47cf3c1  lea r14, [rax+0x21]
00007cc2f47cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf3cb  pinsrb xmm15, r12d, 0x08
00007cc2f47cf3d2  lea r14, [rax+0x22]
00007cc2f47cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf3dc  pinsrb xmm14, r12d, 0x08
00007cc2f47cf3e3  lea r14, [rax+0x23]
00007cc2f47cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf3ed  pinsrb xmm13, r12d, 0x08
00007cc2f47cf3f4  lea r14, [rax+0x24]
00007cc2f47cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf3fe  pinsrb xmm1, r12d, 0x09
00007cc2f47cf405  lea r14, [rax+0x25]
00007cc2f47cf409  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf40f  pinsrb xmm15, r12d, 0x09
00007cc2f47cf416  lea r14, [rax+0x26]
00007cc2f47cf41a  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf420  pinsrb xmm14, r12d, 0x09
00007cc2f47cf427  lea r14, [rax+0x27]
00007cc2f47cf42b  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf431  pinsrb xmm13, r12d, 0x09
00007cc2f47cf438  lea r14, [rax+0x28]
00007cc2f47cf43c  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf442  pinsrb xmm1, r12d, 0x0A
00007cc2f47cf449  lea r14, [rax+0x29]
00007cc2f47cf44d  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf453  pinsrb xmm15, r12d, 0x0A
00007cc2f47cf45a  lea r14, [rax+0x2A]
00007cc2f47cf45e  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf464  pinsrb xmm14, r12d, 0x0A
00007cc2f47cf46b  lea r14, [rax+0x2B]
00007cc2f47cf46f  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf475  pinsrb xmm13, r12d, 0x0A
00007cc2f47cf47c  lea r14, [rax+0x2C]
00007cc2f47cf480  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf486  pinsrb xmm1, r12d, 0x0B
00007cc2f47cf48d  lea r14, [rax+0x2D]
00007cc2f47cf491  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf497  pinsrb xmm15, r12d, 0x0B
00007cc2f47cf49e  lea r14, [rax+0x2E]
00007cc2f47cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf4a8  pinsrb xmm14, r12d, 0x0B
00007cc2f47cf4af  lea r14, [rax+0x2F]
00007cc2f47cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf4b9  pinsrb xmm13, r12d, 0x0B
00007cc2f47cf4c0  lea r14, [rax+0x30]
00007cc2f47cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf4ca  pinsrb xmm1, r12d, 0x0C
00007cc2f47cf4d1  lea r14, [rax+0x31]
00007cc2f47cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf4db  pinsrb xmm15, r12d, 0x0C
00007cc2f47cf4e2  lea r14, [rax+0x32]
00007cc2f47cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf4ec  pinsrb xmm14, r12d, 0x0C
00007cc2f47cf4f3  lea r14, [rax+0x33]
00007cc2f47cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf4fd  pinsrb xmm13, r12d, 0x0C
00007cc2f47cf504  lea r14, [rax+0x34]
00007cc2f47cf508  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf50e  pinsrb xmm1, r12d, 0x0D
00007cc2f47cf515  lea r14, [rax+0x35]
00007cc2f47cf519  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf51f  pinsrb xmm15, r12d, 0x0D
00007cc2f47cf526  lea r14, [rax+0x36]
00007cc2f47cf52a  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf530  pinsrb xmm14, r12d, 0x0D
00007cc2f47cf537  lea r14, [rax+0x37]
00007cc2f47cf53b  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf541  pinsrb xmm13, r12d, 0x0D
00007cc2f47cf548  lea r14, [rax+0x38]
00007cc2f47cf54c  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf552  pinsrb xmm1, r12d, 0x0E
00007cc2f47cf559  lea r14, [rax+0x39]
00007cc2f47cf55d  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf563  pinsrb xmm15, r12d, 0x0E
00007cc2f47cf56a  lea r14, [rax+0x3A]
00007cc2f47cf56e  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf574  pinsrb xmm14, r12d, 0x0E
00007cc2f47cf57b  lea r14, [rax+0x3B]
00007cc2f47cf57f  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf585  pinsrb xmm13, r12d, 0x0E
00007cc2f47cf58c  lea r14, [rax+0x3C]
00007cc2f47cf590  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf596  pinsrb xmm1, r12d, 0x0F
00007cc2f47cf59d  movaps [r15+0x110], xmm1
00007cc2f47cf5a5  lea r14, [rax+0x3D]
00007cc2f47cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf5af  pinsrb xmm15, r12d, 0x0F
00007cc2f47cf5b6  movaps [r15+0x120], xmm15
00007cc2f47cf5be  lea r14, [rax+0x3E]
00007cc2f47cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007cc2f47cf5c8  pinsrb xmm14, r12d, 0x0F
00007cc2f47cf5cf  movaps [r15+0x130], xmm14
00007cc2f47cf5d7  lea r14, [rax+0x3F]
00007cc2f47cf5db  movzx eax, byte ptr [r13+r14*1]
00007cc2f47cf5e1  pinsrb xmm13, eax, 0x0F
00007cc2f47cf5e8  movaps [r15+0x140], xmm13
00007cc2f47cf5f0  movq xmm1, qword ptr [r15+0x120]
00007cc2f47cf5f9  pmovzxbw xmm1, xmm1
00007cc2f47cf5fe  psllw xmm1, 0x00
00007cc2f47cf603  movaps [r15+0x150], xmm1
00007cc2f47cf60b  movq xmm1, qword ptr [r15+0x130]
00007cc2f47cf614  pmovzxbw xmm1, xmm1
00007cc2f47cf619  psllw xmm1, 0x00
00007cc2f47cf61e  movaps [r15+0x160], xmm1
00007cc2f47cf626  movq xmm1, qword ptr [r15+0x110]
00007cc2f47cf62f  pmovzxbw xmm1, xmm1
00007cc2f47cf634  psllw xmm1, 0x00
00007cc2f47cf639  movaps [r15+0x170], xmm1
00007cc2f47cf641  movaps xmm15, [r15+0x110]
00007cc2f47cf649  pextrq rax, xmm15, 0x01
00007cc2f47cf650  movq xmm15, rax
00007cc2f47cf655  pmovzxbw xmm15, xmm15
00007cc2f47cf65b  psllw xmm15, 0x00
00007cc2f47cf661  movaps [r15+0x180], xmm15
00007cc2f47cf669  movaps xmm14, [r15+0x120]
00007cc2f47cf671  pextrq rax, xmm14, 0x01
00007cc2f47cf678  movq xmm14, rax
00007cc2f47cf67d  pmovzxbw xmm14, xmm14
00007cc2f47cf683  psllw xmm14, 0x00
00007cc2f47cf689  movaps [r15+0x210], xmm14
00007cc2f47cf691  movaps xmm13, [r15+0x130]
00007cc2f47cf699  pextrq rax, xmm13, 0x01
00007cc2f47cf6a0  movq xmm13, rax
00007cc2f47cf6a5  pmovzxbw xmm13, xmm13
00007cc2f47cf6ab  psllw xmm13, 0x00
00007cc2f47cf6b1  movaps [r15+0x220], xmm13
00007cc2f47cf6b9  movq xmm12, qword ptr [r15+0x140]
00007cc2f47cf6c2  pmovzxbw xmm12, xmm12
00007cc2f47cf6c8  psllw xmm12, 0x00
00007cc2f47cf6ce  movaps [r15+0x250], xmm12
00007cc2f47cf6d6  movaps xmm12, [r15+0x140]
00007cc2f47cf6de  pextrq rax, xmm12, 0x01
00007cc2f47cf6e5  movq xmm12, rax
00007cc2f47cf6ea  pmovzxbw xmm12, xmm12
00007cc2f47cf6f0  psllw xmm12, 0x00
00007cc2f47cf6f6  movaps [r15+0x110], xmm12
00007cc2f47cf6fe  movq xmm11, qword ptr [r15+0x150]
00007cc2f47cf707  pmovzxwd xmm11, xmm11
00007cc2f47cf70d  pslld xmm11, 0x10
00007cc2f47cf713  movq xmm10, qword ptr [r15+0x160]
00007cc2f47cf71c  pmovzxwd xmm10, xmm10
00007cc2f47cf722  pslld xmm10, 0x08
00007cc2f47cf728  pextrq rax, xmm1, 0x01
00007cc2f47cf72f  movq xmm1, rax
00007cc2f47cf734  pmovzxwd xmm1, xmm1
00007cc2f47cf739  pslld xmm1, 0x00
00007cc2f47cf73e  movaps [r15+0x260], xmm1
00007cc2f47cf746  pextrq rax, xmm15, 0x01
00007cc2f47cf74d  movq xmm15, rax
00007cc2f47cf752  pmovzxwd xmm15, xmm15
00007cc2f47cf758  pslld xmm15, 0x00
00007cc2f47cf75e  movaps [r15+0x270], xmm15
00007cc2f47cf766  movq xmm9, qword ptr [r15+0x170]
00007cc2f47cf76f  pmovzxwd xmm9, xmm9
00007cc2f47cf775  pslld xmm9, 0x00
00007cc2f47cf77b  pextrq rax, xmm14, 0x01
00007cc2f47cf782  movq xmm14, rax
00007cc2f47cf787  pmovzxwd xmm14, xmm14
00007cc2f47cf78d  pslld xmm14, 0x10
00007cc2f47cf793  movaps [r15+0x280], xmm14
00007cc2f47cf79b  movq xmm8, qword ptr [r15+0x180]
00007cc2f47cf7a4  pmovzxwd xmm8, xmm8
00007cc2f47cf7aa  pslld xmm8, 0x00
00007cc2f47cf7b0  movq xmm7, qword ptr [r15+0x210]
00007cc2f47cf7b9  pmovzxwd xmm7, xmm7
00007cc2f47cf7be  pslld xmm7, 0x10
00007cc2f47cf7c3  movaps xmm6, [r15+0x150]
00007cc2f47cf7cb  pextrq rax, xmm6, 0x01
00007cc2f47cf7d2  movq xmm6, rax
00007cc2f47cf7d7  pmovzxwd xmm6, xmm6
00007cc2f47cf7dc  pslld xmm6, 0x10
00007cc2f47cf7e1  por xmm11, xmm10
00007cc2f47cf7e6  movaps [r15+0x230], xmm11
00007cc2f47cf7ee  pextrq rax, xmm13, 0x01
00007cc2f47cf7f5  movq xmm13, rax
00007cc2f47cf7fa  pmovzxwd xmm13, xmm13
00007cc2f47cf800  pslld xmm13, 0x08
00007cc2f47cf806  movaps [r15+0x240], xmm13
00007cc2f47cf80e  movq xmm10, qword ptr [r15+0x220]
00007cc2f47cf817  pmovzxwd xmm10, xmm10
00007cc2f47cf81d  pslld xmm10, 0x08
00007cc2f47cf823  movaps xmm5, [r15+0x160]
00007cc2f47cf82b  pextrq rax, xmm5, 0x01
00007cc2f47cf832  movq xmm5, rax
00007cc2f47cf837  pmovzxwd xmm5, xmm5
00007cc2f47cf83c  pslld xmm5, 0x08
00007cc2f47cf841  pslld xmm9, 0x18
00007cc2f47cf847  pslld xmm15, 0x18
00007cc2f47cf84d  pslld xmm8, 0x18
00007cc2f47cf853  movq xmm4, qword ptr [r15+0x250]
00007cc2f47cf85c  pmovzxwd xmm4, xmm4
00007cc2f47cf861  pslld xmm4, 0x00
00007cc2f47cf866  por xmm14, xmm13
00007cc2f47cf86b  por xmm7, xmm10
00007cc2f47cf870  movaps [r15+0x210], xmm7
00007cc2f47cf878  pslld xmm1, 0x18
00007cc2f47cf87d  movaps [r15+0x220], xmm1
00007cc2f47cf885  por xmm6, xmm5
00007cc2f47cf889  por xmm11, xmm9
00007cc2f47cf88e  movaps [r15+0x160], xmm11
00007cc2f47cf896  pextrq rax, xmm12, 0x01
00007cc2f47cf89d  movq xmm13, rax
00007cc2f47cf8a2  pmovzxwd xmm13, xmm13
00007cc2f47cf8a8  pslld xmm13, 0x00
00007cc2f47cf8ae  movaps [r15+0x170], xmm13
00007cc2f47cf8b6  movq xmm12, qword ptr [r15+0x110]
00007cc2f47cf8bf  pmovzxwd xmm12, xmm12
00007cc2f47cf8c5  pslld xmm12, 0x00
00007cc2f47cf8cb  por xmm14, xmm15
00007cc2f47cf8d0  por xmm7, xmm8
00007cc2f47cf8d5  movaps xmm15, [r15+0x250]
00007cc2f47cf8dd  pextrq rax, xmm15, 0x01
00007cc2f47cf8e4  movq xmm15, rax
00007cc2f47cf8e9  pmovzxwd xmm15, xmm15
00007cc2f47cf8ef  pslld xmm15, 0x00
00007cc2f47cf8f5  movaps [r15+0x180], xmm15
00007cc2f47cf8fd  por xmm6, xmm1
00007cc2f47cf901  movaps [r15+0x150], xmm6
00007cc2f47cf909  por xmm11, xmm4
00007cc2f47cf90e  movaps [r15+0x140], xmm11
00007cc2f47cf916  por xmm7, xmm12
00007cc2f47cf91b  movaps [r15+0x110], xmm7
00007cc2f47cf923  por xmm14, xmm13
00007cc2f47cf928  movaps [r15+0x120], xmm14
00007cc2f47cf930  por xmm6, xmm15
00007cc2f47cf935  movaps [r15+0x130], xmm6
00007cc2f47cf93d  mov rax, [r15+0xF8]
00007cc2f47cf944  lea r14, [rax+0x20]
00007cc2f47cf948  movups [r13+r14*1], xmm7
00007cc2f47cf94e  lea r14, [rax+0x30]
00007cc2f47cf952  movups [r13+r14*1], xmm14
00007cc2f47cf958  movups [r13+rax*1], xmm11
00007cc2f47cf95e  lea r14, [rax+0x10]
00007cc2f47cf962  movups [r13+r14*1], xmm6
00007cc2f47cf968  mov r14d, [r13+rax*1]
00007cc2f47cf96d  mov rax, [r15+0x48]
00007cc2f47cf971  mov [r15+0x68], rax
00007cc2f47cf975  mov qword ptr [r15+0x58], 0x04
00007cc2f47cf97d  lea r12, [rax+0x04]
00007cc2f47cf981  mov r11d, [r13+r12*1]
00007cc2f47cf986  mov [rsp+0x10], r11d
00007cc2f47cf98b  mov r11d, r11d
00007cc2f47cf98e  mov [r15+0x70], r11
00007cc2f47cf992  lea r12, [rax+0x38]
00007cc2f47cf996  mov r11d, [r13+r12*1]
00007cc2f47cf99b  lea r12, [rax+0x24]
00007cc2f47cf99f  mov r10d, [r13+r12*1]
00007cc2f47cf9a4  mov [rsp+0x20], r10d
00007cc2f47cf9a9  mov r10d, r10d
00007cc2f47cf9ac  mov [r15+0x90], r10
00007cc2f47cf9b3  mov [rsp+0x30], rax
00007cc2f47cf9b8  xor eax, eax
00007cc2f47cf9ba  mov r12d, 0x04
00007cc2f47cf9c0  mov r10d, 0xC0
00007cc2f47cf9c6  cmp r12, r10
00007cc2f47cf9c9  cmc
00007cc2f47cf9ca  lahf
00007cc2f47cf9cb  seto al
00007cc2f47cf9ce  mov [r15+0x108], eax
00007cc2f47cf9d5  mov eax, [rsp+0x10]
00007cc2f47cf9d9  mov r12d, [rsp+0x10]
00007cc2f47cf9de  shrd eax, r12d, 0x07
00007cc2f47cf9e3  mov [rsp+0x10], r11d
00007cc2f47cf9e8  mov r10d, [rsp+0x10]
00007cc2f47cf9ed  shrd r11d, r10d, 0x11
00007cc2f47cf9f2  mov r9d, [rsp+0x20]
00007cc2f47cf9f7  lea r8d, [r9d+r14d*1]
00007cc2f47cf9fc  rorx r14d, r12d, 0x12
00007cc2f47cfa02  xor eax, r14d
00007cc2f47cfa05  rorx r14d, r10d, 0x13
00007cc2f47cfa0b  xor r11d, r14d
00007cc2f47cfa0e  mov [rsp+0x10], r11d
00007cc2f47cfa13  mov r11d, r11d
00007cc2f47cfa16  mov [r15+0x88], r11
00007cc2f47cfa1d  mov [rsp+0x20], r12d
00007cc2f47cfa22  shr r12d, 0x03
00007cc2f47cfa26  xor eax, r12d
00007cc2f47cfa29  mov [rsp+0x40], eax
00007cc2f47cfa2d  mov eax, eax
00007cc2f47cfa2f  mov [r15+0x80], rax
00007cc2f47cfa36  shr r10d, 0x0A
00007cc2f47cfa3a  mov eax, [rsp+0x10]
00007cc2f47cfa3e  xor eax, r10d
00007cc2f47cfa41  mov [rsp+0x10], eax
00007cc2f47cfa45  mov eax, eax
00007cc2f47cfa47  mov [r15+0x78], rax
00007cc2f47cfa4b  mov eax, [rsp+0x40]
00007cc2f47cfa4f  lea r14d, [r8d+eax*1]
00007cc2f47cfa54  mov eax, [rsp+0x10]
00007cc2f47cfa58  lea r12d, [r14d+eax*1]
00007cc2f47cfa5d  mov rax, [rsp+0x30]
00007cc2f47cfa62  lea r14, [rax+0x40]
00007cc2f47cfa66  mov [r13+r14*1], r12d
00007cc2f47cfa6b  mov eax, [rsp+0x20]
00007cc2f47cfa6f  mov eax, eax
00007cc2f47cfa71  mov [r15+0x60], rax
00007cc2f47cfa75  mov eax, [r15+0x108]
00007cc2f47cfa7c  sahf
00007cc2f47cfa7d  jnz 0x00007CC2F47CFAAF
00007cc2f47cfa7f  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cfa87  jz 0x00007CC2F47CFF70
00007cc2f47cfa8d  nop [rax+rax*1], ax
00007cc2f47cfa96  nop [rax+rax*1], eax
00007cc2f47cfa9e  mov eax, 0x41088C
00007cc2f47cfaa3  mov [r15+0x100], rax
00007cc2f47cfaaa  jmp 0x00007CC2F45FE110
00007cc2f47cfaaf  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cfab7  jz 0x00007CC2F47CFDC0
00007cc2f47cfabd  nop [rax+rax*1], ax
00007cc2f47cfac6  nop [rax+rax*1], eax
00007cc2f47cface  mov eax, 0x410844
00007cc2f47cfad3  mov [r15+0x100], rax
00007cc2f47cfada  jmp 0x00007CC2F45FE110
00007cc2f47cfadf  int3
00007cc2f47cfae0  call 0x00007CC2F460D860
00007cc2f47cfae5  jmp 0x00007CC2F47CF17A
00007cc2f47cfaea  call 0x00007CC2F46E2420
00007cc2f47cfaef  jmp 0x00007CC2F47CF193
00007cc2f47cfaf4  call 0x00007CC2F46E2420
00007cc2f47cfaf9  jmp 0x00007CC2F47CF1AC
00007cc2f47cfafe  call 0x00007CC2F46E2420
00007cc2f47cfb03  jmp 0x00007CC2F47CF1C5
00007cc2f47cfb08  call 0x00007CC2F46E2420
00007cc2f47cfb0d  jmp 0x00007CC2F47CF1DE
00007cc2f47cfb12  call 0x00007CC2F46E2420
00007cc2f47cfb17  jmp 0x00007CC2F47CF1EF
00007cc2f47cfb1c  call 0x00007CC2F46E2420
00007cc2f47cfb21  jmp 0x00007CC2F47CF200
00007cc2f47cfb26  call 0x00007CC2F46E2420
00007cc2f47cfb2b  jmp 0x00007CC2F47CF211
00007cc2f47cfb30  call 0x00007CC2F46E2420
00007cc2f47cfb35  jmp 0x00007CC2F47CF222
00007cc2f47cfb3a  call 0x00007CC2F46E2420
00007cc2f47cfb3f  jmp 0x00007CC2F47CF233
00007cc2f47cfb44  call 0x00007CC2F46E2420
00007cc2f47cfb49  jmp 0x00007CC2F47CF244
00007cc2f47cfb4e  call 0x00007CC2F46E2420
00007cc2f47cfb53  jmp 0x00007CC2F47CF255
00007cc2f47cfb58  call 0x00007CC2F46E2420
00007cc2f47cfb5d  jmp 0x00007CC2F47CF266
00007cc2f47cfb62  call 0x00007CC2F46E2420
00007cc2f47cfb67  jmp 0x00007CC2F47CF277
00007cc2f47cfb6c  call 0x00007CC2F46E2420
00007cc2f47cfb71  jmp 0x00007CC2F47CF288
00007cc2f47cfb76  call 0x00007CC2F46E2420
00007cc2f47cfb7b  jmp 0x00007CC2F47CF299
00007cc2f47cfb80  call 0x00007CC2F46E2420
00007cc2f47cfb85  jmp 0x00007CC2F47CF2AA
00007cc2f47cfb8a  call 0x00007CC2F46E2420
00007cc2f47cfb8f  jmp 0x00007CC2F47CF2BB
00007cc2f47cfb94  call 0x00007CC2F46E2420
00007cc2f47cfb99  jmp 0x00007CC2F47CF2CC
00007cc2f47cfb9e  call 0x00007CC2F46E2420
00007cc2f47cfba3  jmp 0x00007CC2F47CF2DD
00007cc2f47cfba8  call 0x00007CC2F46E2420
00007cc2f47cfbad  jmp 0x00007CC2F47CF2EE
00007cc2f47cfbb2  call 0x00007CC2F46E2420
00007cc2f47cfbb7  jmp 0x00007CC2F47CF2FF
00007cc2f47cfbbc  call 0x00007CC2F46E2420
00007cc2f47cfbc1  jmp 0x00007CC2F47CF310
00007cc2f47cfbc6  call 0x00007CC2F46E2420
00007cc2f47cfbcb  jmp 0x00007CC2F47CF321
00007cc2f47cfbd0  call 0x00007CC2F46E2420
00007cc2f47cfbd5  jmp 0x00007CC2F47CF332
00007cc2f47cfbda  call 0x00007CC2F46E2420
00007cc2f47cfbdf  jmp 0x00007CC2F47CF343
00007cc2f47cfbe4  call 0x00007CC2F46E2420
00007cc2f47cfbe9  jmp 0x00007CC2F47CF354
00007cc2f47cfbee  call 0x00007CC2F46E2420
00007cc2f47cfbf3  jmp 0x00007CC2F47CF365
00007cc2f47cfbf8  call 0x00007CC2F46E2420
00007cc2f47cfbfd  jmp 0x00007CC2F47CF376
00007cc2f47cfc02  call 0x00007CC2F46E2420
00007cc2f47cfc07  jmp 0x00007CC2F47CF387
00007cc2f47cfc0c  call 0x00007CC2F46E2420
00007cc2f47cfc11  jmp 0x00007CC2F47CF398
00007cc2f47cfc16  call 0x00007CC2F46E2420
00007cc2f47cfc1b  jmp 0x00007CC2F47CF3A9
00007cc2f47cfc20  call 0x00007CC2F46E2420
00007cc2f47cfc25  jmp 0x00007CC2F47CF3BA
00007cc2f47cfc2a  call 0x00007CC2F46E2420
00007cc2f47cfc2f  jmp 0x00007CC2F47CF3CB
00007cc2f47cfc34  call 0x00007CC2F46E2420
00007cc2f47cfc39  jmp 0x00007CC2F47CF3DC
00007cc2f47cfc3e  call 0x00007CC2F46E2420
00007cc2f47cfc43  jmp 0x00007CC2F47CF3ED
00007cc2f47cfc48  call 0x00007CC2F46E2420
00007cc2f47cfc4d  jmp 0x00007CC2F47CF3FE
00007cc2f47cfc52  call 0x00007CC2F46E2420
00007cc2f47cfc57  jmp 0x00007CC2F47CF40F
00007cc2f47cfc5c  call 0x00007CC2F46E2420
00007cc2f47cfc61  jmp 0x00007CC2F47CF420
00007cc2f47cfc66  call 0x00007CC2F46E2420
00007cc2f47cfc6b  jmp 0x00007CC2F47CF431
00007cc2f47cfc70  call 0x00007CC2F46E2420
00007cc2f47cfc75  jmp 0x00007CC2F47CF442
00007cc2f47cfc7a  call 0x00007CC2F46E2420
00007cc2f47cfc7f  jmp 0x00007CC2F47CF453
00007cc2f47cfc84  call 0x00007CC2F46E2420
00007cc2f47cfc89  jmp 0x00007CC2F47CF464
00007cc2f47cfc8e  call 0x00007CC2F46E2420
00007cc2f47cfc93  jmp 0x00007CC2F47CF475
00007cc2f47cfc98  call 0x00007CC2F46E2420
00007cc2f47cfc9d  jmp 0x00007CC2F47CF486
00007cc2f47cfca2  call 0x00007CC2F46E2420
00007cc2f47cfca7  jmp 0x00007CC2F47CF497
00007cc2f47cfcac  call 0x00007CC2F46E2420
00007cc2f47cfcb1  jmp 0x00007CC2F47CF4A8
00007cc2f47cfcb6  call 0x00007CC2F46E2420
00007cc2f47cfcbb  jmp 0x00007CC2F47CF4B9
00007cc2f47cfcc0  call 0x00007CC2F46E2420
00007cc2f47cfcc5  jmp 0x00007CC2F47CF4CA
00007cc2f47cfcca  call 0x00007CC2F46E2420
00007cc2f47cfccf  jmp 0x00007CC2F47CF4DB
00007cc2f47cfcd4  call 0x00007CC2F46E2420
00007cc2f47cfcd9  jmp 0x00007CC2F47CF4EC
00007cc2f47cfcde  call 0x00007CC2F46E2420
00007cc2f47cfce3  jmp 0x00007CC2F47CF4FD
00007cc2f47cfce8  call 0x00007CC2F46E2420
00007cc2f47cfced  jmp 0x00007CC2F47CF50E
00007cc2f47cfcf2  call 0x00007CC2F46E2420
00007cc2f47cfcf7  jmp 0x00007CC2F47CF51F
00007cc2f47cfcfc  call 0x00007CC2F46E2420
00007cc2f47cfd01  jmp 0x00007CC2F47CF530
00007cc2f47cfd06  call 0x00007CC2F46E2420
00007cc2f47cfd0b  jmp 0x00007CC2F47CF541
00007cc2f47cfd10  call 0x00007CC2F46E2420
00007cc2f47cfd15  jmp 0x00007CC2F47CF552
00007cc2f47cfd1a  call 0x00007CC2F46E2420
00007cc2f47cfd1f  jmp 0x00007CC2F47CF563
00007cc2f47cfd24  call 0x00007CC2F46E2420
00007cc2f47cfd29  jmp 0x00007CC2F47CF574
00007cc2f47cfd2e  call 0x00007CC2F46E2420
00007cc2f47cfd33  jmp 0x00007CC2F47CF585
00007cc2f47cfd38  call 0x00007CC2F46E2420
00007cc2f47cfd3d  jmp 0x00007CC2F47CF596
00007cc2f47cfd42  call 0x00007CC2F46E2420
00007cc2f47cfd47  jmp 0x00007CC2F47CF5AF
00007cc2f47cfd4c  call 0x00007CC2F46E2420
00007cc2f47cfd51  jmp 0x00007CC2F47CF5C8
00007cc2f47cfd56  call 0x00007CC2F46D5610
00007cc2f47cfd5b  jmp 0x00007CC2F47CF5E1
00007cc2f47cfd60  call 0x00007CC2F46DC580
00007cc2f47cfd65  jmp 0x00007CC2F47CF94E
00007cc2f47cfd6a  call 0x00007CC2F46E46C0
00007cc2f47cfd6f  jmp 0x00007CC2F47CF958
00007cc2f47cfd74  call 0x00007CC2F4609E90
00007cc2f47cfd79  jmp 0x00007CC2F47CF95E
00007cc2f47cfd7e  call 0x00007CC2F46DB310
00007cc2f47cfd83  jmp 0x00007CC2F47CF968
00007cc2f47cfd88  call 0x00007CC2F460DAE0
00007cc2f47cfd8d  jmp 0x00007CC2F47CF96D
00007cc2f47cfd92  call 0x00007CC2F46C0230
00007cc2f47cfd97  jmp 0x00007CC2F47CF986
00007cc2f47cfd9c  call 0x00007CC2F46C0230
00007cc2f47cfda1  jmp 0x00007CC2F47CF99B
00007cc2f47cfda6  call 0x00007CC2F46BEFC0
00007cc2f47cfdab  jmp 0x00007CC2F47CF9A4
00007cc2f47cfdb0  call 0x00007CC2F46E2BA0
00007cc2f47cfdb5  jmp 0x00007CC2F47CFA6B
00007cc2f47cfdba  int3
00007cc2f47cfdbb  nop [rax+rax*1], eax
00007cc2f47cfdc0  mov rax, [r15+0x48]
00007cc2f47cfdc4  mov r14, [r15+0x58]
00007cc2f47cfdc8  lea r12, [rax+r14*1]
00007cc2f47cfdcc  mov [r15+0x68], r12
00007cc2f47cfdd0  lea rax, [r14+0x04]
00007cc2f47cfdd4  mov [r15+0x58], rax
00007cc2f47cfdd8  lea r14, [r12+0x04]
00007cc2f47cfddd  mov r11d, [r13+r14*1]
00007cc2f47cfde2  mov [rsp+0x10], r11d
00007cc2f47cfde7  mov r11d, r11d
00007cc2f47cfdea  mov [r15+0x70], r11
00007cc2f47cfdee  lea r14, [r12+0x38]
00007cc2f47cfdf3  mov r11d, [r13+r14*1]
00007cc2f47cfdf8  lea r14, [r12+0x24]
00007cc2f47cfdfd  mov r10d, [r13+r14*1]
00007cc2f47cfe02  mov [rsp+0x20], r10d
00007cc2f47cfe07  mov r10d, r10d
00007cc2f47cfe0a  mov [r15+0x90], r10
00007cc2f47cfe11  mov [rsp+0x30], rax
00007cc2f47cfe16  xor eax, eax
00007cc2f47cfe18  mov r14, [rsp+0x30]
00007cc2f47cfe1d  mov r10d, 0xC0
00007cc2f47cfe23  cmp r14, r10
00007cc2f47cfe26  cmc
00007cc2f47cfe27  lahf
00007cc2f47cfe28  seto al
00007cc2f47cfe2b  mov [r15+0x108], eax
00007cc2f47cfe32  mov eax, [rsp+0x10]
00007cc2f47cfe36  mov r14d, [rsp+0x10]
00007cc2f47cfe3b  shrd eax, r14d, 0x07
00007cc2f47cfe40  mov [rsp+0x10], r11d
00007cc2f47cfe45  mov r10d, [rsp+0x10]
00007cc2f47cfe4a  shrd r11d, r10d, 0x11
00007cc2f47cfe4f  mov r9d, [r15+0x60]
00007cc2f47cfe53  mov r8d, [rsp+0x20]
00007cc2f47cfe58  lea ebp, [r8d+r9d*1]
00007cc2f47cfe5d  rorx r9d, r14d, 0x12
00007cc2f47cfe63  xor eax, r9d
00007cc2f47cfe66  rorx r9d, r10d, 0x13
00007cc2f47cfe6c  xor r11d, r9d
00007cc2f47cfe6f  mov [rsp+0x10], r11d
00007cc2f47cfe74  mov r11d, r11d
00007cc2f47cfe77  mov [r15+0x88], r11
00007cc2f47cfe7e  mov [rsp+0x20], r14d
00007cc2f47cfe83  shr r14d, 0x03
00007cc2f47cfe87  xor eax, r14d
00007cc2f47cfe8a  mov [rsp+0x30], eax
00007cc2f47cfe8e  mov eax, eax
00007cc2f47cfe90  mov [r15+0x80], rax
00007cc2f47cfe97  shr r10d, 0x0A
00007cc2f47cfe9b  mov eax, [rsp+0x10]
00007cc2f47cfe9f  xor eax, r10d
00007cc2f47cfea2  mov [rsp+0x10], eax
00007cc2f47cfea6  mov eax, eax
00007cc2f47cfea8  mov [r15+0x78], rax
00007cc2f47cfeac  mov eax, [rsp+0x30]
00007cc2f47cfeb0  lea r14d, [ebp+eax*1]
00007cc2f47cfeb6  mov eax, [rsp+0x10]
00007cc2f47cfeba  lea r11d, [r14d+eax*1]
00007cc2f47cfebf  lea rax, [r12+0x40]
00007cc2f47cfec4  mov [r13+rax*1], r11d
00007cc2f47cfec9  mov eax, [rsp+0x20]
00007cc2f47cfecd  mov eax, eax
00007cc2f47cfecf  mov [r15+0x60], rax
00007cc2f47cfed3  mov eax, [r15+0x108]
00007cc2f47cfeda  sahf
00007cc2f47cfedb  jnz 0x00007CC2F47CFF0D
00007cc2f47cfedd  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cfee5  jz 0x00007CC2F47CFF70
00007cc2f47cfeeb  nop [rax+rax*1], ax
00007cc2f47cfef4  nop [rax+rax*1], eax
00007cc2f47cfefc  mov eax, 0x41088C
00007cc2f47cff01  mov [r15+0x100], rax
00007cc2f47cff08  jmp 0x00007CC2F45FE110
00007cc2f47cff0d  cmp dword ptr [r15+0x318], 0x00
00007cc2f47cff15  jz 0x00007CC2F47CFDC0
00007cc2f47cff1b  nop [rax+rax*1], ax
00007cc2f47cff24  nop [rax+rax*1], eax
00007cc2f47cff2c  mov eax, 0x410844
00007cc2f47cff31  mov [r15+0x100], rax
00007cc2f47cff38  jmp 0x00007CC2F45FE110
00007cc2f47cff3d  int3
00007cc2f47cff3e  call 0x00007CC2F46E1430
00007cc2f47cff43  jmp 0x00007CC2F47CFDE2
00007cc2f47cff48  call 0x00007CC2F46E1430
00007cc2f47cff4d  jmp 0x00007CC2F47CFDF8
00007cc2f47cff52  call 0x00007CC2F46E01C0
00007cc2f47cff57  jmp 0x00007CC2F47CFE02
00007cc2f47cff5c  call 0x00007CC2F460A860
00007cc2f47cff61  jmp 0x00007CC2F47CFEC9
00007cc2f47cff66  int3
00007cc2f47cff67  nop [rax+rax*1], ax
00007cc2f47cff70  mov rax, [r15]
00007cc2f47cff73  mov r14d, [r13+rax*1]
00007cc2f47cff78  lea r12, [rax+0x04]
00007cc2f47cff7c  mov r11d, [r13+r12*1]
00007cc2f47cff81  mov [rsp+0x10], r14d
00007cc2f47cff86  mov r14d, r14d
00007cc2f47cff89  mov [r15+0x78], r14
00007cc2f47cff8d  mov [rsp+0x20], r11d
00007cc2f47cff92  mov r11d, r11d
00007cc2f47cff95  mov [r15+0x80], r11
00007cc2f47cff9c  lea r14, [rax+0x08]
00007cc2f47cffa0  mov r12d, [r13+r14*1]
00007cc2f47cffa5  lea r14, [rax+0x0C]
00007cc2f47cffa9  mov r11d, [r13+r14*1]
00007cc2f47cffae  mov [rsp+0x30], r12d
00007cc2f47cffb3  mov r12d, r12d
00007cc2f47cffb6  mov [r15+0x70], r12
00007cc2f47cffba  mov [rsp+0x40], r11d
00007cc2f47cffbf  mov r11d, r11d
00007cc2f47cffc2  mov [r15+0x68], r11
00007cc2f47cffc6  lea r14, [rax+0x18]
00007cc2f47cffca  mov r12d, [r13+r14*1]
00007cc2f47cffcf  lea r14, [rax+0x1C]
00007cc2f47cffd3  mov r11d, [r13+r14*1]
00007cc2f47cffd8  mov [rsp+0x50], r12d
00007cc2f47cffdd  mov r12d, r12d
00007cc2f47cffe0  mov [r15+0x58], r12
00007cc2f47cffe4  mov [rsp+0x60], r11d
00007cc2f47cffe9  mov r11d, r11d
00007cc2f47cffec  mov [r15+0x60], r11
00007cc2f47cfff0  lea r14, [rax+0x10]
00007cc2f47cfff4  mov r12d, [r13+r14*1]
00007cc2f47cfff9  lea r14, [rax+0x14]
00007cc2f47cfffd  mov eax, [r13+r14*1]
00007cc2f47d0002  mov [rsp+0x70], r12d
00007cc2f47d0007  mov r12d, r12d
00007cc2f47d000a  mov [r15+0x18], r12
00007cc2f47d000e  mov [rsp+0x80], eax
00007cc2f47d0015  mov eax, eax
00007cc2f47d0017  mov [r15+0x90], rax
00007cc2f47d001e  mov eax, [rsp+0x70]
00007cc2f47d0022  mov eax, eax
00007cc2f47d0024  mov [r15+0x30], rax
00007cc2f47d0028  mov eax, [rsp+0x50]
00007cc2f47d002c  mov eax, eax
00007cc2f47d002e  mov [r15+0xA0], rax
00007cc2f47d0035  mov eax, [rsp+0x30]
00007cc2f47d0039  mov eax, eax
00007cc2f47d003b  mov [r15+0x28], rax
00007cc2f47d003f  mov eax, [rsp+0x20]
00007cc2f47d0043  mov eax, eax
00007cc2f47d0045  mov [r15+0x98], rax
00007cc2f47d004c  mov eax, [rsp+0x10]
00007cc2f47d0050  mov eax, eax
00007cc2f47d0052  mov [r15+0x38], rax
00007cc2f47d0056  mov eax, [rsp+0x70]
00007cc2f47d005a  mov r14d, [rsp+0x70]
00007cc2f47d005f  shrd eax, r14d, 0x06
00007cc2f47d0064  mov [rsp+0x70], r14d
00007cc2f47d0069  mov r12d, [rsp+0x80]
00007cc2f47d0071  and r14d, r12d
00007cc2f47d0074  mov r11d, [rsp+0x10]
00007cc2f47d0079  mov r10d, [rsp+0x10]
00007cc2f47d007e  shrd r11d, r10d, 0x02
00007cc2f47d0083  mov [rsp+0x10], r12d
00007cc2f47d0088  mov r12d, r12d
00007cc2f47d008b  mov [r15+0x20], r12
00007cc2f47d008f  mov r12, [r15+0x50]
00007cc2f47d0093  mov r9d, [r13+r12*1]
00007cc2f47d0098  mov r12d, [rsp+0x50]
00007cc2f47d009d  mov r8d, [rsp+0x70]
00007cc2f47d00a2  andn ebp, r8d, r12d
00007cc2f47d00a7  mov edi, [rsp+0x60]
00007cc2f47d00ab  lea esi, [r14d+edi*1]
00007cc2f47d00b0  rorx r14d, r8d, 0x0B
00007cc2f47d00b6  xor eax, r14d
00007cc2f47d00b9  rorx r14d, r10d, 0x0D
00007cc2f47d00bf  xor r11d, r14d
00007cc2f47d00c2  lea edi, [esi+ebp*1]
00007cc2f47d00c6  mov r14, [r15+0x48]
00007cc2f47d00ca  mov ebp, [r13+r14*1]
00007cc2f47d00cf  mov r14d, [rsp+0x30]
00007cc2f47d00d4  mov esi, [rsp+0x20]
00007cc2f47d00d8  and r14d, esi
00007cc2f47d00db  mov [rsp+0x20], r14d
00007cc2f47d00e0  mov r14d, r14d
00007cc2f47d00e3  mov [r15+0xD8], r14
00007cc2f47d00ea  lea r14d, [edi+r9d*1]
00007cc2f47d00ef  mov r9d, [rsp+0x30]
00007cc2f47d00f4  xor r9d, esi
00007cc2f47d00f7  rorx edi, r8d, 0x19
00007cc2f47d00fd  xor eax, edi
00007cc2f47d00ff  and r9d, r10d
00007cc2f47d0102  rorx edi, r10d, 0x16
00007cc2f47d0108  xor r11d, edi
00007cc2f47d010b  mov [rsp+0x30], r11d
00007cc2f47d0110  mov r11d, r11d
00007cc2f47d0113  mov [r15+0xD0], r11
00007cc2f47d011a  lea r11d, [r14d+ebp*1]
00007cc2f47d011f  mov r10d, [rsp+0x20]
00007cc2f47d0124  xor r9d, r10d
00007cc2f47d0127  lea r14d, [r11d+eax*1]
00007cc2f47d012c  mov qword ptr [r15+0x88], 0x04
00007cc2f47d0137  mov eax, [rsp+0x30]
00007cc2f47d013b  lea r11d, [r9d+eax*1]
00007cc2f47d0140  mov eax, [rsp+0x40]
00007cc2f47d0144  lea r10d, [r14d+eax*1]
00007cc2f47d0149  mov r10d, r10d
00007cc2f47d014c  mov [r15+0xB8], r10
00007cc2f47d0153  xor eax, eax
00007cc2f47d0155  mov r10d, 0x04
00007cc2f47d015b  mov r9d, 0x100
00007cc2f47d0161  cmp r10, r9
00007cc2f47d0164  cmc
00007cc2f47d0165  lahf
00007cc2f47d0166  seto al
00007cc2f47d0169  mov [r15+0x108], eax
00007cc2f47d0170  lea eax, [r11d+r14d*1]
00007cc2f47d0175  mov eax, eax
00007cc2f47d0177  mov [r15+0xA8], rax
00007cc2f47d017e  mov r12d, r12d
00007cc2f47d0181  mov [r15+0xB0], r12
00007cc2f47d0188  mov eax, [rsp+0x10]
00007cc2f47d018c  mov eax, eax
00007cc2f47d018e  mov [r15+0xC0], rax
00007cc2f47d0195  mov r8d, r8d
00007cc2f47d0198  mov [r15+0xC8], r8
00007cc2f47d019f  mov eax, [r15+0x108]
00007cc2f47d01a6  sahf
00007cc2f47d01a7  jnz 0x00007CC2F47D01D9
00007cc2f47d01a9  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d01b1  jz 0x00007CC2F47D04A0
00007cc2f47d01b7  nop [rax+rax*1], ax
00007cc2f47d01c0  nop [rax+rax*1], eax
00007cc2f47d01c8  mov eax, 0x41094C
00007cc2f47d01cd  mov [r15+0x100], rax
00007cc2f47d01d4  jmp 0x00007CC2F45FE110
00007cc2f47d01d9  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d01e1  jz 0x00007CC2F47D0270
00007cc2f47d01e7  nop [rax+rax*1], ax
00007cc2f47d01f0  nop [rax+rax*1], eax
00007cc2f47d01f8  mov eax, 0x4108C0
00007cc2f47d01fd  mov [r15+0x100], rax
00007cc2f47d0204  jmp 0x00007CC2F45FE110
00007cc2f47d0209  int3
00007cc2f47d020a  call 0x00007CC2F460DAE0
00007cc2f47d020f  jmp 0x00007CC2F47CFF78
00007cc2f47d0214  call 0x00007CC2F46C0230
00007cc2f47d0219  jmp 0x00007CC2F47CFF81
00007cc2f47d021e  call 0x00007CC2F46E26A0
00007cc2f47d0223  jmp 0x00007CC2F47CFFA5
00007cc2f47d0228  call 0x00007CC2F46E1430
00007cc2f47d022d  jmp 0x00007CC2F47CFFAE
00007cc2f47d0232  call 0x00007CC2F46E26A0
00007cc2f47d0237  jmp 0x00007CC2F47CFFCF
00007cc2f47d023c  call 0x00007CC2F46E1430
00007cc2f47d0241  jmp 0x00007CC2F47CFFD8
00007cc2f47d0246  call 0x00007CC2F46E26A0
00007cc2f47d024b  jmp 0x00007CC2F47CFFF9
00007cc2f47d0250  call 0x00007CC2F46D5890
00007cc2f47d0255  jmp 0x00007CC2F47D0002
00007cc2f47d025a  call 0x00007CC2F46BDD50
00007cc2f47d025f  jmp 0x00007CC2F47D0098
00007cc2f47d0264  call 0x00007CC2F46DA580
00007cc2f47d0269  jmp 0x00007CC2F47D00CF
00007cc2f47d026e  int3
00007cc2f47d026f  nop
00007cc2f47d0270  mov eax, [r15+0xB8]
00007cc2f47d0277  mov [rsp+0x10], eax
00007cc2f47d027b  mov eax, eax
00007cc2f47d027d  mov [r15+0x30], rax
00007cc2f47d0281  mov eax, [r15+0xC0]
00007cc2f47d0288  mov [rsp+0x20], eax
00007cc2f47d028c  mov eax, eax
00007cc2f47d028e  mov [r15+0xA0], rax
00007cc2f47d0295  mov eax, [r15+0x28]
00007cc2f47d0299  mov r14d, [r15+0x98]
00007cc2f47d02a0  mov [rsp+0x30], r14d
00007cc2f47d02a5  mov r14d, r14d
00007cc2f47d02a8  mov [r15+0x28], r14
00007cc2f47d02ac  mov r14d, [r15+0x38]
00007cc2f47d02b0  mov [rsp+0x40], r14d
00007cc2f47d02b5  mov r14d, r14d
00007cc2f47d02b8  mov [r15+0x98], r14
00007cc2f47d02bf  mov r14d, [r15+0xA8]
00007cc2f47d02c6  mov [rsp+0x50], r14d
00007cc2f47d02cb  mov r14d, r14d
00007cc2f47d02ce  mov [r15+0x38], r14
00007cc2f47d02d2  mov r14d, [rsp+0x10]
00007cc2f47d02d7  mov r12d, [rsp+0x10]
00007cc2f47d02dc  shrd r14d, r12d, 0x06
00007cc2f47d02e1  mov r11d, [r15+0xC8]
00007cc2f47d02e8  mov [rsp+0x10], r12d
00007cc2f47d02ed  and r12d, r11d
00007cc2f47d02f0  mov r10d, [rsp+0x50]
00007cc2f47d02f5  mov r9d, [rsp+0x50]
00007cc2f47d02fa  shrd r10d, r9d, 0x02
00007cc2f47d02ff  mov [rsp+0x50], r11d
00007cc2f47d0304  mov r11d, r11d
00007cc2f47d0307  mov [r15+0x20], r11
00007cc2f47d030b  mov r11, [r15+0x88]
00007cc2f47d0312  mov r8, [r15+0x50]
00007cc2f47d0316  lea rbp, [r8+r11*1]
00007cc2f47d031a  mov r8d, [r13+rbp*1]
00007cc2f47d031f  mov ebp, [rsp+0x20]
00007cc2f47d0323  mov edi, [rsp+0x10]
00007cc2f47d0327  andn esi, edi, ebp
00007cc2f47d032c  mov edx, [r15+0xB0]
00007cc2f47d0333  lea ecx, [r12d+edx*1]
00007cc2f47d0338  rorx r12d, edi, 0x0B
00007cc2f47d033e  xor r14d, r12d
00007cc2f47d0341  rorx r12d, r9d, 0x0D
00007cc2f47d0347  xor r10d, r12d
00007cc2f47d034a  lea r12d, [ecx+esi*1]
00007cc2f47d034f  mov rsi, [r15+0x48]
00007cc2f47d0353  lea rdx, [rsi+r11*1]
00007cc2f47d0357  mov esi, [r13+rdx*1]
00007cc2f47d035c  mov edx, [rsp+0x30]
00007cc2f47d0360  mov ecx, [rsp+0x40]
00007cc2f47d0364  and edx, ecx
00007cc2f47d0366  mov [rsp+0x10], edx
00007cc2f47d036a  mov edx, edx
00007cc2f47d036c  mov [r15+0xD8], rdx
00007cc2f47d0373  lea edx, [r12d+r8d*1]
00007cc2f47d0378  mov r12d, [rsp+0x30]
00007cc2f47d037d  xor r12d, ecx
00007cc2f47d0380  rorx r8d, edi, 0x19
00007cc2f47d0386  xor r14d, r8d
00007cc2f47d0389  and r12d, r9d
00007cc2f47d038c  rorx r8d, r9d, 0x16
00007cc2f47d0392  xor r10d, r8d
00007cc2f47d0395  mov [rsp+0x20], r10d
00007cc2f47d039a  mov r10d, r10d
00007cc2f47d039d  mov [r15+0xD0], r10
00007cc2f47d03a4  lea r10d, [edx+esi*1]
00007cc2f47d03a9  mov r9d, [rsp+0x10]
00007cc2f47d03ae  xor r12d, r9d
00007cc2f47d03b1  lea r9d, [r10d+r14d*1]
00007cc2f47d03b6  lea r14, [r11+0x04]
00007cc2f47d03ba  mov [r15+0x88], r14
00007cc2f47d03c1  mov r11d, [rsp+0x20]
00007cc2f47d03c6  lea r10d, [r12d+r11d*1]
00007cc2f47d03cb  lea r11d, [r9d+eax*1]
00007cc2f47d03d0  mov r11d, r11d
00007cc2f47d03d3  mov [r15+0xB8], r11
00007cc2f47d03da  xor eax, eax
00007cc2f47d03dc  mov r12d, 0x100
00007cc2f47d03e2  cmp r14, r12
00007cc2f47d03e5  cmc
00007cc2f47d03e6  lahf
00007cc2f47d03e7  seto al
00007cc2f47d03ea  mov [r15+0x108], eax
00007cc2f47d03f1  lea eax, [r10d+r9d*1]
00007cc2f47d03f6  mov eax, eax
00007cc2f47d03f8  mov [r15+0xA8], rax
00007cc2f47d03ff  mov ebp, ebp
00007cc2f47d0401  mov [r15+0xB0], rbp
00007cc2f47d0408  mov eax, [rsp+0x50]
00007cc2f47d040c  mov eax, eax
00007cc2f47d040e  mov [r15+0xC0], rax
00007cc2f47d0415  mov edi, edi
00007cc2f47d0417  mov [r15+0xC8], rdi
00007cc2f47d041e  mov eax, [r15+0x108]
00007cc2f47d0425  sahf
00007cc2f47d0426  jnz 0x00007CC2F47D0458
00007cc2f47d0428  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0430  jz 0x00007CC2F47D04A0
00007cc2f47d0436  nop [rax+rax*1], ax
00007cc2f47d043f  nop [rax+rax*1], eax
00007cc2f47d0447  mov eax, 0x41094C
00007cc2f47d044c  mov [r15+0x100], rax
00007cc2f47d0453  jmp 0x00007CC2F45FE110
00007cc2f47d0458  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0460  jz 0x00007CC2F47D0270
00007cc2f47d0466  nop [rax+rax*1], ax
00007cc2f47d046f  nop [rax+rax*1], eax
00007cc2f47d0477  mov eax, 0x4108C0
00007cc2f47d047c  mov [r15+0x100], rax
00007cc2f47d0483  jmp 0x00007CC2F45FE110
00007cc2f47d0488  int3
00007cc2f47d0489  call 0x00007CC2F4649010
00007cc2f47d048e  jmp 0x00007CC2F47D031F
00007cc2f47d0493  call 0x00007CC2F4625930
00007cc2f47d0498  jmp 0x00007CC2F47D035C
00007cc2f47d049d  int3
00007cc2f47d049e  nop
00007cc2f47d04a0  mov eax, [r15+0x98]
00007cc2f47d04a7  mov r14d, [r15+0x70]
00007cc2f47d04ab  lea r12d, [eax+r14d*1]
00007cc2f47d04b0  mov eax, [r15+0x28]
00007cc2f47d04b4  mov r14d, [r15+0x68]
00007cc2f47d04b8  lea r11d, [eax+r14d*1]
00007cc2f47d04bd  mov qword ptr [r15+0x88], 0x00
00007cc2f47d04c8  mov eax, [r15+0xA8]
00007cc2f47d04cf  mov r14d, [r15+0x78]
00007cc2f47d04d3  lea r10d, [eax+r14d*1]
00007cc2f47d04d8  mov [rsp+0x10], r10d
00007cc2f47d04dd  mov r10d, r10d
00007cc2f47d04e0  mov [r15+0x78], r10
00007cc2f47d04e4  mov eax, [r15+0x38]
00007cc2f47d04e8  mov r14d, [r15+0x80]
00007cc2f47d04ef  lea r10d, [eax+r14d*1]
00007cc2f47d04f4  mov [rsp+0x20], r10d
00007cc2f47d04f9  mov r10d, r10d
00007cc2f47d04fc  mov [r15+0x80], r10
00007cc2f47d0503  mov rax, [r15]
00007cc2f47d0506  lea r14, [rax+0x08]
00007cc2f47d050a  mov [r13+r14*1], r12d
00007cc2f47d050f  lea r14, [rax+0x0C]
00007cc2f47d0513  mov [r13+r14*1], r11d
00007cc2f47d0518  mov r14d, [r15+0xB8]
00007cc2f47d051f  mov r12d, [r15+0x18]
00007cc2f47d0523  lea r11d, [r14d+r12d*1]
00007cc2f47d0528  mov [rsp+0x30], r11d
00007cc2f47d052d  mov r11d, r11d
00007cc2f47d0530  mov [r15+0x68], r11
00007cc2f47d0534  mov r14d, [r15+0x30]
00007cc2f47d0538  mov r12d, [r15+0x90]
00007cc2f47d053f  lea r11d, [r14d+r12d*1]
00007cc2f47d0544  mov [rsp+0x40], r11d
00007cc2f47d0549  mov r11d, r11d
00007cc2f47d054c  mov [r15+0x70], r11
00007cc2f47d0550  mov r14d, [r15+0x20]
00007cc2f47d0554  mov r12d, [r15+0x58]
00007cc2f47d0558  lea r11d, [r14d+r12d*1]
00007cc2f47d055d  mov [rsp+0x50], r11d
00007cc2f47d0562  mov r11d, r11d
00007cc2f47d0565  mov [r15+0x58], r11
00007cc2f47d0569  mov r14d, [r15+0xA0]
00007cc2f47d0570  mov r12d, [r15+0x60]
00007cc2f47d0574  lea r11d, [r14d+r12d*1]
00007cc2f47d0579  mov [rsp+0x60], r11d
00007cc2f47d057e  mov r11d, r11d
00007cc2f47d0581  mov [r15+0x60], r11
00007cc2f47d0585  mov r14d, [rsp+0x10]
00007cc2f47d058a  mov [r13+rax*1], r14d
00007cc2f47d058f  lea r14, [rax+0x04]
00007cc2f47d0593  mov r12d, [rsp+0x20]
00007cc2f47d0598  mov [r13+r14*1], r12d
00007cc2f47d059d  lea r14, [rax+0x10]
00007cc2f47d05a1  mov r12d, [rsp+0x30]
00007cc2f47d05a6  mov [r13+r14*1], r12d
00007cc2f47d05ab  lea r14, [rax+0x14]
00007cc2f47d05af  mov r12d, [rsp+0x40]
00007cc2f47d05b4  mov [r13+r14*1], r12d
00007cc2f47d05b9  lea r14, [rax+0x18]
00007cc2f47d05bd  mov r12d, [rsp+0x50]
00007cc2f47d05c2  mov [r13+r14*1], r12d
00007cc2f47d05c7  lea r14, [rax+0x1C]
00007cc2f47d05cb  mov r12d, [rsp+0x60]
00007cc2f47d05d0  mov [r13+r14*1], r12d
00007cc2f47d05d5  lea r14, [rax+0x68]
00007cc2f47d05d9  xor eax, eax
00007cc2f47d05db  mov [r13+r14*1], rax
00007cc2f47d05e0  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d05e8  jz 0x00007CC2F47CF0E0
00007cc2f47d05ee  nop [rax+rax*1], ax
00007cc2f47d05f7  nop [rax+rax*1], eax
00007cc2f47d05ff  mov eax, 0x410768
00007cc2f47d0604  mov [r15+0x100], rax
00007cc2f47d060b  jmp 0x00007CC2F45FE110
00007cc2f47d0610  int3
00007cc2f47d0611  call 0x00007CC2F46E2BA0
00007cc2f47d0616  jmp 0x00007CC2F47D050F
00007cc2f47d061b  call 0x00007CC2F46E1920
00007cc2f47d0620  jmp 0x00007CC2F47D0518
00007cc2f47d0625  call 0x00007CC2F460DFE0
00007cc2f47d062a  jmp 0x00007CC2F47D058F
00007cc2f47d062f  call 0x00007CC2F46E2BA0
00007cc2f47d0634  jmp 0x00007CC2F47D059D
00007cc2f47d0639  call 0x00007CC2F46E2BA0
00007cc2f47d063e  jmp 0x00007CC2F47D05AB
00007cc2f47d0643  call 0x00007CC2F46E2BA0
00007cc2f47d0648  jmp 0x00007CC2F47D05B9
00007cc2f47d064d  call 0x00007CC2F46E2BA0
00007cc2f47d0652  jmp 0x00007CC2F47D05C7
00007cc2f47d0657  call 0x00007CC2F46E2BA0
00007cc2f47d065c  jmp 0x00007CC2F47D05D5
00007cc2f47d0661  call 0x00007CC2F46D5EB0
00007cc2f47d0666  jmp 0x00007CC2F47D05E0
00007cc2f47d066b  int3
00007cc2f47d066c  nop [rax], eax
00007cc2f47d0670  mov rax, [r15+0xF8]
00007cc2f47d0677  lea r14, [rax+0x140]
00007cc2f47d067e  mov r12, [r13+r14*1]
00007cc2f47d0683  lea r14, [rax+0x148]
00007cc2f47d068a  mov r11, [r13+r14*1]
00007cc2f47d068f  mov [r15+0xA0], r12
00007cc2f47d0696  mov [r15+0x98], r11
00007cc2f47d069d  lea r14, [rax+0x130]
00007cc2f47d06a4  mov r12, [r13+r14*1]
00007cc2f47d06a9  lea r14, [rax+0x138]
00007cc2f47d06b0  mov r11, [r13+r14*1]
00007cc2f47d06b5  mov [r15+0xB0], r12
00007cc2f47d06bc  mov [r15+0xA8], r11
00007cc2f47d06c3  lea r14, [rax+0x120]
00007cc2f47d06ca  mov r12, [r13+r14*1]
00007cc2f47d06cf  lea r14, [rax+0x128]
00007cc2f47d06d6  mov r11, [r13+r14*1]
00007cc2f47d06db  mov [r15+0xC0], r12
00007cc2f47d06e2  mov [r15+0xB8], r11
00007cc2f47d06e9  lea r14, [rax+0x110]
00007cc2f47d06f0  mov r12, [r13+r14*1]
00007cc2f47d06f5  lea r14, [rax+0x118]
00007cc2f47d06fc  mov r11, [r13+r14*1]
00007cc2f47d0701  mov [r15+0xD0], r12
00007cc2f47d0708  mov [r15+0xC8], r11
00007cc2f47d070f  lea r14, [rax+0x100]
00007cc2f47d0716  mov r12, [r13+r14*1]
00007cc2f47d071b  lea r14, [rax+0x108]
00007cc2f47d0722  mov r11, [r13+r14*1]
00007cc2f47d0727  mov [r15+0xE8], r12
00007cc2f47d072e  mov [r15+0xD8], r11
00007cc2f47d0735  lea r14, [rax+0x150]
00007cc2f47d073c  mov [r15+0xF8], r14
00007cc2f47d0743  mov rax, [r15+0xF0]
00007cc2f47d074a  mov [r15+0x100], rax
00007cc2f47d0751  jmp 0x00007CC2F47CE5C0
00007cc2f47d0756  int3
00007cc2f47d0757  call 0x00007CC2F46E27E0
00007cc2f47d075c  jmp 0x00007CC2F47D0683
00007cc2f47d0761  call 0x00007CC2F46E1570
00007cc2f47d0766  jmp 0x00007CC2F47D068F
00007cc2f47d076b  call 0x00007CC2F46E27E0
00007cc2f47d0770  jmp 0x00007CC2F47D06A9
00007cc2f47d0775  call 0x00007CC2F46E1570
00007cc2f47d077a  jmp 0x00007CC2F47D06B5
00007cc2f47d077f  call 0x00007CC2F46E27E0
00007cc2f47d0784  jmp 0x00007CC2F47D06CF
00007cc2f47d0789  call 0x00007CC2F46E1570
00007cc2f47d078e  jmp 0x00007CC2F47D06DB
00007cc2f47d0793  call 0x00007CC2F46E27E0
00007cc2f47d0798  jmp 0x00007CC2F47D06F5
00007cc2f47d079d  call 0x00007CC2F46E1570
00007cc2f47d07a2  jmp 0x00007CC2F47D0701
00007cc2f47d07a7  call 0x00007CC2F46E27E0
00007cc2f47d07ac  jmp 0x00007CC2F47D071B
00007cc2f47d07b1  call 0x00007CC2F46E1570
00007cc2f47d07b6  jmp 0x00007CC2F47D0727
00007cc2f47d07bb  int3
00007cc2f47d07bc  nop [rax], eax
00007cc2f47d07c0  mov eax, [r15+0xA0]
00007cc2f47d07c7  mov [rsp+0x10], eax
00007cc2f47d07cb  xor eax, eax
00007cc2f47d07cd  mov r14d, [rsp+0x10]
00007cc2f47d07d2  sub r14d, 0x01
00007cc2f47d07d6  cmc
00007cc2f47d07d7  lahf
00007cc2f47d07d8  seto al
00007cc2f47d07db  mov [r15+0x108], eax
00007cc2f47d07e2  mov r14d, r14d
00007cc2f47d07e5  mov [r15+0xA0], r14
00007cc2f47d07ec  mov eax, [r15+0x108]
00007cc2f47d07f3  sahf
00007cc2f47d07f4  jnz 0x00007CC2F47D0826
00007cc2f47d07f6  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d07fe  jz 0x00007CC2F47D0900
00007cc2f47d0804  nop [rax+rax*1], ax
00007cc2f47d080d  nop [rax+rax*1], eax
00007cc2f47d0815  mov eax, 0x41028C
00007cc2f47d081a  mov [r15+0x100], rax
00007cc2f47d0821  jmp 0x00007CC2F45FE110
00007cc2f47d0826  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d082e  jz 0x00007CC2F47D0860
00007cc2f47d0834  nop [rax+rax*1], ax
00007cc2f47d083d  nop [rax+rax*1], eax
00007cc2f47d0845  mov eax, 0x410274
00007cc2f47d084a  mov [r15+0x100], rax
00007cc2f47d0851  jmp 0x00007CC2F45FE110
00007cc2f47d0856  int3
00007cc2f47d0857  int3
00007cc2f47d0858  nop [rax+rax*1], eax
00007cc2f47d0860  mov rax, [r15+0xF8]
00007cc2f47d0867  lea r14, [rax+0x100]
00007cc2f47d086e  mov [r15], r14
00007cc2f47d0871  mov rax, [r15+0x98]
00007cc2f47d0878  mov [r15+0x08], rax
00007cc2f47d087c  mov qword ptr [r15+0x10], 0x12C
00007cc2f47d0884  mov qword ptr [r15+0xF0], 0x410284
00007cc2f47d088f  mov r14d, [r15+0x320]
00007cc2f47d0896  mov eax, 0x410284
00007cc2f47d089b  mov rcx, 0x7CC2F47D07C0
00007cc2f47d08a5  mov [r15+r14*8+0x328], rax
00007cc2f47d08ad  mov [r15+r14*8+0x368], rcx
00007cc2f47d08b5  add r14d, 0x01
00007cc2f47d08b9  and r14d, 0x07
00007cc2f47d08bd  mov [r15+0x320], r14d
00007cc2f47d08c4  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d08cc  jz 0x00007CC2F47CED70
00007cc2f47d08d2  nop [rax+rax*1], ax
00007cc2f47d08db  nop [rax+rax*1], eax
00007cc2f47d08e3  mov eax, 0x410728
00007cc2f47d08e8  mov [r15+0x100], rax
00007cc2f47d08ef  jmp 0x00007CC2F45FE110
00007cc2f47d08f4  int3
00007cc2f47d08f5  int3
00007cc2f47d08f6  nop [rax+rax*1], ax
00007cc2f47d08ff  nop
00007cc2f47d0900  mov rax, [r15+0xF8]
00007cc2f47d0907  lea r14, [rax+0x120]
00007cc2f47d090e  mov r12, [r13+r14*1]
00007cc2f47d0913  mov [r15+0x98], r12
00007cc2f47d091a  mov qword ptr [r15+0x40], 0x80
00007cc2f47d0922  lea r14, [rax+0x100]
00007cc2f47d0929  mov [r15], r14
00007cc2f47d092c  lea r14, [rax+0x17C]
00007cc2f47d0933  mov [r15+0x08], r14
00007cc2f47d0937  mov qword ptr [r15+0x10], 0x01
00007cc2f47d093f  lea r14, [rax+0x17C]
00007cc2f47d0946  mov eax, 0x80
00007cc2f47d094b  mov [r13+r14*1], al
00007cc2f47d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007cc2f47d095b  mov r14d, [r15+0x320]
00007cc2f47d0962  mov eax, 0x4102A8
00007cc2f47d0967  mov rcx, 0x7CC2F47D09E0
00007cc2f47d0971  mov [r15+r14*8+0x328], rax
00007cc2f47d0979  mov [r15+r14*8+0x368], rcx
00007cc2f47d0981  add r14d, 0x01
00007cc2f47d0985  and r14d, 0x07
00007cc2f47d0989  mov [r15+0x320], r14d
00007cc2f47d0990  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0998  jz 0x00007CC2F47CED70
00007cc2f47d099e  nop [rax+rax*1], ax
00007cc2f47d09a7  nop [rax+rax*1], eax
00007cc2f47d09af  mov eax, 0x410728
00007cc2f47d09b4  mov [r15+0x100], rax
00007cc2f47d09bb  jmp 0x00007CC2F45FE110
00007cc2f47d09c0  int3
00007cc2f47d09c1  call 0x00007CC2F46E27E0
00007cc2f47d09c6  jmp 0x00007CC2F47D0913
00007cc2f47d09cb  call 0x00007CC2F46D5AF0
00007cc2f47d09d0  jmp 0x00007CC2F47D0950
00007cc2f47d09d5  int3
00007cc2f47d09d6  nop [rax+rax*1], ax
00007cc2f47d09df  nop
00007cc2f47d09e0  mov rax, [r15+0xF8]
00007cc2f47d09e7  lea r14, [rax+0x168]
00007cc2f47d09ee  mov r12, [r13+r14*1]
00007cc2f47d09f3  mov [r15+0x40], r12
00007cc2f47d09f7  lea r14, [rax+0x178]
00007cc2f47d09fe  xor eax, eax
00007cc2f47d0a00  mov [r13+r14*1], al
00007cc2f47d0a05  xor eax, eax
00007cc2f47d0a07  mov r14d, 0x38
00007cc2f47d0a0d  cmp r12, r14
00007cc2f47d0a10  cmc
00007cc2f47d0a11  lahf
00007cc2f47d0a12  seto al
00007cc2f47d0a15  mov [r15+0x108], eax
00007cc2f47d0a1c  mov eax, [r15+0x108]
00007cc2f47d0a23  sahf
00007cc2f47d0a24  jz 0x00007CC2F47D0A56
00007cc2f47d0a26  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0a2e  jz 0x00007CC2F47D0AA0
00007cc2f47d0a34  nop [rax+rax*1], ax
00007cc2f47d0a3d  nop [rax+rax*1], eax
00007cc2f47d0a45  mov eax, 0x4102B8
00007cc2f47d0a4a  mov [r15+0x100], rax
00007cc2f47d0a51  jmp 0x00007CC2F45FE110
00007cc2f47d0a56  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0a5e  jz 0x00007CC2F47D0BF0
00007cc2f47d0a64  nop [rax+rax*1], ax
00007cc2f47d0a6d  nop [rax+rax*1], eax
00007cc2f47d0a75  mov eax, 0x4102D4
00007cc2f47d0a7a  mov [r15+0x100], rax
00007cc2f47d0a81  jmp 0x00007CC2F45FE110
00007cc2f47d0a86  int3
00007cc2f47d0a87  call 0x00007CC2F46E27E0
00007cc2f47d0a8c  jmp 0x00007CC2F47D09F3
00007cc2f47d0a91  call 0x00007CC2F46D5AF0
00007cc2f47d0a96  jmp 0x00007CC2F47D0A05
00007cc2f47d0a9b  int3
00007cc2f47d0a9c  nop [rax], eax
00007cc2f47d0aa0  mov rax, [r15+0xF8]
00007cc2f47d0aa7  lea r14, [rax+0x100]
00007cc2f47d0aae  mov [r15], r14
00007cc2f47d0ab1  lea r14, [rax+0x178]
00007cc2f47d0ab8  mov [r15+0x08], r14
00007cc2f47d0abc  mov qword ptr [r15+0x10], 0x01
00007cc2f47d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007cc2f47d0acf  mov r14d, [r15+0x320]
00007cc2f47d0ad6  mov eax, 0x4102C8
00007cc2f47d0adb  mov rcx, 0x7CC2F47D0B40
00007cc2f47d0ae5  mov [r15+r14*8+0x328], rax
00007cc2f47d0aed  mov [r15+r14*8+0x368], rcx
00007cc2f47d0af5  add r14d, 0x01
00007cc2f47d0af9  and r14d, 0x07
00007cc2f47d0afd  mov [r15+0x320], r14d
00007cc2f47d0b04  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0b0c  jz 0x00007CC2F47CED70
00007cc2f47d0b12  nop [rax+rax*1], ax
00007cc2f47d0b1b  nop [rax+rax*1], eax
00007cc2f47d0b23  mov eax, 0x410728
00007cc2f47d0b28  mov [r15+0x100], rax
00007cc2f47d0b2f  jmp 0x00007CC2F45FE110
00007cc2f47d0b34  int3
00007cc2f47d0b35  int3
00007cc2f47d0b36  nop [rax+rax*1], ax
00007cc2f47d0b3f  nop
00007cc2f47d0b40  mov rax, [r15+0xF8]
00007cc2f47d0b47  lea r14, [rax+0x168]
00007cc2f47d0b4e  mov rax, [r13+r14*1]
00007cc2f47d0b53  mov [r15+0x40], rax
00007cc2f47d0b57  mov [rsp+0x10], rax
00007cc2f47d0b5c  xor eax, eax
00007cc2f47d0b5e  mov r14, [rsp+0x10]
00007cc2f47d0b63  mov r12d, 0x38
00007cc2f47d0b69  cmp r14, r12
00007cc2f47d0b6c  cmc
00007cc2f47d0b6d  lahf
00007cc2f47d0b6e  seto al
00007cc2f47d0b71  mov [r15+0x108], eax
00007cc2f47d0b78  mov eax, [r15+0x108]
00007cc2f47d0b7f  sahf
00007cc2f47d0b80  jnz 0x00007CC2F47D0BB2
00007cc2f47d0b82  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0b8a  jz 0x00007CC2F47D0BF0
00007cc2f47d0b90  nop [rax+rax*1], ax
00007cc2f47d0b99  nop [rax+rax*1], eax
00007cc2f47d0ba1  mov eax, 0x4102D4
00007cc2f47d0ba6  mov [r15+0x100], rax
00007cc2f47d0bad  jmp 0x00007CC2F45FE110
00007cc2f47d0bb2  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0bba  jz 0x00007CC2F47D0AA0
00007cc2f47d0bc0  nop [rax+rax*1], ax
00007cc2f47d0bc9  nop [rax+rax*1], eax
00007cc2f47d0bd1  mov eax, 0x4102B8
00007cc2f47d0bd6  mov [r15+0x100], rax
00007cc2f47d0bdd  jmp 0x00007CC2F45FE110
00007cc2f47d0be2  int3
00007cc2f47d0be3  call 0x00007CC2F46D59C0
00007cc2f47d0be8  jmp 0x00007CC2F47D0B53
00007cc2f47d0bed  int3
00007cc2f47d0bee  nop
00007cc2f47d0bf0  mov rax, [r15+0x98]
00007cc2f47d0bf7  rorx r14, rax, 0x3D
00007cc2f47d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007cc2f47d0c01  mov rax, [r15+0xF8]
00007cc2f47d0c08  lea r12, [rax+0x100]
00007cc2f47d0c0f  mov [r15], r12
00007cc2f47d0c12  lea r12, [rax+0x170]
00007cc2f47d0c19  mov [r15+0x08], r12
00007cc2f47d0c1d  mov qword ptr [r15+0x10], 0x08
00007cc2f47d0c25  bswap r14
00007cc2f47d0c28  mov [r15+0x40], r14
00007cc2f47d0c2c  lea r12, [rax+0x170]
00007cc2f47d0c33  mov [r13+r12*1], r14
00007cc2f47d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007cc2f47d0c43  mov r14d, [r15+0x320]
00007cc2f47d0c4a  mov eax, 0x4102F0
00007cc2f47d0c4f  mov rcx, 0x7CC2F47D0CC0
00007cc2f47d0c59  mov [r15+r14*8+0x328], rax
00007cc2f47d0c61  mov [r15+r14*8+0x368], rcx
00007cc2f47d0c69  add r14d, 0x01
00007cc2f47d0c6d  and r14d, 0x07
00007cc2f47d0c71  mov [r15+0x320], r14d
00007cc2f47d0c78  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0c80  jz 0x00007CC2F47CED70
00007cc2f47d0c86  nop [rax+rax*1], ax
00007cc2f47d0c8f  nop [rax+rax*1], eax
00007cc2f47d0c97  mov eax, 0x410728
00007cc2f47d0c9c  mov [r15+0x100], rax
00007cc2f47d0ca3  jmp 0x00007CC2F45FE110
00007cc2f47d0ca8  int3
00007cc2f47d0ca9  call 0x00007CC2F46C3FE0
00007cc2f47d0cae  jmp 0x00007CC2F47D0C38
00007cc2f47d0cb3  int3
00007cc2f47d0cb4  nop [rax+rax*1], ax
00007cc2f47d0cbd  nop [rax], eax
00007cc2f47d0cc0  mov rax, [r15+0xF8]
00007cc2f47d0cc7  lea r14, [rax+0x100]
00007cc2f47d0cce  mov r12d, [r13+r14*1]
00007cc2f47d0cd3  lea r14, [rax+0x104]
00007cc2f47d0cda  mov r11d, [r13+r14*1]
00007cc2f47d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007cc2f47d0ce7  lea r14, [rax+0x108]
00007cc2f47d0cee  mov r10d, [r13+r14*1]
00007cc2f47d0cf3  lea r14, [rax+0x10C]
00007cc2f47d0cfa  mov r9d, [r13+r14*1]
00007cc2f47d0cff  bswap r12d
00007cc2f47d0d02  bswap r11d
00007cc2f47d0d05  mov qword ptr [r15+0xA0], 0x00
00007cc2f47d0d10  mov r14d, 0x430C90
00007cc2f47d0d16  mov [r13+r14*1], r12d
00007cc2f47d0d1b  mov r14d, 0x430C94
00007cc2f47d0d21  mov [r13+r14*1], r11d
00007cc2f47d0d26  bswap r10d
00007cc2f47d0d29  lea r14, [rax+0x110]
00007cc2f47d0d30  mov r12d, [r13+r14*1]
00007cc2f47d0d35  bswap r9d
00007cc2f47d0d38  lea r14, [rax+0x114]
00007cc2f47d0d3f  mov r11d, [r13+r14*1]
00007cc2f47d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007cc2f47d0d4f  mov r14d, 0x430C98
00007cc2f47d0d55  mov [r13+r14*1], r10d
00007cc2f47d0d5a  mov r14d, 0x430C9C
00007cc2f47d0d60  mov [r13+r14*1], r9d
00007cc2f47d0d65  bswap r12d
00007cc2f47d0d68  lea r14, [rax+0x118]
00007cc2f47d0d6f  mov r10d, [r13+r14*1]
00007cc2f47d0d74  bswap r11d
00007cc2f47d0d77  mov [rsp+0x10], r11d
00007cc2f47d0d7c  mov r11d, r11d
00007cc2f47d0d7f  mov [r15+0x58], r11
00007cc2f47d0d83  lea r14, [rax+0x11C]
00007cc2f47d0d8a  mov eax, [r13+r14*1]
00007cc2f47d0d8f  mov [rsp+0x20], eax
00007cc2f47d0d93  mov eax, eax
00007cc2f47d0d95  mov [r15+0x60], rax
00007cc2f47d0d99  mov eax, 0x430CA0
00007cc2f47d0d9e  mov [r13+rax*1], r12d
00007cc2f47d0da3  mov eax, 0x430CA4
00007cc2f47d0da8  mov r14d, [rsp+0x10]
00007cc2f47d0dad  mov [r13+rax*1], r14d
00007cc2f47d0db2  bswap r10d
00007cc2f47d0db5  mov [rsp+0x10], r10d
00007cc2f47d0dba  mov r10d, r10d
00007cc2f47d0dbd  mov [r15+0x40], r10
00007cc2f47d0dc1  mov eax, [rsp+0x20]
00007cc2f47d0dc5  bswap eax
00007cc2f47d0dc7  mov [rsp+0x20], eax
00007cc2f47d0dcb  mov eax, eax
00007cc2f47d0dcd  mov [r15+0x50], rax
00007cc2f47d0dd1  mov eax, 0x430CA8
00007cc2f47d0dd6  mov r14d, [rsp+0x10]
00007cc2f47d0ddb  mov [r13+rax*1], r14d
00007cc2f47d0de0  mov eax, 0x430CAC
00007cc2f47d0de5  mov r14d, [rsp+0x20]
00007cc2f47d0dea  mov [r13+rax*1], r14d
00007cc2f47d0def  mov eax, [r15+0xA0]
00007cc2f47d0df6  lea r14d, [eax+0x11]
00007cc2f47d0dfb  mov r14d, r14d
00007cc2f47d0dfe  mov [r15], r14
00007cc2f47d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007cc2f47d0e0c  mov r14d, [r15+0x320]
00007cc2f47d0e13  mov eax, 0x41035C
00007cc2f47d0e18  mov rcx, 0x7CC2F47D0F90
00007cc2f47d0e22  mov [r15+r14*8+0x328], rax
00007cc2f47d0e2a  mov [r15+r14*8+0x368], rcx
00007cc2f47d0e32  add r14d, 0x01
00007cc2f47d0e36  and r14d, 0x07
00007cc2f47d0e3a  mov [r15+0x320], r14d
00007cc2f47d0e41  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0e49  jz 0x00007CC2F47D0F20
00007cc2f47d0e4f  nop [rax+rax*1], ax
00007cc2f47d0e58  nop [rax+rax*1], eax
00007cc2f47d0e60  mov eax, 0x4109A4
00007cc2f47d0e65  mov [r15+0x100], rax
00007cc2f47d0e6c  jmp 0x00007CC2F45FE110
00007cc2f47d0e71  int3
00007cc2f47d0e72  call 0x00007CC2F46E26A0
00007cc2f47d0e77  jmp 0x00007CC2F47D0CD3
00007cc2f47d0e7c  call 0x00007CC2F46E1430
00007cc2f47d0e81  jmp 0x00007CC2F47D0CDF
00007cc2f47d0e86  call 0x00007CC2F46E01C0
00007cc2f47d0e8b  jmp 0x00007CC2F47D0CF3
00007cc2f47d0e90  call 0x00007CC2F46DEF50
00007cc2f47d0e95  jmp 0x00007CC2F47D0CFF
00007cc2f47d0e9a  call 0x00007CC2F46E2BA0
00007cc2f47d0e9f  jmp 0x00007CC2F47D0D1B
00007cc2f47d0ea4  call 0x00007CC2F46E1920
00007cc2f47d0ea9  jmp 0x00007CC2F47D0D26
00007cc2f47d0eae  call 0x00007CC2F46E26A0
00007cc2f47d0eb3  jmp 0x00007CC2F47D0D35
00007cc2f47d0eb8  call 0x00007CC2F46E1430
00007cc2f47d0ebd  jmp 0x00007CC2F47D0D44
00007cc2f47d0ec2  call 0x00007CC2F46E06B0
00007cc2f47d0ec7  jmp 0x00007CC2F47D0D5A
00007cc2f47d0ecc  call 0x00007CC2F46DF440
00007cc2f47d0ed1  jmp 0x00007CC2F47D0D65
00007cc2f47d0ed6  call 0x00007CC2F46E01C0
00007cc2f47d0edb  jmp 0x00007CC2F47D0D74
00007cc2f47d0ee0  call 0x00007CC2F46D5890
00007cc2f47d0ee5  jmp 0x00007CC2F47D0D8F
00007cc2f47d0eea  call 0x00007CC2F460BAE0
00007cc2f47d0eef  jmp 0x00007CC2F47D0DA3
00007cc2f47d0ef4  call 0x00007CC2F460DFE0
00007cc2f47d0ef9  jmp 0x00007CC2F47D0DB2
00007cc2f47d0efe  call 0x00007CC2F460DFE0
00007cc2f47d0f03  jmp 0x00007CC2F47D0DE0
00007cc2f47d0f08  call 0x00007CC2F460DFE0
00007cc2f47d0f0d  jmp 0x00007CC2F47D0DEF
00007cc2f47d0f12  int3
00007cc2f47d0f13  nop [rax+rax*1], ax
00007cc2f47d0f1c  nop [rax], eax
00007cc2f47d0f20  mov eax, [r15]
00007cc2f47d0f23  mov [rsp+0x10], eax
00007cc2f47d0f27  shr eax, 0x10
00007cc2f47d0f2a  mov r14d, [rsp+0x10]
00007cc2f47d0f2f  xor r14d, eax
00007cc2f47d0f32  imul r14d, r14d, 0x7FEB352D
00007cc2f47d0f39  mov eax, 0x846CA68B
00007cc2f47d0f3e  mov eax, eax
00007cc2f47d0f40  mov [r15+0x48], rax
00007cc2f47d0f44  mov [rsp+0x10], r14d
00007cc2f47d0f49  shr r14d, 0x0F
00007cc2f47d0f4d  mov eax, [rsp+0x10]
00007cc2f47d0f51  xor eax, r14d
00007cc2f47d0f54  imul eax, eax, 0x846CA68B
00007cc2f47d0f5a  mov [rsp+0x10], eax
00007cc2f47d0f5e  mov eax, eax
00007cc2f47d0f60  mov [r15+0x40], rax
00007cc2f47d0f64  mov eax, [rsp+0x10]
00007cc2f47d0f68  shr eax, 0x10
00007cc2f47d0f6b  mov r14d, [rsp+0x10]
00007cc2f47d0f70  xor r14d, eax
00007cc2f47d0f73  mov r14d, r14d
00007cc2f47d0f76  mov [r15], r14
00007cc2f47d0f79  mov rax, [r15+0xF0]
00007cc2f47d0f80  mov [r15+0x100], rax
00007cc2f47d0f87  jmp 0x00007CC2F47CE5C0
00007cc2f47d0f8c  int3
00007cc2f47d0f8d  int3
00007cc2f47d0f8e  nop
00007cc2f47d0f90  mov rax, [r15+0xA0]
00007cc2f47d0f97  mov [rsp+0x10], rax
00007cc2f47d0f9c  shl rax, 0x02
00007cc2f47d0fa0  mov r14, [r15+0x98]
00007cc2f47d0fa7  lea r12, [r14+rax*1]
00007cc2f47d0fab  mov eax, [r15]
00007cc2f47d0fae  mov [r13+r12*1], eax
00007cc2f47d0fb3  mov rax, [rsp+0x10]
00007cc2f47d0fb8  lea r14, [rax+0x01]
00007cc2f47d0fbc  mov [r15+0xA0], r14
00007cc2f47d0fc3  xor eax, eax
00007cc2f47d0fc5  mov r12d, 0x400
00007cc2f47d0fcb  cmp r14, r12
00007cc2f47d0fce  cmc
00007cc2f47d0fcf  lahf
00007cc2f47d0fd0  seto al
00007cc2f47d0fd3  mov [r15+0x108], eax
00007cc2f47d0fda  mov eax, [r15+0x108]
00007cc2f47d0fe1  sahf
00007cc2f47d0fe2  jnz 0x00007CC2F47D1014
00007cc2f47d0fe4  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d0fec  jz 0x00007CC2F47D10E0
00007cc2f47d0ff2  nop [rax+rax*1], ax
00007cc2f47d0ffb  nop [rax+rax*1], eax
00007cc2f47d1003  mov eax, 0x41036C
00007cc2f47d1008  mov [r15+0x100], rax
00007cc2f47d100f  jmp 0x00007CC2F45FE110
00007cc2f47d1014  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d101c  jz 0x00007CC2F47D1050
00007cc2f47d1022  nop [rax+rax*1], ax
00007cc2f47d102b  nop [rax+rax*1], eax
00007cc2f47d1033  mov eax, 0x410354
00007cc2f47d1038  mov [r15+0x100], rax
00007cc2f47d103f  jmp 0x00007CC2F45FE110
00007cc2f47d1044  int3
00007cc2f47d1045  call 0x00007CC2F46B4B70
00007cc2f47d104a  jmp 0x00007CC2F47D0FB3
00007cc2f47d104f  int3
00007cc2f47d1050  mov eax, [r15+0xA0]
00007cc2f47d1057  lea r14d, [eax+0x11]
00007cc2f47d105c  mov r14d, r14d
00007cc2f47d105f  mov [r15], r14
00007cc2f47d1062  mov qword ptr [r15+0xF0], 0x41035C
00007cc2f47d106d  mov r14d, [r15+0x320]
00007cc2f47d1074  mov eax, 0x41035C
00007cc2f47d1079  mov rcx, 0x7CC2F47D0F90
00007cc2f47d1083  mov [r15+r14*8+0x328], rax
00007cc2f47d108b  mov [r15+r14*8+0x368], rcx
00007cc2f47d1093  add r14d, 0x01
00007cc2f47d1097  and r14d, 0x07
00007cc2f47d109b  mov [r15+0x320], r14d
00007cc2f47d10a2  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d10aa  jz 0x00007CC2F47D0F20
00007cc2f47d10b0  nop [rax+rax*1], ax
00007cc2f47d10b9  nop [rax+rax*1], eax
00007cc2f47d10c1  mov eax, 0x4109A4
00007cc2f47d10c6  mov [r15+0x100], rax
00007cc2f47d10cd  jmp 0x00007CC2F45FE110
00007cc2f47d10d2  int3
00007cc2f47d10d3  int3
00007cc2f47d10d4  nop [rax+rax*1], ax
00007cc2f47d10dd  nop [rax], eax
00007cc2f47d10e0  mov qword ptr [r15+0x40], 0x01
00007cc2f47d10e8  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d10f0  jz 0x00007CC2F47D1120
00007cc2f47d10f6  nop [rax+rax*1], ax
00007cc2f47d10ff  nop [rax+rax*1], eax
00007cc2f47d1107  mov eax, 0x410388
00007cc2f47d110c  mov [r15+0x100], rax
00007cc2f47d1113  jmp 0x00007CC2F45FE110
00007cc2f47d1118  int3
00007cc2f47d1119  int3
00007cc2f47d111a  nop [rax+rax*1], ax
00007cc2f47d1120  mov rax, [r15+0x40]
00007cc2f47d1124  mov [rsp+0x10], rax
00007cc2f47d1129  shl rax, 0x02
00007cc2f47d112d  mov r14, [r15+0x98]
00007cc2f47d1134  lea r12, [r14+rax*1]
00007cc2f47d1138  mov eax, [r13+r12*1]
00007cc2f47d113d  mov [rsp+0x20], eax
00007cc2f47d1141  mov eax, eax
00007cc2f47d1143  mov [r15+0x48], rax
00007cc2f47d1147  mov rax, [rsp+0x10]
00007cc2f47d114c  mov [r15+0x50], rax
00007cc2f47d1150  mov eax, [r15+0x50]
00007cc2f47d1154  lea r12d, [eax-0x01]
00007cc2f47d1159  mov r12d, r12d
00007cc2f47d115c  mov [r15+0x58], r12
00007cc2f47d1160  mov rax, [r15+0x58]
00007cc2f47d1164  mov r12d, eax
00007cc2f47d1167  mov r12d, r12d
00007cc2f47d116a  shl r12, 0x02
00007cc2f47d116e  lea rax, [r14+r12*1]
00007cc2f47d1172  mov r14d, [r13+rax*1]
00007cc2f47d1177  mov [rsp+0x10], r14d
00007cc2f47d117c  mov r14d, r14d
00007cc2f47d117f  mov [r15+0x60], r14
00007cc2f47d1183  xor eax, eax
00007cc2f47d1185  mov r14d, [rsp+0x10]
00007cc2f47d118a  mov r12d, [rsp+0x20]
00007cc2f47d118f  cmp r14d, r12d
00007cc2f47d1192  cmc
00007cc2f47d1193  lahf
00007cc2f47d1194  seto al
00007cc2f47d1197  mov [r15+0x108], eax
00007cc2f47d119e  mov eax, [r15+0x108]
00007cc2f47d11a5  sahf
00007cc2f47d11a6  cmc
00007cc2f47d11a7  jbe 0x00007CC2F47D11D9
00007cc2f47d11a9  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d11b1  jz 0x00007CC2F47D1220
00007cc2f47d11b7  nop [rax+rax*1], ax
00007cc2f47d11c0  nop [rax+rax*1], eax
00007cc2f47d11c8  mov eax, 0x4103A0
00007cc2f47d11cd  mov [r15+0x100], rax
00007cc2f47d11d4  jmp 0x00007CC2F45FE110
00007cc2f47d11d9  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d11e1  jz 0x00007CC2F47D14C0
00007cc2f47d11e7  nop [rax+rax*1], ax
00007cc2f47d11f0  nop [rax+rax*1], eax
00007cc2f47d11f8  mov eax, 0x410378
00007cc2f47d11fd  mov [r15+0x100], rax
00007cc2f47d1204  jmp 0x00007CC2F45FE110
00007cc2f47d1209  int3
00007cc2f47d120a  call 0x00007CC2F46B4690
00007cc2f47d120f  jmp 0x00007CC2F47D113D
00007cc2f47d1214  call 0x00007CC2F460DAE0
00007cc2f47d1219  jmp 0x00007CC2F47D1177
00007cc2f47d121e  int3
00007cc2f47d121f  nop
00007cc2f47d1220  mov rax, [r15+0x50]
00007cc2f47d1224  mov [rsp+0x10], rax
00007cc2f47d1229  shl rax, 0x02
00007cc2f47d122d  mov r14, [r15+0x98]
00007cc2f47d1234  lea r12, [r14+rax*1]
00007cc2f47d1238  mov eax, [r15+0x60]
00007cc2f47d123c  mov [r13+r12*1], eax
00007cc2f47d1241  mov rax, [rsp+0x10]
00007cc2f47d1246  lea r14, [rax-0x01]
00007cc2f47d124a  mov [r15+0x50], r14
00007cc2f47d124e  mov rax, [r15+0x58]
00007cc2f47d1252  test rax, rax
00007cc2f47d1255  setz al
00007cc2f47d1258  movzx rax, al
00007cc2f47d125c  mov [rsp+0x414], al
00007cc2f47d1263  cmp byte ptr [rsp+0x414], 0x00
00007cc2f47d126b  jz 0x00007CC2F47D129D
00007cc2f47d126d  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d1275  jz 0x00007CC2F47D12E0
00007cc2f47d127b  nop [rax+rax*1], ax
00007cc2f47d1284  nop [rax+rax*1], eax
00007cc2f47d128c  mov eax, 0x4103AC
00007cc2f47d1291  mov [r15+0x100], rax
00007cc2f47d1298  jmp 0x00007CC2F45FE110
00007cc2f47d129d  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d12a5  jz 0x00007CC2F47D13E0
00007cc2f47d12ab  nop [rax+rax*1], ax
00007cc2f47d12b4  nop [rax+rax*1], eax
00007cc2f47d12bc  mov eax, 0x410390
00007cc2f47d12c1  mov [r15+0x100], rax
00007cc2f47d12c8  jmp 0x00007CC2F45FE110
00007cc2f47d12cd  int3
00007cc2f47d12ce  call 0x00007CC2F46B4B70
00007cc2f47d12d3  jmp 0x00007CC2F47D1241
00007cc2f47d12d8  int3
00007cc2f47d12d9  nop [rax], eax
00007cc2f47d12e0  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d12e8  jz 0x00007CC2F47D1320
00007cc2f47d12ee  nop [rax+rax*1], ax
00007cc2f47d12f7  nop [rax+rax*1], eax
00007cc2f47d12ff  mov eax, 0x410374
00007cc2f47d1304  mov [r15+0x100], rax
00007cc2f47d130b  jmp 0x00007CC2F45FE110
00007cc2f47d1310  int3
00007cc2f47d1311  int3
00007cc2f47d1312  nop [rax+rax*1], ax
00007cc2f47d131b  nop [rax+rax*1], eax
00007cc2f47d1320  mov qword ptr [r15+0x50], 0x00
00007cc2f47d1328  mov rax, [r15+0x40]
00007cc2f47d132c  lea r14, [rax+0x01]
00007cc2f47d1330  mov [r15+0x40], r14
00007cc2f47d1334  mov rax, [r15+0x98]
00007cc2f47d133b  mov r12d, [r15+0x48]
00007cc2f47d133f  mov [r13+rax*1], r12d
00007cc2f47d1344  xor eax, eax
00007cc2f47d1346  mov r12d, 0x400
00007cc2f47d134c  cmp r14, r12
00007cc2f47d134f  cmc
00007cc2f47d1350  lahf
00007cc2f47d1351  seto al
00007cc2f47d1354  mov [r15+0x108], eax
00007cc2f47d135b  mov eax, [r15+0x108]
00007cc2f47d1362  sahf
00007cc2f47d1363  jz 0x00007CC2F47D1395
00007cc2f47d1365  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d136d  jz 0x00007CC2F47D1120
00007cc2f47d1373  nop [rax+rax*1], ax
00007cc2f47d137c  nop [rax+rax*1], eax
00007cc2f47d1384  mov eax, 0x410388
00007cc2f47d1389  mov [r15+0x100], rax
00007cc2f47d1390  jmp 0x00007CC2F45FE110
00007cc2f47d1395  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d139d  jz 0x00007CC2F47D1580
00007cc2f47d13a3  nop [rax+rax*1], ax
00007cc2f47d13ac  nop [rax+rax*1], eax
00007cc2f47d13b4  mov eax, 0x4103B0
00007cc2f47d13b9  mov [r15+0x100], rax
00007cc2f47d13c0  jmp 0x00007CC2F45FE110
00007cc2f47d13c5  int3
00007cc2f47d13c6  call 0x00007CC2F460BAE0
00007cc2f47d13cb  jmp 0x00007CC2F47D1344
00007cc2f47d13d0  int3
00007cc2f47d13d1  nop [rax+rax*1], ax
00007cc2f47d13da  nop [rax+rax*1], ax
00007cc2f47d13e0  mov eax, [r15+0x50]
00007cc2f47d13e4  lea r14d, [eax-0x01]
00007cc2f47d13e9  mov r14d, r14d
00007cc2f47d13ec  mov [r15+0x58], r14
00007cc2f47d13f0  mov rax, [r15+0x58]
00007cc2f47d13f4  mov r14d, eax
00007cc2f47d13f7  mov r14d, r14d
00007cc2f47d13fa  shl r14, 0x02
00007cc2f47d13fe  mov rax, [r15+0x98]
00007cc2f47d1405  lea r12, [rax+r14*1]
00007cc2f47d1409  mov eax, [r13+r12*1]
00007cc2f47d140e  mov [rsp+0x10], eax
00007cc2f47d1412  mov eax, eax
00007cc2f47d1414  mov [r15+0x60], rax
00007cc2f47d1418  mov eax, [r15+0x48]
00007cc2f47d141c  mov [rsp+0x20], eax
00007cc2f47d1420  xor eax, eax
00007cc2f47d1422  mov r14d, [rsp+0x10]
00007cc2f47d1427  mov r12d, [rsp+0x20]
00007cc2f47d142c  cmp r14d, r12d
00007cc2f47d142f  cmc
00007cc2f47d1430  lahf
00007cc2f47d1431  seto al
00007cc2f47d1434  mov [r15+0x108], eax
00007cc2f47d143b  mov eax, [r15+0x108]
00007cc2f47d1442  sahf
00007cc2f47d1443  cmc
00007cc2f47d1444  jbe 0x00007CC2F47D1476
00007cc2f47d1446  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d144e  jz 0x00007CC2F47D1220
00007cc2f47d1454  nop [rax+rax*1], ax
00007cc2f47d145d  nop [rax+rax*1], eax
00007cc2f47d1465  mov eax, 0x4103A0
00007cc2f47d146a  mov [r15+0x100], rax
00007cc2f47d1471  jmp 0x00007CC2F45FE110
00007cc2f47d1476  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d147e  jz 0x00007CC2F47D14C0
00007cc2f47d1484  nop [rax+rax*1], ax
00007cc2f47d148d  nop [rax+rax*1], eax
00007cc2f47d1495  mov eax, 0x410378
00007cc2f47d149a  mov [r15+0x100], rax
00007cc2f47d14a1  jmp 0x00007CC2F45FE110
00007cc2f47d14a6  int3
00007cc2f47d14a7  call 0x00007CC2F46B4690
00007cc2f47d14ac  jmp 0x00007CC2F47D140E
00007cc2f47d14b1  int3
00007cc2f47d14b2  nop [rax+rax*1], ax
00007cc2f47d14bb  nop [rax+rax*1], eax
00007cc2f47d14c0  mov rax, [r15+0x40]
00007cc2f47d14c4  lea r14, [rax+0x01]
00007cc2f47d14c8  mov [r15+0x40], r14
00007cc2f47d14cc  mov rax, [r15+0x50]
00007cc2f47d14d0  mov r12d, eax
00007cc2f47d14d3  mov r12d, r12d
00007cc2f47d14d6  shl r12, 0x02
00007cc2f47d14da  mov rax, [r15+0x98]
00007cc2f47d14e1  lea r11, [rax+r12*1]
00007cc2f47d14e5  mov eax, [r15+0x48]
00007cc2f47d14e9  mov [r13+r11*1], eax
00007cc2f47d14ee  xor eax, eax
00007cc2f47d14f0  mov r12d, 0x400
00007cc2f47d14f6  cmp r14, r12
00007cc2f47d14f9  cmc
00007cc2f47d14fa  lahf
00007cc2f47d14fb  seto al
00007cc2f47d14fe  mov [r15+0x108], eax
00007cc2f47d1505  mov eax, [r15+0x108]
00007cc2f47d150c  sahf
00007cc2f47d150d  jz 0x00007CC2F47D153F
00007cc2f47d150f  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d1517  jz 0x00007CC2F47D1120
00007cc2f47d151d  nop [rax+rax*1], ax
00007cc2f47d1526  nop [rax+rax*1], eax
00007cc2f47d152e  mov eax, 0x410388
00007cc2f47d1533  mov [r15+0x100], rax
00007cc2f47d153a  jmp 0x00007CC2F45FE110
00007cc2f47d153f  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d1547  jz 0x00007CC2F47D1580
00007cc2f47d154d  nop [rax+rax*1], ax
00007cc2f47d1556  nop [rax+rax*1], eax
00007cc2f47d155e  mov eax, 0x4103B0
00007cc2f47d1563  mov [r15+0x100], rax
00007cc2f47d156a  jmp 0x00007CC2F45FE110
00007cc2f47d156f  int3
00007cc2f47d1570  call 0x00007CC2F46A4270
00007cc2f47d1575  jmp 0x00007CC2F47D14EE
00007cc2f47d157a  int3
00007cc2f47d157b  nop [rax+rax*1], eax
00007cc2f47d1580  mov qword ptr [r15+0x40], 0x430000
00007cc2f47d1588  mov eax, 0x430CB0
00007cc2f47d158d  mov r14, [r13+rax*1]
00007cc2f47d1592  mov rax, [r15+0x98]
00007cc2f47d1599  mov r12d, [r13+rax*1]
00007cc2f47d159e  lea r11, [rax+0x04]
00007cc2f47d15a2  mov eax, [r13+r11*1]
00007cc2f47d15a7  mov r12d, r12d
00007cc2f47d15aa  mov [r15+0x68], r12
00007cc2f47d15ae  mov eax, eax
00007cc2f47d15b0  mov [r15+0x60], rax
00007cc2f47d15b4  mov rax, [r15+0x68]
00007cc2f47d15b8  mov [r15+0x68], rax
00007cc2f47d15bc  mov qword ptr [r15+0x58], 0x02
00007cc2f47d15c4  mov [rsp+0x10], rax
00007cc2f47d15c9  xor eax, eax
00007cc2f47d15cb  mov r12d, 0x02
00007cc2f47d15d1  mov r11d, 0x400
00007cc2f47d15d7  cmp r12, r11
00007cc2f47d15da  cmc
00007cc2f47d15db  lahf
00007cc2f47d15dc  seto al
00007cc2f47d15df  mov [r15+0x108], eax
00007cc2f47d15e6  mov rax, [r15+0x60]
00007cc2f47d15ea  mov r12d, 0x02
00007cc2f47d15f0  imul rax, r12
00007cc2f47d15f4  mov [r15+0x50], rax
00007cc2f47d15f8  mov rax, [rsp+0x10]
00007cc2f47d15fd  lea r12, [rax+r14*1]
00007cc2f47d1601  mov [r15+0x48], r12
00007cc2f47d1605  mov eax, [r15+0x108]
00007cc2f47d160c  sahf
00007cc2f47d160d  jnz 0x00007CC2F47D163F
00007cc2f47d160f  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d1617  jz 0x00007CC2F47D17B0
00007cc2f47d161d  nop [rax+rax*1], ax
00007cc2f47d1626  nop [rax+rax*1], eax
00007cc2f47d162e  mov eax, 0x4103E0
00007cc2f47d1633  mov [r15+0x100], rax
00007cc2f47d163a  jmp 0x00007CC2F45FE110
00007cc2f47d163f  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d1647  jz 0x00007CC2F47D1690
00007cc2f47d164d  nop [rax+rax*1], ax
00007cc2f47d1656  nop [rax+rax*1], eax
00007cc2f47d165e  mov eax, 0x4103C0
00007cc2f47d1663  mov [r15+0x100], rax
00007cc2f47d166a  jmp 0x00007CC2F45FE110
00007cc2f47d166f  int3
00007cc2f47d1670  call 0x00007CC2F460DC20
00007cc2f47d1675  jmp 0x00007CC2F47D1592
00007cc2f47d167a  call 0x00007CC2F460B5E0
00007cc2f47d167f  jmp 0x00007CC2F47D159E
00007cc2f47d1684  call 0x00007CC2F46A3D90
00007cc2f47d1689  jmp 0x00007CC2F47D15A7
00007cc2f47d168e  int3
00007cc2f47d168f  nop
00007cc2f47d1690  mov rax, [r15+0x98]
00007cc2f47d1697  mov r14, [r15+0x58]
00007cc2f47d169b  mov [rsp+0x10], r14
00007cc2f47d16a0  shl r14, 0x02
00007cc2f47d16a4  lea r12, [rax+r14*1]
00007cc2f47d16a8  mov eax, [r13+r12*1]
00007cc2f47d16ad  lea r14, [r12+0x04]
00007cc2f47d16b2  mov r12d, [r13+r14*1]
00007cc2f47d16b7  mov eax, eax
00007cc2f47d16b9  mov [r15+0x68], rax
00007cc2f47d16bd  mov r12d, r12d
00007cc2f47d16c0  mov [r15+0x60], r12
00007cc2f47d16c4  mov rax, [r15+0x68]
00007cc2f47d16c8  mov [rsp+0x20], rax
00007cc2f47d16cd  mov r14, [rsp+0x10]
00007cc2f47d16d2  imul rax, r14
00007cc2f47d16d6  mov r12, [rsp+0x20]
00007cc2f47d16db  lea r11, [r12+rax*1]
00007cc2f47d16df  mov [r15+0x68], r11
00007cc2f47d16e3  lea rax, [r14+0x02]
00007cc2f47d16e7  mov [r15+0x58], rax
00007cc2f47d16eb  mov [rsp+0x10], rax
00007cc2f47d16f0  xor eax, eax
00007cc2f47d16f2  mov r14, [rsp+0x10]
00007cc2f47d16f7  mov r12d, 0x400
00007cc2f47d16fd  cmp r14, r12
00007cc2f47d1700  cmc
00007cc2f47d1701  lahf
00007cc2f47d1702  seto al
00007cc2f47d1705  mov [r15+0x108], eax
00007cc2f47d170c  mov rax, [r15+0x50]
00007cc2f47d1710  mov r12, [r15+0x60]
00007cc2f47d1714  imul r14, r12
00007cc2f47d1718  lea r12, [rax+r14*1]
00007cc2f47d171c  mov [r15+0x50], r12
00007cc2f47d1720  mov rax, [r15+0x48]
00007cc2f47d1724  lea r14, [r11+rax*1]
00007cc2f47d1728  mov [r15+0x48], r14
00007cc2f47d172c  mov eax, [r15+0x108]
00007cc2f47d1733  sahf
00007cc2f47d1734  jnz 0x00007CC2F47D1766
00007cc2f47d1736  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d173e  jz 0x00007CC2F47D17B0
00007cc2f47d1744  nop [rax+rax*1], ax
00007cc2f47d174d  nop [rax+rax*1], eax
00007cc2f47d1755  mov eax, 0x4103E0
00007cc2f47d175a  mov [r15+0x100], rax
00007cc2f47d1761  jmp 0x00007CC2F45FE110
00007cc2f47d1766  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d176e  jz 0x00007CC2F47D1690
00007cc2f47d1774  nop [rax+rax*1], ax
00007cc2f47d177d  nop [rax+rax*1], eax
00007cc2f47d1785  mov eax, 0x4103C0
00007cc2f47d178a  mov [r15+0x100], rax
00007cc2f47d1791  jmp 0x00007CC2F45FE110
00007cc2f47d1796  int3
00007cc2f47d1797  call 0x00007CC2F46B4690
00007cc2f47d179c  jmp 0x00007CC2F47D16AD
00007cc2f47d17a1  call 0x00007CC2F46E26A0
00007cc2f47d17a6  jmp 0x00007CC2F47D16B7
00007cc2f47d17ab  int3
00007cc2f47d17ac  nop [rax], eax
00007cc2f47d17b0  mov qword ptr [r15+0x98], 0x00
00007cc2f47d17bb  mov rax, [r15+0x50]
00007cc2f47d17bf  mov r14, [r15+0x48]
00007cc2f47d17c3  lea r12, [rax+r14*1]
00007cc2f47d17c7  mov [r15+0x48], r12
00007cc2f47d17cb  mov rax, [r15+0x40]
00007cc2f47d17cf  lea r14, [rax+0xCB0]
00007cc2f47d17d6  mov [r13+r14*1], r12
00007cc2f47d17db  mov qword ptr [r15], 0x01
00007cc2f47d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007cc2f47d17ed  mov r14d, [r15+0x320]
00007cc2f47d17f4  mov eax, 0x4103F8
00007cc2f47d17f9  mov rcx, 0x7CC2F47D1860
00007cc2f47d1803  mov [r15+r14*8+0x328], rax
00007cc2f47d180b  mov [r15+r14*8+0x368], rcx
00007cc2f47d1813  add r14d, 0x01
00007cc2f47d1817  and r14d, 0x07
00007cc2f47d181b  mov [r15+0x320], r14d
00007cc2f47d1822  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d182a  jz 0x00007CC2F47D0F20
00007cc2f47d1830  nop [rax+rax*1], ax
00007cc2f47d1839  nop [rax+rax*1], eax
00007cc2f47d1841  mov eax, 0x4109A4
00007cc2f47d1846  mov [r15+0x100], rax
00007cc2f47d184d  jmp 0x00007CC2F45FE110
00007cc2f47d1852  int3
00007cc2f47d1853  call 0x00007CC2F46E2CE0
00007cc2f47d1858  jmp 0x00007CC2F47D17DB
00007cc2f47d185d  int3
00007cc2f47d185e  nop
00007cc2f47d1860  mov eax, [r15+0x98]
00007cc2f47d1867  lea r14d, [eax+0x01]
00007cc2f47d186c  mov [rsp+0x10], r14d
00007cc2f47d1871  mov r14d, r14d
00007cc2f47d1874  mov [r15+0x98], r14
00007cc2f47d187b  xor eax, eax
00007cc2f47d187d  mov r14d, [rsp+0x10]
00007cc2f47d1882  cmp r14d, 0x10000
00007cc2f47d1889  cmc
00007cc2f47d188a  lahf
00007cc2f47d188b  seto al
00007cc2f47d188e  mov [r15+0x108], eax
00007cc2f47d1895  mov eax, [r15+0x108]
00007cc2f47d189c  sahf
00007cc2f47d189d  jnz 0x00007CC2F47D18CF
00007cc2f47d189f  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d18a7  jz 0x00007CC2F47D19A0
00007cc2f47d18ad  nop [rax+rax*1], ax
00007cc2f47d18b6  nop [rax+rax*1], eax
00007cc2f47d18be  mov eax, 0x410404
00007cc2f47d18c3  mov [r15+0x100], rax
00007cc2f47d18ca  jmp 0x00007CC2F45FE110
00007cc2f47d18cf  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d18d7  jz 0x00007CC2F47D1910
00007cc2f47d18dd  nop [rax+rax*1], ax
00007cc2f47d18e6  nop [rax+rax*1], eax
00007cc2f47d18ee  mov eax, 0x4103F0
00007cc2f47d18f3  mov [r15+0x100], rax
00007cc2f47d18fa  jmp 0x00007CC2F45FE110
00007cc2f47d18ff  int3
00007cc2f47d1900  int3
00007cc2f47d1901  nop [rax+rax*1], ax
00007cc2f47d190a  nop [rax+rax*1], ax
00007cc2f47d1910  mov eax, [r15]
00007cc2f47d1913  mov r14d, [r15+0x98]
00007cc2f47d191a  lea r12d, [eax+r14d*1]
00007cc2f47d191f  mov r12d, r12d
00007cc2f47d1922  mov [r15], r12
00007cc2f47d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007cc2f47d1930  mov r14d, [r15+0x320]
00007cc2f47d1937  mov eax, 0x4103F8
00007cc2f47d193c  mov rcx, 0x7CC2F47D1860
00007cc2f47d1946  mov [r15+r14*8+0x328], rax
00007cc2f47d194e  mov [r15+r14*8+0x368], rcx
00007cc2f47d1956  add r14d, 0x01
00007cc2f47d195a  and r14d, 0x07
00007cc2f47d195e  mov [r15+0x320], r14d
00007cc2f47d1965  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d196d  jz 0x00007CC2F47D0F20
00007cc2f47d1973  nop [rax+rax*1], ax
00007cc2f47d197c  nop [rax+rax*1], eax
00007cc2f47d1984  mov eax, 0x4109A4
00007cc2f47d1989  mov [r15+0x100], rax
00007cc2f47d1990  jmp 0x00007CC2F45FE110
00007cc2f47d1995  int3
00007cc2f47d1996  int3
00007cc2f47d1997  nop [rax+rax*1], ax
00007cc2f47d19a0  vmovaps xmm1, [0x00007CC2F43FE010]
00007cc2f47d19a8  movq xmm1, xmm1
00007cc2f47d19ac  movaps [r15+0x110], xmm1
00007cc2f47d19b4  mov eax, 0x420B10
00007cc2f47d19b9  mov r14, [r13+rax*1]
00007cc2f47d19be  movq xmm1, r14
00007cc2f47d19c3  movaps [r15+0x120], xmm1
00007cc2f47d19cb  vmovaps xmm1, [0x00007CC2F43FE020]
00007cc2f47d19d3  movq xmm1, xmm1
00007cc2f47d19d7  movaps [r15+0x140], xmm1
00007cc2f47d19df  vmovaps xmm1, [0x00007CC2F43FE030]
00007cc2f47d19e7  vpbroadcastq xmm1, xmm1
00007cc2f47d19ec  movaps [r15+0x150], xmm1
00007cc2f47d19f4  mov qword ptr [r15+0x40], 0x02
00007cc2f47d19fc  vmovaps xmm15, [0x00007CC2F43FE040]
00007cc2f47d1a04  movq xmm15, xmm15
00007cc2f47d1a09  movaps [r15+0x160], xmm15
00007cc2f47d1a11  vmovaps xmm15, [0x00007CC2F43FE050]
00007cc2f47d1a19  vpbroadcastq xmm15, xmm15
00007cc2f47d1a1e  movaps [r15+0x130], xmm15
00007cc2f47d1a26  mov rax, [r15+0x40]
00007cc2f47d1a2a  vmovq xmm14, rax
00007cc2f47d1a2f  vpbroadcastq xmm14, xmm14
00007cc2f47d1a34  movaps [r15+0x170], xmm14
00007cc2f47d1a3c  mov eax, 0x420A40
00007cc2f47d1a41  movups xmm13, [r13+rax*1]
00007cc2f47d1a47  mov qword ptr [r15+0x40], 0x431E00
00007cc2f47d1a4f  mov eax, [r15]
00007cc2f47d1a52  mov r14d, 0x430CB8
00007cc2f47d1a58  mov [r13+r14*1], eax
00007cc2f47d1a5d  mov qword ptr [r15+0x50], 0x432000
00007cc2f47d1a65  vpmovqd xmm12, xmm13
00007cc2f47d1a6b  pxor xmm11, xmm11
00007cc2f47d1a70  punpcklqdq xmm12, xmm11
00007cc2f47d1a75  movaps [r15+0x210], xmm12
00007cc2f47d1a7d  movq xmm12, qword ptr [r15+0x140]
00007cc2f47d1a86  movq xmm11, qword ptr [r15+0x120]
00007cc2f47d1a8f  psubd xmm12, xmm11
00007cc2f47d1a94  movq xmm12, xmm12
00007cc2f47d1a99  paddq xmm13, xmm14
00007cc2f47d1a9e  movaps [r15+0x180], xmm13
00007cc2f47d1aa6  movq xmm14, qword ptr [r15+0x160]
00007cc2f47d1aaf  paddd xmm11, xmm14
00007cc2f47d1ab4  movq xmm11, xmm11
00007cc2f47d1ab9  movq xmm11, xmm11
00007cc2f47d1abe  movaps [r15+0x120], xmm11
00007cc2f47d1ac6  pmovzxdq xmm12, xmm12
00007cc2f47d1acc  psllq xmm12, 0x00
00007cc2f47d1ad2  movq xmm14, qword ptr [r15+0x210]
00007cc2f47d1adb  movq xmm13, qword ptr [r15+0x110]
00007cc2f47d1ae4  paddd xmm14, xmm13
00007cc2f47d1ae9  movq xmm14, xmm14
00007cc2f47d1aee  vcvtuqq2pd xmm12, xmm12
00007cc2f47d1af4  pmovzxdq xmm14, xmm14
00007cc2f47d1afa  psllq xmm14, 0x00
00007cc2f47d1b00  vcvtuqq2pd xmm14, xmm14
00007cc2f47d1b06  movaps xmm13, xmm12
00007cc2f47d1b0a  mulpd xmm13, xmm1
00007cc2f47d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007cc2f47d1b15  ptest xmm11, xmm11
00007cc2f47d1b1b  jnz 0x00007CC2F47D1C0F
00007cc2f47d1b21  movaps [r15+0x220], xmm13
00007cc2f47d1b29  mov eax, 0x432000
00007cc2f47d1b2e  movups [r13+rax*1], xmm13
00007cc2f47d1b34  movaps xmm1, xmm14
00007cc2f47d1b38  mulpd xmm1, xmm15
00007cc2f47d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007cc2f47d1b42  ptest xmm13, xmm13
00007cc2f47d1b48  jnz 0x00007CC2F47D1D5C
00007cc2f47d1b4e  movaps [r15+0x210], xmm1
00007cc2f47d1b56  mov eax, 0x431E00
00007cc2f47d1b5b  movups [r13+rax*1], xmm1
00007cc2f47d1b61  mov qword ptr [r15+0x48], 0x10
00007cc2f47d1b69  xor eax, eax
00007cc2f47d1b6b  mov r14d, 0x10
00007cc2f47d1b71  mov r12d, 0x200
00007cc2f47d1b77  cmp r14, r12
00007cc2f47d1b7a  cmc
00007cc2f47d1b7b  lahf
00007cc2f47d1b7c  seto al
00007cc2f47d1b7f  mov [r15+0x108], eax
00007cc2f47d1b86  mov eax, [r15+0x108]
00007cc2f47d1b8d  sahf
00007cc2f47d1b8e  jnz 0x00007CC2F47D1BC0
00007cc2f47d1b90  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d1b98  jz 0x00007CC2F47D2300
00007cc2f47d1b9e  nop [rax+rax*1], ax
00007cc2f47d1ba7  nop [rax+rax*1], eax
00007cc2f47d1baf  mov eax, 0x410490
00007cc2f47d1bb4  mov [r15+0x100], rax
00007cc2f47d1bbb  jmp 0x00007CC2F45FE110
00007cc2f47d1bc0  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d1bc8  jz 0x00007CC2F47D1EB0
00007cc2f47d1bce  nop [rax+rax*1], ax
00007cc2f47d1bd7  nop [rax+rax*1], eax
00007cc2f47d1bdf  mov eax, 0x410450
00007cc2f47d1be4  mov [r15+0x100], rax
00007cc2f47d1beb  jmp 0x00007CC2F45FE110
00007cc2f47d1bf0  int3
00007cc2f47d1bf1  call 0x00007CC2F460DC20
00007cc2f47d1bf6  jmp 0x00007CC2F47D19BE
00007cc2f47d1bfb  call 0x00007CC2F460C260
00007cc2f47d1c00  jmp 0x00007CC2F47D1A47
00007cc2f47d1c05  call 0x00007CC2F46D5D70
00007cc2f47d1c0a  jmp 0x00007CC2F47D1A5D
00007cc2f47d1c0f  sub rsp, 0x08
00007cc2f47d1c13  push rax
00007cc2f47d1c14  push rcx
00007cc2f47d1c15  push rdx
00007cc2f47d1c16  push rdi
00007cc2f47d1c17  push rsi
00007cc2f47d1c18  push r8
00007cc2f47d1c1a  push r9
00007cc2f47d1c1c  push r10
00007cc2f47d1c1e  push r11
00007cc2f47d1c20  sub rsp, 0xF0
00007cc2f47d1c27  vmovaps [rsp], xmm0
00007cc2f47d1c2c  vmovaps [rsp+0x10], xmm1
00007cc2f47d1c32  vmovaps [rsp+0x20], xmm2
00007cc2f47d1c38  vmovaps [rsp+0x30], xmm3
00007cc2f47d1c3e  vmovaps [rsp+0x40], xmm4
00007cc2f47d1c44  vmovaps [rsp+0x50], xmm5
00007cc2f47d1c4a  vmovaps [rsp+0x60], xmm6
00007cc2f47d1c50  vmovaps [rsp+0x70], xmm7
00007cc2f47d1c56  vmovaps [rsp+0x80], xmm8
00007cc2f47d1c5f  vmovaps [rsp+0x90], xmm9
00007cc2f47d1c68  vmovaps [rsp+0xA0], xmm10
00007cc2f47d1c71  vmovaps [rsp+0xB0], xmm11
00007cc2f47d1c7a  vmovaps [rsp+0xC0], xmm12
00007cc2f47d1c83  vmovaps [rsp+0xD0], xmm14
00007cc2f47d1c8c  vmovaps [rsp+0xE0], xmm15
00007cc2f47d1c95  sub rsp, 0x30
00007cc2f47d1c99  movaps [rsp], xmm13
00007cc2f47d1c9e  movaps [rsp+0x10], xmm12
00007cc2f47d1ca4  movaps [rsp+0x20], xmm1
00007cc2f47d1ca9  lea rdi, [rsp]
00007cc2f47d1cad  mov esi, 0x00
00007cc2f47d1cb2  mov rax, 0x5990E710A530
00007cc2f47d1cbc  call rax
00007cc2f47d1cbe  movaps xmm13, [rsp]
00007cc2f47d1cc3  add rsp, 0x30
00007cc2f47d1cc7  vmovaps xmm0, [rsp]
00007cc2f47d1ccc  vmovaps xmm1, [rsp+0x10]
00007cc2f47d1cd2  vmovaps xmm2, [rsp+0x20]
00007cc2f47d1cd8  vmovaps xmm3, [rsp+0x30]
00007cc2f47d1cde  vmovaps xmm4, [rsp+0x40]
00007cc2f47d1ce4  vmovaps xmm5, [rsp+0x50]
00007cc2f47d1cea  vmovaps xmm6, [rsp+0x60]
00007cc2f47d1cf0  vmovaps xmm7, [rsp+0x70]
00007cc2f47d1cf6  vmovaps xmm8, [rsp+0x80]
00007cc2f47d1cff  vmovaps xmm9, [rsp+0x90]
00007cc2f47d1d08  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d1d11  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d1d1a  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d1d23  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d1d2c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d1d35  add rsp, 0xF0
00007cc2f47d1d3c  pop r11
00007cc2f47d1d3e  pop r10
00007cc2f47d1d40  pop r9
00007cc2f47d1d42  pop r8
00007cc2f47d1d44  pop rsi
00007cc2f47d1d45  pop rdi
00007cc2f47d1d46  pop rdx
00007cc2f47d1d47  pop rcx
00007cc2f47d1d48  pop rax
00007cc2f47d1d49  add rsp, 0x08
00007cc2f47d1d4d  jmp 0x00007CC2F47D1B21
00007cc2f47d1d52  call 0x00007CC2F460C380
00007cc2f47d1d57  jmp 0x00007CC2F47D1B34
00007cc2f47d1d5c  sub rsp, 0x08
00007cc2f47d1d60  push rax
00007cc2f47d1d61  push rcx
00007cc2f47d1d62  push rdx
00007cc2f47d1d63  push rdi
00007cc2f47d1d64  push rsi
00007cc2f47d1d65  push r8
00007cc2f47d1d67  push r9
00007cc2f47d1d69  push r10
00007cc2f47d1d6b  push r11
00007cc2f47d1d6d  sub rsp, 0xF0
00007cc2f47d1d74  vmovaps [rsp], xmm0
00007cc2f47d1d79  vmovaps [rsp+0x10], xmm2
00007cc2f47d1d7f  vmovaps [rsp+0x20], xmm3
00007cc2f47d1d85  vmovaps [rsp+0x30], xmm4
00007cc2f47d1d8b  vmovaps [rsp+0x40], xmm5
00007cc2f47d1d91  vmovaps [rsp+0x50], xmm6
00007cc2f47d1d97  vmovaps [rsp+0x60], xmm7
00007cc2f47d1d9d  vmovaps [rsp+0x70], xmm8
00007cc2f47d1da3  vmovaps [rsp+0x80], xmm9
00007cc2f47d1dac  vmovaps [rsp+0x90], xmm10
00007cc2f47d1db5  vmovaps [rsp+0xA0], xmm11
00007cc2f47d1dbe  vmovaps [rsp+0xB0], xmm12
00007cc2f47d1dc7  vmovaps [rsp+0xC0], xmm13
00007cc2f47d1dd0  vmovaps [rsp+0xD0], xmm14
00007cc2f47d1dd9  vmovaps [rsp+0xE0], xmm15
00007cc2f47d1de2  sub rsp, 0x30
00007cc2f47d1de6  movaps [rsp], xmm1
00007cc2f47d1dea  movaps [rsp+0x10], xmm14
00007cc2f47d1df0  movaps [rsp+0x20], xmm15
00007cc2f47d1df6  lea rdi, [rsp]
00007cc2f47d1dfa  mov esi, 0x00
00007cc2f47d1dff  mov rax, 0x5990E710A530
00007cc2f47d1e09  call rax
00007cc2f47d1e0b  movaps xmm1, [rsp]
00007cc2f47d1e0f  add rsp, 0x30
00007cc2f47d1e13  vmovaps xmm0, [rsp]
00007cc2f47d1e18  vmovaps xmm2, [rsp+0x10]
00007cc2f47d1e1e  vmovaps xmm3, [rsp+0x20]
00007cc2f47d1e24  vmovaps xmm4, [rsp+0x30]
00007cc2f47d1e2a  vmovaps xmm5, [rsp+0x40]
00007cc2f47d1e30  vmovaps xmm6, [rsp+0x50]
00007cc2f47d1e36  vmovaps xmm7, [rsp+0x60]
00007cc2f47d1e3c  vmovaps xmm8, [rsp+0x70]
00007cc2f47d1e42  vmovaps xmm9, [rsp+0x80]
00007cc2f47d1e4b  vmovaps xmm10, [rsp+0x90]
00007cc2f47d1e54  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d1e5d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d1e66  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d1e6f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d1e78  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d1e81  add rsp, 0xF0
00007cc2f47d1e88  pop r11
00007cc2f47d1e8a  pop r10
00007cc2f47d1e8c  pop r9
00007cc2f47d1e8e  pop r8
00007cc2f47d1e90  pop rsi
00007cc2f47d1e91  pop rdi
00007cc2f47d1e92  pop rdx
00007cc2f47d1e93  pop rcx
00007cc2f47d1e94  pop rax
00007cc2f47d1e95  add rsp, 0x08
00007cc2f47d1e99  jmp 0x00007CC2F47D1B4E
00007cc2f47d1e9e  call 0x00007CC2F45FF540
00007cc2f47d1ea3  jmp 0x00007CC2F47D1B61
00007cc2f47d1ea8  int3
00007cc2f47d1ea9  nop [rax], eax
00007cc2f47d1eb0  movaps xmm1, [r15+0x180]
00007cc2f47d1eb8  vpmovqd xmm15, xmm1
00007cc2f47d1ebe  pxor xmm14, xmm14
00007cc2f47d1ec3  punpcklqdq xmm15, xmm14
00007cc2f47d1ec8  movaps [r15+0x210], xmm15
00007cc2f47d1ed0  movq xmm15, qword ptr [r15+0x140]
00007cc2f47d1ed9  movq xmm14, qword ptr [r15+0x120]
00007cc2f47d1ee2  psubd xmm15, xmm14
00007cc2f47d1ee7  movq xmm15, xmm15
00007cc2f47d1eec  movaps xmm13, [r15+0x170]
00007cc2f47d1ef4  paddq xmm1, xmm13
00007cc2f47d1ef9  movaps [r15+0x180], xmm1
00007cc2f47d1f01  movq xmm1, qword ptr [r15+0x160]
00007cc2f47d1f0a  paddd xmm14, xmm1
00007cc2f47d1f0f  movq xmm14, xmm14
00007cc2f47d1f14  movq xmm14, xmm14
00007cc2f47d1f19  movaps [r15+0x120], xmm14
00007cc2f47d1f21  pmovzxdq xmm15, xmm15
00007cc2f47d1f27  psllq xmm15, 0x00
00007cc2f47d1f2d  movq xmm1, qword ptr [r15+0x210]
00007cc2f47d1f36  movq xmm14, qword ptr [r15+0x110]
00007cc2f47d1f3f  paddd xmm1, xmm14
00007cc2f47d1f44  movq xmm1, xmm1
00007cc2f47d1f48  vcvtuqq2pd xmm15, xmm15
00007cc2f47d1f4e  pmovzxdq xmm1, xmm1
00007cc2f47d1f53  psllq xmm1, 0x00
00007cc2f47d1f58  vcvtuqq2pd xmm1, xmm1
00007cc2f47d1f5e  movaps xmm14, [r15+0x150]
00007cc2f47d1f66  movaps xmm13, xmm15
00007cc2f47d1f6a  mulpd xmm13, xmm14
00007cc2f47d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2f47d1f75  ptest xmm12, xmm12
00007cc2f47d1f7b  jnz 0x00007CC2F47D205E
00007cc2f47d1f81  movaps [r15+0x220], xmm13
00007cc2f47d1f89  mov rax, [r15+0x48]
00007cc2f47d1f8d  mov r14, [r15+0x50]
00007cc2f47d1f91  lea r12, [r14+rax*1]
00007cc2f47d1f95  movups [r13+r12*1], xmm13
00007cc2f47d1f9b  movaps xmm15, [r15+0x130]
00007cc2f47d1fa3  movaps xmm14, xmm1
00007cc2f47d1fa7  mulpd xmm14, xmm15
00007cc2f47d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007cc2f47d1fb2  ptest xmm13, xmm13
00007cc2f47d1fb8  jnz 0x00007CC2F47D21AC
00007cc2f47d1fbe  movaps [r15+0x210], xmm14
00007cc2f47d1fc6  mov r14, [r15+0x40]
00007cc2f47d1fca  lea r12, [r14+rax*1]
00007cc2f47d1fce  movups [r13+r12*1], xmm14
00007cc2f47d1fd4  lea r14, [rax+0x10]
00007cc2f47d1fd8  mov [r15+0x48], r14
00007cc2f47d1fdc  xor eax, eax
00007cc2f47d1fde  mov r12d, 0x200
00007cc2f47d1fe4  cmp r14, r12
00007cc2f47d1fe7  cmc
00007cc2f47d1fe8  lahf
00007cc2f47d1fe9  seto al
00007cc2f47d1fec  mov [r15+0x108], eax
00007cc2f47d1ff3  mov eax, [r15+0x108]
00007cc2f47d1ffa  sahf
00007cc2f47d1ffb  jnz 0x00007CC2F47D202D
00007cc2f47d1ffd  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d2005  jz 0x00007CC2F47D2300
00007cc2f47d200b  nop [rax+rax*1], ax
00007cc2f47d2014  nop [rax+rax*1], eax
00007cc2f47d201c  mov eax, 0x410490
00007cc2f47d2021  mov [r15+0x100], rax
00007cc2f47d2028  jmp 0x00007CC2F45FE110
00007cc2f47d202d  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d2035  jz 0x00007CC2F47D1EB0
00007cc2f47d203b  nop [rax+rax*1], ax
00007cc2f47d2044  nop [rax+rax*1], eax
00007cc2f47d204c  mov eax, 0x410450
00007cc2f47d2051  mov [r15+0x100], rax
00007cc2f47d2058  jmp 0x00007CC2F45FE110
00007cc2f47d205d  int3
00007cc2f47d205e  sub rsp, 0x08
00007cc2f47d2062  push rax
00007cc2f47d2063  push rcx
00007cc2f47d2064  push rdx
00007cc2f47d2065  push rdi
00007cc2f47d2066  push rsi
00007cc2f47d2067  push r8
00007cc2f47d2069  push r9
00007cc2f47d206b  push r10
00007cc2f47d206d  push r11
00007cc2f47d206f  sub rsp, 0xF0
00007cc2f47d2076  vmovaps [rsp], xmm0
00007cc2f47d207b  vmovaps [rsp+0x10], xmm1
00007cc2f47d2081  vmovaps [rsp+0x20], xmm2
00007cc2f47d2087  vmovaps [rsp+0x30], xmm3
00007cc2f47d208d  vmovaps [rsp+0x40], xmm4
00007cc2f47d2093  vmovaps [rsp+0x50], xmm5
00007cc2f47d2099  vmovaps [rsp+0x60], xmm6
00007cc2f47d209f  vmovaps [rsp+0x70], xmm7
00007cc2f47d20a5  vmovaps [rsp+0x80], xmm8
00007cc2f47d20ae  vmovaps [rsp+0x90], xmm9
00007cc2f47d20b7  vmovaps [rsp+0xA0], xmm10
00007cc2f47d20c0  vmovaps [rsp+0xB0], xmm11
00007cc2f47d20c9  vmovaps [rsp+0xC0], xmm12
00007cc2f47d20d2  vmovaps [rsp+0xD0], xmm14
00007cc2f47d20db  vmovaps [rsp+0xE0], xmm15
00007cc2f47d20e4  sub rsp, 0x30
00007cc2f47d20e8  movaps [rsp], xmm13
00007cc2f47d20ed  movaps [rsp+0x10], xmm15
00007cc2f47d20f3  movaps [rsp+0x20], xmm14
00007cc2f47d20f9  lea rdi, [rsp]
00007cc2f47d20fd  mov esi, 0x00
00007cc2f47d2102  mov rax, 0x5990E710A530
00007cc2f47d210c  call rax
00007cc2f47d210e  movaps xmm13, [rsp]
00007cc2f47d2113  add rsp, 0x30
00007cc2f47d2117  vmovaps xmm0, [rsp]
00007cc2f47d211c  vmovaps xmm1, [rsp+0x10]
00007cc2f47d2122  vmovaps xmm2, [rsp+0x20]
00007cc2f47d2128  vmovaps xmm3, [rsp+0x30]
00007cc2f47d212e  vmovaps xmm4, [rsp+0x40]
00007cc2f47d2134  vmovaps xmm5, [rsp+0x50]
00007cc2f47d213a  vmovaps xmm6, [rsp+0x60]
00007cc2f47d2140  vmovaps xmm7, [rsp+0x70]
00007cc2f47d2146  vmovaps xmm8, [rsp+0x80]
00007cc2f47d214f  vmovaps xmm9, [rsp+0x90]
00007cc2f47d2158  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d2161  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d216a  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d2173  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d217c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d2185  add rsp, 0xF0
00007cc2f47d218c  pop r11
00007cc2f47d218e  pop r10
00007cc2f47d2190  pop r9
00007cc2f47d2192  pop r8
00007cc2f47d2194  pop rsi
00007cc2f47d2195  pop rdi
00007cc2f47d2196  pop rdx
00007cc2f47d2197  pop rcx
00007cc2f47d2198  pop rax
00007cc2f47d2199  add rsp, 0x08
00007cc2f47d219d  jmp 0x00007CC2F47D1F81
00007cc2f47d21a2  call 0x00007CC2F46C2240
00007cc2f47d21a7  jmp 0x00007CC2F47D1F9B
00007cc2f47d21ac  sub rsp, 0x08
00007cc2f47d21b0  push rax
00007cc2f47d21b1  push rcx
00007cc2f47d21b2  push rdx
00007cc2f47d21b3  push rdi
00007cc2f47d21b4  push rsi
00007cc2f47d21b5  push r8
00007cc2f47d21b7  push r9
00007cc2f47d21b9  push r10
00007cc2f47d21bb  push r11
00007cc2f47d21bd  sub rsp, 0xF0
00007cc2f47d21c4  vmovaps [rsp], xmm0
00007cc2f47d21c9  vmovaps [rsp+0x10], xmm1
00007cc2f47d21cf  vmovaps [rsp+0x20], xmm2
00007cc2f47d21d5  vmovaps [rsp+0x30], xmm3
00007cc2f47d21db  vmovaps [rsp+0x40], xmm4
00007cc2f47d21e1  vmovaps [rsp+0x50], xmm5
00007cc2f47d21e7  vmovaps [rsp+0x60], xmm6
00007cc2f47d21ed  vmovaps [rsp+0x70], xmm7
00007cc2f47d21f3  vmovaps [rsp+0x80], xmm8
00007cc2f47d21fc  vmovaps [rsp+0x90], xmm9
00007cc2f47d2205  vmovaps [rsp+0xA0], xmm10
00007cc2f47d220e  vmovaps [rsp+0xB0], xmm11
00007cc2f47d2217  vmovaps [rsp+0xC0], xmm12
00007cc2f47d2220  vmovaps [rsp+0xD0], xmm13
00007cc2f47d2229  vmovaps [rsp+0xE0], xmm15
00007cc2f47d2232  sub rsp, 0x30
00007cc2f47d2236  movaps [rsp], xmm14
00007cc2f47d223b  movaps [rsp+0x10], xmm1
00007cc2f47d2240  movaps [rsp+0x20], xmm15
00007cc2f47d2246  lea rdi, [rsp]
00007cc2f47d224a  mov esi, 0x00
00007cc2f47d224f  mov rax, 0x5990E710A530
00007cc2f47d2259  call rax
00007cc2f47d225b  movaps xmm14, [rsp]
00007cc2f47d2260  add rsp, 0x30
00007cc2f47d2264  vmovaps xmm0, [rsp]
00007cc2f47d2269  vmovaps xmm1, [rsp+0x10]
00007cc2f47d226f  vmovaps xmm2, [rsp+0x20]
00007cc2f47d2275  vmovaps xmm3, [rsp+0x30]
00007cc2f47d227b  vmovaps xmm4, [rsp+0x40]
00007cc2f47d2281  vmovaps xmm5, [rsp+0x50]
00007cc2f47d2287  vmovaps xmm6, [rsp+0x60]
00007cc2f47d228d  vmovaps xmm7, [rsp+0x70]
00007cc2f47d2293  vmovaps xmm8, [rsp+0x80]
00007cc2f47d229c  vmovaps xmm9, [rsp+0x90]
00007cc2f47d22a5  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d22ae  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d22b7  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d22c0  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d22c9  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d22d2  add rsp, 0xF0
00007cc2f47d22d9  pop r11
00007cc2f47d22db  pop r10
00007cc2f47d22dd  pop r9
00007cc2f47d22df  pop r8
00007cc2f47d22e1  pop rsi
00007cc2f47d22e2  pop rdi
00007cc2f47d22e3  pop rdx
00007cc2f47d22e4  pop rcx
00007cc2f47d22e5  pop rax
00007cc2f47d22e6  add rsp, 0x08
00007cc2f47d22ea  jmp 0x00007CC2F47D1FBE
00007cc2f47d22ef  call 0x00007CC2F46C34C0
00007cc2f47d22f4  jmp 0x00007CC2F47D1FD4
00007cc2f47d22f9  int3
00007cc2f47d22fa  nop [rax+rax*1], ax
00007cc2f47d2300  mov rax, [r15+0x50]
00007cc2f47d2304  lea r14, [rax+0x80]
00007cc2f47d230b  movups xmm1, [r13+r14*1]
00007cc2f47d2311  lea r14, [rax+0x90]
00007cc2f47d2318  movups xmm15, [r13+r14*1]
00007cc2f47d231e  vxorps xmm14, xmm14, xmm14
00007cc2f47d2323  vpbroadcastq xmm14, xmm14
00007cc2f47d2328  lea r14, [rax+0x40]
00007cc2f47d232c  movups xmm13, [r13+r14*1]
00007cc2f47d2332  lea r14, [rax+0x50]
00007cc2f47d2336  movups xmm12, [r13+r14*1]
00007cc2f47d233c  mov qword ptr [r15+0x48], 0x00
00007cc2f47d2344  movups xmm11, [r13+rax*1]
00007cc2f47d234a  lea r14, [rax+0x10]
00007cc2f47d234e  movups xmm10, [r13+r14*1]
00007cc2f47d2354  mov r14, [r15+0xF8]
00007cc2f47d235b  lea r12, [r14+0xE0]
00007cc2f47d2362  movups [r13+r12*1], xmm15
00007cc2f47d2368  lea r12, [r14+0xF0]
00007cc2f47d236f  movups [r13+r12*1], xmm1
00007cc2f47d2375  lea r12, [rax+0xC0]
00007cc2f47d237c  movups xmm1, [r13+r12*1]
00007cc2f47d2382  lea r12, [rax+0xD0]
00007cc2f47d2389  movups xmm15, [r13+r12*1]
00007cc2f47d238f  lea r12, [rax+0x140]
00007cc2f47d2396  movups xmm9, [r13+r12*1]
00007cc2f47d239c  lea r12, [rax+0x150]
00007cc2f47d23a3  movups xmm8, [r13+r12*1]
00007cc2f47d23a9  lea r12, [rax+0x180]
00007cc2f47d23b0  movups xmm7, [r13+r12*1]
00007cc2f47d23b6  lea r12, [rax+0x190]
00007cc2f47d23bd  movups xmm6, [r13+r12*1]
00007cc2f47d23c3  lea r12, [r14+0xC0]
00007cc2f47d23ca  movups [r13+r12*1], xmm15
00007cc2f47d23d0  lea r12, [r14+0xD0]
00007cc2f47d23d7  movups [r13+r12*1], xmm1
00007cc2f47d23dd  lea r12, [rax+0x100]
00007cc2f47d23e4  movups xmm1, [r13+r12*1]
00007cc2f47d23ea  lea r12, [rax+0x110]
00007cc2f47d23f1  movups xmm15, [r13+r12*1]
00007cc2f47d23f7  lea r12, [rax+0x1C0]
00007cc2f47d23fe  movups xmm5, [r13+r12*1]
00007cc2f47d2404  lea r12, [rax+0x1D0]
00007cc2f47d240b  movups xmm4, [r13+r12*1]
00007cc2f47d2411  lea r12, [rax+0x20]
00007cc2f47d2415  movups xmm3, [r13+r12*1]
00007cc2f47d241b  lea r12, [rax+0x30]
00007cc2f47d241f  movups xmm2, [r13+r12*1]
00007cc2f47d2425  movaps [r15+0x1F0], xmm2
00007cc2f47d242d  lea r12, [r14+0x20]
00007cc2f47d2431  movups [r13+r12*1], xmm1
00007cc2f47d2437  lea r12, [r14+0x30]
00007cc2f47d243b  movups [r13+r12*1], xmm12
00007cc2f47d2441  lea r12, [rax+0x60]
00007cc2f47d2445  movups xmm1, [r13+r12*1]
00007cc2f47d244b  lea r12, [rax+0x70]
00007cc2f47d244f  movups xmm12, [r13+r12*1]
00007cc2f47d2455  lea r12, [r14+0x60]
00007cc2f47d2459  movups [r13+r12*1], xmm11
00007cc2f47d245f  lea r12, [r14+0x70]
00007cc2f47d2463  movups [r13+r12*1], xmm5
00007cc2f47d2469  lea r12, [rax+0xE0]
00007cc2f47d2470  movups xmm11, [r13+r12*1]
00007cc2f47d2476  lea r12, [rax+0xF0]
00007cc2f47d247d  movups xmm5, [r13+r12*1]
00007cc2f47d2483  lea r12, [rax+0x120]
00007cc2f47d248a  vmovaps [rsp+0x10], xmm1
00007cc2f47d2490  movups xmm1, [r13+r12*1]
00007cc2f47d2496  lea r12, [rax+0x130]
00007cc2f47d249d  vmovaps [rsp+0x20], xmm1
00007cc2f47d24a3  movups xmm1, [r13+r12*1]
00007cc2f47d24a9  lea r12, [r14+0xA0]
00007cc2f47d24b0  movups [r13+r12*1], xmm12
00007cc2f47d24b6  lea r12, [r14+0xB0]
00007cc2f47d24bd  vmovaps xmm12, [rsp+0x10]
00007cc2f47d24c3  movups [r13+r12*1], xmm12
00007cc2f47d24c9  lea r12, [rax+0xA0]
00007cc2f47d24d0  movups xmm12, [r13+r12*1]
00007cc2f47d24d6  lea r12, [rax+0xB0]
00007cc2f47d24dd  vmovaps [rsp+0x10], xmm1
00007cc2f47d24e3  movups xmm1, [r13+r12*1]
00007cc2f47d24e9  lea r12, [rax+0x160]
00007cc2f47d24f0  vmovaps [rsp+0x30], xmm1
00007cc2f47d24f6  movups xmm1, [r13+r12*1]
00007cc2f47d24fc  lea r12, [rax+0x170]
00007cc2f47d2503  vmovaps [rsp+0x40], xmm1
00007cc2f47d2509  movups xmm1, [r13+r12*1]
00007cc2f47d250f  movaps [r15+0x2B0], xmm1
00007cc2f47d2517  lea r12, [rax+0x1A0]
00007cc2f47d251e  vmovaps [rsp+0x50], xmm1
00007cc2f47d2524  movups xmm1, [r13+r12*1]
00007cc2f47d252a  lea r12, [rax+0x1B0]
00007cc2f47d2531  vmovaps [rsp+0x60], xmm1
00007cc2f47d2537  movups xmm1, [r13+r12*1]
00007cc2f47d253d  vmovaps [rsp+0x70], xmm1
00007cc2f47d2543  vmovaps xmm1, [rsp+0x60]
00007cc2f47d2549  movaps [r15+0x290], xmm1
00007cc2f47d2551  vmovaps [rsp+0x60], xmm1
00007cc2f47d2557  vmovaps xmm1, [rsp+0x70]
00007cc2f47d255d  movaps [r15+0x1E0], xmm1
00007cc2f47d2565  lea r12, [r14+0x80]
00007cc2f47d256c  vmovaps [rsp+0x70], xmm1
00007cc2f47d2572  vmovaps xmm1, [rsp+0x30]
00007cc2f47d2578  movups [r13+r12*1], xmm1
00007cc2f47d257e  lea r12, [r14+0x90]
00007cc2f47d2585  movups [r13+r12*1], xmm12
00007cc2f47d258b  lea r12, [rax+0x1E0]
00007cc2f47d2592  movups xmm1, [r13+r12*1]
00007cc2f47d2598  lea r12, [rax+0x1F0]
00007cc2f47d259f  movups xmm12, [r13+r12*1]
00007cc2f47d25a5  mov qword ptr [r15+0x50], 0x432200
00007cc2f47d25ad  lea rax, [r14+0x40]
00007cc2f47d25b1  vmovaps [rsp+0x30], xmm1
00007cc2f47d25b7  vmovaps xmm1, [rsp+0x40]
00007cc2f47d25bd  movups [r13+rax*1], xmm1
00007cc2f47d25c3  lea rax, [r14+0x50]
00007cc2f47d25c7  movups [r13+rax*1], xmm10
00007cc2f47d25cd  movups [r13+r14*1], xmm12
00007cc2f47d25d3  lea rax, [r14+0x10]
00007cc2f47d25d7  vmovaps xmm1, [rsp+0x30]
00007cc2f47d25dd  movups [r13+rax*1], xmm1
00007cc2f47d25e3  mov rax, [r15+0x40]
00007cc2f47d25e7  vmovaps [rsp+0x30], xmm3
00007cc2f47d25ed  vmovaps xmm1, [rsp+0x30]
00007cc2f47d25f3  por xmm3, xmm1
00007cc2f47d25f7  vmovaps [rsp+0x30], xmm6
00007cc2f47d25fd  vmovaps xmm12, [rsp+0x30]
00007cc2f47d2603  por xmm6, xmm12
00007cc2f47d2608  lea r12, [rax+0x30]
00007cc2f47d260c  mov r11, [r13+r12*1]
00007cc2f47d2611  lea r12, [rax+0x38]
00007cc2f47d2615  mov r10, [r13+r12*1]
00007cc2f47d261a  movq xmm12, r11
00007cc2f47d261f  movq xmm10, r10
00007cc2f47d2624  movq xmm12, xmm12
00007cc2f47d2629  vmovaps [rsp+0x30], xmm12
00007cc2f47d262f  movq xmm12, xmm12
00007cc2f47d2634  movaps [r15+0x130], xmm12
00007cc2f47d263c  movq xmm10, xmm10
00007cc2f47d2641  vmovaps [rsp+0x40], xmm10
00007cc2f47d2647  movq xmm10, xmm10
00007cc2f47d264c  movaps [r15+0x280], xmm10
00007cc2f47d2654  vmovaps [rsp+0x80], xmm9
00007cc2f47d265d  vmovaps xmm12, [rsp+0x80]
00007cc2f47d2666  por xmm9, xmm12
00007cc2f47d266b  lea r12, [rax+0x20]
00007cc2f47d266f  mov r11, [r13+r12*1]
00007cc2f47d2674  lea r12, [rax+0x28]
00007cc2f47d2678  mov r10, [r13+r12*1]
00007cc2f47d267d  movq xmm12, r11
00007cc2f47d2682  movq xmm10, r10
00007cc2f47d2687  movq xmm12, xmm12
00007cc2f47d268c  vmovaps [rsp+0x80], xmm12
00007cc2f47d2695  movq xmm12, xmm12
00007cc2f47d269a  movaps [r15+0x150], xmm12
00007cc2f47d26a2  movq xmm10, xmm10
00007cc2f47d26a7  vmovaps [rsp+0x90], xmm10
00007cc2f47d26b0  movq xmm10, xmm10
00007cc2f47d26b5  movaps [r15+0x140], xmm10
00007cc2f47d26bd  lea r12, [rax+0x10]
00007cc2f47d26c1  mov r11, [r13+r12*1]
00007cc2f47d26c6  lea r12, [rax+0x18]
00007cc2f47d26ca  mov r10, [r13+r12*1]
00007cc2f47d26cf  movq xmm12, r11
00007cc2f47d26d4  movq xmm10, r10
00007cc2f47d26d9  movq xmm12, xmm12
00007cc2f47d26de  vmovaps [rsp+0xA0], xmm12
00007cc2f47d26e7  movq xmm12, xmm12
00007cc2f47d26ec  movaps [r15+0x170], xmm12
00007cc2f47d26f4  movq xmm10, xmm10
00007cc2f47d26f9  vmovaps [rsp+0xB0], xmm10
00007cc2f47d2702  movq xmm10, xmm10
00007cc2f47d2707  movaps [r15+0x160], xmm10
00007cc2f47d270f  mov r12, [r13+rax*1]
00007cc2f47d2714  vmovq xmm12, r12
00007cc2f47d2719  vpbroadcastq xmm12, xmm12
00007cc2f47d271e  lea r12, [rax+0x08]
00007cc2f47d2722  mov rax, [r13+r12*1]
00007cc2f47d2727  movq xmm10, rax
00007cc2f47d272c  movaps [r15+0x230], xmm10
00007cc2f47d2734  lea rax, [r14+0x50]
00007cc2f47d2738  movups xmm10, [r13+rax*1]
00007cc2f47d273e  lea rax, [r14+0x60]
00007cc2f47d2742  vmovaps [rsp+0xC0], xmm1
00007cc2f47d274b  movups xmm1, [r13+rax*1]
00007cc2f47d2751  lea rax, [r14+0x30]
00007cc2f47d2755  vmovaps [rsp+0xD0], xmm1
00007cc2f47d275e  movups xmm1, [r13+rax*1]
00007cc2f47d2764  mov qword ptr [r15+0x60], 0x432200
00007cc2f47d276c  mov qword ptr [r15+0x58], 0x40
00007cc2f47d2774  vmovaps [rsp+0xE0], xmm1
00007cc2f47d277d  vmovaps [rsp+0xF0], xmm15
00007cc2f47d2786  vmovaps xmm15, [rsp+0xC0]
00007cc2f47d278f  vmovaps [rsp+0xC0], xmm14
00007cc2f47d2798  movaps xmm1, xmm12
00007cc2f47d279c  mulpd xmm1, xmm15
00007cc2f47d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007cc2f47d27a6  ptest xmm14, xmm14
00007cc2f47d27ac  jnz 0x00007CC2F47D3863
00007cc2f47d27b2  movq xmm15, qword ptr [r15+0x230]
00007cc2f47d27bb  vmovaps [rsp+0x100], xmm15
00007cc2f47d27c4  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d27ca  vmovaps [rsp+0x110], xmm1
00007cc2f47d27d3  vmovaps xmm1, [rsp+0xE0]
00007cc2f47d27dc  vmovaps [rsp+0xE0], xmm13
00007cc2f47d27e5  movaps xmm14, xmm1
00007cc2f47d27e9  mulpd xmm14, xmm15
00007cc2f47d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007cc2f47d27f4  ptest xmm13, xmm13
00007cc2f47d27fa  jnz 0x00007CC2F47D39A5
00007cc2f47d2800  vxorps xmm1, xmm1, xmm1
00007cc2f47d2804  vpbroadcastq xmm1, xmm1
00007cc2f47d2809  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d2812  vmovaps [rsp+0xD0], xmm1
00007cc2f47d281b  movaps xmm15, xmm12
00007cc2f47d281f  mulpd xmm15, xmm13
00007cc2f47d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007cc2f47d282a  ptest xmm1, xmm1
00007cc2f47d282f  jnz 0x00007CC2F47D3AE8
00007cc2f47d2835  movaps xmm1, xmm12
00007cc2f47d2839  mulpd xmm1, xmm10
00007cc2f47d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007cc2f47d2843  ptest xmm13, xmm13
00007cc2f47d2849  jnz 0x00007CC2F47D3C2C
00007cc2f47d284f  movaps xmm13, xmm12
00007cc2f47d2853  mulpd xmm13, xmm2
00007cc2f47d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007cc2f47d285e  ptest xmm10, xmm10
00007cc2f47d2864  jnz 0x00007CC2F47D3D6E
00007cc2f47d286a  vmovaps [rsp+0x120], xmm7
00007cc2f47d2873  vmovaps xmm12, [rsp+0x120]
00007cc2f47d287c  por xmm7, xmm12
00007cc2f47d2881  vmovaps xmm12, [rsp+0xE0]
00007cc2f47d288a  vmovaps xmm10, [rsp+0xE0]
00007cc2f47d2893  por xmm12, xmm10
00007cc2f47d2898  vmovaps xmm2, [rsp+0x100]
00007cc2f47d28a1  vpermilpd xmm2, xmm2, 0x00
00007cc2f47d28a7  vmovaps [rsp+0xE0], xmm1
00007cc2f47d28b0  vmovaps [rsp+0x120], xmm15
00007cc2f47d28b9  movaps xmm1, xmm10
00007cc2f47d28bd  mulpd xmm1, xmm2
00007cc2f47d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007cc2f47d28c6  ptest xmm15, xmm15
00007cc2f47d28cc  jnz 0x00007CC2F47D3EB1
00007cc2f47d28d2  xor eax, eax
00007cc2f47d28d4  mov r12d, 0x40
00007cc2f47d28da  mov r11d, 0x200
00007cc2f47d28e0  cmp r12, r11
00007cc2f47d28e3  cmc
00007cc2f47d28e4  lahf
00007cc2f47d28e5  seto al
00007cc2f47d28e8  mov [r15+0x108], eax
00007cc2f47d28ef  vmovaps xmm10, [rsp+0x110]
00007cc2f47d28f8  vmovaps xmm2, [rsp+0xD0]
00007cc2f47d2901  vmovaps [rsp+0xD0], xmm1
00007cc2f47d290a  movaps xmm15, xmm10
00007cc2f47d290e  addpd xmm15, xmm2
00007cc2f47d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007cc2f47d2919  ptest xmm1, xmm1
00007cc2f47d291e  jnz 0x00007CC2F47D3FF2
00007cc2f47d2924  vmovaps xmm10, [rsp+0x120]
00007cc2f47d292d  vmovaps [rsp+0x110], xmm15
00007cc2f47d2936  vmovaps xmm15, [rsp+0xC0]
00007cc2f47d293f  vmovaps [rsp+0xC0], xmm14
00007cc2f47d2948  movaps xmm1, xmm10
00007cc2f47d294c  addpd xmm1, xmm15
00007cc2f47d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007cc2f47d2956  ptest xmm14, xmm14
00007cc2f47d295c  jnz 0x00007CC2F47D4135
00007cc2f47d2962  vmovaps xmm10, [rsp+0xE0]
00007cc2f47d296b  vmovaps [rsp+0xE0], xmm1
00007cc2f47d2974  movaps xmm14, xmm10
00007cc2f47d2978  addpd xmm14, xmm15
00007cc2f47d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007cc2f47d2983  ptest xmm1, xmm1
00007cc2f47d2988  jnz 0x00007CC2F47D4277
00007cc2f47d298e  vmovaps xmm1, [rsp+0x10]
00007cc2f47d2994  vmovaps xmm15, [rsp+0x10]
00007cc2f47d299a  por xmm1, xmm15
00007cc2f47d299f  vmovaps xmm15, [rsp+0x20]
00007cc2f47d29a5  vmovaps xmm10, [rsp+0x20]
00007cc2f47d29ab  por xmm15, xmm10
00007cc2f47d29b0  vmovaps [rsp+0x10], xmm5
00007cc2f47d29b6  vmovaps xmm10, [rsp+0x10]
00007cc2f47d29bc  por xmm5, xmm10
00007cc2f47d29c1  vmovaps [rsp+0x10], xmm11
00007cc2f47d29c7  vmovaps xmm10, [rsp+0x10]
00007cc2f47d29cd  por xmm11, xmm10
00007cc2f47d29d2  vmovaps [rsp+0x10], xmm4
00007cc2f47d29d8  vmovaps xmm10, [rsp+0x10]
00007cc2f47d29de  por xmm4, xmm10
00007cc2f47d29e3  vmovaps [rsp+0x10], xmm8
00007cc2f47d29e9  vmovaps xmm10, [rsp+0x10]
00007cc2f47d29ef  por xmm8, xmm10
00007cc2f47d29f4  vmovaps xmm10, [rsp+0xF0]
00007cc2f47d29fd  vmovaps [rsp+0x10], xmm1
00007cc2f47d2a03  vmovaps xmm1, [rsp+0xF0]
00007cc2f47d2a0c  por xmm10, xmm1
00007cc2f47d2a11  lea rax, [r14+0xA0]
00007cc2f47d2a18  movups xmm1, [r13+rax*1]
00007cc2f47d2a1e  lea rax, [r14+0xB0]
00007cc2f47d2a25  vmovaps [rsp+0x20], xmm1
00007cc2f47d2a2b  movups xmm1, [r13+rax*1]
00007cc2f47d2a31  vmovaps [rsp+0xF0], xmm1
00007cc2f47d2a3a  vmovaps [rsp+0x120], xmm15
00007cc2f47d2a43  movaps xmm1, xmm13
00007cc2f47d2a47  addpd xmm1, xmm2
00007cc2f47d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007cc2f47d2a50  ptest xmm15, xmm15
00007cc2f47d2a56  jnz 0x00007CC2F47D43CF
00007cc2f47d2a5c  lea rax, [r14+0xF0]
00007cc2f47d2a63  movups xmm15, [r13+rax*1]
00007cc2f47d2a69  vmovaps xmm2, [rsp+0xE0]
00007cc2f47d2a72  vmovaps [rsp+0xE0], xmm1
00007cc2f47d2a7b  vmovaps xmm1, [rsp+0xD0]
00007cc2f47d2a84  vmovaps [rsp+0xD0], xmm15
00007cc2f47d2a8d  movaps xmm13, xmm2
00007cc2f47d2a91  addpd xmm13, xmm1
00007cc2f47d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007cc2f47d2a9c  ptest xmm15, xmm15
00007cc2f47d2aa2  jnz 0x00007CC2F47D451A
00007cc2f47d2aa8  vmovaps xmm15, [rsp+0xC0]
00007cc2f47d2ab1  movaps xmm1, xmm14
00007cc2f47d2ab5  addpd xmm1, xmm15
00007cc2f47d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007cc2f47d2abf  ptest xmm2, xmm2
00007cc2f47d2ac4  jnz 0x00007CC2F47D465C
00007cc2f47d2aca  vmovaps xmm15, [rsp+0x100]
00007cc2f47d2ad3  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d2ad9  vmovaps xmm2, [rsp+0xF0]
00007cc2f47d2ae2  vmovaps [rsp+0xC0], xmm1
00007cc2f47d2aeb  movaps xmm14, xmm2
00007cc2f47d2aef  mulpd xmm14, xmm15
00007cc2f47d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007cc2f47d2afa  ptest xmm1, xmm1
00007cc2f47d2aff  jnz 0x00007CC2F47D479E
00007cc2f47d2b05  vmovaps xmm1, [rsp+0xA0]
00007cc2f47d2b0e  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d2b14  vmovaps xmm2, [rsp+0xD0]
00007cc2f47d2b1d  vmovaps [rsp+0xD0], xmm14
00007cc2f47d2b26  movaps xmm15, xmm2
00007cc2f47d2b2a  mulpd xmm15, xmm1
00007cc2f47d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007cc2f47d2b35  ptest xmm14, xmm14
00007cc2f47d2b3b  jnz 0x00007CC2F47D48E1
00007cc2f47d2b41  lea rax, [r14+0xE0]
00007cc2f47d2b48  movups xmm1, [r13+rax*1]
00007cc2f47d2b4e  vmovaps xmm14, [rsp+0x100]
00007cc2f47d2b57  vpermilpd xmm14, xmm14, 0x00
00007cc2f47d2b5d  vmovaps [rsp+0xF0], xmm1
00007cc2f47d2b66  vmovaps xmm1, [rsp+0x20]
00007cc2f47d2b6c  vmovaps [rsp+0x20], xmm15
00007cc2f47d2b72  movaps xmm2, xmm1
00007cc2f47d2b75  mulpd xmm2, xmm14
00007cc2f47d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007cc2f47d2b7f  ptest xmm15, xmm15
00007cc2f47d2b85  jnz 0x00007CC2F47D4A2D
00007cc2f47d2b8b  vmovaps [rsp+0x100], xmm10
00007cc2f47d2b94  vmovaps xmm1, [rsp+0x100]
00007cc2f47d2b9d  por xmm10, xmm1
00007cc2f47d2ba2  movaps [r15+0x300], xmm10
00007cc2f47d2baa  vmovaps [rsp+0x100], xmm8
00007cc2f47d2bb3  vmovaps xmm1, [rsp+0x100]
00007cc2f47d2bbc  por xmm8, xmm1
00007cc2f47d2bc1  movaps [r15+0x190], xmm8
00007cc2f47d2bc9  vmovaps xmm1, [rsp+0xA0]
00007cc2f47d2bd2  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d2bd8  vmovaps xmm14, [rsp+0xF0]
00007cc2f47d2be1  vmovaps [rsp+0xF0], xmm13
00007cc2f47d2bea  movaps xmm15, xmm14
00007cc2f47d2bee  mulpd xmm15, xmm1
00007cc2f47d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007cc2f47d2bf9  ptest xmm13, xmm13
00007cc2f47d2bff  jnz 0x00007CC2F47D4B6E
00007cc2f47d2c05  lea rax, [r14+0x90]
00007cc2f47d2c0c  movups xmm1, [r13+rax*1]
00007cc2f47d2c12  vmovaps [rsp+0x100], xmm4
00007cc2f47d2c1b  vmovaps xmm14, [rsp+0x100]
00007cc2f47d2c24  por xmm4, xmm14
00007cc2f47d2c29  movaps [r15+0x1C0], xmm4
00007cc2f47d2c31  vmovaps [rsp+0x100], xmm11
00007cc2f47d2c3a  vmovaps xmm14, [rsp+0x100]
00007cc2f47d2c43  por xmm11, xmm14
00007cc2f47d2c48  movaps [r15+0x200], xmm11
00007cc2f47d2c50  vmovaps [rsp+0x100], xmm5
00007cc2f47d2c59  vmovaps xmm14, [rsp+0x100]
00007cc2f47d2c62  por xmm5, xmm14
00007cc2f47d2c67  movaps [r15+0x2D0], xmm5
00007cc2f47d2c6f  vmovaps xmm14, [rsp+0x120]
00007cc2f47d2c78  vmovaps xmm13, [rsp+0x120]
00007cc2f47d2c81  por xmm14, xmm13
00007cc2f47d2c86  movaps [r15+0x2E0], xmm14
00007cc2f47d2c8e  vmovaps [rsp+0x100], xmm1
00007cc2f47d2c97  vmovaps xmm1, [rsp+0x110]
00007cc2f47d2ca0  vmovaps [rsp+0x110], xmm15
00007cc2f47d2ca9  vmovaps xmm15, [rsp+0xD0]
00007cc2f47d2cb2  vmovaps [rsp+0xD0], xmm14
00007cc2f47d2cbb  movaps xmm13, xmm1
00007cc2f47d2cbf  addpd xmm13, xmm15
00007cc2f47d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007cc2f47d2cca  ptest xmm14, xmm14
00007cc2f47d2cd0  jnz 0x00007CC2F47D4CBB
00007cc2f47d2cd6  vmovaps xmm1, [rsp+0xA0]
00007cc2f47d2cdf  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d2ce5  vmovaps xmm14, [rsp+0x100]
00007cc2f47d2cee  vmovaps [rsp+0x100], xmm13
00007cc2f47d2cf7  movaps xmm15, xmm14
00007cc2f47d2cfb  mulpd xmm15, xmm1
00007cc2f47d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007cc2f47d2d06  ptest xmm13, xmm13
00007cc2f47d2d0c  jnz 0x00007CC2F47D4DFE
00007cc2f47d2d12  lea rax, [r14+0x80]
00007cc2f47d2d19  movups xmm1, [r13+rax*1]
00007cc2f47d2d1f  vmovaps xmm13, [rsp+0xE0]
00007cc2f47d2d28  vmovaps [rsp+0xE0], xmm1
00007cc2f47d2d31  movaps xmm14, xmm13
00007cc2f47d2d35  addpd xmm14, xmm2
00007cc2f47d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007cc2f47d2d40  ptest xmm1, xmm1
00007cc2f47d2d45  jnz 0x00007CC2F47D4F4B
00007cc2f47d2d4b  vmovaps xmm13, [rsp+0xF0]
00007cc2f47d2d54  vmovaps xmm2, [rsp+0x20]
00007cc2f47d2d5a  vmovaps [rsp+0x20], xmm15
00007cc2f47d2d60  movaps xmm1, xmm13
00007cc2f47d2d64  addpd xmm1, xmm2
00007cc2f47d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007cc2f47d2d6d  ptest xmm15, xmm15
00007cc2f47d2d73  jnz 0x00007CC2F47D508E
00007cc2f47d2d79  vmovaps xmm15, [rsp+0x10]
00007cc2f47d2d7f  vmovaps xmm13, [rsp+0x10]
00007cc2f47d2d85  por xmm15, xmm13
00007cc2f47d2d8a  movaps [r15+0x2F0], xmm15
00007cc2f47d2d92  vmovaps xmm13, [rsp+0xA0]
00007cc2f47d2d9b  vpermilpd xmm13, xmm13, 0x00
00007cc2f47d2da1  vmovaps [rsp+0x10], xmm1
00007cc2f47d2da7  vmovaps xmm1, [rsp+0xE0]
00007cc2f47d2db0  vmovaps [rsp+0xA0], xmm15
00007cc2f47d2db9  movaps xmm2, xmm1
00007cc2f47d2dbc  mulpd xmm2, xmm13
00007cc2f47d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007cc2f47d2dc6  ptest xmm15, xmm15
00007cc2f47d2dcc  jnz 0x00007CC2F47D51CF
00007cc2f47d2dd2  lea rax, [r14+0xD0]
00007cc2f47d2dd9  movups xmm1, [r13+rax*1]
00007cc2f47d2ddf  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d2de8  vmovaps [rsp+0xC0], xmm1
00007cc2f47d2df1  vmovaps xmm1, [rsp+0x110]
00007cc2f47d2dfa  vmovaps [rsp+0xE0], xmm14
00007cc2f47d2e03  movaps xmm15, xmm13
00007cc2f47d2e07  addpd xmm15, xmm1
00007cc2f47d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007cc2f47d2e12  ptest xmm14, xmm14
00007cc2f47d2e18  jnz 0x00007CC2F47D531A
00007cc2f47d2e1e  vmovaps xmm1, [rsp+0xB0]
00007cc2f47d2e27  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d2e2d  movaps xmm14, xmm11
00007cc2f47d2e31  mulpd xmm14, xmm1
00007cc2f47d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007cc2f47d2e3c  ptest xmm13, xmm13
00007cc2f47d2e42  jnz 0x00007CC2F47D545D
00007cc2f47d2e48  movaps [r15+0x260], xmm14
00007cc2f47d2e50  vxorps xmm1, xmm1, xmm1
00007cc2f47d2e54  vpbroadcastq xmm1, xmm1
00007cc2f47d2e59  movaps [r15+0x1B0], xmm1
00007cc2f47d2e61  vmovaps xmm1, [rsp+0xB0]
00007cc2f47d2e6a  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d2e70  vmovaps xmm11, [rsp+0xC0]
00007cc2f47d2e79  vmovaps [rsp+0xC0], xmm15
00007cc2f47d2e82  movaps xmm13, xmm11
00007cc2f47d2e86  mulpd xmm13, xmm1
00007cc2f47d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007cc2f47d2e91  ptest xmm15, xmm15
00007cc2f47d2e97  jnz 0x00007CC2F47D55A0
00007cc2f47d2e9d  lea rax, [r14+0xC0]
00007cc2f47d2ea4  movups xmm1, [r13+rax*1]
00007cc2f47d2eaa  vmovaps xmm11, [rsp+0x100]
00007cc2f47d2eb3  vmovaps [rsp+0xF0], xmm1
00007cc2f47d2ebc  vmovaps xmm1, [rsp+0x20]
00007cc2f47d2ec2  vmovaps [rsp+0x20], xmm14
00007cc2f47d2ec8  movaps xmm15, xmm11
00007cc2f47d2ecc  addpd xmm15, xmm1
00007cc2f47d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007cc2f47d2ed7  ptest xmm14, xmm14
00007cc2f47d2edd  jnz 0x00007CC2F47D56ED
00007cc2f47d2ee3  vmovaps [rsp+0x100], xmm9
00007cc2f47d2eec  vmovaps xmm1, [rsp+0x100]
00007cc2f47d2ef5  por xmm9, xmm1
00007cc2f47d2efa  movaps [r15+0x270], xmm9
00007cc2f47d2f02  vmovaps [rsp+0x100], xmm6
00007cc2f47d2f0b  vmovaps xmm1, [rsp+0x100]
00007cc2f47d2f14  por xmm6, xmm1
00007cc2f47d2f18  movaps [r15+0x1A0], xmm6
00007cc2f47d2f20  vmovaps xmm14, [rsp+0xB0]
00007cc2f47d2f29  vpermilpd xmm14, xmm14, 0x00
00007cc2f47d2f2f  vmovaps xmm6, [rsp+0xF0]
00007cc2f47d2f38  vmovaps [rsp+0xF0], xmm1
00007cc2f47d2f41  movaps xmm11, xmm6
00007cc2f47d2f45  mulpd xmm11, xmm14
00007cc2f47d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007cc2f47d2f50  ptest xmm1, xmm1
00007cc2f47d2f55  jnz 0x00007CC2F47D5830
00007cc2f47d2f5b  lea rax, [r14+0x20]
00007cc2f47d2f5f  movups xmm1, [r13+rax*1]
00007cc2f47d2f65  movaps [r15+0x110], xmm1
00007cc2f47d2f6d  vmovaps xmm6, [rsp+0xE0]
00007cc2f47d2f76  vmovaps [rsp+0xE0], xmm1
00007cc2f47d2f7f  movaps xmm14, xmm6
00007cc2f47d2f83  addpd xmm14, xmm2
00007cc2f47d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007cc2f47d2f8e  ptest xmm1, xmm1
00007cc2f47d2f93  jnz 0x00007CC2F47D597D
00007cc2f47d2f99  vmovaps xmm1, [rsp+0xB0]
00007cc2f47d2fa2  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d2fa8  movaps xmm6, xmm5
00007cc2f47d2fab  mulpd xmm6, xmm1
00007cc2f47d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007cc2f47d2fb4  ptest xmm2, xmm2
00007cc2f47d2fb9  jnz 0x00007CC2F47D5ABF
00007cc2f47d2fbf  vmovaps xmm5, [rsp+0x10]
00007cc2f47d2fc5  movaps xmm1, xmm5
00007cc2f47d2fc8  addpd xmm1, xmm13
00007cc2f47d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007cc2f47d2fd2  ptest xmm2, xmm2
00007cc2f47d2fd7  jnz 0x00007CC2F47D5BFF
00007cc2f47d2fdd  vmovaps xmm13, [rsp+0x80]
00007cc2f47d2fe6  vpermilpd xmm13, xmm13, 0x00
00007cc2f47d2fec  vmovaps xmm2, [rsp+0xE0]
00007cc2f47d2ff5  vmovaps [rsp+0x10], xmm1
00007cc2f47d2ffb  movaps xmm5, xmm2
00007cc2f47d2ffe  mulpd xmm5, xmm13
00007cc2f47d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007cc2f47d3008  ptest xmm1, xmm1
00007cc2f47d300d  jnz 0x00007CC2F47D5D40
00007cc2f47d3013  vmovaps xmm1, [rsp+0x80]
00007cc2f47d301c  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d3022  movaps xmm13, xmm10
00007cc2f47d3026  mulpd xmm13, xmm1
00007cc2f47d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007cc2f47d3031  ptest xmm2, xmm2
00007cc2f47d3036  jnz 0x00007CC2F47D5E81
00007cc2f47d303c  vmovaps xmm10, [rsp+0x20]
00007cc2f47d3042  movaps xmm1, xmm15
00007cc2f47d3046  addpd xmm1, xmm10
00007cc2f47d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007cc2f47d3050  ptest xmm2, xmm2
00007cc2f47d3055  jnz 0x00007CC2F47D5FC4
00007cc2f47d305b  vmovaps xmm10, [rsp+0xC0]
00007cc2f47d3064  movaps xmm15, xmm10
00007cc2f47d3068  addpd xmm15, xmm11
00007cc2f47d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007cc2f47d3073  ptest xmm2, xmm2
00007cc2f47d3078  jnz 0x00007CC2F47D6106
00007cc2f47d307e  vmovaps xmm11, [rsp+0x80]
00007cc2f47d3087  vpermilpd xmm11, xmm11, 0x00
00007cc2f47d308d  vmovaps xmm2, [rsp+0xD0]
00007cc2f47d3096  vmovaps [rsp+0x20], xmm1
00007cc2f47d309c  movaps xmm10, xmm2
00007cc2f47d30a0  mulpd xmm10, xmm11
00007cc2f47d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007cc2f47d30ab  ptest xmm1, xmm1
00007cc2f47d30b0  jnz 0x00007CC2F47D624A
00007cc2f47d30b6  vmovaps xmm1, [rsp+0x80]
00007cc2f47d30bf  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d30c5  vmovaps xmm2, [rsp+0xA0]
00007cc2f47d30ce  vmovaps [rsp+0x80], xmm15
00007cc2f47d30d7  movaps xmm11, xmm2
00007cc2f47d30db  mulpd xmm11, xmm1
00007cc2f47d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007cc2f47d30e6  ptest xmm15, xmm15
00007cc2f47d30ec  jnz 0x00007CC2F47D638D
00007cc2f47d30f2  movaps xmm1, xmm14
00007cc2f47d30f6  addpd xmm1, xmm6
00007cc2f47d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007cc2f47d30ff  ptest xmm15, xmm15
00007cc2f47d3105  jnz 0x00007CC2F47D64CF
00007cc2f47d310b  vmovaps xmm14, [rsp+0x10]
00007cc2f47d3111  movaps xmm15, xmm14
00007cc2f47d3115  addpd xmm15, xmm5
00007cc2f47d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007cc2f47d3120  ptest xmm6, xmm6
00007cc2f47d3125  jnz 0x00007CC2F47D6610
00007cc2f47d312b  vmovaps xmm14, [rsp+0x90]
00007cc2f47d3134  vpermilpd xmm14, xmm14, 0x00
00007cc2f47d313a  movaps xmm6, xmm9
00007cc2f47d313e  mulpd xmm6, xmm14
00007cc2f47d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007cc2f47d3148  ptest xmm5, xmm5
00007cc2f47d314d  jnz 0x00007CC2F47D6753
00007cc2f47d3153  vmovaps xmm9, [rsp+0x80]
00007cc2f47d315c  movaps xmm14, xmm9
00007cc2f47d3160  addpd xmm14, xmm13
00007cc2f47d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007cc2f47d316b  ptest xmm5, xmm5
00007cc2f47d3170  jnz 0x00007CC2F47D6895
00007cc2f47d3176  vmovaps xmm9, [rsp+0x20]
00007cc2f47d317c  movaps xmm13, xmm9
00007cc2f47d3180  addpd xmm13, xmm10
00007cc2f47d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007cc2f47d318b  ptest xmm5, xmm5
00007cc2f47d3190  jnz 0x00007CC2F47D69D9
00007cc2f47d3196  vmovaps [rsp+0x10], xmm12
00007cc2f47d319c  vmovaps xmm10, [rsp+0x10]
00007cc2f47d31a2  por xmm12, xmm10
00007cc2f47d31a7  movaps [r15+0x250], xmm12
00007cc2f47d31af  vmovaps [rsp+0x10], xmm7
00007cc2f47d31b5  vmovaps xmm12, [rsp+0x10]
00007cc2f47d31bb  por xmm7, xmm12
00007cc2f47d31c0  movaps [r15+0x2A0], xmm7
00007cc2f47d31c8  vmovaps [rsp+0x10], xmm3
00007cc2f47d31ce  vmovaps xmm12, [rsp+0x10]
00007cc2f47d31d4  por xmm3, xmm12
00007cc2f47d31d9  movaps [r15+0x1D0], xmm3
00007cc2f47d31e1  lea rax, [r14+0x40]
00007cc2f47d31e5  movups xmm12, [r13+rax*1]
00007cc2f47d31eb  movaps [r15+0x2C0], xmm12
00007cc2f47d31f3  vmovaps xmm10, [rsp+0x90]
00007cc2f47d31fc  vpermilpd xmm10, xmm10, 0x00
00007cc2f47d3202  movaps xmm9, xmm8
00007cc2f47d3206  mulpd xmm9, xmm10
00007cc2f47d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007cc2f47d3211  ptest xmm5, xmm5
00007cc2f47d3216  jnz 0x00007CC2F47D6B27
00007cc2f47d321c  movaps xmm10, xmm1
00007cc2f47d3220  addpd xmm10, xmm11
00007cc2f47d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007cc2f47d322b  ptest xmm8, xmm8
00007cc2f47d3231  jnz 0x00007CC2F47D6C6B
00007cc2f47d3237  movaps xmm1, xmm15
00007cc2f47d323b  addpd xmm1, xmm6
00007cc2f47d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007cc2f47d3244  ptest xmm11, xmm11
00007cc2f47d324a  jnz 0x00007CC2F47D6DAE
00007cc2f47d3250  vmovaps xmm15, [rsp+0x90]
00007cc2f47d3259  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d325f  movaps xmm11, xmm12
00007cc2f47d3263  mulpd xmm11, xmm15
00007cc2f47d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007cc2f47d326e  ptest xmm8, xmm8
00007cc2f47d3274  jnz 0x00007CC2F47D6EEF
00007cc2f47d327a  vmovaps xmm15, [rsp+0x90]
00007cc2f47d3283  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d3289  vmovaps xmm8, [rsp+0x50]
00007cc2f47d328f  movaps xmm12, xmm8
00007cc2f47d3293  mulpd xmm12, xmm15
00007cc2f47d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007cc2f47d329e  ptest xmm6, xmm6
00007cc2f47d32a3  jnz 0x00007CC2F47D7033
00007cc2f47d32a9  vmovaps xmm15, [rsp+0x30]
00007cc2f47d32af  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d32b5  movaps xmm8, xmm7
00007cc2f47d32b9  mulpd xmm8, xmm15
00007cc2f47d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007cc2f47d32c4  ptest xmm6, xmm6
00007cc2f47d32c9  jnz 0x00007CC2F47D7177
00007cc2f47d32cf  movaps xmm15, xmm14
00007cc2f47d32d3  addpd xmm15, xmm9
00007cc2f47d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007cc2f47d32de  ptest xmm7, xmm7
00007cc2f47d32e3  jnz 0x00007CC2F47D72BA
00007cc2f47d32e9  vmovaps xmm14, [rsp+0x30]
00007cc2f47d32ef  vpermilpd xmm14, xmm14, 0x00
00007cc2f47d32f5  vmovaps xmm7, [rsp+0xF0]
00007cc2f47d32fe  movaps xmm9, xmm7
00007cc2f47d3302  mulpd xmm9, xmm14
00007cc2f47d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007cc2f47d330d  ptest xmm6, xmm6
00007cc2f47d3312  jnz 0x00007CC2F47D73FE
00007cc2f47d3318  movaps xmm14, xmm13
00007cc2f47d331c  addpd xmm14, xmm11
00007cc2f47d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007cc2f47d3327  ptest xmm7, xmm7
00007cc2f47d332c  jnz 0x00007CC2F47D7541
00007cc2f47d3332  vmovaps xmm13, [rsp+0x30]
00007cc2f47d3338  vpermilpd xmm13, xmm13, 0x00
00007cc2f47d333e  vmovaps xmm7, [rsp+0x60]
00007cc2f47d3344  movaps xmm11, xmm7
00007cc2f47d3348  mulpd xmm11, xmm13
00007cc2f47d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007cc2f47d3353  ptest xmm6, xmm6
00007cc2f47d3358  jnz 0x00007CC2F47D7685
00007cc2f47d335e  movaps xmm13, xmm10
00007cc2f47d3362  addpd xmm13, xmm12
00007cc2f47d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007cc2f47d336d  ptest xmm7, xmm7
00007cc2f47d3372  jnz 0x00007CC2F47D77C8
00007cc2f47d3378  vmovaps xmm12, [rsp+0x30]
00007cc2f47d337e  vpermilpd xmm12, xmm12, 0x00
00007cc2f47d3384  vmovaps xmm7, [rsp+0x70]
00007cc2f47d338a  movaps xmm10, xmm7
00007cc2f47d338e  mulpd xmm10, xmm12
00007cc2f47d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007cc2f47d3399  ptest xmm6, xmm6
00007cc2f47d339e  jnz 0x00007CC2F47D790C
00007cc2f47d33a4  movaps xmm12, xmm1
00007cc2f47d33a8  addpd xmm12, xmm8
00007cc2f47d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007cc2f47d33b3  ptest xmm7, xmm7
00007cc2f47d33b8  jnz 0x00007CC2F47D7A4F
00007cc2f47d33be  lea rax, [r14+0x70]
00007cc2f47d33c2  movups xmm1, [r13+rax*1]
00007cc2f47d33c8  movaps [r15+0x240], xmm1
00007cc2f47d33d0  movaps xmm8, xmm15
00007cc2f47d33d4  addpd xmm8, xmm9
00007cc2f47d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007cc2f47d33df  ptest xmm7, xmm7
00007cc2f47d33e4  jnz 0x00007CC2F47D7B9C
00007cc2f47d33ea  movaps [r15+0x170], xmm8
00007cc2f47d33f2  vmovaps xmm15, [rsp+0x40]
00007cc2f47d33f8  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d33fe  movaps xmm9, xmm1
00007cc2f47d3402  mulpd xmm9, xmm15
00007cc2f47d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007cc2f47d340d  ptest xmm7, xmm7
00007cc2f47d3412  jnz 0x00007CC2F47D7CE0
00007cc2f47d3418  vmovaps xmm1, [rsp+0x40]
00007cc2f47d341e  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d3424  movaps xmm15, xmm4
00007cc2f47d3428  mulpd xmm15, xmm1
00007cc2f47d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007cc2f47d3433  ptest xmm7, xmm7
00007cc2f47d3438  jnz 0x00007CC2F47D7E23
00007cc2f47d343e  movaps [r15+0x180], xmm15
00007cc2f47d3446  movaps xmm1, xmm14
00007cc2f47d344a  addpd xmm1, xmm11
00007cc2f47d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007cc2f47d3454  ptest xmm7, xmm7
00007cc2f47d3459  jnz 0x00007CC2F47D7F65
00007cc2f47d345f  movaps [r15+0x210], xmm1
00007cc2f47d3467  movups xmm14, [r13+r14*1]
00007cc2f47d346d  lea rax, [r14+0x10]
00007cc2f47d3471  movups xmm11, [r13+rax*1]
00007cc2f47d3477  movaps [r15+0x230], xmm11
00007cc2f47d347f  movaps xmm7, xmm13
00007cc2f47d3483  addpd xmm7, xmm10
00007cc2f47d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2f47d348d  ptest xmm6, xmm6
00007cc2f47d3492  jnz 0x00007CC2F47D80BB
00007cc2f47d3498  movaps [r15+0x130], xmm7
00007cc2f47d34a0  vmovaps xmm13, [rsp+0x40]
00007cc2f47d34a6  vpermilpd xmm13, xmm13, 0x00
00007cc2f47d34ac  movaps xmm10, xmm11
00007cc2f47d34b0  mulpd xmm10, xmm13
00007cc2f47d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007cc2f47d34bb  ptest xmm6, xmm6
00007cc2f47d34c0  jnz 0x00007CC2F47D81FD
00007cc2f47d34c6  movaps [r15+0x220], xmm10
00007cc2f47d34ce  vmovaps xmm13, [rsp+0x40]
00007cc2f47d34d4  vpermilpd xmm13, xmm13, 0x00
00007cc2f47d34da  movaps xmm11, xmm14
00007cc2f47d34de  mulpd xmm11, xmm13
00007cc2f47d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007cc2f47d34e9  ptest xmm6, xmm6
00007cc2f47d34ee  jnz 0x00007CC2F47D8341
00007cc2f47d34f4  movaps xmm14, xmm12
00007cc2f47d34f8  addpd xmm14, xmm9
00007cc2f47d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007cc2f47d3503  ptest xmm13, xmm13
00007cc2f47d3509  jnz 0x00007CC2F47D8485
00007cc2f47d350f  movaps [r15+0x140], xmm14
00007cc2f47d3517  movaps xmm13, xmm8
00007cc2f47d351b  addpd xmm13, xmm15
00007cc2f47d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2f47d3526  ptest xmm12, xmm12
00007cc2f47d352c  jnz 0x00007CC2F47D85C9
00007cc2f47d3532  movaps [r15+0x150], xmm13
00007cc2f47d353a  movaps xmm15, xmm1
00007cc2f47d353e  addpd xmm15, xmm10
00007cc2f47d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007cc2f47d3549  ptest xmm12, xmm12
00007cc2f47d354f  jnz 0x00007CC2F47D870D
00007cc2f47d3555  movaps [r15+0x160], xmm15
00007cc2f47d355d  movaps xmm1, xmm7
00007cc2f47d3560  addpd xmm1, xmm11
00007cc2f47d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007cc2f47d356a  ptest xmm12, xmm12
00007cc2f47d3570  jnz 0x00007CC2F47D8850
00007cc2f47d3576  movaps [r15+0x120], xmm1
00007cc2f47d357e  mov eax, 0x432200
00007cc2f47d3583  movups [r13+rax*1], xmm14
00007cc2f47d3589  mov eax, 0x432210
00007cc2f47d358e  movups [r13+rax*1], xmm13
00007cc2f47d3594  mov eax, 0x432220
00007cc2f47d3599  movups [r13+rax*1], xmm15
00007cc2f47d359f  mov eax, 0x432230
00007cc2f47d35a4  movups [r13+rax*1], xmm1
00007cc2f47d35aa  mov eax, [r15+0x108]
00007cc2f47d35b1  sahf
00007cc2f47d35b2  jnz 0x00007CC2F47D35E4
00007cc2f47d35b4  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d35bc  jz 0x00007CC2F47DEAE0
00007cc2f47d35c2  nop [rax+rax*1], ax
00007cc2f47d35cb  nop [rax+rax*1], eax
00007cc2f47d35d3  mov eax, 0x4106D0
00007cc2f47d35d8  mov [r15+0x100], rax
00007cc2f47d35df  jmp 0x00007CC2F45FE110
00007cc2f47d35e4  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d35ec  jz 0x00007CC2F47D89C0
00007cc2f47d35f2  nop [rax+rax*1], ax
00007cc2f47d35fb  nop [rax+rax*1], eax
00007cc2f47d3603  mov eax, 0x410504
00007cc2f47d3608  mov [r15+0x100], rax
00007cc2f47d360f  jmp 0x00007CC2F45FE110
00007cc2f47d3614  int3
00007cc2f47d3615  call 0x00007CC2F46D64F0
00007cc2f47d361a  jmp 0x00007CC2F47D2311
00007cc2f47d361f  call 0x00007CC2F46E5820
00007cc2f47d3624  jmp 0x00007CC2F47D231E
00007cc2f47d3629  call 0x00007CC2F46E3320
00007cc2f47d362e  jmp 0x00007CC2F47D2332
00007cc2f47d3633  call 0x00007CC2F46E20A0
00007cc2f47d3638  jmp 0x00007CC2F47D233C
00007cc2f47d363d  call 0x00007CC2F4609D70
00007cc2f47d3642  jmp 0x00007CC2F47D234A
00007cc2f47d3647  call 0x00007CC2F46DFBC0
00007cc2f47d364c  jmp 0x00007CC2F47D2354
00007cc2f47d3651  call 0x00007CC2F46C4740
00007cc2f47d3656  jmp 0x00007CC2F47D2368
00007cc2f47d365b  call 0x00007CC2F46B5400
00007cc2f47d3660  jmp 0x00007CC2F47D2375
00007cc2f47d3665  call 0x00007CC2F46B52F0
00007cc2f47d366a  jmp 0x00007CC2F47D2382
00007cc2f47d366f  call 0x00007CC2F46C4620
00007cc2f47d3674  jmp 0x00007CC2F47D238F
00007cc2f47d3679  call 0x00007CC2F46BD750
00007cc2f47d367e  jmp 0x00007CC2F47D239C
00007cc2f47d3683  call 0x00007CC2F46BC4E0
00007cc2f47d3688  jmp 0x00007CC2F47D23A9
00007cc2f47d368d  call 0x00007CC2F46BB270
00007cc2f47d3692  jmp 0x00007CC2F47D23B6
00007cc2f47d3697  call 0x00007CC2F46BA000
00007cc2f47d369c  jmp 0x00007CC2F47D23C3
00007cc2f47d36a1  call 0x00007CC2F46C4740
00007cc2f47d36a6  jmp 0x00007CC2F47D23D0
00007cc2f47d36ab  call 0x00007CC2F46B5400
00007cc2f47d36b0  jmp 0x00007CC2F47D23DD
00007cc2f47d36b5  call 0x00007CC2F46B52F0
00007cc2f47d36ba  jmp 0x00007CC2F47D23EA
00007cc2f47d36bf  call 0x00007CC2F46C4620
00007cc2f47d36c4  jmp 0x00007CC2F47D23F7
00007cc2f47d36c9  call 0x00007CC2F46B8D90
00007cc2f47d36ce  jmp 0x00007CC2F47D2404
00007cc2f47d36d3  call 0x00007CC2F46B8A20
00007cc2f47d36d8  jmp 0x00007CC2F47D2411
00007cc2f47d36dd  call 0x00007CC2F46B77B0
00007cc2f47d36e2  jmp 0x00007CC2F47D241B
00007cc2f47d36e7  call 0x00007CC2F46B6550
00007cc2f47d36ec  jmp 0x00007CC2F47D2425
00007cc2f47d36f1  call 0x00007CC2F46B5400
00007cc2f47d36f6  jmp 0x00007CC2F47D2437
00007cc2f47d36fb  call 0x00007CC2F46C0FC0
00007cc2f47d3700  jmp 0x00007CC2F47D2441
00007cc2f47d3705  call 0x00007CC2F46B52F0
00007cc2f47d370a  jmp 0x00007CC2F47D244B
00007cc2f47d370f  call 0x00007CC2F46C0EA0
00007cc2f47d3714  jmp 0x00007CC2F47D2455
00007cc2f47d3719  call 0x00007CC2F46BFD50
00007cc2f47d371e  jmp 0x00007CC2F47D245F
00007cc2f47d3723  call 0x00007CC2F46B8EA0
00007cc2f47d3728  jmp 0x00007CC2F47D2469
00007cc2f47d372d  call 0x00007CC2F46BFC30
00007cc2f47d3732  jmp 0x00007CC2F47D2476
00007cc2f47d3737  call 0x00007CC2F46B8D90
00007cc2f47d373c  jmp 0x00007CC2F47D2483
00007cc2f47d3741  call 0x00007CC2F46B52F0
00007cc2f47d3746  jmp 0x00007CC2F47D2496
00007cc2f47d374b  call 0x00007CC2F46B52F0
00007cc2f47d3750  jmp 0x00007CC2F47D24A9
00007cc2f47d3755  call 0x00007CC2F46C0FC0
00007cc2f47d375a  jmp 0x00007CC2F47D24B6
00007cc2f47d375f  call 0x00007CC2F46C0FC0
00007cc2f47d3764  jmp 0x00007CC2F47D24C9
00007cc2f47d3769  call 0x00007CC2F46C0EA0
00007cc2f47d376e  jmp 0x00007CC2F47D24D6
00007cc2f47d3773  call 0x00007CC2F46B52F0
00007cc2f47d3778  jmp 0x00007CC2F47D24E9
00007cc2f47d377d  call 0x00007CC2F46B52F0
00007cc2f47d3782  jmp 0x00007CC2F47D24FC
00007cc2f47d3787  call 0x00007CC2F46B52F0
00007cc2f47d378c  jmp 0x00007CC2F47D250F
00007cc2f47d3791  call 0x00007CC2F46B52F0
00007cc2f47d3796  jmp 0x00007CC2F47D252A
00007cc2f47d379b  call 0x00007CC2F46B52F0
00007cc2f47d37a0  jmp 0x00007CC2F47D253D
00007cc2f47d37a5  call 0x00007CC2F46B5400
00007cc2f47d37aa  jmp 0x00007CC2F47D257E
00007cc2f47d37af  call 0x00007CC2F46C0FC0
00007cc2f47d37b4  jmp 0x00007CC2F47D258B
00007cc2f47d37b9  call 0x00007CC2F46B52F0
00007cc2f47d37be  jmp 0x00007CC2F47D2598
00007cc2f47d37c3  call 0x00007CC2F46C0EA0
00007cc2f47d37c8  jmp 0x00007CC2F47D25A5
00007cc2f47d37cd  call 0x00007CC2F45FF540
00007cc2f47d37d2  jmp 0x00007CC2F47D25C3
00007cc2f47d37d7  call 0x00007CC2F4608C20
00007cc2f47d37dc  jmp 0x00007CC2F47D25CD
00007cc2f47d37e1  call 0x00007CC2F46E21C0
00007cc2f47d37e6  jmp 0x00007CC2F47D25D3
00007cc2f47d37eb  call 0x00007CC2F45FF540
00007cc2f47d37f0  jmp 0x00007CC2F47D25E3
00007cc2f47d37f5  call 0x00007CC2F46C0370
00007cc2f47d37fa  jmp 0x00007CC2F47D2611
00007cc2f47d37ff  call 0x00007CC2F46BF100
00007cc2f47d3804  jmp 0x00007CC2F47D261A
00007cc2f47d3809  call 0x00007CC2F46C0370
00007cc2f47d380e  jmp 0x00007CC2F47D2674
00007cc2f47d3813  call 0x00007CC2F46BF100
00007cc2f47d3818  jmp 0x00007CC2F47D267D
00007cc2f47d381d  call 0x00007CC2F46C0370
00007cc2f47d3822  jmp 0x00007CC2F47D26C6
00007cc2f47d3827  call 0x00007CC2F46BF100
00007cc2f47d382c  jmp 0x00007CC2F47D26CF
00007cc2f47d3831  call 0x00007CC2F460B720
00007cc2f47d3836  jmp 0x00007CC2F47D2714
00007cc2f47d383b  call 0x00007CC2F46B47C0
00007cc2f47d3840  jmp 0x00007CC2F47D2727
00007cc2f47d3845  call 0x00007CC2F4608B00
00007cc2f47d384a  jmp 0x00007CC2F47D273E
00007cc2f47d384f  call 0x00007CC2F45FF430
00007cc2f47d3854  jmp 0x00007CC2F47D2751
00007cc2f47d3859  call 0x00007CC2F45FF430
00007cc2f47d385e  jmp 0x00007CC2F47D2764
00007cc2f47d3863  sub rsp, 0x08
00007cc2f47d3867  push rax
00007cc2f47d3868  push rcx
00007cc2f47d3869  push rdx
00007cc2f47d386a  push rdi
00007cc2f47d386b  push rsi
00007cc2f47d386c  push r8
00007cc2f47d386e  push r9
00007cc2f47d3870  push r10
00007cc2f47d3872  push r11
00007cc2f47d3874  sub rsp, 0xF0
00007cc2f47d387b  vmovaps [rsp], xmm0
00007cc2f47d3880  vmovaps [rsp+0x10], xmm2
00007cc2f47d3886  vmovaps [rsp+0x20], xmm3
00007cc2f47d388c  vmovaps [rsp+0x30], xmm4
00007cc2f47d3892  vmovaps [rsp+0x40], xmm5
00007cc2f47d3898  vmovaps [rsp+0x50], xmm6
00007cc2f47d389e  vmovaps [rsp+0x60], xmm7
00007cc2f47d38a4  vmovaps [rsp+0x70], xmm8
00007cc2f47d38aa  vmovaps [rsp+0x80], xmm9
00007cc2f47d38b3  vmovaps [rsp+0x90], xmm10
00007cc2f47d38bc  vmovaps [rsp+0xA0], xmm11
00007cc2f47d38c5  vmovaps [rsp+0xB0], xmm12
00007cc2f47d38ce  vmovaps [rsp+0xC0], xmm13
00007cc2f47d38d7  vmovaps [rsp+0xD0], xmm14
00007cc2f47d38e0  vmovaps [rsp+0xE0], xmm15
00007cc2f47d38e9  sub rsp, 0x30
00007cc2f47d38ed  movaps [rsp], xmm1
00007cc2f47d38f1  movaps [rsp+0x10], xmm12
00007cc2f47d38f7  movaps [rsp+0x20], xmm15
00007cc2f47d38fd  lea rdi, [rsp]
00007cc2f47d3901  mov esi, 0x00
00007cc2f47d3906  mov rax, 0x5990E710A530
00007cc2f47d3910  call rax
00007cc2f47d3912  movaps xmm1, [rsp]
00007cc2f47d3916  add rsp, 0x30
00007cc2f47d391a  vmovaps xmm0, [rsp]
00007cc2f47d391f  vmovaps xmm2, [rsp+0x10]
00007cc2f47d3925  vmovaps xmm3, [rsp+0x20]
00007cc2f47d392b  vmovaps xmm4, [rsp+0x30]
00007cc2f47d3931  vmovaps xmm5, [rsp+0x40]
00007cc2f47d3937  vmovaps xmm6, [rsp+0x50]
00007cc2f47d393d  vmovaps xmm7, [rsp+0x60]
00007cc2f47d3943  vmovaps xmm8, [rsp+0x70]
00007cc2f47d3949  vmovaps xmm9, [rsp+0x80]
00007cc2f47d3952  vmovaps xmm10, [rsp+0x90]
00007cc2f47d395b  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d3964  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d396d  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d3976  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d397f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d3988  add rsp, 0xF0
00007cc2f47d398f  pop r11
00007cc2f47d3991  pop r10
00007cc2f47d3993  pop r9
00007cc2f47d3995  pop r8
00007cc2f47d3997  pop rsi
00007cc2f47d3998  pop rdi
00007cc2f47d3999  pop rdx
00007cc2f47d399a  pop rcx
00007cc2f47d399b  pop rax
00007cc2f47d399c  add rsp, 0x08
00007cc2f47d39a0  jmp 0x00007CC2F47D27B2
00007cc2f47d39a5  sub rsp, 0x08
00007cc2f47d39a9  push rax
00007cc2f47d39aa  push rcx
00007cc2f47d39ab  push rdx
00007cc2f47d39ac  push rdi
00007cc2f47d39ad  push rsi
00007cc2f47d39ae  push r8
00007cc2f47d39b0  push r9
00007cc2f47d39b2  push r10
00007cc2f47d39b4  push r11
00007cc2f47d39b6  sub rsp, 0xF0
00007cc2f47d39bd  vmovaps [rsp], xmm0
00007cc2f47d39c2  vmovaps [rsp+0x10], xmm1
00007cc2f47d39c8  vmovaps [rsp+0x20], xmm2
00007cc2f47d39ce  vmovaps [rsp+0x30], xmm3
00007cc2f47d39d4  vmovaps [rsp+0x40], xmm4
00007cc2f47d39da  vmovaps [rsp+0x50], xmm5
00007cc2f47d39e0  vmovaps [rsp+0x60], xmm6
00007cc2f47d39e6  vmovaps [rsp+0x70], xmm7
00007cc2f47d39ec  vmovaps [rsp+0x80], xmm8
00007cc2f47d39f5  vmovaps [rsp+0x90], xmm9
00007cc2f47d39fe  vmovaps [rsp+0xA0], xmm10
00007cc2f47d3a07  vmovaps [rsp+0xB0], xmm11
00007cc2f47d3a10  vmovaps [rsp+0xC0], xmm12
00007cc2f47d3a19  vmovaps [rsp+0xD0], xmm13
00007cc2f47d3a22  vmovaps [rsp+0xE0], xmm15
00007cc2f47d3a2b  sub rsp, 0x30
00007cc2f47d3a2f  movaps [rsp], xmm14
00007cc2f47d3a34  movaps [rsp+0x10], xmm1
00007cc2f47d3a39  movaps [rsp+0x20], xmm15
00007cc2f47d3a3f  lea rdi, [rsp]
00007cc2f47d3a43  mov esi, 0x00
00007cc2f47d3a48  mov rax, 0x5990E710A530
00007cc2f47d3a52  call rax
00007cc2f47d3a54  movaps xmm14, [rsp]
00007cc2f47d3a59  add rsp, 0x30
00007cc2f47d3a5d  vmovaps xmm0, [rsp]
00007cc2f47d3a62  vmovaps xmm1, [rsp+0x10]
00007cc2f47d3a68  vmovaps xmm2, [rsp+0x20]
00007cc2f47d3a6e  vmovaps xmm3, [rsp+0x30]
00007cc2f47d3a74  vmovaps xmm4, [rsp+0x40]
00007cc2f47d3a7a  vmovaps xmm5, [rsp+0x50]
00007cc2f47d3a80  vmovaps xmm6, [rsp+0x60]
00007cc2f47d3a86  vmovaps xmm7, [rsp+0x70]
00007cc2f47d3a8c  vmovaps xmm8, [rsp+0x80]
00007cc2f47d3a95  vmovaps xmm9, [rsp+0x90]
00007cc2f47d3a9e  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d3aa7  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d3ab0  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d3ab9  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d3ac2  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d3acb  add rsp, 0xF0
00007cc2f47d3ad2  pop r11
00007cc2f47d3ad4  pop r10
00007cc2f47d3ad6  pop r9
00007cc2f47d3ad8  pop r8
00007cc2f47d3ada  pop rsi
00007cc2f47d3adb  pop rdi
00007cc2f47d3adc  pop rdx
00007cc2f47d3add  pop rcx
00007cc2f47d3ade  pop rax
00007cc2f47d3adf  add rsp, 0x08
00007cc2f47d3ae3  jmp 0x00007CC2F47D2800
00007cc2f47d3ae8  sub rsp, 0x08
00007cc2f47d3aec  push rax
00007cc2f47d3aed  push rcx
00007cc2f47d3aee  push rdx
00007cc2f47d3aef  push rdi
00007cc2f47d3af0  push rsi
00007cc2f47d3af1  push r8
00007cc2f47d3af3  push r9
00007cc2f47d3af5  push r10
00007cc2f47d3af7  push r11
00007cc2f47d3af9  sub rsp, 0xF0
00007cc2f47d3b00  vmovaps [rsp], xmm0
00007cc2f47d3b05  vmovaps [rsp+0x10], xmm1
00007cc2f47d3b0b  vmovaps [rsp+0x20], xmm2
00007cc2f47d3b11  vmovaps [rsp+0x30], xmm3
00007cc2f47d3b17  vmovaps [rsp+0x40], xmm4
00007cc2f47d3b1d  vmovaps [rsp+0x50], xmm5
00007cc2f47d3b23  vmovaps [rsp+0x60], xmm6
00007cc2f47d3b29  vmovaps [rsp+0x70], xmm7
00007cc2f47d3b2f  vmovaps [rsp+0x80], xmm8
00007cc2f47d3b38  vmovaps [rsp+0x90], xmm9
00007cc2f47d3b41  vmovaps [rsp+0xA0], xmm10
00007cc2f47d3b4a  vmovaps [rsp+0xB0], xmm11
00007cc2f47d3b53  vmovaps [rsp+0xC0], xmm12
00007cc2f47d3b5c  vmovaps [rsp+0xD0], xmm13
00007cc2f47d3b65  vmovaps [rsp+0xE0], xmm14
00007cc2f47d3b6e  sub rsp, 0x30
00007cc2f47d3b72  movaps [rsp], xmm15
00007cc2f47d3b77  movaps [rsp+0x10], xmm12
00007cc2f47d3b7d  movaps [rsp+0x20], xmm13
00007cc2f47d3b83  lea rdi, [rsp]
00007cc2f47d3b87  mov esi, 0x00
00007cc2f47d3b8c  mov rax, 0x5990E710A530
00007cc2f47d3b96  call rax
00007cc2f47d3b98  movaps xmm15, [rsp]
00007cc2f47d3b9d  add rsp, 0x30
00007cc2f47d3ba1  vmovaps xmm0, [rsp]
00007cc2f47d3ba6  vmovaps xmm1, [rsp+0x10]
00007cc2f47d3bac  vmovaps xmm2, [rsp+0x20]
00007cc2f47d3bb2  vmovaps xmm3, [rsp+0x30]
00007cc2f47d3bb8  vmovaps xmm4, [rsp+0x40]
00007cc2f47d3bbe  vmovaps xmm5, [rsp+0x50]
00007cc2f47d3bc4  vmovaps xmm6, [rsp+0x60]
00007cc2f47d3bca  vmovaps xmm7, [rsp+0x70]
00007cc2f47d3bd0  vmovaps xmm8, [rsp+0x80]
00007cc2f47d3bd9  vmovaps xmm9, [rsp+0x90]
00007cc2f47d3be2  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d3beb  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d3bf4  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d3bfd  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d3c06  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d3c0f  add rsp, 0xF0
00007cc2f47d3c16  pop r11
00007cc2f47d3c18  pop r10
00007cc2f47d3c1a  pop r9
00007cc2f47d3c1c  pop r8
00007cc2f47d3c1e  pop rsi
00007cc2f47d3c1f  pop rdi
00007cc2f47d3c20  pop rdx
00007cc2f47d3c21  pop rcx
00007cc2f47d3c22  pop rax
00007cc2f47d3c23  add rsp, 0x08
00007cc2f47d3c27  jmp 0x00007CC2F47D2835
00007cc2f47d3c2c  sub rsp, 0x08
00007cc2f47d3c30  push rax
00007cc2f47d3c31  push rcx
00007cc2f47d3c32  push rdx
00007cc2f47d3c33  push rdi
00007cc2f47d3c34  push rsi
00007cc2f47d3c35  push r8
00007cc2f47d3c37  push r9
00007cc2f47d3c39  push r10
00007cc2f47d3c3b  push r11
00007cc2f47d3c3d  sub rsp, 0xF0
00007cc2f47d3c44  vmovaps [rsp], xmm0
00007cc2f47d3c49  vmovaps [rsp+0x10], xmm2
00007cc2f47d3c4f  vmovaps [rsp+0x20], xmm3
00007cc2f47d3c55  vmovaps [rsp+0x30], xmm4
00007cc2f47d3c5b  vmovaps [rsp+0x40], xmm5
00007cc2f47d3c61  vmovaps [rsp+0x50], xmm6
00007cc2f47d3c67  vmovaps [rsp+0x60], xmm7
00007cc2f47d3c6d  vmovaps [rsp+0x70], xmm8
00007cc2f47d3c73  vmovaps [rsp+0x80], xmm9
00007cc2f47d3c7c  vmovaps [rsp+0x90], xmm10
00007cc2f47d3c85  vmovaps [rsp+0xA0], xmm11
00007cc2f47d3c8e  vmovaps [rsp+0xB0], xmm12
00007cc2f47d3c97  vmovaps [rsp+0xC0], xmm13
00007cc2f47d3ca0  vmovaps [rsp+0xD0], xmm14
00007cc2f47d3ca9  vmovaps [rsp+0xE0], xmm15
00007cc2f47d3cb2  sub rsp, 0x30
00007cc2f47d3cb6  movaps [rsp], xmm1
00007cc2f47d3cba  movaps [rsp+0x10], xmm12
00007cc2f47d3cc0  movaps [rsp+0x20], xmm10
00007cc2f47d3cc6  lea rdi, [rsp]
00007cc2f47d3cca  mov esi, 0x00
00007cc2f47d3ccf  mov rax, 0x5990E710A530
00007cc2f47d3cd9  call rax
00007cc2f47d3cdb  movaps xmm1, [rsp]
00007cc2f47d3cdf  add rsp, 0x30
00007cc2f47d3ce3  vmovaps xmm0, [rsp]
00007cc2f47d3ce8  vmovaps xmm2, [rsp+0x10]
00007cc2f47d3cee  vmovaps xmm3, [rsp+0x20]
00007cc2f47d3cf4  vmovaps xmm4, [rsp+0x30]
00007cc2f47d3cfa  vmovaps xmm5, [rsp+0x40]
00007cc2f47d3d00  vmovaps xmm6, [rsp+0x50]
00007cc2f47d3d06  vmovaps xmm7, [rsp+0x60]
00007cc2f47d3d0c  vmovaps xmm8, [rsp+0x70]
00007cc2f47d3d12  vmovaps xmm9, [rsp+0x80]
00007cc2f47d3d1b  vmovaps xmm10, [rsp+0x90]
00007cc2f47d3d24  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d3d2d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d3d36  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d3d3f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d3d48  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d3d51  add rsp, 0xF0
00007cc2f47d3d58  pop r11
00007cc2f47d3d5a  pop r10
00007cc2f47d3d5c  pop r9
00007cc2f47d3d5e  pop r8
00007cc2f47d3d60  pop rsi
00007cc2f47d3d61  pop rdi
00007cc2f47d3d62  pop rdx
00007cc2f47d3d63  pop rcx
00007cc2f47d3d64  pop rax
00007cc2f47d3d65  add rsp, 0x08
00007cc2f47d3d69  jmp 0x00007CC2F47D284F
00007cc2f47d3d6e  sub rsp, 0x08
00007cc2f47d3d72  push rax
00007cc2f47d3d73  push rcx
00007cc2f47d3d74  push rdx
00007cc2f47d3d75  push rdi
00007cc2f47d3d76  push rsi
00007cc2f47d3d77  push r8
00007cc2f47d3d79  push r9
00007cc2f47d3d7b  push r10
00007cc2f47d3d7d  push r11
00007cc2f47d3d7f  sub rsp, 0xF0
00007cc2f47d3d86  vmovaps [rsp], xmm0
00007cc2f47d3d8b  vmovaps [rsp+0x10], xmm1
00007cc2f47d3d91  vmovaps [rsp+0x20], xmm2
00007cc2f47d3d97  vmovaps [rsp+0x30], xmm3
00007cc2f47d3d9d  vmovaps [rsp+0x40], xmm4
00007cc2f47d3da3  vmovaps [rsp+0x50], xmm5
00007cc2f47d3da9  vmovaps [rsp+0x60], xmm6
00007cc2f47d3daf  vmovaps [rsp+0x70], xmm7
00007cc2f47d3db5  vmovaps [rsp+0x80], xmm8
00007cc2f47d3dbe  vmovaps [rsp+0x90], xmm9
00007cc2f47d3dc7  vmovaps [rsp+0xA0], xmm10
00007cc2f47d3dd0  vmovaps [rsp+0xB0], xmm11
00007cc2f47d3dd9  vmovaps [rsp+0xC0], xmm12
00007cc2f47d3de2  vmovaps [rsp+0xD0], xmm14
00007cc2f47d3deb  vmovaps [rsp+0xE0], xmm15
00007cc2f47d3df4  sub rsp, 0x30
00007cc2f47d3df8  movaps [rsp], xmm13
00007cc2f47d3dfd  movaps [rsp+0x10], xmm12
00007cc2f47d3e03  movaps [rsp+0x20], xmm2
00007cc2f47d3e08  lea rdi, [rsp]
00007cc2f47d3e0c  mov esi, 0x00
00007cc2f47d3e11  mov rax, 0x5990E710A530
00007cc2f47d3e1b  call rax
00007cc2f47d3e1d  movaps xmm13, [rsp]
00007cc2f47d3e22  add rsp, 0x30
00007cc2f47d3e26  vmovaps xmm0, [rsp]
00007cc2f47d3e2b  vmovaps xmm1, [rsp+0x10]
00007cc2f47d3e31  vmovaps xmm2, [rsp+0x20]
00007cc2f47d3e37  vmovaps xmm3, [rsp+0x30]
00007cc2f47d3e3d  vmovaps xmm4, [rsp+0x40]
00007cc2f47d3e43  vmovaps xmm5, [rsp+0x50]
00007cc2f47d3e49  vmovaps xmm6, [rsp+0x60]
00007cc2f47d3e4f  vmovaps xmm7, [rsp+0x70]
00007cc2f47d3e55  vmovaps xmm8, [rsp+0x80]
00007cc2f47d3e5e  vmovaps xmm9, [rsp+0x90]
00007cc2f47d3e67  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d3e70  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d3e79  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d3e82  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d3e8b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d3e94  add rsp, 0xF0
00007cc2f47d3e9b  pop r11
00007cc2f47d3e9d  pop r10
00007cc2f47d3e9f  pop r9
00007cc2f47d3ea1  pop r8
00007cc2f47d3ea3  pop rsi
00007cc2f47d3ea4  pop rdi
00007cc2f47d3ea5  pop rdx
00007cc2f47d3ea6  pop rcx
00007cc2f47d3ea7  pop rax
00007cc2f47d3ea8  add rsp, 0x08
00007cc2f47d3eac  jmp 0x00007CC2F47D286A
00007cc2f47d3eb1  sub rsp, 0x08
00007cc2f47d3eb5  push rax
00007cc2f47d3eb6  push rcx
00007cc2f47d3eb7  push rdx
00007cc2f47d3eb8  push rdi
00007cc2f47d3eb9  push rsi
00007cc2f47d3eba  push r8
00007cc2f47d3ebc  push r9
00007cc2f47d3ebe  push r10
00007cc2f47d3ec0  push r11
00007cc2f47d3ec2  sub rsp, 0xF0
00007cc2f47d3ec9  vmovaps [rsp], xmm0
00007cc2f47d3ece  vmovaps [rsp+0x10], xmm2
00007cc2f47d3ed4  vmovaps [rsp+0x20], xmm3
00007cc2f47d3eda  vmovaps [rsp+0x30], xmm4
00007cc2f47d3ee0  vmovaps [rsp+0x40], xmm5
00007cc2f47d3ee6  vmovaps [rsp+0x50], xmm6
00007cc2f47d3eec  vmovaps [rsp+0x60], xmm7
00007cc2f47d3ef2  vmovaps [rsp+0x70], xmm8
00007cc2f47d3ef8  vmovaps [rsp+0x80], xmm9
00007cc2f47d3f01  vmovaps [rsp+0x90], xmm10
00007cc2f47d3f0a  vmovaps [rsp+0xA0], xmm11
00007cc2f47d3f13  vmovaps [rsp+0xB0], xmm12
00007cc2f47d3f1c  vmovaps [rsp+0xC0], xmm13
00007cc2f47d3f25  vmovaps [rsp+0xD0], xmm14
00007cc2f47d3f2e  vmovaps [rsp+0xE0], xmm15
00007cc2f47d3f37  sub rsp, 0x30
00007cc2f47d3f3b  movaps [rsp], xmm1
00007cc2f47d3f3f  movaps [rsp+0x10], xmm10
00007cc2f47d3f45  movaps [rsp+0x20], xmm2
00007cc2f47d3f4a  lea rdi, [rsp]
00007cc2f47d3f4e  mov esi, 0x00
00007cc2f47d3f53  mov rax, 0x5990E710A530
00007cc2f47d3f5d  call rax
00007cc2f47d3f5f  movaps xmm1, [rsp]
00007cc2f47d3f63  add rsp, 0x30
00007cc2f47d3f67  vmovaps xmm0, [rsp]
00007cc2f47d3f6c  vmovaps xmm2, [rsp+0x10]
00007cc2f47d3f72  vmovaps xmm3, [rsp+0x20]
00007cc2f47d3f78  vmovaps xmm4, [rsp+0x30]
00007cc2f47d3f7e  vmovaps xmm5, [rsp+0x40]
00007cc2f47d3f84  vmovaps xmm6, [rsp+0x50]
00007cc2f47d3f8a  vmovaps xmm7, [rsp+0x60]
00007cc2f47d3f90  vmovaps xmm8, [rsp+0x70]
00007cc2f47d3f96  vmovaps xmm9, [rsp+0x80]
00007cc2f47d3f9f  vmovaps xmm10, [rsp+0x90]
00007cc2f47d3fa8  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d3fb1  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d3fba  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d3fc3  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d3fcc  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d3fd5  add rsp, 0xF0
00007cc2f47d3fdc  pop r11
00007cc2f47d3fde  pop r10
00007cc2f47d3fe0  pop r9
00007cc2f47d3fe2  pop r8
00007cc2f47d3fe4  pop rsi
00007cc2f47d3fe5  pop rdi
00007cc2f47d3fe6  pop rdx
00007cc2f47d3fe7  pop rcx
00007cc2f47d3fe8  pop rax
00007cc2f47d3fe9  add rsp, 0x08
00007cc2f47d3fed  jmp 0x00007CC2F47D28D2
00007cc2f47d3ff2  sub rsp, 0x08
00007cc2f47d3ff6  push rax
00007cc2f47d3ff7  push rcx
00007cc2f47d3ff8  push rdx
00007cc2f47d3ff9  push rdi
00007cc2f47d3ffa  push rsi
00007cc2f47d3ffb  push r8
00007cc2f47d3ffd  push r9
00007cc2f47d3fff  push r10
00007cc2f47d4001  push r11
00007cc2f47d4003  sub rsp, 0xF0
00007cc2f47d400a  vmovaps [rsp], xmm0
00007cc2f47d400f  vmovaps [rsp+0x10], xmm1
00007cc2f47d4015  vmovaps [rsp+0x20], xmm2
00007cc2f47d401b  vmovaps [rsp+0x30], xmm3
00007cc2f47d4021  vmovaps [rsp+0x40], xmm4
00007cc2f47d4027  vmovaps [rsp+0x50], xmm5
00007cc2f47d402d  vmovaps [rsp+0x60], xmm6
00007cc2f47d4033  vmovaps [rsp+0x70], xmm7
00007cc2f47d4039  vmovaps [rsp+0x80], xmm8
00007cc2f47d4042  vmovaps [rsp+0x90], xmm9
00007cc2f47d404b  vmovaps [rsp+0xA0], xmm10
00007cc2f47d4054  vmovaps [rsp+0xB0], xmm11
00007cc2f47d405d  vmovaps [rsp+0xC0], xmm12
00007cc2f47d4066  vmovaps [rsp+0xD0], xmm13
00007cc2f47d406f  vmovaps [rsp+0xE0], xmm14
00007cc2f47d4078  sub rsp, 0x30
00007cc2f47d407c  movaps [rsp], xmm15
00007cc2f47d4081  movaps [rsp+0x10], xmm10
00007cc2f47d4087  movaps [rsp+0x20], xmm2
00007cc2f47d408c  lea rdi, [rsp]
00007cc2f47d4090  mov esi, 0x00
00007cc2f47d4095  mov rax, 0x5990E710A530
00007cc2f47d409f  call rax
00007cc2f47d40a1  movaps xmm15, [rsp]
00007cc2f47d40a6  add rsp, 0x30
00007cc2f47d40aa  vmovaps xmm0, [rsp]
00007cc2f47d40af  vmovaps xmm1, [rsp+0x10]
00007cc2f47d40b5  vmovaps xmm2, [rsp+0x20]
00007cc2f47d40bb  vmovaps xmm3, [rsp+0x30]
00007cc2f47d40c1  vmovaps xmm4, [rsp+0x40]
00007cc2f47d40c7  vmovaps xmm5, [rsp+0x50]
00007cc2f47d40cd  vmovaps xmm6, [rsp+0x60]
00007cc2f47d40d3  vmovaps xmm7, [rsp+0x70]
00007cc2f47d40d9  vmovaps xmm8, [rsp+0x80]
00007cc2f47d40e2  vmovaps xmm9, [rsp+0x90]
00007cc2f47d40eb  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d40f4  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d40fd  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d4106  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d410f  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d4118  add rsp, 0xF0
00007cc2f47d411f  pop r11
00007cc2f47d4121  pop r10
00007cc2f47d4123  pop r9
00007cc2f47d4125  pop r8
00007cc2f47d4127  pop rsi
00007cc2f47d4128  pop rdi
00007cc2f47d4129  pop rdx
00007cc2f47d412a  pop rcx
00007cc2f47d412b  pop rax
00007cc2f47d412c  add rsp, 0x08
00007cc2f47d4130  jmp 0x00007CC2F47D2924
00007cc2f47d4135  sub rsp, 0x08
00007cc2f47d4139  push rax
00007cc2f47d413a  push rcx
00007cc2f47d413b  push rdx
00007cc2f47d413c  push rdi
00007cc2f47d413d  push rsi
00007cc2f47d413e  push r8
00007cc2f47d4140  push r9
00007cc2f47d4142  push r10
00007cc2f47d4144  push r11
00007cc2f47d4146  sub rsp, 0xF0
00007cc2f47d414d  vmovaps [rsp], xmm0
00007cc2f47d4152  vmovaps [rsp+0x10], xmm2
00007cc2f47d4158  vmovaps [rsp+0x20], xmm3
00007cc2f47d415e  vmovaps [rsp+0x30], xmm4
00007cc2f47d4164  vmovaps [rsp+0x40], xmm5
00007cc2f47d416a  vmovaps [rsp+0x50], xmm6
00007cc2f47d4170  vmovaps [rsp+0x60], xmm7
00007cc2f47d4176  vmovaps [rsp+0x70], xmm8
00007cc2f47d417c  vmovaps [rsp+0x80], xmm9
00007cc2f47d4185  vmovaps [rsp+0x90], xmm10
00007cc2f47d418e  vmovaps [rsp+0xA0], xmm11
00007cc2f47d4197  vmovaps [rsp+0xB0], xmm12
00007cc2f47d41a0  vmovaps [rsp+0xC0], xmm13
00007cc2f47d41a9  vmovaps [rsp+0xD0], xmm14
00007cc2f47d41b2  vmovaps [rsp+0xE0], xmm15
00007cc2f47d41bb  sub rsp, 0x30
00007cc2f47d41bf  movaps [rsp], xmm1
00007cc2f47d41c3  movaps [rsp+0x10], xmm10
00007cc2f47d41c9  movaps [rsp+0x20], xmm15
00007cc2f47d41cf  lea rdi, [rsp]
00007cc2f47d41d3  mov esi, 0x00
00007cc2f47d41d8  mov rax, 0x5990E710A530
00007cc2f47d41e2  call rax
00007cc2f47d41e4  movaps xmm1, [rsp]
00007cc2f47d41e8  add rsp, 0x30
00007cc2f47d41ec  vmovaps xmm0, [rsp]
00007cc2f47d41f1  vmovaps xmm2, [rsp+0x10]
00007cc2f47d41f7  vmovaps xmm3, [rsp+0x20]
00007cc2f47d41fd  vmovaps xmm4, [rsp+0x30]
00007cc2f47d4203  vmovaps xmm5, [rsp+0x40]
00007cc2f47d4209  vmovaps xmm6, [rsp+0x50]
00007cc2f47d420f  vmovaps xmm7, [rsp+0x60]
00007cc2f47d4215  vmovaps xmm8, [rsp+0x70]
00007cc2f47d421b  vmovaps xmm9, [rsp+0x80]
00007cc2f47d4224  vmovaps xmm10, [rsp+0x90]
00007cc2f47d422d  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d4236  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d423f  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d4248  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d4251  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d425a  add rsp, 0xF0
00007cc2f47d4261  pop r11
00007cc2f47d4263  pop r10
00007cc2f47d4265  pop r9
00007cc2f47d4267  pop r8
00007cc2f47d4269  pop rsi
00007cc2f47d426a  pop rdi
00007cc2f47d426b  pop rdx
00007cc2f47d426c  pop rcx
00007cc2f47d426d  pop rax
00007cc2f47d426e  add rsp, 0x08
00007cc2f47d4272  jmp 0x00007CC2F47D2962
00007cc2f47d4277  sub rsp, 0x08
00007cc2f47d427b  push rax
00007cc2f47d427c  push rcx
00007cc2f47d427d  push rdx
00007cc2f47d427e  push rdi
00007cc2f47d427f  push rsi
00007cc2f47d4280  push r8
00007cc2f47d4282  push r9
00007cc2f47d4284  push r10
00007cc2f47d4286  push r11
00007cc2f47d4288  sub rsp, 0xF0
00007cc2f47d428f  vmovaps [rsp], xmm0
00007cc2f47d4294  vmovaps [rsp+0x10], xmm1
00007cc2f47d429a  vmovaps [rsp+0x20], xmm2
00007cc2f47d42a0  vmovaps [rsp+0x30], xmm3
00007cc2f47d42a6  vmovaps [rsp+0x40], xmm4
00007cc2f47d42ac  vmovaps [rsp+0x50], xmm5
00007cc2f47d42b2  vmovaps [rsp+0x60], xmm6
00007cc2f47d42b8  vmovaps [rsp+0x70], xmm7
00007cc2f47d42be  vmovaps [rsp+0x80], xmm8
00007cc2f47d42c7  vmovaps [rsp+0x90], xmm9
00007cc2f47d42d0  vmovaps [rsp+0xA0], xmm10
00007cc2f47d42d9  vmovaps [rsp+0xB0], xmm11
00007cc2f47d42e2  vmovaps [rsp+0xC0], xmm12
00007cc2f47d42eb  vmovaps [rsp+0xD0], xmm13
00007cc2f47d42f4  vmovaps [rsp+0xE0], xmm15
00007cc2f47d42fd  sub rsp, 0x30
00007cc2f47d4301  movaps [rsp], xmm14
00007cc2f47d4306  movaps [rsp+0x10], xmm10
00007cc2f47d430c  movaps [rsp+0x20], xmm15
00007cc2f47d4312  lea rdi, [rsp]
00007cc2f47d4316  mov esi, 0x00
00007cc2f47d431b  mov rax, 0x5990E710A530
00007cc2f47d4325  call rax
00007cc2f47d4327  movaps xmm14, [rsp]
00007cc2f47d432c  add rsp, 0x30
00007cc2f47d4330  vmovaps xmm0, [rsp]
00007cc2f47d4335  vmovaps xmm1, [rsp+0x10]
00007cc2f47d433b  vmovaps xmm2, [rsp+0x20]
00007cc2f47d4341  vmovaps xmm3, [rsp+0x30]
00007cc2f47d4347  vmovaps xmm4, [rsp+0x40]
00007cc2f47d434d  vmovaps xmm5, [rsp+0x50]
00007cc2f47d4353  vmovaps xmm6, [rsp+0x60]
00007cc2f47d4359  vmovaps xmm7, [rsp+0x70]
00007cc2f47d435f  vmovaps xmm8, [rsp+0x80]
00007cc2f47d4368  vmovaps xmm9, [rsp+0x90]
00007cc2f47d4371  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d437a  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d4383  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d438c  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d4395  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d439e  add rsp, 0xF0
00007cc2f47d43a5  pop r11
00007cc2f47d43a7  pop r10
00007cc2f47d43a9  pop r9
00007cc2f47d43ab  pop r8
00007cc2f47d43ad  pop rsi
00007cc2f47d43ae  pop rdi
00007cc2f47d43af  pop rdx
00007cc2f47d43b0  pop rcx
00007cc2f47d43b1  pop rax
00007cc2f47d43b2  add rsp, 0x08
00007cc2f47d43b6  jmp 0x00007CC2F47D298E
00007cc2f47d43bb  call 0x00007CC2F45FF430
00007cc2f47d43c0  jmp 0x00007CC2F47D2A1E
00007cc2f47d43c5  call 0x00007CC2F45FF430
00007cc2f47d43ca  jmp 0x00007CC2F47D2A31
00007cc2f47d43cf  sub rsp, 0x08
00007cc2f47d43d3  push rax
00007cc2f47d43d4  push rcx
00007cc2f47d43d5  push rdx
00007cc2f47d43d6  push rdi
00007cc2f47d43d7  push rsi
00007cc2f47d43d8  push r8
00007cc2f47d43da  push r9
00007cc2f47d43dc  push r10
00007cc2f47d43de  push r11
00007cc2f47d43e0  sub rsp, 0xF0
00007cc2f47d43e7  vmovaps [rsp], xmm0
00007cc2f47d43ec  vmovaps [rsp+0x10], xmm2
00007cc2f47d43f2  vmovaps [rsp+0x20], xmm3
00007cc2f47d43f8  vmovaps [rsp+0x30], xmm4
00007cc2f47d43fe  vmovaps [rsp+0x40], xmm5
00007cc2f47d4404  vmovaps [rsp+0x50], xmm6
00007cc2f47d440a  vmovaps [rsp+0x60], xmm7
00007cc2f47d4410  vmovaps [rsp+0x70], xmm8
00007cc2f47d4416  vmovaps [rsp+0x80], xmm9
00007cc2f47d441f  vmovaps [rsp+0x90], xmm10
00007cc2f47d4428  vmovaps [rsp+0xA0], xmm11
00007cc2f47d4431  vmovaps [rsp+0xB0], xmm12
00007cc2f47d443a  vmovaps [rsp+0xC0], xmm13
00007cc2f47d4443  vmovaps [rsp+0xD0], xmm14
00007cc2f47d444c  vmovaps [rsp+0xE0], xmm15
00007cc2f47d4455  sub rsp, 0x30
00007cc2f47d4459  movaps [rsp], xmm1
00007cc2f47d445d  movaps [rsp+0x10], xmm13
00007cc2f47d4463  movaps [rsp+0x20], xmm2
00007cc2f47d4468  lea rdi, [rsp]
00007cc2f47d446c  mov esi, 0x00
00007cc2f47d4471  mov rax, 0x5990E710A530
00007cc2f47d447b  call rax
00007cc2f47d447d  movaps xmm1, [rsp]
00007cc2f47d4481  add rsp, 0x30
00007cc2f47d4485  vmovaps xmm0, [rsp]
00007cc2f47d448a  vmovaps xmm2, [rsp+0x10]
00007cc2f47d4490  vmovaps xmm3, [rsp+0x20]
00007cc2f47d4496  vmovaps xmm4, [rsp+0x30]
00007cc2f47d449c  vmovaps xmm5, [rsp+0x40]
00007cc2f47d44a2  vmovaps xmm6, [rsp+0x50]
00007cc2f47d44a8  vmovaps xmm7, [rsp+0x60]
00007cc2f47d44ae  vmovaps xmm8, [rsp+0x70]
00007cc2f47d44b4  vmovaps xmm9, [rsp+0x80]
00007cc2f47d44bd  vmovaps xmm10, [rsp+0x90]
00007cc2f47d44c6  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d44cf  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d44d8  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d44e1  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d44ea  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d44f3  add rsp, 0xF0
00007cc2f47d44fa  pop r11
00007cc2f47d44fc  pop r10
00007cc2f47d44fe  pop r9
00007cc2f47d4500  pop r8
00007cc2f47d4502  pop rsi
00007cc2f47d4503  pop rdi
00007cc2f47d4504  pop rdx
00007cc2f47d4505  pop rcx
00007cc2f47d4506  pop rax
00007cc2f47d4507  add rsp, 0x08
00007cc2f47d450b  jmp 0x00007CC2F47D2A5C
00007cc2f47d4510  call 0x00007CC2F460E760
00007cc2f47d4515  jmp 0x00007CC2F47D2A69
00007cc2f47d451a  sub rsp, 0x08
00007cc2f47d451e  push rax
00007cc2f47d451f  push rcx
00007cc2f47d4520  push rdx
00007cc2f47d4521  push rdi
00007cc2f47d4522  push rsi
00007cc2f47d4523  push r8
00007cc2f47d4525  push r9
00007cc2f47d4527  push r10
00007cc2f47d4529  push r11
00007cc2f47d452b  sub rsp, 0xF0
00007cc2f47d4532  vmovaps [rsp], xmm0
00007cc2f47d4537  vmovaps [rsp+0x10], xmm1
00007cc2f47d453d  vmovaps [rsp+0x20], xmm2
00007cc2f47d4543  vmovaps [rsp+0x30], xmm3
00007cc2f47d4549  vmovaps [rsp+0x40], xmm4
00007cc2f47d454f  vmovaps [rsp+0x50], xmm5
00007cc2f47d4555  vmovaps [rsp+0x60], xmm6
00007cc2f47d455b  vmovaps [rsp+0x70], xmm7
00007cc2f47d4561  vmovaps [rsp+0x80], xmm8
00007cc2f47d456a  vmovaps [rsp+0x90], xmm9
00007cc2f47d4573  vmovaps [rsp+0xA0], xmm10
00007cc2f47d457c  vmovaps [rsp+0xB0], xmm11
00007cc2f47d4585  vmovaps [rsp+0xC0], xmm12
00007cc2f47d458e  vmovaps [rsp+0xD0], xmm14
00007cc2f47d4597  vmovaps [rsp+0xE0], xmm15
00007cc2f47d45a0  sub rsp, 0x30
00007cc2f47d45a4  movaps [rsp], xmm13
00007cc2f47d45a9  movaps [rsp+0x10], xmm2
00007cc2f47d45ae  movaps [rsp+0x20], xmm1
00007cc2f47d45b3  lea rdi, [rsp]
00007cc2f47d45b7  mov esi, 0x00
00007cc2f47d45bc  mov rax, 0x5990E710A530
00007cc2f47d45c6  call rax
00007cc2f47d45c8  movaps xmm13, [rsp]
00007cc2f47d45cd  add rsp, 0x30
00007cc2f47d45d1  vmovaps xmm0, [rsp]
00007cc2f47d45d6  vmovaps xmm1, [rsp+0x10]
00007cc2f47d45dc  vmovaps xmm2, [rsp+0x20]
00007cc2f47d45e2  vmovaps xmm3, [rsp+0x30]
00007cc2f47d45e8  vmovaps xmm4, [rsp+0x40]
00007cc2f47d45ee  vmovaps xmm5, [rsp+0x50]
00007cc2f47d45f4  vmovaps xmm6, [rsp+0x60]
00007cc2f47d45fa  vmovaps xmm7, [rsp+0x70]
00007cc2f47d4600  vmovaps xmm8, [rsp+0x80]
00007cc2f47d4609  vmovaps xmm9, [rsp+0x90]
00007cc2f47d4612  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d461b  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d4624  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d462d  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d4636  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d463f  add rsp, 0xF0
00007cc2f47d4646  pop r11
00007cc2f47d4648  pop r10
00007cc2f47d464a  pop r9
00007cc2f47d464c  pop r8
00007cc2f47d464e  pop rsi
00007cc2f47d464f  pop rdi
00007cc2f47d4650  pop rdx
00007cc2f47d4651  pop rcx
00007cc2f47d4652  pop rax
00007cc2f47d4653  add rsp, 0x08
00007cc2f47d4657  jmp 0x00007CC2F47D2AA8
00007cc2f47d465c  sub rsp, 0x08
00007cc2f47d4660  push rax
00007cc2f47d4661  push rcx
00007cc2f47d4662  push rdx
00007cc2f47d4663  push rdi
00007cc2f47d4664  push rsi
00007cc2f47d4665  push r8
00007cc2f47d4667  push r9
00007cc2f47d4669  push r10
00007cc2f47d466b  push r11
00007cc2f47d466d  sub rsp, 0xF0
00007cc2f47d4674  vmovaps [rsp], xmm0
00007cc2f47d4679  vmovaps [rsp+0x10], xmm2
00007cc2f47d467f  vmovaps [rsp+0x20], xmm3
00007cc2f47d4685  vmovaps [rsp+0x30], xmm4
00007cc2f47d468b  vmovaps [rsp+0x40], xmm5
00007cc2f47d4691  vmovaps [rsp+0x50], xmm6
00007cc2f47d4697  vmovaps [rsp+0x60], xmm7
00007cc2f47d469d  vmovaps [rsp+0x70], xmm8
00007cc2f47d46a3  vmovaps [rsp+0x80], xmm9
00007cc2f47d46ac  vmovaps [rsp+0x90], xmm10
00007cc2f47d46b5  vmovaps [rsp+0xA0], xmm11
00007cc2f47d46be  vmovaps [rsp+0xB0], xmm12
00007cc2f47d46c7  vmovaps [rsp+0xC0], xmm13
00007cc2f47d46d0  vmovaps [rsp+0xD0], xmm14
00007cc2f47d46d9  vmovaps [rsp+0xE0], xmm15
00007cc2f47d46e2  sub rsp, 0x30
00007cc2f47d46e6  movaps [rsp], xmm1
00007cc2f47d46ea  movaps [rsp+0x10], xmm14
00007cc2f47d46f0  movaps [rsp+0x20], xmm15
00007cc2f47d46f6  lea rdi, [rsp]
00007cc2f47d46fa  mov esi, 0x00
00007cc2f47d46ff  mov rax, 0x5990E710A530
00007cc2f47d4709  call rax
00007cc2f47d470b  movaps xmm1, [rsp]
00007cc2f47d470f  add rsp, 0x30
00007cc2f47d4713  vmovaps xmm0, [rsp]
00007cc2f47d4718  vmovaps xmm2, [rsp+0x10]
00007cc2f47d471e  vmovaps xmm3, [rsp+0x20]
00007cc2f47d4724  vmovaps xmm4, [rsp+0x30]
00007cc2f47d472a  vmovaps xmm5, [rsp+0x40]
00007cc2f47d4730  vmovaps xmm6, [rsp+0x50]
00007cc2f47d4736  vmovaps xmm7, [rsp+0x60]
00007cc2f47d473c  vmovaps xmm8, [rsp+0x70]
00007cc2f47d4742  vmovaps xmm9, [rsp+0x80]
00007cc2f47d474b  vmovaps xmm10, [rsp+0x90]
00007cc2f47d4754  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d475d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d4766  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d476f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d4778  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d4781  add rsp, 0xF0
00007cc2f47d4788  pop r11
00007cc2f47d478a  pop r10
00007cc2f47d478c  pop r9
00007cc2f47d478e  pop r8
00007cc2f47d4790  pop rsi
00007cc2f47d4791  pop rdi
00007cc2f47d4792  pop rdx
00007cc2f47d4793  pop rcx
00007cc2f47d4794  pop rax
00007cc2f47d4795  add rsp, 0x08
00007cc2f47d4799  jmp 0x00007CC2F47D2ACA
00007cc2f47d479e  sub rsp, 0x08
00007cc2f47d47a2  push rax
00007cc2f47d47a3  push rcx
00007cc2f47d47a4  push rdx
00007cc2f47d47a5  push rdi
00007cc2f47d47a6  push rsi
00007cc2f47d47a7  push r8
00007cc2f47d47a9  push r9
00007cc2f47d47ab  push r10
00007cc2f47d47ad  push r11
00007cc2f47d47af  sub rsp, 0xF0
00007cc2f47d47b6  vmovaps [rsp], xmm0
00007cc2f47d47bb  vmovaps [rsp+0x10], xmm1
00007cc2f47d47c1  vmovaps [rsp+0x20], xmm2
00007cc2f47d47c7  vmovaps [rsp+0x30], xmm3
00007cc2f47d47cd  vmovaps [rsp+0x40], xmm4
00007cc2f47d47d3  vmovaps [rsp+0x50], xmm5
00007cc2f47d47d9  vmovaps [rsp+0x60], xmm6
00007cc2f47d47df  vmovaps [rsp+0x70], xmm7
00007cc2f47d47e5  vmovaps [rsp+0x80], xmm8
00007cc2f47d47ee  vmovaps [rsp+0x90], xmm9
00007cc2f47d47f7  vmovaps [rsp+0xA0], xmm10
00007cc2f47d4800  vmovaps [rsp+0xB0], xmm11
00007cc2f47d4809  vmovaps [rsp+0xC0], xmm12
00007cc2f47d4812  vmovaps [rsp+0xD0], xmm13
00007cc2f47d481b  vmovaps [rsp+0xE0], xmm15
00007cc2f47d4824  sub rsp, 0x30
00007cc2f47d4828  movaps [rsp], xmm14
00007cc2f47d482d  movaps [rsp+0x10], xmm2
00007cc2f47d4832  movaps [rsp+0x20], xmm15
00007cc2f47d4838  lea rdi, [rsp]
00007cc2f47d483c  mov esi, 0x00
00007cc2f47d4841  mov rax, 0x5990E710A530
00007cc2f47d484b  call rax
00007cc2f47d484d  movaps xmm14, [rsp]
00007cc2f47d4852  add rsp, 0x30
00007cc2f47d4856  vmovaps xmm0, [rsp]
00007cc2f47d485b  vmovaps xmm1, [rsp+0x10]
00007cc2f47d4861  vmovaps xmm2, [rsp+0x20]
00007cc2f47d4867  vmovaps xmm3, [rsp+0x30]
00007cc2f47d486d  vmovaps xmm4, [rsp+0x40]
00007cc2f47d4873  vmovaps xmm5, [rsp+0x50]
00007cc2f47d4879  vmovaps xmm6, [rsp+0x60]
00007cc2f47d487f  vmovaps xmm7, [rsp+0x70]
00007cc2f47d4885  vmovaps xmm8, [rsp+0x80]
00007cc2f47d488e  vmovaps xmm9, [rsp+0x90]
00007cc2f47d4897  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d48a0  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d48a9  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d48b2  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d48bb  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d48c4  add rsp, 0xF0
00007cc2f47d48cb  pop r11
00007cc2f47d48cd  pop r10
00007cc2f47d48cf  pop r9
00007cc2f47d48d1  pop r8
00007cc2f47d48d3  pop rsi
00007cc2f47d48d4  pop rdi
00007cc2f47d48d5  pop rdx
00007cc2f47d48d6  pop rcx
00007cc2f47d48d7  pop rax
00007cc2f47d48d8  add rsp, 0x08
00007cc2f47d48dc  jmp 0x00007CC2F47D2B05
00007cc2f47d48e1  sub rsp, 0x08
00007cc2f47d48e5  push rax
00007cc2f47d48e6  push rcx
00007cc2f47d48e7  push rdx
00007cc2f47d48e8  push rdi
00007cc2f47d48e9  push rsi
00007cc2f47d48ea  push r8
00007cc2f47d48ec  push r9
00007cc2f47d48ee  push r10
00007cc2f47d48f0  push r11
00007cc2f47d48f2  sub rsp, 0xF0
00007cc2f47d48f9  vmovaps [rsp], xmm0
00007cc2f47d48fe  vmovaps [rsp+0x10], xmm1
00007cc2f47d4904  vmovaps [rsp+0x20], xmm2
00007cc2f47d490a  vmovaps [rsp+0x30], xmm3
00007cc2f47d4910  vmovaps [rsp+0x40], xmm4
00007cc2f47d4916  vmovaps [rsp+0x50], xmm5
00007cc2f47d491c  vmovaps [rsp+0x60], xmm6
00007cc2f47d4922  vmovaps [rsp+0x70], xmm7
00007cc2f47d4928  vmovaps [rsp+0x80], xmm8
00007cc2f47d4931  vmovaps [rsp+0x90], xmm9
00007cc2f47d493a  vmovaps [rsp+0xA0], xmm10
00007cc2f47d4943  vmovaps [rsp+0xB0], xmm11
00007cc2f47d494c  vmovaps [rsp+0xC0], xmm12
00007cc2f47d4955  vmovaps [rsp+0xD0], xmm13
00007cc2f47d495e  vmovaps [rsp+0xE0], xmm14
00007cc2f47d4967  sub rsp, 0x30
00007cc2f47d496b  movaps [rsp], xmm15
00007cc2f47d4970  movaps [rsp+0x10], xmm2
00007cc2f47d4975  movaps [rsp+0x20], xmm1
00007cc2f47d497a  lea rdi, [rsp]
00007cc2f47d497e  mov esi, 0x00
00007cc2f47d4983  mov rax, 0x5990E710A530
00007cc2f47d498d  call rax
00007cc2f47d498f  movaps xmm15, [rsp]
00007cc2f47d4994  add rsp, 0x30
00007cc2f47d4998  vmovaps xmm0, [rsp]
00007cc2f47d499d  vmovaps xmm1, [rsp+0x10]
00007cc2f47d49a3  vmovaps xmm2, [rsp+0x20]
00007cc2f47d49a9  vmovaps xmm3, [rsp+0x30]
00007cc2f47d49af  vmovaps xmm4, [rsp+0x40]
00007cc2f47d49b5  vmovaps xmm5, [rsp+0x50]
00007cc2f47d49bb  vmovaps xmm6, [rsp+0x60]
00007cc2f47d49c1  vmovaps xmm7, [rsp+0x70]
00007cc2f47d49c7  vmovaps xmm8, [rsp+0x80]
00007cc2f47d49d0  vmovaps xmm9, [rsp+0x90]
00007cc2f47d49d9  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d49e2  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d49eb  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d49f4  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d49fd  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d4a06  add rsp, 0xF0
00007cc2f47d4a0d  pop r11
00007cc2f47d4a0f  pop r10
00007cc2f47d4a11  pop r9
00007cc2f47d4a13  pop r8
00007cc2f47d4a15  pop rsi
00007cc2f47d4a16  pop rdi
00007cc2f47d4a17  pop rdx
00007cc2f47d4a18  pop rcx
00007cc2f47d4a19  pop rax
00007cc2f47d4a1a  add rsp, 0x08
00007cc2f47d4a1e  jmp 0x00007CC2F47D2B41
00007cc2f47d4a23  call 0x00007CC2F45FF430
00007cc2f47d4a28  jmp 0x00007CC2F47D2B4E
00007cc2f47d4a2d  sub rsp, 0x08
00007cc2f47d4a31  push rax
00007cc2f47d4a32  push rcx
00007cc2f47d4a33  push rdx
00007cc2f47d4a34  push rdi
00007cc2f47d4a35  push rsi
00007cc2f47d4a36  push r8
00007cc2f47d4a38  push r9
00007cc2f47d4a3a  push r10
00007cc2f47d4a3c  push r11
00007cc2f47d4a3e  sub rsp, 0xF0
00007cc2f47d4a45  vmovaps [rsp], xmm0
00007cc2f47d4a4a  vmovaps [rsp+0x10], xmm1
00007cc2f47d4a50  vmovaps [rsp+0x20], xmm3
00007cc2f47d4a56  vmovaps [rsp+0x30], xmm4
00007cc2f47d4a5c  vmovaps [rsp+0x40], xmm5
00007cc2f47d4a62  vmovaps [rsp+0x50], xmm6
00007cc2f47d4a68  vmovaps [rsp+0x60], xmm7
00007cc2f47d4a6e  vmovaps [rsp+0x70], xmm8
00007cc2f47d4a74  vmovaps [rsp+0x80], xmm9
00007cc2f47d4a7d  vmovaps [rsp+0x90], xmm10
00007cc2f47d4a86  vmovaps [rsp+0xA0], xmm11
00007cc2f47d4a8f  vmovaps [rsp+0xB0], xmm12
00007cc2f47d4a98  vmovaps [rsp+0xC0], xmm13
00007cc2f47d4aa1  vmovaps [rsp+0xD0], xmm14
00007cc2f47d4aaa  vmovaps [rsp+0xE0], xmm15
00007cc2f47d4ab3  sub rsp, 0x30
00007cc2f47d4ab7  movaps [rsp], xmm2
00007cc2f47d4abb  movaps [rsp+0x10], xmm1
00007cc2f47d4ac0  movaps [rsp+0x20], xmm14
00007cc2f47d4ac6  lea rdi, [rsp]
00007cc2f47d4aca  mov esi, 0x00
00007cc2f47d4acf  mov rax, 0x5990E710A530
00007cc2f47d4ad9  call rax
00007cc2f47d4adb  movaps xmm2, [rsp]
00007cc2f47d4adf  add rsp, 0x30
00007cc2f47d4ae3  vmovaps xmm0, [rsp]
00007cc2f47d4ae8  vmovaps xmm1, [rsp+0x10]
00007cc2f47d4aee  vmovaps xmm3, [rsp+0x20]
00007cc2f47d4af4  vmovaps xmm4, [rsp+0x30]
00007cc2f47d4afa  vmovaps xmm5, [rsp+0x40]
00007cc2f47d4b00  vmovaps xmm6, [rsp+0x50]
00007cc2f47d4b06  vmovaps xmm7, [rsp+0x60]
00007cc2f47d4b0c  vmovaps xmm8, [rsp+0x70]
00007cc2f47d4b12  vmovaps xmm9, [rsp+0x80]
00007cc2f47d4b1b  vmovaps xmm10, [rsp+0x90]
00007cc2f47d4b24  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d4b2d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d4b36  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d4b3f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d4b48  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d4b51  add rsp, 0xF0
00007cc2f47d4b58  pop r11
00007cc2f47d4b5a  pop r10
00007cc2f47d4b5c  pop r9
00007cc2f47d4b5e  pop r8
00007cc2f47d4b60  pop rsi
00007cc2f47d4b61  pop rdi
00007cc2f47d4b62  pop rdx
00007cc2f47d4b63  pop rcx
00007cc2f47d4b64  pop rax
00007cc2f47d4b65  add rsp, 0x08
00007cc2f47d4b69  jmp 0x00007CC2F47D2B8B
00007cc2f47d4b6e  sub rsp, 0x08
00007cc2f47d4b72  push rax
00007cc2f47d4b73  push rcx
00007cc2f47d4b74  push rdx
00007cc2f47d4b75  push rdi
00007cc2f47d4b76  push rsi
00007cc2f47d4b77  push r8
00007cc2f47d4b79  push r9
00007cc2f47d4b7b  push r10
00007cc2f47d4b7d  push r11
00007cc2f47d4b7f  sub rsp, 0xF0
00007cc2f47d4b86  vmovaps [rsp], xmm0
00007cc2f47d4b8b  vmovaps [rsp+0x10], xmm1
00007cc2f47d4b91  vmovaps [rsp+0x20], xmm2
00007cc2f47d4b97  vmovaps [rsp+0x30], xmm3
00007cc2f47d4b9d  vmovaps [rsp+0x40], xmm4
00007cc2f47d4ba3  vmovaps [rsp+0x50], xmm5
00007cc2f47d4ba9  vmovaps [rsp+0x60], xmm6
00007cc2f47d4baf  vmovaps [rsp+0x70], xmm7
00007cc2f47d4bb5  vmovaps [rsp+0x80], xmm8
00007cc2f47d4bbe  vmovaps [rsp+0x90], xmm9
00007cc2f47d4bc7  vmovaps [rsp+0xA0], xmm10
00007cc2f47d4bd0  vmovaps [rsp+0xB0], xmm11
00007cc2f47d4bd9  vmovaps [rsp+0xC0], xmm12
00007cc2f47d4be2  vmovaps [rsp+0xD0], xmm13
00007cc2f47d4beb  vmovaps [rsp+0xE0], xmm14
00007cc2f47d4bf4  sub rsp, 0x30
00007cc2f47d4bf8  movaps [rsp], xmm15
00007cc2f47d4bfd  movaps [rsp+0x10], xmm14
00007cc2f47d4c03  movaps [rsp+0x20], xmm1
00007cc2f47d4c08  lea rdi, [rsp]
00007cc2f47d4c0c  mov esi, 0x00
00007cc2f47d4c11  mov rax, 0x5990E710A530
00007cc2f47d4c1b  call rax
00007cc2f47d4c1d  movaps xmm15, [rsp]
00007cc2f47d4c22  add rsp, 0x30
00007cc2f47d4c26  vmovaps xmm0, [rsp]
00007cc2f47d4c2b  vmovaps xmm1, [rsp+0x10]
00007cc2f47d4c31  vmovaps xmm2, [rsp+0x20]
00007cc2f47d4c37  vmovaps xmm3, [rsp+0x30]
00007cc2f47d4c3d  vmovaps xmm4, [rsp+0x40]
00007cc2f47d4c43  vmovaps xmm5, [rsp+0x50]
00007cc2f47d4c49  vmovaps xmm6, [rsp+0x60]
00007cc2f47d4c4f  vmovaps xmm7, [rsp+0x70]
00007cc2f47d4c55  vmovaps xmm8, [rsp+0x80]
00007cc2f47d4c5e  vmovaps xmm9, [rsp+0x90]
00007cc2f47d4c67  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d4c70  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d4c79  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d4c82  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d4c8b  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d4c94  add rsp, 0xF0
00007cc2f47d4c9b  pop r11
00007cc2f47d4c9d  pop r10
00007cc2f47d4c9f  pop r9
00007cc2f47d4ca1  pop r8
00007cc2f47d4ca3  pop rsi
00007cc2f47d4ca4  pop rdi
00007cc2f47d4ca5  pop rdx
00007cc2f47d4ca6  pop rcx
00007cc2f47d4ca7  pop rax
00007cc2f47d4ca8  add rsp, 0x08
00007cc2f47d4cac  jmp 0x00007CC2F47D2C05
00007cc2f47d4cb1  call 0x00007CC2F45FF430
00007cc2f47d4cb6  jmp 0x00007CC2F47D2C12
00007cc2f47d4cbb  sub rsp, 0x08
00007cc2f47d4cbf  push rax
00007cc2f47d4cc0  push rcx
00007cc2f47d4cc1  push rdx
00007cc2f47d4cc2  push rdi
00007cc2f47d4cc3  push rsi
00007cc2f47d4cc4  push r8
00007cc2f47d4cc6  push r9
00007cc2f47d4cc8  push r10
00007cc2f47d4cca  push r11
00007cc2f47d4ccc  sub rsp, 0xF0
00007cc2f47d4cd3  vmovaps [rsp], xmm0
00007cc2f47d4cd8  vmovaps [rsp+0x10], xmm1
00007cc2f47d4cde  vmovaps [rsp+0x20], xmm2
00007cc2f47d4ce4  vmovaps [rsp+0x30], xmm3
00007cc2f47d4cea  vmovaps [rsp+0x40], xmm4
00007cc2f47d4cf0  vmovaps [rsp+0x50], xmm5
00007cc2f47d4cf6  vmovaps [rsp+0x60], xmm6
00007cc2f47d4cfc  vmovaps [rsp+0x70], xmm7
00007cc2f47d4d02  vmovaps [rsp+0x80], xmm8
00007cc2f47d4d0b  vmovaps [rsp+0x90], xmm9
00007cc2f47d4d14  vmovaps [rsp+0xA0], xmm10
00007cc2f47d4d1d  vmovaps [rsp+0xB0], xmm11
00007cc2f47d4d26  vmovaps [rsp+0xC0], xmm12
00007cc2f47d4d2f  vmovaps [rsp+0xD0], xmm14
00007cc2f47d4d38  vmovaps [rsp+0xE0], xmm15
00007cc2f47d4d41  sub rsp, 0x30
00007cc2f47d4d45  movaps [rsp], xmm13
00007cc2f47d4d4a  movaps [rsp+0x10], xmm1
00007cc2f47d4d4f  movaps [rsp+0x20], xmm15
00007cc2f47d4d55  lea rdi, [rsp]
00007cc2f47d4d59  mov esi, 0x00
00007cc2f47d4d5e  mov rax, 0x5990E710A530
00007cc2f47d4d68  call rax
00007cc2f47d4d6a  movaps xmm13, [rsp]
00007cc2f47d4d6f  add rsp, 0x30
00007cc2f47d4d73  vmovaps xmm0, [rsp]
00007cc2f47d4d78  vmovaps xmm1, [rsp+0x10]
00007cc2f47d4d7e  vmovaps xmm2, [rsp+0x20]
00007cc2f47d4d84  vmovaps xmm3, [rsp+0x30]
00007cc2f47d4d8a  vmovaps xmm4, [rsp+0x40]
00007cc2f47d4d90  vmovaps xmm5, [rsp+0x50]
00007cc2f47d4d96  vmovaps xmm6, [rsp+0x60]
00007cc2f47d4d9c  vmovaps xmm7, [rsp+0x70]
00007cc2f47d4da2  vmovaps xmm8, [rsp+0x80]
00007cc2f47d4dab  vmovaps xmm9, [rsp+0x90]
00007cc2f47d4db4  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d4dbd  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d4dc6  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d4dcf  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d4dd8  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d4de1  add rsp, 0xF0
00007cc2f47d4de8  pop r11
00007cc2f47d4dea  pop r10
00007cc2f47d4dec  pop r9
00007cc2f47d4dee  pop r8
00007cc2f47d4df0  pop rsi
00007cc2f47d4df1  pop rdi
00007cc2f47d4df2  pop rdx
00007cc2f47d4df3  pop rcx
00007cc2f47d4df4  pop rax
00007cc2f47d4df5  add rsp, 0x08
00007cc2f47d4df9  jmp 0x00007CC2F47D2CD6
00007cc2f47d4dfe  sub rsp, 0x08
00007cc2f47d4e02  push rax
00007cc2f47d4e03  push rcx
00007cc2f47d4e04  push rdx
00007cc2f47d4e05  push rdi
00007cc2f47d4e06  push rsi
00007cc2f47d4e07  push r8
00007cc2f47d4e09  push r9
00007cc2f47d4e0b  push r10
00007cc2f47d4e0d  push r11
00007cc2f47d4e0f  sub rsp, 0xF0
00007cc2f47d4e16  vmovaps [rsp], xmm0
00007cc2f47d4e1b  vmovaps [rsp+0x10], xmm1
00007cc2f47d4e21  vmovaps [rsp+0x20], xmm2
00007cc2f47d4e27  vmovaps [rsp+0x30], xmm3
00007cc2f47d4e2d  vmovaps [rsp+0x40], xmm4
00007cc2f47d4e33  vmovaps [rsp+0x50], xmm5
00007cc2f47d4e39  vmovaps [rsp+0x60], xmm6
00007cc2f47d4e3f  vmovaps [rsp+0x70], xmm7
00007cc2f47d4e45  vmovaps [rsp+0x80], xmm8
00007cc2f47d4e4e  vmovaps [rsp+0x90], xmm9
00007cc2f47d4e57  vmovaps [rsp+0xA0], xmm10
00007cc2f47d4e60  vmovaps [rsp+0xB0], xmm11
00007cc2f47d4e69  vmovaps [rsp+0xC0], xmm12
00007cc2f47d4e72  vmovaps [rsp+0xD0], xmm13
00007cc2f47d4e7b  vmovaps [rsp+0xE0], xmm14
00007cc2f47d4e84  sub rsp, 0x30
00007cc2f47d4e88  movaps [rsp], xmm15
00007cc2f47d4e8d  movaps [rsp+0x10], xmm14
00007cc2f47d4e93  movaps [rsp+0x20], xmm1
00007cc2f47d4e98  lea rdi, [rsp]
00007cc2f47d4e9c  mov esi, 0x00
00007cc2f47d4ea1  mov rax, 0x5990E710A530
00007cc2f47d4eab  call rax
00007cc2f47d4ead  movaps xmm15, [rsp]
00007cc2f47d4eb2  add rsp, 0x30
00007cc2f47d4eb6  vmovaps xmm0, [rsp]
00007cc2f47d4ebb  vmovaps xmm1, [rsp+0x10]
00007cc2f47d4ec1  vmovaps xmm2, [rsp+0x20]
00007cc2f47d4ec7  vmovaps xmm3, [rsp+0x30]
00007cc2f47d4ecd  vmovaps xmm4, [rsp+0x40]
00007cc2f47d4ed3  vmovaps xmm5, [rsp+0x50]
00007cc2f47d4ed9  vmovaps xmm6, [rsp+0x60]
00007cc2f47d4edf  vmovaps xmm7, [rsp+0x70]
00007cc2f47d4ee5  vmovaps xmm8, [rsp+0x80]
00007cc2f47d4eee  vmovaps xmm9, [rsp+0x90]
00007cc2f47d4ef7  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d4f00  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d4f09  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d4f12  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d4f1b  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d4f24  add rsp, 0xF0
00007cc2f47d4f2b  pop r11
00007cc2f47d4f2d  pop r10
00007cc2f47d4f2f  pop r9
00007cc2f47d4f31  pop r8
00007cc2f47d4f33  pop rsi
00007cc2f47d4f34  pop rdi
00007cc2f47d4f35  pop rdx
00007cc2f47d4f36  pop rcx
00007cc2f47d4f37  pop rax
00007cc2f47d4f38  add rsp, 0x08
00007cc2f47d4f3c  jmp 0x00007CC2F47D2D12
00007cc2f47d4f41  call 0x00007CC2F45FF430
00007cc2f47d4f46  jmp 0x00007CC2F47D2D1F
00007cc2f47d4f4b  sub rsp, 0x08
00007cc2f47d4f4f  push rax
00007cc2f47d4f50  push rcx
00007cc2f47d4f51  push rdx
00007cc2f47d4f52  push rdi
00007cc2f47d4f53  push rsi
00007cc2f47d4f54  push r8
00007cc2f47d4f56  push r9
00007cc2f47d4f58  push r10
00007cc2f47d4f5a  push r11
00007cc2f47d4f5c  sub rsp, 0xF0
00007cc2f47d4f63  vmovaps [rsp], xmm0
00007cc2f47d4f68  vmovaps [rsp+0x10], xmm1
00007cc2f47d4f6e  vmovaps [rsp+0x20], xmm2
00007cc2f47d4f74  vmovaps [rsp+0x30], xmm3
00007cc2f47d4f7a  vmovaps [rsp+0x40], xmm4
00007cc2f47d4f80  vmovaps [rsp+0x50], xmm5
00007cc2f47d4f86  vmovaps [rsp+0x60], xmm6
00007cc2f47d4f8c  vmovaps [rsp+0x70], xmm7
00007cc2f47d4f92  vmovaps [rsp+0x80], xmm8
00007cc2f47d4f9b  vmovaps [rsp+0x90], xmm9
00007cc2f47d4fa4  vmovaps [rsp+0xA0], xmm10
00007cc2f47d4fad  vmovaps [rsp+0xB0], xmm11
00007cc2f47d4fb6  vmovaps [rsp+0xC0], xmm12
00007cc2f47d4fbf  vmovaps [rsp+0xD0], xmm13
00007cc2f47d4fc8  vmovaps [rsp+0xE0], xmm15
00007cc2f47d4fd1  sub rsp, 0x30
00007cc2f47d4fd5  movaps [rsp], xmm14
00007cc2f47d4fda  movaps [rsp+0x10], xmm13
00007cc2f47d4fe0  movaps [rsp+0x20], xmm2
00007cc2f47d4fe5  lea rdi, [rsp]
00007cc2f47d4fe9  mov esi, 0x00
00007cc2f47d4fee  mov rax, 0x5990E710A530
00007cc2f47d4ff8  call rax
00007cc2f47d4ffa  movaps xmm14, [rsp]
00007cc2f47d4fff  add rsp, 0x30
00007cc2f47d5003  vmovaps xmm0, [rsp]
00007cc2f47d5008  vmovaps xmm1, [rsp+0x10]
00007cc2f47d500e  vmovaps xmm2, [rsp+0x20]
00007cc2f47d5014  vmovaps xmm3, [rsp+0x30]
00007cc2f47d501a  vmovaps xmm4, [rsp+0x40]
00007cc2f47d5020  vmovaps xmm5, [rsp+0x50]
00007cc2f47d5026  vmovaps xmm6, [rsp+0x60]
00007cc2f47d502c  vmovaps xmm7, [rsp+0x70]
00007cc2f47d5032  vmovaps xmm8, [rsp+0x80]
00007cc2f47d503b  vmovaps xmm9, [rsp+0x90]
00007cc2f47d5044  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d504d  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d5056  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d505f  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d5068  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d5071  add rsp, 0xF0
00007cc2f47d5078  pop r11
00007cc2f47d507a  pop r10
00007cc2f47d507c  pop r9
00007cc2f47d507e  pop r8
00007cc2f47d5080  pop rsi
00007cc2f47d5081  pop rdi
00007cc2f47d5082  pop rdx
00007cc2f47d5083  pop rcx
00007cc2f47d5084  pop rax
00007cc2f47d5085  add rsp, 0x08
00007cc2f47d5089  jmp 0x00007CC2F47D2D4B
00007cc2f47d508e  sub rsp, 0x08
00007cc2f47d5092  push rax
00007cc2f47d5093  push rcx
00007cc2f47d5094  push rdx
00007cc2f47d5095  push rdi
00007cc2f47d5096  push rsi
00007cc2f47d5097  push r8
00007cc2f47d5099  push r9
00007cc2f47d509b  push r10
00007cc2f47d509d  push r11
00007cc2f47d509f  sub rsp, 0xF0
00007cc2f47d50a6  vmovaps [rsp], xmm0
00007cc2f47d50ab  vmovaps [rsp+0x10], xmm2
00007cc2f47d50b1  vmovaps [rsp+0x20], xmm3
00007cc2f47d50b7  vmovaps [rsp+0x30], xmm4
00007cc2f47d50bd  vmovaps [rsp+0x40], xmm5
00007cc2f47d50c3  vmovaps [rsp+0x50], xmm6
00007cc2f47d50c9  vmovaps [rsp+0x60], xmm7
00007cc2f47d50cf  vmovaps [rsp+0x70], xmm8
00007cc2f47d50d5  vmovaps [rsp+0x80], xmm9
00007cc2f47d50de  vmovaps [rsp+0x90], xmm10
00007cc2f47d50e7  vmovaps [rsp+0xA0], xmm11
00007cc2f47d50f0  vmovaps [rsp+0xB0], xmm12
00007cc2f47d50f9  vmovaps [rsp+0xC0], xmm13
00007cc2f47d5102  vmovaps [rsp+0xD0], xmm14
00007cc2f47d510b  vmovaps [rsp+0xE0], xmm15
00007cc2f47d5114  sub rsp, 0x30
00007cc2f47d5118  movaps [rsp], xmm1
00007cc2f47d511c  movaps [rsp+0x10], xmm13
00007cc2f47d5122  movaps [rsp+0x20], xmm2
00007cc2f47d5127  lea rdi, [rsp]
00007cc2f47d512b  mov esi, 0x00
00007cc2f47d5130  mov rax, 0x5990E710A530
00007cc2f47d513a  call rax
00007cc2f47d513c  movaps xmm1, [rsp]
00007cc2f47d5140  add rsp, 0x30
00007cc2f47d5144  vmovaps xmm0, [rsp]
00007cc2f47d5149  vmovaps xmm2, [rsp+0x10]
00007cc2f47d514f  vmovaps xmm3, [rsp+0x20]
00007cc2f47d5155  vmovaps xmm4, [rsp+0x30]
00007cc2f47d515b  vmovaps xmm5, [rsp+0x40]
00007cc2f47d5161  vmovaps xmm6, [rsp+0x50]
00007cc2f47d5167  vmovaps xmm7, [rsp+0x60]
00007cc2f47d516d  vmovaps xmm8, [rsp+0x70]
00007cc2f47d5173  vmovaps xmm9, [rsp+0x80]
00007cc2f47d517c  vmovaps xmm10, [rsp+0x90]
00007cc2f47d5185  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d518e  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d5197  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d51a0  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d51a9  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d51b2  add rsp, 0xF0
00007cc2f47d51b9  pop r11
00007cc2f47d51bb  pop r10
00007cc2f47d51bd  pop r9
00007cc2f47d51bf  pop r8
00007cc2f47d51c1  pop rsi
00007cc2f47d51c2  pop rdi
00007cc2f47d51c3  pop rdx
00007cc2f47d51c4  pop rcx
00007cc2f47d51c5  pop rax
00007cc2f47d51c6  add rsp, 0x08
00007cc2f47d51ca  jmp 0x00007CC2F47D2D79
00007cc2f47d51cf  sub rsp, 0x08
00007cc2f47d51d3  push rax
00007cc2f47d51d4  push rcx
00007cc2f47d51d5  push rdx
00007cc2f47d51d6  push rdi
00007cc2f47d51d7  push rsi
00007cc2f47d51d8  push r8
00007cc2f47d51da  push r9
00007cc2f47d51dc  push r10
00007cc2f47d51de  push r11
00007cc2f47d51e0  sub rsp, 0xF0
00007cc2f47d51e7  vmovaps [rsp], xmm0
00007cc2f47d51ec  vmovaps [rsp+0x10], xmm1
00007cc2f47d51f2  vmovaps [rsp+0x20], xmm3
00007cc2f47d51f8  vmovaps [rsp+0x30], xmm4
00007cc2f47d51fe  vmovaps [rsp+0x40], xmm5
00007cc2f47d5204  vmovaps [rsp+0x50], xmm6
00007cc2f47d520a  vmovaps [rsp+0x60], xmm7
00007cc2f47d5210  vmovaps [rsp+0x70], xmm8
00007cc2f47d5216  vmovaps [rsp+0x80], xmm9
00007cc2f47d521f  vmovaps [rsp+0x90], xmm10
00007cc2f47d5228  vmovaps [rsp+0xA0], xmm11
00007cc2f47d5231  vmovaps [rsp+0xB0], xmm12
00007cc2f47d523a  vmovaps [rsp+0xC0], xmm13
00007cc2f47d5243  vmovaps [rsp+0xD0], xmm14
00007cc2f47d524c  vmovaps [rsp+0xE0], xmm15
00007cc2f47d5255  sub rsp, 0x30
00007cc2f47d5259  movaps [rsp], xmm2
00007cc2f47d525d  movaps [rsp+0x10], xmm1
00007cc2f47d5262  movaps [rsp+0x20], xmm13
00007cc2f47d5268  lea rdi, [rsp]
00007cc2f47d526c  mov esi, 0x00
00007cc2f47d5271  mov rax, 0x5990E710A530
00007cc2f47d527b  call rax
00007cc2f47d527d  movaps xmm2, [rsp]
00007cc2f47d5281  add rsp, 0x30
00007cc2f47d5285  vmovaps xmm0, [rsp]
00007cc2f47d528a  vmovaps xmm1, [rsp+0x10]
00007cc2f47d5290  vmovaps xmm3, [rsp+0x20]
00007cc2f47d5296  vmovaps xmm4, [rsp+0x30]
00007cc2f47d529c  vmovaps xmm5, [rsp+0x40]
00007cc2f47d52a2  vmovaps xmm6, [rsp+0x50]
00007cc2f47d52a8  vmovaps xmm7, [rsp+0x60]
00007cc2f47d52ae  vmovaps xmm8, [rsp+0x70]
00007cc2f47d52b4  vmovaps xmm9, [rsp+0x80]
00007cc2f47d52bd  vmovaps xmm10, [rsp+0x90]
00007cc2f47d52c6  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d52cf  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d52d8  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d52e1  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d52ea  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d52f3  add rsp, 0xF0
00007cc2f47d52fa  pop r11
00007cc2f47d52fc  pop r10
00007cc2f47d52fe  pop r9
00007cc2f47d5300  pop r8
00007cc2f47d5302  pop rsi
00007cc2f47d5303  pop rdi
00007cc2f47d5304  pop rdx
00007cc2f47d5305  pop rcx
00007cc2f47d5306  pop rax
00007cc2f47d5307  add rsp, 0x08
00007cc2f47d530b  jmp 0x00007CC2F47D2DD2
00007cc2f47d5310  call 0x00007CC2F45FF430
00007cc2f47d5315  jmp 0x00007CC2F47D2DDF
00007cc2f47d531a  sub rsp, 0x08
00007cc2f47d531e  push rax
00007cc2f47d531f  push rcx
00007cc2f47d5320  push rdx
00007cc2f47d5321  push rdi
00007cc2f47d5322  push rsi
00007cc2f47d5323  push r8
00007cc2f47d5325  push r9
00007cc2f47d5327  push r10
00007cc2f47d5329  push r11
00007cc2f47d532b  sub rsp, 0xF0
00007cc2f47d5332  vmovaps [rsp], xmm0
00007cc2f47d5337  vmovaps [rsp+0x10], xmm1
00007cc2f47d533d  vmovaps [rsp+0x20], xmm2
00007cc2f47d5343  vmovaps [rsp+0x30], xmm3
00007cc2f47d5349  vmovaps [rsp+0x40], xmm4
00007cc2f47d534f  vmovaps [rsp+0x50], xmm5
00007cc2f47d5355  vmovaps [rsp+0x60], xmm6
00007cc2f47d535b  vmovaps [rsp+0x70], xmm7
00007cc2f47d5361  vmovaps [rsp+0x80], xmm8
00007cc2f47d536a  vmovaps [rsp+0x90], xmm9
00007cc2f47d5373  vmovaps [rsp+0xA0], xmm10
00007cc2f47d537c  vmovaps [rsp+0xB0], xmm11
00007cc2f47d5385  vmovaps [rsp+0xC0], xmm12
00007cc2f47d538e  vmovaps [rsp+0xD0], xmm13
00007cc2f47d5397  vmovaps [rsp+0xE0], xmm14
00007cc2f47d53a0  sub rsp, 0x30
00007cc2f47d53a4  movaps [rsp], xmm15
00007cc2f47d53a9  movaps [rsp+0x10], xmm13
00007cc2f47d53af  movaps [rsp+0x20], xmm1
00007cc2f47d53b4  lea rdi, [rsp]
00007cc2f47d53b8  mov esi, 0x00
00007cc2f47d53bd  mov rax, 0x5990E710A530
00007cc2f47d53c7  call rax
00007cc2f47d53c9  movaps xmm15, [rsp]
00007cc2f47d53ce  add rsp, 0x30
00007cc2f47d53d2  vmovaps xmm0, [rsp]
00007cc2f47d53d7  vmovaps xmm1, [rsp+0x10]
00007cc2f47d53dd  vmovaps xmm2, [rsp+0x20]
00007cc2f47d53e3  vmovaps xmm3, [rsp+0x30]
00007cc2f47d53e9  vmovaps xmm4, [rsp+0x40]
00007cc2f47d53ef  vmovaps xmm5, [rsp+0x50]
00007cc2f47d53f5  vmovaps xmm6, [rsp+0x60]
00007cc2f47d53fb  vmovaps xmm7, [rsp+0x70]
00007cc2f47d5401  vmovaps xmm8, [rsp+0x80]
00007cc2f47d540a  vmovaps xmm9, [rsp+0x90]
00007cc2f47d5413  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d541c  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d5425  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d542e  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d5437  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d5440  add rsp, 0xF0
00007cc2f47d5447  pop r11
00007cc2f47d5449  pop r10
00007cc2f47d544b  pop r9
00007cc2f47d544d  pop r8
00007cc2f47d544f  pop rsi
00007cc2f47d5450  pop rdi
00007cc2f47d5451  pop rdx
00007cc2f47d5452  pop rcx
00007cc2f47d5453  pop rax
00007cc2f47d5454  add rsp, 0x08
00007cc2f47d5458  jmp 0x00007CC2F47D2E1E
00007cc2f47d545d  sub rsp, 0x08
00007cc2f47d5461  push rax
00007cc2f47d5462  push rcx
00007cc2f47d5463  push rdx
00007cc2f47d5464  push rdi
00007cc2f47d5465  push rsi
00007cc2f47d5466  push r8
00007cc2f47d5468  push r9
00007cc2f47d546a  push r10
00007cc2f47d546c  push r11
00007cc2f47d546e  sub rsp, 0xF0
00007cc2f47d5475  vmovaps [rsp], xmm0
00007cc2f47d547a  vmovaps [rsp+0x10], xmm1
00007cc2f47d5480  vmovaps [rsp+0x20], xmm2
00007cc2f47d5486  vmovaps [rsp+0x30], xmm3
00007cc2f47d548c  vmovaps [rsp+0x40], xmm4
00007cc2f47d5492  vmovaps [rsp+0x50], xmm5
00007cc2f47d5498  vmovaps [rsp+0x60], xmm6
00007cc2f47d549e  vmovaps [rsp+0x70], xmm7
00007cc2f47d54a4  vmovaps [rsp+0x80], xmm8
00007cc2f47d54ad  vmovaps [rsp+0x90], xmm9
00007cc2f47d54b6  vmovaps [rsp+0xA0], xmm10
00007cc2f47d54bf  vmovaps [rsp+0xB0], xmm11
00007cc2f47d54c8  vmovaps [rsp+0xC0], xmm12
00007cc2f47d54d1  vmovaps [rsp+0xD0], xmm13
00007cc2f47d54da  vmovaps [rsp+0xE0], xmm15
00007cc2f47d54e3  sub rsp, 0x30
00007cc2f47d54e7  movaps [rsp], xmm14
00007cc2f47d54ec  movaps [rsp+0x10], xmm11
00007cc2f47d54f2  movaps [rsp+0x20], xmm1
00007cc2f47d54f7  lea rdi, [rsp]
00007cc2f47d54fb  mov esi, 0x00
00007cc2f47d5500  mov rax, 0x5990E710A530
00007cc2f47d550a  call rax
00007cc2f47d550c  movaps xmm14, [rsp]
00007cc2f47d5511  add rsp, 0x30
00007cc2f47d5515  vmovaps xmm0, [rsp]
00007cc2f47d551a  vmovaps xmm1, [rsp+0x10]
00007cc2f47d5520  vmovaps xmm2, [rsp+0x20]
00007cc2f47d5526  vmovaps xmm3, [rsp+0x30]
00007cc2f47d552c  vmovaps xmm4, [rsp+0x40]
00007cc2f47d5532  vmovaps xmm5, [rsp+0x50]
00007cc2f47d5538  vmovaps xmm6, [rsp+0x60]
00007cc2f47d553e  vmovaps xmm7, [rsp+0x70]
00007cc2f47d5544  vmovaps xmm8, [rsp+0x80]
00007cc2f47d554d  vmovaps xmm9, [rsp+0x90]
00007cc2f47d5556  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d555f  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d5568  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d5571  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d557a  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d5583  add rsp, 0xF0
00007cc2f47d558a  pop r11
00007cc2f47d558c  pop r10
00007cc2f47d558e  pop r9
00007cc2f47d5590  pop r8
00007cc2f47d5592  pop rsi
00007cc2f47d5593  pop rdi
00007cc2f47d5594  pop rdx
00007cc2f47d5595  pop rcx
00007cc2f47d5596  pop rax
00007cc2f47d5597  add rsp, 0x08
00007cc2f47d559b  jmp 0x00007CC2F47D2E48
00007cc2f47d55a0  sub rsp, 0x08
00007cc2f47d55a4  push rax
00007cc2f47d55a5  push rcx
00007cc2f47d55a6  push rdx
00007cc2f47d55a7  push rdi
00007cc2f47d55a8  push rsi
00007cc2f47d55a9  push r8
00007cc2f47d55ab  push r9
00007cc2f47d55ad  push r10
00007cc2f47d55af  push r11
00007cc2f47d55b1  sub rsp, 0xF0
00007cc2f47d55b8  vmovaps [rsp], xmm0
00007cc2f47d55bd  vmovaps [rsp+0x10], xmm1
00007cc2f47d55c3  vmovaps [rsp+0x20], xmm2
00007cc2f47d55c9  vmovaps [rsp+0x30], xmm3
00007cc2f47d55cf  vmovaps [rsp+0x40], xmm4
00007cc2f47d55d5  vmovaps [rsp+0x50], xmm5
00007cc2f47d55db  vmovaps [rsp+0x60], xmm6
00007cc2f47d55e1  vmovaps [rsp+0x70], xmm7
00007cc2f47d55e7  vmovaps [rsp+0x80], xmm8
00007cc2f47d55f0  vmovaps [rsp+0x90], xmm9
00007cc2f47d55f9  vmovaps [rsp+0xA0], xmm10
00007cc2f47d5602  vmovaps [rsp+0xB0], xmm11
00007cc2f47d560b  vmovaps [rsp+0xC0], xmm12
00007cc2f47d5614  vmovaps [rsp+0xD0], xmm14
00007cc2f47d561d  vmovaps [rsp+0xE0], xmm15
00007cc2f47d5626  sub rsp, 0x30
00007cc2f47d562a  movaps [rsp], xmm13
00007cc2f47d562f  movaps [rsp+0x10], xmm11
00007cc2f47d5635  movaps [rsp+0x20], xmm1
00007cc2f47d563a  lea rdi, [rsp]
00007cc2f47d563e  mov esi, 0x00
00007cc2f47d5643  mov rax, 0x5990E710A530
00007cc2f47d564d  call rax
00007cc2f47d564f  movaps xmm13, [rsp]
00007cc2f47d5654  add rsp, 0x30
00007cc2f47d5658  vmovaps xmm0, [rsp]
00007cc2f47d565d  vmovaps xmm1, [rsp+0x10]
00007cc2f47d5663  vmovaps xmm2, [rsp+0x20]
00007cc2f47d5669  vmovaps xmm3, [rsp+0x30]
00007cc2f47d566f  vmovaps xmm4, [rsp+0x40]
00007cc2f47d5675  vmovaps xmm5, [rsp+0x50]
00007cc2f47d567b  vmovaps xmm6, [rsp+0x60]
00007cc2f47d5681  vmovaps xmm7, [rsp+0x70]
00007cc2f47d5687  vmovaps xmm8, [rsp+0x80]
00007cc2f47d5690  vmovaps xmm9, [rsp+0x90]
00007cc2f47d5699  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d56a2  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d56ab  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d56b4  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d56bd  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d56c6  add rsp, 0xF0
00007cc2f47d56cd  pop r11
00007cc2f47d56cf  pop r10
00007cc2f47d56d1  pop r9
00007cc2f47d56d3  pop r8
00007cc2f47d56d5  pop rsi
00007cc2f47d56d6  pop rdi
00007cc2f47d56d7  pop rdx
00007cc2f47d56d8  pop rcx
00007cc2f47d56d9  pop rax
00007cc2f47d56da  add rsp, 0x08
00007cc2f47d56de  jmp 0x00007CC2F47D2E9D
00007cc2f47d56e3  call 0x00007CC2F45FF430
00007cc2f47d56e8  jmp 0x00007CC2F47D2EAA
00007cc2f47d56ed  sub rsp, 0x08
00007cc2f47d56f1  push rax
00007cc2f47d56f2  push rcx
00007cc2f47d56f3  push rdx
00007cc2f47d56f4  push rdi
00007cc2f47d56f5  push rsi
00007cc2f47d56f6  push r8
00007cc2f47d56f8  push r9
00007cc2f47d56fa  push r10
00007cc2f47d56fc  push r11
00007cc2f47d56fe  sub rsp, 0xF0
00007cc2f47d5705  vmovaps [rsp], xmm0
00007cc2f47d570a  vmovaps [rsp+0x10], xmm1
00007cc2f47d5710  vmovaps [rsp+0x20], xmm2
00007cc2f47d5716  vmovaps [rsp+0x30], xmm3
00007cc2f47d571c  vmovaps [rsp+0x40], xmm4
00007cc2f47d5722  vmovaps [rsp+0x50], xmm5
00007cc2f47d5728  vmovaps [rsp+0x60], xmm6
00007cc2f47d572e  vmovaps [rsp+0x70], xmm7
00007cc2f47d5734  vmovaps [rsp+0x80], xmm8
00007cc2f47d573d  vmovaps [rsp+0x90], xmm9
00007cc2f47d5746  vmovaps [rsp+0xA0], xmm10
00007cc2f47d574f  vmovaps [rsp+0xB0], xmm11
00007cc2f47d5758  vmovaps [rsp+0xC0], xmm12
00007cc2f47d5761  vmovaps [rsp+0xD0], xmm13
00007cc2f47d576a  vmovaps [rsp+0xE0], xmm14
00007cc2f47d5773  sub rsp, 0x30
00007cc2f47d5777  movaps [rsp], xmm15
00007cc2f47d577c  movaps [rsp+0x10], xmm11
00007cc2f47d5782  movaps [rsp+0x20], xmm1
00007cc2f47d5787  lea rdi, [rsp]
00007cc2f47d578b  mov esi, 0x00
00007cc2f47d5790  mov rax, 0x5990E710A530
00007cc2f47d579a  call rax
00007cc2f47d579c  movaps xmm15, [rsp]
00007cc2f47d57a1  add rsp, 0x30
00007cc2f47d57a5  vmovaps xmm0, [rsp]
00007cc2f47d57aa  vmovaps xmm1, [rsp+0x10]
00007cc2f47d57b0  vmovaps xmm2, [rsp+0x20]
00007cc2f47d57b6  vmovaps xmm3, [rsp+0x30]
00007cc2f47d57bc  vmovaps xmm4, [rsp+0x40]
00007cc2f47d57c2  vmovaps xmm5, [rsp+0x50]
00007cc2f47d57c8  vmovaps xmm6, [rsp+0x60]
00007cc2f47d57ce  vmovaps xmm7, [rsp+0x70]
00007cc2f47d57d4  vmovaps xmm8, [rsp+0x80]
00007cc2f47d57dd  vmovaps xmm9, [rsp+0x90]
00007cc2f47d57e6  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d57ef  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d57f8  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d5801  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d580a  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d5813  add rsp, 0xF0
00007cc2f47d581a  pop r11
00007cc2f47d581c  pop r10
00007cc2f47d581e  pop r9
00007cc2f47d5820  pop r8
00007cc2f47d5822  pop rsi
00007cc2f47d5823  pop rdi
00007cc2f47d5824  pop rdx
00007cc2f47d5825  pop rcx
00007cc2f47d5826  pop rax
00007cc2f47d5827  add rsp, 0x08
00007cc2f47d582b  jmp 0x00007CC2F47D2EE3
00007cc2f47d5830  sub rsp, 0x08
00007cc2f47d5834  push rax
00007cc2f47d5835  push rcx
00007cc2f47d5836  push rdx
00007cc2f47d5837  push rdi
00007cc2f47d5838  push rsi
00007cc2f47d5839  push r8
00007cc2f47d583b  push r9
00007cc2f47d583d  push r10
00007cc2f47d583f  push r11
00007cc2f47d5841  sub rsp, 0xF0
00007cc2f47d5848  vmovaps [rsp], xmm0
00007cc2f47d584d  vmovaps [rsp+0x10], xmm1
00007cc2f47d5853  vmovaps [rsp+0x20], xmm2
00007cc2f47d5859  vmovaps [rsp+0x30], xmm3
00007cc2f47d585f  vmovaps [rsp+0x40], xmm4
00007cc2f47d5865  vmovaps [rsp+0x50], xmm5
00007cc2f47d586b  vmovaps [rsp+0x60], xmm6
00007cc2f47d5871  vmovaps [rsp+0x70], xmm7
00007cc2f47d5877  vmovaps [rsp+0x80], xmm8
00007cc2f47d5880  vmovaps [rsp+0x90], xmm9
00007cc2f47d5889  vmovaps [rsp+0xA0], xmm10
00007cc2f47d5892  vmovaps [rsp+0xB0], xmm12
00007cc2f47d589b  vmovaps [rsp+0xC0], xmm13
00007cc2f47d58a4  vmovaps [rsp+0xD0], xmm14
00007cc2f47d58ad  vmovaps [rsp+0xE0], xmm15
00007cc2f47d58b6  sub rsp, 0x30
00007cc2f47d58ba  movaps [rsp], xmm11
00007cc2f47d58bf  movaps [rsp+0x10], xmm6
00007cc2f47d58c4  movaps [rsp+0x20], xmm14
00007cc2f47d58ca  lea rdi, [rsp]
00007cc2f47d58ce  mov esi, 0x00
00007cc2f47d58d3  mov rax, 0x5990E710A530
00007cc2f47d58dd  call rax
00007cc2f47d58df  movaps xmm11, [rsp]
00007cc2f47d58e4  add rsp, 0x30
00007cc2f47d58e8  vmovaps xmm0, [rsp]
00007cc2f47d58ed  vmovaps xmm1, [rsp+0x10]
00007cc2f47d58f3  vmovaps xmm2, [rsp+0x20]
00007cc2f47d58f9  vmovaps xmm3, [rsp+0x30]
00007cc2f47d58ff  vmovaps xmm4, [rsp+0x40]
00007cc2f47d5905  vmovaps xmm5, [rsp+0x50]
00007cc2f47d590b  vmovaps xmm6, [rsp+0x60]
00007cc2f47d5911  vmovaps xmm7, [rsp+0x70]
00007cc2f47d5917  vmovaps xmm8, [rsp+0x80]
00007cc2f47d5920  vmovaps xmm9, [rsp+0x90]
00007cc2f47d5929  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d5932  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d593b  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d5944  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d594d  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d5956  add rsp, 0xF0
00007cc2f47d595d  pop r11
00007cc2f47d595f  pop r10
00007cc2f47d5961  pop r9
00007cc2f47d5963  pop r8
00007cc2f47d5965  pop rsi
00007cc2f47d5966  pop rdi
00007cc2f47d5967  pop rdx
00007cc2f47d5968  pop rcx
00007cc2f47d5969  pop rax
00007cc2f47d596a  add rsp, 0x08
00007cc2f47d596e  jmp 0x00007CC2F47D2F5B
00007cc2f47d5973  call 0x00007CC2F45FF430
00007cc2f47d5978  jmp 0x00007CC2F47D2F65
00007cc2f47d597d  sub rsp, 0x08
00007cc2f47d5981  push rax
00007cc2f47d5982  push rcx
00007cc2f47d5983  push rdx
00007cc2f47d5984  push rdi
00007cc2f47d5985  push rsi
00007cc2f47d5986  push r8
00007cc2f47d5988  push r9
00007cc2f47d598a  push r10
00007cc2f47d598c  push r11
00007cc2f47d598e  sub rsp, 0xF0
00007cc2f47d5995  vmovaps [rsp], xmm0
00007cc2f47d599a  vmovaps [rsp+0x10], xmm1
00007cc2f47d59a0  vmovaps [rsp+0x20], xmm2
00007cc2f47d59a6  vmovaps [rsp+0x30], xmm3
00007cc2f47d59ac  vmovaps [rsp+0x40], xmm4
00007cc2f47d59b2  vmovaps [rsp+0x50], xmm5
00007cc2f47d59b8  vmovaps [rsp+0x60], xmm6
00007cc2f47d59be  vmovaps [rsp+0x70], xmm7
00007cc2f47d59c4  vmovaps [rsp+0x80], xmm8
00007cc2f47d59cd  vmovaps [rsp+0x90], xmm9
00007cc2f47d59d6  vmovaps [rsp+0xA0], xmm10
00007cc2f47d59df  vmovaps [rsp+0xB0], xmm11
00007cc2f47d59e8  vmovaps [rsp+0xC0], xmm12
00007cc2f47d59f1  vmovaps [rsp+0xD0], xmm13
00007cc2f47d59fa  vmovaps [rsp+0xE0], xmm15
00007cc2f47d5a03  sub rsp, 0x30
00007cc2f47d5a07  movaps [rsp], xmm14
00007cc2f47d5a0c  movaps [rsp+0x10], xmm6
00007cc2f47d5a11  movaps [rsp+0x20], xmm2
00007cc2f47d5a16  lea rdi, [rsp]
00007cc2f47d5a1a  mov esi, 0x00
00007cc2f47d5a1f  mov rax, 0x5990E710A530
00007cc2f47d5a29  call rax
00007cc2f47d5a2b  movaps xmm14, [rsp]
00007cc2f47d5a30  add rsp, 0x30
00007cc2f47d5a34  vmovaps xmm0, [rsp]
00007cc2f47d5a39  vmovaps xmm1, [rsp+0x10]
00007cc2f47d5a3f  vmovaps xmm2, [rsp+0x20]
00007cc2f47d5a45  vmovaps xmm3, [rsp+0x30]
00007cc2f47d5a4b  vmovaps xmm4, [rsp+0x40]
00007cc2f47d5a51  vmovaps xmm5, [rsp+0x50]
00007cc2f47d5a57  vmovaps xmm6, [rsp+0x60]
00007cc2f47d5a5d  vmovaps xmm7, [rsp+0x70]
00007cc2f47d5a63  vmovaps xmm8, [rsp+0x80]
00007cc2f47d5a6c  vmovaps xmm9, [rsp+0x90]
00007cc2f47d5a75  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d5a7e  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d5a87  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d5a90  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d5a99  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d5aa2  add rsp, 0xF0
00007cc2f47d5aa9  pop r11
00007cc2f47d5aab  pop r10
00007cc2f47d5aad  pop r9
00007cc2f47d5aaf  pop r8
00007cc2f47d5ab1  pop rsi
00007cc2f47d5ab2  pop rdi
00007cc2f47d5ab3  pop rdx
00007cc2f47d5ab4  pop rcx
00007cc2f47d5ab5  pop rax
00007cc2f47d5ab6  add rsp, 0x08
00007cc2f47d5aba  jmp 0x00007CC2F47D2F99
00007cc2f47d5abf  sub rsp, 0x08
00007cc2f47d5ac3  push rax
00007cc2f47d5ac4  push rcx
00007cc2f47d5ac5  push rdx
00007cc2f47d5ac6  push rdi
00007cc2f47d5ac7  push rsi
00007cc2f47d5ac8  push r8
00007cc2f47d5aca  push r9
00007cc2f47d5acc  push r10
00007cc2f47d5ace  push r11
00007cc2f47d5ad0  sub rsp, 0xF0
00007cc2f47d5ad7  vmovaps [rsp], xmm0
00007cc2f47d5adc  vmovaps [rsp+0x10], xmm1
00007cc2f47d5ae2  vmovaps [rsp+0x20], xmm2
00007cc2f47d5ae8  vmovaps [rsp+0x30], xmm3
00007cc2f47d5aee  vmovaps [rsp+0x40], xmm4
00007cc2f47d5af4  vmovaps [rsp+0x50], xmm5
00007cc2f47d5afa  vmovaps [rsp+0x60], xmm7
00007cc2f47d5b00  vmovaps [rsp+0x70], xmm8
00007cc2f47d5b06  vmovaps [rsp+0x80], xmm9
00007cc2f47d5b0f  vmovaps [rsp+0x90], xmm10
00007cc2f47d5b18  vmovaps [rsp+0xA0], xmm11
00007cc2f47d5b21  vmovaps [rsp+0xB0], xmm12
00007cc2f47d5b2a  vmovaps [rsp+0xC0], xmm13
00007cc2f47d5b33  vmovaps [rsp+0xD0], xmm14
00007cc2f47d5b3c  vmovaps [rsp+0xE0], xmm15
00007cc2f47d5b45  sub rsp, 0x30
00007cc2f47d5b49  movaps [rsp], xmm6
00007cc2f47d5b4d  movaps [rsp+0x10], xmm5
00007cc2f47d5b52  movaps [rsp+0x20], xmm1
00007cc2f47d5b57  lea rdi, [rsp]
00007cc2f47d5b5b  mov esi, 0x00
00007cc2f47d5b60  mov rax, 0x5990E710A530
00007cc2f47d5b6a  call rax
00007cc2f47d5b6c  movaps xmm6, [rsp]
00007cc2f47d5b70  add rsp, 0x30
00007cc2f47d5b74  vmovaps xmm0, [rsp]
00007cc2f47d5b79  vmovaps xmm1, [rsp+0x10]
00007cc2f47d5b7f  vmovaps xmm2, [rsp+0x20]
00007cc2f47d5b85  vmovaps xmm3, [rsp+0x30]
00007cc2f47d5b8b  vmovaps xmm4, [rsp+0x40]
00007cc2f47d5b91  vmovaps xmm5, [rsp+0x50]
00007cc2f47d5b97  vmovaps xmm7, [rsp+0x60]
00007cc2f47d5b9d  vmovaps xmm8, [rsp+0x70]
00007cc2f47d5ba3  vmovaps xmm9, [rsp+0x80]
00007cc2f47d5bac  vmovaps xmm10, [rsp+0x90]
00007cc2f47d5bb5  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d5bbe  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d5bc7  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d5bd0  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d5bd9  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d5be2  add rsp, 0xF0
00007cc2f47d5be9  pop r11
00007cc2f47d5beb  pop r10
00007cc2f47d5bed  pop r9
00007cc2f47d5bef  pop r8
00007cc2f47d5bf1  pop rsi
00007cc2f47d5bf2  pop rdi
00007cc2f47d5bf3  pop rdx
00007cc2f47d5bf4  pop rcx
00007cc2f47d5bf5  pop rax
00007cc2f47d5bf6  add rsp, 0x08
00007cc2f47d5bfa  jmp 0x00007CC2F47D2FBF
00007cc2f47d5bff  sub rsp, 0x08
00007cc2f47d5c03  push rax
00007cc2f47d5c04  push rcx
00007cc2f47d5c05  push rdx
00007cc2f47d5c06  push rdi
00007cc2f47d5c07  push rsi
00007cc2f47d5c08  push r8
00007cc2f47d5c0a  push r9
00007cc2f47d5c0c  push r10
00007cc2f47d5c0e  push r11
00007cc2f47d5c10  sub rsp, 0xF0
00007cc2f47d5c17  vmovaps [rsp], xmm0
00007cc2f47d5c1c  vmovaps [rsp+0x10], xmm2
00007cc2f47d5c22  vmovaps [rsp+0x20], xmm3
00007cc2f47d5c28  vmovaps [rsp+0x30], xmm4
00007cc2f47d5c2e  vmovaps [rsp+0x40], xmm5
00007cc2f47d5c34  vmovaps [rsp+0x50], xmm6
00007cc2f47d5c3a  vmovaps [rsp+0x60], xmm7
00007cc2f47d5c40  vmovaps [rsp+0x70], xmm8
00007cc2f47d5c46  vmovaps [rsp+0x80], xmm9
00007cc2f47d5c4f  vmovaps [rsp+0x90], xmm10
00007cc2f47d5c58  vmovaps [rsp+0xA0], xmm11
00007cc2f47d5c61  vmovaps [rsp+0xB0], xmm12
00007cc2f47d5c6a  vmovaps [rsp+0xC0], xmm13
00007cc2f47d5c73  vmovaps [rsp+0xD0], xmm14
00007cc2f47d5c7c  vmovaps [rsp+0xE0], xmm15
00007cc2f47d5c85  sub rsp, 0x30
00007cc2f47d5c89  movaps [rsp], xmm1
00007cc2f47d5c8d  movaps [rsp+0x10], xmm5
00007cc2f47d5c92  movaps [rsp+0x20], xmm13
00007cc2f47d5c98  lea rdi, [rsp]
00007cc2f47d5c9c  mov esi, 0x00
00007cc2f47d5ca1  mov rax, 0x5990E710A530
00007cc2f47d5cab  call rax
00007cc2f47d5cad  movaps xmm1, [rsp]
00007cc2f47d5cb1  add rsp, 0x30
00007cc2f47d5cb5  vmovaps xmm0, [rsp]
00007cc2f47d5cba  vmovaps xmm2, [rsp+0x10]
00007cc2f47d5cc0  vmovaps xmm3, [rsp+0x20]
00007cc2f47d5cc6  vmovaps xmm4, [rsp+0x30]
00007cc2f47d5ccc  vmovaps xmm5, [rsp+0x40]
00007cc2f47d5cd2  vmovaps xmm6, [rsp+0x50]
00007cc2f47d5cd8  vmovaps xmm7, [rsp+0x60]
00007cc2f47d5cde  vmovaps xmm8, [rsp+0x70]
00007cc2f47d5ce4  vmovaps xmm9, [rsp+0x80]
00007cc2f47d5ced  vmovaps xmm10, [rsp+0x90]
00007cc2f47d5cf6  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d5cff  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d5d08  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d5d11  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d5d1a  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d5d23  add rsp, 0xF0
00007cc2f47d5d2a  pop r11
00007cc2f47d5d2c  pop r10
00007cc2f47d5d2e  pop r9
00007cc2f47d5d30  pop r8
00007cc2f47d5d32  pop rsi
00007cc2f47d5d33  pop rdi
00007cc2f47d5d34  pop rdx
00007cc2f47d5d35  pop rcx
00007cc2f47d5d36  pop rax
00007cc2f47d5d37  add rsp, 0x08
00007cc2f47d5d3b  jmp 0x00007CC2F47D2FDD
00007cc2f47d5d40  sub rsp, 0x08
00007cc2f47d5d44  push rax
00007cc2f47d5d45  push rcx
00007cc2f47d5d46  push rdx
00007cc2f47d5d47  push rdi
00007cc2f47d5d48  push rsi
00007cc2f47d5d49  push r8
00007cc2f47d5d4b  push r9
00007cc2f47d5d4d  push r10
00007cc2f47d5d4f  push r11
00007cc2f47d5d51  sub rsp, 0xF0
00007cc2f47d5d58  vmovaps [rsp], xmm0
00007cc2f47d5d5d  vmovaps [rsp+0x10], xmm1
00007cc2f47d5d63  vmovaps [rsp+0x20], xmm2
00007cc2f47d5d69  vmovaps [rsp+0x30], xmm3
00007cc2f47d5d6f  vmovaps [rsp+0x40], xmm4
00007cc2f47d5d75  vmovaps [rsp+0x50], xmm6
00007cc2f47d5d7b  vmovaps [rsp+0x60], xmm7
00007cc2f47d5d81  vmovaps [rsp+0x70], xmm8
00007cc2f47d5d87  vmovaps [rsp+0x80], xmm9
00007cc2f47d5d90  vmovaps [rsp+0x90], xmm10
00007cc2f47d5d99  vmovaps [rsp+0xA0], xmm11
00007cc2f47d5da2  vmovaps [rsp+0xB0], xmm12
00007cc2f47d5dab  vmovaps [rsp+0xC0], xmm13
00007cc2f47d5db4  vmovaps [rsp+0xD0], xmm14
00007cc2f47d5dbd  vmovaps [rsp+0xE0], xmm15
00007cc2f47d5dc6  sub rsp, 0x30
00007cc2f47d5dca  movaps [rsp], xmm5
00007cc2f47d5dce  movaps [rsp+0x10], xmm2
00007cc2f47d5dd3  movaps [rsp+0x20], xmm13
00007cc2f47d5dd9  lea rdi, [rsp]
00007cc2f47d5ddd  mov esi, 0x00
00007cc2f47d5de2  mov rax, 0x5990E710A530
00007cc2f47d5dec  call rax
00007cc2f47d5dee  movaps xmm5, [rsp]
00007cc2f47d5df2  add rsp, 0x30
00007cc2f47d5df6  vmovaps xmm0, [rsp]
00007cc2f47d5dfb  vmovaps xmm1, [rsp+0x10]
00007cc2f47d5e01  vmovaps xmm2, [rsp+0x20]
00007cc2f47d5e07  vmovaps xmm3, [rsp+0x30]
00007cc2f47d5e0d  vmovaps xmm4, [rsp+0x40]
00007cc2f47d5e13  vmovaps xmm6, [rsp+0x50]
00007cc2f47d5e19  vmovaps xmm7, [rsp+0x60]
00007cc2f47d5e1f  vmovaps xmm8, [rsp+0x70]
00007cc2f47d5e25  vmovaps xmm9, [rsp+0x80]
00007cc2f47d5e2e  vmovaps xmm10, [rsp+0x90]
00007cc2f47d5e37  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d5e40  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d5e49  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d5e52  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d5e5b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d5e64  add rsp, 0xF0
00007cc2f47d5e6b  pop r11
00007cc2f47d5e6d  pop r10
00007cc2f47d5e6f  pop r9
00007cc2f47d5e71  pop r8
00007cc2f47d5e73  pop rsi
00007cc2f47d5e74  pop rdi
00007cc2f47d5e75  pop rdx
00007cc2f47d5e76  pop rcx
00007cc2f47d5e77  pop rax
00007cc2f47d5e78  add rsp, 0x08
00007cc2f47d5e7c  jmp 0x00007CC2F47D3013
00007cc2f47d5e81  sub rsp, 0x08
00007cc2f47d5e85  push rax
00007cc2f47d5e86  push rcx
00007cc2f47d5e87  push rdx
00007cc2f47d5e88  push rdi
00007cc2f47d5e89  push rsi
00007cc2f47d5e8a  push r8
00007cc2f47d5e8c  push r9
00007cc2f47d5e8e  push r10
00007cc2f47d5e90  push r11
00007cc2f47d5e92  sub rsp, 0xF0
00007cc2f47d5e99  vmovaps [rsp], xmm0
00007cc2f47d5e9e  vmovaps [rsp+0x10], xmm1
00007cc2f47d5ea4  vmovaps [rsp+0x20], xmm2
00007cc2f47d5eaa  vmovaps [rsp+0x30], xmm3
00007cc2f47d5eb0  vmovaps [rsp+0x40], xmm4
00007cc2f47d5eb6  vmovaps [rsp+0x50], xmm5
00007cc2f47d5ebc  vmovaps [rsp+0x60], xmm6
00007cc2f47d5ec2  vmovaps [rsp+0x70], xmm7
00007cc2f47d5ec8  vmovaps [rsp+0x80], xmm8
00007cc2f47d5ed1  vmovaps [rsp+0x90], xmm9
00007cc2f47d5eda  vmovaps [rsp+0xA0], xmm10
00007cc2f47d5ee3  vmovaps [rsp+0xB0], xmm11
00007cc2f47d5eec  vmovaps [rsp+0xC0], xmm12
00007cc2f47d5ef5  vmovaps [rsp+0xD0], xmm14
00007cc2f47d5efe  vmovaps [rsp+0xE0], xmm15
00007cc2f47d5f07  sub rsp, 0x30
00007cc2f47d5f0b  movaps [rsp], xmm13
00007cc2f47d5f10  movaps [rsp+0x10], xmm10
00007cc2f47d5f16  movaps [rsp+0x20], xmm1
00007cc2f47d5f1b  lea rdi, [rsp]
00007cc2f47d5f1f  mov esi, 0x00
00007cc2f47d5f24  mov rax, 0x5990E710A530
00007cc2f47d5f2e  call rax
00007cc2f47d5f30  movaps xmm13, [rsp]
00007cc2f47d5f35  add rsp, 0x30
00007cc2f47d5f39  vmovaps xmm0, [rsp]
00007cc2f47d5f3e  vmovaps xmm1, [rsp+0x10]
00007cc2f47d5f44  vmovaps xmm2, [rsp+0x20]
00007cc2f47d5f4a  vmovaps xmm3, [rsp+0x30]
00007cc2f47d5f50  vmovaps xmm4, [rsp+0x40]
00007cc2f47d5f56  vmovaps xmm5, [rsp+0x50]
00007cc2f47d5f5c  vmovaps xmm6, [rsp+0x60]
00007cc2f47d5f62  vmovaps xmm7, [rsp+0x70]
00007cc2f47d5f68  vmovaps xmm8, [rsp+0x80]
00007cc2f47d5f71  vmovaps xmm9, [rsp+0x90]
00007cc2f47d5f7a  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d5f83  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d5f8c  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d5f95  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d5f9e  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d5fa7  add rsp, 0xF0
00007cc2f47d5fae  pop r11
00007cc2f47d5fb0  pop r10
00007cc2f47d5fb2  pop r9
00007cc2f47d5fb4  pop r8
00007cc2f47d5fb6  pop rsi
00007cc2f47d5fb7  pop rdi
00007cc2f47d5fb8  pop rdx
00007cc2f47d5fb9  pop rcx
00007cc2f47d5fba  pop rax
00007cc2f47d5fbb  add rsp, 0x08
00007cc2f47d5fbf  jmp 0x00007CC2F47D303C
00007cc2f47d5fc4  sub rsp, 0x08
00007cc2f47d5fc8  push rax
00007cc2f47d5fc9  push rcx
00007cc2f47d5fca  push rdx
00007cc2f47d5fcb  push rdi
00007cc2f47d5fcc  push rsi
00007cc2f47d5fcd  push r8
00007cc2f47d5fcf  push r9
00007cc2f47d5fd1  push r10
00007cc2f47d5fd3  push r11
00007cc2f47d5fd5  sub rsp, 0xF0
00007cc2f47d5fdc  vmovaps [rsp], xmm0
00007cc2f47d5fe1  vmovaps [rsp+0x10], xmm2
00007cc2f47d5fe7  vmovaps [rsp+0x20], xmm3
00007cc2f47d5fed  vmovaps [rsp+0x30], xmm4
00007cc2f47d5ff3  vmovaps [rsp+0x40], xmm5
00007cc2f47d5ff9  vmovaps [rsp+0x50], xmm6
00007cc2f47d5fff  vmovaps [rsp+0x60], xmm7
00007cc2f47d6005  vmovaps [rsp+0x70], xmm8
00007cc2f47d600b  vmovaps [rsp+0x80], xmm9
00007cc2f47d6014  vmovaps [rsp+0x90], xmm10
00007cc2f47d601d  vmovaps [rsp+0xA0], xmm11
00007cc2f47d6026  vmovaps [rsp+0xB0], xmm12
00007cc2f47d602f  vmovaps [rsp+0xC0], xmm13
00007cc2f47d6038  vmovaps [rsp+0xD0], xmm14
00007cc2f47d6041  vmovaps [rsp+0xE0], xmm15
00007cc2f47d604a  sub rsp, 0x30
00007cc2f47d604e  movaps [rsp], xmm1
00007cc2f47d6052  movaps [rsp+0x10], xmm15
00007cc2f47d6058  movaps [rsp+0x20], xmm10
00007cc2f47d605e  lea rdi, [rsp]
00007cc2f47d6062  mov esi, 0x00
00007cc2f47d6067  mov rax, 0x5990E710A530
00007cc2f47d6071  call rax
00007cc2f47d6073  movaps xmm1, [rsp]
00007cc2f47d6077  add rsp, 0x30
00007cc2f47d607b  vmovaps xmm0, [rsp]
00007cc2f47d6080  vmovaps xmm2, [rsp+0x10]
00007cc2f47d6086  vmovaps xmm3, [rsp+0x20]
00007cc2f47d608c  vmovaps xmm4, [rsp+0x30]
00007cc2f47d6092  vmovaps xmm5, [rsp+0x40]
00007cc2f47d6098  vmovaps xmm6, [rsp+0x50]
00007cc2f47d609e  vmovaps xmm7, [rsp+0x60]
00007cc2f47d60a4  vmovaps xmm8, [rsp+0x70]
00007cc2f47d60aa  vmovaps xmm9, [rsp+0x80]
00007cc2f47d60b3  vmovaps xmm10, [rsp+0x90]
00007cc2f47d60bc  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d60c5  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d60ce  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d60d7  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d60e0  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d60e9  add rsp, 0xF0
00007cc2f47d60f0  pop r11
00007cc2f47d60f2  pop r10
00007cc2f47d60f4  pop r9
00007cc2f47d60f6  pop r8
00007cc2f47d60f8  pop rsi
00007cc2f47d60f9  pop rdi
00007cc2f47d60fa  pop rdx
00007cc2f47d60fb  pop rcx
00007cc2f47d60fc  pop rax
00007cc2f47d60fd  add rsp, 0x08
00007cc2f47d6101  jmp 0x00007CC2F47D305B
00007cc2f47d6106  sub rsp, 0x08
00007cc2f47d610a  push rax
00007cc2f47d610b  push rcx
00007cc2f47d610c  push rdx
00007cc2f47d610d  push rdi
00007cc2f47d610e  push rsi
00007cc2f47d610f  push r8
00007cc2f47d6111  push r9
00007cc2f47d6113  push r10
00007cc2f47d6115  push r11
00007cc2f47d6117  sub rsp, 0xF0
00007cc2f47d611e  vmovaps [rsp], xmm0
00007cc2f47d6123  vmovaps [rsp+0x10], xmm1
00007cc2f47d6129  vmovaps [rsp+0x20], xmm2
00007cc2f47d612f  vmovaps [rsp+0x30], xmm3
00007cc2f47d6135  vmovaps [rsp+0x40], xmm4
00007cc2f47d613b  vmovaps [rsp+0x50], xmm5
00007cc2f47d6141  vmovaps [rsp+0x60], xmm6
00007cc2f47d6147  vmovaps [rsp+0x70], xmm7
00007cc2f47d614d  vmovaps [rsp+0x80], xmm8
00007cc2f47d6156  vmovaps [rsp+0x90], xmm9
00007cc2f47d615f  vmovaps [rsp+0xA0], xmm10
00007cc2f47d6168  vmovaps [rsp+0xB0], xmm11
00007cc2f47d6171  vmovaps [rsp+0xC0], xmm12
00007cc2f47d617a  vmovaps [rsp+0xD0], xmm13
00007cc2f47d6183  vmovaps [rsp+0xE0], xmm14
00007cc2f47d618c  sub rsp, 0x30
00007cc2f47d6190  movaps [rsp], xmm15
00007cc2f47d6195  movaps [rsp+0x10], xmm10
00007cc2f47d619b  movaps [rsp+0x20], xmm11
00007cc2f47d61a1  lea rdi, [rsp]
00007cc2f47d61a5  mov esi, 0x00
00007cc2f47d61aa  mov rax, 0x5990E710A530
00007cc2f47d61b4  call rax
00007cc2f47d61b6  movaps xmm15, [rsp]
00007cc2f47d61bb  add rsp, 0x30
00007cc2f47d61bf  vmovaps xmm0, [rsp]
00007cc2f47d61c4  vmovaps xmm1, [rsp+0x10]
00007cc2f47d61ca  vmovaps xmm2, [rsp+0x20]
00007cc2f47d61d0  vmovaps xmm3, [rsp+0x30]
00007cc2f47d61d6  vmovaps xmm4, [rsp+0x40]
00007cc2f47d61dc  vmovaps xmm5, [rsp+0x50]
00007cc2f47d61e2  vmovaps xmm6, [rsp+0x60]
00007cc2f47d61e8  vmovaps xmm7, [rsp+0x70]
00007cc2f47d61ee  vmovaps xmm8, [rsp+0x80]
00007cc2f47d61f7  vmovaps xmm9, [rsp+0x90]
00007cc2f47d6200  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d6209  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d6212  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d621b  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d6224  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d622d  add rsp, 0xF0
00007cc2f47d6234  pop r11
00007cc2f47d6236  pop r10
00007cc2f47d6238  pop r9
00007cc2f47d623a  pop r8
00007cc2f47d623c  pop rsi
00007cc2f47d623d  pop rdi
00007cc2f47d623e  pop rdx
00007cc2f47d623f  pop rcx
00007cc2f47d6240  pop rax
00007cc2f47d6241  add rsp, 0x08
00007cc2f47d6245  jmp 0x00007CC2F47D307E
00007cc2f47d624a  sub rsp, 0x08
00007cc2f47d624e  push rax
00007cc2f47d624f  push rcx
00007cc2f47d6250  push rdx
00007cc2f47d6251  push rdi
00007cc2f47d6252  push rsi
00007cc2f47d6253  push r8
00007cc2f47d6255  push r9
00007cc2f47d6257  push r10
00007cc2f47d6259  push r11
00007cc2f47d625b  sub rsp, 0xF0
00007cc2f47d6262  vmovaps [rsp], xmm0
00007cc2f47d6267  vmovaps [rsp+0x10], xmm1
00007cc2f47d626d  vmovaps [rsp+0x20], xmm2
00007cc2f47d6273  vmovaps [rsp+0x30], xmm3
00007cc2f47d6279  vmovaps [rsp+0x40], xmm4
00007cc2f47d627f  vmovaps [rsp+0x50], xmm5
00007cc2f47d6285  vmovaps [rsp+0x60], xmm6
00007cc2f47d628b  vmovaps [rsp+0x70], xmm7
00007cc2f47d6291  vmovaps [rsp+0x80], xmm8
00007cc2f47d629a  vmovaps [rsp+0x90], xmm9
00007cc2f47d62a3  vmovaps [rsp+0xA0], xmm11
00007cc2f47d62ac  vmovaps [rsp+0xB0], xmm12
00007cc2f47d62b5  vmovaps [rsp+0xC0], xmm13
00007cc2f47d62be  vmovaps [rsp+0xD0], xmm14
00007cc2f47d62c7  vmovaps [rsp+0xE0], xmm15
00007cc2f47d62d0  sub rsp, 0x30
00007cc2f47d62d4  movaps [rsp], xmm10
00007cc2f47d62d9  movaps [rsp+0x10], xmm2
00007cc2f47d62de  movaps [rsp+0x20], xmm11
00007cc2f47d62e4  lea rdi, [rsp]
00007cc2f47d62e8  mov esi, 0x00
00007cc2f47d62ed  mov rax, 0x5990E710A530
00007cc2f47d62f7  call rax
00007cc2f47d62f9  movaps xmm10, [rsp]
00007cc2f47d62fe  add rsp, 0x30
00007cc2f47d6302  vmovaps xmm0, [rsp]
00007cc2f47d6307  vmovaps xmm1, [rsp+0x10]
00007cc2f47d630d  vmovaps xmm2, [rsp+0x20]
00007cc2f47d6313  vmovaps xmm3, [rsp+0x30]
00007cc2f47d6319  vmovaps xmm4, [rsp+0x40]
00007cc2f47d631f  vmovaps xmm5, [rsp+0x50]
00007cc2f47d6325  vmovaps xmm6, [rsp+0x60]
00007cc2f47d632b  vmovaps xmm7, [rsp+0x70]
00007cc2f47d6331  vmovaps xmm8, [rsp+0x80]
00007cc2f47d633a  vmovaps xmm9, [rsp+0x90]
00007cc2f47d6343  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d634c  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d6355  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d635e  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d6367  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d6370  add rsp, 0xF0
00007cc2f47d6377  pop r11
00007cc2f47d6379  pop r10
00007cc2f47d637b  pop r9
00007cc2f47d637d  pop r8
00007cc2f47d637f  pop rsi
00007cc2f47d6380  pop rdi
00007cc2f47d6381  pop rdx
00007cc2f47d6382  pop rcx
00007cc2f47d6383  pop rax
00007cc2f47d6384  add rsp, 0x08
00007cc2f47d6388  jmp 0x00007CC2F47D30B6
00007cc2f47d638d  sub rsp, 0x08
00007cc2f47d6391  push rax
00007cc2f47d6392  push rcx
00007cc2f47d6393  push rdx
00007cc2f47d6394  push rdi
00007cc2f47d6395  push rsi
00007cc2f47d6396  push r8
00007cc2f47d6398  push r9
00007cc2f47d639a  push r10
00007cc2f47d639c  push r11
00007cc2f47d639e  sub rsp, 0xF0
00007cc2f47d63a5  vmovaps [rsp], xmm0
00007cc2f47d63aa  vmovaps [rsp+0x10], xmm1
00007cc2f47d63b0  vmovaps [rsp+0x20], xmm2
00007cc2f47d63b6  vmovaps [rsp+0x30], xmm3
00007cc2f47d63bc  vmovaps [rsp+0x40], xmm4
00007cc2f47d63c2  vmovaps [rsp+0x50], xmm5
00007cc2f47d63c8  vmovaps [rsp+0x60], xmm6
00007cc2f47d63ce  vmovaps [rsp+0x70], xmm7
00007cc2f47d63d4  vmovaps [rsp+0x80], xmm8
00007cc2f47d63dd  vmovaps [rsp+0x90], xmm9
00007cc2f47d63e6  vmovaps [rsp+0xA0], xmm10
00007cc2f47d63ef  vmovaps [rsp+0xB0], xmm12
00007cc2f47d63f8  vmovaps [rsp+0xC0], xmm13
00007cc2f47d6401  vmovaps [rsp+0xD0], xmm14
00007cc2f47d640a  vmovaps [rsp+0xE0], xmm15
00007cc2f47d6413  sub rsp, 0x30
00007cc2f47d6417  movaps [rsp], xmm11
00007cc2f47d641c  movaps [rsp+0x10], xmm2
00007cc2f47d6421  movaps [rsp+0x20], xmm1
00007cc2f47d6426  lea rdi, [rsp]
00007cc2f47d642a  mov esi, 0x00
00007cc2f47d642f  mov rax, 0x5990E710A530
00007cc2f47d6439  call rax
00007cc2f47d643b  movaps xmm11, [rsp]
00007cc2f47d6440  add rsp, 0x30
00007cc2f47d6444  vmovaps xmm0, [rsp]
00007cc2f47d6449  vmovaps xmm1, [rsp+0x10]
00007cc2f47d644f  vmovaps xmm2, [rsp+0x20]
00007cc2f47d6455  vmovaps xmm3, [rsp+0x30]
00007cc2f47d645b  vmovaps xmm4, [rsp+0x40]
00007cc2f47d6461  vmovaps xmm5, [rsp+0x50]
00007cc2f47d6467  vmovaps xmm6, [rsp+0x60]
00007cc2f47d646d  vmovaps xmm7, [rsp+0x70]
00007cc2f47d6473  vmovaps xmm8, [rsp+0x80]
00007cc2f47d647c  vmovaps xmm9, [rsp+0x90]
00007cc2f47d6485  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d648e  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d6497  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d64a0  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d64a9  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d64b2  add rsp, 0xF0
00007cc2f47d64b9  pop r11
00007cc2f47d64bb  pop r10
00007cc2f47d64bd  pop r9
00007cc2f47d64bf  pop r8
00007cc2f47d64c1  pop rsi
00007cc2f47d64c2  pop rdi
00007cc2f47d64c3  pop rdx
00007cc2f47d64c4  pop rcx
00007cc2f47d64c5  pop rax
00007cc2f47d64c6  add rsp, 0x08
00007cc2f47d64ca  jmp 0x00007CC2F47D30F2
00007cc2f47d64cf  sub rsp, 0x08
00007cc2f47d64d3  push rax
00007cc2f47d64d4  push rcx
00007cc2f47d64d5  push rdx
00007cc2f47d64d6  push rdi
00007cc2f47d64d7  push rsi
00007cc2f47d64d8  push r8
00007cc2f47d64da  push r9
00007cc2f47d64dc  push r10
00007cc2f47d64de  push r11
00007cc2f47d64e0  sub rsp, 0xF0
00007cc2f47d64e7  vmovaps [rsp], xmm0
00007cc2f47d64ec  vmovaps [rsp+0x10], xmm2
00007cc2f47d64f2  vmovaps [rsp+0x20], xmm3
00007cc2f47d64f8  vmovaps [rsp+0x30], xmm4
00007cc2f47d64fe  vmovaps [rsp+0x40], xmm5
00007cc2f47d6504  vmovaps [rsp+0x50], xmm6
00007cc2f47d650a  vmovaps [rsp+0x60], xmm7
00007cc2f47d6510  vmovaps [rsp+0x70], xmm8
00007cc2f47d6516  vmovaps [rsp+0x80], xmm9
00007cc2f47d651f  vmovaps [rsp+0x90], xmm10
00007cc2f47d6528  vmovaps [rsp+0xA0], xmm11
00007cc2f47d6531  vmovaps [rsp+0xB0], xmm12
00007cc2f47d653a  vmovaps [rsp+0xC0], xmm13
00007cc2f47d6543  vmovaps [rsp+0xD0], xmm14
00007cc2f47d654c  vmovaps [rsp+0xE0], xmm15
00007cc2f47d6555  sub rsp, 0x30
00007cc2f47d6559  movaps [rsp], xmm1
00007cc2f47d655d  movaps [rsp+0x10], xmm14
00007cc2f47d6563  movaps [rsp+0x20], xmm6
00007cc2f47d6568  lea rdi, [rsp]
00007cc2f47d656c  mov esi, 0x00
00007cc2f47d6571  mov rax, 0x5990E710A530
00007cc2f47d657b  call rax
00007cc2f47d657d  movaps xmm1, [rsp]
00007cc2f47d6581  add rsp, 0x30
00007cc2f47d6585  vmovaps xmm0, [rsp]
00007cc2f47d658a  vmovaps xmm2, [rsp+0x10]
00007cc2f47d6590  vmovaps xmm3, [rsp+0x20]
00007cc2f47d6596  vmovaps xmm4, [rsp+0x30]
00007cc2f47d659c  vmovaps xmm5, [rsp+0x40]
00007cc2f47d65a2  vmovaps xmm6, [rsp+0x50]
00007cc2f47d65a8  vmovaps xmm7, [rsp+0x60]
00007cc2f47d65ae  vmovaps xmm8, [rsp+0x70]
00007cc2f47d65b4  vmovaps xmm9, [rsp+0x80]
00007cc2f47d65bd  vmovaps xmm10, [rsp+0x90]
00007cc2f47d65c6  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d65cf  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d65d8  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d65e1  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d65ea  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d65f3  add rsp, 0xF0
00007cc2f47d65fa  pop r11
00007cc2f47d65fc  pop r10
00007cc2f47d65fe  pop r9
00007cc2f47d6600  pop r8
00007cc2f47d6602  pop rsi
00007cc2f47d6603  pop rdi
00007cc2f47d6604  pop rdx
00007cc2f47d6605  pop rcx
00007cc2f47d6606  pop rax
00007cc2f47d6607  add rsp, 0x08
00007cc2f47d660b  jmp 0x00007CC2F47D310B
00007cc2f47d6610  sub rsp, 0x08
00007cc2f47d6614  push rax
00007cc2f47d6615  push rcx
00007cc2f47d6616  push rdx
00007cc2f47d6617  push rdi
00007cc2f47d6618  push rsi
00007cc2f47d6619  push r8
00007cc2f47d661b  push r9
00007cc2f47d661d  push r10
00007cc2f47d661f  push r11
00007cc2f47d6621  sub rsp, 0xF0
00007cc2f47d6628  vmovaps [rsp], xmm0
00007cc2f47d662d  vmovaps [rsp+0x10], xmm1
00007cc2f47d6633  vmovaps [rsp+0x20], xmm2
00007cc2f47d6639  vmovaps [rsp+0x30], xmm3
00007cc2f47d663f  vmovaps [rsp+0x40], xmm4
00007cc2f47d6645  vmovaps [rsp+0x50], xmm5
00007cc2f47d664b  vmovaps [rsp+0x60], xmm6
00007cc2f47d6651  vmovaps [rsp+0x70], xmm7
00007cc2f47d6657  vmovaps [rsp+0x80], xmm8
00007cc2f47d6660  vmovaps [rsp+0x90], xmm9
00007cc2f47d6669  vmovaps [rsp+0xA0], xmm10
00007cc2f47d6672  vmovaps [rsp+0xB0], xmm11
00007cc2f47d667b  vmovaps [rsp+0xC0], xmm12
00007cc2f47d6684  vmovaps [rsp+0xD0], xmm13
00007cc2f47d668d  vmovaps [rsp+0xE0], xmm14
00007cc2f47d6696  sub rsp, 0x30
00007cc2f47d669a  movaps [rsp], xmm15
00007cc2f47d669f  movaps [rsp+0x10], xmm14
00007cc2f47d66a5  movaps [rsp+0x20], xmm5
00007cc2f47d66aa  lea rdi, [rsp]
00007cc2f47d66ae  mov esi, 0x00
00007cc2f47d66b3  mov rax, 0x5990E710A530
00007cc2f47d66bd  call rax
00007cc2f47d66bf  movaps xmm15, [rsp]
00007cc2f47d66c4  add rsp, 0x30
00007cc2f47d66c8  vmovaps xmm0, [rsp]
00007cc2f47d66cd  vmovaps xmm1, [rsp+0x10]
00007cc2f47d66d3  vmovaps xmm2, [rsp+0x20]
00007cc2f47d66d9  vmovaps xmm3, [rsp+0x30]
00007cc2f47d66df  vmovaps xmm4, [rsp+0x40]
00007cc2f47d66e5  vmovaps xmm5, [rsp+0x50]
00007cc2f47d66eb  vmovaps xmm6, [rsp+0x60]
00007cc2f47d66f1  vmovaps xmm7, [rsp+0x70]
00007cc2f47d66f7  vmovaps xmm8, [rsp+0x80]
00007cc2f47d6700  vmovaps xmm9, [rsp+0x90]
00007cc2f47d6709  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d6712  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d671b  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d6724  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d672d  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d6736  add rsp, 0xF0
00007cc2f47d673d  pop r11
00007cc2f47d673f  pop r10
00007cc2f47d6741  pop r9
00007cc2f47d6743  pop r8
00007cc2f47d6745  pop rsi
00007cc2f47d6746  pop rdi
00007cc2f47d6747  pop rdx
00007cc2f47d6748  pop rcx
00007cc2f47d6749  pop rax
00007cc2f47d674a  add rsp, 0x08
00007cc2f47d674e  jmp 0x00007CC2F47D312B
00007cc2f47d6753  sub rsp, 0x08
00007cc2f47d6757  push rax
00007cc2f47d6758  push rcx
00007cc2f47d6759  push rdx
00007cc2f47d675a  push rdi
00007cc2f47d675b  push rsi
00007cc2f47d675c  push r8
00007cc2f47d675e  push r9
00007cc2f47d6760  push r10
00007cc2f47d6762  push r11
00007cc2f47d6764  sub rsp, 0xF0
00007cc2f47d676b  vmovaps [rsp], xmm0
00007cc2f47d6770  vmovaps [rsp+0x10], xmm1
00007cc2f47d6776  vmovaps [rsp+0x20], xmm2
00007cc2f47d677c  vmovaps [rsp+0x30], xmm3
00007cc2f47d6782  vmovaps [rsp+0x40], xmm4
00007cc2f47d6788  vmovaps [rsp+0x50], xmm5
00007cc2f47d678e  vmovaps [rsp+0x60], xmm7
00007cc2f47d6794  vmovaps [rsp+0x70], xmm8
00007cc2f47d679a  vmovaps [rsp+0x80], xmm9
00007cc2f47d67a3  vmovaps [rsp+0x90], xmm10
00007cc2f47d67ac  vmovaps [rsp+0xA0], xmm11
00007cc2f47d67b5  vmovaps [rsp+0xB0], xmm12
00007cc2f47d67be  vmovaps [rsp+0xC0], xmm13
00007cc2f47d67c7  vmovaps [rsp+0xD0], xmm14
00007cc2f47d67d0  vmovaps [rsp+0xE0], xmm15
00007cc2f47d67d9  sub rsp, 0x30
00007cc2f47d67dd  movaps [rsp], xmm6
00007cc2f47d67e1  movaps [rsp+0x10], xmm9
00007cc2f47d67e7  movaps [rsp+0x20], xmm14
00007cc2f47d67ed  lea rdi, [rsp]
00007cc2f47d67f1  mov esi, 0x00
00007cc2f47d67f6  mov rax, 0x5990E710A530
00007cc2f47d6800  call rax
00007cc2f47d6802  movaps xmm6, [rsp]
00007cc2f47d6806  add rsp, 0x30
00007cc2f47d680a  vmovaps xmm0, [rsp]
00007cc2f47d680f  vmovaps xmm1, [rsp+0x10]
00007cc2f47d6815  vmovaps xmm2, [rsp+0x20]
00007cc2f47d681b  vmovaps xmm3, [rsp+0x30]
00007cc2f47d6821  vmovaps xmm4, [rsp+0x40]
00007cc2f47d6827  vmovaps xmm5, [rsp+0x50]
00007cc2f47d682d  vmovaps xmm7, [rsp+0x60]
00007cc2f47d6833  vmovaps xmm8, [rsp+0x70]
00007cc2f47d6839  vmovaps xmm9, [rsp+0x80]
00007cc2f47d6842  vmovaps xmm10, [rsp+0x90]
00007cc2f47d684b  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d6854  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d685d  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d6866  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d686f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d6878  add rsp, 0xF0
00007cc2f47d687f  pop r11
00007cc2f47d6881  pop r10
00007cc2f47d6883  pop r9
00007cc2f47d6885  pop r8
00007cc2f47d6887  pop rsi
00007cc2f47d6888  pop rdi
00007cc2f47d6889  pop rdx
00007cc2f47d688a  pop rcx
00007cc2f47d688b  pop rax
00007cc2f47d688c  add rsp, 0x08
00007cc2f47d6890  jmp 0x00007CC2F47D3153
00007cc2f47d6895  sub rsp, 0x08
00007cc2f47d6899  push rax
00007cc2f47d689a  push rcx
00007cc2f47d689b  push rdx
00007cc2f47d689c  push rdi
00007cc2f47d689d  push rsi
00007cc2f47d689e  push r8
00007cc2f47d68a0  push r9
00007cc2f47d68a2  push r10
00007cc2f47d68a4  push r11
00007cc2f47d68a6  sub rsp, 0xF0
00007cc2f47d68ad  vmovaps [rsp], xmm0
00007cc2f47d68b2  vmovaps [rsp+0x10], xmm1
00007cc2f47d68b8  vmovaps [rsp+0x20], xmm2
00007cc2f47d68be  vmovaps [rsp+0x30], xmm3
00007cc2f47d68c4  vmovaps [rsp+0x40], xmm4
00007cc2f47d68ca  vmovaps [rsp+0x50], xmm5
00007cc2f47d68d0  vmovaps [rsp+0x60], xmm6
00007cc2f47d68d6  vmovaps [rsp+0x70], xmm7
00007cc2f47d68dc  vmovaps [rsp+0x80], xmm8
00007cc2f47d68e5  vmovaps [rsp+0x90], xmm9
00007cc2f47d68ee  vmovaps [rsp+0xA0], xmm10
00007cc2f47d68f7  vmovaps [rsp+0xB0], xmm11
00007cc2f47d6900  vmovaps [rsp+0xC0], xmm12
00007cc2f47d6909  vmovaps [rsp+0xD0], xmm13
00007cc2f47d6912  vmovaps [rsp+0xE0], xmm15
00007cc2f47d691b  sub rsp, 0x30
00007cc2f47d691f  movaps [rsp], xmm14
00007cc2f47d6924  movaps [rsp+0x10], xmm9
00007cc2f47d692a  movaps [rsp+0x20], xmm13
00007cc2f47d6930  lea rdi, [rsp]
00007cc2f47d6934  mov esi, 0x00
00007cc2f47d6939  mov rax, 0x5990E710A530
00007cc2f47d6943  call rax
00007cc2f47d6945  movaps xmm14, [rsp]
00007cc2f47d694a  add rsp, 0x30
00007cc2f47d694e  vmovaps xmm0, [rsp]
00007cc2f47d6953  vmovaps xmm1, [rsp+0x10]
00007cc2f47d6959  vmovaps xmm2, [rsp+0x20]
00007cc2f47d695f  vmovaps xmm3, [rsp+0x30]
00007cc2f47d6965  vmovaps xmm4, [rsp+0x40]
00007cc2f47d696b  vmovaps xmm5, [rsp+0x50]
00007cc2f47d6971  vmovaps xmm6, [rsp+0x60]
00007cc2f47d6977  vmovaps xmm7, [rsp+0x70]
00007cc2f47d697d  vmovaps xmm8, [rsp+0x80]
00007cc2f47d6986  vmovaps xmm9, [rsp+0x90]
00007cc2f47d698f  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d6998  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d69a1  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d69aa  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d69b3  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d69bc  add rsp, 0xF0
00007cc2f47d69c3  pop r11
00007cc2f47d69c5  pop r10
00007cc2f47d69c7  pop r9
00007cc2f47d69c9  pop r8
00007cc2f47d69cb  pop rsi
00007cc2f47d69cc  pop rdi
00007cc2f47d69cd  pop rdx
00007cc2f47d69ce  pop rcx
00007cc2f47d69cf  pop rax
00007cc2f47d69d0  add rsp, 0x08
00007cc2f47d69d4  jmp 0x00007CC2F47D3176
00007cc2f47d69d9  sub rsp, 0x08
00007cc2f47d69dd  push rax
00007cc2f47d69de  push rcx
00007cc2f47d69df  push rdx
00007cc2f47d69e0  push rdi
00007cc2f47d69e1  push rsi
00007cc2f47d69e2  push r8
00007cc2f47d69e4  push r9
00007cc2f47d69e6  push r10
00007cc2f47d69e8  push r11
00007cc2f47d69ea  sub rsp, 0xF0
00007cc2f47d69f1  vmovaps [rsp], xmm0
00007cc2f47d69f6  vmovaps [rsp+0x10], xmm1
00007cc2f47d69fc  vmovaps [rsp+0x20], xmm2
00007cc2f47d6a02  vmovaps [rsp+0x30], xmm3
00007cc2f47d6a08  vmovaps [rsp+0x40], xmm4
00007cc2f47d6a0e  vmovaps [rsp+0x50], xmm5
00007cc2f47d6a14  vmovaps [rsp+0x60], xmm6
00007cc2f47d6a1a  vmovaps [rsp+0x70], xmm7
00007cc2f47d6a20  vmovaps [rsp+0x80], xmm8
00007cc2f47d6a29  vmovaps [rsp+0x90], xmm9
00007cc2f47d6a32  vmovaps [rsp+0xA0], xmm10
00007cc2f47d6a3b  vmovaps [rsp+0xB0], xmm11
00007cc2f47d6a44  vmovaps [rsp+0xC0], xmm12
00007cc2f47d6a4d  vmovaps [rsp+0xD0], xmm14
00007cc2f47d6a56  vmovaps [rsp+0xE0], xmm15
00007cc2f47d6a5f  sub rsp, 0x30
00007cc2f47d6a63  movaps [rsp], xmm13
00007cc2f47d6a68  movaps [rsp+0x10], xmm9
00007cc2f47d6a6e  movaps [rsp+0x20], xmm10
00007cc2f47d6a74  lea rdi, [rsp]
00007cc2f47d6a78  mov esi, 0x00
00007cc2f47d6a7d  mov rax, 0x5990E710A530
00007cc2f47d6a87  call rax
00007cc2f47d6a89  movaps xmm13, [rsp]
00007cc2f47d6a8e  add rsp, 0x30
00007cc2f47d6a92  vmovaps xmm0, [rsp]
00007cc2f47d6a97  vmovaps xmm1, [rsp+0x10]
00007cc2f47d6a9d  vmovaps xmm2, [rsp+0x20]
00007cc2f47d6aa3  vmovaps xmm3, [rsp+0x30]
00007cc2f47d6aa9  vmovaps xmm4, [rsp+0x40]
00007cc2f47d6aaf  vmovaps xmm5, [rsp+0x50]
00007cc2f47d6ab5  vmovaps xmm6, [rsp+0x60]
00007cc2f47d6abb  vmovaps xmm7, [rsp+0x70]
00007cc2f47d6ac1  vmovaps xmm8, [rsp+0x80]
00007cc2f47d6aca  vmovaps xmm9, [rsp+0x90]
00007cc2f47d6ad3  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d6adc  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d6ae5  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d6aee  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d6af7  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d6b00  add rsp, 0xF0
00007cc2f47d6b07  pop r11
00007cc2f47d6b09  pop r10
00007cc2f47d6b0b  pop r9
00007cc2f47d6b0d  pop r8
00007cc2f47d6b0f  pop rsi
00007cc2f47d6b10  pop rdi
00007cc2f47d6b11  pop rdx
00007cc2f47d6b12  pop rcx
00007cc2f47d6b13  pop rax
00007cc2f47d6b14  add rsp, 0x08
00007cc2f47d6b18  jmp 0x00007CC2F47D3196
00007cc2f47d6b1d  call 0x00007CC2F460AFE0
00007cc2f47d6b22  jmp 0x00007CC2F47D31EB
00007cc2f47d6b27  sub rsp, 0x08
00007cc2f47d6b2b  push rax
00007cc2f47d6b2c  push rcx
00007cc2f47d6b2d  push rdx
00007cc2f47d6b2e  push rdi
00007cc2f47d6b2f  push rsi
00007cc2f47d6b30  push r8
00007cc2f47d6b32  push r9
00007cc2f47d6b34  push r10
00007cc2f47d6b36  push r11
00007cc2f47d6b38  sub rsp, 0xF0
00007cc2f47d6b3f  vmovaps [rsp], xmm0
00007cc2f47d6b44  vmovaps [rsp+0x10], xmm1
00007cc2f47d6b4a  vmovaps [rsp+0x20], xmm2
00007cc2f47d6b50  vmovaps [rsp+0x30], xmm3
00007cc2f47d6b56  vmovaps [rsp+0x40], xmm4
00007cc2f47d6b5c  vmovaps [rsp+0x50], xmm5
00007cc2f47d6b62  vmovaps [rsp+0x60], xmm6
00007cc2f47d6b68  vmovaps [rsp+0x70], xmm7
00007cc2f47d6b6e  vmovaps [rsp+0x80], xmm8
00007cc2f47d6b77  vmovaps [rsp+0x90], xmm10
00007cc2f47d6b80  vmovaps [rsp+0xA0], xmm11
00007cc2f47d6b89  vmovaps [rsp+0xB0], xmm12
00007cc2f47d6b92  vmovaps [rsp+0xC0], xmm13
00007cc2f47d6b9b  vmovaps [rsp+0xD0], xmm14
00007cc2f47d6ba4  vmovaps [rsp+0xE0], xmm15
00007cc2f47d6bad  sub rsp, 0x30
00007cc2f47d6bb1  movaps [rsp], xmm9
00007cc2f47d6bb6  movaps [rsp+0x10], xmm8
00007cc2f47d6bbc  movaps [rsp+0x20], xmm10
00007cc2f47d6bc2  lea rdi, [rsp]
00007cc2f47d6bc6  mov esi, 0x00
00007cc2f47d6bcb  mov rax, 0x5990E710A530
00007cc2f47d6bd5  call rax
00007cc2f47d6bd7  movaps xmm9, [rsp]
00007cc2f47d6bdc  add rsp, 0x30
00007cc2f47d6be0  vmovaps xmm0, [rsp]
00007cc2f47d6be5  vmovaps xmm1, [rsp+0x10]
00007cc2f47d6beb  vmovaps xmm2, [rsp+0x20]
00007cc2f47d6bf1  vmovaps xmm3, [rsp+0x30]
00007cc2f47d6bf7  vmovaps xmm4, [rsp+0x40]
00007cc2f47d6bfd  vmovaps xmm5, [rsp+0x50]
00007cc2f47d6c03  vmovaps xmm6, [rsp+0x60]
00007cc2f47d6c09  vmovaps xmm7, [rsp+0x70]
00007cc2f47d6c0f  vmovaps xmm8, [rsp+0x80]
00007cc2f47d6c18  vmovaps xmm10, [rsp+0x90]
00007cc2f47d6c21  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d6c2a  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d6c33  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d6c3c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d6c45  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d6c4e  add rsp, 0xF0
00007cc2f47d6c55  pop r11
00007cc2f47d6c57  pop r10
00007cc2f47d6c59  pop r9
00007cc2f47d6c5b  pop r8
00007cc2f47d6c5d  pop rsi
00007cc2f47d6c5e  pop rdi
00007cc2f47d6c5f  pop rdx
00007cc2f47d6c60  pop rcx
00007cc2f47d6c61  pop rax
00007cc2f47d6c62  add rsp, 0x08
00007cc2f47d6c66  jmp 0x00007CC2F47D321C
00007cc2f47d6c6b  sub rsp, 0x08
00007cc2f47d6c6f  push rax
00007cc2f47d6c70  push rcx
00007cc2f47d6c71  push rdx
00007cc2f47d6c72  push rdi
00007cc2f47d6c73  push rsi
00007cc2f47d6c74  push r8
00007cc2f47d6c76  push r9
00007cc2f47d6c78  push r10
00007cc2f47d6c7a  push r11
00007cc2f47d6c7c  sub rsp, 0xF0
00007cc2f47d6c83  vmovaps [rsp], xmm0
00007cc2f47d6c88  vmovaps [rsp+0x10], xmm1
00007cc2f47d6c8e  vmovaps [rsp+0x20], xmm2
00007cc2f47d6c94  vmovaps [rsp+0x30], xmm3
00007cc2f47d6c9a  vmovaps [rsp+0x40], xmm4
00007cc2f47d6ca0  vmovaps [rsp+0x50], xmm5
00007cc2f47d6ca6  vmovaps [rsp+0x60], xmm6
00007cc2f47d6cac  vmovaps [rsp+0x70], xmm7
00007cc2f47d6cb2  vmovaps [rsp+0x80], xmm8
00007cc2f47d6cbb  vmovaps [rsp+0x90], xmm9
00007cc2f47d6cc4  vmovaps [rsp+0xA0], xmm11
00007cc2f47d6ccd  vmovaps [rsp+0xB0], xmm12
00007cc2f47d6cd6  vmovaps [rsp+0xC0], xmm13
00007cc2f47d6cdf  vmovaps [rsp+0xD0], xmm14
00007cc2f47d6ce8  vmovaps [rsp+0xE0], xmm15
00007cc2f47d6cf1  sub rsp, 0x30
00007cc2f47d6cf5  movaps [rsp], xmm10
00007cc2f47d6cfa  movaps [rsp+0x10], xmm1
00007cc2f47d6cff  movaps [rsp+0x20], xmm11
00007cc2f47d6d05  lea rdi, [rsp]
00007cc2f47d6d09  mov esi, 0x00
00007cc2f47d6d0e  mov rax, 0x5990E710A530
00007cc2f47d6d18  call rax
00007cc2f47d6d1a  movaps xmm10, [rsp]
00007cc2f47d6d1f  add rsp, 0x30
00007cc2f47d6d23  vmovaps xmm0, [rsp]
00007cc2f47d6d28  vmovaps xmm1, [rsp+0x10]
00007cc2f47d6d2e  vmovaps xmm2, [rsp+0x20]
00007cc2f47d6d34  vmovaps xmm3, [rsp+0x30]
00007cc2f47d6d3a  vmovaps xmm4, [rsp+0x40]
00007cc2f47d6d40  vmovaps xmm5, [rsp+0x50]
00007cc2f47d6d46  vmovaps xmm6, [rsp+0x60]
00007cc2f47d6d4c  vmovaps xmm7, [rsp+0x70]
00007cc2f47d6d52  vmovaps xmm8, [rsp+0x80]
00007cc2f47d6d5b  vmovaps xmm9, [rsp+0x90]
00007cc2f47d6d64  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d6d6d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d6d76  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d6d7f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d6d88  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d6d91  add rsp, 0xF0
00007cc2f47d6d98  pop r11
00007cc2f47d6d9a  pop r10
00007cc2f47d6d9c  pop r9
00007cc2f47d6d9e  pop r8
00007cc2f47d6da0  pop rsi
00007cc2f47d6da1  pop rdi
00007cc2f47d6da2  pop rdx
00007cc2f47d6da3  pop rcx
00007cc2f47d6da4  pop rax
00007cc2f47d6da5  add rsp, 0x08
00007cc2f47d6da9  jmp 0x00007CC2F47D3237
00007cc2f47d6dae  sub rsp, 0x08
00007cc2f47d6db2  push rax
00007cc2f47d6db3  push rcx
00007cc2f47d6db4  push rdx
00007cc2f47d6db5  push rdi
00007cc2f47d6db6  push rsi
00007cc2f47d6db7  push r8
00007cc2f47d6db9  push r9
00007cc2f47d6dbb  push r10
00007cc2f47d6dbd  push r11
00007cc2f47d6dbf  sub rsp, 0xF0
00007cc2f47d6dc6  vmovaps [rsp], xmm0
00007cc2f47d6dcb  vmovaps [rsp+0x10], xmm2
00007cc2f47d6dd1  vmovaps [rsp+0x20], xmm3
00007cc2f47d6dd7  vmovaps [rsp+0x30], xmm4
00007cc2f47d6ddd  vmovaps [rsp+0x40], xmm5
00007cc2f47d6de3  vmovaps [rsp+0x50], xmm6
00007cc2f47d6de9  vmovaps [rsp+0x60], xmm7
00007cc2f47d6def  vmovaps [rsp+0x70], xmm8
00007cc2f47d6df5  vmovaps [rsp+0x80], xmm9
00007cc2f47d6dfe  vmovaps [rsp+0x90], xmm10
00007cc2f47d6e07  vmovaps [rsp+0xA0], xmm11
00007cc2f47d6e10  vmovaps [rsp+0xB0], xmm12
00007cc2f47d6e19  vmovaps [rsp+0xC0], xmm13
00007cc2f47d6e22  vmovaps [rsp+0xD0], xmm14
00007cc2f47d6e2b  vmovaps [rsp+0xE0], xmm15
00007cc2f47d6e34  sub rsp, 0x30
00007cc2f47d6e38  movaps [rsp], xmm1
00007cc2f47d6e3c  movaps [rsp+0x10], xmm15
00007cc2f47d6e42  movaps [rsp+0x20], xmm6
00007cc2f47d6e47  lea rdi, [rsp]
00007cc2f47d6e4b  mov esi, 0x00
00007cc2f47d6e50  mov rax, 0x5990E710A530
00007cc2f47d6e5a  call rax
00007cc2f47d6e5c  movaps xmm1, [rsp]
00007cc2f47d6e60  add rsp, 0x30
00007cc2f47d6e64  vmovaps xmm0, [rsp]
00007cc2f47d6e69  vmovaps xmm2, [rsp+0x10]
00007cc2f47d6e6f  vmovaps xmm3, [rsp+0x20]
00007cc2f47d6e75  vmovaps xmm4, [rsp+0x30]
00007cc2f47d6e7b  vmovaps xmm5, [rsp+0x40]
00007cc2f47d6e81  vmovaps xmm6, [rsp+0x50]
00007cc2f47d6e87  vmovaps xmm7, [rsp+0x60]
00007cc2f47d6e8d  vmovaps xmm8, [rsp+0x70]
00007cc2f47d6e93  vmovaps xmm9, [rsp+0x80]
00007cc2f47d6e9c  vmovaps xmm10, [rsp+0x90]
00007cc2f47d6ea5  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d6eae  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d6eb7  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d6ec0  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d6ec9  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d6ed2  add rsp, 0xF0
00007cc2f47d6ed9  pop r11
00007cc2f47d6edb  pop r10
00007cc2f47d6edd  pop r9
00007cc2f47d6edf  pop r8
00007cc2f47d6ee1  pop rsi
00007cc2f47d6ee2  pop rdi
00007cc2f47d6ee3  pop rdx
00007cc2f47d6ee4  pop rcx
00007cc2f47d6ee5  pop rax
00007cc2f47d6ee6  add rsp, 0x08
00007cc2f47d6eea  jmp 0x00007CC2F47D3250
00007cc2f47d6eef  sub rsp, 0x08
00007cc2f47d6ef3  push rax
00007cc2f47d6ef4  push rcx
00007cc2f47d6ef5  push rdx
00007cc2f47d6ef6  push rdi
00007cc2f47d6ef7  push rsi
00007cc2f47d6ef8  push r8
00007cc2f47d6efa  push r9
00007cc2f47d6efc  push r10
00007cc2f47d6efe  push r11
00007cc2f47d6f00  sub rsp, 0xF0
00007cc2f47d6f07  vmovaps [rsp], xmm0
00007cc2f47d6f0c  vmovaps [rsp+0x10], xmm1
00007cc2f47d6f12  vmovaps [rsp+0x20], xmm2
00007cc2f47d6f18  vmovaps [rsp+0x30], xmm3
00007cc2f47d6f1e  vmovaps [rsp+0x40], xmm4
00007cc2f47d6f24  vmovaps [rsp+0x50], xmm5
00007cc2f47d6f2a  vmovaps [rsp+0x60], xmm6
00007cc2f47d6f30  vmovaps [rsp+0x70], xmm7
00007cc2f47d6f36  vmovaps [rsp+0x80], xmm8
00007cc2f47d6f3f  vmovaps [rsp+0x90], xmm9
00007cc2f47d6f48  vmovaps [rsp+0xA0], xmm10
00007cc2f47d6f51  vmovaps [rsp+0xB0], xmm12
00007cc2f47d6f5a  vmovaps [rsp+0xC0], xmm13
00007cc2f47d6f63  vmovaps [rsp+0xD0], xmm14
00007cc2f47d6f6c  vmovaps [rsp+0xE0], xmm15
00007cc2f47d6f75  sub rsp, 0x30
00007cc2f47d6f79  movaps [rsp], xmm11
00007cc2f47d6f7e  movaps [rsp+0x10], xmm12
00007cc2f47d6f84  movaps [rsp+0x20], xmm15
00007cc2f47d6f8a  lea rdi, [rsp]
00007cc2f47d6f8e  mov esi, 0x00
00007cc2f47d6f93  mov rax, 0x5990E710A530
00007cc2f47d6f9d  call rax
00007cc2f47d6f9f  movaps xmm11, [rsp]
00007cc2f47d6fa4  add rsp, 0x30
00007cc2f47d6fa8  vmovaps xmm0, [rsp]
00007cc2f47d6fad  vmovaps xmm1, [rsp+0x10]
00007cc2f47d6fb3  vmovaps xmm2, [rsp+0x20]
00007cc2f47d6fb9  vmovaps xmm3, [rsp+0x30]
00007cc2f47d6fbf  vmovaps xmm4, [rsp+0x40]
00007cc2f47d6fc5  vmovaps xmm5, [rsp+0x50]
00007cc2f47d6fcb  vmovaps xmm6, [rsp+0x60]
00007cc2f47d6fd1  vmovaps xmm7, [rsp+0x70]
00007cc2f47d6fd7  vmovaps xmm8, [rsp+0x80]
00007cc2f47d6fe0  vmovaps xmm9, [rsp+0x90]
00007cc2f47d6fe9  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d6ff2  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d6ffb  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d7004  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d700d  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d7016  add rsp, 0xF0
00007cc2f47d701d  pop r11
00007cc2f47d701f  pop r10
00007cc2f47d7021  pop r9
00007cc2f47d7023  pop r8
00007cc2f47d7025  pop rsi
00007cc2f47d7026  pop rdi
00007cc2f47d7027  pop rdx
00007cc2f47d7028  pop rcx
00007cc2f47d7029  pop rax
00007cc2f47d702a  add rsp, 0x08
00007cc2f47d702e  jmp 0x00007CC2F47D327A
00007cc2f47d7033  sub rsp, 0x08
00007cc2f47d7037  push rax
00007cc2f47d7038  push rcx
00007cc2f47d7039  push rdx
00007cc2f47d703a  push rdi
00007cc2f47d703b  push rsi
00007cc2f47d703c  push r8
00007cc2f47d703e  push r9
00007cc2f47d7040  push r10
00007cc2f47d7042  push r11
00007cc2f47d7044  sub rsp, 0xF0
00007cc2f47d704b  vmovaps [rsp], xmm0
00007cc2f47d7050  vmovaps [rsp+0x10], xmm1
00007cc2f47d7056  vmovaps [rsp+0x20], xmm2
00007cc2f47d705c  vmovaps [rsp+0x30], xmm3
00007cc2f47d7062  vmovaps [rsp+0x40], xmm4
00007cc2f47d7068  vmovaps [rsp+0x50], xmm5
00007cc2f47d706e  vmovaps [rsp+0x60], xmm6
00007cc2f47d7074  vmovaps [rsp+0x70], xmm7
00007cc2f47d707a  vmovaps [rsp+0x80], xmm8
00007cc2f47d7083  vmovaps [rsp+0x90], xmm9
00007cc2f47d708c  vmovaps [rsp+0xA0], xmm10
00007cc2f47d7095  vmovaps [rsp+0xB0], xmm11
00007cc2f47d709e  vmovaps [rsp+0xC0], xmm13
00007cc2f47d70a7  vmovaps [rsp+0xD0], xmm14
00007cc2f47d70b0  vmovaps [rsp+0xE0], xmm15
00007cc2f47d70b9  sub rsp, 0x30
00007cc2f47d70bd  movaps [rsp], xmm12
00007cc2f47d70c2  movaps [rsp+0x10], xmm8
00007cc2f47d70c8  movaps [rsp+0x20], xmm15
00007cc2f47d70ce  lea rdi, [rsp]
00007cc2f47d70d2  mov esi, 0x00
00007cc2f47d70d7  mov rax, 0x5990E710A530
00007cc2f47d70e1  call rax
00007cc2f47d70e3  movaps xmm12, [rsp]
00007cc2f47d70e8  add rsp, 0x30
00007cc2f47d70ec  vmovaps xmm0, [rsp]
00007cc2f47d70f1  vmovaps xmm1, [rsp+0x10]
00007cc2f47d70f7  vmovaps xmm2, [rsp+0x20]
00007cc2f47d70fd  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7103  vmovaps xmm4, [rsp+0x40]
00007cc2f47d7109  vmovaps xmm5, [rsp+0x50]
00007cc2f47d710f  vmovaps xmm6, [rsp+0x60]
00007cc2f47d7115  vmovaps xmm7, [rsp+0x70]
00007cc2f47d711b  vmovaps xmm8, [rsp+0x80]
00007cc2f47d7124  vmovaps xmm9, [rsp+0x90]
00007cc2f47d712d  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d7136  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d713f  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d7148  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d7151  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d715a  add rsp, 0xF0
00007cc2f47d7161  pop r11
00007cc2f47d7163  pop r10
00007cc2f47d7165  pop r9
00007cc2f47d7167  pop r8
00007cc2f47d7169  pop rsi
00007cc2f47d716a  pop rdi
00007cc2f47d716b  pop rdx
00007cc2f47d716c  pop rcx
00007cc2f47d716d  pop rax
00007cc2f47d716e  add rsp, 0x08
00007cc2f47d7172  jmp 0x00007CC2F47D32A9
00007cc2f47d7177  sub rsp, 0x08
00007cc2f47d717b  push rax
00007cc2f47d717c  push rcx
00007cc2f47d717d  push rdx
00007cc2f47d717e  push rdi
00007cc2f47d717f  push rsi
00007cc2f47d7180  push r8
00007cc2f47d7182  push r9
00007cc2f47d7184  push r10
00007cc2f47d7186  push r11
00007cc2f47d7188  sub rsp, 0xF0
00007cc2f47d718f  vmovaps [rsp], xmm0
00007cc2f47d7194  vmovaps [rsp+0x10], xmm1
00007cc2f47d719a  vmovaps [rsp+0x20], xmm2
00007cc2f47d71a0  vmovaps [rsp+0x30], xmm3
00007cc2f47d71a6  vmovaps [rsp+0x40], xmm4
00007cc2f47d71ac  vmovaps [rsp+0x50], xmm5
00007cc2f47d71b2  vmovaps [rsp+0x60], xmm6
00007cc2f47d71b8  vmovaps [rsp+0x70], xmm7
00007cc2f47d71be  vmovaps [rsp+0x80], xmm9
00007cc2f47d71c7  vmovaps [rsp+0x90], xmm10
00007cc2f47d71d0  vmovaps [rsp+0xA0], xmm11
00007cc2f47d71d9  vmovaps [rsp+0xB0], xmm12
00007cc2f47d71e2  vmovaps [rsp+0xC0], xmm13
00007cc2f47d71eb  vmovaps [rsp+0xD0], xmm14
00007cc2f47d71f4  vmovaps [rsp+0xE0], xmm15
00007cc2f47d71fd  sub rsp, 0x30
00007cc2f47d7201  movaps [rsp], xmm8
00007cc2f47d7206  movaps [rsp+0x10], xmm7
00007cc2f47d720b  movaps [rsp+0x20], xmm15
00007cc2f47d7211  lea rdi, [rsp]
00007cc2f47d7215  mov esi, 0x00
00007cc2f47d721a  mov rax, 0x5990E710A530
00007cc2f47d7224  call rax
00007cc2f47d7226  movaps xmm8, [rsp]
00007cc2f47d722b  add rsp, 0x30
00007cc2f47d722f  vmovaps xmm0, [rsp]
00007cc2f47d7234  vmovaps xmm1, [rsp+0x10]
00007cc2f47d723a  vmovaps xmm2, [rsp+0x20]
00007cc2f47d7240  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7246  vmovaps xmm4, [rsp+0x40]
00007cc2f47d724c  vmovaps xmm5, [rsp+0x50]
00007cc2f47d7252  vmovaps xmm6, [rsp+0x60]
00007cc2f47d7258  vmovaps xmm7, [rsp+0x70]
00007cc2f47d725e  vmovaps xmm9, [rsp+0x80]
00007cc2f47d7267  vmovaps xmm10, [rsp+0x90]
00007cc2f47d7270  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d7279  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d7282  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d728b  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d7294  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d729d  add rsp, 0xF0
00007cc2f47d72a4  pop r11
00007cc2f47d72a6  pop r10
00007cc2f47d72a8  pop r9
00007cc2f47d72aa  pop r8
00007cc2f47d72ac  pop rsi
00007cc2f47d72ad  pop rdi
00007cc2f47d72ae  pop rdx
00007cc2f47d72af  pop rcx
00007cc2f47d72b0  pop rax
00007cc2f47d72b1  add rsp, 0x08
00007cc2f47d72b5  jmp 0x00007CC2F47D32CF
00007cc2f47d72ba  sub rsp, 0x08
00007cc2f47d72be  push rax
00007cc2f47d72bf  push rcx
00007cc2f47d72c0  push rdx
00007cc2f47d72c1  push rdi
00007cc2f47d72c2  push rsi
00007cc2f47d72c3  push r8
00007cc2f47d72c5  push r9
00007cc2f47d72c7  push r10
00007cc2f47d72c9  push r11
00007cc2f47d72cb  sub rsp, 0xF0
00007cc2f47d72d2  vmovaps [rsp], xmm0
00007cc2f47d72d7  vmovaps [rsp+0x10], xmm1
00007cc2f47d72dd  vmovaps [rsp+0x20], xmm2
00007cc2f47d72e3  vmovaps [rsp+0x30], xmm3
00007cc2f47d72e9  vmovaps [rsp+0x40], xmm4
00007cc2f47d72ef  vmovaps [rsp+0x50], xmm5
00007cc2f47d72f5  vmovaps [rsp+0x60], xmm6
00007cc2f47d72fb  vmovaps [rsp+0x70], xmm7
00007cc2f47d7301  vmovaps [rsp+0x80], xmm8
00007cc2f47d730a  vmovaps [rsp+0x90], xmm9
00007cc2f47d7313  vmovaps [rsp+0xA0], xmm10
00007cc2f47d731c  vmovaps [rsp+0xB0], xmm11
00007cc2f47d7325  vmovaps [rsp+0xC0], xmm12
00007cc2f47d732e  vmovaps [rsp+0xD0], xmm13
00007cc2f47d7337  vmovaps [rsp+0xE0], xmm14
00007cc2f47d7340  sub rsp, 0x30
00007cc2f47d7344  movaps [rsp], xmm15
00007cc2f47d7349  movaps [rsp+0x10], xmm14
00007cc2f47d734f  movaps [rsp+0x20], xmm9
00007cc2f47d7355  lea rdi, [rsp]
00007cc2f47d7359  mov esi, 0x00
00007cc2f47d735e  mov rax, 0x5990E710A530
00007cc2f47d7368  call rax
00007cc2f47d736a  movaps xmm15, [rsp]
00007cc2f47d736f  add rsp, 0x30
00007cc2f47d7373  vmovaps xmm0, [rsp]
00007cc2f47d7378  vmovaps xmm1, [rsp+0x10]
00007cc2f47d737e  vmovaps xmm2, [rsp+0x20]
00007cc2f47d7384  vmovaps xmm3, [rsp+0x30]
00007cc2f47d738a  vmovaps xmm4, [rsp+0x40]
00007cc2f47d7390  vmovaps xmm5, [rsp+0x50]
00007cc2f47d7396  vmovaps xmm6, [rsp+0x60]
00007cc2f47d739c  vmovaps xmm7, [rsp+0x70]
00007cc2f47d73a2  vmovaps xmm8, [rsp+0x80]
00007cc2f47d73ab  vmovaps xmm9, [rsp+0x90]
00007cc2f47d73b4  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d73bd  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d73c6  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d73cf  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d73d8  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d73e1  add rsp, 0xF0
00007cc2f47d73e8  pop r11
00007cc2f47d73ea  pop r10
00007cc2f47d73ec  pop r9
00007cc2f47d73ee  pop r8
00007cc2f47d73f0  pop rsi
00007cc2f47d73f1  pop rdi
00007cc2f47d73f2  pop rdx
00007cc2f47d73f3  pop rcx
00007cc2f47d73f4  pop rax
00007cc2f47d73f5  add rsp, 0x08
00007cc2f47d73f9  jmp 0x00007CC2F47D32E9
00007cc2f47d73fe  sub rsp, 0x08
00007cc2f47d7402  push rax
00007cc2f47d7403  push rcx
00007cc2f47d7404  push rdx
00007cc2f47d7405  push rdi
00007cc2f47d7406  push rsi
00007cc2f47d7407  push r8
00007cc2f47d7409  push r9
00007cc2f47d740b  push r10
00007cc2f47d740d  push r11
00007cc2f47d740f  sub rsp, 0xF0
00007cc2f47d7416  vmovaps [rsp], xmm0
00007cc2f47d741b  vmovaps [rsp+0x10], xmm1
00007cc2f47d7421  vmovaps [rsp+0x20], xmm2
00007cc2f47d7427  vmovaps [rsp+0x30], xmm3
00007cc2f47d742d  vmovaps [rsp+0x40], xmm4
00007cc2f47d7433  vmovaps [rsp+0x50], xmm5
00007cc2f47d7439  vmovaps [rsp+0x60], xmm6
00007cc2f47d743f  vmovaps [rsp+0x70], xmm7
00007cc2f47d7445  vmovaps [rsp+0x80], xmm8
00007cc2f47d744e  vmovaps [rsp+0x90], xmm10
00007cc2f47d7457  vmovaps [rsp+0xA0], xmm11
00007cc2f47d7460  vmovaps [rsp+0xB0], xmm12
00007cc2f47d7469  vmovaps [rsp+0xC0], xmm13
00007cc2f47d7472  vmovaps [rsp+0xD0], xmm14
00007cc2f47d747b  vmovaps [rsp+0xE0], xmm15
00007cc2f47d7484  sub rsp, 0x30
00007cc2f47d7488  movaps [rsp], xmm9
00007cc2f47d748d  movaps [rsp+0x10], xmm7
00007cc2f47d7492  movaps [rsp+0x20], xmm14
00007cc2f47d7498  lea rdi, [rsp]
00007cc2f47d749c  mov esi, 0x00
00007cc2f47d74a1  mov rax, 0x5990E710A530
00007cc2f47d74ab  call rax
00007cc2f47d74ad  movaps xmm9, [rsp]
00007cc2f47d74b2  add rsp, 0x30
00007cc2f47d74b6  vmovaps xmm0, [rsp]
00007cc2f47d74bb  vmovaps xmm1, [rsp+0x10]
00007cc2f47d74c1  vmovaps xmm2, [rsp+0x20]
00007cc2f47d74c7  vmovaps xmm3, [rsp+0x30]
00007cc2f47d74cd  vmovaps xmm4, [rsp+0x40]
00007cc2f47d74d3  vmovaps xmm5, [rsp+0x50]
00007cc2f47d74d9  vmovaps xmm6, [rsp+0x60]
00007cc2f47d74df  vmovaps xmm7, [rsp+0x70]
00007cc2f47d74e5  vmovaps xmm8, [rsp+0x80]
00007cc2f47d74ee  vmovaps xmm10, [rsp+0x90]
00007cc2f47d74f7  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d7500  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d7509  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d7512  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d751b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d7524  add rsp, 0xF0
00007cc2f47d752b  pop r11
00007cc2f47d752d  pop r10
00007cc2f47d752f  pop r9
00007cc2f47d7531  pop r8
00007cc2f47d7533  pop rsi
00007cc2f47d7534  pop rdi
00007cc2f47d7535  pop rdx
00007cc2f47d7536  pop rcx
00007cc2f47d7537  pop rax
00007cc2f47d7538  add rsp, 0x08
00007cc2f47d753c  jmp 0x00007CC2F47D3318
00007cc2f47d7541  sub rsp, 0x08
00007cc2f47d7545  push rax
00007cc2f47d7546  push rcx
00007cc2f47d7547  push rdx
00007cc2f47d7548  push rdi
00007cc2f47d7549  push rsi
00007cc2f47d754a  push r8
00007cc2f47d754c  push r9
00007cc2f47d754e  push r10
00007cc2f47d7550  push r11
00007cc2f47d7552  sub rsp, 0xF0
00007cc2f47d7559  vmovaps [rsp], xmm0
00007cc2f47d755e  vmovaps [rsp+0x10], xmm1
00007cc2f47d7564  vmovaps [rsp+0x20], xmm2
00007cc2f47d756a  vmovaps [rsp+0x30], xmm3
00007cc2f47d7570  vmovaps [rsp+0x40], xmm4
00007cc2f47d7576  vmovaps [rsp+0x50], xmm5
00007cc2f47d757c  vmovaps [rsp+0x60], xmm6
00007cc2f47d7582  vmovaps [rsp+0x70], xmm7
00007cc2f47d7588  vmovaps [rsp+0x80], xmm8
00007cc2f47d7591  vmovaps [rsp+0x90], xmm9
00007cc2f47d759a  vmovaps [rsp+0xA0], xmm10
00007cc2f47d75a3  vmovaps [rsp+0xB0], xmm11
00007cc2f47d75ac  vmovaps [rsp+0xC0], xmm12
00007cc2f47d75b5  vmovaps [rsp+0xD0], xmm13
00007cc2f47d75be  vmovaps [rsp+0xE0], xmm15
00007cc2f47d75c7  sub rsp, 0x30
00007cc2f47d75cb  movaps [rsp], xmm14
00007cc2f47d75d0  movaps [rsp+0x10], xmm13
00007cc2f47d75d6  movaps [rsp+0x20], xmm11
00007cc2f47d75dc  lea rdi, [rsp]
00007cc2f47d75e0  mov esi, 0x00
00007cc2f47d75e5  mov rax, 0x5990E710A530
00007cc2f47d75ef  call rax
00007cc2f47d75f1  movaps xmm14, [rsp]
00007cc2f47d75f6  add rsp, 0x30
00007cc2f47d75fa  vmovaps xmm0, [rsp]
00007cc2f47d75ff  vmovaps xmm1, [rsp+0x10]
00007cc2f47d7605  vmovaps xmm2, [rsp+0x20]
00007cc2f47d760b  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7611  vmovaps xmm4, [rsp+0x40]
00007cc2f47d7617  vmovaps xmm5, [rsp+0x50]
00007cc2f47d761d  vmovaps xmm6, [rsp+0x60]
00007cc2f47d7623  vmovaps xmm7, [rsp+0x70]
00007cc2f47d7629  vmovaps xmm8, [rsp+0x80]
00007cc2f47d7632  vmovaps xmm9, [rsp+0x90]
00007cc2f47d763b  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d7644  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d764d  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d7656  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d765f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d7668  add rsp, 0xF0
00007cc2f47d766f  pop r11
00007cc2f47d7671  pop r10
00007cc2f47d7673  pop r9
00007cc2f47d7675  pop r8
00007cc2f47d7677  pop rsi
00007cc2f47d7678  pop rdi
00007cc2f47d7679  pop rdx
00007cc2f47d767a  pop rcx
00007cc2f47d767b  pop rax
00007cc2f47d767c  add rsp, 0x08
00007cc2f47d7680  jmp 0x00007CC2F47D3332
00007cc2f47d7685  sub rsp, 0x08
00007cc2f47d7689  push rax
00007cc2f47d768a  push rcx
00007cc2f47d768b  push rdx
00007cc2f47d768c  push rdi
00007cc2f47d768d  push rsi
00007cc2f47d768e  push r8
00007cc2f47d7690  push r9
00007cc2f47d7692  push r10
00007cc2f47d7694  push r11
00007cc2f47d7696  sub rsp, 0xF0
00007cc2f47d769d  vmovaps [rsp], xmm0
00007cc2f47d76a2  vmovaps [rsp+0x10], xmm1
00007cc2f47d76a8  vmovaps [rsp+0x20], xmm2
00007cc2f47d76ae  vmovaps [rsp+0x30], xmm3
00007cc2f47d76b4  vmovaps [rsp+0x40], xmm4
00007cc2f47d76ba  vmovaps [rsp+0x50], xmm5
00007cc2f47d76c0  vmovaps [rsp+0x60], xmm6
00007cc2f47d76c6  vmovaps [rsp+0x70], xmm7
00007cc2f47d76cc  vmovaps [rsp+0x80], xmm8
00007cc2f47d76d5  vmovaps [rsp+0x90], xmm9
00007cc2f47d76de  vmovaps [rsp+0xA0], xmm10
00007cc2f47d76e7  vmovaps [rsp+0xB0], xmm12
00007cc2f47d76f0  vmovaps [rsp+0xC0], xmm13
00007cc2f47d76f9  vmovaps [rsp+0xD0], xmm14
00007cc2f47d7702  vmovaps [rsp+0xE0], xmm15
00007cc2f47d770b  sub rsp, 0x30
00007cc2f47d770f  movaps [rsp], xmm11
00007cc2f47d7714  movaps [rsp+0x10], xmm7
00007cc2f47d7719  movaps [rsp+0x20], xmm13
00007cc2f47d771f  lea rdi, [rsp]
00007cc2f47d7723  mov esi, 0x00
00007cc2f47d7728  mov rax, 0x5990E710A530
00007cc2f47d7732  call rax
00007cc2f47d7734  movaps xmm11, [rsp]
00007cc2f47d7739  add rsp, 0x30
00007cc2f47d773d  vmovaps xmm0, [rsp]
00007cc2f47d7742  vmovaps xmm1, [rsp+0x10]
00007cc2f47d7748  vmovaps xmm2, [rsp+0x20]
00007cc2f47d774e  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7754  vmovaps xmm4, [rsp+0x40]
00007cc2f47d775a  vmovaps xmm5, [rsp+0x50]
00007cc2f47d7760  vmovaps xmm6, [rsp+0x60]
00007cc2f47d7766  vmovaps xmm7, [rsp+0x70]
00007cc2f47d776c  vmovaps xmm8, [rsp+0x80]
00007cc2f47d7775  vmovaps xmm9, [rsp+0x90]
00007cc2f47d777e  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d7787  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d7790  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d7799  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d77a2  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d77ab  add rsp, 0xF0
00007cc2f47d77b2  pop r11
00007cc2f47d77b4  pop r10
00007cc2f47d77b6  pop r9
00007cc2f47d77b8  pop r8
00007cc2f47d77ba  pop rsi
00007cc2f47d77bb  pop rdi
00007cc2f47d77bc  pop rdx
00007cc2f47d77bd  pop rcx
00007cc2f47d77be  pop rax
00007cc2f47d77bf  add rsp, 0x08
00007cc2f47d77c3  jmp 0x00007CC2F47D335E
00007cc2f47d77c8  sub rsp, 0x08
00007cc2f47d77cc  push rax
00007cc2f47d77cd  push rcx
00007cc2f47d77ce  push rdx
00007cc2f47d77cf  push rdi
00007cc2f47d77d0  push rsi
00007cc2f47d77d1  push r8
00007cc2f47d77d3  push r9
00007cc2f47d77d5  push r10
00007cc2f47d77d7  push r11
00007cc2f47d77d9  sub rsp, 0xF0
00007cc2f47d77e0  vmovaps [rsp], xmm0
00007cc2f47d77e5  vmovaps [rsp+0x10], xmm1
00007cc2f47d77eb  vmovaps [rsp+0x20], xmm2
00007cc2f47d77f1  vmovaps [rsp+0x30], xmm3
00007cc2f47d77f7  vmovaps [rsp+0x40], xmm4
00007cc2f47d77fd  vmovaps [rsp+0x50], xmm5
00007cc2f47d7803  vmovaps [rsp+0x60], xmm6
00007cc2f47d7809  vmovaps [rsp+0x70], xmm7
00007cc2f47d780f  vmovaps [rsp+0x80], xmm8
00007cc2f47d7818  vmovaps [rsp+0x90], xmm9
00007cc2f47d7821  vmovaps [rsp+0xA0], xmm10
00007cc2f47d782a  vmovaps [rsp+0xB0], xmm11
00007cc2f47d7833  vmovaps [rsp+0xC0], xmm12
00007cc2f47d783c  vmovaps [rsp+0xD0], xmm14
00007cc2f47d7845  vmovaps [rsp+0xE0], xmm15
00007cc2f47d784e  sub rsp, 0x30
00007cc2f47d7852  movaps [rsp], xmm13
00007cc2f47d7857  movaps [rsp+0x10], xmm10
00007cc2f47d785d  movaps [rsp+0x20], xmm12
00007cc2f47d7863  lea rdi, [rsp]
00007cc2f47d7867  mov esi, 0x00
00007cc2f47d786c  mov rax, 0x5990E710A530
00007cc2f47d7876  call rax
00007cc2f47d7878  movaps xmm13, [rsp]
00007cc2f47d787d  add rsp, 0x30
00007cc2f47d7881  vmovaps xmm0, [rsp]
00007cc2f47d7886  vmovaps xmm1, [rsp+0x10]
00007cc2f47d788c  vmovaps xmm2, [rsp+0x20]
00007cc2f47d7892  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7898  vmovaps xmm4, [rsp+0x40]
00007cc2f47d789e  vmovaps xmm5, [rsp+0x50]
00007cc2f47d78a4  vmovaps xmm6, [rsp+0x60]
00007cc2f47d78aa  vmovaps xmm7, [rsp+0x70]
00007cc2f47d78b0  vmovaps xmm8, [rsp+0x80]
00007cc2f47d78b9  vmovaps xmm9, [rsp+0x90]
00007cc2f47d78c2  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d78cb  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d78d4  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d78dd  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d78e6  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d78ef  add rsp, 0xF0
00007cc2f47d78f6  pop r11
00007cc2f47d78f8  pop r10
00007cc2f47d78fa  pop r9
00007cc2f47d78fc  pop r8
00007cc2f47d78fe  pop rsi
00007cc2f47d78ff  pop rdi
00007cc2f47d7900  pop rdx
00007cc2f47d7901  pop rcx
00007cc2f47d7902  pop rax
00007cc2f47d7903  add rsp, 0x08
00007cc2f47d7907  jmp 0x00007CC2F47D3378
00007cc2f47d790c  sub rsp, 0x08
00007cc2f47d7910  push rax
00007cc2f47d7911  push rcx
00007cc2f47d7912  push rdx
00007cc2f47d7913  push rdi
00007cc2f47d7914  push rsi
00007cc2f47d7915  push r8
00007cc2f47d7917  push r9
00007cc2f47d7919  push r10
00007cc2f47d791b  push r11
00007cc2f47d791d  sub rsp, 0xF0
00007cc2f47d7924  vmovaps [rsp], xmm0
00007cc2f47d7929  vmovaps [rsp+0x10], xmm1
00007cc2f47d792f  vmovaps [rsp+0x20], xmm2
00007cc2f47d7935  vmovaps [rsp+0x30], xmm3
00007cc2f47d793b  vmovaps [rsp+0x40], xmm4
00007cc2f47d7941  vmovaps [rsp+0x50], xmm5
00007cc2f47d7947  vmovaps [rsp+0x60], xmm6
00007cc2f47d794d  vmovaps [rsp+0x70], xmm7
00007cc2f47d7953  vmovaps [rsp+0x80], xmm8
00007cc2f47d795c  vmovaps [rsp+0x90], xmm9
00007cc2f47d7965  vmovaps [rsp+0xA0], xmm11
00007cc2f47d796e  vmovaps [rsp+0xB0], xmm12
00007cc2f47d7977  vmovaps [rsp+0xC0], xmm13
00007cc2f47d7980  vmovaps [rsp+0xD0], xmm14
00007cc2f47d7989  vmovaps [rsp+0xE0], xmm15
00007cc2f47d7992  sub rsp, 0x30
00007cc2f47d7996  movaps [rsp], xmm10
00007cc2f47d799b  movaps [rsp+0x10], xmm7
00007cc2f47d79a0  movaps [rsp+0x20], xmm12
00007cc2f47d79a6  lea rdi, [rsp]
00007cc2f47d79aa  mov esi, 0x00
00007cc2f47d79af  mov rax, 0x5990E710A530
00007cc2f47d79b9  call rax
00007cc2f47d79bb  movaps xmm10, [rsp]
00007cc2f47d79c0  add rsp, 0x30
00007cc2f47d79c4  vmovaps xmm0, [rsp]
00007cc2f47d79c9  vmovaps xmm1, [rsp+0x10]
00007cc2f47d79cf  vmovaps xmm2, [rsp+0x20]
00007cc2f47d79d5  vmovaps xmm3, [rsp+0x30]
00007cc2f47d79db  vmovaps xmm4, [rsp+0x40]
00007cc2f47d79e1  vmovaps xmm5, [rsp+0x50]
00007cc2f47d79e7  vmovaps xmm6, [rsp+0x60]
00007cc2f47d79ed  vmovaps xmm7, [rsp+0x70]
00007cc2f47d79f3  vmovaps xmm8, [rsp+0x80]
00007cc2f47d79fc  vmovaps xmm9, [rsp+0x90]
00007cc2f47d7a05  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d7a0e  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d7a17  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d7a20  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d7a29  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d7a32  add rsp, 0xF0
00007cc2f47d7a39  pop r11
00007cc2f47d7a3b  pop r10
00007cc2f47d7a3d  pop r9
00007cc2f47d7a3f  pop r8
00007cc2f47d7a41  pop rsi
00007cc2f47d7a42  pop rdi
00007cc2f47d7a43  pop rdx
00007cc2f47d7a44  pop rcx
00007cc2f47d7a45  pop rax
00007cc2f47d7a46  add rsp, 0x08
00007cc2f47d7a4a  jmp 0x00007CC2F47D33A4
00007cc2f47d7a4f  sub rsp, 0x08
00007cc2f47d7a53  push rax
00007cc2f47d7a54  push rcx
00007cc2f47d7a55  push rdx
00007cc2f47d7a56  push rdi
00007cc2f47d7a57  push rsi
00007cc2f47d7a58  push r8
00007cc2f47d7a5a  push r9
00007cc2f47d7a5c  push r10
00007cc2f47d7a5e  push r11
00007cc2f47d7a60  sub rsp, 0xF0
00007cc2f47d7a67  vmovaps [rsp], xmm0
00007cc2f47d7a6c  vmovaps [rsp+0x10], xmm1
00007cc2f47d7a72  vmovaps [rsp+0x20], xmm2
00007cc2f47d7a78  vmovaps [rsp+0x30], xmm3
00007cc2f47d7a7e  vmovaps [rsp+0x40], xmm4
00007cc2f47d7a84  vmovaps [rsp+0x50], xmm5
00007cc2f47d7a8a  vmovaps [rsp+0x60], xmm6
00007cc2f47d7a90  vmovaps [rsp+0x70], xmm7
00007cc2f47d7a96  vmovaps [rsp+0x80], xmm8
00007cc2f47d7a9f  vmovaps [rsp+0x90], xmm9
00007cc2f47d7aa8  vmovaps [rsp+0xA0], xmm10
00007cc2f47d7ab1  vmovaps [rsp+0xB0], xmm11
00007cc2f47d7aba  vmovaps [rsp+0xC0], xmm13
00007cc2f47d7ac3  vmovaps [rsp+0xD0], xmm14
00007cc2f47d7acc  vmovaps [rsp+0xE0], xmm15
00007cc2f47d7ad5  sub rsp, 0x30
00007cc2f47d7ad9  movaps [rsp], xmm12
00007cc2f47d7ade  movaps [rsp+0x10], xmm1
00007cc2f47d7ae3  movaps [rsp+0x20], xmm8
00007cc2f47d7ae9  lea rdi, [rsp]
00007cc2f47d7aed  mov esi, 0x00
00007cc2f47d7af2  mov rax, 0x5990E710A530
00007cc2f47d7afc  call rax
00007cc2f47d7afe  movaps xmm12, [rsp]
00007cc2f47d7b03  add rsp, 0x30
00007cc2f47d7b07  vmovaps xmm0, [rsp]
00007cc2f47d7b0c  vmovaps xmm1, [rsp+0x10]
00007cc2f47d7b12  vmovaps xmm2, [rsp+0x20]
00007cc2f47d7b18  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7b1e  vmovaps xmm4, [rsp+0x40]
00007cc2f47d7b24  vmovaps xmm5, [rsp+0x50]
00007cc2f47d7b2a  vmovaps xmm6, [rsp+0x60]
00007cc2f47d7b30  vmovaps xmm7, [rsp+0x70]
00007cc2f47d7b36  vmovaps xmm8, [rsp+0x80]
00007cc2f47d7b3f  vmovaps xmm9, [rsp+0x90]
00007cc2f47d7b48  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d7b51  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d7b5a  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d7b63  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d7b6c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d7b75  add rsp, 0xF0
00007cc2f47d7b7c  pop r11
00007cc2f47d7b7e  pop r10
00007cc2f47d7b80  pop r9
00007cc2f47d7b82  pop r8
00007cc2f47d7b84  pop rsi
00007cc2f47d7b85  pop rdi
00007cc2f47d7b86  pop rdx
00007cc2f47d7b87  pop rcx
00007cc2f47d7b88  pop rax
00007cc2f47d7b89  add rsp, 0x08
00007cc2f47d7b8d  jmp 0x00007CC2F47D33BE
00007cc2f47d7b92  call 0x00007CC2F45FF430
00007cc2f47d7b97  jmp 0x00007CC2F47D33C8
00007cc2f47d7b9c  sub rsp, 0x08
00007cc2f47d7ba0  push rax
00007cc2f47d7ba1  push rcx
00007cc2f47d7ba2  push rdx
00007cc2f47d7ba3  push rdi
00007cc2f47d7ba4  push rsi
00007cc2f47d7ba5  push r8
00007cc2f47d7ba7  push r9
00007cc2f47d7ba9  push r10
00007cc2f47d7bab  push r11
00007cc2f47d7bad  sub rsp, 0xF0
00007cc2f47d7bb4  vmovaps [rsp], xmm0
00007cc2f47d7bb9  vmovaps [rsp+0x10], xmm1
00007cc2f47d7bbf  vmovaps [rsp+0x20], xmm2
00007cc2f47d7bc5  vmovaps [rsp+0x30], xmm3
00007cc2f47d7bcb  vmovaps [rsp+0x40], xmm4
00007cc2f47d7bd1  vmovaps [rsp+0x50], xmm5
00007cc2f47d7bd7  vmovaps [rsp+0x60], xmm6
00007cc2f47d7bdd  vmovaps [rsp+0x70], xmm7
00007cc2f47d7be3  vmovaps [rsp+0x80], xmm9
00007cc2f47d7bec  vmovaps [rsp+0x90], xmm10
00007cc2f47d7bf5  vmovaps [rsp+0xA0], xmm11
00007cc2f47d7bfe  vmovaps [rsp+0xB0], xmm12
00007cc2f47d7c07  vmovaps [rsp+0xC0], xmm13
00007cc2f47d7c10  vmovaps [rsp+0xD0], xmm14
00007cc2f47d7c19  vmovaps [rsp+0xE0], xmm15
00007cc2f47d7c22  sub rsp, 0x30
00007cc2f47d7c26  movaps [rsp], xmm8
00007cc2f47d7c2b  movaps [rsp+0x10], xmm15
00007cc2f47d7c31  movaps [rsp+0x20], xmm9
00007cc2f47d7c37  lea rdi, [rsp]
00007cc2f47d7c3b  mov esi, 0x00
00007cc2f47d7c40  mov rax, 0x5990E710A530
00007cc2f47d7c4a  call rax
00007cc2f47d7c4c  movaps xmm8, [rsp]
00007cc2f47d7c51  add rsp, 0x30
00007cc2f47d7c55  vmovaps xmm0, [rsp]
00007cc2f47d7c5a  vmovaps xmm1, [rsp+0x10]
00007cc2f47d7c60  vmovaps xmm2, [rsp+0x20]
00007cc2f47d7c66  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7c6c  vmovaps xmm4, [rsp+0x40]
00007cc2f47d7c72  vmovaps xmm5, [rsp+0x50]
00007cc2f47d7c78  vmovaps xmm6, [rsp+0x60]
00007cc2f47d7c7e  vmovaps xmm7, [rsp+0x70]
00007cc2f47d7c84  vmovaps xmm9, [rsp+0x80]
00007cc2f47d7c8d  vmovaps xmm10, [rsp+0x90]
00007cc2f47d7c96  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d7c9f  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d7ca8  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d7cb1  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d7cba  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d7cc3  add rsp, 0xF0
00007cc2f47d7cca  pop r11
00007cc2f47d7ccc  pop r10
00007cc2f47d7cce  pop r9
00007cc2f47d7cd0  pop r8
00007cc2f47d7cd2  pop rsi
00007cc2f47d7cd3  pop rdi
00007cc2f47d7cd4  pop rdx
00007cc2f47d7cd5  pop rcx
00007cc2f47d7cd6  pop rax
00007cc2f47d7cd7  add rsp, 0x08
00007cc2f47d7cdb  jmp 0x00007CC2F47D33EA
00007cc2f47d7ce0  sub rsp, 0x08
00007cc2f47d7ce4  push rax
00007cc2f47d7ce5  push rcx
00007cc2f47d7ce6  push rdx
00007cc2f47d7ce7  push rdi
00007cc2f47d7ce8  push rsi
00007cc2f47d7ce9  push r8
00007cc2f47d7ceb  push r9
00007cc2f47d7ced  push r10
00007cc2f47d7cef  push r11
00007cc2f47d7cf1  sub rsp, 0xF0
00007cc2f47d7cf8  vmovaps [rsp], xmm0
00007cc2f47d7cfd  vmovaps [rsp+0x10], xmm1
00007cc2f47d7d03  vmovaps [rsp+0x20], xmm2
00007cc2f47d7d09  vmovaps [rsp+0x30], xmm3
00007cc2f47d7d0f  vmovaps [rsp+0x40], xmm4
00007cc2f47d7d15  vmovaps [rsp+0x50], xmm5
00007cc2f47d7d1b  vmovaps [rsp+0x60], xmm6
00007cc2f47d7d21  vmovaps [rsp+0x70], xmm7
00007cc2f47d7d27  vmovaps [rsp+0x80], xmm8
00007cc2f47d7d30  vmovaps [rsp+0x90], xmm10
00007cc2f47d7d39  vmovaps [rsp+0xA0], xmm11
00007cc2f47d7d42  vmovaps [rsp+0xB0], xmm12
00007cc2f47d7d4b  vmovaps [rsp+0xC0], xmm13
00007cc2f47d7d54  vmovaps [rsp+0xD0], xmm14
00007cc2f47d7d5d  vmovaps [rsp+0xE0], xmm15
00007cc2f47d7d66  sub rsp, 0x30
00007cc2f47d7d6a  movaps [rsp], xmm9
00007cc2f47d7d6f  movaps [rsp+0x10], xmm1
00007cc2f47d7d74  movaps [rsp+0x20], xmm15
00007cc2f47d7d7a  lea rdi, [rsp]
00007cc2f47d7d7e  mov esi, 0x00
00007cc2f47d7d83  mov rax, 0x5990E710A530
00007cc2f47d7d8d  call rax
00007cc2f47d7d8f  movaps xmm9, [rsp]
00007cc2f47d7d94  add rsp, 0x30
00007cc2f47d7d98  vmovaps xmm0, [rsp]
00007cc2f47d7d9d  vmovaps xmm1, [rsp+0x10]
00007cc2f47d7da3  vmovaps xmm2, [rsp+0x20]
00007cc2f47d7da9  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7daf  vmovaps xmm4, [rsp+0x40]
00007cc2f47d7db5  vmovaps xmm5, [rsp+0x50]
00007cc2f47d7dbb  vmovaps xmm6, [rsp+0x60]
00007cc2f47d7dc1  vmovaps xmm7, [rsp+0x70]
00007cc2f47d7dc7  vmovaps xmm8, [rsp+0x80]
00007cc2f47d7dd0  vmovaps xmm10, [rsp+0x90]
00007cc2f47d7dd9  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d7de2  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d7deb  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d7df4  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d7dfd  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d7e06  add rsp, 0xF0
00007cc2f47d7e0d  pop r11
00007cc2f47d7e0f  pop r10
00007cc2f47d7e11  pop r9
00007cc2f47d7e13  pop r8
00007cc2f47d7e15  pop rsi
00007cc2f47d7e16  pop rdi
00007cc2f47d7e17  pop rdx
00007cc2f47d7e18  pop rcx
00007cc2f47d7e19  pop rax
00007cc2f47d7e1a  add rsp, 0x08
00007cc2f47d7e1e  jmp 0x00007CC2F47D3418
00007cc2f47d7e23  sub rsp, 0x08
00007cc2f47d7e27  push rax
00007cc2f47d7e28  push rcx
00007cc2f47d7e29  push rdx
00007cc2f47d7e2a  push rdi
00007cc2f47d7e2b  push rsi
00007cc2f47d7e2c  push r8
00007cc2f47d7e2e  push r9
00007cc2f47d7e30  push r10
00007cc2f47d7e32  push r11
00007cc2f47d7e34  sub rsp, 0xF0
00007cc2f47d7e3b  vmovaps [rsp], xmm0
00007cc2f47d7e40  vmovaps [rsp+0x10], xmm1
00007cc2f47d7e46  vmovaps [rsp+0x20], xmm2
00007cc2f47d7e4c  vmovaps [rsp+0x30], xmm3
00007cc2f47d7e52  vmovaps [rsp+0x40], xmm4
00007cc2f47d7e58  vmovaps [rsp+0x50], xmm5
00007cc2f47d7e5e  vmovaps [rsp+0x60], xmm6
00007cc2f47d7e64  vmovaps [rsp+0x70], xmm7
00007cc2f47d7e6a  vmovaps [rsp+0x80], xmm8
00007cc2f47d7e73  vmovaps [rsp+0x90], xmm9
00007cc2f47d7e7c  vmovaps [rsp+0xA0], xmm10
00007cc2f47d7e85  vmovaps [rsp+0xB0], xmm11
00007cc2f47d7e8e  vmovaps [rsp+0xC0], xmm12
00007cc2f47d7e97  vmovaps [rsp+0xD0], xmm13
00007cc2f47d7ea0  vmovaps [rsp+0xE0], xmm14
00007cc2f47d7ea9  sub rsp, 0x30
00007cc2f47d7ead  movaps [rsp], xmm15
00007cc2f47d7eb2  movaps [rsp+0x10], xmm4
00007cc2f47d7eb7  movaps [rsp+0x20], xmm1
00007cc2f47d7ebc  lea rdi, [rsp]
00007cc2f47d7ec0  mov esi, 0x00
00007cc2f47d7ec5  mov rax, 0x5990E710A530
00007cc2f47d7ecf  call rax
00007cc2f47d7ed1  movaps xmm15, [rsp]
00007cc2f47d7ed6  add rsp, 0x30
00007cc2f47d7eda  vmovaps xmm0, [rsp]
00007cc2f47d7edf  vmovaps xmm1, [rsp+0x10]
00007cc2f47d7ee5  vmovaps xmm2, [rsp+0x20]
00007cc2f47d7eeb  vmovaps xmm3, [rsp+0x30]
00007cc2f47d7ef1  vmovaps xmm4, [rsp+0x40]
00007cc2f47d7ef7  vmovaps xmm5, [rsp+0x50]
00007cc2f47d7efd  vmovaps xmm6, [rsp+0x60]
00007cc2f47d7f03  vmovaps xmm7, [rsp+0x70]
00007cc2f47d7f09  vmovaps xmm8, [rsp+0x80]
00007cc2f47d7f12  vmovaps xmm9, [rsp+0x90]
00007cc2f47d7f1b  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d7f24  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d7f2d  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d7f36  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d7f3f  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d7f48  add rsp, 0xF0
00007cc2f47d7f4f  pop r11
00007cc2f47d7f51  pop r10
00007cc2f47d7f53  pop r9
00007cc2f47d7f55  pop r8
00007cc2f47d7f57  pop rsi
00007cc2f47d7f58  pop rdi
00007cc2f47d7f59  pop rdx
00007cc2f47d7f5a  pop rcx
00007cc2f47d7f5b  pop rax
00007cc2f47d7f5c  add rsp, 0x08
00007cc2f47d7f60  jmp 0x00007CC2F47D343E
00007cc2f47d7f65  sub rsp, 0x08
00007cc2f47d7f69  push rax
00007cc2f47d7f6a  push rcx
00007cc2f47d7f6b  push rdx
00007cc2f47d7f6c  push rdi
00007cc2f47d7f6d  push rsi
00007cc2f47d7f6e  push r8
00007cc2f47d7f70  push r9
00007cc2f47d7f72  push r10
00007cc2f47d7f74  push r11
00007cc2f47d7f76  sub rsp, 0xF0
00007cc2f47d7f7d  vmovaps [rsp], xmm0
00007cc2f47d7f82  vmovaps [rsp+0x10], xmm2
00007cc2f47d7f88  vmovaps [rsp+0x20], xmm3
00007cc2f47d7f8e  vmovaps [rsp+0x30], xmm4
00007cc2f47d7f94  vmovaps [rsp+0x40], xmm5
00007cc2f47d7f9a  vmovaps [rsp+0x50], xmm6
00007cc2f47d7fa0  vmovaps [rsp+0x60], xmm7
00007cc2f47d7fa6  vmovaps [rsp+0x70], xmm8
00007cc2f47d7fac  vmovaps [rsp+0x80], xmm9
00007cc2f47d7fb5  vmovaps [rsp+0x90], xmm10
00007cc2f47d7fbe  vmovaps [rsp+0xA0], xmm11
00007cc2f47d7fc7  vmovaps [rsp+0xB0], xmm12
00007cc2f47d7fd0  vmovaps [rsp+0xC0], xmm13
00007cc2f47d7fd9  vmovaps [rsp+0xD0], xmm14
00007cc2f47d7fe2  vmovaps [rsp+0xE0], xmm15
00007cc2f47d7feb  sub rsp, 0x30
00007cc2f47d7fef  movaps [rsp], xmm1
00007cc2f47d7ff3  movaps [rsp+0x10], xmm14
00007cc2f47d7ff9  movaps [rsp+0x20], xmm11
00007cc2f47d7fff  lea rdi, [rsp]
00007cc2f47d8003  mov esi, 0x00
00007cc2f47d8008  mov rax, 0x5990E710A530
00007cc2f47d8012  call rax
00007cc2f47d8014  movaps xmm1, [rsp]
00007cc2f47d8018  add rsp, 0x30
00007cc2f47d801c  vmovaps xmm0, [rsp]
00007cc2f47d8021  vmovaps xmm2, [rsp+0x10]
00007cc2f47d8027  vmovaps xmm3, [rsp+0x20]
00007cc2f47d802d  vmovaps xmm4, [rsp+0x30]
00007cc2f47d8033  vmovaps xmm5, [rsp+0x40]
00007cc2f47d8039  vmovaps xmm6, [rsp+0x50]
00007cc2f47d803f  vmovaps xmm7, [rsp+0x60]
00007cc2f47d8045  vmovaps xmm8, [rsp+0x70]
00007cc2f47d804b  vmovaps xmm9, [rsp+0x80]
00007cc2f47d8054  vmovaps xmm10, [rsp+0x90]
00007cc2f47d805d  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d8066  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d806f  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d8078  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d8081  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d808a  add rsp, 0xF0
00007cc2f47d8091  pop r11
00007cc2f47d8093  pop r10
00007cc2f47d8095  pop r9
00007cc2f47d8097  pop r8
00007cc2f47d8099  pop rsi
00007cc2f47d809a  pop rdi
00007cc2f47d809b  pop rdx
00007cc2f47d809c  pop rcx
00007cc2f47d809d  pop rax
00007cc2f47d809e  add rsp, 0x08
00007cc2f47d80a2  jmp 0x00007CC2F47D345F
00007cc2f47d80a7  call 0x00007CC2F46E45A0
00007cc2f47d80ac  jmp 0x00007CC2F47D346D
00007cc2f47d80b1  call 0x00007CC2F4609D70
00007cc2f47d80b6  jmp 0x00007CC2F47D3477
00007cc2f47d80bb  sub rsp, 0x08
00007cc2f47d80bf  push rax
00007cc2f47d80c0  push rcx
00007cc2f47d80c1  push rdx
00007cc2f47d80c2  push rdi
00007cc2f47d80c3  push rsi
00007cc2f47d80c4  push r8
00007cc2f47d80c6  push r9
00007cc2f47d80c8  push r10
00007cc2f47d80ca  push r11
00007cc2f47d80cc  sub rsp, 0xF0
00007cc2f47d80d3  vmovaps [rsp], xmm0
00007cc2f47d80d8  vmovaps [rsp+0x10], xmm1
00007cc2f47d80de  vmovaps [rsp+0x20], xmm2
00007cc2f47d80e4  vmovaps [rsp+0x30], xmm3
00007cc2f47d80ea  vmovaps [rsp+0x40], xmm4
00007cc2f47d80f0  vmovaps [rsp+0x50], xmm5
00007cc2f47d80f6  vmovaps [rsp+0x60], xmm6
00007cc2f47d80fc  vmovaps [rsp+0x70], xmm8
00007cc2f47d8102  vmovaps [rsp+0x80], xmm9
00007cc2f47d810b  vmovaps [rsp+0x90], xmm10
00007cc2f47d8114  vmovaps [rsp+0xA0], xmm11
00007cc2f47d811d  vmovaps [rsp+0xB0], xmm12
00007cc2f47d8126  vmovaps [rsp+0xC0], xmm13
00007cc2f47d812f  vmovaps [rsp+0xD0], xmm14
00007cc2f47d8138  vmovaps [rsp+0xE0], xmm15
00007cc2f47d8141  sub rsp, 0x30
00007cc2f47d8145  movaps [rsp], xmm7
00007cc2f47d8149  movaps [rsp+0x10], xmm13
00007cc2f47d814f  movaps [rsp+0x20], xmm10
00007cc2f47d8155  lea rdi, [rsp]
00007cc2f47d8159  mov esi, 0x00
00007cc2f47d815e  mov rax, 0x5990E710A530
00007cc2f47d8168  call rax
00007cc2f47d816a  movaps xmm7, [rsp]
00007cc2f47d816e  add rsp, 0x30
00007cc2f47d8172  vmovaps xmm0, [rsp]
00007cc2f47d8177  vmovaps xmm1, [rsp+0x10]
00007cc2f47d817d  vmovaps xmm2, [rsp+0x20]
00007cc2f47d8183  vmovaps xmm3, [rsp+0x30]
00007cc2f47d8189  vmovaps xmm4, [rsp+0x40]
00007cc2f47d818f  vmovaps xmm5, [rsp+0x50]
00007cc2f47d8195  vmovaps xmm6, [rsp+0x60]
00007cc2f47d819b  vmovaps xmm8, [rsp+0x70]
00007cc2f47d81a1  vmovaps xmm9, [rsp+0x80]
00007cc2f47d81aa  vmovaps xmm10, [rsp+0x90]
00007cc2f47d81b3  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d81bc  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d81c5  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d81ce  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d81d7  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d81e0  add rsp, 0xF0
00007cc2f47d81e7  pop r11
00007cc2f47d81e9  pop r10
00007cc2f47d81eb  pop r9
00007cc2f47d81ed  pop r8
00007cc2f47d81ef  pop rsi
00007cc2f47d81f0  pop rdi
00007cc2f47d81f1  pop rdx
00007cc2f47d81f2  pop rcx
00007cc2f47d81f3  pop rax
00007cc2f47d81f4  add rsp, 0x08
00007cc2f47d81f8  jmp 0x00007CC2F47D3498
00007cc2f47d81fd  sub rsp, 0x08
00007cc2f47d8201  push rax
00007cc2f47d8202  push rcx
00007cc2f47d8203  push rdx
00007cc2f47d8204  push rdi
00007cc2f47d8205  push rsi
00007cc2f47d8206  push r8
00007cc2f47d8208  push r9
00007cc2f47d820a  push r10
00007cc2f47d820c  push r11
00007cc2f47d820e  sub rsp, 0xF0
00007cc2f47d8215  vmovaps [rsp], xmm0
00007cc2f47d821a  vmovaps [rsp+0x10], xmm1
00007cc2f47d8220  vmovaps [rsp+0x20], xmm2
00007cc2f47d8226  vmovaps [rsp+0x30], xmm3
00007cc2f47d822c  vmovaps [rsp+0x40], xmm4
00007cc2f47d8232  vmovaps [rsp+0x50], xmm5
00007cc2f47d8238  vmovaps [rsp+0x60], xmm6
00007cc2f47d823e  vmovaps [rsp+0x70], xmm7
00007cc2f47d8244  vmovaps [rsp+0x80], xmm8
00007cc2f47d824d  vmovaps [rsp+0x90], xmm9
00007cc2f47d8256  vmovaps [rsp+0xA0], xmm11
00007cc2f47d825f  vmovaps [rsp+0xB0], xmm12
00007cc2f47d8268  vmovaps [rsp+0xC0], xmm13
00007cc2f47d8271  vmovaps [rsp+0xD0], xmm14
00007cc2f47d827a  vmovaps [rsp+0xE0], xmm15
00007cc2f47d8283  sub rsp, 0x30
00007cc2f47d8287  movaps [rsp], xmm10
00007cc2f47d828c  movaps [rsp+0x10], xmm11
00007cc2f47d8292  movaps [rsp+0x20], xmm13
00007cc2f47d8298  lea rdi, [rsp]
00007cc2f47d829c  mov esi, 0x00
00007cc2f47d82a1  mov rax, 0x5990E710A530
00007cc2f47d82ab  call rax
00007cc2f47d82ad  movaps xmm10, [rsp]
00007cc2f47d82b2  add rsp, 0x30
00007cc2f47d82b6  vmovaps xmm0, [rsp]
00007cc2f47d82bb  vmovaps xmm1, [rsp+0x10]
00007cc2f47d82c1  vmovaps xmm2, [rsp+0x20]
00007cc2f47d82c7  vmovaps xmm3, [rsp+0x30]
00007cc2f47d82cd  vmovaps xmm4, [rsp+0x40]
00007cc2f47d82d3  vmovaps xmm5, [rsp+0x50]
00007cc2f47d82d9  vmovaps xmm6, [rsp+0x60]
00007cc2f47d82df  vmovaps xmm7, [rsp+0x70]
00007cc2f47d82e5  vmovaps xmm8, [rsp+0x80]
00007cc2f47d82ee  vmovaps xmm9, [rsp+0x90]
00007cc2f47d82f7  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d8300  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d8309  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d8312  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d831b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d8324  add rsp, 0xF0
00007cc2f47d832b  pop r11
00007cc2f47d832d  pop r10
00007cc2f47d832f  pop r9
00007cc2f47d8331  pop r8
00007cc2f47d8333  pop rsi
00007cc2f47d8334  pop rdi
00007cc2f47d8335  pop rdx
00007cc2f47d8336  pop rcx
00007cc2f47d8337  pop rax
00007cc2f47d8338  add rsp, 0x08
00007cc2f47d833c  jmp 0x00007CC2F47D34C6
00007cc2f47d8341  sub rsp, 0x08
00007cc2f47d8345  push rax
00007cc2f47d8346  push rcx
00007cc2f47d8347  push rdx
00007cc2f47d8348  push rdi
00007cc2f47d8349  push rsi
00007cc2f47d834a  push r8
00007cc2f47d834c  push r9
00007cc2f47d834e  push r10
00007cc2f47d8350  push r11
00007cc2f47d8352  sub rsp, 0xF0
00007cc2f47d8359  vmovaps [rsp], xmm0
00007cc2f47d835e  vmovaps [rsp+0x10], xmm1
00007cc2f47d8364  vmovaps [rsp+0x20], xmm2
00007cc2f47d836a  vmovaps [rsp+0x30], xmm3
00007cc2f47d8370  vmovaps [rsp+0x40], xmm4
00007cc2f47d8376  vmovaps [rsp+0x50], xmm5
00007cc2f47d837c  vmovaps [rsp+0x60], xmm6
00007cc2f47d8382  vmovaps [rsp+0x70], xmm7
00007cc2f47d8388  vmovaps [rsp+0x80], xmm8
00007cc2f47d8391  vmovaps [rsp+0x90], xmm9
00007cc2f47d839a  vmovaps [rsp+0xA0], xmm10
00007cc2f47d83a3  vmovaps [rsp+0xB0], xmm12
00007cc2f47d83ac  vmovaps [rsp+0xC0], xmm13
00007cc2f47d83b5  vmovaps [rsp+0xD0], xmm14
00007cc2f47d83be  vmovaps [rsp+0xE0], xmm15
00007cc2f47d83c7  sub rsp, 0x30
00007cc2f47d83cb  movaps [rsp], xmm11
00007cc2f47d83d0  movaps [rsp+0x10], xmm14
00007cc2f47d83d6  movaps [rsp+0x20], xmm13
00007cc2f47d83dc  lea rdi, [rsp]
00007cc2f47d83e0  mov esi, 0x00
00007cc2f47d83e5  mov rax, 0x5990E710A530
00007cc2f47d83ef  call rax
00007cc2f47d83f1  movaps xmm11, [rsp]
00007cc2f47d83f6  add rsp, 0x30
00007cc2f47d83fa  vmovaps xmm0, [rsp]
00007cc2f47d83ff  vmovaps xmm1, [rsp+0x10]
00007cc2f47d8405  vmovaps xmm2, [rsp+0x20]
00007cc2f47d840b  vmovaps xmm3, [rsp+0x30]
00007cc2f47d8411  vmovaps xmm4, [rsp+0x40]
00007cc2f47d8417  vmovaps xmm5, [rsp+0x50]
00007cc2f47d841d  vmovaps xmm6, [rsp+0x60]
00007cc2f47d8423  vmovaps xmm7, [rsp+0x70]
00007cc2f47d8429  vmovaps xmm8, [rsp+0x80]
00007cc2f47d8432  vmovaps xmm9, [rsp+0x90]
00007cc2f47d843b  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d8444  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d844d  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d8456  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d845f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d8468  add rsp, 0xF0
00007cc2f47d846f  pop r11
00007cc2f47d8471  pop r10
00007cc2f47d8473  pop r9
00007cc2f47d8475  pop r8
00007cc2f47d8477  pop rsi
00007cc2f47d8478  pop rdi
00007cc2f47d8479  pop rdx
00007cc2f47d847a  pop rcx
00007cc2f47d847b  pop rax
00007cc2f47d847c  add rsp, 0x08
00007cc2f47d8480  jmp 0x00007CC2F47D34F4
00007cc2f47d8485  sub rsp, 0x08
00007cc2f47d8489  push rax
00007cc2f47d848a  push rcx
00007cc2f47d848b  push rdx
00007cc2f47d848c  push rdi
00007cc2f47d848d  push rsi
00007cc2f47d848e  push r8
00007cc2f47d8490  push r9
00007cc2f47d8492  push r10
00007cc2f47d8494  push r11
00007cc2f47d8496  sub rsp, 0xF0
00007cc2f47d849d  vmovaps [rsp], xmm0
00007cc2f47d84a2  vmovaps [rsp+0x10], xmm1
00007cc2f47d84a8  vmovaps [rsp+0x20], xmm2
00007cc2f47d84ae  vmovaps [rsp+0x30], xmm3
00007cc2f47d84b4  vmovaps [rsp+0x40], xmm4
00007cc2f47d84ba  vmovaps [rsp+0x50], xmm5
00007cc2f47d84c0  vmovaps [rsp+0x60], xmm6
00007cc2f47d84c6  vmovaps [rsp+0x70], xmm7
00007cc2f47d84cc  vmovaps [rsp+0x80], xmm8
00007cc2f47d84d5  vmovaps [rsp+0x90], xmm9
00007cc2f47d84de  vmovaps [rsp+0xA0], xmm10
00007cc2f47d84e7  vmovaps [rsp+0xB0], xmm11
00007cc2f47d84f0  vmovaps [rsp+0xC0], xmm12
00007cc2f47d84f9  vmovaps [rsp+0xD0], xmm13
00007cc2f47d8502  vmovaps [rsp+0xE0], xmm15
00007cc2f47d850b  sub rsp, 0x30
00007cc2f47d850f  movaps [rsp], xmm14
00007cc2f47d8514  movaps [rsp+0x10], xmm12
00007cc2f47d851a  movaps [rsp+0x20], xmm9
00007cc2f47d8520  lea rdi, [rsp]
00007cc2f47d8524  mov esi, 0x00
00007cc2f47d8529  mov rax, 0x5990E710A530
00007cc2f47d8533  call rax
00007cc2f47d8535  movaps xmm14, [rsp]
00007cc2f47d853a  add rsp, 0x30
00007cc2f47d853e  vmovaps xmm0, [rsp]
00007cc2f47d8543  vmovaps xmm1, [rsp+0x10]
00007cc2f47d8549  vmovaps xmm2, [rsp+0x20]
00007cc2f47d854f  vmovaps xmm3, [rsp+0x30]
00007cc2f47d8555  vmovaps xmm4, [rsp+0x40]
00007cc2f47d855b  vmovaps xmm5, [rsp+0x50]
00007cc2f47d8561  vmovaps xmm6, [rsp+0x60]
00007cc2f47d8567  vmovaps xmm7, [rsp+0x70]
00007cc2f47d856d  vmovaps xmm8, [rsp+0x80]
00007cc2f47d8576  vmovaps xmm9, [rsp+0x90]
00007cc2f47d857f  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d8588  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d8591  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d859a  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d85a3  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d85ac  add rsp, 0xF0
00007cc2f47d85b3  pop r11
00007cc2f47d85b5  pop r10
00007cc2f47d85b7  pop r9
00007cc2f47d85b9  pop r8
00007cc2f47d85bb  pop rsi
00007cc2f47d85bc  pop rdi
00007cc2f47d85bd  pop rdx
00007cc2f47d85be  pop rcx
00007cc2f47d85bf  pop rax
00007cc2f47d85c0  add rsp, 0x08
00007cc2f47d85c4  jmp 0x00007CC2F47D350F
00007cc2f47d85c9  sub rsp, 0x08
00007cc2f47d85cd  push rax
00007cc2f47d85ce  push rcx
00007cc2f47d85cf  push rdx
00007cc2f47d85d0  push rdi
00007cc2f47d85d1  push rsi
00007cc2f47d85d2  push r8
00007cc2f47d85d4  push r9
00007cc2f47d85d6  push r10
00007cc2f47d85d8  push r11
00007cc2f47d85da  sub rsp, 0xF0
00007cc2f47d85e1  vmovaps [rsp], xmm0
00007cc2f47d85e6  vmovaps [rsp+0x10], xmm1
00007cc2f47d85ec  vmovaps [rsp+0x20], xmm2
00007cc2f47d85f2  vmovaps [rsp+0x30], xmm3
00007cc2f47d85f8  vmovaps [rsp+0x40], xmm4
00007cc2f47d85fe  vmovaps [rsp+0x50], xmm5
00007cc2f47d8604  vmovaps [rsp+0x60], xmm6
00007cc2f47d860a  vmovaps [rsp+0x70], xmm7
00007cc2f47d8610  vmovaps [rsp+0x80], xmm8
00007cc2f47d8619  vmovaps [rsp+0x90], xmm9
00007cc2f47d8622  vmovaps [rsp+0xA0], xmm10
00007cc2f47d862b  vmovaps [rsp+0xB0], xmm11
00007cc2f47d8634  vmovaps [rsp+0xC0], xmm12
00007cc2f47d863d  vmovaps [rsp+0xD0], xmm14
00007cc2f47d8646  vmovaps [rsp+0xE0], xmm15
00007cc2f47d864f  sub rsp, 0x30
00007cc2f47d8653  movaps [rsp], xmm13
00007cc2f47d8658  movaps [rsp+0x10], xmm8
00007cc2f47d865e  movaps [rsp+0x20], xmm15
00007cc2f47d8664  lea rdi, [rsp]
00007cc2f47d8668  mov esi, 0x00
00007cc2f47d866d  mov rax, 0x5990E710A530
00007cc2f47d8677  call rax
00007cc2f47d8679  movaps xmm13, [rsp]
00007cc2f47d867e  add rsp, 0x30
00007cc2f47d8682  vmovaps xmm0, [rsp]
00007cc2f47d8687  vmovaps xmm1, [rsp+0x10]
00007cc2f47d868d  vmovaps xmm2, [rsp+0x20]
00007cc2f47d8693  vmovaps xmm3, [rsp+0x30]
00007cc2f47d8699  vmovaps xmm4, [rsp+0x40]
00007cc2f47d869f  vmovaps xmm5, [rsp+0x50]
00007cc2f47d86a5  vmovaps xmm6, [rsp+0x60]
00007cc2f47d86ab  vmovaps xmm7, [rsp+0x70]
00007cc2f47d86b1  vmovaps xmm8, [rsp+0x80]
00007cc2f47d86ba  vmovaps xmm9, [rsp+0x90]
00007cc2f47d86c3  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d86cc  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d86d5  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d86de  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d86e7  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d86f0  add rsp, 0xF0
00007cc2f47d86f7  pop r11
00007cc2f47d86f9  pop r10
00007cc2f47d86fb  pop r9
00007cc2f47d86fd  pop r8
00007cc2f47d86ff  pop rsi
00007cc2f47d8700  pop rdi
00007cc2f47d8701  pop rdx
00007cc2f47d8702  pop rcx
00007cc2f47d8703  pop rax
00007cc2f47d8704  add rsp, 0x08
00007cc2f47d8708  jmp 0x00007CC2F47D3532
00007cc2f47d870d  sub rsp, 0x08
00007cc2f47d8711  push rax
00007cc2f47d8712  push rcx
00007cc2f47d8713  push rdx
00007cc2f47d8714  push rdi
00007cc2f47d8715  push rsi
00007cc2f47d8716  push r8
00007cc2f47d8718  push r9
00007cc2f47d871a  push r10
00007cc2f47d871c  push r11
00007cc2f47d871e  sub rsp, 0xF0
00007cc2f47d8725  vmovaps [rsp], xmm0
00007cc2f47d872a  vmovaps [rsp+0x10], xmm1
00007cc2f47d8730  vmovaps [rsp+0x20], xmm2
00007cc2f47d8736  vmovaps [rsp+0x30], xmm3
00007cc2f47d873c  vmovaps [rsp+0x40], xmm4
00007cc2f47d8742  vmovaps [rsp+0x50], xmm5
00007cc2f47d8748  vmovaps [rsp+0x60], xmm6
00007cc2f47d874e  vmovaps [rsp+0x70], xmm7
00007cc2f47d8754  vmovaps [rsp+0x80], xmm8
00007cc2f47d875d  vmovaps [rsp+0x90], xmm9
00007cc2f47d8766  vmovaps [rsp+0xA0], xmm10
00007cc2f47d876f  vmovaps [rsp+0xB0], xmm11
00007cc2f47d8778  vmovaps [rsp+0xC0], xmm12
00007cc2f47d8781  vmovaps [rsp+0xD0], xmm13
00007cc2f47d878a  vmovaps [rsp+0xE0], xmm14
00007cc2f47d8793  sub rsp, 0x30
00007cc2f47d8797  movaps [rsp], xmm15
00007cc2f47d879c  movaps [rsp+0x10], xmm1
00007cc2f47d87a1  movaps [rsp+0x20], xmm10
00007cc2f47d87a7  lea rdi, [rsp]
00007cc2f47d87ab  mov esi, 0x00
00007cc2f47d87b0  mov rax, 0x5990E710A530
00007cc2f47d87ba  call rax
00007cc2f47d87bc  movaps xmm15, [rsp]
00007cc2f47d87c1  add rsp, 0x30
00007cc2f47d87c5  vmovaps xmm0, [rsp]
00007cc2f47d87ca  vmovaps xmm1, [rsp+0x10]
00007cc2f47d87d0  vmovaps xmm2, [rsp+0x20]
00007cc2f47d87d6  vmovaps xmm3, [rsp+0x30]
00007cc2f47d87dc  vmovaps xmm4, [rsp+0x40]
00007cc2f47d87e2  vmovaps xmm5, [rsp+0x50]
00007cc2f47d87e8  vmovaps xmm6, [rsp+0x60]
00007cc2f47d87ee  vmovaps xmm7, [rsp+0x70]
00007cc2f47d87f4  vmovaps xmm8, [rsp+0x80]
00007cc2f47d87fd  vmovaps xmm9, [rsp+0x90]
00007cc2f47d8806  vmovaps xmm10, [rsp+0xA0]
00007cc2f47d880f  vmovaps xmm11, [rsp+0xB0]
00007cc2f47d8818  vmovaps xmm12, [rsp+0xC0]
00007cc2f47d8821  vmovaps xmm13, [rsp+0xD0]
00007cc2f47d882a  vmovaps xmm14, [rsp+0xE0]
00007cc2f47d8833  add rsp, 0xF0
00007cc2f47d883a  pop r11
00007cc2f47d883c  pop r10
00007cc2f47d883e  pop r9
00007cc2f47d8840  pop r8
00007cc2f47d8842  pop rsi
00007cc2f47d8843  pop rdi
00007cc2f47d8844  pop rdx
00007cc2f47d8845  pop rcx
00007cc2f47d8846  pop rax
00007cc2f47d8847  add rsp, 0x08
00007cc2f47d884b  jmp 0x00007CC2F47D3555
00007cc2f47d8850  sub rsp, 0x08
00007cc2f47d8854  push rax
00007cc2f47d8855  push rcx
00007cc2f47d8856  push rdx
00007cc2f47d8857  push rdi
00007cc2f47d8858  push rsi
00007cc2f47d8859  push r8
00007cc2f47d885b  push r9
00007cc2f47d885d  push r10
00007cc2f47d885f  push r11
00007cc2f47d8861  sub rsp, 0xF0
00007cc2f47d8868  vmovaps [rsp], xmm0
00007cc2f47d886d  vmovaps [rsp+0x10], xmm2
00007cc2f47d8873  vmovaps [rsp+0x20], xmm3
00007cc2f47d8879  vmovaps [rsp+0x30], xmm4
00007cc2f47d887f  vmovaps [rsp+0x40], xmm5
00007cc2f47d8885  vmovaps [rsp+0x50], xmm6
00007cc2f47d888b  vmovaps [rsp+0x60], xmm7
00007cc2f47d8891  vmovaps [rsp+0x70], xmm8
00007cc2f47d8897  vmovaps [rsp+0x80], xmm9
00007cc2f47d88a0  vmovaps [rsp+0x90], xmm10
00007cc2f47d88a9  vmovaps [rsp+0xA0], xmm11
00007cc2f47d88b2  vmovaps [rsp+0xB0], xmm12
00007cc2f47d88bb  vmovaps [rsp+0xC0], xmm13
00007cc2f47d88c4  vmovaps [rsp+0xD0], xmm14
00007cc2f47d88cd  vmovaps [rsp+0xE0], xmm15
00007cc2f47d88d6  sub rsp, 0x30
00007cc2f47d88da  movaps [rsp], xmm1
00007cc2f47d88de  movaps [rsp+0x10], xmm7
00007cc2f47d88e3  movaps [rsp+0x20], xmm11
00007cc2f47d88e9  lea rdi, [rsp]
00007cc2f47d88ed  mov esi, 0x00
00007cc2f47d88f2  mov rax, 0x5990E710A530
00007cc2f47d88fc  call rax
00007cc2f47d88fe  movaps xmm1, [rsp]
00007cc2f47d8902  add rsp, 0x30
00007cc2f47d8906  vmovaps xmm0, [rsp]
00007cc2f47d890b  vmovaps xmm2, [rsp+0x10]
00007cc2f47d8911  vmovaps xmm3, [rsp+0x20]
00007cc2f47d8917  vmovaps xmm4, [rsp+0x30]
00007cc2f47d891d  vmovaps xmm5, [rsp+0x40]
00007cc2f47d8923  vmovaps xmm6, [rsp+0x50]
00007cc2f47d8929  vmovaps xmm7, [rsp+0x60]
00007cc2f47d892f  vmovaps xmm8, [rsp+0x70]
00007cc2f47d8935  vmovaps xmm9, [rsp+0x80]
00007cc2f47d893e  vmovaps xmm10, [rsp+0x90]
00007cc2f47d8947  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d8950  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d8959  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d8962  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d896b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d8974  add rsp, 0xF0
00007cc2f47d897b  pop r11
00007cc2f47d897d  pop r10
00007cc2f47d897f  pop r9
00007cc2f47d8981  pop r8
00007cc2f47d8983  pop rsi
00007cc2f47d8984  pop rdi
00007cc2f47d8985  pop rdx
00007cc2f47d8986  pop rcx
00007cc2f47d8987  pop rax
00007cc2f47d8988  add rsp, 0x08
00007cc2f47d898c  jmp 0x00007CC2F47D3576
00007cc2f47d8991  call 0x00007CC2F460D600
00007cc2f47d8996  jmp 0x00007CC2F47D3589
00007cc2f47d899b  call 0x00007CC2F460C380
00007cc2f47d89a0  jmp 0x00007CC2F47D3594
00007cc2f47d89a5  call 0x00007CC2F460E880
00007cc2f47d89aa  jmp 0x00007CC2F47D359F
00007cc2f47d89af  call 0x00007CC2F45FF540
00007cc2f47d89b4  jmp 0x00007CC2F47D35AA
00007cc2f47d89b9  int3
00007cc2f47d89ba  nop [rax+rax*1], ax
00007cc2f47d89c0  mov rax, [r15+0x40]
00007cc2f47d89c4  mov r14, [r15+0x58]
00007cc2f47d89c8  lea r12, [rax+r14*1]
00007cc2f47d89cc  movaps xmm1, [r15+0x1D0]
00007cc2f47d89d4  vmovaps [rsp+0x10], xmm1
00007cc2f47d89da  vmovaps xmm15, [rsp+0x10]
00007cc2f47d89e0  por xmm1, xmm15
00007cc2f47d89e5  movaps xmm14, [r15+0x1A0]
00007cc2f47d89ed  vmovaps [rsp+0x10], xmm14
00007cc2f47d89f3  vmovaps xmm13, [rsp+0x10]
00007cc2f47d89f9  por xmm14, xmm13
00007cc2f47d89fe  lea rax, [r12+0x30]
00007cc2f47d8a03  mov r11, [r13+rax*1]
00007cc2f47d8a08  lea rax, [r12+0x38]
00007cc2f47d8a0d  mov r10, [r13+rax*1]
00007cc2f47d8a12  movq xmm13, r11
00007cc2f47d8a17  movq xmm12, r10
00007cc2f47d8a1c  movq xmm13, xmm13
00007cc2f47d8a21  vmovaps [rsp+0x10], xmm13
00007cc2f47d8a27  movq xmm13, xmm13
00007cc2f47d8a2c  movaps [r15+0x130], xmm13
00007cc2f47d8a34  movq xmm12, xmm12
00007cc2f47d8a39  vmovaps [rsp+0x20], xmm12
00007cc2f47d8a3f  movq xmm12, xmm12
00007cc2f47d8a44  movaps [r15+0x280], xmm12
00007cc2f47d8a4c  movaps xmm13, [r15+0x270]
00007cc2f47d8a54  vmovaps [rsp+0x30], xmm13
00007cc2f47d8a5a  vmovaps xmm12, [rsp+0x30]
00007cc2f47d8a60  por xmm13, xmm12
00007cc2f47d8a65  lea rax, [r12+0x20]
00007cc2f47d8a6a  mov r11, [r13+rax*1]
00007cc2f47d8a6f  lea rax, [r12+0x28]
00007cc2f47d8a74  mov r10, [r13+rax*1]
00007cc2f47d8a79  movq xmm12, r11
00007cc2f47d8a7e  movq xmm11, r10
00007cc2f47d8a83  movq xmm12, xmm12
00007cc2f47d8a88  vmovaps [rsp+0x30], xmm12
00007cc2f47d8a8e  movq xmm12, xmm12
00007cc2f47d8a93  movaps [r15+0x150], xmm12
00007cc2f47d8a9b  movq xmm11, xmm11
00007cc2f47d8aa0  vmovaps [rsp+0x40], xmm11
00007cc2f47d8aa6  movq xmm11, xmm11
00007cc2f47d8aab  movaps [r15+0x140], xmm11
00007cc2f47d8ab3  lea rax, [r12+0x10]
00007cc2f47d8ab8  mov r11, [r13+rax*1]
00007cc2f47d8abd  lea rax, [r12+0x18]
00007cc2f47d8ac2  mov r10, [r13+rax*1]
00007cc2f47d8ac7  movq xmm12, r11
00007cc2f47d8acc  movq xmm11, r10
00007cc2f47d8ad1  movq xmm12, xmm12
00007cc2f47d8ad6  vmovaps [rsp+0x50], xmm12
00007cc2f47d8adc  movq xmm12, xmm12
00007cc2f47d8ae1  movaps [r15+0x170], xmm12
00007cc2f47d8ae9  movq xmm11, xmm11
00007cc2f47d8aee  vmovaps [rsp+0x60], xmm11
00007cc2f47d8af4  movq xmm11, xmm11
00007cc2f47d8af9  movaps [r15+0x160], xmm11
00007cc2f47d8b01  mov rax, [r13+r12*1]
00007cc2f47d8b06  vmovq xmm12, rax
00007cc2f47d8b0b  vpbroadcastq xmm12, xmm12
00007cc2f47d8b10  lea rax, [r12+0x08]
00007cc2f47d8b15  mov r12, [r13+rax*1]
00007cc2f47d8b1a  movq xmm11, r12
00007cc2f47d8b1f  movaps [r15+0x230], xmm11
00007cc2f47d8b27  mov rax, [r15+0xF8]
00007cc2f47d8b2e  lea r12, [rax+0x50]
00007cc2f47d8b32  movups xmm11, [r13+r12*1]
00007cc2f47d8b38  lea r12, [rax+0x60]
00007cc2f47d8b3c  movups xmm10, [r13+r12*1]
00007cc2f47d8b42  lea r12, [rax+0x30]
00007cc2f47d8b46  movups xmm9, [r13+r12*1]
00007cc2f47d8b4c  mov r12, [r15+0x50]
00007cc2f47d8b50  lea r11, [r12+r14*1]
00007cc2f47d8b54  mov [r15+0x60], r11
00007cc2f47d8b58  lea r12, [r14+0x40]
00007cc2f47d8b5c  mov [r15+0x58], r12
00007cc2f47d8b60  movaps xmm8, xmm12
00007cc2f47d8b64  mulpd xmm8, xmm15
00007cc2f47d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007cc2f47d8b6f  ptest xmm7, xmm7
00007cc2f47d8b74  jnz 0x00007CC2F47D9997
00007cc2f47d8b7a  movq xmm15, qword ptr [r15+0x230]
00007cc2f47d8b83  vmovaps [rsp+0x70], xmm15
00007cc2f47d8b89  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d8b8f  movaps xmm7, xmm9
00007cc2f47d8b93  mulpd xmm7, xmm15
00007cc2f47d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2f47d8b9d  ptest xmm6, xmm6
00007cc2f47d8ba2  jnz 0x00007CC2F47D9ADB
00007cc2f47d8ba8  vxorps xmm15, xmm15, xmm15
00007cc2f47d8bad  vpbroadcastq xmm15, xmm15
00007cc2f47d8bb2  movaps xmm9, xmm12
00007cc2f47d8bb6  mulpd xmm9, xmm10
00007cc2f47d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007cc2f47d8bc1  ptest xmm6, xmm6
00007cc2f47d8bc6  jnz 0x00007CC2F47D9C1D
00007cc2f47d8bcc  movaps xmm10, xmm12
00007cc2f47d8bd0  mulpd xmm10, xmm11
00007cc2f47d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007cc2f47d8bdb  ptest xmm6, xmm6
00007cc2f47d8be0  jnz 0x00007CC2F47D9D61
00007cc2f47d8be6  movaps xmm11, [r15+0x1F0]
00007cc2f47d8bee  movaps xmm6, xmm12
00007cc2f47d8bf2  mulpd xmm6, xmm11
00007cc2f47d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007cc2f47d8bfc  ptest xmm5, xmm5
00007cc2f47d8c01  jnz 0x00007CC2F47D9EA5
00007cc2f47d8c07  movaps xmm12, [r15+0x2A0]
00007cc2f47d8c0f  vmovaps [rsp+0x80], xmm12
00007cc2f47d8c18  vmovaps xmm11, [rsp+0x80]
00007cc2f47d8c21  por xmm12, xmm11
00007cc2f47d8c26  movaps xmm11, [r15+0x250]
00007cc2f47d8c2e  vmovaps [rsp+0x80], xmm11
00007cc2f47d8c37  vmovaps xmm5, [rsp+0x80]
00007cc2f47d8c40  por xmm11, xmm5
00007cc2f47d8c45  vmovaps xmm4, [rsp+0x70]
00007cc2f47d8c4b  vpermilpd xmm4, xmm4, 0x00
00007cc2f47d8c51  movaps xmm3, xmm5
00007cc2f47d8c54  mulpd xmm3, xmm4
00007cc2f47d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007cc2f47d8c5d  ptest xmm2, xmm2
00007cc2f47d8c62  jnz 0x00007CC2F47D9FE7
00007cc2f47d8c68  mov [rsp+0x80], rax
00007cc2f47d8c70  xor eax, eax
00007cc2f47d8c72  mov r14d, 0x200
00007cc2f47d8c78  cmp r12, r14
00007cc2f47d8c7b  cmc
00007cc2f47d8c7c  lahf
00007cc2f47d8c7d  seto al
00007cc2f47d8c80  mov [r15+0x108], eax
00007cc2f47d8c87  movaps xmm5, xmm8
00007cc2f47d8c8b  addpd xmm5, xmm15
00007cc2f47d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007cc2f47d8c95  ptest xmm4, xmm4
00007cc2f47d8c9a  jnz 0x00007CC2F47DA127
00007cc2f47d8ca0  movaps xmm8, [r15+0x1B0]
00007cc2f47d8ca8  movaps xmm4, xmm9
00007cc2f47d8cac  addpd xmm4, xmm8
00007cc2f47d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007cc2f47d8cb6  ptest xmm2, xmm2
00007cc2f47d8cbb  jnz 0x00007CC2F47DA269
00007cc2f47d8cc1  movaps xmm9, xmm10
00007cc2f47d8cc5  addpd xmm9, xmm8
00007cc2f47d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007cc2f47d8cd0  ptest xmm2, xmm2
00007cc2f47d8cd5  jnz 0x00007CC2F47DA3AB
00007cc2f47d8cdb  movaps xmm10, [r15+0x2F0]
00007cc2f47d8ce3  vmovaps [rsp+0x90], xmm10
00007cc2f47d8cec  vmovaps xmm8, [rsp+0x90]
00007cc2f47d8cf5  por xmm10, xmm8
00007cc2f47d8cfa  movaps xmm8, [r15+0x2E0]
00007cc2f47d8d02  vmovaps [rsp+0x90], xmm8
00007cc2f47d8d0b  vmovaps xmm2, [rsp+0x90]
00007cc2f47d8d14  por xmm8, xmm2
00007cc2f47d8d19  movaps xmm2, [r15+0x2D0]
00007cc2f47d8d21  vmovaps [rsp+0x90], xmm2
00007cc2f47d8d2a  vmovaps [rsp+0xA0], xmm1
00007cc2f47d8d33  vmovaps xmm1, [rsp+0x90]
00007cc2f47d8d3c  por xmm2, xmm1
00007cc2f47d8d40  movaps xmm1, [r15+0x200]
00007cc2f47d8d48  vmovaps [rsp+0x90], xmm1
00007cc2f47d8d51  vmovaps [rsp+0xB0], xmm15
00007cc2f47d8d5a  vmovaps xmm15, [rsp+0x90]
00007cc2f47d8d63  por xmm1, xmm15
00007cc2f47d8d68  movaps xmm15, [r15+0x1C0]
00007cc2f47d8d70  vmovaps [rsp+0x90], xmm15
00007cc2f47d8d79  vmovaps [rsp+0xC0], xmm1
00007cc2f47d8d82  vmovaps xmm1, [rsp+0x90]
00007cc2f47d8d8b  por xmm15, xmm1
00007cc2f47d8d90  movaps xmm1, [r15+0x190]
00007cc2f47d8d98  vmovaps [rsp+0x90], xmm1
00007cc2f47d8da1  vmovaps [rsp+0xD0], xmm15
00007cc2f47d8daa  vmovaps xmm15, [rsp+0x90]
00007cc2f47d8db3  por xmm1, xmm15
00007cc2f47d8db8  movaps xmm15, [r15+0x300]
00007cc2f47d8dc0  vmovaps [rsp+0x90], xmm15
00007cc2f47d8dc9  vmovaps [rsp+0xE0], xmm1
00007cc2f47d8dd2  vmovaps xmm1, [rsp+0x90]
00007cc2f47d8ddb  por xmm15, xmm1
00007cc2f47d8de0  mov rax, [rsp+0x80]
00007cc2f47d8de8  lea r14, [rax+0xA0]
00007cc2f47d8def  movups xmm1, [r13+r14*1]
00007cc2f47d8df5  lea r14, [rax+0xB0]
00007cc2f47d8dfc  vmovaps [rsp+0x80], xmm1
00007cc2f47d8e05  movups xmm1, [r13+r14*1]
00007cc2f47d8e0b  vmovaps [rsp+0x90], xmm1
00007cc2f47d8e14  vmovaps [rsp+0xF0], xmm15
00007cc2f47d8e1d  vmovaps xmm15, [rsp+0xB0]
00007cc2f47d8e26  vmovaps [rsp+0xB0], xmm14
00007cc2f47d8e2f  movaps xmm1, xmm6
00007cc2f47d8e32  addpd xmm1, xmm15
00007cc2f47d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007cc2f47d8e3c  ptest xmm14, xmm14
00007cc2f47d8e42  jnz 0x00007CC2F47DA503
00007cc2f47d8e48  lea r14, [rax+0xF0]
00007cc2f47d8e4f  movups xmm15, [r13+r14*1]
00007cc2f47d8e55  movaps xmm14, xmm4
00007cc2f47d8e59  addpd xmm14, xmm3
00007cc2f47d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007cc2f47d8e64  ptest xmm6, xmm6
00007cc2f47d8e69  jnz 0x00007CC2F47DA64E
00007cc2f47d8e6f  movaps xmm6, xmm9
00007cc2f47d8e73  addpd xmm6, xmm7
00007cc2f47d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007cc2f47d8e7c  ptest xmm4, xmm4
00007cc2f47d8e81  jnz 0x00007CC2F47DA790
00007cc2f47d8e87  vmovaps xmm9, [rsp+0x70]
00007cc2f47d8e8d  vpermilpd xmm9, xmm9, 0x00
00007cc2f47d8e93  vmovaps xmm4, [rsp+0x90]
00007cc2f47d8e9c  movaps xmm7, xmm4
00007cc2f47d8e9f  mulpd xmm7, xmm9
00007cc2f47d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007cc2f47d8ea9  ptest xmm3, xmm3
00007cc2f47d8eae  jnz 0x00007CC2F47DA8D1
00007cc2f47d8eb4  vmovaps xmm9, [rsp+0x50]
00007cc2f47d8eba  vpermilpd xmm9, xmm9, 0x00
00007cc2f47d8ec0  movaps xmm4, xmm15
00007cc2f47d8ec4  mulpd xmm4, xmm9
00007cc2f47d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007cc2f47d8ece  ptest xmm3, xmm3
00007cc2f47d8ed3  jnz 0x00007CC2F47DAA12
00007cc2f47d8ed9  lea r14, [rax+0xE0]
00007cc2f47d8ee0  movups xmm15, [r13+r14*1]
00007cc2f47d8ee6  vmovaps xmm9, [rsp+0x70]
00007cc2f47d8eec  vpermilpd xmm9, xmm9, 0x00
00007cc2f47d8ef2  vmovaps [rsp+0x70], xmm1
00007cc2f47d8ef8  vmovaps xmm1, [rsp+0x80]
00007cc2f47d8f01  vmovaps [rsp+0x80], xmm15
00007cc2f47d8f0a  movaps xmm3, xmm1
00007cc2f47d8f0d  mulpd xmm3, xmm9
00007cc2f47d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007cc2f47d8f17  ptest xmm15, xmm15
00007cc2f47d8f1d  jnz 0x00007CC2F47DAB5E
00007cc2f47d8f23  vmovaps xmm1, [rsp+0xF0]
00007cc2f47d8f2c  vmovaps xmm15, [rsp+0xF0]
00007cc2f47d8f35  por xmm1, xmm15
00007cc2f47d8f3a  movaps [r15+0x300], xmm1
00007cc2f47d8f42  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d8f4b  vmovaps xmm9, [rsp+0xE0]
00007cc2f47d8f54  por xmm15, xmm9
00007cc2f47d8f59  movaps [r15+0x190], xmm15
00007cc2f47d8f61  vmovaps xmm9, [rsp+0x50]
00007cc2f47d8f67  vpermilpd xmm9, xmm9, 0x00
00007cc2f47d8f6d  vmovaps [rsp+0x90], xmm1
00007cc2f47d8f76  vmovaps [rsp+0xE0], xmm15
00007cc2f47d8f7f  vmovaps xmm15, [rsp+0x80]
00007cc2f47d8f88  vmovaps [rsp+0x80], xmm14
00007cc2f47d8f91  movaps xmm1, xmm15
00007cc2f47d8f95  mulpd xmm1, xmm9
00007cc2f47d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007cc2f47d8f9f  ptest xmm14, xmm14
00007cc2f47d8fa5  jnz 0x00007CC2F47DAC9F
00007cc2f47d8fab  lea r14, [rax+0x90]
00007cc2f47d8fb2  movups xmm15, [r13+r14*1]
00007cc2f47d8fb8  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d8fc1  vmovaps xmm9, [rsp+0xD0]
00007cc2f47d8fca  por xmm14, xmm9
00007cc2f47d8fcf  movaps [r15+0x1C0], xmm14
00007cc2f47d8fd7  vmovaps xmm9, [rsp+0xC0]
00007cc2f47d8fe0  vmovaps [rsp+0xD0], xmm1
00007cc2f47d8fe9  vmovaps xmm1, [rsp+0xC0]
00007cc2f47d8ff2  por xmm9, xmm1
00007cc2f47d8ff7  movaps [r15+0x200], xmm9
00007cc2f47d8fff  vmovaps [rsp+0xC0], xmm2
00007cc2f47d9008  vmovaps xmm1, [rsp+0xC0]
00007cc2f47d9011  por xmm2, xmm1
00007cc2f47d9015  movaps [r15+0x2D0], xmm2
00007cc2f47d901d  vmovaps [rsp+0xC0], xmm8
00007cc2f47d9026  vmovaps xmm1, [rsp+0xC0]
00007cc2f47d902f  por xmm8, xmm1
00007cc2f47d9034  movaps [r15+0x2E0], xmm8
00007cc2f47d903c  vmovaps [rsp+0xC0], xmm15
00007cc2f47d9045  movaps xmm1, xmm5
00007cc2f47d9048  addpd xmm1, xmm7
00007cc2f47d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007cc2f47d9051  ptest xmm15, xmm15
00007cc2f47d9057  jnz 0x00007CC2F47DADEB
00007cc2f47d905d  vmovaps xmm15, [rsp+0x50]
00007cc2f47d9063  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d9069  vmovaps xmm5, [rsp+0xC0]
00007cc2f47d9072  vmovaps [rsp+0xC0], xmm1
00007cc2f47d907b  movaps xmm7, xmm5
00007cc2f47d907e  mulpd xmm7, xmm15
00007cc2f47d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007cc2f47d9088  ptest xmm1, xmm1
00007cc2f47d908d  jnz 0x00007CC2F47DAF2B
00007cc2f47d9093  lea r14, [rax+0x80]
00007cc2f47d909a  movups xmm1, [r13+r14*1]
00007cc2f47d90a0  vmovaps xmm5, [rsp+0x70]
00007cc2f47d90a6  vmovaps [rsp+0x70], xmm1
00007cc2f47d90ac  movaps xmm15, xmm5
00007cc2f47d90b0  addpd xmm15, xmm3
00007cc2f47d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007cc2f47d90bb  ptest xmm1, xmm1
00007cc2f47d90c0  jnz 0x00007CC2F47DB076
00007cc2f47d90c6  vmovaps xmm5, [rsp+0x80]
00007cc2f47d90cf  movaps xmm1, xmm5
00007cc2f47d90d2  addpd xmm1, xmm4
00007cc2f47d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007cc2f47d90db  ptest xmm3, xmm3
00007cc2f47d90e0  jnz 0x00007CC2F47DB1B8
00007cc2f47d90e6  vmovaps [rsp+0x80], xmm10
00007cc2f47d90ef  vmovaps xmm5, [rsp+0x80]
00007cc2f47d90f8  por xmm10, xmm5
00007cc2f47d90fd  movaps [r15+0x2F0], xmm10
00007cc2f47d9105  vmovaps xmm5, [rsp+0x50]
00007cc2f47d910b  vpermilpd xmm5, xmm5, 0x00
00007cc2f47d9111  vmovaps xmm3, [rsp+0x70]
00007cc2f47d9117  vmovaps [rsp+0x50], xmm1
00007cc2f47d911d  movaps xmm4, xmm3
00007cc2f47d9120  mulpd xmm4, xmm5
00007cc2f47d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007cc2f47d9129  ptest xmm1, xmm1
00007cc2f47d912e  jnz 0x00007CC2F47DB2F8
00007cc2f47d9134  lea r14, [rax+0xD0]
00007cc2f47d913b  movups xmm1, [r13+r14*1]
00007cc2f47d9141  vmovaps xmm3, [rsp+0xD0]
00007cc2f47d914a  vmovaps [rsp+0x70], xmm1
00007cc2f47d9150  movaps xmm5, xmm6
00007cc2f47d9153  addpd xmm5, xmm3
00007cc2f47d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007cc2f47d915c  ptest xmm1, xmm1
00007cc2f47d9161  jnz 0x00007CC2F47DB442
00007cc2f47d9167  vmovaps xmm1, [rsp+0x60]
00007cc2f47d916d  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d9173  movaps xmm6, xmm9
00007cc2f47d9177  mulpd xmm6, xmm1
00007cc2f47d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007cc2f47d9180  ptest xmm3, xmm3
00007cc2f47d9185  jnz 0x00007CC2F47DB582
00007cc2f47d918b  movaps [r15+0x260], xmm6
00007cc2f47d9193  vxorps xmm1, xmm1, xmm1
00007cc2f47d9197  vpbroadcastq xmm1, xmm1
00007cc2f47d919c  movaps [r15+0x1B0], xmm1
00007cc2f47d91a4  vmovaps xmm1, [rsp+0x60]
00007cc2f47d91aa  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d91b0  vmovaps xmm3, [rsp+0x70]
00007cc2f47d91b6  vmovaps [rsp+0x70], xmm15
00007cc2f47d91bc  movaps xmm9, xmm3
00007cc2f47d91c0  mulpd xmm9, xmm1
00007cc2f47d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007cc2f47d91cb  ptest xmm15, xmm15
00007cc2f47d91d1  jnz 0x00007CC2F47DB6C3
00007cc2f47d91d7  lea r14, [rax+0xC0]
00007cc2f47d91de  movups xmm1, [r13+r14*1]
00007cc2f47d91e4  vmovaps xmm3, [rsp+0xC0]
00007cc2f47d91ed  vmovaps [rsp+0x80], xmm1
00007cc2f47d91f6  movaps xmm15, xmm3
00007cc2f47d91fa  addpd xmm15, xmm7
00007cc2f47d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007cc2f47d9205  ptest xmm1, xmm1
00007cc2f47d920a  jnz 0x00007CC2F47DB80F
00007cc2f47d9210  vmovaps [rsp+0xC0], xmm13
00007cc2f47d9219  vmovaps xmm1, [rsp+0xC0]
00007cc2f47d9222  por xmm13, xmm1
00007cc2f47d9227  movaps [r15+0x270], xmm13
00007cc2f47d922f  vmovaps xmm1, [rsp+0xB0]
00007cc2f47d9238  vmovaps xmm7, [rsp+0xB0]
00007cc2f47d9241  por xmm1, xmm7
00007cc2f47d9245  movaps [r15+0x1A0], xmm1
00007cc2f47d924d  vmovaps xmm1, [rsp+0x60]
00007cc2f47d9253  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d9259  vmovaps [rsp+0xB0], xmm1
00007cc2f47d9262  vmovaps xmm1, [rsp+0x80]
00007cc2f47d926b  vmovaps [rsp+0x80], xmm15
00007cc2f47d9274  vmovaps xmm15, [rsp+0xB0]
00007cc2f47d927d  vmovaps [rsp+0xB0], xmm14
00007cc2f47d9286  movaps xmm3, xmm1
00007cc2f47d9289  mulpd xmm3, xmm15
00007cc2f47d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007cc2f47d9293  ptest xmm14, xmm14
00007cc2f47d9299  jnz 0x00007CC2F47DB951
00007cc2f47d929f  lea r14, [rax+0x20]
00007cc2f47d92a3  movups xmm1, [r13+r14*1]
00007cc2f47d92a9  movaps [r15+0x110], xmm1
00007cc2f47d92b1  vmovaps xmm14, [rsp+0x70]
00007cc2f47d92b7  vmovaps [rsp+0x70], xmm1
00007cc2f47d92bd  movaps xmm15, xmm14
00007cc2f47d92c1  addpd xmm15, xmm4
00007cc2f47d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007cc2f47d92cc  ptest xmm1, xmm1
00007cc2f47d92d1  jnz 0x00007CC2F47DBA9C
00007cc2f47d92d7  vmovaps xmm1, [rsp+0x60]
00007cc2f47d92dd  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d92e3  movaps xmm14, xmm2
00007cc2f47d92e7  mulpd xmm14, xmm1
00007cc2f47d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007cc2f47d92f2  ptest xmm4, xmm4
00007cc2f47d92f7  jnz 0x00007CC2F47DBBDF
00007cc2f47d92fd  vmovaps xmm4, [rsp+0x50]
00007cc2f47d9303  movaps xmm1, xmm4
00007cc2f47d9306  addpd xmm1, xmm9
00007cc2f47d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007cc2f47d9310  ptest xmm2, xmm2
00007cc2f47d9315  jnz 0x00007CC2F47DBD21
00007cc2f47d931b  vmovaps xmm9, [rsp+0x30]
00007cc2f47d9321  vpermilpd xmm9, xmm9, 0x00
00007cc2f47d9327  vmovaps xmm2, [rsp+0x70]
00007cc2f47d932d  vmovaps [rsp+0x50], xmm1
00007cc2f47d9333  movaps xmm4, xmm2
00007cc2f47d9336  mulpd xmm4, xmm9
00007cc2f47d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007cc2f47d9340  ptest xmm1, xmm1
00007cc2f47d9345  jnz 0x00007CC2F47DBE62
00007cc2f47d934b  vmovaps xmm1, [rsp+0x30]
00007cc2f47d9351  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d9357  vmovaps xmm2, [rsp+0x90]
00007cc2f47d9360  vmovaps [rsp+0x60], xmm15
00007cc2f47d9366  movaps xmm9, xmm2
00007cc2f47d936a  mulpd xmm9, xmm1
00007cc2f47d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007cc2f47d9375  ptest xmm15, xmm15
00007cc2f47d937b  jnz 0x00007CC2F47DBFA3
00007cc2f47d9381  vmovaps xmm15, [rsp+0x80]
00007cc2f47d938a  movaps xmm1, xmm15
00007cc2f47d938e  addpd xmm1, xmm6
00007cc2f47d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007cc2f47d9397  ptest xmm2, xmm2
00007cc2f47d939c  jnz 0x00007CC2F47DC0E5
00007cc2f47d93a2  movaps xmm15, xmm5
00007cc2f47d93a6  addpd xmm15, xmm3
00007cc2f47d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007cc2f47d93b1  ptest xmm6, xmm6
00007cc2f47d93b6  jnz 0x00007CC2F47DC226
00007cc2f47d93bc  vmovaps xmm6, [rsp+0x30]
00007cc2f47d93c2  vpermilpd xmm6, xmm6, 0x00
00007cc2f47d93c8  movaps xmm5, xmm8
00007cc2f47d93cc  mulpd xmm5, xmm6
00007cc2f47d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007cc2f47d93d5  ptest xmm3, xmm3
00007cc2f47d93da  jnz 0x00007CC2F47DC368
00007cc2f47d93e0  vmovaps xmm8, [rsp+0x30]
00007cc2f47d93e6  vpermilpd xmm8, xmm8, 0x00
00007cc2f47d93ec  movaps xmm6, xmm10
00007cc2f47d93f0  mulpd xmm6, xmm8
00007cc2f47d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007cc2f47d93fa  ptest xmm3, xmm3
00007cc2f47d93ff  jnz 0x00007CC2F47DC4A9
00007cc2f47d9405  vmovaps xmm8, [rsp+0x60]
00007cc2f47d940b  movaps xmm10, xmm8
00007cc2f47d940f  addpd xmm10, xmm14
00007cc2f47d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007cc2f47d941a  ptest xmm3, xmm3
00007cc2f47d941f  jnz 0x00007CC2F47DC5EB
00007cc2f47d9425  vmovaps xmm8, [rsp+0x50]
00007cc2f47d942b  movaps xmm14, xmm8
00007cc2f47d942f  addpd xmm14, xmm4
00007cc2f47d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007cc2f47d943a  ptest xmm3, xmm3
00007cc2f47d943f  jnz 0x00007CC2F47DC72F
00007cc2f47d9445  vmovaps xmm8, [rsp+0x40]
00007cc2f47d944b  vpermilpd xmm8, xmm8, 0x00
00007cc2f47d9451  movaps xmm4, xmm13
00007cc2f47d9455  mulpd xmm4, xmm8
00007cc2f47d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007cc2f47d945f  ptest xmm3, xmm3
00007cc2f47d9464  jnz 0x00007CC2F47DC872
00007cc2f47d946a  movaps xmm13, xmm15
00007cc2f47d946e  addpd xmm13, xmm9
00007cc2f47d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007cc2f47d9479  ptest xmm8, xmm8
00007cc2f47d947f  jnz 0x00007CC2F47DC9B4
00007cc2f47d9485  movaps xmm15, xmm1
00007cc2f47d9489  addpd xmm15, xmm5
00007cc2f47d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007cc2f47d9494  ptest xmm9, xmm9
00007cc2f47d949a  jnz 0x00007CC2F47DCAF8
00007cc2f47d94a0  vmovaps [rsp+0x30], xmm11
00007cc2f47d94a6  vmovaps xmm1, [rsp+0x30]
00007cc2f47d94ac  por xmm11, xmm1
00007cc2f47d94b1  movaps [r15+0x250], xmm11
00007cc2f47d94b9  vmovaps [rsp+0x30], xmm12
00007cc2f47d94bf  vmovaps xmm1, [rsp+0x30]
00007cc2f47d94c5  por xmm12, xmm1
00007cc2f47d94ca  movaps [r15+0x2A0], xmm12
00007cc2f47d94d2  vmovaps xmm1, [rsp+0xA0]
00007cc2f47d94db  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d94e4  por xmm1, xmm11
00007cc2f47d94e9  movaps [r15+0x1D0], xmm1
00007cc2f47d94f1  lea r14, [rax+0x40]
00007cc2f47d94f5  movups xmm1, [r13+r14*1]
00007cc2f47d94fb  movaps [r15+0x2C0], xmm1
00007cc2f47d9503  vmovaps xmm11, [rsp+0x40]
00007cc2f47d9509  vpermilpd xmm11, xmm11, 0x00
00007cc2f47d950f  vmovaps xmm8, [rsp+0xE0]
00007cc2f47d9518  movaps xmm9, xmm8
00007cc2f47d951c  mulpd xmm9, xmm11
00007cc2f47d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007cc2f47d9527  ptest xmm5, xmm5
00007cc2f47d952c  jnz 0x00007CC2F47DCC44
00007cc2f47d9532  movaps xmm11, xmm10
00007cc2f47d9536  addpd xmm11, xmm6
00007cc2f47d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007cc2f47d9541  ptest xmm8, xmm8
00007cc2f47d9547  jnz 0x00007CC2F47DCD88
00007cc2f47d954d  movaps xmm10, xmm14
00007cc2f47d9551  addpd xmm10, xmm4
00007cc2f47d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007cc2f47d955c  ptest xmm8, xmm8
00007cc2f47d9562  jnz 0x00007CC2F47DCECB
00007cc2f47d9568  vmovaps xmm14, [rsp+0x40]
00007cc2f47d956e  vpermilpd xmm14, xmm14, 0x00
00007cc2f47d9574  movaps xmm8, xmm1
00007cc2f47d9578  mulpd xmm8, xmm14
00007cc2f47d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007cc2f47d9583  ptest xmm6, xmm6
00007cc2f47d9588  jnz 0x00007CC2F47DD00E
00007cc2f47d958e  movaps xmm1, [r15+0x2B0]
00007cc2f47d9596  vmovaps xmm14, [rsp+0x40]
00007cc2f47d959c  vpermilpd xmm14, xmm14, 0x00
00007cc2f47d95a2  movaps xmm6, xmm1
00007cc2f47d95a5  mulpd xmm6, xmm14
00007cc2f47d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007cc2f47d95af  ptest xmm5, xmm5
00007cc2f47d95b4  jnz 0x00007CC2F47DD151
00007cc2f47d95ba  vmovaps xmm1, [rsp+0x10]
00007cc2f47d95c0  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d95c6  movaps xmm14, xmm12
00007cc2f47d95ca  mulpd xmm14, xmm1
00007cc2f47d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007cc2f47d95d5  ptest xmm5, xmm5
00007cc2f47d95da  jnz 0x00007CC2F47DD292
00007cc2f47d95e0  movaps xmm1, xmm13
00007cc2f47d95e4  addpd xmm1, xmm9
00007cc2f47d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007cc2f47d95ee  ptest xmm12, xmm12
00007cc2f47d95f4  jnz 0x00007CC2F47DD3D5
00007cc2f47d95fa  vmovaps xmm13, [rsp+0x10]
00007cc2f47d9600  vpermilpd xmm13, xmm13, 0x00
00007cc2f47d9606  movaps xmm12, xmm7
00007cc2f47d960a  mulpd xmm12, xmm13
00007cc2f47d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007cc2f47d9615  ptest xmm9, xmm9
00007cc2f47d961b  jnz 0x00007CC2F47DD517
00007cc2f47d9621  movaps xmm13, xmm15
00007cc2f47d9625  addpd xmm13, xmm8
00007cc2f47d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007cc2f47d9630  ptest xmm9, xmm9
00007cc2f47d9636  jnz 0x00007CC2F47DD65A
00007cc2f47d963c  movaps xmm15, [r15+0x290]
00007cc2f47d9644  vmovaps xmm9, [rsp+0x10]
00007cc2f47d964a  vpermilpd xmm9, xmm9, 0x00
00007cc2f47d9650  movaps xmm8, xmm15
00007cc2f47d9654  mulpd xmm8, xmm9
00007cc2f47d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007cc2f47d965f  ptest xmm7, xmm7
00007cc2f47d9664  jnz 0x00007CC2F47DD79E
00007cc2f47d966a  movaps xmm15, xmm11
00007cc2f47d966e  addpd xmm15, xmm6
00007cc2f47d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007cc2f47d9679  ptest xmm9, xmm9
00007cc2f47d967f  jnz 0x00007CC2F47DD8E2
00007cc2f47d9685  movaps xmm11, [r15+0x1E0]
00007cc2f47d968d  vmovaps xmm9, [rsp+0x10]
00007cc2f47d9693  vpermilpd xmm9, xmm9, 0x00
00007cc2f47d9699  movaps xmm7, xmm11
00007cc2f47d969d  mulpd xmm7, xmm9
00007cc2f47d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2f47d96a7  ptest xmm6, xmm6
00007cc2f47d96ac  jnz 0x00007CC2F47DDA25
00007cc2f47d96b2  movaps xmm11, xmm10
00007cc2f47d96b6  addpd xmm11, xmm14
00007cc2f47d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007cc2f47d96c1  ptest xmm9, xmm9
00007cc2f47d96c7  jnz 0x00007CC2F47DDB67
00007cc2f47d96cd  lea r14, [rax+0x70]
00007cc2f47d96d1  movups xmm14, [r13+r14*1]
00007cc2f47d96d7  movaps [r15+0x240], xmm14
00007cc2f47d96df  movaps xmm10, xmm1
00007cc2f47d96e3  addpd xmm10, xmm12
00007cc2f47d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007cc2f47d96ee  ptest xmm9, xmm9
00007cc2f47d96f4  jnz 0x00007CC2F47DDCB5
00007cc2f47d96fa  movaps [r15+0x170], xmm10
00007cc2f47d9702  vmovaps xmm1, [rsp+0x20]
00007cc2f47d9708  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d970e  movaps xmm12, xmm14
00007cc2f47d9712  mulpd xmm12, xmm1
00007cc2f47d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007cc2f47d971d  ptest xmm9, xmm9
00007cc2f47d9723  jnz 0x00007CC2F47DDDF8
00007cc2f47d9729  vmovaps xmm1, [rsp+0x20]
00007cc2f47d972f  vpermilpd xmm1, xmm1, 0x00
00007cc2f47d9735  vmovaps xmm9, [rsp+0xB0]
00007cc2f47d973e  movaps xmm14, xmm9
00007cc2f47d9742  mulpd xmm14, xmm1
00007cc2f47d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007cc2f47d974d  ptest xmm6, xmm6
00007cc2f47d9752  jnz 0x00007CC2F47DDF3B
00007cc2f47d9758  movaps [r15+0x180], xmm14
00007cc2f47d9760  movaps xmm1, xmm13
00007cc2f47d9764  addpd xmm1, xmm8
00007cc2f47d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007cc2f47d976e  ptest xmm9, xmm9
00007cc2f47d9774  jnz 0x00007CC2F47DE07E
00007cc2f47d977a  movaps [r15+0x210], xmm1
00007cc2f47d9782  movups xmm13, [r13+rax*1]
00007cc2f47d9788  lea r14, [rax+0x10]
00007cc2f47d978c  movups xmm9, [r13+r14*1]
00007cc2f47d9792  movaps [r15+0x230], xmm9
00007cc2f47d979a  movaps xmm8, xmm15
00007cc2f47d979e  addpd xmm8, xmm7
00007cc2f47d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007cc2f47d97a9  ptest xmm6, xmm6
00007cc2f47d97ae  jnz 0x00007CC2F47DE1D4
00007cc2f47d97b4  movaps [r15+0x130], xmm8
00007cc2f47d97bc  vmovaps xmm15, [rsp+0x20]
00007cc2f47d97c2  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d97c8  movaps xmm7, xmm9
00007cc2f47d97cc  mulpd xmm7, xmm15
00007cc2f47d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2f47d97d6  ptest xmm6, xmm6
00007cc2f47d97db  jnz 0x00007CC2F47DE317
00007cc2f47d97e1  movaps [r15+0x220], xmm7
00007cc2f47d97e9  vmovaps xmm15, [rsp+0x20]
00007cc2f47d97ef  vpermilpd xmm15, xmm15, 0x00
00007cc2f47d97f5  movaps xmm9, xmm13
00007cc2f47d97f9  mulpd xmm9, xmm15
00007cc2f47d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007cc2f47d9804  ptest xmm6, xmm6
00007cc2f47d9809  jnz 0x00007CC2F47DE459
00007cc2f47d980f  movaps xmm15, xmm11
00007cc2f47d9813  addpd xmm15, xmm12
00007cc2f47d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007cc2f47d981e  ptest xmm13, xmm13
00007cc2f47d9824  jnz 0x00007CC2F47DE59D
00007cc2f47d982a  movaps [r15+0x140], xmm15
00007cc2f47d9832  movaps xmm13, xmm10
00007cc2f47d9836  addpd xmm13, xmm14
00007cc2f47d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2f47d9841  ptest xmm12, xmm12
00007cc2f47d9847  jnz 0x00007CC2F47DE6E1
00007cc2f47d984d  movaps [r15+0x150], xmm13
00007cc2f47d9855  movaps xmm14, xmm1
00007cc2f47d9859  addpd xmm14, xmm7
00007cc2f47d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007cc2f47d9864  ptest xmm12, xmm12
00007cc2f47d986a  jnz 0x00007CC2F47DE825
00007cc2f47d9870  movaps [r15+0x160], xmm14
00007cc2f47d9878  movaps xmm1, xmm8
00007cc2f47d987c  addpd xmm1, xmm9
00007cc2f47d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007cc2f47d9886  ptest xmm12, xmm12
00007cc2f47d988c  jnz 0x00007CC2F47DE967
00007cc2f47d9892  movaps [r15+0x120], xmm1
00007cc2f47d989a  movups [r13+r11*1], xmm15
00007cc2f47d98a0  lea rax, [r11+0x10]
00007cc2f47d98a4  movups [r13+rax*1], xmm13
00007cc2f47d98aa  lea rax, [r11+0x20]
00007cc2f47d98ae  movups [r13+rax*1], xmm14
00007cc2f47d98b4  lea rax, [r11+0x30]
00007cc2f47d98b8  movups [r13+rax*1], xmm1
00007cc2f47d98be  mov eax, [r15+0x108]
00007cc2f47d98c5  sahf
00007cc2f47d98c6  jnz 0x00007CC2F47D98F8
00007cc2f47d98c8  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d98d0  jz 0x00007CC2F47DEAE0
00007cc2f47d98d6  nop [rax+rax*1], ax
00007cc2f47d98df  nop [rax+rax*1], eax
00007cc2f47d98e7  mov eax, 0x4106D0
00007cc2f47d98ec  mov [r15+0x100], rax
00007cc2f47d98f3  jmp 0x00007CC2F45FE110
00007cc2f47d98f8  cmp dword ptr [r15+0x318], 0x00
00007cc2f47d9900  jz 0x00007CC2F47D89C0
00007cc2f47d9906  nop [rax+rax*1], ax
00007cc2f47d990f  nop [rax+rax*1], eax
00007cc2f47d9917  mov eax, 0x410504
00007cc2f47d991c  mov [r15+0x100], rax
00007cc2f47d9923  jmp 0x00007CC2F45FE110
00007cc2f47d9928  int3
00007cc2f47d9929  call 0x00007CC2F460A4B0
00007cc2f47d992e  jmp 0x00007CC2F47D8A08
00007cc2f47d9933  call 0x00007CC2F4609240
00007cc2f47d9938  jmp 0x00007CC2F47D8A12
00007cc2f47d993d  call 0x00007CC2F460A4B0
00007cc2f47d9942  jmp 0x00007CC2F47D8A6F
00007cc2f47d9947  call 0x00007CC2F4609240
00007cc2f47d994c  jmp 0x00007CC2F47D8A79
00007cc2f47d9951  call 0x00007CC2F460A4B0
00007cc2f47d9956  jmp 0x00007CC2F47D8ABD
00007cc2f47d995b  call 0x00007CC2F4609240
00007cc2f47d9960  jmp 0x00007CC2F47D8AC7
00007cc2f47d9965  call 0x00007CC2F46B47C0
00007cc2f47d996a  jmp 0x00007CC2F47D8B06
00007cc2f47d996f  call 0x00007CC2F460B720
00007cc2f47d9974  jmp 0x00007CC2F47D8B1A
00007cc2f47d9979  call 0x00007CC2F46BFC30
00007cc2f47d997e  jmp 0x00007CC2F47D8B38
00007cc2f47d9983  call 0x00007CC2F46BE9C0
00007cc2f47d9988  jmp 0x00007CC2F47D8B42
00007cc2f47d998d  call 0x00007CC2F46BD750
00007cc2f47d9992  jmp 0x00007CC2F47D8B4C
00007cc2f47d9997  sub rsp, 0x08
00007cc2f47d999b  push rax
00007cc2f47d999c  push rcx
00007cc2f47d999d  push rdx
00007cc2f47d999e  push rdi
00007cc2f47d999f  push rsi
00007cc2f47d99a0  push r8
00007cc2f47d99a2  push r9
00007cc2f47d99a4  push r10
00007cc2f47d99a6  push r11
00007cc2f47d99a8  sub rsp, 0xF0
00007cc2f47d99af  vmovaps [rsp], xmm0
00007cc2f47d99b4  vmovaps [rsp+0x10], xmm1
00007cc2f47d99ba  vmovaps [rsp+0x20], xmm2
00007cc2f47d99c0  vmovaps [rsp+0x30], xmm3
00007cc2f47d99c6  vmovaps [rsp+0x40], xmm4
00007cc2f47d99cc  vmovaps [rsp+0x50], xmm5
00007cc2f47d99d2  vmovaps [rsp+0x60], xmm6
00007cc2f47d99d8  vmovaps [rsp+0x70], xmm7
00007cc2f47d99de  vmovaps [rsp+0x80], xmm9
00007cc2f47d99e7  vmovaps [rsp+0x90], xmm10
00007cc2f47d99f0  vmovaps [rsp+0xA0], xmm11
00007cc2f47d99f9  vmovaps [rsp+0xB0], xmm12
00007cc2f47d9a02  vmovaps [rsp+0xC0], xmm13
00007cc2f47d9a0b  vmovaps [rsp+0xD0], xmm14
00007cc2f47d9a14  vmovaps [rsp+0xE0], xmm15
00007cc2f47d9a1d  sub rsp, 0x30
00007cc2f47d9a21  movaps [rsp], xmm8
00007cc2f47d9a26  movaps [rsp+0x10], xmm12
00007cc2f47d9a2c  movaps [rsp+0x20], xmm15
00007cc2f47d9a32  lea rdi, [rsp]
00007cc2f47d9a36  mov esi, 0x00
00007cc2f47d9a3b  mov rax, 0x5990E710A530
00007cc2f47d9a45  call rax
00007cc2f47d9a47  movaps xmm8, [rsp]
00007cc2f47d9a4c  add rsp, 0x30
00007cc2f47d9a50  vmovaps xmm0, [rsp]
00007cc2f47d9a55  vmovaps xmm1, [rsp+0x10]
00007cc2f47d9a5b  vmovaps xmm2, [rsp+0x20]
00007cc2f47d9a61  vmovaps xmm3, [rsp+0x30]
00007cc2f47d9a67  vmovaps xmm4, [rsp+0x40]
00007cc2f47d9a6d  vmovaps xmm5, [rsp+0x50]
00007cc2f47d9a73  vmovaps xmm6, [rsp+0x60]
00007cc2f47d9a79  vmovaps xmm7, [rsp+0x70]
00007cc2f47d9a7f  vmovaps xmm9, [rsp+0x80]
00007cc2f47d9a88  vmovaps xmm10, [rsp+0x90]
00007cc2f47d9a91  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d9a9a  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d9aa3  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d9aac  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d9ab5  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d9abe  add rsp, 0xF0
00007cc2f47d9ac5  pop r11
00007cc2f47d9ac7  pop r10
00007cc2f47d9ac9  pop r9
00007cc2f47d9acb  pop r8
00007cc2f47d9acd  pop rsi
00007cc2f47d9ace  pop rdi
00007cc2f47d9acf  pop rdx
00007cc2f47d9ad0  pop rcx
00007cc2f47d9ad1  pop rax
00007cc2f47d9ad2  add rsp, 0x08
00007cc2f47d9ad6  jmp 0x00007CC2F47D8B7A
00007cc2f47d9adb  sub rsp, 0x08
00007cc2f47d9adf  push rax
00007cc2f47d9ae0  push rcx
00007cc2f47d9ae1  push rdx
00007cc2f47d9ae2  push rdi
00007cc2f47d9ae3  push rsi
00007cc2f47d9ae4  push r8
00007cc2f47d9ae6  push r9
00007cc2f47d9ae8  push r10
00007cc2f47d9aea  push r11
00007cc2f47d9aec  sub rsp, 0xF0
00007cc2f47d9af3  vmovaps [rsp], xmm0
00007cc2f47d9af8  vmovaps [rsp+0x10], xmm1
00007cc2f47d9afe  vmovaps [rsp+0x20], xmm2
00007cc2f47d9b04  vmovaps [rsp+0x30], xmm3
00007cc2f47d9b0a  vmovaps [rsp+0x40], xmm4
00007cc2f47d9b10  vmovaps [rsp+0x50], xmm5
00007cc2f47d9b16  vmovaps [rsp+0x60], xmm6
00007cc2f47d9b1c  vmovaps [rsp+0x70], xmm8
00007cc2f47d9b22  vmovaps [rsp+0x80], xmm9
00007cc2f47d9b2b  vmovaps [rsp+0x90], xmm10
00007cc2f47d9b34  vmovaps [rsp+0xA0], xmm11
00007cc2f47d9b3d  vmovaps [rsp+0xB0], xmm12
00007cc2f47d9b46  vmovaps [rsp+0xC0], xmm13
00007cc2f47d9b4f  vmovaps [rsp+0xD0], xmm14
00007cc2f47d9b58  vmovaps [rsp+0xE0], xmm15
00007cc2f47d9b61  sub rsp, 0x30
00007cc2f47d9b65  movaps [rsp], xmm7
00007cc2f47d9b69  movaps [rsp+0x10], xmm9
00007cc2f47d9b6f  movaps [rsp+0x20], xmm15
00007cc2f47d9b75  lea rdi, [rsp]
00007cc2f47d9b79  mov esi, 0x00
00007cc2f47d9b7e  mov rax, 0x5990E710A530
00007cc2f47d9b88  call rax
00007cc2f47d9b8a  movaps xmm7, [rsp]
00007cc2f47d9b8e  add rsp, 0x30
00007cc2f47d9b92  vmovaps xmm0, [rsp]
00007cc2f47d9b97  vmovaps xmm1, [rsp+0x10]
00007cc2f47d9b9d  vmovaps xmm2, [rsp+0x20]
00007cc2f47d9ba3  vmovaps xmm3, [rsp+0x30]
00007cc2f47d9ba9  vmovaps xmm4, [rsp+0x40]
00007cc2f47d9baf  vmovaps xmm5, [rsp+0x50]
00007cc2f47d9bb5  vmovaps xmm6, [rsp+0x60]
00007cc2f47d9bbb  vmovaps xmm8, [rsp+0x70]
00007cc2f47d9bc1  vmovaps xmm9, [rsp+0x80]
00007cc2f47d9bca  vmovaps xmm10, [rsp+0x90]
00007cc2f47d9bd3  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d9bdc  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d9be5  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d9bee  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d9bf7  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d9c00  add rsp, 0xF0
00007cc2f47d9c07  pop r11
00007cc2f47d9c09  pop r10
00007cc2f47d9c0b  pop r9
00007cc2f47d9c0d  pop r8
00007cc2f47d9c0f  pop rsi
00007cc2f47d9c10  pop rdi
00007cc2f47d9c11  pop rdx
00007cc2f47d9c12  pop rcx
00007cc2f47d9c13  pop rax
00007cc2f47d9c14  add rsp, 0x08
00007cc2f47d9c18  jmp 0x00007CC2F47D8BA8
00007cc2f47d9c1d  sub rsp, 0x08
00007cc2f47d9c21  push rax
00007cc2f47d9c22  push rcx
00007cc2f47d9c23  push rdx
00007cc2f47d9c24  push rdi
00007cc2f47d9c25  push rsi
00007cc2f47d9c26  push r8
00007cc2f47d9c28  push r9
00007cc2f47d9c2a  push r10
00007cc2f47d9c2c  push r11
00007cc2f47d9c2e  sub rsp, 0xF0
00007cc2f47d9c35  vmovaps [rsp], xmm0
00007cc2f47d9c3a  vmovaps [rsp+0x10], xmm1
00007cc2f47d9c40  vmovaps [rsp+0x20], xmm2
00007cc2f47d9c46  vmovaps [rsp+0x30], xmm3
00007cc2f47d9c4c  vmovaps [rsp+0x40], xmm4
00007cc2f47d9c52  vmovaps [rsp+0x50], xmm5
00007cc2f47d9c58  vmovaps [rsp+0x60], xmm6
00007cc2f47d9c5e  vmovaps [rsp+0x70], xmm7
00007cc2f47d9c64  vmovaps [rsp+0x80], xmm8
00007cc2f47d9c6d  vmovaps [rsp+0x90], xmm10
00007cc2f47d9c76  vmovaps [rsp+0xA0], xmm11
00007cc2f47d9c7f  vmovaps [rsp+0xB0], xmm12
00007cc2f47d9c88  vmovaps [rsp+0xC0], xmm13
00007cc2f47d9c91  vmovaps [rsp+0xD0], xmm14
00007cc2f47d9c9a  vmovaps [rsp+0xE0], xmm15
00007cc2f47d9ca3  sub rsp, 0x30
00007cc2f47d9ca7  movaps [rsp], xmm9
00007cc2f47d9cac  movaps [rsp+0x10], xmm12
00007cc2f47d9cb2  movaps [rsp+0x20], xmm10
00007cc2f47d9cb8  lea rdi, [rsp]
00007cc2f47d9cbc  mov esi, 0x00
00007cc2f47d9cc1  mov rax, 0x5990E710A530
00007cc2f47d9ccb  call rax
00007cc2f47d9ccd  movaps xmm9, [rsp]
00007cc2f47d9cd2  add rsp, 0x30
00007cc2f47d9cd6  vmovaps xmm0, [rsp]
00007cc2f47d9cdb  vmovaps xmm1, [rsp+0x10]
00007cc2f47d9ce1  vmovaps xmm2, [rsp+0x20]
00007cc2f47d9ce7  vmovaps xmm3, [rsp+0x30]
00007cc2f47d9ced  vmovaps xmm4, [rsp+0x40]
00007cc2f47d9cf3  vmovaps xmm5, [rsp+0x50]
00007cc2f47d9cf9  vmovaps xmm6, [rsp+0x60]
00007cc2f47d9cff  vmovaps xmm7, [rsp+0x70]
00007cc2f47d9d05  vmovaps xmm8, [rsp+0x80]
00007cc2f47d9d0e  vmovaps xmm10, [rsp+0x90]
00007cc2f47d9d17  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d9d20  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d9d29  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d9d32  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d9d3b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d9d44  add rsp, 0xF0
00007cc2f47d9d4b  pop r11
00007cc2f47d9d4d  pop r10
00007cc2f47d9d4f  pop r9
00007cc2f47d9d51  pop r8
00007cc2f47d9d53  pop rsi
00007cc2f47d9d54  pop rdi
00007cc2f47d9d55  pop rdx
00007cc2f47d9d56  pop rcx
00007cc2f47d9d57  pop rax
00007cc2f47d9d58  add rsp, 0x08
00007cc2f47d9d5c  jmp 0x00007CC2F47D8BCC
00007cc2f47d9d61  sub rsp, 0x08
00007cc2f47d9d65  push rax
00007cc2f47d9d66  push rcx
00007cc2f47d9d67  push rdx
00007cc2f47d9d68  push rdi
00007cc2f47d9d69  push rsi
00007cc2f47d9d6a  push r8
00007cc2f47d9d6c  push r9
00007cc2f47d9d6e  push r10
00007cc2f47d9d70  push r11
00007cc2f47d9d72  sub rsp, 0xF0
00007cc2f47d9d79  vmovaps [rsp], xmm0
00007cc2f47d9d7e  vmovaps [rsp+0x10], xmm1
00007cc2f47d9d84  vmovaps [rsp+0x20], xmm2
00007cc2f47d9d8a  vmovaps [rsp+0x30], xmm3
00007cc2f47d9d90  vmovaps [rsp+0x40], xmm4
00007cc2f47d9d96  vmovaps [rsp+0x50], xmm5
00007cc2f47d9d9c  vmovaps [rsp+0x60], xmm6
00007cc2f47d9da2  vmovaps [rsp+0x70], xmm7
00007cc2f47d9da8  vmovaps [rsp+0x80], xmm8
00007cc2f47d9db1  vmovaps [rsp+0x90], xmm9
00007cc2f47d9dba  vmovaps [rsp+0xA0], xmm11
00007cc2f47d9dc3  vmovaps [rsp+0xB0], xmm12
00007cc2f47d9dcc  vmovaps [rsp+0xC0], xmm13
00007cc2f47d9dd5  vmovaps [rsp+0xD0], xmm14
00007cc2f47d9dde  vmovaps [rsp+0xE0], xmm15
00007cc2f47d9de7  sub rsp, 0x30
00007cc2f47d9deb  movaps [rsp], xmm10
00007cc2f47d9df0  movaps [rsp+0x10], xmm12
00007cc2f47d9df6  movaps [rsp+0x20], xmm11
00007cc2f47d9dfc  lea rdi, [rsp]
00007cc2f47d9e00  mov esi, 0x00
00007cc2f47d9e05  mov rax, 0x5990E710A530
00007cc2f47d9e0f  call rax
00007cc2f47d9e11  movaps xmm10, [rsp]
00007cc2f47d9e16  add rsp, 0x30
00007cc2f47d9e1a  vmovaps xmm0, [rsp]
00007cc2f47d9e1f  vmovaps xmm1, [rsp+0x10]
00007cc2f47d9e25  vmovaps xmm2, [rsp+0x20]
00007cc2f47d9e2b  vmovaps xmm3, [rsp+0x30]
00007cc2f47d9e31  vmovaps xmm4, [rsp+0x40]
00007cc2f47d9e37  vmovaps xmm5, [rsp+0x50]
00007cc2f47d9e3d  vmovaps xmm6, [rsp+0x60]
00007cc2f47d9e43  vmovaps xmm7, [rsp+0x70]
00007cc2f47d9e49  vmovaps xmm8, [rsp+0x80]
00007cc2f47d9e52  vmovaps xmm9, [rsp+0x90]
00007cc2f47d9e5b  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d9e64  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d9e6d  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d9e76  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d9e7f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d9e88  add rsp, 0xF0
00007cc2f47d9e8f  pop r11
00007cc2f47d9e91  pop r10
00007cc2f47d9e93  pop r9
00007cc2f47d9e95  pop r8
00007cc2f47d9e97  pop rsi
00007cc2f47d9e98  pop rdi
00007cc2f47d9e99  pop rdx
00007cc2f47d9e9a  pop rcx
00007cc2f47d9e9b  pop rax
00007cc2f47d9e9c  add rsp, 0x08
00007cc2f47d9ea0  jmp 0x00007CC2F47D8BE6
00007cc2f47d9ea5  sub rsp, 0x08
00007cc2f47d9ea9  push rax
00007cc2f47d9eaa  push rcx
00007cc2f47d9eab  push rdx
00007cc2f47d9eac  push rdi
00007cc2f47d9ead  push rsi
00007cc2f47d9eae  push r8
00007cc2f47d9eb0  push r9
00007cc2f47d9eb2  push r10
00007cc2f47d9eb4  push r11
00007cc2f47d9eb6  sub rsp, 0xF0
00007cc2f47d9ebd  vmovaps [rsp], xmm0
00007cc2f47d9ec2  vmovaps [rsp+0x10], xmm1
00007cc2f47d9ec8  vmovaps [rsp+0x20], xmm2
00007cc2f47d9ece  vmovaps [rsp+0x30], xmm3
00007cc2f47d9ed4  vmovaps [rsp+0x40], xmm4
00007cc2f47d9eda  vmovaps [rsp+0x50], xmm5
00007cc2f47d9ee0  vmovaps [rsp+0x60], xmm7
00007cc2f47d9ee6  vmovaps [rsp+0x70], xmm8
00007cc2f47d9eec  vmovaps [rsp+0x80], xmm9
00007cc2f47d9ef5  vmovaps [rsp+0x90], xmm10
00007cc2f47d9efe  vmovaps [rsp+0xA0], xmm11
00007cc2f47d9f07  vmovaps [rsp+0xB0], xmm12
00007cc2f47d9f10  vmovaps [rsp+0xC0], xmm13
00007cc2f47d9f19  vmovaps [rsp+0xD0], xmm14
00007cc2f47d9f22  vmovaps [rsp+0xE0], xmm15
00007cc2f47d9f2b  sub rsp, 0x30
00007cc2f47d9f2f  movaps [rsp], xmm6
00007cc2f47d9f33  movaps [rsp+0x10], xmm12
00007cc2f47d9f39  movaps [rsp+0x20], xmm11
00007cc2f47d9f3f  lea rdi, [rsp]
00007cc2f47d9f43  mov esi, 0x00
00007cc2f47d9f48  mov rax, 0x5990E710A530
00007cc2f47d9f52  call rax
00007cc2f47d9f54  movaps xmm6, [rsp]
00007cc2f47d9f58  add rsp, 0x30
00007cc2f47d9f5c  vmovaps xmm0, [rsp]
00007cc2f47d9f61  vmovaps xmm1, [rsp+0x10]
00007cc2f47d9f67  vmovaps xmm2, [rsp+0x20]
00007cc2f47d9f6d  vmovaps xmm3, [rsp+0x30]
00007cc2f47d9f73  vmovaps xmm4, [rsp+0x40]
00007cc2f47d9f79  vmovaps xmm5, [rsp+0x50]
00007cc2f47d9f7f  vmovaps xmm7, [rsp+0x60]
00007cc2f47d9f85  vmovaps xmm8, [rsp+0x70]
00007cc2f47d9f8b  vmovaps xmm9, [rsp+0x80]
00007cc2f47d9f94  vmovaps xmm10, [rsp+0x90]
00007cc2f47d9f9d  vmovaps xmm11, [rsp+0xA0]
00007cc2f47d9fa6  vmovaps xmm12, [rsp+0xB0]
00007cc2f47d9faf  vmovaps xmm13, [rsp+0xC0]
00007cc2f47d9fb8  vmovaps xmm14, [rsp+0xD0]
00007cc2f47d9fc1  vmovaps xmm15, [rsp+0xE0]
00007cc2f47d9fca  add rsp, 0xF0
00007cc2f47d9fd1  pop r11
00007cc2f47d9fd3  pop r10
00007cc2f47d9fd5  pop r9
00007cc2f47d9fd7  pop r8
00007cc2f47d9fd9  pop rsi
00007cc2f47d9fda  pop rdi
00007cc2f47d9fdb  pop rdx
00007cc2f47d9fdc  pop rcx
00007cc2f47d9fdd  pop rax
00007cc2f47d9fde  add rsp, 0x08
00007cc2f47d9fe2  jmp 0x00007CC2F47D8C07
00007cc2f47d9fe7  sub rsp, 0x08
00007cc2f47d9feb  push rax
00007cc2f47d9fec  push rcx
00007cc2f47d9fed  push rdx
00007cc2f47d9fee  push rdi
00007cc2f47d9fef  push rsi
00007cc2f47d9ff0  push r8
00007cc2f47d9ff2  push r9
00007cc2f47d9ff4  push r10
00007cc2f47d9ff6  push r11
00007cc2f47d9ff8  sub rsp, 0xF0
00007cc2f47d9fff  vmovaps [rsp], xmm0
00007cc2f47da004  vmovaps [rsp+0x10], xmm1
00007cc2f47da00a  vmovaps [rsp+0x20], xmm2
00007cc2f47da010  vmovaps [rsp+0x30], xmm4
00007cc2f47da016  vmovaps [rsp+0x40], xmm5
00007cc2f47da01c  vmovaps [rsp+0x50], xmm6
00007cc2f47da022  vmovaps [rsp+0x60], xmm7
00007cc2f47da028  vmovaps [rsp+0x70], xmm8
00007cc2f47da02e  vmovaps [rsp+0x80], xmm9
00007cc2f47da037  vmovaps [rsp+0x90], xmm10
00007cc2f47da040  vmovaps [rsp+0xA0], xmm11
00007cc2f47da049  vmovaps [rsp+0xB0], xmm12
00007cc2f47da052  vmovaps [rsp+0xC0], xmm13
00007cc2f47da05b  vmovaps [rsp+0xD0], xmm14
00007cc2f47da064  vmovaps [rsp+0xE0], xmm15
00007cc2f47da06d  sub rsp, 0x30
00007cc2f47da071  movaps [rsp], xmm3
00007cc2f47da075  movaps [rsp+0x10], xmm5
00007cc2f47da07a  movaps [rsp+0x20], xmm4
00007cc2f47da07f  lea rdi, [rsp]
00007cc2f47da083  mov esi, 0x00
00007cc2f47da088  mov rax, 0x5990E710A530
00007cc2f47da092  call rax
00007cc2f47da094  movaps xmm3, [rsp]
00007cc2f47da098  add rsp, 0x30
00007cc2f47da09c  vmovaps xmm0, [rsp]
00007cc2f47da0a1  vmovaps xmm1, [rsp+0x10]
00007cc2f47da0a7  vmovaps xmm2, [rsp+0x20]
00007cc2f47da0ad  vmovaps xmm4, [rsp+0x30]
00007cc2f47da0b3  vmovaps xmm5, [rsp+0x40]
00007cc2f47da0b9  vmovaps xmm6, [rsp+0x50]
00007cc2f47da0bf  vmovaps xmm7, [rsp+0x60]
00007cc2f47da0c5  vmovaps xmm8, [rsp+0x70]
00007cc2f47da0cb  vmovaps xmm9, [rsp+0x80]
00007cc2f47da0d4  vmovaps xmm10, [rsp+0x90]
00007cc2f47da0dd  vmovaps xmm11, [rsp+0xA0]
00007cc2f47da0e6  vmovaps xmm12, [rsp+0xB0]
00007cc2f47da0ef  vmovaps xmm13, [rsp+0xC0]
00007cc2f47da0f8  vmovaps xmm14, [rsp+0xD0]
00007cc2f47da101  vmovaps xmm15, [rsp+0xE0]
00007cc2f47da10a  add rsp, 0xF0
00007cc2f47da111  pop r11
00007cc2f47da113  pop r10
00007cc2f47da115  pop r9
00007cc2f47da117  pop r8
00007cc2f47da119  pop rsi
00007cc2f47da11a  pop rdi
00007cc2f47da11b  pop rdx
00007cc2f47da11c  pop rcx
00007cc2f47da11d  pop rax
00007cc2f47da11e  add rsp, 0x08
00007cc2f47da122  jmp 0x00007CC2F47D8C68
00007cc2f47da127  sub rsp, 0x08
00007cc2f47da12b  push rax
00007cc2f47da12c  push rcx
00007cc2f47da12d  push rdx
00007cc2f47da12e  push rdi
00007cc2f47da12f  push rsi
00007cc2f47da130  push r8
00007cc2f47da132  push r9
00007cc2f47da134  push r10
00007cc2f47da136  push r11
00007cc2f47da138  sub rsp, 0xF0
00007cc2f47da13f  vmovaps [rsp], xmm0
00007cc2f47da144  vmovaps [rsp+0x10], xmm1
00007cc2f47da14a  vmovaps [rsp+0x20], xmm2
00007cc2f47da150  vmovaps [rsp+0x30], xmm3
00007cc2f47da156  vmovaps [rsp+0x40], xmm4
00007cc2f47da15c  vmovaps [rsp+0x50], xmm6
00007cc2f47da162  vmovaps [rsp+0x60], xmm7
00007cc2f47da168  vmovaps [rsp+0x70], xmm8
00007cc2f47da16e  vmovaps [rsp+0x80], xmm9
00007cc2f47da177  vmovaps [rsp+0x90], xmm10
00007cc2f47da180  vmovaps [rsp+0xA0], xmm11
00007cc2f47da189  vmovaps [rsp+0xB0], xmm12
00007cc2f47da192  vmovaps [rsp+0xC0], xmm13
00007cc2f47da19b  vmovaps [rsp+0xD0], xmm14
00007cc2f47da1a4  vmovaps [rsp+0xE0], xmm15
00007cc2f47da1ad  sub rsp, 0x30
00007cc2f47da1b1  movaps [rsp], xmm5
00007cc2f47da1b5  movaps [rsp+0x10], xmm8
00007cc2f47da1bb  movaps [rsp+0x20], xmm15
00007cc2f47da1c1  lea rdi, [rsp]
00007cc2f47da1c5  mov esi, 0x00
00007cc2f47da1ca  mov rax, 0x5990E710A530
00007cc2f47da1d4  call rax
00007cc2f47da1d6  movaps xmm5, [rsp]
00007cc2f47da1da  add rsp, 0x30
00007cc2f47da1de  vmovaps xmm0, [rsp]
00007cc2f47da1e3  vmovaps xmm1, [rsp+0x10]
00007cc2f47da1e9  vmovaps xmm2, [rsp+0x20]
00007cc2f47da1ef  vmovaps xmm3, [rsp+0x30]
00007cc2f47da1f5  vmovaps xmm4, [rsp+0x40]
00007cc2f47da1fb  vmovaps xmm6, [rsp+0x50]
00007cc2f47da201  vmovaps xmm7, [rsp+0x60]
00007cc2f47da207  vmovaps xmm8, [rsp+0x70]
00007cc2f47da20d  vmovaps xmm9, [rsp+0x80]
00007cc2f47da216  vmovaps xmm10, [rsp+0x90]
00007cc2f47da21f  vmovaps xmm11, [rsp+0xA0]
00007cc2f47da228  vmovaps xmm12, [rsp+0xB0]
00007cc2f47da231  vmovaps xmm13, [rsp+0xC0]
00007cc2f47da23a  vmovaps xmm14, [rsp+0xD0]
00007cc2f47da243  vmovaps xmm15, [rsp+0xE0]
00007cc2f47da24c  add rsp, 0xF0
00007cc2f47da253  pop r11
00007cc2f47da255  pop r10
00007cc2f47da257  pop r9
00007cc2f47da259  pop r8
00007cc2f47da25b  pop rsi
00007cc2f47da25c  pop rdi
00007cc2f47da25d  pop rdx
00007cc2f47da25e  pop rcx
00007cc2f47da25f  pop rax
00007cc2f47da260  add rsp, 0x08
00007cc2f47da264  jmp 0x00007CC2F47D8CA0
00007cc2f47da269  sub rsp, 0x08
00007cc2f47da26d  push rax
00007cc2f47da26e  push rcx
00007cc2f47da26f  push rdx
00007cc2f47da270  push rdi
00007cc2f47da271  push rsi
00007cc2f47da272  push r8
00007cc2f47da274  push r9
00007cc2f47da276  push r10
00007cc2f47da278  push r11
00007cc2f47da27a  sub rsp, 0xF0
00007cc2f47da281  vmovaps [rsp], xmm0
00007cc2f47da286  vmovaps [rsp+0x10], xmm1
00007cc2f47da28c  vmovaps [rsp+0x20], xmm2
00007cc2f47da292  vmovaps [rsp+0x30], xmm3
00007cc2f47da298  vmovaps [rsp+0x40], xmm5
00007cc2f47da29e  vmovaps [rsp+0x50], xmm6
00007cc2f47da2a4  vmovaps [rsp+0x60], xmm7
00007cc2f47da2aa  vmovaps [rsp+0x70], xmm8
00007cc2f47da2b0  vmovaps [rsp+0x80], xmm9
00007cc2f47da2b9  vmovaps [rsp+0x90], xmm10
00007cc2f47da2c2  vmovaps [rsp+0xA0], xmm11
00007cc2f47da2cb  vmovaps [rsp+0xB0], xmm12
00007cc2f47da2d4  vmovaps [rsp+0xC0], xmm13
00007cc2f47da2dd  vmovaps [rsp+0xD0], xmm14
00007cc2f47da2e6  vmovaps [rsp+0xE0], xmm15
00007cc2f47da2ef  sub rsp, 0x30
00007cc2f47da2f3  movaps [rsp], xmm4
00007cc2f47da2f7  movaps [rsp+0x10], xmm9
00007cc2f47da2fd  movaps [rsp+0x20], xmm8
00007cc2f47da303  lea rdi, [rsp]
00007cc2f47da307  mov esi, 0x00
00007cc2f47da30c  mov rax, 0x5990E710A530
00007cc2f47da316  call rax
00007cc2f47da318  movaps xmm4, [rsp]
00007cc2f47da31c  add rsp, 0x30
00007cc2f47da320  vmovaps xmm0, [rsp]
00007cc2f47da325  vmovaps xmm1, [rsp+0x10]
00007cc2f47da32b  vmovaps xmm2, [rsp+0x20]
00007cc2f47da331  vmovaps xmm3, [rsp+0x30]
00007cc2f47da337  vmovaps xmm5, [rsp+0x40]
00007cc2f47da33d  vmovaps xmm6, [rsp+0x50]
00007cc2f47da343  vmovaps xmm7, [rsp+0x60]
00007cc2f47da349  vmovaps xmm8, [rsp+0x70]
00007cc2f47da34f  vmovaps xmm9, [rsp+0x80]
00007cc2f47da358  vmovaps xmm10, [rsp+0x90]
00007cc2f47da361  vmovaps xmm11, [rsp+0xA0]
00007cc2f47da36a  vmovaps xmm12, [rsp+0xB0]
00007cc2f47da373  vmovaps xmm13, [rsp+0xC0]
00007cc2f47da37c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47da385  vmovaps xmm15, [rsp+0xE0]
00007cc2f47da38e  add rsp, 0xF0
00007cc2f47da395  pop r11
00007cc2f47da397  pop r10
00007cc2f47da399  pop r9
00007cc2f47da39b  pop r8
00007cc2f47da39d  pop rsi
00007cc2f47da39e  pop rdi
00007cc2f47da39f  pop rdx
00007cc2f47da3a0  pop rcx
00007cc2f47da3a1  pop rax
00007cc2f47da3a2  add rsp, 0x08
00007cc2f47da3a6  jmp 0x00007CC2F47D8CC1
00007cc2f47da3ab  sub rsp, 0x08
00007cc2f47da3af  push rax
00007cc2f47da3b0  push rcx
00007cc2f47da3b1  push rdx
00007cc2f47da3b2  push rdi
00007cc2f47da3b3  push rsi
00007cc2f47da3b4  push r8
00007cc2f47da3b6  push r9
00007cc2f47da3b8  push r10
00007cc2f47da3ba  push r11
00007cc2f47da3bc  sub rsp, 0xF0
00007cc2f47da3c3  vmovaps [rsp], xmm0
00007cc2f47da3c8  vmovaps [rsp+0x10], xmm1
00007cc2f47da3ce  vmovaps [rsp+0x20], xmm2
00007cc2f47da3d4  vmovaps [rsp+0x30], xmm3
00007cc2f47da3da  vmovaps [rsp+0x40], xmm4
00007cc2f47da3e0  vmovaps [rsp+0x50], xmm5
00007cc2f47da3e6  vmovaps [rsp+0x60], xmm6
00007cc2f47da3ec  vmovaps [rsp+0x70], xmm7
00007cc2f47da3f2  vmovaps [rsp+0x80], xmm8
00007cc2f47da3fb  vmovaps [rsp+0x90], xmm10
00007cc2f47da404  vmovaps [rsp+0xA0], xmm11
00007cc2f47da40d  vmovaps [rsp+0xB0], xmm12
00007cc2f47da416  vmovaps [rsp+0xC0], xmm13
00007cc2f47da41f  vmovaps [rsp+0xD0], xmm14
00007cc2f47da428  vmovaps [rsp+0xE0], xmm15
00007cc2f47da431  sub rsp, 0x30
00007cc2f47da435  movaps [rsp], xmm9
00007cc2f47da43a  movaps [rsp+0x10], xmm10
00007cc2f47da440  movaps [rsp+0x20], xmm8
00007cc2f47da446  lea rdi, [rsp]
00007cc2f47da44a  mov esi, 0x00
00007cc2f47da44f  mov rax, 0x5990E710A530
00007cc2f47da459  call rax
00007cc2f47da45b  movaps xmm9, [rsp]
00007cc2f47da460  add rsp, 0x30
00007cc2f47da464  vmovaps xmm0, [rsp]
00007cc2f47da469  vmovaps xmm1, [rsp+0x10]
00007cc2f47da46f  vmovaps xmm2, [rsp+0x20]
00007cc2f47da475  vmovaps xmm3, [rsp+0x30]
00007cc2f47da47b  vmovaps xmm4, [rsp+0x40]
00007cc2f47da481  vmovaps xmm5, [rsp+0x50]
00007cc2f47da487  vmovaps xmm6, [rsp+0x60]
00007cc2f47da48d  vmovaps xmm7, [rsp+0x70]
00007cc2f47da493  vmovaps xmm8, [rsp+0x80]
00007cc2f47da49c  vmovaps xmm10, [rsp+0x90]
00007cc2f47da4a5  vmovaps xmm11, [rsp+0xA0]
00007cc2f47da4ae  vmovaps xmm12, [rsp+0xB0]
00007cc2f47da4b7  vmovaps xmm13, [rsp+0xC0]
00007cc2f47da4c0  vmovaps xmm14, [rsp+0xD0]
00007cc2f47da4c9  vmovaps xmm15, [rsp+0xE0]
00007cc2f47da4d2  add rsp, 0xF0
00007cc2f47da4d9  pop r11
00007cc2f47da4db  pop r10
00007cc2f47da4dd  pop r9
00007cc2f47da4df  pop r8
00007cc2f47da4e1  pop rsi
00007cc2f47da4e2  pop rdi
00007cc2f47da4e3  pop rdx
00007cc2f47da4e4  pop rcx
00007cc2f47da4e5  pop rax
00007cc2f47da4e6  add rsp, 0x08
00007cc2f47da4ea  jmp 0x00007CC2F47D8CDB
00007cc2f47da4ef  call 0x00007CC2F46D64F0
00007cc2f47da4f4  jmp 0x00007CC2F47D8DF5
00007cc2f47da4f9  call 0x00007CC2F46D64F0
00007cc2f47da4fe  jmp 0x00007CC2F47D8E0B
00007cc2f47da503  sub rsp, 0x08
00007cc2f47da507  push rax
00007cc2f47da508  push rcx
00007cc2f47da509  push rdx
00007cc2f47da50a  push rdi
00007cc2f47da50b  push rsi
00007cc2f47da50c  push r8
00007cc2f47da50e  push r9
00007cc2f47da510  push r10
00007cc2f47da512  push r11
00007cc2f47da514  sub rsp, 0xF0
00007cc2f47da51b  vmovaps [rsp], xmm0
00007cc2f47da520  vmovaps [rsp+0x10], xmm2
00007cc2f47da526  vmovaps [rsp+0x20], xmm3
00007cc2f47da52c  vmovaps [rsp+0x30], xmm4
00007cc2f47da532  vmovaps [rsp+0x40], xmm5
00007cc2f47da538  vmovaps [rsp+0x50], xmm6
00007cc2f47da53e  vmovaps [rsp+0x60], xmm7
00007cc2f47da544  vmovaps [rsp+0x70], xmm8
00007cc2f47da54a  vmovaps [rsp+0x80], xmm9
00007cc2f47da553  vmovaps [rsp+0x90], xmm10
00007cc2f47da55c  vmovaps [rsp+0xA0], xmm11
00007cc2f47da565  vmovaps [rsp+0xB0], xmm12
00007cc2f47da56e  vmovaps [rsp+0xC0], xmm13
00007cc2f47da577  vmovaps [rsp+0xD0], xmm14
00007cc2f47da580  vmovaps [rsp+0xE0], xmm15
00007cc2f47da589  sub rsp, 0x30
00007cc2f47da58d  movaps [rsp], xmm1
00007cc2f47da591  movaps [rsp+0x10], xmm6
00007cc2f47da596  movaps [rsp+0x20], xmm15
00007cc2f47da59c  lea rdi, [rsp]
00007cc2f47da5a0  mov esi, 0x00
00007cc2f47da5a5  mov rax, 0x5990E710A530
00007cc2f47da5af  call rax
00007cc2f47da5b1  movaps xmm1, [rsp]
00007cc2f47da5b5  add rsp, 0x30
00007cc2f47da5b9  vmovaps xmm0, [rsp]
00007cc2f47da5be  vmovaps xmm2, [rsp+0x10]
00007cc2f47da5c4  vmovaps xmm3, [rsp+0x20]
00007cc2f47da5ca  vmovaps xmm4, [rsp+0x30]
00007cc2f47da5d0  vmovaps xmm5, [rsp+0x40]
00007cc2f47da5d6  vmovaps xmm6, [rsp+0x50]
00007cc2f47da5dc  vmovaps xmm7, [rsp+0x60]
00007cc2f47da5e2  vmovaps xmm8, [rsp+0x70]
00007cc2f47da5e8  vmovaps xmm9, [rsp+0x80]
00007cc2f47da5f1  vmovaps xmm10, [rsp+0x90]
00007cc2f47da5fa  vmovaps xmm11, [rsp+0xA0]
00007cc2f47da603  vmovaps xmm12, [rsp+0xB0]
00007cc2f47da60c  vmovaps xmm13, [rsp+0xC0]
00007cc2f47da615  vmovaps xmm14, [rsp+0xD0]
00007cc2f47da61e  vmovaps xmm15, [rsp+0xE0]
00007cc2f47da627  add rsp, 0xF0
00007cc2f47da62e  pop r11
00007cc2f47da630  pop r10
00007cc2f47da632  pop r9
00007cc2f47da634  pop r8
00007cc2f47da636  pop rsi
00007cc2f47da637  pop rdi
00007cc2f47da638  pop rdx
00007cc2f47da639  pop rcx
00007cc2f47da63a  pop rax
00007cc2f47da63b  add rsp, 0x08
00007cc2f47da63f  jmp 0x00007CC2F47D8E48
00007cc2f47da644  call 0x00007CC2F46E5820
00007cc2f47da649  jmp 0x00007CC2F47D8E55
00007cc2f47da64e  sub rsp, 0x08
00007cc2f47da652  push rax
00007cc2f47da653  push rcx
00007cc2f47da654  push rdx
00007cc2f47da655  push rdi
00007cc2f47da656  push rsi
00007cc2f47da657  push r8
00007cc2f47da659  push r9
00007cc2f47da65b  push r10
00007cc2f47da65d  push r11
00007cc2f47da65f  sub rsp, 0xF0
00007cc2f47da666  vmovaps [rsp], xmm0
00007cc2f47da66b  vmovaps [rsp+0x10], xmm1
00007cc2f47da671  vmovaps [rsp+0x20], xmm2
00007cc2f47da677  vmovaps [rsp+0x30], xmm3
00007cc2f47da67d  vmovaps [rsp+0x40], xmm4
00007cc2f47da683  vmovaps [rsp+0x50], xmm5
00007cc2f47da689  vmovaps [rsp+0x60], xmm6
00007cc2f47da68f  vmovaps [rsp+0x70], xmm7
00007cc2f47da695  vmovaps [rsp+0x80], xmm8
00007cc2f47da69e  vmovaps [rsp+0x90], xmm9
00007cc2f47da6a7  vmovaps [rsp+0xA0], xmm10
00007cc2f47da6b0  vmovaps [rsp+0xB0], xmm11
00007cc2f47da6b9  vmovaps [rsp+0xC0], xmm12
00007cc2f47da6c2  vmovaps [rsp+0xD0], xmm13
00007cc2f47da6cb  vmovaps [rsp+0xE0], xmm15
00007cc2f47da6d4  sub rsp, 0x30
00007cc2f47da6d8  movaps [rsp], xmm14
00007cc2f47da6dd  movaps [rsp+0x10], xmm4
00007cc2f47da6e2  movaps [rsp+0x20], xmm3
00007cc2f47da6e7  lea rdi, [rsp]
00007cc2f47da6eb  mov esi, 0x00
00007cc2f47da6f0  mov rax, 0x5990E710A530
00007cc2f47da6fa  call rax
00007cc2f47da6fc  movaps xmm14, [rsp]
00007cc2f47da701  add rsp, 0x30
00007cc2f47da705  vmovaps xmm0, [rsp]
00007cc2f47da70a  vmovaps xmm1, [rsp+0x10]
00007cc2f47da710  vmovaps xmm2, [rsp+0x20]
00007cc2f47da716  vmovaps xmm3, [rsp+0x30]
00007cc2f47da71c  vmovaps xmm4, [rsp+0x40]
00007cc2f47da722  vmovaps xmm5, [rsp+0x50]
00007cc2f47da728  vmovaps xmm6, [rsp+0x60]
00007cc2f47da72e  vmovaps xmm7, [rsp+0x70]
00007cc2f47da734  vmovaps xmm8, [rsp+0x80]
00007cc2f47da73d  vmovaps xmm9, [rsp+0x90]
00007cc2f47da746  vmovaps xmm10, [rsp+0xA0]
00007cc2f47da74f  vmovaps xmm11, [rsp+0xB0]
00007cc2f47da758  vmovaps xmm12, [rsp+0xC0]
00007cc2f47da761  vmovaps xmm13, [rsp+0xD0]
00007cc2f47da76a  vmovaps xmm15, [rsp+0xE0]
00007cc2f47da773  add rsp, 0xF0
00007cc2f47da77a  pop r11
00007cc2f47da77c  pop r10
00007cc2f47da77e  pop r9
00007cc2f47da780  pop r8
00007cc2f47da782  pop rsi
00007cc2f47da783  pop rdi
00007cc2f47da784  pop rdx
00007cc2f47da785  pop rcx
00007cc2f47da786  pop rax
00007cc2f47da787  add rsp, 0x08
00007cc2f47da78b  jmp 0x00007CC2F47D8E6F
00007cc2f47da790  sub rsp, 0x08
00007cc2f47da794  push rax
00007cc2f47da795  push rcx
00007cc2f47da796  push rdx
00007cc2f47da797  push rdi
00007cc2f47da798  push rsi
00007cc2f47da799  push r8
00007cc2f47da79b  push r9
00007cc2f47da79d  push r10
00007cc2f47da79f  push r11
00007cc2f47da7a1  sub rsp, 0xF0
00007cc2f47da7a8  vmovaps [rsp], xmm0
00007cc2f47da7ad  vmovaps [rsp+0x10], xmm1
00007cc2f47da7b3  vmovaps [rsp+0x20], xmm2
00007cc2f47da7b9  vmovaps [rsp+0x30], xmm3
00007cc2f47da7bf  vmovaps [rsp+0x40], xmm4
00007cc2f47da7c5  vmovaps [rsp+0x50], xmm5
00007cc2f47da7cb  vmovaps [rsp+0x60], xmm7
00007cc2f47da7d1  vmovaps [rsp+0x70], xmm8
00007cc2f47da7d7  vmovaps [rsp+0x80], xmm9
00007cc2f47da7e0  vmovaps [rsp+0x90], xmm10
00007cc2f47da7e9  vmovaps [rsp+0xA0], xmm11
00007cc2f47da7f2  vmovaps [rsp+0xB0], xmm12
00007cc2f47da7fb  vmovaps [rsp+0xC0], xmm13
00007cc2f47da804  vmovaps [rsp+0xD0], xmm14
00007cc2f47da80d  vmovaps [rsp+0xE0], xmm15
00007cc2f47da816  sub rsp, 0x30
00007cc2f47da81a  movaps [rsp], xmm6
00007cc2f47da81e  movaps [rsp+0x10], xmm9
00007cc2f47da824  movaps [rsp+0x20], xmm7
00007cc2f47da829  lea rdi, [rsp]
00007cc2f47da82d  mov esi, 0x00
00007cc2f47da832  mov rax, 0x5990E710A530
00007cc2f47da83c  call rax
00007cc2f47da83e  movaps xmm6, [rsp]
00007cc2f47da842  add rsp, 0x30
00007cc2f47da846  vmovaps xmm0, [rsp]
00007cc2f47da84b  vmovaps xmm1, [rsp+0x10]
00007cc2f47da851  vmovaps xmm2, [rsp+0x20]
00007cc2f47da857  vmovaps xmm3, [rsp+0x30]
00007cc2f47da85d  vmovaps xmm4, [rsp+0x40]
00007cc2f47da863  vmovaps xmm5, [rsp+0x50]
00007cc2f47da869  vmovaps xmm7, [rsp+0x60]
00007cc2f47da86f  vmovaps xmm8, [rsp+0x70]
00007cc2f47da875  vmovaps xmm9, [rsp+0x80]
00007cc2f47da87e  vmovaps xmm10, [rsp+0x90]
00007cc2f47da887  vmovaps xmm11, [rsp+0xA0]
00007cc2f47da890  vmovaps xmm12, [rsp+0xB0]
00007cc2f47da899  vmovaps xmm13, [rsp+0xC0]
00007cc2f47da8a2  vmovaps xmm14, [rsp+0xD0]
00007cc2f47da8ab  vmovaps xmm15, [rsp+0xE0]
00007cc2f47da8b4  add rsp, 0xF0
00007cc2f47da8bb  pop r11
00007cc2f47da8bd  pop r10
00007cc2f47da8bf  pop r9
00007cc2f47da8c1  pop r8
00007cc2f47da8c3  pop rsi
00007cc2f47da8c4  pop rdi
00007cc2f47da8c5  pop rdx
00007cc2f47da8c6  pop rcx
00007cc2f47da8c7  pop rax
00007cc2f47da8c8  add rsp, 0x08
00007cc2f47da8cc  jmp 0x00007CC2F47D8E87
00007cc2f47da8d1  sub rsp, 0x08
00007cc2f47da8d5  push rax
00007cc2f47da8d6  push rcx
00007cc2f47da8d7  push rdx
00007cc2f47da8d8  push rdi
00007cc2f47da8d9  push rsi
00007cc2f47da8da  push r8
00007cc2f47da8dc  push r9
00007cc2f47da8de  push r10
00007cc2f47da8e0  push r11
00007cc2f47da8e2  sub rsp, 0xF0
00007cc2f47da8e9  vmovaps [rsp], xmm0
00007cc2f47da8ee  vmovaps [rsp+0x10], xmm1
00007cc2f47da8f4  vmovaps [rsp+0x20], xmm2
00007cc2f47da8fa  vmovaps [rsp+0x30], xmm3
00007cc2f47da900  vmovaps [rsp+0x40], xmm4
00007cc2f47da906  vmovaps [rsp+0x50], xmm5
00007cc2f47da90c  vmovaps [rsp+0x60], xmm6
00007cc2f47da912  vmovaps [rsp+0x70], xmm8
00007cc2f47da918  vmovaps [rsp+0x80], xmm9
00007cc2f47da921  vmovaps [rsp+0x90], xmm10
00007cc2f47da92a  vmovaps [rsp+0xA0], xmm11
00007cc2f47da933  vmovaps [rsp+0xB0], xmm12
00007cc2f47da93c  vmovaps [rsp+0xC0], xmm13
00007cc2f47da945  vmovaps [rsp+0xD0], xmm14
00007cc2f47da94e  vmovaps [rsp+0xE0], xmm15
00007cc2f47da957  sub rsp, 0x30
00007cc2f47da95b  movaps [rsp], xmm7
00007cc2f47da95f  movaps [rsp+0x10], xmm4
00007cc2f47da964  movaps [rsp+0x20], xmm9
00007cc2f47da96a  lea rdi, [rsp]
00007cc2f47da96e  mov esi, 0x00
00007cc2f47da973  mov rax, 0x5990E710A530
00007cc2f47da97d  call rax
00007cc2f47da97f  movaps xmm7, [rsp]
00007cc2f47da983  add rsp, 0x30
00007cc2f47da987  vmovaps xmm0, [rsp]
00007cc2f47da98c  vmovaps xmm1, [rsp+0x10]
00007cc2f47da992  vmovaps xmm2, [rsp+0x20]
00007cc2f47da998  vmovaps xmm3, [rsp+0x30]
00007cc2f47da99e  vmovaps xmm4, [rsp+0x40]
00007cc2f47da9a4  vmovaps xmm5, [rsp+0x50]
00007cc2f47da9aa  vmovaps xmm6, [rsp+0x60]
00007cc2f47da9b0  vmovaps xmm8, [rsp+0x70]
00007cc2f47da9b6  vmovaps xmm9, [rsp+0x80]
00007cc2f47da9bf  vmovaps xmm10, [rsp+0x90]
00007cc2f47da9c8  vmovaps xmm11, [rsp+0xA0]
00007cc2f47da9d1  vmovaps xmm12, [rsp+0xB0]
00007cc2f47da9da  vmovaps xmm13, [rsp+0xC0]
00007cc2f47da9e3  vmovaps xmm14, [rsp+0xD0]
00007cc2f47da9ec  vmovaps xmm15, [rsp+0xE0]
00007cc2f47da9f5  add rsp, 0xF0
00007cc2f47da9fc  pop r11
00007cc2f47da9fe  pop r10
00007cc2f47daa00  pop r9
00007cc2f47daa02  pop r8
00007cc2f47daa04  pop rsi
00007cc2f47daa05  pop rdi
00007cc2f47daa06  pop rdx
00007cc2f47daa07  pop rcx
00007cc2f47daa08  pop rax
00007cc2f47daa09  add rsp, 0x08
00007cc2f47daa0d  jmp 0x00007CC2F47D8EB4
00007cc2f47daa12  sub rsp, 0x08
00007cc2f47daa16  push rax
00007cc2f47daa17  push rcx
00007cc2f47daa18  push rdx
00007cc2f47daa19  push rdi
00007cc2f47daa1a  push rsi
00007cc2f47daa1b  push r8
00007cc2f47daa1d  push r9
00007cc2f47daa1f  push r10
00007cc2f47daa21  push r11
00007cc2f47daa23  sub rsp, 0xF0
00007cc2f47daa2a  vmovaps [rsp], xmm0
00007cc2f47daa2f  vmovaps [rsp+0x10], xmm1
00007cc2f47daa35  vmovaps [rsp+0x20], xmm2
00007cc2f47daa3b  vmovaps [rsp+0x30], xmm3
00007cc2f47daa41  vmovaps [rsp+0x40], xmm5
00007cc2f47daa47  vmovaps [rsp+0x50], xmm6
00007cc2f47daa4d  vmovaps [rsp+0x60], xmm7
00007cc2f47daa53  vmovaps [rsp+0x70], xmm8
00007cc2f47daa59  vmovaps [rsp+0x80], xmm9
00007cc2f47daa62  vmovaps [rsp+0x90], xmm10
00007cc2f47daa6b  vmovaps [rsp+0xA0], xmm11
00007cc2f47daa74  vmovaps [rsp+0xB0], xmm12
00007cc2f47daa7d  vmovaps [rsp+0xC0], xmm13
00007cc2f47daa86  vmovaps [rsp+0xD0], xmm14
00007cc2f47daa8f  vmovaps [rsp+0xE0], xmm15
00007cc2f47daa98  sub rsp, 0x30
00007cc2f47daa9c  movaps [rsp], xmm4
00007cc2f47daaa0  movaps [rsp+0x10], xmm15
00007cc2f47daaa6  movaps [rsp+0x20], xmm9
00007cc2f47daaac  lea rdi, [rsp]
00007cc2f47daab0  mov esi, 0x00
00007cc2f47daab5  mov rax, 0x5990E710A530
00007cc2f47daabf  call rax
00007cc2f47daac1  movaps xmm4, [rsp]
00007cc2f47daac5  add rsp, 0x30
00007cc2f47daac9  vmovaps xmm0, [rsp]
00007cc2f47daace  vmovaps xmm1, [rsp+0x10]
00007cc2f47daad4  vmovaps xmm2, [rsp+0x20]
00007cc2f47daada  vmovaps xmm3, [rsp+0x30]
00007cc2f47daae0  vmovaps xmm5, [rsp+0x40]
00007cc2f47daae6  vmovaps xmm6, [rsp+0x50]
00007cc2f47daaec  vmovaps xmm7, [rsp+0x60]
00007cc2f47daaf2  vmovaps xmm8, [rsp+0x70]
00007cc2f47daaf8  vmovaps xmm9, [rsp+0x80]
00007cc2f47dab01  vmovaps xmm10, [rsp+0x90]
00007cc2f47dab0a  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dab13  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dab1c  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dab25  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dab2e  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dab37  add rsp, 0xF0
00007cc2f47dab3e  pop r11
00007cc2f47dab40  pop r10
00007cc2f47dab42  pop r9
00007cc2f47dab44  pop r8
00007cc2f47dab46  pop rsi
00007cc2f47dab47  pop rdi
00007cc2f47dab48  pop rdx
00007cc2f47dab49  pop rcx
00007cc2f47dab4a  pop rax
00007cc2f47dab4b  add rsp, 0x08
00007cc2f47dab4f  jmp 0x00007CC2F47D8ED9
00007cc2f47dab54  call 0x00007CC2F46E5820
00007cc2f47dab59  jmp 0x00007CC2F47D8EE6
00007cc2f47dab5e  sub rsp, 0x08
00007cc2f47dab62  push rax
00007cc2f47dab63  push rcx
00007cc2f47dab64  push rdx
00007cc2f47dab65  push rdi
00007cc2f47dab66  push rsi
00007cc2f47dab67  push r8
00007cc2f47dab69  push r9
00007cc2f47dab6b  push r10
00007cc2f47dab6d  push r11
00007cc2f47dab6f  sub rsp, 0xF0
00007cc2f47dab76  vmovaps [rsp], xmm0
00007cc2f47dab7b  vmovaps [rsp+0x10], xmm1
00007cc2f47dab81  vmovaps [rsp+0x20], xmm2
00007cc2f47dab87  vmovaps [rsp+0x30], xmm4
00007cc2f47dab8d  vmovaps [rsp+0x40], xmm5
00007cc2f47dab93  vmovaps [rsp+0x50], xmm6
00007cc2f47dab99  vmovaps [rsp+0x60], xmm7
00007cc2f47dab9f  vmovaps [rsp+0x70], xmm8
00007cc2f47daba5  vmovaps [rsp+0x80], xmm9
00007cc2f47dabae  vmovaps [rsp+0x90], xmm10
00007cc2f47dabb7  vmovaps [rsp+0xA0], xmm11
00007cc2f47dabc0  vmovaps [rsp+0xB0], xmm12
00007cc2f47dabc9  vmovaps [rsp+0xC0], xmm13
00007cc2f47dabd2  vmovaps [rsp+0xD0], xmm14
00007cc2f47dabdb  vmovaps [rsp+0xE0], xmm15
00007cc2f47dabe4  sub rsp, 0x30
00007cc2f47dabe8  movaps [rsp], xmm3
00007cc2f47dabec  movaps [rsp+0x10], xmm1
00007cc2f47dabf1  movaps [rsp+0x20], xmm9
00007cc2f47dabf7  lea rdi, [rsp]
00007cc2f47dabfb  mov esi, 0x00
00007cc2f47dac00  mov rax, 0x5990E710A530
00007cc2f47dac0a  call rax
00007cc2f47dac0c  movaps xmm3, [rsp]
00007cc2f47dac10  add rsp, 0x30
00007cc2f47dac14  vmovaps xmm0, [rsp]
00007cc2f47dac19  vmovaps xmm1, [rsp+0x10]
00007cc2f47dac1f  vmovaps xmm2, [rsp+0x20]
00007cc2f47dac25  vmovaps xmm4, [rsp+0x30]
00007cc2f47dac2b  vmovaps xmm5, [rsp+0x40]
00007cc2f47dac31  vmovaps xmm6, [rsp+0x50]
00007cc2f47dac37  vmovaps xmm7, [rsp+0x60]
00007cc2f47dac3d  vmovaps xmm8, [rsp+0x70]
00007cc2f47dac43  vmovaps xmm9, [rsp+0x80]
00007cc2f47dac4c  vmovaps xmm10, [rsp+0x90]
00007cc2f47dac55  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dac5e  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dac67  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dac70  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dac79  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dac82  add rsp, 0xF0
00007cc2f47dac89  pop r11
00007cc2f47dac8b  pop r10
00007cc2f47dac8d  pop r9
00007cc2f47dac8f  pop r8
00007cc2f47dac91  pop rsi
00007cc2f47dac92  pop rdi
00007cc2f47dac93  pop rdx
00007cc2f47dac94  pop rcx
00007cc2f47dac95  pop rax
00007cc2f47dac96  add rsp, 0x08
00007cc2f47dac9a  jmp 0x00007CC2F47D8F23
00007cc2f47dac9f  sub rsp, 0x08
00007cc2f47daca3  push rax
00007cc2f47daca4  push rcx
00007cc2f47daca5  push rdx
00007cc2f47daca6  push rdi
00007cc2f47daca7  push rsi
00007cc2f47daca8  push r8
00007cc2f47dacaa  push r9
00007cc2f47dacac  push r10
00007cc2f47dacae  push r11
00007cc2f47dacb0  sub rsp, 0xF0
00007cc2f47dacb7  vmovaps [rsp], xmm0
00007cc2f47dacbc  vmovaps [rsp+0x10], xmm2
00007cc2f47dacc2  vmovaps [rsp+0x20], xmm3
00007cc2f47dacc8  vmovaps [rsp+0x30], xmm4
00007cc2f47dacce  vmovaps [rsp+0x40], xmm5
00007cc2f47dacd4  vmovaps [rsp+0x50], xmm6
00007cc2f47dacda  vmovaps [rsp+0x60], xmm7
00007cc2f47dace0  vmovaps [rsp+0x70], xmm8
00007cc2f47dace6  vmovaps [rsp+0x80], xmm9
00007cc2f47dacef  vmovaps [rsp+0x90], xmm10
00007cc2f47dacf8  vmovaps [rsp+0xA0], xmm11
00007cc2f47dad01  vmovaps [rsp+0xB0], xmm12
00007cc2f47dad0a  vmovaps [rsp+0xC0], xmm13
00007cc2f47dad13  vmovaps [rsp+0xD0], xmm14
00007cc2f47dad1c  vmovaps [rsp+0xE0], xmm15
00007cc2f47dad25  sub rsp, 0x30
00007cc2f47dad29  movaps [rsp], xmm1
00007cc2f47dad2d  movaps [rsp+0x10], xmm15
00007cc2f47dad33  movaps [rsp+0x20], xmm9
00007cc2f47dad39  lea rdi, [rsp]
00007cc2f47dad3d  mov esi, 0x00
00007cc2f47dad42  mov rax, 0x5990E710A530
00007cc2f47dad4c  call rax
00007cc2f47dad4e  movaps xmm1, [rsp]
00007cc2f47dad52  add rsp, 0x30
00007cc2f47dad56  vmovaps xmm0, [rsp]
00007cc2f47dad5b  vmovaps xmm2, [rsp+0x10]
00007cc2f47dad61  vmovaps xmm3, [rsp+0x20]
00007cc2f47dad67  vmovaps xmm4, [rsp+0x30]
00007cc2f47dad6d  vmovaps xmm5, [rsp+0x40]
00007cc2f47dad73  vmovaps xmm6, [rsp+0x50]
00007cc2f47dad79  vmovaps xmm7, [rsp+0x60]
00007cc2f47dad7f  vmovaps xmm8, [rsp+0x70]
00007cc2f47dad85  vmovaps xmm9, [rsp+0x80]
00007cc2f47dad8e  vmovaps xmm10, [rsp+0x90]
00007cc2f47dad97  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dada0  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dada9  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dadb2  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dadbb  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dadc4  add rsp, 0xF0
00007cc2f47dadcb  pop r11
00007cc2f47dadcd  pop r10
00007cc2f47dadcf  pop r9
00007cc2f47dadd1  pop r8
00007cc2f47dadd3  pop rsi
00007cc2f47dadd4  pop rdi
00007cc2f47dadd5  pop rdx
00007cc2f47dadd6  pop rcx
00007cc2f47dadd7  pop rax
00007cc2f47dadd8  add rsp, 0x08
00007cc2f47daddc  jmp 0x00007CC2F47D8FAB
00007cc2f47dade1  call 0x00007CC2F46E5820
00007cc2f47dade6  jmp 0x00007CC2F47D8FB8
00007cc2f47dadeb  sub rsp, 0x08
00007cc2f47dadef  push rax
00007cc2f47dadf0  push rcx
00007cc2f47dadf1  push rdx
00007cc2f47dadf2  push rdi
00007cc2f47dadf3  push rsi
00007cc2f47dadf4  push r8
00007cc2f47dadf6  push r9
00007cc2f47dadf8  push r10
00007cc2f47dadfa  push r11
00007cc2f47dadfc  sub rsp, 0xF0
00007cc2f47dae03  vmovaps [rsp], xmm0
00007cc2f47dae08  vmovaps [rsp+0x10], xmm2
00007cc2f47dae0e  vmovaps [rsp+0x20], xmm3
00007cc2f47dae14  vmovaps [rsp+0x30], xmm4
00007cc2f47dae1a  vmovaps [rsp+0x40], xmm5
00007cc2f47dae20  vmovaps [rsp+0x50], xmm6
00007cc2f47dae26  vmovaps [rsp+0x60], xmm7
00007cc2f47dae2c  vmovaps [rsp+0x70], xmm8
00007cc2f47dae32  vmovaps [rsp+0x80], xmm9
00007cc2f47dae3b  vmovaps [rsp+0x90], xmm10
00007cc2f47dae44  vmovaps [rsp+0xA0], xmm11
00007cc2f47dae4d  vmovaps [rsp+0xB0], xmm12
00007cc2f47dae56  vmovaps [rsp+0xC0], xmm13
00007cc2f47dae5f  vmovaps [rsp+0xD0], xmm14
00007cc2f47dae68  vmovaps [rsp+0xE0], xmm15
00007cc2f47dae71  sub rsp, 0x30
00007cc2f47dae75  movaps [rsp], xmm1
00007cc2f47dae79  movaps [rsp+0x10], xmm5
00007cc2f47dae7e  movaps [rsp+0x20], xmm7
00007cc2f47dae83  lea rdi, [rsp]
00007cc2f47dae87  mov esi, 0x00
00007cc2f47dae8c  mov rax, 0x5990E710A530
00007cc2f47dae96  call rax
00007cc2f47dae98  movaps xmm1, [rsp]
00007cc2f47dae9c  add rsp, 0x30
00007cc2f47daea0  vmovaps xmm0, [rsp]
00007cc2f47daea5  vmovaps xmm2, [rsp+0x10]
00007cc2f47daeab  vmovaps xmm3, [rsp+0x20]
00007cc2f47daeb1  vmovaps xmm4, [rsp+0x30]
00007cc2f47daeb7  vmovaps xmm5, [rsp+0x40]
00007cc2f47daebd  vmovaps xmm6, [rsp+0x50]
00007cc2f47daec3  vmovaps xmm7, [rsp+0x60]
00007cc2f47daec9  vmovaps xmm8, [rsp+0x70]
00007cc2f47daecf  vmovaps xmm9, [rsp+0x80]
00007cc2f47daed8  vmovaps xmm10, [rsp+0x90]
00007cc2f47daee1  vmovaps xmm11, [rsp+0xA0]
00007cc2f47daeea  vmovaps xmm12, [rsp+0xB0]
00007cc2f47daef3  vmovaps xmm13, [rsp+0xC0]
00007cc2f47daefc  vmovaps xmm14, [rsp+0xD0]
00007cc2f47daf05  vmovaps xmm15, [rsp+0xE0]
00007cc2f47daf0e  add rsp, 0xF0
00007cc2f47daf15  pop r11
00007cc2f47daf17  pop r10
00007cc2f47daf19  pop r9
00007cc2f47daf1b  pop r8
00007cc2f47daf1d  pop rsi
00007cc2f47daf1e  pop rdi
00007cc2f47daf1f  pop rdx
00007cc2f47daf20  pop rcx
00007cc2f47daf21  pop rax
00007cc2f47daf22  add rsp, 0x08
00007cc2f47daf26  jmp 0x00007CC2F47D905D
00007cc2f47daf2b  sub rsp, 0x08
00007cc2f47daf2f  push rax
00007cc2f47daf30  push rcx
00007cc2f47daf31  push rdx
00007cc2f47daf32  push rdi
00007cc2f47daf33  push rsi
00007cc2f47daf34  push r8
00007cc2f47daf36  push r9
00007cc2f47daf38  push r10
00007cc2f47daf3a  push r11
00007cc2f47daf3c  sub rsp, 0xF0
00007cc2f47daf43  vmovaps [rsp], xmm0
00007cc2f47daf48  vmovaps [rsp+0x10], xmm1
00007cc2f47daf4e  vmovaps [rsp+0x20], xmm2
00007cc2f47daf54  vmovaps [rsp+0x30], xmm3
00007cc2f47daf5a  vmovaps [rsp+0x40], xmm4
00007cc2f47daf60  vmovaps [rsp+0x50], xmm5
00007cc2f47daf66  vmovaps [rsp+0x60], xmm6
00007cc2f47daf6c  vmovaps [rsp+0x70], xmm8
00007cc2f47daf72  vmovaps [rsp+0x80], xmm9
00007cc2f47daf7b  vmovaps [rsp+0x90], xmm10
00007cc2f47daf84  vmovaps [rsp+0xA0], xmm11
00007cc2f47daf8d  vmovaps [rsp+0xB0], xmm12
00007cc2f47daf96  vmovaps [rsp+0xC0], xmm13
00007cc2f47daf9f  vmovaps [rsp+0xD0], xmm14
00007cc2f47dafa8  vmovaps [rsp+0xE0], xmm15
00007cc2f47dafb1  sub rsp, 0x30
00007cc2f47dafb5  movaps [rsp], xmm7
00007cc2f47dafb9  movaps [rsp+0x10], xmm5
00007cc2f47dafbe  movaps [rsp+0x20], xmm15
00007cc2f47dafc4  lea rdi, [rsp]
00007cc2f47dafc8  mov esi, 0x00
00007cc2f47dafcd  mov rax, 0x5990E710A530
00007cc2f47dafd7  call rax
00007cc2f47dafd9  movaps xmm7, [rsp]
00007cc2f47dafdd  add rsp, 0x30
00007cc2f47dafe1  vmovaps xmm0, [rsp]
00007cc2f47dafe6  vmovaps xmm1, [rsp+0x10]
00007cc2f47dafec  vmovaps xmm2, [rsp+0x20]
00007cc2f47daff2  vmovaps xmm3, [rsp+0x30]
00007cc2f47daff8  vmovaps xmm4, [rsp+0x40]
00007cc2f47daffe  vmovaps xmm5, [rsp+0x50]
00007cc2f47db004  vmovaps xmm6, [rsp+0x60]
00007cc2f47db00a  vmovaps xmm8, [rsp+0x70]
00007cc2f47db010  vmovaps xmm9, [rsp+0x80]
00007cc2f47db019  vmovaps xmm10, [rsp+0x90]
00007cc2f47db022  vmovaps xmm11, [rsp+0xA0]
00007cc2f47db02b  vmovaps xmm12, [rsp+0xB0]
00007cc2f47db034  vmovaps xmm13, [rsp+0xC0]
00007cc2f47db03d  vmovaps xmm14, [rsp+0xD0]
00007cc2f47db046  vmovaps xmm15, [rsp+0xE0]
00007cc2f47db04f  add rsp, 0xF0
00007cc2f47db056  pop r11
00007cc2f47db058  pop r10
00007cc2f47db05a  pop r9
00007cc2f47db05c  pop r8
00007cc2f47db05e  pop rsi
00007cc2f47db05f  pop rdi
00007cc2f47db060  pop rdx
00007cc2f47db061  pop rcx
00007cc2f47db062  pop rax
00007cc2f47db063  add rsp, 0x08
00007cc2f47db067  jmp 0x00007CC2F47D9093
00007cc2f47db06c  call 0x00007CC2F46D64F0
00007cc2f47db071  jmp 0x00007CC2F47D90A0
00007cc2f47db076  sub rsp, 0x08
00007cc2f47db07a  push rax
00007cc2f47db07b  push rcx
00007cc2f47db07c  push rdx
00007cc2f47db07d  push rdi
00007cc2f47db07e  push rsi
00007cc2f47db07f  push r8
00007cc2f47db081  push r9
00007cc2f47db083  push r10
00007cc2f47db085  push r11
00007cc2f47db087  sub rsp, 0xF0
00007cc2f47db08e  vmovaps [rsp], xmm0
00007cc2f47db093  vmovaps [rsp+0x10], xmm1
00007cc2f47db099  vmovaps [rsp+0x20], xmm2
00007cc2f47db09f  vmovaps [rsp+0x30], xmm3
00007cc2f47db0a5  vmovaps [rsp+0x40], xmm4
00007cc2f47db0ab  vmovaps [rsp+0x50], xmm5
00007cc2f47db0b1  vmovaps [rsp+0x60], xmm6
00007cc2f47db0b7  vmovaps [rsp+0x70], xmm7
00007cc2f47db0bd  vmovaps [rsp+0x80], xmm8
00007cc2f47db0c6  vmovaps [rsp+0x90], xmm9
00007cc2f47db0cf  vmovaps [rsp+0xA0], xmm10
00007cc2f47db0d8  vmovaps [rsp+0xB0], xmm11
00007cc2f47db0e1  vmovaps [rsp+0xC0], xmm12
00007cc2f47db0ea  vmovaps [rsp+0xD0], xmm13
00007cc2f47db0f3  vmovaps [rsp+0xE0], xmm14
00007cc2f47db0fc  sub rsp, 0x30
00007cc2f47db100  movaps [rsp], xmm15
00007cc2f47db105  movaps [rsp+0x10], xmm5
00007cc2f47db10a  movaps [rsp+0x20], xmm3
00007cc2f47db10f  lea rdi, [rsp]
00007cc2f47db113  mov esi, 0x00
00007cc2f47db118  mov rax, 0x5990E710A530
00007cc2f47db122  call rax
00007cc2f47db124  movaps xmm15, [rsp]
00007cc2f47db129  add rsp, 0x30
00007cc2f47db12d  vmovaps xmm0, [rsp]
00007cc2f47db132  vmovaps xmm1, [rsp+0x10]
00007cc2f47db138  vmovaps xmm2, [rsp+0x20]
00007cc2f47db13e  vmovaps xmm3, [rsp+0x30]
00007cc2f47db144  vmovaps xmm4, [rsp+0x40]
00007cc2f47db14a  vmovaps xmm5, [rsp+0x50]
00007cc2f47db150  vmovaps xmm6, [rsp+0x60]
00007cc2f47db156  vmovaps xmm7, [rsp+0x70]
00007cc2f47db15c  vmovaps xmm8, [rsp+0x80]
00007cc2f47db165  vmovaps xmm9, [rsp+0x90]
00007cc2f47db16e  vmovaps xmm10, [rsp+0xA0]
00007cc2f47db177  vmovaps xmm11, [rsp+0xB0]
00007cc2f47db180  vmovaps xmm12, [rsp+0xC0]
00007cc2f47db189  vmovaps xmm13, [rsp+0xD0]
00007cc2f47db192  vmovaps xmm14, [rsp+0xE0]
00007cc2f47db19b  add rsp, 0xF0
00007cc2f47db1a2  pop r11
00007cc2f47db1a4  pop r10
00007cc2f47db1a6  pop r9
00007cc2f47db1a8  pop r8
00007cc2f47db1aa  pop rsi
00007cc2f47db1ab  pop rdi
00007cc2f47db1ac  pop rdx
00007cc2f47db1ad  pop rcx
00007cc2f47db1ae  pop rax
00007cc2f47db1af  add rsp, 0x08
00007cc2f47db1b3  jmp 0x00007CC2F47D90C6
00007cc2f47db1b8  sub rsp, 0x08
00007cc2f47db1bc  push rax
00007cc2f47db1bd  push rcx
00007cc2f47db1be  push rdx
00007cc2f47db1bf  push rdi
00007cc2f47db1c0  push rsi
00007cc2f47db1c1  push r8
00007cc2f47db1c3  push r9
00007cc2f47db1c5  push r10
00007cc2f47db1c7  push r11
00007cc2f47db1c9  sub rsp, 0xF0
00007cc2f47db1d0  vmovaps [rsp], xmm0
00007cc2f47db1d5  vmovaps [rsp+0x10], xmm2
00007cc2f47db1db  vmovaps [rsp+0x20], xmm3
00007cc2f47db1e1  vmovaps [rsp+0x30], xmm4
00007cc2f47db1e7  vmovaps [rsp+0x40], xmm5
00007cc2f47db1ed  vmovaps [rsp+0x50], xmm6
00007cc2f47db1f3  vmovaps [rsp+0x60], xmm7
00007cc2f47db1f9  vmovaps [rsp+0x70], xmm8
00007cc2f47db1ff  vmovaps [rsp+0x80], xmm9
00007cc2f47db208  vmovaps [rsp+0x90], xmm10
00007cc2f47db211  vmovaps [rsp+0xA0], xmm11
00007cc2f47db21a  vmovaps [rsp+0xB0], xmm12
00007cc2f47db223  vmovaps [rsp+0xC0], xmm13
00007cc2f47db22c  vmovaps [rsp+0xD0], xmm14
00007cc2f47db235  vmovaps [rsp+0xE0], xmm15
00007cc2f47db23e  sub rsp, 0x30
00007cc2f47db242  movaps [rsp], xmm1
00007cc2f47db246  movaps [rsp+0x10], xmm5
00007cc2f47db24b  movaps [rsp+0x20], xmm4
00007cc2f47db250  lea rdi, [rsp]
00007cc2f47db254  mov esi, 0x00
00007cc2f47db259  mov rax, 0x5990E710A530
00007cc2f47db263  call rax
00007cc2f47db265  movaps xmm1, [rsp]
00007cc2f47db269  add rsp, 0x30
00007cc2f47db26d  vmovaps xmm0, [rsp]
00007cc2f47db272  vmovaps xmm2, [rsp+0x10]
00007cc2f47db278  vmovaps xmm3, [rsp+0x20]
00007cc2f47db27e  vmovaps xmm4, [rsp+0x30]
00007cc2f47db284  vmovaps xmm5, [rsp+0x40]
00007cc2f47db28a  vmovaps xmm6, [rsp+0x50]
00007cc2f47db290  vmovaps xmm7, [rsp+0x60]
00007cc2f47db296  vmovaps xmm8, [rsp+0x70]
00007cc2f47db29c  vmovaps xmm9, [rsp+0x80]
00007cc2f47db2a5  vmovaps xmm10, [rsp+0x90]
00007cc2f47db2ae  vmovaps xmm11, [rsp+0xA0]
00007cc2f47db2b7  vmovaps xmm12, [rsp+0xB0]
00007cc2f47db2c0  vmovaps xmm13, [rsp+0xC0]
00007cc2f47db2c9  vmovaps xmm14, [rsp+0xD0]
00007cc2f47db2d2  vmovaps xmm15, [rsp+0xE0]
00007cc2f47db2db  add rsp, 0xF0
00007cc2f47db2e2  pop r11
00007cc2f47db2e4  pop r10
00007cc2f47db2e6  pop r9
00007cc2f47db2e8  pop r8
00007cc2f47db2ea  pop rsi
00007cc2f47db2eb  pop rdi
00007cc2f47db2ec  pop rdx
00007cc2f47db2ed  pop rcx
00007cc2f47db2ee  pop rax
00007cc2f47db2ef  add rsp, 0x08
00007cc2f47db2f3  jmp 0x00007CC2F47D90E6
00007cc2f47db2f8  sub rsp, 0x08
00007cc2f47db2fc  push rax
00007cc2f47db2fd  push rcx
00007cc2f47db2fe  push rdx
00007cc2f47db2ff  push rdi
00007cc2f47db300  push rsi
00007cc2f47db301  push r8
00007cc2f47db303  push r9
00007cc2f47db305  push r10
00007cc2f47db307  push r11
00007cc2f47db309  sub rsp, 0xF0
00007cc2f47db310  vmovaps [rsp], xmm0
00007cc2f47db315  vmovaps [rsp+0x10], xmm1
00007cc2f47db31b  vmovaps [rsp+0x20], xmm2
00007cc2f47db321  vmovaps [rsp+0x30], xmm3
00007cc2f47db327  vmovaps [rsp+0x40], xmm5
00007cc2f47db32d  vmovaps [rsp+0x50], xmm6
00007cc2f47db333  vmovaps [rsp+0x60], xmm7
00007cc2f47db339  vmovaps [rsp+0x70], xmm8
00007cc2f47db33f  vmovaps [rsp+0x80], xmm9
00007cc2f47db348  vmovaps [rsp+0x90], xmm10
00007cc2f47db351  vmovaps [rsp+0xA0], xmm11
00007cc2f47db35a  vmovaps [rsp+0xB0], xmm12
00007cc2f47db363  vmovaps [rsp+0xC0], xmm13
00007cc2f47db36c  vmovaps [rsp+0xD0], xmm14
00007cc2f47db375  vmovaps [rsp+0xE0], xmm15
00007cc2f47db37e  sub rsp, 0x30
00007cc2f47db382  movaps [rsp], xmm4
00007cc2f47db386  movaps [rsp+0x10], xmm3
00007cc2f47db38b  movaps [rsp+0x20], xmm5
00007cc2f47db390  lea rdi, [rsp]
00007cc2f47db394  mov esi, 0x00
00007cc2f47db399  mov rax, 0x5990E710A530
00007cc2f47db3a3  call rax
00007cc2f47db3a5  movaps xmm4, [rsp]
00007cc2f47db3a9  add rsp, 0x30
00007cc2f47db3ad  vmovaps xmm0, [rsp]
00007cc2f47db3b2  vmovaps xmm1, [rsp+0x10]
00007cc2f47db3b8  vmovaps xmm2, [rsp+0x20]
00007cc2f47db3be  vmovaps xmm3, [rsp+0x30]
00007cc2f47db3c4  vmovaps xmm5, [rsp+0x40]
00007cc2f47db3ca  vmovaps xmm6, [rsp+0x50]
00007cc2f47db3d0  vmovaps xmm7, [rsp+0x60]
00007cc2f47db3d6  vmovaps xmm8, [rsp+0x70]
00007cc2f47db3dc  vmovaps xmm9, [rsp+0x80]
00007cc2f47db3e5  vmovaps xmm10, [rsp+0x90]
00007cc2f47db3ee  vmovaps xmm11, [rsp+0xA0]
00007cc2f47db3f7  vmovaps xmm12, [rsp+0xB0]
00007cc2f47db400  vmovaps xmm13, [rsp+0xC0]
00007cc2f47db409  vmovaps xmm14, [rsp+0xD0]
00007cc2f47db412  vmovaps xmm15, [rsp+0xE0]
00007cc2f47db41b  add rsp, 0xF0
00007cc2f47db422  pop r11
00007cc2f47db424  pop r10
00007cc2f47db426  pop r9
00007cc2f47db428  pop r8
00007cc2f47db42a  pop rsi
00007cc2f47db42b  pop rdi
00007cc2f47db42c  pop rdx
00007cc2f47db42d  pop rcx
00007cc2f47db42e  pop rax
00007cc2f47db42f  add rsp, 0x08
00007cc2f47db433  jmp 0x00007CC2F47D9134
00007cc2f47db438  call 0x00007CC2F46D64F0
00007cc2f47db43d  jmp 0x00007CC2F47D9141
00007cc2f47db442  sub rsp, 0x08
00007cc2f47db446  push rax
00007cc2f47db447  push rcx
00007cc2f47db448  push rdx
00007cc2f47db449  push rdi
00007cc2f47db44a  push rsi
00007cc2f47db44b  push r8
00007cc2f47db44d  push r9
00007cc2f47db44f  push r10
00007cc2f47db451  push r11
00007cc2f47db453  sub rsp, 0xF0
00007cc2f47db45a  vmovaps [rsp], xmm0
00007cc2f47db45f  vmovaps [rsp+0x10], xmm1
00007cc2f47db465  vmovaps [rsp+0x20], xmm2
00007cc2f47db46b  vmovaps [rsp+0x30], xmm3
00007cc2f47db471  vmovaps [rsp+0x40], xmm4
00007cc2f47db477  vmovaps [rsp+0x50], xmm6
00007cc2f47db47d  vmovaps [rsp+0x60], xmm7
00007cc2f47db483  vmovaps [rsp+0x70], xmm8
00007cc2f47db489  vmovaps [rsp+0x80], xmm9
00007cc2f47db492  vmovaps [rsp+0x90], xmm10
00007cc2f47db49b  vmovaps [rsp+0xA0], xmm11
00007cc2f47db4a4  vmovaps [rsp+0xB0], xmm12
00007cc2f47db4ad  vmovaps [rsp+0xC0], xmm13
00007cc2f47db4b6  vmovaps [rsp+0xD0], xmm14
00007cc2f47db4bf  vmovaps [rsp+0xE0], xmm15
00007cc2f47db4c8  sub rsp, 0x30
00007cc2f47db4cc  movaps [rsp], xmm5
00007cc2f47db4d0  movaps [rsp+0x10], xmm6
00007cc2f47db4d5  movaps [rsp+0x20], xmm3
00007cc2f47db4da  lea rdi, [rsp]
00007cc2f47db4de  mov esi, 0x00
00007cc2f47db4e3  mov rax, 0x5990E710A530
00007cc2f47db4ed  call rax
00007cc2f47db4ef  movaps xmm5, [rsp]
00007cc2f47db4f3  add rsp, 0x30
00007cc2f47db4f7  vmovaps xmm0, [rsp]
00007cc2f47db4fc  vmovaps xmm1, [rsp+0x10]
00007cc2f47db502  vmovaps xmm2, [rsp+0x20]
00007cc2f47db508  vmovaps xmm3, [rsp+0x30]
00007cc2f47db50e  vmovaps xmm4, [rsp+0x40]
00007cc2f47db514  vmovaps xmm6, [rsp+0x50]
00007cc2f47db51a  vmovaps xmm7, [rsp+0x60]
00007cc2f47db520  vmovaps xmm8, [rsp+0x70]
00007cc2f47db526  vmovaps xmm9, [rsp+0x80]
00007cc2f47db52f  vmovaps xmm10, [rsp+0x90]
00007cc2f47db538  vmovaps xmm11, [rsp+0xA0]
00007cc2f47db541  vmovaps xmm12, [rsp+0xB0]
00007cc2f47db54a  vmovaps xmm13, [rsp+0xC0]
00007cc2f47db553  vmovaps xmm14, [rsp+0xD0]
00007cc2f47db55c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47db565  add rsp, 0xF0
00007cc2f47db56c  pop r11
00007cc2f47db56e  pop r10
00007cc2f47db570  pop r9
00007cc2f47db572  pop r8
00007cc2f47db574  pop rsi
00007cc2f47db575  pop rdi
00007cc2f47db576  pop rdx
00007cc2f47db577  pop rcx
00007cc2f47db578  pop rax
00007cc2f47db579  add rsp, 0x08
00007cc2f47db57d  jmp 0x00007CC2F47D9167
00007cc2f47db582  sub rsp, 0x08
00007cc2f47db586  push rax
00007cc2f47db587  push rcx
00007cc2f47db588  push rdx
00007cc2f47db589  push rdi
00007cc2f47db58a  push rsi
00007cc2f47db58b  push r8
00007cc2f47db58d  push r9
00007cc2f47db58f  push r10
00007cc2f47db591  push r11
00007cc2f47db593  sub rsp, 0xF0
00007cc2f47db59a  vmovaps [rsp], xmm0
00007cc2f47db59f  vmovaps [rsp+0x10], xmm1
00007cc2f47db5a5  vmovaps [rsp+0x20], xmm2
00007cc2f47db5ab  vmovaps [rsp+0x30], xmm3
00007cc2f47db5b1  vmovaps [rsp+0x40], xmm4
00007cc2f47db5b7  vmovaps [rsp+0x50], xmm5
00007cc2f47db5bd  vmovaps [rsp+0x60], xmm7
00007cc2f47db5c3  vmovaps [rsp+0x70], xmm8
00007cc2f47db5c9  vmovaps [rsp+0x80], xmm9
00007cc2f47db5d2  vmovaps [rsp+0x90], xmm10
00007cc2f47db5db  vmovaps [rsp+0xA0], xmm11
00007cc2f47db5e4  vmovaps [rsp+0xB0], xmm12
00007cc2f47db5ed  vmovaps [rsp+0xC0], xmm13
00007cc2f47db5f6  vmovaps [rsp+0xD0], xmm14
00007cc2f47db5ff  vmovaps [rsp+0xE0], xmm15
00007cc2f47db608  sub rsp, 0x30
00007cc2f47db60c  movaps [rsp], xmm6
00007cc2f47db610  movaps [rsp+0x10], xmm9
00007cc2f47db616  movaps [rsp+0x20], xmm1
00007cc2f47db61b  lea rdi, [rsp]
00007cc2f47db61f  mov esi, 0x00
00007cc2f47db624  mov rax, 0x5990E710A530
00007cc2f47db62e  call rax
00007cc2f47db630  movaps xmm6, [rsp]
00007cc2f47db634  add rsp, 0x30
00007cc2f47db638  vmovaps xmm0, [rsp]
00007cc2f47db63d  vmovaps xmm1, [rsp+0x10]
00007cc2f47db643  vmovaps xmm2, [rsp+0x20]
00007cc2f47db649  vmovaps xmm3, [rsp+0x30]
00007cc2f47db64f  vmovaps xmm4, [rsp+0x40]
00007cc2f47db655  vmovaps xmm5, [rsp+0x50]
00007cc2f47db65b  vmovaps xmm7, [rsp+0x60]
00007cc2f47db661  vmovaps xmm8, [rsp+0x70]
00007cc2f47db667  vmovaps xmm9, [rsp+0x80]
00007cc2f47db670  vmovaps xmm10, [rsp+0x90]
00007cc2f47db679  vmovaps xmm11, [rsp+0xA0]
00007cc2f47db682  vmovaps xmm12, [rsp+0xB0]
00007cc2f47db68b  vmovaps xmm13, [rsp+0xC0]
00007cc2f47db694  vmovaps xmm14, [rsp+0xD0]
00007cc2f47db69d  vmovaps xmm15, [rsp+0xE0]
00007cc2f47db6a6  add rsp, 0xF0
00007cc2f47db6ad  pop r11
00007cc2f47db6af  pop r10
00007cc2f47db6b1  pop r9
00007cc2f47db6b3  pop r8
00007cc2f47db6b5  pop rsi
00007cc2f47db6b6  pop rdi
00007cc2f47db6b7  pop rdx
00007cc2f47db6b8  pop rcx
00007cc2f47db6b9  pop rax
00007cc2f47db6ba  add rsp, 0x08
00007cc2f47db6be  jmp 0x00007CC2F47D918B
00007cc2f47db6c3  sub rsp, 0x08
00007cc2f47db6c7  push rax
00007cc2f47db6c8  push rcx
00007cc2f47db6c9  push rdx
00007cc2f47db6ca  push rdi
00007cc2f47db6cb  push rsi
00007cc2f47db6cc  push r8
00007cc2f47db6ce  push r9
00007cc2f47db6d0  push r10
00007cc2f47db6d2  push r11
00007cc2f47db6d4  sub rsp, 0xF0
00007cc2f47db6db  vmovaps [rsp], xmm0
00007cc2f47db6e0  vmovaps [rsp+0x10], xmm1
00007cc2f47db6e6  vmovaps [rsp+0x20], xmm2
00007cc2f47db6ec  vmovaps [rsp+0x30], xmm3
00007cc2f47db6f2  vmovaps [rsp+0x40], xmm4
00007cc2f47db6f8  vmovaps [rsp+0x50], xmm5
00007cc2f47db6fe  vmovaps [rsp+0x60], xmm6
00007cc2f47db704  vmovaps [rsp+0x70], xmm7
00007cc2f47db70a  vmovaps [rsp+0x80], xmm8
00007cc2f47db713  vmovaps [rsp+0x90], xmm10
00007cc2f47db71c  vmovaps [rsp+0xA0], xmm11
00007cc2f47db725  vmovaps [rsp+0xB0], xmm12
00007cc2f47db72e  vmovaps [rsp+0xC0], xmm13
00007cc2f47db737  vmovaps [rsp+0xD0], xmm14
00007cc2f47db740  vmovaps [rsp+0xE0], xmm15
00007cc2f47db749  sub rsp, 0x30
00007cc2f47db74d  movaps [rsp], xmm9
00007cc2f47db752  movaps [rsp+0x10], xmm3
00007cc2f47db757  movaps [rsp+0x20], xmm1
00007cc2f47db75c  lea rdi, [rsp]
00007cc2f47db760  mov esi, 0x00
00007cc2f47db765  mov rax, 0x5990E710A530
00007cc2f47db76f  call rax
00007cc2f47db771  movaps xmm9, [rsp]
00007cc2f47db776  add rsp, 0x30
00007cc2f47db77a  vmovaps xmm0, [rsp]
00007cc2f47db77f  vmovaps xmm1, [rsp+0x10]
00007cc2f47db785  vmovaps xmm2, [rsp+0x20]
00007cc2f47db78b  vmovaps xmm3, [rsp+0x30]
00007cc2f47db791  vmovaps xmm4, [rsp+0x40]
00007cc2f47db797  vmovaps xmm5, [rsp+0x50]
00007cc2f47db79d  vmovaps xmm6, [rsp+0x60]
00007cc2f47db7a3  vmovaps xmm7, [rsp+0x70]
00007cc2f47db7a9  vmovaps xmm8, [rsp+0x80]
00007cc2f47db7b2  vmovaps xmm10, [rsp+0x90]
00007cc2f47db7bb  vmovaps xmm11, [rsp+0xA0]
00007cc2f47db7c4  vmovaps xmm12, [rsp+0xB0]
00007cc2f47db7cd  vmovaps xmm13, [rsp+0xC0]
00007cc2f47db7d6  vmovaps xmm14, [rsp+0xD0]
00007cc2f47db7df  vmovaps xmm15, [rsp+0xE0]
00007cc2f47db7e8  add rsp, 0xF0
00007cc2f47db7ef  pop r11
00007cc2f47db7f1  pop r10
00007cc2f47db7f3  pop r9
00007cc2f47db7f5  pop r8
00007cc2f47db7f7  pop rsi
00007cc2f47db7f8  pop rdi
00007cc2f47db7f9  pop rdx
00007cc2f47db7fa  pop rcx
00007cc2f47db7fb  pop rax
00007cc2f47db7fc  add rsp, 0x08
00007cc2f47db800  jmp 0x00007CC2F47D91D7
00007cc2f47db805  call 0x00007CC2F46D64F0
00007cc2f47db80a  jmp 0x00007CC2F47D91E4
00007cc2f47db80f  sub rsp, 0x08
00007cc2f47db813  push rax
00007cc2f47db814  push rcx
00007cc2f47db815  push rdx
00007cc2f47db816  push rdi
00007cc2f47db817  push rsi
00007cc2f47db818  push r8
00007cc2f47db81a  push r9
00007cc2f47db81c  push r10
00007cc2f47db81e  push r11
00007cc2f47db820  sub rsp, 0xF0
00007cc2f47db827  vmovaps [rsp], xmm0
00007cc2f47db82c  vmovaps [rsp+0x10], xmm1
00007cc2f47db832  vmovaps [rsp+0x20], xmm2
00007cc2f47db838  vmovaps [rsp+0x30], xmm3
00007cc2f47db83e  vmovaps [rsp+0x40], xmm4
00007cc2f47db844  vmovaps [rsp+0x50], xmm5
00007cc2f47db84a  vmovaps [rsp+0x60], xmm6
00007cc2f47db850  vmovaps [rsp+0x70], xmm7
00007cc2f47db856  vmovaps [rsp+0x80], xmm8
00007cc2f47db85f  vmovaps [rsp+0x90], xmm9
00007cc2f47db868  vmovaps [rsp+0xA0], xmm10
00007cc2f47db871  vmovaps [rsp+0xB0], xmm11
00007cc2f47db87a  vmovaps [rsp+0xC0], xmm12
00007cc2f47db883  vmovaps [rsp+0xD0], xmm13
00007cc2f47db88c  vmovaps [rsp+0xE0], xmm14
00007cc2f47db895  sub rsp, 0x30
00007cc2f47db899  movaps [rsp], xmm15
00007cc2f47db89e  movaps [rsp+0x10], xmm3
00007cc2f47db8a3  movaps [rsp+0x20], xmm7
00007cc2f47db8a8  lea rdi, [rsp]
00007cc2f47db8ac  mov esi, 0x00
00007cc2f47db8b1  mov rax, 0x5990E710A530
00007cc2f47db8bb  call rax
00007cc2f47db8bd  movaps xmm15, [rsp]
00007cc2f47db8c2  add rsp, 0x30
00007cc2f47db8c6  vmovaps xmm0, [rsp]
00007cc2f47db8cb  vmovaps xmm1, [rsp+0x10]
00007cc2f47db8d1  vmovaps xmm2, [rsp+0x20]
00007cc2f47db8d7  vmovaps xmm3, [rsp+0x30]
00007cc2f47db8dd  vmovaps xmm4, [rsp+0x40]
00007cc2f47db8e3  vmovaps xmm5, [rsp+0x50]
00007cc2f47db8e9  vmovaps xmm6, [rsp+0x60]
00007cc2f47db8ef  vmovaps xmm7, [rsp+0x70]
00007cc2f47db8f5  vmovaps xmm8, [rsp+0x80]
00007cc2f47db8fe  vmovaps xmm9, [rsp+0x90]
00007cc2f47db907  vmovaps xmm10, [rsp+0xA0]
00007cc2f47db910  vmovaps xmm11, [rsp+0xB0]
00007cc2f47db919  vmovaps xmm12, [rsp+0xC0]
00007cc2f47db922  vmovaps xmm13, [rsp+0xD0]
00007cc2f47db92b  vmovaps xmm14, [rsp+0xE0]
00007cc2f47db934  add rsp, 0xF0
00007cc2f47db93b  pop r11
00007cc2f47db93d  pop r10
00007cc2f47db93f  pop r9
00007cc2f47db941  pop r8
00007cc2f47db943  pop rsi
00007cc2f47db944  pop rdi
00007cc2f47db945  pop rdx
00007cc2f47db946  pop rcx
00007cc2f47db947  pop rax
00007cc2f47db948  add rsp, 0x08
00007cc2f47db94c  jmp 0x00007CC2F47D9210
00007cc2f47db951  sub rsp, 0x08
00007cc2f47db955  push rax
00007cc2f47db956  push rcx
00007cc2f47db957  push rdx
00007cc2f47db958  push rdi
00007cc2f47db959  push rsi
00007cc2f47db95a  push r8
00007cc2f47db95c  push r9
00007cc2f47db95e  push r10
00007cc2f47db960  push r11
00007cc2f47db962  sub rsp, 0xF0
00007cc2f47db969  vmovaps [rsp], xmm0
00007cc2f47db96e  vmovaps [rsp+0x10], xmm1
00007cc2f47db974  vmovaps [rsp+0x20], xmm2
00007cc2f47db97a  vmovaps [rsp+0x30], xmm4
00007cc2f47db980  vmovaps [rsp+0x40], xmm5
00007cc2f47db986  vmovaps [rsp+0x50], xmm6
00007cc2f47db98c  vmovaps [rsp+0x60], xmm7
00007cc2f47db992  vmovaps [rsp+0x70], xmm8
00007cc2f47db998  vmovaps [rsp+0x80], xmm9
00007cc2f47db9a1  vmovaps [rsp+0x90], xmm10
00007cc2f47db9aa  vmovaps [rsp+0xA0], xmm11
00007cc2f47db9b3  vmovaps [rsp+0xB0], xmm12
00007cc2f47db9bc  vmovaps [rsp+0xC0], xmm13
00007cc2f47db9c5  vmovaps [rsp+0xD0], xmm14
00007cc2f47db9ce  vmovaps [rsp+0xE0], xmm15
00007cc2f47db9d7  sub rsp, 0x30
00007cc2f47db9db  movaps [rsp], xmm3
00007cc2f47db9df  movaps [rsp+0x10], xmm1
00007cc2f47db9e4  movaps [rsp+0x20], xmm15
00007cc2f47db9ea  lea rdi, [rsp]
00007cc2f47db9ee  mov esi, 0x00
00007cc2f47db9f3  mov rax, 0x5990E710A530
00007cc2f47db9fd  call rax
00007cc2f47db9ff  movaps xmm3, [rsp]
00007cc2f47dba03  add rsp, 0x30
00007cc2f47dba07  vmovaps xmm0, [rsp]
00007cc2f47dba0c  vmovaps xmm1, [rsp+0x10]
00007cc2f47dba12  vmovaps xmm2, [rsp+0x20]
00007cc2f47dba18  vmovaps xmm4, [rsp+0x30]
00007cc2f47dba1e  vmovaps xmm5, [rsp+0x40]
00007cc2f47dba24  vmovaps xmm6, [rsp+0x50]
00007cc2f47dba2a  vmovaps xmm7, [rsp+0x60]
00007cc2f47dba30  vmovaps xmm8, [rsp+0x70]
00007cc2f47dba36  vmovaps xmm9, [rsp+0x80]
00007cc2f47dba3f  vmovaps xmm10, [rsp+0x90]
00007cc2f47dba48  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dba51  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dba5a  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dba63  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dba6c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dba75  add rsp, 0xF0
00007cc2f47dba7c  pop r11
00007cc2f47dba7e  pop r10
00007cc2f47dba80  pop r9
00007cc2f47dba82  pop r8
00007cc2f47dba84  pop rsi
00007cc2f47dba85  pop rdi
00007cc2f47dba86  pop rdx
00007cc2f47dba87  pop rcx
00007cc2f47dba88  pop rax
00007cc2f47dba89  add rsp, 0x08
00007cc2f47dba8d  jmp 0x00007CC2F47D929F
00007cc2f47dba92  call 0x00007CC2F46D64F0
00007cc2f47dba97  jmp 0x00007CC2F47D92A9
00007cc2f47dba9c  sub rsp, 0x08
00007cc2f47dbaa0  push rax
00007cc2f47dbaa1  push rcx
00007cc2f47dbaa2  push rdx
00007cc2f47dbaa3  push rdi
00007cc2f47dbaa4  push rsi
00007cc2f47dbaa5  push r8
00007cc2f47dbaa7  push r9
00007cc2f47dbaa9  push r10
00007cc2f47dbaab  push r11
00007cc2f47dbaad  sub rsp, 0xF0
00007cc2f47dbab4  vmovaps [rsp], xmm0
00007cc2f47dbab9  vmovaps [rsp+0x10], xmm1
00007cc2f47dbabf  vmovaps [rsp+0x20], xmm2
00007cc2f47dbac5  vmovaps [rsp+0x30], xmm3
00007cc2f47dbacb  vmovaps [rsp+0x40], xmm4
00007cc2f47dbad1  vmovaps [rsp+0x50], xmm5
00007cc2f47dbad7  vmovaps [rsp+0x60], xmm6
00007cc2f47dbadd  vmovaps [rsp+0x70], xmm7
00007cc2f47dbae3  vmovaps [rsp+0x80], xmm8
00007cc2f47dbaec  vmovaps [rsp+0x90], xmm9
00007cc2f47dbaf5  vmovaps [rsp+0xA0], xmm10
00007cc2f47dbafe  vmovaps [rsp+0xB0], xmm11
00007cc2f47dbb07  vmovaps [rsp+0xC0], xmm12
00007cc2f47dbb10  vmovaps [rsp+0xD0], xmm13
00007cc2f47dbb19  vmovaps [rsp+0xE0], xmm14
00007cc2f47dbb22  sub rsp, 0x30
00007cc2f47dbb26  movaps [rsp], xmm15
00007cc2f47dbb2b  movaps [rsp+0x10], xmm14
00007cc2f47dbb31  movaps [rsp+0x20], xmm4
00007cc2f47dbb36  lea rdi, [rsp]
00007cc2f47dbb3a  mov esi, 0x00
00007cc2f47dbb3f  mov rax, 0x5990E710A530
00007cc2f47dbb49  call rax
00007cc2f47dbb4b  movaps xmm15, [rsp]
00007cc2f47dbb50  add rsp, 0x30
00007cc2f47dbb54  vmovaps xmm0, [rsp]
00007cc2f47dbb59  vmovaps xmm1, [rsp+0x10]
00007cc2f47dbb5f  vmovaps xmm2, [rsp+0x20]
00007cc2f47dbb65  vmovaps xmm3, [rsp+0x30]
00007cc2f47dbb6b  vmovaps xmm4, [rsp+0x40]
00007cc2f47dbb71  vmovaps xmm5, [rsp+0x50]
00007cc2f47dbb77  vmovaps xmm6, [rsp+0x60]
00007cc2f47dbb7d  vmovaps xmm7, [rsp+0x70]
00007cc2f47dbb83  vmovaps xmm8, [rsp+0x80]
00007cc2f47dbb8c  vmovaps xmm9, [rsp+0x90]
00007cc2f47dbb95  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dbb9e  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dbba7  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dbbb0  vmovaps xmm13, [rsp+0xD0]
00007cc2f47dbbb9  vmovaps xmm14, [rsp+0xE0]
00007cc2f47dbbc2  add rsp, 0xF0
00007cc2f47dbbc9  pop r11
00007cc2f47dbbcb  pop r10
00007cc2f47dbbcd  pop r9
00007cc2f47dbbcf  pop r8
00007cc2f47dbbd1  pop rsi
00007cc2f47dbbd2  pop rdi
00007cc2f47dbbd3  pop rdx
00007cc2f47dbbd4  pop rcx
00007cc2f47dbbd5  pop rax
00007cc2f47dbbd6  add rsp, 0x08
00007cc2f47dbbda  jmp 0x00007CC2F47D92D7
00007cc2f47dbbdf  sub rsp, 0x08
00007cc2f47dbbe3  push rax
00007cc2f47dbbe4  push rcx
00007cc2f47dbbe5  push rdx
00007cc2f47dbbe6  push rdi
00007cc2f47dbbe7  push rsi
00007cc2f47dbbe8  push r8
00007cc2f47dbbea  push r9
00007cc2f47dbbec  push r10
00007cc2f47dbbee  push r11
00007cc2f47dbbf0  sub rsp, 0xF0
00007cc2f47dbbf7  vmovaps [rsp], xmm0
00007cc2f47dbbfc  vmovaps [rsp+0x10], xmm1
00007cc2f47dbc02  vmovaps [rsp+0x20], xmm2
00007cc2f47dbc08  vmovaps [rsp+0x30], xmm3
00007cc2f47dbc0e  vmovaps [rsp+0x40], xmm4
00007cc2f47dbc14  vmovaps [rsp+0x50], xmm5
00007cc2f47dbc1a  vmovaps [rsp+0x60], xmm6
00007cc2f47dbc20  vmovaps [rsp+0x70], xmm7
00007cc2f47dbc26  vmovaps [rsp+0x80], xmm8
00007cc2f47dbc2f  vmovaps [rsp+0x90], xmm9
00007cc2f47dbc38  vmovaps [rsp+0xA0], xmm10
00007cc2f47dbc41  vmovaps [rsp+0xB0], xmm11
00007cc2f47dbc4a  vmovaps [rsp+0xC0], xmm12
00007cc2f47dbc53  vmovaps [rsp+0xD0], xmm13
00007cc2f47dbc5c  vmovaps [rsp+0xE0], xmm15
00007cc2f47dbc65  sub rsp, 0x30
00007cc2f47dbc69  movaps [rsp], xmm14
00007cc2f47dbc6e  movaps [rsp+0x10], xmm2
00007cc2f47dbc73  movaps [rsp+0x20], xmm1
00007cc2f47dbc78  lea rdi, [rsp]
00007cc2f47dbc7c  mov esi, 0x00
00007cc2f47dbc81  mov rax, 0x5990E710A530
00007cc2f47dbc8b  call rax
00007cc2f47dbc8d  movaps xmm14, [rsp]
00007cc2f47dbc92  add rsp, 0x30
00007cc2f47dbc96  vmovaps xmm0, [rsp]
00007cc2f47dbc9b  vmovaps xmm1, [rsp+0x10]
00007cc2f47dbca1  vmovaps xmm2, [rsp+0x20]
00007cc2f47dbca7  vmovaps xmm3, [rsp+0x30]
00007cc2f47dbcad  vmovaps xmm4, [rsp+0x40]
00007cc2f47dbcb3  vmovaps xmm5, [rsp+0x50]
00007cc2f47dbcb9  vmovaps xmm6, [rsp+0x60]
00007cc2f47dbcbf  vmovaps xmm7, [rsp+0x70]
00007cc2f47dbcc5  vmovaps xmm8, [rsp+0x80]
00007cc2f47dbcce  vmovaps xmm9, [rsp+0x90]
00007cc2f47dbcd7  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dbce0  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dbce9  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dbcf2  vmovaps xmm13, [rsp+0xD0]
00007cc2f47dbcfb  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dbd04  add rsp, 0xF0
00007cc2f47dbd0b  pop r11
00007cc2f47dbd0d  pop r10
00007cc2f47dbd0f  pop r9
00007cc2f47dbd11  pop r8
00007cc2f47dbd13  pop rsi
00007cc2f47dbd14  pop rdi
00007cc2f47dbd15  pop rdx
00007cc2f47dbd16  pop rcx
00007cc2f47dbd17  pop rax
00007cc2f47dbd18  add rsp, 0x08
00007cc2f47dbd1c  jmp 0x00007CC2F47D92FD
00007cc2f47dbd21  sub rsp, 0x08
00007cc2f47dbd25  push rax
00007cc2f47dbd26  push rcx
00007cc2f47dbd27  push rdx
00007cc2f47dbd28  push rdi
00007cc2f47dbd29  push rsi
00007cc2f47dbd2a  push r8
00007cc2f47dbd2c  push r9
00007cc2f47dbd2e  push r10
00007cc2f47dbd30  push r11
00007cc2f47dbd32  sub rsp, 0xF0
00007cc2f47dbd39  vmovaps [rsp], xmm0
00007cc2f47dbd3e  vmovaps [rsp+0x10], xmm2
00007cc2f47dbd44  vmovaps [rsp+0x20], xmm3
00007cc2f47dbd4a  vmovaps [rsp+0x30], xmm4
00007cc2f47dbd50  vmovaps [rsp+0x40], xmm5
00007cc2f47dbd56  vmovaps [rsp+0x50], xmm6
00007cc2f47dbd5c  vmovaps [rsp+0x60], xmm7
00007cc2f47dbd62  vmovaps [rsp+0x70], xmm8
00007cc2f47dbd68  vmovaps [rsp+0x80], xmm9
00007cc2f47dbd71  vmovaps [rsp+0x90], xmm10
00007cc2f47dbd7a  vmovaps [rsp+0xA0], xmm11
00007cc2f47dbd83  vmovaps [rsp+0xB0], xmm12
00007cc2f47dbd8c  vmovaps [rsp+0xC0], xmm13
00007cc2f47dbd95  vmovaps [rsp+0xD0], xmm14
00007cc2f47dbd9e  vmovaps [rsp+0xE0], xmm15
00007cc2f47dbda7  sub rsp, 0x30
00007cc2f47dbdab  movaps [rsp], xmm1
00007cc2f47dbdaf  movaps [rsp+0x10], xmm4
00007cc2f47dbdb4  movaps [rsp+0x20], xmm9
00007cc2f47dbdba  lea rdi, [rsp]
00007cc2f47dbdbe  mov esi, 0x00
00007cc2f47dbdc3  mov rax, 0x5990E710A530
00007cc2f47dbdcd  call rax
00007cc2f47dbdcf  movaps xmm1, [rsp]
00007cc2f47dbdd3  add rsp, 0x30
00007cc2f47dbdd7  vmovaps xmm0, [rsp]
00007cc2f47dbddc  vmovaps xmm2, [rsp+0x10]
00007cc2f47dbde2  vmovaps xmm3, [rsp+0x20]
00007cc2f47dbde8  vmovaps xmm4, [rsp+0x30]
00007cc2f47dbdee  vmovaps xmm5, [rsp+0x40]
00007cc2f47dbdf4  vmovaps xmm6, [rsp+0x50]
00007cc2f47dbdfa  vmovaps xmm7, [rsp+0x60]
00007cc2f47dbe00  vmovaps xmm8, [rsp+0x70]
00007cc2f47dbe06  vmovaps xmm9, [rsp+0x80]
00007cc2f47dbe0f  vmovaps xmm10, [rsp+0x90]
00007cc2f47dbe18  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dbe21  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dbe2a  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dbe33  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dbe3c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dbe45  add rsp, 0xF0
00007cc2f47dbe4c  pop r11
00007cc2f47dbe4e  pop r10
00007cc2f47dbe50  pop r9
00007cc2f47dbe52  pop r8
00007cc2f47dbe54  pop rsi
00007cc2f47dbe55  pop rdi
00007cc2f47dbe56  pop rdx
00007cc2f47dbe57  pop rcx
00007cc2f47dbe58  pop rax
00007cc2f47dbe59  add rsp, 0x08
00007cc2f47dbe5d  jmp 0x00007CC2F47D931B
00007cc2f47dbe62  sub rsp, 0x08
00007cc2f47dbe66  push rax
00007cc2f47dbe67  push rcx
00007cc2f47dbe68  push rdx
00007cc2f47dbe69  push rdi
00007cc2f47dbe6a  push rsi
00007cc2f47dbe6b  push r8
00007cc2f47dbe6d  push r9
00007cc2f47dbe6f  push r10
00007cc2f47dbe71  push r11
00007cc2f47dbe73  sub rsp, 0xF0
00007cc2f47dbe7a  vmovaps [rsp], xmm0
00007cc2f47dbe7f  vmovaps [rsp+0x10], xmm1
00007cc2f47dbe85  vmovaps [rsp+0x20], xmm2
00007cc2f47dbe8b  vmovaps [rsp+0x30], xmm3
00007cc2f47dbe91  vmovaps [rsp+0x40], xmm5
00007cc2f47dbe97  vmovaps [rsp+0x50], xmm6
00007cc2f47dbe9d  vmovaps [rsp+0x60], xmm7
00007cc2f47dbea3  vmovaps [rsp+0x70], xmm8
00007cc2f47dbea9  vmovaps [rsp+0x80], xmm9
00007cc2f47dbeb2  vmovaps [rsp+0x90], xmm10
00007cc2f47dbebb  vmovaps [rsp+0xA0], xmm11
00007cc2f47dbec4  vmovaps [rsp+0xB0], xmm12
00007cc2f47dbecd  vmovaps [rsp+0xC0], xmm13
00007cc2f47dbed6  vmovaps [rsp+0xD0], xmm14
00007cc2f47dbedf  vmovaps [rsp+0xE0], xmm15
00007cc2f47dbee8  sub rsp, 0x30
00007cc2f47dbeec  movaps [rsp], xmm4
00007cc2f47dbef0  movaps [rsp+0x10], xmm2
00007cc2f47dbef5  movaps [rsp+0x20], xmm9
00007cc2f47dbefb  lea rdi, [rsp]
00007cc2f47dbeff  mov esi, 0x00
00007cc2f47dbf04  mov rax, 0x5990E710A530
00007cc2f47dbf0e  call rax
00007cc2f47dbf10  movaps xmm4, [rsp]
00007cc2f47dbf14  add rsp, 0x30
00007cc2f47dbf18  vmovaps xmm0, [rsp]
00007cc2f47dbf1d  vmovaps xmm1, [rsp+0x10]
00007cc2f47dbf23  vmovaps xmm2, [rsp+0x20]
00007cc2f47dbf29  vmovaps xmm3, [rsp+0x30]
00007cc2f47dbf2f  vmovaps xmm5, [rsp+0x40]
00007cc2f47dbf35  vmovaps xmm6, [rsp+0x50]
00007cc2f47dbf3b  vmovaps xmm7, [rsp+0x60]
00007cc2f47dbf41  vmovaps xmm8, [rsp+0x70]
00007cc2f47dbf47  vmovaps xmm9, [rsp+0x80]
00007cc2f47dbf50  vmovaps xmm10, [rsp+0x90]
00007cc2f47dbf59  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dbf62  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dbf6b  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dbf74  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dbf7d  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dbf86  add rsp, 0xF0
00007cc2f47dbf8d  pop r11
00007cc2f47dbf8f  pop r10
00007cc2f47dbf91  pop r9
00007cc2f47dbf93  pop r8
00007cc2f47dbf95  pop rsi
00007cc2f47dbf96  pop rdi
00007cc2f47dbf97  pop rdx
00007cc2f47dbf98  pop rcx
00007cc2f47dbf99  pop rax
00007cc2f47dbf9a  add rsp, 0x08
00007cc2f47dbf9e  jmp 0x00007CC2F47D934B
00007cc2f47dbfa3  sub rsp, 0x08
00007cc2f47dbfa7  push rax
00007cc2f47dbfa8  push rcx
00007cc2f47dbfa9  push rdx
00007cc2f47dbfaa  push rdi
00007cc2f47dbfab  push rsi
00007cc2f47dbfac  push r8
00007cc2f47dbfae  push r9
00007cc2f47dbfb0  push r10
00007cc2f47dbfb2  push r11
00007cc2f47dbfb4  sub rsp, 0xF0
00007cc2f47dbfbb  vmovaps [rsp], xmm0
00007cc2f47dbfc0  vmovaps [rsp+0x10], xmm1
00007cc2f47dbfc6  vmovaps [rsp+0x20], xmm2
00007cc2f47dbfcc  vmovaps [rsp+0x30], xmm3
00007cc2f47dbfd2  vmovaps [rsp+0x40], xmm4
00007cc2f47dbfd8  vmovaps [rsp+0x50], xmm5
00007cc2f47dbfde  vmovaps [rsp+0x60], xmm6
00007cc2f47dbfe4  vmovaps [rsp+0x70], xmm7
00007cc2f47dbfea  vmovaps [rsp+0x80], xmm8
00007cc2f47dbff3  vmovaps [rsp+0x90], xmm10
00007cc2f47dbffc  vmovaps [rsp+0xA0], xmm11
00007cc2f47dc005  vmovaps [rsp+0xB0], xmm12
00007cc2f47dc00e  vmovaps [rsp+0xC0], xmm13
00007cc2f47dc017  vmovaps [rsp+0xD0], xmm14
00007cc2f47dc020  vmovaps [rsp+0xE0], xmm15
00007cc2f47dc029  sub rsp, 0x30
00007cc2f47dc02d  movaps [rsp], xmm9
00007cc2f47dc032  movaps [rsp+0x10], xmm2
00007cc2f47dc037  movaps [rsp+0x20], xmm1
00007cc2f47dc03c  lea rdi, [rsp]
00007cc2f47dc040  mov esi, 0x00
00007cc2f47dc045  mov rax, 0x5990E710A530
00007cc2f47dc04f  call rax
00007cc2f47dc051  movaps xmm9, [rsp]
00007cc2f47dc056  add rsp, 0x30
00007cc2f47dc05a  vmovaps xmm0, [rsp]
00007cc2f47dc05f  vmovaps xmm1, [rsp+0x10]
00007cc2f47dc065  vmovaps xmm2, [rsp+0x20]
00007cc2f47dc06b  vmovaps xmm3, [rsp+0x30]
00007cc2f47dc071  vmovaps xmm4, [rsp+0x40]
00007cc2f47dc077  vmovaps xmm5, [rsp+0x50]
00007cc2f47dc07d  vmovaps xmm6, [rsp+0x60]
00007cc2f47dc083  vmovaps xmm7, [rsp+0x70]
00007cc2f47dc089  vmovaps xmm8, [rsp+0x80]
00007cc2f47dc092  vmovaps xmm10, [rsp+0x90]
00007cc2f47dc09b  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dc0a4  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dc0ad  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dc0b6  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dc0bf  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dc0c8  add rsp, 0xF0
00007cc2f47dc0cf  pop r11
00007cc2f47dc0d1  pop r10
00007cc2f47dc0d3  pop r9
00007cc2f47dc0d5  pop r8
00007cc2f47dc0d7  pop rsi
00007cc2f47dc0d8  pop rdi
00007cc2f47dc0d9  pop rdx
00007cc2f47dc0da  pop rcx
00007cc2f47dc0db  pop rax
00007cc2f47dc0dc  add rsp, 0x08
00007cc2f47dc0e0  jmp 0x00007CC2F47D9381
00007cc2f47dc0e5  sub rsp, 0x08
00007cc2f47dc0e9  push rax
00007cc2f47dc0ea  push rcx
00007cc2f47dc0eb  push rdx
00007cc2f47dc0ec  push rdi
00007cc2f47dc0ed  push rsi
00007cc2f47dc0ee  push r8
00007cc2f47dc0f0  push r9
00007cc2f47dc0f2  push r10
00007cc2f47dc0f4  push r11
00007cc2f47dc0f6  sub rsp, 0xF0
00007cc2f47dc0fd  vmovaps [rsp], xmm0
00007cc2f47dc102  vmovaps [rsp+0x10], xmm2
00007cc2f47dc108  vmovaps [rsp+0x20], xmm3
00007cc2f47dc10e  vmovaps [rsp+0x30], xmm4
00007cc2f47dc114  vmovaps [rsp+0x40], xmm5
00007cc2f47dc11a  vmovaps [rsp+0x50], xmm6
00007cc2f47dc120  vmovaps [rsp+0x60], xmm7
00007cc2f47dc126  vmovaps [rsp+0x70], xmm8
00007cc2f47dc12c  vmovaps [rsp+0x80], xmm9
00007cc2f47dc135  vmovaps [rsp+0x90], xmm10
00007cc2f47dc13e  vmovaps [rsp+0xA0], xmm11
00007cc2f47dc147  vmovaps [rsp+0xB0], xmm12
00007cc2f47dc150  vmovaps [rsp+0xC0], xmm13
00007cc2f47dc159  vmovaps [rsp+0xD0], xmm14
00007cc2f47dc162  vmovaps [rsp+0xE0], xmm15
00007cc2f47dc16b  sub rsp, 0x30
00007cc2f47dc16f  movaps [rsp], xmm1
00007cc2f47dc173  movaps [rsp+0x10], xmm15
00007cc2f47dc179  movaps [rsp+0x20], xmm6
00007cc2f47dc17e  lea rdi, [rsp]
00007cc2f47dc182  mov esi, 0x00
00007cc2f47dc187  mov rax, 0x5990E710A530
00007cc2f47dc191  call rax
00007cc2f47dc193  movaps xmm1, [rsp]
00007cc2f47dc197  add rsp, 0x30
00007cc2f47dc19b  vmovaps xmm0, [rsp]
00007cc2f47dc1a0  vmovaps xmm2, [rsp+0x10]
00007cc2f47dc1a6  vmovaps xmm3, [rsp+0x20]
00007cc2f47dc1ac  vmovaps xmm4, [rsp+0x30]
00007cc2f47dc1b2  vmovaps xmm5, [rsp+0x40]
00007cc2f47dc1b8  vmovaps xmm6, [rsp+0x50]
00007cc2f47dc1be  vmovaps xmm7, [rsp+0x60]
00007cc2f47dc1c4  vmovaps xmm8, [rsp+0x70]
00007cc2f47dc1ca  vmovaps xmm9, [rsp+0x80]
00007cc2f47dc1d3  vmovaps xmm10, [rsp+0x90]
00007cc2f47dc1dc  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dc1e5  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dc1ee  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dc1f7  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dc200  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dc209  add rsp, 0xF0
00007cc2f47dc210  pop r11
00007cc2f47dc212  pop r10
00007cc2f47dc214  pop r9
00007cc2f47dc216  pop r8
00007cc2f47dc218  pop rsi
00007cc2f47dc219  pop rdi
00007cc2f47dc21a  pop rdx
00007cc2f47dc21b  pop rcx
00007cc2f47dc21c  pop rax
00007cc2f47dc21d  add rsp, 0x08
00007cc2f47dc221  jmp 0x00007CC2F47D93A2
00007cc2f47dc226  sub rsp, 0x08
00007cc2f47dc22a  push rax
00007cc2f47dc22b  push rcx
00007cc2f47dc22c  push rdx
00007cc2f47dc22d  push rdi
00007cc2f47dc22e  push rsi
00007cc2f47dc22f  push r8
00007cc2f47dc231  push r9
00007cc2f47dc233  push r10
00007cc2f47dc235  push r11
00007cc2f47dc237  sub rsp, 0xF0
00007cc2f47dc23e  vmovaps [rsp], xmm0
00007cc2f47dc243  vmovaps [rsp+0x10], xmm1
00007cc2f47dc249  vmovaps [rsp+0x20], xmm2
00007cc2f47dc24f  vmovaps [rsp+0x30], xmm3
00007cc2f47dc255  vmovaps [rsp+0x40], xmm4
00007cc2f47dc25b  vmovaps [rsp+0x50], xmm5
00007cc2f47dc261  vmovaps [rsp+0x60], xmm6
00007cc2f47dc267  vmovaps [rsp+0x70], xmm7
00007cc2f47dc26d  vmovaps [rsp+0x80], xmm8
00007cc2f47dc276  vmovaps [rsp+0x90], xmm9
00007cc2f47dc27f  vmovaps [rsp+0xA0], xmm10
00007cc2f47dc288  vmovaps [rsp+0xB0], xmm11
00007cc2f47dc291  vmovaps [rsp+0xC0], xmm12
00007cc2f47dc29a  vmovaps [rsp+0xD0], xmm13
00007cc2f47dc2a3  vmovaps [rsp+0xE0], xmm14
00007cc2f47dc2ac  sub rsp, 0x30
00007cc2f47dc2b0  movaps [rsp], xmm15
00007cc2f47dc2b5  movaps [rsp+0x10], xmm5
00007cc2f47dc2ba  movaps [rsp+0x20], xmm3
00007cc2f47dc2bf  lea rdi, [rsp]
00007cc2f47dc2c3  mov esi, 0x00
00007cc2f47dc2c8  mov rax, 0x5990E710A530
00007cc2f47dc2d2  call rax
00007cc2f47dc2d4  movaps xmm15, [rsp]
00007cc2f47dc2d9  add rsp, 0x30
00007cc2f47dc2dd  vmovaps xmm0, [rsp]
00007cc2f47dc2e2  vmovaps xmm1, [rsp+0x10]
00007cc2f47dc2e8  vmovaps xmm2, [rsp+0x20]
00007cc2f47dc2ee  vmovaps xmm3, [rsp+0x30]
00007cc2f47dc2f4  vmovaps xmm4, [rsp+0x40]
00007cc2f47dc2fa  vmovaps xmm5, [rsp+0x50]
00007cc2f47dc300  vmovaps xmm6, [rsp+0x60]
00007cc2f47dc306  vmovaps xmm7, [rsp+0x70]
00007cc2f47dc30c  vmovaps xmm8, [rsp+0x80]
00007cc2f47dc315  vmovaps xmm9, [rsp+0x90]
00007cc2f47dc31e  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dc327  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dc330  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dc339  vmovaps xmm13, [rsp+0xD0]
00007cc2f47dc342  vmovaps xmm14, [rsp+0xE0]
00007cc2f47dc34b  add rsp, 0xF0
00007cc2f47dc352  pop r11
00007cc2f47dc354  pop r10
00007cc2f47dc356  pop r9
00007cc2f47dc358  pop r8
00007cc2f47dc35a  pop rsi
00007cc2f47dc35b  pop rdi
00007cc2f47dc35c  pop rdx
00007cc2f47dc35d  pop rcx
00007cc2f47dc35e  pop rax
00007cc2f47dc35f  add rsp, 0x08
00007cc2f47dc363  jmp 0x00007CC2F47D93BC
00007cc2f47dc368  sub rsp, 0x08
00007cc2f47dc36c  push rax
00007cc2f47dc36d  push rcx
00007cc2f47dc36e  push rdx
00007cc2f47dc36f  push rdi
00007cc2f47dc370  push rsi
00007cc2f47dc371  push r8
00007cc2f47dc373  push r9
00007cc2f47dc375  push r10
00007cc2f47dc377  push r11
00007cc2f47dc379  sub rsp, 0xF0
00007cc2f47dc380  vmovaps [rsp], xmm0
00007cc2f47dc385  vmovaps [rsp+0x10], xmm1
00007cc2f47dc38b  vmovaps [rsp+0x20], xmm2
00007cc2f47dc391  vmovaps [rsp+0x30], xmm3
00007cc2f47dc397  vmovaps [rsp+0x40], xmm4
00007cc2f47dc39d  vmovaps [rsp+0x50], xmm6
00007cc2f47dc3a3  vmovaps [rsp+0x60], xmm7
00007cc2f47dc3a9  vmovaps [rsp+0x70], xmm8
00007cc2f47dc3af  vmovaps [rsp+0x80], xmm9
00007cc2f47dc3b8  vmovaps [rsp+0x90], xmm10
00007cc2f47dc3c1  vmovaps [rsp+0xA0], xmm11
00007cc2f47dc3ca  vmovaps [rsp+0xB0], xmm12
00007cc2f47dc3d3  vmovaps [rsp+0xC0], xmm13
00007cc2f47dc3dc  vmovaps [rsp+0xD0], xmm14
00007cc2f47dc3e5  vmovaps [rsp+0xE0], xmm15
00007cc2f47dc3ee  sub rsp, 0x30
00007cc2f47dc3f2  movaps [rsp], xmm5
00007cc2f47dc3f6  movaps [rsp+0x10], xmm8
00007cc2f47dc3fc  movaps [rsp+0x20], xmm6
00007cc2f47dc401  lea rdi, [rsp]
00007cc2f47dc405  mov esi, 0x00
00007cc2f47dc40a  mov rax, 0x5990E710A530
00007cc2f47dc414  call rax
00007cc2f47dc416  movaps xmm5, [rsp]
00007cc2f47dc41a  add rsp, 0x30
00007cc2f47dc41e  vmovaps xmm0, [rsp]
00007cc2f47dc423  vmovaps xmm1, [rsp+0x10]
00007cc2f47dc429  vmovaps xmm2, [rsp+0x20]
00007cc2f47dc42f  vmovaps xmm3, [rsp+0x30]
00007cc2f47dc435  vmovaps xmm4, [rsp+0x40]
00007cc2f47dc43b  vmovaps xmm6, [rsp+0x50]
00007cc2f47dc441  vmovaps xmm7, [rsp+0x60]
00007cc2f47dc447  vmovaps xmm8, [rsp+0x70]
00007cc2f47dc44d  vmovaps xmm9, [rsp+0x80]
00007cc2f47dc456  vmovaps xmm10, [rsp+0x90]
00007cc2f47dc45f  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dc468  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dc471  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dc47a  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dc483  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dc48c  add rsp, 0xF0
00007cc2f47dc493  pop r11
00007cc2f47dc495  pop r10
00007cc2f47dc497  pop r9
00007cc2f47dc499  pop r8
00007cc2f47dc49b  pop rsi
00007cc2f47dc49c  pop rdi
00007cc2f47dc49d  pop rdx
00007cc2f47dc49e  pop rcx
00007cc2f47dc49f  pop rax
00007cc2f47dc4a0  add rsp, 0x08
00007cc2f47dc4a4  jmp 0x00007CC2F47D93E0
00007cc2f47dc4a9  sub rsp, 0x08
00007cc2f47dc4ad  push rax
00007cc2f47dc4ae  push rcx
00007cc2f47dc4af  push rdx
00007cc2f47dc4b0  push rdi
00007cc2f47dc4b1  push rsi
00007cc2f47dc4b2  push r8
00007cc2f47dc4b4  push r9
00007cc2f47dc4b6  push r10
00007cc2f47dc4b8  push r11
00007cc2f47dc4ba  sub rsp, 0xF0
00007cc2f47dc4c1  vmovaps [rsp], xmm0
00007cc2f47dc4c6  vmovaps [rsp+0x10], xmm1
00007cc2f47dc4cc  vmovaps [rsp+0x20], xmm2
00007cc2f47dc4d2  vmovaps [rsp+0x30], xmm3
00007cc2f47dc4d8  vmovaps [rsp+0x40], xmm4
00007cc2f47dc4de  vmovaps [rsp+0x50], xmm5
00007cc2f47dc4e4  vmovaps [rsp+0x60], xmm7
00007cc2f47dc4ea  vmovaps [rsp+0x70], xmm8
00007cc2f47dc4f0  vmovaps [rsp+0x80], xmm9
00007cc2f47dc4f9  vmovaps [rsp+0x90], xmm10
00007cc2f47dc502  vmovaps [rsp+0xA0], xmm11
00007cc2f47dc50b  vmovaps [rsp+0xB0], xmm12
00007cc2f47dc514  vmovaps [rsp+0xC0], xmm13
00007cc2f47dc51d  vmovaps [rsp+0xD0], xmm14
00007cc2f47dc526  vmovaps [rsp+0xE0], xmm15
00007cc2f47dc52f  sub rsp, 0x30
00007cc2f47dc533  movaps [rsp], xmm6
00007cc2f47dc537  movaps [rsp+0x10], xmm10
00007cc2f47dc53d  movaps [rsp+0x20], xmm8
00007cc2f47dc543  lea rdi, [rsp]
00007cc2f47dc547  mov esi, 0x00
00007cc2f47dc54c  mov rax, 0x5990E710A530
00007cc2f47dc556  call rax
00007cc2f47dc558  movaps xmm6, [rsp]
00007cc2f47dc55c  add rsp, 0x30
00007cc2f47dc560  vmovaps xmm0, [rsp]
00007cc2f47dc565  vmovaps xmm1, [rsp+0x10]
00007cc2f47dc56b  vmovaps xmm2, [rsp+0x20]
00007cc2f47dc571  vmovaps xmm3, [rsp+0x30]
00007cc2f47dc577  vmovaps xmm4, [rsp+0x40]
00007cc2f47dc57d  vmovaps xmm5, [rsp+0x50]
00007cc2f47dc583  vmovaps xmm7, [rsp+0x60]
00007cc2f47dc589  vmovaps xmm8, [rsp+0x70]
00007cc2f47dc58f  vmovaps xmm9, [rsp+0x80]
00007cc2f47dc598  vmovaps xmm10, [rsp+0x90]
00007cc2f47dc5a1  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dc5aa  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dc5b3  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dc5bc  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dc5c5  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dc5ce  add rsp, 0xF0
00007cc2f47dc5d5  pop r11
00007cc2f47dc5d7  pop r10
00007cc2f47dc5d9  pop r9
00007cc2f47dc5db  pop r8
00007cc2f47dc5dd  pop rsi
00007cc2f47dc5de  pop rdi
00007cc2f47dc5df  pop rdx
00007cc2f47dc5e0  pop rcx
00007cc2f47dc5e1  pop rax
00007cc2f47dc5e2  add rsp, 0x08
00007cc2f47dc5e6  jmp 0x00007CC2F47D9405
00007cc2f47dc5eb  sub rsp, 0x08
00007cc2f47dc5ef  push rax
00007cc2f47dc5f0  push rcx
00007cc2f47dc5f1  push rdx
00007cc2f47dc5f2  push rdi
00007cc2f47dc5f3  push rsi
00007cc2f47dc5f4  push r8
00007cc2f47dc5f6  push r9
00007cc2f47dc5f8  push r10
00007cc2f47dc5fa  push r11
00007cc2f47dc5fc  sub rsp, 0xF0
00007cc2f47dc603  vmovaps [rsp], xmm0
00007cc2f47dc608  vmovaps [rsp+0x10], xmm1
00007cc2f47dc60e  vmovaps [rsp+0x20], xmm2
00007cc2f47dc614  vmovaps [rsp+0x30], xmm3
00007cc2f47dc61a  vmovaps [rsp+0x40], xmm4
00007cc2f47dc620  vmovaps [rsp+0x50], xmm5
00007cc2f47dc626  vmovaps [rsp+0x60], xmm6
00007cc2f47dc62c  vmovaps [rsp+0x70], xmm7
00007cc2f47dc632  vmovaps [rsp+0x80], xmm8
00007cc2f47dc63b  vmovaps [rsp+0x90], xmm9
00007cc2f47dc644  vmovaps [rsp+0xA0], xmm11
00007cc2f47dc64d  vmovaps [rsp+0xB0], xmm12
00007cc2f47dc656  vmovaps [rsp+0xC0], xmm13
00007cc2f47dc65f  vmovaps [rsp+0xD0], xmm14
00007cc2f47dc668  vmovaps [rsp+0xE0], xmm15
00007cc2f47dc671  sub rsp, 0x30
00007cc2f47dc675  movaps [rsp], xmm10
00007cc2f47dc67a  movaps [rsp+0x10], xmm8
00007cc2f47dc680  movaps [rsp+0x20], xmm14
00007cc2f47dc686  lea rdi, [rsp]
00007cc2f47dc68a  mov esi, 0x00
00007cc2f47dc68f  mov rax, 0x5990E710A530
00007cc2f47dc699  call rax
00007cc2f47dc69b  movaps xmm10, [rsp]
00007cc2f47dc6a0  add rsp, 0x30
00007cc2f47dc6a4  vmovaps xmm0, [rsp]
00007cc2f47dc6a9  vmovaps xmm1, [rsp+0x10]
00007cc2f47dc6af  vmovaps xmm2, [rsp+0x20]
00007cc2f47dc6b5  vmovaps xmm3, [rsp+0x30]
00007cc2f47dc6bb  vmovaps xmm4, [rsp+0x40]
00007cc2f47dc6c1  vmovaps xmm5, [rsp+0x50]
00007cc2f47dc6c7  vmovaps xmm6, [rsp+0x60]
00007cc2f47dc6cd  vmovaps xmm7, [rsp+0x70]
00007cc2f47dc6d3  vmovaps xmm8, [rsp+0x80]
00007cc2f47dc6dc  vmovaps xmm9, [rsp+0x90]
00007cc2f47dc6e5  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dc6ee  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dc6f7  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dc700  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dc709  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dc712  add rsp, 0xF0
00007cc2f47dc719  pop r11
00007cc2f47dc71b  pop r10
00007cc2f47dc71d  pop r9
00007cc2f47dc71f  pop r8
00007cc2f47dc721  pop rsi
00007cc2f47dc722  pop rdi
00007cc2f47dc723  pop rdx
00007cc2f47dc724  pop rcx
00007cc2f47dc725  pop rax
00007cc2f47dc726  add rsp, 0x08
00007cc2f47dc72a  jmp 0x00007CC2F47D9425
00007cc2f47dc72f  sub rsp, 0x08
00007cc2f47dc733  push rax
00007cc2f47dc734  push rcx
00007cc2f47dc735  push rdx
00007cc2f47dc736  push rdi
00007cc2f47dc737  push rsi
00007cc2f47dc738  push r8
00007cc2f47dc73a  push r9
00007cc2f47dc73c  push r10
00007cc2f47dc73e  push r11
00007cc2f47dc740  sub rsp, 0xF0
00007cc2f47dc747  vmovaps [rsp], xmm0
00007cc2f47dc74c  vmovaps [rsp+0x10], xmm1
00007cc2f47dc752  vmovaps [rsp+0x20], xmm2
00007cc2f47dc758  vmovaps [rsp+0x30], xmm3
00007cc2f47dc75e  vmovaps [rsp+0x40], xmm4
00007cc2f47dc764  vmovaps [rsp+0x50], xmm5
00007cc2f47dc76a  vmovaps [rsp+0x60], xmm6
00007cc2f47dc770  vmovaps [rsp+0x70], xmm7
00007cc2f47dc776  vmovaps [rsp+0x80], xmm8
00007cc2f47dc77f  vmovaps [rsp+0x90], xmm9
00007cc2f47dc788  vmovaps [rsp+0xA0], xmm10
00007cc2f47dc791  vmovaps [rsp+0xB0], xmm11
00007cc2f47dc79a  vmovaps [rsp+0xC0], xmm12
00007cc2f47dc7a3  vmovaps [rsp+0xD0], xmm13
00007cc2f47dc7ac  vmovaps [rsp+0xE0], xmm15
00007cc2f47dc7b5  sub rsp, 0x30
00007cc2f47dc7b9  movaps [rsp], xmm14
00007cc2f47dc7be  movaps [rsp+0x10], xmm8
00007cc2f47dc7c4  movaps [rsp+0x20], xmm4
00007cc2f47dc7c9  lea rdi, [rsp]
00007cc2f47dc7cd  mov esi, 0x00
00007cc2f47dc7d2  mov rax, 0x5990E710A530
00007cc2f47dc7dc  call rax
00007cc2f47dc7de  movaps xmm14, [rsp]
00007cc2f47dc7e3  add rsp, 0x30
00007cc2f47dc7e7  vmovaps xmm0, [rsp]
00007cc2f47dc7ec  vmovaps xmm1, [rsp+0x10]
00007cc2f47dc7f2  vmovaps xmm2, [rsp+0x20]
00007cc2f47dc7f8  vmovaps xmm3, [rsp+0x30]
00007cc2f47dc7fe  vmovaps xmm4, [rsp+0x40]
00007cc2f47dc804  vmovaps xmm5, [rsp+0x50]
00007cc2f47dc80a  vmovaps xmm6, [rsp+0x60]
00007cc2f47dc810  vmovaps xmm7, [rsp+0x70]
00007cc2f47dc816  vmovaps xmm8, [rsp+0x80]
00007cc2f47dc81f  vmovaps xmm9, [rsp+0x90]
00007cc2f47dc828  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dc831  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dc83a  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dc843  vmovaps xmm13, [rsp+0xD0]
00007cc2f47dc84c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dc855  add rsp, 0xF0
00007cc2f47dc85c  pop r11
00007cc2f47dc85e  pop r10
00007cc2f47dc860  pop r9
00007cc2f47dc862  pop r8
00007cc2f47dc864  pop rsi
00007cc2f47dc865  pop rdi
00007cc2f47dc866  pop rdx
00007cc2f47dc867  pop rcx
00007cc2f47dc868  pop rax
00007cc2f47dc869  add rsp, 0x08
00007cc2f47dc86d  jmp 0x00007CC2F47D9445
00007cc2f47dc872  sub rsp, 0x08
00007cc2f47dc876  push rax
00007cc2f47dc877  push rcx
00007cc2f47dc878  push rdx
00007cc2f47dc879  push rdi
00007cc2f47dc87a  push rsi
00007cc2f47dc87b  push r8
00007cc2f47dc87d  push r9
00007cc2f47dc87f  push r10
00007cc2f47dc881  push r11
00007cc2f47dc883  sub rsp, 0xF0
00007cc2f47dc88a  vmovaps [rsp], xmm0
00007cc2f47dc88f  vmovaps [rsp+0x10], xmm1
00007cc2f47dc895  vmovaps [rsp+0x20], xmm2
00007cc2f47dc89b  vmovaps [rsp+0x30], xmm3
00007cc2f47dc8a1  vmovaps [rsp+0x40], xmm5
00007cc2f47dc8a7  vmovaps [rsp+0x50], xmm6
00007cc2f47dc8ad  vmovaps [rsp+0x60], xmm7
00007cc2f47dc8b3  vmovaps [rsp+0x70], xmm8
00007cc2f47dc8b9  vmovaps [rsp+0x80], xmm9
00007cc2f47dc8c2  vmovaps [rsp+0x90], xmm10
00007cc2f47dc8cb  vmovaps [rsp+0xA0], xmm11
00007cc2f47dc8d4  vmovaps [rsp+0xB0], xmm12
00007cc2f47dc8dd  vmovaps [rsp+0xC0], xmm13
00007cc2f47dc8e6  vmovaps [rsp+0xD0], xmm14
00007cc2f47dc8ef  vmovaps [rsp+0xE0], xmm15
00007cc2f47dc8f8  sub rsp, 0x30
00007cc2f47dc8fc  movaps [rsp], xmm4
00007cc2f47dc900  movaps [rsp+0x10], xmm13
00007cc2f47dc906  movaps [rsp+0x20], xmm8
00007cc2f47dc90c  lea rdi, [rsp]
00007cc2f47dc910  mov esi, 0x00
00007cc2f47dc915  mov rax, 0x5990E710A530
00007cc2f47dc91f  call rax
00007cc2f47dc921  movaps xmm4, [rsp]
00007cc2f47dc925  add rsp, 0x30
00007cc2f47dc929  vmovaps xmm0, [rsp]
00007cc2f47dc92e  vmovaps xmm1, [rsp+0x10]
00007cc2f47dc934  vmovaps xmm2, [rsp+0x20]
00007cc2f47dc93a  vmovaps xmm3, [rsp+0x30]
00007cc2f47dc940  vmovaps xmm5, [rsp+0x40]
00007cc2f47dc946  vmovaps xmm6, [rsp+0x50]
00007cc2f47dc94c  vmovaps xmm7, [rsp+0x60]
00007cc2f47dc952  vmovaps xmm8, [rsp+0x70]
00007cc2f47dc958  vmovaps xmm9, [rsp+0x80]
00007cc2f47dc961  vmovaps xmm10, [rsp+0x90]
00007cc2f47dc96a  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dc973  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dc97c  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dc985  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dc98e  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dc997  add rsp, 0xF0
00007cc2f47dc99e  pop r11
00007cc2f47dc9a0  pop r10
00007cc2f47dc9a2  pop r9
00007cc2f47dc9a4  pop r8
00007cc2f47dc9a6  pop rsi
00007cc2f47dc9a7  pop rdi
00007cc2f47dc9a8  pop rdx
00007cc2f47dc9a9  pop rcx
00007cc2f47dc9aa  pop rax
00007cc2f47dc9ab  add rsp, 0x08
00007cc2f47dc9af  jmp 0x00007CC2F47D946A
00007cc2f47dc9b4  sub rsp, 0x08
00007cc2f47dc9b8  push rax
00007cc2f47dc9b9  push rcx
00007cc2f47dc9ba  push rdx
00007cc2f47dc9bb  push rdi
00007cc2f47dc9bc  push rsi
00007cc2f47dc9bd  push r8
00007cc2f47dc9bf  push r9
00007cc2f47dc9c1  push r10
00007cc2f47dc9c3  push r11
00007cc2f47dc9c5  sub rsp, 0xF0
00007cc2f47dc9cc  vmovaps [rsp], xmm0
00007cc2f47dc9d1  vmovaps [rsp+0x10], xmm1
00007cc2f47dc9d7  vmovaps [rsp+0x20], xmm2
00007cc2f47dc9dd  vmovaps [rsp+0x30], xmm3
00007cc2f47dc9e3  vmovaps [rsp+0x40], xmm4
00007cc2f47dc9e9  vmovaps [rsp+0x50], xmm5
00007cc2f47dc9ef  vmovaps [rsp+0x60], xmm6
00007cc2f47dc9f5  vmovaps [rsp+0x70], xmm7
00007cc2f47dc9fb  vmovaps [rsp+0x80], xmm8
00007cc2f47dca04  vmovaps [rsp+0x90], xmm9
00007cc2f47dca0d  vmovaps [rsp+0xA0], xmm10
00007cc2f47dca16  vmovaps [rsp+0xB0], xmm11
00007cc2f47dca1f  vmovaps [rsp+0xC0], xmm12
00007cc2f47dca28  vmovaps [rsp+0xD0], xmm14
00007cc2f47dca31  vmovaps [rsp+0xE0], xmm15
00007cc2f47dca3a  sub rsp, 0x30
00007cc2f47dca3e  movaps [rsp], xmm13
00007cc2f47dca43  movaps [rsp+0x10], xmm15
00007cc2f47dca49  movaps [rsp+0x20], xmm9
00007cc2f47dca4f  lea rdi, [rsp]
00007cc2f47dca53  mov esi, 0x00
00007cc2f47dca58  mov rax, 0x5990E710A530
00007cc2f47dca62  call rax
00007cc2f47dca64  movaps xmm13, [rsp]
00007cc2f47dca69  add rsp, 0x30
00007cc2f47dca6d  vmovaps xmm0, [rsp]
00007cc2f47dca72  vmovaps xmm1, [rsp+0x10]
00007cc2f47dca78  vmovaps xmm2, [rsp+0x20]
00007cc2f47dca7e  vmovaps xmm3, [rsp+0x30]
00007cc2f47dca84  vmovaps xmm4, [rsp+0x40]
00007cc2f47dca8a  vmovaps xmm5, [rsp+0x50]
00007cc2f47dca90  vmovaps xmm6, [rsp+0x60]
00007cc2f47dca96  vmovaps xmm7, [rsp+0x70]
00007cc2f47dca9c  vmovaps xmm8, [rsp+0x80]
00007cc2f47dcaa5  vmovaps xmm9, [rsp+0x90]
00007cc2f47dcaae  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dcab7  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dcac0  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dcac9  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dcad2  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dcadb  add rsp, 0xF0
00007cc2f47dcae2  pop r11
00007cc2f47dcae4  pop r10
00007cc2f47dcae6  pop r9
00007cc2f47dcae8  pop r8
00007cc2f47dcaea  pop rsi
00007cc2f47dcaeb  pop rdi
00007cc2f47dcaec  pop rdx
00007cc2f47dcaed  pop rcx
00007cc2f47dcaee  pop rax
00007cc2f47dcaef  add rsp, 0x08
00007cc2f47dcaf3  jmp 0x00007CC2F47D9485
00007cc2f47dcaf8  sub rsp, 0x08
00007cc2f47dcafc  push rax
00007cc2f47dcafd  push rcx
00007cc2f47dcafe  push rdx
00007cc2f47dcaff  push rdi
00007cc2f47dcb00  push rsi
00007cc2f47dcb01  push r8
00007cc2f47dcb03  push r9
00007cc2f47dcb05  push r10
00007cc2f47dcb07  push r11
00007cc2f47dcb09  sub rsp, 0xF0
00007cc2f47dcb10  vmovaps [rsp], xmm0
00007cc2f47dcb15  vmovaps [rsp+0x10], xmm1
00007cc2f47dcb1b  vmovaps [rsp+0x20], xmm2
00007cc2f47dcb21  vmovaps [rsp+0x30], xmm3
00007cc2f47dcb27  vmovaps [rsp+0x40], xmm4
00007cc2f47dcb2d  vmovaps [rsp+0x50], xmm5
00007cc2f47dcb33  vmovaps [rsp+0x60], xmm6
00007cc2f47dcb39  vmovaps [rsp+0x70], xmm7
00007cc2f47dcb3f  vmovaps [rsp+0x80], xmm8
00007cc2f47dcb48  vmovaps [rsp+0x90], xmm9
00007cc2f47dcb51  vmovaps [rsp+0xA0], xmm10
00007cc2f47dcb5a  vmovaps [rsp+0xB0], xmm11
00007cc2f47dcb63  vmovaps [rsp+0xC0], xmm12
00007cc2f47dcb6c  vmovaps [rsp+0xD0], xmm13
00007cc2f47dcb75  vmovaps [rsp+0xE0], xmm14
00007cc2f47dcb7e  sub rsp, 0x30
00007cc2f47dcb82  movaps [rsp], xmm15
00007cc2f47dcb87  movaps [rsp+0x10], xmm1
00007cc2f47dcb8c  movaps [rsp+0x20], xmm5
00007cc2f47dcb91  lea rdi, [rsp]
00007cc2f47dcb95  mov esi, 0x00
00007cc2f47dcb9a  mov rax, 0x5990E710A530
00007cc2f47dcba4  call rax
00007cc2f47dcba6  movaps xmm15, [rsp]
00007cc2f47dcbab  add rsp, 0x30
00007cc2f47dcbaf  vmovaps xmm0, [rsp]
00007cc2f47dcbb4  vmovaps xmm1, [rsp+0x10]
00007cc2f47dcbba  vmovaps xmm2, [rsp+0x20]
00007cc2f47dcbc0  vmovaps xmm3, [rsp+0x30]
00007cc2f47dcbc6  vmovaps xmm4, [rsp+0x40]
00007cc2f47dcbcc  vmovaps xmm5, [rsp+0x50]
00007cc2f47dcbd2  vmovaps xmm6, [rsp+0x60]
00007cc2f47dcbd8  vmovaps xmm7, [rsp+0x70]
00007cc2f47dcbde  vmovaps xmm8, [rsp+0x80]
00007cc2f47dcbe7  vmovaps xmm9, [rsp+0x90]
00007cc2f47dcbf0  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dcbf9  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dcc02  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dcc0b  vmovaps xmm13, [rsp+0xD0]
00007cc2f47dcc14  vmovaps xmm14, [rsp+0xE0]
00007cc2f47dcc1d  add rsp, 0xF0
00007cc2f47dcc24  pop r11
00007cc2f47dcc26  pop r10
00007cc2f47dcc28  pop r9
00007cc2f47dcc2a  pop r8
00007cc2f47dcc2c  pop rsi
00007cc2f47dcc2d  pop rdi
00007cc2f47dcc2e  pop rdx
00007cc2f47dcc2f  pop rcx
00007cc2f47dcc30  pop rax
00007cc2f47dcc31  add rsp, 0x08
00007cc2f47dcc35  jmp 0x00007CC2F47D94A0
00007cc2f47dcc3a  call 0x00007CC2F46D64F0
00007cc2f47dcc3f  jmp 0x00007CC2F47D94FB
00007cc2f47dcc44  sub rsp, 0x08
00007cc2f47dcc48  push rax
00007cc2f47dcc49  push rcx
00007cc2f47dcc4a  push rdx
00007cc2f47dcc4b  push rdi
00007cc2f47dcc4c  push rsi
00007cc2f47dcc4d  push r8
00007cc2f47dcc4f  push r9
00007cc2f47dcc51  push r10
00007cc2f47dcc53  push r11
00007cc2f47dcc55  sub rsp, 0xF0
00007cc2f47dcc5c  vmovaps [rsp], xmm0
00007cc2f47dcc61  vmovaps [rsp+0x10], xmm1
00007cc2f47dcc67  vmovaps [rsp+0x20], xmm2
00007cc2f47dcc6d  vmovaps [rsp+0x30], xmm3
00007cc2f47dcc73  vmovaps [rsp+0x40], xmm4
00007cc2f47dcc79  vmovaps [rsp+0x50], xmm5
00007cc2f47dcc7f  vmovaps [rsp+0x60], xmm6
00007cc2f47dcc85  vmovaps [rsp+0x70], xmm7
00007cc2f47dcc8b  vmovaps [rsp+0x80], xmm8
00007cc2f47dcc94  vmovaps [rsp+0x90], xmm10
00007cc2f47dcc9d  vmovaps [rsp+0xA0], xmm11
00007cc2f47dcca6  vmovaps [rsp+0xB0], xmm12
00007cc2f47dccaf  vmovaps [rsp+0xC0], xmm13
00007cc2f47dccb8  vmovaps [rsp+0xD0], xmm14
00007cc2f47dccc1  vmovaps [rsp+0xE0], xmm15
00007cc2f47dccca  sub rsp, 0x30
00007cc2f47dccce  movaps [rsp], xmm9
00007cc2f47dccd3  movaps [rsp+0x10], xmm8
00007cc2f47dccd9  movaps [rsp+0x20], xmm11
00007cc2f47dccdf  lea rdi, [rsp]
00007cc2f47dcce3  mov esi, 0x00
00007cc2f47dcce8  mov rax, 0x5990E710A530
00007cc2f47dccf2  call rax
00007cc2f47dccf4  movaps xmm9, [rsp]
00007cc2f47dccf9  add rsp, 0x30
00007cc2f47dccfd  vmovaps xmm0, [rsp]
00007cc2f47dcd02  vmovaps xmm1, [rsp+0x10]
00007cc2f47dcd08  vmovaps xmm2, [rsp+0x20]
00007cc2f47dcd0e  vmovaps xmm3, [rsp+0x30]
00007cc2f47dcd14  vmovaps xmm4, [rsp+0x40]
00007cc2f47dcd1a  vmovaps xmm5, [rsp+0x50]
00007cc2f47dcd20  vmovaps xmm6, [rsp+0x60]
00007cc2f47dcd26  vmovaps xmm7, [rsp+0x70]
00007cc2f47dcd2c  vmovaps xmm8, [rsp+0x80]
00007cc2f47dcd35  vmovaps xmm10, [rsp+0x90]
00007cc2f47dcd3e  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dcd47  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dcd50  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dcd59  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dcd62  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dcd6b  add rsp, 0xF0
00007cc2f47dcd72  pop r11
00007cc2f47dcd74  pop r10
00007cc2f47dcd76  pop r9
00007cc2f47dcd78  pop r8
00007cc2f47dcd7a  pop rsi
00007cc2f47dcd7b  pop rdi
00007cc2f47dcd7c  pop rdx
00007cc2f47dcd7d  pop rcx
00007cc2f47dcd7e  pop rax
00007cc2f47dcd7f  add rsp, 0x08
00007cc2f47dcd83  jmp 0x00007CC2F47D9532
00007cc2f47dcd88  sub rsp, 0x08
00007cc2f47dcd8c  push rax
00007cc2f47dcd8d  push rcx
00007cc2f47dcd8e  push rdx
00007cc2f47dcd8f  push rdi
00007cc2f47dcd90  push rsi
00007cc2f47dcd91  push r8
00007cc2f47dcd93  push r9
00007cc2f47dcd95  push r10
00007cc2f47dcd97  push r11
00007cc2f47dcd99  sub rsp, 0xF0
00007cc2f47dcda0  vmovaps [rsp], xmm0
00007cc2f47dcda5  vmovaps [rsp+0x10], xmm1
00007cc2f47dcdab  vmovaps [rsp+0x20], xmm2
00007cc2f47dcdb1  vmovaps [rsp+0x30], xmm3
00007cc2f47dcdb7  vmovaps [rsp+0x40], xmm4
00007cc2f47dcdbd  vmovaps [rsp+0x50], xmm5
00007cc2f47dcdc3  vmovaps [rsp+0x60], xmm6
00007cc2f47dcdc9  vmovaps [rsp+0x70], xmm7
00007cc2f47dcdcf  vmovaps [rsp+0x80], xmm8
00007cc2f47dcdd8  vmovaps [rsp+0x90], xmm9
00007cc2f47dcde1  vmovaps [rsp+0xA0], xmm10
00007cc2f47dcdea  vmovaps [rsp+0xB0], xmm12
00007cc2f47dcdf3  vmovaps [rsp+0xC0], xmm13
00007cc2f47dcdfc  vmovaps [rsp+0xD0], xmm14
00007cc2f47dce05  vmovaps [rsp+0xE0], xmm15
00007cc2f47dce0e  sub rsp, 0x30
00007cc2f47dce12  movaps [rsp], xmm11
00007cc2f47dce17  movaps [rsp+0x10], xmm10
00007cc2f47dce1d  movaps [rsp+0x20], xmm6
00007cc2f47dce22  lea rdi, [rsp]
00007cc2f47dce26  mov esi, 0x00
00007cc2f47dce2b  mov rax, 0x5990E710A530
00007cc2f47dce35  call rax
00007cc2f47dce37  movaps xmm11, [rsp]
00007cc2f47dce3c  add rsp, 0x30
00007cc2f47dce40  vmovaps xmm0, [rsp]
00007cc2f47dce45  vmovaps xmm1, [rsp+0x10]
00007cc2f47dce4b  vmovaps xmm2, [rsp+0x20]
00007cc2f47dce51  vmovaps xmm3, [rsp+0x30]
00007cc2f47dce57  vmovaps xmm4, [rsp+0x40]
00007cc2f47dce5d  vmovaps xmm5, [rsp+0x50]
00007cc2f47dce63  vmovaps xmm6, [rsp+0x60]
00007cc2f47dce69  vmovaps xmm7, [rsp+0x70]
00007cc2f47dce6f  vmovaps xmm8, [rsp+0x80]
00007cc2f47dce78  vmovaps xmm9, [rsp+0x90]
00007cc2f47dce81  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dce8a  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dce93  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dce9c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dcea5  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dceae  add rsp, 0xF0
00007cc2f47dceb5  pop r11
00007cc2f47dceb7  pop r10
00007cc2f47dceb9  pop r9
00007cc2f47dcebb  pop r8
00007cc2f47dcebd  pop rsi
00007cc2f47dcebe  pop rdi
00007cc2f47dcebf  pop rdx
00007cc2f47dcec0  pop rcx
00007cc2f47dcec1  pop rax
00007cc2f47dcec2  add rsp, 0x08
00007cc2f47dcec6  jmp 0x00007CC2F47D954D
00007cc2f47dcecb  sub rsp, 0x08
00007cc2f47dcecf  push rax
00007cc2f47dced0  push rcx
00007cc2f47dced1  push rdx
00007cc2f47dced2  push rdi
00007cc2f47dced3  push rsi
00007cc2f47dced4  push r8
00007cc2f47dced6  push r9
00007cc2f47dced8  push r10
00007cc2f47dceda  push r11
00007cc2f47dcedc  sub rsp, 0xF0
00007cc2f47dcee3  vmovaps [rsp], xmm0
00007cc2f47dcee8  vmovaps [rsp+0x10], xmm1
00007cc2f47dceee  vmovaps [rsp+0x20], xmm2
00007cc2f47dcef4  vmovaps [rsp+0x30], xmm3
00007cc2f47dcefa  vmovaps [rsp+0x40], xmm4
00007cc2f47dcf00  vmovaps [rsp+0x50], xmm5
00007cc2f47dcf06  vmovaps [rsp+0x60], xmm6
00007cc2f47dcf0c  vmovaps [rsp+0x70], xmm7
00007cc2f47dcf12  vmovaps [rsp+0x80], xmm8
00007cc2f47dcf1b  vmovaps [rsp+0x90], xmm9
00007cc2f47dcf24  vmovaps [rsp+0xA0], xmm11
00007cc2f47dcf2d  vmovaps [rsp+0xB0], xmm12
00007cc2f47dcf36  vmovaps [rsp+0xC0], xmm13
00007cc2f47dcf3f  vmovaps [rsp+0xD0], xmm14
00007cc2f47dcf48  vmovaps [rsp+0xE0], xmm15
00007cc2f47dcf51  sub rsp, 0x30
00007cc2f47dcf55  movaps [rsp], xmm10
00007cc2f47dcf5a  movaps [rsp+0x10], xmm14
00007cc2f47dcf60  movaps [rsp+0x20], xmm4
00007cc2f47dcf65  lea rdi, [rsp]
00007cc2f47dcf69  mov esi, 0x00
00007cc2f47dcf6e  mov rax, 0x5990E710A530
00007cc2f47dcf78  call rax
00007cc2f47dcf7a  movaps xmm10, [rsp]
00007cc2f47dcf7f  add rsp, 0x30
00007cc2f47dcf83  vmovaps xmm0, [rsp]
00007cc2f47dcf88  vmovaps xmm1, [rsp+0x10]
00007cc2f47dcf8e  vmovaps xmm2, [rsp+0x20]
00007cc2f47dcf94  vmovaps xmm3, [rsp+0x30]
00007cc2f47dcf9a  vmovaps xmm4, [rsp+0x40]
00007cc2f47dcfa0  vmovaps xmm5, [rsp+0x50]
00007cc2f47dcfa6  vmovaps xmm6, [rsp+0x60]
00007cc2f47dcfac  vmovaps xmm7, [rsp+0x70]
00007cc2f47dcfb2  vmovaps xmm8, [rsp+0x80]
00007cc2f47dcfbb  vmovaps xmm9, [rsp+0x90]
00007cc2f47dcfc4  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dcfcd  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dcfd6  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dcfdf  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dcfe8  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dcff1  add rsp, 0xF0
00007cc2f47dcff8  pop r11
00007cc2f47dcffa  pop r10
00007cc2f47dcffc  pop r9
00007cc2f47dcffe  pop r8
00007cc2f47dd000  pop rsi
00007cc2f47dd001  pop rdi
00007cc2f47dd002  pop rdx
00007cc2f47dd003  pop rcx
00007cc2f47dd004  pop rax
00007cc2f47dd005  add rsp, 0x08
00007cc2f47dd009  jmp 0x00007CC2F47D9568
00007cc2f47dd00e  sub rsp, 0x08
00007cc2f47dd012  push rax
00007cc2f47dd013  push rcx
00007cc2f47dd014  push rdx
00007cc2f47dd015  push rdi
00007cc2f47dd016  push rsi
00007cc2f47dd017  push r8
00007cc2f47dd019  push r9
00007cc2f47dd01b  push r10
00007cc2f47dd01d  push r11
00007cc2f47dd01f  sub rsp, 0xF0
00007cc2f47dd026  vmovaps [rsp], xmm0
00007cc2f47dd02b  vmovaps [rsp+0x10], xmm1
00007cc2f47dd031  vmovaps [rsp+0x20], xmm2
00007cc2f47dd037  vmovaps [rsp+0x30], xmm3
00007cc2f47dd03d  vmovaps [rsp+0x40], xmm4
00007cc2f47dd043  vmovaps [rsp+0x50], xmm5
00007cc2f47dd049  vmovaps [rsp+0x60], xmm6
00007cc2f47dd04f  vmovaps [rsp+0x70], xmm7
00007cc2f47dd055  vmovaps [rsp+0x80], xmm9
00007cc2f47dd05e  vmovaps [rsp+0x90], xmm10
00007cc2f47dd067  vmovaps [rsp+0xA0], xmm11
00007cc2f47dd070  vmovaps [rsp+0xB0], xmm12
00007cc2f47dd079  vmovaps [rsp+0xC0], xmm13
00007cc2f47dd082  vmovaps [rsp+0xD0], xmm14
00007cc2f47dd08b  vmovaps [rsp+0xE0], xmm15
00007cc2f47dd094  sub rsp, 0x30
00007cc2f47dd098  movaps [rsp], xmm8
00007cc2f47dd09d  movaps [rsp+0x10], xmm1
00007cc2f47dd0a2  movaps [rsp+0x20], xmm14
00007cc2f47dd0a8  lea rdi, [rsp]
00007cc2f47dd0ac  mov esi, 0x00
00007cc2f47dd0b1  mov rax, 0x5990E710A530
00007cc2f47dd0bb  call rax
00007cc2f47dd0bd  movaps xmm8, [rsp]
00007cc2f47dd0c2  add rsp, 0x30
00007cc2f47dd0c6  vmovaps xmm0, [rsp]
00007cc2f47dd0cb  vmovaps xmm1, [rsp+0x10]
00007cc2f47dd0d1  vmovaps xmm2, [rsp+0x20]
00007cc2f47dd0d7  vmovaps xmm3, [rsp+0x30]
00007cc2f47dd0dd  vmovaps xmm4, [rsp+0x40]
00007cc2f47dd0e3  vmovaps xmm5, [rsp+0x50]
00007cc2f47dd0e9  vmovaps xmm6, [rsp+0x60]
00007cc2f47dd0ef  vmovaps xmm7, [rsp+0x70]
00007cc2f47dd0f5  vmovaps xmm9, [rsp+0x80]
00007cc2f47dd0fe  vmovaps xmm10, [rsp+0x90]
00007cc2f47dd107  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dd110  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dd119  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dd122  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dd12b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dd134  add rsp, 0xF0
00007cc2f47dd13b  pop r11
00007cc2f47dd13d  pop r10
00007cc2f47dd13f  pop r9
00007cc2f47dd141  pop r8
00007cc2f47dd143  pop rsi
00007cc2f47dd144  pop rdi
00007cc2f47dd145  pop rdx
00007cc2f47dd146  pop rcx
00007cc2f47dd147  pop rax
00007cc2f47dd148  add rsp, 0x08
00007cc2f47dd14c  jmp 0x00007CC2F47D958E
00007cc2f47dd151  sub rsp, 0x08
00007cc2f47dd155  push rax
00007cc2f47dd156  push rcx
00007cc2f47dd157  push rdx
00007cc2f47dd158  push rdi
00007cc2f47dd159  push rsi
00007cc2f47dd15a  push r8
00007cc2f47dd15c  push r9
00007cc2f47dd15e  push r10
00007cc2f47dd160  push r11
00007cc2f47dd162  sub rsp, 0xF0
00007cc2f47dd169  vmovaps [rsp], xmm0
00007cc2f47dd16e  vmovaps [rsp+0x10], xmm1
00007cc2f47dd174  vmovaps [rsp+0x20], xmm2
00007cc2f47dd17a  vmovaps [rsp+0x30], xmm3
00007cc2f47dd180  vmovaps [rsp+0x40], xmm4
00007cc2f47dd186  vmovaps [rsp+0x50], xmm5
00007cc2f47dd18c  vmovaps [rsp+0x60], xmm7
00007cc2f47dd192  vmovaps [rsp+0x70], xmm8
00007cc2f47dd198  vmovaps [rsp+0x80], xmm9
00007cc2f47dd1a1  vmovaps [rsp+0x90], xmm10
00007cc2f47dd1aa  vmovaps [rsp+0xA0], xmm11
00007cc2f47dd1b3  vmovaps [rsp+0xB0], xmm12
00007cc2f47dd1bc  vmovaps [rsp+0xC0], xmm13
00007cc2f47dd1c5  vmovaps [rsp+0xD0], xmm14
00007cc2f47dd1ce  vmovaps [rsp+0xE0], xmm15
00007cc2f47dd1d7  sub rsp, 0x30
00007cc2f47dd1db  movaps [rsp], xmm6
00007cc2f47dd1df  movaps [rsp+0x10], xmm1
00007cc2f47dd1e4  movaps [rsp+0x20], xmm14
00007cc2f47dd1ea  lea rdi, [rsp]
00007cc2f47dd1ee  mov esi, 0x00
00007cc2f47dd1f3  mov rax, 0x5990E710A530
00007cc2f47dd1fd  call rax
00007cc2f47dd1ff  movaps xmm6, [rsp]
00007cc2f47dd203  add rsp, 0x30
00007cc2f47dd207  vmovaps xmm0, [rsp]
00007cc2f47dd20c  vmovaps xmm1, [rsp+0x10]
00007cc2f47dd212  vmovaps xmm2, [rsp+0x20]
00007cc2f47dd218  vmovaps xmm3, [rsp+0x30]
00007cc2f47dd21e  vmovaps xmm4, [rsp+0x40]
00007cc2f47dd224  vmovaps xmm5, [rsp+0x50]
00007cc2f47dd22a  vmovaps xmm7, [rsp+0x60]
00007cc2f47dd230  vmovaps xmm8, [rsp+0x70]
00007cc2f47dd236  vmovaps xmm9, [rsp+0x80]
00007cc2f47dd23f  vmovaps xmm10, [rsp+0x90]
00007cc2f47dd248  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dd251  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dd25a  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dd263  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dd26c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dd275  add rsp, 0xF0
00007cc2f47dd27c  pop r11
00007cc2f47dd27e  pop r10
00007cc2f47dd280  pop r9
00007cc2f47dd282  pop r8
00007cc2f47dd284  pop rsi
00007cc2f47dd285  pop rdi
00007cc2f47dd286  pop rdx
00007cc2f47dd287  pop rcx
00007cc2f47dd288  pop rax
00007cc2f47dd289  add rsp, 0x08
00007cc2f47dd28d  jmp 0x00007CC2F47D95BA
00007cc2f47dd292  sub rsp, 0x08
00007cc2f47dd296  push rax
00007cc2f47dd297  push rcx
00007cc2f47dd298  push rdx
00007cc2f47dd299  push rdi
00007cc2f47dd29a  push rsi
00007cc2f47dd29b  push r8
00007cc2f47dd29d  push r9
00007cc2f47dd29f  push r10
00007cc2f47dd2a1  push r11
00007cc2f47dd2a3  sub rsp, 0xF0
00007cc2f47dd2aa  vmovaps [rsp], xmm0
00007cc2f47dd2af  vmovaps [rsp+0x10], xmm1
00007cc2f47dd2b5  vmovaps [rsp+0x20], xmm2
00007cc2f47dd2bb  vmovaps [rsp+0x30], xmm3
00007cc2f47dd2c1  vmovaps [rsp+0x40], xmm4
00007cc2f47dd2c7  vmovaps [rsp+0x50], xmm5
00007cc2f47dd2cd  vmovaps [rsp+0x60], xmm6
00007cc2f47dd2d3  vmovaps [rsp+0x70], xmm7
00007cc2f47dd2d9  vmovaps [rsp+0x80], xmm8
00007cc2f47dd2e2  vmovaps [rsp+0x90], xmm9
00007cc2f47dd2eb  vmovaps [rsp+0xA0], xmm10
00007cc2f47dd2f4  vmovaps [rsp+0xB0], xmm11
00007cc2f47dd2fd  vmovaps [rsp+0xC0], xmm12
00007cc2f47dd306  vmovaps [rsp+0xD0], xmm13
00007cc2f47dd30f  vmovaps [rsp+0xE0], xmm15
00007cc2f47dd318  sub rsp, 0x30
00007cc2f47dd31c  movaps [rsp], xmm14
00007cc2f47dd321  movaps [rsp+0x10], xmm12
00007cc2f47dd327  movaps [rsp+0x20], xmm1
00007cc2f47dd32c  lea rdi, [rsp]
00007cc2f47dd330  mov esi, 0x00
00007cc2f47dd335  mov rax, 0x5990E710A530
00007cc2f47dd33f  call rax
00007cc2f47dd341  movaps xmm14, [rsp]
00007cc2f47dd346  add rsp, 0x30
00007cc2f47dd34a  vmovaps xmm0, [rsp]
00007cc2f47dd34f  vmovaps xmm1, [rsp+0x10]
00007cc2f47dd355  vmovaps xmm2, [rsp+0x20]
00007cc2f47dd35b  vmovaps xmm3, [rsp+0x30]
00007cc2f47dd361  vmovaps xmm4, [rsp+0x40]
00007cc2f47dd367  vmovaps xmm5, [rsp+0x50]
00007cc2f47dd36d  vmovaps xmm6, [rsp+0x60]
00007cc2f47dd373  vmovaps xmm7, [rsp+0x70]
00007cc2f47dd379  vmovaps xmm8, [rsp+0x80]
00007cc2f47dd382  vmovaps xmm9, [rsp+0x90]
00007cc2f47dd38b  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dd394  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dd39d  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dd3a6  vmovaps xmm13, [rsp+0xD0]
00007cc2f47dd3af  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dd3b8  add rsp, 0xF0
00007cc2f47dd3bf  pop r11
00007cc2f47dd3c1  pop r10
00007cc2f47dd3c3  pop r9
00007cc2f47dd3c5  pop r8
00007cc2f47dd3c7  pop rsi
00007cc2f47dd3c8  pop rdi
00007cc2f47dd3c9  pop rdx
00007cc2f47dd3ca  pop rcx
00007cc2f47dd3cb  pop rax
00007cc2f47dd3cc  add rsp, 0x08
00007cc2f47dd3d0  jmp 0x00007CC2F47D95E0
00007cc2f47dd3d5  sub rsp, 0x08
00007cc2f47dd3d9  push rax
00007cc2f47dd3da  push rcx
00007cc2f47dd3db  push rdx
00007cc2f47dd3dc  push rdi
00007cc2f47dd3dd  push rsi
00007cc2f47dd3de  push r8
00007cc2f47dd3e0  push r9
00007cc2f47dd3e2  push r10
00007cc2f47dd3e4  push r11
00007cc2f47dd3e6  sub rsp, 0xF0
00007cc2f47dd3ed  vmovaps [rsp], xmm0
00007cc2f47dd3f2  vmovaps [rsp+0x10], xmm2
00007cc2f47dd3f8  vmovaps [rsp+0x20], xmm3
00007cc2f47dd3fe  vmovaps [rsp+0x30], xmm4
00007cc2f47dd404  vmovaps [rsp+0x40], xmm5
00007cc2f47dd40a  vmovaps [rsp+0x50], xmm6
00007cc2f47dd410  vmovaps [rsp+0x60], xmm7
00007cc2f47dd416  vmovaps [rsp+0x70], xmm8
00007cc2f47dd41c  vmovaps [rsp+0x80], xmm9
00007cc2f47dd425  vmovaps [rsp+0x90], xmm10
00007cc2f47dd42e  vmovaps [rsp+0xA0], xmm11
00007cc2f47dd437  vmovaps [rsp+0xB0], xmm12
00007cc2f47dd440  vmovaps [rsp+0xC0], xmm13
00007cc2f47dd449  vmovaps [rsp+0xD0], xmm14
00007cc2f47dd452  vmovaps [rsp+0xE0], xmm15
00007cc2f47dd45b  sub rsp, 0x30
00007cc2f47dd45f  movaps [rsp], xmm1
00007cc2f47dd463  movaps [rsp+0x10], xmm13
00007cc2f47dd469  movaps [rsp+0x20], xmm9
00007cc2f47dd46f  lea rdi, [rsp]
00007cc2f47dd473  mov esi, 0x00
00007cc2f47dd478  mov rax, 0x5990E710A530
00007cc2f47dd482  call rax
00007cc2f47dd484  movaps xmm1, [rsp]
00007cc2f47dd488  add rsp, 0x30
00007cc2f47dd48c  vmovaps xmm0, [rsp]
00007cc2f47dd491  vmovaps xmm2, [rsp+0x10]
00007cc2f47dd497  vmovaps xmm3, [rsp+0x20]
00007cc2f47dd49d  vmovaps xmm4, [rsp+0x30]
00007cc2f47dd4a3  vmovaps xmm5, [rsp+0x40]
00007cc2f47dd4a9  vmovaps xmm6, [rsp+0x50]
00007cc2f47dd4af  vmovaps xmm7, [rsp+0x60]
00007cc2f47dd4b5  vmovaps xmm8, [rsp+0x70]
00007cc2f47dd4bb  vmovaps xmm9, [rsp+0x80]
00007cc2f47dd4c4  vmovaps xmm10, [rsp+0x90]
00007cc2f47dd4cd  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dd4d6  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dd4df  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dd4e8  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dd4f1  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dd4fa  add rsp, 0xF0
00007cc2f47dd501  pop r11
00007cc2f47dd503  pop r10
00007cc2f47dd505  pop r9
00007cc2f47dd507  pop r8
00007cc2f47dd509  pop rsi
00007cc2f47dd50a  pop rdi
00007cc2f47dd50b  pop rdx
00007cc2f47dd50c  pop rcx
00007cc2f47dd50d  pop rax
00007cc2f47dd50e  add rsp, 0x08
00007cc2f47dd512  jmp 0x00007CC2F47D95FA
00007cc2f47dd517  sub rsp, 0x08
00007cc2f47dd51b  push rax
00007cc2f47dd51c  push rcx
00007cc2f47dd51d  push rdx
00007cc2f47dd51e  push rdi
00007cc2f47dd51f  push rsi
00007cc2f47dd520  push r8
00007cc2f47dd522  push r9
00007cc2f47dd524  push r10
00007cc2f47dd526  push r11
00007cc2f47dd528  sub rsp, 0xF0
00007cc2f47dd52f  vmovaps [rsp], xmm0
00007cc2f47dd534  vmovaps [rsp+0x10], xmm1
00007cc2f47dd53a  vmovaps [rsp+0x20], xmm2
00007cc2f47dd540  vmovaps [rsp+0x30], xmm3
00007cc2f47dd546  vmovaps [rsp+0x40], xmm4
00007cc2f47dd54c  vmovaps [rsp+0x50], xmm5
00007cc2f47dd552  vmovaps [rsp+0x60], xmm6
00007cc2f47dd558  vmovaps [rsp+0x70], xmm7
00007cc2f47dd55e  vmovaps [rsp+0x80], xmm8
00007cc2f47dd567  vmovaps [rsp+0x90], xmm9
00007cc2f47dd570  vmovaps [rsp+0xA0], xmm10
00007cc2f47dd579  vmovaps [rsp+0xB0], xmm11
00007cc2f47dd582  vmovaps [rsp+0xC0], xmm13
00007cc2f47dd58b  vmovaps [rsp+0xD0], xmm14
00007cc2f47dd594  vmovaps [rsp+0xE0], xmm15
00007cc2f47dd59d  sub rsp, 0x30
00007cc2f47dd5a1  movaps [rsp], xmm12
00007cc2f47dd5a6  movaps [rsp+0x10], xmm7
00007cc2f47dd5ab  movaps [rsp+0x20], xmm13
00007cc2f47dd5b1  lea rdi, [rsp]
00007cc2f47dd5b5  mov esi, 0x00
00007cc2f47dd5ba  mov rax, 0x5990E710A530
00007cc2f47dd5c4  call rax
00007cc2f47dd5c6  movaps xmm12, [rsp]
00007cc2f47dd5cb  add rsp, 0x30
00007cc2f47dd5cf  vmovaps xmm0, [rsp]
00007cc2f47dd5d4  vmovaps xmm1, [rsp+0x10]
00007cc2f47dd5da  vmovaps xmm2, [rsp+0x20]
00007cc2f47dd5e0  vmovaps xmm3, [rsp+0x30]
00007cc2f47dd5e6  vmovaps xmm4, [rsp+0x40]
00007cc2f47dd5ec  vmovaps xmm5, [rsp+0x50]
00007cc2f47dd5f2  vmovaps xmm6, [rsp+0x60]
00007cc2f47dd5f8  vmovaps xmm7, [rsp+0x70]
00007cc2f47dd5fe  vmovaps xmm8, [rsp+0x80]
00007cc2f47dd607  vmovaps xmm9, [rsp+0x90]
00007cc2f47dd610  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dd619  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dd622  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dd62b  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dd634  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dd63d  add rsp, 0xF0
00007cc2f47dd644  pop r11
00007cc2f47dd646  pop r10
00007cc2f47dd648  pop r9
00007cc2f47dd64a  pop r8
00007cc2f47dd64c  pop rsi
00007cc2f47dd64d  pop rdi
00007cc2f47dd64e  pop rdx
00007cc2f47dd64f  pop rcx
00007cc2f47dd650  pop rax
00007cc2f47dd651  add rsp, 0x08
00007cc2f47dd655  jmp 0x00007CC2F47D9621
00007cc2f47dd65a  sub rsp, 0x08
00007cc2f47dd65e  push rax
00007cc2f47dd65f  push rcx
00007cc2f47dd660  push rdx
00007cc2f47dd661  push rdi
00007cc2f47dd662  push rsi
00007cc2f47dd663  push r8
00007cc2f47dd665  push r9
00007cc2f47dd667  push r10
00007cc2f47dd669  push r11
00007cc2f47dd66b  sub rsp, 0xF0
00007cc2f47dd672  vmovaps [rsp], xmm0
00007cc2f47dd677  vmovaps [rsp+0x10], xmm1
00007cc2f47dd67d  vmovaps [rsp+0x20], xmm2
00007cc2f47dd683  vmovaps [rsp+0x30], xmm3
00007cc2f47dd689  vmovaps [rsp+0x40], xmm4
00007cc2f47dd68f  vmovaps [rsp+0x50], xmm5
00007cc2f47dd695  vmovaps [rsp+0x60], xmm6
00007cc2f47dd69b  vmovaps [rsp+0x70], xmm7
00007cc2f47dd6a1  vmovaps [rsp+0x80], xmm8
00007cc2f47dd6aa  vmovaps [rsp+0x90], xmm9
00007cc2f47dd6b3  vmovaps [rsp+0xA0], xmm10
00007cc2f47dd6bc  vmovaps [rsp+0xB0], xmm11
00007cc2f47dd6c5  vmovaps [rsp+0xC0], xmm12
00007cc2f47dd6ce  vmovaps [rsp+0xD0], xmm14
00007cc2f47dd6d7  vmovaps [rsp+0xE0], xmm15
00007cc2f47dd6e0  sub rsp, 0x30
00007cc2f47dd6e4  movaps [rsp], xmm13
00007cc2f47dd6e9  movaps [rsp+0x10], xmm15
00007cc2f47dd6ef  movaps [rsp+0x20], xmm8
00007cc2f47dd6f5  lea rdi, [rsp]
00007cc2f47dd6f9  mov esi, 0x00
00007cc2f47dd6fe  mov rax, 0x5990E710A530
00007cc2f47dd708  call rax
00007cc2f47dd70a  movaps xmm13, [rsp]
00007cc2f47dd70f  add rsp, 0x30
00007cc2f47dd713  vmovaps xmm0, [rsp]
00007cc2f47dd718  vmovaps xmm1, [rsp+0x10]
00007cc2f47dd71e  vmovaps xmm2, [rsp+0x20]
00007cc2f47dd724  vmovaps xmm3, [rsp+0x30]
00007cc2f47dd72a  vmovaps xmm4, [rsp+0x40]
00007cc2f47dd730  vmovaps xmm5, [rsp+0x50]
00007cc2f47dd736  vmovaps xmm6, [rsp+0x60]
00007cc2f47dd73c  vmovaps xmm7, [rsp+0x70]
00007cc2f47dd742  vmovaps xmm8, [rsp+0x80]
00007cc2f47dd74b  vmovaps xmm9, [rsp+0x90]
00007cc2f47dd754  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dd75d  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dd766  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dd76f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dd778  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dd781  add rsp, 0xF0
00007cc2f47dd788  pop r11
00007cc2f47dd78a  pop r10
00007cc2f47dd78c  pop r9
00007cc2f47dd78e  pop r8
00007cc2f47dd790  pop rsi
00007cc2f47dd791  pop rdi
00007cc2f47dd792  pop rdx
00007cc2f47dd793  pop rcx
00007cc2f47dd794  pop rax
00007cc2f47dd795  add rsp, 0x08
00007cc2f47dd799  jmp 0x00007CC2F47D963C
00007cc2f47dd79e  sub rsp, 0x08
00007cc2f47dd7a2  push rax
00007cc2f47dd7a3  push rcx
00007cc2f47dd7a4  push rdx
00007cc2f47dd7a5  push rdi
00007cc2f47dd7a6  push rsi
00007cc2f47dd7a7  push r8
00007cc2f47dd7a9  push r9
00007cc2f47dd7ab  push r10
00007cc2f47dd7ad  push r11
00007cc2f47dd7af  sub rsp, 0xF0
00007cc2f47dd7b6  vmovaps [rsp], xmm0
00007cc2f47dd7bb  vmovaps [rsp+0x10], xmm1
00007cc2f47dd7c1  vmovaps [rsp+0x20], xmm2
00007cc2f47dd7c7  vmovaps [rsp+0x30], xmm3
00007cc2f47dd7cd  vmovaps [rsp+0x40], xmm4
00007cc2f47dd7d3  vmovaps [rsp+0x50], xmm5
00007cc2f47dd7d9  vmovaps [rsp+0x60], xmm6
00007cc2f47dd7df  vmovaps [rsp+0x70], xmm7
00007cc2f47dd7e5  vmovaps [rsp+0x80], xmm9
00007cc2f47dd7ee  vmovaps [rsp+0x90], xmm10
00007cc2f47dd7f7  vmovaps [rsp+0xA0], xmm11
00007cc2f47dd800  vmovaps [rsp+0xB0], xmm12
00007cc2f47dd809  vmovaps [rsp+0xC0], xmm13
00007cc2f47dd812  vmovaps [rsp+0xD0], xmm14
00007cc2f47dd81b  vmovaps [rsp+0xE0], xmm15
00007cc2f47dd824  sub rsp, 0x30
00007cc2f47dd828  movaps [rsp], xmm8
00007cc2f47dd82d  movaps [rsp+0x10], xmm15
00007cc2f47dd833  movaps [rsp+0x20], xmm9
00007cc2f47dd839  lea rdi, [rsp]
00007cc2f47dd83d  mov esi, 0x00
00007cc2f47dd842  mov rax, 0x5990E710A530
00007cc2f47dd84c  call rax
00007cc2f47dd84e  movaps xmm8, [rsp]
00007cc2f47dd853  add rsp, 0x30
00007cc2f47dd857  vmovaps xmm0, [rsp]
00007cc2f47dd85c  vmovaps xmm1, [rsp+0x10]
00007cc2f47dd862  vmovaps xmm2, [rsp+0x20]
00007cc2f47dd868  vmovaps xmm3, [rsp+0x30]
00007cc2f47dd86e  vmovaps xmm4, [rsp+0x40]
00007cc2f47dd874  vmovaps xmm5, [rsp+0x50]
00007cc2f47dd87a  vmovaps xmm6, [rsp+0x60]
00007cc2f47dd880  vmovaps xmm7, [rsp+0x70]
00007cc2f47dd886  vmovaps xmm9, [rsp+0x80]
00007cc2f47dd88f  vmovaps xmm10, [rsp+0x90]
00007cc2f47dd898  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dd8a1  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dd8aa  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dd8b3  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dd8bc  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dd8c5  add rsp, 0xF0
00007cc2f47dd8cc  pop r11
00007cc2f47dd8ce  pop r10
00007cc2f47dd8d0  pop r9
00007cc2f47dd8d2  pop r8
00007cc2f47dd8d4  pop rsi
00007cc2f47dd8d5  pop rdi
00007cc2f47dd8d6  pop rdx
00007cc2f47dd8d7  pop rcx
00007cc2f47dd8d8  pop rax
00007cc2f47dd8d9  add rsp, 0x08
00007cc2f47dd8dd  jmp 0x00007CC2F47D966A
00007cc2f47dd8e2  sub rsp, 0x08
00007cc2f47dd8e6  push rax
00007cc2f47dd8e7  push rcx
00007cc2f47dd8e8  push rdx
00007cc2f47dd8e9  push rdi
00007cc2f47dd8ea  push rsi
00007cc2f47dd8eb  push r8
00007cc2f47dd8ed  push r9
00007cc2f47dd8ef  push r10
00007cc2f47dd8f1  push r11
00007cc2f47dd8f3  sub rsp, 0xF0
00007cc2f47dd8fa  vmovaps [rsp], xmm0
00007cc2f47dd8ff  vmovaps [rsp+0x10], xmm1
00007cc2f47dd905  vmovaps [rsp+0x20], xmm2
00007cc2f47dd90b  vmovaps [rsp+0x30], xmm3
00007cc2f47dd911  vmovaps [rsp+0x40], xmm4
00007cc2f47dd917  vmovaps [rsp+0x50], xmm5
00007cc2f47dd91d  vmovaps [rsp+0x60], xmm6
00007cc2f47dd923  vmovaps [rsp+0x70], xmm7
00007cc2f47dd929  vmovaps [rsp+0x80], xmm8
00007cc2f47dd932  vmovaps [rsp+0x90], xmm9
00007cc2f47dd93b  vmovaps [rsp+0xA0], xmm10
00007cc2f47dd944  vmovaps [rsp+0xB0], xmm11
00007cc2f47dd94d  vmovaps [rsp+0xC0], xmm12
00007cc2f47dd956  vmovaps [rsp+0xD0], xmm13
00007cc2f47dd95f  vmovaps [rsp+0xE0], xmm14
00007cc2f47dd968  sub rsp, 0x30
00007cc2f47dd96c  movaps [rsp], xmm15
00007cc2f47dd971  movaps [rsp+0x10], xmm11
00007cc2f47dd977  movaps [rsp+0x20], xmm6
00007cc2f47dd97c  lea rdi, [rsp]
00007cc2f47dd980  mov esi, 0x00
00007cc2f47dd985  mov rax, 0x5990E710A530
00007cc2f47dd98f  call rax
00007cc2f47dd991  movaps xmm15, [rsp]
00007cc2f47dd996  add rsp, 0x30
00007cc2f47dd99a  vmovaps xmm0, [rsp]
00007cc2f47dd99f  vmovaps xmm1, [rsp+0x10]
00007cc2f47dd9a5  vmovaps xmm2, [rsp+0x20]
00007cc2f47dd9ab  vmovaps xmm3, [rsp+0x30]
00007cc2f47dd9b1  vmovaps xmm4, [rsp+0x40]
00007cc2f47dd9b7  vmovaps xmm5, [rsp+0x50]
00007cc2f47dd9bd  vmovaps xmm6, [rsp+0x60]
00007cc2f47dd9c3  vmovaps xmm7, [rsp+0x70]
00007cc2f47dd9c9  vmovaps xmm8, [rsp+0x80]
00007cc2f47dd9d2  vmovaps xmm9, [rsp+0x90]
00007cc2f47dd9db  vmovaps xmm10, [rsp+0xA0]
00007cc2f47dd9e4  vmovaps xmm11, [rsp+0xB0]
00007cc2f47dd9ed  vmovaps xmm12, [rsp+0xC0]
00007cc2f47dd9f6  vmovaps xmm13, [rsp+0xD0]
00007cc2f47dd9ff  vmovaps xmm14, [rsp+0xE0]
00007cc2f47dda08  add rsp, 0xF0
00007cc2f47dda0f  pop r11
00007cc2f47dda11  pop r10
00007cc2f47dda13  pop r9
00007cc2f47dda15  pop r8
00007cc2f47dda17  pop rsi
00007cc2f47dda18  pop rdi
00007cc2f47dda19  pop rdx
00007cc2f47dda1a  pop rcx
00007cc2f47dda1b  pop rax
00007cc2f47dda1c  add rsp, 0x08
00007cc2f47dda20  jmp 0x00007CC2F47D9685
00007cc2f47dda25  sub rsp, 0x08
00007cc2f47dda29  push rax
00007cc2f47dda2a  push rcx
00007cc2f47dda2b  push rdx
00007cc2f47dda2c  push rdi
00007cc2f47dda2d  push rsi
00007cc2f47dda2e  push r8
00007cc2f47dda30  push r9
00007cc2f47dda32  push r10
00007cc2f47dda34  push r11
00007cc2f47dda36  sub rsp, 0xF0
00007cc2f47dda3d  vmovaps [rsp], xmm0
00007cc2f47dda42  vmovaps [rsp+0x10], xmm1
00007cc2f47dda48  vmovaps [rsp+0x20], xmm2
00007cc2f47dda4e  vmovaps [rsp+0x30], xmm3
00007cc2f47dda54  vmovaps [rsp+0x40], xmm4
00007cc2f47dda5a  vmovaps [rsp+0x50], xmm5
00007cc2f47dda60  vmovaps [rsp+0x60], xmm6
00007cc2f47dda66  vmovaps [rsp+0x70], xmm8
00007cc2f47dda6c  vmovaps [rsp+0x80], xmm9
00007cc2f47dda75  vmovaps [rsp+0x90], xmm10
00007cc2f47dda7e  vmovaps [rsp+0xA0], xmm11
00007cc2f47dda87  vmovaps [rsp+0xB0], xmm12
00007cc2f47dda90  vmovaps [rsp+0xC0], xmm13
00007cc2f47dda99  vmovaps [rsp+0xD0], xmm14
00007cc2f47ddaa2  vmovaps [rsp+0xE0], xmm15
00007cc2f47ddaab  sub rsp, 0x30
00007cc2f47ddaaf  movaps [rsp], xmm7
00007cc2f47ddab3  movaps [rsp+0x10], xmm11
00007cc2f47ddab9  movaps [rsp+0x20], xmm9
00007cc2f47ddabf  lea rdi, [rsp]
00007cc2f47ddac3  mov esi, 0x00
00007cc2f47ddac8  mov rax, 0x5990E710A530
00007cc2f47ddad2  call rax
00007cc2f47ddad4  movaps xmm7, [rsp]
00007cc2f47ddad8  add rsp, 0x30
00007cc2f47ddadc  vmovaps xmm0, [rsp]
00007cc2f47ddae1  vmovaps xmm1, [rsp+0x10]
00007cc2f47ddae7  vmovaps xmm2, [rsp+0x20]
00007cc2f47ddaed  vmovaps xmm3, [rsp+0x30]
00007cc2f47ddaf3  vmovaps xmm4, [rsp+0x40]
00007cc2f47ddaf9  vmovaps xmm5, [rsp+0x50]
00007cc2f47ddaff  vmovaps xmm6, [rsp+0x60]
00007cc2f47ddb05  vmovaps xmm8, [rsp+0x70]
00007cc2f47ddb0b  vmovaps xmm9, [rsp+0x80]
00007cc2f47ddb14  vmovaps xmm10, [rsp+0x90]
00007cc2f47ddb1d  vmovaps xmm11, [rsp+0xA0]
00007cc2f47ddb26  vmovaps xmm12, [rsp+0xB0]
00007cc2f47ddb2f  vmovaps xmm13, [rsp+0xC0]
00007cc2f47ddb38  vmovaps xmm14, [rsp+0xD0]
00007cc2f47ddb41  vmovaps xmm15, [rsp+0xE0]
00007cc2f47ddb4a  add rsp, 0xF0
00007cc2f47ddb51  pop r11
00007cc2f47ddb53  pop r10
00007cc2f47ddb55  pop r9
00007cc2f47ddb57  pop r8
00007cc2f47ddb59  pop rsi
00007cc2f47ddb5a  pop rdi
00007cc2f47ddb5b  pop rdx
00007cc2f47ddb5c  pop rcx
00007cc2f47ddb5d  pop rax
00007cc2f47ddb5e  add rsp, 0x08
00007cc2f47ddb62  jmp 0x00007CC2F47D96B2
00007cc2f47ddb67  sub rsp, 0x08
00007cc2f47ddb6b  push rax
00007cc2f47ddb6c  push rcx
00007cc2f47ddb6d  push rdx
00007cc2f47ddb6e  push rdi
00007cc2f47ddb6f  push rsi
00007cc2f47ddb70  push r8
00007cc2f47ddb72  push r9
00007cc2f47ddb74  push r10
00007cc2f47ddb76  push r11
00007cc2f47ddb78  sub rsp, 0xF0
00007cc2f47ddb7f  vmovaps [rsp], xmm0
00007cc2f47ddb84  vmovaps [rsp+0x10], xmm1
00007cc2f47ddb8a  vmovaps [rsp+0x20], xmm2
00007cc2f47ddb90  vmovaps [rsp+0x30], xmm3
00007cc2f47ddb96  vmovaps [rsp+0x40], xmm4
00007cc2f47ddb9c  vmovaps [rsp+0x50], xmm5
00007cc2f47ddba2  vmovaps [rsp+0x60], xmm6
00007cc2f47ddba8  vmovaps [rsp+0x70], xmm7
00007cc2f47ddbae  vmovaps [rsp+0x80], xmm8
00007cc2f47ddbb7  vmovaps [rsp+0x90], xmm9
00007cc2f47ddbc0  vmovaps [rsp+0xA0], xmm10
00007cc2f47ddbc9  vmovaps [rsp+0xB0], xmm12
00007cc2f47ddbd2  vmovaps [rsp+0xC0], xmm13
00007cc2f47ddbdb  vmovaps [rsp+0xD0], xmm14
00007cc2f47ddbe4  vmovaps [rsp+0xE0], xmm15
00007cc2f47ddbed  sub rsp, 0x30
00007cc2f47ddbf1  movaps [rsp], xmm11
00007cc2f47ddbf6  movaps [rsp+0x10], xmm10
00007cc2f47ddbfc  movaps [rsp+0x20], xmm14
00007cc2f47ddc02  lea rdi, [rsp]
00007cc2f47ddc06  mov esi, 0x00
00007cc2f47ddc0b  mov rax, 0x5990E710A530
00007cc2f47ddc15  call rax
00007cc2f47ddc17  movaps xmm11, [rsp]
00007cc2f47ddc1c  add rsp, 0x30
00007cc2f47ddc20  vmovaps xmm0, [rsp]
00007cc2f47ddc25  vmovaps xmm1, [rsp+0x10]
00007cc2f47ddc2b  vmovaps xmm2, [rsp+0x20]
00007cc2f47ddc31  vmovaps xmm3, [rsp+0x30]
00007cc2f47ddc37  vmovaps xmm4, [rsp+0x40]
00007cc2f47ddc3d  vmovaps xmm5, [rsp+0x50]
00007cc2f47ddc43  vmovaps xmm6, [rsp+0x60]
00007cc2f47ddc49  vmovaps xmm7, [rsp+0x70]
00007cc2f47ddc4f  vmovaps xmm8, [rsp+0x80]
00007cc2f47ddc58  vmovaps xmm9, [rsp+0x90]
00007cc2f47ddc61  vmovaps xmm10, [rsp+0xA0]
00007cc2f47ddc6a  vmovaps xmm12, [rsp+0xB0]
00007cc2f47ddc73  vmovaps xmm13, [rsp+0xC0]
00007cc2f47ddc7c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47ddc85  vmovaps xmm15, [rsp+0xE0]
00007cc2f47ddc8e  add rsp, 0xF0
00007cc2f47ddc95  pop r11
00007cc2f47ddc97  pop r10
00007cc2f47ddc99  pop r9
00007cc2f47ddc9b  pop r8
00007cc2f47ddc9d  pop rsi
00007cc2f47ddc9e  pop rdi
00007cc2f47ddc9f  pop rdx
00007cc2f47ddca0  pop rcx
00007cc2f47ddca1  pop rax
00007cc2f47ddca2  add rsp, 0x08
00007cc2f47ddca6  jmp 0x00007CC2F47D96CD
00007cc2f47ddcab  call 0x00007CC2F46E45A0
00007cc2f47ddcb0  jmp 0x00007CC2F47D96D7
00007cc2f47ddcb5  sub rsp, 0x08
00007cc2f47ddcb9  push rax
00007cc2f47ddcba  push rcx
00007cc2f47ddcbb  push rdx
00007cc2f47ddcbc  push rdi
00007cc2f47ddcbd  push rsi
00007cc2f47ddcbe  push r8
00007cc2f47ddcc0  push r9
00007cc2f47ddcc2  push r10
00007cc2f47ddcc4  push r11
00007cc2f47ddcc6  sub rsp, 0xF0
00007cc2f47ddccd  vmovaps [rsp], xmm0
00007cc2f47ddcd2  vmovaps [rsp+0x10], xmm1
00007cc2f47ddcd8  vmovaps [rsp+0x20], xmm2
00007cc2f47ddcde  vmovaps [rsp+0x30], xmm3
00007cc2f47ddce4  vmovaps [rsp+0x40], xmm4
00007cc2f47ddcea  vmovaps [rsp+0x50], xmm5
00007cc2f47ddcf0  vmovaps [rsp+0x60], xmm6
00007cc2f47ddcf6  vmovaps [rsp+0x70], xmm7
00007cc2f47ddcfc  vmovaps [rsp+0x80], xmm8
00007cc2f47ddd05  vmovaps [rsp+0x90], xmm9
00007cc2f47ddd0e  vmovaps [rsp+0xA0], xmm11
00007cc2f47ddd17  vmovaps [rsp+0xB0], xmm12
00007cc2f47ddd20  vmovaps [rsp+0xC0], xmm13
00007cc2f47ddd29  vmovaps [rsp+0xD0], xmm14
00007cc2f47ddd32  vmovaps [rsp+0xE0], xmm15
00007cc2f47ddd3b  sub rsp, 0x30
00007cc2f47ddd3f  movaps [rsp], xmm10
00007cc2f47ddd44  movaps [rsp+0x10], xmm1
00007cc2f47ddd49  movaps [rsp+0x20], xmm12
00007cc2f47ddd4f  lea rdi, [rsp]
00007cc2f47ddd53  mov esi, 0x00
00007cc2f47ddd58  mov rax, 0x5990E710A530
00007cc2f47ddd62  call rax
00007cc2f47ddd64  movaps xmm10, [rsp]
00007cc2f47ddd69  add rsp, 0x30
00007cc2f47ddd6d  vmovaps xmm0, [rsp]
00007cc2f47ddd72  vmovaps xmm1, [rsp+0x10]
00007cc2f47ddd78  vmovaps xmm2, [rsp+0x20]
00007cc2f47ddd7e  vmovaps xmm3, [rsp+0x30]
00007cc2f47ddd84  vmovaps xmm4, [rsp+0x40]
00007cc2f47ddd8a  vmovaps xmm5, [rsp+0x50]
00007cc2f47ddd90  vmovaps xmm6, [rsp+0x60]
00007cc2f47ddd96  vmovaps xmm7, [rsp+0x70]
00007cc2f47ddd9c  vmovaps xmm8, [rsp+0x80]
00007cc2f47ddda5  vmovaps xmm9, [rsp+0x90]
00007cc2f47dddae  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dddb7  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dddc0  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dddc9  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dddd2  vmovaps xmm15, [rsp+0xE0]
00007cc2f47ddddb  add rsp, 0xF0
00007cc2f47ddde2  pop r11
00007cc2f47ddde4  pop r10
00007cc2f47ddde6  pop r9
00007cc2f47ddde8  pop r8
00007cc2f47dddea  pop rsi
00007cc2f47dddeb  pop rdi
00007cc2f47dddec  pop rdx
00007cc2f47ddded  pop rcx
00007cc2f47dddee  pop rax
00007cc2f47dddef  add rsp, 0x08
00007cc2f47dddf3  jmp 0x00007CC2F47D96FA
00007cc2f47dddf8  sub rsp, 0x08
00007cc2f47dddfc  push rax
00007cc2f47dddfd  push rcx
00007cc2f47dddfe  push rdx
00007cc2f47dddff  push rdi
00007cc2f47dde00  push rsi
00007cc2f47dde01  push r8
00007cc2f47dde03  push r9
00007cc2f47dde05  push r10
00007cc2f47dde07  push r11
00007cc2f47dde09  sub rsp, 0xF0
00007cc2f47dde10  vmovaps [rsp], xmm0
00007cc2f47dde15  vmovaps [rsp+0x10], xmm1
00007cc2f47dde1b  vmovaps [rsp+0x20], xmm2
00007cc2f47dde21  vmovaps [rsp+0x30], xmm3
00007cc2f47dde27  vmovaps [rsp+0x40], xmm4
00007cc2f47dde2d  vmovaps [rsp+0x50], xmm5
00007cc2f47dde33  vmovaps [rsp+0x60], xmm6
00007cc2f47dde39  vmovaps [rsp+0x70], xmm7
00007cc2f47dde3f  vmovaps [rsp+0x80], xmm8
00007cc2f47dde48  vmovaps [rsp+0x90], xmm9
00007cc2f47dde51  vmovaps [rsp+0xA0], xmm10
00007cc2f47dde5a  vmovaps [rsp+0xB0], xmm11
00007cc2f47dde63  vmovaps [rsp+0xC0], xmm13
00007cc2f47dde6c  vmovaps [rsp+0xD0], xmm14
00007cc2f47dde75  vmovaps [rsp+0xE0], xmm15
00007cc2f47dde7e  sub rsp, 0x30
00007cc2f47dde82  movaps [rsp], xmm12
00007cc2f47dde87  movaps [rsp+0x10], xmm14
00007cc2f47dde8d  movaps [rsp+0x20], xmm1
00007cc2f47dde92  lea rdi, [rsp]
00007cc2f47dde96  mov esi, 0x00
00007cc2f47dde9b  mov rax, 0x5990E710A530
00007cc2f47ddea5  call rax
00007cc2f47ddea7  movaps xmm12, [rsp]
00007cc2f47ddeac  add rsp, 0x30
00007cc2f47ddeb0  vmovaps xmm0, [rsp]
00007cc2f47ddeb5  vmovaps xmm1, [rsp+0x10]
00007cc2f47ddebb  vmovaps xmm2, [rsp+0x20]
00007cc2f47ddec1  vmovaps xmm3, [rsp+0x30]
00007cc2f47ddec7  vmovaps xmm4, [rsp+0x40]
00007cc2f47ddecd  vmovaps xmm5, [rsp+0x50]
00007cc2f47dded3  vmovaps xmm6, [rsp+0x60]
00007cc2f47dded9  vmovaps xmm7, [rsp+0x70]
00007cc2f47ddedf  vmovaps xmm8, [rsp+0x80]
00007cc2f47ddee8  vmovaps xmm9, [rsp+0x90]
00007cc2f47ddef1  vmovaps xmm10, [rsp+0xA0]
00007cc2f47ddefa  vmovaps xmm11, [rsp+0xB0]
00007cc2f47ddf03  vmovaps xmm13, [rsp+0xC0]
00007cc2f47ddf0c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47ddf15  vmovaps xmm15, [rsp+0xE0]
00007cc2f47ddf1e  add rsp, 0xF0
00007cc2f47ddf25  pop r11
00007cc2f47ddf27  pop r10
00007cc2f47ddf29  pop r9
00007cc2f47ddf2b  pop r8
00007cc2f47ddf2d  pop rsi
00007cc2f47ddf2e  pop rdi
00007cc2f47ddf2f  pop rdx
00007cc2f47ddf30  pop rcx
00007cc2f47ddf31  pop rax
00007cc2f47ddf32  add rsp, 0x08
00007cc2f47ddf36  jmp 0x00007CC2F47D9729
00007cc2f47ddf3b  sub rsp, 0x08
00007cc2f47ddf3f  push rax
00007cc2f47ddf40  push rcx
00007cc2f47ddf41  push rdx
00007cc2f47ddf42  push rdi
00007cc2f47ddf43  push rsi
00007cc2f47ddf44  push r8
00007cc2f47ddf46  push r9
00007cc2f47ddf48  push r10
00007cc2f47ddf4a  push r11
00007cc2f47ddf4c  sub rsp, 0xF0
00007cc2f47ddf53  vmovaps [rsp], xmm0
00007cc2f47ddf58  vmovaps [rsp+0x10], xmm1
00007cc2f47ddf5e  vmovaps [rsp+0x20], xmm2
00007cc2f47ddf64  vmovaps [rsp+0x30], xmm3
00007cc2f47ddf6a  vmovaps [rsp+0x40], xmm4
00007cc2f47ddf70  vmovaps [rsp+0x50], xmm5
00007cc2f47ddf76  vmovaps [rsp+0x60], xmm6
00007cc2f47ddf7c  vmovaps [rsp+0x70], xmm7
00007cc2f47ddf82  vmovaps [rsp+0x80], xmm8
00007cc2f47ddf8b  vmovaps [rsp+0x90], xmm9
00007cc2f47ddf94  vmovaps [rsp+0xA0], xmm10
00007cc2f47ddf9d  vmovaps [rsp+0xB0], xmm11
00007cc2f47ddfa6  vmovaps [rsp+0xC0], xmm12
00007cc2f47ddfaf  vmovaps [rsp+0xD0], xmm13
00007cc2f47ddfb8  vmovaps [rsp+0xE0], xmm15
00007cc2f47ddfc1  sub rsp, 0x30
00007cc2f47ddfc5  movaps [rsp], xmm14
00007cc2f47ddfca  movaps [rsp+0x10], xmm9
00007cc2f47ddfd0  movaps [rsp+0x20], xmm1
00007cc2f47ddfd5  lea rdi, [rsp]
00007cc2f47ddfd9  mov esi, 0x00
00007cc2f47ddfde  mov rax, 0x5990E710A530
00007cc2f47ddfe8  call rax
00007cc2f47ddfea  movaps xmm14, [rsp]
00007cc2f47ddfef  add rsp, 0x30
00007cc2f47ddff3  vmovaps xmm0, [rsp]
00007cc2f47ddff8  vmovaps xmm1, [rsp+0x10]
00007cc2f47ddffe  vmovaps xmm2, [rsp+0x20]
00007cc2f47de004  vmovaps xmm3, [rsp+0x30]
00007cc2f47de00a  vmovaps xmm4, [rsp+0x40]
00007cc2f47de010  vmovaps xmm5, [rsp+0x50]
00007cc2f47de016  vmovaps xmm6, [rsp+0x60]
00007cc2f47de01c  vmovaps xmm7, [rsp+0x70]
00007cc2f47de022  vmovaps xmm8, [rsp+0x80]
00007cc2f47de02b  vmovaps xmm9, [rsp+0x90]
00007cc2f47de034  vmovaps xmm10, [rsp+0xA0]
00007cc2f47de03d  vmovaps xmm11, [rsp+0xB0]
00007cc2f47de046  vmovaps xmm12, [rsp+0xC0]
00007cc2f47de04f  vmovaps xmm13, [rsp+0xD0]
00007cc2f47de058  vmovaps xmm15, [rsp+0xE0]
00007cc2f47de061  add rsp, 0xF0
00007cc2f47de068  pop r11
00007cc2f47de06a  pop r10
00007cc2f47de06c  pop r9
00007cc2f47de06e  pop r8
00007cc2f47de070  pop rsi
00007cc2f47de071  pop rdi
00007cc2f47de072  pop rdx
00007cc2f47de073  pop rcx
00007cc2f47de074  pop rax
00007cc2f47de075  add rsp, 0x08
00007cc2f47de079  jmp 0x00007CC2F47D9758
00007cc2f47de07e  sub rsp, 0x08
00007cc2f47de082  push rax
00007cc2f47de083  push rcx
00007cc2f47de084  push rdx
00007cc2f47de085  push rdi
00007cc2f47de086  push rsi
00007cc2f47de087  push r8
00007cc2f47de089  push r9
00007cc2f47de08b  push r10
00007cc2f47de08d  push r11
00007cc2f47de08f  sub rsp, 0xF0
00007cc2f47de096  vmovaps [rsp], xmm0
00007cc2f47de09b  vmovaps [rsp+0x10], xmm2
00007cc2f47de0a1  vmovaps [rsp+0x20], xmm3
00007cc2f47de0a7  vmovaps [rsp+0x30], xmm4
00007cc2f47de0ad  vmovaps [rsp+0x40], xmm5
00007cc2f47de0b3  vmovaps [rsp+0x50], xmm6
00007cc2f47de0b9  vmovaps [rsp+0x60], xmm7
00007cc2f47de0bf  vmovaps [rsp+0x70], xmm8
00007cc2f47de0c5  vmovaps [rsp+0x80], xmm9
00007cc2f47de0ce  vmovaps [rsp+0x90], xmm10
00007cc2f47de0d7  vmovaps [rsp+0xA0], xmm11
00007cc2f47de0e0  vmovaps [rsp+0xB0], xmm12
00007cc2f47de0e9  vmovaps [rsp+0xC0], xmm13
00007cc2f47de0f2  vmovaps [rsp+0xD0], xmm14
00007cc2f47de0fb  vmovaps [rsp+0xE0], xmm15
00007cc2f47de104  sub rsp, 0x30
00007cc2f47de108  movaps [rsp], xmm1
00007cc2f47de10c  movaps [rsp+0x10], xmm13
00007cc2f47de112  movaps [rsp+0x20], xmm8
00007cc2f47de118  lea rdi, [rsp]
00007cc2f47de11c  mov esi, 0x00
00007cc2f47de121  mov rax, 0x5990E710A530
00007cc2f47de12b  call rax
00007cc2f47de12d  movaps xmm1, [rsp]
00007cc2f47de131  add rsp, 0x30
00007cc2f47de135  vmovaps xmm0, [rsp]
00007cc2f47de13a  vmovaps xmm2, [rsp+0x10]
00007cc2f47de140  vmovaps xmm3, [rsp+0x20]
00007cc2f47de146  vmovaps xmm4, [rsp+0x30]
00007cc2f47de14c  vmovaps xmm5, [rsp+0x40]
00007cc2f47de152  vmovaps xmm6, [rsp+0x50]
00007cc2f47de158  vmovaps xmm7, [rsp+0x60]
00007cc2f47de15e  vmovaps xmm8, [rsp+0x70]
00007cc2f47de164  vmovaps xmm9, [rsp+0x80]
00007cc2f47de16d  vmovaps xmm10, [rsp+0x90]
00007cc2f47de176  vmovaps xmm11, [rsp+0xA0]
00007cc2f47de17f  vmovaps xmm12, [rsp+0xB0]
00007cc2f47de188  vmovaps xmm13, [rsp+0xC0]
00007cc2f47de191  vmovaps xmm14, [rsp+0xD0]
00007cc2f47de19a  vmovaps xmm15, [rsp+0xE0]
00007cc2f47de1a3  add rsp, 0xF0
00007cc2f47de1aa  pop r11
00007cc2f47de1ac  pop r10
00007cc2f47de1ae  pop r9
00007cc2f47de1b0  pop r8
00007cc2f47de1b2  pop rsi
00007cc2f47de1b3  pop rdi
00007cc2f47de1b4  pop rdx
00007cc2f47de1b5  pop rcx
00007cc2f47de1b6  pop rax
00007cc2f47de1b7  add rsp, 0x08
00007cc2f47de1bb  jmp 0x00007CC2F47D977A
00007cc2f47de1c0  call 0x00007CC2F460C260
00007cc2f47de1c5  jmp 0x00007CC2F47D9788
00007cc2f47de1ca  call 0x00007CC2F46DE950
00007cc2f47de1cf  jmp 0x00007CC2F47D9792
00007cc2f47de1d4  sub rsp, 0x08
00007cc2f47de1d8  push rax
00007cc2f47de1d9  push rcx
00007cc2f47de1da  push rdx
00007cc2f47de1db  push rdi
00007cc2f47de1dc  push rsi
00007cc2f47de1dd  push r8
00007cc2f47de1df  push r9
00007cc2f47de1e1  push r10
00007cc2f47de1e3  push r11
00007cc2f47de1e5  sub rsp, 0xF0
00007cc2f47de1ec  vmovaps [rsp], xmm0
00007cc2f47de1f1  vmovaps [rsp+0x10], xmm1
00007cc2f47de1f7  vmovaps [rsp+0x20], xmm2
00007cc2f47de1fd  vmovaps [rsp+0x30], xmm3
00007cc2f47de203  vmovaps [rsp+0x40], xmm4
00007cc2f47de209  vmovaps [rsp+0x50], xmm5
00007cc2f47de20f  vmovaps [rsp+0x60], xmm6
00007cc2f47de215  vmovaps [rsp+0x70], xmm7
00007cc2f47de21b  vmovaps [rsp+0x80], xmm9
00007cc2f47de224  vmovaps [rsp+0x90], xmm10
00007cc2f47de22d  vmovaps [rsp+0xA0], xmm11
00007cc2f47de236  vmovaps [rsp+0xB0], xmm12
00007cc2f47de23f  vmovaps [rsp+0xC0], xmm13
00007cc2f47de248  vmovaps [rsp+0xD0], xmm14
00007cc2f47de251  vmovaps [rsp+0xE0], xmm15
00007cc2f47de25a  sub rsp, 0x30
00007cc2f47de25e  movaps [rsp], xmm8
00007cc2f47de263  movaps [rsp+0x10], xmm15
00007cc2f47de269  movaps [rsp+0x20], xmm7
00007cc2f47de26e  lea rdi, [rsp]
00007cc2f47de272  mov esi, 0x00
00007cc2f47de277  mov rax, 0x5990E710A530
00007cc2f47de281  call rax
00007cc2f47de283  movaps xmm8, [rsp]
00007cc2f47de288  add rsp, 0x30
00007cc2f47de28c  vmovaps xmm0, [rsp]
00007cc2f47de291  vmovaps xmm1, [rsp+0x10]
00007cc2f47de297  vmovaps xmm2, [rsp+0x20]
00007cc2f47de29d  vmovaps xmm3, [rsp+0x30]
00007cc2f47de2a3  vmovaps xmm4, [rsp+0x40]
00007cc2f47de2a9  vmovaps xmm5, [rsp+0x50]
00007cc2f47de2af  vmovaps xmm6, [rsp+0x60]
00007cc2f47de2b5  vmovaps xmm7, [rsp+0x70]
00007cc2f47de2bb  vmovaps xmm9, [rsp+0x80]
00007cc2f47de2c4  vmovaps xmm10, [rsp+0x90]
00007cc2f47de2cd  vmovaps xmm11, [rsp+0xA0]
00007cc2f47de2d6  vmovaps xmm12, [rsp+0xB0]
00007cc2f47de2df  vmovaps xmm13, [rsp+0xC0]
00007cc2f47de2e8  vmovaps xmm14, [rsp+0xD0]
00007cc2f47de2f1  vmovaps xmm15, [rsp+0xE0]
00007cc2f47de2fa  add rsp, 0xF0
00007cc2f47de301  pop r11
00007cc2f47de303  pop r10
00007cc2f47de305  pop r9
00007cc2f47de307  pop r8
00007cc2f47de309  pop rsi
00007cc2f47de30a  pop rdi
00007cc2f47de30b  pop rdx
00007cc2f47de30c  pop rcx
00007cc2f47de30d  pop rax
00007cc2f47de30e  add rsp, 0x08
00007cc2f47de312  jmp 0x00007CC2F47D97B4
00007cc2f47de317  sub rsp, 0x08
00007cc2f47de31b  push rax
00007cc2f47de31c  push rcx
00007cc2f47de31d  push rdx
00007cc2f47de31e  push rdi
00007cc2f47de31f  push rsi
00007cc2f47de320  push r8
00007cc2f47de322  push r9
00007cc2f47de324  push r10
00007cc2f47de326  push r11
00007cc2f47de328  sub rsp, 0xF0
00007cc2f47de32f  vmovaps [rsp], xmm0
00007cc2f47de334  vmovaps [rsp+0x10], xmm1
00007cc2f47de33a  vmovaps [rsp+0x20], xmm2
00007cc2f47de340  vmovaps [rsp+0x30], xmm3
00007cc2f47de346  vmovaps [rsp+0x40], xmm4
00007cc2f47de34c  vmovaps [rsp+0x50], xmm5
00007cc2f47de352  vmovaps [rsp+0x60], xmm6
00007cc2f47de358  vmovaps [rsp+0x70], xmm8
00007cc2f47de35e  vmovaps [rsp+0x80], xmm9
00007cc2f47de367  vmovaps [rsp+0x90], xmm10
00007cc2f47de370  vmovaps [rsp+0xA0], xmm11
00007cc2f47de379  vmovaps [rsp+0xB0], xmm12
00007cc2f47de382  vmovaps [rsp+0xC0], xmm13
00007cc2f47de38b  vmovaps [rsp+0xD0], xmm14
00007cc2f47de394  vmovaps [rsp+0xE0], xmm15
00007cc2f47de39d  sub rsp, 0x30
00007cc2f47de3a1  movaps [rsp], xmm7
00007cc2f47de3a5  movaps [rsp+0x10], xmm9
00007cc2f47de3ab  movaps [rsp+0x20], xmm15
00007cc2f47de3b1  lea rdi, [rsp]
00007cc2f47de3b5  mov esi, 0x00
00007cc2f47de3ba  mov rax, 0x5990E710A530
00007cc2f47de3c4  call rax
00007cc2f47de3c6  movaps xmm7, [rsp]
00007cc2f47de3ca  add rsp, 0x30
00007cc2f47de3ce  vmovaps xmm0, [rsp]
00007cc2f47de3d3  vmovaps xmm1, [rsp+0x10]
00007cc2f47de3d9  vmovaps xmm2, [rsp+0x20]
00007cc2f47de3df  vmovaps xmm3, [rsp+0x30]
00007cc2f47de3e5  vmovaps xmm4, [rsp+0x40]
00007cc2f47de3eb  vmovaps xmm5, [rsp+0x50]
00007cc2f47de3f1  vmovaps xmm6, [rsp+0x60]
00007cc2f47de3f7  vmovaps xmm8, [rsp+0x70]
00007cc2f47de3fd  vmovaps xmm9, [rsp+0x80]
00007cc2f47de406  vmovaps xmm10, [rsp+0x90]
00007cc2f47de40f  vmovaps xmm11, [rsp+0xA0]
00007cc2f47de418  vmovaps xmm12, [rsp+0xB0]
00007cc2f47de421  vmovaps xmm13, [rsp+0xC0]
00007cc2f47de42a  vmovaps xmm14, [rsp+0xD0]
00007cc2f47de433  vmovaps xmm15, [rsp+0xE0]
00007cc2f47de43c  add rsp, 0xF0
00007cc2f47de443  pop r11
00007cc2f47de445  pop r10
00007cc2f47de447  pop r9
00007cc2f47de449  pop r8
00007cc2f47de44b  pop rsi
00007cc2f47de44c  pop rdi
00007cc2f47de44d  pop rdx
00007cc2f47de44e  pop rcx
00007cc2f47de44f  pop rax
00007cc2f47de450  add rsp, 0x08
00007cc2f47de454  jmp 0x00007CC2F47D97E1
00007cc2f47de459  sub rsp, 0x08
00007cc2f47de45d  push rax
00007cc2f47de45e  push rcx
00007cc2f47de45f  push rdx
00007cc2f47de460  push rdi
00007cc2f47de461  push rsi
00007cc2f47de462  push r8
00007cc2f47de464  push r9
00007cc2f47de466  push r10
00007cc2f47de468  push r11
00007cc2f47de46a  sub rsp, 0xF0
00007cc2f47de471  vmovaps [rsp], xmm0
00007cc2f47de476  vmovaps [rsp+0x10], xmm1
00007cc2f47de47c  vmovaps [rsp+0x20], xmm2
00007cc2f47de482  vmovaps [rsp+0x30], xmm3
00007cc2f47de488  vmovaps [rsp+0x40], xmm4
00007cc2f47de48e  vmovaps [rsp+0x50], xmm5
00007cc2f47de494  vmovaps [rsp+0x60], xmm6
00007cc2f47de49a  vmovaps [rsp+0x70], xmm7
00007cc2f47de4a0  vmovaps [rsp+0x80], xmm8
00007cc2f47de4a9  vmovaps [rsp+0x90], xmm10
00007cc2f47de4b2  vmovaps [rsp+0xA0], xmm11
00007cc2f47de4bb  vmovaps [rsp+0xB0], xmm12
00007cc2f47de4c4  vmovaps [rsp+0xC0], xmm13
00007cc2f47de4cd  vmovaps [rsp+0xD0], xmm14
00007cc2f47de4d6  vmovaps [rsp+0xE0], xmm15
00007cc2f47de4df  sub rsp, 0x30
00007cc2f47de4e3  movaps [rsp], xmm9
00007cc2f47de4e8  movaps [rsp+0x10], xmm13
00007cc2f47de4ee  movaps [rsp+0x20], xmm15
00007cc2f47de4f4  lea rdi, [rsp]
00007cc2f47de4f8  mov esi, 0x00
00007cc2f47de4fd  mov rax, 0x5990E710A530
00007cc2f47de507  call rax
00007cc2f47de509  movaps xmm9, [rsp]
00007cc2f47de50e  add rsp, 0x30
00007cc2f47de512  vmovaps xmm0, [rsp]
00007cc2f47de517  vmovaps xmm1, [rsp+0x10]
00007cc2f47de51d  vmovaps xmm2, [rsp+0x20]
00007cc2f47de523  vmovaps xmm3, [rsp+0x30]
00007cc2f47de529  vmovaps xmm4, [rsp+0x40]
00007cc2f47de52f  vmovaps xmm5, [rsp+0x50]
00007cc2f47de535  vmovaps xmm6, [rsp+0x60]
00007cc2f47de53b  vmovaps xmm7, [rsp+0x70]
00007cc2f47de541  vmovaps xmm8, [rsp+0x80]
00007cc2f47de54a  vmovaps xmm10, [rsp+0x90]
00007cc2f47de553  vmovaps xmm11, [rsp+0xA0]
00007cc2f47de55c  vmovaps xmm12, [rsp+0xB0]
00007cc2f47de565  vmovaps xmm13, [rsp+0xC0]
00007cc2f47de56e  vmovaps xmm14, [rsp+0xD0]
00007cc2f47de577  vmovaps xmm15, [rsp+0xE0]
00007cc2f47de580  add rsp, 0xF0
00007cc2f47de587  pop r11
00007cc2f47de589  pop r10
00007cc2f47de58b  pop r9
00007cc2f47de58d  pop r8
00007cc2f47de58f  pop rsi
00007cc2f47de590  pop rdi
00007cc2f47de591  pop rdx
00007cc2f47de592  pop rcx
00007cc2f47de593  pop rax
00007cc2f47de594  add rsp, 0x08
00007cc2f47de598  jmp 0x00007CC2F47D980F
00007cc2f47de59d  sub rsp, 0x08
00007cc2f47de5a1  push rax
00007cc2f47de5a2  push rcx
00007cc2f47de5a3  push rdx
00007cc2f47de5a4  push rdi
00007cc2f47de5a5  push rsi
00007cc2f47de5a6  push r8
00007cc2f47de5a8  push r9
00007cc2f47de5aa  push r10
00007cc2f47de5ac  push r11
00007cc2f47de5ae  sub rsp, 0xF0
00007cc2f47de5b5  vmovaps [rsp], xmm0
00007cc2f47de5ba  vmovaps [rsp+0x10], xmm1
00007cc2f47de5c0  vmovaps [rsp+0x20], xmm2
00007cc2f47de5c6  vmovaps [rsp+0x30], xmm3
00007cc2f47de5cc  vmovaps [rsp+0x40], xmm4
00007cc2f47de5d2  vmovaps [rsp+0x50], xmm5
00007cc2f47de5d8  vmovaps [rsp+0x60], xmm6
00007cc2f47de5de  vmovaps [rsp+0x70], xmm7
00007cc2f47de5e4  vmovaps [rsp+0x80], xmm8
00007cc2f47de5ed  vmovaps [rsp+0x90], xmm9
00007cc2f47de5f6  vmovaps [rsp+0xA0], xmm10
00007cc2f47de5ff  vmovaps [rsp+0xB0], xmm11
00007cc2f47de608  vmovaps [rsp+0xC0], xmm12
00007cc2f47de611  vmovaps [rsp+0xD0], xmm13
00007cc2f47de61a  vmovaps [rsp+0xE0], xmm14
00007cc2f47de623  sub rsp, 0x30
00007cc2f47de627  movaps [rsp], xmm15
00007cc2f47de62c  movaps [rsp+0x10], xmm11
00007cc2f47de632  movaps [rsp+0x20], xmm12
00007cc2f47de638  lea rdi, [rsp]
00007cc2f47de63c  mov esi, 0x00
00007cc2f47de641  mov rax, 0x5990E710A530
00007cc2f47de64b  call rax
00007cc2f47de64d  movaps xmm15, [rsp]
00007cc2f47de652  add rsp, 0x30
00007cc2f47de656  vmovaps xmm0, [rsp]
00007cc2f47de65b  vmovaps xmm1, [rsp+0x10]
00007cc2f47de661  vmovaps xmm2, [rsp+0x20]
00007cc2f47de667  vmovaps xmm3, [rsp+0x30]
00007cc2f47de66d  vmovaps xmm4, [rsp+0x40]
00007cc2f47de673  vmovaps xmm5, [rsp+0x50]
00007cc2f47de679  vmovaps xmm6, [rsp+0x60]
00007cc2f47de67f  vmovaps xmm7, [rsp+0x70]
00007cc2f47de685  vmovaps xmm8, [rsp+0x80]
00007cc2f47de68e  vmovaps xmm9, [rsp+0x90]
00007cc2f47de697  vmovaps xmm10, [rsp+0xA0]
00007cc2f47de6a0  vmovaps xmm11, [rsp+0xB0]
00007cc2f47de6a9  vmovaps xmm12, [rsp+0xC0]
00007cc2f47de6b2  vmovaps xmm13, [rsp+0xD0]
00007cc2f47de6bb  vmovaps xmm14, [rsp+0xE0]
00007cc2f47de6c4  add rsp, 0xF0
00007cc2f47de6cb  pop r11
00007cc2f47de6cd  pop r10
00007cc2f47de6cf  pop r9
00007cc2f47de6d1  pop r8
00007cc2f47de6d3  pop rsi
00007cc2f47de6d4  pop rdi
00007cc2f47de6d5  pop rdx
00007cc2f47de6d6  pop rcx
00007cc2f47de6d7  pop rax
00007cc2f47de6d8  add rsp, 0x08
00007cc2f47de6dc  jmp 0x00007CC2F47D982A
00007cc2f47de6e1  sub rsp, 0x08
00007cc2f47de6e5  push rax
00007cc2f47de6e6  push rcx
00007cc2f47de6e7  push rdx
00007cc2f47de6e8  push rdi
00007cc2f47de6e9  push rsi
00007cc2f47de6ea  push r8
00007cc2f47de6ec  push r9
00007cc2f47de6ee  push r10
00007cc2f47de6f0  push r11
00007cc2f47de6f2  sub rsp, 0xF0
00007cc2f47de6f9  vmovaps [rsp], xmm0
00007cc2f47de6fe  vmovaps [rsp+0x10], xmm1
00007cc2f47de704  vmovaps [rsp+0x20], xmm2
00007cc2f47de70a  vmovaps [rsp+0x30], xmm3
00007cc2f47de710  vmovaps [rsp+0x40], xmm4
00007cc2f47de716  vmovaps [rsp+0x50], xmm5
00007cc2f47de71c  vmovaps [rsp+0x60], xmm6
00007cc2f47de722  vmovaps [rsp+0x70], xmm7
00007cc2f47de728  vmovaps [rsp+0x80], xmm8
00007cc2f47de731  vmovaps [rsp+0x90], xmm9
00007cc2f47de73a  vmovaps [rsp+0xA0], xmm10
00007cc2f47de743  vmovaps [rsp+0xB0], xmm11
00007cc2f47de74c  vmovaps [rsp+0xC0], xmm12
00007cc2f47de755  vmovaps [rsp+0xD0], xmm14
00007cc2f47de75e  vmovaps [rsp+0xE0], xmm15
00007cc2f47de767  sub rsp, 0x30
00007cc2f47de76b  movaps [rsp], xmm13
00007cc2f47de770  movaps [rsp+0x10], xmm10
00007cc2f47de776  movaps [rsp+0x20], xmm14
00007cc2f47de77c  lea rdi, [rsp]
00007cc2f47de780  mov esi, 0x00
00007cc2f47de785  mov rax, 0x5990E710A530
00007cc2f47de78f  call rax
00007cc2f47de791  movaps xmm13, [rsp]
00007cc2f47de796  add rsp, 0x30
00007cc2f47de79a  vmovaps xmm0, [rsp]
00007cc2f47de79f  vmovaps xmm1, [rsp+0x10]
00007cc2f47de7a5  vmovaps xmm2, [rsp+0x20]
00007cc2f47de7ab  vmovaps xmm3, [rsp+0x30]
00007cc2f47de7b1  vmovaps xmm4, [rsp+0x40]
00007cc2f47de7b7  vmovaps xmm5, [rsp+0x50]
00007cc2f47de7bd  vmovaps xmm6, [rsp+0x60]
00007cc2f47de7c3  vmovaps xmm7, [rsp+0x70]
00007cc2f47de7c9  vmovaps xmm8, [rsp+0x80]
00007cc2f47de7d2  vmovaps xmm9, [rsp+0x90]
00007cc2f47de7db  vmovaps xmm10, [rsp+0xA0]
00007cc2f47de7e4  vmovaps xmm11, [rsp+0xB0]
00007cc2f47de7ed  vmovaps xmm12, [rsp+0xC0]
00007cc2f47de7f6  vmovaps xmm14, [rsp+0xD0]
00007cc2f47de7ff  vmovaps xmm15, [rsp+0xE0]
00007cc2f47de808  add rsp, 0xF0
00007cc2f47de80f  pop r11
00007cc2f47de811  pop r10
00007cc2f47de813  pop r9
00007cc2f47de815  pop r8
00007cc2f47de817  pop rsi
00007cc2f47de818  pop rdi
00007cc2f47de819  pop rdx
00007cc2f47de81a  pop rcx
00007cc2f47de81b  pop rax
00007cc2f47de81c  add rsp, 0x08
00007cc2f47de820  jmp 0x00007CC2F47D984D
00007cc2f47de825  sub rsp, 0x08
00007cc2f47de829  push rax
00007cc2f47de82a  push rcx
00007cc2f47de82b  push rdx
00007cc2f47de82c  push rdi
00007cc2f47de82d  push rsi
00007cc2f47de82e  push r8
00007cc2f47de830  push r9
00007cc2f47de832  push r10
00007cc2f47de834  push r11
00007cc2f47de836  sub rsp, 0xF0
00007cc2f47de83d  vmovaps [rsp], xmm0
00007cc2f47de842  vmovaps [rsp+0x10], xmm1
00007cc2f47de848  vmovaps [rsp+0x20], xmm2
00007cc2f47de84e  vmovaps [rsp+0x30], xmm3
00007cc2f47de854  vmovaps [rsp+0x40], xmm4
00007cc2f47de85a  vmovaps [rsp+0x50], xmm5
00007cc2f47de860  vmovaps [rsp+0x60], xmm6
00007cc2f47de866  vmovaps [rsp+0x70], xmm7
00007cc2f47de86c  vmovaps [rsp+0x80], xmm8
00007cc2f47de875  vmovaps [rsp+0x90], xmm9
00007cc2f47de87e  vmovaps [rsp+0xA0], xmm10
00007cc2f47de887  vmovaps [rsp+0xB0], xmm11
00007cc2f47de890  vmovaps [rsp+0xC0], xmm12
00007cc2f47de899  vmovaps [rsp+0xD0], xmm13
00007cc2f47de8a2  vmovaps [rsp+0xE0], xmm15
00007cc2f47de8ab  sub rsp, 0x30
00007cc2f47de8af  movaps [rsp], xmm14
00007cc2f47de8b4  movaps [rsp+0x10], xmm1
00007cc2f47de8b9  movaps [rsp+0x20], xmm7
00007cc2f47de8be  lea rdi, [rsp]
00007cc2f47de8c2  mov esi, 0x00
00007cc2f47de8c7  mov rax, 0x5990E710A530
00007cc2f47de8d1  call rax
00007cc2f47de8d3  movaps xmm14, [rsp]
00007cc2f47de8d8  add rsp, 0x30
00007cc2f47de8dc  vmovaps xmm0, [rsp]
00007cc2f47de8e1  vmovaps xmm1, [rsp+0x10]
00007cc2f47de8e7  vmovaps xmm2, [rsp+0x20]
00007cc2f47de8ed  vmovaps xmm3, [rsp+0x30]
00007cc2f47de8f3  vmovaps xmm4, [rsp+0x40]
00007cc2f47de8f9  vmovaps xmm5, [rsp+0x50]
00007cc2f47de8ff  vmovaps xmm6, [rsp+0x60]
00007cc2f47de905  vmovaps xmm7, [rsp+0x70]
00007cc2f47de90b  vmovaps xmm8, [rsp+0x80]
00007cc2f47de914  vmovaps xmm9, [rsp+0x90]
00007cc2f47de91d  vmovaps xmm10, [rsp+0xA0]
00007cc2f47de926  vmovaps xmm11, [rsp+0xB0]
00007cc2f47de92f  vmovaps xmm12, [rsp+0xC0]
00007cc2f47de938  vmovaps xmm13, [rsp+0xD0]
00007cc2f47de941  vmovaps xmm15, [rsp+0xE0]
00007cc2f47de94a  add rsp, 0xF0
00007cc2f47de951  pop r11
00007cc2f47de953  pop r10
00007cc2f47de955  pop r9
00007cc2f47de957  pop r8
00007cc2f47de959  pop rsi
00007cc2f47de95a  pop rdi
00007cc2f47de95b  pop rdx
00007cc2f47de95c  pop rcx
00007cc2f47de95d  pop rax
00007cc2f47de95e  add rsp, 0x08
00007cc2f47de962  jmp 0x00007CC2F47D9870
00007cc2f47de967  sub rsp, 0x08
00007cc2f47de96b  push rax
00007cc2f47de96c  push rcx
00007cc2f47de96d  push rdx
00007cc2f47de96e  push rdi
00007cc2f47de96f  push rsi
00007cc2f47de970  push r8
00007cc2f47de972  push r9
00007cc2f47de974  push r10
00007cc2f47de976  push r11
00007cc2f47de978  sub rsp, 0xF0
00007cc2f47de97f  vmovaps [rsp], xmm0
00007cc2f47de984  vmovaps [rsp+0x10], xmm2
00007cc2f47de98a  vmovaps [rsp+0x20], xmm3
00007cc2f47de990  vmovaps [rsp+0x30], xmm4
00007cc2f47de996  vmovaps [rsp+0x40], xmm5
00007cc2f47de99c  vmovaps [rsp+0x50], xmm6
00007cc2f47de9a2  vmovaps [rsp+0x60], xmm7
00007cc2f47de9a8  vmovaps [rsp+0x70], xmm8
00007cc2f47de9ae  vmovaps [rsp+0x80], xmm9
00007cc2f47de9b7  vmovaps [rsp+0x90], xmm10
00007cc2f47de9c0  vmovaps [rsp+0xA0], xmm11
00007cc2f47de9c9  vmovaps [rsp+0xB0], xmm12
00007cc2f47de9d2  vmovaps [rsp+0xC0], xmm13
00007cc2f47de9db  vmovaps [rsp+0xD0], xmm14
00007cc2f47de9e4  vmovaps [rsp+0xE0], xmm15
00007cc2f47de9ed  sub rsp, 0x30
00007cc2f47de9f1  movaps [rsp], xmm1
00007cc2f47de9f5  movaps [rsp+0x10], xmm8
00007cc2f47de9fb  movaps [rsp+0x20], xmm9
00007cc2f47dea01  lea rdi, [rsp]
00007cc2f47dea05  mov esi, 0x00
00007cc2f47dea0a  mov rax, 0x5990E710A530
00007cc2f47dea14  call rax
00007cc2f47dea16  movaps xmm1, [rsp]
00007cc2f47dea1a  add rsp, 0x30
00007cc2f47dea1e  vmovaps xmm0, [rsp]
00007cc2f47dea23  vmovaps xmm2, [rsp+0x10]
00007cc2f47dea29  vmovaps xmm3, [rsp+0x20]
00007cc2f47dea2f  vmovaps xmm4, [rsp+0x30]
00007cc2f47dea35  vmovaps xmm5, [rsp+0x40]
00007cc2f47dea3b  vmovaps xmm6, [rsp+0x50]
00007cc2f47dea41  vmovaps xmm7, [rsp+0x60]
00007cc2f47dea47  vmovaps xmm8, [rsp+0x70]
00007cc2f47dea4d  vmovaps xmm9, [rsp+0x80]
00007cc2f47dea56  vmovaps xmm10, [rsp+0x90]
00007cc2f47dea5f  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dea68  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dea71  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dea7a  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dea83  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dea8c  add rsp, 0xF0
00007cc2f47dea93  pop r11
00007cc2f47dea95  pop r10
00007cc2f47dea97  pop r9
00007cc2f47dea99  pop r8
00007cc2f47dea9b  pop rsi
00007cc2f47dea9c  pop rdi
00007cc2f47dea9d  pop rdx
00007cc2f47dea9e  pop rcx
00007cc2f47dea9f  pop rax
00007cc2f47deaa0  add rsp, 0x08
00007cc2f47deaa4  jmp 0x00007CC2F47D9892
00007cc2f47deaa9  call 0x00007CC2F46B3E40
00007cc2f47deaae  jmp 0x00007CC2F47D98A0
00007cc2f47deab3  call 0x00007CC2F460C380
00007cc2f47deab8  jmp 0x00007CC2F47D98AA
00007cc2f47deabd  call 0x00007CC2F460D600
00007cc2f47deac2  jmp 0x00007CC2F47D98B4
00007cc2f47deac7  call 0x00007CC2F45FF540
00007cc2f47deacc  jmp 0x00007CC2F47D98BE
00007cc2f47dead1  int3
00007cc2f47dead2  nop [rax+rax*1], ax
00007cc2f47deadb  nop [rax+rax*1], eax
00007cc2f47deae0  mov eax, [r15+0x48]
00007cc2f47deae4  lea r14d, [eax+0x01]
00007cc2f47deae9  mov [rsp+0x10], r14d
00007cc2f47deaee  mov r14d, r14d
00007cc2f47deaf1  mov [r15+0x48], r14
00007cc2f47deaf5  xor eax, eax
00007cc2f47deaf7  mov r14d, [rsp+0x10]
00007cc2f47deafc  cmp r14d, 0x1F4
00007cc2f47deb03  cmc
00007cc2f47deb04  lahf
00007cc2f47deb05  seto al
00007cc2f47deb08  mov [r15+0x108], eax
00007cc2f47deb0f  mov eax, [r15+0x108]
00007cc2f47deb16  sahf
00007cc2f47deb17  jnz 0x00007CC2F47DEB49
00007cc2f47deb19  cmp dword ptr [r15+0x318], 0x00
00007cc2f47deb21  jz 0x00007CC2F47E4C90
00007cc2f47deb27  nop [rax+rax*1], ax
00007cc2f47deb30  nop [rax+rax*1], eax
00007cc2f47deb38  mov eax, 0x4106DC
00007cc2f47deb3d  mov [r15+0x100], rax
00007cc2f47deb44  jmp 0x00007CC2F45FE110
00007cc2f47deb49  cmp dword ptr [r15+0x318], 0x00
00007cc2f47deb51  jz 0x00007CC2F47DEB80
00007cc2f47deb57  nop [rax+rax*1], ax
00007cc2f47deb60  nop [rax+rax*1], eax
00007cc2f47deb68  mov eax, 0x410500
00007cc2f47deb6d  mov [r15+0x100], rax
00007cc2f47deb74  jmp 0x00007CC2F45FE110
00007cc2f47deb79  int3
00007cc2f47deb7a  int3
00007cc2f47deb7b  nop [rax+rax*1], eax
00007cc2f47deb80  mov rax, [r15+0x40]
00007cc2f47deb84  movaps xmm1, [r15+0x1D0]
00007cc2f47deb8c  vmovaps [rsp+0x10], xmm1
00007cc2f47deb92  vmovaps xmm15, [rsp+0x10]
00007cc2f47deb98  por xmm1, xmm15
00007cc2f47deb9d  movaps xmm14, [r15+0x1A0]
00007cc2f47deba5  vmovaps [rsp+0x10], xmm14
00007cc2f47debab  vmovaps xmm13, [rsp+0x10]
00007cc2f47debb1  por xmm14, xmm13
00007cc2f47debb6  lea r14, [rax+0x30]
00007cc2f47debba  mov r12, [r13+r14*1]
00007cc2f47debbf  lea r14, [rax+0x38]
00007cc2f47debc3  mov r11, [r13+r14*1]
00007cc2f47debc8  movq xmm13, r12
00007cc2f47debcd  movq xmm12, r11
00007cc2f47debd2  movq xmm13, xmm13
00007cc2f47debd7  vmovaps [rsp+0x10], xmm13
00007cc2f47debdd  movq xmm13, xmm13
00007cc2f47debe2  movaps [r15+0x130], xmm13
00007cc2f47debea  movq xmm12, xmm12
00007cc2f47debef  vmovaps [rsp+0x20], xmm12
00007cc2f47debf5  movq xmm12, xmm12
00007cc2f47debfa  movaps [r15+0x280], xmm12
00007cc2f47dec02  movaps xmm13, [r15+0x270]
00007cc2f47dec0a  vmovaps [rsp+0x30], xmm13
00007cc2f47dec10  vmovaps xmm12, [rsp+0x30]
00007cc2f47dec16  por xmm13, xmm12
00007cc2f47dec1b  lea r14, [rax+0x20]
00007cc2f47dec1f  mov r12, [r13+r14*1]
00007cc2f47dec24  lea r14, [rax+0x28]
00007cc2f47dec28  mov r11, [r13+r14*1]
00007cc2f47dec2d  movq xmm12, r12
00007cc2f47dec32  movq xmm11, r11
00007cc2f47dec37  movq xmm12, xmm12
00007cc2f47dec3c  vmovaps [rsp+0x30], xmm12
00007cc2f47dec42  movq xmm12, xmm12
00007cc2f47dec47  movaps [r15+0x150], xmm12
00007cc2f47dec4f  movq xmm11, xmm11
00007cc2f47dec54  vmovaps [rsp+0x40], xmm11
00007cc2f47dec5a  movq xmm11, xmm11
00007cc2f47dec5f  movaps [r15+0x140], xmm11
00007cc2f47dec67  lea r14, [rax+0x10]
00007cc2f47dec6b  mov r12, [r13+r14*1]
00007cc2f47dec70  lea r14, [rax+0x18]
00007cc2f47dec74  mov r11, [r13+r14*1]
00007cc2f47dec79  movq xmm12, r12
00007cc2f47dec7e  movq xmm11, r11
00007cc2f47dec83  movq xmm12, xmm12
00007cc2f47dec88  vmovaps [rsp+0x50], xmm12
00007cc2f47dec8e  movq xmm12, xmm12
00007cc2f47dec93  movaps [r15+0x170], xmm12
00007cc2f47dec9b  movq xmm11, xmm11
00007cc2f47deca0  vmovaps [rsp+0x60], xmm11
00007cc2f47deca6  movq xmm11, xmm11
00007cc2f47decab  movaps [r15+0x160], xmm11
00007cc2f47decb3  mov r14, [r13+rax*1]
00007cc2f47decb8  vmovq xmm12, r14
00007cc2f47decbd  vpbroadcastq xmm12, xmm12
00007cc2f47decc2  lea r14, [rax+0x08]
00007cc2f47decc6  mov rax, [r13+r14*1]
00007cc2f47deccb  movq xmm11, rax
00007cc2f47decd0  movaps [r15+0x230], xmm11
00007cc2f47decd8  mov rax, [r15+0xF8]
00007cc2f47decdf  lea r14, [rax+0x50]
00007cc2f47dece3  movups xmm11, [r13+r14*1]
00007cc2f47dece9  lea r14, [rax+0x60]
00007cc2f47deced  movups xmm10, [r13+r14*1]
00007cc2f47decf3  lea r14, [rax+0x30]
00007cc2f47decf7  movups xmm9, [r13+r14*1]
00007cc2f47decfd  mov r14, [r15+0x50]
00007cc2f47ded01  mov [r15+0x60], r14
00007cc2f47ded05  mov qword ptr [r15+0x58], 0x40
00007cc2f47ded0d  movaps xmm8, xmm12
00007cc2f47ded11  mulpd xmm8, xmm15
00007cc2f47ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007cc2f47ded1c  ptest xmm7, xmm7
00007cc2f47ded21  jnz 0x00007CC2F47DFB4A
00007cc2f47ded27  movq xmm15, qword ptr [r15+0x230]
00007cc2f47ded30  vmovaps [rsp+0x70], xmm15
00007cc2f47ded36  vpermilpd xmm15, xmm15, 0x00
00007cc2f47ded3c  movaps xmm7, xmm9
00007cc2f47ded40  mulpd xmm7, xmm15
00007cc2f47ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2f47ded4a  ptest xmm6, xmm6
00007cc2f47ded4f  jnz 0x00007CC2F47DFC8E
00007cc2f47ded55  vxorps xmm15, xmm15, xmm15
00007cc2f47ded5a  vpbroadcastq xmm15, xmm15
00007cc2f47ded5f  movaps xmm9, xmm12
00007cc2f47ded63  mulpd xmm9, xmm10
00007cc2f47ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007cc2f47ded6e  ptest xmm6, xmm6
00007cc2f47ded73  jnz 0x00007CC2F47DFDD0
00007cc2f47ded79  movaps xmm10, xmm12
00007cc2f47ded7d  mulpd xmm10, xmm11
00007cc2f47ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007cc2f47ded88  ptest xmm6, xmm6
00007cc2f47ded8d  jnz 0x00007CC2F47DFF14
00007cc2f47ded93  movaps xmm11, [r15+0x1F0]
00007cc2f47ded9b  movaps xmm6, xmm12
00007cc2f47ded9f  mulpd xmm6, xmm11
00007cc2f47deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007cc2f47deda9  ptest xmm5, xmm5
00007cc2f47dedae  jnz 0x00007CC2F47E0058
00007cc2f47dedb4  movaps xmm12, [r15+0x2A0]
00007cc2f47dedbc  vmovaps [rsp+0x80], xmm12
00007cc2f47dedc5  vmovaps xmm11, [rsp+0x80]
00007cc2f47dedce  por xmm12, xmm11
00007cc2f47dedd3  movaps xmm11, [r15+0x250]
00007cc2f47deddb  vmovaps [rsp+0x80], xmm11
00007cc2f47dede4  vmovaps xmm5, [rsp+0x80]
00007cc2f47deded  por xmm11, xmm5
00007cc2f47dedf2  vmovaps xmm4, [rsp+0x70]
00007cc2f47dedf8  vpermilpd xmm4, xmm4, 0x00
00007cc2f47dedfe  movaps xmm3, xmm5
00007cc2f47dee01  mulpd xmm3, xmm4
00007cc2f47dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007cc2f47dee0a  ptest xmm2, xmm2
00007cc2f47dee0f  jnz 0x00007CC2F47E019A
00007cc2f47dee15  mov [rsp+0x80], rax
00007cc2f47dee1d  xor eax, eax
00007cc2f47dee1f  mov r12d, 0x40
00007cc2f47dee25  mov r11d, 0x200
00007cc2f47dee2b  cmp r12, r11
00007cc2f47dee2e  cmc
00007cc2f47dee2f  lahf
00007cc2f47dee30  seto al
00007cc2f47dee33  mov [r15+0x108], eax
00007cc2f47dee3a  movaps xmm5, xmm8
00007cc2f47dee3e  addpd xmm5, xmm15
00007cc2f47dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007cc2f47dee48  ptest xmm4, xmm4
00007cc2f47dee4d  jnz 0x00007CC2F47E02DA
00007cc2f47dee53  movaps xmm8, [r15+0x1B0]
00007cc2f47dee5b  movaps xmm4, xmm9
00007cc2f47dee5f  addpd xmm4, xmm8
00007cc2f47dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007cc2f47dee69  ptest xmm2, xmm2
00007cc2f47dee6e  jnz 0x00007CC2F47E041C
00007cc2f47dee74  movaps xmm9, xmm10
00007cc2f47dee78  addpd xmm9, xmm8
00007cc2f47dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007cc2f47dee83  ptest xmm2, xmm2
00007cc2f47dee88  jnz 0x00007CC2F47E055E
00007cc2f47dee8e  movaps xmm10, [r15+0x2F0]
00007cc2f47dee96  vmovaps [rsp+0x90], xmm10
00007cc2f47dee9f  vmovaps xmm8, [rsp+0x90]
00007cc2f47deea8  por xmm10, xmm8
00007cc2f47deead  movaps xmm8, [r15+0x2E0]
00007cc2f47deeb5  vmovaps [rsp+0x90], xmm8
00007cc2f47deebe  vmovaps xmm2, [rsp+0x90]
00007cc2f47deec7  por xmm8, xmm2
00007cc2f47deecc  movaps xmm2, [r15+0x2D0]
00007cc2f47deed4  vmovaps [rsp+0x90], xmm2
00007cc2f47deedd  vmovaps [rsp+0xA0], xmm1
00007cc2f47deee6  vmovaps xmm1, [rsp+0x90]
00007cc2f47deeef  por xmm2, xmm1
00007cc2f47deef3  movaps xmm1, [r15+0x200]
00007cc2f47deefb  vmovaps [rsp+0x90], xmm1
00007cc2f47def04  vmovaps [rsp+0xB0], xmm15
00007cc2f47def0d  vmovaps xmm15, [rsp+0x90]
00007cc2f47def16  por xmm1, xmm15
00007cc2f47def1b  movaps xmm15, [r15+0x1C0]
00007cc2f47def23  vmovaps [rsp+0x90], xmm15
00007cc2f47def2c  vmovaps [rsp+0xC0], xmm1
00007cc2f47def35  vmovaps xmm1, [rsp+0x90]
00007cc2f47def3e  por xmm15, xmm1
00007cc2f47def43  movaps xmm1, [r15+0x190]
00007cc2f47def4b  vmovaps [rsp+0x90], xmm1
00007cc2f47def54  vmovaps [rsp+0xD0], xmm15
00007cc2f47def5d  vmovaps xmm15, [rsp+0x90]
00007cc2f47def66  por xmm1, xmm15
00007cc2f47def6b  movaps xmm15, [r15+0x300]
00007cc2f47def73  vmovaps [rsp+0x90], xmm15
00007cc2f47def7c  vmovaps [rsp+0xE0], xmm1
00007cc2f47def85  vmovaps xmm1, [rsp+0x90]
00007cc2f47def8e  por xmm15, xmm1
00007cc2f47def93  mov rax, [rsp+0x80]
00007cc2f47def9b  lea r12, [rax+0xA0]
00007cc2f47defa2  movups xmm1, [r13+r12*1]
00007cc2f47defa8  lea r12, [rax+0xB0]
00007cc2f47defaf  vmovaps [rsp+0x80], xmm1
00007cc2f47defb8  movups xmm1, [r13+r12*1]
00007cc2f47defbe  vmovaps [rsp+0x90], xmm1
00007cc2f47defc7  vmovaps [rsp+0xF0], xmm15
00007cc2f47defd0  vmovaps xmm15, [rsp+0xB0]
00007cc2f47defd9  vmovaps [rsp+0xB0], xmm14
00007cc2f47defe2  movaps xmm1, xmm6
00007cc2f47defe5  addpd xmm1, xmm15
00007cc2f47defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007cc2f47defef  ptest xmm14, xmm14
00007cc2f47deff5  jnz 0x00007CC2F47E06B6
00007cc2f47deffb  lea r12, [rax+0xF0]
00007cc2f47df002  movups xmm15, [r13+r12*1]
00007cc2f47df008  movaps xmm14, xmm4
00007cc2f47df00c  addpd xmm14, xmm3
00007cc2f47df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007cc2f47df017  ptest xmm6, xmm6
00007cc2f47df01c  jnz 0x00007CC2F47E0801
00007cc2f47df022  movaps xmm6, xmm9
00007cc2f47df026  addpd xmm6, xmm7
00007cc2f47df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007cc2f47df02f  ptest xmm4, xmm4
00007cc2f47df034  jnz 0x00007CC2F47E0943
00007cc2f47df03a  vmovaps xmm9, [rsp+0x70]
00007cc2f47df040  vpermilpd xmm9, xmm9, 0x00
00007cc2f47df046  vmovaps xmm4, [rsp+0x90]
00007cc2f47df04f  movaps xmm7, xmm4
00007cc2f47df052  mulpd xmm7, xmm9
00007cc2f47df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007cc2f47df05c  ptest xmm3, xmm3
00007cc2f47df061  jnz 0x00007CC2F47E0A84
00007cc2f47df067  vmovaps xmm9, [rsp+0x50]
00007cc2f47df06d  vpermilpd xmm9, xmm9, 0x00
00007cc2f47df073  movaps xmm4, xmm15
00007cc2f47df077  mulpd xmm4, xmm9
00007cc2f47df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007cc2f47df081  ptest xmm3, xmm3
00007cc2f47df086  jnz 0x00007CC2F47E0BC5
00007cc2f47df08c  lea r12, [rax+0xE0]
00007cc2f47df093  movups xmm15, [r13+r12*1]
00007cc2f47df099  vmovaps xmm9, [rsp+0x70]
00007cc2f47df09f  vpermilpd xmm9, xmm9, 0x00
00007cc2f47df0a5  vmovaps [rsp+0x70], xmm1
00007cc2f47df0ab  vmovaps xmm1, [rsp+0x80]
00007cc2f47df0b4  vmovaps [rsp+0x80], xmm15
00007cc2f47df0bd  movaps xmm3, xmm1
00007cc2f47df0c0  mulpd xmm3, xmm9
00007cc2f47df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007cc2f47df0ca  ptest xmm15, xmm15
00007cc2f47df0d0  jnz 0x00007CC2F47E0D11
00007cc2f47df0d6  vmovaps xmm1, [rsp+0xF0]
00007cc2f47df0df  vmovaps xmm15, [rsp+0xF0]
00007cc2f47df0e8  por xmm1, xmm15
00007cc2f47df0ed  movaps [r15+0x300], xmm1
00007cc2f47df0f5  vmovaps xmm15, [rsp+0xE0]
00007cc2f47df0fe  vmovaps xmm9, [rsp+0xE0]
00007cc2f47df107  por xmm15, xmm9
00007cc2f47df10c  movaps [r15+0x190], xmm15
00007cc2f47df114  vmovaps xmm9, [rsp+0x50]
00007cc2f47df11a  vpermilpd xmm9, xmm9, 0x00
00007cc2f47df120  vmovaps [rsp+0x90], xmm1
00007cc2f47df129  vmovaps [rsp+0xE0], xmm15
00007cc2f47df132  vmovaps xmm15, [rsp+0x80]
00007cc2f47df13b  vmovaps [rsp+0x80], xmm14
00007cc2f47df144  movaps xmm1, xmm15
00007cc2f47df148  mulpd xmm1, xmm9
00007cc2f47df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007cc2f47df152  ptest xmm14, xmm14
00007cc2f47df158  jnz 0x00007CC2F47E0E52
00007cc2f47df15e  lea r12, [rax+0x90]
00007cc2f47df165  movups xmm15, [r13+r12*1]
00007cc2f47df16b  vmovaps xmm14, [rsp+0xD0]
00007cc2f47df174  vmovaps xmm9, [rsp+0xD0]
00007cc2f47df17d  por xmm14, xmm9
00007cc2f47df182  movaps [r15+0x1C0], xmm14
00007cc2f47df18a  vmovaps xmm9, [rsp+0xC0]
00007cc2f47df193  vmovaps [rsp+0xD0], xmm1
00007cc2f47df19c  vmovaps xmm1, [rsp+0xC0]
00007cc2f47df1a5  por xmm9, xmm1
00007cc2f47df1aa  movaps [r15+0x200], xmm9
00007cc2f47df1b2  vmovaps [rsp+0xC0], xmm2
00007cc2f47df1bb  vmovaps xmm1, [rsp+0xC0]
00007cc2f47df1c4  por xmm2, xmm1
00007cc2f47df1c8  movaps [r15+0x2D0], xmm2
00007cc2f47df1d0  vmovaps [rsp+0xC0], xmm8
00007cc2f47df1d9  vmovaps xmm1, [rsp+0xC0]
00007cc2f47df1e2  por xmm8, xmm1
00007cc2f47df1e7  movaps [r15+0x2E0], xmm8
00007cc2f47df1ef  vmovaps [rsp+0xC0], xmm15
00007cc2f47df1f8  movaps xmm1, xmm5
00007cc2f47df1fb  addpd xmm1, xmm7
00007cc2f47df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007cc2f47df204  ptest xmm15, xmm15
00007cc2f47df20a  jnz 0x00007CC2F47E0F9E
00007cc2f47df210  vmovaps xmm15, [rsp+0x50]
00007cc2f47df216  vpermilpd xmm15, xmm15, 0x00
00007cc2f47df21c  vmovaps xmm5, [rsp+0xC0]
00007cc2f47df225  vmovaps [rsp+0xC0], xmm1
00007cc2f47df22e  movaps xmm7, xmm5
00007cc2f47df231  mulpd xmm7, xmm15
00007cc2f47df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007cc2f47df23b  ptest xmm1, xmm1
00007cc2f47df240  jnz 0x00007CC2F47E10DE
00007cc2f47df246  lea r12, [rax+0x80]
00007cc2f47df24d  movups xmm1, [r13+r12*1]
00007cc2f47df253  vmovaps xmm5, [rsp+0x70]
00007cc2f47df259  vmovaps [rsp+0x70], xmm1
00007cc2f47df25f  movaps xmm15, xmm5
00007cc2f47df263  addpd xmm15, xmm3
00007cc2f47df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007cc2f47df26e  ptest xmm1, xmm1
00007cc2f47df273  jnz 0x00007CC2F47E1229
00007cc2f47df279  vmovaps xmm5, [rsp+0x80]
00007cc2f47df282  movaps xmm1, xmm5
00007cc2f47df285  addpd xmm1, xmm4
00007cc2f47df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007cc2f47df28e  ptest xmm3, xmm3
00007cc2f47df293  jnz 0x00007CC2F47E136B
00007cc2f47df299  vmovaps [rsp+0x80], xmm10
00007cc2f47df2a2  vmovaps xmm5, [rsp+0x80]
00007cc2f47df2ab  por xmm10, xmm5
00007cc2f47df2b0  movaps [r15+0x2F0], xmm10
00007cc2f47df2b8  vmovaps xmm5, [rsp+0x50]
00007cc2f47df2be  vpermilpd xmm5, xmm5, 0x00
00007cc2f47df2c4  vmovaps xmm3, [rsp+0x70]
00007cc2f47df2ca  vmovaps [rsp+0x50], xmm1
00007cc2f47df2d0  movaps xmm4, xmm3
00007cc2f47df2d3  mulpd xmm4, xmm5
00007cc2f47df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007cc2f47df2dc  ptest xmm1, xmm1
00007cc2f47df2e1  jnz 0x00007CC2F47E14AB
00007cc2f47df2e7  lea r12, [rax+0xD0]
00007cc2f47df2ee  movups xmm1, [r13+r12*1]
00007cc2f47df2f4  vmovaps xmm3, [rsp+0xD0]
00007cc2f47df2fd  vmovaps [rsp+0x70], xmm1
00007cc2f47df303  movaps xmm5, xmm6
00007cc2f47df306  addpd xmm5, xmm3
00007cc2f47df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007cc2f47df30f  ptest xmm1, xmm1
00007cc2f47df314  jnz 0x00007CC2F47E15F5
00007cc2f47df31a  vmovaps xmm1, [rsp+0x60]
00007cc2f47df320  vpermilpd xmm1, xmm1, 0x00
00007cc2f47df326  movaps xmm6, xmm9
00007cc2f47df32a  mulpd xmm6, xmm1
00007cc2f47df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007cc2f47df333  ptest xmm3, xmm3
00007cc2f47df338  jnz 0x00007CC2F47E1735
00007cc2f47df33e  movaps [r15+0x260], xmm6
00007cc2f47df346  vxorps xmm1, xmm1, xmm1
00007cc2f47df34a  vpbroadcastq xmm1, xmm1
00007cc2f47df34f  movaps [r15+0x1B0], xmm1
00007cc2f47df357  vmovaps xmm1, [rsp+0x60]
00007cc2f47df35d  vpermilpd xmm1, xmm1, 0x00
00007cc2f47df363  vmovaps xmm3, [rsp+0x70]
00007cc2f47df369  vmovaps [rsp+0x70], xmm15
00007cc2f47df36f  movaps xmm9, xmm3
00007cc2f47df373  mulpd xmm9, xmm1
00007cc2f47df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007cc2f47df37e  ptest xmm15, xmm15
00007cc2f47df384  jnz 0x00007CC2F47E1876
00007cc2f47df38a  lea r12, [rax+0xC0]
00007cc2f47df391  movups xmm1, [r13+r12*1]
00007cc2f47df397  vmovaps xmm3, [rsp+0xC0]
00007cc2f47df3a0  vmovaps [rsp+0x80], xmm1
00007cc2f47df3a9  movaps xmm15, xmm3
00007cc2f47df3ad  addpd xmm15, xmm7
00007cc2f47df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007cc2f47df3b8  ptest xmm1, xmm1
00007cc2f47df3bd  jnz 0x00007CC2F47E19C2
00007cc2f47df3c3  vmovaps [rsp+0xC0], xmm13
00007cc2f47df3cc  vmovaps xmm1, [rsp+0xC0]
00007cc2f47df3d5  por xmm13, xmm1
00007cc2f47df3da  movaps [r15+0x270], xmm13
00007cc2f47df3e2  vmovaps xmm1, [rsp+0xB0]
00007cc2f47df3eb  vmovaps xmm7, [rsp+0xB0]
00007cc2f47df3f4  por xmm1, xmm7
00007cc2f47df3f8  movaps [r15+0x1A0], xmm1
00007cc2f47df400  vmovaps xmm1, [rsp+0x60]
00007cc2f47df406  vpermilpd xmm1, xmm1, 0x00
00007cc2f47df40c  vmovaps [rsp+0xB0], xmm1
00007cc2f47df415  vmovaps xmm1, [rsp+0x80]
00007cc2f47df41e  vmovaps [rsp+0x80], xmm15
00007cc2f47df427  vmovaps xmm15, [rsp+0xB0]
00007cc2f47df430  vmovaps [rsp+0xB0], xmm14
00007cc2f47df439  movaps xmm3, xmm1
00007cc2f47df43c  mulpd xmm3, xmm15
00007cc2f47df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007cc2f47df446  ptest xmm14, xmm14
00007cc2f47df44c  jnz 0x00007CC2F47E1B04
00007cc2f47df452  lea r12, [rax+0x20]
00007cc2f47df456  movups xmm1, [r13+r12*1]
00007cc2f47df45c  movaps [r15+0x110], xmm1
00007cc2f47df464  vmovaps xmm14, [rsp+0x70]
00007cc2f47df46a  vmovaps [rsp+0x70], xmm1
00007cc2f47df470  movaps xmm15, xmm14
00007cc2f47df474  addpd xmm15, xmm4
00007cc2f47df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007cc2f47df47f  ptest xmm1, xmm1
00007cc2f47df484  jnz 0x00007CC2F47E1C4F
00007cc2f47df48a  vmovaps xmm1, [rsp+0x60]
00007cc2f47df490  vpermilpd xmm1, xmm1, 0x00
00007cc2f47df496  movaps xmm14, xmm2
00007cc2f47df49a  mulpd xmm14, xmm1
00007cc2f47df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007cc2f47df4a5  ptest xmm4, xmm4
00007cc2f47df4aa  jnz 0x00007CC2F47E1D92
00007cc2f47df4b0  vmovaps xmm4, [rsp+0x50]
00007cc2f47df4b6  movaps xmm1, xmm4
00007cc2f47df4b9  addpd xmm1, xmm9
00007cc2f47df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007cc2f47df4c3  ptest xmm2, xmm2
00007cc2f47df4c8  jnz 0x00007CC2F47E1ED4
00007cc2f47df4ce  vmovaps xmm9, [rsp+0x30]
00007cc2f47df4d4  vpermilpd xmm9, xmm9, 0x00
00007cc2f47df4da  vmovaps xmm2, [rsp+0x70]
00007cc2f47df4e0  vmovaps [rsp+0x50], xmm1
00007cc2f47df4e6  movaps xmm4, xmm2
00007cc2f47df4e9  mulpd xmm4, xmm9
00007cc2f47df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007cc2f47df4f3  ptest xmm1, xmm1
00007cc2f47df4f8  jnz 0x00007CC2F47E2015
00007cc2f47df4fe  vmovaps xmm1, [rsp+0x30]
00007cc2f47df504  vpermilpd xmm1, xmm1, 0x00
00007cc2f47df50a  vmovaps xmm2, [rsp+0x90]
00007cc2f47df513  vmovaps [rsp+0x60], xmm15
00007cc2f47df519  movaps xmm9, xmm2
00007cc2f47df51d  mulpd xmm9, xmm1
00007cc2f47df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007cc2f47df528  ptest xmm15, xmm15
00007cc2f47df52e  jnz 0x00007CC2F47E2156
00007cc2f47df534  vmovaps xmm15, [rsp+0x80]
00007cc2f47df53d  movaps xmm1, xmm15
00007cc2f47df541  addpd xmm1, xmm6
00007cc2f47df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007cc2f47df54a  ptest xmm2, xmm2
00007cc2f47df54f  jnz 0x00007CC2F47E2298
00007cc2f47df555  movaps xmm15, xmm5
00007cc2f47df559  addpd xmm15, xmm3
00007cc2f47df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007cc2f47df564  ptest xmm6, xmm6
00007cc2f47df569  jnz 0x00007CC2F47E23D9
00007cc2f47df56f  vmovaps xmm6, [rsp+0x30]
00007cc2f47df575  vpermilpd xmm6, xmm6, 0x00
00007cc2f47df57b  movaps xmm5, xmm8
00007cc2f47df57f  mulpd xmm5, xmm6
00007cc2f47df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007cc2f47df588  ptest xmm3, xmm3
00007cc2f47df58d  jnz 0x00007CC2F47E251B
00007cc2f47df593  vmovaps xmm8, [rsp+0x30]
00007cc2f47df599  vpermilpd xmm8, xmm8, 0x00
00007cc2f47df59f  movaps xmm6, xmm10
00007cc2f47df5a3  mulpd xmm6, xmm8
00007cc2f47df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007cc2f47df5ad  ptest xmm3, xmm3
00007cc2f47df5b2  jnz 0x00007CC2F47E265C
00007cc2f47df5b8  vmovaps xmm8, [rsp+0x60]
00007cc2f47df5be  movaps xmm10, xmm8
00007cc2f47df5c2  addpd xmm10, xmm14
00007cc2f47df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007cc2f47df5cd  ptest xmm3, xmm3
00007cc2f47df5d2  jnz 0x00007CC2F47E279E
00007cc2f47df5d8  vmovaps xmm8, [rsp+0x50]
00007cc2f47df5de  movaps xmm14, xmm8
00007cc2f47df5e2  addpd xmm14, xmm4
00007cc2f47df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007cc2f47df5ed  ptest xmm3, xmm3
00007cc2f47df5f2  jnz 0x00007CC2F47E28E2
00007cc2f47df5f8  vmovaps xmm8, [rsp+0x40]
00007cc2f47df5fe  vpermilpd xmm8, xmm8, 0x00
00007cc2f47df604  movaps xmm4, xmm13
00007cc2f47df608  mulpd xmm4, xmm8
00007cc2f47df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007cc2f47df612  ptest xmm3, xmm3
00007cc2f47df617  jnz 0x00007CC2F47E2A25
00007cc2f47df61d  movaps xmm13, xmm15
00007cc2f47df621  addpd xmm13, xmm9
00007cc2f47df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007cc2f47df62c  ptest xmm8, xmm8
00007cc2f47df632  jnz 0x00007CC2F47E2B67
00007cc2f47df638  movaps xmm15, xmm1
00007cc2f47df63c  addpd xmm15, xmm5
00007cc2f47df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007cc2f47df647  ptest xmm9, xmm9
00007cc2f47df64d  jnz 0x00007CC2F47E2CAB
00007cc2f47df653  vmovaps [rsp+0x30], xmm11
00007cc2f47df659  vmovaps xmm1, [rsp+0x30]
00007cc2f47df65f  por xmm11, xmm1
00007cc2f47df664  movaps [r15+0x250], xmm11
00007cc2f47df66c  vmovaps [rsp+0x30], xmm12
00007cc2f47df672  vmovaps xmm1, [rsp+0x30]
00007cc2f47df678  por xmm12, xmm1
00007cc2f47df67d  movaps [r15+0x2A0], xmm12
00007cc2f47df685  vmovaps xmm1, [rsp+0xA0]
00007cc2f47df68e  vmovaps xmm11, [rsp+0xA0]
00007cc2f47df697  por xmm1, xmm11
00007cc2f47df69c  movaps [r15+0x1D0], xmm1
00007cc2f47df6a4  lea r12, [rax+0x40]
00007cc2f47df6a8  movups xmm1, [r13+r12*1]
00007cc2f47df6ae  movaps [r15+0x2C0], xmm1
00007cc2f47df6b6  vmovaps xmm11, [rsp+0x40]
00007cc2f47df6bc  vpermilpd xmm11, xmm11, 0x00
00007cc2f47df6c2  vmovaps xmm8, [rsp+0xE0]
00007cc2f47df6cb  movaps xmm9, xmm8
00007cc2f47df6cf  mulpd xmm9, xmm11
00007cc2f47df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007cc2f47df6da  ptest xmm5, xmm5
00007cc2f47df6df  jnz 0x00007CC2F47E2DF7
00007cc2f47df6e5  movaps xmm11, xmm10
00007cc2f47df6e9  addpd xmm11, xmm6
00007cc2f47df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007cc2f47df6f4  ptest xmm8, xmm8
00007cc2f47df6fa  jnz 0x00007CC2F47E2F3B
00007cc2f47df700  movaps xmm10, xmm14
00007cc2f47df704  addpd xmm10, xmm4
00007cc2f47df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007cc2f47df70f  ptest xmm8, xmm8
00007cc2f47df715  jnz 0x00007CC2F47E307E
00007cc2f47df71b  vmovaps xmm14, [rsp+0x40]
00007cc2f47df721  vpermilpd xmm14, xmm14, 0x00
00007cc2f47df727  movaps xmm8, xmm1
00007cc2f47df72b  mulpd xmm8, xmm14
00007cc2f47df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007cc2f47df736  ptest xmm6, xmm6
00007cc2f47df73b  jnz 0x00007CC2F47E31C1
00007cc2f47df741  movaps xmm1, [r15+0x2B0]
00007cc2f47df749  vmovaps xmm14, [rsp+0x40]
00007cc2f47df74f  vpermilpd xmm14, xmm14, 0x00
00007cc2f47df755  movaps xmm6, xmm1
00007cc2f47df758  mulpd xmm6, xmm14
00007cc2f47df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007cc2f47df762  ptest xmm5, xmm5
00007cc2f47df767  jnz 0x00007CC2F47E3304
00007cc2f47df76d  vmovaps xmm1, [rsp+0x10]
00007cc2f47df773  vpermilpd xmm1, xmm1, 0x00
00007cc2f47df779  movaps xmm14, xmm12
00007cc2f47df77d  mulpd xmm14, xmm1
00007cc2f47df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007cc2f47df788  ptest xmm5, xmm5
00007cc2f47df78d  jnz 0x00007CC2F47E3445
00007cc2f47df793  movaps xmm1, xmm13
00007cc2f47df797  addpd xmm1, xmm9
00007cc2f47df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007cc2f47df7a1  ptest xmm12, xmm12
00007cc2f47df7a7  jnz 0x00007CC2F47E3588
00007cc2f47df7ad  vmovaps xmm13, [rsp+0x10]
00007cc2f47df7b3  vpermilpd xmm13, xmm13, 0x00
00007cc2f47df7b9  movaps xmm12, xmm7
00007cc2f47df7bd  mulpd xmm12, xmm13
00007cc2f47df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007cc2f47df7c8  ptest xmm9, xmm9
00007cc2f47df7ce  jnz 0x00007CC2F47E36CA
00007cc2f47df7d4  movaps xmm13, xmm15
00007cc2f47df7d8  addpd xmm13, xmm8
00007cc2f47df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007cc2f47df7e3  ptest xmm9, xmm9
00007cc2f47df7e9  jnz 0x00007CC2F47E380D
00007cc2f47df7ef  movaps xmm15, [r15+0x290]
00007cc2f47df7f7  vmovaps xmm9, [rsp+0x10]
00007cc2f47df7fd  vpermilpd xmm9, xmm9, 0x00
00007cc2f47df803  movaps xmm8, xmm15
00007cc2f47df807  mulpd xmm8, xmm9
00007cc2f47df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007cc2f47df812  ptest xmm7, xmm7
00007cc2f47df817  jnz 0x00007CC2F47E3951
00007cc2f47df81d  movaps xmm15, xmm11
00007cc2f47df821  addpd xmm15, xmm6
00007cc2f47df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007cc2f47df82c  ptest xmm9, xmm9
00007cc2f47df832  jnz 0x00007CC2F47E3A95
00007cc2f47df838  movaps xmm11, [r15+0x1E0]
00007cc2f47df840  vmovaps xmm9, [rsp+0x10]
00007cc2f47df846  vpermilpd xmm9, xmm9, 0x00
00007cc2f47df84c  movaps xmm7, xmm11
00007cc2f47df850  mulpd xmm7, xmm9
00007cc2f47df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2f47df85a  ptest xmm6, xmm6
00007cc2f47df85f  jnz 0x00007CC2F47E3BD8
00007cc2f47df865  movaps xmm11, xmm10
00007cc2f47df869  addpd xmm11, xmm14
00007cc2f47df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007cc2f47df874  ptest xmm9, xmm9
00007cc2f47df87a  jnz 0x00007CC2F47E3D1A
00007cc2f47df880  lea r12, [rax+0x70]
00007cc2f47df884  movups xmm14, [r13+r12*1]
00007cc2f47df88a  movaps [r15+0x240], xmm14
00007cc2f47df892  movaps xmm10, xmm1
00007cc2f47df896  addpd xmm10, xmm12
00007cc2f47df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007cc2f47df8a1  ptest xmm9, xmm9
00007cc2f47df8a7  jnz 0x00007CC2F47E3E68
00007cc2f47df8ad  movaps [r15+0x170], xmm10
00007cc2f47df8b5  vmovaps xmm1, [rsp+0x20]
00007cc2f47df8bb  vpermilpd xmm1, xmm1, 0x00
00007cc2f47df8c1  movaps xmm12, xmm14
00007cc2f47df8c5  mulpd xmm12, xmm1
00007cc2f47df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007cc2f47df8d0  ptest xmm9, xmm9
00007cc2f47df8d6  jnz 0x00007CC2F47E3FAB
00007cc2f47df8dc  vmovaps xmm1, [rsp+0x20]
00007cc2f47df8e2  vpermilpd xmm1, xmm1, 0x00
00007cc2f47df8e8  vmovaps xmm9, [rsp+0xB0]
00007cc2f47df8f1  movaps xmm14, xmm9
00007cc2f47df8f5  mulpd xmm14, xmm1
00007cc2f47df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007cc2f47df900  ptest xmm6, xmm6
00007cc2f47df905  jnz 0x00007CC2F47E40EE
00007cc2f47df90b  movaps [r15+0x180], xmm14
00007cc2f47df913  movaps xmm1, xmm13
00007cc2f47df917  addpd xmm1, xmm8
00007cc2f47df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007cc2f47df921  ptest xmm9, xmm9
00007cc2f47df927  jnz 0x00007CC2F47E4231
00007cc2f47df92d  movaps [r15+0x210], xmm1
00007cc2f47df935  movups xmm13, [r13+rax*1]
00007cc2f47df93b  lea r12, [rax+0x10]
00007cc2f47df93f  movups xmm9, [r13+r12*1]
00007cc2f47df945  movaps [r15+0x230], xmm9
00007cc2f47df94d  movaps xmm8, xmm15
00007cc2f47df951  addpd xmm8, xmm7
00007cc2f47df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007cc2f47df95c  ptest xmm6, xmm6
00007cc2f47df961  jnz 0x00007CC2F47E4387
00007cc2f47df967  movaps [r15+0x130], xmm8
00007cc2f47df96f  vmovaps xmm15, [rsp+0x20]
00007cc2f47df975  vpermilpd xmm15, xmm15, 0x00
00007cc2f47df97b  movaps xmm7, xmm9
00007cc2f47df97f  mulpd xmm7, xmm15
00007cc2f47df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007cc2f47df989  ptest xmm6, xmm6
00007cc2f47df98e  jnz 0x00007CC2F47E44CA
00007cc2f47df994  movaps [r15+0x220], xmm7
00007cc2f47df99c  vmovaps xmm15, [rsp+0x20]
00007cc2f47df9a2  vpermilpd xmm15, xmm15, 0x00
00007cc2f47df9a8  movaps xmm9, xmm13
00007cc2f47df9ac  mulpd xmm9, xmm15
00007cc2f47df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007cc2f47df9b7  ptest xmm6, xmm6
00007cc2f47df9bc  jnz 0x00007CC2F47E460C
00007cc2f47df9c2  movaps xmm15, xmm11
00007cc2f47df9c6  addpd xmm15, xmm12
00007cc2f47df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007cc2f47df9d1  ptest xmm13, xmm13
00007cc2f47df9d7  jnz 0x00007CC2F47E4750
00007cc2f47df9dd  movaps [r15+0x140], xmm15
00007cc2f47df9e5  movaps xmm13, xmm10
00007cc2f47df9e9  addpd xmm13, xmm14
00007cc2f47df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007cc2f47df9f4  ptest xmm12, xmm12
00007cc2f47df9fa  jnz 0x00007CC2F47E4894
00007cc2f47dfa00  movaps [r15+0x150], xmm13
00007cc2f47dfa08  movaps xmm14, xmm1
00007cc2f47dfa0c  addpd xmm14, xmm7
00007cc2f47dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007cc2f47dfa17  ptest xmm12, xmm12
00007cc2f47dfa1d  jnz 0x00007CC2F47E49D8
00007cc2f47dfa23  movaps [r15+0x160], xmm14
00007cc2f47dfa2b  movaps xmm1, xmm8
00007cc2f47dfa2f  addpd xmm1, xmm9
00007cc2f47dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007cc2f47dfa39  ptest xmm12, xmm12
00007cc2f47dfa3f  jnz 0x00007CC2F47E4B1A
00007cc2f47dfa45  movaps [r15+0x120], xmm1
00007cc2f47dfa4d  movups [r13+r14*1], xmm15
00007cc2f47dfa53  lea rax, [r14+0x10]
00007cc2f47dfa57  movups [r13+rax*1], xmm13
00007cc2f47dfa5d  lea rax, [r14+0x20]
00007cc2f47dfa61  movups [r13+rax*1], xmm14
00007cc2f47dfa67  lea rax, [r14+0x30]
00007cc2f47dfa6b  movups [r13+rax*1], xmm1
00007cc2f47dfa71  mov eax, [r15+0x108]
00007cc2f47dfa78  sahf
00007cc2f47dfa79  jnz 0x00007CC2F47DFAAB
00007cc2f47dfa7b  cmp dword ptr [r15+0x318], 0x00
00007cc2f47dfa83  jz 0x00007CC2F47DEAE0
00007cc2f47dfa89  nop [rax+rax*1], ax
00007cc2f47dfa92  nop [rax+rax*1], eax
00007cc2f47dfa9a  mov eax, 0x4106D0
00007cc2f47dfa9f  mov [r15+0x100], rax
00007cc2f47dfaa6  jmp 0x00007CC2F45FE110
00007cc2f47dfaab  cmp dword ptr [r15+0x318], 0x00
00007cc2f47dfab3  jz 0x00007CC2F47D89C0
00007cc2f47dfab9  nop [rax+rax*1], ax
00007cc2f47dfac2  nop [rax+rax*1], eax
00007cc2f47dfaca  mov eax, 0x410504
00007cc2f47dfacf  mov [r15+0x100], rax
00007cc2f47dfad6  jmp 0x00007CC2F45FE110
00007cc2f47dfadb  int3
00007cc2f47dfadc  call 0x00007CC2F46E27E0
00007cc2f47dfae1  jmp 0x00007CC2F47DEBBF
00007cc2f47dfae6  call 0x00007CC2F46E1570
00007cc2f47dfaeb  jmp 0x00007CC2F47DEBC8
00007cc2f47dfaf0  call 0x00007CC2F46E27E0
00007cc2f47dfaf5  jmp 0x00007CC2F47DEC24
00007cc2f47dfafa  call 0x00007CC2F46E1570
00007cc2f47dfaff  jmp 0x00007CC2F47DEC2D
00007cc2f47dfb04  call 0x00007CC2F46E27E0
00007cc2f47dfb09  jmp 0x00007CC2F47DEC70
00007cc2f47dfb0e  call 0x00007CC2F46E1570
00007cc2f47dfb13  jmp 0x00007CC2F47DEC79
00007cc2f47dfb18  call 0x00007CC2F460DC20
00007cc2f47dfb1d  jmp 0x00007CC2F47DECB8
00007cc2f47dfb22  call 0x00007CC2F46D59C0
00007cc2f47dfb27  jmp 0x00007CC2F47DECCB
00007cc2f47dfb2c  call 0x00007CC2F46E0E30
00007cc2f47dfb31  jmp 0x00007CC2F47DECE9
00007cc2f47dfb36  call 0x00007CC2F46DFBC0
00007cc2f47dfb3b  jmp 0x00007CC2F47DECF3
00007cc2f47dfb40  call 0x00007CC2F46DE950
00007cc2f47dfb45  jmp 0x00007CC2F47DECFD
00007cc2f47dfb4a  sub rsp, 0x08
00007cc2f47dfb4e  push rax
00007cc2f47dfb4f  push rcx
00007cc2f47dfb50  push rdx
00007cc2f47dfb51  push rdi
00007cc2f47dfb52  push rsi
00007cc2f47dfb53  push r8
00007cc2f47dfb55  push r9
00007cc2f47dfb57  push r10
00007cc2f47dfb59  push r11
00007cc2f47dfb5b  sub rsp, 0xF0
00007cc2f47dfb62  vmovaps [rsp], xmm0
00007cc2f47dfb67  vmovaps [rsp+0x10], xmm1
00007cc2f47dfb6d  vmovaps [rsp+0x20], xmm2
00007cc2f47dfb73  vmovaps [rsp+0x30], xmm3
00007cc2f47dfb79  vmovaps [rsp+0x40], xmm4
00007cc2f47dfb7f  vmovaps [rsp+0x50], xmm5
00007cc2f47dfb85  vmovaps [rsp+0x60], xmm6
00007cc2f47dfb8b  vmovaps [rsp+0x70], xmm7
00007cc2f47dfb91  vmovaps [rsp+0x80], xmm9
00007cc2f47dfb9a  vmovaps [rsp+0x90], xmm10
00007cc2f47dfba3  vmovaps [rsp+0xA0], xmm11
00007cc2f47dfbac  vmovaps [rsp+0xB0], xmm12
00007cc2f47dfbb5  vmovaps [rsp+0xC0], xmm13
00007cc2f47dfbbe  vmovaps [rsp+0xD0], xmm14
00007cc2f47dfbc7  vmovaps [rsp+0xE0], xmm15
00007cc2f47dfbd0  sub rsp, 0x30
00007cc2f47dfbd4  movaps [rsp], xmm8
00007cc2f47dfbd9  movaps [rsp+0x10], xmm12
00007cc2f47dfbdf  movaps [rsp+0x20], xmm15
00007cc2f47dfbe5  lea rdi, [rsp]
00007cc2f47dfbe9  mov esi, 0x00
00007cc2f47dfbee  mov rax, 0x5990E710A530
00007cc2f47dfbf8  call rax
00007cc2f47dfbfa  movaps xmm8, [rsp]
00007cc2f47dfbff  add rsp, 0x30
00007cc2f47dfc03  vmovaps xmm0, [rsp]
00007cc2f47dfc08  vmovaps xmm1, [rsp+0x10]
00007cc2f47dfc0e  vmovaps xmm2, [rsp+0x20]
00007cc2f47dfc14  vmovaps xmm3, [rsp+0x30]
00007cc2f47dfc1a  vmovaps xmm4, [rsp+0x40]
00007cc2f47dfc20  vmovaps xmm5, [rsp+0x50]
00007cc2f47dfc26  vmovaps xmm6, [rsp+0x60]
00007cc2f47dfc2c  vmovaps xmm7, [rsp+0x70]
00007cc2f47dfc32  vmovaps xmm9, [rsp+0x80]
00007cc2f47dfc3b  vmovaps xmm10, [rsp+0x90]
00007cc2f47dfc44  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dfc4d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dfc56  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dfc5f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dfc68  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dfc71  add rsp, 0xF0
00007cc2f47dfc78  pop r11
00007cc2f47dfc7a  pop r10
00007cc2f47dfc7c  pop r9
00007cc2f47dfc7e  pop r8
00007cc2f47dfc80  pop rsi
00007cc2f47dfc81  pop rdi
00007cc2f47dfc82  pop rdx
00007cc2f47dfc83  pop rcx
00007cc2f47dfc84  pop rax
00007cc2f47dfc85  add rsp, 0x08
00007cc2f47dfc89  jmp 0x00007CC2F47DED27
00007cc2f47dfc8e  sub rsp, 0x08
00007cc2f47dfc92  push rax
00007cc2f47dfc93  push rcx
00007cc2f47dfc94  push rdx
00007cc2f47dfc95  push rdi
00007cc2f47dfc96  push rsi
00007cc2f47dfc97  push r8
00007cc2f47dfc99  push r9
00007cc2f47dfc9b  push r10
00007cc2f47dfc9d  push r11
00007cc2f47dfc9f  sub rsp, 0xF0
00007cc2f47dfca6  vmovaps [rsp], xmm0
00007cc2f47dfcab  vmovaps [rsp+0x10], xmm1
00007cc2f47dfcb1  vmovaps [rsp+0x20], xmm2
00007cc2f47dfcb7  vmovaps [rsp+0x30], xmm3
00007cc2f47dfcbd  vmovaps [rsp+0x40], xmm4
00007cc2f47dfcc3  vmovaps [rsp+0x50], xmm5
00007cc2f47dfcc9  vmovaps [rsp+0x60], xmm6
00007cc2f47dfccf  vmovaps [rsp+0x70], xmm8
00007cc2f47dfcd5  vmovaps [rsp+0x80], xmm9
00007cc2f47dfcde  vmovaps [rsp+0x90], xmm10
00007cc2f47dfce7  vmovaps [rsp+0xA0], xmm11
00007cc2f47dfcf0  vmovaps [rsp+0xB0], xmm12
00007cc2f47dfcf9  vmovaps [rsp+0xC0], xmm13
00007cc2f47dfd02  vmovaps [rsp+0xD0], xmm14
00007cc2f47dfd0b  vmovaps [rsp+0xE0], xmm15
00007cc2f47dfd14  sub rsp, 0x30
00007cc2f47dfd18  movaps [rsp], xmm7
00007cc2f47dfd1c  movaps [rsp+0x10], xmm9
00007cc2f47dfd22  movaps [rsp+0x20], xmm15
00007cc2f47dfd28  lea rdi, [rsp]
00007cc2f47dfd2c  mov esi, 0x00
00007cc2f47dfd31  mov rax, 0x5990E710A530
00007cc2f47dfd3b  call rax
00007cc2f47dfd3d  movaps xmm7, [rsp]
00007cc2f47dfd41  add rsp, 0x30
00007cc2f47dfd45  vmovaps xmm0, [rsp]
00007cc2f47dfd4a  vmovaps xmm1, [rsp+0x10]
00007cc2f47dfd50  vmovaps xmm2, [rsp+0x20]
00007cc2f47dfd56  vmovaps xmm3, [rsp+0x30]
00007cc2f47dfd5c  vmovaps xmm4, [rsp+0x40]
00007cc2f47dfd62  vmovaps xmm5, [rsp+0x50]
00007cc2f47dfd68  vmovaps xmm6, [rsp+0x60]
00007cc2f47dfd6e  vmovaps xmm8, [rsp+0x70]
00007cc2f47dfd74  vmovaps xmm9, [rsp+0x80]
00007cc2f47dfd7d  vmovaps xmm10, [rsp+0x90]
00007cc2f47dfd86  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dfd8f  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dfd98  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dfda1  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dfdaa  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dfdb3  add rsp, 0xF0
00007cc2f47dfdba  pop r11
00007cc2f47dfdbc  pop r10
00007cc2f47dfdbe  pop r9
00007cc2f47dfdc0  pop r8
00007cc2f47dfdc2  pop rsi
00007cc2f47dfdc3  pop rdi
00007cc2f47dfdc4  pop rdx
00007cc2f47dfdc5  pop rcx
00007cc2f47dfdc6  pop rax
00007cc2f47dfdc7  add rsp, 0x08
00007cc2f47dfdcb  jmp 0x00007CC2F47DED55
00007cc2f47dfdd0  sub rsp, 0x08
00007cc2f47dfdd4  push rax
00007cc2f47dfdd5  push rcx
00007cc2f47dfdd6  push rdx
00007cc2f47dfdd7  push rdi
00007cc2f47dfdd8  push rsi
00007cc2f47dfdd9  push r8
00007cc2f47dfddb  push r9
00007cc2f47dfddd  push r10
00007cc2f47dfddf  push r11
00007cc2f47dfde1  sub rsp, 0xF0
00007cc2f47dfde8  vmovaps [rsp], xmm0
00007cc2f47dfded  vmovaps [rsp+0x10], xmm1
00007cc2f47dfdf3  vmovaps [rsp+0x20], xmm2
00007cc2f47dfdf9  vmovaps [rsp+0x30], xmm3
00007cc2f47dfdff  vmovaps [rsp+0x40], xmm4
00007cc2f47dfe05  vmovaps [rsp+0x50], xmm5
00007cc2f47dfe0b  vmovaps [rsp+0x60], xmm6
00007cc2f47dfe11  vmovaps [rsp+0x70], xmm7
00007cc2f47dfe17  vmovaps [rsp+0x80], xmm8
00007cc2f47dfe20  vmovaps [rsp+0x90], xmm10
00007cc2f47dfe29  vmovaps [rsp+0xA0], xmm11
00007cc2f47dfe32  vmovaps [rsp+0xB0], xmm12
00007cc2f47dfe3b  vmovaps [rsp+0xC0], xmm13
00007cc2f47dfe44  vmovaps [rsp+0xD0], xmm14
00007cc2f47dfe4d  vmovaps [rsp+0xE0], xmm15
00007cc2f47dfe56  sub rsp, 0x30
00007cc2f47dfe5a  movaps [rsp], xmm9
00007cc2f47dfe5f  movaps [rsp+0x10], xmm12
00007cc2f47dfe65  movaps [rsp+0x20], xmm10
00007cc2f47dfe6b  lea rdi, [rsp]
00007cc2f47dfe6f  mov esi, 0x00
00007cc2f47dfe74  mov rax, 0x5990E710A530
00007cc2f47dfe7e  call rax
00007cc2f47dfe80  movaps xmm9, [rsp]
00007cc2f47dfe85  add rsp, 0x30
00007cc2f47dfe89  vmovaps xmm0, [rsp]
00007cc2f47dfe8e  vmovaps xmm1, [rsp+0x10]
00007cc2f47dfe94  vmovaps xmm2, [rsp+0x20]
00007cc2f47dfe9a  vmovaps xmm3, [rsp+0x30]
00007cc2f47dfea0  vmovaps xmm4, [rsp+0x40]
00007cc2f47dfea6  vmovaps xmm5, [rsp+0x50]
00007cc2f47dfeac  vmovaps xmm6, [rsp+0x60]
00007cc2f47dfeb2  vmovaps xmm7, [rsp+0x70]
00007cc2f47dfeb8  vmovaps xmm8, [rsp+0x80]
00007cc2f47dfec1  vmovaps xmm10, [rsp+0x90]
00007cc2f47dfeca  vmovaps xmm11, [rsp+0xA0]
00007cc2f47dfed3  vmovaps xmm12, [rsp+0xB0]
00007cc2f47dfedc  vmovaps xmm13, [rsp+0xC0]
00007cc2f47dfee5  vmovaps xmm14, [rsp+0xD0]
00007cc2f47dfeee  vmovaps xmm15, [rsp+0xE0]
00007cc2f47dfef7  add rsp, 0xF0
00007cc2f47dfefe  pop r11
00007cc2f47dff00  pop r10
00007cc2f47dff02  pop r9
00007cc2f47dff04  pop r8
00007cc2f47dff06  pop rsi
00007cc2f47dff07  pop rdi
00007cc2f47dff08  pop rdx
00007cc2f47dff09  pop rcx
00007cc2f47dff0a  pop rax
00007cc2f47dff0b  add rsp, 0x08
00007cc2f47dff0f  jmp 0x00007CC2F47DED79
00007cc2f47dff14  sub rsp, 0x08
00007cc2f47dff18  push rax
00007cc2f47dff19  push rcx
00007cc2f47dff1a  push rdx
00007cc2f47dff1b  push rdi
00007cc2f47dff1c  push rsi
00007cc2f47dff1d  push r8
00007cc2f47dff1f  push r9
00007cc2f47dff21  push r10
00007cc2f47dff23  push r11
00007cc2f47dff25  sub rsp, 0xF0
00007cc2f47dff2c  vmovaps [rsp], xmm0
00007cc2f47dff31  vmovaps [rsp+0x10], xmm1
00007cc2f47dff37  vmovaps [rsp+0x20], xmm2
00007cc2f47dff3d  vmovaps [rsp+0x30], xmm3
00007cc2f47dff43  vmovaps [rsp+0x40], xmm4
00007cc2f47dff49  vmovaps [rsp+0x50], xmm5
00007cc2f47dff4f  vmovaps [rsp+0x60], xmm6
00007cc2f47dff55  vmovaps [rsp+0x70], xmm7
00007cc2f47dff5b  vmovaps [rsp+0x80], xmm8
00007cc2f47dff64  vmovaps [rsp+0x90], xmm9
00007cc2f47dff6d  vmovaps [rsp+0xA0], xmm11
00007cc2f47dff76  vmovaps [rsp+0xB0], xmm12
00007cc2f47dff7f  vmovaps [rsp+0xC0], xmm13
00007cc2f47dff88  vmovaps [rsp+0xD0], xmm14
00007cc2f47dff91  vmovaps [rsp+0xE0], xmm15
00007cc2f47dff9a  sub rsp, 0x30
00007cc2f47dff9e  movaps [rsp], xmm10
00007cc2f47dffa3  movaps [rsp+0x10], xmm12
00007cc2f47dffa9  movaps [rsp+0x20], xmm11
00007cc2f47dffaf  lea rdi, [rsp]
00007cc2f47dffb3  mov esi, 0x00
00007cc2f47dffb8  mov rax, 0x5990E710A530
00007cc2f47dffc2  call rax
00007cc2f47dffc4  movaps xmm10, [rsp]
00007cc2f47dffc9  add rsp, 0x30
00007cc2f47dffcd  vmovaps xmm0, [rsp]
00007cc2f47dffd2  vmovaps xmm1, [rsp+0x10]
00007cc2f47dffd8  vmovaps xmm2, [rsp+0x20]
00007cc2f47dffde  vmovaps xmm3, [rsp+0x30]
00007cc2f47dffe4  vmovaps xmm4, [rsp+0x40]
00007cc2f47dffea  vmovaps xmm5, [rsp+0x50]
00007cc2f47dfff0  vmovaps xmm6, [rsp+0x60]
00007cc2f47dfff6  vmovaps xmm7, [rsp+0x70]
00007cc2f47dfffc  vmovaps xmm8, [rsp+0x80]
00007cc2f47e0005  vmovaps xmm9, [rsp+0x90]
00007cc2f47e000e  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0017  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e0020  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e0029  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e0032  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e003b  add rsp, 0xF0
00007cc2f47e0042  pop r11
00007cc2f47e0044  pop r10
00007cc2f47e0046  pop r9
00007cc2f47e0048  pop r8
00007cc2f47e004a  pop rsi
00007cc2f47e004b  pop rdi
00007cc2f47e004c  pop rdx
00007cc2f47e004d  pop rcx
00007cc2f47e004e  pop rax
00007cc2f47e004f  add rsp, 0x08
00007cc2f47e0053  jmp 0x00007CC2F47DED93
00007cc2f47e0058  sub rsp, 0x08
00007cc2f47e005c  push rax
00007cc2f47e005d  push rcx
00007cc2f47e005e  push rdx
00007cc2f47e005f  push rdi
00007cc2f47e0060  push rsi
00007cc2f47e0061  push r8
00007cc2f47e0063  push r9
00007cc2f47e0065  push r10
00007cc2f47e0067  push r11
00007cc2f47e0069  sub rsp, 0xF0
00007cc2f47e0070  vmovaps [rsp], xmm0
00007cc2f47e0075  vmovaps [rsp+0x10], xmm1
00007cc2f47e007b  vmovaps [rsp+0x20], xmm2
00007cc2f47e0081  vmovaps [rsp+0x30], xmm3
00007cc2f47e0087  vmovaps [rsp+0x40], xmm4
00007cc2f47e008d  vmovaps [rsp+0x50], xmm5
00007cc2f47e0093  vmovaps [rsp+0x60], xmm7
00007cc2f47e0099  vmovaps [rsp+0x70], xmm8
00007cc2f47e009f  vmovaps [rsp+0x80], xmm9
00007cc2f47e00a8  vmovaps [rsp+0x90], xmm10
00007cc2f47e00b1  vmovaps [rsp+0xA0], xmm11
00007cc2f47e00ba  vmovaps [rsp+0xB0], xmm12
00007cc2f47e00c3  vmovaps [rsp+0xC0], xmm13
00007cc2f47e00cc  vmovaps [rsp+0xD0], xmm14
00007cc2f47e00d5  vmovaps [rsp+0xE0], xmm15
00007cc2f47e00de  sub rsp, 0x30
00007cc2f47e00e2  movaps [rsp], xmm6
00007cc2f47e00e6  movaps [rsp+0x10], xmm12
00007cc2f47e00ec  movaps [rsp+0x20], xmm11
00007cc2f47e00f2  lea rdi, [rsp]
00007cc2f47e00f6  mov esi, 0x00
00007cc2f47e00fb  mov rax, 0x5990E710A530
00007cc2f47e0105  call rax
00007cc2f47e0107  movaps xmm6, [rsp]
00007cc2f47e010b  add rsp, 0x30
00007cc2f47e010f  vmovaps xmm0, [rsp]
00007cc2f47e0114  vmovaps xmm1, [rsp+0x10]
00007cc2f47e011a  vmovaps xmm2, [rsp+0x20]
00007cc2f47e0120  vmovaps xmm3, [rsp+0x30]
00007cc2f47e0126  vmovaps xmm4, [rsp+0x40]
00007cc2f47e012c  vmovaps xmm5, [rsp+0x50]
00007cc2f47e0132  vmovaps xmm7, [rsp+0x60]
00007cc2f47e0138  vmovaps xmm8, [rsp+0x70]
00007cc2f47e013e  vmovaps xmm9, [rsp+0x80]
00007cc2f47e0147  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0150  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0159  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e0162  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e016b  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e0174  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e017d  add rsp, 0xF0
00007cc2f47e0184  pop r11
00007cc2f47e0186  pop r10
00007cc2f47e0188  pop r9
00007cc2f47e018a  pop r8
00007cc2f47e018c  pop rsi
00007cc2f47e018d  pop rdi
00007cc2f47e018e  pop rdx
00007cc2f47e018f  pop rcx
00007cc2f47e0190  pop rax
00007cc2f47e0191  add rsp, 0x08
00007cc2f47e0195  jmp 0x00007CC2F47DEDB4
00007cc2f47e019a  sub rsp, 0x08
00007cc2f47e019e  push rax
00007cc2f47e019f  push rcx
00007cc2f47e01a0  push rdx
00007cc2f47e01a1  push rdi
00007cc2f47e01a2  push rsi
00007cc2f47e01a3  push r8
00007cc2f47e01a5  push r9
00007cc2f47e01a7  push r10
00007cc2f47e01a9  push r11
00007cc2f47e01ab  sub rsp, 0xF0
00007cc2f47e01b2  vmovaps [rsp], xmm0
00007cc2f47e01b7  vmovaps [rsp+0x10], xmm1
00007cc2f47e01bd  vmovaps [rsp+0x20], xmm2
00007cc2f47e01c3  vmovaps [rsp+0x30], xmm4
00007cc2f47e01c9  vmovaps [rsp+0x40], xmm5
00007cc2f47e01cf  vmovaps [rsp+0x50], xmm6
00007cc2f47e01d5  vmovaps [rsp+0x60], xmm7
00007cc2f47e01db  vmovaps [rsp+0x70], xmm8
00007cc2f47e01e1  vmovaps [rsp+0x80], xmm9
00007cc2f47e01ea  vmovaps [rsp+0x90], xmm10
00007cc2f47e01f3  vmovaps [rsp+0xA0], xmm11
00007cc2f47e01fc  vmovaps [rsp+0xB0], xmm12
00007cc2f47e0205  vmovaps [rsp+0xC0], xmm13
00007cc2f47e020e  vmovaps [rsp+0xD0], xmm14
00007cc2f47e0217  vmovaps [rsp+0xE0], xmm15
00007cc2f47e0220  sub rsp, 0x30
00007cc2f47e0224  movaps [rsp], xmm3
00007cc2f47e0228  movaps [rsp+0x10], xmm5
00007cc2f47e022d  movaps [rsp+0x20], xmm4
00007cc2f47e0232  lea rdi, [rsp]
00007cc2f47e0236  mov esi, 0x00
00007cc2f47e023b  mov rax, 0x5990E710A530
00007cc2f47e0245  call rax
00007cc2f47e0247  movaps xmm3, [rsp]
00007cc2f47e024b  add rsp, 0x30
00007cc2f47e024f  vmovaps xmm0, [rsp]
00007cc2f47e0254  vmovaps xmm1, [rsp+0x10]
00007cc2f47e025a  vmovaps xmm2, [rsp+0x20]
00007cc2f47e0260  vmovaps xmm4, [rsp+0x30]
00007cc2f47e0266  vmovaps xmm5, [rsp+0x40]
00007cc2f47e026c  vmovaps xmm6, [rsp+0x50]
00007cc2f47e0272  vmovaps xmm7, [rsp+0x60]
00007cc2f47e0278  vmovaps xmm8, [rsp+0x70]
00007cc2f47e027e  vmovaps xmm9, [rsp+0x80]
00007cc2f47e0287  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0290  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0299  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e02a2  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e02ab  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e02b4  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e02bd  add rsp, 0xF0
00007cc2f47e02c4  pop r11
00007cc2f47e02c6  pop r10
00007cc2f47e02c8  pop r9
00007cc2f47e02ca  pop r8
00007cc2f47e02cc  pop rsi
00007cc2f47e02cd  pop rdi
00007cc2f47e02ce  pop rdx
00007cc2f47e02cf  pop rcx
00007cc2f47e02d0  pop rax
00007cc2f47e02d1  add rsp, 0x08
00007cc2f47e02d5  jmp 0x00007CC2F47DEE15
00007cc2f47e02da  sub rsp, 0x08
00007cc2f47e02de  push rax
00007cc2f47e02df  push rcx
00007cc2f47e02e0  push rdx
00007cc2f47e02e1  push rdi
00007cc2f47e02e2  push rsi
00007cc2f47e02e3  push r8
00007cc2f47e02e5  push r9
00007cc2f47e02e7  push r10
00007cc2f47e02e9  push r11
00007cc2f47e02eb  sub rsp, 0xF0
00007cc2f47e02f2  vmovaps [rsp], xmm0
00007cc2f47e02f7  vmovaps [rsp+0x10], xmm1
00007cc2f47e02fd  vmovaps [rsp+0x20], xmm2
00007cc2f47e0303  vmovaps [rsp+0x30], xmm3
00007cc2f47e0309  vmovaps [rsp+0x40], xmm4
00007cc2f47e030f  vmovaps [rsp+0x50], xmm6
00007cc2f47e0315  vmovaps [rsp+0x60], xmm7
00007cc2f47e031b  vmovaps [rsp+0x70], xmm8
00007cc2f47e0321  vmovaps [rsp+0x80], xmm9
00007cc2f47e032a  vmovaps [rsp+0x90], xmm10
00007cc2f47e0333  vmovaps [rsp+0xA0], xmm11
00007cc2f47e033c  vmovaps [rsp+0xB0], xmm12
00007cc2f47e0345  vmovaps [rsp+0xC0], xmm13
00007cc2f47e034e  vmovaps [rsp+0xD0], xmm14
00007cc2f47e0357  vmovaps [rsp+0xE0], xmm15
00007cc2f47e0360  sub rsp, 0x30
00007cc2f47e0364  movaps [rsp], xmm5
00007cc2f47e0368  movaps [rsp+0x10], xmm8
00007cc2f47e036e  movaps [rsp+0x20], xmm15
00007cc2f47e0374  lea rdi, [rsp]
00007cc2f47e0378  mov esi, 0x00
00007cc2f47e037d  mov rax, 0x5990E710A530
00007cc2f47e0387  call rax
00007cc2f47e0389  movaps xmm5, [rsp]
00007cc2f47e038d  add rsp, 0x30
00007cc2f47e0391  vmovaps xmm0, [rsp]
00007cc2f47e0396  vmovaps xmm1, [rsp+0x10]
00007cc2f47e039c  vmovaps xmm2, [rsp+0x20]
00007cc2f47e03a2  vmovaps xmm3, [rsp+0x30]
00007cc2f47e03a8  vmovaps xmm4, [rsp+0x40]
00007cc2f47e03ae  vmovaps xmm6, [rsp+0x50]
00007cc2f47e03b4  vmovaps xmm7, [rsp+0x60]
00007cc2f47e03ba  vmovaps xmm8, [rsp+0x70]
00007cc2f47e03c0  vmovaps xmm9, [rsp+0x80]
00007cc2f47e03c9  vmovaps xmm10, [rsp+0x90]
00007cc2f47e03d2  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e03db  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e03e4  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e03ed  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e03f6  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e03ff  add rsp, 0xF0
00007cc2f47e0406  pop r11
00007cc2f47e0408  pop r10
00007cc2f47e040a  pop r9
00007cc2f47e040c  pop r8
00007cc2f47e040e  pop rsi
00007cc2f47e040f  pop rdi
00007cc2f47e0410  pop rdx
00007cc2f47e0411  pop rcx
00007cc2f47e0412  pop rax
00007cc2f47e0413  add rsp, 0x08
00007cc2f47e0417  jmp 0x00007CC2F47DEE53
00007cc2f47e041c  sub rsp, 0x08
00007cc2f47e0420  push rax
00007cc2f47e0421  push rcx
00007cc2f47e0422  push rdx
00007cc2f47e0423  push rdi
00007cc2f47e0424  push rsi
00007cc2f47e0425  push r8
00007cc2f47e0427  push r9
00007cc2f47e0429  push r10
00007cc2f47e042b  push r11
00007cc2f47e042d  sub rsp, 0xF0
00007cc2f47e0434  vmovaps [rsp], xmm0
00007cc2f47e0439  vmovaps [rsp+0x10], xmm1
00007cc2f47e043f  vmovaps [rsp+0x20], xmm2
00007cc2f47e0445  vmovaps [rsp+0x30], xmm3
00007cc2f47e044b  vmovaps [rsp+0x40], xmm5
00007cc2f47e0451  vmovaps [rsp+0x50], xmm6
00007cc2f47e0457  vmovaps [rsp+0x60], xmm7
00007cc2f47e045d  vmovaps [rsp+0x70], xmm8
00007cc2f47e0463  vmovaps [rsp+0x80], xmm9
00007cc2f47e046c  vmovaps [rsp+0x90], xmm10
00007cc2f47e0475  vmovaps [rsp+0xA0], xmm11
00007cc2f47e047e  vmovaps [rsp+0xB0], xmm12
00007cc2f47e0487  vmovaps [rsp+0xC0], xmm13
00007cc2f47e0490  vmovaps [rsp+0xD0], xmm14
00007cc2f47e0499  vmovaps [rsp+0xE0], xmm15
00007cc2f47e04a2  sub rsp, 0x30
00007cc2f47e04a6  movaps [rsp], xmm4
00007cc2f47e04aa  movaps [rsp+0x10], xmm9
00007cc2f47e04b0  movaps [rsp+0x20], xmm8
00007cc2f47e04b6  lea rdi, [rsp]
00007cc2f47e04ba  mov esi, 0x00
00007cc2f47e04bf  mov rax, 0x5990E710A530
00007cc2f47e04c9  call rax
00007cc2f47e04cb  movaps xmm4, [rsp]
00007cc2f47e04cf  add rsp, 0x30
00007cc2f47e04d3  vmovaps xmm0, [rsp]
00007cc2f47e04d8  vmovaps xmm1, [rsp+0x10]
00007cc2f47e04de  vmovaps xmm2, [rsp+0x20]
00007cc2f47e04e4  vmovaps xmm3, [rsp+0x30]
00007cc2f47e04ea  vmovaps xmm5, [rsp+0x40]
00007cc2f47e04f0  vmovaps xmm6, [rsp+0x50]
00007cc2f47e04f6  vmovaps xmm7, [rsp+0x60]
00007cc2f47e04fc  vmovaps xmm8, [rsp+0x70]
00007cc2f47e0502  vmovaps xmm9, [rsp+0x80]
00007cc2f47e050b  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0514  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e051d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e0526  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e052f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e0538  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e0541  add rsp, 0xF0
00007cc2f47e0548  pop r11
00007cc2f47e054a  pop r10
00007cc2f47e054c  pop r9
00007cc2f47e054e  pop r8
00007cc2f47e0550  pop rsi
00007cc2f47e0551  pop rdi
00007cc2f47e0552  pop rdx
00007cc2f47e0553  pop rcx
00007cc2f47e0554  pop rax
00007cc2f47e0555  add rsp, 0x08
00007cc2f47e0559  jmp 0x00007CC2F47DEE74
00007cc2f47e055e  sub rsp, 0x08
00007cc2f47e0562  push rax
00007cc2f47e0563  push rcx
00007cc2f47e0564  push rdx
00007cc2f47e0565  push rdi
00007cc2f47e0566  push rsi
00007cc2f47e0567  push r8
00007cc2f47e0569  push r9
00007cc2f47e056b  push r10
00007cc2f47e056d  push r11
00007cc2f47e056f  sub rsp, 0xF0
00007cc2f47e0576  vmovaps [rsp], xmm0
00007cc2f47e057b  vmovaps [rsp+0x10], xmm1
00007cc2f47e0581  vmovaps [rsp+0x20], xmm2
00007cc2f47e0587  vmovaps [rsp+0x30], xmm3
00007cc2f47e058d  vmovaps [rsp+0x40], xmm4
00007cc2f47e0593  vmovaps [rsp+0x50], xmm5
00007cc2f47e0599  vmovaps [rsp+0x60], xmm6
00007cc2f47e059f  vmovaps [rsp+0x70], xmm7
00007cc2f47e05a5  vmovaps [rsp+0x80], xmm8
00007cc2f47e05ae  vmovaps [rsp+0x90], xmm10
00007cc2f47e05b7  vmovaps [rsp+0xA0], xmm11
00007cc2f47e05c0  vmovaps [rsp+0xB0], xmm12
00007cc2f47e05c9  vmovaps [rsp+0xC0], xmm13
00007cc2f47e05d2  vmovaps [rsp+0xD0], xmm14
00007cc2f47e05db  vmovaps [rsp+0xE0], xmm15
00007cc2f47e05e4  sub rsp, 0x30
00007cc2f47e05e8  movaps [rsp], xmm9
00007cc2f47e05ed  movaps [rsp+0x10], xmm10
00007cc2f47e05f3  movaps [rsp+0x20], xmm8
00007cc2f47e05f9  lea rdi, [rsp]
00007cc2f47e05fd  mov esi, 0x00
00007cc2f47e0602  mov rax, 0x5990E710A530
00007cc2f47e060c  call rax
00007cc2f47e060e  movaps xmm9, [rsp]
00007cc2f47e0613  add rsp, 0x30
00007cc2f47e0617  vmovaps xmm0, [rsp]
00007cc2f47e061c  vmovaps xmm1, [rsp+0x10]
00007cc2f47e0622  vmovaps xmm2, [rsp+0x20]
00007cc2f47e0628  vmovaps xmm3, [rsp+0x30]
00007cc2f47e062e  vmovaps xmm4, [rsp+0x40]
00007cc2f47e0634  vmovaps xmm5, [rsp+0x50]
00007cc2f47e063a  vmovaps xmm6, [rsp+0x60]
00007cc2f47e0640  vmovaps xmm7, [rsp+0x70]
00007cc2f47e0646  vmovaps xmm8, [rsp+0x80]
00007cc2f47e064f  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0658  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0661  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e066a  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e0673  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e067c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e0685  add rsp, 0xF0
00007cc2f47e068c  pop r11
00007cc2f47e068e  pop r10
00007cc2f47e0690  pop r9
00007cc2f47e0692  pop r8
00007cc2f47e0694  pop rsi
00007cc2f47e0695  pop rdi
00007cc2f47e0696  pop rdx
00007cc2f47e0697  pop rcx
00007cc2f47e0698  pop rax
00007cc2f47e0699  add rsp, 0x08
00007cc2f47e069d  jmp 0x00007CC2F47DEE8E
00007cc2f47e06a2  call 0x00007CC2F46B52F0
00007cc2f47e06a7  jmp 0x00007CC2F47DEFA8
00007cc2f47e06ac  call 0x00007CC2F46B52F0
00007cc2f47e06b1  jmp 0x00007CC2F47DEFBE
00007cc2f47e06b6  sub rsp, 0x08
00007cc2f47e06ba  push rax
00007cc2f47e06bb  push rcx
00007cc2f47e06bc  push rdx
00007cc2f47e06bd  push rdi
00007cc2f47e06be  push rsi
00007cc2f47e06bf  push r8
00007cc2f47e06c1  push r9
00007cc2f47e06c3  push r10
00007cc2f47e06c5  push r11
00007cc2f47e06c7  sub rsp, 0xF0
00007cc2f47e06ce  vmovaps [rsp], xmm0
00007cc2f47e06d3  vmovaps [rsp+0x10], xmm2
00007cc2f47e06d9  vmovaps [rsp+0x20], xmm3
00007cc2f47e06df  vmovaps [rsp+0x30], xmm4
00007cc2f47e06e5  vmovaps [rsp+0x40], xmm5
00007cc2f47e06eb  vmovaps [rsp+0x50], xmm6
00007cc2f47e06f1  vmovaps [rsp+0x60], xmm7
00007cc2f47e06f7  vmovaps [rsp+0x70], xmm8
00007cc2f47e06fd  vmovaps [rsp+0x80], xmm9
00007cc2f47e0706  vmovaps [rsp+0x90], xmm10
00007cc2f47e070f  vmovaps [rsp+0xA0], xmm11
00007cc2f47e0718  vmovaps [rsp+0xB0], xmm12
00007cc2f47e0721  vmovaps [rsp+0xC0], xmm13
00007cc2f47e072a  vmovaps [rsp+0xD0], xmm14
00007cc2f47e0733  vmovaps [rsp+0xE0], xmm15
00007cc2f47e073c  sub rsp, 0x30
00007cc2f47e0740  movaps [rsp], xmm1
00007cc2f47e0744  movaps [rsp+0x10], xmm6
00007cc2f47e0749  movaps [rsp+0x20], xmm15
00007cc2f47e074f  lea rdi, [rsp]
00007cc2f47e0753  mov esi, 0x00
00007cc2f47e0758  mov rax, 0x5990E710A530
00007cc2f47e0762  call rax
00007cc2f47e0764  movaps xmm1, [rsp]
00007cc2f47e0768  add rsp, 0x30
00007cc2f47e076c  vmovaps xmm0, [rsp]
00007cc2f47e0771  vmovaps xmm2, [rsp+0x10]
00007cc2f47e0777  vmovaps xmm3, [rsp+0x20]
00007cc2f47e077d  vmovaps xmm4, [rsp+0x30]
00007cc2f47e0783  vmovaps xmm5, [rsp+0x40]
00007cc2f47e0789  vmovaps xmm6, [rsp+0x50]
00007cc2f47e078f  vmovaps xmm7, [rsp+0x60]
00007cc2f47e0795  vmovaps xmm8, [rsp+0x70]
00007cc2f47e079b  vmovaps xmm9, [rsp+0x80]
00007cc2f47e07a4  vmovaps xmm10, [rsp+0x90]
00007cc2f47e07ad  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e07b6  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e07bf  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e07c8  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e07d1  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e07da  add rsp, 0xF0
00007cc2f47e07e1  pop r11
00007cc2f47e07e3  pop r10
00007cc2f47e07e5  pop r9
00007cc2f47e07e7  pop r8
00007cc2f47e07e9  pop rsi
00007cc2f47e07ea  pop rdi
00007cc2f47e07eb  pop rdx
00007cc2f47e07ec  pop rcx
00007cc2f47e07ed  pop rax
00007cc2f47e07ee  add rsp, 0x08
00007cc2f47e07f2  jmp 0x00007CC2F47DEFFB
00007cc2f47e07f7  call 0x00007CC2F46C4620
00007cc2f47e07fc  jmp 0x00007CC2F47DF008
00007cc2f47e0801  sub rsp, 0x08
00007cc2f47e0805  push rax
00007cc2f47e0806  push rcx
00007cc2f47e0807  push rdx
00007cc2f47e0808  push rdi
00007cc2f47e0809  push rsi
00007cc2f47e080a  push r8
00007cc2f47e080c  push r9
00007cc2f47e080e  push r10
00007cc2f47e0810  push r11
00007cc2f47e0812  sub rsp, 0xF0
00007cc2f47e0819  vmovaps [rsp], xmm0
00007cc2f47e081e  vmovaps [rsp+0x10], xmm1
00007cc2f47e0824  vmovaps [rsp+0x20], xmm2
00007cc2f47e082a  vmovaps [rsp+0x30], xmm3
00007cc2f47e0830  vmovaps [rsp+0x40], xmm4
00007cc2f47e0836  vmovaps [rsp+0x50], xmm5
00007cc2f47e083c  vmovaps [rsp+0x60], xmm6
00007cc2f47e0842  vmovaps [rsp+0x70], xmm7
00007cc2f47e0848  vmovaps [rsp+0x80], xmm8
00007cc2f47e0851  vmovaps [rsp+0x90], xmm9
00007cc2f47e085a  vmovaps [rsp+0xA0], xmm10
00007cc2f47e0863  vmovaps [rsp+0xB0], xmm11
00007cc2f47e086c  vmovaps [rsp+0xC0], xmm12
00007cc2f47e0875  vmovaps [rsp+0xD0], xmm13
00007cc2f47e087e  vmovaps [rsp+0xE0], xmm15
00007cc2f47e0887  sub rsp, 0x30
00007cc2f47e088b  movaps [rsp], xmm14
00007cc2f47e0890  movaps [rsp+0x10], xmm4
00007cc2f47e0895  movaps [rsp+0x20], xmm3
00007cc2f47e089a  lea rdi, [rsp]
00007cc2f47e089e  mov esi, 0x00
00007cc2f47e08a3  mov rax, 0x5990E710A530
00007cc2f47e08ad  call rax
00007cc2f47e08af  movaps xmm14, [rsp]
00007cc2f47e08b4  add rsp, 0x30
00007cc2f47e08b8  vmovaps xmm0, [rsp]
00007cc2f47e08bd  vmovaps xmm1, [rsp+0x10]
00007cc2f47e08c3  vmovaps xmm2, [rsp+0x20]
00007cc2f47e08c9  vmovaps xmm3, [rsp+0x30]
00007cc2f47e08cf  vmovaps xmm4, [rsp+0x40]
00007cc2f47e08d5  vmovaps xmm5, [rsp+0x50]
00007cc2f47e08db  vmovaps xmm6, [rsp+0x60]
00007cc2f47e08e1  vmovaps xmm7, [rsp+0x70]
00007cc2f47e08e7  vmovaps xmm8, [rsp+0x80]
00007cc2f47e08f0  vmovaps xmm9, [rsp+0x90]
00007cc2f47e08f9  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e0902  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e090b  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e0914  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e091d  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e0926  add rsp, 0xF0
00007cc2f47e092d  pop r11
00007cc2f47e092f  pop r10
00007cc2f47e0931  pop r9
00007cc2f47e0933  pop r8
00007cc2f47e0935  pop rsi
00007cc2f47e0936  pop rdi
00007cc2f47e0937  pop rdx
00007cc2f47e0938  pop rcx
00007cc2f47e0939  pop rax
00007cc2f47e093a  add rsp, 0x08
00007cc2f47e093e  jmp 0x00007CC2F47DF022
00007cc2f47e0943  sub rsp, 0x08
00007cc2f47e0947  push rax
00007cc2f47e0948  push rcx
00007cc2f47e0949  push rdx
00007cc2f47e094a  push rdi
00007cc2f47e094b  push rsi
00007cc2f47e094c  push r8
00007cc2f47e094e  push r9
00007cc2f47e0950  push r10
00007cc2f47e0952  push r11
00007cc2f47e0954  sub rsp, 0xF0
00007cc2f47e095b  vmovaps [rsp], xmm0
00007cc2f47e0960  vmovaps [rsp+0x10], xmm1
00007cc2f47e0966  vmovaps [rsp+0x20], xmm2
00007cc2f47e096c  vmovaps [rsp+0x30], xmm3
00007cc2f47e0972  vmovaps [rsp+0x40], xmm4
00007cc2f47e0978  vmovaps [rsp+0x50], xmm5
00007cc2f47e097e  vmovaps [rsp+0x60], xmm7
00007cc2f47e0984  vmovaps [rsp+0x70], xmm8
00007cc2f47e098a  vmovaps [rsp+0x80], xmm9
00007cc2f47e0993  vmovaps [rsp+0x90], xmm10
00007cc2f47e099c  vmovaps [rsp+0xA0], xmm11
00007cc2f47e09a5  vmovaps [rsp+0xB0], xmm12
00007cc2f47e09ae  vmovaps [rsp+0xC0], xmm13
00007cc2f47e09b7  vmovaps [rsp+0xD0], xmm14
00007cc2f47e09c0  vmovaps [rsp+0xE0], xmm15
00007cc2f47e09c9  sub rsp, 0x30
00007cc2f47e09cd  movaps [rsp], xmm6
00007cc2f47e09d1  movaps [rsp+0x10], xmm9
00007cc2f47e09d7  movaps [rsp+0x20], xmm7
00007cc2f47e09dc  lea rdi, [rsp]
00007cc2f47e09e0  mov esi, 0x00
00007cc2f47e09e5  mov rax, 0x5990E710A530
00007cc2f47e09ef  call rax
00007cc2f47e09f1  movaps xmm6, [rsp]
00007cc2f47e09f5  add rsp, 0x30
00007cc2f47e09f9  vmovaps xmm0, [rsp]
00007cc2f47e09fe  vmovaps xmm1, [rsp+0x10]
00007cc2f47e0a04  vmovaps xmm2, [rsp+0x20]
00007cc2f47e0a0a  vmovaps xmm3, [rsp+0x30]
00007cc2f47e0a10  vmovaps xmm4, [rsp+0x40]
00007cc2f47e0a16  vmovaps xmm5, [rsp+0x50]
00007cc2f47e0a1c  vmovaps xmm7, [rsp+0x60]
00007cc2f47e0a22  vmovaps xmm8, [rsp+0x70]
00007cc2f47e0a28  vmovaps xmm9, [rsp+0x80]
00007cc2f47e0a31  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0a3a  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0a43  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e0a4c  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e0a55  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e0a5e  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e0a67  add rsp, 0xF0
00007cc2f47e0a6e  pop r11
00007cc2f47e0a70  pop r10
00007cc2f47e0a72  pop r9
00007cc2f47e0a74  pop r8
00007cc2f47e0a76  pop rsi
00007cc2f47e0a77  pop rdi
00007cc2f47e0a78  pop rdx
00007cc2f47e0a79  pop rcx
00007cc2f47e0a7a  pop rax
00007cc2f47e0a7b  add rsp, 0x08
00007cc2f47e0a7f  jmp 0x00007CC2F47DF03A
00007cc2f47e0a84  sub rsp, 0x08
00007cc2f47e0a88  push rax
00007cc2f47e0a89  push rcx
00007cc2f47e0a8a  push rdx
00007cc2f47e0a8b  push rdi
00007cc2f47e0a8c  push rsi
00007cc2f47e0a8d  push r8
00007cc2f47e0a8f  push r9
00007cc2f47e0a91  push r10
00007cc2f47e0a93  push r11
00007cc2f47e0a95  sub rsp, 0xF0
00007cc2f47e0a9c  vmovaps [rsp], xmm0
00007cc2f47e0aa1  vmovaps [rsp+0x10], xmm1
00007cc2f47e0aa7  vmovaps [rsp+0x20], xmm2
00007cc2f47e0aad  vmovaps [rsp+0x30], xmm3
00007cc2f47e0ab3  vmovaps [rsp+0x40], xmm4
00007cc2f47e0ab9  vmovaps [rsp+0x50], xmm5
00007cc2f47e0abf  vmovaps [rsp+0x60], xmm6
00007cc2f47e0ac5  vmovaps [rsp+0x70], xmm8
00007cc2f47e0acb  vmovaps [rsp+0x80], xmm9
00007cc2f47e0ad4  vmovaps [rsp+0x90], xmm10
00007cc2f47e0add  vmovaps [rsp+0xA0], xmm11
00007cc2f47e0ae6  vmovaps [rsp+0xB0], xmm12
00007cc2f47e0aef  vmovaps [rsp+0xC0], xmm13
00007cc2f47e0af8  vmovaps [rsp+0xD0], xmm14
00007cc2f47e0b01  vmovaps [rsp+0xE0], xmm15
00007cc2f47e0b0a  sub rsp, 0x30
00007cc2f47e0b0e  movaps [rsp], xmm7
00007cc2f47e0b12  movaps [rsp+0x10], xmm4
00007cc2f47e0b17  movaps [rsp+0x20], xmm9
00007cc2f47e0b1d  lea rdi, [rsp]
00007cc2f47e0b21  mov esi, 0x00
00007cc2f47e0b26  mov rax, 0x5990E710A530
00007cc2f47e0b30  call rax
00007cc2f47e0b32  movaps xmm7, [rsp]
00007cc2f47e0b36  add rsp, 0x30
00007cc2f47e0b3a  vmovaps xmm0, [rsp]
00007cc2f47e0b3f  vmovaps xmm1, [rsp+0x10]
00007cc2f47e0b45  vmovaps xmm2, [rsp+0x20]
00007cc2f47e0b4b  vmovaps xmm3, [rsp+0x30]
00007cc2f47e0b51  vmovaps xmm4, [rsp+0x40]
00007cc2f47e0b57  vmovaps xmm5, [rsp+0x50]
00007cc2f47e0b5d  vmovaps xmm6, [rsp+0x60]
00007cc2f47e0b63  vmovaps xmm8, [rsp+0x70]
00007cc2f47e0b69  vmovaps xmm9, [rsp+0x80]
00007cc2f47e0b72  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0b7b  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0b84  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e0b8d  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e0b96  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e0b9f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e0ba8  add rsp, 0xF0
00007cc2f47e0baf  pop r11
00007cc2f47e0bb1  pop r10
00007cc2f47e0bb3  pop r9
00007cc2f47e0bb5  pop r8
00007cc2f47e0bb7  pop rsi
00007cc2f47e0bb8  pop rdi
00007cc2f47e0bb9  pop rdx
00007cc2f47e0bba  pop rcx
00007cc2f47e0bbb  pop rax
00007cc2f47e0bbc  add rsp, 0x08
00007cc2f47e0bc0  jmp 0x00007CC2F47DF067
00007cc2f47e0bc5  sub rsp, 0x08
00007cc2f47e0bc9  push rax
00007cc2f47e0bca  push rcx
00007cc2f47e0bcb  push rdx
00007cc2f47e0bcc  push rdi
00007cc2f47e0bcd  push rsi
00007cc2f47e0bce  push r8
00007cc2f47e0bd0  push r9
00007cc2f47e0bd2  push r10
00007cc2f47e0bd4  push r11
00007cc2f47e0bd6  sub rsp, 0xF0
00007cc2f47e0bdd  vmovaps [rsp], xmm0
00007cc2f47e0be2  vmovaps [rsp+0x10], xmm1
00007cc2f47e0be8  vmovaps [rsp+0x20], xmm2
00007cc2f47e0bee  vmovaps [rsp+0x30], xmm3
00007cc2f47e0bf4  vmovaps [rsp+0x40], xmm5
00007cc2f47e0bfa  vmovaps [rsp+0x50], xmm6
00007cc2f47e0c00  vmovaps [rsp+0x60], xmm7
00007cc2f47e0c06  vmovaps [rsp+0x70], xmm8
00007cc2f47e0c0c  vmovaps [rsp+0x80], xmm9
00007cc2f47e0c15  vmovaps [rsp+0x90], xmm10
00007cc2f47e0c1e  vmovaps [rsp+0xA0], xmm11
00007cc2f47e0c27  vmovaps [rsp+0xB0], xmm12
00007cc2f47e0c30  vmovaps [rsp+0xC0], xmm13
00007cc2f47e0c39  vmovaps [rsp+0xD0], xmm14
00007cc2f47e0c42  vmovaps [rsp+0xE0], xmm15
00007cc2f47e0c4b  sub rsp, 0x30
00007cc2f47e0c4f  movaps [rsp], xmm4
00007cc2f47e0c53  movaps [rsp+0x10], xmm15
00007cc2f47e0c59  movaps [rsp+0x20], xmm9
00007cc2f47e0c5f  lea rdi, [rsp]
00007cc2f47e0c63  mov esi, 0x00
00007cc2f47e0c68  mov rax, 0x5990E710A530
00007cc2f47e0c72  call rax
00007cc2f47e0c74  movaps xmm4, [rsp]
00007cc2f47e0c78  add rsp, 0x30
00007cc2f47e0c7c  vmovaps xmm0, [rsp]
00007cc2f47e0c81  vmovaps xmm1, [rsp+0x10]
00007cc2f47e0c87  vmovaps xmm2, [rsp+0x20]
00007cc2f47e0c8d  vmovaps xmm3, [rsp+0x30]
00007cc2f47e0c93  vmovaps xmm5, [rsp+0x40]
00007cc2f47e0c99  vmovaps xmm6, [rsp+0x50]
00007cc2f47e0c9f  vmovaps xmm7, [rsp+0x60]
00007cc2f47e0ca5  vmovaps xmm8, [rsp+0x70]
00007cc2f47e0cab  vmovaps xmm9, [rsp+0x80]
00007cc2f47e0cb4  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0cbd  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0cc6  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e0ccf  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e0cd8  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e0ce1  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e0cea  add rsp, 0xF0
00007cc2f47e0cf1  pop r11
00007cc2f47e0cf3  pop r10
00007cc2f47e0cf5  pop r9
00007cc2f47e0cf7  pop r8
00007cc2f47e0cf9  pop rsi
00007cc2f47e0cfa  pop rdi
00007cc2f47e0cfb  pop rdx
00007cc2f47e0cfc  pop rcx
00007cc2f47e0cfd  pop rax
00007cc2f47e0cfe  add rsp, 0x08
00007cc2f47e0d02  jmp 0x00007CC2F47DF08C
00007cc2f47e0d07  call 0x00007CC2F46C4620
00007cc2f47e0d0c  jmp 0x00007CC2F47DF099
00007cc2f47e0d11  sub rsp, 0x08
00007cc2f47e0d15  push rax
00007cc2f47e0d16  push rcx
00007cc2f47e0d17  push rdx
00007cc2f47e0d18  push rdi
00007cc2f47e0d19  push rsi
00007cc2f47e0d1a  push r8
00007cc2f47e0d1c  push r9
00007cc2f47e0d1e  push r10
00007cc2f47e0d20  push r11
00007cc2f47e0d22  sub rsp, 0xF0
00007cc2f47e0d29  vmovaps [rsp], xmm0
00007cc2f47e0d2e  vmovaps [rsp+0x10], xmm1
00007cc2f47e0d34  vmovaps [rsp+0x20], xmm2
00007cc2f47e0d3a  vmovaps [rsp+0x30], xmm4
00007cc2f47e0d40  vmovaps [rsp+0x40], xmm5
00007cc2f47e0d46  vmovaps [rsp+0x50], xmm6
00007cc2f47e0d4c  vmovaps [rsp+0x60], xmm7
00007cc2f47e0d52  vmovaps [rsp+0x70], xmm8
00007cc2f47e0d58  vmovaps [rsp+0x80], xmm9
00007cc2f47e0d61  vmovaps [rsp+0x90], xmm10
00007cc2f47e0d6a  vmovaps [rsp+0xA0], xmm11
00007cc2f47e0d73  vmovaps [rsp+0xB0], xmm12
00007cc2f47e0d7c  vmovaps [rsp+0xC0], xmm13
00007cc2f47e0d85  vmovaps [rsp+0xD0], xmm14
00007cc2f47e0d8e  vmovaps [rsp+0xE0], xmm15
00007cc2f47e0d97  sub rsp, 0x30
00007cc2f47e0d9b  movaps [rsp], xmm3
00007cc2f47e0d9f  movaps [rsp+0x10], xmm1
00007cc2f47e0da4  movaps [rsp+0x20], xmm9
00007cc2f47e0daa  lea rdi, [rsp]
00007cc2f47e0dae  mov esi, 0x00
00007cc2f47e0db3  mov rax, 0x5990E710A530
00007cc2f47e0dbd  call rax
00007cc2f47e0dbf  movaps xmm3, [rsp]
00007cc2f47e0dc3  add rsp, 0x30
00007cc2f47e0dc7  vmovaps xmm0, [rsp]
00007cc2f47e0dcc  vmovaps xmm1, [rsp+0x10]
00007cc2f47e0dd2  vmovaps xmm2, [rsp+0x20]
00007cc2f47e0dd8  vmovaps xmm4, [rsp+0x30]
00007cc2f47e0dde  vmovaps xmm5, [rsp+0x40]
00007cc2f47e0de4  vmovaps xmm6, [rsp+0x50]
00007cc2f47e0dea  vmovaps xmm7, [rsp+0x60]
00007cc2f47e0df0  vmovaps xmm8, [rsp+0x70]
00007cc2f47e0df6  vmovaps xmm9, [rsp+0x80]
00007cc2f47e0dff  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0e08  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0e11  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e0e1a  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e0e23  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e0e2c  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e0e35  add rsp, 0xF0
00007cc2f47e0e3c  pop r11
00007cc2f47e0e3e  pop r10
00007cc2f47e0e40  pop r9
00007cc2f47e0e42  pop r8
00007cc2f47e0e44  pop rsi
00007cc2f47e0e45  pop rdi
00007cc2f47e0e46  pop rdx
00007cc2f47e0e47  pop rcx
00007cc2f47e0e48  pop rax
00007cc2f47e0e49  add rsp, 0x08
00007cc2f47e0e4d  jmp 0x00007CC2F47DF0D6
00007cc2f47e0e52  sub rsp, 0x08
00007cc2f47e0e56  push rax
00007cc2f47e0e57  push rcx
00007cc2f47e0e58  push rdx
00007cc2f47e0e59  push rdi
00007cc2f47e0e5a  push rsi
00007cc2f47e0e5b  push r8
00007cc2f47e0e5d  push r9
00007cc2f47e0e5f  push r10
00007cc2f47e0e61  push r11
00007cc2f47e0e63  sub rsp, 0xF0
00007cc2f47e0e6a  vmovaps [rsp], xmm0
00007cc2f47e0e6f  vmovaps [rsp+0x10], xmm2
00007cc2f47e0e75  vmovaps [rsp+0x20], xmm3
00007cc2f47e0e7b  vmovaps [rsp+0x30], xmm4
00007cc2f47e0e81  vmovaps [rsp+0x40], xmm5
00007cc2f47e0e87  vmovaps [rsp+0x50], xmm6
00007cc2f47e0e8d  vmovaps [rsp+0x60], xmm7
00007cc2f47e0e93  vmovaps [rsp+0x70], xmm8
00007cc2f47e0e99  vmovaps [rsp+0x80], xmm9
00007cc2f47e0ea2  vmovaps [rsp+0x90], xmm10
00007cc2f47e0eab  vmovaps [rsp+0xA0], xmm11
00007cc2f47e0eb4  vmovaps [rsp+0xB0], xmm12
00007cc2f47e0ebd  vmovaps [rsp+0xC0], xmm13
00007cc2f47e0ec6  vmovaps [rsp+0xD0], xmm14
00007cc2f47e0ecf  vmovaps [rsp+0xE0], xmm15
00007cc2f47e0ed8  sub rsp, 0x30
00007cc2f47e0edc  movaps [rsp], xmm1
00007cc2f47e0ee0  movaps [rsp+0x10], xmm15
00007cc2f47e0ee6  movaps [rsp+0x20], xmm9
00007cc2f47e0eec  lea rdi, [rsp]
00007cc2f47e0ef0  mov esi, 0x00
00007cc2f47e0ef5  mov rax, 0x5990E710A530
00007cc2f47e0eff  call rax
00007cc2f47e0f01  movaps xmm1, [rsp]
00007cc2f47e0f05  add rsp, 0x30
00007cc2f47e0f09  vmovaps xmm0, [rsp]
00007cc2f47e0f0e  vmovaps xmm2, [rsp+0x10]
00007cc2f47e0f14  vmovaps xmm3, [rsp+0x20]
00007cc2f47e0f1a  vmovaps xmm4, [rsp+0x30]
00007cc2f47e0f20  vmovaps xmm5, [rsp+0x40]
00007cc2f47e0f26  vmovaps xmm6, [rsp+0x50]
00007cc2f47e0f2c  vmovaps xmm7, [rsp+0x60]
00007cc2f47e0f32  vmovaps xmm8, [rsp+0x70]
00007cc2f47e0f38  vmovaps xmm9, [rsp+0x80]
00007cc2f47e0f41  vmovaps xmm10, [rsp+0x90]
00007cc2f47e0f4a  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e0f53  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e0f5c  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e0f65  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e0f6e  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e0f77  add rsp, 0xF0
00007cc2f47e0f7e  pop r11
00007cc2f47e0f80  pop r10
00007cc2f47e0f82  pop r9
00007cc2f47e0f84  pop r8
00007cc2f47e0f86  pop rsi
00007cc2f47e0f87  pop rdi
00007cc2f47e0f88  pop rdx
00007cc2f47e0f89  pop rcx
00007cc2f47e0f8a  pop rax
00007cc2f47e0f8b  add rsp, 0x08
00007cc2f47e0f8f  jmp 0x00007CC2F47DF15E
00007cc2f47e0f94  call 0x00007CC2F46C4620
00007cc2f47e0f99  jmp 0x00007CC2F47DF16B
00007cc2f47e0f9e  sub rsp, 0x08
00007cc2f47e0fa2  push rax
00007cc2f47e0fa3  push rcx
00007cc2f47e0fa4  push rdx
00007cc2f47e0fa5  push rdi
00007cc2f47e0fa6  push rsi
00007cc2f47e0fa7  push r8
00007cc2f47e0fa9  push r9
00007cc2f47e0fab  push r10
00007cc2f47e0fad  push r11
00007cc2f47e0faf  sub rsp, 0xF0
00007cc2f47e0fb6  vmovaps [rsp], xmm0
00007cc2f47e0fbb  vmovaps [rsp+0x10], xmm2
00007cc2f47e0fc1  vmovaps [rsp+0x20], xmm3
00007cc2f47e0fc7  vmovaps [rsp+0x30], xmm4
00007cc2f47e0fcd  vmovaps [rsp+0x40], xmm5
00007cc2f47e0fd3  vmovaps [rsp+0x50], xmm6
00007cc2f47e0fd9  vmovaps [rsp+0x60], xmm7
00007cc2f47e0fdf  vmovaps [rsp+0x70], xmm8
00007cc2f47e0fe5  vmovaps [rsp+0x80], xmm9
00007cc2f47e0fee  vmovaps [rsp+0x90], xmm10
00007cc2f47e0ff7  vmovaps [rsp+0xA0], xmm11
00007cc2f47e1000  vmovaps [rsp+0xB0], xmm12
00007cc2f47e1009  vmovaps [rsp+0xC0], xmm13
00007cc2f47e1012  vmovaps [rsp+0xD0], xmm14
00007cc2f47e101b  vmovaps [rsp+0xE0], xmm15
00007cc2f47e1024  sub rsp, 0x30
00007cc2f47e1028  movaps [rsp], xmm1
00007cc2f47e102c  movaps [rsp+0x10], xmm5
00007cc2f47e1031  movaps [rsp+0x20], xmm7
00007cc2f47e1036  lea rdi, [rsp]
00007cc2f47e103a  mov esi, 0x00
00007cc2f47e103f  mov rax, 0x5990E710A530
00007cc2f47e1049  call rax
00007cc2f47e104b  movaps xmm1, [rsp]
00007cc2f47e104f  add rsp, 0x30
00007cc2f47e1053  vmovaps xmm0, [rsp]
00007cc2f47e1058  vmovaps xmm2, [rsp+0x10]
00007cc2f47e105e  vmovaps xmm3, [rsp+0x20]
00007cc2f47e1064  vmovaps xmm4, [rsp+0x30]
00007cc2f47e106a  vmovaps xmm5, [rsp+0x40]
00007cc2f47e1070  vmovaps xmm6, [rsp+0x50]
00007cc2f47e1076  vmovaps xmm7, [rsp+0x60]
00007cc2f47e107c  vmovaps xmm8, [rsp+0x70]
00007cc2f47e1082  vmovaps xmm9, [rsp+0x80]
00007cc2f47e108b  vmovaps xmm10, [rsp+0x90]
00007cc2f47e1094  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e109d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e10a6  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e10af  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e10b8  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e10c1  add rsp, 0xF0
00007cc2f47e10c8  pop r11
00007cc2f47e10ca  pop r10
00007cc2f47e10cc  pop r9
00007cc2f47e10ce  pop r8
00007cc2f47e10d0  pop rsi
00007cc2f47e10d1  pop rdi
00007cc2f47e10d2  pop rdx
00007cc2f47e10d3  pop rcx
00007cc2f47e10d4  pop rax
00007cc2f47e10d5  add rsp, 0x08
00007cc2f47e10d9  jmp 0x00007CC2F47DF210
00007cc2f47e10de  sub rsp, 0x08
00007cc2f47e10e2  push rax
00007cc2f47e10e3  push rcx
00007cc2f47e10e4  push rdx
00007cc2f47e10e5  push rdi
00007cc2f47e10e6  push rsi
00007cc2f47e10e7  push r8
00007cc2f47e10e9  push r9
00007cc2f47e10eb  push r10
00007cc2f47e10ed  push r11
00007cc2f47e10ef  sub rsp, 0xF0
00007cc2f47e10f6  vmovaps [rsp], xmm0
00007cc2f47e10fb  vmovaps [rsp+0x10], xmm1
00007cc2f47e1101  vmovaps [rsp+0x20], xmm2
00007cc2f47e1107  vmovaps [rsp+0x30], xmm3
00007cc2f47e110d  vmovaps [rsp+0x40], xmm4
00007cc2f47e1113  vmovaps [rsp+0x50], xmm5
00007cc2f47e1119  vmovaps [rsp+0x60], xmm6
00007cc2f47e111f  vmovaps [rsp+0x70], xmm8
00007cc2f47e1125  vmovaps [rsp+0x80], xmm9
00007cc2f47e112e  vmovaps [rsp+0x90], xmm10
00007cc2f47e1137  vmovaps [rsp+0xA0], xmm11
00007cc2f47e1140  vmovaps [rsp+0xB0], xmm12
00007cc2f47e1149  vmovaps [rsp+0xC0], xmm13
00007cc2f47e1152  vmovaps [rsp+0xD0], xmm14
00007cc2f47e115b  vmovaps [rsp+0xE0], xmm15
00007cc2f47e1164  sub rsp, 0x30
00007cc2f47e1168  movaps [rsp], xmm7
00007cc2f47e116c  movaps [rsp+0x10], xmm5
00007cc2f47e1171  movaps [rsp+0x20], xmm15
00007cc2f47e1177  lea rdi, [rsp]
00007cc2f47e117b  mov esi, 0x00
00007cc2f47e1180  mov rax, 0x5990E710A530
00007cc2f47e118a  call rax
00007cc2f47e118c  movaps xmm7, [rsp]
00007cc2f47e1190  add rsp, 0x30
00007cc2f47e1194  vmovaps xmm0, [rsp]
00007cc2f47e1199  vmovaps xmm1, [rsp+0x10]
00007cc2f47e119f  vmovaps xmm2, [rsp+0x20]
00007cc2f47e11a5  vmovaps xmm3, [rsp+0x30]
00007cc2f47e11ab  vmovaps xmm4, [rsp+0x40]
00007cc2f47e11b1  vmovaps xmm5, [rsp+0x50]
00007cc2f47e11b7  vmovaps xmm6, [rsp+0x60]
00007cc2f47e11bd  vmovaps xmm8, [rsp+0x70]
00007cc2f47e11c3  vmovaps xmm9, [rsp+0x80]
00007cc2f47e11cc  vmovaps xmm10, [rsp+0x90]
00007cc2f47e11d5  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e11de  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e11e7  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e11f0  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e11f9  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e1202  add rsp, 0xF0
00007cc2f47e1209  pop r11
00007cc2f47e120b  pop r10
00007cc2f47e120d  pop r9
00007cc2f47e120f  pop r8
00007cc2f47e1211  pop rsi
00007cc2f47e1212  pop rdi
00007cc2f47e1213  pop rdx
00007cc2f47e1214  pop rcx
00007cc2f47e1215  pop rax
00007cc2f47e1216  add rsp, 0x08
00007cc2f47e121a  jmp 0x00007CC2F47DF246
00007cc2f47e121f  call 0x00007CC2F46B52F0
00007cc2f47e1224  jmp 0x00007CC2F47DF253
00007cc2f47e1229  sub rsp, 0x08
00007cc2f47e122d  push rax
00007cc2f47e122e  push rcx
00007cc2f47e122f  push rdx
00007cc2f47e1230  push rdi
00007cc2f47e1231  push rsi
00007cc2f47e1232  push r8
00007cc2f47e1234  push r9
00007cc2f47e1236  push r10
00007cc2f47e1238  push r11
00007cc2f47e123a  sub rsp, 0xF0
00007cc2f47e1241  vmovaps [rsp], xmm0
00007cc2f47e1246  vmovaps [rsp+0x10], xmm1
00007cc2f47e124c  vmovaps [rsp+0x20], xmm2
00007cc2f47e1252  vmovaps [rsp+0x30], xmm3
00007cc2f47e1258  vmovaps [rsp+0x40], xmm4
00007cc2f47e125e  vmovaps [rsp+0x50], xmm5
00007cc2f47e1264  vmovaps [rsp+0x60], xmm6
00007cc2f47e126a  vmovaps [rsp+0x70], xmm7
00007cc2f47e1270  vmovaps [rsp+0x80], xmm8
00007cc2f47e1279  vmovaps [rsp+0x90], xmm9
00007cc2f47e1282  vmovaps [rsp+0xA0], xmm10
00007cc2f47e128b  vmovaps [rsp+0xB0], xmm11
00007cc2f47e1294  vmovaps [rsp+0xC0], xmm12
00007cc2f47e129d  vmovaps [rsp+0xD0], xmm13
00007cc2f47e12a6  vmovaps [rsp+0xE0], xmm14
00007cc2f47e12af  sub rsp, 0x30
00007cc2f47e12b3  movaps [rsp], xmm15
00007cc2f47e12b8  movaps [rsp+0x10], xmm5
00007cc2f47e12bd  movaps [rsp+0x20], xmm3
00007cc2f47e12c2  lea rdi, [rsp]
00007cc2f47e12c6  mov esi, 0x00
00007cc2f47e12cb  mov rax, 0x5990E710A530
00007cc2f47e12d5  call rax
00007cc2f47e12d7  movaps xmm15, [rsp]
00007cc2f47e12dc  add rsp, 0x30
00007cc2f47e12e0  vmovaps xmm0, [rsp]
00007cc2f47e12e5  vmovaps xmm1, [rsp+0x10]
00007cc2f47e12eb  vmovaps xmm2, [rsp+0x20]
00007cc2f47e12f1  vmovaps xmm3, [rsp+0x30]
00007cc2f47e12f7  vmovaps xmm4, [rsp+0x40]
00007cc2f47e12fd  vmovaps xmm5, [rsp+0x50]
00007cc2f47e1303  vmovaps xmm6, [rsp+0x60]
00007cc2f47e1309  vmovaps xmm7, [rsp+0x70]
00007cc2f47e130f  vmovaps xmm8, [rsp+0x80]
00007cc2f47e1318  vmovaps xmm9, [rsp+0x90]
00007cc2f47e1321  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e132a  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e1333  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e133c  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e1345  vmovaps xmm14, [rsp+0xE0]
00007cc2f47e134e  add rsp, 0xF0
00007cc2f47e1355  pop r11
00007cc2f47e1357  pop r10
00007cc2f47e1359  pop r9
00007cc2f47e135b  pop r8
00007cc2f47e135d  pop rsi
00007cc2f47e135e  pop rdi
00007cc2f47e135f  pop rdx
00007cc2f47e1360  pop rcx
00007cc2f47e1361  pop rax
00007cc2f47e1362  add rsp, 0x08
00007cc2f47e1366  jmp 0x00007CC2F47DF279
00007cc2f47e136b  sub rsp, 0x08
00007cc2f47e136f  push rax
00007cc2f47e1370  push rcx
00007cc2f47e1371  push rdx
00007cc2f47e1372  push rdi
00007cc2f47e1373  push rsi
00007cc2f47e1374  push r8
00007cc2f47e1376  push r9
00007cc2f47e1378  push r10
00007cc2f47e137a  push r11
00007cc2f47e137c  sub rsp, 0xF0
00007cc2f47e1383  vmovaps [rsp], xmm0
00007cc2f47e1388  vmovaps [rsp+0x10], xmm2
00007cc2f47e138e  vmovaps [rsp+0x20], xmm3
00007cc2f47e1394  vmovaps [rsp+0x30], xmm4
00007cc2f47e139a  vmovaps [rsp+0x40], xmm5
00007cc2f47e13a0  vmovaps [rsp+0x50], xmm6
00007cc2f47e13a6  vmovaps [rsp+0x60], xmm7
00007cc2f47e13ac  vmovaps [rsp+0x70], xmm8
00007cc2f47e13b2  vmovaps [rsp+0x80], xmm9
00007cc2f47e13bb  vmovaps [rsp+0x90], xmm10
00007cc2f47e13c4  vmovaps [rsp+0xA0], xmm11
00007cc2f47e13cd  vmovaps [rsp+0xB0], xmm12
00007cc2f47e13d6  vmovaps [rsp+0xC0], xmm13
00007cc2f47e13df  vmovaps [rsp+0xD0], xmm14
00007cc2f47e13e8  vmovaps [rsp+0xE0], xmm15
00007cc2f47e13f1  sub rsp, 0x30
00007cc2f47e13f5  movaps [rsp], xmm1
00007cc2f47e13f9  movaps [rsp+0x10], xmm5
00007cc2f47e13fe  movaps [rsp+0x20], xmm4
00007cc2f47e1403  lea rdi, [rsp]
00007cc2f47e1407  mov esi, 0x00
00007cc2f47e140c  mov rax, 0x5990E710A530
00007cc2f47e1416  call rax
00007cc2f47e1418  movaps xmm1, [rsp]
00007cc2f47e141c  add rsp, 0x30
00007cc2f47e1420  vmovaps xmm0, [rsp]
00007cc2f47e1425  vmovaps xmm2, [rsp+0x10]
00007cc2f47e142b  vmovaps xmm3, [rsp+0x20]
00007cc2f47e1431  vmovaps xmm4, [rsp+0x30]
00007cc2f47e1437  vmovaps xmm5, [rsp+0x40]
00007cc2f47e143d  vmovaps xmm6, [rsp+0x50]
00007cc2f47e1443  vmovaps xmm7, [rsp+0x60]
00007cc2f47e1449  vmovaps xmm8, [rsp+0x70]
00007cc2f47e144f  vmovaps xmm9, [rsp+0x80]
00007cc2f47e1458  vmovaps xmm10, [rsp+0x90]
00007cc2f47e1461  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e146a  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e1473  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e147c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e1485  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e148e  add rsp, 0xF0
00007cc2f47e1495  pop r11
00007cc2f47e1497  pop r10
00007cc2f47e1499  pop r9
00007cc2f47e149b  pop r8
00007cc2f47e149d  pop rsi
00007cc2f47e149e  pop rdi
00007cc2f47e149f  pop rdx
00007cc2f47e14a0  pop rcx
00007cc2f47e14a1  pop rax
00007cc2f47e14a2  add rsp, 0x08
00007cc2f47e14a6  jmp 0x00007CC2F47DF299
00007cc2f47e14ab  sub rsp, 0x08
00007cc2f47e14af  push rax
00007cc2f47e14b0  push rcx
00007cc2f47e14b1  push rdx
00007cc2f47e14b2  push rdi
00007cc2f47e14b3  push rsi
00007cc2f47e14b4  push r8
00007cc2f47e14b6  push r9
00007cc2f47e14b8  push r10
00007cc2f47e14ba  push r11
00007cc2f47e14bc  sub rsp, 0xF0
00007cc2f47e14c3  vmovaps [rsp], xmm0
00007cc2f47e14c8  vmovaps [rsp+0x10], xmm1
00007cc2f47e14ce  vmovaps [rsp+0x20], xmm2
00007cc2f47e14d4  vmovaps [rsp+0x30], xmm3
00007cc2f47e14da  vmovaps [rsp+0x40], xmm5
00007cc2f47e14e0  vmovaps [rsp+0x50], xmm6
00007cc2f47e14e6  vmovaps [rsp+0x60], xmm7
00007cc2f47e14ec  vmovaps [rsp+0x70], xmm8
00007cc2f47e14f2  vmovaps [rsp+0x80], xmm9
00007cc2f47e14fb  vmovaps [rsp+0x90], xmm10
00007cc2f47e1504  vmovaps [rsp+0xA0], xmm11
00007cc2f47e150d  vmovaps [rsp+0xB0], xmm12
00007cc2f47e1516  vmovaps [rsp+0xC0], xmm13
00007cc2f47e151f  vmovaps [rsp+0xD0], xmm14
00007cc2f47e1528  vmovaps [rsp+0xE0], xmm15
00007cc2f47e1531  sub rsp, 0x30
00007cc2f47e1535  movaps [rsp], xmm4
00007cc2f47e1539  movaps [rsp+0x10], xmm3
00007cc2f47e153e  movaps [rsp+0x20], xmm5
00007cc2f47e1543  lea rdi, [rsp]
00007cc2f47e1547  mov esi, 0x00
00007cc2f47e154c  mov rax, 0x5990E710A530
00007cc2f47e1556  call rax
00007cc2f47e1558  movaps xmm4, [rsp]
00007cc2f47e155c  add rsp, 0x30
00007cc2f47e1560  vmovaps xmm0, [rsp]
00007cc2f47e1565  vmovaps xmm1, [rsp+0x10]
00007cc2f47e156b  vmovaps xmm2, [rsp+0x20]
00007cc2f47e1571  vmovaps xmm3, [rsp+0x30]
00007cc2f47e1577  vmovaps xmm5, [rsp+0x40]
00007cc2f47e157d  vmovaps xmm6, [rsp+0x50]
00007cc2f47e1583  vmovaps xmm7, [rsp+0x60]
00007cc2f47e1589  vmovaps xmm8, [rsp+0x70]
00007cc2f47e158f  vmovaps xmm9, [rsp+0x80]
00007cc2f47e1598  vmovaps xmm10, [rsp+0x90]
00007cc2f47e15a1  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e15aa  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e15b3  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e15bc  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e15c5  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e15ce  add rsp, 0xF0
00007cc2f47e15d5  pop r11
00007cc2f47e15d7  pop r10
00007cc2f47e15d9  pop r9
00007cc2f47e15db  pop r8
00007cc2f47e15dd  pop rsi
00007cc2f47e15de  pop rdi
00007cc2f47e15df  pop rdx
00007cc2f47e15e0  pop rcx
00007cc2f47e15e1  pop rax
00007cc2f47e15e2  add rsp, 0x08
00007cc2f47e15e6  jmp 0x00007CC2F47DF2E7
00007cc2f47e15eb  call 0x00007CC2F46B52F0
00007cc2f47e15f0  jmp 0x00007CC2F47DF2F4
00007cc2f47e15f5  sub rsp, 0x08
00007cc2f47e15f9  push rax
00007cc2f47e15fa  push rcx
00007cc2f47e15fb  push rdx
00007cc2f47e15fc  push rdi
00007cc2f47e15fd  push rsi
00007cc2f47e15fe  push r8
00007cc2f47e1600  push r9
00007cc2f47e1602  push r10
00007cc2f47e1604  push r11
00007cc2f47e1606  sub rsp, 0xF0
00007cc2f47e160d  vmovaps [rsp], xmm0
00007cc2f47e1612  vmovaps [rsp+0x10], xmm1
00007cc2f47e1618  vmovaps [rsp+0x20], xmm2
00007cc2f47e161e  vmovaps [rsp+0x30], xmm3
00007cc2f47e1624  vmovaps [rsp+0x40], xmm4
00007cc2f47e162a  vmovaps [rsp+0x50], xmm6
00007cc2f47e1630  vmovaps [rsp+0x60], xmm7
00007cc2f47e1636  vmovaps [rsp+0x70], xmm8
00007cc2f47e163c  vmovaps [rsp+0x80], xmm9
00007cc2f47e1645  vmovaps [rsp+0x90], xmm10
00007cc2f47e164e  vmovaps [rsp+0xA0], xmm11
00007cc2f47e1657  vmovaps [rsp+0xB0], xmm12
00007cc2f47e1660  vmovaps [rsp+0xC0], xmm13
00007cc2f47e1669  vmovaps [rsp+0xD0], xmm14
00007cc2f47e1672  vmovaps [rsp+0xE0], xmm15
00007cc2f47e167b  sub rsp, 0x30
00007cc2f47e167f  movaps [rsp], xmm5
00007cc2f47e1683  movaps [rsp+0x10], xmm6
00007cc2f47e1688  movaps [rsp+0x20], xmm3
00007cc2f47e168d  lea rdi, [rsp]
00007cc2f47e1691  mov esi, 0x00
00007cc2f47e1696  mov rax, 0x5990E710A530
00007cc2f47e16a0  call rax
00007cc2f47e16a2  movaps xmm5, [rsp]
00007cc2f47e16a6  add rsp, 0x30
00007cc2f47e16aa  vmovaps xmm0, [rsp]
00007cc2f47e16af  vmovaps xmm1, [rsp+0x10]
00007cc2f47e16b5  vmovaps xmm2, [rsp+0x20]
00007cc2f47e16bb  vmovaps xmm3, [rsp+0x30]
00007cc2f47e16c1  vmovaps xmm4, [rsp+0x40]
00007cc2f47e16c7  vmovaps xmm6, [rsp+0x50]
00007cc2f47e16cd  vmovaps xmm7, [rsp+0x60]
00007cc2f47e16d3  vmovaps xmm8, [rsp+0x70]
00007cc2f47e16d9  vmovaps xmm9, [rsp+0x80]
00007cc2f47e16e2  vmovaps xmm10, [rsp+0x90]
00007cc2f47e16eb  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e16f4  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e16fd  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e1706  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e170f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e1718  add rsp, 0xF0
00007cc2f47e171f  pop r11
00007cc2f47e1721  pop r10
00007cc2f47e1723  pop r9
00007cc2f47e1725  pop r8
00007cc2f47e1727  pop rsi
00007cc2f47e1728  pop rdi
00007cc2f47e1729  pop rdx
00007cc2f47e172a  pop rcx
00007cc2f47e172b  pop rax
00007cc2f47e172c  add rsp, 0x08
00007cc2f47e1730  jmp 0x00007CC2F47DF31A
00007cc2f47e1735  sub rsp, 0x08
00007cc2f47e1739  push rax
00007cc2f47e173a  push rcx
00007cc2f47e173b  push rdx
00007cc2f47e173c  push rdi
00007cc2f47e173d  push rsi
00007cc2f47e173e  push r8
00007cc2f47e1740  push r9
00007cc2f47e1742  push r10
00007cc2f47e1744  push r11
00007cc2f47e1746  sub rsp, 0xF0
00007cc2f47e174d  vmovaps [rsp], xmm0
00007cc2f47e1752  vmovaps [rsp+0x10], xmm1
00007cc2f47e1758  vmovaps [rsp+0x20], xmm2
00007cc2f47e175e  vmovaps [rsp+0x30], xmm3
00007cc2f47e1764  vmovaps [rsp+0x40], xmm4
00007cc2f47e176a  vmovaps [rsp+0x50], xmm5
00007cc2f47e1770  vmovaps [rsp+0x60], xmm7
00007cc2f47e1776  vmovaps [rsp+0x70], xmm8
00007cc2f47e177c  vmovaps [rsp+0x80], xmm9
00007cc2f47e1785  vmovaps [rsp+0x90], xmm10
00007cc2f47e178e  vmovaps [rsp+0xA0], xmm11
00007cc2f47e1797  vmovaps [rsp+0xB0], xmm12
00007cc2f47e17a0  vmovaps [rsp+0xC0], xmm13
00007cc2f47e17a9  vmovaps [rsp+0xD0], xmm14
00007cc2f47e17b2  vmovaps [rsp+0xE0], xmm15
00007cc2f47e17bb  sub rsp, 0x30
00007cc2f47e17bf  movaps [rsp], xmm6
00007cc2f47e17c3  movaps [rsp+0x10], xmm9
00007cc2f47e17c9  movaps [rsp+0x20], xmm1
00007cc2f47e17ce  lea rdi, [rsp]
00007cc2f47e17d2  mov esi, 0x00
00007cc2f47e17d7  mov rax, 0x5990E710A530
00007cc2f47e17e1  call rax
00007cc2f47e17e3  movaps xmm6, [rsp]
00007cc2f47e17e7  add rsp, 0x30
00007cc2f47e17eb  vmovaps xmm0, [rsp]
00007cc2f47e17f0  vmovaps xmm1, [rsp+0x10]
00007cc2f47e17f6  vmovaps xmm2, [rsp+0x20]
00007cc2f47e17fc  vmovaps xmm3, [rsp+0x30]
00007cc2f47e1802  vmovaps xmm4, [rsp+0x40]
00007cc2f47e1808  vmovaps xmm5, [rsp+0x50]
00007cc2f47e180e  vmovaps xmm7, [rsp+0x60]
00007cc2f47e1814  vmovaps xmm8, [rsp+0x70]
00007cc2f47e181a  vmovaps xmm9, [rsp+0x80]
00007cc2f47e1823  vmovaps xmm10, [rsp+0x90]
00007cc2f47e182c  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e1835  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e183e  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e1847  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e1850  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e1859  add rsp, 0xF0
00007cc2f47e1860  pop r11
00007cc2f47e1862  pop r10
00007cc2f47e1864  pop r9
00007cc2f47e1866  pop r8
00007cc2f47e1868  pop rsi
00007cc2f47e1869  pop rdi
00007cc2f47e186a  pop rdx
00007cc2f47e186b  pop rcx
00007cc2f47e186c  pop rax
00007cc2f47e186d  add rsp, 0x08
00007cc2f47e1871  jmp 0x00007CC2F47DF33E
00007cc2f47e1876  sub rsp, 0x08
00007cc2f47e187a  push rax
00007cc2f47e187b  push rcx
00007cc2f47e187c  push rdx
00007cc2f47e187d  push rdi
00007cc2f47e187e  push rsi
00007cc2f47e187f  push r8
00007cc2f47e1881  push r9
00007cc2f47e1883  push r10
00007cc2f47e1885  push r11
00007cc2f47e1887  sub rsp, 0xF0
00007cc2f47e188e  vmovaps [rsp], xmm0
00007cc2f47e1893  vmovaps [rsp+0x10], xmm1
00007cc2f47e1899  vmovaps [rsp+0x20], xmm2
00007cc2f47e189f  vmovaps [rsp+0x30], xmm3
00007cc2f47e18a5  vmovaps [rsp+0x40], xmm4
00007cc2f47e18ab  vmovaps [rsp+0x50], xmm5
00007cc2f47e18b1  vmovaps [rsp+0x60], xmm6
00007cc2f47e18b7  vmovaps [rsp+0x70], xmm7
00007cc2f47e18bd  vmovaps [rsp+0x80], xmm8
00007cc2f47e18c6  vmovaps [rsp+0x90], xmm10
00007cc2f47e18cf  vmovaps [rsp+0xA0], xmm11
00007cc2f47e18d8  vmovaps [rsp+0xB0], xmm12
00007cc2f47e18e1  vmovaps [rsp+0xC0], xmm13
00007cc2f47e18ea  vmovaps [rsp+0xD0], xmm14
00007cc2f47e18f3  vmovaps [rsp+0xE0], xmm15
00007cc2f47e18fc  sub rsp, 0x30
00007cc2f47e1900  movaps [rsp], xmm9
00007cc2f47e1905  movaps [rsp+0x10], xmm3
00007cc2f47e190a  movaps [rsp+0x20], xmm1
00007cc2f47e190f  lea rdi, [rsp]
00007cc2f47e1913  mov esi, 0x00
00007cc2f47e1918  mov rax, 0x5990E710A530
00007cc2f47e1922  call rax
00007cc2f47e1924  movaps xmm9, [rsp]
00007cc2f47e1929  add rsp, 0x30
00007cc2f47e192d  vmovaps xmm0, [rsp]
00007cc2f47e1932  vmovaps xmm1, [rsp+0x10]
00007cc2f47e1938  vmovaps xmm2, [rsp+0x20]
00007cc2f47e193e  vmovaps xmm3, [rsp+0x30]
00007cc2f47e1944  vmovaps xmm4, [rsp+0x40]
00007cc2f47e194a  vmovaps xmm5, [rsp+0x50]
00007cc2f47e1950  vmovaps xmm6, [rsp+0x60]
00007cc2f47e1956  vmovaps xmm7, [rsp+0x70]
00007cc2f47e195c  vmovaps xmm8, [rsp+0x80]
00007cc2f47e1965  vmovaps xmm10, [rsp+0x90]
00007cc2f47e196e  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e1977  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e1980  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e1989  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e1992  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e199b  add rsp, 0xF0
00007cc2f47e19a2  pop r11
00007cc2f47e19a4  pop r10
00007cc2f47e19a6  pop r9
00007cc2f47e19a8  pop r8
00007cc2f47e19aa  pop rsi
00007cc2f47e19ab  pop rdi
00007cc2f47e19ac  pop rdx
00007cc2f47e19ad  pop rcx
00007cc2f47e19ae  pop rax
00007cc2f47e19af  add rsp, 0x08
00007cc2f47e19b3  jmp 0x00007CC2F47DF38A
00007cc2f47e19b8  call 0x00007CC2F46B52F0
00007cc2f47e19bd  jmp 0x00007CC2F47DF397
00007cc2f47e19c2  sub rsp, 0x08
00007cc2f47e19c6  push rax
00007cc2f47e19c7  push rcx
00007cc2f47e19c8  push rdx
00007cc2f47e19c9  push rdi
00007cc2f47e19ca  push rsi
00007cc2f47e19cb  push r8
00007cc2f47e19cd  push r9
00007cc2f47e19cf  push r10
00007cc2f47e19d1  push r11
00007cc2f47e19d3  sub rsp, 0xF0
00007cc2f47e19da  vmovaps [rsp], xmm0
00007cc2f47e19df  vmovaps [rsp+0x10], xmm1
00007cc2f47e19e5  vmovaps [rsp+0x20], xmm2
00007cc2f47e19eb  vmovaps [rsp+0x30], xmm3
00007cc2f47e19f1  vmovaps [rsp+0x40], xmm4
00007cc2f47e19f7  vmovaps [rsp+0x50], xmm5
00007cc2f47e19fd  vmovaps [rsp+0x60], xmm6
00007cc2f47e1a03  vmovaps [rsp+0x70], xmm7
00007cc2f47e1a09  vmovaps [rsp+0x80], xmm8
00007cc2f47e1a12  vmovaps [rsp+0x90], xmm9
00007cc2f47e1a1b  vmovaps [rsp+0xA0], xmm10
00007cc2f47e1a24  vmovaps [rsp+0xB0], xmm11
00007cc2f47e1a2d  vmovaps [rsp+0xC0], xmm12
00007cc2f47e1a36  vmovaps [rsp+0xD0], xmm13
00007cc2f47e1a3f  vmovaps [rsp+0xE0], xmm14
00007cc2f47e1a48  sub rsp, 0x30
00007cc2f47e1a4c  movaps [rsp], xmm15
00007cc2f47e1a51  movaps [rsp+0x10], xmm3
00007cc2f47e1a56  movaps [rsp+0x20], xmm7
00007cc2f47e1a5b  lea rdi, [rsp]
00007cc2f47e1a5f  mov esi, 0x00
00007cc2f47e1a64  mov rax, 0x5990E710A530
00007cc2f47e1a6e  call rax
00007cc2f47e1a70  movaps xmm15, [rsp]
00007cc2f47e1a75  add rsp, 0x30
00007cc2f47e1a79  vmovaps xmm0, [rsp]
00007cc2f47e1a7e  vmovaps xmm1, [rsp+0x10]
00007cc2f47e1a84  vmovaps xmm2, [rsp+0x20]
00007cc2f47e1a8a  vmovaps xmm3, [rsp+0x30]
00007cc2f47e1a90  vmovaps xmm4, [rsp+0x40]
00007cc2f47e1a96  vmovaps xmm5, [rsp+0x50]
00007cc2f47e1a9c  vmovaps xmm6, [rsp+0x60]
00007cc2f47e1aa2  vmovaps xmm7, [rsp+0x70]
00007cc2f47e1aa8  vmovaps xmm8, [rsp+0x80]
00007cc2f47e1ab1  vmovaps xmm9, [rsp+0x90]
00007cc2f47e1aba  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e1ac3  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e1acc  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e1ad5  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e1ade  vmovaps xmm14, [rsp+0xE0]
00007cc2f47e1ae7  add rsp, 0xF0
00007cc2f47e1aee  pop r11
00007cc2f47e1af0  pop r10
00007cc2f47e1af2  pop r9
00007cc2f47e1af4  pop r8
00007cc2f47e1af6  pop rsi
00007cc2f47e1af7  pop rdi
00007cc2f47e1af8  pop rdx
00007cc2f47e1af9  pop rcx
00007cc2f47e1afa  pop rax
00007cc2f47e1afb  add rsp, 0x08
00007cc2f47e1aff  jmp 0x00007CC2F47DF3C3
00007cc2f47e1b04  sub rsp, 0x08
00007cc2f47e1b08  push rax
00007cc2f47e1b09  push rcx
00007cc2f47e1b0a  push rdx
00007cc2f47e1b0b  push rdi
00007cc2f47e1b0c  push rsi
00007cc2f47e1b0d  push r8
00007cc2f47e1b0f  push r9
00007cc2f47e1b11  push r10
00007cc2f47e1b13  push r11
00007cc2f47e1b15  sub rsp, 0xF0
00007cc2f47e1b1c  vmovaps [rsp], xmm0
00007cc2f47e1b21  vmovaps [rsp+0x10], xmm1
00007cc2f47e1b27  vmovaps [rsp+0x20], xmm2
00007cc2f47e1b2d  vmovaps [rsp+0x30], xmm4
00007cc2f47e1b33  vmovaps [rsp+0x40], xmm5
00007cc2f47e1b39  vmovaps [rsp+0x50], xmm6
00007cc2f47e1b3f  vmovaps [rsp+0x60], xmm7
00007cc2f47e1b45  vmovaps [rsp+0x70], xmm8
00007cc2f47e1b4b  vmovaps [rsp+0x80], xmm9
00007cc2f47e1b54  vmovaps [rsp+0x90], xmm10
00007cc2f47e1b5d  vmovaps [rsp+0xA0], xmm11
00007cc2f47e1b66  vmovaps [rsp+0xB0], xmm12
00007cc2f47e1b6f  vmovaps [rsp+0xC0], xmm13
00007cc2f47e1b78  vmovaps [rsp+0xD0], xmm14
00007cc2f47e1b81  vmovaps [rsp+0xE0], xmm15
00007cc2f47e1b8a  sub rsp, 0x30
00007cc2f47e1b8e  movaps [rsp], xmm3
00007cc2f47e1b92  movaps [rsp+0x10], xmm1
00007cc2f47e1b97  movaps [rsp+0x20], xmm15
00007cc2f47e1b9d  lea rdi, [rsp]
00007cc2f47e1ba1  mov esi, 0x00
00007cc2f47e1ba6  mov rax, 0x5990E710A530
00007cc2f47e1bb0  call rax
00007cc2f47e1bb2  movaps xmm3, [rsp]
00007cc2f47e1bb6  add rsp, 0x30
00007cc2f47e1bba  vmovaps xmm0, [rsp]
00007cc2f47e1bbf  vmovaps xmm1, [rsp+0x10]
00007cc2f47e1bc5  vmovaps xmm2, [rsp+0x20]
00007cc2f47e1bcb  vmovaps xmm4, [rsp+0x30]
00007cc2f47e1bd1  vmovaps xmm5, [rsp+0x40]
00007cc2f47e1bd7  vmovaps xmm6, [rsp+0x50]
00007cc2f47e1bdd  vmovaps xmm7, [rsp+0x60]
00007cc2f47e1be3  vmovaps xmm8, [rsp+0x70]
00007cc2f47e1be9  vmovaps xmm9, [rsp+0x80]
00007cc2f47e1bf2  vmovaps xmm10, [rsp+0x90]
00007cc2f47e1bfb  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e1c04  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e1c0d  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e1c16  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e1c1f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e1c28  add rsp, 0xF0
00007cc2f47e1c2f  pop r11
00007cc2f47e1c31  pop r10
00007cc2f47e1c33  pop r9
00007cc2f47e1c35  pop r8
00007cc2f47e1c37  pop rsi
00007cc2f47e1c38  pop rdi
00007cc2f47e1c39  pop rdx
00007cc2f47e1c3a  pop rcx
00007cc2f47e1c3b  pop rax
00007cc2f47e1c3c  add rsp, 0x08
00007cc2f47e1c40  jmp 0x00007CC2F47DF452
00007cc2f47e1c45  call 0x00007CC2F46B52F0
00007cc2f47e1c4a  jmp 0x00007CC2F47DF45C
00007cc2f47e1c4f  sub rsp, 0x08
00007cc2f47e1c53  push rax
00007cc2f47e1c54  push rcx
00007cc2f47e1c55  push rdx
00007cc2f47e1c56  push rdi
00007cc2f47e1c57  push rsi
00007cc2f47e1c58  push r8
00007cc2f47e1c5a  push r9
00007cc2f47e1c5c  push r10
00007cc2f47e1c5e  push r11
00007cc2f47e1c60  sub rsp, 0xF0
00007cc2f47e1c67  vmovaps [rsp], xmm0
00007cc2f47e1c6c  vmovaps [rsp+0x10], xmm1
00007cc2f47e1c72  vmovaps [rsp+0x20], xmm2
00007cc2f47e1c78  vmovaps [rsp+0x30], xmm3
00007cc2f47e1c7e  vmovaps [rsp+0x40], xmm4
00007cc2f47e1c84  vmovaps [rsp+0x50], xmm5
00007cc2f47e1c8a  vmovaps [rsp+0x60], xmm6
00007cc2f47e1c90  vmovaps [rsp+0x70], xmm7
00007cc2f47e1c96  vmovaps [rsp+0x80], xmm8
00007cc2f47e1c9f  vmovaps [rsp+0x90], xmm9
00007cc2f47e1ca8  vmovaps [rsp+0xA0], xmm10
00007cc2f47e1cb1  vmovaps [rsp+0xB0], xmm11
00007cc2f47e1cba  vmovaps [rsp+0xC0], xmm12
00007cc2f47e1cc3  vmovaps [rsp+0xD0], xmm13
00007cc2f47e1ccc  vmovaps [rsp+0xE0], xmm14
00007cc2f47e1cd5  sub rsp, 0x30
00007cc2f47e1cd9  movaps [rsp], xmm15
00007cc2f47e1cde  movaps [rsp+0x10], xmm14
00007cc2f47e1ce4  movaps [rsp+0x20], xmm4
00007cc2f47e1ce9  lea rdi, [rsp]
00007cc2f47e1ced  mov esi, 0x00
00007cc2f47e1cf2  mov rax, 0x5990E710A530
00007cc2f47e1cfc  call rax
00007cc2f47e1cfe  movaps xmm15, [rsp]
00007cc2f47e1d03  add rsp, 0x30
00007cc2f47e1d07  vmovaps xmm0, [rsp]
00007cc2f47e1d0c  vmovaps xmm1, [rsp+0x10]
00007cc2f47e1d12  vmovaps xmm2, [rsp+0x20]
00007cc2f47e1d18  vmovaps xmm3, [rsp+0x30]
00007cc2f47e1d1e  vmovaps xmm4, [rsp+0x40]
00007cc2f47e1d24  vmovaps xmm5, [rsp+0x50]
00007cc2f47e1d2a  vmovaps xmm6, [rsp+0x60]
00007cc2f47e1d30  vmovaps xmm7, [rsp+0x70]
00007cc2f47e1d36  vmovaps xmm8, [rsp+0x80]
00007cc2f47e1d3f  vmovaps xmm9, [rsp+0x90]
00007cc2f47e1d48  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e1d51  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e1d5a  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e1d63  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e1d6c  vmovaps xmm14, [rsp+0xE0]
00007cc2f47e1d75  add rsp, 0xF0
00007cc2f47e1d7c  pop r11
00007cc2f47e1d7e  pop r10
00007cc2f47e1d80  pop r9
00007cc2f47e1d82  pop r8
00007cc2f47e1d84  pop rsi
00007cc2f47e1d85  pop rdi
00007cc2f47e1d86  pop rdx
00007cc2f47e1d87  pop rcx
00007cc2f47e1d88  pop rax
00007cc2f47e1d89  add rsp, 0x08
00007cc2f47e1d8d  jmp 0x00007CC2F47DF48A
00007cc2f47e1d92  sub rsp, 0x08
00007cc2f47e1d96  push rax
00007cc2f47e1d97  push rcx
00007cc2f47e1d98  push rdx
00007cc2f47e1d99  push rdi
00007cc2f47e1d9a  push rsi
00007cc2f47e1d9b  push r8
00007cc2f47e1d9d  push r9
00007cc2f47e1d9f  push r10
00007cc2f47e1da1  push r11
00007cc2f47e1da3  sub rsp, 0xF0
00007cc2f47e1daa  vmovaps [rsp], xmm0
00007cc2f47e1daf  vmovaps [rsp+0x10], xmm1
00007cc2f47e1db5  vmovaps [rsp+0x20], xmm2
00007cc2f47e1dbb  vmovaps [rsp+0x30], xmm3
00007cc2f47e1dc1  vmovaps [rsp+0x40], xmm4
00007cc2f47e1dc7  vmovaps [rsp+0x50], xmm5
00007cc2f47e1dcd  vmovaps [rsp+0x60], xmm6
00007cc2f47e1dd3  vmovaps [rsp+0x70], xmm7
00007cc2f47e1dd9  vmovaps [rsp+0x80], xmm8
00007cc2f47e1de2  vmovaps [rsp+0x90], xmm9
00007cc2f47e1deb  vmovaps [rsp+0xA0], xmm10
00007cc2f47e1df4  vmovaps [rsp+0xB0], xmm11
00007cc2f47e1dfd  vmovaps [rsp+0xC0], xmm12
00007cc2f47e1e06  vmovaps [rsp+0xD0], xmm13
00007cc2f47e1e0f  vmovaps [rsp+0xE0], xmm15
00007cc2f47e1e18  sub rsp, 0x30
00007cc2f47e1e1c  movaps [rsp], xmm14
00007cc2f47e1e21  movaps [rsp+0x10], xmm2
00007cc2f47e1e26  movaps [rsp+0x20], xmm1
00007cc2f47e1e2b  lea rdi, [rsp]
00007cc2f47e1e2f  mov esi, 0x00
00007cc2f47e1e34  mov rax, 0x5990E710A530
00007cc2f47e1e3e  call rax
00007cc2f47e1e40  movaps xmm14, [rsp]
00007cc2f47e1e45  add rsp, 0x30
00007cc2f47e1e49  vmovaps xmm0, [rsp]
00007cc2f47e1e4e  vmovaps xmm1, [rsp+0x10]
00007cc2f47e1e54  vmovaps xmm2, [rsp+0x20]
00007cc2f47e1e5a  vmovaps xmm3, [rsp+0x30]
00007cc2f47e1e60  vmovaps xmm4, [rsp+0x40]
00007cc2f47e1e66  vmovaps xmm5, [rsp+0x50]
00007cc2f47e1e6c  vmovaps xmm6, [rsp+0x60]
00007cc2f47e1e72  vmovaps xmm7, [rsp+0x70]
00007cc2f47e1e78  vmovaps xmm8, [rsp+0x80]
00007cc2f47e1e81  vmovaps xmm9, [rsp+0x90]
00007cc2f47e1e8a  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e1e93  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e1e9c  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e1ea5  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e1eae  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e1eb7  add rsp, 0xF0
00007cc2f47e1ebe  pop r11
00007cc2f47e1ec0  pop r10
00007cc2f47e1ec2  pop r9
00007cc2f47e1ec4  pop r8
00007cc2f47e1ec6  pop rsi
00007cc2f47e1ec7  pop rdi
00007cc2f47e1ec8  pop rdx
00007cc2f47e1ec9  pop rcx
00007cc2f47e1eca  pop rax
00007cc2f47e1ecb  add rsp, 0x08
00007cc2f47e1ecf  jmp 0x00007CC2F47DF4B0
00007cc2f47e1ed4  sub rsp, 0x08
00007cc2f47e1ed8  push rax
00007cc2f47e1ed9  push rcx
00007cc2f47e1eda  push rdx
00007cc2f47e1edb  push rdi
00007cc2f47e1edc  push rsi
00007cc2f47e1edd  push r8
00007cc2f47e1edf  push r9
00007cc2f47e1ee1  push r10
00007cc2f47e1ee3  push r11
00007cc2f47e1ee5  sub rsp, 0xF0
00007cc2f47e1eec  vmovaps [rsp], xmm0
00007cc2f47e1ef1  vmovaps [rsp+0x10], xmm2
00007cc2f47e1ef7  vmovaps [rsp+0x20], xmm3
00007cc2f47e1efd  vmovaps [rsp+0x30], xmm4
00007cc2f47e1f03  vmovaps [rsp+0x40], xmm5
00007cc2f47e1f09  vmovaps [rsp+0x50], xmm6
00007cc2f47e1f0f  vmovaps [rsp+0x60], xmm7
00007cc2f47e1f15  vmovaps [rsp+0x70], xmm8
00007cc2f47e1f1b  vmovaps [rsp+0x80], xmm9
00007cc2f47e1f24  vmovaps [rsp+0x90], xmm10
00007cc2f47e1f2d  vmovaps [rsp+0xA0], xmm11
00007cc2f47e1f36  vmovaps [rsp+0xB0], xmm12
00007cc2f47e1f3f  vmovaps [rsp+0xC0], xmm13
00007cc2f47e1f48  vmovaps [rsp+0xD0], xmm14
00007cc2f47e1f51  vmovaps [rsp+0xE0], xmm15
00007cc2f47e1f5a  sub rsp, 0x30
00007cc2f47e1f5e  movaps [rsp], xmm1
00007cc2f47e1f62  movaps [rsp+0x10], xmm4
00007cc2f47e1f67  movaps [rsp+0x20], xmm9
00007cc2f47e1f6d  lea rdi, [rsp]
00007cc2f47e1f71  mov esi, 0x00
00007cc2f47e1f76  mov rax, 0x5990E710A530
00007cc2f47e1f80  call rax
00007cc2f47e1f82  movaps xmm1, [rsp]
00007cc2f47e1f86  add rsp, 0x30
00007cc2f47e1f8a  vmovaps xmm0, [rsp]
00007cc2f47e1f8f  vmovaps xmm2, [rsp+0x10]
00007cc2f47e1f95  vmovaps xmm3, [rsp+0x20]
00007cc2f47e1f9b  vmovaps xmm4, [rsp+0x30]
00007cc2f47e1fa1  vmovaps xmm5, [rsp+0x40]
00007cc2f47e1fa7  vmovaps xmm6, [rsp+0x50]
00007cc2f47e1fad  vmovaps xmm7, [rsp+0x60]
00007cc2f47e1fb3  vmovaps xmm8, [rsp+0x70]
00007cc2f47e1fb9  vmovaps xmm9, [rsp+0x80]
00007cc2f47e1fc2  vmovaps xmm10, [rsp+0x90]
00007cc2f47e1fcb  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e1fd4  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e1fdd  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e1fe6  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e1fef  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e1ff8  add rsp, 0xF0
00007cc2f47e1fff  pop r11
00007cc2f47e2001  pop r10
00007cc2f47e2003  pop r9
00007cc2f47e2005  pop r8
00007cc2f47e2007  pop rsi
00007cc2f47e2008  pop rdi
00007cc2f47e2009  pop rdx
00007cc2f47e200a  pop rcx
00007cc2f47e200b  pop rax
00007cc2f47e200c  add rsp, 0x08
00007cc2f47e2010  jmp 0x00007CC2F47DF4CE
00007cc2f47e2015  sub rsp, 0x08
00007cc2f47e2019  push rax
00007cc2f47e201a  push rcx
00007cc2f47e201b  push rdx
00007cc2f47e201c  push rdi
00007cc2f47e201d  push rsi
00007cc2f47e201e  push r8
00007cc2f47e2020  push r9
00007cc2f47e2022  push r10
00007cc2f47e2024  push r11
00007cc2f47e2026  sub rsp, 0xF0
00007cc2f47e202d  vmovaps [rsp], xmm0
00007cc2f47e2032  vmovaps [rsp+0x10], xmm1
00007cc2f47e2038  vmovaps [rsp+0x20], xmm2
00007cc2f47e203e  vmovaps [rsp+0x30], xmm3
00007cc2f47e2044  vmovaps [rsp+0x40], xmm5
00007cc2f47e204a  vmovaps [rsp+0x50], xmm6
00007cc2f47e2050  vmovaps [rsp+0x60], xmm7
00007cc2f47e2056  vmovaps [rsp+0x70], xmm8
00007cc2f47e205c  vmovaps [rsp+0x80], xmm9
00007cc2f47e2065  vmovaps [rsp+0x90], xmm10
00007cc2f47e206e  vmovaps [rsp+0xA0], xmm11
00007cc2f47e2077  vmovaps [rsp+0xB0], xmm12
00007cc2f47e2080  vmovaps [rsp+0xC0], xmm13
00007cc2f47e2089  vmovaps [rsp+0xD0], xmm14
00007cc2f47e2092  vmovaps [rsp+0xE0], xmm15
00007cc2f47e209b  sub rsp, 0x30
00007cc2f47e209f  movaps [rsp], xmm4
00007cc2f47e20a3  movaps [rsp+0x10], xmm2
00007cc2f47e20a8  movaps [rsp+0x20], xmm9
00007cc2f47e20ae  lea rdi, [rsp]
00007cc2f47e20b2  mov esi, 0x00
00007cc2f47e20b7  mov rax, 0x5990E710A530
00007cc2f47e20c1  call rax
00007cc2f47e20c3  movaps xmm4, [rsp]
00007cc2f47e20c7  add rsp, 0x30
00007cc2f47e20cb  vmovaps xmm0, [rsp]
00007cc2f47e20d0  vmovaps xmm1, [rsp+0x10]
00007cc2f47e20d6  vmovaps xmm2, [rsp+0x20]
00007cc2f47e20dc  vmovaps xmm3, [rsp+0x30]
00007cc2f47e20e2  vmovaps xmm5, [rsp+0x40]
00007cc2f47e20e8  vmovaps xmm6, [rsp+0x50]
00007cc2f47e20ee  vmovaps xmm7, [rsp+0x60]
00007cc2f47e20f4  vmovaps xmm8, [rsp+0x70]
00007cc2f47e20fa  vmovaps xmm9, [rsp+0x80]
00007cc2f47e2103  vmovaps xmm10, [rsp+0x90]
00007cc2f47e210c  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e2115  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e211e  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e2127  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e2130  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e2139  add rsp, 0xF0
00007cc2f47e2140  pop r11
00007cc2f47e2142  pop r10
00007cc2f47e2144  pop r9
00007cc2f47e2146  pop r8
00007cc2f47e2148  pop rsi
00007cc2f47e2149  pop rdi
00007cc2f47e214a  pop rdx
00007cc2f47e214b  pop rcx
00007cc2f47e214c  pop rax
00007cc2f47e214d  add rsp, 0x08
00007cc2f47e2151  jmp 0x00007CC2F47DF4FE
00007cc2f47e2156  sub rsp, 0x08
00007cc2f47e215a  push rax
00007cc2f47e215b  push rcx
00007cc2f47e215c  push rdx
00007cc2f47e215d  push rdi
00007cc2f47e215e  push rsi
00007cc2f47e215f  push r8
00007cc2f47e2161  push r9
00007cc2f47e2163  push r10
00007cc2f47e2165  push r11
00007cc2f47e2167  sub rsp, 0xF0
00007cc2f47e216e  vmovaps [rsp], xmm0
00007cc2f47e2173  vmovaps [rsp+0x10], xmm1
00007cc2f47e2179  vmovaps [rsp+0x20], xmm2
00007cc2f47e217f  vmovaps [rsp+0x30], xmm3
00007cc2f47e2185  vmovaps [rsp+0x40], xmm4
00007cc2f47e218b  vmovaps [rsp+0x50], xmm5
00007cc2f47e2191  vmovaps [rsp+0x60], xmm6
00007cc2f47e2197  vmovaps [rsp+0x70], xmm7
00007cc2f47e219d  vmovaps [rsp+0x80], xmm8
00007cc2f47e21a6  vmovaps [rsp+0x90], xmm10
00007cc2f47e21af  vmovaps [rsp+0xA0], xmm11
00007cc2f47e21b8  vmovaps [rsp+0xB0], xmm12
00007cc2f47e21c1  vmovaps [rsp+0xC0], xmm13
00007cc2f47e21ca  vmovaps [rsp+0xD0], xmm14
00007cc2f47e21d3  vmovaps [rsp+0xE0], xmm15
00007cc2f47e21dc  sub rsp, 0x30
00007cc2f47e21e0  movaps [rsp], xmm9
00007cc2f47e21e5  movaps [rsp+0x10], xmm2
00007cc2f47e21ea  movaps [rsp+0x20], xmm1
00007cc2f47e21ef  lea rdi, [rsp]
00007cc2f47e21f3  mov esi, 0x00
00007cc2f47e21f8  mov rax, 0x5990E710A530
00007cc2f47e2202  call rax
00007cc2f47e2204  movaps xmm9, [rsp]
00007cc2f47e2209  add rsp, 0x30
00007cc2f47e220d  vmovaps xmm0, [rsp]
00007cc2f47e2212  vmovaps xmm1, [rsp+0x10]
00007cc2f47e2218  vmovaps xmm2, [rsp+0x20]
00007cc2f47e221e  vmovaps xmm3, [rsp+0x30]
00007cc2f47e2224  vmovaps xmm4, [rsp+0x40]
00007cc2f47e222a  vmovaps xmm5, [rsp+0x50]
00007cc2f47e2230  vmovaps xmm6, [rsp+0x60]
00007cc2f47e2236  vmovaps xmm7, [rsp+0x70]
00007cc2f47e223c  vmovaps xmm8, [rsp+0x80]
00007cc2f47e2245  vmovaps xmm10, [rsp+0x90]
00007cc2f47e224e  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e2257  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e2260  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e2269  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e2272  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e227b  add rsp, 0xF0
00007cc2f47e2282  pop r11
00007cc2f47e2284  pop r10
00007cc2f47e2286  pop r9
00007cc2f47e2288  pop r8
00007cc2f47e228a  pop rsi
00007cc2f47e228b  pop rdi
00007cc2f47e228c  pop rdx
00007cc2f47e228d  pop rcx
00007cc2f47e228e  pop rax
00007cc2f47e228f  add rsp, 0x08
00007cc2f47e2293  jmp 0x00007CC2F47DF534
00007cc2f47e2298  sub rsp, 0x08
00007cc2f47e229c  push rax
00007cc2f47e229d  push rcx
00007cc2f47e229e  push rdx
00007cc2f47e229f  push rdi
00007cc2f47e22a0  push rsi
00007cc2f47e22a1  push r8
00007cc2f47e22a3  push r9
00007cc2f47e22a5  push r10
00007cc2f47e22a7  push r11
00007cc2f47e22a9  sub rsp, 0xF0
00007cc2f47e22b0  vmovaps [rsp], xmm0
00007cc2f47e22b5  vmovaps [rsp+0x10], xmm2
00007cc2f47e22bb  vmovaps [rsp+0x20], xmm3
00007cc2f47e22c1  vmovaps [rsp+0x30], xmm4
00007cc2f47e22c7  vmovaps [rsp+0x40], xmm5
00007cc2f47e22cd  vmovaps [rsp+0x50], xmm6
00007cc2f47e22d3  vmovaps [rsp+0x60], xmm7
00007cc2f47e22d9  vmovaps [rsp+0x70], xmm8
00007cc2f47e22df  vmovaps [rsp+0x80], xmm9
00007cc2f47e22e8  vmovaps [rsp+0x90], xmm10
00007cc2f47e22f1  vmovaps [rsp+0xA0], xmm11
00007cc2f47e22fa  vmovaps [rsp+0xB0], xmm12
00007cc2f47e2303  vmovaps [rsp+0xC0], xmm13
00007cc2f47e230c  vmovaps [rsp+0xD0], xmm14
00007cc2f47e2315  vmovaps [rsp+0xE0], xmm15
00007cc2f47e231e  sub rsp, 0x30
00007cc2f47e2322  movaps [rsp], xmm1
00007cc2f47e2326  movaps [rsp+0x10], xmm15
00007cc2f47e232c  movaps [rsp+0x20], xmm6
00007cc2f47e2331  lea rdi, [rsp]
00007cc2f47e2335  mov esi, 0x00
00007cc2f47e233a  mov rax, 0x5990E710A530
00007cc2f47e2344  call rax
00007cc2f47e2346  movaps xmm1, [rsp]
00007cc2f47e234a  add rsp, 0x30
00007cc2f47e234e  vmovaps xmm0, [rsp]
00007cc2f47e2353  vmovaps xmm2, [rsp+0x10]
00007cc2f47e2359  vmovaps xmm3, [rsp+0x20]
00007cc2f47e235f  vmovaps xmm4, [rsp+0x30]
00007cc2f47e2365  vmovaps xmm5, [rsp+0x40]
00007cc2f47e236b  vmovaps xmm6, [rsp+0x50]
00007cc2f47e2371  vmovaps xmm7, [rsp+0x60]
00007cc2f47e2377  vmovaps xmm8, [rsp+0x70]
00007cc2f47e237d  vmovaps xmm9, [rsp+0x80]
00007cc2f47e2386  vmovaps xmm10, [rsp+0x90]
00007cc2f47e238f  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e2398  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e23a1  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e23aa  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e23b3  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e23bc  add rsp, 0xF0
00007cc2f47e23c3  pop r11
00007cc2f47e23c5  pop r10
00007cc2f47e23c7  pop r9
00007cc2f47e23c9  pop r8
00007cc2f47e23cb  pop rsi
00007cc2f47e23cc  pop rdi
00007cc2f47e23cd  pop rdx
00007cc2f47e23ce  pop rcx
00007cc2f47e23cf  pop rax
00007cc2f47e23d0  add rsp, 0x08
00007cc2f47e23d4  jmp 0x00007CC2F47DF555
00007cc2f47e23d9  sub rsp, 0x08
00007cc2f47e23dd  push rax
00007cc2f47e23de  push rcx
00007cc2f47e23df  push rdx
00007cc2f47e23e0  push rdi
00007cc2f47e23e1  push rsi
00007cc2f47e23e2  push r8
00007cc2f47e23e4  push r9
00007cc2f47e23e6  push r10
00007cc2f47e23e8  push r11
00007cc2f47e23ea  sub rsp, 0xF0
00007cc2f47e23f1  vmovaps [rsp], xmm0
00007cc2f47e23f6  vmovaps [rsp+0x10], xmm1
00007cc2f47e23fc  vmovaps [rsp+0x20], xmm2
00007cc2f47e2402  vmovaps [rsp+0x30], xmm3
00007cc2f47e2408  vmovaps [rsp+0x40], xmm4
00007cc2f47e240e  vmovaps [rsp+0x50], xmm5
00007cc2f47e2414  vmovaps [rsp+0x60], xmm6
00007cc2f47e241a  vmovaps [rsp+0x70], xmm7
00007cc2f47e2420  vmovaps [rsp+0x80], xmm8
00007cc2f47e2429  vmovaps [rsp+0x90], xmm9
00007cc2f47e2432  vmovaps [rsp+0xA0], xmm10
00007cc2f47e243b  vmovaps [rsp+0xB0], xmm11
00007cc2f47e2444  vmovaps [rsp+0xC0], xmm12
00007cc2f47e244d  vmovaps [rsp+0xD0], xmm13
00007cc2f47e2456  vmovaps [rsp+0xE0], xmm14
00007cc2f47e245f  sub rsp, 0x30
00007cc2f47e2463  movaps [rsp], xmm15
00007cc2f47e2468  movaps [rsp+0x10], xmm5
00007cc2f47e246d  movaps [rsp+0x20], xmm3
00007cc2f47e2472  lea rdi, [rsp]
00007cc2f47e2476  mov esi, 0x00
00007cc2f47e247b  mov rax, 0x5990E710A530
00007cc2f47e2485  call rax
00007cc2f47e2487  movaps xmm15, [rsp]
00007cc2f47e248c  add rsp, 0x30
00007cc2f47e2490  vmovaps xmm0, [rsp]
00007cc2f47e2495  vmovaps xmm1, [rsp+0x10]
00007cc2f47e249b  vmovaps xmm2, [rsp+0x20]
00007cc2f47e24a1  vmovaps xmm3, [rsp+0x30]
00007cc2f47e24a7  vmovaps xmm4, [rsp+0x40]
00007cc2f47e24ad  vmovaps xmm5, [rsp+0x50]
00007cc2f47e24b3  vmovaps xmm6, [rsp+0x60]
00007cc2f47e24b9  vmovaps xmm7, [rsp+0x70]
00007cc2f47e24bf  vmovaps xmm8, [rsp+0x80]
00007cc2f47e24c8  vmovaps xmm9, [rsp+0x90]
00007cc2f47e24d1  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e24da  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e24e3  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e24ec  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e24f5  vmovaps xmm14, [rsp+0xE0]
00007cc2f47e24fe  add rsp, 0xF0
00007cc2f47e2505  pop r11
00007cc2f47e2507  pop r10
00007cc2f47e2509  pop r9
00007cc2f47e250b  pop r8
00007cc2f47e250d  pop rsi
00007cc2f47e250e  pop rdi
00007cc2f47e250f  pop rdx
00007cc2f47e2510  pop rcx
00007cc2f47e2511  pop rax
00007cc2f47e2512  add rsp, 0x08
00007cc2f47e2516  jmp 0x00007CC2F47DF56F
00007cc2f47e251b  sub rsp, 0x08
00007cc2f47e251f  push rax
00007cc2f47e2520  push rcx
00007cc2f47e2521  push rdx
00007cc2f47e2522  push rdi
00007cc2f47e2523  push rsi
00007cc2f47e2524  push r8
00007cc2f47e2526  push r9
00007cc2f47e2528  push r10
00007cc2f47e252a  push r11
00007cc2f47e252c  sub rsp, 0xF0
00007cc2f47e2533  vmovaps [rsp], xmm0
00007cc2f47e2538  vmovaps [rsp+0x10], xmm1
00007cc2f47e253e  vmovaps [rsp+0x20], xmm2
00007cc2f47e2544  vmovaps [rsp+0x30], xmm3
00007cc2f47e254a  vmovaps [rsp+0x40], xmm4
00007cc2f47e2550  vmovaps [rsp+0x50], xmm6
00007cc2f47e2556  vmovaps [rsp+0x60], xmm7
00007cc2f47e255c  vmovaps [rsp+0x70], xmm8
00007cc2f47e2562  vmovaps [rsp+0x80], xmm9
00007cc2f47e256b  vmovaps [rsp+0x90], xmm10
00007cc2f47e2574  vmovaps [rsp+0xA0], xmm11
00007cc2f47e257d  vmovaps [rsp+0xB0], xmm12
00007cc2f47e2586  vmovaps [rsp+0xC0], xmm13
00007cc2f47e258f  vmovaps [rsp+0xD0], xmm14
00007cc2f47e2598  vmovaps [rsp+0xE0], xmm15
00007cc2f47e25a1  sub rsp, 0x30
00007cc2f47e25a5  movaps [rsp], xmm5
00007cc2f47e25a9  movaps [rsp+0x10], xmm8
00007cc2f47e25af  movaps [rsp+0x20], xmm6
00007cc2f47e25b4  lea rdi, [rsp]
00007cc2f47e25b8  mov esi, 0x00
00007cc2f47e25bd  mov rax, 0x5990E710A530
00007cc2f47e25c7  call rax
00007cc2f47e25c9  movaps xmm5, [rsp]
00007cc2f47e25cd  add rsp, 0x30
00007cc2f47e25d1  vmovaps xmm0, [rsp]
00007cc2f47e25d6  vmovaps xmm1, [rsp+0x10]
00007cc2f47e25dc  vmovaps xmm2, [rsp+0x20]
00007cc2f47e25e2  vmovaps xmm3, [rsp+0x30]
00007cc2f47e25e8  vmovaps xmm4, [rsp+0x40]
00007cc2f47e25ee  vmovaps xmm6, [rsp+0x50]
00007cc2f47e25f4  vmovaps xmm7, [rsp+0x60]
00007cc2f47e25fa  vmovaps xmm8, [rsp+0x70]
00007cc2f47e2600  vmovaps xmm9, [rsp+0x80]
00007cc2f47e2609  vmovaps xmm10, [rsp+0x90]
00007cc2f47e2612  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e261b  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e2624  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e262d  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e2636  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e263f  add rsp, 0xF0
00007cc2f47e2646  pop r11
00007cc2f47e2648  pop r10
00007cc2f47e264a  pop r9
00007cc2f47e264c  pop r8
00007cc2f47e264e  pop rsi
00007cc2f47e264f  pop rdi
00007cc2f47e2650  pop rdx
00007cc2f47e2651  pop rcx
00007cc2f47e2652  pop rax
00007cc2f47e2653  add rsp, 0x08
00007cc2f47e2657  jmp 0x00007CC2F47DF593
00007cc2f47e265c  sub rsp, 0x08
00007cc2f47e2660  push rax
00007cc2f47e2661  push rcx
00007cc2f47e2662  push rdx
00007cc2f47e2663  push rdi
00007cc2f47e2664  push rsi
00007cc2f47e2665  push r8
00007cc2f47e2667  push r9
00007cc2f47e2669  push r10
00007cc2f47e266b  push r11
00007cc2f47e266d  sub rsp, 0xF0
00007cc2f47e2674  vmovaps [rsp], xmm0
00007cc2f47e2679  vmovaps [rsp+0x10], xmm1
00007cc2f47e267f  vmovaps [rsp+0x20], xmm2
00007cc2f47e2685  vmovaps [rsp+0x30], xmm3
00007cc2f47e268b  vmovaps [rsp+0x40], xmm4
00007cc2f47e2691  vmovaps [rsp+0x50], xmm5
00007cc2f47e2697  vmovaps [rsp+0x60], xmm7
00007cc2f47e269d  vmovaps [rsp+0x70], xmm8
00007cc2f47e26a3  vmovaps [rsp+0x80], xmm9
00007cc2f47e26ac  vmovaps [rsp+0x90], xmm10
00007cc2f47e26b5  vmovaps [rsp+0xA0], xmm11
00007cc2f47e26be  vmovaps [rsp+0xB0], xmm12
00007cc2f47e26c7  vmovaps [rsp+0xC0], xmm13
00007cc2f47e26d0  vmovaps [rsp+0xD0], xmm14
00007cc2f47e26d9  vmovaps [rsp+0xE0], xmm15
00007cc2f47e26e2  sub rsp, 0x30
00007cc2f47e26e6  movaps [rsp], xmm6
00007cc2f47e26ea  movaps [rsp+0x10], xmm10
00007cc2f47e26f0  movaps [rsp+0x20], xmm8
00007cc2f47e26f6  lea rdi, [rsp]
00007cc2f47e26fa  mov esi, 0x00
00007cc2f47e26ff  mov rax, 0x5990E710A530
00007cc2f47e2709  call rax
00007cc2f47e270b  movaps xmm6, [rsp]
00007cc2f47e270f  add rsp, 0x30
00007cc2f47e2713  vmovaps xmm0, [rsp]
00007cc2f47e2718  vmovaps xmm1, [rsp+0x10]
00007cc2f47e271e  vmovaps xmm2, [rsp+0x20]
00007cc2f47e2724  vmovaps xmm3, [rsp+0x30]
00007cc2f47e272a  vmovaps xmm4, [rsp+0x40]
00007cc2f47e2730  vmovaps xmm5, [rsp+0x50]
00007cc2f47e2736  vmovaps xmm7, [rsp+0x60]
00007cc2f47e273c  vmovaps xmm8, [rsp+0x70]
00007cc2f47e2742  vmovaps xmm9, [rsp+0x80]
00007cc2f47e274b  vmovaps xmm10, [rsp+0x90]
00007cc2f47e2754  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e275d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e2766  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e276f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e2778  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e2781  add rsp, 0xF0
00007cc2f47e2788  pop r11
00007cc2f47e278a  pop r10
00007cc2f47e278c  pop r9
00007cc2f47e278e  pop r8
00007cc2f47e2790  pop rsi
00007cc2f47e2791  pop rdi
00007cc2f47e2792  pop rdx
00007cc2f47e2793  pop rcx
00007cc2f47e2794  pop rax
00007cc2f47e2795  add rsp, 0x08
00007cc2f47e2799  jmp 0x00007CC2F47DF5B8
00007cc2f47e279e  sub rsp, 0x08
00007cc2f47e27a2  push rax
00007cc2f47e27a3  push rcx
00007cc2f47e27a4  push rdx
00007cc2f47e27a5  push rdi
00007cc2f47e27a6  push rsi
00007cc2f47e27a7  push r8
00007cc2f47e27a9  push r9
00007cc2f47e27ab  push r10
00007cc2f47e27ad  push r11
00007cc2f47e27af  sub rsp, 0xF0
00007cc2f47e27b6  vmovaps [rsp], xmm0
00007cc2f47e27bb  vmovaps [rsp+0x10], xmm1
00007cc2f47e27c1  vmovaps [rsp+0x20], xmm2
00007cc2f47e27c7  vmovaps [rsp+0x30], xmm3
00007cc2f47e27cd  vmovaps [rsp+0x40], xmm4
00007cc2f47e27d3  vmovaps [rsp+0x50], xmm5
00007cc2f47e27d9  vmovaps [rsp+0x60], xmm6
00007cc2f47e27df  vmovaps [rsp+0x70], xmm7
00007cc2f47e27e5  vmovaps [rsp+0x80], xmm8
00007cc2f47e27ee  vmovaps [rsp+0x90], xmm9
00007cc2f47e27f7  vmovaps [rsp+0xA0], xmm11
00007cc2f47e2800  vmovaps [rsp+0xB0], xmm12
00007cc2f47e2809  vmovaps [rsp+0xC0], xmm13
00007cc2f47e2812  vmovaps [rsp+0xD0], xmm14
00007cc2f47e281b  vmovaps [rsp+0xE0], xmm15
00007cc2f47e2824  sub rsp, 0x30
00007cc2f47e2828  movaps [rsp], xmm10
00007cc2f47e282d  movaps [rsp+0x10], xmm8
00007cc2f47e2833  movaps [rsp+0x20], xmm14
00007cc2f47e2839  lea rdi, [rsp]
00007cc2f47e283d  mov esi, 0x00
00007cc2f47e2842  mov rax, 0x5990E710A530
00007cc2f47e284c  call rax
00007cc2f47e284e  movaps xmm10, [rsp]
00007cc2f47e2853  add rsp, 0x30
00007cc2f47e2857  vmovaps xmm0, [rsp]
00007cc2f47e285c  vmovaps xmm1, [rsp+0x10]
00007cc2f47e2862  vmovaps xmm2, [rsp+0x20]
00007cc2f47e2868  vmovaps xmm3, [rsp+0x30]
00007cc2f47e286e  vmovaps xmm4, [rsp+0x40]
00007cc2f47e2874  vmovaps xmm5, [rsp+0x50]
00007cc2f47e287a  vmovaps xmm6, [rsp+0x60]
00007cc2f47e2880  vmovaps xmm7, [rsp+0x70]
00007cc2f47e2886  vmovaps xmm8, [rsp+0x80]
00007cc2f47e288f  vmovaps xmm9, [rsp+0x90]
00007cc2f47e2898  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e28a1  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e28aa  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e28b3  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e28bc  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e28c5  add rsp, 0xF0
00007cc2f47e28cc  pop r11
00007cc2f47e28ce  pop r10
00007cc2f47e28d0  pop r9
00007cc2f47e28d2  pop r8
00007cc2f47e28d4  pop rsi
00007cc2f47e28d5  pop rdi
00007cc2f47e28d6  pop rdx
00007cc2f47e28d7  pop rcx
00007cc2f47e28d8  pop rax
00007cc2f47e28d9  add rsp, 0x08
00007cc2f47e28dd  jmp 0x00007CC2F47DF5D8
00007cc2f47e28e2  sub rsp, 0x08
00007cc2f47e28e6  push rax
00007cc2f47e28e7  push rcx
00007cc2f47e28e8  push rdx
00007cc2f47e28e9  push rdi
00007cc2f47e28ea  push rsi
00007cc2f47e28eb  push r8
00007cc2f47e28ed  push r9
00007cc2f47e28ef  push r10
00007cc2f47e28f1  push r11
00007cc2f47e28f3  sub rsp, 0xF0
00007cc2f47e28fa  vmovaps [rsp], xmm0
00007cc2f47e28ff  vmovaps [rsp+0x10], xmm1
00007cc2f47e2905  vmovaps [rsp+0x20], xmm2
00007cc2f47e290b  vmovaps [rsp+0x30], xmm3
00007cc2f47e2911  vmovaps [rsp+0x40], xmm4
00007cc2f47e2917  vmovaps [rsp+0x50], xmm5
00007cc2f47e291d  vmovaps [rsp+0x60], xmm6
00007cc2f47e2923  vmovaps [rsp+0x70], xmm7
00007cc2f47e2929  vmovaps [rsp+0x80], xmm8
00007cc2f47e2932  vmovaps [rsp+0x90], xmm9
00007cc2f47e293b  vmovaps [rsp+0xA0], xmm10
00007cc2f47e2944  vmovaps [rsp+0xB0], xmm11
00007cc2f47e294d  vmovaps [rsp+0xC0], xmm12
00007cc2f47e2956  vmovaps [rsp+0xD0], xmm13
00007cc2f47e295f  vmovaps [rsp+0xE0], xmm15
00007cc2f47e2968  sub rsp, 0x30
00007cc2f47e296c  movaps [rsp], xmm14
00007cc2f47e2971  movaps [rsp+0x10], xmm8
00007cc2f47e2977  movaps [rsp+0x20], xmm4
00007cc2f47e297c  lea rdi, [rsp]
00007cc2f47e2980  mov esi, 0x00
00007cc2f47e2985  mov rax, 0x5990E710A530
00007cc2f47e298f  call rax
00007cc2f47e2991  movaps xmm14, [rsp]
00007cc2f47e2996  add rsp, 0x30
00007cc2f47e299a  vmovaps xmm0, [rsp]
00007cc2f47e299f  vmovaps xmm1, [rsp+0x10]
00007cc2f47e29a5  vmovaps xmm2, [rsp+0x20]
00007cc2f47e29ab  vmovaps xmm3, [rsp+0x30]
00007cc2f47e29b1  vmovaps xmm4, [rsp+0x40]
00007cc2f47e29b7  vmovaps xmm5, [rsp+0x50]
00007cc2f47e29bd  vmovaps xmm6, [rsp+0x60]
00007cc2f47e29c3  vmovaps xmm7, [rsp+0x70]
00007cc2f47e29c9  vmovaps xmm8, [rsp+0x80]
00007cc2f47e29d2  vmovaps xmm9, [rsp+0x90]
00007cc2f47e29db  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e29e4  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e29ed  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e29f6  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e29ff  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e2a08  add rsp, 0xF0
00007cc2f47e2a0f  pop r11
00007cc2f47e2a11  pop r10
00007cc2f47e2a13  pop r9
00007cc2f47e2a15  pop r8
00007cc2f47e2a17  pop rsi
00007cc2f47e2a18  pop rdi
00007cc2f47e2a19  pop rdx
00007cc2f47e2a1a  pop rcx
00007cc2f47e2a1b  pop rax
00007cc2f47e2a1c  add rsp, 0x08
00007cc2f47e2a20  jmp 0x00007CC2F47DF5F8
00007cc2f47e2a25  sub rsp, 0x08
00007cc2f47e2a29  push rax
00007cc2f47e2a2a  push rcx
00007cc2f47e2a2b  push rdx
00007cc2f47e2a2c  push rdi
00007cc2f47e2a2d  push rsi
00007cc2f47e2a2e  push r8
00007cc2f47e2a30  push r9
00007cc2f47e2a32  push r10
00007cc2f47e2a34  push r11
00007cc2f47e2a36  sub rsp, 0xF0
00007cc2f47e2a3d  vmovaps [rsp], xmm0
00007cc2f47e2a42  vmovaps [rsp+0x10], xmm1
00007cc2f47e2a48  vmovaps [rsp+0x20], xmm2
00007cc2f47e2a4e  vmovaps [rsp+0x30], xmm3
00007cc2f47e2a54  vmovaps [rsp+0x40], xmm5
00007cc2f47e2a5a  vmovaps [rsp+0x50], xmm6
00007cc2f47e2a60  vmovaps [rsp+0x60], xmm7
00007cc2f47e2a66  vmovaps [rsp+0x70], xmm8
00007cc2f47e2a6c  vmovaps [rsp+0x80], xmm9
00007cc2f47e2a75  vmovaps [rsp+0x90], xmm10
00007cc2f47e2a7e  vmovaps [rsp+0xA0], xmm11
00007cc2f47e2a87  vmovaps [rsp+0xB0], xmm12
00007cc2f47e2a90  vmovaps [rsp+0xC0], xmm13
00007cc2f47e2a99  vmovaps [rsp+0xD0], xmm14
00007cc2f47e2aa2  vmovaps [rsp+0xE0], xmm15
00007cc2f47e2aab  sub rsp, 0x30
00007cc2f47e2aaf  movaps [rsp], xmm4
00007cc2f47e2ab3  movaps [rsp+0x10], xmm13
00007cc2f47e2ab9  movaps [rsp+0x20], xmm8
00007cc2f47e2abf  lea rdi, [rsp]
00007cc2f47e2ac3  mov esi, 0x00
00007cc2f47e2ac8  mov rax, 0x5990E710A530
00007cc2f47e2ad2  call rax
00007cc2f47e2ad4  movaps xmm4, [rsp]
00007cc2f47e2ad8  add rsp, 0x30
00007cc2f47e2adc  vmovaps xmm0, [rsp]
00007cc2f47e2ae1  vmovaps xmm1, [rsp+0x10]
00007cc2f47e2ae7  vmovaps xmm2, [rsp+0x20]
00007cc2f47e2aed  vmovaps xmm3, [rsp+0x30]
00007cc2f47e2af3  vmovaps xmm5, [rsp+0x40]
00007cc2f47e2af9  vmovaps xmm6, [rsp+0x50]
00007cc2f47e2aff  vmovaps xmm7, [rsp+0x60]
00007cc2f47e2b05  vmovaps xmm8, [rsp+0x70]
00007cc2f47e2b0b  vmovaps xmm9, [rsp+0x80]
00007cc2f47e2b14  vmovaps xmm10, [rsp+0x90]
00007cc2f47e2b1d  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e2b26  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e2b2f  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e2b38  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e2b41  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e2b4a  add rsp, 0xF0
00007cc2f47e2b51  pop r11
00007cc2f47e2b53  pop r10
00007cc2f47e2b55  pop r9
00007cc2f47e2b57  pop r8
00007cc2f47e2b59  pop rsi
00007cc2f47e2b5a  pop rdi
00007cc2f47e2b5b  pop rdx
00007cc2f47e2b5c  pop rcx
00007cc2f47e2b5d  pop rax
00007cc2f47e2b5e  add rsp, 0x08
00007cc2f47e2b62  jmp 0x00007CC2F47DF61D
00007cc2f47e2b67  sub rsp, 0x08
00007cc2f47e2b6b  push rax
00007cc2f47e2b6c  push rcx
00007cc2f47e2b6d  push rdx
00007cc2f47e2b6e  push rdi
00007cc2f47e2b6f  push rsi
00007cc2f47e2b70  push r8
00007cc2f47e2b72  push r9
00007cc2f47e2b74  push r10
00007cc2f47e2b76  push r11
00007cc2f47e2b78  sub rsp, 0xF0
00007cc2f47e2b7f  vmovaps [rsp], xmm0
00007cc2f47e2b84  vmovaps [rsp+0x10], xmm1
00007cc2f47e2b8a  vmovaps [rsp+0x20], xmm2
00007cc2f47e2b90  vmovaps [rsp+0x30], xmm3
00007cc2f47e2b96  vmovaps [rsp+0x40], xmm4
00007cc2f47e2b9c  vmovaps [rsp+0x50], xmm5
00007cc2f47e2ba2  vmovaps [rsp+0x60], xmm6
00007cc2f47e2ba8  vmovaps [rsp+0x70], xmm7
00007cc2f47e2bae  vmovaps [rsp+0x80], xmm8
00007cc2f47e2bb7  vmovaps [rsp+0x90], xmm9
00007cc2f47e2bc0  vmovaps [rsp+0xA0], xmm10
00007cc2f47e2bc9  vmovaps [rsp+0xB0], xmm11
00007cc2f47e2bd2  vmovaps [rsp+0xC0], xmm12
00007cc2f47e2bdb  vmovaps [rsp+0xD0], xmm14
00007cc2f47e2be4  vmovaps [rsp+0xE0], xmm15
00007cc2f47e2bed  sub rsp, 0x30
00007cc2f47e2bf1  movaps [rsp], xmm13
00007cc2f47e2bf6  movaps [rsp+0x10], xmm15
00007cc2f47e2bfc  movaps [rsp+0x20], xmm9
00007cc2f47e2c02  lea rdi, [rsp]
00007cc2f47e2c06  mov esi, 0x00
00007cc2f47e2c0b  mov rax, 0x5990E710A530
00007cc2f47e2c15  call rax
00007cc2f47e2c17  movaps xmm13, [rsp]
00007cc2f47e2c1c  add rsp, 0x30
00007cc2f47e2c20  vmovaps xmm0, [rsp]
00007cc2f47e2c25  vmovaps xmm1, [rsp+0x10]
00007cc2f47e2c2b  vmovaps xmm2, [rsp+0x20]
00007cc2f47e2c31  vmovaps xmm3, [rsp+0x30]
00007cc2f47e2c37  vmovaps xmm4, [rsp+0x40]
00007cc2f47e2c3d  vmovaps xmm5, [rsp+0x50]
00007cc2f47e2c43  vmovaps xmm6, [rsp+0x60]
00007cc2f47e2c49  vmovaps xmm7, [rsp+0x70]
00007cc2f47e2c4f  vmovaps xmm8, [rsp+0x80]
00007cc2f47e2c58  vmovaps xmm9, [rsp+0x90]
00007cc2f47e2c61  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e2c6a  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e2c73  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e2c7c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e2c85  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e2c8e  add rsp, 0xF0
00007cc2f47e2c95  pop r11
00007cc2f47e2c97  pop r10
00007cc2f47e2c99  pop r9
00007cc2f47e2c9b  pop r8
00007cc2f47e2c9d  pop rsi
00007cc2f47e2c9e  pop rdi
00007cc2f47e2c9f  pop rdx
00007cc2f47e2ca0  pop rcx
00007cc2f47e2ca1  pop rax
00007cc2f47e2ca2  add rsp, 0x08
00007cc2f47e2ca6  jmp 0x00007CC2F47DF638
00007cc2f47e2cab  sub rsp, 0x08
00007cc2f47e2caf  push rax
00007cc2f47e2cb0  push rcx
00007cc2f47e2cb1  push rdx
00007cc2f47e2cb2  push rdi
00007cc2f47e2cb3  push rsi
00007cc2f47e2cb4  push r8
00007cc2f47e2cb6  push r9
00007cc2f47e2cb8  push r10
00007cc2f47e2cba  push r11
00007cc2f47e2cbc  sub rsp, 0xF0
00007cc2f47e2cc3  vmovaps [rsp], xmm0
00007cc2f47e2cc8  vmovaps [rsp+0x10], xmm1
00007cc2f47e2cce  vmovaps [rsp+0x20], xmm2
00007cc2f47e2cd4  vmovaps [rsp+0x30], xmm3
00007cc2f47e2cda  vmovaps [rsp+0x40], xmm4
00007cc2f47e2ce0  vmovaps [rsp+0x50], xmm5
00007cc2f47e2ce6  vmovaps [rsp+0x60], xmm6
00007cc2f47e2cec  vmovaps [rsp+0x70], xmm7
00007cc2f47e2cf2  vmovaps [rsp+0x80], xmm8
00007cc2f47e2cfb  vmovaps [rsp+0x90], xmm9
00007cc2f47e2d04  vmovaps [rsp+0xA0], xmm10
00007cc2f47e2d0d  vmovaps [rsp+0xB0], xmm11
00007cc2f47e2d16  vmovaps [rsp+0xC0], xmm12
00007cc2f47e2d1f  vmovaps [rsp+0xD0], xmm13
00007cc2f47e2d28  vmovaps [rsp+0xE0], xmm14
00007cc2f47e2d31  sub rsp, 0x30
00007cc2f47e2d35  movaps [rsp], xmm15
00007cc2f47e2d3a  movaps [rsp+0x10], xmm1
00007cc2f47e2d3f  movaps [rsp+0x20], xmm5
00007cc2f47e2d44  lea rdi, [rsp]
00007cc2f47e2d48  mov esi, 0x00
00007cc2f47e2d4d  mov rax, 0x5990E710A530
00007cc2f47e2d57  call rax
00007cc2f47e2d59  movaps xmm15, [rsp]
00007cc2f47e2d5e  add rsp, 0x30
00007cc2f47e2d62  vmovaps xmm0, [rsp]
00007cc2f47e2d67  vmovaps xmm1, [rsp+0x10]
00007cc2f47e2d6d  vmovaps xmm2, [rsp+0x20]
00007cc2f47e2d73  vmovaps xmm3, [rsp+0x30]
00007cc2f47e2d79  vmovaps xmm4, [rsp+0x40]
00007cc2f47e2d7f  vmovaps xmm5, [rsp+0x50]
00007cc2f47e2d85  vmovaps xmm6, [rsp+0x60]
00007cc2f47e2d8b  vmovaps xmm7, [rsp+0x70]
00007cc2f47e2d91  vmovaps xmm8, [rsp+0x80]
00007cc2f47e2d9a  vmovaps xmm9, [rsp+0x90]
00007cc2f47e2da3  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e2dac  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e2db5  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e2dbe  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e2dc7  vmovaps xmm14, [rsp+0xE0]
00007cc2f47e2dd0  add rsp, 0xF0
00007cc2f47e2dd7  pop r11
00007cc2f47e2dd9  pop r10
00007cc2f47e2ddb  pop r9
00007cc2f47e2ddd  pop r8
00007cc2f47e2ddf  pop rsi
00007cc2f47e2de0  pop rdi
00007cc2f47e2de1  pop rdx
00007cc2f47e2de2  pop rcx
00007cc2f47e2de3  pop rax
00007cc2f47e2de4  add rsp, 0x08
00007cc2f47e2de8  jmp 0x00007CC2F47DF653
00007cc2f47e2ded  call 0x00007CC2F46B52F0
00007cc2f47e2df2  jmp 0x00007CC2F47DF6AE
00007cc2f47e2df7  sub rsp, 0x08
00007cc2f47e2dfb  push rax
00007cc2f47e2dfc  push rcx
00007cc2f47e2dfd  push rdx
00007cc2f47e2dfe  push rdi
00007cc2f47e2dff  push rsi
00007cc2f47e2e00  push r8
00007cc2f47e2e02  push r9
00007cc2f47e2e04  push r10
00007cc2f47e2e06  push r11
00007cc2f47e2e08  sub rsp, 0xF0
00007cc2f47e2e0f  vmovaps [rsp], xmm0
00007cc2f47e2e14  vmovaps [rsp+0x10], xmm1
00007cc2f47e2e1a  vmovaps [rsp+0x20], xmm2
00007cc2f47e2e20  vmovaps [rsp+0x30], xmm3
00007cc2f47e2e26  vmovaps [rsp+0x40], xmm4
00007cc2f47e2e2c  vmovaps [rsp+0x50], xmm5
00007cc2f47e2e32  vmovaps [rsp+0x60], xmm6
00007cc2f47e2e38  vmovaps [rsp+0x70], xmm7
00007cc2f47e2e3e  vmovaps [rsp+0x80], xmm8
00007cc2f47e2e47  vmovaps [rsp+0x90], xmm10
00007cc2f47e2e50  vmovaps [rsp+0xA0], xmm11
00007cc2f47e2e59  vmovaps [rsp+0xB0], xmm12
00007cc2f47e2e62  vmovaps [rsp+0xC0], xmm13
00007cc2f47e2e6b  vmovaps [rsp+0xD0], xmm14
00007cc2f47e2e74  vmovaps [rsp+0xE0], xmm15
00007cc2f47e2e7d  sub rsp, 0x30
00007cc2f47e2e81  movaps [rsp], xmm9
00007cc2f47e2e86  movaps [rsp+0x10], xmm8
00007cc2f47e2e8c  movaps [rsp+0x20], xmm11
00007cc2f47e2e92  lea rdi, [rsp]
00007cc2f47e2e96  mov esi, 0x00
00007cc2f47e2e9b  mov rax, 0x5990E710A530
00007cc2f47e2ea5  call rax
00007cc2f47e2ea7  movaps xmm9, [rsp]
00007cc2f47e2eac  add rsp, 0x30
00007cc2f47e2eb0  vmovaps xmm0, [rsp]
00007cc2f47e2eb5  vmovaps xmm1, [rsp+0x10]
00007cc2f47e2ebb  vmovaps xmm2, [rsp+0x20]
00007cc2f47e2ec1  vmovaps xmm3, [rsp+0x30]
00007cc2f47e2ec7  vmovaps xmm4, [rsp+0x40]
00007cc2f47e2ecd  vmovaps xmm5, [rsp+0x50]
00007cc2f47e2ed3  vmovaps xmm6, [rsp+0x60]
00007cc2f47e2ed9  vmovaps xmm7, [rsp+0x70]
00007cc2f47e2edf  vmovaps xmm8, [rsp+0x80]
00007cc2f47e2ee8  vmovaps xmm10, [rsp+0x90]
00007cc2f47e2ef1  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e2efa  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e2f03  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e2f0c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e2f15  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e2f1e  add rsp, 0xF0
00007cc2f47e2f25  pop r11
00007cc2f47e2f27  pop r10
00007cc2f47e2f29  pop r9
00007cc2f47e2f2b  pop r8
00007cc2f47e2f2d  pop rsi
00007cc2f47e2f2e  pop rdi
00007cc2f47e2f2f  pop rdx
00007cc2f47e2f30  pop rcx
00007cc2f47e2f31  pop rax
00007cc2f47e2f32  add rsp, 0x08
00007cc2f47e2f36  jmp 0x00007CC2F47DF6E5
00007cc2f47e2f3b  sub rsp, 0x08
00007cc2f47e2f3f  push rax
00007cc2f47e2f40  push rcx
00007cc2f47e2f41  push rdx
00007cc2f47e2f42  push rdi
00007cc2f47e2f43  push rsi
00007cc2f47e2f44  push r8
00007cc2f47e2f46  push r9
00007cc2f47e2f48  push r10
00007cc2f47e2f4a  push r11
00007cc2f47e2f4c  sub rsp, 0xF0
00007cc2f47e2f53  vmovaps [rsp], xmm0
00007cc2f47e2f58  vmovaps [rsp+0x10], xmm1
00007cc2f47e2f5e  vmovaps [rsp+0x20], xmm2
00007cc2f47e2f64  vmovaps [rsp+0x30], xmm3
00007cc2f47e2f6a  vmovaps [rsp+0x40], xmm4
00007cc2f47e2f70  vmovaps [rsp+0x50], xmm5
00007cc2f47e2f76  vmovaps [rsp+0x60], xmm6
00007cc2f47e2f7c  vmovaps [rsp+0x70], xmm7
00007cc2f47e2f82  vmovaps [rsp+0x80], xmm8
00007cc2f47e2f8b  vmovaps [rsp+0x90], xmm9
00007cc2f47e2f94  vmovaps [rsp+0xA0], xmm10
00007cc2f47e2f9d  vmovaps [rsp+0xB0], xmm12
00007cc2f47e2fa6  vmovaps [rsp+0xC0], xmm13
00007cc2f47e2faf  vmovaps [rsp+0xD0], xmm14
00007cc2f47e2fb8  vmovaps [rsp+0xE0], xmm15
00007cc2f47e2fc1  sub rsp, 0x30
00007cc2f47e2fc5  movaps [rsp], xmm11
00007cc2f47e2fca  movaps [rsp+0x10], xmm10
00007cc2f47e2fd0  movaps [rsp+0x20], xmm6
00007cc2f47e2fd5  lea rdi, [rsp]
00007cc2f47e2fd9  mov esi, 0x00
00007cc2f47e2fde  mov rax, 0x5990E710A530
00007cc2f47e2fe8  call rax
00007cc2f47e2fea  movaps xmm11, [rsp]
00007cc2f47e2fef  add rsp, 0x30
00007cc2f47e2ff3  vmovaps xmm0, [rsp]
00007cc2f47e2ff8  vmovaps xmm1, [rsp+0x10]
00007cc2f47e2ffe  vmovaps xmm2, [rsp+0x20]
00007cc2f47e3004  vmovaps xmm3, [rsp+0x30]
00007cc2f47e300a  vmovaps xmm4, [rsp+0x40]
00007cc2f47e3010  vmovaps xmm5, [rsp+0x50]
00007cc2f47e3016  vmovaps xmm6, [rsp+0x60]
00007cc2f47e301c  vmovaps xmm7, [rsp+0x70]
00007cc2f47e3022  vmovaps xmm8, [rsp+0x80]
00007cc2f47e302b  vmovaps xmm9, [rsp+0x90]
00007cc2f47e3034  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e303d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e3046  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e304f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e3058  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e3061  add rsp, 0xF0
00007cc2f47e3068  pop r11
00007cc2f47e306a  pop r10
00007cc2f47e306c  pop r9
00007cc2f47e306e  pop r8
00007cc2f47e3070  pop rsi
00007cc2f47e3071  pop rdi
00007cc2f47e3072  pop rdx
00007cc2f47e3073  pop rcx
00007cc2f47e3074  pop rax
00007cc2f47e3075  add rsp, 0x08
00007cc2f47e3079  jmp 0x00007CC2F47DF700
00007cc2f47e307e  sub rsp, 0x08
00007cc2f47e3082  push rax
00007cc2f47e3083  push rcx
00007cc2f47e3084  push rdx
00007cc2f47e3085  push rdi
00007cc2f47e3086  push rsi
00007cc2f47e3087  push r8
00007cc2f47e3089  push r9
00007cc2f47e308b  push r10
00007cc2f47e308d  push r11
00007cc2f47e308f  sub rsp, 0xF0
00007cc2f47e3096  vmovaps [rsp], xmm0
00007cc2f47e309b  vmovaps [rsp+0x10], xmm1
00007cc2f47e30a1  vmovaps [rsp+0x20], xmm2
00007cc2f47e30a7  vmovaps [rsp+0x30], xmm3
00007cc2f47e30ad  vmovaps [rsp+0x40], xmm4
00007cc2f47e30b3  vmovaps [rsp+0x50], xmm5
00007cc2f47e30b9  vmovaps [rsp+0x60], xmm6
00007cc2f47e30bf  vmovaps [rsp+0x70], xmm7
00007cc2f47e30c5  vmovaps [rsp+0x80], xmm8
00007cc2f47e30ce  vmovaps [rsp+0x90], xmm9
00007cc2f47e30d7  vmovaps [rsp+0xA0], xmm11
00007cc2f47e30e0  vmovaps [rsp+0xB0], xmm12
00007cc2f47e30e9  vmovaps [rsp+0xC0], xmm13
00007cc2f47e30f2  vmovaps [rsp+0xD0], xmm14
00007cc2f47e30fb  vmovaps [rsp+0xE0], xmm15
00007cc2f47e3104  sub rsp, 0x30
00007cc2f47e3108  movaps [rsp], xmm10
00007cc2f47e310d  movaps [rsp+0x10], xmm14
00007cc2f47e3113  movaps [rsp+0x20], xmm4
00007cc2f47e3118  lea rdi, [rsp]
00007cc2f47e311c  mov esi, 0x00
00007cc2f47e3121  mov rax, 0x5990E710A530
00007cc2f47e312b  call rax
00007cc2f47e312d  movaps xmm10, [rsp]
00007cc2f47e3132  add rsp, 0x30
00007cc2f47e3136  vmovaps xmm0, [rsp]
00007cc2f47e313b  vmovaps xmm1, [rsp+0x10]
00007cc2f47e3141  vmovaps xmm2, [rsp+0x20]
00007cc2f47e3147  vmovaps xmm3, [rsp+0x30]
00007cc2f47e314d  vmovaps xmm4, [rsp+0x40]
00007cc2f47e3153  vmovaps xmm5, [rsp+0x50]
00007cc2f47e3159  vmovaps xmm6, [rsp+0x60]
00007cc2f47e315f  vmovaps xmm7, [rsp+0x70]
00007cc2f47e3165  vmovaps xmm8, [rsp+0x80]
00007cc2f47e316e  vmovaps xmm9, [rsp+0x90]
00007cc2f47e3177  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e3180  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e3189  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e3192  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e319b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e31a4  add rsp, 0xF0
00007cc2f47e31ab  pop r11
00007cc2f47e31ad  pop r10
00007cc2f47e31af  pop r9
00007cc2f47e31b1  pop r8
00007cc2f47e31b3  pop rsi
00007cc2f47e31b4  pop rdi
00007cc2f47e31b5  pop rdx
00007cc2f47e31b6  pop rcx
00007cc2f47e31b7  pop rax
00007cc2f47e31b8  add rsp, 0x08
00007cc2f47e31bc  jmp 0x00007CC2F47DF71B
00007cc2f47e31c1  sub rsp, 0x08
00007cc2f47e31c5  push rax
00007cc2f47e31c6  push rcx
00007cc2f47e31c7  push rdx
00007cc2f47e31c8  push rdi
00007cc2f47e31c9  push rsi
00007cc2f47e31ca  push r8
00007cc2f47e31cc  push r9
00007cc2f47e31ce  push r10
00007cc2f47e31d0  push r11
00007cc2f47e31d2  sub rsp, 0xF0
00007cc2f47e31d9  vmovaps [rsp], xmm0
00007cc2f47e31de  vmovaps [rsp+0x10], xmm1
00007cc2f47e31e4  vmovaps [rsp+0x20], xmm2
00007cc2f47e31ea  vmovaps [rsp+0x30], xmm3
00007cc2f47e31f0  vmovaps [rsp+0x40], xmm4
00007cc2f47e31f6  vmovaps [rsp+0x50], xmm5
00007cc2f47e31fc  vmovaps [rsp+0x60], xmm6
00007cc2f47e3202  vmovaps [rsp+0x70], xmm7
00007cc2f47e3208  vmovaps [rsp+0x80], xmm9
00007cc2f47e3211  vmovaps [rsp+0x90], xmm10
00007cc2f47e321a  vmovaps [rsp+0xA0], xmm11
00007cc2f47e3223  vmovaps [rsp+0xB0], xmm12
00007cc2f47e322c  vmovaps [rsp+0xC0], xmm13
00007cc2f47e3235  vmovaps [rsp+0xD0], xmm14
00007cc2f47e323e  vmovaps [rsp+0xE0], xmm15
00007cc2f47e3247  sub rsp, 0x30
00007cc2f47e324b  movaps [rsp], xmm8
00007cc2f47e3250  movaps [rsp+0x10], xmm1
00007cc2f47e3255  movaps [rsp+0x20], xmm14
00007cc2f47e325b  lea rdi, [rsp]
00007cc2f47e325f  mov esi, 0x00
00007cc2f47e3264  mov rax, 0x5990E710A530
00007cc2f47e326e  call rax
00007cc2f47e3270  movaps xmm8, [rsp]
00007cc2f47e3275  add rsp, 0x30
00007cc2f47e3279  vmovaps xmm0, [rsp]
00007cc2f47e327e  vmovaps xmm1, [rsp+0x10]
00007cc2f47e3284  vmovaps xmm2, [rsp+0x20]
00007cc2f47e328a  vmovaps xmm3, [rsp+0x30]
00007cc2f47e3290  vmovaps xmm4, [rsp+0x40]
00007cc2f47e3296  vmovaps xmm5, [rsp+0x50]
00007cc2f47e329c  vmovaps xmm6, [rsp+0x60]
00007cc2f47e32a2  vmovaps xmm7, [rsp+0x70]
00007cc2f47e32a8  vmovaps xmm9, [rsp+0x80]
00007cc2f47e32b1  vmovaps xmm10, [rsp+0x90]
00007cc2f47e32ba  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e32c3  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e32cc  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e32d5  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e32de  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e32e7  add rsp, 0xF0
00007cc2f47e32ee  pop r11
00007cc2f47e32f0  pop r10
00007cc2f47e32f2  pop r9
00007cc2f47e32f4  pop r8
00007cc2f47e32f6  pop rsi
00007cc2f47e32f7  pop rdi
00007cc2f47e32f8  pop rdx
00007cc2f47e32f9  pop rcx
00007cc2f47e32fa  pop rax
00007cc2f47e32fb  add rsp, 0x08
00007cc2f47e32ff  jmp 0x00007CC2F47DF741
00007cc2f47e3304  sub rsp, 0x08
00007cc2f47e3308  push rax
00007cc2f47e3309  push rcx
00007cc2f47e330a  push rdx
00007cc2f47e330b  push rdi
00007cc2f47e330c  push rsi
00007cc2f47e330d  push r8
00007cc2f47e330f  push r9
00007cc2f47e3311  push r10
00007cc2f47e3313  push r11
00007cc2f47e3315  sub rsp, 0xF0
00007cc2f47e331c  vmovaps [rsp], xmm0
00007cc2f47e3321  vmovaps [rsp+0x10], xmm1
00007cc2f47e3327  vmovaps [rsp+0x20], xmm2
00007cc2f47e332d  vmovaps [rsp+0x30], xmm3
00007cc2f47e3333  vmovaps [rsp+0x40], xmm4
00007cc2f47e3339  vmovaps [rsp+0x50], xmm5
00007cc2f47e333f  vmovaps [rsp+0x60], xmm7
00007cc2f47e3345  vmovaps [rsp+0x70], xmm8
00007cc2f47e334b  vmovaps [rsp+0x80], xmm9
00007cc2f47e3354  vmovaps [rsp+0x90], xmm10
00007cc2f47e335d  vmovaps [rsp+0xA0], xmm11
00007cc2f47e3366  vmovaps [rsp+0xB0], xmm12
00007cc2f47e336f  vmovaps [rsp+0xC0], xmm13
00007cc2f47e3378  vmovaps [rsp+0xD0], xmm14
00007cc2f47e3381  vmovaps [rsp+0xE0], xmm15
00007cc2f47e338a  sub rsp, 0x30
00007cc2f47e338e  movaps [rsp], xmm6
00007cc2f47e3392  movaps [rsp+0x10], xmm1
00007cc2f47e3397  movaps [rsp+0x20], xmm14
00007cc2f47e339d  lea rdi, [rsp]
00007cc2f47e33a1  mov esi, 0x00
00007cc2f47e33a6  mov rax, 0x5990E710A530
00007cc2f47e33b0  call rax
00007cc2f47e33b2  movaps xmm6, [rsp]
00007cc2f47e33b6  add rsp, 0x30
00007cc2f47e33ba  vmovaps xmm0, [rsp]
00007cc2f47e33bf  vmovaps xmm1, [rsp+0x10]
00007cc2f47e33c5  vmovaps xmm2, [rsp+0x20]
00007cc2f47e33cb  vmovaps xmm3, [rsp+0x30]
00007cc2f47e33d1  vmovaps xmm4, [rsp+0x40]
00007cc2f47e33d7  vmovaps xmm5, [rsp+0x50]
00007cc2f47e33dd  vmovaps xmm7, [rsp+0x60]
00007cc2f47e33e3  vmovaps xmm8, [rsp+0x70]
00007cc2f47e33e9  vmovaps xmm9, [rsp+0x80]
00007cc2f47e33f2  vmovaps xmm10, [rsp+0x90]
00007cc2f47e33fb  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e3404  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e340d  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e3416  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e341f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e3428  add rsp, 0xF0
00007cc2f47e342f  pop r11
00007cc2f47e3431  pop r10
00007cc2f47e3433  pop r9
00007cc2f47e3435  pop r8
00007cc2f47e3437  pop rsi
00007cc2f47e3438  pop rdi
00007cc2f47e3439  pop rdx
00007cc2f47e343a  pop rcx
00007cc2f47e343b  pop rax
00007cc2f47e343c  add rsp, 0x08
00007cc2f47e3440  jmp 0x00007CC2F47DF76D
00007cc2f47e3445  sub rsp, 0x08
00007cc2f47e3449  push rax
00007cc2f47e344a  push rcx
00007cc2f47e344b  push rdx
00007cc2f47e344c  push rdi
00007cc2f47e344d  push rsi
00007cc2f47e344e  push r8
00007cc2f47e3450  push r9
00007cc2f47e3452  push r10
00007cc2f47e3454  push r11
00007cc2f47e3456  sub rsp, 0xF0
00007cc2f47e345d  vmovaps [rsp], xmm0
00007cc2f47e3462  vmovaps [rsp+0x10], xmm1
00007cc2f47e3468  vmovaps [rsp+0x20], xmm2
00007cc2f47e346e  vmovaps [rsp+0x30], xmm3
00007cc2f47e3474  vmovaps [rsp+0x40], xmm4
00007cc2f47e347a  vmovaps [rsp+0x50], xmm5
00007cc2f47e3480  vmovaps [rsp+0x60], xmm6
00007cc2f47e3486  vmovaps [rsp+0x70], xmm7
00007cc2f47e348c  vmovaps [rsp+0x80], xmm8
00007cc2f47e3495  vmovaps [rsp+0x90], xmm9
00007cc2f47e349e  vmovaps [rsp+0xA0], xmm10
00007cc2f47e34a7  vmovaps [rsp+0xB0], xmm11
00007cc2f47e34b0  vmovaps [rsp+0xC0], xmm12
00007cc2f47e34b9  vmovaps [rsp+0xD0], xmm13
00007cc2f47e34c2  vmovaps [rsp+0xE0], xmm15
00007cc2f47e34cb  sub rsp, 0x30
00007cc2f47e34cf  movaps [rsp], xmm14
00007cc2f47e34d4  movaps [rsp+0x10], xmm12
00007cc2f47e34da  movaps [rsp+0x20], xmm1
00007cc2f47e34df  lea rdi, [rsp]
00007cc2f47e34e3  mov esi, 0x00
00007cc2f47e34e8  mov rax, 0x5990E710A530
00007cc2f47e34f2  call rax
00007cc2f47e34f4  movaps xmm14, [rsp]
00007cc2f47e34f9  add rsp, 0x30
00007cc2f47e34fd  vmovaps xmm0, [rsp]
00007cc2f47e3502  vmovaps xmm1, [rsp+0x10]
00007cc2f47e3508  vmovaps xmm2, [rsp+0x20]
00007cc2f47e350e  vmovaps xmm3, [rsp+0x30]
00007cc2f47e3514  vmovaps xmm4, [rsp+0x40]
00007cc2f47e351a  vmovaps xmm5, [rsp+0x50]
00007cc2f47e3520  vmovaps xmm6, [rsp+0x60]
00007cc2f47e3526  vmovaps xmm7, [rsp+0x70]
00007cc2f47e352c  vmovaps xmm8, [rsp+0x80]
00007cc2f47e3535  vmovaps xmm9, [rsp+0x90]
00007cc2f47e353e  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e3547  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e3550  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e3559  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e3562  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e356b  add rsp, 0xF0
00007cc2f47e3572  pop r11
00007cc2f47e3574  pop r10
00007cc2f47e3576  pop r9
00007cc2f47e3578  pop r8
00007cc2f47e357a  pop rsi
00007cc2f47e357b  pop rdi
00007cc2f47e357c  pop rdx
00007cc2f47e357d  pop rcx
00007cc2f47e357e  pop rax
00007cc2f47e357f  add rsp, 0x08
00007cc2f47e3583  jmp 0x00007CC2F47DF793
00007cc2f47e3588  sub rsp, 0x08
00007cc2f47e358c  push rax
00007cc2f47e358d  push rcx
00007cc2f47e358e  push rdx
00007cc2f47e358f  push rdi
00007cc2f47e3590  push rsi
00007cc2f47e3591  push r8
00007cc2f47e3593  push r9
00007cc2f47e3595  push r10
00007cc2f47e3597  push r11
00007cc2f47e3599  sub rsp, 0xF0
00007cc2f47e35a0  vmovaps [rsp], xmm0
00007cc2f47e35a5  vmovaps [rsp+0x10], xmm2
00007cc2f47e35ab  vmovaps [rsp+0x20], xmm3
00007cc2f47e35b1  vmovaps [rsp+0x30], xmm4
00007cc2f47e35b7  vmovaps [rsp+0x40], xmm5
00007cc2f47e35bd  vmovaps [rsp+0x50], xmm6
00007cc2f47e35c3  vmovaps [rsp+0x60], xmm7
00007cc2f47e35c9  vmovaps [rsp+0x70], xmm8
00007cc2f47e35cf  vmovaps [rsp+0x80], xmm9
00007cc2f47e35d8  vmovaps [rsp+0x90], xmm10
00007cc2f47e35e1  vmovaps [rsp+0xA0], xmm11
00007cc2f47e35ea  vmovaps [rsp+0xB0], xmm12
00007cc2f47e35f3  vmovaps [rsp+0xC0], xmm13
00007cc2f47e35fc  vmovaps [rsp+0xD0], xmm14
00007cc2f47e3605  vmovaps [rsp+0xE0], xmm15
00007cc2f47e360e  sub rsp, 0x30
00007cc2f47e3612  movaps [rsp], xmm1
00007cc2f47e3616  movaps [rsp+0x10], xmm13
00007cc2f47e361c  movaps [rsp+0x20], xmm9
00007cc2f47e3622  lea rdi, [rsp]
00007cc2f47e3626  mov esi, 0x00
00007cc2f47e362b  mov rax, 0x5990E710A530
00007cc2f47e3635  call rax
00007cc2f47e3637  movaps xmm1, [rsp]
00007cc2f47e363b  add rsp, 0x30
00007cc2f47e363f  vmovaps xmm0, [rsp]
00007cc2f47e3644  vmovaps xmm2, [rsp+0x10]
00007cc2f47e364a  vmovaps xmm3, [rsp+0x20]
00007cc2f47e3650  vmovaps xmm4, [rsp+0x30]
00007cc2f47e3656  vmovaps xmm5, [rsp+0x40]
00007cc2f47e365c  vmovaps xmm6, [rsp+0x50]
00007cc2f47e3662  vmovaps xmm7, [rsp+0x60]
00007cc2f47e3668  vmovaps xmm8, [rsp+0x70]
00007cc2f47e366e  vmovaps xmm9, [rsp+0x80]
00007cc2f47e3677  vmovaps xmm10, [rsp+0x90]
00007cc2f47e3680  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e3689  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e3692  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e369b  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e36a4  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e36ad  add rsp, 0xF0
00007cc2f47e36b4  pop r11
00007cc2f47e36b6  pop r10
00007cc2f47e36b8  pop r9
00007cc2f47e36ba  pop r8
00007cc2f47e36bc  pop rsi
00007cc2f47e36bd  pop rdi
00007cc2f47e36be  pop rdx
00007cc2f47e36bf  pop rcx
00007cc2f47e36c0  pop rax
00007cc2f47e36c1  add rsp, 0x08
00007cc2f47e36c5  jmp 0x00007CC2F47DF7AD
00007cc2f47e36ca  sub rsp, 0x08
00007cc2f47e36ce  push rax
00007cc2f47e36cf  push rcx
00007cc2f47e36d0  push rdx
00007cc2f47e36d1  push rdi
00007cc2f47e36d2  push rsi
00007cc2f47e36d3  push r8
00007cc2f47e36d5  push r9
00007cc2f47e36d7  push r10
00007cc2f47e36d9  push r11
00007cc2f47e36db  sub rsp, 0xF0
00007cc2f47e36e2  vmovaps [rsp], xmm0
00007cc2f47e36e7  vmovaps [rsp+0x10], xmm1
00007cc2f47e36ed  vmovaps [rsp+0x20], xmm2
00007cc2f47e36f3  vmovaps [rsp+0x30], xmm3
00007cc2f47e36f9  vmovaps [rsp+0x40], xmm4
00007cc2f47e36ff  vmovaps [rsp+0x50], xmm5
00007cc2f47e3705  vmovaps [rsp+0x60], xmm6
00007cc2f47e370b  vmovaps [rsp+0x70], xmm7
00007cc2f47e3711  vmovaps [rsp+0x80], xmm8
00007cc2f47e371a  vmovaps [rsp+0x90], xmm9
00007cc2f47e3723  vmovaps [rsp+0xA0], xmm10
00007cc2f47e372c  vmovaps [rsp+0xB0], xmm11
00007cc2f47e3735  vmovaps [rsp+0xC0], xmm13
00007cc2f47e373e  vmovaps [rsp+0xD0], xmm14
00007cc2f47e3747  vmovaps [rsp+0xE0], xmm15
00007cc2f47e3750  sub rsp, 0x30
00007cc2f47e3754  movaps [rsp], xmm12
00007cc2f47e3759  movaps [rsp+0x10], xmm7
00007cc2f47e375e  movaps [rsp+0x20], xmm13
00007cc2f47e3764  lea rdi, [rsp]
00007cc2f47e3768  mov esi, 0x00
00007cc2f47e376d  mov rax, 0x5990E710A530
00007cc2f47e3777  call rax
00007cc2f47e3779  movaps xmm12, [rsp]
00007cc2f47e377e  add rsp, 0x30
00007cc2f47e3782  vmovaps xmm0, [rsp]
00007cc2f47e3787  vmovaps xmm1, [rsp+0x10]
00007cc2f47e378d  vmovaps xmm2, [rsp+0x20]
00007cc2f47e3793  vmovaps xmm3, [rsp+0x30]
00007cc2f47e3799  vmovaps xmm4, [rsp+0x40]
00007cc2f47e379f  vmovaps xmm5, [rsp+0x50]
00007cc2f47e37a5  vmovaps xmm6, [rsp+0x60]
00007cc2f47e37ab  vmovaps xmm7, [rsp+0x70]
00007cc2f47e37b1  vmovaps xmm8, [rsp+0x80]
00007cc2f47e37ba  vmovaps xmm9, [rsp+0x90]
00007cc2f47e37c3  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e37cc  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e37d5  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e37de  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e37e7  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e37f0  add rsp, 0xF0
00007cc2f47e37f7  pop r11
00007cc2f47e37f9  pop r10
00007cc2f47e37fb  pop r9
00007cc2f47e37fd  pop r8
00007cc2f47e37ff  pop rsi
00007cc2f47e3800  pop rdi
00007cc2f47e3801  pop rdx
00007cc2f47e3802  pop rcx
00007cc2f47e3803  pop rax
00007cc2f47e3804  add rsp, 0x08
00007cc2f47e3808  jmp 0x00007CC2F47DF7D4
00007cc2f47e380d  sub rsp, 0x08
00007cc2f47e3811  push rax
00007cc2f47e3812  push rcx
00007cc2f47e3813  push rdx
00007cc2f47e3814  push rdi
00007cc2f47e3815  push rsi
00007cc2f47e3816  push r8
00007cc2f47e3818  push r9
00007cc2f47e381a  push r10
00007cc2f47e381c  push r11
00007cc2f47e381e  sub rsp, 0xF0
00007cc2f47e3825  vmovaps [rsp], xmm0
00007cc2f47e382a  vmovaps [rsp+0x10], xmm1
00007cc2f47e3830  vmovaps [rsp+0x20], xmm2
00007cc2f47e3836  vmovaps [rsp+0x30], xmm3
00007cc2f47e383c  vmovaps [rsp+0x40], xmm4
00007cc2f47e3842  vmovaps [rsp+0x50], xmm5
00007cc2f47e3848  vmovaps [rsp+0x60], xmm6
00007cc2f47e384e  vmovaps [rsp+0x70], xmm7
00007cc2f47e3854  vmovaps [rsp+0x80], xmm8
00007cc2f47e385d  vmovaps [rsp+0x90], xmm9
00007cc2f47e3866  vmovaps [rsp+0xA0], xmm10
00007cc2f47e386f  vmovaps [rsp+0xB0], xmm11
00007cc2f47e3878  vmovaps [rsp+0xC0], xmm12
00007cc2f47e3881  vmovaps [rsp+0xD0], xmm14
00007cc2f47e388a  vmovaps [rsp+0xE0], xmm15
00007cc2f47e3893  sub rsp, 0x30
00007cc2f47e3897  movaps [rsp], xmm13
00007cc2f47e389c  movaps [rsp+0x10], xmm15
00007cc2f47e38a2  movaps [rsp+0x20], xmm8
00007cc2f47e38a8  lea rdi, [rsp]
00007cc2f47e38ac  mov esi, 0x00
00007cc2f47e38b1  mov rax, 0x5990E710A530
00007cc2f47e38bb  call rax
00007cc2f47e38bd  movaps xmm13, [rsp]
00007cc2f47e38c2  add rsp, 0x30
00007cc2f47e38c6  vmovaps xmm0, [rsp]
00007cc2f47e38cb  vmovaps xmm1, [rsp+0x10]
00007cc2f47e38d1  vmovaps xmm2, [rsp+0x20]
00007cc2f47e38d7  vmovaps xmm3, [rsp+0x30]
00007cc2f47e38dd  vmovaps xmm4, [rsp+0x40]
00007cc2f47e38e3  vmovaps xmm5, [rsp+0x50]
00007cc2f47e38e9  vmovaps xmm6, [rsp+0x60]
00007cc2f47e38ef  vmovaps xmm7, [rsp+0x70]
00007cc2f47e38f5  vmovaps xmm8, [rsp+0x80]
00007cc2f47e38fe  vmovaps xmm9, [rsp+0x90]
00007cc2f47e3907  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e3910  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e3919  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e3922  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e392b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e3934  add rsp, 0xF0
00007cc2f47e393b  pop r11
00007cc2f47e393d  pop r10
00007cc2f47e393f  pop r9
00007cc2f47e3941  pop r8
00007cc2f47e3943  pop rsi
00007cc2f47e3944  pop rdi
00007cc2f47e3945  pop rdx
00007cc2f47e3946  pop rcx
00007cc2f47e3947  pop rax
00007cc2f47e3948  add rsp, 0x08
00007cc2f47e394c  jmp 0x00007CC2F47DF7EF
00007cc2f47e3951  sub rsp, 0x08
00007cc2f47e3955  push rax
00007cc2f47e3956  push rcx
00007cc2f47e3957  push rdx
00007cc2f47e3958  push rdi
00007cc2f47e3959  push rsi
00007cc2f47e395a  push r8
00007cc2f47e395c  push r9
00007cc2f47e395e  push r10
00007cc2f47e3960  push r11
00007cc2f47e3962  sub rsp, 0xF0
00007cc2f47e3969  vmovaps [rsp], xmm0
00007cc2f47e396e  vmovaps [rsp+0x10], xmm1
00007cc2f47e3974  vmovaps [rsp+0x20], xmm2
00007cc2f47e397a  vmovaps [rsp+0x30], xmm3
00007cc2f47e3980  vmovaps [rsp+0x40], xmm4
00007cc2f47e3986  vmovaps [rsp+0x50], xmm5
00007cc2f47e398c  vmovaps [rsp+0x60], xmm6
00007cc2f47e3992  vmovaps [rsp+0x70], xmm7
00007cc2f47e3998  vmovaps [rsp+0x80], xmm9
00007cc2f47e39a1  vmovaps [rsp+0x90], xmm10
00007cc2f47e39aa  vmovaps [rsp+0xA0], xmm11
00007cc2f47e39b3  vmovaps [rsp+0xB0], xmm12
00007cc2f47e39bc  vmovaps [rsp+0xC0], xmm13
00007cc2f47e39c5  vmovaps [rsp+0xD0], xmm14
00007cc2f47e39ce  vmovaps [rsp+0xE0], xmm15
00007cc2f47e39d7  sub rsp, 0x30
00007cc2f47e39db  movaps [rsp], xmm8
00007cc2f47e39e0  movaps [rsp+0x10], xmm15
00007cc2f47e39e6  movaps [rsp+0x20], xmm9
00007cc2f47e39ec  lea rdi, [rsp]
00007cc2f47e39f0  mov esi, 0x00
00007cc2f47e39f5  mov rax, 0x5990E710A530
00007cc2f47e39ff  call rax
00007cc2f47e3a01  movaps xmm8, [rsp]
00007cc2f47e3a06  add rsp, 0x30
00007cc2f47e3a0a  vmovaps xmm0, [rsp]
00007cc2f47e3a0f  vmovaps xmm1, [rsp+0x10]
00007cc2f47e3a15  vmovaps xmm2, [rsp+0x20]
00007cc2f47e3a1b  vmovaps xmm3, [rsp+0x30]
00007cc2f47e3a21  vmovaps xmm4, [rsp+0x40]
00007cc2f47e3a27  vmovaps xmm5, [rsp+0x50]
00007cc2f47e3a2d  vmovaps xmm6, [rsp+0x60]
00007cc2f47e3a33  vmovaps xmm7, [rsp+0x70]
00007cc2f47e3a39  vmovaps xmm9, [rsp+0x80]
00007cc2f47e3a42  vmovaps xmm10, [rsp+0x90]
00007cc2f47e3a4b  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e3a54  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e3a5d  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e3a66  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e3a6f  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e3a78  add rsp, 0xF0
00007cc2f47e3a7f  pop r11
00007cc2f47e3a81  pop r10
00007cc2f47e3a83  pop r9
00007cc2f47e3a85  pop r8
00007cc2f47e3a87  pop rsi
00007cc2f47e3a88  pop rdi
00007cc2f47e3a89  pop rdx
00007cc2f47e3a8a  pop rcx
00007cc2f47e3a8b  pop rax
00007cc2f47e3a8c  add rsp, 0x08
00007cc2f47e3a90  jmp 0x00007CC2F47DF81D
00007cc2f47e3a95  sub rsp, 0x08
00007cc2f47e3a99  push rax
00007cc2f47e3a9a  push rcx
00007cc2f47e3a9b  push rdx
00007cc2f47e3a9c  push rdi
00007cc2f47e3a9d  push rsi
00007cc2f47e3a9e  push r8
00007cc2f47e3aa0  push r9
00007cc2f47e3aa2  push r10
00007cc2f47e3aa4  push r11
00007cc2f47e3aa6  sub rsp, 0xF0
00007cc2f47e3aad  vmovaps [rsp], xmm0
00007cc2f47e3ab2  vmovaps [rsp+0x10], xmm1
00007cc2f47e3ab8  vmovaps [rsp+0x20], xmm2
00007cc2f47e3abe  vmovaps [rsp+0x30], xmm3
00007cc2f47e3ac4  vmovaps [rsp+0x40], xmm4
00007cc2f47e3aca  vmovaps [rsp+0x50], xmm5
00007cc2f47e3ad0  vmovaps [rsp+0x60], xmm6
00007cc2f47e3ad6  vmovaps [rsp+0x70], xmm7
00007cc2f47e3adc  vmovaps [rsp+0x80], xmm8
00007cc2f47e3ae5  vmovaps [rsp+0x90], xmm9
00007cc2f47e3aee  vmovaps [rsp+0xA0], xmm10
00007cc2f47e3af7  vmovaps [rsp+0xB0], xmm11
00007cc2f47e3b00  vmovaps [rsp+0xC0], xmm12
00007cc2f47e3b09  vmovaps [rsp+0xD0], xmm13
00007cc2f47e3b12  vmovaps [rsp+0xE0], xmm14
00007cc2f47e3b1b  sub rsp, 0x30
00007cc2f47e3b1f  movaps [rsp], xmm15
00007cc2f47e3b24  movaps [rsp+0x10], xmm11
00007cc2f47e3b2a  movaps [rsp+0x20], xmm6
00007cc2f47e3b2f  lea rdi, [rsp]
00007cc2f47e3b33  mov esi, 0x00
00007cc2f47e3b38  mov rax, 0x5990E710A530
00007cc2f47e3b42  call rax
00007cc2f47e3b44  movaps xmm15, [rsp]
00007cc2f47e3b49  add rsp, 0x30
00007cc2f47e3b4d  vmovaps xmm0, [rsp]
00007cc2f47e3b52  vmovaps xmm1, [rsp+0x10]
00007cc2f47e3b58  vmovaps xmm2, [rsp+0x20]
00007cc2f47e3b5e  vmovaps xmm3, [rsp+0x30]
00007cc2f47e3b64  vmovaps xmm4, [rsp+0x40]
00007cc2f47e3b6a  vmovaps xmm5, [rsp+0x50]
00007cc2f47e3b70  vmovaps xmm6, [rsp+0x60]
00007cc2f47e3b76  vmovaps xmm7, [rsp+0x70]
00007cc2f47e3b7c  vmovaps xmm8, [rsp+0x80]
00007cc2f47e3b85  vmovaps xmm9, [rsp+0x90]
00007cc2f47e3b8e  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e3b97  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e3ba0  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e3ba9  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e3bb2  vmovaps xmm14, [rsp+0xE0]
00007cc2f47e3bbb  add rsp, 0xF0
00007cc2f47e3bc2  pop r11
00007cc2f47e3bc4  pop r10
00007cc2f47e3bc6  pop r9
00007cc2f47e3bc8  pop r8
00007cc2f47e3bca  pop rsi
00007cc2f47e3bcb  pop rdi
00007cc2f47e3bcc  pop rdx
00007cc2f47e3bcd  pop rcx
00007cc2f47e3bce  pop rax
00007cc2f47e3bcf  add rsp, 0x08
00007cc2f47e3bd3  jmp 0x00007CC2F47DF838
00007cc2f47e3bd8  sub rsp, 0x08
00007cc2f47e3bdc  push rax
00007cc2f47e3bdd  push rcx
00007cc2f47e3bde  push rdx
00007cc2f47e3bdf  push rdi
00007cc2f47e3be0  push rsi
00007cc2f47e3be1  push r8
00007cc2f47e3be3  push r9
00007cc2f47e3be5  push r10
00007cc2f47e3be7  push r11
00007cc2f47e3be9  sub rsp, 0xF0
00007cc2f47e3bf0  vmovaps [rsp], xmm0
00007cc2f47e3bf5  vmovaps [rsp+0x10], xmm1
00007cc2f47e3bfb  vmovaps [rsp+0x20], xmm2
00007cc2f47e3c01  vmovaps [rsp+0x30], xmm3
00007cc2f47e3c07  vmovaps [rsp+0x40], xmm4
00007cc2f47e3c0d  vmovaps [rsp+0x50], xmm5
00007cc2f47e3c13  vmovaps [rsp+0x60], xmm6
00007cc2f47e3c19  vmovaps [rsp+0x70], xmm8
00007cc2f47e3c1f  vmovaps [rsp+0x80], xmm9
00007cc2f47e3c28  vmovaps [rsp+0x90], xmm10
00007cc2f47e3c31  vmovaps [rsp+0xA0], xmm11
00007cc2f47e3c3a  vmovaps [rsp+0xB0], xmm12
00007cc2f47e3c43  vmovaps [rsp+0xC0], xmm13
00007cc2f47e3c4c  vmovaps [rsp+0xD0], xmm14
00007cc2f47e3c55  vmovaps [rsp+0xE0], xmm15
00007cc2f47e3c5e  sub rsp, 0x30
00007cc2f47e3c62  movaps [rsp], xmm7
00007cc2f47e3c66  movaps [rsp+0x10], xmm11
00007cc2f47e3c6c  movaps [rsp+0x20], xmm9
00007cc2f47e3c72  lea rdi, [rsp]
00007cc2f47e3c76  mov esi, 0x00
00007cc2f47e3c7b  mov rax, 0x5990E710A530
00007cc2f47e3c85  call rax
00007cc2f47e3c87  movaps xmm7, [rsp]
00007cc2f47e3c8b  add rsp, 0x30
00007cc2f47e3c8f  vmovaps xmm0, [rsp]
00007cc2f47e3c94  vmovaps xmm1, [rsp+0x10]
00007cc2f47e3c9a  vmovaps xmm2, [rsp+0x20]
00007cc2f47e3ca0  vmovaps xmm3, [rsp+0x30]
00007cc2f47e3ca6  vmovaps xmm4, [rsp+0x40]
00007cc2f47e3cac  vmovaps xmm5, [rsp+0x50]
00007cc2f47e3cb2  vmovaps xmm6, [rsp+0x60]
00007cc2f47e3cb8  vmovaps xmm8, [rsp+0x70]
00007cc2f47e3cbe  vmovaps xmm9, [rsp+0x80]
00007cc2f47e3cc7  vmovaps xmm10, [rsp+0x90]
00007cc2f47e3cd0  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e3cd9  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e3ce2  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e3ceb  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e3cf4  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e3cfd  add rsp, 0xF0
00007cc2f47e3d04  pop r11
00007cc2f47e3d06  pop r10
00007cc2f47e3d08  pop r9
00007cc2f47e3d0a  pop r8
00007cc2f47e3d0c  pop rsi
00007cc2f47e3d0d  pop rdi
00007cc2f47e3d0e  pop rdx
00007cc2f47e3d0f  pop rcx
00007cc2f47e3d10  pop rax
00007cc2f47e3d11  add rsp, 0x08
00007cc2f47e3d15  jmp 0x00007CC2F47DF865
00007cc2f47e3d1a  sub rsp, 0x08
00007cc2f47e3d1e  push rax
00007cc2f47e3d1f  push rcx
00007cc2f47e3d20  push rdx
00007cc2f47e3d21  push rdi
00007cc2f47e3d22  push rsi
00007cc2f47e3d23  push r8
00007cc2f47e3d25  push r9
00007cc2f47e3d27  push r10
00007cc2f47e3d29  push r11
00007cc2f47e3d2b  sub rsp, 0xF0
00007cc2f47e3d32  vmovaps [rsp], xmm0
00007cc2f47e3d37  vmovaps [rsp+0x10], xmm1
00007cc2f47e3d3d  vmovaps [rsp+0x20], xmm2
00007cc2f47e3d43  vmovaps [rsp+0x30], xmm3
00007cc2f47e3d49  vmovaps [rsp+0x40], xmm4
00007cc2f47e3d4f  vmovaps [rsp+0x50], xmm5
00007cc2f47e3d55  vmovaps [rsp+0x60], xmm6
00007cc2f47e3d5b  vmovaps [rsp+0x70], xmm7
00007cc2f47e3d61  vmovaps [rsp+0x80], xmm8
00007cc2f47e3d6a  vmovaps [rsp+0x90], xmm9
00007cc2f47e3d73  vmovaps [rsp+0xA0], xmm10
00007cc2f47e3d7c  vmovaps [rsp+0xB0], xmm12
00007cc2f47e3d85  vmovaps [rsp+0xC0], xmm13
00007cc2f47e3d8e  vmovaps [rsp+0xD0], xmm14
00007cc2f47e3d97  vmovaps [rsp+0xE0], xmm15
00007cc2f47e3da0  sub rsp, 0x30
00007cc2f47e3da4  movaps [rsp], xmm11
00007cc2f47e3da9  movaps [rsp+0x10], xmm10
00007cc2f47e3daf  movaps [rsp+0x20], xmm14
00007cc2f47e3db5  lea rdi, [rsp]
00007cc2f47e3db9  mov esi, 0x00
00007cc2f47e3dbe  mov rax, 0x5990E710A530
00007cc2f47e3dc8  call rax
00007cc2f47e3dca  movaps xmm11, [rsp]
00007cc2f47e3dcf  add rsp, 0x30
00007cc2f47e3dd3  vmovaps xmm0, [rsp]
00007cc2f47e3dd8  vmovaps xmm1, [rsp+0x10]
00007cc2f47e3dde  vmovaps xmm2, [rsp+0x20]
00007cc2f47e3de4  vmovaps xmm3, [rsp+0x30]
00007cc2f47e3dea  vmovaps xmm4, [rsp+0x40]
00007cc2f47e3df0  vmovaps xmm5, [rsp+0x50]
00007cc2f47e3df6  vmovaps xmm6, [rsp+0x60]
00007cc2f47e3dfc  vmovaps xmm7, [rsp+0x70]
00007cc2f47e3e02  vmovaps xmm8, [rsp+0x80]
00007cc2f47e3e0b  vmovaps xmm9, [rsp+0x90]
00007cc2f47e3e14  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e3e1d  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e3e26  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e3e2f  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e3e38  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e3e41  add rsp, 0xF0
00007cc2f47e3e48  pop r11
00007cc2f47e3e4a  pop r10
00007cc2f47e3e4c  pop r9
00007cc2f47e3e4e  pop r8
00007cc2f47e3e50  pop rsi
00007cc2f47e3e51  pop rdi
00007cc2f47e3e52  pop rdx
00007cc2f47e3e53  pop rcx
00007cc2f47e3e54  pop rax
00007cc2f47e3e55  add rsp, 0x08
00007cc2f47e3e59  jmp 0x00007CC2F47DF880
00007cc2f47e3e5e  call 0x00007CC2F46C33A0
00007cc2f47e3e63  jmp 0x00007CC2F47DF88A
00007cc2f47e3e68  sub rsp, 0x08
00007cc2f47e3e6c  push rax
00007cc2f47e3e6d  push rcx
00007cc2f47e3e6e  push rdx
00007cc2f47e3e6f  push rdi
00007cc2f47e3e70  push rsi
00007cc2f47e3e71  push r8
00007cc2f47e3e73  push r9
00007cc2f47e3e75  push r10
00007cc2f47e3e77  push r11
00007cc2f47e3e79  sub rsp, 0xF0
00007cc2f47e3e80  vmovaps [rsp], xmm0
00007cc2f47e3e85  vmovaps [rsp+0x10], xmm1
00007cc2f47e3e8b  vmovaps [rsp+0x20], xmm2
00007cc2f47e3e91  vmovaps [rsp+0x30], xmm3
00007cc2f47e3e97  vmovaps [rsp+0x40], xmm4
00007cc2f47e3e9d  vmovaps [rsp+0x50], xmm5
00007cc2f47e3ea3  vmovaps [rsp+0x60], xmm6
00007cc2f47e3ea9  vmovaps [rsp+0x70], xmm7
00007cc2f47e3eaf  vmovaps [rsp+0x80], xmm8
00007cc2f47e3eb8  vmovaps [rsp+0x90], xmm9
00007cc2f47e3ec1  vmovaps [rsp+0xA0], xmm11
00007cc2f47e3eca  vmovaps [rsp+0xB0], xmm12
00007cc2f47e3ed3  vmovaps [rsp+0xC0], xmm13
00007cc2f47e3edc  vmovaps [rsp+0xD0], xmm14
00007cc2f47e3ee5  vmovaps [rsp+0xE0], xmm15
00007cc2f47e3eee  sub rsp, 0x30
00007cc2f47e3ef2  movaps [rsp], xmm10
00007cc2f47e3ef7  movaps [rsp+0x10], xmm1
00007cc2f47e3efc  movaps [rsp+0x20], xmm12
00007cc2f47e3f02  lea rdi, [rsp]
00007cc2f47e3f06  mov esi, 0x00
00007cc2f47e3f0b  mov rax, 0x5990E710A530
00007cc2f47e3f15  call rax
00007cc2f47e3f17  movaps xmm10, [rsp]
00007cc2f47e3f1c  add rsp, 0x30
00007cc2f47e3f20  vmovaps xmm0, [rsp]
00007cc2f47e3f25  vmovaps xmm1, [rsp+0x10]
00007cc2f47e3f2b  vmovaps xmm2, [rsp+0x20]
00007cc2f47e3f31  vmovaps xmm3, [rsp+0x30]
00007cc2f47e3f37  vmovaps xmm4, [rsp+0x40]
00007cc2f47e3f3d  vmovaps xmm5, [rsp+0x50]
00007cc2f47e3f43  vmovaps xmm6, [rsp+0x60]
00007cc2f47e3f49  vmovaps xmm7, [rsp+0x70]
00007cc2f47e3f4f  vmovaps xmm8, [rsp+0x80]
00007cc2f47e3f58  vmovaps xmm9, [rsp+0x90]
00007cc2f47e3f61  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e3f6a  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e3f73  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e3f7c  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e3f85  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e3f8e  add rsp, 0xF0
00007cc2f47e3f95  pop r11
00007cc2f47e3f97  pop r10
00007cc2f47e3f99  pop r9
00007cc2f47e3f9b  pop r8
00007cc2f47e3f9d  pop rsi
00007cc2f47e3f9e  pop rdi
00007cc2f47e3f9f  pop rdx
00007cc2f47e3fa0  pop rcx
00007cc2f47e3fa1  pop rax
00007cc2f47e3fa2  add rsp, 0x08
00007cc2f47e3fa6  jmp 0x00007CC2F47DF8AD
00007cc2f47e3fab  sub rsp, 0x08
00007cc2f47e3faf  push rax
00007cc2f47e3fb0  push rcx
00007cc2f47e3fb1  push rdx
00007cc2f47e3fb2  push rdi
00007cc2f47e3fb3  push rsi
00007cc2f47e3fb4  push r8
00007cc2f47e3fb6  push r9
00007cc2f47e3fb8  push r10
00007cc2f47e3fba  push r11
00007cc2f47e3fbc  sub rsp, 0xF0
00007cc2f47e3fc3  vmovaps [rsp], xmm0
00007cc2f47e3fc8  vmovaps [rsp+0x10], xmm1
00007cc2f47e3fce  vmovaps [rsp+0x20], xmm2
00007cc2f47e3fd4  vmovaps [rsp+0x30], xmm3
00007cc2f47e3fda  vmovaps [rsp+0x40], xmm4
00007cc2f47e3fe0  vmovaps [rsp+0x50], xmm5
00007cc2f47e3fe6  vmovaps [rsp+0x60], xmm6
00007cc2f47e3fec  vmovaps [rsp+0x70], xmm7
00007cc2f47e3ff2  vmovaps [rsp+0x80], xmm8
00007cc2f47e3ffb  vmovaps [rsp+0x90], xmm9
00007cc2f47e4004  vmovaps [rsp+0xA0], xmm10
00007cc2f47e400d  vmovaps [rsp+0xB0], xmm11
00007cc2f47e4016  vmovaps [rsp+0xC0], xmm13
00007cc2f47e401f  vmovaps [rsp+0xD0], xmm14
00007cc2f47e4028  vmovaps [rsp+0xE0], xmm15
00007cc2f47e4031  sub rsp, 0x30
00007cc2f47e4035  movaps [rsp], xmm12
00007cc2f47e403a  movaps [rsp+0x10], xmm14
00007cc2f47e4040  movaps [rsp+0x20], xmm1
00007cc2f47e4045  lea rdi, [rsp]
00007cc2f47e4049  mov esi, 0x00
00007cc2f47e404e  mov rax, 0x5990E710A530
00007cc2f47e4058  call rax
00007cc2f47e405a  movaps xmm12, [rsp]
00007cc2f47e405f  add rsp, 0x30
00007cc2f47e4063  vmovaps xmm0, [rsp]
00007cc2f47e4068  vmovaps xmm1, [rsp+0x10]
00007cc2f47e406e  vmovaps xmm2, [rsp+0x20]
00007cc2f47e4074  vmovaps xmm3, [rsp+0x30]
00007cc2f47e407a  vmovaps xmm4, [rsp+0x40]
00007cc2f47e4080  vmovaps xmm5, [rsp+0x50]
00007cc2f47e4086  vmovaps xmm6, [rsp+0x60]
00007cc2f47e408c  vmovaps xmm7, [rsp+0x70]
00007cc2f47e4092  vmovaps xmm8, [rsp+0x80]
00007cc2f47e409b  vmovaps xmm9, [rsp+0x90]
00007cc2f47e40a4  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e40ad  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e40b6  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e40bf  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e40c8  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e40d1  add rsp, 0xF0
00007cc2f47e40d8  pop r11
00007cc2f47e40da  pop r10
00007cc2f47e40dc  pop r9
00007cc2f47e40de  pop r8
00007cc2f47e40e0  pop rsi
00007cc2f47e40e1  pop rdi
00007cc2f47e40e2  pop rdx
00007cc2f47e40e3  pop rcx
00007cc2f47e40e4  pop rax
00007cc2f47e40e5  add rsp, 0x08
00007cc2f47e40e9  jmp 0x00007CC2F47DF8DC
00007cc2f47e40ee  sub rsp, 0x08
00007cc2f47e40f2  push rax
00007cc2f47e40f3  push rcx
00007cc2f47e40f4  push rdx
00007cc2f47e40f5  push rdi
00007cc2f47e40f6  push rsi
00007cc2f47e40f7  push r8
00007cc2f47e40f9  push r9
00007cc2f47e40fb  push r10
00007cc2f47e40fd  push r11
00007cc2f47e40ff  sub rsp, 0xF0
00007cc2f47e4106  vmovaps [rsp], xmm0
00007cc2f47e410b  vmovaps [rsp+0x10], xmm1
00007cc2f47e4111  vmovaps [rsp+0x20], xmm2
00007cc2f47e4117  vmovaps [rsp+0x30], xmm3
00007cc2f47e411d  vmovaps [rsp+0x40], xmm4
00007cc2f47e4123  vmovaps [rsp+0x50], xmm5
00007cc2f47e4129  vmovaps [rsp+0x60], xmm6
00007cc2f47e412f  vmovaps [rsp+0x70], xmm7
00007cc2f47e4135  vmovaps [rsp+0x80], xmm8
00007cc2f47e413e  vmovaps [rsp+0x90], xmm9
00007cc2f47e4147  vmovaps [rsp+0xA0], xmm10
00007cc2f47e4150  vmovaps [rsp+0xB0], xmm11
00007cc2f47e4159  vmovaps [rsp+0xC0], xmm12
00007cc2f47e4162  vmovaps [rsp+0xD0], xmm13
00007cc2f47e416b  vmovaps [rsp+0xE0], xmm15
00007cc2f47e4174  sub rsp, 0x30
00007cc2f47e4178  movaps [rsp], xmm14
00007cc2f47e417d  movaps [rsp+0x10], xmm9
00007cc2f47e4183  movaps [rsp+0x20], xmm1
00007cc2f47e4188  lea rdi, [rsp]
00007cc2f47e418c  mov esi, 0x00
00007cc2f47e4191  mov rax, 0x5990E710A530
00007cc2f47e419b  call rax
00007cc2f47e419d  movaps xmm14, [rsp]
00007cc2f47e41a2  add rsp, 0x30
00007cc2f47e41a6  vmovaps xmm0, [rsp]
00007cc2f47e41ab  vmovaps xmm1, [rsp+0x10]
00007cc2f47e41b1  vmovaps xmm2, [rsp+0x20]
00007cc2f47e41b7  vmovaps xmm3, [rsp+0x30]
00007cc2f47e41bd  vmovaps xmm4, [rsp+0x40]
00007cc2f47e41c3  vmovaps xmm5, [rsp+0x50]
00007cc2f47e41c9  vmovaps xmm6, [rsp+0x60]
00007cc2f47e41cf  vmovaps xmm7, [rsp+0x70]
00007cc2f47e41d5  vmovaps xmm8, [rsp+0x80]
00007cc2f47e41de  vmovaps xmm9, [rsp+0x90]
00007cc2f47e41e7  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e41f0  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e41f9  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e4202  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e420b  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e4214  add rsp, 0xF0
00007cc2f47e421b  pop r11
00007cc2f47e421d  pop r10
00007cc2f47e421f  pop r9
00007cc2f47e4221  pop r8
00007cc2f47e4223  pop rsi
00007cc2f47e4224  pop rdi
00007cc2f47e4225  pop rdx
00007cc2f47e4226  pop rcx
00007cc2f47e4227  pop rax
00007cc2f47e4228  add rsp, 0x08
00007cc2f47e422c  jmp 0x00007CC2F47DF90B
00007cc2f47e4231  sub rsp, 0x08
00007cc2f47e4235  push rax
00007cc2f47e4236  push rcx
00007cc2f47e4237  push rdx
00007cc2f47e4238  push rdi
00007cc2f47e4239  push rsi
00007cc2f47e423a  push r8
00007cc2f47e423c  push r9
00007cc2f47e423e  push r10
00007cc2f47e4240  push r11
00007cc2f47e4242  sub rsp, 0xF0
00007cc2f47e4249  vmovaps [rsp], xmm0
00007cc2f47e424e  vmovaps [rsp+0x10], xmm2
00007cc2f47e4254  vmovaps [rsp+0x20], xmm3
00007cc2f47e425a  vmovaps [rsp+0x30], xmm4
00007cc2f47e4260  vmovaps [rsp+0x40], xmm5
00007cc2f47e4266  vmovaps [rsp+0x50], xmm6
00007cc2f47e426c  vmovaps [rsp+0x60], xmm7
00007cc2f47e4272  vmovaps [rsp+0x70], xmm8
00007cc2f47e4278  vmovaps [rsp+0x80], xmm9
00007cc2f47e4281  vmovaps [rsp+0x90], xmm10
00007cc2f47e428a  vmovaps [rsp+0xA0], xmm11
00007cc2f47e4293  vmovaps [rsp+0xB0], xmm12
00007cc2f47e429c  vmovaps [rsp+0xC0], xmm13
00007cc2f47e42a5  vmovaps [rsp+0xD0], xmm14
00007cc2f47e42ae  vmovaps [rsp+0xE0], xmm15
00007cc2f47e42b7  sub rsp, 0x30
00007cc2f47e42bb  movaps [rsp], xmm1
00007cc2f47e42bf  movaps [rsp+0x10], xmm13
00007cc2f47e42c5  movaps [rsp+0x20], xmm8
00007cc2f47e42cb  lea rdi, [rsp]
00007cc2f47e42cf  mov esi, 0x00
00007cc2f47e42d4  mov rax, 0x5990E710A530
00007cc2f47e42de  call rax
00007cc2f47e42e0  movaps xmm1, [rsp]
00007cc2f47e42e4  add rsp, 0x30
00007cc2f47e42e8  vmovaps xmm0, [rsp]
00007cc2f47e42ed  vmovaps xmm2, [rsp+0x10]
00007cc2f47e42f3  vmovaps xmm3, [rsp+0x20]
00007cc2f47e42f9  vmovaps xmm4, [rsp+0x30]
00007cc2f47e42ff  vmovaps xmm5, [rsp+0x40]
00007cc2f47e4305  vmovaps xmm6, [rsp+0x50]
00007cc2f47e430b  vmovaps xmm7, [rsp+0x60]
00007cc2f47e4311  vmovaps xmm8, [rsp+0x70]
00007cc2f47e4317  vmovaps xmm9, [rsp+0x80]
00007cc2f47e4320  vmovaps xmm10, [rsp+0x90]
00007cc2f47e4329  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e4332  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e433b  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e4344  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e434d  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e4356  add rsp, 0xF0
00007cc2f47e435d  pop r11
00007cc2f47e435f  pop r10
00007cc2f47e4361  pop r9
00007cc2f47e4363  pop r8
00007cc2f47e4365  pop rsi
00007cc2f47e4366  pop rdi
00007cc2f47e4367  pop rdx
00007cc2f47e4368  pop rcx
00007cc2f47e4369  pop rax
00007cc2f47e436a  add rsp, 0x08
00007cc2f47e436e  jmp 0x00007CC2F47DF92D
00007cc2f47e4373  call 0x00007CC2F460C260
00007cc2f47e4378  jmp 0x00007CC2F47DF93B
00007cc2f47e437d  call 0x00007CC2F46BD750
00007cc2f47e4382  jmp 0x00007CC2F47DF945
00007cc2f47e4387  sub rsp, 0x08
00007cc2f47e438b  push rax
00007cc2f47e438c  push rcx
00007cc2f47e438d  push rdx
00007cc2f47e438e  push rdi
00007cc2f47e438f  push rsi
00007cc2f47e4390  push r8
00007cc2f47e4392  push r9
00007cc2f47e4394  push r10
00007cc2f47e4396  push r11
00007cc2f47e4398  sub rsp, 0xF0
00007cc2f47e439f  vmovaps [rsp], xmm0
00007cc2f47e43a4  vmovaps [rsp+0x10], xmm1
00007cc2f47e43aa  vmovaps [rsp+0x20], xmm2
00007cc2f47e43b0  vmovaps [rsp+0x30], xmm3
00007cc2f47e43b6  vmovaps [rsp+0x40], xmm4
00007cc2f47e43bc  vmovaps [rsp+0x50], xmm5
00007cc2f47e43c2  vmovaps [rsp+0x60], xmm6
00007cc2f47e43c8  vmovaps [rsp+0x70], xmm7
00007cc2f47e43ce  vmovaps [rsp+0x80], xmm9
00007cc2f47e43d7  vmovaps [rsp+0x90], xmm10
00007cc2f47e43e0  vmovaps [rsp+0xA0], xmm11
00007cc2f47e43e9  vmovaps [rsp+0xB0], xmm12
00007cc2f47e43f2  vmovaps [rsp+0xC0], xmm13
00007cc2f47e43fb  vmovaps [rsp+0xD0], xmm14
00007cc2f47e4404  vmovaps [rsp+0xE0], xmm15
00007cc2f47e440d  sub rsp, 0x30
00007cc2f47e4411  movaps [rsp], xmm8
00007cc2f47e4416  movaps [rsp+0x10], xmm15
00007cc2f47e441c  movaps [rsp+0x20], xmm7
00007cc2f47e4421  lea rdi, [rsp]
00007cc2f47e4425  mov esi, 0x00
00007cc2f47e442a  mov rax, 0x5990E710A530
00007cc2f47e4434  call rax
00007cc2f47e4436  movaps xmm8, [rsp]
00007cc2f47e443b  add rsp, 0x30
00007cc2f47e443f  vmovaps xmm0, [rsp]
00007cc2f47e4444  vmovaps xmm1, [rsp+0x10]
00007cc2f47e444a  vmovaps xmm2, [rsp+0x20]
00007cc2f47e4450  vmovaps xmm3, [rsp+0x30]
00007cc2f47e4456  vmovaps xmm4, [rsp+0x40]
00007cc2f47e445c  vmovaps xmm5, [rsp+0x50]
00007cc2f47e4462  vmovaps xmm6, [rsp+0x60]
00007cc2f47e4468  vmovaps xmm7, [rsp+0x70]
00007cc2f47e446e  vmovaps xmm9, [rsp+0x80]
00007cc2f47e4477  vmovaps xmm10, [rsp+0x90]
00007cc2f47e4480  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e4489  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e4492  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e449b  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e44a4  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e44ad  add rsp, 0xF0
00007cc2f47e44b4  pop r11
00007cc2f47e44b6  pop r10
00007cc2f47e44b8  pop r9
00007cc2f47e44ba  pop r8
00007cc2f47e44bc  pop rsi
00007cc2f47e44bd  pop rdi
00007cc2f47e44be  pop rdx
00007cc2f47e44bf  pop rcx
00007cc2f47e44c0  pop rax
00007cc2f47e44c1  add rsp, 0x08
00007cc2f47e44c5  jmp 0x00007CC2F47DF967
00007cc2f47e44ca  sub rsp, 0x08
00007cc2f47e44ce  push rax
00007cc2f47e44cf  push rcx
00007cc2f47e44d0  push rdx
00007cc2f47e44d1  push rdi
00007cc2f47e44d2  push rsi
00007cc2f47e44d3  push r8
00007cc2f47e44d5  push r9
00007cc2f47e44d7  push r10
00007cc2f47e44d9  push r11
00007cc2f47e44db  sub rsp, 0xF0
00007cc2f47e44e2  vmovaps [rsp], xmm0
00007cc2f47e44e7  vmovaps [rsp+0x10], xmm1
00007cc2f47e44ed  vmovaps [rsp+0x20], xmm2
00007cc2f47e44f3  vmovaps [rsp+0x30], xmm3
00007cc2f47e44f9  vmovaps [rsp+0x40], xmm4
00007cc2f47e44ff  vmovaps [rsp+0x50], xmm5
00007cc2f47e4505  vmovaps [rsp+0x60], xmm6
00007cc2f47e450b  vmovaps [rsp+0x70], xmm8
00007cc2f47e4511  vmovaps [rsp+0x80], xmm9
00007cc2f47e451a  vmovaps [rsp+0x90], xmm10
00007cc2f47e4523  vmovaps [rsp+0xA0], xmm11
00007cc2f47e452c  vmovaps [rsp+0xB0], xmm12
00007cc2f47e4535  vmovaps [rsp+0xC0], xmm13
00007cc2f47e453e  vmovaps [rsp+0xD0], xmm14
00007cc2f47e4547  vmovaps [rsp+0xE0], xmm15
00007cc2f47e4550  sub rsp, 0x30
00007cc2f47e4554  movaps [rsp], xmm7
00007cc2f47e4558  movaps [rsp+0x10], xmm9
00007cc2f47e455e  movaps [rsp+0x20], xmm15
00007cc2f47e4564  lea rdi, [rsp]
00007cc2f47e4568  mov esi, 0x00
00007cc2f47e456d  mov rax, 0x5990E710A530
00007cc2f47e4577  call rax
00007cc2f47e4579  movaps xmm7, [rsp]
00007cc2f47e457d  add rsp, 0x30
00007cc2f47e4581  vmovaps xmm0, [rsp]
00007cc2f47e4586  vmovaps xmm1, [rsp+0x10]
00007cc2f47e458c  vmovaps xmm2, [rsp+0x20]
00007cc2f47e4592  vmovaps xmm3, [rsp+0x30]
00007cc2f47e4598  vmovaps xmm4, [rsp+0x40]
00007cc2f47e459e  vmovaps xmm5, [rsp+0x50]
00007cc2f47e45a4  vmovaps xmm6, [rsp+0x60]
00007cc2f47e45aa  vmovaps xmm8, [rsp+0x70]
00007cc2f47e45b0  vmovaps xmm9, [rsp+0x80]
00007cc2f47e45b9  vmovaps xmm10, [rsp+0x90]
00007cc2f47e45c2  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e45cb  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e45d4  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e45dd  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e45e6  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e45ef  add rsp, 0xF0
00007cc2f47e45f6  pop r11
00007cc2f47e45f8  pop r10
00007cc2f47e45fa  pop r9
00007cc2f47e45fc  pop r8
00007cc2f47e45fe  pop rsi
00007cc2f47e45ff  pop rdi
00007cc2f47e4600  pop rdx
00007cc2f47e4601  pop rcx
00007cc2f47e4602  pop rax
00007cc2f47e4603  add rsp, 0x08
00007cc2f47e4607  jmp 0x00007CC2F47DF994
00007cc2f47e460c  sub rsp, 0x08
00007cc2f47e4610  push rax
00007cc2f47e4611  push rcx
00007cc2f47e4612  push rdx
00007cc2f47e4613  push rdi
00007cc2f47e4614  push rsi
00007cc2f47e4615  push r8
00007cc2f47e4617  push r9
00007cc2f47e4619  push r10
00007cc2f47e461b  push r11
00007cc2f47e461d  sub rsp, 0xF0
00007cc2f47e4624  vmovaps [rsp], xmm0
00007cc2f47e4629  vmovaps [rsp+0x10], xmm1
00007cc2f47e462f  vmovaps [rsp+0x20], xmm2
00007cc2f47e4635  vmovaps [rsp+0x30], xmm3
00007cc2f47e463b  vmovaps [rsp+0x40], xmm4
00007cc2f47e4641  vmovaps [rsp+0x50], xmm5
00007cc2f47e4647  vmovaps [rsp+0x60], xmm6
00007cc2f47e464d  vmovaps [rsp+0x70], xmm7
00007cc2f47e4653  vmovaps [rsp+0x80], xmm8
00007cc2f47e465c  vmovaps [rsp+0x90], xmm10
00007cc2f47e4665  vmovaps [rsp+0xA0], xmm11
00007cc2f47e466e  vmovaps [rsp+0xB0], xmm12
00007cc2f47e4677  vmovaps [rsp+0xC0], xmm13
00007cc2f47e4680  vmovaps [rsp+0xD0], xmm14
00007cc2f47e4689  vmovaps [rsp+0xE0], xmm15
00007cc2f47e4692  sub rsp, 0x30
00007cc2f47e4696  movaps [rsp], xmm9
00007cc2f47e469b  movaps [rsp+0x10], xmm13
00007cc2f47e46a1  movaps [rsp+0x20], xmm15
00007cc2f47e46a7  lea rdi, [rsp]
00007cc2f47e46ab  mov esi, 0x00
00007cc2f47e46b0  mov rax, 0x5990E710A530
00007cc2f47e46ba  call rax
00007cc2f47e46bc  movaps xmm9, [rsp]
00007cc2f47e46c1  add rsp, 0x30
00007cc2f47e46c5  vmovaps xmm0, [rsp]
00007cc2f47e46ca  vmovaps xmm1, [rsp+0x10]
00007cc2f47e46d0  vmovaps xmm2, [rsp+0x20]
00007cc2f47e46d6  vmovaps xmm3, [rsp+0x30]
00007cc2f47e46dc  vmovaps xmm4, [rsp+0x40]
00007cc2f47e46e2  vmovaps xmm5, [rsp+0x50]
00007cc2f47e46e8  vmovaps xmm6, [rsp+0x60]
00007cc2f47e46ee  vmovaps xmm7, [rsp+0x70]
00007cc2f47e46f4  vmovaps xmm8, [rsp+0x80]
00007cc2f47e46fd  vmovaps xmm10, [rsp+0x90]
00007cc2f47e4706  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e470f  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e4718  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e4721  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e472a  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e4733  add rsp, 0xF0
00007cc2f47e473a  pop r11
00007cc2f47e473c  pop r10
00007cc2f47e473e  pop r9
00007cc2f47e4740  pop r8
00007cc2f47e4742  pop rsi
00007cc2f47e4743  pop rdi
00007cc2f47e4744  pop rdx
00007cc2f47e4745  pop rcx
00007cc2f47e4746  pop rax
00007cc2f47e4747  add rsp, 0x08
00007cc2f47e474b  jmp 0x00007CC2F47DF9C2
00007cc2f47e4750  sub rsp, 0x08
00007cc2f47e4754  push rax
00007cc2f47e4755  push rcx
00007cc2f47e4756  push rdx
00007cc2f47e4757  push rdi
00007cc2f47e4758  push rsi
00007cc2f47e4759  push r8
00007cc2f47e475b  push r9
00007cc2f47e475d  push r10
00007cc2f47e475f  push r11
00007cc2f47e4761  sub rsp, 0xF0
00007cc2f47e4768  vmovaps [rsp], xmm0
00007cc2f47e476d  vmovaps [rsp+0x10], xmm1
00007cc2f47e4773  vmovaps [rsp+0x20], xmm2
00007cc2f47e4779  vmovaps [rsp+0x30], xmm3
00007cc2f47e477f  vmovaps [rsp+0x40], xmm4
00007cc2f47e4785  vmovaps [rsp+0x50], xmm5
00007cc2f47e478b  vmovaps [rsp+0x60], xmm6
00007cc2f47e4791  vmovaps [rsp+0x70], xmm7
00007cc2f47e4797  vmovaps [rsp+0x80], xmm8
00007cc2f47e47a0  vmovaps [rsp+0x90], xmm9
00007cc2f47e47a9  vmovaps [rsp+0xA0], xmm10
00007cc2f47e47b2  vmovaps [rsp+0xB0], xmm11
00007cc2f47e47bb  vmovaps [rsp+0xC0], xmm12
00007cc2f47e47c4  vmovaps [rsp+0xD0], xmm13
00007cc2f47e47cd  vmovaps [rsp+0xE0], xmm14
00007cc2f47e47d6  sub rsp, 0x30
00007cc2f47e47da  movaps [rsp], xmm15
00007cc2f47e47df  movaps [rsp+0x10], xmm11
00007cc2f47e47e5  movaps [rsp+0x20], xmm12
00007cc2f47e47eb  lea rdi, [rsp]
00007cc2f47e47ef  mov esi, 0x00
00007cc2f47e47f4  mov rax, 0x5990E710A530
00007cc2f47e47fe  call rax
00007cc2f47e4800  movaps xmm15, [rsp]
00007cc2f47e4805  add rsp, 0x30
00007cc2f47e4809  vmovaps xmm0, [rsp]
00007cc2f47e480e  vmovaps xmm1, [rsp+0x10]
00007cc2f47e4814  vmovaps xmm2, [rsp+0x20]
00007cc2f47e481a  vmovaps xmm3, [rsp+0x30]
00007cc2f47e4820  vmovaps xmm4, [rsp+0x40]
00007cc2f47e4826  vmovaps xmm5, [rsp+0x50]
00007cc2f47e482c  vmovaps xmm6, [rsp+0x60]
00007cc2f47e4832  vmovaps xmm7, [rsp+0x70]
00007cc2f47e4838  vmovaps xmm8, [rsp+0x80]
00007cc2f47e4841  vmovaps xmm9, [rsp+0x90]
00007cc2f47e484a  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e4853  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e485c  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e4865  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e486e  vmovaps xmm14, [rsp+0xE0]
00007cc2f47e4877  add rsp, 0xF0
00007cc2f47e487e  pop r11
00007cc2f47e4880  pop r10
00007cc2f47e4882  pop r9
00007cc2f47e4884  pop r8
00007cc2f47e4886  pop rsi
00007cc2f47e4887  pop rdi
00007cc2f47e4888  pop rdx
00007cc2f47e4889  pop rcx
00007cc2f47e488a  pop rax
00007cc2f47e488b  add rsp, 0x08
00007cc2f47e488f  jmp 0x00007CC2F47DF9DD
00007cc2f47e4894  sub rsp, 0x08
00007cc2f47e4898  push rax
00007cc2f47e4899  push rcx
00007cc2f47e489a  push rdx
00007cc2f47e489b  push rdi
00007cc2f47e489c  push rsi
00007cc2f47e489d  push r8
00007cc2f47e489f  push r9
00007cc2f47e48a1  push r10
00007cc2f47e48a3  push r11
00007cc2f47e48a5  sub rsp, 0xF0
00007cc2f47e48ac  vmovaps [rsp], xmm0
00007cc2f47e48b1  vmovaps [rsp+0x10], xmm1
00007cc2f47e48b7  vmovaps [rsp+0x20], xmm2
00007cc2f47e48bd  vmovaps [rsp+0x30], xmm3
00007cc2f47e48c3  vmovaps [rsp+0x40], xmm4
00007cc2f47e48c9  vmovaps [rsp+0x50], xmm5
00007cc2f47e48cf  vmovaps [rsp+0x60], xmm6
00007cc2f47e48d5  vmovaps [rsp+0x70], xmm7
00007cc2f47e48db  vmovaps [rsp+0x80], xmm8
00007cc2f47e48e4  vmovaps [rsp+0x90], xmm9
00007cc2f47e48ed  vmovaps [rsp+0xA0], xmm10
00007cc2f47e48f6  vmovaps [rsp+0xB0], xmm11
00007cc2f47e48ff  vmovaps [rsp+0xC0], xmm12
00007cc2f47e4908  vmovaps [rsp+0xD0], xmm14
00007cc2f47e4911  vmovaps [rsp+0xE0], xmm15
00007cc2f47e491a  sub rsp, 0x30
00007cc2f47e491e  movaps [rsp], xmm13
00007cc2f47e4923  movaps [rsp+0x10], xmm10
00007cc2f47e4929  movaps [rsp+0x20], xmm14
00007cc2f47e492f  lea rdi, [rsp]
00007cc2f47e4933  mov esi, 0x00
00007cc2f47e4938  mov rax, 0x5990E710A530
00007cc2f47e4942  call rax
00007cc2f47e4944  movaps xmm13, [rsp]
00007cc2f47e4949  add rsp, 0x30
00007cc2f47e494d  vmovaps xmm0, [rsp]
00007cc2f47e4952  vmovaps xmm1, [rsp+0x10]
00007cc2f47e4958  vmovaps xmm2, [rsp+0x20]
00007cc2f47e495e  vmovaps xmm3, [rsp+0x30]
00007cc2f47e4964  vmovaps xmm4, [rsp+0x40]
00007cc2f47e496a  vmovaps xmm5, [rsp+0x50]
00007cc2f47e4970  vmovaps xmm6, [rsp+0x60]
00007cc2f47e4976  vmovaps xmm7, [rsp+0x70]
00007cc2f47e497c  vmovaps xmm8, [rsp+0x80]
00007cc2f47e4985  vmovaps xmm9, [rsp+0x90]
00007cc2f47e498e  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e4997  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e49a0  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e49a9  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e49b2  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e49bb  add rsp, 0xF0
00007cc2f47e49c2  pop r11
00007cc2f47e49c4  pop r10
00007cc2f47e49c6  pop r9
00007cc2f47e49c8  pop r8
00007cc2f47e49ca  pop rsi
00007cc2f47e49cb  pop rdi
00007cc2f47e49cc  pop rdx
00007cc2f47e49cd  pop rcx
00007cc2f47e49ce  pop rax
00007cc2f47e49cf  add rsp, 0x08
00007cc2f47e49d3  jmp 0x00007CC2F47DFA00
00007cc2f47e49d8  sub rsp, 0x08
00007cc2f47e49dc  push rax
00007cc2f47e49dd  push rcx
00007cc2f47e49de  push rdx
00007cc2f47e49df  push rdi
00007cc2f47e49e0  push rsi
00007cc2f47e49e1  push r8
00007cc2f47e49e3  push r9
00007cc2f47e49e5  push r10
00007cc2f47e49e7  push r11
00007cc2f47e49e9  sub rsp, 0xF0
00007cc2f47e49f0  vmovaps [rsp], xmm0
00007cc2f47e49f5  vmovaps [rsp+0x10], xmm1
00007cc2f47e49fb  vmovaps [rsp+0x20], xmm2
00007cc2f47e4a01  vmovaps [rsp+0x30], xmm3
00007cc2f47e4a07  vmovaps [rsp+0x40], xmm4
00007cc2f47e4a0d  vmovaps [rsp+0x50], xmm5
00007cc2f47e4a13  vmovaps [rsp+0x60], xmm6
00007cc2f47e4a19  vmovaps [rsp+0x70], xmm7
00007cc2f47e4a1f  vmovaps [rsp+0x80], xmm8
00007cc2f47e4a28  vmovaps [rsp+0x90], xmm9
00007cc2f47e4a31  vmovaps [rsp+0xA0], xmm10
00007cc2f47e4a3a  vmovaps [rsp+0xB0], xmm11
00007cc2f47e4a43  vmovaps [rsp+0xC0], xmm12
00007cc2f47e4a4c  vmovaps [rsp+0xD0], xmm13
00007cc2f47e4a55  vmovaps [rsp+0xE0], xmm15
00007cc2f47e4a5e  sub rsp, 0x30
00007cc2f47e4a62  movaps [rsp], xmm14
00007cc2f47e4a67  movaps [rsp+0x10], xmm1
00007cc2f47e4a6c  movaps [rsp+0x20], xmm7
00007cc2f47e4a71  lea rdi, [rsp]
00007cc2f47e4a75  mov esi, 0x00
00007cc2f47e4a7a  mov rax, 0x5990E710A530
00007cc2f47e4a84  call rax
00007cc2f47e4a86  movaps xmm14, [rsp]
00007cc2f47e4a8b  add rsp, 0x30
00007cc2f47e4a8f  vmovaps xmm0, [rsp]
00007cc2f47e4a94  vmovaps xmm1, [rsp+0x10]
00007cc2f47e4a9a  vmovaps xmm2, [rsp+0x20]
00007cc2f47e4aa0  vmovaps xmm3, [rsp+0x30]
00007cc2f47e4aa6  vmovaps xmm4, [rsp+0x40]
00007cc2f47e4aac  vmovaps xmm5, [rsp+0x50]
00007cc2f47e4ab2  vmovaps xmm6, [rsp+0x60]
00007cc2f47e4ab8  vmovaps xmm7, [rsp+0x70]
00007cc2f47e4abe  vmovaps xmm8, [rsp+0x80]
00007cc2f47e4ac7  vmovaps xmm9, [rsp+0x90]
00007cc2f47e4ad0  vmovaps xmm10, [rsp+0xA0]
00007cc2f47e4ad9  vmovaps xmm11, [rsp+0xB0]
00007cc2f47e4ae2  vmovaps xmm12, [rsp+0xC0]
00007cc2f47e4aeb  vmovaps xmm13, [rsp+0xD0]
00007cc2f47e4af4  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e4afd  add rsp, 0xF0
00007cc2f47e4b04  pop r11
00007cc2f47e4b06  pop r10
00007cc2f47e4b08  pop r9
00007cc2f47e4b0a  pop r8
00007cc2f47e4b0c  pop rsi
00007cc2f47e4b0d  pop rdi
00007cc2f47e4b0e  pop rdx
00007cc2f47e4b0f  pop rcx
00007cc2f47e4b10  pop rax
00007cc2f47e4b11  add rsp, 0x08
00007cc2f47e4b15  jmp 0x00007CC2F47DFA23
00007cc2f47e4b1a  sub rsp, 0x08
00007cc2f47e4b1e  push rax
00007cc2f47e4b1f  push rcx
00007cc2f47e4b20  push rdx
00007cc2f47e4b21  push rdi
00007cc2f47e4b22  push rsi
00007cc2f47e4b23  push r8
00007cc2f47e4b25  push r9
00007cc2f47e4b27  push r10
00007cc2f47e4b29  push r11
00007cc2f47e4b2b  sub rsp, 0xF0
00007cc2f47e4b32  vmovaps [rsp], xmm0
00007cc2f47e4b37  vmovaps [rsp+0x10], xmm2
00007cc2f47e4b3d  vmovaps [rsp+0x20], xmm3
00007cc2f47e4b43  vmovaps [rsp+0x30], xmm4
00007cc2f47e4b49  vmovaps [rsp+0x40], xmm5
00007cc2f47e4b4f  vmovaps [rsp+0x50], xmm6
00007cc2f47e4b55  vmovaps [rsp+0x60], xmm7
00007cc2f47e4b5b  vmovaps [rsp+0x70], xmm8
00007cc2f47e4b61  vmovaps [rsp+0x80], xmm9
00007cc2f47e4b6a  vmovaps [rsp+0x90], xmm10
00007cc2f47e4b73  vmovaps [rsp+0xA0], xmm11
00007cc2f47e4b7c  vmovaps [rsp+0xB0], xmm12
00007cc2f47e4b85  vmovaps [rsp+0xC0], xmm13
00007cc2f47e4b8e  vmovaps [rsp+0xD0], xmm14
00007cc2f47e4b97  vmovaps [rsp+0xE0], xmm15
00007cc2f47e4ba0  sub rsp, 0x30
00007cc2f47e4ba4  movaps [rsp], xmm1
00007cc2f47e4ba8  movaps [rsp+0x10], xmm8
00007cc2f47e4bae  movaps [rsp+0x20], xmm9
00007cc2f47e4bb4  lea rdi, [rsp]
00007cc2f47e4bb8  mov esi, 0x00
00007cc2f47e4bbd  mov rax, 0x5990E710A530
00007cc2f47e4bc7  call rax
00007cc2f47e4bc9  movaps xmm1, [rsp]
00007cc2f47e4bcd  add rsp, 0x30
00007cc2f47e4bd1  vmovaps xmm0, [rsp]
00007cc2f47e4bd6  vmovaps xmm2, [rsp+0x10]
00007cc2f47e4bdc  vmovaps xmm3, [rsp+0x20]
00007cc2f47e4be2  vmovaps xmm4, [rsp+0x30]
00007cc2f47e4be8  vmovaps xmm5, [rsp+0x40]
00007cc2f47e4bee  vmovaps xmm6, [rsp+0x50]
00007cc2f47e4bf4  vmovaps xmm7, [rsp+0x60]
00007cc2f47e4bfa  vmovaps xmm8, [rsp+0x70]
00007cc2f47e4c00  vmovaps xmm9, [rsp+0x80]
00007cc2f47e4c09  vmovaps xmm10, [rsp+0x90]
00007cc2f47e4c12  vmovaps xmm11, [rsp+0xA0]
00007cc2f47e4c1b  vmovaps xmm12, [rsp+0xB0]
00007cc2f47e4c24  vmovaps xmm13, [rsp+0xC0]
00007cc2f47e4c2d  vmovaps xmm14, [rsp+0xD0]
00007cc2f47e4c36  vmovaps xmm15, [rsp+0xE0]
00007cc2f47e4c3f  add rsp, 0xF0
00007cc2f47e4c46  pop r11
00007cc2f47e4c48  pop r10
00007cc2f47e4c4a  pop r9
00007cc2f47e4c4c  pop r8
00007cc2f47e4c4e  pop rsi
00007cc2f47e4c4f  pop rdi
00007cc2f47e4c50  pop rdx
00007cc2f47e4c51  pop rcx
00007cc2f47e4c52  pop rax
00007cc2f47e4c53  add rsp, 0x08
00007cc2f47e4c57  jmp 0x00007CC2F47DFA45
00007cc2f47e4c5c  call 0x00007CC2F46E5940
00007cc2f47e4c61  jmp 0x00007CC2F47DFA53
00007cc2f47e4c66  call 0x00007CC2F460C380
00007cc2f47e4c6b  jmp 0x00007CC2F47DFA5D
00007cc2f47e4c70  call 0x00007CC2F460D600
00007cc2f47e4c75  jmp 0x00007CC2F47DFA67
00007cc2f47e4c7a  call 0x00007CC2F45FF540
00007cc2f47e4c7f  jmp 0x00007CC2F47DFA71
00007cc2f47e4c84  int3
00007cc2f47e4c85  nop [rax+rax*1], ax
00007cc2f47e4c8e  nop
00007cc2f47e4c90  mov qword ptr [r15+0x40], 0x430000
00007cc2f47e4c98  mov eax, 0x430CC0
00007cc2f47e4c9d  mov r14, [r13+rax*1]
00007cc2f47e4ca2  movq xmm1, r14
00007cc2f47e4ca7  mov rax, [r15+0x50]
00007cc2f47e4cab  movups xmm15, [r13+rax*1]
00007cc2f47e4cb1  movaps [r15+0x120], xmm15
00007cc2f47e4cb9  mov qword ptr [r15+0x48], 0x10
00007cc2f47e4cc1  xor eax, eax
00007cc2f47e4cc3  mov r14d, 0x10
00007cc2f47e4cc9  mov r12d, 0x200
00007cc2f47e4ccf  cmp r14, r12
00007cc2f47e4cd2  cmc
00007cc2f47e4cd3  lahf
00007cc2f47e4cd4  seto al
00007cc2f47e4cd7  mov [r15+0x108], eax
00007cc2f47e4cde  pextrq rax, xmm15, 0x01
00007cc2f47e4ce5  movq xmm14, rax
00007cc2f47e4cea  movaps [r15+0x130], xmm14
00007cc2f47e4cf2  movq rax, xmm1
00007cc2f47e4cf7  movq r14, xmm15
00007cc2f47e4cfc  vmovq xmm1, rax
00007cc2f47e4d01  vmovq xmm15, r14
00007cc2f47e4d06  movaps xmm13, xmm1
00007cc2f47e4d0a  addsd xmm13, xmm15
00007cc2f47e4d0f  ucomisd xmm13, xmm13
00007cc2f47e4d14  jp 0x00007CC2F47E4DD3
00007cc2f47e4d1a  movq xmm13, xmm13
00007cc2f47e4d1f  movq rax, xmm13
00007cc2f47e4d24  movq r14, xmm14
00007cc2f47e4d29  vmovq xmm1, rax
00007cc2f47e4d2e  vmovq xmm15, r14
00007cc2f47e4d33  movaps xmm14, xmm1
00007cc2f47e4d37  addsd xmm14, xmm15
00007cc2f47e4d3c  ucomisd xmm14, xmm14
00007cc2f47e4d41  jp 0x00007CC2F47E4E1B
00007cc2f47e4d47  movq xmm14, xmm14
00007cc2f47e4d4c  movaps [r15+0x110], xmm14
00007cc2f47e4d54  mov eax, [r15+0x108]
00007cc2f47e4d5b  sahf
00007cc2f47e4d5c  jnz 0x00007CC2F47E4D8E
00007cc2f47e4d5e  cmp dword ptr [r15+0x318], 0x00
00007cc2f47e4d66  jz 0x00007CC2F47E5030
00007cc2f47e4d6c  nop [rax+rax*1], ax
00007cc2f47e4d75  nop [rax+rax*1], eax
00007cc2f47e4d7d  mov eax, 0x410704
00007cc2f47e4d82  mov [r15+0x100], rax
00007cc2f47e4d89  jmp 0x00007CC2F45FE110
00007cc2f47e4d8e  cmp dword ptr [r15+0x318], 0x00
00007cc2f47e4d96  jz 0x00007CC2F47E4E70
00007cc2f47e4d9c  nop [rax+rax*1], ax
00007cc2f47e4da5  nop [rax+rax*1], eax
00007cc2f47e4dad  mov eax, 0x4106E8
00007cc2f47e4db2  mov [r15+0x100], rax
00007cc2f47e4db9  jmp 0x00007CC2F45FE110
00007cc2f47e4dbe  int3
00007cc2f47e4dbf  call 0x00007CC2F460DC20
00007cc2f47e4dc4  jmp 0x00007CC2F47E4CA2
00007cc2f47e4dc9  call 0x00007CC2F460E760
00007cc2f47e4dce  jmp 0x00007CC2F47E4CB1
00007cc2f47e4dd3  ucomisd xmm1, xmm15
00007cc2f47e4dd8  jp 0x00007CC2F47E4DE7
00007cc2f47e4dda  movaps xmm13, [0x00007CC2F43FE060]
00007cc2f47e4de2  jmp 0x00007CC2F47E4D1A
00007cc2f47e4de7  vxorps xmm0, xmm1, xmm15
00007cc2f47e4dec  pextrw eax, xmm0, 0x03
00007cc2f47e4df1  and eax, 0x7FF8
00007cc2f47e4df6  cmp eax, 0x08
00007cc2f47e4df9  jnz 0x00007CC2F47E4D1A
00007cc2f47e4dff  movq rax, xmm15
00007cc2f47e4e04  shl rax, 0x0D
00007cc2f47e4e08  jbe 0x00007CC2F47E4D1A
00007cc2f47e4e0e  vorps xmm13, xmm15, [0x00007CC2F43FE070]
00007cc2f47e4e16  jmp 0x00007CC2F47E4D1A
00007cc2f47e4e1b  ucomisd xmm1, xmm15
00007cc2f47e4e20  jp 0x00007CC2F47E4E2F
00007cc2f47e4e22  movaps xmm14, [0x00007CC2F43FE060]
00007cc2f47e4e2a  jmp 0x00007CC2F47E4D47
00007cc2f47e4e2f  vxorps xmm0, xmm1, xmm15
00007cc2f47e4e34  pextrw eax, xmm0, 0x03
00007cc2f47e4e39  and eax, 0x7FF8
00007cc2f47e4e3e  cmp eax, 0x08
00007cc2f47e4e41  jnz 0x00007CC2F47E4D47
00007cc2f47e4e47  movq rax, xmm15
00007cc2f47e4e4c  shl rax, 0x0D
00007cc2f47e4e50  jbe 0x00007CC2F47E4D47
00007cc2f47e4e56  vorps xmm14, xmm15, [0x00007CC2F43FE070]
00007cc2f47e4e5e  jmp 0x00007CC2F47E4D47
00007cc2f47e4e63  int3
00007cc2f47e4e64  nop [rax+rax*1], ax
00007cc2f47e4e6d  nop [rax], eax
00007cc2f47e4e70  mov rax, [r15+0x48]
00007cc2f47e4e74  mov r14, [r15+0x50]
00007cc2f47e4e78  lea r12, [r14+rax*1]
00007cc2f47e4e7c  movups xmm1, [r13+r12*1]
00007cc2f47e4e82  movaps [r15+0x120], xmm1
00007cc2f47e4e8a  lea r14, [rax+0x10]
00007cc2f47e4e8e  mov [r15+0x48], r14
00007cc2f47e4e92  xor eax, eax
00007cc2f47e4e94  mov r12d, 0x200
00007cc2f47e4e9a  cmp r14, r12
00007cc2f47e4e9d  cmc
00007cc2f47e4e9e  lahf
00007cc2f47e4e9f  seto al
00007cc2f47e4ea2  mov [r15+0x108], eax
00007cc2f47e4ea9  pextrq rax, xmm1, 0x01
00007cc2f47e4eb0  movq xmm15, rax
00007cc2f47e4eb5  movaps [r15+0x130], xmm15
00007cc2f47e4ebd  movaps xmm14, [r15+0x110]
00007cc2f47e4ec5  movq rax, xmm14
00007cc2f47e4eca  movq r14, xmm1
00007cc2f47e4ecf  vmovq xmm1, rax
00007cc2f47e4ed4  vmovq xmm14, r14
00007cc2f47e4ed9  movaps xmm13, xmm1
00007cc2f47e4edd  addsd xmm13, xmm14
00007cc2f47e4ee2  ucomisd xmm13, xmm13
00007cc2f47e4ee7  jp 0x00007CC2F47E4F9C
00007cc2f47e4eed  movq xmm13, xmm13
00007cc2f47e4ef2  movq rax, xmm13
00007cc2f47e4ef7  movq r14, xmm15
00007cc2f47e4efc  vmovq xmm1, rax
00007cc2f47e4f01  vmovq xmm15, r14
00007cc2f47e4f06  movaps xmm14, xmm1
00007cc2f47e4f0a  addsd xmm14, xmm15
00007cc2f47e4f0f  ucomisd xmm14, xmm14
00007cc2f47e4f14  jp 0x00007CC2F47E4FE4
00007cc2f47e4f1a  movq xmm14, xmm14
00007cc2f47e4f1f  movaps [r15+0x110], xmm14
00007cc2f47e4f27  mov eax, [r15+0x108]
00007cc2f47e4f2e  sahf
00007cc2f47e4f2f  jnz 0x00007CC2F47E4F61
00007cc2f47e4f31  cmp dword ptr [r15+0x318], 0x00
00007cc2f47e4f39  jz 0x00007CC2F47E5030
00007cc2f47e4f3f  nop [rax+rax*1], ax
00007cc2f47e4f48  nop [rax+rax*1], eax
00007cc2f47e4f50  mov eax, 0x410704
00007cc2f47e4f55  mov [r15+0x100], rax
00007cc2f47e4f5c  jmp 0x00007CC2F45FE110
00007cc2f47e4f61  cmp dword ptr [r15+0x318], 0x00
00007cc2f47e4f69  jz 0x00007CC2F47E4E70
00007cc2f47e4f6f  nop [rax+rax*1], ax
00007cc2f47e4f78  nop [rax+rax*1], eax
00007cc2f47e4f80  mov eax, 0x4106E8
00007cc2f47e4f85  mov [r15+0x100], rax
00007cc2f47e4f8c  jmp 0x00007CC2F45FE110
00007cc2f47e4f91  int3
00007cc2f47e4f92  call 0x00007CC2F46B52F0
00007cc2f47e4f97  jmp 0x00007CC2F47E4E82
00007cc2f47e4f9c  ucomisd xmm1, xmm14
00007cc2f47e4fa1  jp 0x00007CC2F47E4FB0
00007cc2f47e4fa3  movaps xmm13, [0x00007CC2F43FE060]
00007cc2f47e4fab  jmp 0x00007CC2F47E4EED
00007cc2f47e4fb0  vxorps xmm0, xmm1, xmm14
00007cc2f47e4fb5  pextrw eax, xmm0, 0x03
00007cc2f47e4fba  and eax, 0x7FF8
00007cc2f47e4fbf  cmp eax, 0x08
00007cc2f47e4fc2  jnz 0x00007CC2F47E4EED
00007cc2f47e4fc8  movq rax, xmm14
00007cc2f47e4fcd  shl rax, 0x0D
00007cc2f47e4fd1  jbe 0x00007CC2F47E4EED
00007cc2f47e4fd7  vorps xmm13, xmm14, [0x00007CC2F43FE070]
00007cc2f47e4fdf  jmp 0x00007CC2F47E4EED
00007cc2f47e4fe4  ucomisd xmm1, xmm15
00007cc2f47e4fe9  jp 0x00007CC2F47E4FF8
00007cc2f47e4feb  movaps xmm14, [0x00007CC2F43FE060]
00007cc2f47e4ff3  jmp 0x00007CC2F47E4F1A
00007cc2f47e4ff8  vxorps xmm0, xmm1, xmm15
00007cc2f47e4ffd  pextrw eax, xmm0, 0x03
00007cc2f47e5002  and eax, 0x7FF8
00007cc2f47e5007  cmp eax, 0x08
00007cc2f47e500a  jnz 0x00007CC2F47E4F1A
00007cc2f47e5010  movq rax, xmm15
00007cc2f47e5015  shl rax, 0x0D
00007cc2f47e5019  jbe 0x00007CC2F47E4F1A
00007cc2f47e501f  vorps xmm14, xmm15, [0x00007CC2F43FE070]
00007cc2f47e5027  jmp 0x00007CC2F47E4F1A
00007cc2f47e502c  int3
00007cc2f47e502d  nop [rax], eax
00007cc2f47e5030  mov rax, [r15+0xF8]
00007cc2f47e5037  lea r14, [rax+0x1D0]
00007cc2f47e503e  mov r12, [r13+r14*1]
00007cc2f47e5043  lea r14, [rax+0x1D8]
00007cc2f47e504a  mov r11, [r13+r14*1]
00007cc2f47e504f  mov [r15+0xA0], r12
00007cc2f47e5056  mov [r15+0x98], r11
00007cc2f47e505d  mov r14, [r15+0x40]
00007cc2f47e5061  lea r12, [r14+0xCC0]
00007cc2f47e5068  movaps xmm1, [r15+0x110]
00007cc2f47e5070  movq r14, xmm1
00007cc2f47e5075  mov [r13+r12*1], r14
00007cc2f47e507a  lea r14, [rax+0x1C0]
00007cc2f47e5081  mov r12, [r13+r14*1]
00007cc2f47e5086  lea r14, [rax+0x1C8]
00007cc2f47e508d  mov r11, [r13+r14*1]
00007cc2f47e5092  mov [r15+0xE8], r12
00007cc2f47e5099  mov [r15+0xF0], r11
00007cc2f47e50a0  lea r14, [rax+0x1B0]
00007cc2f47e50a7  mov r12, [r13+r14*1]
00007cc2f47e50ac  lea r14, [rax+0x1B8]
00007cc2f47e50b3  mov r10, [r13+r14*1]
00007cc2f47e50b8  movq xmm1, r12
00007cc2f47e50bd  movq xmm15, r10
00007cc2f47e50c2  movq xmm1, xmm1
00007cc2f47e50c6  movq xmm1, xmm1
00007cc2f47e50ca  movaps [r15+0x1A0], xmm1
00007cc2f47e50d2  movq xmm15, xmm15
00007cc2f47e50d7  movq xmm15, xmm15
00007cc2f47e50dc  movaps [r15+0x190], xmm15
00007cc2f47e50e4  lea r14, [rax+0x1A0]
00007cc2f47e50eb  mov r12, [r13+r14*1]
00007cc2f47e50f0  lea r14, [rax+0x1A8]
00007cc2f47e50f7  mov r10, [r13+r14*1]
00007cc2f47e50fc  movq xmm1, r12
00007cc2f47e5101  movq xmm15, r10
00007cc2f47e5106  movq xmm1, xmm1
00007cc2f47e510a  movq xmm1, xmm1
00007cc2f47e510e  movaps [r15+0x1C0], xmm1
00007cc2f47e5116  movq xmm15, xmm15
00007cc2f47e511b  movq xmm15, xmm15
00007cc2f47e5120  movaps [r15+0x1B0], xmm15
00007cc2f47e5128  lea r14, [rax+0x190]
00007cc2f47e512f  mov r12, [r13+r14*1]
00007cc2f47e5134  lea r14, [rax+0x198]
00007cc2f47e513b  mov r10, [r13+r14*1]
00007cc2f47e5140  movq xmm1, r12
00007cc2f47e5145  movq xmm15, r10
00007cc2f47e514a  movq xmm1, xmm1
00007cc2f47e514e  movq xmm1, xmm1
00007cc2f47e5152  movaps [r15+0x1E0], xmm1
00007cc2f47e515a  movq xmm15, xmm15
00007cc2f47e515f  movq xmm15, xmm15
00007cc2f47e5164  movaps [r15+0x1D0], xmm15
00007cc2f47e516c  lea r14, [rax+0x180]
00007cc2f47e5173  mov r12, [r13+r14*1]
00007cc2f47e5178  lea r14, [rax+0x188]
00007cc2f47e517f  mov r10, [r13+r14*1]
00007cc2f47e5184  movq xmm1, r12
00007cc2f47e5189  movq xmm15, r10
00007cc2f47e518e  movq xmm1, xmm1
00007cc2f47e5192  movq xmm1, xmm1
00007cc2f47e5196  movaps [r15+0x200], xmm1
00007cc2f47e519e  movq xmm15, xmm15
00007cc2f47e51a3  movq xmm15, xmm15
00007cc2f47e51a8  movaps [r15+0x1F0], xmm15
00007cc2f47e51b0  lea r14, [rax+0x1E0]
00007cc2f47e51b7  mov [r15+0xF8], r14
00007cc2f47e51be  mov [r15+0x100], r11
00007cc2f47e51c5  jmp 0x00007CC2F47CE5C0
00007cc2f47e51ca  int3
00007cc2f47e51cb  call 0x00007CC2F46E27E0
00007cc2f47e51d0  jmp 0x00007CC2F47E5043
00007cc2f47e51d5  call 0x00007CC2F46E1570
00007cc2f47e51da  jmp 0x00007CC2F47E504F
00007cc2f47e51df  call 0x00007CC2F46C3FE0
00007cc2f47e51e4  jmp 0x00007CC2F47E507A
00007cc2f47e51e9  call 0x00007CC2F46E27E0
00007cc2f47e51ee  jmp 0x00007CC2F47E5086
00007cc2f47e51f3  call 0x00007CC2F46E1570
00007cc2f47e51f8  jmp 0x00007CC2F47E5092
00007cc2f47e51fd  call 0x00007CC2F46E27E0
00007cc2f47e5202  jmp 0x00007CC2F47E50AC
00007cc2f47e5207  call 0x00007CC2F46E0300
00007cc2f47e520c  jmp 0x00007CC2F47E50B8
00007cc2f47e5211  call 0x00007CC2F46E27E0
00007cc2f47e5216  jmp 0x00007CC2F47E50F0
00007cc2f47e521b  call 0x00007CC2F46E0300
00007cc2f47e5220  jmp 0x00007CC2F47E50FC
00007cc2f47e5225  call 0x00007CC2F46E27E0
00007cc2f47e522a  jmp 0x00007CC2F47E5134
00007cc2f47e522f  call 0x00007CC2F46E0300
00007cc2f47e5234  jmp 0x00007CC2F47E5140
00007cc2f47e5239  call 0x00007CC2F46E27E0
00007cc2f47e523e  jmp 0x00007CC2F47E5178
00007cc2f47e5243  call 0x00007CC2F46E0300
00007cc2f47e5248  jmp 0x00007CC2F47E5184
00007cc2f47e524d  int3
00007cc2f47e524e  nop
00007cc2f47e5250  mov qword ptr [r15+0x100], 0x04
00007cc2f47e525b  mov esi, 0x00
00007cc2f47e5260  mov edx, 0x09
00007cc2f47e5265  mov rdi, 0x7FFED8579C10
00007cc2f47e526f  mov rax, 0x5990E6F9D970
00007cc2f47e5279  call rax
00007cc2f47e527b  cmp dword ptr [r15+0x318], 0x00
00007cc2f47e5283  jnz 0x00007CC2F45FE110
00007cc2f47e5289  jmp 0x00007CC2F45FE0A0
00007cc2f47e528e  int3
00007cc2f47e528f  int3
