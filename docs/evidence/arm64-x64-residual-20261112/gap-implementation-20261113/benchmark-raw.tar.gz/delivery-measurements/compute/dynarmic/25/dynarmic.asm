00007d516e5ce69b  nop [rax+rax*1], eax
00007d516e5ce6a0  mov rax, [r15+0xF8]
00007d516e5ce6a7  lea r14, [rax-0x1E0]
00007d516e5ce6ae  mov [r15+0xF8], r14
00007d516e5ce6b5  lea rax, [r14+0x1D0]
00007d516e5ce6bc  mov r12, [r15+0xA0]
00007d516e5ce6c3  mov r11, [r15+0x98]
00007d516e5ce6ca  mov [r13+rax*1], r12
00007d516e5ce6cf  lea rax, [r14+0x1D8]
00007d516e5ce6d6  mov [r13+rax*1], r11
00007d516e5ce6db  mov eax, 0x420AA0
00007d516e5ce6e0  movups xmm1, [r13+rax*1]
00007d516e5ce6e6  mov eax, 0x420A30
00007d516e5ce6eb  movups xmm15, [r13+rax*1]
00007d516e5ce6f1  mov eax, 0x420AC0
00007d516e5ce6f6  movups xmm14, [r13+rax*1]
00007d516e5ce6fc  mov eax, 0x420A60
00007d516e5ce701  movups xmm13, [r13+rax*1]
00007d516e5ce707  mov qword ptr [r15+0x98], 0x430CD0
00007d516e5ce712  mov eax, 0x420AD0
00007d516e5ce717  movups xmm12, [r13+rax*1]
00007d516e5ce71d  mov eax, 0x430CD0
00007d516e5ce722  movups [r13+rax*1], xmm1
00007d516e5ce728  mov eax, 0x430CE0
00007d516e5ce72d  movups [r13+rax*1], xmm15
00007d516e5ce733  mov eax, 0x430CF0
00007d516e5ce738  movups [r13+rax*1], xmm14
00007d516e5ce73e  mov eax, 0x430D00
00007d516e5ce743  movups [r13+rax*1], xmm13
00007d516e5ce749  mov eax, 0x420A20
00007d516e5ce74e  movups xmm14, [r13+rax*1]
00007d516e5ce754  mov eax, 0x420A10
00007d516e5ce759  movups xmm13, [r13+rax*1]
00007d516e5ce75f  mov eax, 0x430DD0
00007d516e5ce764  movups [r13+rax*1], xmm1
00007d516e5ce76a  mov eax, 0x430DE0
00007d516e5ce76f  movups [r13+rax*1], xmm15
00007d516e5ce775  mov eax, 0x430D10
00007d516e5ce77a  movups [r13+rax*1], xmm12
00007d516e5ce780  mov eax, 0x430D20
00007d516e5ce785  movups [r13+rax*1], xmm14
00007d516e5ce78b  mov eax, 0x420A00
00007d516e5ce790  movups xmm1, [r13+rax*1]
00007d516e5ce796  mov eax, 0x420A70
00007d516e5ce79b  movups xmm15, [r13+rax*1]
00007d516e5ce7a1  mov eax, 0x430D30
00007d516e5ce7a6  movups [r13+rax*1], xmm13
00007d516e5ce7ac  mov eax, 0x430D40
00007d516e5ce7b1  movups [r13+rax*1], xmm1
00007d516e5ce7b7  mov eax, 0x420A80
00007d516e5ce7bc  movups xmm1, [r13+rax*1]
00007d516e5ce7c2  mov eax, 0x420A50
00007d516e5ce7c7  movups xmm14, [r13+rax*1]
00007d516e5ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007d516e5ce7d5  mov eax, 0x430D50
00007d516e5ce7da  movups [r13+rax*1], xmm15
00007d516e5ce7e0  mov eax, 0x430D60
00007d516e5ce7e5  movups [r13+rax*1], xmm1
00007d516e5ce7eb  mov eax, 0x420AF0
00007d516e5ce7f0  movups xmm1, [r13+rax*1]
00007d516e5ce7f6  mov eax, 0x420B00
00007d516e5ce7fb  movups xmm15, [r13+rax*1]
00007d516e5ce801  movaps [r15+0x150], xmm15
00007d516e5ce809  mov qword ptr [r15+0xA0], 0x3E8
00007d516e5ce814  mov eax, 0x430D70
00007d516e5ce819  movups [r13+rax*1], xmm14
00007d516e5ce81f  mov eax, 0x430D80
00007d516e5ce824  movups [r13+rax*1], xmm1
00007d516e5ce82a  mov eax, 0x420AE0
00007d516e5ce82f  movups xmm1, [r13+rax*1]
00007d516e5ce835  mov eax, 0x420A90
00007d516e5ce83a  movups xmm14, [r13+rax*1]
00007d516e5ce840  movaps [r15+0x140], xmm14
00007d516e5ce848  lea rax, [r14+0x180]
00007d516e5ce84f  movq xmm13, qword ptr [r15+0x200]
00007d516e5ce858  movq xmm12, qword ptr [r15+0x1F0]
00007d516e5ce861  movq r12, xmm13
00007d516e5ce866  movq r11, xmm12
00007d516e5ce86b  mov [r13+rax*1], r12
00007d516e5ce870  lea rax, [r14+0x188]
00007d516e5ce877  mov [r13+rax*1], r11
00007d516e5ce87c  mov eax, 0x430D90
00007d516e5ce881  movups [r13+rax*1], xmm15
00007d516e5ce887  mov eax, 0x430DA0
00007d516e5ce88c  movups [r13+rax*1], xmm1
00007d516e5ce892  mov eax, 0x420AB0
00007d516e5ce897  movups xmm1, [r13+rax*1]
00007d516e5ce89d  mov eax, 0x420B18
00007d516e5ce8a2  mov r12, [r13+rax*1]
00007d516e5ce8a7  movq xmm15, r12
00007d516e5ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007d516e5ce8b4  mov eax, 0x430DB0
00007d516e5ce8b9  movups [r13+rax*1], xmm14
00007d516e5ce8bf  mov eax, 0x430DC0
00007d516e5ce8c4  movups [r13+rax*1], xmm1
00007d516e5ce8ca  mov eax, 0x420B80
00007d516e5ce8cf  movups xmm1, [r13+rax*1]
00007d516e5ce8d5  movq rax, xmm15
00007d516e5ce8da  mov r12d, 0x430DF0
00007d516e5ce8e0  mov [r13+r12*1], rax
00007d516e5ce8e5  mov eax, 0x420B60
00007d516e5ce8ea  movups xmm15, [r13+rax*1]
00007d516e5ce8f0  mov eax, 0x420B70
00007d516e5ce8f5  movups xmm14, [r13+rax*1]
00007d516e5ce8fb  lea rax, [r14+0x160]
00007d516e5ce902  movups [r13+rax*1], xmm1
00007d516e5ce908  lea rax, [r14+0x190]
00007d516e5ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007d516e5ce918  movq xmm13, qword ptr [r15+0x1D0]
00007d516e5ce921  movq r12, xmm1
00007d516e5ce926  movq r11, xmm13
00007d516e5ce92b  mov [r13+rax*1], r12
00007d516e5ce930  lea rax, [r14+0x198]
00007d516e5ce937  mov [r13+rax*1], r11
00007d516e5ce93c  lea rax, [r14+0x140]
00007d516e5ce943  movups [r13+rax*1], xmm15
00007d516e5ce949  lea rax, [r14+0x150]
00007d516e5ce950  movups [r13+rax*1], xmm14
00007d516e5ce956  mov eax, 0x420B20
00007d516e5ce95b  movups xmm1, [r13+rax*1]
00007d516e5ce961  mov eax, 0x420B30
00007d516e5ce966  movups xmm15, [r13+rax*1]
00007d516e5ce96c  movaps [r15+0x120], xmm15
00007d516e5ce974  lea rax, [r14+0x1A0]
00007d516e5ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007d516e5ce984  movq xmm13, qword ptr [r15+0x1B0]
00007d516e5ce98d  movq r12, xmm14
00007d516e5ce992  movq r11, xmm13
00007d516e5ce997  mov [r13+rax*1], r12
00007d516e5ce99c  lea rax, [r14+0x1A8]
00007d516e5ce9a3  mov [r13+rax*1], r11
00007d516e5ce9a8  lea rax, [r14+0x1B0]
00007d516e5ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007d516e5ce9b8  movq xmm13, qword ptr [r15+0x190]
00007d516e5ce9c1  movq r12, xmm14
00007d516e5ce9c6  movq r11, xmm13
00007d516e5ce9cb  mov [r13+rax*1], r12
00007d516e5ce9d0  lea rax, [r14+0x1B8]
00007d516e5ce9d7  mov [r13+rax*1], r11
00007d516e5ce9dc  lea rax, [r14+0x100]
00007d516e5ce9e3  movups [r13+rax*1], xmm1
00007d516e5ce9e9  lea rax, [r14+0x110]
00007d516e5ce9f0  movups [r13+rax*1], xmm15
00007d516e5ce9f6  mov eax, 0x420B40
00007d516e5ce9fb  movups xmm1, [r13+rax*1]
00007d516e5cea01  mov eax, 0x420B50
00007d516e5cea06  movups xmm15, [r13+rax*1]
00007d516e5cea0c  movaps [r15+0x110], xmm1
00007d516e5cea14  movaps [r15+0x130], xmm15
00007d516e5cea1c  lea rax, [r14+0x1C0]
00007d516e5cea23  mov r12, [r15+0xE8]
00007d516e5cea2a  mov r11, [r15+0xF0]
00007d516e5cea31  mov [r13+rax*1], r12
00007d516e5cea36  lea rax, [r14+0x1C8]
00007d516e5cea3d  mov [r13+rax*1], r11
00007d516e5cea42  mov eax, 0x430DF8
00007d516e5cea47  mov r12d, 0x421DF8D3
00007d516e5cea4d  mov [r13+rax*1], r12d
00007d516e5cea52  lea rax, [r14+0x120]
00007d516e5cea59  movups [r13+rax*1], xmm1
00007d516e5cea5f  lea rax, [r14+0x130]
00007d516e5cea66  movups [r13+rax*1], xmm15
00007d516e5cea6c  lea rax, [r14+0x100]
00007d516e5cea73  mov [r15], rax
00007d516e5cea76  mov qword ptr [r15+0x08], 0x430CD0
00007d516e5cea7e  mov qword ptr [r15+0x10], 0x12C
00007d516e5cea86  mov qword ptr [r15+0xF0], 0x410284
00007d516e5cea91  mov r14d, [r15+0x320]
00007d516e5cea98  mov eax, 0x410284
00007d516e5cea9d  mov rcx, 0x7D516E5D07C0
00007d516e5ceaa7  mov [r15+r14*8+0x328], rax
00007d516e5ceaaf  mov [r15+r14*8+0x368], rcx
00007d516e5ceab7  add r14d, 0x01
00007d516e5ceabb  and r14d, 0x07
00007d516e5ceabf  mov [r15+0x320], r14d
00007d516e5ceac6  cmp dword ptr [r15+0x318], 0x00
00007d516e5ceace  jz 0x00007D516E5CED70
00007d516e5cead4  nop [rax+rax*1], ax
00007d516e5ceadd  nop [rax+rax*1], eax
00007d516e5ceae5  mov eax, 0x410728
00007d516e5ceaea  mov [r15+0x100], rax
00007d516e5ceaf1  jmp 0x00007D516E3FE110
00007d516e5ceaf6  int3
00007d516e5ceaf7  call 0x00007D516E40BC20
00007d516e5ceafc  jmp 0x00007D516E5CE6CF
00007d516e5ceb01  call 0x00007D516E40A9A0
00007d516e5ceb06  jmp 0x00007D516E5CE6DB
00007d516e5ceb0b  call 0x00007D516E3FF430
00007d516e5ceb10  jmp 0x00007D516E5CE6E6
00007d516e5ceb15  call 0x00007D516E40E760
00007d516e5ceb1a  jmp 0x00007D516E5CE6F1
00007d516e5ceb1f  call 0x00007D516E40D4E0
00007d516e5ceb24  jmp 0x00007D516E5CE6FC
00007d516e5ceb29  call 0x00007D516E40C260
00007d516e5ceb2e  jmp 0x00007D516E5CE707
00007d516e5ceb33  call 0x00007D516E40AFE0
00007d516e5ceb38  jmp 0x00007D516E5CE71D
00007d516e5ceb3d  call 0x00007D516E3FF540
00007d516e5ceb42  jmp 0x00007D516E5CE728
00007d516e5ceb47  call 0x00007D516E40E880
00007d516e5ceb4c  jmp 0x00007D516E5CE733
00007d516e5ceb51  call 0x00007D516E40D600
00007d516e5ceb56  jmp 0x00007D516E5CE73E
00007d516e5ceb5b  call 0x00007D516E40C380
00007d516e5ceb60  jmp 0x00007D516E5CE749
00007d516e5ceb65  call 0x00007D516E40D4E0
00007d516e5ceb6a  jmp 0x00007D516E5CE754
00007d516e5ceb6f  call 0x00007D516E40C260
00007d516e5ceb74  jmp 0x00007D516E5CE75F
00007d516e5ceb79  call 0x00007D516E3FF540
00007d516e5ceb7e  jmp 0x00007D516E5CE76A
00007d516e5ceb83  call 0x00007D516E40E880
00007d516e5ceb88  jmp 0x00007D516E5CE775
00007d516e5ceb8d  call 0x00007D516E40B100
00007d516e5ceb92  jmp 0x00007D516E5CE780
00007d516e5ceb97  call 0x00007D516E40D600
00007d516e5ceb9c  jmp 0x00007D516E5CE78B
00007d516e5ceba1  call 0x00007D516E3FF430
00007d516e5ceba6  jmp 0x00007D516E5CE796
00007d516e5cebab  call 0x00007D516E40E760
00007d516e5cebb0  jmp 0x00007D516E5CE7A1
00007d516e5cebb5  call 0x00007D516E40C380
00007d516e5cebba  jmp 0x00007D516E5CE7AC
00007d516e5cebbf  call 0x00007D516E3FF540
00007d516e5cebc4  jmp 0x00007D516E5CE7B7
00007d516e5cebc9  call 0x00007D516E3FF430
00007d516e5cebce  jmp 0x00007D516E5CE7C2
00007d516e5cebd3  call 0x00007D516E40D4E0
00007d516e5cebd8  jmp 0x00007D516E5CE7CD
00007d516e5cebdd  call 0x00007D516E40E880
00007d516e5cebe2  jmp 0x00007D516E5CE7E0
00007d516e5cebe7  call 0x00007D516E3FF540
00007d516e5cebec  jmp 0x00007D516E5CE7EB
00007d516e5cebf1  call 0x00007D516E3FF430
00007d516e5cebf6  jmp 0x00007D516E5CE7F6
00007d516e5cebfb  call 0x00007D516E40E760
00007d516e5cec00  jmp 0x00007D516E5CE801
00007d516e5cec05  call 0x00007D516E40D600
00007d516e5cec0a  jmp 0x00007D516E5CE81F
00007d516e5cec0f  call 0x00007D516E3FF540
00007d516e5cec14  jmp 0x00007D516E5CE82A
00007d516e5cec19  call 0x00007D516E3FF430
00007d516e5cec1e  jmp 0x00007D516E5CE835
00007d516e5cec23  call 0x00007D516E40D4E0
00007d516e5cec28  jmp 0x00007D516E5CE840
00007d516e5cec2d  call 0x00007D516E40BC20
00007d516e5cec32  jmp 0x00007D516E5CE870
00007d516e5cec37  call 0x00007D516E40A9A0
00007d516e5cec3c  jmp 0x00007D516E5CE87C
00007d516e5cec41  call 0x00007D516E40E880
00007d516e5cec46  jmp 0x00007D516E5CE887
00007d516e5cec4b  call 0x00007D516E3FF540
00007d516e5cec50  jmp 0x00007D516E5CE892
00007d516e5cec55  call 0x00007D516E3FF430
00007d516e5cec5a  jmp 0x00007D516E5CE89D
00007d516e5cec5f  call 0x00007D516E40B720
00007d516e5cec64  jmp 0x00007D516E5CE8A7
00007d516e5cec69  call 0x00007D516E40D600
00007d516e5cec6e  jmp 0x00007D516E5CE8BF
00007d516e5cec73  call 0x00007D516E3FF540
00007d516e5cec78  jmp 0x00007D516E5CE8CA
00007d516e5cec7d  call 0x00007D516E3FF430
00007d516e5cec82  jmp 0x00007D516E5CE8D5
00007d516e5cec87  call 0x00007D516E4B4CB0
00007d516e5cec8c  jmp 0x00007D516E5CE8E5
00007d516e5cec91  call 0x00007D516E40E760
00007d516e5cec96  jmp 0x00007D516E5CE8F0
00007d516e5cec9b  call 0x00007D516E40D4E0
00007d516e5ceca0  jmp 0x00007D516E5CE8FB
00007d516e5ceca5  call 0x00007D516E3FF540
00007d516e5cecaa  jmp 0x00007D516E5CE908
00007d516e5cecaf  call 0x00007D516E40BC20
00007d516e5cecb4  jmp 0x00007D516E5CE930
00007d516e5cecb9  call 0x00007D516E40A9A0
00007d516e5cecbe  jmp 0x00007D516E5CE93C
00007d516e5cecc3  call 0x00007D516E40E880
00007d516e5cecc8  jmp 0x00007D516E5CE949
00007d516e5ceccd  call 0x00007D516E40D600
00007d516e5cecd2  jmp 0x00007D516E5CE956
00007d516e5cecd7  call 0x00007D516E3FF430
00007d516e5cecdc  jmp 0x00007D516E5CE961
00007d516e5cece1  call 0x00007D516E40E760
00007d516e5cece6  jmp 0x00007D516E5CE96C
00007d516e5ceceb  call 0x00007D516E40BC20
00007d516e5cecf0  jmp 0x00007D516E5CE99C
00007d516e5cecf5  call 0x00007D516E40A9A0
00007d516e5cecfa  jmp 0x00007D516E5CE9A8
00007d516e5cecff  call 0x00007D516E40BC20
00007d516e5ced04  jmp 0x00007D516E5CE9D0
00007d516e5ced09  call 0x00007D516E40A9A0
00007d516e5ced0e  jmp 0x00007D516E5CE9DC
00007d516e5ced13  call 0x00007D516E3FF540
00007d516e5ced18  jmp 0x00007D516E5CE9E9
00007d516e5ced1d  call 0x00007D516E40E880
00007d516e5ced22  jmp 0x00007D516E5CE9F6
00007d516e5ced27  call 0x00007D516E3FF430
00007d516e5ced2c  jmp 0x00007D516E5CEA01
00007d516e5ced31  call 0x00007D516E40E760
00007d516e5ced36  jmp 0x00007D516E5CEA0C
00007d516e5ced3b  call 0x00007D516E40BC20
00007d516e5ced40  jmp 0x00007D516E5CEA36
00007d516e5ced45  call 0x00007D516E40A9A0
00007d516e5ced4a  jmp 0x00007D516E5CEA42
00007d516e5ced4f  call 0x00007D516E40BAE0
00007d516e5ced54  jmp 0x00007D516E5CEA52
00007d516e5ced59  call 0x00007D516E3FF540
00007d516e5ced5e  jmp 0x00007D516E5CEA5F
00007d516e5ced63  call 0x00007D516E40E880
00007d516e5ced68  jmp 0x00007D516E5CEA6C
00007d516e5ced6d  int3
00007d516e5ced6e  nop
00007d516e5ced70  mov rax, [r15]
00007d516e5ced73  lea r14, [rax+0x20]
00007d516e5ced77  mov r12, [r13+r14*1]
00007d516e5ced7c  mov r14, [r15+0x10]
00007d516e5ced80  lea r11, [r12+r14*1]
00007d516e5ced84  mov [r15+0x40], r11
00007d516e5ced88  lea r12, [rax+0x20]
00007d516e5ced8c  mov [r13+r12*1], r11
00007d516e5ced91  test r14, r14
00007d516e5ced94  setz r14b
00007d516e5ced98  movzx r14, r14b
00007d516e5ced9c  mov [rsp+0x414], r14b
00007d516e5ceda4  cmp byte ptr [rsp+0x414], 0x00
00007d516e5cedac  jz 0x00007D516E5CEDDE
00007d516e5cedae  cmp dword ptr [r15+0x318], 0x00
00007d516e5cedb6  mov eax, 0x4109A0
00007d516e5cedbb  mov [r15+0x100], rax
00007d516e5cedc2  jz 0x00007D516E3FE0A0
00007d516e5cedc8  nop [rax+rax*1], eax
00007d516e5cedcd  mov eax, 0x4109A0
00007d516e5cedd2  mov [r15+0x100], rax
00007d516e5cedd9  jmp 0x00007D516E3FE110
00007d516e5cedde  cmp dword ptr [r15+0x318], 0x00
00007d516e5cede6  jz 0x00007D516E5CEE30
00007d516e5cedec  nop [rax+rax*1], ax
00007d516e5cedf5  nop [rax+rax*1], eax
00007d516e5cedfd  mov eax, 0x410738
00007d516e5cee02  mov [r15+0x100], rax
00007d516e5cee09  jmp 0x00007D516E3FE110
00007d516e5cee0e  int3
00007d516e5cee0f  call 0x00007D516E4E27E0
00007d516e5cee14  jmp 0x00007D516E5CED7C
00007d516e5cee19  call 0x00007D516E4C0860
00007d516e5cee1e  jmp 0x00007D516E5CED91
00007d516e5cee23  int3
00007d516e5cee24  nop [rax+rax*1], ax
00007d516e5cee2d  nop [rax], eax
00007d516e5cee30  mov rax, [r15+0xF8]
00007d516e5cee37  lea r14, [rax-0x150]
00007d516e5cee3e  mov [r15+0xF8], r14
00007d516e5cee45  mov rax, [r15]
00007d516e5cee48  lea r12, [rax+0x68]
00007d516e5cee4c  mov r11, [r13+r12*1]
00007d516e5cee51  mov [r15+0x88], r11
00007d516e5cee58  lea r12, [rax+0x28]
00007d516e5cee5c  mov [r15+0x40], r12
00007d516e5cee60  mov [r15+0x48], r14
00007d516e5cee64  mov qword ptr [r15+0x50], 0x420B90
00007d516e5cee6c  lea rax, [r14+0x100]
00007d516e5cee73  mov r12, [r15+0xE8]
00007d516e5cee7a  mov r11, [r15+0xD8]
00007d516e5cee81  mov [r13+rax*1], r12
00007d516e5cee86  lea rax, [r14+0x108]
00007d516e5cee8d  mov [r13+rax*1], r11
00007d516e5cee92  lea rax, [r14+0x110]
00007d516e5cee99  mov r12, [r15+0xD0]
00007d516e5ceea0  mov r11, [r15+0xC8]
00007d516e5ceea7  mov [r13+rax*1], r12
00007d516e5ceeac  lea rax, [r14+0x118]
00007d516e5ceeb3  mov [r13+rax*1], r11
00007d516e5ceeb8  lea rax, [r14+0x120]
00007d516e5ceebf  mov r12, [r15+0xC0]
00007d516e5ceec6  mov r11, [r15+0xB8]
00007d516e5ceecd  mov [r13+rax*1], r12
00007d516e5ceed2  lea rax, [r14+0x128]
00007d516e5ceed9  mov [r13+rax*1], r11
00007d516e5ceede  lea rax, [r14+0x130]
00007d516e5ceee5  mov r12, [r15+0xB0]
00007d516e5ceeec  mov r11, [r15+0xA8]
00007d516e5ceef3  mov [r13+rax*1], r12
00007d516e5ceef8  lea rax, [r14+0x138]
00007d516e5ceeff  mov [r13+rax*1], r11
00007d516e5cef04  lea rax, [r14+0x140]
00007d516e5cef0b  mov r12, [r15+0xA0]
00007d516e5cef12  mov r11, [r15+0x98]
00007d516e5cef19  mov [r13+rax*1], r12
00007d516e5cef1e  lea rax, [r14+0x148]
00007d516e5cef25  mov [r13+rax*1], r11
00007d516e5cef2a  cmp dword ptr [r15+0x318], 0x00
00007d516e5cef32  jz 0x00007D516E5CEFD0
00007d516e5cef38  nop [rax+rax*1], ax
00007d516e5cef41  nop [rax+rax*1], eax
00007d516e5cef49  mov eax, 0x410770
00007d516e5cef4e  mov [r15+0x100], rax
00007d516e5cef55  jmp 0x00007D516E3FE110
00007d516e5cef5a  int3
00007d516e5cef5b  call 0x00007D516E4C0370
00007d516e5cef60  jmp 0x00007D516E5CEE51
00007d516e5cef65  call 0x00007D516E40BC20
00007d516e5cef6a  jmp 0x00007D516E5CEE86
00007d516e5cef6f  call 0x00007D516E40A9A0
00007d516e5cef74  jmp 0x00007D516E5CEE92
00007d516e5cef79  call 0x00007D516E40BC20
00007d516e5cef7e  jmp 0x00007D516E5CEEAC
00007d516e5cef83  call 0x00007D516E40A9A0
00007d516e5cef88  jmp 0x00007D516E5CEEB8
00007d516e5cef8d  call 0x00007D516E40BC20
00007d516e5cef92  jmp 0x00007D516E5CEED2
00007d516e5cef97  call 0x00007D516E40A9A0
00007d516e5cef9c  jmp 0x00007D516E5CEEDE
00007d516e5cefa1  call 0x00007D516E40BC20
00007d516e5cefa6  jmp 0x00007D516E5CEEF8
00007d516e5cefab  call 0x00007D516E40A9A0
00007d516e5cefb0  jmp 0x00007D516E5CEF04
00007d516e5cefb5  call 0x00007D516E40BC20
00007d516e5cefba  jmp 0x00007D516E5CEF1E
00007d516e5cefbf  call 0x00007D516E40A9A0
00007d516e5cefc4  jmp 0x00007D516E5CEF2A
00007d516e5cefc9  int3
00007d516e5cefca  nop [rax+rax*1], ax
00007d516e5cefd0  mov rax, [r15+0x08]
00007d516e5cefd4  movzx r14d, byte ptr [r13+rax*1]
00007d516e5cefda  movzx r14d, r14b
00007d516e5cefde  mov [rsp+0x10], r14d
00007d516e5cefe3  mov r14d, r14d
00007d516e5cefe6  mov [r15+0x58], r14
00007d516e5cefea  lea r14, [rax+0x01]
00007d516e5cefee  mov [r15+0x08], r14
00007d516e5ceff2  mov rax, [r15+0x88]
00007d516e5ceff9  lea r14, [rax+0x01]
00007d516e5ceffd  mov r12, [r15]
00007d516e5cf000  lea r11, [r12+0x68]
00007d516e5cf005  mov [r13+r11*1], r14
00007d516e5cf00a  lea r14, [r12+rax*1]
00007d516e5cf00e  mov [r15+0x60], r14
00007d516e5cf012  lea rax, [r14+0x28]
00007d516e5cf016  mov r11d, [rsp+0x10]
00007d516e5cf01b  movzx r14d, r11b
00007d516e5cf01f  mov [r13+rax*1], r14b
00007d516e5cf024  lea rax, [r12+0x68]
00007d516e5cf029  mov r14, [r13+rax*1]
00007d516e5cf02e  mov [r15+0x88], r14
00007d516e5cf035  xor eax, eax
00007d516e5cf037  mov r12d, 0x40
00007d516e5cf03d  cmp r14, r12
00007d516e5cf040  cmc
00007d516e5cf041  lahf
00007d516e5cf042  seto al
00007d516e5cf045  mov [r15+0x108], eax
00007d516e5cf04c  mov eax, [r15+0x108]
00007d516e5cf053  sahf
00007d516e5cf054  jnz 0x00007D516E5CF086
00007d516e5cf056  cmp dword ptr [r15+0x318], 0x00
00007d516e5cf05e  jz 0x00007D516E5CF170
00007d516e5cf064  nop [rax+rax*1], ax
00007d516e5cf06d  nop [rax+rax*1], eax
00007d516e5cf075  mov eax, 0x410790
00007d516e5cf07a  mov [r15+0x100], rax
00007d516e5cf081  jmp 0x00007D516E3FE110
00007d516e5cf086  cmp dword ptr [r15+0x318], 0x00
00007d516e5cf08e  jz 0x00007D516E5CF0E0
00007d516e5cf094  nop [rax+rax*1], ax
00007d516e5cf09d  nop [rax+rax*1], eax
00007d516e5cf0a5  mov eax, 0x410768
00007d516e5cf0aa  mov [r15+0x100], rax
00007d516e5cf0b1  jmp 0x00007D516E3FE110
00007d516e5cf0b6  int3
00007d516e5cf0b7  call 0x00007D516E40D860
00007d516e5cf0bc  jmp 0x00007D516E5CEFDA
00007d516e5cf0c1  call 0x00007D516E4B36E0
00007d516e5cf0c6  jmp 0x00007D516E5CF00A
00007d516e5cf0cb  call 0x00007D516E40DD60
00007d516e5cf0d0  jmp 0x00007D516E5CF024
00007d516e5cf0d5  call 0x00007D516E40DC20
00007d516e5cf0da  jmp 0x00007D516E5CF02E
00007d516e5cf0df  int3
00007d516e5cf0e0  mov rax, [r15+0x10]
00007d516e5cf0e4  lea r14, [rax-0x01]
00007d516e5cf0e8  mov [r15+0x10], r14
00007d516e5cf0ec  test r14, r14
00007d516e5cf0ef  setz r14b
00007d516e5cf0f3  movzx r14, r14b
00007d516e5cf0f7  mov [rsp+0x414], r14b
00007d516e5cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007d516e5cf107  jz 0x00007D516E5CF139
00007d516e5cf109  cmp dword ptr [r15+0x318], 0x00
00007d516e5cf111  jz 0x00007D516E5D0670
00007d516e5cf117  nop [rax+rax*1], ax
00007d516e5cf120  nop [rax+rax*1], eax
00007d516e5cf128  mov eax, 0x410988
00007d516e5cf12d  mov [r15+0x100], rax
00007d516e5cf134  jmp 0x00007D516E3FE110
00007d516e5cf139  cmp dword ptr [r15+0x318], 0x00
00007d516e5cf141  jz 0x00007D516E5CEFD0
00007d516e5cf147  nop [rax+rax*1], ax
00007d516e5cf150  nop [rax+rax*1], eax
00007d516e5cf158  mov eax, 0x410770
00007d516e5cf15d  mov [r15+0x100], rax
00007d516e5cf164  jmp 0x00007D516E3FE110
00007d516e5cf169  int3
00007d516e5cf16a  int3
00007d516e5cf16b  nop [rax+rax*1], eax
00007d516e5cf170  mov rax, [r15+0x40]
00007d516e5cf174  movzx r14d, byte ptr [r13+rax*1]
00007d516e5cf17a  movaps xmm1, [r15+0x110]
00007d516e5cf182  pinsrb xmm1, r14d, 0x00
00007d516e5cf189  lea r14, [rax+0x01]
00007d516e5cf18d  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf193  movaps xmm15, [r15+0x120]
00007d516e5cf19b  pinsrb xmm15, r12d, 0x00
00007d516e5cf1a2  lea r14, [rax+0x02]
00007d516e5cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf1ac  movaps xmm14, [r15+0x130]
00007d516e5cf1b4  pinsrb xmm14, r12d, 0x00
00007d516e5cf1bb  lea r14, [rax+0x03]
00007d516e5cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf1c5  movaps xmm13, [r15+0x140]
00007d516e5cf1cd  pinsrb xmm13, r12d, 0x00
00007d516e5cf1d4  lea r14, [rax+0x04]
00007d516e5cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf1de  pinsrb xmm1, r12d, 0x01
00007d516e5cf1e5  lea r14, [rax+0x05]
00007d516e5cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf1ef  pinsrb xmm15, r12d, 0x01
00007d516e5cf1f6  lea r14, [rax+0x06]
00007d516e5cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf200  pinsrb xmm14, r12d, 0x01
00007d516e5cf207  lea r14, [rax+0x07]
00007d516e5cf20b  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf211  pinsrb xmm13, r12d, 0x01
00007d516e5cf218  lea r14, [rax+0x08]
00007d516e5cf21c  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf222  pinsrb xmm1, r12d, 0x02
00007d516e5cf229  lea r14, [rax+0x09]
00007d516e5cf22d  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf233  pinsrb xmm15, r12d, 0x02
00007d516e5cf23a  lea r14, [rax+0x0A]
00007d516e5cf23e  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf244  pinsrb xmm14, r12d, 0x02
00007d516e5cf24b  lea r14, [rax+0x0B]
00007d516e5cf24f  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf255  pinsrb xmm13, r12d, 0x02
00007d516e5cf25c  lea r14, [rax+0x0C]
00007d516e5cf260  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf266  pinsrb xmm1, r12d, 0x03
00007d516e5cf26d  lea r14, [rax+0x0D]
00007d516e5cf271  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf277  pinsrb xmm15, r12d, 0x03
00007d516e5cf27e  lea r14, [rax+0x0E]
00007d516e5cf282  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf288  pinsrb xmm14, r12d, 0x03
00007d516e5cf28f  lea r14, [rax+0x0F]
00007d516e5cf293  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf299  pinsrb xmm13, r12d, 0x03
00007d516e5cf2a0  lea r14, [rax+0x10]
00007d516e5cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf2aa  pinsrb xmm1, r12d, 0x04
00007d516e5cf2b1  lea r14, [rax+0x11]
00007d516e5cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf2bb  pinsrb xmm15, r12d, 0x04
00007d516e5cf2c2  lea r14, [rax+0x12]
00007d516e5cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf2cc  pinsrb xmm14, r12d, 0x04
00007d516e5cf2d3  lea r14, [rax+0x13]
00007d516e5cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf2dd  pinsrb xmm13, r12d, 0x04
00007d516e5cf2e4  lea r14, [rax+0x14]
00007d516e5cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf2ee  pinsrb xmm1, r12d, 0x05
00007d516e5cf2f5  lea r14, [rax+0x15]
00007d516e5cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf2ff  pinsrb xmm15, r12d, 0x05
00007d516e5cf306  lea r14, [rax+0x16]
00007d516e5cf30a  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf310  pinsrb xmm14, r12d, 0x05
00007d516e5cf317  lea r14, [rax+0x17]
00007d516e5cf31b  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf321  pinsrb xmm13, r12d, 0x05
00007d516e5cf328  lea r14, [rax+0x18]
00007d516e5cf32c  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf332  pinsrb xmm1, r12d, 0x06
00007d516e5cf339  lea r14, [rax+0x19]
00007d516e5cf33d  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf343  pinsrb xmm15, r12d, 0x06
00007d516e5cf34a  lea r14, [rax+0x1A]
00007d516e5cf34e  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf354  pinsrb xmm14, r12d, 0x06
00007d516e5cf35b  lea r14, [rax+0x1B]
00007d516e5cf35f  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf365  pinsrb xmm13, r12d, 0x06
00007d516e5cf36c  lea r14, [rax+0x1C]
00007d516e5cf370  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf376  pinsrb xmm1, r12d, 0x07
00007d516e5cf37d  lea r14, [rax+0x1D]
00007d516e5cf381  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf387  pinsrb xmm15, r12d, 0x07
00007d516e5cf38e  lea r14, [rax+0x1E]
00007d516e5cf392  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf398  pinsrb xmm14, r12d, 0x07
00007d516e5cf39f  lea r14, [rax+0x1F]
00007d516e5cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf3a9  pinsrb xmm13, r12d, 0x07
00007d516e5cf3b0  lea r14, [rax+0x20]
00007d516e5cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf3ba  pinsrb xmm1, r12d, 0x08
00007d516e5cf3c1  lea r14, [rax+0x21]
00007d516e5cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf3cb  pinsrb xmm15, r12d, 0x08
00007d516e5cf3d2  lea r14, [rax+0x22]
00007d516e5cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf3dc  pinsrb xmm14, r12d, 0x08
00007d516e5cf3e3  lea r14, [rax+0x23]
00007d516e5cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf3ed  pinsrb xmm13, r12d, 0x08
00007d516e5cf3f4  lea r14, [rax+0x24]
00007d516e5cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf3fe  pinsrb xmm1, r12d, 0x09
00007d516e5cf405  lea r14, [rax+0x25]
00007d516e5cf409  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf40f  pinsrb xmm15, r12d, 0x09
00007d516e5cf416  lea r14, [rax+0x26]
00007d516e5cf41a  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf420  pinsrb xmm14, r12d, 0x09
00007d516e5cf427  lea r14, [rax+0x27]
00007d516e5cf42b  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf431  pinsrb xmm13, r12d, 0x09
00007d516e5cf438  lea r14, [rax+0x28]
00007d516e5cf43c  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf442  pinsrb xmm1, r12d, 0x0A
00007d516e5cf449  lea r14, [rax+0x29]
00007d516e5cf44d  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf453  pinsrb xmm15, r12d, 0x0A
00007d516e5cf45a  lea r14, [rax+0x2A]
00007d516e5cf45e  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf464  pinsrb xmm14, r12d, 0x0A
00007d516e5cf46b  lea r14, [rax+0x2B]
00007d516e5cf46f  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf475  pinsrb xmm13, r12d, 0x0A
00007d516e5cf47c  lea r14, [rax+0x2C]
00007d516e5cf480  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf486  pinsrb xmm1, r12d, 0x0B
00007d516e5cf48d  lea r14, [rax+0x2D]
00007d516e5cf491  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf497  pinsrb xmm15, r12d, 0x0B
00007d516e5cf49e  lea r14, [rax+0x2E]
00007d516e5cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf4a8  pinsrb xmm14, r12d, 0x0B
00007d516e5cf4af  lea r14, [rax+0x2F]
00007d516e5cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf4b9  pinsrb xmm13, r12d, 0x0B
00007d516e5cf4c0  lea r14, [rax+0x30]
00007d516e5cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf4ca  pinsrb xmm1, r12d, 0x0C
00007d516e5cf4d1  lea r14, [rax+0x31]
00007d516e5cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf4db  pinsrb xmm15, r12d, 0x0C
00007d516e5cf4e2  lea r14, [rax+0x32]
00007d516e5cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf4ec  pinsrb xmm14, r12d, 0x0C
00007d516e5cf4f3  lea r14, [rax+0x33]
00007d516e5cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf4fd  pinsrb xmm13, r12d, 0x0C
00007d516e5cf504  lea r14, [rax+0x34]
00007d516e5cf508  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf50e  pinsrb xmm1, r12d, 0x0D
00007d516e5cf515  lea r14, [rax+0x35]
00007d516e5cf519  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf51f  pinsrb xmm15, r12d, 0x0D
00007d516e5cf526  lea r14, [rax+0x36]
00007d516e5cf52a  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf530  pinsrb xmm14, r12d, 0x0D
00007d516e5cf537  lea r14, [rax+0x37]
00007d516e5cf53b  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf541  pinsrb xmm13, r12d, 0x0D
00007d516e5cf548  lea r14, [rax+0x38]
00007d516e5cf54c  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf552  pinsrb xmm1, r12d, 0x0E
00007d516e5cf559  lea r14, [rax+0x39]
00007d516e5cf55d  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf563  pinsrb xmm15, r12d, 0x0E
00007d516e5cf56a  lea r14, [rax+0x3A]
00007d516e5cf56e  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf574  pinsrb xmm14, r12d, 0x0E
00007d516e5cf57b  lea r14, [rax+0x3B]
00007d516e5cf57f  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf585  pinsrb xmm13, r12d, 0x0E
00007d516e5cf58c  lea r14, [rax+0x3C]
00007d516e5cf590  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf596  pinsrb xmm1, r12d, 0x0F
00007d516e5cf59d  movaps [r15+0x110], xmm1
00007d516e5cf5a5  lea r14, [rax+0x3D]
00007d516e5cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf5af  pinsrb xmm15, r12d, 0x0F
00007d516e5cf5b6  movaps [r15+0x120], xmm15
00007d516e5cf5be  lea r14, [rax+0x3E]
00007d516e5cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007d516e5cf5c8  pinsrb xmm14, r12d, 0x0F
00007d516e5cf5cf  movaps [r15+0x130], xmm14
00007d516e5cf5d7  lea r14, [rax+0x3F]
00007d516e5cf5db  movzx eax, byte ptr [r13+r14*1]
00007d516e5cf5e1  pinsrb xmm13, eax, 0x0F
00007d516e5cf5e8  movaps [r15+0x140], xmm13
00007d516e5cf5f0  movq xmm1, qword ptr [r15+0x120]
00007d516e5cf5f9  pmovzxbw xmm1, xmm1
00007d516e5cf5fe  psllw xmm1, 0x00
00007d516e5cf603  movaps [r15+0x150], xmm1
00007d516e5cf60b  movq xmm1, qword ptr [r15+0x130]
00007d516e5cf614  pmovzxbw xmm1, xmm1
00007d516e5cf619  psllw xmm1, 0x00
00007d516e5cf61e  movaps [r15+0x160], xmm1
00007d516e5cf626  movq xmm1, qword ptr [r15+0x110]
00007d516e5cf62f  pmovzxbw xmm1, xmm1
00007d516e5cf634  psllw xmm1, 0x00
00007d516e5cf639  movaps [r15+0x170], xmm1
00007d516e5cf641  movaps xmm15, [r15+0x110]
00007d516e5cf649  pextrq rax, xmm15, 0x01
00007d516e5cf650  movq xmm15, rax
00007d516e5cf655  pmovzxbw xmm15, xmm15
00007d516e5cf65b  psllw xmm15, 0x00
00007d516e5cf661  movaps [r15+0x180], xmm15
00007d516e5cf669  movaps xmm14, [r15+0x120]
00007d516e5cf671  pextrq rax, xmm14, 0x01
00007d516e5cf678  movq xmm14, rax
00007d516e5cf67d  pmovzxbw xmm14, xmm14
00007d516e5cf683  psllw xmm14, 0x00
00007d516e5cf689  movaps [r15+0x210], xmm14
00007d516e5cf691  movaps xmm13, [r15+0x130]
00007d516e5cf699  pextrq rax, xmm13, 0x01
00007d516e5cf6a0  movq xmm13, rax
00007d516e5cf6a5  pmovzxbw xmm13, xmm13
00007d516e5cf6ab  psllw xmm13, 0x00
00007d516e5cf6b1  movaps [r15+0x220], xmm13
00007d516e5cf6b9  movq xmm12, qword ptr [r15+0x140]
00007d516e5cf6c2  pmovzxbw xmm12, xmm12
00007d516e5cf6c8  psllw xmm12, 0x00
00007d516e5cf6ce  movaps [r15+0x250], xmm12
00007d516e5cf6d6  movaps xmm12, [r15+0x140]
00007d516e5cf6de  pextrq rax, xmm12, 0x01
00007d516e5cf6e5  movq xmm12, rax
00007d516e5cf6ea  pmovzxbw xmm12, xmm12
00007d516e5cf6f0  psllw xmm12, 0x00
00007d516e5cf6f6  movaps [r15+0x110], xmm12
00007d516e5cf6fe  movq xmm11, qword ptr [r15+0x150]
00007d516e5cf707  pmovzxwd xmm11, xmm11
00007d516e5cf70d  pslld xmm11, 0x10
00007d516e5cf713  movq xmm10, qword ptr [r15+0x160]
00007d516e5cf71c  pmovzxwd xmm10, xmm10
00007d516e5cf722  pslld xmm10, 0x08
00007d516e5cf728  pextrq rax, xmm1, 0x01
00007d516e5cf72f  movq xmm1, rax
00007d516e5cf734  pmovzxwd xmm1, xmm1
00007d516e5cf739  pslld xmm1, 0x00
00007d516e5cf73e  movaps [r15+0x260], xmm1
00007d516e5cf746  pextrq rax, xmm15, 0x01
00007d516e5cf74d  movq xmm15, rax
00007d516e5cf752  pmovzxwd xmm15, xmm15
00007d516e5cf758  pslld xmm15, 0x00
00007d516e5cf75e  movaps [r15+0x270], xmm15
00007d516e5cf766  movq xmm9, qword ptr [r15+0x170]
00007d516e5cf76f  pmovzxwd xmm9, xmm9
00007d516e5cf775  pslld xmm9, 0x00
00007d516e5cf77b  pextrq rax, xmm14, 0x01
00007d516e5cf782  movq xmm14, rax
00007d516e5cf787  pmovzxwd xmm14, xmm14
00007d516e5cf78d  pslld xmm14, 0x10
00007d516e5cf793  movaps [r15+0x280], xmm14
00007d516e5cf79b  movq xmm8, qword ptr [r15+0x180]
00007d516e5cf7a4  pmovzxwd xmm8, xmm8
00007d516e5cf7aa  pslld xmm8, 0x00
00007d516e5cf7b0  movq xmm7, qword ptr [r15+0x210]
00007d516e5cf7b9  pmovzxwd xmm7, xmm7
00007d516e5cf7be  pslld xmm7, 0x10
00007d516e5cf7c3  movaps xmm6, [r15+0x150]
00007d516e5cf7cb  pextrq rax, xmm6, 0x01
00007d516e5cf7d2  movq xmm6, rax
00007d516e5cf7d7  pmovzxwd xmm6, xmm6
00007d516e5cf7dc  pslld xmm6, 0x10
00007d516e5cf7e1  por xmm11, xmm10
00007d516e5cf7e6  movaps [r15+0x230], xmm11
00007d516e5cf7ee  pextrq rax, xmm13, 0x01
00007d516e5cf7f5  movq xmm13, rax
00007d516e5cf7fa  pmovzxwd xmm13, xmm13
00007d516e5cf800  pslld xmm13, 0x08
00007d516e5cf806  movaps [r15+0x240], xmm13
00007d516e5cf80e  movq xmm10, qword ptr [r15+0x220]
00007d516e5cf817  pmovzxwd xmm10, xmm10
00007d516e5cf81d  pslld xmm10, 0x08
00007d516e5cf823  movaps xmm5, [r15+0x160]
00007d516e5cf82b  pextrq rax, xmm5, 0x01
00007d516e5cf832  movq xmm5, rax
00007d516e5cf837  pmovzxwd xmm5, xmm5
00007d516e5cf83c  pslld xmm5, 0x08
00007d516e5cf841  pslld xmm9, 0x18
00007d516e5cf847  pslld xmm15, 0x18
00007d516e5cf84d  pslld xmm8, 0x18
00007d516e5cf853  movq xmm4, qword ptr [r15+0x250]
00007d516e5cf85c  pmovzxwd xmm4, xmm4
00007d516e5cf861  pslld xmm4, 0x00
00007d516e5cf866  por xmm14, xmm13
00007d516e5cf86b  por xmm7, xmm10
00007d516e5cf870  movaps [r15+0x210], xmm7
00007d516e5cf878  pslld xmm1, 0x18
00007d516e5cf87d  movaps [r15+0x220], xmm1
00007d516e5cf885  por xmm6, xmm5
00007d516e5cf889  por xmm11, xmm9
00007d516e5cf88e  movaps [r15+0x160], xmm11
00007d516e5cf896  pextrq rax, xmm12, 0x01
00007d516e5cf89d  movq xmm13, rax
00007d516e5cf8a2  pmovzxwd xmm13, xmm13
00007d516e5cf8a8  pslld xmm13, 0x00
00007d516e5cf8ae  movaps [r15+0x170], xmm13
00007d516e5cf8b6  movq xmm12, qword ptr [r15+0x110]
00007d516e5cf8bf  pmovzxwd xmm12, xmm12
00007d516e5cf8c5  pslld xmm12, 0x00
00007d516e5cf8cb  por xmm14, xmm15
00007d516e5cf8d0  por xmm7, xmm8
00007d516e5cf8d5  movaps xmm15, [r15+0x250]
00007d516e5cf8dd  pextrq rax, xmm15, 0x01
00007d516e5cf8e4  movq xmm15, rax
00007d516e5cf8e9  pmovzxwd xmm15, xmm15
00007d516e5cf8ef  pslld xmm15, 0x00
00007d516e5cf8f5  movaps [r15+0x180], xmm15
00007d516e5cf8fd  por xmm6, xmm1
00007d516e5cf901  movaps [r15+0x150], xmm6
00007d516e5cf909  por xmm11, xmm4
00007d516e5cf90e  movaps [r15+0x140], xmm11
00007d516e5cf916  por xmm7, xmm12
00007d516e5cf91b  movaps [r15+0x110], xmm7
00007d516e5cf923  por xmm14, xmm13
00007d516e5cf928  movaps [r15+0x120], xmm14
00007d516e5cf930  por xmm6, xmm15
00007d516e5cf935  movaps [r15+0x130], xmm6
00007d516e5cf93d  mov rax, [r15+0xF8]
00007d516e5cf944  lea r14, [rax+0x20]
00007d516e5cf948  movups [r13+r14*1], xmm7
00007d516e5cf94e  lea r14, [rax+0x30]
00007d516e5cf952  movups [r13+r14*1], xmm14
00007d516e5cf958  movups [r13+rax*1], xmm11
00007d516e5cf95e  lea r14, [rax+0x10]
00007d516e5cf962  movups [r13+r14*1], xmm6
00007d516e5cf968  mov r14d, [r13+rax*1]
00007d516e5cf96d  mov rax, [r15+0x48]
00007d516e5cf971  mov [r15+0x68], rax
00007d516e5cf975  mov qword ptr [r15+0x58], 0x04
00007d516e5cf97d  lea r12, [rax+0x04]
00007d516e5cf981  mov r11d, [r13+r12*1]
00007d516e5cf986  mov [rsp+0x10], r11d
00007d516e5cf98b  mov r11d, r11d
00007d516e5cf98e  mov [r15+0x70], r11
00007d516e5cf992  lea r12, [rax+0x38]
00007d516e5cf996  mov r11d, [r13+r12*1]
00007d516e5cf99b  lea r12, [rax+0x24]
00007d516e5cf99f  mov r10d, [r13+r12*1]
00007d516e5cf9a4  mov [rsp+0x20], r10d
00007d516e5cf9a9  mov r10d, r10d
00007d516e5cf9ac  mov [r15+0x90], r10
00007d516e5cf9b3  mov [rsp+0x30], rax
00007d516e5cf9b8  xor eax, eax
00007d516e5cf9ba  mov r12d, 0x04
00007d516e5cf9c0  mov r10d, 0xC0
00007d516e5cf9c6  cmp r12, r10
00007d516e5cf9c9  cmc
00007d516e5cf9ca  lahf
00007d516e5cf9cb  seto al
00007d516e5cf9ce  mov [r15+0x108], eax
00007d516e5cf9d5  mov eax, [rsp+0x10]
00007d516e5cf9d9  mov r12d, [rsp+0x10]
00007d516e5cf9de  shrd eax, r12d, 0x07
00007d516e5cf9e3  mov [rsp+0x10], r11d
00007d516e5cf9e8  mov r10d, [rsp+0x10]
00007d516e5cf9ed  shrd r11d, r10d, 0x11
00007d516e5cf9f2  mov r9d, [rsp+0x20]
00007d516e5cf9f7  lea r8d, [r9d+r14d*1]
00007d516e5cf9fc  rorx r14d, r12d, 0x12
00007d516e5cfa02  xor eax, r14d
00007d516e5cfa05  rorx r14d, r10d, 0x13
00007d516e5cfa0b  xor r11d, r14d
00007d516e5cfa0e  mov [rsp+0x10], r11d
00007d516e5cfa13  mov r11d, r11d
00007d516e5cfa16  mov [r15+0x88], r11
00007d516e5cfa1d  mov [rsp+0x20], r12d
00007d516e5cfa22  shr r12d, 0x03
00007d516e5cfa26  xor eax, r12d
00007d516e5cfa29  mov [rsp+0x40], eax
00007d516e5cfa2d  mov eax, eax
00007d516e5cfa2f  mov [r15+0x80], rax
00007d516e5cfa36  shr r10d, 0x0A
00007d516e5cfa3a  mov eax, [rsp+0x10]
00007d516e5cfa3e  xor eax, r10d
00007d516e5cfa41  mov [rsp+0x10], eax
00007d516e5cfa45  mov eax, eax
00007d516e5cfa47  mov [r15+0x78], rax
00007d516e5cfa4b  mov eax, [rsp+0x40]
00007d516e5cfa4f  lea r14d, [r8d+eax*1]
00007d516e5cfa54  mov eax, [rsp+0x10]
00007d516e5cfa58  lea r12d, [r14d+eax*1]
00007d516e5cfa5d  mov rax, [rsp+0x30]
00007d516e5cfa62  lea r14, [rax+0x40]
00007d516e5cfa66  mov [r13+r14*1], r12d
00007d516e5cfa6b  mov eax, [rsp+0x20]
00007d516e5cfa6f  mov eax, eax
00007d516e5cfa71  mov [r15+0x60], rax
00007d516e5cfa75  mov eax, [r15+0x108]
00007d516e5cfa7c  sahf
00007d516e5cfa7d  jnz 0x00007D516E5CFAAF
00007d516e5cfa7f  cmp dword ptr [r15+0x318], 0x00
00007d516e5cfa87  jz 0x00007D516E5CFF70
00007d516e5cfa8d  nop [rax+rax*1], ax
00007d516e5cfa96  nop [rax+rax*1], eax
00007d516e5cfa9e  mov eax, 0x41088C
00007d516e5cfaa3  mov [r15+0x100], rax
00007d516e5cfaaa  jmp 0x00007D516E3FE110
00007d516e5cfaaf  cmp dword ptr [r15+0x318], 0x00
00007d516e5cfab7  jz 0x00007D516E5CFDC0
00007d516e5cfabd  nop [rax+rax*1], ax
00007d516e5cfac6  nop [rax+rax*1], eax
00007d516e5cface  mov eax, 0x410844
00007d516e5cfad3  mov [r15+0x100], rax
00007d516e5cfada  jmp 0x00007D516E3FE110
00007d516e5cfadf  int3
00007d516e5cfae0  call 0x00007D516E40D860
00007d516e5cfae5  jmp 0x00007D516E5CF17A
00007d516e5cfaea  call 0x00007D516E4E2420
00007d516e5cfaef  jmp 0x00007D516E5CF193
00007d516e5cfaf4  call 0x00007D516E4E2420
00007d516e5cfaf9  jmp 0x00007D516E5CF1AC
00007d516e5cfafe  call 0x00007D516E4E2420
00007d516e5cfb03  jmp 0x00007D516E5CF1C5
00007d516e5cfb08  call 0x00007D516E4E2420
00007d516e5cfb0d  jmp 0x00007D516E5CF1DE
00007d516e5cfb12  call 0x00007D516E4E2420
00007d516e5cfb17  jmp 0x00007D516E5CF1EF
00007d516e5cfb1c  call 0x00007D516E4E2420
00007d516e5cfb21  jmp 0x00007D516E5CF200
00007d516e5cfb26  call 0x00007D516E4E2420
00007d516e5cfb2b  jmp 0x00007D516E5CF211
00007d516e5cfb30  call 0x00007D516E4E2420
00007d516e5cfb35  jmp 0x00007D516E5CF222
00007d516e5cfb3a  call 0x00007D516E4E2420
00007d516e5cfb3f  jmp 0x00007D516E5CF233
00007d516e5cfb44  call 0x00007D516E4E2420
00007d516e5cfb49  jmp 0x00007D516E5CF244
00007d516e5cfb4e  call 0x00007D516E4E2420
00007d516e5cfb53  jmp 0x00007D516E5CF255
00007d516e5cfb58  call 0x00007D516E4E2420
00007d516e5cfb5d  jmp 0x00007D516E5CF266
00007d516e5cfb62  call 0x00007D516E4E2420
00007d516e5cfb67  jmp 0x00007D516E5CF277
00007d516e5cfb6c  call 0x00007D516E4E2420
00007d516e5cfb71  jmp 0x00007D516E5CF288
00007d516e5cfb76  call 0x00007D516E4E2420
00007d516e5cfb7b  jmp 0x00007D516E5CF299
00007d516e5cfb80  call 0x00007D516E4E2420
00007d516e5cfb85  jmp 0x00007D516E5CF2AA
00007d516e5cfb8a  call 0x00007D516E4E2420
00007d516e5cfb8f  jmp 0x00007D516E5CF2BB
00007d516e5cfb94  call 0x00007D516E4E2420
00007d516e5cfb99  jmp 0x00007D516E5CF2CC
00007d516e5cfb9e  call 0x00007D516E4E2420
00007d516e5cfba3  jmp 0x00007D516E5CF2DD
00007d516e5cfba8  call 0x00007D516E4E2420
00007d516e5cfbad  jmp 0x00007D516E5CF2EE
00007d516e5cfbb2  call 0x00007D516E4E2420
00007d516e5cfbb7  jmp 0x00007D516E5CF2FF
00007d516e5cfbbc  call 0x00007D516E4E2420
00007d516e5cfbc1  jmp 0x00007D516E5CF310
00007d516e5cfbc6  call 0x00007D516E4E2420
00007d516e5cfbcb  jmp 0x00007D516E5CF321
00007d516e5cfbd0  call 0x00007D516E4E2420
00007d516e5cfbd5  jmp 0x00007D516E5CF332
00007d516e5cfbda  call 0x00007D516E4E2420
00007d516e5cfbdf  jmp 0x00007D516E5CF343
00007d516e5cfbe4  call 0x00007D516E4E2420
00007d516e5cfbe9  jmp 0x00007D516E5CF354
00007d516e5cfbee  call 0x00007D516E4E2420
00007d516e5cfbf3  jmp 0x00007D516E5CF365
00007d516e5cfbf8  call 0x00007D516E4E2420
00007d516e5cfbfd  jmp 0x00007D516E5CF376
00007d516e5cfc02  call 0x00007D516E4E2420
00007d516e5cfc07  jmp 0x00007D516E5CF387
00007d516e5cfc0c  call 0x00007D516E4E2420
00007d516e5cfc11  jmp 0x00007D516E5CF398
00007d516e5cfc16  call 0x00007D516E4E2420
00007d516e5cfc1b  jmp 0x00007D516E5CF3A9
00007d516e5cfc20  call 0x00007D516E4E2420
00007d516e5cfc25  jmp 0x00007D516E5CF3BA
00007d516e5cfc2a  call 0x00007D516E4E2420
00007d516e5cfc2f  jmp 0x00007D516E5CF3CB
00007d516e5cfc34  call 0x00007D516E4E2420
00007d516e5cfc39  jmp 0x00007D516E5CF3DC
00007d516e5cfc3e  call 0x00007D516E4E2420
00007d516e5cfc43  jmp 0x00007D516E5CF3ED
00007d516e5cfc48  call 0x00007D516E4E2420
00007d516e5cfc4d  jmp 0x00007D516E5CF3FE
00007d516e5cfc52  call 0x00007D516E4E2420
00007d516e5cfc57  jmp 0x00007D516E5CF40F
00007d516e5cfc5c  call 0x00007D516E4E2420
00007d516e5cfc61  jmp 0x00007D516E5CF420
00007d516e5cfc66  call 0x00007D516E4E2420
00007d516e5cfc6b  jmp 0x00007D516E5CF431
00007d516e5cfc70  call 0x00007D516E4E2420
00007d516e5cfc75  jmp 0x00007D516E5CF442
00007d516e5cfc7a  call 0x00007D516E4E2420
00007d516e5cfc7f  jmp 0x00007D516E5CF453
00007d516e5cfc84  call 0x00007D516E4E2420
00007d516e5cfc89  jmp 0x00007D516E5CF464
00007d516e5cfc8e  call 0x00007D516E4E2420
00007d516e5cfc93  jmp 0x00007D516E5CF475
00007d516e5cfc98  call 0x00007D516E4E2420
00007d516e5cfc9d  jmp 0x00007D516E5CF486
00007d516e5cfca2  call 0x00007D516E4E2420
00007d516e5cfca7  jmp 0x00007D516E5CF497
00007d516e5cfcac  call 0x00007D516E4E2420
00007d516e5cfcb1  jmp 0x00007D516E5CF4A8
00007d516e5cfcb6  call 0x00007D516E4E2420
00007d516e5cfcbb  jmp 0x00007D516E5CF4B9
00007d516e5cfcc0  call 0x00007D516E4E2420
00007d516e5cfcc5  jmp 0x00007D516E5CF4CA
00007d516e5cfcca  call 0x00007D516E4E2420
00007d516e5cfccf  jmp 0x00007D516E5CF4DB
00007d516e5cfcd4  call 0x00007D516E4E2420
00007d516e5cfcd9  jmp 0x00007D516E5CF4EC
00007d516e5cfcde  call 0x00007D516E4E2420
00007d516e5cfce3  jmp 0x00007D516E5CF4FD
00007d516e5cfce8  call 0x00007D516E4E2420
00007d516e5cfced  jmp 0x00007D516E5CF50E
00007d516e5cfcf2  call 0x00007D516E4E2420
00007d516e5cfcf7  jmp 0x00007D516E5CF51F
00007d516e5cfcfc  call 0x00007D516E4E2420
00007d516e5cfd01  jmp 0x00007D516E5CF530
00007d516e5cfd06  call 0x00007D516E4E2420
00007d516e5cfd0b  jmp 0x00007D516E5CF541
00007d516e5cfd10  call 0x00007D516E4E2420
00007d516e5cfd15  jmp 0x00007D516E5CF552
00007d516e5cfd1a  call 0x00007D516E4E2420
00007d516e5cfd1f  jmp 0x00007D516E5CF563
00007d516e5cfd24  call 0x00007D516E4E2420
00007d516e5cfd29  jmp 0x00007D516E5CF574
00007d516e5cfd2e  call 0x00007D516E4E2420
00007d516e5cfd33  jmp 0x00007D516E5CF585
00007d516e5cfd38  call 0x00007D516E4E2420
00007d516e5cfd3d  jmp 0x00007D516E5CF596
00007d516e5cfd42  call 0x00007D516E4E2420
00007d516e5cfd47  jmp 0x00007D516E5CF5AF
00007d516e5cfd4c  call 0x00007D516E4E2420
00007d516e5cfd51  jmp 0x00007D516E5CF5C8
00007d516e5cfd56  call 0x00007D516E4D5610
00007d516e5cfd5b  jmp 0x00007D516E5CF5E1
00007d516e5cfd60  call 0x00007D516E4DC580
00007d516e5cfd65  jmp 0x00007D516E5CF94E
00007d516e5cfd6a  call 0x00007D516E4E46C0
00007d516e5cfd6f  jmp 0x00007D516E5CF958
00007d516e5cfd74  call 0x00007D516E409E90
00007d516e5cfd79  jmp 0x00007D516E5CF95E
00007d516e5cfd7e  call 0x00007D516E4DB310
00007d516e5cfd83  jmp 0x00007D516E5CF968
00007d516e5cfd88  call 0x00007D516E40DAE0
00007d516e5cfd8d  jmp 0x00007D516E5CF96D
00007d516e5cfd92  call 0x00007D516E4C0230
00007d516e5cfd97  jmp 0x00007D516E5CF986
00007d516e5cfd9c  call 0x00007D516E4C0230
00007d516e5cfda1  jmp 0x00007D516E5CF99B
00007d516e5cfda6  call 0x00007D516E4BEFC0
00007d516e5cfdab  jmp 0x00007D516E5CF9A4
00007d516e5cfdb0  call 0x00007D516E4E2BA0
00007d516e5cfdb5  jmp 0x00007D516E5CFA6B
00007d516e5cfdba  int3
00007d516e5cfdbb  nop [rax+rax*1], eax
00007d516e5cfdc0  mov rax, [r15+0x48]
00007d516e5cfdc4  mov r14, [r15+0x58]
00007d516e5cfdc8  lea r12, [rax+r14*1]
00007d516e5cfdcc  mov [r15+0x68], r12
00007d516e5cfdd0  lea rax, [r14+0x04]
00007d516e5cfdd4  mov [r15+0x58], rax
00007d516e5cfdd8  lea r14, [r12+0x04]
00007d516e5cfddd  mov r11d, [r13+r14*1]
00007d516e5cfde2  mov [rsp+0x10], r11d
00007d516e5cfde7  mov r11d, r11d
00007d516e5cfdea  mov [r15+0x70], r11
00007d516e5cfdee  lea r14, [r12+0x38]
00007d516e5cfdf3  mov r11d, [r13+r14*1]
00007d516e5cfdf8  lea r14, [r12+0x24]
00007d516e5cfdfd  mov r10d, [r13+r14*1]
00007d516e5cfe02  mov [rsp+0x20], r10d
00007d516e5cfe07  mov r10d, r10d
00007d516e5cfe0a  mov [r15+0x90], r10
00007d516e5cfe11  mov [rsp+0x30], rax
00007d516e5cfe16  xor eax, eax
00007d516e5cfe18  mov r14, [rsp+0x30]
00007d516e5cfe1d  mov r10d, 0xC0
00007d516e5cfe23  cmp r14, r10
00007d516e5cfe26  cmc
00007d516e5cfe27  lahf
00007d516e5cfe28  seto al
00007d516e5cfe2b  mov [r15+0x108], eax
00007d516e5cfe32  mov eax, [rsp+0x10]
00007d516e5cfe36  mov r14d, [rsp+0x10]
00007d516e5cfe3b  shrd eax, r14d, 0x07
00007d516e5cfe40  mov [rsp+0x10], r11d
00007d516e5cfe45  mov r10d, [rsp+0x10]
00007d516e5cfe4a  shrd r11d, r10d, 0x11
00007d516e5cfe4f  mov r9d, [r15+0x60]
00007d516e5cfe53  mov r8d, [rsp+0x20]
00007d516e5cfe58  lea ebp, [r8d+r9d*1]
00007d516e5cfe5d  rorx r9d, r14d, 0x12
00007d516e5cfe63  xor eax, r9d
00007d516e5cfe66  rorx r9d, r10d, 0x13
00007d516e5cfe6c  xor r11d, r9d
00007d516e5cfe6f  mov [rsp+0x10], r11d
00007d516e5cfe74  mov r11d, r11d
00007d516e5cfe77  mov [r15+0x88], r11
00007d516e5cfe7e  mov [rsp+0x20], r14d
00007d516e5cfe83  shr r14d, 0x03
00007d516e5cfe87  xor eax, r14d
00007d516e5cfe8a  mov [rsp+0x30], eax
00007d516e5cfe8e  mov eax, eax
00007d516e5cfe90  mov [r15+0x80], rax
00007d516e5cfe97  shr r10d, 0x0A
00007d516e5cfe9b  mov eax, [rsp+0x10]
00007d516e5cfe9f  xor eax, r10d
00007d516e5cfea2  mov [rsp+0x10], eax
00007d516e5cfea6  mov eax, eax
00007d516e5cfea8  mov [r15+0x78], rax
00007d516e5cfeac  mov eax, [rsp+0x30]
00007d516e5cfeb0  lea r14d, [ebp+eax*1]
00007d516e5cfeb6  mov eax, [rsp+0x10]
00007d516e5cfeba  lea r11d, [r14d+eax*1]
00007d516e5cfebf  lea rax, [r12+0x40]
00007d516e5cfec4  mov [r13+rax*1], r11d
00007d516e5cfec9  mov eax, [rsp+0x20]
00007d516e5cfecd  mov eax, eax
00007d516e5cfecf  mov [r15+0x60], rax
00007d516e5cfed3  mov eax, [r15+0x108]
00007d516e5cfeda  sahf
00007d516e5cfedb  jnz 0x00007D516E5CFF0D
00007d516e5cfedd  cmp dword ptr [r15+0x318], 0x00
00007d516e5cfee5  jz 0x00007D516E5CFF70
00007d516e5cfeeb  nop [rax+rax*1], ax
00007d516e5cfef4  nop [rax+rax*1], eax
00007d516e5cfefc  mov eax, 0x41088C
00007d516e5cff01  mov [r15+0x100], rax
00007d516e5cff08  jmp 0x00007D516E3FE110
00007d516e5cff0d  cmp dword ptr [r15+0x318], 0x00
00007d516e5cff15  jz 0x00007D516E5CFDC0
00007d516e5cff1b  nop [rax+rax*1], ax
00007d516e5cff24  nop [rax+rax*1], eax
00007d516e5cff2c  mov eax, 0x410844
00007d516e5cff31  mov [r15+0x100], rax
00007d516e5cff38  jmp 0x00007D516E3FE110
00007d516e5cff3d  int3
00007d516e5cff3e  call 0x00007D516E4E1430
00007d516e5cff43  jmp 0x00007D516E5CFDE2
00007d516e5cff48  call 0x00007D516E4E1430
00007d516e5cff4d  jmp 0x00007D516E5CFDF8
00007d516e5cff52  call 0x00007D516E4E01C0
00007d516e5cff57  jmp 0x00007D516E5CFE02
00007d516e5cff5c  call 0x00007D516E40A860
00007d516e5cff61  jmp 0x00007D516E5CFEC9
00007d516e5cff66  int3
00007d516e5cff67  nop [rax+rax*1], ax
00007d516e5cff70  mov rax, [r15]
00007d516e5cff73  mov r14d, [r13+rax*1]
00007d516e5cff78  lea r12, [rax+0x04]
00007d516e5cff7c  mov r11d, [r13+r12*1]
00007d516e5cff81  mov [rsp+0x10], r14d
00007d516e5cff86  mov r14d, r14d
00007d516e5cff89  mov [r15+0x78], r14
00007d516e5cff8d  mov [rsp+0x20], r11d
00007d516e5cff92  mov r11d, r11d
00007d516e5cff95  mov [r15+0x80], r11
00007d516e5cff9c  lea r14, [rax+0x08]
00007d516e5cffa0  mov r12d, [r13+r14*1]
00007d516e5cffa5  lea r14, [rax+0x0C]
00007d516e5cffa9  mov r11d, [r13+r14*1]
00007d516e5cffae  mov [rsp+0x30], r12d
00007d516e5cffb3  mov r12d, r12d
00007d516e5cffb6  mov [r15+0x70], r12
00007d516e5cffba  mov [rsp+0x40], r11d
00007d516e5cffbf  mov r11d, r11d
00007d516e5cffc2  mov [r15+0x68], r11
00007d516e5cffc6  lea r14, [rax+0x18]
00007d516e5cffca  mov r12d, [r13+r14*1]
00007d516e5cffcf  lea r14, [rax+0x1C]
00007d516e5cffd3  mov r11d, [r13+r14*1]
00007d516e5cffd8  mov [rsp+0x50], r12d
00007d516e5cffdd  mov r12d, r12d
00007d516e5cffe0  mov [r15+0x58], r12
00007d516e5cffe4  mov [rsp+0x60], r11d
00007d516e5cffe9  mov r11d, r11d
00007d516e5cffec  mov [r15+0x60], r11
00007d516e5cfff0  lea r14, [rax+0x10]
00007d516e5cfff4  mov r12d, [r13+r14*1]
00007d516e5cfff9  lea r14, [rax+0x14]
00007d516e5cfffd  mov eax, [r13+r14*1]
00007d516e5d0002  mov [rsp+0x70], r12d
00007d516e5d0007  mov r12d, r12d
00007d516e5d000a  mov [r15+0x18], r12
00007d516e5d000e  mov [rsp+0x80], eax
00007d516e5d0015  mov eax, eax
00007d516e5d0017  mov [r15+0x90], rax
00007d516e5d001e  mov eax, [rsp+0x70]
00007d516e5d0022  mov eax, eax
00007d516e5d0024  mov [r15+0x30], rax
00007d516e5d0028  mov eax, [rsp+0x50]
00007d516e5d002c  mov eax, eax
00007d516e5d002e  mov [r15+0xA0], rax
00007d516e5d0035  mov eax, [rsp+0x30]
00007d516e5d0039  mov eax, eax
00007d516e5d003b  mov [r15+0x28], rax
00007d516e5d003f  mov eax, [rsp+0x20]
00007d516e5d0043  mov eax, eax
00007d516e5d0045  mov [r15+0x98], rax
00007d516e5d004c  mov eax, [rsp+0x10]
00007d516e5d0050  mov eax, eax
00007d516e5d0052  mov [r15+0x38], rax
00007d516e5d0056  mov eax, [rsp+0x70]
00007d516e5d005a  mov r14d, [rsp+0x70]
00007d516e5d005f  shrd eax, r14d, 0x06
00007d516e5d0064  mov [rsp+0x70], r14d
00007d516e5d0069  mov r12d, [rsp+0x80]
00007d516e5d0071  and r14d, r12d
00007d516e5d0074  mov r11d, [rsp+0x10]
00007d516e5d0079  mov r10d, [rsp+0x10]
00007d516e5d007e  shrd r11d, r10d, 0x02
00007d516e5d0083  mov [rsp+0x10], r12d
00007d516e5d0088  mov r12d, r12d
00007d516e5d008b  mov [r15+0x20], r12
00007d516e5d008f  mov r12, [r15+0x50]
00007d516e5d0093  mov r9d, [r13+r12*1]
00007d516e5d0098  mov r12d, [rsp+0x50]
00007d516e5d009d  mov r8d, [rsp+0x70]
00007d516e5d00a2  andn ebp, r8d, r12d
00007d516e5d00a7  mov edi, [rsp+0x60]
00007d516e5d00ab  lea esi, [r14d+edi*1]
00007d516e5d00b0  rorx r14d, r8d, 0x0B
00007d516e5d00b6  xor eax, r14d
00007d516e5d00b9  rorx r14d, r10d, 0x0D
00007d516e5d00bf  xor r11d, r14d
00007d516e5d00c2  lea edi, [esi+ebp*1]
00007d516e5d00c6  mov r14, [r15+0x48]
00007d516e5d00ca  mov ebp, [r13+r14*1]
00007d516e5d00cf  mov r14d, [rsp+0x30]
00007d516e5d00d4  mov esi, [rsp+0x20]
00007d516e5d00d8  and r14d, esi
00007d516e5d00db  mov [rsp+0x20], r14d
00007d516e5d00e0  mov r14d, r14d
00007d516e5d00e3  mov [r15+0xD8], r14
00007d516e5d00ea  lea r14d, [edi+r9d*1]
00007d516e5d00ef  mov r9d, [rsp+0x30]
00007d516e5d00f4  xor r9d, esi
00007d516e5d00f7  rorx edi, r8d, 0x19
00007d516e5d00fd  xor eax, edi
00007d516e5d00ff  and r9d, r10d
00007d516e5d0102  rorx edi, r10d, 0x16
00007d516e5d0108  xor r11d, edi
00007d516e5d010b  mov [rsp+0x30], r11d
00007d516e5d0110  mov r11d, r11d
00007d516e5d0113  mov [r15+0xD0], r11
00007d516e5d011a  lea r11d, [r14d+ebp*1]
00007d516e5d011f  mov r10d, [rsp+0x20]
00007d516e5d0124  xor r9d, r10d
00007d516e5d0127  lea r14d, [r11d+eax*1]
00007d516e5d012c  mov qword ptr [r15+0x88], 0x04
00007d516e5d0137  mov eax, [rsp+0x30]
00007d516e5d013b  lea r11d, [r9d+eax*1]
00007d516e5d0140  mov eax, [rsp+0x40]
00007d516e5d0144  lea r10d, [r14d+eax*1]
00007d516e5d0149  mov r10d, r10d
00007d516e5d014c  mov [r15+0xB8], r10
00007d516e5d0153  xor eax, eax
00007d516e5d0155  mov r10d, 0x04
00007d516e5d015b  mov r9d, 0x100
00007d516e5d0161  cmp r10, r9
00007d516e5d0164  cmc
00007d516e5d0165  lahf
00007d516e5d0166  seto al
00007d516e5d0169  mov [r15+0x108], eax
00007d516e5d0170  lea eax, [r11d+r14d*1]
00007d516e5d0175  mov eax, eax
00007d516e5d0177  mov [r15+0xA8], rax
00007d516e5d017e  mov r12d, r12d
00007d516e5d0181  mov [r15+0xB0], r12
00007d516e5d0188  mov eax, [rsp+0x10]
00007d516e5d018c  mov eax, eax
00007d516e5d018e  mov [r15+0xC0], rax
00007d516e5d0195  mov r8d, r8d
00007d516e5d0198  mov [r15+0xC8], r8
00007d516e5d019f  mov eax, [r15+0x108]
00007d516e5d01a6  sahf
00007d516e5d01a7  jnz 0x00007D516E5D01D9
00007d516e5d01a9  cmp dword ptr [r15+0x318], 0x00
00007d516e5d01b1  jz 0x00007D516E5D04A0
00007d516e5d01b7  nop [rax+rax*1], ax
00007d516e5d01c0  nop [rax+rax*1], eax
00007d516e5d01c8  mov eax, 0x41094C
00007d516e5d01cd  mov [r15+0x100], rax
00007d516e5d01d4  jmp 0x00007D516E3FE110
00007d516e5d01d9  cmp dword ptr [r15+0x318], 0x00
00007d516e5d01e1  jz 0x00007D516E5D0270
00007d516e5d01e7  nop [rax+rax*1], ax
00007d516e5d01f0  nop [rax+rax*1], eax
00007d516e5d01f8  mov eax, 0x4108C0
00007d516e5d01fd  mov [r15+0x100], rax
00007d516e5d0204  jmp 0x00007D516E3FE110
00007d516e5d0209  int3
00007d516e5d020a  call 0x00007D516E40DAE0
00007d516e5d020f  jmp 0x00007D516E5CFF78
00007d516e5d0214  call 0x00007D516E4C0230
00007d516e5d0219  jmp 0x00007D516E5CFF81
00007d516e5d021e  call 0x00007D516E4E26A0
00007d516e5d0223  jmp 0x00007D516E5CFFA5
00007d516e5d0228  call 0x00007D516E4E1430
00007d516e5d022d  jmp 0x00007D516E5CFFAE
00007d516e5d0232  call 0x00007D516E4E26A0
00007d516e5d0237  jmp 0x00007D516E5CFFCF
00007d516e5d023c  call 0x00007D516E4E1430
00007d516e5d0241  jmp 0x00007D516E5CFFD8
00007d516e5d0246  call 0x00007D516E4E26A0
00007d516e5d024b  jmp 0x00007D516E5CFFF9
00007d516e5d0250  call 0x00007D516E4D5890
00007d516e5d0255  jmp 0x00007D516E5D0002
00007d516e5d025a  call 0x00007D516E4BDD50
00007d516e5d025f  jmp 0x00007D516E5D0098
00007d516e5d0264  call 0x00007D516E4DA580
00007d516e5d0269  jmp 0x00007D516E5D00CF
00007d516e5d026e  int3
00007d516e5d026f  nop
00007d516e5d0270  mov eax, [r15+0xB8]
00007d516e5d0277  mov [rsp+0x10], eax
00007d516e5d027b  mov eax, eax
00007d516e5d027d  mov [r15+0x30], rax
00007d516e5d0281  mov eax, [r15+0xC0]
00007d516e5d0288  mov [rsp+0x20], eax
00007d516e5d028c  mov eax, eax
00007d516e5d028e  mov [r15+0xA0], rax
00007d516e5d0295  mov eax, [r15+0x28]
00007d516e5d0299  mov r14d, [r15+0x98]
00007d516e5d02a0  mov [rsp+0x30], r14d
00007d516e5d02a5  mov r14d, r14d
00007d516e5d02a8  mov [r15+0x28], r14
00007d516e5d02ac  mov r14d, [r15+0x38]
00007d516e5d02b0  mov [rsp+0x40], r14d
00007d516e5d02b5  mov r14d, r14d
00007d516e5d02b8  mov [r15+0x98], r14
00007d516e5d02bf  mov r14d, [r15+0xA8]
00007d516e5d02c6  mov [rsp+0x50], r14d
00007d516e5d02cb  mov r14d, r14d
00007d516e5d02ce  mov [r15+0x38], r14
00007d516e5d02d2  mov r14d, [rsp+0x10]
00007d516e5d02d7  mov r12d, [rsp+0x10]
00007d516e5d02dc  shrd r14d, r12d, 0x06
00007d516e5d02e1  mov r11d, [r15+0xC8]
00007d516e5d02e8  mov [rsp+0x10], r12d
00007d516e5d02ed  and r12d, r11d
00007d516e5d02f0  mov r10d, [rsp+0x50]
00007d516e5d02f5  mov r9d, [rsp+0x50]
00007d516e5d02fa  shrd r10d, r9d, 0x02
00007d516e5d02ff  mov [rsp+0x50], r11d
00007d516e5d0304  mov r11d, r11d
00007d516e5d0307  mov [r15+0x20], r11
00007d516e5d030b  mov r11, [r15+0x88]
00007d516e5d0312  mov r8, [r15+0x50]
00007d516e5d0316  lea rbp, [r8+r11*1]
00007d516e5d031a  mov r8d, [r13+rbp*1]
00007d516e5d031f  mov ebp, [rsp+0x20]
00007d516e5d0323  mov edi, [rsp+0x10]
00007d516e5d0327  andn esi, edi, ebp
00007d516e5d032c  mov edx, [r15+0xB0]
00007d516e5d0333  lea ecx, [r12d+edx*1]
00007d516e5d0338  rorx r12d, edi, 0x0B
00007d516e5d033e  xor r14d, r12d
00007d516e5d0341  rorx r12d, r9d, 0x0D
00007d516e5d0347  xor r10d, r12d
00007d516e5d034a  lea r12d, [ecx+esi*1]
00007d516e5d034f  mov rsi, [r15+0x48]
00007d516e5d0353  lea rdx, [rsi+r11*1]
00007d516e5d0357  mov esi, [r13+rdx*1]
00007d516e5d035c  mov edx, [rsp+0x30]
00007d516e5d0360  mov ecx, [rsp+0x40]
00007d516e5d0364  and edx, ecx
00007d516e5d0366  mov [rsp+0x10], edx
00007d516e5d036a  mov edx, edx
00007d516e5d036c  mov [r15+0xD8], rdx
00007d516e5d0373  lea edx, [r12d+r8d*1]
00007d516e5d0378  mov r12d, [rsp+0x30]
00007d516e5d037d  xor r12d, ecx
00007d516e5d0380  rorx r8d, edi, 0x19
00007d516e5d0386  xor r14d, r8d
00007d516e5d0389  and r12d, r9d
00007d516e5d038c  rorx r8d, r9d, 0x16
00007d516e5d0392  xor r10d, r8d
00007d516e5d0395  mov [rsp+0x20], r10d
00007d516e5d039a  mov r10d, r10d
00007d516e5d039d  mov [r15+0xD0], r10
00007d516e5d03a4  lea r10d, [edx+esi*1]
00007d516e5d03a9  mov r9d, [rsp+0x10]
00007d516e5d03ae  xor r12d, r9d
00007d516e5d03b1  lea r9d, [r10d+r14d*1]
00007d516e5d03b6  lea r14, [r11+0x04]
00007d516e5d03ba  mov [r15+0x88], r14
00007d516e5d03c1  mov r11d, [rsp+0x20]
00007d516e5d03c6  lea r10d, [r12d+r11d*1]
00007d516e5d03cb  lea r11d, [r9d+eax*1]
00007d516e5d03d0  mov r11d, r11d
00007d516e5d03d3  mov [r15+0xB8], r11
00007d516e5d03da  xor eax, eax
00007d516e5d03dc  mov r12d, 0x100
00007d516e5d03e2  cmp r14, r12
00007d516e5d03e5  cmc
00007d516e5d03e6  lahf
00007d516e5d03e7  seto al
00007d516e5d03ea  mov [r15+0x108], eax
00007d516e5d03f1  lea eax, [r10d+r9d*1]
00007d516e5d03f6  mov eax, eax
00007d516e5d03f8  mov [r15+0xA8], rax
00007d516e5d03ff  mov ebp, ebp
00007d516e5d0401  mov [r15+0xB0], rbp
00007d516e5d0408  mov eax, [rsp+0x50]
00007d516e5d040c  mov eax, eax
00007d516e5d040e  mov [r15+0xC0], rax
00007d516e5d0415  mov edi, edi
00007d516e5d0417  mov [r15+0xC8], rdi
00007d516e5d041e  mov eax, [r15+0x108]
00007d516e5d0425  sahf
00007d516e5d0426  jnz 0x00007D516E5D0458
00007d516e5d0428  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0430  jz 0x00007D516E5D04A0
00007d516e5d0436  nop [rax+rax*1], ax
00007d516e5d043f  nop [rax+rax*1], eax
00007d516e5d0447  mov eax, 0x41094C
00007d516e5d044c  mov [r15+0x100], rax
00007d516e5d0453  jmp 0x00007D516E3FE110
00007d516e5d0458  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0460  jz 0x00007D516E5D0270
00007d516e5d0466  nop [rax+rax*1], ax
00007d516e5d046f  nop [rax+rax*1], eax
00007d516e5d0477  mov eax, 0x4108C0
00007d516e5d047c  mov [r15+0x100], rax
00007d516e5d0483  jmp 0x00007D516E3FE110
00007d516e5d0488  int3
00007d516e5d0489  call 0x00007D516E449010
00007d516e5d048e  jmp 0x00007D516E5D031F
00007d516e5d0493  call 0x00007D516E425930
00007d516e5d0498  jmp 0x00007D516E5D035C
00007d516e5d049d  int3
00007d516e5d049e  nop
00007d516e5d04a0  mov eax, [r15+0x98]
00007d516e5d04a7  mov r14d, [r15+0x70]
00007d516e5d04ab  lea r12d, [eax+r14d*1]
00007d516e5d04b0  mov eax, [r15+0x28]
00007d516e5d04b4  mov r14d, [r15+0x68]
00007d516e5d04b8  lea r11d, [eax+r14d*1]
00007d516e5d04bd  mov qword ptr [r15+0x88], 0x00
00007d516e5d04c8  mov eax, [r15+0xA8]
00007d516e5d04cf  mov r14d, [r15+0x78]
00007d516e5d04d3  lea r10d, [eax+r14d*1]
00007d516e5d04d8  mov [rsp+0x10], r10d
00007d516e5d04dd  mov r10d, r10d
00007d516e5d04e0  mov [r15+0x78], r10
00007d516e5d04e4  mov eax, [r15+0x38]
00007d516e5d04e8  mov r14d, [r15+0x80]
00007d516e5d04ef  lea r10d, [eax+r14d*1]
00007d516e5d04f4  mov [rsp+0x20], r10d
00007d516e5d04f9  mov r10d, r10d
00007d516e5d04fc  mov [r15+0x80], r10
00007d516e5d0503  mov rax, [r15]
00007d516e5d0506  lea r14, [rax+0x08]
00007d516e5d050a  mov [r13+r14*1], r12d
00007d516e5d050f  lea r14, [rax+0x0C]
00007d516e5d0513  mov [r13+r14*1], r11d
00007d516e5d0518  mov r14d, [r15+0xB8]
00007d516e5d051f  mov r12d, [r15+0x18]
00007d516e5d0523  lea r11d, [r14d+r12d*1]
00007d516e5d0528  mov [rsp+0x30], r11d
00007d516e5d052d  mov r11d, r11d
00007d516e5d0530  mov [r15+0x68], r11
00007d516e5d0534  mov r14d, [r15+0x30]
00007d516e5d0538  mov r12d, [r15+0x90]
00007d516e5d053f  lea r11d, [r14d+r12d*1]
00007d516e5d0544  mov [rsp+0x40], r11d
00007d516e5d0549  mov r11d, r11d
00007d516e5d054c  mov [r15+0x70], r11
00007d516e5d0550  mov r14d, [r15+0x20]
00007d516e5d0554  mov r12d, [r15+0x58]
00007d516e5d0558  lea r11d, [r14d+r12d*1]
00007d516e5d055d  mov [rsp+0x50], r11d
00007d516e5d0562  mov r11d, r11d
00007d516e5d0565  mov [r15+0x58], r11
00007d516e5d0569  mov r14d, [r15+0xA0]
00007d516e5d0570  mov r12d, [r15+0x60]
00007d516e5d0574  lea r11d, [r14d+r12d*1]
00007d516e5d0579  mov [rsp+0x60], r11d
00007d516e5d057e  mov r11d, r11d
00007d516e5d0581  mov [r15+0x60], r11
00007d516e5d0585  mov r14d, [rsp+0x10]
00007d516e5d058a  mov [r13+rax*1], r14d
00007d516e5d058f  lea r14, [rax+0x04]
00007d516e5d0593  mov r12d, [rsp+0x20]
00007d516e5d0598  mov [r13+r14*1], r12d
00007d516e5d059d  lea r14, [rax+0x10]
00007d516e5d05a1  mov r12d, [rsp+0x30]
00007d516e5d05a6  mov [r13+r14*1], r12d
00007d516e5d05ab  lea r14, [rax+0x14]
00007d516e5d05af  mov r12d, [rsp+0x40]
00007d516e5d05b4  mov [r13+r14*1], r12d
00007d516e5d05b9  lea r14, [rax+0x18]
00007d516e5d05bd  mov r12d, [rsp+0x50]
00007d516e5d05c2  mov [r13+r14*1], r12d
00007d516e5d05c7  lea r14, [rax+0x1C]
00007d516e5d05cb  mov r12d, [rsp+0x60]
00007d516e5d05d0  mov [r13+r14*1], r12d
00007d516e5d05d5  lea r14, [rax+0x68]
00007d516e5d05d9  xor eax, eax
00007d516e5d05db  mov [r13+r14*1], rax
00007d516e5d05e0  cmp dword ptr [r15+0x318], 0x00
00007d516e5d05e8  jz 0x00007D516E5CF0E0
00007d516e5d05ee  nop [rax+rax*1], ax
00007d516e5d05f7  nop [rax+rax*1], eax
00007d516e5d05ff  mov eax, 0x410768
00007d516e5d0604  mov [r15+0x100], rax
00007d516e5d060b  jmp 0x00007D516E3FE110
00007d516e5d0610  int3
00007d516e5d0611  call 0x00007D516E4E2BA0
00007d516e5d0616  jmp 0x00007D516E5D050F
00007d516e5d061b  call 0x00007D516E4E1920
00007d516e5d0620  jmp 0x00007D516E5D0518
00007d516e5d0625  call 0x00007D516E40DFE0
00007d516e5d062a  jmp 0x00007D516E5D058F
00007d516e5d062f  call 0x00007D516E4E2BA0
00007d516e5d0634  jmp 0x00007D516E5D059D
00007d516e5d0639  call 0x00007D516E4E2BA0
00007d516e5d063e  jmp 0x00007D516E5D05AB
00007d516e5d0643  call 0x00007D516E4E2BA0
00007d516e5d0648  jmp 0x00007D516E5D05B9
00007d516e5d064d  call 0x00007D516E4E2BA0
00007d516e5d0652  jmp 0x00007D516E5D05C7
00007d516e5d0657  call 0x00007D516E4E2BA0
00007d516e5d065c  jmp 0x00007D516E5D05D5
00007d516e5d0661  call 0x00007D516E4D5EB0
00007d516e5d0666  jmp 0x00007D516E5D05E0
00007d516e5d066b  int3
00007d516e5d066c  nop [rax], eax
00007d516e5d0670  mov rax, [r15+0xF8]
00007d516e5d0677  lea r14, [rax+0x140]
00007d516e5d067e  mov r12, [r13+r14*1]
00007d516e5d0683  lea r14, [rax+0x148]
00007d516e5d068a  mov r11, [r13+r14*1]
00007d516e5d068f  mov [r15+0xA0], r12
00007d516e5d0696  mov [r15+0x98], r11
00007d516e5d069d  lea r14, [rax+0x130]
00007d516e5d06a4  mov r12, [r13+r14*1]
00007d516e5d06a9  lea r14, [rax+0x138]
00007d516e5d06b0  mov r11, [r13+r14*1]
00007d516e5d06b5  mov [r15+0xB0], r12
00007d516e5d06bc  mov [r15+0xA8], r11
00007d516e5d06c3  lea r14, [rax+0x120]
00007d516e5d06ca  mov r12, [r13+r14*1]
00007d516e5d06cf  lea r14, [rax+0x128]
00007d516e5d06d6  mov r11, [r13+r14*1]
00007d516e5d06db  mov [r15+0xC0], r12
00007d516e5d06e2  mov [r15+0xB8], r11
00007d516e5d06e9  lea r14, [rax+0x110]
00007d516e5d06f0  mov r12, [r13+r14*1]
00007d516e5d06f5  lea r14, [rax+0x118]
00007d516e5d06fc  mov r11, [r13+r14*1]
00007d516e5d0701  mov [r15+0xD0], r12
00007d516e5d0708  mov [r15+0xC8], r11
00007d516e5d070f  lea r14, [rax+0x100]
00007d516e5d0716  mov r12, [r13+r14*1]
00007d516e5d071b  lea r14, [rax+0x108]
00007d516e5d0722  mov r11, [r13+r14*1]
00007d516e5d0727  mov [r15+0xE8], r12
00007d516e5d072e  mov [r15+0xD8], r11
00007d516e5d0735  lea r14, [rax+0x150]
00007d516e5d073c  mov [r15+0xF8], r14
00007d516e5d0743  mov rax, [r15+0xF0]
00007d516e5d074a  mov [r15+0x100], rax
00007d516e5d0751  jmp 0x00007D516E5CE5C0
00007d516e5d0756  int3
00007d516e5d0757  call 0x00007D516E4E27E0
00007d516e5d075c  jmp 0x00007D516E5D0683
00007d516e5d0761  call 0x00007D516E4E1570
00007d516e5d0766  jmp 0x00007D516E5D068F
00007d516e5d076b  call 0x00007D516E4E27E0
00007d516e5d0770  jmp 0x00007D516E5D06A9
00007d516e5d0775  call 0x00007D516E4E1570
00007d516e5d077a  jmp 0x00007D516E5D06B5
00007d516e5d077f  call 0x00007D516E4E27E0
00007d516e5d0784  jmp 0x00007D516E5D06CF
00007d516e5d0789  call 0x00007D516E4E1570
00007d516e5d078e  jmp 0x00007D516E5D06DB
00007d516e5d0793  call 0x00007D516E4E27E0
00007d516e5d0798  jmp 0x00007D516E5D06F5
00007d516e5d079d  call 0x00007D516E4E1570
00007d516e5d07a2  jmp 0x00007D516E5D0701
00007d516e5d07a7  call 0x00007D516E4E27E0
00007d516e5d07ac  jmp 0x00007D516E5D071B
00007d516e5d07b1  call 0x00007D516E4E1570
00007d516e5d07b6  jmp 0x00007D516E5D0727
00007d516e5d07bb  int3
00007d516e5d07bc  nop [rax], eax
00007d516e5d07c0  mov eax, [r15+0xA0]
00007d516e5d07c7  mov [rsp+0x10], eax
00007d516e5d07cb  xor eax, eax
00007d516e5d07cd  mov r14d, [rsp+0x10]
00007d516e5d07d2  sub r14d, 0x01
00007d516e5d07d6  cmc
00007d516e5d07d7  lahf
00007d516e5d07d8  seto al
00007d516e5d07db  mov [r15+0x108], eax
00007d516e5d07e2  mov r14d, r14d
00007d516e5d07e5  mov [r15+0xA0], r14
00007d516e5d07ec  mov eax, [r15+0x108]
00007d516e5d07f3  sahf
00007d516e5d07f4  jnz 0x00007D516E5D0826
00007d516e5d07f6  cmp dword ptr [r15+0x318], 0x00
00007d516e5d07fe  jz 0x00007D516E5D0900
00007d516e5d0804  nop [rax+rax*1], ax
00007d516e5d080d  nop [rax+rax*1], eax
00007d516e5d0815  mov eax, 0x41028C
00007d516e5d081a  mov [r15+0x100], rax
00007d516e5d0821  jmp 0x00007D516E3FE110
00007d516e5d0826  cmp dword ptr [r15+0x318], 0x00
00007d516e5d082e  jz 0x00007D516E5D0860
00007d516e5d0834  nop [rax+rax*1], ax
00007d516e5d083d  nop [rax+rax*1], eax
00007d516e5d0845  mov eax, 0x410274
00007d516e5d084a  mov [r15+0x100], rax
00007d516e5d0851  jmp 0x00007D516E3FE110
00007d516e5d0856  int3
00007d516e5d0857  int3
00007d516e5d0858  nop [rax+rax*1], eax
00007d516e5d0860  mov rax, [r15+0xF8]
00007d516e5d0867  lea r14, [rax+0x100]
00007d516e5d086e  mov [r15], r14
00007d516e5d0871  mov rax, [r15+0x98]
00007d516e5d0878  mov [r15+0x08], rax
00007d516e5d087c  mov qword ptr [r15+0x10], 0x12C
00007d516e5d0884  mov qword ptr [r15+0xF0], 0x410284
00007d516e5d088f  mov r14d, [r15+0x320]
00007d516e5d0896  mov eax, 0x410284
00007d516e5d089b  mov rcx, 0x7D516E5D07C0
00007d516e5d08a5  mov [r15+r14*8+0x328], rax
00007d516e5d08ad  mov [r15+r14*8+0x368], rcx
00007d516e5d08b5  add r14d, 0x01
00007d516e5d08b9  and r14d, 0x07
00007d516e5d08bd  mov [r15+0x320], r14d
00007d516e5d08c4  cmp dword ptr [r15+0x318], 0x00
00007d516e5d08cc  jz 0x00007D516E5CED70
00007d516e5d08d2  nop [rax+rax*1], ax
00007d516e5d08db  nop [rax+rax*1], eax
00007d516e5d08e3  mov eax, 0x410728
00007d516e5d08e8  mov [r15+0x100], rax
00007d516e5d08ef  jmp 0x00007D516E3FE110
00007d516e5d08f4  int3
00007d516e5d08f5  int3
00007d516e5d08f6  nop [rax+rax*1], ax
00007d516e5d08ff  nop
00007d516e5d0900  mov rax, [r15+0xF8]
00007d516e5d0907  lea r14, [rax+0x120]
00007d516e5d090e  mov r12, [r13+r14*1]
00007d516e5d0913  mov [r15+0x98], r12
00007d516e5d091a  mov qword ptr [r15+0x40], 0x80
00007d516e5d0922  lea r14, [rax+0x100]
00007d516e5d0929  mov [r15], r14
00007d516e5d092c  lea r14, [rax+0x17C]
00007d516e5d0933  mov [r15+0x08], r14
00007d516e5d0937  mov qword ptr [r15+0x10], 0x01
00007d516e5d093f  lea r14, [rax+0x17C]
00007d516e5d0946  mov eax, 0x80
00007d516e5d094b  mov [r13+r14*1], al
00007d516e5d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007d516e5d095b  mov r14d, [r15+0x320]
00007d516e5d0962  mov eax, 0x4102A8
00007d516e5d0967  mov rcx, 0x7D516E5D09E0
00007d516e5d0971  mov [r15+r14*8+0x328], rax
00007d516e5d0979  mov [r15+r14*8+0x368], rcx
00007d516e5d0981  add r14d, 0x01
00007d516e5d0985  and r14d, 0x07
00007d516e5d0989  mov [r15+0x320], r14d
00007d516e5d0990  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0998  jz 0x00007D516E5CED70
00007d516e5d099e  nop [rax+rax*1], ax
00007d516e5d09a7  nop [rax+rax*1], eax
00007d516e5d09af  mov eax, 0x410728
00007d516e5d09b4  mov [r15+0x100], rax
00007d516e5d09bb  jmp 0x00007D516E3FE110
00007d516e5d09c0  int3
00007d516e5d09c1  call 0x00007D516E4E27E0
00007d516e5d09c6  jmp 0x00007D516E5D0913
00007d516e5d09cb  call 0x00007D516E4D5AF0
00007d516e5d09d0  jmp 0x00007D516E5D0950
00007d516e5d09d5  int3
00007d516e5d09d6  nop [rax+rax*1], ax
00007d516e5d09df  nop
00007d516e5d09e0  mov rax, [r15+0xF8]
00007d516e5d09e7  lea r14, [rax+0x168]
00007d516e5d09ee  mov r12, [r13+r14*1]
00007d516e5d09f3  mov [r15+0x40], r12
00007d516e5d09f7  lea r14, [rax+0x178]
00007d516e5d09fe  xor eax, eax
00007d516e5d0a00  mov [r13+r14*1], al
00007d516e5d0a05  xor eax, eax
00007d516e5d0a07  mov r14d, 0x38
00007d516e5d0a0d  cmp r12, r14
00007d516e5d0a10  cmc
00007d516e5d0a11  lahf
00007d516e5d0a12  seto al
00007d516e5d0a15  mov [r15+0x108], eax
00007d516e5d0a1c  mov eax, [r15+0x108]
00007d516e5d0a23  sahf
00007d516e5d0a24  jz 0x00007D516E5D0A56
00007d516e5d0a26  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0a2e  jz 0x00007D516E5D0AA0
00007d516e5d0a34  nop [rax+rax*1], ax
00007d516e5d0a3d  nop [rax+rax*1], eax
00007d516e5d0a45  mov eax, 0x4102B8
00007d516e5d0a4a  mov [r15+0x100], rax
00007d516e5d0a51  jmp 0x00007D516E3FE110
00007d516e5d0a56  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0a5e  jz 0x00007D516E5D0BF0
00007d516e5d0a64  nop [rax+rax*1], ax
00007d516e5d0a6d  nop [rax+rax*1], eax
00007d516e5d0a75  mov eax, 0x4102D4
00007d516e5d0a7a  mov [r15+0x100], rax
00007d516e5d0a81  jmp 0x00007D516E3FE110
00007d516e5d0a86  int3
00007d516e5d0a87  call 0x00007D516E4E27E0
00007d516e5d0a8c  jmp 0x00007D516E5D09F3
00007d516e5d0a91  call 0x00007D516E4D5AF0
00007d516e5d0a96  jmp 0x00007D516E5D0A05
00007d516e5d0a9b  int3
00007d516e5d0a9c  nop [rax], eax
00007d516e5d0aa0  mov rax, [r15+0xF8]
00007d516e5d0aa7  lea r14, [rax+0x100]
00007d516e5d0aae  mov [r15], r14
00007d516e5d0ab1  lea r14, [rax+0x178]
00007d516e5d0ab8  mov [r15+0x08], r14
00007d516e5d0abc  mov qword ptr [r15+0x10], 0x01
00007d516e5d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007d516e5d0acf  mov r14d, [r15+0x320]
00007d516e5d0ad6  mov eax, 0x4102C8
00007d516e5d0adb  mov rcx, 0x7D516E5D0B40
00007d516e5d0ae5  mov [r15+r14*8+0x328], rax
00007d516e5d0aed  mov [r15+r14*8+0x368], rcx
00007d516e5d0af5  add r14d, 0x01
00007d516e5d0af9  and r14d, 0x07
00007d516e5d0afd  mov [r15+0x320], r14d
00007d516e5d0b04  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0b0c  jz 0x00007D516E5CED70
00007d516e5d0b12  nop [rax+rax*1], ax
00007d516e5d0b1b  nop [rax+rax*1], eax
00007d516e5d0b23  mov eax, 0x410728
00007d516e5d0b28  mov [r15+0x100], rax
00007d516e5d0b2f  jmp 0x00007D516E3FE110
00007d516e5d0b34  int3
00007d516e5d0b35  int3
00007d516e5d0b36  nop [rax+rax*1], ax
00007d516e5d0b3f  nop
00007d516e5d0b40  mov rax, [r15+0xF8]
00007d516e5d0b47  lea r14, [rax+0x168]
00007d516e5d0b4e  mov rax, [r13+r14*1]
00007d516e5d0b53  mov [r15+0x40], rax
00007d516e5d0b57  mov [rsp+0x10], rax
00007d516e5d0b5c  xor eax, eax
00007d516e5d0b5e  mov r14, [rsp+0x10]
00007d516e5d0b63  mov r12d, 0x38
00007d516e5d0b69  cmp r14, r12
00007d516e5d0b6c  cmc
00007d516e5d0b6d  lahf
00007d516e5d0b6e  seto al
00007d516e5d0b71  mov [r15+0x108], eax
00007d516e5d0b78  mov eax, [r15+0x108]
00007d516e5d0b7f  sahf
00007d516e5d0b80  jnz 0x00007D516E5D0BB2
00007d516e5d0b82  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0b8a  jz 0x00007D516E5D0BF0
00007d516e5d0b90  nop [rax+rax*1], ax
00007d516e5d0b99  nop [rax+rax*1], eax
00007d516e5d0ba1  mov eax, 0x4102D4
00007d516e5d0ba6  mov [r15+0x100], rax
00007d516e5d0bad  jmp 0x00007D516E3FE110
00007d516e5d0bb2  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0bba  jz 0x00007D516E5D0AA0
00007d516e5d0bc0  nop [rax+rax*1], ax
00007d516e5d0bc9  nop [rax+rax*1], eax
00007d516e5d0bd1  mov eax, 0x4102B8
00007d516e5d0bd6  mov [r15+0x100], rax
00007d516e5d0bdd  jmp 0x00007D516E3FE110
00007d516e5d0be2  int3
00007d516e5d0be3  call 0x00007D516E4D59C0
00007d516e5d0be8  jmp 0x00007D516E5D0B53
00007d516e5d0bed  int3
00007d516e5d0bee  nop
00007d516e5d0bf0  mov rax, [r15+0x98]
00007d516e5d0bf7  rorx r14, rax, 0x3D
00007d516e5d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007d516e5d0c01  mov rax, [r15+0xF8]
00007d516e5d0c08  lea r12, [rax+0x100]
00007d516e5d0c0f  mov [r15], r12
00007d516e5d0c12  lea r12, [rax+0x170]
00007d516e5d0c19  mov [r15+0x08], r12
00007d516e5d0c1d  mov qword ptr [r15+0x10], 0x08
00007d516e5d0c25  bswap r14
00007d516e5d0c28  mov [r15+0x40], r14
00007d516e5d0c2c  lea r12, [rax+0x170]
00007d516e5d0c33  mov [r13+r12*1], r14
00007d516e5d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007d516e5d0c43  mov r14d, [r15+0x320]
00007d516e5d0c4a  mov eax, 0x4102F0
00007d516e5d0c4f  mov rcx, 0x7D516E5D0CC0
00007d516e5d0c59  mov [r15+r14*8+0x328], rax
00007d516e5d0c61  mov [r15+r14*8+0x368], rcx
00007d516e5d0c69  add r14d, 0x01
00007d516e5d0c6d  and r14d, 0x07
00007d516e5d0c71  mov [r15+0x320], r14d
00007d516e5d0c78  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0c80  jz 0x00007D516E5CED70
00007d516e5d0c86  nop [rax+rax*1], ax
00007d516e5d0c8f  nop [rax+rax*1], eax
00007d516e5d0c97  mov eax, 0x410728
00007d516e5d0c9c  mov [r15+0x100], rax
00007d516e5d0ca3  jmp 0x00007D516E3FE110
00007d516e5d0ca8  int3
00007d516e5d0ca9  call 0x00007D516E4C3FE0
00007d516e5d0cae  jmp 0x00007D516E5D0C38
00007d516e5d0cb3  int3
00007d516e5d0cb4  nop [rax+rax*1], ax
00007d516e5d0cbd  nop [rax], eax
00007d516e5d0cc0  mov rax, [r15+0xF8]
00007d516e5d0cc7  lea r14, [rax+0x100]
00007d516e5d0cce  mov r12d, [r13+r14*1]
00007d516e5d0cd3  lea r14, [rax+0x104]
00007d516e5d0cda  mov r11d, [r13+r14*1]
00007d516e5d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007d516e5d0ce7  lea r14, [rax+0x108]
00007d516e5d0cee  mov r10d, [r13+r14*1]
00007d516e5d0cf3  lea r14, [rax+0x10C]
00007d516e5d0cfa  mov r9d, [r13+r14*1]
00007d516e5d0cff  bswap r12d
00007d516e5d0d02  bswap r11d
00007d516e5d0d05  mov qword ptr [r15+0xA0], 0x00
00007d516e5d0d10  mov r14d, 0x430C90
00007d516e5d0d16  mov [r13+r14*1], r12d
00007d516e5d0d1b  mov r14d, 0x430C94
00007d516e5d0d21  mov [r13+r14*1], r11d
00007d516e5d0d26  bswap r10d
00007d516e5d0d29  lea r14, [rax+0x110]
00007d516e5d0d30  mov r12d, [r13+r14*1]
00007d516e5d0d35  bswap r9d
00007d516e5d0d38  lea r14, [rax+0x114]
00007d516e5d0d3f  mov r11d, [r13+r14*1]
00007d516e5d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007d516e5d0d4f  mov r14d, 0x430C98
00007d516e5d0d55  mov [r13+r14*1], r10d
00007d516e5d0d5a  mov r14d, 0x430C9C
00007d516e5d0d60  mov [r13+r14*1], r9d
00007d516e5d0d65  bswap r12d
00007d516e5d0d68  lea r14, [rax+0x118]
00007d516e5d0d6f  mov r10d, [r13+r14*1]
00007d516e5d0d74  bswap r11d
00007d516e5d0d77  mov [rsp+0x10], r11d
00007d516e5d0d7c  mov r11d, r11d
00007d516e5d0d7f  mov [r15+0x58], r11
00007d516e5d0d83  lea r14, [rax+0x11C]
00007d516e5d0d8a  mov eax, [r13+r14*1]
00007d516e5d0d8f  mov [rsp+0x20], eax
00007d516e5d0d93  mov eax, eax
00007d516e5d0d95  mov [r15+0x60], rax
00007d516e5d0d99  mov eax, 0x430CA0
00007d516e5d0d9e  mov [r13+rax*1], r12d
00007d516e5d0da3  mov eax, 0x430CA4
00007d516e5d0da8  mov r14d, [rsp+0x10]
00007d516e5d0dad  mov [r13+rax*1], r14d
00007d516e5d0db2  bswap r10d
00007d516e5d0db5  mov [rsp+0x10], r10d
00007d516e5d0dba  mov r10d, r10d
00007d516e5d0dbd  mov [r15+0x40], r10
00007d516e5d0dc1  mov eax, [rsp+0x20]
00007d516e5d0dc5  bswap eax
00007d516e5d0dc7  mov [rsp+0x20], eax
00007d516e5d0dcb  mov eax, eax
00007d516e5d0dcd  mov [r15+0x50], rax
00007d516e5d0dd1  mov eax, 0x430CA8
00007d516e5d0dd6  mov r14d, [rsp+0x10]
00007d516e5d0ddb  mov [r13+rax*1], r14d
00007d516e5d0de0  mov eax, 0x430CAC
00007d516e5d0de5  mov r14d, [rsp+0x20]
00007d516e5d0dea  mov [r13+rax*1], r14d
00007d516e5d0def  mov eax, [r15+0xA0]
00007d516e5d0df6  lea r14d, [eax+0x11]
00007d516e5d0dfb  mov r14d, r14d
00007d516e5d0dfe  mov [r15], r14
00007d516e5d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007d516e5d0e0c  mov r14d, [r15+0x320]
00007d516e5d0e13  mov eax, 0x41035C
00007d516e5d0e18  mov rcx, 0x7D516E5D0F90
00007d516e5d0e22  mov [r15+r14*8+0x328], rax
00007d516e5d0e2a  mov [r15+r14*8+0x368], rcx
00007d516e5d0e32  add r14d, 0x01
00007d516e5d0e36  and r14d, 0x07
00007d516e5d0e3a  mov [r15+0x320], r14d
00007d516e5d0e41  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0e49  jz 0x00007D516E5D0F20
00007d516e5d0e4f  nop [rax+rax*1], ax
00007d516e5d0e58  nop [rax+rax*1], eax
00007d516e5d0e60  mov eax, 0x4109A4
00007d516e5d0e65  mov [r15+0x100], rax
00007d516e5d0e6c  jmp 0x00007D516E3FE110
00007d516e5d0e71  int3
00007d516e5d0e72  call 0x00007D516E4E26A0
00007d516e5d0e77  jmp 0x00007D516E5D0CD3
00007d516e5d0e7c  call 0x00007D516E4E1430
00007d516e5d0e81  jmp 0x00007D516E5D0CDF
00007d516e5d0e86  call 0x00007D516E4E01C0
00007d516e5d0e8b  jmp 0x00007D516E5D0CF3
00007d516e5d0e90  call 0x00007D516E4DEF50
00007d516e5d0e95  jmp 0x00007D516E5D0CFF
00007d516e5d0e9a  call 0x00007D516E4E2BA0
00007d516e5d0e9f  jmp 0x00007D516E5D0D1B
00007d516e5d0ea4  call 0x00007D516E4E1920
00007d516e5d0ea9  jmp 0x00007D516E5D0D26
00007d516e5d0eae  call 0x00007D516E4E26A0
00007d516e5d0eb3  jmp 0x00007D516E5D0D35
00007d516e5d0eb8  call 0x00007D516E4E1430
00007d516e5d0ebd  jmp 0x00007D516E5D0D44
00007d516e5d0ec2  call 0x00007D516E4E06B0
00007d516e5d0ec7  jmp 0x00007D516E5D0D5A
00007d516e5d0ecc  call 0x00007D516E4DF440
00007d516e5d0ed1  jmp 0x00007D516E5D0D65
00007d516e5d0ed6  call 0x00007D516E4E01C0
00007d516e5d0edb  jmp 0x00007D516E5D0D74
00007d516e5d0ee0  call 0x00007D516E4D5890
00007d516e5d0ee5  jmp 0x00007D516E5D0D8F
00007d516e5d0eea  call 0x00007D516E40BAE0
00007d516e5d0eef  jmp 0x00007D516E5D0DA3
00007d516e5d0ef4  call 0x00007D516E40DFE0
00007d516e5d0ef9  jmp 0x00007D516E5D0DB2
00007d516e5d0efe  call 0x00007D516E40DFE0
00007d516e5d0f03  jmp 0x00007D516E5D0DE0
00007d516e5d0f08  call 0x00007D516E40DFE0
00007d516e5d0f0d  jmp 0x00007D516E5D0DEF
00007d516e5d0f12  int3
00007d516e5d0f13  nop [rax+rax*1], ax
00007d516e5d0f1c  nop [rax], eax
00007d516e5d0f20  mov eax, [r15]
00007d516e5d0f23  mov [rsp+0x10], eax
00007d516e5d0f27  shr eax, 0x10
00007d516e5d0f2a  mov r14d, [rsp+0x10]
00007d516e5d0f2f  xor r14d, eax
00007d516e5d0f32  imul r14d, r14d, 0x7FEB352D
00007d516e5d0f39  mov eax, 0x846CA68B
00007d516e5d0f3e  mov eax, eax
00007d516e5d0f40  mov [r15+0x48], rax
00007d516e5d0f44  mov [rsp+0x10], r14d
00007d516e5d0f49  shr r14d, 0x0F
00007d516e5d0f4d  mov eax, [rsp+0x10]
00007d516e5d0f51  xor eax, r14d
00007d516e5d0f54  imul eax, eax, 0x846CA68B
00007d516e5d0f5a  mov [rsp+0x10], eax
00007d516e5d0f5e  mov eax, eax
00007d516e5d0f60  mov [r15+0x40], rax
00007d516e5d0f64  mov eax, [rsp+0x10]
00007d516e5d0f68  shr eax, 0x10
00007d516e5d0f6b  mov r14d, [rsp+0x10]
00007d516e5d0f70  xor r14d, eax
00007d516e5d0f73  mov r14d, r14d
00007d516e5d0f76  mov [r15], r14
00007d516e5d0f79  mov rax, [r15+0xF0]
00007d516e5d0f80  mov [r15+0x100], rax
00007d516e5d0f87  jmp 0x00007D516E5CE5C0
00007d516e5d0f8c  int3
00007d516e5d0f8d  int3
00007d516e5d0f8e  nop
00007d516e5d0f90  mov rax, [r15+0xA0]
00007d516e5d0f97  mov [rsp+0x10], rax
00007d516e5d0f9c  shl rax, 0x02
00007d516e5d0fa0  mov r14, [r15+0x98]
00007d516e5d0fa7  lea r12, [r14+rax*1]
00007d516e5d0fab  mov eax, [r15]
00007d516e5d0fae  mov [r13+r12*1], eax
00007d516e5d0fb3  mov rax, [rsp+0x10]
00007d516e5d0fb8  lea r14, [rax+0x01]
00007d516e5d0fbc  mov [r15+0xA0], r14
00007d516e5d0fc3  xor eax, eax
00007d516e5d0fc5  mov r12d, 0x400
00007d516e5d0fcb  cmp r14, r12
00007d516e5d0fce  cmc
00007d516e5d0fcf  lahf
00007d516e5d0fd0  seto al
00007d516e5d0fd3  mov [r15+0x108], eax
00007d516e5d0fda  mov eax, [r15+0x108]
00007d516e5d0fe1  sahf
00007d516e5d0fe2  jnz 0x00007D516E5D1014
00007d516e5d0fe4  cmp dword ptr [r15+0x318], 0x00
00007d516e5d0fec  jz 0x00007D516E5D10E0
00007d516e5d0ff2  nop [rax+rax*1], ax
00007d516e5d0ffb  nop [rax+rax*1], eax
00007d516e5d1003  mov eax, 0x41036C
00007d516e5d1008  mov [r15+0x100], rax
00007d516e5d100f  jmp 0x00007D516E3FE110
00007d516e5d1014  cmp dword ptr [r15+0x318], 0x00
00007d516e5d101c  jz 0x00007D516E5D1050
00007d516e5d1022  nop [rax+rax*1], ax
00007d516e5d102b  nop [rax+rax*1], eax
00007d516e5d1033  mov eax, 0x410354
00007d516e5d1038  mov [r15+0x100], rax
00007d516e5d103f  jmp 0x00007D516E3FE110
00007d516e5d1044  int3
00007d516e5d1045  call 0x00007D516E4B4B70
00007d516e5d104a  jmp 0x00007D516E5D0FB3
00007d516e5d104f  int3
00007d516e5d1050  mov eax, [r15+0xA0]
00007d516e5d1057  lea r14d, [eax+0x11]
00007d516e5d105c  mov r14d, r14d
00007d516e5d105f  mov [r15], r14
00007d516e5d1062  mov qword ptr [r15+0xF0], 0x41035C
00007d516e5d106d  mov r14d, [r15+0x320]
00007d516e5d1074  mov eax, 0x41035C
00007d516e5d1079  mov rcx, 0x7D516E5D0F90
00007d516e5d1083  mov [r15+r14*8+0x328], rax
00007d516e5d108b  mov [r15+r14*8+0x368], rcx
00007d516e5d1093  add r14d, 0x01
00007d516e5d1097  and r14d, 0x07
00007d516e5d109b  mov [r15+0x320], r14d
00007d516e5d10a2  cmp dword ptr [r15+0x318], 0x00
00007d516e5d10aa  jz 0x00007D516E5D0F20
00007d516e5d10b0  nop [rax+rax*1], ax
00007d516e5d10b9  nop [rax+rax*1], eax
00007d516e5d10c1  mov eax, 0x4109A4
00007d516e5d10c6  mov [r15+0x100], rax
00007d516e5d10cd  jmp 0x00007D516E3FE110
00007d516e5d10d2  int3
00007d516e5d10d3  int3
00007d516e5d10d4  nop [rax+rax*1], ax
00007d516e5d10dd  nop [rax], eax
00007d516e5d10e0  mov qword ptr [r15+0x40], 0x01
00007d516e5d10e8  cmp dword ptr [r15+0x318], 0x00
00007d516e5d10f0  jz 0x00007D516E5D1120
00007d516e5d10f6  nop [rax+rax*1], ax
00007d516e5d10ff  nop [rax+rax*1], eax
00007d516e5d1107  mov eax, 0x410388
00007d516e5d110c  mov [r15+0x100], rax
00007d516e5d1113  jmp 0x00007D516E3FE110
00007d516e5d1118  int3
00007d516e5d1119  int3
00007d516e5d111a  nop [rax+rax*1], ax
00007d516e5d1120  mov rax, [r15+0x40]
00007d516e5d1124  mov [rsp+0x10], rax
00007d516e5d1129  shl rax, 0x02
00007d516e5d112d  mov r14, [r15+0x98]
00007d516e5d1134  lea r12, [r14+rax*1]
00007d516e5d1138  mov eax, [r13+r12*1]
00007d516e5d113d  mov [rsp+0x20], eax
00007d516e5d1141  mov eax, eax
00007d516e5d1143  mov [r15+0x48], rax
00007d516e5d1147  mov rax, [rsp+0x10]
00007d516e5d114c  mov [r15+0x50], rax
00007d516e5d1150  mov eax, [r15+0x50]
00007d516e5d1154  lea r12d, [eax-0x01]
00007d516e5d1159  mov r12d, r12d
00007d516e5d115c  mov [r15+0x58], r12
00007d516e5d1160  mov rax, [r15+0x58]
00007d516e5d1164  mov r12d, eax
00007d516e5d1167  mov r12d, r12d
00007d516e5d116a  shl r12, 0x02
00007d516e5d116e  lea rax, [r14+r12*1]
00007d516e5d1172  mov r14d, [r13+rax*1]
00007d516e5d1177  mov [rsp+0x10], r14d
00007d516e5d117c  mov r14d, r14d
00007d516e5d117f  mov [r15+0x60], r14
00007d516e5d1183  xor eax, eax
00007d516e5d1185  mov r14d, [rsp+0x10]
00007d516e5d118a  mov r12d, [rsp+0x20]
00007d516e5d118f  cmp r14d, r12d
00007d516e5d1192  cmc
00007d516e5d1193  lahf
00007d516e5d1194  seto al
00007d516e5d1197  mov [r15+0x108], eax
00007d516e5d119e  mov eax, [r15+0x108]
00007d516e5d11a5  sahf
00007d516e5d11a6  cmc
00007d516e5d11a7  jbe 0x00007D516E5D11D9
00007d516e5d11a9  cmp dword ptr [r15+0x318], 0x00
00007d516e5d11b1  jz 0x00007D516E5D1220
00007d516e5d11b7  nop [rax+rax*1], ax
00007d516e5d11c0  nop [rax+rax*1], eax
00007d516e5d11c8  mov eax, 0x4103A0
00007d516e5d11cd  mov [r15+0x100], rax
00007d516e5d11d4  jmp 0x00007D516E3FE110
00007d516e5d11d9  cmp dword ptr [r15+0x318], 0x00
00007d516e5d11e1  jz 0x00007D516E5D14C0
00007d516e5d11e7  nop [rax+rax*1], ax
00007d516e5d11f0  nop [rax+rax*1], eax
00007d516e5d11f8  mov eax, 0x410378
00007d516e5d11fd  mov [r15+0x100], rax
00007d516e5d1204  jmp 0x00007D516E3FE110
00007d516e5d1209  int3
00007d516e5d120a  call 0x00007D516E4B4690
00007d516e5d120f  jmp 0x00007D516E5D113D
00007d516e5d1214  call 0x00007D516E40DAE0
00007d516e5d1219  jmp 0x00007D516E5D1177
00007d516e5d121e  int3
00007d516e5d121f  nop
00007d516e5d1220  mov rax, [r15+0x50]
00007d516e5d1224  mov [rsp+0x10], rax
00007d516e5d1229  shl rax, 0x02
00007d516e5d122d  mov r14, [r15+0x98]
00007d516e5d1234  lea r12, [r14+rax*1]
00007d516e5d1238  mov eax, [r15+0x60]
00007d516e5d123c  mov [r13+r12*1], eax
00007d516e5d1241  mov rax, [rsp+0x10]
00007d516e5d1246  lea r14, [rax-0x01]
00007d516e5d124a  mov [r15+0x50], r14
00007d516e5d124e  mov rax, [r15+0x58]
00007d516e5d1252  test rax, rax
00007d516e5d1255  setz al
00007d516e5d1258  movzx rax, al
00007d516e5d125c  mov [rsp+0x414], al
00007d516e5d1263  cmp byte ptr [rsp+0x414], 0x00
00007d516e5d126b  jz 0x00007D516E5D129D
00007d516e5d126d  cmp dword ptr [r15+0x318], 0x00
00007d516e5d1275  jz 0x00007D516E5D12E0
00007d516e5d127b  nop [rax+rax*1], ax
00007d516e5d1284  nop [rax+rax*1], eax
00007d516e5d128c  mov eax, 0x4103AC
00007d516e5d1291  mov [r15+0x100], rax
00007d516e5d1298  jmp 0x00007D516E3FE110
00007d516e5d129d  cmp dword ptr [r15+0x318], 0x00
00007d516e5d12a5  jz 0x00007D516E5D13E0
00007d516e5d12ab  nop [rax+rax*1], ax
00007d516e5d12b4  nop [rax+rax*1], eax
00007d516e5d12bc  mov eax, 0x410390
00007d516e5d12c1  mov [r15+0x100], rax
00007d516e5d12c8  jmp 0x00007D516E3FE110
00007d516e5d12cd  int3
00007d516e5d12ce  call 0x00007D516E4B4B70
00007d516e5d12d3  jmp 0x00007D516E5D1241
00007d516e5d12d8  int3
00007d516e5d12d9  nop [rax], eax
00007d516e5d12e0  cmp dword ptr [r15+0x318], 0x00
00007d516e5d12e8  jz 0x00007D516E5D1320
00007d516e5d12ee  nop [rax+rax*1], ax
00007d516e5d12f7  nop [rax+rax*1], eax
00007d516e5d12ff  mov eax, 0x410374
00007d516e5d1304  mov [r15+0x100], rax
00007d516e5d130b  jmp 0x00007D516E3FE110
00007d516e5d1310  int3
00007d516e5d1311  int3
00007d516e5d1312  nop [rax+rax*1], ax
00007d516e5d131b  nop [rax+rax*1], eax
00007d516e5d1320  mov qword ptr [r15+0x50], 0x00
00007d516e5d1328  mov rax, [r15+0x40]
00007d516e5d132c  lea r14, [rax+0x01]
00007d516e5d1330  mov [r15+0x40], r14
00007d516e5d1334  mov rax, [r15+0x98]
00007d516e5d133b  mov r12d, [r15+0x48]
00007d516e5d133f  mov [r13+rax*1], r12d
00007d516e5d1344  xor eax, eax
00007d516e5d1346  mov r12d, 0x400
00007d516e5d134c  cmp r14, r12
00007d516e5d134f  cmc
00007d516e5d1350  lahf
00007d516e5d1351  seto al
00007d516e5d1354  mov [r15+0x108], eax
00007d516e5d135b  mov eax, [r15+0x108]
00007d516e5d1362  sahf
00007d516e5d1363  jz 0x00007D516E5D1395
00007d516e5d1365  cmp dword ptr [r15+0x318], 0x00
00007d516e5d136d  jz 0x00007D516E5D1120
00007d516e5d1373  nop [rax+rax*1], ax
00007d516e5d137c  nop [rax+rax*1], eax
00007d516e5d1384  mov eax, 0x410388
00007d516e5d1389  mov [r15+0x100], rax
00007d516e5d1390  jmp 0x00007D516E3FE110
00007d516e5d1395  cmp dword ptr [r15+0x318], 0x00
00007d516e5d139d  jz 0x00007D516E5D1580
00007d516e5d13a3  nop [rax+rax*1], ax
00007d516e5d13ac  nop [rax+rax*1], eax
00007d516e5d13b4  mov eax, 0x4103B0
00007d516e5d13b9  mov [r15+0x100], rax
00007d516e5d13c0  jmp 0x00007D516E3FE110
00007d516e5d13c5  int3
00007d516e5d13c6  call 0x00007D516E40BAE0
00007d516e5d13cb  jmp 0x00007D516E5D1344
00007d516e5d13d0  int3
00007d516e5d13d1  nop [rax+rax*1], ax
00007d516e5d13da  nop [rax+rax*1], ax
00007d516e5d13e0  mov eax, [r15+0x50]
00007d516e5d13e4  lea r14d, [eax-0x01]
00007d516e5d13e9  mov r14d, r14d
00007d516e5d13ec  mov [r15+0x58], r14
00007d516e5d13f0  mov rax, [r15+0x58]
00007d516e5d13f4  mov r14d, eax
00007d516e5d13f7  mov r14d, r14d
00007d516e5d13fa  shl r14, 0x02
00007d516e5d13fe  mov rax, [r15+0x98]
00007d516e5d1405  lea r12, [rax+r14*1]
00007d516e5d1409  mov eax, [r13+r12*1]
00007d516e5d140e  mov [rsp+0x10], eax
00007d516e5d1412  mov eax, eax
00007d516e5d1414  mov [r15+0x60], rax
00007d516e5d1418  mov eax, [r15+0x48]
00007d516e5d141c  mov [rsp+0x20], eax
00007d516e5d1420  xor eax, eax
00007d516e5d1422  mov r14d, [rsp+0x10]
00007d516e5d1427  mov r12d, [rsp+0x20]
00007d516e5d142c  cmp r14d, r12d
00007d516e5d142f  cmc
00007d516e5d1430  lahf
00007d516e5d1431  seto al
00007d516e5d1434  mov [r15+0x108], eax
00007d516e5d143b  mov eax, [r15+0x108]
00007d516e5d1442  sahf
00007d516e5d1443  cmc
00007d516e5d1444  jbe 0x00007D516E5D1476
00007d516e5d1446  cmp dword ptr [r15+0x318], 0x00
00007d516e5d144e  jz 0x00007D516E5D1220
00007d516e5d1454  nop [rax+rax*1], ax
00007d516e5d145d  nop [rax+rax*1], eax
00007d516e5d1465  mov eax, 0x4103A0
00007d516e5d146a  mov [r15+0x100], rax
00007d516e5d1471  jmp 0x00007D516E3FE110
00007d516e5d1476  cmp dword ptr [r15+0x318], 0x00
00007d516e5d147e  jz 0x00007D516E5D14C0
00007d516e5d1484  nop [rax+rax*1], ax
00007d516e5d148d  nop [rax+rax*1], eax
00007d516e5d1495  mov eax, 0x410378
00007d516e5d149a  mov [r15+0x100], rax
00007d516e5d14a1  jmp 0x00007D516E3FE110
00007d516e5d14a6  int3
00007d516e5d14a7  call 0x00007D516E4B4690
00007d516e5d14ac  jmp 0x00007D516E5D140E
00007d516e5d14b1  int3
00007d516e5d14b2  nop [rax+rax*1], ax
00007d516e5d14bb  nop [rax+rax*1], eax
00007d516e5d14c0  mov rax, [r15+0x40]
00007d516e5d14c4  lea r14, [rax+0x01]
00007d516e5d14c8  mov [r15+0x40], r14
00007d516e5d14cc  mov rax, [r15+0x50]
00007d516e5d14d0  mov r12d, eax
00007d516e5d14d3  mov r12d, r12d
00007d516e5d14d6  shl r12, 0x02
00007d516e5d14da  mov rax, [r15+0x98]
00007d516e5d14e1  lea r11, [rax+r12*1]
00007d516e5d14e5  mov eax, [r15+0x48]
00007d516e5d14e9  mov [r13+r11*1], eax
00007d516e5d14ee  xor eax, eax
00007d516e5d14f0  mov r12d, 0x400
00007d516e5d14f6  cmp r14, r12
00007d516e5d14f9  cmc
00007d516e5d14fa  lahf
00007d516e5d14fb  seto al
00007d516e5d14fe  mov [r15+0x108], eax
00007d516e5d1505  mov eax, [r15+0x108]
00007d516e5d150c  sahf
00007d516e5d150d  jz 0x00007D516E5D153F
00007d516e5d150f  cmp dword ptr [r15+0x318], 0x00
00007d516e5d1517  jz 0x00007D516E5D1120
00007d516e5d151d  nop [rax+rax*1], ax
00007d516e5d1526  nop [rax+rax*1], eax
00007d516e5d152e  mov eax, 0x410388
00007d516e5d1533  mov [r15+0x100], rax
00007d516e5d153a  jmp 0x00007D516E3FE110
00007d516e5d153f  cmp dword ptr [r15+0x318], 0x00
00007d516e5d1547  jz 0x00007D516E5D1580
00007d516e5d154d  nop [rax+rax*1], ax
00007d516e5d1556  nop [rax+rax*1], eax
00007d516e5d155e  mov eax, 0x4103B0
00007d516e5d1563  mov [r15+0x100], rax
00007d516e5d156a  jmp 0x00007D516E3FE110
00007d516e5d156f  int3
00007d516e5d1570  call 0x00007D516E4A4270
00007d516e5d1575  jmp 0x00007D516E5D14EE
00007d516e5d157a  int3
00007d516e5d157b  nop [rax+rax*1], eax
00007d516e5d1580  mov qword ptr [r15+0x40], 0x430000
00007d516e5d1588  mov eax, 0x430CB0
00007d516e5d158d  mov r14, [r13+rax*1]
00007d516e5d1592  mov rax, [r15+0x98]
00007d516e5d1599  mov r12d, [r13+rax*1]
00007d516e5d159e  lea r11, [rax+0x04]
00007d516e5d15a2  mov eax, [r13+r11*1]
00007d516e5d15a7  mov r12d, r12d
00007d516e5d15aa  mov [r15+0x68], r12
00007d516e5d15ae  mov eax, eax
00007d516e5d15b0  mov [r15+0x60], rax
00007d516e5d15b4  mov rax, [r15+0x68]
00007d516e5d15b8  mov [r15+0x68], rax
00007d516e5d15bc  mov qword ptr [r15+0x58], 0x02
00007d516e5d15c4  mov [rsp+0x10], rax
00007d516e5d15c9  xor eax, eax
00007d516e5d15cb  mov r12d, 0x02
00007d516e5d15d1  mov r11d, 0x400
00007d516e5d15d7  cmp r12, r11
00007d516e5d15da  cmc
00007d516e5d15db  lahf
00007d516e5d15dc  seto al
00007d516e5d15df  mov [r15+0x108], eax
00007d516e5d15e6  mov rax, [r15+0x60]
00007d516e5d15ea  mov r12d, 0x02
00007d516e5d15f0  imul rax, r12
00007d516e5d15f4  mov [r15+0x50], rax
00007d516e5d15f8  mov rax, [rsp+0x10]
00007d516e5d15fd  lea r12, [rax+r14*1]
00007d516e5d1601  mov [r15+0x48], r12
00007d516e5d1605  mov eax, [r15+0x108]
00007d516e5d160c  sahf
00007d516e5d160d  jnz 0x00007D516E5D163F
00007d516e5d160f  cmp dword ptr [r15+0x318], 0x00
00007d516e5d1617  jz 0x00007D516E5D17B0
00007d516e5d161d  nop [rax+rax*1], ax
00007d516e5d1626  nop [rax+rax*1], eax
00007d516e5d162e  mov eax, 0x4103E0
00007d516e5d1633  mov [r15+0x100], rax
00007d516e5d163a  jmp 0x00007D516E3FE110
00007d516e5d163f  cmp dword ptr [r15+0x318], 0x00
00007d516e5d1647  jz 0x00007D516E5D1690
00007d516e5d164d  nop [rax+rax*1], ax
00007d516e5d1656  nop [rax+rax*1], eax
00007d516e5d165e  mov eax, 0x4103C0
00007d516e5d1663  mov [r15+0x100], rax
00007d516e5d166a  jmp 0x00007D516E3FE110
00007d516e5d166f  int3
00007d516e5d1670  call 0x00007D516E40DC20
00007d516e5d1675  jmp 0x00007D516E5D1592
00007d516e5d167a  call 0x00007D516E40B5E0
00007d516e5d167f  jmp 0x00007D516E5D159E
00007d516e5d1684  call 0x00007D516E4A3D90
00007d516e5d1689  jmp 0x00007D516E5D15A7
00007d516e5d168e  int3
00007d516e5d168f  nop
00007d516e5d1690  mov rax, [r15+0x98]
00007d516e5d1697  mov r14, [r15+0x58]
00007d516e5d169b  mov [rsp+0x10], r14
00007d516e5d16a0  shl r14, 0x02
00007d516e5d16a4  lea r12, [rax+r14*1]
00007d516e5d16a8  mov eax, [r13+r12*1]
00007d516e5d16ad  lea r14, [r12+0x04]
00007d516e5d16b2  mov r12d, [r13+r14*1]
00007d516e5d16b7  mov eax, eax
00007d516e5d16b9  mov [r15+0x68], rax
00007d516e5d16bd  mov r12d, r12d
00007d516e5d16c0  mov [r15+0x60], r12
00007d516e5d16c4  mov rax, [r15+0x68]
00007d516e5d16c8  mov [rsp+0x20], rax
00007d516e5d16cd  mov r14, [rsp+0x10]
00007d516e5d16d2  imul rax, r14
00007d516e5d16d6  mov r12, [rsp+0x20]
00007d516e5d16db  lea r11, [r12+rax*1]
00007d516e5d16df  mov [r15+0x68], r11
00007d516e5d16e3  lea rax, [r14+0x02]
00007d516e5d16e7  mov [r15+0x58], rax
00007d516e5d16eb  mov [rsp+0x10], rax
00007d516e5d16f0  xor eax, eax
00007d516e5d16f2  mov r14, [rsp+0x10]
00007d516e5d16f7  mov r12d, 0x400
00007d516e5d16fd  cmp r14, r12
00007d516e5d1700  cmc
00007d516e5d1701  lahf
00007d516e5d1702  seto al
00007d516e5d1705  mov [r15+0x108], eax
00007d516e5d170c  mov rax, [r15+0x50]
00007d516e5d1710  mov r12, [r15+0x60]
00007d516e5d1714  imul r14, r12
00007d516e5d1718  lea r12, [rax+r14*1]
00007d516e5d171c  mov [r15+0x50], r12
00007d516e5d1720  mov rax, [r15+0x48]
00007d516e5d1724  lea r14, [r11+rax*1]
00007d516e5d1728  mov [r15+0x48], r14
00007d516e5d172c  mov eax, [r15+0x108]
00007d516e5d1733  sahf
00007d516e5d1734  jnz 0x00007D516E5D1766
00007d516e5d1736  cmp dword ptr [r15+0x318], 0x00
00007d516e5d173e  jz 0x00007D516E5D17B0
00007d516e5d1744  nop [rax+rax*1], ax
00007d516e5d174d  nop [rax+rax*1], eax
00007d516e5d1755  mov eax, 0x4103E0
00007d516e5d175a  mov [r15+0x100], rax
00007d516e5d1761  jmp 0x00007D516E3FE110
00007d516e5d1766  cmp dword ptr [r15+0x318], 0x00
00007d516e5d176e  jz 0x00007D516E5D1690
00007d516e5d1774  nop [rax+rax*1], ax
00007d516e5d177d  nop [rax+rax*1], eax
00007d516e5d1785  mov eax, 0x4103C0
00007d516e5d178a  mov [r15+0x100], rax
00007d516e5d1791  jmp 0x00007D516E3FE110
00007d516e5d1796  int3
00007d516e5d1797  call 0x00007D516E4B4690
00007d516e5d179c  jmp 0x00007D516E5D16AD
00007d516e5d17a1  call 0x00007D516E4E26A0
00007d516e5d17a6  jmp 0x00007D516E5D16B7
00007d516e5d17ab  int3
00007d516e5d17ac  nop [rax], eax
00007d516e5d17b0  mov qword ptr [r15+0x98], 0x00
00007d516e5d17bb  mov rax, [r15+0x50]
00007d516e5d17bf  mov r14, [r15+0x48]
00007d516e5d17c3  lea r12, [rax+r14*1]
00007d516e5d17c7  mov [r15+0x48], r12
00007d516e5d17cb  mov rax, [r15+0x40]
00007d516e5d17cf  lea r14, [rax+0xCB0]
00007d516e5d17d6  mov [r13+r14*1], r12
00007d516e5d17db  mov qword ptr [r15], 0x01
00007d516e5d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007d516e5d17ed  mov r14d, [r15+0x320]
00007d516e5d17f4  mov eax, 0x4103F8
00007d516e5d17f9  mov rcx, 0x7D516E5D1860
00007d516e5d1803  mov [r15+r14*8+0x328], rax
00007d516e5d180b  mov [r15+r14*8+0x368], rcx
00007d516e5d1813  add r14d, 0x01
00007d516e5d1817  and r14d, 0x07
00007d516e5d181b  mov [r15+0x320], r14d
00007d516e5d1822  cmp dword ptr [r15+0x318], 0x00
00007d516e5d182a  jz 0x00007D516E5D0F20
00007d516e5d1830  nop [rax+rax*1], ax
00007d516e5d1839  nop [rax+rax*1], eax
00007d516e5d1841  mov eax, 0x4109A4
00007d516e5d1846  mov [r15+0x100], rax
00007d516e5d184d  jmp 0x00007D516E3FE110
00007d516e5d1852  int3
00007d516e5d1853  call 0x00007D516E4E2CE0
00007d516e5d1858  jmp 0x00007D516E5D17DB
00007d516e5d185d  int3
00007d516e5d185e  nop
00007d516e5d1860  mov eax, [r15+0x98]
00007d516e5d1867  lea r14d, [eax+0x01]
00007d516e5d186c  mov [rsp+0x10], r14d
00007d516e5d1871  mov r14d, r14d
00007d516e5d1874  mov [r15+0x98], r14
00007d516e5d187b  xor eax, eax
00007d516e5d187d  mov r14d, [rsp+0x10]
00007d516e5d1882  cmp r14d, 0x10000
00007d516e5d1889  cmc
00007d516e5d188a  lahf
00007d516e5d188b  seto al
00007d516e5d188e  mov [r15+0x108], eax
00007d516e5d1895  mov eax, [r15+0x108]
00007d516e5d189c  sahf
00007d516e5d189d  jnz 0x00007D516E5D18CF
00007d516e5d189f  cmp dword ptr [r15+0x318], 0x00
00007d516e5d18a7  jz 0x00007D516E5D19A0
00007d516e5d18ad  nop [rax+rax*1], ax
00007d516e5d18b6  nop [rax+rax*1], eax
00007d516e5d18be  mov eax, 0x410404
00007d516e5d18c3  mov [r15+0x100], rax
00007d516e5d18ca  jmp 0x00007D516E3FE110
00007d516e5d18cf  cmp dword ptr [r15+0x318], 0x00
00007d516e5d18d7  jz 0x00007D516E5D1910
00007d516e5d18dd  nop [rax+rax*1], ax
00007d516e5d18e6  nop [rax+rax*1], eax
00007d516e5d18ee  mov eax, 0x4103F0
00007d516e5d18f3  mov [r15+0x100], rax
00007d516e5d18fa  jmp 0x00007D516E3FE110
00007d516e5d18ff  int3
00007d516e5d1900  int3
00007d516e5d1901  nop [rax+rax*1], ax
00007d516e5d190a  nop [rax+rax*1], ax
00007d516e5d1910  mov eax, [r15]
00007d516e5d1913  mov r14d, [r15+0x98]
00007d516e5d191a  lea r12d, [eax+r14d*1]
00007d516e5d191f  mov r12d, r12d
00007d516e5d1922  mov [r15], r12
00007d516e5d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007d516e5d1930  mov r14d, [r15+0x320]
00007d516e5d1937  mov eax, 0x4103F8
00007d516e5d193c  mov rcx, 0x7D516E5D1860
00007d516e5d1946  mov [r15+r14*8+0x328], rax
00007d516e5d194e  mov [r15+r14*8+0x368], rcx
00007d516e5d1956  add r14d, 0x01
00007d516e5d195a  and r14d, 0x07
00007d516e5d195e  mov [r15+0x320], r14d
00007d516e5d1965  cmp dword ptr [r15+0x318], 0x00
00007d516e5d196d  jz 0x00007D516E5D0F20
00007d516e5d1973  nop [rax+rax*1], ax
00007d516e5d197c  nop [rax+rax*1], eax
00007d516e5d1984  mov eax, 0x4109A4
00007d516e5d1989  mov [r15+0x100], rax
00007d516e5d1990  jmp 0x00007D516E3FE110
00007d516e5d1995  int3
00007d516e5d1996  int3
00007d516e5d1997  nop [rax+rax*1], ax
00007d516e5d19a0  vmovaps xmm1, [0x00007D516E1FE010]
00007d516e5d19a8  movq xmm1, xmm1
00007d516e5d19ac  movaps [r15+0x110], xmm1
00007d516e5d19b4  mov eax, 0x420B10
00007d516e5d19b9  mov r14, [r13+rax*1]
00007d516e5d19be  movq xmm1, r14
00007d516e5d19c3  movaps [r15+0x120], xmm1
00007d516e5d19cb  vmovaps xmm1, [0x00007D516E1FE020]
00007d516e5d19d3  movq xmm1, xmm1
00007d516e5d19d7  movaps [r15+0x140], xmm1
00007d516e5d19df  vmovaps xmm1, [0x00007D516E1FE030]
00007d516e5d19e7  vpbroadcastq xmm1, xmm1
00007d516e5d19ec  movaps [r15+0x150], xmm1
00007d516e5d19f4  mov qword ptr [r15+0x40], 0x02
00007d516e5d19fc  vmovaps xmm15, [0x00007D516E1FE040]
00007d516e5d1a04  movq xmm15, xmm15
00007d516e5d1a09  movaps [r15+0x160], xmm15
00007d516e5d1a11  vmovaps xmm15, [0x00007D516E1FE050]
00007d516e5d1a19  vpbroadcastq xmm15, xmm15
00007d516e5d1a1e  movaps [r15+0x130], xmm15
00007d516e5d1a26  mov rax, [r15+0x40]
00007d516e5d1a2a  vmovq xmm14, rax
00007d516e5d1a2f  vpbroadcastq xmm14, xmm14
00007d516e5d1a34  movaps [r15+0x170], xmm14
00007d516e5d1a3c  mov eax, 0x420A40
00007d516e5d1a41  movups xmm13, [r13+rax*1]
00007d516e5d1a47  mov qword ptr [r15+0x40], 0x431E00
00007d516e5d1a4f  mov eax, [r15]
00007d516e5d1a52  mov r14d, 0x430CB8
00007d516e5d1a58  mov [r13+r14*1], eax
00007d516e5d1a5d  mov qword ptr [r15+0x50], 0x432000
00007d516e5d1a65  vpmovqd xmm12, xmm13
00007d516e5d1a6b  pxor xmm11, xmm11
00007d516e5d1a70  punpcklqdq xmm12, xmm11
00007d516e5d1a75  movaps [r15+0x210], xmm12
00007d516e5d1a7d  movq xmm12, qword ptr [r15+0x140]
00007d516e5d1a86  movq xmm11, qword ptr [r15+0x120]
00007d516e5d1a8f  psubd xmm12, xmm11
00007d516e5d1a94  movq xmm12, xmm12
00007d516e5d1a99  paddq xmm13, xmm14
00007d516e5d1a9e  movaps [r15+0x180], xmm13
00007d516e5d1aa6  movq xmm14, qword ptr [r15+0x160]
00007d516e5d1aaf  paddd xmm11, xmm14
00007d516e5d1ab4  movq xmm11, xmm11
00007d516e5d1ab9  movq xmm11, xmm11
00007d516e5d1abe  movaps [r15+0x120], xmm11
00007d516e5d1ac6  pmovzxdq xmm12, xmm12
00007d516e5d1acc  psllq xmm12, 0x00
00007d516e5d1ad2  movq xmm14, qword ptr [r15+0x210]
00007d516e5d1adb  movq xmm13, qword ptr [r15+0x110]
00007d516e5d1ae4  paddd xmm14, xmm13
00007d516e5d1ae9  movq xmm14, xmm14
00007d516e5d1aee  vcvtuqq2pd xmm12, xmm12
00007d516e5d1af4  pmovzxdq xmm14, xmm14
00007d516e5d1afa  psllq xmm14, 0x00
00007d516e5d1b00  vcvtuqq2pd xmm14, xmm14
00007d516e5d1b06  movaps xmm13, xmm12
00007d516e5d1b0a  mulpd xmm13, xmm1
00007d516e5d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007d516e5d1b15  ptest xmm11, xmm11
00007d516e5d1b1b  jnz 0x00007D516E5D1C0F
00007d516e5d1b21  movaps [r15+0x220], xmm13
00007d516e5d1b29  mov eax, 0x432000
00007d516e5d1b2e  movups [r13+rax*1], xmm13
00007d516e5d1b34  movaps xmm1, xmm14
00007d516e5d1b38  mulpd xmm1, xmm15
00007d516e5d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007d516e5d1b42  ptest xmm13, xmm13
00007d516e5d1b48  jnz 0x00007D516E5D1D5C
00007d516e5d1b4e  movaps [r15+0x210], xmm1
00007d516e5d1b56  mov eax, 0x431E00
00007d516e5d1b5b  movups [r13+rax*1], xmm1
00007d516e5d1b61  mov qword ptr [r15+0x48], 0x10
00007d516e5d1b69  xor eax, eax
00007d516e5d1b6b  mov r14d, 0x10
00007d516e5d1b71  mov r12d, 0x200
00007d516e5d1b77  cmp r14, r12
00007d516e5d1b7a  cmc
00007d516e5d1b7b  lahf
00007d516e5d1b7c  seto al
00007d516e5d1b7f  mov [r15+0x108], eax
00007d516e5d1b86  mov eax, [r15+0x108]
00007d516e5d1b8d  sahf
00007d516e5d1b8e  jnz 0x00007D516E5D1BC0
00007d516e5d1b90  cmp dword ptr [r15+0x318], 0x00
00007d516e5d1b98  jz 0x00007D516E5D2300
00007d516e5d1b9e  nop [rax+rax*1], ax
00007d516e5d1ba7  nop [rax+rax*1], eax
00007d516e5d1baf  mov eax, 0x410490
00007d516e5d1bb4  mov [r15+0x100], rax
00007d516e5d1bbb  jmp 0x00007D516E3FE110
00007d516e5d1bc0  cmp dword ptr [r15+0x318], 0x00
00007d516e5d1bc8  jz 0x00007D516E5D1EB0
00007d516e5d1bce  nop [rax+rax*1], ax
00007d516e5d1bd7  nop [rax+rax*1], eax
00007d516e5d1bdf  mov eax, 0x410450
00007d516e5d1be4  mov [r15+0x100], rax
00007d516e5d1beb  jmp 0x00007D516E3FE110
00007d516e5d1bf0  int3
00007d516e5d1bf1  call 0x00007D516E40DC20
00007d516e5d1bf6  jmp 0x00007D516E5D19BE
00007d516e5d1bfb  call 0x00007D516E40C260
00007d516e5d1c00  jmp 0x00007D516E5D1A47
00007d516e5d1c05  call 0x00007D516E4D5D70
00007d516e5d1c0a  jmp 0x00007D516E5D1A5D
00007d516e5d1c0f  sub rsp, 0x08
00007d516e5d1c13  push rax
00007d516e5d1c14  push rcx
00007d516e5d1c15  push rdx
00007d516e5d1c16  push rdi
00007d516e5d1c17  push rsi
00007d516e5d1c18  push r8
00007d516e5d1c1a  push r9
00007d516e5d1c1c  push r10
00007d516e5d1c1e  push r11
00007d516e5d1c20  sub rsp, 0xF0
00007d516e5d1c27  vmovaps [rsp], xmm0
00007d516e5d1c2c  vmovaps [rsp+0x10], xmm1
00007d516e5d1c32  vmovaps [rsp+0x20], xmm2
00007d516e5d1c38  vmovaps [rsp+0x30], xmm3
00007d516e5d1c3e  vmovaps [rsp+0x40], xmm4
00007d516e5d1c44  vmovaps [rsp+0x50], xmm5
00007d516e5d1c4a  vmovaps [rsp+0x60], xmm6
00007d516e5d1c50  vmovaps [rsp+0x70], xmm7
00007d516e5d1c56  vmovaps [rsp+0x80], xmm8
00007d516e5d1c5f  vmovaps [rsp+0x90], xmm9
00007d516e5d1c68  vmovaps [rsp+0xA0], xmm10
00007d516e5d1c71  vmovaps [rsp+0xB0], xmm11
00007d516e5d1c7a  vmovaps [rsp+0xC0], xmm12
00007d516e5d1c83  vmovaps [rsp+0xD0], xmm14
00007d516e5d1c8c  vmovaps [rsp+0xE0], xmm15
00007d516e5d1c95  sub rsp, 0x30
00007d516e5d1c99  movaps [rsp], xmm13
00007d516e5d1c9e  movaps [rsp+0x10], xmm12
00007d516e5d1ca4  movaps [rsp+0x20], xmm1
00007d516e5d1ca9  lea rdi, [rsp]
00007d516e5d1cad  mov esi, 0x00
00007d516e5d1cb2  mov rax, 0x5EE43AF14530
00007d516e5d1cbc  call rax
00007d516e5d1cbe  movaps xmm13, [rsp]
00007d516e5d1cc3  add rsp, 0x30
00007d516e5d1cc7  vmovaps xmm0, [rsp]
00007d516e5d1ccc  vmovaps xmm1, [rsp+0x10]
00007d516e5d1cd2  vmovaps xmm2, [rsp+0x20]
00007d516e5d1cd8  vmovaps xmm3, [rsp+0x30]
00007d516e5d1cde  vmovaps xmm4, [rsp+0x40]
00007d516e5d1ce4  vmovaps xmm5, [rsp+0x50]
00007d516e5d1cea  vmovaps xmm6, [rsp+0x60]
00007d516e5d1cf0  vmovaps xmm7, [rsp+0x70]
00007d516e5d1cf6  vmovaps xmm8, [rsp+0x80]
00007d516e5d1cff  vmovaps xmm9, [rsp+0x90]
00007d516e5d1d08  vmovaps xmm10, [rsp+0xA0]
00007d516e5d1d11  vmovaps xmm11, [rsp+0xB0]
00007d516e5d1d1a  vmovaps xmm12, [rsp+0xC0]
00007d516e5d1d23  vmovaps xmm14, [rsp+0xD0]
00007d516e5d1d2c  vmovaps xmm15, [rsp+0xE0]
00007d516e5d1d35  add rsp, 0xF0
00007d516e5d1d3c  pop r11
00007d516e5d1d3e  pop r10
00007d516e5d1d40  pop r9
00007d516e5d1d42  pop r8
00007d516e5d1d44  pop rsi
00007d516e5d1d45  pop rdi
00007d516e5d1d46  pop rdx
00007d516e5d1d47  pop rcx
00007d516e5d1d48  pop rax
00007d516e5d1d49  add rsp, 0x08
00007d516e5d1d4d  jmp 0x00007D516E5D1B21
00007d516e5d1d52  call 0x00007D516E40C380
00007d516e5d1d57  jmp 0x00007D516E5D1B34
00007d516e5d1d5c  sub rsp, 0x08
00007d516e5d1d60  push rax
00007d516e5d1d61  push rcx
00007d516e5d1d62  push rdx
00007d516e5d1d63  push rdi
00007d516e5d1d64  push rsi
00007d516e5d1d65  push r8
00007d516e5d1d67  push r9
00007d516e5d1d69  push r10
00007d516e5d1d6b  push r11
00007d516e5d1d6d  sub rsp, 0xF0
00007d516e5d1d74  vmovaps [rsp], xmm0
00007d516e5d1d79  vmovaps [rsp+0x10], xmm2
00007d516e5d1d7f  vmovaps [rsp+0x20], xmm3
00007d516e5d1d85  vmovaps [rsp+0x30], xmm4
00007d516e5d1d8b  vmovaps [rsp+0x40], xmm5
00007d516e5d1d91  vmovaps [rsp+0x50], xmm6
00007d516e5d1d97  vmovaps [rsp+0x60], xmm7
00007d516e5d1d9d  vmovaps [rsp+0x70], xmm8
00007d516e5d1da3  vmovaps [rsp+0x80], xmm9
00007d516e5d1dac  vmovaps [rsp+0x90], xmm10
00007d516e5d1db5  vmovaps [rsp+0xA0], xmm11
00007d516e5d1dbe  vmovaps [rsp+0xB0], xmm12
00007d516e5d1dc7  vmovaps [rsp+0xC0], xmm13
00007d516e5d1dd0  vmovaps [rsp+0xD0], xmm14
00007d516e5d1dd9  vmovaps [rsp+0xE0], xmm15
00007d516e5d1de2  sub rsp, 0x30
00007d516e5d1de6  movaps [rsp], xmm1
00007d516e5d1dea  movaps [rsp+0x10], xmm14
00007d516e5d1df0  movaps [rsp+0x20], xmm15
00007d516e5d1df6  lea rdi, [rsp]
00007d516e5d1dfa  mov esi, 0x00
00007d516e5d1dff  mov rax, 0x5EE43AF14530
00007d516e5d1e09  call rax
00007d516e5d1e0b  movaps xmm1, [rsp]
00007d516e5d1e0f  add rsp, 0x30
00007d516e5d1e13  vmovaps xmm0, [rsp]
00007d516e5d1e18  vmovaps xmm2, [rsp+0x10]
00007d516e5d1e1e  vmovaps xmm3, [rsp+0x20]
00007d516e5d1e24  vmovaps xmm4, [rsp+0x30]
00007d516e5d1e2a  vmovaps xmm5, [rsp+0x40]
00007d516e5d1e30  vmovaps xmm6, [rsp+0x50]
00007d516e5d1e36  vmovaps xmm7, [rsp+0x60]
00007d516e5d1e3c  vmovaps xmm8, [rsp+0x70]
00007d516e5d1e42  vmovaps xmm9, [rsp+0x80]
00007d516e5d1e4b  vmovaps xmm10, [rsp+0x90]
00007d516e5d1e54  vmovaps xmm11, [rsp+0xA0]
00007d516e5d1e5d  vmovaps xmm12, [rsp+0xB0]
00007d516e5d1e66  vmovaps xmm13, [rsp+0xC0]
00007d516e5d1e6f  vmovaps xmm14, [rsp+0xD0]
00007d516e5d1e78  vmovaps xmm15, [rsp+0xE0]
00007d516e5d1e81  add rsp, 0xF0
00007d516e5d1e88  pop r11
00007d516e5d1e8a  pop r10
00007d516e5d1e8c  pop r9
00007d516e5d1e8e  pop r8
00007d516e5d1e90  pop rsi
00007d516e5d1e91  pop rdi
00007d516e5d1e92  pop rdx
00007d516e5d1e93  pop rcx
00007d516e5d1e94  pop rax
00007d516e5d1e95  add rsp, 0x08
00007d516e5d1e99  jmp 0x00007D516E5D1B4E
00007d516e5d1e9e  call 0x00007D516E3FF540
00007d516e5d1ea3  jmp 0x00007D516E5D1B61
00007d516e5d1ea8  int3
00007d516e5d1ea9  nop [rax], eax
00007d516e5d1eb0  movaps xmm1, [r15+0x180]
00007d516e5d1eb8  vpmovqd xmm15, xmm1
00007d516e5d1ebe  pxor xmm14, xmm14
00007d516e5d1ec3  punpcklqdq xmm15, xmm14
00007d516e5d1ec8  movaps [r15+0x210], xmm15
00007d516e5d1ed0  movq xmm15, qword ptr [r15+0x140]
00007d516e5d1ed9  movq xmm14, qword ptr [r15+0x120]
00007d516e5d1ee2  psubd xmm15, xmm14
00007d516e5d1ee7  movq xmm15, xmm15
00007d516e5d1eec  movaps xmm13, [r15+0x170]
00007d516e5d1ef4  paddq xmm1, xmm13
00007d516e5d1ef9  movaps [r15+0x180], xmm1
00007d516e5d1f01  movq xmm1, qword ptr [r15+0x160]
00007d516e5d1f0a  paddd xmm14, xmm1
00007d516e5d1f0f  movq xmm14, xmm14
00007d516e5d1f14  movq xmm14, xmm14
00007d516e5d1f19  movaps [r15+0x120], xmm14
00007d516e5d1f21  pmovzxdq xmm15, xmm15
00007d516e5d1f27  psllq xmm15, 0x00
00007d516e5d1f2d  movq xmm1, qword ptr [r15+0x210]
00007d516e5d1f36  movq xmm14, qword ptr [r15+0x110]
00007d516e5d1f3f  paddd xmm1, xmm14
00007d516e5d1f44  movq xmm1, xmm1
00007d516e5d1f48  vcvtuqq2pd xmm15, xmm15
00007d516e5d1f4e  pmovzxdq xmm1, xmm1
00007d516e5d1f53  psllq xmm1, 0x00
00007d516e5d1f58  vcvtuqq2pd xmm1, xmm1
00007d516e5d1f5e  movaps xmm14, [r15+0x150]
00007d516e5d1f66  movaps xmm13, xmm15
00007d516e5d1f6a  mulpd xmm13, xmm14
00007d516e5d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d516e5d1f75  ptest xmm12, xmm12
00007d516e5d1f7b  jnz 0x00007D516E5D205E
00007d516e5d1f81  movaps [r15+0x220], xmm13
00007d516e5d1f89  mov rax, [r15+0x48]
00007d516e5d1f8d  mov r14, [r15+0x50]
00007d516e5d1f91  lea r12, [r14+rax*1]
00007d516e5d1f95  movups [r13+r12*1], xmm13
00007d516e5d1f9b  movaps xmm15, [r15+0x130]
00007d516e5d1fa3  movaps xmm14, xmm1
00007d516e5d1fa7  mulpd xmm14, xmm15
00007d516e5d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007d516e5d1fb2  ptest xmm13, xmm13
00007d516e5d1fb8  jnz 0x00007D516E5D21AC
00007d516e5d1fbe  movaps [r15+0x210], xmm14
00007d516e5d1fc6  mov r14, [r15+0x40]
00007d516e5d1fca  lea r12, [r14+rax*1]
00007d516e5d1fce  movups [r13+r12*1], xmm14
00007d516e5d1fd4  lea r14, [rax+0x10]
00007d516e5d1fd8  mov [r15+0x48], r14
00007d516e5d1fdc  xor eax, eax
00007d516e5d1fde  mov r12d, 0x200
00007d516e5d1fe4  cmp r14, r12
00007d516e5d1fe7  cmc
00007d516e5d1fe8  lahf
00007d516e5d1fe9  seto al
00007d516e5d1fec  mov [r15+0x108], eax
00007d516e5d1ff3  mov eax, [r15+0x108]
00007d516e5d1ffa  sahf
00007d516e5d1ffb  jnz 0x00007D516E5D202D
00007d516e5d1ffd  cmp dword ptr [r15+0x318], 0x00
00007d516e5d2005  jz 0x00007D516E5D2300
00007d516e5d200b  nop [rax+rax*1], ax
00007d516e5d2014  nop [rax+rax*1], eax
00007d516e5d201c  mov eax, 0x410490
00007d516e5d2021  mov [r15+0x100], rax
00007d516e5d2028  jmp 0x00007D516E3FE110
00007d516e5d202d  cmp dword ptr [r15+0x318], 0x00
00007d516e5d2035  jz 0x00007D516E5D1EB0
00007d516e5d203b  nop [rax+rax*1], ax
00007d516e5d2044  nop [rax+rax*1], eax
00007d516e5d204c  mov eax, 0x410450
00007d516e5d2051  mov [r15+0x100], rax
00007d516e5d2058  jmp 0x00007D516E3FE110
00007d516e5d205d  int3
00007d516e5d205e  sub rsp, 0x08
00007d516e5d2062  push rax
00007d516e5d2063  push rcx
00007d516e5d2064  push rdx
00007d516e5d2065  push rdi
00007d516e5d2066  push rsi
00007d516e5d2067  push r8
00007d516e5d2069  push r9
00007d516e5d206b  push r10
00007d516e5d206d  push r11
00007d516e5d206f  sub rsp, 0xF0
00007d516e5d2076  vmovaps [rsp], xmm0
00007d516e5d207b  vmovaps [rsp+0x10], xmm1
00007d516e5d2081  vmovaps [rsp+0x20], xmm2
00007d516e5d2087  vmovaps [rsp+0x30], xmm3
00007d516e5d208d  vmovaps [rsp+0x40], xmm4
00007d516e5d2093  vmovaps [rsp+0x50], xmm5
00007d516e5d2099  vmovaps [rsp+0x60], xmm6
00007d516e5d209f  vmovaps [rsp+0x70], xmm7
00007d516e5d20a5  vmovaps [rsp+0x80], xmm8
00007d516e5d20ae  vmovaps [rsp+0x90], xmm9
00007d516e5d20b7  vmovaps [rsp+0xA0], xmm10
00007d516e5d20c0  vmovaps [rsp+0xB0], xmm11
00007d516e5d20c9  vmovaps [rsp+0xC0], xmm12
00007d516e5d20d2  vmovaps [rsp+0xD0], xmm14
00007d516e5d20db  vmovaps [rsp+0xE0], xmm15
00007d516e5d20e4  sub rsp, 0x30
00007d516e5d20e8  movaps [rsp], xmm13
00007d516e5d20ed  movaps [rsp+0x10], xmm15
00007d516e5d20f3  movaps [rsp+0x20], xmm14
00007d516e5d20f9  lea rdi, [rsp]
00007d516e5d20fd  mov esi, 0x00
00007d516e5d2102  mov rax, 0x5EE43AF14530
00007d516e5d210c  call rax
00007d516e5d210e  movaps xmm13, [rsp]
00007d516e5d2113  add rsp, 0x30
00007d516e5d2117  vmovaps xmm0, [rsp]
00007d516e5d211c  vmovaps xmm1, [rsp+0x10]
00007d516e5d2122  vmovaps xmm2, [rsp+0x20]
00007d516e5d2128  vmovaps xmm3, [rsp+0x30]
00007d516e5d212e  vmovaps xmm4, [rsp+0x40]
00007d516e5d2134  vmovaps xmm5, [rsp+0x50]
00007d516e5d213a  vmovaps xmm6, [rsp+0x60]
00007d516e5d2140  vmovaps xmm7, [rsp+0x70]
00007d516e5d2146  vmovaps xmm8, [rsp+0x80]
00007d516e5d214f  vmovaps xmm9, [rsp+0x90]
00007d516e5d2158  vmovaps xmm10, [rsp+0xA0]
00007d516e5d2161  vmovaps xmm11, [rsp+0xB0]
00007d516e5d216a  vmovaps xmm12, [rsp+0xC0]
00007d516e5d2173  vmovaps xmm14, [rsp+0xD0]
00007d516e5d217c  vmovaps xmm15, [rsp+0xE0]
00007d516e5d2185  add rsp, 0xF0
00007d516e5d218c  pop r11
00007d516e5d218e  pop r10
00007d516e5d2190  pop r9
00007d516e5d2192  pop r8
00007d516e5d2194  pop rsi
00007d516e5d2195  pop rdi
00007d516e5d2196  pop rdx
00007d516e5d2197  pop rcx
00007d516e5d2198  pop rax
00007d516e5d2199  add rsp, 0x08
00007d516e5d219d  jmp 0x00007D516E5D1F81
00007d516e5d21a2  call 0x00007D516E4C2240
00007d516e5d21a7  jmp 0x00007D516E5D1F9B
00007d516e5d21ac  sub rsp, 0x08
00007d516e5d21b0  push rax
00007d516e5d21b1  push rcx
00007d516e5d21b2  push rdx
00007d516e5d21b3  push rdi
00007d516e5d21b4  push rsi
00007d516e5d21b5  push r8
00007d516e5d21b7  push r9
00007d516e5d21b9  push r10
00007d516e5d21bb  push r11
00007d516e5d21bd  sub rsp, 0xF0
00007d516e5d21c4  vmovaps [rsp], xmm0
00007d516e5d21c9  vmovaps [rsp+0x10], xmm1
00007d516e5d21cf  vmovaps [rsp+0x20], xmm2
00007d516e5d21d5  vmovaps [rsp+0x30], xmm3
00007d516e5d21db  vmovaps [rsp+0x40], xmm4
00007d516e5d21e1  vmovaps [rsp+0x50], xmm5
00007d516e5d21e7  vmovaps [rsp+0x60], xmm6
00007d516e5d21ed  vmovaps [rsp+0x70], xmm7
00007d516e5d21f3  vmovaps [rsp+0x80], xmm8
00007d516e5d21fc  vmovaps [rsp+0x90], xmm9
00007d516e5d2205  vmovaps [rsp+0xA0], xmm10
00007d516e5d220e  vmovaps [rsp+0xB0], xmm11
00007d516e5d2217  vmovaps [rsp+0xC0], xmm12
00007d516e5d2220  vmovaps [rsp+0xD0], xmm13
00007d516e5d2229  vmovaps [rsp+0xE0], xmm15
00007d516e5d2232  sub rsp, 0x30
00007d516e5d2236  movaps [rsp], xmm14
00007d516e5d223b  movaps [rsp+0x10], xmm1
00007d516e5d2240  movaps [rsp+0x20], xmm15
00007d516e5d2246  lea rdi, [rsp]
00007d516e5d224a  mov esi, 0x00
00007d516e5d224f  mov rax, 0x5EE43AF14530
00007d516e5d2259  call rax
00007d516e5d225b  movaps xmm14, [rsp]
00007d516e5d2260  add rsp, 0x30
00007d516e5d2264  vmovaps xmm0, [rsp]
00007d516e5d2269  vmovaps xmm1, [rsp+0x10]
00007d516e5d226f  vmovaps xmm2, [rsp+0x20]
00007d516e5d2275  vmovaps xmm3, [rsp+0x30]
00007d516e5d227b  vmovaps xmm4, [rsp+0x40]
00007d516e5d2281  vmovaps xmm5, [rsp+0x50]
00007d516e5d2287  vmovaps xmm6, [rsp+0x60]
00007d516e5d228d  vmovaps xmm7, [rsp+0x70]
00007d516e5d2293  vmovaps xmm8, [rsp+0x80]
00007d516e5d229c  vmovaps xmm9, [rsp+0x90]
00007d516e5d22a5  vmovaps xmm10, [rsp+0xA0]
00007d516e5d22ae  vmovaps xmm11, [rsp+0xB0]
00007d516e5d22b7  vmovaps xmm12, [rsp+0xC0]
00007d516e5d22c0  vmovaps xmm13, [rsp+0xD0]
00007d516e5d22c9  vmovaps xmm15, [rsp+0xE0]
00007d516e5d22d2  add rsp, 0xF0
00007d516e5d22d9  pop r11
00007d516e5d22db  pop r10
00007d516e5d22dd  pop r9
00007d516e5d22df  pop r8
00007d516e5d22e1  pop rsi
00007d516e5d22e2  pop rdi
00007d516e5d22e3  pop rdx
00007d516e5d22e4  pop rcx
00007d516e5d22e5  pop rax
00007d516e5d22e6  add rsp, 0x08
00007d516e5d22ea  jmp 0x00007D516E5D1FBE
00007d516e5d22ef  call 0x00007D516E4C34C0
00007d516e5d22f4  jmp 0x00007D516E5D1FD4
00007d516e5d22f9  int3
00007d516e5d22fa  nop [rax+rax*1], ax
00007d516e5d2300  mov rax, [r15+0x50]
00007d516e5d2304  lea r14, [rax+0x80]
00007d516e5d230b  movups xmm1, [r13+r14*1]
00007d516e5d2311  lea r14, [rax+0x90]
00007d516e5d2318  movups xmm15, [r13+r14*1]
00007d516e5d231e  vxorps xmm14, xmm14, xmm14
00007d516e5d2323  vpbroadcastq xmm14, xmm14
00007d516e5d2328  lea r14, [rax+0x40]
00007d516e5d232c  movups xmm13, [r13+r14*1]
00007d516e5d2332  lea r14, [rax+0x50]
00007d516e5d2336  movups xmm12, [r13+r14*1]
00007d516e5d233c  mov qword ptr [r15+0x48], 0x00
00007d516e5d2344  movups xmm11, [r13+rax*1]
00007d516e5d234a  lea r14, [rax+0x10]
00007d516e5d234e  movups xmm10, [r13+r14*1]
00007d516e5d2354  mov r14, [r15+0xF8]
00007d516e5d235b  lea r12, [r14+0xE0]
00007d516e5d2362  movups [r13+r12*1], xmm15
00007d516e5d2368  lea r12, [r14+0xF0]
00007d516e5d236f  movups [r13+r12*1], xmm1
00007d516e5d2375  lea r12, [rax+0xC0]
00007d516e5d237c  movups xmm1, [r13+r12*1]
00007d516e5d2382  lea r12, [rax+0xD0]
00007d516e5d2389  movups xmm15, [r13+r12*1]
00007d516e5d238f  lea r12, [rax+0x140]
00007d516e5d2396  movups xmm9, [r13+r12*1]
00007d516e5d239c  lea r12, [rax+0x150]
00007d516e5d23a3  movups xmm8, [r13+r12*1]
00007d516e5d23a9  lea r12, [rax+0x180]
00007d516e5d23b0  movups xmm7, [r13+r12*1]
00007d516e5d23b6  lea r12, [rax+0x190]
00007d516e5d23bd  movups xmm6, [r13+r12*1]
00007d516e5d23c3  lea r12, [r14+0xC0]
00007d516e5d23ca  movups [r13+r12*1], xmm15
00007d516e5d23d0  lea r12, [r14+0xD0]
00007d516e5d23d7  movups [r13+r12*1], xmm1
00007d516e5d23dd  lea r12, [rax+0x100]
00007d516e5d23e4  movups xmm1, [r13+r12*1]
00007d516e5d23ea  lea r12, [rax+0x110]
00007d516e5d23f1  movups xmm15, [r13+r12*1]
00007d516e5d23f7  lea r12, [rax+0x1C0]
00007d516e5d23fe  movups xmm5, [r13+r12*1]
00007d516e5d2404  lea r12, [rax+0x1D0]
00007d516e5d240b  movups xmm4, [r13+r12*1]
00007d516e5d2411  lea r12, [rax+0x20]
00007d516e5d2415  movups xmm3, [r13+r12*1]
00007d516e5d241b  lea r12, [rax+0x30]
00007d516e5d241f  movups xmm2, [r13+r12*1]
00007d516e5d2425  movaps [r15+0x1F0], xmm2
00007d516e5d242d  lea r12, [r14+0x20]
00007d516e5d2431  movups [r13+r12*1], xmm1
00007d516e5d2437  lea r12, [r14+0x30]
00007d516e5d243b  movups [r13+r12*1], xmm12
00007d516e5d2441  lea r12, [rax+0x60]
00007d516e5d2445  movups xmm1, [r13+r12*1]
00007d516e5d244b  lea r12, [rax+0x70]
00007d516e5d244f  movups xmm12, [r13+r12*1]
00007d516e5d2455  lea r12, [r14+0x60]
00007d516e5d2459  movups [r13+r12*1], xmm11
00007d516e5d245f  lea r12, [r14+0x70]
00007d516e5d2463  movups [r13+r12*1], xmm5
00007d516e5d2469  lea r12, [rax+0xE0]
00007d516e5d2470  movups xmm11, [r13+r12*1]
00007d516e5d2476  lea r12, [rax+0xF0]
00007d516e5d247d  movups xmm5, [r13+r12*1]
00007d516e5d2483  lea r12, [rax+0x120]
00007d516e5d248a  vmovaps [rsp+0x10], xmm1
00007d516e5d2490  movups xmm1, [r13+r12*1]
00007d516e5d2496  lea r12, [rax+0x130]
00007d516e5d249d  vmovaps [rsp+0x20], xmm1
00007d516e5d24a3  movups xmm1, [r13+r12*1]
00007d516e5d24a9  lea r12, [r14+0xA0]
00007d516e5d24b0  movups [r13+r12*1], xmm12
00007d516e5d24b6  lea r12, [r14+0xB0]
00007d516e5d24bd  vmovaps xmm12, [rsp+0x10]
00007d516e5d24c3  movups [r13+r12*1], xmm12
00007d516e5d24c9  lea r12, [rax+0xA0]
00007d516e5d24d0  movups xmm12, [r13+r12*1]
00007d516e5d24d6  lea r12, [rax+0xB0]
00007d516e5d24dd  vmovaps [rsp+0x10], xmm1
00007d516e5d24e3  movups xmm1, [r13+r12*1]
00007d516e5d24e9  lea r12, [rax+0x160]
00007d516e5d24f0  vmovaps [rsp+0x30], xmm1
00007d516e5d24f6  movups xmm1, [r13+r12*1]
00007d516e5d24fc  lea r12, [rax+0x170]
00007d516e5d2503  vmovaps [rsp+0x40], xmm1
00007d516e5d2509  movups xmm1, [r13+r12*1]
00007d516e5d250f  movaps [r15+0x2B0], xmm1
00007d516e5d2517  lea r12, [rax+0x1A0]
00007d516e5d251e  vmovaps [rsp+0x50], xmm1
00007d516e5d2524  movups xmm1, [r13+r12*1]
00007d516e5d252a  lea r12, [rax+0x1B0]
00007d516e5d2531  vmovaps [rsp+0x60], xmm1
00007d516e5d2537  movups xmm1, [r13+r12*1]
00007d516e5d253d  vmovaps [rsp+0x70], xmm1
00007d516e5d2543  vmovaps xmm1, [rsp+0x60]
00007d516e5d2549  movaps [r15+0x290], xmm1
00007d516e5d2551  vmovaps [rsp+0x60], xmm1
00007d516e5d2557  vmovaps xmm1, [rsp+0x70]
00007d516e5d255d  movaps [r15+0x1E0], xmm1
00007d516e5d2565  lea r12, [r14+0x80]
00007d516e5d256c  vmovaps [rsp+0x70], xmm1
00007d516e5d2572  vmovaps xmm1, [rsp+0x30]
00007d516e5d2578  movups [r13+r12*1], xmm1
00007d516e5d257e  lea r12, [r14+0x90]
00007d516e5d2585  movups [r13+r12*1], xmm12
00007d516e5d258b  lea r12, [rax+0x1E0]
00007d516e5d2592  movups xmm1, [r13+r12*1]
00007d516e5d2598  lea r12, [rax+0x1F0]
00007d516e5d259f  movups xmm12, [r13+r12*1]
00007d516e5d25a5  mov qword ptr [r15+0x50], 0x432200
00007d516e5d25ad  lea rax, [r14+0x40]
00007d516e5d25b1  vmovaps [rsp+0x30], xmm1
00007d516e5d25b7  vmovaps xmm1, [rsp+0x40]
00007d516e5d25bd  movups [r13+rax*1], xmm1
00007d516e5d25c3  lea rax, [r14+0x50]
00007d516e5d25c7  movups [r13+rax*1], xmm10
00007d516e5d25cd  movups [r13+r14*1], xmm12
00007d516e5d25d3  lea rax, [r14+0x10]
00007d516e5d25d7  vmovaps xmm1, [rsp+0x30]
00007d516e5d25dd  movups [r13+rax*1], xmm1
00007d516e5d25e3  mov rax, [r15+0x40]
00007d516e5d25e7  vmovaps [rsp+0x30], xmm3
00007d516e5d25ed  vmovaps xmm1, [rsp+0x30]
00007d516e5d25f3  por xmm3, xmm1
00007d516e5d25f7  vmovaps [rsp+0x30], xmm6
00007d516e5d25fd  vmovaps xmm12, [rsp+0x30]
00007d516e5d2603  por xmm6, xmm12
00007d516e5d2608  lea r12, [rax+0x30]
00007d516e5d260c  mov r11, [r13+r12*1]
00007d516e5d2611  lea r12, [rax+0x38]
00007d516e5d2615  mov r10, [r13+r12*1]
00007d516e5d261a  movq xmm12, r11
00007d516e5d261f  movq xmm10, r10
00007d516e5d2624  movq xmm12, xmm12
00007d516e5d2629  vmovaps [rsp+0x30], xmm12
00007d516e5d262f  movq xmm12, xmm12
00007d516e5d2634  movaps [r15+0x130], xmm12
00007d516e5d263c  movq xmm10, xmm10
00007d516e5d2641  vmovaps [rsp+0x40], xmm10
00007d516e5d2647  movq xmm10, xmm10
00007d516e5d264c  movaps [r15+0x280], xmm10
00007d516e5d2654  vmovaps [rsp+0x80], xmm9
00007d516e5d265d  vmovaps xmm12, [rsp+0x80]
00007d516e5d2666  por xmm9, xmm12
00007d516e5d266b  lea r12, [rax+0x20]
00007d516e5d266f  mov r11, [r13+r12*1]
00007d516e5d2674  lea r12, [rax+0x28]
00007d516e5d2678  mov r10, [r13+r12*1]
00007d516e5d267d  movq xmm12, r11
00007d516e5d2682  movq xmm10, r10
00007d516e5d2687  movq xmm12, xmm12
00007d516e5d268c  vmovaps [rsp+0x80], xmm12
00007d516e5d2695  movq xmm12, xmm12
00007d516e5d269a  movaps [r15+0x150], xmm12
00007d516e5d26a2  movq xmm10, xmm10
00007d516e5d26a7  vmovaps [rsp+0x90], xmm10
00007d516e5d26b0  movq xmm10, xmm10
00007d516e5d26b5  movaps [r15+0x140], xmm10
00007d516e5d26bd  lea r12, [rax+0x10]
00007d516e5d26c1  mov r11, [r13+r12*1]
00007d516e5d26c6  lea r12, [rax+0x18]
00007d516e5d26ca  mov r10, [r13+r12*1]
00007d516e5d26cf  movq xmm12, r11
00007d516e5d26d4  movq xmm10, r10
00007d516e5d26d9  movq xmm12, xmm12
00007d516e5d26de  vmovaps [rsp+0xA0], xmm12
00007d516e5d26e7  movq xmm12, xmm12
00007d516e5d26ec  movaps [r15+0x170], xmm12
00007d516e5d26f4  movq xmm10, xmm10
00007d516e5d26f9  vmovaps [rsp+0xB0], xmm10
00007d516e5d2702  movq xmm10, xmm10
00007d516e5d2707  movaps [r15+0x160], xmm10
00007d516e5d270f  mov r12, [r13+rax*1]
00007d516e5d2714  vmovq xmm12, r12
00007d516e5d2719  vpbroadcastq xmm12, xmm12
00007d516e5d271e  lea r12, [rax+0x08]
00007d516e5d2722  mov rax, [r13+r12*1]
00007d516e5d2727  movq xmm10, rax
00007d516e5d272c  movaps [r15+0x230], xmm10
00007d516e5d2734  lea rax, [r14+0x50]
00007d516e5d2738  movups xmm10, [r13+rax*1]
00007d516e5d273e  lea rax, [r14+0x60]
00007d516e5d2742  vmovaps [rsp+0xC0], xmm1
00007d516e5d274b  movups xmm1, [r13+rax*1]
00007d516e5d2751  lea rax, [r14+0x30]
00007d516e5d2755  vmovaps [rsp+0xD0], xmm1
00007d516e5d275e  movups xmm1, [r13+rax*1]
00007d516e5d2764  mov qword ptr [r15+0x60], 0x432200
00007d516e5d276c  mov qword ptr [r15+0x58], 0x40
00007d516e5d2774  vmovaps [rsp+0xE0], xmm1
00007d516e5d277d  vmovaps [rsp+0xF0], xmm15
00007d516e5d2786  vmovaps xmm15, [rsp+0xC0]
00007d516e5d278f  vmovaps [rsp+0xC0], xmm14
00007d516e5d2798  movaps xmm1, xmm12
00007d516e5d279c  mulpd xmm1, xmm15
00007d516e5d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007d516e5d27a6  ptest xmm14, xmm14
00007d516e5d27ac  jnz 0x00007D516E5D3863
00007d516e5d27b2  movq xmm15, qword ptr [r15+0x230]
00007d516e5d27bb  vmovaps [rsp+0x100], xmm15
00007d516e5d27c4  vpermilpd xmm15, xmm15, 0x00
00007d516e5d27ca  vmovaps [rsp+0x110], xmm1
00007d516e5d27d3  vmovaps xmm1, [rsp+0xE0]
00007d516e5d27dc  vmovaps [rsp+0xE0], xmm13
00007d516e5d27e5  movaps xmm14, xmm1
00007d516e5d27e9  mulpd xmm14, xmm15
00007d516e5d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007d516e5d27f4  ptest xmm13, xmm13
00007d516e5d27fa  jnz 0x00007D516E5D39A5
00007d516e5d2800  vxorps xmm1, xmm1, xmm1
00007d516e5d2804  vpbroadcastq xmm1, xmm1
00007d516e5d2809  vmovaps xmm13, [rsp+0xD0]
00007d516e5d2812  vmovaps [rsp+0xD0], xmm1
00007d516e5d281b  movaps xmm15, xmm12
00007d516e5d281f  mulpd xmm15, xmm13
00007d516e5d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007d516e5d282a  ptest xmm1, xmm1
00007d516e5d282f  jnz 0x00007D516E5D3AE8
00007d516e5d2835  movaps xmm1, xmm12
00007d516e5d2839  mulpd xmm1, xmm10
00007d516e5d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007d516e5d2843  ptest xmm13, xmm13
00007d516e5d2849  jnz 0x00007D516E5D3C2C
00007d516e5d284f  movaps xmm13, xmm12
00007d516e5d2853  mulpd xmm13, xmm2
00007d516e5d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007d516e5d285e  ptest xmm10, xmm10
00007d516e5d2864  jnz 0x00007D516E5D3D6E
00007d516e5d286a  vmovaps [rsp+0x120], xmm7
00007d516e5d2873  vmovaps xmm12, [rsp+0x120]
00007d516e5d287c  por xmm7, xmm12
00007d516e5d2881  vmovaps xmm12, [rsp+0xE0]
00007d516e5d288a  vmovaps xmm10, [rsp+0xE0]
00007d516e5d2893  por xmm12, xmm10
00007d516e5d2898  vmovaps xmm2, [rsp+0x100]
00007d516e5d28a1  vpermilpd xmm2, xmm2, 0x00
00007d516e5d28a7  vmovaps [rsp+0xE0], xmm1
00007d516e5d28b0  vmovaps [rsp+0x120], xmm15
00007d516e5d28b9  movaps xmm1, xmm10
00007d516e5d28bd  mulpd xmm1, xmm2
00007d516e5d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007d516e5d28c6  ptest xmm15, xmm15
00007d516e5d28cc  jnz 0x00007D516E5D3EB1
00007d516e5d28d2  xor eax, eax
00007d516e5d28d4  mov r12d, 0x40
00007d516e5d28da  mov r11d, 0x200
00007d516e5d28e0  cmp r12, r11
00007d516e5d28e3  cmc
00007d516e5d28e4  lahf
00007d516e5d28e5  seto al
00007d516e5d28e8  mov [r15+0x108], eax
00007d516e5d28ef  vmovaps xmm10, [rsp+0x110]
00007d516e5d28f8  vmovaps xmm2, [rsp+0xD0]
00007d516e5d2901  vmovaps [rsp+0xD0], xmm1
00007d516e5d290a  movaps xmm15, xmm10
00007d516e5d290e  addpd xmm15, xmm2
00007d516e5d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007d516e5d2919  ptest xmm1, xmm1
00007d516e5d291e  jnz 0x00007D516E5D3FF2
00007d516e5d2924  vmovaps xmm10, [rsp+0x120]
00007d516e5d292d  vmovaps [rsp+0x110], xmm15
00007d516e5d2936  vmovaps xmm15, [rsp+0xC0]
00007d516e5d293f  vmovaps [rsp+0xC0], xmm14
00007d516e5d2948  movaps xmm1, xmm10
00007d516e5d294c  addpd xmm1, xmm15
00007d516e5d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007d516e5d2956  ptest xmm14, xmm14
00007d516e5d295c  jnz 0x00007D516E5D4135
00007d516e5d2962  vmovaps xmm10, [rsp+0xE0]
00007d516e5d296b  vmovaps [rsp+0xE0], xmm1
00007d516e5d2974  movaps xmm14, xmm10
00007d516e5d2978  addpd xmm14, xmm15
00007d516e5d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007d516e5d2983  ptest xmm1, xmm1
00007d516e5d2988  jnz 0x00007D516E5D4277
00007d516e5d298e  vmovaps xmm1, [rsp+0x10]
00007d516e5d2994  vmovaps xmm15, [rsp+0x10]
00007d516e5d299a  por xmm1, xmm15
00007d516e5d299f  vmovaps xmm15, [rsp+0x20]
00007d516e5d29a5  vmovaps xmm10, [rsp+0x20]
00007d516e5d29ab  por xmm15, xmm10
00007d516e5d29b0  vmovaps [rsp+0x10], xmm5
00007d516e5d29b6  vmovaps xmm10, [rsp+0x10]
00007d516e5d29bc  por xmm5, xmm10
00007d516e5d29c1  vmovaps [rsp+0x10], xmm11
00007d516e5d29c7  vmovaps xmm10, [rsp+0x10]
00007d516e5d29cd  por xmm11, xmm10
00007d516e5d29d2  vmovaps [rsp+0x10], xmm4
00007d516e5d29d8  vmovaps xmm10, [rsp+0x10]
00007d516e5d29de  por xmm4, xmm10
00007d516e5d29e3  vmovaps [rsp+0x10], xmm8
00007d516e5d29e9  vmovaps xmm10, [rsp+0x10]
00007d516e5d29ef  por xmm8, xmm10
00007d516e5d29f4  vmovaps xmm10, [rsp+0xF0]
00007d516e5d29fd  vmovaps [rsp+0x10], xmm1
00007d516e5d2a03  vmovaps xmm1, [rsp+0xF0]
00007d516e5d2a0c  por xmm10, xmm1
00007d516e5d2a11  lea rax, [r14+0xA0]
00007d516e5d2a18  movups xmm1, [r13+rax*1]
00007d516e5d2a1e  lea rax, [r14+0xB0]
00007d516e5d2a25  vmovaps [rsp+0x20], xmm1
00007d516e5d2a2b  movups xmm1, [r13+rax*1]
00007d516e5d2a31  vmovaps [rsp+0xF0], xmm1
00007d516e5d2a3a  vmovaps [rsp+0x120], xmm15
00007d516e5d2a43  movaps xmm1, xmm13
00007d516e5d2a47  addpd xmm1, xmm2
00007d516e5d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d516e5d2a50  ptest xmm15, xmm15
00007d516e5d2a56  jnz 0x00007D516E5D43CF
00007d516e5d2a5c  lea rax, [r14+0xF0]
00007d516e5d2a63  movups xmm15, [r13+rax*1]
00007d516e5d2a69  vmovaps xmm2, [rsp+0xE0]
00007d516e5d2a72  vmovaps [rsp+0xE0], xmm1
00007d516e5d2a7b  vmovaps xmm1, [rsp+0xD0]
00007d516e5d2a84  vmovaps [rsp+0xD0], xmm15
00007d516e5d2a8d  movaps xmm13, xmm2
00007d516e5d2a91  addpd xmm13, xmm1
00007d516e5d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007d516e5d2a9c  ptest xmm15, xmm15
00007d516e5d2aa2  jnz 0x00007D516E5D451A
00007d516e5d2aa8  vmovaps xmm15, [rsp+0xC0]
00007d516e5d2ab1  movaps xmm1, xmm14
00007d516e5d2ab5  addpd xmm1, xmm15
00007d516e5d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007d516e5d2abf  ptest xmm2, xmm2
00007d516e5d2ac4  jnz 0x00007D516E5D465C
00007d516e5d2aca  vmovaps xmm15, [rsp+0x100]
00007d516e5d2ad3  vpermilpd xmm15, xmm15, 0x00
00007d516e5d2ad9  vmovaps xmm2, [rsp+0xF0]
00007d516e5d2ae2  vmovaps [rsp+0xC0], xmm1
00007d516e5d2aeb  movaps xmm14, xmm2
00007d516e5d2aef  mulpd xmm14, xmm15
00007d516e5d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007d516e5d2afa  ptest xmm1, xmm1
00007d516e5d2aff  jnz 0x00007D516E5D479E
00007d516e5d2b05  vmovaps xmm1, [rsp+0xA0]
00007d516e5d2b0e  vpermilpd xmm1, xmm1, 0x00
00007d516e5d2b14  vmovaps xmm2, [rsp+0xD0]
00007d516e5d2b1d  vmovaps [rsp+0xD0], xmm14
00007d516e5d2b26  movaps xmm15, xmm2
00007d516e5d2b2a  mulpd xmm15, xmm1
00007d516e5d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007d516e5d2b35  ptest xmm14, xmm14
00007d516e5d2b3b  jnz 0x00007D516E5D48E1
00007d516e5d2b41  lea rax, [r14+0xE0]
00007d516e5d2b48  movups xmm1, [r13+rax*1]
00007d516e5d2b4e  vmovaps xmm14, [rsp+0x100]
00007d516e5d2b57  vpermilpd xmm14, xmm14, 0x00
00007d516e5d2b5d  vmovaps [rsp+0xF0], xmm1
00007d516e5d2b66  vmovaps xmm1, [rsp+0x20]
00007d516e5d2b6c  vmovaps [rsp+0x20], xmm15
00007d516e5d2b72  movaps xmm2, xmm1
00007d516e5d2b75  mulpd xmm2, xmm14
00007d516e5d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d516e5d2b7f  ptest xmm15, xmm15
00007d516e5d2b85  jnz 0x00007D516E5D4A2D
00007d516e5d2b8b  vmovaps [rsp+0x100], xmm10
00007d516e5d2b94  vmovaps xmm1, [rsp+0x100]
00007d516e5d2b9d  por xmm10, xmm1
00007d516e5d2ba2  movaps [r15+0x300], xmm10
00007d516e5d2baa  vmovaps [rsp+0x100], xmm8
00007d516e5d2bb3  vmovaps xmm1, [rsp+0x100]
00007d516e5d2bbc  por xmm8, xmm1
00007d516e5d2bc1  movaps [r15+0x190], xmm8
00007d516e5d2bc9  vmovaps xmm1, [rsp+0xA0]
00007d516e5d2bd2  vpermilpd xmm1, xmm1, 0x00
00007d516e5d2bd8  vmovaps xmm14, [rsp+0xF0]
00007d516e5d2be1  vmovaps [rsp+0xF0], xmm13
00007d516e5d2bea  movaps xmm15, xmm14
00007d516e5d2bee  mulpd xmm15, xmm1
00007d516e5d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007d516e5d2bf9  ptest xmm13, xmm13
00007d516e5d2bff  jnz 0x00007D516E5D4B6E
00007d516e5d2c05  lea rax, [r14+0x90]
00007d516e5d2c0c  movups xmm1, [r13+rax*1]
00007d516e5d2c12  vmovaps [rsp+0x100], xmm4
00007d516e5d2c1b  vmovaps xmm14, [rsp+0x100]
00007d516e5d2c24  por xmm4, xmm14
00007d516e5d2c29  movaps [r15+0x1C0], xmm4
00007d516e5d2c31  vmovaps [rsp+0x100], xmm11
00007d516e5d2c3a  vmovaps xmm14, [rsp+0x100]
00007d516e5d2c43  por xmm11, xmm14
00007d516e5d2c48  movaps [r15+0x200], xmm11
00007d516e5d2c50  vmovaps [rsp+0x100], xmm5
00007d516e5d2c59  vmovaps xmm14, [rsp+0x100]
00007d516e5d2c62  por xmm5, xmm14
00007d516e5d2c67  movaps [r15+0x2D0], xmm5
00007d516e5d2c6f  vmovaps xmm14, [rsp+0x120]
00007d516e5d2c78  vmovaps xmm13, [rsp+0x120]
00007d516e5d2c81  por xmm14, xmm13
00007d516e5d2c86  movaps [r15+0x2E0], xmm14
00007d516e5d2c8e  vmovaps [rsp+0x100], xmm1
00007d516e5d2c97  vmovaps xmm1, [rsp+0x110]
00007d516e5d2ca0  vmovaps [rsp+0x110], xmm15
00007d516e5d2ca9  vmovaps xmm15, [rsp+0xD0]
00007d516e5d2cb2  vmovaps [rsp+0xD0], xmm14
00007d516e5d2cbb  movaps xmm13, xmm1
00007d516e5d2cbf  addpd xmm13, xmm15
00007d516e5d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007d516e5d2cca  ptest xmm14, xmm14
00007d516e5d2cd0  jnz 0x00007D516E5D4CBB
00007d516e5d2cd6  vmovaps xmm1, [rsp+0xA0]
00007d516e5d2cdf  vpermilpd xmm1, xmm1, 0x00
00007d516e5d2ce5  vmovaps xmm14, [rsp+0x100]
00007d516e5d2cee  vmovaps [rsp+0x100], xmm13
00007d516e5d2cf7  movaps xmm15, xmm14
00007d516e5d2cfb  mulpd xmm15, xmm1
00007d516e5d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007d516e5d2d06  ptest xmm13, xmm13
00007d516e5d2d0c  jnz 0x00007D516E5D4DFE
00007d516e5d2d12  lea rax, [r14+0x80]
00007d516e5d2d19  movups xmm1, [r13+rax*1]
00007d516e5d2d1f  vmovaps xmm13, [rsp+0xE0]
00007d516e5d2d28  vmovaps [rsp+0xE0], xmm1
00007d516e5d2d31  movaps xmm14, xmm13
00007d516e5d2d35  addpd xmm14, xmm2
00007d516e5d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007d516e5d2d40  ptest xmm1, xmm1
00007d516e5d2d45  jnz 0x00007D516E5D4F4B
00007d516e5d2d4b  vmovaps xmm13, [rsp+0xF0]
00007d516e5d2d54  vmovaps xmm2, [rsp+0x20]
00007d516e5d2d5a  vmovaps [rsp+0x20], xmm15
00007d516e5d2d60  movaps xmm1, xmm13
00007d516e5d2d64  addpd xmm1, xmm2
00007d516e5d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007d516e5d2d6d  ptest xmm15, xmm15
00007d516e5d2d73  jnz 0x00007D516E5D508E
00007d516e5d2d79  vmovaps xmm15, [rsp+0x10]
00007d516e5d2d7f  vmovaps xmm13, [rsp+0x10]
00007d516e5d2d85  por xmm15, xmm13
00007d516e5d2d8a  movaps [r15+0x2F0], xmm15
00007d516e5d2d92  vmovaps xmm13, [rsp+0xA0]
00007d516e5d2d9b  vpermilpd xmm13, xmm13, 0x00
00007d516e5d2da1  vmovaps [rsp+0x10], xmm1
00007d516e5d2da7  vmovaps xmm1, [rsp+0xE0]
00007d516e5d2db0  vmovaps [rsp+0xA0], xmm15
00007d516e5d2db9  movaps xmm2, xmm1
00007d516e5d2dbc  mulpd xmm2, xmm13
00007d516e5d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007d516e5d2dc6  ptest xmm15, xmm15
00007d516e5d2dcc  jnz 0x00007D516E5D51CF
00007d516e5d2dd2  lea rax, [r14+0xD0]
00007d516e5d2dd9  movups xmm1, [r13+rax*1]
00007d516e5d2ddf  vmovaps xmm13, [rsp+0xC0]
00007d516e5d2de8  vmovaps [rsp+0xC0], xmm1
00007d516e5d2df1  vmovaps xmm1, [rsp+0x110]
00007d516e5d2dfa  vmovaps [rsp+0xE0], xmm14
00007d516e5d2e03  movaps xmm15, xmm13
00007d516e5d2e07  addpd xmm15, xmm1
00007d516e5d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007d516e5d2e12  ptest xmm14, xmm14
00007d516e5d2e18  jnz 0x00007D516E5D531A
00007d516e5d2e1e  vmovaps xmm1, [rsp+0xB0]
00007d516e5d2e27  vpermilpd xmm1, xmm1, 0x00
00007d516e5d2e2d  movaps xmm14, xmm11
00007d516e5d2e31  mulpd xmm14, xmm1
00007d516e5d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007d516e5d2e3c  ptest xmm13, xmm13
00007d516e5d2e42  jnz 0x00007D516E5D545D
00007d516e5d2e48  movaps [r15+0x260], xmm14
00007d516e5d2e50  vxorps xmm1, xmm1, xmm1
00007d516e5d2e54  vpbroadcastq xmm1, xmm1
00007d516e5d2e59  movaps [r15+0x1B0], xmm1
00007d516e5d2e61  vmovaps xmm1, [rsp+0xB0]
00007d516e5d2e6a  vpermilpd xmm1, xmm1, 0x00
00007d516e5d2e70  vmovaps xmm11, [rsp+0xC0]
00007d516e5d2e79  vmovaps [rsp+0xC0], xmm15
00007d516e5d2e82  movaps xmm13, xmm11
00007d516e5d2e86  mulpd xmm13, xmm1
00007d516e5d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007d516e5d2e91  ptest xmm15, xmm15
00007d516e5d2e97  jnz 0x00007D516E5D55A0
00007d516e5d2e9d  lea rax, [r14+0xC0]
00007d516e5d2ea4  movups xmm1, [r13+rax*1]
00007d516e5d2eaa  vmovaps xmm11, [rsp+0x100]
00007d516e5d2eb3  vmovaps [rsp+0xF0], xmm1
00007d516e5d2ebc  vmovaps xmm1, [rsp+0x20]
00007d516e5d2ec2  vmovaps [rsp+0x20], xmm14
00007d516e5d2ec8  movaps xmm15, xmm11
00007d516e5d2ecc  addpd xmm15, xmm1
00007d516e5d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007d516e5d2ed7  ptest xmm14, xmm14
00007d516e5d2edd  jnz 0x00007D516E5D56ED
00007d516e5d2ee3  vmovaps [rsp+0x100], xmm9
00007d516e5d2eec  vmovaps xmm1, [rsp+0x100]
00007d516e5d2ef5  por xmm9, xmm1
00007d516e5d2efa  movaps [r15+0x270], xmm9
00007d516e5d2f02  vmovaps [rsp+0x100], xmm6
00007d516e5d2f0b  vmovaps xmm1, [rsp+0x100]
00007d516e5d2f14  por xmm6, xmm1
00007d516e5d2f18  movaps [r15+0x1A0], xmm6
00007d516e5d2f20  vmovaps xmm14, [rsp+0xB0]
00007d516e5d2f29  vpermilpd xmm14, xmm14, 0x00
00007d516e5d2f2f  vmovaps xmm6, [rsp+0xF0]
00007d516e5d2f38  vmovaps [rsp+0xF0], xmm1
00007d516e5d2f41  movaps xmm11, xmm6
00007d516e5d2f45  mulpd xmm11, xmm14
00007d516e5d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007d516e5d2f50  ptest xmm1, xmm1
00007d516e5d2f55  jnz 0x00007D516E5D5830
00007d516e5d2f5b  lea rax, [r14+0x20]
00007d516e5d2f5f  movups xmm1, [r13+rax*1]
00007d516e5d2f65  movaps [r15+0x110], xmm1
00007d516e5d2f6d  vmovaps xmm6, [rsp+0xE0]
00007d516e5d2f76  vmovaps [rsp+0xE0], xmm1
00007d516e5d2f7f  movaps xmm14, xmm6
00007d516e5d2f83  addpd xmm14, xmm2
00007d516e5d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007d516e5d2f8e  ptest xmm1, xmm1
00007d516e5d2f93  jnz 0x00007D516E5D597D
00007d516e5d2f99  vmovaps xmm1, [rsp+0xB0]
00007d516e5d2fa2  vpermilpd xmm1, xmm1, 0x00
00007d516e5d2fa8  movaps xmm6, xmm5
00007d516e5d2fab  mulpd xmm6, xmm1
00007d516e5d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007d516e5d2fb4  ptest xmm2, xmm2
00007d516e5d2fb9  jnz 0x00007D516E5D5ABF
00007d516e5d2fbf  vmovaps xmm5, [rsp+0x10]
00007d516e5d2fc5  movaps xmm1, xmm5
00007d516e5d2fc8  addpd xmm1, xmm13
00007d516e5d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007d516e5d2fd2  ptest xmm2, xmm2
00007d516e5d2fd7  jnz 0x00007D516E5D5BFF
00007d516e5d2fdd  vmovaps xmm13, [rsp+0x80]
00007d516e5d2fe6  vpermilpd xmm13, xmm13, 0x00
00007d516e5d2fec  vmovaps xmm2, [rsp+0xE0]
00007d516e5d2ff5  vmovaps [rsp+0x10], xmm1
00007d516e5d2ffb  movaps xmm5, xmm2
00007d516e5d2ffe  mulpd xmm5, xmm13
00007d516e5d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007d516e5d3008  ptest xmm1, xmm1
00007d516e5d300d  jnz 0x00007D516E5D5D40
00007d516e5d3013  vmovaps xmm1, [rsp+0x80]
00007d516e5d301c  vpermilpd xmm1, xmm1, 0x00
00007d516e5d3022  movaps xmm13, xmm10
00007d516e5d3026  mulpd xmm13, xmm1
00007d516e5d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007d516e5d3031  ptest xmm2, xmm2
00007d516e5d3036  jnz 0x00007D516E5D5E81
00007d516e5d303c  vmovaps xmm10, [rsp+0x20]
00007d516e5d3042  movaps xmm1, xmm15
00007d516e5d3046  addpd xmm1, xmm10
00007d516e5d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d516e5d3050  ptest xmm2, xmm2
00007d516e5d3055  jnz 0x00007D516E5D5FC4
00007d516e5d305b  vmovaps xmm10, [rsp+0xC0]
00007d516e5d3064  movaps xmm15, xmm10
00007d516e5d3068  addpd xmm15, xmm11
00007d516e5d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007d516e5d3073  ptest xmm2, xmm2
00007d516e5d3078  jnz 0x00007D516E5D6106
00007d516e5d307e  vmovaps xmm11, [rsp+0x80]
00007d516e5d3087  vpermilpd xmm11, xmm11, 0x00
00007d516e5d308d  vmovaps xmm2, [rsp+0xD0]
00007d516e5d3096  vmovaps [rsp+0x20], xmm1
00007d516e5d309c  movaps xmm10, xmm2
00007d516e5d30a0  mulpd xmm10, xmm11
00007d516e5d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007d516e5d30ab  ptest xmm1, xmm1
00007d516e5d30b0  jnz 0x00007D516E5D624A
00007d516e5d30b6  vmovaps xmm1, [rsp+0x80]
00007d516e5d30bf  vpermilpd xmm1, xmm1, 0x00
00007d516e5d30c5  vmovaps xmm2, [rsp+0xA0]
00007d516e5d30ce  vmovaps [rsp+0x80], xmm15
00007d516e5d30d7  movaps xmm11, xmm2
00007d516e5d30db  mulpd xmm11, xmm1
00007d516e5d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007d516e5d30e6  ptest xmm15, xmm15
00007d516e5d30ec  jnz 0x00007D516E5D638D
00007d516e5d30f2  movaps xmm1, xmm14
00007d516e5d30f6  addpd xmm1, xmm6
00007d516e5d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007d516e5d30ff  ptest xmm15, xmm15
00007d516e5d3105  jnz 0x00007D516E5D64CF
00007d516e5d310b  vmovaps xmm14, [rsp+0x10]
00007d516e5d3111  movaps xmm15, xmm14
00007d516e5d3115  addpd xmm15, xmm5
00007d516e5d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007d516e5d3120  ptest xmm6, xmm6
00007d516e5d3125  jnz 0x00007D516E5D6610
00007d516e5d312b  vmovaps xmm14, [rsp+0x90]
00007d516e5d3134  vpermilpd xmm14, xmm14, 0x00
00007d516e5d313a  movaps xmm6, xmm9
00007d516e5d313e  mulpd xmm6, xmm14
00007d516e5d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007d516e5d3148  ptest xmm5, xmm5
00007d516e5d314d  jnz 0x00007D516E5D6753
00007d516e5d3153  vmovaps xmm9, [rsp+0x80]
00007d516e5d315c  movaps xmm14, xmm9
00007d516e5d3160  addpd xmm14, xmm13
00007d516e5d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007d516e5d316b  ptest xmm5, xmm5
00007d516e5d3170  jnz 0x00007D516E5D6895
00007d516e5d3176  vmovaps xmm9, [rsp+0x20]
00007d516e5d317c  movaps xmm13, xmm9
00007d516e5d3180  addpd xmm13, xmm10
00007d516e5d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007d516e5d318b  ptest xmm5, xmm5
00007d516e5d3190  jnz 0x00007D516E5D69D9
00007d516e5d3196  vmovaps [rsp+0x10], xmm12
00007d516e5d319c  vmovaps xmm10, [rsp+0x10]
00007d516e5d31a2  por xmm12, xmm10
00007d516e5d31a7  movaps [r15+0x250], xmm12
00007d516e5d31af  vmovaps [rsp+0x10], xmm7
00007d516e5d31b5  vmovaps xmm12, [rsp+0x10]
00007d516e5d31bb  por xmm7, xmm12
00007d516e5d31c0  movaps [r15+0x2A0], xmm7
00007d516e5d31c8  vmovaps [rsp+0x10], xmm3
00007d516e5d31ce  vmovaps xmm12, [rsp+0x10]
00007d516e5d31d4  por xmm3, xmm12
00007d516e5d31d9  movaps [r15+0x1D0], xmm3
00007d516e5d31e1  lea rax, [r14+0x40]
00007d516e5d31e5  movups xmm12, [r13+rax*1]
00007d516e5d31eb  movaps [r15+0x2C0], xmm12
00007d516e5d31f3  vmovaps xmm10, [rsp+0x90]
00007d516e5d31fc  vpermilpd xmm10, xmm10, 0x00
00007d516e5d3202  movaps xmm9, xmm8
00007d516e5d3206  mulpd xmm9, xmm10
00007d516e5d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007d516e5d3211  ptest xmm5, xmm5
00007d516e5d3216  jnz 0x00007D516E5D6B27
00007d516e5d321c  movaps xmm10, xmm1
00007d516e5d3220  addpd xmm10, xmm11
00007d516e5d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007d516e5d322b  ptest xmm8, xmm8
00007d516e5d3231  jnz 0x00007D516E5D6C6B
00007d516e5d3237  movaps xmm1, xmm15
00007d516e5d323b  addpd xmm1, xmm6
00007d516e5d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007d516e5d3244  ptest xmm11, xmm11
00007d516e5d324a  jnz 0x00007D516E5D6DAE
00007d516e5d3250  vmovaps xmm15, [rsp+0x90]
00007d516e5d3259  vpermilpd xmm15, xmm15, 0x00
00007d516e5d325f  movaps xmm11, xmm12
00007d516e5d3263  mulpd xmm11, xmm15
00007d516e5d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007d516e5d326e  ptest xmm8, xmm8
00007d516e5d3274  jnz 0x00007D516E5D6EEF
00007d516e5d327a  vmovaps xmm15, [rsp+0x90]
00007d516e5d3283  vpermilpd xmm15, xmm15, 0x00
00007d516e5d3289  vmovaps xmm8, [rsp+0x50]
00007d516e5d328f  movaps xmm12, xmm8
00007d516e5d3293  mulpd xmm12, xmm15
00007d516e5d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007d516e5d329e  ptest xmm6, xmm6
00007d516e5d32a3  jnz 0x00007D516E5D7033
00007d516e5d32a9  vmovaps xmm15, [rsp+0x30]
00007d516e5d32af  vpermilpd xmm15, xmm15, 0x00
00007d516e5d32b5  movaps xmm8, xmm7
00007d516e5d32b9  mulpd xmm8, xmm15
00007d516e5d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007d516e5d32c4  ptest xmm6, xmm6
00007d516e5d32c9  jnz 0x00007D516E5D7177
00007d516e5d32cf  movaps xmm15, xmm14
00007d516e5d32d3  addpd xmm15, xmm9
00007d516e5d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007d516e5d32de  ptest xmm7, xmm7
00007d516e5d32e3  jnz 0x00007D516E5D72BA
00007d516e5d32e9  vmovaps xmm14, [rsp+0x30]
00007d516e5d32ef  vpermilpd xmm14, xmm14, 0x00
00007d516e5d32f5  vmovaps xmm7, [rsp+0xF0]
00007d516e5d32fe  movaps xmm9, xmm7
00007d516e5d3302  mulpd xmm9, xmm14
00007d516e5d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007d516e5d330d  ptest xmm6, xmm6
00007d516e5d3312  jnz 0x00007D516E5D73FE
00007d516e5d3318  movaps xmm14, xmm13
00007d516e5d331c  addpd xmm14, xmm11
00007d516e5d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007d516e5d3327  ptest xmm7, xmm7
00007d516e5d332c  jnz 0x00007D516E5D7541
00007d516e5d3332  vmovaps xmm13, [rsp+0x30]
00007d516e5d3338  vpermilpd xmm13, xmm13, 0x00
00007d516e5d333e  vmovaps xmm7, [rsp+0x60]
00007d516e5d3344  movaps xmm11, xmm7
00007d516e5d3348  mulpd xmm11, xmm13
00007d516e5d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007d516e5d3353  ptest xmm6, xmm6
00007d516e5d3358  jnz 0x00007D516E5D7685
00007d516e5d335e  movaps xmm13, xmm10
00007d516e5d3362  addpd xmm13, xmm12
00007d516e5d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007d516e5d336d  ptest xmm7, xmm7
00007d516e5d3372  jnz 0x00007D516E5D77C8
00007d516e5d3378  vmovaps xmm12, [rsp+0x30]
00007d516e5d337e  vpermilpd xmm12, xmm12, 0x00
00007d516e5d3384  vmovaps xmm7, [rsp+0x70]
00007d516e5d338a  movaps xmm10, xmm7
00007d516e5d338e  mulpd xmm10, xmm12
00007d516e5d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007d516e5d3399  ptest xmm6, xmm6
00007d516e5d339e  jnz 0x00007D516E5D790C
00007d516e5d33a4  movaps xmm12, xmm1
00007d516e5d33a8  addpd xmm12, xmm8
00007d516e5d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007d516e5d33b3  ptest xmm7, xmm7
00007d516e5d33b8  jnz 0x00007D516E5D7A4F
00007d516e5d33be  lea rax, [r14+0x70]
00007d516e5d33c2  movups xmm1, [r13+rax*1]
00007d516e5d33c8  movaps [r15+0x240], xmm1
00007d516e5d33d0  movaps xmm8, xmm15
00007d516e5d33d4  addpd xmm8, xmm9
00007d516e5d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007d516e5d33df  ptest xmm7, xmm7
00007d516e5d33e4  jnz 0x00007D516E5D7B9C
00007d516e5d33ea  movaps [r15+0x170], xmm8
00007d516e5d33f2  vmovaps xmm15, [rsp+0x40]
00007d516e5d33f8  vpermilpd xmm15, xmm15, 0x00
00007d516e5d33fe  movaps xmm9, xmm1
00007d516e5d3402  mulpd xmm9, xmm15
00007d516e5d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007d516e5d340d  ptest xmm7, xmm7
00007d516e5d3412  jnz 0x00007D516E5D7CE0
00007d516e5d3418  vmovaps xmm1, [rsp+0x40]
00007d516e5d341e  vpermilpd xmm1, xmm1, 0x00
00007d516e5d3424  movaps xmm15, xmm4
00007d516e5d3428  mulpd xmm15, xmm1
00007d516e5d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007d516e5d3433  ptest xmm7, xmm7
00007d516e5d3438  jnz 0x00007D516E5D7E23
00007d516e5d343e  movaps [r15+0x180], xmm15
00007d516e5d3446  movaps xmm1, xmm14
00007d516e5d344a  addpd xmm1, xmm11
00007d516e5d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007d516e5d3454  ptest xmm7, xmm7
00007d516e5d3459  jnz 0x00007D516E5D7F65
00007d516e5d345f  movaps [r15+0x210], xmm1
00007d516e5d3467  movups xmm14, [r13+r14*1]
00007d516e5d346d  lea rax, [r14+0x10]
00007d516e5d3471  movups xmm11, [r13+rax*1]
00007d516e5d3477  movaps [r15+0x230], xmm11
00007d516e5d347f  movaps xmm7, xmm13
00007d516e5d3483  addpd xmm7, xmm10
00007d516e5d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007d516e5d348d  ptest xmm6, xmm6
00007d516e5d3492  jnz 0x00007D516E5D80BB
00007d516e5d3498  movaps [r15+0x130], xmm7
00007d516e5d34a0  vmovaps xmm13, [rsp+0x40]
00007d516e5d34a6  vpermilpd xmm13, xmm13, 0x00
00007d516e5d34ac  movaps xmm10, xmm11
00007d516e5d34b0  mulpd xmm10, xmm13
00007d516e5d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d516e5d34bb  ptest xmm6, xmm6
00007d516e5d34c0  jnz 0x00007D516E5D81FD
00007d516e5d34c6  movaps [r15+0x220], xmm10
00007d516e5d34ce  vmovaps xmm13, [rsp+0x40]
00007d516e5d34d4  vpermilpd xmm13, xmm13, 0x00
00007d516e5d34da  movaps xmm11, xmm14
00007d516e5d34de  mulpd xmm11, xmm13
00007d516e5d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007d516e5d34e9  ptest xmm6, xmm6
00007d516e5d34ee  jnz 0x00007D516E5D8341
00007d516e5d34f4  movaps xmm14, xmm12
00007d516e5d34f8  addpd xmm14, xmm9
00007d516e5d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007d516e5d3503  ptest xmm13, xmm13
00007d516e5d3509  jnz 0x00007D516E5D8485
00007d516e5d350f  movaps [r15+0x140], xmm14
00007d516e5d3517  movaps xmm13, xmm8
00007d516e5d351b  addpd xmm13, xmm15
00007d516e5d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007d516e5d3526  ptest xmm12, xmm12
00007d516e5d352c  jnz 0x00007D516E5D85C9
00007d516e5d3532  movaps [r15+0x150], xmm13
00007d516e5d353a  movaps xmm15, xmm1
00007d516e5d353e  addpd xmm15, xmm10
00007d516e5d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007d516e5d3549  ptest xmm12, xmm12
00007d516e5d354f  jnz 0x00007D516E5D870D
00007d516e5d3555  movaps [r15+0x160], xmm15
00007d516e5d355d  movaps xmm1, xmm7
00007d516e5d3560  addpd xmm1, xmm11
00007d516e5d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007d516e5d356a  ptest xmm12, xmm12
00007d516e5d3570  jnz 0x00007D516E5D8850
00007d516e5d3576  movaps [r15+0x120], xmm1
00007d516e5d357e  mov eax, 0x432200
00007d516e5d3583  movups [r13+rax*1], xmm14
00007d516e5d3589  mov eax, 0x432210
00007d516e5d358e  movups [r13+rax*1], xmm13
00007d516e5d3594  mov eax, 0x432220
00007d516e5d3599  movups [r13+rax*1], xmm15
00007d516e5d359f  mov eax, 0x432230
00007d516e5d35a4  movups [r13+rax*1], xmm1
00007d516e5d35aa  mov eax, [r15+0x108]
00007d516e5d35b1  sahf
00007d516e5d35b2  jnz 0x00007D516E5D35E4
00007d516e5d35b4  cmp dword ptr [r15+0x318], 0x00
00007d516e5d35bc  jz 0x00007D516E5DEAE0
00007d516e5d35c2  nop [rax+rax*1], ax
00007d516e5d35cb  nop [rax+rax*1], eax
00007d516e5d35d3  mov eax, 0x4106D0
00007d516e5d35d8  mov [r15+0x100], rax
00007d516e5d35df  jmp 0x00007D516E3FE110
00007d516e5d35e4  cmp dword ptr [r15+0x318], 0x00
00007d516e5d35ec  jz 0x00007D516E5D89C0
00007d516e5d35f2  nop [rax+rax*1], ax
00007d516e5d35fb  nop [rax+rax*1], eax
00007d516e5d3603  mov eax, 0x410504
00007d516e5d3608  mov [r15+0x100], rax
00007d516e5d360f  jmp 0x00007D516E3FE110
00007d516e5d3614  int3
00007d516e5d3615  call 0x00007D516E4D64F0
00007d516e5d361a  jmp 0x00007D516E5D2311
00007d516e5d361f  call 0x00007D516E4E5820
00007d516e5d3624  jmp 0x00007D516E5D231E
00007d516e5d3629  call 0x00007D516E4E3320
00007d516e5d362e  jmp 0x00007D516E5D2332
00007d516e5d3633  call 0x00007D516E4E20A0
00007d516e5d3638  jmp 0x00007D516E5D233C
00007d516e5d363d  call 0x00007D516E409D70
00007d516e5d3642  jmp 0x00007D516E5D234A
00007d516e5d3647  call 0x00007D516E4DFBC0
00007d516e5d364c  jmp 0x00007D516E5D2354
00007d516e5d3651  call 0x00007D516E4C4740
00007d516e5d3656  jmp 0x00007D516E5D2368
00007d516e5d365b  call 0x00007D516E4B5400
00007d516e5d3660  jmp 0x00007D516E5D2375
00007d516e5d3665  call 0x00007D516E4B52F0
00007d516e5d366a  jmp 0x00007D516E5D2382
00007d516e5d366f  call 0x00007D516E4C4620
00007d516e5d3674  jmp 0x00007D516E5D238F
00007d516e5d3679  call 0x00007D516E4BD750
00007d516e5d367e  jmp 0x00007D516E5D239C
00007d516e5d3683  call 0x00007D516E4BC4E0
00007d516e5d3688  jmp 0x00007D516E5D23A9
00007d516e5d368d  call 0x00007D516E4BB270
00007d516e5d3692  jmp 0x00007D516E5D23B6
00007d516e5d3697  call 0x00007D516E4BA000
00007d516e5d369c  jmp 0x00007D516E5D23C3
00007d516e5d36a1  call 0x00007D516E4C4740
00007d516e5d36a6  jmp 0x00007D516E5D23D0
00007d516e5d36ab  call 0x00007D516E4B5400
00007d516e5d36b0  jmp 0x00007D516E5D23DD
00007d516e5d36b5  call 0x00007D516E4B52F0
00007d516e5d36ba  jmp 0x00007D516E5D23EA
00007d516e5d36bf  call 0x00007D516E4C4620
00007d516e5d36c4  jmp 0x00007D516E5D23F7
00007d516e5d36c9  call 0x00007D516E4B8D90
00007d516e5d36ce  jmp 0x00007D516E5D2404
00007d516e5d36d3  call 0x00007D516E4B8A20
00007d516e5d36d8  jmp 0x00007D516E5D2411
00007d516e5d36dd  call 0x00007D516E4B77B0
00007d516e5d36e2  jmp 0x00007D516E5D241B
00007d516e5d36e7  call 0x00007D516E4B6550
00007d516e5d36ec  jmp 0x00007D516E5D2425
00007d516e5d36f1  call 0x00007D516E4B5400
00007d516e5d36f6  jmp 0x00007D516E5D2437
00007d516e5d36fb  call 0x00007D516E4C0FC0
00007d516e5d3700  jmp 0x00007D516E5D2441
00007d516e5d3705  call 0x00007D516E4B52F0
00007d516e5d370a  jmp 0x00007D516E5D244B
00007d516e5d370f  call 0x00007D516E4C0EA0
00007d516e5d3714  jmp 0x00007D516E5D2455
00007d516e5d3719  call 0x00007D516E4BFD50
00007d516e5d371e  jmp 0x00007D516E5D245F
00007d516e5d3723  call 0x00007D516E4B8EA0
00007d516e5d3728  jmp 0x00007D516E5D2469
00007d516e5d372d  call 0x00007D516E4BFC30
00007d516e5d3732  jmp 0x00007D516E5D2476
00007d516e5d3737  call 0x00007D516E4B8D90
00007d516e5d373c  jmp 0x00007D516E5D2483
00007d516e5d3741  call 0x00007D516E4B52F0
00007d516e5d3746  jmp 0x00007D516E5D2496
00007d516e5d374b  call 0x00007D516E4B52F0
00007d516e5d3750  jmp 0x00007D516E5D24A9
00007d516e5d3755  call 0x00007D516E4C0FC0
00007d516e5d375a  jmp 0x00007D516E5D24B6
00007d516e5d375f  call 0x00007D516E4C0FC0
00007d516e5d3764  jmp 0x00007D516E5D24C9
00007d516e5d3769  call 0x00007D516E4C0EA0
00007d516e5d376e  jmp 0x00007D516E5D24D6
00007d516e5d3773  call 0x00007D516E4B52F0
00007d516e5d3778  jmp 0x00007D516E5D24E9
00007d516e5d377d  call 0x00007D516E4B52F0
00007d516e5d3782  jmp 0x00007D516E5D24FC
00007d516e5d3787  call 0x00007D516E4B52F0
00007d516e5d378c  jmp 0x00007D516E5D250F
00007d516e5d3791  call 0x00007D516E4B52F0
00007d516e5d3796  jmp 0x00007D516E5D252A
00007d516e5d379b  call 0x00007D516E4B52F0
00007d516e5d37a0  jmp 0x00007D516E5D253D
00007d516e5d37a5  call 0x00007D516E4B5400
00007d516e5d37aa  jmp 0x00007D516E5D257E
00007d516e5d37af  call 0x00007D516E4C0FC0
00007d516e5d37b4  jmp 0x00007D516E5D258B
00007d516e5d37b9  call 0x00007D516E4B52F0
00007d516e5d37be  jmp 0x00007D516E5D2598
00007d516e5d37c3  call 0x00007D516E4C0EA0
00007d516e5d37c8  jmp 0x00007D516E5D25A5
00007d516e5d37cd  call 0x00007D516E3FF540
00007d516e5d37d2  jmp 0x00007D516E5D25C3
00007d516e5d37d7  call 0x00007D516E408C20
00007d516e5d37dc  jmp 0x00007D516E5D25CD
00007d516e5d37e1  call 0x00007D516E4E21C0
00007d516e5d37e6  jmp 0x00007D516E5D25D3
00007d516e5d37eb  call 0x00007D516E3FF540
00007d516e5d37f0  jmp 0x00007D516E5D25E3
00007d516e5d37f5  call 0x00007D516E4C0370
00007d516e5d37fa  jmp 0x00007D516E5D2611
00007d516e5d37ff  call 0x00007D516E4BF100
00007d516e5d3804  jmp 0x00007D516E5D261A
00007d516e5d3809  call 0x00007D516E4C0370
00007d516e5d380e  jmp 0x00007D516E5D2674
00007d516e5d3813  call 0x00007D516E4BF100
00007d516e5d3818  jmp 0x00007D516E5D267D
00007d516e5d381d  call 0x00007D516E4C0370
00007d516e5d3822  jmp 0x00007D516E5D26C6
00007d516e5d3827  call 0x00007D516E4BF100
00007d516e5d382c  jmp 0x00007D516E5D26CF
00007d516e5d3831  call 0x00007D516E40B720
00007d516e5d3836  jmp 0x00007D516E5D2714
00007d516e5d383b  call 0x00007D516E4B47C0
00007d516e5d3840  jmp 0x00007D516E5D2727
00007d516e5d3845  call 0x00007D516E408B00
00007d516e5d384a  jmp 0x00007D516E5D273E
00007d516e5d384f  call 0x00007D516E3FF430
00007d516e5d3854  jmp 0x00007D516E5D2751
00007d516e5d3859  call 0x00007D516E3FF430
00007d516e5d385e  jmp 0x00007D516E5D2764
00007d516e5d3863  sub rsp, 0x08
00007d516e5d3867  push rax
00007d516e5d3868  push rcx
00007d516e5d3869  push rdx
00007d516e5d386a  push rdi
00007d516e5d386b  push rsi
00007d516e5d386c  push r8
00007d516e5d386e  push r9
00007d516e5d3870  push r10
00007d516e5d3872  push r11
00007d516e5d3874  sub rsp, 0xF0
00007d516e5d387b  vmovaps [rsp], xmm0
00007d516e5d3880  vmovaps [rsp+0x10], xmm2
00007d516e5d3886  vmovaps [rsp+0x20], xmm3
00007d516e5d388c  vmovaps [rsp+0x30], xmm4
00007d516e5d3892  vmovaps [rsp+0x40], xmm5
00007d516e5d3898  vmovaps [rsp+0x50], xmm6
00007d516e5d389e  vmovaps [rsp+0x60], xmm7
00007d516e5d38a4  vmovaps [rsp+0x70], xmm8
00007d516e5d38aa  vmovaps [rsp+0x80], xmm9
00007d516e5d38b3  vmovaps [rsp+0x90], xmm10
00007d516e5d38bc  vmovaps [rsp+0xA0], xmm11
00007d516e5d38c5  vmovaps [rsp+0xB0], xmm12
00007d516e5d38ce  vmovaps [rsp+0xC0], xmm13
00007d516e5d38d7  vmovaps [rsp+0xD0], xmm14
00007d516e5d38e0  vmovaps [rsp+0xE0], xmm15
00007d516e5d38e9  sub rsp, 0x30
00007d516e5d38ed  movaps [rsp], xmm1
00007d516e5d38f1  movaps [rsp+0x10], xmm12
00007d516e5d38f7  movaps [rsp+0x20], xmm15
00007d516e5d38fd  lea rdi, [rsp]
00007d516e5d3901  mov esi, 0x00
00007d516e5d3906  mov rax, 0x5EE43AF14530
00007d516e5d3910  call rax
00007d516e5d3912  movaps xmm1, [rsp]
00007d516e5d3916  add rsp, 0x30
00007d516e5d391a  vmovaps xmm0, [rsp]
00007d516e5d391f  vmovaps xmm2, [rsp+0x10]
00007d516e5d3925  vmovaps xmm3, [rsp+0x20]
00007d516e5d392b  vmovaps xmm4, [rsp+0x30]
00007d516e5d3931  vmovaps xmm5, [rsp+0x40]
00007d516e5d3937  vmovaps xmm6, [rsp+0x50]
00007d516e5d393d  vmovaps xmm7, [rsp+0x60]
00007d516e5d3943  vmovaps xmm8, [rsp+0x70]
00007d516e5d3949  vmovaps xmm9, [rsp+0x80]
00007d516e5d3952  vmovaps xmm10, [rsp+0x90]
00007d516e5d395b  vmovaps xmm11, [rsp+0xA0]
00007d516e5d3964  vmovaps xmm12, [rsp+0xB0]
00007d516e5d396d  vmovaps xmm13, [rsp+0xC0]
00007d516e5d3976  vmovaps xmm14, [rsp+0xD0]
00007d516e5d397f  vmovaps xmm15, [rsp+0xE0]
00007d516e5d3988  add rsp, 0xF0
00007d516e5d398f  pop r11
00007d516e5d3991  pop r10
00007d516e5d3993  pop r9
00007d516e5d3995  pop r8
00007d516e5d3997  pop rsi
00007d516e5d3998  pop rdi
00007d516e5d3999  pop rdx
00007d516e5d399a  pop rcx
00007d516e5d399b  pop rax
00007d516e5d399c  add rsp, 0x08
00007d516e5d39a0  jmp 0x00007D516E5D27B2
00007d516e5d39a5  sub rsp, 0x08
00007d516e5d39a9  push rax
00007d516e5d39aa  push rcx
00007d516e5d39ab  push rdx
00007d516e5d39ac  push rdi
00007d516e5d39ad  push rsi
00007d516e5d39ae  push r8
00007d516e5d39b0  push r9
00007d516e5d39b2  push r10
00007d516e5d39b4  push r11
00007d516e5d39b6  sub rsp, 0xF0
00007d516e5d39bd  vmovaps [rsp], xmm0
00007d516e5d39c2  vmovaps [rsp+0x10], xmm1
00007d516e5d39c8  vmovaps [rsp+0x20], xmm2
00007d516e5d39ce  vmovaps [rsp+0x30], xmm3
00007d516e5d39d4  vmovaps [rsp+0x40], xmm4
00007d516e5d39da  vmovaps [rsp+0x50], xmm5
00007d516e5d39e0  vmovaps [rsp+0x60], xmm6
00007d516e5d39e6  vmovaps [rsp+0x70], xmm7
00007d516e5d39ec  vmovaps [rsp+0x80], xmm8
00007d516e5d39f5  vmovaps [rsp+0x90], xmm9
00007d516e5d39fe  vmovaps [rsp+0xA0], xmm10
00007d516e5d3a07  vmovaps [rsp+0xB0], xmm11
00007d516e5d3a10  vmovaps [rsp+0xC0], xmm12
00007d516e5d3a19  vmovaps [rsp+0xD0], xmm13
00007d516e5d3a22  vmovaps [rsp+0xE0], xmm15
00007d516e5d3a2b  sub rsp, 0x30
00007d516e5d3a2f  movaps [rsp], xmm14
00007d516e5d3a34  movaps [rsp+0x10], xmm1
00007d516e5d3a39  movaps [rsp+0x20], xmm15
00007d516e5d3a3f  lea rdi, [rsp]
00007d516e5d3a43  mov esi, 0x00
00007d516e5d3a48  mov rax, 0x5EE43AF14530
00007d516e5d3a52  call rax
00007d516e5d3a54  movaps xmm14, [rsp]
00007d516e5d3a59  add rsp, 0x30
00007d516e5d3a5d  vmovaps xmm0, [rsp]
00007d516e5d3a62  vmovaps xmm1, [rsp+0x10]
00007d516e5d3a68  vmovaps xmm2, [rsp+0x20]
00007d516e5d3a6e  vmovaps xmm3, [rsp+0x30]
00007d516e5d3a74  vmovaps xmm4, [rsp+0x40]
00007d516e5d3a7a  vmovaps xmm5, [rsp+0x50]
00007d516e5d3a80  vmovaps xmm6, [rsp+0x60]
00007d516e5d3a86  vmovaps xmm7, [rsp+0x70]
00007d516e5d3a8c  vmovaps xmm8, [rsp+0x80]
00007d516e5d3a95  vmovaps xmm9, [rsp+0x90]
00007d516e5d3a9e  vmovaps xmm10, [rsp+0xA0]
00007d516e5d3aa7  vmovaps xmm11, [rsp+0xB0]
00007d516e5d3ab0  vmovaps xmm12, [rsp+0xC0]
00007d516e5d3ab9  vmovaps xmm13, [rsp+0xD0]
00007d516e5d3ac2  vmovaps xmm15, [rsp+0xE0]
00007d516e5d3acb  add rsp, 0xF0
00007d516e5d3ad2  pop r11
00007d516e5d3ad4  pop r10
00007d516e5d3ad6  pop r9
00007d516e5d3ad8  pop r8
00007d516e5d3ada  pop rsi
00007d516e5d3adb  pop rdi
00007d516e5d3adc  pop rdx
00007d516e5d3add  pop rcx
00007d516e5d3ade  pop rax
00007d516e5d3adf  add rsp, 0x08
00007d516e5d3ae3  jmp 0x00007D516E5D2800
00007d516e5d3ae8  sub rsp, 0x08
00007d516e5d3aec  push rax
00007d516e5d3aed  push rcx
00007d516e5d3aee  push rdx
00007d516e5d3aef  push rdi
00007d516e5d3af0  push rsi
00007d516e5d3af1  push r8
00007d516e5d3af3  push r9
00007d516e5d3af5  push r10
00007d516e5d3af7  push r11
00007d516e5d3af9  sub rsp, 0xF0
00007d516e5d3b00  vmovaps [rsp], xmm0
00007d516e5d3b05  vmovaps [rsp+0x10], xmm1
00007d516e5d3b0b  vmovaps [rsp+0x20], xmm2
00007d516e5d3b11  vmovaps [rsp+0x30], xmm3
00007d516e5d3b17  vmovaps [rsp+0x40], xmm4
00007d516e5d3b1d  vmovaps [rsp+0x50], xmm5
00007d516e5d3b23  vmovaps [rsp+0x60], xmm6
00007d516e5d3b29  vmovaps [rsp+0x70], xmm7
00007d516e5d3b2f  vmovaps [rsp+0x80], xmm8
00007d516e5d3b38  vmovaps [rsp+0x90], xmm9
00007d516e5d3b41  vmovaps [rsp+0xA0], xmm10
00007d516e5d3b4a  vmovaps [rsp+0xB0], xmm11
00007d516e5d3b53  vmovaps [rsp+0xC0], xmm12
00007d516e5d3b5c  vmovaps [rsp+0xD0], xmm13
00007d516e5d3b65  vmovaps [rsp+0xE0], xmm14
00007d516e5d3b6e  sub rsp, 0x30
00007d516e5d3b72  movaps [rsp], xmm15
00007d516e5d3b77  movaps [rsp+0x10], xmm12
00007d516e5d3b7d  movaps [rsp+0x20], xmm13
00007d516e5d3b83  lea rdi, [rsp]
00007d516e5d3b87  mov esi, 0x00
00007d516e5d3b8c  mov rax, 0x5EE43AF14530
00007d516e5d3b96  call rax
00007d516e5d3b98  movaps xmm15, [rsp]
00007d516e5d3b9d  add rsp, 0x30
00007d516e5d3ba1  vmovaps xmm0, [rsp]
00007d516e5d3ba6  vmovaps xmm1, [rsp+0x10]
00007d516e5d3bac  vmovaps xmm2, [rsp+0x20]
00007d516e5d3bb2  vmovaps xmm3, [rsp+0x30]
00007d516e5d3bb8  vmovaps xmm4, [rsp+0x40]
00007d516e5d3bbe  vmovaps xmm5, [rsp+0x50]
00007d516e5d3bc4  vmovaps xmm6, [rsp+0x60]
00007d516e5d3bca  vmovaps xmm7, [rsp+0x70]
00007d516e5d3bd0  vmovaps xmm8, [rsp+0x80]
00007d516e5d3bd9  vmovaps xmm9, [rsp+0x90]
00007d516e5d3be2  vmovaps xmm10, [rsp+0xA0]
00007d516e5d3beb  vmovaps xmm11, [rsp+0xB0]
00007d516e5d3bf4  vmovaps xmm12, [rsp+0xC0]
00007d516e5d3bfd  vmovaps xmm13, [rsp+0xD0]
00007d516e5d3c06  vmovaps xmm14, [rsp+0xE0]
00007d516e5d3c0f  add rsp, 0xF0
00007d516e5d3c16  pop r11
00007d516e5d3c18  pop r10
00007d516e5d3c1a  pop r9
00007d516e5d3c1c  pop r8
00007d516e5d3c1e  pop rsi
00007d516e5d3c1f  pop rdi
00007d516e5d3c20  pop rdx
00007d516e5d3c21  pop rcx
00007d516e5d3c22  pop rax
00007d516e5d3c23  add rsp, 0x08
00007d516e5d3c27  jmp 0x00007D516E5D2835
00007d516e5d3c2c  sub rsp, 0x08
00007d516e5d3c30  push rax
00007d516e5d3c31  push rcx
00007d516e5d3c32  push rdx
00007d516e5d3c33  push rdi
00007d516e5d3c34  push rsi
00007d516e5d3c35  push r8
00007d516e5d3c37  push r9
00007d516e5d3c39  push r10
00007d516e5d3c3b  push r11
00007d516e5d3c3d  sub rsp, 0xF0
00007d516e5d3c44  vmovaps [rsp], xmm0
00007d516e5d3c49  vmovaps [rsp+0x10], xmm2
00007d516e5d3c4f  vmovaps [rsp+0x20], xmm3
00007d516e5d3c55  vmovaps [rsp+0x30], xmm4
00007d516e5d3c5b  vmovaps [rsp+0x40], xmm5
00007d516e5d3c61  vmovaps [rsp+0x50], xmm6
00007d516e5d3c67  vmovaps [rsp+0x60], xmm7
00007d516e5d3c6d  vmovaps [rsp+0x70], xmm8
00007d516e5d3c73  vmovaps [rsp+0x80], xmm9
00007d516e5d3c7c  vmovaps [rsp+0x90], xmm10
00007d516e5d3c85  vmovaps [rsp+0xA0], xmm11
00007d516e5d3c8e  vmovaps [rsp+0xB0], xmm12
00007d516e5d3c97  vmovaps [rsp+0xC0], xmm13
00007d516e5d3ca0  vmovaps [rsp+0xD0], xmm14
00007d516e5d3ca9  vmovaps [rsp+0xE0], xmm15
00007d516e5d3cb2  sub rsp, 0x30
00007d516e5d3cb6  movaps [rsp], xmm1
00007d516e5d3cba  movaps [rsp+0x10], xmm12
00007d516e5d3cc0  movaps [rsp+0x20], xmm10
00007d516e5d3cc6  lea rdi, [rsp]
00007d516e5d3cca  mov esi, 0x00
00007d516e5d3ccf  mov rax, 0x5EE43AF14530
00007d516e5d3cd9  call rax
00007d516e5d3cdb  movaps xmm1, [rsp]
00007d516e5d3cdf  add rsp, 0x30
00007d516e5d3ce3  vmovaps xmm0, [rsp]
00007d516e5d3ce8  vmovaps xmm2, [rsp+0x10]
00007d516e5d3cee  vmovaps xmm3, [rsp+0x20]
00007d516e5d3cf4  vmovaps xmm4, [rsp+0x30]
00007d516e5d3cfa  vmovaps xmm5, [rsp+0x40]
00007d516e5d3d00  vmovaps xmm6, [rsp+0x50]
00007d516e5d3d06  vmovaps xmm7, [rsp+0x60]
00007d516e5d3d0c  vmovaps xmm8, [rsp+0x70]
00007d516e5d3d12  vmovaps xmm9, [rsp+0x80]
00007d516e5d3d1b  vmovaps xmm10, [rsp+0x90]
00007d516e5d3d24  vmovaps xmm11, [rsp+0xA0]
00007d516e5d3d2d  vmovaps xmm12, [rsp+0xB0]
00007d516e5d3d36  vmovaps xmm13, [rsp+0xC0]
00007d516e5d3d3f  vmovaps xmm14, [rsp+0xD0]
00007d516e5d3d48  vmovaps xmm15, [rsp+0xE0]
00007d516e5d3d51  add rsp, 0xF0
00007d516e5d3d58  pop r11
00007d516e5d3d5a  pop r10
00007d516e5d3d5c  pop r9
00007d516e5d3d5e  pop r8
00007d516e5d3d60  pop rsi
00007d516e5d3d61  pop rdi
00007d516e5d3d62  pop rdx
00007d516e5d3d63  pop rcx
00007d516e5d3d64  pop rax
00007d516e5d3d65  add rsp, 0x08
00007d516e5d3d69  jmp 0x00007D516E5D284F
00007d516e5d3d6e  sub rsp, 0x08
00007d516e5d3d72  push rax
00007d516e5d3d73  push rcx
00007d516e5d3d74  push rdx
00007d516e5d3d75  push rdi
00007d516e5d3d76  push rsi
00007d516e5d3d77  push r8
00007d516e5d3d79  push r9
00007d516e5d3d7b  push r10
00007d516e5d3d7d  push r11
00007d516e5d3d7f  sub rsp, 0xF0
00007d516e5d3d86  vmovaps [rsp], xmm0
00007d516e5d3d8b  vmovaps [rsp+0x10], xmm1
00007d516e5d3d91  vmovaps [rsp+0x20], xmm2
00007d516e5d3d97  vmovaps [rsp+0x30], xmm3
00007d516e5d3d9d  vmovaps [rsp+0x40], xmm4
00007d516e5d3da3  vmovaps [rsp+0x50], xmm5
00007d516e5d3da9  vmovaps [rsp+0x60], xmm6
00007d516e5d3daf  vmovaps [rsp+0x70], xmm7
00007d516e5d3db5  vmovaps [rsp+0x80], xmm8
00007d516e5d3dbe  vmovaps [rsp+0x90], xmm9
00007d516e5d3dc7  vmovaps [rsp+0xA0], xmm10
00007d516e5d3dd0  vmovaps [rsp+0xB0], xmm11
00007d516e5d3dd9  vmovaps [rsp+0xC0], xmm12
00007d516e5d3de2  vmovaps [rsp+0xD0], xmm14
00007d516e5d3deb  vmovaps [rsp+0xE0], xmm15
00007d516e5d3df4  sub rsp, 0x30
00007d516e5d3df8  movaps [rsp], xmm13
00007d516e5d3dfd  movaps [rsp+0x10], xmm12
00007d516e5d3e03  movaps [rsp+0x20], xmm2
00007d516e5d3e08  lea rdi, [rsp]
00007d516e5d3e0c  mov esi, 0x00
00007d516e5d3e11  mov rax, 0x5EE43AF14530
00007d516e5d3e1b  call rax
00007d516e5d3e1d  movaps xmm13, [rsp]
00007d516e5d3e22  add rsp, 0x30
00007d516e5d3e26  vmovaps xmm0, [rsp]
00007d516e5d3e2b  vmovaps xmm1, [rsp+0x10]
00007d516e5d3e31  vmovaps xmm2, [rsp+0x20]
00007d516e5d3e37  vmovaps xmm3, [rsp+0x30]
00007d516e5d3e3d  vmovaps xmm4, [rsp+0x40]
00007d516e5d3e43  vmovaps xmm5, [rsp+0x50]
00007d516e5d3e49  vmovaps xmm6, [rsp+0x60]
00007d516e5d3e4f  vmovaps xmm7, [rsp+0x70]
00007d516e5d3e55  vmovaps xmm8, [rsp+0x80]
00007d516e5d3e5e  vmovaps xmm9, [rsp+0x90]
00007d516e5d3e67  vmovaps xmm10, [rsp+0xA0]
00007d516e5d3e70  vmovaps xmm11, [rsp+0xB0]
00007d516e5d3e79  vmovaps xmm12, [rsp+0xC0]
00007d516e5d3e82  vmovaps xmm14, [rsp+0xD0]
00007d516e5d3e8b  vmovaps xmm15, [rsp+0xE0]
00007d516e5d3e94  add rsp, 0xF0
00007d516e5d3e9b  pop r11
00007d516e5d3e9d  pop r10
00007d516e5d3e9f  pop r9
00007d516e5d3ea1  pop r8
00007d516e5d3ea3  pop rsi
00007d516e5d3ea4  pop rdi
00007d516e5d3ea5  pop rdx
00007d516e5d3ea6  pop rcx
00007d516e5d3ea7  pop rax
00007d516e5d3ea8  add rsp, 0x08
00007d516e5d3eac  jmp 0x00007D516E5D286A
00007d516e5d3eb1  sub rsp, 0x08
00007d516e5d3eb5  push rax
00007d516e5d3eb6  push rcx
00007d516e5d3eb7  push rdx
00007d516e5d3eb8  push rdi
00007d516e5d3eb9  push rsi
00007d516e5d3eba  push r8
00007d516e5d3ebc  push r9
00007d516e5d3ebe  push r10
00007d516e5d3ec0  push r11
00007d516e5d3ec2  sub rsp, 0xF0
00007d516e5d3ec9  vmovaps [rsp], xmm0
00007d516e5d3ece  vmovaps [rsp+0x10], xmm2
00007d516e5d3ed4  vmovaps [rsp+0x20], xmm3
00007d516e5d3eda  vmovaps [rsp+0x30], xmm4
00007d516e5d3ee0  vmovaps [rsp+0x40], xmm5
00007d516e5d3ee6  vmovaps [rsp+0x50], xmm6
00007d516e5d3eec  vmovaps [rsp+0x60], xmm7
00007d516e5d3ef2  vmovaps [rsp+0x70], xmm8
00007d516e5d3ef8  vmovaps [rsp+0x80], xmm9
00007d516e5d3f01  vmovaps [rsp+0x90], xmm10
00007d516e5d3f0a  vmovaps [rsp+0xA0], xmm11
00007d516e5d3f13  vmovaps [rsp+0xB0], xmm12
00007d516e5d3f1c  vmovaps [rsp+0xC0], xmm13
00007d516e5d3f25  vmovaps [rsp+0xD0], xmm14
00007d516e5d3f2e  vmovaps [rsp+0xE0], xmm15
00007d516e5d3f37  sub rsp, 0x30
00007d516e5d3f3b  movaps [rsp], xmm1
00007d516e5d3f3f  movaps [rsp+0x10], xmm10
00007d516e5d3f45  movaps [rsp+0x20], xmm2
00007d516e5d3f4a  lea rdi, [rsp]
00007d516e5d3f4e  mov esi, 0x00
00007d516e5d3f53  mov rax, 0x5EE43AF14530
00007d516e5d3f5d  call rax
00007d516e5d3f5f  movaps xmm1, [rsp]
00007d516e5d3f63  add rsp, 0x30
00007d516e5d3f67  vmovaps xmm0, [rsp]
00007d516e5d3f6c  vmovaps xmm2, [rsp+0x10]
00007d516e5d3f72  vmovaps xmm3, [rsp+0x20]
00007d516e5d3f78  vmovaps xmm4, [rsp+0x30]
00007d516e5d3f7e  vmovaps xmm5, [rsp+0x40]
00007d516e5d3f84  vmovaps xmm6, [rsp+0x50]
00007d516e5d3f8a  vmovaps xmm7, [rsp+0x60]
00007d516e5d3f90  vmovaps xmm8, [rsp+0x70]
00007d516e5d3f96  vmovaps xmm9, [rsp+0x80]
00007d516e5d3f9f  vmovaps xmm10, [rsp+0x90]
00007d516e5d3fa8  vmovaps xmm11, [rsp+0xA0]
00007d516e5d3fb1  vmovaps xmm12, [rsp+0xB0]
00007d516e5d3fba  vmovaps xmm13, [rsp+0xC0]
00007d516e5d3fc3  vmovaps xmm14, [rsp+0xD0]
00007d516e5d3fcc  vmovaps xmm15, [rsp+0xE0]
00007d516e5d3fd5  add rsp, 0xF0
00007d516e5d3fdc  pop r11
00007d516e5d3fde  pop r10
00007d516e5d3fe0  pop r9
00007d516e5d3fe2  pop r8
00007d516e5d3fe4  pop rsi
00007d516e5d3fe5  pop rdi
00007d516e5d3fe6  pop rdx
00007d516e5d3fe7  pop rcx
00007d516e5d3fe8  pop rax
00007d516e5d3fe9  add rsp, 0x08
00007d516e5d3fed  jmp 0x00007D516E5D28D2
00007d516e5d3ff2  sub rsp, 0x08
00007d516e5d3ff6  push rax
00007d516e5d3ff7  push rcx
00007d516e5d3ff8  push rdx
00007d516e5d3ff9  push rdi
00007d516e5d3ffa  push rsi
00007d516e5d3ffb  push r8
00007d516e5d3ffd  push r9
00007d516e5d3fff  push r10
00007d516e5d4001  push r11
00007d516e5d4003  sub rsp, 0xF0
00007d516e5d400a  vmovaps [rsp], xmm0
00007d516e5d400f  vmovaps [rsp+0x10], xmm1
00007d516e5d4015  vmovaps [rsp+0x20], xmm2
00007d516e5d401b  vmovaps [rsp+0x30], xmm3
00007d516e5d4021  vmovaps [rsp+0x40], xmm4
00007d516e5d4027  vmovaps [rsp+0x50], xmm5
00007d516e5d402d  vmovaps [rsp+0x60], xmm6
00007d516e5d4033  vmovaps [rsp+0x70], xmm7
00007d516e5d4039  vmovaps [rsp+0x80], xmm8
00007d516e5d4042  vmovaps [rsp+0x90], xmm9
00007d516e5d404b  vmovaps [rsp+0xA0], xmm10
00007d516e5d4054  vmovaps [rsp+0xB0], xmm11
00007d516e5d405d  vmovaps [rsp+0xC0], xmm12
00007d516e5d4066  vmovaps [rsp+0xD0], xmm13
00007d516e5d406f  vmovaps [rsp+0xE0], xmm14
00007d516e5d4078  sub rsp, 0x30
00007d516e5d407c  movaps [rsp], xmm15
00007d516e5d4081  movaps [rsp+0x10], xmm10
00007d516e5d4087  movaps [rsp+0x20], xmm2
00007d516e5d408c  lea rdi, [rsp]
00007d516e5d4090  mov esi, 0x00
00007d516e5d4095  mov rax, 0x5EE43AF14530
00007d516e5d409f  call rax
00007d516e5d40a1  movaps xmm15, [rsp]
00007d516e5d40a6  add rsp, 0x30
00007d516e5d40aa  vmovaps xmm0, [rsp]
00007d516e5d40af  vmovaps xmm1, [rsp+0x10]
00007d516e5d40b5  vmovaps xmm2, [rsp+0x20]
00007d516e5d40bb  vmovaps xmm3, [rsp+0x30]
00007d516e5d40c1  vmovaps xmm4, [rsp+0x40]
00007d516e5d40c7  vmovaps xmm5, [rsp+0x50]
00007d516e5d40cd  vmovaps xmm6, [rsp+0x60]
00007d516e5d40d3  vmovaps xmm7, [rsp+0x70]
00007d516e5d40d9  vmovaps xmm8, [rsp+0x80]
00007d516e5d40e2  vmovaps xmm9, [rsp+0x90]
00007d516e5d40eb  vmovaps xmm10, [rsp+0xA0]
00007d516e5d40f4  vmovaps xmm11, [rsp+0xB0]
00007d516e5d40fd  vmovaps xmm12, [rsp+0xC0]
00007d516e5d4106  vmovaps xmm13, [rsp+0xD0]
00007d516e5d410f  vmovaps xmm14, [rsp+0xE0]
00007d516e5d4118  add rsp, 0xF0
00007d516e5d411f  pop r11
00007d516e5d4121  pop r10
00007d516e5d4123  pop r9
00007d516e5d4125  pop r8
00007d516e5d4127  pop rsi
00007d516e5d4128  pop rdi
00007d516e5d4129  pop rdx
00007d516e5d412a  pop rcx
00007d516e5d412b  pop rax
00007d516e5d412c  add rsp, 0x08
00007d516e5d4130  jmp 0x00007D516E5D2924
00007d516e5d4135  sub rsp, 0x08
00007d516e5d4139  push rax
00007d516e5d413a  push rcx
00007d516e5d413b  push rdx
00007d516e5d413c  push rdi
00007d516e5d413d  push rsi
00007d516e5d413e  push r8
00007d516e5d4140  push r9
00007d516e5d4142  push r10
00007d516e5d4144  push r11
00007d516e5d4146  sub rsp, 0xF0
00007d516e5d414d  vmovaps [rsp], xmm0
00007d516e5d4152  vmovaps [rsp+0x10], xmm2
00007d516e5d4158  vmovaps [rsp+0x20], xmm3
00007d516e5d415e  vmovaps [rsp+0x30], xmm4
00007d516e5d4164  vmovaps [rsp+0x40], xmm5
00007d516e5d416a  vmovaps [rsp+0x50], xmm6
00007d516e5d4170  vmovaps [rsp+0x60], xmm7
00007d516e5d4176  vmovaps [rsp+0x70], xmm8
00007d516e5d417c  vmovaps [rsp+0x80], xmm9
00007d516e5d4185  vmovaps [rsp+0x90], xmm10
00007d516e5d418e  vmovaps [rsp+0xA0], xmm11
00007d516e5d4197  vmovaps [rsp+0xB0], xmm12
00007d516e5d41a0  vmovaps [rsp+0xC0], xmm13
00007d516e5d41a9  vmovaps [rsp+0xD0], xmm14
00007d516e5d41b2  vmovaps [rsp+0xE0], xmm15
00007d516e5d41bb  sub rsp, 0x30
00007d516e5d41bf  movaps [rsp], xmm1
00007d516e5d41c3  movaps [rsp+0x10], xmm10
00007d516e5d41c9  movaps [rsp+0x20], xmm15
00007d516e5d41cf  lea rdi, [rsp]
00007d516e5d41d3  mov esi, 0x00
00007d516e5d41d8  mov rax, 0x5EE43AF14530
00007d516e5d41e2  call rax
00007d516e5d41e4  movaps xmm1, [rsp]
00007d516e5d41e8  add rsp, 0x30
00007d516e5d41ec  vmovaps xmm0, [rsp]
00007d516e5d41f1  vmovaps xmm2, [rsp+0x10]
00007d516e5d41f7  vmovaps xmm3, [rsp+0x20]
00007d516e5d41fd  vmovaps xmm4, [rsp+0x30]
00007d516e5d4203  vmovaps xmm5, [rsp+0x40]
00007d516e5d4209  vmovaps xmm6, [rsp+0x50]
00007d516e5d420f  vmovaps xmm7, [rsp+0x60]
00007d516e5d4215  vmovaps xmm8, [rsp+0x70]
00007d516e5d421b  vmovaps xmm9, [rsp+0x80]
00007d516e5d4224  vmovaps xmm10, [rsp+0x90]
00007d516e5d422d  vmovaps xmm11, [rsp+0xA0]
00007d516e5d4236  vmovaps xmm12, [rsp+0xB0]
00007d516e5d423f  vmovaps xmm13, [rsp+0xC0]
00007d516e5d4248  vmovaps xmm14, [rsp+0xD0]
00007d516e5d4251  vmovaps xmm15, [rsp+0xE0]
00007d516e5d425a  add rsp, 0xF0
00007d516e5d4261  pop r11
00007d516e5d4263  pop r10
00007d516e5d4265  pop r9
00007d516e5d4267  pop r8
00007d516e5d4269  pop rsi
00007d516e5d426a  pop rdi
00007d516e5d426b  pop rdx
00007d516e5d426c  pop rcx
00007d516e5d426d  pop rax
00007d516e5d426e  add rsp, 0x08
00007d516e5d4272  jmp 0x00007D516E5D2962
00007d516e5d4277  sub rsp, 0x08
00007d516e5d427b  push rax
00007d516e5d427c  push rcx
00007d516e5d427d  push rdx
00007d516e5d427e  push rdi
00007d516e5d427f  push rsi
00007d516e5d4280  push r8
00007d516e5d4282  push r9
00007d516e5d4284  push r10
00007d516e5d4286  push r11
00007d516e5d4288  sub rsp, 0xF0
00007d516e5d428f  vmovaps [rsp], xmm0
00007d516e5d4294  vmovaps [rsp+0x10], xmm1
00007d516e5d429a  vmovaps [rsp+0x20], xmm2
00007d516e5d42a0  vmovaps [rsp+0x30], xmm3
00007d516e5d42a6  vmovaps [rsp+0x40], xmm4
00007d516e5d42ac  vmovaps [rsp+0x50], xmm5
00007d516e5d42b2  vmovaps [rsp+0x60], xmm6
00007d516e5d42b8  vmovaps [rsp+0x70], xmm7
00007d516e5d42be  vmovaps [rsp+0x80], xmm8
00007d516e5d42c7  vmovaps [rsp+0x90], xmm9
00007d516e5d42d0  vmovaps [rsp+0xA0], xmm10
00007d516e5d42d9  vmovaps [rsp+0xB0], xmm11
00007d516e5d42e2  vmovaps [rsp+0xC0], xmm12
00007d516e5d42eb  vmovaps [rsp+0xD0], xmm13
00007d516e5d42f4  vmovaps [rsp+0xE0], xmm15
00007d516e5d42fd  sub rsp, 0x30
00007d516e5d4301  movaps [rsp], xmm14
00007d516e5d4306  movaps [rsp+0x10], xmm10
00007d516e5d430c  movaps [rsp+0x20], xmm15
00007d516e5d4312  lea rdi, [rsp]
00007d516e5d4316  mov esi, 0x00
00007d516e5d431b  mov rax, 0x5EE43AF14530
00007d516e5d4325  call rax
00007d516e5d4327  movaps xmm14, [rsp]
00007d516e5d432c  add rsp, 0x30
00007d516e5d4330  vmovaps xmm0, [rsp]
00007d516e5d4335  vmovaps xmm1, [rsp+0x10]
00007d516e5d433b  vmovaps xmm2, [rsp+0x20]
00007d516e5d4341  vmovaps xmm3, [rsp+0x30]
00007d516e5d4347  vmovaps xmm4, [rsp+0x40]
00007d516e5d434d  vmovaps xmm5, [rsp+0x50]
00007d516e5d4353  vmovaps xmm6, [rsp+0x60]
00007d516e5d4359  vmovaps xmm7, [rsp+0x70]
00007d516e5d435f  vmovaps xmm8, [rsp+0x80]
00007d516e5d4368  vmovaps xmm9, [rsp+0x90]
00007d516e5d4371  vmovaps xmm10, [rsp+0xA0]
00007d516e5d437a  vmovaps xmm11, [rsp+0xB0]
00007d516e5d4383  vmovaps xmm12, [rsp+0xC0]
00007d516e5d438c  vmovaps xmm13, [rsp+0xD0]
00007d516e5d4395  vmovaps xmm15, [rsp+0xE0]
00007d516e5d439e  add rsp, 0xF0
00007d516e5d43a5  pop r11
00007d516e5d43a7  pop r10
00007d516e5d43a9  pop r9
00007d516e5d43ab  pop r8
00007d516e5d43ad  pop rsi
00007d516e5d43ae  pop rdi
00007d516e5d43af  pop rdx
00007d516e5d43b0  pop rcx
00007d516e5d43b1  pop rax
00007d516e5d43b2  add rsp, 0x08
00007d516e5d43b6  jmp 0x00007D516E5D298E
00007d516e5d43bb  call 0x00007D516E3FF430
00007d516e5d43c0  jmp 0x00007D516E5D2A1E
00007d516e5d43c5  call 0x00007D516E3FF430
00007d516e5d43ca  jmp 0x00007D516E5D2A31
00007d516e5d43cf  sub rsp, 0x08
00007d516e5d43d3  push rax
00007d516e5d43d4  push rcx
00007d516e5d43d5  push rdx
00007d516e5d43d6  push rdi
00007d516e5d43d7  push rsi
00007d516e5d43d8  push r8
00007d516e5d43da  push r9
00007d516e5d43dc  push r10
00007d516e5d43de  push r11
00007d516e5d43e0  sub rsp, 0xF0
00007d516e5d43e7  vmovaps [rsp], xmm0
00007d516e5d43ec  vmovaps [rsp+0x10], xmm2
00007d516e5d43f2  vmovaps [rsp+0x20], xmm3
00007d516e5d43f8  vmovaps [rsp+0x30], xmm4
00007d516e5d43fe  vmovaps [rsp+0x40], xmm5
00007d516e5d4404  vmovaps [rsp+0x50], xmm6
00007d516e5d440a  vmovaps [rsp+0x60], xmm7
00007d516e5d4410  vmovaps [rsp+0x70], xmm8
00007d516e5d4416  vmovaps [rsp+0x80], xmm9
00007d516e5d441f  vmovaps [rsp+0x90], xmm10
00007d516e5d4428  vmovaps [rsp+0xA0], xmm11
00007d516e5d4431  vmovaps [rsp+0xB0], xmm12
00007d516e5d443a  vmovaps [rsp+0xC0], xmm13
00007d516e5d4443  vmovaps [rsp+0xD0], xmm14
00007d516e5d444c  vmovaps [rsp+0xE0], xmm15
00007d516e5d4455  sub rsp, 0x30
00007d516e5d4459  movaps [rsp], xmm1
00007d516e5d445d  movaps [rsp+0x10], xmm13
00007d516e5d4463  movaps [rsp+0x20], xmm2
00007d516e5d4468  lea rdi, [rsp]
00007d516e5d446c  mov esi, 0x00
00007d516e5d4471  mov rax, 0x5EE43AF14530
00007d516e5d447b  call rax
00007d516e5d447d  movaps xmm1, [rsp]
00007d516e5d4481  add rsp, 0x30
00007d516e5d4485  vmovaps xmm0, [rsp]
00007d516e5d448a  vmovaps xmm2, [rsp+0x10]
00007d516e5d4490  vmovaps xmm3, [rsp+0x20]
00007d516e5d4496  vmovaps xmm4, [rsp+0x30]
00007d516e5d449c  vmovaps xmm5, [rsp+0x40]
00007d516e5d44a2  vmovaps xmm6, [rsp+0x50]
00007d516e5d44a8  vmovaps xmm7, [rsp+0x60]
00007d516e5d44ae  vmovaps xmm8, [rsp+0x70]
00007d516e5d44b4  vmovaps xmm9, [rsp+0x80]
00007d516e5d44bd  vmovaps xmm10, [rsp+0x90]
00007d516e5d44c6  vmovaps xmm11, [rsp+0xA0]
00007d516e5d44cf  vmovaps xmm12, [rsp+0xB0]
00007d516e5d44d8  vmovaps xmm13, [rsp+0xC0]
00007d516e5d44e1  vmovaps xmm14, [rsp+0xD0]
00007d516e5d44ea  vmovaps xmm15, [rsp+0xE0]
00007d516e5d44f3  add rsp, 0xF0
00007d516e5d44fa  pop r11
00007d516e5d44fc  pop r10
00007d516e5d44fe  pop r9
00007d516e5d4500  pop r8
00007d516e5d4502  pop rsi
00007d516e5d4503  pop rdi
00007d516e5d4504  pop rdx
00007d516e5d4505  pop rcx
00007d516e5d4506  pop rax
00007d516e5d4507  add rsp, 0x08
00007d516e5d450b  jmp 0x00007D516E5D2A5C
00007d516e5d4510  call 0x00007D516E40E760
00007d516e5d4515  jmp 0x00007D516E5D2A69
00007d516e5d451a  sub rsp, 0x08
00007d516e5d451e  push rax
00007d516e5d451f  push rcx
00007d516e5d4520  push rdx
00007d516e5d4521  push rdi
00007d516e5d4522  push rsi
00007d516e5d4523  push r8
00007d516e5d4525  push r9
00007d516e5d4527  push r10
00007d516e5d4529  push r11
00007d516e5d452b  sub rsp, 0xF0
00007d516e5d4532  vmovaps [rsp], xmm0
00007d516e5d4537  vmovaps [rsp+0x10], xmm1
00007d516e5d453d  vmovaps [rsp+0x20], xmm2
00007d516e5d4543  vmovaps [rsp+0x30], xmm3
00007d516e5d4549  vmovaps [rsp+0x40], xmm4
00007d516e5d454f  vmovaps [rsp+0x50], xmm5
00007d516e5d4555  vmovaps [rsp+0x60], xmm6
00007d516e5d455b  vmovaps [rsp+0x70], xmm7
00007d516e5d4561  vmovaps [rsp+0x80], xmm8
00007d516e5d456a  vmovaps [rsp+0x90], xmm9
00007d516e5d4573  vmovaps [rsp+0xA0], xmm10
00007d516e5d457c  vmovaps [rsp+0xB0], xmm11
00007d516e5d4585  vmovaps [rsp+0xC0], xmm12
00007d516e5d458e  vmovaps [rsp+0xD0], xmm14
00007d516e5d4597  vmovaps [rsp+0xE0], xmm15
00007d516e5d45a0  sub rsp, 0x30
00007d516e5d45a4  movaps [rsp], xmm13
00007d516e5d45a9  movaps [rsp+0x10], xmm2
00007d516e5d45ae  movaps [rsp+0x20], xmm1
00007d516e5d45b3  lea rdi, [rsp]
00007d516e5d45b7  mov esi, 0x00
00007d516e5d45bc  mov rax, 0x5EE43AF14530
00007d516e5d45c6  call rax
00007d516e5d45c8  movaps xmm13, [rsp]
00007d516e5d45cd  add rsp, 0x30
00007d516e5d45d1  vmovaps xmm0, [rsp]
00007d516e5d45d6  vmovaps xmm1, [rsp+0x10]
00007d516e5d45dc  vmovaps xmm2, [rsp+0x20]
00007d516e5d45e2  vmovaps xmm3, [rsp+0x30]
00007d516e5d45e8  vmovaps xmm4, [rsp+0x40]
00007d516e5d45ee  vmovaps xmm5, [rsp+0x50]
00007d516e5d45f4  vmovaps xmm6, [rsp+0x60]
00007d516e5d45fa  vmovaps xmm7, [rsp+0x70]
00007d516e5d4600  vmovaps xmm8, [rsp+0x80]
00007d516e5d4609  vmovaps xmm9, [rsp+0x90]
00007d516e5d4612  vmovaps xmm10, [rsp+0xA0]
00007d516e5d461b  vmovaps xmm11, [rsp+0xB0]
00007d516e5d4624  vmovaps xmm12, [rsp+0xC0]
00007d516e5d462d  vmovaps xmm14, [rsp+0xD0]
00007d516e5d4636  vmovaps xmm15, [rsp+0xE0]
00007d516e5d463f  add rsp, 0xF0
00007d516e5d4646  pop r11
00007d516e5d4648  pop r10
00007d516e5d464a  pop r9
00007d516e5d464c  pop r8
00007d516e5d464e  pop rsi
00007d516e5d464f  pop rdi
00007d516e5d4650  pop rdx
00007d516e5d4651  pop rcx
00007d516e5d4652  pop rax
00007d516e5d4653  add rsp, 0x08
00007d516e5d4657  jmp 0x00007D516E5D2AA8
00007d516e5d465c  sub rsp, 0x08
00007d516e5d4660  push rax
00007d516e5d4661  push rcx
00007d516e5d4662  push rdx
00007d516e5d4663  push rdi
00007d516e5d4664  push rsi
00007d516e5d4665  push r8
00007d516e5d4667  push r9
00007d516e5d4669  push r10
00007d516e5d466b  push r11
00007d516e5d466d  sub rsp, 0xF0
00007d516e5d4674  vmovaps [rsp], xmm0
00007d516e5d4679  vmovaps [rsp+0x10], xmm2
00007d516e5d467f  vmovaps [rsp+0x20], xmm3
00007d516e5d4685  vmovaps [rsp+0x30], xmm4
00007d516e5d468b  vmovaps [rsp+0x40], xmm5
00007d516e5d4691  vmovaps [rsp+0x50], xmm6
00007d516e5d4697  vmovaps [rsp+0x60], xmm7
00007d516e5d469d  vmovaps [rsp+0x70], xmm8
00007d516e5d46a3  vmovaps [rsp+0x80], xmm9
00007d516e5d46ac  vmovaps [rsp+0x90], xmm10
00007d516e5d46b5  vmovaps [rsp+0xA0], xmm11
00007d516e5d46be  vmovaps [rsp+0xB0], xmm12
00007d516e5d46c7  vmovaps [rsp+0xC0], xmm13
00007d516e5d46d0  vmovaps [rsp+0xD0], xmm14
00007d516e5d46d9  vmovaps [rsp+0xE0], xmm15
00007d516e5d46e2  sub rsp, 0x30
00007d516e5d46e6  movaps [rsp], xmm1
00007d516e5d46ea  movaps [rsp+0x10], xmm14
00007d516e5d46f0  movaps [rsp+0x20], xmm15
00007d516e5d46f6  lea rdi, [rsp]
00007d516e5d46fa  mov esi, 0x00
00007d516e5d46ff  mov rax, 0x5EE43AF14530
00007d516e5d4709  call rax
00007d516e5d470b  movaps xmm1, [rsp]
00007d516e5d470f  add rsp, 0x30
00007d516e5d4713  vmovaps xmm0, [rsp]
00007d516e5d4718  vmovaps xmm2, [rsp+0x10]
00007d516e5d471e  vmovaps xmm3, [rsp+0x20]
00007d516e5d4724  vmovaps xmm4, [rsp+0x30]
00007d516e5d472a  vmovaps xmm5, [rsp+0x40]
00007d516e5d4730  vmovaps xmm6, [rsp+0x50]
00007d516e5d4736  vmovaps xmm7, [rsp+0x60]
00007d516e5d473c  vmovaps xmm8, [rsp+0x70]
00007d516e5d4742  vmovaps xmm9, [rsp+0x80]
00007d516e5d474b  vmovaps xmm10, [rsp+0x90]
00007d516e5d4754  vmovaps xmm11, [rsp+0xA0]
00007d516e5d475d  vmovaps xmm12, [rsp+0xB0]
00007d516e5d4766  vmovaps xmm13, [rsp+0xC0]
00007d516e5d476f  vmovaps xmm14, [rsp+0xD0]
00007d516e5d4778  vmovaps xmm15, [rsp+0xE0]
00007d516e5d4781  add rsp, 0xF0
00007d516e5d4788  pop r11
00007d516e5d478a  pop r10
00007d516e5d478c  pop r9
00007d516e5d478e  pop r8
00007d516e5d4790  pop rsi
00007d516e5d4791  pop rdi
00007d516e5d4792  pop rdx
00007d516e5d4793  pop rcx
00007d516e5d4794  pop rax
00007d516e5d4795  add rsp, 0x08
00007d516e5d4799  jmp 0x00007D516E5D2ACA
00007d516e5d479e  sub rsp, 0x08
00007d516e5d47a2  push rax
00007d516e5d47a3  push rcx
00007d516e5d47a4  push rdx
00007d516e5d47a5  push rdi
00007d516e5d47a6  push rsi
00007d516e5d47a7  push r8
00007d516e5d47a9  push r9
00007d516e5d47ab  push r10
00007d516e5d47ad  push r11
00007d516e5d47af  sub rsp, 0xF0
00007d516e5d47b6  vmovaps [rsp], xmm0
00007d516e5d47bb  vmovaps [rsp+0x10], xmm1
00007d516e5d47c1  vmovaps [rsp+0x20], xmm2
00007d516e5d47c7  vmovaps [rsp+0x30], xmm3
00007d516e5d47cd  vmovaps [rsp+0x40], xmm4
00007d516e5d47d3  vmovaps [rsp+0x50], xmm5
00007d516e5d47d9  vmovaps [rsp+0x60], xmm6
00007d516e5d47df  vmovaps [rsp+0x70], xmm7
00007d516e5d47e5  vmovaps [rsp+0x80], xmm8
00007d516e5d47ee  vmovaps [rsp+0x90], xmm9
00007d516e5d47f7  vmovaps [rsp+0xA0], xmm10
00007d516e5d4800  vmovaps [rsp+0xB0], xmm11
00007d516e5d4809  vmovaps [rsp+0xC0], xmm12
00007d516e5d4812  vmovaps [rsp+0xD0], xmm13
00007d516e5d481b  vmovaps [rsp+0xE0], xmm15
00007d516e5d4824  sub rsp, 0x30
00007d516e5d4828  movaps [rsp], xmm14
00007d516e5d482d  movaps [rsp+0x10], xmm2
00007d516e5d4832  movaps [rsp+0x20], xmm15
00007d516e5d4838  lea rdi, [rsp]
00007d516e5d483c  mov esi, 0x00
00007d516e5d4841  mov rax, 0x5EE43AF14530
00007d516e5d484b  call rax
00007d516e5d484d  movaps xmm14, [rsp]
00007d516e5d4852  add rsp, 0x30
00007d516e5d4856  vmovaps xmm0, [rsp]
00007d516e5d485b  vmovaps xmm1, [rsp+0x10]
00007d516e5d4861  vmovaps xmm2, [rsp+0x20]
00007d516e5d4867  vmovaps xmm3, [rsp+0x30]
00007d516e5d486d  vmovaps xmm4, [rsp+0x40]
00007d516e5d4873  vmovaps xmm5, [rsp+0x50]
00007d516e5d4879  vmovaps xmm6, [rsp+0x60]
00007d516e5d487f  vmovaps xmm7, [rsp+0x70]
00007d516e5d4885  vmovaps xmm8, [rsp+0x80]
00007d516e5d488e  vmovaps xmm9, [rsp+0x90]
00007d516e5d4897  vmovaps xmm10, [rsp+0xA0]
00007d516e5d48a0  vmovaps xmm11, [rsp+0xB0]
00007d516e5d48a9  vmovaps xmm12, [rsp+0xC0]
00007d516e5d48b2  vmovaps xmm13, [rsp+0xD0]
00007d516e5d48bb  vmovaps xmm15, [rsp+0xE0]
00007d516e5d48c4  add rsp, 0xF0
00007d516e5d48cb  pop r11
00007d516e5d48cd  pop r10
00007d516e5d48cf  pop r9
00007d516e5d48d1  pop r8
00007d516e5d48d3  pop rsi
00007d516e5d48d4  pop rdi
00007d516e5d48d5  pop rdx
00007d516e5d48d6  pop rcx
00007d516e5d48d7  pop rax
00007d516e5d48d8  add rsp, 0x08
00007d516e5d48dc  jmp 0x00007D516E5D2B05
00007d516e5d48e1  sub rsp, 0x08
00007d516e5d48e5  push rax
00007d516e5d48e6  push rcx
00007d516e5d48e7  push rdx
00007d516e5d48e8  push rdi
00007d516e5d48e9  push rsi
00007d516e5d48ea  push r8
00007d516e5d48ec  push r9
00007d516e5d48ee  push r10
00007d516e5d48f0  push r11
00007d516e5d48f2  sub rsp, 0xF0
00007d516e5d48f9  vmovaps [rsp], xmm0
00007d516e5d48fe  vmovaps [rsp+0x10], xmm1
00007d516e5d4904  vmovaps [rsp+0x20], xmm2
00007d516e5d490a  vmovaps [rsp+0x30], xmm3
00007d516e5d4910  vmovaps [rsp+0x40], xmm4
00007d516e5d4916  vmovaps [rsp+0x50], xmm5
00007d516e5d491c  vmovaps [rsp+0x60], xmm6
00007d516e5d4922  vmovaps [rsp+0x70], xmm7
00007d516e5d4928  vmovaps [rsp+0x80], xmm8
00007d516e5d4931  vmovaps [rsp+0x90], xmm9
00007d516e5d493a  vmovaps [rsp+0xA0], xmm10
00007d516e5d4943  vmovaps [rsp+0xB0], xmm11
00007d516e5d494c  vmovaps [rsp+0xC0], xmm12
00007d516e5d4955  vmovaps [rsp+0xD0], xmm13
00007d516e5d495e  vmovaps [rsp+0xE0], xmm14
00007d516e5d4967  sub rsp, 0x30
00007d516e5d496b  movaps [rsp], xmm15
00007d516e5d4970  movaps [rsp+0x10], xmm2
00007d516e5d4975  movaps [rsp+0x20], xmm1
00007d516e5d497a  lea rdi, [rsp]
00007d516e5d497e  mov esi, 0x00
00007d516e5d4983  mov rax, 0x5EE43AF14530
00007d516e5d498d  call rax
00007d516e5d498f  movaps xmm15, [rsp]
00007d516e5d4994  add rsp, 0x30
00007d516e5d4998  vmovaps xmm0, [rsp]
00007d516e5d499d  vmovaps xmm1, [rsp+0x10]
00007d516e5d49a3  vmovaps xmm2, [rsp+0x20]
00007d516e5d49a9  vmovaps xmm3, [rsp+0x30]
00007d516e5d49af  vmovaps xmm4, [rsp+0x40]
00007d516e5d49b5  vmovaps xmm5, [rsp+0x50]
00007d516e5d49bb  vmovaps xmm6, [rsp+0x60]
00007d516e5d49c1  vmovaps xmm7, [rsp+0x70]
00007d516e5d49c7  vmovaps xmm8, [rsp+0x80]
00007d516e5d49d0  vmovaps xmm9, [rsp+0x90]
00007d516e5d49d9  vmovaps xmm10, [rsp+0xA0]
00007d516e5d49e2  vmovaps xmm11, [rsp+0xB0]
00007d516e5d49eb  vmovaps xmm12, [rsp+0xC0]
00007d516e5d49f4  vmovaps xmm13, [rsp+0xD0]
00007d516e5d49fd  vmovaps xmm14, [rsp+0xE0]
00007d516e5d4a06  add rsp, 0xF0
00007d516e5d4a0d  pop r11
00007d516e5d4a0f  pop r10
00007d516e5d4a11  pop r9
00007d516e5d4a13  pop r8
00007d516e5d4a15  pop rsi
00007d516e5d4a16  pop rdi
00007d516e5d4a17  pop rdx
00007d516e5d4a18  pop rcx
00007d516e5d4a19  pop rax
00007d516e5d4a1a  add rsp, 0x08
00007d516e5d4a1e  jmp 0x00007D516E5D2B41
00007d516e5d4a23  call 0x00007D516E3FF430
00007d516e5d4a28  jmp 0x00007D516E5D2B4E
00007d516e5d4a2d  sub rsp, 0x08
00007d516e5d4a31  push rax
00007d516e5d4a32  push rcx
00007d516e5d4a33  push rdx
00007d516e5d4a34  push rdi
00007d516e5d4a35  push rsi
00007d516e5d4a36  push r8
00007d516e5d4a38  push r9
00007d516e5d4a3a  push r10
00007d516e5d4a3c  push r11
00007d516e5d4a3e  sub rsp, 0xF0
00007d516e5d4a45  vmovaps [rsp], xmm0
00007d516e5d4a4a  vmovaps [rsp+0x10], xmm1
00007d516e5d4a50  vmovaps [rsp+0x20], xmm3
00007d516e5d4a56  vmovaps [rsp+0x30], xmm4
00007d516e5d4a5c  vmovaps [rsp+0x40], xmm5
00007d516e5d4a62  vmovaps [rsp+0x50], xmm6
00007d516e5d4a68  vmovaps [rsp+0x60], xmm7
00007d516e5d4a6e  vmovaps [rsp+0x70], xmm8
00007d516e5d4a74  vmovaps [rsp+0x80], xmm9
00007d516e5d4a7d  vmovaps [rsp+0x90], xmm10
00007d516e5d4a86  vmovaps [rsp+0xA0], xmm11
00007d516e5d4a8f  vmovaps [rsp+0xB0], xmm12
00007d516e5d4a98  vmovaps [rsp+0xC0], xmm13
00007d516e5d4aa1  vmovaps [rsp+0xD0], xmm14
00007d516e5d4aaa  vmovaps [rsp+0xE0], xmm15
00007d516e5d4ab3  sub rsp, 0x30
00007d516e5d4ab7  movaps [rsp], xmm2
00007d516e5d4abb  movaps [rsp+0x10], xmm1
00007d516e5d4ac0  movaps [rsp+0x20], xmm14
00007d516e5d4ac6  lea rdi, [rsp]
00007d516e5d4aca  mov esi, 0x00
00007d516e5d4acf  mov rax, 0x5EE43AF14530
00007d516e5d4ad9  call rax
00007d516e5d4adb  movaps xmm2, [rsp]
00007d516e5d4adf  add rsp, 0x30
00007d516e5d4ae3  vmovaps xmm0, [rsp]
00007d516e5d4ae8  vmovaps xmm1, [rsp+0x10]
00007d516e5d4aee  vmovaps xmm3, [rsp+0x20]
00007d516e5d4af4  vmovaps xmm4, [rsp+0x30]
00007d516e5d4afa  vmovaps xmm5, [rsp+0x40]
00007d516e5d4b00  vmovaps xmm6, [rsp+0x50]
00007d516e5d4b06  vmovaps xmm7, [rsp+0x60]
00007d516e5d4b0c  vmovaps xmm8, [rsp+0x70]
00007d516e5d4b12  vmovaps xmm9, [rsp+0x80]
00007d516e5d4b1b  vmovaps xmm10, [rsp+0x90]
00007d516e5d4b24  vmovaps xmm11, [rsp+0xA0]
00007d516e5d4b2d  vmovaps xmm12, [rsp+0xB0]
00007d516e5d4b36  vmovaps xmm13, [rsp+0xC0]
00007d516e5d4b3f  vmovaps xmm14, [rsp+0xD0]
00007d516e5d4b48  vmovaps xmm15, [rsp+0xE0]
00007d516e5d4b51  add rsp, 0xF0
00007d516e5d4b58  pop r11
00007d516e5d4b5a  pop r10
00007d516e5d4b5c  pop r9
00007d516e5d4b5e  pop r8
00007d516e5d4b60  pop rsi
00007d516e5d4b61  pop rdi
00007d516e5d4b62  pop rdx
00007d516e5d4b63  pop rcx
00007d516e5d4b64  pop rax
00007d516e5d4b65  add rsp, 0x08
00007d516e5d4b69  jmp 0x00007D516E5D2B8B
00007d516e5d4b6e  sub rsp, 0x08
00007d516e5d4b72  push rax
00007d516e5d4b73  push rcx
00007d516e5d4b74  push rdx
00007d516e5d4b75  push rdi
00007d516e5d4b76  push rsi
00007d516e5d4b77  push r8
00007d516e5d4b79  push r9
00007d516e5d4b7b  push r10
00007d516e5d4b7d  push r11
00007d516e5d4b7f  sub rsp, 0xF0
00007d516e5d4b86  vmovaps [rsp], xmm0
00007d516e5d4b8b  vmovaps [rsp+0x10], xmm1
00007d516e5d4b91  vmovaps [rsp+0x20], xmm2
00007d516e5d4b97  vmovaps [rsp+0x30], xmm3
00007d516e5d4b9d  vmovaps [rsp+0x40], xmm4
00007d516e5d4ba3  vmovaps [rsp+0x50], xmm5
00007d516e5d4ba9  vmovaps [rsp+0x60], xmm6
00007d516e5d4baf  vmovaps [rsp+0x70], xmm7
00007d516e5d4bb5  vmovaps [rsp+0x80], xmm8
00007d516e5d4bbe  vmovaps [rsp+0x90], xmm9
00007d516e5d4bc7  vmovaps [rsp+0xA0], xmm10
00007d516e5d4bd0  vmovaps [rsp+0xB0], xmm11
00007d516e5d4bd9  vmovaps [rsp+0xC0], xmm12
00007d516e5d4be2  vmovaps [rsp+0xD0], xmm13
00007d516e5d4beb  vmovaps [rsp+0xE0], xmm14
00007d516e5d4bf4  sub rsp, 0x30
00007d516e5d4bf8  movaps [rsp], xmm15
00007d516e5d4bfd  movaps [rsp+0x10], xmm14
00007d516e5d4c03  movaps [rsp+0x20], xmm1
00007d516e5d4c08  lea rdi, [rsp]
00007d516e5d4c0c  mov esi, 0x00
00007d516e5d4c11  mov rax, 0x5EE43AF14530
00007d516e5d4c1b  call rax
00007d516e5d4c1d  movaps xmm15, [rsp]
00007d516e5d4c22  add rsp, 0x30
00007d516e5d4c26  vmovaps xmm0, [rsp]
00007d516e5d4c2b  vmovaps xmm1, [rsp+0x10]
00007d516e5d4c31  vmovaps xmm2, [rsp+0x20]
00007d516e5d4c37  vmovaps xmm3, [rsp+0x30]
00007d516e5d4c3d  vmovaps xmm4, [rsp+0x40]
00007d516e5d4c43  vmovaps xmm5, [rsp+0x50]
00007d516e5d4c49  vmovaps xmm6, [rsp+0x60]
00007d516e5d4c4f  vmovaps xmm7, [rsp+0x70]
00007d516e5d4c55  vmovaps xmm8, [rsp+0x80]
00007d516e5d4c5e  vmovaps xmm9, [rsp+0x90]
00007d516e5d4c67  vmovaps xmm10, [rsp+0xA0]
00007d516e5d4c70  vmovaps xmm11, [rsp+0xB0]
00007d516e5d4c79  vmovaps xmm12, [rsp+0xC0]
00007d516e5d4c82  vmovaps xmm13, [rsp+0xD0]
00007d516e5d4c8b  vmovaps xmm14, [rsp+0xE0]
00007d516e5d4c94  add rsp, 0xF0
00007d516e5d4c9b  pop r11
00007d516e5d4c9d  pop r10
00007d516e5d4c9f  pop r9
00007d516e5d4ca1  pop r8
00007d516e5d4ca3  pop rsi
00007d516e5d4ca4  pop rdi
00007d516e5d4ca5  pop rdx
00007d516e5d4ca6  pop rcx
00007d516e5d4ca7  pop rax
00007d516e5d4ca8  add rsp, 0x08
00007d516e5d4cac  jmp 0x00007D516E5D2C05
00007d516e5d4cb1  call 0x00007D516E3FF430
00007d516e5d4cb6  jmp 0x00007D516E5D2C12
00007d516e5d4cbb  sub rsp, 0x08
00007d516e5d4cbf  push rax
00007d516e5d4cc0  push rcx
00007d516e5d4cc1  push rdx
00007d516e5d4cc2  push rdi
00007d516e5d4cc3  push rsi
00007d516e5d4cc4  push r8
00007d516e5d4cc6  push r9
00007d516e5d4cc8  push r10
00007d516e5d4cca  push r11
00007d516e5d4ccc  sub rsp, 0xF0
00007d516e5d4cd3  vmovaps [rsp], xmm0
00007d516e5d4cd8  vmovaps [rsp+0x10], xmm1
00007d516e5d4cde  vmovaps [rsp+0x20], xmm2
00007d516e5d4ce4  vmovaps [rsp+0x30], xmm3
00007d516e5d4cea  vmovaps [rsp+0x40], xmm4
00007d516e5d4cf0  vmovaps [rsp+0x50], xmm5
00007d516e5d4cf6  vmovaps [rsp+0x60], xmm6
00007d516e5d4cfc  vmovaps [rsp+0x70], xmm7
00007d516e5d4d02  vmovaps [rsp+0x80], xmm8
00007d516e5d4d0b  vmovaps [rsp+0x90], xmm9
00007d516e5d4d14  vmovaps [rsp+0xA0], xmm10
00007d516e5d4d1d  vmovaps [rsp+0xB0], xmm11
00007d516e5d4d26  vmovaps [rsp+0xC0], xmm12
00007d516e5d4d2f  vmovaps [rsp+0xD0], xmm14
00007d516e5d4d38  vmovaps [rsp+0xE0], xmm15
00007d516e5d4d41  sub rsp, 0x30
00007d516e5d4d45  movaps [rsp], xmm13
00007d516e5d4d4a  movaps [rsp+0x10], xmm1
00007d516e5d4d4f  movaps [rsp+0x20], xmm15
00007d516e5d4d55  lea rdi, [rsp]
00007d516e5d4d59  mov esi, 0x00
00007d516e5d4d5e  mov rax, 0x5EE43AF14530
00007d516e5d4d68  call rax
00007d516e5d4d6a  movaps xmm13, [rsp]
00007d516e5d4d6f  add rsp, 0x30
00007d516e5d4d73  vmovaps xmm0, [rsp]
00007d516e5d4d78  vmovaps xmm1, [rsp+0x10]
00007d516e5d4d7e  vmovaps xmm2, [rsp+0x20]
00007d516e5d4d84  vmovaps xmm3, [rsp+0x30]
00007d516e5d4d8a  vmovaps xmm4, [rsp+0x40]
00007d516e5d4d90  vmovaps xmm5, [rsp+0x50]
00007d516e5d4d96  vmovaps xmm6, [rsp+0x60]
00007d516e5d4d9c  vmovaps xmm7, [rsp+0x70]
00007d516e5d4da2  vmovaps xmm8, [rsp+0x80]
00007d516e5d4dab  vmovaps xmm9, [rsp+0x90]
00007d516e5d4db4  vmovaps xmm10, [rsp+0xA0]
00007d516e5d4dbd  vmovaps xmm11, [rsp+0xB0]
00007d516e5d4dc6  vmovaps xmm12, [rsp+0xC0]
00007d516e5d4dcf  vmovaps xmm14, [rsp+0xD0]
00007d516e5d4dd8  vmovaps xmm15, [rsp+0xE0]
00007d516e5d4de1  add rsp, 0xF0
00007d516e5d4de8  pop r11
00007d516e5d4dea  pop r10
00007d516e5d4dec  pop r9
00007d516e5d4dee  pop r8
00007d516e5d4df0  pop rsi
00007d516e5d4df1  pop rdi
00007d516e5d4df2  pop rdx
00007d516e5d4df3  pop rcx
00007d516e5d4df4  pop rax
00007d516e5d4df5  add rsp, 0x08
00007d516e5d4df9  jmp 0x00007D516E5D2CD6
00007d516e5d4dfe  sub rsp, 0x08
00007d516e5d4e02  push rax
00007d516e5d4e03  push rcx
00007d516e5d4e04  push rdx
00007d516e5d4e05  push rdi
00007d516e5d4e06  push rsi
00007d516e5d4e07  push r8
00007d516e5d4e09  push r9
00007d516e5d4e0b  push r10
00007d516e5d4e0d  push r11
00007d516e5d4e0f  sub rsp, 0xF0
00007d516e5d4e16  vmovaps [rsp], xmm0
00007d516e5d4e1b  vmovaps [rsp+0x10], xmm1
00007d516e5d4e21  vmovaps [rsp+0x20], xmm2
00007d516e5d4e27  vmovaps [rsp+0x30], xmm3
00007d516e5d4e2d  vmovaps [rsp+0x40], xmm4
00007d516e5d4e33  vmovaps [rsp+0x50], xmm5
00007d516e5d4e39  vmovaps [rsp+0x60], xmm6
00007d516e5d4e3f  vmovaps [rsp+0x70], xmm7
00007d516e5d4e45  vmovaps [rsp+0x80], xmm8
00007d516e5d4e4e  vmovaps [rsp+0x90], xmm9
00007d516e5d4e57  vmovaps [rsp+0xA0], xmm10
00007d516e5d4e60  vmovaps [rsp+0xB0], xmm11
00007d516e5d4e69  vmovaps [rsp+0xC0], xmm12
00007d516e5d4e72  vmovaps [rsp+0xD0], xmm13
00007d516e5d4e7b  vmovaps [rsp+0xE0], xmm14
00007d516e5d4e84  sub rsp, 0x30
00007d516e5d4e88  movaps [rsp], xmm15
00007d516e5d4e8d  movaps [rsp+0x10], xmm14
00007d516e5d4e93  movaps [rsp+0x20], xmm1
00007d516e5d4e98  lea rdi, [rsp]
00007d516e5d4e9c  mov esi, 0x00
00007d516e5d4ea1  mov rax, 0x5EE43AF14530
00007d516e5d4eab  call rax
00007d516e5d4ead  movaps xmm15, [rsp]
00007d516e5d4eb2  add rsp, 0x30
00007d516e5d4eb6  vmovaps xmm0, [rsp]
00007d516e5d4ebb  vmovaps xmm1, [rsp+0x10]
00007d516e5d4ec1  vmovaps xmm2, [rsp+0x20]
00007d516e5d4ec7  vmovaps xmm3, [rsp+0x30]
00007d516e5d4ecd  vmovaps xmm4, [rsp+0x40]
00007d516e5d4ed3  vmovaps xmm5, [rsp+0x50]
00007d516e5d4ed9  vmovaps xmm6, [rsp+0x60]
00007d516e5d4edf  vmovaps xmm7, [rsp+0x70]
00007d516e5d4ee5  vmovaps xmm8, [rsp+0x80]
00007d516e5d4eee  vmovaps xmm9, [rsp+0x90]
00007d516e5d4ef7  vmovaps xmm10, [rsp+0xA0]
00007d516e5d4f00  vmovaps xmm11, [rsp+0xB0]
00007d516e5d4f09  vmovaps xmm12, [rsp+0xC0]
00007d516e5d4f12  vmovaps xmm13, [rsp+0xD0]
00007d516e5d4f1b  vmovaps xmm14, [rsp+0xE0]
00007d516e5d4f24  add rsp, 0xF0
00007d516e5d4f2b  pop r11
00007d516e5d4f2d  pop r10
00007d516e5d4f2f  pop r9
00007d516e5d4f31  pop r8
00007d516e5d4f33  pop rsi
00007d516e5d4f34  pop rdi
00007d516e5d4f35  pop rdx
00007d516e5d4f36  pop rcx
00007d516e5d4f37  pop rax
00007d516e5d4f38  add rsp, 0x08
00007d516e5d4f3c  jmp 0x00007D516E5D2D12
00007d516e5d4f41  call 0x00007D516E3FF430
00007d516e5d4f46  jmp 0x00007D516E5D2D1F
00007d516e5d4f4b  sub rsp, 0x08
00007d516e5d4f4f  push rax
00007d516e5d4f50  push rcx
00007d516e5d4f51  push rdx
00007d516e5d4f52  push rdi
00007d516e5d4f53  push rsi
00007d516e5d4f54  push r8
00007d516e5d4f56  push r9
00007d516e5d4f58  push r10
00007d516e5d4f5a  push r11
00007d516e5d4f5c  sub rsp, 0xF0
00007d516e5d4f63  vmovaps [rsp], xmm0
00007d516e5d4f68  vmovaps [rsp+0x10], xmm1
00007d516e5d4f6e  vmovaps [rsp+0x20], xmm2
00007d516e5d4f74  vmovaps [rsp+0x30], xmm3
00007d516e5d4f7a  vmovaps [rsp+0x40], xmm4
00007d516e5d4f80  vmovaps [rsp+0x50], xmm5
00007d516e5d4f86  vmovaps [rsp+0x60], xmm6
00007d516e5d4f8c  vmovaps [rsp+0x70], xmm7
00007d516e5d4f92  vmovaps [rsp+0x80], xmm8
00007d516e5d4f9b  vmovaps [rsp+0x90], xmm9
00007d516e5d4fa4  vmovaps [rsp+0xA0], xmm10
00007d516e5d4fad  vmovaps [rsp+0xB0], xmm11
00007d516e5d4fb6  vmovaps [rsp+0xC0], xmm12
00007d516e5d4fbf  vmovaps [rsp+0xD0], xmm13
00007d516e5d4fc8  vmovaps [rsp+0xE0], xmm15
00007d516e5d4fd1  sub rsp, 0x30
00007d516e5d4fd5  movaps [rsp], xmm14
00007d516e5d4fda  movaps [rsp+0x10], xmm13
00007d516e5d4fe0  movaps [rsp+0x20], xmm2
00007d516e5d4fe5  lea rdi, [rsp]
00007d516e5d4fe9  mov esi, 0x00
00007d516e5d4fee  mov rax, 0x5EE43AF14530
00007d516e5d4ff8  call rax
00007d516e5d4ffa  movaps xmm14, [rsp]
00007d516e5d4fff  add rsp, 0x30
00007d516e5d5003  vmovaps xmm0, [rsp]
00007d516e5d5008  vmovaps xmm1, [rsp+0x10]
00007d516e5d500e  vmovaps xmm2, [rsp+0x20]
00007d516e5d5014  vmovaps xmm3, [rsp+0x30]
00007d516e5d501a  vmovaps xmm4, [rsp+0x40]
00007d516e5d5020  vmovaps xmm5, [rsp+0x50]
00007d516e5d5026  vmovaps xmm6, [rsp+0x60]
00007d516e5d502c  vmovaps xmm7, [rsp+0x70]
00007d516e5d5032  vmovaps xmm8, [rsp+0x80]
00007d516e5d503b  vmovaps xmm9, [rsp+0x90]
00007d516e5d5044  vmovaps xmm10, [rsp+0xA0]
00007d516e5d504d  vmovaps xmm11, [rsp+0xB0]
00007d516e5d5056  vmovaps xmm12, [rsp+0xC0]
00007d516e5d505f  vmovaps xmm13, [rsp+0xD0]
00007d516e5d5068  vmovaps xmm15, [rsp+0xE0]
00007d516e5d5071  add rsp, 0xF0
00007d516e5d5078  pop r11
00007d516e5d507a  pop r10
00007d516e5d507c  pop r9
00007d516e5d507e  pop r8
00007d516e5d5080  pop rsi
00007d516e5d5081  pop rdi
00007d516e5d5082  pop rdx
00007d516e5d5083  pop rcx
00007d516e5d5084  pop rax
00007d516e5d5085  add rsp, 0x08
00007d516e5d5089  jmp 0x00007D516E5D2D4B
00007d516e5d508e  sub rsp, 0x08
00007d516e5d5092  push rax
00007d516e5d5093  push rcx
00007d516e5d5094  push rdx
00007d516e5d5095  push rdi
00007d516e5d5096  push rsi
00007d516e5d5097  push r8
00007d516e5d5099  push r9
00007d516e5d509b  push r10
00007d516e5d509d  push r11
00007d516e5d509f  sub rsp, 0xF0
00007d516e5d50a6  vmovaps [rsp], xmm0
00007d516e5d50ab  vmovaps [rsp+0x10], xmm2
00007d516e5d50b1  vmovaps [rsp+0x20], xmm3
00007d516e5d50b7  vmovaps [rsp+0x30], xmm4
00007d516e5d50bd  vmovaps [rsp+0x40], xmm5
00007d516e5d50c3  vmovaps [rsp+0x50], xmm6
00007d516e5d50c9  vmovaps [rsp+0x60], xmm7
00007d516e5d50cf  vmovaps [rsp+0x70], xmm8
00007d516e5d50d5  vmovaps [rsp+0x80], xmm9
00007d516e5d50de  vmovaps [rsp+0x90], xmm10
00007d516e5d50e7  vmovaps [rsp+0xA0], xmm11
00007d516e5d50f0  vmovaps [rsp+0xB0], xmm12
00007d516e5d50f9  vmovaps [rsp+0xC0], xmm13
00007d516e5d5102  vmovaps [rsp+0xD0], xmm14
00007d516e5d510b  vmovaps [rsp+0xE0], xmm15
00007d516e5d5114  sub rsp, 0x30
00007d516e5d5118  movaps [rsp], xmm1
00007d516e5d511c  movaps [rsp+0x10], xmm13
00007d516e5d5122  movaps [rsp+0x20], xmm2
00007d516e5d5127  lea rdi, [rsp]
00007d516e5d512b  mov esi, 0x00
00007d516e5d5130  mov rax, 0x5EE43AF14530
00007d516e5d513a  call rax
00007d516e5d513c  movaps xmm1, [rsp]
00007d516e5d5140  add rsp, 0x30
00007d516e5d5144  vmovaps xmm0, [rsp]
00007d516e5d5149  vmovaps xmm2, [rsp+0x10]
00007d516e5d514f  vmovaps xmm3, [rsp+0x20]
00007d516e5d5155  vmovaps xmm4, [rsp+0x30]
00007d516e5d515b  vmovaps xmm5, [rsp+0x40]
00007d516e5d5161  vmovaps xmm6, [rsp+0x50]
00007d516e5d5167  vmovaps xmm7, [rsp+0x60]
00007d516e5d516d  vmovaps xmm8, [rsp+0x70]
00007d516e5d5173  vmovaps xmm9, [rsp+0x80]
00007d516e5d517c  vmovaps xmm10, [rsp+0x90]
00007d516e5d5185  vmovaps xmm11, [rsp+0xA0]
00007d516e5d518e  vmovaps xmm12, [rsp+0xB0]
00007d516e5d5197  vmovaps xmm13, [rsp+0xC0]
00007d516e5d51a0  vmovaps xmm14, [rsp+0xD0]
00007d516e5d51a9  vmovaps xmm15, [rsp+0xE0]
00007d516e5d51b2  add rsp, 0xF0
00007d516e5d51b9  pop r11
00007d516e5d51bb  pop r10
00007d516e5d51bd  pop r9
00007d516e5d51bf  pop r8
00007d516e5d51c1  pop rsi
00007d516e5d51c2  pop rdi
00007d516e5d51c3  pop rdx
00007d516e5d51c4  pop rcx
00007d516e5d51c5  pop rax
00007d516e5d51c6  add rsp, 0x08
00007d516e5d51ca  jmp 0x00007D516E5D2D79
00007d516e5d51cf  sub rsp, 0x08
00007d516e5d51d3  push rax
00007d516e5d51d4  push rcx
00007d516e5d51d5  push rdx
00007d516e5d51d6  push rdi
00007d516e5d51d7  push rsi
00007d516e5d51d8  push r8
00007d516e5d51da  push r9
00007d516e5d51dc  push r10
00007d516e5d51de  push r11
00007d516e5d51e0  sub rsp, 0xF0
00007d516e5d51e7  vmovaps [rsp], xmm0
00007d516e5d51ec  vmovaps [rsp+0x10], xmm1
00007d516e5d51f2  vmovaps [rsp+0x20], xmm3
00007d516e5d51f8  vmovaps [rsp+0x30], xmm4
00007d516e5d51fe  vmovaps [rsp+0x40], xmm5
00007d516e5d5204  vmovaps [rsp+0x50], xmm6
00007d516e5d520a  vmovaps [rsp+0x60], xmm7
00007d516e5d5210  vmovaps [rsp+0x70], xmm8
00007d516e5d5216  vmovaps [rsp+0x80], xmm9
00007d516e5d521f  vmovaps [rsp+0x90], xmm10
00007d516e5d5228  vmovaps [rsp+0xA0], xmm11
00007d516e5d5231  vmovaps [rsp+0xB0], xmm12
00007d516e5d523a  vmovaps [rsp+0xC0], xmm13
00007d516e5d5243  vmovaps [rsp+0xD0], xmm14
00007d516e5d524c  vmovaps [rsp+0xE0], xmm15
00007d516e5d5255  sub rsp, 0x30
00007d516e5d5259  movaps [rsp], xmm2
00007d516e5d525d  movaps [rsp+0x10], xmm1
00007d516e5d5262  movaps [rsp+0x20], xmm13
00007d516e5d5268  lea rdi, [rsp]
00007d516e5d526c  mov esi, 0x00
00007d516e5d5271  mov rax, 0x5EE43AF14530
00007d516e5d527b  call rax
00007d516e5d527d  movaps xmm2, [rsp]
00007d516e5d5281  add rsp, 0x30
00007d516e5d5285  vmovaps xmm0, [rsp]
00007d516e5d528a  vmovaps xmm1, [rsp+0x10]
00007d516e5d5290  vmovaps xmm3, [rsp+0x20]
00007d516e5d5296  vmovaps xmm4, [rsp+0x30]
00007d516e5d529c  vmovaps xmm5, [rsp+0x40]
00007d516e5d52a2  vmovaps xmm6, [rsp+0x50]
00007d516e5d52a8  vmovaps xmm7, [rsp+0x60]
00007d516e5d52ae  vmovaps xmm8, [rsp+0x70]
00007d516e5d52b4  vmovaps xmm9, [rsp+0x80]
00007d516e5d52bd  vmovaps xmm10, [rsp+0x90]
00007d516e5d52c6  vmovaps xmm11, [rsp+0xA0]
00007d516e5d52cf  vmovaps xmm12, [rsp+0xB0]
00007d516e5d52d8  vmovaps xmm13, [rsp+0xC0]
00007d516e5d52e1  vmovaps xmm14, [rsp+0xD0]
00007d516e5d52ea  vmovaps xmm15, [rsp+0xE0]
00007d516e5d52f3  add rsp, 0xF0
00007d516e5d52fa  pop r11
00007d516e5d52fc  pop r10
00007d516e5d52fe  pop r9
00007d516e5d5300  pop r8
00007d516e5d5302  pop rsi
00007d516e5d5303  pop rdi
00007d516e5d5304  pop rdx
00007d516e5d5305  pop rcx
00007d516e5d5306  pop rax
00007d516e5d5307  add rsp, 0x08
00007d516e5d530b  jmp 0x00007D516E5D2DD2
00007d516e5d5310  call 0x00007D516E3FF430
00007d516e5d5315  jmp 0x00007D516E5D2DDF
00007d516e5d531a  sub rsp, 0x08
00007d516e5d531e  push rax
00007d516e5d531f  push rcx
00007d516e5d5320  push rdx
00007d516e5d5321  push rdi
00007d516e5d5322  push rsi
00007d516e5d5323  push r8
00007d516e5d5325  push r9
00007d516e5d5327  push r10
00007d516e5d5329  push r11
00007d516e5d532b  sub rsp, 0xF0
00007d516e5d5332  vmovaps [rsp], xmm0
00007d516e5d5337  vmovaps [rsp+0x10], xmm1
00007d516e5d533d  vmovaps [rsp+0x20], xmm2
00007d516e5d5343  vmovaps [rsp+0x30], xmm3
00007d516e5d5349  vmovaps [rsp+0x40], xmm4
00007d516e5d534f  vmovaps [rsp+0x50], xmm5
00007d516e5d5355  vmovaps [rsp+0x60], xmm6
00007d516e5d535b  vmovaps [rsp+0x70], xmm7
00007d516e5d5361  vmovaps [rsp+0x80], xmm8
00007d516e5d536a  vmovaps [rsp+0x90], xmm9
00007d516e5d5373  vmovaps [rsp+0xA0], xmm10
00007d516e5d537c  vmovaps [rsp+0xB0], xmm11
00007d516e5d5385  vmovaps [rsp+0xC0], xmm12
00007d516e5d538e  vmovaps [rsp+0xD0], xmm13
00007d516e5d5397  vmovaps [rsp+0xE0], xmm14
00007d516e5d53a0  sub rsp, 0x30
00007d516e5d53a4  movaps [rsp], xmm15
00007d516e5d53a9  movaps [rsp+0x10], xmm13
00007d516e5d53af  movaps [rsp+0x20], xmm1
00007d516e5d53b4  lea rdi, [rsp]
00007d516e5d53b8  mov esi, 0x00
00007d516e5d53bd  mov rax, 0x5EE43AF14530
00007d516e5d53c7  call rax
00007d516e5d53c9  movaps xmm15, [rsp]
00007d516e5d53ce  add rsp, 0x30
00007d516e5d53d2  vmovaps xmm0, [rsp]
00007d516e5d53d7  vmovaps xmm1, [rsp+0x10]
00007d516e5d53dd  vmovaps xmm2, [rsp+0x20]
00007d516e5d53e3  vmovaps xmm3, [rsp+0x30]
00007d516e5d53e9  vmovaps xmm4, [rsp+0x40]
00007d516e5d53ef  vmovaps xmm5, [rsp+0x50]
00007d516e5d53f5  vmovaps xmm6, [rsp+0x60]
00007d516e5d53fb  vmovaps xmm7, [rsp+0x70]
00007d516e5d5401  vmovaps xmm8, [rsp+0x80]
00007d516e5d540a  vmovaps xmm9, [rsp+0x90]
00007d516e5d5413  vmovaps xmm10, [rsp+0xA0]
00007d516e5d541c  vmovaps xmm11, [rsp+0xB0]
00007d516e5d5425  vmovaps xmm12, [rsp+0xC0]
00007d516e5d542e  vmovaps xmm13, [rsp+0xD0]
00007d516e5d5437  vmovaps xmm14, [rsp+0xE0]
00007d516e5d5440  add rsp, 0xF0
00007d516e5d5447  pop r11
00007d516e5d5449  pop r10
00007d516e5d544b  pop r9
00007d516e5d544d  pop r8
00007d516e5d544f  pop rsi
00007d516e5d5450  pop rdi
00007d516e5d5451  pop rdx
00007d516e5d5452  pop rcx
00007d516e5d5453  pop rax
00007d516e5d5454  add rsp, 0x08
00007d516e5d5458  jmp 0x00007D516E5D2E1E
00007d516e5d545d  sub rsp, 0x08
00007d516e5d5461  push rax
00007d516e5d5462  push rcx
00007d516e5d5463  push rdx
00007d516e5d5464  push rdi
00007d516e5d5465  push rsi
00007d516e5d5466  push r8
00007d516e5d5468  push r9
00007d516e5d546a  push r10
00007d516e5d546c  push r11
00007d516e5d546e  sub rsp, 0xF0
00007d516e5d5475  vmovaps [rsp], xmm0
00007d516e5d547a  vmovaps [rsp+0x10], xmm1
00007d516e5d5480  vmovaps [rsp+0x20], xmm2
00007d516e5d5486  vmovaps [rsp+0x30], xmm3
00007d516e5d548c  vmovaps [rsp+0x40], xmm4
00007d516e5d5492  vmovaps [rsp+0x50], xmm5
00007d516e5d5498  vmovaps [rsp+0x60], xmm6
00007d516e5d549e  vmovaps [rsp+0x70], xmm7
00007d516e5d54a4  vmovaps [rsp+0x80], xmm8
00007d516e5d54ad  vmovaps [rsp+0x90], xmm9
00007d516e5d54b6  vmovaps [rsp+0xA0], xmm10
00007d516e5d54bf  vmovaps [rsp+0xB0], xmm11
00007d516e5d54c8  vmovaps [rsp+0xC0], xmm12
00007d516e5d54d1  vmovaps [rsp+0xD0], xmm13
00007d516e5d54da  vmovaps [rsp+0xE0], xmm15
00007d516e5d54e3  sub rsp, 0x30
00007d516e5d54e7  movaps [rsp], xmm14
00007d516e5d54ec  movaps [rsp+0x10], xmm11
00007d516e5d54f2  movaps [rsp+0x20], xmm1
00007d516e5d54f7  lea rdi, [rsp]
00007d516e5d54fb  mov esi, 0x00
00007d516e5d5500  mov rax, 0x5EE43AF14530
00007d516e5d550a  call rax
00007d516e5d550c  movaps xmm14, [rsp]
00007d516e5d5511  add rsp, 0x30
00007d516e5d5515  vmovaps xmm0, [rsp]
00007d516e5d551a  vmovaps xmm1, [rsp+0x10]
00007d516e5d5520  vmovaps xmm2, [rsp+0x20]
00007d516e5d5526  vmovaps xmm3, [rsp+0x30]
00007d516e5d552c  vmovaps xmm4, [rsp+0x40]
00007d516e5d5532  vmovaps xmm5, [rsp+0x50]
00007d516e5d5538  vmovaps xmm6, [rsp+0x60]
00007d516e5d553e  vmovaps xmm7, [rsp+0x70]
00007d516e5d5544  vmovaps xmm8, [rsp+0x80]
00007d516e5d554d  vmovaps xmm9, [rsp+0x90]
00007d516e5d5556  vmovaps xmm10, [rsp+0xA0]
00007d516e5d555f  vmovaps xmm11, [rsp+0xB0]
00007d516e5d5568  vmovaps xmm12, [rsp+0xC0]
00007d516e5d5571  vmovaps xmm13, [rsp+0xD0]
00007d516e5d557a  vmovaps xmm15, [rsp+0xE0]
00007d516e5d5583  add rsp, 0xF0
00007d516e5d558a  pop r11
00007d516e5d558c  pop r10
00007d516e5d558e  pop r9
00007d516e5d5590  pop r8
00007d516e5d5592  pop rsi
00007d516e5d5593  pop rdi
00007d516e5d5594  pop rdx
00007d516e5d5595  pop rcx
00007d516e5d5596  pop rax
00007d516e5d5597  add rsp, 0x08
00007d516e5d559b  jmp 0x00007D516E5D2E48
00007d516e5d55a0  sub rsp, 0x08
00007d516e5d55a4  push rax
00007d516e5d55a5  push rcx
00007d516e5d55a6  push rdx
00007d516e5d55a7  push rdi
00007d516e5d55a8  push rsi
00007d516e5d55a9  push r8
00007d516e5d55ab  push r9
00007d516e5d55ad  push r10
00007d516e5d55af  push r11
00007d516e5d55b1  sub rsp, 0xF0
00007d516e5d55b8  vmovaps [rsp], xmm0
00007d516e5d55bd  vmovaps [rsp+0x10], xmm1
00007d516e5d55c3  vmovaps [rsp+0x20], xmm2
00007d516e5d55c9  vmovaps [rsp+0x30], xmm3
00007d516e5d55cf  vmovaps [rsp+0x40], xmm4
00007d516e5d55d5  vmovaps [rsp+0x50], xmm5
00007d516e5d55db  vmovaps [rsp+0x60], xmm6
00007d516e5d55e1  vmovaps [rsp+0x70], xmm7
00007d516e5d55e7  vmovaps [rsp+0x80], xmm8
00007d516e5d55f0  vmovaps [rsp+0x90], xmm9
00007d516e5d55f9  vmovaps [rsp+0xA0], xmm10
00007d516e5d5602  vmovaps [rsp+0xB0], xmm11
00007d516e5d560b  vmovaps [rsp+0xC0], xmm12
00007d516e5d5614  vmovaps [rsp+0xD0], xmm14
00007d516e5d561d  vmovaps [rsp+0xE0], xmm15
00007d516e5d5626  sub rsp, 0x30
00007d516e5d562a  movaps [rsp], xmm13
00007d516e5d562f  movaps [rsp+0x10], xmm11
00007d516e5d5635  movaps [rsp+0x20], xmm1
00007d516e5d563a  lea rdi, [rsp]
00007d516e5d563e  mov esi, 0x00
00007d516e5d5643  mov rax, 0x5EE43AF14530
00007d516e5d564d  call rax
00007d516e5d564f  movaps xmm13, [rsp]
00007d516e5d5654  add rsp, 0x30
00007d516e5d5658  vmovaps xmm0, [rsp]
00007d516e5d565d  vmovaps xmm1, [rsp+0x10]
00007d516e5d5663  vmovaps xmm2, [rsp+0x20]
00007d516e5d5669  vmovaps xmm3, [rsp+0x30]
00007d516e5d566f  vmovaps xmm4, [rsp+0x40]
00007d516e5d5675  vmovaps xmm5, [rsp+0x50]
00007d516e5d567b  vmovaps xmm6, [rsp+0x60]
00007d516e5d5681  vmovaps xmm7, [rsp+0x70]
00007d516e5d5687  vmovaps xmm8, [rsp+0x80]
00007d516e5d5690  vmovaps xmm9, [rsp+0x90]
00007d516e5d5699  vmovaps xmm10, [rsp+0xA0]
00007d516e5d56a2  vmovaps xmm11, [rsp+0xB0]
00007d516e5d56ab  vmovaps xmm12, [rsp+0xC0]
00007d516e5d56b4  vmovaps xmm14, [rsp+0xD0]
00007d516e5d56bd  vmovaps xmm15, [rsp+0xE0]
00007d516e5d56c6  add rsp, 0xF0
00007d516e5d56cd  pop r11
00007d516e5d56cf  pop r10
00007d516e5d56d1  pop r9
00007d516e5d56d3  pop r8
00007d516e5d56d5  pop rsi
00007d516e5d56d6  pop rdi
00007d516e5d56d7  pop rdx
00007d516e5d56d8  pop rcx
00007d516e5d56d9  pop rax
00007d516e5d56da  add rsp, 0x08
00007d516e5d56de  jmp 0x00007D516E5D2E9D
00007d516e5d56e3  call 0x00007D516E3FF430
00007d516e5d56e8  jmp 0x00007D516E5D2EAA
00007d516e5d56ed  sub rsp, 0x08
00007d516e5d56f1  push rax
00007d516e5d56f2  push rcx
00007d516e5d56f3  push rdx
00007d516e5d56f4  push rdi
00007d516e5d56f5  push rsi
00007d516e5d56f6  push r8
00007d516e5d56f8  push r9
00007d516e5d56fa  push r10
00007d516e5d56fc  push r11
00007d516e5d56fe  sub rsp, 0xF0
00007d516e5d5705  vmovaps [rsp], xmm0
00007d516e5d570a  vmovaps [rsp+0x10], xmm1
00007d516e5d5710  vmovaps [rsp+0x20], xmm2
00007d516e5d5716  vmovaps [rsp+0x30], xmm3
00007d516e5d571c  vmovaps [rsp+0x40], xmm4
00007d516e5d5722  vmovaps [rsp+0x50], xmm5
00007d516e5d5728  vmovaps [rsp+0x60], xmm6
00007d516e5d572e  vmovaps [rsp+0x70], xmm7
00007d516e5d5734  vmovaps [rsp+0x80], xmm8
00007d516e5d573d  vmovaps [rsp+0x90], xmm9
00007d516e5d5746  vmovaps [rsp+0xA0], xmm10
00007d516e5d574f  vmovaps [rsp+0xB0], xmm11
00007d516e5d5758  vmovaps [rsp+0xC0], xmm12
00007d516e5d5761  vmovaps [rsp+0xD0], xmm13
00007d516e5d576a  vmovaps [rsp+0xE0], xmm14
00007d516e5d5773  sub rsp, 0x30
00007d516e5d5777  movaps [rsp], xmm15
00007d516e5d577c  movaps [rsp+0x10], xmm11
00007d516e5d5782  movaps [rsp+0x20], xmm1
00007d516e5d5787  lea rdi, [rsp]
00007d516e5d578b  mov esi, 0x00
00007d516e5d5790  mov rax, 0x5EE43AF14530
00007d516e5d579a  call rax
00007d516e5d579c  movaps xmm15, [rsp]
00007d516e5d57a1  add rsp, 0x30
00007d516e5d57a5  vmovaps xmm0, [rsp]
00007d516e5d57aa  vmovaps xmm1, [rsp+0x10]
00007d516e5d57b0  vmovaps xmm2, [rsp+0x20]
00007d516e5d57b6  vmovaps xmm3, [rsp+0x30]
00007d516e5d57bc  vmovaps xmm4, [rsp+0x40]
00007d516e5d57c2  vmovaps xmm5, [rsp+0x50]
00007d516e5d57c8  vmovaps xmm6, [rsp+0x60]
00007d516e5d57ce  vmovaps xmm7, [rsp+0x70]
00007d516e5d57d4  vmovaps xmm8, [rsp+0x80]
00007d516e5d57dd  vmovaps xmm9, [rsp+0x90]
00007d516e5d57e6  vmovaps xmm10, [rsp+0xA0]
00007d516e5d57ef  vmovaps xmm11, [rsp+0xB0]
00007d516e5d57f8  vmovaps xmm12, [rsp+0xC0]
00007d516e5d5801  vmovaps xmm13, [rsp+0xD0]
00007d516e5d580a  vmovaps xmm14, [rsp+0xE0]
00007d516e5d5813  add rsp, 0xF0
00007d516e5d581a  pop r11
00007d516e5d581c  pop r10
00007d516e5d581e  pop r9
00007d516e5d5820  pop r8
00007d516e5d5822  pop rsi
00007d516e5d5823  pop rdi
00007d516e5d5824  pop rdx
00007d516e5d5825  pop rcx
00007d516e5d5826  pop rax
00007d516e5d5827  add rsp, 0x08
00007d516e5d582b  jmp 0x00007D516E5D2EE3
00007d516e5d5830  sub rsp, 0x08
00007d516e5d5834  push rax
00007d516e5d5835  push rcx
00007d516e5d5836  push rdx
00007d516e5d5837  push rdi
00007d516e5d5838  push rsi
00007d516e5d5839  push r8
00007d516e5d583b  push r9
00007d516e5d583d  push r10
00007d516e5d583f  push r11
00007d516e5d5841  sub rsp, 0xF0
00007d516e5d5848  vmovaps [rsp], xmm0
00007d516e5d584d  vmovaps [rsp+0x10], xmm1
00007d516e5d5853  vmovaps [rsp+0x20], xmm2
00007d516e5d5859  vmovaps [rsp+0x30], xmm3
00007d516e5d585f  vmovaps [rsp+0x40], xmm4
00007d516e5d5865  vmovaps [rsp+0x50], xmm5
00007d516e5d586b  vmovaps [rsp+0x60], xmm6
00007d516e5d5871  vmovaps [rsp+0x70], xmm7
00007d516e5d5877  vmovaps [rsp+0x80], xmm8
00007d516e5d5880  vmovaps [rsp+0x90], xmm9
00007d516e5d5889  vmovaps [rsp+0xA0], xmm10
00007d516e5d5892  vmovaps [rsp+0xB0], xmm12
00007d516e5d589b  vmovaps [rsp+0xC0], xmm13
00007d516e5d58a4  vmovaps [rsp+0xD0], xmm14
00007d516e5d58ad  vmovaps [rsp+0xE0], xmm15
00007d516e5d58b6  sub rsp, 0x30
00007d516e5d58ba  movaps [rsp], xmm11
00007d516e5d58bf  movaps [rsp+0x10], xmm6
00007d516e5d58c4  movaps [rsp+0x20], xmm14
00007d516e5d58ca  lea rdi, [rsp]
00007d516e5d58ce  mov esi, 0x00
00007d516e5d58d3  mov rax, 0x5EE43AF14530
00007d516e5d58dd  call rax
00007d516e5d58df  movaps xmm11, [rsp]
00007d516e5d58e4  add rsp, 0x30
00007d516e5d58e8  vmovaps xmm0, [rsp]
00007d516e5d58ed  vmovaps xmm1, [rsp+0x10]
00007d516e5d58f3  vmovaps xmm2, [rsp+0x20]
00007d516e5d58f9  vmovaps xmm3, [rsp+0x30]
00007d516e5d58ff  vmovaps xmm4, [rsp+0x40]
00007d516e5d5905  vmovaps xmm5, [rsp+0x50]
00007d516e5d590b  vmovaps xmm6, [rsp+0x60]
00007d516e5d5911  vmovaps xmm7, [rsp+0x70]
00007d516e5d5917  vmovaps xmm8, [rsp+0x80]
00007d516e5d5920  vmovaps xmm9, [rsp+0x90]
00007d516e5d5929  vmovaps xmm10, [rsp+0xA0]
00007d516e5d5932  vmovaps xmm12, [rsp+0xB0]
00007d516e5d593b  vmovaps xmm13, [rsp+0xC0]
00007d516e5d5944  vmovaps xmm14, [rsp+0xD0]
00007d516e5d594d  vmovaps xmm15, [rsp+0xE0]
00007d516e5d5956  add rsp, 0xF0
00007d516e5d595d  pop r11
00007d516e5d595f  pop r10
00007d516e5d5961  pop r9
00007d516e5d5963  pop r8
00007d516e5d5965  pop rsi
00007d516e5d5966  pop rdi
00007d516e5d5967  pop rdx
00007d516e5d5968  pop rcx
00007d516e5d5969  pop rax
00007d516e5d596a  add rsp, 0x08
00007d516e5d596e  jmp 0x00007D516E5D2F5B
00007d516e5d5973  call 0x00007D516E3FF430
00007d516e5d5978  jmp 0x00007D516E5D2F65
00007d516e5d597d  sub rsp, 0x08
00007d516e5d5981  push rax
00007d516e5d5982  push rcx
00007d516e5d5983  push rdx
00007d516e5d5984  push rdi
00007d516e5d5985  push rsi
00007d516e5d5986  push r8
00007d516e5d5988  push r9
00007d516e5d598a  push r10
00007d516e5d598c  push r11
00007d516e5d598e  sub rsp, 0xF0
00007d516e5d5995  vmovaps [rsp], xmm0
00007d516e5d599a  vmovaps [rsp+0x10], xmm1
00007d516e5d59a0  vmovaps [rsp+0x20], xmm2
00007d516e5d59a6  vmovaps [rsp+0x30], xmm3
00007d516e5d59ac  vmovaps [rsp+0x40], xmm4
00007d516e5d59b2  vmovaps [rsp+0x50], xmm5
00007d516e5d59b8  vmovaps [rsp+0x60], xmm6
00007d516e5d59be  vmovaps [rsp+0x70], xmm7
00007d516e5d59c4  vmovaps [rsp+0x80], xmm8
00007d516e5d59cd  vmovaps [rsp+0x90], xmm9
00007d516e5d59d6  vmovaps [rsp+0xA0], xmm10
00007d516e5d59df  vmovaps [rsp+0xB0], xmm11
00007d516e5d59e8  vmovaps [rsp+0xC0], xmm12
00007d516e5d59f1  vmovaps [rsp+0xD0], xmm13
00007d516e5d59fa  vmovaps [rsp+0xE0], xmm15
00007d516e5d5a03  sub rsp, 0x30
00007d516e5d5a07  movaps [rsp], xmm14
00007d516e5d5a0c  movaps [rsp+0x10], xmm6
00007d516e5d5a11  movaps [rsp+0x20], xmm2
00007d516e5d5a16  lea rdi, [rsp]
00007d516e5d5a1a  mov esi, 0x00
00007d516e5d5a1f  mov rax, 0x5EE43AF14530
00007d516e5d5a29  call rax
00007d516e5d5a2b  movaps xmm14, [rsp]
00007d516e5d5a30  add rsp, 0x30
00007d516e5d5a34  vmovaps xmm0, [rsp]
00007d516e5d5a39  vmovaps xmm1, [rsp+0x10]
00007d516e5d5a3f  vmovaps xmm2, [rsp+0x20]
00007d516e5d5a45  vmovaps xmm3, [rsp+0x30]
00007d516e5d5a4b  vmovaps xmm4, [rsp+0x40]
00007d516e5d5a51  vmovaps xmm5, [rsp+0x50]
00007d516e5d5a57  vmovaps xmm6, [rsp+0x60]
00007d516e5d5a5d  vmovaps xmm7, [rsp+0x70]
00007d516e5d5a63  vmovaps xmm8, [rsp+0x80]
00007d516e5d5a6c  vmovaps xmm9, [rsp+0x90]
00007d516e5d5a75  vmovaps xmm10, [rsp+0xA0]
00007d516e5d5a7e  vmovaps xmm11, [rsp+0xB0]
00007d516e5d5a87  vmovaps xmm12, [rsp+0xC0]
00007d516e5d5a90  vmovaps xmm13, [rsp+0xD0]
00007d516e5d5a99  vmovaps xmm15, [rsp+0xE0]
00007d516e5d5aa2  add rsp, 0xF0
00007d516e5d5aa9  pop r11
00007d516e5d5aab  pop r10
00007d516e5d5aad  pop r9
00007d516e5d5aaf  pop r8
00007d516e5d5ab1  pop rsi
00007d516e5d5ab2  pop rdi
00007d516e5d5ab3  pop rdx
00007d516e5d5ab4  pop rcx
00007d516e5d5ab5  pop rax
00007d516e5d5ab6  add rsp, 0x08
00007d516e5d5aba  jmp 0x00007D516E5D2F99
00007d516e5d5abf  sub rsp, 0x08
00007d516e5d5ac3  push rax
00007d516e5d5ac4  push rcx
00007d516e5d5ac5  push rdx
00007d516e5d5ac6  push rdi
00007d516e5d5ac7  push rsi
00007d516e5d5ac8  push r8
00007d516e5d5aca  push r9
00007d516e5d5acc  push r10
00007d516e5d5ace  push r11
00007d516e5d5ad0  sub rsp, 0xF0
00007d516e5d5ad7  vmovaps [rsp], xmm0
00007d516e5d5adc  vmovaps [rsp+0x10], xmm1
00007d516e5d5ae2  vmovaps [rsp+0x20], xmm2
00007d516e5d5ae8  vmovaps [rsp+0x30], xmm3
00007d516e5d5aee  vmovaps [rsp+0x40], xmm4
00007d516e5d5af4  vmovaps [rsp+0x50], xmm5
00007d516e5d5afa  vmovaps [rsp+0x60], xmm7
00007d516e5d5b00  vmovaps [rsp+0x70], xmm8
00007d516e5d5b06  vmovaps [rsp+0x80], xmm9
00007d516e5d5b0f  vmovaps [rsp+0x90], xmm10
00007d516e5d5b18  vmovaps [rsp+0xA0], xmm11
00007d516e5d5b21  vmovaps [rsp+0xB0], xmm12
00007d516e5d5b2a  vmovaps [rsp+0xC0], xmm13
00007d516e5d5b33  vmovaps [rsp+0xD0], xmm14
00007d516e5d5b3c  vmovaps [rsp+0xE0], xmm15
00007d516e5d5b45  sub rsp, 0x30
00007d516e5d5b49  movaps [rsp], xmm6
00007d516e5d5b4d  movaps [rsp+0x10], xmm5
00007d516e5d5b52  movaps [rsp+0x20], xmm1
00007d516e5d5b57  lea rdi, [rsp]
00007d516e5d5b5b  mov esi, 0x00
00007d516e5d5b60  mov rax, 0x5EE43AF14530
00007d516e5d5b6a  call rax
00007d516e5d5b6c  movaps xmm6, [rsp]
00007d516e5d5b70  add rsp, 0x30
00007d516e5d5b74  vmovaps xmm0, [rsp]
00007d516e5d5b79  vmovaps xmm1, [rsp+0x10]
00007d516e5d5b7f  vmovaps xmm2, [rsp+0x20]
00007d516e5d5b85  vmovaps xmm3, [rsp+0x30]
00007d516e5d5b8b  vmovaps xmm4, [rsp+0x40]
00007d516e5d5b91  vmovaps xmm5, [rsp+0x50]
00007d516e5d5b97  vmovaps xmm7, [rsp+0x60]
00007d516e5d5b9d  vmovaps xmm8, [rsp+0x70]
00007d516e5d5ba3  vmovaps xmm9, [rsp+0x80]
00007d516e5d5bac  vmovaps xmm10, [rsp+0x90]
00007d516e5d5bb5  vmovaps xmm11, [rsp+0xA0]
00007d516e5d5bbe  vmovaps xmm12, [rsp+0xB0]
00007d516e5d5bc7  vmovaps xmm13, [rsp+0xC0]
00007d516e5d5bd0  vmovaps xmm14, [rsp+0xD0]
00007d516e5d5bd9  vmovaps xmm15, [rsp+0xE0]
00007d516e5d5be2  add rsp, 0xF0
00007d516e5d5be9  pop r11
00007d516e5d5beb  pop r10
00007d516e5d5bed  pop r9
00007d516e5d5bef  pop r8
00007d516e5d5bf1  pop rsi
00007d516e5d5bf2  pop rdi
00007d516e5d5bf3  pop rdx
00007d516e5d5bf4  pop rcx
00007d516e5d5bf5  pop rax
00007d516e5d5bf6  add rsp, 0x08
00007d516e5d5bfa  jmp 0x00007D516E5D2FBF
00007d516e5d5bff  sub rsp, 0x08
00007d516e5d5c03  push rax
00007d516e5d5c04  push rcx
00007d516e5d5c05  push rdx
00007d516e5d5c06  push rdi
00007d516e5d5c07  push rsi
00007d516e5d5c08  push r8
00007d516e5d5c0a  push r9
00007d516e5d5c0c  push r10
00007d516e5d5c0e  push r11
00007d516e5d5c10  sub rsp, 0xF0
00007d516e5d5c17  vmovaps [rsp], xmm0
00007d516e5d5c1c  vmovaps [rsp+0x10], xmm2
00007d516e5d5c22  vmovaps [rsp+0x20], xmm3
00007d516e5d5c28  vmovaps [rsp+0x30], xmm4
00007d516e5d5c2e  vmovaps [rsp+0x40], xmm5
00007d516e5d5c34  vmovaps [rsp+0x50], xmm6
00007d516e5d5c3a  vmovaps [rsp+0x60], xmm7
00007d516e5d5c40  vmovaps [rsp+0x70], xmm8
00007d516e5d5c46  vmovaps [rsp+0x80], xmm9
00007d516e5d5c4f  vmovaps [rsp+0x90], xmm10
00007d516e5d5c58  vmovaps [rsp+0xA0], xmm11
00007d516e5d5c61  vmovaps [rsp+0xB0], xmm12
00007d516e5d5c6a  vmovaps [rsp+0xC0], xmm13
00007d516e5d5c73  vmovaps [rsp+0xD0], xmm14
00007d516e5d5c7c  vmovaps [rsp+0xE0], xmm15
00007d516e5d5c85  sub rsp, 0x30
00007d516e5d5c89  movaps [rsp], xmm1
00007d516e5d5c8d  movaps [rsp+0x10], xmm5
00007d516e5d5c92  movaps [rsp+0x20], xmm13
00007d516e5d5c98  lea rdi, [rsp]
00007d516e5d5c9c  mov esi, 0x00
00007d516e5d5ca1  mov rax, 0x5EE43AF14530
00007d516e5d5cab  call rax
00007d516e5d5cad  movaps xmm1, [rsp]
00007d516e5d5cb1  add rsp, 0x30
00007d516e5d5cb5  vmovaps xmm0, [rsp]
00007d516e5d5cba  vmovaps xmm2, [rsp+0x10]
00007d516e5d5cc0  vmovaps xmm3, [rsp+0x20]
00007d516e5d5cc6  vmovaps xmm4, [rsp+0x30]
00007d516e5d5ccc  vmovaps xmm5, [rsp+0x40]
00007d516e5d5cd2  vmovaps xmm6, [rsp+0x50]
00007d516e5d5cd8  vmovaps xmm7, [rsp+0x60]
00007d516e5d5cde  vmovaps xmm8, [rsp+0x70]
00007d516e5d5ce4  vmovaps xmm9, [rsp+0x80]
00007d516e5d5ced  vmovaps xmm10, [rsp+0x90]
00007d516e5d5cf6  vmovaps xmm11, [rsp+0xA0]
00007d516e5d5cff  vmovaps xmm12, [rsp+0xB0]
00007d516e5d5d08  vmovaps xmm13, [rsp+0xC0]
00007d516e5d5d11  vmovaps xmm14, [rsp+0xD0]
00007d516e5d5d1a  vmovaps xmm15, [rsp+0xE0]
00007d516e5d5d23  add rsp, 0xF0
00007d516e5d5d2a  pop r11
00007d516e5d5d2c  pop r10
00007d516e5d5d2e  pop r9
00007d516e5d5d30  pop r8
00007d516e5d5d32  pop rsi
00007d516e5d5d33  pop rdi
00007d516e5d5d34  pop rdx
00007d516e5d5d35  pop rcx
00007d516e5d5d36  pop rax
00007d516e5d5d37  add rsp, 0x08
00007d516e5d5d3b  jmp 0x00007D516E5D2FDD
00007d516e5d5d40  sub rsp, 0x08
00007d516e5d5d44  push rax
00007d516e5d5d45  push rcx
00007d516e5d5d46  push rdx
00007d516e5d5d47  push rdi
00007d516e5d5d48  push rsi
00007d516e5d5d49  push r8
00007d516e5d5d4b  push r9
00007d516e5d5d4d  push r10
00007d516e5d5d4f  push r11
00007d516e5d5d51  sub rsp, 0xF0
00007d516e5d5d58  vmovaps [rsp], xmm0
00007d516e5d5d5d  vmovaps [rsp+0x10], xmm1
00007d516e5d5d63  vmovaps [rsp+0x20], xmm2
00007d516e5d5d69  vmovaps [rsp+0x30], xmm3
00007d516e5d5d6f  vmovaps [rsp+0x40], xmm4
00007d516e5d5d75  vmovaps [rsp+0x50], xmm6
00007d516e5d5d7b  vmovaps [rsp+0x60], xmm7
00007d516e5d5d81  vmovaps [rsp+0x70], xmm8
00007d516e5d5d87  vmovaps [rsp+0x80], xmm9
00007d516e5d5d90  vmovaps [rsp+0x90], xmm10
00007d516e5d5d99  vmovaps [rsp+0xA0], xmm11
00007d516e5d5da2  vmovaps [rsp+0xB0], xmm12
00007d516e5d5dab  vmovaps [rsp+0xC0], xmm13
00007d516e5d5db4  vmovaps [rsp+0xD0], xmm14
00007d516e5d5dbd  vmovaps [rsp+0xE0], xmm15
00007d516e5d5dc6  sub rsp, 0x30
00007d516e5d5dca  movaps [rsp], xmm5
00007d516e5d5dce  movaps [rsp+0x10], xmm2
00007d516e5d5dd3  movaps [rsp+0x20], xmm13
00007d516e5d5dd9  lea rdi, [rsp]
00007d516e5d5ddd  mov esi, 0x00
00007d516e5d5de2  mov rax, 0x5EE43AF14530
00007d516e5d5dec  call rax
00007d516e5d5dee  movaps xmm5, [rsp]
00007d516e5d5df2  add rsp, 0x30
00007d516e5d5df6  vmovaps xmm0, [rsp]
00007d516e5d5dfb  vmovaps xmm1, [rsp+0x10]
00007d516e5d5e01  vmovaps xmm2, [rsp+0x20]
00007d516e5d5e07  vmovaps xmm3, [rsp+0x30]
00007d516e5d5e0d  vmovaps xmm4, [rsp+0x40]
00007d516e5d5e13  vmovaps xmm6, [rsp+0x50]
00007d516e5d5e19  vmovaps xmm7, [rsp+0x60]
00007d516e5d5e1f  vmovaps xmm8, [rsp+0x70]
00007d516e5d5e25  vmovaps xmm9, [rsp+0x80]
00007d516e5d5e2e  vmovaps xmm10, [rsp+0x90]
00007d516e5d5e37  vmovaps xmm11, [rsp+0xA0]
00007d516e5d5e40  vmovaps xmm12, [rsp+0xB0]
00007d516e5d5e49  vmovaps xmm13, [rsp+0xC0]
00007d516e5d5e52  vmovaps xmm14, [rsp+0xD0]
00007d516e5d5e5b  vmovaps xmm15, [rsp+0xE0]
00007d516e5d5e64  add rsp, 0xF0
00007d516e5d5e6b  pop r11
00007d516e5d5e6d  pop r10
00007d516e5d5e6f  pop r9
00007d516e5d5e71  pop r8
00007d516e5d5e73  pop rsi
00007d516e5d5e74  pop rdi
00007d516e5d5e75  pop rdx
00007d516e5d5e76  pop rcx
00007d516e5d5e77  pop rax
00007d516e5d5e78  add rsp, 0x08
00007d516e5d5e7c  jmp 0x00007D516E5D3013
00007d516e5d5e81  sub rsp, 0x08
00007d516e5d5e85  push rax
00007d516e5d5e86  push rcx
00007d516e5d5e87  push rdx
00007d516e5d5e88  push rdi
00007d516e5d5e89  push rsi
00007d516e5d5e8a  push r8
00007d516e5d5e8c  push r9
00007d516e5d5e8e  push r10
00007d516e5d5e90  push r11
00007d516e5d5e92  sub rsp, 0xF0
00007d516e5d5e99  vmovaps [rsp], xmm0
00007d516e5d5e9e  vmovaps [rsp+0x10], xmm1
00007d516e5d5ea4  vmovaps [rsp+0x20], xmm2
00007d516e5d5eaa  vmovaps [rsp+0x30], xmm3
00007d516e5d5eb0  vmovaps [rsp+0x40], xmm4
00007d516e5d5eb6  vmovaps [rsp+0x50], xmm5
00007d516e5d5ebc  vmovaps [rsp+0x60], xmm6
00007d516e5d5ec2  vmovaps [rsp+0x70], xmm7
00007d516e5d5ec8  vmovaps [rsp+0x80], xmm8
00007d516e5d5ed1  vmovaps [rsp+0x90], xmm9
00007d516e5d5eda  vmovaps [rsp+0xA0], xmm10
00007d516e5d5ee3  vmovaps [rsp+0xB0], xmm11
00007d516e5d5eec  vmovaps [rsp+0xC0], xmm12
00007d516e5d5ef5  vmovaps [rsp+0xD0], xmm14
00007d516e5d5efe  vmovaps [rsp+0xE0], xmm15
00007d516e5d5f07  sub rsp, 0x30
00007d516e5d5f0b  movaps [rsp], xmm13
00007d516e5d5f10  movaps [rsp+0x10], xmm10
00007d516e5d5f16  movaps [rsp+0x20], xmm1
00007d516e5d5f1b  lea rdi, [rsp]
00007d516e5d5f1f  mov esi, 0x00
00007d516e5d5f24  mov rax, 0x5EE43AF14530
00007d516e5d5f2e  call rax
00007d516e5d5f30  movaps xmm13, [rsp]
00007d516e5d5f35  add rsp, 0x30
00007d516e5d5f39  vmovaps xmm0, [rsp]
00007d516e5d5f3e  vmovaps xmm1, [rsp+0x10]
00007d516e5d5f44  vmovaps xmm2, [rsp+0x20]
00007d516e5d5f4a  vmovaps xmm3, [rsp+0x30]
00007d516e5d5f50  vmovaps xmm4, [rsp+0x40]
00007d516e5d5f56  vmovaps xmm5, [rsp+0x50]
00007d516e5d5f5c  vmovaps xmm6, [rsp+0x60]
00007d516e5d5f62  vmovaps xmm7, [rsp+0x70]
00007d516e5d5f68  vmovaps xmm8, [rsp+0x80]
00007d516e5d5f71  vmovaps xmm9, [rsp+0x90]
00007d516e5d5f7a  vmovaps xmm10, [rsp+0xA0]
00007d516e5d5f83  vmovaps xmm11, [rsp+0xB0]
00007d516e5d5f8c  vmovaps xmm12, [rsp+0xC0]
00007d516e5d5f95  vmovaps xmm14, [rsp+0xD0]
00007d516e5d5f9e  vmovaps xmm15, [rsp+0xE0]
00007d516e5d5fa7  add rsp, 0xF0
00007d516e5d5fae  pop r11
00007d516e5d5fb0  pop r10
00007d516e5d5fb2  pop r9
00007d516e5d5fb4  pop r8
00007d516e5d5fb6  pop rsi
00007d516e5d5fb7  pop rdi
00007d516e5d5fb8  pop rdx
00007d516e5d5fb9  pop rcx
00007d516e5d5fba  pop rax
00007d516e5d5fbb  add rsp, 0x08
00007d516e5d5fbf  jmp 0x00007D516E5D303C
00007d516e5d5fc4  sub rsp, 0x08
00007d516e5d5fc8  push rax
00007d516e5d5fc9  push rcx
00007d516e5d5fca  push rdx
00007d516e5d5fcb  push rdi
00007d516e5d5fcc  push rsi
00007d516e5d5fcd  push r8
00007d516e5d5fcf  push r9
00007d516e5d5fd1  push r10
00007d516e5d5fd3  push r11
00007d516e5d5fd5  sub rsp, 0xF0
00007d516e5d5fdc  vmovaps [rsp], xmm0
00007d516e5d5fe1  vmovaps [rsp+0x10], xmm2
00007d516e5d5fe7  vmovaps [rsp+0x20], xmm3
00007d516e5d5fed  vmovaps [rsp+0x30], xmm4
00007d516e5d5ff3  vmovaps [rsp+0x40], xmm5
00007d516e5d5ff9  vmovaps [rsp+0x50], xmm6
00007d516e5d5fff  vmovaps [rsp+0x60], xmm7
00007d516e5d6005  vmovaps [rsp+0x70], xmm8
00007d516e5d600b  vmovaps [rsp+0x80], xmm9
00007d516e5d6014  vmovaps [rsp+0x90], xmm10
00007d516e5d601d  vmovaps [rsp+0xA0], xmm11
00007d516e5d6026  vmovaps [rsp+0xB0], xmm12
00007d516e5d602f  vmovaps [rsp+0xC0], xmm13
00007d516e5d6038  vmovaps [rsp+0xD0], xmm14
00007d516e5d6041  vmovaps [rsp+0xE0], xmm15
00007d516e5d604a  sub rsp, 0x30
00007d516e5d604e  movaps [rsp], xmm1
00007d516e5d6052  movaps [rsp+0x10], xmm15
00007d516e5d6058  movaps [rsp+0x20], xmm10
00007d516e5d605e  lea rdi, [rsp]
00007d516e5d6062  mov esi, 0x00
00007d516e5d6067  mov rax, 0x5EE43AF14530
00007d516e5d6071  call rax
00007d516e5d6073  movaps xmm1, [rsp]
00007d516e5d6077  add rsp, 0x30
00007d516e5d607b  vmovaps xmm0, [rsp]
00007d516e5d6080  vmovaps xmm2, [rsp+0x10]
00007d516e5d6086  vmovaps xmm3, [rsp+0x20]
00007d516e5d608c  vmovaps xmm4, [rsp+0x30]
00007d516e5d6092  vmovaps xmm5, [rsp+0x40]
00007d516e5d6098  vmovaps xmm6, [rsp+0x50]
00007d516e5d609e  vmovaps xmm7, [rsp+0x60]
00007d516e5d60a4  vmovaps xmm8, [rsp+0x70]
00007d516e5d60aa  vmovaps xmm9, [rsp+0x80]
00007d516e5d60b3  vmovaps xmm10, [rsp+0x90]
00007d516e5d60bc  vmovaps xmm11, [rsp+0xA0]
00007d516e5d60c5  vmovaps xmm12, [rsp+0xB0]
00007d516e5d60ce  vmovaps xmm13, [rsp+0xC0]
00007d516e5d60d7  vmovaps xmm14, [rsp+0xD0]
00007d516e5d60e0  vmovaps xmm15, [rsp+0xE0]
00007d516e5d60e9  add rsp, 0xF0
00007d516e5d60f0  pop r11
00007d516e5d60f2  pop r10
00007d516e5d60f4  pop r9
00007d516e5d60f6  pop r8
00007d516e5d60f8  pop rsi
00007d516e5d60f9  pop rdi
00007d516e5d60fa  pop rdx
00007d516e5d60fb  pop rcx
00007d516e5d60fc  pop rax
00007d516e5d60fd  add rsp, 0x08
00007d516e5d6101  jmp 0x00007D516E5D305B
00007d516e5d6106  sub rsp, 0x08
00007d516e5d610a  push rax
00007d516e5d610b  push rcx
00007d516e5d610c  push rdx
00007d516e5d610d  push rdi
00007d516e5d610e  push rsi
00007d516e5d610f  push r8
00007d516e5d6111  push r9
00007d516e5d6113  push r10
00007d516e5d6115  push r11
00007d516e5d6117  sub rsp, 0xF0
00007d516e5d611e  vmovaps [rsp], xmm0
00007d516e5d6123  vmovaps [rsp+0x10], xmm1
00007d516e5d6129  vmovaps [rsp+0x20], xmm2
00007d516e5d612f  vmovaps [rsp+0x30], xmm3
00007d516e5d6135  vmovaps [rsp+0x40], xmm4
00007d516e5d613b  vmovaps [rsp+0x50], xmm5
00007d516e5d6141  vmovaps [rsp+0x60], xmm6
00007d516e5d6147  vmovaps [rsp+0x70], xmm7
00007d516e5d614d  vmovaps [rsp+0x80], xmm8
00007d516e5d6156  vmovaps [rsp+0x90], xmm9
00007d516e5d615f  vmovaps [rsp+0xA0], xmm10
00007d516e5d6168  vmovaps [rsp+0xB0], xmm11
00007d516e5d6171  vmovaps [rsp+0xC0], xmm12
00007d516e5d617a  vmovaps [rsp+0xD0], xmm13
00007d516e5d6183  vmovaps [rsp+0xE0], xmm14
00007d516e5d618c  sub rsp, 0x30
00007d516e5d6190  movaps [rsp], xmm15
00007d516e5d6195  movaps [rsp+0x10], xmm10
00007d516e5d619b  movaps [rsp+0x20], xmm11
00007d516e5d61a1  lea rdi, [rsp]
00007d516e5d61a5  mov esi, 0x00
00007d516e5d61aa  mov rax, 0x5EE43AF14530
00007d516e5d61b4  call rax
00007d516e5d61b6  movaps xmm15, [rsp]
00007d516e5d61bb  add rsp, 0x30
00007d516e5d61bf  vmovaps xmm0, [rsp]
00007d516e5d61c4  vmovaps xmm1, [rsp+0x10]
00007d516e5d61ca  vmovaps xmm2, [rsp+0x20]
00007d516e5d61d0  vmovaps xmm3, [rsp+0x30]
00007d516e5d61d6  vmovaps xmm4, [rsp+0x40]
00007d516e5d61dc  vmovaps xmm5, [rsp+0x50]
00007d516e5d61e2  vmovaps xmm6, [rsp+0x60]
00007d516e5d61e8  vmovaps xmm7, [rsp+0x70]
00007d516e5d61ee  vmovaps xmm8, [rsp+0x80]
00007d516e5d61f7  vmovaps xmm9, [rsp+0x90]
00007d516e5d6200  vmovaps xmm10, [rsp+0xA0]
00007d516e5d6209  vmovaps xmm11, [rsp+0xB0]
00007d516e5d6212  vmovaps xmm12, [rsp+0xC0]
00007d516e5d621b  vmovaps xmm13, [rsp+0xD0]
00007d516e5d6224  vmovaps xmm14, [rsp+0xE0]
00007d516e5d622d  add rsp, 0xF0
00007d516e5d6234  pop r11
00007d516e5d6236  pop r10
00007d516e5d6238  pop r9
00007d516e5d623a  pop r8
00007d516e5d623c  pop rsi
00007d516e5d623d  pop rdi
00007d516e5d623e  pop rdx
00007d516e5d623f  pop rcx
00007d516e5d6240  pop rax
00007d516e5d6241  add rsp, 0x08
00007d516e5d6245  jmp 0x00007D516E5D307E
00007d516e5d624a  sub rsp, 0x08
00007d516e5d624e  push rax
00007d516e5d624f  push rcx
00007d516e5d6250  push rdx
00007d516e5d6251  push rdi
00007d516e5d6252  push rsi
00007d516e5d6253  push r8
00007d516e5d6255  push r9
00007d516e5d6257  push r10
00007d516e5d6259  push r11
00007d516e5d625b  sub rsp, 0xF0
00007d516e5d6262  vmovaps [rsp], xmm0
00007d516e5d6267  vmovaps [rsp+0x10], xmm1
00007d516e5d626d  vmovaps [rsp+0x20], xmm2
00007d516e5d6273  vmovaps [rsp+0x30], xmm3
00007d516e5d6279  vmovaps [rsp+0x40], xmm4
00007d516e5d627f  vmovaps [rsp+0x50], xmm5
00007d516e5d6285  vmovaps [rsp+0x60], xmm6
00007d516e5d628b  vmovaps [rsp+0x70], xmm7
00007d516e5d6291  vmovaps [rsp+0x80], xmm8
00007d516e5d629a  vmovaps [rsp+0x90], xmm9
00007d516e5d62a3  vmovaps [rsp+0xA0], xmm11
00007d516e5d62ac  vmovaps [rsp+0xB0], xmm12
00007d516e5d62b5  vmovaps [rsp+0xC0], xmm13
00007d516e5d62be  vmovaps [rsp+0xD0], xmm14
00007d516e5d62c7  vmovaps [rsp+0xE0], xmm15
00007d516e5d62d0  sub rsp, 0x30
00007d516e5d62d4  movaps [rsp], xmm10
00007d516e5d62d9  movaps [rsp+0x10], xmm2
00007d516e5d62de  movaps [rsp+0x20], xmm11
00007d516e5d62e4  lea rdi, [rsp]
00007d516e5d62e8  mov esi, 0x00
00007d516e5d62ed  mov rax, 0x5EE43AF14530
00007d516e5d62f7  call rax
00007d516e5d62f9  movaps xmm10, [rsp]
00007d516e5d62fe  add rsp, 0x30
00007d516e5d6302  vmovaps xmm0, [rsp]
00007d516e5d6307  vmovaps xmm1, [rsp+0x10]
00007d516e5d630d  vmovaps xmm2, [rsp+0x20]
00007d516e5d6313  vmovaps xmm3, [rsp+0x30]
00007d516e5d6319  vmovaps xmm4, [rsp+0x40]
00007d516e5d631f  vmovaps xmm5, [rsp+0x50]
00007d516e5d6325  vmovaps xmm6, [rsp+0x60]
00007d516e5d632b  vmovaps xmm7, [rsp+0x70]
00007d516e5d6331  vmovaps xmm8, [rsp+0x80]
00007d516e5d633a  vmovaps xmm9, [rsp+0x90]
00007d516e5d6343  vmovaps xmm11, [rsp+0xA0]
00007d516e5d634c  vmovaps xmm12, [rsp+0xB0]
00007d516e5d6355  vmovaps xmm13, [rsp+0xC0]
00007d516e5d635e  vmovaps xmm14, [rsp+0xD0]
00007d516e5d6367  vmovaps xmm15, [rsp+0xE0]
00007d516e5d6370  add rsp, 0xF0
00007d516e5d6377  pop r11
00007d516e5d6379  pop r10
00007d516e5d637b  pop r9
00007d516e5d637d  pop r8
00007d516e5d637f  pop rsi
00007d516e5d6380  pop rdi
00007d516e5d6381  pop rdx
00007d516e5d6382  pop rcx
00007d516e5d6383  pop rax
00007d516e5d6384  add rsp, 0x08
00007d516e5d6388  jmp 0x00007D516E5D30B6
00007d516e5d638d  sub rsp, 0x08
00007d516e5d6391  push rax
00007d516e5d6392  push rcx
00007d516e5d6393  push rdx
00007d516e5d6394  push rdi
00007d516e5d6395  push rsi
00007d516e5d6396  push r8
00007d516e5d6398  push r9
00007d516e5d639a  push r10
00007d516e5d639c  push r11
00007d516e5d639e  sub rsp, 0xF0
00007d516e5d63a5  vmovaps [rsp], xmm0
00007d516e5d63aa  vmovaps [rsp+0x10], xmm1
00007d516e5d63b0  vmovaps [rsp+0x20], xmm2
00007d516e5d63b6  vmovaps [rsp+0x30], xmm3
00007d516e5d63bc  vmovaps [rsp+0x40], xmm4
00007d516e5d63c2  vmovaps [rsp+0x50], xmm5
00007d516e5d63c8  vmovaps [rsp+0x60], xmm6
00007d516e5d63ce  vmovaps [rsp+0x70], xmm7
00007d516e5d63d4  vmovaps [rsp+0x80], xmm8
00007d516e5d63dd  vmovaps [rsp+0x90], xmm9
00007d516e5d63e6  vmovaps [rsp+0xA0], xmm10
00007d516e5d63ef  vmovaps [rsp+0xB0], xmm12
00007d516e5d63f8  vmovaps [rsp+0xC0], xmm13
00007d516e5d6401  vmovaps [rsp+0xD0], xmm14
00007d516e5d640a  vmovaps [rsp+0xE0], xmm15
00007d516e5d6413  sub rsp, 0x30
00007d516e5d6417  movaps [rsp], xmm11
00007d516e5d641c  movaps [rsp+0x10], xmm2
00007d516e5d6421  movaps [rsp+0x20], xmm1
00007d516e5d6426  lea rdi, [rsp]
00007d516e5d642a  mov esi, 0x00
00007d516e5d642f  mov rax, 0x5EE43AF14530
00007d516e5d6439  call rax
00007d516e5d643b  movaps xmm11, [rsp]
00007d516e5d6440  add rsp, 0x30
00007d516e5d6444  vmovaps xmm0, [rsp]
00007d516e5d6449  vmovaps xmm1, [rsp+0x10]
00007d516e5d644f  vmovaps xmm2, [rsp+0x20]
00007d516e5d6455  vmovaps xmm3, [rsp+0x30]
00007d516e5d645b  vmovaps xmm4, [rsp+0x40]
00007d516e5d6461  vmovaps xmm5, [rsp+0x50]
00007d516e5d6467  vmovaps xmm6, [rsp+0x60]
00007d516e5d646d  vmovaps xmm7, [rsp+0x70]
00007d516e5d6473  vmovaps xmm8, [rsp+0x80]
00007d516e5d647c  vmovaps xmm9, [rsp+0x90]
00007d516e5d6485  vmovaps xmm10, [rsp+0xA0]
00007d516e5d648e  vmovaps xmm12, [rsp+0xB0]
00007d516e5d6497  vmovaps xmm13, [rsp+0xC0]
00007d516e5d64a0  vmovaps xmm14, [rsp+0xD0]
00007d516e5d64a9  vmovaps xmm15, [rsp+0xE0]
00007d516e5d64b2  add rsp, 0xF0
00007d516e5d64b9  pop r11
00007d516e5d64bb  pop r10
00007d516e5d64bd  pop r9
00007d516e5d64bf  pop r8
00007d516e5d64c1  pop rsi
00007d516e5d64c2  pop rdi
00007d516e5d64c3  pop rdx
00007d516e5d64c4  pop rcx
00007d516e5d64c5  pop rax
00007d516e5d64c6  add rsp, 0x08
00007d516e5d64ca  jmp 0x00007D516E5D30F2
00007d516e5d64cf  sub rsp, 0x08
00007d516e5d64d3  push rax
00007d516e5d64d4  push rcx
00007d516e5d64d5  push rdx
00007d516e5d64d6  push rdi
00007d516e5d64d7  push rsi
00007d516e5d64d8  push r8
00007d516e5d64da  push r9
00007d516e5d64dc  push r10
00007d516e5d64de  push r11
00007d516e5d64e0  sub rsp, 0xF0
00007d516e5d64e7  vmovaps [rsp], xmm0
00007d516e5d64ec  vmovaps [rsp+0x10], xmm2
00007d516e5d64f2  vmovaps [rsp+0x20], xmm3
00007d516e5d64f8  vmovaps [rsp+0x30], xmm4
00007d516e5d64fe  vmovaps [rsp+0x40], xmm5
00007d516e5d6504  vmovaps [rsp+0x50], xmm6
00007d516e5d650a  vmovaps [rsp+0x60], xmm7
00007d516e5d6510  vmovaps [rsp+0x70], xmm8
00007d516e5d6516  vmovaps [rsp+0x80], xmm9
00007d516e5d651f  vmovaps [rsp+0x90], xmm10
00007d516e5d6528  vmovaps [rsp+0xA0], xmm11
00007d516e5d6531  vmovaps [rsp+0xB0], xmm12
00007d516e5d653a  vmovaps [rsp+0xC0], xmm13
00007d516e5d6543  vmovaps [rsp+0xD0], xmm14
00007d516e5d654c  vmovaps [rsp+0xE0], xmm15
00007d516e5d6555  sub rsp, 0x30
00007d516e5d6559  movaps [rsp], xmm1
00007d516e5d655d  movaps [rsp+0x10], xmm14
00007d516e5d6563  movaps [rsp+0x20], xmm6
00007d516e5d6568  lea rdi, [rsp]
00007d516e5d656c  mov esi, 0x00
00007d516e5d6571  mov rax, 0x5EE43AF14530
00007d516e5d657b  call rax
00007d516e5d657d  movaps xmm1, [rsp]
00007d516e5d6581  add rsp, 0x30
00007d516e5d6585  vmovaps xmm0, [rsp]
00007d516e5d658a  vmovaps xmm2, [rsp+0x10]
00007d516e5d6590  vmovaps xmm3, [rsp+0x20]
00007d516e5d6596  vmovaps xmm4, [rsp+0x30]
00007d516e5d659c  vmovaps xmm5, [rsp+0x40]
00007d516e5d65a2  vmovaps xmm6, [rsp+0x50]
00007d516e5d65a8  vmovaps xmm7, [rsp+0x60]
00007d516e5d65ae  vmovaps xmm8, [rsp+0x70]
00007d516e5d65b4  vmovaps xmm9, [rsp+0x80]
00007d516e5d65bd  vmovaps xmm10, [rsp+0x90]
00007d516e5d65c6  vmovaps xmm11, [rsp+0xA0]
00007d516e5d65cf  vmovaps xmm12, [rsp+0xB0]
00007d516e5d65d8  vmovaps xmm13, [rsp+0xC0]
00007d516e5d65e1  vmovaps xmm14, [rsp+0xD0]
00007d516e5d65ea  vmovaps xmm15, [rsp+0xE0]
00007d516e5d65f3  add rsp, 0xF0
00007d516e5d65fa  pop r11
00007d516e5d65fc  pop r10
00007d516e5d65fe  pop r9
00007d516e5d6600  pop r8
00007d516e5d6602  pop rsi
00007d516e5d6603  pop rdi
00007d516e5d6604  pop rdx
00007d516e5d6605  pop rcx
00007d516e5d6606  pop rax
00007d516e5d6607  add rsp, 0x08
00007d516e5d660b  jmp 0x00007D516E5D310B
00007d516e5d6610  sub rsp, 0x08
00007d516e5d6614  push rax
00007d516e5d6615  push rcx
00007d516e5d6616  push rdx
00007d516e5d6617  push rdi
00007d516e5d6618  push rsi
00007d516e5d6619  push r8
00007d516e5d661b  push r9
00007d516e5d661d  push r10
00007d516e5d661f  push r11
00007d516e5d6621  sub rsp, 0xF0
00007d516e5d6628  vmovaps [rsp], xmm0
00007d516e5d662d  vmovaps [rsp+0x10], xmm1
00007d516e5d6633  vmovaps [rsp+0x20], xmm2
00007d516e5d6639  vmovaps [rsp+0x30], xmm3
00007d516e5d663f  vmovaps [rsp+0x40], xmm4
00007d516e5d6645  vmovaps [rsp+0x50], xmm5
00007d516e5d664b  vmovaps [rsp+0x60], xmm6
00007d516e5d6651  vmovaps [rsp+0x70], xmm7
00007d516e5d6657  vmovaps [rsp+0x80], xmm8
00007d516e5d6660  vmovaps [rsp+0x90], xmm9
00007d516e5d6669  vmovaps [rsp+0xA0], xmm10
00007d516e5d6672  vmovaps [rsp+0xB0], xmm11
00007d516e5d667b  vmovaps [rsp+0xC0], xmm12
00007d516e5d6684  vmovaps [rsp+0xD0], xmm13
00007d516e5d668d  vmovaps [rsp+0xE0], xmm14
00007d516e5d6696  sub rsp, 0x30
00007d516e5d669a  movaps [rsp], xmm15
00007d516e5d669f  movaps [rsp+0x10], xmm14
00007d516e5d66a5  movaps [rsp+0x20], xmm5
00007d516e5d66aa  lea rdi, [rsp]
00007d516e5d66ae  mov esi, 0x00
00007d516e5d66b3  mov rax, 0x5EE43AF14530
00007d516e5d66bd  call rax
00007d516e5d66bf  movaps xmm15, [rsp]
00007d516e5d66c4  add rsp, 0x30
00007d516e5d66c8  vmovaps xmm0, [rsp]
00007d516e5d66cd  vmovaps xmm1, [rsp+0x10]
00007d516e5d66d3  vmovaps xmm2, [rsp+0x20]
00007d516e5d66d9  vmovaps xmm3, [rsp+0x30]
00007d516e5d66df  vmovaps xmm4, [rsp+0x40]
00007d516e5d66e5  vmovaps xmm5, [rsp+0x50]
00007d516e5d66eb  vmovaps xmm6, [rsp+0x60]
00007d516e5d66f1  vmovaps xmm7, [rsp+0x70]
00007d516e5d66f7  vmovaps xmm8, [rsp+0x80]
00007d516e5d6700  vmovaps xmm9, [rsp+0x90]
00007d516e5d6709  vmovaps xmm10, [rsp+0xA0]
00007d516e5d6712  vmovaps xmm11, [rsp+0xB0]
00007d516e5d671b  vmovaps xmm12, [rsp+0xC0]
00007d516e5d6724  vmovaps xmm13, [rsp+0xD0]
00007d516e5d672d  vmovaps xmm14, [rsp+0xE0]
00007d516e5d6736  add rsp, 0xF0
00007d516e5d673d  pop r11
00007d516e5d673f  pop r10
00007d516e5d6741  pop r9
00007d516e5d6743  pop r8
00007d516e5d6745  pop rsi
00007d516e5d6746  pop rdi
00007d516e5d6747  pop rdx
00007d516e5d6748  pop rcx
00007d516e5d6749  pop rax
00007d516e5d674a  add rsp, 0x08
00007d516e5d674e  jmp 0x00007D516E5D312B
00007d516e5d6753  sub rsp, 0x08
00007d516e5d6757  push rax
00007d516e5d6758  push rcx
00007d516e5d6759  push rdx
00007d516e5d675a  push rdi
00007d516e5d675b  push rsi
00007d516e5d675c  push r8
00007d516e5d675e  push r9
00007d516e5d6760  push r10
00007d516e5d6762  push r11
00007d516e5d6764  sub rsp, 0xF0
00007d516e5d676b  vmovaps [rsp], xmm0
00007d516e5d6770  vmovaps [rsp+0x10], xmm1
00007d516e5d6776  vmovaps [rsp+0x20], xmm2
00007d516e5d677c  vmovaps [rsp+0x30], xmm3
00007d516e5d6782  vmovaps [rsp+0x40], xmm4
00007d516e5d6788  vmovaps [rsp+0x50], xmm5
00007d516e5d678e  vmovaps [rsp+0x60], xmm7
00007d516e5d6794  vmovaps [rsp+0x70], xmm8
00007d516e5d679a  vmovaps [rsp+0x80], xmm9
00007d516e5d67a3  vmovaps [rsp+0x90], xmm10
00007d516e5d67ac  vmovaps [rsp+0xA0], xmm11
00007d516e5d67b5  vmovaps [rsp+0xB0], xmm12
00007d516e5d67be  vmovaps [rsp+0xC0], xmm13
00007d516e5d67c7  vmovaps [rsp+0xD0], xmm14
00007d516e5d67d0  vmovaps [rsp+0xE0], xmm15
00007d516e5d67d9  sub rsp, 0x30
00007d516e5d67dd  movaps [rsp], xmm6
00007d516e5d67e1  movaps [rsp+0x10], xmm9
00007d516e5d67e7  movaps [rsp+0x20], xmm14
00007d516e5d67ed  lea rdi, [rsp]
00007d516e5d67f1  mov esi, 0x00
00007d516e5d67f6  mov rax, 0x5EE43AF14530
00007d516e5d6800  call rax
00007d516e5d6802  movaps xmm6, [rsp]
00007d516e5d6806  add rsp, 0x30
00007d516e5d680a  vmovaps xmm0, [rsp]
00007d516e5d680f  vmovaps xmm1, [rsp+0x10]
00007d516e5d6815  vmovaps xmm2, [rsp+0x20]
00007d516e5d681b  vmovaps xmm3, [rsp+0x30]
00007d516e5d6821  vmovaps xmm4, [rsp+0x40]
00007d516e5d6827  vmovaps xmm5, [rsp+0x50]
00007d516e5d682d  vmovaps xmm7, [rsp+0x60]
00007d516e5d6833  vmovaps xmm8, [rsp+0x70]
00007d516e5d6839  vmovaps xmm9, [rsp+0x80]
00007d516e5d6842  vmovaps xmm10, [rsp+0x90]
00007d516e5d684b  vmovaps xmm11, [rsp+0xA0]
00007d516e5d6854  vmovaps xmm12, [rsp+0xB0]
00007d516e5d685d  vmovaps xmm13, [rsp+0xC0]
00007d516e5d6866  vmovaps xmm14, [rsp+0xD0]
00007d516e5d686f  vmovaps xmm15, [rsp+0xE0]
00007d516e5d6878  add rsp, 0xF0
00007d516e5d687f  pop r11
00007d516e5d6881  pop r10
00007d516e5d6883  pop r9
00007d516e5d6885  pop r8
00007d516e5d6887  pop rsi
00007d516e5d6888  pop rdi
00007d516e5d6889  pop rdx
00007d516e5d688a  pop rcx
00007d516e5d688b  pop rax
00007d516e5d688c  add rsp, 0x08
00007d516e5d6890  jmp 0x00007D516E5D3153
00007d516e5d6895  sub rsp, 0x08
00007d516e5d6899  push rax
00007d516e5d689a  push rcx
00007d516e5d689b  push rdx
00007d516e5d689c  push rdi
00007d516e5d689d  push rsi
00007d516e5d689e  push r8
00007d516e5d68a0  push r9
00007d516e5d68a2  push r10
00007d516e5d68a4  push r11
00007d516e5d68a6  sub rsp, 0xF0
00007d516e5d68ad  vmovaps [rsp], xmm0
00007d516e5d68b2  vmovaps [rsp+0x10], xmm1
00007d516e5d68b8  vmovaps [rsp+0x20], xmm2
00007d516e5d68be  vmovaps [rsp+0x30], xmm3
00007d516e5d68c4  vmovaps [rsp+0x40], xmm4
00007d516e5d68ca  vmovaps [rsp+0x50], xmm5
00007d516e5d68d0  vmovaps [rsp+0x60], xmm6
00007d516e5d68d6  vmovaps [rsp+0x70], xmm7
00007d516e5d68dc  vmovaps [rsp+0x80], xmm8
00007d516e5d68e5  vmovaps [rsp+0x90], xmm9
00007d516e5d68ee  vmovaps [rsp+0xA0], xmm10
00007d516e5d68f7  vmovaps [rsp+0xB0], xmm11
00007d516e5d6900  vmovaps [rsp+0xC0], xmm12
00007d516e5d6909  vmovaps [rsp+0xD0], xmm13
00007d516e5d6912  vmovaps [rsp+0xE0], xmm15
00007d516e5d691b  sub rsp, 0x30
00007d516e5d691f  movaps [rsp], xmm14
00007d516e5d6924  movaps [rsp+0x10], xmm9
00007d516e5d692a  movaps [rsp+0x20], xmm13
00007d516e5d6930  lea rdi, [rsp]
00007d516e5d6934  mov esi, 0x00
00007d516e5d6939  mov rax, 0x5EE43AF14530
00007d516e5d6943  call rax
00007d516e5d6945  movaps xmm14, [rsp]
00007d516e5d694a  add rsp, 0x30
00007d516e5d694e  vmovaps xmm0, [rsp]
00007d516e5d6953  vmovaps xmm1, [rsp+0x10]
00007d516e5d6959  vmovaps xmm2, [rsp+0x20]
00007d516e5d695f  vmovaps xmm3, [rsp+0x30]
00007d516e5d6965  vmovaps xmm4, [rsp+0x40]
00007d516e5d696b  vmovaps xmm5, [rsp+0x50]
00007d516e5d6971  vmovaps xmm6, [rsp+0x60]
00007d516e5d6977  vmovaps xmm7, [rsp+0x70]
00007d516e5d697d  vmovaps xmm8, [rsp+0x80]
00007d516e5d6986  vmovaps xmm9, [rsp+0x90]
00007d516e5d698f  vmovaps xmm10, [rsp+0xA0]
00007d516e5d6998  vmovaps xmm11, [rsp+0xB0]
00007d516e5d69a1  vmovaps xmm12, [rsp+0xC0]
00007d516e5d69aa  vmovaps xmm13, [rsp+0xD0]
00007d516e5d69b3  vmovaps xmm15, [rsp+0xE0]
00007d516e5d69bc  add rsp, 0xF0
00007d516e5d69c3  pop r11
00007d516e5d69c5  pop r10
00007d516e5d69c7  pop r9
00007d516e5d69c9  pop r8
00007d516e5d69cb  pop rsi
00007d516e5d69cc  pop rdi
00007d516e5d69cd  pop rdx
00007d516e5d69ce  pop rcx
00007d516e5d69cf  pop rax
00007d516e5d69d0  add rsp, 0x08
00007d516e5d69d4  jmp 0x00007D516E5D3176
00007d516e5d69d9  sub rsp, 0x08
00007d516e5d69dd  push rax
00007d516e5d69de  push rcx
00007d516e5d69df  push rdx
00007d516e5d69e0  push rdi
00007d516e5d69e1  push rsi
00007d516e5d69e2  push r8
00007d516e5d69e4  push r9
00007d516e5d69e6  push r10
00007d516e5d69e8  push r11
00007d516e5d69ea  sub rsp, 0xF0
00007d516e5d69f1  vmovaps [rsp], xmm0
00007d516e5d69f6  vmovaps [rsp+0x10], xmm1
00007d516e5d69fc  vmovaps [rsp+0x20], xmm2
00007d516e5d6a02  vmovaps [rsp+0x30], xmm3
00007d516e5d6a08  vmovaps [rsp+0x40], xmm4
00007d516e5d6a0e  vmovaps [rsp+0x50], xmm5
00007d516e5d6a14  vmovaps [rsp+0x60], xmm6
00007d516e5d6a1a  vmovaps [rsp+0x70], xmm7
00007d516e5d6a20  vmovaps [rsp+0x80], xmm8
00007d516e5d6a29  vmovaps [rsp+0x90], xmm9
00007d516e5d6a32  vmovaps [rsp+0xA0], xmm10
00007d516e5d6a3b  vmovaps [rsp+0xB0], xmm11
00007d516e5d6a44  vmovaps [rsp+0xC0], xmm12
00007d516e5d6a4d  vmovaps [rsp+0xD0], xmm14
00007d516e5d6a56  vmovaps [rsp+0xE0], xmm15
00007d516e5d6a5f  sub rsp, 0x30
00007d516e5d6a63  movaps [rsp], xmm13
00007d516e5d6a68  movaps [rsp+0x10], xmm9
00007d516e5d6a6e  movaps [rsp+0x20], xmm10
00007d516e5d6a74  lea rdi, [rsp]
00007d516e5d6a78  mov esi, 0x00
00007d516e5d6a7d  mov rax, 0x5EE43AF14530
00007d516e5d6a87  call rax
00007d516e5d6a89  movaps xmm13, [rsp]
00007d516e5d6a8e  add rsp, 0x30
00007d516e5d6a92  vmovaps xmm0, [rsp]
00007d516e5d6a97  vmovaps xmm1, [rsp+0x10]
00007d516e5d6a9d  vmovaps xmm2, [rsp+0x20]
00007d516e5d6aa3  vmovaps xmm3, [rsp+0x30]
00007d516e5d6aa9  vmovaps xmm4, [rsp+0x40]
00007d516e5d6aaf  vmovaps xmm5, [rsp+0x50]
00007d516e5d6ab5  vmovaps xmm6, [rsp+0x60]
00007d516e5d6abb  vmovaps xmm7, [rsp+0x70]
00007d516e5d6ac1  vmovaps xmm8, [rsp+0x80]
00007d516e5d6aca  vmovaps xmm9, [rsp+0x90]
00007d516e5d6ad3  vmovaps xmm10, [rsp+0xA0]
00007d516e5d6adc  vmovaps xmm11, [rsp+0xB0]
00007d516e5d6ae5  vmovaps xmm12, [rsp+0xC0]
00007d516e5d6aee  vmovaps xmm14, [rsp+0xD0]
00007d516e5d6af7  vmovaps xmm15, [rsp+0xE0]
00007d516e5d6b00  add rsp, 0xF0
00007d516e5d6b07  pop r11
00007d516e5d6b09  pop r10
00007d516e5d6b0b  pop r9
00007d516e5d6b0d  pop r8
00007d516e5d6b0f  pop rsi
00007d516e5d6b10  pop rdi
00007d516e5d6b11  pop rdx
00007d516e5d6b12  pop rcx
00007d516e5d6b13  pop rax
00007d516e5d6b14  add rsp, 0x08
00007d516e5d6b18  jmp 0x00007D516E5D3196
00007d516e5d6b1d  call 0x00007D516E40AFE0
00007d516e5d6b22  jmp 0x00007D516E5D31EB
00007d516e5d6b27  sub rsp, 0x08
00007d516e5d6b2b  push rax
00007d516e5d6b2c  push rcx
00007d516e5d6b2d  push rdx
00007d516e5d6b2e  push rdi
00007d516e5d6b2f  push rsi
00007d516e5d6b30  push r8
00007d516e5d6b32  push r9
00007d516e5d6b34  push r10
00007d516e5d6b36  push r11
00007d516e5d6b38  sub rsp, 0xF0
00007d516e5d6b3f  vmovaps [rsp], xmm0
00007d516e5d6b44  vmovaps [rsp+0x10], xmm1
00007d516e5d6b4a  vmovaps [rsp+0x20], xmm2
00007d516e5d6b50  vmovaps [rsp+0x30], xmm3
00007d516e5d6b56  vmovaps [rsp+0x40], xmm4
00007d516e5d6b5c  vmovaps [rsp+0x50], xmm5
00007d516e5d6b62  vmovaps [rsp+0x60], xmm6
00007d516e5d6b68  vmovaps [rsp+0x70], xmm7
00007d516e5d6b6e  vmovaps [rsp+0x80], xmm8
00007d516e5d6b77  vmovaps [rsp+0x90], xmm10
00007d516e5d6b80  vmovaps [rsp+0xA0], xmm11
00007d516e5d6b89  vmovaps [rsp+0xB0], xmm12
00007d516e5d6b92  vmovaps [rsp+0xC0], xmm13
00007d516e5d6b9b  vmovaps [rsp+0xD0], xmm14
00007d516e5d6ba4  vmovaps [rsp+0xE0], xmm15
00007d516e5d6bad  sub rsp, 0x30
00007d516e5d6bb1  movaps [rsp], xmm9
00007d516e5d6bb6  movaps [rsp+0x10], xmm8
00007d516e5d6bbc  movaps [rsp+0x20], xmm10
00007d516e5d6bc2  lea rdi, [rsp]
00007d516e5d6bc6  mov esi, 0x00
00007d516e5d6bcb  mov rax, 0x5EE43AF14530
00007d516e5d6bd5  call rax
00007d516e5d6bd7  movaps xmm9, [rsp]
00007d516e5d6bdc  add rsp, 0x30
00007d516e5d6be0  vmovaps xmm0, [rsp]
00007d516e5d6be5  vmovaps xmm1, [rsp+0x10]
00007d516e5d6beb  vmovaps xmm2, [rsp+0x20]
00007d516e5d6bf1  vmovaps xmm3, [rsp+0x30]
00007d516e5d6bf7  vmovaps xmm4, [rsp+0x40]
00007d516e5d6bfd  vmovaps xmm5, [rsp+0x50]
00007d516e5d6c03  vmovaps xmm6, [rsp+0x60]
00007d516e5d6c09  vmovaps xmm7, [rsp+0x70]
00007d516e5d6c0f  vmovaps xmm8, [rsp+0x80]
00007d516e5d6c18  vmovaps xmm10, [rsp+0x90]
00007d516e5d6c21  vmovaps xmm11, [rsp+0xA0]
00007d516e5d6c2a  vmovaps xmm12, [rsp+0xB0]
00007d516e5d6c33  vmovaps xmm13, [rsp+0xC0]
00007d516e5d6c3c  vmovaps xmm14, [rsp+0xD0]
00007d516e5d6c45  vmovaps xmm15, [rsp+0xE0]
00007d516e5d6c4e  add rsp, 0xF0
00007d516e5d6c55  pop r11
00007d516e5d6c57  pop r10
00007d516e5d6c59  pop r9
00007d516e5d6c5b  pop r8
00007d516e5d6c5d  pop rsi
00007d516e5d6c5e  pop rdi
00007d516e5d6c5f  pop rdx
00007d516e5d6c60  pop rcx
00007d516e5d6c61  pop rax
00007d516e5d6c62  add rsp, 0x08
00007d516e5d6c66  jmp 0x00007D516E5D321C
00007d516e5d6c6b  sub rsp, 0x08
00007d516e5d6c6f  push rax
00007d516e5d6c70  push rcx
00007d516e5d6c71  push rdx
00007d516e5d6c72  push rdi
00007d516e5d6c73  push rsi
00007d516e5d6c74  push r8
00007d516e5d6c76  push r9
00007d516e5d6c78  push r10
00007d516e5d6c7a  push r11
00007d516e5d6c7c  sub rsp, 0xF0
00007d516e5d6c83  vmovaps [rsp], xmm0
00007d516e5d6c88  vmovaps [rsp+0x10], xmm1
00007d516e5d6c8e  vmovaps [rsp+0x20], xmm2
00007d516e5d6c94  vmovaps [rsp+0x30], xmm3
00007d516e5d6c9a  vmovaps [rsp+0x40], xmm4
00007d516e5d6ca0  vmovaps [rsp+0x50], xmm5
00007d516e5d6ca6  vmovaps [rsp+0x60], xmm6
00007d516e5d6cac  vmovaps [rsp+0x70], xmm7
00007d516e5d6cb2  vmovaps [rsp+0x80], xmm8
00007d516e5d6cbb  vmovaps [rsp+0x90], xmm9
00007d516e5d6cc4  vmovaps [rsp+0xA0], xmm11
00007d516e5d6ccd  vmovaps [rsp+0xB0], xmm12
00007d516e5d6cd6  vmovaps [rsp+0xC0], xmm13
00007d516e5d6cdf  vmovaps [rsp+0xD0], xmm14
00007d516e5d6ce8  vmovaps [rsp+0xE0], xmm15
00007d516e5d6cf1  sub rsp, 0x30
00007d516e5d6cf5  movaps [rsp], xmm10
00007d516e5d6cfa  movaps [rsp+0x10], xmm1
00007d516e5d6cff  movaps [rsp+0x20], xmm11
00007d516e5d6d05  lea rdi, [rsp]
00007d516e5d6d09  mov esi, 0x00
00007d516e5d6d0e  mov rax, 0x5EE43AF14530
00007d516e5d6d18  call rax
00007d516e5d6d1a  movaps xmm10, [rsp]
00007d516e5d6d1f  add rsp, 0x30
00007d516e5d6d23  vmovaps xmm0, [rsp]
00007d516e5d6d28  vmovaps xmm1, [rsp+0x10]
00007d516e5d6d2e  vmovaps xmm2, [rsp+0x20]
00007d516e5d6d34  vmovaps xmm3, [rsp+0x30]
00007d516e5d6d3a  vmovaps xmm4, [rsp+0x40]
00007d516e5d6d40  vmovaps xmm5, [rsp+0x50]
00007d516e5d6d46  vmovaps xmm6, [rsp+0x60]
00007d516e5d6d4c  vmovaps xmm7, [rsp+0x70]
00007d516e5d6d52  vmovaps xmm8, [rsp+0x80]
00007d516e5d6d5b  vmovaps xmm9, [rsp+0x90]
00007d516e5d6d64  vmovaps xmm11, [rsp+0xA0]
00007d516e5d6d6d  vmovaps xmm12, [rsp+0xB0]
00007d516e5d6d76  vmovaps xmm13, [rsp+0xC0]
00007d516e5d6d7f  vmovaps xmm14, [rsp+0xD0]
00007d516e5d6d88  vmovaps xmm15, [rsp+0xE0]
00007d516e5d6d91  add rsp, 0xF0
00007d516e5d6d98  pop r11
00007d516e5d6d9a  pop r10
00007d516e5d6d9c  pop r9
00007d516e5d6d9e  pop r8
00007d516e5d6da0  pop rsi
00007d516e5d6da1  pop rdi
00007d516e5d6da2  pop rdx
00007d516e5d6da3  pop rcx
00007d516e5d6da4  pop rax
00007d516e5d6da5  add rsp, 0x08
00007d516e5d6da9  jmp 0x00007D516E5D3237
00007d516e5d6dae  sub rsp, 0x08
00007d516e5d6db2  push rax
00007d516e5d6db3  push rcx
00007d516e5d6db4  push rdx
00007d516e5d6db5  push rdi
00007d516e5d6db6  push rsi
00007d516e5d6db7  push r8
00007d516e5d6db9  push r9
00007d516e5d6dbb  push r10
00007d516e5d6dbd  push r11
00007d516e5d6dbf  sub rsp, 0xF0
00007d516e5d6dc6  vmovaps [rsp], xmm0
00007d516e5d6dcb  vmovaps [rsp+0x10], xmm2
00007d516e5d6dd1  vmovaps [rsp+0x20], xmm3
00007d516e5d6dd7  vmovaps [rsp+0x30], xmm4
00007d516e5d6ddd  vmovaps [rsp+0x40], xmm5
00007d516e5d6de3  vmovaps [rsp+0x50], xmm6
00007d516e5d6de9  vmovaps [rsp+0x60], xmm7
00007d516e5d6def  vmovaps [rsp+0x70], xmm8
00007d516e5d6df5  vmovaps [rsp+0x80], xmm9
00007d516e5d6dfe  vmovaps [rsp+0x90], xmm10
00007d516e5d6e07  vmovaps [rsp+0xA0], xmm11
00007d516e5d6e10  vmovaps [rsp+0xB0], xmm12
00007d516e5d6e19  vmovaps [rsp+0xC0], xmm13
00007d516e5d6e22  vmovaps [rsp+0xD0], xmm14
00007d516e5d6e2b  vmovaps [rsp+0xE0], xmm15
00007d516e5d6e34  sub rsp, 0x30
00007d516e5d6e38  movaps [rsp], xmm1
00007d516e5d6e3c  movaps [rsp+0x10], xmm15
00007d516e5d6e42  movaps [rsp+0x20], xmm6
00007d516e5d6e47  lea rdi, [rsp]
00007d516e5d6e4b  mov esi, 0x00
00007d516e5d6e50  mov rax, 0x5EE43AF14530
00007d516e5d6e5a  call rax
00007d516e5d6e5c  movaps xmm1, [rsp]
00007d516e5d6e60  add rsp, 0x30
00007d516e5d6e64  vmovaps xmm0, [rsp]
00007d516e5d6e69  vmovaps xmm2, [rsp+0x10]
00007d516e5d6e6f  vmovaps xmm3, [rsp+0x20]
00007d516e5d6e75  vmovaps xmm4, [rsp+0x30]
00007d516e5d6e7b  vmovaps xmm5, [rsp+0x40]
00007d516e5d6e81  vmovaps xmm6, [rsp+0x50]
00007d516e5d6e87  vmovaps xmm7, [rsp+0x60]
00007d516e5d6e8d  vmovaps xmm8, [rsp+0x70]
00007d516e5d6e93  vmovaps xmm9, [rsp+0x80]
00007d516e5d6e9c  vmovaps xmm10, [rsp+0x90]
00007d516e5d6ea5  vmovaps xmm11, [rsp+0xA0]
00007d516e5d6eae  vmovaps xmm12, [rsp+0xB0]
00007d516e5d6eb7  vmovaps xmm13, [rsp+0xC0]
00007d516e5d6ec0  vmovaps xmm14, [rsp+0xD0]
00007d516e5d6ec9  vmovaps xmm15, [rsp+0xE0]
00007d516e5d6ed2  add rsp, 0xF0
00007d516e5d6ed9  pop r11
00007d516e5d6edb  pop r10
00007d516e5d6edd  pop r9
00007d516e5d6edf  pop r8
00007d516e5d6ee1  pop rsi
00007d516e5d6ee2  pop rdi
00007d516e5d6ee3  pop rdx
00007d516e5d6ee4  pop rcx
00007d516e5d6ee5  pop rax
00007d516e5d6ee6  add rsp, 0x08
00007d516e5d6eea  jmp 0x00007D516E5D3250
00007d516e5d6eef  sub rsp, 0x08
00007d516e5d6ef3  push rax
00007d516e5d6ef4  push rcx
00007d516e5d6ef5  push rdx
00007d516e5d6ef6  push rdi
00007d516e5d6ef7  push rsi
00007d516e5d6ef8  push r8
00007d516e5d6efa  push r9
00007d516e5d6efc  push r10
00007d516e5d6efe  push r11
00007d516e5d6f00  sub rsp, 0xF0
00007d516e5d6f07  vmovaps [rsp], xmm0
00007d516e5d6f0c  vmovaps [rsp+0x10], xmm1
00007d516e5d6f12  vmovaps [rsp+0x20], xmm2
00007d516e5d6f18  vmovaps [rsp+0x30], xmm3
00007d516e5d6f1e  vmovaps [rsp+0x40], xmm4
00007d516e5d6f24  vmovaps [rsp+0x50], xmm5
00007d516e5d6f2a  vmovaps [rsp+0x60], xmm6
00007d516e5d6f30  vmovaps [rsp+0x70], xmm7
00007d516e5d6f36  vmovaps [rsp+0x80], xmm8
00007d516e5d6f3f  vmovaps [rsp+0x90], xmm9
00007d516e5d6f48  vmovaps [rsp+0xA0], xmm10
00007d516e5d6f51  vmovaps [rsp+0xB0], xmm12
00007d516e5d6f5a  vmovaps [rsp+0xC0], xmm13
00007d516e5d6f63  vmovaps [rsp+0xD0], xmm14
00007d516e5d6f6c  vmovaps [rsp+0xE0], xmm15
00007d516e5d6f75  sub rsp, 0x30
00007d516e5d6f79  movaps [rsp], xmm11
00007d516e5d6f7e  movaps [rsp+0x10], xmm12
00007d516e5d6f84  movaps [rsp+0x20], xmm15
00007d516e5d6f8a  lea rdi, [rsp]
00007d516e5d6f8e  mov esi, 0x00
00007d516e5d6f93  mov rax, 0x5EE43AF14530
00007d516e5d6f9d  call rax
00007d516e5d6f9f  movaps xmm11, [rsp]
00007d516e5d6fa4  add rsp, 0x30
00007d516e5d6fa8  vmovaps xmm0, [rsp]
00007d516e5d6fad  vmovaps xmm1, [rsp+0x10]
00007d516e5d6fb3  vmovaps xmm2, [rsp+0x20]
00007d516e5d6fb9  vmovaps xmm3, [rsp+0x30]
00007d516e5d6fbf  vmovaps xmm4, [rsp+0x40]
00007d516e5d6fc5  vmovaps xmm5, [rsp+0x50]
00007d516e5d6fcb  vmovaps xmm6, [rsp+0x60]
00007d516e5d6fd1  vmovaps xmm7, [rsp+0x70]
00007d516e5d6fd7  vmovaps xmm8, [rsp+0x80]
00007d516e5d6fe0  vmovaps xmm9, [rsp+0x90]
00007d516e5d6fe9  vmovaps xmm10, [rsp+0xA0]
00007d516e5d6ff2  vmovaps xmm12, [rsp+0xB0]
00007d516e5d6ffb  vmovaps xmm13, [rsp+0xC0]
00007d516e5d7004  vmovaps xmm14, [rsp+0xD0]
00007d516e5d700d  vmovaps xmm15, [rsp+0xE0]
00007d516e5d7016  add rsp, 0xF0
00007d516e5d701d  pop r11
00007d516e5d701f  pop r10
00007d516e5d7021  pop r9
00007d516e5d7023  pop r8
00007d516e5d7025  pop rsi
00007d516e5d7026  pop rdi
00007d516e5d7027  pop rdx
00007d516e5d7028  pop rcx
00007d516e5d7029  pop rax
00007d516e5d702a  add rsp, 0x08
00007d516e5d702e  jmp 0x00007D516E5D327A
00007d516e5d7033  sub rsp, 0x08
00007d516e5d7037  push rax
00007d516e5d7038  push rcx
00007d516e5d7039  push rdx
00007d516e5d703a  push rdi
00007d516e5d703b  push rsi
00007d516e5d703c  push r8
00007d516e5d703e  push r9
00007d516e5d7040  push r10
00007d516e5d7042  push r11
00007d516e5d7044  sub rsp, 0xF0
00007d516e5d704b  vmovaps [rsp], xmm0
00007d516e5d7050  vmovaps [rsp+0x10], xmm1
00007d516e5d7056  vmovaps [rsp+0x20], xmm2
00007d516e5d705c  vmovaps [rsp+0x30], xmm3
00007d516e5d7062  vmovaps [rsp+0x40], xmm4
00007d516e5d7068  vmovaps [rsp+0x50], xmm5
00007d516e5d706e  vmovaps [rsp+0x60], xmm6
00007d516e5d7074  vmovaps [rsp+0x70], xmm7
00007d516e5d707a  vmovaps [rsp+0x80], xmm8
00007d516e5d7083  vmovaps [rsp+0x90], xmm9
00007d516e5d708c  vmovaps [rsp+0xA0], xmm10
00007d516e5d7095  vmovaps [rsp+0xB0], xmm11
00007d516e5d709e  vmovaps [rsp+0xC0], xmm13
00007d516e5d70a7  vmovaps [rsp+0xD0], xmm14
00007d516e5d70b0  vmovaps [rsp+0xE0], xmm15
00007d516e5d70b9  sub rsp, 0x30
00007d516e5d70bd  movaps [rsp], xmm12
00007d516e5d70c2  movaps [rsp+0x10], xmm8
00007d516e5d70c8  movaps [rsp+0x20], xmm15
00007d516e5d70ce  lea rdi, [rsp]
00007d516e5d70d2  mov esi, 0x00
00007d516e5d70d7  mov rax, 0x5EE43AF14530
00007d516e5d70e1  call rax
00007d516e5d70e3  movaps xmm12, [rsp]
00007d516e5d70e8  add rsp, 0x30
00007d516e5d70ec  vmovaps xmm0, [rsp]
00007d516e5d70f1  vmovaps xmm1, [rsp+0x10]
00007d516e5d70f7  vmovaps xmm2, [rsp+0x20]
00007d516e5d70fd  vmovaps xmm3, [rsp+0x30]
00007d516e5d7103  vmovaps xmm4, [rsp+0x40]
00007d516e5d7109  vmovaps xmm5, [rsp+0x50]
00007d516e5d710f  vmovaps xmm6, [rsp+0x60]
00007d516e5d7115  vmovaps xmm7, [rsp+0x70]
00007d516e5d711b  vmovaps xmm8, [rsp+0x80]
00007d516e5d7124  vmovaps xmm9, [rsp+0x90]
00007d516e5d712d  vmovaps xmm10, [rsp+0xA0]
00007d516e5d7136  vmovaps xmm11, [rsp+0xB0]
00007d516e5d713f  vmovaps xmm13, [rsp+0xC0]
00007d516e5d7148  vmovaps xmm14, [rsp+0xD0]
00007d516e5d7151  vmovaps xmm15, [rsp+0xE0]
00007d516e5d715a  add rsp, 0xF0
00007d516e5d7161  pop r11
00007d516e5d7163  pop r10
00007d516e5d7165  pop r9
00007d516e5d7167  pop r8
00007d516e5d7169  pop rsi
00007d516e5d716a  pop rdi
00007d516e5d716b  pop rdx
00007d516e5d716c  pop rcx
00007d516e5d716d  pop rax
00007d516e5d716e  add rsp, 0x08
00007d516e5d7172  jmp 0x00007D516E5D32A9
00007d516e5d7177  sub rsp, 0x08
00007d516e5d717b  push rax
00007d516e5d717c  push rcx
00007d516e5d717d  push rdx
00007d516e5d717e  push rdi
00007d516e5d717f  push rsi
00007d516e5d7180  push r8
00007d516e5d7182  push r9
00007d516e5d7184  push r10
00007d516e5d7186  push r11
00007d516e5d7188  sub rsp, 0xF0
00007d516e5d718f  vmovaps [rsp], xmm0
00007d516e5d7194  vmovaps [rsp+0x10], xmm1
00007d516e5d719a  vmovaps [rsp+0x20], xmm2
00007d516e5d71a0  vmovaps [rsp+0x30], xmm3
00007d516e5d71a6  vmovaps [rsp+0x40], xmm4
00007d516e5d71ac  vmovaps [rsp+0x50], xmm5
00007d516e5d71b2  vmovaps [rsp+0x60], xmm6
00007d516e5d71b8  vmovaps [rsp+0x70], xmm7
00007d516e5d71be  vmovaps [rsp+0x80], xmm9
00007d516e5d71c7  vmovaps [rsp+0x90], xmm10
00007d516e5d71d0  vmovaps [rsp+0xA0], xmm11
00007d516e5d71d9  vmovaps [rsp+0xB0], xmm12
00007d516e5d71e2  vmovaps [rsp+0xC0], xmm13
00007d516e5d71eb  vmovaps [rsp+0xD0], xmm14
00007d516e5d71f4  vmovaps [rsp+0xE0], xmm15
00007d516e5d71fd  sub rsp, 0x30
00007d516e5d7201  movaps [rsp], xmm8
00007d516e5d7206  movaps [rsp+0x10], xmm7
00007d516e5d720b  movaps [rsp+0x20], xmm15
00007d516e5d7211  lea rdi, [rsp]
00007d516e5d7215  mov esi, 0x00
00007d516e5d721a  mov rax, 0x5EE43AF14530
00007d516e5d7224  call rax
00007d516e5d7226  movaps xmm8, [rsp]
00007d516e5d722b  add rsp, 0x30
00007d516e5d722f  vmovaps xmm0, [rsp]
00007d516e5d7234  vmovaps xmm1, [rsp+0x10]
00007d516e5d723a  vmovaps xmm2, [rsp+0x20]
00007d516e5d7240  vmovaps xmm3, [rsp+0x30]
00007d516e5d7246  vmovaps xmm4, [rsp+0x40]
00007d516e5d724c  vmovaps xmm5, [rsp+0x50]
00007d516e5d7252  vmovaps xmm6, [rsp+0x60]
00007d516e5d7258  vmovaps xmm7, [rsp+0x70]
00007d516e5d725e  vmovaps xmm9, [rsp+0x80]
00007d516e5d7267  vmovaps xmm10, [rsp+0x90]
00007d516e5d7270  vmovaps xmm11, [rsp+0xA0]
00007d516e5d7279  vmovaps xmm12, [rsp+0xB0]
00007d516e5d7282  vmovaps xmm13, [rsp+0xC0]
00007d516e5d728b  vmovaps xmm14, [rsp+0xD0]
00007d516e5d7294  vmovaps xmm15, [rsp+0xE0]
00007d516e5d729d  add rsp, 0xF0
00007d516e5d72a4  pop r11
00007d516e5d72a6  pop r10
00007d516e5d72a8  pop r9
00007d516e5d72aa  pop r8
00007d516e5d72ac  pop rsi
00007d516e5d72ad  pop rdi
00007d516e5d72ae  pop rdx
00007d516e5d72af  pop rcx
00007d516e5d72b0  pop rax
00007d516e5d72b1  add rsp, 0x08
00007d516e5d72b5  jmp 0x00007D516E5D32CF
00007d516e5d72ba  sub rsp, 0x08
00007d516e5d72be  push rax
00007d516e5d72bf  push rcx
00007d516e5d72c0  push rdx
00007d516e5d72c1  push rdi
00007d516e5d72c2  push rsi
00007d516e5d72c3  push r8
00007d516e5d72c5  push r9
00007d516e5d72c7  push r10
00007d516e5d72c9  push r11
00007d516e5d72cb  sub rsp, 0xF0
00007d516e5d72d2  vmovaps [rsp], xmm0
00007d516e5d72d7  vmovaps [rsp+0x10], xmm1
00007d516e5d72dd  vmovaps [rsp+0x20], xmm2
00007d516e5d72e3  vmovaps [rsp+0x30], xmm3
00007d516e5d72e9  vmovaps [rsp+0x40], xmm4
00007d516e5d72ef  vmovaps [rsp+0x50], xmm5
00007d516e5d72f5  vmovaps [rsp+0x60], xmm6
00007d516e5d72fb  vmovaps [rsp+0x70], xmm7
00007d516e5d7301  vmovaps [rsp+0x80], xmm8
00007d516e5d730a  vmovaps [rsp+0x90], xmm9
00007d516e5d7313  vmovaps [rsp+0xA0], xmm10
00007d516e5d731c  vmovaps [rsp+0xB0], xmm11
00007d516e5d7325  vmovaps [rsp+0xC0], xmm12
00007d516e5d732e  vmovaps [rsp+0xD0], xmm13
00007d516e5d7337  vmovaps [rsp+0xE0], xmm14
00007d516e5d7340  sub rsp, 0x30
00007d516e5d7344  movaps [rsp], xmm15
00007d516e5d7349  movaps [rsp+0x10], xmm14
00007d516e5d734f  movaps [rsp+0x20], xmm9
00007d516e5d7355  lea rdi, [rsp]
00007d516e5d7359  mov esi, 0x00
00007d516e5d735e  mov rax, 0x5EE43AF14530
00007d516e5d7368  call rax
00007d516e5d736a  movaps xmm15, [rsp]
00007d516e5d736f  add rsp, 0x30
00007d516e5d7373  vmovaps xmm0, [rsp]
00007d516e5d7378  vmovaps xmm1, [rsp+0x10]
00007d516e5d737e  vmovaps xmm2, [rsp+0x20]
00007d516e5d7384  vmovaps xmm3, [rsp+0x30]
00007d516e5d738a  vmovaps xmm4, [rsp+0x40]
00007d516e5d7390  vmovaps xmm5, [rsp+0x50]
00007d516e5d7396  vmovaps xmm6, [rsp+0x60]
00007d516e5d739c  vmovaps xmm7, [rsp+0x70]
00007d516e5d73a2  vmovaps xmm8, [rsp+0x80]
00007d516e5d73ab  vmovaps xmm9, [rsp+0x90]
00007d516e5d73b4  vmovaps xmm10, [rsp+0xA0]
00007d516e5d73bd  vmovaps xmm11, [rsp+0xB0]
00007d516e5d73c6  vmovaps xmm12, [rsp+0xC0]
00007d516e5d73cf  vmovaps xmm13, [rsp+0xD0]
00007d516e5d73d8  vmovaps xmm14, [rsp+0xE0]
00007d516e5d73e1  add rsp, 0xF0
00007d516e5d73e8  pop r11
00007d516e5d73ea  pop r10
00007d516e5d73ec  pop r9
00007d516e5d73ee  pop r8
00007d516e5d73f0  pop rsi
00007d516e5d73f1  pop rdi
00007d516e5d73f2  pop rdx
00007d516e5d73f3  pop rcx
00007d516e5d73f4  pop rax
00007d516e5d73f5  add rsp, 0x08
00007d516e5d73f9  jmp 0x00007D516E5D32E9
00007d516e5d73fe  sub rsp, 0x08
00007d516e5d7402  push rax
00007d516e5d7403  push rcx
00007d516e5d7404  push rdx
00007d516e5d7405  push rdi
00007d516e5d7406  push rsi
00007d516e5d7407  push r8
00007d516e5d7409  push r9
00007d516e5d740b  push r10
00007d516e5d740d  push r11
00007d516e5d740f  sub rsp, 0xF0
00007d516e5d7416  vmovaps [rsp], xmm0
00007d516e5d741b  vmovaps [rsp+0x10], xmm1
00007d516e5d7421  vmovaps [rsp+0x20], xmm2
00007d516e5d7427  vmovaps [rsp+0x30], xmm3
00007d516e5d742d  vmovaps [rsp+0x40], xmm4
00007d516e5d7433  vmovaps [rsp+0x50], xmm5
00007d516e5d7439  vmovaps [rsp+0x60], xmm6
00007d516e5d743f  vmovaps [rsp+0x70], xmm7
00007d516e5d7445  vmovaps [rsp+0x80], xmm8
00007d516e5d744e  vmovaps [rsp+0x90], xmm10
00007d516e5d7457  vmovaps [rsp+0xA0], xmm11
00007d516e5d7460  vmovaps [rsp+0xB0], xmm12
00007d516e5d7469  vmovaps [rsp+0xC0], xmm13
00007d516e5d7472  vmovaps [rsp+0xD0], xmm14
00007d516e5d747b  vmovaps [rsp+0xE0], xmm15
00007d516e5d7484  sub rsp, 0x30
00007d516e5d7488  movaps [rsp], xmm9
00007d516e5d748d  movaps [rsp+0x10], xmm7
00007d516e5d7492  movaps [rsp+0x20], xmm14
00007d516e5d7498  lea rdi, [rsp]
00007d516e5d749c  mov esi, 0x00
00007d516e5d74a1  mov rax, 0x5EE43AF14530
00007d516e5d74ab  call rax
00007d516e5d74ad  movaps xmm9, [rsp]
00007d516e5d74b2  add rsp, 0x30
00007d516e5d74b6  vmovaps xmm0, [rsp]
00007d516e5d74bb  vmovaps xmm1, [rsp+0x10]
00007d516e5d74c1  vmovaps xmm2, [rsp+0x20]
00007d516e5d74c7  vmovaps xmm3, [rsp+0x30]
00007d516e5d74cd  vmovaps xmm4, [rsp+0x40]
00007d516e5d74d3  vmovaps xmm5, [rsp+0x50]
00007d516e5d74d9  vmovaps xmm6, [rsp+0x60]
00007d516e5d74df  vmovaps xmm7, [rsp+0x70]
00007d516e5d74e5  vmovaps xmm8, [rsp+0x80]
00007d516e5d74ee  vmovaps xmm10, [rsp+0x90]
00007d516e5d74f7  vmovaps xmm11, [rsp+0xA0]
00007d516e5d7500  vmovaps xmm12, [rsp+0xB0]
00007d516e5d7509  vmovaps xmm13, [rsp+0xC0]
00007d516e5d7512  vmovaps xmm14, [rsp+0xD0]
00007d516e5d751b  vmovaps xmm15, [rsp+0xE0]
00007d516e5d7524  add rsp, 0xF0
00007d516e5d752b  pop r11
00007d516e5d752d  pop r10
00007d516e5d752f  pop r9
00007d516e5d7531  pop r8
00007d516e5d7533  pop rsi
00007d516e5d7534  pop rdi
00007d516e5d7535  pop rdx
00007d516e5d7536  pop rcx
00007d516e5d7537  pop rax
00007d516e5d7538  add rsp, 0x08
00007d516e5d753c  jmp 0x00007D516E5D3318
00007d516e5d7541  sub rsp, 0x08
00007d516e5d7545  push rax
00007d516e5d7546  push rcx
00007d516e5d7547  push rdx
00007d516e5d7548  push rdi
00007d516e5d7549  push rsi
00007d516e5d754a  push r8
00007d516e5d754c  push r9
00007d516e5d754e  push r10
00007d516e5d7550  push r11
00007d516e5d7552  sub rsp, 0xF0
00007d516e5d7559  vmovaps [rsp], xmm0
00007d516e5d755e  vmovaps [rsp+0x10], xmm1
00007d516e5d7564  vmovaps [rsp+0x20], xmm2
00007d516e5d756a  vmovaps [rsp+0x30], xmm3
00007d516e5d7570  vmovaps [rsp+0x40], xmm4
00007d516e5d7576  vmovaps [rsp+0x50], xmm5
00007d516e5d757c  vmovaps [rsp+0x60], xmm6
00007d516e5d7582  vmovaps [rsp+0x70], xmm7
00007d516e5d7588  vmovaps [rsp+0x80], xmm8
00007d516e5d7591  vmovaps [rsp+0x90], xmm9
00007d516e5d759a  vmovaps [rsp+0xA0], xmm10
00007d516e5d75a3  vmovaps [rsp+0xB0], xmm11
00007d516e5d75ac  vmovaps [rsp+0xC0], xmm12
00007d516e5d75b5  vmovaps [rsp+0xD0], xmm13
00007d516e5d75be  vmovaps [rsp+0xE0], xmm15
00007d516e5d75c7  sub rsp, 0x30
00007d516e5d75cb  movaps [rsp], xmm14
00007d516e5d75d0  movaps [rsp+0x10], xmm13
00007d516e5d75d6  movaps [rsp+0x20], xmm11
00007d516e5d75dc  lea rdi, [rsp]
00007d516e5d75e0  mov esi, 0x00
00007d516e5d75e5  mov rax, 0x5EE43AF14530
00007d516e5d75ef  call rax
00007d516e5d75f1  movaps xmm14, [rsp]
00007d516e5d75f6  add rsp, 0x30
00007d516e5d75fa  vmovaps xmm0, [rsp]
00007d516e5d75ff  vmovaps xmm1, [rsp+0x10]
00007d516e5d7605  vmovaps xmm2, [rsp+0x20]
00007d516e5d760b  vmovaps xmm3, [rsp+0x30]
00007d516e5d7611  vmovaps xmm4, [rsp+0x40]
00007d516e5d7617  vmovaps xmm5, [rsp+0x50]
00007d516e5d761d  vmovaps xmm6, [rsp+0x60]
00007d516e5d7623  vmovaps xmm7, [rsp+0x70]
00007d516e5d7629  vmovaps xmm8, [rsp+0x80]
00007d516e5d7632  vmovaps xmm9, [rsp+0x90]
00007d516e5d763b  vmovaps xmm10, [rsp+0xA0]
00007d516e5d7644  vmovaps xmm11, [rsp+0xB0]
00007d516e5d764d  vmovaps xmm12, [rsp+0xC0]
00007d516e5d7656  vmovaps xmm13, [rsp+0xD0]
00007d516e5d765f  vmovaps xmm15, [rsp+0xE0]
00007d516e5d7668  add rsp, 0xF0
00007d516e5d766f  pop r11
00007d516e5d7671  pop r10
00007d516e5d7673  pop r9
00007d516e5d7675  pop r8
00007d516e5d7677  pop rsi
00007d516e5d7678  pop rdi
00007d516e5d7679  pop rdx
00007d516e5d767a  pop rcx
00007d516e5d767b  pop rax
00007d516e5d767c  add rsp, 0x08
00007d516e5d7680  jmp 0x00007D516E5D3332
00007d516e5d7685  sub rsp, 0x08
00007d516e5d7689  push rax
00007d516e5d768a  push rcx
00007d516e5d768b  push rdx
00007d516e5d768c  push rdi
00007d516e5d768d  push rsi
00007d516e5d768e  push r8
00007d516e5d7690  push r9
00007d516e5d7692  push r10
00007d516e5d7694  push r11
00007d516e5d7696  sub rsp, 0xF0
00007d516e5d769d  vmovaps [rsp], xmm0
00007d516e5d76a2  vmovaps [rsp+0x10], xmm1
00007d516e5d76a8  vmovaps [rsp+0x20], xmm2
00007d516e5d76ae  vmovaps [rsp+0x30], xmm3
00007d516e5d76b4  vmovaps [rsp+0x40], xmm4
00007d516e5d76ba  vmovaps [rsp+0x50], xmm5
00007d516e5d76c0  vmovaps [rsp+0x60], xmm6
00007d516e5d76c6  vmovaps [rsp+0x70], xmm7
00007d516e5d76cc  vmovaps [rsp+0x80], xmm8
00007d516e5d76d5  vmovaps [rsp+0x90], xmm9
00007d516e5d76de  vmovaps [rsp+0xA0], xmm10
00007d516e5d76e7  vmovaps [rsp+0xB0], xmm12
00007d516e5d76f0  vmovaps [rsp+0xC0], xmm13
00007d516e5d76f9  vmovaps [rsp+0xD0], xmm14
00007d516e5d7702  vmovaps [rsp+0xE0], xmm15
00007d516e5d770b  sub rsp, 0x30
00007d516e5d770f  movaps [rsp], xmm11
00007d516e5d7714  movaps [rsp+0x10], xmm7
00007d516e5d7719  movaps [rsp+0x20], xmm13
00007d516e5d771f  lea rdi, [rsp]
00007d516e5d7723  mov esi, 0x00
00007d516e5d7728  mov rax, 0x5EE43AF14530
00007d516e5d7732  call rax
00007d516e5d7734  movaps xmm11, [rsp]
00007d516e5d7739  add rsp, 0x30
00007d516e5d773d  vmovaps xmm0, [rsp]
00007d516e5d7742  vmovaps xmm1, [rsp+0x10]
00007d516e5d7748  vmovaps xmm2, [rsp+0x20]
00007d516e5d774e  vmovaps xmm3, [rsp+0x30]
00007d516e5d7754  vmovaps xmm4, [rsp+0x40]
00007d516e5d775a  vmovaps xmm5, [rsp+0x50]
00007d516e5d7760  vmovaps xmm6, [rsp+0x60]
00007d516e5d7766  vmovaps xmm7, [rsp+0x70]
00007d516e5d776c  vmovaps xmm8, [rsp+0x80]
00007d516e5d7775  vmovaps xmm9, [rsp+0x90]
00007d516e5d777e  vmovaps xmm10, [rsp+0xA0]
00007d516e5d7787  vmovaps xmm12, [rsp+0xB0]
00007d516e5d7790  vmovaps xmm13, [rsp+0xC0]
00007d516e5d7799  vmovaps xmm14, [rsp+0xD0]
00007d516e5d77a2  vmovaps xmm15, [rsp+0xE0]
00007d516e5d77ab  add rsp, 0xF0
00007d516e5d77b2  pop r11
00007d516e5d77b4  pop r10
00007d516e5d77b6  pop r9
00007d516e5d77b8  pop r8
00007d516e5d77ba  pop rsi
00007d516e5d77bb  pop rdi
00007d516e5d77bc  pop rdx
00007d516e5d77bd  pop rcx
00007d516e5d77be  pop rax
00007d516e5d77bf  add rsp, 0x08
00007d516e5d77c3  jmp 0x00007D516E5D335E
00007d516e5d77c8  sub rsp, 0x08
00007d516e5d77cc  push rax
00007d516e5d77cd  push rcx
00007d516e5d77ce  push rdx
00007d516e5d77cf  push rdi
00007d516e5d77d0  push rsi
00007d516e5d77d1  push r8
00007d516e5d77d3  push r9
00007d516e5d77d5  push r10
00007d516e5d77d7  push r11
00007d516e5d77d9  sub rsp, 0xF0
00007d516e5d77e0  vmovaps [rsp], xmm0
00007d516e5d77e5  vmovaps [rsp+0x10], xmm1
00007d516e5d77eb  vmovaps [rsp+0x20], xmm2
00007d516e5d77f1  vmovaps [rsp+0x30], xmm3
00007d516e5d77f7  vmovaps [rsp+0x40], xmm4
00007d516e5d77fd  vmovaps [rsp+0x50], xmm5
00007d516e5d7803  vmovaps [rsp+0x60], xmm6
00007d516e5d7809  vmovaps [rsp+0x70], xmm7
00007d516e5d780f  vmovaps [rsp+0x80], xmm8
00007d516e5d7818  vmovaps [rsp+0x90], xmm9
00007d516e5d7821  vmovaps [rsp+0xA0], xmm10
00007d516e5d782a  vmovaps [rsp+0xB0], xmm11
00007d516e5d7833  vmovaps [rsp+0xC0], xmm12
00007d516e5d783c  vmovaps [rsp+0xD0], xmm14
00007d516e5d7845  vmovaps [rsp+0xE0], xmm15
00007d516e5d784e  sub rsp, 0x30
00007d516e5d7852  movaps [rsp], xmm13
00007d516e5d7857  movaps [rsp+0x10], xmm10
00007d516e5d785d  movaps [rsp+0x20], xmm12
00007d516e5d7863  lea rdi, [rsp]
00007d516e5d7867  mov esi, 0x00
00007d516e5d786c  mov rax, 0x5EE43AF14530
00007d516e5d7876  call rax
00007d516e5d7878  movaps xmm13, [rsp]
00007d516e5d787d  add rsp, 0x30
00007d516e5d7881  vmovaps xmm0, [rsp]
00007d516e5d7886  vmovaps xmm1, [rsp+0x10]
00007d516e5d788c  vmovaps xmm2, [rsp+0x20]
00007d516e5d7892  vmovaps xmm3, [rsp+0x30]
00007d516e5d7898  vmovaps xmm4, [rsp+0x40]
00007d516e5d789e  vmovaps xmm5, [rsp+0x50]
00007d516e5d78a4  vmovaps xmm6, [rsp+0x60]
00007d516e5d78aa  vmovaps xmm7, [rsp+0x70]
00007d516e5d78b0  vmovaps xmm8, [rsp+0x80]
00007d516e5d78b9  vmovaps xmm9, [rsp+0x90]
00007d516e5d78c2  vmovaps xmm10, [rsp+0xA0]
00007d516e5d78cb  vmovaps xmm11, [rsp+0xB0]
00007d516e5d78d4  vmovaps xmm12, [rsp+0xC0]
00007d516e5d78dd  vmovaps xmm14, [rsp+0xD0]
00007d516e5d78e6  vmovaps xmm15, [rsp+0xE0]
00007d516e5d78ef  add rsp, 0xF0
00007d516e5d78f6  pop r11
00007d516e5d78f8  pop r10
00007d516e5d78fa  pop r9
00007d516e5d78fc  pop r8
00007d516e5d78fe  pop rsi
00007d516e5d78ff  pop rdi
00007d516e5d7900  pop rdx
00007d516e5d7901  pop rcx
00007d516e5d7902  pop rax
00007d516e5d7903  add rsp, 0x08
00007d516e5d7907  jmp 0x00007D516E5D3378
00007d516e5d790c  sub rsp, 0x08
00007d516e5d7910  push rax
00007d516e5d7911  push rcx
00007d516e5d7912  push rdx
00007d516e5d7913  push rdi
00007d516e5d7914  push rsi
00007d516e5d7915  push r8
00007d516e5d7917  push r9
00007d516e5d7919  push r10
00007d516e5d791b  push r11
00007d516e5d791d  sub rsp, 0xF0
00007d516e5d7924  vmovaps [rsp], xmm0
00007d516e5d7929  vmovaps [rsp+0x10], xmm1
00007d516e5d792f  vmovaps [rsp+0x20], xmm2
00007d516e5d7935  vmovaps [rsp+0x30], xmm3
00007d516e5d793b  vmovaps [rsp+0x40], xmm4
00007d516e5d7941  vmovaps [rsp+0x50], xmm5
00007d516e5d7947  vmovaps [rsp+0x60], xmm6
00007d516e5d794d  vmovaps [rsp+0x70], xmm7
00007d516e5d7953  vmovaps [rsp+0x80], xmm8
00007d516e5d795c  vmovaps [rsp+0x90], xmm9
00007d516e5d7965  vmovaps [rsp+0xA0], xmm11
00007d516e5d796e  vmovaps [rsp+0xB0], xmm12
00007d516e5d7977  vmovaps [rsp+0xC0], xmm13
00007d516e5d7980  vmovaps [rsp+0xD0], xmm14
00007d516e5d7989  vmovaps [rsp+0xE0], xmm15
00007d516e5d7992  sub rsp, 0x30
00007d516e5d7996  movaps [rsp], xmm10
00007d516e5d799b  movaps [rsp+0x10], xmm7
00007d516e5d79a0  movaps [rsp+0x20], xmm12
00007d516e5d79a6  lea rdi, [rsp]
00007d516e5d79aa  mov esi, 0x00
00007d516e5d79af  mov rax, 0x5EE43AF14530
00007d516e5d79b9  call rax
00007d516e5d79bb  movaps xmm10, [rsp]
00007d516e5d79c0  add rsp, 0x30
00007d516e5d79c4  vmovaps xmm0, [rsp]
00007d516e5d79c9  vmovaps xmm1, [rsp+0x10]
00007d516e5d79cf  vmovaps xmm2, [rsp+0x20]
00007d516e5d79d5  vmovaps xmm3, [rsp+0x30]
00007d516e5d79db  vmovaps xmm4, [rsp+0x40]
00007d516e5d79e1  vmovaps xmm5, [rsp+0x50]
00007d516e5d79e7  vmovaps xmm6, [rsp+0x60]
00007d516e5d79ed  vmovaps xmm7, [rsp+0x70]
00007d516e5d79f3  vmovaps xmm8, [rsp+0x80]
00007d516e5d79fc  vmovaps xmm9, [rsp+0x90]
00007d516e5d7a05  vmovaps xmm11, [rsp+0xA0]
00007d516e5d7a0e  vmovaps xmm12, [rsp+0xB0]
00007d516e5d7a17  vmovaps xmm13, [rsp+0xC0]
00007d516e5d7a20  vmovaps xmm14, [rsp+0xD0]
00007d516e5d7a29  vmovaps xmm15, [rsp+0xE0]
00007d516e5d7a32  add rsp, 0xF0
00007d516e5d7a39  pop r11
00007d516e5d7a3b  pop r10
00007d516e5d7a3d  pop r9
00007d516e5d7a3f  pop r8
00007d516e5d7a41  pop rsi
00007d516e5d7a42  pop rdi
00007d516e5d7a43  pop rdx
00007d516e5d7a44  pop rcx
00007d516e5d7a45  pop rax
00007d516e5d7a46  add rsp, 0x08
00007d516e5d7a4a  jmp 0x00007D516E5D33A4
00007d516e5d7a4f  sub rsp, 0x08
00007d516e5d7a53  push rax
00007d516e5d7a54  push rcx
00007d516e5d7a55  push rdx
00007d516e5d7a56  push rdi
00007d516e5d7a57  push rsi
00007d516e5d7a58  push r8
00007d516e5d7a5a  push r9
00007d516e5d7a5c  push r10
00007d516e5d7a5e  push r11
00007d516e5d7a60  sub rsp, 0xF0
00007d516e5d7a67  vmovaps [rsp], xmm0
00007d516e5d7a6c  vmovaps [rsp+0x10], xmm1
00007d516e5d7a72  vmovaps [rsp+0x20], xmm2
00007d516e5d7a78  vmovaps [rsp+0x30], xmm3
00007d516e5d7a7e  vmovaps [rsp+0x40], xmm4
00007d516e5d7a84  vmovaps [rsp+0x50], xmm5
00007d516e5d7a8a  vmovaps [rsp+0x60], xmm6
00007d516e5d7a90  vmovaps [rsp+0x70], xmm7
00007d516e5d7a96  vmovaps [rsp+0x80], xmm8
00007d516e5d7a9f  vmovaps [rsp+0x90], xmm9
00007d516e5d7aa8  vmovaps [rsp+0xA0], xmm10
00007d516e5d7ab1  vmovaps [rsp+0xB0], xmm11
00007d516e5d7aba  vmovaps [rsp+0xC0], xmm13
00007d516e5d7ac3  vmovaps [rsp+0xD0], xmm14
00007d516e5d7acc  vmovaps [rsp+0xE0], xmm15
00007d516e5d7ad5  sub rsp, 0x30
00007d516e5d7ad9  movaps [rsp], xmm12
00007d516e5d7ade  movaps [rsp+0x10], xmm1
00007d516e5d7ae3  movaps [rsp+0x20], xmm8
00007d516e5d7ae9  lea rdi, [rsp]
00007d516e5d7aed  mov esi, 0x00
00007d516e5d7af2  mov rax, 0x5EE43AF14530
00007d516e5d7afc  call rax
00007d516e5d7afe  movaps xmm12, [rsp]
00007d516e5d7b03  add rsp, 0x30
00007d516e5d7b07  vmovaps xmm0, [rsp]
00007d516e5d7b0c  vmovaps xmm1, [rsp+0x10]
00007d516e5d7b12  vmovaps xmm2, [rsp+0x20]
00007d516e5d7b18  vmovaps xmm3, [rsp+0x30]
00007d516e5d7b1e  vmovaps xmm4, [rsp+0x40]
00007d516e5d7b24  vmovaps xmm5, [rsp+0x50]
00007d516e5d7b2a  vmovaps xmm6, [rsp+0x60]
00007d516e5d7b30  vmovaps xmm7, [rsp+0x70]
00007d516e5d7b36  vmovaps xmm8, [rsp+0x80]
00007d516e5d7b3f  vmovaps xmm9, [rsp+0x90]
00007d516e5d7b48  vmovaps xmm10, [rsp+0xA0]
00007d516e5d7b51  vmovaps xmm11, [rsp+0xB0]
00007d516e5d7b5a  vmovaps xmm13, [rsp+0xC0]
00007d516e5d7b63  vmovaps xmm14, [rsp+0xD0]
00007d516e5d7b6c  vmovaps xmm15, [rsp+0xE0]
00007d516e5d7b75  add rsp, 0xF0
00007d516e5d7b7c  pop r11
00007d516e5d7b7e  pop r10
00007d516e5d7b80  pop r9
00007d516e5d7b82  pop r8
00007d516e5d7b84  pop rsi
00007d516e5d7b85  pop rdi
00007d516e5d7b86  pop rdx
00007d516e5d7b87  pop rcx
00007d516e5d7b88  pop rax
00007d516e5d7b89  add rsp, 0x08
00007d516e5d7b8d  jmp 0x00007D516E5D33BE
00007d516e5d7b92  call 0x00007D516E3FF430
00007d516e5d7b97  jmp 0x00007D516E5D33C8
00007d516e5d7b9c  sub rsp, 0x08
00007d516e5d7ba0  push rax
00007d516e5d7ba1  push rcx
00007d516e5d7ba2  push rdx
00007d516e5d7ba3  push rdi
00007d516e5d7ba4  push rsi
00007d516e5d7ba5  push r8
00007d516e5d7ba7  push r9
00007d516e5d7ba9  push r10
00007d516e5d7bab  push r11
00007d516e5d7bad  sub rsp, 0xF0
00007d516e5d7bb4  vmovaps [rsp], xmm0
00007d516e5d7bb9  vmovaps [rsp+0x10], xmm1
00007d516e5d7bbf  vmovaps [rsp+0x20], xmm2
00007d516e5d7bc5  vmovaps [rsp+0x30], xmm3
00007d516e5d7bcb  vmovaps [rsp+0x40], xmm4
00007d516e5d7bd1  vmovaps [rsp+0x50], xmm5
00007d516e5d7bd7  vmovaps [rsp+0x60], xmm6
00007d516e5d7bdd  vmovaps [rsp+0x70], xmm7
00007d516e5d7be3  vmovaps [rsp+0x80], xmm9
00007d516e5d7bec  vmovaps [rsp+0x90], xmm10
00007d516e5d7bf5  vmovaps [rsp+0xA0], xmm11
00007d516e5d7bfe  vmovaps [rsp+0xB0], xmm12
00007d516e5d7c07  vmovaps [rsp+0xC0], xmm13
00007d516e5d7c10  vmovaps [rsp+0xD0], xmm14
00007d516e5d7c19  vmovaps [rsp+0xE0], xmm15
00007d516e5d7c22  sub rsp, 0x30
00007d516e5d7c26  movaps [rsp], xmm8
00007d516e5d7c2b  movaps [rsp+0x10], xmm15
00007d516e5d7c31  movaps [rsp+0x20], xmm9
00007d516e5d7c37  lea rdi, [rsp]
00007d516e5d7c3b  mov esi, 0x00
00007d516e5d7c40  mov rax, 0x5EE43AF14530
00007d516e5d7c4a  call rax
00007d516e5d7c4c  movaps xmm8, [rsp]
00007d516e5d7c51  add rsp, 0x30
00007d516e5d7c55  vmovaps xmm0, [rsp]
00007d516e5d7c5a  vmovaps xmm1, [rsp+0x10]
00007d516e5d7c60  vmovaps xmm2, [rsp+0x20]
00007d516e5d7c66  vmovaps xmm3, [rsp+0x30]
00007d516e5d7c6c  vmovaps xmm4, [rsp+0x40]
00007d516e5d7c72  vmovaps xmm5, [rsp+0x50]
00007d516e5d7c78  vmovaps xmm6, [rsp+0x60]
00007d516e5d7c7e  vmovaps xmm7, [rsp+0x70]
00007d516e5d7c84  vmovaps xmm9, [rsp+0x80]
00007d516e5d7c8d  vmovaps xmm10, [rsp+0x90]
00007d516e5d7c96  vmovaps xmm11, [rsp+0xA0]
00007d516e5d7c9f  vmovaps xmm12, [rsp+0xB0]
00007d516e5d7ca8  vmovaps xmm13, [rsp+0xC0]
00007d516e5d7cb1  vmovaps xmm14, [rsp+0xD0]
00007d516e5d7cba  vmovaps xmm15, [rsp+0xE0]
00007d516e5d7cc3  add rsp, 0xF0
00007d516e5d7cca  pop r11
00007d516e5d7ccc  pop r10
00007d516e5d7cce  pop r9
00007d516e5d7cd0  pop r8
00007d516e5d7cd2  pop rsi
00007d516e5d7cd3  pop rdi
00007d516e5d7cd4  pop rdx
00007d516e5d7cd5  pop rcx
00007d516e5d7cd6  pop rax
00007d516e5d7cd7  add rsp, 0x08
00007d516e5d7cdb  jmp 0x00007D516E5D33EA
00007d516e5d7ce0  sub rsp, 0x08
00007d516e5d7ce4  push rax
00007d516e5d7ce5  push rcx
00007d516e5d7ce6  push rdx
00007d516e5d7ce7  push rdi
00007d516e5d7ce8  push rsi
00007d516e5d7ce9  push r8
00007d516e5d7ceb  push r9
00007d516e5d7ced  push r10
00007d516e5d7cef  push r11
00007d516e5d7cf1  sub rsp, 0xF0
00007d516e5d7cf8  vmovaps [rsp], xmm0
00007d516e5d7cfd  vmovaps [rsp+0x10], xmm1
00007d516e5d7d03  vmovaps [rsp+0x20], xmm2
00007d516e5d7d09  vmovaps [rsp+0x30], xmm3
00007d516e5d7d0f  vmovaps [rsp+0x40], xmm4
00007d516e5d7d15  vmovaps [rsp+0x50], xmm5
00007d516e5d7d1b  vmovaps [rsp+0x60], xmm6
00007d516e5d7d21  vmovaps [rsp+0x70], xmm7
00007d516e5d7d27  vmovaps [rsp+0x80], xmm8
00007d516e5d7d30  vmovaps [rsp+0x90], xmm10
00007d516e5d7d39  vmovaps [rsp+0xA0], xmm11
00007d516e5d7d42  vmovaps [rsp+0xB0], xmm12
00007d516e5d7d4b  vmovaps [rsp+0xC0], xmm13
00007d516e5d7d54  vmovaps [rsp+0xD0], xmm14
00007d516e5d7d5d  vmovaps [rsp+0xE0], xmm15
00007d516e5d7d66  sub rsp, 0x30
00007d516e5d7d6a  movaps [rsp], xmm9
00007d516e5d7d6f  movaps [rsp+0x10], xmm1
00007d516e5d7d74  movaps [rsp+0x20], xmm15
00007d516e5d7d7a  lea rdi, [rsp]
00007d516e5d7d7e  mov esi, 0x00
00007d516e5d7d83  mov rax, 0x5EE43AF14530
00007d516e5d7d8d  call rax
00007d516e5d7d8f  movaps xmm9, [rsp]
00007d516e5d7d94  add rsp, 0x30
00007d516e5d7d98  vmovaps xmm0, [rsp]
00007d516e5d7d9d  vmovaps xmm1, [rsp+0x10]
00007d516e5d7da3  vmovaps xmm2, [rsp+0x20]
00007d516e5d7da9  vmovaps xmm3, [rsp+0x30]
00007d516e5d7daf  vmovaps xmm4, [rsp+0x40]
00007d516e5d7db5  vmovaps xmm5, [rsp+0x50]
00007d516e5d7dbb  vmovaps xmm6, [rsp+0x60]
00007d516e5d7dc1  vmovaps xmm7, [rsp+0x70]
00007d516e5d7dc7  vmovaps xmm8, [rsp+0x80]
00007d516e5d7dd0  vmovaps xmm10, [rsp+0x90]
00007d516e5d7dd9  vmovaps xmm11, [rsp+0xA0]
00007d516e5d7de2  vmovaps xmm12, [rsp+0xB0]
00007d516e5d7deb  vmovaps xmm13, [rsp+0xC0]
00007d516e5d7df4  vmovaps xmm14, [rsp+0xD0]
00007d516e5d7dfd  vmovaps xmm15, [rsp+0xE0]
00007d516e5d7e06  add rsp, 0xF0
00007d516e5d7e0d  pop r11
00007d516e5d7e0f  pop r10
00007d516e5d7e11  pop r9
00007d516e5d7e13  pop r8
00007d516e5d7e15  pop rsi
00007d516e5d7e16  pop rdi
00007d516e5d7e17  pop rdx
00007d516e5d7e18  pop rcx
00007d516e5d7e19  pop rax
00007d516e5d7e1a  add rsp, 0x08
00007d516e5d7e1e  jmp 0x00007D516E5D3418
00007d516e5d7e23  sub rsp, 0x08
00007d516e5d7e27  push rax
00007d516e5d7e28  push rcx
00007d516e5d7e29  push rdx
00007d516e5d7e2a  push rdi
00007d516e5d7e2b  push rsi
00007d516e5d7e2c  push r8
00007d516e5d7e2e  push r9
00007d516e5d7e30  push r10
00007d516e5d7e32  push r11
00007d516e5d7e34  sub rsp, 0xF0
00007d516e5d7e3b  vmovaps [rsp], xmm0
00007d516e5d7e40  vmovaps [rsp+0x10], xmm1
00007d516e5d7e46  vmovaps [rsp+0x20], xmm2
00007d516e5d7e4c  vmovaps [rsp+0x30], xmm3
00007d516e5d7e52  vmovaps [rsp+0x40], xmm4
00007d516e5d7e58  vmovaps [rsp+0x50], xmm5
00007d516e5d7e5e  vmovaps [rsp+0x60], xmm6
00007d516e5d7e64  vmovaps [rsp+0x70], xmm7
00007d516e5d7e6a  vmovaps [rsp+0x80], xmm8
00007d516e5d7e73  vmovaps [rsp+0x90], xmm9
00007d516e5d7e7c  vmovaps [rsp+0xA0], xmm10
00007d516e5d7e85  vmovaps [rsp+0xB0], xmm11
00007d516e5d7e8e  vmovaps [rsp+0xC0], xmm12
00007d516e5d7e97  vmovaps [rsp+0xD0], xmm13
00007d516e5d7ea0  vmovaps [rsp+0xE0], xmm14
00007d516e5d7ea9  sub rsp, 0x30
00007d516e5d7ead  movaps [rsp], xmm15
00007d516e5d7eb2  movaps [rsp+0x10], xmm4
00007d516e5d7eb7  movaps [rsp+0x20], xmm1
00007d516e5d7ebc  lea rdi, [rsp]
00007d516e5d7ec0  mov esi, 0x00
00007d516e5d7ec5  mov rax, 0x5EE43AF14530
00007d516e5d7ecf  call rax
00007d516e5d7ed1  movaps xmm15, [rsp]
00007d516e5d7ed6  add rsp, 0x30
00007d516e5d7eda  vmovaps xmm0, [rsp]
00007d516e5d7edf  vmovaps xmm1, [rsp+0x10]
00007d516e5d7ee5  vmovaps xmm2, [rsp+0x20]
00007d516e5d7eeb  vmovaps xmm3, [rsp+0x30]
00007d516e5d7ef1  vmovaps xmm4, [rsp+0x40]
00007d516e5d7ef7  vmovaps xmm5, [rsp+0x50]
00007d516e5d7efd  vmovaps xmm6, [rsp+0x60]
00007d516e5d7f03  vmovaps xmm7, [rsp+0x70]
00007d516e5d7f09  vmovaps xmm8, [rsp+0x80]
00007d516e5d7f12  vmovaps xmm9, [rsp+0x90]
00007d516e5d7f1b  vmovaps xmm10, [rsp+0xA0]
00007d516e5d7f24  vmovaps xmm11, [rsp+0xB0]
00007d516e5d7f2d  vmovaps xmm12, [rsp+0xC0]
00007d516e5d7f36  vmovaps xmm13, [rsp+0xD0]
00007d516e5d7f3f  vmovaps xmm14, [rsp+0xE0]
00007d516e5d7f48  add rsp, 0xF0
00007d516e5d7f4f  pop r11
00007d516e5d7f51  pop r10
00007d516e5d7f53  pop r9
00007d516e5d7f55  pop r8
00007d516e5d7f57  pop rsi
00007d516e5d7f58  pop rdi
00007d516e5d7f59  pop rdx
00007d516e5d7f5a  pop rcx
00007d516e5d7f5b  pop rax
00007d516e5d7f5c  add rsp, 0x08
00007d516e5d7f60  jmp 0x00007D516E5D343E
00007d516e5d7f65  sub rsp, 0x08
00007d516e5d7f69  push rax
00007d516e5d7f6a  push rcx
00007d516e5d7f6b  push rdx
00007d516e5d7f6c  push rdi
00007d516e5d7f6d  push rsi
00007d516e5d7f6e  push r8
00007d516e5d7f70  push r9
00007d516e5d7f72  push r10
00007d516e5d7f74  push r11
00007d516e5d7f76  sub rsp, 0xF0
00007d516e5d7f7d  vmovaps [rsp], xmm0
00007d516e5d7f82  vmovaps [rsp+0x10], xmm2
00007d516e5d7f88  vmovaps [rsp+0x20], xmm3
00007d516e5d7f8e  vmovaps [rsp+0x30], xmm4
00007d516e5d7f94  vmovaps [rsp+0x40], xmm5
00007d516e5d7f9a  vmovaps [rsp+0x50], xmm6
00007d516e5d7fa0  vmovaps [rsp+0x60], xmm7
00007d516e5d7fa6  vmovaps [rsp+0x70], xmm8
00007d516e5d7fac  vmovaps [rsp+0x80], xmm9
00007d516e5d7fb5  vmovaps [rsp+0x90], xmm10
00007d516e5d7fbe  vmovaps [rsp+0xA0], xmm11
00007d516e5d7fc7  vmovaps [rsp+0xB0], xmm12
00007d516e5d7fd0  vmovaps [rsp+0xC0], xmm13
00007d516e5d7fd9  vmovaps [rsp+0xD0], xmm14
00007d516e5d7fe2  vmovaps [rsp+0xE0], xmm15
00007d516e5d7feb  sub rsp, 0x30
00007d516e5d7fef  movaps [rsp], xmm1
00007d516e5d7ff3  movaps [rsp+0x10], xmm14
00007d516e5d7ff9  movaps [rsp+0x20], xmm11
00007d516e5d7fff  lea rdi, [rsp]
00007d516e5d8003  mov esi, 0x00
00007d516e5d8008  mov rax, 0x5EE43AF14530
00007d516e5d8012  call rax
00007d516e5d8014  movaps xmm1, [rsp]
00007d516e5d8018  add rsp, 0x30
00007d516e5d801c  vmovaps xmm0, [rsp]
00007d516e5d8021  vmovaps xmm2, [rsp+0x10]
00007d516e5d8027  vmovaps xmm3, [rsp+0x20]
00007d516e5d802d  vmovaps xmm4, [rsp+0x30]
00007d516e5d8033  vmovaps xmm5, [rsp+0x40]
00007d516e5d8039  vmovaps xmm6, [rsp+0x50]
00007d516e5d803f  vmovaps xmm7, [rsp+0x60]
00007d516e5d8045  vmovaps xmm8, [rsp+0x70]
00007d516e5d804b  vmovaps xmm9, [rsp+0x80]
00007d516e5d8054  vmovaps xmm10, [rsp+0x90]
00007d516e5d805d  vmovaps xmm11, [rsp+0xA0]
00007d516e5d8066  vmovaps xmm12, [rsp+0xB0]
00007d516e5d806f  vmovaps xmm13, [rsp+0xC0]
00007d516e5d8078  vmovaps xmm14, [rsp+0xD0]
00007d516e5d8081  vmovaps xmm15, [rsp+0xE0]
00007d516e5d808a  add rsp, 0xF0
00007d516e5d8091  pop r11
00007d516e5d8093  pop r10
00007d516e5d8095  pop r9
00007d516e5d8097  pop r8
00007d516e5d8099  pop rsi
00007d516e5d809a  pop rdi
00007d516e5d809b  pop rdx
00007d516e5d809c  pop rcx
00007d516e5d809d  pop rax
00007d516e5d809e  add rsp, 0x08
00007d516e5d80a2  jmp 0x00007D516E5D345F
00007d516e5d80a7  call 0x00007D516E4E45A0
00007d516e5d80ac  jmp 0x00007D516E5D346D
00007d516e5d80b1  call 0x00007D516E409D70
00007d516e5d80b6  jmp 0x00007D516E5D3477
00007d516e5d80bb  sub rsp, 0x08
00007d516e5d80bf  push rax
00007d516e5d80c0  push rcx
00007d516e5d80c1  push rdx
00007d516e5d80c2  push rdi
00007d516e5d80c3  push rsi
00007d516e5d80c4  push r8
00007d516e5d80c6  push r9
00007d516e5d80c8  push r10
00007d516e5d80ca  push r11
00007d516e5d80cc  sub rsp, 0xF0
00007d516e5d80d3  vmovaps [rsp], xmm0
00007d516e5d80d8  vmovaps [rsp+0x10], xmm1
00007d516e5d80de  vmovaps [rsp+0x20], xmm2
00007d516e5d80e4  vmovaps [rsp+0x30], xmm3
00007d516e5d80ea  vmovaps [rsp+0x40], xmm4
00007d516e5d80f0  vmovaps [rsp+0x50], xmm5
00007d516e5d80f6  vmovaps [rsp+0x60], xmm6
00007d516e5d80fc  vmovaps [rsp+0x70], xmm8
00007d516e5d8102  vmovaps [rsp+0x80], xmm9
00007d516e5d810b  vmovaps [rsp+0x90], xmm10
00007d516e5d8114  vmovaps [rsp+0xA0], xmm11
00007d516e5d811d  vmovaps [rsp+0xB0], xmm12
00007d516e5d8126  vmovaps [rsp+0xC0], xmm13
00007d516e5d812f  vmovaps [rsp+0xD0], xmm14
00007d516e5d8138  vmovaps [rsp+0xE0], xmm15
00007d516e5d8141  sub rsp, 0x30
00007d516e5d8145  movaps [rsp], xmm7
00007d516e5d8149  movaps [rsp+0x10], xmm13
00007d516e5d814f  movaps [rsp+0x20], xmm10
00007d516e5d8155  lea rdi, [rsp]
00007d516e5d8159  mov esi, 0x00
00007d516e5d815e  mov rax, 0x5EE43AF14530
00007d516e5d8168  call rax
00007d516e5d816a  movaps xmm7, [rsp]
00007d516e5d816e  add rsp, 0x30
00007d516e5d8172  vmovaps xmm0, [rsp]
00007d516e5d8177  vmovaps xmm1, [rsp+0x10]
00007d516e5d817d  vmovaps xmm2, [rsp+0x20]
00007d516e5d8183  vmovaps xmm3, [rsp+0x30]
00007d516e5d8189  vmovaps xmm4, [rsp+0x40]
00007d516e5d818f  vmovaps xmm5, [rsp+0x50]
00007d516e5d8195  vmovaps xmm6, [rsp+0x60]
00007d516e5d819b  vmovaps xmm8, [rsp+0x70]
00007d516e5d81a1  vmovaps xmm9, [rsp+0x80]
00007d516e5d81aa  vmovaps xmm10, [rsp+0x90]
00007d516e5d81b3  vmovaps xmm11, [rsp+0xA0]
00007d516e5d81bc  vmovaps xmm12, [rsp+0xB0]
00007d516e5d81c5  vmovaps xmm13, [rsp+0xC0]
00007d516e5d81ce  vmovaps xmm14, [rsp+0xD0]
00007d516e5d81d7  vmovaps xmm15, [rsp+0xE0]
00007d516e5d81e0  add rsp, 0xF0
00007d516e5d81e7  pop r11
00007d516e5d81e9  pop r10
00007d516e5d81eb  pop r9
00007d516e5d81ed  pop r8
00007d516e5d81ef  pop rsi
00007d516e5d81f0  pop rdi
00007d516e5d81f1  pop rdx
00007d516e5d81f2  pop rcx
00007d516e5d81f3  pop rax
00007d516e5d81f4  add rsp, 0x08
00007d516e5d81f8  jmp 0x00007D516E5D3498
00007d516e5d81fd  sub rsp, 0x08
00007d516e5d8201  push rax
00007d516e5d8202  push rcx
00007d516e5d8203  push rdx
00007d516e5d8204  push rdi
00007d516e5d8205  push rsi
00007d516e5d8206  push r8
00007d516e5d8208  push r9
00007d516e5d820a  push r10
00007d516e5d820c  push r11
00007d516e5d820e  sub rsp, 0xF0
00007d516e5d8215  vmovaps [rsp], xmm0
00007d516e5d821a  vmovaps [rsp+0x10], xmm1
00007d516e5d8220  vmovaps [rsp+0x20], xmm2
00007d516e5d8226  vmovaps [rsp+0x30], xmm3
00007d516e5d822c  vmovaps [rsp+0x40], xmm4
00007d516e5d8232  vmovaps [rsp+0x50], xmm5
00007d516e5d8238  vmovaps [rsp+0x60], xmm6
00007d516e5d823e  vmovaps [rsp+0x70], xmm7
00007d516e5d8244  vmovaps [rsp+0x80], xmm8
00007d516e5d824d  vmovaps [rsp+0x90], xmm9
00007d516e5d8256  vmovaps [rsp+0xA0], xmm11
00007d516e5d825f  vmovaps [rsp+0xB0], xmm12
00007d516e5d8268  vmovaps [rsp+0xC0], xmm13
00007d516e5d8271  vmovaps [rsp+0xD0], xmm14
00007d516e5d827a  vmovaps [rsp+0xE0], xmm15
00007d516e5d8283  sub rsp, 0x30
00007d516e5d8287  movaps [rsp], xmm10
00007d516e5d828c  movaps [rsp+0x10], xmm11
00007d516e5d8292  movaps [rsp+0x20], xmm13
00007d516e5d8298  lea rdi, [rsp]
00007d516e5d829c  mov esi, 0x00
00007d516e5d82a1  mov rax, 0x5EE43AF14530
00007d516e5d82ab  call rax
00007d516e5d82ad  movaps xmm10, [rsp]
00007d516e5d82b2  add rsp, 0x30
00007d516e5d82b6  vmovaps xmm0, [rsp]
00007d516e5d82bb  vmovaps xmm1, [rsp+0x10]
00007d516e5d82c1  vmovaps xmm2, [rsp+0x20]
00007d516e5d82c7  vmovaps xmm3, [rsp+0x30]
00007d516e5d82cd  vmovaps xmm4, [rsp+0x40]
00007d516e5d82d3  vmovaps xmm5, [rsp+0x50]
00007d516e5d82d9  vmovaps xmm6, [rsp+0x60]
00007d516e5d82df  vmovaps xmm7, [rsp+0x70]
00007d516e5d82e5  vmovaps xmm8, [rsp+0x80]
00007d516e5d82ee  vmovaps xmm9, [rsp+0x90]
00007d516e5d82f7  vmovaps xmm11, [rsp+0xA0]
00007d516e5d8300  vmovaps xmm12, [rsp+0xB0]
00007d516e5d8309  vmovaps xmm13, [rsp+0xC0]
00007d516e5d8312  vmovaps xmm14, [rsp+0xD0]
00007d516e5d831b  vmovaps xmm15, [rsp+0xE0]
00007d516e5d8324  add rsp, 0xF0
00007d516e5d832b  pop r11
00007d516e5d832d  pop r10
00007d516e5d832f  pop r9
00007d516e5d8331  pop r8
00007d516e5d8333  pop rsi
00007d516e5d8334  pop rdi
00007d516e5d8335  pop rdx
00007d516e5d8336  pop rcx
00007d516e5d8337  pop rax
00007d516e5d8338  add rsp, 0x08
00007d516e5d833c  jmp 0x00007D516E5D34C6
00007d516e5d8341  sub rsp, 0x08
00007d516e5d8345  push rax
00007d516e5d8346  push rcx
00007d516e5d8347  push rdx
00007d516e5d8348  push rdi
00007d516e5d8349  push rsi
00007d516e5d834a  push r8
00007d516e5d834c  push r9
00007d516e5d834e  push r10
00007d516e5d8350  push r11
00007d516e5d8352  sub rsp, 0xF0
00007d516e5d8359  vmovaps [rsp], xmm0
00007d516e5d835e  vmovaps [rsp+0x10], xmm1
00007d516e5d8364  vmovaps [rsp+0x20], xmm2
00007d516e5d836a  vmovaps [rsp+0x30], xmm3
00007d516e5d8370  vmovaps [rsp+0x40], xmm4
00007d516e5d8376  vmovaps [rsp+0x50], xmm5
00007d516e5d837c  vmovaps [rsp+0x60], xmm6
00007d516e5d8382  vmovaps [rsp+0x70], xmm7
00007d516e5d8388  vmovaps [rsp+0x80], xmm8
00007d516e5d8391  vmovaps [rsp+0x90], xmm9
00007d516e5d839a  vmovaps [rsp+0xA0], xmm10
00007d516e5d83a3  vmovaps [rsp+0xB0], xmm12
00007d516e5d83ac  vmovaps [rsp+0xC0], xmm13
00007d516e5d83b5  vmovaps [rsp+0xD0], xmm14
00007d516e5d83be  vmovaps [rsp+0xE0], xmm15
00007d516e5d83c7  sub rsp, 0x30
00007d516e5d83cb  movaps [rsp], xmm11
00007d516e5d83d0  movaps [rsp+0x10], xmm14
00007d516e5d83d6  movaps [rsp+0x20], xmm13
00007d516e5d83dc  lea rdi, [rsp]
00007d516e5d83e0  mov esi, 0x00
00007d516e5d83e5  mov rax, 0x5EE43AF14530
00007d516e5d83ef  call rax
00007d516e5d83f1  movaps xmm11, [rsp]
00007d516e5d83f6  add rsp, 0x30
00007d516e5d83fa  vmovaps xmm0, [rsp]
00007d516e5d83ff  vmovaps xmm1, [rsp+0x10]
00007d516e5d8405  vmovaps xmm2, [rsp+0x20]
00007d516e5d840b  vmovaps xmm3, [rsp+0x30]
00007d516e5d8411  vmovaps xmm4, [rsp+0x40]
00007d516e5d8417  vmovaps xmm5, [rsp+0x50]
00007d516e5d841d  vmovaps xmm6, [rsp+0x60]
00007d516e5d8423  vmovaps xmm7, [rsp+0x70]
00007d516e5d8429  vmovaps xmm8, [rsp+0x80]
00007d516e5d8432  vmovaps xmm9, [rsp+0x90]
00007d516e5d843b  vmovaps xmm10, [rsp+0xA0]
00007d516e5d8444  vmovaps xmm12, [rsp+0xB0]
00007d516e5d844d  vmovaps xmm13, [rsp+0xC0]
00007d516e5d8456  vmovaps xmm14, [rsp+0xD0]
00007d516e5d845f  vmovaps xmm15, [rsp+0xE0]
00007d516e5d8468  add rsp, 0xF0
00007d516e5d846f  pop r11
00007d516e5d8471  pop r10
00007d516e5d8473  pop r9
00007d516e5d8475  pop r8
00007d516e5d8477  pop rsi
00007d516e5d8478  pop rdi
00007d516e5d8479  pop rdx
00007d516e5d847a  pop rcx
00007d516e5d847b  pop rax
00007d516e5d847c  add rsp, 0x08
00007d516e5d8480  jmp 0x00007D516E5D34F4
00007d516e5d8485  sub rsp, 0x08
00007d516e5d8489  push rax
00007d516e5d848a  push rcx
00007d516e5d848b  push rdx
00007d516e5d848c  push rdi
00007d516e5d848d  push rsi
00007d516e5d848e  push r8
00007d516e5d8490  push r9
00007d516e5d8492  push r10
00007d516e5d8494  push r11
00007d516e5d8496  sub rsp, 0xF0
00007d516e5d849d  vmovaps [rsp], xmm0
00007d516e5d84a2  vmovaps [rsp+0x10], xmm1
00007d516e5d84a8  vmovaps [rsp+0x20], xmm2
00007d516e5d84ae  vmovaps [rsp+0x30], xmm3
00007d516e5d84b4  vmovaps [rsp+0x40], xmm4
00007d516e5d84ba  vmovaps [rsp+0x50], xmm5
00007d516e5d84c0  vmovaps [rsp+0x60], xmm6
00007d516e5d84c6  vmovaps [rsp+0x70], xmm7
00007d516e5d84cc  vmovaps [rsp+0x80], xmm8
00007d516e5d84d5  vmovaps [rsp+0x90], xmm9
00007d516e5d84de  vmovaps [rsp+0xA0], xmm10
00007d516e5d84e7  vmovaps [rsp+0xB0], xmm11
00007d516e5d84f0  vmovaps [rsp+0xC0], xmm12
00007d516e5d84f9  vmovaps [rsp+0xD0], xmm13
00007d516e5d8502  vmovaps [rsp+0xE0], xmm15
00007d516e5d850b  sub rsp, 0x30
00007d516e5d850f  movaps [rsp], xmm14
00007d516e5d8514  movaps [rsp+0x10], xmm12
00007d516e5d851a  movaps [rsp+0x20], xmm9
00007d516e5d8520  lea rdi, [rsp]
00007d516e5d8524  mov esi, 0x00
00007d516e5d8529  mov rax, 0x5EE43AF14530
00007d516e5d8533  call rax
00007d516e5d8535  movaps xmm14, [rsp]
00007d516e5d853a  add rsp, 0x30
00007d516e5d853e  vmovaps xmm0, [rsp]
00007d516e5d8543  vmovaps xmm1, [rsp+0x10]
00007d516e5d8549  vmovaps xmm2, [rsp+0x20]
00007d516e5d854f  vmovaps xmm3, [rsp+0x30]
00007d516e5d8555  vmovaps xmm4, [rsp+0x40]
00007d516e5d855b  vmovaps xmm5, [rsp+0x50]
00007d516e5d8561  vmovaps xmm6, [rsp+0x60]
00007d516e5d8567  vmovaps xmm7, [rsp+0x70]
00007d516e5d856d  vmovaps xmm8, [rsp+0x80]
00007d516e5d8576  vmovaps xmm9, [rsp+0x90]
00007d516e5d857f  vmovaps xmm10, [rsp+0xA0]
00007d516e5d8588  vmovaps xmm11, [rsp+0xB0]
00007d516e5d8591  vmovaps xmm12, [rsp+0xC0]
00007d516e5d859a  vmovaps xmm13, [rsp+0xD0]
00007d516e5d85a3  vmovaps xmm15, [rsp+0xE0]
00007d516e5d85ac  add rsp, 0xF0
00007d516e5d85b3  pop r11
00007d516e5d85b5  pop r10
00007d516e5d85b7  pop r9
00007d516e5d85b9  pop r8
00007d516e5d85bb  pop rsi
00007d516e5d85bc  pop rdi
00007d516e5d85bd  pop rdx
00007d516e5d85be  pop rcx
00007d516e5d85bf  pop rax
00007d516e5d85c0  add rsp, 0x08
00007d516e5d85c4  jmp 0x00007D516E5D350F
00007d516e5d85c9  sub rsp, 0x08
00007d516e5d85cd  push rax
00007d516e5d85ce  push rcx
00007d516e5d85cf  push rdx
00007d516e5d85d0  push rdi
00007d516e5d85d1  push rsi
00007d516e5d85d2  push r8
00007d516e5d85d4  push r9
00007d516e5d85d6  push r10
00007d516e5d85d8  push r11
00007d516e5d85da  sub rsp, 0xF0
00007d516e5d85e1  vmovaps [rsp], xmm0
00007d516e5d85e6  vmovaps [rsp+0x10], xmm1
00007d516e5d85ec  vmovaps [rsp+0x20], xmm2
00007d516e5d85f2  vmovaps [rsp+0x30], xmm3
00007d516e5d85f8  vmovaps [rsp+0x40], xmm4
00007d516e5d85fe  vmovaps [rsp+0x50], xmm5
00007d516e5d8604  vmovaps [rsp+0x60], xmm6
00007d516e5d860a  vmovaps [rsp+0x70], xmm7
00007d516e5d8610  vmovaps [rsp+0x80], xmm8
00007d516e5d8619  vmovaps [rsp+0x90], xmm9
00007d516e5d8622  vmovaps [rsp+0xA0], xmm10
00007d516e5d862b  vmovaps [rsp+0xB0], xmm11
00007d516e5d8634  vmovaps [rsp+0xC0], xmm12
00007d516e5d863d  vmovaps [rsp+0xD0], xmm14
00007d516e5d8646  vmovaps [rsp+0xE0], xmm15
00007d516e5d864f  sub rsp, 0x30
00007d516e5d8653  movaps [rsp], xmm13
00007d516e5d8658  movaps [rsp+0x10], xmm8
00007d516e5d865e  movaps [rsp+0x20], xmm15
00007d516e5d8664  lea rdi, [rsp]
00007d516e5d8668  mov esi, 0x00
00007d516e5d866d  mov rax, 0x5EE43AF14530
00007d516e5d8677  call rax
00007d516e5d8679  movaps xmm13, [rsp]
00007d516e5d867e  add rsp, 0x30
00007d516e5d8682  vmovaps xmm0, [rsp]
00007d516e5d8687  vmovaps xmm1, [rsp+0x10]
00007d516e5d868d  vmovaps xmm2, [rsp+0x20]
00007d516e5d8693  vmovaps xmm3, [rsp+0x30]
00007d516e5d8699  vmovaps xmm4, [rsp+0x40]
00007d516e5d869f  vmovaps xmm5, [rsp+0x50]
00007d516e5d86a5  vmovaps xmm6, [rsp+0x60]
00007d516e5d86ab  vmovaps xmm7, [rsp+0x70]
00007d516e5d86b1  vmovaps xmm8, [rsp+0x80]
00007d516e5d86ba  vmovaps xmm9, [rsp+0x90]
00007d516e5d86c3  vmovaps xmm10, [rsp+0xA0]
00007d516e5d86cc  vmovaps xmm11, [rsp+0xB0]
00007d516e5d86d5  vmovaps xmm12, [rsp+0xC0]
00007d516e5d86de  vmovaps xmm14, [rsp+0xD0]
00007d516e5d86e7  vmovaps xmm15, [rsp+0xE0]
00007d516e5d86f0  add rsp, 0xF0
00007d516e5d86f7  pop r11
00007d516e5d86f9  pop r10
00007d516e5d86fb  pop r9
00007d516e5d86fd  pop r8
00007d516e5d86ff  pop rsi
00007d516e5d8700  pop rdi
00007d516e5d8701  pop rdx
00007d516e5d8702  pop rcx
00007d516e5d8703  pop rax
00007d516e5d8704  add rsp, 0x08
00007d516e5d8708  jmp 0x00007D516E5D3532
00007d516e5d870d  sub rsp, 0x08
00007d516e5d8711  push rax
00007d516e5d8712  push rcx
00007d516e5d8713  push rdx
00007d516e5d8714  push rdi
00007d516e5d8715  push rsi
00007d516e5d8716  push r8
00007d516e5d8718  push r9
00007d516e5d871a  push r10
00007d516e5d871c  push r11
00007d516e5d871e  sub rsp, 0xF0
00007d516e5d8725  vmovaps [rsp], xmm0
00007d516e5d872a  vmovaps [rsp+0x10], xmm1
00007d516e5d8730  vmovaps [rsp+0x20], xmm2
00007d516e5d8736  vmovaps [rsp+0x30], xmm3
00007d516e5d873c  vmovaps [rsp+0x40], xmm4
00007d516e5d8742  vmovaps [rsp+0x50], xmm5
00007d516e5d8748  vmovaps [rsp+0x60], xmm6
00007d516e5d874e  vmovaps [rsp+0x70], xmm7
00007d516e5d8754  vmovaps [rsp+0x80], xmm8
00007d516e5d875d  vmovaps [rsp+0x90], xmm9
00007d516e5d8766  vmovaps [rsp+0xA0], xmm10
00007d516e5d876f  vmovaps [rsp+0xB0], xmm11
00007d516e5d8778  vmovaps [rsp+0xC0], xmm12
00007d516e5d8781  vmovaps [rsp+0xD0], xmm13
00007d516e5d878a  vmovaps [rsp+0xE0], xmm14
00007d516e5d8793  sub rsp, 0x30
00007d516e5d8797  movaps [rsp], xmm15
00007d516e5d879c  movaps [rsp+0x10], xmm1
00007d516e5d87a1  movaps [rsp+0x20], xmm10
00007d516e5d87a7  lea rdi, [rsp]
00007d516e5d87ab  mov esi, 0x00
00007d516e5d87b0  mov rax, 0x5EE43AF14530
00007d516e5d87ba  call rax
00007d516e5d87bc  movaps xmm15, [rsp]
00007d516e5d87c1  add rsp, 0x30
00007d516e5d87c5  vmovaps xmm0, [rsp]
00007d516e5d87ca  vmovaps xmm1, [rsp+0x10]
00007d516e5d87d0  vmovaps xmm2, [rsp+0x20]
00007d516e5d87d6  vmovaps xmm3, [rsp+0x30]
00007d516e5d87dc  vmovaps xmm4, [rsp+0x40]
00007d516e5d87e2  vmovaps xmm5, [rsp+0x50]
00007d516e5d87e8  vmovaps xmm6, [rsp+0x60]
00007d516e5d87ee  vmovaps xmm7, [rsp+0x70]
00007d516e5d87f4  vmovaps xmm8, [rsp+0x80]
00007d516e5d87fd  vmovaps xmm9, [rsp+0x90]
00007d516e5d8806  vmovaps xmm10, [rsp+0xA0]
00007d516e5d880f  vmovaps xmm11, [rsp+0xB0]
00007d516e5d8818  vmovaps xmm12, [rsp+0xC0]
00007d516e5d8821  vmovaps xmm13, [rsp+0xD0]
00007d516e5d882a  vmovaps xmm14, [rsp+0xE0]
00007d516e5d8833  add rsp, 0xF0
00007d516e5d883a  pop r11
00007d516e5d883c  pop r10
00007d516e5d883e  pop r9
00007d516e5d8840  pop r8
00007d516e5d8842  pop rsi
00007d516e5d8843  pop rdi
00007d516e5d8844  pop rdx
00007d516e5d8845  pop rcx
00007d516e5d8846  pop rax
00007d516e5d8847  add rsp, 0x08
00007d516e5d884b  jmp 0x00007D516E5D3555
00007d516e5d8850  sub rsp, 0x08
00007d516e5d8854  push rax
00007d516e5d8855  push rcx
00007d516e5d8856  push rdx
00007d516e5d8857  push rdi
00007d516e5d8858  push rsi
00007d516e5d8859  push r8
00007d516e5d885b  push r9
00007d516e5d885d  push r10
00007d516e5d885f  push r11
00007d516e5d8861  sub rsp, 0xF0
00007d516e5d8868  vmovaps [rsp], xmm0
00007d516e5d886d  vmovaps [rsp+0x10], xmm2
00007d516e5d8873  vmovaps [rsp+0x20], xmm3
00007d516e5d8879  vmovaps [rsp+0x30], xmm4
00007d516e5d887f  vmovaps [rsp+0x40], xmm5
00007d516e5d8885  vmovaps [rsp+0x50], xmm6
00007d516e5d888b  vmovaps [rsp+0x60], xmm7
00007d516e5d8891  vmovaps [rsp+0x70], xmm8
00007d516e5d8897  vmovaps [rsp+0x80], xmm9
00007d516e5d88a0  vmovaps [rsp+0x90], xmm10
00007d516e5d88a9  vmovaps [rsp+0xA0], xmm11
00007d516e5d88b2  vmovaps [rsp+0xB0], xmm12
00007d516e5d88bb  vmovaps [rsp+0xC0], xmm13
00007d516e5d88c4  vmovaps [rsp+0xD0], xmm14
00007d516e5d88cd  vmovaps [rsp+0xE0], xmm15
00007d516e5d88d6  sub rsp, 0x30
00007d516e5d88da  movaps [rsp], xmm1
00007d516e5d88de  movaps [rsp+0x10], xmm7
00007d516e5d88e3  movaps [rsp+0x20], xmm11
00007d516e5d88e9  lea rdi, [rsp]
00007d516e5d88ed  mov esi, 0x00
00007d516e5d88f2  mov rax, 0x5EE43AF14530
00007d516e5d88fc  call rax
00007d516e5d88fe  movaps xmm1, [rsp]
00007d516e5d8902  add rsp, 0x30
00007d516e5d8906  vmovaps xmm0, [rsp]
00007d516e5d890b  vmovaps xmm2, [rsp+0x10]
00007d516e5d8911  vmovaps xmm3, [rsp+0x20]
00007d516e5d8917  vmovaps xmm4, [rsp+0x30]
00007d516e5d891d  vmovaps xmm5, [rsp+0x40]
00007d516e5d8923  vmovaps xmm6, [rsp+0x50]
00007d516e5d8929  vmovaps xmm7, [rsp+0x60]
00007d516e5d892f  vmovaps xmm8, [rsp+0x70]
00007d516e5d8935  vmovaps xmm9, [rsp+0x80]
00007d516e5d893e  vmovaps xmm10, [rsp+0x90]
00007d516e5d8947  vmovaps xmm11, [rsp+0xA0]
00007d516e5d8950  vmovaps xmm12, [rsp+0xB0]
00007d516e5d8959  vmovaps xmm13, [rsp+0xC0]
00007d516e5d8962  vmovaps xmm14, [rsp+0xD0]
00007d516e5d896b  vmovaps xmm15, [rsp+0xE0]
00007d516e5d8974  add rsp, 0xF0
00007d516e5d897b  pop r11
00007d516e5d897d  pop r10
00007d516e5d897f  pop r9
00007d516e5d8981  pop r8
00007d516e5d8983  pop rsi
00007d516e5d8984  pop rdi
00007d516e5d8985  pop rdx
00007d516e5d8986  pop rcx
00007d516e5d8987  pop rax
00007d516e5d8988  add rsp, 0x08
00007d516e5d898c  jmp 0x00007D516E5D3576
00007d516e5d8991  call 0x00007D516E40D600
00007d516e5d8996  jmp 0x00007D516E5D3589
00007d516e5d899b  call 0x00007D516E40C380
00007d516e5d89a0  jmp 0x00007D516E5D3594
00007d516e5d89a5  call 0x00007D516E40E880
00007d516e5d89aa  jmp 0x00007D516E5D359F
00007d516e5d89af  call 0x00007D516E3FF540
00007d516e5d89b4  jmp 0x00007D516E5D35AA
00007d516e5d89b9  int3
00007d516e5d89ba  nop [rax+rax*1], ax
00007d516e5d89c0  mov rax, [r15+0x40]
00007d516e5d89c4  mov r14, [r15+0x58]
00007d516e5d89c8  lea r12, [rax+r14*1]
00007d516e5d89cc  movaps xmm1, [r15+0x1D0]
00007d516e5d89d4  vmovaps [rsp+0x10], xmm1
00007d516e5d89da  vmovaps xmm15, [rsp+0x10]
00007d516e5d89e0  por xmm1, xmm15
00007d516e5d89e5  movaps xmm14, [r15+0x1A0]
00007d516e5d89ed  vmovaps [rsp+0x10], xmm14
00007d516e5d89f3  vmovaps xmm13, [rsp+0x10]
00007d516e5d89f9  por xmm14, xmm13
00007d516e5d89fe  lea rax, [r12+0x30]
00007d516e5d8a03  mov r11, [r13+rax*1]
00007d516e5d8a08  lea rax, [r12+0x38]
00007d516e5d8a0d  mov r10, [r13+rax*1]
00007d516e5d8a12  movq xmm13, r11
00007d516e5d8a17  movq xmm12, r10
00007d516e5d8a1c  movq xmm13, xmm13
00007d516e5d8a21  vmovaps [rsp+0x10], xmm13
00007d516e5d8a27  movq xmm13, xmm13
00007d516e5d8a2c  movaps [r15+0x130], xmm13
00007d516e5d8a34  movq xmm12, xmm12
00007d516e5d8a39  vmovaps [rsp+0x20], xmm12
00007d516e5d8a3f  movq xmm12, xmm12
00007d516e5d8a44  movaps [r15+0x280], xmm12
00007d516e5d8a4c  movaps xmm13, [r15+0x270]
00007d516e5d8a54  vmovaps [rsp+0x30], xmm13
00007d516e5d8a5a  vmovaps xmm12, [rsp+0x30]
00007d516e5d8a60  por xmm13, xmm12
00007d516e5d8a65  lea rax, [r12+0x20]
00007d516e5d8a6a  mov r11, [r13+rax*1]
00007d516e5d8a6f  lea rax, [r12+0x28]
00007d516e5d8a74  mov r10, [r13+rax*1]
00007d516e5d8a79  movq xmm12, r11
00007d516e5d8a7e  movq xmm11, r10
00007d516e5d8a83  movq xmm12, xmm12
00007d516e5d8a88  vmovaps [rsp+0x30], xmm12
00007d516e5d8a8e  movq xmm12, xmm12
00007d516e5d8a93  movaps [r15+0x150], xmm12
00007d516e5d8a9b  movq xmm11, xmm11
00007d516e5d8aa0  vmovaps [rsp+0x40], xmm11
00007d516e5d8aa6  movq xmm11, xmm11
00007d516e5d8aab  movaps [r15+0x140], xmm11
00007d516e5d8ab3  lea rax, [r12+0x10]
00007d516e5d8ab8  mov r11, [r13+rax*1]
00007d516e5d8abd  lea rax, [r12+0x18]
00007d516e5d8ac2  mov r10, [r13+rax*1]
00007d516e5d8ac7  movq xmm12, r11
00007d516e5d8acc  movq xmm11, r10
00007d516e5d8ad1  movq xmm12, xmm12
00007d516e5d8ad6  vmovaps [rsp+0x50], xmm12
00007d516e5d8adc  movq xmm12, xmm12
00007d516e5d8ae1  movaps [r15+0x170], xmm12
00007d516e5d8ae9  movq xmm11, xmm11
00007d516e5d8aee  vmovaps [rsp+0x60], xmm11
00007d516e5d8af4  movq xmm11, xmm11
00007d516e5d8af9  movaps [r15+0x160], xmm11
00007d516e5d8b01  mov rax, [r13+r12*1]
00007d516e5d8b06  vmovq xmm12, rax
00007d516e5d8b0b  vpbroadcastq xmm12, xmm12
00007d516e5d8b10  lea rax, [r12+0x08]
00007d516e5d8b15  mov r12, [r13+rax*1]
00007d516e5d8b1a  movq xmm11, r12
00007d516e5d8b1f  movaps [r15+0x230], xmm11
00007d516e5d8b27  mov rax, [r15+0xF8]
00007d516e5d8b2e  lea r12, [rax+0x50]
00007d516e5d8b32  movups xmm11, [r13+r12*1]
00007d516e5d8b38  lea r12, [rax+0x60]
00007d516e5d8b3c  movups xmm10, [r13+r12*1]
00007d516e5d8b42  lea r12, [rax+0x30]
00007d516e5d8b46  movups xmm9, [r13+r12*1]
00007d516e5d8b4c  mov r12, [r15+0x50]
00007d516e5d8b50  lea r11, [r12+r14*1]
00007d516e5d8b54  mov [r15+0x60], r11
00007d516e5d8b58  lea r12, [r14+0x40]
00007d516e5d8b5c  mov [r15+0x58], r12
00007d516e5d8b60  movaps xmm8, xmm12
00007d516e5d8b64  mulpd xmm8, xmm15
00007d516e5d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007d516e5d8b6f  ptest xmm7, xmm7
00007d516e5d8b74  jnz 0x00007D516E5D9997
00007d516e5d8b7a  movq xmm15, qword ptr [r15+0x230]
00007d516e5d8b83  vmovaps [rsp+0x70], xmm15
00007d516e5d8b89  vpermilpd xmm15, xmm15, 0x00
00007d516e5d8b8f  movaps xmm7, xmm9
00007d516e5d8b93  mulpd xmm7, xmm15
00007d516e5d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007d516e5d8b9d  ptest xmm6, xmm6
00007d516e5d8ba2  jnz 0x00007D516E5D9ADB
00007d516e5d8ba8  vxorps xmm15, xmm15, xmm15
00007d516e5d8bad  vpbroadcastq xmm15, xmm15
00007d516e5d8bb2  movaps xmm9, xmm12
00007d516e5d8bb6  mulpd xmm9, xmm10
00007d516e5d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007d516e5d8bc1  ptest xmm6, xmm6
00007d516e5d8bc6  jnz 0x00007D516E5D9C1D
00007d516e5d8bcc  movaps xmm10, xmm12
00007d516e5d8bd0  mulpd xmm10, xmm11
00007d516e5d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d516e5d8bdb  ptest xmm6, xmm6
00007d516e5d8be0  jnz 0x00007D516E5D9D61
00007d516e5d8be6  movaps xmm11, [r15+0x1F0]
00007d516e5d8bee  movaps xmm6, xmm12
00007d516e5d8bf2  mulpd xmm6, xmm11
00007d516e5d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007d516e5d8bfc  ptest xmm5, xmm5
00007d516e5d8c01  jnz 0x00007D516E5D9EA5
00007d516e5d8c07  movaps xmm12, [r15+0x2A0]
00007d516e5d8c0f  vmovaps [rsp+0x80], xmm12
00007d516e5d8c18  vmovaps xmm11, [rsp+0x80]
00007d516e5d8c21  por xmm12, xmm11
00007d516e5d8c26  movaps xmm11, [r15+0x250]
00007d516e5d8c2e  vmovaps [rsp+0x80], xmm11
00007d516e5d8c37  vmovaps xmm5, [rsp+0x80]
00007d516e5d8c40  por xmm11, xmm5
00007d516e5d8c45  vmovaps xmm4, [rsp+0x70]
00007d516e5d8c4b  vpermilpd xmm4, xmm4, 0x00
00007d516e5d8c51  movaps xmm3, xmm5
00007d516e5d8c54  mulpd xmm3, xmm4
00007d516e5d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007d516e5d8c5d  ptest xmm2, xmm2
00007d516e5d8c62  jnz 0x00007D516E5D9FE7
00007d516e5d8c68  mov [rsp+0x80], rax
00007d516e5d8c70  xor eax, eax
00007d516e5d8c72  mov r14d, 0x200
00007d516e5d8c78  cmp r12, r14
00007d516e5d8c7b  cmc
00007d516e5d8c7c  lahf
00007d516e5d8c7d  seto al
00007d516e5d8c80  mov [r15+0x108], eax
00007d516e5d8c87  movaps xmm5, xmm8
00007d516e5d8c8b  addpd xmm5, xmm15
00007d516e5d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007d516e5d8c95  ptest xmm4, xmm4
00007d516e5d8c9a  jnz 0x00007D516E5DA127
00007d516e5d8ca0  movaps xmm8, [r15+0x1B0]
00007d516e5d8ca8  movaps xmm4, xmm9
00007d516e5d8cac  addpd xmm4, xmm8
00007d516e5d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d516e5d8cb6  ptest xmm2, xmm2
00007d516e5d8cbb  jnz 0x00007D516E5DA269
00007d516e5d8cc1  movaps xmm9, xmm10
00007d516e5d8cc5  addpd xmm9, xmm8
00007d516e5d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007d516e5d8cd0  ptest xmm2, xmm2
00007d516e5d8cd5  jnz 0x00007D516E5DA3AB
00007d516e5d8cdb  movaps xmm10, [r15+0x2F0]
00007d516e5d8ce3  vmovaps [rsp+0x90], xmm10
00007d516e5d8cec  vmovaps xmm8, [rsp+0x90]
00007d516e5d8cf5  por xmm10, xmm8
00007d516e5d8cfa  movaps xmm8, [r15+0x2E0]
00007d516e5d8d02  vmovaps [rsp+0x90], xmm8
00007d516e5d8d0b  vmovaps xmm2, [rsp+0x90]
00007d516e5d8d14  por xmm8, xmm2
00007d516e5d8d19  movaps xmm2, [r15+0x2D0]
00007d516e5d8d21  vmovaps [rsp+0x90], xmm2
00007d516e5d8d2a  vmovaps [rsp+0xA0], xmm1
00007d516e5d8d33  vmovaps xmm1, [rsp+0x90]
00007d516e5d8d3c  por xmm2, xmm1
00007d516e5d8d40  movaps xmm1, [r15+0x200]
00007d516e5d8d48  vmovaps [rsp+0x90], xmm1
00007d516e5d8d51  vmovaps [rsp+0xB0], xmm15
00007d516e5d8d5a  vmovaps xmm15, [rsp+0x90]
00007d516e5d8d63  por xmm1, xmm15
00007d516e5d8d68  movaps xmm15, [r15+0x1C0]
00007d516e5d8d70  vmovaps [rsp+0x90], xmm15
00007d516e5d8d79  vmovaps [rsp+0xC0], xmm1
00007d516e5d8d82  vmovaps xmm1, [rsp+0x90]
00007d516e5d8d8b  por xmm15, xmm1
00007d516e5d8d90  movaps xmm1, [r15+0x190]
00007d516e5d8d98  vmovaps [rsp+0x90], xmm1
00007d516e5d8da1  vmovaps [rsp+0xD0], xmm15
00007d516e5d8daa  vmovaps xmm15, [rsp+0x90]
00007d516e5d8db3  por xmm1, xmm15
00007d516e5d8db8  movaps xmm15, [r15+0x300]
00007d516e5d8dc0  vmovaps [rsp+0x90], xmm15
00007d516e5d8dc9  vmovaps [rsp+0xE0], xmm1
00007d516e5d8dd2  vmovaps xmm1, [rsp+0x90]
00007d516e5d8ddb  por xmm15, xmm1
00007d516e5d8de0  mov rax, [rsp+0x80]
00007d516e5d8de8  lea r14, [rax+0xA0]
00007d516e5d8def  movups xmm1, [r13+r14*1]
00007d516e5d8df5  lea r14, [rax+0xB0]
00007d516e5d8dfc  vmovaps [rsp+0x80], xmm1
00007d516e5d8e05  movups xmm1, [r13+r14*1]
00007d516e5d8e0b  vmovaps [rsp+0x90], xmm1
00007d516e5d8e14  vmovaps [rsp+0xF0], xmm15
00007d516e5d8e1d  vmovaps xmm15, [rsp+0xB0]
00007d516e5d8e26  vmovaps [rsp+0xB0], xmm14
00007d516e5d8e2f  movaps xmm1, xmm6
00007d516e5d8e32  addpd xmm1, xmm15
00007d516e5d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007d516e5d8e3c  ptest xmm14, xmm14
00007d516e5d8e42  jnz 0x00007D516E5DA503
00007d516e5d8e48  lea r14, [rax+0xF0]
00007d516e5d8e4f  movups xmm15, [r13+r14*1]
00007d516e5d8e55  movaps xmm14, xmm4
00007d516e5d8e59  addpd xmm14, xmm3
00007d516e5d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d516e5d8e64  ptest xmm6, xmm6
00007d516e5d8e69  jnz 0x00007D516E5DA64E
00007d516e5d8e6f  movaps xmm6, xmm9
00007d516e5d8e73  addpd xmm6, xmm7
00007d516e5d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007d516e5d8e7c  ptest xmm4, xmm4
00007d516e5d8e81  jnz 0x00007D516E5DA790
00007d516e5d8e87  vmovaps xmm9, [rsp+0x70]
00007d516e5d8e8d  vpermilpd xmm9, xmm9, 0x00
00007d516e5d8e93  vmovaps xmm4, [rsp+0x90]
00007d516e5d8e9c  movaps xmm7, xmm4
00007d516e5d8e9f  mulpd xmm7, xmm9
00007d516e5d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d516e5d8ea9  ptest xmm3, xmm3
00007d516e5d8eae  jnz 0x00007D516E5DA8D1
00007d516e5d8eb4  vmovaps xmm9, [rsp+0x50]
00007d516e5d8eba  vpermilpd xmm9, xmm9, 0x00
00007d516e5d8ec0  movaps xmm4, xmm15
00007d516e5d8ec4  mulpd xmm4, xmm9
00007d516e5d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d516e5d8ece  ptest xmm3, xmm3
00007d516e5d8ed3  jnz 0x00007D516E5DAA12
00007d516e5d8ed9  lea r14, [rax+0xE0]
00007d516e5d8ee0  movups xmm15, [r13+r14*1]
00007d516e5d8ee6  vmovaps xmm9, [rsp+0x70]
00007d516e5d8eec  vpermilpd xmm9, xmm9, 0x00
00007d516e5d8ef2  vmovaps [rsp+0x70], xmm1
00007d516e5d8ef8  vmovaps xmm1, [rsp+0x80]
00007d516e5d8f01  vmovaps [rsp+0x80], xmm15
00007d516e5d8f0a  movaps xmm3, xmm1
00007d516e5d8f0d  mulpd xmm3, xmm9
00007d516e5d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007d516e5d8f17  ptest xmm15, xmm15
00007d516e5d8f1d  jnz 0x00007D516E5DAB5E
00007d516e5d8f23  vmovaps xmm1, [rsp+0xF0]
00007d516e5d8f2c  vmovaps xmm15, [rsp+0xF0]
00007d516e5d8f35  por xmm1, xmm15
00007d516e5d8f3a  movaps [r15+0x300], xmm1
00007d516e5d8f42  vmovaps xmm15, [rsp+0xE0]
00007d516e5d8f4b  vmovaps xmm9, [rsp+0xE0]
00007d516e5d8f54  por xmm15, xmm9
00007d516e5d8f59  movaps [r15+0x190], xmm15
00007d516e5d8f61  vmovaps xmm9, [rsp+0x50]
00007d516e5d8f67  vpermilpd xmm9, xmm9, 0x00
00007d516e5d8f6d  vmovaps [rsp+0x90], xmm1
00007d516e5d8f76  vmovaps [rsp+0xE0], xmm15
00007d516e5d8f7f  vmovaps xmm15, [rsp+0x80]
00007d516e5d8f88  vmovaps [rsp+0x80], xmm14
00007d516e5d8f91  movaps xmm1, xmm15
00007d516e5d8f95  mulpd xmm1, xmm9
00007d516e5d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d516e5d8f9f  ptest xmm14, xmm14
00007d516e5d8fa5  jnz 0x00007D516E5DAC9F
00007d516e5d8fab  lea r14, [rax+0x90]
00007d516e5d8fb2  movups xmm15, [r13+r14*1]
00007d516e5d8fb8  vmovaps xmm14, [rsp+0xD0]
00007d516e5d8fc1  vmovaps xmm9, [rsp+0xD0]
00007d516e5d8fca  por xmm14, xmm9
00007d516e5d8fcf  movaps [r15+0x1C0], xmm14
00007d516e5d8fd7  vmovaps xmm9, [rsp+0xC0]
00007d516e5d8fe0  vmovaps [rsp+0xD0], xmm1
00007d516e5d8fe9  vmovaps xmm1, [rsp+0xC0]
00007d516e5d8ff2  por xmm9, xmm1
00007d516e5d8ff7  movaps [r15+0x200], xmm9
00007d516e5d8fff  vmovaps [rsp+0xC0], xmm2
00007d516e5d9008  vmovaps xmm1, [rsp+0xC0]
00007d516e5d9011  por xmm2, xmm1
00007d516e5d9015  movaps [r15+0x2D0], xmm2
00007d516e5d901d  vmovaps [rsp+0xC0], xmm8
00007d516e5d9026  vmovaps xmm1, [rsp+0xC0]
00007d516e5d902f  por xmm8, xmm1
00007d516e5d9034  movaps [r15+0x2E0], xmm8
00007d516e5d903c  vmovaps [rsp+0xC0], xmm15
00007d516e5d9045  movaps xmm1, xmm5
00007d516e5d9048  addpd xmm1, xmm7
00007d516e5d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d516e5d9051  ptest xmm15, xmm15
00007d516e5d9057  jnz 0x00007D516E5DADEB
00007d516e5d905d  vmovaps xmm15, [rsp+0x50]
00007d516e5d9063  vpermilpd xmm15, xmm15, 0x00
00007d516e5d9069  vmovaps xmm5, [rsp+0xC0]
00007d516e5d9072  vmovaps [rsp+0xC0], xmm1
00007d516e5d907b  movaps xmm7, xmm5
00007d516e5d907e  mulpd xmm7, xmm15
00007d516e5d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007d516e5d9088  ptest xmm1, xmm1
00007d516e5d908d  jnz 0x00007D516E5DAF2B
00007d516e5d9093  lea r14, [rax+0x80]
00007d516e5d909a  movups xmm1, [r13+r14*1]
00007d516e5d90a0  vmovaps xmm5, [rsp+0x70]
00007d516e5d90a6  vmovaps [rsp+0x70], xmm1
00007d516e5d90ac  movaps xmm15, xmm5
00007d516e5d90b0  addpd xmm15, xmm3
00007d516e5d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d516e5d90bb  ptest xmm1, xmm1
00007d516e5d90c0  jnz 0x00007D516E5DB076
00007d516e5d90c6  vmovaps xmm5, [rsp+0x80]
00007d516e5d90cf  movaps xmm1, xmm5
00007d516e5d90d2  addpd xmm1, xmm4
00007d516e5d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d516e5d90db  ptest xmm3, xmm3
00007d516e5d90e0  jnz 0x00007D516E5DB1B8
00007d516e5d90e6  vmovaps [rsp+0x80], xmm10
00007d516e5d90ef  vmovaps xmm5, [rsp+0x80]
00007d516e5d90f8  por xmm10, xmm5
00007d516e5d90fd  movaps [r15+0x2F0], xmm10
00007d516e5d9105  vmovaps xmm5, [rsp+0x50]
00007d516e5d910b  vpermilpd xmm5, xmm5, 0x00
00007d516e5d9111  vmovaps xmm3, [rsp+0x70]
00007d516e5d9117  vmovaps [rsp+0x50], xmm1
00007d516e5d911d  movaps xmm4, xmm3
00007d516e5d9120  mulpd xmm4, xmm5
00007d516e5d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007d516e5d9129  ptest xmm1, xmm1
00007d516e5d912e  jnz 0x00007D516E5DB2F8
00007d516e5d9134  lea r14, [rax+0xD0]
00007d516e5d913b  movups xmm1, [r13+r14*1]
00007d516e5d9141  vmovaps xmm3, [rsp+0xD0]
00007d516e5d914a  vmovaps [rsp+0x70], xmm1
00007d516e5d9150  movaps xmm5, xmm6
00007d516e5d9153  addpd xmm5, xmm3
00007d516e5d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007d516e5d915c  ptest xmm1, xmm1
00007d516e5d9161  jnz 0x00007D516E5DB442
00007d516e5d9167  vmovaps xmm1, [rsp+0x60]
00007d516e5d916d  vpermilpd xmm1, xmm1, 0x00
00007d516e5d9173  movaps xmm6, xmm9
00007d516e5d9177  mulpd xmm6, xmm1
00007d516e5d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d516e5d9180  ptest xmm3, xmm3
00007d516e5d9185  jnz 0x00007D516E5DB582
00007d516e5d918b  movaps [r15+0x260], xmm6
00007d516e5d9193  vxorps xmm1, xmm1, xmm1
00007d516e5d9197  vpbroadcastq xmm1, xmm1
00007d516e5d919c  movaps [r15+0x1B0], xmm1
00007d516e5d91a4  vmovaps xmm1, [rsp+0x60]
00007d516e5d91aa  vpermilpd xmm1, xmm1, 0x00
00007d516e5d91b0  vmovaps xmm3, [rsp+0x70]
00007d516e5d91b6  vmovaps [rsp+0x70], xmm15
00007d516e5d91bc  movaps xmm9, xmm3
00007d516e5d91c0  mulpd xmm9, xmm1
00007d516e5d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d516e5d91cb  ptest xmm15, xmm15
00007d516e5d91d1  jnz 0x00007D516E5DB6C3
00007d516e5d91d7  lea r14, [rax+0xC0]
00007d516e5d91de  movups xmm1, [r13+r14*1]
00007d516e5d91e4  vmovaps xmm3, [rsp+0xC0]
00007d516e5d91ed  vmovaps [rsp+0x80], xmm1
00007d516e5d91f6  movaps xmm15, xmm3
00007d516e5d91fa  addpd xmm15, xmm7
00007d516e5d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007d516e5d9205  ptest xmm1, xmm1
00007d516e5d920a  jnz 0x00007D516E5DB80F
00007d516e5d9210  vmovaps [rsp+0xC0], xmm13
00007d516e5d9219  vmovaps xmm1, [rsp+0xC0]
00007d516e5d9222  por xmm13, xmm1
00007d516e5d9227  movaps [r15+0x270], xmm13
00007d516e5d922f  vmovaps xmm1, [rsp+0xB0]
00007d516e5d9238  vmovaps xmm7, [rsp+0xB0]
00007d516e5d9241  por xmm1, xmm7
00007d516e5d9245  movaps [r15+0x1A0], xmm1
00007d516e5d924d  vmovaps xmm1, [rsp+0x60]
00007d516e5d9253  vpermilpd xmm1, xmm1, 0x00
00007d516e5d9259  vmovaps [rsp+0xB0], xmm1
00007d516e5d9262  vmovaps xmm1, [rsp+0x80]
00007d516e5d926b  vmovaps [rsp+0x80], xmm15
00007d516e5d9274  vmovaps xmm15, [rsp+0xB0]
00007d516e5d927d  vmovaps [rsp+0xB0], xmm14
00007d516e5d9286  movaps xmm3, xmm1
00007d516e5d9289  mulpd xmm3, xmm15
00007d516e5d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007d516e5d9293  ptest xmm14, xmm14
00007d516e5d9299  jnz 0x00007D516E5DB951
00007d516e5d929f  lea r14, [rax+0x20]
00007d516e5d92a3  movups xmm1, [r13+r14*1]
00007d516e5d92a9  movaps [r15+0x110], xmm1
00007d516e5d92b1  vmovaps xmm14, [rsp+0x70]
00007d516e5d92b7  vmovaps [rsp+0x70], xmm1
00007d516e5d92bd  movaps xmm15, xmm14
00007d516e5d92c1  addpd xmm15, xmm4
00007d516e5d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d516e5d92cc  ptest xmm1, xmm1
00007d516e5d92d1  jnz 0x00007D516E5DBA9C
00007d516e5d92d7  vmovaps xmm1, [rsp+0x60]
00007d516e5d92dd  vpermilpd xmm1, xmm1, 0x00
00007d516e5d92e3  movaps xmm14, xmm2
00007d516e5d92e7  mulpd xmm14, xmm1
00007d516e5d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007d516e5d92f2  ptest xmm4, xmm4
00007d516e5d92f7  jnz 0x00007D516E5DBBDF
00007d516e5d92fd  vmovaps xmm4, [rsp+0x50]
00007d516e5d9303  movaps xmm1, xmm4
00007d516e5d9306  addpd xmm1, xmm9
00007d516e5d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d516e5d9310  ptest xmm2, xmm2
00007d516e5d9315  jnz 0x00007D516E5DBD21
00007d516e5d931b  vmovaps xmm9, [rsp+0x30]
00007d516e5d9321  vpermilpd xmm9, xmm9, 0x00
00007d516e5d9327  vmovaps xmm2, [rsp+0x70]
00007d516e5d932d  vmovaps [rsp+0x50], xmm1
00007d516e5d9333  movaps xmm4, xmm2
00007d516e5d9336  mulpd xmm4, xmm9
00007d516e5d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d516e5d9340  ptest xmm1, xmm1
00007d516e5d9345  jnz 0x00007D516E5DBE62
00007d516e5d934b  vmovaps xmm1, [rsp+0x30]
00007d516e5d9351  vpermilpd xmm1, xmm1, 0x00
00007d516e5d9357  vmovaps xmm2, [rsp+0x90]
00007d516e5d9360  vmovaps [rsp+0x60], xmm15
00007d516e5d9366  movaps xmm9, xmm2
00007d516e5d936a  mulpd xmm9, xmm1
00007d516e5d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d516e5d9375  ptest xmm15, xmm15
00007d516e5d937b  jnz 0x00007D516E5DBFA3
00007d516e5d9381  vmovaps xmm15, [rsp+0x80]
00007d516e5d938a  movaps xmm1, xmm15
00007d516e5d938e  addpd xmm1, xmm6
00007d516e5d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007d516e5d9397  ptest xmm2, xmm2
00007d516e5d939c  jnz 0x00007D516E5DC0E5
00007d516e5d93a2  movaps xmm15, xmm5
00007d516e5d93a6  addpd xmm15, xmm3
00007d516e5d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007d516e5d93b1  ptest xmm6, xmm6
00007d516e5d93b6  jnz 0x00007D516E5DC226
00007d516e5d93bc  vmovaps xmm6, [rsp+0x30]
00007d516e5d93c2  vpermilpd xmm6, xmm6, 0x00
00007d516e5d93c8  movaps xmm5, xmm8
00007d516e5d93cc  mulpd xmm5, xmm6
00007d516e5d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d516e5d93d5  ptest xmm3, xmm3
00007d516e5d93da  jnz 0x00007D516E5DC368
00007d516e5d93e0  vmovaps xmm8, [rsp+0x30]
00007d516e5d93e6  vpermilpd xmm8, xmm8, 0x00
00007d516e5d93ec  movaps xmm6, xmm10
00007d516e5d93f0  mulpd xmm6, xmm8
00007d516e5d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007d516e5d93fa  ptest xmm3, xmm3
00007d516e5d93ff  jnz 0x00007D516E5DC4A9
00007d516e5d9405  vmovaps xmm8, [rsp+0x60]
00007d516e5d940b  movaps xmm10, xmm8
00007d516e5d940f  addpd xmm10, xmm14
00007d516e5d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007d516e5d941a  ptest xmm3, xmm3
00007d516e5d941f  jnz 0x00007D516E5DC5EB
00007d516e5d9425  vmovaps xmm8, [rsp+0x50]
00007d516e5d942b  movaps xmm14, xmm8
00007d516e5d942f  addpd xmm14, xmm4
00007d516e5d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007d516e5d943a  ptest xmm3, xmm3
00007d516e5d943f  jnz 0x00007D516E5DC72F
00007d516e5d9445  vmovaps xmm8, [rsp+0x40]
00007d516e5d944b  vpermilpd xmm8, xmm8, 0x00
00007d516e5d9451  movaps xmm4, xmm13
00007d516e5d9455  mulpd xmm4, xmm8
00007d516e5d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d516e5d945f  ptest xmm3, xmm3
00007d516e5d9464  jnz 0x00007D516E5DC872
00007d516e5d946a  movaps xmm13, xmm15
00007d516e5d946e  addpd xmm13, xmm9
00007d516e5d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007d516e5d9479  ptest xmm8, xmm8
00007d516e5d947f  jnz 0x00007D516E5DC9B4
00007d516e5d9485  movaps xmm15, xmm1
00007d516e5d9489  addpd xmm15, xmm5
00007d516e5d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007d516e5d9494  ptest xmm9, xmm9
00007d516e5d949a  jnz 0x00007D516E5DCAF8
00007d516e5d94a0  vmovaps [rsp+0x30], xmm11
00007d516e5d94a6  vmovaps xmm1, [rsp+0x30]
00007d516e5d94ac  por xmm11, xmm1
00007d516e5d94b1  movaps [r15+0x250], xmm11
00007d516e5d94b9  vmovaps [rsp+0x30], xmm12
00007d516e5d94bf  vmovaps xmm1, [rsp+0x30]
00007d516e5d94c5  por xmm12, xmm1
00007d516e5d94ca  movaps [r15+0x2A0], xmm12
00007d516e5d94d2  vmovaps xmm1, [rsp+0xA0]
00007d516e5d94db  vmovaps xmm11, [rsp+0xA0]
00007d516e5d94e4  por xmm1, xmm11
00007d516e5d94e9  movaps [r15+0x1D0], xmm1
00007d516e5d94f1  lea r14, [rax+0x40]
00007d516e5d94f5  movups xmm1, [r13+r14*1]
00007d516e5d94fb  movaps [r15+0x2C0], xmm1
00007d516e5d9503  vmovaps xmm11, [rsp+0x40]
00007d516e5d9509  vpermilpd xmm11, xmm11, 0x00
00007d516e5d950f  vmovaps xmm8, [rsp+0xE0]
00007d516e5d9518  movaps xmm9, xmm8
00007d516e5d951c  mulpd xmm9, xmm11
00007d516e5d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007d516e5d9527  ptest xmm5, xmm5
00007d516e5d952c  jnz 0x00007D516E5DCC44
00007d516e5d9532  movaps xmm11, xmm10
00007d516e5d9536  addpd xmm11, xmm6
00007d516e5d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d516e5d9541  ptest xmm8, xmm8
00007d516e5d9547  jnz 0x00007D516E5DCD88
00007d516e5d954d  movaps xmm10, xmm14
00007d516e5d9551  addpd xmm10, xmm4
00007d516e5d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007d516e5d955c  ptest xmm8, xmm8
00007d516e5d9562  jnz 0x00007D516E5DCECB
00007d516e5d9568  vmovaps xmm14, [rsp+0x40]
00007d516e5d956e  vpermilpd xmm14, xmm14, 0x00
00007d516e5d9574  movaps xmm8, xmm1
00007d516e5d9578  mulpd xmm8, xmm14
00007d516e5d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d516e5d9583  ptest xmm6, xmm6
00007d516e5d9588  jnz 0x00007D516E5DD00E
00007d516e5d958e  movaps xmm1, [r15+0x2B0]
00007d516e5d9596  vmovaps xmm14, [rsp+0x40]
00007d516e5d959c  vpermilpd xmm14, xmm14, 0x00
00007d516e5d95a2  movaps xmm6, xmm1
00007d516e5d95a5  mulpd xmm6, xmm14
00007d516e5d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007d516e5d95af  ptest xmm5, xmm5
00007d516e5d95b4  jnz 0x00007D516E5DD151
00007d516e5d95ba  vmovaps xmm1, [rsp+0x10]
00007d516e5d95c0  vpermilpd xmm1, xmm1, 0x00
00007d516e5d95c6  movaps xmm14, xmm12
00007d516e5d95ca  mulpd xmm14, xmm1
00007d516e5d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007d516e5d95d5  ptest xmm5, xmm5
00007d516e5d95da  jnz 0x00007D516E5DD292
00007d516e5d95e0  movaps xmm1, xmm13
00007d516e5d95e4  addpd xmm1, xmm9
00007d516e5d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007d516e5d95ee  ptest xmm12, xmm12
00007d516e5d95f4  jnz 0x00007D516E5DD3D5
00007d516e5d95fa  vmovaps xmm13, [rsp+0x10]
00007d516e5d9600  vpermilpd xmm13, xmm13, 0x00
00007d516e5d9606  movaps xmm12, xmm7
00007d516e5d960a  mulpd xmm12, xmm13
00007d516e5d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d516e5d9615  ptest xmm9, xmm9
00007d516e5d961b  jnz 0x00007D516E5DD517
00007d516e5d9621  movaps xmm13, xmm15
00007d516e5d9625  addpd xmm13, xmm8
00007d516e5d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d516e5d9630  ptest xmm9, xmm9
00007d516e5d9636  jnz 0x00007D516E5DD65A
00007d516e5d963c  movaps xmm15, [r15+0x290]
00007d516e5d9644  vmovaps xmm9, [rsp+0x10]
00007d516e5d964a  vpermilpd xmm9, xmm9, 0x00
00007d516e5d9650  movaps xmm8, xmm15
00007d516e5d9654  mulpd xmm8, xmm9
00007d516e5d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007d516e5d965f  ptest xmm7, xmm7
00007d516e5d9664  jnz 0x00007D516E5DD79E
00007d516e5d966a  movaps xmm15, xmm11
00007d516e5d966e  addpd xmm15, xmm6
00007d516e5d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007d516e5d9679  ptest xmm9, xmm9
00007d516e5d967f  jnz 0x00007D516E5DD8E2
00007d516e5d9685  movaps xmm11, [r15+0x1E0]
00007d516e5d968d  vmovaps xmm9, [rsp+0x10]
00007d516e5d9693  vpermilpd xmm9, xmm9, 0x00
00007d516e5d9699  movaps xmm7, xmm11
00007d516e5d969d  mulpd xmm7, xmm9
00007d516e5d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d516e5d96a7  ptest xmm6, xmm6
00007d516e5d96ac  jnz 0x00007D516E5DDA25
00007d516e5d96b2  movaps xmm11, xmm10
00007d516e5d96b6  addpd xmm11, xmm14
00007d516e5d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007d516e5d96c1  ptest xmm9, xmm9
00007d516e5d96c7  jnz 0x00007D516E5DDB67
00007d516e5d96cd  lea r14, [rax+0x70]
00007d516e5d96d1  movups xmm14, [r13+r14*1]
00007d516e5d96d7  movaps [r15+0x240], xmm14
00007d516e5d96df  movaps xmm10, xmm1
00007d516e5d96e3  addpd xmm10, xmm12
00007d516e5d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007d516e5d96ee  ptest xmm9, xmm9
00007d516e5d96f4  jnz 0x00007D516E5DDCB5
00007d516e5d96fa  movaps [r15+0x170], xmm10
00007d516e5d9702  vmovaps xmm1, [rsp+0x20]
00007d516e5d9708  vpermilpd xmm1, xmm1, 0x00
00007d516e5d970e  movaps xmm12, xmm14
00007d516e5d9712  mulpd xmm12, xmm1
00007d516e5d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007d516e5d971d  ptest xmm9, xmm9
00007d516e5d9723  jnz 0x00007D516E5DDDF8
00007d516e5d9729  vmovaps xmm1, [rsp+0x20]
00007d516e5d972f  vpermilpd xmm1, xmm1, 0x00
00007d516e5d9735  vmovaps xmm9, [rsp+0xB0]
00007d516e5d973e  movaps xmm14, xmm9
00007d516e5d9742  mulpd xmm14, xmm1
00007d516e5d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007d516e5d974d  ptest xmm6, xmm6
00007d516e5d9752  jnz 0x00007D516E5DDF3B
00007d516e5d9758  movaps [r15+0x180], xmm14
00007d516e5d9760  movaps xmm1, xmm13
00007d516e5d9764  addpd xmm1, xmm8
00007d516e5d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007d516e5d976e  ptest xmm9, xmm9
00007d516e5d9774  jnz 0x00007D516E5DE07E
00007d516e5d977a  movaps [r15+0x210], xmm1
00007d516e5d9782  movups xmm13, [r13+rax*1]
00007d516e5d9788  lea r14, [rax+0x10]
00007d516e5d978c  movups xmm9, [r13+r14*1]
00007d516e5d9792  movaps [r15+0x230], xmm9
00007d516e5d979a  movaps xmm8, xmm15
00007d516e5d979e  addpd xmm8, xmm7
00007d516e5d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d516e5d97a9  ptest xmm6, xmm6
00007d516e5d97ae  jnz 0x00007D516E5DE1D4
00007d516e5d97b4  movaps [r15+0x130], xmm8
00007d516e5d97bc  vmovaps xmm15, [rsp+0x20]
00007d516e5d97c2  vpermilpd xmm15, xmm15, 0x00
00007d516e5d97c8  movaps xmm7, xmm9
00007d516e5d97cc  mulpd xmm7, xmm15
00007d516e5d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d516e5d97d6  ptest xmm6, xmm6
00007d516e5d97db  jnz 0x00007D516E5DE317
00007d516e5d97e1  movaps [r15+0x220], xmm7
00007d516e5d97e9  vmovaps xmm15, [rsp+0x20]
00007d516e5d97ef  vpermilpd xmm15, xmm15, 0x00
00007d516e5d97f5  movaps xmm9, xmm13
00007d516e5d97f9  mulpd xmm9, xmm15
00007d516e5d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007d516e5d9804  ptest xmm6, xmm6
00007d516e5d9809  jnz 0x00007D516E5DE459
00007d516e5d980f  movaps xmm15, xmm11
00007d516e5d9813  addpd xmm15, xmm12
00007d516e5d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007d516e5d981e  ptest xmm13, xmm13
00007d516e5d9824  jnz 0x00007D516E5DE59D
00007d516e5d982a  movaps [r15+0x140], xmm15
00007d516e5d9832  movaps xmm13, xmm10
00007d516e5d9836  addpd xmm13, xmm14
00007d516e5d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d516e5d9841  ptest xmm12, xmm12
00007d516e5d9847  jnz 0x00007D516E5DE6E1
00007d516e5d984d  movaps [r15+0x150], xmm13
00007d516e5d9855  movaps xmm14, xmm1
00007d516e5d9859  addpd xmm14, xmm7
00007d516e5d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d516e5d9864  ptest xmm12, xmm12
00007d516e5d986a  jnz 0x00007D516E5DE825
00007d516e5d9870  movaps [r15+0x160], xmm14
00007d516e5d9878  movaps xmm1, xmm8
00007d516e5d987c  addpd xmm1, xmm9
00007d516e5d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007d516e5d9886  ptest xmm12, xmm12
00007d516e5d988c  jnz 0x00007D516E5DE967
00007d516e5d9892  movaps [r15+0x120], xmm1
00007d516e5d989a  movups [r13+r11*1], xmm15
00007d516e5d98a0  lea rax, [r11+0x10]
00007d516e5d98a4  movups [r13+rax*1], xmm13
00007d516e5d98aa  lea rax, [r11+0x20]
00007d516e5d98ae  movups [r13+rax*1], xmm14
00007d516e5d98b4  lea rax, [r11+0x30]
00007d516e5d98b8  movups [r13+rax*1], xmm1
00007d516e5d98be  mov eax, [r15+0x108]
00007d516e5d98c5  sahf
00007d516e5d98c6  jnz 0x00007D516E5D98F8
00007d516e5d98c8  cmp dword ptr [r15+0x318], 0x00
00007d516e5d98d0  jz 0x00007D516E5DEAE0
00007d516e5d98d6  nop [rax+rax*1], ax
00007d516e5d98df  nop [rax+rax*1], eax
00007d516e5d98e7  mov eax, 0x4106D0
00007d516e5d98ec  mov [r15+0x100], rax
00007d516e5d98f3  jmp 0x00007D516E3FE110
00007d516e5d98f8  cmp dword ptr [r15+0x318], 0x00
00007d516e5d9900  jz 0x00007D516E5D89C0
00007d516e5d9906  nop [rax+rax*1], ax
00007d516e5d990f  nop [rax+rax*1], eax
00007d516e5d9917  mov eax, 0x410504
00007d516e5d991c  mov [r15+0x100], rax
00007d516e5d9923  jmp 0x00007D516E3FE110
00007d516e5d9928  int3
00007d516e5d9929  call 0x00007D516E40A4B0
00007d516e5d992e  jmp 0x00007D516E5D8A08
00007d516e5d9933  call 0x00007D516E409240
00007d516e5d9938  jmp 0x00007D516E5D8A12
00007d516e5d993d  call 0x00007D516E40A4B0
00007d516e5d9942  jmp 0x00007D516E5D8A6F
00007d516e5d9947  call 0x00007D516E409240
00007d516e5d994c  jmp 0x00007D516E5D8A79
00007d516e5d9951  call 0x00007D516E40A4B0
00007d516e5d9956  jmp 0x00007D516E5D8ABD
00007d516e5d995b  call 0x00007D516E409240
00007d516e5d9960  jmp 0x00007D516E5D8AC7
00007d516e5d9965  call 0x00007D516E4B47C0
00007d516e5d996a  jmp 0x00007D516E5D8B06
00007d516e5d996f  call 0x00007D516E40B720
00007d516e5d9974  jmp 0x00007D516E5D8B1A
00007d516e5d9979  call 0x00007D516E4BFC30
00007d516e5d997e  jmp 0x00007D516E5D8B38
00007d516e5d9983  call 0x00007D516E4BE9C0
00007d516e5d9988  jmp 0x00007D516E5D8B42
00007d516e5d998d  call 0x00007D516E4BD750
00007d516e5d9992  jmp 0x00007D516E5D8B4C
00007d516e5d9997  sub rsp, 0x08
00007d516e5d999b  push rax
00007d516e5d999c  push rcx
00007d516e5d999d  push rdx
00007d516e5d999e  push rdi
00007d516e5d999f  push rsi
00007d516e5d99a0  push r8
00007d516e5d99a2  push r9
00007d516e5d99a4  push r10
00007d516e5d99a6  push r11
00007d516e5d99a8  sub rsp, 0xF0
00007d516e5d99af  vmovaps [rsp], xmm0
00007d516e5d99b4  vmovaps [rsp+0x10], xmm1
00007d516e5d99ba  vmovaps [rsp+0x20], xmm2
00007d516e5d99c0  vmovaps [rsp+0x30], xmm3
00007d516e5d99c6  vmovaps [rsp+0x40], xmm4
00007d516e5d99cc  vmovaps [rsp+0x50], xmm5
00007d516e5d99d2  vmovaps [rsp+0x60], xmm6
00007d516e5d99d8  vmovaps [rsp+0x70], xmm7
00007d516e5d99de  vmovaps [rsp+0x80], xmm9
00007d516e5d99e7  vmovaps [rsp+0x90], xmm10
00007d516e5d99f0  vmovaps [rsp+0xA0], xmm11
00007d516e5d99f9  vmovaps [rsp+0xB0], xmm12
00007d516e5d9a02  vmovaps [rsp+0xC0], xmm13
00007d516e5d9a0b  vmovaps [rsp+0xD0], xmm14
00007d516e5d9a14  vmovaps [rsp+0xE0], xmm15
00007d516e5d9a1d  sub rsp, 0x30
00007d516e5d9a21  movaps [rsp], xmm8
00007d516e5d9a26  movaps [rsp+0x10], xmm12
00007d516e5d9a2c  movaps [rsp+0x20], xmm15
00007d516e5d9a32  lea rdi, [rsp]
00007d516e5d9a36  mov esi, 0x00
00007d516e5d9a3b  mov rax, 0x5EE43AF14530
00007d516e5d9a45  call rax
00007d516e5d9a47  movaps xmm8, [rsp]
00007d516e5d9a4c  add rsp, 0x30
00007d516e5d9a50  vmovaps xmm0, [rsp]
00007d516e5d9a55  vmovaps xmm1, [rsp+0x10]
00007d516e5d9a5b  vmovaps xmm2, [rsp+0x20]
00007d516e5d9a61  vmovaps xmm3, [rsp+0x30]
00007d516e5d9a67  vmovaps xmm4, [rsp+0x40]
00007d516e5d9a6d  vmovaps xmm5, [rsp+0x50]
00007d516e5d9a73  vmovaps xmm6, [rsp+0x60]
00007d516e5d9a79  vmovaps xmm7, [rsp+0x70]
00007d516e5d9a7f  vmovaps xmm9, [rsp+0x80]
00007d516e5d9a88  vmovaps xmm10, [rsp+0x90]
00007d516e5d9a91  vmovaps xmm11, [rsp+0xA0]
00007d516e5d9a9a  vmovaps xmm12, [rsp+0xB0]
00007d516e5d9aa3  vmovaps xmm13, [rsp+0xC0]
00007d516e5d9aac  vmovaps xmm14, [rsp+0xD0]
00007d516e5d9ab5  vmovaps xmm15, [rsp+0xE0]
00007d516e5d9abe  add rsp, 0xF0
00007d516e5d9ac5  pop r11
00007d516e5d9ac7  pop r10
00007d516e5d9ac9  pop r9
00007d516e5d9acb  pop r8
00007d516e5d9acd  pop rsi
00007d516e5d9ace  pop rdi
00007d516e5d9acf  pop rdx
00007d516e5d9ad0  pop rcx
00007d516e5d9ad1  pop rax
00007d516e5d9ad2  add rsp, 0x08
00007d516e5d9ad6  jmp 0x00007D516E5D8B7A
00007d516e5d9adb  sub rsp, 0x08
00007d516e5d9adf  push rax
00007d516e5d9ae0  push rcx
00007d516e5d9ae1  push rdx
00007d516e5d9ae2  push rdi
00007d516e5d9ae3  push rsi
00007d516e5d9ae4  push r8
00007d516e5d9ae6  push r9
00007d516e5d9ae8  push r10
00007d516e5d9aea  push r11
00007d516e5d9aec  sub rsp, 0xF0
00007d516e5d9af3  vmovaps [rsp], xmm0
00007d516e5d9af8  vmovaps [rsp+0x10], xmm1
00007d516e5d9afe  vmovaps [rsp+0x20], xmm2
00007d516e5d9b04  vmovaps [rsp+0x30], xmm3
00007d516e5d9b0a  vmovaps [rsp+0x40], xmm4
00007d516e5d9b10  vmovaps [rsp+0x50], xmm5
00007d516e5d9b16  vmovaps [rsp+0x60], xmm6
00007d516e5d9b1c  vmovaps [rsp+0x70], xmm8
00007d516e5d9b22  vmovaps [rsp+0x80], xmm9
00007d516e5d9b2b  vmovaps [rsp+0x90], xmm10
00007d516e5d9b34  vmovaps [rsp+0xA0], xmm11
00007d516e5d9b3d  vmovaps [rsp+0xB0], xmm12
00007d516e5d9b46  vmovaps [rsp+0xC0], xmm13
00007d516e5d9b4f  vmovaps [rsp+0xD0], xmm14
00007d516e5d9b58  vmovaps [rsp+0xE0], xmm15
00007d516e5d9b61  sub rsp, 0x30
00007d516e5d9b65  movaps [rsp], xmm7
00007d516e5d9b69  movaps [rsp+0x10], xmm9
00007d516e5d9b6f  movaps [rsp+0x20], xmm15
00007d516e5d9b75  lea rdi, [rsp]
00007d516e5d9b79  mov esi, 0x00
00007d516e5d9b7e  mov rax, 0x5EE43AF14530
00007d516e5d9b88  call rax
00007d516e5d9b8a  movaps xmm7, [rsp]
00007d516e5d9b8e  add rsp, 0x30
00007d516e5d9b92  vmovaps xmm0, [rsp]
00007d516e5d9b97  vmovaps xmm1, [rsp+0x10]
00007d516e5d9b9d  vmovaps xmm2, [rsp+0x20]
00007d516e5d9ba3  vmovaps xmm3, [rsp+0x30]
00007d516e5d9ba9  vmovaps xmm4, [rsp+0x40]
00007d516e5d9baf  vmovaps xmm5, [rsp+0x50]
00007d516e5d9bb5  vmovaps xmm6, [rsp+0x60]
00007d516e5d9bbb  vmovaps xmm8, [rsp+0x70]
00007d516e5d9bc1  vmovaps xmm9, [rsp+0x80]
00007d516e5d9bca  vmovaps xmm10, [rsp+0x90]
00007d516e5d9bd3  vmovaps xmm11, [rsp+0xA0]
00007d516e5d9bdc  vmovaps xmm12, [rsp+0xB0]
00007d516e5d9be5  vmovaps xmm13, [rsp+0xC0]
00007d516e5d9bee  vmovaps xmm14, [rsp+0xD0]
00007d516e5d9bf7  vmovaps xmm15, [rsp+0xE0]
00007d516e5d9c00  add rsp, 0xF0
00007d516e5d9c07  pop r11
00007d516e5d9c09  pop r10
00007d516e5d9c0b  pop r9
00007d516e5d9c0d  pop r8
00007d516e5d9c0f  pop rsi
00007d516e5d9c10  pop rdi
00007d516e5d9c11  pop rdx
00007d516e5d9c12  pop rcx
00007d516e5d9c13  pop rax
00007d516e5d9c14  add rsp, 0x08
00007d516e5d9c18  jmp 0x00007D516E5D8BA8
00007d516e5d9c1d  sub rsp, 0x08
00007d516e5d9c21  push rax
00007d516e5d9c22  push rcx
00007d516e5d9c23  push rdx
00007d516e5d9c24  push rdi
00007d516e5d9c25  push rsi
00007d516e5d9c26  push r8
00007d516e5d9c28  push r9
00007d516e5d9c2a  push r10
00007d516e5d9c2c  push r11
00007d516e5d9c2e  sub rsp, 0xF0
00007d516e5d9c35  vmovaps [rsp], xmm0
00007d516e5d9c3a  vmovaps [rsp+0x10], xmm1
00007d516e5d9c40  vmovaps [rsp+0x20], xmm2
00007d516e5d9c46  vmovaps [rsp+0x30], xmm3
00007d516e5d9c4c  vmovaps [rsp+0x40], xmm4
00007d516e5d9c52  vmovaps [rsp+0x50], xmm5
00007d516e5d9c58  vmovaps [rsp+0x60], xmm6
00007d516e5d9c5e  vmovaps [rsp+0x70], xmm7
00007d516e5d9c64  vmovaps [rsp+0x80], xmm8
00007d516e5d9c6d  vmovaps [rsp+0x90], xmm10
00007d516e5d9c76  vmovaps [rsp+0xA0], xmm11
00007d516e5d9c7f  vmovaps [rsp+0xB0], xmm12
00007d516e5d9c88  vmovaps [rsp+0xC0], xmm13
00007d516e5d9c91  vmovaps [rsp+0xD0], xmm14
00007d516e5d9c9a  vmovaps [rsp+0xE0], xmm15
00007d516e5d9ca3  sub rsp, 0x30
00007d516e5d9ca7  movaps [rsp], xmm9
00007d516e5d9cac  movaps [rsp+0x10], xmm12
00007d516e5d9cb2  movaps [rsp+0x20], xmm10
00007d516e5d9cb8  lea rdi, [rsp]
00007d516e5d9cbc  mov esi, 0x00
00007d516e5d9cc1  mov rax, 0x5EE43AF14530
00007d516e5d9ccb  call rax
00007d516e5d9ccd  movaps xmm9, [rsp]
00007d516e5d9cd2  add rsp, 0x30
00007d516e5d9cd6  vmovaps xmm0, [rsp]
00007d516e5d9cdb  vmovaps xmm1, [rsp+0x10]
00007d516e5d9ce1  vmovaps xmm2, [rsp+0x20]
00007d516e5d9ce7  vmovaps xmm3, [rsp+0x30]
00007d516e5d9ced  vmovaps xmm4, [rsp+0x40]
00007d516e5d9cf3  vmovaps xmm5, [rsp+0x50]
00007d516e5d9cf9  vmovaps xmm6, [rsp+0x60]
00007d516e5d9cff  vmovaps xmm7, [rsp+0x70]
00007d516e5d9d05  vmovaps xmm8, [rsp+0x80]
00007d516e5d9d0e  vmovaps xmm10, [rsp+0x90]
00007d516e5d9d17  vmovaps xmm11, [rsp+0xA0]
00007d516e5d9d20  vmovaps xmm12, [rsp+0xB0]
00007d516e5d9d29  vmovaps xmm13, [rsp+0xC0]
00007d516e5d9d32  vmovaps xmm14, [rsp+0xD0]
00007d516e5d9d3b  vmovaps xmm15, [rsp+0xE0]
00007d516e5d9d44  add rsp, 0xF0
00007d516e5d9d4b  pop r11
00007d516e5d9d4d  pop r10
00007d516e5d9d4f  pop r9
00007d516e5d9d51  pop r8
00007d516e5d9d53  pop rsi
00007d516e5d9d54  pop rdi
00007d516e5d9d55  pop rdx
00007d516e5d9d56  pop rcx
00007d516e5d9d57  pop rax
00007d516e5d9d58  add rsp, 0x08
00007d516e5d9d5c  jmp 0x00007D516E5D8BCC
00007d516e5d9d61  sub rsp, 0x08
00007d516e5d9d65  push rax
00007d516e5d9d66  push rcx
00007d516e5d9d67  push rdx
00007d516e5d9d68  push rdi
00007d516e5d9d69  push rsi
00007d516e5d9d6a  push r8
00007d516e5d9d6c  push r9
00007d516e5d9d6e  push r10
00007d516e5d9d70  push r11
00007d516e5d9d72  sub rsp, 0xF0
00007d516e5d9d79  vmovaps [rsp], xmm0
00007d516e5d9d7e  vmovaps [rsp+0x10], xmm1
00007d516e5d9d84  vmovaps [rsp+0x20], xmm2
00007d516e5d9d8a  vmovaps [rsp+0x30], xmm3
00007d516e5d9d90  vmovaps [rsp+0x40], xmm4
00007d516e5d9d96  vmovaps [rsp+0x50], xmm5
00007d516e5d9d9c  vmovaps [rsp+0x60], xmm6
00007d516e5d9da2  vmovaps [rsp+0x70], xmm7
00007d516e5d9da8  vmovaps [rsp+0x80], xmm8
00007d516e5d9db1  vmovaps [rsp+0x90], xmm9
00007d516e5d9dba  vmovaps [rsp+0xA0], xmm11
00007d516e5d9dc3  vmovaps [rsp+0xB0], xmm12
00007d516e5d9dcc  vmovaps [rsp+0xC0], xmm13
00007d516e5d9dd5  vmovaps [rsp+0xD0], xmm14
00007d516e5d9dde  vmovaps [rsp+0xE0], xmm15
00007d516e5d9de7  sub rsp, 0x30
00007d516e5d9deb  movaps [rsp], xmm10
00007d516e5d9df0  movaps [rsp+0x10], xmm12
00007d516e5d9df6  movaps [rsp+0x20], xmm11
00007d516e5d9dfc  lea rdi, [rsp]
00007d516e5d9e00  mov esi, 0x00
00007d516e5d9e05  mov rax, 0x5EE43AF14530
00007d516e5d9e0f  call rax
00007d516e5d9e11  movaps xmm10, [rsp]
00007d516e5d9e16  add rsp, 0x30
00007d516e5d9e1a  vmovaps xmm0, [rsp]
00007d516e5d9e1f  vmovaps xmm1, [rsp+0x10]
00007d516e5d9e25  vmovaps xmm2, [rsp+0x20]
00007d516e5d9e2b  vmovaps xmm3, [rsp+0x30]
00007d516e5d9e31  vmovaps xmm4, [rsp+0x40]
00007d516e5d9e37  vmovaps xmm5, [rsp+0x50]
00007d516e5d9e3d  vmovaps xmm6, [rsp+0x60]
00007d516e5d9e43  vmovaps xmm7, [rsp+0x70]
00007d516e5d9e49  vmovaps xmm8, [rsp+0x80]
00007d516e5d9e52  vmovaps xmm9, [rsp+0x90]
00007d516e5d9e5b  vmovaps xmm11, [rsp+0xA0]
00007d516e5d9e64  vmovaps xmm12, [rsp+0xB0]
00007d516e5d9e6d  vmovaps xmm13, [rsp+0xC0]
00007d516e5d9e76  vmovaps xmm14, [rsp+0xD0]
00007d516e5d9e7f  vmovaps xmm15, [rsp+0xE0]
00007d516e5d9e88  add rsp, 0xF0
00007d516e5d9e8f  pop r11
00007d516e5d9e91  pop r10
00007d516e5d9e93  pop r9
00007d516e5d9e95  pop r8
00007d516e5d9e97  pop rsi
00007d516e5d9e98  pop rdi
00007d516e5d9e99  pop rdx
00007d516e5d9e9a  pop rcx
00007d516e5d9e9b  pop rax
00007d516e5d9e9c  add rsp, 0x08
00007d516e5d9ea0  jmp 0x00007D516E5D8BE6
00007d516e5d9ea5  sub rsp, 0x08
00007d516e5d9ea9  push rax
00007d516e5d9eaa  push rcx
00007d516e5d9eab  push rdx
00007d516e5d9eac  push rdi
00007d516e5d9ead  push rsi
00007d516e5d9eae  push r8
00007d516e5d9eb0  push r9
00007d516e5d9eb2  push r10
00007d516e5d9eb4  push r11
00007d516e5d9eb6  sub rsp, 0xF0
00007d516e5d9ebd  vmovaps [rsp], xmm0
00007d516e5d9ec2  vmovaps [rsp+0x10], xmm1
00007d516e5d9ec8  vmovaps [rsp+0x20], xmm2
00007d516e5d9ece  vmovaps [rsp+0x30], xmm3
00007d516e5d9ed4  vmovaps [rsp+0x40], xmm4
00007d516e5d9eda  vmovaps [rsp+0x50], xmm5
00007d516e5d9ee0  vmovaps [rsp+0x60], xmm7
00007d516e5d9ee6  vmovaps [rsp+0x70], xmm8
00007d516e5d9eec  vmovaps [rsp+0x80], xmm9
00007d516e5d9ef5  vmovaps [rsp+0x90], xmm10
00007d516e5d9efe  vmovaps [rsp+0xA0], xmm11
00007d516e5d9f07  vmovaps [rsp+0xB0], xmm12
00007d516e5d9f10  vmovaps [rsp+0xC0], xmm13
00007d516e5d9f19  vmovaps [rsp+0xD0], xmm14
00007d516e5d9f22  vmovaps [rsp+0xE0], xmm15
00007d516e5d9f2b  sub rsp, 0x30
00007d516e5d9f2f  movaps [rsp], xmm6
00007d516e5d9f33  movaps [rsp+0x10], xmm12
00007d516e5d9f39  movaps [rsp+0x20], xmm11
00007d516e5d9f3f  lea rdi, [rsp]
00007d516e5d9f43  mov esi, 0x00
00007d516e5d9f48  mov rax, 0x5EE43AF14530
00007d516e5d9f52  call rax
00007d516e5d9f54  movaps xmm6, [rsp]
00007d516e5d9f58  add rsp, 0x30
00007d516e5d9f5c  vmovaps xmm0, [rsp]
00007d516e5d9f61  vmovaps xmm1, [rsp+0x10]
00007d516e5d9f67  vmovaps xmm2, [rsp+0x20]
00007d516e5d9f6d  vmovaps xmm3, [rsp+0x30]
00007d516e5d9f73  vmovaps xmm4, [rsp+0x40]
00007d516e5d9f79  vmovaps xmm5, [rsp+0x50]
00007d516e5d9f7f  vmovaps xmm7, [rsp+0x60]
00007d516e5d9f85  vmovaps xmm8, [rsp+0x70]
00007d516e5d9f8b  vmovaps xmm9, [rsp+0x80]
00007d516e5d9f94  vmovaps xmm10, [rsp+0x90]
00007d516e5d9f9d  vmovaps xmm11, [rsp+0xA0]
00007d516e5d9fa6  vmovaps xmm12, [rsp+0xB0]
00007d516e5d9faf  vmovaps xmm13, [rsp+0xC0]
00007d516e5d9fb8  vmovaps xmm14, [rsp+0xD0]
00007d516e5d9fc1  vmovaps xmm15, [rsp+0xE0]
00007d516e5d9fca  add rsp, 0xF0
00007d516e5d9fd1  pop r11
00007d516e5d9fd3  pop r10
00007d516e5d9fd5  pop r9
00007d516e5d9fd7  pop r8
00007d516e5d9fd9  pop rsi
00007d516e5d9fda  pop rdi
00007d516e5d9fdb  pop rdx
00007d516e5d9fdc  pop rcx
00007d516e5d9fdd  pop rax
00007d516e5d9fde  add rsp, 0x08
00007d516e5d9fe2  jmp 0x00007D516E5D8C07
00007d516e5d9fe7  sub rsp, 0x08
00007d516e5d9feb  push rax
00007d516e5d9fec  push rcx
00007d516e5d9fed  push rdx
00007d516e5d9fee  push rdi
00007d516e5d9fef  push rsi
00007d516e5d9ff0  push r8
00007d516e5d9ff2  push r9
00007d516e5d9ff4  push r10
00007d516e5d9ff6  push r11
00007d516e5d9ff8  sub rsp, 0xF0
00007d516e5d9fff  vmovaps [rsp], xmm0
00007d516e5da004  vmovaps [rsp+0x10], xmm1
00007d516e5da00a  vmovaps [rsp+0x20], xmm2
00007d516e5da010  vmovaps [rsp+0x30], xmm4
00007d516e5da016  vmovaps [rsp+0x40], xmm5
00007d516e5da01c  vmovaps [rsp+0x50], xmm6
00007d516e5da022  vmovaps [rsp+0x60], xmm7
00007d516e5da028  vmovaps [rsp+0x70], xmm8
00007d516e5da02e  vmovaps [rsp+0x80], xmm9
00007d516e5da037  vmovaps [rsp+0x90], xmm10
00007d516e5da040  vmovaps [rsp+0xA0], xmm11
00007d516e5da049  vmovaps [rsp+0xB0], xmm12
00007d516e5da052  vmovaps [rsp+0xC0], xmm13
00007d516e5da05b  vmovaps [rsp+0xD0], xmm14
00007d516e5da064  vmovaps [rsp+0xE0], xmm15
00007d516e5da06d  sub rsp, 0x30
00007d516e5da071  movaps [rsp], xmm3
00007d516e5da075  movaps [rsp+0x10], xmm5
00007d516e5da07a  movaps [rsp+0x20], xmm4
00007d516e5da07f  lea rdi, [rsp]
00007d516e5da083  mov esi, 0x00
00007d516e5da088  mov rax, 0x5EE43AF14530
00007d516e5da092  call rax
00007d516e5da094  movaps xmm3, [rsp]
00007d516e5da098  add rsp, 0x30
00007d516e5da09c  vmovaps xmm0, [rsp]
00007d516e5da0a1  vmovaps xmm1, [rsp+0x10]
00007d516e5da0a7  vmovaps xmm2, [rsp+0x20]
00007d516e5da0ad  vmovaps xmm4, [rsp+0x30]
00007d516e5da0b3  vmovaps xmm5, [rsp+0x40]
00007d516e5da0b9  vmovaps xmm6, [rsp+0x50]
00007d516e5da0bf  vmovaps xmm7, [rsp+0x60]
00007d516e5da0c5  vmovaps xmm8, [rsp+0x70]
00007d516e5da0cb  vmovaps xmm9, [rsp+0x80]
00007d516e5da0d4  vmovaps xmm10, [rsp+0x90]
00007d516e5da0dd  vmovaps xmm11, [rsp+0xA0]
00007d516e5da0e6  vmovaps xmm12, [rsp+0xB0]
00007d516e5da0ef  vmovaps xmm13, [rsp+0xC0]
00007d516e5da0f8  vmovaps xmm14, [rsp+0xD0]
00007d516e5da101  vmovaps xmm15, [rsp+0xE0]
00007d516e5da10a  add rsp, 0xF0
00007d516e5da111  pop r11
00007d516e5da113  pop r10
00007d516e5da115  pop r9
00007d516e5da117  pop r8
00007d516e5da119  pop rsi
00007d516e5da11a  pop rdi
00007d516e5da11b  pop rdx
00007d516e5da11c  pop rcx
00007d516e5da11d  pop rax
00007d516e5da11e  add rsp, 0x08
00007d516e5da122  jmp 0x00007D516E5D8C68
00007d516e5da127  sub rsp, 0x08
00007d516e5da12b  push rax
00007d516e5da12c  push rcx
00007d516e5da12d  push rdx
00007d516e5da12e  push rdi
00007d516e5da12f  push rsi
00007d516e5da130  push r8
00007d516e5da132  push r9
00007d516e5da134  push r10
00007d516e5da136  push r11
00007d516e5da138  sub rsp, 0xF0
00007d516e5da13f  vmovaps [rsp], xmm0
00007d516e5da144  vmovaps [rsp+0x10], xmm1
00007d516e5da14a  vmovaps [rsp+0x20], xmm2
00007d516e5da150  vmovaps [rsp+0x30], xmm3
00007d516e5da156  vmovaps [rsp+0x40], xmm4
00007d516e5da15c  vmovaps [rsp+0x50], xmm6
00007d516e5da162  vmovaps [rsp+0x60], xmm7
00007d516e5da168  vmovaps [rsp+0x70], xmm8
00007d516e5da16e  vmovaps [rsp+0x80], xmm9
00007d516e5da177  vmovaps [rsp+0x90], xmm10
00007d516e5da180  vmovaps [rsp+0xA0], xmm11
00007d516e5da189  vmovaps [rsp+0xB0], xmm12
00007d516e5da192  vmovaps [rsp+0xC0], xmm13
00007d516e5da19b  vmovaps [rsp+0xD0], xmm14
00007d516e5da1a4  vmovaps [rsp+0xE0], xmm15
00007d516e5da1ad  sub rsp, 0x30
00007d516e5da1b1  movaps [rsp], xmm5
00007d516e5da1b5  movaps [rsp+0x10], xmm8
00007d516e5da1bb  movaps [rsp+0x20], xmm15
00007d516e5da1c1  lea rdi, [rsp]
00007d516e5da1c5  mov esi, 0x00
00007d516e5da1ca  mov rax, 0x5EE43AF14530
00007d516e5da1d4  call rax
00007d516e5da1d6  movaps xmm5, [rsp]
00007d516e5da1da  add rsp, 0x30
00007d516e5da1de  vmovaps xmm0, [rsp]
00007d516e5da1e3  vmovaps xmm1, [rsp+0x10]
00007d516e5da1e9  vmovaps xmm2, [rsp+0x20]
00007d516e5da1ef  vmovaps xmm3, [rsp+0x30]
00007d516e5da1f5  vmovaps xmm4, [rsp+0x40]
00007d516e5da1fb  vmovaps xmm6, [rsp+0x50]
00007d516e5da201  vmovaps xmm7, [rsp+0x60]
00007d516e5da207  vmovaps xmm8, [rsp+0x70]
00007d516e5da20d  vmovaps xmm9, [rsp+0x80]
00007d516e5da216  vmovaps xmm10, [rsp+0x90]
00007d516e5da21f  vmovaps xmm11, [rsp+0xA0]
00007d516e5da228  vmovaps xmm12, [rsp+0xB0]
00007d516e5da231  vmovaps xmm13, [rsp+0xC0]
00007d516e5da23a  vmovaps xmm14, [rsp+0xD0]
00007d516e5da243  vmovaps xmm15, [rsp+0xE0]
00007d516e5da24c  add rsp, 0xF0
00007d516e5da253  pop r11
00007d516e5da255  pop r10
00007d516e5da257  pop r9
00007d516e5da259  pop r8
00007d516e5da25b  pop rsi
00007d516e5da25c  pop rdi
00007d516e5da25d  pop rdx
00007d516e5da25e  pop rcx
00007d516e5da25f  pop rax
00007d516e5da260  add rsp, 0x08
00007d516e5da264  jmp 0x00007D516E5D8CA0
00007d516e5da269  sub rsp, 0x08
00007d516e5da26d  push rax
00007d516e5da26e  push rcx
00007d516e5da26f  push rdx
00007d516e5da270  push rdi
00007d516e5da271  push rsi
00007d516e5da272  push r8
00007d516e5da274  push r9
00007d516e5da276  push r10
00007d516e5da278  push r11
00007d516e5da27a  sub rsp, 0xF0
00007d516e5da281  vmovaps [rsp], xmm0
00007d516e5da286  vmovaps [rsp+0x10], xmm1
00007d516e5da28c  vmovaps [rsp+0x20], xmm2
00007d516e5da292  vmovaps [rsp+0x30], xmm3
00007d516e5da298  vmovaps [rsp+0x40], xmm5
00007d516e5da29e  vmovaps [rsp+0x50], xmm6
00007d516e5da2a4  vmovaps [rsp+0x60], xmm7
00007d516e5da2aa  vmovaps [rsp+0x70], xmm8
00007d516e5da2b0  vmovaps [rsp+0x80], xmm9
00007d516e5da2b9  vmovaps [rsp+0x90], xmm10
00007d516e5da2c2  vmovaps [rsp+0xA0], xmm11
00007d516e5da2cb  vmovaps [rsp+0xB0], xmm12
00007d516e5da2d4  vmovaps [rsp+0xC0], xmm13
00007d516e5da2dd  vmovaps [rsp+0xD0], xmm14
00007d516e5da2e6  vmovaps [rsp+0xE0], xmm15
00007d516e5da2ef  sub rsp, 0x30
00007d516e5da2f3  movaps [rsp], xmm4
00007d516e5da2f7  movaps [rsp+0x10], xmm9
00007d516e5da2fd  movaps [rsp+0x20], xmm8
00007d516e5da303  lea rdi, [rsp]
00007d516e5da307  mov esi, 0x00
00007d516e5da30c  mov rax, 0x5EE43AF14530
00007d516e5da316  call rax
00007d516e5da318  movaps xmm4, [rsp]
00007d516e5da31c  add rsp, 0x30
00007d516e5da320  vmovaps xmm0, [rsp]
00007d516e5da325  vmovaps xmm1, [rsp+0x10]
00007d516e5da32b  vmovaps xmm2, [rsp+0x20]
00007d516e5da331  vmovaps xmm3, [rsp+0x30]
00007d516e5da337  vmovaps xmm5, [rsp+0x40]
00007d516e5da33d  vmovaps xmm6, [rsp+0x50]
00007d516e5da343  vmovaps xmm7, [rsp+0x60]
00007d516e5da349  vmovaps xmm8, [rsp+0x70]
00007d516e5da34f  vmovaps xmm9, [rsp+0x80]
00007d516e5da358  vmovaps xmm10, [rsp+0x90]
00007d516e5da361  vmovaps xmm11, [rsp+0xA0]
00007d516e5da36a  vmovaps xmm12, [rsp+0xB0]
00007d516e5da373  vmovaps xmm13, [rsp+0xC0]
00007d516e5da37c  vmovaps xmm14, [rsp+0xD0]
00007d516e5da385  vmovaps xmm15, [rsp+0xE0]
00007d516e5da38e  add rsp, 0xF0
00007d516e5da395  pop r11
00007d516e5da397  pop r10
00007d516e5da399  pop r9
00007d516e5da39b  pop r8
00007d516e5da39d  pop rsi
00007d516e5da39e  pop rdi
00007d516e5da39f  pop rdx
00007d516e5da3a0  pop rcx
00007d516e5da3a1  pop rax
00007d516e5da3a2  add rsp, 0x08
00007d516e5da3a6  jmp 0x00007D516E5D8CC1
00007d516e5da3ab  sub rsp, 0x08
00007d516e5da3af  push rax
00007d516e5da3b0  push rcx
00007d516e5da3b1  push rdx
00007d516e5da3b2  push rdi
00007d516e5da3b3  push rsi
00007d516e5da3b4  push r8
00007d516e5da3b6  push r9
00007d516e5da3b8  push r10
00007d516e5da3ba  push r11
00007d516e5da3bc  sub rsp, 0xF0
00007d516e5da3c3  vmovaps [rsp], xmm0
00007d516e5da3c8  vmovaps [rsp+0x10], xmm1
00007d516e5da3ce  vmovaps [rsp+0x20], xmm2
00007d516e5da3d4  vmovaps [rsp+0x30], xmm3
00007d516e5da3da  vmovaps [rsp+0x40], xmm4
00007d516e5da3e0  vmovaps [rsp+0x50], xmm5
00007d516e5da3e6  vmovaps [rsp+0x60], xmm6
00007d516e5da3ec  vmovaps [rsp+0x70], xmm7
00007d516e5da3f2  vmovaps [rsp+0x80], xmm8
00007d516e5da3fb  vmovaps [rsp+0x90], xmm10
00007d516e5da404  vmovaps [rsp+0xA0], xmm11
00007d516e5da40d  vmovaps [rsp+0xB0], xmm12
00007d516e5da416  vmovaps [rsp+0xC0], xmm13
00007d516e5da41f  vmovaps [rsp+0xD0], xmm14
00007d516e5da428  vmovaps [rsp+0xE0], xmm15
00007d516e5da431  sub rsp, 0x30
00007d516e5da435  movaps [rsp], xmm9
00007d516e5da43a  movaps [rsp+0x10], xmm10
00007d516e5da440  movaps [rsp+0x20], xmm8
00007d516e5da446  lea rdi, [rsp]
00007d516e5da44a  mov esi, 0x00
00007d516e5da44f  mov rax, 0x5EE43AF14530
00007d516e5da459  call rax
00007d516e5da45b  movaps xmm9, [rsp]
00007d516e5da460  add rsp, 0x30
00007d516e5da464  vmovaps xmm0, [rsp]
00007d516e5da469  vmovaps xmm1, [rsp+0x10]
00007d516e5da46f  vmovaps xmm2, [rsp+0x20]
00007d516e5da475  vmovaps xmm3, [rsp+0x30]
00007d516e5da47b  vmovaps xmm4, [rsp+0x40]
00007d516e5da481  vmovaps xmm5, [rsp+0x50]
00007d516e5da487  vmovaps xmm6, [rsp+0x60]
00007d516e5da48d  vmovaps xmm7, [rsp+0x70]
00007d516e5da493  vmovaps xmm8, [rsp+0x80]
00007d516e5da49c  vmovaps xmm10, [rsp+0x90]
00007d516e5da4a5  vmovaps xmm11, [rsp+0xA0]
00007d516e5da4ae  vmovaps xmm12, [rsp+0xB0]
00007d516e5da4b7  vmovaps xmm13, [rsp+0xC0]
00007d516e5da4c0  vmovaps xmm14, [rsp+0xD0]
00007d516e5da4c9  vmovaps xmm15, [rsp+0xE0]
00007d516e5da4d2  add rsp, 0xF0
00007d516e5da4d9  pop r11
00007d516e5da4db  pop r10
00007d516e5da4dd  pop r9
00007d516e5da4df  pop r8
00007d516e5da4e1  pop rsi
00007d516e5da4e2  pop rdi
00007d516e5da4e3  pop rdx
00007d516e5da4e4  pop rcx
00007d516e5da4e5  pop rax
00007d516e5da4e6  add rsp, 0x08
00007d516e5da4ea  jmp 0x00007D516E5D8CDB
00007d516e5da4ef  call 0x00007D516E4D64F0
00007d516e5da4f4  jmp 0x00007D516E5D8DF5
00007d516e5da4f9  call 0x00007D516E4D64F0
00007d516e5da4fe  jmp 0x00007D516E5D8E0B
00007d516e5da503  sub rsp, 0x08
00007d516e5da507  push rax
00007d516e5da508  push rcx
00007d516e5da509  push rdx
00007d516e5da50a  push rdi
00007d516e5da50b  push rsi
00007d516e5da50c  push r8
00007d516e5da50e  push r9
00007d516e5da510  push r10
00007d516e5da512  push r11
00007d516e5da514  sub rsp, 0xF0
00007d516e5da51b  vmovaps [rsp], xmm0
00007d516e5da520  vmovaps [rsp+0x10], xmm2
00007d516e5da526  vmovaps [rsp+0x20], xmm3
00007d516e5da52c  vmovaps [rsp+0x30], xmm4
00007d516e5da532  vmovaps [rsp+0x40], xmm5
00007d516e5da538  vmovaps [rsp+0x50], xmm6
00007d516e5da53e  vmovaps [rsp+0x60], xmm7
00007d516e5da544  vmovaps [rsp+0x70], xmm8
00007d516e5da54a  vmovaps [rsp+0x80], xmm9
00007d516e5da553  vmovaps [rsp+0x90], xmm10
00007d516e5da55c  vmovaps [rsp+0xA0], xmm11
00007d516e5da565  vmovaps [rsp+0xB0], xmm12
00007d516e5da56e  vmovaps [rsp+0xC0], xmm13
00007d516e5da577  vmovaps [rsp+0xD0], xmm14
00007d516e5da580  vmovaps [rsp+0xE0], xmm15
00007d516e5da589  sub rsp, 0x30
00007d516e5da58d  movaps [rsp], xmm1
00007d516e5da591  movaps [rsp+0x10], xmm6
00007d516e5da596  movaps [rsp+0x20], xmm15
00007d516e5da59c  lea rdi, [rsp]
00007d516e5da5a0  mov esi, 0x00
00007d516e5da5a5  mov rax, 0x5EE43AF14530
00007d516e5da5af  call rax
00007d516e5da5b1  movaps xmm1, [rsp]
00007d516e5da5b5  add rsp, 0x30
00007d516e5da5b9  vmovaps xmm0, [rsp]
00007d516e5da5be  vmovaps xmm2, [rsp+0x10]
00007d516e5da5c4  vmovaps xmm3, [rsp+0x20]
00007d516e5da5ca  vmovaps xmm4, [rsp+0x30]
00007d516e5da5d0  vmovaps xmm5, [rsp+0x40]
00007d516e5da5d6  vmovaps xmm6, [rsp+0x50]
00007d516e5da5dc  vmovaps xmm7, [rsp+0x60]
00007d516e5da5e2  vmovaps xmm8, [rsp+0x70]
00007d516e5da5e8  vmovaps xmm9, [rsp+0x80]
00007d516e5da5f1  vmovaps xmm10, [rsp+0x90]
00007d516e5da5fa  vmovaps xmm11, [rsp+0xA0]
00007d516e5da603  vmovaps xmm12, [rsp+0xB0]
00007d516e5da60c  vmovaps xmm13, [rsp+0xC0]
00007d516e5da615  vmovaps xmm14, [rsp+0xD0]
00007d516e5da61e  vmovaps xmm15, [rsp+0xE0]
00007d516e5da627  add rsp, 0xF0
00007d516e5da62e  pop r11
00007d516e5da630  pop r10
00007d516e5da632  pop r9
00007d516e5da634  pop r8
00007d516e5da636  pop rsi
00007d516e5da637  pop rdi
00007d516e5da638  pop rdx
00007d516e5da639  pop rcx
00007d516e5da63a  pop rax
00007d516e5da63b  add rsp, 0x08
00007d516e5da63f  jmp 0x00007D516E5D8E48
00007d516e5da644  call 0x00007D516E4E5820
00007d516e5da649  jmp 0x00007D516E5D8E55
00007d516e5da64e  sub rsp, 0x08
00007d516e5da652  push rax
00007d516e5da653  push rcx
00007d516e5da654  push rdx
00007d516e5da655  push rdi
00007d516e5da656  push rsi
00007d516e5da657  push r8
00007d516e5da659  push r9
00007d516e5da65b  push r10
00007d516e5da65d  push r11
00007d516e5da65f  sub rsp, 0xF0
00007d516e5da666  vmovaps [rsp], xmm0
00007d516e5da66b  vmovaps [rsp+0x10], xmm1
00007d516e5da671  vmovaps [rsp+0x20], xmm2
00007d516e5da677  vmovaps [rsp+0x30], xmm3
00007d516e5da67d  vmovaps [rsp+0x40], xmm4
00007d516e5da683  vmovaps [rsp+0x50], xmm5
00007d516e5da689  vmovaps [rsp+0x60], xmm6
00007d516e5da68f  vmovaps [rsp+0x70], xmm7
00007d516e5da695  vmovaps [rsp+0x80], xmm8
00007d516e5da69e  vmovaps [rsp+0x90], xmm9
00007d516e5da6a7  vmovaps [rsp+0xA0], xmm10
00007d516e5da6b0  vmovaps [rsp+0xB0], xmm11
00007d516e5da6b9  vmovaps [rsp+0xC0], xmm12
00007d516e5da6c2  vmovaps [rsp+0xD0], xmm13
00007d516e5da6cb  vmovaps [rsp+0xE0], xmm15
00007d516e5da6d4  sub rsp, 0x30
00007d516e5da6d8  movaps [rsp], xmm14
00007d516e5da6dd  movaps [rsp+0x10], xmm4
00007d516e5da6e2  movaps [rsp+0x20], xmm3
00007d516e5da6e7  lea rdi, [rsp]
00007d516e5da6eb  mov esi, 0x00
00007d516e5da6f0  mov rax, 0x5EE43AF14530
00007d516e5da6fa  call rax
00007d516e5da6fc  movaps xmm14, [rsp]
00007d516e5da701  add rsp, 0x30
00007d516e5da705  vmovaps xmm0, [rsp]
00007d516e5da70a  vmovaps xmm1, [rsp+0x10]
00007d516e5da710  vmovaps xmm2, [rsp+0x20]
00007d516e5da716  vmovaps xmm3, [rsp+0x30]
00007d516e5da71c  vmovaps xmm4, [rsp+0x40]
00007d516e5da722  vmovaps xmm5, [rsp+0x50]
00007d516e5da728  vmovaps xmm6, [rsp+0x60]
00007d516e5da72e  vmovaps xmm7, [rsp+0x70]
00007d516e5da734  vmovaps xmm8, [rsp+0x80]
00007d516e5da73d  vmovaps xmm9, [rsp+0x90]
00007d516e5da746  vmovaps xmm10, [rsp+0xA0]
00007d516e5da74f  vmovaps xmm11, [rsp+0xB0]
00007d516e5da758  vmovaps xmm12, [rsp+0xC0]
00007d516e5da761  vmovaps xmm13, [rsp+0xD0]
00007d516e5da76a  vmovaps xmm15, [rsp+0xE0]
00007d516e5da773  add rsp, 0xF0
00007d516e5da77a  pop r11
00007d516e5da77c  pop r10
00007d516e5da77e  pop r9
00007d516e5da780  pop r8
00007d516e5da782  pop rsi
00007d516e5da783  pop rdi
00007d516e5da784  pop rdx
00007d516e5da785  pop rcx
00007d516e5da786  pop rax
00007d516e5da787  add rsp, 0x08
00007d516e5da78b  jmp 0x00007D516E5D8E6F
00007d516e5da790  sub rsp, 0x08
00007d516e5da794  push rax
00007d516e5da795  push rcx
00007d516e5da796  push rdx
00007d516e5da797  push rdi
00007d516e5da798  push rsi
00007d516e5da799  push r8
00007d516e5da79b  push r9
00007d516e5da79d  push r10
00007d516e5da79f  push r11
00007d516e5da7a1  sub rsp, 0xF0
00007d516e5da7a8  vmovaps [rsp], xmm0
00007d516e5da7ad  vmovaps [rsp+0x10], xmm1
00007d516e5da7b3  vmovaps [rsp+0x20], xmm2
00007d516e5da7b9  vmovaps [rsp+0x30], xmm3
00007d516e5da7bf  vmovaps [rsp+0x40], xmm4
00007d516e5da7c5  vmovaps [rsp+0x50], xmm5
00007d516e5da7cb  vmovaps [rsp+0x60], xmm7
00007d516e5da7d1  vmovaps [rsp+0x70], xmm8
00007d516e5da7d7  vmovaps [rsp+0x80], xmm9
00007d516e5da7e0  vmovaps [rsp+0x90], xmm10
00007d516e5da7e9  vmovaps [rsp+0xA0], xmm11
00007d516e5da7f2  vmovaps [rsp+0xB0], xmm12
00007d516e5da7fb  vmovaps [rsp+0xC0], xmm13
00007d516e5da804  vmovaps [rsp+0xD0], xmm14
00007d516e5da80d  vmovaps [rsp+0xE0], xmm15
00007d516e5da816  sub rsp, 0x30
00007d516e5da81a  movaps [rsp], xmm6
00007d516e5da81e  movaps [rsp+0x10], xmm9
00007d516e5da824  movaps [rsp+0x20], xmm7
00007d516e5da829  lea rdi, [rsp]
00007d516e5da82d  mov esi, 0x00
00007d516e5da832  mov rax, 0x5EE43AF14530
00007d516e5da83c  call rax
00007d516e5da83e  movaps xmm6, [rsp]
00007d516e5da842  add rsp, 0x30
00007d516e5da846  vmovaps xmm0, [rsp]
00007d516e5da84b  vmovaps xmm1, [rsp+0x10]
00007d516e5da851  vmovaps xmm2, [rsp+0x20]
00007d516e5da857  vmovaps xmm3, [rsp+0x30]
00007d516e5da85d  vmovaps xmm4, [rsp+0x40]
00007d516e5da863  vmovaps xmm5, [rsp+0x50]
00007d516e5da869  vmovaps xmm7, [rsp+0x60]
00007d516e5da86f  vmovaps xmm8, [rsp+0x70]
00007d516e5da875  vmovaps xmm9, [rsp+0x80]
00007d516e5da87e  vmovaps xmm10, [rsp+0x90]
00007d516e5da887  vmovaps xmm11, [rsp+0xA0]
00007d516e5da890  vmovaps xmm12, [rsp+0xB0]
00007d516e5da899  vmovaps xmm13, [rsp+0xC0]
00007d516e5da8a2  vmovaps xmm14, [rsp+0xD0]
00007d516e5da8ab  vmovaps xmm15, [rsp+0xE0]
00007d516e5da8b4  add rsp, 0xF0
00007d516e5da8bb  pop r11
00007d516e5da8bd  pop r10
00007d516e5da8bf  pop r9
00007d516e5da8c1  pop r8
00007d516e5da8c3  pop rsi
00007d516e5da8c4  pop rdi
00007d516e5da8c5  pop rdx
00007d516e5da8c6  pop rcx
00007d516e5da8c7  pop rax
00007d516e5da8c8  add rsp, 0x08
00007d516e5da8cc  jmp 0x00007D516E5D8E87
00007d516e5da8d1  sub rsp, 0x08
00007d516e5da8d5  push rax
00007d516e5da8d6  push rcx
00007d516e5da8d7  push rdx
00007d516e5da8d8  push rdi
00007d516e5da8d9  push rsi
00007d516e5da8da  push r8
00007d516e5da8dc  push r9
00007d516e5da8de  push r10
00007d516e5da8e0  push r11
00007d516e5da8e2  sub rsp, 0xF0
00007d516e5da8e9  vmovaps [rsp], xmm0
00007d516e5da8ee  vmovaps [rsp+0x10], xmm1
00007d516e5da8f4  vmovaps [rsp+0x20], xmm2
00007d516e5da8fa  vmovaps [rsp+0x30], xmm3
00007d516e5da900  vmovaps [rsp+0x40], xmm4
00007d516e5da906  vmovaps [rsp+0x50], xmm5
00007d516e5da90c  vmovaps [rsp+0x60], xmm6
00007d516e5da912  vmovaps [rsp+0x70], xmm8
00007d516e5da918  vmovaps [rsp+0x80], xmm9
00007d516e5da921  vmovaps [rsp+0x90], xmm10
00007d516e5da92a  vmovaps [rsp+0xA0], xmm11
00007d516e5da933  vmovaps [rsp+0xB0], xmm12
00007d516e5da93c  vmovaps [rsp+0xC0], xmm13
00007d516e5da945  vmovaps [rsp+0xD0], xmm14
00007d516e5da94e  vmovaps [rsp+0xE0], xmm15
00007d516e5da957  sub rsp, 0x30
00007d516e5da95b  movaps [rsp], xmm7
00007d516e5da95f  movaps [rsp+0x10], xmm4
00007d516e5da964  movaps [rsp+0x20], xmm9
00007d516e5da96a  lea rdi, [rsp]
00007d516e5da96e  mov esi, 0x00
00007d516e5da973  mov rax, 0x5EE43AF14530
00007d516e5da97d  call rax
00007d516e5da97f  movaps xmm7, [rsp]
00007d516e5da983  add rsp, 0x30
00007d516e5da987  vmovaps xmm0, [rsp]
00007d516e5da98c  vmovaps xmm1, [rsp+0x10]
00007d516e5da992  vmovaps xmm2, [rsp+0x20]
00007d516e5da998  vmovaps xmm3, [rsp+0x30]
00007d516e5da99e  vmovaps xmm4, [rsp+0x40]
00007d516e5da9a4  vmovaps xmm5, [rsp+0x50]
00007d516e5da9aa  vmovaps xmm6, [rsp+0x60]
00007d516e5da9b0  vmovaps xmm8, [rsp+0x70]
00007d516e5da9b6  vmovaps xmm9, [rsp+0x80]
00007d516e5da9bf  vmovaps xmm10, [rsp+0x90]
00007d516e5da9c8  vmovaps xmm11, [rsp+0xA0]
00007d516e5da9d1  vmovaps xmm12, [rsp+0xB0]
00007d516e5da9da  vmovaps xmm13, [rsp+0xC0]
00007d516e5da9e3  vmovaps xmm14, [rsp+0xD0]
00007d516e5da9ec  vmovaps xmm15, [rsp+0xE0]
00007d516e5da9f5  add rsp, 0xF0
00007d516e5da9fc  pop r11
00007d516e5da9fe  pop r10
00007d516e5daa00  pop r9
00007d516e5daa02  pop r8
00007d516e5daa04  pop rsi
00007d516e5daa05  pop rdi
00007d516e5daa06  pop rdx
00007d516e5daa07  pop rcx
00007d516e5daa08  pop rax
00007d516e5daa09  add rsp, 0x08
00007d516e5daa0d  jmp 0x00007D516E5D8EB4
00007d516e5daa12  sub rsp, 0x08
00007d516e5daa16  push rax
00007d516e5daa17  push rcx
00007d516e5daa18  push rdx
00007d516e5daa19  push rdi
00007d516e5daa1a  push rsi
00007d516e5daa1b  push r8
00007d516e5daa1d  push r9
00007d516e5daa1f  push r10
00007d516e5daa21  push r11
00007d516e5daa23  sub rsp, 0xF0
00007d516e5daa2a  vmovaps [rsp], xmm0
00007d516e5daa2f  vmovaps [rsp+0x10], xmm1
00007d516e5daa35  vmovaps [rsp+0x20], xmm2
00007d516e5daa3b  vmovaps [rsp+0x30], xmm3
00007d516e5daa41  vmovaps [rsp+0x40], xmm5
00007d516e5daa47  vmovaps [rsp+0x50], xmm6
00007d516e5daa4d  vmovaps [rsp+0x60], xmm7
00007d516e5daa53  vmovaps [rsp+0x70], xmm8
00007d516e5daa59  vmovaps [rsp+0x80], xmm9
00007d516e5daa62  vmovaps [rsp+0x90], xmm10
00007d516e5daa6b  vmovaps [rsp+0xA0], xmm11
00007d516e5daa74  vmovaps [rsp+0xB0], xmm12
00007d516e5daa7d  vmovaps [rsp+0xC0], xmm13
00007d516e5daa86  vmovaps [rsp+0xD0], xmm14
00007d516e5daa8f  vmovaps [rsp+0xE0], xmm15
00007d516e5daa98  sub rsp, 0x30
00007d516e5daa9c  movaps [rsp], xmm4
00007d516e5daaa0  movaps [rsp+0x10], xmm15
00007d516e5daaa6  movaps [rsp+0x20], xmm9
00007d516e5daaac  lea rdi, [rsp]
00007d516e5daab0  mov esi, 0x00
00007d516e5daab5  mov rax, 0x5EE43AF14530
00007d516e5daabf  call rax
00007d516e5daac1  movaps xmm4, [rsp]
00007d516e5daac5  add rsp, 0x30
00007d516e5daac9  vmovaps xmm0, [rsp]
00007d516e5daace  vmovaps xmm1, [rsp+0x10]
00007d516e5daad4  vmovaps xmm2, [rsp+0x20]
00007d516e5daada  vmovaps xmm3, [rsp+0x30]
00007d516e5daae0  vmovaps xmm5, [rsp+0x40]
00007d516e5daae6  vmovaps xmm6, [rsp+0x50]
00007d516e5daaec  vmovaps xmm7, [rsp+0x60]
00007d516e5daaf2  vmovaps xmm8, [rsp+0x70]
00007d516e5daaf8  vmovaps xmm9, [rsp+0x80]
00007d516e5dab01  vmovaps xmm10, [rsp+0x90]
00007d516e5dab0a  vmovaps xmm11, [rsp+0xA0]
00007d516e5dab13  vmovaps xmm12, [rsp+0xB0]
00007d516e5dab1c  vmovaps xmm13, [rsp+0xC0]
00007d516e5dab25  vmovaps xmm14, [rsp+0xD0]
00007d516e5dab2e  vmovaps xmm15, [rsp+0xE0]
00007d516e5dab37  add rsp, 0xF0
00007d516e5dab3e  pop r11
00007d516e5dab40  pop r10
00007d516e5dab42  pop r9
00007d516e5dab44  pop r8
00007d516e5dab46  pop rsi
00007d516e5dab47  pop rdi
00007d516e5dab48  pop rdx
00007d516e5dab49  pop rcx
00007d516e5dab4a  pop rax
00007d516e5dab4b  add rsp, 0x08
00007d516e5dab4f  jmp 0x00007D516E5D8ED9
00007d516e5dab54  call 0x00007D516E4E5820
00007d516e5dab59  jmp 0x00007D516E5D8EE6
00007d516e5dab5e  sub rsp, 0x08
00007d516e5dab62  push rax
00007d516e5dab63  push rcx
00007d516e5dab64  push rdx
00007d516e5dab65  push rdi
00007d516e5dab66  push rsi
00007d516e5dab67  push r8
00007d516e5dab69  push r9
00007d516e5dab6b  push r10
00007d516e5dab6d  push r11
00007d516e5dab6f  sub rsp, 0xF0
00007d516e5dab76  vmovaps [rsp], xmm0
00007d516e5dab7b  vmovaps [rsp+0x10], xmm1
00007d516e5dab81  vmovaps [rsp+0x20], xmm2
00007d516e5dab87  vmovaps [rsp+0x30], xmm4
00007d516e5dab8d  vmovaps [rsp+0x40], xmm5
00007d516e5dab93  vmovaps [rsp+0x50], xmm6
00007d516e5dab99  vmovaps [rsp+0x60], xmm7
00007d516e5dab9f  vmovaps [rsp+0x70], xmm8
00007d516e5daba5  vmovaps [rsp+0x80], xmm9
00007d516e5dabae  vmovaps [rsp+0x90], xmm10
00007d516e5dabb7  vmovaps [rsp+0xA0], xmm11
00007d516e5dabc0  vmovaps [rsp+0xB0], xmm12
00007d516e5dabc9  vmovaps [rsp+0xC0], xmm13
00007d516e5dabd2  vmovaps [rsp+0xD0], xmm14
00007d516e5dabdb  vmovaps [rsp+0xE0], xmm15
00007d516e5dabe4  sub rsp, 0x30
00007d516e5dabe8  movaps [rsp], xmm3
00007d516e5dabec  movaps [rsp+0x10], xmm1
00007d516e5dabf1  movaps [rsp+0x20], xmm9
00007d516e5dabf7  lea rdi, [rsp]
00007d516e5dabfb  mov esi, 0x00
00007d516e5dac00  mov rax, 0x5EE43AF14530
00007d516e5dac0a  call rax
00007d516e5dac0c  movaps xmm3, [rsp]
00007d516e5dac10  add rsp, 0x30
00007d516e5dac14  vmovaps xmm0, [rsp]
00007d516e5dac19  vmovaps xmm1, [rsp+0x10]
00007d516e5dac1f  vmovaps xmm2, [rsp+0x20]
00007d516e5dac25  vmovaps xmm4, [rsp+0x30]
00007d516e5dac2b  vmovaps xmm5, [rsp+0x40]
00007d516e5dac31  vmovaps xmm6, [rsp+0x50]
00007d516e5dac37  vmovaps xmm7, [rsp+0x60]
00007d516e5dac3d  vmovaps xmm8, [rsp+0x70]
00007d516e5dac43  vmovaps xmm9, [rsp+0x80]
00007d516e5dac4c  vmovaps xmm10, [rsp+0x90]
00007d516e5dac55  vmovaps xmm11, [rsp+0xA0]
00007d516e5dac5e  vmovaps xmm12, [rsp+0xB0]
00007d516e5dac67  vmovaps xmm13, [rsp+0xC0]
00007d516e5dac70  vmovaps xmm14, [rsp+0xD0]
00007d516e5dac79  vmovaps xmm15, [rsp+0xE0]
00007d516e5dac82  add rsp, 0xF0
00007d516e5dac89  pop r11
00007d516e5dac8b  pop r10
00007d516e5dac8d  pop r9
00007d516e5dac8f  pop r8
00007d516e5dac91  pop rsi
00007d516e5dac92  pop rdi
00007d516e5dac93  pop rdx
00007d516e5dac94  pop rcx
00007d516e5dac95  pop rax
00007d516e5dac96  add rsp, 0x08
00007d516e5dac9a  jmp 0x00007D516E5D8F23
00007d516e5dac9f  sub rsp, 0x08
00007d516e5daca3  push rax
00007d516e5daca4  push rcx
00007d516e5daca5  push rdx
00007d516e5daca6  push rdi
00007d516e5daca7  push rsi
00007d516e5daca8  push r8
00007d516e5dacaa  push r9
00007d516e5dacac  push r10
00007d516e5dacae  push r11
00007d516e5dacb0  sub rsp, 0xF0
00007d516e5dacb7  vmovaps [rsp], xmm0
00007d516e5dacbc  vmovaps [rsp+0x10], xmm2
00007d516e5dacc2  vmovaps [rsp+0x20], xmm3
00007d516e5dacc8  vmovaps [rsp+0x30], xmm4
00007d516e5dacce  vmovaps [rsp+0x40], xmm5
00007d516e5dacd4  vmovaps [rsp+0x50], xmm6
00007d516e5dacda  vmovaps [rsp+0x60], xmm7
00007d516e5dace0  vmovaps [rsp+0x70], xmm8
00007d516e5dace6  vmovaps [rsp+0x80], xmm9
00007d516e5dacef  vmovaps [rsp+0x90], xmm10
00007d516e5dacf8  vmovaps [rsp+0xA0], xmm11
00007d516e5dad01  vmovaps [rsp+0xB0], xmm12
00007d516e5dad0a  vmovaps [rsp+0xC0], xmm13
00007d516e5dad13  vmovaps [rsp+0xD0], xmm14
00007d516e5dad1c  vmovaps [rsp+0xE0], xmm15
00007d516e5dad25  sub rsp, 0x30
00007d516e5dad29  movaps [rsp], xmm1
00007d516e5dad2d  movaps [rsp+0x10], xmm15
00007d516e5dad33  movaps [rsp+0x20], xmm9
00007d516e5dad39  lea rdi, [rsp]
00007d516e5dad3d  mov esi, 0x00
00007d516e5dad42  mov rax, 0x5EE43AF14530
00007d516e5dad4c  call rax
00007d516e5dad4e  movaps xmm1, [rsp]
00007d516e5dad52  add rsp, 0x30
00007d516e5dad56  vmovaps xmm0, [rsp]
00007d516e5dad5b  vmovaps xmm2, [rsp+0x10]
00007d516e5dad61  vmovaps xmm3, [rsp+0x20]
00007d516e5dad67  vmovaps xmm4, [rsp+0x30]
00007d516e5dad6d  vmovaps xmm5, [rsp+0x40]
00007d516e5dad73  vmovaps xmm6, [rsp+0x50]
00007d516e5dad79  vmovaps xmm7, [rsp+0x60]
00007d516e5dad7f  vmovaps xmm8, [rsp+0x70]
00007d516e5dad85  vmovaps xmm9, [rsp+0x80]
00007d516e5dad8e  vmovaps xmm10, [rsp+0x90]
00007d516e5dad97  vmovaps xmm11, [rsp+0xA0]
00007d516e5dada0  vmovaps xmm12, [rsp+0xB0]
00007d516e5dada9  vmovaps xmm13, [rsp+0xC0]
00007d516e5dadb2  vmovaps xmm14, [rsp+0xD0]
00007d516e5dadbb  vmovaps xmm15, [rsp+0xE0]
00007d516e5dadc4  add rsp, 0xF0
00007d516e5dadcb  pop r11
00007d516e5dadcd  pop r10
00007d516e5dadcf  pop r9
00007d516e5dadd1  pop r8
00007d516e5dadd3  pop rsi
00007d516e5dadd4  pop rdi
00007d516e5dadd5  pop rdx
00007d516e5dadd6  pop rcx
00007d516e5dadd7  pop rax
00007d516e5dadd8  add rsp, 0x08
00007d516e5daddc  jmp 0x00007D516E5D8FAB
00007d516e5dade1  call 0x00007D516E4E5820
00007d516e5dade6  jmp 0x00007D516E5D8FB8
00007d516e5dadeb  sub rsp, 0x08
00007d516e5dadef  push rax
00007d516e5dadf0  push rcx
00007d516e5dadf1  push rdx
00007d516e5dadf2  push rdi
00007d516e5dadf3  push rsi
00007d516e5dadf4  push r8
00007d516e5dadf6  push r9
00007d516e5dadf8  push r10
00007d516e5dadfa  push r11
00007d516e5dadfc  sub rsp, 0xF0
00007d516e5dae03  vmovaps [rsp], xmm0
00007d516e5dae08  vmovaps [rsp+0x10], xmm2
00007d516e5dae0e  vmovaps [rsp+0x20], xmm3
00007d516e5dae14  vmovaps [rsp+0x30], xmm4
00007d516e5dae1a  vmovaps [rsp+0x40], xmm5
00007d516e5dae20  vmovaps [rsp+0x50], xmm6
00007d516e5dae26  vmovaps [rsp+0x60], xmm7
00007d516e5dae2c  vmovaps [rsp+0x70], xmm8
00007d516e5dae32  vmovaps [rsp+0x80], xmm9
00007d516e5dae3b  vmovaps [rsp+0x90], xmm10
00007d516e5dae44  vmovaps [rsp+0xA0], xmm11
00007d516e5dae4d  vmovaps [rsp+0xB0], xmm12
00007d516e5dae56  vmovaps [rsp+0xC0], xmm13
00007d516e5dae5f  vmovaps [rsp+0xD0], xmm14
00007d516e5dae68  vmovaps [rsp+0xE0], xmm15
00007d516e5dae71  sub rsp, 0x30
00007d516e5dae75  movaps [rsp], xmm1
00007d516e5dae79  movaps [rsp+0x10], xmm5
00007d516e5dae7e  movaps [rsp+0x20], xmm7
00007d516e5dae83  lea rdi, [rsp]
00007d516e5dae87  mov esi, 0x00
00007d516e5dae8c  mov rax, 0x5EE43AF14530
00007d516e5dae96  call rax
00007d516e5dae98  movaps xmm1, [rsp]
00007d516e5dae9c  add rsp, 0x30
00007d516e5daea0  vmovaps xmm0, [rsp]
00007d516e5daea5  vmovaps xmm2, [rsp+0x10]
00007d516e5daeab  vmovaps xmm3, [rsp+0x20]
00007d516e5daeb1  vmovaps xmm4, [rsp+0x30]
00007d516e5daeb7  vmovaps xmm5, [rsp+0x40]
00007d516e5daebd  vmovaps xmm6, [rsp+0x50]
00007d516e5daec3  vmovaps xmm7, [rsp+0x60]
00007d516e5daec9  vmovaps xmm8, [rsp+0x70]
00007d516e5daecf  vmovaps xmm9, [rsp+0x80]
00007d516e5daed8  vmovaps xmm10, [rsp+0x90]
00007d516e5daee1  vmovaps xmm11, [rsp+0xA0]
00007d516e5daeea  vmovaps xmm12, [rsp+0xB0]
00007d516e5daef3  vmovaps xmm13, [rsp+0xC0]
00007d516e5daefc  vmovaps xmm14, [rsp+0xD0]
00007d516e5daf05  vmovaps xmm15, [rsp+0xE0]
00007d516e5daf0e  add rsp, 0xF0
00007d516e5daf15  pop r11
00007d516e5daf17  pop r10
00007d516e5daf19  pop r9
00007d516e5daf1b  pop r8
00007d516e5daf1d  pop rsi
00007d516e5daf1e  pop rdi
00007d516e5daf1f  pop rdx
00007d516e5daf20  pop rcx
00007d516e5daf21  pop rax
00007d516e5daf22  add rsp, 0x08
00007d516e5daf26  jmp 0x00007D516E5D905D
00007d516e5daf2b  sub rsp, 0x08
00007d516e5daf2f  push rax
00007d516e5daf30  push rcx
00007d516e5daf31  push rdx
00007d516e5daf32  push rdi
00007d516e5daf33  push rsi
00007d516e5daf34  push r8
00007d516e5daf36  push r9
00007d516e5daf38  push r10
00007d516e5daf3a  push r11
00007d516e5daf3c  sub rsp, 0xF0
00007d516e5daf43  vmovaps [rsp], xmm0
00007d516e5daf48  vmovaps [rsp+0x10], xmm1
00007d516e5daf4e  vmovaps [rsp+0x20], xmm2
00007d516e5daf54  vmovaps [rsp+0x30], xmm3
00007d516e5daf5a  vmovaps [rsp+0x40], xmm4
00007d516e5daf60  vmovaps [rsp+0x50], xmm5
00007d516e5daf66  vmovaps [rsp+0x60], xmm6
00007d516e5daf6c  vmovaps [rsp+0x70], xmm8
00007d516e5daf72  vmovaps [rsp+0x80], xmm9
00007d516e5daf7b  vmovaps [rsp+0x90], xmm10
00007d516e5daf84  vmovaps [rsp+0xA0], xmm11
00007d516e5daf8d  vmovaps [rsp+0xB0], xmm12
00007d516e5daf96  vmovaps [rsp+0xC0], xmm13
00007d516e5daf9f  vmovaps [rsp+0xD0], xmm14
00007d516e5dafa8  vmovaps [rsp+0xE0], xmm15
00007d516e5dafb1  sub rsp, 0x30
00007d516e5dafb5  movaps [rsp], xmm7
00007d516e5dafb9  movaps [rsp+0x10], xmm5
00007d516e5dafbe  movaps [rsp+0x20], xmm15
00007d516e5dafc4  lea rdi, [rsp]
00007d516e5dafc8  mov esi, 0x00
00007d516e5dafcd  mov rax, 0x5EE43AF14530
00007d516e5dafd7  call rax
00007d516e5dafd9  movaps xmm7, [rsp]
00007d516e5dafdd  add rsp, 0x30
00007d516e5dafe1  vmovaps xmm0, [rsp]
00007d516e5dafe6  vmovaps xmm1, [rsp+0x10]
00007d516e5dafec  vmovaps xmm2, [rsp+0x20]
00007d516e5daff2  vmovaps xmm3, [rsp+0x30]
00007d516e5daff8  vmovaps xmm4, [rsp+0x40]
00007d516e5daffe  vmovaps xmm5, [rsp+0x50]
00007d516e5db004  vmovaps xmm6, [rsp+0x60]
00007d516e5db00a  vmovaps xmm8, [rsp+0x70]
00007d516e5db010  vmovaps xmm9, [rsp+0x80]
00007d516e5db019  vmovaps xmm10, [rsp+0x90]
00007d516e5db022  vmovaps xmm11, [rsp+0xA0]
00007d516e5db02b  vmovaps xmm12, [rsp+0xB0]
00007d516e5db034  vmovaps xmm13, [rsp+0xC0]
00007d516e5db03d  vmovaps xmm14, [rsp+0xD0]
00007d516e5db046  vmovaps xmm15, [rsp+0xE0]
00007d516e5db04f  add rsp, 0xF0
00007d516e5db056  pop r11
00007d516e5db058  pop r10
00007d516e5db05a  pop r9
00007d516e5db05c  pop r8
00007d516e5db05e  pop rsi
00007d516e5db05f  pop rdi
00007d516e5db060  pop rdx
00007d516e5db061  pop rcx
00007d516e5db062  pop rax
00007d516e5db063  add rsp, 0x08
00007d516e5db067  jmp 0x00007D516E5D9093
00007d516e5db06c  call 0x00007D516E4D64F0
00007d516e5db071  jmp 0x00007D516E5D90A0
00007d516e5db076  sub rsp, 0x08
00007d516e5db07a  push rax
00007d516e5db07b  push rcx
00007d516e5db07c  push rdx
00007d516e5db07d  push rdi
00007d516e5db07e  push rsi
00007d516e5db07f  push r8
00007d516e5db081  push r9
00007d516e5db083  push r10
00007d516e5db085  push r11
00007d516e5db087  sub rsp, 0xF0
00007d516e5db08e  vmovaps [rsp], xmm0
00007d516e5db093  vmovaps [rsp+0x10], xmm1
00007d516e5db099  vmovaps [rsp+0x20], xmm2
00007d516e5db09f  vmovaps [rsp+0x30], xmm3
00007d516e5db0a5  vmovaps [rsp+0x40], xmm4
00007d516e5db0ab  vmovaps [rsp+0x50], xmm5
00007d516e5db0b1  vmovaps [rsp+0x60], xmm6
00007d516e5db0b7  vmovaps [rsp+0x70], xmm7
00007d516e5db0bd  vmovaps [rsp+0x80], xmm8
00007d516e5db0c6  vmovaps [rsp+0x90], xmm9
00007d516e5db0cf  vmovaps [rsp+0xA0], xmm10
00007d516e5db0d8  vmovaps [rsp+0xB0], xmm11
00007d516e5db0e1  vmovaps [rsp+0xC0], xmm12
00007d516e5db0ea  vmovaps [rsp+0xD0], xmm13
00007d516e5db0f3  vmovaps [rsp+0xE0], xmm14
00007d516e5db0fc  sub rsp, 0x30
00007d516e5db100  movaps [rsp], xmm15
00007d516e5db105  movaps [rsp+0x10], xmm5
00007d516e5db10a  movaps [rsp+0x20], xmm3
00007d516e5db10f  lea rdi, [rsp]
00007d516e5db113  mov esi, 0x00
00007d516e5db118  mov rax, 0x5EE43AF14530
00007d516e5db122  call rax
00007d516e5db124  movaps xmm15, [rsp]
00007d516e5db129  add rsp, 0x30
00007d516e5db12d  vmovaps xmm0, [rsp]
00007d516e5db132  vmovaps xmm1, [rsp+0x10]
00007d516e5db138  vmovaps xmm2, [rsp+0x20]
00007d516e5db13e  vmovaps xmm3, [rsp+0x30]
00007d516e5db144  vmovaps xmm4, [rsp+0x40]
00007d516e5db14a  vmovaps xmm5, [rsp+0x50]
00007d516e5db150  vmovaps xmm6, [rsp+0x60]
00007d516e5db156  vmovaps xmm7, [rsp+0x70]
00007d516e5db15c  vmovaps xmm8, [rsp+0x80]
00007d516e5db165  vmovaps xmm9, [rsp+0x90]
00007d516e5db16e  vmovaps xmm10, [rsp+0xA0]
00007d516e5db177  vmovaps xmm11, [rsp+0xB0]
00007d516e5db180  vmovaps xmm12, [rsp+0xC0]
00007d516e5db189  vmovaps xmm13, [rsp+0xD0]
00007d516e5db192  vmovaps xmm14, [rsp+0xE0]
00007d516e5db19b  add rsp, 0xF0
00007d516e5db1a2  pop r11
00007d516e5db1a4  pop r10
00007d516e5db1a6  pop r9
00007d516e5db1a8  pop r8
00007d516e5db1aa  pop rsi
00007d516e5db1ab  pop rdi
00007d516e5db1ac  pop rdx
00007d516e5db1ad  pop rcx
00007d516e5db1ae  pop rax
00007d516e5db1af  add rsp, 0x08
00007d516e5db1b3  jmp 0x00007D516E5D90C6
00007d516e5db1b8  sub rsp, 0x08
00007d516e5db1bc  push rax
00007d516e5db1bd  push rcx
00007d516e5db1be  push rdx
00007d516e5db1bf  push rdi
00007d516e5db1c0  push rsi
00007d516e5db1c1  push r8
00007d516e5db1c3  push r9
00007d516e5db1c5  push r10
00007d516e5db1c7  push r11
00007d516e5db1c9  sub rsp, 0xF0
00007d516e5db1d0  vmovaps [rsp], xmm0
00007d516e5db1d5  vmovaps [rsp+0x10], xmm2
00007d516e5db1db  vmovaps [rsp+0x20], xmm3
00007d516e5db1e1  vmovaps [rsp+0x30], xmm4
00007d516e5db1e7  vmovaps [rsp+0x40], xmm5
00007d516e5db1ed  vmovaps [rsp+0x50], xmm6
00007d516e5db1f3  vmovaps [rsp+0x60], xmm7
00007d516e5db1f9  vmovaps [rsp+0x70], xmm8
00007d516e5db1ff  vmovaps [rsp+0x80], xmm9
00007d516e5db208  vmovaps [rsp+0x90], xmm10
00007d516e5db211  vmovaps [rsp+0xA0], xmm11
00007d516e5db21a  vmovaps [rsp+0xB0], xmm12
00007d516e5db223  vmovaps [rsp+0xC0], xmm13
00007d516e5db22c  vmovaps [rsp+0xD0], xmm14
00007d516e5db235  vmovaps [rsp+0xE0], xmm15
00007d516e5db23e  sub rsp, 0x30
00007d516e5db242  movaps [rsp], xmm1
00007d516e5db246  movaps [rsp+0x10], xmm5
00007d516e5db24b  movaps [rsp+0x20], xmm4
00007d516e5db250  lea rdi, [rsp]
00007d516e5db254  mov esi, 0x00
00007d516e5db259  mov rax, 0x5EE43AF14530
00007d516e5db263  call rax
00007d516e5db265  movaps xmm1, [rsp]
00007d516e5db269  add rsp, 0x30
00007d516e5db26d  vmovaps xmm0, [rsp]
00007d516e5db272  vmovaps xmm2, [rsp+0x10]
00007d516e5db278  vmovaps xmm3, [rsp+0x20]
00007d516e5db27e  vmovaps xmm4, [rsp+0x30]
00007d516e5db284  vmovaps xmm5, [rsp+0x40]
00007d516e5db28a  vmovaps xmm6, [rsp+0x50]
00007d516e5db290  vmovaps xmm7, [rsp+0x60]
00007d516e5db296  vmovaps xmm8, [rsp+0x70]
00007d516e5db29c  vmovaps xmm9, [rsp+0x80]
00007d516e5db2a5  vmovaps xmm10, [rsp+0x90]
00007d516e5db2ae  vmovaps xmm11, [rsp+0xA0]
00007d516e5db2b7  vmovaps xmm12, [rsp+0xB0]
00007d516e5db2c0  vmovaps xmm13, [rsp+0xC0]
00007d516e5db2c9  vmovaps xmm14, [rsp+0xD0]
00007d516e5db2d2  vmovaps xmm15, [rsp+0xE0]
00007d516e5db2db  add rsp, 0xF0
00007d516e5db2e2  pop r11
00007d516e5db2e4  pop r10
00007d516e5db2e6  pop r9
00007d516e5db2e8  pop r8
00007d516e5db2ea  pop rsi
00007d516e5db2eb  pop rdi
00007d516e5db2ec  pop rdx
00007d516e5db2ed  pop rcx
00007d516e5db2ee  pop rax
00007d516e5db2ef  add rsp, 0x08
00007d516e5db2f3  jmp 0x00007D516E5D90E6
00007d516e5db2f8  sub rsp, 0x08
00007d516e5db2fc  push rax
00007d516e5db2fd  push rcx
00007d516e5db2fe  push rdx
00007d516e5db2ff  push rdi
00007d516e5db300  push rsi
00007d516e5db301  push r8
00007d516e5db303  push r9
00007d516e5db305  push r10
00007d516e5db307  push r11
00007d516e5db309  sub rsp, 0xF0
00007d516e5db310  vmovaps [rsp], xmm0
00007d516e5db315  vmovaps [rsp+0x10], xmm1
00007d516e5db31b  vmovaps [rsp+0x20], xmm2
00007d516e5db321  vmovaps [rsp+0x30], xmm3
00007d516e5db327  vmovaps [rsp+0x40], xmm5
00007d516e5db32d  vmovaps [rsp+0x50], xmm6
00007d516e5db333  vmovaps [rsp+0x60], xmm7
00007d516e5db339  vmovaps [rsp+0x70], xmm8
00007d516e5db33f  vmovaps [rsp+0x80], xmm9
00007d516e5db348  vmovaps [rsp+0x90], xmm10
00007d516e5db351  vmovaps [rsp+0xA0], xmm11
00007d516e5db35a  vmovaps [rsp+0xB0], xmm12
00007d516e5db363  vmovaps [rsp+0xC0], xmm13
00007d516e5db36c  vmovaps [rsp+0xD0], xmm14
00007d516e5db375  vmovaps [rsp+0xE0], xmm15
00007d516e5db37e  sub rsp, 0x30
00007d516e5db382  movaps [rsp], xmm4
00007d516e5db386  movaps [rsp+0x10], xmm3
00007d516e5db38b  movaps [rsp+0x20], xmm5
00007d516e5db390  lea rdi, [rsp]
00007d516e5db394  mov esi, 0x00
00007d516e5db399  mov rax, 0x5EE43AF14530
00007d516e5db3a3  call rax
00007d516e5db3a5  movaps xmm4, [rsp]
00007d516e5db3a9  add rsp, 0x30
00007d516e5db3ad  vmovaps xmm0, [rsp]
00007d516e5db3b2  vmovaps xmm1, [rsp+0x10]
00007d516e5db3b8  vmovaps xmm2, [rsp+0x20]
00007d516e5db3be  vmovaps xmm3, [rsp+0x30]
00007d516e5db3c4  vmovaps xmm5, [rsp+0x40]
00007d516e5db3ca  vmovaps xmm6, [rsp+0x50]
00007d516e5db3d0  vmovaps xmm7, [rsp+0x60]
00007d516e5db3d6  vmovaps xmm8, [rsp+0x70]
00007d516e5db3dc  vmovaps xmm9, [rsp+0x80]
00007d516e5db3e5  vmovaps xmm10, [rsp+0x90]
00007d516e5db3ee  vmovaps xmm11, [rsp+0xA0]
00007d516e5db3f7  vmovaps xmm12, [rsp+0xB0]
00007d516e5db400  vmovaps xmm13, [rsp+0xC0]
00007d516e5db409  vmovaps xmm14, [rsp+0xD0]
00007d516e5db412  vmovaps xmm15, [rsp+0xE0]
00007d516e5db41b  add rsp, 0xF0
00007d516e5db422  pop r11
00007d516e5db424  pop r10
00007d516e5db426  pop r9
00007d516e5db428  pop r8
00007d516e5db42a  pop rsi
00007d516e5db42b  pop rdi
00007d516e5db42c  pop rdx
00007d516e5db42d  pop rcx
00007d516e5db42e  pop rax
00007d516e5db42f  add rsp, 0x08
00007d516e5db433  jmp 0x00007D516E5D9134
00007d516e5db438  call 0x00007D516E4D64F0
00007d516e5db43d  jmp 0x00007D516E5D9141
00007d516e5db442  sub rsp, 0x08
00007d516e5db446  push rax
00007d516e5db447  push rcx
00007d516e5db448  push rdx
00007d516e5db449  push rdi
00007d516e5db44a  push rsi
00007d516e5db44b  push r8
00007d516e5db44d  push r9
00007d516e5db44f  push r10
00007d516e5db451  push r11
00007d516e5db453  sub rsp, 0xF0
00007d516e5db45a  vmovaps [rsp], xmm0
00007d516e5db45f  vmovaps [rsp+0x10], xmm1
00007d516e5db465  vmovaps [rsp+0x20], xmm2
00007d516e5db46b  vmovaps [rsp+0x30], xmm3
00007d516e5db471  vmovaps [rsp+0x40], xmm4
00007d516e5db477  vmovaps [rsp+0x50], xmm6
00007d516e5db47d  vmovaps [rsp+0x60], xmm7
00007d516e5db483  vmovaps [rsp+0x70], xmm8
00007d516e5db489  vmovaps [rsp+0x80], xmm9
00007d516e5db492  vmovaps [rsp+0x90], xmm10
00007d516e5db49b  vmovaps [rsp+0xA0], xmm11
00007d516e5db4a4  vmovaps [rsp+0xB0], xmm12
00007d516e5db4ad  vmovaps [rsp+0xC0], xmm13
00007d516e5db4b6  vmovaps [rsp+0xD0], xmm14
00007d516e5db4bf  vmovaps [rsp+0xE0], xmm15
00007d516e5db4c8  sub rsp, 0x30
00007d516e5db4cc  movaps [rsp], xmm5
00007d516e5db4d0  movaps [rsp+0x10], xmm6
00007d516e5db4d5  movaps [rsp+0x20], xmm3
00007d516e5db4da  lea rdi, [rsp]
00007d516e5db4de  mov esi, 0x00
00007d516e5db4e3  mov rax, 0x5EE43AF14530
00007d516e5db4ed  call rax
00007d516e5db4ef  movaps xmm5, [rsp]
00007d516e5db4f3  add rsp, 0x30
00007d516e5db4f7  vmovaps xmm0, [rsp]
00007d516e5db4fc  vmovaps xmm1, [rsp+0x10]
00007d516e5db502  vmovaps xmm2, [rsp+0x20]
00007d516e5db508  vmovaps xmm3, [rsp+0x30]
00007d516e5db50e  vmovaps xmm4, [rsp+0x40]
00007d516e5db514  vmovaps xmm6, [rsp+0x50]
00007d516e5db51a  vmovaps xmm7, [rsp+0x60]
00007d516e5db520  vmovaps xmm8, [rsp+0x70]
00007d516e5db526  vmovaps xmm9, [rsp+0x80]
00007d516e5db52f  vmovaps xmm10, [rsp+0x90]
00007d516e5db538  vmovaps xmm11, [rsp+0xA0]
00007d516e5db541  vmovaps xmm12, [rsp+0xB0]
00007d516e5db54a  vmovaps xmm13, [rsp+0xC0]
00007d516e5db553  vmovaps xmm14, [rsp+0xD0]
00007d516e5db55c  vmovaps xmm15, [rsp+0xE0]
00007d516e5db565  add rsp, 0xF0
00007d516e5db56c  pop r11
00007d516e5db56e  pop r10
00007d516e5db570  pop r9
00007d516e5db572  pop r8
00007d516e5db574  pop rsi
00007d516e5db575  pop rdi
00007d516e5db576  pop rdx
00007d516e5db577  pop rcx
00007d516e5db578  pop rax
00007d516e5db579  add rsp, 0x08
00007d516e5db57d  jmp 0x00007D516E5D9167
00007d516e5db582  sub rsp, 0x08
00007d516e5db586  push rax
00007d516e5db587  push rcx
00007d516e5db588  push rdx
00007d516e5db589  push rdi
00007d516e5db58a  push rsi
00007d516e5db58b  push r8
00007d516e5db58d  push r9
00007d516e5db58f  push r10
00007d516e5db591  push r11
00007d516e5db593  sub rsp, 0xF0
00007d516e5db59a  vmovaps [rsp], xmm0
00007d516e5db59f  vmovaps [rsp+0x10], xmm1
00007d516e5db5a5  vmovaps [rsp+0x20], xmm2
00007d516e5db5ab  vmovaps [rsp+0x30], xmm3
00007d516e5db5b1  vmovaps [rsp+0x40], xmm4
00007d516e5db5b7  vmovaps [rsp+0x50], xmm5
00007d516e5db5bd  vmovaps [rsp+0x60], xmm7
00007d516e5db5c3  vmovaps [rsp+0x70], xmm8
00007d516e5db5c9  vmovaps [rsp+0x80], xmm9
00007d516e5db5d2  vmovaps [rsp+0x90], xmm10
00007d516e5db5db  vmovaps [rsp+0xA0], xmm11
00007d516e5db5e4  vmovaps [rsp+0xB0], xmm12
00007d516e5db5ed  vmovaps [rsp+0xC0], xmm13
00007d516e5db5f6  vmovaps [rsp+0xD0], xmm14
00007d516e5db5ff  vmovaps [rsp+0xE0], xmm15
00007d516e5db608  sub rsp, 0x30
00007d516e5db60c  movaps [rsp], xmm6
00007d516e5db610  movaps [rsp+0x10], xmm9
00007d516e5db616  movaps [rsp+0x20], xmm1
00007d516e5db61b  lea rdi, [rsp]
00007d516e5db61f  mov esi, 0x00
00007d516e5db624  mov rax, 0x5EE43AF14530
00007d516e5db62e  call rax
00007d516e5db630  movaps xmm6, [rsp]
00007d516e5db634  add rsp, 0x30
00007d516e5db638  vmovaps xmm0, [rsp]
00007d516e5db63d  vmovaps xmm1, [rsp+0x10]
00007d516e5db643  vmovaps xmm2, [rsp+0x20]
00007d516e5db649  vmovaps xmm3, [rsp+0x30]
00007d516e5db64f  vmovaps xmm4, [rsp+0x40]
00007d516e5db655  vmovaps xmm5, [rsp+0x50]
00007d516e5db65b  vmovaps xmm7, [rsp+0x60]
00007d516e5db661  vmovaps xmm8, [rsp+0x70]
00007d516e5db667  vmovaps xmm9, [rsp+0x80]
00007d516e5db670  vmovaps xmm10, [rsp+0x90]
00007d516e5db679  vmovaps xmm11, [rsp+0xA0]
00007d516e5db682  vmovaps xmm12, [rsp+0xB0]
00007d516e5db68b  vmovaps xmm13, [rsp+0xC0]
00007d516e5db694  vmovaps xmm14, [rsp+0xD0]
00007d516e5db69d  vmovaps xmm15, [rsp+0xE0]
00007d516e5db6a6  add rsp, 0xF0
00007d516e5db6ad  pop r11
00007d516e5db6af  pop r10
00007d516e5db6b1  pop r9
00007d516e5db6b3  pop r8
00007d516e5db6b5  pop rsi
00007d516e5db6b6  pop rdi
00007d516e5db6b7  pop rdx
00007d516e5db6b8  pop rcx
00007d516e5db6b9  pop rax
00007d516e5db6ba  add rsp, 0x08
00007d516e5db6be  jmp 0x00007D516E5D918B
00007d516e5db6c3  sub rsp, 0x08
00007d516e5db6c7  push rax
00007d516e5db6c8  push rcx
00007d516e5db6c9  push rdx
00007d516e5db6ca  push rdi
00007d516e5db6cb  push rsi
00007d516e5db6cc  push r8
00007d516e5db6ce  push r9
00007d516e5db6d0  push r10
00007d516e5db6d2  push r11
00007d516e5db6d4  sub rsp, 0xF0
00007d516e5db6db  vmovaps [rsp], xmm0
00007d516e5db6e0  vmovaps [rsp+0x10], xmm1
00007d516e5db6e6  vmovaps [rsp+0x20], xmm2
00007d516e5db6ec  vmovaps [rsp+0x30], xmm3
00007d516e5db6f2  vmovaps [rsp+0x40], xmm4
00007d516e5db6f8  vmovaps [rsp+0x50], xmm5
00007d516e5db6fe  vmovaps [rsp+0x60], xmm6
00007d516e5db704  vmovaps [rsp+0x70], xmm7
00007d516e5db70a  vmovaps [rsp+0x80], xmm8
00007d516e5db713  vmovaps [rsp+0x90], xmm10
00007d516e5db71c  vmovaps [rsp+0xA0], xmm11
00007d516e5db725  vmovaps [rsp+0xB0], xmm12
00007d516e5db72e  vmovaps [rsp+0xC0], xmm13
00007d516e5db737  vmovaps [rsp+0xD0], xmm14
00007d516e5db740  vmovaps [rsp+0xE0], xmm15
00007d516e5db749  sub rsp, 0x30
00007d516e5db74d  movaps [rsp], xmm9
00007d516e5db752  movaps [rsp+0x10], xmm3
00007d516e5db757  movaps [rsp+0x20], xmm1
00007d516e5db75c  lea rdi, [rsp]
00007d516e5db760  mov esi, 0x00
00007d516e5db765  mov rax, 0x5EE43AF14530
00007d516e5db76f  call rax
00007d516e5db771  movaps xmm9, [rsp]
00007d516e5db776  add rsp, 0x30
00007d516e5db77a  vmovaps xmm0, [rsp]
00007d516e5db77f  vmovaps xmm1, [rsp+0x10]
00007d516e5db785  vmovaps xmm2, [rsp+0x20]
00007d516e5db78b  vmovaps xmm3, [rsp+0x30]
00007d516e5db791  vmovaps xmm4, [rsp+0x40]
00007d516e5db797  vmovaps xmm5, [rsp+0x50]
00007d516e5db79d  vmovaps xmm6, [rsp+0x60]
00007d516e5db7a3  vmovaps xmm7, [rsp+0x70]
00007d516e5db7a9  vmovaps xmm8, [rsp+0x80]
00007d516e5db7b2  vmovaps xmm10, [rsp+0x90]
00007d516e5db7bb  vmovaps xmm11, [rsp+0xA0]
00007d516e5db7c4  vmovaps xmm12, [rsp+0xB0]
00007d516e5db7cd  vmovaps xmm13, [rsp+0xC0]
00007d516e5db7d6  vmovaps xmm14, [rsp+0xD0]
00007d516e5db7df  vmovaps xmm15, [rsp+0xE0]
00007d516e5db7e8  add rsp, 0xF0
00007d516e5db7ef  pop r11
00007d516e5db7f1  pop r10
00007d516e5db7f3  pop r9
00007d516e5db7f5  pop r8
00007d516e5db7f7  pop rsi
00007d516e5db7f8  pop rdi
00007d516e5db7f9  pop rdx
00007d516e5db7fa  pop rcx
00007d516e5db7fb  pop rax
00007d516e5db7fc  add rsp, 0x08
00007d516e5db800  jmp 0x00007D516E5D91D7
00007d516e5db805  call 0x00007D516E4D64F0
00007d516e5db80a  jmp 0x00007D516E5D91E4
00007d516e5db80f  sub rsp, 0x08
00007d516e5db813  push rax
00007d516e5db814  push rcx
00007d516e5db815  push rdx
00007d516e5db816  push rdi
00007d516e5db817  push rsi
00007d516e5db818  push r8
00007d516e5db81a  push r9
00007d516e5db81c  push r10
00007d516e5db81e  push r11
00007d516e5db820  sub rsp, 0xF0
00007d516e5db827  vmovaps [rsp], xmm0
00007d516e5db82c  vmovaps [rsp+0x10], xmm1
00007d516e5db832  vmovaps [rsp+0x20], xmm2
00007d516e5db838  vmovaps [rsp+0x30], xmm3
00007d516e5db83e  vmovaps [rsp+0x40], xmm4
00007d516e5db844  vmovaps [rsp+0x50], xmm5
00007d516e5db84a  vmovaps [rsp+0x60], xmm6
00007d516e5db850  vmovaps [rsp+0x70], xmm7
00007d516e5db856  vmovaps [rsp+0x80], xmm8
00007d516e5db85f  vmovaps [rsp+0x90], xmm9
00007d516e5db868  vmovaps [rsp+0xA0], xmm10
00007d516e5db871  vmovaps [rsp+0xB0], xmm11
00007d516e5db87a  vmovaps [rsp+0xC0], xmm12
00007d516e5db883  vmovaps [rsp+0xD0], xmm13
00007d516e5db88c  vmovaps [rsp+0xE0], xmm14
00007d516e5db895  sub rsp, 0x30
00007d516e5db899  movaps [rsp], xmm15
00007d516e5db89e  movaps [rsp+0x10], xmm3
00007d516e5db8a3  movaps [rsp+0x20], xmm7
00007d516e5db8a8  lea rdi, [rsp]
00007d516e5db8ac  mov esi, 0x00
00007d516e5db8b1  mov rax, 0x5EE43AF14530
00007d516e5db8bb  call rax
00007d516e5db8bd  movaps xmm15, [rsp]
00007d516e5db8c2  add rsp, 0x30
00007d516e5db8c6  vmovaps xmm0, [rsp]
00007d516e5db8cb  vmovaps xmm1, [rsp+0x10]
00007d516e5db8d1  vmovaps xmm2, [rsp+0x20]
00007d516e5db8d7  vmovaps xmm3, [rsp+0x30]
00007d516e5db8dd  vmovaps xmm4, [rsp+0x40]
00007d516e5db8e3  vmovaps xmm5, [rsp+0x50]
00007d516e5db8e9  vmovaps xmm6, [rsp+0x60]
00007d516e5db8ef  vmovaps xmm7, [rsp+0x70]
00007d516e5db8f5  vmovaps xmm8, [rsp+0x80]
00007d516e5db8fe  vmovaps xmm9, [rsp+0x90]
00007d516e5db907  vmovaps xmm10, [rsp+0xA0]
00007d516e5db910  vmovaps xmm11, [rsp+0xB0]
00007d516e5db919  vmovaps xmm12, [rsp+0xC0]
00007d516e5db922  vmovaps xmm13, [rsp+0xD0]
00007d516e5db92b  vmovaps xmm14, [rsp+0xE0]
00007d516e5db934  add rsp, 0xF0
00007d516e5db93b  pop r11
00007d516e5db93d  pop r10
00007d516e5db93f  pop r9
00007d516e5db941  pop r8
00007d516e5db943  pop rsi
00007d516e5db944  pop rdi
00007d516e5db945  pop rdx
00007d516e5db946  pop rcx
00007d516e5db947  pop rax
00007d516e5db948  add rsp, 0x08
00007d516e5db94c  jmp 0x00007D516E5D9210
00007d516e5db951  sub rsp, 0x08
00007d516e5db955  push rax
00007d516e5db956  push rcx
00007d516e5db957  push rdx
00007d516e5db958  push rdi
00007d516e5db959  push rsi
00007d516e5db95a  push r8
00007d516e5db95c  push r9
00007d516e5db95e  push r10
00007d516e5db960  push r11
00007d516e5db962  sub rsp, 0xF0
00007d516e5db969  vmovaps [rsp], xmm0
00007d516e5db96e  vmovaps [rsp+0x10], xmm1
00007d516e5db974  vmovaps [rsp+0x20], xmm2
00007d516e5db97a  vmovaps [rsp+0x30], xmm4
00007d516e5db980  vmovaps [rsp+0x40], xmm5
00007d516e5db986  vmovaps [rsp+0x50], xmm6
00007d516e5db98c  vmovaps [rsp+0x60], xmm7
00007d516e5db992  vmovaps [rsp+0x70], xmm8
00007d516e5db998  vmovaps [rsp+0x80], xmm9
00007d516e5db9a1  vmovaps [rsp+0x90], xmm10
00007d516e5db9aa  vmovaps [rsp+0xA0], xmm11
00007d516e5db9b3  vmovaps [rsp+0xB0], xmm12
00007d516e5db9bc  vmovaps [rsp+0xC0], xmm13
00007d516e5db9c5  vmovaps [rsp+0xD0], xmm14
00007d516e5db9ce  vmovaps [rsp+0xE0], xmm15
00007d516e5db9d7  sub rsp, 0x30
00007d516e5db9db  movaps [rsp], xmm3
00007d516e5db9df  movaps [rsp+0x10], xmm1
00007d516e5db9e4  movaps [rsp+0x20], xmm15
00007d516e5db9ea  lea rdi, [rsp]
00007d516e5db9ee  mov esi, 0x00
00007d516e5db9f3  mov rax, 0x5EE43AF14530
00007d516e5db9fd  call rax
00007d516e5db9ff  movaps xmm3, [rsp]
00007d516e5dba03  add rsp, 0x30
00007d516e5dba07  vmovaps xmm0, [rsp]
00007d516e5dba0c  vmovaps xmm1, [rsp+0x10]
00007d516e5dba12  vmovaps xmm2, [rsp+0x20]
00007d516e5dba18  vmovaps xmm4, [rsp+0x30]
00007d516e5dba1e  vmovaps xmm5, [rsp+0x40]
00007d516e5dba24  vmovaps xmm6, [rsp+0x50]
00007d516e5dba2a  vmovaps xmm7, [rsp+0x60]
00007d516e5dba30  vmovaps xmm8, [rsp+0x70]
00007d516e5dba36  vmovaps xmm9, [rsp+0x80]
00007d516e5dba3f  vmovaps xmm10, [rsp+0x90]
00007d516e5dba48  vmovaps xmm11, [rsp+0xA0]
00007d516e5dba51  vmovaps xmm12, [rsp+0xB0]
00007d516e5dba5a  vmovaps xmm13, [rsp+0xC0]
00007d516e5dba63  vmovaps xmm14, [rsp+0xD0]
00007d516e5dba6c  vmovaps xmm15, [rsp+0xE0]
00007d516e5dba75  add rsp, 0xF0
00007d516e5dba7c  pop r11
00007d516e5dba7e  pop r10
00007d516e5dba80  pop r9
00007d516e5dba82  pop r8
00007d516e5dba84  pop rsi
00007d516e5dba85  pop rdi
00007d516e5dba86  pop rdx
00007d516e5dba87  pop rcx
00007d516e5dba88  pop rax
00007d516e5dba89  add rsp, 0x08
00007d516e5dba8d  jmp 0x00007D516E5D929F
00007d516e5dba92  call 0x00007D516E4D64F0
00007d516e5dba97  jmp 0x00007D516E5D92A9
00007d516e5dba9c  sub rsp, 0x08
00007d516e5dbaa0  push rax
00007d516e5dbaa1  push rcx
00007d516e5dbaa2  push rdx
00007d516e5dbaa3  push rdi
00007d516e5dbaa4  push rsi
00007d516e5dbaa5  push r8
00007d516e5dbaa7  push r9
00007d516e5dbaa9  push r10
00007d516e5dbaab  push r11
00007d516e5dbaad  sub rsp, 0xF0
00007d516e5dbab4  vmovaps [rsp], xmm0
00007d516e5dbab9  vmovaps [rsp+0x10], xmm1
00007d516e5dbabf  vmovaps [rsp+0x20], xmm2
00007d516e5dbac5  vmovaps [rsp+0x30], xmm3
00007d516e5dbacb  vmovaps [rsp+0x40], xmm4
00007d516e5dbad1  vmovaps [rsp+0x50], xmm5
00007d516e5dbad7  vmovaps [rsp+0x60], xmm6
00007d516e5dbadd  vmovaps [rsp+0x70], xmm7
00007d516e5dbae3  vmovaps [rsp+0x80], xmm8
00007d516e5dbaec  vmovaps [rsp+0x90], xmm9
00007d516e5dbaf5  vmovaps [rsp+0xA0], xmm10
00007d516e5dbafe  vmovaps [rsp+0xB0], xmm11
00007d516e5dbb07  vmovaps [rsp+0xC0], xmm12
00007d516e5dbb10  vmovaps [rsp+0xD0], xmm13
00007d516e5dbb19  vmovaps [rsp+0xE0], xmm14
00007d516e5dbb22  sub rsp, 0x30
00007d516e5dbb26  movaps [rsp], xmm15
00007d516e5dbb2b  movaps [rsp+0x10], xmm14
00007d516e5dbb31  movaps [rsp+0x20], xmm4
00007d516e5dbb36  lea rdi, [rsp]
00007d516e5dbb3a  mov esi, 0x00
00007d516e5dbb3f  mov rax, 0x5EE43AF14530
00007d516e5dbb49  call rax
00007d516e5dbb4b  movaps xmm15, [rsp]
00007d516e5dbb50  add rsp, 0x30
00007d516e5dbb54  vmovaps xmm0, [rsp]
00007d516e5dbb59  vmovaps xmm1, [rsp+0x10]
00007d516e5dbb5f  vmovaps xmm2, [rsp+0x20]
00007d516e5dbb65  vmovaps xmm3, [rsp+0x30]
00007d516e5dbb6b  vmovaps xmm4, [rsp+0x40]
00007d516e5dbb71  vmovaps xmm5, [rsp+0x50]
00007d516e5dbb77  vmovaps xmm6, [rsp+0x60]
00007d516e5dbb7d  vmovaps xmm7, [rsp+0x70]
00007d516e5dbb83  vmovaps xmm8, [rsp+0x80]
00007d516e5dbb8c  vmovaps xmm9, [rsp+0x90]
00007d516e5dbb95  vmovaps xmm10, [rsp+0xA0]
00007d516e5dbb9e  vmovaps xmm11, [rsp+0xB0]
00007d516e5dbba7  vmovaps xmm12, [rsp+0xC0]
00007d516e5dbbb0  vmovaps xmm13, [rsp+0xD0]
00007d516e5dbbb9  vmovaps xmm14, [rsp+0xE0]
00007d516e5dbbc2  add rsp, 0xF0
00007d516e5dbbc9  pop r11
00007d516e5dbbcb  pop r10
00007d516e5dbbcd  pop r9
00007d516e5dbbcf  pop r8
00007d516e5dbbd1  pop rsi
00007d516e5dbbd2  pop rdi
00007d516e5dbbd3  pop rdx
00007d516e5dbbd4  pop rcx
00007d516e5dbbd5  pop rax
00007d516e5dbbd6  add rsp, 0x08
00007d516e5dbbda  jmp 0x00007D516E5D92D7
00007d516e5dbbdf  sub rsp, 0x08
00007d516e5dbbe3  push rax
00007d516e5dbbe4  push rcx
00007d516e5dbbe5  push rdx
00007d516e5dbbe6  push rdi
00007d516e5dbbe7  push rsi
00007d516e5dbbe8  push r8
00007d516e5dbbea  push r9
00007d516e5dbbec  push r10
00007d516e5dbbee  push r11
00007d516e5dbbf0  sub rsp, 0xF0
00007d516e5dbbf7  vmovaps [rsp], xmm0
00007d516e5dbbfc  vmovaps [rsp+0x10], xmm1
00007d516e5dbc02  vmovaps [rsp+0x20], xmm2
00007d516e5dbc08  vmovaps [rsp+0x30], xmm3
00007d516e5dbc0e  vmovaps [rsp+0x40], xmm4
00007d516e5dbc14  vmovaps [rsp+0x50], xmm5
00007d516e5dbc1a  vmovaps [rsp+0x60], xmm6
00007d516e5dbc20  vmovaps [rsp+0x70], xmm7
00007d516e5dbc26  vmovaps [rsp+0x80], xmm8
00007d516e5dbc2f  vmovaps [rsp+0x90], xmm9
00007d516e5dbc38  vmovaps [rsp+0xA0], xmm10
00007d516e5dbc41  vmovaps [rsp+0xB0], xmm11
00007d516e5dbc4a  vmovaps [rsp+0xC0], xmm12
00007d516e5dbc53  vmovaps [rsp+0xD0], xmm13
00007d516e5dbc5c  vmovaps [rsp+0xE0], xmm15
00007d516e5dbc65  sub rsp, 0x30
00007d516e5dbc69  movaps [rsp], xmm14
00007d516e5dbc6e  movaps [rsp+0x10], xmm2
00007d516e5dbc73  movaps [rsp+0x20], xmm1
00007d516e5dbc78  lea rdi, [rsp]
00007d516e5dbc7c  mov esi, 0x00
00007d516e5dbc81  mov rax, 0x5EE43AF14530
00007d516e5dbc8b  call rax
00007d516e5dbc8d  movaps xmm14, [rsp]
00007d516e5dbc92  add rsp, 0x30
00007d516e5dbc96  vmovaps xmm0, [rsp]
00007d516e5dbc9b  vmovaps xmm1, [rsp+0x10]
00007d516e5dbca1  vmovaps xmm2, [rsp+0x20]
00007d516e5dbca7  vmovaps xmm3, [rsp+0x30]
00007d516e5dbcad  vmovaps xmm4, [rsp+0x40]
00007d516e5dbcb3  vmovaps xmm5, [rsp+0x50]
00007d516e5dbcb9  vmovaps xmm6, [rsp+0x60]
00007d516e5dbcbf  vmovaps xmm7, [rsp+0x70]
00007d516e5dbcc5  vmovaps xmm8, [rsp+0x80]
00007d516e5dbcce  vmovaps xmm9, [rsp+0x90]
00007d516e5dbcd7  vmovaps xmm10, [rsp+0xA0]
00007d516e5dbce0  vmovaps xmm11, [rsp+0xB0]
00007d516e5dbce9  vmovaps xmm12, [rsp+0xC0]
00007d516e5dbcf2  vmovaps xmm13, [rsp+0xD0]
00007d516e5dbcfb  vmovaps xmm15, [rsp+0xE0]
00007d516e5dbd04  add rsp, 0xF0
00007d516e5dbd0b  pop r11
00007d516e5dbd0d  pop r10
00007d516e5dbd0f  pop r9
00007d516e5dbd11  pop r8
00007d516e5dbd13  pop rsi
00007d516e5dbd14  pop rdi
00007d516e5dbd15  pop rdx
00007d516e5dbd16  pop rcx
00007d516e5dbd17  pop rax
00007d516e5dbd18  add rsp, 0x08
00007d516e5dbd1c  jmp 0x00007D516E5D92FD
00007d516e5dbd21  sub rsp, 0x08
00007d516e5dbd25  push rax
00007d516e5dbd26  push rcx
00007d516e5dbd27  push rdx
00007d516e5dbd28  push rdi
00007d516e5dbd29  push rsi
00007d516e5dbd2a  push r8
00007d516e5dbd2c  push r9
00007d516e5dbd2e  push r10
00007d516e5dbd30  push r11
00007d516e5dbd32  sub rsp, 0xF0
00007d516e5dbd39  vmovaps [rsp], xmm0
00007d516e5dbd3e  vmovaps [rsp+0x10], xmm2
00007d516e5dbd44  vmovaps [rsp+0x20], xmm3
00007d516e5dbd4a  vmovaps [rsp+0x30], xmm4
00007d516e5dbd50  vmovaps [rsp+0x40], xmm5
00007d516e5dbd56  vmovaps [rsp+0x50], xmm6
00007d516e5dbd5c  vmovaps [rsp+0x60], xmm7
00007d516e5dbd62  vmovaps [rsp+0x70], xmm8
00007d516e5dbd68  vmovaps [rsp+0x80], xmm9
00007d516e5dbd71  vmovaps [rsp+0x90], xmm10
00007d516e5dbd7a  vmovaps [rsp+0xA0], xmm11
00007d516e5dbd83  vmovaps [rsp+0xB0], xmm12
00007d516e5dbd8c  vmovaps [rsp+0xC0], xmm13
00007d516e5dbd95  vmovaps [rsp+0xD0], xmm14
00007d516e5dbd9e  vmovaps [rsp+0xE0], xmm15
00007d516e5dbda7  sub rsp, 0x30
00007d516e5dbdab  movaps [rsp], xmm1
00007d516e5dbdaf  movaps [rsp+0x10], xmm4
00007d516e5dbdb4  movaps [rsp+0x20], xmm9
00007d516e5dbdba  lea rdi, [rsp]
00007d516e5dbdbe  mov esi, 0x00
00007d516e5dbdc3  mov rax, 0x5EE43AF14530
00007d516e5dbdcd  call rax
00007d516e5dbdcf  movaps xmm1, [rsp]
00007d516e5dbdd3  add rsp, 0x30
00007d516e5dbdd7  vmovaps xmm0, [rsp]
00007d516e5dbddc  vmovaps xmm2, [rsp+0x10]
00007d516e5dbde2  vmovaps xmm3, [rsp+0x20]
00007d516e5dbde8  vmovaps xmm4, [rsp+0x30]
00007d516e5dbdee  vmovaps xmm5, [rsp+0x40]
00007d516e5dbdf4  vmovaps xmm6, [rsp+0x50]
00007d516e5dbdfa  vmovaps xmm7, [rsp+0x60]
00007d516e5dbe00  vmovaps xmm8, [rsp+0x70]
00007d516e5dbe06  vmovaps xmm9, [rsp+0x80]
00007d516e5dbe0f  vmovaps xmm10, [rsp+0x90]
00007d516e5dbe18  vmovaps xmm11, [rsp+0xA0]
00007d516e5dbe21  vmovaps xmm12, [rsp+0xB0]
00007d516e5dbe2a  vmovaps xmm13, [rsp+0xC0]
00007d516e5dbe33  vmovaps xmm14, [rsp+0xD0]
00007d516e5dbe3c  vmovaps xmm15, [rsp+0xE0]
00007d516e5dbe45  add rsp, 0xF0
00007d516e5dbe4c  pop r11
00007d516e5dbe4e  pop r10
00007d516e5dbe50  pop r9
00007d516e5dbe52  pop r8
00007d516e5dbe54  pop rsi
00007d516e5dbe55  pop rdi
00007d516e5dbe56  pop rdx
00007d516e5dbe57  pop rcx
00007d516e5dbe58  pop rax
00007d516e5dbe59  add rsp, 0x08
00007d516e5dbe5d  jmp 0x00007D516E5D931B
00007d516e5dbe62  sub rsp, 0x08
00007d516e5dbe66  push rax
00007d516e5dbe67  push rcx
00007d516e5dbe68  push rdx
00007d516e5dbe69  push rdi
00007d516e5dbe6a  push rsi
00007d516e5dbe6b  push r8
00007d516e5dbe6d  push r9
00007d516e5dbe6f  push r10
00007d516e5dbe71  push r11
00007d516e5dbe73  sub rsp, 0xF0
00007d516e5dbe7a  vmovaps [rsp], xmm0
00007d516e5dbe7f  vmovaps [rsp+0x10], xmm1
00007d516e5dbe85  vmovaps [rsp+0x20], xmm2
00007d516e5dbe8b  vmovaps [rsp+0x30], xmm3
00007d516e5dbe91  vmovaps [rsp+0x40], xmm5
00007d516e5dbe97  vmovaps [rsp+0x50], xmm6
00007d516e5dbe9d  vmovaps [rsp+0x60], xmm7
00007d516e5dbea3  vmovaps [rsp+0x70], xmm8
00007d516e5dbea9  vmovaps [rsp+0x80], xmm9
00007d516e5dbeb2  vmovaps [rsp+0x90], xmm10
00007d516e5dbebb  vmovaps [rsp+0xA0], xmm11
00007d516e5dbec4  vmovaps [rsp+0xB0], xmm12
00007d516e5dbecd  vmovaps [rsp+0xC0], xmm13
00007d516e5dbed6  vmovaps [rsp+0xD0], xmm14
00007d516e5dbedf  vmovaps [rsp+0xE0], xmm15
00007d516e5dbee8  sub rsp, 0x30
00007d516e5dbeec  movaps [rsp], xmm4
00007d516e5dbef0  movaps [rsp+0x10], xmm2
00007d516e5dbef5  movaps [rsp+0x20], xmm9
00007d516e5dbefb  lea rdi, [rsp]
00007d516e5dbeff  mov esi, 0x00
00007d516e5dbf04  mov rax, 0x5EE43AF14530
00007d516e5dbf0e  call rax
00007d516e5dbf10  movaps xmm4, [rsp]
00007d516e5dbf14  add rsp, 0x30
00007d516e5dbf18  vmovaps xmm0, [rsp]
00007d516e5dbf1d  vmovaps xmm1, [rsp+0x10]
00007d516e5dbf23  vmovaps xmm2, [rsp+0x20]
00007d516e5dbf29  vmovaps xmm3, [rsp+0x30]
00007d516e5dbf2f  vmovaps xmm5, [rsp+0x40]
00007d516e5dbf35  vmovaps xmm6, [rsp+0x50]
00007d516e5dbf3b  vmovaps xmm7, [rsp+0x60]
00007d516e5dbf41  vmovaps xmm8, [rsp+0x70]
00007d516e5dbf47  vmovaps xmm9, [rsp+0x80]
00007d516e5dbf50  vmovaps xmm10, [rsp+0x90]
00007d516e5dbf59  vmovaps xmm11, [rsp+0xA0]
00007d516e5dbf62  vmovaps xmm12, [rsp+0xB0]
00007d516e5dbf6b  vmovaps xmm13, [rsp+0xC0]
00007d516e5dbf74  vmovaps xmm14, [rsp+0xD0]
00007d516e5dbf7d  vmovaps xmm15, [rsp+0xE0]
00007d516e5dbf86  add rsp, 0xF0
00007d516e5dbf8d  pop r11
00007d516e5dbf8f  pop r10
00007d516e5dbf91  pop r9
00007d516e5dbf93  pop r8
00007d516e5dbf95  pop rsi
00007d516e5dbf96  pop rdi
00007d516e5dbf97  pop rdx
00007d516e5dbf98  pop rcx
00007d516e5dbf99  pop rax
00007d516e5dbf9a  add rsp, 0x08
00007d516e5dbf9e  jmp 0x00007D516E5D934B
00007d516e5dbfa3  sub rsp, 0x08
00007d516e5dbfa7  push rax
00007d516e5dbfa8  push rcx
00007d516e5dbfa9  push rdx
00007d516e5dbfaa  push rdi
00007d516e5dbfab  push rsi
00007d516e5dbfac  push r8
00007d516e5dbfae  push r9
00007d516e5dbfb0  push r10
00007d516e5dbfb2  push r11
00007d516e5dbfb4  sub rsp, 0xF0
00007d516e5dbfbb  vmovaps [rsp], xmm0
00007d516e5dbfc0  vmovaps [rsp+0x10], xmm1
00007d516e5dbfc6  vmovaps [rsp+0x20], xmm2
00007d516e5dbfcc  vmovaps [rsp+0x30], xmm3
00007d516e5dbfd2  vmovaps [rsp+0x40], xmm4
00007d516e5dbfd8  vmovaps [rsp+0x50], xmm5
00007d516e5dbfde  vmovaps [rsp+0x60], xmm6
00007d516e5dbfe4  vmovaps [rsp+0x70], xmm7
00007d516e5dbfea  vmovaps [rsp+0x80], xmm8
00007d516e5dbff3  vmovaps [rsp+0x90], xmm10
00007d516e5dbffc  vmovaps [rsp+0xA0], xmm11
00007d516e5dc005  vmovaps [rsp+0xB0], xmm12
00007d516e5dc00e  vmovaps [rsp+0xC0], xmm13
00007d516e5dc017  vmovaps [rsp+0xD0], xmm14
00007d516e5dc020  vmovaps [rsp+0xE0], xmm15
00007d516e5dc029  sub rsp, 0x30
00007d516e5dc02d  movaps [rsp], xmm9
00007d516e5dc032  movaps [rsp+0x10], xmm2
00007d516e5dc037  movaps [rsp+0x20], xmm1
00007d516e5dc03c  lea rdi, [rsp]
00007d516e5dc040  mov esi, 0x00
00007d516e5dc045  mov rax, 0x5EE43AF14530
00007d516e5dc04f  call rax
00007d516e5dc051  movaps xmm9, [rsp]
00007d516e5dc056  add rsp, 0x30
00007d516e5dc05a  vmovaps xmm0, [rsp]
00007d516e5dc05f  vmovaps xmm1, [rsp+0x10]
00007d516e5dc065  vmovaps xmm2, [rsp+0x20]
00007d516e5dc06b  vmovaps xmm3, [rsp+0x30]
00007d516e5dc071  vmovaps xmm4, [rsp+0x40]
00007d516e5dc077  vmovaps xmm5, [rsp+0x50]
00007d516e5dc07d  vmovaps xmm6, [rsp+0x60]
00007d516e5dc083  vmovaps xmm7, [rsp+0x70]
00007d516e5dc089  vmovaps xmm8, [rsp+0x80]
00007d516e5dc092  vmovaps xmm10, [rsp+0x90]
00007d516e5dc09b  vmovaps xmm11, [rsp+0xA0]
00007d516e5dc0a4  vmovaps xmm12, [rsp+0xB0]
00007d516e5dc0ad  vmovaps xmm13, [rsp+0xC0]
00007d516e5dc0b6  vmovaps xmm14, [rsp+0xD0]
00007d516e5dc0bf  vmovaps xmm15, [rsp+0xE0]
00007d516e5dc0c8  add rsp, 0xF0
00007d516e5dc0cf  pop r11
00007d516e5dc0d1  pop r10
00007d516e5dc0d3  pop r9
00007d516e5dc0d5  pop r8
00007d516e5dc0d7  pop rsi
00007d516e5dc0d8  pop rdi
00007d516e5dc0d9  pop rdx
00007d516e5dc0da  pop rcx
00007d516e5dc0db  pop rax
00007d516e5dc0dc  add rsp, 0x08
00007d516e5dc0e0  jmp 0x00007D516E5D9381
00007d516e5dc0e5  sub rsp, 0x08
00007d516e5dc0e9  push rax
00007d516e5dc0ea  push rcx
00007d516e5dc0eb  push rdx
00007d516e5dc0ec  push rdi
00007d516e5dc0ed  push rsi
00007d516e5dc0ee  push r8
00007d516e5dc0f0  push r9
00007d516e5dc0f2  push r10
00007d516e5dc0f4  push r11
00007d516e5dc0f6  sub rsp, 0xF0
00007d516e5dc0fd  vmovaps [rsp], xmm0
00007d516e5dc102  vmovaps [rsp+0x10], xmm2
00007d516e5dc108  vmovaps [rsp+0x20], xmm3
00007d516e5dc10e  vmovaps [rsp+0x30], xmm4
00007d516e5dc114  vmovaps [rsp+0x40], xmm5
00007d516e5dc11a  vmovaps [rsp+0x50], xmm6
00007d516e5dc120  vmovaps [rsp+0x60], xmm7
00007d516e5dc126  vmovaps [rsp+0x70], xmm8
00007d516e5dc12c  vmovaps [rsp+0x80], xmm9
00007d516e5dc135  vmovaps [rsp+0x90], xmm10
00007d516e5dc13e  vmovaps [rsp+0xA0], xmm11
00007d516e5dc147  vmovaps [rsp+0xB0], xmm12
00007d516e5dc150  vmovaps [rsp+0xC0], xmm13
00007d516e5dc159  vmovaps [rsp+0xD0], xmm14
00007d516e5dc162  vmovaps [rsp+0xE0], xmm15
00007d516e5dc16b  sub rsp, 0x30
00007d516e5dc16f  movaps [rsp], xmm1
00007d516e5dc173  movaps [rsp+0x10], xmm15
00007d516e5dc179  movaps [rsp+0x20], xmm6
00007d516e5dc17e  lea rdi, [rsp]
00007d516e5dc182  mov esi, 0x00
00007d516e5dc187  mov rax, 0x5EE43AF14530
00007d516e5dc191  call rax
00007d516e5dc193  movaps xmm1, [rsp]
00007d516e5dc197  add rsp, 0x30
00007d516e5dc19b  vmovaps xmm0, [rsp]
00007d516e5dc1a0  vmovaps xmm2, [rsp+0x10]
00007d516e5dc1a6  vmovaps xmm3, [rsp+0x20]
00007d516e5dc1ac  vmovaps xmm4, [rsp+0x30]
00007d516e5dc1b2  vmovaps xmm5, [rsp+0x40]
00007d516e5dc1b8  vmovaps xmm6, [rsp+0x50]
00007d516e5dc1be  vmovaps xmm7, [rsp+0x60]
00007d516e5dc1c4  vmovaps xmm8, [rsp+0x70]
00007d516e5dc1ca  vmovaps xmm9, [rsp+0x80]
00007d516e5dc1d3  vmovaps xmm10, [rsp+0x90]
00007d516e5dc1dc  vmovaps xmm11, [rsp+0xA0]
00007d516e5dc1e5  vmovaps xmm12, [rsp+0xB0]
00007d516e5dc1ee  vmovaps xmm13, [rsp+0xC0]
00007d516e5dc1f7  vmovaps xmm14, [rsp+0xD0]
00007d516e5dc200  vmovaps xmm15, [rsp+0xE0]
00007d516e5dc209  add rsp, 0xF0
00007d516e5dc210  pop r11
00007d516e5dc212  pop r10
00007d516e5dc214  pop r9
00007d516e5dc216  pop r8
00007d516e5dc218  pop rsi
00007d516e5dc219  pop rdi
00007d516e5dc21a  pop rdx
00007d516e5dc21b  pop rcx
00007d516e5dc21c  pop rax
00007d516e5dc21d  add rsp, 0x08
00007d516e5dc221  jmp 0x00007D516E5D93A2
00007d516e5dc226  sub rsp, 0x08
00007d516e5dc22a  push rax
00007d516e5dc22b  push rcx
00007d516e5dc22c  push rdx
00007d516e5dc22d  push rdi
00007d516e5dc22e  push rsi
00007d516e5dc22f  push r8
00007d516e5dc231  push r9
00007d516e5dc233  push r10
00007d516e5dc235  push r11
00007d516e5dc237  sub rsp, 0xF0
00007d516e5dc23e  vmovaps [rsp], xmm0
00007d516e5dc243  vmovaps [rsp+0x10], xmm1
00007d516e5dc249  vmovaps [rsp+0x20], xmm2
00007d516e5dc24f  vmovaps [rsp+0x30], xmm3
00007d516e5dc255  vmovaps [rsp+0x40], xmm4
00007d516e5dc25b  vmovaps [rsp+0x50], xmm5
00007d516e5dc261  vmovaps [rsp+0x60], xmm6
00007d516e5dc267  vmovaps [rsp+0x70], xmm7
00007d516e5dc26d  vmovaps [rsp+0x80], xmm8
00007d516e5dc276  vmovaps [rsp+0x90], xmm9
00007d516e5dc27f  vmovaps [rsp+0xA0], xmm10
00007d516e5dc288  vmovaps [rsp+0xB0], xmm11
00007d516e5dc291  vmovaps [rsp+0xC0], xmm12
00007d516e5dc29a  vmovaps [rsp+0xD0], xmm13
00007d516e5dc2a3  vmovaps [rsp+0xE0], xmm14
00007d516e5dc2ac  sub rsp, 0x30
00007d516e5dc2b0  movaps [rsp], xmm15
00007d516e5dc2b5  movaps [rsp+0x10], xmm5
00007d516e5dc2ba  movaps [rsp+0x20], xmm3
00007d516e5dc2bf  lea rdi, [rsp]
00007d516e5dc2c3  mov esi, 0x00
00007d516e5dc2c8  mov rax, 0x5EE43AF14530
00007d516e5dc2d2  call rax
00007d516e5dc2d4  movaps xmm15, [rsp]
00007d516e5dc2d9  add rsp, 0x30
00007d516e5dc2dd  vmovaps xmm0, [rsp]
00007d516e5dc2e2  vmovaps xmm1, [rsp+0x10]
00007d516e5dc2e8  vmovaps xmm2, [rsp+0x20]
00007d516e5dc2ee  vmovaps xmm3, [rsp+0x30]
00007d516e5dc2f4  vmovaps xmm4, [rsp+0x40]
00007d516e5dc2fa  vmovaps xmm5, [rsp+0x50]
00007d516e5dc300  vmovaps xmm6, [rsp+0x60]
00007d516e5dc306  vmovaps xmm7, [rsp+0x70]
00007d516e5dc30c  vmovaps xmm8, [rsp+0x80]
00007d516e5dc315  vmovaps xmm9, [rsp+0x90]
00007d516e5dc31e  vmovaps xmm10, [rsp+0xA0]
00007d516e5dc327  vmovaps xmm11, [rsp+0xB0]
00007d516e5dc330  vmovaps xmm12, [rsp+0xC0]
00007d516e5dc339  vmovaps xmm13, [rsp+0xD0]
00007d516e5dc342  vmovaps xmm14, [rsp+0xE0]
00007d516e5dc34b  add rsp, 0xF0
00007d516e5dc352  pop r11
00007d516e5dc354  pop r10
00007d516e5dc356  pop r9
00007d516e5dc358  pop r8
00007d516e5dc35a  pop rsi
00007d516e5dc35b  pop rdi
00007d516e5dc35c  pop rdx
00007d516e5dc35d  pop rcx
00007d516e5dc35e  pop rax
00007d516e5dc35f  add rsp, 0x08
00007d516e5dc363  jmp 0x00007D516E5D93BC
00007d516e5dc368  sub rsp, 0x08
00007d516e5dc36c  push rax
00007d516e5dc36d  push rcx
00007d516e5dc36e  push rdx
00007d516e5dc36f  push rdi
00007d516e5dc370  push rsi
00007d516e5dc371  push r8
00007d516e5dc373  push r9
00007d516e5dc375  push r10
00007d516e5dc377  push r11
00007d516e5dc379  sub rsp, 0xF0
00007d516e5dc380  vmovaps [rsp], xmm0
00007d516e5dc385  vmovaps [rsp+0x10], xmm1
00007d516e5dc38b  vmovaps [rsp+0x20], xmm2
00007d516e5dc391  vmovaps [rsp+0x30], xmm3
00007d516e5dc397  vmovaps [rsp+0x40], xmm4
00007d516e5dc39d  vmovaps [rsp+0x50], xmm6
00007d516e5dc3a3  vmovaps [rsp+0x60], xmm7
00007d516e5dc3a9  vmovaps [rsp+0x70], xmm8
00007d516e5dc3af  vmovaps [rsp+0x80], xmm9
00007d516e5dc3b8  vmovaps [rsp+0x90], xmm10
00007d516e5dc3c1  vmovaps [rsp+0xA0], xmm11
00007d516e5dc3ca  vmovaps [rsp+0xB0], xmm12
00007d516e5dc3d3  vmovaps [rsp+0xC0], xmm13
00007d516e5dc3dc  vmovaps [rsp+0xD0], xmm14
00007d516e5dc3e5  vmovaps [rsp+0xE0], xmm15
00007d516e5dc3ee  sub rsp, 0x30
00007d516e5dc3f2  movaps [rsp], xmm5
00007d516e5dc3f6  movaps [rsp+0x10], xmm8
00007d516e5dc3fc  movaps [rsp+0x20], xmm6
00007d516e5dc401  lea rdi, [rsp]
00007d516e5dc405  mov esi, 0x00
00007d516e5dc40a  mov rax, 0x5EE43AF14530
00007d516e5dc414  call rax
00007d516e5dc416  movaps xmm5, [rsp]
00007d516e5dc41a  add rsp, 0x30
00007d516e5dc41e  vmovaps xmm0, [rsp]
00007d516e5dc423  vmovaps xmm1, [rsp+0x10]
00007d516e5dc429  vmovaps xmm2, [rsp+0x20]
00007d516e5dc42f  vmovaps xmm3, [rsp+0x30]
00007d516e5dc435  vmovaps xmm4, [rsp+0x40]
00007d516e5dc43b  vmovaps xmm6, [rsp+0x50]
00007d516e5dc441  vmovaps xmm7, [rsp+0x60]
00007d516e5dc447  vmovaps xmm8, [rsp+0x70]
00007d516e5dc44d  vmovaps xmm9, [rsp+0x80]
00007d516e5dc456  vmovaps xmm10, [rsp+0x90]
00007d516e5dc45f  vmovaps xmm11, [rsp+0xA0]
00007d516e5dc468  vmovaps xmm12, [rsp+0xB0]
00007d516e5dc471  vmovaps xmm13, [rsp+0xC0]
00007d516e5dc47a  vmovaps xmm14, [rsp+0xD0]
00007d516e5dc483  vmovaps xmm15, [rsp+0xE0]
00007d516e5dc48c  add rsp, 0xF0
00007d516e5dc493  pop r11
00007d516e5dc495  pop r10
00007d516e5dc497  pop r9
00007d516e5dc499  pop r8
00007d516e5dc49b  pop rsi
00007d516e5dc49c  pop rdi
00007d516e5dc49d  pop rdx
00007d516e5dc49e  pop rcx
00007d516e5dc49f  pop rax
00007d516e5dc4a0  add rsp, 0x08
00007d516e5dc4a4  jmp 0x00007D516E5D93E0
00007d516e5dc4a9  sub rsp, 0x08
00007d516e5dc4ad  push rax
00007d516e5dc4ae  push rcx
00007d516e5dc4af  push rdx
00007d516e5dc4b0  push rdi
00007d516e5dc4b1  push rsi
00007d516e5dc4b2  push r8
00007d516e5dc4b4  push r9
00007d516e5dc4b6  push r10
00007d516e5dc4b8  push r11
00007d516e5dc4ba  sub rsp, 0xF0
00007d516e5dc4c1  vmovaps [rsp], xmm0
00007d516e5dc4c6  vmovaps [rsp+0x10], xmm1
00007d516e5dc4cc  vmovaps [rsp+0x20], xmm2
00007d516e5dc4d2  vmovaps [rsp+0x30], xmm3
00007d516e5dc4d8  vmovaps [rsp+0x40], xmm4
00007d516e5dc4de  vmovaps [rsp+0x50], xmm5
00007d516e5dc4e4  vmovaps [rsp+0x60], xmm7
00007d516e5dc4ea  vmovaps [rsp+0x70], xmm8
00007d516e5dc4f0  vmovaps [rsp+0x80], xmm9
00007d516e5dc4f9  vmovaps [rsp+0x90], xmm10
00007d516e5dc502  vmovaps [rsp+0xA0], xmm11
00007d516e5dc50b  vmovaps [rsp+0xB0], xmm12
00007d516e5dc514  vmovaps [rsp+0xC0], xmm13
00007d516e5dc51d  vmovaps [rsp+0xD0], xmm14
00007d516e5dc526  vmovaps [rsp+0xE0], xmm15
00007d516e5dc52f  sub rsp, 0x30
00007d516e5dc533  movaps [rsp], xmm6
00007d516e5dc537  movaps [rsp+0x10], xmm10
00007d516e5dc53d  movaps [rsp+0x20], xmm8
00007d516e5dc543  lea rdi, [rsp]
00007d516e5dc547  mov esi, 0x00
00007d516e5dc54c  mov rax, 0x5EE43AF14530
00007d516e5dc556  call rax
00007d516e5dc558  movaps xmm6, [rsp]
00007d516e5dc55c  add rsp, 0x30
00007d516e5dc560  vmovaps xmm0, [rsp]
00007d516e5dc565  vmovaps xmm1, [rsp+0x10]
00007d516e5dc56b  vmovaps xmm2, [rsp+0x20]
00007d516e5dc571  vmovaps xmm3, [rsp+0x30]
00007d516e5dc577  vmovaps xmm4, [rsp+0x40]
00007d516e5dc57d  vmovaps xmm5, [rsp+0x50]
00007d516e5dc583  vmovaps xmm7, [rsp+0x60]
00007d516e5dc589  vmovaps xmm8, [rsp+0x70]
00007d516e5dc58f  vmovaps xmm9, [rsp+0x80]
00007d516e5dc598  vmovaps xmm10, [rsp+0x90]
00007d516e5dc5a1  vmovaps xmm11, [rsp+0xA0]
00007d516e5dc5aa  vmovaps xmm12, [rsp+0xB0]
00007d516e5dc5b3  vmovaps xmm13, [rsp+0xC0]
00007d516e5dc5bc  vmovaps xmm14, [rsp+0xD0]
00007d516e5dc5c5  vmovaps xmm15, [rsp+0xE0]
00007d516e5dc5ce  add rsp, 0xF0
00007d516e5dc5d5  pop r11
00007d516e5dc5d7  pop r10
00007d516e5dc5d9  pop r9
00007d516e5dc5db  pop r8
00007d516e5dc5dd  pop rsi
00007d516e5dc5de  pop rdi
00007d516e5dc5df  pop rdx
00007d516e5dc5e0  pop rcx
00007d516e5dc5e1  pop rax
00007d516e5dc5e2  add rsp, 0x08
00007d516e5dc5e6  jmp 0x00007D516E5D9405
00007d516e5dc5eb  sub rsp, 0x08
00007d516e5dc5ef  push rax
00007d516e5dc5f0  push rcx
00007d516e5dc5f1  push rdx
00007d516e5dc5f2  push rdi
00007d516e5dc5f3  push rsi
00007d516e5dc5f4  push r8
00007d516e5dc5f6  push r9
00007d516e5dc5f8  push r10
00007d516e5dc5fa  push r11
00007d516e5dc5fc  sub rsp, 0xF0
00007d516e5dc603  vmovaps [rsp], xmm0
00007d516e5dc608  vmovaps [rsp+0x10], xmm1
00007d516e5dc60e  vmovaps [rsp+0x20], xmm2
00007d516e5dc614  vmovaps [rsp+0x30], xmm3
00007d516e5dc61a  vmovaps [rsp+0x40], xmm4
00007d516e5dc620  vmovaps [rsp+0x50], xmm5
00007d516e5dc626  vmovaps [rsp+0x60], xmm6
00007d516e5dc62c  vmovaps [rsp+0x70], xmm7
00007d516e5dc632  vmovaps [rsp+0x80], xmm8
00007d516e5dc63b  vmovaps [rsp+0x90], xmm9
00007d516e5dc644  vmovaps [rsp+0xA0], xmm11
00007d516e5dc64d  vmovaps [rsp+0xB0], xmm12
00007d516e5dc656  vmovaps [rsp+0xC0], xmm13
00007d516e5dc65f  vmovaps [rsp+0xD0], xmm14
00007d516e5dc668  vmovaps [rsp+0xE0], xmm15
00007d516e5dc671  sub rsp, 0x30
00007d516e5dc675  movaps [rsp], xmm10
00007d516e5dc67a  movaps [rsp+0x10], xmm8
00007d516e5dc680  movaps [rsp+0x20], xmm14
00007d516e5dc686  lea rdi, [rsp]
00007d516e5dc68a  mov esi, 0x00
00007d516e5dc68f  mov rax, 0x5EE43AF14530
00007d516e5dc699  call rax
00007d516e5dc69b  movaps xmm10, [rsp]
00007d516e5dc6a0  add rsp, 0x30
00007d516e5dc6a4  vmovaps xmm0, [rsp]
00007d516e5dc6a9  vmovaps xmm1, [rsp+0x10]
00007d516e5dc6af  vmovaps xmm2, [rsp+0x20]
00007d516e5dc6b5  vmovaps xmm3, [rsp+0x30]
00007d516e5dc6bb  vmovaps xmm4, [rsp+0x40]
00007d516e5dc6c1  vmovaps xmm5, [rsp+0x50]
00007d516e5dc6c7  vmovaps xmm6, [rsp+0x60]
00007d516e5dc6cd  vmovaps xmm7, [rsp+0x70]
00007d516e5dc6d3  vmovaps xmm8, [rsp+0x80]
00007d516e5dc6dc  vmovaps xmm9, [rsp+0x90]
00007d516e5dc6e5  vmovaps xmm11, [rsp+0xA0]
00007d516e5dc6ee  vmovaps xmm12, [rsp+0xB0]
00007d516e5dc6f7  vmovaps xmm13, [rsp+0xC0]
00007d516e5dc700  vmovaps xmm14, [rsp+0xD0]
00007d516e5dc709  vmovaps xmm15, [rsp+0xE0]
00007d516e5dc712  add rsp, 0xF0
00007d516e5dc719  pop r11
00007d516e5dc71b  pop r10
00007d516e5dc71d  pop r9
00007d516e5dc71f  pop r8
00007d516e5dc721  pop rsi
00007d516e5dc722  pop rdi
00007d516e5dc723  pop rdx
00007d516e5dc724  pop rcx
00007d516e5dc725  pop rax
00007d516e5dc726  add rsp, 0x08
00007d516e5dc72a  jmp 0x00007D516E5D9425
00007d516e5dc72f  sub rsp, 0x08
00007d516e5dc733  push rax
00007d516e5dc734  push rcx
00007d516e5dc735  push rdx
00007d516e5dc736  push rdi
00007d516e5dc737  push rsi
00007d516e5dc738  push r8
00007d516e5dc73a  push r9
00007d516e5dc73c  push r10
00007d516e5dc73e  push r11
00007d516e5dc740  sub rsp, 0xF0
00007d516e5dc747  vmovaps [rsp], xmm0
00007d516e5dc74c  vmovaps [rsp+0x10], xmm1
00007d516e5dc752  vmovaps [rsp+0x20], xmm2
00007d516e5dc758  vmovaps [rsp+0x30], xmm3
00007d516e5dc75e  vmovaps [rsp+0x40], xmm4
00007d516e5dc764  vmovaps [rsp+0x50], xmm5
00007d516e5dc76a  vmovaps [rsp+0x60], xmm6
00007d516e5dc770  vmovaps [rsp+0x70], xmm7
00007d516e5dc776  vmovaps [rsp+0x80], xmm8
00007d516e5dc77f  vmovaps [rsp+0x90], xmm9
00007d516e5dc788  vmovaps [rsp+0xA0], xmm10
00007d516e5dc791  vmovaps [rsp+0xB0], xmm11
00007d516e5dc79a  vmovaps [rsp+0xC0], xmm12
00007d516e5dc7a3  vmovaps [rsp+0xD0], xmm13
00007d516e5dc7ac  vmovaps [rsp+0xE0], xmm15
00007d516e5dc7b5  sub rsp, 0x30
00007d516e5dc7b9  movaps [rsp], xmm14
00007d516e5dc7be  movaps [rsp+0x10], xmm8
00007d516e5dc7c4  movaps [rsp+0x20], xmm4
00007d516e5dc7c9  lea rdi, [rsp]
00007d516e5dc7cd  mov esi, 0x00
00007d516e5dc7d2  mov rax, 0x5EE43AF14530
00007d516e5dc7dc  call rax
00007d516e5dc7de  movaps xmm14, [rsp]
00007d516e5dc7e3  add rsp, 0x30
00007d516e5dc7e7  vmovaps xmm0, [rsp]
00007d516e5dc7ec  vmovaps xmm1, [rsp+0x10]
00007d516e5dc7f2  vmovaps xmm2, [rsp+0x20]
00007d516e5dc7f8  vmovaps xmm3, [rsp+0x30]
00007d516e5dc7fe  vmovaps xmm4, [rsp+0x40]
00007d516e5dc804  vmovaps xmm5, [rsp+0x50]
00007d516e5dc80a  vmovaps xmm6, [rsp+0x60]
00007d516e5dc810  vmovaps xmm7, [rsp+0x70]
00007d516e5dc816  vmovaps xmm8, [rsp+0x80]
00007d516e5dc81f  vmovaps xmm9, [rsp+0x90]
00007d516e5dc828  vmovaps xmm10, [rsp+0xA0]
00007d516e5dc831  vmovaps xmm11, [rsp+0xB0]
00007d516e5dc83a  vmovaps xmm12, [rsp+0xC0]
00007d516e5dc843  vmovaps xmm13, [rsp+0xD0]
00007d516e5dc84c  vmovaps xmm15, [rsp+0xE0]
00007d516e5dc855  add rsp, 0xF0
00007d516e5dc85c  pop r11
00007d516e5dc85e  pop r10
00007d516e5dc860  pop r9
00007d516e5dc862  pop r8
00007d516e5dc864  pop rsi
00007d516e5dc865  pop rdi
00007d516e5dc866  pop rdx
00007d516e5dc867  pop rcx
00007d516e5dc868  pop rax
00007d516e5dc869  add rsp, 0x08
00007d516e5dc86d  jmp 0x00007D516E5D9445
00007d516e5dc872  sub rsp, 0x08
00007d516e5dc876  push rax
00007d516e5dc877  push rcx
00007d516e5dc878  push rdx
00007d516e5dc879  push rdi
00007d516e5dc87a  push rsi
00007d516e5dc87b  push r8
00007d516e5dc87d  push r9
00007d516e5dc87f  push r10
00007d516e5dc881  push r11
00007d516e5dc883  sub rsp, 0xF0
00007d516e5dc88a  vmovaps [rsp], xmm0
00007d516e5dc88f  vmovaps [rsp+0x10], xmm1
00007d516e5dc895  vmovaps [rsp+0x20], xmm2
00007d516e5dc89b  vmovaps [rsp+0x30], xmm3
00007d516e5dc8a1  vmovaps [rsp+0x40], xmm5
00007d516e5dc8a7  vmovaps [rsp+0x50], xmm6
00007d516e5dc8ad  vmovaps [rsp+0x60], xmm7
00007d516e5dc8b3  vmovaps [rsp+0x70], xmm8
00007d516e5dc8b9  vmovaps [rsp+0x80], xmm9
00007d516e5dc8c2  vmovaps [rsp+0x90], xmm10
00007d516e5dc8cb  vmovaps [rsp+0xA0], xmm11
00007d516e5dc8d4  vmovaps [rsp+0xB0], xmm12
00007d516e5dc8dd  vmovaps [rsp+0xC0], xmm13
00007d516e5dc8e6  vmovaps [rsp+0xD0], xmm14
00007d516e5dc8ef  vmovaps [rsp+0xE0], xmm15
00007d516e5dc8f8  sub rsp, 0x30
00007d516e5dc8fc  movaps [rsp], xmm4
00007d516e5dc900  movaps [rsp+0x10], xmm13
00007d516e5dc906  movaps [rsp+0x20], xmm8
00007d516e5dc90c  lea rdi, [rsp]
00007d516e5dc910  mov esi, 0x00
00007d516e5dc915  mov rax, 0x5EE43AF14530
00007d516e5dc91f  call rax
00007d516e5dc921  movaps xmm4, [rsp]
00007d516e5dc925  add rsp, 0x30
00007d516e5dc929  vmovaps xmm0, [rsp]
00007d516e5dc92e  vmovaps xmm1, [rsp+0x10]
00007d516e5dc934  vmovaps xmm2, [rsp+0x20]
00007d516e5dc93a  vmovaps xmm3, [rsp+0x30]
00007d516e5dc940  vmovaps xmm5, [rsp+0x40]
00007d516e5dc946  vmovaps xmm6, [rsp+0x50]
00007d516e5dc94c  vmovaps xmm7, [rsp+0x60]
00007d516e5dc952  vmovaps xmm8, [rsp+0x70]
00007d516e5dc958  vmovaps xmm9, [rsp+0x80]
00007d516e5dc961  vmovaps xmm10, [rsp+0x90]
00007d516e5dc96a  vmovaps xmm11, [rsp+0xA0]
00007d516e5dc973  vmovaps xmm12, [rsp+0xB0]
00007d516e5dc97c  vmovaps xmm13, [rsp+0xC0]
00007d516e5dc985  vmovaps xmm14, [rsp+0xD0]
00007d516e5dc98e  vmovaps xmm15, [rsp+0xE0]
00007d516e5dc997  add rsp, 0xF0
00007d516e5dc99e  pop r11
00007d516e5dc9a0  pop r10
00007d516e5dc9a2  pop r9
00007d516e5dc9a4  pop r8
00007d516e5dc9a6  pop rsi
00007d516e5dc9a7  pop rdi
00007d516e5dc9a8  pop rdx
00007d516e5dc9a9  pop rcx
00007d516e5dc9aa  pop rax
00007d516e5dc9ab  add rsp, 0x08
00007d516e5dc9af  jmp 0x00007D516E5D946A
00007d516e5dc9b4  sub rsp, 0x08
00007d516e5dc9b8  push rax
00007d516e5dc9b9  push rcx
00007d516e5dc9ba  push rdx
00007d516e5dc9bb  push rdi
00007d516e5dc9bc  push rsi
00007d516e5dc9bd  push r8
00007d516e5dc9bf  push r9
00007d516e5dc9c1  push r10
00007d516e5dc9c3  push r11
00007d516e5dc9c5  sub rsp, 0xF0
00007d516e5dc9cc  vmovaps [rsp], xmm0
00007d516e5dc9d1  vmovaps [rsp+0x10], xmm1
00007d516e5dc9d7  vmovaps [rsp+0x20], xmm2
00007d516e5dc9dd  vmovaps [rsp+0x30], xmm3
00007d516e5dc9e3  vmovaps [rsp+0x40], xmm4
00007d516e5dc9e9  vmovaps [rsp+0x50], xmm5
00007d516e5dc9ef  vmovaps [rsp+0x60], xmm6
00007d516e5dc9f5  vmovaps [rsp+0x70], xmm7
00007d516e5dc9fb  vmovaps [rsp+0x80], xmm8
00007d516e5dca04  vmovaps [rsp+0x90], xmm9
00007d516e5dca0d  vmovaps [rsp+0xA0], xmm10
00007d516e5dca16  vmovaps [rsp+0xB0], xmm11
00007d516e5dca1f  vmovaps [rsp+0xC0], xmm12
00007d516e5dca28  vmovaps [rsp+0xD0], xmm14
00007d516e5dca31  vmovaps [rsp+0xE0], xmm15
00007d516e5dca3a  sub rsp, 0x30
00007d516e5dca3e  movaps [rsp], xmm13
00007d516e5dca43  movaps [rsp+0x10], xmm15
00007d516e5dca49  movaps [rsp+0x20], xmm9
00007d516e5dca4f  lea rdi, [rsp]
00007d516e5dca53  mov esi, 0x00
00007d516e5dca58  mov rax, 0x5EE43AF14530
00007d516e5dca62  call rax
00007d516e5dca64  movaps xmm13, [rsp]
00007d516e5dca69  add rsp, 0x30
00007d516e5dca6d  vmovaps xmm0, [rsp]
00007d516e5dca72  vmovaps xmm1, [rsp+0x10]
00007d516e5dca78  vmovaps xmm2, [rsp+0x20]
00007d516e5dca7e  vmovaps xmm3, [rsp+0x30]
00007d516e5dca84  vmovaps xmm4, [rsp+0x40]
00007d516e5dca8a  vmovaps xmm5, [rsp+0x50]
00007d516e5dca90  vmovaps xmm6, [rsp+0x60]
00007d516e5dca96  vmovaps xmm7, [rsp+0x70]
00007d516e5dca9c  vmovaps xmm8, [rsp+0x80]
00007d516e5dcaa5  vmovaps xmm9, [rsp+0x90]
00007d516e5dcaae  vmovaps xmm10, [rsp+0xA0]
00007d516e5dcab7  vmovaps xmm11, [rsp+0xB0]
00007d516e5dcac0  vmovaps xmm12, [rsp+0xC0]
00007d516e5dcac9  vmovaps xmm14, [rsp+0xD0]
00007d516e5dcad2  vmovaps xmm15, [rsp+0xE0]
00007d516e5dcadb  add rsp, 0xF0
00007d516e5dcae2  pop r11
00007d516e5dcae4  pop r10
00007d516e5dcae6  pop r9
00007d516e5dcae8  pop r8
00007d516e5dcaea  pop rsi
00007d516e5dcaeb  pop rdi
00007d516e5dcaec  pop rdx
00007d516e5dcaed  pop rcx
00007d516e5dcaee  pop rax
00007d516e5dcaef  add rsp, 0x08
00007d516e5dcaf3  jmp 0x00007D516E5D9485
00007d516e5dcaf8  sub rsp, 0x08
00007d516e5dcafc  push rax
00007d516e5dcafd  push rcx
00007d516e5dcafe  push rdx
00007d516e5dcaff  push rdi
00007d516e5dcb00  push rsi
00007d516e5dcb01  push r8
00007d516e5dcb03  push r9
00007d516e5dcb05  push r10
00007d516e5dcb07  push r11
00007d516e5dcb09  sub rsp, 0xF0
00007d516e5dcb10  vmovaps [rsp], xmm0
00007d516e5dcb15  vmovaps [rsp+0x10], xmm1
00007d516e5dcb1b  vmovaps [rsp+0x20], xmm2
00007d516e5dcb21  vmovaps [rsp+0x30], xmm3
00007d516e5dcb27  vmovaps [rsp+0x40], xmm4
00007d516e5dcb2d  vmovaps [rsp+0x50], xmm5
00007d516e5dcb33  vmovaps [rsp+0x60], xmm6
00007d516e5dcb39  vmovaps [rsp+0x70], xmm7
00007d516e5dcb3f  vmovaps [rsp+0x80], xmm8
00007d516e5dcb48  vmovaps [rsp+0x90], xmm9
00007d516e5dcb51  vmovaps [rsp+0xA0], xmm10
00007d516e5dcb5a  vmovaps [rsp+0xB0], xmm11
00007d516e5dcb63  vmovaps [rsp+0xC0], xmm12
00007d516e5dcb6c  vmovaps [rsp+0xD0], xmm13
00007d516e5dcb75  vmovaps [rsp+0xE0], xmm14
00007d516e5dcb7e  sub rsp, 0x30
00007d516e5dcb82  movaps [rsp], xmm15
00007d516e5dcb87  movaps [rsp+0x10], xmm1
00007d516e5dcb8c  movaps [rsp+0x20], xmm5
00007d516e5dcb91  lea rdi, [rsp]
00007d516e5dcb95  mov esi, 0x00
00007d516e5dcb9a  mov rax, 0x5EE43AF14530
00007d516e5dcba4  call rax
00007d516e5dcba6  movaps xmm15, [rsp]
00007d516e5dcbab  add rsp, 0x30
00007d516e5dcbaf  vmovaps xmm0, [rsp]
00007d516e5dcbb4  vmovaps xmm1, [rsp+0x10]
00007d516e5dcbba  vmovaps xmm2, [rsp+0x20]
00007d516e5dcbc0  vmovaps xmm3, [rsp+0x30]
00007d516e5dcbc6  vmovaps xmm4, [rsp+0x40]
00007d516e5dcbcc  vmovaps xmm5, [rsp+0x50]
00007d516e5dcbd2  vmovaps xmm6, [rsp+0x60]
00007d516e5dcbd8  vmovaps xmm7, [rsp+0x70]
00007d516e5dcbde  vmovaps xmm8, [rsp+0x80]
00007d516e5dcbe7  vmovaps xmm9, [rsp+0x90]
00007d516e5dcbf0  vmovaps xmm10, [rsp+0xA0]
00007d516e5dcbf9  vmovaps xmm11, [rsp+0xB0]
00007d516e5dcc02  vmovaps xmm12, [rsp+0xC0]
00007d516e5dcc0b  vmovaps xmm13, [rsp+0xD0]
00007d516e5dcc14  vmovaps xmm14, [rsp+0xE0]
00007d516e5dcc1d  add rsp, 0xF0
00007d516e5dcc24  pop r11
00007d516e5dcc26  pop r10
00007d516e5dcc28  pop r9
00007d516e5dcc2a  pop r8
00007d516e5dcc2c  pop rsi
00007d516e5dcc2d  pop rdi
00007d516e5dcc2e  pop rdx
00007d516e5dcc2f  pop rcx
00007d516e5dcc30  pop rax
00007d516e5dcc31  add rsp, 0x08
00007d516e5dcc35  jmp 0x00007D516E5D94A0
00007d516e5dcc3a  call 0x00007D516E4D64F0
00007d516e5dcc3f  jmp 0x00007D516E5D94FB
00007d516e5dcc44  sub rsp, 0x08
00007d516e5dcc48  push rax
00007d516e5dcc49  push rcx
00007d516e5dcc4a  push rdx
00007d516e5dcc4b  push rdi
00007d516e5dcc4c  push rsi
00007d516e5dcc4d  push r8
00007d516e5dcc4f  push r9
00007d516e5dcc51  push r10
00007d516e5dcc53  push r11
00007d516e5dcc55  sub rsp, 0xF0
00007d516e5dcc5c  vmovaps [rsp], xmm0
00007d516e5dcc61  vmovaps [rsp+0x10], xmm1
00007d516e5dcc67  vmovaps [rsp+0x20], xmm2
00007d516e5dcc6d  vmovaps [rsp+0x30], xmm3
00007d516e5dcc73  vmovaps [rsp+0x40], xmm4
00007d516e5dcc79  vmovaps [rsp+0x50], xmm5
00007d516e5dcc7f  vmovaps [rsp+0x60], xmm6
00007d516e5dcc85  vmovaps [rsp+0x70], xmm7
00007d516e5dcc8b  vmovaps [rsp+0x80], xmm8
00007d516e5dcc94  vmovaps [rsp+0x90], xmm10
00007d516e5dcc9d  vmovaps [rsp+0xA0], xmm11
00007d516e5dcca6  vmovaps [rsp+0xB0], xmm12
00007d516e5dccaf  vmovaps [rsp+0xC0], xmm13
00007d516e5dccb8  vmovaps [rsp+0xD0], xmm14
00007d516e5dccc1  vmovaps [rsp+0xE0], xmm15
00007d516e5dccca  sub rsp, 0x30
00007d516e5dccce  movaps [rsp], xmm9
00007d516e5dccd3  movaps [rsp+0x10], xmm8
00007d516e5dccd9  movaps [rsp+0x20], xmm11
00007d516e5dccdf  lea rdi, [rsp]
00007d516e5dcce3  mov esi, 0x00
00007d516e5dcce8  mov rax, 0x5EE43AF14530
00007d516e5dccf2  call rax
00007d516e5dccf4  movaps xmm9, [rsp]
00007d516e5dccf9  add rsp, 0x30
00007d516e5dccfd  vmovaps xmm0, [rsp]
00007d516e5dcd02  vmovaps xmm1, [rsp+0x10]
00007d516e5dcd08  vmovaps xmm2, [rsp+0x20]
00007d516e5dcd0e  vmovaps xmm3, [rsp+0x30]
00007d516e5dcd14  vmovaps xmm4, [rsp+0x40]
00007d516e5dcd1a  vmovaps xmm5, [rsp+0x50]
00007d516e5dcd20  vmovaps xmm6, [rsp+0x60]
00007d516e5dcd26  vmovaps xmm7, [rsp+0x70]
00007d516e5dcd2c  vmovaps xmm8, [rsp+0x80]
00007d516e5dcd35  vmovaps xmm10, [rsp+0x90]
00007d516e5dcd3e  vmovaps xmm11, [rsp+0xA0]
00007d516e5dcd47  vmovaps xmm12, [rsp+0xB0]
00007d516e5dcd50  vmovaps xmm13, [rsp+0xC0]
00007d516e5dcd59  vmovaps xmm14, [rsp+0xD0]
00007d516e5dcd62  vmovaps xmm15, [rsp+0xE0]
00007d516e5dcd6b  add rsp, 0xF0
00007d516e5dcd72  pop r11
00007d516e5dcd74  pop r10
00007d516e5dcd76  pop r9
00007d516e5dcd78  pop r8
00007d516e5dcd7a  pop rsi
00007d516e5dcd7b  pop rdi
00007d516e5dcd7c  pop rdx
00007d516e5dcd7d  pop rcx
00007d516e5dcd7e  pop rax
00007d516e5dcd7f  add rsp, 0x08
00007d516e5dcd83  jmp 0x00007D516E5D9532
00007d516e5dcd88  sub rsp, 0x08
00007d516e5dcd8c  push rax
00007d516e5dcd8d  push rcx
00007d516e5dcd8e  push rdx
00007d516e5dcd8f  push rdi
00007d516e5dcd90  push rsi
00007d516e5dcd91  push r8
00007d516e5dcd93  push r9
00007d516e5dcd95  push r10
00007d516e5dcd97  push r11
00007d516e5dcd99  sub rsp, 0xF0
00007d516e5dcda0  vmovaps [rsp], xmm0
00007d516e5dcda5  vmovaps [rsp+0x10], xmm1
00007d516e5dcdab  vmovaps [rsp+0x20], xmm2
00007d516e5dcdb1  vmovaps [rsp+0x30], xmm3
00007d516e5dcdb7  vmovaps [rsp+0x40], xmm4
00007d516e5dcdbd  vmovaps [rsp+0x50], xmm5
00007d516e5dcdc3  vmovaps [rsp+0x60], xmm6
00007d516e5dcdc9  vmovaps [rsp+0x70], xmm7
00007d516e5dcdcf  vmovaps [rsp+0x80], xmm8
00007d516e5dcdd8  vmovaps [rsp+0x90], xmm9
00007d516e5dcde1  vmovaps [rsp+0xA0], xmm10
00007d516e5dcdea  vmovaps [rsp+0xB0], xmm12
00007d516e5dcdf3  vmovaps [rsp+0xC0], xmm13
00007d516e5dcdfc  vmovaps [rsp+0xD0], xmm14
00007d516e5dce05  vmovaps [rsp+0xE0], xmm15
00007d516e5dce0e  sub rsp, 0x30
00007d516e5dce12  movaps [rsp], xmm11
00007d516e5dce17  movaps [rsp+0x10], xmm10
00007d516e5dce1d  movaps [rsp+0x20], xmm6
00007d516e5dce22  lea rdi, [rsp]
00007d516e5dce26  mov esi, 0x00
00007d516e5dce2b  mov rax, 0x5EE43AF14530
00007d516e5dce35  call rax
00007d516e5dce37  movaps xmm11, [rsp]
00007d516e5dce3c  add rsp, 0x30
00007d516e5dce40  vmovaps xmm0, [rsp]
00007d516e5dce45  vmovaps xmm1, [rsp+0x10]
00007d516e5dce4b  vmovaps xmm2, [rsp+0x20]
00007d516e5dce51  vmovaps xmm3, [rsp+0x30]
00007d516e5dce57  vmovaps xmm4, [rsp+0x40]
00007d516e5dce5d  vmovaps xmm5, [rsp+0x50]
00007d516e5dce63  vmovaps xmm6, [rsp+0x60]
00007d516e5dce69  vmovaps xmm7, [rsp+0x70]
00007d516e5dce6f  vmovaps xmm8, [rsp+0x80]
00007d516e5dce78  vmovaps xmm9, [rsp+0x90]
00007d516e5dce81  vmovaps xmm10, [rsp+0xA0]
00007d516e5dce8a  vmovaps xmm12, [rsp+0xB0]
00007d516e5dce93  vmovaps xmm13, [rsp+0xC0]
00007d516e5dce9c  vmovaps xmm14, [rsp+0xD0]
00007d516e5dcea5  vmovaps xmm15, [rsp+0xE0]
00007d516e5dceae  add rsp, 0xF0
00007d516e5dceb5  pop r11
00007d516e5dceb7  pop r10
00007d516e5dceb9  pop r9
00007d516e5dcebb  pop r8
00007d516e5dcebd  pop rsi
00007d516e5dcebe  pop rdi
00007d516e5dcebf  pop rdx
00007d516e5dcec0  pop rcx
00007d516e5dcec1  pop rax
00007d516e5dcec2  add rsp, 0x08
00007d516e5dcec6  jmp 0x00007D516E5D954D
00007d516e5dcecb  sub rsp, 0x08
00007d516e5dcecf  push rax
00007d516e5dced0  push rcx
00007d516e5dced1  push rdx
00007d516e5dced2  push rdi
00007d516e5dced3  push rsi
00007d516e5dced4  push r8
00007d516e5dced6  push r9
00007d516e5dced8  push r10
00007d516e5dceda  push r11
00007d516e5dcedc  sub rsp, 0xF0
00007d516e5dcee3  vmovaps [rsp], xmm0
00007d516e5dcee8  vmovaps [rsp+0x10], xmm1
00007d516e5dceee  vmovaps [rsp+0x20], xmm2
00007d516e5dcef4  vmovaps [rsp+0x30], xmm3
00007d516e5dcefa  vmovaps [rsp+0x40], xmm4
00007d516e5dcf00  vmovaps [rsp+0x50], xmm5
00007d516e5dcf06  vmovaps [rsp+0x60], xmm6
00007d516e5dcf0c  vmovaps [rsp+0x70], xmm7
00007d516e5dcf12  vmovaps [rsp+0x80], xmm8
00007d516e5dcf1b  vmovaps [rsp+0x90], xmm9
00007d516e5dcf24  vmovaps [rsp+0xA0], xmm11
00007d516e5dcf2d  vmovaps [rsp+0xB0], xmm12
00007d516e5dcf36  vmovaps [rsp+0xC0], xmm13
00007d516e5dcf3f  vmovaps [rsp+0xD0], xmm14
00007d516e5dcf48  vmovaps [rsp+0xE0], xmm15
00007d516e5dcf51  sub rsp, 0x30
00007d516e5dcf55  movaps [rsp], xmm10
00007d516e5dcf5a  movaps [rsp+0x10], xmm14
00007d516e5dcf60  movaps [rsp+0x20], xmm4
00007d516e5dcf65  lea rdi, [rsp]
00007d516e5dcf69  mov esi, 0x00
00007d516e5dcf6e  mov rax, 0x5EE43AF14530
00007d516e5dcf78  call rax
00007d516e5dcf7a  movaps xmm10, [rsp]
00007d516e5dcf7f  add rsp, 0x30
00007d516e5dcf83  vmovaps xmm0, [rsp]
00007d516e5dcf88  vmovaps xmm1, [rsp+0x10]
00007d516e5dcf8e  vmovaps xmm2, [rsp+0x20]
00007d516e5dcf94  vmovaps xmm3, [rsp+0x30]
00007d516e5dcf9a  vmovaps xmm4, [rsp+0x40]
00007d516e5dcfa0  vmovaps xmm5, [rsp+0x50]
00007d516e5dcfa6  vmovaps xmm6, [rsp+0x60]
00007d516e5dcfac  vmovaps xmm7, [rsp+0x70]
00007d516e5dcfb2  vmovaps xmm8, [rsp+0x80]
00007d516e5dcfbb  vmovaps xmm9, [rsp+0x90]
00007d516e5dcfc4  vmovaps xmm11, [rsp+0xA0]
00007d516e5dcfcd  vmovaps xmm12, [rsp+0xB0]
00007d516e5dcfd6  vmovaps xmm13, [rsp+0xC0]
00007d516e5dcfdf  vmovaps xmm14, [rsp+0xD0]
00007d516e5dcfe8  vmovaps xmm15, [rsp+0xE0]
00007d516e5dcff1  add rsp, 0xF0
00007d516e5dcff8  pop r11
00007d516e5dcffa  pop r10
00007d516e5dcffc  pop r9
00007d516e5dcffe  pop r8
00007d516e5dd000  pop rsi
00007d516e5dd001  pop rdi
00007d516e5dd002  pop rdx
00007d516e5dd003  pop rcx
00007d516e5dd004  pop rax
00007d516e5dd005  add rsp, 0x08
00007d516e5dd009  jmp 0x00007D516E5D9568
00007d516e5dd00e  sub rsp, 0x08
00007d516e5dd012  push rax
00007d516e5dd013  push rcx
00007d516e5dd014  push rdx
00007d516e5dd015  push rdi
00007d516e5dd016  push rsi
00007d516e5dd017  push r8
00007d516e5dd019  push r9
00007d516e5dd01b  push r10
00007d516e5dd01d  push r11
00007d516e5dd01f  sub rsp, 0xF0
00007d516e5dd026  vmovaps [rsp], xmm0
00007d516e5dd02b  vmovaps [rsp+0x10], xmm1
00007d516e5dd031  vmovaps [rsp+0x20], xmm2
00007d516e5dd037  vmovaps [rsp+0x30], xmm3
00007d516e5dd03d  vmovaps [rsp+0x40], xmm4
00007d516e5dd043  vmovaps [rsp+0x50], xmm5
00007d516e5dd049  vmovaps [rsp+0x60], xmm6
00007d516e5dd04f  vmovaps [rsp+0x70], xmm7
00007d516e5dd055  vmovaps [rsp+0x80], xmm9
00007d516e5dd05e  vmovaps [rsp+0x90], xmm10
00007d516e5dd067  vmovaps [rsp+0xA0], xmm11
00007d516e5dd070  vmovaps [rsp+0xB0], xmm12
00007d516e5dd079  vmovaps [rsp+0xC0], xmm13
00007d516e5dd082  vmovaps [rsp+0xD0], xmm14
00007d516e5dd08b  vmovaps [rsp+0xE0], xmm15
00007d516e5dd094  sub rsp, 0x30
00007d516e5dd098  movaps [rsp], xmm8
00007d516e5dd09d  movaps [rsp+0x10], xmm1
00007d516e5dd0a2  movaps [rsp+0x20], xmm14
00007d516e5dd0a8  lea rdi, [rsp]
00007d516e5dd0ac  mov esi, 0x00
00007d516e5dd0b1  mov rax, 0x5EE43AF14530
00007d516e5dd0bb  call rax
00007d516e5dd0bd  movaps xmm8, [rsp]
00007d516e5dd0c2  add rsp, 0x30
00007d516e5dd0c6  vmovaps xmm0, [rsp]
00007d516e5dd0cb  vmovaps xmm1, [rsp+0x10]
00007d516e5dd0d1  vmovaps xmm2, [rsp+0x20]
00007d516e5dd0d7  vmovaps xmm3, [rsp+0x30]
00007d516e5dd0dd  vmovaps xmm4, [rsp+0x40]
00007d516e5dd0e3  vmovaps xmm5, [rsp+0x50]
00007d516e5dd0e9  vmovaps xmm6, [rsp+0x60]
00007d516e5dd0ef  vmovaps xmm7, [rsp+0x70]
00007d516e5dd0f5  vmovaps xmm9, [rsp+0x80]
00007d516e5dd0fe  vmovaps xmm10, [rsp+0x90]
00007d516e5dd107  vmovaps xmm11, [rsp+0xA0]
00007d516e5dd110  vmovaps xmm12, [rsp+0xB0]
00007d516e5dd119  vmovaps xmm13, [rsp+0xC0]
00007d516e5dd122  vmovaps xmm14, [rsp+0xD0]
00007d516e5dd12b  vmovaps xmm15, [rsp+0xE0]
00007d516e5dd134  add rsp, 0xF0
00007d516e5dd13b  pop r11
00007d516e5dd13d  pop r10
00007d516e5dd13f  pop r9
00007d516e5dd141  pop r8
00007d516e5dd143  pop rsi
00007d516e5dd144  pop rdi
00007d516e5dd145  pop rdx
00007d516e5dd146  pop rcx
00007d516e5dd147  pop rax
00007d516e5dd148  add rsp, 0x08
00007d516e5dd14c  jmp 0x00007D516E5D958E
00007d516e5dd151  sub rsp, 0x08
00007d516e5dd155  push rax
00007d516e5dd156  push rcx
00007d516e5dd157  push rdx
00007d516e5dd158  push rdi
00007d516e5dd159  push rsi
00007d516e5dd15a  push r8
00007d516e5dd15c  push r9
00007d516e5dd15e  push r10
00007d516e5dd160  push r11
00007d516e5dd162  sub rsp, 0xF0
00007d516e5dd169  vmovaps [rsp], xmm0
00007d516e5dd16e  vmovaps [rsp+0x10], xmm1
00007d516e5dd174  vmovaps [rsp+0x20], xmm2
00007d516e5dd17a  vmovaps [rsp+0x30], xmm3
00007d516e5dd180  vmovaps [rsp+0x40], xmm4
00007d516e5dd186  vmovaps [rsp+0x50], xmm5
00007d516e5dd18c  vmovaps [rsp+0x60], xmm7
00007d516e5dd192  vmovaps [rsp+0x70], xmm8
00007d516e5dd198  vmovaps [rsp+0x80], xmm9
00007d516e5dd1a1  vmovaps [rsp+0x90], xmm10
00007d516e5dd1aa  vmovaps [rsp+0xA0], xmm11
00007d516e5dd1b3  vmovaps [rsp+0xB0], xmm12
00007d516e5dd1bc  vmovaps [rsp+0xC0], xmm13
00007d516e5dd1c5  vmovaps [rsp+0xD0], xmm14
00007d516e5dd1ce  vmovaps [rsp+0xE0], xmm15
00007d516e5dd1d7  sub rsp, 0x30
00007d516e5dd1db  movaps [rsp], xmm6
00007d516e5dd1df  movaps [rsp+0x10], xmm1
00007d516e5dd1e4  movaps [rsp+0x20], xmm14
00007d516e5dd1ea  lea rdi, [rsp]
00007d516e5dd1ee  mov esi, 0x00
00007d516e5dd1f3  mov rax, 0x5EE43AF14530
00007d516e5dd1fd  call rax
00007d516e5dd1ff  movaps xmm6, [rsp]
00007d516e5dd203  add rsp, 0x30
00007d516e5dd207  vmovaps xmm0, [rsp]
00007d516e5dd20c  vmovaps xmm1, [rsp+0x10]
00007d516e5dd212  vmovaps xmm2, [rsp+0x20]
00007d516e5dd218  vmovaps xmm3, [rsp+0x30]
00007d516e5dd21e  vmovaps xmm4, [rsp+0x40]
00007d516e5dd224  vmovaps xmm5, [rsp+0x50]
00007d516e5dd22a  vmovaps xmm7, [rsp+0x60]
00007d516e5dd230  vmovaps xmm8, [rsp+0x70]
00007d516e5dd236  vmovaps xmm9, [rsp+0x80]
00007d516e5dd23f  vmovaps xmm10, [rsp+0x90]
00007d516e5dd248  vmovaps xmm11, [rsp+0xA0]
00007d516e5dd251  vmovaps xmm12, [rsp+0xB0]
00007d516e5dd25a  vmovaps xmm13, [rsp+0xC0]
00007d516e5dd263  vmovaps xmm14, [rsp+0xD0]
00007d516e5dd26c  vmovaps xmm15, [rsp+0xE0]
00007d516e5dd275  add rsp, 0xF0
00007d516e5dd27c  pop r11
00007d516e5dd27e  pop r10
00007d516e5dd280  pop r9
00007d516e5dd282  pop r8
00007d516e5dd284  pop rsi
00007d516e5dd285  pop rdi
00007d516e5dd286  pop rdx
00007d516e5dd287  pop rcx
00007d516e5dd288  pop rax
00007d516e5dd289  add rsp, 0x08
00007d516e5dd28d  jmp 0x00007D516E5D95BA
00007d516e5dd292  sub rsp, 0x08
00007d516e5dd296  push rax
00007d516e5dd297  push rcx
00007d516e5dd298  push rdx
00007d516e5dd299  push rdi
00007d516e5dd29a  push rsi
00007d516e5dd29b  push r8
00007d516e5dd29d  push r9
00007d516e5dd29f  push r10
00007d516e5dd2a1  push r11
00007d516e5dd2a3  sub rsp, 0xF0
00007d516e5dd2aa  vmovaps [rsp], xmm0
00007d516e5dd2af  vmovaps [rsp+0x10], xmm1
00007d516e5dd2b5  vmovaps [rsp+0x20], xmm2
00007d516e5dd2bb  vmovaps [rsp+0x30], xmm3
00007d516e5dd2c1  vmovaps [rsp+0x40], xmm4
00007d516e5dd2c7  vmovaps [rsp+0x50], xmm5
00007d516e5dd2cd  vmovaps [rsp+0x60], xmm6
00007d516e5dd2d3  vmovaps [rsp+0x70], xmm7
00007d516e5dd2d9  vmovaps [rsp+0x80], xmm8
00007d516e5dd2e2  vmovaps [rsp+0x90], xmm9
00007d516e5dd2eb  vmovaps [rsp+0xA0], xmm10
00007d516e5dd2f4  vmovaps [rsp+0xB0], xmm11
00007d516e5dd2fd  vmovaps [rsp+0xC0], xmm12
00007d516e5dd306  vmovaps [rsp+0xD0], xmm13
00007d516e5dd30f  vmovaps [rsp+0xE0], xmm15
00007d516e5dd318  sub rsp, 0x30
00007d516e5dd31c  movaps [rsp], xmm14
00007d516e5dd321  movaps [rsp+0x10], xmm12
00007d516e5dd327  movaps [rsp+0x20], xmm1
00007d516e5dd32c  lea rdi, [rsp]
00007d516e5dd330  mov esi, 0x00
00007d516e5dd335  mov rax, 0x5EE43AF14530
00007d516e5dd33f  call rax
00007d516e5dd341  movaps xmm14, [rsp]
00007d516e5dd346  add rsp, 0x30
00007d516e5dd34a  vmovaps xmm0, [rsp]
00007d516e5dd34f  vmovaps xmm1, [rsp+0x10]
00007d516e5dd355  vmovaps xmm2, [rsp+0x20]
00007d516e5dd35b  vmovaps xmm3, [rsp+0x30]
00007d516e5dd361  vmovaps xmm4, [rsp+0x40]
00007d516e5dd367  vmovaps xmm5, [rsp+0x50]
00007d516e5dd36d  vmovaps xmm6, [rsp+0x60]
00007d516e5dd373  vmovaps xmm7, [rsp+0x70]
00007d516e5dd379  vmovaps xmm8, [rsp+0x80]
00007d516e5dd382  vmovaps xmm9, [rsp+0x90]
00007d516e5dd38b  vmovaps xmm10, [rsp+0xA0]
00007d516e5dd394  vmovaps xmm11, [rsp+0xB0]
00007d516e5dd39d  vmovaps xmm12, [rsp+0xC0]
00007d516e5dd3a6  vmovaps xmm13, [rsp+0xD0]
00007d516e5dd3af  vmovaps xmm15, [rsp+0xE0]
00007d516e5dd3b8  add rsp, 0xF0
00007d516e5dd3bf  pop r11
00007d516e5dd3c1  pop r10
00007d516e5dd3c3  pop r9
00007d516e5dd3c5  pop r8
00007d516e5dd3c7  pop rsi
00007d516e5dd3c8  pop rdi
00007d516e5dd3c9  pop rdx
00007d516e5dd3ca  pop rcx
00007d516e5dd3cb  pop rax
00007d516e5dd3cc  add rsp, 0x08
00007d516e5dd3d0  jmp 0x00007D516E5D95E0
00007d516e5dd3d5  sub rsp, 0x08
00007d516e5dd3d9  push rax
00007d516e5dd3da  push rcx
00007d516e5dd3db  push rdx
00007d516e5dd3dc  push rdi
00007d516e5dd3dd  push rsi
00007d516e5dd3de  push r8
00007d516e5dd3e0  push r9
00007d516e5dd3e2  push r10
00007d516e5dd3e4  push r11
00007d516e5dd3e6  sub rsp, 0xF0
00007d516e5dd3ed  vmovaps [rsp], xmm0
00007d516e5dd3f2  vmovaps [rsp+0x10], xmm2
00007d516e5dd3f8  vmovaps [rsp+0x20], xmm3
00007d516e5dd3fe  vmovaps [rsp+0x30], xmm4
00007d516e5dd404  vmovaps [rsp+0x40], xmm5
00007d516e5dd40a  vmovaps [rsp+0x50], xmm6
00007d516e5dd410  vmovaps [rsp+0x60], xmm7
00007d516e5dd416  vmovaps [rsp+0x70], xmm8
00007d516e5dd41c  vmovaps [rsp+0x80], xmm9
00007d516e5dd425  vmovaps [rsp+0x90], xmm10
00007d516e5dd42e  vmovaps [rsp+0xA0], xmm11
00007d516e5dd437  vmovaps [rsp+0xB0], xmm12
00007d516e5dd440  vmovaps [rsp+0xC0], xmm13
00007d516e5dd449  vmovaps [rsp+0xD0], xmm14
00007d516e5dd452  vmovaps [rsp+0xE0], xmm15
00007d516e5dd45b  sub rsp, 0x30
00007d516e5dd45f  movaps [rsp], xmm1
00007d516e5dd463  movaps [rsp+0x10], xmm13
00007d516e5dd469  movaps [rsp+0x20], xmm9
00007d516e5dd46f  lea rdi, [rsp]
00007d516e5dd473  mov esi, 0x00
00007d516e5dd478  mov rax, 0x5EE43AF14530
00007d516e5dd482  call rax
00007d516e5dd484  movaps xmm1, [rsp]
00007d516e5dd488  add rsp, 0x30
00007d516e5dd48c  vmovaps xmm0, [rsp]
00007d516e5dd491  vmovaps xmm2, [rsp+0x10]
00007d516e5dd497  vmovaps xmm3, [rsp+0x20]
00007d516e5dd49d  vmovaps xmm4, [rsp+0x30]
00007d516e5dd4a3  vmovaps xmm5, [rsp+0x40]
00007d516e5dd4a9  vmovaps xmm6, [rsp+0x50]
00007d516e5dd4af  vmovaps xmm7, [rsp+0x60]
00007d516e5dd4b5  vmovaps xmm8, [rsp+0x70]
00007d516e5dd4bb  vmovaps xmm9, [rsp+0x80]
00007d516e5dd4c4  vmovaps xmm10, [rsp+0x90]
00007d516e5dd4cd  vmovaps xmm11, [rsp+0xA0]
00007d516e5dd4d6  vmovaps xmm12, [rsp+0xB0]
00007d516e5dd4df  vmovaps xmm13, [rsp+0xC0]
00007d516e5dd4e8  vmovaps xmm14, [rsp+0xD0]
00007d516e5dd4f1  vmovaps xmm15, [rsp+0xE0]
00007d516e5dd4fa  add rsp, 0xF0
00007d516e5dd501  pop r11
00007d516e5dd503  pop r10
00007d516e5dd505  pop r9
00007d516e5dd507  pop r8
00007d516e5dd509  pop rsi
00007d516e5dd50a  pop rdi
00007d516e5dd50b  pop rdx
00007d516e5dd50c  pop rcx
00007d516e5dd50d  pop rax
00007d516e5dd50e  add rsp, 0x08
00007d516e5dd512  jmp 0x00007D516E5D95FA
00007d516e5dd517  sub rsp, 0x08
00007d516e5dd51b  push rax
00007d516e5dd51c  push rcx
00007d516e5dd51d  push rdx
00007d516e5dd51e  push rdi
00007d516e5dd51f  push rsi
00007d516e5dd520  push r8
00007d516e5dd522  push r9
00007d516e5dd524  push r10
00007d516e5dd526  push r11
00007d516e5dd528  sub rsp, 0xF0
00007d516e5dd52f  vmovaps [rsp], xmm0
00007d516e5dd534  vmovaps [rsp+0x10], xmm1
00007d516e5dd53a  vmovaps [rsp+0x20], xmm2
00007d516e5dd540  vmovaps [rsp+0x30], xmm3
00007d516e5dd546  vmovaps [rsp+0x40], xmm4
00007d516e5dd54c  vmovaps [rsp+0x50], xmm5
00007d516e5dd552  vmovaps [rsp+0x60], xmm6
00007d516e5dd558  vmovaps [rsp+0x70], xmm7
00007d516e5dd55e  vmovaps [rsp+0x80], xmm8
00007d516e5dd567  vmovaps [rsp+0x90], xmm9
00007d516e5dd570  vmovaps [rsp+0xA0], xmm10
00007d516e5dd579  vmovaps [rsp+0xB0], xmm11
00007d516e5dd582  vmovaps [rsp+0xC0], xmm13
00007d516e5dd58b  vmovaps [rsp+0xD0], xmm14
00007d516e5dd594  vmovaps [rsp+0xE0], xmm15
00007d516e5dd59d  sub rsp, 0x30
00007d516e5dd5a1  movaps [rsp], xmm12
00007d516e5dd5a6  movaps [rsp+0x10], xmm7
00007d516e5dd5ab  movaps [rsp+0x20], xmm13
00007d516e5dd5b1  lea rdi, [rsp]
00007d516e5dd5b5  mov esi, 0x00
00007d516e5dd5ba  mov rax, 0x5EE43AF14530
00007d516e5dd5c4  call rax
00007d516e5dd5c6  movaps xmm12, [rsp]
00007d516e5dd5cb  add rsp, 0x30
00007d516e5dd5cf  vmovaps xmm0, [rsp]
00007d516e5dd5d4  vmovaps xmm1, [rsp+0x10]
00007d516e5dd5da  vmovaps xmm2, [rsp+0x20]
00007d516e5dd5e0  vmovaps xmm3, [rsp+0x30]
00007d516e5dd5e6  vmovaps xmm4, [rsp+0x40]
00007d516e5dd5ec  vmovaps xmm5, [rsp+0x50]
00007d516e5dd5f2  vmovaps xmm6, [rsp+0x60]
00007d516e5dd5f8  vmovaps xmm7, [rsp+0x70]
00007d516e5dd5fe  vmovaps xmm8, [rsp+0x80]
00007d516e5dd607  vmovaps xmm9, [rsp+0x90]
00007d516e5dd610  vmovaps xmm10, [rsp+0xA0]
00007d516e5dd619  vmovaps xmm11, [rsp+0xB0]
00007d516e5dd622  vmovaps xmm13, [rsp+0xC0]
00007d516e5dd62b  vmovaps xmm14, [rsp+0xD0]
00007d516e5dd634  vmovaps xmm15, [rsp+0xE0]
00007d516e5dd63d  add rsp, 0xF0
00007d516e5dd644  pop r11
00007d516e5dd646  pop r10
00007d516e5dd648  pop r9
00007d516e5dd64a  pop r8
00007d516e5dd64c  pop rsi
00007d516e5dd64d  pop rdi
00007d516e5dd64e  pop rdx
00007d516e5dd64f  pop rcx
00007d516e5dd650  pop rax
00007d516e5dd651  add rsp, 0x08
00007d516e5dd655  jmp 0x00007D516E5D9621
00007d516e5dd65a  sub rsp, 0x08
00007d516e5dd65e  push rax
00007d516e5dd65f  push rcx
00007d516e5dd660  push rdx
00007d516e5dd661  push rdi
00007d516e5dd662  push rsi
00007d516e5dd663  push r8
00007d516e5dd665  push r9
00007d516e5dd667  push r10
00007d516e5dd669  push r11
00007d516e5dd66b  sub rsp, 0xF0
00007d516e5dd672  vmovaps [rsp], xmm0
00007d516e5dd677  vmovaps [rsp+0x10], xmm1
00007d516e5dd67d  vmovaps [rsp+0x20], xmm2
00007d516e5dd683  vmovaps [rsp+0x30], xmm3
00007d516e5dd689  vmovaps [rsp+0x40], xmm4
00007d516e5dd68f  vmovaps [rsp+0x50], xmm5
00007d516e5dd695  vmovaps [rsp+0x60], xmm6
00007d516e5dd69b  vmovaps [rsp+0x70], xmm7
00007d516e5dd6a1  vmovaps [rsp+0x80], xmm8
00007d516e5dd6aa  vmovaps [rsp+0x90], xmm9
00007d516e5dd6b3  vmovaps [rsp+0xA0], xmm10
00007d516e5dd6bc  vmovaps [rsp+0xB0], xmm11
00007d516e5dd6c5  vmovaps [rsp+0xC0], xmm12
00007d516e5dd6ce  vmovaps [rsp+0xD0], xmm14
00007d516e5dd6d7  vmovaps [rsp+0xE0], xmm15
00007d516e5dd6e0  sub rsp, 0x30
00007d516e5dd6e4  movaps [rsp], xmm13
00007d516e5dd6e9  movaps [rsp+0x10], xmm15
00007d516e5dd6ef  movaps [rsp+0x20], xmm8
00007d516e5dd6f5  lea rdi, [rsp]
00007d516e5dd6f9  mov esi, 0x00
00007d516e5dd6fe  mov rax, 0x5EE43AF14530
00007d516e5dd708  call rax
00007d516e5dd70a  movaps xmm13, [rsp]
00007d516e5dd70f  add rsp, 0x30
00007d516e5dd713  vmovaps xmm0, [rsp]
00007d516e5dd718  vmovaps xmm1, [rsp+0x10]
00007d516e5dd71e  vmovaps xmm2, [rsp+0x20]
00007d516e5dd724  vmovaps xmm3, [rsp+0x30]
00007d516e5dd72a  vmovaps xmm4, [rsp+0x40]
00007d516e5dd730  vmovaps xmm5, [rsp+0x50]
00007d516e5dd736  vmovaps xmm6, [rsp+0x60]
00007d516e5dd73c  vmovaps xmm7, [rsp+0x70]
00007d516e5dd742  vmovaps xmm8, [rsp+0x80]
00007d516e5dd74b  vmovaps xmm9, [rsp+0x90]
00007d516e5dd754  vmovaps xmm10, [rsp+0xA0]
00007d516e5dd75d  vmovaps xmm11, [rsp+0xB0]
00007d516e5dd766  vmovaps xmm12, [rsp+0xC0]
00007d516e5dd76f  vmovaps xmm14, [rsp+0xD0]
00007d516e5dd778  vmovaps xmm15, [rsp+0xE0]
00007d516e5dd781  add rsp, 0xF0
00007d516e5dd788  pop r11
00007d516e5dd78a  pop r10
00007d516e5dd78c  pop r9
00007d516e5dd78e  pop r8
00007d516e5dd790  pop rsi
00007d516e5dd791  pop rdi
00007d516e5dd792  pop rdx
00007d516e5dd793  pop rcx
00007d516e5dd794  pop rax
00007d516e5dd795  add rsp, 0x08
00007d516e5dd799  jmp 0x00007D516E5D963C
00007d516e5dd79e  sub rsp, 0x08
00007d516e5dd7a2  push rax
00007d516e5dd7a3  push rcx
00007d516e5dd7a4  push rdx
00007d516e5dd7a5  push rdi
00007d516e5dd7a6  push rsi
00007d516e5dd7a7  push r8
00007d516e5dd7a9  push r9
00007d516e5dd7ab  push r10
00007d516e5dd7ad  push r11
00007d516e5dd7af  sub rsp, 0xF0
00007d516e5dd7b6  vmovaps [rsp], xmm0
00007d516e5dd7bb  vmovaps [rsp+0x10], xmm1
00007d516e5dd7c1  vmovaps [rsp+0x20], xmm2
00007d516e5dd7c7  vmovaps [rsp+0x30], xmm3
00007d516e5dd7cd  vmovaps [rsp+0x40], xmm4
00007d516e5dd7d3  vmovaps [rsp+0x50], xmm5
00007d516e5dd7d9  vmovaps [rsp+0x60], xmm6
00007d516e5dd7df  vmovaps [rsp+0x70], xmm7
00007d516e5dd7e5  vmovaps [rsp+0x80], xmm9
00007d516e5dd7ee  vmovaps [rsp+0x90], xmm10
00007d516e5dd7f7  vmovaps [rsp+0xA0], xmm11
00007d516e5dd800  vmovaps [rsp+0xB0], xmm12
00007d516e5dd809  vmovaps [rsp+0xC0], xmm13
00007d516e5dd812  vmovaps [rsp+0xD0], xmm14
00007d516e5dd81b  vmovaps [rsp+0xE0], xmm15
00007d516e5dd824  sub rsp, 0x30
00007d516e5dd828  movaps [rsp], xmm8
00007d516e5dd82d  movaps [rsp+0x10], xmm15
00007d516e5dd833  movaps [rsp+0x20], xmm9
00007d516e5dd839  lea rdi, [rsp]
00007d516e5dd83d  mov esi, 0x00
00007d516e5dd842  mov rax, 0x5EE43AF14530
00007d516e5dd84c  call rax
00007d516e5dd84e  movaps xmm8, [rsp]
00007d516e5dd853  add rsp, 0x30
00007d516e5dd857  vmovaps xmm0, [rsp]
00007d516e5dd85c  vmovaps xmm1, [rsp+0x10]
00007d516e5dd862  vmovaps xmm2, [rsp+0x20]
00007d516e5dd868  vmovaps xmm3, [rsp+0x30]
00007d516e5dd86e  vmovaps xmm4, [rsp+0x40]
00007d516e5dd874  vmovaps xmm5, [rsp+0x50]
00007d516e5dd87a  vmovaps xmm6, [rsp+0x60]
00007d516e5dd880  vmovaps xmm7, [rsp+0x70]
00007d516e5dd886  vmovaps xmm9, [rsp+0x80]
00007d516e5dd88f  vmovaps xmm10, [rsp+0x90]
00007d516e5dd898  vmovaps xmm11, [rsp+0xA0]
00007d516e5dd8a1  vmovaps xmm12, [rsp+0xB0]
00007d516e5dd8aa  vmovaps xmm13, [rsp+0xC0]
00007d516e5dd8b3  vmovaps xmm14, [rsp+0xD0]
00007d516e5dd8bc  vmovaps xmm15, [rsp+0xE0]
00007d516e5dd8c5  add rsp, 0xF0
00007d516e5dd8cc  pop r11
00007d516e5dd8ce  pop r10
00007d516e5dd8d0  pop r9
00007d516e5dd8d2  pop r8
00007d516e5dd8d4  pop rsi
00007d516e5dd8d5  pop rdi
00007d516e5dd8d6  pop rdx
00007d516e5dd8d7  pop rcx
00007d516e5dd8d8  pop rax
00007d516e5dd8d9  add rsp, 0x08
00007d516e5dd8dd  jmp 0x00007D516E5D966A
00007d516e5dd8e2  sub rsp, 0x08
00007d516e5dd8e6  push rax
00007d516e5dd8e7  push rcx
00007d516e5dd8e8  push rdx
00007d516e5dd8e9  push rdi
00007d516e5dd8ea  push rsi
00007d516e5dd8eb  push r8
00007d516e5dd8ed  push r9
00007d516e5dd8ef  push r10
00007d516e5dd8f1  push r11
00007d516e5dd8f3  sub rsp, 0xF0
00007d516e5dd8fa  vmovaps [rsp], xmm0
00007d516e5dd8ff  vmovaps [rsp+0x10], xmm1
00007d516e5dd905  vmovaps [rsp+0x20], xmm2
00007d516e5dd90b  vmovaps [rsp+0x30], xmm3
00007d516e5dd911  vmovaps [rsp+0x40], xmm4
00007d516e5dd917  vmovaps [rsp+0x50], xmm5
00007d516e5dd91d  vmovaps [rsp+0x60], xmm6
00007d516e5dd923  vmovaps [rsp+0x70], xmm7
00007d516e5dd929  vmovaps [rsp+0x80], xmm8
00007d516e5dd932  vmovaps [rsp+0x90], xmm9
00007d516e5dd93b  vmovaps [rsp+0xA0], xmm10
00007d516e5dd944  vmovaps [rsp+0xB0], xmm11
00007d516e5dd94d  vmovaps [rsp+0xC0], xmm12
00007d516e5dd956  vmovaps [rsp+0xD0], xmm13
00007d516e5dd95f  vmovaps [rsp+0xE0], xmm14
00007d516e5dd968  sub rsp, 0x30
00007d516e5dd96c  movaps [rsp], xmm15
00007d516e5dd971  movaps [rsp+0x10], xmm11
00007d516e5dd977  movaps [rsp+0x20], xmm6
00007d516e5dd97c  lea rdi, [rsp]
00007d516e5dd980  mov esi, 0x00
00007d516e5dd985  mov rax, 0x5EE43AF14530
00007d516e5dd98f  call rax
00007d516e5dd991  movaps xmm15, [rsp]
00007d516e5dd996  add rsp, 0x30
00007d516e5dd99a  vmovaps xmm0, [rsp]
00007d516e5dd99f  vmovaps xmm1, [rsp+0x10]
00007d516e5dd9a5  vmovaps xmm2, [rsp+0x20]
00007d516e5dd9ab  vmovaps xmm3, [rsp+0x30]
00007d516e5dd9b1  vmovaps xmm4, [rsp+0x40]
00007d516e5dd9b7  vmovaps xmm5, [rsp+0x50]
00007d516e5dd9bd  vmovaps xmm6, [rsp+0x60]
00007d516e5dd9c3  vmovaps xmm7, [rsp+0x70]
00007d516e5dd9c9  vmovaps xmm8, [rsp+0x80]
00007d516e5dd9d2  vmovaps xmm9, [rsp+0x90]
00007d516e5dd9db  vmovaps xmm10, [rsp+0xA0]
00007d516e5dd9e4  vmovaps xmm11, [rsp+0xB0]
00007d516e5dd9ed  vmovaps xmm12, [rsp+0xC0]
00007d516e5dd9f6  vmovaps xmm13, [rsp+0xD0]
00007d516e5dd9ff  vmovaps xmm14, [rsp+0xE0]
00007d516e5dda08  add rsp, 0xF0
00007d516e5dda0f  pop r11
00007d516e5dda11  pop r10
00007d516e5dda13  pop r9
00007d516e5dda15  pop r8
00007d516e5dda17  pop rsi
00007d516e5dda18  pop rdi
00007d516e5dda19  pop rdx
00007d516e5dda1a  pop rcx
00007d516e5dda1b  pop rax
00007d516e5dda1c  add rsp, 0x08
00007d516e5dda20  jmp 0x00007D516E5D9685
00007d516e5dda25  sub rsp, 0x08
00007d516e5dda29  push rax
00007d516e5dda2a  push rcx
00007d516e5dda2b  push rdx
00007d516e5dda2c  push rdi
00007d516e5dda2d  push rsi
00007d516e5dda2e  push r8
00007d516e5dda30  push r9
00007d516e5dda32  push r10
00007d516e5dda34  push r11
00007d516e5dda36  sub rsp, 0xF0
00007d516e5dda3d  vmovaps [rsp], xmm0
00007d516e5dda42  vmovaps [rsp+0x10], xmm1
00007d516e5dda48  vmovaps [rsp+0x20], xmm2
00007d516e5dda4e  vmovaps [rsp+0x30], xmm3
00007d516e5dda54  vmovaps [rsp+0x40], xmm4
00007d516e5dda5a  vmovaps [rsp+0x50], xmm5
00007d516e5dda60  vmovaps [rsp+0x60], xmm6
00007d516e5dda66  vmovaps [rsp+0x70], xmm8
00007d516e5dda6c  vmovaps [rsp+0x80], xmm9
00007d516e5dda75  vmovaps [rsp+0x90], xmm10
00007d516e5dda7e  vmovaps [rsp+0xA0], xmm11
00007d516e5dda87  vmovaps [rsp+0xB0], xmm12
00007d516e5dda90  vmovaps [rsp+0xC0], xmm13
00007d516e5dda99  vmovaps [rsp+0xD0], xmm14
00007d516e5ddaa2  vmovaps [rsp+0xE0], xmm15
00007d516e5ddaab  sub rsp, 0x30
00007d516e5ddaaf  movaps [rsp], xmm7
00007d516e5ddab3  movaps [rsp+0x10], xmm11
00007d516e5ddab9  movaps [rsp+0x20], xmm9
00007d516e5ddabf  lea rdi, [rsp]
00007d516e5ddac3  mov esi, 0x00
00007d516e5ddac8  mov rax, 0x5EE43AF14530
00007d516e5ddad2  call rax
00007d516e5ddad4  movaps xmm7, [rsp]
00007d516e5ddad8  add rsp, 0x30
00007d516e5ddadc  vmovaps xmm0, [rsp]
00007d516e5ddae1  vmovaps xmm1, [rsp+0x10]
00007d516e5ddae7  vmovaps xmm2, [rsp+0x20]
00007d516e5ddaed  vmovaps xmm3, [rsp+0x30]
00007d516e5ddaf3  vmovaps xmm4, [rsp+0x40]
00007d516e5ddaf9  vmovaps xmm5, [rsp+0x50]
00007d516e5ddaff  vmovaps xmm6, [rsp+0x60]
00007d516e5ddb05  vmovaps xmm8, [rsp+0x70]
00007d516e5ddb0b  vmovaps xmm9, [rsp+0x80]
00007d516e5ddb14  vmovaps xmm10, [rsp+0x90]
00007d516e5ddb1d  vmovaps xmm11, [rsp+0xA0]
00007d516e5ddb26  vmovaps xmm12, [rsp+0xB0]
00007d516e5ddb2f  vmovaps xmm13, [rsp+0xC0]
00007d516e5ddb38  vmovaps xmm14, [rsp+0xD0]
00007d516e5ddb41  vmovaps xmm15, [rsp+0xE0]
00007d516e5ddb4a  add rsp, 0xF0
00007d516e5ddb51  pop r11
00007d516e5ddb53  pop r10
00007d516e5ddb55  pop r9
00007d516e5ddb57  pop r8
00007d516e5ddb59  pop rsi
00007d516e5ddb5a  pop rdi
00007d516e5ddb5b  pop rdx
00007d516e5ddb5c  pop rcx
00007d516e5ddb5d  pop rax
00007d516e5ddb5e  add rsp, 0x08
00007d516e5ddb62  jmp 0x00007D516E5D96B2
00007d516e5ddb67  sub rsp, 0x08
00007d516e5ddb6b  push rax
00007d516e5ddb6c  push rcx
00007d516e5ddb6d  push rdx
00007d516e5ddb6e  push rdi
00007d516e5ddb6f  push rsi
00007d516e5ddb70  push r8
00007d516e5ddb72  push r9
00007d516e5ddb74  push r10
00007d516e5ddb76  push r11
00007d516e5ddb78  sub rsp, 0xF0
00007d516e5ddb7f  vmovaps [rsp], xmm0
00007d516e5ddb84  vmovaps [rsp+0x10], xmm1
00007d516e5ddb8a  vmovaps [rsp+0x20], xmm2
00007d516e5ddb90  vmovaps [rsp+0x30], xmm3
00007d516e5ddb96  vmovaps [rsp+0x40], xmm4
00007d516e5ddb9c  vmovaps [rsp+0x50], xmm5
00007d516e5ddba2  vmovaps [rsp+0x60], xmm6
00007d516e5ddba8  vmovaps [rsp+0x70], xmm7
00007d516e5ddbae  vmovaps [rsp+0x80], xmm8
00007d516e5ddbb7  vmovaps [rsp+0x90], xmm9
00007d516e5ddbc0  vmovaps [rsp+0xA0], xmm10
00007d516e5ddbc9  vmovaps [rsp+0xB0], xmm12
00007d516e5ddbd2  vmovaps [rsp+0xC0], xmm13
00007d516e5ddbdb  vmovaps [rsp+0xD0], xmm14
00007d516e5ddbe4  vmovaps [rsp+0xE0], xmm15
00007d516e5ddbed  sub rsp, 0x30
00007d516e5ddbf1  movaps [rsp], xmm11
00007d516e5ddbf6  movaps [rsp+0x10], xmm10
00007d516e5ddbfc  movaps [rsp+0x20], xmm14
00007d516e5ddc02  lea rdi, [rsp]
00007d516e5ddc06  mov esi, 0x00
00007d516e5ddc0b  mov rax, 0x5EE43AF14530
00007d516e5ddc15  call rax
00007d516e5ddc17  movaps xmm11, [rsp]
00007d516e5ddc1c  add rsp, 0x30
00007d516e5ddc20  vmovaps xmm0, [rsp]
00007d516e5ddc25  vmovaps xmm1, [rsp+0x10]
00007d516e5ddc2b  vmovaps xmm2, [rsp+0x20]
00007d516e5ddc31  vmovaps xmm3, [rsp+0x30]
00007d516e5ddc37  vmovaps xmm4, [rsp+0x40]
00007d516e5ddc3d  vmovaps xmm5, [rsp+0x50]
00007d516e5ddc43  vmovaps xmm6, [rsp+0x60]
00007d516e5ddc49  vmovaps xmm7, [rsp+0x70]
00007d516e5ddc4f  vmovaps xmm8, [rsp+0x80]
00007d516e5ddc58  vmovaps xmm9, [rsp+0x90]
00007d516e5ddc61  vmovaps xmm10, [rsp+0xA0]
00007d516e5ddc6a  vmovaps xmm12, [rsp+0xB0]
00007d516e5ddc73  vmovaps xmm13, [rsp+0xC0]
00007d516e5ddc7c  vmovaps xmm14, [rsp+0xD0]
00007d516e5ddc85  vmovaps xmm15, [rsp+0xE0]
00007d516e5ddc8e  add rsp, 0xF0
00007d516e5ddc95  pop r11
00007d516e5ddc97  pop r10
00007d516e5ddc99  pop r9
00007d516e5ddc9b  pop r8
00007d516e5ddc9d  pop rsi
00007d516e5ddc9e  pop rdi
00007d516e5ddc9f  pop rdx
00007d516e5ddca0  pop rcx
00007d516e5ddca1  pop rax
00007d516e5ddca2  add rsp, 0x08
00007d516e5ddca6  jmp 0x00007D516E5D96CD
00007d516e5ddcab  call 0x00007D516E4E45A0
00007d516e5ddcb0  jmp 0x00007D516E5D96D7
00007d516e5ddcb5  sub rsp, 0x08
00007d516e5ddcb9  push rax
00007d516e5ddcba  push rcx
00007d516e5ddcbb  push rdx
00007d516e5ddcbc  push rdi
00007d516e5ddcbd  push rsi
00007d516e5ddcbe  push r8
00007d516e5ddcc0  push r9
00007d516e5ddcc2  push r10
00007d516e5ddcc4  push r11
00007d516e5ddcc6  sub rsp, 0xF0
00007d516e5ddccd  vmovaps [rsp], xmm0
00007d516e5ddcd2  vmovaps [rsp+0x10], xmm1
00007d516e5ddcd8  vmovaps [rsp+0x20], xmm2
00007d516e5ddcde  vmovaps [rsp+0x30], xmm3
00007d516e5ddce4  vmovaps [rsp+0x40], xmm4
00007d516e5ddcea  vmovaps [rsp+0x50], xmm5
00007d516e5ddcf0  vmovaps [rsp+0x60], xmm6
00007d516e5ddcf6  vmovaps [rsp+0x70], xmm7
00007d516e5ddcfc  vmovaps [rsp+0x80], xmm8
00007d516e5ddd05  vmovaps [rsp+0x90], xmm9
00007d516e5ddd0e  vmovaps [rsp+0xA0], xmm11
00007d516e5ddd17  vmovaps [rsp+0xB0], xmm12
00007d516e5ddd20  vmovaps [rsp+0xC0], xmm13
00007d516e5ddd29  vmovaps [rsp+0xD0], xmm14
00007d516e5ddd32  vmovaps [rsp+0xE0], xmm15
00007d516e5ddd3b  sub rsp, 0x30
00007d516e5ddd3f  movaps [rsp], xmm10
00007d516e5ddd44  movaps [rsp+0x10], xmm1
00007d516e5ddd49  movaps [rsp+0x20], xmm12
00007d516e5ddd4f  lea rdi, [rsp]
00007d516e5ddd53  mov esi, 0x00
00007d516e5ddd58  mov rax, 0x5EE43AF14530
00007d516e5ddd62  call rax
00007d516e5ddd64  movaps xmm10, [rsp]
00007d516e5ddd69  add rsp, 0x30
00007d516e5ddd6d  vmovaps xmm0, [rsp]
00007d516e5ddd72  vmovaps xmm1, [rsp+0x10]
00007d516e5ddd78  vmovaps xmm2, [rsp+0x20]
00007d516e5ddd7e  vmovaps xmm3, [rsp+0x30]
00007d516e5ddd84  vmovaps xmm4, [rsp+0x40]
00007d516e5ddd8a  vmovaps xmm5, [rsp+0x50]
00007d516e5ddd90  vmovaps xmm6, [rsp+0x60]
00007d516e5ddd96  vmovaps xmm7, [rsp+0x70]
00007d516e5ddd9c  vmovaps xmm8, [rsp+0x80]
00007d516e5ddda5  vmovaps xmm9, [rsp+0x90]
00007d516e5dddae  vmovaps xmm11, [rsp+0xA0]
00007d516e5dddb7  vmovaps xmm12, [rsp+0xB0]
00007d516e5dddc0  vmovaps xmm13, [rsp+0xC0]
00007d516e5dddc9  vmovaps xmm14, [rsp+0xD0]
00007d516e5dddd2  vmovaps xmm15, [rsp+0xE0]
00007d516e5ddddb  add rsp, 0xF0
00007d516e5ddde2  pop r11
00007d516e5ddde4  pop r10
00007d516e5ddde6  pop r9
00007d516e5ddde8  pop r8
00007d516e5dddea  pop rsi
00007d516e5dddeb  pop rdi
00007d516e5dddec  pop rdx
00007d516e5ddded  pop rcx
00007d516e5dddee  pop rax
00007d516e5dddef  add rsp, 0x08
00007d516e5dddf3  jmp 0x00007D516E5D96FA
00007d516e5dddf8  sub rsp, 0x08
00007d516e5dddfc  push rax
00007d516e5dddfd  push rcx
00007d516e5dddfe  push rdx
00007d516e5dddff  push rdi
00007d516e5dde00  push rsi
00007d516e5dde01  push r8
00007d516e5dde03  push r9
00007d516e5dde05  push r10
00007d516e5dde07  push r11
00007d516e5dde09  sub rsp, 0xF0
00007d516e5dde10  vmovaps [rsp], xmm0
00007d516e5dde15  vmovaps [rsp+0x10], xmm1
00007d516e5dde1b  vmovaps [rsp+0x20], xmm2
00007d516e5dde21  vmovaps [rsp+0x30], xmm3
00007d516e5dde27  vmovaps [rsp+0x40], xmm4
00007d516e5dde2d  vmovaps [rsp+0x50], xmm5
00007d516e5dde33  vmovaps [rsp+0x60], xmm6
00007d516e5dde39  vmovaps [rsp+0x70], xmm7
00007d516e5dde3f  vmovaps [rsp+0x80], xmm8
00007d516e5dde48  vmovaps [rsp+0x90], xmm9
00007d516e5dde51  vmovaps [rsp+0xA0], xmm10
00007d516e5dde5a  vmovaps [rsp+0xB0], xmm11
00007d516e5dde63  vmovaps [rsp+0xC0], xmm13
00007d516e5dde6c  vmovaps [rsp+0xD0], xmm14
00007d516e5dde75  vmovaps [rsp+0xE0], xmm15
00007d516e5dde7e  sub rsp, 0x30
00007d516e5dde82  movaps [rsp], xmm12
00007d516e5dde87  movaps [rsp+0x10], xmm14
00007d516e5dde8d  movaps [rsp+0x20], xmm1
00007d516e5dde92  lea rdi, [rsp]
00007d516e5dde96  mov esi, 0x00
00007d516e5dde9b  mov rax, 0x5EE43AF14530
00007d516e5ddea5  call rax
00007d516e5ddea7  movaps xmm12, [rsp]
00007d516e5ddeac  add rsp, 0x30
00007d516e5ddeb0  vmovaps xmm0, [rsp]
00007d516e5ddeb5  vmovaps xmm1, [rsp+0x10]
00007d516e5ddebb  vmovaps xmm2, [rsp+0x20]
00007d516e5ddec1  vmovaps xmm3, [rsp+0x30]
00007d516e5ddec7  vmovaps xmm4, [rsp+0x40]
00007d516e5ddecd  vmovaps xmm5, [rsp+0x50]
00007d516e5dded3  vmovaps xmm6, [rsp+0x60]
00007d516e5dded9  vmovaps xmm7, [rsp+0x70]
00007d516e5ddedf  vmovaps xmm8, [rsp+0x80]
00007d516e5ddee8  vmovaps xmm9, [rsp+0x90]
00007d516e5ddef1  vmovaps xmm10, [rsp+0xA0]
00007d516e5ddefa  vmovaps xmm11, [rsp+0xB0]
00007d516e5ddf03  vmovaps xmm13, [rsp+0xC0]
00007d516e5ddf0c  vmovaps xmm14, [rsp+0xD0]
00007d516e5ddf15  vmovaps xmm15, [rsp+0xE0]
00007d516e5ddf1e  add rsp, 0xF0
00007d516e5ddf25  pop r11
00007d516e5ddf27  pop r10
00007d516e5ddf29  pop r9
00007d516e5ddf2b  pop r8
00007d516e5ddf2d  pop rsi
00007d516e5ddf2e  pop rdi
00007d516e5ddf2f  pop rdx
00007d516e5ddf30  pop rcx
00007d516e5ddf31  pop rax
00007d516e5ddf32  add rsp, 0x08
00007d516e5ddf36  jmp 0x00007D516E5D9729
00007d516e5ddf3b  sub rsp, 0x08
00007d516e5ddf3f  push rax
00007d516e5ddf40  push rcx
00007d516e5ddf41  push rdx
00007d516e5ddf42  push rdi
00007d516e5ddf43  push rsi
00007d516e5ddf44  push r8
00007d516e5ddf46  push r9
00007d516e5ddf48  push r10
00007d516e5ddf4a  push r11
00007d516e5ddf4c  sub rsp, 0xF0
00007d516e5ddf53  vmovaps [rsp], xmm0
00007d516e5ddf58  vmovaps [rsp+0x10], xmm1
00007d516e5ddf5e  vmovaps [rsp+0x20], xmm2
00007d516e5ddf64  vmovaps [rsp+0x30], xmm3
00007d516e5ddf6a  vmovaps [rsp+0x40], xmm4
00007d516e5ddf70  vmovaps [rsp+0x50], xmm5
00007d516e5ddf76  vmovaps [rsp+0x60], xmm6
00007d516e5ddf7c  vmovaps [rsp+0x70], xmm7
00007d516e5ddf82  vmovaps [rsp+0x80], xmm8
00007d516e5ddf8b  vmovaps [rsp+0x90], xmm9
00007d516e5ddf94  vmovaps [rsp+0xA0], xmm10
00007d516e5ddf9d  vmovaps [rsp+0xB0], xmm11
00007d516e5ddfa6  vmovaps [rsp+0xC0], xmm12
00007d516e5ddfaf  vmovaps [rsp+0xD0], xmm13
00007d516e5ddfb8  vmovaps [rsp+0xE0], xmm15
00007d516e5ddfc1  sub rsp, 0x30
00007d516e5ddfc5  movaps [rsp], xmm14
00007d516e5ddfca  movaps [rsp+0x10], xmm9
00007d516e5ddfd0  movaps [rsp+0x20], xmm1
00007d516e5ddfd5  lea rdi, [rsp]
00007d516e5ddfd9  mov esi, 0x00
00007d516e5ddfde  mov rax, 0x5EE43AF14530
00007d516e5ddfe8  call rax
00007d516e5ddfea  movaps xmm14, [rsp]
00007d516e5ddfef  add rsp, 0x30
00007d516e5ddff3  vmovaps xmm0, [rsp]
00007d516e5ddff8  vmovaps xmm1, [rsp+0x10]
00007d516e5ddffe  vmovaps xmm2, [rsp+0x20]
00007d516e5de004  vmovaps xmm3, [rsp+0x30]
00007d516e5de00a  vmovaps xmm4, [rsp+0x40]
00007d516e5de010  vmovaps xmm5, [rsp+0x50]
00007d516e5de016  vmovaps xmm6, [rsp+0x60]
00007d516e5de01c  vmovaps xmm7, [rsp+0x70]
00007d516e5de022  vmovaps xmm8, [rsp+0x80]
00007d516e5de02b  vmovaps xmm9, [rsp+0x90]
00007d516e5de034  vmovaps xmm10, [rsp+0xA0]
00007d516e5de03d  vmovaps xmm11, [rsp+0xB0]
00007d516e5de046  vmovaps xmm12, [rsp+0xC0]
00007d516e5de04f  vmovaps xmm13, [rsp+0xD0]
00007d516e5de058  vmovaps xmm15, [rsp+0xE0]
00007d516e5de061  add rsp, 0xF0
00007d516e5de068  pop r11
00007d516e5de06a  pop r10
00007d516e5de06c  pop r9
00007d516e5de06e  pop r8
00007d516e5de070  pop rsi
00007d516e5de071  pop rdi
00007d516e5de072  pop rdx
00007d516e5de073  pop rcx
00007d516e5de074  pop rax
00007d516e5de075  add rsp, 0x08
00007d516e5de079  jmp 0x00007D516E5D9758
00007d516e5de07e  sub rsp, 0x08
00007d516e5de082  push rax
00007d516e5de083  push rcx
00007d516e5de084  push rdx
00007d516e5de085  push rdi
00007d516e5de086  push rsi
00007d516e5de087  push r8
00007d516e5de089  push r9
00007d516e5de08b  push r10
00007d516e5de08d  push r11
00007d516e5de08f  sub rsp, 0xF0
00007d516e5de096  vmovaps [rsp], xmm0
00007d516e5de09b  vmovaps [rsp+0x10], xmm2
00007d516e5de0a1  vmovaps [rsp+0x20], xmm3
00007d516e5de0a7  vmovaps [rsp+0x30], xmm4
00007d516e5de0ad  vmovaps [rsp+0x40], xmm5
00007d516e5de0b3  vmovaps [rsp+0x50], xmm6
00007d516e5de0b9  vmovaps [rsp+0x60], xmm7
00007d516e5de0bf  vmovaps [rsp+0x70], xmm8
00007d516e5de0c5  vmovaps [rsp+0x80], xmm9
00007d516e5de0ce  vmovaps [rsp+0x90], xmm10
00007d516e5de0d7  vmovaps [rsp+0xA0], xmm11
00007d516e5de0e0  vmovaps [rsp+0xB0], xmm12
00007d516e5de0e9  vmovaps [rsp+0xC0], xmm13
00007d516e5de0f2  vmovaps [rsp+0xD0], xmm14
00007d516e5de0fb  vmovaps [rsp+0xE0], xmm15
00007d516e5de104  sub rsp, 0x30
00007d516e5de108  movaps [rsp], xmm1
00007d516e5de10c  movaps [rsp+0x10], xmm13
00007d516e5de112  movaps [rsp+0x20], xmm8
00007d516e5de118  lea rdi, [rsp]
00007d516e5de11c  mov esi, 0x00
00007d516e5de121  mov rax, 0x5EE43AF14530
00007d516e5de12b  call rax
00007d516e5de12d  movaps xmm1, [rsp]
00007d516e5de131  add rsp, 0x30
00007d516e5de135  vmovaps xmm0, [rsp]
00007d516e5de13a  vmovaps xmm2, [rsp+0x10]
00007d516e5de140  vmovaps xmm3, [rsp+0x20]
00007d516e5de146  vmovaps xmm4, [rsp+0x30]
00007d516e5de14c  vmovaps xmm5, [rsp+0x40]
00007d516e5de152  vmovaps xmm6, [rsp+0x50]
00007d516e5de158  vmovaps xmm7, [rsp+0x60]
00007d516e5de15e  vmovaps xmm8, [rsp+0x70]
00007d516e5de164  vmovaps xmm9, [rsp+0x80]
00007d516e5de16d  vmovaps xmm10, [rsp+0x90]
00007d516e5de176  vmovaps xmm11, [rsp+0xA0]
00007d516e5de17f  vmovaps xmm12, [rsp+0xB0]
00007d516e5de188  vmovaps xmm13, [rsp+0xC0]
00007d516e5de191  vmovaps xmm14, [rsp+0xD0]
00007d516e5de19a  vmovaps xmm15, [rsp+0xE0]
00007d516e5de1a3  add rsp, 0xF0
00007d516e5de1aa  pop r11
00007d516e5de1ac  pop r10
00007d516e5de1ae  pop r9
00007d516e5de1b0  pop r8
00007d516e5de1b2  pop rsi
00007d516e5de1b3  pop rdi
00007d516e5de1b4  pop rdx
00007d516e5de1b5  pop rcx
00007d516e5de1b6  pop rax
00007d516e5de1b7  add rsp, 0x08
00007d516e5de1bb  jmp 0x00007D516E5D977A
00007d516e5de1c0  call 0x00007D516E40C260
00007d516e5de1c5  jmp 0x00007D516E5D9788
00007d516e5de1ca  call 0x00007D516E4DE950
00007d516e5de1cf  jmp 0x00007D516E5D9792
00007d516e5de1d4  sub rsp, 0x08
00007d516e5de1d8  push rax
00007d516e5de1d9  push rcx
00007d516e5de1da  push rdx
00007d516e5de1db  push rdi
00007d516e5de1dc  push rsi
00007d516e5de1dd  push r8
00007d516e5de1df  push r9
00007d516e5de1e1  push r10
00007d516e5de1e3  push r11
00007d516e5de1e5  sub rsp, 0xF0
00007d516e5de1ec  vmovaps [rsp], xmm0
00007d516e5de1f1  vmovaps [rsp+0x10], xmm1
00007d516e5de1f7  vmovaps [rsp+0x20], xmm2
00007d516e5de1fd  vmovaps [rsp+0x30], xmm3
00007d516e5de203  vmovaps [rsp+0x40], xmm4
00007d516e5de209  vmovaps [rsp+0x50], xmm5
00007d516e5de20f  vmovaps [rsp+0x60], xmm6
00007d516e5de215  vmovaps [rsp+0x70], xmm7
00007d516e5de21b  vmovaps [rsp+0x80], xmm9
00007d516e5de224  vmovaps [rsp+0x90], xmm10
00007d516e5de22d  vmovaps [rsp+0xA0], xmm11
00007d516e5de236  vmovaps [rsp+0xB0], xmm12
00007d516e5de23f  vmovaps [rsp+0xC0], xmm13
00007d516e5de248  vmovaps [rsp+0xD0], xmm14
00007d516e5de251  vmovaps [rsp+0xE0], xmm15
00007d516e5de25a  sub rsp, 0x30
00007d516e5de25e  movaps [rsp], xmm8
00007d516e5de263  movaps [rsp+0x10], xmm15
00007d516e5de269  movaps [rsp+0x20], xmm7
00007d516e5de26e  lea rdi, [rsp]
00007d516e5de272  mov esi, 0x00
00007d516e5de277  mov rax, 0x5EE43AF14530
00007d516e5de281  call rax
00007d516e5de283  movaps xmm8, [rsp]
00007d516e5de288  add rsp, 0x30
00007d516e5de28c  vmovaps xmm0, [rsp]
00007d516e5de291  vmovaps xmm1, [rsp+0x10]
00007d516e5de297  vmovaps xmm2, [rsp+0x20]
00007d516e5de29d  vmovaps xmm3, [rsp+0x30]
00007d516e5de2a3  vmovaps xmm4, [rsp+0x40]
00007d516e5de2a9  vmovaps xmm5, [rsp+0x50]
00007d516e5de2af  vmovaps xmm6, [rsp+0x60]
00007d516e5de2b5  vmovaps xmm7, [rsp+0x70]
00007d516e5de2bb  vmovaps xmm9, [rsp+0x80]
00007d516e5de2c4  vmovaps xmm10, [rsp+0x90]
00007d516e5de2cd  vmovaps xmm11, [rsp+0xA0]
00007d516e5de2d6  vmovaps xmm12, [rsp+0xB0]
00007d516e5de2df  vmovaps xmm13, [rsp+0xC0]
00007d516e5de2e8  vmovaps xmm14, [rsp+0xD0]
00007d516e5de2f1  vmovaps xmm15, [rsp+0xE0]
00007d516e5de2fa  add rsp, 0xF0
00007d516e5de301  pop r11
00007d516e5de303  pop r10
00007d516e5de305  pop r9
00007d516e5de307  pop r8
00007d516e5de309  pop rsi
00007d516e5de30a  pop rdi
00007d516e5de30b  pop rdx
00007d516e5de30c  pop rcx
00007d516e5de30d  pop rax
00007d516e5de30e  add rsp, 0x08
00007d516e5de312  jmp 0x00007D516E5D97B4
00007d516e5de317  sub rsp, 0x08
00007d516e5de31b  push rax
00007d516e5de31c  push rcx
00007d516e5de31d  push rdx
00007d516e5de31e  push rdi
00007d516e5de31f  push rsi
00007d516e5de320  push r8
00007d516e5de322  push r9
00007d516e5de324  push r10
00007d516e5de326  push r11
00007d516e5de328  sub rsp, 0xF0
00007d516e5de32f  vmovaps [rsp], xmm0
00007d516e5de334  vmovaps [rsp+0x10], xmm1
00007d516e5de33a  vmovaps [rsp+0x20], xmm2
00007d516e5de340  vmovaps [rsp+0x30], xmm3
00007d516e5de346  vmovaps [rsp+0x40], xmm4
00007d516e5de34c  vmovaps [rsp+0x50], xmm5
00007d516e5de352  vmovaps [rsp+0x60], xmm6
00007d516e5de358  vmovaps [rsp+0x70], xmm8
00007d516e5de35e  vmovaps [rsp+0x80], xmm9
00007d516e5de367  vmovaps [rsp+0x90], xmm10
00007d516e5de370  vmovaps [rsp+0xA0], xmm11
00007d516e5de379  vmovaps [rsp+0xB0], xmm12
00007d516e5de382  vmovaps [rsp+0xC0], xmm13
00007d516e5de38b  vmovaps [rsp+0xD0], xmm14
00007d516e5de394  vmovaps [rsp+0xE0], xmm15
00007d516e5de39d  sub rsp, 0x30
00007d516e5de3a1  movaps [rsp], xmm7
00007d516e5de3a5  movaps [rsp+0x10], xmm9
00007d516e5de3ab  movaps [rsp+0x20], xmm15
00007d516e5de3b1  lea rdi, [rsp]
00007d516e5de3b5  mov esi, 0x00
00007d516e5de3ba  mov rax, 0x5EE43AF14530
00007d516e5de3c4  call rax
00007d516e5de3c6  movaps xmm7, [rsp]
00007d516e5de3ca  add rsp, 0x30
00007d516e5de3ce  vmovaps xmm0, [rsp]
00007d516e5de3d3  vmovaps xmm1, [rsp+0x10]
00007d516e5de3d9  vmovaps xmm2, [rsp+0x20]
00007d516e5de3df  vmovaps xmm3, [rsp+0x30]
00007d516e5de3e5  vmovaps xmm4, [rsp+0x40]
00007d516e5de3eb  vmovaps xmm5, [rsp+0x50]
00007d516e5de3f1  vmovaps xmm6, [rsp+0x60]
00007d516e5de3f7  vmovaps xmm8, [rsp+0x70]
00007d516e5de3fd  vmovaps xmm9, [rsp+0x80]
00007d516e5de406  vmovaps xmm10, [rsp+0x90]
00007d516e5de40f  vmovaps xmm11, [rsp+0xA0]
00007d516e5de418  vmovaps xmm12, [rsp+0xB0]
00007d516e5de421  vmovaps xmm13, [rsp+0xC0]
00007d516e5de42a  vmovaps xmm14, [rsp+0xD0]
00007d516e5de433  vmovaps xmm15, [rsp+0xE0]
00007d516e5de43c  add rsp, 0xF0
00007d516e5de443  pop r11
00007d516e5de445  pop r10
00007d516e5de447  pop r9
00007d516e5de449  pop r8
00007d516e5de44b  pop rsi
00007d516e5de44c  pop rdi
00007d516e5de44d  pop rdx
00007d516e5de44e  pop rcx
00007d516e5de44f  pop rax
00007d516e5de450  add rsp, 0x08
00007d516e5de454  jmp 0x00007D516E5D97E1
00007d516e5de459  sub rsp, 0x08
00007d516e5de45d  push rax
00007d516e5de45e  push rcx
00007d516e5de45f  push rdx
00007d516e5de460  push rdi
00007d516e5de461  push rsi
00007d516e5de462  push r8
00007d516e5de464  push r9
00007d516e5de466  push r10
00007d516e5de468  push r11
00007d516e5de46a  sub rsp, 0xF0
00007d516e5de471  vmovaps [rsp], xmm0
00007d516e5de476  vmovaps [rsp+0x10], xmm1
00007d516e5de47c  vmovaps [rsp+0x20], xmm2
00007d516e5de482  vmovaps [rsp+0x30], xmm3
00007d516e5de488  vmovaps [rsp+0x40], xmm4
00007d516e5de48e  vmovaps [rsp+0x50], xmm5
00007d516e5de494  vmovaps [rsp+0x60], xmm6
00007d516e5de49a  vmovaps [rsp+0x70], xmm7
00007d516e5de4a0  vmovaps [rsp+0x80], xmm8
00007d516e5de4a9  vmovaps [rsp+0x90], xmm10
00007d516e5de4b2  vmovaps [rsp+0xA0], xmm11
00007d516e5de4bb  vmovaps [rsp+0xB0], xmm12
00007d516e5de4c4  vmovaps [rsp+0xC0], xmm13
00007d516e5de4cd  vmovaps [rsp+0xD0], xmm14
00007d516e5de4d6  vmovaps [rsp+0xE0], xmm15
00007d516e5de4df  sub rsp, 0x30
00007d516e5de4e3  movaps [rsp], xmm9
00007d516e5de4e8  movaps [rsp+0x10], xmm13
00007d516e5de4ee  movaps [rsp+0x20], xmm15
00007d516e5de4f4  lea rdi, [rsp]
00007d516e5de4f8  mov esi, 0x00
00007d516e5de4fd  mov rax, 0x5EE43AF14530
00007d516e5de507  call rax
00007d516e5de509  movaps xmm9, [rsp]
00007d516e5de50e  add rsp, 0x30
00007d516e5de512  vmovaps xmm0, [rsp]
00007d516e5de517  vmovaps xmm1, [rsp+0x10]
00007d516e5de51d  vmovaps xmm2, [rsp+0x20]
00007d516e5de523  vmovaps xmm3, [rsp+0x30]
00007d516e5de529  vmovaps xmm4, [rsp+0x40]
00007d516e5de52f  vmovaps xmm5, [rsp+0x50]
00007d516e5de535  vmovaps xmm6, [rsp+0x60]
00007d516e5de53b  vmovaps xmm7, [rsp+0x70]
00007d516e5de541  vmovaps xmm8, [rsp+0x80]
00007d516e5de54a  vmovaps xmm10, [rsp+0x90]
00007d516e5de553  vmovaps xmm11, [rsp+0xA0]
00007d516e5de55c  vmovaps xmm12, [rsp+0xB0]
00007d516e5de565  vmovaps xmm13, [rsp+0xC0]
00007d516e5de56e  vmovaps xmm14, [rsp+0xD0]
00007d516e5de577  vmovaps xmm15, [rsp+0xE0]
00007d516e5de580  add rsp, 0xF0
00007d516e5de587  pop r11
00007d516e5de589  pop r10
00007d516e5de58b  pop r9
00007d516e5de58d  pop r8
00007d516e5de58f  pop rsi
00007d516e5de590  pop rdi
00007d516e5de591  pop rdx
00007d516e5de592  pop rcx
00007d516e5de593  pop rax
00007d516e5de594  add rsp, 0x08
00007d516e5de598  jmp 0x00007D516E5D980F
00007d516e5de59d  sub rsp, 0x08
00007d516e5de5a1  push rax
00007d516e5de5a2  push rcx
00007d516e5de5a3  push rdx
00007d516e5de5a4  push rdi
00007d516e5de5a5  push rsi
00007d516e5de5a6  push r8
00007d516e5de5a8  push r9
00007d516e5de5aa  push r10
00007d516e5de5ac  push r11
00007d516e5de5ae  sub rsp, 0xF0
00007d516e5de5b5  vmovaps [rsp], xmm0
00007d516e5de5ba  vmovaps [rsp+0x10], xmm1
00007d516e5de5c0  vmovaps [rsp+0x20], xmm2
00007d516e5de5c6  vmovaps [rsp+0x30], xmm3
00007d516e5de5cc  vmovaps [rsp+0x40], xmm4
00007d516e5de5d2  vmovaps [rsp+0x50], xmm5
00007d516e5de5d8  vmovaps [rsp+0x60], xmm6
00007d516e5de5de  vmovaps [rsp+0x70], xmm7
00007d516e5de5e4  vmovaps [rsp+0x80], xmm8
00007d516e5de5ed  vmovaps [rsp+0x90], xmm9
00007d516e5de5f6  vmovaps [rsp+0xA0], xmm10
00007d516e5de5ff  vmovaps [rsp+0xB0], xmm11
00007d516e5de608  vmovaps [rsp+0xC0], xmm12
00007d516e5de611  vmovaps [rsp+0xD0], xmm13
00007d516e5de61a  vmovaps [rsp+0xE0], xmm14
00007d516e5de623  sub rsp, 0x30
00007d516e5de627  movaps [rsp], xmm15
00007d516e5de62c  movaps [rsp+0x10], xmm11
00007d516e5de632  movaps [rsp+0x20], xmm12
00007d516e5de638  lea rdi, [rsp]
00007d516e5de63c  mov esi, 0x00
00007d516e5de641  mov rax, 0x5EE43AF14530
00007d516e5de64b  call rax
00007d516e5de64d  movaps xmm15, [rsp]
00007d516e5de652  add rsp, 0x30
00007d516e5de656  vmovaps xmm0, [rsp]
00007d516e5de65b  vmovaps xmm1, [rsp+0x10]
00007d516e5de661  vmovaps xmm2, [rsp+0x20]
00007d516e5de667  vmovaps xmm3, [rsp+0x30]
00007d516e5de66d  vmovaps xmm4, [rsp+0x40]
00007d516e5de673  vmovaps xmm5, [rsp+0x50]
00007d516e5de679  vmovaps xmm6, [rsp+0x60]
00007d516e5de67f  vmovaps xmm7, [rsp+0x70]
00007d516e5de685  vmovaps xmm8, [rsp+0x80]
00007d516e5de68e  vmovaps xmm9, [rsp+0x90]
00007d516e5de697  vmovaps xmm10, [rsp+0xA0]
00007d516e5de6a0  vmovaps xmm11, [rsp+0xB0]
00007d516e5de6a9  vmovaps xmm12, [rsp+0xC0]
00007d516e5de6b2  vmovaps xmm13, [rsp+0xD0]
00007d516e5de6bb  vmovaps xmm14, [rsp+0xE0]
00007d516e5de6c4  add rsp, 0xF0
00007d516e5de6cb  pop r11
00007d516e5de6cd  pop r10
00007d516e5de6cf  pop r9
00007d516e5de6d1  pop r8
00007d516e5de6d3  pop rsi
00007d516e5de6d4  pop rdi
00007d516e5de6d5  pop rdx
00007d516e5de6d6  pop rcx
00007d516e5de6d7  pop rax
00007d516e5de6d8  add rsp, 0x08
00007d516e5de6dc  jmp 0x00007D516E5D982A
00007d516e5de6e1  sub rsp, 0x08
00007d516e5de6e5  push rax
00007d516e5de6e6  push rcx
00007d516e5de6e7  push rdx
00007d516e5de6e8  push rdi
00007d516e5de6e9  push rsi
00007d516e5de6ea  push r8
00007d516e5de6ec  push r9
00007d516e5de6ee  push r10
00007d516e5de6f0  push r11
00007d516e5de6f2  sub rsp, 0xF0
00007d516e5de6f9  vmovaps [rsp], xmm0
00007d516e5de6fe  vmovaps [rsp+0x10], xmm1
00007d516e5de704  vmovaps [rsp+0x20], xmm2
00007d516e5de70a  vmovaps [rsp+0x30], xmm3
00007d516e5de710  vmovaps [rsp+0x40], xmm4
00007d516e5de716  vmovaps [rsp+0x50], xmm5
00007d516e5de71c  vmovaps [rsp+0x60], xmm6
00007d516e5de722  vmovaps [rsp+0x70], xmm7
00007d516e5de728  vmovaps [rsp+0x80], xmm8
00007d516e5de731  vmovaps [rsp+0x90], xmm9
00007d516e5de73a  vmovaps [rsp+0xA0], xmm10
00007d516e5de743  vmovaps [rsp+0xB0], xmm11
00007d516e5de74c  vmovaps [rsp+0xC0], xmm12
00007d516e5de755  vmovaps [rsp+0xD0], xmm14
00007d516e5de75e  vmovaps [rsp+0xE0], xmm15
00007d516e5de767  sub rsp, 0x30
00007d516e5de76b  movaps [rsp], xmm13
00007d516e5de770  movaps [rsp+0x10], xmm10
00007d516e5de776  movaps [rsp+0x20], xmm14
00007d516e5de77c  lea rdi, [rsp]
00007d516e5de780  mov esi, 0x00
00007d516e5de785  mov rax, 0x5EE43AF14530
00007d516e5de78f  call rax
00007d516e5de791  movaps xmm13, [rsp]
00007d516e5de796  add rsp, 0x30
00007d516e5de79a  vmovaps xmm0, [rsp]
00007d516e5de79f  vmovaps xmm1, [rsp+0x10]
00007d516e5de7a5  vmovaps xmm2, [rsp+0x20]
00007d516e5de7ab  vmovaps xmm3, [rsp+0x30]
00007d516e5de7b1  vmovaps xmm4, [rsp+0x40]
00007d516e5de7b7  vmovaps xmm5, [rsp+0x50]
00007d516e5de7bd  vmovaps xmm6, [rsp+0x60]
00007d516e5de7c3  vmovaps xmm7, [rsp+0x70]
00007d516e5de7c9  vmovaps xmm8, [rsp+0x80]
00007d516e5de7d2  vmovaps xmm9, [rsp+0x90]
00007d516e5de7db  vmovaps xmm10, [rsp+0xA0]
00007d516e5de7e4  vmovaps xmm11, [rsp+0xB0]
00007d516e5de7ed  vmovaps xmm12, [rsp+0xC0]
00007d516e5de7f6  vmovaps xmm14, [rsp+0xD0]
00007d516e5de7ff  vmovaps xmm15, [rsp+0xE0]
00007d516e5de808  add rsp, 0xF0
00007d516e5de80f  pop r11
00007d516e5de811  pop r10
00007d516e5de813  pop r9
00007d516e5de815  pop r8
00007d516e5de817  pop rsi
00007d516e5de818  pop rdi
00007d516e5de819  pop rdx
00007d516e5de81a  pop rcx
00007d516e5de81b  pop rax
00007d516e5de81c  add rsp, 0x08
00007d516e5de820  jmp 0x00007D516E5D984D
00007d516e5de825  sub rsp, 0x08
00007d516e5de829  push rax
00007d516e5de82a  push rcx
00007d516e5de82b  push rdx
00007d516e5de82c  push rdi
00007d516e5de82d  push rsi
00007d516e5de82e  push r8
00007d516e5de830  push r9
00007d516e5de832  push r10
00007d516e5de834  push r11
00007d516e5de836  sub rsp, 0xF0
00007d516e5de83d  vmovaps [rsp], xmm0
00007d516e5de842  vmovaps [rsp+0x10], xmm1
00007d516e5de848  vmovaps [rsp+0x20], xmm2
00007d516e5de84e  vmovaps [rsp+0x30], xmm3
00007d516e5de854  vmovaps [rsp+0x40], xmm4
00007d516e5de85a  vmovaps [rsp+0x50], xmm5
00007d516e5de860  vmovaps [rsp+0x60], xmm6
00007d516e5de866  vmovaps [rsp+0x70], xmm7
00007d516e5de86c  vmovaps [rsp+0x80], xmm8
00007d516e5de875  vmovaps [rsp+0x90], xmm9
00007d516e5de87e  vmovaps [rsp+0xA0], xmm10
00007d516e5de887  vmovaps [rsp+0xB0], xmm11
00007d516e5de890  vmovaps [rsp+0xC0], xmm12
00007d516e5de899  vmovaps [rsp+0xD0], xmm13
00007d516e5de8a2  vmovaps [rsp+0xE0], xmm15
00007d516e5de8ab  sub rsp, 0x30
00007d516e5de8af  movaps [rsp], xmm14
00007d516e5de8b4  movaps [rsp+0x10], xmm1
00007d516e5de8b9  movaps [rsp+0x20], xmm7
00007d516e5de8be  lea rdi, [rsp]
00007d516e5de8c2  mov esi, 0x00
00007d516e5de8c7  mov rax, 0x5EE43AF14530
00007d516e5de8d1  call rax
00007d516e5de8d3  movaps xmm14, [rsp]
00007d516e5de8d8  add rsp, 0x30
00007d516e5de8dc  vmovaps xmm0, [rsp]
00007d516e5de8e1  vmovaps xmm1, [rsp+0x10]
00007d516e5de8e7  vmovaps xmm2, [rsp+0x20]
00007d516e5de8ed  vmovaps xmm3, [rsp+0x30]
00007d516e5de8f3  vmovaps xmm4, [rsp+0x40]
00007d516e5de8f9  vmovaps xmm5, [rsp+0x50]
00007d516e5de8ff  vmovaps xmm6, [rsp+0x60]
00007d516e5de905  vmovaps xmm7, [rsp+0x70]
00007d516e5de90b  vmovaps xmm8, [rsp+0x80]
00007d516e5de914  vmovaps xmm9, [rsp+0x90]
00007d516e5de91d  vmovaps xmm10, [rsp+0xA0]
00007d516e5de926  vmovaps xmm11, [rsp+0xB0]
00007d516e5de92f  vmovaps xmm12, [rsp+0xC0]
00007d516e5de938  vmovaps xmm13, [rsp+0xD0]
00007d516e5de941  vmovaps xmm15, [rsp+0xE0]
00007d516e5de94a  add rsp, 0xF0
00007d516e5de951  pop r11
00007d516e5de953  pop r10
00007d516e5de955  pop r9
00007d516e5de957  pop r8
00007d516e5de959  pop rsi
00007d516e5de95a  pop rdi
00007d516e5de95b  pop rdx
00007d516e5de95c  pop rcx
00007d516e5de95d  pop rax
00007d516e5de95e  add rsp, 0x08
00007d516e5de962  jmp 0x00007D516E5D9870
00007d516e5de967  sub rsp, 0x08
00007d516e5de96b  push rax
00007d516e5de96c  push rcx
00007d516e5de96d  push rdx
00007d516e5de96e  push rdi
00007d516e5de96f  push rsi
00007d516e5de970  push r8
00007d516e5de972  push r9
00007d516e5de974  push r10
00007d516e5de976  push r11
00007d516e5de978  sub rsp, 0xF0
00007d516e5de97f  vmovaps [rsp], xmm0
00007d516e5de984  vmovaps [rsp+0x10], xmm2
00007d516e5de98a  vmovaps [rsp+0x20], xmm3
00007d516e5de990  vmovaps [rsp+0x30], xmm4
00007d516e5de996  vmovaps [rsp+0x40], xmm5
00007d516e5de99c  vmovaps [rsp+0x50], xmm6
00007d516e5de9a2  vmovaps [rsp+0x60], xmm7
00007d516e5de9a8  vmovaps [rsp+0x70], xmm8
00007d516e5de9ae  vmovaps [rsp+0x80], xmm9
00007d516e5de9b7  vmovaps [rsp+0x90], xmm10
00007d516e5de9c0  vmovaps [rsp+0xA0], xmm11
00007d516e5de9c9  vmovaps [rsp+0xB0], xmm12
00007d516e5de9d2  vmovaps [rsp+0xC0], xmm13
00007d516e5de9db  vmovaps [rsp+0xD0], xmm14
00007d516e5de9e4  vmovaps [rsp+0xE0], xmm15
00007d516e5de9ed  sub rsp, 0x30
00007d516e5de9f1  movaps [rsp], xmm1
00007d516e5de9f5  movaps [rsp+0x10], xmm8
00007d516e5de9fb  movaps [rsp+0x20], xmm9
00007d516e5dea01  lea rdi, [rsp]
00007d516e5dea05  mov esi, 0x00
00007d516e5dea0a  mov rax, 0x5EE43AF14530
00007d516e5dea14  call rax
00007d516e5dea16  movaps xmm1, [rsp]
00007d516e5dea1a  add rsp, 0x30
00007d516e5dea1e  vmovaps xmm0, [rsp]
00007d516e5dea23  vmovaps xmm2, [rsp+0x10]
00007d516e5dea29  vmovaps xmm3, [rsp+0x20]
00007d516e5dea2f  vmovaps xmm4, [rsp+0x30]
00007d516e5dea35  vmovaps xmm5, [rsp+0x40]
00007d516e5dea3b  vmovaps xmm6, [rsp+0x50]
00007d516e5dea41  vmovaps xmm7, [rsp+0x60]
00007d516e5dea47  vmovaps xmm8, [rsp+0x70]
00007d516e5dea4d  vmovaps xmm9, [rsp+0x80]
00007d516e5dea56  vmovaps xmm10, [rsp+0x90]
00007d516e5dea5f  vmovaps xmm11, [rsp+0xA0]
00007d516e5dea68  vmovaps xmm12, [rsp+0xB0]
00007d516e5dea71  vmovaps xmm13, [rsp+0xC0]
00007d516e5dea7a  vmovaps xmm14, [rsp+0xD0]
00007d516e5dea83  vmovaps xmm15, [rsp+0xE0]
00007d516e5dea8c  add rsp, 0xF0
00007d516e5dea93  pop r11
00007d516e5dea95  pop r10
00007d516e5dea97  pop r9
00007d516e5dea99  pop r8
00007d516e5dea9b  pop rsi
00007d516e5dea9c  pop rdi
00007d516e5dea9d  pop rdx
00007d516e5dea9e  pop rcx
00007d516e5dea9f  pop rax
00007d516e5deaa0  add rsp, 0x08
00007d516e5deaa4  jmp 0x00007D516E5D9892
00007d516e5deaa9  call 0x00007D516E4B3E40
00007d516e5deaae  jmp 0x00007D516E5D98A0
00007d516e5deab3  call 0x00007D516E40C380
00007d516e5deab8  jmp 0x00007D516E5D98AA
00007d516e5deabd  call 0x00007D516E40D600
00007d516e5deac2  jmp 0x00007D516E5D98B4
00007d516e5deac7  call 0x00007D516E3FF540
00007d516e5deacc  jmp 0x00007D516E5D98BE
00007d516e5dead1  int3
00007d516e5dead2  nop [rax+rax*1], ax
00007d516e5deadb  nop [rax+rax*1], eax
00007d516e5deae0  mov eax, [r15+0x48]
00007d516e5deae4  lea r14d, [eax+0x01]
00007d516e5deae9  mov [rsp+0x10], r14d
00007d516e5deaee  mov r14d, r14d
00007d516e5deaf1  mov [r15+0x48], r14
00007d516e5deaf5  xor eax, eax
00007d516e5deaf7  mov r14d, [rsp+0x10]
00007d516e5deafc  cmp r14d, 0x1F4
00007d516e5deb03  cmc
00007d516e5deb04  lahf
00007d516e5deb05  seto al
00007d516e5deb08  mov [r15+0x108], eax
00007d516e5deb0f  mov eax, [r15+0x108]
00007d516e5deb16  sahf
00007d516e5deb17  jnz 0x00007D516E5DEB49
00007d516e5deb19  cmp dword ptr [r15+0x318], 0x00
00007d516e5deb21  jz 0x00007D516E5E4C90
00007d516e5deb27  nop [rax+rax*1], ax
00007d516e5deb30  nop [rax+rax*1], eax
00007d516e5deb38  mov eax, 0x4106DC
00007d516e5deb3d  mov [r15+0x100], rax
00007d516e5deb44  jmp 0x00007D516E3FE110
00007d516e5deb49  cmp dword ptr [r15+0x318], 0x00
00007d516e5deb51  jz 0x00007D516E5DEB80
00007d516e5deb57  nop [rax+rax*1], ax
00007d516e5deb60  nop [rax+rax*1], eax
00007d516e5deb68  mov eax, 0x410500
00007d516e5deb6d  mov [r15+0x100], rax
00007d516e5deb74  jmp 0x00007D516E3FE110
00007d516e5deb79  int3
00007d516e5deb7a  int3
00007d516e5deb7b  nop [rax+rax*1], eax
00007d516e5deb80  mov rax, [r15+0x40]
00007d516e5deb84  movaps xmm1, [r15+0x1D0]
00007d516e5deb8c  vmovaps [rsp+0x10], xmm1
00007d516e5deb92  vmovaps xmm15, [rsp+0x10]
00007d516e5deb98  por xmm1, xmm15
00007d516e5deb9d  movaps xmm14, [r15+0x1A0]
00007d516e5deba5  vmovaps [rsp+0x10], xmm14
00007d516e5debab  vmovaps xmm13, [rsp+0x10]
00007d516e5debb1  por xmm14, xmm13
00007d516e5debb6  lea r14, [rax+0x30]
00007d516e5debba  mov r12, [r13+r14*1]
00007d516e5debbf  lea r14, [rax+0x38]
00007d516e5debc3  mov r11, [r13+r14*1]
00007d516e5debc8  movq xmm13, r12
00007d516e5debcd  movq xmm12, r11
00007d516e5debd2  movq xmm13, xmm13
00007d516e5debd7  vmovaps [rsp+0x10], xmm13
00007d516e5debdd  movq xmm13, xmm13
00007d516e5debe2  movaps [r15+0x130], xmm13
00007d516e5debea  movq xmm12, xmm12
00007d516e5debef  vmovaps [rsp+0x20], xmm12
00007d516e5debf5  movq xmm12, xmm12
00007d516e5debfa  movaps [r15+0x280], xmm12
00007d516e5dec02  movaps xmm13, [r15+0x270]
00007d516e5dec0a  vmovaps [rsp+0x30], xmm13
00007d516e5dec10  vmovaps xmm12, [rsp+0x30]
00007d516e5dec16  por xmm13, xmm12
00007d516e5dec1b  lea r14, [rax+0x20]
00007d516e5dec1f  mov r12, [r13+r14*1]
00007d516e5dec24  lea r14, [rax+0x28]
00007d516e5dec28  mov r11, [r13+r14*1]
00007d516e5dec2d  movq xmm12, r12
00007d516e5dec32  movq xmm11, r11
00007d516e5dec37  movq xmm12, xmm12
00007d516e5dec3c  vmovaps [rsp+0x30], xmm12
00007d516e5dec42  movq xmm12, xmm12
00007d516e5dec47  movaps [r15+0x150], xmm12
00007d516e5dec4f  movq xmm11, xmm11
00007d516e5dec54  vmovaps [rsp+0x40], xmm11
00007d516e5dec5a  movq xmm11, xmm11
00007d516e5dec5f  movaps [r15+0x140], xmm11
00007d516e5dec67  lea r14, [rax+0x10]
00007d516e5dec6b  mov r12, [r13+r14*1]
00007d516e5dec70  lea r14, [rax+0x18]
00007d516e5dec74  mov r11, [r13+r14*1]
00007d516e5dec79  movq xmm12, r12
00007d516e5dec7e  movq xmm11, r11
00007d516e5dec83  movq xmm12, xmm12
00007d516e5dec88  vmovaps [rsp+0x50], xmm12
00007d516e5dec8e  movq xmm12, xmm12
00007d516e5dec93  movaps [r15+0x170], xmm12
00007d516e5dec9b  movq xmm11, xmm11
00007d516e5deca0  vmovaps [rsp+0x60], xmm11
00007d516e5deca6  movq xmm11, xmm11
00007d516e5decab  movaps [r15+0x160], xmm11
00007d516e5decb3  mov r14, [r13+rax*1]
00007d516e5decb8  vmovq xmm12, r14
00007d516e5decbd  vpbroadcastq xmm12, xmm12
00007d516e5decc2  lea r14, [rax+0x08]
00007d516e5decc6  mov rax, [r13+r14*1]
00007d516e5deccb  movq xmm11, rax
00007d516e5decd0  movaps [r15+0x230], xmm11
00007d516e5decd8  mov rax, [r15+0xF8]
00007d516e5decdf  lea r14, [rax+0x50]
00007d516e5dece3  movups xmm11, [r13+r14*1]
00007d516e5dece9  lea r14, [rax+0x60]
00007d516e5deced  movups xmm10, [r13+r14*1]
00007d516e5decf3  lea r14, [rax+0x30]
00007d516e5decf7  movups xmm9, [r13+r14*1]
00007d516e5decfd  mov r14, [r15+0x50]
00007d516e5ded01  mov [r15+0x60], r14
00007d516e5ded05  mov qword ptr [r15+0x58], 0x40
00007d516e5ded0d  movaps xmm8, xmm12
00007d516e5ded11  mulpd xmm8, xmm15
00007d516e5ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007d516e5ded1c  ptest xmm7, xmm7
00007d516e5ded21  jnz 0x00007D516E5DFB4A
00007d516e5ded27  movq xmm15, qword ptr [r15+0x230]
00007d516e5ded30  vmovaps [rsp+0x70], xmm15
00007d516e5ded36  vpermilpd xmm15, xmm15, 0x00
00007d516e5ded3c  movaps xmm7, xmm9
00007d516e5ded40  mulpd xmm7, xmm15
00007d516e5ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007d516e5ded4a  ptest xmm6, xmm6
00007d516e5ded4f  jnz 0x00007D516E5DFC8E
00007d516e5ded55  vxorps xmm15, xmm15, xmm15
00007d516e5ded5a  vpbroadcastq xmm15, xmm15
00007d516e5ded5f  movaps xmm9, xmm12
00007d516e5ded63  mulpd xmm9, xmm10
00007d516e5ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007d516e5ded6e  ptest xmm6, xmm6
00007d516e5ded73  jnz 0x00007D516E5DFDD0
00007d516e5ded79  movaps xmm10, xmm12
00007d516e5ded7d  mulpd xmm10, xmm11
00007d516e5ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007d516e5ded88  ptest xmm6, xmm6
00007d516e5ded8d  jnz 0x00007D516E5DFF14
00007d516e5ded93  movaps xmm11, [r15+0x1F0]
00007d516e5ded9b  movaps xmm6, xmm12
00007d516e5ded9f  mulpd xmm6, xmm11
00007d516e5deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d516e5deda9  ptest xmm5, xmm5
00007d516e5dedae  jnz 0x00007D516E5E0058
00007d516e5dedb4  movaps xmm12, [r15+0x2A0]
00007d516e5dedbc  vmovaps [rsp+0x80], xmm12
00007d516e5dedc5  vmovaps xmm11, [rsp+0x80]
00007d516e5dedce  por xmm12, xmm11
00007d516e5dedd3  movaps xmm11, [r15+0x250]
00007d516e5deddb  vmovaps [rsp+0x80], xmm11
00007d516e5dede4  vmovaps xmm5, [rsp+0x80]
00007d516e5deded  por xmm11, xmm5
00007d516e5dedf2  vmovaps xmm4, [rsp+0x70]
00007d516e5dedf8  vpermilpd xmm4, xmm4, 0x00
00007d516e5dedfe  movaps xmm3, xmm5
00007d516e5dee01  mulpd xmm3, xmm4
00007d516e5dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007d516e5dee0a  ptest xmm2, xmm2
00007d516e5dee0f  jnz 0x00007D516E5E019A
00007d516e5dee15  mov [rsp+0x80], rax
00007d516e5dee1d  xor eax, eax
00007d516e5dee1f  mov r12d, 0x40
00007d516e5dee25  mov r11d, 0x200
00007d516e5dee2b  cmp r12, r11
00007d516e5dee2e  cmc
00007d516e5dee2f  lahf
00007d516e5dee30  seto al
00007d516e5dee33  mov [r15+0x108], eax
00007d516e5dee3a  movaps xmm5, xmm8
00007d516e5dee3e  addpd xmm5, xmm15
00007d516e5dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007d516e5dee48  ptest xmm4, xmm4
00007d516e5dee4d  jnz 0x00007D516E5E02DA
00007d516e5dee53  movaps xmm8, [r15+0x1B0]
00007d516e5dee5b  movaps xmm4, xmm9
00007d516e5dee5f  addpd xmm4, xmm8
00007d516e5dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007d516e5dee69  ptest xmm2, xmm2
00007d516e5dee6e  jnz 0x00007D516E5E041C
00007d516e5dee74  movaps xmm9, xmm10
00007d516e5dee78  addpd xmm9, xmm8
00007d516e5dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d516e5dee83  ptest xmm2, xmm2
00007d516e5dee88  jnz 0x00007D516E5E055E
00007d516e5dee8e  movaps xmm10, [r15+0x2F0]
00007d516e5dee96  vmovaps [rsp+0x90], xmm10
00007d516e5dee9f  vmovaps xmm8, [rsp+0x90]
00007d516e5deea8  por xmm10, xmm8
00007d516e5deead  movaps xmm8, [r15+0x2E0]
00007d516e5deeb5  vmovaps [rsp+0x90], xmm8
00007d516e5deebe  vmovaps xmm2, [rsp+0x90]
00007d516e5deec7  por xmm8, xmm2
00007d516e5deecc  movaps xmm2, [r15+0x2D0]
00007d516e5deed4  vmovaps [rsp+0x90], xmm2
00007d516e5deedd  vmovaps [rsp+0xA0], xmm1
00007d516e5deee6  vmovaps xmm1, [rsp+0x90]
00007d516e5deeef  por xmm2, xmm1
00007d516e5deef3  movaps xmm1, [r15+0x200]
00007d516e5deefb  vmovaps [rsp+0x90], xmm1
00007d516e5def04  vmovaps [rsp+0xB0], xmm15
00007d516e5def0d  vmovaps xmm15, [rsp+0x90]
00007d516e5def16  por xmm1, xmm15
00007d516e5def1b  movaps xmm15, [r15+0x1C0]
00007d516e5def23  vmovaps [rsp+0x90], xmm15
00007d516e5def2c  vmovaps [rsp+0xC0], xmm1
00007d516e5def35  vmovaps xmm1, [rsp+0x90]
00007d516e5def3e  por xmm15, xmm1
00007d516e5def43  movaps xmm1, [r15+0x190]
00007d516e5def4b  vmovaps [rsp+0x90], xmm1
00007d516e5def54  vmovaps [rsp+0xD0], xmm15
00007d516e5def5d  vmovaps xmm15, [rsp+0x90]
00007d516e5def66  por xmm1, xmm15
00007d516e5def6b  movaps xmm15, [r15+0x300]
00007d516e5def73  vmovaps [rsp+0x90], xmm15
00007d516e5def7c  vmovaps [rsp+0xE0], xmm1
00007d516e5def85  vmovaps xmm1, [rsp+0x90]
00007d516e5def8e  por xmm15, xmm1
00007d516e5def93  mov rax, [rsp+0x80]
00007d516e5def9b  lea r12, [rax+0xA0]
00007d516e5defa2  movups xmm1, [r13+r12*1]
00007d516e5defa8  lea r12, [rax+0xB0]
00007d516e5defaf  vmovaps [rsp+0x80], xmm1
00007d516e5defb8  movups xmm1, [r13+r12*1]
00007d516e5defbe  vmovaps [rsp+0x90], xmm1
00007d516e5defc7  vmovaps [rsp+0xF0], xmm15
00007d516e5defd0  vmovaps xmm15, [rsp+0xB0]
00007d516e5defd9  vmovaps [rsp+0xB0], xmm14
00007d516e5defe2  movaps xmm1, xmm6
00007d516e5defe5  addpd xmm1, xmm15
00007d516e5defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007d516e5defef  ptest xmm14, xmm14
00007d516e5deff5  jnz 0x00007D516E5E06B6
00007d516e5deffb  lea r12, [rax+0xF0]
00007d516e5df002  movups xmm15, [r13+r12*1]
00007d516e5df008  movaps xmm14, xmm4
00007d516e5df00c  addpd xmm14, xmm3
00007d516e5df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007d516e5df017  ptest xmm6, xmm6
00007d516e5df01c  jnz 0x00007D516E5E0801
00007d516e5df022  movaps xmm6, xmm9
00007d516e5df026  addpd xmm6, xmm7
00007d516e5df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d516e5df02f  ptest xmm4, xmm4
00007d516e5df034  jnz 0x00007D516E5E0943
00007d516e5df03a  vmovaps xmm9, [rsp+0x70]
00007d516e5df040  vpermilpd xmm9, xmm9, 0x00
00007d516e5df046  vmovaps xmm4, [rsp+0x90]
00007d516e5df04f  movaps xmm7, xmm4
00007d516e5df052  mulpd xmm7, xmm9
00007d516e5df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007d516e5df05c  ptest xmm3, xmm3
00007d516e5df061  jnz 0x00007D516E5E0A84
00007d516e5df067  vmovaps xmm9, [rsp+0x50]
00007d516e5df06d  vpermilpd xmm9, xmm9, 0x00
00007d516e5df073  movaps xmm4, xmm15
00007d516e5df077  mulpd xmm4, xmm9
00007d516e5df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d516e5df081  ptest xmm3, xmm3
00007d516e5df086  jnz 0x00007D516E5E0BC5
00007d516e5df08c  lea r12, [rax+0xE0]
00007d516e5df093  movups xmm15, [r13+r12*1]
00007d516e5df099  vmovaps xmm9, [rsp+0x70]
00007d516e5df09f  vpermilpd xmm9, xmm9, 0x00
00007d516e5df0a5  vmovaps [rsp+0x70], xmm1
00007d516e5df0ab  vmovaps xmm1, [rsp+0x80]
00007d516e5df0b4  vmovaps [rsp+0x80], xmm15
00007d516e5df0bd  movaps xmm3, xmm1
00007d516e5df0c0  mulpd xmm3, xmm9
00007d516e5df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d516e5df0ca  ptest xmm15, xmm15
00007d516e5df0d0  jnz 0x00007D516E5E0D11
00007d516e5df0d6  vmovaps xmm1, [rsp+0xF0]
00007d516e5df0df  vmovaps xmm15, [rsp+0xF0]
00007d516e5df0e8  por xmm1, xmm15
00007d516e5df0ed  movaps [r15+0x300], xmm1
00007d516e5df0f5  vmovaps xmm15, [rsp+0xE0]
00007d516e5df0fe  vmovaps xmm9, [rsp+0xE0]
00007d516e5df107  por xmm15, xmm9
00007d516e5df10c  movaps [r15+0x190], xmm15
00007d516e5df114  vmovaps xmm9, [rsp+0x50]
00007d516e5df11a  vpermilpd xmm9, xmm9, 0x00
00007d516e5df120  vmovaps [rsp+0x90], xmm1
00007d516e5df129  vmovaps [rsp+0xE0], xmm15
00007d516e5df132  vmovaps xmm15, [rsp+0x80]
00007d516e5df13b  vmovaps [rsp+0x80], xmm14
00007d516e5df144  movaps xmm1, xmm15
00007d516e5df148  mulpd xmm1, xmm9
00007d516e5df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d516e5df152  ptest xmm14, xmm14
00007d516e5df158  jnz 0x00007D516E5E0E52
00007d516e5df15e  lea r12, [rax+0x90]
00007d516e5df165  movups xmm15, [r13+r12*1]
00007d516e5df16b  vmovaps xmm14, [rsp+0xD0]
00007d516e5df174  vmovaps xmm9, [rsp+0xD0]
00007d516e5df17d  por xmm14, xmm9
00007d516e5df182  movaps [r15+0x1C0], xmm14
00007d516e5df18a  vmovaps xmm9, [rsp+0xC0]
00007d516e5df193  vmovaps [rsp+0xD0], xmm1
00007d516e5df19c  vmovaps xmm1, [rsp+0xC0]
00007d516e5df1a5  por xmm9, xmm1
00007d516e5df1aa  movaps [r15+0x200], xmm9
00007d516e5df1b2  vmovaps [rsp+0xC0], xmm2
00007d516e5df1bb  vmovaps xmm1, [rsp+0xC0]
00007d516e5df1c4  por xmm2, xmm1
00007d516e5df1c8  movaps [r15+0x2D0], xmm2
00007d516e5df1d0  vmovaps [rsp+0xC0], xmm8
00007d516e5df1d9  vmovaps xmm1, [rsp+0xC0]
00007d516e5df1e2  por xmm8, xmm1
00007d516e5df1e7  movaps [r15+0x2E0], xmm8
00007d516e5df1ef  vmovaps [rsp+0xC0], xmm15
00007d516e5df1f8  movaps xmm1, xmm5
00007d516e5df1fb  addpd xmm1, xmm7
00007d516e5df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007d516e5df204  ptest xmm15, xmm15
00007d516e5df20a  jnz 0x00007D516E5E0F9E
00007d516e5df210  vmovaps xmm15, [rsp+0x50]
00007d516e5df216  vpermilpd xmm15, xmm15, 0x00
00007d516e5df21c  vmovaps xmm5, [rsp+0xC0]
00007d516e5df225  vmovaps [rsp+0xC0], xmm1
00007d516e5df22e  movaps xmm7, xmm5
00007d516e5df231  mulpd xmm7, xmm15
00007d516e5df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007d516e5df23b  ptest xmm1, xmm1
00007d516e5df240  jnz 0x00007D516E5E10DE
00007d516e5df246  lea r12, [rax+0x80]
00007d516e5df24d  movups xmm1, [r13+r12*1]
00007d516e5df253  vmovaps xmm5, [rsp+0x70]
00007d516e5df259  vmovaps [rsp+0x70], xmm1
00007d516e5df25f  movaps xmm15, xmm5
00007d516e5df263  addpd xmm15, xmm3
00007d516e5df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007d516e5df26e  ptest xmm1, xmm1
00007d516e5df273  jnz 0x00007D516E5E1229
00007d516e5df279  vmovaps xmm5, [rsp+0x80]
00007d516e5df282  movaps xmm1, xmm5
00007d516e5df285  addpd xmm1, xmm4
00007d516e5df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007d516e5df28e  ptest xmm3, xmm3
00007d516e5df293  jnz 0x00007D516E5E136B
00007d516e5df299  vmovaps [rsp+0x80], xmm10
00007d516e5df2a2  vmovaps xmm5, [rsp+0x80]
00007d516e5df2ab  por xmm10, xmm5
00007d516e5df2b0  movaps [r15+0x2F0], xmm10
00007d516e5df2b8  vmovaps xmm5, [rsp+0x50]
00007d516e5df2be  vpermilpd xmm5, xmm5, 0x00
00007d516e5df2c4  vmovaps xmm3, [rsp+0x70]
00007d516e5df2ca  vmovaps [rsp+0x50], xmm1
00007d516e5df2d0  movaps xmm4, xmm3
00007d516e5df2d3  mulpd xmm4, xmm5
00007d516e5df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d516e5df2dc  ptest xmm1, xmm1
00007d516e5df2e1  jnz 0x00007D516E5E14AB
00007d516e5df2e7  lea r12, [rax+0xD0]
00007d516e5df2ee  movups xmm1, [r13+r12*1]
00007d516e5df2f4  vmovaps xmm3, [rsp+0xD0]
00007d516e5df2fd  vmovaps [rsp+0x70], xmm1
00007d516e5df303  movaps xmm5, xmm6
00007d516e5df306  addpd xmm5, xmm3
00007d516e5df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d516e5df30f  ptest xmm1, xmm1
00007d516e5df314  jnz 0x00007D516E5E15F5
00007d516e5df31a  vmovaps xmm1, [rsp+0x60]
00007d516e5df320  vpermilpd xmm1, xmm1, 0x00
00007d516e5df326  movaps xmm6, xmm9
00007d516e5df32a  mulpd xmm6, xmm1
00007d516e5df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d516e5df333  ptest xmm3, xmm3
00007d516e5df338  jnz 0x00007D516E5E1735
00007d516e5df33e  movaps [r15+0x260], xmm6
00007d516e5df346  vxorps xmm1, xmm1, xmm1
00007d516e5df34a  vpbroadcastq xmm1, xmm1
00007d516e5df34f  movaps [r15+0x1B0], xmm1
00007d516e5df357  vmovaps xmm1, [rsp+0x60]
00007d516e5df35d  vpermilpd xmm1, xmm1, 0x00
00007d516e5df363  vmovaps xmm3, [rsp+0x70]
00007d516e5df369  vmovaps [rsp+0x70], xmm15
00007d516e5df36f  movaps xmm9, xmm3
00007d516e5df373  mulpd xmm9, xmm1
00007d516e5df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007d516e5df37e  ptest xmm15, xmm15
00007d516e5df384  jnz 0x00007D516E5E1876
00007d516e5df38a  lea r12, [rax+0xC0]
00007d516e5df391  movups xmm1, [r13+r12*1]
00007d516e5df397  vmovaps xmm3, [rsp+0xC0]
00007d516e5df3a0  vmovaps [rsp+0x80], xmm1
00007d516e5df3a9  movaps xmm15, xmm3
00007d516e5df3ad  addpd xmm15, xmm7
00007d516e5df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d516e5df3b8  ptest xmm1, xmm1
00007d516e5df3bd  jnz 0x00007D516E5E19C2
00007d516e5df3c3  vmovaps [rsp+0xC0], xmm13
00007d516e5df3cc  vmovaps xmm1, [rsp+0xC0]
00007d516e5df3d5  por xmm13, xmm1
00007d516e5df3da  movaps [r15+0x270], xmm13
00007d516e5df3e2  vmovaps xmm1, [rsp+0xB0]
00007d516e5df3eb  vmovaps xmm7, [rsp+0xB0]
00007d516e5df3f4  por xmm1, xmm7
00007d516e5df3f8  movaps [r15+0x1A0], xmm1
00007d516e5df400  vmovaps xmm1, [rsp+0x60]
00007d516e5df406  vpermilpd xmm1, xmm1, 0x00
00007d516e5df40c  vmovaps [rsp+0xB0], xmm1
00007d516e5df415  vmovaps xmm1, [rsp+0x80]
00007d516e5df41e  vmovaps [rsp+0x80], xmm15
00007d516e5df427  vmovaps xmm15, [rsp+0xB0]
00007d516e5df430  vmovaps [rsp+0xB0], xmm14
00007d516e5df439  movaps xmm3, xmm1
00007d516e5df43c  mulpd xmm3, xmm15
00007d516e5df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007d516e5df446  ptest xmm14, xmm14
00007d516e5df44c  jnz 0x00007D516E5E1B04
00007d516e5df452  lea r12, [rax+0x20]
00007d516e5df456  movups xmm1, [r13+r12*1]
00007d516e5df45c  movaps [r15+0x110], xmm1
00007d516e5df464  vmovaps xmm14, [rsp+0x70]
00007d516e5df46a  vmovaps [rsp+0x70], xmm1
00007d516e5df470  movaps xmm15, xmm14
00007d516e5df474  addpd xmm15, xmm4
00007d516e5df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007d516e5df47f  ptest xmm1, xmm1
00007d516e5df484  jnz 0x00007D516E5E1C4F
00007d516e5df48a  vmovaps xmm1, [rsp+0x60]
00007d516e5df490  vpermilpd xmm1, xmm1, 0x00
00007d516e5df496  movaps xmm14, xmm2
00007d516e5df49a  mulpd xmm14, xmm1
00007d516e5df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007d516e5df4a5  ptest xmm4, xmm4
00007d516e5df4aa  jnz 0x00007D516E5E1D92
00007d516e5df4b0  vmovaps xmm4, [rsp+0x50]
00007d516e5df4b6  movaps xmm1, xmm4
00007d516e5df4b9  addpd xmm1, xmm9
00007d516e5df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007d516e5df4c3  ptest xmm2, xmm2
00007d516e5df4c8  jnz 0x00007D516E5E1ED4
00007d516e5df4ce  vmovaps xmm9, [rsp+0x30]
00007d516e5df4d4  vpermilpd xmm9, xmm9, 0x00
00007d516e5df4da  vmovaps xmm2, [rsp+0x70]
00007d516e5df4e0  vmovaps [rsp+0x50], xmm1
00007d516e5df4e6  movaps xmm4, xmm2
00007d516e5df4e9  mulpd xmm4, xmm9
00007d516e5df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007d516e5df4f3  ptest xmm1, xmm1
00007d516e5df4f8  jnz 0x00007D516E5E2015
00007d516e5df4fe  vmovaps xmm1, [rsp+0x30]
00007d516e5df504  vpermilpd xmm1, xmm1, 0x00
00007d516e5df50a  vmovaps xmm2, [rsp+0x90]
00007d516e5df513  vmovaps [rsp+0x60], xmm15
00007d516e5df519  movaps xmm9, xmm2
00007d516e5df51d  mulpd xmm9, xmm1
00007d516e5df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007d516e5df528  ptest xmm15, xmm15
00007d516e5df52e  jnz 0x00007D516E5E2156
00007d516e5df534  vmovaps xmm15, [rsp+0x80]
00007d516e5df53d  movaps xmm1, xmm15
00007d516e5df541  addpd xmm1, xmm6
00007d516e5df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007d516e5df54a  ptest xmm2, xmm2
00007d516e5df54f  jnz 0x00007D516E5E2298
00007d516e5df555  movaps xmm15, xmm5
00007d516e5df559  addpd xmm15, xmm3
00007d516e5df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d516e5df564  ptest xmm6, xmm6
00007d516e5df569  jnz 0x00007D516E5E23D9
00007d516e5df56f  vmovaps xmm6, [rsp+0x30]
00007d516e5df575  vpermilpd xmm6, xmm6, 0x00
00007d516e5df57b  movaps xmm5, xmm8
00007d516e5df57f  mulpd xmm5, xmm6
00007d516e5df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007d516e5df588  ptest xmm3, xmm3
00007d516e5df58d  jnz 0x00007D516E5E251B
00007d516e5df593  vmovaps xmm8, [rsp+0x30]
00007d516e5df599  vpermilpd xmm8, xmm8, 0x00
00007d516e5df59f  movaps xmm6, xmm10
00007d516e5df5a3  mulpd xmm6, xmm8
00007d516e5df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d516e5df5ad  ptest xmm3, xmm3
00007d516e5df5b2  jnz 0x00007D516E5E265C
00007d516e5df5b8  vmovaps xmm8, [rsp+0x60]
00007d516e5df5be  movaps xmm10, xmm8
00007d516e5df5c2  addpd xmm10, xmm14
00007d516e5df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d516e5df5cd  ptest xmm3, xmm3
00007d516e5df5d2  jnz 0x00007D516E5E279E
00007d516e5df5d8  vmovaps xmm8, [rsp+0x50]
00007d516e5df5de  movaps xmm14, xmm8
00007d516e5df5e2  addpd xmm14, xmm4
00007d516e5df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007d516e5df5ed  ptest xmm3, xmm3
00007d516e5df5f2  jnz 0x00007D516E5E28E2
00007d516e5df5f8  vmovaps xmm8, [rsp+0x40]
00007d516e5df5fe  vpermilpd xmm8, xmm8, 0x00
00007d516e5df604  movaps xmm4, xmm13
00007d516e5df608  mulpd xmm4, xmm8
00007d516e5df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d516e5df612  ptest xmm3, xmm3
00007d516e5df617  jnz 0x00007D516E5E2A25
00007d516e5df61d  movaps xmm13, xmm15
00007d516e5df621  addpd xmm13, xmm9
00007d516e5df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007d516e5df62c  ptest xmm8, xmm8
00007d516e5df632  jnz 0x00007D516E5E2B67
00007d516e5df638  movaps xmm15, xmm1
00007d516e5df63c  addpd xmm15, xmm5
00007d516e5df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007d516e5df647  ptest xmm9, xmm9
00007d516e5df64d  jnz 0x00007D516E5E2CAB
00007d516e5df653  vmovaps [rsp+0x30], xmm11
00007d516e5df659  vmovaps xmm1, [rsp+0x30]
00007d516e5df65f  por xmm11, xmm1
00007d516e5df664  movaps [r15+0x250], xmm11
00007d516e5df66c  vmovaps [rsp+0x30], xmm12
00007d516e5df672  vmovaps xmm1, [rsp+0x30]
00007d516e5df678  por xmm12, xmm1
00007d516e5df67d  movaps [r15+0x2A0], xmm12
00007d516e5df685  vmovaps xmm1, [rsp+0xA0]
00007d516e5df68e  vmovaps xmm11, [rsp+0xA0]
00007d516e5df697  por xmm1, xmm11
00007d516e5df69c  movaps [r15+0x1D0], xmm1
00007d516e5df6a4  lea r12, [rax+0x40]
00007d516e5df6a8  movups xmm1, [r13+r12*1]
00007d516e5df6ae  movaps [r15+0x2C0], xmm1
00007d516e5df6b6  vmovaps xmm11, [rsp+0x40]
00007d516e5df6bc  vpermilpd xmm11, xmm11, 0x00
00007d516e5df6c2  vmovaps xmm8, [rsp+0xE0]
00007d516e5df6cb  movaps xmm9, xmm8
00007d516e5df6cf  mulpd xmm9, xmm11
00007d516e5df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d516e5df6da  ptest xmm5, xmm5
00007d516e5df6df  jnz 0x00007D516E5E2DF7
00007d516e5df6e5  movaps xmm11, xmm10
00007d516e5df6e9  addpd xmm11, xmm6
00007d516e5df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007d516e5df6f4  ptest xmm8, xmm8
00007d516e5df6fa  jnz 0x00007D516E5E2F3B
00007d516e5df700  movaps xmm10, xmm14
00007d516e5df704  addpd xmm10, xmm4
00007d516e5df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007d516e5df70f  ptest xmm8, xmm8
00007d516e5df715  jnz 0x00007D516E5E307E
00007d516e5df71b  vmovaps xmm14, [rsp+0x40]
00007d516e5df721  vpermilpd xmm14, xmm14, 0x00
00007d516e5df727  movaps xmm8, xmm1
00007d516e5df72b  mulpd xmm8, xmm14
00007d516e5df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007d516e5df736  ptest xmm6, xmm6
00007d516e5df73b  jnz 0x00007D516E5E31C1
00007d516e5df741  movaps xmm1, [r15+0x2B0]
00007d516e5df749  vmovaps xmm14, [rsp+0x40]
00007d516e5df74f  vpermilpd xmm14, xmm14, 0x00
00007d516e5df755  movaps xmm6, xmm1
00007d516e5df758  mulpd xmm6, xmm14
00007d516e5df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d516e5df762  ptest xmm5, xmm5
00007d516e5df767  jnz 0x00007D516E5E3304
00007d516e5df76d  vmovaps xmm1, [rsp+0x10]
00007d516e5df773  vpermilpd xmm1, xmm1, 0x00
00007d516e5df779  movaps xmm14, xmm12
00007d516e5df77d  mulpd xmm14, xmm1
00007d516e5df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007d516e5df788  ptest xmm5, xmm5
00007d516e5df78d  jnz 0x00007D516E5E3445
00007d516e5df793  movaps xmm1, xmm13
00007d516e5df797  addpd xmm1, xmm9
00007d516e5df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007d516e5df7a1  ptest xmm12, xmm12
00007d516e5df7a7  jnz 0x00007D516E5E3588
00007d516e5df7ad  vmovaps xmm13, [rsp+0x10]
00007d516e5df7b3  vpermilpd xmm13, xmm13, 0x00
00007d516e5df7b9  movaps xmm12, xmm7
00007d516e5df7bd  mulpd xmm12, xmm13
00007d516e5df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d516e5df7c8  ptest xmm9, xmm9
00007d516e5df7ce  jnz 0x00007D516E5E36CA
00007d516e5df7d4  movaps xmm13, xmm15
00007d516e5df7d8  addpd xmm13, xmm8
00007d516e5df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d516e5df7e3  ptest xmm9, xmm9
00007d516e5df7e9  jnz 0x00007D516E5E380D
00007d516e5df7ef  movaps xmm15, [r15+0x290]
00007d516e5df7f7  vmovaps xmm9, [rsp+0x10]
00007d516e5df7fd  vpermilpd xmm9, xmm9, 0x00
00007d516e5df803  movaps xmm8, xmm15
00007d516e5df807  mulpd xmm8, xmm9
00007d516e5df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d516e5df812  ptest xmm7, xmm7
00007d516e5df817  jnz 0x00007D516E5E3951
00007d516e5df81d  movaps xmm15, xmm11
00007d516e5df821  addpd xmm15, xmm6
00007d516e5df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007d516e5df82c  ptest xmm9, xmm9
00007d516e5df832  jnz 0x00007D516E5E3A95
00007d516e5df838  movaps xmm11, [r15+0x1E0]
00007d516e5df840  vmovaps xmm9, [rsp+0x10]
00007d516e5df846  vpermilpd xmm9, xmm9, 0x00
00007d516e5df84c  movaps xmm7, xmm11
00007d516e5df850  mulpd xmm7, xmm9
00007d516e5df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007d516e5df85a  ptest xmm6, xmm6
00007d516e5df85f  jnz 0x00007D516E5E3BD8
00007d516e5df865  movaps xmm11, xmm10
00007d516e5df869  addpd xmm11, xmm14
00007d516e5df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d516e5df874  ptest xmm9, xmm9
00007d516e5df87a  jnz 0x00007D516E5E3D1A
00007d516e5df880  lea r12, [rax+0x70]
00007d516e5df884  movups xmm14, [r13+r12*1]
00007d516e5df88a  movaps [r15+0x240], xmm14
00007d516e5df892  movaps xmm10, xmm1
00007d516e5df896  addpd xmm10, xmm12
00007d516e5df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007d516e5df8a1  ptest xmm9, xmm9
00007d516e5df8a7  jnz 0x00007D516E5E3E68
00007d516e5df8ad  movaps [r15+0x170], xmm10
00007d516e5df8b5  vmovaps xmm1, [rsp+0x20]
00007d516e5df8bb  vpermilpd xmm1, xmm1, 0x00
00007d516e5df8c1  movaps xmm12, xmm14
00007d516e5df8c5  mulpd xmm12, xmm1
00007d516e5df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007d516e5df8d0  ptest xmm9, xmm9
00007d516e5df8d6  jnz 0x00007D516E5E3FAB
00007d516e5df8dc  vmovaps xmm1, [rsp+0x20]
00007d516e5df8e2  vpermilpd xmm1, xmm1, 0x00
00007d516e5df8e8  vmovaps xmm9, [rsp+0xB0]
00007d516e5df8f1  movaps xmm14, xmm9
00007d516e5df8f5  mulpd xmm14, xmm1
00007d516e5df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007d516e5df900  ptest xmm6, xmm6
00007d516e5df905  jnz 0x00007D516E5E40EE
00007d516e5df90b  movaps [r15+0x180], xmm14
00007d516e5df913  movaps xmm1, xmm13
00007d516e5df917  addpd xmm1, xmm8
00007d516e5df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d516e5df921  ptest xmm9, xmm9
00007d516e5df927  jnz 0x00007D516E5E4231
00007d516e5df92d  movaps [r15+0x210], xmm1
00007d516e5df935  movups xmm13, [r13+rax*1]
00007d516e5df93b  lea r12, [rax+0x10]
00007d516e5df93f  movups xmm9, [r13+r12*1]
00007d516e5df945  movaps [r15+0x230], xmm9
00007d516e5df94d  movaps xmm8, xmm15
00007d516e5df951  addpd xmm8, xmm7
00007d516e5df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007d516e5df95c  ptest xmm6, xmm6
00007d516e5df961  jnz 0x00007D516E5E4387
00007d516e5df967  movaps [r15+0x130], xmm8
00007d516e5df96f  vmovaps xmm15, [rsp+0x20]
00007d516e5df975  vpermilpd xmm15, xmm15, 0x00
00007d516e5df97b  movaps xmm7, xmm9
00007d516e5df97f  mulpd xmm7, xmm15
00007d516e5df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007d516e5df989  ptest xmm6, xmm6
00007d516e5df98e  jnz 0x00007D516E5E44CA
00007d516e5df994  movaps [r15+0x220], xmm7
00007d516e5df99c  vmovaps xmm15, [rsp+0x20]
00007d516e5df9a2  vpermilpd xmm15, xmm15, 0x00
00007d516e5df9a8  movaps xmm9, xmm13
00007d516e5df9ac  mulpd xmm9, xmm15
00007d516e5df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d516e5df9b7  ptest xmm6, xmm6
00007d516e5df9bc  jnz 0x00007D516E5E460C
00007d516e5df9c2  movaps xmm15, xmm11
00007d516e5df9c6  addpd xmm15, xmm12
00007d516e5df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d516e5df9d1  ptest xmm13, xmm13
00007d516e5df9d7  jnz 0x00007D516E5E4750
00007d516e5df9dd  movaps [r15+0x140], xmm15
00007d516e5df9e5  movaps xmm13, xmm10
00007d516e5df9e9  addpd xmm13, xmm14
00007d516e5df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007d516e5df9f4  ptest xmm12, xmm12
00007d516e5df9fa  jnz 0x00007D516E5E4894
00007d516e5dfa00  movaps [r15+0x150], xmm13
00007d516e5dfa08  movaps xmm14, xmm1
00007d516e5dfa0c  addpd xmm14, xmm7
00007d516e5dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007d516e5dfa17  ptest xmm12, xmm12
00007d516e5dfa1d  jnz 0x00007D516E5E49D8
00007d516e5dfa23  movaps [r15+0x160], xmm14
00007d516e5dfa2b  movaps xmm1, xmm8
00007d516e5dfa2f  addpd xmm1, xmm9
00007d516e5dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007d516e5dfa39  ptest xmm12, xmm12
00007d516e5dfa3f  jnz 0x00007D516E5E4B1A
00007d516e5dfa45  movaps [r15+0x120], xmm1
00007d516e5dfa4d  movups [r13+r14*1], xmm15
00007d516e5dfa53  lea rax, [r14+0x10]
00007d516e5dfa57  movups [r13+rax*1], xmm13
00007d516e5dfa5d  lea rax, [r14+0x20]
00007d516e5dfa61  movups [r13+rax*1], xmm14
00007d516e5dfa67  lea rax, [r14+0x30]
00007d516e5dfa6b  movups [r13+rax*1], xmm1
00007d516e5dfa71  mov eax, [r15+0x108]
00007d516e5dfa78  sahf
00007d516e5dfa79  jnz 0x00007D516E5DFAAB
00007d516e5dfa7b  cmp dword ptr [r15+0x318], 0x00
00007d516e5dfa83  jz 0x00007D516E5DEAE0
00007d516e5dfa89  nop [rax+rax*1], ax
00007d516e5dfa92  nop [rax+rax*1], eax
00007d516e5dfa9a  mov eax, 0x4106D0
00007d516e5dfa9f  mov [r15+0x100], rax
00007d516e5dfaa6  jmp 0x00007D516E3FE110
00007d516e5dfaab  cmp dword ptr [r15+0x318], 0x00
00007d516e5dfab3  jz 0x00007D516E5D89C0
00007d516e5dfab9  nop [rax+rax*1], ax
00007d516e5dfac2  nop [rax+rax*1], eax
00007d516e5dfaca  mov eax, 0x410504
00007d516e5dfacf  mov [r15+0x100], rax
00007d516e5dfad6  jmp 0x00007D516E3FE110
00007d516e5dfadb  int3
00007d516e5dfadc  call 0x00007D516E4E27E0
00007d516e5dfae1  jmp 0x00007D516E5DEBBF
00007d516e5dfae6  call 0x00007D516E4E1570
00007d516e5dfaeb  jmp 0x00007D516E5DEBC8
00007d516e5dfaf0  call 0x00007D516E4E27E0
00007d516e5dfaf5  jmp 0x00007D516E5DEC24
00007d516e5dfafa  call 0x00007D516E4E1570
00007d516e5dfaff  jmp 0x00007D516E5DEC2D
00007d516e5dfb04  call 0x00007D516E4E27E0
00007d516e5dfb09  jmp 0x00007D516E5DEC70
00007d516e5dfb0e  call 0x00007D516E4E1570
00007d516e5dfb13  jmp 0x00007D516E5DEC79
00007d516e5dfb18  call 0x00007D516E40DC20
00007d516e5dfb1d  jmp 0x00007D516E5DECB8
00007d516e5dfb22  call 0x00007D516E4D59C0
00007d516e5dfb27  jmp 0x00007D516E5DECCB
00007d516e5dfb2c  call 0x00007D516E4E0E30
00007d516e5dfb31  jmp 0x00007D516E5DECE9
00007d516e5dfb36  call 0x00007D516E4DFBC0
00007d516e5dfb3b  jmp 0x00007D516E5DECF3
00007d516e5dfb40  call 0x00007D516E4DE950
00007d516e5dfb45  jmp 0x00007D516E5DECFD
00007d516e5dfb4a  sub rsp, 0x08
00007d516e5dfb4e  push rax
00007d516e5dfb4f  push rcx
00007d516e5dfb50  push rdx
00007d516e5dfb51  push rdi
00007d516e5dfb52  push rsi
00007d516e5dfb53  push r8
00007d516e5dfb55  push r9
00007d516e5dfb57  push r10
00007d516e5dfb59  push r11
00007d516e5dfb5b  sub rsp, 0xF0
00007d516e5dfb62  vmovaps [rsp], xmm0
00007d516e5dfb67  vmovaps [rsp+0x10], xmm1
00007d516e5dfb6d  vmovaps [rsp+0x20], xmm2
00007d516e5dfb73  vmovaps [rsp+0x30], xmm3
00007d516e5dfb79  vmovaps [rsp+0x40], xmm4
00007d516e5dfb7f  vmovaps [rsp+0x50], xmm5
00007d516e5dfb85  vmovaps [rsp+0x60], xmm6
00007d516e5dfb8b  vmovaps [rsp+0x70], xmm7
00007d516e5dfb91  vmovaps [rsp+0x80], xmm9
00007d516e5dfb9a  vmovaps [rsp+0x90], xmm10
00007d516e5dfba3  vmovaps [rsp+0xA0], xmm11
00007d516e5dfbac  vmovaps [rsp+0xB0], xmm12
00007d516e5dfbb5  vmovaps [rsp+0xC0], xmm13
00007d516e5dfbbe  vmovaps [rsp+0xD0], xmm14
00007d516e5dfbc7  vmovaps [rsp+0xE0], xmm15
00007d516e5dfbd0  sub rsp, 0x30
00007d516e5dfbd4  movaps [rsp], xmm8
00007d516e5dfbd9  movaps [rsp+0x10], xmm12
00007d516e5dfbdf  movaps [rsp+0x20], xmm15
00007d516e5dfbe5  lea rdi, [rsp]
00007d516e5dfbe9  mov esi, 0x00
00007d516e5dfbee  mov rax, 0x5EE43AF14530
00007d516e5dfbf8  call rax
00007d516e5dfbfa  movaps xmm8, [rsp]
00007d516e5dfbff  add rsp, 0x30
00007d516e5dfc03  vmovaps xmm0, [rsp]
00007d516e5dfc08  vmovaps xmm1, [rsp+0x10]
00007d516e5dfc0e  vmovaps xmm2, [rsp+0x20]
00007d516e5dfc14  vmovaps xmm3, [rsp+0x30]
00007d516e5dfc1a  vmovaps xmm4, [rsp+0x40]
00007d516e5dfc20  vmovaps xmm5, [rsp+0x50]
00007d516e5dfc26  vmovaps xmm6, [rsp+0x60]
00007d516e5dfc2c  vmovaps xmm7, [rsp+0x70]
00007d516e5dfc32  vmovaps xmm9, [rsp+0x80]
00007d516e5dfc3b  vmovaps xmm10, [rsp+0x90]
00007d516e5dfc44  vmovaps xmm11, [rsp+0xA0]
00007d516e5dfc4d  vmovaps xmm12, [rsp+0xB0]
00007d516e5dfc56  vmovaps xmm13, [rsp+0xC0]
00007d516e5dfc5f  vmovaps xmm14, [rsp+0xD0]
00007d516e5dfc68  vmovaps xmm15, [rsp+0xE0]
00007d516e5dfc71  add rsp, 0xF0
00007d516e5dfc78  pop r11
00007d516e5dfc7a  pop r10
00007d516e5dfc7c  pop r9
00007d516e5dfc7e  pop r8
00007d516e5dfc80  pop rsi
00007d516e5dfc81  pop rdi
00007d516e5dfc82  pop rdx
00007d516e5dfc83  pop rcx
00007d516e5dfc84  pop rax
00007d516e5dfc85  add rsp, 0x08
00007d516e5dfc89  jmp 0x00007D516E5DED27
00007d516e5dfc8e  sub rsp, 0x08
00007d516e5dfc92  push rax
00007d516e5dfc93  push rcx
00007d516e5dfc94  push rdx
00007d516e5dfc95  push rdi
00007d516e5dfc96  push rsi
00007d516e5dfc97  push r8
00007d516e5dfc99  push r9
00007d516e5dfc9b  push r10
00007d516e5dfc9d  push r11
00007d516e5dfc9f  sub rsp, 0xF0
00007d516e5dfca6  vmovaps [rsp], xmm0
00007d516e5dfcab  vmovaps [rsp+0x10], xmm1
00007d516e5dfcb1  vmovaps [rsp+0x20], xmm2
00007d516e5dfcb7  vmovaps [rsp+0x30], xmm3
00007d516e5dfcbd  vmovaps [rsp+0x40], xmm4
00007d516e5dfcc3  vmovaps [rsp+0x50], xmm5
00007d516e5dfcc9  vmovaps [rsp+0x60], xmm6
00007d516e5dfccf  vmovaps [rsp+0x70], xmm8
00007d516e5dfcd5  vmovaps [rsp+0x80], xmm9
00007d516e5dfcde  vmovaps [rsp+0x90], xmm10
00007d516e5dfce7  vmovaps [rsp+0xA0], xmm11
00007d516e5dfcf0  vmovaps [rsp+0xB0], xmm12
00007d516e5dfcf9  vmovaps [rsp+0xC0], xmm13
00007d516e5dfd02  vmovaps [rsp+0xD0], xmm14
00007d516e5dfd0b  vmovaps [rsp+0xE0], xmm15
00007d516e5dfd14  sub rsp, 0x30
00007d516e5dfd18  movaps [rsp], xmm7
00007d516e5dfd1c  movaps [rsp+0x10], xmm9
00007d516e5dfd22  movaps [rsp+0x20], xmm15
00007d516e5dfd28  lea rdi, [rsp]
00007d516e5dfd2c  mov esi, 0x00
00007d516e5dfd31  mov rax, 0x5EE43AF14530
00007d516e5dfd3b  call rax
00007d516e5dfd3d  movaps xmm7, [rsp]
00007d516e5dfd41  add rsp, 0x30
00007d516e5dfd45  vmovaps xmm0, [rsp]
00007d516e5dfd4a  vmovaps xmm1, [rsp+0x10]
00007d516e5dfd50  vmovaps xmm2, [rsp+0x20]
00007d516e5dfd56  vmovaps xmm3, [rsp+0x30]
00007d516e5dfd5c  vmovaps xmm4, [rsp+0x40]
00007d516e5dfd62  vmovaps xmm5, [rsp+0x50]
00007d516e5dfd68  vmovaps xmm6, [rsp+0x60]
00007d516e5dfd6e  vmovaps xmm8, [rsp+0x70]
00007d516e5dfd74  vmovaps xmm9, [rsp+0x80]
00007d516e5dfd7d  vmovaps xmm10, [rsp+0x90]
00007d516e5dfd86  vmovaps xmm11, [rsp+0xA0]
00007d516e5dfd8f  vmovaps xmm12, [rsp+0xB0]
00007d516e5dfd98  vmovaps xmm13, [rsp+0xC0]
00007d516e5dfda1  vmovaps xmm14, [rsp+0xD0]
00007d516e5dfdaa  vmovaps xmm15, [rsp+0xE0]
00007d516e5dfdb3  add rsp, 0xF0
00007d516e5dfdba  pop r11
00007d516e5dfdbc  pop r10
00007d516e5dfdbe  pop r9
00007d516e5dfdc0  pop r8
00007d516e5dfdc2  pop rsi
00007d516e5dfdc3  pop rdi
00007d516e5dfdc4  pop rdx
00007d516e5dfdc5  pop rcx
00007d516e5dfdc6  pop rax
00007d516e5dfdc7  add rsp, 0x08
00007d516e5dfdcb  jmp 0x00007D516E5DED55
00007d516e5dfdd0  sub rsp, 0x08
00007d516e5dfdd4  push rax
00007d516e5dfdd5  push rcx
00007d516e5dfdd6  push rdx
00007d516e5dfdd7  push rdi
00007d516e5dfdd8  push rsi
00007d516e5dfdd9  push r8
00007d516e5dfddb  push r9
00007d516e5dfddd  push r10
00007d516e5dfddf  push r11
00007d516e5dfde1  sub rsp, 0xF0
00007d516e5dfde8  vmovaps [rsp], xmm0
00007d516e5dfded  vmovaps [rsp+0x10], xmm1
00007d516e5dfdf3  vmovaps [rsp+0x20], xmm2
00007d516e5dfdf9  vmovaps [rsp+0x30], xmm3
00007d516e5dfdff  vmovaps [rsp+0x40], xmm4
00007d516e5dfe05  vmovaps [rsp+0x50], xmm5
00007d516e5dfe0b  vmovaps [rsp+0x60], xmm6
00007d516e5dfe11  vmovaps [rsp+0x70], xmm7
00007d516e5dfe17  vmovaps [rsp+0x80], xmm8
00007d516e5dfe20  vmovaps [rsp+0x90], xmm10
00007d516e5dfe29  vmovaps [rsp+0xA0], xmm11
00007d516e5dfe32  vmovaps [rsp+0xB0], xmm12
00007d516e5dfe3b  vmovaps [rsp+0xC0], xmm13
00007d516e5dfe44  vmovaps [rsp+0xD0], xmm14
00007d516e5dfe4d  vmovaps [rsp+0xE0], xmm15
00007d516e5dfe56  sub rsp, 0x30
00007d516e5dfe5a  movaps [rsp], xmm9
00007d516e5dfe5f  movaps [rsp+0x10], xmm12
00007d516e5dfe65  movaps [rsp+0x20], xmm10
00007d516e5dfe6b  lea rdi, [rsp]
00007d516e5dfe6f  mov esi, 0x00
00007d516e5dfe74  mov rax, 0x5EE43AF14530
00007d516e5dfe7e  call rax
00007d516e5dfe80  movaps xmm9, [rsp]
00007d516e5dfe85  add rsp, 0x30
00007d516e5dfe89  vmovaps xmm0, [rsp]
00007d516e5dfe8e  vmovaps xmm1, [rsp+0x10]
00007d516e5dfe94  vmovaps xmm2, [rsp+0x20]
00007d516e5dfe9a  vmovaps xmm3, [rsp+0x30]
00007d516e5dfea0  vmovaps xmm4, [rsp+0x40]
00007d516e5dfea6  vmovaps xmm5, [rsp+0x50]
00007d516e5dfeac  vmovaps xmm6, [rsp+0x60]
00007d516e5dfeb2  vmovaps xmm7, [rsp+0x70]
00007d516e5dfeb8  vmovaps xmm8, [rsp+0x80]
00007d516e5dfec1  vmovaps xmm10, [rsp+0x90]
00007d516e5dfeca  vmovaps xmm11, [rsp+0xA0]
00007d516e5dfed3  vmovaps xmm12, [rsp+0xB0]
00007d516e5dfedc  vmovaps xmm13, [rsp+0xC0]
00007d516e5dfee5  vmovaps xmm14, [rsp+0xD0]
00007d516e5dfeee  vmovaps xmm15, [rsp+0xE0]
00007d516e5dfef7  add rsp, 0xF0
00007d516e5dfefe  pop r11
00007d516e5dff00  pop r10
00007d516e5dff02  pop r9
00007d516e5dff04  pop r8
00007d516e5dff06  pop rsi
00007d516e5dff07  pop rdi
00007d516e5dff08  pop rdx
00007d516e5dff09  pop rcx
00007d516e5dff0a  pop rax
00007d516e5dff0b  add rsp, 0x08
00007d516e5dff0f  jmp 0x00007D516E5DED79
00007d516e5dff14  sub rsp, 0x08
00007d516e5dff18  push rax
00007d516e5dff19  push rcx
00007d516e5dff1a  push rdx
00007d516e5dff1b  push rdi
00007d516e5dff1c  push rsi
00007d516e5dff1d  push r8
00007d516e5dff1f  push r9
00007d516e5dff21  push r10
00007d516e5dff23  push r11
00007d516e5dff25  sub rsp, 0xF0
00007d516e5dff2c  vmovaps [rsp], xmm0
00007d516e5dff31  vmovaps [rsp+0x10], xmm1
00007d516e5dff37  vmovaps [rsp+0x20], xmm2
00007d516e5dff3d  vmovaps [rsp+0x30], xmm3
00007d516e5dff43  vmovaps [rsp+0x40], xmm4
00007d516e5dff49  vmovaps [rsp+0x50], xmm5
00007d516e5dff4f  vmovaps [rsp+0x60], xmm6
00007d516e5dff55  vmovaps [rsp+0x70], xmm7
00007d516e5dff5b  vmovaps [rsp+0x80], xmm8
00007d516e5dff64  vmovaps [rsp+0x90], xmm9
00007d516e5dff6d  vmovaps [rsp+0xA0], xmm11
00007d516e5dff76  vmovaps [rsp+0xB0], xmm12
00007d516e5dff7f  vmovaps [rsp+0xC0], xmm13
00007d516e5dff88  vmovaps [rsp+0xD0], xmm14
00007d516e5dff91  vmovaps [rsp+0xE0], xmm15
00007d516e5dff9a  sub rsp, 0x30
00007d516e5dff9e  movaps [rsp], xmm10
00007d516e5dffa3  movaps [rsp+0x10], xmm12
00007d516e5dffa9  movaps [rsp+0x20], xmm11
00007d516e5dffaf  lea rdi, [rsp]
00007d516e5dffb3  mov esi, 0x00
00007d516e5dffb8  mov rax, 0x5EE43AF14530
00007d516e5dffc2  call rax
00007d516e5dffc4  movaps xmm10, [rsp]
00007d516e5dffc9  add rsp, 0x30
00007d516e5dffcd  vmovaps xmm0, [rsp]
00007d516e5dffd2  vmovaps xmm1, [rsp+0x10]
00007d516e5dffd8  vmovaps xmm2, [rsp+0x20]
00007d516e5dffde  vmovaps xmm3, [rsp+0x30]
00007d516e5dffe4  vmovaps xmm4, [rsp+0x40]
00007d516e5dffea  vmovaps xmm5, [rsp+0x50]
00007d516e5dfff0  vmovaps xmm6, [rsp+0x60]
00007d516e5dfff6  vmovaps xmm7, [rsp+0x70]
00007d516e5dfffc  vmovaps xmm8, [rsp+0x80]
00007d516e5e0005  vmovaps xmm9, [rsp+0x90]
00007d516e5e000e  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0017  vmovaps xmm12, [rsp+0xB0]
00007d516e5e0020  vmovaps xmm13, [rsp+0xC0]
00007d516e5e0029  vmovaps xmm14, [rsp+0xD0]
00007d516e5e0032  vmovaps xmm15, [rsp+0xE0]
00007d516e5e003b  add rsp, 0xF0
00007d516e5e0042  pop r11
00007d516e5e0044  pop r10
00007d516e5e0046  pop r9
00007d516e5e0048  pop r8
00007d516e5e004a  pop rsi
00007d516e5e004b  pop rdi
00007d516e5e004c  pop rdx
00007d516e5e004d  pop rcx
00007d516e5e004e  pop rax
00007d516e5e004f  add rsp, 0x08
00007d516e5e0053  jmp 0x00007D516E5DED93
00007d516e5e0058  sub rsp, 0x08
00007d516e5e005c  push rax
00007d516e5e005d  push rcx
00007d516e5e005e  push rdx
00007d516e5e005f  push rdi
00007d516e5e0060  push rsi
00007d516e5e0061  push r8
00007d516e5e0063  push r9
00007d516e5e0065  push r10
00007d516e5e0067  push r11
00007d516e5e0069  sub rsp, 0xF0
00007d516e5e0070  vmovaps [rsp], xmm0
00007d516e5e0075  vmovaps [rsp+0x10], xmm1
00007d516e5e007b  vmovaps [rsp+0x20], xmm2
00007d516e5e0081  vmovaps [rsp+0x30], xmm3
00007d516e5e0087  vmovaps [rsp+0x40], xmm4
00007d516e5e008d  vmovaps [rsp+0x50], xmm5
00007d516e5e0093  vmovaps [rsp+0x60], xmm7
00007d516e5e0099  vmovaps [rsp+0x70], xmm8
00007d516e5e009f  vmovaps [rsp+0x80], xmm9
00007d516e5e00a8  vmovaps [rsp+0x90], xmm10
00007d516e5e00b1  vmovaps [rsp+0xA0], xmm11
00007d516e5e00ba  vmovaps [rsp+0xB0], xmm12
00007d516e5e00c3  vmovaps [rsp+0xC0], xmm13
00007d516e5e00cc  vmovaps [rsp+0xD0], xmm14
00007d516e5e00d5  vmovaps [rsp+0xE0], xmm15
00007d516e5e00de  sub rsp, 0x30
00007d516e5e00e2  movaps [rsp], xmm6
00007d516e5e00e6  movaps [rsp+0x10], xmm12
00007d516e5e00ec  movaps [rsp+0x20], xmm11
00007d516e5e00f2  lea rdi, [rsp]
00007d516e5e00f6  mov esi, 0x00
00007d516e5e00fb  mov rax, 0x5EE43AF14530
00007d516e5e0105  call rax
00007d516e5e0107  movaps xmm6, [rsp]
00007d516e5e010b  add rsp, 0x30
00007d516e5e010f  vmovaps xmm0, [rsp]
00007d516e5e0114  vmovaps xmm1, [rsp+0x10]
00007d516e5e011a  vmovaps xmm2, [rsp+0x20]
00007d516e5e0120  vmovaps xmm3, [rsp+0x30]
00007d516e5e0126  vmovaps xmm4, [rsp+0x40]
00007d516e5e012c  vmovaps xmm5, [rsp+0x50]
00007d516e5e0132  vmovaps xmm7, [rsp+0x60]
00007d516e5e0138  vmovaps xmm8, [rsp+0x70]
00007d516e5e013e  vmovaps xmm9, [rsp+0x80]
00007d516e5e0147  vmovaps xmm10, [rsp+0x90]
00007d516e5e0150  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0159  vmovaps xmm12, [rsp+0xB0]
00007d516e5e0162  vmovaps xmm13, [rsp+0xC0]
00007d516e5e016b  vmovaps xmm14, [rsp+0xD0]
00007d516e5e0174  vmovaps xmm15, [rsp+0xE0]
00007d516e5e017d  add rsp, 0xF0
00007d516e5e0184  pop r11
00007d516e5e0186  pop r10
00007d516e5e0188  pop r9
00007d516e5e018a  pop r8
00007d516e5e018c  pop rsi
00007d516e5e018d  pop rdi
00007d516e5e018e  pop rdx
00007d516e5e018f  pop rcx
00007d516e5e0190  pop rax
00007d516e5e0191  add rsp, 0x08
00007d516e5e0195  jmp 0x00007D516E5DEDB4
00007d516e5e019a  sub rsp, 0x08
00007d516e5e019e  push rax
00007d516e5e019f  push rcx
00007d516e5e01a0  push rdx
00007d516e5e01a1  push rdi
00007d516e5e01a2  push rsi
00007d516e5e01a3  push r8
00007d516e5e01a5  push r9
00007d516e5e01a7  push r10
00007d516e5e01a9  push r11
00007d516e5e01ab  sub rsp, 0xF0
00007d516e5e01b2  vmovaps [rsp], xmm0
00007d516e5e01b7  vmovaps [rsp+0x10], xmm1
00007d516e5e01bd  vmovaps [rsp+0x20], xmm2
00007d516e5e01c3  vmovaps [rsp+0x30], xmm4
00007d516e5e01c9  vmovaps [rsp+0x40], xmm5
00007d516e5e01cf  vmovaps [rsp+0x50], xmm6
00007d516e5e01d5  vmovaps [rsp+0x60], xmm7
00007d516e5e01db  vmovaps [rsp+0x70], xmm8
00007d516e5e01e1  vmovaps [rsp+0x80], xmm9
00007d516e5e01ea  vmovaps [rsp+0x90], xmm10
00007d516e5e01f3  vmovaps [rsp+0xA0], xmm11
00007d516e5e01fc  vmovaps [rsp+0xB0], xmm12
00007d516e5e0205  vmovaps [rsp+0xC0], xmm13
00007d516e5e020e  vmovaps [rsp+0xD0], xmm14
00007d516e5e0217  vmovaps [rsp+0xE0], xmm15
00007d516e5e0220  sub rsp, 0x30
00007d516e5e0224  movaps [rsp], xmm3
00007d516e5e0228  movaps [rsp+0x10], xmm5
00007d516e5e022d  movaps [rsp+0x20], xmm4
00007d516e5e0232  lea rdi, [rsp]
00007d516e5e0236  mov esi, 0x00
00007d516e5e023b  mov rax, 0x5EE43AF14530
00007d516e5e0245  call rax
00007d516e5e0247  movaps xmm3, [rsp]
00007d516e5e024b  add rsp, 0x30
00007d516e5e024f  vmovaps xmm0, [rsp]
00007d516e5e0254  vmovaps xmm1, [rsp+0x10]
00007d516e5e025a  vmovaps xmm2, [rsp+0x20]
00007d516e5e0260  vmovaps xmm4, [rsp+0x30]
00007d516e5e0266  vmovaps xmm5, [rsp+0x40]
00007d516e5e026c  vmovaps xmm6, [rsp+0x50]
00007d516e5e0272  vmovaps xmm7, [rsp+0x60]
00007d516e5e0278  vmovaps xmm8, [rsp+0x70]
00007d516e5e027e  vmovaps xmm9, [rsp+0x80]
00007d516e5e0287  vmovaps xmm10, [rsp+0x90]
00007d516e5e0290  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0299  vmovaps xmm12, [rsp+0xB0]
00007d516e5e02a2  vmovaps xmm13, [rsp+0xC0]
00007d516e5e02ab  vmovaps xmm14, [rsp+0xD0]
00007d516e5e02b4  vmovaps xmm15, [rsp+0xE0]
00007d516e5e02bd  add rsp, 0xF0
00007d516e5e02c4  pop r11
00007d516e5e02c6  pop r10
00007d516e5e02c8  pop r9
00007d516e5e02ca  pop r8
00007d516e5e02cc  pop rsi
00007d516e5e02cd  pop rdi
00007d516e5e02ce  pop rdx
00007d516e5e02cf  pop rcx
00007d516e5e02d0  pop rax
00007d516e5e02d1  add rsp, 0x08
00007d516e5e02d5  jmp 0x00007D516E5DEE15
00007d516e5e02da  sub rsp, 0x08
00007d516e5e02de  push rax
00007d516e5e02df  push rcx
00007d516e5e02e0  push rdx
00007d516e5e02e1  push rdi
00007d516e5e02e2  push rsi
00007d516e5e02e3  push r8
00007d516e5e02e5  push r9
00007d516e5e02e7  push r10
00007d516e5e02e9  push r11
00007d516e5e02eb  sub rsp, 0xF0
00007d516e5e02f2  vmovaps [rsp], xmm0
00007d516e5e02f7  vmovaps [rsp+0x10], xmm1
00007d516e5e02fd  vmovaps [rsp+0x20], xmm2
00007d516e5e0303  vmovaps [rsp+0x30], xmm3
00007d516e5e0309  vmovaps [rsp+0x40], xmm4
00007d516e5e030f  vmovaps [rsp+0x50], xmm6
00007d516e5e0315  vmovaps [rsp+0x60], xmm7
00007d516e5e031b  vmovaps [rsp+0x70], xmm8
00007d516e5e0321  vmovaps [rsp+0x80], xmm9
00007d516e5e032a  vmovaps [rsp+0x90], xmm10
00007d516e5e0333  vmovaps [rsp+0xA0], xmm11
00007d516e5e033c  vmovaps [rsp+0xB0], xmm12
00007d516e5e0345  vmovaps [rsp+0xC0], xmm13
00007d516e5e034e  vmovaps [rsp+0xD0], xmm14
00007d516e5e0357  vmovaps [rsp+0xE0], xmm15
00007d516e5e0360  sub rsp, 0x30
00007d516e5e0364  movaps [rsp], xmm5
00007d516e5e0368  movaps [rsp+0x10], xmm8
00007d516e5e036e  movaps [rsp+0x20], xmm15
00007d516e5e0374  lea rdi, [rsp]
00007d516e5e0378  mov esi, 0x00
00007d516e5e037d  mov rax, 0x5EE43AF14530
00007d516e5e0387  call rax
00007d516e5e0389  movaps xmm5, [rsp]
00007d516e5e038d  add rsp, 0x30
00007d516e5e0391  vmovaps xmm0, [rsp]
00007d516e5e0396  vmovaps xmm1, [rsp+0x10]
00007d516e5e039c  vmovaps xmm2, [rsp+0x20]
00007d516e5e03a2  vmovaps xmm3, [rsp+0x30]
00007d516e5e03a8  vmovaps xmm4, [rsp+0x40]
00007d516e5e03ae  vmovaps xmm6, [rsp+0x50]
00007d516e5e03b4  vmovaps xmm7, [rsp+0x60]
00007d516e5e03ba  vmovaps xmm8, [rsp+0x70]
00007d516e5e03c0  vmovaps xmm9, [rsp+0x80]
00007d516e5e03c9  vmovaps xmm10, [rsp+0x90]
00007d516e5e03d2  vmovaps xmm11, [rsp+0xA0]
00007d516e5e03db  vmovaps xmm12, [rsp+0xB0]
00007d516e5e03e4  vmovaps xmm13, [rsp+0xC0]
00007d516e5e03ed  vmovaps xmm14, [rsp+0xD0]
00007d516e5e03f6  vmovaps xmm15, [rsp+0xE0]
00007d516e5e03ff  add rsp, 0xF0
00007d516e5e0406  pop r11
00007d516e5e0408  pop r10
00007d516e5e040a  pop r9
00007d516e5e040c  pop r8
00007d516e5e040e  pop rsi
00007d516e5e040f  pop rdi
00007d516e5e0410  pop rdx
00007d516e5e0411  pop rcx
00007d516e5e0412  pop rax
00007d516e5e0413  add rsp, 0x08
00007d516e5e0417  jmp 0x00007D516E5DEE53
00007d516e5e041c  sub rsp, 0x08
00007d516e5e0420  push rax
00007d516e5e0421  push rcx
00007d516e5e0422  push rdx
00007d516e5e0423  push rdi
00007d516e5e0424  push rsi
00007d516e5e0425  push r8
00007d516e5e0427  push r9
00007d516e5e0429  push r10
00007d516e5e042b  push r11
00007d516e5e042d  sub rsp, 0xF0
00007d516e5e0434  vmovaps [rsp], xmm0
00007d516e5e0439  vmovaps [rsp+0x10], xmm1
00007d516e5e043f  vmovaps [rsp+0x20], xmm2
00007d516e5e0445  vmovaps [rsp+0x30], xmm3
00007d516e5e044b  vmovaps [rsp+0x40], xmm5
00007d516e5e0451  vmovaps [rsp+0x50], xmm6
00007d516e5e0457  vmovaps [rsp+0x60], xmm7
00007d516e5e045d  vmovaps [rsp+0x70], xmm8
00007d516e5e0463  vmovaps [rsp+0x80], xmm9
00007d516e5e046c  vmovaps [rsp+0x90], xmm10
00007d516e5e0475  vmovaps [rsp+0xA0], xmm11
00007d516e5e047e  vmovaps [rsp+0xB0], xmm12
00007d516e5e0487  vmovaps [rsp+0xC0], xmm13
00007d516e5e0490  vmovaps [rsp+0xD0], xmm14
00007d516e5e0499  vmovaps [rsp+0xE0], xmm15
00007d516e5e04a2  sub rsp, 0x30
00007d516e5e04a6  movaps [rsp], xmm4
00007d516e5e04aa  movaps [rsp+0x10], xmm9
00007d516e5e04b0  movaps [rsp+0x20], xmm8
00007d516e5e04b6  lea rdi, [rsp]
00007d516e5e04ba  mov esi, 0x00
00007d516e5e04bf  mov rax, 0x5EE43AF14530
00007d516e5e04c9  call rax
00007d516e5e04cb  movaps xmm4, [rsp]
00007d516e5e04cf  add rsp, 0x30
00007d516e5e04d3  vmovaps xmm0, [rsp]
00007d516e5e04d8  vmovaps xmm1, [rsp+0x10]
00007d516e5e04de  vmovaps xmm2, [rsp+0x20]
00007d516e5e04e4  vmovaps xmm3, [rsp+0x30]
00007d516e5e04ea  vmovaps xmm5, [rsp+0x40]
00007d516e5e04f0  vmovaps xmm6, [rsp+0x50]
00007d516e5e04f6  vmovaps xmm7, [rsp+0x60]
00007d516e5e04fc  vmovaps xmm8, [rsp+0x70]
00007d516e5e0502  vmovaps xmm9, [rsp+0x80]
00007d516e5e050b  vmovaps xmm10, [rsp+0x90]
00007d516e5e0514  vmovaps xmm11, [rsp+0xA0]
00007d516e5e051d  vmovaps xmm12, [rsp+0xB0]
00007d516e5e0526  vmovaps xmm13, [rsp+0xC0]
00007d516e5e052f  vmovaps xmm14, [rsp+0xD0]
00007d516e5e0538  vmovaps xmm15, [rsp+0xE0]
00007d516e5e0541  add rsp, 0xF0
00007d516e5e0548  pop r11
00007d516e5e054a  pop r10
00007d516e5e054c  pop r9
00007d516e5e054e  pop r8
00007d516e5e0550  pop rsi
00007d516e5e0551  pop rdi
00007d516e5e0552  pop rdx
00007d516e5e0553  pop rcx
00007d516e5e0554  pop rax
00007d516e5e0555  add rsp, 0x08
00007d516e5e0559  jmp 0x00007D516E5DEE74
00007d516e5e055e  sub rsp, 0x08
00007d516e5e0562  push rax
00007d516e5e0563  push rcx
00007d516e5e0564  push rdx
00007d516e5e0565  push rdi
00007d516e5e0566  push rsi
00007d516e5e0567  push r8
00007d516e5e0569  push r9
00007d516e5e056b  push r10
00007d516e5e056d  push r11
00007d516e5e056f  sub rsp, 0xF0
00007d516e5e0576  vmovaps [rsp], xmm0
00007d516e5e057b  vmovaps [rsp+0x10], xmm1
00007d516e5e0581  vmovaps [rsp+0x20], xmm2
00007d516e5e0587  vmovaps [rsp+0x30], xmm3
00007d516e5e058d  vmovaps [rsp+0x40], xmm4
00007d516e5e0593  vmovaps [rsp+0x50], xmm5
00007d516e5e0599  vmovaps [rsp+0x60], xmm6
00007d516e5e059f  vmovaps [rsp+0x70], xmm7
00007d516e5e05a5  vmovaps [rsp+0x80], xmm8
00007d516e5e05ae  vmovaps [rsp+0x90], xmm10
00007d516e5e05b7  vmovaps [rsp+0xA0], xmm11
00007d516e5e05c0  vmovaps [rsp+0xB0], xmm12
00007d516e5e05c9  vmovaps [rsp+0xC0], xmm13
00007d516e5e05d2  vmovaps [rsp+0xD0], xmm14
00007d516e5e05db  vmovaps [rsp+0xE0], xmm15
00007d516e5e05e4  sub rsp, 0x30
00007d516e5e05e8  movaps [rsp], xmm9
00007d516e5e05ed  movaps [rsp+0x10], xmm10
00007d516e5e05f3  movaps [rsp+0x20], xmm8
00007d516e5e05f9  lea rdi, [rsp]
00007d516e5e05fd  mov esi, 0x00
00007d516e5e0602  mov rax, 0x5EE43AF14530
00007d516e5e060c  call rax
00007d516e5e060e  movaps xmm9, [rsp]
00007d516e5e0613  add rsp, 0x30
00007d516e5e0617  vmovaps xmm0, [rsp]
00007d516e5e061c  vmovaps xmm1, [rsp+0x10]
00007d516e5e0622  vmovaps xmm2, [rsp+0x20]
00007d516e5e0628  vmovaps xmm3, [rsp+0x30]
00007d516e5e062e  vmovaps xmm4, [rsp+0x40]
00007d516e5e0634  vmovaps xmm5, [rsp+0x50]
00007d516e5e063a  vmovaps xmm6, [rsp+0x60]
00007d516e5e0640  vmovaps xmm7, [rsp+0x70]
00007d516e5e0646  vmovaps xmm8, [rsp+0x80]
00007d516e5e064f  vmovaps xmm10, [rsp+0x90]
00007d516e5e0658  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0661  vmovaps xmm12, [rsp+0xB0]
00007d516e5e066a  vmovaps xmm13, [rsp+0xC0]
00007d516e5e0673  vmovaps xmm14, [rsp+0xD0]
00007d516e5e067c  vmovaps xmm15, [rsp+0xE0]
00007d516e5e0685  add rsp, 0xF0
00007d516e5e068c  pop r11
00007d516e5e068e  pop r10
00007d516e5e0690  pop r9
00007d516e5e0692  pop r8
00007d516e5e0694  pop rsi
00007d516e5e0695  pop rdi
00007d516e5e0696  pop rdx
00007d516e5e0697  pop rcx
00007d516e5e0698  pop rax
00007d516e5e0699  add rsp, 0x08
00007d516e5e069d  jmp 0x00007D516E5DEE8E
00007d516e5e06a2  call 0x00007D516E4B52F0
00007d516e5e06a7  jmp 0x00007D516E5DEFA8
00007d516e5e06ac  call 0x00007D516E4B52F0
00007d516e5e06b1  jmp 0x00007D516E5DEFBE
00007d516e5e06b6  sub rsp, 0x08
00007d516e5e06ba  push rax
00007d516e5e06bb  push rcx
00007d516e5e06bc  push rdx
00007d516e5e06bd  push rdi
00007d516e5e06be  push rsi
00007d516e5e06bf  push r8
00007d516e5e06c1  push r9
00007d516e5e06c3  push r10
00007d516e5e06c5  push r11
00007d516e5e06c7  sub rsp, 0xF0
00007d516e5e06ce  vmovaps [rsp], xmm0
00007d516e5e06d3  vmovaps [rsp+0x10], xmm2
00007d516e5e06d9  vmovaps [rsp+0x20], xmm3
00007d516e5e06df  vmovaps [rsp+0x30], xmm4
00007d516e5e06e5  vmovaps [rsp+0x40], xmm5
00007d516e5e06eb  vmovaps [rsp+0x50], xmm6
00007d516e5e06f1  vmovaps [rsp+0x60], xmm7
00007d516e5e06f7  vmovaps [rsp+0x70], xmm8
00007d516e5e06fd  vmovaps [rsp+0x80], xmm9
00007d516e5e0706  vmovaps [rsp+0x90], xmm10
00007d516e5e070f  vmovaps [rsp+0xA0], xmm11
00007d516e5e0718  vmovaps [rsp+0xB0], xmm12
00007d516e5e0721  vmovaps [rsp+0xC0], xmm13
00007d516e5e072a  vmovaps [rsp+0xD0], xmm14
00007d516e5e0733  vmovaps [rsp+0xE0], xmm15
00007d516e5e073c  sub rsp, 0x30
00007d516e5e0740  movaps [rsp], xmm1
00007d516e5e0744  movaps [rsp+0x10], xmm6
00007d516e5e0749  movaps [rsp+0x20], xmm15
00007d516e5e074f  lea rdi, [rsp]
00007d516e5e0753  mov esi, 0x00
00007d516e5e0758  mov rax, 0x5EE43AF14530
00007d516e5e0762  call rax
00007d516e5e0764  movaps xmm1, [rsp]
00007d516e5e0768  add rsp, 0x30
00007d516e5e076c  vmovaps xmm0, [rsp]
00007d516e5e0771  vmovaps xmm2, [rsp+0x10]
00007d516e5e0777  vmovaps xmm3, [rsp+0x20]
00007d516e5e077d  vmovaps xmm4, [rsp+0x30]
00007d516e5e0783  vmovaps xmm5, [rsp+0x40]
00007d516e5e0789  vmovaps xmm6, [rsp+0x50]
00007d516e5e078f  vmovaps xmm7, [rsp+0x60]
00007d516e5e0795  vmovaps xmm8, [rsp+0x70]
00007d516e5e079b  vmovaps xmm9, [rsp+0x80]
00007d516e5e07a4  vmovaps xmm10, [rsp+0x90]
00007d516e5e07ad  vmovaps xmm11, [rsp+0xA0]
00007d516e5e07b6  vmovaps xmm12, [rsp+0xB0]
00007d516e5e07bf  vmovaps xmm13, [rsp+0xC0]
00007d516e5e07c8  vmovaps xmm14, [rsp+0xD0]
00007d516e5e07d1  vmovaps xmm15, [rsp+0xE0]
00007d516e5e07da  add rsp, 0xF0
00007d516e5e07e1  pop r11
00007d516e5e07e3  pop r10
00007d516e5e07e5  pop r9
00007d516e5e07e7  pop r8
00007d516e5e07e9  pop rsi
00007d516e5e07ea  pop rdi
00007d516e5e07eb  pop rdx
00007d516e5e07ec  pop rcx
00007d516e5e07ed  pop rax
00007d516e5e07ee  add rsp, 0x08
00007d516e5e07f2  jmp 0x00007D516E5DEFFB
00007d516e5e07f7  call 0x00007D516E4C4620
00007d516e5e07fc  jmp 0x00007D516E5DF008
00007d516e5e0801  sub rsp, 0x08
00007d516e5e0805  push rax
00007d516e5e0806  push rcx
00007d516e5e0807  push rdx
00007d516e5e0808  push rdi
00007d516e5e0809  push rsi
00007d516e5e080a  push r8
00007d516e5e080c  push r9
00007d516e5e080e  push r10
00007d516e5e0810  push r11
00007d516e5e0812  sub rsp, 0xF0
00007d516e5e0819  vmovaps [rsp], xmm0
00007d516e5e081e  vmovaps [rsp+0x10], xmm1
00007d516e5e0824  vmovaps [rsp+0x20], xmm2
00007d516e5e082a  vmovaps [rsp+0x30], xmm3
00007d516e5e0830  vmovaps [rsp+0x40], xmm4
00007d516e5e0836  vmovaps [rsp+0x50], xmm5
00007d516e5e083c  vmovaps [rsp+0x60], xmm6
00007d516e5e0842  vmovaps [rsp+0x70], xmm7
00007d516e5e0848  vmovaps [rsp+0x80], xmm8
00007d516e5e0851  vmovaps [rsp+0x90], xmm9
00007d516e5e085a  vmovaps [rsp+0xA0], xmm10
00007d516e5e0863  vmovaps [rsp+0xB0], xmm11
00007d516e5e086c  vmovaps [rsp+0xC0], xmm12
00007d516e5e0875  vmovaps [rsp+0xD0], xmm13
00007d516e5e087e  vmovaps [rsp+0xE0], xmm15
00007d516e5e0887  sub rsp, 0x30
00007d516e5e088b  movaps [rsp], xmm14
00007d516e5e0890  movaps [rsp+0x10], xmm4
00007d516e5e0895  movaps [rsp+0x20], xmm3
00007d516e5e089a  lea rdi, [rsp]
00007d516e5e089e  mov esi, 0x00
00007d516e5e08a3  mov rax, 0x5EE43AF14530
00007d516e5e08ad  call rax
00007d516e5e08af  movaps xmm14, [rsp]
00007d516e5e08b4  add rsp, 0x30
00007d516e5e08b8  vmovaps xmm0, [rsp]
00007d516e5e08bd  vmovaps xmm1, [rsp+0x10]
00007d516e5e08c3  vmovaps xmm2, [rsp+0x20]
00007d516e5e08c9  vmovaps xmm3, [rsp+0x30]
00007d516e5e08cf  vmovaps xmm4, [rsp+0x40]
00007d516e5e08d5  vmovaps xmm5, [rsp+0x50]
00007d516e5e08db  vmovaps xmm6, [rsp+0x60]
00007d516e5e08e1  vmovaps xmm7, [rsp+0x70]
00007d516e5e08e7  vmovaps xmm8, [rsp+0x80]
00007d516e5e08f0  vmovaps xmm9, [rsp+0x90]
00007d516e5e08f9  vmovaps xmm10, [rsp+0xA0]
00007d516e5e0902  vmovaps xmm11, [rsp+0xB0]
00007d516e5e090b  vmovaps xmm12, [rsp+0xC0]
00007d516e5e0914  vmovaps xmm13, [rsp+0xD0]
00007d516e5e091d  vmovaps xmm15, [rsp+0xE0]
00007d516e5e0926  add rsp, 0xF0
00007d516e5e092d  pop r11
00007d516e5e092f  pop r10
00007d516e5e0931  pop r9
00007d516e5e0933  pop r8
00007d516e5e0935  pop rsi
00007d516e5e0936  pop rdi
00007d516e5e0937  pop rdx
00007d516e5e0938  pop rcx
00007d516e5e0939  pop rax
00007d516e5e093a  add rsp, 0x08
00007d516e5e093e  jmp 0x00007D516E5DF022
00007d516e5e0943  sub rsp, 0x08
00007d516e5e0947  push rax
00007d516e5e0948  push rcx
00007d516e5e0949  push rdx
00007d516e5e094a  push rdi
00007d516e5e094b  push rsi
00007d516e5e094c  push r8
00007d516e5e094e  push r9
00007d516e5e0950  push r10
00007d516e5e0952  push r11
00007d516e5e0954  sub rsp, 0xF0
00007d516e5e095b  vmovaps [rsp], xmm0
00007d516e5e0960  vmovaps [rsp+0x10], xmm1
00007d516e5e0966  vmovaps [rsp+0x20], xmm2
00007d516e5e096c  vmovaps [rsp+0x30], xmm3
00007d516e5e0972  vmovaps [rsp+0x40], xmm4
00007d516e5e0978  vmovaps [rsp+0x50], xmm5
00007d516e5e097e  vmovaps [rsp+0x60], xmm7
00007d516e5e0984  vmovaps [rsp+0x70], xmm8
00007d516e5e098a  vmovaps [rsp+0x80], xmm9
00007d516e5e0993  vmovaps [rsp+0x90], xmm10
00007d516e5e099c  vmovaps [rsp+0xA0], xmm11
00007d516e5e09a5  vmovaps [rsp+0xB0], xmm12
00007d516e5e09ae  vmovaps [rsp+0xC0], xmm13
00007d516e5e09b7  vmovaps [rsp+0xD0], xmm14
00007d516e5e09c0  vmovaps [rsp+0xE0], xmm15
00007d516e5e09c9  sub rsp, 0x30
00007d516e5e09cd  movaps [rsp], xmm6
00007d516e5e09d1  movaps [rsp+0x10], xmm9
00007d516e5e09d7  movaps [rsp+0x20], xmm7
00007d516e5e09dc  lea rdi, [rsp]
00007d516e5e09e0  mov esi, 0x00
00007d516e5e09e5  mov rax, 0x5EE43AF14530
00007d516e5e09ef  call rax
00007d516e5e09f1  movaps xmm6, [rsp]
00007d516e5e09f5  add rsp, 0x30
00007d516e5e09f9  vmovaps xmm0, [rsp]
00007d516e5e09fe  vmovaps xmm1, [rsp+0x10]
00007d516e5e0a04  vmovaps xmm2, [rsp+0x20]
00007d516e5e0a0a  vmovaps xmm3, [rsp+0x30]
00007d516e5e0a10  vmovaps xmm4, [rsp+0x40]
00007d516e5e0a16  vmovaps xmm5, [rsp+0x50]
00007d516e5e0a1c  vmovaps xmm7, [rsp+0x60]
00007d516e5e0a22  vmovaps xmm8, [rsp+0x70]
00007d516e5e0a28  vmovaps xmm9, [rsp+0x80]
00007d516e5e0a31  vmovaps xmm10, [rsp+0x90]
00007d516e5e0a3a  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0a43  vmovaps xmm12, [rsp+0xB0]
00007d516e5e0a4c  vmovaps xmm13, [rsp+0xC0]
00007d516e5e0a55  vmovaps xmm14, [rsp+0xD0]
00007d516e5e0a5e  vmovaps xmm15, [rsp+0xE0]
00007d516e5e0a67  add rsp, 0xF0
00007d516e5e0a6e  pop r11
00007d516e5e0a70  pop r10
00007d516e5e0a72  pop r9
00007d516e5e0a74  pop r8
00007d516e5e0a76  pop rsi
00007d516e5e0a77  pop rdi
00007d516e5e0a78  pop rdx
00007d516e5e0a79  pop rcx
00007d516e5e0a7a  pop rax
00007d516e5e0a7b  add rsp, 0x08
00007d516e5e0a7f  jmp 0x00007D516E5DF03A
00007d516e5e0a84  sub rsp, 0x08
00007d516e5e0a88  push rax
00007d516e5e0a89  push rcx
00007d516e5e0a8a  push rdx
00007d516e5e0a8b  push rdi
00007d516e5e0a8c  push rsi
00007d516e5e0a8d  push r8
00007d516e5e0a8f  push r9
00007d516e5e0a91  push r10
00007d516e5e0a93  push r11
00007d516e5e0a95  sub rsp, 0xF0
00007d516e5e0a9c  vmovaps [rsp], xmm0
00007d516e5e0aa1  vmovaps [rsp+0x10], xmm1
00007d516e5e0aa7  vmovaps [rsp+0x20], xmm2
00007d516e5e0aad  vmovaps [rsp+0x30], xmm3
00007d516e5e0ab3  vmovaps [rsp+0x40], xmm4
00007d516e5e0ab9  vmovaps [rsp+0x50], xmm5
00007d516e5e0abf  vmovaps [rsp+0x60], xmm6
00007d516e5e0ac5  vmovaps [rsp+0x70], xmm8
00007d516e5e0acb  vmovaps [rsp+0x80], xmm9
00007d516e5e0ad4  vmovaps [rsp+0x90], xmm10
00007d516e5e0add  vmovaps [rsp+0xA0], xmm11
00007d516e5e0ae6  vmovaps [rsp+0xB0], xmm12
00007d516e5e0aef  vmovaps [rsp+0xC0], xmm13
00007d516e5e0af8  vmovaps [rsp+0xD0], xmm14
00007d516e5e0b01  vmovaps [rsp+0xE0], xmm15
00007d516e5e0b0a  sub rsp, 0x30
00007d516e5e0b0e  movaps [rsp], xmm7
00007d516e5e0b12  movaps [rsp+0x10], xmm4
00007d516e5e0b17  movaps [rsp+0x20], xmm9
00007d516e5e0b1d  lea rdi, [rsp]
00007d516e5e0b21  mov esi, 0x00
00007d516e5e0b26  mov rax, 0x5EE43AF14530
00007d516e5e0b30  call rax
00007d516e5e0b32  movaps xmm7, [rsp]
00007d516e5e0b36  add rsp, 0x30
00007d516e5e0b3a  vmovaps xmm0, [rsp]
00007d516e5e0b3f  vmovaps xmm1, [rsp+0x10]
00007d516e5e0b45  vmovaps xmm2, [rsp+0x20]
00007d516e5e0b4b  vmovaps xmm3, [rsp+0x30]
00007d516e5e0b51  vmovaps xmm4, [rsp+0x40]
00007d516e5e0b57  vmovaps xmm5, [rsp+0x50]
00007d516e5e0b5d  vmovaps xmm6, [rsp+0x60]
00007d516e5e0b63  vmovaps xmm8, [rsp+0x70]
00007d516e5e0b69  vmovaps xmm9, [rsp+0x80]
00007d516e5e0b72  vmovaps xmm10, [rsp+0x90]
00007d516e5e0b7b  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0b84  vmovaps xmm12, [rsp+0xB0]
00007d516e5e0b8d  vmovaps xmm13, [rsp+0xC0]
00007d516e5e0b96  vmovaps xmm14, [rsp+0xD0]
00007d516e5e0b9f  vmovaps xmm15, [rsp+0xE0]
00007d516e5e0ba8  add rsp, 0xF0
00007d516e5e0baf  pop r11
00007d516e5e0bb1  pop r10
00007d516e5e0bb3  pop r9
00007d516e5e0bb5  pop r8
00007d516e5e0bb7  pop rsi
00007d516e5e0bb8  pop rdi
00007d516e5e0bb9  pop rdx
00007d516e5e0bba  pop rcx
00007d516e5e0bbb  pop rax
00007d516e5e0bbc  add rsp, 0x08
00007d516e5e0bc0  jmp 0x00007D516E5DF067
00007d516e5e0bc5  sub rsp, 0x08
00007d516e5e0bc9  push rax
00007d516e5e0bca  push rcx
00007d516e5e0bcb  push rdx
00007d516e5e0bcc  push rdi
00007d516e5e0bcd  push rsi
00007d516e5e0bce  push r8
00007d516e5e0bd0  push r9
00007d516e5e0bd2  push r10
00007d516e5e0bd4  push r11
00007d516e5e0bd6  sub rsp, 0xF0
00007d516e5e0bdd  vmovaps [rsp], xmm0
00007d516e5e0be2  vmovaps [rsp+0x10], xmm1
00007d516e5e0be8  vmovaps [rsp+0x20], xmm2
00007d516e5e0bee  vmovaps [rsp+0x30], xmm3
00007d516e5e0bf4  vmovaps [rsp+0x40], xmm5
00007d516e5e0bfa  vmovaps [rsp+0x50], xmm6
00007d516e5e0c00  vmovaps [rsp+0x60], xmm7
00007d516e5e0c06  vmovaps [rsp+0x70], xmm8
00007d516e5e0c0c  vmovaps [rsp+0x80], xmm9
00007d516e5e0c15  vmovaps [rsp+0x90], xmm10
00007d516e5e0c1e  vmovaps [rsp+0xA0], xmm11
00007d516e5e0c27  vmovaps [rsp+0xB0], xmm12
00007d516e5e0c30  vmovaps [rsp+0xC0], xmm13
00007d516e5e0c39  vmovaps [rsp+0xD0], xmm14
00007d516e5e0c42  vmovaps [rsp+0xE0], xmm15
00007d516e5e0c4b  sub rsp, 0x30
00007d516e5e0c4f  movaps [rsp], xmm4
00007d516e5e0c53  movaps [rsp+0x10], xmm15
00007d516e5e0c59  movaps [rsp+0x20], xmm9
00007d516e5e0c5f  lea rdi, [rsp]
00007d516e5e0c63  mov esi, 0x00
00007d516e5e0c68  mov rax, 0x5EE43AF14530
00007d516e5e0c72  call rax
00007d516e5e0c74  movaps xmm4, [rsp]
00007d516e5e0c78  add rsp, 0x30
00007d516e5e0c7c  vmovaps xmm0, [rsp]
00007d516e5e0c81  vmovaps xmm1, [rsp+0x10]
00007d516e5e0c87  vmovaps xmm2, [rsp+0x20]
00007d516e5e0c8d  vmovaps xmm3, [rsp+0x30]
00007d516e5e0c93  vmovaps xmm5, [rsp+0x40]
00007d516e5e0c99  vmovaps xmm6, [rsp+0x50]
00007d516e5e0c9f  vmovaps xmm7, [rsp+0x60]
00007d516e5e0ca5  vmovaps xmm8, [rsp+0x70]
00007d516e5e0cab  vmovaps xmm9, [rsp+0x80]
00007d516e5e0cb4  vmovaps xmm10, [rsp+0x90]
00007d516e5e0cbd  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0cc6  vmovaps xmm12, [rsp+0xB0]
00007d516e5e0ccf  vmovaps xmm13, [rsp+0xC0]
00007d516e5e0cd8  vmovaps xmm14, [rsp+0xD0]
00007d516e5e0ce1  vmovaps xmm15, [rsp+0xE0]
00007d516e5e0cea  add rsp, 0xF0
00007d516e5e0cf1  pop r11
00007d516e5e0cf3  pop r10
00007d516e5e0cf5  pop r9
00007d516e5e0cf7  pop r8
00007d516e5e0cf9  pop rsi
00007d516e5e0cfa  pop rdi
00007d516e5e0cfb  pop rdx
00007d516e5e0cfc  pop rcx
00007d516e5e0cfd  pop rax
00007d516e5e0cfe  add rsp, 0x08
00007d516e5e0d02  jmp 0x00007D516E5DF08C
00007d516e5e0d07  call 0x00007D516E4C4620
00007d516e5e0d0c  jmp 0x00007D516E5DF099
00007d516e5e0d11  sub rsp, 0x08
00007d516e5e0d15  push rax
00007d516e5e0d16  push rcx
00007d516e5e0d17  push rdx
00007d516e5e0d18  push rdi
00007d516e5e0d19  push rsi
00007d516e5e0d1a  push r8
00007d516e5e0d1c  push r9
00007d516e5e0d1e  push r10
00007d516e5e0d20  push r11
00007d516e5e0d22  sub rsp, 0xF0
00007d516e5e0d29  vmovaps [rsp], xmm0
00007d516e5e0d2e  vmovaps [rsp+0x10], xmm1
00007d516e5e0d34  vmovaps [rsp+0x20], xmm2
00007d516e5e0d3a  vmovaps [rsp+0x30], xmm4
00007d516e5e0d40  vmovaps [rsp+0x40], xmm5
00007d516e5e0d46  vmovaps [rsp+0x50], xmm6
00007d516e5e0d4c  vmovaps [rsp+0x60], xmm7
00007d516e5e0d52  vmovaps [rsp+0x70], xmm8
00007d516e5e0d58  vmovaps [rsp+0x80], xmm9
00007d516e5e0d61  vmovaps [rsp+0x90], xmm10
00007d516e5e0d6a  vmovaps [rsp+0xA0], xmm11
00007d516e5e0d73  vmovaps [rsp+0xB0], xmm12
00007d516e5e0d7c  vmovaps [rsp+0xC0], xmm13
00007d516e5e0d85  vmovaps [rsp+0xD0], xmm14
00007d516e5e0d8e  vmovaps [rsp+0xE0], xmm15
00007d516e5e0d97  sub rsp, 0x30
00007d516e5e0d9b  movaps [rsp], xmm3
00007d516e5e0d9f  movaps [rsp+0x10], xmm1
00007d516e5e0da4  movaps [rsp+0x20], xmm9
00007d516e5e0daa  lea rdi, [rsp]
00007d516e5e0dae  mov esi, 0x00
00007d516e5e0db3  mov rax, 0x5EE43AF14530
00007d516e5e0dbd  call rax
00007d516e5e0dbf  movaps xmm3, [rsp]
00007d516e5e0dc3  add rsp, 0x30
00007d516e5e0dc7  vmovaps xmm0, [rsp]
00007d516e5e0dcc  vmovaps xmm1, [rsp+0x10]
00007d516e5e0dd2  vmovaps xmm2, [rsp+0x20]
00007d516e5e0dd8  vmovaps xmm4, [rsp+0x30]
00007d516e5e0dde  vmovaps xmm5, [rsp+0x40]
00007d516e5e0de4  vmovaps xmm6, [rsp+0x50]
00007d516e5e0dea  vmovaps xmm7, [rsp+0x60]
00007d516e5e0df0  vmovaps xmm8, [rsp+0x70]
00007d516e5e0df6  vmovaps xmm9, [rsp+0x80]
00007d516e5e0dff  vmovaps xmm10, [rsp+0x90]
00007d516e5e0e08  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0e11  vmovaps xmm12, [rsp+0xB0]
00007d516e5e0e1a  vmovaps xmm13, [rsp+0xC0]
00007d516e5e0e23  vmovaps xmm14, [rsp+0xD0]
00007d516e5e0e2c  vmovaps xmm15, [rsp+0xE0]
00007d516e5e0e35  add rsp, 0xF0
00007d516e5e0e3c  pop r11
00007d516e5e0e3e  pop r10
00007d516e5e0e40  pop r9
00007d516e5e0e42  pop r8
00007d516e5e0e44  pop rsi
00007d516e5e0e45  pop rdi
00007d516e5e0e46  pop rdx
00007d516e5e0e47  pop rcx
00007d516e5e0e48  pop rax
00007d516e5e0e49  add rsp, 0x08
00007d516e5e0e4d  jmp 0x00007D516E5DF0D6
00007d516e5e0e52  sub rsp, 0x08
00007d516e5e0e56  push rax
00007d516e5e0e57  push rcx
00007d516e5e0e58  push rdx
00007d516e5e0e59  push rdi
00007d516e5e0e5a  push rsi
00007d516e5e0e5b  push r8
00007d516e5e0e5d  push r9
00007d516e5e0e5f  push r10
00007d516e5e0e61  push r11
00007d516e5e0e63  sub rsp, 0xF0
00007d516e5e0e6a  vmovaps [rsp], xmm0
00007d516e5e0e6f  vmovaps [rsp+0x10], xmm2
00007d516e5e0e75  vmovaps [rsp+0x20], xmm3
00007d516e5e0e7b  vmovaps [rsp+0x30], xmm4
00007d516e5e0e81  vmovaps [rsp+0x40], xmm5
00007d516e5e0e87  vmovaps [rsp+0x50], xmm6
00007d516e5e0e8d  vmovaps [rsp+0x60], xmm7
00007d516e5e0e93  vmovaps [rsp+0x70], xmm8
00007d516e5e0e99  vmovaps [rsp+0x80], xmm9
00007d516e5e0ea2  vmovaps [rsp+0x90], xmm10
00007d516e5e0eab  vmovaps [rsp+0xA0], xmm11
00007d516e5e0eb4  vmovaps [rsp+0xB0], xmm12
00007d516e5e0ebd  vmovaps [rsp+0xC0], xmm13
00007d516e5e0ec6  vmovaps [rsp+0xD0], xmm14
00007d516e5e0ecf  vmovaps [rsp+0xE0], xmm15
00007d516e5e0ed8  sub rsp, 0x30
00007d516e5e0edc  movaps [rsp], xmm1
00007d516e5e0ee0  movaps [rsp+0x10], xmm15
00007d516e5e0ee6  movaps [rsp+0x20], xmm9
00007d516e5e0eec  lea rdi, [rsp]
00007d516e5e0ef0  mov esi, 0x00
00007d516e5e0ef5  mov rax, 0x5EE43AF14530
00007d516e5e0eff  call rax
00007d516e5e0f01  movaps xmm1, [rsp]
00007d516e5e0f05  add rsp, 0x30
00007d516e5e0f09  vmovaps xmm0, [rsp]
00007d516e5e0f0e  vmovaps xmm2, [rsp+0x10]
00007d516e5e0f14  vmovaps xmm3, [rsp+0x20]
00007d516e5e0f1a  vmovaps xmm4, [rsp+0x30]
00007d516e5e0f20  vmovaps xmm5, [rsp+0x40]
00007d516e5e0f26  vmovaps xmm6, [rsp+0x50]
00007d516e5e0f2c  vmovaps xmm7, [rsp+0x60]
00007d516e5e0f32  vmovaps xmm8, [rsp+0x70]
00007d516e5e0f38  vmovaps xmm9, [rsp+0x80]
00007d516e5e0f41  vmovaps xmm10, [rsp+0x90]
00007d516e5e0f4a  vmovaps xmm11, [rsp+0xA0]
00007d516e5e0f53  vmovaps xmm12, [rsp+0xB0]
00007d516e5e0f5c  vmovaps xmm13, [rsp+0xC0]
00007d516e5e0f65  vmovaps xmm14, [rsp+0xD0]
00007d516e5e0f6e  vmovaps xmm15, [rsp+0xE0]
00007d516e5e0f77  add rsp, 0xF0
00007d516e5e0f7e  pop r11
00007d516e5e0f80  pop r10
00007d516e5e0f82  pop r9
00007d516e5e0f84  pop r8
00007d516e5e0f86  pop rsi
00007d516e5e0f87  pop rdi
00007d516e5e0f88  pop rdx
00007d516e5e0f89  pop rcx
00007d516e5e0f8a  pop rax
00007d516e5e0f8b  add rsp, 0x08
00007d516e5e0f8f  jmp 0x00007D516E5DF15E
00007d516e5e0f94  call 0x00007D516E4C4620
00007d516e5e0f99  jmp 0x00007D516E5DF16B
00007d516e5e0f9e  sub rsp, 0x08
00007d516e5e0fa2  push rax
00007d516e5e0fa3  push rcx
00007d516e5e0fa4  push rdx
00007d516e5e0fa5  push rdi
00007d516e5e0fa6  push rsi
00007d516e5e0fa7  push r8
00007d516e5e0fa9  push r9
00007d516e5e0fab  push r10
00007d516e5e0fad  push r11
00007d516e5e0faf  sub rsp, 0xF0
00007d516e5e0fb6  vmovaps [rsp], xmm0
00007d516e5e0fbb  vmovaps [rsp+0x10], xmm2
00007d516e5e0fc1  vmovaps [rsp+0x20], xmm3
00007d516e5e0fc7  vmovaps [rsp+0x30], xmm4
00007d516e5e0fcd  vmovaps [rsp+0x40], xmm5
00007d516e5e0fd3  vmovaps [rsp+0x50], xmm6
00007d516e5e0fd9  vmovaps [rsp+0x60], xmm7
00007d516e5e0fdf  vmovaps [rsp+0x70], xmm8
00007d516e5e0fe5  vmovaps [rsp+0x80], xmm9
00007d516e5e0fee  vmovaps [rsp+0x90], xmm10
00007d516e5e0ff7  vmovaps [rsp+0xA0], xmm11
00007d516e5e1000  vmovaps [rsp+0xB0], xmm12
00007d516e5e1009  vmovaps [rsp+0xC0], xmm13
00007d516e5e1012  vmovaps [rsp+0xD0], xmm14
00007d516e5e101b  vmovaps [rsp+0xE0], xmm15
00007d516e5e1024  sub rsp, 0x30
00007d516e5e1028  movaps [rsp], xmm1
00007d516e5e102c  movaps [rsp+0x10], xmm5
00007d516e5e1031  movaps [rsp+0x20], xmm7
00007d516e5e1036  lea rdi, [rsp]
00007d516e5e103a  mov esi, 0x00
00007d516e5e103f  mov rax, 0x5EE43AF14530
00007d516e5e1049  call rax
00007d516e5e104b  movaps xmm1, [rsp]
00007d516e5e104f  add rsp, 0x30
00007d516e5e1053  vmovaps xmm0, [rsp]
00007d516e5e1058  vmovaps xmm2, [rsp+0x10]
00007d516e5e105e  vmovaps xmm3, [rsp+0x20]
00007d516e5e1064  vmovaps xmm4, [rsp+0x30]
00007d516e5e106a  vmovaps xmm5, [rsp+0x40]
00007d516e5e1070  vmovaps xmm6, [rsp+0x50]
00007d516e5e1076  vmovaps xmm7, [rsp+0x60]
00007d516e5e107c  vmovaps xmm8, [rsp+0x70]
00007d516e5e1082  vmovaps xmm9, [rsp+0x80]
00007d516e5e108b  vmovaps xmm10, [rsp+0x90]
00007d516e5e1094  vmovaps xmm11, [rsp+0xA0]
00007d516e5e109d  vmovaps xmm12, [rsp+0xB0]
00007d516e5e10a6  vmovaps xmm13, [rsp+0xC0]
00007d516e5e10af  vmovaps xmm14, [rsp+0xD0]
00007d516e5e10b8  vmovaps xmm15, [rsp+0xE0]
00007d516e5e10c1  add rsp, 0xF0
00007d516e5e10c8  pop r11
00007d516e5e10ca  pop r10
00007d516e5e10cc  pop r9
00007d516e5e10ce  pop r8
00007d516e5e10d0  pop rsi
00007d516e5e10d1  pop rdi
00007d516e5e10d2  pop rdx
00007d516e5e10d3  pop rcx
00007d516e5e10d4  pop rax
00007d516e5e10d5  add rsp, 0x08
00007d516e5e10d9  jmp 0x00007D516E5DF210
00007d516e5e10de  sub rsp, 0x08
00007d516e5e10e2  push rax
00007d516e5e10e3  push rcx
00007d516e5e10e4  push rdx
00007d516e5e10e5  push rdi
00007d516e5e10e6  push rsi
00007d516e5e10e7  push r8
00007d516e5e10e9  push r9
00007d516e5e10eb  push r10
00007d516e5e10ed  push r11
00007d516e5e10ef  sub rsp, 0xF0
00007d516e5e10f6  vmovaps [rsp], xmm0
00007d516e5e10fb  vmovaps [rsp+0x10], xmm1
00007d516e5e1101  vmovaps [rsp+0x20], xmm2
00007d516e5e1107  vmovaps [rsp+0x30], xmm3
00007d516e5e110d  vmovaps [rsp+0x40], xmm4
00007d516e5e1113  vmovaps [rsp+0x50], xmm5
00007d516e5e1119  vmovaps [rsp+0x60], xmm6
00007d516e5e111f  vmovaps [rsp+0x70], xmm8
00007d516e5e1125  vmovaps [rsp+0x80], xmm9
00007d516e5e112e  vmovaps [rsp+0x90], xmm10
00007d516e5e1137  vmovaps [rsp+0xA0], xmm11
00007d516e5e1140  vmovaps [rsp+0xB0], xmm12
00007d516e5e1149  vmovaps [rsp+0xC0], xmm13
00007d516e5e1152  vmovaps [rsp+0xD0], xmm14
00007d516e5e115b  vmovaps [rsp+0xE0], xmm15
00007d516e5e1164  sub rsp, 0x30
00007d516e5e1168  movaps [rsp], xmm7
00007d516e5e116c  movaps [rsp+0x10], xmm5
00007d516e5e1171  movaps [rsp+0x20], xmm15
00007d516e5e1177  lea rdi, [rsp]
00007d516e5e117b  mov esi, 0x00
00007d516e5e1180  mov rax, 0x5EE43AF14530
00007d516e5e118a  call rax
00007d516e5e118c  movaps xmm7, [rsp]
00007d516e5e1190  add rsp, 0x30
00007d516e5e1194  vmovaps xmm0, [rsp]
00007d516e5e1199  vmovaps xmm1, [rsp+0x10]
00007d516e5e119f  vmovaps xmm2, [rsp+0x20]
00007d516e5e11a5  vmovaps xmm3, [rsp+0x30]
00007d516e5e11ab  vmovaps xmm4, [rsp+0x40]
00007d516e5e11b1  vmovaps xmm5, [rsp+0x50]
00007d516e5e11b7  vmovaps xmm6, [rsp+0x60]
00007d516e5e11bd  vmovaps xmm8, [rsp+0x70]
00007d516e5e11c3  vmovaps xmm9, [rsp+0x80]
00007d516e5e11cc  vmovaps xmm10, [rsp+0x90]
00007d516e5e11d5  vmovaps xmm11, [rsp+0xA0]
00007d516e5e11de  vmovaps xmm12, [rsp+0xB0]
00007d516e5e11e7  vmovaps xmm13, [rsp+0xC0]
00007d516e5e11f0  vmovaps xmm14, [rsp+0xD0]
00007d516e5e11f9  vmovaps xmm15, [rsp+0xE0]
00007d516e5e1202  add rsp, 0xF0
00007d516e5e1209  pop r11
00007d516e5e120b  pop r10
00007d516e5e120d  pop r9
00007d516e5e120f  pop r8
00007d516e5e1211  pop rsi
00007d516e5e1212  pop rdi
00007d516e5e1213  pop rdx
00007d516e5e1214  pop rcx
00007d516e5e1215  pop rax
00007d516e5e1216  add rsp, 0x08
00007d516e5e121a  jmp 0x00007D516E5DF246
00007d516e5e121f  call 0x00007D516E4B52F0
00007d516e5e1224  jmp 0x00007D516E5DF253
00007d516e5e1229  sub rsp, 0x08
00007d516e5e122d  push rax
00007d516e5e122e  push rcx
00007d516e5e122f  push rdx
00007d516e5e1230  push rdi
00007d516e5e1231  push rsi
00007d516e5e1232  push r8
00007d516e5e1234  push r9
00007d516e5e1236  push r10
00007d516e5e1238  push r11
00007d516e5e123a  sub rsp, 0xF0
00007d516e5e1241  vmovaps [rsp], xmm0
00007d516e5e1246  vmovaps [rsp+0x10], xmm1
00007d516e5e124c  vmovaps [rsp+0x20], xmm2
00007d516e5e1252  vmovaps [rsp+0x30], xmm3
00007d516e5e1258  vmovaps [rsp+0x40], xmm4
00007d516e5e125e  vmovaps [rsp+0x50], xmm5
00007d516e5e1264  vmovaps [rsp+0x60], xmm6
00007d516e5e126a  vmovaps [rsp+0x70], xmm7
00007d516e5e1270  vmovaps [rsp+0x80], xmm8
00007d516e5e1279  vmovaps [rsp+0x90], xmm9
00007d516e5e1282  vmovaps [rsp+0xA0], xmm10
00007d516e5e128b  vmovaps [rsp+0xB0], xmm11
00007d516e5e1294  vmovaps [rsp+0xC0], xmm12
00007d516e5e129d  vmovaps [rsp+0xD0], xmm13
00007d516e5e12a6  vmovaps [rsp+0xE0], xmm14
00007d516e5e12af  sub rsp, 0x30
00007d516e5e12b3  movaps [rsp], xmm15
00007d516e5e12b8  movaps [rsp+0x10], xmm5
00007d516e5e12bd  movaps [rsp+0x20], xmm3
00007d516e5e12c2  lea rdi, [rsp]
00007d516e5e12c6  mov esi, 0x00
00007d516e5e12cb  mov rax, 0x5EE43AF14530
00007d516e5e12d5  call rax
00007d516e5e12d7  movaps xmm15, [rsp]
00007d516e5e12dc  add rsp, 0x30
00007d516e5e12e0  vmovaps xmm0, [rsp]
00007d516e5e12e5  vmovaps xmm1, [rsp+0x10]
00007d516e5e12eb  vmovaps xmm2, [rsp+0x20]
00007d516e5e12f1  vmovaps xmm3, [rsp+0x30]
00007d516e5e12f7  vmovaps xmm4, [rsp+0x40]
00007d516e5e12fd  vmovaps xmm5, [rsp+0x50]
00007d516e5e1303  vmovaps xmm6, [rsp+0x60]
00007d516e5e1309  vmovaps xmm7, [rsp+0x70]
00007d516e5e130f  vmovaps xmm8, [rsp+0x80]
00007d516e5e1318  vmovaps xmm9, [rsp+0x90]
00007d516e5e1321  vmovaps xmm10, [rsp+0xA0]
00007d516e5e132a  vmovaps xmm11, [rsp+0xB0]
00007d516e5e1333  vmovaps xmm12, [rsp+0xC0]
00007d516e5e133c  vmovaps xmm13, [rsp+0xD0]
00007d516e5e1345  vmovaps xmm14, [rsp+0xE0]
00007d516e5e134e  add rsp, 0xF0
00007d516e5e1355  pop r11
00007d516e5e1357  pop r10
00007d516e5e1359  pop r9
00007d516e5e135b  pop r8
00007d516e5e135d  pop rsi
00007d516e5e135e  pop rdi
00007d516e5e135f  pop rdx
00007d516e5e1360  pop rcx
00007d516e5e1361  pop rax
00007d516e5e1362  add rsp, 0x08
00007d516e5e1366  jmp 0x00007D516E5DF279
00007d516e5e136b  sub rsp, 0x08
00007d516e5e136f  push rax
00007d516e5e1370  push rcx
00007d516e5e1371  push rdx
00007d516e5e1372  push rdi
00007d516e5e1373  push rsi
00007d516e5e1374  push r8
00007d516e5e1376  push r9
00007d516e5e1378  push r10
00007d516e5e137a  push r11
00007d516e5e137c  sub rsp, 0xF0
00007d516e5e1383  vmovaps [rsp], xmm0
00007d516e5e1388  vmovaps [rsp+0x10], xmm2
00007d516e5e138e  vmovaps [rsp+0x20], xmm3
00007d516e5e1394  vmovaps [rsp+0x30], xmm4
00007d516e5e139a  vmovaps [rsp+0x40], xmm5
00007d516e5e13a0  vmovaps [rsp+0x50], xmm6
00007d516e5e13a6  vmovaps [rsp+0x60], xmm7
00007d516e5e13ac  vmovaps [rsp+0x70], xmm8
00007d516e5e13b2  vmovaps [rsp+0x80], xmm9
00007d516e5e13bb  vmovaps [rsp+0x90], xmm10
00007d516e5e13c4  vmovaps [rsp+0xA0], xmm11
00007d516e5e13cd  vmovaps [rsp+0xB0], xmm12
00007d516e5e13d6  vmovaps [rsp+0xC0], xmm13
00007d516e5e13df  vmovaps [rsp+0xD0], xmm14
00007d516e5e13e8  vmovaps [rsp+0xE0], xmm15
00007d516e5e13f1  sub rsp, 0x30
00007d516e5e13f5  movaps [rsp], xmm1
00007d516e5e13f9  movaps [rsp+0x10], xmm5
00007d516e5e13fe  movaps [rsp+0x20], xmm4
00007d516e5e1403  lea rdi, [rsp]
00007d516e5e1407  mov esi, 0x00
00007d516e5e140c  mov rax, 0x5EE43AF14530
00007d516e5e1416  call rax
00007d516e5e1418  movaps xmm1, [rsp]
00007d516e5e141c  add rsp, 0x30
00007d516e5e1420  vmovaps xmm0, [rsp]
00007d516e5e1425  vmovaps xmm2, [rsp+0x10]
00007d516e5e142b  vmovaps xmm3, [rsp+0x20]
00007d516e5e1431  vmovaps xmm4, [rsp+0x30]
00007d516e5e1437  vmovaps xmm5, [rsp+0x40]
00007d516e5e143d  vmovaps xmm6, [rsp+0x50]
00007d516e5e1443  vmovaps xmm7, [rsp+0x60]
00007d516e5e1449  vmovaps xmm8, [rsp+0x70]
00007d516e5e144f  vmovaps xmm9, [rsp+0x80]
00007d516e5e1458  vmovaps xmm10, [rsp+0x90]
00007d516e5e1461  vmovaps xmm11, [rsp+0xA0]
00007d516e5e146a  vmovaps xmm12, [rsp+0xB0]
00007d516e5e1473  vmovaps xmm13, [rsp+0xC0]
00007d516e5e147c  vmovaps xmm14, [rsp+0xD0]
00007d516e5e1485  vmovaps xmm15, [rsp+0xE0]
00007d516e5e148e  add rsp, 0xF0
00007d516e5e1495  pop r11
00007d516e5e1497  pop r10
00007d516e5e1499  pop r9
00007d516e5e149b  pop r8
00007d516e5e149d  pop rsi
00007d516e5e149e  pop rdi
00007d516e5e149f  pop rdx
00007d516e5e14a0  pop rcx
00007d516e5e14a1  pop rax
00007d516e5e14a2  add rsp, 0x08
00007d516e5e14a6  jmp 0x00007D516E5DF299
00007d516e5e14ab  sub rsp, 0x08
00007d516e5e14af  push rax
00007d516e5e14b0  push rcx
00007d516e5e14b1  push rdx
00007d516e5e14b2  push rdi
00007d516e5e14b3  push rsi
00007d516e5e14b4  push r8
00007d516e5e14b6  push r9
00007d516e5e14b8  push r10
00007d516e5e14ba  push r11
00007d516e5e14bc  sub rsp, 0xF0
00007d516e5e14c3  vmovaps [rsp], xmm0
00007d516e5e14c8  vmovaps [rsp+0x10], xmm1
00007d516e5e14ce  vmovaps [rsp+0x20], xmm2
00007d516e5e14d4  vmovaps [rsp+0x30], xmm3
00007d516e5e14da  vmovaps [rsp+0x40], xmm5
00007d516e5e14e0  vmovaps [rsp+0x50], xmm6
00007d516e5e14e6  vmovaps [rsp+0x60], xmm7
00007d516e5e14ec  vmovaps [rsp+0x70], xmm8
00007d516e5e14f2  vmovaps [rsp+0x80], xmm9
00007d516e5e14fb  vmovaps [rsp+0x90], xmm10
00007d516e5e1504  vmovaps [rsp+0xA0], xmm11
00007d516e5e150d  vmovaps [rsp+0xB0], xmm12
00007d516e5e1516  vmovaps [rsp+0xC0], xmm13
00007d516e5e151f  vmovaps [rsp+0xD0], xmm14
00007d516e5e1528  vmovaps [rsp+0xE0], xmm15
00007d516e5e1531  sub rsp, 0x30
00007d516e5e1535  movaps [rsp], xmm4
00007d516e5e1539  movaps [rsp+0x10], xmm3
00007d516e5e153e  movaps [rsp+0x20], xmm5
00007d516e5e1543  lea rdi, [rsp]
00007d516e5e1547  mov esi, 0x00
00007d516e5e154c  mov rax, 0x5EE43AF14530
00007d516e5e1556  call rax
00007d516e5e1558  movaps xmm4, [rsp]
00007d516e5e155c  add rsp, 0x30
00007d516e5e1560  vmovaps xmm0, [rsp]
00007d516e5e1565  vmovaps xmm1, [rsp+0x10]
00007d516e5e156b  vmovaps xmm2, [rsp+0x20]
00007d516e5e1571  vmovaps xmm3, [rsp+0x30]
00007d516e5e1577  vmovaps xmm5, [rsp+0x40]
00007d516e5e157d  vmovaps xmm6, [rsp+0x50]
00007d516e5e1583  vmovaps xmm7, [rsp+0x60]
00007d516e5e1589  vmovaps xmm8, [rsp+0x70]
00007d516e5e158f  vmovaps xmm9, [rsp+0x80]
00007d516e5e1598  vmovaps xmm10, [rsp+0x90]
00007d516e5e15a1  vmovaps xmm11, [rsp+0xA0]
00007d516e5e15aa  vmovaps xmm12, [rsp+0xB0]
00007d516e5e15b3  vmovaps xmm13, [rsp+0xC0]
00007d516e5e15bc  vmovaps xmm14, [rsp+0xD0]
00007d516e5e15c5  vmovaps xmm15, [rsp+0xE0]
00007d516e5e15ce  add rsp, 0xF0
00007d516e5e15d5  pop r11
00007d516e5e15d7  pop r10
00007d516e5e15d9  pop r9
00007d516e5e15db  pop r8
00007d516e5e15dd  pop rsi
00007d516e5e15de  pop rdi
00007d516e5e15df  pop rdx
00007d516e5e15e0  pop rcx
00007d516e5e15e1  pop rax
00007d516e5e15e2  add rsp, 0x08
00007d516e5e15e6  jmp 0x00007D516E5DF2E7
00007d516e5e15eb  call 0x00007D516E4B52F0
00007d516e5e15f0  jmp 0x00007D516E5DF2F4
00007d516e5e15f5  sub rsp, 0x08
00007d516e5e15f9  push rax
00007d516e5e15fa  push rcx
00007d516e5e15fb  push rdx
00007d516e5e15fc  push rdi
00007d516e5e15fd  push rsi
00007d516e5e15fe  push r8
00007d516e5e1600  push r9
00007d516e5e1602  push r10
00007d516e5e1604  push r11
00007d516e5e1606  sub rsp, 0xF0
00007d516e5e160d  vmovaps [rsp], xmm0
00007d516e5e1612  vmovaps [rsp+0x10], xmm1
00007d516e5e1618  vmovaps [rsp+0x20], xmm2
00007d516e5e161e  vmovaps [rsp+0x30], xmm3
00007d516e5e1624  vmovaps [rsp+0x40], xmm4
00007d516e5e162a  vmovaps [rsp+0x50], xmm6
00007d516e5e1630  vmovaps [rsp+0x60], xmm7
00007d516e5e1636  vmovaps [rsp+0x70], xmm8
00007d516e5e163c  vmovaps [rsp+0x80], xmm9
00007d516e5e1645  vmovaps [rsp+0x90], xmm10
00007d516e5e164e  vmovaps [rsp+0xA0], xmm11
00007d516e5e1657  vmovaps [rsp+0xB0], xmm12
00007d516e5e1660  vmovaps [rsp+0xC0], xmm13
00007d516e5e1669  vmovaps [rsp+0xD0], xmm14
00007d516e5e1672  vmovaps [rsp+0xE0], xmm15
00007d516e5e167b  sub rsp, 0x30
00007d516e5e167f  movaps [rsp], xmm5
00007d516e5e1683  movaps [rsp+0x10], xmm6
00007d516e5e1688  movaps [rsp+0x20], xmm3
00007d516e5e168d  lea rdi, [rsp]
00007d516e5e1691  mov esi, 0x00
00007d516e5e1696  mov rax, 0x5EE43AF14530
00007d516e5e16a0  call rax
00007d516e5e16a2  movaps xmm5, [rsp]
00007d516e5e16a6  add rsp, 0x30
00007d516e5e16aa  vmovaps xmm0, [rsp]
00007d516e5e16af  vmovaps xmm1, [rsp+0x10]
00007d516e5e16b5  vmovaps xmm2, [rsp+0x20]
00007d516e5e16bb  vmovaps xmm3, [rsp+0x30]
00007d516e5e16c1  vmovaps xmm4, [rsp+0x40]
00007d516e5e16c7  vmovaps xmm6, [rsp+0x50]
00007d516e5e16cd  vmovaps xmm7, [rsp+0x60]
00007d516e5e16d3  vmovaps xmm8, [rsp+0x70]
00007d516e5e16d9  vmovaps xmm9, [rsp+0x80]
00007d516e5e16e2  vmovaps xmm10, [rsp+0x90]
00007d516e5e16eb  vmovaps xmm11, [rsp+0xA0]
00007d516e5e16f4  vmovaps xmm12, [rsp+0xB0]
00007d516e5e16fd  vmovaps xmm13, [rsp+0xC0]
00007d516e5e1706  vmovaps xmm14, [rsp+0xD0]
00007d516e5e170f  vmovaps xmm15, [rsp+0xE0]
00007d516e5e1718  add rsp, 0xF0
00007d516e5e171f  pop r11
00007d516e5e1721  pop r10
00007d516e5e1723  pop r9
00007d516e5e1725  pop r8
00007d516e5e1727  pop rsi
00007d516e5e1728  pop rdi
00007d516e5e1729  pop rdx
00007d516e5e172a  pop rcx
00007d516e5e172b  pop rax
00007d516e5e172c  add rsp, 0x08
00007d516e5e1730  jmp 0x00007D516E5DF31A
00007d516e5e1735  sub rsp, 0x08
00007d516e5e1739  push rax
00007d516e5e173a  push rcx
00007d516e5e173b  push rdx
00007d516e5e173c  push rdi
00007d516e5e173d  push rsi
00007d516e5e173e  push r8
00007d516e5e1740  push r9
00007d516e5e1742  push r10
00007d516e5e1744  push r11
00007d516e5e1746  sub rsp, 0xF0
00007d516e5e174d  vmovaps [rsp], xmm0
00007d516e5e1752  vmovaps [rsp+0x10], xmm1
00007d516e5e1758  vmovaps [rsp+0x20], xmm2
00007d516e5e175e  vmovaps [rsp+0x30], xmm3
00007d516e5e1764  vmovaps [rsp+0x40], xmm4
00007d516e5e176a  vmovaps [rsp+0x50], xmm5
00007d516e5e1770  vmovaps [rsp+0x60], xmm7
00007d516e5e1776  vmovaps [rsp+0x70], xmm8
00007d516e5e177c  vmovaps [rsp+0x80], xmm9
00007d516e5e1785  vmovaps [rsp+0x90], xmm10
00007d516e5e178e  vmovaps [rsp+0xA0], xmm11
00007d516e5e1797  vmovaps [rsp+0xB0], xmm12
00007d516e5e17a0  vmovaps [rsp+0xC0], xmm13
00007d516e5e17a9  vmovaps [rsp+0xD0], xmm14
00007d516e5e17b2  vmovaps [rsp+0xE0], xmm15
00007d516e5e17bb  sub rsp, 0x30
00007d516e5e17bf  movaps [rsp], xmm6
00007d516e5e17c3  movaps [rsp+0x10], xmm9
00007d516e5e17c9  movaps [rsp+0x20], xmm1
00007d516e5e17ce  lea rdi, [rsp]
00007d516e5e17d2  mov esi, 0x00
00007d516e5e17d7  mov rax, 0x5EE43AF14530
00007d516e5e17e1  call rax
00007d516e5e17e3  movaps xmm6, [rsp]
00007d516e5e17e7  add rsp, 0x30
00007d516e5e17eb  vmovaps xmm0, [rsp]
00007d516e5e17f0  vmovaps xmm1, [rsp+0x10]
00007d516e5e17f6  vmovaps xmm2, [rsp+0x20]
00007d516e5e17fc  vmovaps xmm3, [rsp+0x30]
00007d516e5e1802  vmovaps xmm4, [rsp+0x40]
00007d516e5e1808  vmovaps xmm5, [rsp+0x50]
00007d516e5e180e  vmovaps xmm7, [rsp+0x60]
00007d516e5e1814  vmovaps xmm8, [rsp+0x70]
00007d516e5e181a  vmovaps xmm9, [rsp+0x80]
00007d516e5e1823  vmovaps xmm10, [rsp+0x90]
00007d516e5e182c  vmovaps xmm11, [rsp+0xA0]
00007d516e5e1835  vmovaps xmm12, [rsp+0xB0]
00007d516e5e183e  vmovaps xmm13, [rsp+0xC0]
00007d516e5e1847  vmovaps xmm14, [rsp+0xD0]
00007d516e5e1850  vmovaps xmm15, [rsp+0xE0]
00007d516e5e1859  add rsp, 0xF0
00007d516e5e1860  pop r11
00007d516e5e1862  pop r10
00007d516e5e1864  pop r9
00007d516e5e1866  pop r8
00007d516e5e1868  pop rsi
00007d516e5e1869  pop rdi
00007d516e5e186a  pop rdx
00007d516e5e186b  pop rcx
00007d516e5e186c  pop rax
00007d516e5e186d  add rsp, 0x08
00007d516e5e1871  jmp 0x00007D516E5DF33E
00007d516e5e1876  sub rsp, 0x08
00007d516e5e187a  push rax
00007d516e5e187b  push rcx
00007d516e5e187c  push rdx
00007d516e5e187d  push rdi
00007d516e5e187e  push rsi
00007d516e5e187f  push r8
00007d516e5e1881  push r9
00007d516e5e1883  push r10
00007d516e5e1885  push r11
00007d516e5e1887  sub rsp, 0xF0
00007d516e5e188e  vmovaps [rsp], xmm0
00007d516e5e1893  vmovaps [rsp+0x10], xmm1
00007d516e5e1899  vmovaps [rsp+0x20], xmm2
00007d516e5e189f  vmovaps [rsp+0x30], xmm3
00007d516e5e18a5  vmovaps [rsp+0x40], xmm4
00007d516e5e18ab  vmovaps [rsp+0x50], xmm5
00007d516e5e18b1  vmovaps [rsp+0x60], xmm6
00007d516e5e18b7  vmovaps [rsp+0x70], xmm7
00007d516e5e18bd  vmovaps [rsp+0x80], xmm8
00007d516e5e18c6  vmovaps [rsp+0x90], xmm10
00007d516e5e18cf  vmovaps [rsp+0xA0], xmm11
00007d516e5e18d8  vmovaps [rsp+0xB0], xmm12
00007d516e5e18e1  vmovaps [rsp+0xC0], xmm13
00007d516e5e18ea  vmovaps [rsp+0xD0], xmm14
00007d516e5e18f3  vmovaps [rsp+0xE0], xmm15
00007d516e5e18fc  sub rsp, 0x30
00007d516e5e1900  movaps [rsp], xmm9
00007d516e5e1905  movaps [rsp+0x10], xmm3
00007d516e5e190a  movaps [rsp+0x20], xmm1
00007d516e5e190f  lea rdi, [rsp]
00007d516e5e1913  mov esi, 0x00
00007d516e5e1918  mov rax, 0x5EE43AF14530
00007d516e5e1922  call rax
00007d516e5e1924  movaps xmm9, [rsp]
00007d516e5e1929  add rsp, 0x30
00007d516e5e192d  vmovaps xmm0, [rsp]
00007d516e5e1932  vmovaps xmm1, [rsp+0x10]
00007d516e5e1938  vmovaps xmm2, [rsp+0x20]
00007d516e5e193e  vmovaps xmm3, [rsp+0x30]
00007d516e5e1944  vmovaps xmm4, [rsp+0x40]
00007d516e5e194a  vmovaps xmm5, [rsp+0x50]
00007d516e5e1950  vmovaps xmm6, [rsp+0x60]
00007d516e5e1956  vmovaps xmm7, [rsp+0x70]
00007d516e5e195c  vmovaps xmm8, [rsp+0x80]
00007d516e5e1965  vmovaps xmm10, [rsp+0x90]
00007d516e5e196e  vmovaps xmm11, [rsp+0xA0]
00007d516e5e1977  vmovaps xmm12, [rsp+0xB0]
00007d516e5e1980  vmovaps xmm13, [rsp+0xC0]
00007d516e5e1989  vmovaps xmm14, [rsp+0xD0]
00007d516e5e1992  vmovaps xmm15, [rsp+0xE0]
00007d516e5e199b  add rsp, 0xF0
00007d516e5e19a2  pop r11
00007d516e5e19a4  pop r10
00007d516e5e19a6  pop r9
00007d516e5e19a8  pop r8
00007d516e5e19aa  pop rsi
00007d516e5e19ab  pop rdi
00007d516e5e19ac  pop rdx
00007d516e5e19ad  pop rcx
00007d516e5e19ae  pop rax
00007d516e5e19af  add rsp, 0x08
00007d516e5e19b3  jmp 0x00007D516E5DF38A
00007d516e5e19b8  call 0x00007D516E4B52F0
00007d516e5e19bd  jmp 0x00007D516E5DF397
00007d516e5e19c2  sub rsp, 0x08
00007d516e5e19c6  push rax
00007d516e5e19c7  push rcx
00007d516e5e19c8  push rdx
00007d516e5e19c9  push rdi
00007d516e5e19ca  push rsi
00007d516e5e19cb  push r8
00007d516e5e19cd  push r9
00007d516e5e19cf  push r10
00007d516e5e19d1  push r11
00007d516e5e19d3  sub rsp, 0xF0
00007d516e5e19da  vmovaps [rsp], xmm0
00007d516e5e19df  vmovaps [rsp+0x10], xmm1
00007d516e5e19e5  vmovaps [rsp+0x20], xmm2
00007d516e5e19eb  vmovaps [rsp+0x30], xmm3
00007d516e5e19f1  vmovaps [rsp+0x40], xmm4
00007d516e5e19f7  vmovaps [rsp+0x50], xmm5
00007d516e5e19fd  vmovaps [rsp+0x60], xmm6
00007d516e5e1a03  vmovaps [rsp+0x70], xmm7
00007d516e5e1a09  vmovaps [rsp+0x80], xmm8
00007d516e5e1a12  vmovaps [rsp+0x90], xmm9
00007d516e5e1a1b  vmovaps [rsp+0xA0], xmm10
00007d516e5e1a24  vmovaps [rsp+0xB0], xmm11
00007d516e5e1a2d  vmovaps [rsp+0xC0], xmm12
00007d516e5e1a36  vmovaps [rsp+0xD0], xmm13
00007d516e5e1a3f  vmovaps [rsp+0xE0], xmm14
00007d516e5e1a48  sub rsp, 0x30
00007d516e5e1a4c  movaps [rsp], xmm15
00007d516e5e1a51  movaps [rsp+0x10], xmm3
00007d516e5e1a56  movaps [rsp+0x20], xmm7
00007d516e5e1a5b  lea rdi, [rsp]
00007d516e5e1a5f  mov esi, 0x00
00007d516e5e1a64  mov rax, 0x5EE43AF14530
00007d516e5e1a6e  call rax
00007d516e5e1a70  movaps xmm15, [rsp]
00007d516e5e1a75  add rsp, 0x30
00007d516e5e1a79  vmovaps xmm0, [rsp]
00007d516e5e1a7e  vmovaps xmm1, [rsp+0x10]
00007d516e5e1a84  vmovaps xmm2, [rsp+0x20]
00007d516e5e1a8a  vmovaps xmm3, [rsp+0x30]
00007d516e5e1a90  vmovaps xmm4, [rsp+0x40]
00007d516e5e1a96  vmovaps xmm5, [rsp+0x50]
00007d516e5e1a9c  vmovaps xmm6, [rsp+0x60]
00007d516e5e1aa2  vmovaps xmm7, [rsp+0x70]
00007d516e5e1aa8  vmovaps xmm8, [rsp+0x80]
00007d516e5e1ab1  vmovaps xmm9, [rsp+0x90]
00007d516e5e1aba  vmovaps xmm10, [rsp+0xA0]
00007d516e5e1ac3  vmovaps xmm11, [rsp+0xB0]
00007d516e5e1acc  vmovaps xmm12, [rsp+0xC0]
00007d516e5e1ad5  vmovaps xmm13, [rsp+0xD0]
00007d516e5e1ade  vmovaps xmm14, [rsp+0xE0]
00007d516e5e1ae7  add rsp, 0xF0
00007d516e5e1aee  pop r11
00007d516e5e1af0  pop r10
00007d516e5e1af2  pop r9
00007d516e5e1af4  pop r8
00007d516e5e1af6  pop rsi
00007d516e5e1af7  pop rdi
00007d516e5e1af8  pop rdx
00007d516e5e1af9  pop rcx
00007d516e5e1afa  pop rax
00007d516e5e1afb  add rsp, 0x08
00007d516e5e1aff  jmp 0x00007D516E5DF3C3
00007d516e5e1b04  sub rsp, 0x08
00007d516e5e1b08  push rax
00007d516e5e1b09  push rcx
00007d516e5e1b0a  push rdx
00007d516e5e1b0b  push rdi
00007d516e5e1b0c  push rsi
00007d516e5e1b0d  push r8
00007d516e5e1b0f  push r9
00007d516e5e1b11  push r10
00007d516e5e1b13  push r11
00007d516e5e1b15  sub rsp, 0xF0
00007d516e5e1b1c  vmovaps [rsp], xmm0
00007d516e5e1b21  vmovaps [rsp+0x10], xmm1
00007d516e5e1b27  vmovaps [rsp+0x20], xmm2
00007d516e5e1b2d  vmovaps [rsp+0x30], xmm4
00007d516e5e1b33  vmovaps [rsp+0x40], xmm5
00007d516e5e1b39  vmovaps [rsp+0x50], xmm6
00007d516e5e1b3f  vmovaps [rsp+0x60], xmm7
00007d516e5e1b45  vmovaps [rsp+0x70], xmm8
00007d516e5e1b4b  vmovaps [rsp+0x80], xmm9
00007d516e5e1b54  vmovaps [rsp+0x90], xmm10
00007d516e5e1b5d  vmovaps [rsp+0xA0], xmm11
00007d516e5e1b66  vmovaps [rsp+0xB0], xmm12
00007d516e5e1b6f  vmovaps [rsp+0xC0], xmm13
00007d516e5e1b78  vmovaps [rsp+0xD0], xmm14
00007d516e5e1b81  vmovaps [rsp+0xE0], xmm15
00007d516e5e1b8a  sub rsp, 0x30
00007d516e5e1b8e  movaps [rsp], xmm3
00007d516e5e1b92  movaps [rsp+0x10], xmm1
00007d516e5e1b97  movaps [rsp+0x20], xmm15
00007d516e5e1b9d  lea rdi, [rsp]
00007d516e5e1ba1  mov esi, 0x00
00007d516e5e1ba6  mov rax, 0x5EE43AF14530
00007d516e5e1bb0  call rax
00007d516e5e1bb2  movaps xmm3, [rsp]
00007d516e5e1bb6  add rsp, 0x30
00007d516e5e1bba  vmovaps xmm0, [rsp]
00007d516e5e1bbf  vmovaps xmm1, [rsp+0x10]
00007d516e5e1bc5  vmovaps xmm2, [rsp+0x20]
00007d516e5e1bcb  vmovaps xmm4, [rsp+0x30]
00007d516e5e1bd1  vmovaps xmm5, [rsp+0x40]
00007d516e5e1bd7  vmovaps xmm6, [rsp+0x50]
00007d516e5e1bdd  vmovaps xmm7, [rsp+0x60]
00007d516e5e1be3  vmovaps xmm8, [rsp+0x70]
00007d516e5e1be9  vmovaps xmm9, [rsp+0x80]
00007d516e5e1bf2  vmovaps xmm10, [rsp+0x90]
00007d516e5e1bfb  vmovaps xmm11, [rsp+0xA0]
00007d516e5e1c04  vmovaps xmm12, [rsp+0xB0]
00007d516e5e1c0d  vmovaps xmm13, [rsp+0xC0]
00007d516e5e1c16  vmovaps xmm14, [rsp+0xD0]
00007d516e5e1c1f  vmovaps xmm15, [rsp+0xE0]
00007d516e5e1c28  add rsp, 0xF0
00007d516e5e1c2f  pop r11
00007d516e5e1c31  pop r10
00007d516e5e1c33  pop r9
00007d516e5e1c35  pop r8
00007d516e5e1c37  pop rsi
00007d516e5e1c38  pop rdi
00007d516e5e1c39  pop rdx
00007d516e5e1c3a  pop rcx
00007d516e5e1c3b  pop rax
00007d516e5e1c3c  add rsp, 0x08
00007d516e5e1c40  jmp 0x00007D516E5DF452
00007d516e5e1c45  call 0x00007D516E4B52F0
00007d516e5e1c4a  jmp 0x00007D516E5DF45C
00007d516e5e1c4f  sub rsp, 0x08
00007d516e5e1c53  push rax
00007d516e5e1c54  push rcx
00007d516e5e1c55  push rdx
00007d516e5e1c56  push rdi
00007d516e5e1c57  push rsi
00007d516e5e1c58  push r8
00007d516e5e1c5a  push r9
00007d516e5e1c5c  push r10
00007d516e5e1c5e  push r11
00007d516e5e1c60  sub rsp, 0xF0
00007d516e5e1c67  vmovaps [rsp], xmm0
00007d516e5e1c6c  vmovaps [rsp+0x10], xmm1
00007d516e5e1c72  vmovaps [rsp+0x20], xmm2
00007d516e5e1c78  vmovaps [rsp+0x30], xmm3
00007d516e5e1c7e  vmovaps [rsp+0x40], xmm4
00007d516e5e1c84  vmovaps [rsp+0x50], xmm5
00007d516e5e1c8a  vmovaps [rsp+0x60], xmm6
00007d516e5e1c90  vmovaps [rsp+0x70], xmm7
00007d516e5e1c96  vmovaps [rsp+0x80], xmm8
00007d516e5e1c9f  vmovaps [rsp+0x90], xmm9
00007d516e5e1ca8  vmovaps [rsp+0xA0], xmm10
00007d516e5e1cb1  vmovaps [rsp+0xB0], xmm11
00007d516e5e1cba  vmovaps [rsp+0xC0], xmm12
00007d516e5e1cc3  vmovaps [rsp+0xD0], xmm13
00007d516e5e1ccc  vmovaps [rsp+0xE0], xmm14
00007d516e5e1cd5  sub rsp, 0x30
00007d516e5e1cd9  movaps [rsp], xmm15
00007d516e5e1cde  movaps [rsp+0x10], xmm14
00007d516e5e1ce4  movaps [rsp+0x20], xmm4
00007d516e5e1ce9  lea rdi, [rsp]
00007d516e5e1ced  mov esi, 0x00
00007d516e5e1cf2  mov rax, 0x5EE43AF14530
00007d516e5e1cfc  call rax
00007d516e5e1cfe  movaps xmm15, [rsp]
00007d516e5e1d03  add rsp, 0x30
00007d516e5e1d07  vmovaps xmm0, [rsp]
00007d516e5e1d0c  vmovaps xmm1, [rsp+0x10]
00007d516e5e1d12  vmovaps xmm2, [rsp+0x20]
00007d516e5e1d18  vmovaps xmm3, [rsp+0x30]
00007d516e5e1d1e  vmovaps xmm4, [rsp+0x40]
00007d516e5e1d24  vmovaps xmm5, [rsp+0x50]
00007d516e5e1d2a  vmovaps xmm6, [rsp+0x60]
00007d516e5e1d30  vmovaps xmm7, [rsp+0x70]
00007d516e5e1d36  vmovaps xmm8, [rsp+0x80]
00007d516e5e1d3f  vmovaps xmm9, [rsp+0x90]
00007d516e5e1d48  vmovaps xmm10, [rsp+0xA0]
00007d516e5e1d51  vmovaps xmm11, [rsp+0xB0]
00007d516e5e1d5a  vmovaps xmm12, [rsp+0xC0]
00007d516e5e1d63  vmovaps xmm13, [rsp+0xD0]
00007d516e5e1d6c  vmovaps xmm14, [rsp+0xE0]
00007d516e5e1d75  add rsp, 0xF0
00007d516e5e1d7c  pop r11
00007d516e5e1d7e  pop r10
00007d516e5e1d80  pop r9
00007d516e5e1d82  pop r8
00007d516e5e1d84  pop rsi
00007d516e5e1d85  pop rdi
00007d516e5e1d86  pop rdx
00007d516e5e1d87  pop rcx
00007d516e5e1d88  pop rax
00007d516e5e1d89  add rsp, 0x08
00007d516e5e1d8d  jmp 0x00007D516E5DF48A
00007d516e5e1d92  sub rsp, 0x08
00007d516e5e1d96  push rax
00007d516e5e1d97  push rcx
00007d516e5e1d98  push rdx
00007d516e5e1d99  push rdi
00007d516e5e1d9a  push rsi
00007d516e5e1d9b  push r8
00007d516e5e1d9d  push r9
00007d516e5e1d9f  push r10
00007d516e5e1da1  push r11
00007d516e5e1da3  sub rsp, 0xF0
00007d516e5e1daa  vmovaps [rsp], xmm0
00007d516e5e1daf  vmovaps [rsp+0x10], xmm1
00007d516e5e1db5  vmovaps [rsp+0x20], xmm2
00007d516e5e1dbb  vmovaps [rsp+0x30], xmm3
00007d516e5e1dc1  vmovaps [rsp+0x40], xmm4
00007d516e5e1dc7  vmovaps [rsp+0x50], xmm5
00007d516e5e1dcd  vmovaps [rsp+0x60], xmm6
00007d516e5e1dd3  vmovaps [rsp+0x70], xmm7
00007d516e5e1dd9  vmovaps [rsp+0x80], xmm8
00007d516e5e1de2  vmovaps [rsp+0x90], xmm9
00007d516e5e1deb  vmovaps [rsp+0xA0], xmm10
00007d516e5e1df4  vmovaps [rsp+0xB0], xmm11
00007d516e5e1dfd  vmovaps [rsp+0xC0], xmm12
00007d516e5e1e06  vmovaps [rsp+0xD0], xmm13
00007d516e5e1e0f  vmovaps [rsp+0xE0], xmm15
00007d516e5e1e18  sub rsp, 0x30
00007d516e5e1e1c  movaps [rsp], xmm14
00007d516e5e1e21  movaps [rsp+0x10], xmm2
00007d516e5e1e26  movaps [rsp+0x20], xmm1
00007d516e5e1e2b  lea rdi, [rsp]
00007d516e5e1e2f  mov esi, 0x00
00007d516e5e1e34  mov rax, 0x5EE43AF14530
00007d516e5e1e3e  call rax
00007d516e5e1e40  movaps xmm14, [rsp]
00007d516e5e1e45  add rsp, 0x30
00007d516e5e1e49  vmovaps xmm0, [rsp]
00007d516e5e1e4e  vmovaps xmm1, [rsp+0x10]
00007d516e5e1e54  vmovaps xmm2, [rsp+0x20]
00007d516e5e1e5a  vmovaps xmm3, [rsp+0x30]
00007d516e5e1e60  vmovaps xmm4, [rsp+0x40]
00007d516e5e1e66  vmovaps xmm5, [rsp+0x50]
00007d516e5e1e6c  vmovaps xmm6, [rsp+0x60]
00007d516e5e1e72  vmovaps xmm7, [rsp+0x70]
00007d516e5e1e78  vmovaps xmm8, [rsp+0x80]
00007d516e5e1e81  vmovaps xmm9, [rsp+0x90]
00007d516e5e1e8a  vmovaps xmm10, [rsp+0xA0]
00007d516e5e1e93  vmovaps xmm11, [rsp+0xB0]
00007d516e5e1e9c  vmovaps xmm12, [rsp+0xC0]
00007d516e5e1ea5  vmovaps xmm13, [rsp+0xD0]
00007d516e5e1eae  vmovaps xmm15, [rsp+0xE0]
00007d516e5e1eb7  add rsp, 0xF0
00007d516e5e1ebe  pop r11
00007d516e5e1ec0  pop r10
00007d516e5e1ec2  pop r9
00007d516e5e1ec4  pop r8
00007d516e5e1ec6  pop rsi
00007d516e5e1ec7  pop rdi
00007d516e5e1ec8  pop rdx
00007d516e5e1ec9  pop rcx
00007d516e5e1eca  pop rax
00007d516e5e1ecb  add rsp, 0x08
00007d516e5e1ecf  jmp 0x00007D516E5DF4B0
00007d516e5e1ed4  sub rsp, 0x08
00007d516e5e1ed8  push rax
00007d516e5e1ed9  push rcx
00007d516e5e1eda  push rdx
00007d516e5e1edb  push rdi
00007d516e5e1edc  push rsi
00007d516e5e1edd  push r8
00007d516e5e1edf  push r9
00007d516e5e1ee1  push r10
00007d516e5e1ee3  push r11
00007d516e5e1ee5  sub rsp, 0xF0
00007d516e5e1eec  vmovaps [rsp], xmm0
00007d516e5e1ef1  vmovaps [rsp+0x10], xmm2
00007d516e5e1ef7  vmovaps [rsp+0x20], xmm3
00007d516e5e1efd  vmovaps [rsp+0x30], xmm4
00007d516e5e1f03  vmovaps [rsp+0x40], xmm5
00007d516e5e1f09  vmovaps [rsp+0x50], xmm6
00007d516e5e1f0f  vmovaps [rsp+0x60], xmm7
00007d516e5e1f15  vmovaps [rsp+0x70], xmm8
00007d516e5e1f1b  vmovaps [rsp+0x80], xmm9
00007d516e5e1f24  vmovaps [rsp+0x90], xmm10
00007d516e5e1f2d  vmovaps [rsp+0xA0], xmm11
00007d516e5e1f36  vmovaps [rsp+0xB0], xmm12
00007d516e5e1f3f  vmovaps [rsp+0xC0], xmm13
00007d516e5e1f48  vmovaps [rsp+0xD0], xmm14
00007d516e5e1f51  vmovaps [rsp+0xE0], xmm15
00007d516e5e1f5a  sub rsp, 0x30
00007d516e5e1f5e  movaps [rsp], xmm1
00007d516e5e1f62  movaps [rsp+0x10], xmm4
00007d516e5e1f67  movaps [rsp+0x20], xmm9
00007d516e5e1f6d  lea rdi, [rsp]
00007d516e5e1f71  mov esi, 0x00
00007d516e5e1f76  mov rax, 0x5EE43AF14530
00007d516e5e1f80  call rax
00007d516e5e1f82  movaps xmm1, [rsp]
00007d516e5e1f86  add rsp, 0x30
00007d516e5e1f8a  vmovaps xmm0, [rsp]
00007d516e5e1f8f  vmovaps xmm2, [rsp+0x10]
00007d516e5e1f95  vmovaps xmm3, [rsp+0x20]
00007d516e5e1f9b  vmovaps xmm4, [rsp+0x30]
00007d516e5e1fa1  vmovaps xmm5, [rsp+0x40]
00007d516e5e1fa7  vmovaps xmm6, [rsp+0x50]
00007d516e5e1fad  vmovaps xmm7, [rsp+0x60]
00007d516e5e1fb3  vmovaps xmm8, [rsp+0x70]
00007d516e5e1fb9  vmovaps xmm9, [rsp+0x80]
00007d516e5e1fc2  vmovaps xmm10, [rsp+0x90]
00007d516e5e1fcb  vmovaps xmm11, [rsp+0xA0]
00007d516e5e1fd4  vmovaps xmm12, [rsp+0xB0]
00007d516e5e1fdd  vmovaps xmm13, [rsp+0xC0]
00007d516e5e1fe6  vmovaps xmm14, [rsp+0xD0]
00007d516e5e1fef  vmovaps xmm15, [rsp+0xE0]
00007d516e5e1ff8  add rsp, 0xF0
00007d516e5e1fff  pop r11
00007d516e5e2001  pop r10
00007d516e5e2003  pop r9
00007d516e5e2005  pop r8
00007d516e5e2007  pop rsi
00007d516e5e2008  pop rdi
00007d516e5e2009  pop rdx
00007d516e5e200a  pop rcx
00007d516e5e200b  pop rax
00007d516e5e200c  add rsp, 0x08
00007d516e5e2010  jmp 0x00007D516E5DF4CE
00007d516e5e2015  sub rsp, 0x08
00007d516e5e2019  push rax
00007d516e5e201a  push rcx
00007d516e5e201b  push rdx
00007d516e5e201c  push rdi
00007d516e5e201d  push rsi
00007d516e5e201e  push r8
00007d516e5e2020  push r9
00007d516e5e2022  push r10
00007d516e5e2024  push r11
00007d516e5e2026  sub rsp, 0xF0
00007d516e5e202d  vmovaps [rsp], xmm0
00007d516e5e2032  vmovaps [rsp+0x10], xmm1
00007d516e5e2038  vmovaps [rsp+0x20], xmm2
00007d516e5e203e  vmovaps [rsp+0x30], xmm3
00007d516e5e2044  vmovaps [rsp+0x40], xmm5
00007d516e5e204a  vmovaps [rsp+0x50], xmm6
00007d516e5e2050  vmovaps [rsp+0x60], xmm7
00007d516e5e2056  vmovaps [rsp+0x70], xmm8
00007d516e5e205c  vmovaps [rsp+0x80], xmm9
00007d516e5e2065  vmovaps [rsp+0x90], xmm10
00007d516e5e206e  vmovaps [rsp+0xA0], xmm11
00007d516e5e2077  vmovaps [rsp+0xB0], xmm12
00007d516e5e2080  vmovaps [rsp+0xC0], xmm13
00007d516e5e2089  vmovaps [rsp+0xD0], xmm14
00007d516e5e2092  vmovaps [rsp+0xE0], xmm15
00007d516e5e209b  sub rsp, 0x30
00007d516e5e209f  movaps [rsp], xmm4
00007d516e5e20a3  movaps [rsp+0x10], xmm2
00007d516e5e20a8  movaps [rsp+0x20], xmm9
00007d516e5e20ae  lea rdi, [rsp]
00007d516e5e20b2  mov esi, 0x00
00007d516e5e20b7  mov rax, 0x5EE43AF14530
00007d516e5e20c1  call rax
00007d516e5e20c3  movaps xmm4, [rsp]
00007d516e5e20c7  add rsp, 0x30
00007d516e5e20cb  vmovaps xmm0, [rsp]
00007d516e5e20d0  vmovaps xmm1, [rsp+0x10]
00007d516e5e20d6  vmovaps xmm2, [rsp+0x20]
00007d516e5e20dc  vmovaps xmm3, [rsp+0x30]
00007d516e5e20e2  vmovaps xmm5, [rsp+0x40]
00007d516e5e20e8  vmovaps xmm6, [rsp+0x50]
00007d516e5e20ee  vmovaps xmm7, [rsp+0x60]
00007d516e5e20f4  vmovaps xmm8, [rsp+0x70]
00007d516e5e20fa  vmovaps xmm9, [rsp+0x80]
00007d516e5e2103  vmovaps xmm10, [rsp+0x90]
00007d516e5e210c  vmovaps xmm11, [rsp+0xA0]
00007d516e5e2115  vmovaps xmm12, [rsp+0xB0]
00007d516e5e211e  vmovaps xmm13, [rsp+0xC0]
00007d516e5e2127  vmovaps xmm14, [rsp+0xD0]
00007d516e5e2130  vmovaps xmm15, [rsp+0xE0]
00007d516e5e2139  add rsp, 0xF0
00007d516e5e2140  pop r11
00007d516e5e2142  pop r10
00007d516e5e2144  pop r9
00007d516e5e2146  pop r8
00007d516e5e2148  pop rsi
00007d516e5e2149  pop rdi
00007d516e5e214a  pop rdx
00007d516e5e214b  pop rcx
00007d516e5e214c  pop rax
00007d516e5e214d  add rsp, 0x08
00007d516e5e2151  jmp 0x00007D516E5DF4FE
00007d516e5e2156  sub rsp, 0x08
00007d516e5e215a  push rax
00007d516e5e215b  push rcx
00007d516e5e215c  push rdx
00007d516e5e215d  push rdi
00007d516e5e215e  push rsi
00007d516e5e215f  push r8
00007d516e5e2161  push r9
00007d516e5e2163  push r10
00007d516e5e2165  push r11
00007d516e5e2167  sub rsp, 0xF0
00007d516e5e216e  vmovaps [rsp], xmm0
00007d516e5e2173  vmovaps [rsp+0x10], xmm1
00007d516e5e2179  vmovaps [rsp+0x20], xmm2
00007d516e5e217f  vmovaps [rsp+0x30], xmm3
00007d516e5e2185  vmovaps [rsp+0x40], xmm4
00007d516e5e218b  vmovaps [rsp+0x50], xmm5
00007d516e5e2191  vmovaps [rsp+0x60], xmm6
00007d516e5e2197  vmovaps [rsp+0x70], xmm7
00007d516e5e219d  vmovaps [rsp+0x80], xmm8
00007d516e5e21a6  vmovaps [rsp+0x90], xmm10
00007d516e5e21af  vmovaps [rsp+0xA0], xmm11
00007d516e5e21b8  vmovaps [rsp+0xB0], xmm12
00007d516e5e21c1  vmovaps [rsp+0xC0], xmm13
00007d516e5e21ca  vmovaps [rsp+0xD0], xmm14
00007d516e5e21d3  vmovaps [rsp+0xE0], xmm15
00007d516e5e21dc  sub rsp, 0x30
00007d516e5e21e0  movaps [rsp], xmm9
00007d516e5e21e5  movaps [rsp+0x10], xmm2
00007d516e5e21ea  movaps [rsp+0x20], xmm1
00007d516e5e21ef  lea rdi, [rsp]
00007d516e5e21f3  mov esi, 0x00
00007d516e5e21f8  mov rax, 0x5EE43AF14530
00007d516e5e2202  call rax
00007d516e5e2204  movaps xmm9, [rsp]
00007d516e5e2209  add rsp, 0x30
00007d516e5e220d  vmovaps xmm0, [rsp]
00007d516e5e2212  vmovaps xmm1, [rsp+0x10]
00007d516e5e2218  vmovaps xmm2, [rsp+0x20]
00007d516e5e221e  vmovaps xmm3, [rsp+0x30]
00007d516e5e2224  vmovaps xmm4, [rsp+0x40]
00007d516e5e222a  vmovaps xmm5, [rsp+0x50]
00007d516e5e2230  vmovaps xmm6, [rsp+0x60]
00007d516e5e2236  vmovaps xmm7, [rsp+0x70]
00007d516e5e223c  vmovaps xmm8, [rsp+0x80]
00007d516e5e2245  vmovaps xmm10, [rsp+0x90]
00007d516e5e224e  vmovaps xmm11, [rsp+0xA0]
00007d516e5e2257  vmovaps xmm12, [rsp+0xB0]
00007d516e5e2260  vmovaps xmm13, [rsp+0xC0]
00007d516e5e2269  vmovaps xmm14, [rsp+0xD0]
00007d516e5e2272  vmovaps xmm15, [rsp+0xE0]
00007d516e5e227b  add rsp, 0xF0
00007d516e5e2282  pop r11
00007d516e5e2284  pop r10
00007d516e5e2286  pop r9
00007d516e5e2288  pop r8
00007d516e5e228a  pop rsi
00007d516e5e228b  pop rdi
00007d516e5e228c  pop rdx
00007d516e5e228d  pop rcx
00007d516e5e228e  pop rax
00007d516e5e228f  add rsp, 0x08
00007d516e5e2293  jmp 0x00007D516E5DF534
00007d516e5e2298  sub rsp, 0x08
00007d516e5e229c  push rax
00007d516e5e229d  push rcx
00007d516e5e229e  push rdx
00007d516e5e229f  push rdi
00007d516e5e22a0  push rsi
00007d516e5e22a1  push r8
00007d516e5e22a3  push r9
00007d516e5e22a5  push r10
00007d516e5e22a7  push r11
00007d516e5e22a9  sub rsp, 0xF0
00007d516e5e22b0  vmovaps [rsp], xmm0
00007d516e5e22b5  vmovaps [rsp+0x10], xmm2
00007d516e5e22bb  vmovaps [rsp+0x20], xmm3
00007d516e5e22c1  vmovaps [rsp+0x30], xmm4
00007d516e5e22c7  vmovaps [rsp+0x40], xmm5
00007d516e5e22cd  vmovaps [rsp+0x50], xmm6
00007d516e5e22d3  vmovaps [rsp+0x60], xmm7
00007d516e5e22d9  vmovaps [rsp+0x70], xmm8
00007d516e5e22df  vmovaps [rsp+0x80], xmm9
00007d516e5e22e8  vmovaps [rsp+0x90], xmm10
00007d516e5e22f1  vmovaps [rsp+0xA0], xmm11
00007d516e5e22fa  vmovaps [rsp+0xB0], xmm12
00007d516e5e2303  vmovaps [rsp+0xC0], xmm13
00007d516e5e230c  vmovaps [rsp+0xD0], xmm14
00007d516e5e2315  vmovaps [rsp+0xE0], xmm15
00007d516e5e231e  sub rsp, 0x30
00007d516e5e2322  movaps [rsp], xmm1
00007d516e5e2326  movaps [rsp+0x10], xmm15
00007d516e5e232c  movaps [rsp+0x20], xmm6
00007d516e5e2331  lea rdi, [rsp]
00007d516e5e2335  mov esi, 0x00
00007d516e5e233a  mov rax, 0x5EE43AF14530
00007d516e5e2344  call rax
00007d516e5e2346  movaps xmm1, [rsp]
00007d516e5e234a  add rsp, 0x30
00007d516e5e234e  vmovaps xmm0, [rsp]
00007d516e5e2353  vmovaps xmm2, [rsp+0x10]
00007d516e5e2359  vmovaps xmm3, [rsp+0x20]
00007d516e5e235f  vmovaps xmm4, [rsp+0x30]
00007d516e5e2365  vmovaps xmm5, [rsp+0x40]
00007d516e5e236b  vmovaps xmm6, [rsp+0x50]
00007d516e5e2371  vmovaps xmm7, [rsp+0x60]
00007d516e5e2377  vmovaps xmm8, [rsp+0x70]
00007d516e5e237d  vmovaps xmm9, [rsp+0x80]
00007d516e5e2386  vmovaps xmm10, [rsp+0x90]
00007d516e5e238f  vmovaps xmm11, [rsp+0xA0]
00007d516e5e2398  vmovaps xmm12, [rsp+0xB0]
00007d516e5e23a1  vmovaps xmm13, [rsp+0xC0]
00007d516e5e23aa  vmovaps xmm14, [rsp+0xD0]
00007d516e5e23b3  vmovaps xmm15, [rsp+0xE0]
00007d516e5e23bc  add rsp, 0xF0
00007d516e5e23c3  pop r11
00007d516e5e23c5  pop r10
00007d516e5e23c7  pop r9
00007d516e5e23c9  pop r8
00007d516e5e23cb  pop rsi
00007d516e5e23cc  pop rdi
00007d516e5e23cd  pop rdx
00007d516e5e23ce  pop rcx
00007d516e5e23cf  pop rax
00007d516e5e23d0  add rsp, 0x08
00007d516e5e23d4  jmp 0x00007D516E5DF555
00007d516e5e23d9  sub rsp, 0x08
00007d516e5e23dd  push rax
00007d516e5e23de  push rcx
00007d516e5e23df  push rdx
00007d516e5e23e0  push rdi
00007d516e5e23e1  push rsi
00007d516e5e23e2  push r8
00007d516e5e23e4  push r9
00007d516e5e23e6  push r10
00007d516e5e23e8  push r11
00007d516e5e23ea  sub rsp, 0xF0
00007d516e5e23f1  vmovaps [rsp], xmm0
00007d516e5e23f6  vmovaps [rsp+0x10], xmm1
00007d516e5e23fc  vmovaps [rsp+0x20], xmm2
00007d516e5e2402  vmovaps [rsp+0x30], xmm3
00007d516e5e2408  vmovaps [rsp+0x40], xmm4
00007d516e5e240e  vmovaps [rsp+0x50], xmm5
00007d516e5e2414  vmovaps [rsp+0x60], xmm6
00007d516e5e241a  vmovaps [rsp+0x70], xmm7
00007d516e5e2420  vmovaps [rsp+0x80], xmm8
00007d516e5e2429  vmovaps [rsp+0x90], xmm9
00007d516e5e2432  vmovaps [rsp+0xA0], xmm10
00007d516e5e243b  vmovaps [rsp+0xB0], xmm11
00007d516e5e2444  vmovaps [rsp+0xC0], xmm12
00007d516e5e244d  vmovaps [rsp+0xD0], xmm13
00007d516e5e2456  vmovaps [rsp+0xE0], xmm14
00007d516e5e245f  sub rsp, 0x30
00007d516e5e2463  movaps [rsp], xmm15
00007d516e5e2468  movaps [rsp+0x10], xmm5
00007d516e5e246d  movaps [rsp+0x20], xmm3
00007d516e5e2472  lea rdi, [rsp]
00007d516e5e2476  mov esi, 0x00
00007d516e5e247b  mov rax, 0x5EE43AF14530
00007d516e5e2485  call rax
00007d516e5e2487  movaps xmm15, [rsp]
00007d516e5e248c  add rsp, 0x30
00007d516e5e2490  vmovaps xmm0, [rsp]
00007d516e5e2495  vmovaps xmm1, [rsp+0x10]
00007d516e5e249b  vmovaps xmm2, [rsp+0x20]
00007d516e5e24a1  vmovaps xmm3, [rsp+0x30]
00007d516e5e24a7  vmovaps xmm4, [rsp+0x40]
00007d516e5e24ad  vmovaps xmm5, [rsp+0x50]
00007d516e5e24b3  vmovaps xmm6, [rsp+0x60]
00007d516e5e24b9  vmovaps xmm7, [rsp+0x70]
00007d516e5e24bf  vmovaps xmm8, [rsp+0x80]
00007d516e5e24c8  vmovaps xmm9, [rsp+0x90]
00007d516e5e24d1  vmovaps xmm10, [rsp+0xA0]
00007d516e5e24da  vmovaps xmm11, [rsp+0xB0]
00007d516e5e24e3  vmovaps xmm12, [rsp+0xC0]
00007d516e5e24ec  vmovaps xmm13, [rsp+0xD0]
00007d516e5e24f5  vmovaps xmm14, [rsp+0xE0]
00007d516e5e24fe  add rsp, 0xF0
00007d516e5e2505  pop r11
00007d516e5e2507  pop r10
00007d516e5e2509  pop r9
00007d516e5e250b  pop r8
00007d516e5e250d  pop rsi
00007d516e5e250e  pop rdi
00007d516e5e250f  pop rdx
00007d516e5e2510  pop rcx
00007d516e5e2511  pop rax
00007d516e5e2512  add rsp, 0x08
00007d516e5e2516  jmp 0x00007D516E5DF56F
00007d516e5e251b  sub rsp, 0x08
00007d516e5e251f  push rax
00007d516e5e2520  push rcx
00007d516e5e2521  push rdx
00007d516e5e2522  push rdi
00007d516e5e2523  push rsi
00007d516e5e2524  push r8
00007d516e5e2526  push r9
00007d516e5e2528  push r10
00007d516e5e252a  push r11
00007d516e5e252c  sub rsp, 0xF0
00007d516e5e2533  vmovaps [rsp], xmm0
00007d516e5e2538  vmovaps [rsp+0x10], xmm1
00007d516e5e253e  vmovaps [rsp+0x20], xmm2
00007d516e5e2544  vmovaps [rsp+0x30], xmm3
00007d516e5e254a  vmovaps [rsp+0x40], xmm4
00007d516e5e2550  vmovaps [rsp+0x50], xmm6
00007d516e5e2556  vmovaps [rsp+0x60], xmm7
00007d516e5e255c  vmovaps [rsp+0x70], xmm8
00007d516e5e2562  vmovaps [rsp+0x80], xmm9
00007d516e5e256b  vmovaps [rsp+0x90], xmm10
00007d516e5e2574  vmovaps [rsp+0xA0], xmm11
00007d516e5e257d  vmovaps [rsp+0xB0], xmm12
00007d516e5e2586  vmovaps [rsp+0xC0], xmm13
00007d516e5e258f  vmovaps [rsp+0xD0], xmm14
00007d516e5e2598  vmovaps [rsp+0xE0], xmm15
00007d516e5e25a1  sub rsp, 0x30
00007d516e5e25a5  movaps [rsp], xmm5
00007d516e5e25a9  movaps [rsp+0x10], xmm8
00007d516e5e25af  movaps [rsp+0x20], xmm6
00007d516e5e25b4  lea rdi, [rsp]
00007d516e5e25b8  mov esi, 0x00
00007d516e5e25bd  mov rax, 0x5EE43AF14530
00007d516e5e25c7  call rax
00007d516e5e25c9  movaps xmm5, [rsp]
00007d516e5e25cd  add rsp, 0x30
00007d516e5e25d1  vmovaps xmm0, [rsp]
00007d516e5e25d6  vmovaps xmm1, [rsp+0x10]
00007d516e5e25dc  vmovaps xmm2, [rsp+0x20]
00007d516e5e25e2  vmovaps xmm3, [rsp+0x30]
00007d516e5e25e8  vmovaps xmm4, [rsp+0x40]
00007d516e5e25ee  vmovaps xmm6, [rsp+0x50]
00007d516e5e25f4  vmovaps xmm7, [rsp+0x60]
00007d516e5e25fa  vmovaps xmm8, [rsp+0x70]
00007d516e5e2600  vmovaps xmm9, [rsp+0x80]
00007d516e5e2609  vmovaps xmm10, [rsp+0x90]
00007d516e5e2612  vmovaps xmm11, [rsp+0xA0]
00007d516e5e261b  vmovaps xmm12, [rsp+0xB0]
00007d516e5e2624  vmovaps xmm13, [rsp+0xC0]
00007d516e5e262d  vmovaps xmm14, [rsp+0xD0]
00007d516e5e2636  vmovaps xmm15, [rsp+0xE0]
00007d516e5e263f  add rsp, 0xF0
00007d516e5e2646  pop r11
00007d516e5e2648  pop r10
00007d516e5e264a  pop r9
00007d516e5e264c  pop r8
00007d516e5e264e  pop rsi
00007d516e5e264f  pop rdi
00007d516e5e2650  pop rdx
00007d516e5e2651  pop rcx
00007d516e5e2652  pop rax
00007d516e5e2653  add rsp, 0x08
00007d516e5e2657  jmp 0x00007D516E5DF593
00007d516e5e265c  sub rsp, 0x08
00007d516e5e2660  push rax
00007d516e5e2661  push rcx
00007d516e5e2662  push rdx
00007d516e5e2663  push rdi
00007d516e5e2664  push rsi
00007d516e5e2665  push r8
00007d516e5e2667  push r9
00007d516e5e2669  push r10
00007d516e5e266b  push r11
00007d516e5e266d  sub rsp, 0xF0
00007d516e5e2674  vmovaps [rsp], xmm0
00007d516e5e2679  vmovaps [rsp+0x10], xmm1
00007d516e5e267f  vmovaps [rsp+0x20], xmm2
00007d516e5e2685  vmovaps [rsp+0x30], xmm3
00007d516e5e268b  vmovaps [rsp+0x40], xmm4
00007d516e5e2691  vmovaps [rsp+0x50], xmm5
00007d516e5e2697  vmovaps [rsp+0x60], xmm7
00007d516e5e269d  vmovaps [rsp+0x70], xmm8
00007d516e5e26a3  vmovaps [rsp+0x80], xmm9
00007d516e5e26ac  vmovaps [rsp+0x90], xmm10
00007d516e5e26b5  vmovaps [rsp+0xA0], xmm11
00007d516e5e26be  vmovaps [rsp+0xB0], xmm12
00007d516e5e26c7  vmovaps [rsp+0xC0], xmm13
00007d516e5e26d0  vmovaps [rsp+0xD0], xmm14
00007d516e5e26d9  vmovaps [rsp+0xE0], xmm15
00007d516e5e26e2  sub rsp, 0x30
00007d516e5e26e6  movaps [rsp], xmm6
00007d516e5e26ea  movaps [rsp+0x10], xmm10
00007d516e5e26f0  movaps [rsp+0x20], xmm8
00007d516e5e26f6  lea rdi, [rsp]
00007d516e5e26fa  mov esi, 0x00
00007d516e5e26ff  mov rax, 0x5EE43AF14530
00007d516e5e2709  call rax
00007d516e5e270b  movaps xmm6, [rsp]
00007d516e5e270f  add rsp, 0x30
00007d516e5e2713  vmovaps xmm0, [rsp]
00007d516e5e2718  vmovaps xmm1, [rsp+0x10]
00007d516e5e271e  vmovaps xmm2, [rsp+0x20]
00007d516e5e2724  vmovaps xmm3, [rsp+0x30]
00007d516e5e272a  vmovaps xmm4, [rsp+0x40]
00007d516e5e2730  vmovaps xmm5, [rsp+0x50]
00007d516e5e2736  vmovaps xmm7, [rsp+0x60]
00007d516e5e273c  vmovaps xmm8, [rsp+0x70]
00007d516e5e2742  vmovaps xmm9, [rsp+0x80]
00007d516e5e274b  vmovaps xmm10, [rsp+0x90]
00007d516e5e2754  vmovaps xmm11, [rsp+0xA0]
00007d516e5e275d  vmovaps xmm12, [rsp+0xB0]
00007d516e5e2766  vmovaps xmm13, [rsp+0xC0]
00007d516e5e276f  vmovaps xmm14, [rsp+0xD0]
00007d516e5e2778  vmovaps xmm15, [rsp+0xE0]
00007d516e5e2781  add rsp, 0xF0
00007d516e5e2788  pop r11
00007d516e5e278a  pop r10
00007d516e5e278c  pop r9
00007d516e5e278e  pop r8
00007d516e5e2790  pop rsi
00007d516e5e2791  pop rdi
00007d516e5e2792  pop rdx
00007d516e5e2793  pop rcx
00007d516e5e2794  pop rax
00007d516e5e2795  add rsp, 0x08
00007d516e5e2799  jmp 0x00007D516E5DF5B8
00007d516e5e279e  sub rsp, 0x08
00007d516e5e27a2  push rax
00007d516e5e27a3  push rcx
00007d516e5e27a4  push rdx
00007d516e5e27a5  push rdi
00007d516e5e27a6  push rsi
00007d516e5e27a7  push r8
00007d516e5e27a9  push r9
00007d516e5e27ab  push r10
00007d516e5e27ad  push r11
00007d516e5e27af  sub rsp, 0xF0
00007d516e5e27b6  vmovaps [rsp], xmm0
00007d516e5e27bb  vmovaps [rsp+0x10], xmm1
00007d516e5e27c1  vmovaps [rsp+0x20], xmm2
00007d516e5e27c7  vmovaps [rsp+0x30], xmm3
00007d516e5e27cd  vmovaps [rsp+0x40], xmm4
00007d516e5e27d3  vmovaps [rsp+0x50], xmm5
00007d516e5e27d9  vmovaps [rsp+0x60], xmm6
00007d516e5e27df  vmovaps [rsp+0x70], xmm7
00007d516e5e27e5  vmovaps [rsp+0x80], xmm8
00007d516e5e27ee  vmovaps [rsp+0x90], xmm9
00007d516e5e27f7  vmovaps [rsp+0xA0], xmm11
00007d516e5e2800  vmovaps [rsp+0xB0], xmm12
00007d516e5e2809  vmovaps [rsp+0xC0], xmm13
00007d516e5e2812  vmovaps [rsp+0xD0], xmm14
00007d516e5e281b  vmovaps [rsp+0xE0], xmm15
00007d516e5e2824  sub rsp, 0x30
00007d516e5e2828  movaps [rsp], xmm10
00007d516e5e282d  movaps [rsp+0x10], xmm8
00007d516e5e2833  movaps [rsp+0x20], xmm14
00007d516e5e2839  lea rdi, [rsp]
00007d516e5e283d  mov esi, 0x00
00007d516e5e2842  mov rax, 0x5EE43AF14530
00007d516e5e284c  call rax
00007d516e5e284e  movaps xmm10, [rsp]
00007d516e5e2853  add rsp, 0x30
00007d516e5e2857  vmovaps xmm0, [rsp]
00007d516e5e285c  vmovaps xmm1, [rsp+0x10]
00007d516e5e2862  vmovaps xmm2, [rsp+0x20]
00007d516e5e2868  vmovaps xmm3, [rsp+0x30]
00007d516e5e286e  vmovaps xmm4, [rsp+0x40]
00007d516e5e2874  vmovaps xmm5, [rsp+0x50]
00007d516e5e287a  vmovaps xmm6, [rsp+0x60]
00007d516e5e2880  vmovaps xmm7, [rsp+0x70]
00007d516e5e2886  vmovaps xmm8, [rsp+0x80]
00007d516e5e288f  vmovaps xmm9, [rsp+0x90]
00007d516e5e2898  vmovaps xmm11, [rsp+0xA0]
00007d516e5e28a1  vmovaps xmm12, [rsp+0xB0]
00007d516e5e28aa  vmovaps xmm13, [rsp+0xC0]
00007d516e5e28b3  vmovaps xmm14, [rsp+0xD0]
00007d516e5e28bc  vmovaps xmm15, [rsp+0xE0]
00007d516e5e28c5  add rsp, 0xF0
00007d516e5e28cc  pop r11
00007d516e5e28ce  pop r10
00007d516e5e28d0  pop r9
00007d516e5e28d2  pop r8
00007d516e5e28d4  pop rsi
00007d516e5e28d5  pop rdi
00007d516e5e28d6  pop rdx
00007d516e5e28d7  pop rcx
00007d516e5e28d8  pop rax
00007d516e5e28d9  add rsp, 0x08
00007d516e5e28dd  jmp 0x00007D516E5DF5D8
00007d516e5e28e2  sub rsp, 0x08
00007d516e5e28e6  push rax
00007d516e5e28e7  push rcx
00007d516e5e28e8  push rdx
00007d516e5e28e9  push rdi
00007d516e5e28ea  push rsi
00007d516e5e28eb  push r8
00007d516e5e28ed  push r9
00007d516e5e28ef  push r10
00007d516e5e28f1  push r11
00007d516e5e28f3  sub rsp, 0xF0
00007d516e5e28fa  vmovaps [rsp], xmm0
00007d516e5e28ff  vmovaps [rsp+0x10], xmm1
00007d516e5e2905  vmovaps [rsp+0x20], xmm2
00007d516e5e290b  vmovaps [rsp+0x30], xmm3
00007d516e5e2911  vmovaps [rsp+0x40], xmm4
00007d516e5e2917  vmovaps [rsp+0x50], xmm5
00007d516e5e291d  vmovaps [rsp+0x60], xmm6
00007d516e5e2923  vmovaps [rsp+0x70], xmm7
00007d516e5e2929  vmovaps [rsp+0x80], xmm8
00007d516e5e2932  vmovaps [rsp+0x90], xmm9
00007d516e5e293b  vmovaps [rsp+0xA0], xmm10
00007d516e5e2944  vmovaps [rsp+0xB0], xmm11
00007d516e5e294d  vmovaps [rsp+0xC0], xmm12
00007d516e5e2956  vmovaps [rsp+0xD0], xmm13
00007d516e5e295f  vmovaps [rsp+0xE0], xmm15
00007d516e5e2968  sub rsp, 0x30
00007d516e5e296c  movaps [rsp], xmm14
00007d516e5e2971  movaps [rsp+0x10], xmm8
00007d516e5e2977  movaps [rsp+0x20], xmm4
00007d516e5e297c  lea rdi, [rsp]
00007d516e5e2980  mov esi, 0x00
00007d516e5e2985  mov rax, 0x5EE43AF14530
00007d516e5e298f  call rax
00007d516e5e2991  movaps xmm14, [rsp]
00007d516e5e2996  add rsp, 0x30
00007d516e5e299a  vmovaps xmm0, [rsp]
00007d516e5e299f  vmovaps xmm1, [rsp+0x10]
00007d516e5e29a5  vmovaps xmm2, [rsp+0x20]
00007d516e5e29ab  vmovaps xmm3, [rsp+0x30]
00007d516e5e29b1  vmovaps xmm4, [rsp+0x40]
00007d516e5e29b7  vmovaps xmm5, [rsp+0x50]
00007d516e5e29bd  vmovaps xmm6, [rsp+0x60]
00007d516e5e29c3  vmovaps xmm7, [rsp+0x70]
00007d516e5e29c9  vmovaps xmm8, [rsp+0x80]
00007d516e5e29d2  vmovaps xmm9, [rsp+0x90]
00007d516e5e29db  vmovaps xmm10, [rsp+0xA0]
00007d516e5e29e4  vmovaps xmm11, [rsp+0xB0]
00007d516e5e29ed  vmovaps xmm12, [rsp+0xC0]
00007d516e5e29f6  vmovaps xmm13, [rsp+0xD0]
00007d516e5e29ff  vmovaps xmm15, [rsp+0xE0]
00007d516e5e2a08  add rsp, 0xF0
00007d516e5e2a0f  pop r11
00007d516e5e2a11  pop r10
00007d516e5e2a13  pop r9
00007d516e5e2a15  pop r8
00007d516e5e2a17  pop rsi
00007d516e5e2a18  pop rdi
00007d516e5e2a19  pop rdx
00007d516e5e2a1a  pop rcx
00007d516e5e2a1b  pop rax
00007d516e5e2a1c  add rsp, 0x08
00007d516e5e2a20  jmp 0x00007D516E5DF5F8
00007d516e5e2a25  sub rsp, 0x08
00007d516e5e2a29  push rax
00007d516e5e2a2a  push rcx
00007d516e5e2a2b  push rdx
00007d516e5e2a2c  push rdi
00007d516e5e2a2d  push rsi
00007d516e5e2a2e  push r8
00007d516e5e2a30  push r9
00007d516e5e2a32  push r10
00007d516e5e2a34  push r11
00007d516e5e2a36  sub rsp, 0xF0
00007d516e5e2a3d  vmovaps [rsp], xmm0
00007d516e5e2a42  vmovaps [rsp+0x10], xmm1
00007d516e5e2a48  vmovaps [rsp+0x20], xmm2
00007d516e5e2a4e  vmovaps [rsp+0x30], xmm3
00007d516e5e2a54  vmovaps [rsp+0x40], xmm5
00007d516e5e2a5a  vmovaps [rsp+0x50], xmm6
00007d516e5e2a60  vmovaps [rsp+0x60], xmm7
00007d516e5e2a66  vmovaps [rsp+0x70], xmm8
00007d516e5e2a6c  vmovaps [rsp+0x80], xmm9
00007d516e5e2a75  vmovaps [rsp+0x90], xmm10
00007d516e5e2a7e  vmovaps [rsp+0xA0], xmm11
00007d516e5e2a87  vmovaps [rsp+0xB0], xmm12
00007d516e5e2a90  vmovaps [rsp+0xC0], xmm13
00007d516e5e2a99  vmovaps [rsp+0xD0], xmm14
00007d516e5e2aa2  vmovaps [rsp+0xE0], xmm15
00007d516e5e2aab  sub rsp, 0x30
00007d516e5e2aaf  movaps [rsp], xmm4
00007d516e5e2ab3  movaps [rsp+0x10], xmm13
00007d516e5e2ab9  movaps [rsp+0x20], xmm8
00007d516e5e2abf  lea rdi, [rsp]
00007d516e5e2ac3  mov esi, 0x00
00007d516e5e2ac8  mov rax, 0x5EE43AF14530
00007d516e5e2ad2  call rax
00007d516e5e2ad4  movaps xmm4, [rsp]
00007d516e5e2ad8  add rsp, 0x30
00007d516e5e2adc  vmovaps xmm0, [rsp]
00007d516e5e2ae1  vmovaps xmm1, [rsp+0x10]
00007d516e5e2ae7  vmovaps xmm2, [rsp+0x20]
00007d516e5e2aed  vmovaps xmm3, [rsp+0x30]
00007d516e5e2af3  vmovaps xmm5, [rsp+0x40]
00007d516e5e2af9  vmovaps xmm6, [rsp+0x50]
00007d516e5e2aff  vmovaps xmm7, [rsp+0x60]
00007d516e5e2b05  vmovaps xmm8, [rsp+0x70]
00007d516e5e2b0b  vmovaps xmm9, [rsp+0x80]
00007d516e5e2b14  vmovaps xmm10, [rsp+0x90]
00007d516e5e2b1d  vmovaps xmm11, [rsp+0xA0]
00007d516e5e2b26  vmovaps xmm12, [rsp+0xB0]
00007d516e5e2b2f  vmovaps xmm13, [rsp+0xC0]
00007d516e5e2b38  vmovaps xmm14, [rsp+0xD0]
00007d516e5e2b41  vmovaps xmm15, [rsp+0xE0]
00007d516e5e2b4a  add rsp, 0xF0
00007d516e5e2b51  pop r11
00007d516e5e2b53  pop r10
00007d516e5e2b55  pop r9
00007d516e5e2b57  pop r8
00007d516e5e2b59  pop rsi
00007d516e5e2b5a  pop rdi
00007d516e5e2b5b  pop rdx
00007d516e5e2b5c  pop rcx
00007d516e5e2b5d  pop rax
00007d516e5e2b5e  add rsp, 0x08
00007d516e5e2b62  jmp 0x00007D516E5DF61D
00007d516e5e2b67  sub rsp, 0x08
00007d516e5e2b6b  push rax
00007d516e5e2b6c  push rcx
00007d516e5e2b6d  push rdx
00007d516e5e2b6e  push rdi
00007d516e5e2b6f  push rsi
00007d516e5e2b70  push r8
00007d516e5e2b72  push r9
00007d516e5e2b74  push r10
00007d516e5e2b76  push r11
00007d516e5e2b78  sub rsp, 0xF0
00007d516e5e2b7f  vmovaps [rsp], xmm0
00007d516e5e2b84  vmovaps [rsp+0x10], xmm1
00007d516e5e2b8a  vmovaps [rsp+0x20], xmm2
00007d516e5e2b90  vmovaps [rsp+0x30], xmm3
00007d516e5e2b96  vmovaps [rsp+0x40], xmm4
00007d516e5e2b9c  vmovaps [rsp+0x50], xmm5
00007d516e5e2ba2  vmovaps [rsp+0x60], xmm6
00007d516e5e2ba8  vmovaps [rsp+0x70], xmm7
00007d516e5e2bae  vmovaps [rsp+0x80], xmm8
00007d516e5e2bb7  vmovaps [rsp+0x90], xmm9
00007d516e5e2bc0  vmovaps [rsp+0xA0], xmm10
00007d516e5e2bc9  vmovaps [rsp+0xB0], xmm11
00007d516e5e2bd2  vmovaps [rsp+0xC0], xmm12
00007d516e5e2bdb  vmovaps [rsp+0xD0], xmm14
00007d516e5e2be4  vmovaps [rsp+0xE0], xmm15
00007d516e5e2bed  sub rsp, 0x30
00007d516e5e2bf1  movaps [rsp], xmm13
00007d516e5e2bf6  movaps [rsp+0x10], xmm15
00007d516e5e2bfc  movaps [rsp+0x20], xmm9
00007d516e5e2c02  lea rdi, [rsp]
00007d516e5e2c06  mov esi, 0x00
00007d516e5e2c0b  mov rax, 0x5EE43AF14530
00007d516e5e2c15  call rax
00007d516e5e2c17  movaps xmm13, [rsp]
00007d516e5e2c1c  add rsp, 0x30
00007d516e5e2c20  vmovaps xmm0, [rsp]
00007d516e5e2c25  vmovaps xmm1, [rsp+0x10]
00007d516e5e2c2b  vmovaps xmm2, [rsp+0x20]
00007d516e5e2c31  vmovaps xmm3, [rsp+0x30]
00007d516e5e2c37  vmovaps xmm4, [rsp+0x40]
00007d516e5e2c3d  vmovaps xmm5, [rsp+0x50]
00007d516e5e2c43  vmovaps xmm6, [rsp+0x60]
00007d516e5e2c49  vmovaps xmm7, [rsp+0x70]
00007d516e5e2c4f  vmovaps xmm8, [rsp+0x80]
00007d516e5e2c58  vmovaps xmm9, [rsp+0x90]
00007d516e5e2c61  vmovaps xmm10, [rsp+0xA0]
00007d516e5e2c6a  vmovaps xmm11, [rsp+0xB0]
00007d516e5e2c73  vmovaps xmm12, [rsp+0xC0]
00007d516e5e2c7c  vmovaps xmm14, [rsp+0xD0]
00007d516e5e2c85  vmovaps xmm15, [rsp+0xE0]
00007d516e5e2c8e  add rsp, 0xF0
00007d516e5e2c95  pop r11
00007d516e5e2c97  pop r10
00007d516e5e2c99  pop r9
00007d516e5e2c9b  pop r8
00007d516e5e2c9d  pop rsi
00007d516e5e2c9e  pop rdi
00007d516e5e2c9f  pop rdx
00007d516e5e2ca0  pop rcx
00007d516e5e2ca1  pop rax
00007d516e5e2ca2  add rsp, 0x08
00007d516e5e2ca6  jmp 0x00007D516E5DF638
00007d516e5e2cab  sub rsp, 0x08
00007d516e5e2caf  push rax
00007d516e5e2cb0  push rcx
00007d516e5e2cb1  push rdx
00007d516e5e2cb2  push rdi
00007d516e5e2cb3  push rsi
00007d516e5e2cb4  push r8
00007d516e5e2cb6  push r9
00007d516e5e2cb8  push r10
00007d516e5e2cba  push r11
00007d516e5e2cbc  sub rsp, 0xF0
00007d516e5e2cc3  vmovaps [rsp], xmm0
00007d516e5e2cc8  vmovaps [rsp+0x10], xmm1
00007d516e5e2cce  vmovaps [rsp+0x20], xmm2
00007d516e5e2cd4  vmovaps [rsp+0x30], xmm3
00007d516e5e2cda  vmovaps [rsp+0x40], xmm4
00007d516e5e2ce0  vmovaps [rsp+0x50], xmm5
00007d516e5e2ce6  vmovaps [rsp+0x60], xmm6
00007d516e5e2cec  vmovaps [rsp+0x70], xmm7
00007d516e5e2cf2  vmovaps [rsp+0x80], xmm8
00007d516e5e2cfb  vmovaps [rsp+0x90], xmm9
00007d516e5e2d04  vmovaps [rsp+0xA0], xmm10
00007d516e5e2d0d  vmovaps [rsp+0xB0], xmm11
00007d516e5e2d16  vmovaps [rsp+0xC0], xmm12
00007d516e5e2d1f  vmovaps [rsp+0xD0], xmm13
00007d516e5e2d28  vmovaps [rsp+0xE0], xmm14
00007d516e5e2d31  sub rsp, 0x30
00007d516e5e2d35  movaps [rsp], xmm15
00007d516e5e2d3a  movaps [rsp+0x10], xmm1
00007d516e5e2d3f  movaps [rsp+0x20], xmm5
00007d516e5e2d44  lea rdi, [rsp]
00007d516e5e2d48  mov esi, 0x00
00007d516e5e2d4d  mov rax, 0x5EE43AF14530
00007d516e5e2d57  call rax
00007d516e5e2d59  movaps xmm15, [rsp]
00007d516e5e2d5e  add rsp, 0x30
00007d516e5e2d62  vmovaps xmm0, [rsp]
00007d516e5e2d67  vmovaps xmm1, [rsp+0x10]
00007d516e5e2d6d  vmovaps xmm2, [rsp+0x20]
00007d516e5e2d73  vmovaps xmm3, [rsp+0x30]
00007d516e5e2d79  vmovaps xmm4, [rsp+0x40]
00007d516e5e2d7f  vmovaps xmm5, [rsp+0x50]
00007d516e5e2d85  vmovaps xmm6, [rsp+0x60]
00007d516e5e2d8b  vmovaps xmm7, [rsp+0x70]
00007d516e5e2d91  vmovaps xmm8, [rsp+0x80]
00007d516e5e2d9a  vmovaps xmm9, [rsp+0x90]
00007d516e5e2da3  vmovaps xmm10, [rsp+0xA0]
00007d516e5e2dac  vmovaps xmm11, [rsp+0xB0]
00007d516e5e2db5  vmovaps xmm12, [rsp+0xC0]
00007d516e5e2dbe  vmovaps xmm13, [rsp+0xD0]
00007d516e5e2dc7  vmovaps xmm14, [rsp+0xE0]
00007d516e5e2dd0  add rsp, 0xF0
00007d516e5e2dd7  pop r11
00007d516e5e2dd9  pop r10
00007d516e5e2ddb  pop r9
00007d516e5e2ddd  pop r8
00007d516e5e2ddf  pop rsi
00007d516e5e2de0  pop rdi
00007d516e5e2de1  pop rdx
00007d516e5e2de2  pop rcx
00007d516e5e2de3  pop rax
00007d516e5e2de4  add rsp, 0x08
00007d516e5e2de8  jmp 0x00007D516E5DF653
00007d516e5e2ded  call 0x00007D516E4B52F0
00007d516e5e2df2  jmp 0x00007D516E5DF6AE
00007d516e5e2df7  sub rsp, 0x08
00007d516e5e2dfb  push rax
00007d516e5e2dfc  push rcx
00007d516e5e2dfd  push rdx
00007d516e5e2dfe  push rdi
00007d516e5e2dff  push rsi
00007d516e5e2e00  push r8
00007d516e5e2e02  push r9
00007d516e5e2e04  push r10
00007d516e5e2e06  push r11
00007d516e5e2e08  sub rsp, 0xF0
00007d516e5e2e0f  vmovaps [rsp], xmm0
00007d516e5e2e14  vmovaps [rsp+0x10], xmm1
00007d516e5e2e1a  vmovaps [rsp+0x20], xmm2
00007d516e5e2e20  vmovaps [rsp+0x30], xmm3
00007d516e5e2e26  vmovaps [rsp+0x40], xmm4
00007d516e5e2e2c  vmovaps [rsp+0x50], xmm5
00007d516e5e2e32  vmovaps [rsp+0x60], xmm6
00007d516e5e2e38  vmovaps [rsp+0x70], xmm7
00007d516e5e2e3e  vmovaps [rsp+0x80], xmm8
00007d516e5e2e47  vmovaps [rsp+0x90], xmm10
00007d516e5e2e50  vmovaps [rsp+0xA0], xmm11
00007d516e5e2e59  vmovaps [rsp+0xB0], xmm12
00007d516e5e2e62  vmovaps [rsp+0xC0], xmm13
00007d516e5e2e6b  vmovaps [rsp+0xD0], xmm14
00007d516e5e2e74  vmovaps [rsp+0xE0], xmm15
00007d516e5e2e7d  sub rsp, 0x30
00007d516e5e2e81  movaps [rsp], xmm9
00007d516e5e2e86  movaps [rsp+0x10], xmm8
00007d516e5e2e8c  movaps [rsp+0x20], xmm11
00007d516e5e2e92  lea rdi, [rsp]
00007d516e5e2e96  mov esi, 0x00
00007d516e5e2e9b  mov rax, 0x5EE43AF14530
00007d516e5e2ea5  call rax
00007d516e5e2ea7  movaps xmm9, [rsp]
00007d516e5e2eac  add rsp, 0x30
00007d516e5e2eb0  vmovaps xmm0, [rsp]
00007d516e5e2eb5  vmovaps xmm1, [rsp+0x10]
00007d516e5e2ebb  vmovaps xmm2, [rsp+0x20]
00007d516e5e2ec1  vmovaps xmm3, [rsp+0x30]
00007d516e5e2ec7  vmovaps xmm4, [rsp+0x40]
00007d516e5e2ecd  vmovaps xmm5, [rsp+0x50]
00007d516e5e2ed3  vmovaps xmm6, [rsp+0x60]
00007d516e5e2ed9  vmovaps xmm7, [rsp+0x70]
00007d516e5e2edf  vmovaps xmm8, [rsp+0x80]
00007d516e5e2ee8  vmovaps xmm10, [rsp+0x90]
00007d516e5e2ef1  vmovaps xmm11, [rsp+0xA0]
00007d516e5e2efa  vmovaps xmm12, [rsp+0xB0]
00007d516e5e2f03  vmovaps xmm13, [rsp+0xC0]
00007d516e5e2f0c  vmovaps xmm14, [rsp+0xD0]
00007d516e5e2f15  vmovaps xmm15, [rsp+0xE0]
00007d516e5e2f1e  add rsp, 0xF0
00007d516e5e2f25  pop r11
00007d516e5e2f27  pop r10
00007d516e5e2f29  pop r9
00007d516e5e2f2b  pop r8
00007d516e5e2f2d  pop rsi
00007d516e5e2f2e  pop rdi
00007d516e5e2f2f  pop rdx
00007d516e5e2f30  pop rcx
00007d516e5e2f31  pop rax
00007d516e5e2f32  add rsp, 0x08
00007d516e5e2f36  jmp 0x00007D516E5DF6E5
00007d516e5e2f3b  sub rsp, 0x08
00007d516e5e2f3f  push rax
00007d516e5e2f40  push rcx
00007d516e5e2f41  push rdx
00007d516e5e2f42  push rdi
00007d516e5e2f43  push rsi
00007d516e5e2f44  push r8
00007d516e5e2f46  push r9
00007d516e5e2f48  push r10
00007d516e5e2f4a  push r11
00007d516e5e2f4c  sub rsp, 0xF0
00007d516e5e2f53  vmovaps [rsp], xmm0
00007d516e5e2f58  vmovaps [rsp+0x10], xmm1
00007d516e5e2f5e  vmovaps [rsp+0x20], xmm2
00007d516e5e2f64  vmovaps [rsp+0x30], xmm3
00007d516e5e2f6a  vmovaps [rsp+0x40], xmm4
00007d516e5e2f70  vmovaps [rsp+0x50], xmm5
00007d516e5e2f76  vmovaps [rsp+0x60], xmm6
00007d516e5e2f7c  vmovaps [rsp+0x70], xmm7
00007d516e5e2f82  vmovaps [rsp+0x80], xmm8
00007d516e5e2f8b  vmovaps [rsp+0x90], xmm9
00007d516e5e2f94  vmovaps [rsp+0xA0], xmm10
00007d516e5e2f9d  vmovaps [rsp+0xB0], xmm12
00007d516e5e2fa6  vmovaps [rsp+0xC0], xmm13
00007d516e5e2faf  vmovaps [rsp+0xD0], xmm14
00007d516e5e2fb8  vmovaps [rsp+0xE0], xmm15
00007d516e5e2fc1  sub rsp, 0x30
00007d516e5e2fc5  movaps [rsp], xmm11
00007d516e5e2fca  movaps [rsp+0x10], xmm10
00007d516e5e2fd0  movaps [rsp+0x20], xmm6
00007d516e5e2fd5  lea rdi, [rsp]
00007d516e5e2fd9  mov esi, 0x00
00007d516e5e2fde  mov rax, 0x5EE43AF14530
00007d516e5e2fe8  call rax
00007d516e5e2fea  movaps xmm11, [rsp]
00007d516e5e2fef  add rsp, 0x30
00007d516e5e2ff3  vmovaps xmm0, [rsp]
00007d516e5e2ff8  vmovaps xmm1, [rsp+0x10]
00007d516e5e2ffe  vmovaps xmm2, [rsp+0x20]
00007d516e5e3004  vmovaps xmm3, [rsp+0x30]
00007d516e5e300a  vmovaps xmm4, [rsp+0x40]
00007d516e5e3010  vmovaps xmm5, [rsp+0x50]
00007d516e5e3016  vmovaps xmm6, [rsp+0x60]
00007d516e5e301c  vmovaps xmm7, [rsp+0x70]
00007d516e5e3022  vmovaps xmm8, [rsp+0x80]
00007d516e5e302b  vmovaps xmm9, [rsp+0x90]
00007d516e5e3034  vmovaps xmm10, [rsp+0xA0]
00007d516e5e303d  vmovaps xmm12, [rsp+0xB0]
00007d516e5e3046  vmovaps xmm13, [rsp+0xC0]
00007d516e5e304f  vmovaps xmm14, [rsp+0xD0]
00007d516e5e3058  vmovaps xmm15, [rsp+0xE0]
00007d516e5e3061  add rsp, 0xF0
00007d516e5e3068  pop r11
00007d516e5e306a  pop r10
00007d516e5e306c  pop r9
00007d516e5e306e  pop r8
00007d516e5e3070  pop rsi
00007d516e5e3071  pop rdi
00007d516e5e3072  pop rdx
00007d516e5e3073  pop rcx
00007d516e5e3074  pop rax
00007d516e5e3075  add rsp, 0x08
00007d516e5e3079  jmp 0x00007D516E5DF700
00007d516e5e307e  sub rsp, 0x08
00007d516e5e3082  push rax
00007d516e5e3083  push rcx
00007d516e5e3084  push rdx
00007d516e5e3085  push rdi
00007d516e5e3086  push rsi
00007d516e5e3087  push r8
00007d516e5e3089  push r9
00007d516e5e308b  push r10
00007d516e5e308d  push r11
00007d516e5e308f  sub rsp, 0xF0
00007d516e5e3096  vmovaps [rsp], xmm0
00007d516e5e309b  vmovaps [rsp+0x10], xmm1
00007d516e5e30a1  vmovaps [rsp+0x20], xmm2
00007d516e5e30a7  vmovaps [rsp+0x30], xmm3
00007d516e5e30ad  vmovaps [rsp+0x40], xmm4
00007d516e5e30b3  vmovaps [rsp+0x50], xmm5
00007d516e5e30b9  vmovaps [rsp+0x60], xmm6
00007d516e5e30bf  vmovaps [rsp+0x70], xmm7
00007d516e5e30c5  vmovaps [rsp+0x80], xmm8
00007d516e5e30ce  vmovaps [rsp+0x90], xmm9
00007d516e5e30d7  vmovaps [rsp+0xA0], xmm11
00007d516e5e30e0  vmovaps [rsp+0xB0], xmm12
00007d516e5e30e9  vmovaps [rsp+0xC0], xmm13
00007d516e5e30f2  vmovaps [rsp+0xD0], xmm14
00007d516e5e30fb  vmovaps [rsp+0xE0], xmm15
00007d516e5e3104  sub rsp, 0x30
00007d516e5e3108  movaps [rsp], xmm10
00007d516e5e310d  movaps [rsp+0x10], xmm14
00007d516e5e3113  movaps [rsp+0x20], xmm4
00007d516e5e3118  lea rdi, [rsp]
00007d516e5e311c  mov esi, 0x00
00007d516e5e3121  mov rax, 0x5EE43AF14530
00007d516e5e312b  call rax
00007d516e5e312d  movaps xmm10, [rsp]
00007d516e5e3132  add rsp, 0x30
00007d516e5e3136  vmovaps xmm0, [rsp]
00007d516e5e313b  vmovaps xmm1, [rsp+0x10]
00007d516e5e3141  vmovaps xmm2, [rsp+0x20]
00007d516e5e3147  vmovaps xmm3, [rsp+0x30]
00007d516e5e314d  vmovaps xmm4, [rsp+0x40]
00007d516e5e3153  vmovaps xmm5, [rsp+0x50]
00007d516e5e3159  vmovaps xmm6, [rsp+0x60]
00007d516e5e315f  vmovaps xmm7, [rsp+0x70]
00007d516e5e3165  vmovaps xmm8, [rsp+0x80]
00007d516e5e316e  vmovaps xmm9, [rsp+0x90]
00007d516e5e3177  vmovaps xmm11, [rsp+0xA0]
00007d516e5e3180  vmovaps xmm12, [rsp+0xB0]
00007d516e5e3189  vmovaps xmm13, [rsp+0xC0]
00007d516e5e3192  vmovaps xmm14, [rsp+0xD0]
00007d516e5e319b  vmovaps xmm15, [rsp+0xE0]
00007d516e5e31a4  add rsp, 0xF0
00007d516e5e31ab  pop r11
00007d516e5e31ad  pop r10
00007d516e5e31af  pop r9
00007d516e5e31b1  pop r8
00007d516e5e31b3  pop rsi
00007d516e5e31b4  pop rdi
00007d516e5e31b5  pop rdx
00007d516e5e31b6  pop rcx
00007d516e5e31b7  pop rax
00007d516e5e31b8  add rsp, 0x08
00007d516e5e31bc  jmp 0x00007D516E5DF71B
00007d516e5e31c1  sub rsp, 0x08
00007d516e5e31c5  push rax
00007d516e5e31c6  push rcx
00007d516e5e31c7  push rdx
00007d516e5e31c8  push rdi
00007d516e5e31c9  push rsi
00007d516e5e31ca  push r8
00007d516e5e31cc  push r9
00007d516e5e31ce  push r10
00007d516e5e31d0  push r11
00007d516e5e31d2  sub rsp, 0xF0
00007d516e5e31d9  vmovaps [rsp], xmm0
00007d516e5e31de  vmovaps [rsp+0x10], xmm1
00007d516e5e31e4  vmovaps [rsp+0x20], xmm2
00007d516e5e31ea  vmovaps [rsp+0x30], xmm3
00007d516e5e31f0  vmovaps [rsp+0x40], xmm4
00007d516e5e31f6  vmovaps [rsp+0x50], xmm5
00007d516e5e31fc  vmovaps [rsp+0x60], xmm6
00007d516e5e3202  vmovaps [rsp+0x70], xmm7
00007d516e5e3208  vmovaps [rsp+0x80], xmm9
00007d516e5e3211  vmovaps [rsp+0x90], xmm10
00007d516e5e321a  vmovaps [rsp+0xA0], xmm11
00007d516e5e3223  vmovaps [rsp+0xB0], xmm12
00007d516e5e322c  vmovaps [rsp+0xC0], xmm13
00007d516e5e3235  vmovaps [rsp+0xD0], xmm14
00007d516e5e323e  vmovaps [rsp+0xE0], xmm15
00007d516e5e3247  sub rsp, 0x30
00007d516e5e324b  movaps [rsp], xmm8
00007d516e5e3250  movaps [rsp+0x10], xmm1
00007d516e5e3255  movaps [rsp+0x20], xmm14
00007d516e5e325b  lea rdi, [rsp]
00007d516e5e325f  mov esi, 0x00
00007d516e5e3264  mov rax, 0x5EE43AF14530
00007d516e5e326e  call rax
00007d516e5e3270  movaps xmm8, [rsp]
00007d516e5e3275  add rsp, 0x30
00007d516e5e3279  vmovaps xmm0, [rsp]
00007d516e5e327e  vmovaps xmm1, [rsp+0x10]
00007d516e5e3284  vmovaps xmm2, [rsp+0x20]
00007d516e5e328a  vmovaps xmm3, [rsp+0x30]
00007d516e5e3290  vmovaps xmm4, [rsp+0x40]
00007d516e5e3296  vmovaps xmm5, [rsp+0x50]
00007d516e5e329c  vmovaps xmm6, [rsp+0x60]
00007d516e5e32a2  vmovaps xmm7, [rsp+0x70]
00007d516e5e32a8  vmovaps xmm9, [rsp+0x80]
00007d516e5e32b1  vmovaps xmm10, [rsp+0x90]
00007d516e5e32ba  vmovaps xmm11, [rsp+0xA0]
00007d516e5e32c3  vmovaps xmm12, [rsp+0xB0]
00007d516e5e32cc  vmovaps xmm13, [rsp+0xC0]
00007d516e5e32d5  vmovaps xmm14, [rsp+0xD0]
00007d516e5e32de  vmovaps xmm15, [rsp+0xE0]
00007d516e5e32e7  add rsp, 0xF0
00007d516e5e32ee  pop r11
00007d516e5e32f0  pop r10
00007d516e5e32f2  pop r9
00007d516e5e32f4  pop r8
00007d516e5e32f6  pop rsi
00007d516e5e32f7  pop rdi
00007d516e5e32f8  pop rdx
00007d516e5e32f9  pop rcx
00007d516e5e32fa  pop rax
00007d516e5e32fb  add rsp, 0x08
00007d516e5e32ff  jmp 0x00007D516E5DF741
00007d516e5e3304  sub rsp, 0x08
00007d516e5e3308  push rax
00007d516e5e3309  push rcx
00007d516e5e330a  push rdx
00007d516e5e330b  push rdi
00007d516e5e330c  push rsi
00007d516e5e330d  push r8
00007d516e5e330f  push r9
00007d516e5e3311  push r10
00007d516e5e3313  push r11
00007d516e5e3315  sub rsp, 0xF0
00007d516e5e331c  vmovaps [rsp], xmm0
00007d516e5e3321  vmovaps [rsp+0x10], xmm1
00007d516e5e3327  vmovaps [rsp+0x20], xmm2
00007d516e5e332d  vmovaps [rsp+0x30], xmm3
00007d516e5e3333  vmovaps [rsp+0x40], xmm4
00007d516e5e3339  vmovaps [rsp+0x50], xmm5
00007d516e5e333f  vmovaps [rsp+0x60], xmm7
00007d516e5e3345  vmovaps [rsp+0x70], xmm8
00007d516e5e334b  vmovaps [rsp+0x80], xmm9
00007d516e5e3354  vmovaps [rsp+0x90], xmm10
00007d516e5e335d  vmovaps [rsp+0xA0], xmm11
00007d516e5e3366  vmovaps [rsp+0xB0], xmm12
00007d516e5e336f  vmovaps [rsp+0xC0], xmm13
00007d516e5e3378  vmovaps [rsp+0xD0], xmm14
00007d516e5e3381  vmovaps [rsp+0xE0], xmm15
00007d516e5e338a  sub rsp, 0x30
00007d516e5e338e  movaps [rsp], xmm6
00007d516e5e3392  movaps [rsp+0x10], xmm1
00007d516e5e3397  movaps [rsp+0x20], xmm14
00007d516e5e339d  lea rdi, [rsp]
00007d516e5e33a1  mov esi, 0x00
00007d516e5e33a6  mov rax, 0x5EE43AF14530
00007d516e5e33b0  call rax
00007d516e5e33b2  movaps xmm6, [rsp]
00007d516e5e33b6  add rsp, 0x30
00007d516e5e33ba  vmovaps xmm0, [rsp]
00007d516e5e33bf  vmovaps xmm1, [rsp+0x10]
00007d516e5e33c5  vmovaps xmm2, [rsp+0x20]
00007d516e5e33cb  vmovaps xmm3, [rsp+0x30]
00007d516e5e33d1  vmovaps xmm4, [rsp+0x40]
00007d516e5e33d7  vmovaps xmm5, [rsp+0x50]
00007d516e5e33dd  vmovaps xmm7, [rsp+0x60]
00007d516e5e33e3  vmovaps xmm8, [rsp+0x70]
00007d516e5e33e9  vmovaps xmm9, [rsp+0x80]
00007d516e5e33f2  vmovaps xmm10, [rsp+0x90]
00007d516e5e33fb  vmovaps xmm11, [rsp+0xA0]
00007d516e5e3404  vmovaps xmm12, [rsp+0xB0]
00007d516e5e340d  vmovaps xmm13, [rsp+0xC0]
00007d516e5e3416  vmovaps xmm14, [rsp+0xD0]
00007d516e5e341f  vmovaps xmm15, [rsp+0xE0]
00007d516e5e3428  add rsp, 0xF0
00007d516e5e342f  pop r11
00007d516e5e3431  pop r10
00007d516e5e3433  pop r9
00007d516e5e3435  pop r8
00007d516e5e3437  pop rsi
00007d516e5e3438  pop rdi
00007d516e5e3439  pop rdx
00007d516e5e343a  pop rcx
00007d516e5e343b  pop rax
00007d516e5e343c  add rsp, 0x08
00007d516e5e3440  jmp 0x00007D516E5DF76D
00007d516e5e3445  sub rsp, 0x08
00007d516e5e3449  push rax
00007d516e5e344a  push rcx
00007d516e5e344b  push rdx
00007d516e5e344c  push rdi
00007d516e5e344d  push rsi
00007d516e5e344e  push r8
00007d516e5e3450  push r9
00007d516e5e3452  push r10
00007d516e5e3454  push r11
00007d516e5e3456  sub rsp, 0xF0
00007d516e5e345d  vmovaps [rsp], xmm0
00007d516e5e3462  vmovaps [rsp+0x10], xmm1
00007d516e5e3468  vmovaps [rsp+0x20], xmm2
00007d516e5e346e  vmovaps [rsp+0x30], xmm3
00007d516e5e3474  vmovaps [rsp+0x40], xmm4
00007d516e5e347a  vmovaps [rsp+0x50], xmm5
00007d516e5e3480  vmovaps [rsp+0x60], xmm6
00007d516e5e3486  vmovaps [rsp+0x70], xmm7
00007d516e5e348c  vmovaps [rsp+0x80], xmm8
00007d516e5e3495  vmovaps [rsp+0x90], xmm9
00007d516e5e349e  vmovaps [rsp+0xA0], xmm10
00007d516e5e34a7  vmovaps [rsp+0xB0], xmm11
00007d516e5e34b0  vmovaps [rsp+0xC0], xmm12
00007d516e5e34b9  vmovaps [rsp+0xD0], xmm13
00007d516e5e34c2  vmovaps [rsp+0xE0], xmm15
00007d516e5e34cb  sub rsp, 0x30
00007d516e5e34cf  movaps [rsp], xmm14
00007d516e5e34d4  movaps [rsp+0x10], xmm12
00007d516e5e34da  movaps [rsp+0x20], xmm1
00007d516e5e34df  lea rdi, [rsp]
00007d516e5e34e3  mov esi, 0x00
00007d516e5e34e8  mov rax, 0x5EE43AF14530
00007d516e5e34f2  call rax
00007d516e5e34f4  movaps xmm14, [rsp]
00007d516e5e34f9  add rsp, 0x30
00007d516e5e34fd  vmovaps xmm0, [rsp]
00007d516e5e3502  vmovaps xmm1, [rsp+0x10]
00007d516e5e3508  vmovaps xmm2, [rsp+0x20]
00007d516e5e350e  vmovaps xmm3, [rsp+0x30]
00007d516e5e3514  vmovaps xmm4, [rsp+0x40]
00007d516e5e351a  vmovaps xmm5, [rsp+0x50]
00007d516e5e3520  vmovaps xmm6, [rsp+0x60]
00007d516e5e3526  vmovaps xmm7, [rsp+0x70]
00007d516e5e352c  vmovaps xmm8, [rsp+0x80]
00007d516e5e3535  vmovaps xmm9, [rsp+0x90]
00007d516e5e353e  vmovaps xmm10, [rsp+0xA0]
00007d516e5e3547  vmovaps xmm11, [rsp+0xB0]
00007d516e5e3550  vmovaps xmm12, [rsp+0xC0]
00007d516e5e3559  vmovaps xmm13, [rsp+0xD0]
00007d516e5e3562  vmovaps xmm15, [rsp+0xE0]
00007d516e5e356b  add rsp, 0xF0
00007d516e5e3572  pop r11
00007d516e5e3574  pop r10
00007d516e5e3576  pop r9
00007d516e5e3578  pop r8
00007d516e5e357a  pop rsi
00007d516e5e357b  pop rdi
00007d516e5e357c  pop rdx
00007d516e5e357d  pop rcx
00007d516e5e357e  pop rax
00007d516e5e357f  add rsp, 0x08
00007d516e5e3583  jmp 0x00007D516E5DF793
00007d516e5e3588  sub rsp, 0x08
00007d516e5e358c  push rax
00007d516e5e358d  push rcx
00007d516e5e358e  push rdx
00007d516e5e358f  push rdi
00007d516e5e3590  push rsi
00007d516e5e3591  push r8
00007d516e5e3593  push r9
00007d516e5e3595  push r10
00007d516e5e3597  push r11
00007d516e5e3599  sub rsp, 0xF0
00007d516e5e35a0  vmovaps [rsp], xmm0
00007d516e5e35a5  vmovaps [rsp+0x10], xmm2
00007d516e5e35ab  vmovaps [rsp+0x20], xmm3
00007d516e5e35b1  vmovaps [rsp+0x30], xmm4
00007d516e5e35b7  vmovaps [rsp+0x40], xmm5
00007d516e5e35bd  vmovaps [rsp+0x50], xmm6
00007d516e5e35c3  vmovaps [rsp+0x60], xmm7
00007d516e5e35c9  vmovaps [rsp+0x70], xmm8
00007d516e5e35cf  vmovaps [rsp+0x80], xmm9
00007d516e5e35d8  vmovaps [rsp+0x90], xmm10
00007d516e5e35e1  vmovaps [rsp+0xA0], xmm11
00007d516e5e35ea  vmovaps [rsp+0xB0], xmm12
00007d516e5e35f3  vmovaps [rsp+0xC0], xmm13
00007d516e5e35fc  vmovaps [rsp+0xD0], xmm14
00007d516e5e3605  vmovaps [rsp+0xE0], xmm15
00007d516e5e360e  sub rsp, 0x30
00007d516e5e3612  movaps [rsp], xmm1
00007d516e5e3616  movaps [rsp+0x10], xmm13
00007d516e5e361c  movaps [rsp+0x20], xmm9
00007d516e5e3622  lea rdi, [rsp]
00007d516e5e3626  mov esi, 0x00
00007d516e5e362b  mov rax, 0x5EE43AF14530
00007d516e5e3635  call rax
00007d516e5e3637  movaps xmm1, [rsp]
00007d516e5e363b  add rsp, 0x30
00007d516e5e363f  vmovaps xmm0, [rsp]
00007d516e5e3644  vmovaps xmm2, [rsp+0x10]
00007d516e5e364a  vmovaps xmm3, [rsp+0x20]
00007d516e5e3650  vmovaps xmm4, [rsp+0x30]
00007d516e5e3656  vmovaps xmm5, [rsp+0x40]
00007d516e5e365c  vmovaps xmm6, [rsp+0x50]
00007d516e5e3662  vmovaps xmm7, [rsp+0x60]
00007d516e5e3668  vmovaps xmm8, [rsp+0x70]
00007d516e5e366e  vmovaps xmm9, [rsp+0x80]
00007d516e5e3677  vmovaps xmm10, [rsp+0x90]
00007d516e5e3680  vmovaps xmm11, [rsp+0xA0]
00007d516e5e3689  vmovaps xmm12, [rsp+0xB0]
00007d516e5e3692  vmovaps xmm13, [rsp+0xC0]
00007d516e5e369b  vmovaps xmm14, [rsp+0xD0]
00007d516e5e36a4  vmovaps xmm15, [rsp+0xE0]
00007d516e5e36ad  add rsp, 0xF0
00007d516e5e36b4  pop r11
00007d516e5e36b6  pop r10
00007d516e5e36b8  pop r9
00007d516e5e36ba  pop r8
00007d516e5e36bc  pop rsi
00007d516e5e36bd  pop rdi
00007d516e5e36be  pop rdx
00007d516e5e36bf  pop rcx
00007d516e5e36c0  pop rax
00007d516e5e36c1  add rsp, 0x08
00007d516e5e36c5  jmp 0x00007D516E5DF7AD
00007d516e5e36ca  sub rsp, 0x08
00007d516e5e36ce  push rax
00007d516e5e36cf  push rcx
00007d516e5e36d0  push rdx
00007d516e5e36d1  push rdi
00007d516e5e36d2  push rsi
00007d516e5e36d3  push r8
00007d516e5e36d5  push r9
00007d516e5e36d7  push r10
00007d516e5e36d9  push r11
00007d516e5e36db  sub rsp, 0xF0
00007d516e5e36e2  vmovaps [rsp], xmm0
00007d516e5e36e7  vmovaps [rsp+0x10], xmm1
00007d516e5e36ed  vmovaps [rsp+0x20], xmm2
00007d516e5e36f3  vmovaps [rsp+0x30], xmm3
00007d516e5e36f9  vmovaps [rsp+0x40], xmm4
00007d516e5e36ff  vmovaps [rsp+0x50], xmm5
00007d516e5e3705  vmovaps [rsp+0x60], xmm6
00007d516e5e370b  vmovaps [rsp+0x70], xmm7
00007d516e5e3711  vmovaps [rsp+0x80], xmm8
00007d516e5e371a  vmovaps [rsp+0x90], xmm9
00007d516e5e3723  vmovaps [rsp+0xA0], xmm10
00007d516e5e372c  vmovaps [rsp+0xB0], xmm11
00007d516e5e3735  vmovaps [rsp+0xC0], xmm13
00007d516e5e373e  vmovaps [rsp+0xD0], xmm14
00007d516e5e3747  vmovaps [rsp+0xE0], xmm15
00007d516e5e3750  sub rsp, 0x30
00007d516e5e3754  movaps [rsp], xmm12
00007d516e5e3759  movaps [rsp+0x10], xmm7
00007d516e5e375e  movaps [rsp+0x20], xmm13
00007d516e5e3764  lea rdi, [rsp]
00007d516e5e3768  mov esi, 0x00
00007d516e5e376d  mov rax, 0x5EE43AF14530
00007d516e5e3777  call rax
00007d516e5e3779  movaps xmm12, [rsp]
00007d516e5e377e  add rsp, 0x30
00007d516e5e3782  vmovaps xmm0, [rsp]
00007d516e5e3787  vmovaps xmm1, [rsp+0x10]
00007d516e5e378d  vmovaps xmm2, [rsp+0x20]
00007d516e5e3793  vmovaps xmm3, [rsp+0x30]
00007d516e5e3799  vmovaps xmm4, [rsp+0x40]
00007d516e5e379f  vmovaps xmm5, [rsp+0x50]
00007d516e5e37a5  vmovaps xmm6, [rsp+0x60]
00007d516e5e37ab  vmovaps xmm7, [rsp+0x70]
00007d516e5e37b1  vmovaps xmm8, [rsp+0x80]
00007d516e5e37ba  vmovaps xmm9, [rsp+0x90]
00007d516e5e37c3  vmovaps xmm10, [rsp+0xA0]
00007d516e5e37cc  vmovaps xmm11, [rsp+0xB0]
00007d516e5e37d5  vmovaps xmm13, [rsp+0xC0]
00007d516e5e37de  vmovaps xmm14, [rsp+0xD0]
00007d516e5e37e7  vmovaps xmm15, [rsp+0xE0]
00007d516e5e37f0  add rsp, 0xF0
00007d516e5e37f7  pop r11
00007d516e5e37f9  pop r10
00007d516e5e37fb  pop r9
00007d516e5e37fd  pop r8
00007d516e5e37ff  pop rsi
00007d516e5e3800  pop rdi
00007d516e5e3801  pop rdx
00007d516e5e3802  pop rcx
00007d516e5e3803  pop rax
00007d516e5e3804  add rsp, 0x08
00007d516e5e3808  jmp 0x00007D516E5DF7D4
00007d516e5e380d  sub rsp, 0x08
00007d516e5e3811  push rax
00007d516e5e3812  push rcx
00007d516e5e3813  push rdx
00007d516e5e3814  push rdi
00007d516e5e3815  push rsi
00007d516e5e3816  push r8
00007d516e5e3818  push r9
00007d516e5e381a  push r10
00007d516e5e381c  push r11
00007d516e5e381e  sub rsp, 0xF0
00007d516e5e3825  vmovaps [rsp], xmm0
00007d516e5e382a  vmovaps [rsp+0x10], xmm1
00007d516e5e3830  vmovaps [rsp+0x20], xmm2
00007d516e5e3836  vmovaps [rsp+0x30], xmm3
00007d516e5e383c  vmovaps [rsp+0x40], xmm4
00007d516e5e3842  vmovaps [rsp+0x50], xmm5
00007d516e5e3848  vmovaps [rsp+0x60], xmm6
00007d516e5e384e  vmovaps [rsp+0x70], xmm7
00007d516e5e3854  vmovaps [rsp+0x80], xmm8
00007d516e5e385d  vmovaps [rsp+0x90], xmm9
00007d516e5e3866  vmovaps [rsp+0xA0], xmm10
00007d516e5e386f  vmovaps [rsp+0xB0], xmm11
00007d516e5e3878  vmovaps [rsp+0xC0], xmm12
00007d516e5e3881  vmovaps [rsp+0xD0], xmm14
00007d516e5e388a  vmovaps [rsp+0xE0], xmm15
00007d516e5e3893  sub rsp, 0x30
00007d516e5e3897  movaps [rsp], xmm13
00007d516e5e389c  movaps [rsp+0x10], xmm15
00007d516e5e38a2  movaps [rsp+0x20], xmm8
00007d516e5e38a8  lea rdi, [rsp]
00007d516e5e38ac  mov esi, 0x00
00007d516e5e38b1  mov rax, 0x5EE43AF14530
00007d516e5e38bb  call rax
00007d516e5e38bd  movaps xmm13, [rsp]
00007d516e5e38c2  add rsp, 0x30
00007d516e5e38c6  vmovaps xmm0, [rsp]
00007d516e5e38cb  vmovaps xmm1, [rsp+0x10]
00007d516e5e38d1  vmovaps xmm2, [rsp+0x20]
00007d516e5e38d7  vmovaps xmm3, [rsp+0x30]
00007d516e5e38dd  vmovaps xmm4, [rsp+0x40]
00007d516e5e38e3  vmovaps xmm5, [rsp+0x50]
00007d516e5e38e9  vmovaps xmm6, [rsp+0x60]
00007d516e5e38ef  vmovaps xmm7, [rsp+0x70]
00007d516e5e38f5  vmovaps xmm8, [rsp+0x80]
00007d516e5e38fe  vmovaps xmm9, [rsp+0x90]
00007d516e5e3907  vmovaps xmm10, [rsp+0xA0]
00007d516e5e3910  vmovaps xmm11, [rsp+0xB0]
00007d516e5e3919  vmovaps xmm12, [rsp+0xC0]
00007d516e5e3922  vmovaps xmm14, [rsp+0xD0]
00007d516e5e392b  vmovaps xmm15, [rsp+0xE0]
00007d516e5e3934  add rsp, 0xF0
00007d516e5e393b  pop r11
00007d516e5e393d  pop r10
00007d516e5e393f  pop r9
00007d516e5e3941  pop r8
00007d516e5e3943  pop rsi
00007d516e5e3944  pop rdi
00007d516e5e3945  pop rdx
00007d516e5e3946  pop rcx
00007d516e5e3947  pop rax
00007d516e5e3948  add rsp, 0x08
00007d516e5e394c  jmp 0x00007D516E5DF7EF
00007d516e5e3951  sub rsp, 0x08
00007d516e5e3955  push rax
00007d516e5e3956  push rcx
00007d516e5e3957  push rdx
00007d516e5e3958  push rdi
00007d516e5e3959  push rsi
00007d516e5e395a  push r8
00007d516e5e395c  push r9
00007d516e5e395e  push r10
00007d516e5e3960  push r11
00007d516e5e3962  sub rsp, 0xF0
00007d516e5e3969  vmovaps [rsp], xmm0
00007d516e5e396e  vmovaps [rsp+0x10], xmm1
00007d516e5e3974  vmovaps [rsp+0x20], xmm2
00007d516e5e397a  vmovaps [rsp+0x30], xmm3
00007d516e5e3980  vmovaps [rsp+0x40], xmm4
00007d516e5e3986  vmovaps [rsp+0x50], xmm5
00007d516e5e398c  vmovaps [rsp+0x60], xmm6
00007d516e5e3992  vmovaps [rsp+0x70], xmm7
00007d516e5e3998  vmovaps [rsp+0x80], xmm9
00007d516e5e39a1  vmovaps [rsp+0x90], xmm10
00007d516e5e39aa  vmovaps [rsp+0xA0], xmm11
00007d516e5e39b3  vmovaps [rsp+0xB0], xmm12
00007d516e5e39bc  vmovaps [rsp+0xC0], xmm13
00007d516e5e39c5  vmovaps [rsp+0xD0], xmm14
00007d516e5e39ce  vmovaps [rsp+0xE0], xmm15
00007d516e5e39d7  sub rsp, 0x30
00007d516e5e39db  movaps [rsp], xmm8
00007d516e5e39e0  movaps [rsp+0x10], xmm15
00007d516e5e39e6  movaps [rsp+0x20], xmm9
00007d516e5e39ec  lea rdi, [rsp]
00007d516e5e39f0  mov esi, 0x00
00007d516e5e39f5  mov rax, 0x5EE43AF14530
00007d516e5e39ff  call rax
00007d516e5e3a01  movaps xmm8, [rsp]
00007d516e5e3a06  add rsp, 0x30
00007d516e5e3a0a  vmovaps xmm0, [rsp]
00007d516e5e3a0f  vmovaps xmm1, [rsp+0x10]
00007d516e5e3a15  vmovaps xmm2, [rsp+0x20]
00007d516e5e3a1b  vmovaps xmm3, [rsp+0x30]
00007d516e5e3a21  vmovaps xmm4, [rsp+0x40]
00007d516e5e3a27  vmovaps xmm5, [rsp+0x50]
00007d516e5e3a2d  vmovaps xmm6, [rsp+0x60]
00007d516e5e3a33  vmovaps xmm7, [rsp+0x70]
00007d516e5e3a39  vmovaps xmm9, [rsp+0x80]
00007d516e5e3a42  vmovaps xmm10, [rsp+0x90]
00007d516e5e3a4b  vmovaps xmm11, [rsp+0xA0]
00007d516e5e3a54  vmovaps xmm12, [rsp+0xB0]
00007d516e5e3a5d  vmovaps xmm13, [rsp+0xC0]
00007d516e5e3a66  vmovaps xmm14, [rsp+0xD0]
00007d516e5e3a6f  vmovaps xmm15, [rsp+0xE0]
00007d516e5e3a78  add rsp, 0xF0
00007d516e5e3a7f  pop r11
00007d516e5e3a81  pop r10
00007d516e5e3a83  pop r9
00007d516e5e3a85  pop r8
00007d516e5e3a87  pop rsi
00007d516e5e3a88  pop rdi
00007d516e5e3a89  pop rdx
00007d516e5e3a8a  pop rcx
00007d516e5e3a8b  pop rax
00007d516e5e3a8c  add rsp, 0x08
00007d516e5e3a90  jmp 0x00007D516E5DF81D
00007d516e5e3a95  sub rsp, 0x08
00007d516e5e3a99  push rax
00007d516e5e3a9a  push rcx
00007d516e5e3a9b  push rdx
00007d516e5e3a9c  push rdi
00007d516e5e3a9d  push rsi
00007d516e5e3a9e  push r8
00007d516e5e3aa0  push r9
00007d516e5e3aa2  push r10
00007d516e5e3aa4  push r11
00007d516e5e3aa6  sub rsp, 0xF0
00007d516e5e3aad  vmovaps [rsp], xmm0
00007d516e5e3ab2  vmovaps [rsp+0x10], xmm1
00007d516e5e3ab8  vmovaps [rsp+0x20], xmm2
00007d516e5e3abe  vmovaps [rsp+0x30], xmm3
00007d516e5e3ac4  vmovaps [rsp+0x40], xmm4
00007d516e5e3aca  vmovaps [rsp+0x50], xmm5
00007d516e5e3ad0  vmovaps [rsp+0x60], xmm6
00007d516e5e3ad6  vmovaps [rsp+0x70], xmm7
00007d516e5e3adc  vmovaps [rsp+0x80], xmm8
00007d516e5e3ae5  vmovaps [rsp+0x90], xmm9
00007d516e5e3aee  vmovaps [rsp+0xA0], xmm10
00007d516e5e3af7  vmovaps [rsp+0xB0], xmm11
00007d516e5e3b00  vmovaps [rsp+0xC0], xmm12
00007d516e5e3b09  vmovaps [rsp+0xD0], xmm13
00007d516e5e3b12  vmovaps [rsp+0xE0], xmm14
00007d516e5e3b1b  sub rsp, 0x30
00007d516e5e3b1f  movaps [rsp], xmm15
00007d516e5e3b24  movaps [rsp+0x10], xmm11
00007d516e5e3b2a  movaps [rsp+0x20], xmm6
00007d516e5e3b2f  lea rdi, [rsp]
00007d516e5e3b33  mov esi, 0x00
00007d516e5e3b38  mov rax, 0x5EE43AF14530
00007d516e5e3b42  call rax
00007d516e5e3b44  movaps xmm15, [rsp]
00007d516e5e3b49  add rsp, 0x30
00007d516e5e3b4d  vmovaps xmm0, [rsp]
00007d516e5e3b52  vmovaps xmm1, [rsp+0x10]
00007d516e5e3b58  vmovaps xmm2, [rsp+0x20]
00007d516e5e3b5e  vmovaps xmm3, [rsp+0x30]
00007d516e5e3b64  vmovaps xmm4, [rsp+0x40]
00007d516e5e3b6a  vmovaps xmm5, [rsp+0x50]
00007d516e5e3b70  vmovaps xmm6, [rsp+0x60]
00007d516e5e3b76  vmovaps xmm7, [rsp+0x70]
00007d516e5e3b7c  vmovaps xmm8, [rsp+0x80]
00007d516e5e3b85  vmovaps xmm9, [rsp+0x90]
00007d516e5e3b8e  vmovaps xmm10, [rsp+0xA0]
00007d516e5e3b97  vmovaps xmm11, [rsp+0xB0]
00007d516e5e3ba0  vmovaps xmm12, [rsp+0xC0]
00007d516e5e3ba9  vmovaps xmm13, [rsp+0xD0]
00007d516e5e3bb2  vmovaps xmm14, [rsp+0xE0]
00007d516e5e3bbb  add rsp, 0xF0
00007d516e5e3bc2  pop r11
00007d516e5e3bc4  pop r10
00007d516e5e3bc6  pop r9
00007d516e5e3bc8  pop r8
00007d516e5e3bca  pop rsi
00007d516e5e3bcb  pop rdi
00007d516e5e3bcc  pop rdx
00007d516e5e3bcd  pop rcx
00007d516e5e3bce  pop rax
00007d516e5e3bcf  add rsp, 0x08
00007d516e5e3bd3  jmp 0x00007D516E5DF838
00007d516e5e3bd8  sub rsp, 0x08
00007d516e5e3bdc  push rax
00007d516e5e3bdd  push rcx
00007d516e5e3bde  push rdx
00007d516e5e3bdf  push rdi
00007d516e5e3be0  push rsi
00007d516e5e3be1  push r8
00007d516e5e3be3  push r9
00007d516e5e3be5  push r10
00007d516e5e3be7  push r11
00007d516e5e3be9  sub rsp, 0xF0
00007d516e5e3bf0  vmovaps [rsp], xmm0
00007d516e5e3bf5  vmovaps [rsp+0x10], xmm1
00007d516e5e3bfb  vmovaps [rsp+0x20], xmm2
00007d516e5e3c01  vmovaps [rsp+0x30], xmm3
00007d516e5e3c07  vmovaps [rsp+0x40], xmm4
00007d516e5e3c0d  vmovaps [rsp+0x50], xmm5
00007d516e5e3c13  vmovaps [rsp+0x60], xmm6
00007d516e5e3c19  vmovaps [rsp+0x70], xmm8
00007d516e5e3c1f  vmovaps [rsp+0x80], xmm9
00007d516e5e3c28  vmovaps [rsp+0x90], xmm10
00007d516e5e3c31  vmovaps [rsp+0xA0], xmm11
00007d516e5e3c3a  vmovaps [rsp+0xB0], xmm12
00007d516e5e3c43  vmovaps [rsp+0xC0], xmm13
00007d516e5e3c4c  vmovaps [rsp+0xD0], xmm14
00007d516e5e3c55  vmovaps [rsp+0xE0], xmm15
00007d516e5e3c5e  sub rsp, 0x30
00007d516e5e3c62  movaps [rsp], xmm7
00007d516e5e3c66  movaps [rsp+0x10], xmm11
00007d516e5e3c6c  movaps [rsp+0x20], xmm9
00007d516e5e3c72  lea rdi, [rsp]
00007d516e5e3c76  mov esi, 0x00
00007d516e5e3c7b  mov rax, 0x5EE43AF14530
00007d516e5e3c85  call rax
00007d516e5e3c87  movaps xmm7, [rsp]
00007d516e5e3c8b  add rsp, 0x30
00007d516e5e3c8f  vmovaps xmm0, [rsp]
00007d516e5e3c94  vmovaps xmm1, [rsp+0x10]
00007d516e5e3c9a  vmovaps xmm2, [rsp+0x20]
00007d516e5e3ca0  vmovaps xmm3, [rsp+0x30]
00007d516e5e3ca6  vmovaps xmm4, [rsp+0x40]
00007d516e5e3cac  vmovaps xmm5, [rsp+0x50]
00007d516e5e3cb2  vmovaps xmm6, [rsp+0x60]
00007d516e5e3cb8  vmovaps xmm8, [rsp+0x70]
00007d516e5e3cbe  vmovaps xmm9, [rsp+0x80]
00007d516e5e3cc7  vmovaps xmm10, [rsp+0x90]
00007d516e5e3cd0  vmovaps xmm11, [rsp+0xA0]
00007d516e5e3cd9  vmovaps xmm12, [rsp+0xB0]
00007d516e5e3ce2  vmovaps xmm13, [rsp+0xC0]
00007d516e5e3ceb  vmovaps xmm14, [rsp+0xD0]
00007d516e5e3cf4  vmovaps xmm15, [rsp+0xE0]
00007d516e5e3cfd  add rsp, 0xF0
00007d516e5e3d04  pop r11
00007d516e5e3d06  pop r10
00007d516e5e3d08  pop r9
00007d516e5e3d0a  pop r8
00007d516e5e3d0c  pop rsi
00007d516e5e3d0d  pop rdi
00007d516e5e3d0e  pop rdx
00007d516e5e3d0f  pop rcx
00007d516e5e3d10  pop rax
00007d516e5e3d11  add rsp, 0x08
00007d516e5e3d15  jmp 0x00007D516E5DF865
00007d516e5e3d1a  sub rsp, 0x08
00007d516e5e3d1e  push rax
00007d516e5e3d1f  push rcx
00007d516e5e3d20  push rdx
00007d516e5e3d21  push rdi
00007d516e5e3d22  push rsi
00007d516e5e3d23  push r8
00007d516e5e3d25  push r9
00007d516e5e3d27  push r10
00007d516e5e3d29  push r11
00007d516e5e3d2b  sub rsp, 0xF0
00007d516e5e3d32  vmovaps [rsp], xmm0
00007d516e5e3d37  vmovaps [rsp+0x10], xmm1
00007d516e5e3d3d  vmovaps [rsp+0x20], xmm2
00007d516e5e3d43  vmovaps [rsp+0x30], xmm3
00007d516e5e3d49  vmovaps [rsp+0x40], xmm4
00007d516e5e3d4f  vmovaps [rsp+0x50], xmm5
00007d516e5e3d55  vmovaps [rsp+0x60], xmm6
00007d516e5e3d5b  vmovaps [rsp+0x70], xmm7
00007d516e5e3d61  vmovaps [rsp+0x80], xmm8
00007d516e5e3d6a  vmovaps [rsp+0x90], xmm9
00007d516e5e3d73  vmovaps [rsp+0xA0], xmm10
00007d516e5e3d7c  vmovaps [rsp+0xB0], xmm12
00007d516e5e3d85  vmovaps [rsp+0xC0], xmm13
00007d516e5e3d8e  vmovaps [rsp+0xD0], xmm14
00007d516e5e3d97  vmovaps [rsp+0xE0], xmm15
00007d516e5e3da0  sub rsp, 0x30
00007d516e5e3da4  movaps [rsp], xmm11
00007d516e5e3da9  movaps [rsp+0x10], xmm10
00007d516e5e3daf  movaps [rsp+0x20], xmm14
00007d516e5e3db5  lea rdi, [rsp]
00007d516e5e3db9  mov esi, 0x00
00007d516e5e3dbe  mov rax, 0x5EE43AF14530
00007d516e5e3dc8  call rax
00007d516e5e3dca  movaps xmm11, [rsp]
00007d516e5e3dcf  add rsp, 0x30
00007d516e5e3dd3  vmovaps xmm0, [rsp]
00007d516e5e3dd8  vmovaps xmm1, [rsp+0x10]
00007d516e5e3dde  vmovaps xmm2, [rsp+0x20]
00007d516e5e3de4  vmovaps xmm3, [rsp+0x30]
00007d516e5e3dea  vmovaps xmm4, [rsp+0x40]
00007d516e5e3df0  vmovaps xmm5, [rsp+0x50]
00007d516e5e3df6  vmovaps xmm6, [rsp+0x60]
00007d516e5e3dfc  vmovaps xmm7, [rsp+0x70]
00007d516e5e3e02  vmovaps xmm8, [rsp+0x80]
00007d516e5e3e0b  vmovaps xmm9, [rsp+0x90]
00007d516e5e3e14  vmovaps xmm10, [rsp+0xA0]
00007d516e5e3e1d  vmovaps xmm12, [rsp+0xB0]
00007d516e5e3e26  vmovaps xmm13, [rsp+0xC0]
00007d516e5e3e2f  vmovaps xmm14, [rsp+0xD0]
00007d516e5e3e38  vmovaps xmm15, [rsp+0xE0]
00007d516e5e3e41  add rsp, 0xF0
00007d516e5e3e48  pop r11
00007d516e5e3e4a  pop r10
00007d516e5e3e4c  pop r9
00007d516e5e3e4e  pop r8
00007d516e5e3e50  pop rsi
00007d516e5e3e51  pop rdi
00007d516e5e3e52  pop rdx
00007d516e5e3e53  pop rcx
00007d516e5e3e54  pop rax
00007d516e5e3e55  add rsp, 0x08
00007d516e5e3e59  jmp 0x00007D516E5DF880
00007d516e5e3e5e  call 0x00007D516E4C33A0
00007d516e5e3e63  jmp 0x00007D516E5DF88A
00007d516e5e3e68  sub rsp, 0x08
00007d516e5e3e6c  push rax
00007d516e5e3e6d  push rcx
00007d516e5e3e6e  push rdx
00007d516e5e3e6f  push rdi
00007d516e5e3e70  push rsi
00007d516e5e3e71  push r8
00007d516e5e3e73  push r9
00007d516e5e3e75  push r10
00007d516e5e3e77  push r11
00007d516e5e3e79  sub rsp, 0xF0
00007d516e5e3e80  vmovaps [rsp], xmm0
00007d516e5e3e85  vmovaps [rsp+0x10], xmm1
00007d516e5e3e8b  vmovaps [rsp+0x20], xmm2
00007d516e5e3e91  vmovaps [rsp+0x30], xmm3
00007d516e5e3e97  vmovaps [rsp+0x40], xmm4
00007d516e5e3e9d  vmovaps [rsp+0x50], xmm5
00007d516e5e3ea3  vmovaps [rsp+0x60], xmm6
00007d516e5e3ea9  vmovaps [rsp+0x70], xmm7
00007d516e5e3eaf  vmovaps [rsp+0x80], xmm8
00007d516e5e3eb8  vmovaps [rsp+0x90], xmm9
00007d516e5e3ec1  vmovaps [rsp+0xA0], xmm11
00007d516e5e3eca  vmovaps [rsp+0xB0], xmm12
00007d516e5e3ed3  vmovaps [rsp+0xC0], xmm13
00007d516e5e3edc  vmovaps [rsp+0xD0], xmm14
00007d516e5e3ee5  vmovaps [rsp+0xE0], xmm15
00007d516e5e3eee  sub rsp, 0x30
00007d516e5e3ef2  movaps [rsp], xmm10
00007d516e5e3ef7  movaps [rsp+0x10], xmm1
00007d516e5e3efc  movaps [rsp+0x20], xmm12
00007d516e5e3f02  lea rdi, [rsp]
00007d516e5e3f06  mov esi, 0x00
00007d516e5e3f0b  mov rax, 0x5EE43AF14530
00007d516e5e3f15  call rax
00007d516e5e3f17  movaps xmm10, [rsp]
00007d516e5e3f1c  add rsp, 0x30
00007d516e5e3f20  vmovaps xmm0, [rsp]
00007d516e5e3f25  vmovaps xmm1, [rsp+0x10]
00007d516e5e3f2b  vmovaps xmm2, [rsp+0x20]
00007d516e5e3f31  vmovaps xmm3, [rsp+0x30]
00007d516e5e3f37  vmovaps xmm4, [rsp+0x40]
00007d516e5e3f3d  vmovaps xmm5, [rsp+0x50]
00007d516e5e3f43  vmovaps xmm6, [rsp+0x60]
00007d516e5e3f49  vmovaps xmm7, [rsp+0x70]
00007d516e5e3f4f  vmovaps xmm8, [rsp+0x80]
00007d516e5e3f58  vmovaps xmm9, [rsp+0x90]
00007d516e5e3f61  vmovaps xmm11, [rsp+0xA0]
00007d516e5e3f6a  vmovaps xmm12, [rsp+0xB0]
00007d516e5e3f73  vmovaps xmm13, [rsp+0xC0]
00007d516e5e3f7c  vmovaps xmm14, [rsp+0xD0]
00007d516e5e3f85  vmovaps xmm15, [rsp+0xE0]
00007d516e5e3f8e  add rsp, 0xF0
00007d516e5e3f95  pop r11
00007d516e5e3f97  pop r10
00007d516e5e3f99  pop r9
00007d516e5e3f9b  pop r8
00007d516e5e3f9d  pop rsi
00007d516e5e3f9e  pop rdi
00007d516e5e3f9f  pop rdx
00007d516e5e3fa0  pop rcx
00007d516e5e3fa1  pop rax
00007d516e5e3fa2  add rsp, 0x08
00007d516e5e3fa6  jmp 0x00007D516E5DF8AD
00007d516e5e3fab  sub rsp, 0x08
00007d516e5e3faf  push rax
00007d516e5e3fb0  push rcx
00007d516e5e3fb1  push rdx
00007d516e5e3fb2  push rdi
00007d516e5e3fb3  push rsi
00007d516e5e3fb4  push r8
00007d516e5e3fb6  push r9
00007d516e5e3fb8  push r10
00007d516e5e3fba  push r11
00007d516e5e3fbc  sub rsp, 0xF0
00007d516e5e3fc3  vmovaps [rsp], xmm0
00007d516e5e3fc8  vmovaps [rsp+0x10], xmm1
00007d516e5e3fce  vmovaps [rsp+0x20], xmm2
00007d516e5e3fd4  vmovaps [rsp+0x30], xmm3
00007d516e5e3fda  vmovaps [rsp+0x40], xmm4
00007d516e5e3fe0  vmovaps [rsp+0x50], xmm5
00007d516e5e3fe6  vmovaps [rsp+0x60], xmm6
00007d516e5e3fec  vmovaps [rsp+0x70], xmm7
00007d516e5e3ff2  vmovaps [rsp+0x80], xmm8
00007d516e5e3ffb  vmovaps [rsp+0x90], xmm9
00007d516e5e4004  vmovaps [rsp+0xA0], xmm10
00007d516e5e400d  vmovaps [rsp+0xB0], xmm11
00007d516e5e4016  vmovaps [rsp+0xC0], xmm13
00007d516e5e401f  vmovaps [rsp+0xD0], xmm14
00007d516e5e4028  vmovaps [rsp+0xE0], xmm15
00007d516e5e4031  sub rsp, 0x30
00007d516e5e4035  movaps [rsp], xmm12
00007d516e5e403a  movaps [rsp+0x10], xmm14
00007d516e5e4040  movaps [rsp+0x20], xmm1
00007d516e5e4045  lea rdi, [rsp]
00007d516e5e4049  mov esi, 0x00
00007d516e5e404e  mov rax, 0x5EE43AF14530
00007d516e5e4058  call rax
00007d516e5e405a  movaps xmm12, [rsp]
00007d516e5e405f  add rsp, 0x30
00007d516e5e4063  vmovaps xmm0, [rsp]
00007d516e5e4068  vmovaps xmm1, [rsp+0x10]
00007d516e5e406e  vmovaps xmm2, [rsp+0x20]
00007d516e5e4074  vmovaps xmm3, [rsp+0x30]
00007d516e5e407a  vmovaps xmm4, [rsp+0x40]
00007d516e5e4080  vmovaps xmm5, [rsp+0x50]
00007d516e5e4086  vmovaps xmm6, [rsp+0x60]
00007d516e5e408c  vmovaps xmm7, [rsp+0x70]
00007d516e5e4092  vmovaps xmm8, [rsp+0x80]
00007d516e5e409b  vmovaps xmm9, [rsp+0x90]
00007d516e5e40a4  vmovaps xmm10, [rsp+0xA0]
00007d516e5e40ad  vmovaps xmm11, [rsp+0xB0]
00007d516e5e40b6  vmovaps xmm13, [rsp+0xC0]
00007d516e5e40bf  vmovaps xmm14, [rsp+0xD0]
00007d516e5e40c8  vmovaps xmm15, [rsp+0xE0]
00007d516e5e40d1  add rsp, 0xF0
00007d516e5e40d8  pop r11
00007d516e5e40da  pop r10
00007d516e5e40dc  pop r9
00007d516e5e40de  pop r8
00007d516e5e40e0  pop rsi
00007d516e5e40e1  pop rdi
00007d516e5e40e2  pop rdx
00007d516e5e40e3  pop rcx
00007d516e5e40e4  pop rax
00007d516e5e40e5  add rsp, 0x08
00007d516e5e40e9  jmp 0x00007D516E5DF8DC
00007d516e5e40ee  sub rsp, 0x08
00007d516e5e40f2  push rax
00007d516e5e40f3  push rcx
00007d516e5e40f4  push rdx
00007d516e5e40f5  push rdi
00007d516e5e40f6  push rsi
00007d516e5e40f7  push r8
00007d516e5e40f9  push r9
00007d516e5e40fb  push r10
00007d516e5e40fd  push r11
00007d516e5e40ff  sub rsp, 0xF0
00007d516e5e4106  vmovaps [rsp], xmm0
00007d516e5e410b  vmovaps [rsp+0x10], xmm1
00007d516e5e4111  vmovaps [rsp+0x20], xmm2
00007d516e5e4117  vmovaps [rsp+0x30], xmm3
00007d516e5e411d  vmovaps [rsp+0x40], xmm4
00007d516e5e4123  vmovaps [rsp+0x50], xmm5
00007d516e5e4129  vmovaps [rsp+0x60], xmm6
00007d516e5e412f  vmovaps [rsp+0x70], xmm7
00007d516e5e4135  vmovaps [rsp+0x80], xmm8
00007d516e5e413e  vmovaps [rsp+0x90], xmm9
00007d516e5e4147  vmovaps [rsp+0xA0], xmm10
00007d516e5e4150  vmovaps [rsp+0xB0], xmm11
00007d516e5e4159  vmovaps [rsp+0xC0], xmm12
00007d516e5e4162  vmovaps [rsp+0xD0], xmm13
00007d516e5e416b  vmovaps [rsp+0xE0], xmm15
00007d516e5e4174  sub rsp, 0x30
00007d516e5e4178  movaps [rsp], xmm14
00007d516e5e417d  movaps [rsp+0x10], xmm9
00007d516e5e4183  movaps [rsp+0x20], xmm1
00007d516e5e4188  lea rdi, [rsp]
00007d516e5e418c  mov esi, 0x00
00007d516e5e4191  mov rax, 0x5EE43AF14530
00007d516e5e419b  call rax
00007d516e5e419d  movaps xmm14, [rsp]
00007d516e5e41a2  add rsp, 0x30
00007d516e5e41a6  vmovaps xmm0, [rsp]
00007d516e5e41ab  vmovaps xmm1, [rsp+0x10]
00007d516e5e41b1  vmovaps xmm2, [rsp+0x20]
00007d516e5e41b7  vmovaps xmm3, [rsp+0x30]
00007d516e5e41bd  vmovaps xmm4, [rsp+0x40]
00007d516e5e41c3  vmovaps xmm5, [rsp+0x50]
00007d516e5e41c9  vmovaps xmm6, [rsp+0x60]
00007d516e5e41cf  vmovaps xmm7, [rsp+0x70]
00007d516e5e41d5  vmovaps xmm8, [rsp+0x80]
00007d516e5e41de  vmovaps xmm9, [rsp+0x90]
00007d516e5e41e7  vmovaps xmm10, [rsp+0xA0]
00007d516e5e41f0  vmovaps xmm11, [rsp+0xB0]
00007d516e5e41f9  vmovaps xmm12, [rsp+0xC0]
00007d516e5e4202  vmovaps xmm13, [rsp+0xD0]
00007d516e5e420b  vmovaps xmm15, [rsp+0xE0]
00007d516e5e4214  add rsp, 0xF0
00007d516e5e421b  pop r11
00007d516e5e421d  pop r10
00007d516e5e421f  pop r9
00007d516e5e4221  pop r8
00007d516e5e4223  pop rsi
00007d516e5e4224  pop rdi
00007d516e5e4225  pop rdx
00007d516e5e4226  pop rcx
00007d516e5e4227  pop rax
00007d516e5e4228  add rsp, 0x08
00007d516e5e422c  jmp 0x00007D516E5DF90B
00007d516e5e4231  sub rsp, 0x08
00007d516e5e4235  push rax
00007d516e5e4236  push rcx
00007d516e5e4237  push rdx
00007d516e5e4238  push rdi
00007d516e5e4239  push rsi
00007d516e5e423a  push r8
00007d516e5e423c  push r9
00007d516e5e423e  push r10
00007d516e5e4240  push r11
00007d516e5e4242  sub rsp, 0xF0
00007d516e5e4249  vmovaps [rsp], xmm0
00007d516e5e424e  vmovaps [rsp+0x10], xmm2
00007d516e5e4254  vmovaps [rsp+0x20], xmm3
00007d516e5e425a  vmovaps [rsp+0x30], xmm4
00007d516e5e4260  vmovaps [rsp+0x40], xmm5
00007d516e5e4266  vmovaps [rsp+0x50], xmm6
00007d516e5e426c  vmovaps [rsp+0x60], xmm7
00007d516e5e4272  vmovaps [rsp+0x70], xmm8
00007d516e5e4278  vmovaps [rsp+0x80], xmm9
00007d516e5e4281  vmovaps [rsp+0x90], xmm10
00007d516e5e428a  vmovaps [rsp+0xA0], xmm11
00007d516e5e4293  vmovaps [rsp+0xB0], xmm12
00007d516e5e429c  vmovaps [rsp+0xC0], xmm13
00007d516e5e42a5  vmovaps [rsp+0xD0], xmm14
00007d516e5e42ae  vmovaps [rsp+0xE0], xmm15
00007d516e5e42b7  sub rsp, 0x30
00007d516e5e42bb  movaps [rsp], xmm1
00007d516e5e42bf  movaps [rsp+0x10], xmm13
00007d516e5e42c5  movaps [rsp+0x20], xmm8
00007d516e5e42cb  lea rdi, [rsp]
00007d516e5e42cf  mov esi, 0x00
00007d516e5e42d4  mov rax, 0x5EE43AF14530
00007d516e5e42de  call rax
00007d516e5e42e0  movaps xmm1, [rsp]
00007d516e5e42e4  add rsp, 0x30
00007d516e5e42e8  vmovaps xmm0, [rsp]
00007d516e5e42ed  vmovaps xmm2, [rsp+0x10]
00007d516e5e42f3  vmovaps xmm3, [rsp+0x20]
00007d516e5e42f9  vmovaps xmm4, [rsp+0x30]
00007d516e5e42ff  vmovaps xmm5, [rsp+0x40]
00007d516e5e4305  vmovaps xmm6, [rsp+0x50]
00007d516e5e430b  vmovaps xmm7, [rsp+0x60]
00007d516e5e4311  vmovaps xmm8, [rsp+0x70]
00007d516e5e4317  vmovaps xmm9, [rsp+0x80]
00007d516e5e4320  vmovaps xmm10, [rsp+0x90]
00007d516e5e4329  vmovaps xmm11, [rsp+0xA0]
00007d516e5e4332  vmovaps xmm12, [rsp+0xB0]
00007d516e5e433b  vmovaps xmm13, [rsp+0xC0]
00007d516e5e4344  vmovaps xmm14, [rsp+0xD0]
00007d516e5e434d  vmovaps xmm15, [rsp+0xE0]
00007d516e5e4356  add rsp, 0xF0
00007d516e5e435d  pop r11
00007d516e5e435f  pop r10
00007d516e5e4361  pop r9
00007d516e5e4363  pop r8
00007d516e5e4365  pop rsi
00007d516e5e4366  pop rdi
00007d516e5e4367  pop rdx
00007d516e5e4368  pop rcx
00007d516e5e4369  pop rax
00007d516e5e436a  add rsp, 0x08
00007d516e5e436e  jmp 0x00007D516E5DF92D
00007d516e5e4373  call 0x00007D516E40C260
00007d516e5e4378  jmp 0x00007D516E5DF93B
00007d516e5e437d  call 0x00007D516E4BD750
00007d516e5e4382  jmp 0x00007D516E5DF945
00007d516e5e4387  sub rsp, 0x08
00007d516e5e438b  push rax
00007d516e5e438c  push rcx
00007d516e5e438d  push rdx
00007d516e5e438e  push rdi
00007d516e5e438f  push rsi
00007d516e5e4390  push r8
00007d516e5e4392  push r9
00007d516e5e4394  push r10
00007d516e5e4396  push r11
00007d516e5e4398  sub rsp, 0xF0
00007d516e5e439f  vmovaps [rsp], xmm0
00007d516e5e43a4  vmovaps [rsp+0x10], xmm1
00007d516e5e43aa  vmovaps [rsp+0x20], xmm2
00007d516e5e43b0  vmovaps [rsp+0x30], xmm3
00007d516e5e43b6  vmovaps [rsp+0x40], xmm4
00007d516e5e43bc  vmovaps [rsp+0x50], xmm5
00007d516e5e43c2  vmovaps [rsp+0x60], xmm6
00007d516e5e43c8  vmovaps [rsp+0x70], xmm7
00007d516e5e43ce  vmovaps [rsp+0x80], xmm9
00007d516e5e43d7  vmovaps [rsp+0x90], xmm10
00007d516e5e43e0  vmovaps [rsp+0xA0], xmm11
00007d516e5e43e9  vmovaps [rsp+0xB0], xmm12
00007d516e5e43f2  vmovaps [rsp+0xC0], xmm13
00007d516e5e43fb  vmovaps [rsp+0xD0], xmm14
00007d516e5e4404  vmovaps [rsp+0xE0], xmm15
00007d516e5e440d  sub rsp, 0x30
00007d516e5e4411  movaps [rsp], xmm8
00007d516e5e4416  movaps [rsp+0x10], xmm15
00007d516e5e441c  movaps [rsp+0x20], xmm7
00007d516e5e4421  lea rdi, [rsp]
00007d516e5e4425  mov esi, 0x00
00007d516e5e442a  mov rax, 0x5EE43AF14530
00007d516e5e4434  call rax
00007d516e5e4436  movaps xmm8, [rsp]
00007d516e5e443b  add rsp, 0x30
00007d516e5e443f  vmovaps xmm0, [rsp]
00007d516e5e4444  vmovaps xmm1, [rsp+0x10]
00007d516e5e444a  vmovaps xmm2, [rsp+0x20]
00007d516e5e4450  vmovaps xmm3, [rsp+0x30]
00007d516e5e4456  vmovaps xmm4, [rsp+0x40]
00007d516e5e445c  vmovaps xmm5, [rsp+0x50]
00007d516e5e4462  vmovaps xmm6, [rsp+0x60]
00007d516e5e4468  vmovaps xmm7, [rsp+0x70]
00007d516e5e446e  vmovaps xmm9, [rsp+0x80]
00007d516e5e4477  vmovaps xmm10, [rsp+0x90]
00007d516e5e4480  vmovaps xmm11, [rsp+0xA0]
00007d516e5e4489  vmovaps xmm12, [rsp+0xB0]
00007d516e5e4492  vmovaps xmm13, [rsp+0xC0]
00007d516e5e449b  vmovaps xmm14, [rsp+0xD0]
00007d516e5e44a4  vmovaps xmm15, [rsp+0xE0]
00007d516e5e44ad  add rsp, 0xF0
00007d516e5e44b4  pop r11
00007d516e5e44b6  pop r10
00007d516e5e44b8  pop r9
00007d516e5e44ba  pop r8
00007d516e5e44bc  pop rsi
00007d516e5e44bd  pop rdi
00007d516e5e44be  pop rdx
00007d516e5e44bf  pop rcx
00007d516e5e44c0  pop rax
00007d516e5e44c1  add rsp, 0x08
00007d516e5e44c5  jmp 0x00007D516E5DF967
00007d516e5e44ca  sub rsp, 0x08
00007d516e5e44ce  push rax
00007d516e5e44cf  push rcx
00007d516e5e44d0  push rdx
00007d516e5e44d1  push rdi
00007d516e5e44d2  push rsi
00007d516e5e44d3  push r8
00007d516e5e44d5  push r9
00007d516e5e44d7  push r10
00007d516e5e44d9  push r11
00007d516e5e44db  sub rsp, 0xF0
00007d516e5e44e2  vmovaps [rsp], xmm0
00007d516e5e44e7  vmovaps [rsp+0x10], xmm1
00007d516e5e44ed  vmovaps [rsp+0x20], xmm2
00007d516e5e44f3  vmovaps [rsp+0x30], xmm3
00007d516e5e44f9  vmovaps [rsp+0x40], xmm4
00007d516e5e44ff  vmovaps [rsp+0x50], xmm5
00007d516e5e4505  vmovaps [rsp+0x60], xmm6
00007d516e5e450b  vmovaps [rsp+0x70], xmm8
00007d516e5e4511  vmovaps [rsp+0x80], xmm9
00007d516e5e451a  vmovaps [rsp+0x90], xmm10
00007d516e5e4523  vmovaps [rsp+0xA0], xmm11
00007d516e5e452c  vmovaps [rsp+0xB0], xmm12
00007d516e5e4535  vmovaps [rsp+0xC0], xmm13
00007d516e5e453e  vmovaps [rsp+0xD0], xmm14
00007d516e5e4547  vmovaps [rsp+0xE0], xmm15
00007d516e5e4550  sub rsp, 0x30
00007d516e5e4554  movaps [rsp], xmm7
00007d516e5e4558  movaps [rsp+0x10], xmm9
00007d516e5e455e  movaps [rsp+0x20], xmm15
00007d516e5e4564  lea rdi, [rsp]
00007d516e5e4568  mov esi, 0x00
00007d516e5e456d  mov rax, 0x5EE43AF14530
00007d516e5e4577  call rax
00007d516e5e4579  movaps xmm7, [rsp]
00007d516e5e457d  add rsp, 0x30
00007d516e5e4581  vmovaps xmm0, [rsp]
00007d516e5e4586  vmovaps xmm1, [rsp+0x10]
00007d516e5e458c  vmovaps xmm2, [rsp+0x20]
00007d516e5e4592  vmovaps xmm3, [rsp+0x30]
00007d516e5e4598  vmovaps xmm4, [rsp+0x40]
00007d516e5e459e  vmovaps xmm5, [rsp+0x50]
00007d516e5e45a4  vmovaps xmm6, [rsp+0x60]
00007d516e5e45aa  vmovaps xmm8, [rsp+0x70]
00007d516e5e45b0  vmovaps xmm9, [rsp+0x80]
00007d516e5e45b9  vmovaps xmm10, [rsp+0x90]
00007d516e5e45c2  vmovaps xmm11, [rsp+0xA0]
00007d516e5e45cb  vmovaps xmm12, [rsp+0xB0]
00007d516e5e45d4  vmovaps xmm13, [rsp+0xC0]
00007d516e5e45dd  vmovaps xmm14, [rsp+0xD0]
00007d516e5e45e6  vmovaps xmm15, [rsp+0xE0]
00007d516e5e45ef  add rsp, 0xF0
00007d516e5e45f6  pop r11
00007d516e5e45f8  pop r10
00007d516e5e45fa  pop r9
00007d516e5e45fc  pop r8
00007d516e5e45fe  pop rsi
00007d516e5e45ff  pop rdi
00007d516e5e4600  pop rdx
00007d516e5e4601  pop rcx
00007d516e5e4602  pop rax
00007d516e5e4603  add rsp, 0x08
00007d516e5e4607  jmp 0x00007D516E5DF994
00007d516e5e460c  sub rsp, 0x08
00007d516e5e4610  push rax
00007d516e5e4611  push rcx
00007d516e5e4612  push rdx
00007d516e5e4613  push rdi
00007d516e5e4614  push rsi
00007d516e5e4615  push r8
00007d516e5e4617  push r9
00007d516e5e4619  push r10
00007d516e5e461b  push r11
00007d516e5e461d  sub rsp, 0xF0
00007d516e5e4624  vmovaps [rsp], xmm0
00007d516e5e4629  vmovaps [rsp+0x10], xmm1
00007d516e5e462f  vmovaps [rsp+0x20], xmm2
00007d516e5e4635  vmovaps [rsp+0x30], xmm3
00007d516e5e463b  vmovaps [rsp+0x40], xmm4
00007d516e5e4641  vmovaps [rsp+0x50], xmm5
00007d516e5e4647  vmovaps [rsp+0x60], xmm6
00007d516e5e464d  vmovaps [rsp+0x70], xmm7
00007d516e5e4653  vmovaps [rsp+0x80], xmm8
00007d516e5e465c  vmovaps [rsp+0x90], xmm10
00007d516e5e4665  vmovaps [rsp+0xA0], xmm11
00007d516e5e466e  vmovaps [rsp+0xB0], xmm12
00007d516e5e4677  vmovaps [rsp+0xC0], xmm13
00007d516e5e4680  vmovaps [rsp+0xD0], xmm14
00007d516e5e4689  vmovaps [rsp+0xE0], xmm15
00007d516e5e4692  sub rsp, 0x30
00007d516e5e4696  movaps [rsp], xmm9
00007d516e5e469b  movaps [rsp+0x10], xmm13
00007d516e5e46a1  movaps [rsp+0x20], xmm15
00007d516e5e46a7  lea rdi, [rsp]
00007d516e5e46ab  mov esi, 0x00
00007d516e5e46b0  mov rax, 0x5EE43AF14530
00007d516e5e46ba  call rax
00007d516e5e46bc  movaps xmm9, [rsp]
00007d516e5e46c1  add rsp, 0x30
00007d516e5e46c5  vmovaps xmm0, [rsp]
00007d516e5e46ca  vmovaps xmm1, [rsp+0x10]
00007d516e5e46d0  vmovaps xmm2, [rsp+0x20]
00007d516e5e46d6  vmovaps xmm3, [rsp+0x30]
00007d516e5e46dc  vmovaps xmm4, [rsp+0x40]
00007d516e5e46e2  vmovaps xmm5, [rsp+0x50]
00007d516e5e46e8  vmovaps xmm6, [rsp+0x60]
00007d516e5e46ee  vmovaps xmm7, [rsp+0x70]
00007d516e5e46f4  vmovaps xmm8, [rsp+0x80]
00007d516e5e46fd  vmovaps xmm10, [rsp+0x90]
00007d516e5e4706  vmovaps xmm11, [rsp+0xA0]
00007d516e5e470f  vmovaps xmm12, [rsp+0xB0]
00007d516e5e4718  vmovaps xmm13, [rsp+0xC0]
00007d516e5e4721  vmovaps xmm14, [rsp+0xD0]
00007d516e5e472a  vmovaps xmm15, [rsp+0xE0]
00007d516e5e4733  add rsp, 0xF0
00007d516e5e473a  pop r11
00007d516e5e473c  pop r10
00007d516e5e473e  pop r9
00007d516e5e4740  pop r8
00007d516e5e4742  pop rsi
00007d516e5e4743  pop rdi
00007d516e5e4744  pop rdx
00007d516e5e4745  pop rcx
00007d516e5e4746  pop rax
00007d516e5e4747  add rsp, 0x08
00007d516e5e474b  jmp 0x00007D516E5DF9C2
00007d516e5e4750  sub rsp, 0x08
00007d516e5e4754  push rax
00007d516e5e4755  push rcx
00007d516e5e4756  push rdx
00007d516e5e4757  push rdi
00007d516e5e4758  push rsi
00007d516e5e4759  push r8
00007d516e5e475b  push r9
00007d516e5e475d  push r10
00007d516e5e475f  push r11
00007d516e5e4761  sub rsp, 0xF0
00007d516e5e4768  vmovaps [rsp], xmm0
00007d516e5e476d  vmovaps [rsp+0x10], xmm1
00007d516e5e4773  vmovaps [rsp+0x20], xmm2
00007d516e5e4779  vmovaps [rsp+0x30], xmm3
00007d516e5e477f  vmovaps [rsp+0x40], xmm4
00007d516e5e4785  vmovaps [rsp+0x50], xmm5
00007d516e5e478b  vmovaps [rsp+0x60], xmm6
00007d516e5e4791  vmovaps [rsp+0x70], xmm7
00007d516e5e4797  vmovaps [rsp+0x80], xmm8
00007d516e5e47a0  vmovaps [rsp+0x90], xmm9
00007d516e5e47a9  vmovaps [rsp+0xA0], xmm10
00007d516e5e47b2  vmovaps [rsp+0xB0], xmm11
00007d516e5e47bb  vmovaps [rsp+0xC0], xmm12
00007d516e5e47c4  vmovaps [rsp+0xD0], xmm13
00007d516e5e47cd  vmovaps [rsp+0xE0], xmm14
00007d516e5e47d6  sub rsp, 0x30
00007d516e5e47da  movaps [rsp], xmm15
00007d516e5e47df  movaps [rsp+0x10], xmm11
00007d516e5e47e5  movaps [rsp+0x20], xmm12
00007d516e5e47eb  lea rdi, [rsp]
00007d516e5e47ef  mov esi, 0x00
00007d516e5e47f4  mov rax, 0x5EE43AF14530
00007d516e5e47fe  call rax
00007d516e5e4800  movaps xmm15, [rsp]
00007d516e5e4805  add rsp, 0x30
00007d516e5e4809  vmovaps xmm0, [rsp]
00007d516e5e480e  vmovaps xmm1, [rsp+0x10]
00007d516e5e4814  vmovaps xmm2, [rsp+0x20]
00007d516e5e481a  vmovaps xmm3, [rsp+0x30]
00007d516e5e4820  vmovaps xmm4, [rsp+0x40]
00007d516e5e4826  vmovaps xmm5, [rsp+0x50]
00007d516e5e482c  vmovaps xmm6, [rsp+0x60]
00007d516e5e4832  vmovaps xmm7, [rsp+0x70]
00007d516e5e4838  vmovaps xmm8, [rsp+0x80]
00007d516e5e4841  vmovaps xmm9, [rsp+0x90]
00007d516e5e484a  vmovaps xmm10, [rsp+0xA0]
00007d516e5e4853  vmovaps xmm11, [rsp+0xB0]
00007d516e5e485c  vmovaps xmm12, [rsp+0xC0]
00007d516e5e4865  vmovaps xmm13, [rsp+0xD0]
00007d516e5e486e  vmovaps xmm14, [rsp+0xE0]
00007d516e5e4877  add rsp, 0xF0
00007d516e5e487e  pop r11
00007d516e5e4880  pop r10
00007d516e5e4882  pop r9
00007d516e5e4884  pop r8
00007d516e5e4886  pop rsi
00007d516e5e4887  pop rdi
00007d516e5e4888  pop rdx
00007d516e5e4889  pop rcx
00007d516e5e488a  pop rax
00007d516e5e488b  add rsp, 0x08
00007d516e5e488f  jmp 0x00007D516E5DF9DD
00007d516e5e4894  sub rsp, 0x08
00007d516e5e4898  push rax
00007d516e5e4899  push rcx
00007d516e5e489a  push rdx
00007d516e5e489b  push rdi
00007d516e5e489c  push rsi
00007d516e5e489d  push r8
00007d516e5e489f  push r9
00007d516e5e48a1  push r10
00007d516e5e48a3  push r11
00007d516e5e48a5  sub rsp, 0xF0
00007d516e5e48ac  vmovaps [rsp], xmm0
00007d516e5e48b1  vmovaps [rsp+0x10], xmm1
00007d516e5e48b7  vmovaps [rsp+0x20], xmm2
00007d516e5e48bd  vmovaps [rsp+0x30], xmm3
00007d516e5e48c3  vmovaps [rsp+0x40], xmm4
00007d516e5e48c9  vmovaps [rsp+0x50], xmm5
00007d516e5e48cf  vmovaps [rsp+0x60], xmm6
00007d516e5e48d5  vmovaps [rsp+0x70], xmm7
00007d516e5e48db  vmovaps [rsp+0x80], xmm8
00007d516e5e48e4  vmovaps [rsp+0x90], xmm9
00007d516e5e48ed  vmovaps [rsp+0xA0], xmm10
00007d516e5e48f6  vmovaps [rsp+0xB0], xmm11
00007d516e5e48ff  vmovaps [rsp+0xC0], xmm12
00007d516e5e4908  vmovaps [rsp+0xD0], xmm14
00007d516e5e4911  vmovaps [rsp+0xE0], xmm15
00007d516e5e491a  sub rsp, 0x30
00007d516e5e491e  movaps [rsp], xmm13
00007d516e5e4923  movaps [rsp+0x10], xmm10
00007d516e5e4929  movaps [rsp+0x20], xmm14
00007d516e5e492f  lea rdi, [rsp]
00007d516e5e4933  mov esi, 0x00
00007d516e5e4938  mov rax, 0x5EE43AF14530
00007d516e5e4942  call rax
00007d516e5e4944  movaps xmm13, [rsp]
00007d516e5e4949  add rsp, 0x30
00007d516e5e494d  vmovaps xmm0, [rsp]
00007d516e5e4952  vmovaps xmm1, [rsp+0x10]
00007d516e5e4958  vmovaps xmm2, [rsp+0x20]
00007d516e5e495e  vmovaps xmm3, [rsp+0x30]
00007d516e5e4964  vmovaps xmm4, [rsp+0x40]
00007d516e5e496a  vmovaps xmm5, [rsp+0x50]
00007d516e5e4970  vmovaps xmm6, [rsp+0x60]
00007d516e5e4976  vmovaps xmm7, [rsp+0x70]
00007d516e5e497c  vmovaps xmm8, [rsp+0x80]
00007d516e5e4985  vmovaps xmm9, [rsp+0x90]
00007d516e5e498e  vmovaps xmm10, [rsp+0xA0]
00007d516e5e4997  vmovaps xmm11, [rsp+0xB0]
00007d516e5e49a0  vmovaps xmm12, [rsp+0xC0]
00007d516e5e49a9  vmovaps xmm14, [rsp+0xD0]
00007d516e5e49b2  vmovaps xmm15, [rsp+0xE0]
00007d516e5e49bb  add rsp, 0xF0
00007d516e5e49c2  pop r11
00007d516e5e49c4  pop r10
00007d516e5e49c6  pop r9
00007d516e5e49c8  pop r8
00007d516e5e49ca  pop rsi
00007d516e5e49cb  pop rdi
00007d516e5e49cc  pop rdx
00007d516e5e49cd  pop rcx
00007d516e5e49ce  pop rax
00007d516e5e49cf  add rsp, 0x08
00007d516e5e49d3  jmp 0x00007D516E5DFA00
00007d516e5e49d8  sub rsp, 0x08
00007d516e5e49dc  push rax
00007d516e5e49dd  push rcx
00007d516e5e49de  push rdx
00007d516e5e49df  push rdi
00007d516e5e49e0  push rsi
00007d516e5e49e1  push r8
00007d516e5e49e3  push r9
00007d516e5e49e5  push r10
00007d516e5e49e7  push r11
00007d516e5e49e9  sub rsp, 0xF0
00007d516e5e49f0  vmovaps [rsp], xmm0
00007d516e5e49f5  vmovaps [rsp+0x10], xmm1
00007d516e5e49fb  vmovaps [rsp+0x20], xmm2
00007d516e5e4a01  vmovaps [rsp+0x30], xmm3
00007d516e5e4a07  vmovaps [rsp+0x40], xmm4
00007d516e5e4a0d  vmovaps [rsp+0x50], xmm5
00007d516e5e4a13  vmovaps [rsp+0x60], xmm6
00007d516e5e4a19  vmovaps [rsp+0x70], xmm7
00007d516e5e4a1f  vmovaps [rsp+0x80], xmm8
00007d516e5e4a28  vmovaps [rsp+0x90], xmm9
00007d516e5e4a31  vmovaps [rsp+0xA0], xmm10
00007d516e5e4a3a  vmovaps [rsp+0xB0], xmm11
00007d516e5e4a43  vmovaps [rsp+0xC0], xmm12
00007d516e5e4a4c  vmovaps [rsp+0xD0], xmm13
00007d516e5e4a55  vmovaps [rsp+0xE0], xmm15
00007d516e5e4a5e  sub rsp, 0x30
00007d516e5e4a62  movaps [rsp], xmm14
00007d516e5e4a67  movaps [rsp+0x10], xmm1
00007d516e5e4a6c  movaps [rsp+0x20], xmm7
00007d516e5e4a71  lea rdi, [rsp]
00007d516e5e4a75  mov esi, 0x00
00007d516e5e4a7a  mov rax, 0x5EE43AF14530
00007d516e5e4a84  call rax
00007d516e5e4a86  movaps xmm14, [rsp]
00007d516e5e4a8b  add rsp, 0x30
00007d516e5e4a8f  vmovaps xmm0, [rsp]
00007d516e5e4a94  vmovaps xmm1, [rsp+0x10]
00007d516e5e4a9a  vmovaps xmm2, [rsp+0x20]
00007d516e5e4aa0  vmovaps xmm3, [rsp+0x30]
00007d516e5e4aa6  vmovaps xmm4, [rsp+0x40]
00007d516e5e4aac  vmovaps xmm5, [rsp+0x50]
00007d516e5e4ab2  vmovaps xmm6, [rsp+0x60]
00007d516e5e4ab8  vmovaps xmm7, [rsp+0x70]
00007d516e5e4abe  vmovaps xmm8, [rsp+0x80]
00007d516e5e4ac7  vmovaps xmm9, [rsp+0x90]
00007d516e5e4ad0  vmovaps xmm10, [rsp+0xA0]
00007d516e5e4ad9  vmovaps xmm11, [rsp+0xB0]
00007d516e5e4ae2  vmovaps xmm12, [rsp+0xC0]
00007d516e5e4aeb  vmovaps xmm13, [rsp+0xD0]
00007d516e5e4af4  vmovaps xmm15, [rsp+0xE0]
00007d516e5e4afd  add rsp, 0xF0
00007d516e5e4b04  pop r11
00007d516e5e4b06  pop r10
00007d516e5e4b08  pop r9
00007d516e5e4b0a  pop r8
00007d516e5e4b0c  pop rsi
00007d516e5e4b0d  pop rdi
00007d516e5e4b0e  pop rdx
00007d516e5e4b0f  pop rcx
00007d516e5e4b10  pop rax
00007d516e5e4b11  add rsp, 0x08
00007d516e5e4b15  jmp 0x00007D516E5DFA23
00007d516e5e4b1a  sub rsp, 0x08
00007d516e5e4b1e  push rax
00007d516e5e4b1f  push rcx
00007d516e5e4b20  push rdx
00007d516e5e4b21  push rdi
00007d516e5e4b22  push rsi
00007d516e5e4b23  push r8
00007d516e5e4b25  push r9
00007d516e5e4b27  push r10
00007d516e5e4b29  push r11
00007d516e5e4b2b  sub rsp, 0xF0
00007d516e5e4b32  vmovaps [rsp], xmm0
00007d516e5e4b37  vmovaps [rsp+0x10], xmm2
00007d516e5e4b3d  vmovaps [rsp+0x20], xmm3
00007d516e5e4b43  vmovaps [rsp+0x30], xmm4
00007d516e5e4b49  vmovaps [rsp+0x40], xmm5
00007d516e5e4b4f  vmovaps [rsp+0x50], xmm6
00007d516e5e4b55  vmovaps [rsp+0x60], xmm7
00007d516e5e4b5b  vmovaps [rsp+0x70], xmm8
00007d516e5e4b61  vmovaps [rsp+0x80], xmm9
00007d516e5e4b6a  vmovaps [rsp+0x90], xmm10
00007d516e5e4b73  vmovaps [rsp+0xA0], xmm11
00007d516e5e4b7c  vmovaps [rsp+0xB0], xmm12
00007d516e5e4b85  vmovaps [rsp+0xC0], xmm13
00007d516e5e4b8e  vmovaps [rsp+0xD0], xmm14
00007d516e5e4b97  vmovaps [rsp+0xE0], xmm15
00007d516e5e4ba0  sub rsp, 0x30
00007d516e5e4ba4  movaps [rsp], xmm1
00007d516e5e4ba8  movaps [rsp+0x10], xmm8
00007d516e5e4bae  movaps [rsp+0x20], xmm9
00007d516e5e4bb4  lea rdi, [rsp]
00007d516e5e4bb8  mov esi, 0x00
00007d516e5e4bbd  mov rax, 0x5EE43AF14530
00007d516e5e4bc7  call rax
00007d516e5e4bc9  movaps xmm1, [rsp]
00007d516e5e4bcd  add rsp, 0x30
00007d516e5e4bd1  vmovaps xmm0, [rsp]
00007d516e5e4bd6  vmovaps xmm2, [rsp+0x10]
00007d516e5e4bdc  vmovaps xmm3, [rsp+0x20]
00007d516e5e4be2  vmovaps xmm4, [rsp+0x30]
00007d516e5e4be8  vmovaps xmm5, [rsp+0x40]
00007d516e5e4bee  vmovaps xmm6, [rsp+0x50]
00007d516e5e4bf4  vmovaps xmm7, [rsp+0x60]
00007d516e5e4bfa  vmovaps xmm8, [rsp+0x70]
00007d516e5e4c00  vmovaps xmm9, [rsp+0x80]
00007d516e5e4c09  vmovaps xmm10, [rsp+0x90]
00007d516e5e4c12  vmovaps xmm11, [rsp+0xA0]
00007d516e5e4c1b  vmovaps xmm12, [rsp+0xB0]
00007d516e5e4c24  vmovaps xmm13, [rsp+0xC0]
00007d516e5e4c2d  vmovaps xmm14, [rsp+0xD0]
00007d516e5e4c36  vmovaps xmm15, [rsp+0xE0]
00007d516e5e4c3f  add rsp, 0xF0
00007d516e5e4c46  pop r11
00007d516e5e4c48  pop r10
00007d516e5e4c4a  pop r9
00007d516e5e4c4c  pop r8
00007d516e5e4c4e  pop rsi
00007d516e5e4c4f  pop rdi
00007d516e5e4c50  pop rdx
00007d516e5e4c51  pop rcx
00007d516e5e4c52  pop rax
00007d516e5e4c53  add rsp, 0x08
00007d516e5e4c57  jmp 0x00007D516E5DFA45
00007d516e5e4c5c  call 0x00007D516E4E5940
00007d516e5e4c61  jmp 0x00007D516E5DFA53
00007d516e5e4c66  call 0x00007D516E40C380
00007d516e5e4c6b  jmp 0x00007D516E5DFA5D
00007d516e5e4c70  call 0x00007D516E40D600
00007d516e5e4c75  jmp 0x00007D516E5DFA67
00007d516e5e4c7a  call 0x00007D516E3FF540
00007d516e5e4c7f  jmp 0x00007D516E5DFA71
00007d516e5e4c84  int3
00007d516e5e4c85  nop [rax+rax*1], ax
00007d516e5e4c8e  nop
00007d516e5e4c90  mov qword ptr [r15+0x40], 0x430000
00007d516e5e4c98  mov eax, 0x430CC0
00007d516e5e4c9d  mov r14, [r13+rax*1]
00007d516e5e4ca2  movq xmm1, r14
00007d516e5e4ca7  mov rax, [r15+0x50]
00007d516e5e4cab  movups xmm15, [r13+rax*1]
00007d516e5e4cb1  movaps [r15+0x120], xmm15
00007d516e5e4cb9  mov qword ptr [r15+0x48], 0x10
00007d516e5e4cc1  xor eax, eax
00007d516e5e4cc3  mov r14d, 0x10
00007d516e5e4cc9  mov r12d, 0x200
00007d516e5e4ccf  cmp r14, r12
00007d516e5e4cd2  cmc
00007d516e5e4cd3  lahf
00007d516e5e4cd4  seto al
00007d516e5e4cd7  mov [r15+0x108], eax
00007d516e5e4cde  pextrq rax, xmm15, 0x01
00007d516e5e4ce5  movq xmm14, rax
00007d516e5e4cea  movaps [r15+0x130], xmm14
00007d516e5e4cf2  movq rax, xmm1
00007d516e5e4cf7  movq r14, xmm15
00007d516e5e4cfc  vmovq xmm1, rax
00007d516e5e4d01  vmovq xmm15, r14
00007d516e5e4d06  movaps xmm13, xmm1
00007d516e5e4d0a  addsd xmm13, xmm15
00007d516e5e4d0f  ucomisd xmm13, xmm13
00007d516e5e4d14  jp 0x00007D516E5E4DD3
00007d516e5e4d1a  movq xmm13, xmm13
00007d516e5e4d1f  movq rax, xmm13
00007d516e5e4d24  movq r14, xmm14
00007d516e5e4d29  vmovq xmm1, rax
00007d516e5e4d2e  vmovq xmm15, r14
00007d516e5e4d33  movaps xmm14, xmm1
00007d516e5e4d37  addsd xmm14, xmm15
00007d516e5e4d3c  ucomisd xmm14, xmm14
00007d516e5e4d41  jp 0x00007D516E5E4E1B
00007d516e5e4d47  movq xmm14, xmm14
00007d516e5e4d4c  movaps [r15+0x110], xmm14
00007d516e5e4d54  mov eax, [r15+0x108]
00007d516e5e4d5b  sahf
00007d516e5e4d5c  jnz 0x00007D516E5E4D8E
00007d516e5e4d5e  cmp dword ptr [r15+0x318], 0x00
00007d516e5e4d66  jz 0x00007D516E5E5030
00007d516e5e4d6c  nop [rax+rax*1], ax
00007d516e5e4d75  nop [rax+rax*1], eax
00007d516e5e4d7d  mov eax, 0x410704
00007d516e5e4d82  mov [r15+0x100], rax
00007d516e5e4d89  jmp 0x00007D516E3FE110
00007d516e5e4d8e  cmp dword ptr [r15+0x318], 0x00
00007d516e5e4d96  jz 0x00007D516E5E4E70
00007d516e5e4d9c  nop [rax+rax*1], ax
00007d516e5e4da5  nop [rax+rax*1], eax
00007d516e5e4dad  mov eax, 0x4106E8
00007d516e5e4db2  mov [r15+0x100], rax
00007d516e5e4db9  jmp 0x00007D516E3FE110
00007d516e5e4dbe  int3
00007d516e5e4dbf  call 0x00007D516E40DC20
00007d516e5e4dc4  jmp 0x00007D516E5E4CA2
00007d516e5e4dc9  call 0x00007D516E40E760
00007d516e5e4dce  jmp 0x00007D516E5E4CB1
00007d516e5e4dd3  ucomisd xmm1, xmm15
00007d516e5e4dd8  jp 0x00007D516E5E4DE7
00007d516e5e4dda  movaps xmm13, [0x00007D516E1FE060]
00007d516e5e4de2  jmp 0x00007D516E5E4D1A
00007d516e5e4de7  vxorps xmm0, xmm1, xmm15
00007d516e5e4dec  pextrw eax, xmm0, 0x03
00007d516e5e4df1  and eax, 0x7FF8
00007d516e5e4df6  cmp eax, 0x08
00007d516e5e4df9  jnz 0x00007D516E5E4D1A
00007d516e5e4dff  movq rax, xmm15
00007d516e5e4e04  shl rax, 0x0D
00007d516e5e4e08  jbe 0x00007D516E5E4D1A
00007d516e5e4e0e  vorps xmm13, xmm15, [0x00007D516E1FE070]
00007d516e5e4e16  jmp 0x00007D516E5E4D1A
00007d516e5e4e1b  ucomisd xmm1, xmm15
00007d516e5e4e20  jp 0x00007D516E5E4E2F
00007d516e5e4e22  movaps xmm14, [0x00007D516E1FE060]
00007d516e5e4e2a  jmp 0x00007D516E5E4D47
00007d516e5e4e2f  vxorps xmm0, xmm1, xmm15
00007d516e5e4e34  pextrw eax, xmm0, 0x03
00007d516e5e4e39  and eax, 0x7FF8
00007d516e5e4e3e  cmp eax, 0x08
00007d516e5e4e41  jnz 0x00007D516E5E4D47
00007d516e5e4e47  movq rax, xmm15
00007d516e5e4e4c  shl rax, 0x0D
00007d516e5e4e50  jbe 0x00007D516E5E4D47
00007d516e5e4e56  vorps xmm14, xmm15, [0x00007D516E1FE070]
00007d516e5e4e5e  jmp 0x00007D516E5E4D47
00007d516e5e4e63  int3
00007d516e5e4e64  nop [rax+rax*1], ax
00007d516e5e4e6d  nop [rax], eax
00007d516e5e4e70  mov rax, [r15+0x48]
00007d516e5e4e74  mov r14, [r15+0x50]
00007d516e5e4e78  lea r12, [r14+rax*1]
00007d516e5e4e7c  movups xmm1, [r13+r12*1]
00007d516e5e4e82  movaps [r15+0x120], xmm1
00007d516e5e4e8a  lea r14, [rax+0x10]
00007d516e5e4e8e  mov [r15+0x48], r14
00007d516e5e4e92  xor eax, eax
00007d516e5e4e94  mov r12d, 0x200
00007d516e5e4e9a  cmp r14, r12
00007d516e5e4e9d  cmc
00007d516e5e4e9e  lahf
00007d516e5e4e9f  seto al
00007d516e5e4ea2  mov [r15+0x108], eax
00007d516e5e4ea9  pextrq rax, xmm1, 0x01
00007d516e5e4eb0  movq xmm15, rax
00007d516e5e4eb5  movaps [r15+0x130], xmm15
00007d516e5e4ebd  movaps xmm14, [r15+0x110]
00007d516e5e4ec5  movq rax, xmm14
00007d516e5e4eca  movq r14, xmm1
00007d516e5e4ecf  vmovq xmm1, rax
00007d516e5e4ed4  vmovq xmm14, r14
00007d516e5e4ed9  movaps xmm13, xmm1
00007d516e5e4edd  addsd xmm13, xmm14
00007d516e5e4ee2  ucomisd xmm13, xmm13
00007d516e5e4ee7  jp 0x00007D516E5E4F9C
00007d516e5e4eed  movq xmm13, xmm13
00007d516e5e4ef2  movq rax, xmm13
00007d516e5e4ef7  movq r14, xmm15
00007d516e5e4efc  vmovq xmm1, rax
00007d516e5e4f01  vmovq xmm15, r14
00007d516e5e4f06  movaps xmm14, xmm1
00007d516e5e4f0a  addsd xmm14, xmm15
00007d516e5e4f0f  ucomisd xmm14, xmm14
00007d516e5e4f14  jp 0x00007D516E5E4FE4
00007d516e5e4f1a  movq xmm14, xmm14
00007d516e5e4f1f  movaps [r15+0x110], xmm14
00007d516e5e4f27  mov eax, [r15+0x108]
00007d516e5e4f2e  sahf
00007d516e5e4f2f  jnz 0x00007D516E5E4F61
00007d516e5e4f31  cmp dword ptr [r15+0x318], 0x00
00007d516e5e4f39  jz 0x00007D516E5E5030
00007d516e5e4f3f  nop [rax+rax*1], ax
00007d516e5e4f48  nop [rax+rax*1], eax
00007d516e5e4f50  mov eax, 0x410704
00007d516e5e4f55  mov [r15+0x100], rax
00007d516e5e4f5c  jmp 0x00007D516E3FE110
00007d516e5e4f61  cmp dword ptr [r15+0x318], 0x00
00007d516e5e4f69  jz 0x00007D516E5E4E70
00007d516e5e4f6f  nop [rax+rax*1], ax
00007d516e5e4f78  nop [rax+rax*1], eax
00007d516e5e4f80  mov eax, 0x4106E8
00007d516e5e4f85  mov [r15+0x100], rax
00007d516e5e4f8c  jmp 0x00007D516E3FE110
00007d516e5e4f91  int3
00007d516e5e4f92  call 0x00007D516E4B52F0
00007d516e5e4f97  jmp 0x00007D516E5E4E82
00007d516e5e4f9c  ucomisd xmm1, xmm14
00007d516e5e4fa1  jp 0x00007D516E5E4FB0
00007d516e5e4fa3  movaps xmm13, [0x00007D516E1FE060]
00007d516e5e4fab  jmp 0x00007D516E5E4EED
00007d516e5e4fb0  vxorps xmm0, xmm1, xmm14
00007d516e5e4fb5  pextrw eax, xmm0, 0x03
00007d516e5e4fba  and eax, 0x7FF8
00007d516e5e4fbf  cmp eax, 0x08
00007d516e5e4fc2  jnz 0x00007D516E5E4EED
00007d516e5e4fc8  movq rax, xmm14
00007d516e5e4fcd  shl rax, 0x0D
00007d516e5e4fd1  jbe 0x00007D516E5E4EED
00007d516e5e4fd7  vorps xmm13, xmm14, [0x00007D516E1FE070]
00007d516e5e4fdf  jmp 0x00007D516E5E4EED
00007d516e5e4fe4  ucomisd xmm1, xmm15
00007d516e5e4fe9  jp 0x00007D516E5E4FF8
00007d516e5e4feb  movaps xmm14, [0x00007D516E1FE060]
00007d516e5e4ff3  jmp 0x00007D516E5E4F1A
00007d516e5e4ff8  vxorps xmm0, xmm1, xmm15
00007d516e5e4ffd  pextrw eax, xmm0, 0x03
00007d516e5e5002  and eax, 0x7FF8
00007d516e5e5007  cmp eax, 0x08
00007d516e5e500a  jnz 0x00007D516E5E4F1A
00007d516e5e5010  movq rax, xmm15
00007d516e5e5015  shl rax, 0x0D
00007d516e5e5019  jbe 0x00007D516E5E4F1A
00007d516e5e501f  vorps xmm14, xmm15, [0x00007D516E1FE070]
00007d516e5e5027  jmp 0x00007D516E5E4F1A
00007d516e5e502c  int3
00007d516e5e502d  nop [rax], eax
00007d516e5e5030  mov rax, [r15+0xF8]
00007d516e5e5037  lea r14, [rax+0x1D0]
00007d516e5e503e  mov r12, [r13+r14*1]
00007d516e5e5043  lea r14, [rax+0x1D8]
00007d516e5e504a  mov r11, [r13+r14*1]
00007d516e5e504f  mov [r15+0xA0], r12
00007d516e5e5056  mov [r15+0x98], r11
00007d516e5e505d  mov r14, [r15+0x40]
00007d516e5e5061  lea r12, [r14+0xCC0]
00007d516e5e5068  movaps xmm1, [r15+0x110]
00007d516e5e5070  movq r14, xmm1
00007d516e5e5075  mov [r13+r12*1], r14
00007d516e5e507a  lea r14, [rax+0x1C0]
00007d516e5e5081  mov r12, [r13+r14*1]
00007d516e5e5086  lea r14, [rax+0x1C8]
00007d516e5e508d  mov r11, [r13+r14*1]
00007d516e5e5092  mov [r15+0xE8], r12
00007d516e5e5099  mov [r15+0xF0], r11
00007d516e5e50a0  lea r14, [rax+0x1B0]
00007d516e5e50a7  mov r12, [r13+r14*1]
00007d516e5e50ac  lea r14, [rax+0x1B8]
00007d516e5e50b3  mov r10, [r13+r14*1]
00007d516e5e50b8  movq xmm1, r12
00007d516e5e50bd  movq xmm15, r10
00007d516e5e50c2  movq xmm1, xmm1
00007d516e5e50c6  movq xmm1, xmm1
00007d516e5e50ca  movaps [r15+0x1A0], xmm1
00007d516e5e50d2  movq xmm15, xmm15
00007d516e5e50d7  movq xmm15, xmm15
00007d516e5e50dc  movaps [r15+0x190], xmm15
00007d516e5e50e4  lea r14, [rax+0x1A0]
00007d516e5e50eb  mov r12, [r13+r14*1]
00007d516e5e50f0  lea r14, [rax+0x1A8]
00007d516e5e50f7  mov r10, [r13+r14*1]
00007d516e5e50fc  movq xmm1, r12
00007d516e5e5101  movq xmm15, r10
00007d516e5e5106  movq xmm1, xmm1
00007d516e5e510a  movq xmm1, xmm1
00007d516e5e510e  movaps [r15+0x1C0], xmm1
00007d516e5e5116  movq xmm15, xmm15
00007d516e5e511b  movq xmm15, xmm15
00007d516e5e5120  movaps [r15+0x1B0], xmm15
00007d516e5e5128  lea r14, [rax+0x190]
00007d516e5e512f  mov r12, [r13+r14*1]
00007d516e5e5134  lea r14, [rax+0x198]
00007d516e5e513b  mov r10, [r13+r14*1]
00007d516e5e5140  movq xmm1, r12
00007d516e5e5145  movq xmm15, r10
00007d516e5e514a  movq xmm1, xmm1
00007d516e5e514e  movq xmm1, xmm1
00007d516e5e5152  movaps [r15+0x1E0], xmm1
00007d516e5e515a  movq xmm15, xmm15
00007d516e5e515f  movq xmm15, xmm15
00007d516e5e5164  movaps [r15+0x1D0], xmm15
00007d516e5e516c  lea r14, [rax+0x180]
00007d516e5e5173  mov r12, [r13+r14*1]
00007d516e5e5178  lea r14, [rax+0x188]
00007d516e5e517f  mov r10, [r13+r14*1]
00007d516e5e5184  movq xmm1, r12
00007d516e5e5189  movq xmm15, r10
00007d516e5e518e  movq xmm1, xmm1
00007d516e5e5192  movq xmm1, xmm1
00007d516e5e5196  movaps [r15+0x200], xmm1
00007d516e5e519e  movq xmm15, xmm15
00007d516e5e51a3  movq xmm15, xmm15
00007d516e5e51a8  movaps [r15+0x1F0], xmm15
00007d516e5e51b0  lea r14, [rax+0x1E0]
00007d516e5e51b7  mov [r15+0xF8], r14
00007d516e5e51be  mov [r15+0x100], r11
00007d516e5e51c5  jmp 0x00007D516E5CE5C0
00007d516e5e51ca  int3
00007d516e5e51cb  call 0x00007D516E4E27E0
00007d516e5e51d0  jmp 0x00007D516E5E5043
00007d516e5e51d5  call 0x00007D516E4E1570
00007d516e5e51da  jmp 0x00007D516E5E504F
00007d516e5e51df  call 0x00007D516E4C3FE0
00007d516e5e51e4  jmp 0x00007D516E5E507A
00007d516e5e51e9  call 0x00007D516E4E27E0
00007d516e5e51ee  jmp 0x00007D516E5E5086
00007d516e5e51f3  call 0x00007D516E4E1570
00007d516e5e51f8  jmp 0x00007D516E5E5092
00007d516e5e51fd  call 0x00007D516E4E27E0
00007d516e5e5202  jmp 0x00007D516E5E50AC
00007d516e5e5207  call 0x00007D516E4E0300
00007d516e5e520c  jmp 0x00007D516E5E50B8
00007d516e5e5211  call 0x00007D516E4E27E0
00007d516e5e5216  jmp 0x00007D516E5E50F0
00007d516e5e521b  call 0x00007D516E4E0300
00007d516e5e5220  jmp 0x00007D516E5E50FC
00007d516e5e5225  call 0x00007D516E4E27E0
00007d516e5e522a  jmp 0x00007D516E5E5134
00007d516e5e522f  call 0x00007D516E4E0300
00007d516e5e5234  jmp 0x00007D516E5E5140
00007d516e5e5239  call 0x00007D516E4E27E0
00007d516e5e523e  jmp 0x00007D516E5E5178
00007d516e5e5243  call 0x00007D516E4E0300
00007d516e5e5248  jmp 0x00007D516E5E5184
00007d516e5e524d  int3
00007d516e5e524e  nop
00007d516e5e5250  mov qword ptr [r15+0x100], 0x04
00007d516e5e525b  mov esi, 0x00
00007d516e5e5260  mov edx, 0x09
00007d516e5e5265  mov rdi, 0x7FFE1B078A20
00007d516e5e526f  mov rax, 0x5EE43ADA7970
00007d516e5e5279  call rax
00007d516e5e527b  cmp dword ptr [r15+0x318], 0x00
00007d516e5e5283  jnz 0x00007D516E3FE110
00007d516e5e5289  jmp 0x00007D516E3FE0A0
00007d516e5e528e  int3
00007d516e5e528f  int3
