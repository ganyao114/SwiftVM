00007fb1689ce69b  nop [rax+rax*1], eax
00007fb1689ce6a0  mov rax, [r15+0xF8]
00007fb1689ce6a7  lea r14, [rax-0x1E0]
00007fb1689ce6ae  mov [r15+0xF8], r14
00007fb1689ce6b5  lea rax, [r14+0x1D0]
00007fb1689ce6bc  mov r12, [r15+0xA0]
00007fb1689ce6c3  mov r11, [r15+0x98]
00007fb1689ce6ca  mov [r13+rax*1], r12
00007fb1689ce6cf  lea rax, [r14+0x1D8]
00007fb1689ce6d6  mov [r13+rax*1], r11
00007fb1689ce6db  mov eax, 0x420AA0
00007fb1689ce6e0  movups xmm1, [r13+rax*1]
00007fb1689ce6e6  mov eax, 0x420A30
00007fb1689ce6eb  movups xmm15, [r13+rax*1]
00007fb1689ce6f1  mov eax, 0x420AC0
00007fb1689ce6f6  movups xmm14, [r13+rax*1]
00007fb1689ce6fc  mov eax, 0x420A60
00007fb1689ce701  movups xmm13, [r13+rax*1]
00007fb1689ce707  mov qword ptr [r15+0x98], 0x430CD0
00007fb1689ce712  mov eax, 0x420AD0
00007fb1689ce717  movups xmm12, [r13+rax*1]
00007fb1689ce71d  mov eax, 0x430CD0
00007fb1689ce722  movups [r13+rax*1], xmm1
00007fb1689ce728  mov eax, 0x430CE0
00007fb1689ce72d  movups [r13+rax*1], xmm15
00007fb1689ce733  mov eax, 0x430CF0
00007fb1689ce738  movups [r13+rax*1], xmm14
00007fb1689ce73e  mov eax, 0x430D00
00007fb1689ce743  movups [r13+rax*1], xmm13
00007fb1689ce749  mov eax, 0x420A20
00007fb1689ce74e  movups xmm14, [r13+rax*1]
00007fb1689ce754  mov eax, 0x420A10
00007fb1689ce759  movups xmm13, [r13+rax*1]
00007fb1689ce75f  mov eax, 0x430DD0
00007fb1689ce764  movups [r13+rax*1], xmm1
00007fb1689ce76a  mov eax, 0x430DE0
00007fb1689ce76f  movups [r13+rax*1], xmm15
00007fb1689ce775  mov eax, 0x430D10
00007fb1689ce77a  movups [r13+rax*1], xmm12
00007fb1689ce780  mov eax, 0x430D20
00007fb1689ce785  movups [r13+rax*1], xmm14
00007fb1689ce78b  mov eax, 0x420A00
00007fb1689ce790  movups xmm1, [r13+rax*1]
00007fb1689ce796  mov eax, 0x420A70
00007fb1689ce79b  movups xmm15, [r13+rax*1]
00007fb1689ce7a1  mov eax, 0x430D30
00007fb1689ce7a6  movups [r13+rax*1], xmm13
00007fb1689ce7ac  mov eax, 0x430D40
00007fb1689ce7b1  movups [r13+rax*1], xmm1
00007fb1689ce7b7  mov eax, 0x420A80
00007fb1689ce7bc  movups xmm1, [r13+rax*1]
00007fb1689ce7c2  mov eax, 0x420A50
00007fb1689ce7c7  movups xmm14, [r13+rax*1]
00007fb1689ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007fb1689ce7d5  mov eax, 0x430D50
00007fb1689ce7da  movups [r13+rax*1], xmm15
00007fb1689ce7e0  mov eax, 0x430D60
00007fb1689ce7e5  movups [r13+rax*1], xmm1
00007fb1689ce7eb  mov eax, 0x420AF0
00007fb1689ce7f0  movups xmm1, [r13+rax*1]
00007fb1689ce7f6  mov eax, 0x420B00
00007fb1689ce7fb  movups xmm15, [r13+rax*1]
00007fb1689ce801  movaps [r15+0x150], xmm15
00007fb1689ce809  mov qword ptr [r15+0xA0], 0x3E8
00007fb1689ce814  mov eax, 0x430D70
00007fb1689ce819  movups [r13+rax*1], xmm14
00007fb1689ce81f  mov eax, 0x430D80
00007fb1689ce824  movups [r13+rax*1], xmm1
00007fb1689ce82a  mov eax, 0x420AE0
00007fb1689ce82f  movups xmm1, [r13+rax*1]
00007fb1689ce835  mov eax, 0x420A90
00007fb1689ce83a  movups xmm14, [r13+rax*1]
00007fb1689ce840  movaps [r15+0x140], xmm14
00007fb1689ce848  lea rax, [r14+0x180]
00007fb1689ce84f  movq xmm13, qword ptr [r15+0x200]
00007fb1689ce858  movq xmm12, qword ptr [r15+0x1F0]
00007fb1689ce861  movq r12, xmm13
00007fb1689ce866  movq r11, xmm12
00007fb1689ce86b  mov [r13+rax*1], r12
00007fb1689ce870  lea rax, [r14+0x188]
00007fb1689ce877  mov [r13+rax*1], r11
00007fb1689ce87c  mov eax, 0x430D90
00007fb1689ce881  movups [r13+rax*1], xmm15
00007fb1689ce887  mov eax, 0x430DA0
00007fb1689ce88c  movups [r13+rax*1], xmm1
00007fb1689ce892  mov eax, 0x420AB0
00007fb1689ce897  movups xmm1, [r13+rax*1]
00007fb1689ce89d  mov eax, 0x420B18
00007fb1689ce8a2  mov r12, [r13+rax*1]
00007fb1689ce8a7  movq xmm15, r12
00007fb1689ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007fb1689ce8b4  mov eax, 0x430DB0
00007fb1689ce8b9  movups [r13+rax*1], xmm14
00007fb1689ce8bf  mov eax, 0x430DC0
00007fb1689ce8c4  movups [r13+rax*1], xmm1
00007fb1689ce8ca  mov eax, 0x420B80
00007fb1689ce8cf  movups xmm1, [r13+rax*1]
00007fb1689ce8d5  movq rax, xmm15
00007fb1689ce8da  mov r12d, 0x430DF0
00007fb1689ce8e0  mov [r13+r12*1], rax
00007fb1689ce8e5  mov eax, 0x420B60
00007fb1689ce8ea  movups xmm15, [r13+rax*1]
00007fb1689ce8f0  mov eax, 0x420B70
00007fb1689ce8f5  movups xmm14, [r13+rax*1]
00007fb1689ce8fb  lea rax, [r14+0x160]
00007fb1689ce902  movups [r13+rax*1], xmm1
00007fb1689ce908  lea rax, [r14+0x190]
00007fb1689ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007fb1689ce918  movq xmm13, qword ptr [r15+0x1D0]
00007fb1689ce921  movq r12, xmm1
00007fb1689ce926  movq r11, xmm13
00007fb1689ce92b  mov [r13+rax*1], r12
00007fb1689ce930  lea rax, [r14+0x198]
00007fb1689ce937  mov [r13+rax*1], r11
00007fb1689ce93c  lea rax, [r14+0x140]
00007fb1689ce943  movups [r13+rax*1], xmm15
00007fb1689ce949  lea rax, [r14+0x150]
00007fb1689ce950  movups [r13+rax*1], xmm14
00007fb1689ce956  mov eax, 0x420B20
00007fb1689ce95b  movups xmm1, [r13+rax*1]
00007fb1689ce961  mov eax, 0x420B30
00007fb1689ce966  movups xmm15, [r13+rax*1]
00007fb1689ce96c  movaps [r15+0x120], xmm15
00007fb1689ce974  lea rax, [r14+0x1A0]
00007fb1689ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007fb1689ce984  movq xmm13, qword ptr [r15+0x1B0]
00007fb1689ce98d  movq r12, xmm14
00007fb1689ce992  movq r11, xmm13
00007fb1689ce997  mov [r13+rax*1], r12
00007fb1689ce99c  lea rax, [r14+0x1A8]
00007fb1689ce9a3  mov [r13+rax*1], r11
00007fb1689ce9a8  lea rax, [r14+0x1B0]
00007fb1689ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007fb1689ce9b8  movq xmm13, qword ptr [r15+0x190]
00007fb1689ce9c1  movq r12, xmm14
00007fb1689ce9c6  movq r11, xmm13
00007fb1689ce9cb  mov [r13+rax*1], r12
00007fb1689ce9d0  lea rax, [r14+0x1B8]
00007fb1689ce9d7  mov [r13+rax*1], r11
00007fb1689ce9dc  lea rax, [r14+0x100]
00007fb1689ce9e3  movups [r13+rax*1], xmm1
00007fb1689ce9e9  lea rax, [r14+0x110]
00007fb1689ce9f0  movups [r13+rax*1], xmm15
00007fb1689ce9f6  mov eax, 0x420B40
00007fb1689ce9fb  movups xmm1, [r13+rax*1]
00007fb1689cea01  mov eax, 0x420B50
00007fb1689cea06  movups xmm15, [r13+rax*1]
00007fb1689cea0c  movaps [r15+0x110], xmm1
00007fb1689cea14  movaps [r15+0x130], xmm15
00007fb1689cea1c  lea rax, [r14+0x1C0]
00007fb1689cea23  mov r12, [r15+0xE8]
00007fb1689cea2a  mov r11, [r15+0xF0]
00007fb1689cea31  mov [r13+rax*1], r12
00007fb1689cea36  lea rax, [r14+0x1C8]
00007fb1689cea3d  mov [r13+rax*1], r11
00007fb1689cea42  mov eax, 0x430DF8
00007fb1689cea47  mov r12d, 0x421DF8D3
00007fb1689cea4d  mov [r13+rax*1], r12d
00007fb1689cea52  lea rax, [r14+0x120]
00007fb1689cea59  movups [r13+rax*1], xmm1
00007fb1689cea5f  lea rax, [r14+0x130]
00007fb1689cea66  movups [r13+rax*1], xmm15
00007fb1689cea6c  lea rax, [r14+0x100]
00007fb1689cea73  mov [r15], rax
00007fb1689cea76  mov qword ptr [r15+0x08], 0x430CD0
00007fb1689cea7e  mov qword ptr [r15+0x10], 0x12C
00007fb1689cea86  mov qword ptr [r15+0xF0], 0x410284
00007fb1689cea91  mov r14d, [r15+0x320]
00007fb1689cea98  mov eax, 0x410284
00007fb1689cea9d  mov rcx, 0x7FB1689D07C0
00007fb1689ceaa7  mov [r15+r14*8+0x328], rax
00007fb1689ceaaf  mov [r15+r14*8+0x368], rcx
00007fb1689ceab7  add r14d, 0x01
00007fb1689ceabb  and r14d, 0x07
00007fb1689ceabf  mov [r15+0x320], r14d
00007fb1689ceac6  cmp dword ptr [r15+0x318], 0x00
00007fb1689ceace  jz 0x00007FB1689CED70
00007fb1689cead4  nop [rax+rax*1], ax
00007fb1689ceadd  nop [rax+rax*1], eax
00007fb1689ceae5  mov eax, 0x410728
00007fb1689ceaea  mov [r15+0x100], rax
00007fb1689ceaf1  jmp 0x00007FB1687FE110
00007fb1689ceaf6  int3
00007fb1689ceaf7  call 0x00007FB16880BC20
00007fb1689ceafc  jmp 0x00007FB1689CE6CF
00007fb1689ceb01  call 0x00007FB16880A9A0
00007fb1689ceb06  jmp 0x00007FB1689CE6DB
00007fb1689ceb0b  call 0x00007FB1687FF430
00007fb1689ceb10  jmp 0x00007FB1689CE6E6
00007fb1689ceb15  call 0x00007FB16880E760
00007fb1689ceb1a  jmp 0x00007FB1689CE6F1
00007fb1689ceb1f  call 0x00007FB16880D4E0
00007fb1689ceb24  jmp 0x00007FB1689CE6FC
00007fb1689ceb29  call 0x00007FB16880C260
00007fb1689ceb2e  jmp 0x00007FB1689CE707
00007fb1689ceb33  call 0x00007FB16880AFE0
00007fb1689ceb38  jmp 0x00007FB1689CE71D
00007fb1689ceb3d  call 0x00007FB1687FF540
00007fb1689ceb42  jmp 0x00007FB1689CE728
00007fb1689ceb47  call 0x00007FB16880E880
00007fb1689ceb4c  jmp 0x00007FB1689CE733
00007fb1689ceb51  call 0x00007FB16880D600
00007fb1689ceb56  jmp 0x00007FB1689CE73E
00007fb1689ceb5b  call 0x00007FB16880C380
00007fb1689ceb60  jmp 0x00007FB1689CE749
00007fb1689ceb65  call 0x00007FB16880D4E0
00007fb1689ceb6a  jmp 0x00007FB1689CE754
00007fb1689ceb6f  call 0x00007FB16880C260
00007fb1689ceb74  jmp 0x00007FB1689CE75F
00007fb1689ceb79  call 0x00007FB1687FF540
00007fb1689ceb7e  jmp 0x00007FB1689CE76A
00007fb1689ceb83  call 0x00007FB16880E880
00007fb1689ceb88  jmp 0x00007FB1689CE775
00007fb1689ceb8d  call 0x00007FB16880B100
00007fb1689ceb92  jmp 0x00007FB1689CE780
00007fb1689ceb97  call 0x00007FB16880D600
00007fb1689ceb9c  jmp 0x00007FB1689CE78B
00007fb1689ceba1  call 0x00007FB1687FF430
00007fb1689ceba6  jmp 0x00007FB1689CE796
00007fb1689cebab  call 0x00007FB16880E760
00007fb1689cebb0  jmp 0x00007FB1689CE7A1
00007fb1689cebb5  call 0x00007FB16880C380
00007fb1689cebba  jmp 0x00007FB1689CE7AC
00007fb1689cebbf  call 0x00007FB1687FF540
00007fb1689cebc4  jmp 0x00007FB1689CE7B7
00007fb1689cebc9  call 0x00007FB1687FF430
00007fb1689cebce  jmp 0x00007FB1689CE7C2
00007fb1689cebd3  call 0x00007FB16880D4E0
00007fb1689cebd8  jmp 0x00007FB1689CE7CD
00007fb1689cebdd  call 0x00007FB16880E880
00007fb1689cebe2  jmp 0x00007FB1689CE7E0
00007fb1689cebe7  call 0x00007FB1687FF540
00007fb1689cebec  jmp 0x00007FB1689CE7EB
00007fb1689cebf1  call 0x00007FB1687FF430
00007fb1689cebf6  jmp 0x00007FB1689CE7F6
00007fb1689cebfb  call 0x00007FB16880E760
00007fb1689cec00  jmp 0x00007FB1689CE801
00007fb1689cec05  call 0x00007FB16880D600
00007fb1689cec0a  jmp 0x00007FB1689CE81F
00007fb1689cec0f  call 0x00007FB1687FF540
00007fb1689cec14  jmp 0x00007FB1689CE82A
00007fb1689cec19  call 0x00007FB1687FF430
00007fb1689cec1e  jmp 0x00007FB1689CE835
00007fb1689cec23  call 0x00007FB16880D4E0
00007fb1689cec28  jmp 0x00007FB1689CE840
00007fb1689cec2d  call 0x00007FB16880BC20
00007fb1689cec32  jmp 0x00007FB1689CE870
00007fb1689cec37  call 0x00007FB16880A9A0
00007fb1689cec3c  jmp 0x00007FB1689CE87C
00007fb1689cec41  call 0x00007FB16880E880
00007fb1689cec46  jmp 0x00007FB1689CE887
00007fb1689cec4b  call 0x00007FB1687FF540
00007fb1689cec50  jmp 0x00007FB1689CE892
00007fb1689cec55  call 0x00007FB1687FF430
00007fb1689cec5a  jmp 0x00007FB1689CE89D
00007fb1689cec5f  call 0x00007FB16880B720
00007fb1689cec64  jmp 0x00007FB1689CE8A7
00007fb1689cec69  call 0x00007FB16880D600
00007fb1689cec6e  jmp 0x00007FB1689CE8BF
00007fb1689cec73  call 0x00007FB1687FF540
00007fb1689cec78  jmp 0x00007FB1689CE8CA
00007fb1689cec7d  call 0x00007FB1687FF430
00007fb1689cec82  jmp 0x00007FB1689CE8D5
00007fb1689cec87  call 0x00007FB1688B4CB0
00007fb1689cec8c  jmp 0x00007FB1689CE8E5
00007fb1689cec91  call 0x00007FB16880E760
00007fb1689cec96  jmp 0x00007FB1689CE8F0
00007fb1689cec9b  call 0x00007FB16880D4E0
00007fb1689ceca0  jmp 0x00007FB1689CE8FB
00007fb1689ceca5  call 0x00007FB1687FF540
00007fb1689cecaa  jmp 0x00007FB1689CE908
00007fb1689cecaf  call 0x00007FB16880BC20
00007fb1689cecb4  jmp 0x00007FB1689CE930
00007fb1689cecb9  call 0x00007FB16880A9A0
00007fb1689cecbe  jmp 0x00007FB1689CE93C
00007fb1689cecc3  call 0x00007FB16880E880
00007fb1689cecc8  jmp 0x00007FB1689CE949
00007fb1689ceccd  call 0x00007FB16880D600
00007fb1689cecd2  jmp 0x00007FB1689CE956
00007fb1689cecd7  call 0x00007FB1687FF430
00007fb1689cecdc  jmp 0x00007FB1689CE961
00007fb1689cece1  call 0x00007FB16880E760
00007fb1689cece6  jmp 0x00007FB1689CE96C
00007fb1689ceceb  call 0x00007FB16880BC20
00007fb1689cecf0  jmp 0x00007FB1689CE99C
00007fb1689cecf5  call 0x00007FB16880A9A0
00007fb1689cecfa  jmp 0x00007FB1689CE9A8
00007fb1689cecff  call 0x00007FB16880BC20
00007fb1689ced04  jmp 0x00007FB1689CE9D0
00007fb1689ced09  call 0x00007FB16880A9A0
00007fb1689ced0e  jmp 0x00007FB1689CE9DC
00007fb1689ced13  call 0x00007FB1687FF540
00007fb1689ced18  jmp 0x00007FB1689CE9E9
00007fb1689ced1d  call 0x00007FB16880E880
00007fb1689ced22  jmp 0x00007FB1689CE9F6
00007fb1689ced27  call 0x00007FB1687FF430
00007fb1689ced2c  jmp 0x00007FB1689CEA01
00007fb1689ced31  call 0x00007FB16880E760
00007fb1689ced36  jmp 0x00007FB1689CEA0C
00007fb1689ced3b  call 0x00007FB16880BC20
00007fb1689ced40  jmp 0x00007FB1689CEA36
00007fb1689ced45  call 0x00007FB16880A9A0
00007fb1689ced4a  jmp 0x00007FB1689CEA42
00007fb1689ced4f  call 0x00007FB16880BAE0
00007fb1689ced54  jmp 0x00007FB1689CEA52
00007fb1689ced59  call 0x00007FB1687FF540
00007fb1689ced5e  jmp 0x00007FB1689CEA5F
00007fb1689ced63  call 0x00007FB16880E880
00007fb1689ced68  jmp 0x00007FB1689CEA6C
00007fb1689ced6d  int3
00007fb1689ced6e  nop
00007fb1689ced70  mov rax, [r15]
00007fb1689ced73  lea r14, [rax+0x20]
00007fb1689ced77  mov r12, [r13+r14*1]
00007fb1689ced7c  mov r14, [r15+0x10]
00007fb1689ced80  lea r11, [r12+r14*1]
00007fb1689ced84  mov [r15+0x40], r11
00007fb1689ced88  lea r12, [rax+0x20]
00007fb1689ced8c  mov [r13+r12*1], r11
00007fb1689ced91  test r14, r14
00007fb1689ced94  setz r14b
00007fb1689ced98  movzx r14, r14b
00007fb1689ced9c  mov [rsp+0x414], r14b
00007fb1689ceda4  cmp byte ptr [rsp+0x414], 0x00
00007fb1689cedac  jz 0x00007FB1689CEDDE
00007fb1689cedae  cmp dword ptr [r15+0x318], 0x00
00007fb1689cedb6  mov eax, 0x4109A0
00007fb1689cedbb  mov [r15+0x100], rax
00007fb1689cedc2  jz 0x00007FB1687FE0A0
00007fb1689cedc8  nop [rax+rax*1], eax
00007fb1689cedcd  mov eax, 0x4109A0
00007fb1689cedd2  mov [r15+0x100], rax
00007fb1689cedd9  jmp 0x00007FB1687FE110
00007fb1689cedde  cmp dword ptr [r15+0x318], 0x00
00007fb1689cede6  jz 0x00007FB1689CEE30
00007fb1689cedec  nop [rax+rax*1], ax
00007fb1689cedf5  nop [rax+rax*1], eax
00007fb1689cedfd  mov eax, 0x410738
00007fb1689cee02  mov [r15+0x100], rax
00007fb1689cee09  jmp 0x00007FB1687FE110
00007fb1689cee0e  int3
00007fb1689cee0f  call 0x00007FB1688E27E0
00007fb1689cee14  jmp 0x00007FB1689CED7C
00007fb1689cee19  call 0x00007FB1688C0860
00007fb1689cee1e  jmp 0x00007FB1689CED91
00007fb1689cee23  int3
00007fb1689cee24  nop [rax+rax*1], ax
00007fb1689cee2d  nop [rax], eax
00007fb1689cee30  mov rax, [r15+0xF8]
00007fb1689cee37  lea r14, [rax-0x150]
00007fb1689cee3e  mov [r15+0xF8], r14
00007fb1689cee45  mov rax, [r15]
00007fb1689cee48  lea r12, [rax+0x68]
00007fb1689cee4c  mov r11, [r13+r12*1]
00007fb1689cee51  mov [r15+0x88], r11
00007fb1689cee58  lea r12, [rax+0x28]
00007fb1689cee5c  mov [r15+0x40], r12
00007fb1689cee60  mov [r15+0x48], r14
00007fb1689cee64  mov qword ptr [r15+0x50], 0x420B90
00007fb1689cee6c  lea rax, [r14+0x100]
00007fb1689cee73  mov r12, [r15+0xE8]
00007fb1689cee7a  mov r11, [r15+0xD8]
00007fb1689cee81  mov [r13+rax*1], r12
00007fb1689cee86  lea rax, [r14+0x108]
00007fb1689cee8d  mov [r13+rax*1], r11
00007fb1689cee92  lea rax, [r14+0x110]
00007fb1689cee99  mov r12, [r15+0xD0]
00007fb1689ceea0  mov r11, [r15+0xC8]
00007fb1689ceea7  mov [r13+rax*1], r12
00007fb1689ceeac  lea rax, [r14+0x118]
00007fb1689ceeb3  mov [r13+rax*1], r11
00007fb1689ceeb8  lea rax, [r14+0x120]
00007fb1689ceebf  mov r12, [r15+0xC0]
00007fb1689ceec6  mov r11, [r15+0xB8]
00007fb1689ceecd  mov [r13+rax*1], r12
00007fb1689ceed2  lea rax, [r14+0x128]
00007fb1689ceed9  mov [r13+rax*1], r11
00007fb1689ceede  lea rax, [r14+0x130]
00007fb1689ceee5  mov r12, [r15+0xB0]
00007fb1689ceeec  mov r11, [r15+0xA8]
00007fb1689ceef3  mov [r13+rax*1], r12
00007fb1689ceef8  lea rax, [r14+0x138]
00007fb1689ceeff  mov [r13+rax*1], r11
00007fb1689cef04  lea rax, [r14+0x140]
00007fb1689cef0b  mov r12, [r15+0xA0]
00007fb1689cef12  mov r11, [r15+0x98]
00007fb1689cef19  mov [r13+rax*1], r12
00007fb1689cef1e  lea rax, [r14+0x148]
00007fb1689cef25  mov [r13+rax*1], r11
00007fb1689cef2a  cmp dword ptr [r15+0x318], 0x00
00007fb1689cef32  jz 0x00007FB1689CEFD0
00007fb1689cef38  nop [rax+rax*1], ax
00007fb1689cef41  nop [rax+rax*1], eax
00007fb1689cef49  mov eax, 0x410770
00007fb1689cef4e  mov [r15+0x100], rax
00007fb1689cef55  jmp 0x00007FB1687FE110
00007fb1689cef5a  int3
00007fb1689cef5b  call 0x00007FB1688C0370
00007fb1689cef60  jmp 0x00007FB1689CEE51
00007fb1689cef65  call 0x00007FB16880BC20
00007fb1689cef6a  jmp 0x00007FB1689CEE86
00007fb1689cef6f  call 0x00007FB16880A9A0
00007fb1689cef74  jmp 0x00007FB1689CEE92
00007fb1689cef79  call 0x00007FB16880BC20
00007fb1689cef7e  jmp 0x00007FB1689CEEAC
00007fb1689cef83  call 0x00007FB16880A9A0
00007fb1689cef88  jmp 0x00007FB1689CEEB8
00007fb1689cef8d  call 0x00007FB16880BC20
00007fb1689cef92  jmp 0x00007FB1689CEED2
00007fb1689cef97  call 0x00007FB16880A9A0
00007fb1689cef9c  jmp 0x00007FB1689CEEDE
00007fb1689cefa1  call 0x00007FB16880BC20
00007fb1689cefa6  jmp 0x00007FB1689CEEF8
00007fb1689cefab  call 0x00007FB16880A9A0
00007fb1689cefb0  jmp 0x00007FB1689CEF04
00007fb1689cefb5  call 0x00007FB16880BC20
00007fb1689cefba  jmp 0x00007FB1689CEF1E
00007fb1689cefbf  call 0x00007FB16880A9A0
00007fb1689cefc4  jmp 0x00007FB1689CEF2A
00007fb1689cefc9  int3
00007fb1689cefca  nop [rax+rax*1], ax
00007fb1689cefd0  mov rax, [r15+0x08]
00007fb1689cefd4  movzx r14d, byte ptr [r13+rax*1]
00007fb1689cefda  movzx r14d, r14b
00007fb1689cefde  mov [rsp+0x10], r14d
00007fb1689cefe3  mov r14d, r14d
00007fb1689cefe6  mov [r15+0x58], r14
00007fb1689cefea  lea r14, [rax+0x01]
00007fb1689cefee  mov [r15+0x08], r14
00007fb1689ceff2  mov rax, [r15+0x88]
00007fb1689ceff9  lea r14, [rax+0x01]
00007fb1689ceffd  mov r12, [r15]
00007fb1689cf000  lea r11, [r12+0x68]
00007fb1689cf005  mov [r13+r11*1], r14
00007fb1689cf00a  lea r14, [r12+rax*1]
00007fb1689cf00e  mov [r15+0x60], r14
00007fb1689cf012  lea rax, [r14+0x28]
00007fb1689cf016  mov r11d, [rsp+0x10]
00007fb1689cf01b  movzx r14d, r11b
00007fb1689cf01f  mov [r13+rax*1], r14b
00007fb1689cf024  lea rax, [r12+0x68]
00007fb1689cf029  mov r14, [r13+rax*1]
00007fb1689cf02e  mov [r15+0x88], r14
00007fb1689cf035  xor eax, eax
00007fb1689cf037  mov r12d, 0x40
00007fb1689cf03d  cmp r14, r12
00007fb1689cf040  cmc
00007fb1689cf041  lahf
00007fb1689cf042  seto al
00007fb1689cf045  mov [r15+0x108], eax
00007fb1689cf04c  mov eax, [r15+0x108]
00007fb1689cf053  sahf
00007fb1689cf054  jnz 0x00007FB1689CF086
00007fb1689cf056  cmp dword ptr [r15+0x318], 0x00
00007fb1689cf05e  jz 0x00007FB1689CF170
00007fb1689cf064  nop [rax+rax*1], ax
00007fb1689cf06d  nop [rax+rax*1], eax
00007fb1689cf075  mov eax, 0x410790
00007fb1689cf07a  mov [r15+0x100], rax
00007fb1689cf081  jmp 0x00007FB1687FE110
00007fb1689cf086  cmp dword ptr [r15+0x318], 0x00
00007fb1689cf08e  jz 0x00007FB1689CF0E0
00007fb1689cf094  nop [rax+rax*1], ax
00007fb1689cf09d  nop [rax+rax*1], eax
00007fb1689cf0a5  mov eax, 0x410768
00007fb1689cf0aa  mov [r15+0x100], rax
00007fb1689cf0b1  jmp 0x00007FB1687FE110
00007fb1689cf0b6  int3
00007fb1689cf0b7  call 0x00007FB16880D860
00007fb1689cf0bc  jmp 0x00007FB1689CEFDA
00007fb1689cf0c1  call 0x00007FB1688B36E0
00007fb1689cf0c6  jmp 0x00007FB1689CF00A
00007fb1689cf0cb  call 0x00007FB16880DD60
00007fb1689cf0d0  jmp 0x00007FB1689CF024
00007fb1689cf0d5  call 0x00007FB16880DC20
00007fb1689cf0da  jmp 0x00007FB1689CF02E
00007fb1689cf0df  int3
00007fb1689cf0e0  mov rax, [r15+0x10]
00007fb1689cf0e4  lea r14, [rax-0x01]
00007fb1689cf0e8  mov [r15+0x10], r14
00007fb1689cf0ec  test r14, r14
00007fb1689cf0ef  setz r14b
00007fb1689cf0f3  movzx r14, r14b
00007fb1689cf0f7  mov [rsp+0x414], r14b
00007fb1689cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007fb1689cf107  jz 0x00007FB1689CF139
00007fb1689cf109  cmp dword ptr [r15+0x318], 0x00
00007fb1689cf111  jz 0x00007FB1689D0670
00007fb1689cf117  nop [rax+rax*1], ax
00007fb1689cf120  nop [rax+rax*1], eax
00007fb1689cf128  mov eax, 0x410988
00007fb1689cf12d  mov [r15+0x100], rax
00007fb1689cf134  jmp 0x00007FB1687FE110
00007fb1689cf139  cmp dword ptr [r15+0x318], 0x00
00007fb1689cf141  jz 0x00007FB1689CEFD0
00007fb1689cf147  nop [rax+rax*1], ax
00007fb1689cf150  nop [rax+rax*1], eax
00007fb1689cf158  mov eax, 0x410770
00007fb1689cf15d  mov [r15+0x100], rax
00007fb1689cf164  jmp 0x00007FB1687FE110
00007fb1689cf169  int3
00007fb1689cf16a  int3
00007fb1689cf16b  nop [rax+rax*1], eax
00007fb1689cf170  mov rax, [r15+0x40]
00007fb1689cf174  movzx r14d, byte ptr [r13+rax*1]
00007fb1689cf17a  movaps xmm1, [r15+0x110]
00007fb1689cf182  pinsrb xmm1, r14d, 0x00
00007fb1689cf189  lea r14, [rax+0x01]
00007fb1689cf18d  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf193  movaps xmm15, [r15+0x120]
00007fb1689cf19b  pinsrb xmm15, r12d, 0x00
00007fb1689cf1a2  lea r14, [rax+0x02]
00007fb1689cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf1ac  movaps xmm14, [r15+0x130]
00007fb1689cf1b4  pinsrb xmm14, r12d, 0x00
00007fb1689cf1bb  lea r14, [rax+0x03]
00007fb1689cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf1c5  movaps xmm13, [r15+0x140]
00007fb1689cf1cd  pinsrb xmm13, r12d, 0x00
00007fb1689cf1d4  lea r14, [rax+0x04]
00007fb1689cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf1de  pinsrb xmm1, r12d, 0x01
00007fb1689cf1e5  lea r14, [rax+0x05]
00007fb1689cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf1ef  pinsrb xmm15, r12d, 0x01
00007fb1689cf1f6  lea r14, [rax+0x06]
00007fb1689cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf200  pinsrb xmm14, r12d, 0x01
00007fb1689cf207  lea r14, [rax+0x07]
00007fb1689cf20b  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf211  pinsrb xmm13, r12d, 0x01
00007fb1689cf218  lea r14, [rax+0x08]
00007fb1689cf21c  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf222  pinsrb xmm1, r12d, 0x02
00007fb1689cf229  lea r14, [rax+0x09]
00007fb1689cf22d  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf233  pinsrb xmm15, r12d, 0x02
00007fb1689cf23a  lea r14, [rax+0x0A]
00007fb1689cf23e  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf244  pinsrb xmm14, r12d, 0x02
00007fb1689cf24b  lea r14, [rax+0x0B]
00007fb1689cf24f  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf255  pinsrb xmm13, r12d, 0x02
00007fb1689cf25c  lea r14, [rax+0x0C]
00007fb1689cf260  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf266  pinsrb xmm1, r12d, 0x03
00007fb1689cf26d  lea r14, [rax+0x0D]
00007fb1689cf271  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf277  pinsrb xmm15, r12d, 0x03
00007fb1689cf27e  lea r14, [rax+0x0E]
00007fb1689cf282  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf288  pinsrb xmm14, r12d, 0x03
00007fb1689cf28f  lea r14, [rax+0x0F]
00007fb1689cf293  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf299  pinsrb xmm13, r12d, 0x03
00007fb1689cf2a0  lea r14, [rax+0x10]
00007fb1689cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf2aa  pinsrb xmm1, r12d, 0x04
00007fb1689cf2b1  lea r14, [rax+0x11]
00007fb1689cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf2bb  pinsrb xmm15, r12d, 0x04
00007fb1689cf2c2  lea r14, [rax+0x12]
00007fb1689cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf2cc  pinsrb xmm14, r12d, 0x04
00007fb1689cf2d3  lea r14, [rax+0x13]
00007fb1689cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf2dd  pinsrb xmm13, r12d, 0x04
00007fb1689cf2e4  lea r14, [rax+0x14]
00007fb1689cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf2ee  pinsrb xmm1, r12d, 0x05
00007fb1689cf2f5  lea r14, [rax+0x15]
00007fb1689cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf2ff  pinsrb xmm15, r12d, 0x05
00007fb1689cf306  lea r14, [rax+0x16]
00007fb1689cf30a  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf310  pinsrb xmm14, r12d, 0x05
00007fb1689cf317  lea r14, [rax+0x17]
00007fb1689cf31b  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf321  pinsrb xmm13, r12d, 0x05
00007fb1689cf328  lea r14, [rax+0x18]
00007fb1689cf32c  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf332  pinsrb xmm1, r12d, 0x06
00007fb1689cf339  lea r14, [rax+0x19]
00007fb1689cf33d  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf343  pinsrb xmm15, r12d, 0x06
00007fb1689cf34a  lea r14, [rax+0x1A]
00007fb1689cf34e  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf354  pinsrb xmm14, r12d, 0x06
00007fb1689cf35b  lea r14, [rax+0x1B]
00007fb1689cf35f  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf365  pinsrb xmm13, r12d, 0x06
00007fb1689cf36c  lea r14, [rax+0x1C]
00007fb1689cf370  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf376  pinsrb xmm1, r12d, 0x07
00007fb1689cf37d  lea r14, [rax+0x1D]
00007fb1689cf381  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf387  pinsrb xmm15, r12d, 0x07
00007fb1689cf38e  lea r14, [rax+0x1E]
00007fb1689cf392  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf398  pinsrb xmm14, r12d, 0x07
00007fb1689cf39f  lea r14, [rax+0x1F]
00007fb1689cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf3a9  pinsrb xmm13, r12d, 0x07
00007fb1689cf3b0  lea r14, [rax+0x20]
00007fb1689cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf3ba  pinsrb xmm1, r12d, 0x08
00007fb1689cf3c1  lea r14, [rax+0x21]
00007fb1689cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf3cb  pinsrb xmm15, r12d, 0x08
00007fb1689cf3d2  lea r14, [rax+0x22]
00007fb1689cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf3dc  pinsrb xmm14, r12d, 0x08
00007fb1689cf3e3  lea r14, [rax+0x23]
00007fb1689cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf3ed  pinsrb xmm13, r12d, 0x08
00007fb1689cf3f4  lea r14, [rax+0x24]
00007fb1689cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf3fe  pinsrb xmm1, r12d, 0x09
00007fb1689cf405  lea r14, [rax+0x25]
00007fb1689cf409  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf40f  pinsrb xmm15, r12d, 0x09
00007fb1689cf416  lea r14, [rax+0x26]
00007fb1689cf41a  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf420  pinsrb xmm14, r12d, 0x09
00007fb1689cf427  lea r14, [rax+0x27]
00007fb1689cf42b  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf431  pinsrb xmm13, r12d, 0x09
00007fb1689cf438  lea r14, [rax+0x28]
00007fb1689cf43c  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf442  pinsrb xmm1, r12d, 0x0A
00007fb1689cf449  lea r14, [rax+0x29]
00007fb1689cf44d  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf453  pinsrb xmm15, r12d, 0x0A
00007fb1689cf45a  lea r14, [rax+0x2A]
00007fb1689cf45e  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf464  pinsrb xmm14, r12d, 0x0A
00007fb1689cf46b  lea r14, [rax+0x2B]
00007fb1689cf46f  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf475  pinsrb xmm13, r12d, 0x0A
00007fb1689cf47c  lea r14, [rax+0x2C]
00007fb1689cf480  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf486  pinsrb xmm1, r12d, 0x0B
00007fb1689cf48d  lea r14, [rax+0x2D]
00007fb1689cf491  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf497  pinsrb xmm15, r12d, 0x0B
00007fb1689cf49e  lea r14, [rax+0x2E]
00007fb1689cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf4a8  pinsrb xmm14, r12d, 0x0B
00007fb1689cf4af  lea r14, [rax+0x2F]
00007fb1689cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf4b9  pinsrb xmm13, r12d, 0x0B
00007fb1689cf4c0  lea r14, [rax+0x30]
00007fb1689cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf4ca  pinsrb xmm1, r12d, 0x0C
00007fb1689cf4d1  lea r14, [rax+0x31]
00007fb1689cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf4db  pinsrb xmm15, r12d, 0x0C
00007fb1689cf4e2  lea r14, [rax+0x32]
00007fb1689cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf4ec  pinsrb xmm14, r12d, 0x0C
00007fb1689cf4f3  lea r14, [rax+0x33]
00007fb1689cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf4fd  pinsrb xmm13, r12d, 0x0C
00007fb1689cf504  lea r14, [rax+0x34]
00007fb1689cf508  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf50e  pinsrb xmm1, r12d, 0x0D
00007fb1689cf515  lea r14, [rax+0x35]
00007fb1689cf519  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf51f  pinsrb xmm15, r12d, 0x0D
00007fb1689cf526  lea r14, [rax+0x36]
00007fb1689cf52a  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf530  pinsrb xmm14, r12d, 0x0D
00007fb1689cf537  lea r14, [rax+0x37]
00007fb1689cf53b  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf541  pinsrb xmm13, r12d, 0x0D
00007fb1689cf548  lea r14, [rax+0x38]
00007fb1689cf54c  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf552  pinsrb xmm1, r12d, 0x0E
00007fb1689cf559  lea r14, [rax+0x39]
00007fb1689cf55d  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf563  pinsrb xmm15, r12d, 0x0E
00007fb1689cf56a  lea r14, [rax+0x3A]
00007fb1689cf56e  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf574  pinsrb xmm14, r12d, 0x0E
00007fb1689cf57b  lea r14, [rax+0x3B]
00007fb1689cf57f  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf585  pinsrb xmm13, r12d, 0x0E
00007fb1689cf58c  lea r14, [rax+0x3C]
00007fb1689cf590  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf596  pinsrb xmm1, r12d, 0x0F
00007fb1689cf59d  movaps [r15+0x110], xmm1
00007fb1689cf5a5  lea r14, [rax+0x3D]
00007fb1689cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf5af  pinsrb xmm15, r12d, 0x0F
00007fb1689cf5b6  movaps [r15+0x120], xmm15
00007fb1689cf5be  lea r14, [rax+0x3E]
00007fb1689cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007fb1689cf5c8  pinsrb xmm14, r12d, 0x0F
00007fb1689cf5cf  movaps [r15+0x130], xmm14
00007fb1689cf5d7  lea r14, [rax+0x3F]
00007fb1689cf5db  movzx eax, byte ptr [r13+r14*1]
00007fb1689cf5e1  pinsrb xmm13, eax, 0x0F
00007fb1689cf5e8  movaps [r15+0x140], xmm13
00007fb1689cf5f0  movq xmm1, qword ptr [r15+0x120]
00007fb1689cf5f9  pmovzxbw xmm1, xmm1
00007fb1689cf5fe  psllw xmm1, 0x00
00007fb1689cf603  movaps [r15+0x150], xmm1
00007fb1689cf60b  movq xmm1, qword ptr [r15+0x130]
00007fb1689cf614  pmovzxbw xmm1, xmm1
00007fb1689cf619  psllw xmm1, 0x00
00007fb1689cf61e  movaps [r15+0x160], xmm1
00007fb1689cf626  movq xmm1, qword ptr [r15+0x110]
00007fb1689cf62f  pmovzxbw xmm1, xmm1
00007fb1689cf634  psllw xmm1, 0x00
00007fb1689cf639  movaps [r15+0x170], xmm1
00007fb1689cf641  movaps xmm15, [r15+0x110]
00007fb1689cf649  pextrq rax, xmm15, 0x01
00007fb1689cf650  movq xmm15, rax
00007fb1689cf655  pmovzxbw xmm15, xmm15
00007fb1689cf65b  psllw xmm15, 0x00
00007fb1689cf661  movaps [r15+0x180], xmm15
00007fb1689cf669  movaps xmm14, [r15+0x120]
00007fb1689cf671  pextrq rax, xmm14, 0x01
00007fb1689cf678  movq xmm14, rax
00007fb1689cf67d  pmovzxbw xmm14, xmm14
00007fb1689cf683  psllw xmm14, 0x00
00007fb1689cf689  movaps [r15+0x210], xmm14
00007fb1689cf691  movaps xmm13, [r15+0x130]
00007fb1689cf699  pextrq rax, xmm13, 0x01
00007fb1689cf6a0  movq xmm13, rax
00007fb1689cf6a5  pmovzxbw xmm13, xmm13
00007fb1689cf6ab  psllw xmm13, 0x00
00007fb1689cf6b1  movaps [r15+0x220], xmm13
00007fb1689cf6b9  movq xmm12, qword ptr [r15+0x140]
00007fb1689cf6c2  pmovzxbw xmm12, xmm12
00007fb1689cf6c8  psllw xmm12, 0x00
00007fb1689cf6ce  movaps [r15+0x250], xmm12
00007fb1689cf6d6  movaps xmm12, [r15+0x140]
00007fb1689cf6de  pextrq rax, xmm12, 0x01
00007fb1689cf6e5  movq xmm12, rax
00007fb1689cf6ea  pmovzxbw xmm12, xmm12
00007fb1689cf6f0  psllw xmm12, 0x00
00007fb1689cf6f6  movaps [r15+0x110], xmm12
00007fb1689cf6fe  movq xmm11, qword ptr [r15+0x150]
00007fb1689cf707  pmovzxwd xmm11, xmm11
00007fb1689cf70d  pslld xmm11, 0x10
00007fb1689cf713  movq xmm10, qword ptr [r15+0x160]
00007fb1689cf71c  pmovzxwd xmm10, xmm10
00007fb1689cf722  pslld xmm10, 0x08
00007fb1689cf728  pextrq rax, xmm1, 0x01
00007fb1689cf72f  movq xmm1, rax
00007fb1689cf734  pmovzxwd xmm1, xmm1
00007fb1689cf739  pslld xmm1, 0x00
00007fb1689cf73e  movaps [r15+0x260], xmm1
00007fb1689cf746  pextrq rax, xmm15, 0x01
00007fb1689cf74d  movq xmm15, rax
00007fb1689cf752  pmovzxwd xmm15, xmm15
00007fb1689cf758  pslld xmm15, 0x00
00007fb1689cf75e  movaps [r15+0x270], xmm15
00007fb1689cf766  movq xmm9, qword ptr [r15+0x170]
00007fb1689cf76f  pmovzxwd xmm9, xmm9
00007fb1689cf775  pslld xmm9, 0x00
00007fb1689cf77b  pextrq rax, xmm14, 0x01
00007fb1689cf782  movq xmm14, rax
00007fb1689cf787  pmovzxwd xmm14, xmm14
00007fb1689cf78d  pslld xmm14, 0x10
00007fb1689cf793  movaps [r15+0x280], xmm14
00007fb1689cf79b  movq xmm8, qword ptr [r15+0x180]
00007fb1689cf7a4  pmovzxwd xmm8, xmm8
00007fb1689cf7aa  pslld xmm8, 0x00
00007fb1689cf7b0  movq xmm7, qword ptr [r15+0x210]
00007fb1689cf7b9  pmovzxwd xmm7, xmm7
00007fb1689cf7be  pslld xmm7, 0x10
00007fb1689cf7c3  movaps xmm6, [r15+0x150]
00007fb1689cf7cb  pextrq rax, xmm6, 0x01
00007fb1689cf7d2  movq xmm6, rax
00007fb1689cf7d7  pmovzxwd xmm6, xmm6
00007fb1689cf7dc  pslld xmm6, 0x10
00007fb1689cf7e1  por xmm11, xmm10
00007fb1689cf7e6  movaps [r15+0x230], xmm11
00007fb1689cf7ee  pextrq rax, xmm13, 0x01
00007fb1689cf7f5  movq xmm13, rax
00007fb1689cf7fa  pmovzxwd xmm13, xmm13
00007fb1689cf800  pslld xmm13, 0x08
00007fb1689cf806  movaps [r15+0x240], xmm13
00007fb1689cf80e  movq xmm10, qword ptr [r15+0x220]
00007fb1689cf817  pmovzxwd xmm10, xmm10
00007fb1689cf81d  pslld xmm10, 0x08
00007fb1689cf823  movaps xmm5, [r15+0x160]
00007fb1689cf82b  pextrq rax, xmm5, 0x01
00007fb1689cf832  movq xmm5, rax
00007fb1689cf837  pmovzxwd xmm5, xmm5
00007fb1689cf83c  pslld xmm5, 0x08
00007fb1689cf841  pslld xmm9, 0x18
00007fb1689cf847  pslld xmm15, 0x18
00007fb1689cf84d  pslld xmm8, 0x18
00007fb1689cf853  movq xmm4, qword ptr [r15+0x250]
00007fb1689cf85c  pmovzxwd xmm4, xmm4
00007fb1689cf861  pslld xmm4, 0x00
00007fb1689cf866  por xmm14, xmm13
00007fb1689cf86b  por xmm7, xmm10
00007fb1689cf870  movaps [r15+0x210], xmm7
00007fb1689cf878  pslld xmm1, 0x18
00007fb1689cf87d  movaps [r15+0x220], xmm1
00007fb1689cf885  por xmm6, xmm5
00007fb1689cf889  por xmm11, xmm9
00007fb1689cf88e  movaps [r15+0x160], xmm11
00007fb1689cf896  pextrq rax, xmm12, 0x01
00007fb1689cf89d  movq xmm13, rax
00007fb1689cf8a2  pmovzxwd xmm13, xmm13
00007fb1689cf8a8  pslld xmm13, 0x00
00007fb1689cf8ae  movaps [r15+0x170], xmm13
00007fb1689cf8b6  movq xmm12, qword ptr [r15+0x110]
00007fb1689cf8bf  pmovzxwd xmm12, xmm12
00007fb1689cf8c5  pslld xmm12, 0x00
00007fb1689cf8cb  por xmm14, xmm15
00007fb1689cf8d0  por xmm7, xmm8
00007fb1689cf8d5  movaps xmm15, [r15+0x250]
00007fb1689cf8dd  pextrq rax, xmm15, 0x01
00007fb1689cf8e4  movq xmm15, rax
00007fb1689cf8e9  pmovzxwd xmm15, xmm15
00007fb1689cf8ef  pslld xmm15, 0x00
00007fb1689cf8f5  movaps [r15+0x180], xmm15
00007fb1689cf8fd  por xmm6, xmm1
00007fb1689cf901  movaps [r15+0x150], xmm6
00007fb1689cf909  por xmm11, xmm4
00007fb1689cf90e  movaps [r15+0x140], xmm11
00007fb1689cf916  por xmm7, xmm12
00007fb1689cf91b  movaps [r15+0x110], xmm7
00007fb1689cf923  por xmm14, xmm13
00007fb1689cf928  movaps [r15+0x120], xmm14
00007fb1689cf930  por xmm6, xmm15
00007fb1689cf935  movaps [r15+0x130], xmm6
00007fb1689cf93d  mov rax, [r15+0xF8]
00007fb1689cf944  lea r14, [rax+0x20]
00007fb1689cf948  movups [r13+r14*1], xmm7
00007fb1689cf94e  lea r14, [rax+0x30]
00007fb1689cf952  movups [r13+r14*1], xmm14
00007fb1689cf958  movups [r13+rax*1], xmm11
00007fb1689cf95e  lea r14, [rax+0x10]
00007fb1689cf962  movups [r13+r14*1], xmm6
00007fb1689cf968  mov r14d, [r13+rax*1]
00007fb1689cf96d  mov rax, [r15+0x48]
00007fb1689cf971  mov [r15+0x68], rax
00007fb1689cf975  mov qword ptr [r15+0x58], 0x04
00007fb1689cf97d  lea r12, [rax+0x04]
00007fb1689cf981  mov r11d, [r13+r12*1]
00007fb1689cf986  mov [rsp+0x10], r11d
00007fb1689cf98b  mov r11d, r11d
00007fb1689cf98e  mov [r15+0x70], r11
00007fb1689cf992  lea r12, [rax+0x38]
00007fb1689cf996  mov r11d, [r13+r12*1]
00007fb1689cf99b  lea r12, [rax+0x24]
00007fb1689cf99f  mov r10d, [r13+r12*1]
00007fb1689cf9a4  mov [rsp+0x20], r10d
00007fb1689cf9a9  mov r10d, r10d
00007fb1689cf9ac  mov [r15+0x90], r10
00007fb1689cf9b3  mov [rsp+0x30], rax
00007fb1689cf9b8  xor eax, eax
00007fb1689cf9ba  mov r12d, 0x04
00007fb1689cf9c0  mov r10d, 0xC0
00007fb1689cf9c6  cmp r12, r10
00007fb1689cf9c9  cmc
00007fb1689cf9ca  lahf
00007fb1689cf9cb  seto al
00007fb1689cf9ce  mov [r15+0x108], eax
00007fb1689cf9d5  mov eax, [rsp+0x10]
00007fb1689cf9d9  mov r12d, [rsp+0x10]
00007fb1689cf9de  shrd eax, r12d, 0x07
00007fb1689cf9e3  mov [rsp+0x10], r11d
00007fb1689cf9e8  mov r10d, [rsp+0x10]
00007fb1689cf9ed  shrd r11d, r10d, 0x11
00007fb1689cf9f2  mov r9d, [rsp+0x20]
00007fb1689cf9f7  lea r8d, [r9d+r14d*1]
00007fb1689cf9fc  rorx r14d, r12d, 0x12
00007fb1689cfa02  xor eax, r14d
00007fb1689cfa05  rorx r14d, r10d, 0x13
00007fb1689cfa0b  xor r11d, r14d
00007fb1689cfa0e  mov [rsp+0x10], r11d
00007fb1689cfa13  mov r11d, r11d
00007fb1689cfa16  mov [r15+0x88], r11
00007fb1689cfa1d  mov [rsp+0x20], r12d
00007fb1689cfa22  shr r12d, 0x03
00007fb1689cfa26  xor eax, r12d
00007fb1689cfa29  mov [rsp+0x40], eax
00007fb1689cfa2d  mov eax, eax
00007fb1689cfa2f  mov [r15+0x80], rax
00007fb1689cfa36  shr r10d, 0x0A
00007fb1689cfa3a  mov eax, [rsp+0x10]
00007fb1689cfa3e  xor eax, r10d
00007fb1689cfa41  mov [rsp+0x10], eax
00007fb1689cfa45  mov eax, eax
00007fb1689cfa47  mov [r15+0x78], rax
00007fb1689cfa4b  mov eax, [rsp+0x40]
00007fb1689cfa4f  lea r14d, [r8d+eax*1]
00007fb1689cfa54  mov eax, [rsp+0x10]
00007fb1689cfa58  lea r12d, [r14d+eax*1]
00007fb1689cfa5d  mov rax, [rsp+0x30]
00007fb1689cfa62  lea r14, [rax+0x40]
00007fb1689cfa66  mov [r13+r14*1], r12d
00007fb1689cfa6b  mov eax, [rsp+0x20]
00007fb1689cfa6f  mov eax, eax
00007fb1689cfa71  mov [r15+0x60], rax
00007fb1689cfa75  mov eax, [r15+0x108]
00007fb1689cfa7c  sahf
00007fb1689cfa7d  jnz 0x00007FB1689CFAAF
00007fb1689cfa7f  cmp dword ptr [r15+0x318], 0x00
00007fb1689cfa87  jz 0x00007FB1689CFF70
00007fb1689cfa8d  nop [rax+rax*1], ax
00007fb1689cfa96  nop [rax+rax*1], eax
00007fb1689cfa9e  mov eax, 0x41088C
00007fb1689cfaa3  mov [r15+0x100], rax
00007fb1689cfaaa  jmp 0x00007FB1687FE110
00007fb1689cfaaf  cmp dword ptr [r15+0x318], 0x00
00007fb1689cfab7  jz 0x00007FB1689CFDC0
00007fb1689cfabd  nop [rax+rax*1], ax
00007fb1689cfac6  nop [rax+rax*1], eax
00007fb1689cface  mov eax, 0x410844
00007fb1689cfad3  mov [r15+0x100], rax
00007fb1689cfada  jmp 0x00007FB1687FE110
00007fb1689cfadf  int3
00007fb1689cfae0  call 0x00007FB16880D860
00007fb1689cfae5  jmp 0x00007FB1689CF17A
00007fb1689cfaea  call 0x00007FB1688E2420
00007fb1689cfaef  jmp 0x00007FB1689CF193
00007fb1689cfaf4  call 0x00007FB1688E2420
00007fb1689cfaf9  jmp 0x00007FB1689CF1AC
00007fb1689cfafe  call 0x00007FB1688E2420
00007fb1689cfb03  jmp 0x00007FB1689CF1C5
00007fb1689cfb08  call 0x00007FB1688E2420
00007fb1689cfb0d  jmp 0x00007FB1689CF1DE
00007fb1689cfb12  call 0x00007FB1688E2420
00007fb1689cfb17  jmp 0x00007FB1689CF1EF
00007fb1689cfb1c  call 0x00007FB1688E2420
00007fb1689cfb21  jmp 0x00007FB1689CF200
00007fb1689cfb26  call 0x00007FB1688E2420
00007fb1689cfb2b  jmp 0x00007FB1689CF211
00007fb1689cfb30  call 0x00007FB1688E2420
00007fb1689cfb35  jmp 0x00007FB1689CF222
00007fb1689cfb3a  call 0x00007FB1688E2420
00007fb1689cfb3f  jmp 0x00007FB1689CF233
00007fb1689cfb44  call 0x00007FB1688E2420
00007fb1689cfb49  jmp 0x00007FB1689CF244
00007fb1689cfb4e  call 0x00007FB1688E2420
00007fb1689cfb53  jmp 0x00007FB1689CF255
00007fb1689cfb58  call 0x00007FB1688E2420
00007fb1689cfb5d  jmp 0x00007FB1689CF266
00007fb1689cfb62  call 0x00007FB1688E2420
00007fb1689cfb67  jmp 0x00007FB1689CF277
00007fb1689cfb6c  call 0x00007FB1688E2420
00007fb1689cfb71  jmp 0x00007FB1689CF288
00007fb1689cfb76  call 0x00007FB1688E2420
00007fb1689cfb7b  jmp 0x00007FB1689CF299
00007fb1689cfb80  call 0x00007FB1688E2420
00007fb1689cfb85  jmp 0x00007FB1689CF2AA
00007fb1689cfb8a  call 0x00007FB1688E2420
00007fb1689cfb8f  jmp 0x00007FB1689CF2BB
00007fb1689cfb94  call 0x00007FB1688E2420
00007fb1689cfb99  jmp 0x00007FB1689CF2CC
00007fb1689cfb9e  call 0x00007FB1688E2420
00007fb1689cfba3  jmp 0x00007FB1689CF2DD
00007fb1689cfba8  call 0x00007FB1688E2420
00007fb1689cfbad  jmp 0x00007FB1689CF2EE
00007fb1689cfbb2  call 0x00007FB1688E2420
00007fb1689cfbb7  jmp 0x00007FB1689CF2FF
00007fb1689cfbbc  call 0x00007FB1688E2420
00007fb1689cfbc1  jmp 0x00007FB1689CF310
00007fb1689cfbc6  call 0x00007FB1688E2420
00007fb1689cfbcb  jmp 0x00007FB1689CF321
00007fb1689cfbd0  call 0x00007FB1688E2420
00007fb1689cfbd5  jmp 0x00007FB1689CF332
00007fb1689cfbda  call 0x00007FB1688E2420
00007fb1689cfbdf  jmp 0x00007FB1689CF343
00007fb1689cfbe4  call 0x00007FB1688E2420
00007fb1689cfbe9  jmp 0x00007FB1689CF354
00007fb1689cfbee  call 0x00007FB1688E2420
00007fb1689cfbf3  jmp 0x00007FB1689CF365
00007fb1689cfbf8  call 0x00007FB1688E2420
00007fb1689cfbfd  jmp 0x00007FB1689CF376
00007fb1689cfc02  call 0x00007FB1688E2420
00007fb1689cfc07  jmp 0x00007FB1689CF387
00007fb1689cfc0c  call 0x00007FB1688E2420
00007fb1689cfc11  jmp 0x00007FB1689CF398
00007fb1689cfc16  call 0x00007FB1688E2420
00007fb1689cfc1b  jmp 0x00007FB1689CF3A9
00007fb1689cfc20  call 0x00007FB1688E2420
00007fb1689cfc25  jmp 0x00007FB1689CF3BA
00007fb1689cfc2a  call 0x00007FB1688E2420
00007fb1689cfc2f  jmp 0x00007FB1689CF3CB
00007fb1689cfc34  call 0x00007FB1688E2420
00007fb1689cfc39  jmp 0x00007FB1689CF3DC
00007fb1689cfc3e  call 0x00007FB1688E2420
00007fb1689cfc43  jmp 0x00007FB1689CF3ED
00007fb1689cfc48  call 0x00007FB1688E2420
00007fb1689cfc4d  jmp 0x00007FB1689CF3FE
00007fb1689cfc52  call 0x00007FB1688E2420
00007fb1689cfc57  jmp 0x00007FB1689CF40F
00007fb1689cfc5c  call 0x00007FB1688E2420
00007fb1689cfc61  jmp 0x00007FB1689CF420
00007fb1689cfc66  call 0x00007FB1688E2420
00007fb1689cfc6b  jmp 0x00007FB1689CF431
00007fb1689cfc70  call 0x00007FB1688E2420
00007fb1689cfc75  jmp 0x00007FB1689CF442
00007fb1689cfc7a  call 0x00007FB1688E2420
00007fb1689cfc7f  jmp 0x00007FB1689CF453
00007fb1689cfc84  call 0x00007FB1688E2420
00007fb1689cfc89  jmp 0x00007FB1689CF464
00007fb1689cfc8e  call 0x00007FB1688E2420
00007fb1689cfc93  jmp 0x00007FB1689CF475
00007fb1689cfc98  call 0x00007FB1688E2420
00007fb1689cfc9d  jmp 0x00007FB1689CF486
00007fb1689cfca2  call 0x00007FB1688E2420
00007fb1689cfca7  jmp 0x00007FB1689CF497
00007fb1689cfcac  call 0x00007FB1688E2420
00007fb1689cfcb1  jmp 0x00007FB1689CF4A8
00007fb1689cfcb6  call 0x00007FB1688E2420
00007fb1689cfcbb  jmp 0x00007FB1689CF4B9
00007fb1689cfcc0  call 0x00007FB1688E2420
00007fb1689cfcc5  jmp 0x00007FB1689CF4CA
00007fb1689cfcca  call 0x00007FB1688E2420
00007fb1689cfccf  jmp 0x00007FB1689CF4DB
00007fb1689cfcd4  call 0x00007FB1688E2420
00007fb1689cfcd9  jmp 0x00007FB1689CF4EC
00007fb1689cfcde  call 0x00007FB1688E2420
00007fb1689cfce3  jmp 0x00007FB1689CF4FD
00007fb1689cfce8  call 0x00007FB1688E2420
00007fb1689cfced  jmp 0x00007FB1689CF50E
00007fb1689cfcf2  call 0x00007FB1688E2420
00007fb1689cfcf7  jmp 0x00007FB1689CF51F
00007fb1689cfcfc  call 0x00007FB1688E2420
00007fb1689cfd01  jmp 0x00007FB1689CF530
00007fb1689cfd06  call 0x00007FB1688E2420
00007fb1689cfd0b  jmp 0x00007FB1689CF541
00007fb1689cfd10  call 0x00007FB1688E2420
00007fb1689cfd15  jmp 0x00007FB1689CF552
00007fb1689cfd1a  call 0x00007FB1688E2420
00007fb1689cfd1f  jmp 0x00007FB1689CF563
00007fb1689cfd24  call 0x00007FB1688E2420
00007fb1689cfd29  jmp 0x00007FB1689CF574
00007fb1689cfd2e  call 0x00007FB1688E2420
00007fb1689cfd33  jmp 0x00007FB1689CF585
00007fb1689cfd38  call 0x00007FB1688E2420
00007fb1689cfd3d  jmp 0x00007FB1689CF596
00007fb1689cfd42  call 0x00007FB1688E2420
00007fb1689cfd47  jmp 0x00007FB1689CF5AF
00007fb1689cfd4c  call 0x00007FB1688E2420
00007fb1689cfd51  jmp 0x00007FB1689CF5C8
00007fb1689cfd56  call 0x00007FB1688D5610
00007fb1689cfd5b  jmp 0x00007FB1689CF5E1
00007fb1689cfd60  call 0x00007FB1688DC580
00007fb1689cfd65  jmp 0x00007FB1689CF94E
00007fb1689cfd6a  call 0x00007FB1688E46C0
00007fb1689cfd6f  jmp 0x00007FB1689CF958
00007fb1689cfd74  call 0x00007FB168809E90
00007fb1689cfd79  jmp 0x00007FB1689CF95E
00007fb1689cfd7e  call 0x00007FB1688DB310
00007fb1689cfd83  jmp 0x00007FB1689CF968
00007fb1689cfd88  call 0x00007FB16880DAE0
00007fb1689cfd8d  jmp 0x00007FB1689CF96D
00007fb1689cfd92  call 0x00007FB1688C0230
00007fb1689cfd97  jmp 0x00007FB1689CF986
00007fb1689cfd9c  call 0x00007FB1688C0230
00007fb1689cfda1  jmp 0x00007FB1689CF99B
00007fb1689cfda6  call 0x00007FB1688BEFC0
00007fb1689cfdab  jmp 0x00007FB1689CF9A4
00007fb1689cfdb0  call 0x00007FB1688E2BA0
00007fb1689cfdb5  jmp 0x00007FB1689CFA6B
00007fb1689cfdba  int3
00007fb1689cfdbb  nop [rax+rax*1], eax
00007fb1689cfdc0  mov rax, [r15+0x48]
00007fb1689cfdc4  mov r14, [r15+0x58]
00007fb1689cfdc8  lea r12, [rax+r14*1]
00007fb1689cfdcc  mov [r15+0x68], r12
00007fb1689cfdd0  lea rax, [r14+0x04]
00007fb1689cfdd4  mov [r15+0x58], rax
00007fb1689cfdd8  lea r14, [r12+0x04]
00007fb1689cfddd  mov r11d, [r13+r14*1]
00007fb1689cfde2  mov [rsp+0x10], r11d
00007fb1689cfde7  mov r11d, r11d
00007fb1689cfdea  mov [r15+0x70], r11
00007fb1689cfdee  lea r14, [r12+0x38]
00007fb1689cfdf3  mov r11d, [r13+r14*1]
00007fb1689cfdf8  lea r14, [r12+0x24]
00007fb1689cfdfd  mov r10d, [r13+r14*1]
00007fb1689cfe02  mov [rsp+0x20], r10d
00007fb1689cfe07  mov r10d, r10d
00007fb1689cfe0a  mov [r15+0x90], r10
00007fb1689cfe11  mov [rsp+0x30], rax
00007fb1689cfe16  xor eax, eax
00007fb1689cfe18  mov r14, [rsp+0x30]
00007fb1689cfe1d  mov r10d, 0xC0
00007fb1689cfe23  cmp r14, r10
00007fb1689cfe26  cmc
00007fb1689cfe27  lahf
00007fb1689cfe28  seto al
00007fb1689cfe2b  mov [r15+0x108], eax
00007fb1689cfe32  mov eax, [rsp+0x10]
00007fb1689cfe36  mov r14d, [rsp+0x10]
00007fb1689cfe3b  shrd eax, r14d, 0x07
00007fb1689cfe40  mov [rsp+0x10], r11d
00007fb1689cfe45  mov r10d, [rsp+0x10]
00007fb1689cfe4a  shrd r11d, r10d, 0x11
00007fb1689cfe4f  mov r9d, [r15+0x60]
00007fb1689cfe53  mov r8d, [rsp+0x20]
00007fb1689cfe58  lea ebp, [r8d+r9d*1]
00007fb1689cfe5d  rorx r9d, r14d, 0x12
00007fb1689cfe63  xor eax, r9d
00007fb1689cfe66  rorx r9d, r10d, 0x13
00007fb1689cfe6c  xor r11d, r9d
00007fb1689cfe6f  mov [rsp+0x10], r11d
00007fb1689cfe74  mov r11d, r11d
00007fb1689cfe77  mov [r15+0x88], r11
00007fb1689cfe7e  mov [rsp+0x20], r14d
00007fb1689cfe83  shr r14d, 0x03
00007fb1689cfe87  xor eax, r14d
00007fb1689cfe8a  mov [rsp+0x30], eax
00007fb1689cfe8e  mov eax, eax
00007fb1689cfe90  mov [r15+0x80], rax
00007fb1689cfe97  shr r10d, 0x0A
00007fb1689cfe9b  mov eax, [rsp+0x10]
00007fb1689cfe9f  xor eax, r10d
00007fb1689cfea2  mov [rsp+0x10], eax
00007fb1689cfea6  mov eax, eax
00007fb1689cfea8  mov [r15+0x78], rax
00007fb1689cfeac  mov eax, [rsp+0x30]
00007fb1689cfeb0  lea r14d, [ebp+eax*1]
00007fb1689cfeb6  mov eax, [rsp+0x10]
00007fb1689cfeba  lea r11d, [r14d+eax*1]
00007fb1689cfebf  lea rax, [r12+0x40]
00007fb1689cfec4  mov [r13+rax*1], r11d
00007fb1689cfec9  mov eax, [rsp+0x20]
00007fb1689cfecd  mov eax, eax
00007fb1689cfecf  mov [r15+0x60], rax
00007fb1689cfed3  mov eax, [r15+0x108]
00007fb1689cfeda  sahf
00007fb1689cfedb  jnz 0x00007FB1689CFF0D
00007fb1689cfedd  cmp dword ptr [r15+0x318], 0x00
00007fb1689cfee5  jz 0x00007FB1689CFF70
00007fb1689cfeeb  nop [rax+rax*1], ax
00007fb1689cfef4  nop [rax+rax*1], eax
00007fb1689cfefc  mov eax, 0x41088C
00007fb1689cff01  mov [r15+0x100], rax
00007fb1689cff08  jmp 0x00007FB1687FE110
00007fb1689cff0d  cmp dword ptr [r15+0x318], 0x00
00007fb1689cff15  jz 0x00007FB1689CFDC0
00007fb1689cff1b  nop [rax+rax*1], ax
00007fb1689cff24  nop [rax+rax*1], eax
00007fb1689cff2c  mov eax, 0x410844
00007fb1689cff31  mov [r15+0x100], rax
00007fb1689cff38  jmp 0x00007FB1687FE110
00007fb1689cff3d  int3
00007fb1689cff3e  call 0x00007FB1688E1430
00007fb1689cff43  jmp 0x00007FB1689CFDE2
00007fb1689cff48  call 0x00007FB1688E1430
00007fb1689cff4d  jmp 0x00007FB1689CFDF8
00007fb1689cff52  call 0x00007FB1688E01C0
00007fb1689cff57  jmp 0x00007FB1689CFE02
00007fb1689cff5c  call 0x00007FB16880A860
00007fb1689cff61  jmp 0x00007FB1689CFEC9
00007fb1689cff66  int3
00007fb1689cff67  nop [rax+rax*1], ax
00007fb1689cff70  mov rax, [r15]
00007fb1689cff73  mov r14d, [r13+rax*1]
00007fb1689cff78  lea r12, [rax+0x04]
00007fb1689cff7c  mov r11d, [r13+r12*1]
00007fb1689cff81  mov [rsp+0x10], r14d
00007fb1689cff86  mov r14d, r14d
00007fb1689cff89  mov [r15+0x78], r14
00007fb1689cff8d  mov [rsp+0x20], r11d
00007fb1689cff92  mov r11d, r11d
00007fb1689cff95  mov [r15+0x80], r11
00007fb1689cff9c  lea r14, [rax+0x08]
00007fb1689cffa0  mov r12d, [r13+r14*1]
00007fb1689cffa5  lea r14, [rax+0x0C]
00007fb1689cffa9  mov r11d, [r13+r14*1]
00007fb1689cffae  mov [rsp+0x30], r12d
00007fb1689cffb3  mov r12d, r12d
00007fb1689cffb6  mov [r15+0x70], r12
00007fb1689cffba  mov [rsp+0x40], r11d
00007fb1689cffbf  mov r11d, r11d
00007fb1689cffc2  mov [r15+0x68], r11
00007fb1689cffc6  lea r14, [rax+0x18]
00007fb1689cffca  mov r12d, [r13+r14*1]
00007fb1689cffcf  lea r14, [rax+0x1C]
00007fb1689cffd3  mov r11d, [r13+r14*1]
00007fb1689cffd8  mov [rsp+0x50], r12d
00007fb1689cffdd  mov r12d, r12d
00007fb1689cffe0  mov [r15+0x58], r12
00007fb1689cffe4  mov [rsp+0x60], r11d
00007fb1689cffe9  mov r11d, r11d
00007fb1689cffec  mov [r15+0x60], r11
00007fb1689cfff0  lea r14, [rax+0x10]
00007fb1689cfff4  mov r12d, [r13+r14*1]
00007fb1689cfff9  lea r14, [rax+0x14]
00007fb1689cfffd  mov eax, [r13+r14*1]
00007fb1689d0002  mov [rsp+0x70], r12d
00007fb1689d0007  mov r12d, r12d
00007fb1689d000a  mov [r15+0x18], r12
00007fb1689d000e  mov [rsp+0x80], eax
00007fb1689d0015  mov eax, eax
00007fb1689d0017  mov [r15+0x90], rax
00007fb1689d001e  mov eax, [rsp+0x70]
00007fb1689d0022  mov eax, eax
00007fb1689d0024  mov [r15+0x30], rax
00007fb1689d0028  mov eax, [rsp+0x50]
00007fb1689d002c  mov eax, eax
00007fb1689d002e  mov [r15+0xA0], rax
00007fb1689d0035  mov eax, [rsp+0x30]
00007fb1689d0039  mov eax, eax
00007fb1689d003b  mov [r15+0x28], rax
00007fb1689d003f  mov eax, [rsp+0x20]
00007fb1689d0043  mov eax, eax
00007fb1689d0045  mov [r15+0x98], rax
00007fb1689d004c  mov eax, [rsp+0x10]
00007fb1689d0050  mov eax, eax
00007fb1689d0052  mov [r15+0x38], rax
00007fb1689d0056  mov eax, [rsp+0x70]
00007fb1689d005a  mov r14d, [rsp+0x70]
00007fb1689d005f  shrd eax, r14d, 0x06
00007fb1689d0064  mov [rsp+0x70], r14d
00007fb1689d0069  mov r12d, [rsp+0x80]
00007fb1689d0071  and r14d, r12d
00007fb1689d0074  mov r11d, [rsp+0x10]
00007fb1689d0079  mov r10d, [rsp+0x10]
00007fb1689d007e  shrd r11d, r10d, 0x02
00007fb1689d0083  mov [rsp+0x10], r12d
00007fb1689d0088  mov r12d, r12d
00007fb1689d008b  mov [r15+0x20], r12
00007fb1689d008f  mov r12, [r15+0x50]
00007fb1689d0093  mov r9d, [r13+r12*1]
00007fb1689d0098  mov r12d, [rsp+0x50]
00007fb1689d009d  mov r8d, [rsp+0x70]
00007fb1689d00a2  andn ebp, r8d, r12d
00007fb1689d00a7  mov edi, [rsp+0x60]
00007fb1689d00ab  lea esi, [r14d+edi*1]
00007fb1689d00b0  rorx r14d, r8d, 0x0B
00007fb1689d00b6  xor eax, r14d
00007fb1689d00b9  rorx r14d, r10d, 0x0D
00007fb1689d00bf  xor r11d, r14d
00007fb1689d00c2  lea edi, [esi+ebp*1]
00007fb1689d00c6  mov r14, [r15+0x48]
00007fb1689d00ca  mov ebp, [r13+r14*1]
00007fb1689d00cf  mov r14d, [rsp+0x30]
00007fb1689d00d4  mov esi, [rsp+0x20]
00007fb1689d00d8  and r14d, esi
00007fb1689d00db  mov [rsp+0x20], r14d
00007fb1689d00e0  mov r14d, r14d
00007fb1689d00e3  mov [r15+0xD8], r14
00007fb1689d00ea  lea r14d, [edi+r9d*1]
00007fb1689d00ef  mov r9d, [rsp+0x30]
00007fb1689d00f4  xor r9d, esi
00007fb1689d00f7  rorx edi, r8d, 0x19
00007fb1689d00fd  xor eax, edi
00007fb1689d00ff  and r9d, r10d
00007fb1689d0102  rorx edi, r10d, 0x16
00007fb1689d0108  xor r11d, edi
00007fb1689d010b  mov [rsp+0x30], r11d
00007fb1689d0110  mov r11d, r11d
00007fb1689d0113  mov [r15+0xD0], r11
00007fb1689d011a  lea r11d, [r14d+ebp*1]
00007fb1689d011f  mov r10d, [rsp+0x20]
00007fb1689d0124  xor r9d, r10d
00007fb1689d0127  lea r14d, [r11d+eax*1]
00007fb1689d012c  mov qword ptr [r15+0x88], 0x04
00007fb1689d0137  mov eax, [rsp+0x30]
00007fb1689d013b  lea r11d, [r9d+eax*1]
00007fb1689d0140  mov eax, [rsp+0x40]
00007fb1689d0144  lea r10d, [r14d+eax*1]
00007fb1689d0149  mov r10d, r10d
00007fb1689d014c  mov [r15+0xB8], r10
00007fb1689d0153  xor eax, eax
00007fb1689d0155  mov r10d, 0x04
00007fb1689d015b  mov r9d, 0x100
00007fb1689d0161  cmp r10, r9
00007fb1689d0164  cmc
00007fb1689d0165  lahf
00007fb1689d0166  seto al
00007fb1689d0169  mov [r15+0x108], eax
00007fb1689d0170  lea eax, [r11d+r14d*1]
00007fb1689d0175  mov eax, eax
00007fb1689d0177  mov [r15+0xA8], rax
00007fb1689d017e  mov r12d, r12d
00007fb1689d0181  mov [r15+0xB0], r12
00007fb1689d0188  mov eax, [rsp+0x10]
00007fb1689d018c  mov eax, eax
00007fb1689d018e  mov [r15+0xC0], rax
00007fb1689d0195  mov r8d, r8d
00007fb1689d0198  mov [r15+0xC8], r8
00007fb1689d019f  mov eax, [r15+0x108]
00007fb1689d01a6  sahf
00007fb1689d01a7  jnz 0x00007FB1689D01D9
00007fb1689d01a9  cmp dword ptr [r15+0x318], 0x00
00007fb1689d01b1  jz 0x00007FB1689D04A0
00007fb1689d01b7  nop [rax+rax*1], ax
00007fb1689d01c0  nop [rax+rax*1], eax
00007fb1689d01c8  mov eax, 0x41094C
00007fb1689d01cd  mov [r15+0x100], rax
00007fb1689d01d4  jmp 0x00007FB1687FE110
00007fb1689d01d9  cmp dword ptr [r15+0x318], 0x00
00007fb1689d01e1  jz 0x00007FB1689D0270
00007fb1689d01e7  nop [rax+rax*1], ax
00007fb1689d01f0  nop [rax+rax*1], eax
00007fb1689d01f8  mov eax, 0x4108C0
00007fb1689d01fd  mov [r15+0x100], rax
00007fb1689d0204  jmp 0x00007FB1687FE110
00007fb1689d0209  int3
00007fb1689d020a  call 0x00007FB16880DAE0
00007fb1689d020f  jmp 0x00007FB1689CFF78
00007fb1689d0214  call 0x00007FB1688C0230
00007fb1689d0219  jmp 0x00007FB1689CFF81
00007fb1689d021e  call 0x00007FB1688E26A0
00007fb1689d0223  jmp 0x00007FB1689CFFA5
00007fb1689d0228  call 0x00007FB1688E1430
00007fb1689d022d  jmp 0x00007FB1689CFFAE
00007fb1689d0232  call 0x00007FB1688E26A0
00007fb1689d0237  jmp 0x00007FB1689CFFCF
00007fb1689d023c  call 0x00007FB1688E1430
00007fb1689d0241  jmp 0x00007FB1689CFFD8
00007fb1689d0246  call 0x00007FB1688E26A0
00007fb1689d024b  jmp 0x00007FB1689CFFF9
00007fb1689d0250  call 0x00007FB1688D5890
00007fb1689d0255  jmp 0x00007FB1689D0002
00007fb1689d025a  call 0x00007FB1688BDD50
00007fb1689d025f  jmp 0x00007FB1689D0098
00007fb1689d0264  call 0x00007FB1688DA580
00007fb1689d0269  jmp 0x00007FB1689D00CF
00007fb1689d026e  int3
00007fb1689d026f  nop
00007fb1689d0270  mov eax, [r15+0xB8]
00007fb1689d0277  mov [rsp+0x10], eax
00007fb1689d027b  mov eax, eax
00007fb1689d027d  mov [r15+0x30], rax
00007fb1689d0281  mov eax, [r15+0xC0]
00007fb1689d0288  mov [rsp+0x20], eax
00007fb1689d028c  mov eax, eax
00007fb1689d028e  mov [r15+0xA0], rax
00007fb1689d0295  mov eax, [r15+0x28]
00007fb1689d0299  mov r14d, [r15+0x98]
00007fb1689d02a0  mov [rsp+0x30], r14d
00007fb1689d02a5  mov r14d, r14d
00007fb1689d02a8  mov [r15+0x28], r14
00007fb1689d02ac  mov r14d, [r15+0x38]
00007fb1689d02b0  mov [rsp+0x40], r14d
00007fb1689d02b5  mov r14d, r14d
00007fb1689d02b8  mov [r15+0x98], r14
00007fb1689d02bf  mov r14d, [r15+0xA8]
00007fb1689d02c6  mov [rsp+0x50], r14d
00007fb1689d02cb  mov r14d, r14d
00007fb1689d02ce  mov [r15+0x38], r14
00007fb1689d02d2  mov r14d, [rsp+0x10]
00007fb1689d02d7  mov r12d, [rsp+0x10]
00007fb1689d02dc  shrd r14d, r12d, 0x06
00007fb1689d02e1  mov r11d, [r15+0xC8]
00007fb1689d02e8  mov [rsp+0x10], r12d
00007fb1689d02ed  and r12d, r11d
00007fb1689d02f0  mov r10d, [rsp+0x50]
00007fb1689d02f5  mov r9d, [rsp+0x50]
00007fb1689d02fa  shrd r10d, r9d, 0x02
00007fb1689d02ff  mov [rsp+0x50], r11d
00007fb1689d0304  mov r11d, r11d
00007fb1689d0307  mov [r15+0x20], r11
00007fb1689d030b  mov r11, [r15+0x88]
00007fb1689d0312  mov r8, [r15+0x50]
00007fb1689d0316  lea rbp, [r8+r11*1]
00007fb1689d031a  mov r8d, [r13+rbp*1]
00007fb1689d031f  mov ebp, [rsp+0x20]
00007fb1689d0323  mov edi, [rsp+0x10]
00007fb1689d0327  andn esi, edi, ebp
00007fb1689d032c  mov edx, [r15+0xB0]
00007fb1689d0333  lea ecx, [r12d+edx*1]
00007fb1689d0338  rorx r12d, edi, 0x0B
00007fb1689d033e  xor r14d, r12d
00007fb1689d0341  rorx r12d, r9d, 0x0D
00007fb1689d0347  xor r10d, r12d
00007fb1689d034a  lea r12d, [ecx+esi*1]
00007fb1689d034f  mov rsi, [r15+0x48]
00007fb1689d0353  lea rdx, [rsi+r11*1]
00007fb1689d0357  mov esi, [r13+rdx*1]
00007fb1689d035c  mov edx, [rsp+0x30]
00007fb1689d0360  mov ecx, [rsp+0x40]
00007fb1689d0364  and edx, ecx
00007fb1689d0366  mov [rsp+0x10], edx
00007fb1689d036a  mov edx, edx
00007fb1689d036c  mov [r15+0xD8], rdx
00007fb1689d0373  lea edx, [r12d+r8d*1]
00007fb1689d0378  mov r12d, [rsp+0x30]
00007fb1689d037d  xor r12d, ecx
00007fb1689d0380  rorx r8d, edi, 0x19
00007fb1689d0386  xor r14d, r8d
00007fb1689d0389  and r12d, r9d
00007fb1689d038c  rorx r8d, r9d, 0x16
00007fb1689d0392  xor r10d, r8d
00007fb1689d0395  mov [rsp+0x20], r10d
00007fb1689d039a  mov r10d, r10d
00007fb1689d039d  mov [r15+0xD0], r10
00007fb1689d03a4  lea r10d, [edx+esi*1]
00007fb1689d03a9  mov r9d, [rsp+0x10]
00007fb1689d03ae  xor r12d, r9d
00007fb1689d03b1  lea r9d, [r10d+r14d*1]
00007fb1689d03b6  lea r14, [r11+0x04]
00007fb1689d03ba  mov [r15+0x88], r14
00007fb1689d03c1  mov r11d, [rsp+0x20]
00007fb1689d03c6  lea r10d, [r12d+r11d*1]
00007fb1689d03cb  lea r11d, [r9d+eax*1]
00007fb1689d03d0  mov r11d, r11d
00007fb1689d03d3  mov [r15+0xB8], r11
00007fb1689d03da  xor eax, eax
00007fb1689d03dc  mov r12d, 0x100
00007fb1689d03e2  cmp r14, r12
00007fb1689d03e5  cmc
00007fb1689d03e6  lahf
00007fb1689d03e7  seto al
00007fb1689d03ea  mov [r15+0x108], eax
00007fb1689d03f1  lea eax, [r10d+r9d*1]
00007fb1689d03f6  mov eax, eax
00007fb1689d03f8  mov [r15+0xA8], rax
00007fb1689d03ff  mov ebp, ebp
00007fb1689d0401  mov [r15+0xB0], rbp
00007fb1689d0408  mov eax, [rsp+0x50]
00007fb1689d040c  mov eax, eax
00007fb1689d040e  mov [r15+0xC0], rax
00007fb1689d0415  mov edi, edi
00007fb1689d0417  mov [r15+0xC8], rdi
00007fb1689d041e  mov eax, [r15+0x108]
00007fb1689d0425  sahf
00007fb1689d0426  jnz 0x00007FB1689D0458
00007fb1689d0428  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0430  jz 0x00007FB1689D04A0
00007fb1689d0436  nop [rax+rax*1], ax
00007fb1689d043f  nop [rax+rax*1], eax
00007fb1689d0447  mov eax, 0x41094C
00007fb1689d044c  mov [r15+0x100], rax
00007fb1689d0453  jmp 0x00007FB1687FE110
00007fb1689d0458  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0460  jz 0x00007FB1689D0270
00007fb1689d0466  nop [rax+rax*1], ax
00007fb1689d046f  nop [rax+rax*1], eax
00007fb1689d0477  mov eax, 0x4108C0
00007fb1689d047c  mov [r15+0x100], rax
00007fb1689d0483  jmp 0x00007FB1687FE110
00007fb1689d0488  int3
00007fb1689d0489  call 0x00007FB168849010
00007fb1689d048e  jmp 0x00007FB1689D031F
00007fb1689d0493  call 0x00007FB168825930
00007fb1689d0498  jmp 0x00007FB1689D035C
00007fb1689d049d  int3
00007fb1689d049e  nop
00007fb1689d04a0  mov eax, [r15+0x98]
00007fb1689d04a7  mov r14d, [r15+0x70]
00007fb1689d04ab  lea r12d, [eax+r14d*1]
00007fb1689d04b0  mov eax, [r15+0x28]
00007fb1689d04b4  mov r14d, [r15+0x68]
00007fb1689d04b8  lea r11d, [eax+r14d*1]
00007fb1689d04bd  mov qword ptr [r15+0x88], 0x00
00007fb1689d04c8  mov eax, [r15+0xA8]
00007fb1689d04cf  mov r14d, [r15+0x78]
00007fb1689d04d3  lea r10d, [eax+r14d*1]
00007fb1689d04d8  mov [rsp+0x10], r10d
00007fb1689d04dd  mov r10d, r10d
00007fb1689d04e0  mov [r15+0x78], r10
00007fb1689d04e4  mov eax, [r15+0x38]
00007fb1689d04e8  mov r14d, [r15+0x80]
00007fb1689d04ef  lea r10d, [eax+r14d*1]
00007fb1689d04f4  mov [rsp+0x20], r10d
00007fb1689d04f9  mov r10d, r10d
00007fb1689d04fc  mov [r15+0x80], r10
00007fb1689d0503  mov rax, [r15]
00007fb1689d0506  lea r14, [rax+0x08]
00007fb1689d050a  mov [r13+r14*1], r12d
00007fb1689d050f  lea r14, [rax+0x0C]
00007fb1689d0513  mov [r13+r14*1], r11d
00007fb1689d0518  mov r14d, [r15+0xB8]
00007fb1689d051f  mov r12d, [r15+0x18]
00007fb1689d0523  lea r11d, [r14d+r12d*1]
00007fb1689d0528  mov [rsp+0x30], r11d
00007fb1689d052d  mov r11d, r11d
00007fb1689d0530  mov [r15+0x68], r11
00007fb1689d0534  mov r14d, [r15+0x30]
00007fb1689d0538  mov r12d, [r15+0x90]
00007fb1689d053f  lea r11d, [r14d+r12d*1]
00007fb1689d0544  mov [rsp+0x40], r11d
00007fb1689d0549  mov r11d, r11d
00007fb1689d054c  mov [r15+0x70], r11
00007fb1689d0550  mov r14d, [r15+0x20]
00007fb1689d0554  mov r12d, [r15+0x58]
00007fb1689d0558  lea r11d, [r14d+r12d*1]
00007fb1689d055d  mov [rsp+0x50], r11d
00007fb1689d0562  mov r11d, r11d
00007fb1689d0565  mov [r15+0x58], r11
00007fb1689d0569  mov r14d, [r15+0xA0]
00007fb1689d0570  mov r12d, [r15+0x60]
00007fb1689d0574  lea r11d, [r14d+r12d*1]
00007fb1689d0579  mov [rsp+0x60], r11d
00007fb1689d057e  mov r11d, r11d
00007fb1689d0581  mov [r15+0x60], r11
00007fb1689d0585  mov r14d, [rsp+0x10]
00007fb1689d058a  mov [r13+rax*1], r14d
00007fb1689d058f  lea r14, [rax+0x04]
00007fb1689d0593  mov r12d, [rsp+0x20]
00007fb1689d0598  mov [r13+r14*1], r12d
00007fb1689d059d  lea r14, [rax+0x10]
00007fb1689d05a1  mov r12d, [rsp+0x30]
00007fb1689d05a6  mov [r13+r14*1], r12d
00007fb1689d05ab  lea r14, [rax+0x14]
00007fb1689d05af  mov r12d, [rsp+0x40]
00007fb1689d05b4  mov [r13+r14*1], r12d
00007fb1689d05b9  lea r14, [rax+0x18]
00007fb1689d05bd  mov r12d, [rsp+0x50]
00007fb1689d05c2  mov [r13+r14*1], r12d
00007fb1689d05c7  lea r14, [rax+0x1C]
00007fb1689d05cb  mov r12d, [rsp+0x60]
00007fb1689d05d0  mov [r13+r14*1], r12d
00007fb1689d05d5  lea r14, [rax+0x68]
00007fb1689d05d9  xor eax, eax
00007fb1689d05db  mov [r13+r14*1], rax
00007fb1689d05e0  cmp dword ptr [r15+0x318], 0x00
00007fb1689d05e8  jz 0x00007FB1689CF0E0
00007fb1689d05ee  nop [rax+rax*1], ax
00007fb1689d05f7  nop [rax+rax*1], eax
00007fb1689d05ff  mov eax, 0x410768
00007fb1689d0604  mov [r15+0x100], rax
00007fb1689d060b  jmp 0x00007FB1687FE110
00007fb1689d0610  int3
00007fb1689d0611  call 0x00007FB1688E2BA0
00007fb1689d0616  jmp 0x00007FB1689D050F
00007fb1689d061b  call 0x00007FB1688E1920
00007fb1689d0620  jmp 0x00007FB1689D0518
00007fb1689d0625  call 0x00007FB16880DFE0
00007fb1689d062a  jmp 0x00007FB1689D058F
00007fb1689d062f  call 0x00007FB1688E2BA0
00007fb1689d0634  jmp 0x00007FB1689D059D
00007fb1689d0639  call 0x00007FB1688E2BA0
00007fb1689d063e  jmp 0x00007FB1689D05AB
00007fb1689d0643  call 0x00007FB1688E2BA0
00007fb1689d0648  jmp 0x00007FB1689D05B9
00007fb1689d064d  call 0x00007FB1688E2BA0
00007fb1689d0652  jmp 0x00007FB1689D05C7
00007fb1689d0657  call 0x00007FB1688E2BA0
00007fb1689d065c  jmp 0x00007FB1689D05D5
00007fb1689d0661  call 0x00007FB1688D5EB0
00007fb1689d0666  jmp 0x00007FB1689D05E0
00007fb1689d066b  int3
00007fb1689d066c  nop [rax], eax
00007fb1689d0670  mov rax, [r15+0xF8]
00007fb1689d0677  lea r14, [rax+0x140]
00007fb1689d067e  mov r12, [r13+r14*1]
00007fb1689d0683  lea r14, [rax+0x148]
00007fb1689d068a  mov r11, [r13+r14*1]
00007fb1689d068f  mov [r15+0xA0], r12
00007fb1689d0696  mov [r15+0x98], r11
00007fb1689d069d  lea r14, [rax+0x130]
00007fb1689d06a4  mov r12, [r13+r14*1]
00007fb1689d06a9  lea r14, [rax+0x138]
00007fb1689d06b0  mov r11, [r13+r14*1]
00007fb1689d06b5  mov [r15+0xB0], r12
00007fb1689d06bc  mov [r15+0xA8], r11
00007fb1689d06c3  lea r14, [rax+0x120]
00007fb1689d06ca  mov r12, [r13+r14*1]
00007fb1689d06cf  lea r14, [rax+0x128]
00007fb1689d06d6  mov r11, [r13+r14*1]
00007fb1689d06db  mov [r15+0xC0], r12
00007fb1689d06e2  mov [r15+0xB8], r11
00007fb1689d06e9  lea r14, [rax+0x110]
00007fb1689d06f0  mov r12, [r13+r14*1]
00007fb1689d06f5  lea r14, [rax+0x118]
00007fb1689d06fc  mov r11, [r13+r14*1]
00007fb1689d0701  mov [r15+0xD0], r12
00007fb1689d0708  mov [r15+0xC8], r11
00007fb1689d070f  lea r14, [rax+0x100]
00007fb1689d0716  mov r12, [r13+r14*1]
00007fb1689d071b  lea r14, [rax+0x108]
00007fb1689d0722  mov r11, [r13+r14*1]
00007fb1689d0727  mov [r15+0xE8], r12
00007fb1689d072e  mov [r15+0xD8], r11
00007fb1689d0735  lea r14, [rax+0x150]
00007fb1689d073c  mov [r15+0xF8], r14
00007fb1689d0743  mov rax, [r15+0xF0]
00007fb1689d074a  mov [r15+0x100], rax
00007fb1689d0751  jmp 0x00007FB1689CE5C0
00007fb1689d0756  int3
00007fb1689d0757  call 0x00007FB1688E27E0
00007fb1689d075c  jmp 0x00007FB1689D0683
00007fb1689d0761  call 0x00007FB1688E1570
00007fb1689d0766  jmp 0x00007FB1689D068F
00007fb1689d076b  call 0x00007FB1688E27E0
00007fb1689d0770  jmp 0x00007FB1689D06A9
00007fb1689d0775  call 0x00007FB1688E1570
00007fb1689d077a  jmp 0x00007FB1689D06B5
00007fb1689d077f  call 0x00007FB1688E27E0
00007fb1689d0784  jmp 0x00007FB1689D06CF
00007fb1689d0789  call 0x00007FB1688E1570
00007fb1689d078e  jmp 0x00007FB1689D06DB
00007fb1689d0793  call 0x00007FB1688E27E0
00007fb1689d0798  jmp 0x00007FB1689D06F5
00007fb1689d079d  call 0x00007FB1688E1570
00007fb1689d07a2  jmp 0x00007FB1689D0701
00007fb1689d07a7  call 0x00007FB1688E27E0
00007fb1689d07ac  jmp 0x00007FB1689D071B
00007fb1689d07b1  call 0x00007FB1688E1570
00007fb1689d07b6  jmp 0x00007FB1689D0727
00007fb1689d07bb  int3
00007fb1689d07bc  nop [rax], eax
00007fb1689d07c0  mov eax, [r15+0xA0]
00007fb1689d07c7  mov [rsp+0x10], eax
00007fb1689d07cb  xor eax, eax
00007fb1689d07cd  mov r14d, [rsp+0x10]
00007fb1689d07d2  sub r14d, 0x01
00007fb1689d07d6  cmc
00007fb1689d07d7  lahf
00007fb1689d07d8  seto al
00007fb1689d07db  mov [r15+0x108], eax
00007fb1689d07e2  mov r14d, r14d
00007fb1689d07e5  mov [r15+0xA0], r14
00007fb1689d07ec  mov eax, [r15+0x108]
00007fb1689d07f3  sahf
00007fb1689d07f4  jnz 0x00007FB1689D0826
00007fb1689d07f6  cmp dword ptr [r15+0x318], 0x00
00007fb1689d07fe  jz 0x00007FB1689D0900
00007fb1689d0804  nop [rax+rax*1], ax
00007fb1689d080d  nop [rax+rax*1], eax
00007fb1689d0815  mov eax, 0x41028C
00007fb1689d081a  mov [r15+0x100], rax
00007fb1689d0821  jmp 0x00007FB1687FE110
00007fb1689d0826  cmp dword ptr [r15+0x318], 0x00
00007fb1689d082e  jz 0x00007FB1689D0860
00007fb1689d0834  nop [rax+rax*1], ax
00007fb1689d083d  nop [rax+rax*1], eax
00007fb1689d0845  mov eax, 0x410274
00007fb1689d084a  mov [r15+0x100], rax
00007fb1689d0851  jmp 0x00007FB1687FE110
00007fb1689d0856  int3
00007fb1689d0857  int3
00007fb1689d0858  nop [rax+rax*1], eax
00007fb1689d0860  mov rax, [r15+0xF8]
00007fb1689d0867  lea r14, [rax+0x100]
00007fb1689d086e  mov [r15], r14
00007fb1689d0871  mov rax, [r15+0x98]
00007fb1689d0878  mov [r15+0x08], rax
00007fb1689d087c  mov qword ptr [r15+0x10], 0x12C
00007fb1689d0884  mov qword ptr [r15+0xF0], 0x410284
00007fb1689d088f  mov r14d, [r15+0x320]
00007fb1689d0896  mov eax, 0x410284
00007fb1689d089b  mov rcx, 0x7FB1689D07C0
00007fb1689d08a5  mov [r15+r14*8+0x328], rax
00007fb1689d08ad  mov [r15+r14*8+0x368], rcx
00007fb1689d08b5  add r14d, 0x01
00007fb1689d08b9  and r14d, 0x07
00007fb1689d08bd  mov [r15+0x320], r14d
00007fb1689d08c4  cmp dword ptr [r15+0x318], 0x00
00007fb1689d08cc  jz 0x00007FB1689CED70
00007fb1689d08d2  nop [rax+rax*1], ax
00007fb1689d08db  nop [rax+rax*1], eax
00007fb1689d08e3  mov eax, 0x410728
00007fb1689d08e8  mov [r15+0x100], rax
00007fb1689d08ef  jmp 0x00007FB1687FE110
00007fb1689d08f4  int3
00007fb1689d08f5  int3
00007fb1689d08f6  nop [rax+rax*1], ax
00007fb1689d08ff  nop
00007fb1689d0900  mov rax, [r15+0xF8]
00007fb1689d0907  lea r14, [rax+0x120]
00007fb1689d090e  mov r12, [r13+r14*1]
00007fb1689d0913  mov [r15+0x98], r12
00007fb1689d091a  mov qword ptr [r15+0x40], 0x80
00007fb1689d0922  lea r14, [rax+0x100]
00007fb1689d0929  mov [r15], r14
00007fb1689d092c  lea r14, [rax+0x17C]
00007fb1689d0933  mov [r15+0x08], r14
00007fb1689d0937  mov qword ptr [r15+0x10], 0x01
00007fb1689d093f  lea r14, [rax+0x17C]
00007fb1689d0946  mov eax, 0x80
00007fb1689d094b  mov [r13+r14*1], al
00007fb1689d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007fb1689d095b  mov r14d, [r15+0x320]
00007fb1689d0962  mov eax, 0x4102A8
00007fb1689d0967  mov rcx, 0x7FB1689D09E0
00007fb1689d0971  mov [r15+r14*8+0x328], rax
00007fb1689d0979  mov [r15+r14*8+0x368], rcx
00007fb1689d0981  add r14d, 0x01
00007fb1689d0985  and r14d, 0x07
00007fb1689d0989  mov [r15+0x320], r14d
00007fb1689d0990  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0998  jz 0x00007FB1689CED70
00007fb1689d099e  nop [rax+rax*1], ax
00007fb1689d09a7  nop [rax+rax*1], eax
00007fb1689d09af  mov eax, 0x410728
00007fb1689d09b4  mov [r15+0x100], rax
00007fb1689d09bb  jmp 0x00007FB1687FE110
00007fb1689d09c0  int3
00007fb1689d09c1  call 0x00007FB1688E27E0
00007fb1689d09c6  jmp 0x00007FB1689D0913
00007fb1689d09cb  call 0x00007FB1688D5AF0
00007fb1689d09d0  jmp 0x00007FB1689D0950
00007fb1689d09d5  int3
00007fb1689d09d6  nop [rax+rax*1], ax
00007fb1689d09df  nop
00007fb1689d09e0  mov rax, [r15+0xF8]
00007fb1689d09e7  lea r14, [rax+0x168]
00007fb1689d09ee  mov r12, [r13+r14*1]
00007fb1689d09f3  mov [r15+0x40], r12
00007fb1689d09f7  lea r14, [rax+0x178]
00007fb1689d09fe  xor eax, eax
00007fb1689d0a00  mov [r13+r14*1], al
00007fb1689d0a05  xor eax, eax
00007fb1689d0a07  mov r14d, 0x38
00007fb1689d0a0d  cmp r12, r14
00007fb1689d0a10  cmc
00007fb1689d0a11  lahf
00007fb1689d0a12  seto al
00007fb1689d0a15  mov [r15+0x108], eax
00007fb1689d0a1c  mov eax, [r15+0x108]
00007fb1689d0a23  sahf
00007fb1689d0a24  jz 0x00007FB1689D0A56
00007fb1689d0a26  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0a2e  jz 0x00007FB1689D0AA0
00007fb1689d0a34  nop [rax+rax*1], ax
00007fb1689d0a3d  nop [rax+rax*1], eax
00007fb1689d0a45  mov eax, 0x4102B8
00007fb1689d0a4a  mov [r15+0x100], rax
00007fb1689d0a51  jmp 0x00007FB1687FE110
00007fb1689d0a56  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0a5e  jz 0x00007FB1689D0BF0
00007fb1689d0a64  nop [rax+rax*1], ax
00007fb1689d0a6d  nop [rax+rax*1], eax
00007fb1689d0a75  mov eax, 0x4102D4
00007fb1689d0a7a  mov [r15+0x100], rax
00007fb1689d0a81  jmp 0x00007FB1687FE110
00007fb1689d0a86  int3
00007fb1689d0a87  call 0x00007FB1688E27E0
00007fb1689d0a8c  jmp 0x00007FB1689D09F3
00007fb1689d0a91  call 0x00007FB1688D5AF0
00007fb1689d0a96  jmp 0x00007FB1689D0A05
00007fb1689d0a9b  int3
00007fb1689d0a9c  nop [rax], eax
00007fb1689d0aa0  mov rax, [r15+0xF8]
00007fb1689d0aa7  lea r14, [rax+0x100]
00007fb1689d0aae  mov [r15], r14
00007fb1689d0ab1  lea r14, [rax+0x178]
00007fb1689d0ab8  mov [r15+0x08], r14
00007fb1689d0abc  mov qword ptr [r15+0x10], 0x01
00007fb1689d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007fb1689d0acf  mov r14d, [r15+0x320]
00007fb1689d0ad6  mov eax, 0x4102C8
00007fb1689d0adb  mov rcx, 0x7FB1689D0B40
00007fb1689d0ae5  mov [r15+r14*8+0x328], rax
00007fb1689d0aed  mov [r15+r14*8+0x368], rcx
00007fb1689d0af5  add r14d, 0x01
00007fb1689d0af9  and r14d, 0x07
00007fb1689d0afd  mov [r15+0x320], r14d
00007fb1689d0b04  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0b0c  jz 0x00007FB1689CED70
00007fb1689d0b12  nop [rax+rax*1], ax
00007fb1689d0b1b  nop [rax+rax*1], eax
00007fb1689d0b23  mov eax, 0x410728
00007fb1689d0b28  mov [r15+0x100], rax
00007fb1689d0b2f  jmp 0x00007FB1687FE110
00007fb1689d0b34  int3
00007fb1689d0b35  int3
00007fb1689d0b36  nop [rax+rax*1], ax
00007fb1689d0b3f  nop
00007fb1689d0b40  mov rax, [r15+0xF8]
00007fb1689d0b47  lea r14, [rax+0x168]
00007fb1689d0b4e  mov rax, [r13+r14*1]
00007fb1689d0b53  mov [r15+0x40], rax
00007fb1689d0b57  mov [rsp+0x10], rax
00007fb1689d0b5c  xor eax, eax
00007fb1689d0b5e  mov r14, [rsp+0x10]
00007fb1689d0b63  mov r12d, 0x38
00007fb1689d0b69  cmp r14, r12
00007fb1689d0b6c  cmc
00007fb1689d0b6d  lahf
00007fb1689d0b6e  seto al
00007fb1689d0b71  mov [r15+0x108], eax
00007fb1689d0b78  mov eax, [r15+0x108]
00007fb1689d0b7f  sahf
00007fb1689d0b80  jnz 0x00007FB1689D0BB2
00007fb1689d0b82  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0b8a  jz 0x00007FB1689D0BF0
00007fb1689d0b90  nop [rax+rax*1], ax
00007fb1689d0b99  nop [rax+rax*1], eax
00007fb1689d0ba1  mov eax, 0x4102D4
00007fb1689d0ba6  mov [r15+0x100], rax
00007fb1689d0bad  jmp 0x00007FB1687FE110
00007fb1689d0bb2  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0bba  jz 0x00007FB1689D0AA0
00007fb1689d0bc0  nop [rax+rax*1], ax
00007fb1689d0bc9  nop [rax+rax*1], eax
00007fb1689d0bd1  mov eax, 0x4102B8
00007fb1689d0bd6  mov [r15+0x100], rax
00007fb1689d0bdd  jmp 0x00007FB1687FE110
00007fb1689d0be2  int3
00007fb1689d0be3  call 0x00007FB1688D59C0
00007fb1689d0be8  jmp 0x00007FB1689D0B53
00007fb1689d0bed  int3
00007fb1689d0bee  nop
00007fb1689d0bf0  mov rax, [r15+0x98]
00007fb1689d0bf7  rorx r14, rax, 0x3D
00007fb1689d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007fb1689d0c01  mov rax, [r15+0xF8]
00007fb1689d0c08  lea r12, [rax+0x100]
00007fb1689d0c0f  mov [r15], r12
00007fb1689d0c12  lea r12, [rax+0x170]
00007fb1689d0c19  mov [r15+0x08], r12
00007fb1689d0c1d  mov qword ptr [r15+0x10], 0x08
00007fb1689d0c25  bswap r14
00007fb1689d0c28  mov [r15+0x40], r14
00007fb1689d0c2c  lea r12, [rax+0x170]
00007fb1689d0c33  mov [r13+r12*1], r14
00007fb1689d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007fb1689d0c43  mov r14d, [r15+0x320]
00007fb1689d0c4a  mov eax, 0x4102F0
00007fb1689d0c4f  mov rcx, 0x7FB1689D0CC0
00007fb1689d0c59  mov [r15+r14*8+0x328], rax
00007fb1689d0c61  mov [r15+r14*8+0x368], rcx
00007fb1689d0c69  add r14d, 0x01
00007fb1689d0c6d  and r14d, 0x07
00007fb1689d0c71  mov [r15+0x320], r14d
00007fb1689d0c78  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0c80  jz 0x00007FB1689CED70
00007fb1689d0c86  nop [rax+rax*1], ax
00007fb1689d0c8f  nop [rax+rax*1], eax
00007fb1689d0c97  mov eax, 0x410728
00007fb1689d0c9c  mov [r15+0x100], rax
00007fb1689d0ca3  jmp 0x00007FB1687FE110
00007fb1689d0ca8  int3
00007fb1689d0ca9  call 0x00007FB1688C3FE0
00007fb1689d0cae  jmp 0x00007FB1689D0C38
00007fb1689d0cb3  int3
00007fb1689d0cb4  nop [rax+rax*1], ax
00007fb1689d0cbd  nop [rax], eax
00007fb1689d0cc0  mov rax, [r15+0xF8]
00007fb1689d0cc7  lea r14, [rax+0x100]
00007fb1689d0cce  mov r12d, [r13+r14*1]
00007fb1689d0cd3  lea r14, [rax+0x104]
00007fb1689d0cda  mov r11d, [r13+r14*1]
00007fb1689d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007fb1689d0ce7  lea r14, [rax+0x108]
00007fb1689d0cee  mov r10d, [r13+r14*1]
00007fb1689d0cf3  lea r14, [rax+0x10C]
00007fb1689d0cfa  mov r9d, [r13+r14*1]
00007fb1689d0cff  bswap r12d
00007fb1689d0d02  bswap r11d
00007fb1689d0d05  mov qword ptr [r15+0xA0], 0x00
00007fb1689d0d10  mov r14d, 0x430C90
00007fb1689d0d16  mov [r13+r14*1], r12d
00007fb1689d0d1b  mov r14d, 0x430C94
00007fb1689d0d21  mov [r13+r14*1], r11d
00007fb1689d0d26  bswap r10d
00007fb1689d0d29  lea r14, [rax+0x110]
00007fb1689d0d30  mov r12d, [r13+r14*1]
00007fb1689d0d35  bswap r9d
00007fb1689d0d38  lea r14, [rax+0x114]
00007fb1689d0d3f  mov r11d, [r13+r14*1]
00007fb1689d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007fb1689d0d4f  mov r14d, 0x430C98
00007fb1689d0d55  mov [r13+r14*1], r10d
00007fb1689d0d5a  mov r14d, 0x430C9C
00007fb1689d0d60  mov [r13+r14*1], r9d
00007fb1689d0d65  bswap r12d
00007fb1689d0d68  lea r14, [rax+0x118]
00007fb1689d0d6f  mov r10d, [r13+r14*1]
00007fb1689d0d74  bswap r11d
00007fb1689d0d77  mov [rsp+0x10], r11d
00007fb1689d0d7c  mov r11d, r11d
00007fb1689d0d7f  mov [r15+0x58], r11
00007fb1689d0d83  lea r14, [rax+0x11C]
00007fb1689d0d8a  mov eax, [r13+r14*1]
00007fb1689d0d8f  mov [rsp+0x20], eax
00007fb1689d0d93  mov eax, eax
00007fb1689d0d95  mov [r15+0x60], rax
00007fb1689d0d99  mov eax, 0x430CA0
00007fb1689d0d9e  mov [r13+rax*1], r12d
00007fb1689d0da3  mov eax, 0x430CA4
00007fb1689d0da8  mov r14d, [rsp+0x10]
00007fb1689d0dad  mov [r13+rax*1], r14d
00007fb1689d0db2  bswap r10d
00007fb1689d0db5  mov [rsp+0x10], r10d
00007fb1689d0dba  mov r10d, r10d
00007fb1689d0dbd  mov [r15+0x40], r10
00007fb1689d0dc1  mov eax, [rsp+0x20]
00007fb1689d0dc5  bswap eax
00007fb1689d0dc7  mov [rsp+0x20], eax
00007fb1689d0dcb  mov eax, eax
00007fb1689d0dcd  mov [r15+0x50], rax
00007fb1689d0dd1  mov eax, 0x430CA8
00007fb1689d0dd6  mov r14d, [rsp+0x10]
00007fb1689d0ddb  mov [r13+rax*1], r14d
00007fb1689d0de0  mov eax, 0x430CAC
00007fb1689d0de5  mov r14d, [rsp+0x20]
00007fb1689d0dea  mov [r13+rax*1], r14d
00007fb1689d0def  mov eax, [r15+0xA0]
00007fb1689d0df6  lea r14d, [eax+0x11]
00007fb1689d0dfb  mov r14d, r14d
00007fb1689d0dfe  mov [r15], r14
00007fb1689d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007fb1689d0e0c  mov r14d, [r15+0x320]
00007fb1689d0e13  mov eax, 0x41035C
00007fb1689d0e18  mov rcx, 0x7FB1689D0F90
00007fb1689d0e22  mov [r15+r14*8+0x328], rax
00007fb1689d0e2a  mov [r15+r14*8+0x368], rcx
00007fb1689d0e32  add r14d, 0x01
00007fb1689d0e36  and r14d, 0x07
00007fb1689d0e3a  mov [r15+0x320], r14d
00007fb1689d0e41  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0e49  jz 0x00007FB1689D0F20
00007fb1689d0e4f  nop [rax+rax*1], ax
00007fb1689d0e58  nop [rax+rax*1], eax
00007fb1689d0e60  mov eax, 0x4109A4
00007fb1689d0e65  mov [r15+0x100], rax
00007fb1689d0e6c  jmp 0x00007FB1687FE110
00007fb1689d0e71  int3
00007fb1689d0e72  call 0x00007FB1688E26A0
00007fb1689d0e77  jmp 0x00007FB1689D0CD3
00007fb1689d0e7c  call 0x00007FB1688E1430
00007fb1689d0e81  jmp 0x00007FB1689D0CDF
00007fb1689d0e86  call 0x00007FB1688E01C0
00007fb1689d0e8b  jmp 0x00007FB1689D0CF3
00007fb1689d0e90  call 0x00007FB1688DEF50
00007fb1689d0e95  jmp 0x00007FB1689D0CFF
00007fb1689d0e9a  call 0x00007FB1688E2BA0
00007fb1689d0e9f  jmp 0x00007FB1689D0D1B
00007fb1689d0ea4  call 0x00007FB1688E1920
00007fb1689d0ea9  jmp 0x00007FB1689D0D26
00007fb1689d0eae  call 0x00007FB1688E26A0
00007fb1689d0eb3  jmp 0x00007FB1689D0D35
00007fb1689d0eb8  call 0x00007FB1688E1430
00007fb1689d0ebd  jmp 0x00007FB1689D0D44
00007fb1689d0ec2  call 0x00007FB1688E06B0
00007fb1689d0ec7  jmp 0x00007FB1689D0D5A
00007fb1689d0ecc  call 0x00007FB1688DF440
00007fb1689d0ed1  jmp 0x00007FB1689D0D65
00007fb1689d0ed6  call 0x00007FB1688E01C0
00007fb1689d0edb  jmp 0x00007FB1689D0D74
00007fb1689d0ee0  call 0x00007FB1688D5890
00007fb1689d0ee5  jmp 0x00007FB1689D0D8F
00007fb1689d0eea  call 0x00007FB16880BAE0
00007fb1689d0eef  jmp 0x00007FB1689D0DA3
00007fb1689d0ef4  call 0x00007FB16880DFE0
00007fb1689d0ef9  jmp 0x00007FB1689D0DB2
00007fb1689d0efe  call 0x00007FB16880DFE0
00007fb1689d0f03  jmp 0x00007FB1689D0DE0
00007fb1689d0f08  call 0x00007FB16880DFE0
00007fb1689d0f0d  jmp 0x00007FB1689D0DEF
00007fb1689d0f12  int3
00007fb1689d0f13  nop [rax+rax*1], ax
00007fb1689d0f1c  nop [rax], eax
00007fb1689d0f20  mov eax, [r15]
00007fb1689d0f23  mov [rsp+0x10], eax
00007fb1689d0f27  shr eax, 0x10
00007fb1689d0f2a  mov r14d, [rsp+0x10]
00007fb1689d0f2f  xor r14d, eax
00007fb1689d0f32  imul r14d, r14d, 0x7FEB352D
00007fb1689d0f39  mov eax, 0x846CA68B
00007fb1689d0f3e  mov eax, eax
00007fb1689d0f40  mov [r15+0x48], rax
00007fb1689d0f44  mov [rsp+0x10], r14d
00007fb1689d0f49  shr r14d, 0x0F
00007fb1689d0f4d  mov eax, [rsp+0x10]
00007fb1689d0f51  xor eax, r14d
00007fb1689d0f54  imul eax, eax, 0x846CA68B
00007fb1689d0f5a  mov [rsp+0x10], eax
00007fb1689d0f5e  mov eax, eax
00007fb1689d0f60  mov [r15+0x40], rax
00007fb1689d0f64  mov eax, [rsp+0x10]
00007fb1689d0f68  shr eax, 0x10
00007fb1689d0f6b  mov r14d, [rsp+0x10]
00007fb1689d0f70  xor r14d, eax
00007fb1689d0f73  mov r14d, r14d
00007fb1689d0f76  mov [r15], r14
00007fb1689d0f79  mov rax, [r15+0xF0]
00007fb1689d0f80  mov [r15+0x100], rax
00007fb1689d0f87  jmp 0x00007FB1689CE5C0
00007fb1689d0f8c  int3
00007fb1689d0f8d  int3
00007fb1689d0f8e  nop
00007fb1689d0f90  mov rax, [r15+0xA0]
00007fb1689d0f97  mov [rsp+0x10], rax
00007fb1689d0f9c  shl rax, 0x02
00007fb1689d0fa0  mov r14, [r15+0x98]
00007fb1689d0fa7  lea r12, [r14+rax*1]
00007fb1689d0fab  mov eax, [r15]
00007fb1689d0fae  mov [r13+r12*1], eax
00007fb1689d0fb3  mov rax, [rsp+0x10]
00007fb1689d0fb8  lea r14, [rax+0x01]
00007fb1689d0fbc  mov [r15+0xA0], r14
00007fb1689d0fc3  xor eax, eax
00007fb1689d0fc5  mov r12d, 0x400
00007fb1689d0fcb  cmp r14, r12
00007fb1689d0fce  cmc
00007fb1689d0fcf  lahf
00007fb1689d0fd0  seto al
00007fb1689d0fd3  mov [r15+0x108], eax
00007fb1689d0fda  mov eax, [r15+0x108]
00007fb1689d0fe1  sahf
00007fb1689d0fe2  jnz 0x00007FB1689D1014
00007fb1689d0fe4  cmp dword ptr [r15+0x318], 0x00
00007fb1689d0fec  jz 0x00007FB1689D10E0
00007fb1689d0ff2  nop [rax+rax*1], ax
00007fb1689d0ffb  nop [rax+rax*1], eax
00007fb1689d1003  mov eax, 0x41036C
00007fb1689d1008  mov [r15+0x100], rax
00007fb1689d100f  jmp 0x00007FB1687FE110
00007fb1689d1014  cmp dword ptr [r15+0x318], 0x00
00007fb1689d101c  jz 0x00007FB1689D1050
00007fb1689d1022  nop [rax+rax*1], ax
00007fb1689d102b  nop [rax+rax*1], eax
00007fb1689d1033  mov eax, 0x410354
00007fb1689d1038  mov [r15+0x100], rax
00007fb1689d103f  jmp 0x00007FB1687FE110
00007fb1689d1044  int3
00007fb1689d1045  call 0x00007FB1688B4B70
00007fb1689d104a  jmp 0x00007FB1689D0FB3
00007fb1689d104f  int3
00007fb1689d1050  mov eax, [r15+0xA0]
00007fb1689d1057  lea r14d, [eax+0x11]
00007fb1689d105c  mov r14d, r14d
00007fb1689d105f  mov [r15], r14
00007fb1689d1062  mov qword ptr [r15+0xF0], 0x41035C
00007fb1689d106d  mov r14d, [r15+0x320]
00007fb1689d1074  mov eax, 0x41035C
00007fb1689d1079  mov rcx, 0x7FB1689D0F90
00007fb1689d1083  mov [r15+r14*8+0x328], rax
00007fb1689d108b  mov [r15+r14*8+0x368], rcx
00007fb1689d1093  add r14d, 0x01
00007fb1689d1097  and r14d, 0x07
00007fb1689d109b  mov [r15+0x320], r14d
00007fb1689d10a2  cmp dword ptr [r15+0x318], 0x00
00007fb1689d10aa  jz 0x00007FB1689D0F20
00007fb1689d10b0  nop [rax+rax*1], ax
00007fb1689d10b9  nop [rax+rax*1], eax
00007fb1689d10c1  mov eax, 0x4109A4
00007fb1689d10c6  mov [r15+0x100], rax
00007fb1689d10cd  jmp 0x00007FB1687FE110
00007fb1689d10d2  int3
00007fb1689d10d3  int3
00007fb1689d10d4  nop [rax+rax*1], ax
00007fb1689d10dd  nop [rax], eax
00007fb1689d10e0  mov qword ptr [r15+0x40], 0x01
00007fb1689d10e8  cmp dword ptr [r15+0x318], 0x00
00007fb1689d10f0  jz 0x00007FB1689D1120
00007fb1689d10f6  nop [rax+rax*1], ax
00007fb1689d10ff  nop [rax+rax*1], eax
00007fb1689d1107  mov eax, 0x410388
00007fb1689d110c  mov [r15+0x100], rax
00007fb1689d1113  jmp 0x00007FB1687FE110
00007fb1689d1118  int3
00007fb1689d1119  int3
00007fb1689d111a  nop [rax+rax*1], ax
00007fb1689d1120  mov rax, [r15+0x40]
00007fb1689d1124  mov [rsp+0x10], rax
00007fb1689d1129  shl rax, 0x02
00007fb1689d112d  mov r14, [r15+0x98]
00007fb1689d1134  lea r12, [r14+rax*1]
00007fb1689d1138  mov eax, [r13+r12*1]
00007fb1689d113d  mov [rsp+0x20], eax
00007fb1689d1141  mov eax, eax
00007fb1689d1143  mov [r15+0x48], rax
00007fb1689d1147  mov rax, [rsp+0x10]
00007fb1689d114c  mov [r15+0x50], rax
00007fb1689d1150  mov eax, [r15+0x50]
00007fb1689d1154  lea r12d, [eax-0x01]
00007fb1689d1159  mov r12d, r12d
00007fb1689d115c  mov [r15+0x58], r12
00007fb1689d1160  mov rax, [r15+0x58]
00007fb1689d1164  mov r12d, eax
00007fb1689d1167  mov r12d, r12d
00007fb1689d116a  shl r12, 0x02
00007fb1689d116e  lea rax, [r14+r12*1]
00007fb1689d1172  mov r14d, [r13+rax*1]
00007fb1689d1177  mov [rsp+0x10], r14d
00007fb1689d117c  mov r14d, r14d
00007fb1689d117f  mov [r15+0x60], r14
00007fb1689d1183  xor eax, eax
00007fb1689d1185  mov r14d, [rsp+0x10]
00007fb1689d118a  mov r12d, [rsp+0x20]
00007fb1689d118f  cmp r14d, r12d
00007fb1689d1192  cmc
00007fb1689d1193  lahf
00007fb1689d1194  seto al
00007fb1689d1197  mov [r15+0x108], eax
00007fb1689d119e  mov eax, [r15+0x108]
00007fb1689d11a5  sahf
00007fb1689d11a6  cmc
00007fb1689d11a7  jbe 0x00007FB1689D11D9
00007fb1689d11a9  cmp dword ptr [r15+0x318], 0x00
00007fb1689d11b1  jz 0x00007FB1689D1220
00007fb1689d11b7  nop [rax+rax*1], ax
00007fb1689d11c0  nop [rax+rax*1], eax
00007fb1689d11c8  mov eax, 0x4103A0
00007fb1689d11cd  mov [r15+0x100], rax
00007fb1689d11d4  jmp 0x00007FB1687FE110
00007fb1689d11d9  cmp dword ptr [r15+0x318], 0x00
00007fb1689d11e1  jz 0x00007FB1689D14C0
00007fb1689d11e7  nop [rax+rax*1], ax
00007fb1689d11f0  nop [rax+rax*1], eax
00007fb1689d11f8  mov eax, 0x410378
00007fb1689d11fd  mov [r15+0x100], rax
00007fb1689d1204  jmp 0x00007FB1687FE110
00007fb1689d1209  int3
00007fb1689d120a  call 0x00007FB1688B4690
00007fb1689d120f  jmp 0x00007FB1689D113D
00007fb1689d1214  call 0x00007FB16880DAE0
00007fb1689d1219  jmp 0x00007FB1689D1177
00007fb1689d121e  int3
00007fb1689d121f  nop
00007fb1689d1220  mov rax, [r15+0x50]
00007fb1689d1224  mov [rsp+0x10], rax
00007fb1689d1229  shl rax, 0x02
00007fb1689d122d  mov r14, [r15+0x98]
00007fb1689d1234  lea r12, [r14+rax*1]
00007fb1689d1238  mov eax, [r15+0x60]
00007fb1689d123c  mov [r13+r12*1], eax
00007fb1689d1241  mov rax, [rsp+0x10]
00007fb1689d1246  lea r14, [rax-0x01]
00007fb1689d124a  mov [r15+0x50], r14
00007fb1689d124e  mov rax, [r15+0x58]
00007fb1689d1252  test rax, rax
00007fb1689d1255  setz al
00007fb1689d1258  movzx rax, al
00007fb1689d125c  mov [rsp+0x414], al
00007fb1689d1263  cmp byte ptr [rsp+0x414], 0x00
00007fb1689d126b  jz 0x00007FB1689D129D
00007fb1689d126d  cmp dword ptr [r15+0x318], 0x00
00007fb1689d1275  jz 0x00007FB1689D12E0
00007fb1689d127b  nop [rax+rax*1], ax
00007fb1689d1284  nop [rax+rax*1], eax
00007fb1689d128c  mov eax, 0x4103AC
00007fb1689d1291  mov [r15+0x100], rax
00007fb1689d1298  jmp 0x00007FB1687FE110
00007fb1689d129d  cmp dword ptr [r15+0x318], 0x00
00007fb1689d12a5  jz 0x00007FB1689D13E0
00007fb1689d12ab  nop [rax+rax*1], ax
00007fb1689d12b4  nop [rax+rax*1], eax
00007fb1689d12bc  mov eax, 0x410390
00007fb1689d12c1  mov [r15+0x100], rax
00007fb1689d12c8  jmp 0x00007FB1687FE110
00007fb1689d12cd  int3
00007fb1689d12ce  call 0x00007FB1688B4B70
00007fb1689d12d3  jmp 0x00007FB1689D1241
00007fb1689d12d8  int3
00007fb1689d12d9  nop [rax], eax
00007fb1689d12e0  cmp dword ptr [r15+0x318], 0x00
00007fb1689d12e8  jz 0x00007FB1689D1320
00007fb1689d12ee  nop [rax+rax*1], ax
00007fb1689d12f7  nop [rax+rax*1], eax
00007fb1689d12ff  mov eax, 0x410374
00007fb1689d1304  mov [r15+0x100], rax
00007fb1689d130b  jmp 0x00007FB1687FE110
00007fb1689d1310  int3
00007fb1689d1311  int3
00007fb1689d1312  nop [rax+rax*1], ax
00007fb1689d131b  nop [rax+rax*1], eax
00007fb1689d1320  mov qword ptr [r15+0x50], 0x00
00007fb1689d1328  mov rax, [r15+0x40]
00007fb1689d132c  lea r14, [rax+0x01]
00007fb1689d1330  mov [r15+0x40], r14
00007fb1689d1334  mov rax, [r15+0x98]
00007fb1689d133b  mov r12d, [r15+0x48]
00007fb1689d133f  mov [r13+rax*1], r12d
00007fb1689d1344  xor eax, eax
00007fb1689d1346  mov r12d, 0x400
00007fb1689d134c  cmp r14, r12
00007fb1689d134f  cmc
00007fb1689d1350  lahf
00007fb1689d1351  seto al
00007fb1689d1354  mov [r15+0x108], eax
00007fb1689d135b  mov eax, [r15+0x108]
00007fb1689d1362  sahf
00007fb1689d1363  jz 0x00007FB1689D1395
00007fb1689d1365  cmp dword ptr [r15+0x318], 0x00
00007fb1689d136d  jz 0x00007FB1689D1120
00007fb1689d1373  nop [rax+rax*1], ax
00007fb1689d137c  nop [rax+rax*1], eax
00007fb1689d1384  mov eax, 0x410388
00007fb1689d1389  mov [r15+0x100], rax
00007fb1689d1390  jmp 0x00007FB1687FE110
00007fb1689d1395  cmp dword ptr [r15+0x318], 0x00
00007fb1689d139d  jz 0x00007FB1689D1580
00007fb1689d13a3  nop [rax+rax*1], ax
00007fb1689d13ac  nop [rax+rax*1], eax
00007fb1689d13b4  mov eax, 0x4103B0
00007fb1689d13b9  mov [r15+0x100], rax
00007fb1689d13c0  jmp 0x00007FB1687FE110
00007fb1689d13c5  int3
00007fb1689d13c6  call 0x00007FB16880BAE0
00007fb1689d13cb  jmp 0x00007FB1689D1344
00007fb1689d13d0  int3
00007fb1689d13d1  nop [rax+rax*1], ax
00007fb1689d13da  nop [rax+rax*1], ax
00007fb1689d13e0  mov eax, [r15+0x50]
00007fb1689d13e4  lea r14d, [eax-0x01]
00007fb1689d13e9  mov r14d, r14d
00007fb1689d13ec  mov [r15+0x58], r14
00007fb1689d13f0  mov rax, [r15+0x58]
00007fb1689d13f4  mov r14d, eax
00007fb1689d13f7  mov r14d, r14d
00007fb1689d13fa  shl r14, 0x02
00007fb1689d13fe  mov rax, [r15+0x98]
00007fb1689d1405  lea r12, [rax+r14*1]
00007fb1689d1409  mov eax, [r13+r12*1]
00007fb1689d140e  mov [rsp+0x10], eax
00007fb1689d1412  mov eax, eax
00007fb1689d1414  mov [r15+0x60], rax
00007fb1689d1418  mov eax, [r15+0x48]
00007fb1689d141c  mov [rsp+0x20], eax
00007fb1689d1420  xor eax, eax
00007fb1689d1422  mov r14d, [rsp+0x10]
00007fb1689d1427  mov r12d, [rsp+0x20]
00007fb1689d142c  cmp r14d, r12d
00007fb1689d142f  cmc
00007fb1689d1430  lahf
00007fb1689d1431  seto al
00007fb1689d1434  mov [r15+0x108], eax
00007fb1689d143b  mov eax, [r15+0x108]
00007fb1689d1442  sahf
00007fb1689d1443  cmc
00007fb1689d1444  jbe 0x00007FB1689D1476
00007fb1689d1446  cmp dword ptr [r15+0x318], 0x00
00007fb1689d144e  jz 0x00007FB1689D1220
00007fb1689d1454  nop [rax+rax*1], ax
00007fb1689d145d  nop [rax+rax*1], eax
00007fb1689d1465  mov eax, 0x4103A0
00007fb1689d146a  mov [r15+0x100], rax
00007fb1689d1471  jmp 0x00007FB1687FE110
00007fb1689d1476  cmp dword ptr [r15+0x318], 0x00
00007fb1689d147e  jz 0x00007FB1689D14C0
00007fb1689d1484  nop [rax+rax*1], ax
00007fb1689d148d  nop [rax+rax*1], eax
00007fb1689d1495  mov eax, 0x410378
00007fb1689d149a  mov [r15+0x100], rax
00007fb1689d14a1  jmp 0x00007FB1687FE110
00007fb1689d14a6  int3
00007fb1689d14a7  call 0x00007FB1688B4690
00007fb1689d14ac  jmp 0x00007FB1689D140E
00007fb1689d14b1  int3
00007fb1689d14b2  nop [rax+rax*1], ax
00007fb1689d14bb  nop [rax+rax*1], eax
00007fb1689d14c0  mov rax, [r15+0x40]
00007fb1689d14c4  lea r14, [rax+0x01]
00007fb1689d14c8  mov [r15+0x40], r14
00007fb1689d14cc  mov rax, [r15+0x50]
00007fb1689d14d0  mov r12d, eax
00007fb1689d14d3  mov r12d, r12d
00007fb1689d14d6  shl r12, 0x02
00007fb1689d14da  mov rax, [r15+0x98]
00007fb1689d14e1  lea r11, [rax+r12*1]
00007fb1689d14e5  mov eax, [r15+0x48]
00007fb1689d14e9  mov [r13+r11*1], eax
00007fb1689d14ee  xor eax, eax
00007fb1689d14f0  mov r12d, 0x400
00007fb1689d14f6  cmp r14, r12
00007fb1689d14f9  cmc
00007fb1689d14fa  lahf
00007fb1689d14fb  seto al
00007fb1689d14fe  mov [r15+0x108], eax
00007fb1689d1505  mov eax, [r15+0x108]
00007fb1689d150c  sahf
00007fb1689d150d  jz 0x00007FB1689D153F
00007fb1689d150f  cmp dword ptr [r15+0x318], 0x00
00007fb1689d1517  jz 0x00007FB1689D1120
00007fb1689d151d  nop [rax+rax*1], ax
00007fb1689d1526  nop [rax+rax*1], eax
00007fb1689d152e  mov eax, 0x410388
00007fb1689d1533  mov [r15+0x100], rax
00007fb1689d153a  jmp 0x00007FB1687FE110
00007fb1689d153f  cmp dword ptr [r15+0x318], 0x00
00007fb1689d1547  jz 0x00007FB1689D1580
00007fb1689d154d  nop [rax+rax*1], ax
00007fb1689d1556  nop [rax+rax*1], eax
00007fb1689d155e  mov eax, 0x4103B0
00007fb1689d1563  mov [r15+0x100], rax
00007fb1689d156a  jmp 0x00007FB1687FE110
00007fb1689d156f  int3
00007fb1689d1570  call 0x00007FB1688A4270
00007fb1689d1575  jmp 0x00007FB1689D14EE
00007fb1689d157a  int3
00007fb1689d157b  nop [rax+rax*1], eax
00007fb1689d1580  mov qword ptr [r15+0x40], 0x430000
00007fb1689d1588  mov eax, 0x430CB0
00007fb1689d158d  mov r14, [r13+rax*1]
00007fb1689d1592  mov rax, [r15+0x98]
00007fb1689d1599  mov r12d, [r13+rax*1]
00007fb1689d159e  lea r11, [rax+0x04]
00007fb1689d15a2  mov eax, [r13+r11*1]
00007fb1689d15a7  mov r12d, r12d
00007fb1689d15aa  mov [r15+0x68], r12
00007fb1689d15ae  mov eax, eax
00007fb1689d15b0  mov [r15+0x60], rax
00007fb1689d15b4  mov rax, [r15+0x68]
00007fb1689d15b8  mov [r15+0x68], rax
00007fb1689d15bc  mov qword ptr [r15+0x58], 0x02
00007fb1689d15c4  mov [rsp+0x10], rax
00007fb1689d15c9  xor eax, eax
00007fb1689d15cb  mov r12d, 0x02
00007fb1689d15d1  mov r11d, 0x400
00007fb1689d15d7  cmp r12, r11
00007fb1689d15da  cmc
00007fb1689d15db  lahf
00007fb1689d15dc  seto al
00007fb1689d15df  mov [r15+0x108], eax
00007fb1689d15e6  mov rax, [r15+0x60]
00007fb1689d15ea  mov r12d, 0x02
00007fb1689d15f0  imul rax, r12
00007fb1689d15f4  mov [r15+0x50], rax
00007fb1689d15f8  mov rax, [rsp+0x10]
00007fb1689d15fd  lea r12, [rax+r14*1]
00007fb1689d1601  mov [r15+0x48], r12
00007fb1689d1605  mov eax, [r15+0x108]
00007fb1689d160c  sahf
00007fb1689d160d  jnz 0x00007FB1689D163F
00007fb1689d160f  cmp dword ptr [r15+0x318], 0x00
00007fb1689d1617  jz 0x00007FB1689D17B0
00007fb1689d161d  nop [rax+rax*1], ax
00007fb1689d1626  nop [rax+rax*1], eax
00007fb1689d162e  mov eax, 0x4103E0
00007fb1689d1633  mov [r15+0x100], rax
00007fb1689d163a  jmp 0x00007FB1687FE110
00007fb1689d163f  cmp dword ptr [r15+0x318], 0x00
00007fb1689d1647  jz 0x00007FB1689D1690
00007fb1689d164d  nop [rax+rax*1], ax
00007fb1689d1656  nop [rax+rax*1], eax
00007fb1689d165e  mov eax, 0x4103C0
00007fb1689d1663  mov [r15+0x100], rax
00007fb1689d166a  jmp 0x00007FB1687FE110
00007fb1689d166f  int3
00007fb1689d1670  call 0x00007FB16880DC20
00007fb1689d1675  jmp 0x00007FB1689D1592
00007fb1689d167a  call 0x00007FB16880B5E0
00007fb1689d167f  jmp 0x00007FB1689D159E
00007fb1689d1684  call 0x00007FB1688A3D90
00007fb1689d1689  jmp 0x00007FB1689D15A7
00007fb1689d168e  int3
00007fb1689d168f  nop
00007fb1689d1690  mov rax, [r15+0x98]
00007fb1689d1697  mov r14, [r15+0x58]
00007fb1689d169b  mov [rsp+0x10], r14
00007fb1689d16a0  shl r14, 0x02
00007fb1689d16a4  lea r12, [rax+r14*1]
00007fb1689d16a8  mov eax, [r13+r12*1]
00007fb1689d16ad  lea r14, [r12+0x04]
00007fb1689d16b2  mov r12d, [r13+r14*1]
00007fb1689d16b7  mov eax, eax
00007fb1689d16b9  mov [r15+0x68], rax
00007fb1689d16bd  mov r12d, r12d
00007fb1689d16c0  mov [r15+0x60], r12
00007fb1689d16c4  mov rax, [r15+0x68]
00007fb1689d16c8  mov [rsp+0x20], rax
00007fb1689d16cd  mov r14, [rsp+0x10]
00007fb1689d16d2  imul rax, r14
00007fb1689d16d6  mov r12, [rsp+0x20]
00007fb1689d16db  lea r11, [r12+rax*1]
00007fb1689d16df  mov [r15+0x68], r11
00007fb1689d16e3  lea rax, [r14+0x02]
00007fb1689d16e7  mov [r15+0x58], rax
00007fb1689d16eb  mov [rsp+0x10], rax
00007fb1689d16f0  xor eax, eax
00007fb1689d16f2  mov r14, [rsp+0x10]
00007fb1689d16f7  mov r12d, 0x400
00007fb1689d16fd  cmp r14, r12
00007fb1689d1700  cmc
00007fb1689d1701  lahf
00007fb1689d1702  seto al
00007fb1689d1705  mov [r15+0x108], eax
00007fb1689d170c  mov rax, [r15+0x50]
00007fb1689d1710  mov r12, [r15+0x60]
00007fb1689d1714  imul r14, r12
00007fb1689d1718  lea r12, [rax+r14*1]
00007fb1689d171c  mov [r15+0x50], r12
00007fb1689d1720  mov rax, [r15+0x48]
00007fb1689d1724  lea r14, [r11+rax*1]
00007fb1689d1728  mov [r15+0x48], r14
00007fb1689d172c  mov eax, [r15+0x108]
00007fb1689d1733  sahf
00007fb1689d1734  jnz 0x00007FB1689D1766
00007fb1689d1736  cmp dword ptr [r15+0x318], 0x00
00007fb1689d173e  jz 0x00007FB1689D17B0
00007fb1689d1744  nop [rax+rax*1], ax
00007fb1689d174d  nop [rax+rax*1], eax
00007fb1689d1755  mov eax, 0x4103E0
00007fb1689d175a  mov [r15+0x100], rax
00007fb1689d1761  jmp 0x00007FB1687FE110
00007fb1689d1766  cmp dword ptr [r15+0x318], 0x00
00007fb1689d176e  jz 0x00007FB1689D1690
00007fb1689d1774  nop [rax+rax*1], ax
00007fb1689d177d  nop [rax+rax*1], eax
00007fb1689d1785  mov eax, 0x4103C0
00007fb1689d178a  mov [r15+0x100], rax
00007fb1689d1791  jmp 0x00007FB1687FE110
00007fb1689d1796  int3
00007fb1689d1797  call 0x00007FB1688B4690
00007fb1689d179c  jmp 0x00007FB1689D16AD
00007fb1689d17a1  call 0x00007FB1688E26A0
00007fb1689d17a6  jmp 0x00007FB1689D16B7
00007fb1689d17ab  int3
00007fb1689d17ac  nop [rax], eax
00007fb1689d17b0  mov qword ptr [r15+0x98], 0x00
00007fb1689d17bb  mov rax, [r15+0x50]
00007fb1689d17bf  mov r14, [r15+0x48]
00007fb1689d17c3  lea r12, [rax+r14*1]
00007fb1689d17c7  mov [r15+0x48], r12
00007fb1689d17cb  mov rax, [r15+0x40]
00007fb1689d17cf  lea r14, [rax+0xCB0]
00007fb1689d17d6  mov [r13+r14*1], r12
00007fb1689d17db  mov qword ptr [r15], 0x01
00007fb1689d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007fb1689d17ed  mov r14d, [r15+0x320]
00007fb1689d17f4  mov eax, 0x4103F8
00007fb1689d17f9  mov rcx, 0x7FB1689D1860
00007fb1689d1803  mov [r15+r14*8+0x328], rax
00007fb1689d180b  mov [r15+r14*8+0x368], rcx
00007fb1689d1813  add r14d, 0x01
00007fb1689d1817  and r14d, 0x07
00007fb1689d181b  mov [r15+0x320], r14d
00007fb1689d1822  cmp dword ptr [r15+0x318], 0x00
00007fb1689d182a  jz 0x00007FB1689D0F20
00007fb1689d1830  nop [rax+rax*1], ax
00007fb1689d1839  nop [rax+rax*1], eax
00007fb1689d1841  mov eax, 0x4109A4
00007fb1689d1846  mov [r15+0x100], rax
00007fb1689d184d  jmp 0x00007FB1687FE110
00007fb1689d1852  int3
00007fb1689d1853  call 0x00007FB1688E2CE0
00007fb1689d1858  jmp 0x00007FB1689D17DB
00007fb1689d185d  int3
00007fb1689d185e  nop
00007fb1689d1860  mov eax, [r15+0x98]
00007fb1689d1867  lea r14d, [eax+0x01]
00007fb1689d186c  mov [rsp+0x10], r14d
00007fb1689d1871  mov r14d, r14d
00007fb1689d1874  mov [r15+0x98], r14
00007fb1689d187b  xor eax, eax
00007fb1689d187d  mov r14d, [rsp+0x10]
00007fb1689d1882  cmp r14d, 0x10000
00007fb1689d1889  cmc
00007fb1689d188a  lahf
00007fb1689d188b  seto al
00007fb1689d188e  mov [r15+0x108], eax
00007fb1689d1895  mov eax, [r15+0x108]
00007fb1689d189c  sahf
00007fb1689d189d  jnz 0x00007FB1689D18CF
00007fb1689d189f  cmp dword ptr [r15+0x318], 0x00
00007fb1689d18a7  jz 0x00007FB1689D19A0
00007fb1689d18ad  nop [rax+rax*1], ax
00007fb1689d18b6  nop [rax+rax*1], eax
00007fb1689d18be  mov eax, 0x410404
00007fb1689d18c3  mov [r15+0x100], rax
00007fb1689d18ca  jmp 0x00007FB1687FE110
00007fb1689d18cf  cmp dword ptr [r15+0x318], 0x00
00007fb1689d18d7  jz 0x00007FB1689D1910
00007fb1689d18dd  nop [rax+rax*1], ax
00007fb1689d18e6  nop [rax+rax*1], eax
00007fb1689d18ee  mov eax, 0x4103F0
00007fb1689d18f3  mov [r15+0x100], rax
00007fb1689d18fa  jmp 0x00007FB1687FE110
00007fb1689d18ff  int3
00007fb1689d1900  int3
00007fb1689d1901  nop [rax+rax*1], ax
00007fb1689d190a  nop [rax+rax*1], ax
00007fb1689d1910  mov eax, [r15]
00007fb1689d1913  mov r14d, [r15+0x98]
00007fb1689d191a  lea r12d, [eax+r14d*1]
00007fb1689d191f  mov r12d, r12d
00007fb1689d1922  mov [r15], r12
00007fb1689d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007fb1689d1930  mov r14d, [r15+0x320]
00007fb1689d1937  mov eax, 0x4103F8
00007fb1689d193c  mov rcx, 0x7FB1689D1860
00007fb1689d1946  mov [r15+r14*8+0x328], rax
00007fb1689d194e  mov [r15+r14*8+0x368], rcx
00007fb1689d1956  add r14d, 0x01
00007fb1689d195a  and r14d, 0x07
00007fb1689d195e  mov [r15+0x320], r14d
00007fb1689d1965  cmp dword ptr [r15+0x318], 0x00
00007fb1689d196d  jz 0x00007FB1689D0F20
00007fb1689d1973  nop [rax+rax*1], ax
00007fb1689d197c  nop [rax+rax*1], eax
00007fb1689d1984  mov eax, 0x4109A4
00007fb1689d1989  mov [r15+0x100], rax
00007fb1689d1990  jmp 0x00007FB1687FE110
00007fb1689d1995  int3
00007fb1689d1996  int3
00007fb1689d1997  nop [rax+rax*1], ax
00007fb1689d19a0  vmovaps xmm1, [0x00007FB1685FE010]
00007fb1689d19a8  movq xmm1, xmm1
00007fb1689d19ac  movaps [r15+0x110], xmm1
00007fb1689d19b4  mov eax, 0x420B10
00007fb1689d19b9  mov r14, [r13+rax*1]
00007fb1689d19be  movq xmm1, r14
00007fb1689d19c3  movaps [r15+0x120], xmm1
00007fb1689d19cb  vmovaps xmm1, [0x00007FB1685FE020]
00007fb1689d19d3  movq xmm1, xmm1
00007fb1689d19d7  movaps [r15+0x140], xmm1
00007fb1689d19df  vmovaps xmm1, [0x00007FB1685FE030]
00007fb1689d19e7  vpbroadcastq xmm1, xmm1
00007fb1689d19ec  movaps [r15+0x150], xmm1
00007fb1689d19f4  mov qword ptr [r15+0x40], 0x02
00007fb1689d19fc  vmovaps xmm15, [0x00007FB1685FE040]
00007fb1689d1a04  movq xmm15, xmm15
00007fb1689d1a09  movaps [r15+0x160], xmm15
00007fb1689d1a11  vmovaps xmm15, [0x00007FB1685FE050]
00007fb1689d1a19  vpbroadcastq xmm15, xmm15
00007fb1689d1a1e  movaps [r15+0x130], xmm15
00007fb1689d1a26  mov rax, [r15+0x40]
00007fb1689d1a2a  vmovq xmm14, rax
00007fb1689d1a2f  vpbroadcastq xmm14, xmm14
00007fb1689d1a34  movaps [r15+0x170], xmm14
00007fb1689d1a3c  mov eax, 0x420A40
00007fb1689d1a41  movups xmm13, [r13+rax*1]
00007fb1689d1a47  mov qword ptr [r15+0x40], 0x431E00
00007fb1689d1a4f  mov eax, [r15]
00007fb1689d1a52  mov r14d, 0x430CB8
00007fb1689d1a58  mov [r13+r14*1], eax
00007fb1689d1a5d  mov qword ptr [r15+0x50], 0x432000
00007fb1689d1a65  vpmovqd xmm12, xmm13
00007fb1689d1a6b  pxor xmm11, xmm11
00007fb1689d1a70  punpcklqdq xmm12, xmm11
00007fb1689d1a75  movaps [r15+0x210], xmm12
00007fb1689d1a7d  movq xmm12, qword ptr [r15+0x140]
00007fb1689d1a86  movq xmm11, qword ptr [r15+0x120]
00007fb1689d1a8f  psubd xmm12, xmm11
00007fb1689d1a94  movq xmm12, xmm12
00007fb1689d1a99  paddq xmm13, xmm14
00007fb1689d1a9e  movaps [r15+0x180], xmm13
00007fb1689d1aa6  movq xmm14, qword ptr [r15+0x160]
00007fb1689d1aaf  paddd xmm11, xmm14
00007fb1689d1ab4  movq xmm11, xmm11
00007fb1689d1ab9  movq xmm11, xmm11
00007fb1689d1abe  movaps [r15+0x120], xmm11
00007fb1689d1ac6  pmovzxdq xmm12, xmm12
00007fb1689d1acc  psllq xmm12, 0x00
00007fb1689d1ad2  movq xmm14, qword ptr [r15+0x210]
00007fb1689d1adb  movq xmm13, qword ptr [r15+0x110]
00007fb1689d1ae4  paddd xmm14, xmm13
00007fb1689d1ae9  movq xmm14, xmm14
00007fb1689d1aee  vcvtuqq2pd xmm12, xmm12
00007fb1689d1af4  pmovzxdq xmm14, xmm14
00007fb1689d1afa  psllq xmm14, 0x00
00007fb1689d1b00  vcvtuqq2pd xmm14, xmm14
00007fb1689d1b06  movaps xmm13, xmm12
00007fb1689d1b0a  mulpd xmm13, xmm1
00007fb1689d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007fb1689d1b15  ptest xmm11, xmm11
00007fb1689d1b1b  jnz 0x00007FB1689D1C0F
00007fb1689d1b21  movaps [r15+0x220], xmm13
00007fb1689d1b29  mov eax, 0x432000
00007fb1689d1b2e  movups [r13+rax*1], xmm13
00007fb1689d1b34  movaps xmm1, xmm14
00007fb1689d1b38  mulpd xmm1, xmm15
00007fb1689d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007fb1689d1b42  ptest xmm13, xmm13
00007fb1689d1b48  jnz 0x00007FB1689D1D5C
00007fb1689d1b4e  movaps [r15+0x210], xmm1
00007fb1689d1b56  mov eax, 0x431E00
00007fb1689d1b5b  movups [r13+rax*1], xmm1
00007fb1689d1b61  mov qword ptr [r15+0x48], 0x10
00007fb1689d1b69  xor eax, eax
00007fb1689d1b6b  mov r14d, 0x10
00007fb1689d1b71  mov r12d, 0x200
00007fb1689d1b77  cmp r14, r12
00007fb1689d1b7a  cmc
00007fb1689d1b7b  lahf
00007fb1689d1b7c  seto al
00007fb1689d1b7f  mov [r15+0x108], eax
00007fb1689d1b86  mov eax, [r15+0x108]
00007fb1689d1b8d  sahf
00007fb1689d1b8e  jnz 0x00007FB1689D1BC0
00007fb1689d1b90  cmp dword ptr [r15+0x318], 0x00
00007fb1689d1b98  jz 0x00007FB1689D2300
00007fb1689d1b9e  nop [rax+rax*1], ax
00007fb1689d1ba7  nop [rax+rax*1], eax
00007fb1689d1baf  mov eax, 0x410490
00007fb1689d1bb4  mov [r15+0x100], rax
00007fb1689d1bbb  jmp 0x00007FB1687FE110
00007fb1689d1bc0  cmp dword ptr [r15+0x318], 0x00
00007fb1689d1bc8  jz 0x00007FB1689D1EB0
00007fb1689d1bce  nop [rax+rax*1], ax
00007fb1689d1bd7  nop [rax+rax*1], eax
00007fb1689d1bdf  mov eax, 0x410450
00007fb1689d1be4  mov [r15+0x100], rax
00007fb1689d1beb  jmp 0x00007FB1687FE110
00007fb1689d1bf0  int3
00007fb1689d1bf1  call 0x00007FB16880DC20
00007fb1689d1bf6  jmp 0x00007FB1689D19BE
00007fb1689d1bfb  call 0x00007FB16880C260
00007fb1689d1c00  jmp 0x00007FB1689D1A47
00007fb1689d1c05  call 0x00007FB1688D5D70
00007fb1689d1c0a  jmp 0x00007FB1689D1A5D
00007fb1689d1c0f  sub rsp, 0x08
00007fb1689d1c13  push rax
00007fb1689d1c14  push rcx
00007fb1689d1c15  push rdx
00007fb1689d1c16  push rdi
00007fb1689d1c17  push rsi
00007fb1689d1c18  push r8
00007fb1689d1c1a  push r9
00007fb1689d1c1c  push r10
00007fb1689d1c1e  push r11
00007fb1689d1c20  sub rsp, 0xF0
00007fb1689d1c27  vmovaps [rsp], xmm0
00007fb1689d1c2c  vmovaps [rsp+0x10], xmm1
00007fb1689d1c32  vmovaps [rsp+0x20], xmm2
00007fb1689d1c38  vmovaps [rsp+0x30], xmm3
00007fb1689d1c3e  vmovaps [rsp+0x40], xmm4
00007fb1689d1c44  vmovaps [rsp+0x50], xmm5
00007fb1689d1c4a  vmovaps [rsp+0x60], xmm6
00007fb1689d1c50  vmovaps [rsp+0x70], xmm7
00007fb1689d1c56  vmovaps [rsp+0x80], xmm8
00007fb1689d1c5f  vmovaps [rsp+0x90], xmm9
00007fb1689d1c68  vmovaps [rsp+0xA0], xmm10
00007fb1689d1c71  vmovaps [rsp+0xB0], xmm11
00007fb1689d1c7a  vmovaps [rsp+0xC0], xmm12
00007fb1689d1c83  vmovaps [rsp+0xD0], xmm14
00007fb1689d1c8c  vmovaps [rsp+0xE0], xmm15
00007fb1689d1c95  sub rsp, 0x30
00007fb1689d1c99  movaps [rsp], xmm13
00007fb1689d1c9e  movaps [rsp+0x10], xmm12
00007fb1689d1ca4  movaps [rsp+0x20], xmm1
00007fb1689d1ca9  lea rdi, [rsp]
00007fb1689d1cad  mov esi, 0x00
00007fb1689d1cb2  mov rax, 0x57CCFD419530
00007fb1689d1cbc  call rax
00007fb1689d1cbe  movaps xmm13, [rsp]
00007fb1689d1cc3  add rsp, 0x30
00007fb1689d1cc7  vmovaps xmm0, [rsp]
00007fb1689d1ccc  vmovaps xmm1, [rsp+0x10]
00007fb1689d1cd2  vmovaps xmm2, [rsp+0x20]
00007fb1689d1cd8  vmovaps xmm3, [rsp+0x30]
00007fb1689d1cde  vmovaps xmm4, [rsp+0x40]
00007fb1689d1ce4  vmovaps xmm5, [rsp+0x50]
00007fb1689d1cea  vmovaps xmm6, [rsp+0x60]
00007fb1689d1cf0  vmovaps xmm7, [rsp+0x70]
00007fb1689d1cf6  vmovaps xmm8, [rsp+0x80]
00007fb1689d1cff  vmovaps xmm9, [rsp+0x90]
00007fb1689d1d08  vmovaps xmm10, [rsp+0xA0]
00007fb1689d1d11  vmovaps xmm11, [rsp+0xB0]
00007fb1689d1d1a  vmovaps xmm12, [rsp+0xC0]
00007fb1689d1d23  vmovaps xmm14, [rsp+0xD0]
00007fb1689d1d2c  vmovaps xmm15, [rsp+0xE0]
00007fb1689d1d35  add rsp, 0xF0
00007fb1689d1d3c  pop r11
00007fb1689d1d3e  pop r10
00007fb1689d1d40  pop r9
00007fb1689d1d42  pop r8
00007fb1689d1d44  pop rsi
00007fb1689d1d45  pop rdi
00007fb1689d1d46  pop rdx
00007fb1689d1d47  pop rcx
00007fb1689d1d48  pop rax
00007fb1689d1d49  add rsp, 0x08
00007fb1689d1d4d  jmp 0x00007FB1689D1B21
00007fb1689d1d52  call 0x00007FB16880C380
00007fb1689d1d57  jmp 0x00007FB1689D1B34
00007fb1689d1d5c  sub rsp, 0x08
00007fb1689d1d60  push rax
00007fb1689d1d61  push rcx
00007fb1689d1d62  push rdx
00007fb1689d1d63  push rdi
00007fb1689d1d64  push rsi
00007fb1689d1d65  push r8
00007fb1689d1d67  push r9
00007fb1689d1d69  push r10
00007fb1689d1d6b  push r11
00007fb1689d1d6d  sub rsp, 0xF0
00007fb1689d1d74  vmovaps [rsp], xmm0
00007fb1689d1d79  vmovaps [rsp+0x10], xmm2
00007fb1689d1d7f  vmovaps [rsp+0x20], xmm3
00007fb1689d1d85  vmovaps [rsp+0x30], xmm4
00007fb1689d1d8b  vmovaps [rsp+0x40], xmm5
00007fb1689d1d91  vmovaps [rsp+0x50], xmm6
00007fb1689d1d97  vmovaps [rsp+0x60], xmm7
00007fb1689d1d9d  vmovaps [rsp+0x70], xmm8
00007fb1689d1da3  vmovaps [rsp+0x80], xmm9
00007fb1689d1dac  vmovaps [rsp+0x90], xmm10
00007fb1689d1db5  vmovaps [rsp+0xA0], xmm11
00007fb1689d1dbe  vmovaps [rsp+0xB0], xmm12
00007fb1689d1dc7  vmovaps [rsp+0xC0], xmm13
00007fb1689d1dd0  vmovaps [rsp+0xD0], xmm14
00007fb1689d1dd9  vmovaps [rsp+0xE0], xmm15
00007fb1689d1de2  sub rsp, 0x30
00007fb1689d1de6  movaps [rsp], xmm1
00007fb1689d1dea  movaps [rsp+0x10], xmm14
00007fb1689d1df0  movaps [rsp+0x20], xmm15
00007fb1689d1df6  lea rdi, [rsp]
00007fb1689d1dfa  mov esi, 0x00
00007fb1689d1dff  mov rax, 0x57CCFD419530
00007fb1689d1e09  call rax
00007fb1689d1e0b  movaps xmm1, [rsp]
00007fb1689d1e0f  add rsp, 0x30
00007fb1689d1e13  vmovaps xmm0, [rsp]
00007fb1689d1e18  vmovaps xmm2, [rsp+0x10]
00007fb1689d1e1e  vmovaps xmm3, [rsp+0x20]
00007fb1689d1e24  vmovaps xmm4, [rsp+0x30]
00007fb1689d1e2a  vmovaps xmm5, [rsp+0x40]
00007fb1689d1e30  vmovaps xmm6, [rsp+0x50]
00007fb1689d1e36  vmovaps xmm7, [rsp+0x60]
00007fb1689d1e3c  vmovaps xmm8, [rsp+0x70]
00007fb1689d1e42  vmovaps xmm9, [rsp+0x80]
00007fb1689d1e4b  vmovaps xmm10, [rsp+0x90]
00007fb1689d1e54  vmovaps xmm11, [rsp+0xA0]
00007fb1689d1e5d  vmovaps xmm12, [rsp+0xB0]
00007fb1689d1e66  vmovaps xmm13, [rsp+0xC0]
00007fb1689d1e6f  vmovaps xmm14, [rsp+0xD0]
00007fb1689d1e78  vmovaps xmm15, [rsp+0xE0]
00007fb1689d1e81  add rsp, 0xF0
00007fb1689d1e88  pop r11
00007fb1689d1e8a  pop r10
00007fb1689d1e8c  pop r9
00007fb1689d1e8e  pop r8
00007fb1689d1e90  pop rsi
00007fb1689d1e91  pop rdi
00007fb1689d1e92  pop rdx
00007fb1689d1e93  pop rcx
00007fb1689d1e94  pop rax
00007fb1689d1e95  add rsp, 0x08
00007fb1689d1e99  jmp 0x00007FB1689D1B4E
00007fb1689d1e9e  call 0x00007FB1687FF540
00007fb1689d1ea3  jmp 0x00007FB1689D1B61
00007fb1689d1ea8  int3
00007fb1689d1ea9  nop [rax], eax
00007fb1689d1eb0  movaps xmm1, [r15+0x180]
00007fb1689d1eb8  vpmovqd xmm15, xmm1
00007fb1689d1ebe  pxor xmm14, xmm14
00007fb1689d1ec3  punpcklqdq xmm15, xmm14
00007fb1689d1ec8  movaps [r15+0x210], xmm15
00007fb1689d1ed0  movq xmm15, qword ptr [r15+0x140]
00007fb1689d1ed9  movq xmm14, qword ptr [r15+0x120]
00007fb1689d1ee2  psubd xmm15, xmm14
00007fb1689d1ee7  movq xmm15, xmm15
00007fb1689d1eec  movaps xmm13, [r15+0x170]
00007fb1689d1ef4  paddq xmm1, xmm13
00007fb1689d1ef9  movaps [r15+0x180], xmm1
00007fb1689d1f01  movq xmm1, qword ptr [r15+0x160]
00007fb1689d1f0a  paddd xmm14, xmm1
00007fb1689d1f0f  movq xmm14, xmm14
00007fb1689d1f14  movq xmm14, xmm14
00007fb1689d1f19  movaps [r15+0x120], xmm14
00007fb1689d1f21  pmovzxdq xmm15, xmm15
00007fb1689d1f27  psllq xmm15, 0x00
00007fb1689d1f2d  movq xmm1, qword ptr [r15+0x210]
00007fb1689d1f36  movq xmm14, qword ptr [r15+0x110]
00007fb1689d1f3f  paddd xmm1, xmm14
00007fb1689d1f44  movq xmm1, xmm1
00007fb1689d1f48  vcvtuqq2pd xmm15, xmm15
00007fb1689d1f4e  pmovzxdq xmm1, xmm1
00007fb1689d1f53  psllq xmm1, 0x00
00007fb1689d1f58  vcvtuqq2pd xmm1, xmm1
00007fb1689d1f5e  movaps xmm14, [r15+0x150]
00007fb1689d1f66  movaps xmm13, xmm15
00007fb1689d1f6a  mulpd xmm13, xmm14
00007fb1689d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007fb1689d1f75  ptest xmm12, xmm12
00007fb1689d1f7b  jnz 0x00007FB1689D205E
00007fb1689d1f81  movaps [r15+0x220], xmm13
00007fb1689d1f89  mov rax, [r15+0x48]
00007fb1689d1f8d  mov r14, [r15+0x50]
00007fb1689d1f91  lea r12, [r14+rax*1]
00007fb1689d1f95  movups [r13+r12*1], xmm13
00007fb1689d1f9b  movaps xmm15, [r15+0x130]
00007fb1689d1fa3  movaps xmm14, xmm1
00007fb1689d1fa7  mulpd xmm14, xmm15
00007fb1689d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007fb1689d1fb2  ptest xmm13, xmm13
00007fb1689d1fb8  jnz 0x00007FB1689D21AC
00007fb1689d1fbe  movaps [r15+0x210], xmm14
00007fb1689d1fc6  mov r14, [r15+0x40]
00007fb1689d1fca  lea r12, [r14+rax*1]
00007fb1689d1fce  movups [r13+r12*1], xmm14
00007fb1689d1fd4  lea r14, [rax+0x10]
00007fb1689d1fd8  mov [r15+0x48], r14
00007fb1689d1fdc  xor eax, eax
00007fb1689d1fde  mov r12d, 0x200
00007fb1689d1fe4  cmp r14, r12
00007fb1689d1fe7  cmc
00007fb1689d1fe8  lahf
00007fb1689d1fe9  seto al
00007fb1689d1fec  mov [r15+0x108], eax
00007fb1689d1ff3  mov eax, [r15+0x108]
00007fb1689d1ffa  sahf
00007fb1689d1ffb  jnz 0x00007FB1689D202D
00007fb1689d1ffd  cmp dword ptr [r15+0x318], 0x00
00007fb1689d2005  jz 0x00007FB1689D2300
00007fb1689d200b  nop [rax+rax*1], ax
00007fb1689d2014  nop [rax+rax*1], eax
00007fb1689d201c  mov eax, 0x410490
00007fb1689d2021  mov [r15+0x100], rax
00007fb1689d2028  jmp 0x00007FB1687FE110
00007fb1689d202d  cmp dword ptr [r15+0x318], 0x00
00007fb1689d2035  jz 0x00007FB1689D1EB0
00007fb1689d203b  nop [rax+rax*1], ax
00007fb1689d2044  nop [rax+rax*1], eax
00007fb1689d204c  mov eax, 0x410450
00007fb1689d2051  mov [r15+0x100], rax
00007fb1689d2058  jmp 0x00007FB1687FE110
00007fb1689d205d  int3
00007fb1689d205e  sub rsp, 0x08
00007fb1689d2062  push rax
00007fb1689d2063  push rcx
00007fb1689d2064  push rdx
00007fb1689d2065  push rdi
00007fb1689d2066  push rsi
00007fb1689d2067  push r8
00007fb1689d2069  push r9
00007fb1689d206b  push r10
00007fb1689d206d  push r11
00007fb1689d206f  sub rsp, 0xF0
00007fb1689d2076  vmovaps [rsp], xmm0
00007fb1689d207b  vmovaps [rsp+0x10], xmm1
00007fb1689d2081  vmovaps [rsp+0x20], xmm2
00007fb1689d2087  vmovaps [rsp+0x30], xmm3
00007fb1689d208d  vmovaps [rsp+0x40], xmm4
00007fb1689d2093  vmovaps [rsp+0x50], xmm5
00007fb1689d2099  vmovaps [rsp+0x60], xmm6
00007fb1689d209f  vmovaps [rsp+0x70], xmm7
00007fb1689d20a5  vmovaps [rsp+0x80], xmm8
00007fb1689d20ae  vmovaps [rsp+0x90], xmm9
00007fb1689d20b7  vmovaps [rsp+0xA0], xmm10
00007fb1689d20c0  vmovaps [rsp+0xB0], xmm11
00007fb1689d20c9  vmovaps [rsp+0xC0], xmm12
00007fb1689d20d2  vmovaps [rsp+0xD0], xmm14
00007fb1689d20db  vmovaps [rsp+0xE0], xmm15
00007fb1689d20e4  sub rsp, 0x30
00007fb1689d20e8  movaps [rsp], xmm13
00007fb1689d20ed  movaps [rsp+0x10], xmm15
00007fb1689d20f3  movaps [rsp+0x20], xmm14
00007fb1689d20f9  lea rdi, [rsp]
00007fb1689d20fd  mov esi, 0x00
00007fb1689d2102  mov rax, 0x57CCFD419530
00007fb1689d210c  call rax
00007fb1689d210e  movaps xmm13, [rsp]
00007fb1689d2113  add rsp, 0x30
00007fb1689d2117  vmovaps xmm0, [rsp]
00007fb1689d211c  vmovaps xmm1, [rsp+0x10]
00007fb1689d2122  vmovaps xmm2, [rsp+0x20]
00007fb1689d2128  vmovaps xmm3, [rsp+0x30]
00007fb1689d212e  vmovaps xmm4, [rsp+0x40]
00007fb1689d2134  vmovaps xmm5, [rsp+0x50]
00007fb1689d213a  vmovaps xmm6, [rsp+0x60]
00007fb1689d2140  vmovaps xmm7, [rsp+0x70]
00007fb1689d2146  vmovaps xmm8, [rsp+0x80]
00007fb1689d214f  vmovaps xmm9, [rsp+0x90]
00007fb1689d2158  vmovaps xmm10, [rsp+0xA0]
00007fb1689d2161  vmovaps xmm11, [rsp+0xB0]
00007fb1689d216a  vmovaps xmm12, [rsp+0xC0]
00007fb1689d2173  vmovaps xmm14, [rsp+0xD0]
00007fb1689d217c  vmovaps xmm15, [rsp+0xE0]
00007fb1689d2185  add rsp, 0xF0
00007fb1689d218c  pop r11
00007fb1689d218e  pop r10
00007fb1689d2190  pop r9
00007fb1689d2192  pop r8
00007fb1689d2194  pop rsi
00007fb1689d2195  pop rdi
00007fb1689d2196  pop rdx
00007fb1689d2197  pop rcx
00007fb1689d2198  pop rax
00007fb1689d2199  add rsp, 0x08
00007fb1689d219d  jmp 0x00007FB1689D1F81
00007fb1689d21a2  call 0x00007FB1688C2240
00007fb1689d21a7  jmp 0x00007FB1689D1F9B
00007fb1689d21ac  sub rsp, 0x08
00007fb1689d21b0  push rax
00007fb1689d21b1  push rcx
00007fb1689d21b2  push rdx
00007fb1689d21b3  push rdi
00007fb1689d21b4  push rsi
00007fb1689d21b5  push r8
00007fb1689d21b7  push r9
00007fb1689d21b9  push r10
00007fb1689d21bb  push r11
00007fb1689d21bd  sub rsp, 0xF0
00007fb1689d21c4  vmovaps [rsp], xmm0
00007fb1689d21c9  vmovaps [rsp+0x10], xmm1
00007fb1689d21cf  vmovaps [rsp+0x20], xmm2
00007fb1689d21d5  vmovaps [rsp+0x30], xmm3
00007fb1689d21db  vmovaps [rsp+0x40], xmm4
00007fb1689d21e1  vmovaps [rsp+0x50], xmm5
00007fb1689d21e7  vmovaps [rsp+0x60], xmm6
00007fb1689d21ed  vmovaps [rsp+0x70], xmm7
00007fb1689d21f3  vmovaps [rsp+0x80], xmm8
00007fb1689d21fc  vmovaps [rsp+0x90], xmm9
00007fb1689d2205  vmovaps [rsp+0xA0], xmm10
00007fb1689d220e  vmovaps [rsp+0xB0], xmm11
00007fb1689d2217  vmovaps [rsp+0xC0], xmm12
00007fb1689d2220  vmovaps [rsp+0xD0], xmm13
00007fb1689d2229  vmovaps [rsp+0xE0], xmm15
00007fb1689d2232  sub rsp, 0x30
00007fb1689d2236  movaps [rsp], xmm14
00007fb1689d223b  movaps [rsp+0x10], xmm1
00007fb1689d2240  movaps [rsp+0x20], xmm15
00007fb1689d2246  lea rdi, [rsp]
00007fb1689d224a  mov esi, 0x00
00007fb1689d224f  mov rax, 0x57CCFD419530
00007fb1689d2259  call rax
00007fb1689d225b  movaps xmm14, [rsp]
00007fb1689d2260  add rsp, 0x30
00007fb1689d2264  vmovaps xmm0, [rsp]
00007fb1689d2269  vmovaps xmm1, [rsp+0x10]
00007fb1689d226f  vmovaps xmm2, [rsp+0x20]
00007fb1689d2275  vmovaps xmm3, [rsp+0x30]
00007fb1689d227b  vmovaps xmm4, [rsp+0x40]
00007fb1689d2281  vmovaps xmm5, [rsp+0x50]
00007fb1689d2287  vmovaps xmm6, [rsp+0x60]
00007fb1689d228d  vmovaps xmm7, [rsp+0x70]
00007fb1689d2293  vmovaps xmm8, [rsp+0x80]
00007fb1689d229c  vmovaps xmm9, [rsp+0x90]
00007fb1689d22a5  vmovaps xmm10, [rsp+0xA0]
00007fb1689d22ae  vmovaps xmm11, [rsp+0xB0]
00007fb1689d22b7  vmovaps xmm12, [rsp+0xC0]
00007fb1689d22c0  vmovaps xmm13, [rsp+0xD0]
00007fb1689d22c9  vmovaps xmm15, [rsp+0xE0]
00007fb1689d22d2  add rsp, 0xF0
00007fb1689d22d9  pop r11
00007fb1689d22db  pop r10
00007fb1689d22dd  pop r9
00007fb1689d22df  pop r8
00007fb1689d22e1  pop rsi
00007fb1689d22e2  pop rdi
00007fb1689d22e3  pop rdx
00007fb1689d22e4  pop rcx
00007fb1689d22e5  pop rax
00007fb1689d22e6  add rsp, 0x08
00007fb1689d22ea  jmp 0x00007FB1689D1FBE
00007fb1689d22ef  call 0x00007FB1688C34C0
00007fb1689d22f4  jmp 0x00007FB1689D1FD4
00007fb1689d22f9  int3
00007fb1689d22fa  nop [rax+rax*1], ax
00007fb1689d2300  mov rax, [r15+0x50]
00007fb1689d2304  lea r14, [rax+0x80]
00007fb1689d230b  movups xmm1, [r13+r14*1]
00007fb1689d2311  lea r14, [rax+0x90]
00007fb1689d2318  movups xmm15, [r13+r14*1]
00007fb1689d231e  vxorps xmm14, xmm14, xmm14
00007fb1689d2323  vpbroadcastq xmm14, xmm14
00007fb1689d2328  lea r14, [rax+0x40]
00007fb1689d232c  movups xmm13, [r13+r14*1]
00007fb1689d2332  lea r14, [rax+0x50]
00007fb1689d2336  movups xmm12, [r13+r14*1]
00007fb1689d233c  mov qword ptr [r15+0x48], 0x00
00007fb1689d2344  movups xmm11, [r13+rax*1]
00007fb1689d234a  lea r14, [rax+0x10]
00007fb1689d234e  movups xmm10, [r13+r14*1]
00007fb1689d2354  mov r14, [r15+0xF8]
00007fb1689d235b  lea r12, [r14+0xE0]
00007fb1689d2362  movups [r13+r12*1], xmm15
00007fb1689d2368  lea r12, [r14+0xF0]
00007fb1689d236f  movups [r13+r12*1], xmm1
00007fb1689d2375  lea r12, [rax+0xC0]
00007fb1689d237c  movups xmm1, [r13+r12*1]
00007fb1689d2382  lea r12, [rax+0xD0]
00007fb1689d2389  movups xmm15, [r13+r12*1]
00007fb1689d238f  lea r12, [rax+0x140]
00007fb1689d2396  movups xmm9, [r13+r12*1]
00007fb1689d239c  lea r12, [rax+0x150]
00007fb1689d23a3  movups xmm8, [r13+r12*1]
00007fb1689d23a9  lea r12, [rax+0x180]
00007fb1689d23b0  movups xmm7, [r13+r12*1]
00007fb1689d23b6  lea r12, [rax+0x190]
00007fb1689d23bd  movups xmm6, [r13+r12*1]
00007fb1689d23c3  lea r12, [r14+0xC0]
00007fb1689d23ca  movups [r13+r12*1], xmm15
00007fb1689d23d0  lea r12, [r14+0xD0]
00007fb1689d23d7  movups [r13+r12*1], xmm1
00007fb1689d23dd  lea r12, [rax+0x100]
00007fb1689d23e4  movups xmm1, [r13+r12*1]
00007fb1689d23ea  lea r12, [rax+0x110]
00007fb1689d23f1  movups xmm15, [r13+r12*1]
00007fb1689d23f7  lea r12, [rax+0x1C0]
00007fb1689d23fe  movups xmm5, [r13+r12*1]
00007fb1689d2404  lea r12, [rax+0x1D0]
00007fb1689d240b  movups xmm4, [r13+r12*1]
00007fb1689d2411  lea r12, [rax+0x20]
00007fb1689d2415  movups xmm3, [r13+r12*1]
00007fb1689d241b  lea r12, [rax+0x30]
00007fb1689d241f  movups xmm2, [r13+r12*1]
00007fb1689d2425  movaps [r15+0x1F0], xmm2
00007fb1689d242d  lea r12, [r14+0x20]
00007fb1689d2431  movups [r13+r12*1], xmm1
00007fb1689d2437  lea r12, [r14+0x30]
00007fb1689d243b  movups [r13+r12*1], xmm12
00007fb1689d2441  lea r12, [rax+0x60]
00007fb1689d2445  movups xmm1, [r13+r12*1]
00007fb1689d244b  lea r12, [rax+0x70]
00007fb1689d244f  movups xmm12, [r13+r12*1]
00007fb1689d2455  lea r12, [r14+0x60]
00007fb1689d2459  movups [r13+r12*1], xmm11
00007fb1689d245f  lea r12, [r14+0x70]
00007fb1689d2463  movups [r13+r12*1], xmm5
00007fb1689d2469  lea r12, [rax+0xE0]
00007fb1689d2470  movups xmm11, [r13+r12*1]
00007fb1689d2476  lea r12, [rax+0xF0]
00007fb1689d247d  movups xmm5, [r13+r12*1]
00007fb1689d2483  lea r12, [rax+0x120]
00007fb1689d248a  vmovaps [rsp+0x10], xmm1
00007fb1689d2490  movups xmm1, [r13+r12*1]
00007fb1689d2496  lea r12, [rax+0x130]
00007fb1689d249d  vmovaps [rsp+0x20], xmm1
00007fb1689d24a3  movups xmm1, [r13+r12*1]
00007fb1689d24a9  lea r12, [r14+0xA0]
00007fb1689d24b0  movups [r13+r12*1], xmm12
00007fb1689d24b6  lea r12, [r14+0xB0]
00007fb1689d24bd  vmovaps xmm12, [rsp+0x10]
00007fb1689d24c3  movups [r13+r12*1], xmm12
00007fb1689d24c9  lea r12, [rax+0xA0]
00007fb1689d24d0  movups xmm12, [r13+r12*1]
00007fb1689d24d6  lea r12, [rax+0xB0]
00007fb1689d24dd  vmovaps [rsp+0x10], xmm1
00007fb1689d24e3  movups xmm1, [r13+r12*1]
00007fb1689d24e9  lea r12, [rax+0x160]
00007fb1689d24f0  vmovaps [rsp+0x30], xmm1
00007fb1689d24f6  movups xmm1, [r13+r12*1]
00007fb1689d24fc  lea r12, [rax+0x170]
00007fb1689d2503  vmovaps [rsp+0x40], xmm1
00007fb1689d2509  movups xmm1, [r13+r12*1]
00007fb1689d250f  movaps [r15+0x2B0], xmm1
00007fb1689d2517  lea r12, [rax+0x1A0]
00007fb1689d251e  vmovaps [rsp+0x50], xmm1
00007fb1689d2524  movups xmm1, [r13+r12*1]
00007fb1689d252a  lea r12, [rax+0x1B0]
00007fb1689d2531  vmovaps [rsp+0x60], xmm1
00007fb1689d2537  movups xmm1, [r13+r12*1]
00007fb1689d253d  vmovaps [rsp+0x70], xmm1
00007fb1689d2543  vmovaps xmm1, [rsp+0x60]
00007fb1689d2549  movaps [r15+0x290], xmm1
00007fb1689d2551  vmovaps [rsp+0x60], xmm1
00007fb1689d2557  vmovaps xmm1, [rsp+0x70]
00007fb1689d255d  movaps [r15+0x1E0], xmm1
00007fb1689d2565  lea r12, [r14+0x80]
00007fb1689d256c  vmovaps [rsp+0x70], xmm1
00007fb1689d2572  vmovaps xmm1, [rsp+0x30]
00007fb1689d2578  movups [r13+r12*1], xmm1
00007fb1689d257e  lea r12, [r14+0x90]
00007fb1689d2585  movups [r13+r12*1], xmm12
00007fb1689d258b  lea r12, [rax+0x1E0]
00007fb1689d2592  movups xmm1, [r13+r12*1]
00007fb1689d2598  lea r12, [rax+0x1F0]
00007fb1689d259f  movups xmm12, [r13+r12*1]
00007fb1689d25a5  mov qword ptr [r15+0x50], 0x432200
00007fb1689d25ad  lea rax, [r14+0x40]
00007fb1689d25b1  vmovaps [rsp+0x30], xmm1
00007fb1689d25b7  vmovaps xmm1, [rsp+0x40]
00007fb1689d25bd  movups [r13+rax*1], xmm1
00007fb1689d25c3  lea rax, [r14+0x50]
00007fb1689d25c7  movups [r13+rax*1], xmm10
00007fb1689d25cd  movups [r13+r14*1], xmm12
00007fb1689d25d3  lea rax, [r14+0x10]
00007fb1689d25d7  vmovaps xmm1, [rsp+0x30]
00007fb1689d25dd  movups [r13+rax*1], xmm1
00007fb1689d25e3  mov rax, [r15+0x40]
00007fb1689d25e7  vmovaps [rsp+0x30], xmm3
00007fb1689d25ed  vmovaps xmm1, [rsp+0x30]
00007fb1689d25f3  por xmm3, xmm1
00007fb1689d25f7  vmovaps [rsp+0x30], xmm6
00007fb1689d25fd  vmovaps xmm12, [rsp+0x30]
00007fb1689d2603  por xmm6, xmm12
00007fb1689d2608  lea r12, [rax+0x30]
00007fb1689d260c  mov r11, [r13+r12*1]
00007fb1689d2611  lea r12, [rax+0x38]
00007fb1689d2615  mov r10, [r13+r12*1]
00007fb1689d261a  movq xmm12, r11
00007fb1689d261f  movq xmm10, r10
00007fb1689d2624  movq xmm12, xmm12
00007fb1689d2629  vmovaps [rsp+0x30], xmm12
00007fb1689d262f  movq xmm12, xmm12
00007fb1689d2634  movaps [r15+0x130], xmm12
00007fb1689d263c  movq xmm10, xmm10
00007fb1689d2641  vmovaps [rsp+0x40], xmm10
00007fb1689d2647  movq xmm10, xmm10
00007fb1689d264c  movaps [r15+0x280], xmm10
00007fb1689d2654  vmovaps [rsp+0x80], xmm9
00007fb1689d265d  vmovaps xmm12, [rsp+0x80]
00007fb1689d2666  por xmm9, xmm12
00007fb1689d266b  lea r12, [rax+0x20]
00007fb1689d266f  mov r11, [r13+r12*1]
00007fb1689d2674  lea r12, [rax+0x28]
00007fb1689d2678  mov r10, [r13+r12*1]
00007fb1689d267d  movq xmm12, r11
00007fb1689d2682  movq xmm10, r10
00007fb1689d2687  movq xmm12, xmm12
00007fb1689d268c  vmovaps [rsp+0x80], xmm12
00007fb1689d2695  movq xmm12, xmm12
00007fb1689d269a  movaps [r15+0x150], xmm12
00007fb1689d26a2  movq xmm10, xmm10
00007fb1689d26a7  vmovaps [rsp+0x90], xmm10
00007fb1689d26b0  movq xmm10, xmm10
00007fb1689d26b5  movaps [r15+0x140], xmm10
00007fb1689d26bd  lea r12, [rax+0x10]
00007fb1689d26c1  mov r11, [r13+r12*1]
00007fb1689d26c6  lea r12, [rax+0x18]
00007fb1689d26ca  mov r10, [r13+r12*1]
00007fb1689d26cf  movq xmm12, r11
00007fb1689d26d4  movq xmm10, r10
00007fb1689d26d9  movq xmm12, xmm12
00007fb1689d26de  vmovaps [rsp+0xA0], xmm12
00007fb1689d26e7  movq xmm12, xmm12
00007fb1689d26ec  movaps [r15+0x170], xmm12
00007fb1689d26f4  movq xmm10, xmm10
00007fb1689d26f9  vmovaps [rsp+0xB0], xmm10
00007fb1689d2702  movq xmm10, xmm10
00007fb1689d2707  movaps [r15+0x160], xmm10
00007fb1689d270f  mov r12, [r13+rax*1]
00007fb1689d2714  vmovq xmm12, r12
00007fb1689d2719  vpbroadcastq xmm12, xmm12
00007fb1689d271e  lea r12, [rax+0x08]
00007fb1689d2722  mov rax, [r13+r12*1]
00007fb1689d2727  movq xmm10, rax
00007fb1689d272c  movaps [r15+0x230], xmm10
00007fb1689d2734  lea rax, [r14+0x50]
00007fb1689d2738  movups xmm10, [r13+rax*1]
00007fb1689d273e  lea rax, [r14+0x60]
00007fb1689d2742  vmovaps [rsp+0xC0], xmm1
00007fb1689d274b  movups xmm1, [r13+rax*1]
00007fb1689d2751  lea rax, [r14+0x30]
00007fb1689d2755  vmovaps [rsp+0xD0], xmm1
00007fb1689d275e  movups xmm1, [r13+rax*1]
00007fb1689d2764  mov qword ptr [r15+0x60], 0x432200
00007fb1689d276c  mov qword ptr [r15+0x58], 0x40
00007fb1689d2774  vmovaps [rsp+0xE0], xmm1
00007fb1689d277d  vmovaps [rsp+0xF0], xmm15
00007fb1689d2786  vmovaps xmm15, [rsp+0xC0]
00007fb1689d278f  vmovaps [rsp+0xC0], xmm14
00007fb1689d2798  movaps xmm1, xmm12
00007fb1689d279c  mulpd xmm1, xmm15
00007fb1689d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007fb1689d27a6  ptest xmm14, xmm14
00007fb1689d27ac  jnz 0x00007FB1689D3863
00007fb1689d27b2  movq xmm15, qword ptr [r15+0x230]
00007fb1689d27bb  vmovaps [rsp+0x100], xmm15
00007fb1689d27c4  vpermilpd xmm15, xmm15, 0x00
00007fb1689d27ca  vmovaps [rsp+0x110], xmm1
00007fb1689d27d3  vmovaps xmm1, [rsp+0xE0]
00007fb1689d27dc  vmovaps [rsp+0xE0], xmm13
00007fb1689d27e5  movaps xmm14, xmm1
00007fb1689d27e9  mulpd xmm14, xmm15
00007fb1689d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007fb1689d27f4  ptest xmm13, xmm13
00007fb1689d27fa  jnz 0x00007FB1689D39A5
00007fb1689d2800  vxorps xmm1, xmm1, xmm1
00007fb1689d2804  vpbroadcastq xmm1, xmm1
00007fb1689d2809  vmovaps xmm13, [rsp+0xD0]
00007fb1689d2812  vmovaps [rsp+0xD0], xmm1
00007fb1689d281b  movaps xmm15, xmm12
00007fb1689d281f  mulpd xmm15, xmm13
00007fb1689d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007fb1689d282a  ptest xmm1, xmm1
00007fb1689d282f  jnz 0x00007FB1689D3AE8
00007fb1689d2835  movaps xmm1, xmm12
00007fb1689d2839  mulpd xmm1, xmm10
00007fb1689d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007fb1689d2843  ptest xmm13, xmm13
00007fb1689d2849  jnz 0x00007FB1689D3C2C
00007fb1689d284f  movaps xmm13, xmm12
00007fb1689d2853  mulpd xmm13, xmm2
00007fb1689d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007fb1689d285e  ptest xmm10, xmm10
00007fb1689d2864  jnz 0x00007FB1689D3D6E
00007fb1689d286a  vmovaps [rsp+0x120], xmm7
00007fb1689d2873  vmovaps xmm12, [rsp+0x120]
00007fb1689d287c  por xmm7, xmm12
00007fb1689d2881  vmovaps xmm12, [rsp+0xE0]
00007fb1689d288a  vmovaps xmm10, [rsp+0xE0]
00007fb1689d2893  por xmm12, xmm10
00007fb1689d2898  vmovaps xmm2, [rsp+0x100]
00007fb1689d28a1  vpermilpd xmm2, xmm2, 0x00
00007fb1689d28a7  vmovaps [rsp+0xE0], xmm1
00007fb1689d28b0  vmovaps [rsp+0x120], xmm15
00007fb1689d28b9  movaps xmm1, xmm10
00007fb1689d28bd  mulpd xmm1, xmm2
00007fb1689d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007fb1689d28c6  ptest xmm15, xmm15
00007fb1689d28cc  jnz 0x00007FB1689D3EB1
00007fb1689d28d2  xor eax, eax
00007fb1689d28d4  mov r12d, 0x40
00007fb1689d28da  mov r11d, 0x200
00007fb1689d28e0  cmp r12, r11
00007fb1689d28e3  cmc
00007fb1689d28e4  lahf
00007fb1689d28e5  seto al
00007fb1689d28e8  mov [r15+0x108], eax
00007fb1689d28ef  vmovaps xmm10, [rsp+0x110]
00007fb1689d28f8  vmovaps xmm2, [rsp+0xD0]
00007fb1689d2901  vmovaps [rsp+0xD0], xmm1
00007fb1689d290a  movaps xmm15, xmm10
00007fb1689d290e  addpd xmm15, xmm2
00007fb1689d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007fb1689d2919  ptest xmm1, xmm1
00007fb1689d291e  jnz 0x00007FB1689D3FF2
00007fb1689d2924  vmovaps xmm10, [rsp+0x120]
00007fb1689d292d  vmovaps [rsp+0x110], xmm15
00007fb1689d2936  vmovaps xmm15, [rsp+0xC0]
00007fb1689d293f  vmovaps [rsp+0xC0], xmm14
00007fb1689d2948  movaps xmm1, xmm10
00007fb1689d294c  addpd xmm1, xmm15
00007fb1689d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007fb1689d2956  ptest xmm14, xmm14
00007fb1689d295c  jnz 0x00007FB1689D4135
00007fb1689d2962  vmovaps xmm10, [rsp+0xE0]
00007fb1689d296b  vmovaps [rsp+0xE0], xmm1
00007fb1689d2974  movaps xmm14, xmm10
00007fb1689d2978  addpd xmm14, xmm15
00007fb1689d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007fb1689d2983  ptest xmm1, xmm1
00007fb1689d2988  jnz 0x00007FB1689D4277
00007fb1689d298e  vmovaps xmm1, [rsp+0x10]
00007fb1689d2994  vmovaps xmm15, [rsp+0x10]
00007fb1689d299a  por xmm1, xmm15
00007fb1689d299f  vmovaps xmm15, [rsp+0x20]
00007fb1689d29a5  vmovaps xmm10, [rsp+0x20]
00007fb1689d29ab  por xmm15, xmm10
00007fb1689d29b0  vmovaps [rsp+0x10], xmm5
00007fb1689d29b6  vmovaps xmm10, [rsp+0x10]
00007fb1689d29bc  por xmm5, xmm10
00007fb1689d29c1  vmovaps [rsp+0x10], xmm11
00007fb1689d29c7  vmovaps xmm10, [rsp+0x10]
00007fb1689d29cd  por xmm11, xmm10
00007fb1689d29d2  vmovaps [rsp+0x10], xmm4
00007fb1689d29d8  vmovaps xmm10, [rsp+0x10]
00007fb1689d29de  por xmm4, xmm10
00007fb1689d29e3  vmovaps [rsp+0x10], xmm8
00007fb1689d29e9  vmovaps xmm10, [rsp+0x10]
00007fb1689d29ef  por xmm8, xmm10
00007fb1689d29f4  vmovaps xmm10, [rsp+0xF0]
00007fb1689d29fd  vmovaps [rsp+0x10], xmm1
00007fb1689d2a03  vmovaps xmm1, [rsp+0xF0]
00007fb1689d2a0c  por xmm10, xmm1
00007fb1689d2a11  lea rax, [r14+0xA0]
00007fb1689d2a18  movups xmm1, [r13+rax*1]
00007fb1689d2a1e  lea rax, [r14+0xB0]
00007fb1689d2a25  vmovaps [rsp+0x20], xmm1
00007fb1689d2a2b  movups xmm1, [r13+rax*1]
00007fb1689d2a31  vmovaps [rsp+0xF0], xmm1
00007fb1689d2a3a  vmovaps [rsp+0x120], xmm15
00007fb1689d2a43  movaps xmm1, xmm13
00007fb1689d2a47  addpd xmm1, xmm2
00007fb1689d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007fb1689d2a50  ptest xmm15, xmm15
00007fb1689d2a56  jnz 0x00007FB1689D43CF
00007fb1689d2a5c  lea rax, [r14+0xF0]
00007fb1689d2a63  movups xmm15, [r13+rax*1]
00007fb1689d2a69  vmovaps xmm2, [rsp+0xE0]
00007fb1689d2a72  vmovaps [rsp+0xE0], xmm1
00007fb1689d2a7b  vmovaps xmm1, [rsp+0xD0]
00007fb1689d2a84  vmovaps [rsp+0xD0], xmm15
00007fb1689d2a8d  movaps xmm13, xmm2
00007fb1689d2a91  addpd xmm13, xmm1
00007fb1689d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007fb1689d2a9c  ptest xmm15, xmm15
00007fb1689d2aa2  jnz 0x00007FB1689D451A
00007fb1689d2aa8  vmovaps xmm15, [rsp+0xC0]
00007fb1689d2ab1  movaps xmm1, xmm14
00007fb1689d2ab5  addpd xmm1, xmm15
00007fb1689d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007fb1689d2abf  ptest xmm2, xmm2
00007fb1689d2ac4  jnz 0x00007FB1689D465C
00007fb1689d2aca  vmovaps xmm15, [rsp+0x100]
00007fb1689d2ad3  vpermilpd xmm15, xmm15, 0x00
00007fb1689d2ad9  vmovaps xmm2, [rsp+0xF0]
00007fb1689d2ae2  vmovaps [rsp+0xC0], xmm1
00007fb1689d2aeb  movaps xmm14, xmm2
00007fb1689d2aef  mulpd xmm14, xmm15
00007fb1689d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007fb1689d2afa  ptest xmm1, xmm1
00007fb1689d2aff  jnz 0x00007FB1689D479E
00007fb1689d2b05  vmovaps xmm1, [rsp+0xA0]
00007fb1689d2b0e  vpermilpd xmm1, xmm1, 0x00
00007fb1689d2b14  vmovaps xmm2, [rsp+0xD0]
00007fb1689d2b1d  vmovaps [rsp+0xD0], xmm14
00007fb1689d2b26  movaps xmm15, xmm2
00007fb1689d2b2a  mulpd xmm15, xmm1
00007fb1689d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007fb1689d2b35  ptest xmm14, xmm14
00007fb1689d2b3b  jnz 0x00007FB1689D48E1
00007fb1689d2b41  lea rax, [r14+0xE0]
00007fb1689d2b48  movups xmm1, [r13+rax*1]
00007fb1689d2b4e  vmovaps xmm14, [rsp+0x100]
00007fb1689d2b57  vpermilpd xmm14, xmm14, 0x00
00007fb1689d2b5d  vmovaps [rsp+0xF0], xmm1
00007fb1689d2b66  vmovaps xmm1, [rsp+0x20]
00007fb1689d2b6c  vmovaps [rsp+0x20], xmm15
00007fb1689d2b72  movaps xmm2, xmm1
00007fb1689d2b75  mulpd xmm2, xmm14
00007fb1689d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007fb1689d2b7f  ptest xmm15, xmm15
00007fb1689d2b85  jnz 0x00007FB1689D4A2D
00007fb1689d2b8b  vmovaps [rsp+0x100], xmm10
00007fb1689d2b94  vmovaps xmm1, [rsp+0x100]
00007fb1689d2b9d  por xmm10, xmm1
00007fb1689d2ba2  movaps [r15+0x300], xmm10
00007fb1689d2baa  vmovaps [rsp+0x100], xmm8
00007fb1689d2bb3  vmovaps xmm1, [rsp+0x100]
00007fb1689d2bbc  por xmm8, xmm1
00007fb1689d2bc1  movaps [r15+0x190], xmm8
00007fb1689d2bc9  vmovaps xmm1, [rsp+0xA0]
00007fb1689d2bd2  vpermilpd xmm1, xmm1, 0x00
00007fb1689d2bd8  vmovaps xmm14, [rsp+0xF0]
00007fb1689d2be1  vmovaps [rsp+0xF0], xmm13
00007fb1689d2bea  movaps xmm15, xmm14
00007fb1689d2bee  mulpd xmm15, xmm1
00007fb1689d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007fb1689d2bf9  ptest xmm13, xmm13
00007fb1689d2bff  jnz 0x00007FB1689D4B6E
00007fb1689d2c05  lea rax, [r14+0x90]
00007fb1689d2c0c  movups xmm1, [r13+rax*1]
00007fb1689d2c12  vmovaps [rsp+0x100], xmm4
00007fb1689d2c1b  vmovaps xmm14, [rsp+0x100]
00007fb1689d2c24  por xmm4, xmm14
00007fb1689d2c29  movaps [r15+0x1C0], xmm4
00007fb1689d2c31  vmovaps [rsp+0x100], xmm11
00007fb1689d2c3a  vmovaps xmm14, [rsp+0x100]
00007fb1689d2c43  por xmm11, xmm14
00007fb1689d2c48  movaps [r15+0x200], xmm11
00007fb1689d2c50  vmovaps [rsp+0x100], xmm5
00007fb1689d2c59  vmovaps xmm14, [rsp+0x100]
00007fb1689d2c62  por xmm5, xmm14
00007fb1689d2c67  movaps [r15+0x2D0], xmm5
00007fb1689d2c6f  vmovaps xmm14, [rsp+0x120]
00007fb1689d2c78  vmovaps xmm13, [rsp+0x120]
00007fb1689d2c81  por xmm14, xmm13
00007fb1689d2c86  movaps [r15+0x2E0], xmm14
00007fb1689d2c8e  vmovaps [rsp+0x100], xmm1
00007fb1689d2c97  vmovaps xmm1, [rsp+0x110]
00007fb1689d2ca0  vmovaps [rsp+0x110], xmm15
00007fb1689d2ca9  vmovaps xmm15, [rsp+0xD0]
00007fb1689d2cb2  vmovaps [rsp+0xD0], xmm14
00007fb1689d2cbb  movaps xmm13, xmm1
00007fb1689d2cbf  addpd xmm13, xmm15
00007fb1689d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007fb1689d2cca  ptest xmm14, xmm14
00007fb1689d2cd0  jnz 0x00007FB1689D4CBB
00007fb1689d2cd6  vmovaps xmm1, [rsp+0xA0]
00007fb1689d2cdf  vpermilpd xmm1, xmm1, 0x00
00007fb1689d2ce5  vmovaps xmm14, [rsp+0x100]
00007fb1689d2cee  vmovaps [rsp+0x100], xmm13
00007fb1689d2cf7  movaps xmm15, xmm14
00007fb1689d2cfb  mulpd xmm15, xmm1
00007fb1689d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007fb1689d2d06  ptest xmm13, xmm13
00007fb1689d2d0c  jnz 0x00007FB1689D4DFE
00007fb1689d2d12  lea rax, [r14+0x80]
00007fb1689d2d19  movups xmm1, [r13+rax*1]
00007fb1689d2d1f  vmovaps xmm13, [rsp+0xE0]
00007fb1689d2d28  vmovaps [rsp+0xE0], xmm1
00007fb1689d2d31  movaps xmm14, xmm13
00007fb1689d2d35  addpd xmm14, xmm2
00007fb1689d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007fb1689d2d40  ptest xmm1, xmm1
00007fb1689d2d45  jnz 0x00007FB1689D4F4B
00007fb1689d2d4b  vmovaps xmm13, [rsp+0xF0]
00007fb1689d2d54  vmovaps xmm2, [rsp+0x20]
00007fb1689d2d5a  vmovaps [rsp+0x20], xmm15
00007fb1689d2d60  movaps xmm1, xmm13
00007fb1689d2d64  addpd xmm1, xmm2
00007fb1689d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007fb1689d2d6d  ptest xmm15, xmm15
00007fb1689d2d73  jnz 0x00007FB1689D508E
00007fb1689d2d79  vmovaps xmm15, [rsp+0x10]
00007fb1689d2d7f  vmovaps xmm13, [rsp+0x10]
00007fb1689d2d85  por xmm15, xmm13
00007fb1689d2d8a  movaps [r15+0x2F0], xmm15
00007fb1689d2d92  vmovaps xmm13, [rsp+0xA0]
00007fb1689d2d9b  vpermilpd xmm13, xmm13, 0x00
00007fb1689d2da1  vmovaps [rsp+0x10], xmm1
00007fb1689d2da7  vmovaps xmm1, [rsp+0xE0]
00007fb1689d2db0  vmovaps [rsp+0xA0], xmm15
00007fb1689d2db9  movaps xmm2, xmm1
00007fb1689d2dbc  mulpd xmm2, xmm13
00007fb1689d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007fb1689d2dc6  ptest xmm15, xmm15
00007fb1689d2dcc  jnz 0x00007FB1689D51CF
00007fb1689d2dd2  lea rax, [r14+0xD0]
00007fb1689d2dd9  movups xmm1, [r13+rax*1]
00007fb1689d2ddf  vmovaps xmm13, [rsp+0xC0]
00007fb1689d2de8  vmovaps [rsp+0xC0], xmm1
00007fb1689d2df1  vmovaps xmm1, [rsp+0x110]
00007fb1689d2dfa  vmovaps [rsp+0xE0], xmm14
00007fb1689d2e03  movaps xmm15, xmm13
00007fb1689d2e07  addpd xmm15, xmm1
00007fb1689d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007fb1689d2e12  ptest xmm14, xmm14
00007fb1689d2e18  jnz 0x00007FB1689D531A
00007fb1689d2e1e  vmovaps xmm1, [rsp+0xB0]
00007fb1689d2e27  vpermilpd xmm1, xmm1, 0x00
00007fb1689d2e2d  movaps xmm14, xmm11
00007fb1689d2e31  mulpd xmm14, xmm1
00007fb1689d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007fb1689d2e3c  ptest xmm13, xmm13
00007fb1689d2e42  jnz 0x00007FB1689D545D
00007fb1689d2e48  movaps [r15+0x260], xmm14
00007fb1689d2e50  vxorps xmm1, xmm1, xmm1
00007fb1689d2e54  vpbroadcastq xmm1, xmm1
00007fb1689d2e59  movaps [r15+0x1B0], xmm1
00007fb1689d2e61  vmovaps xmm1, [rsp+0xB0]
00007fb1689d2e6a  vpermilpd xmm1, xmm1, 0x00
00007fb1689d2e70  vmovaps xmm11, [rsp+0xC0]
00007fb1689d2e79  vmovaps [rsp+0xC0], xmm15
00007fb1689d2e82  movaps xmm13, xmm11
00007fb1689d2e86  mulpd xmm13, xmm1
00007fb1689d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007fb1689d2e91  ptest xmm15, xmm15
00007fb1689d2e97  jnz 0x00007FB1689D55A0
00007fb1689d2e9d  lea rax, [r14+0xC0]
00007fb1689d2ea4  movups xmm1, [r13+rax*1]
00007fb1689d2eaa  vmovaps xmm11, [rsp+0x100]
00007fb1689d2eb3  vmovaps [rsp+0xF0], xmm1
00007fb1689d2ebc  vmovaps xmm1, [rsp+0x20]
00007fb1689d2ec2  vmovaps [rsp+0x20], xmm14
00007fb1689d2ec8  movaps xmm15, xmm11
00007fb1689d2ecc  addpd xmm15, xmm1
00007fb1689d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007fb1689d2ed7  ptest xmm14, xmm14
00007fb1689d2edd  jnz 0x00007FB1689D56ED
00007fb1689d2ee3  vmovaps [rsp+0x100], xmm9
00007fb1689d2eec  vmovaps xmm1, [rsp+0x100]
00007fb1689d2ef5  por xmm9, xmm1
00007fb1689d2efa  movaps [r15+0x270], xmm9
00007fb1689d2f02  vmovaps [rsp+0x100], xmm6
00007fb1689d2f0b  vmovaps xmm1, [rsp+0x100]
00007fb1689d2f14  por xmm6, xmm1
00007fb1689d2f18  movaps [r15+0x1A0], xmm6
00007fb1689d2f20  vmovaps xmm14, [rsp+0xB0]
00007fb1689d2f29  vpermilpd xmm14, xmm14, 0x00
00007fb1689d2f2f  vmovaps xmm6, [rsp+0xF0]
00007fb1689d2f38  vmovaps [rsp+0xF0], xmm1
00007fb1689d2f41  movaps xmm11, xmm6
00007fb1689d2f45  mulpd xmm11, xmm14
00007fb1689d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007fb1689d2f50  ptest xmm1, xmm1
00007fb1689d2f55  jnz 0x00007FB1689D5830
00007fb1689d2f5b  lea rax, [r14+0x20]
00007fb1689d2f5f  movups xmm1, [r13+rax*1]
00007fb1689d2f65  movaps [r15+0x110], xmm1
00007fb1689d2f6d  vmovaps xmm6, [rsp+0xE0]
00007fb1689d2f76  vmovaps [rsp+0xE0], xmm1
00007fb1689d2f7f  movaps xmm14, xmm6
00007fb1689d2f83  addpd xmm14, xmm2
00007fb1689d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007fb1689d2f8e  ptest xmm1, xmm1
00007fb1689d2f93  jnz 0x00007FB1689D597D
00007fb1689d2f99  vmovaps xmm1, [rsp+0xB0]
00007fb1689d2fa2  vpermilpd xmm1, xmm1, 0x00
00007fb1689d2fa8  movaps xmm6, xmm5
00007fb1689d2fab  mulpd xmm6, xmm1
00007fb1689d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007fb1689d2fb4  ptest xmm2, xmm2
00007fb1689d2fb9  jnz 0x00007FB1689D5ABF
00007fb1689d2fbf  vmovaps xmm5, [rsp+0x10]
00007fb1689d2fc5  movaps xmm1, xmm5
00007fb1689d2fc8  addpd xmm1, xmm13
00007fb1689d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007fb1689d2fd2  ptest xmm2, xmm2
00007fb1689d2fd7  jnz 0x00007FB1689D5BFF
00007fb1689d2fdd  vmovaps xmm13, [rsp+0x80]
00007fb1689d2fe6  vpermilpd xmm13, xmm13, 0x00
00007fb1689d2fec  vmovaps xmm2, [rsp+0xE0]
00007fb1689d2ff5  vmovaps [rsp+0x10], xmm1
00007fb1689d2ffb  movaps xmm5, xmm2
00007fb1689d2ffe  mulpd xmm5, xmm13
00007fb1689d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007fb1689d3008  ptest xmm1, xmm1
00007fb1689d300d  jnz 0x00007FB1689D5D40
00007fb1689d3013  vmovaps xmm1, [rsp+0x80]
00007fb1689d301c  vpermilpd xmm1, xmm1, 0x00
00007fb1689d3022  movaps xmm13, xmm10
00007fb1689d3026  mulpd xmm13, xmm1
00007fb1689d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007fb1689d3031  ptest xmm2, xmm2
00007fb1689d3036  jnz 0x00007FB1689D5E81
00007fb1689d303c  vmovaps xmm10, [rsp+0x20]
00007fb1689d3042  movaps xmm1, xmm15
00007fb1689d3046  addpd xmm1, xmm10
00007fb1689d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007fb1689d3050  ptest xmm2, xmm2
00007fb1689d3055  jnz 0x00007FB1689D5FC4
00007fb1689d305b  vmovaps xmm10, [rsp+0xC0]
00007fb1689d3064  movaps xmm15, xmm10
00007fb1689d3068  addpd xmm15, xmm11
00007fb1689d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007fb1689d3073  ptest xmm2, xmm2
00007fb1689d3078  jnz 0x00007FB1689D6106
00007fb1689d307e  vmovaps xmm11, [rsp+0x80]
00007fb1689d3087  vpermilpd xmm11, xmm11, 0x00
00007fb1689d308d  vmovaps xmm2, [rsp+0xD0]
00007fb1689d3096  vmovaps [rsp+0x20], xmm1
00007fb1689d309c  movaps xmm10, xmm2
00007fb1689d30a0  mulpd xmm10, xmm11
00007fb1689d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007fb1689d30ab  ptest xmm1, xmm1
00007fb1689d30b0  jnz 0x00007FB1689D624A
00007fb1689d30b6  vmovaps xmm1, [rsp+0x80]
00007fb1689d30bf  vpermilpd xmm1, xmm1, 0x00
00007fb1689d30c5  vmovaps xmm2, [rsp+0xA0]
00007fb1689d30ce  vmovaps [rsp+0x80], xmm15
00007fb1689d30d7  movaps xmm11, xmm2
00007fb1689d30db  mulpd xmm11, xmm1
00007fb1689d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007fb1689d30e6  ptest xmm15, xmm15
00007fb1689d30ec  jnz 0x00007FB1689D638D
00007fb1689d30f2  movaps xmm1, xmm14
00007fb1689d30f6  addpd xmm1, xmm6
00007fb1689d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007fb1689d30ff  ptest xmm15, xmm15
00007fb1689d3105  jnz 0x00007FB1689D64CF
00007fb1689d310b  vmovaps xmm14, [rsp+0x10]
00007fb1689d3111  movaps xmm15, xmm14
00007fb1689d3115  addpd xmm15, xmm5
00007fb1689d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007fb1689d3120  ptest xmm6, xmm6
00007fb1689d3125  jnz 0x00007FB1689D6610
00007fb1689d312b  vmovaps xmm14, [rsp+0x90]
00007fb1689d3134  vpermilpd xmm14, xmm14, 0x00
00007fb1689d313a  movaps xmm6, xmm9
00007fb1689d313e  mulpd xmm6, xmm14
00007fb1689d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007fb1689d3148  ptest xmm5, xmm5
00007fb1689d314d  jnz 0x00007FB1689D6753
00007fb1689d3153  vmovaps xmm9, [rsp+0x80]
00007fb1689d315c  movaps xmm14, xmm9
00007fb1689d3160  addpd xmm14, xmm13
00007fb1689d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007fb1689d316b  ptest xmm5, xmm5
00007fb1689d3170  jnz 0x00007FB1689D6895
00007fb1689d3176  vmovaps xmm9, [rsp+0x20]
00007fb1689d317c  movaps xmm13, xmm9
00007fb1689d3180  addpd xmm13, xmm10
00007fb1689d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007fb1689d318b  ptest xmm5, xmm5
00007fb1689d3190  jnz 0x00007FB1689D69D9
00007fb1689d3196  vmovaps [rsp+0x10], xmm12
00007fb1689d319c  vmovaps xmm10, [rsp+0x10]
00007fb1689d31a2  por xmm12, xmm10
00007fb1689d31a7  movaps [r15+0x250], xmm12
00007fb1689d31af  vmovaps [rsp+0x10], xmm7
00007fb1689d31b5  vmovaps xmm12, [rsp+0x10]
00007fb1689d31bb  por xmm7, xmm12
00007fb1689d31c0  movaps [r15+0x2A0], xmm7
00007fb1689d31c8  vmovaps [rsp+0x10], xmm3
00007fb1689d31ce  vmovaps xmm12, [rsp+0x10]
00007fb1689d31d4  por xmm3, xmm12
00007fb1689d31d9  movaps [r15+0x1D0], xmm3
00007fb1689d31e1  lea rax, [r14+0x40]
00007fb1689d31e5  movups xmm12, [r13+rax*1]
00007fb1689d31eb  movaps [r15+0x2C0], xmm12
00007fb1689d31f3  vmovaps xmm10, [rsp+0x90]
00007fb1689d31fc  vpermilpd xmm10, xmm10, 0x00
00007fb1689d3202  movaps xmm9, xmm8
00007fb1689d3206  mulpd xmm9, xmm10
00007fb1689d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007fb1689d3211  ptest xmm5, xmm5
00007fb1689d3216  jnz 0x00007FB1689D6B27
00007fb1689d321c  movaps xmm10, xmm1
00007fb1689d3220  addpd xmm10, xmm11
00007fb1689d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007fb1689d322b  ptest xmm8, xmm8
00007fb1689d3231  jnz 0x00007FB1689D6C6B
00007fb1689d3237  movaps xmm1, xmm15
00007fb1689d323b  addpd xmm1, xmm6
00007fb1689d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007fb1689d3244  ptest xmm11, xmm11
00007fb1689d324a  jnz 0x00007FB1689D6DAE
00007fb1689d3250  vmovaps xmm15, [rsp+0x90]
00007fb1689d3259  vpermilpd xmm15, xmm15, 0x00
00007fb1689d325f  movaps xmm11, xmm12
00007fb1689d3263  mulpd xmm11, xmm15
00007fb1689d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007fb1689d326e  ptest xmm8, xmm8
00007fb1689d3274  jnz 0x00007FB1689D6EEF
00007fb1689d327a  vmovaps xmm15, [rsp+0x90]
00007fb1689d3283  vpermilpd xmm15, xmm15, 0x00
00007fb1689d3289  vmovaps xmm8, [rsp+0x50]
00007fb1689d328f  movaps xmm12, xmm8
00007fb1689d3293  mulpd xmm12, xmm15
00007fb1689d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007fb1689d329e  ptest xmm6, xmm6
00007fb1689d32a3  jnz 0x00007FB1689D7033
00007fb1689d32a9  vmovaps xmm15, [rsp+0x30]
00007fb1689d32af  vpermilpd xmm15, xmm15, 0x00
00007fb1689d32b5  movaps xmm8, xmm7
00007fb1689d32b9  mulpd xmm8, xmm15
00007fb1689d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007fb1689d32c4  ptest xmm6, xmm6
00007fb1689d32c9  jnz 0x00007FB1689D7177
00007fb1689d32cf  movaps xmm15, xmm14
00007fb1689d32d3  addpd xmm15, xmm9
00007fb1689d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007fb1689d32de  ptest xmm7, xmm7
00007fb1689d32e3  jnz 0x00007FB1689D72BA
00007fb1689d32e9  vmovaps xmm14, [rsp+0x30]
00007fb1689d32ef  vpermilpd xmm14, xmm14, 0x00
00007fb1689d32f5  vmovaps xmm7, [rsp+0xF0]
00007fb1689d32fe  movaps xmm9, xmm7
00007fb1689d3302  mulpd xmm9, xmm14
00007fb1689d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007fb1689d330d  ptest xmm6, xmm6
00007fb1689d3312  jnz 0x00007FB1689D73FE
00007fb1689d3318  movaps xmm14, xmm13
00007fb1689d331c  addpd xmm14, xmm11
00007fb1689d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007fb1689d3327  ptest xmm7, xmm7
00007fb1689d332c  jnz 0x00007FB1689D7541
00007fb1689d3332  vmovaps xmm13, [rsp+0x30]
00007fb1689d3338  vpermilpd xmm13, xmm13, 0x00
00007fb1689d333e  vmovaps xmm7, [rsp+0x60]
00007fb1689d3344  movaps xmm11, xmm7
00007fb1689d3348  mulpd xmm11, xmm13
00007fb1689d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007fb1689d3353  ptest xmm6, xmm6
00007fb1689d3358  jnz 0x00007FB1689D7685
00007fb1689d335e  movaps xmm13, xmm10
00007fb1689d3362  addpd xmm13, xmm12
00007fb1689d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007fb1689d336d  ptest xmm7, xmm7
00007fb1689d3372  jnz 0x00007FB1689D77C8
00007fb1689d3378  vmovaps xmm12, [rsp+0x30]
00007fb1689d337e  vpermilpd xmm12, xmm12, 0x00
00007fb1689d3384  vmovaps xmm7, [rsp+0x70]
00007fb1689d338a  movaps xmm10, xmm7
00007fb1689d338e  mulpd xmm10, xmm12
00007fb1689d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007fb1689d3399  ptest xmm6, xmm6
00007fb1689d339e  jnz 0x00007FB1689D790C
00007fb1689d33a4  movaps xmm12, xmm1
00007fb1689d33a8  addpd xmm12, xmm8
00007fb1689d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007fb1689d33b3  ptest xmm7, xmm7
00007fb1689d33b8  jnz 0x00007FB1689D7A4F
00007fb1689d33be  lea rax, [r14+0x70]
00007fb1689d33c2  movups xmm1, [r13+rax*1]
00007fb1689d33c8  movaps [r15+0x240], xmm1
00007fb1689d33d0  movaps xmm8, xmm15
00007fb1689d33d4  addpd xmm8, xmm9
00007fb1689d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007fb1689d33df  ptest xmm7, xmm7
00007fb1689d33e4  jnz 0x00007FB1689D7B9C
00007fb1689d33ea  movaps [r15+0x170], xmm8
00007fb1689d33f2  vmovaps xmm15, [rsp+0x40]
00007fb1689d33f8  vpermilpd xmm15, xmm15, 0x00
00007fb1689d33fe  movaps xmm9, xmm1
00007fb1689d3402  mulpd xmm9, xmm15
00007fb1689d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007fb1689d340d  ptest xmm7, xmm7
00007fb1689d3412  jnz 0x00007FB1689D7CE0
00007fb1689d3418  vmovaps xmm1, [rsp+0x40]
00007fb1689d341e  vpermilpd xmm1, xmm1, 0x00
00007fb1689d3424  movaps xmm15, xmm4
00007fb1689d3428  mulpd xmm15, xmm1
00007fb1689d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007fb1689d3433  ptest xmm7, xmm7
00007fb1689d3438  jnz 0x00007FB1689D7E23
00007fb1689d343e  movaps [r15+0x180], xmm15
00007fb1689d3446  movaps xmm1, xmm14
00007fb1689d344a  addpd xmm1, xmm11
00007fb1689d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007fb1689d3454  ptest xmm7, xmm7
00007fb1689d3459  jnz 0x00007FB1689D7F65
00007fb1689d345f  movaps [r15+0x210], xmm1
00007fb1689d3467  movups xmm14, [r13+r14*1]
00007fb1689d346d  lea rax, [r14+0x10]
00007fb1689d3471  movups xmm11, [r13+rax*1]
00007fb1689d3477  movaps [r15+0x230], xmm11
00007fb1689d347f  movaps xmm7, xmm13
00007fb1689d3483  addpd xmm7, xmm10
00007fb1689d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007fb1689d348d  ptest xmm6, xmm6
00007fb1689d3492  jnz 0x00007FB1689D80BB
00007fb1689d3498  movaps [r15+0x130], xmm7
00007fb1689d34a0  vmovaps xmm13, [rsp+0x40]
00007fb1689d34a6  vpermilpd xmm13, xmm13, 0x00
00007fb1689d34ac  movaps xmm10, xmm11
00007fb1689d34b0  mulpd xmm10, xmm13
00007fb1689d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007fb1689d34bb  ptest xmm6, xmm6
00007fb1689d34c0  jnz 0x00007FB1689D81FD
00007fb1689d34c6  movaps [r15+0x220], xmm10
00007fb1689d34ce  vmovaps xmm13, [rsp+0x40]
00007fb1689d34d4  vpermilpd xmm13, xmm13, 0x00
00007fb1689d34da  movaps xmm11, xmm14
00007fb1689d34de  mulpd xmm11, xmm13
00007fb1689d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007fb1689d34e9  ptest xmm6, xmm6
00007fb1689d34ee  jnz 0x00007FB1689D8341
00007fb1689d34f4  movaps xmm14, xmm12
00007fb1689d34f8  addpd xmm14, xmm9
00007fb1689d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007fb1689d3503  ptest xmm13, xmm13
00007fb1689d3509  jnz 0x00007FB1689D8485
00007fb1689d350f  movaps [r15+0x140], xmm14
00007fb1689d3517  movaps xmm13, xmm8
00007fb1689d351b  addpd xmm13, xmm15
00007fb1689d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007fb1689d3526  ptest xmm12, xmm12
00007fb1689d352c  jnz 0x00007FB1689D85C9
00007fb1689d3532  movaps [r15+0x150], xmm13
00007fb1689d353a  movaps xmm15, xmm1
00007fb1689d353e  addpd xmm15, xmm10
00007fb1689d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007fb1689d3549  ptest xmm12, xmm12
00007fb1689d354f  jnz 0x00007FB1689D870D
00007fb1689d3555  movaps [r15+0x160], xmm15
00007fb1689d355d  movaps xmm1, xmm7
00007fb1689d3560  addpd xmm1, xmm11
00007fb1689d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007fb1689d356a  ptest xmm12, xmm12
00007fb1689d3570  jnz 0x00007FB1689D8850
00007fb1689d3576  movaps [r15+0x120], xmm1
00007fb1689d357e  mov eax, 0x432200
00007fb1689d3583  movups [r13+rax*1], xmm14
00007fb1689d3589  mov eax, 0x432210
00007fb1689d358e  movups [r13+rax*1], xmm13
00007fb1689d3594  mov eax, 0x432220
00007fb1689d3599  movups [r13+rax*1], xmm15
00007fb1689d359f  mov eax, 0x432230
00007fb1689d35a4  movups [r13+rax*1], xmm1
00007fb1689d35aa  mov eax, [r15+0x108]
00007fb1689d35b1  sahf
00007fb1689d35b2  jnz 0x00007FB1689D35E4
00007fb1689d35b4  cmp dword ptr [r15+0x318], 0x00
00007fb1689d35bc  jz 0x00007FB1689DEAE0
00007fb1689d35c2  nop [rax+rax*1], ax
00007fb1689d35cb  nop [rax+rax*1], eax
00007fb1689d35d3  mov eax, 0x4106D0
00007fb1689d35d8  mov [r15+0x100], rax
00007fb1689d35df  jmp 0x00007FB1687FE110
00007fb1689d35e4  cmp dword ptr [r15+0x318], 0x00
00007fb1689d35ec  jz 0x00007FB1689D89C0
00007fb1689d35f2  nop [rax+rax*1], ax
00007fb1689d35fb  nop [rax+rax*1], eax
00007fb1689d3603  mov eax, 0x410504
00007fb1689d3608  mov [r15+0x100], rax
00007fb1689d360f  jmp 0x00007FB1687FE110
00007fb1689d3614  int3
00007fb1689d3615  call 0x00007FB1688D64F0
00007fb1689d361a  jmp 0x00007FB1689D2311
00007fb1689d361f  call 0x00007FB1688E5820
00007fb1689d3624  jmp 0x00007FB1689D231E
00007fb1689d3629  call 0x00007FB1688E3320
00007fb1689d362e  jmp 0x00007FB1689D2332
00007fb1689d3633  call 0x00007FB1688E20A0
00007fb1689d3638  jmp 0x00007FB1689D233C
00007fb1689d363d  call 0x00007FB168809D70
00007fb1689d3642  jmp 0x00007FB1689D234A
00007fb1689d3647  call 0x00007FB1688DFBC0
00007fb1689d364c  jmp 0x00007FB1689D2354
00007fb1689d3651  call 0x00007FB1688C4740
00007fb1689d3656  jmp 0x00007FB1689D2368
00007fb1689d365b  call 0x00007FB1688B5400
00007fb1689d3660  jmp 0x00007FB1689D2375
00007fb1689d3665  call 0x00007FB1688B52F0
00007fb1689d366a  jmp 0x00007FB1689D2382
00007fb1689d366f  call 0x00007FB1688C4620
00007fb1689d3674  jmp 0x00007FB1689D238F
00007fb1689d3679  call 0x00007FB1688BD750
00007fb1689d367e  jmp 0x00007FB1689D239C
00007fb1689d3683  call 0x00007FB1688BC4E0
00007fb1689d3688  jmp 0x00007FB1689D23A9
00007fb1689d368d  call 0x00007FB1688BB270
00007fb1689d3692  jmp 0x00007FB1689D23B6
00007fb1689d3697  call 0x00007FB1688BA000
00007fb1689d369c  jmp 0x00007FB1689D23C3
00007fb1689d36a1  call 0x00007FB1688C4740
00007fb1689d36a6  jmp 0x00007FB1689D23D0
00007fb1689d36ab  call 0x00007FB1688B5400
00007fb1689d36b0  jmp 0x00007FB1689D23DD
00007fb1689d36b5  call 0x00007FB1688B52F0
00007fb1689d36ba  jmp 0x00007FB1689D23EA
00007fb1689d36bf  call 0x00007FB1688C4620
00007fb1689d36c4  jmp 0x00007FB1689D23F7
00007fb1689d36c9  call 0x00007FB1688B8D90
00007fb1689d36ce  jmp 0x00007FB1689D2404
00007fb1689d36d3  call 0x00007FB1688B8A20
00007fb1689d36d8  jmp 0x00007FB1689D2411
00007fb1689d36dd  call 0x00007FB1688B77B0
00007fb1689d36e2  jmp 0x00007FB1689D241B
00007fb1689d36e7  call 0x00007FB1688B6550
00007fb1689d36ec  jmp 0x00007FB1689D2425
00007fb1689d36f1  call 0x00007FB1688B5400
00007fb1689d36f6  jmp 0x00007FB1689D2437
00007fb1689d36fb  call 0x00007FB1688C0FC0
00007fb1689d3700  jmp 0x00007FB1689D2441
00007fb1689d3705  call 0x00007FB1688B52F0
00007fb1689d370a  jmp 0x00007FB1689D244B
00007fb1689d370f  call 0x00007FB1688C0EA0
00007fb1689d3714  jmp 0x00007FB1689D2455
00007fb1689d3719  call 0x00007FB1688BFD50
00007fb1689d371e  jmp 0x00007FB1689D245F
00007fb1689d3723  call 0x00007FB1688B8EA0
00007fb1689d3728  jmp 0x00007FB1689D2469
00007fb1689d372d  call 0x00007FB1688BFC30
00007fb1689d3732  jmp 0x00007FB1689D2476
00007fb1689d3737  call 0x00007FB1688B8D90
00007fb1689d373c  jmp 0x00007FB1689D2483
00007fb1689d3741  call 0x00007FB1688B52F0
00007fb1689d3746  jmp 0x00007FB1689D2496
00007fb1689d374b  call 0x00007FB1688B52F0
00007fb1689d3750  jmp 0x00007FB1689D24A9
00007fb1689d3755  call 0x00007FB1688C0FC0
00007fb1689d375a  jmp 0x00007FB1689D24B6
00007fb1689d375f  call 0x00007FB1688C0FC0
00007fb1689d3764  jmp 0x00007FB1689D24C9
00007fb1689d3769  call 0x00007FB1688C0EA0
00007fb1689d376e  jmp 0x00007FB1689D24D6
00007fb1689d3773  call 0x00007FB1688B52F0
00007fb1689d3778  jmp 0x00007FB1689D24E9
00007fb1689d377d  call 0x00007FB1688B52F0
00007fb1689d3782  jmp 0x00007FB1689D24FC
00007fb1689d3787  call 0x00007FB1688B52F0
00007fb1689d378c  jmp 0x00007FB1689D250F
00007fb1689d3791  call 0x00007FB1688B52F0
00007fb1689d3796  jmp 0x00007FB1689D252A
00007fb1689d379b  call 0x00007FB1688B52F0
00007fb1689d37a0  jmp 0x00007FB1689D253D
00007fb1689d37a5  call 0x00007FB1688B5400
00007fb1689d37aa  jmp 0x00007FB1689D257E
00007fb1689d37af  call 0x00007FB1688C0FC0
00007fb1689d37b4  jmp 0x00007FB1689D258B
00007fb1689d37b9  call 0x00007FB1688B52F0
00007fb1689d37be  jmp 0x00007FB1689D2598
00007fb1689d37c3  call 0x00007FB1688C0EA0
00007fb1689d37c8  jmp 0x00007FB1689D25A5
00007fb1689d37cd  call 0x00007FB1687FF540
00007fb1689d37d2  jmp 0x00007FB1689D25C3
00007fb1689d37d7  call 0x00007FB168808C20
00007fb1689d37dc  jmp 0x00007FB1689D25CD
00007fb1689d37e1  call 0x00007FB1688E21C0
00007fb1689d37e6  jmp 0x00007FB1689D25D3
00007fb1689d37eb  call 0x00007FB1687FF540
00007fb1689d37f0  jmp 0x00007FB1689D25E3
00007fb1689d37f5  call 0x00007FB1688C0370
00007fb1689d37fa  jmp 0x00007FB1689D2611
00007fb1689d37ff  call 0x00007FB1688BF100
00007fb1689d3804  jmp 0x00007FB1689D261A
00007fb1689d3809  call 0x00007FB1688C0370
00007fb1689d380e  jmp 0x00007FB1689D2674
00007fb1689d3813  call 0x00007FB1688BF100
00007fb1689d3818  jmp 0x00007FB1689D267D
00007fb1689d381d  call 0x00007FB1688C0370
00007fb1689d3822  jmp 0x00007FB1689D26C6
00007fb1689d3827  call 0x00007FB1688BF100
00007fb1689d382c  jmp 0x00007FB1689D26CF
00007fb1689d3831  call 0x00007FB16880B720
00007fb1689d3836  jmp 0x00007FB1689D2714
00007fb1689d383b  call 0x00007FB1688B47C0
00007fb1689d3840  jmp 0x00007FB1689D2727
00007fb1689d3845  call 0x00007FB168808B00
00007fb1689d384a  jmp 0x00007FB1689D273E
00007fb1689d384f  call 0x00007FB1687FF430
00007fb1689d3854  jmp 0x00007FB1689D2751
00007fb1689d3859  call 0x00007FB1687FF430
00007fb1689d385e  jmp 0x00007FB1689D2764
00007fb1689d3863  sub rsp, 0x08
00007fb1689d3867  push rax
00007fb1689d3868  push rcx
00007fb1689d3869  push rdx
00007fb1689d386a  push rdi
00007fb1689d386b  push rsi
00007fb1689d386c  push r8
00007fb1689d386e  push r9
00007fb1689d3870  push r10
00007fb1689d3872  push r11
00007fb1689d3874  sub rsp, 0xF0
00007fb1689d387b  vmovaps [rsp], xmm0
00007fb1689d3880  vmovaps [rsp+0x10], xmm2
00007fb1689d3886  vmovaps [rsp+0x20], xmm3
00007fb1689d388c  vmovaps [rsp+0x30], xmm4
00007fb1689d3892  vmovaps [rsp+0x40], xmm5
00007fb1689d3898  vmovaps [rsp+0x50], xmm6
00007fb1689d389e  vmovaps [rsp+0x60], xmm7
00007fb1689d38a4  vmovaps [rsp+0x70], xmm8
00007fb1689d38aa  vmovaps [rsp+0x80], xmm9
00007fb1689d38b3  vmovaps [rsp+0x90], xmm10
00007fb1689d38bc  vmovaps [rsp+0xA0], xmm11
00007fb1689d38c5  vmovaps [rsp+0xB0], xmm12
00007fb1689d38ce  vmovaps [rsp+0xC0], xmm13
00007fb1689d38d7  vmovaps [rsp+0xD0], xmm14
00007fb1689d38e0  vmovaps [rsp+0xE0], xmm15
00007fb1689d38e9  sub rsp, 0x30
00007fb1689d38ed  movaps [rsp], xmm1
00007fb1689d38f1  movaps [rsp+0x10], xmm12
00007fb1689d38f7  movaps [rsp+0x20], xmm15
00007fb1689d38fd  lea rdi, [rsp]
00007fb1689d3901  mov esi, 0x00
00007fb1689d3906  mov rax, 0x57CCFD419530
00007fb1689d3910  call rax
00007fb1689d3912  movaps xmm1, [rsp]
00007fb1689d3916  add rsp, 0x30
00007fb1689d391a  vmovaps xmm0, [rsp]
00007fb1689d391f  vmovaps xmm2, [rsp+0x10]
00007fb1689d3925  vmovaps xmm3, [rsp+0x20]
00007fb1689d392b  vmovaps xmm4, [rsp+0x30]
00007fb1689d3931  vmovaps xmm5, [rsp+0x40]
00007fb1689d3937  vmovaps xmm6, [rsp+0x50]
00007fb1689d393d  vmovaps xmm7, [rsp+0x60]
00007fb1689d3943  vmovaps xmm8, [rsp+0x70]
00007fb1689d3949  vmovaps xmm9, [rsp+0x80]
00007fb1689d3952  vmovaps xmm10, [rsp+0x90]
00007fb1689d395b  vmovaps xmm11, [rsp+0xA0]
00007fb1689d3964  vmovaps xmm12, [rsp+0xB0]
00007fb1689d396d  vmovaps xmm13, [rsp+0xC0]
00007fb1689d3976  vmovaps xmm14, [rsp+0xD0]
00007fb1689d397f  vmovaps xmm15, [rsp+0xE0]
00007fb1689d3988  add rsp, 0xF0
00007fb1689d398f  pop r11
00007fb1689d3991  pop r10
00007fb1689d3993  pop r9
00007fb1689d3995  pop r8
00007fb1689d3997  pop rsi
00007fb1689d3998  pop rdi
00007fb1689d3999  pop rdx
00007fb1689d399a  pop rcx
00007fb1689d399b  pop rax
00007fb1689d399c  add rsp, 0x08
00007fb1689d39a0  jmp 0x00007FB1689D27B2
00007fb1689d39a5  sub rsp, 0x08
00007fb1689d39a9  push rax
00007fb1689d39aa  push rcx
00007fb1689d39ab  push rdx
00007fb1689d39ac  push rdi
00007fb1689d39ad  push rsi
00007fb1689d39ae  push r8
00007fb1689d39b0  push r9
00007fb1689d39b2  push r10
00007fb1689d39b4  push r11
00007fb1689d39b6  sub rsp, 0xF0
00007fb1689d39bd  vmovaps [rsp], xmm0
00007fb1689d39c2  vmovaps [rsp+0x10], xmm1
00007fb1689d39c8  vmovaps [rsp+0x20], xmm2
00007fb1689d39ce  vmovaps [rsp+0x30], xmm3
00007fb1689d39d4  vmovaps [rsp+0x40], xmm4
00007fb1689d39da  vmovaps [rsp+0x50], xmm5
00007fb1689d39e0  vmovaps [rsp+0x60], xmm6
00007fb1689d39e6  vmovaps [rsp+0x70], xmm7
00007fb1689d39ec  vmovaps [rsp+0x80], xmm8
00007fb1689d39f5  vmovaps [rsp+0x90], xmm9
00007fb1689d39fe  vmovaps [rsp+0xA0], xmm10
00007fb1689d3a07  vmovaps [rsp+0xB0], xmm11
00007fb1689d3a10  vmovaps [rsp+0xC0], xmm12
00007fb1689d3a19  vmovaps [rsp+0xD0], xmm13
00007fb1689d3a22  vmovaps [rsp+0xE0], xmm15
00007fb1689d3a2b  sub rsp, 0x30
00007fb1689d3a2f  movaps [rsp], xmm14
00007fb1689d3a34  movaps [rsp+0x10], xmm1
00007fb1689d3a39  movaps [rsp+0x20], xmm15
00007fb1689d3a3f  lea rdi, [rsp]
00007fb1689d3a43  mov esi, 0x00
00007fb1689d3a48  mov rax, 0x57CCFD419530
00007fb1689d3a52  call rax
00007fb1689d3a54  movaps xmm14, [rsp]
00007fb1689d3a59  add rsp, 0x30
00007fb1689d3a5d  vmovaps xmm0, [rsp]
00007fb1689d3a62  vmovaps xmm1, [rsp+0x10]
00007fb1689d3a68  vmovaps xmm2, [rsp+0x20]
00007fb1689d3a6e  vmovaps xmm3, [rsp+0x30]
00007fb1689d3a74  vmovaps xmm4, [rsp+0x40]
00007fb1689d3a7a  vmovaps xmm5, [rsp+0x50]
00007fb1689d3a80  vmovaps xmm6, [rsp+0x60]
00007fb1689d3a86  vmovaps xmm7, [rsp+0x70]
00007fb1689d3a8c  vmovaps xmm8, [rsp+0x80]
00007fb1689d3a95  vmovaps xmm9, [rsp+0x90]
00007fb1689d3a9e  vmovaps xmm10, [rsp+0xA0]
00007fb1689d3aa7  vmovaps xmm11, [rsp+0xB0]
00007fb1689d3ab0  vmovaps xmm12, [rsp+0xC0]
00007fb1689d3ab9  vmovaps xmm13, [rsp+0xD0]
00007fb1689d3ac2  vmovaps xmm15, [rsp+0xE0]
00007fb1689d3acb  add rsp, 0xF0
00007fb1689d3ad2  pop r11
00007fb1689d3ad4  pop r10
00007fb1689d3ad6  pop r9
00007fb1689d3ad8  pop r8
00007fb1689d3ada  pop rsi
00007fb1689d3adb  pop rdi
00007fb1689d3adc  pop rdx
00007fb1689d3add  pop rcx
00007fb1689d3ade  pop rax
00007fb1689d3adf  add rsp, 0x08
00007fb1689d3ae3  jmp 0x00007FB1689D2800
00007fb1689d3ae8  sub rsp, 0x08
00007fb1689d3aec  push rax
00007fb1689d3aed  push rcx
00007fb1689d3aee  push rdx
00007fb1689d3aef  push rdi
00007fb1689d3af0  push rsi
00007fb1689d3af1  push r8
00007fb1689d3af3  push r9
00007fb1689d3af5  push r10
00007fb1689d3af7  push r11
00007fb1689d3af9  sub rsp, 0xF0
00007fb1689d3b00  vmovaps [rsp], xmm0
00007fb1689d3b05  vmovaps [rsp+0x10], xmm1
00007fb1689d3b0b  vmovaps [rsp+0x20], xmm2
00007fb1689d3b11  vmovaps [rsp+0x30], xmm3
00007fb1689d3b17  vmovaps [rsp+0x40], xmm4
00007fb1689d3b1d  vmovaps [rsp+0x50], xmm5
00007fb1689d3b23  vmovaps [rsp+0x60], xmm6
00007fb1689d3b29  vmovaps [rsp+0x70], xmm7
00007fb1689d3b2f  vmovaps [rsp+0x80], xmm8
00007fb1689d3b38  vmovaps [rsp+0x90], xmm9
00007fb1689d3b41  vmovaps [rsp+0xA0], xmm10
00007fb1689d3b4a  vmovaps [rsp+0xB0], xmm11
00007fb1689d3b53  vmovaps [rsp+0xC0], xmm12
00007fb1689d3b5c  vmovaps [rsp+0xD0], xmm13
00007fb1689d3b65  vmovaps [rsp+0xE0], xmm14
00007fb1689d3b6e  sub rsp, 0x30
00007fb1689d3b72  movaps [rsp], xmm15
00007fb1689d3b77  movaps [rsp+0x10], xmm12
00007fb1689d3b7d  movaps [rsp+0x20], xmm13
00007fb1689d3b83  lea rdi, [rsp]
00007fb1689d3b87  mov esi, 0x00
00007fb1689d3b8c  mov rax, 0x57CCFD419530
00007fb1689d3b96  call rax
00007fb1689d3b98  movaps xmm15, [rsp]
00007fb1689d3b9d  add rsp, 0x30
00007fb1689d3ba1  vmovaps xmm0, [rsp]
00007fb1689d3ba6  vmovaps xmm1, [rsp+0x10]
00007fb1689d3bac  vmovaps xmm2, [rsp+0x20]
00007fb1689d3bb2  vmovaps xmm3, [rsp+0x30]
00007fb1689d3bb8  vmovaps xmm4, [rsp+0x40]
00007fb1689d3bbe  vmovaps xmm5, [rsp+0x50]
00007fb1689d3bc4  vmovaps xmm6, [rsp+0x60]
00007fb1689d3bca  vmovaps xmm7, [rsp+0x70]
00007fb1689d3bd0  vmovaps xmm8, [rsp+0x80]
00007fb1689d3bd9  vmovaps xmm9, [rsp+0x90]
00007fb1689d3be2  vmovaps xmm10, [rsp+0xA0]
00007fb1689d3beb  vmovaps xmm11, [rsp+0xB0]
00007fb1689d3bf4  vmovaps xmm12, [rsp+0xC0]
00007fb1689d3bfd  vmovaps xmm13, [rsp+0xD0]
00007fb1689d3c06  vmovaps xmm14, [rsp+0xE0]
00007fb1689d3c0f  add rsp, 0xF0
00007fb1689d3c16  pop r11
00007fb1689d3c18  pop r10
00007fb1689d3c1a  pop r9
00007fb1689d3c1c  pop r8
00007fb1689d3c1e  pop rsi
00007fb1689d3c1f  pop rdi
00007fb1689d3c20  pop rdx
00007fb1689d3c21  pop rcx
00007fb1689d3c22  pop rax
00007fb1689d3c23  add rsp, 0x08
00007fb1689d3c27  jmp 0x00007FB1689D2835
00007fb1689d3c2c  sub rsp, 0x08
00007fb1689d3c30  push rax
00007fb1689d3c31  push rcx
00007fb1689d3c32  push rdx
00007fb1689d3c33  push rdi
00007fb1689d3c34  push rsi
00007fb1689d3c35  push r8
00007fb1689d3c37  push r9
00007fb1689d3c39  push r10
00007fb1689d3c3b  push r11
00007fb1689d3c3d  sub rsp, 0xF0
00007fb1689d3c44  vmovaps [rsp], xmm0
00007fb1689d3c49  vmovaps [rsp+0x10], xmm2
00007fb1689d3c4f  vmovaps [rsp+0x20], xmm3
00007fb1689d3c55  vmovaps [rsp+0x30], xmm4
00007fb1689d3c5b  vmovaps [rsp+0x40], xmm5
00007fb1689d3c61  vmovaps [rsp+0x50], xmm6
00007fb1689d3c67  vmovaps [rsp+0x60], xmm7
00007fb1689d3c6d  vmovaps [rsp+0x70], xmm8
00007fb1689d3c73  vmovaps [rsp+0x80], xmm9
00007fb1689d3c7c  vmovaps [rsp+0x90], xmm10
00007fb1689d3c85  vmovaps [rsp+0xA0], xmm11
00007fb1689d3c8e  vmovaps [rsp+0xB0], xmm12
00007fb1689d3c97  vmovaps [rsp+0xC0], xmm13
00007fb1689d3ca0  vmovaps [rsp+0xD0], xmm14
00007fb1689d3ca9  vmovaps [rsp+0xE0], xmm15
00007fb1689d3cb2  sub rsp, 0x30
00007fb1689d3cb6  movaps [rsp], xmm1
00007fb1689d3cba  movaps [rsp+0x10], xmm12
00007fb1689d3cc0  movaps [rsp+0x20], xmm10
00007fb1689d3cc6  lea rdi, [rsp]
00007fb1689d3cca  mov esi, 0x00
00007fb1689d3ccf  mov rax, 0x57CCFD419530
00007fb1689d3cd9  call rax
00007fb1689d3cdb  movaps xmm1, [rsp]
00007fb1689d3cdf  add rsp, 0x30
00007fb1689d3ce3  vmovaps xmm0, [rsp]
00007fb1689d3ce8  vmovaps xmm2, [rsp+0x10]
00007fb1689d3cee  vmovaps xmm3, [rsp+0x20]
00007fb1689d3cf4  vmovaps xmm4, [rsp+0x30]
00007fb1689d3cfa  vmovaps xmm5, [rsp+0x40]
00007fb1689d3d00  vmovaps xmm6, [rsp+0x50]
00007fb1689d3d06  vmovaps xmm7, [rsp+0x60]
00007fb1689d3d0c  vmovaps xmm8, [rsp+0x70]
00007fb1689d3d12  vmovaps xmm9, [rsp+0x80]
00007fb1689d3d1b  vmovaps xmm10, [rsp+0x90]
00007fb1689d3d24  vmovaps xmm11, [rsp+0xA0]
00007fb1689d3d2d  vmovaps xmm12, [rsp+0xB0]
00007fb1689d3d36  vmovaps xmm13, [rsp+0xC0]
00007fb1689d3d3f  vmovaps xmm14, [rsp+0xD0]
00007fb1689d3d48  vmovaps xmm15, [rsp+0xE0]
00007fb1689d3d51  add rsp, 0xF0
00007fb1689d3d58  pop r11
00007fb1689d3d5a  pop r10
00007fb1689d3d5c  pop r9
00007fb1689d3d5e  pop r8
00007fb1689d3d60  pop rsi
00007fb1689d3d61  pop rdi
00007fb1689d3d62  pop rdx
00007fb1689d3d63  pop rcx
00007fb1689d3d64  pop rax
00007fb1689d3d65  add rsp, 0x08
00007fb1689d3d69  jmp 0x00007FB1689D284F
00007fb1689d3d6e  sub rsp, 0x08
00007fb1689d3d72  push rax
00007fb1689d3d73  push rcx
00007fb1689d3d74  push rdx
00007fb1689d3d75  push rdi
00007fb1689d3d76  push rsi
00007fb1689d3d77  push r8
00007fb1689d3d79  push r9
00007fb1689d3d7b  push r10
00007fb1689d3d7d  push r11
00007fb1689d3d7f  sub rsp, 0xF0
00007fb1689d3d86  vmovaps [rsp], xmm0
00007fb1689d3d8b  vmovaps [rsp+0x10], xmm1
00007fb1689d3d91  vmovaps [rsp+0x20], xmm2
00007fb1689d3d97  vmovaps [rsp+0x30], xmm3
00007fb1689d3d9d  vmovaps [rsp+0x40], xmm4
00007fb1689d3da3  vmovaps [rsp+0x50], xmm5
00007fb1689d3da9  vmovaps [rsp+0x60], xmm6
00007fb1689d3daf  vmovaps [rsp+0x70], xmm7
00007fb1689d3db5  vmovaps [rsp+0x80], xmm8
00007fb1689d3dbe  vmovaps [rsp+0x90], xmm9
00007fb1689d3dc7  vmovaps [rsp+0xA0], xmm10
00007fb1689d3dd0  vmovaps [rsp+0xB0], xmm11
00007fb1689d3dd9  vmovaps [rsp+0xC0], xmm12
00007fb1689d3de2  vmovaps [rsp+0xD0], xmm14
00007fb1689d3deb  vmovaps [rsp+0xE0], xmm15
00007fb1689d3df4  sub rsp, 0x30
00007fb1689d3df8  movaps [rsp], xmm13
00007fb1689d3dfd  movaps [rsp+0x10], xmm12
00007fb1689d3e03  movaps [rsp+0x20], xmm2
00007fb1689d3e08  lea rdi, [rsp]
00007fb1689d3e0c  mov esi, 0x00
00007fb1689d3e11  mov rax, 0x57CCFD419530
00007fb1689d3e1b  call rax
00007fb1689d3e1d  movaps xmm13, [rsp]
00007fb1689d3e22  add rsp, 0x30
00007fb1689d3e26  vmovaps xmm0, [rsp]
00007fb1689d3e2b  vmovaps xmm1, [rsp+0x10]
00007fb1689d3e31  vmovaps xmm2, [rsp+0x20]
00007fb1689d3e37  vmovaps xmm3, [rsp+0x30]
00007fb1689d3e3d  vmovaps xmm4, [rsp+0x40]
00007fb1689d3e43  vmovaps xmm5, [rsp+0x50]
00007fb1689d3e49  vmovaps xmm6, [rsp+0x60]
00007fb1689d3e4f  vmovaps xmm7, [rsp+0x70]
00007fb1689d3e55  vmovaps xmm8, [rsp+0x80]
00007fb1689d3e5e  vmovaps xmm9, [rsp+0x90]
00007fb1689d3e67  vmovaps xmm10, [rsp+0xA0]
00007fb1689d3e70  vmovaps xmm11, [rsp+0xB0]
00007fb1689d3e79  vmovaps xmm12, [rsp+0xC0]
00007fb1689d3e82  vmovaps xmm14, [rsp+0xD0]
00007fb1689d3e8b  vmovaps xmm15, [rsp+0xE0]
00007fb1689d3e94  add rsp, 0xF0
00007fb1689d3e9b  pop r11
00007fb1689d3e9d  pop r10
00007fb1689d3e9f  pop r9
00007fb1689d3ea1  pop r8
00007fb1689d3ea3  pop rsi
00007fb1689d3ea4  pop rdi
00007fb1689d3ea5  pop rdx
00007fb1689d3ea6  pop rcx
00007fb1689d3ea7  pop rax
00007fb1689d3ea8  add rsp, 0x08
00007fb1689d3eac  jmp 0x00007FB1689D286A
00007fb1689d3eb1  sub rsp, 0x08
00007fb1689d3eb5  push rax
00007fb1689d3eb6  push rcx
00007fb1689d3eb7  push rdx
00007fb1689d3eb8  push rdi
00007fb1689d3eb9  push rsi
00007fb1689d3eba  push r8
00007fb1689d3ebc  push r9
00007fb1689d3ebe  push r10
00007fb1689d3ec0  push r11
00007fb1689d3ec2  sub rsp, 0xF0
00007fb1689d3ec9  vmovaps [rsp], xmm0
00007fb1689d3ece  vmovaps [rsp+0x10], xmm2
00007fb1689d3ed4  vmovaps [rsp+0x20], xmm3
00007fb1689d3eda  vmovaps [rsp+0x30], xmm4
00007fb1689d3ee0  vmovaps [rsp+0x40], xmm5
00007fb1689d3ee6  vmovaps [rsp+0x50], xmm6
00007fb1689d3eec  vmovaps [rsp+0x60], xmm7
00007fb1689d3ef2  vmovaps [rsp+0x70], xmm8
00007fb1689d3ef8  vmovaps [rsp+0x80], xmm9
00007fb1689d3f01  vmovaps [rsp+0x90], xmm10
00007fb1689d3f0a  vmovaps [rsp+0xA0], xmm11
00007fb1689d3f13  vmovaps [rsp+0xB0], xmm12
00007fb1689d3f1c  vmovaps [rsp+0xC0], xmm13
00007fb1689d3f25  vmovaps [rsp+0xD0], xmm14
00007fb1689d3f2e  vmovaps [rsp+0xE0], xmm15
00007fb1689d3f37  sub rsp, 0x30
00007fb1689d3f3b  movaps [rsp], xmm1
00007fb1689d3f3f  movaps [rsp+0x10], xmm10
00007fb1689d3f45  movaps [rsp+0x20], xmm2
00007fb1689d3f4a  lea rdi, [rsp]
00007fb1689d3f4e  mov esi, 0x00
00007fb1689d3f53  mov rax, 0x57CCFD419530
00007fb1689d3f5d  call rax
00007fb1689d3f5f  movaps xmm1, [rsp]
00007fb1689d3f63  add rsp, 0x30
00007fb1689d3f67  vmovaps xmm0, [rsp]
00007fb1689d3f6c  vmovaps xmm2, [rsp+0x10]
00007fb1689d3f72  vmovaps xmm3, [rsp+0x20]
00007fb1689d3f78  vmovaps xmm4, [rsp+0x30]
00007fb1689d3f7e  vmovaps xmm5, [rsp+0x40]
00007fb1689d3f84  vmovaps xmm6, [rsp+0x50]
00007fb1689d3f8a  vmovaps xmm7, [rsp+0x60]
00007fb1689d3f90  vmovaps xmm8, [rsp+0x70]
00007fb1689d3f96  vmovaps xmm9, [rsp+0x80]
00007fb1689d3f9f  vmovaps xmm10, [rsp+0x90]
00007fb1689d3fa8  vmovaps xmm11, [rsp+0xA0]
00007fb1689d3fb1  vmovaps xmm12, [rsp+0xB0]
00007fb1689d3fba  vmovaps xmm13, [rsp+0xC0]
00007fb1689d3fc3  vmovaps xmm14, [rsp+0xD0]
00007fb1689d3fcc  vmovaps xmm15, [rsp+0xE0]
00007fb1689d3fd5  add rsp, 0xF0
00007fb1689d3fdc  pop r11
00007fb1689d3fde  pop r10
00007fb1689d3fe0  pop r9
00007fb1689d3fe2  pop r8
00007fb1689d3fe4  pop rsi
00007fb1689d3fe5  pop rdi
00007fb1689d3fe6  pop rdx
00007fb1689d3fe7  pop rcx
00007fb1689d3fe8  pop rax
00007fb1689d3fe9  add rsp, 0x08
00007fb1689d3fed  jmp 0x00007FB1689D28D2
00007fb1689d3ff2  sub rsp, 0x08
00007fb1689d3ff6  push rax
00007fb1689d3ff7  push rcx
00007fb1689d3ff8  push rdx
00007fb1689d3ff9  push rdi
00007fb1689d3ffa  push rsi
00007fb1689d3ffb  push r8
00007fb1689d3ffd  push r9
00007fb1689d3fff  push r10
00007fb1689d4001  push r11
00007fb1689d4003  sub rsp, 0xF0
00007fb1689d400a  vmovaps [rsp], xmm0
00007fb1689d400f  vmovaps [rsp+0x10], xmm1
00007fb1689d4015  vmovaps [rsp+0x20], xmm2
00007fb1689d401b  vmovaps [rsp+0x30], xmm3
00007fb1689d4021  vmovaps [rsp+0x40], xmm4
00007fb1689d4027  vmovaps [rsp+0x50], xmm5
00007fb1689d402d  vmovaps [rsp+0x60], xmm6
00007fb1689d4033  vmovaps [rsp+0x70], xmm7
00007fb1689d4039  vmovaps [rsp+0x80], xmm8
00007fb1689d4042  vmovaps [rsp+0x90], xmm9
00007fb1689d404b  vmovaps [rsp+0xA0], xmm10
00007fb1689d4054  vmovaps [rsp+0xB0], xmm11
00007fb1689d405d  vmovaps [rsp+0xC0], xmm12
00007fb1689d4066  vmovaps [rsp+0xD0], xmm13
00007fb1689d406f  vmovaps [rsp+0xE0], xmm14
00007fb1689d4078  sub rsp, 0x30
00007fb1689d407c  movaps [rsp], xmm15
00007fb1689d4081  movaps [rsp+0x10], xmm10
00007fb1689d4087  movaps [rsp+0x20], xmm2
00007fb1689d408c  lea rdi, [rsp]
00007fb1689d4090  mov esi, 0x00
00007fb1689d4095  mov rax, 0x57CCFD419530
00007fb1689d409f  call rax
00007fb1689d40a1  movaps xmm15, [rsp]
00007fb1689d40a6  add rsp, 0x30
00007fb1689d40aa  vmovaps xmm0, [rsp]
00007fb1689d40af  vmovaps xmm1, [rsp+0x10]
00007fb1689d40b5  vmovaps xmm2, [rsp+0x20]
00007fb1689d40bb  vmovaps xmm3, [rsp+0x30]
00007fb1689d40c1  vmovaps xmm4, [rsp+0x40]
00007fb1689d40c7  vmovaps xmm5, [rsp+0x50]
00007fb1689d40cd  vmovaps xmm6, [rsp+0x60]
00007fb1689d40d3  vmovaps xmm7, [rsp+0x70]
00007fb1689d40d9  vmovaps xmm8, [rsp+0x80]
00007fb1689d40e2  vmovaps xmm9, [rsp+0x90]
00007fb1689d40eb  vmovaps xmm10, [rsp+0xA0]
00007fb1689d40f4  vmovaps xmm11, [rsp+0xB0]
00007fb1689d40fd  vmovaps xmm12, [rsp+0xC0]
00007fb1689d4106  vmovaps xmm13, [rsp+0xD0]
00007fb1689d410f  vmovaps xmm14, [rsp+0xE0]
00007fb1689d4118  add rsp, 0xF0
00007fb1689d411f  pop r11
00007fb1689d4121  pop r10
00007fb1689d4123  pop r9
00007fb1689d4125  pop r8
00007fb1689d4127  pop rsi
00007fb1689d4128  pop rdi
00007fb1689d4129  pop rdx
00007fb1689d412a  pop rcx
00007fb1689d412b  pop rax
00007fb1689d412c  add rsp, 0x08
00007fb1689d4130  jmp 0x00007FB1689D2924
00007fb1689d4135  sub rsp, 0x08
00007fb1689d4139  push rax
00007fb1689d413a  push rcx
00007fb1689d413b  push rdx
00007fb1689d413c  push rdi
00007fb1689d413d  push rsi
00007fb1689d413e  push r8
00007fb1689d4140  push r9
00007fb1689d4142  push r10
00007fb1689d4144  push r11
00007fb1689d4146  sub rsp, 0xF0
00007fb1689d414d  vmovaps [rsp], xmm0
00007fb1689d4152  vmovaps [rsp+0x10], xmm2
00007fb1689d4158  vmovaps [rsp+0x20], xmm3
00007fb1689d415e  vmovaps [rsp+0x30], xmm4
00007fb1689d4164  vmovaps [rsp+0x40], xmm5
00007fb1689d416a  vmovaps [rsp+0x50], xmm6
00007fb1689d4170  vmovaps [rsp+0x60], xmm7
00007fb1689d4176  vmovaps [rsp+0x70], xmm8
00007fb1689d417c  vmovaps [rsp+0x80], xmm9
00007fb1689d4185  vmovaps [rsp+0x90], xmm10
00007fb1689d418e  vmovaps [rsp+0xA0], xmm11
00007fb1689d4197  vmovaps [rsp+0xB0], xmm12
00007fb1689d41a0  vmovaps [rsp+0xC0], xmm13
00007fb1689d41a9  vmovaps [rsp+0xD0], xmm14
00007fb1689d41b2  vmovaps [rsp+0xE0], xmm15
00007fb1689d41bb  sub rsp, 0x30
00007fb1689d41bf  movaps [rsp], xmm1
00007fb1689d41c3  movaps [rsp+0x10], xmm10
00007fb1689d41c9  movaps [rsp+0x20], xmm15
00007fb1689d41cf  lea rdi, [rsp]
00007fb1689d41d3  mov esi, 0x00
00007fb1689d41d8  mov rax, 0x57CCFD419530
00007fb1689d41e2  call rax
00007fb1689d41e4  movaps xmm1, [rsp]
00007fb1689d41e8  add rsp, 0x30
00007fb1689d41ec  vmovaps xmm0, [rsp]
00007fb1689d41f1  vmovaps xmm2, [rsp+0x10]
00007fb1689d41f7  vmovaps xmm3, [rsp+0x20]
00007fb1689d41fd  vmovaps xmm4, [rsp+0x30]
00007fb1689d4203  vmovaps xmm5, [rsp+0x40]
00007fb1689d4209  vmovaps xmm6, [rsp+0x50]
00007fb1689d420f  vmovaps xmm7, [rsp+0x60]
00007fb1689d4215  vmovaps xmm8, [rsp+0x70]
00007fb1689d421b  vmovaps xmm9, [rsp+0x80]
00007fb1689d4224  vmovaps xmm10, [rsp+0x90]
00007fb1689d422d  vmovaps xmm11, [rsp+0xA0]
00007fb1689d4236  vmovaps xmm12, [rsp+0xB0]
00007fb1689d423f  vmovaps xmm13, [rsp+0xC0]
00007fb1689d4248  vmovaps xmm14, [rsp+0xD0]
00007fb1689d4251  vmovaps xmm15, [rsp+0xE0]
00007fb1689d425a  add rsp, 0xF0
00007fb1689d4261  pop r11
00007fb1689d4263  pop r10
00007fb1689d4265  pop r9
00007fb1689d4267  pop r8
00007fb1689d4269  pop rsi
00007fb1689d426a  pop rdi
00007fb1689d426b  pop rdx
00007fb1689d426c  pop rcx
00007fb1689d426d  pop rax
00007fb1689d426e  add rsp, 0x08
00007fb1689d4272  jmp 0x00007FB1689D2962
00007fb1689d4277  sub rsp, 0x08
00007fb1689d427b  push rax
00007fb1689d427c  push rcx
00007fb1689d427d  push rdx
00007fb1689d427e  push rdi
00007fb1689d427f  push rsi
00007fb1689d4280  push r8
00007fb1689d4282  push r9
00007fb1689d4284  push r10
00007fb1689d4286  push r11
00007fb1689d4288  sub rsp, 0xF0
00007fb1689d428f  vmovaps [rsp], xmm0
00007fb1689d4294  vmovaps [rsp+0x10], xmm1
00007fb1689d429a  vmovaps [rsp+0x20], xmm2
00007fb1689d42a0  vmovaps [rsp+0x30], xmm3
00007fb1689d42a6  vmovaps [rsp+0x40], xmm4
00007fb1689d42ac  vmovaps [rsp+0x50], xmm5
00007fb1689d42b2  vmovaps [rsp+0x60], xmm6
00007fb1689d42b8  vmovaps [rsp+0x70], xmm7
00007fb1689d42be  vmovaps [rsp+0x80], xmm8
00007fb1689d42c7  vmovaps [rsp+0x90], xmm9
00007fb1689d42d0  vmovaps [rsp+0xA0], xmm10
00007fb1689d42d9  vmovaps [rsp+0xB0], xmm11
00007fb1689d42e2  vmovaps [rsp+0xC0], xmm12
00007fb1689d42eb  vmovaps [rsp+0xD0], xmm13
00007fb1689d42f4  vmovaps [rsp+0xE0], xmm15
00007fb1689d42fd  sub rsp, 0x30
00007fb1689d4301  movaps [rsp], xmm14
00007fb1689d4306  movaps [rsp+0x10], xmm10
00007fb1689d430c  movaps [rsp+0x20], xmm15
00007fb1689d4312  lea rdi, [rsp]
00007fb1689d4316  mov esi, 0x00
00007fb1689d431b  mov rax, 0x57CCFD419530
00007fb1689d4325  call rax
00007fb1689d4327  movaps xmm14, [rsp]
00007fb1689d432c  add rsp, 0x30
00007fb1689d4330  vmovaps xmm0, [rsp]
00007fb1689d4335  vmovaps xmm1, [rsp+0x10]
00007fb1689d433b  vmovaps xmm2, [rsp+0x20]
00007fb1689d4341  vmovaps xmm3, [rsp+0x30]
00007fb1689d4347  vmovaps xmm4, [rsp+0x40]
00007fb1689d434d  vmovaps xmm5, [rsp+0x50]
00007fb1689d4353  vmovaps xmm6, [rsp+0x60]
00007fb1689d4359  vmovaps xmm7, [rsp+0x70]
00007fb1689d435f  vmovaps xmm8, [rsp+0x80]
00007fb1689d4368  vmovaps xmm9, [rsp+0x90]
00007fb1689d4371  vmovaps xmm10, [rsp+0xA0]
00007fb1689d437a  vmovaps xmm11, [rsp+0xB0]
00007fb1689d4383  vmovaps xmm12, [rsp+0xC0]
00007fb1689d438c  vmovaps xmm13, [rsp+0xD0]
00007fb1689d4395  vmovaps xmm15, [rsp+0xE0]
00007fb1689d439e  add rsp, 0xF0
00007fb1689d43a5  pop r11
00007fb1689d43a7  pop r10
00007fb1689d43a9  pop r9
00007fb1689d43ab  pop r8
00007fb1689d43ad  pop rsi
00007fb1689d43ae  pop rdi
00007fb1689d43af  pop rdx
00007fb1689d43b0  pop rcx
00007fb1689d43b1  pop rax
00007fb1689d43b2  add rsp, 0x08
00007fb1689d43b6  jmp 0x00007FB1689D298E
00007fb1689d43bb  call 0x00007FB1687FF430
00007fb1689d43c0  jmp 0x00007FB1689D2A1E
00007fb1689d43c5  call 0x00007FB1687FF430
00007fb1689d43ca  jmp 0x00007FB1689D2A31
00007fb1689d43cf  sub rsp, 0x08
00007fb1689d43d3  push rax
00007fb1689d43d4  push rcx
00007fb1689d43d5  push rdx
00007fb1689d43d6  push rdi
00007fb1689d43d7  push rsi
00007fb1689d43d8  push r8
00007fb1689d43da  push r9
00007fb1689d43dc  push r10
00007fb1689d43de  push r11
00007fb1689d43e0  sub rsp, 0xF0
00007fb1689d43e7  vmovaps [rsp], xmm0
00007fb1689d43ec  vmovaps [rsp+0x10], xmm2
00007fb1689d43f2  vmovaps [rsp+0x20], xmm3
00007fb1689d43f8  vmovaps [rsp+0x30], xmm4
00007fb1689d43fe  vmovaps [rsp+0x40], xmm5
00007fb1689d4404  vmovaps [rsp+0x50], xmm6
00007fb1689d440a  vmovaps [rsp+0x60], xmm7
00007fb1689d4410  vmovaps [rsp+0x70], xmm8
00007fb1689d4416  vmovaps [rsp+0x80], xmm9
00007fb1689d441f  vmovaps [rsp+0x90], xmm10
00007fb1689d4428  vmovaps [rsp+0xA0], xmm11
00007fb1689d4431  vmovaps [rsp+0xB0], xmm12
00007fb1689d443a  vmovaps [rsp+0xC0], xmm13
00007fb1689d4443  vmovaps [rsp+0xD0], xmm14
00007fb1689d444c  vmovaps [rsp+0xE0], xmm15
00007fb1689d4455  sub rsp, 0x30
00007fb1689d4459  movaps [rsp], xmm1
00007fb1689d445d  movaps [rsp+0x10], xmm13
00007fb1689d4463  movaps [rsp+0x20], xmm2
00007fb1689d4468  lea rdi, [rsp]
00007fb1689d446c  mov esi, 0x00
00007fb1689d4471  mov rax, 0x57CCFD419530
00007fb1689d447b  call rax
00007fb1689d447d  movaps xmm1, [rsp]
00007fb1689d4481  add rsp, 0x30
00007fb1689d4485  vmovaps xmm0, [rsp]
00007fb1689d448a  vmovaps xmm2, [rsp+0x10]
00007fb1689d4490  vmovaps xmm3, [rsp+0x20]
00007fb1689d4496  vmovaps xmm4, [rsp+0x30]
00007fb1689d449c  vmovaps xmm5, [rsp+0x40]
00007fb1689d44a2  vmovaps xmm6, [rsp+0x50]
00007fb1689d44a8  vmovaps xmm7, [rsp+0x60]
00007fb1689d44ae  vmovaps xmm8, [rsp+0x70]
00007fb1689d44b4  vmovaps xmm9, [rsp+0x80]
00007fb1689d44bd  vmovaps xmm10, [rsp+0x90]
00007fb1689d44c6  vmovaps xmm11, [rsp+0xA0]
00007fb1689d44cf  vmovaps xmm12, [rsp+0xB0]
00007fb1689d44d8  vmovaps xmm13, [rsp+0xC0]
00007fb1689d44e1  vmovaps xmm14, [rsp+0xD0]
00007fb1689d44ea  vmovaps xmm15, [rsp+0xE0]
00007fb1689d44f3  add rsp, 0xF0
00007fb1689d44fa  pop r11
00007fb1689d44fc  pop r10
00007fb1689d44fe  pop r9
00007fb1689d4500  pop r8
00007fb1689d4502  pop rsi
00007fb1689d4503  pop rdi
00007fb1689d4504  pop rdx
00007fb1689d4505  pop rcx
00007fb1689d4506  pop rax
00007fb1689d4507  add rsp, 0x08
00007fb1689d450b  jmp 0x00007FB1689D2A5C
00007fb1689d4510  call 0x00007FB16880E760
00007fb1689d4515  jmp 0x00007FB1689D2A69
00007fb1689d451a  sub rsp, 0x08
00007fb1689d451e  push rax
00007fb1689d451f  push rcx
00007fb1689d4520  push rdx
00007fb1689d4521  push rdi
00007fb1689d4522  push rsi
00007fb1689d4523  push r8
00007fb1689d4525  push r9
00007fb1689d4527  push r10
00007fb1689d4529  push r11
00007fb1689d452b  sub rsp, 0xF0
00007fb1689d4532  vmovaps [rsp], xmm0
00007fb1689d4537  vmovaps [rsp+0x10], xmm1
00007fb1689d453d  vmovaps [rsp+0x20], xmm2
00007fb1689d4543  vmovaps [rsp+0x30], xmm3
00007fb1689d4549  vmovaps [rsp+0x40], xmm4
00007fb1689d454f  vmovaps [rsp+0x50], xmm5
00007fb1689d4555  vmovaps [rsp+0x60], xmm6
00007fb1689d455b  vmovaps [rsp+0x70], xmm7
00007fb1689d4561  vmovaps [rsp+0x80], xmm8
00007fb1689d456a  vmovaps [rsp+0x90], xmm9
00007fb1689d4573  vmovaps [rsp+0xA0], xmm10
00007fb1689d457c  vmovaps [rsp+0xB0], xmm11
00007fb1689d4585  vmovaps [rsp+0xC0], xmm12
00007fb1689d458e  vmovaps [rsp+0xD0], xmm14
00007fb1689d4597  vmovaps [rsp+0xE0], xmm15
00007fb1689d45a0  sub rsp, 0x30
00007fb1689d45a4  movaps [rsp], xmm13
00007fb1689d45a9  movaps [rsp+0x10], xmm2
00007fb1689d45ae  movaps [rsp+0x20], xmm1
00007fb1689d45b3  lea rdi, [rsp]
00007fb1689d45b7  mov esi, 0x00
00007fb1689d45bc  mov rax, 0x57CCFD419530
00007fb1689d45c6  call rax
00007fb1689d45c8  movaps xmm13, [rsp]
00007fb1689d45cd  add rsp, 0x30
00007fb1689d45d1  vmovaps xmm0, [rsp]
00007fb1689d45d6  vmovaps xmm1, [rsp+0x10]
00007fb1689d45dc  vmovaps xmm2, [rsp+0x20]
00007fb1689d45e2  vmovaps xmm3, [rsp+0x30]
00007fb1689d45e8  vmovaps xmm4, [rsp+0x40]
00007fb1689d45ee  vmovaps xmm5, [rsp+0x50]
00007fb1689d45f4  vmovaps xmm6, [rsp+0x60]
00007fb1689d45fa  vmovaps xmm7, [rsp+0x70]
00007fb1689d4600  vmovaps xmm8, [rsp+0x80]
00007fb1689d4609  vmovaps xmm9, [rsp+0x90]
00007fb1689d4612  vmovaps xmm10, [rsp+0xA0]
00007fb1689d461b  vmovaps xmm11, [rsp+0xB0]
00007fb1689d4624  vmovaps xmm12, [rsp+0xC0]
00007fb1689d462d  vmovaps xmm14, [rsp+0xD0]
00007fb1689d4636  vmovaps xmm15, [rsp+0xE0]
00007fb1689d463f  add rsp, 0xF0
00007fb1689d4646  pop r11
00007fb1689d4648  pop r10
00007fb1689d464a  pop r9
00007fb1689d464c  pop r8
00007fb1689d464e  pop rsi
00007fb1689d464f  pop rdi
00007fb1689d4650  pop rdx
00007fb1689d4651  pop rcx
00007fb1689d4652  pop rax
00007fb1689d4653  add rsp, 0x08
00007fb1689d4657  jmp 0x00007FB1689D2AA8
00007fb1689d465c  sub rsp, 0x08
00007fb1689d4660  push rax
00007fb1689d4661  push rcx
00007fb1689d4662  push rdx
00007fb1689d4663  push rdi
00007fb1689d4664  push rsi
00007fb1689d4665  push r8
00007fb1689d4667  push r9
00007fb1689d4669  push r10
00007fb1689d466b  push r11
00007fb1689d466d  sub rsp, 0xF0
00007fb1689d4674  vmovaps [rsp], xmm0
00007fb1689d4679  vmovaps [rsp+0x10], xmm2
00007fb1689d467f  vmovaps [rsp+0x20], xmm3
00007fb1689d4685  vmovaps [rsp+0x30], xmm4
00007fb1689d468b  vmovaps [rsp+0x40], xmm5
00007fb1689d4691  vmovaps [rsp+0x50], xmm6
00007fb1689d4697  vmovaps [rsp+0x60], xmm7
00007fb1689d469d  vmovaps [rsp+0x70], xmm8
00007fb1689d46a3  vmovaps [rsp+0x80], xmm9
00007fb1689d46ac  vmovaps [rsp+0x90], xmm10
00007fb1689d46b5  vmovaps [rsp+0xA0], xmm11
00007fb1689d46be  vmovaps [rsp+0xB0], xmm12
00007fb1689d46c7  vmovaps [rsp+0xC0], xmm13
00007fb1689d46d0  vmovaps [rsp+0xD0], xmm14
00007fb1689d46d9  vmovaps [rsp+0xE0], xmm15
00007fb1689d46e2  sub rsp, 0x30
00007fb1689d46e6  movaps [rsp], xmm1
00007fb1689d46ea  movaps [rsp+0x10], xmm14
00007fb1689d46f0  movaps [rsp+0x20], xmm15
00007fb1689d46f6  lea rdi, [rsp]
00007fb1689d46fa  mov esi, 0x00
00007fb1689d46ff  mov rax, 0x57CCFD419530
00007fb1689d4709  call rax
00007fb1689d470b  movaps xmm1, [rsp]
00007fb1689d470f  add rsp, 0x30
00007fb1689d4713  vmovaps xmm0, [rsp]
00007fb1689d4718  vmovaps xmm2, [rsp+0x10]
00007fb1689d471e  vmovaps xmm3, [rsp+0x20]
00007fb1689d4724  vmovaps xmm4, [rsp+0x30]
00007fb1689d472a  vmovaps xmm5, [rsp+0x40]
00007fb1689d4730  vmovaps xmm6, [rsp+0x50]
00007fb1689d4736  vmovaps xmm7, [rsp+0x60]
00007fb1689d473c  vmovaps xmm8, [rsp+0x70]
00007fb1689d4742  vmovaps xmm9, [rsp+0x80]
00007fb1689d474b  vmovaps xmm10, [rsp+0x90]
00007fb1689d4754  vmovaps xmm11, [rsp+0xA0]
00007fb1689d475d  vmovaps xmm12, [rsp+0xB0]
00007fb1689d4766  vmovaps xmm13, [rsp+0xC0]
00007fb1689d476f  vmovaps xmm14, [rsp+0xD0]
00007fb1689d4778  vmovaps xmm15, [rsp+0xE0]
00007fb1689d4781  add rsp, 0xF0
00007fb1689d4788  pop r11
00007fb1689d478a  pop r10
00007fb1689d478c  pop r9
00007fb1689d478e  pop r8
00007fb1689d4790  pop rsi
00007fb1689d4791  pop rdi
00007fb1689d4792  pop rdx
00007fb1689d4793  pop rcx
00007fb1689d4794  pop rax
00007fb1689d4795  add rsp, 0x08
00007fb1689d4799  jmp 0x00007FB1689D2ACA
00007fb1689d479e  sub rsp, 0x08
00007fb1689d47a2  push rax
00007fb1689d47a3  push rcx
00007fb1689d47a4  push rdx
00007fb1689d47a5  push rdi
00007fb1689d47a6  push rsi
00007fb1689d47a7  push r8
00007fb1689d47a9  push r9
00007fb1689d47ab  push r10
00007fb1689d47ad  push r11
00007fb1689d47af  sub rsp, 0xF0
00007fb1689d47b6  vmovaps [rsp], xmm0
00007fb1689d47bb  vmovaps [rsp+0x10], xmm1
00007fb1689d47c1  vmovaps [rsp+0x20], xmm2
00007fb1689d47c7  vmovaps [rsp+0x30], xmm3
00007fb1689d47cd  vmovaps [rsp+0x40], xmm4
00007fb1689d47d3  vmovaps [rsp+0x50], xmm5
00007fb1689d47d9  vmovaps [rsp+0x60], xmm6
00007fb1689d47df  vmovaps [rsp+0x70], xmm7
00007fb1689d47e5  vmovaps [rsp+0x80], xmm8
00007fb1689d47ee  vmovaps [rsp+0x90], xmm9
00007fb1689d47f7  vmovaps [rsp+0xA0], xmm10
00007fb1689d4800  vmovaps [rsp+0xB0], xmm11
00007fb1689d4809  vmovaps [rsp+0xC0], xmm12
00007fb1689d4812  vmovaps [rsp+0xD0], xmm13
00007fb1689d481b  vmovaps [rsp+0xE0], xmm15
00007fb1689d4824  sub rsp, 0x30
00007fb1689d4828  movaps [rsp], xmm14
00007fb1689d482d  movaps [rsp+0x10], xmm2
00007fb1689d4832  movaps [rsp+0x20], xmm15
00007fb1689d4838  lea rdi, [rsp]
00007fb1689d483c  mov esi, 0x00
00007fb1689d4841  mov rax, 0x57CCFD419530
00007fb1689d484b  call rax
00007fb1689d484d  movaps xmm14, [rsp]
00007fb1689d4852  add rsp, 0x30
00007fb1689d4856  vmovaps xmm0, [rsp]
00007fb1689d485b  vmovaps xmm1, [rsp+0x10]
00007fb1689d4861  vmovaps xmm2, [rsp+0x20]
00007fb1689d4867  vmovaps xmm3, [rsp+0x30]
00007fb1689d486d  vmovaps xmm4, [rsp+0x40]
00007fb1689d4873  vmovaps xmm5, [rsp+0x50]
00007fb1689d4879  vmovaps xmm6, [rsp+0x60]
00007fb1689d487f  vmovaps xmm7, [rsp+0x70]
00007fb1689d4885  vmovaps xmm8, [rsp+0x80]
00007fb1689d488e  vmovaps xmm9, [rsp+0x90]
00007fb1689d4897  vmovaps xmm10, [rsp+0xA0]
00007fb1689d48a0  vmovaps xmm11, [rsp+0xB0]
00007fb1689d48a9  vmovaps xmm12, [rsp+0xC0]
00007fb1689d48b2  vmovaps xmm13, [rsp+0xD0]
00007fb1689d48bb  vmovaps xmm15, [rsp+0xE0]
00007fb1689d48c4  add rsp, 0xF0
00007fb1689d48cb  pop r11
00007fb1689d48cd  pop r10
00007fb1689d48cf  pop r9
00007fb1689d48d1  pop r8
00007fb1689d48d3  pop rsi
00007fb1689d48d4  pop rdi
00007fb1689d48d5  pop rdx
00007fb1689d48d6  pop rcx
00007fb1689d48d7  pop rax
00007fb1689d48d8  add rsp, 0x08
00007fb1689d48dc  jmp 0x00007FB1689D2B05
00007fb1689d48e1  sub rsp, 0x08
00007fb1689d48e5  push rax
00007fb1689d48e6  push rcx
00007fb1689d48e7  push rdx
00007fb1689d48e8  push rdi
00007fb1689d48e9  push rsi
00007fb1689d48ea  push r8
00007fb1689d48ec  push r9
00007fb1689d48ee  push r10
00007fb1689d48f0  push r11
00007fb1689d48f2  sub rsp, 0xF0
00007fb1689d48f9  vmovaps [rsp], xmm0
00007fb1689d48fe  vmovaps [rsp+0x10], xmm1
00007fb1689d4904  vmovaps [rsp+0x20], xmm2
00007fb1689d490a  vmovaps [rsp+0x30], xmm3
00007fb1689d4910  vmovaps [rsp+0x40], xmm4
00007fb1689d4916  vmovaps [rsp+0x50], xmm5
00007fb1689d491c  vmovaps [rsp+0x60], xmm6
00007fb1689d4922  vmovaps [rsp+0x70], xmm7
00007fb1689d4928  vmovaps [rsp+0x80], xmm8
00007fb1689d4931  vmovaps [rsp+0x90], xmm9
00007fb1689d493a  vmovaps [rsp+0xA0], xmm10
00007fb1689d4943  vmovaps [rsp+0xB0], xmm11
00007fb1689d494c  vmovaps [rsp+0xC0], xmm12
00007fb1689d4955  vmovaps [rsp+0xD0], xmm13
00007fb1689d495e  vmovaps [rsp+0xE0], xmm14
00007fb1689d4967  sub rsp, 0x30
00007fb1689d496b  movaps [rsp], xmm15
00007fb1689d4970  movaps [rsp+0x10], xmm2
00007fb1689d4975  movaps [rsp+0x20], xmm1
00007fb1689d497a  lea rdi, [rsp]
00007fb1689d497e  mov esi, 0x00
00007fb1689d4983  mov rax, 0x57CCFD419530
00007fb1689d498d  call rax
00007fb1689d498f  movaps xmm15, [rsp]
00007fb1689d4994  add rsp, 0x30
00007fb1689d4998  vmovaps xmm0, [rsp]
00007fb1689d499d  vmovaps xmm1, [rsp+0x10]
00007fb1689d49a3  vmovaps xmm2, [rsp+0x20]
00007fb1689d49a9  vmovaps xmm3, [rsp+0x30]
00007fb1689d49af  vmovaps xmm4, [rsp+0x40]
00007fb1689d49b5  vmovaps xmm5, [rsp+0x50]
00007fb1689d49bb  vmovaps xmm6, [rsp+0x60]
00007fb1689d49c1  vmovaps xmm7, [rsp+0x70]
00007fb1689d49c7  vmovaps xmm8, [rsp+0x80]
00007fb1689d49d0  vmovaps xmm9, [rsp+0x90]
00007fb1689d49d9  vmovaps xmm10, [rsp+0xA0]
00007fb1689d49e2  vmovaps xmm11, [rsp+0xB0]
00007fb1689d49eb  vmovaps xmm12, [rsp+0xC0]
00007fb1689d49f4  vmovaps xmm13, [rsp+0xD0]
00007fb1689d49fd  vmovaps xmm14, [rsp+0xE0]
00007fb1689d4a06  add rsp, 0xF0
00007fb1689d4a0d  pop r11
00007fb1689d4a0f  pop r10
00007fb1689d4a11  pop r9
00007fb1689d4a13  pop r8
00007fb1689d4a15  pop rsi
00007fb1689d4a16  pop rdi
00007fb1689d4a17  pop rdx
00007fb1689d4a18  pop rcx
00007fb1689d4a19  pop rax
00007fb1689d4a1a  add rsp, 0x08
00007fb1689d4a1e  jmp 0x00007FB1689D2B41
00007fb1689d4a23  call 0x00007FB1687FF430
00007fb1689d4a28  jmp 0x00007FB1689D2B4E
00007fb1689d4a2d  sub rsp, 0x08
00007fb1689d4a31  push rax
00007fb1689d4a32  push rcx
00007fb1689d4a33  push rdx
00007fb1689d4a34  push rdi
00007fb1689d4a35  push rsi
00007fb1689d4a36  push r8
00007fb1689d4a38  push r9
00007fb1689d4a3a  push r10
00007fb1689d4a3c  push r11
00007fb1689d4a3e  sub rsp, 0xF0
00007fb1689d4a45  vmovaps [rsp], xmm0
00007fb1689d4a4a  vmovaps [rsp+0x10], xmm1
00007fb1689d4a50  vmovaps [rsp+0x20], xmm3
00007fb1689d4a56  vmovaps [rsp+0x30], xmm4
00007fb1689d4a5c  vmovaps [rsp+0x40], xmm5
00007fb1689d4a62  vmovaps [rsp+0x50], xmm6
00007fb1689d4a68  vmovaps [rsp+0x60], xmm7
00007fb1689d4a6e  vmovaps [rsp+0x70], xmm8
00007fb1689d4a74  vmovaps [rsp+0x80], xmm9
00007fb1689d4a7d  vmovaps [rsp+0x90], xmm10
00007fb1689d4a86  vmovaps [rsp+0xA0], xmm11
00007fb1689d4a8f  vmovaps [rsp+0xB0], xmm12
00007fb1689d4a98  vmovaps [rsp+0xC0], xmm13
00007fb1689d4aa1  vmovaps [rsp+0xD0], xmm14
00007fb1689d4aaa  vmovaps [rsp+0xE0], xmm15
00007fb1689d4ab3  sub rsp, 0x30
00007fb1689d4ab7  movaps [rsp], xmm2
00007fb1689d4abb  movaps [rsp+0x10], xmm1
00007fb1689d4ac0  movaps [rsp+0x20], xmm14
00007fb1689d4ac6  lea rdi, [rsp]
00007fb1689d4aca  mov esi, 0x00
00007fb1689d4acf  mov rax, 0x57CCFD419530
00007fb1689d4ad9  call rax
00007fb1689d4adb  movaps xmm2, [rsp]
00007fb1689d4adf  add rsp, 0x30
00007fb1689d4ae3  vmovaps xmm0, [rsp]
00007fb1689d4ae8  vmovaps xmm1, [rsp+0x10]
00007fb1689d4aee  vmovaps xmm3, [rsp+0x20]
00007fb1689d4af4  vmovaps xmm4, [rsp+0x30]
00007fb1689d4afa  vmovaps xmm5, [rsp+0x40]
00007fb1689d4b00  vmovaps xmm6, [rsp+0x50]
00007fb1689d4b06  vmovaps xmm7, [rsp+0x60]
00007fb1689d4b0c  vmovaps xmm8, [rsp+0x70]
00007fb1689d4b12  vmovaps xmm9, [rsp+0x80]
00007fb1689d4b1b  vmovaps xmm10, [rsp+0x90]
00007fb1689d4b24  vmovaps xmm11, [rsp+0xA0]
00007fb1689d4b2d  vmovaps xmm12, [rsp+0xB0]
00007fb1689d4b36  vmovaps xmm13, [rsp+0xC0]
00007fb1689d4b3f  vmovaps xmm14, [rsp+0xD0]
00007fb1689d4b48  vmovaps xmm15, [rsp+0xE0]
00007fb1689d4b51  add rsp, 0xF0
00007fb1689d4b58  pop r11
00007fb1689d4b5a  pop r10
00007fb1689d4b5c  pop r9
00007fb1689d4b5e  pop r8
00007fb1689d4b60  pop rsi
00007fb1689d4b61  pop rdi
00007fb1689d4b62  pop rdx
00007fb1689d4b63  pop rcx
00007fb1689d4b64  pop rax
00007fb1689d4b65  add rsp, 0x08
00007fb1689d4b69  jmp 0x00007FB1689D2B8B
00007fb1689d4b6e  sub rsp, 0x08
00007fb1689d4b72  push rax
00007fb1689d4b73  push rcx
00007fb1689d4b74  push rdx
00007fb1689d4b75  push rdi
00007fb1689d4b76  push rsi
00007fb1689d4b77  push r8
00007fb1689d4b79  push r9
00007fb1689d4b7b  push r10
00007fb1689d4b7d  push r11
00007fb1689d4b7f  sub rsp, 0xF0
00007fb1689d4b86  vmovaps [rsp], xmm0
00007fb1689d4b8b  vmovaps [rsp+0x10], xmm1
00007fb1689d4b91  vmovaps [rsp+0x20], xmm2
00007fb1689d4b97  vmovaps [rsp+0x30], xmm3
00007fb1689d4b9d  vmovaps [rsp+0x40], xmm4
00007fb1689d4ba3  vmovaps [rsp+0x50], xmm5
00007fb1689d4ba9  vmovaps [rsp+0x60], xmm6
00007fb1689d4baf  vmovaps [rsp+0x70], xmm7
00007fb1689d4bb5  vmovaps [rsp+0x80], xmm8
00007fb1689d4bbe  vmovaps [rsp+0x90], xmm9
00007fb1689d4bc7  vmovaps [rsp+0xA0], xmm10
00007fb1689d4bd0  vmovaps [rsp+0xB0], xmm11
00007fb1689d4bd9  vmovaps [rsp+0xC0], xmm12
00007fb1689d4be2  vmovaps [rsp+0xD0], xmm13
00007fb1689d4beb  vmovaps [rsp+0xE0], xmm14
00007fb1689d4bf4  sub rsp, 0x30
00007fb1689d4bf8  movaps [rsp], xmm15
00007fb1689d4bfd  movaps [rsp+0x10], xmm14
00007fb1689d4c03  movaps [rsp+0x20], xmm1
00007fb1689d4c08  lea rdi, [rsp]
00007fb1689d4c0c  mov esi, 0x00
00007fb1689d4c11  mov rax, 0x57CCFD419530
00007fb1689d4c1b  call rax
00007fb1689d4c1d  movaps xmm15, [rsp]
00007fb1689d4c22  add rsp, 0x30
00007fb1689d4c26  vmovaps xmm0, [rsp]
00007fb1689d4c2b  vmovaps xmm1, [rsp+0x10]
00007fb1689d4c31  vmovaps xmm2, [rsp+0x20]
00007fb1689d4c37  vmovaps xmm3, [rsp+0x30]
00007fb1689d4c3d  vmovaps xmm4, [rsp+0x40]
00007fb1689d4c43  vmovaps xmm5, [rsp+0x50]
00007fb1689d4c49  vmovaps xmm6, [rsp+0x60]
00007fb1689d4c4f  vmovaps xmm7, [rsp+0x70]
00007fb1689d4c55  vmovaps xmm8, [rsp+0x80]
00007fb1689d4c5e  vmovaps xmm9, [rsp+0x90]
00007fb1689d4c67  vmovaps xmm10, [rsp+0xA0]
00007fb1689d4c70  vmovaps xmm11, [rsp+0xB0]
00007fb1689d4c79  vmovaps xmm12, [rsp+0xC0]
00007fb1689d4c82  vmovaps xmm13, [rsp+0xD0]
00007fb1689d4c8b  vmovaps xmm14, [rsp+0xE0]
00007fb1689d4c94  add rsp, 0xF0
00007fb1689d4c9b  pop r11
00007fb1689d4c9d  pop r10
00007fb1689d4c9f  pop r9
00007fb1689d4ca1  pop r8
00007fb1689d4ca3  pop rsi
00007fb1689d4ca4  pop rdi
00007fb1689d4ca5  pop rdx
00007fb1689d4ca6  pop rcx
00007fb1689d4ca7  pop rax
00007fb1689d4ca8  add rsp, 0x08
00007fb1689d4cac  jmp 0x00007FB1689D2C05
00007fb1689d4cb1  call 0x00007FB1687FF430
00007fb1689d4cb6  jmp 0x00007FB1689D2C12
00007fb1689d4cbb  sub rsp, 0x08
00007fb1689d4cbf  push rax
00007fb1689d4cc0  push rcx
00007fb1689d4cc1  push rdx
00007fb1689d4cc2  push rdi
00007fb1689d4cc3  push rsi
00007fb1689d4cc4  push r8
00007fb1689d4cc6  push r9
00007fb1689d4cc8  push r10
00007fb1689d4cca  push r11
00007fb1689d4ccc  sub rsp, 0xF0
00007fb1689d4cd3  vmovaps [rsp], xmm0
00007fb1689d4cd8  vmovaps [rsp+0x10], xmm1
00007fb1689d4cde  vmovaps [rsp+0x20], xmm2
00007fb1689d4ce4  vmovaps [rsp+0x30], xmm3
00007fb1689d4cea  vmovaps [rsp+0x40], xmm4
00007fb1689d4cf0  vmovaps [rsp+0x50], xmm5
00007fb1689d4cf6  vmovaps [rsp+0x60], xmm6
00007fb1689d4cfc  vmovaps [rsp+0x70], xmm7
00007fb1689d4d02  vmovaps [rsp+0x80], xmm8
00007fb1689d4d0b  vmovaps [rsp+0x90], xmm9
00007fb1689d4d14  vmovaps [rsp+0xA0], xmm10
00007fb1689d4d1d  vmovaps [rsp+0xB0], xmm11
00007fb1689d4d26  vmovaps [rsp+0xC0], xmm12
00007fb1689d4d2f  vmovaps [rsp+0xD0], xmm14
00007fb1689d4d38  vmovaps [rsp+0xE0], xmm15
00007fb1689d4d41  sub rsp, 0x30
00007fb1689d4d45  movaps [rsp], xmm13
00007fb1689d4d4a  movaps [rsp+0x10], xmm1
00007fb1689d4d4f  movaps [rsp+0x20], xmm15
00007fb1689d4d55  lea rdi, [rsp]
00007fb1689d4d59  mov esi, 0x00
00007fb1689d4d5e  mov rax, 0x57CCFD419530
00007fb1689d4d68  call rax
00007fb1689d4d6a  movaps xmm13, [rsp]
00007fb1689d4d6f  add rsp, 0x30
00007fb1689d4d73  vmovaps xmm0, [rsp]
00007fb1689d4d78  vmovaps xmm1, [rsp+0x10]
00007fb1689d4d7e  vmovaps xmm2, [rsp+0x20]
00007fb1689d4d84  vmovaps xmm3, [rsp+0x30]
00007fb1689d4d8a  vmovaps xmm4, [rsp+0x40]
00007fb1689d4d90  vmovaps xmm5, [rsp+0x50]
00007fb1689d4d96  vmovaps xmm6, [rsp+0x60]
00007fb1689d4d9c  vmovaps xmm7, [rsp+0x70]
00007fb1689d4da2  vmovaps xmm8, [rsp+0x80]
00007fb1689d4dab  vmovaps xmm9, [rsp+0x90]
00007fb1689d4db4  vmovaps xmm10, [rsp+0xA0]
00007fb1689d4dbd  vmovaps xmm11, [rsp+0xB0]
00007fb1689d4dc6  vmovaps xmm12, [rsp+0xC0]
00007fb1689d4dcf  vmovaps xmm14, [rsp+0xD0]
00007fb1689d4dd8  vmovaps xmm15, [rsp+0xE0]
00007fb1689d4de1  add rsp, 0xF0
00007fb1689d4de8  pop r11
00007fb1689d4dea  pop r10
00007fb1689d4dec  pop r9
00007fb1689d4dee  pop r8
00007fb1689d4df0  pop rsi
00007fb1689d4df1  pop rdi
00007fb1689d4df2  pop rdx
00007fb1689d4df3  pop rcx
00007fb1689d4df4  pop rax
00007fb1689d4df5  add rsp, 0x08
00007fb1689d4df9  jmp 0x00007FB1689D2CD6
00007fb1689d4dfe  sub rsp, 0x08
00007fb1689d4e02  push rax
00007fb1689d4e03  push rcx
00007fb1689d4e04  push rdx
00007fb1689d4e05  push rdi
00007fb1689d4e06  push rsi
00007fb1689d4e07  push r8
00007fb1689d4e09  push r9
00007fb1689d4e0b  push r10
00007fb1689d4e0d  push r11
00007fb1689d4e0f  sub rsp, 0xF0
00007fb1689d4e16  vmovaps [rsp], xmm0
00007fb1689d4e1b  vmovaps [rsp+0x10], xmm1
00007fb1689d4e21  vmovaps [rsp+0x20], xmm2
00007fb1689d4e27  vmovaps [rsp+0x30], xmm3
00007fb1689d4e2d  vmovaps [rsp+0x40], xmm4
00007fb1689d4e33  vmovaps [rsp+0x50], xmm5
00007fb1689d4e39  vmovaps [rsp+0x60], xmm6
00007fb1689d4e3f  vmovaps [rsp+0x70], xmm7
00007fb1689d4e45  vmovaps [rsp+0x80], xmm8
00007fb1689d4e4e  vmovaps [rsp+0x90], xmm9
00007fb1689d4e57  vmovaps [rsp+0xA0], xmm10
00007fb1689d4e60  vmovaps [rsp+0xB0], xmm11
00007fb1689d4e69  vmovaps [rsp+0xC0], xmm12
00007fb1689d4e72  vmovaps [rsp+0xD0], xmm13
00007fb1689d4e7b  vmovaps [rsp+0xE0], xmm14
00007fb1689d4e84  sub rsp, 0x30
00007fb1689d4e88  movaps [rsp], xmm15
00007fb1689d4e8d  movaps [rsp+0x10], xmm14
00007fb1689d4e93  movaps [rsp+0x20], xmm1
00007fb1689d4e98  lea rdi, [rsp]
00007fb1689d4e9c  mov esi, 0x00
00007fb1689d4ea1  mov rax, 0x57CCFD419530
00007fb1689d4eab  call rax
00007fb1689d4ead  movaps xmm15, [rsp]
00007fb1689d4eb2  add rsp, 0x30
00007fb1689d4eb6  vmovaps xmm0, [rsp]
00007fb1689d4ebb  vmovaps xmm1, [rsp+0x10]
00007fb1689d4ec1  vmovaps xmm2, [rsp+0x20]
00007fb1689d4ec7  vmovaps xmm3, [rsp+0x30]
00007fb1689d4ecd  vmovaps xmm4, [rsp+0x40]
00007fb1689d4ed3  vmovaps xmm5, [rsp+0x50]
00007fb1689d4ed9  vmovaps xmm6, [rsp+0x60]
00007fb1689d4edf  vmovaps xmm7, [rsp+0x70]
00007fb1689d4ee5  vmovaps xmm8, [rsp+0x80]
00007fb1689d4eee  vmovaps xmm9, [rsp+0x90]
00007fb1689d4ef7  vmovaps xmm10, [rsp+0xA0]
00007fb1689d4f00  vmovaps xmm11, [rsp+0xB0]
00007fb1689d4f09  vmovaps xmm12, [rsp+0xC0]
00007fb1689d4f12  vmovaps xmm13, [rsp+0xD0]
00007fb1689d4f1b  vmovaps xmm14, [rsp+0xE0]
00007fb1689d4f24  add rsp, 0xF0
00007fb1689d4f2b  pop r11
00007fb1689d4f2d  pop r10
00007fb1689d4f2f  pop r9
00007fb1689d4f31  pop r8
00007fb1689d4f33  pop rsi
00007fb1689d4f34  pop rdi
00007fb1689d4f35  pop rdx
00007fb1689d4f36  pop rcx
00007fb1689d4f37  pop rax
00007fb1689d4f38  add rsp, 0x08
00007fb1689d4f3c  jmp 0x00007FB1689D2D12
00007fb1689d4f41  call 0x00007FB1687FF430
00007fb1689d4f46  jmp 0x00007FB1689D2D1F
00007fb1689d4f4b  sub rsp, 0x08
00007fb1689d4f4f  push rax
00007fb1689d4f50  push rcx
00007fb1689d4f51  push rdx
00007fb1689d4f52  push rdi
00007fb1689d4f53  push rsi
00007fb1689d4f54  push r8
00007fb1689d4f56  push r9
00007fb1689d4f58  push r10
00007fb1689d4f5a  push r11
00007fb1689d4f5c  sub rsp, 0xF0
00007fb1689d4f63  vmovaps [rsp], xmm0
00007fb1689d4f68  vmovaps [rsp+0x10], xmm1
00007fb1689d4f6e  vmovaps [rsp+0x20], xmm2
00007fb1689d4f74  vmovaps [rsp+0x30], xmm3
00007fb1689d4f7a  vmovaps [rsp+0x40], xmm4
00007fb1689d4f80  vmovaps [rsp+0x50], xmm5
00007fb1689d4f86  vmovaps [rsp+0x60], xmm6
00007fb1689d4f8c  vmovaps [rsp+0x70], xmm7
00007fb1689d4f92  vmovaps [rsp+0x80], xmm8
00007fb1689d4f9b  vmovaps [rsp+0x90], xmm9
00007fb1689d4fa4  vmovaps [rsp+0xA0], xmm10
00007fb1689d4fad  vmovaps [rsp+0xB0], xmm11
00007fb1689d4fb6  vmovaps [rsp+0xC0], xmm12
00007fb1689d4fbf  vmovaps [rsp+0xD0], xmm13
00007fb1689d4fc8  vmovaps [rsp+0xE0], xmm15
00007fb1689d4fd1  sub rsp, 0x30
00007fb1689d4fd5  movaps [rsp], xmm14
00007fb1689d4fda  movaps [rsp+0x10], xmm13
00007fb1689d4fe0  movaps [rsp+0x20], xmm2
00007fb1689d4fe5  lea rdi, [rsp]
00007fb1689d4fe9  mov esi, 0x00
00007fb1689d4fee  mov rax, 0x57CCFD419530
00007fb1689d4ff8  call rax
00007fb1689d4ffa  movaps xmm14, [rsp]
00007fb1689d4fff  add rsp, 0x30
00007fb1689d5003  vmovaps xmm0, [rsp]
00007fb1689d5008  vmovaps xmm1, [rsp+0x10]
00007fb1689d500e  vmovaps xmm2, [rsp+0x20]
00007fb1689d5014  vmovaps xmm3, [rsp+0x30]
00007fb1689d501a  vmovaps xmm4, [rsp+0x40]
00007fb1689d5020  vmovaps xmm5, [rsp+0x50]
00007fb1689d5026  vmovaps xmm6, [rsp+0x60]
00007fb1689d502c  vmovaps xmm7, [rsp+0x70]
00007fb1689d5032  vmovaps xmm8, [rsp+0x80]
00007fb1689d503b  vmovaps xmm9, [rsp+0x90]
00007fb1689d5044  vmovaps xmm10, [rsp+0xA0]
00007fb1689d504d  vmovaps xmm11, [rsp+0xB0]
00007fb1689d5056  vmovaps xmm12, [rsp+0xC0]
00007fb1689d505f  vmovaps xmm13, [rsp+0xD0]
00007fb1689d5068  vmovaps xmm15, [rsp+0xE0]
00007fb1689d5071  add rsp, 0xF0
00007fb1689d5078  pop r11
00007fb1689d507a  pop r10
00007fb1689d507c  pop r9
00007fb1689d507e  pop r8
00007fb1689d5080  pop rsi
00007fb1689d5081  pop rdi
00007fb1689d5082  pop rdx
00007fb1689d5083  pop rcx
00007fb1689d5084  pop rax
00007fb1689d5085  add rsp, 0x08
00007fb1689d5089  jmp 0x00007FB1689D2D4B
00007fb1689d508e  sub rsp, 0x08
00007fb1689d5092  push rax
00007fb1689d5093  push rcx
00007fb1689d5094  push rdx
00007fb1689d5095  push rdi
00007fb1689d5096  push rsi
00007fb1689d5097  push r8
00007fb1689d5099  push r9
00007fb1689d509b  push r10
00007fb1689d509d  push r11
00007fb1689d509f  sub rsp, 0xF0
00007fb1689d50a6  vmovaps [rsp], xmm0
00007fb1689d50ab  vmovaps [rsp+0x10], xmm2
00007fb1689d50b1  vmovaps [rsp+0x20], xmm3
00007fb1689d50b7  vmovaps [rsp+0x30], xmm4
00007fb1689d50bd  vmovaps [rsp+0x40], xmm5
00007fb1689d50c3  vmovaps [rsp+0x50], xmm6
00007fb1689d50c9  vmovaps [rsp+0x60], xmm7
00007fb1689d50cf  vmovaps [rsp+0x70], xmm8
00007fb1689d50d5  vmovaps [rsp+0x80], xmm9
00007fb1689d50de  vmovaps [rsp+0x90], xmm10
00007fb1689d50e7  vmovaps [rsp+0xA0], xmm11
00007fb1689d50f0  vmovaps [rsp+0xB0], xmm12
00007fb1689d50f9  vmovaps [rsp+0xC0], xmm13
00007fb1689d5102  vmovaps [rsp+0xD0], xmm14
00007fb1689d510b  vmovaps [rsp+0xE0], xmm15
00007fb1689d5114  sub rsp, 0x30
00007fb1689d5118  movaps [rsp], xmm1
00007fb1689d511c  movaps [rsp+0x10], xmm13
00007fb1689d5122  movaps [rsp+0x20], xmm2
00007fb1689d5127  lea rdi, [rsp]
00007fb1689d512b  mov esi, 0x00
00007fb1689d5130  mov rax, 0x57CCFD419530
00007fb1689d513a  call rax
00007fb1689d513c  movaps xmm1, [rsp]
00007fb1689d5140  add rsp, 0x30
00007fb1689d5144  vmovaps xmm0, [rsp]
00007fb1689d5149  vmovaps xmm2, [rsp+0x10]
00007fb1689d514f  vmovaps xmm3, [rsp+0x20]
00007fb1689d5155  vmovaps xmm4, [rsp+0x30]
00007fb1689d515b  vmovaps xmm5, [rsp+0x40]
00007fb1689d5161  vmovaps xmm6, [rsp+0x50]
00007fb1689d5167  vmovaps xmm7, [rsp+0x60]
00007fb1689d516d  vmovaps xmm8, [rsp+0x70]
00007fb1689d5173  vmovaps xmm9, [rsp+0x80]
00007fb1689d517c  vmovaps xmm10, [rsp+0x90]
00007fb1689d5185  vmovaps xmm11, [rsp+0xA0]
00007fb1689d518e  vmovaps xmm12, [rsp+0xB0]
00007fb1689d5197  vmovaps xmm13, [rsp+0xC0]
00007fb1689d51a0  vmovaps xmm14, [rsp+0xD0]
00007fb1689d51a9  vmovaps xmm15, [rsp+0xE0]
00007fb1689d51b2  add rsp, 0xF0
00007fb1689d51b9  pop r11
00007fb1689d51bb  pop r10
00007fb1689d51bd  pop r9
00007fb1689d51bf  pop r8
00007fb1689d51c1  pop rsi
00007fb1689d51c2  pop rdi
00007fb1689d51c3  pop rdx
00007fb1689d51c4  pop rcx
00007fb1689d51c5  pop rax
00007fb1689d51c6  add rsp, 0x08
00007fb1689d51ca  jmp 0x00007FB1689D2D79
00007fb1689d51cf  sub rsp, 0x08
00007fb1689d51d3  push rax
00007fb1689d51d4  push rcx
00007fb1689d51d5  push rdx
00007fb1689d51d6  push rdi
00007fb1689d51d7  push rsi
00007fb1689d51d8  push r8
00007fb1689d51da  push r9
00007fb1689d51dc  push r10
00007fb1689d51de  push r11
00007fb1689d51e0  sub rsp, 0xF0
00007fb1689d51e7  vmovaps [rsp], xmm0
00007fb1689d51ec  vmovaps [rsp+0x10], xmm1
00007fb1689d51f2  vmovaps [rsp+0x20], xmm3
00007fb1689d51f8  vmovaps [rsp+0x30], xmm4
00007fb1689d51fe  vmovaps [rsp+0x40], xmm5
00007fb1689d5204  vmovaps [rsp+0x50], xmm6
00007fb1689d520a  vmovaps [rsp+0x60], xmm7
00007fb1689d5210  vmovaps [rsp+0x70], xmm8
00007fb1689d5216  vmovaps [rsp+0x80], xmm9
00007fb1689d521f  vmovaps [rsp+0x90], xmm10
00007fb1689d5228  vmovaps [rsp+0xA0], xmm11
00007fb1689d5231  vmovaps [rsp+0xB0], xmm12
00007fb1689d523a  vmovaps [rsp+0xC0], xmm13
00007fb1689d5243  vmovaps [rsp+0xD0], xmm14
00007fb1689d524c  vmovaps [rsp+0xE0], xmm15
00007fb1689d5255  sub rsp, 0x30
00007fb1689d5259  movaps [rsp], xmm2
00007fb1689d525d  movaps [rsp+0x10], xmm1
00007fb1689d5262  movaps [rsp+0x20], xmm13
00007fb1689d5268  lea rdi, [rsp]
00007fb1689d526c  mov esi, 0x00
00007fb1689d5271  mov rax, 0x57CCFD419530
00007fb1689d527b  call rax
00007fb1689d527d  movaps xmm2, [rsp]
00007fb1689d5281  add rsp, 0x30
00007fb1689d5285  vmovaps xmm0, [rsp]
00007fb1689d528a  vmovaps xmm1, [rsp+0x10]
00007fb1689d5290  vmovaps xmm3, [rsp+0x20]
00007fb1689d5296  vmovaps xmm4, [rsp+0x30]
00007fb1689d529c  vmovaps xmm5, [rsp+0x40]
00007fb1689d52a2  vmovaps xmm6, [rsp+0x50]
00007fb1689d52a8  vmovaps xmm7, [rsp+0x60]
00007fb1689d52ae  vmovaps xmm8, [rsp+0x70]
00007fb1689d52b4  vmovaps xmm9, [rsp+0x80]
00007fb1689d52bd  vmovaps xmm10, [rsp+0x90]
00007fb1689d52c6  vmovaps xmm11, [rsp+0xA0]
00007fb1689d52cf  vmovaps xmm12, [rsp+0xB0]
00007fb1689d52d8  vmovaps xmm13, [rsp+0xC0]
00007fb1689d52e1  vmovaps xmm14, [rsp+0xD0]
00007fb1689d52ea  vmovaps xmm15, [rsp+0xE0]
00007fb1689d52f3  add rsp, 0xF0
00007fb1689d52fa  pop r11
00007fb1689d52fc  pop r10
00007fb1689d52fe  pop r9
00007fb1689d5300  pop r8
00007fb1689d5302  pop rsi
00007fb1689d5303  pop rdi
00007fb1689d5304  pop rdx
00007fb1689d5305  pop rcx
00007fb1689d5306  pop rax
00007fb1689d5307  add rsp, 0x08
00007fb1689d530b  jmp 0x00007FB1689D2DD2
00007fb1689d5310  call 0x00007FB1687FF430
00007fb1689d5315  jmp 0x00007FB1689D2DDF
00007fb1689d531a  sub rsp, 0x08
00007fb1689d531e  push rax
00007fb1689d531f  push rcx
00007fb1689d5320  push rdx
00007fb1689d5321  push rdi
00007fb1689d5322  push rsi
00007fb1689d5323  push r8
00007fb1689d5325  push r9
00007fb1689d5327  push r10
00007fb1689d5329  push r11
00007fb1689d532b  sub rsp, 0xF0
00007fb1689d5332  vmovaps [rsp], xmm0
00007fb1689d5337  vmovaps [rsp+0x10], xmm1
00007fb1689d533d  vmovaps [rsp+0x20], xmm2
00007fb1689d5343  vmovaps [rsp+0x30], xmm3
00007fb1689d5349  vmovaps [rsp+0x40], xmm4
00007fb1689d534f  vmovaps [rsp+0x50], xmm5
00007fb1689d5355  vmovaps [rsp+0x60], xmm6
00007fb1689d535b  vmovaps [rsp+0x70], xmm7
00007fb1689d5361  vmovaps [rsp+0x80], xmm8
00007fb1689d536a  vmovaps [rsp+0x90], xmm9
00007fb1689d5373  vmovaps [rsp+0xA0], xmm10
00007fb1689d537c  vmovaps [rsp+0xB0], xmm11
00007fb1689d5385  vmovaps [rsp+0xC0], xmm12
00007fb1689d538e  vmovaps [rsp+0xD0], xmm13
00007fb1689d5397  vmovaps [rsp+0xE0], xmm14
00007fb1689d53a0  sub rsp, 0x30
00007fb1689d53a4  movaps [rsp], xmm15
00007fb1689d53a9  movaps [rsp+0x10], xmm13
00007fb1689d53af  movaps [rsp+0x20], xmm1
00007fb1689d53b4  lea rdi, [rsp]
00007fb1689d53b8  mov esi, 0x00
00007fb1689d53bd  mov rax, 0x57CCFD419530
00007fb1689d53c7  call rax
00007fb1689d53c9  movaps xmm15, [rsp]
00007fb1689d53ce  add rsp, 0x30
00007fb1689d53d2  vmovaps xmm0, [rsp]
00007fb1689d53d7  vmovaps xmm1, [rsp+0x10]
00007fb1689d53dd  vmovaps xmm2, [rsp+0x20]
00007fb1689d53e3  vmovaps xmm3, [rsp+0x30]
00007fb1689d53e9  vmovaps xmm4, [rsp+0x40]
00007fb1689d53ef  vmovaps xmm5, [rsp+0x50]
00007fb1689d53f5  vmovaps xmm6, [rsp+0x60]
00007fb1689d53fb  vmovaps xmm7, [rsp+0x70]
00007fb1689d5401  vmovaps xmm8, [rsp+0x80]
00007fb1689d540a  vmovaps xmm9, [rsp+0x90]
00007fb1689d5413  vmovaps xmm10, [rsp+0xA0]
00007fb1689d541c  vmovaps xmm11, [rsp+0xB0]
00007fb1689d5425  vmovaps xmm12, [rsp+0xC0]
00007fb1689d542e  vmovaps xmm13, [rsp+0xD0]
00007fb1689d5437  vmovaps xmm14, [rsp+0xE0]
00007fb1689d5440  add rsp, 0xF0
00007fb1689d5447  pop r11
00007fb1689d5449  pop r10
00007fb1689d544b  pop r9
00007fb1689d544d  pop r8
00007fb1689d544f  pop rsi
00007fb1689d5450  pop rdi
00007fb1689d5451  pop rdx
00007fb1689d5452  pop rcx
00007fb1689d5453  pop rax
00007fb1689d5454  add rsp, 0x08
00007fb1689d5458  jmp 0x00007FB1689D2E1E
00007fb1689d545d  sub rsp, 0x08
00007fb1689d5461  push rax
00007fb1689d5462  push rcx
00007fb1689d5463  push rdx
00007fb1689d5464  push rdi
00007fb1689d5465  push rsi
00007fb1689d5466  push r8
00007fb1689d5468  push r9
00007fb1689d546a  push r10
00007fb1689d546c  push r11
00007fb1689d546e  sub rsp, 0xF0
00007fb1689d5475  vmovaps [rsp], xmm0
00007fb1689d547a  vmovaps [rsp+0x10], xmm1
00007fb1689d5480  vmovaps [rsp+0x20], xmm2
00007fb1689d5486  vmovaps [rsp+0x30], xmm3
00007fb1689d548c  vmovaps [rsp+0x40], xmm4
00007fb1689d5492  vmovaps [rsp+0x50], xmm5
00007fb1689d5498  vmovaps [rsp+0x60], xmm6
00007fb1689d549e  vmovaps [rsp+0x70], xmm7
00007fb1689d54a4  vmovaps [rsp+0x80], xmm8
00007fb1689d54ad  vmovaps [rsp+0x90], xmm9
00007fb1689d54b6  vmovaps [rsp+0xA0], xmm10
00007fb1689d54bf  vmovaps [rsp+0xB0], xmm11
00007fb1689d54c8  vmovaps [rsp+0xC0], xmm12
00007fb1689d54d1  vmovaps [rsp+0xD0], xmm13
00007fb1689d54da  vmovaps [rsp+0xE0], xmm15
00007fb1689d54e3  sub rsp, 0x30
00007fb1689d54e7  movaps [rsp], xmm14
00007fb1689d54ec  movaps [rsp+0x10], xmm11
00007fb1689d54f2  movaps [rsp+0x20], xmm1
00007fb1689d54f7  lea rdi, [rsp]
00007fb1689d54fb  mov esi, 0x00
00007fb1689d5500  mov rax, 0x57CCFD419530
00007fb1689d550a  call rax
00007fb1689d550c  movaps xmm14, [rsp]
00007fb1689d5511  add rsp, 0x30
00007fb1689d5515  vmovaps xmm0, [rsp]
00007fb1689d551a  vmovaps xmm1, [rsp+0x10]
00007fb1689d5520  vmovaps xmm2, [rsp+0x20]
00007fb1689d5526  vmovaps xmm3, [rsp+0x30]
00007fb1689d552c  vmovaps xmm4, [rsp+0x40]
00007fb1689d5532  vmovaps xmm5, [rsp+0x50]
00007fb1689d5538  vmovaps xmm6, [rsp+0x60]
00007fb1689d553e  vmovaps xmm7, [rsp+0x70]
00007fb1689d5544  vmovaps xmm8, [rsp+0x80]
00007fb1689d554d  vmovaps xmm9, [rsp+0x90]
00007fb1689d5556  vmovaps xmm10, [rsp+0xA0]
00007fb1689d555f  vmovaps xmm11, [rsp+0xB0]
00007fb1689d5568  vmovaps xmm12, [rsp+0xC0]
00007fb1689d5571  vmovaps xmm13, [rsp+0xD0]
00007fb1689d557a  vmovaps xmm15, [rsp+0xE0]
00007fb1689d5583  add rsp, 0xF0
00007fb1689d558a  pop r11
00007fb1689d558c  pop r10
00007fb1689d558e  pop r9
00007fb1689d5590  pop r8
00007fb1689d5592  pop rsi
00007fb1689d5593  pop rdi
00007fb1689d5594  pop rdx
00007fb1689d5595  pop rcx
00007fb1689d5596  pop rax
00007fb1689d5597  add rsp, 0x08
00007fb1689d559b  jmp 0x00007FB1689D2E48
00007fb1689d55a0  sub rsp, 0x08
00007fb1689d55a4  push rax
00007fb1689d55a5  push rcx
00007fb1689d55a6  push rdx
00007fb1689d55a7  push rdi
00007fb1689d55a8  push rsi
00007fb1689d55a9  push r8
00007fb1689d55ab  push r9
00007fb1689d55ad  push r10
00007fb1689d55af  push r11
00007fb1689d55b1  sub rsp, 0xF0
00007fb1689d55b8  vmovaps [rsp], xmm0
00007fb1689d55bd  vmovaps [rsp+0x10], xmm1
00007fb1689d55c3  vmovaps [rsp+0x20], xmm2
00007fb1689d55c9  vmovaps [rsp+0x30], xmm3
00007fb1689d55cf  vmovaps [rsp+0x40], xmm4
00007fb1689d55d5  vmovaps [rsp+0x50], xmm5
00007fb1689d55db  vmovaps [rsp+0x60], xmm6
00007fb1689d55e1  vmovaps [rsp+0x70], xmm7
00007fb1689d55e7  vmovaps [rsp+0x80], xmm8
00007fb1689d55f0  vmovaps [rsp+0x90], xmm9
00007fb1689d55f9  vmovaps [rsp+0xA0], xmm10
00007fb1689d5602  vmovaps [rsp+0xB0], xmm11
00007fb1689d560b  vmovaps [rsp+0xC0], xmm12
00007fb1689d5614  vmovaps [rsp+0xD0], xmm14
00007fb1689d561d  vmovaps [rsp+0xE0], xmm15
00007fb1689d5626  sub rsp, 0x30
00007fb1689d562a  movaps [rsp], xmm13
00007fb1689d562f  movaps [rsp+0x10], xmm11
00007fb1689d5635  movaps [rsp+0x20], xmm1
00007fb1689d563a  lea rdi, [rsp]
00007fb1689d563e  mov esi, 0x00
00007fb1689d5643  mov rax, 0x57CCFD419530
00007fb1689d564d  call rax
00007fb1689d564f  movaps xmm13, [rsp]
00007fb1689d5654  add rsp, 0x30
00007fb1689d5658  vmovaps xmm0, [rsp]
00007fb1689d565d  vmovaps xmm1, [rsp+0x10]
00007fb1689d5663  vmovaps xmm2, [rsp+0x20]
00007fb1689d5669  vmovaps xmm3, [rsp+0x30]
00007fb1689d566f  vmovaps xmm4, [rsp+0x40]
00007fb1689d5675  vmovaps xmm5, [rsp+0x50]
00007fb1689d567b  vmovaps xmm6, [rsp+0x60]
00007fb1689d5681  vmovaps xmm7, [rsp+0x70]
00007fb1689d5687  vmovaps xmm8, [rsp+0x80]
00007fb1689d5690  vmovaps xmm9, [rsp+0x90]
00007fb1689d5699  vmovaps xmm10, [rsp+0xA0]
00007fb1689d56a2  vmovaps xmm11, [rsp+0xB0]
00007fb1689d56ab  vmovaps xmm12, [rsp+0xC0]
00007fb1689d56b4  vmovaps xmm14, [rsp+0xD0]
00007fb1689d56bd  vmovaps xmm15, [rsp+0xE0]
00007fb1689d56c6  add rsp, 0xF0
00007fb1689d56cd  pop r11
00007fb1689d56cf  pop r10
00007fb1689d56d1  pop r9
00007fb1689d56d3  pop r8
00007fb1689d56d5  pop rsi
00007fb1689d56d6  pop rdi
00007fb1689d56d7  pop rdx
00007fb1689d56d8  pop rcx
00007fb1689d56d9  pop rax
00007fb1689d56da  add rsp, 0x08
00007fb1689d56de  jmp 0x00007FB1689D2E9D
00007fb1689d56e3  call 0x00007FB1687FF430
00007fb1689d56e8  jmp 0x00007FB1689D2EAA
00007fb1689d56ed  sub rsp, 0x08
00007fb1689d56f1  push rax
00007fb1689d56f2  push rcx
00007fb1689d56f3  push rdx
00007fb1689d56f4  push rdi
00007fb1689d56f5  push rsi
00007fb1689d56f6  push r8
00007fb1689d56f8  push r9
00007fb1689d56fa  push r10
00007fb1689d56fc  push r11
00007fb1689d56fe  sub rsp, 0xF0
00007fb1689d5705  vmovaps [rsp], xmm0
00007fb1689d570a  vmovaps [rsp+0x10], xmm1
00007fb1689d5710  vmovaps [rsp+0x20], xmm2
00007fb1689d5716  vmovaps [rsp+0x30], xmm3
00007fb1689d571c  vmovaps [rsp+0x40], xmm4
00007fb1689d5722  vmovaps [rsp+0x50], xmm5
00007fb1689d5728  vmovaps [rsp+0x60], xmm6
00007fb1689d572e  vmovaps [rsp+0x70], xmm7
00007fb1689d5734  vmovaps [rsp+0x80], xmm8
00007fb1689d573d  vmovaps [rsp+0x90], xmm9
00007fb1689d5746  vmovaps [rsp+0xA0], xmm10
00007fb1689d574f  vmovaps [rsp+0xB0], xmm11
00007fb1689d5758  vmovaps [rsp+0xC0], xmm12
00007fb1689d5761  vmovaps [rsp+0xD0], xmm13
00007fb1689d576a  vmovaps [rsp+0xE0], xmm14
00007fb1689d5773  sub rsp, 0x30
00007fb1689d5777  movaps [rsp], xmm15
00007fb1689d577c  movaps [rsp+0x10], xmm11
00007fb1689d5782  movaps [rsp+0x20], xmm1
00007fb1689d5787  lea rdi, [rsp]
00007fb1689d578b  mov esi, 0x00
00007fb1689d5790  mov rax, 0x57CCFD419530
00007fb1689d579a  call rax
00007fb1689d579c  movaps xmm15, [rsp]
00007fb1689d57a1  add rsp, 0x30
00007fb1689d57a5  vmovaps xmm0, [rsp]
00007fb1689d57aa  vmovaps xmm1, [rsp+0x10]
00007fb1689d57b0  vmovaps xmm2, [rsp+0x20]
00007fb1689d57b6  vmovaps xmm3, [rsp+0x30]
00007fb1689d57bc  vmovaps xmm4, [rsp+0x40]
00007fb1689d57c2  vmovaps xmm5, [rsp+0x50]
00007fb1689d57c8  vmovaps xmm6, [rsp+0x60]
00007fb1689d57ce  vmovaps xmm7, [rsp+0x70]
00007fb1689d57d4  vmovaps xmm8, [rsp+0x80]
00007fb1689d57dd  vmovaps xmm9, [rsp+0x90]
00007fb1689d57e6  vmovaps xmm10, [rsp+0xA0]
00007fb1689d57ef  vmovaps xmm11, [rsp+0xB0]
00007fb1689d57f8  vmovaps xmm12, [rsp+0xC0]
00007fb1689d5801  vmovaps xmm13, [rsp+0xD0]
00007fb1689d580a  vmovaps xmm14, [rsp+0xE0]
00007fb1689d5813  add rsp, 0xF0
00007fb1689d581a  pop r11
00007fb1689d581c  pop r10
00007fb1689d581e  pop r9
00007fb1689d5820  pop r8
00007fb1689d5822  pop rsi
00007fb1689d5823  pop rdi
00007fb1689d5824  pop rdx
00007fb1689d5825  pop rcx
00007fb1689d5826  pop rax
00007fb1689d5827  add rsp, 0x08
00007fb1689d582b  jmp 0x00007FB1689D2EE3
00007fb1689d5830  sub rsp, 0x08
00007fb1689d5834  push rax
00007fb1689d5835  push rcx
00007fb1689d5836  push rdx
00007fb1689d5837  push rdi
00007fb1689d5838  push rsi
00007fb1689d5839  push r8
00007fb1689d583b  push r9
00007fb1689d583d  push r10
00007fb1689d583f  push r11
00007fb1689d5841  sub rsp, 0xF0
00007fb1689d5848  vmovaps [rsp], xmm0
00007fb1689d584d  vmovaps [rsp+0x10], xmm1
00007fb1689d5853  vmovaps [rsp+0x20], xmm2
00007fb1689d5859  vmovaps [rsp+0x30], xmm3
00007fb1689d585f  vmovaps [rsp+0x40], xmm4
00007fb1689d5865  vmovaps [rsp+0x50], xmm5
00007fb1689d586b  vmovaps [rsp+0x60], xmm6
00007fb1689d5871  vmovaps [rsp+0x70], xmm7
00007fb1689d5877  vmovaps [rsp+0x80], xmm8
00007fb1689d5880  vmovaps [rsp+0x90], xmm9
00007fb1689d5889  vmovaps [rsp+0xA0], xmm10
00007fb1689d5892  vmovaps [rsp+0xB0], xmm12
00007fb1689d589b  vmovaps [rsp+0xC0], xmm13
00007fb1689d58a4  vmovaps [rsp+0xD0], xmm14
00007fb1689d58ad  vmovaps [rsp+0xE0], xmm15
00007fb1689d58b6  sub rsp, 0x30
00007fb1689d58ba  movaps [rsp], xmm11
00007fb1689d58bf  movaps [rsp+0x10], xmm6
00007fb1689d58c4  movaps [rsp+0x20], xmm14
00007fb1689d58ca  lea rdi, [rsp]
00007fb1689d58ce  mov esi, 0x00
00007fb1689d58d3  mov rax, 0x57CCFD419530
00007fb1689d58dd  call rax
00007fb1689d58df  movaps xmm11, [rsp]
00007fb1689d58e4  add rsp, 0x30
00007fb1689d58e8  vmovaps xmm0, [rsp]
00007fb1689d58ed  vmovaps xmm1, [rsp+0x10]
00007fb1689d58f3  vmovaps xmm2, [rsp+0x20]
00007fb1689d58f9  vmovaps xmm3, [rsp+0x30]
00007fb1689d58ff  vmovaps xmm4, [rsp+0x40]
00007fb1689d5905  vmovaps xmm5, [rsp+0x50]
00007fb1689d590b  vmovaps xmm6, [rsp+0x60]
00007fb1689d5911  vmovaps xmm7, [rsp+0x70]
00007fb1689d5917  vmovaps xmm8, [rsp+0x80]
00007fb1689d5920  vmovaps xmm9, [rsp+0x90]
00007fb1689d5929  vmovaps xmm10, [rsp+0xA0]
00007fb1689d5932  vmovaps xmm12, [rsp+0xB0]
00007fb1689d593b  vmovaps xmm13, [rsp+0xC0]
00007fb1689d5944  vmovaps xmm14, [rsp+0xD0]
00007fb1689d594d  vmovaps xmm15, [rsp+0xE0]
00007fb1689d5956  add rsp, 0xF0
00007fb1689d595d  pop r11
00007fb1689d595f  pop r10
00007fb1689d5961  pop r9
00007fb1689d5963  pop r8
00007fb1689d5965  pop rsi
00007fb1689d5966  pop rdi
00007fb1689d5967  pop rdx
00007fb1689d5968  pop rcx
00007fb1689d5969  pop rax
00007fb1689d596a  add rsp, 0x08
00007fb1689d596e  jmp 0x00007FB1689D2F5B
00007fb1689d5973  call 0x00007FB1687FF430
00007fb1689d5978  jmp 0x00007FB1689D2F65
00007fb1689d597d  sub rsp, 0x08
00007fb1689d5981  push rax
00007fb1689d5982  push rcx
00007fb1689d5983  push rdx
00007fb1689d5984  push rdi
00007fb1689d5985  push rsi
00007fb1689d5986  push r8
00007fb1689d5988  push r9
00007fb1689d598a  push r10
00007fb1689d598c  push r11
00007fb1689d598e  sub rsp, 0xF0
00007fb1689d5995  vmovaps [rsp], xmm0
00007fb1689d599a  vmovaps [rsp+0x10], xmm1
00007fb1689d59a0  vmovaps [rsp+0x20], xmm2
00007fb1689d59a6  vmovaps [rsp+0x30], xmm3
00007fb1689d59ac  vmovaps [rsp+0x40], xmm4
00007fb1689d59b2  vmovaps [rsp+0x50], xmm5
00007fb1689d59b8  vmovaps [rsp+0x60], xmm6
00007fb1689d59be  vmovaps [rsp+0x70], xmm7
00007fb1689d59c4  vmovaps [rsp+0x80], xmm8
00007fb1689d59cd  vmovaps [rsp+0x90], xmm9
00007fb1689d59d6  vmovaps [rsp+0xA0], xmm10
00007fb1689d59df  vmovaps [rsp+0xB0], xmm11
00007fb1689d59e8  vmovaps [rsp+0xC0], xmm12
00007fb1689d59f1  vmovaps [rsp+0xD0], xmm13
00007fb1689d59fa  vmovaps [rsp+0xE0], xmm15
00007fb1689d5a03  sub rsp, 0x30
00007fb1689d5a07  movaps [rsp], xmm14
00007fb1689d5a0c  movaps [rsp+0x10], xmm6
00007fb1689d5a11  movaps [rsp+0x20], xmm2
00007fb1689d5a16  lea rdi, [rsp]
00007fb1689d5a1a  mov esi, 0x00
00007fb1689d5a1f  mov rax, 0x57CCFD419530
00007fb1689d5a29  call rax
00007fb1689d5a2b  movaps xmm14, [rsp]
00007fb1689d5a30  add rsp, 0x30
00007fb1689d5a34  vmovaps xmm0, [rsp]
00007fb1689d5a39  vmovaps xmm1, [rsp+0x10]
00007fb1689d5a3f  vmovaps xmm2, [rsp+0x20]
00007fb1689d5a45  vmovaps xmm3, [rsp+0x30]
00007fb1689d5a4b  vmovaps xmm4, [rsp+0x40]
00007fb1689d5a51  vmovaps xmm5, [rsp+0x50]
00007fb1689d5a57  vmovaps xmm6, [rsp+0x60]
00007fb1689d5a5d  vmovaps xmm7, [rsp+0x70]
00007fb1689d5a63  vmovaps xmm8, [rsp+0x80]
00007fb1689d5a6c  vmovaps xmm9, [rsp+0x90]
00007fb1689d5a75  vmovaps xmm10, [rsp+0xA0]
00007fb1689d5a7e  vmovaps xmm11, [rsp+0xB0]
00007fb1689d5a87  vmovaps xmm12, [rsp+0xC0]
00007fb1689d5a90  vmovaps xmm13, [rsp+0xD0]
00007fb1689d5a99  vmovaps xmm15, [rsp+0xE0]
00007fb1689d5aa2  add rsp, 0xF0
00007fb1689d5aa9  pop r11
00007fb1689d5aab  pop r10
00007fb1689d5aad  pop r9
00007fb1689d5aaf  pop r8
00007fb1689d5ab1  pop rsi
00007fb1689d5ab2  pop rdi
00007fb1689d5ab3  pop rdx
00007fb1689d5ab4  pop rcx
00007fb1689d5ab5  pop rax
00007fb1689d5ab6  add rsp, 0x08
00007fb1689d5aba  jmp 0x00007FB1689D2F99
00007fb1689d5abf  sub rsp, 0x08
00007fb1689d5ac3  push rax
00007fb1689d5ac4  push rcx
00007fb1689d5ac5  push rdx
00007fb1689d5ac6  push rdi
00007fb1689d5ac7  push rsi
00007fb1689d5ac8  push r8
00007fb1689d5aca  push r9
00007fb1689d5acc  push r10
00007fb1689d5ace  push r11
00007fb1689d5ad0  sub rsp, 0xF0
00007fb1689d5ad7  vmovaps [rsp], xmm0
00007fb1689d5adc  vmovaps [rsp+0x10], xmm1
00007fb1689d5ae2  vmovaps [rsp+0x20], xmm2
00007fb1689d5ae8  vmovaps [rsp+0x30], xmm3
00007fb1689d5aee  vmovaps [rsp+0x40], xmm4
00007fb1689d5af4  vmovaps [rsp+0x50], xmm5
00007fb1689d5afa  vmovaps [rsp+0x60], xmm7
00007fb1689d5b00  vmovaps [rsp+0x70], xmm8
00007fb1689d5b06  vmovaps [rsp+0x80], xmm9
00007fb1689d5b0f  vmovaps [rsp+0x90], xmm10
00007fb1689d5b18  vmovaps [rsp+0xA0], xmm11
00007fb1689d5b21  vmovaps [rsp+0xB0], xmm12
00007fb1689d5b2a  vmovaps [rsp+0xC0], xmm13
00007fb1689d5b33  vmovaps [rsp+0xD0], xmm14
00007fb1689d5b3c  vmovaps [rsp+0xE0], xmm15
00007fb1689d5b45  sub rsp, 0x30
00007fb1689d5b49  movaps [rsp], xmm6
00007fb1689d5b4d  movaps [rsp+0x10], xmm5
00007fb1689d5b52  movaps [rsp+0x20], xmm1
00007fb1689d5b57  lea rdi, [rsp]
00007fb1689d5b5b  mov esi, 0x00
00007fb1689d5b60  mov rax, 0x57CCFD419530
00007fb1689d5b6a  call rax
00007fb1689d5b6c  movaps xmm6, [rsp]
00007fb1689d5b70  add rsp, 0x30
00007fb1689d5b74  vmovaps xmm0, [rsp]
00007fb1689d5b79  vmovaps xmm1, [rsp+0x10]
00007fb1689d5b7f  vmovaps xmm2, [rsp+0x20]
00007fb1689d5b85  vmovaps xmm3, [rsp+0x30]
00007fb1689d5b8b  vmovaps xmm4, [rsp+0x40]
00007fb1689d5b91  vmovaps xmm5, [rsp+0x50]
00007fb1689d5b97  vmovaps xmm7, [rsp+0x60]
00007fb1689d5b9d  vmovaps xmm8, [rsp+0x70]
00007fb1689d5ba3  vmovaps xmm9, [rsp+0x80]
00007fb1689d5bac  vmovaps xmm10, [rsp+0x90]
00007fb1689d5bb5  vmovaps xmm11, [rsp+0xA0]
00007fb1689d5bbe  vmovaps xmm12, [rsp+0xB0]
00007fb1689d5bc7  vmovaps xmm13, [rsp+0xC0]
00007fb1689d5bd0  vmovaps xmm14, [rsp+0xD0]
00007fb1689d5bd9  vmovaps xmm15, [rsp+0xE0]
00007fb1689d5be2  add rsp, 0xF0
00007fb1689d5be9  pop r11
00007fb1689d5beb  pop r10
00007fb1689d5bed  pop r9
00007fb1689d5bef  pop r8
00007fb1689d5bf1  pop rsi
00007fb1689d5bf2  pop rdi
00007fb1689d5bf3  pop rdx
00007fb1689d5bf4  pop rcx
00007fb1689d5bf5  pop rax
00007fb1689d5bf6  add rsp, 0x08
00007fb1689d5bfa  jmp 0x00007FB1689D2FBF
00007fb1689d5bff  sub rsp, 0x08
00007fb1689d5c03  push rax
00007fb1689d5c04  push rcx
00007fb1689d5c05  push rdx
00007fb1689d5c06  push rdi
00007fb1689d5c07  push rsi
00007fb1689d5c08  push r8
00007fb1689d5c0a  push r9
00007fb1689d5c0c  push r10
00007fb1689d5c0e  push r11
00007fb1689d5c10  sub rsp, 0xF0
00007fb1689d5c17  vmovaps [rsp], xmm0
00007fb1689d5c1c  vmovaps [rsp+0x10], xmm2
00007fb1689d5c22  vmovaps [rsp+0x20], xmm3
00007fb1689d5c28  vmovaps [rsp+0x30], xmm4
00007fb1689d5c2e  vmovaps [rsp+0x40], xmm5
00007fb1689d5c34  vmovaps [rsp+0x50], xmm6
00007fb1689d5c3a  vmovaps [rsp+0x60], xmm7
00007fb1689d5c40  vmovaps [rsp+0x70], xmm8
00007fb1689d5c46  vmovaps [rsp+0x80], xmm9
00007fb1689d5c4f  vmovaps [rsp+0x90], xmm10
00007fb1689d5c58  vmovaps [rsp+0xA0], xmm11
00007fb1689d5c61  vmovaps [rsp+0xB0], xmm12
00007fb1689d5c6a  vmovaps [rsp+0xC0], xmm13
00007fb1689d5c73  vmovaps [rsp+0xD0], xmm14
00007fb1689d5c7c  vmovaps [rsp+0xE0], xmm15
00007fb1689d5c85  sub rsp, 0x30
00007fb1689d5c89  movaps [rsp], xmm1
00007fb1689d5c8d  movaps [rsp+0x10], xmm5
00007fb1689d5c92  movaps [rsp+0x20], xmm13
00007fb1689d5c98  lea rdi, [rsp]
00007fb1689d5c9c  mov esi, 0x00
00007fb1689d5ca1  mov rax, 0x57CCFD419530
00007fb1689d5cab  call rax
00007fb1689d5cad  movaps xmm1, [rsp]
00007fb1689d5cb1  add rsp, 0x30
00007fb1689d5cb5  vmovaps xmm0, [rsp]
00007fb1689d5cba  vmovaps xmm2, [rsp+0x10]
00007fb1689d5cc0  vmovaps xmm3, [rsp+0x20]
00007fb1689d5cc6  vmovaps xmm4, [rsp+0x30]
00007fb1689d5ccc  vmovaps xmm5, [rsp+0x40]
00007fb1689d5cd2  vmovaps xmm6, [rsp+0x50]
00007fb1689d5cd8  vmovaps xmm7, [rsp+0x60]
00007fb1689d5cde  vmovaps xmm8, [rsp+0x70]
00007fb1689d5ce4  vmovaps xmm9, [rsp+0x80]
00007fb1689d5ced  vmovaps xmm10, [rsp+0x90]
00007fb1689d5cf6  vmovaps xmm11, [rsp+0xA0]
00007fb1689d5cff  vmovaps xmm12, [rsp+0xB0]
00007fb1689d5d08  vmovaps xmm13, [rsp+0xC0]
00007fb1689d5d11  vmovaps xmm14, [rsp+0xD0]
00007fb1689d5d1a  vmovaps xmm15, [rsp+0xE0]
00007fb1689d5d23  add rsp, 0xF0
00007fb1689d5d2a  pop r11
00007fb1689d5d2c  pop r10
00007fb1689d5d2e  pop r9
00007fb1689d5d30  pop r8
00007fb1689d5d32  pop rsi
00007fb1689d5d33  pop rdi
00007fb1689d5d34  pop rdx
00007fb1689d5d35  pop rcx
00007fb1689d5d36  pop rax
00007fb1689d5d37  add rsp, 0x08
00007fb1689d5d3b  jmp 0x00007FB1689D2FDD
00007fb1689d5d40  sub rsp, 0x08
00007fb1689d5d44  push rax
00007fb1689d5d45  push rcx
00007fb1689d5d46  push rdx
00007fb1689d5d47  push rdi
00007fb1689d5d48  push rsi
00007fb1689d5d49  push r8
00007fb1689d5d4b  push r9
00007fb1689d5d4d  push r10
00007fb1689d5d4f  push r11
00007fb1689d5d51  sub rsp, 0xF0
00007fb1689d5d58  vmovaps [rsp], xmm0
00007fb1689d5d5d  vmovaps [rsp+0x10], xmm1
00007fb1689d5d63  vmovaps [rsp+0x20], xmm2
00007fb1689d5d69  vmovaps [rsp+0x30], xmm3
00007fb1689d5d6f  vmovaps [rsp+0x40], xmm4
00007fb1689d5d75  vmovaps [rsp+0x50], xmm6
00007fb1689d5d7b  vmovaps [rsp+0x60], xmm7
00007fb1689d5d81  vmovaps [rsp+0x70], xmm8
00007fb1689d5d87  vmovaps [rsp+0x80], xmm9
00007fb1689d5d90  vmovaps [rsp+0x90], xmm10
00007fb1689d5d99  vmovaps [rsp+0xA0], xmm11
00007fb1689d5da2  vmovaps [rsp+0xB0], xmm12
00007fb1689d5dab  vmovaps [rsp+0xC0], xmm13
00007fb1689d5db4  vmovaps [rsp+0xD0], xmm14
00007fb1689d5dbd  vmovaps [rsp+0xE0], xmm15
00007fb1689d5dc6  sub rsp, 0x30
00007fb1689d5dca  movaps [rsp], xmm5
00007fb1689d5dce  movaps [rsp+0x10], xmm2
00007fb1689d5dd3  movaps [rsp+0x20], xmm13
00007fb1689d5dd9  lea rdi, [rsp]
00007fb1689d5ddd  mov esi, 0x00
00007fb1689d5de2  mov rax, 0x57CCFD419530
00007fb1689d5dec  call rax
00007fb1689d5dee  movaps xmm5, [rsp]
00007fb1689d5df2  add rsp, 0x30
00007fb1689d5df6  vmovaps xmm0, [rsp]
00007fb1689d5dfb  vmovaps xmm1, [rsp+0x10]
00007fb1689d5e01  vmovaps xmm2, [rsp+0x20]
00007fb1689d5e07  vmovaps xmm3, [rsp+0x30]
00007fb1689d5e0d  vmovaps xmm4, [rsp+0x40]
00007fb1689d5e13  vmovaps xmm6, [rsp+0x50]
00007fb1689d5e19  vmovaps xmm7, [rsp+0x60]
00007fb1689d5e1f  vmovaps xmm8, [rsp+0x70]
00007fb1689d5e25  vmovaps xmm9, [rsp+0x80]
00007fb1689d5e2e  vmovaps xmm10, [rsp+0x90]
00007fb1689d5e37  vmovaps xmm11, [rsp+0xA0]
00007fb1689d5e40  vmovaps xmm12, [rsp+0xB0]
00007fb1689d5e49  vmovaps xmm13, [rsp+0xC0]
00007fb1689d5e52  vmovaps xmm14, [rsp+0xD0]
00007fb1689d5e5b  vmovaps xmm15, [rsp+0xE0]
00007fb1689d5e64  add rsp, 0xF0
00007fb1689d5e6b  pop r11
00007fb1689d5e6d  pop r10
00007fb1689d5e6f  pop r9
00007fb1689d5e71  pop r8
00007fb1689d5e73  pop rsi
00007fb1689d5e74  pop rdi
00007fb1689d5e75  pop rdx
00007fb1689d5e76  pop rcx
00007fb1689d5e77  pop rax
00007fb1689d5e78  add rsp, 0x08
00007fb1689d5e7c  jmp 0x00007FB1689D3013
00007fb1689d5e81  sub rsp, 0x08
00007fb1689d5e85  push rax
00007fb1689d5e86  push rcx
00007fb1689d5e87  push rdx
00007fb1689d5e88  push rdi
00007fb1689d5e89  push rsi
00007fb1689d5e8a  push r8
00007fb1689d5e8c  push r9
00007fb1689d5e8e  push r10
00007fb1689d5e90  push r11
00007fb1689d5e92  sub rsp, 0xF0
00007fb1689d5e99  vmovaps [rsp], xmm0
00007fb1689d5e9e  vmovaps [rsp+0x10], xmm1
00007fb1689d5ea4  vmovaps [rsp+0x20], xmm2
00007fb1689d5eaa  vmovaps [rsp+0x30], xmm3
00007fb1689d5eb0  vmovaps [rsp+0x40], xmm4
00007fb1689d5eb6  vmovaps [rsp+0x50], xmm5
00007fb1689d5ebc  vmovaps [rsp+0x60], xmm6
00007fb1689d5ec2  vmovaps [rsp+0x70], xmm7
00007fb1689d5ec8  vmovaps [rsp+0x80], xmm8
00007fb1689d5ed1  vmovaps [rsp+0x90], xmm9
00007fb1689d5eda  vmovaps [rsp+0xA0], xmm10
00007fb1689d5ee3  vmovaps [rsp+0xB0], xmm11
00007fb1689d5eec  vmovaps [rsp+0xC0], xmm12
00007fb1689d5ef5  vmovaps [rsp+0xD0], xmm14
00007fb1689d5efe  vmovaps [rsp+0xE0], xmm15
00007fb1689d5f07  sub rsp, 0x30
00007fb1689d5f0b  movaps [rsp], xmm13
00007fb1689d5f10  movaps [rsp+0x10], xmm10
00007fb1689d5f16  movaps [rsp+0x20], xmm1
00007fb1689d5f1b  lea rdi, [rsp]
00007fb1689d5f1f  mov esi, 0x00
00007fb1689d5f24  mov rax, 0x57CCFD419530
00007fb1689d5f2e  call rax
00007fb1689d5f30  movaps xmm13, [rsp]
00007fb1689d5f35  add rsp, 0x30
00007fb1689d5f39  vmovaps xmm0, [rsp]
00007fb1689d5f3e  vmovaps xmm1, [rsp+0x10]
00007fb1689d5f44  vmovaps xmm2, [rsp+0x20]
00007fb1689d5f4a  vmovaps xmm3, [rsp+0x30]
00007fb1689d5f50  vmovaps xmm4, [rsp+0x40]
00007fb1689d5f56  vmovaps xmm5, [rsp+0x50]
00007fb1689d5f5c  vmovaps xmm6, [rsp+0x60]
00007fb1689d5f62  vmovaps xmm7, [rsp+0x70]
00007fb1689d5f68  vmovaps xmm8, [rsp+0x80]
00007fb1689d5f71  vmovaps xmm9, [rsp+0x90]
00007fb1689d5f7a  vmovaps xmm10, [rsp+0xA0]
00007fb1689d5f83  vmovaps xmm11, [rsp+0xB0]
00007fb1689d5f8c  vmovaps xmm12, [rsp+0xC0]
00007fb1689d5f95  vmovaps xmm14, [rsp+0xD0]
00007fb1689d5f9e  vmovaps xmm15, [rsp+0xE0]
00007fb1689d5fa7  add rsp, 0xF0
00007fb1689d5fae  pop r11
00007fb1689d5fb0  pop r10
00007fb1689d5fb2  pop r9
00007fb1689d5fb4  pop r8
00007fb1689d5fb6  pop rsi
00007fb1689d5fb7  pop rdi
00007fb1689d5fb8  pop rdx
00007fb1689d5fb9  pop rcx
00007fb1689d5fba  pop rax
00007fb1689d5fbb  add rsp, 0x08
00007fb1689d5fbf  jmp 0x00007FB1689D303C
00007fb1689d5fc4  sub rsp, 0x08
00007fb1689d5fc8  push rax
00007fb1689d5fc9  push rcx
00007fb1689d5fca  push rdx
00007fb1689d5fcb  push rdi
00007fb1689d5fcc  push rsi
00007fb1689d5fcd  push r8
00007fb1689d5fcf  push r9
00007fb1689d5fd1  push r10
00007fb1689d5fd3  push r11
00007fb1689d5fd5  sub rsp, 0xF0
00007fb1689d5fdc  vmovaps [rsp], xmm0
00007fb1689d5fe1  vmovaps [rsp+0x10], xmm2
00007fb1689d5fe7  vmovaps [rsp+0x20], xmm3
00007fb1689d5fed  vmovaps [rsp+0x30], xmm4
00007fb1689d5ff3  vmovaps [rsp+0x40], xmm5
00007fb1689d5ff9  vmovaps [rsp+0x50], xmm6
00007fb1689d5fff  vmovaps [rsp+0x60], xmm7
00007fb1689d6005  vmovaps [rsp+0x70], xmm8
00007fb1689d600b  vmovaps [rsp+0x80], xmm9
00007fb1689d6014  vmovaps [rsp+0x90], xmm10
00007fb1689d601d  vmovaps [rsp+0xA0], xmm11
00007fb1689d6026  vmovaps [rsp+0xB0], xmm12
00007fb1689d602f  vmovaps [rsp+0xC0], xmm13
00007fb1689d6038  vmovaps [rsp+0xD0], xmm14
00007fb1689d6041  vmovaps [rsp+0xE0], xmm15
00007fb1689d604a  sub rsp, 0x30
00007fb1689d604e  movaps [rsp], xmm1
00007fb1689d6052  movaps [rsp+0x10], xmm15
00007fb1689d6058  movaps [rsp+0x20], xmm10
00007fb1689d605e  lea rdi, [rsp]
00007fb1689d6062  mov esi, 0x00
00007fb1689d6067  mov rax, 0x57CCFD419530
00007fb1689d6071  call rax
00007fb1689d6073  movaps xmm1, [rsp]
00007fb1689d6077  add rsp, 0x30
00007fb1689d607b  vmovaps xmm0, [rsp]
00007fb1689d6080  vmovaps xmm2, [rsp+0x10]
00007fb1689d6086  vmovaps xmm3, [rsp+0x20]
00007fb1689d608c  vmovaps xmm4, [rsp+0x30]
00007fb1689d6092  vmovaps xmm5, [rsp+0x40]
00007fb1689d6098  vmovaps xmm6, [rsp+0x50]
00007fb1689d609e  vmovaps xmm7, [rsp+0x60]
00007fb1689d60a4  vmovaps xmm8, [rsp+0x70]
00007fb1689d60aa  vmovaps xmm9, [rsp+0x80]
00007fb1689d60b3  vmovaps xmm10, [rsp+0x90]
00007fb1689d60bc  vmovaps xmm11, [rsp+0xA0]
00007fb1689d60c5  vmovaps xmm12, [rsp+0xB0]
00007fb1689d60ce  vmovaps xmm13, [rsp+0xC0]
00007fb1689d60d7  vmovaps xmm14, [rsp+0xD0]
00007fb1689d60e0  vmovaps xmm15, [rsp+0xE0]
00007fb1689d60e9  add rsp, 0xF0
00007fb1689d60f0  pop r11
00007fb1689d60f2  pop r10
00007fb1689d60f4  pop r9
00007fb1689d60f6  pop r8
00007fb1689d60f8  pop rsi
00007fb1689d60f9  pop rdi
00007fb1689d60fa  pop rdx
00007fb1689d60fb  pop rcx
00007fb1689d60fc  pop rax
00007fb1689d60fd  add rsp, 0x08
00007fb1689d6101  jmp 0x00007FB1689D305B
00007fb1689d6106  sub rsp, 0x08
00007fb1689d610a  push rax
00007fb1689d610b  push rcx
00007fb1689d610c  push rdx
00007fb1689d610d  push rdi
00007fb1689d610e  push rsi
00007fb1689d610f  push r8
00007fb1689d6111  push r9
00007fb1689d6113  push r10
00007fb1689d6115  push r11
00007fb1689d6117  sub rsp, 0xF0
00007fb1689d611e  vmovaps [rsp], xmm0
00007fb1689d6123  vmovaps [rsp+0x10], xmm1
00007fb1689d6129  vmovaps [rsp+0x20], xmm2
00007fb1689d612f  vmovaps [rsp+0x30], xmm3
00007fb1689d6135  vmovaps [rsp+0x40], xmm4
00007fb1689d613b  vmovaps [rsp+0x50], xmm5
00007fb1689d6141  vmovaps [rsp+0x60], xmm6
00007fb1689d6147  vmovaps [rsp+0x70], xmm7
00007fb1689d614d  vmovaps [rsp+0x80], xmm8
00007fb1689d6156  vmovaps [rsp+0x90], xmm9
00007fb1689d615f  vmovaps [rsp+0xA0], xmm10
00007fb1689d6168  vmovaps [rsp+0xB0], xmm11
00007fb1689d6171  vmovaps [rsp+0xC0], xmm12
00007fb1689d617a  vmovaps [rsp+0xD0], xmm13
00007fb1689d6183  vmovaps [rsp+0xE0], xmm14
00007fb1689d618c  sub rsp, 0x30
00007fb1689d6190  movaps [rsp], xmm15
00007fb1689d6195  movaps [rsp+0x10], xmm10
00007fb1689d619b  movaps [rsp+0x20], xmm11
00007fb1689d61a1  lea rdi, [rsp]
00007fb1689d61a5  mov esi, 0x00
00007fb1689d61aa  mov rax, 0x57CCFD419530
00007fb1689d61b4  call rax
00007fb1689d61b6  movaps xmm15, [rsp]
00007fb1689d61bb  add rsp, 0x30
00007fb1689d61bf  vmovaps xmm0, [rsp]
00007fb1689d61c4  vmovaps xmm1, [rsp+0x10]
00007fb1689d61ca  vmovaps xmm2, [rsp+0x20]
00007fb1689d61d0  vmovaps xmm3, [rsp+0x30]
00007fb1689d61d6  vmovaps xmm4, [rsp+0x40]
00007fb1689d61dc  vmovaps xmm5, [rsp+0x50]
00007fb1689d61e2  vmovaps xmm6, [rsp+0x60]
00007fb1689d61e8  vmovaps xmm7, [rsp+0x70]
00007fb1689d61ee  vmovaps xmm8, [rsp+0x80]
00007fb1689d61f7  vmovaps xmm9, [rsp+0x90]
00007fb1689d6200  vmovaps xmm10, [rsp+0xA0]
00007fb1689d6209  vmovaps xmm11, [rsp+0xB0]
00007fb1689d6212  vmovaps xmm12, [rsp+0xC0]
00007fb1689d621b  vmovaps xmm13, [rsp+0xD0]
00007fb1689d6224  vmovaps xmm14, [rsp+0xE0]
00007fb1689d622d  add rsp, 0xF0
00007fb1689d6234  pop r11
00007fb1689d6236  pop r10
00007fb1689d6238  pop r9
00007fb1689d623a  pop r8
00007fb1689d623c  pop rsi
00007fb1689d623d  pop rdi
00007fb1689d623e  pop rdx
00007fb1689d623f  pop rcx
00007fb1689d6240  pop rax
00007fb1689d6241  add rsp, 0x08
00007fb1689d6245  jmp 0x00007FB1689D307E
00007fb1689d624a  sub rsp, 0x08
00007fb1689d624e  push rax
00007fb1689d624f  push rcx
00007fb1689d6250  push rdx
00007fb1689d6251  push rdi
00007fb1689d6252  push rsi
00007fb1689d6253  push r8
00007fb1689d6255  push r9
00007fb1689d6257  push r10
00007fb1689d6259  push r11
00007fb1689d625b  sub rsp, 0xF0
00007fb1689d6262  vmovaps [rsp], xmm0
00007fb1689d6267  vmovaps [rsp+0x10], xmm1
00007fb1689d626d  vmovaps [rsp+0x20], xmm2
00007fb1689d6273  vmovaps [rsp+0x30], xmm3
00007fb1689d6279  vmovaps [rsp+0x40], xmm4
00007fb1689d627f  vmovaps [rsp+0x50], xmm5
00007fb1689d6285  vmovaps [rsp+0x60], xmm6
00007fb1689d628b  vmovaps [rsp+0x70], xmm7
00007fb1689d6291  vmovaps [rsp+0x80], xmm8
00007fb1689d629a  vmovaps [rsp+0x90], xmm9
00007fb1689d62a3  vmovaps [rsp+0xA0], xmm11
00007fb1689d62ac  vmovaps [rsp+0xB0], xmm12
00007fb1689d62b5  vmovaps [rsp+0xC0], xmm13
00007fb1689d62be  vmovaps [rsp+0xD0], xmm14
00007fb1689d62c7  vmovaps [rsp+0xE0], xmm15
00007fb1689d62d0  sub rsp, 0x30
00007fb1689d62d4  movaps [rsp], xmm10
00007fb1689d62d9  movaps [rsp+0x10], xmm2
00007fb1689d62de  movaps [rsp+0x20], xmm11
00007fb1689d62e4  lea rdi, [rsp]
00007fb1689d62e8  mov esi, 0x00
00007fb1689d62ed  mov rax, 0x57CCFD419530
00007fb1689d62f7  call rax
00007fb1689d62f9  movaps xmm10, [rsp]
00007fb1689d62fe  add rsp, 0x30
00007fb1689d6302  vmovaps xmm0, [rsp]
00007fb1689d6307  vmovaps xmm1, [rsp+0x10]
00007fb1689d630d  vmovaps xmm2, [rsp+0x20]
00007fb1689d6313  vmovaps xmm3, [rsp+0x30]
00007fb1689d6319  vmovaps xmm4, [rsp+0x40]
00007fb1689d631f  vmovaps xmm5, [rsp+0x50]
00007fb1689d6325  vmovaps xmm6, [rsp+0x60]
00007fb1689d632b  vmovaps xmm7, [rsp+0x70]
00007fb1689d6331  vmovaps xmm8, [rsp+0x80]
00007fb1689d633a  vmovaps xmm9, [rsp+0x90]
00007fb1689d6343  vmovaps xmm11, [rsp+0xA0]
00007fb1689d634c  vmovaps xmm12, [rsp+0xB0]
00007fb1689d6355  vmovaps xmm13, [rsp+0xC0]
00007fb1689d635e  vmovaps xmm14, [rsp+0xD0]
00007fb1689d6367  vmovaps xmm15, [rsp+0xE0]
00007fb1689d6370  add rsp, 0xF0
00007fb1689d6377  pop r11
00007fb1689d6379  pop r10
00007fb1689d637b  pop r9
00007fb1689d637d  pop r8
00007fb1689d637f  pop rsi
00007fb1689d6380  pop rdi
00007fb1689d6381  pop rdx
00007fb1689d6382  pop rcx
00007fb1689d6383  pop rax
00007fb1689d6384  add rsp, 0x08
00007fb1689d6388  jmp 0x00007FB1689D30B6
00007fb1689d638d  sub rsp, 0x08
00007fb1689d6391  push rax
00007fb1689d6392  push rcx
00007fb1689d6393  push rdx
00007fb1689d6394  push rdi
00007fb1689d6395  push rsi
00007fb1689d6396  push r8
00007fb1689d6398  push r9
00007fb1689d639a  push r10
00007fb1689d639c  push r11
00007fb1689d639e  sub rsp, 0xF0
00007fb1689d63a5  vmovaps [rsp], xmm0
00007fb1689d63aa  vmovaps [rsp+0x10], xmm1
00007fb1689d63b0  vmovaps [rsp+0x20], xmm2
00007fb1689d63b6  vmovaps [rsp+0x30], xmm3
00007fb1689d63bc  vmovaps [rsp+0x40], xmm4
00007fb1689d63c2  vmovaps [rsp+0x50], xmm5
00007fb1689d63c8  vmovaps [rsp+0x60], xmm6
00007fb1689d63ce  vmovaps [rsp+0x70], xmm7
00007fb1689d63d4  vmovaps [rsp+0x80], xmm8
00007fb1689d63dd  vmovaps [rsp+0x90], xmm9
00007fb1689d63e6  vmovaps [rsp+0xA0], xmm10
00007fb1689d63ef  vmovaps [rsp+0xB0], xmm12
00007fb1689d63f8  vmovaps [rsp+0xC0], xmm13
00007fb1689d6401  vmovaps [rsp+0xD0], xmm14
00007fb1689d640a  vmovaps [rsp+0xE0], xmm15
00007fb1689d6413  sub rsp, 0x30
00007fb1689d6417  movaps [rsp], xmm11
00007fb1689d641c  movaps [rsp+0x10], xmm2
00007fb1689d6421  movaps [rsp+0x20], xmm1
00007fb1689d6426  lea rdi, [rsp]
00007fb1689d642a  mov esi, 0x00
00007fb1689d642f  mov rax, 0x57CCFD419530
00007fb1689d6439  call rax
00007fb1689d643b  movaps xmm11, [rsp]
00007fb1689d6440  add rsp, 0x30
00007fb1689d6444  vmovaps xmm0, [rsp]
00007fb1689d6449  vmovaps xmm1, [rsp+0x10]
00007fb1689d644f  vmovaps xmm2, [rsp+0x20]
00007fb1689d6455  vmovaps xmm3, [rsp+0x30]
00007fb1689d645b  vmovaps xmm4, [rsp+0x40]
00007fb1689d6461  vmovaps xmm5, [rsp+0x50]
00007fb1689d6467  vmovaps xmm6, [rsp+0x60]
00007fb1689d646d  vmovaps xmm7, [rsp+0x70]
00007fb1689d6473  vmovaps xmm8, [rsp+0x80]
00007fb1689d647c  vmovaps xmm9, [rsp+0x90]
00007fb1689d6485  vmovaps xmm10, [rsp+0xA0]
00007fb1689d648e  vmovaps xmm12, [rsp+0xB0]
00007fb1689d6497  vmovaps xmm13, [rsp+0xC0]
00007fb1689d64a0  vmovaps xmm14, [rsp+0xD0]
00007fb1689d64a9  vmovaps xmm15, [rsp+0xE0]
00007fb1689d64b2  add rsp, 0xF0
00007fb1689d64b9  pop r11
00007fb1689d64bb  pop r10
00007fb1689d64bd  pop r9
00007fb1689d64bf  pop r8
00007fb1689d64c1  pop rsi
00007fb1689d64c2  pop rdi
00007fb1689d64c3  pop rdx
00007fb1689d64c4  pop rcx
00007fb1689d64c5  pop rax
00007fb1689d64c6  add rsp, 0x08
00007fb1689d64ca  jmp 0x00007FB1689D30F2
00007fb1689d64cf  sub rsp, 0x08
00007fb1689d64d3  push rax
00007fb1689d64d4  push rcx
00007fb1689d64d5  push rdx
00007fb1689d64d6  push rdi
00007fb1689d64d7  push rsi
00007fb1689d64d8  push r8
00007fb1689d64da  push r9
00007fb1689d64dc  push r10
00007fb1689d64de  push r11
00007fb1689d64e0  sub rsp, 0xF0
00007fb1689d64e7  vmovaps [rsp], xmm0
00007fb1689d64ec  vmovaps [rsp+0x10], xmm2
00007fb1689d64f2  vmovaps [rsp+0x20], xmm3
00007fb1689d64f8  vmovaps [rsp+0x30], xmm4
00007fb1689d64fe  vmovaps [rsp+0x40], xmm5
00007fb1689d6504  vmovaps [rsp+0x50], xmm6
00007fb1689d650a  vmovaps [rsp+0x60], xmm7
00007fb1689d6510  vmovaps [rsp+0x70], xmm8
00007fb1689d6516  vmovaps [rsp+0x80], xmm9
00007fb1689d651f  vmovaps [rsp+0x90], xmm10
00007fb1689d6528  vmovaps [rsp+0xA0], xmm11
00007fb1689d6531  vmovaps [rsp+0xB0], xmm12
00007fb1689d653a  vmovaps [rsp+0xC0], xmm13
00007fb1689d6543  vmovaps [rsp+0xD0], xmm14
00007fb1689d654c  vmovaps [rsp+0xE0], xmm15
00007fb1689d6555  sub rsp, 0x30
00007fb1689d6559  movaps [rsp], xmm1
00007fb1689d655d  movaps [rsp+0x10], xmm14
00007fb1689d6563  movaps [rsp+0x20], xmm6
00007fb1689d6568  lea rdi, [rsp]
00007fb1689d656c  mov esi, 0x00
00007fb1689d6571  mov rax, 0x57CCFD419530
00007fb1689d657b  call rax
00007fb1689d657d  movaps xmm1, [rsp]
00007fb1689d6581  add rsp, 0x30
00007fb1689d6585  vmovaps xmm0, [rsp]
00007fb1689d658a  vmovaps xmm2, [rsp+0x10]
00007fb1689d6590  vmovaps xmm3, [rsp+0x20]
00007fb1689d6596  vmovaps xmm4, [rsp+0x30]
00007fb1689d659c  vmovaps xmm5, [rsp+0x40]
00007fb1689d65a2  vmovaps xmm6, [rsp+0x50]
00007fb1689d65a8  vmovaps xmm7, [rsp+0x60]
00007fb1689d65ae  vmovaps xmm8, [rsp+0x70]
00007fb1689d65b4  vmovaps xmm9, [rsp+0x80]
00007fb1689d65bd  vmovaps xmm10, [rsp+0x90]
00007fb1689d65c6  vmovaps xmm11, [rsp+0xA0]
00007fb1689d65cf  vmovaps xmm12, [rsp+0xB0]
00007fb1689d65d8  vmovaps xmm13, [rsp+0xC0]
00007fb1689d65e1  vmovaps xmm14, [rsp+0xD0]
00007fb1689d65ea  vmovaps xmm15, [rsp+0xE0]
00007fb1689d65f3  add rsp, 0xF0
00007fb1689d65fa  pop r11
00007fb1689d65fc  pop r10
00007fb1689d65fe  pop r9
00007fb1689d6600  pop r8
00007fb1689d6602  pop rsi
00007fb1689d6603  pop rdi
00007fb1689d6604  pop rdx
00007fb1689d6605  pop rcx
00007fb1689d6606  pop rax
00007fb1689d6607  add rsp, 0x08
00007fb1689d660b  jmp 0x00007FB1689D310B
00007fb1689d6610  sub rsp, 0x08
00007fb1689d6614  push rax
00007fb1689d6615  push rcx
00007fb1689d6616  push rdx
00007fb1689d6617  push rdi
00007fb1689d6618  push rsi
00007fb1689d6619  push r8
00007fb1689d661b  push r9
00007fb1689d661d  push r10
00007fb1689d661f  push r11
00007fb1689d6621  sub rsp, 0xF0
00007fb1689d6628  vmovaps [rsp], xmm0
00007fb1689d662d  vmovaps [rsp+0x10], xmm1
00007fb1689d6633  vmovaps [rsp+0x20], xmm2
00007fb1689d6639  vmovaps [rsp+0x30], xmm3
00007fb1689d663f  vmovaps [rsp+0x40], xmm4
00007fb1689d6645  vmovaps [rsp+0x50], xmm5
00007fb1689d664b  vmovaps [rsp+0x60], xmm6
00007fb1689d6651  vmovaps [rsp+0x70], xmm7
00007fb1689d6657  vmovaps [rsp+0x80], xmm8
00007fb1689d6660  vmovaps [rsp+0x90], xmm9
00007fb1689d6669  vmovaps [rsp+0xA0], xmm10
00007fb1689d6672  vmovaps [rsp+0xB0], xmm11
00007fb1689d667b  vmovaps [rsp+0xC0], xmm12
00007fb1689d6684  vmovaps [rsp+0xD0], xmm13
00007fb1689d668d  vmovaps [rsp+0xE0], xmm14
00007fb1689d6696  sub rsp, 0x30
00007fb1689d669a  movaps [rsp], xmm15
00007fb1689d669f  movaps [rsp+0x10], xmm14
00007fb1689d66a5  movaps [rsp+0x20], xmm5
00007fb1689d66aa  lea rdi, [rsp]
00007fb1689d66ae  mov esi, 0x00
00007fb1689d66b3  mov rax, 0x57CCFD419530
00007fb1689d66bd  call rax
00007fb1689d66bf  movaps xmm15, [rsp]
00007fb1689d66c4  add rsp, 0x30
00007fb1689d66c8  vmovaps xmm0, [rsp]
00007fb1689d66cd  vmovaps xmm1, [rsp+0x10]
00007fb1689d66d3  vmovaps xmm2, [rsp+0x20]
00007fb1689d66d9  vmovaps xmm3, [rsp+0x30]
00007fb1689d66df  vmovaps xmm4, [rsp+0x40]
00007fb1689d66e5  vmovaps xmm5, [rsp+0x50]
00007fb1689d66eb  vmovaps xmm6, [rsp+0x60]
00007fb1689d66f1  vmovaps xmm7, [rsp+0x70]
00007fb1689d66f7  vmovaps xmm8, [rsp+0x80]
00007fb1689d6700  vmovaps xmm9, [rsp+0x90]
00007fb1689d6709  vmovaps xmm10, [rsp+0xA0]
00007fb1689d6712  vmovaps xmm11, [rsp+0xB0]
00007fb1689d671b  vmovaps xmm12, [rsp+0xC0]
00007fb1689d6724  vmovaps xmm13, [rsp+0xD0]
00007fb1689d672d  vmovaps xmm14, [rsp+0xE0]
00007fb1689d6736  add rsp, 0xF0
00007fb1689d673d  pop r11
00007fb1689d673f  pop r10
00007fb1689d6741  pop r9
00007fb1689d6743  pop r8
00007fb1689d6745  pop rsi
00007fb1689d6746  pop rdi
00007fb1689d6747  pop rdx
00007fb1689d6748  pop rcx
00007fb1689d6749  pop rax
00007fb1689d674a  add rsp, 0x08
00007fb1689d674e  jmp 0x00007FB1689D312B
00007fb1689d6753  sub rsp, 0x08
00007fb1689d6757  push rax
00007fb1689d6758  push rcx
00007fb1689d6759  push rdx
00007fb1689d675a  push rdi
00007fb1689d675b  push rsi
00007fb1689d675c  push r8
00007fb1689d675e  push r9
00007fb1689d6760  push r10
00007fb1689d6762  push r11
00007fb1689d6764  sub rsp, 0xF0
00007fb1689d676b  vmovaps [rsp], xmm0
00007fb1689d6770  vmovaps [rsp+0x10], xmm1
00007fb1689d6776  vmovaps [rsp+0x20], xmm2
00007fb1689d677c  vmovaps [rsp+0x30], xmm3
00007fb1689d6782  vmovaps [rsp+0x40], xmm4
00007fb1689d6788  vmovaps [rsp+0x50], xmm5
00007fb1689d678e  vmovaps [rsp+0x60], xmm7
00007fb1689d6794  vmovaps [rsp+0x70], xmm8
00007fb1689d679a  vmovaps [rsp+0x80], xmm9
00007fb1689d67a3  vmovaps [rsp+0x90], xmm10
00007fb1689d67ac  vmovaps [rsp+0xA0], xmm11
00007fb1689d67b5  vmovaps [rsp+0xB0], xmm12
00007fb1689d67be  vmovaps [rsp+0xC0], xmm13
00007fb1689d67c7  vmovaps [rsp+0xD0], xmm14
00007fb1689d67d0  vmovaps [rsp+0xE0], xmm15
00007fb1689d67d9  sub rsp, 0x30
00007fb1689d67dd  movaps [rsp], xmm6
00007fb1689d67e1  movaps [rsp+0x10], xmm9
00007fb1689d67e7  movaps [rsp+0x20], xmm14
00007fb1689d67ed  lea rdi, [rsp]
00007fb1689d67f1  mov esi, 0x00
00007fb1689d67f6  mov rax, 0x57CCFD419530
00007fb1689d6800  call rax
00007fb1689d6802  movaps xmm6, [rsp]
00007fb1689d6806  add rsp, 0x30
00007fb1689d680a  vmovaps xmm0, [rsp]
00007fb1689d680f  vmovaps xmm1, [rsp+0x10]
00007fb1689d6815  vmovaps xmm2, [rsp+0x20]
00007fb1689d681b  vmovaps xmm3, [rsp+0x30]
00007fb1689d6821  vmovaps xmm4, [rsp+0x40]
00007fb1689d6827  vmovaps xmm5, [rsp+0x50]
00007fb1689d682d  vmovaps xmm7, [rsp+0x60]
00007fb1689d6833  vmovaps xmm8, [rsp+0x70]
00007fb1689d6839  vmovaps xmm9, [rsp+0x80]
00007fb1689d6842  vmovaps xmm10, [rsp+0x90]
00007fb1689d684b  vmovaps xmm11, [rsp+0xA0]
00007fb1689d6854  vmovaps xmm12, [rsp+0xB0]
00007fb1689d685d  vmovaps xmm13, [rsp+0xC0]
00007fb1689d6866  vmovaps xmm14, [rsp+0xD0]
00007fb1689d686f  vmovaps xmm15, [rsp+0xE0]
00007fb1689d6878  add rsp, 0xF0
00007fb1689d687f  pop r11
00007fb1689d6881  pop r10
00007fb1689d6883  pop r9
00007fb1689d6885  pop r8
00007fb1689d6887  pop rsi
00007fb1689d6888  pop rdi
00007fb1689d6889  pop rdx
00007fb1689d688a  pop rcx
00007fb1689d688b  pop rax
00007fb1689d688c  add rsp, 0x08
00007fb1689d6890  jmp 0x00007FB1689D3153
00007fb1689d6895  sub rsp, 0x08
00007fb1689d6899  push rax
00007fb1689d689a  push rcx
00007fb1689d689b  push rdx
00007fb1689d689c  push rdi
00007fb1689d689d  push rsi
00007fb1689d689e  push r8
00007fb1689d68a0  push r9
00007fb1689d68a2  push r10
00007fb1689d68a4  push r11
00007fb1689d68a6  sub rsp, 0xF0
00007fb1689d68ad  vmovaps [rsp], xmm0
00007fb1689d68b2  vmovaps [rsp+0x10], xmm1
00007fb1689d68b8  vmovaps [rsp+0x20], xmm2
00007fb1689d68be  vmovaps [rsp+0x30], xmm3
00007fb1689d68c4  vmovaps [rsp+0x40], xmm4
00007fb1689d68ca  vmovaps [rsp+0x50], xmm5
00007fb1689d68d0  vmovaps [rsp+0x60], xmm6
00007fb1689d68d6  vmovaps [rsp+0x70], xmm7
00007fb1689d68dc  vmovaps [rsp+0x80], xmm8
00007fb1689d68e5  vmovaps [rsp+0x90], xmm9
00007fb1689d68ee  vmovaps [rsp+0xA0], xmm10
00007fb1689d68f7  vmovaps [rsp+0xB0], xmm11
00007fb1689d6900  vmovaps [rsp+0xC0], xmm12
00007fb1689d6909  vmovaps [rsp+0xD0], xmm13
00007fb1689d6912  vmovaps [rsp+0xE0], xmm15
00007fb1689d691b  sub rsp, 0x30
00007fb1689d691f  movaps [rsp], xmm14
00007fb1689d6924  movaps [rsp+0x10], xmm9
00007fb1689d692a  movaps [rsp+0x20], xmm13
00007fb1689d6930  lea rdi, [rsp]
00007fb1689d6934  mov esi, 0x00
00007fb1689d6939  mov rax, 0x57CCFD419530
00007fb1689d6943  call rax
00007fb1689d6945  movaps xmm14, [rsp]
00007fb1689d694a  add rsp, 0x30
00007fb1689d694e  vmovaps xmm0, [rsp]
00007fb1689d6953  vmovaps xmm1, [rsp+0x10]
00007fb1689d6959  vmovaps xmm2, [rsp+0x20]
00007fb1689d695f  vmovaps xmm3, [rsp+0x30]
00007fb1689d6965  vmovaps xmm4, [rsp+0x40]
00007fb1689d696b  vmovaps xmm5, [rsp+0x50]
00007fb1689d6971  vmovaps xmm6, [rsp+0x60]
00007fb1689d6977  vmovaps xmm7, [rsp+0x70]
00007fb1689d697d  vmovaps xmm8, [rsp+0x80]
00007fb1689d6986  vmovaps xmm9, [rsp+0x90]
00007fb1689d698f  vmovaps xmm10, [rsp+0xA0]
00007fb1689d6998  vmovaps xmm11, [rsp+0xB0]
00007fb1689d69a1  vmovaps xmm12, [rsp+0xC0]
00007fb1689d69aa  vmovaps xmm13, [rsp+0xD0]
00007fb1689d69b3  vmovaps xmm15, [rsp+0xE0]
00007fb1689d69bc  add rsp, 0xF0
00007fb1689d69c3  pop r11
00007fb1689d69c5  pop r10
00007fb1689d69c7  pop r9
00007fb1689d69c9  pop r8
00007fb1689d69cb  pop rsi
00007fb1689d69cc  pop rdi
00007fb1689d69cd  pop rdx
00007fb1689d69ce  pop rcx
00007fb1689d69cf  pop rax
00007fb1689d69d0  add rsp, 0x08
00007fb1689d69d4  jmp 0x00007FB1689D3176
00007fb1689d69d9  sub rsp, 0x08
00007fb1689d69dd  push rax
00007fb1689d69de  push rcx
00007fb1689d69df  push rdx
00007fb1689d69e0  push rdi
00007fb1689d69e1  push rsi
00007fb1689d69e2  push r8
00007fb1689d69e4  push r9
00007fb1689d69e6  push r10
00007fb1689d69e8  push r11
00007fb1689d69ea  sub rsp, 0xF0
00007fb1689d69f1  vmovaps [rsp], xmm0
00007fb1689d69f6  vmovaps [rsp+0x10], xmm1
00007fb1689d69fc  vmovaps [rsp+0x20], xmm2
00007fb1689d6a02  vmovaps [rsp+0x30], xmm3
00007fb1689d6a08  vmovaps [rsp+0x40], xmm4
00007fb1689d6a0e  vmovaps [rsp+0x50], xmm5
00007fb1689d6a14  vmovaps [rsp+0x60], xmm6
00007fb1689d6a1a  vmovaps [rsp+0x70], xmm7
00007fb1689d6a20  vmovaps [rsp+0x80], xmm8
00007fb1689d6a29  vmovaps [rsp+0x90], xmm9
00007fb1689d6a32  vmovaps [rsp+0xA0], xmm10
00007fb1689d6a3b  vmovaps [rsp+0xB0], xmm11
00007fb1689d6a44  vmovaps [rsp+0xC0], xmm12
00007fb1689d6a4d  vmovaps [rsp+0xD0], xmm14
00007fb1689d6a56  vmovaps [rsp+0xE0], xmm15
00007fb1689d6a5f  sub rsp, 0x30
00007fb1689d6a63  movaps [rsp], xmm13
00007fb1689d6a68  movaps [rsp+0x10], xmm9
00007fb1689d6a6e  movaps [rsp+0x20], xmm10
00007fb1689d6a74  lea rdi, [rsp]
00007fb1689d6a78  mov esi, 0x00
00007fb1689d6a7d  mov rax, 0x57CCFD419530
00007fb1689d6a87  call rax
00007fb1689d6a89  movaps xmm13, [rsp]
00007fb1689d6a8e  add rsp, 0x30
00007fb1689d6a92  vmovaps xmm0, [rsp]
00007fb1689d6a97  vmovaps xmm1, [rsp+0x10]
00007fb1689d6a9d  vmovaps xmm2, [rsp+0x20]
00007fb1689d6aa3  vmovaps xmm3, [rsp+0x30]
00007fb1689d6aa9  vmovaps xmm4, [rsp+0x40]
00007fb1689d6aaf  vmovaps xmm5, [rsp+0x50]
00007fb1689d6ab5  vmovaps xmm6, [rsp+0x60]
00007fb1689d6abb  vmovaps xmm7, [rsp+0x70]
00007fb1689d6ac1  vmovaps xmm8, [rsp+0x80]
00007fb1689d6aca  vmovaps xmm9, [rsp+0x90]
00007fb1689d6ad3  vmovaps xmm10, [rsp+0xA0]
00007fb1689d6adc  vmovaps xmm11, [rsp+0xB0]
00007fb1689d6ae5  vmovaps xmm12, [rsp+0xC0]
00007fb1689d6aee  vmovaps xmm14, [rsp+0xD0]
00007fb1689d6af7  vmovaps xmm15, [rsp+0xE0]
00007fb1689d6b00  add rsp, 0xF0
00007fb1689d6b07  pop r11
00007fb1689d6b09  pop r10
00007fb1689d6b0b  pop r9
00007fb1689d6b0d  pop r8
00007fb1689d6b0f  pop rsi
00007fb1689d6b10  pop rdi
00007fb1689d6b11  pop rdx
00007fb1689d6b12  pop rcx
00007fb1689d6b13  pop rax
00007fb1689d6b14  add rsp, 0x08
00007fb1689d6b18  jmp 0x00007FB1689D3196
00007fb1689d6b1d  call 0x00007FB16880AFE0
00007fb1689d6b22  jmp 0x00007FB1689D31EB
00007fb1689d6b27  sub rsp, 0x08
00007fb1689d6b2b  push rax
00007fb1689d6b2c  push rcx
00007fb1689d6b2d  push rdx
00007fb1689d6b2e  push rdi
00007fb1689d6b2f  push rsi
00007fb1689d6b30  push r8
00007fb1689d6b32  push r9
00007fb1689d6b34  push r10
00007fb1689d6b36  push r11
00007fb1689d6b38  sub rsp, 0xF0
00007fb1689d6b3f  vmovaps [rsp], xmm0
00007fb1689d6b44  vmovaps [rsp+0x10], xmm1
00007fb1689d6b4a  vmovaps [rsp+0x20], xmm2
00007fb1689d6b50  vmovaps [rsp+0x30], xmm3
00007fb1689d6b56  vmovaps [rsp+0x40], xmm4
00007fb1689d6b5c  vmovaps [rsp+0x50], xmm5
00007fb1689d6b62  vmovaps [rsp+0x60], xmm6
00007fb1689d6b68  vmovaps [rsp+0x70], xmm7
00007fb1689d6b6e  vmovaps [rsp+0x80], xmm8
00007fb1689d6b77  vmovaps [rsp+0x90], xmm10
00007fb1689d6b80  vmovaps [rsp+0xA0], xmm11
00007fb1689d6b89  vmovaps [rsp+0xB0], xmm12
00007fb1689d6b92  vmovaps [rsp+0xC0], xmm13
00007fb1689d6b9b  vmovaps [rsp+0xD0], xmm14
00007fb1689d6ba4  vmovaps [rsp+0xE0], xmm15
00007fb1689d6bad  sub rsp, 0x30
00007fb1689d6bb1  movaps [rsp], xmm9
00007fb1689d6bb6  movaps [rsp+0x10], xmm8
00007fb1689d6bbc  movaps [rsp+0x20], xmm10
00007fb1689d6bc2  lea rdi, [rsp]
00007fb1689d6bc6  mov esi, 0x00
00007fb1689d6bcb  mov rax, 0x57CCFD419530
00007fb1689d6bd5  call rax
00007fb1689d6bd7  movaps xmm9, [rsp]
00007fb1689d6bdc  add rsp, 0x30
00007fb1689d6be0  vmovaps xmm0, [rsp]
00007fb1689d6be5  vmovaps xmm1, [rsp+0x10]
00007fb1689d6beb  vmovaps xmm2, [rsp+0x20]
00007fb1689d6bf1  vmovaps xmm3, [rsp+0x30]
00007fb1689d6bf7  vmovaps xmm4, [rsp+0x40]
00007fb1689d6bfd  vmovaps xmm5, [rsp+0x50]
00007fb1689d6c03  vmovaps xmm6, [rsp+0x60]
00007fb1689d6c09  vmovaps xmm7, [rsp+0x70]
00007fb1689d6c0f  vmovaps xmm8, [rsp+0x80]
00007fb1689d6c18  vmovaps xmm10, [rsp+0x90]
00007fb1689d6c21  vmovaps xmm11, [rsp+0xA0]
00007fb1689d6c2a  vmovaps xmm12, [rsp+0xB0]
00007fb1689d6c33  vmovaps xmm13, [rsp+0xC0]
00007fb1689d6c3c  vmovaps xmm14, [rsp+0xD0]
00007fb1689d6c45  vmovaps xmm15, [rsp+0xE0]
00007fb1689d6c4e  add rsp, 0xF0
00007fb1689d6c55  pop r11
00007fb1689d6c57  pop r10
00007fb1689d6c59  pop r9
00007fb1689d6c5b  pop r8
00007fb1689d6c5d  pop rsi
00007fb1689d6c5e  pop rdi
00007fb1689d6c5f  pop rdx
00007fb1689d6c60  pop rcx
00007fb1689d6c61  pop rax
00007fb1689d6c62  add rsp, 0x08
00007fb1689d6c66  jmp 0x00007FB1689D321C
00007fb1689d6c6b  sub rsp, 0x08
00007fb1689d6c6f  push rax
00007fb1689d6c70  push rcx
00007fb1689d6c71  push rdx
00007fb1689d6c72  push rdi
00007fb1689d6c73  push rsi
00007fb1689d6c74  push r8
00007fb1689d6c76  push r9
00007fb1689d6c78  push r10
00007fb1689d6c7a  push r11
00007fb1689d6c7c  sub rsp, 0xF0
00007fb1689d6c83  vmovaps [rsp], xmm0
00007fb1689d6c88  vmovaps [rsp+0x10], xmm1
00007fb1689d6c8e  vmovaps [rsp+0x20], xmm2
00007fb1689d6c94  vmovaps [rsp+0x30], xmm3
00007fb1689d6c9a  vmovaps [rsp+0x40], xmm4
00007fb1689d6ca0  vmovaps [rsp+0x50], xmm5
00007fb1689d6ca6  vmovaps [rsp+0x60], xmm6
00007fb1689d6cac  vmovaps [rsp+0x70], xmm7
00007fb1689d6cb2  vmovaps [rsp+0x80], xmm8
00007fb1689d6cbb  vmovaps [rsp+0x90], xmm9
00007fb1689d6cc4  vmovaps [rsp+0xA0], xmm11
00007fb1689d6ccd  vmovaps [rsp+0xB0], xmm12
00007fb1689d6cd6  vmovaps [rsp+0xC0], xmm13
00007fb1689d6cdf  vmovaps [rsp+0xD0], xmm14
00007fb1689d6ce8  vmovaps [rsp+0xE0], xmm15
00007fb1689d6cf1  sub rsp, 0x30
00007fb1689d6cf5  movaps [rsp], xmm10
00007fb1689d6cfa  movaps [rsp+0x10], xmm1
00007fb1689d6cff  movaps [rsp+0x20], xmm11
00007fb1689d6d05  lea rdi, [rsp]
00007fb1689d6d09  mov esi, 0x00
00007fb1689d6d0e  mov rax, 0x57CCFD419530
00007fb1689d6d18  call rax
00007fb1689d6d1a  movaps xmm10, [rsp]
00007fb1689d6d1f  add rsp, 0x30
00007fb1689d6d23  vmovaps xmm0, [rsp]
00007fb1689d6d28  vmovaps xmm1, [rsp+0x10]
00007fb1689d6d2e  vmovaps xmm2, [rsp+0x20]
00007fb1689d6d34  vmovaps xmm3, [rsp+0x30]
00007fb1689d6d3a  vmovaps xmm4, [rsp+0x40]
00007fb1689d6d40  vmovaps xmm5, [rsp+0x50]
00007fb1689d6d46  vmovaps xmm6, [rsp+0x60]
00007fb1689d6d4c  vmovaps xmm7, [rsp+0x70]
00007fb1689d6d52  vmovaps xmm8, [rsp+0x80]
00007fb1689d6d5b  vmovaps xmm9, [rsp+0x90]
00007fb1689d6d64  vmovaps xmm11, [rsp+0xA0]
00007fb1689d6d6d  vmovaps xmm12, [rsp+0xB0]
00007fb1689d6d76  vmovaps xmm13, [rsp+0xC0]
00007fb1689d6d7f  vmovaps xmm14, [rsp+0xD0]
00007fb1689d6d88  vmovaps xmm15, [rsp+0xE0]
00007fb1689d6d91  add rsp, 0xF0
00007fb1689d6d98  pop r11
00007fb1689d6d9a  pop r10
00007fb1689d6d9c  pop r9
00007fb1689d6d9e  pop r8
00007fb1689d6da0  pop rsi
00007fb1689d6da1  pop rdi
00007fb1689d6da2  pop rdx
00007fb1689d6da3  pop rcx
00007fb1689d6da4  pop rax
00007fb1689d6da5  add rsp, 0x08
00007fb1689d6da9  jmp 0x00007FB1689D3237
00007fb1689d6dae  sub rsp, 0x08
00007fb1689d6db2  push rax
00007fb1689d6db3  push rcx
00007fb1689d6db4  push rdx
00007fb1689d6db5  push rdi
00007fb1689d6db6  push rsi
00007fb1689d6db7  push r8
00007fb1689d6db9  push r9
00007fb1689d6dbb  push r10
00007fb1689d6dbd  push r11
00007fb1689d6dbf  sub rsp, 0xF0
00007fb1689d6dc6  vmovaps [rsp], xmm0
00007fb1689d6dcb  vmovaps [rsp+0x10], xmm2
00007fb1689d6dd1  vmovaps [rsp+0x20], xmm3
00007fb1689d6dd7  vmovaps [rsp+0x30], xmm4
00007fb1689d6ddd  vmovaps [rsp+0x40], xmm5
00007fb1689d6de3  vmovaps [rsp+0x50], xmm6
00007fb1689d6de9  vmovaps [rsp+0x60], xmm7
00007fb1689d6def  vmovaps [rsp+0x70], xmm8
00007fb1689d6df5  vmovaps [rsp+0x80], xmm9
00007fb1689d6dfe  vmovaps [rsp+0x90], xmm10
00007fb1689d6e07  vmovaps [rsp+0xA0], xmm11
00007fb1689d6e10  vmovaps [rsp+0xB0], xmm12
00007fb1689d6e19  vmovaps [rsp+0xC0], xmm13
00007fb1689d6e22  vmovaps [rsp+0xD0], xmm14
00007fb1689d6e2b  vmovaps [rsp+0xE0], xmm15
00007fb1689d6e34  sub rsp, 0x30
00007fb1689d6e38  movaps [rsp], xmm1
00007fb1689d6e3c  movaps [rsp+0x10], xmm15
00007fb1689d6e42  movaps [rsp+0x20], xmm6
00007fb1689d6e47  lea rdi, [rsp]
00007fb1689d6e4b  mov esi, 0x00
00007fb1689d6e50  mov rax, 0x57CCFD419530
00007fb1689d6e5a  call rax
00007fb1689d6e5c  movaps xmm1, [rsp]
00007fb1689d6e60  add rsp, 0x30
00007fb1689d6e64  vmovaps xmm0, [rsp]
00007fb1689d6e69  vmovaps xmm2, [rsp+0x10]
00007fb1689d6e6f  vmovaps xmm3, [rsp+0x20]
00007fb1689d6e75  vmovaps xmm4, [rsp+0x30]
00007fb1689d6e7b  vmovaps xmm5, [rsp+0x40]
00007fb1689d6e81  vmovaps xmm6, [rsp+0x50]
00007fb1689d6e87  vmovaps xmm7, [rsp+0x60]
00007fb1689d6e8d  vmovaps xmm8, [rsp+0x70]
00007fb1689d6e93  vmovaps xmm9, [rsp+0x80]
00007fb1689d6e9c  vmovaps xmm10, [rsp+0x90]
00007fb1689d6ea5  vmovaps xmm11, [rsp+0xA0]
00007fb1689d6eae  vmovaps xmm12, [rsp+0xB0]
00007fb1689d6eb7  vmovaps xmm13, [rsp+0xC0]
00007fb1689d6ec0  vmovaps xmm14, [rsp+0xD0]
00007fb1689d6ec9  vmovaps xmm15, [rsp+0xE0]
00007fb1689d6ed2  add rsp, 0xF0
00007fb1689d6ed9  pop r11
00007fb1689d6edb  pop r10
00007fb1689d6edd  pop r9
00007fb1689d6edf  pop r8
00007fb1689d6ee1  pop rsi
00007fb1689d6ee2  pop rdi
00007fb1689d6ee3  pop rdx
00007fb1689d6ee4  pop rcx
00007fb1689d6ee5  pop rax
00007fb1689d6ee6  add rsp, 0x08
00007fb1689d6eea  jmp 0x00007FB1689D3250
00007fb1689d6eef  sub rsp, 0x08
00007fb1689d6ef3  push rax
00007fb1689d6ef4  push rcx
00007fb1689d6ef5  push rdx
00007fb1689d6ef6  push rdi
00007fb1689d6ef7  push rsi
00007fb1689d6ef8  push r8
00007fb1689d6efa  push r9
00007fb1689d6efc  push r10
00007fb1689d6efe  push r11
00007fb1689d6f00  sub rsp, 0xF0
00007fb1689d6f07  vmovaps [rsp], xmm0
00007fb1689d6f0c  vmovaps [rsp+0x10], xmm1
00007fb1689d6f12  vmovaps [rsp+0x20], xmm2
00007fb1689d6f18  vmovaps [rsp+0x30], xmm3
00007fb1689d6f1e  vmovaps [rsp+0x40], xmm4
00007fb1689d6f24  vmovaps [rsp+0x50], xmm5
00007fb1689d6f2a  vmovaps [rsp+0x60], xmm6
00007fb1689d6f30  vmovaps [rsp+0x70], xmm7
00007fb1689d6f36  vmovaps [rsp+0x80], xmm8
00007fb1689d6f3f  vmovaps [rsp+0x90], xmm9
00007fb1689d6f48  vmovaps [rsp+0xA0], xmm10
00007fb1689d6f51  vmovaps [rsp+0xB0], xmm12
00007fb1689d6f5a  vmovaps [rsp+0xC0], xmm13
00007fb1689d6f63  vmovaps [rsp+0xD0], xmm14
00007fb1689d6f6c  vmovaps [rsp+0xE0], xmm15
00007fb1689d6f75  sub rsp, 0x30
00007fb1689d6f79  movaps [rsp], xmm11
00007fb1689d6f7e  movaps [rsp+0x10], xmm12
00007fb1689d6f84  movaps [rsp+0x20], xmm15
00007fb1689d6f8a  lea rdi, [rsp]
00007fb1689d6f8e  mov esi, 0x00
00007fb1689d6f93  mov rax, 0x57CCFD419530
00007fb1689d6f9d  call rax
00007fb1689d6f9f  movaps xmm11, [rsp]
00007fb1689d6fa4  add rsp, 0x30
00007fb1689d6fa8  vmovaps xmm0, [rsp]
00007fb1689d6fad  vmovaps xmm1, [rsp+0x10]
00007fb1689d6fb3  vmovaps xmm2, [rsp+0x20]
00007fb1689d6fb9  vmovaps xmm3, [rsp+0x30]
00007fb1689d6fbf  vmovaps xmm4, [rsp+0x40]
00007fb1689d6fc5  vmovaps xmm5, [rsp+0x50]
00007fb1689d6fcb  vmovaps xmm6, [rsp+0x60]
00007fb1689d6fd1  vmovaps xmm7, [rsp+0x70]
00007fb1689d6fd7  vmovaps xmm8, [rsp+0x80]
00007fb1689d6fe0  vmovaps xmm9, [rsp+0x90]
00007fb1689d6fe9  vmovaps xmm10, [rsp+0xA0]
00007fb1689d6ff2  vmovaps xmm12, [rsp+0xB0]
00007fb1689d6ffb  vmovaps xmm13, [rsp+0xC0]
00007fb1689d7004  vmovaps xmm14, [rsp+0xD0]
00007fb1689d700d  vmovaps xmm15, [rsp+0xE0]
00007fb1689d7016  add rsp, 0xF0
00007fb1689d701d  pop r11
00007fb1689d701f  pop r10
00007fb1689d7021  pop r9
00007fb1689d7023  pop r8
00007fb1689d7025  pop rsi
00007fb1689d7026  pop rdi
00007fb1689d7027  pop rdx
00007fb1689d7028  pop rcx
00007fb1689d7029  pop rax
00007fb1689d702a  add rsp, 0x08
00007fb1689d702e  jmp 0x00007FB1689D327A
00007fb1689d7033  sub rsp, 0x08
00007fb1689d7037  push rax
00007fb1689d7038  push rcx
00007fb1689d7039  push rdx
00007fb1689d703a  push rdi
00007fb1689d703b  push rsi
00007fb1689d703c  push r8
00007fb1689d703e  push r9
00007fb1689d7040  push r10
00007fb1689d7042  push r11
00007fb1689d7044  sub rsp, 0xF0
00007fb1689d704b  vmovaps [rsp], xmm0
00007fb1689d7050  vmovaps [rsp+0x10], xmm1
00007fb1689d7056  vmovaps [rsp+0x20], xmm2
00007fb1689d705c  vmovaps [rsp+0x30], xmm3
00007fb1689d7062  vmovaps [rsp+0x40], xmm4
00007fb1689d7068  vmovaps [rsp+0x50], xmm5
00007fb1689d706e  vmovaps [rsp+0x60], xmm6
00007fb1689d7074  vmovaps [rsp+0x70], xmm7
00007fb1689d707a  vmovaps [rsp+0x80], xmm8
00007fb1689d7083  vmovaps [rsp+0x90], xmm9
00007fb1689d708c  vmovaps [rsp+0xA0], xmm10
00007fb1689d7095  vmovaps [rsp+0xB0], xmm11
00007fb1689d709e  vmovaps [rsp+0xC0], xmm13
00007fb1689d70a7  vmovaps [rsp+0xD0], xmm14
00007fb1689d70b0  vmovaps [rsp+0xE0], xmm15
00007fb1689d70b9  sub rsp, 0x30
00007fb1689d70bd  movaps [rsp], xmm12
00007fb1689d70c2  movaps [rsp+0x10], xmm8
00007fb1689d70c8  movaps [rsp+0x20], xmm15
00007fb1689d70ce  lea rdi, [rsp]
00007fb1689d70d2  mov esi, 0x00
00007fb1689d70d7  mov rax, 0x57CCFD419530
00007fb1689d70e1  call rax
00007fb1689d70e3  movaps xmm12, [rsp]
00007fb1689d70e8  add rsp, 0x30
00007fb1689d70ec  vmovaps xmm0, [rsp]
00007fb1689d70f1  vmovaps xmm1, [rsp+0x10]
00007fb1689d70f7  vmovaps xmm2, [rsp+0x20]
00007fb1689d70fd  vmovaps xmm3, [rsp+0x30]
00007fb1689d7103  vmovaps xmm4, [rsp+0x40]
00007fb1689d7109  vmovaps xmm5, [rsp+0x50]
00007fb1689d710f  vmovaps xmm6, [rsp+0x60]
00007fb1689d7115  vmovaps xmm7, [rsp+0x70]
00007fb1689d711b  vmovaps xmm8, [rsp+0x80]
00007fb1689d7124  vmovaps xmm9, [rsp+0x90]
00007fb1689d712d  vmovaps xmm10, [rsp+0xA0]
00007fb1689d7136  vmovaps xmm11, [rsp+0xB0]
00007fb1689d713f  vmovaps xmm13, [rsp+0xC0]
00007fb1689d7148  vmovaps xmm14, [rsp+0xD0]
00007fb1689d7151  vmovaps xmm15, [rsp+0xE0]
00007fb1689d715a  add rsp, 0xF0
00007fb1689d7161  pop r11
00007fb1689d7163  pop r10
00007fb1689d7165  pop r9
00007fb1689d7167  pop r8
00007fb1689d7169  pop rsi
00007fb1689d716a  pop rdi
00007fb1689d716b  pop rdx
00007fb1689d716c  pop rcx
00007fb1689d716d  pop rax
00007fb1689d716e  add rsp, 0x08
00007fb1689d7172  jmp 0x00007FB1689D32A9
00007fb1689d7177  sub rsp, 0x08
00007fb1689d717b  push rax
00007fb1689d717c  push rcx
00007fb1689d717d  push rdx
00007fb1689d717e  push rdi
00007fb1689d717f  push rsi
00007fb1689d7180  push r8
00007fb1689d7182  push r9
00007fb1689d7184  push r10
00007fb1689d7186  push r11
00007fb1689d7188  sub rsp, 0xF0
00007fb1689d718f  vmovaps [rsp], xmm0
00007fb1689d7194  vmovaps [rsp+0x10], xmm1
00007fb1689d719a  vmovaps [rsp+0x20], xmm2
00007fb1689d71a0  vmovaps [rsp+0x30], xmm3
00007fb1689d71a6  vmovaps [rsp+0x40], xmm4
00007fb1689d71ac  vmovaps [rsp+0x50], xmm5
00007fb1689d71b2  vmovaps [rsp+0x60], xmm6
00007fb1689d71b8  vmovaps [rsp+0x70], xmm7
00007fb1689d71be  vmovaps [rsp+0x80], xmm9
00007fb1689d71c7  vmovaps [rsp+0x90], xmm10
00007fb1689d71d0  vmovaps [rsp+0xA0], xmm11
00007fb1689d71d9  vmovaps [rsp+0xB0], xmm12
00007fb1689d71e2  vmovaps [rsp+0xC0], xmm13
00007fb1689d71eb  vmovaps [rsp+0xD0], xmm14
00007fb1689d71f4  vmovaps [rsp+0xE0], xmm15
00007fb1689d71fd  sub rsp, 0x30
00007fb1689d7201  movaps [rsp], xmm8
00007fb1689d7206  movaps [rsp+0x10], xmm7
00007fb1689d720b  movaps [rsp+0x20], xmm15
00007fb1689d7211  lea rdi, [rsp]
00007fb1689d7215  mov esi, 0x00
00007fb1689d721a  mov rax, 0x57CCFD419530
00007fb1689d7224  call rax
00007fb1689d7226  movaps xmm8, [rsp]
00007fb1689d722b  add rsp, 0x30
00007fb1689d722f  vmovaps xmm0, [rsp]
00007fb1689d7234  vmovaps xmm1, [rsp+0x10]
00007fb1689d723a  vmovaps xmm2, [rsp+0x20]
00007fb1689d7240  vmovaps xmm3, [rsp+0x30]
00007fb1689d7246  vmovaps xmm4, [rsp+0x40]
00007fb1689d724c  vmovaps xmm5, [rsp+0x50]
00007fb1689d7252  vmovaps xmm6, [rsp+0x60]
00007fb1689d7258  vmovaps xmm7, [rsp+0x70]
00007fb1689d725e  vmovaps xmm9, [rsp+0x80]
00007fb1689d7267  vmovaps xmm10, [rsp+0x90]
00007fb1689d7270  vmovaps xmm11, [rsp+0xA0]
00007fb1689d7279  vmovaps xmm12, [rsp+0xB0]
00007fb1689d7282  vmovaps xmm13, [rsp+0xC0]
00007fb1689d728b  vmovaps xmm14, [rsp+0xD0]
00007fb1689d7294  vmovaps xmm15, [rsp+0xE0]
00007fb1689d729d  add rsp, 0xF0
00007fb1689d72a4  pop r11
00007fb1689d72a6  pop r10
00007fb1689d72a8  pop r9
00007fb1689d72aa  pop r8
00007fb1689d72ac  pop rsi
00007fb1689d72ad  pop rdi
00007fb1689d72ae  pop rdx
00007fb1689d72af  pop rcx
00007fb1689d72b0  pop rax
00007fb1689d72b1  add rsp, 0x08
00007fb1689d72b5  jmp 0x00007FB1689D32CF
00007fb1689d72ba  sub rsp, 0x08
00007fb1689d72be  push rax
00007fb1689d72bf  push rcx
00007fb1689d72c0  push rdx
00007fb1689d72c1  push rdi
00007fb1689d72c2  push rsi
00007fb1689d72c3  push r8
00007fb1689d72c5  push r9
00007fb1689d72c7  push r10
00007fb1689d72c9  push r11
00007fb1689d72cb  sub rsp, 0xF0
00007fb1689d72d2  vmovaps [rsp], xmm0
00007fb1689d72d7  vmovaps [rsp+0x10], xmm1
00007fb1689d72dd  vmovaps [rsp+0x20], xmm2
00007fb1689d72e3  vmovaps [rsp+0x30], xmm3
00007fb1689d72e9  vmovaps [rsp+0x40], xmm4
00007fb1689d72ef  vmovaps [rsp+0x50], xmm5
00007fb1689d72f5  vmovaps [rsp+0x60], xmm6
00007fb1689d72fb  vmovaps [rsp+0x70], xmm7
00007fb1689d7301  vmovaps [rsp+0x80], xmm8
00007fb1689d730a  vmovaps [rsp+0x90], xmm9
00007fb1689d7313  vmovaps [rsp+0xA0], xmm10
00007fb1689d731c  vmovaps [rsp+0xB0], xmm11
00007fb1689d7325  vmovaps [rsp+0xC0], xmm12
00007fb1689d732e  vmovaps [rsp+0xD0], xmm13
00007fb1689d7337  vmovaps [rsp+0xE0], xmm14
00007fb1689d7340  sub rsp, 0x30
00007fb1689d7344  movaps [rsp], xmm15
00007fb1689d7349  movaps [rsp+0x10], xmm14
00007fb1689d734f  movaps [rsp+0x20], xmm9
00007fb1689d7355  lea rdi, [rsp]
00007fb1689d7359  mov esi, 0x00
00007fb1689d735e  mov rax, 0x57CCFD419530
00007fb1689d7368  call rax
00007fb1689d736a  movaps xmm15, [rsp]
00007fb1689d736f  add rsp, 0x30
00007fb1689d7373  vmovaps xmm0, [rsp]
00007fb1689d7378  vmovaps xmm1, [rsp+0x10]
00007fb1689d737e  vmovaps xmm2, [rsp+0x20]
00007fb1689d7384  vmovaps xmm3, [rsp+0x30]
00007fb1689d738a  vmovaps xmm4, [rsp+0x40]
00007fb1689d7390  vmovaps xmm5, [rsp+0x50]
00007fb1689d7396  vmovaps xmm6, [rsp+0x60]
00007fb1689d739c  vmovaps xmm7, [rsp+0x70]
00007fb1689d73a2  vmovaps xmm8, [rsp+0x80]
00007fb1689d73ab  vmovaps xmm9, [rsp+0x90]
00007fb1689d73b4  vmovaps xmm10, [rsp+0xA0]
00007fb1689d73bd  vmovaps xmm11, [rsp+0xB0]
00007fb1689d73c6  vmovaps xmm12, [rsp+0xC0]
00007fb1689d73cf  vmovaps xmm13, [rsp+0xD0]
00007fb1689d73d8  vmovaps xmm14, [rsp+0xE0]
00007fb1689d73e1  add rsp, 0xF0
00007fb1689d73e8  pop r11
00007fb1689d73ea  pop r10
00007fb1689d73ec  pop r9
00007fb1689d73ee  pop r8
00007fb1689d73f0  pop rsi
00007fb1689d73f1  pop rdi
00007fb1689d73f2  pop rdx
00007fb1689d73f3  pop rcx
00007fb1689d73f4  pop rax
00007fb1689d73f5  add rsp, 0x08
00007fb1689d73f9  jmp 0x00007FB1689D32E9
00007fb1689d73fe  sub rsp, 0x08
00007fb1689d7402  push rax
00007fb1689d7403  push rcx
00007fb1689d7404  push rdx
00007fb1689d7405  push rdi
00007fb1689d7406  push rsi
00007fb1689d7407  push r8
00007fb1689d7409  push r9
00007fb1689d740b  push r10
00007fb1689d740d  push r11
00007fb1689d740f  sub rsp, 0xF0
00007fb1689d7416  vmovaps [rsp], xmm0
00007fb1689d741b  vmovaps [rsp+0x10], xmm1
00007fb1689d7421  vmovaps [rsp+0x20], xmm2
00007fb1689d7427  vmovaps [rsp+0x30], xmm3
00007fb1689d742d  vmovaps [rsp+0x40], xmm4
00007fb1689d7433  vmovaps [rsp+0x50], xmm5
00007fb1689d7439  vmovaps [rsp+0x60], xmm6
00007fb1689d743f  vmovaps [rsp+0x70], xmm7
00007fb1689d7445  vmovaps [rsp+0x80], xmm8
00007fb1689d744e  vmovaps [rsp+0x90], xmm10
00007fb1689d7457  vmovaps [rsp+0xA0], xmm11
00007fb1689d7460  vmovaps [rsp+0xB0], xmm12
00007fb1689d7469  vmovaps [rsp+0xC0], xmm13
00007fb1689d7472  vmovaps [rsp+0xD0], xmm14
00007fb1689d747b  vmovaps [rsp+0xE0], xmm15
00007fb1689d7484  sub rsp, 0x30
00007fb1689d7488  movaps [rsp], xmm9
00007fb1689d748d  movaps [rsp+0x10], xmm7
00007fb1689d7492  movaps [rsp+0x20], xmm14
00007fb1689d7498  lea rdi, [rsp]
00007fb1689d749c  mov esi, 0x00
00007fb1689d74a1  mov rax, 0x57CCFD419530
00007fb1689d74ab  call rax
00007fb1689d74ad  movaps xmm9, [rsp]
00007fb1689d74b2  add rsp, 0x30
00007fb1689d74b6  vmovaps xmm0, [rsp]
00007fb1689d74bb  vmovaps xmm1, [rsp+0x10]
00007fb1689d74c1  vmovaps xmm2, [rsp+0x20]
00007fb1689d74c7  vmovaps xmm3, [rsp+0x30]
00007fb1689d74cd  vmovaps xmm4, [rsp+0x40]
00007fb1689d74d3  vmovaps xmm5, [rsp+0x50]
00007fb1689d74d9  vmovaps xmm6, [rsp+0x60]
00007fb1689d74df  vmovaps xmm7, [rsp+0x70]
00007fb1689d74e5  vmovaps xmm8, [rsp+0x80]
00007fb1689d74ee  vmovaps xmm10, [rsp+0x90]
00007fb1689d74f7  vmovaps xmm11, [rsp+0xA0]
00007fb1689d7500  vmovaps xmm12, [rsp+0xB0]
00007fb1689d7509  vmovaps xmm13, [rsp+0xC0]
00007fb1689d7512  vmovaps xmm14, [rsp+0xD0]
00007fb1689d751b  vmovaps xmm15, [rsp+0xE0]
00007fb1689d7524  add rsp, 0xF0
00007fb1689d752b  pop r11
00007fb1689d752d  pop r10
00007fb1689d752f  pop r9
00007fb1689d7531  pop r8
00007fb1689d7533  pop rsi
00007fb1689d7534  pop rdi
00007fb1689d7535  pop rdx
00007fb1689d7536  pop rcx
00007fb1689d7537  pop rax
00007fb1689d7538  add rsp, 0x08
00007fb1689d753c  jmp 0x00007FB1689D3318
00007fb1689d7541  sub rsp, 0x08
00007fb1689d7545  push rax
00007fb1689d7546  push rcx
00007fb1689d7547  push rdx
00007fb1689d7548  push rdi
00007fb1689d7549  push rsi
00007fb1689d754a  push r8
00007fb1689d754c  push r9
00007fb1689d754e  push r10
00007fb1689d7550  push r11
00007fb1689d7552  sub rsp, 0xF0
00007fb1689d7559  vmovaps [rsp], xmm0
00007fb1689d755e  vmovaps [rsp+0x10], xmm1
00007fb1689d7564  vmovaps [rsp+0x20], xmm2
00007fb1689d756a  vmovaps [rsp+0x30], xmm3
00007fb1689d7570  vmovaps [rsp+0x40], xmm4
00007fb1689d7576  vmovaps [rsp+0x50], xmm5
00007fb1689d757c  vmovaps [rsp+0x60], xmm6
00007fb1689d7582  vmovaps [rsp+0x70], xmm7
00007fb1689d7588  vmovaps [rsp+0x80], xmm8
00007fb1689d7591  vmovaps [rsp+0x90], xmm9
00007fb1689d759a  vmovaps [rsp+0xA0], xmm10
00007fb1689d75a3  vmovaps [rsp+0xB0], xmm11
00007fb1689d75ac  vmovaps [rsp+0xC0], xmm12
00007fb1689d75b5  vmovaps [rsp+0xD0], xmm13
00007fb1689d75be  vmovaps [rsp+0xE0], xmm15
00007fb1689d75c7  sub rsp, 0x30
00007fb1689d75cb  movaps [rsp], xmm14
00007fb1689d75d0  movaps [rsp+0x10], xmm13
00007fb1689d75d6  movaps [rsp+0x20], xmm11
00007fb1689d75dc  lea rdi, [rsp]
00007fb1689d75e0  mov esi, 0x00
00007fb1689d75e5  mov rax, 0x57CCFD419530
00007fb1689d75ef  call rax
00007fb1689d75f1  movaps xmm14, [rsp]
00007fb1689d75f6  add rsp, 0x30
00007fb1689d75fa  vmovaps xmm0, [rsp]
00007fb1689d75ff  vmovaps xmm1, [rsp+0x10]
00007fb1689d7605  vmovaps xmm2, [rsp+0x20]
00007fb1689d760b  vmovaps xmm3, [rsp+0x30]
00007fb1689d7611  vmovaps xmm4, [rsp+0x40]
00007fb1689d7617  vmovaps xmm5, [rsp+0x50]
00007fb1689d761d  vmovaps xmm6, [rsp+0x60]
00007fb1689d7623  vmovaps xmm7, [rsp+0x70]
00007fb1689d7629  vmovaps xmm8, [rsp+0x80]
00007fb1689d7632  vmovaps xmm9, [rsp+0x90]
00007fb1689d763b  vmovaps xmm10, [rsp+0xA0]
00007fb1689d7644  vmovaps xmm11, [rsp+0xB0]
00007fb1689d764d  vmovaps xmm12, [rsp+0xC0]
00007fb1689d7656  vmovaps xmm13, [rsp+0xD0]
00007fb1689d765f  vmovaps xmm15, [rsp+0xE0]
00007fb1689d7668  add rsp, 0xF0
00007fb1689d766f  pop r11
00007fb1689d7671  pop r10
00007fb1689d7673  pop r9
00007fb1689d7675  pop r8
00007fb1689d7677  pop rsi
00007fb1689d7678  pop rdi
00007fb1689d7679  pop rdx
00007fb1689d767a  pop rcx
00007fb1689d767b  pop rax
00007fb1689d767c  add rsp, 0x08
00007fb1689d7680  jmp 0x00007FB1689D3332
00007fb1689d7685  sub rsp, 0x08
00007fb1689d7689  push rax
00007fb1689d768a  push rcx
00007fb1689d768b  push rdx
00007fb1689d768c  push rdi
00007fb1689d768d  push rsi
00007fb1689d768e  push r8
00007fb1689d7690  push r9
00007fb1689d7692  push r10
00007fb1689d7694  push r11
00007fb1689d7696  sub rsp, 0xF0
00007fb1689d769d  vmovaps [rsp], xmm0
00007fb1689d76a2  vmovaps [rsp+0x10], xmm1
00007fb1689d76a8  vmovaps [rsp+0x20], xmm2
00007fb1689d76ae  vmovaps [rsp+0x30], xmm3
00007fb1689d76b4  vmovaps [rsp+0x40], xmm4
00007fb1689d76ba  vmovaps [rsp+0x50], xmm5
00007fb1689d76c0  vmovaps [rsp+0x60], xmm6
00007fb1689d76c6  vmovaps [rsp+0x70], xmm7
00007fb1689d76cc  vmovaps [rsp+0x80], xmm8
00007fb1689d76d5  vmovaps [rsp+0x90], xmm9
00007fb1689d76de  vmovaps [rsp+0xA0], xmm10
00007fb1689d76e7  vmovaps [rsp+0xB0], xmm12
00007fb1689d76f0  vmovaps [rsp+0xC0], xmm13
00007fb1689d76f9  vmovaps [rsp+0xD0], xmm14
00007fb1689d7702  vmovaps [rsp+0xE0], xmm15
00007fb1689d770b  sub rsp, 0x30
00007fb1689d770f  movaps [rsp], xmm11
00007fb1689d7714  movaps [rsp+0x10], xmm7
00007fb1689d7719  movaps [rsp+0x20], xmm13
00007fb1689d771f  lea rdi, [rsp]
00007fb1689d7723  mov esi, 0x00
00007fb1689d7728  mov rax, 0x57CCFD419530
00007fb1689d7732  call rax
00007fb1689d7734  movaps xmm11, [rsp]
00007fb1689d7739  add rsp, 0x30
00007fb1689d773d  vmovaps xmm0, [rsp]
00007fb1689d7742  vmovaps xmm1, [rsp+0x10]
00007fb1689d7748  vmovaps xmm2, [rsp+0x20]
00007fb1689d774e  vmovaps xmm3, [rsp+0x30]
00007fb1689d7754  vmovaps xmm4, [rsp+0x40]
00007fb1689d775a  vmovaps xmm5, [rsp+0x50]
00007fb1689d7760  vmovaps xmm6, [rsp+0x60]
00007fb1689d7766  vmovaps xmm7, [rsp+0x70]
00007fb1689d776c  vmovaps xmm8, [rsp+0x80]
00007fb1689d7775  vmovaps xmm9, [rsp+0x90]
00007fb1689d777e  vmovaps xmm10, [rsp+0xA0]
00007fb1689d7787  vmovaps xmm12, [rsp+0xB0]
00007fb1689d7790  vmovaps xmm13, [rsp+0xC0]
00007fb1689d7799  vmovaps xmm14, [rsp+0xD0]
00007fb1689d77a2  vmovaps xmm15, [rsp+0xE0]
00007fb1689d77ab  add rsp, 0xF0
00007fb1689d77b2  pop r11
00007fb1689d77b4  pop r10
00007fb1689d77b6  pop r9
00007fb1689d77b8  pop r8
00007fb1689d77ba  pop rsi
00007fb1689d77bb  pop rdi
00007fb1689d77bc  pop rdx
00007fb1689d77bd  pop rcx
00007fb1689d77be  pop rax
00007fb1689d77bf  add rsp, 0x08
00007fb1689d77c3  jmp 0x00007FB1689D335E
00007fb1689d77c8  sub rsp, 0x08
00007fb1689d77cc  push rax
00007fb1689d77cd  push rcx
00007fb1689d77ce  push rdx
00007fb1689d77cf  push rdi
00007fb1689d77d0  push rsi
00007fb1689d77d1  push r8
00007fb1689d77d3  push r9
00007fb1689d77d5  push r10
00007fb1689d77d7  push r11
00007fb1689d77d9  sub rsp, 0xF0
00007fb1689d77e0  vmovaps [rsp], xmm0
00007fb1689d77e5  vmovaps [rsp+0x10], xmm1
00007fb1689d77eb  vmovaps [rsp+0x20], xmm2
00007fb1689d77f1  vmovaps [rsp+0x30], xmm3
00007fb1689d77f7  vmovaps [rsp+0x40], xmm4
00007fb1689d77fd  vmovaps [rsp+0x50], xmm5
00007fb1689d7803  vmovaps [rsp+0x60], xmm6
00007fb1689d7809  vmovaps [rsp+0x70], xmm7
00007fb1689d780f  vmovaps [rsp+0x80], xmm8
00007fb1689d7818  vmovaps [rsp+0x90], xmm9
00007fb1689d7821  vmovaps [rsp+0xA0], xmm10
00007fb1689d782a  vmovaps [rsp+0xB0], xmm11
00007fb1689d7833  vmovaps [rsp+0xC0], xmm12
00007fb1689d783c  vmovaps [rsp+0xD0], xmm14
00007fb1689d7845  vmovaps [rsp+0xE0], xmm15
00007fb1689d784e  sub rsp, 0x30
00007fb1689d7852  movaps [rsp], xmm13
00007fb1689d7857  movaps [rsp+0x10], xmm10
00007fb1689d785d  movaps [rsp+0x20], xmm12
00007fb1689d7863  lea rdi, [rsp]
00007fb1689d7867  mov esi, 0x00
00007fb1689d786c  mov rax, 0x57CCFD419530
00007fb1689d7876  call rax
00007fb1689d7878  movaps xmm13, [rsp]
00007fb1689d787d  add rsp, 0x30
00007fb1689d7881  vmovaps xmm0, [rsp]
00007fb1689d7886  vmovaps xmm1, [rsp+0x10]
00007fb1689d788c  vmovaps xmm2, [rsp+0x20]
00007fb1689d7892  vmovaps xmm3, [rsp+0x30]
00007fb1689d7898  vmovaps xmm4, [rsp+0x40]
00007fb1689d789e  vmovaps xmm5, [rsp+0x50]
00007fb1689d78a4  vmovaps xmm6, [rsp+0x60]
00007fb1689d78aa  vmovaps xmm7, [rsp+0x70]
00007fb1689d78b0  vmovaps xmm8, [rsp+0x80]
00007fb1689d78b9  vmovaps xmm9, [rsp+0x90]
00007fb1689d78c2  vmovaps xmm10, [rsp+0xA0]
00007fb1689d78cb  vmovaps xmm11, [rsp+0xB0]
00007fb1689d78d4  vmovaps xmm12, [rsp+0xC0]
00007fb1689d78dd  vmovaps xmm14, [rsp+0xD0]
00007fb1689d78e6  vmovaps xmm15, [rsp+0xE0]
00007fb1689d78ef  add rsp, 0xF0
00007fb1689d78f6  pop r11
00007fb1689d78f8  pop r10
00007fb1689d78fa  pop r9
00007fb1689d78fc  pop r8
00007fb1689d78fe  pop rsi
00007fb1689d78ff  pop rdi
00007fb1689d7900  pop rdx
00007fb1689d7901  pop rcx
00007fb1689d7902  pop rax
00007fb1689d7903  add rsp, 0x08
00007fb1689d7907  jmp 0x00007FB1689D3378
00007fb1689d790c  sub rsp, 0x08
00007fb1689d7910  push rax
00007fb1689d7911  push rcx
00007fb1689d7912  push rdx
00007fb1689d7913  push rdi
00007fb1689d7914  push rsi
00007fb1689d7915  push r8
00007fb1689d7917  push r9
00007fb1689d7919  push r10
00007fb1689d791b  push r11
00007fb1689d791d  sub rsp, 0xF0
00007fb1689d7924  vmovaps [rsp], xmm0
00007fb1689d7929  vmovaps [rsp+0x10], xmm1
00007fb1689d792f  vmovaps [rsp+0x20], xmm2
00007fb1689d7935  vmovaps [rsp+0x30], xmm3
00007fb1689d793b  vmovaps [rsp+0x40], xmm4
00007fb1689d7941  vmovaps [rsp+0x50], xmm5
00007fb1689d7947  vmovaps [rsp+0x60], xmm6
00007fb1689d794d  vmovaps [rsp+0x70], xmm7
00007fb1689d7953  vmovaps [rsp+0x80], xmm8
00007fb1689d795c  vmovaps [rsp+0x90], xmm9
00007fb1689d7965  vmovaps [rsp+0xA0], xmm11
00007fb1689d796e  vmovaps [rsp+0xB0], xmm12
00007fb1689d7977  vmovaps [rsp+0xC0], xmm13
00007fb1689d7980  vmovaps [rsp+0xD0], xmm14
00007fb1689d7989  vmovaps [rsp+0xE0], xmm15
00007fb1689d7992  sub rsp, 0x30
00007fb1689d7996  movaps [rsp], xmm10
00007fb1689d799b  movaps [rsp+0x10], xmm7
00007fb1689d79a0  movaps [rsp+0x20], xmm12
00007fb1689d79a6  lea rdi, [rsp]
00007fb1689d79aa  mov esi, 0x00
00007fb1689d79af  mov rax, 0x57CCFD419530
00007fb1689d79b9  call rax
00007fb1689d79bb  movaps xmm10, [rsp]
00007fb1689d79c0  add rsp, 0x30
00007fb1689d79c4  vmovaps xmm0, [rsp]
00007fb1689d79c9  vmovaps xmm1, [rsp+0x10]
00007fb1689d79cf  vmovaps xmm2, [rsp+0x20]
00007fb1689d79d5  vmovaps xmm3, [rsp+0x30]
00007fb1689d79db  vmovaps xmm4, [rsp+0x40]
00007fb1689d79e1  vmovaps xmm5, [rsp+0x50]
00007fb1689d79e7  vmovaps xmm6, [rsp+0x60]
00007fb1689d79ed  vmovaps xmm7, [rsp+0x70]
00007fb1689d79f3  vmovaps xmm8, [rsp+0x80]
00007fb1689d79fc  vmovaps xmm9, [rsp+0x90]
00007fb1689d7a05  vmovaps xmm11, [rsp+0xA0]
00007fb1689d7a0e  vmovaps xmm12, [rsp+0xB0]
00007fb1689d7a17  vmovaps xmm13, [rsp+0xC0]
00007fb1689d7a20  vmovaps xmm14, [rsp+0xD0]
00007fb1689d7a29  vmovaps xmm15, [rsp+0xE0]
00007fb1689d7a32  add rsp, 0xF0
00007fb1689d7a39  pop r11
00007fb1689d7a3b  pop r10
00007fb1689d7a3d  pop r9
00007fb1689d7a3f  pop r8
00007fb1689d7a41  pop rsi
00007fb1689d7a42  pop rdi
00007fb1689d7a43  pop rdx
00007fb1689d7a44  pop rcx
00007fb1689d7a45  pop rax
00007fb1689d7a46  add rsp, 0x08
00007fb1689d7a4a  jmp 0x00007FB1689D33A4
00007fb1689d7a4f  sub rsp, 0x08
00007fb1689d7a53  push rax
00007fb1689d7a54  push rcx
00007fb1689d7a55  push rdx
00007fb1689d7a56  push rdi
00007fb1689d7a57  push rsi
00007fb1689d7a58  push r8
00007fb1689d7a5a  push r9
00007fb1689d7a5c  push r10
00007fb1689d7a5e  push r11
00007fb1689d7a60  sub rsp, 0xF0
00007fb1689d7a67  vmovaps [rsp], xmm0
00007fb1689d7a6c  vmovaps [rsp+0x10], xmm1
00007fb1689d7a72  vmovaps [rsp+0x20], xmm2
00007fb1689d7a78  vmovaps [rsp+0x30], xmm3
00007fb1689d7a7e  vmovaps [rsp+0x40], xmm4
00007fb1689d7a84  vmovaps [rsp+0x50], xmm5
00007fb1689d7a8a  vmovaps [rsp+0x60], xmm6
00007fb1689d7a90  vmovaps [rsp+0x70], xmm7
00007fb1689d7a96  vmovaps [rsp+0x80], xmm8
00007fb1689d7a9f  vmovaps [rsp+0x90], xmm9
00007fb1689d7aa8  vmovaps [rsp+0xA0], xmm10
00007fb1689d7ab1  vmovaps [rsp+0xB0], xmm11
00007fb1689d7aba  vmovaps [rsp+0xC0], xmm13
00007fb1689d7ac3  vmovaps [rsp+0xD0], xmm14
00007fb1689d7acc  vmovaps [rsp+0xE0], xmm15
00007fb1689d7ad5  sub rsp, 0x30
00007fb1689d7ad9  movaps [rsp], xmm12
00007fb1689d7ade  movaps [rsp+0x10], xmm1
00007fb1689d7ae3  movaps [rsp+0x20], xmm8
00007fb1689d7ae9  lea rdi, [rsp]
00007fb1689d7aed  mov esi, 0x00
00007fb1689d7af2  mov rax, 0x57CCFD419530
00007fb1689d7afc  call rax
00007fb1689d7afe  movaps xmm12, [rsp]
00007fb1689d7b03  add rsp, 0x30
00007fb1689d7b07  vmovaps xmm0, [rsp]
00007fb1689d7b0c  vmovaps xmm1, [rsp+0x10]
00007fb1689d7b12  vmovaps xmm2, [rsp+0x20]
00007fb1689d7b18  vmovaps xmm3, [rsp+0x30]
00007fb1689d7b1e  vmovaps xmm4, [rsp+0x40]
00007fb1689d7b24  vmovaps xmm5, [rsp+0x50]
00007fb1689d7b2a  vmovaps xmm6, [rsp+0x60]
00007fb1689d7b30  vmovaps xmm7, [rsp+0x70]
00007fb1689d7b36  vmovaps xmm8, [rsp+0x80]
00007fb1689d7b3f  vmovaps xmm9, [rsp+0x90]
00007fb1689d7b48  vmovaps xmm10, [rsp+0xA0]
00007fb1689d7b51  vmovaps xmm11, [rsp+0xB0]
00007fb1689d7b5a  vmovaps xmm13, [rsp+0xC0]
00007fb1689d7b63  vmovaps xmm14, [rsp+0xD0]
00007fb1689d7b6c  vmovaps xmm15, [rsp+0xE0]
00007fb1689d7b75  add rsp, 0xF0
00007fb1689d7b7c  pop r11
00007fb1689d7b7e  pop r10
00007fb1689d7b80  pop r9
00007fb1689d7b82  pop r8
00007fb1689d7b84  pop rsi
00007fb1689d7b85  pop rdi
00007fb1689d7b86  pop rdx
00007fb1689d7b87  pop rcx
00007fb1689d7b88  pop rax
00007fb1689d7b89  add rsp, 0x08
00007fb1689d7b8d  jmp 0x00007FB1689D33BE
00007fb1689d7b92  call 0x00007FB1687FF430
00007fb1689d7b97  jmp 0x00007FB1689D33C8
00007fb1689d7b9c  sub rsp, 0x08
00007fb1689d7ba0  push rax
00007fb1689d7ba1  push rcx
00007fb1689d7ba2  push rdx
00007fb1689d7ba3  push rdi
00007fb1689d7ba4  push rsi
00007fb1689d7ba5  push r8
00007fb1689d7ba7  push r9
00007fb1689d7ba9  push r10
00007fb1689d7bab  push r11
00007fb1689d7bad  sub rsp, 0xF0
00007fb1689d7bb4  vmovaps [rsp], xmm0
00007fb1689d7bb9  vmovaps [rsp+0x10], xmm1
00007fb1689d7bbf  vmovaps [rsp+0x20], xmm2
00007fb1689d7bc5  vmovaps [rsp+0x30], xmm3
00007fb1689d7bcb  vmovaps [rsp+0x40], xmm4
00007fb1689d7bd1  vmovaps [rsp+0x50], xmm5
00007fb1689d7bd7  vmovaps [rsp+0x60], xmm6
00007fb1689d7bdd  vmovaps [rsp+0x70], xmm7
00007fb1689d7be3  vmovaps [rsp+0x80], xmm9
00007fb1689d7bec  vmovaps [rsp+0x90], xmm10
00007fb1689d7bf5  vmovaps [rsp+0xA0], xmm11
00007fb1689d7bfe  vmovaps [rsp+0xB0], xmm12
00007fb1689d7c07  vmovaps [rsp+0xC0], xmm13
00007fb1689d7c10  vmovaps [rsp+0xD0], xmm14
00007fb1689d7c19  vmovaps [rsp+0xE0], xmm15
00007fb1689d7c22  sub rsp, 0x30
00007fb1689d7c26  movaps [rsp], xmm8
00007fb1689d7c2b  movaps [rsp+0x10], xmm15
00007fb1689d7c31  movaps [rsp+0x20], xmm9
00007fb1689d7c37  lea rdi, [rsp]
00007fb1689d7c3b  mov esi, 0x00
00007fb1689d7c40  mov rax, 0x57CCFD419530
00007fb1689d7c4a  call rax
00007fb1689d7c4c  movaps xmm8, [rsp]
00007fb1689d7c51  add rsp, 0x30
00007fb1689d7c55  vmovaps xmm0, [rsp]
00007fb1689d7c5a  vmovaps xmm1, [rsp+0x10]
00007fb1689d7c60  vmovaps xmm2, [rsp+0x20]
00007fb1689d7c66  vmovaps xmm3, [rsp+0x30]
00007fb1689d7c6c  vmovaps xmm4, [rsp+0x40]
00007fb1689d7c72  vmovaps xmm5, [rsp+0x50]
00007fb1689d7c78  vmovaps xmm6, [rsp+0x60]
00007fb1689d7c7e  vmovaps xmm7, [rsp+0x70]
00007fb1689d7c84  vmovaps xmm9, [rsp+0x80]
00007fb1689d7c8d  vmovaps xmm10, [rsp+0x90]
00007fb1689d7c96  vmovaps xmm11, [rsp+0xA0]
00007fb1689d7c9f  vmovaps xmm12, [rsp+0xB0]
00007fb1689d7ca8  vmovaps xmm13, [rsp+0xC0]
00007fb1689d7cb1  vmovaps xmm14, [rsp+0xD0]
00007fb1689d7cba  vmovaps xmm15, [rsp+0xE0]
00007fb1689d7cc3  add rsp, 0xF0
00007fb1689d7cca  pop r11
00007fb1689d7ccc  pop r10
00007fb1689d7cce  pop r9
00007fb1689d7cd0  pop r8
00007fb1689d7cd2  pop rsi
00007fb1689d7cd3  pop rdi
00007fb1689d7cd4  pop rdx
00007fb1689d7cd5  pop rcx
00007fb1689d7cd6  pop rax
00007fb1689d7cd7  add rsp, 0x08
00007fb1689d7cdb  jmp 0x00007FB1689D33EA
00007fb1689d7ce0  sub rsp, 0x08
00007fb1689d7ce4  push rax
00007fb1689d7ce5  push rcx
00007fb1689d7ce6  push rdx
00007fb1689d7ce7  push rdi
00007fb1689d7ce8  push rsi
00007fb1689d7ce9  push r8
00007fb1689d7ceb  push r9
00007fb1689d7ced  push r10
00007fb1689d7cef  push r11
00007fb1689d7cf1  sub rsp, 0xF0
00007fb1689d7cf8  vmovaps [rsp], xmm0
00007fb1689d7cfd  vmovaps [rsp+0x10], xmm1
00007fb1689d7d03  vmovaps [rsp+0x20], xmm2
00007fb1689d7d09  vmovaps [rsp+0x30], xmm3
00007fb1689d7d0f  vmovaps [rsp+0x40], xmm4
00007fb1689d7d15  vmovaps [rsp+0x50], xmm5
00007fb1689d7d1b  vmovaps [rsp+0x60], xmm6
00007fb1689d7d21  vmovaps [rsp+0x70], xmm7
00007fb1689d7d27  vmovaps [rsp+0x80], xmm8
00007fb1689d7d30  vmovaps [rsp+0x90], xmm10
00007fb1689d7d39  vmovaps [rsp+0xA0], xmm11
00007fb1689d7d42  vmovaps [rsp+0xB0], xmm12
00007fb1689d7d4b  vmovaps [rsp+0xC0], xmm13
00007fb1689d7d54  vmovaps [rsp+0xD0], xmm14
00007fb1689d7d5d  vmovaps [rsp+0xE0], xmm15
00007fb1689d7d66  sub rsp, 0x30
00007fb1689d7d6a  movaps [rsp], xmm9
00007fb1689d7d6f  movaps [rsp+0x10], xmm1
00007fb1689d7d74  movaps [rsp+0x20], xmm15
00007fb1689d7d7a  lea rdi, [rsp]
00007fb1689d7d7e  mov esi, 0x00
00007fb1689d7d83  mov rax, 0x57CCFD419530
00007fb1689d7d8d  call rax
00007fb1689d7d8f  movaps xmm9, [rsp]
00007fb1689d7d94  add rsp, 0x30
00007fb1689d7d98  vmovaps xmm0, [rsp]
00007fb1689d7d9d  vmovaps xmm1, [rsp+0x10]
00007fb1689d7da3  vmovaps xmm2, [rsp+0x20]
00007fb1689d7da9  vmovaps xmm3, [rsp+0x30]
00007fb1689d7daf  vmovaps xmm4, [rsp+0x40]
00007fb1689d7db5  vmovaps xmm5, [rsp+0x50]
00007fb1689d7dbb  vmovaps xmm6, [rsp+0x60]
00007fb1689d7dc1  vmovaps xmm7, [rsp+0x70]
00007fb1689d7dc7  vmovaps xmm8, [rsp+0x80]
00007fb1689d7dd0  vmovaps xmm10, [rsp+0x90]
00007fb1689d7dd9  vmovaps xmm11, [rsp+0xA0]
00007fb1689d7de2  vmovaps xmm12, [rsp+0xB0]
00007fb1689d7deb  vmovaps xmm13, [rsp+0xC0]
00007fb1689d7df4  vmovaps xmm14, [rsp+0xD0]
00007fb1689d7dfd  vmovaps xmm15, [rsp+0xE0]
00007fb1689d7e06  add rsp, 0xF0
00007fb1689d7e0d  pop r11
00007fb1689d7e0f  pop r10
00007fb1689d7e11  pop r9
00007fb1689d7e13  pop r8
00007fb1689d7e15  pop rsi
00007fb1689d7e16  pop rdi
00007fb1689d7e17  pop rdx
00007fb1689d7e18  pop rcx
00007fb1689d7e19  pop rax
00007fb1689d7e1a  add rsp, 0x08
00007fb1689d7e1e  jmp 0x00007FB1689D3418
00007fb1689d7e23  sub rsp, 0x08
00007fb1689d7e27  push rax
00007fb1689d7e28  push rcx
00007fb1689d7e29  push rdx
00007fb1689d7e2a  push rdi
00007fb1689d7e2b  push rsi
00007fb1689d7e2c  push r8
00007fb1689d7e2e  push r9
00007fb1689d7e30  push r10
00007fb1689d7e32  push r11
00007fb1689d7e34  sub rsp, 0xF0
00007fb1689d7e3b  vmovaps [rsp], xmm0
00007fb1689d7e40  vmovaps [rsp+0x10], xmm1
00007fb1689d7e46  vmovaps [rsp+0x20], xmm2
00007fb1689d7e4c  vmovaps [rsp+0x30], xmm3
00007fb1689d7e52  vmovaps [rsp+0x40], xmm4
00007fb1689d7e58  vmovaps [rsp+0x50], xmm5
00007fb1689d7e5e  vmovaps [rsp+0x60], xmm6
00007fb1689d7e64  vmovaps [rsp+0x70], xmm7
00007fb1689d7e6a  vmovaps [rsp+0x80], xmm8
00007fb1689d7e73  vmovaps [rsp+0x90], xmm9
00007fb1689d7e7c  vmovaps [rsp+0xA0], xmm10
00007fb1689d7e85  vmovaps [rsp+0xB0], xmm11
00007fb1689d7e8e  vmovaps [rsp+0xC0], xmm12
00007fb1689d7e97  vmovaps [rsp+0xD0], xmm13
00007fb1689d7ea0  vmovaps [rsp+0xE0], xmm14
00007fb1689d7ea9  sub rsp, 0x30
00007fb1689d7ead  movaps [rsp], xmm15
00007fb1689d7eb2  movaps [rsp+0x10], xmm4
00007fb1689d7eb7  movaps [rsp+0x20], xmm1
00007fb1689d7ebc  lea rdi, [rsp]
00007fb1689d7ec0  mov esi, 0x00
00007fb1689d7ec5  mov rax, 0x57CCFD419530
00007fb1689d7ecf  call rax
00007fb1689d7ed1  movaps xmm15, [rsp]
00007fb1689d7ed6  add rsp, 0x30
00007fb1689d7eda  vmovaps xmm0, [rsp]
00007fb1689d7edf  vmovaps xmm1, [rsp+0x10]
00007fb1689d7ee5  vmovaps xmm2, [rsp+0x20]
00007fb1689d7eeb  vmovaps xmm3, [rsp+0x30]
00007fb1689d7ef1  vmovaps xmm4, [rsp+0x40]
00007fb1689d7ef7  vmovaps xmm5, [rsp+0x50]
00007fb1689d7efd  vmovaps xmm6, [rsp+0x60]
00007fb1689d7f03  vmovaps xmm7, [rsp+0x70]
00007fb1689d7f09  vmovaps xmm8, [rsp+0x80]
00007fb1689d7f12  vmovaps xmm9, [rsp+0x90]
00007fb1689d7f1b  vmovaps xmm10, [rsp+0xA0]
00007fb1689d7f24  vmovaps xmm11, [rsp+0xB0]
00007fb1689d7f2d  vmovaps xmm12, [rsp+0xC0]
00007fb1689d7f36  vmovaps xmm13, [rsp+0xD0]
00007fb1689d7f3f  vmovaps xmm14, [rsp+0xE0]
00007fb1689d7f48  add rsp, 0xF0
00007fb1689d7f4f  pop r11
00007fb1689d7f51  pop r10
00007fb1689d7f53  pop r9
00007fb1689d7f55  pop r8
00007fb1689d7f57  pop rsi
00007fb1689d7f58  pop rdi
00007fb1689d7f59  pop rdx
00007fb1689d7f5a  pop rcx
00007fb1689d7f5b  pop rax
00007fb1689d7f5c  add rsp, 0x08
00007fb1689d7f60  jmp 0x00007FB1689D343E
00007fb1689d7f65  sub rsp, 0x08
00007fb1689d7f69  push rax
00007fb1689d7f6a  push rcx
00007fb1689d7f6b  push rdx
00007fb1689d7f6c  push rdi
00007fb1689d7f6d  push rsi
00007fb1689d7f6e  push r8
00007fb1689d7f70  push r9
00007fb1689d7f72  push r10
00007fb1689d7f74  push r11
00007fb1689d7f76  sub rsp, 0xF0
00007fb1689d7f7d  vmovaps [rsp], xmm0
00007fb1689d7f82  vmovaps [rsp+0x10], xmm2
00007fb1689d7f88  vmovaps [rsp+0x20], xmm3
00007fb1689d7f8e  vmovaps [rsp+0x30], xmm4
00007fb1689d7f94  vmovaps [rsp+0x40], xmm5
00007fb1689d7f9a  vmovaps [rsp+0x50], xmm6
00007fb1689d7fa0  vmovaps [rsp+0x60], xmm7
00007fb1689d7fa6  vmovaps [rsp+0x70], xmm8
00007fb1689d7fac  vmovaps [rsp+0x80], xmm9
00007fb1689d7fb5  vmovaps [rsp+0x90], xmm10
00007fb1689d7fbe  vmovaps [rsp+0xA0], xmm11
00007fb1689d7fc7  vmovaps [rsp+0xB0], xmm12
00007fb1689d7fd0  vmovaps [rsp+0xC0], xmm13
00007fb1689d7fd9  vmovaps [rsp+0xD0], xmm14
00007fb1689d7fe2  vmovaps [rsp+0xE0], xmm15
00007fb1689d7feb  sub rsp, 0x30
00007fb1689d7fef  movaps [rsp], xmm1
00007fb1689d7ff3  movaps [rsp+0x10], xmm14
00007fb1689d7ff9  movaps [rsp+0x20], xmm11
00007fb1689d7fff  lea rdi, [rsp]
00007fb1689d8003  mov esi, 0x00
00007fb1689d8008  mov rax, 0x57CCFD419530
00007fb1689d8012  call rax
00007fb1689d8014  movaps xmm1, [rsp]
00007fb1689d8018  add rsp, 0x30
00007fb1689d801c  vmovaps xmm0, [rsp]
00007fb1689d8021  vmovaps xmm2, [rsp+0x10]
00007fb1689d8027  vmovaps xmm3, [rsp+0x20]
00007fb1689d802d  vmovaps xmm4, [rsp+0x30]
00007fb1689d8033  vmovaps xmm5, [rsp+0x40]
00007fb1689d8039  vmovaps xmm6, [rsp+0x50]
00007fb1689d803f  vmovaps xmm7, [rsp+0x60]
00007fb1689d8045  vmovaps xmm8, [rsp+0x70]
00007fb1689d804b  vmovaps xmm9, [rsp+0x80]
00007fb1689d8054  vmovaps xmm10, [rsp+0x90]
00007fb1689d805d  vmovaps xmm11, [rsp+0xA0]
00007fb1689d8066  vmovaps xmm12, [rsp+0xB0]
00007fb1689d806f  vmovaps xmm13, [rsp+0xC0]
00007fb1689d8078  vmovaps xmm14, [rsp+0xD0]
00007fb1689d8081  vmovaps xmm15, [rsp+0xE0]
00007fb1689d808a  add rsp, 0xF0
00007fb1689d8091  pop r11
00007fb1689d8093  pop r10
00007fb1689d8095  pop r9
00007fb1689d8097  pop r8
00007fb1689d8099  pop rsi
00007fb1689d809a  pop rdi
00007fb1689d809b  pop rdx
00007fb1689d809c  pop rcx
00007fb1689d809d  pop rax
00007fb1689d809e  add rsp, 0x08
00007fb1689d80a2  jmp 0x00007FB1689D345F
00007fb1689d80a7  call 0x00007FB1688E45A0
00007fb1689d80ac  jmp 0x00007FB1689D346D
00007fb1689d80b1  call 0x00007FB168809D70
00007fb1689d80b6  jmp 0x00007FB1689D3477
00007fb1689d80bb  sub rsp, 0x08
00007fb1689d80bf  push rax
00007fb1689d80c0  push rcx
00007fb1689d80c1  push rdx
00007fb1689d80c2  push rdi
00007fb1689d80c3  push rsi
00007fb1689d80c4  push r8
00007fb1689d80c6  push r9
00007fb1689d80c8  push r10
00007fb1689d80ca  push r11
00007fb1689d80cc  sub rsp, 0xF0
00007fb1689d80d3  vmovaps [rsp], xmm0
00007fb1689d80d8  vmovaps [rsp+0x10], xmm1
00007fb1689d80de  vmovaps [rsp+0x20], xmm2
00007fb1689d80e4  vmovaps [rsp+0x30], xmm3
00007fb1689d80ea  vmovaps [rsp+0x40], xmm4
00007fb1689d80f0  vmovaps [rsp+0x50], xmm5
00007fb1689d80f6  vmovaps [rsp+0x60], xmm6
00007fb1689d80fc  vmovaps [rsp+0x70], xmm8
00007fb1689d8102  vmovaps [rsp+0x80], xmm9
00007fb1689d810b  vmovaps [rsp+0x90], xmm10
00007fb1689d8114  vmovaps [rsp+0xA0], xmm11
00007fb1689d811d  vmovaps [rsp+0xB0], xmm12
00007fb1689d8126  vmovaps [rsp+0xC0], xmm13
00007fb1689d812f  vmovaps [rsp+0xD0], xmm14
00007fb1689d8138  vmovaps [rsp+0xE0], xmm15
00007fb1689d8141  sub rsp, 0x30
00007fb1689d8145  movaps [rsp], xmm7
00007fb1689d8149  movaps [rsp+0x10], xmm13
00007fb1689d814f  movaps [rsp+0x20], xmm10
00007fb1689d8155  lea rdi, [rsp]
00007fb1689d8159  mov esi, 0x00
00007fb1689d815e  mov rax, 0x57CCFD419530
00007fb1689d8168  call rax
00007fb1689d816a  movaps xmm7, [rsp]
00007fb1689d816e  add rsp, 0x30
00007fb1689d8172  vmovaps xmm0, [rsp]
00007fb1689d8177  vmovaps xmm1, [rsp+0x10]
00007fb1689d817d  vmovaps xmm2, [rsp+0x20]
00007fb1689d8183  vmovaps xmm3, [rsp+0x30]
00007fb1689d8189  vmovaps xmm4, [rsp+0x40]
00007fb1689d818f  vmovaps xmm5, [rsp+0x50]
00007fb1689d8195  vmovaps xmm6, [rsp+0x60]
00007fb1689d819b  vmovaps xmm8, [rsp+0x70]
00007fb1689d81a1  vmovaps xmm9, [rsp+0x80]
00007fb1689d81aa  vmovaps xmm10, [rsp+0x90]
00007fb1689d81b3  vmovaps xmm11, [rsp+0xA0]
00007fb1689d81bc  vmovaps xmm12, [rsp+0xB0]
00007fb1689d81c5  vmovaps xmm13, [rsp+0xC0]
00007fb1689d81ce  vmovaps xmm14, [rsp+0xD0]
00007fb1689d81d7  vmovaps xmm15, [rsp+0xE0]
00007fb1689d81e0  add rsp, 0xF0
00007fb1689d81e7  pop r11
00007fb1689d81e9  pop r10
00007fb1689d81eb  pop r9
00007fb1689d81ed  pop r8
00007fb1689d81ef  pop rsi
00007fb1689d81f0  pop rdi
00007fb1689d81f1  pop rdx
00007fb1689d81f2  pop rcx
00007fb1689d81f3  pop rax
00007fb1689d81f4  add rsp, 0x08
00007fb1689d81f8  jmp 0x00007FB1689D3498
00007fb1689d81fd  sub rsp, 0x08
00007fb1689d8201  push rax
00007fb1689d8202  push rcx
00007fb1689d8203  push rdx
00007fb1689d8204  push rdi
00007fb1689d8205  push rsi
00007fb1689d8206  push r8
00007fb1689d8208  push r9
00007fb1689d820a  push r10
00007fb1689d820c  push r11
00007fb1689d820e  sub rsp, 0xF0
00007fb1689d8215  vmovaps [rsp], xmm0
00007fb1689d821a  vmovaps [rsp+0x10], xmm1
00007fb1689d8220  vmovaps [rsp+0x20], xmm2
00007fb1689d8226  vmovaps [rsp+0x30], xmm3
00007fb1689d822c  vmovaps [rsp+0x40], xmm4
00007fb1689d8232  vmovaps [rsp+0x50], xmm5
00007fb1689d8238  vmovaps [rsp+0x60], xmm6
00007fb1689d823e  vmovaps [rsp+0x70], xmm7
00007fb1689d8244  vmovaps [rsp+0x80], xmm8
00007fb1689d824d  vmovaps [rsp+0x90], xmm9
00007fb1689d8256  vmovaps [rsp+0xA0], xmm11
00007fb1689d825f  vmovaps [rsp+0xB0], xmm12
00007fb1689d8268  vmovaps [rsp+0xC0], xmm13
00007fb1689d8271  vmovaps [rsp+0xD0], xmm14
00007fb1689d827a  vmovaps [rsp+0xE0], xmm15
00007fb1689d8283  sub rsp, 0x30
00007fb1689d8287  movaps [rsp], xmm10
00007fb1689d828c  movaps [rsp+0x10], xmm11
00007fb1689d8292  movaps [rsp+0x20], xmm13
00007fb1689d8298  lea rdi, [rsp]
00007fb1689d829c  mov esi, 0x00
00007fb1689d82a1  mov rax, 0x57CCFD419530
00007fb1689d82ab  call rax
00007fb1689d82ad  movaps xmm10, [rsp]
00007fb1689d82b2  add rsp, 0x30
00007fb1689d82b6  vmovaps xmm0, [rsp]
00007fb1689d82bb  vmovaps xmm1, [rsp+0x10]
00007fb1689d82c1  vmovaps xmm2, [rsp+0x20]
00007fb1689d82c7  vmovaps xmm3, [rsp+0x30]
00007fb1689d82cd  vmovaps xmm4, [rsp+0x40]
00007fb1689d82d3  vmovaps xmm5, [rsp+0x50]
00007fb1689d82d9  vmovaps xmm6, [rsp+0x60]
00007fb1689d82df  vmovaps xmm7, [rsp+0x70]
00007fb1689d82e5  vmovaps xmm8, [rsp+0x80]
00007fb1689d82ee  vmovaps xmm9, [rsp+0x90]
00007fb1689d82f7  vmovaps xmm11, [rsp+0xA0]
00007fb1689d8300  vmovaps xmm12, [rsp+0xB0]
00007fb1689d8309  vmovaps xmm13, [rsp+0xC0]
00007fb1689d8312  vmovaps xmm14, [rsp+0xD0]
00007fb1689d831b  vmovaps xmm15, [rsp+0xE0]
00007fb1689d8324  add rsp, 0xF0
00007fb1689d832b  pop r11
00007fb1689d832d  pop r10
00007fb1689d832f  pop r9
00007fb1689d8331  pop r8
00007fb1689d8333  pop rsi
00007fb1689d8334  pop rdi
00007fb1689d8335  pop rdx
00007fb1689d8336  pop rcx
00007fb1689d8337  pop rax
00007fb1689d8338  add rsp, 0x08
00007fb1689d833c  jmp 0x00007FB1689D34C6
00007fb1689d8341  sub rsp, 0x08
00007fb1689d8345  push rax
00007fb1689d8346  push rcx
00007fb1689d8347  push rdx
00007fb1689d8348  push rdi
00007fb1689d8349  push rsi
00007fb1689d834a  push r8
00007fb1689d834c  push r9
00007fb1689d834e  push r10
00007fb1689d8350  push r11
00007fb1689d8352  sub rsp, 0xF0
00007fb1689d8359  vmovaps [rsp], xmm0
00007fb1689d835e  vmovaps [rsp+0x10], xmm1
00007fb1689d8364  vmovaps [rsp+0x20], xmm2
00007fb1689d836a  vmovaps [rsp+0x30], xmm3
00007fb1689d8370  vmovaps [rsp+0x40], xmm4
00007fb1689d8376  vmovaps [rsp+0x50], xmm5
00007fb1689d837c  vmovaps [rsp+0x60], xmm6
00007fb1689d8382  vmovaps [rsp+0x70], xmm7
00007fb1689d8388  vmovaps [rsp+0x80], xmm8
00007fb1689d8391  vmovaps [rsp+0x90], xmm9
00007fb1689d839a  vmovaps [rsp+0xA0], xmm10
00007fb1689d83a3  vmovaps [rsp+0xB0], xmm12
00007fb1689d83ac  vmovaps [rsp+0xC0], xmm13
00007fb1689d83b5  vmovaps [rsp+0xD0], xmm14
00007fb1689d83be  vmovaps [rsp+0xE0], xmm15
00007fb1689d83c7  sub rsp, 0x30
00007fb1689d83cb  movaps [rsp], xmm11
00007fb1689d83d0  movaps [rsp+0x10], xmm14
00007fb1689d83d6  movaps [rsp+0x20], xmm13
00007fb1689d83dc  lea rdi, [rsp]
00007fb1689d83e0  mov esi, 0x00
00007fb1689d83e5  mov rax, 0x57CCFD419530
00007fb1689d83ef  call rax
00007fb1689d83f1  movaps xmm11, [rsp]
00007fb1689d83f6  add rsp, 0x30
00007fb1689d83fa  vmovaps xmm0, [rsp]
00007fb1689d83ff  vmovaps xmm1, [rsp+0x10]
00007fb1689d8405  vmovaps xmm2, [rsp+0x20]
00007fb1689d840b  vmovaps xmm3, [rsp+0x30]
00007fb1689d8411  vmovaps xmm4, [rsp+0x40]
00007fb1689d8417  vmovaps xmm5, [rsp+0x50]
00007fb1689d841d  vmovaps xmm6, [rsp+0x60]
00007fb1689d8423  vmovaps xmm7, [rsp+0x70]
00007fb1689d8429  vmovaps xmm8, [rsp+0x80]
00007fb1689d8432  vmovaps xmm9, [rsp+0x90]
00007fb1689d843b  vmovaps xmm10, [rsp+0xA0]
00007fb1689d8444  vmovaps xmm12, [rsp+0xB0]
00007fb1689d844d  vmovaps xmm13, [rsp+0xC0]
00007fb1689d8456  vmovaps xmm14, [rsp+0xD0]
00007fb1689d845f  vmovaps xmm15, [rsp+0xE0]
00007fb1689d8468  add rsp, 0xF0
00007fb1689d846f  pop r11
00007fb1689d8471  pop r10
00007fb1689d8473  pop r9
00007fb1689d8475  pop r8
00007fb1689d8477  pop rsi
00007fb1689d8478  pop rdi
00007fb1689d8479  pop rdx
00007fb1689d847a  pop rcx
00007fb1689d847b  pop rax
00007fb1689d847c  add rsp, 0x08
00007fb1689d8480  jmp 0x00007FB1689D34F4
00007fb1689d8485  sub rsp, 0x08
00007fb1689d8489  push rax
00007fb1689d848a  push rcx
00007fb1689d848b  push rdx
00007fb1689d848c  push rdi
00007fb1689d848d  push rsi
00007fb1689d848e  push r8
00007fb1689d8490  push r9
00007fb1689d8492  push r10
00007fb1689d8494  push r11
00007fb1689d8496  sub rsp, 0xF0
00007fb1689d849d  vmovaps [rsp], xmm0
00007fb1689d84a2  vmovaps [rsp+0x10], xmm1
00007fb1689d84a8  vmovaps [rsp+0x20], xmm2
00007fb1689d84ae  vmovaps [rsp+0x30], xmm3
00007fb1689d84b4  vmovaps [rsp+0x40], xmm4
00007fb1689d84ba  vmovaps [rsp+0x50], xmm5
00007fb1689d84c0  vmovaps [rsp+0x60], xmm6
00007fb1689d84c6  vmovaps [rsp+0x70], xmm7
00007fb1689d84cc  vmovaps [rsp+0x80], xmm8
00007fb1689d84d5  vmovaps [rsp+0x90], xmm9
00007fb1689d84de  vmovaps [rsp+0xA0], xmm10
00007fb1689d84e7  vmovaps [rsp+0xB0], xmm11
00007fb1689d84f0  vmovaps [rsp+0xC0], xmm12
00007fb1689d84f9  vmovaps [rsp+0xD0], xmm13
00007fb1689d8502  vmovaps [rsp+0xE0], xmm15
00007fb1689d850b  sub rsp, 0x30
00007fb1689d850f  movaps [rsp], xmm14
00007fb1689d8514  movaps [rsp+0x10], xmm12
00007fb1689d851a  movaps [rsp+0x20], xmm9
00007fb1689d8520  lea rdi, [rsp]
00007fb1689d8524  mov esi, 0x00
00007fb1689d8529  mov rax, 0x57CCFD419530
00007fb1689d8533  call rax
00007fb1689d8535  movaps xmm14, [rsp]
00007fb1689d853a  add rsp, 0x30
00007fb1689d853e  vmovaps xmm0, [rsp]
00007fb1689d8543  vmovaps xmm1, [rsp+0x10]
00007fb1689d8549  vmovaps xmm2, [rsp+0x20]
00007fb1689d854f  vmovaps xmm3, [rsp+0x30]
00007fb1689d8555  vmovaps xmm4, [rsp+0x40]
00007fb1689d855b  vmovaps xmm5, [rsp+0x50]
00007fb1689d8561  vmovaps xmm6, [rsp+0x60]
00007fb1689d8567  vmovaps xmm7, [rsp+0x70]
00007fb1689d856d  vmovaps xmm8, [rsp+0x80]
00007fb1689d8576  vmovaps xmm9, [rsp+0x90]
00007fb1689d857f  vmovaps xmm10, [rsp+0xA0]
00007fb1689d8588  vmovaps xmm11, [rsp+0xB0]
00007fb1689d8591  vmovaps xmm12, [rsp+0xC0]
00007fb1689d859a  vmovaps xmm13, [rsp+0xD0]
00007fb1689d85a3  vmovaps xmm15, [rsp+0xE0]
00007fb1689d85ac  add rsp, 0xF0
00007fb1689d85b3  pop r11
00007fb1689d85b5  pop r10
00007fb1689d85b7  pop r9
00007fb1689d85b9  pop r8
00007fb1689d85bb  pop rsi
00007fb1689d85bc  pop rdi
00007fb1689d85bd  pop rdx
00007fb1689d85be  pop rcx
00007fb1689d85bf  pop rax
00007fb1689d85c0  add rsp, 0x08
00007fb1689d85c4  jmp 0x00007FB1689D350F
00007fb1689d85c9  sub rsp, 0x08
00007fb1689d85cd  push rax
00007fb1689d85ce  push rcx
00007fb1689d85cf  push rdx
00007fb1689d85d0  push rdi
00007fb1689d85d1  push rsi
00007fb1689d85d2  push r8
00007fb1689d85d4  push r9
00007fb1689d85d6  push r10
00007fb1689d85d8  push r11
00007fb1689d85da  sub rsp, 0xF0
00007fb1689d85e1  vmovaps [rsp], xmm0
00007fb1689d85e6  vmovaps [rsp+0x10], xmm1
00007fb1689d85ec  vmovaps [rsp+0x20], xmm2
00007fb1689d85f2  vmovaps [rsp+0x30], xmm3
00007fb1689d85f8  vmovaps [rsp+0x40], xmm4
00007fb1689d85fe  vmovaps [rsp+0x50], xmm5
00007fb1689d8604  vmovaps [rsp+0x60], xmm6
00007fb1689d860a  vmovaps [rsp+0x70], xmm7
00007fb1689d8610  vmovaps [rsp+0x80], xmm8
00007fb1689d8619  vmovaps [rsp+0x90], xmm9
00007fb1689d8622  vmovaps [rsp+0xA0], xmm10
00007fb1689d862b  vmovaps [rsp+0xB0], xmm11
00007fb1689d8634  vmovaps [rsp+0xC0], xmm12
00007fb1689d863d  vmovaps [rsp+0xD0], xmm14
00007fb1689d8646  vmovaps [rsp+0xE0], xmm15
00007fb1689d864f  sub rsp, 0x30
00007fb1689d8653  movaps [rsp], xmm13
00007fb1689d8658  movaps [rsp+0x10], xmm8
00007fb1689d865e  movaps [rsp+0x20], xmm15
00007fb1689d8664  lea rdi, [rsp]
00007fb1689d8668  mov esi, 0x00
00007fb1689d866d  mov rax, 0x57CCFD419530
00007fb1689d8677  call rax
00007fb1689d8679  movaps xmm13, [rsp]
00007fb1689d867e  add rsp, 0x30
00007fb1689d8682  vmovaps xmm0, [rsp]
00007fb1689d8687  vmovaps xmm1, [rsp+0x10]
00007fb1689d868d  vmovaps xmm2, [rsp+0x20]
00007fb1689d8693  vmovaps xmm3, [rsp+0x30]
00007fb1689d8699  vmovaps xmm4, [rsp+0x40]
00007fb1689d869f  vmovaps xmm5, [rsp+0x50]
00007fb1689d86a5  vmovaps xmm6, [rsp+0x60]
00007fb1689d86ab  vmovaps xmm7, [rsp+0x70]
00007fb1689d86b1  vmovaps xmm8, [rsp+0x80]
00007fb1689d86ba  vmovaps xmm9, [rsp+0x90]
00007fb1689d86c3  vmovaps xmm10, [rsp+0xA0]
00007fb1689d86cc  vmovaps xmm11, [rsp+0xB0]
00007fb1689d86d5  vmovaps xmm12, [rsp+0xC0]
00007fb1689d86de  vmovaps xmm14, [rsp+0xD0]
00007fb1689d86e7  vmovaps xmm15, [rsp+0xE0]
00007fb1689d86f0  add rsp, 0xF0
00007fb1689d86f7  pop r11
00007fb1689d86f9  pop r10
00007fb1689d86fb  pop r9
00007fb1689d86fd  pop r8
00007fb1689d86ff  pop rsi
00007fb1689d8700  pop rdi
00007fb1689d8701  pop rdx
00007fb1689d8702  pop rcx
00007fb1689d8703  pop rax
00007fb1689d8704  add rsp, 0x08
00007fb1689d8708  jmp 0x00007FB1689D3532
00007fb1689d870d  sub rsp, 0x08
00007fb1689d8711  push rax
00007fb1689d8712  push rcx
00007fb1689d8713  push rdx
00007fb1689d8714  push rdi
00007fb1689d8715  push rsi
00007fb1689d8716  push r8
00007fb1689d8718  push r9
00007fb1689d871a  push r10
00007fb1689d871c  push r11
00007fb1689d871e  sub rsp, 0xF0
00007fb1689d8725  vmovaps [rsp], xmm0
00007fb1689d872a  vmovaps [rsp+0x10], xmm1
00007fb1689d8730  vmovaps [rsp+0x20], xmm2
00007fb1689d8736  vmovaps [rsp+0x30], xmm3
00007fb1689d873c  vmovaps [rsp+0x40], xmm4
00007fb1689d8742  vmovaps [rsp+0x50], xmm5
00007fb1689d8748  vmovaps [rsp+0x60], xmm6
00007fb1689d874e  vmovaps [rsp+0x70], xmm7
00007fb1689d8754  vmovaps [rsp+0x80], xmm8
00007fb1689d875d  vmovaps [rsp+0x90], xmm9
00007fb1689d8766  vmovaps [rsp+0xA0], xmm10
00007fb1689d876f  vmovaps [rsp+0xB0], xmm11
00007fb1689d8778  vmovaps [rsp+0xC0], xmm12
00007fb1689d8781  vmovaps [rsp+0xD0], xmm13
00007fb1689d878a  vmovaps [rsp+0xE0], xmm14
00007fb1689d8793  sub rsp, 0x30
00007fb1689d8797  movaps [rsp], xmm15
00007fb1689d879c  movaps [rsp+0x10], xmm1
00007fb1689d87a1  movaps [rsp+0x20], xmm10
00007fb1689d87a7  lea rdi, [rsp]
00007fb1689d87ab  mov esi, 0x00
00007fb1689d87b0  mov rax, 0x57CCFD419530
00007fb1689d87ba  call rax
00007fb1689d87bc  movaps xmm15, [rsp]
00007fb1689d87c1  add rsp, 0x30
00007fb1689d87c5  vmovaps xmm0, [rsp]
00007fb1689d87ca  vmovaps xmm1, [rsp+0x10]
00007fb1689d87d0  vmovaps xmm2, [rsp+0x20]
00007fb1689d87d6  vmovaps xmm3, [rsp+0x30]
00007fb1689d87dc  vmovaps xmm4, [rsp+0x40]
00007fb1689d87e2  vmovaps xmm5, [rsp+0x50]
00007fb1689d87e8  vmovaps xmm6, [rsp+0x60]
00007fb1689d87ee  vmovaps xmm7, [rsp+0x70]
00007fb1689d87f4  vmovaps xmm8, [rsp+0x80]
00007fb1689d87fd  vmovaps xmm9, [rsp+0x90]
00007fb1689d8806  vmovaps xmm10, [rsp+0xA0]
00007fb1689d880f  vmovaps xmm11, [rsp+0xB0]
00007fb1689d8818  vmovaps xmm12, [rsp+0xC0]
00007fb1689d8821  vmovaps xmm13, [rsp+0xD0]
00007fb1689d882a  vmovaps xmm14, [rsp+0xE0]
00007fb1689d8833  add rsp, 0xF0
00007fb1689d883a  pop r11
00007fb1689d883c  pop r10
00007fb1689d883e  pop r9
00007fb1689d8840  pop r8
00007fb1689d8842  pop rsi
00007fb1689d8843  pop rdi
00007fb1689d8844  pop rdx
00007fb1689d8845  pop rcx
00007fb1689d8846  pop rax
00007fb1689d8847  add rsp, 0x08
00007fb1689d884b  jmp 0x00007FB1689D3555
00007fb1689d8850  sub rsp, 0x08
00007fb1689d8854  push rax
00007fb1689d8855  push rcx
00007fb1689d8856  push rdx
00007fb1689d8857  push rdi
00007fb1689d8858  push rsi
00007fb1689d8859  push r8
00007fb1689d885b  push r9
00007fb1689d885d  push r10
00007fb1689d885f  push r11
00007fb1689d8861  sub rsp, 0xF0
00007fb1689d8868  vmovaps [rsp], xmm0
00007fb1689d886d  vmovaps [rsp+0x10], xmm2
00007fb1689d8873  vmovaps [rsp+0x20], xmm3
00007fb1689d8879  vmovaps [rsp+0x30], xmm4
00007fb1689d887f  vmovaps [rsp+0x40], xmm5
00007fb1689d8885  vmovaps [rsp+0x50], xmm6
00007fb1689d888b  vmovaps [rsp+0x60], xmm7
00007fb1689d8891  vmovaps [rsp+0x70], xmm8
00007fb1689d8897  vmovaps [rsp+0x80], xmm9
00007fb1689d88a0  vmovaps [rsp+0x90], xmm10
00007fb1689d88a9  vmovaps [rsp+0xA0], xmm11
00007fb1689d88b2  vmovaps [rsp+0xB0], xmm12
00007fb1689d88bb  vmovaps [rsp+0xC0], xmm13
00007fb1689d88c4  vmovaps [rsp+0xD0], xmm14
00007fb1689d88cd  vmovaps [rsp+0xE0], xmm15
00007fb1689d88d6  sub rsp, 0x30
00007fb1689d88da  movaps [rsp], xmm1
00007fb1689d88de  movaps [rsp+0x10], xmm7
00007fb1689d88e3  movaps [rsp+0x20], xmm11
00007fb1689d88e9  lea rdi, [rsp]
00007fb1689d88ed  mov esi, 0x00
00007fb1689d88f2  mov rax, 0x57CCFD419530
00007fb1689d88fc  call rax
00007fb1689d88fe  movaps xmm1, [rsp]
00007fb1689d8902  add rsp, 0x30
00007fb1689d8906  vmovaps xmm0, [rsp]
00007fb1689d890b  vmovaps xmm2, [rsp+0x10]
00007fb1689d8911  vmovaps xmm3, [rsp+0x20]
00007fb1689d8917  vmovaps xmm4, [rsp+0x30]
00007fb1689d891d  vmovaps xmm5, [rsp+0x40]
00007fb1689d8923  vmovaps xmm6, [rsp+0x50]
00007fb1689d8929  vmovaps xmm7, [rsp+0x60]
00007fb1689d892f  vmovaps xmm8, [rsp+0x70]
00007fb1689d8935  vmovaps xmm9, [rsp+0x80]
00007fb1689d893e  vmovaps xmm10, [rsp+0x90]
00007fb1689d8947  vmovaps xmm11, [rsp+0xA0]
00007fb1689d8950  vmovaps xmm12, [rsp+0xB0]
00007fb1689d8959  vmovaps xmm13, [rsp+0xC0]
00007fb1689d8962  vmovaps xmm14, [rsp+0xD0]
00007fb1689d896b  vmovaps xmm15, [rsp+0xE0]
00007fb1689d8974  add rsp, 0xF0
00007fb1689d897b  pop r11
00007fb1689d897d  pop r10
00007fb1689d897f  pop r9
00007fb1689d8981  pop r8
00007fb1689d8983  pop rsi
00007fb1689d8984  pop rdi
00007fb1689d8985  pop rdx
00007fb1689d8986  pop rcx
00007fb1689d8987  pop rax
00007fb1689d8988  add rsp, 0x08
00007fb1689d898c  jmp 0x00007FB1689D3576
00007fb1689d8991  call 0x00007FB16880D600
00007fb1689d8996  jmp 0x00007FB1689D3589
00007fb1689d899b  call 0x00007FB16880C380
00007fb1689d89a0  jmp 0x00007FB1689D3594
00007fb1689d89a5  call 0x00007FB16880E880
00007fb1689d89aa  jmp 0x00007FB1689D359F
00007fb1689d89af  call 0x00007FB1687FF540
00007fb1689d89b4  jmp 0x00007FB1689D35AA
00007fb1689d89b9  int3
00007fb1689d89ba  nop [rax+rax*1], ax
00007fb1689d89c0  mov rax, [r15+0x40]
00007fb1689d89c4  mov r14, [r15+0x58]
00007fb1689d89c8  lea r12, [rax+r14*1]
00007fb1689d89cc  movaps xmm1, [r15+0x1D0]
00007fb1689d89d4  vmovaps [rsp+0x10], xmm1
00007fb1689d89da  vmovaps xmm15, [rsp+0x10]
00007fb1689d89e0  por xmm1, xmm15
00007fb1689d89e5  movaps xmm14, [r15+0x1A0]
00007fb1689d89ed  vmovaps [rsp+0x10], xmm14
00007fb1689d89f3  vmovaps xmm13, [rsp+0x10]
00007fb1689d89f9  por xmm14, xmm13
00007fb1689d89fe  lea rax, [r12+0x30]
00007fb1689d8a03  mov r11, [r13+rax*1]
00007fb1689d8a08  lea rax, [r12+0x38]
00007fb1689d8a0d  mov r10, [r13+rax*1]
00007fb1689d8a12  movq xmm13, r11
00007fb1689d8a17  movq xmm12, r10
00007fb1689d8a1c  movq xmm13, xmm13
00007fb1689d8a21  vmovaps [rsp+0x10], xmm13
00007fb1689d8a27  movq xmm13, xmm13
00007fb1689d8a2c  movaps [r15+0x130], xmm13
00007fb1689d8a34  movq xmm12, xmm12
00007fb1689d8a39  vmovaps [rsp+0x20], xmm12
00007fb1689d8a3f  movq xmm12, xmm12
00007fb1689d8a44  movaps [r15+0x280], xmm12
00007fb1689d8a4c  movaps xmm13, [r15+0x270]
00007fb1689d8a54  vmovaps [rsp+0x30], xmm13
00007fb1689d8a5a  vmovaps xmm12, [rsp+0x30]
00007fb1689d8a60  por xmm13, xmm12
00007fb1689d8a65  lea rax, [r12+0x20]
00007fb1689d8a6a  mov r11, [r13+rax*1]
00007fb1689d8a6f  lea rax, [r12+0x28]
00007fb1689d8a74  mov r10, [r13+rax*1]
00007fb1689d8a79  movq xmm12, r11
00007fb1689d8a7e  movq xmm11, r10
00007fb1689d8a83  movq xmm12, xmm12
00007fb1689d8a88  vmovaps [rsp+0x30], xmm12
00007fb1689d8a8e  movq xmm12, xmm12
00007fb1689d8a93  movaps [r15+0x150], xmm12
00007fb1689d8a9b  movq xmm11, xmm11
00007fb1689d8aa0  vmovaps [rsp+0x40], xmm11
00007fb1689d8aa6  movq xmm11, xmm11
00007fb1689d8aab  movaps [r15+0x140], xmm11
00007fb1689d8ab3  lea rax, [r12+0x10]
00007fb1689d8ab8  mov r11, [r13+rax*1]
00007fb1689d8abd  lea rax, [r12+0x18]
00007fb1689d8ac2  mov r10, [r13+rax*1]
00007fb1689d8ac7  movq xmm12, r11
00007fb1689d8acc  movq xmm11, r10
00007fb1689d8ad1  movq xmm12, xmm12
00007fb1689d8ad6  vmovaps [rsp+0x50], xmm12
00007fb1689d8adc  movq xmm12, xmm12
00007fb1689d8ae1  movaps [r15+0x170], xmm12
00007fb1689d8ae9  movq xmm11, xmm11
00007fb1689d8aee  vmovaps [rsp+0x60], xmm11
00007fb1689d8af4  movq xmm11, xmm11
00007fb1689d8af9  movaps [r15+0x160], xmm11
00007fb1689d8b01  mov rax, [r13+r12*1]
00007fb1689d8b06  vmovq xmm12, rax
00007fb1689d8b0b  vpbroadcastq xmm12, xmm12
00007fb1689d8b10  lea rax, [r12+0x08]
00007fb1689d8b15  mov r12, [r13+rax*1]
00007fb1689d8b1a  movq xmm11, r12
00007fb1689d8b1f  movaps [r15+0x230], xmm11
00007fb1689d8b27  mov rax, [r15+0xF8]
00007fb1689d8b2e  lea r12, [rax+0x50]
00007fb1689d8b32  movups xmm11, [r13+r12*1]
00007fb1689d8b38  lea r12, [rax+0x60]
00007fb1689d8b3c  movups xmm10, [r13+r12*1]
00007fb1689d8b42  lea r12, [rax+0x30]
00007fb1689d8b46  movups xmm9, [r13+r12*1]
00007fb1689d8b4c  mov r12, [r15+0x50]
00007fb1689d8b50  lea r11, [r12+r14*1]
00007fb1689d8b54  mov [r15+0x60], r11
00007fb1689d8b58  lea r12, [r14+0x40]
00007fb1689d8b5c  mov [r15+0x58], r12
00007fb1689d8b60  movaps xmm8, xmm12
00007fb1689d8b64  mulpd xmm8, xmm15
00007fb1689d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007fb1689d8b6f  ptest xmm7, xmm7
00007fb1689d8b74  jnz 0x00007FB1689D9997
00007fb1689d8b7a  movq xmm15, qword ptr [r15+0x230]
00007fb1689d8b83  vmovaps [rsp+0x70], xmm15
00007fb1689d8b89  vpermilpd xmm15, xmm15, 0x00
00007fb1689d8b8f  movaps xmm7, xmm9
00007fb1689d8b93  mulpd xmm7, xmm15
00007fb1689d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007fb1689d8b9d  ptest xmm6, xmm6
00007fb1689d8ba2  jnz 0x00007FB1689D9ADB
00007fb1689d8ba8  vxorps xmm15, xmm15, xmm15
00007fb1689d8bad  vpbroadcastq xmm15, xmm15
00007fb1689d8bb2  movaps xmm9, xmm12
00007fb1689d8bb6  mulpd xmm9, xmm10
00007fb1689d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007fb1689d8bc1  ptest xmm6, xmm6
00007fb1689d8bc6  jnz 0x00007FB1689D9C1D
00007fb1689d8bcc  movaps xmm10, xmm12
00007fb1689d8bd0  mulpd xmm10, xmm11
00007fb1689d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007fb1689d8bdb  ptest xmm6, xmm6
00007fb1689d8be0  jnz 0x00007FB1689D9D61
00007fb1689d8be6  movaps xmm11, [r15+0x1F0]
00007fb1689d8bee  movaps xmm6, xmm12
00007fb1689d8bf2  mulpd xmm6, xmm11
00007fb1689d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007fb1689d8bfc  ptest xmm5, xmm5
00007fb1689d8c01  jnz 0x00007FB1689D9EA5
00007fb1689d8c07  movaps xmm12, [r15+0x2A0]
00007fb1689d8c0f  vmovaps [rsp+0x80], xmm12
00007fb1689d8c18  vmovaps xmm11, [rsp+0x80]
00007fb1689d8c21  por xmm12, xmm11
00007fb1689d8c26  movaps xmm11, [r15+0x250]
00007fb1689d8c2e  vmovaps [rsp+0x80], xmm11
00007fb1689d8c37  vmovaps xmm5, [rsp+0x80]
00007fb1689d8c40  por xmm11, xmm5
00007fb1689d8c45  vmovaps xmm4, [rsp+0x70]
00007fb1689d8c4b  vpermilpd xmm4, xmm4, 0x00
00007fb1689d8c51  movaps xmm3, xmm5
00007fb1689d8c54  mulpd xmm3, xmm4
00007fb1689d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007fb1689d8c5d  ptest xmm2, xmm2
00007fb1689d8c62  jnz 0x00007FB1689D9FE7
00007fb1689d8c68  mov [rsp+0x80], rax
00007fb1689d8c70  xor eax, eax
00007fb1689d8c72  mov r14d, 0x200
00007fb1689d8c78  cmp r12, r14
00007fb1689d8c7b  cmc
00007fb1689d8c7c  lahf
00007fb1689d8c7d  seto al
00007fb1689d8c80  mov [r15+0x108], eax
00007fb1689d8c87  movaps xmm5, xmm8
00007fb1689d8c8b  addpd xmm5, xmm15
00007fb1689d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007fb1689d8c95  ptest xmm4, xmm4
00007fb1689d8c9a  jnz 0x00007FB1689DA127
00007fb1689d8ca0  movaps xmm8, [r15+0x1B0]
00007fb1689d8ca8  movaps xmm4, xmm9
00007fb1689d8cac  addpd xmm4, xmm8
00007fb1689d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007fb1689d8cb6  ptest xmm2, xmm2
00007fb1689d8cbb  jnz 0x00007FB1689DA269
00007fb1689d8cc1  movaps xmm9, xmm10
00007fb1689d8cc5  addpd xmm9, xmm8
00007fb1689d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007fb1689d8cd0  ptest xmm2, xmm2
00007fb1689d8cd5  jnz 0x00007FB1689DA3AB
00007fb1689d8cdb  movaps xmm10, [r15+0x2F0]
00007fb1689d8ce3  vmovaps [rsp+0x90], xmm10
00007fb1689d8cec  vmovaps xmm8, [rsp+0x90]
00007fb1689d8cf5  por xmm10, xmm8
00007fb1689d8cfa  movaps xmm8, [r15+0x2E0]
00007fb1689d8d02  vmovaps [rsp+0x90], xmm8
00007fb1689d8d0b  vmovaps xmm2, [rsp+0x90]
00007fb1689d8d14  por xmm8, xmm2
00007fb1689d8d19  movaps xmm2, [r15+0x2D0]
00007fb1689d8d21  vmovaps [rsp+0x90], xmm2
00007fb1689d8d2a  vmovaps [rsp+0xA0], xmm1
00007fb1689d8d33  vmovaps xmm1, [rsp+0x90]
00007fb1689d8d3c  por xmm2, xmm1
00007fb1689d8d40  movaps xmm1, [r15+0x200]
00007fb1689d8d48  vmovaps [rsp+0x90], xmm1
00007fb1689d8d51  vmovaps [rsp+0xB0], xmm15
00007fb1689d8d5a  vmovaps xmm15, [rsp+0x90]
00007fb1689d8d63  por xmm1, xmm15
00007fb1689d8d68  movaps xmm15, [r15+0x1C0]
00007fb1689d8d70  vmovaps [rsp+0x90], xmm15
00007fb1689d8d79  vmovaps [rsp+0xC0], xmm1
00007fb1689d8d82  vmovaps xmm1, [rsp+0x90]
00007fb1689d8d8b  por xmm15, xmm1
00007fb1689d8d90  movaps xmm1, [r15+0x190]
00007fb1689d8d98  vmovaps [rsp+0x90], xmm1
00007fb1689d8da1  vmovaps [rsp+0xD0], xmm15
00007fb1689d8daa  vmovaps xmm15, [rsp+0x90]
00007fb1689d8db3  por xmm1, xmm15
00007fb1689d8db8  movaps xmm15, [r15+0x300]
00007fb1689d8dc0  vmovaps [rsp+0x90], xmm15
00007fb1689d8dc9  vmovaps [rsp+0xE0], xmm1
00007fb1689d8dd2  vmovaps xmm1, [rsp+0x90]
00007fb1689d8ddb  por xmm15, xmm1
00007fb1689d8de0  mov rax, [rsp+0x80]
00007fb1689d8de8  lea r14, [rax+0xA0]
00007fb1689d8def  movups xmm1, [r13+r14*1]
00007fb1689d8df5  lea r14, [rax+0xB0]
00007fb1689d8dfc  vmovaps [rsp+0x80], xmm1
00007fb1689d8e05  movups xmm1, [r13+r14*1]
00007fb1689d8e0b  vmovaps [rsp+0x90], xmm1
00007fb1689d8e14  vmovaps [rsp+0xF0], xmm15
00007fb1689d8e1d  vmovaps xmm15, [rsp+0xB0]
00007fb1689d8e26  vmovaps [rsp+0xB0], xmm14
00007fb1689d8e2f  movaps xmm1, xmm6
00007fb1689d8e32  addpd xmm1, xmm15
00007fb1689d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007fb1689d8e3c  ptest xmm14, xmm14
00007fb1689d8e42  jnz 0x00007FB1689DA503
00007fb1689d8e48  lea r14, [rax+0xF0]
00007fb1689d8e4f  movups xmm15, [r13+r14*1]
00007fb1689d8e55  movaps xmm14, xmm4
00007fb1689d8e59  addpd xmm14, xmm3
00007fb1689d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007fb1689d8e64  ptest xmm6, xmm6
00007fb1689d8e69  jnz 0x00007FB1689DA64E
00007fb1689d8e6f  movaps xmm6, xmm9
00007fb1689d8e73  addpd xmm6, xmm7
00007fb1689d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007fb1689d8e7c  ptest xmm4, xmm4
00007fb1689d8e81  jnz 0x00007FB1689DA790
00007fb1689d8e87  vmovaps xmm9, [rsp+0x70]
00007fb1689d8e8d  vpermilpd xmm9, xmm9, 0x00
00007fb1689d8e93  vmovaps xmm4, [rsp+0x90]
00007fb1689d8e9c  movaps xmm7, xmm4
00007fb1689d8e9f  mulpd xmm7, xmm9
00007fb1689d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007fb1689d8ea9  ptest xmm3, xmm3
00007fb1689d8eae  jnz 0x00007FB1689DA8D1
00007fb1689d8eb4  vmovaps xmm9, [rsp+0x50]
00007fb1689d8eba  vpermilpd xmm9, xmm9, 0x00
00007fb1689d8ec0  movaps xmm4, xmm15
00007fb1689d8ec4  mulpd xmm4, xmm9
00007fb1689d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007fb1689d8ece  ptest xmm3, xmm3
00007fb1689d8ed3  jnz 0x00007FB1689DAA12
00007fb1689d8ed9  lea r14, [rax+0xE0]
00007fb1689d8ee0  movups xmm15, [r13+r14*1]
00007fb1689d8ee6  vmovaps xmm9, [rsp+0x70]
00007fb1689d8eec  vpermilpd xmm9, xmm9, 0x00
00007fb1689d8ef2  vmovaps [rsp+0x70], xmm1
00007fb1689d8ef8  vmovaps xmm1, [rsp+0x80]
00007fb1689d8f01  vmovaps [rsp+0x80], xmm15
00007fb1689d8f0a  movaps xmm3, xmm1
00007fb1689d8f0d  mulpd xmm3, xmm9
00007fb1689d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007fb1689d8f17  ptest xmm15, xmm15
00007fb1689d8f1d  jnz 0x00007FB1689DAB5E
00007fb1689d8f23  vmovaps xmm1, [rsp+0xF0]
00007fb1689d8f2c  vmovaps xmm15, [rsp+0xF0]
00007fb1689d8f35  por xmm1, xmm15
00007fb1689d8f3a  movaps [r15+0x300], xmm1
00007fb1689d8f42  vmovaps xmm15, [rsp+0xE0]
00007fb1689d8f4b  vmovaps xmm9, [rsp+0xE0]
00007fb1689d8f54  por xmm15, xmm9
00007fb1689d8f59  movaps [r15+0x190], xmm15
00007fb1689d8f61  vmovaps xmm9, [rsp+0x50]
00007fb1689d8f67  vpermilpd xmm9, xmm9, 0x00
00007fb1689d8f6d  vmovaps [rsp+0x90], xmm1
00007fb1689d8f76  vmovaps [rsp+0xE0], xmm15
00007fb1689d8f7f  vmovaps xmm15, [rsp+0x80]
00007fb1689d8f88  vmovaps [rsp+0x80], xmm14
00007fb1689d8f91  movaps xmm1, xmm15
00007fb1689d8f95  mulpd xmm1, xmm9
00007fb1689d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007fb1689d8f9f  ptest xmm14, xmm14
00007fb1689d8fa5  jnz 0x00007FB1689DAC9F
00007fb1689d8fab  lea r14, [rax+0x90]
00007fb1689d8fb2  movups xmm15, [r13+r14*1]
00007fb1689d8fb8  vmovaps xmm14, [rsp+0xD0]
00007fb1689d8fc1  vmovaps xmm9, [rsp+0xD0]
00007fb1689d8fca  por xmm14, xmm9
00007fb1689d8fcf  movaps [r15+0x1C0], xmm14
00007fb1689d8fd7  vmovaps xmm9, [rsp+0xC0]
00007fb1689d8fe0  vmovaps [rsp+0xD0], xmm1
00007fb1689d8fe9  vmovaps xmm1, [rsp+0xC0]
00007fb1689d8ff2  por xmm9, xmm1
00007fb1689d8ff7  movaps [r15+0x200], xmm9
00007fb1689d8fff  vmovaps [rsp+0xC0], xmm2
00007fb1689d9008  vmovaps xmm1, [rsp+0xC0]
00007fb1689d9011  por xmm2, xmm1
00007fb1689d9015  movaps [r15+0x2D0], xmm2
00007fb1689d901d  vmovaps [rsp+0xC0], xmm8
00007fb1689d9026  vmovaps xmm1, [rsp+0xC0]
00007fb1689d902f  por xmm8, xmm1
00007fb1689d9034  movaps [r15+0x2E0], xmm8
00007fb1689d903c  vmovaps [rsp+0xC0], xmm15
00007fb1689d9045  movaps xmm1, xmm5
00007fb1689d9048  addpd xmm1, xmm7
00007fb1689d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007fb1689d9051  ptest xmm15, xmm15
00007fb1689d9057  jnz 0x00007FB1689DADEB
00007fb1689d905d  vmovaps xmm15, [rsp+0x50]
00007fb1689d9063  vpermilpd xmm15, xmm15, 0x00
00007fb1689d9069  vmovaps xmm5, [rsp+0xC0]
00007fb1689d9072  vmovaps [rsp+0xC0], xmm1
00007fb1689d907b  movaps xmm7, xmm5
00007fb1689d907e  mulpd xmm7, xmm15
00007fb1689d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007fb1689d9088  ptest xmm1, xmm1
00007fb1689d908d  jnz 0x00007FB1689DAF2B
00007fb1689d9093  lea r14, [rax+0x80]
00007fb1689d909a  movups xmm1, [r13+r14*1]
00007fb1689d90a0  vmovaps xmm5, [rsp+0x70]
00007fb1689d90a6  vmovaps [rsp+0x70], xmm1
00007fb1689d90ac  movaps xmm15, xmm5
00007fb1689d90b0  addpd xmm15, xmm3
00007fb1689d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007fb1689d90bb  ptest xmm1, xmm1
00007fb1689d90c0  jnz 0x00007FB1689DB076
00007fb1689d90c6  vmovaps xmm5, [rsp+0x80]
00007fb1689d90cf  movaps xmm1, xmm5
00007fb1689d90d2  addpd xmm1, xmm4
00007fb1689d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007fb1689d90db  ptest xmm3, xmm3
00007fb1689d90e0  jnz 0x00007FB1689DB1B8
00007fb1689d90e6  vmovaps [rsp+0x80], xmm10
00007fb1689d90ef  vmovaps xmm5, [rsp+0x80]
00007fb1689d90f8  por xmm10, xmm5
00007fb1689d90fd  movaps [r15+0x2F0], xmm10
00007fb1689d9105  vmovaps xmm5, [rsp+0x50]
00007fb1689d910b  vpermilpd xmm5, xmm5, 0x00
00007fb1689d9111  vmovaps xmm3, [rsp+0x70]
00007fb1689d9117  vmovaps [rsp+0x50], xmm1
00007fb1689d911d  movaps xmm4, xmm3
00007fb1689d9120  mulpd xmm4, xmm5
00007fb1689d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007fb1689d9129  ptest xmm1, xmm1
00007fb1689d912e  jnz 0x00007FB1689DB2F8
00007fb1689d9134  lea r14, [rax+0xD0]
00007fb1689d913b  movups xmm1, [r13+r14*1]
00007fb1689d9141  vmovaps xmm3, [rsp+0xD0]
00007fb1689d914a  vmovaps [rsp+0x70], xmm1
00007fb1689d9150  movaps xmm5, xmm6
00007fb1689d9153  addpd xmm5, xmm3
00007fb1689d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007fb1689d915c  ptest xmm1, xmm1
00007fb1689d9161  jnz 0x00007FB1689DB442
00007fb1689d9167  vmovaps xmm1, [rsp+0x60]
00007fb1689d916d  vpermilpd xmm1, xmm1, 0x00
00007fb1689d9173  movaps xmm6, xmm9
00007fb1689d9177  mulpd xmm6, xmm1
00007fb1689d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007fb1689d9180  ptest xmm3, xmm3
00007fb1689d9185  jnz 0x00007FB1689DB582
00007fb1689d918b  movaps [r15+0x260], xmm6
00007fb1689d9193  vxorps xmm1, xmm1, xmm1
00007fb1689d9197  vpbroadcastq xmm1, xmm1
00007fb1689d919c  movaps [r15+0x1B0], xmm1
00007fb1689d91a4  vmovaps xmm1, [rsp+0x60]
00007fb1689d91aa  vpermilpd xmm1, xmm1, 0x00
00007fb1689d91b0  vmovaps xmm3, [rsp+0x70]
00007fb1689d91b6  vmovaps [rsp+0x70], xmm15
00007fb1689d91bc  movaps xmm9, xmm3
00007fb1689d91c0  mulpd xmm9, xmm1
00007fb1689d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007fb1689d91cb  ptest xmm15, xmm15
00007fb1689d91d1  jnz 0x00007FB1689DB6C3
00007fb1689d91d7  lea r14, [rax+0xC0]
00007fb1689d91de  movups xmm1, [r13+r14*1]
00007fb1689d91e4  vmovaps xmm3, [rsp+0xC0]
00007fb1689d91ed  vmovaps [rsp+0x80], xmm1
00007fb1689d91f6  movaps xmm15, xmm3
00007fb1689d91fa  addpd xmm15, xmm7
00007fb1689d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007fb1689d9205  ptest xmm1, xmm1
00007fb1689d920a  jnz 0x00007FB1689DB80F
00007fb1689d9210  vmovaps [rsp+0xC0], xmm13
00007fb1689d9219  vmovaps xmm1, [rsp+0xC0]
00007fb1689d9222  por xmm13, xmm1
00007fb1689d9227  movaps [r15+0x270], xmm13
00007fb1689d922f  vmovaps xmm1, [rsp+0xB0]
00007fb1689d9238  vmovaps xmm7, [rsp+0xB0]
00007fb1689d9241  por xmm1, xmm7
00007fb1689d9245  movaps [r15+0x1A0], xmm1
00007fb1689d924d  vmovaps xmm1, [rsp+0x60]
00007fb1689d9253  vpermilpd xmm1, xmm1, 0x00
00007fb1689d9259  vmovaps [rsp+0xB0], xmm1
00007fb1689d9262  vmovaps xmm1, [rsp+0x80]
00007fb1689d926b  vmovaps [rsp+0x80], xmm15
00007fb1689d9274  vmovaps xmm15, [rsp+0xB0]
00007fb1689d927d  vmovaps [rsp+0xB0], xmm14
00007fb1689d9286  movaps xmm3, xmm1
00007fb1689d9289  mulpd xmm3, xmm15
00007fb1689d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007fb1689d9293  ptest xmm14, xmm14
00007fb1689d9299  jnz 0x00007FB1689DB951
00007fb1689d929f  lea r14, [rax+0x20]
00007fb1689d92a3  movups xmm1, [r13+r14*1]
00007fb1689d92a9  movaps [r15+0x110], xmm1
00007fb1689d92b1  vmovaps xmm14, [rsp+0x70]
00007fb1689d92b7  vmovaps [rsp+0x70], xmm1
00007fb1689d92bd  movaps xmm15, xmm14
00007fb1689d92c1  addpd xmm15, xmm4
00007fb1689d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007fb1689d92cc  ptest xmm1, xmm1
00007fb1689d92d1  jnz 0x00007FB1689DBA9C
00007fb1689d92d7  vmovaps xmm1, [rsp+0x60]
00007fb1689d92dd  vpermilpd xmm1, xmm1, 0x00
00007fb1689d92e3  movaps xmm14, xmm2
00007fb1689d92e7  mulpd xmm14, xmm1
00007fb1689d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007fb1689d92f2  ptest xmm4, xmm4
00007fb1689d92f7  jnz 0x00007FB1689DBBDF
00007fb1689d92fd  vmovaps xmm4, [rsp+0x50]
00007fb1689d9303  movaps xmm1, xmm4
00007fb1689d9306  addpd xmm1, xmm9
00007fb1689d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007fb1689d9310  ptest xmm2, xmm2
00007fb1689d9315  jnz 0x00007FB1689DBD21
00007fb1689d931b  vmovaps xmm9, [rsp+0x30]
00007fb1689d9321  vpermilpd xmm9, xmm9, 0x00
00007fb1689d9327  vmovaps xmm2, [rsp+0x70]
00007fb1689d932d  vmovaps [rsp+0x50], xmm1
00007fb1689d9333  movaps xmm4, xmm2
00007fb1689d9336  mulpd xmm4, xmm9
00007fb1689d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007fb1689d9340  ptest xmm1, xmm1
00007fb1689d9345  jnz 0x00007FB1689DBE62
00007fb1689d934b  vmovaps xmm1, [rsp+0x30]
00007fb1689d9351  vpermilpd xmm1, xmm1, 0x00
00007fb1689d9357  vmovaps xmm2, [rsp+0x90]
00007fb1689d9360  vmovaps [rsp+0x60], xmm15
00007fb1689d9366  movaps xmm9, xmm2
00007fb1689d936a  mulpd xmm9, xmm1
00007fb1689d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007fb1689d9375  ptest xmm15, xmm15
00007fb1689d937b  jnz 0x00007FB1689DBFA3
00007fb1689d9381  vmovaps xmm15, [rsp+0x80]
00007fb1689d938a  movaps xmm1, xmm15
00007fb1689d938e  addpd xmm1, xmm6
00007fb1689d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007fb1689d9397  ptest xmm2, xmm2
00007fb1689d939c  jnz 0x00007FB1689DC0E5
00007fb1689d93a2  movaps xmm15, xmm5
00007fb1689d93a6  addpd xmm15, xmm3
00007fb1689d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007fb1689d93b1  ptest xmm6, xmm6
00007fb1689d93b6  jnz 0x00007FB1689DC226
00007fb1689d93bc  vmovaps xmm6, [rsp+0x30]
00007fb1689d93c2  vpermilpd xmm6, xmm6, 0x00
00007fb1689d93c8  movaps xmm5, xmm8
00007fb1689d93cc  mulpd xmm5, xmm6
00007fb1689d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007fb1689d93d5  ptest xmm3, xmm3
00007fb1689d93da  jnz 0x00007FB1689DC368
00007fb1689d93e0  vmovaps xmm8, [rsp+0x30]
00007fb1689d93e6  vpermilpd xmm8, xmm8, 0x00
00007fb1689d93ec  movaps xmm6, xmm10
00007fb1689d93f0  mulpd xmm6, xmm8
00007fb1689d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007fb1689d93fa  ptest xmm3, xmm3
00007fb1689d93ff  jnz 0x00007FB1689DC4A9
00007fb1689d9405  vmovaps xmm8, [rsp+0x60]
00007fb1689d940b  movaps xmm10, xmm8
00007fb1689d940f  addpd xmm10, xmm14
00007fb1689d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007fb1689d941a  ptest xmm3, xmm3
00007fb1689d941f  jnz 0x00007FB1689DC5EB
00007fb1689d9425  vmovaps xmm8, [rsp+0x50]
00007fb1689d942b  movaps xmm14, xmm8
00007fb1689d942f  addpd xmm14, xmm4
00007fb1689d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007fb1689d943a  ptest xmm3, xmm3
00007fb1689d943f  jnz 0x00007FB1689DC72F
00007fb1689d9445  vmovaps xmm8, [rsp+0x40]
00007fb1689d944b  vpermilpd xmm8, xmm8, 0x00
00007fb1689d9451  movaps xmm4, xmm13
00007fb1689d9455  mulpd xmm4, xmm8
00007fb1689d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007fb1689d945f  ptest xmm3, xmm3
00007fb1689d9464  jnz 0x00007FB1689DC872
00007fb1689d946a  movaps xmm13, xmm15
00007fb1689d946e  addpd xmm13, xmm9
00007fb1689d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007fb1689d9479  ptest xmm8, xmm8
00007fb1689d947f  jnz 0x00007FB1689DC9B4
00007fb1689d9485  movaps xmm15, xmm1
00007fb1689d9489  addpd xmm15, xmm5
00007fb1689d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007fb1689d9494  ptest xmm9, xmm9
00007fb1689d949a  jnz 0x00007FB1689DCAF8
00007fb1689d94a0  vmovaps [rsp+0x30], xmm11
00007fb1689d94a6  vmovaps xmm1, [rsp+0x30]
00007fb1689d94ac  por xmm11, xmm1
00007fb1689d94b1  movaps [r15+0x250], xmm11
00007fb1689d94b9  vmovaps [rsp+0x30], xmm12
00007fb1689d94bf  vmovaps xmm1, [rsp+0x30]
00007fb1689d94c5  por xmm12, xmm1
00007fb1689d94ca  movaps [r15+0x2A0], xmm12
00007fb1689d94d2  vmovaps xmm1, [rsp+0xA0]
00007fb1689d94db  vmovaps xmm11, [rsp+0xA0]
00007fb1689d94e4  por xmm1, xmm11
00007fb1689d94e9  movaps [r15+0x1D0], xmm1
00007fb1689d94f1  lea r14, [rax+0x40]
00007fb1689d94f5  movups xmm1, [r13+r14*1]
00007fb1689d94fb  movaps [r15+0x2C0], xmm1
00007fb1689d9503  vmovaps xmm11, [rsp+0x40]
00007fb1689d9509  vpermilpd xmm11, xmm11, 0x00
00007fb1689d950f  vmovaps xmm8, [rsp+0xE0]
00007fb1689d9518  movaps xmm9, xmm8
00007fb1689d951c  mulpd xmm9, xmm11
00007fb1689d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007fb1689d9527  ptest xmm5, xmm5
00007fb1689d952c  jnz 0x00007FB1689DCC44
00007fb1689d9532  movaps xmm11, xmm10
00007fb1689d9536  addpd xmm11, xmm6
00007fb1689d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007fb1689d9541  ptest xmm8, xmm8
00007fb1689d9547  jnz 0x00007FB1689DCD88
00007fb1689d954d  movaps xmm10, xmm14
00007fb1689d9551  addpd xmm10, xmm4
00007fb1689d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007fb1689d955c  ptest xmm8, xmm8
00007fb1689d9562  jnz 0x00007FB1689DCECB
00007fb1689d9568  vmovaps xmm14, [rsp+0x40]
00007fb1689d956e  vpermilpd xmm14, xmm14, 0x00
00007fb1689d9574  movaps xmm8, xmm1
00007fb1689d9578  mulpd xmm8, xmm14
00007fb1689d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007fb1689d9583  ptest xmm6, xmm6
00007fb1689d9588  jnz 0x00007FB1689DD00E
00007fb1689d958e  movaps xmm1, [r15+0x2B0]
00007fb1689d9596  vmovaps xmm14, [rsp+0x40]
00007fb1689d959c  vpermilpd xmm14, xmm14, 0x00
00007fb1689d95a2  movaps xmm6, xmm1
00007fb1689d95a5  mulpd xmm6, xmm14
00007fb1689d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007fb1689d95af  ptest xmm5, xmm5
00007fb1689d95b4  jnz 0x00007FB1689DD151
00007fb1689d95ba  vmovaps xmm1, [rsp+0x10]
00007fb1689d95c0  vpermilpd xmm1, xmm1, 0x00
00007fb1689d95c6  movaps xmm14, xmm12
00007fb1689d95ca  mulpd xmm14, xmm1
00007fb1689d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007fb1689d95d5  ptest xmm5, xmm5
00007fb1689d95da  jnz 0x00007FB1689DD292
00007fb1689d95e0  movaps xmm1, xmm13
00007fb1689d95e4  addpd xmm1, xmm9
00007fb1689d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007fb1689d95ee  ptest xmm12, xmm12
00007fb1689d95f4  jnz 0x00007FB1689DD3D5
00007fb1689d95fa  vmovaps xmm13, [rsp+0x10]
00007fb1689d9600  vpermilpd xmm13, xmm13, 0x00
00007fb1689d9606  movaps xmm12, xmm7
00007fb1689d960a  mulpd xmm12, xmm13
00007fb1689d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007fb1689d9615  ptest xmm9, xmm9
00007fb1689d961b  jnz 0x00007FB1689DD517
00007fb1689d9621  movaps xmm13, xmm15
00007fb1689d9625  addpd xmm13, xmm8
00007fb1689d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007fb1689d9630  ptest xmm9, xmm9
00007fb1689d9636  jnz 0x00007FB1689DD65A
00007fb1689d963c  movaps xmm15, [r15+0x290]
00007fb1689d9644  vmovaps xmm9, [rsp+0x10]
00007fb1689d964a  vpermilpd xmm9, xmm9, 0x00
00007fb1689d9650  movaps xmm8, xmm15
00007fb1689d9654  mulpd xmm8, xmm9
00007fb1689d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007fb1689d965f  ptest xmm7, xmm7
00007fb1689d9664  jnz 0x00007FB1689DD79E
00007fb1689d966a  movaps xmm15, xmm11
00007fb1689d966e  addpd xmm15, xmm6
00007fb1689d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007fb1689d9679  ptest xmm9, xmm9
00007fb1689d967f  jnz 0x00007FB1689DD8E2
00007fb1689d9685  movaps xmm11, [r15+0x1E0]
00007fb1689d968d  vmovaps xmm9, [rsp+0x10]
00007fb1689d9693  vpermilpd xmm9, xmm9, 0x00
00007fb1689d9699  movaps xmm7, xmm11
00007fb1689d969d  mulpd xmm7, xmm9
00007fb1689d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007fb1689d96a7  ptest xmm6, xmm6
00007fb1689d96ac  jnz 0x00007FB1689DDA25
00007fb1689d96b2  movaps xmm11, xmm10
00007fb1689d96b6  addpd xmm11, xmm14
00007fb1689d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007fb1689d96c1  ptest xmm9, xmm9
00007fb1689d96c7  jnz 0x00007FB1689DDB67
00007fb1689d96cd  lea r14, [rax+0x70]
00007fb1689d96d1  movups xmm14, [r13+r14*1]
00007fb1689d96d7  movaps [r15+0x240], xmm14
00007fb1689d96df  movaps xmm10, xmm1
00007fb1689d96e3  addpd xmm10, xmm12
00007fb1689d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007fb1689d96ee  ptest xmm9, xmm9
00007fb1689d96f4  jnz 0x00007FB1689DDCB5
00007fb1689d96fa  movaps [r15+0x170], xmm10
00007fb1689d9702  vmovaps xmm1, [rsp+0x20]
00007fb1689d9708  vpermilpd xmm1, xmm1, 0x00
00007fb1689d970e  movaps xmm12, xmm14
00007fb1689d9712  mulpd xmm12, xmm1
00007fb1689d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007fb1689d971d  ptest xmm9, xmm9
00007fb1689d9723  jnz 0x00007FB1689DDDF8
00007fb1689d9729  vmovaps xmm1, [rsp+0x20]
00007fb1689d972f  vpermilpd xmm1, xmm1, 0x00
00007fb1689d9735  vmovaps xmm9, [rsp+0xB0]
00007fb1689d973e  movaps xmm14, xmm9
00007fb1689d9742  mulpd xmm14, xmm1
00007fb1689d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007fb1689d974d  ptest xmm6, xmm6
00007fb1689d9752  jnz 0x00007FB1689DDF3B
00007fb1689d9758  movaps [r15+0x180], xmm14
00007fb1689d9760  movaps xmm1, xmm13
00007fb1689d9764  addpd xmm1, xmm8
00007fb1689d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007fb1689d976e  ptest xmm9, xmm9
00007fb1689d9774  jnz 0x00007FB1689DE07E
00007fb1689d977a  movaps [r15+0x210], xmm1
00007fb1689d9782  movups xmm13, [r13+rax*1]
00007fb1689d9788  lea r14, [rax+0x10]
00007fb1689d978c  movups xmm9, [r13+r14*1]
00007fb1689d9792  movaps [r15+0x230], xmm9
00007fb1689d979a  movaps xmm8, xmm15
00007fb1689d979e  addpd xmm8, xmm7
00007fb1689d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007fb1689d97a9  ptest xmm6, xmm6
00007fb1689d97ae  jnz 0x00007FB1689DE1D4
00007fb1689d97b4  movaps [r15+0x130], xmm8
00007fb1689d97bc  vmovaps xmm15, [rsp+0x20]
00007fb1689d97c2  vpermilpd xmm15, xmm15, 0x00
00007fb1689d97c8  movaps xmm7, xmm9
00007fb1689d97cc  mulpd xmm7, xmm15
00007fb1689d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007fb1689d97d6  ptest xmm6, xmm6
00007fb1689d97db  jnz 0x00007FB1689DE317
00007fb1689d97e1  movaps [r15+0x220], xmm7
00007fb1689d97e9  vmovaps xmm15, [rsp+0x20]
00007fb1689d97ef  vpermilpd xmm15, xmm15, 0x00
00007fb1689d97f5  movaps xmm9, xmm13
00007fb1689d97f9  mulpd xmm9, xmm15
00007fb1689d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007fb1689d9804  ptest xmm6, xmm6
00007fb1689d9809  jnz 0x00007FB1689DE459
00007fb1689d980f  movaps xmm15, xmm11
00007fb1689d9813  addpd xmm15, xmm12
00007fb1689d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007fb1689d981e  ptest xmm13, xmm13
00007fb1689d9824  jnz 0x00007FB1689DE59D
00007fb1689d982a  movaps [r15+0x140], xmm15
00007fb1689d9832  movaps xmm13, xmm10
00007fb1689d9836  addpd xmm13, xmm14
00007fb1689d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007fb1689d9841  ptest xmm12, xmm12
00007fb1689d9847  jnz 0x00007FB1689DE6E1
00007fb1689d984d  movaps [r15+0x150], xmm13
00007fb1689d9855  movaps xmm14, xmm1
00007fb1689d9859  addpd xmm14, xmm7
00007fb1689d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007fb1689d9864  ptest xmm12, xmm12
00007fb1689d986a  jnz 0x00007FB1689DE825
00007fb1689d9870  movaps [r15+0x160], xmm14
00007fb1689d9878  movaps xmm1, xmm8
00007fb1689d987c  addpd xmm1, xmm9
00007fb1689d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007fb1689d9886  ptest xmm12, xmm12
00007fb1689d988c  jnz 0x00007FB1689DE967
00007fb1689d9892  movaps [r15+0x120], xmm1
00007fb1689d989a  movups [r13+r11*1], xmm15
00007fb1689d98a0  lea rax, [r11+0x10]
00007fb1689d98a4  movups [r13+rax*1], xmm13
00007fb1689d98aa  lea rax, [r11+0x20]
00007fb1689d98ae  movups [r13+rax*1], xmm14
00007fb1689d98b4  lea rax, [r11+0x30]
00007fb1689d98b8  movups [r13+rax*1], xmm1
00007fb1689d98be  mov eax, [r15+0x108]
00007fb1689d98c5  sahf
00007fb1689d98c6  jnz 0x00007FB1689D98F8
00007fb1689d98c8  cmp dword ptr [r15+0x318], 0x00
00007fb1689d98d0  jz 0x00007FB1689DEAE0
00007fb1689d98d6  nop [rax+rax*1], ax
00007fb1689d98df  nop [rax+rax*1], eax
00007fb1689d98e7  mov eax, 0x4106D0
00007fb1689d98ec  mov [r15+0x100], rax
00007fb1689d98f3  jmp 0x00007FB1687FE110
00007fb1689d98f8  cmp dword ptr [r15+0x318], 0x00
00007fb1689d9900  jz 0x00007FB1689D89C0
00007fb1689d9906  nop [rax+rax*1], ax
00007fb1689d990f  nop [rax+rax*1], eax
00007fb1689d9917  mov eax, 0x410504
00007fb1689d991c  mov [r15+0x100], rax
00007fb1689d9923  jmp 0x00007FB1687FE110
00007fb1689d9928  int3
00007fb1689d9929  call 0x00007FB16880A4B0
00007fb1689d992e  jmp 0x00007FB1689D8A08
00007fb1689d9933  call 0x00007FB168809240
00007fb1689d9938  jmp 0x00007FB1689D8A12
00007fb1689d993d  call 0x00007FB16880A4B0
00007fb1689d9942  jmp 0x00007FB1689D8A6F
00007fb1689d9947  call 0x00007FB168809240
00007fb1689d994c  jmp 0x00007FB1689D8A79
00007fb1689d9951  call 0x00007FB16880A4B0
00007fb1689d9956  jmp 0x00007FB1689D8ABD
00007fb1689d995b  call 0x00007FB168809240
00007fb1689d9960  jmp 0x00007FB1689D8AC7
00007fb1689d9965  call 0x00007FB1688B47C0
00007fb1689d996a  jmp 0x00007FB1689D8B06
00007fb1689d996f  call 0x00007FB16880B720
00007fb1689d9974  jmp 0x00007FB1689D8B1A
00007fb1689d9979  call 0x00007FB1688BFC30
00007fb1689d997e  jmp 0x00007FB1689D8B38
00007fb1689d9983  call 0x00007FB1688BE9C0
00007fb1689d9988  jmp 0x00007FB1689D8B42
00007fb1689d998d  call 0x00007FB1688BD750
00007fb1689d9992  jmp 0x00007FB1689D8B4C
00007fb1689d9997  sub rsp, 0x08
00007fb1689d999b  push rax
00007fb1689d999c  push rcx
00007fb1689d999d  push rdx
00007fb1689d999e  push rdi
00007fb1689d999f  push rsi
00007fb1689d99a0  push r8
00007fb1689d99a2  push r9
00007fb1689d99a4  push r10
00007fb1689d99a6  push r11
00007fb1689d99a8  sub rsp, 0xF0
00007fb1689d99af  vmovaps [rsp], xmm0
00007fb1689d99b4  vmovaps [rsp+0x10], xmm1
00007fb1689d99ba  vmovaps [rsp+0x20], xmm2
00007fb1689d99c0  vmovaps [rsp+0x30], xmm3
00007fb1689d99c6  vmovaps [rsp+0x40], xmm4
00007fb1689d99cc  vmovaps [rsp+0x50], xmm5
00007fb1689d99d2  vmovaps [rsp+0x60], xmm6
00007fb1689d99d8  vmovaps [rsp+0x70], xmm7
00007fb1689d99de  vmovaps [rsp+0x80], xmm9
00007fb1689d99e7  vmovaps [rsp+0x90], xmm10
00007fb1689d99f0  vmovaps [rsp+0xA0], xmm11
00007fb1689d99f9  vmovaps [rsp+0xB0], xmm12
00007fb1689d9a02  vmovaps [rsp+0xC0], xmm13
00007fb1689d9a0b  vmovaps [rsp+0xD0], xmm14
00007fb1689d9a14  vmovaps [rsp+0xE0], xmm15
00007fb1689d9a1d  sub rsp, 0x30
00007fb1689d9a21  movaps [rsp], xmm8
00007fb1689d9a26  movaps [rsp+0x10], xmm12
00007fb1689d9a2c  movaps [rsp+0x20], xmm15
00007fb1689d9a32  lea rdi, [rsp]
00007fb1689d9a36  mov esi, 0x00
00007fb1689d9a3b  mov rax, 0x57CCFD419530
00007fb1689d9a45  call rax
00007fb1689d9a47  movaps xmm8, [rsp]
00007fb1689d9a4c  add rsp, 0x30
00007fb1689d9a50  vmovaps xmm0, [rsp]
00007fb1689d9a55  vmovaps xmm1, [rsp+0x10]
00007fb1689d9a5b  vmovaps xmm2, [rsp+0x20]
00007fb1689d9a61  vmovaps xmm3, [rsp+0x30]
00007fb1689d9a67  vmovaps xmm4, [rsp+0x40]
00007fb1689d9a6d  vmovaps xmm5, [rsp+0x50]
00007fb1689d9a73  vmovaps xmm6, [rsp+0x60]
00007fb1689d9a79  vmovaps xmm7, [rsp+0x70]
00007fb1689d9a7f  vmovaps xmm9, [rsp+0x80]
00007fb1689d9a88  vmovaps xmm10, [rsp+0x90]
00007fb1689d9a91  vmovaps xmm11, [rsp+0xA0]
00007fb1689d9a9a  vmovaps xmm12, [rsp+0xB0]
00007fb1689d9aa3  vmovaps xmm13, [rsp+0xC0]
00007fb1689d9aac  vmovaps xmm14, [rsp+0xD0]
00007fb1689d9ab5  vmovaps xmm15, [rsp+0xE0]
00007fb1689d9abe  add rsp, 0xF0
00007fb1689d9ac5  pop r11
00007fb1689d9ac7  pop r10
00007fb1689d9ac9  pop r9
00007fb1689d9acb  pop r8
00007fb1689d9acd  pop rsi
00007fb1689d9ace  pop rdi
00007fb1689d9acf  pop rdx
00007fb1689d9ad0  pop rcx
00007fb1689d9ad1  pop rax
00007fb1689d9ad2  add rsp, 0x08
00007fb1689d9ad6  jmp 0x00007FB1689D8B7A
00007fb1689d9adb  sub rsp, 0x08
00007fb1689d9adf  push rax
00007fb1689d9ae0  push rcx
00007fb1689d9ae1  push rdx
00007fb1689d9ae2  push rdi
00007fb1689d9ae3  push rsi
00007fb1689d9ae4  push r8
00007fb1689d9ae6  push r9
00007fb1689d9ae8  push r10
00007fb1689d9aea  push r11
00007fb1689d9aec  sub rsp, 0xF0
00007fb1689d9af3  vmovaps [rsp], xmm0
00007fb1689d9af8  vmovaps [rsp+0x10], xmm1
00007fb1689d9afe  vmovaps [rsp+0x20], xmm2
00007fb1689d9b04  vmovaps [rsp+0x30], xmm3
00007fb1689d9b0a  vmovaps [rsp+0x40], xmm4
00007fb1689d9b10  vmovaps [rsp+0x50], xmm5
00007fb1689d9b16  vmovaps [rsp+0x60], xmm6
00007fb1689d9b1c  vmovaps [rsp+0x70], xmm8
00007fb1689d9b22  vmovaps [rsp+0x80], xmm9
00007fb1689d9b2b  vmovaps [rsp+0x90], xmm10
00007fb1689d9b34  vmovaps [rsp+0xA0], xmm11
00007fb1689d9b3d  vmovaps [rsp+0xB0], xmm12
00007fb1689d9b46  vmovaps [rsp+0xC0], xmm13
00007fb1689d9b4f  vmovaps [rsp+0xD0], xmm14
00007fb1689d9b58  vmovaps [rsp+0xE0], xmm15
00007fb1689d9b61  sub rsp, 0x30
00007fb1689d9b65  movaps [rsp], xmm7
00007fb1689d9b69  movaps [rsp+0x10], xmm9
00007fb1689d9b6f  movaps [rsp+0x20], xmm15
00007fb1689d9b75  lea rdi, [rsp]
00007fb1689d9b79  mov esi, 0x00
00007fb1689d9b7e  mov rax, 0x57CCFD419530
00007fb1689d9b88  call rax
00007fb1689d9b8a  movaps xmm7, [rsp]
00007fb1689d9b8e  add rsp, 0x30
00007fb1689d9b92  vmovaps xmm0, [rsp]
00007fb1689d9b97  vmovaps xmm1, [rsp+0x10]
00007fb1689d9b9d  vmovaps xmm2, [rsp+0x20]
00007fb1689d9ba3  vmovaps xmm3, [rsp+0x30]
00007fb1689d9ba9  vmovaps xmm4, [rsp+0x40]
00007fb1689d9baf  vmovaps xmm5, [rsp+0x50]
00007fb1689d9bb5  vmovaps xmm6, [rsp+0x60]
00007fb1689d9bbb  vmovaps xmm8, [rsp+0x70]
00007fb1689d9bc1  vmovaps xmm9, [rsp+0x80]
00007fb1689d9bca  vmovaps xmm10, [rsp+0x90]
00007fb1689d9bd3  vmovaps xmm11, [rsp+0xA0]
00007fb1689d9bdc  vmovaps xmm12, [rsp+0xB0]
00007fb1689d9be5  vmovaps xmm13, [rsp+0xC0]
00007fb1689d9bee  vmovaps xmm14, [rsp+0xD0]
00007fb1689d9bf7  vmovaps xmm15, [rsp+0xE0]
00007fb1689d9c00  add rsp, 0xF0
00007fb1689d9c07  pop r11
00007fb1689d9c09  pop r10
00007fb1689d9c0b  pop r9
00007fb1689d9c0d  pop r8
00007fb1689d9c0f  pop rsi
00007fb1689d9c10  pop rdi
00007fb1689d9c11  pop rdx
00007fb1689d9c12  pop rcx
00007fb1689d9c13  pop rax
00007fb1689d9c14  add rsp, 0x08
00007fb1689d9c18  jmp 0x00007FB1689D8BA8
00007fb1689d9c1d  sub rsp, 0x08
00007fb1689d9c21  push rax
00007fb1689d9c22  push rcx
00007fb1689d9c23  push rdx
00007fb1689d9c24  push rdi
00007fb1689d9c25  push rsi
00007fb1689d9c26  push r8
00007fb1689d9c28  push r9
00007fb1689d9c2a  push r10
00007fb1689d9c2c  push r11
00007fb1689d9c2e  sub rsp, 0xF0
00007fb1689d9c35  vmovaps [rsp], xmm0
00007fb1689d9c3a  vmovaps [rsp+0x10], xmm1
00007fb1689d9c40  vmovaps [rsp+0x20], xmm2
00007fb1689d9c46  vmovaps [rsp+0x30], xmm3
00007fb1689d9c4c  vmovaps [rsp+0x40], xmm4
00007fb1689d9c52  vmovaps [rsp+0x50], xmm5
00007fb1689d9c58  vmovaps [rsp+0x60], xmm6
00007fb1689d9c5e  vmovaps [rsp+0x70], xmm7
00007fb1689d9c64  vmovaps [rsp+0x80], xmm8
00007fb1689d9c6d  vmovaps [rsp+0x90], xmm10
00007fb1689d9c76  vmovaps [rsp+0xA0], xmm11
00007fb1689d9c7f  vmovaps [rsp+0xB0], xmm12
00007fb1689d9c88  vmovaps [rsp+0xC0], xmm13
00007fb1689d9c91  vmovaps [rsp+0xD0], xmm14
00007fb1689d9c9a  vmovaps [rsp+0xE0], xmm15
00007fb1689d9ca3  sub rsp, 0x30
00007fb1689d9ca7  movaps [rsp], xmm9
00007fb1689d9cac  movaps [rsp+0x10], xmm12
00007fb1689d9cb2  movaps [rsp+0x20], xmm10
00007fb1689d9cb8  lea rdi, [rsp]
00007fb1689d9cbc  mov esi, 0x00
00007fb1689d9cc1  mov rax, 0x57CCFD419530
00007fb1689d9ccb  call rax
00007fb1689d9ccd  movaps xmm9, [rsp]
00007fb1689d9cd2  add rsp, 0x30
00007fb1689d9cd6  vmovaps xmm0, [rsp]
00007fb1689d9cdb  vmovaps xmm1, [rsp+0x10]
00007fb1689d9ce1  vmovaps xmm2, [rsp+0x20]
00007fb1689d9ce7  vmovaps xmm3, [rsp+0x30]
00007fb1689d9ced  vmovaps xmm4, [rsp+0x40]
00007fb1689d9cf3  vmovaps xmm5, [rsp+0x50]
00007fb1689d9cf9  vmovaps xmm6, [rsp+0x60]
00007fb1689d9cff  vmovaps xmm7, [rsp+0x70]
00007fb1689d9d05  vmovaps xmm8, [rsp+0x80]
00007fb1689d9d0e  vmovaps xmm10, [rsp+0x90]
00007fb1689d9d17  vmovaps xmm11, [rsp+0xA0]
00007fb1689d9d20  vmovaps xmm12, [rsp+0xB0]
00007fb1689d9d29  vmovaps xmm13, [rsp+0xC0]
00007fb1689d9d32  vmovaps xmm14, [rsp+0xD0]
00007fb1689d9d3b  vmovaps xmm15, [rsp+0xE0]
00007fb1689d9d44  add rsp, 0xF0
00007fb1689d9d4b  pop r11
00007fb1689d9d4d  pop r10
00007fb1689d9d4f  pop r9
00007fb1689d9d51  pop r8
00007fb1689d9d53  pop rsi
00007fb1689d9d54  pop rdi
00007fb1689d9d55  pop rdx
00007fb1689d9d56  pop rcx
00007fb1689d9d57  pop rax
00007fb1689d9d58  add rsp, 0x08
00007fb1689d9d5c  jmp 0x00007FB1689D8BCC
00007fb1689d9d61  sub rsp, 0x08
00007fb1689d9d65  push rax
00007fb1689d9d66  push rcx
00007fb1689d9d67  push rdx
00007fb1689d9d68  push rdi
00007fb1689d9d69  push rsi
00007fb1689d9d6a  push r8
00007fb1689d9d6c  push r9
00007fb1689d9d6e  push r10
00007fb1689d9d70  push r11
00007fb1689d9d72  sub rsp, 0xF0
00007fb1689d9d79  vmovaps [rsp], xmm0
00007fb1689d9d7e  vmovaps [rsp+0x10], xmm1
00007fb1689d9d84  vmovaps [rsp+0x20], xmm2
00007fb1689d9d8a  vmovaps [rsp+0x30], xmm3
00007fb1689d9d90  vmovaps [rsp+0x40], xmm4
00007fb1689d9d96  vmovaps [rsp+0x50], xmm5
00007fb1689d9d9c  vmovaps [rsp+0x60], xmm6
00007fb1689d9da2  vmovaps [rsp+0x70], xmm7
00007fb1689d9da8  vmovaps [rsp+0x80], xmm8
00007fb1689d9db1  vmovaps [rsp+0x90], xmm9
00007fb1689d9dba  vmovaps [rsp+0xA0], xmm11
00007fb1689d9dc3  vmovaps [rsp+0xB0], xmm12
00007fb1689d9dcc  vmovaps [rsp+0xC0], xmm13
00007fb1689d9dd5  vmovaps [rsp+0xD0], xmm14
00007fb1689d9dde  vmovaps [rsp+0xE0], xmm15
00007fb1689d9de7  sub rsp, 0x30
00007fb1689d9deb  movaps [rsp], xmm10
00007fb1689d9df0  movaps [rsp+0x10], xmm12
00007fb1689d9df6  movaps [rsp+0x20], xmm11
00007fb1689d9dfc  lea rdi, [rsp]
00007fb1689d9e00  mov esi, 0x00
00007fb1689d9e05  mov rax, 0x57CCFD419530
00007fb1689d9e0f  call rax
00007fb1689d9e11  movaps xmm10, [rsp]
00007fb1689d9e16  add rsp, 0x30
00007fb1689d9e1a  vmovaps xmm0, [rsp]
00007fb1689d9e1f  vmovaps xmm1, [rsp+0x10]
00007fb1689d9e25  vmovaps xmm2, [rsp+0x20]
00007fb1689d9e2b  vmovaps xmm3, [rsp+0x30]
00007fb1689d9e31  vmovaps xmm4, [rsp+0x40]
00007fb1689d9e37  vmovaps xmm5, [rsp+0x50]
00007fb1689d9e3d  vmovaps xmm6, [rsp+0x60]
00007fb1689d9e43  vmovaps xmm7, [rsp+0x70]
00007fb1689d9e49  vmovaps xmm8, [rsp+0x80]
00007fb1689d9e52  vmovaps xmm9, [rsp+0x90]
00007fb1689d9e5b  vmovaps xmm11, [rsp+0xA0]
00007fb1689d9e64  vmovaps xmm12, [rsp+0xB0]
00007fb1689d9e6d  vmovaps xmm13, [rsp+0xC0]
00007fb1689d9e76  vmovaps xmm14, [rsp+0xD0]
00007fb1689d9e7f  vmovaps xmm15, [rsp+0xE0]
00007fb1689d9e88  add rsp, 0xF0
00007fb1689d9e8f  pop r11
00007fb1689d9e91  pop r10
00007fb1689d9e93  pop r9
00007fb1689d9e95  pop r8
00007fb1689d9e97  pop rsi
00007fb1689d9e98  pop rdi
00007fb1689d9e99  pop rdx
00007fb1689d9e9a  pop rcx
00007fb1689d9e9b  pop rax
00007fb1689d9e9c  add rsp, 0x08
00007fb1689d9ea0  jmp 0x00007FB1689D8BE6
00007fb1689d9ea5  sub rsp, 0x08
00007fb1689d9ea9  push rax
00007fb1689d9eaa  push rcx
00007fb1689d9eab  push rdx
00007fb1689d9eac  push rdi
00007fb1689d9ead  push rsi
00007fb1689d9eae  push r8
00007fb1689d9eb0  push r9
00007fb1689d9eb2  push r10
00007fb1689d9eb4  push r11
00007fb1689d9eb6  sub rsp, 0xF0
00007fb1689d9ebd  vmovaps [rsp], xmm0
00007fb1689d9ec2  vmovaps [rsp+0x10], xmm1
00007fb1689d9ec8  vmovaps [rsp+0x20], xmm2
00007fb1689d9ece  vmovaps [rsp+0x30], xmm3
00007fb1689d9ed4  vmovaps [rsp+0x40], xmm4
00007fb1689d9eda  vmovaps [rsp+0x50], xmm5
00007fb1689d9ee0  vmovaps [rsp+0x60], xmm7
00007fb1689d9ee6  vmovaps [rsp+0x70], xmm8
00007fb1689d9eec  vmovaps [rsp+0x80], xmm9
00007fb1689d9ef5  vmovaps [rsp+0x90], xmm10
00007fb1689d9efe  vmovaps [rsp+0xA0], xmm11
00007fb1689d9f07  vmovaps [rsp+0xB0], xmm12
00007fb1689d9f10  vmovaps [rsp+0xC0], xmm13
00007fb1689d9f19  vmovaps [rsp+0xD0], xmm14
00007fb1689d9f22  vmovaps [rsp+0xE0], xmm15
00007fb1689d9f2b  sub rsp, 0x30
00007fb1689d9f2f  movaps [rsp], xmm6
00007fb1689d9f33  movaps [rsp+0x10], xmm12
00007fb1689d9f39  movaps [rsp+0x20], xmm11
00007fb1689d9f3f  lea rdi, [rsp]
00007fb1689d9f43  mov esi, 0x00
00007fb1689d9f48  mov rax, 0x57CCFD419530
00007fb1689d9f52  call rax
00007fb1689d9f54  movaps xmm6, [rsp]
00007fb1689d9f58  add rsp, 0x30
00007fb1689d9f5c  vmovaps xmm0, [rsp]
00007fb1689d9f61  vmovaps xmm1, [rsp+0x10]
00007fb1689d9f67  vmovaps xmm2, [rsp+0x20]
00007fb1689d9f6d  vmovaps xmm3, [rsp+0x30]
00007fb1689d9f73  vmovaps xmm4, [rsp+0x40]
00007fb1689d9f79  vmovaps xmm5, [rsp+0x50]
00007fb1689d9f7f  vmovaps xmm7, [rsp+0x60]
00007fb1689d9f85  vmovaps xmm8, [rsp+0x70]
00007fb1689d9f8b  vmovaps xmm9, [rsp+0x80]
00007fb1689d9f94  vmovaps xmm10, [rsp+0x90]
00007fb1689d9f9d  vmovaps xmm11, [rsp+0xA0]
00007fb1689d9fa6  vmovaps xmm12, [rsp+0xB0]
00007fb1689d9faf  vmovaps xmm13, [rsp+0xC0]
00007fb1689d9fb8  vmovaps xmm14, [rsp+0xD0]
00007fb1689d9fc1  vmovaps xmm15, [rsp+0xE0]
00007fb1689d9fca  add rsp, 0xF0
00007fb1689d9fd1  pop r11
00007fb1689d9fd3  pop r10
00007fb1689d9fd5  pop r9
00007fb1689d9fd7  pop r8
00007fb1689d9fd9  pop rsi
00007fb1689d9fda  pop rdi
00007fb1689d9fdb  pop rdx
00007fb1689d9fdc  pop rcx
00007fb1689d9fdd  pop rax
00007fb1689d9fde  add rsp, 0x08
00007fb1689d9fe2  jmp 0x00007FB1689D8C07
00007fb1689d9fe7  sub rsp, 0x08
00007fb1689d9feb  push rax
00007fb1689d9fec  push rcx
00007fb1689d9fed  push rdx
00007fb1689d9fee  push rdi
00007fb1689d9fef  push rsi
00007fb1689d9ff0  push r8
00007fb1689d9ff2  push r9
00007fb1689d9ff4  push r10
00007fb1689d9ff6  push r11
00007fb1689d9ff8  sub rsp, 0xF0
00007fb1689d9fff  vmovaps [rsp], xmm0
00007fb1689da004  vmovaps [rsp+0x10], xmm1
00007fb1689da00a  vmovaps [rsp+0x20], xmm2
00007fb1689da010  vmovaps [rsp+0x30], xmm4
00007fb1689da016  vmovaps [rsp+0x40], xmm5
00007fb1689da01c  vmovaps [rsp+0x50], xmm6
00007fb1689da022  vmovaps [rsp+0x60], xmm7
00007fb1689da028  vmovaps [rsp+0x70], xmm8
00007fb1689da02e  vmovaps [rsp+0x80], xmm9
00007fb1689da037  vmovaps [rsp+0x90], xmm10
00007fb1689da040  vmovaps [rsp+0xA0], xmm11
00007fb1689da049  vmovaps [rsp+0xB0], xmm12
00007fb1689da052  vmovaps [rsp+0xC0], xmm13
00007fb1689da05b  vmovaps [rsp+0xD0], xmm14
00007fb1689da064  vmovaps [rsp+0xE0], xmm15
00007fb1689da06d  sub rsp, 0x30
00007fb1689da071  movaps [rsp], xmm3
00007fb1689da075  movaps [rsp+0x10], xmm5
00007fb1689da07a  movaps [rsp+0x20], xmm4
00007fb1689da07f  lea rdi, [rsp]
00007fb1689da083  mov esi, 0x00
00007fb1689da088  mov rax, 0x57CCFD419530
00007fb1689da092  call rax
00007fb1689da094  movaps xmm3, [rsp]
00007fb1689da098  add rsp, 0x30
00007fb1689da09c  vmovaps xmm0, [rsp]
00007fb1689da0a1  vmovaps xmm1, [rsp+0x10]
00007fb1689da0a7  vmovaps xmm2, [rsp+0x20]
00007fb1689da0ad  vmovaps xmm4, [rsp+0x30]
00007fb1689da0b3  vmovaps xmm5, [rsp+0x40]
00007fb1689da0b9  vmovaps xmm6, [rsp+0x50]
00007fb1689da0bf  vmovaps xmm7, [rsp+0x60]
00007fb1689da0c5  vmovaps xmm8, [rsp+0x70]
00007fb1689da0cb  vmovaps xmm9, [rsp+0x80]
00007fb1689da0d4  vmovaps xmm10, [rsp+0x90]
00007fb1689da0dd  vmovaps xmm11, [rsp+0xA0]
00007fb1689da0e6  vmovaps xmm12, [rsp+0xB0]
00007fb1689da0ef  vmovaps xmm13, [rsp+0xC0]
00007fb1689da0f8  vmovaps xmm14, [rsp+0xD0]
00007fb1689da101  vmovaps xmm15, [rsp+0xE0]
00007fb1689da10a  add rsp, 0xF0
00007fb1689da111  pop r11
00007fb1689da113  pop r10
00007fb1689da115  pop r9
00007fb1689da117  pop r8
00007fb1689da119  pop rsi
00007fb1689da11a  pop rdi
00007fb1689da11b  pop rdx
00007fb1689da11c  pop rcx
00007fb1689da11d  pop rax
00007fb1689da11e  add rsp, 0x08
00007fb1689da122  jmp 0x00007FB1689D8C68
00007fb1689da127  sub rsp, 0x08
00007fb1689da12b  push rax
00007fb1689da12c  push rcx
00007fb1689da12d  push rdx
00007fb1689da12e  push rdi
00007fb1689da12f  push rsi
00007fb1689da130  push r8
00007fb1689da132  push r9
00007fb1689da134  push r10
00007fb1689da136  push r11
00007fb1689da138  sub rsp, 0xF0
00007fb1689da13f  vmovaps [rsp], xmm0
00007fb1689da144  vmovaps [rsp+0x10], xmm1
00007fb1689da14a  vmovaps [rsp+0x20], xmm2
00007fb1689da150  vmovaps [rsp+0x30], xmm3
00007fb1689da156  vmovaps [rsp+0x40], xmm4
00007fb1689da15c  vmovaps [rsp+0x50], xmm6
00007fb1689da162  vmovaps [rsp+0x60], xmm7
00007fb1689da168  vmovaps [rsp+0x70], xmm8
00007fb1689da16e  vmovaps [rsp+0x80], xmm9
00007fb1689da177  vmovaps [rsp+0x90], xmm10
00007fb1689da180  vmovaps [rsp+0xA0], xmm11
00007fb1689da189  vmovaps [rsp+0xB0], xmm12
00007fb1689da192  vmovaps [rsp+0xC0], xmm13
00007fb1689da19b  vmovaps [rsp+0xD0], xmm14
00007fb1689da1a4  vmovaps [rsp+0xE0], xmm15
00007fb1689da1ad  sub rsp, 0x30
00007fb1689da1b1  movaps [rsp], xmm5
00007fb1689da1b5  movaps [rsp+0x10], xmm8
00007fb1689da1bb  movaps [rsp+0x20], xmm15
00007fb1689da1c1  lea rdi, [rsp]
00007fb1689da1c5  mov esi, 0x00
00007fb1689da1ca  mov rax, 0x57CCFD419530
00007fb1689da1d4  call rax
00007fb1689da1d6  movaps xmm5, [rsp]
00007fb1689da1da  add rsp, 0x30
00007fb1689da1de  vmovaps xmm0, [rsp]
00007fb1689da1e3  vmovaps xmm1, [rsp+0x10]
00007fb1689da1e9  vmovaps xmm2, [rsp+0x20]
00007fb1689da1ef  vmovaps xmm3, [rsp+0x30]
00007fb1689da1f5  vmovaps xmm4, [rsp+0x40]
00007fb1689da1fb  vmovaps xmm6, [rsp+0x50]
00007fb1689da201  vmovaps xmm7, [rsp+0x60]
00007fb1689da207  vmovaps xmm8, [rsp+0x70]
00007fb1689da20d  vmovaps xmm9, [rsp+0x80]
00007fb1689da216  vmovaps xmm10, [rsp+0x90]
00007fb1689da21f  vmovaps xmm11, [rsp+0xA0]
00007fb1689da228  vmovaps xmm12, [rsp+0xB0]
00007fb1689da231  vmovaps xmm13, [rsp+0xC0]
00007fb1689da23a  vmovaps xmm14, [rsp+0xD0]
00007fb1689da243  vmovaps xmm15, [rsp+0xE0]
00007fb1689da24c  add rsp, 0xF0
00007fb1689da253  pop r11
00007fb1689da255  pop r10
00007fb1689da257  pop r9
00007fb1689da259  pop r8
00007fb1689da25b  pop rsi
00007fb1689da25c  pop rdi
00007fb1689da25d  pop rdx
00007fb1689da25e  pop rcx
00007fb1689da25f  pop rax
00007fb1689da260  add rsp, 0x08
00007fb1689da264  jmp 0x00007FB1689D8CA0
00007fb1689da269  sub rsp, 0x08
00007fb1689da26d  push rax
00007fb1689da26e  push rcx
00007fb1689da26f  push rdx
00007fb1689da270  push rdi
00007fb1689da271  push rsi
00007fb1689da272  push r8
00007fb1689da274  push r9
00007fb1689da276  push r10
00007fb1689da278  push r11
00007fb1689da27a  sub rsp, 0xF0
00007fb1689da281  vmovaps [rsp], xmm0
00007fb1689da286  vmovaps [rsp+0x10], xmm1
00007fb1689da28c  vmovaps [rsp+0x20], xmm2
00007fb1689da292  vmovaps [rsp+0x30], xmm3
00007fb1689da298  vmovaps [rsp+0x40], xmm5
00007fb1689da29e  vmovaps [rsp+0x50], xmm6
00007fb1689da2a4  vmovaps [rsp+0x60], xmm7
00007fb1689da2aa  vmovaps [rsp+0x70], xmm8
00007fb1689da2b0  vmovaps [rsp+0x80], xmm9
00007fb1689da2b9  vmovaps [rsp+0x90], xmm10
00007fb1689da2c2  vmovaps [rsp+0xA0], xmm11
00007fb1689da2cb  vmovaps [rsp+0xB0], xmm12
00007fb1689da2d4  vmovaps [rsp+0xC0], xmm13
00007fb1689da2dd  vmovaps [rsp+0xD0], xmm14
00007fb1689da2e6  vmovaps [rsp+0xE0], xmm15
00007fb1689da2ef  sub rsp, 0x30
00007fb1689da2f3  movaps [rsp], xmm4
00007fb1689da2f7  movaps [rsp+0x10], xmm9
00007fb1689da2fd  movaps [rsp+0x20], xmm8
00007fb1689da303  lea rdi, [rsp]
00007fb1689da307  mov esi, 0x00
00007fb1689da30c  mov rax, 0x57CCFD419530
00007fb1689da316  call rax
00007fb1689da318  movaps xmm4, [rsp]
00007fb1689da31c  add rsp, 0x30
00007fb1689da320  vmovaps xmm0, [rsp]
00007fb1689da325  vmovaps xmm1, [rsp+0x10]
00007fb1689da32b  vmovaps xmm2, [rsp+0x20]
00007fb1689da331  vmovaps xmm3, [rsp+0x30]
00007fb1689da337  vmovaps xmm5, [rsp+0x40]
00007fb1689da33d  vmovaps xmm6, [rsp+0x50]
00007fb1689da343  vmovaps xmm7, [rsp+0x60]
00007fb1689da349  vmovaps xmm8, [rsp+0x70]
00007fb1689da34f  vmovaps xmm9, [rsp+0x80]
00007fb1689da358  vmovaps xmm10, [rsp+0x90]
00007fb1689da361  vmovaps xmm11, [rsp+0xA0]
00007fb1689da36a  vmovaps xmm12, [rsp+0xB0]
00007fb1689da373  vmovaps xmm13, [rsp+0xC0]
00007fb1689da37c  vmovaps xmm14, [rsp+0xD0]
00007fb1689da385  vmovaps xmm15, [rsp+0xE0]
00007fb1689da38e  add rsp, 0xF0
00007fb1689da395  pop r11
00007fb1689da397  pop r10
00007fb1689da399  pop r9
00007fb1689da39b  pop r8
00007fb1689da39d  pop rsi
00007fb1689da39e  pop rdi
00007fb1689da39f  pop rdx
00007fb1689da3a0  pop rcx
00007fb1689da3a1  pop rax
00007fb1689da3a2  add rsp, 0x08
00007fb1689da3a6  jmp 0x00007FB1689D8CC1
00007fb1689da3ab  sub rsp, 0x08
00007fb1689da3af  push rax
00007fb1689da3b0  push rcx
00007fb1689da3b1  push rdx
00007fb1689da3b2  push rdi
00007fb1689da3b3  push rsi
00007fb1689da3b4  push r8
00007fb1689da3b6  push r9
00007fb1689da3b8  push r10
00007fb1689da3ba  push r11
00007fb1689da3bc  sub rsp, 0xF0
00007fb1689da3c3  vmovaps [rsp], xmm0
00007fb1689da3c8  vmovaps [rsp+0x10], xmm1
00007fb1689da3ce  vmovaps [rsp+0x20], xmm2
00007fb1689da3d4  vmovaps [rsp+0x30], xmm3
00007fb1689da3da  vmovaps [rsp+0x40], xmm4
00007fb1689da3e0  vmovaps [rsp+0x50], xmm5
00007fb1689da3e6  vmovaps [rsp+0x60], xmm6
00007fb1689da3ec  vmovaps [rsp+0x70], xmm7
00007fb1689da3f2  vmovaps [rsp+0x80], xmm8
00007fb1689da3fb  vmovaps [rsp+0x90], xmm10
00007fb1689da404  vmovaps [rsp+0xA0], xmm11
00007fb1689da40d  vmovaps [rsp+0xB0], xmm12
00007fb1689da416  vmovaps [rsp+0xC0], xmm13
00007fb1689da41f  vmovaps [rsp+0xD0], xmm14
00007fb1689da428  vmovaps [rsp+0xE0], xmm15
00007fb1689da431  sub rsp, 0x30
00007fb1689da435  movaps [rsp], xmm9
00007fb1689da43a  movaps [rsp+0x10], xmm10
00007fb1689da440  movaps [rsp+0x20], xmm8
00007fb1689da446  lea rdi, [rsp]
00007fb1689da44a  mov esi, 0x00
00007fb1689da44f  mov rax, 0x57CCFD419530
00007fb1689da459  call rax
00007fb1689da45b  movaps xmm9, [rsp]
00007fb1689da460  add rsp, 0x30
00007fb1689da464  vmovaps xmm0, [rsp]
00007fb1689da469  vmovaps xmm1, [rsp+0x10]
00007fb1689da46f  vmovaps xmm2, [rsp+0x20]
00007fb1689da475  vmovaps xmm3, [rsp+0x30]
00007fb1689da47b  vmovaps xmm4, [rsp+0x40]
00007fb1689da481  vmovaps xmm5, [rsp+0x50]
00007fb1689da487  vmovaps xmm6, [rsp+0x60]
00007fb1689da48d  vmovaps xmm7, [rsp+0x70]
00007fb1689da493  vmovaps xmm8, [rsp+0x80]
00007fb1689da49c  vmovaps xmm10, [rsp+0x90]
00007fb1689da4a5  vmovaps xmm11, [rsp+0xA0]
00007fb1689da4ae  vmovaps xmm12, [rsp+0xB0]
00007fb1689da4b7  vmovaps xmm13, [rsp+0xC0]
00007fb1689da4c0  vmovaps xmm14, [rsp+0xD0]
00007fb1689da4c9  vmovaps xmm15, [rsp+0xE0]
00007fb1689da4d2  add rsp, 0xF0
00007fb1689da4d9  pop r11
00007fb1689da4db  pop r10
00007fb1689da4dd  pop r9
00007fb1689da4df  pop r8
00007fb1689da4e1  pop rsi
00007fb1689da4e2  pop rdi
00007fb1689da4e3  pop rdx
00007fb1689da4e4  pop rcx
00007fb1689da4e5  pop rax
00007fb1689da4e6  add rsp, 0x08
00007fb1689da4ea  jmp 0x00007FB1689D8CDB
00007fb1689da4ef  call 0x00007FB1688D64F0
00007fb1689da4f4  jmp 0x00007FB1689D8DF5
00007fb1689da4f9  call 0x00007FB1688D64F0
00007fb1689da4fe  jmp 0x00007FB1689D8E0B
00007fb1689da503  sub rsp, 0x08
00007fb1689da507  push rax
00007fb1689da508  push rcx
00007fb1689da509  push rdx
00007fb1689da50a  push rdi
00007fb1689da50b  push rsi
00007fb1689da50c  push r8
00007fb1689da50e  push r9
00007fb1689da510  push r10
00007fb1689da512  push r11
00007fb1689da514  sub rsp, 0xF0
00007fb1689da51b  vmovaps [rsp], xmm0
00007fb1689da520  vmovaps [rsp+0x10], xmm2
00007fb1689da526  vmovaps [rsp+0x20], xmm3
00007fb1689da52c  vmovaps [rsp+0x30], xmm4
00007fb1689da532  vmovaps [rsp+0x40], xmm5
00007fb1689da538  vmovaps [rsp+0x50], xmm6
00007fb1689da53e  vmovaps [rsp+0x60], xmm7
00007fb1689da544  vmovaps [rsp+0x70], xmm8
00007fb1689da54a  vmovaps [rsp+0x80], xmm9
00007fb1689da553  vmovaps [rsp+0x90], xmm10
00007fb1689da55c  vmovaps [rsp+0xA0], xmm11
00007fb1689da565  vmovaps [rsp+0xB0], xmm12
00007fb1689da56e  vmovaps [rsp+0xC0], xmm13
00007fb1689da577  vmovaps [rsp+0xD0], xmm14
00007fb1689da580  vmovaps [rsp+0xE0], xmm15
00007fb1689da589  sub rsp, 0x30
00007fb1689da58d  movaps [rsp], xmm1
00007fb1689da591  movaps [rsp+0x10], xmm6
00007fb1689da596  movaps [rsp+0x20], xmm15
00007fb1689da59c  lea rdi, [rsp]
00007fb1689da5a0  mov esi, 0x00
00007fb1689da5a5  mov rax, 0x57CCFD419530
00007fb1689da5af  call rax
00007fb1689da5b1  movaps xmm1, [rsp]
00007fb1689da5b5  add rsp, 0x30
00007fb1689da5b9  vmovaps xmm0, [rsp]
00007fb1689da5be  vmovaps xmm2, [rsp+0x10]
00007fb1689da5c4  vmovaps xmm3, [rsp+0x20]
00007fb1689da5ca  vmovaps xmm4, [rsp+0x30]
00007fb1689da5d0  vmovaps xmm5, [rsp+0x40]
00007fb1689da5d6  vmovaps xmm6, [rsp+0x50]
00007fb1689da5dc  vmovaps xmm7, [rsp+0x60]
00007fb1689da5e2  vmovaps xmm8, [rsp+0x70]
00007fb1689da5e8  vmovaps xmm9, [rsp+0x80]
00007fb1689da5f1  vmovaps xmm10, [rsp+0x90]
00007fb1689da5fa  vmovaps xmm11, [rsp+0xA0]
00007fb1689da603  vmovaps xmm12, [rsp+0xB0]
00007fb1689da60c  vmovaps xmm13, [rsp+0xC0]
00007fb1689da615  vmovaps xmm14, [rsp+0xD0]
00007fb1689da61e  vmovaps xmm15, [rsp+0xE0]
00007fb1689da627  add rsp, 0xF0
00007fb1689da62e  pop r11
00007fb1689da630  pop r10
00007fb1689da632  pop r9
00007fb1689da634  pop r8
00007fb1689da636  pop rsi
00007fb1689da637  pop rdi
00007fb1689da638  pop rdx
00007fb1689da639  pop rcx
00007fb1689da63a  pop rax
00007fb1689da63b  add rsp, 0x08
00007fb1689da63f  jmp 0x00007FB1689D8E48
00007fb1689da644  call 0x00007FB1688E5820
00007fb1689da649  jmp 0x00007FB1689D8E55
00007fb1689da64e  sub rsp, 0x08
00007fb1689da652  push rax
00007fb1689da653  push rcx
00007fb1689da654  push rdx
00007fb1689da655  push rdi
00007fb1689da656  push rsi
00007fb1689da657  push r8
00007fb1689da659  push r9
00007fb1689da65b  push r10
00007fb1689da65d  push r11
00007fb1689da65f  sub rsp, 0xF0
00007fb1689da666  vmovaps [rsp], xmm0
00007fb1689da66b  vmovaps [rsp+0x10], xmm1
00007fb1689da671  vmovaps [rsp+0x20], xmm2
00007fb1689da677  vmovaps [rsp+0x30], xmm3
00007fb1689da67d  vmovaps [rsp+0x40], xmm4
00007fb1689da683  vmovaps [rsp+0x50], xmm5
00007fb1689da689  vmovaps [rsp+0x60], xmm6
00007fb1689da68f  vmovaps [rsp+0x70], xmm7
00007fb1689da695  vmovaps [rsp+0x80], xmm8
00007fb1689da69e  vmovaps [rsp+0x90], xmm9
00007fb1689da6a7  vmovaps [rsp+0xA0], xmm10
00007fb1689da6b0  vmovaps [rsp+0xB0], xmm11
00007fb1689da6b9  vmovaps [rsp+0xC0], xmm12
00007fb1689da6c2  vmovaps [rsp+0xD0], xmm13
00007fb1689da6cb  vmovaps [rsp+0xE0], xmm15
00007fb1689da6d4  sub rsp, 0x30
00007fb1689da6d8  movaps [rsp], xmm14
00007fb1689da6dd  movaps [rsp+0x10], xmm4
00007fb1689da6e2  movaps [rsp+0x20], xmm3
00007fb1689da6e7  lea rdi, [rsp]
00007fb1689da6eb  mov esi, 0x00
00007fb1689da6f0  mov rax, 0x57CCFD419530
00007fb1689da6fa  call rax
00007fb1689da6fc  movaps xmm14, [rsp]
00007fb1689da701  add rsp, 0x30
00007fb1689da705  vmovaps xmm0, [rsp]
00007fb1689da70a  vmovaps xmm1, [rsp+0x10]
00007fb1689da710  vmovaps xmm2, [rsp+0x20]
00007fb1689da716  vmovaps xmm3, [rsp+0x30]
00007fb1689da71c  vmovaps xmm4, [rsp+0x40]
00007fb1689da722  vmovaps xmm5, [rsp+0x50]
00007fb1689da728  vmovaps xmm6, [rsp+0x60]
00007fb1689da72e  vmovaps xmm7, [rsp+0x70]
00007fb1689da734  vmovaps xmm8, [rsp+0x80]
00007fb1689da73d  vmovaps xmm9, [rsp+0x90]
00007fb1689da746  vmovaps xmm10, [rsp+0xA0]
00007fb1689da74f  vmovaps xmm11, [rsp+0xB0]
00007fb1689da758  vmovaps xmm12, [rsp+0xC0]
00007fb1689da761  vmovaps xmm13, [rsp+0xD0]
00007fb1689da76a  vmovaps xmm15, [rsp+0xE0]
00007fb1689da773  add rsp, 0xF0
00007fb1689da77a  pop r11
00007fb1689da77c  pop r10
00007fb1689da77e  pop r9
00007fb1689da780  pop r8
00007fb1689da782  pop rsi
00007fb1689da783  pop rdi
00007fb1689da784  pop rdx
00007fb1689da785  pop rcx
00007fb1689da786  pop rax
00007fb1689da787  add rsp, 0x08
00007fb1689da78b  jmp 0x00007FB1689D8E6F
00007fb1689da790  sub rsp, 0x08
00007fb1689da794  push rax
00007fb1689da795  push rcx
00007fb1689da796  push rdx
00007fb1689da797  push rdi
00007fb1689da798  push rsi
00007fb1689da799  push r8
00007fb1689da79b  push r9
00007fb1689da79d  push r10
00007fb1689da79f  push r11
00007fb1689da7a1  sub rsp, 0xF0
00007fb1689da7a8  vmovaps [rsp], xmm0
00007fb1689da7ad  vmovaps [rsp+0x10], xmm1
00007fb1689da7b3  vmovaps [rsp+0x20], xmm2
00007fb1689da7b9  vmovaps [rsp+0x30], xmm3
00007fb1689da7bf  vmovaps [rsp+0x40], xmm4
00007fb1689da7c5  vmovaps [rsp+0x50], xmm5
00007fb1689da7cb  vmovaps [rsp+0x60], xmm7
00007fb1689da7d1  vmovaps [rsp+0x70], xmm8
00007fb1689da7d7  vmovaps [rsp+0x80], xmm9
00007fb1689da7e0  vmovaps [rsp+0x90], xmm10
00007fb1689da7e9  vmovaps [rsp+0xA0], xmm11
00007fb1689da7f2  vmovaps [rsp+0xB0], xmm12
00007fb1689da7fb  vmovaps [rsp+0xC0], xmm13
00007fb1689da804  vmovaps [rsp+0xD0], xmm14
00007fb1689da80d  vmovaps [rsp+0xE0], xmm15
00007fb1689da816  sub rsp, 0x30
00007fb1689da81a  movaps [rsp], xmm6
00007fb1689da81e  movaps [rsp+0x10], xmm9
00007fb1689da824  movaps [rsp+0x20], xmm7
00007fb1689da829  lea rdi, [rsp]
00007fb1689da82d  mov esi, 0x00
00007fb1689da832  mov rax, 0x57CCFD419530
00007fb1689da83c  call rax
00007fb1689da83e  movaps xmm6, [rsp]
00007fb1689da842  add rsp, 0x30
00007fb1689da846  vmovaps xmm0, [rsp]
00007fb1689da84b  vmovaps xmm1, [rsp+0x10]
00007fb1689da851  vmovaps xmm2, [rsp+0x20]
00007fb1689da857  vmovaps xmm3, [rsp+0x30]
00007fb1689da85d  vmovaps xmm4, [rsp+0x40]
00007fb1689da863  vmovaps xmm5, [rsp+0x50]
00007fb1689da869  vmovaps xmm7, [rsp+0x60]
00007fb1689da86f  vmovaps xmm8, [rsp+0x70]
00007fb1689da875  vmovaps xmm9, [rsp+0x80]
00007fb1689da87e  vmovaps xmm10, [rsp+0x90]
00007fb1689da887  vmovaps xmm11, [rsp+0xA0]
00007fb1689da890  vmovaps xmm12, [rsp+0xB0]
00007fb1689da899  vmovaps xmm13, [rsp+0xC0]
00007fb1689da8a2  vmovaps xmm14, [rsp+0xD0]
00007fb1689da8ab  vmovaps xmm15, [rsp+0xE0]
00007fb1689da8b4  add rsp, 0xF0
00007fb1689da8bb  pop r11
00007fb1689da8bd  pop r10
00007fb1689da8bf  pop r9
00007fb1689da8c1  pop r8
00007fb1689da8c3  pop rsi
00007fb1689da8c4  pop rdi
00007fb1689da8c5  pop rdx
00007fb1689da8c6  pop rcx
00007fb1689da8c7  pop rax
00007fb1689da8c8  add rsp, 0x08
00007fb1689da8cc  jmp 0x00007FB1689D8E87
00007fb1689da8d1  sub rsp, 0x08
00007fb1689da8d5  push rax
00007fb1689da8d6  push rcx
00007fb1689da8d7  push rdx
00007fb1689da8d8  push rdi
00007fb1689da8d9  push rsi
00007fb1689da8da  push r8
00007fb1689da8dc  push r9
00007fb1689da8de  push r10
00007fb1689da8e0  push r11
00007fb1689da8e2  sub rsp, 0xF0
00007fb1689da8e9  vmovaps [rsp], xmm0
00007fb1689da8ee  vmovaps [rsp+0x10], xmm1
00007fb1689da8f4  vmovaps [rsp+0x20], xmm2
00007fb1689da8fa  vmovaps [rsp+0x30], xmm3
00007fb1689da900  vmovaps [rsp+0x40], xmm4
00007fb1689da906  vmovaps [rsp+0x50], xmm5
00007fb1689da90c  vmovaps [rsp+0x60], xmm6
00007fb1689da912  vmovaps [rsp+0x70], xmm8
00007fb1689da918  vmovaps [rsp+0x80], xmm9
00007fb1689da921  vmovaps [rsp+0x90], xmm10
00007fb1689da92a  vmovaps [rsp+0xA0], xmm11
00007fb1689da933  vmovaps [rsp+0xB0], xmm12
00007fb1689da93c  vmovaps [rsp+0xC0], xmm13
00007fb1689da945  vmovaps [rsp+0xD0], xmm14
00007fb1689da94e  vmovaps [rsp+0xE0], xmm15
00007fb1689da957  sub rsp, 0x30
00007fb1689da95b  movaps [rsp], xmm7
00007fb1689da95f  movaps [rsp+0x10], xmm4
00007fb1689da964  movaps [rsp+0x20], xmm9
00007fb1689da96a  lea rdi, [rsp]
00007fb1689da96e  mov esi, 0x00
00007fb1689da973  mov rax, 0x57CCFD419530
00007fb1689da97d  call rax
00007fb1689da97f  movaps xmm7, [rsp]
00007fb1689da983  add rsp, 0x30
00007fb1689da987  vmovaps xmm0, [rsp]
00007fb1689da98c  vmovaps xmm1, [rsp+0x10]
00007fb1689da992  vmovaps xmm2, [rsp+0x20]
00007fb1689da998  vmovaps xmm3, [rsp+0x30]
00007fb1689da99e  vmovaps xmm4, [rsp+0x40]
00007fb1689da9a4  vmovaps xmm5, [rsp+0x50]
00007fb1689da9aa  vmovaps xmm6, [rsp+0x60]
00007fb1689da9b0  vmovaps xmm8, [rsp+0x70]
00007fb1689da9b6  vmovaps xmm9, [rsp+0x80]
00007fb1689da9bf  vmovaps xmm10, [rsp+0x90]
00007fb1689da9c8  vmovaps xmm11, [rsp+0xA0]
00007fb1689da9d1  vmovaps xmm12, [rsp+0xB0]
00007fb1689da9da  vmovaps xmm13, [rsp+0xC0]
00007fb1689da9e3  vmovaps xmm14, [rsp+0xD0]
00007fb1689da9ec  vmovaps xmm15, [rsp+0xE0]
00007fb1689da9f5  add rsp, 0xF0
00007fb1689da9fc  pop r11
00007fb1689da9fe  pop r10
00007fb1689daa00  pop r9
00007fb1689daa02  pop r8
00007fb1689daa04  pop rsi
00007fb1689daa05  pop rdi
00007fb1689daa06  pop rdx
00007fb1689daa07  pop rcx
00007fb1689daa08  pop rax
00007fb1689daa09  add rsp, 0x08
00007fb1689daa0d  jmp 0x00007FB1689D8EB4
00007fb1689daa12  sub rsp, 0x08
00007fb1689daa16  push rax
00007fb1689daa17  push rcx
00007fb1689daa18  push rdx
00007fb1689daa19  push rdi
00007fb1689daa1a  push rsi
00007fb1689daa1b  push r8
00007fb1689daa1d  push r9
00007fb1689daa1f  push r10
00007fb1689daa21  push r11
00007fb1689daa23  sub rsp, 0xF0
00007fb1689daa2a  vmovaps [rsp], xmm0
00007fb1689daa2f  vmovaps [rsp+0x10], xmm1
00007fb1689daa35  vmovaps [rsp+0x20], xmm2
00007fb1689daa3b  vmovaps [rsp+0x30], xmm3
00007fb1689daa41  vmovaps [rsp+0x40], xmm5
00007fb1689daa47  vmovaps [rsp+0x50], xmm6
00007fb1689daa4d  vmovaps [rsp+0x60], xmm7
00007fb1689daa53  vmovaps [rsp+0x70], xmm8
00007fb1689daa59  vmovaps [rsp+0x80], xmm9
00007fb1689daa62  vmovaps [rsp+0x90], xmm10
00007fb1689daa6b  vmovaps [rsp+0xA0], xmm11
00007fb1689daa74  vmovaps [rsp+0xB0], xmm12
00007fb1689daa7d  vmovaps [rsp+0xC0], xmm13
00007fb1689daa86  vmovaps [rsp+0xD0], xmm14
00007fb1689daa8f  vmovaps [rsp+0xE0], xmm15
00007fb1689daa98  sub rsp, 0x30
00007fb1689daa9c  movaps [rsp], xmm4
00007fb1689daaa0  movaps [rsp+0x10], xmm15
00007fb1689daaa6  movaps [rsp+0x20], xmm9
00007fb1689daaac  lea rdi, [rsp]
00007fb1689daab0  mov esi, 0x00
00007fb1689daab5  mov rax, 0x57CCFD419530
00007fb1689daabf  call rax
00007fb1689daac1  movaps xmm4, [rsp]
00007fb1689daac5  add rsp, 0x30
00007fb1689daac9  vmovaps xmm0, [rsp]
00007fb1689daace  vmovaps xmm1, [rsp+0x10]
00007fb1689daad4  vmovaps xmm2, [rsp+0x20]
00007fb1689daada  vmovaps xmm3, [rsp+0x30]
00007fb1689daae0  vmovaps xmm5, [rsp+0x40]
00007fb1689daae6  vmovaps xmm6, [rsp+0x50]
00007fb1689daaec  vmovaps xmm7, [rsp+0x60]
00007fb1689daaf2  vmovaps xmm8, [rsp+0x70]
00007fb1689daaf8  vmovaps xmm9, [rsp+0x80]
00007fb1689dab01  vmovaps xmm10, [rsp+0x90]
00007fb1689dab0a  vmovaps xmm11, [rsp+0xA0]
00007fb1689dab13  vmovaps xmm12, [rsp+0xB0]
00007fb1689dab1c  vmovaps xmm13, [rsp+0xC0]
00007fb1689dab25  vmovaps xmm14, [rsp+0xD0]
00007fb1689dab2e  vmovaps xmm15, [rsp+0xE0]
00007fb1689dab37  add rsp, 0xF0
00007fb1689dab3e  pop r11
00007fb1689dab40  pop r10
00007fb1689dab42  pop r9
00007fb1689dab44  pop r8
00007fb1689dab46  pop rsi
00007fb1689dab47  pop rdi
00007fb1689dab48  pop rdx
00007fb1689dab49  pop rcx
00007fb1689dab4a  pop rax
00007fb1689dab4b  add rsp, 0x08
00007fb1689dab4f  jmp 0x00007FB1689D8ED9
00007fb1689dab54  call 0x00007FB1688E5820
00007fb1689dab59  jmp 0x00007FB1689D8EE6
00007fb1689dab5e  sub rsp, 0x08
00007fb1689dab62  push rax
00007fb1689dab63  push rcx
00007fb1689dab64  push rdx
00007fb1689dab65  push rdi
00007fb1689dab66  push rsi
00007fb1689dab67  push r8
00007fb1689dab69  push r9
00007fb1689dab6b  push r10
00007fb1689dab6d  push r11
00007fb1689dab6f  sub rsp, 0xF0
00007fb1689dab76  vmovaps [rsp], xmm0
00007fb1689dab7b  vmovaps [rsp+0x10], xmm1
00007fb1689dab81  vmovaps [rsp+0x20], xmm2
00007fb1689dab87  vmovaps [rsp+0x30], xmm4
00007fb1689dab8d  vmovaps [rsp+0x40], xmm5
00007fb1689dab93  vmovaps [rsp+0x50], xmm6
00007fb1689dab99  vmovaps [rsp+0x60], xmm7
00007fb1689dab9f  vmovaps [rsp+0x70], xmm8
00007fb1689daba5  vmovaps [rsp+0x80], xmm9
00007fb1689dabae  vmovaps [rsp+0x90], xmm10
00007fb1689dabb7  vmovaps [rsp+0xA0], xmm11
00007fb1689dabc0  vmovaps [rsp+0xB0], xmm12
00007fb1689dabc9  vmovaps [rsp+0xC0], xmm13
00007fb1689dabd2  vmovaps [rsp+0xD0], xmm14
00007fb1689dabdb  vmovaps [rsp+0xE0], xmm15
00007fb1689dabe4  sub rsp, 0x30
00007fb1689dabe8  movaps [rsp], xmm3
00007fb1689dabec  movaps [rsp+0x10], xmm1
00007fb1689dabf1  movaps [rsp+0x20], xmm9
00007fb1689dabf7  lea rdi, [rsp]
00007fb1689dabfb  mov esi, 0x00
00007fb1689dac00  mov rax, 0x57CCFD419530
00007fb1689dac0a  call rax
00007fb1689dac0c  movaps xmm3, [rsp]
00007fb1689dac10  add rsp, 0x30
00007fb1689dac14  vmovaps xmm0, [rsp]
00007fb1689dac19  vmovaps xmm1, [rsp+0x10]
00007fb1689dac1f  vmovaps xmm2, [rsp+0x20]
00007fb1689dac25  vmovaps xmm4, [rsp+0x30]
00007fb1689dac2b  vmovaps xmm5, [rsp+0x40]
00007fb1689dac31  vmovaps xmm6, [rsp+0x50]
00007fb1689dac37  vmovaps xmm7, [rsp+0x60]
00007fb1689dac3d  vmovaps xmm8, [rsp+0x70]
00007fb1689dac43  vmovaps xmm9, [rsp+0x80]
00007fb1689dac4c  vmovaps xmm10, [rsp+0x90]
00007fb1689dac55  vmovaps xmm11, [rsp+0xA0]
00007fb1689dac5e  vmovaps xmm12, [rsp+0xB0]
00007fb1689dac67  vmovaps xmm13, [rsp+0xC0]
00007fb1689dac70  vmovaps xmm14, [rsp+0xD0]
00007fb1689dac79  vmovaps xmm15, [rsp+0xE0]
00007fb1689dac82  add rsp, 0xF0
00007fb1689dac89  pop r11
00007fb1689dac8b  pop r10
00007fb1689dac8d  pop r9
00007fb1689dac8f  pop r8
00007fb1689dac91  pop rsi
00007fb1689dac92  pop rdi
00007fb1689dac93  pop rdx
00007fb1689dac94  pop rcx
00007fb1689dac95  pop rax
00007fb1689dac96  add rsp, 0x08
00007fb1689dac9a  jmp 0x00007FB1689D8F23
00007fb1689dac9f  sub rsp, 0x08
00007fb1689daca3  push rax
00007fb1689daca4  push rcx
00007fb1689daca5  push rdx
00007fb1689daca6  push rdi
00007fb1689daca7  push rsi
00007fb1689daca8  push r8
00007fb1689dacaa  push r9
00007fb1689dacac  push r10
00007fb1689dacae  push r11
00007fb1689dacb0  sub rsp, 0xF0
00007fb1689dacb7  vmovaps [rsp], xmm0
00007fb1689dacbc  vmovaps [rsp+0x10], xmm2
00007fb1689dacc2  vmovaps [rsp+0x20], xmm3
00007fb1689dacc8  vmovaps [rsp+0x30], xmm4
00007fb1689dacce  vmovaps [rsp+0x40], xmm5
00007fb1689dacd4  vmovaps [rsp+0x50], xmm6
00007fb1689dacda  vmovaps [rsp+0x60], xmm7
00007fb1689dace0  vmovaps [rsp+0x70], xmm8
00007fb1689dace6  vmovaps [rsp+0x80], xmm9
00007fb1689dacef  vmovaps [rsp+0x90], xmm10
00007fb1689dacf8  vmovaps [rsp+0xA0], xmm11
00007fb1689dad01  vmovaps [rsp+0xB0], xmm12
00007fb1689dad0a  vmovaps [rsp+0xC0], xmm13
00007fb1689dad13  vmovaps [rsp+0xD0], xmm14
00007fb1689dad1c  vmovaps [rsp+0xE0], xmm15
00007fb1689dad25  sub rsp, 0x30
00007fb1689dad29  movaps [rsp], xmm1
00007fb1689dad2d  movaps [rsp+0x10], xmm15
00007fb1689dad33  movaps [rsp+0x20], xmm9
00007fb1689dad39  lea rdi, [rsp]
00007fb1689dad3d  mov esi, 0x00
00007fb1689dad42  mov rax, 0x57CCFD419530
00007fb1689dad4c  call rax
00007fb1689dad4e  movaps xmm1, [rsp]
00007fb1689dad52  add rsp, 0x30
00007fb1689dad56  vmovaps xmm0, [rsp]
00007fb1689dad5b  vmovaps xmm2, [rsp+0x10]
00007fb1689dad61  vmovaps xmm3, [rsp+0x20]
00007fb1689dad67  vmovaps xmm4, [rsp+0x30]
00007fb1689dad6d  vmovaps xmm5, [rsp+0x40]
00007fb1689dad73  vmovaps xmm6, [rsp+0x50]
00007fb1689dad79  vmovaps xmm7, [rsp+0x60]
00007fb1689dad7f  vmovaps xmm8, [rsp+0x70]
00007fb1689dad85  vmovaps xmm9, [rsp+0x80]
00007fb1689dad8e  vmovaps xmm10, [rsp+0x90]
00007fb1689dad97  vmovaps xmm11, [rsp+0xA0]
00007fb1689dada0  vmovaps xmm12, [rsp+0xB0]
00007fb1689dada9  vmovaps xmm13, [rsp+0xC0]
00007fb1689dadb2  vmovaps xmm14, [rsp+0xD0]
00007fb1689dadbb  vmovaps xmm15, [rsp+0xE0]
00007fb1689dadc4  add rsp, 0xF0
00007fb1689dadcb  pop r11
00007fb1689dadcd  pop r10
00007fb1689dadcf  pop r9
00007fb1689dadd1  pop r8
00007fb1689dadd3  pop rsi
00007fb1689dadd4  pop rdi
00007fb1689dadd5  pop rdx
00007fb1689dadd6  pop rcx
00007fb1689dadd7  pop rax
00007fb1689dadd8  add rsp, 0x08
00007fb1689daddc  jmp 0x00007FB1689D8FAB
00007fb1689dade1  call 0x00007FB1688E5820
00007fb1689dade6  jmp 0x00007FB1689D8FB8
00007fb1689dadeb  sub rsp, 0x08
00007fb1689dadef  push rax
00007fb1689dadf0  push rcx
00007fb1689dadf1  push rdx
00007fb1689dadf2  push rdi
00007fb1689dadf3  push rsi
00007fb1689dadf4  push r8
00007fb1689dadf6  push r9
00007fb1689dadf8  push r10
00007fb1689dadfa  push r11
00007fb1689dadfc  sub rsp, 0xF0
00007fb1689dae03  vmovaps [rsp], xmm0
00007fb1689dae08  vmovaps [rsp+0x10], xmm2
00007fb1689dae0e  vmovaps [rsp+0x20], xmm3
00007fb1689dae14  vmovaps [rsp+0x30], xmm4
00007fb1689dae1a  vmovaps [rsp+0x40], xmm5
00007fb1689dae20  vmovaps [rsp+0x50], xmm6
00007fb1689dae26  vmovaps [rsp+0x60], xmm7
00007fb1689dae2c  vmovaps [rsp+0x70], xmm8
00007fb1689dae32  vmovaps [rsp+0x80], xmm9
00007fb1689dae3b  vmovaps [rsp+0x90], xmm10
00007fb1689dae44  vmovaps [rsp+0xA0], xmm11
00007fb1689dae4d  vmovaps [rsp+0xB0], xmm12
00007fb1689dae56  vmovaps [rsp+0xC0], xmm13
00007fb1689dae5f  vmovaps [rsp+0xD0], xmm14
00007fb1689dae68  vmovaps [rsp+0xE0], xmm15
00007fb1689dae71  sub rsp, 0x30
00007fb1689dae75  movaps [rsp], xmm1
00007fb1689dae79  movaps [rsp+0x10], xmm5
00007fb1689dae7e  movaps [rsp+0x20], xmm7
00007fb1689dae83  lea rdi, [rsp]
00007fb1689dae87  mov esi, 0x00
00007fb1689dae8c  mov rax, 0x57CCFD419530
00007fb1689dae96  call rax
00007fb1689dae98  movaps xmm1, [rsp]
00007fb1689dae9c  add rsp, 0x30
00007fb1689daea0  vmovaps xmm0, [rsp]
00007fb1689daea5  vmovaps xmm2, [rsp+0x10]
00007fb1689daeab  vmovaps xmm3, [rsp+0x20]
00007fb1689daeb1  vmovaps xmm4, [rsp+0x30]
00007fb1689daeb7  vmovaps xmm5, [rsp+0x40]
00007fb1689daebd  vmovaps xmm6, [rsp+0x50]
00007fb1689daec3  vmovaps xmm7, [rsp+0x60]
00007fb1689daec9  vmovaps xmm8, [rsp+0x70]
00007fb1689daecf  vmovaps xmm9, [rsp+0x80]
00007fb1689daed8  vmovaps xmm10, [rsp+0x90]
00007fb1689daee1  vmovaps xmm11, [rsp+0xA0]
00007fb1689daeea  vmovaps xmm12, [rsp+0xB0]
00007fb1689daef3  vmovaps xmm13, [rsp+0xC0]
00007fb1689daefc  vmovaps xmm14, [rsp+0xD0]
00007fb1689daf05  vmovaps xmm15, [rsp+0xE0]
00007fb1689daf0e  add rsp, 0xF0
00007fb1689daf15  pop r11
00007fb1689daf17  pop r10
00007fb1689daf19  pop r9
00007fb1689daf1b  pop r8
00007fb1689daf1d  pop rsi
00007fb1689daf1e  pop rdi
00007fb1689daf1f  pop rdx
00007fb1689daf20  pop rcx
00007fb1689daf21  pop rax
00007fb1689daf22  add rsp, 0x08
00007fb1689daf26  jmp 0x00007FB1689D905D
00007fb1689daf2b  sub rsp, 0x08
00007fb1689daf2f  push rax
00007fb1689daf30  push rcx
00007fb1689daf31  push rdx
00007fb1689daf32  push rdi
00007fb1689daf33  push rsi
00007fb1689daf34  push r8
00007fb1689daf36  push r9
00007fb1689daf38  push r10
00007fb1689daf3a  push r11
00007fb1689daf3c  sub rsp, 0xF0
00007fb1689daf43  vmovaps [rsp], xmm0
00007fb1689daf48  vmovaps [rsp+0x10], xmm1
00007fb1689daf4e  vmovaps [rsp+0x20], xmm2
00007fb1689daf54  vmovaps [rsp+0x30], xmm3
00007fb1689daf5a  vmovaps [rsp+0x40], xmm4
00007fb1689daf60  vmovaps [rsp+0x50], xmm5
00007fb1689daf66  vmovaps [rsp+0x60], xmm6
00007fb1689daf6c  vmovaps [rsp+0x70], xmm8
00007fb1689daf72  vmovaps [rsp+0x80], xmm9
00007fb1689daf7b  vmovaps [rsp+0x90], xmm10
00007fb1689daf84  vmovaps [rsp+0xA0], xmm11
00007fb1689daf8d  vmovaps [rsp+0xB0], xmm12
00007fb1689daf96  vmovaps [rsp+0xC0], xmm13
00007fb1689daf9f  vmovaps [rsp+0xD0], xmm14
00007fb1689dafa8  vmovaps [rsp+0xE0], xmm15
00007fb1689dafb1  sub rsp, 0x30
00007fb1689dafb5  movaps [rsp], xmm7
00007fb1689dafb9  movaps [rsp+0x10], xmm5
00007fb1689dafbe  movaps [rsp+0x20], xmm15
00007fb1689dafc4  lea rdi, [rsp]
00007fb1689dafc8  mov esi, 0x00
00007fb1689dafcd  mov rax, 0x57CCFD419530
00007fb1689dafd7  call rax
00007fb1689dafd9  movaps xmm7, [rsp]
00007fb1689dafdd  add rsp, 0x30
00007fb1689dafe1  vmovaps xmm0, [rsp]
00007fb1689dafe6  vmovaps xmm1, [rsp+0x10]
00007fb1689dafec  vmovaps xmm2, [rsp+0x20]
00007fb1689daff2  vmovaps xmm3, [rsp+0x30]
00007fb1689daff8  vmovaps xmm4, [rsp+0x40]
00007fb1689daffe  vmovaps xmm5, [rsp+0x50]
00007fb1689db004  vmovaps xmm6, [rsp+0x60]
00007fb1689db00a  vmovaps xmm8, [rsp+0x70]
00007fb1689db010  vmovaps xmm9, [rsp+0x80]
00007fb1689db019  vmovaps xmm10, [rsp+0x90]
00007fb1689db022  vmovaps xmm11, [rsp+0xA0]
00007fb1689db02b  vmovaps xmm12, [rsp+0xB0]
00007fb1689db034  vmovaps xmm13, [rsp+0xC0]
00007fb1689db03d  vmovaps xmm14, [rsp+0xD0]
00007fb1689db046  vmovaps xmm15, [rsp+0xE0]
00007fb1689db04f  add rsp, 0xF0
00007fb1689db056  pop r11
00007fb1689db058  pop r10
00007fb1689db05a  pop r9
00007fb1689db05c  pop r8
00007fb1689db05e  pop rsi
00007fb1689db05f  pop rdi
00007fb1689db060  pop rdx
00007fb1689db061  pop rcx
00007fb1689db062  pop rax
00007fb1689db063  add rsp, 0x08
00007fb1689db067  jmp 0x00007FB1689D9093
00007fb1689db06c  call 0x00007FB1688D64F0
00007fb1689db071  jmp 0x00007FB1689D90A0
00007fb1689db076  sub rsp, 0x08
00007fb1689db07a  push rax
00007fb1689db07b  push rcx
00007fb1689db07c  push rdx
00007fb1689db07d  push rdi
00007fb1689db07e  push rsi
00007fb1689db07f  push r8
00007fb1689db081  push r9
00007fb1689db083  push r10
00007fb1689db085  push r11
00007fb1689db087  sub rsp, 0xF0
00007fb1689db08e  vmovaps [rsp], xmm0
00007fb1689db093  vmovaps [rsp+0x10], xmm1
00007fb1689db099  vmovaps [rsp+0x20], xmm2
00007fb1689db09f  vmovaps [rsp+0x30], xmm3
00007fb1689db0a5  vmovaps [rsp+0x40], xmm4
00007fb1689db0ab  vmovaps [rsp+0x50], xmm5
00007fb1689db0b1  vmovaps [rsp+0x60], xmm6
00007fb1689db0b7  vmovaps [rsp+0x70], xmm7
00007fb1689db0bd  vmovaps [rsp+0x80], xmm8
00007fb1689db0c6  vmovaps [rsp+0x90], xmm9
00007fb1689db0cf  vmovaps [rsp+0xA0], xmm10
00007fb1689db0d8  vmovaps [rsp+0xB0], xmm11
00007fb1689db0e1  vmovaps [rsp+0xC0], xmm12
00007fb1689db0ea  vmovaps [rsp+0xD0], xmm13
00007fb1689db0f3  vmovaps [rsp+0xE0], xmm14
00007fb1689db0fc  sub rsp, 0x30
00007fb1689db100  movaps [rsp], xmm15
00007fb1689db105  movaps [rsp+0x10], xmm5
00007fb1689db10a  movaps [rsp+0x20], xmm3
00007fb1689db10f  lea rdi, [rsp]
00007fb1689db113  mov esi, 0x00
00007fb1689db118  mov rax, 0x57CCFD419530
00007fb1689db122  call rax
00007fb1689db124  movaps xmm15, [rsp]
00007fb1689db129  add rsp, 0x30
00007fb1689db12d  vmovaps xmm0, [rsp]
00007fb1689db132  vmovaps xmm1, [rsp+0x10]
00007fb1689db138  vmovaps xmm2, [rsp+0x20]
00007fb1689db13e  vmovaps xmm3, [rsp+0x30]
00007fb1689db144  vmovaps xmm4, [rsp+0x40]
00007fb1689db14a  vmovaps xmm5, [rsp+0x50]
00007fb1689db150  vmovaps xmm6, [rsp+0x60]
00007fb1689db156  vmovaps xmm7, [rsp+0x70]
00007fb1689db15c  vmovaps xmm8, [rsp+0x80]
00007fb1689db165  vmovaps xmm9, [rsp+0x90]
00007fb1689db16e  vmovaps xmm10, [rsp+0xA0]
00007fb1689db177  vmovaps xmm11, [rsp+0xB0]
00007fb1689db180  vmovaps xmm12, [rsp+0xC0]
00007fb1689db189  vmovaps xmm13, [rsp+0xD0]
00007fb1689db192  vmovaps xmm14, [rsp+0xE0]
00007fb1689db19b  add rsp, 0xF0
00007fb1689db1a2  pop r11
00007fb1689db1a4  pop r10
00007fb1689db1a6  pop r9
00007fb1689db1a8  pop r8
00007fb1689db1aa  pop rsi
00007fb1689db1ab  pop rdi
00007fb1689db1ac  pop rdx
00007fb1689db1ad  pop rcx
00007fb1689db1ae  pop rax
00007fb1689db1af  add rsp, 0x08
00007fb1689db1b3  jmp 0x00007FB1689D90C6
00007fb1689db1b8  sub rsp, 0x08
00007fb1689db1bc  push rax
00007fb1689db1bd  push rcx
00007fb1689db1be  push rdx
00007fb1689db1bf  push rdi
00007fb1689db1c0  push rsi
00007fb1689db1c1  push r8
00007fb1689db1c3  push r9
00007fb1689db1c5  push r10
00007fb1689db1c7  push r11
00007fb1689db1c9  sub rsp, 0xF0
00007fb1689db1d0  vmovaps [rsp], xmm0
00007fb1689db1d5  vmovaps [rsp+0x10], xmm2
00007fb1689db1db  vmovaps [rsp+0x20], xmm3
00007fb1689db1e1  vmovaps [rsp+0x30], xmm4
00007fb1689db1e7  vmovaps [rsp+0x40], xmm5
00007fb1689db1ed  vmovaps [rsp+0x50], xmm6
00007fb1689db1f3  vmovaps [rsp+0x60], xmm7
00007fb1689db1f9  vmovaps [rsp+0x70], xmm8
00007fb1689db1ff  vmovaps [rsp+0x80], xmm9
00007fb1689db208  vmovaps [rsp+0x90], xmm10
00007fb1689db211  vmovaps [rsp+0xA0], xmm11
00007fb1689db21a  vmovaps [rsp+0xB0], xmm12
00007fb1689db223  vmovaps [rsp+0xC0], xmm13
00007fb1689db22c  vmovaps [rsp+0xD0], xmm14
00007fb1689db235  vmovaps [rsp+0xE0], xmm15
00007fb1689db23e  sub rsp, 0x30
00007fb1689db242  movaps [rsp], xmm1
00007fb1689db246  movaps [rsp+0x10], xmm5
00007fb1689db24b  movaps [rsp+0x20], xmm4
00007fb1689db250  lea rdi, [rsp]
00007fb1689db254  mov esi, 0x00
00007fb1689db259  mov rax, 0x57CCFD419530
00007fb1689db263  call rax
00007fb1689db265  movaps xmm1, [rsp]
00007fb1689db269  add rsp, 0x30
00007fb1689db26d  vmovaps xmm0, [rsp]
00007fb1689db272  vmovaps xmm2, [rsp+0x10]
00007fb1689db278  vmovaps xmm3, [rsp+0x20]
00007fb1689db27e  vmovaps xmm4, [rsp+0x30]
00007fb1689db284  vmovaps xmm5, [rsp+0x40]
00007fb1689db28a  vmovaps xmm6, [rsp+0x50]
00007fb1689db290  vmovaps xmm7, [rsp+0x60]
00007fb1689db296  vmovaps xmm8, [rsp+0x70]
00007fb1689db29c  vmovaps xmm9, [rsp+0x80]
00007fb1689db2a5  vmovaps xmm10, [rsp+0x90]
00007fb1689db2ae  vmovaps xmm11, [rsp+0xA0]
00007fb1689db2b7  vmovaps xmm12, [rsp+0xB0]
00007fb1689db2c0  vmovaps xmm13, [rsp+0xC0]
00007fb1689db2c9  vmovaps xmm14, [rsp+0xD0]
00007fb1689db2d2  vmovaps xmm15, [rsp+0xE0]
00007fb1689db2db  add rsp, 0xF0
00007fb1689db2e2  pop r11
00007fb1689db2e4  pop r10
00007fb1689db2e6  pop r9
00007fb1689db2e8  pop r8
00007fb1689db2ea  pop rsi
00007fb1689db2eb  pop rdi
00007fb1689db2ec  pop rdx
00007fb1689db2ed  pop rcx
00007fb1689db2ee  pop rax
00007fb1689db2ef  add rsp, 0x08
00007fb1689db2f3  jmp 0x00007FB1689D90E6
00007fb1689db2f8  sub rsp, 0x08
00007fb1689db2fc  push rax
00007fb1689db2fd  push rcx
00007fb1689db2fe  push rdx
00007fb1689db2ff  push rdi
00007fb1689db300  push rsi
00007fb1689db301  push r8
00007fb1689db303  push r9
00007fb1689db305  push r10
00007fb1689db307  push r11
00007fb1689db309  sub rsp, 0xF0
00007fb1689db310  vmovaps [rsp], xmm0
00007fb1689db315  vmovaps [rsp+0x10], xmm1
00007fb1689db31b  vmovaps [rsp+0x20], xmm2
00007fb1689db321  vmovaps [rsp+0x30], xmm3
00007fb1689db327  vmovaps [rsp+0x40], xmm5
00007fb1689db32d  vmovaps [rsp+0x50], xmm6
00007fb1689db333  vmovaps [rsp+0x60], xmm7
00007fb1689db339  vmovaps [rsp+0x70], xmm8
00007fb1689db33f  vmovaps [rsp+0x80], xmm9
00007fb1689db348  vmovaps [rsp+0x90], xmm10
00007fb1689db351  vmovaps [rsp+0xA0], xmm11
00007fb1689db35a  vmovaps [rsp+0xB0], xmm12
00007fb1689db363  vmovaps [rsp+0xC0], xmm13
00007fb1689db36c  vmovaps [rsp+0xD0], xmm14
00007fb1689db375  vmovaps [rsp+0xE0], xmm15
00007fb1689db37e  sub rsp, 0x30
00007fb1689db382  movaps [rsp], xmm4
00007fb1689db386  movaps [rsp+0x10], xmm3
00007fb1689db38b  movaps [rsp+0x20], xmm5
00007fb1689db390  lea rdi, [rsp]
00007fb1689db394  mov esi, 0x00
00007fb1689db399  mov rax, 0x57CCFD419530
00007fb1689db3a3  call rax
00007fb1689db3a5  movaps xmm4, [rsp]
00007fb1689db3a9  add rsp, 0x30
00007fb1689db3ad  vmovaps xmm0, [rsp]
00007fb1689db3b2  vmovaps xmm1, [rsp+0x10]
00007fb1689db3b8  vmovaps xmm2, [rsp+0x20]
00007fb1689db3be  vmovaps xmm3, [rsp+0x30]
00007fb1689db3c4  vmovaps xmm5, [rsp+0x40]
00007fb1689db3ca  vmovaps xmm6, [rsp+0x50]
00007fb1689db3d0  vmovaps xmm7, [rsp+0x60]
00007fb1689db3d6  vmovaps xmm8, [rsp+0x70]
00007fb1689db3dc  vmovaps xmm9, [rsp+0x80]
00007fb1689db3e5  vmovaps xmm10, [rsp+0x90]
00007fb1689db3ee  vmovaps xmm11, [rsp+0xA0]
00007fb1689db3f7  vmovaps xmm12, [rsp+0xB0]
00007fb1689db400  vmovaps xmm13, [rsp+0xC0]
00007fb1689db409  vmovaps xmm14, [rsp+0xD0]
00007fb1689db412  vmovaps xmm15, [rsp+0xE0]
00007fb1689db41b  add rsp, 0xF0
00007fb1689db422  pop r11
00007fb1689db424  pop r10
00007fb1689db426  pop r9
00007fb1689db428  pop r8
00007fb1689db42a  pop rsi
00007fb1689db42b  pop rdi
00007fb1689db42c  pop rdx
00007fb1689db42d  pop rcx
00007fb1689db42e  pop rax
00007fb1689db42f  add rsp, 0x08
00007fb1689db433  jmp 0x00007FB1689D9134
00007fb1689db438  call 0x00007FB1688D64F0
00007fb1689db43d  jmp 0x00007FB1689D9141
00007fb1689db442  sub rsp, 0x08
00007fb1689db446  push rax
00007fb1689db447  push rcx
00007fb1689db448  push rdx
00007fb1689db449  push rdi
00007fb1689db44a  push rsi
00007fb1689db44b  push r8
00007fb1689db44d  push r9
00007fb1689db44f  push r10
00007fb1689db451  push r11
00007fb1689db453  sub rsp, 0xF0
00007fb1689db45a  vmovaps [rsp], xmm0
00007fb1689db45f  vmovaps [rsp+0x10], xmm1
00007fb1689db465  vmovaps [rsp+0x20], xmm2
00007fb1689db46b  vmovaps [rsp+0x30], xmm3
00007fb1689db471  vmovaps [rsp+0x40], xmm4
00007fb1689db477  vmovaps [rsp+0x50], xmm6
00007fb1689db47d  vmovaps [rsp+0x60], xmm7
00007fb1689db483  vmovaps [rsp+0x70], xmm8
00007fb1689db489  vmovaps [rsp+0x80], xmm9
00007fb1689db492  vmovaps [rsp+0x90], xmm10
00007fb1689db49b  vmovaps [rsp+0xA0], xmm11
00007fb1689db4a4  vmovaps [rsp+0xB0], xmm12
00007fb1689db4ad  vmovaps [rsp+0xC0], xmm13
00007fb1689db4b6  vmovaps [rsp+0xD0], xmm14
00007fb1689db4bf  vmovaps [rsp+0xE0], xmm15
00007fb1689db4c8  sub rsp, 0x30
00007fb1689db4cc  movaps [rsp], xmm5
00007fb1689db4d0  movaps [rsp+0x10], xmm6
00007fb1689db4d5  movaps [rsp+0x20], xmm3
00007fb1689db4da  lea rdi, [rsp]
00007fb1689db4de  mov esi, 0x00
00007fb1689db4e3  mov rax, 0x57CCFD419530
00007fb1689db4ed  call rax
00007fb1689db4ef  movaps xmm5, [rsp]
00007fb1689db4f3  add rsp, 0x30
00007fb1689db4f7  vmovaps xmm0, [rsp]
00007fb1689db4fc  vmovaps xmm1, [rsp+0x10]
00007fb1689db502  vmovaps xmm2, [rsp+0x20]
00007fb1689db508  vmovaps xmm3, [rsp+0x30]
00007fb1689db50e  vmovaps xmm4, [rsp+0x40]
00007fb1689db514  vmovaps xmm6, [rsp+0x50]
00007fb1689db51a  vmovaps xmm7, [rsp+0x60]
00007fb1689db520  vmovaps xmm8, [rsp+0x70]
00007fb1689db526  vmovaps xmm9, [rsp+0x80]
00007fb1689db52f  vmovaps xmm10, [rsp+0x90]
00007fb1689db538  vmovaps xmm11, [rsp+0xA0]
00007fb1689db541  vmovaps xmm12, [rsp+0xB0]
00007fb1689db54a  vmovaps xmm13, [rsp+0xC0]
00007fb1689db553  vmovaps xmm14, [rsp+0xD0]
00007fb1689db55c  vmovaps xmm15, [rsp+0xE0]
00007fb1689db565  add rsp, 0xF0
00007fb1689db56c  pop r11
00007fb1689db56e  pop r10
00007fb1689db570  pop r9
00007fb1689db572  pop r8
00007fb1689db574  pop rsi
00007fb1689db575  pop rdi
00007fb1689db576  pop rdx
00007fb1689db577  pop rcx
00007fb1689db578  pop rax
00007fb1689db579  add rsp, 0x08
00007fb1689db57d  jmp 0x00007FB1689D9167
00007fb1689db582  sub rsp, 0x08
00007fb1689db586  push rax
00007fb1689db587  push rcx
00007fb1689db588  push rdx
00007fb1689db589  push rdi
00007fb1689db58a  push rsi
00007fb1689db58b  push r8
00007fb1689db58d  push r9
00007fb1689db58f  push r10
00007fb1689db591  push r11
00007fb1689db593  sub rsp, 0xF0
00007fb1689db59a  vmovaps [rsp], xmm0
00007fb1689db59f  vmovaps [rsp+0x10], xmm1
00007fb1689db5a5  vmovaps [rsp+0x20], xmm2
00007fb1689db5ab  vmovaps [rsp+0x30], xmm3
00007fb1689db5b1  vmovaps [rsp+0x40], xmm4
00007fb1689db5b7  vmovaps [rsp+0x50], xmm5
00007fb1689db5bd  vmovaps [rsp+0x60], xmm7
00007fb1689db5c3  vmovaps [rsp+0x70], xmm8
00007fb1689db5c9  vmovaps [rsp+0x80], xmm9
00007fb1689db5d2  vmovaps [rsp+0x90], xmm10
00007fb1689db5db  vmovaps [rsp+0xA0], xmm11
00007fb1689db5e4  vmovaps [rsp+0xB0], xmm12
00007fb1689db5ed  vmovaps [rsp+0xC0], xmm13
00007fb1689db5f6  vmovaps [rsp+0xD0], xmm14
00007fb1689db5ff  vmovaps [rsp+0xE0], xmm15
00007fb1689db608  sub rsp, 0x30
00007fb1689db60c  movaps [rsp], xmm6
00007fb1689db610  movaps [rsp+0x10], xmm9
00007fb1689db616  movaps [rsp+0x20], xmm1
00007fb1689db61b  lea rdi, [rsp]
00007fb1689db61f  mov esi, 0x00
00007fb1689db624  mov rax, 0x57CCFD419530
00007fb1689db62e  call rax
00007fb1689db630  movaps xmm6, [rsp]
00007fb1689db634  add rsp, 0x30
00007fb1689db638  vmovaps xmm0, [rsp]
00007fb1689db63d  vmovaps xmm1, [rsp+0x10]
00007fb1689db643  vmovaps xmm2, [rsp+0x20]
00007fb1689db649  vmovaps xmm3, [rsp+0x30]
00007fb1689db64f  vmovaps xmm4, [rsp+0x40]
00007fb1689db655  vmovaps xmm5, [rsp+0x50]
00007fb1689db65b  vmovaps xmm7, [rsp+0x60]
00007fb1689db661  vmovaps xmm8, [rsp+0x70]
00007fb1689db667  vmovaps xmm9, [rsp+0x80]
00007fb1689db670  vmovaps xmm10, [rsp+0x90]
00007fb1689db679  vmovaps xmm11, [rsp+0xA0]
00007fb1689db682  vmovaps xmm12, [rsp+0xB0]
00007fb1689db68b  vmovaps xmm13, [rsp+0xC0]
00007fb1689db694  vmovaps xmm14, [rsp+0xD0]
00007fb1689db69d  vmovaps xmm15, [rsp+0xE0]
00007fb1689db6a6  add rsp, 0xF0
00007fb1689db6ad  pop r11
00007fb1689db6af  pop r10
00007fb1689db6b1  pop r9
00007fb1689db6b3  pop r8
00007fb1689db6b5  pop rsi
00007fb1689db6b6  pop rdi
00007fb1689db6b7  pop rdx
00007fb1689db6b8  pop rcx
00007fb1689db6b9  pop rax
00007fb1689db6ba  add rsp, 0x08
00007fb1689db6be  jmp 0x00007FB1689D918B
00007fb1689db6c3  sub rsp, 0x08
00007fb1689db6c7  push rax
00007fb1689db6c8  push rcx
00007fb1689db6c9  push rdx
00007fb1689db6ca  push rdi
00007fb1689db6cb  push rsi
00007fb1689db6cc  push r8
00007fb1689db6ce  push r9
00007fb1689db6d0  push r10
00007fb1689db6d2  push r11
00007fb1689db6d4  sub rsp, 0xF0
00007fb1689db6db  vmovaps [rsp], xmm0
00007fb1689db6e0  vmovaps [rsp+0x10], xmm1
00007fb1689db6e6  vmovaps [rsp+0x20], xmm2
00007fb1689db6ec  vmovaps [rsp+0x30], xmm3
00007fb1689db6f2  vmovaps [rsp+0x40], xmm4
00007fb1689db6f8  vmovaps [rsp+0x50], xmm5
00007fb1689db6fe  vmovaps [rsp+0x60], xmm6
00007fb1689db704  vmovaps [rsp+0x70], xmm7
00007fb1689db70a  vmovaps [rsp+0x80], xmm8
00007fb1689db713  vmovaps [rsp+0x90], xmm10
00007fb1689db71c  vmovaps [rsp+0xA0], xmm11
00007fb1689db725  vmovaps [rsp+0xB0], xmm12
00007fb1689db72e  vmovaps [rsp+0xC0], xmm13
00007fb1689db737  vmovaps [rsp+0xD0], xmm14
00007fb1689db740  vmovaps [rsp+0xE0], xmm15
00007fb1689db749  sub rsp, 0x30
00007fb1689db74d  movaps [rsp], xmm9
00007fb1689db752  movaps [rsp+0x10], xmm3
00007fb1689db757  movaps [rsp+0x20], xmm1
00007fb1689db75c  lea rdi, [rsp]
00007fb1689db760  mov esi, 0x00
00007fb1689db765  mov rax, 0x57CCFD419530
00007fb1689db76f  call rax
00007fb1689db771  movaps xmm9, [rsp]
00007fb1689db776  add rsp, 0x30
00007fb1689db77a  vmovaps xmm0, [rsp]
00007fb1689db77f  vmovaps xmm1, [rsp+0x10]
00007fb1689db785  vmovaps xmm2, [rsp+0x20]
00007fb1689db78b  vmovaps xmm3, [rsp+0x30]
00007fb1689db791  vmovaps xmm4, [rsp+0x40]
00007fb1689db797  vmovaps xmm5, [rsp+0x50]
00007fb1689db79d  vmovaps xmm6, [rsp+0x60]
00007fb1689db7a3  vmovaps xmm7, [rsp+0x70]
00007fb1689db7a9  vmovaps xmm8, [rsp+0x80]
00007fb1689db7b2  vmovaps xmm10, [rsp+0x90]
00007fb1689db7bb  vmovaps xmm11, [rsp+0xA0]
00007fb1689db7c4  vmovaps xmm12, [rsp+0xB0]
00007fb1689db7cd  vmovaps xmm13, [rsp+0xC0]
00007fb1689db7d6  vmovaps xmm14, [rsp+0xD0]
00007fb1689db7df  vmovaps xmm15, [rsp+0xE0]
00007fb1689db7e8  add rsp, 0xF0
00007fb1689db7ef  pop r11
00007fb1689db7f1  pop r10
00007fb1689db7f3  pop r9
00007fb1689db7f5  pop r8
00007fb1689db7f7  pop rsi
00007fb1689db7f8  pop rdi
00007fb1689db7f9  pop rdx
00007fb1689db7fa  pop rcx
00007fb1689db7fb  pop rax
00007fb1689db7fc  add rsp, 0x08
00007fb1689db800  jmp 0x00007FB1689D91D7
00007fb1689db805  call 0x00007FB1688D64F0
00007fb1689db80a  jmp 0x00007FB1689D91E4
00007fb1689db80f  sub rsp, 0x08
00007fb1689db813  push rax
00007fb1689db814  push rcx
00007fb1689db815  push rdx
00007fb1689db816  push rdi
00007fb1689db817  push rsi
00007fb1689db818  push r8
00007fb1689db81a  push r9
00007fb1689db81c  push r10
00007fb1689db81e  push r11
00007fb1689db820  sub rsp, 0xF0
00007fb1689db827  vmovaps [rsp], xmm0
00007fb1689db82c  vmovaps [rsp+0x10], xmm1
00007fb1689db832  vmovaps [rsp+0x20], xmm2
00007fb1689db838  vmovaps [rsp+0x30], xmm3
00007fb1689db83e  vmovaps [rsp+0x40], xmm4
00007fb1689db844  vmovaps [rsp+0x50], xmm5
00007fb1689db84a  vmovaps [rsp+0x60], xmm6
00007fb1689db850  vmovaps [rsp+0x70], xmm7
00007fb1689db856  vmovaps [rsp+0x80], xmm8
00007fb1689db85f  vmovaps [rsp+0x90], xmm9
00007fb1689db868  vmovaps [rsp+0xA0], xmm10
00007fb1689db871  vmovaps [rsp+0xB0], xmm11
00007fb1689db87a  vmovaps [rsp+0xC0], xmm12
00007fb1689db883  vmovaps [rsp+0xD0], xmm13
00007fb1689db88c  vmovaps [rsp+0xE0], xmm14
00007fb1689db895  sub rsp, 0x30
00007fb1689db899  movaps [rsp], xmm15
00007fb1689db89e  movaps [rsp+0x10], xmm3
00007fb1689db8a3  movaps [rsp+0x20], xmm7
00007fb1689db8a8  lea rdi, [rsp]
00007fb1689db8ac  mov esi, 0x00
00007fb1689db8b1  mov rax, 0x57CCFD419530
00007fb1689db8bb  call rax
00007fb1689db8bd  movaps xmm15, [rsp]
00007fb1689db8c2  add rsp, 0x30
00007fb1689db8c6  vmovaps xmm0, [rsp]
00007fb1689db8cb  vmovaps xmm1, [rsp+0x10]
00007fb1689db8d1  vmovaps xmm2, [rsp+0x20]
00007fb1689db8d7  vmovaps xmm3, [rsp+0x30]
00007fb1689db8dd  vmovaps xmm4, [rsp+0x40]
00007fb1689db8e3  vmovaps xmm5, [rsp+0x50]
00007fb1689db8e9  vmovaps xmm6, [rsp+0x60]
00007fb1689db8ef  vmovaps xmm7, [rsp+0x70]
00007fb1689db8f5  vmovaps xmm8, [rsp+0x80]
00007fb1689db8fe  vmovaps xmm9, [rsp+0x90]
00007fb1689db907  vmovaps xmm10, [rsp+0xA0]
00007fb1689db910  vmovaps xmm11, [rsp+0xB0]
00007fb1689db919  vmovaps xmm12, [rsp+0xC0]
00007fb1689db922  vmovaps xmm13, [rsp+0xD0]
00007fb1689db92b  vmovaps xmm14, [rsp+0xE0]
00007fb1689db934  add rsp, 0xF0
00007fb1689db93b  pop r11
00007fb1689db93d  pop r10
00007fb1689db93f  pop r9
00007fb1689db941  pop r8
00007fb1689db943  pop rsi
00007fb1689db944  pop rdi
00007fb1689db945  pop rdx
00007fb1689db946  pop rcx
00007fb1689db947  pop rax
00007fb1689db948  add rsp, 0x08
00007fb1689db94c  jmp 0x00007FB1689D9210
00007fb1689db951  sub rsp, 0x08
00007fb1689db955  push rax
00007fb1689db956  push rcx
00007fb1689db957  push rdx
00007fb1689db958  push rdi
00007fb1689db959  push rsi
00007fb1689db95a  push r8
00007fb1689db95c  push r9
00007fb1689db95e  push r10
00007fb1689db960  push r11
00007fb1689db962  sub rsp, 0xF0
00007fb1689db969  vmovaps [rsp], xmm0
00007fb1689db96e  vmovaps [rsp+0x10], xmm1
00007fb1689db974  vmovaps [rsp+0x20], xmm2
00007fb1689db97a  vmovaps [rsp+0x30], xmm4
00007fb1689db980  vmovaps [rsp+0x40], xmm5
00007fb1689db986  vmovaps [rsp+0x50], xmm6
00007fb1689db98c  vmovaps [rsp+0x60], xmm7
00007fb1689db992  vmovaps [rsp+0x70], xmm8
00007fb1689db998  vmovaps [rsp+0x80], xmm9
00007fb1689db9a1  vmovaps [rsp+0x90], xmm10
00007fb1689db9aa  vmovaps [rsp+0xA0], xmm11
00007fb1689db9b3  vmovaps [rsp+0xB0], xmm12
00007fb1689db9bc  vmovaps [rsp+0xC0], xmm13
00007fb1689db9c5  vmovaps [rsp+0xD0], xmm14
00007fb1689db9ce  vmovaps [rsp+0xE0], xmm15
00007fb1689db9d7  sub rsp, 0x30
00007fb1689db9db  movaps [rsp], xmm3
00007fb1689db9df  movaps [rsp+0x10], xmm1
00007fb1689db9e4  movaps [rsp+0x20], xmm15
00007fb1689db9ea  lea rdi, [rsp]
00007fb1689db9ee  mov esi, 0x00
00007fb1689db9f3  mov rax, 0x57CCFD419530
00007fb1689db9fd  call rax
00007fb1689db9ff  movaps xmm3, [rsp]
00007fb1689dba03  add rsp, 0x30
00007fb1689dba07  vmovaps xmm0, [rsp]
00007fb1689dba0c  vmovaps xmm1, [rsp+0x10]
00007fb1689dba12  vmovaps xmm2, [rsp+0x20]
00007fb1689dba18  vmovaps xmm4, [rsp+0x30]
00007fb1689dba1e  vmovaps xmm5, [rsp+0x40]
00007fb1689dba24  vmovaps xmm6, [rsp+0x50]
00007fb1689dba2a  vmovaps xmm7, [rsp+0x60]
00007fb1689dba30  vmovaps xmm8, [rsp+0x70]
00007fb1689dba36  vmovaps xmm9, [rsp+0x80]
00007fb1689dba3f  vmovaps xmm10, [rsp+0x90]
00007fb1689dba48  vmovaps xmm11, [rsp+0xA0]
00007fb1689dba51  vmovaps xmm12, [rsp+0xB0]
00007fb1689dba5a  vmovaps xmm13, [rsp+0xC0]
00007fb1689dba63  vmovaps xmm14, [rsp+0xD0]
00007fb1689dba6c  vmovaps xmm15, [rsp+0xE0]
00007fb1689dba75  add rsp, 0xF0
00007fb1689dba7c  pop r11
00007fb1689dba7e  pop r10
00007fb1689dba80  pop r9
00007fb1689dba82  pop r8
00007fb1689dba84  pop rsi
00007fb1689dba85  pop rdi
00007fb1689dba86  pop rdx
00007fb1689dba87  pop rcx
00007fb1689dba88  pop rax
00007fb1689dba89  add rsp, 0x08
00007fb1689dba8d  jmp 0x00007FB1689D929F
00007fb1689dba92  call 0x00007FB1688D64F0
00007fb1689dba97  jmp 0x00007FB1689D92A9
00007fb1689dba9c  sub rsp, 0x08
00007fb1689dbaa0  push rax
00007fb1689dbaa1  push rcx
00007fb1689dbaa2  push rdx
00007fb1689dbaa3  push rdi
00007fb1689dbaa4  push rsi
00007fb1689dbaa5  push r8
00007fb1689dbaa7  push r9
00007fb1689dbaa9  push r10
00007fb1689dbaab  push r11
00007fb1689dbaad  sub rsp, 0xF0
00007fb1689dbab4  vmovaps [rsp], xmm0
00007fb1689dbab9  vmovaps [rsp+0x10], xmm1
00007fb1689dbabf  vmovaps [rsp+0x20], xmm2
00007fb1689dbac5  vmovaps [rsp+0x30], xmm3
00007fb1689dbacb  vmovaps [rsp+0x40], xmm4
00007fb1689dbad1  vmovaps [rsp+0x50], xmm5
00007fb1689dbad7  vmovaps [rsp+0x60], xmm6
00007fb1689dbadd  vmovaps [rsp+0x70], xmm7
00007fb1689dbae3  vmovaps [rsp+0x80], xmm8
00007fb1689dbaec  vmovaps [rsp+0x90], xmm9
00007fb1689dbaf5  vmovaps [rsp+0xA0], xmm10
00007fb1689dbafe  vmovaps [rsp+0xB0], xmm11
00007fb1689dbb07  vmovaps [rsp+0xC0], xmm12
00007fb1689dbb10  vmovaps [rsp+0xD0], xmm13
00007fb1689dbb19  vmovaps [rsp+0xE0], xmm14
00007fb1689dbb22  sub rsp, 0x30
00007fb1689dbb26  movaps [rsp], xmm15
00007fb1689dbb2b  movaps [rsp+0x10], xmm14
00007fb1689dbb31  movaps [rsp+0x20], xmm4
00007fb1689dbb36  lea rdi, [rsp]
00007fb1689dbb3a  mov esi, 0x00
00007fb1689dbb3f  mov rax, 0x57CCFD419530
00007fb1689dbb49  call rax
00007fb1689dbb4b  movaps xmm15, [rsp]
00007fb1689dbb50  add rsp, 0x30
00007fb1689dbb54  vmovaps xmm0, [rsp]
00007fb1689dbb59  vmovaps xmm1, [rsp+0x10]
00007fb1689dbb5f  vmovaps xmm2, [rsp+0x20]
00007fb1689dbb65  vmovaps xmm3, [rsp+0x30]
00007fb1689dbb6b  vmovaps xmm4, [rsp+0x40]
00007fb1689dbb71  vmovaps xmm5, [rsp+0x50]
00007fb1689dbb77  vmovaps xmm6, [rsp+0x60]
00007fb1689dbb7d  vmovaps xmm7, [rsp+0x70]
00007fb1689dbb83  vmovaps xmm8, [rsp+0x80]
00007fb1689dbb8c  vmovaps xmm9, [rsp+0x90]
00007fb1689dbb95  vmovaps xmm10, [rsp+0xA0]
00007fb1689dbb9e  vmovaps xmm11, [rsp+0xB0]
00007fb1689dbba7  vmovaps xmm12, [rsp+0xC0]
00007fb1689dbbb0  vmovaps xmm13, [rsp+0xD0]
00007fb1689dbbb9  vmovaps xmm14, [rsp+0xE0]
00007fb1689dbbc2  add rsp, 0xF0
00007fb1689dbbc9  pop r11
00007fb1689dbbcb  pop r10
00007fb1689dbbcd  pop r9
00007fb1689dbbcf  pop r8
00007fb1689dbbd1  pop rsi
00007fb1689dbbd2  pop rdi
00007fb1689dbbd3  pop rdx
00007fb1689dbbd4  pop rcx
00007fb1689dbbd5  pop rax
00007fb1689dbbd6  add rsp, 0x08
00007fb1689dbbda  jmp 0x00007FB1689D92D7
00007fb1689dbbdf  sub rsp, 0x08
00007fb1689dbbe3  push rax
00007fb1689dbbe4  push rcx
00007fb1689dbbe5  push rdx
00007fb1689dbbe6  push rdi
00007fb1689dbbe7  push rsi
00007fb1689dbbe8  push r8
00007fb1689dbbea  push r9
00007fb1689dbbec  push r10
00007fb1689dbbee  push r11
00007fb1689dbbf0  sub rsp, 0xF0
00007fb1689dbbf7  vmovaps [rsp], xmm0
00007fb1689dbbfc  vmovaps [rsp+0x10], xmm1
00007fb1689dbc02  vmovaps [rsp+0x20], xmm2
00007fb1689dbc08  vmovaps [rsp+0x30], xmm3
00007fb1689dbc0e  vmovaps [rsp+0x40], xmm4
00007fb1689dbc14  vmovaps [rsp+0x50], xmm5
00007fb1689dbc1a  vmovaps [rsp+0x60], xmm6
00007fb1689dbc20  vmovaps [rsp+0x70], xmm7
00007fb1689dbc26  vmovaps [rsp+0x80], xmm8
00007fb1689dbc2f  vmovaps [rsp+0x90], xmm9
00007fb1689dbc38  vmovaps [rsp+0xA0], xmm10
00007fb1689dbc41  vmovaps [rsp+0xB0], xmm11
00007fb1689dbc4a  vmovaps [rsp+0xC0], xmm12
00007fb1689dbc53  vmovaps [rsp+0xD0], xmm13
00007fb1689dbc5c  vmovaps [rsp+0xE0], xmm15
00007fb1689dbc65  sub rsp, 0x30
00007fb1689dbc69  movaps [rsp], xmm14
00007fb1689dbc6e  movaps [rsp+0x10], xmm2
00007fb1689dbc73  movaps [rsp+0x20], xmm1
00007fb1689dbc78  lea rdi, [rsp]
00007fb1689dbc7c  mov esi, 0x00
00007fb1689dbc81  mov rax, 0x57CCFD419530
00007fb1689dbc8b  call rax
00007fb1689dbc8d  movaps xmm14, [rsp]
00007fb1689dbc92  add rsp, 0x30
00007fb1689dbc96  vmovaps xmm0, [rsp]
00007fb1689dbc9b  vmovaps xmm1, [rsp+0x10]
00007fb1689dbca1  vmovaps xmm2, [rsp+0x20]
00007fb1689dbca7  vmovaps xmm3, [rsp+0x30]
00007fb1689dbcad  vmovaps xmm4, [rsp+0x40]
00007fb1689dbcb3  vmovaps xmm5, [rsp+0x50]
00007fb1689dbcb9  vmovaps xmm6, [rsp+0x60]
00007fb1689dbcbf  vmovaps xmm7, [rsp+0x70]
00007fb1689dbcc5  vmovaps xmm8, [rsp+0x80]
00007fb1689dbcce  vmovaps xmm9, [rsp+0x90]
00007fb1689dbcd7  vmovaps xmm10, [rsp+0xA0]
00007fb1689dbce0  vmovaps xmm11, [rsp+0xB0]
00007fb1689dbce9  vmovaps xmm12, [rsp+0xC0]
00007fb1689dbcf2  vmovaps xmm13, [rsp+0xD0]
00007fb1689dbcfb  vmovaps xmm15, [rsp+0xE0]
00007fb1689dbd04  add rsp, 0xF0
00007fb1689dbd0b  pop r11
00007fb1689dbd0d  pop r10
00007fb1689dbd0f  pop r9
00007fb1689dbd11  pop r8
00007fb1689dbd13  pop rsi
00007fb1689dbd14  pop rdi
00007fb1689dbd15  pop rdx
00007fb1689dbd16  pop rcx
00007fb1689dbd17  pop rax
00007fb1689dbd18  add rsp, 0x08
00007fb1689dbd1c  jmp 0x00007FB1689D92FD
00007fb1689dbd21  sub rsp, 0x08
00007fb1689dbd25  push rax
00007fb1689dbd26  push rcx
00007fb1689dbd27  push rdx
00007fb1689dbd28  push rdi
00007fb1689dbd29  push rsi
00007fb1689dbd2a  push r8
00007fb1689dbd2c  push r9
00007fb1689dbd2e  push r10
00007fb1689dbd30  push r11
00007fb1689dbd32  sub rsp, 0xF0
00007fb1689dbd39  vmovaps [rsp], xmm0
00007fb1689dbd3e  vmovaps [rsp+0x10], xmm2
00007fb1689dbd44  vmovaps [rsp+0x20], xmm3
00007fb1689dbd4a  vmovaps [rsp+0x30], xmm4
00007fb1689dbd50  vmovaps [rsp+0x40], xmm5
00007fb1689dbd56  vmovaps [rsp+0x50], xmm6
00007fb1689dbd5c  vmovaps [rsp+0x60], xmm7
00007fb1689dbd62  vmovaps [rsp+0x70], xmm8
00007fb1689dbd68  vmovaps [rsp+0x80], xmm9
00007fb1689dbd71  vmovaps [rsp+0x90], xmm10
00007fb1689dbd7a  vmovaps [rsp+0xA0], xmm11
00007fb1689dbd83  vmovaps [rsp+0xB0], xmm12
00007fb1689dbd8c  vmovaps [rsp+0xC0], xmm13
00007fb1689dbd95  vmovaps [rsp+0xD0], xmm14
00007fb1689dbd9e  vmovaps [rsp+0xE0], xmm15
00007fb1689dbda7  sub rsp, 0x30
00007fb1689dbdab  movaps [rsp], xmm1
00007fb1689dbdaf  movaps [rsp+0x10], xmm4
00007fb1689dbdb4  movaps [rsp+0x20], xmm9
00007fb1689dbdba  lea rdi, [rsp]
00007fb1689dbdbe  mov esi, 0x00
00007fb1689dbdc3  mov rax, 0x57CCFD419530
00007fb1689dbdcd  call rax
00007fb1689dbdcf  movaps xmm1, [rsp]
00007fb1689dbdd3  add rsp, 0x30
00007fb1689dbdd7  vmovaps xmm0, [rsp]
00007fb1689dbddc  vmovaps xmm2, [rsp+0x10]
00007fb1689dbde2  vmovaps xmm3, [rsp+0x20]
00007fb1689dbde8  vmovaps xmm4, [rsp+0x30]
00007fb1689dbdee  vmovaps xmm5, [rsp+0x40]
00007fb1689dbdf4  vmovaps xmm6, [rsp+0x50]
00007fb1689dbdfa  vmovaps xmm7, [rsp+0x60]
00007fb1689dbe00  vmovaps xmm8, [rsp+0x70]
00007fb1689dbe06  vmovaps xmm9, [rsp+0x80]
00007fb1689dbe0f  vmovaps xmm10, [rsp+0x90]
00007fb1689dbe18  vmovaps xmm11, [rsp+0xA0]
00007fb1689dbe21  vmovaps xmm12, [rsp+0xB0]
00007fb1689dbe2a  vmovaps xmm13, [rsp+0xC0]
00007fb1689dbe33  vmovaps xmm14, [rsp+0xD0]
00007fb1689dbe3c  vmovaps xmm15, [rsp+0xE0]
00007fb1689dbe45  add rsp, 0xF0
00007fb1689dbe4c  pop r11
00007fb1689dbe4e  pop r10
00007fb1689dbe50  pop r9
00007fb1689dbe52  pop r8
00007fb1689dbe54  pop rsi
00007fb1689dbe55  pop rdi
00007fb1689dbe56  pop rdx
00007fb1689dbe57  pop rcx
00007fb1689dbe58  pop rax
00007fb1689dbe59  add rsp, 0x08
00007fb1689dbe5d  jmp 0x00007FB1689D931B
00007fb1689dbe62  sub rsp, 0x08
00007fb1689dbe66  push rax
00007fb1689dbe67  push rcx
00007fb1689dbe68  push rdx
00007fb1689dbe69  push rdi
00007fb1689dbe6a  push rsi
00007fb1689dbe6b  push r8
00007fb1689dbe6d  push r9
00007fb1689dbe6f  push r10
00007fb1689dbe71  push r11
00007fb1689dbe73  sub rsp, 0xF0
00007fb1689dbe7a  vmovaps [rsp], xmm0
00007fb1689dbe7f  vmovaps [rsp+0x10], xmm1
00007fb1689dbe85  vmovaps [rsp+0x20], xmm2
00007fb1689dbe8b  vmovaps [rsp+0x30], xmm3
00007fb1689dbe91  vmovaps [rsp+0x40], xmm5
00007fb1689dbe97  vmovaps [rsp+0x50], xmm6
00007fb1689dbe9d  vmovaps [rsp+0x60], xmm7
00007fb1689dbea3  vmovaps [rsp+0x70], xmm8
00007fb1689dbea9  vmovaps [rsp+0x80], xmm9
00007fb1689dbeb2  vmovaps [rsp+0x90], xmm10
00007fb1689dbebb  vmovaps [rsp+0xA0], xmm11
00007fb1689dbec4  vmovaps [rsp+0xB0], xmm12
00007fb1689dbecd  vmovaps [rsp+0xC0], xmm13
00007fb1689dbed6  vmovaps [rsp+0xD0], xmm14
00007fb1689dbedf  vmovaps [rsp+0xE0], xmm15
00007fb1689dbee8  sub rsp, 0x30
00007fb1689dbeec  movaps [rsp], xmm4
00007fb1689dbef0  movaps [rsp+0x10], xmm2
00007fb1689dbef5  movaps [rsp+0x20], xmm9
00007fb1689dbefb  lea rdi, [rsp]
00007fb1689dbeff  mov esi, 0x00
00007fb1689dbf04  mov rax, 0x57CCFD419530
00007fb1689dbf0e  call rax
00007fb1689dbf10  movaps xmm4, [rsp]
00007fb1689dbf14  add rsp, 0x30
00007fb1689dbf18  vmovaps xmm0, [rsp]
00007fb1689dbf1d  vmovaps xmm1, [rsp+0x10]
00007fb1689dbf23  vmovaps xmm2, [rsp+0x20]
00007fb1689dbf29  vmovaps xmm3, [rsp+0x30]
00007fb1689dbf2f  vmovaps xmm5, [rsp+0x40]
00007fb1689dbf35  vmovaps xmm6, [rsp+0x50]
00007fb1689dbf3b  vmovaps xmm7, [rsp+0x60]
00007fb1689dbf41  vmovaps xmm8, [rsp+0x70]
00007fb1689dbf47  vmovaps xmm9, [rsp+0x80]
00007fb1689dbf50  vmovaps xmm10, [rsp+0x90]
00007fb1689dbf59  vmovaps xmm11, [rsp+0xA0]
00007fb1689dbf62  vmovaps xmm12, [rsp+0xB0]
00007fb1689dbf6b  vmovaps xmm13, [rsp+0xC0]
00007fb1689dbf74  vmovaps xmm14, [rsp+0xD0]
00007fb1689dbf7d  vmovaps xmm15, [rsp+0xE0]
00007fb1689dbf86  add rsp, 0xF0
00007fb1689dbf8d  pop r11
00007fb1689dbf8f  pop r10
00007fb1689dbf91  pop r9
00007fb1689dbf93  pop r8
00007fb1689dbf95  pop rsi
00007fb1689dbf96  pop rdi
00007fb1689dbf97  pop rdx
00007fb1689dbf98  pop rcx
00007fb1689dbf99  pop rax
00007fb1689dbf9a  add rsp, 0x08
00007fb1689dbf9e  jmp 0x00007FB1689D934B
00007fb1689dbfa3  sub rsp, 0x08
00007fb1689dbfa7  push rax
00007fb1689dbfa8  push rcx
00007fb1689dbfa9  push rdx
00007fb1689dbfaa  push rdi
00007fb1689dbfab  push rsi
00007fb1689dbfac  push r8
00007fb1689dbfae  push r9
00007fb1689dbfb0  push r10
00007fb1689dbfb2  push r11
00007fb1689dbfb4  sub rsp, 0xF0
00007fb1689dbfbb  vmovaps [rsp], xmm0
00007fb1689dbfc0  vmovaps [rsp+0x10], xmm1
00007fb1689dbfc6  vmovaps [rsp+0x20], xmm2
00007fb1689dbfcc  vmovaps [rsp+0x30], xmm3
00007fb1689dbfd2  vmovaps [rsp+0x40], xmm4
00007fb1689dbfd8  vmovaps [rsp+0x50], xmm5
00007fb1689dbfde  vmovaps [rsp+0x60], xmm6
00007fb1689dbfe4  vmovaps [rsp+0x70], xmm7
00007fb1689dbfea  vmovaps [rsp+0x80], xmm8
00007fb1689dbff3  vmovaps [rsp+0x90], xmm10
00007fb1689dbffc  vmovaps [rsp+0xA0], xmm11
00007fb1689dc005  vmovaps [rsp+0xB0], xmm12
00007fb1689dc00e  vmovaps [rsp+0xC0], xmm13
00007fb1689dc017  vmovaps [rsp+0xD0], xmm14
00007fb1689dc020  vmovaps [rsp+0xE0], xmm15
00007fb1689dc029  sub rsp, 0x30
00007fb1689dc02d  movaps [rsp], xmm9
00007fb1689dc032  movaps [rsp+0x10], xmm2
00007fb1689dc037  movaps [rsp+0x20], xmm1
00007fb1689dc03c  lea rdi, [rsp]
00007fb1689dc040  mov esi, 0x00
00007fb1689dc045  mov rax, 0x57CCFD419530
00007fb1689dc04f  call rax
00007fb1689dc051  movaps xmm9, [rsp]
00007fb1689dc056  add rsp, 0x30
00007fb1689dc05a  vmovaps xmm0, [rsp]
00007fb1689dc05f  vmovaps xmm1, [rsp+0x10]
00007fb1689dc065  vmovaps xmm2, [rsp+0x20]
00007fb1689dc06b  vmovaps xmm3, [rsp+0x30]
00007fb1689dc071  vmovaps xmm4, [rsp+0x40]
00007fb1689dc077  vmovaps xmm5, [rsp+0x50]
00007fb1689dc07d  vmovaps xmm6, [rsp+0x60]
00007fb1689dc083  vmovaps xmm7, [rsp+0x70]
00007fb1689dc089  vmovaps xmm8, [rsp+0x80]
00007fb1689dc092  vmovaps xmm10, [rsp+0x90]
00007fb1689dc09b  vmovaps xmm11, [rsp+0xA0]
00007fb1689dc0a4  vmovaps xmm12, [rsp+0xB0]
00007fb1689dc0ad  vmovaps xmm13, [rsp+0xC0]
00007fb1689dc0b6  vmovaps xmm14, [rsp+0xD0]
00007fb1689dc0bf  vmovaps xmm15, [rsp+0xE0]
00007fb1689dc0c8  add rsp, 0xF0
00007fb1689dc0cf  pop r11
00007fb1689dc0d1  pop r10
00007fb1689dc0d3  pop r9
00007fb1689dc0d5  pop r8
00007fb1689dc0d7  pop rsi
00007fb1689dc0d8  pop rdi
00007fb1689dc0d9  pop rdx
00007fb1689dc0da  pop rcx
00007fb1689dc0db  pop rax
00007fb1689dc0dc  add rsp, 0x08
00007fb1689dc0e0  jmp 0x00007FB1689D9381
00007fb1689dc0e5  sub rsp, 0x08
00007fb1689dc0e9  push rax
00007fb1689dc0ea  push rcx
00007fb1689dc0eb  push rdx
00007fb1689dc0ec  push rdi
00007fb1689dc0ed  push rsi
00007fb1689dc0ee  push r8
00007fb1689dc0f0  push r9
00007fb1689dc0f2  push r10
00007fb1689dc0f4  push r11
00007fb1689dc0f6  sub rsp, 0xF0
00007fb1689dc0fd  vmovaps [rsp], xmm0
00007fb1689dc102  vmovaps [rsp+0x10], xmm2
00007fb1689dc108  vmovaps [rsp+0x20], xmm3
00007fb1689dc10e  vmovaps [rsp+0x30], xmm4
00007fb1689dc114  vmovaps [rsp+0x40], xmm5
00007fb1689dc11a  vmovaps [rsp+0x50], xmm6
00007fb1689dc120  vmovaps [rsp+0x60], xmm7
00007fb1689dc126  vmovaps [rsp+0x70], xmm8
00007fb1689dc12c  vmovaps [rsp+0x80], xmm9
00007fb1689dc135  vmovaps [rsp+0x90], xmm10
00007fb1689dc13e  vmovaps [rsp+0xA0], xmm11
00007fb1689dc147  vmovaps [rsp+0xB0], xmm12
00007fb1689dc150  vmovaps [rsp+0xC0], xmm13
00007fb1689dc159  vmovaps [rsp+0xD0], xmm14
00007fb1689dc162  vmovaps [rsp+0xE0], xmm15
00007fb1689dc16b  sub rsp, 0x30
00007fb1689dc16f  movaps [rsp], xmm1
00007fb1689dc173  movaps [rsp+0x10], xmm15
00007fb1689dc179  movaps [rsp+0x20], xmm6
00007fb1689dc17e  lea rdi, [rsp]
00007fb1689dc182  mov esi, 0x00
00007fb1689dc187  mov rax, 0x57CCFD419530
00007fb1689dc191  call rax
00007fb1689dc193  movaps xmm1, [rsp]
00007fb1689dc197  add rsp, 0x30
00007fb1689dc19b  vmovaps xmm0, [rsp]
00007fb1689dc1a0  vmovaps xmm2, [rsp+0x10]
00007fb1689dc1a6  vmovaps xmm3, [rsp+0x20]
00007fb1689dc1ac  vmovaps xmm4, [rsp+0x30]
00007fb1689dc1b2  vmovaps xmm5, [rsp+0x40]
00007fb1689dc1b8  vmovaps xmm6, [rsp+0x50]
00007fb1689dc1be  vmovaps xmm7, [rsp+0x60]
00007fb1689dc1c4  vmovaps xmm8, [rsp+0x70]
00007fb1689dc1ca  vmovaps xmm9, [rsp+0x80]
00007fb1689dc1d3  vmovaps xmm10, [rsp+0x90]
00007fb1689dc1dc  vmovaps xmm11, [rsp+0xA0]
00007fb1689dc1e5  vmovaps xmm12, [rsp+0xB0]
00007fb1689dc1ee  vmovaps xmm13, [rsp+0xC0]
00007fb1689dc1f7  vmovaps xmm14, [rsp+0xD0]
00007fb1689dc200  vmovaps xmm15, [rsp+0xE0]
00007fb1689dc209  add rsp, 0xF0
00007fb1689dc210  pop r11
00007fb1689dc212  pop r10
00007fb1689dc214  pop r9
00007fb1689dc216  pop r8
00007fb1689dc218  pop rsi
00007fb1689dc219  pop rdi
00007fb1689dc21a  pop rdx
00007fb1689dc21b  pop rcx
00007fb1689dc21c  pop rax
00007fb1689dc21d  add rsp, 0x08
00007fb1689dc221  jmp 0x00007FB1689D93A2
00007fb1689dc226  sub rsp, 0x08
00007fb1689dc22a  push rax
00007fb1689dc22b  push rcx
00007fb1689dc22c  push rdx
00007fb1689dc22d  push rdi
00007fb1689dc22e  push rsi
00007fb1689dc22f  push r8
00007fb1689dc231  push r9
00007fb1689dc233  push r10
00007fb1689dc235  push r11
00007fb1689dc237  sub rsp, 0xF0
00007fb1689dc23e  vmovaps [rsp], xmm0
00007fb1689dc243  vmovaps [rsp+0x10], xmm1
00007fb1689dc249  vmovaps [rsp+0x20], xmm2
00007fb1689dc24f  vmovaps [rsp+0x30], xmm3
00007fb1689dc255  vmovaps [rsp+0x40], xmm4
00007fb1689dc25b  vmovaps [rsp+0x50], xmm5
00007fb1689dc261  vmovaps [rsp+0x60], xmm6
00007fb1689dc267  vmovaps [rsp+0x70], xmm7
00007fb1689dc26d  vmovaps [rsp+0x80], xmm8
00007fb1689dc276  vmovaps [rsp+0x90], xmm9
00007fb1689dc27f  vmovaps [rsp+0xA0], xmm10
00007fb1689dc288  vmovaps [rsp+0xB0], xmm11
00007fb1689dc291  vmovaps [rsp+0xC0], xmm12
00007fb1689dc29a  vmovaps [rsp+0xD0], xmm13
00007fb1689dc2a3  vmovaps [rsp+0xE0], xmm14
00007fb1689dc2ac  sub rsp, 0x30
00007fb1689dc2b0  movaps [rsp], xmm15
00007fb1689dc2b5  movaps [rsp+0x10], xmm5
00007fb1689dc2ba  movaps [rsp+0x20], xmm3
00007fb1689dc2bf  lea rdi, [rsp]
00007fb1689dc2c3  mov esi, 0x00
00007fb1689dc2c8  mov rax, 0x57CCFD419530
00007fb1689dc2d2  call rax
00007fb1689dc2d4  movaps xmm15, [rsp]
00007fb1689dc2d9  add rsp, 0x30
00007fb1689dc2dd  vmovaps xmm0, [rsp]
00007fb1689dc2e2  vmovaps xmm1, [rsp+0x10]
00007fb1689dc2e8  vmovaps xmm2, [rsp+0x20]
00007fb1689dc2ee  vmovaps xmm3, [rsp+0x30]
00007fb1689dc2f4  vmovaps xmm4, [rsp+0x40]
00007fb1689dc2fa  vmovaps xmm5, [rsp+0x50]
00007fb1689dc300  vmovaps xmm6, [rsp+0x60]
00007fb1689dc306  vmovaps xmm7, [rsp+0x70]
00007fb1689dc30c  vmovaps xmm8, [rsp+0x80]
00007fb1689dc315  vmovaps xmm9, [rsp+0x90]
00007fb1689dc31e  vmovaps xmm10, [rsp+0xA0]
00007fb1689dc327  vmovaps xmm11, [rsp+0xB0]
00007fb1689dc330  vmovaps xmm12, [rsp+0xC0]
00007fb1689dc339  vmovaps xmm13, [rsp+0xD0]
00007fb1689dc342  vmovaps xmm14, [rsp+0xE0]
00007fb1689dc34b  add rsp, 0xF0
00007fb1689dc352  pop r11
00007fb1689dc354  pop r10
00007fb1689dc356  pop r9
00007fb1689dc358  pop r8
00007fb1689dc35a  pop rsi
00007fb1689dc35b  pop rdi
00007fb1689dc35c  pop rdx
00007fb1689dc35d  pop rcx
00007fb1689dc35e  pop rax
00007fb1689dc35f  add rsp, 0x08
00007fb1689dc363  jmp 0x00007FB1689D93BC
00007fb1689dc368  sub rsp, 0x08
00007fb1689dc36c  push rax
00007fb1689dc36d  push rcx
00007fb1689dc36e  push rdx
00007fb1689dc36f  push rdi
00007fb1689dc370  push rsi
00007fb1689dc371  push r8
00007fb1689dc373  push r9
00007fb1689dc375  push r10
00007fb1689dc377  push r11
00007fb1689dc379  sub rsp, 0xF0
00007fb1689dc380  vmovaps [rsp], xmm0
00007fb1689dc385  vmovaps [rsp+0x10], xmm1
00007fb1689dc38b  vmovaps [rsp+0x20], xmm2
00007fb1689dc391  vmovaps [rsp+0x30], xmm3
00007fb1689dc397  vmovaps [rsp+0x40], xmm4
00007fb1689dc39d  vmovaps [rsp+0x50], xmm6
00007fb1689dc3a3  vmovaps [rsp+0x60], xmm7
00007fb1689dc3a9  vmovaps [rsp+0x70], xmm8
00007fb1689dc3af  vmovaps [rsp+0x80], xmm9
00007fb1689dc3b8  vmovaps [rsp+0x90], xmm10
00007fb1689dc3c1  vmovaps [rsp+0xA0], xmm11
00007fb1689dc3ca  vmovaps [rsp+0xB0], xmm12
00007fb1689dc3d3  vmovaps [rsp+0xC0], xmm13
00007fb1689dc3dc  vmovaps [rsp+0xD0], xmm14
00007fb1689dc3e5  vmovaps [rsp+0xE0], xmm15
00007fb1689dc3ee  sub rsp, 0x30
00007fb1689dc3f2  movaps [rsp], xmm5
00007fb1689dc3f6  movaps [rsp+0x10], xmm8
00007fb1689dc3fc  movaps [rsp+0x20], xmm6
00007fb1689dc401  lea rdi, [rsp]
00007fb1689dc405  mov esi, 0x00
00007fb1689dc40a  mov rax, 0x57CCFD419530
00007fb1689dc414  call rax
00007fb1689dc416  movaps xmm5, [rsp]
00007fb1689dc41a  add rsp, 0x30
00007fb1689dc41e  vmovaps xmm0, [rsp]
00007fb1689dc423  vmovaps xmm1, [rsp+0x10]
00007fb1689dc429  vmovaps xmm2, [rsp+0x20]
00007fb1689dc42f  vmovaps xmm3, [rsp+0x30]
00007fb1689dc435  vmovaps xmm4, [rsp+0x40]
00007fb1689dc43b  vmovaps xmm6, [rsp+0x50]
00007fb1689dc441  vmovaps xmm7, [rsp+0x60]
00007fb1689dc447  vmovaps xmm8, [rsp+0x70]
00007fb1689dc44d  vmovaps xmm9, [rsp+0x80]
00007fb1689dc456  vmovaps xmm10, [rsp+0x90]
00007fb1689dc45f  vmovaps xmm11, [rsp+0xA0]
00007fb1689dc468  vmovaps xmm12, [rsp+0xB0]
00007fb1689dc471  vmovaps xmm13, [rsp+0xC0]
00007fb1689dc47a  vmovaps xmm14, [rsp+0xD0]
00007fb1689dc483  vmovaps xmm15, [rsp+0xE0]
00007fb1689dc48c  add rsp, 0xF0
00007fb1689dc493  pop r11
00007fb1689dc495  pop r10
00007fb1689dc497  pop r9
00007fb1689dc499  pop r8
00007fb1689dc49b  pop rsi
00007fb1689dc49c  pop rdi
00007fb1689dc49d  pop rdx
00007fb1689dc49e  pop rcx
00007fb1689dc49f  pop rax
00007fb1689dc4a0  add rsp, 0x08
00007fb1689dc4a4  jmp 0x00007FB1689D93E0
00007fb1689dc4a9  sub rsp, 0x08
00007fb1689dc4ad  push rax
00007fb1689dc4ae  push rcx
00007fb1689dc4af  push rdx
00007fb1689dc4b0  push rdi
00007fb1689dc4b1  push rsi
00007fb1689dc4b2  push r8
00007fb1689dc4b4  push r9
00007fb1689dc4b6  push r10
00007fb1689dc4b8  push r11
00007fb1689dc4ba  sub rsp, 0xF0
00007fb1689dc4c1  vmovaps [rsp], xmm0
00007fb1689dc4c6  vmovaps [rsp+0x10], xmm1
00007fb1689dc4cc  vmovaps [rsp+0x20], xmm2
00007fb1689dc4d2  vmovaps [rsp+0x30], xmm3
00007fb1689dc4d8  vmovaps [rsp+0x40], xmm4
00007fb1689dc4de  vmovaps [rsp+0x50], xmm5
00007fb1689dc4e4  vmovaps [rsp+0x60], xmm7
00007fb1689dc4ea  vmovaps [rsp+0x70], xmm8
00007fb1689dc4f0  vmovaps [rsp+0x80], xmm9
00007fb1689dc4f9  vmovaps [rsp+0x90], xmm10
00007fb1689dc502  vmovaps [rsp+0xA0], xmm11
00007fb1689dc50b  vmovaps [rsp+0xB0], xmm12
00007fb1689dc514  vmovaps [rsp+0xC0], xmm13
00007fb1689dc51d  vmovaps [rsp+0xD0], xmm14
00007fb1689dc526  vmovaps [rsp+0xE0], xmm15
00007fb1689dc52f  sub rsp, 0x30
00007fb1689dc533  movaps [rsp], xmm6
00007fb1689dc537  movaps [rsp+0x10], xmm10
00007fb1689dc53d  movaps [rsp+0x20], xmm8
00007fb1689dc543  lea rdi, [rsp]
00007fb1689dc547  mov esi, 0x00
00007fb1689dc54c  mov rax, 0x57CCFD419530
00007fb1689dc556  call rax
00007fb1689dc558  movaps xmm6, [rsp]
00007fb1689dc55c  add rsp, 0x30
00007fb1689dc560  vmovaps xmm0, [rsp]
00007fb1689dc565  vmovaps xmm1, [rsp+0x10]
00007fb1689dc56b  vmovaps xmm2, [rsp+0x20]
00007fb1689dc571  vmovaps xmm3, [rsp+0x30]
00007fb1689dc577  vmovaps xmm4, [rsp+0x40]
00007fb1689dc57d  vmovaps xmm5, [rsp+0x50]
00007fb1689dc583  vmovaps xmm7, [rsp+0x60]
00007fb1689dc589  vmovaps xmm8, [rsp+0x70]
00007fb1689dc58f  vmovaps xmm9, [rsp+0x80]
00007fb1689dc598  vmovaps xmm10, [rsp+0x90]
00007fb1689dc5a1  vmovaps xmm11, [rsp+0xA0]
00007fb1689dc5aa  vmovaps xmm12, [rsp+0xB0]
00007fb1689dc5b3  vmovaps xmm13, [rsp+0xC0]
00007fb1689dc5bc  vmovaps xmm14, [rsp+0xD0]
00007fb1689dc5c5  vmovaps xmm15, [rsp+0xE0]
00007fb1689dc5ce  add rsp, 0xF0
00007fb1689dc5d5  pop r11
00007fb1689dc5d7  pop r10
00007fb1689dc5d9  pop r9
00007fb1689dc5db  pop r8
00007fb1689dc5dd  pop rsi
00007fb1689dc5de  pop rdi
00007fb1689dc5df  pop rdx
00007fb1689dc5e0  pop rcx
00007fb1689dc5e1  pop rax
00007fb1689dc5e2  add rsp, 0x08
00007fb1689dc5e6  jmp 0x00007FB1689D9405
00007fb1689dc5eb  sub rsp, 0x08
00007fb1689dc5ef  push rax
00007fb1689dc5f0  push rcx
00007fb1689dc5f1  push rdx
00007fb1689dc5f2  push rdi
00007fb1689dc5f3  push rsi
00007fb1689dc5f4  push r8
00007fb1689dc5f6  push r9
00007fb1689dc5f8  push r10
00007fb1689dc5fa  push r11
00007fb1689dc5fc  sub rsp, 0xF0
00007fb1689dc603  vmovaps [rsp], xmm0
00007fb1689dc608  vmovaps [rsp+0x10], xmm1
00007fb1689dc60e  vmovaps [rsp+0x20], xmm2
00007fb1689dc614  vmovaps [rsp+0x30], xmm3
00007fb1689dc61a  vmovaps [rsp+0x40], xmm4
00007fb1689dc620  vmovaps [rsp+0x50], xmm5
00007fb1689dc626  vmovaps [rsp+0x60], xmm6
00007fb1689dc62c  vmovaps [rsp+0x70], xmm7
00007fb1689dc632  vmovaps [rsp+0x80], xmm8
00007fb1689dc63b  vmovaps [rsp+0x90], xmm9
00007fb1689dc644  vmovaps [rsp+0xA0], xmm11
00007fb1689dc64d  vmovaps [rsp+0xB0], xmm12
00007fb1689dc656  vmovaps [rsp+0xC0], xmm13
00007fb1689dc65f  vmovaps [rsp+0xD0], xmm14
00007fb1689dc668  vmovaps [rsp+0xE0], xmm15
00007fb1689dc671  sub rsp, 0x30
00007fb1689dc675  movaps [rsp], xmm10
00007fb1689dc67a  movaps [rsp+0x10], xmm8
00007fb1689dc680  movaps [rsp+0x20], xmm14
00007fb1689dc686  lea rdi, [rsp]
00007fb1689dc68a  mov esi, 0x00
00007fb1689dc68f  mov rax, 0x57CCFD419530
00007fb1689dc699  call rax
00007fb1689dc69b  movaps xmm10, [rsp]
00007fb1689dc6a0  add rsp, 0x30
00007fb1689dc6a4  vmovaps xmm0, [rsp]
00007fb1689dc6a9  vmovaps xmm1, [rsp+0x10]
00007fb1689dc6af  vmovaps xmm2, [rsp+0x20]
00007fb1689dc6b5  vmovaps xmm3, [rsp+0x30]
00007fb1689dc6bb  vmovaps xmm4, [rsp+0x40]
00007fb1689dc6c1  vmovaps xmm5, [rsp+0x50]
00007fb1689dc6c7  vmovaps xmm6, [rsp+0x60]
00007fb1689dc6cd  vmovaps xmm7, [rsp+0x70]
00007fb1689dc6d3  vmovaps xmm8, [rsp+0x80]
00007fb1689dc6dc  vmovaps xmm9, [rsp+0x90]
00007fb1689dc6e5  vmovaps xmm11, [rsp+0xA0]
00007fb1689dc6ee  vmovaps xmm12, [rsp+0xB0]
00007fb1689dc6f7  vmovaps xmm13, [rsp+0xC0]
00007fb1689dc700  vmovaps xmm14, [rsp+0xD0]
00007fb1689dc709  vmovaps xmm15, [rsp+0xE0]
00007fb1689dc712  add rsp, 0xF0
00007fb1689dc719  pop r11
00007fb1689dc71b  pop r10
00007fb1689dc71d  pop r9
00007fb1689dc71f  pop r8
00007fb1689dc721  pop rsi
00007fb1689dc722  pop rdi
00007fb1689dc723  pop rdx
00007fb1689dc724  pop rcx
00007fb1689dc725  pop rax
00007fb1689dc726  add rsp, 0x08
00007fb1689dc72a  jmp 0x00007FB1689D9425
00007fb1689dc72f  sub rsp, 0x08
00007fb1689dc733  push rax
00007fb1689dc734  push rcx
00007fb1689dc735  push rdx
00007fb1689dc736  push rdi
00007fb1689dc737  push rsi
00007fb1689dc738  push r8
00007fb1689dc73a  push r9
00007fb1689dc73c  push r10
00007fb1689dc73e  push r11
00007fb1689dc740  sub rsp, 0xF0
00007fb1689dc747  vmovaps [rsp], xmm0
00007fb1689dc74c  vmovaps [rsp+0x10], xmm1
00007fb1689dc752  vmovaps [rsp+0x20], xmm2
00007fb1689dc758  vmovaps [rsp+0x30], xmm3
00007fb1689dc75e  vmovaps [rsp+0x40], xmm4
00007fb1689dc764  vmovaps [rsp+0x50], xmm5
00007fb1689dc76a  vmovaps [rsp+0x60], xmm6
00007fb1689dc770  vmovaps [rsp+0x70], xmm7
00007fb1689dc776  vmovaps [rsp+0x80], xmm8
00007fb1689dc77f  vmovaps [rsp+0x90], xmm9
00007fb1689dc788  vmovaps [rsp+0xA0], xmm10
00007fb1689dc791  vmovaps [rsp+0xB0], xmm11
00007fb1689dc79a  vmovaps [rsp+0xC0], xmm12
00007fb1689dc7a3  vmovaps [rsp+0xD0], xmm13
00007fb1689dc7ac  vmovaps [rsp+0xE0], xmm15
00007fb1689dc7b5  sub rsp, 0x30
00007fb1689dc7b9  movaps [rsp], xmm14
00007fb1689dc7be  movaps [rsp+0x10], xmm8
00007fb1689dc7c4  movaps [rsp+0x20], xmm4
00007fb1689dc7c9  lea rdi, [rsp]
00007fb1689dc7cd  mov esi, 0x00
00007fb1689dc7d2  mov rax, 0x57CCFD419530
00007fb1689dc7dc  call rax
00007fb1689dc7de  movaps xmm14, [rsp]
00007fb1689dc7e3  add rsp, 0x30
00007fb1689dc7e7  vmovaps xmm0, [rsp]
00007fb1689dc7ec  vmovaps xmm1, [rsp+0x10]
00007fb1689dc7f2  vmovaps xmm2, [rsp+0x20]
00007fb1689dc7f8  vmovaps xmm3, [rsp+0x30]
00007fb1689dc7fe  vmovaps xmm4, [rsp+0x40]
00007fb1689dc804  vmovaps xmm5, [rsp+0x50]
00007fb1689dc80a  vmovaps xmm6, [rsp+0x60]
00007fb1689dc810  vmovaps xmm7, [rsp+0x70]
00007fb1689dc816  vmovaps xmm8, [rsp+0x80]
00007fb1689dc81f  vmovaps xmm9, [rsp+0x90]
00007fb1689dc828  vmovaps xmm10, [rsp+0xA0]
00007fb1689dc831  vmovaps xmm11, [rsp+0xB0]
00007fb1689dc83a  vmovaps xmm12, [rsp+0xC0]
00007fb1689dc843  vmovaps xmm13, [rsp+0xD0]
00007fb1689dc84c  vmovaps xmm15, [rsp+0xE0]
00007fb1689dc855  add rsp, 0xF0
00007fb1689dc85c  pop r11
00007fb1689dc85e  pop r10
00007fb1689dc860  pop r9
00007fb1689dc862  pop r8
00007fb1689dc864  pop rsi
00007fb1689dc865  pop rdi
00007fb1689dc866  pop rdx
00007fb1689dc867  pop rcx
00007fb1689dc868  pop rax
00007fb1689dc869  add rsp, 0x08
00007fb1689dc86d  jmp 0x00007FB1689D9445
00007fb1689dc872  sub rsp, 0x08
00007fb1689dc876  push rax
00007fb1689dc877  push rcx
00007fb1689dc878  push rdx
00007fb1689dc879  push rdi
00007fb1689dc87a  push rsi
00007fb1689dc87b  push r8
00007fb1689dc87d  push r9
00007fb1689dc87f  push r10
00007fb1689dc881  push r11
00007fb1689dc883  sub rsp, 0xF0
00007fb1689dc88a  vmovaps [rsp], xmm0
00007fb1689dc88f  vmovaps [rsp+0x10], xmm1
00007fb1689dc895  vmovaps [rsp+0x20], xmm2
00007fb1689dc89b  vmovaps [rsp+0x30], xmm3
00007fb1689dc8a1  vmovaps [rsp+0x40], xmm5
00007fb1689dc8a7  vmovaps [rsp+0x50], xmm6
00007fb1689dc8ad  vmovaps [rsp+0x60], xmm7
00007fb1689dc8b3  vmovaps [rsp+0x70], xmm8
00007fb1689dc8b9  vmovaps [rsp+0x80], xmm9
00007fb1689dc8c2  vmovaps [rsp+0x90], xmm10
00007fb1689dc8cb  vmovaps [rsp+0xA0], xmm11
00007fb1689dc8d4  vmovaps [rsp+0xB0], xmm12
00007fb1689dc8dd  vmovaps [rsp+0xC0], xmm13
00007fb1689dc8e6  vmovaps [rsp+0xD0], xmm14
00007fb1689dc8ef  vmovaps [rsp+0xE0], xmm15
00007fb1689dc8f8  sub rsp, 0x30
00007fb1689dc8fc  movaps [rsp], xmm4
00007fb1689dc900  movaps [rsp+0x10], xmm13
00007fb1689dc906  movaps [rsp+0x20], xmm8
00007fb1689dc90c  lea rdi, [rsp]
00007fb1689dc910  mov esi, 0x00
00007fb1689dc915  mov rax, 0x57CCFD419530
00007fb1689dc91f  call rax
00007fb1689dc921  movaps xmm4, [rsp]
00007fb1689dc925  add rsp, 0x30
00007fb1689dc929  vmovaps xmm0, [rsp]
00007fb1689dc92e  vmovaps xmm1, [rsp+0x10]
00007fb1689dc934  vmovaps xmm2, [rsp+0x20]
00007fb1689dc93a  vmovaps xmm3, [rsp+0x30]
00007fb1689dc940  vmovaps xmm5, [rsp+0x40]
00007fb1689dc946  vmovaps xmm6, [rsp+0x50]
00007fb1689dc94c  vmovaps xmm7, [rsp+0x60]
00007fb1689dc952  vmovaps xmm8, [rsp+0x70]
00007fb1689dc958  vmovaps xmm9, [rsp+0x80]
00007fb1689dc961  vmovaps xmm10, [rsp+0x90]
00007fb1689dc96a  vmovaps xmm11, [rsp+0xA0]
00007fb1689dc973  vmovaps xmm12, [rsp+0xB0]
00007fb1689dc97c  vmovaps xmm13, [rsp+0xC0]
00007fb1689dc985  vmovaps xmm14, [rsp+0xD0]
00007fb1689dc98e  vmovaps xmm15, [rsp+0xE0]
00007fb1689dc997  add rsp, 0xF0
00007fb1689dc99e  pop r11
00007fb1689dc9a0  pop r10
00007fb1689dc9a2  pop r9
00007fb1689dc9a4  pop r8
00007fb1689dc9a6  pop rsi
00007fb1689dc9a7  pop rdi
00007fb1689dc9a8  pop rdx
00007fb1689dc9a9  pop rcx
00007fb1689dc9aa  pop rax
00007fb1689dc9ab  add rsp, 0x08
00007fb1689dc9af  jmp 0x00007FB1689D946A
00007fb1689dc9b4  sub rsp, 0x08
00007fb1689dc9b8  push rax
00007fb1689dc9b9  push rcx
00007fb1689dc9ba  push rdx
00007fb1689dc9bb  push rdi
00007fb1689dc9bc  push rsi
00007fb1689dc9bd  push r8
00007fb1689dc9bf  push r9
00007fb1689dc9c1  push r10
00007fb1689dc9c3  push r11
00007fb1689dc9c5  sub rsp, 0xF0
00007fb1689dc9cc  vmovaps [rsp], xmm0
00007fb1689dc9d1  vmovaps [rsp+0x10], xmm1
00007fb1689dc9d7  vmovaps [rsp+0x20], xmm2
00007fb1689dc9dd  vmovaps [rsp+0x30], xmm3
00007fb1689dc9e3  vmovaps [rsp+0x40], xmm4
00007fb1689dc9e9  vmovaps [rsp+0x50], xmm5
00007fb1689dc9ef  vmovaps [rsp+0x60], xmm6
00007fb1689dc9f5  vmovaps [rsp+0x70], xmm7
00007fb1689dc9fb  vmovaps [rsp+0x80], xmm8
00007fb1689dca04  vmovaps [rsp+0x90], xmm9
00007fb1689dca0d  vmovaps [rsp+0xA0], xmm10
00007fb1689dca16  vmovaps [rsp+0xB0], xmm11
00007fb1689dca1f  vmovaps [rsp+0xC0], xmm12
00007fb1689dca28  vmovaps [rsp+0xD0], xmm14
00007fb1689dca31  vmovaps [rsp+0xE0], xmm15
00007fb1689dca3a  sub rsp, 0x30
00007fb1689dca3e  movaps [rsp], xmm13
00007fb1689dca43  movaps [rsp+0x10], xmm15
00007fb1689dca49  movaps [rsp+0x20], xmm9
00007fb1689dca4f  lea rdi, [rsp]
00007fb1689dca53  mov esi, 0x00
00007fb1689dca58  mov rax, 0x57CCFD419530
00007fb1689dca62  call rax
00007fb1689dca64  movaps xmm13, [rsp]
00007fb1689dca69  add rsp, 0x30
00007fb1689dca6d  vmovaps xmm0, [rsp]
00007fb1689dca72  vmovaps xmm1, [rsp+0x10]
00007fb1689dca78  vmovaps xmm2, [rsp+0x20]
00007fb1689dca7e  vmovaps xmm3, [rsp+0x30]
00007fb1689dca84  vmovaps xmm4, [rsp+0x40]
00007fb1689dca8a  vmovaps xmm5, [rsp+0x50]
00007fb1689dca90  vmovaps xmm6, [rsp+0x60]
00007fb1689dca96  vmovaps xmm7, [rsp+0x70]
00007fb1689dca9c  vmovaps xmm8, [rsp+0x80]
00007fb1689dcaa5  vmovaps xmm9, [rsp+0x90]
00007fb1689dcaae  vmovaps xmm10, [rsp+0xA0]
00007fb1689dcab7  vmovaps xmm11, [rsp+0xB0]
00007fb1689dcac0  vmovaps xmm12, [rsp+0xC0]
00007fb1689dcac9  vmovaps xmm14, [rsp+0xD0]
00007fb1689dcad2  vmovaps xmm15, [rsp+0xE0]
00007fb1689dcadb  add rsp, 0xF0
00007fb1689dcae2  pop r11
00007fb1689dcae4  pop r10
00007fb1689dcae6  pop r9
00007fb1689dcae8  pop r8
00007fb1689dcaea  pop rsi
00007fb1689dcaeb  pop rdi
00007fb1689dcaec  pop rdx
00007fb1689dcaed  pop rcx
00007fb1689dcaee  pop rax
00007fb1689dcaef  add rsp, 0x08
00007fb1689dcaf3  jmp 0x00007FB1689D9485
00007fb1689dcaf8  sub rsp, 0x08
00007fb1689dcafc  push rax
00007fb1689dcafd  push rcx
00007fb1689dcafe  push rdx
00007fb1689dcaff  push rdi
00007fb1689dcb00  push rsi
00007fb1689dcb01  push r8
00007fb1689dcb03  push r9
00007fb1689dcb05  push r10
00007fb1689dcb07  push r11
00007fb1689dcb09  sub rsp, 0xF0
00007fb1689dcb10  vmovaps [rsp], xmm0
00007fb1689dcb15  vmovaps [rsp+0x10], xmm1
00007fb1689dcb1b  vmovaps [rsp+0x20], xmm2
00007fb1689dcb21  vmovaps [rsp+0x30], xmm3
00007fb1689dcb27  vmovaps [rsp+0x40], xmm4
00007fb1689dcb2d  vmovaps [rsp+0x50], xmm5
00007fb1689dcb33  vmovaps [rsp+0x60], xmm6
00007fb1689dcb39  vmovaps [rsp+0x70], xmm7
00007fb1689dcb3f  vmovaps [rsp+0x80], xmm8
00007fb1689dcb48  vmovaps [rsp+0x90], xmm9
00007fb1689dcb51  vmovaps [rsp+0xA0], xmm10
00007fb1689dcb5a  vmovaps [rsp+0xB0], xmm11
00007fb1689dcb63  vmovaps [rsp+0xC0], xmm12
00007fb1689dcb6c  vmovaps [rsp+0xD0], xmm13
00007fb1689dcb75  vmovaps [rsp+0xE0], xmm14
00007fb1689dcb7e  sub rsp, 0x30
00007fb1689dcb82  movaps [rsp], xmm15
00007fb1689dcb87  movaps [rsp+0x10], xmm1
00007fb1689dcb8c  movaps [rsp+0x20], xmm5
00007fb1689dcb91  lea rdi, [rsp]
00007fb1689dcb95  mov esi, 0x00
00007fb1689dcb9a  mov rax, 0x57CCFD419530
00007fb1689dcba4  call rax
00007fb1689dcba6  movaps xmm15, [rsp]
00007fb1689dcbab  add rsp, 0x30
00007fb1689dcbaf  vmovaps xmm0, [rsp]
00007fb1689dcbb4  vmovaps xmm1, [rsp+0x10]
00007fb1689dcbba  vmovaps xmm2, [rsp+0x20]
00007fb1689dcbc0  vmovaps xmm3, [rsp+0x30]
00007fb1689dcbc6  vmovaps xmm4, [rsp+0x40]
00007fb1689dcbcc  vmovaps xmm5, [rsp+0x50]
00007fb1689dcbd2  vmovaps xmm6, [rsp+0x60]
00007fb1689dcbd8  vmovaps xmm7, [rsp+0x70]
00007fb1689dcbde  vmovaps xmm8, [rsp+0x80]
00007fb1689dcbe7  vmovaps xmm9, [rsp+0x90]
00007fb1689dcbf0  vmovaps xmm10, [rsp+0xA0]
00007fb1689dcbf9  vmovaps xmm11, [rsp+0xB0]
00007fb1689dcc02  vmovaps xmm12, [rsp+0xC0]
00007fb1689dcc0b  vmovaps xmm13, [rsp+0xD0]
00007fb1689dcc14  vmovaps xmm14, [rsp+0xE0]
00007fb1689dcc1d  add rsp, 0xF0
00007fb1689dcc24  pop r11
00007fb1689dcc26  pop r10
00007fb1689dcc28  pop r9
00007fb1689dcc2a  pop r8
00007fb1689dcc2c  pop rsi
00007fb1689dcc2d  pop rdi
00007fb1689dcc2e  pop rdx
00007fb1689dcc2f  pop rcx
00007fb1689dcc30  pop rax
00007fb1689dcc31  add rsp, 0x08
00007fb1689dcc35  jmp 0x00007FB1689D94A0
00007fb1689dcc3a  call 0x00007FB1688D64F0
00007fb1689dcc3f  jmp 0x00007FB1689D94FB
00007fb1689dcc44  sub rsp, 0x08
00007fb1689dcc48  push rax
00007fb1689dcc49  push rcx
00007fb1689dcc4a  push rdx
00007fb1689dcc4b  push rdi
00007fb1689dcc4c  push rsi
00007fb1689dcc4d  push r8
00007fb1689dcc4f  push r9
00007fb1689dcc51  push r10
00007fb1689dcc53  push r11
00007fb1689dcc55  sub rsp, 0xF0
00007fb1689dcc5c  vmovaps [rsp], xmm0
00007fb1689dcc61  vmovaps [rsp+0x10], xmm1
00007fb1689dcc67  vmovaps [rsp+0x20], xmm2
00007fb1689dcc6d  vmovaps [rsp+0x30], xmm3
00007fb1689dcc73  vmovaps [rsp+0x40], xmm4
00007fb1689dcc79  vmovaps [rsp+0x50], xmm5
00007fb1689dcc7f  vmovaps [rsp+0x60], xmm6
00007fb1689dcc85  vmovaps [rsp+0x70], xmm7
00007fb1689dcc8b  vmovaps [rsp+0x80], xmm8
00007fb1689dcc94  vmovaps [rsp+0x90], xmm10
00007fb1689dcc9d  vmovaps [rsp+0xA0], xmm11
00007fb1689dcca6  vmovaps [rsp+0xB0], xmm12
00007fb1689dccaf  vmovaps [rsp+0xC0], xmm13
00007fb1689dccb8  vmovaps [rsp+0xD0], xmm14
00007fb1689dccc1  vmovaps [rsp+0xE0], xmm15
00007fb1689dccca  sub rsp, 0x30
00007fb1689dccce  movaps [rsp], xmm9
00007fb1689dccd3  movaps [rsp+0x10], xmm8
00007fb1689dccd9  movaps [rsp+0x20], xmm11
00007fb1689dccdf  lea rdi, [rsp]
00007fb1689dcce3  mov esi, 0x00
00007fb1689dcce8  mov rax, 0x57CCFD419530
00007fb1689dccf2  call rax
00007fb1689dccf4  movaps xmm9, [rsp]
00007fb1689dccf9  add rsp, 0x30
00007fb1689dccfd  vmovaps xmm0, [rsp]
00007fb1689dcd02  vmovaps xmm1, [rsp+0x10]
00007fb1689dcd08  vmovaps xmm2, [rsp+0x20]
00007fb1689dcd0e  vmovaps xmm3, [rsp+0x30]
00007fb1689dcd14  vmovaps xmm4, [rsp+0x40]
00007fb1689dcd1a  vmovaps xmm5, [rsp+0x50]
00007fb1689dcd20  vmovaps xmm6, [rsp+0x60]
00007fb1689dcd26  vmovaps xmm7, [rsp+0x70]
00007fb1689dcd2c  vmovaps xmm8, [rsp+0x80]
00007fb1689dcd35  vmovaps xmm10, [rsp+0x90]
00007fb1689dcd3e  vmovaps xmm11, [rsp+0xA0]
00007fb1689dcd47  vmovaps xmm12, [rsp+0xB0]
00007fb1689dcd50  vmovaps xmm13, [rsp+0xC0]
00007fb1689dcd59  vmovaps xmm14, [rsp+0xD0]
00007fb1689dcd62  vmovaps xmm15, [rsp+0xE0]
00007fb1689dcd6b  add rsp, 0xF0
00007fb1689dcd72  pop r11
00007fb1689dcd74  pop r10
00007fb1689dcd76  pop r9
00007fb1689dcd78  pop r8
00007fb1689dcd7a  pop rsi
00007fb1689dcd7b  pop rdi
00007fb1689dcd7c  pop rdx
00007fb1689dcd7d  pop rcx
00007fb1689dcd7e  pop rax
00007fb1689dcd7f  add rsp, 0x08
00007fb1689dcd83  jmp 0x00007FB1689D9532
00007fb1689dcd88  sub rsp, 0x08
00007fb1689dcd8c  push rax
00007fb1689dcd8d  push rcx
00007fb1689dcd8e  push rdx
00007fb1689dcd8f  push rdi
00007fb1689dcd90  push rsi
00007fb1689dcd91  push r8
00007fb1689dcd93  push r9
00007fb1689dcd95  push r10
00007fb1689dcd97  push r11
00007fb1689dcd99  sub rsp, 0xF0
00007fb1689dcda0  vmovaps [rsp], xmm0
00007fb1689dcda5  vmovaps [rsp+0x10], xmm1
00007fb1689dcdab  vmovaps [rsp+0x20], xmm2
00007fb1689dcdb1  vmovaps [rsp+0x30], xmm3
00007fb1689dcdb7  vmovaps [rsp+0x40], xmm4
00007fb1689dcdbd  vmovaps [rsp+0x50], xmm5
00007fb1689dcdc3  vmovaps [rsp+0x60], xmm6
00007fb1689dcdc9  vmovaps [rsp+0x70], xmm7
00007fb1689dcdcf  vmovaps [rsp+0x80], xmm8
00007fb1689dcdd8  vmovaps [rsp+0x90], xmm9
00007fb1689dcde1  vmovaps [rsp+0xA0], xmm10
00007fb1689dcdea  vmovaps [rsp+0xB0], xmm12
00007fb1689dcdf3  vmovaps [rsp+0xC0], xmm13
00007fb1689dcdfc  vmovaps [rsp+0xD0], xmm14
00007fb1689dce05  vmovaps [rsp+0xE0], xmm15
00007fb1689dce0e  sub rsp, 0x30
00007fb1689dce12  movaps [rsp], xmm11
00007fb1689dce17  movaps [rsp+0x10], xmm10
00007fb1689dce1d  movaps [rsp+0x20], xmm6
00007fb1689dce22  lea rdi, [rsp]
00007fb1689dce26  mov esi, 0x00
00007fb1689dce2b  mov rax, 0x57CCFD419530
00007fb1689dce35  call rax
00007fb1689dce37  movaps xmm11, [rsp]
00007fb1689dce3c  add rsp, 0x30
00007fb1689dce40  vmovaps xmm0, [rsp]
00007fb1689dce45  vmovaps xmm1, [rsp+0x10]
00007fb1689dce4b  vmovaps xmm2, [rsp+0x20]
00007fb1689dce51  vmovaps xmm3, [rsp+0x30]
00007fb1689dce57  vmovaps xmm4, [rsp+0x40]
00007fb1689dce5d  vmovaps xmm5, [rsp+0x50]
00007fb1689dce63  vmovaps xmm6, [rsp+0x60]
00007fb1689dce69  vmovaps xmm7, [rsp+0x70]
00007fb1689dce6f  vmovaps xmm8, [rsp+0x80]
00007fb1689dce78  vmovaps xmm9, [rsp+0x90]
00007fb1689dce81  vmovaps xmm10, [rsp+0xA0]
00007fb1689dce8a  vmovaps xmm12, [rsp+0xB0]
00007fb1689dce93  vmovaps xmm13, [rsp+0xC0]
00007fb1689dce9c  vmovaps xmm14, [rsp+0xD0]
00007fb1689dcea5  vmovaps xmm15, [rsp+0xE0]
00007fb1689dceae  add rsp, 0xF0
00007fb1689dceb5  pop r11
00007fb1689dceb7  pop r10
00007fb1689dceb9  pop r9
00007fb1689dcebb  pop r8
00007fb1689dcebd  pop rsi
00007fb1689dcebe  pop rdi
00007fb1689dcebf  pop rdx
00007fb1689dcec0  pop rcx
00007fb1689dcec1  pop rax
00007fb1689dcec2  add rsp, 0x08
00007fb1689dcec6  jmp 0x00007FB1689D954D
00007fb1689dcecb  sub rsp, 0x08
00007fb1689dcecf  push rax
00007fb1689dced0  push rcx
00007fb1689dced1  push rdx
00007fb1689dced2  push rdi
00007fb1689dced3  push rsi
00007fb1689dced4  push r8
00007fb1689dced6  push r9
00007fb1689dced8  push r10
00007fb1689dceda  push r11
00007fb1689dcedc  sub rsp, 0xF0
00007fb1689dcee3  vmovaps [rsp], xmm0
00007fb1689dcee8  vmovaps [rsp+0x10], xmm1
00007fb1689dceee  vmovaps [rsp+0x20], xmm2
00007fb1689dcef4  vmovaps [rsp+0x30], xmm3
00007fb1689dcefa  vmovaps [rsp+0x40], xmm4
00007fb1689dcf00  vmovaps [rsp+0x50], xmm5
00007fb1689dcf06  vmovaps [rsp+0x60], xmm6
00007fb1689dcf0c  vmovaps [rsp+0x70], xmm7
00007fb1689dcf12  vmovaps [rsp+0x80], xmm8
00007fb1689dcf1b  vmovaps [rsp+0x90], xmm9
00007fb1689dcf24  vmovaps [rsp+0xA0], xmm11
00007fb1689dcf2d  vmovaps [rsp+0xB0], xmm12
00007fb1689dcf36  vmovaps [rsp+0xC0], xmm13
00007fb1689dcf3f  vmovaps [rsp+0xD0], xmm14
00007fb1689dcf48  vmovaps [rsp+0xE0], xmm15
00007fb1689dcf51  sub rsp, 0x30
00007fb1689dcf55  movaps [rsp], xmm10
00007fb1689dcf5a  movaps [rsp+0x10], xmm14
00007fb1689dcf60  movaps [rsp+0x20], xmm4
00007fb1689dcf65  lea rdi, [rsp]
00007fb1689dcf69  mov esi, 0x00
00007fb1689dcf6e  mov rax, 0x57CCFD419530
00007fb1689dcf78  call rax
00007fb1689dcf7a  movaps xmm10, [rsp]
00007fb1689dcf7f  add rsp, 0x30
00007fb1689dcf83  vmovaps xmm0, [rsp]
00007fb1689dcf88  vmovaps xmm1, [rsp+0x10]
00007fb1689dcf8e  vmovaps xmm2, [rsp+0x20]
00007fb1689dcf94  vmovaps xmm3, [rsp+0x30]
00007fb1689dcf9a  vmovaps xmm4, [rsp+0x40]
00007fb1689dcfa0  vmovaps xmm5, [rsp+0x50]
00007fb1689dcfa6  vmovaps xmm6, [rsp+0x60]
00007fb1689dcfac  vmovaps xmm7, [rsp+0x70]
00007fb1689dcfb2  vmovaps xmm8, [rsp+0x80]
00007fb1689dcfbb  vmovaps xmm9, [rsp+0x90]
00007fb1689dcfc4  vmovaps xmm11, [rsp+0xA0]
00007fb1689dcfcd  vmovaps xmm12, [rsp+0xB0]
00007fb1689dcfd6  vmovaps xmm13, [rsp+0xC0]
00007fb1689dcfdf  vmovaps xmm14, [rsp+0xD0]
00007fb1689dcfe8  vmovaps xmm15, [rsp+0xE0]
00007fb1689dcff1  add rsp, 0xF0
00007fb1689dcff8  pop r11
00007fb1689dcffa  pop r10
00007fb1689dcffc  pop r9
00007fb1689dcffe  pop r8
00007fb1689dd000  pop rsi
00007fb1689dd001  pop rdi
00007fb1689dd002  pop rdx
00007fb1689dd003  pop rcx
00007fb1689dd004  pop rax
00007fb1689dd005  add rsp, 0x08
00007fb1689dd009  jmp 0x00007FB1689D9568
00007fb1689dd00e  sub rsp, 0x08
00007fb1689dd012  push rax
00007fb1689dd013  push rcx
00007fb1689dd014  push rdx
00007fb1689dd015  push rdi
00007fb1689dd016  push rsi
00007fb1689dd017  push r8
00007fb1689dd019  push r9
00007fb1689dd01b  push r10
00007fb1689dd01d  push r11
00007fb1689dd01f  sub rsp, 0xF0
00007fb1689dd026  vmovaps [rsp], xmm0
00007fb1689dd02b  vmovaps [rsp+0x10], xmm1
00007fb1689dd031  vmovaps [rsp+0x20], xmm2
00007fb1689dd037  vmovaps [rsp+0x30], xmm3
00007fb1689dd03d  vmovaps [rsp+0x40], xmm4
00007fb1689dd043  vmovaps [rsp+0x50], xmm5
00007fb1689dd049  vmovaps [rsp+0x60], xmm6
00007fb1689dd04f  vmovaps [rsp+0x70], xmm7
00007fb1689dd055  vmovaps [rsp+0x80], xmm9
00007fb1689dd05e  vmovaps [rsp+0x90], xmm10
00007fb1689dd067  vmovaps [rsp+0xA0], xmm11
00007fb1689dd070  vmovaps [rsp+0xB0], xmm12
00007fb1689dd079  vmovaps [rsp+0xC0], xmm13
00007fb1689dd082  vmovaps [rsp+0xD0], xmm14
00007fb1689dd08b  vmovaps [rsp+0xE0], xmm15
00007fb1689dd094  sub rsp, 0x30
00007fb1689dd098  movaps [rsp], xmm8
00007fb1689dd09d  movaps [rsp+0x10], xmm1
00007fb1689dd0a2  movaps [rsp+0x20], xmm14
00007fb1689dd0a8  lea rdi, [rsp]
00007fb1689dd0ac  mov esi, 0x00
00007fb1689dd0b1  mov rax, 0x57CCFD419530
00007fb1689dd0bb  call rax
00007fb1689dd0bd  movaps xmm8, [rsp]
00007fb1689dd0c2  add rsp, 0x30
00007fb1689dd0c6  vmovaps xmm0, [rsp]
00007fb1689dd0cb  vmovaps xmm1, [rsp+0x10]
00007fb1689dd0d1  vmovaps xmm2, [rsp+0x20]
00007fb1689dd0d7  vmovaps xmm3, [rsp+0x30]
00007fb1689dd0dd  vmovaps xmm4, [rsp+0x40]
00007fb1689dd0e3  vmovaps xmm5, [rsp+0x50]
00007fb1689dd0e9  vmovaps xmm6, [rsp+0x60]
00007fb1689dd0ef  vmovaps xmm7, [rsp+0x70]
00007fb1689dd0f5  vmovaps xmm9, [rsp+0x80]
00007fb1689dd0fe  vmovaps xmm10, [rsp+0x90]
00007fb1689dd107  vmovaps xmm11, [rsp+0xA0]
00007fb1689dd110  vmovaps xmm12, [rsp+0xB0]
00007fb1689dd119  vmovaps xmm13, [rsp+0xC0]
00007fb1689dd122  vmovaps xmm14, [rsp+0xD0]
00007fb1689dd12b  vmovaps xmm15, [rsp+0xE0]
00007fb1689dd134  add rsp, 0xF0
00007fb1689dd13b  pop r11
00007fb1689dd13d  pop r10
00007fb1689dd13f  pop r9
00007fb1689dd141  pop r8
00007fb1689dd143  pop rsi
00007fb1689dd144  pop rdi
00007fb1689dd145  pop rdx
00007fb1689dd146  pop rcx
00007fb1689dd147  pop rax
00007fb1689dd148  add rsp, 0x08
00007fb1689dd14c  jmp 0x00007FB1689D958E
00007fb1689dd151  sub rsp, 0x08
00007fb1689dd155  push rax
00007fb1689dd156  push rcx
00007fb1689dd157  push rdx
00007fb1689dd158  push rdi
00007fb1689dd159  push rsi
00007fb1689dd15a  push r8
00007fb1689dd15c  push r9
00007fb1689dd15e  push r10
00007fb1689dd160  push r11
00007fb1689dd162  sub rsp, 0xF0
00007fb1689dd169  vmovaps [rsp], xmm0
00007fb1689dd16e  vmovaps [rsp+0x10], xmm1
00007fb1689dd174  vmovaps [rsp+0x20], xmm2
00007fb1689dd17a  vmovaps [rsp+0x30], xmm3
00007fb1689dd180  vmovaps [rsp+0x40], xmm4
00007fb1689dd186  vmovaps [rsp+0x50], xmm5
00007fb1689dd18c  vmovaps [rsp+0x60], xmm7
00007fb1689dd192  vmovaps [rsp+0x70], xmm8
00007fb1689dd198  vmovaps [rsp+0x80], xmm9
00007fb1689dd1a1  vmovaps [rsp+0x90], xmm10
00007fb1689dd1aa  vmovaps [rsp+0xA0], xmm11
00007fb1689dd1b3  vmovaps [rsp+0xB0], xmm12
00007fb1689dd1bc  vmovaps [rsp+0xC0], xmm13
00007fb1689dd1c5  vmovaps [rsp+0xD0], xmm14
00007fb1689dd1ce  vmovaps [rsp+0xE0], xmm15
00007fb1689dd1d7  sub rsp, 0x30
00007fb1689dd1db  movaps [rsp], xmm6
00007fb1689dd1df  movaps [rsp+0x10], xmm1
00007fb1689dd1e4  movaps [rsp+0x20], xmm14
00007fb1689dd1ea  lea rdi, [rsp]
00007fb1689dd1ee  mov esi, 0x00
00007fb1689dd1f3  mov rax, 0x57CCFD419530
00007fb1689dd1fd  call rax
00007fb1689dd1ff  movaps xmm6, [rsp]
00007fb1689dd203  add rsp, 0x30
00007fb1689dd207  vmovaps xmm0, [rsp]
00007fb1689dd20c  vmovaps xmm1, [rsp+0x10]
00007fb1689dd212  vmovaps xmm2, [rsp+0x20]
00007fb1689dd218  vmovaps xmm3, [rsp+0x30]
00007fb1689dd21e  vmovaps xmm4, [rsp+0x40]
00007fb1689dd224  vmovaps xmm5, [rsp+0x50]
00007fb1689dd22a  vmovaps xmm7, [rsp+0x60]
00007fb1689dd230  vmovaps xmm8, [rsp+0x70]
00007fb1689dd236  vmovaps xmm9, [rsp+0x80]
00007fb1689dd23f  vmovaps xmm10, [rsp+0x90]
00007fb1689dd248  vmovaps xmm11, [rsp+0xA0]
00007fb1689dd251  vmovaps xmm12, [rsp+0xB0]
00007fb1689dd25a  vmovaps xmm13, [rsp+0xC0]
00007fb1689dd263  vmovaps xmm14, [rsp+0xD0]
00007fb1689dd26c  vmovaps xmm15, [rsp+0xE0]
00007fb1689dd275  add rsp, 0xF0
00007fb1689dd27c  pop r11
00007fb1689dd27e  pop r10
00007fb1689dd280  pop r9
00007fb1689dd282  pop r8
00007fb1689dd284  pop rsi
00007fb1689dd285  pop rdi
00007fb1689dd286  pop rdx
00007fb1689dd287  pop rcx
00007fb1689dd288  pop rax
00007fb1689dd289  add rsp, 0x08
00007fb1689dd28d  jmp 0x00007FB1689D95BA
00007fb1689dd292  sub rsp, 0x08
00007fb1689dd296  push rax
00007fb1689dd297  push rcx
00007fb1689dd298  push rdx
00007fb1689dd299  push rdi
00007fb1689dd29a  push rsi
00007fb1689dd29b  push r8
00007fb1689dd29d  push r9
00007fb1689dd29f  push r10
00007fb1689dd2a1  push r11
00007fb1689dd2a3  sub rsp, 0xF0
00007fb1689dd2aa  vmovaps [rsp], xmm0
00007fb1689dd2af  vmovaps [rsp+0x10], xmm1
00007fb1689dd2b5  vmovaps [rsp+0x20], xmm2
00007fb1689dd2bb  vmovaps [rsp+0x30], xmm3
00007fb1689dd2c1  vmovaps [rsp+0x40], xmm4
00007fb1689dd2c7  vmovaps [rsp+0x50], xmm5
00007fb1689dd2cd  vmovaps [rsp+0x60], xmm6
00007fb1689dd2d3  vmovaps [rsp+0x70], xmm7
00007fb1689dd2d9  vmovaps [rsp+0x80], xmm8
00007fb1689dd2e2  vmovaps [rsp+0x90], xmm9
00007fb1689dd2eb  vmovaps [rsp+0xA0], xmm10
00007fb1689dd2f4  vmovaps [rsp+0xB0], xmm11
00007fb1689dd2fd  vmovaps [rsp+0xC0], xmm12
00007fb1689dd306  vmovaps [rsp+0xD0], xmm13
00007fb1689dd30f  vmovaps [rsp+0xE0], xmm15
00007fb1689dd318  sub rsp, 0x30
00007fb1689dd31c  movaps [rsp], xmm14
00007fb1689dd321  movaps [rsp+0x10], xmm12
00007fb1689dd327  movaps [rsp+0x20], xmm1
00007fb1689dd32c  lea rdi, [rsp]
00007fb1689dd330  mov esi, 0x00
00007fb1689dd335  mov rax, 0x57CCFD419530
00007fb1689dd33f  call rax
00007fb1689dd341  movaps xmm14, [rsp]
00007fb1689dd346  add rsp, 0x30
00007fb1689dd34a  vmovaps xmm0, [rsp]
00007fb1689dd34f  vmovaps xmm1, [rsp+0x10]
00007fb1689dd355  vmovaps xmm2, [rsp+0x20]
00007fb1689dd35b  vmovaps xmm3, [rsp+0x30]
00007fb1689dd361  vmovaps xmm4, [rsp+0x40]
00007fb1689dd367  vmovaps xmm5, [rsp+0x50]
00007fb1689dd36d  vmovaps xmm6, [rsp+0x60]
00007fb1689dd373  vmovaps xmm7, [rsp+0x70]
00007fb1689dd379  vmovaps xmm8, [rsp+0x80]
00007fb1689dd382  vmovaps xmm9, [rsp+0x90]
00007fb1689dd38b  vmovaps xmm10, [rsp+0xA0]
00007fb1689dd394  vmovaps xmm11, [rsp+0xB0]
00007fb1689dd39d  vmovaps xmm12, [rsp+0xC0]
00007fb1689dd3a6  vmovaps xmm13, [rsp+0xD0]
00007fb1689dd3af  vmovaps xmm15, [rsp+0xE0]
00007fb1689dd3b8  add rsp, 0xF0
00007fb1689dd3bf  pop r11
00007fb1689dd3c1  pop r10
00007fb1689dd3c3  pop r9
00007fb1689dd3c5  pop r8
00007fb1689dd3c7  pop rsi
00007fb1689dd3c8  pop rdi
00007fb1689dd3c9  pop rdx
00007fb1689dd3ca  pop rcx
00007fb1689dd3cb  pop rax
00007fb1689dd3cc  add rsp, 0x08
00007fb1689dd3d0  jmp 0x00007FB1689D95E0
00007fb1689dd3d5  sub rsp, 0x08
00007fb1689dd3d9  push rax
00007fb1689dd3da  push rcx
00007fb1689dd3db  push rdx
00007fb1689dd3dc  push rdi
00007fb1689dd3dd  push rsi
00007fb1689dd3de  push r8
00007fb1689dd3e0  push r9
00007fb1689dd3e2  push r10
00007fb1689dd3e4  push r11
00007fb1689dd3e6  sub rsp, 0xF0
00007fb1689dd3ed  vmovaps [rsp], xmm0
00007fb1689dd3f2  vmovaps [rsp+0x10], xmm2
00007fb1689dd3f8  vmovaps [rsp+0x20], xmm3
00007fb1689dd3fe  vmovaps [rsp+0x30], xmm4
00007fb1689dd404  vmovaps [rsp+0x40], xmm5
00007fb1689dd40a  vmovaps [rsp+0x50], xmm6
00007fb1689dd410  vmovaps [rsp+0x60], xmm7
00007fb1689dd416  vmovaps [rsp+0x70], xmm8
00007fb1689dd41c  vmovaps [rsp+0x80], xmm9
00007fb1689dd425  vmovaps [rsp+0x90], xmm10
00007fb1689dd42e  vmovaps [rsp+0xA0], xmm11
00007fb1689dd437  vmovaps [rsp+0xB0], xmm12
00007fb1689dd440  vmovaps [rsp+0xC0], xmm13
00007fb1689dd449  vmovaps [rsp+0xD0], xmm14
00007fb1689dd452  vmovaps [rsp+0xE0], xmm15
00007fb1689dd45b  sub rsp, 0x30
00007fb1689dd45f  movaps [rsp], xmm1
00007fb1689dd463  movaps [rsp+0x10], xmm13
00007fb1689dd469  movaps [rsp+0x20], xmm9
00007fb1689dd46f  lea rdi, [rsp]
00007fb1689dd473  mov esi, 0x00
00007fb1689dd478  mov rax, 0x57CCFD419530
00007fb1689dd482  call rax
00007fb1689dd484  movaps xmm1, [rsp]
00007fb1689dd488  add rsp, 0x30
00007fb1689dd48c  vmovaps xmm0, [rsp]
00007fb1689dd491  vmovaps xmm2, [rsp+0x10]
00007fb1689dd497  vmovaps xmm3, [rsp+0x20]
00007fb1689dd49d  vmovaps xmm4, [rsp+0x30]
00007fb1689dd4a3  vmovaps xmm5, [rsp+0x40]
00007fb1689dd4a9  vmovaps xmm6, [rsp+0x50]
00007fb1689dd4af  vmovaps xmm7, [rsp+0x60]
00007fb1689dd4b5  vmovaps xmm8, [rsp+0x70]
00007fb1689dd4bb  vmovaps xmm9, [rsp+0x80]
00007fb1689dd4c4  vmovaps xmm10, [rsp+0x90]
00007fb1689dd4cd  vmovaps xmm11, [rsp+0xA0]
00007fb1689dd4d6  vmovaps xmm12, [rsp+0xB0]
00007fb1689dd4df  vmovaps xmm13, [rsp+0xC0]
00007fb1689dd4e8  vmovaps xmm14, [rsp+0xD0]
00007fb1689dd4f1  vmovaps xmm15, [rsp+0xE0]
00007fb1689dd4fa  add rsp, 0xF0
00007fb1689dd501  pop r11
00007fb1689dd503  pop r10
00007fb1689dd505  pop r9
00007fb1689dd507  pop r8
00007fb1689dd509  pop rsi
00007fb1689dd50a  pop rdi
00007fb1689dd50b  pop rdx
00007fb1689dd50c  pop rcx
00007fb1689dd50d  pop rax
00007fb1689dd50e  add rsp, 0x08
00007fb1689dd512  jmp 0x00007FB1689D95FA
00007fb1689dd517  sub rsp, 0x08
00007fb1689dd51b  push rax
00007fb1689dd51c  push rcx
00007fb1689dd51d  push rdx
00007fb1689dd51e  push rdi
00007fb1689dd51f  push rsi
00007fb1689dd520  push r8
00007fb1689dd522  push r9
00007fb1689dd524  push r10
00007fb1689dd526  push r11
00007fb1689dd528  sub rsp, 0xF0
00007fb1689dd52f  vmovaps [rsp], xmm0
00007fb1689dd534  vmovaps [rsp+0x10], xmm1
00007fb1689dd53a  vmovaps [rsp+0x20], xmm2
00007fb1689dd540  vmovaps [rsp+0x30], xmm3
00007fb1689dd546  vmovaps [rsp+0x40], xmm4
00007fb1689dd54c  vmovaps [rsp+0x50], xmm5
00007fb1689dd552  vmovaps [rsp+0x60], xmm6
00007fb1689dd558  vmovaps [rsp+0x70], xmm7
00007fb1689dd55e  vmovaps [rsp+0x80], xmm8
00007fb1689dd567  vmovaps [rsp+0x90], xmm9
00007fb1689dd570  vmovaps [rsp+0xA0], xmm10
00007fb1689dd579  vmovaps [rsp+0xB0], xmm11
00007fb1689dd582  vmovaps [rsp+0xC0], xmm13
00007fb1689dd58b  vmovaps [rsp+0xD0], xmm14
00007fb1689dd594  vmovaps [rsp+0xE0], xmm15
00007fb1689dd59d  sub rsp, 0x30
00007fb1689dd5a1  movaps [rsp], xmm12
00007fb1689dd5a6  movaps [rsp+0x10], xmm7
00007fb1689dd5ab  movaps [rsp+0x20], xmm13
00007fb1689dd5b1  lea rdi, [rsp]
00007fb1689dd5b5  mov esi, 0x00
00007fb1689dd5ba  mov rax, 0x57CCFD419530
00007fb1689dd5c4  call rax
00007fb1689dd5c6  movaps xmm12, [rsp]
00007fb1689dd5cb  add rsp, 0x30
00007fb1689dd5cf  vmovaps xmm0, [rsp]
00007fb1689dd5d4  vmovaps xmm1, [rsp+0x10]
00007fb1689dd5da  vmovaps xmm2, [rsp+0x20]
00007fb1689dd5e0  vmovaps xmm3, [rsp+0x30]
00007fb1689dd5e6  vmovaps xmm4, [rsp+0x40]
00007fb1689dd5ec  vmovaps xmm5, [rsp+0x50]
00007fb1689dd5f2  vmovaps xmm6, [rsp+0x60]
00007fb1689dd5f8  vmovaps xmm7, [rsp+0x70]
00007fb1689dd5fe  vmovaps xmm8, [rsp+0x80]
00007fb1689dd607  vmovaps xmm9, [rsp+0x90]
00007fb1689dd610  vmovaps xmm10, [rsp+0xA0]
00007fb1689dd619  vmovaps xmm11, [rsp+0xB0]
00007fb1689dd622  vmovaps xmm13, [rsp+0xC0]
00007fb1689dd62b  vmovaps xmm14, [rsp+0xD0]
00007fb1689dd634  vmovaps xmm15, [rsp+0xE0]
00007fb1689dd63d  add rsp, 0xF0
00007fb1689dd644  pop r11
00007fb1689dd646  pop r10
00007fb1689dd648  pop r9
00007fb1689dd64a  pop r8
00007fb1689dd64c  pop rsi
00007fb1689dd64d  pop rdi
00007fb1689dd64e  pop rdx
00007fb1689dd64f  pop rcx
00007fb1689dd650  pop rax
00007fb1689dd651  add rsp, 0x08
00007fb1689dd655  jmp 0x00007FB1689D9621
00007fb1689dd65a  sub rsp, 0x08
00007fb1689dd65e  push rax
00007fb1689dd65f  push rcx
00007fb1689dd660  push rdx
00007fb1689dd661  push rdi
00007fb1689dd662  push rsi
00007fb1689dd663  push r8
00007fb1689dd665  push r9
00007fb1689dd667  push r10
00007fb1689dd669  push r11
00007fb1689dd66b  sub rsp, 0xF0
00007fb1689dd672  vmovaps [rsp], xmm0
00007fb1689dd677  vmovaps [rsp+0x10], xmm1
00007fb1689dd67d  vmovaps [rsp+0x20], xmm2
00007fb1689dd683  vmovaps [rsp+0x30], xmm3
00007fb1689dd689  vmovaps [rsp+0x40], xmm4
00007fb1689dd68f  vmovaps [rsp+0x50], xmm5
00007fb1689dd695  vmovaps [rsp+0x60], xmm6
00007fb1689dd69b  vmovaps [rsp+0x70], xmm7
00007fb1689dd6a1  vmovaps [rsp+0x80], xmm8
00007fb1689dd6aa  vmovaps [rsp+0x90], xmm9
00007fb1689dd6b3  vmovaps [rsp+0xA0], xmm10
00007fb1689dd6bc  vmovaps [rsp+0xB0], xmm11
00007fb1689dd6c5  vmovaps [rsp+0xC0], xmm12
00007fb1689dd6ce  vmovaps [rsp+0xD0], xmm14
00007fb1689dd6d7  vmovaps [rsp+0xE0], xmm15
00007fb1689dd6e0  sub rsp, 0x30
00007fb1689dd6e4  movaps [rsp], xmm13
00007fb1689dd6e9  movaps [rsp+0x10], xmm15
00007fb1689dd6ef  movaps [rsp+0x20], xmm8
00007fb1689dd6f5  lea rdi, [rsp]
00007fb1689dd6f9  mov esi, 0x00
00007fb1689dd6fe  mov rax, 0x57CCFD419530
00007fb1689dd708  call rax
00007fb1689dd70a  movaps xmm13, [rsp]
00007fb1689dd70f  add rsp, 0x30
00007fb1689dd713  vmovaps xmm0, [rsp]
00007fb1689dd718  vmovaps xmm1, [rsp+0x10]
00007fb1689dd71e  vmovaps xmm2, [rsp+0x20]
00007fb1689dd724  vmovaps xmm3, [rsp+0x30]
00007fb1689dd72a  vmovaps xmm4, [rsp+0x40]
00007fb1689dd730  vmovaps xmm5, [rsp+0x50]
00007fb1689dd736  vmovaps xmm6, [rsp+0x60]
00007fb1689dd73c  vmovaps xmm7, [rsp+0x70]
00007fb1689dd742  vmovaps xmm8, [rsp+0x80]
00007fb1689dd74b  vmovaps xmm9, [rsp+0x90]
00007fb1689dd754  vmovaps xmm10, [rsp+0xA0]
00007fb1689dd75d  vmovaps xmm11, [rsp+0xB0]
00007fb1689dd766  vmovaps xmm12, [rsp+0xC0]
00007fb1689dd76f  vmovaps xmm14, [rsp+0xD0]
00007fb1689dd778  vmovaps xmm15, [rsp+0xE0]
00007fb1689dd781  add rsp, 0xF0
00007fb1689dd788  pop r11
00007fb1689dd78a  pop r10
00007fb1689dd78c  pop r9
00007fb1689dd78e  pop r8
00007fb1689dd790  pop rsi
00007fb1689dd791  pop rdi
00007fb1689dd792  pop rdx
00007fb1689dd793  pop rcx
00007fb1689dd794  pop rax
00007fb1689dd795  add rsp, 0x08
00007fb1689dd799  jmp 0x00007FB1689D963C
00007fb1689dd79e  sub rsp, 0x08
00007fb1689dd7a2  push rax
00007fb1689dd7a3  push rcx
00007fb1689dd7a4  push rdx
00007fb1689dd7a5  push rdi
00007fb1689dd7a6  push rsi
00007fb1689dd7a7  push r8
00007fb1689dd7a9  push r9
00007fb1689dd7ab  push r10
00007fb1689dd7ad  push r11
00007fb1689dd7af  sub rsp, 0xF0
00007fb1689dd7b6  vmovaps [rsp], xmm0
00007fb1689dd7bb  vmovaps [rsp+0x10], xmm1
00007fb1689dd7c1  vmovaps [rsp+0x20], xmm2
00007fb1689dd7c7  vmovaps [rsp+0x30], xmm3
00007fb1689dd7cd  vmovaps [rsp+0x40], xmm4
00007fb1689dd7d3  vmovaps [rsp+0x50], xmm5
00007fb1689dd7d9  vmovaps [rsp+0x60], xmm6
00007fb1689dd7df  vmovaps [rsp+0x70], xmm7
00007fb1689dd7e5  vmovaps [rsp+0x80], xmm9
00007fb1689dd7ee  vmovaps [rsp+0x90], xmm10
00007fb1689dd7f7  vmovaps [rsp+0xA0], xmm11
00007fb1689dd800  vmovaps [rsp+0xB0], xmm12
00007fb1689dd809  vmovaps [rsp+0xC0], xmm13
00007fb1689dd812  vmovaps [rsp+0xD0], xmm14
00007fb1689dd81b  vmovaps [rsp+0xE0], xmm15
00007fb1689dd824  sub rsp, 0x30
00007fb1689dd828  movaps [rsp], xmm8
00007fb1689dd82d  movaps [rsp+0x10], xmm15
00007fb1689dd833  movaps [rsp+0x20], xmm9
00007fb1689dd839  lea rdi, [rsp]
00007fb1689dd83d  mov esi, 0x00
00007fb1689dd842  mov rax, 0x57CCFD419530
00007fb1689dd84c  call rax
00007fb1689dd84e  movaps xmm8, [rsp]
00007fb1689dd853  add rsp, 0x30
00007fb1689dd857  vmovaps xmm0, [rsp]
00007fb1689dd85c  vmovaps xmm1, [rsp+0x10]
00007fb1689dd862  vmovaps xmm2, [rsp+0x20]
00007fb1689dd868  vmovaps xmm3, [rsp+0x30]
00007fb1689dd86e  vmovaps xmm4, [rsp+0x40]
00007fb1689dd874  vmovaps xmm5, [rsp+0x50]
00007fb1689dd87a  vmovaps xmm6, [rsp+0x60]
00007fb1689dd880  vmovaps xmm7, [rsp+0x70]
00007fb1689dd886  vmovaps xmm9, [rsp+0x80]
00007fb1689dd88f  vmovaps xmm10, [rsp+0x90]
00007fb1689dd898  vmovaps xmm11, [rsp+0xA0]
00007fb1689dd8a1  vmovaps xmm12, [rsp+0xB0]
00007fb1689dd8aa  vmovaps xmm13, [rsp+0xC0]
00007fb1689dd8b3  vmovaps xmm14, [rsp+0xD0]
00007fb1689dd8bc  vmovaps xmm15, [rsp+0xE0]
00007fb1689dd8c5  add rsp, 0xF0
00007fb1689dd8cc  pop r11
00007fb1689dd8ce  pop r10
00007fb1689dd8d0  pop r9
00007fb1689dd8d2  pop r8
00007fb1689dd8d4  pop rsi
00007fb1689dd8d5  pop rdi
00007fb1689dd8d6  pop rdx
00007fb1689dd8d7  pop rcx
00007fb1689dd8d8  pop rax
00007fb1689dd8d9  add rsp, 0x08
00007fb1689dd8dd  jmp 0x00007FB1689D966A
00007fb1689dd8e2  sub rsp, 0x08
00007fb1689dd8e6  push rax
00007fb1689dd8e7  push rcx
00007fb1689dd8e8  push rdx
00007fb1689dd8e9  push rdi
00007fb1689dd8ea  push rsi
00007fb1689dd8eb  push r8
00007fb1689dd8ed  push r9
00007fb1689dd8ef  push r10
00007fb1689dd8f1  push r11
00007fb1689dd8f3  sub rsp, 0xF0
00007fb1689dd8fa  vmovaps [rsp], xmm0
00007fb1689dd8ff  vmovaps [rsp+0x10], xmm1
00007fb1689dd905  vmovaps [rsp+0x20], xmm2
00007fb1689dd90b  vmovaps [rsp+0x30], xmm3
00007fb1689dd911  vmovaps [rsp+0x40], xmm4
00007fb1689dd917  vmovaps [rsp+0x50], xmm5
00007fb1689dd91d  vmovaps [rsp+0x60], xmm6
00007fb1689dd923  vmovaps [rsp+0x70], xmm7
00007fb1689dd929  vmovaps [rsp+0x80], xmm8
00007fb1689dd932  vmovaps [rsp+0x90], xmm9
00007fb1689dd93b  vmovaps [rsp+0xA0], xmm10
00007fb1689dd944  vmovaps [rsp+0xB0], xmm11
00007fb1689dd94d  vmovaps [rsp+0xC0], xmm12
00007fb1689dd956  vmovaps [rsp+0xD0], xmm13
00007fb1689dd95f  vmovaps [rsp+0xE0], xmm14
00007fb1689dd968  sub rsp, 0x30
00007fb1689dd96c  movaps [rsp], xmm15
00007fb1689dd971  movaps [rsp+0x10], xmm11
00007fb1689dd977  movaps [rsp+0x20], xmm6
00007fb1689dd97c  lea rdi, [rsp]
00007fb1689dd980  mov esi, 0x00
00007fb1689dd985  mov rax, 0x57CCFD419530
00007fb1689dd98f  call rax
00007fb1689dd991  movaps xmm15, [rsp]
00007fb1689dd996  add rsp, 0x30
00007fb1689dd99a  vmovaps xmm0, [rsp]
00007fb1689dd99f  vmovaps xmm1, [rsp+0x10]
00007fb1689dd9a5  vmovaps xmm2, [rsp+0x20]
00007fb1689dd9ab  vmovaps xmm3, [rsp+0x30]
00007fb1689dd9b1  vmovaps xmm4, [rsp+0x40]
00007fb1689dd9b7  vmovaps xmm5, [rsp+0x50]
00007fb1689dd9bd  vmovaps xmm6, [rsp+0x60]
00007fb1689dd9c3  vmovaps xmm7, [rsp+0x70]
00007fb1689dd9c9  vmovaps xmm8, [rsp+0x80]
00007fb1689dd9d2  vmovaps xmm9, [rsp+0x90]
00007fb1689dd9db  vmovaps xmm10, [rsp+0xA0]
00007fb1689dd9e4  vmovaps xmm11, [rsp+0xB0]
00007fb1689dd9ed  vmovaps xmm12, [rsp+0xC0]
00007fb1689dd9f6  vmovaps xmm13, [rsp+0xD0]
00007fb1689dd9ff  vmovaps xmm14, [rsp+0xE0]
00007fb1689dda08  add rsp, 0xF0
00007fb1689dda0f  pop r11
00007fb1689dda11  pop r10
00007fb1689dda13  pop r9
00007fb1689dda15  pop r8
00007fb1689dda17  pop rsi
00007fb1689dda18  pop rdi
00007fb1689dda19  pop rdx
00007fb1689dda1a  pop rcx
00007fb1689dda1b  pop rax
00007fb1689dda1c  add rsp, 0x08
00007fb1689dda20  jmp 0x00007FB1689D9685
00007fb1689dda25  sub rsp, 0x08
00007fb1689dda29  push rax
00007fb1689dda2a  push rcx
00007fb1689dda2b  push rdx
00007fb1689dda2c  push rdi
00007fb1689dda2d  push rsi
00007fb1689dda2e  push r8
00007fb1689dda30  push r9
00007fb1689dda32  push r10
00007fb1689dda34  push r11
00007fb1689dda36  sub rsp, 0xF0
00007fb1689dda3d  vmovaps [rsp], xmm0
00007fb1689dda42  vmovaps [rsp+0x10], xmm1
00007fb1689dda48  vmovaps [rsp+0x20], xmm2
00007fb1689dda4e  vmovaps [rsp+0x30], xmm3
00007fb1689dda54  vmovaps [rsp+0x40], xmm4
00007fb1689dda5a  vmovaps [rsp+0x50], xmm5
00007fb1689dda60  vmovaps [rsp+0x60], xmm6
00007fb1689dda66  vmovaps [rsp+0x70], xmm8
00007fb1689dda6c  vmovaps [rsp+0x80], xmm9
00007fb1689dda75  vmovaps [rsp+0x90], xmm10
00007fb1689dda7e  vmovaps [rsp+0xA0], xmm11
00007fb1689dda87  vmovaps [rsp+0xB0], xmm12
00007fb1689dda90  vmovaps [rsp+0xC0], xmm13
00007fb1689dda99  vmovaps [rsp+0xD0], xmm14
00007fb1689ddaa2  vmovaps [rsp+0xE0], xmm15
00007fb1689ddaab  sub rsp, 0x30
00007fb1689ddaaf  movaps [rsp], xmm7
00007fb1689ddab3  movaps [rsp+0x10], xmm11
00007fb1689ddab9  movaps [rsp+0x20], xmm9
00007fb1689ddabf  lea rdi, [rsp]
00007fb1689ddac3  mov esi, 0x00
00007fb1689ddac8  mov rax, 0x57CCFD419530
00007fb1689ddad2  call rax
00007fb1689ddad4  movaps xmm7, [rsp]
00007fb1689ddad8  add rsp, 0x30
00007fb1689ddadc  vmovaps xmm0, [rsp]
00007fb1689ddae1  vmovaps xmm1, [rsp+0x10]
00007fb1689ddae7  vmovaps xmm2, [rsp+0x20]
00007fb1689ddaed  vmovaps xmm3, [rsp+0x30]
00007fb1689ddaf3  vmovaps xmm4, [rsp+0x40]
00007fb1689ddaf9  vmovaps xmm5, [rsp+0x50]
00007fb1689ddaff  vmovaps xmm6, [rsp+0x60]
00007fb1689ddb05  vmovaps xmm8, [rsp+0x70]
00007fb1689ddb0b  vmovaps xmm9, [rsp+0x80]
00007fb1689ddb14  vmovaps xmm10, [rsp+0x90]
00007fb1689ddb1d  vmovaps xmm11, [rsp+0xA0]
00007fb1689ddb26  vmovaps xmm12, [rsp+0xB0]
00007fb1689ddb2f  vmovaps xmm13, [rsp+0xC0]
00007fb1689ddb38  vmovaps xmm14, [rsp+0xD0]
00007fb1689ddb41  vmovaps xmm15, [rsp+0xE0]
00007fb1689ddb4a  add rsp, 0xF0
00007fb1689ddb51  pop r11
00007fb1689ddb53  pop r10
00007fb1689ddb55  pop r9
00007fb1689ddb57  pop r8
00007fb1689ddb59  pop rsi
00007fb1689ddb5a  pop rdi
00007fb1689ddb5b  pop rdx
00007fb1689ddb5c  pop rcx
00007fb1689ddb5d  pop rax
00007fb1689ddb5e  add rsp, 0x08
00007fb1689ddb62  jmp 0x00007FB1689D96B2
00007fb1689ddb67  sub rsp, 0x08
00007fb1689ddb6b  push rax
00007fb1689ddb6c  push rcx
00007fb1689ddb6d  push rdx
00007fb1689ddb6e  push rdi
00007fb1689ddb6f  push rsi
00007fb1689ddb70  push r8
00007fb1689ddb72  push r9
00007fb1689ddb74  push r10
00007fb1689ddb76  push r11
00007fb1689ddb78  sub rsp, 0xF0
00007fb1689ddb7f  vmovaps [rsp], xmm0
00007fb1689ddb84  vmovaps [rsp+0x10], xmm1
00007fb1689ddb8a  vmovaps [rsp+0x20], xmm2
00007fb1689ddb90  vmovaps [rsp+0x30], xmm3
00007fb1689ddb96  vmovaps [rsp+0x40], xmm4
00007fb1689ddb9c  vmovaps [rsp+0x50], xmm5
00007fb1689ddba2  vmovaps [rsp+0x60], xmm6
00007fb1689ddba8  vmovaps [rsp+0x70], xmm7
00007fb1689ddbae  vmovaps [rsp+0x80], xmm8
00007fb1689ddbb7  vmovaps [rsp+0x90], xmm9
00007fb1689ddbc0  vmovaps [rsp+0xA0], xmm10
00007fb1689ddbc9  vmovaps [rsp+0xB0], xmm12
00007fb1689ddbd2  vmovaps [rsp+0xC0], xmm13
00007fb1689ddbdb  vmovaps [rsp+0xD0], xmm14
00007fb1689ddbe4  vmovaps [rsp+0xE0], xmm15
00007fb1689ddbed  sub rsp, 0x30
00007fb1689ddbf1  movaps [rsp], xmm11
00007fb1689ddbf6  movaps [rsp+0x10], xmm10
00007fb1689ddbfc  movaps [rsp+0x20], xmm14
00007fb1689ddc02  lea rdi, [rsp]
00007fb1689ddc06  mov esi, 0x00
00007fb1689ddc0b  mov rax, 0x57CCFD419530
00007fb1689ddc15  call rax
00007fb1689ddc17  movaps xmm11, [rsp]
00007fb1689ddc1c  add rsp, 0x30
00007fb1689ddc20  vmovaps xmm0, [rsp]
00007fb1689ddc25  vmovaps xmm1, [rsp+0x10]
00007fb1689ddc2b  vmovaps xmm2, [rsp+0x20]
00007fb1689ddc31  vmovaps xmm3, [rsp+0x30]
00007fb1689ddc37  vmovaps xmm4, [rsp+0x40]
00007fb1689ddc3d  vmovaps xmm5, [rsp+0x50]
00007fb1689ddc43  vmovaps xmm6, [rsp+0x60]
00007fb1689ddc49  vmovaps xmm7, [rsp+0x70]
00007fb1689ddc4f  vmovaps xmm8, [rsp+0x80]
00007fb1689ddc58  vmovaps xmm9, [rsp+0x90]
00007fb1689ddc61  vmovaps xmm10, [rsp+0xA0]
00007fb1689ddc6a  vmovaps xmm12, [rsp+0xB0]
00007fb1689ddc73  vmovaps xmm13, [rsp+0xC0]
00007fb1689ddc7c  vmovaps xmm14, [rsp+0xD0]
00007fb1689ddc85  vmovaps xmm15, [rsp+0xE0]
00007fb1689ddc8e  add rsp, 0xF0
00007fb1689ddc95  pop r11
00007fb1689ddc97  pop r10
00007fb1689ddc99  pop r9
00007fb1689ddc9b  pop r8
00007fb1689ddc9d  pop rsi
00007fb1689ddc9e  pop rdi
00007fb1689ddc9f  pop rdx
00007fb1689ddca0  pop rcx
00007fb1689ddca1  pop rax
00007fb1689ddca2  add rsp, 0x08
00007fb1689ddca6  jmp 0x00007FB1689D96CD
00007fb1689ddcab  call 0x00007FB1688E45A0
00007fb1689ddcb0  jmp 0x00007FB1689D96D7
00007fb1689ddcb5  sub rsp, 0x08
00007fb1689ddcb9  push rax
00007fb1689ddcba  push rcx
00007fb1689ddcbb  push rdx
00007fb1689ddcbc  push rdi
00007fb1689ddcbd  push rsi
00007fb1689ddcbe  push r8
00007fb1689ddcc0  push r9
00007fb1689ddcc2  push r10
00007fb1689ddcc4  push r11
00007fb1689ddcc6  sub rsp, 0xF0
00007fb1689ddccd  vmovaps [rsp], xmm0
00007fb1689ddcd2  vmovaps [rsp+0x10], xmm1
00007fb1689ddcd8  vmovaps [rsp+0x20], xmm2
00007fb1689ddcde  vmovaps [rsp+0x30], xmm3
00007fb1689ddce4  vmovaps [rsp+0x40], xmm4
00007fb1689ddcea  vmovaps [rsp+0x50], xmm5
00007fb1689ddcf0  vmovaps [rsp+0x60], xmm6
00007fb1689ddcf6  vmovaps [rsp+0x70], xmm7
00007fb1689ddcfc  vmovaps [rsp+0x80], xmm8
00007fb1689ddd05  vmovaps [rsp+0x90], xmm9
00007fb1689ddd0e  vmovaps [rsp+0xA0], xmm11
00007fb1689ddd17  vmovaps [rsp+0xB0], xmm12
00007fb1689ddd20  vmovaps [rsp+0xC0], xmm13
00007fb1689ddd29  vmovaps [rsp+0xD0], xmm14
00007fb1689ddd32  vmovaps [rsp+0xE0], xmm15
00007fb1689ddd3b  sub rsp, 0x30
00007fb1689ddd3f  movaps [rsp], xmm10
00007fb1689ddd44  movaps [rsp+0x10], xmm1
00007fb1689ddd49  movaps [rsp+0x20], xmm12
00007fb1689ddd4f  lea rdi, [rsp]
00007fb1689ddd53  mov esi, 0x00
00007fb1689ddd58  mov rax, 0x57CCFD419530
00007fb1689ddd62  call rax
00007fb1689ddd64  movaps xmm10, [rsp]
00007fb1689ddd69  add rsp, 0x30
00007fb1689ddd6d  vmovaps xmm0, [rsp]
00007fb1689ddd72  vmovaps xmm1, [rsp+0x10]
00007fb1689ddd78  vmovaps xmm2, [rsp+0x20]
00007fb1689ddd7e  vmovaps xmm3, [rsp+0x30]
00007fb1689ddd84  vmovaps xmm4, [rsp+0x40]
00007fb1689ddd8a  vmovaps xmm5, [rsp+0x50]
00007fb1689ddd90  vmovaps xmm6, [rsp+0x60]
00007fb1689ddd96  vmovaps xmm7, [rsp+0x70]
00007fb1689ddd9c  vmovaps xmm8, [rsp+0x80]
00007fb1689ddda5  vmovaps xmm9, [rsp+0x90]
00007fb1689dddae  vmovaps xmm11, [rsp+0xA0]
00007fb1689dddb7  vmovaps xmm12, [rsp+0xB0]
00007fb1689dddc0  vmovaps xmm13, [rsp+0xC0]
00007fb1689dddc9  vmovaps xmm14, [rsp+0xD0]
00007fb1689dddd2  vmovaps xmm15, [rsp+0xE0]
00007fb1689ddddb  add rsp, 0xF0
00007fb1689ddde2  pop r11
00007fb1689ddde4  pop r10
00007fb1689ddde6  pop r9
00007fb1689ddde8  pop r8
00007fb1689dddea  pop rsi
00007fb1689dddeb  pop rdi
00007fb1689dddec  pop rdx
00007fb1689ddded  pop rcx
00007fb1689dddee  pop rax
00007fb1689dddef  add rsp, 0x08
00007fb1689dddf3  jmp 0x00007FB1689D96FA
00007fb1689dddf8  sub rsp, 0x08
00007fb1689dddfc  push rax
00007fb1689dddfd  push rcx
00007fb1689dddfe  push rdx
00007fb1689dddff  push rdi
00007fb1689dde00  push rsi
00007fb1689dde01  push r8
00007fb1689dde03  push r9
00007fb1689dde05  push r10
00007fb1689dde07  push r11
00007fb1689dde09  sub rsp, 0xF0
00007fb1689dde10  vmovaps [rsp], xmm0
00007fb1689dde15  vmovaps [rsp+0x10], xmm1
00007fb1689dde1b  vmovaps [rsp+0x20], xmm2
00007fb1689dde21  vmovaps [rsp+0x30], xmm3
00007fb1689dde27  vmovaps [rsp+0x40], xmm4
00007fb1689dde2d  vmovaps [rsp+0x50], xmm5
00007fb1689dde33  vmovaps [rsp+0x60], xmm6
00007fb1689dde39  vmovaps [rsp+0x70], xmm7
00007fb1689dde3f  vmovaps [rsp+0x80], xmm8
00007fb1689dde48  vmovaps [rsp+0x90], xmm9
00007fb1689dde51  vmovaps [rsp+0xA0], xmm10
00007fb1689dde5a  vmovaps [rsp+0xB0], xmm11
00007fb1689dde63  vmovaps [rsp+0xC0], xmm13
00007fb1689dde6c  vmovaps [rsp+0xD0], xmm14
00007fb1689dde75  vmovaps [rsp+0xE0], xmm15
00007fb1689dde7e  sub rsp, 0x30
00007fb1689dde82  movaps [rsp], xmm12
00007fb1689dde87  movaps [rsp+0x10], xmm14
00007fb1689dde8d  movaps [rsp+0x20], xmm1
00007fb1689dde92  lea rdi, [rsp]
00007fb1689dde96  mov esi, 0x00
00007fb1689dde9b  mov rax, 0x57CCFD419530
00007fb1689ddea5  call rax
00007fb1689ddea7  movaps xmm12, [rsp]
00007fb1689ddeac  add rsp, 0x30
00007fb1689ddeb0  vmovaps xmm0, [rsp]
00007fb1689ddeb5  vmovaps xmm1, [rsp+0x10]
00007fb1689ddebb  vmovaps xmm2, [rsp+0x20]
00007fb1689ddec1  vmovaps xmm3, [rsp+0x30]
00007fb1689ddec7  vmovaps xmm4, [rsp+0x40]
00007fb1689ddecd  vmovaps xmm5, [rsp+0x50]
00007fb1689dded3  vmovaps xmm6, [rsp+0x60]
00007fb1689dded9  vmovaps xmm7, [rsp+0x70]
00007fb1689ddedf  vmovaps xmm8, [rsp+0x80]
00007fb1689ddee8  vmovaps xmm9, [rsp+0x90]
00007fb1689ddef1  vmovaps xmm10, [rsp+0xA0]
00007fb1689ddefa  vmovaps xmm11, [rsp+0xB0]
00007fb1689ddf03  vmovaps xmm13, [rsp+0xC0]
00007fb1689ddf0c  vmovaps xmm14, [rsp+0xD0]
00007fb1689ddf15  vmovaps xmm15, [rsp+0xE0]
00007fb1689ddf1e  add rsp, 0xF0
00007fb1689ddf25  pop r11
00007fb1689ddf27  pop r10
00007fb1689ddf29  pop r9
00007fb1689ddf2b  pop r8
00007fb1689ddf2d  pop rsi
00007fb1689ddf2e  pop rdi
00007fb1689ddf2f  pop rdx
00007fb1689ddf30  pop rcx
00007fb1689ddf31  pop rax
00007fb1689ddf32  add rsp, 0x08
00007fb1689ddf36  jmp 0x00007FB1689D9729
00007fb1689ddf3b  sub rsp, 0x08
00007fb1689ddf3f  push rax
00007fb1689ddf40  push rcx
00007fb1689ddf41  push rdx
00007fb1689ddf42  push rdi
00007fb1689ddf43  push rsi
00007fb1689ddf44  push r8
00007fb1689ddf46  push r9
00007fb1689ddf48  push r10
00007fb1689ddf4a  push r11
00007fb1689ddf4c  sub rsp, 0xF0
00007fb1689ddf53  vmovaps [rsp], xmm0
00007fb1689ddf58  vmovaps [rsp+0x10], xmm1
00007fb1689ddf5e  vmovaps [rsp+0x20], xmm2
00007fb1689ddf64  vmovaps [rsp+0x30], xmm3
00007fb1689ddf6a  vmovaps [rsp+0x40], xmm4
00007fb1689ddf70  vmovaps [rsp+0x50], xmm5
00007fb1689ddf76  vmovaps [rsp+0x60], xmm6
00007fb1689ddf7c  vmovaps [rsp+0x70], xmm7
00007fb1689ddf82  vmovaps [rsp+0x80], xmm8
00007fb1689ddf8b  vmovaps [rsp+0x90], xmm9
00007fb1689ddf94  vmovaps [rsp+0xA0], xmm10
00007fb1689ddf9d  vmovaps [rsp+0xB0], xmm11
00007fb1689ddfa6  vmovaps [rsp+0xC0], xmm12
00007fb1689ddfaf  vmovaps [rsp+0xD0], xmm13
00007fb1689ddfb8  vmovaps [rsp+0xE0], xmm15
00007fb1689ddfc1  sub rsp, 0x30
00007fb1689ddfc5  movaps [rsp], xmm14
00007fb1689ddfca  movaps [rsp+0x10], xmm9
00007fb1689ddfd0  movaps [rsp+0x20], xmm1
00007fb1689ddfd5  lea rdi, [rsp]
00007fb1689ddfd9  mov esi, 0x00
00007fb1689ddfde  mov rax, 0x57CCFD419530
00007fb1689ddfe8  call rax
00007fb1689ddfea  movaps xmm14, [rsp]
00007fb1689ddfef  add rsp, 0x30
00007fb1689ddff3  vmovaps xmm0, [rsp]
00007fb1689ddff8  vmovaps xmm1, [rsp+0x10]
00007fb1689ddffe  vmovaps xmm2, [rsp+0x20]
00007fb1689de004  vmovaps xmm3, [rsp+0x30]
00007fb1689de00a  vmovaps xmm4, [rsp+0x40]
00007fb1689de010  vmovaps xmm5, [rsp+0x50]
00007fb1689de016  vmovaps xmm6, [rsp+0x60]
00007fb1689de01c  vmovaps xmm7, [rsp+0x70]
00007fb1689de022  vmovaps xmm8, [rsp+0x80]
00007fb1689de02b  vmovaps xmm9, [rsp+0x90]
00007fb1689de034  vmovaps xmm10, [rsp+0xA0]
00007fb1689de03d  vmovaps xmm11, [rsp+0xB0]
00007fb1689de046  vmovaps xmm12, [rsp+0xC0]
00007fb1689de04f  vmovaps xmm13, [rsp+0xD0]
00007fb1689de058  vmovaps xmm15, [rsp+0xE0]
00007fb1689de061  add rsp, 0xF0
00007fb1689de068  pop r11
00007fb1689de06a  pop r10
00007fb1689de06c  pop r9
00007fb1689de06e  pop r8
00007fb1689de070  pop rsi
00007fb1689de071  pop rdi
00007fb1689de072  pop rdx
00007fb1689de073  pop rcx
00007fb1689de074  pop rax
00007fb1689de075  add rsp, 0x08
00007fb1689de079  jmp 0x00007FB1689D9758
00007fb1689de07e  sub rsp, 0x08
00007fb1689de082  push rax
00007fb1689de083  push rcx
00007fb1689de084  push rdx
00007fb1689de085  push rdi
00007fb1689de086  push rsi
00007fb1689de087  push r8
00007fb1689de089  push r9
00007fb1689de08b  push r10
00007fb1689de08d  push r11
00007fb1689de08f  sub rsp, 0xF0
00007fb1689de096  vmovaps [rsp], xmm0
00007fb1689de09b  vmovaps [rsp+0x10], xmm2
00007fb1689de0a1  vmovaps [rsp+0x20], xmm3
00007fb1689de0a7  vmovaps [rsp+0x30], xmm4
00007fb1689de0ad  vmovaps [rsp+0x40], xmm5
00007fb1689de0b3  vmovaps [rsp+0x50], xmm6
00007fb1689de0b9  vmovaps [rsp+0x60], xmm7
00007fb1689de0bf  vmovaps [rsp+0x70], xmm8
00007fb1689de0c5  vmovaps [rsp+0x80], xmm9
00007fb1689de0ce  vmovaps [rsp+0x90], xmm10
00007fb1689de0d7  vmovaps [rsp+0xA0], xmm11
00007fb1689de0e0  vmovaps [rsp+0xB0], xmm12
00007fb1689de0e9  vmovaps [rsp+0xC0], xmm13
00007fb1689de0f2  vmovaps [rsp+0xD0], xmm14
00007fb1689de0fb  vmovaps [rsp+0xE0], xmm15
00007fb1689de104  sub rsp, 0x30
00007fb1689de108  movaps [rsp], xmm1
00007fb1689de10c  movaps [rsp+0x10], xmm13
00007fb1689de112  movaps [rsp+0x20], xmm8
00007fb1689de118  lea rdi, [rsp]
00007fb1689de11c  mov esi, 0x00
00007fb1689de121  mov rax, 0x57CCFD419530
00007fb1689de12b  call rax
00007fb1689de12d  movaps xmm1, [rsp]
00007fb1689de131  add rsp, 0x30
00007fb1689de135  vmovaps xmm0, [rsp]
00007fb1689de13a  vmovaps xmm2, [rsp+0x10]
00007fb1689de140  vmovaps xmm3, [rsp+0x20]
00007fb1689de146  vmovaps xmm4, [rsp+0x30]
00007fb1689de14c  vmovaps xmm5, [rsp+0x40]
00007fb1689de152  vmovaps xmm6, [rsp+0x50]
00007fb1689de158  vmovaps xmm7, [rsp+0x60]
00007fb1689de15e  vmovaps xmm8, [rsp+0x70]
00007fb1689de164  vmovaps xmm9, [rsp+0x80]
00007fb1689de16d  vmovaps xmm10, [rsp+0x90]
00007fb1689de176  vmovaps xmm11, [rsp+0xA0]
00007fb1689de17f  vmovaps xmm12, [rsp+0xB0]
00007fb1689de188  vmovaps xmm13, [rsp+0xC0]
00007fb1689de191  vmovaps xmm14, [rsp+0xD0]
00007fb1689de19a  vmovaps xmm15, [rsp+0xE0]
00007fb1689de1a3  add rsp, 0xF0
00007fb1689de1aa  pop r11
00007fb1689de1ac  pop r10
00007fb1689de1ae  pop r9
00007fb1689de1b0  pop r8
00007fb1689de1b2  pop rsi
00007fb1689de1b3  pop rdi
00007fb1689de1b4  pop rdx
00007fb1689de1b5  pop rcx
00007fb1689de1b6  pop rax
00007fb1689de1b7  add rsp, 0x08
00007fb1689de1bb  jmp 0x00007FB1689D977A
00007fb1689de1c0  call 0x00007FB16880C260
00007fb1689de1c5  jmp 0x00007FB1689D9788
00007fb1689de1ca  call 0x00007FB1688DE950
00007fb1689de1cf  jmp 0x00007FB1689D9792
00007fb1689de1d4  sub rsp, 0x08
00007fb1689de1d8  push rax
00007fb1689de1d9  push rcx
00007fb1689de1da  push rdx
00007fb1689de1db  push rdi
00007fb1689de1dc  push rsi
00007fb1689de1dd  push r8
00007fb1689de1df  push r9
00007fb1689de1e1  push r10
00007fb1689de1e3  push r11
00007fb1689de1e5  sub rsp, 0xF0
00007fb1689de1ec  vmovaps [rsp], xmm0
00007fb1689de1f1  vmovaps [rsp+0x10], xmm1
00007fb1689de1f7  vmovaps [rsp+0x20], xmm2
00007fb1689de1fd  vmovaps [rsp+0x30], xmm3
00007fb1689de203  vmovaps [rsp+0x40], xmm4
00007fb1689de209  vmovaps [rsp+0x50], xmm5
00007fb1689de20f  vmovaps [rsp+0x60], xmm6
00007fb1689de215  vmovaps [rsp+0x70], xmm7
00007fb1689de21b  vmovaps [rsp+0x80], xmm9
00007fb1689de224  vmovaps [rsp+0x90], xmm10
00007fb1689de22d  vmovaps [rsp+0xA0], xmm11
00007fb1689de236  vmovaps [rsp+0xB0], xmm12
00007fb1689de23f  vmovaps [rsp+0xC0], xmm13
00007fb1689de248  vmovaps [rsp+0xD0], xmm14
00007fb1689de251  vmovaps [rsp+0xE0], xmm15
00007fb1689de25a  sub rsp, 0x30
00007fb1689de25e  movaps [rsp], xmm8
00007fb1689de263  movaps [rsp+0x10], xmm15
00007fb1689de269  movaps [rsp+0x20], xmm7
00007fb1689de26e  lea rdi, [rsp]
00007fb1689de272  mov esi, 0x00
00007fb1689de277  mov rax, 0x57CCFD419530
00007fb1689de281  call rax
00007fb1689de283  movaps xmm8, [rsp]
00007fb1689de288  add rsp, 0x30
00007fb1689de28c  vmovaps xmm0, [rsp]
00007fb1689de291  vmovaps xmm1, [rsp+0x10]
00007fb1689de297  vmovaps xmm2, [rsp+0x20]
00007fb1689de29d  vmovaps xmm3, [rsp+0x30]
00007fb1689de2a3  vmovaps xmm4, [rsp+0x40]
00007fb1689de2a9  vmovaps xmm5, [rsp+0x50]
00007fb1689de2af  vmovaps xmm6, [rsp+0x60]
00007fb1689de2b5  vmovaps xmm7, [rsp+0x70]
00007fb1689de2bb  vmovaps xmm9, [rsp+0x80]
00007fb1689de2c4  vmovaps xmm10, [rsp+0x90]
00007fb1689de2cd  vmovaps xmm11, [rsp+0xA0]
00007fb1689de2d6  vmovaps xmm12, [rsp+0xB0]
00007fb1689de2df  vmovaps xmm13, [rsp+0xC0]
00007fb1689de2e8  vmovaps xmm14, [rsp+0xD0]
00007fb1689de2f1  vmovaps xmm15, [rsp+0xE0]
00007fb1689de2fa  add rsp, 0xF0
00007fb1689de301  pop r11
00007fb1689de303  pop r10
00007fb1689de305  pop r9
00007fb1689de307  pop r8
00007fb1689de309  pop rsi
00007fb1689de30a  pop rdi
00007fb1689de30b  pop rdx
00007fb1689de30c  pop rcx
00007fb1689de30d  pop rax
00007fb1689de30e  add rsp, 0x08
00007fb1689de312  jmp 0x00007FB1689D97B4
00007fb1689de317  sub rsp, 0x08
00007fb1689de31b  push rax
00007fb1689de31c  push rcx
00007fb1689de31d  push rdx
00007fb1689de31e  push rdi
00007fb1689de31f  push rsi
00007fb1689de320  push r8
00007fb1689de322  push r9
00007fb1689de324  push r10
00007fb1689de326  push r11
00007fb1689de328  sub rsp, 0xF0
00007fb1689de32f  vmovaps [rsp], xmm0
00007fb1689de334  vmovaps [rsp+0x10], xmm1
00007fb1689de33a  vmovaps [rsp+0x20], xmm2
00007fb1689de340  vmovaps [rsp+0x30], xmm3
00007fb1689de346  vmovaps [rsp+0x40], xmm4
00007fb1689de34c  vmovaps [rsp+0x50], xmm5
00007fb1689de352  vmovaps [rsp+0x60], xmm6
00007fb1689de358  vmovaps [rsp+0x70], xmm8
00007fb1689de35e  vmovaps [rsp+0x80], xmm9
00007fb1689de367  vmovaps [rsp+0x90], xmm10
00007fb1689de370  vmovaps [rsp+0xA0], xmm11
00007fb1689de379  vmovaps [rsp+0xB0], xmm12
00007fb1689de382  vmovaps [rsp+0xC0], xmm13
00007fb1689de38b  vmovaps [rsp+0xD0], xmm14
00007fb1689de394  vmovaps [rsp+0xE0], xmm15
00007fb1689de39d  sub rsp, 0x30
00007fb1689de3a1  movaps [rsp], xmm7
00007fb1689de3a5  movaps [rsp+0x10], xmm9
00007fb1689de3ab  movaps [rsp+0x20], xmm15
00007fb1689de3b1  lea rdi, [rsp]
00007fb1689de3b5  mov esi, 0x00
00007fb1689de3ba  mov rax, 0x57CCFD419530
00007fb1689de3c4  call rax
00007fb1689de3c6  movaps xmm7, [rsp]
00007fb1689de3ca  add rsp, 0x30
00007fb1689de3ce  vmovaps xmm0, [rsp]
00007fb1689de3d3  vmovaps xmm1, [rsp+0x10]
00007fb1689de3d9  vmovaps xmm2, [rsp+0x20]
00007fb1689de3df  vmovaps xmm3, [rsp+0x30]
00007fb1689de3e5  vmovaps xmm4, [rsp+0x40]
00007fb1689de3eb  vmovaps xmm5, [rsp+0x50]
00007fb1689de3f1  vmovaps xmm6, [rsp+0x60]
00007fb1689de3f7  vmovaps xmm8, [rsp+0x70]
00007fb1689de3fd  vmovaps xmm9, [rsp+0x80]
00007fb1689de406  vmovaps xmm10, [rsp+0x90]
00007fb1689de40f  vmovaps xmm11, [rsp+0xA0]
00007fb1689de418  vmovaps xmm12, [rsp+0xB0]
00007fb1689de421  vmovaps xmm13, [rsp+0xC0]
00007fb1689de42a  vmovaps xmm14, [rsp+0xD0]
00007fb1689de433  vmovaps xmm15, [rsp+0xE0]
00007fb1689de43c  add rsp, 0xF0
00007fb1689de443  pop r11
00007fb1689de445  pop r10
00007fb1689de447  pop r9
00007fb1689de449  pop r8
00007fb1689de44b  pop rsi
00007fb1689de44c  pop rdi
00007fb1689de44d  pop rdx
00007fb1689de44e  pop rcx
00007fb1689de44f  pop rax
00007fb1689de450  add rsp, 0x08
00007fb1689de454  jmp 0x00007FB1689D97E1
00007fb1689de459  sub rsp, 0x08
00007fb1689de45d  push rax
00007fb1689de45e  push rcx
00007fb1689de45f  push rdx
00007fb1689de460  push rdi
00007fb1689de461  push rsi
00007fb1689de462  push r8
00007fb1689de464  push r9
00007fb1689de466  push r10
00007fb1689de468  push r11
00007fb1689de46a  sub rsp, 0xF0
00007fb1689de471  vmovaps [rsp], xmm0
00007fb1689de476  vmovaps [rsp+0x10], xmm1
00007fb1689de47c  vmovaps [rsp+0x20], xmm2
00007fb1689de482  vmovaps [rsp+0x30], xmm3
00007fb1689de488  vmovaps [rsp+0x40], xmm4
00007fb1689de48e  vmovaps [rsp+0x50], xmm5
00007fb1689de494  vmovaps [rsp+0x60], xmm6
00007fb1689de49a  vmovaps [rsp+0x70], xmm7
00007fb1689de4a0  vmovaps [rsp+0x80], xmm8
00007fb1689de4a9  vmovaps [rsp+0x90], xmm10
00007fb1689de4b2  vmovaps [rsp+0xA0], xmm11
00007fb1689de4bb  vmovaps [rsp+0xB0], xmm12
00007fb1689de4c4  vmovaps [rsp+0xC0], xmm13
00007fb1689de4cd  vmovaps [rsp+0xD0], xmm14
00007fb1689de4d6  vmovaps [rsp+0xE0], xmm15
00007fb1689de4df  sub rsp, 0x30
00007fb1689de4e3  movaps [rsp], xmm9
00007fb1689de4e8  movaps [rsp+0x10], xmm13
00007fb1689de4ee  movaps [rsp+0x20], xmm15
00007fb1689de4f4  lea rdi, [rsp]
00007fb1689de4f8  mov esi, 0x00
00007fb1689de4fd  mov rax, 0x57CCFD419530
00007fb1689de507  call rax
00007fb1689de509  movaps xmm9, [rsp]
00007fb1689de50e  add rsp, 0x30
00007fb1689de512  vmovaps xmm0, [rsp]
00007fb1689de517  vmovaps xmm1, [rsp+0x10]
00007fb1689de51d  vmovaps xmm2, [rsp+0x20]
00007fb1689de523  vmovaps xmm3, [rsp+0x30]
00007fb1689de529  vmovaps xmm4, [rsp+0x40]
00007fb1689de52f  vmovaps xmm5, [rsp+0x50]
00007fb1689de535  vmovaps xmm6, [rsp+0x60]
00007fb1689de53b  vmovaps xmm7, [rsp+0x70]
00007fb1689de541  vmovaps xmm8, [rsp+0x80]
00007fb1689de54a  vmovaps xmm10, [rsp+0x90]
00007fb1689de553  vmovaps xmm11, [rsp+0xA0]
00007fb1689de55c  vmovaps xmm12, [rsp+0xB0]
00007fb1689de565  vmovaps xmm13, [rsp+0xC0]
00007fb1689de56e  vmovaps xmm14, [rsp+0xD0]
00007fb1689de577  vmovaps xmm15, [rsp+0xE0]
00007fb1689de580  add rsp, 0xF0
00007fb1689de587  pop r11
00007fb1689de589  pop r10
00007fb1689de58b  pop r9
00007fb1689de58d  pop r8
00007fb1689de58f  pop rsi
00007fb1689de590  pop rdi
00007fb1689de591  pop rdx
00007fb1689de592  pop rcx
00007fb1689de593  pop rax
00007fb1689de594  add rsp, 0x08
00007fb1689de598  jmp 0x00007FB1689D980F
00007fb1689de59d  sub rsp, 0x08
00007fb1689de5a1  push rax
00007fb1689de5a2  push rcx
00007fb1689de5a3  push rdx
00007fb1689de5a4  push rdi
00007fb1689de5a5  push rsi
00007fb1689de5a6  push r8
00007fb1689de5a8  push r9
00007fb1689de5aa  push r10
00007fb1689de5ac  push r11
00007fb1689de5ae  sub rsp, 0xF0
00007fb1689de5b5  vmovaps [rsp], xmm0
00007fb1689de5ba  vmovaps [rsp+0x10], xmm1
00007fb1689de5c0  vmovaps [rsp+0x20], xmm2
00007fb1689de5c6  vmovaps [rsp+0x30], xmm3
00007fb1689de5cc  vmovaps [rsp+0x40], xmm4
00007fb1689de5d2  vmovaps [rsp+0x50], xmm5
00007fb1689de5d8  vmovaps [rsp+0x60], xmm6
00007fb1689de5de  vmovaps [rsp+0x70], xmm7
00007fb1689de5e4  vmovaps [rsp+0x80], xmm8
00007fb1689de5ed  vmovaps [rsp+0x90], xmm9
00007fb1689de5f6  vmovaps [rsp+0xA0], xmm10
00007fb1689de5ff  vmovaps [rsp+0xB0], xmm11
00007fb1689de608  vmovaps [rsp+0xC0], xmm12
00007fb1689de611  vmovaps [rsp+0xD0], xmm13
00007fb1689de61a  vmovaps [rsp+0xE0], xmm14
00007fb1689de623  sub rsp, 0x30
00007fb1689de627  movaps [rsp], xmm15
00007fb1689de62c  movaps [rsp+0x10], xmm11
00007fb1689de632  movaps [rsp+0x20], xmm12
00007fb1689de638  lea rdi, [rsp]
00007fb1689de63c  mov esi, 0x00
00007fb1689de641  mov rax, 0x57CCFD419530
00007fb1689de64b  call rax
00007fb1689de64d  movaps xmm15, [rsp]
00007fb1689de652  add rsp, 0x30
00007fb1689de656  vmovaps xmm0, [rsp]
00007fb1689de65b  vmovaps xmm1, [rsp+0x10]
00007fb1689de661  vmovaps xmm2, [rsp+0x20]
00007fb1689de667  vmovaps xmm3, [rsp+0x30]
00007fb1689de66d  vmovaps xmm4, [rsp+0x40]
00007fb1689de673  vmovaps xmm5, [rsp+0x50]
00007fb1689de679  vmovaps xmm6, [rsp+0x60]
00007fb1689de67f  vmovaps xmm7, [rsp+0x70]
00007fb1689de685  vmovaps xmm8, [rsp+0x80]
00007fb1689de68e  vmovaps xmm9, [rsp+0x90]
00007fb1689de697  vmovaps xmm10, [rsp+0xA0]
00007fb1689de6a0  vmovaps xmm11, [rsp+0xB0]
00007fb1689de6a9  vmovaps xmm12, [rsp+0xC0]
00007fb1689de6b2  vmovaps xmm13, [rsp+0xD0]
00007fb1689de6bb  vmovaps xmm14, [rsp+0xE0]
00007fb1689de6c4  add rsp, 0xF0
00007fb1689de6cb  pop r11
00007fb1689de6cd  pop r10
00007fb1689de6cf  pop r9
00007fb1689de6d1  pop r8
00007fb1689de6d3  pop rsi
00007fb1689de6d4  pop rdi
00007fb1689de6d5  pop rdx
00007fb1689de6d6  pop rcx
00007fb1689de6d7  pop rax
00007fb1689de6d8  add rsp, 0x08
00007fb1689de6dc  jmp 0x00007FB1689D982A
00007fb1689de6e1  sub rsp, 0x08
00007fb1689de6e5  push rax
00007fb1689de6e6  push rcx
00007fb1689de6e7  push rdx
00007fb1689de6e8  push rdi
00007fb1689de6e9  push rsi
00007fb1689de6ea  push r8
00007fb1689de6ec  push r9
00007fb1689de6ee  push r10
00007fb1689de6f0  push r11
00007fb1689de6f2  sub rsp, 0xF0
00007fb1689de6f9  vmovaps [rsp], xmm0
00007fb1689de6fe  vmovaps [rsp+0x10], xmm1
00007fb1689de704  vmovaps [rsp+0x20], xmm2
00007fb1689de70a  vmovaps [rsp+0x30], xmm3
00007fb1689de710  vmovaps [rsp+0x40], xmm4
00007fb1689de716  vmovaps [rsp+0x50], xmm5
00007fb1689de71c  vmovaps [rsp+0x60], xmm6
00007fb1689de722  vmovaps [rsp+0x70], xmm7
00007fb1689de728  vmovaps [rsp+0x80], xmm8
00007fb1689de731  vmovaps [rsp+0x90], xmm9
00007fb1689de73a  vmovaps [rsp+0xA0], xmm10
00007fb1689de743  vmovaps [rsp+0xB0], xmm11
00007fb1689de74c  vmovaps [rsp+0xC0], xmm12
00007fb1689de755  vmovaps [rsp+0xD0], xmm14
00007fb1689de75e  vmovaps [rsp+0xE0], xmm15
00007fb1689de767  sub rsp, 0x30
00007fb1689de76b  movaps [rsp], xmm13
00007fb1689de770  movaps [rsp+0x10], xmm10
00007fb1689de776  movaps [rsp+0x20], xmm14
00007fb1689de77c  lea rdi, [rsp]
00007fb1689de780  mov esi, 0x00
00007fb1689de785  mov rax, 0x57CCFD419530
00007fb1689de78f  call rax
00007fb1689de791  movaps xmm13, [rsp]
00007fb1689de796  add rsp, 0x30
00007fb1689de79a  vmovaps xmm0, [rsp]
00007fb1689de79f  vmovaps xmm1, [rsp+0x10]
00007fb1689de7a5  vmovaps xmm2, [rsp+0x20]
00007fb1689de7ab  vmovaps xmm3, [rsp+0x30]
00007fb1689de7b1  vmovaps xmm4, [rsp+0x40]
00007fb1689de7b7  vmovaps xmm5, [rsp+0x50]
00007fb1689de7bd  vmovaps xmm6, [rsp+0x60]
00007fb1689de7c3  vmovaps xmm7, [rsp+0x70]
00007fb1689de7c9  vmovaps xmm8, [rsp+0x80]
00007fb1689de7d2  vmovaps xmm9, [rsp+0x90]
00007fb1689de7db  vmovaps xmm10, [rsp+0xA0]
00007fb1689de7e4  vmovaps xmm11, [rsp+0xB0]
00007fb1689de7ed  vmovaps xmm12, [rsp+0xC0]
00007fb1689de7f6  vmovaps xmm14, [rsp+0xD0]
00007fb1689de7ff  vmovaps xmm15, [rsp+0xE0]
00007fb1689de808  add rsp, 0xF0
00007fb1689de80f  pop r11
00007fb1689de811  pop r10
00007fb1689de813  pop r9
00007fb1689de815  pop r8
00007fb1689de817  pop rsi
00007fb1689de818  pop rdi
00007fb1689de819  pop rdx
00007fb1689de81a  pop rcx
00007fb1689de81b  pop rax
00007fb1689de81c  add rsp, 0x08
00007fb1689de820  jmp 0x00007FB1689D984D
00007fb1689de825  sub rsp, 0x08
00007fb1689de829  push rax
00007fb1689de82a  push rcx
00007fb1689de82b  push rdx
00007fb1689de82c  push rdi
00007fb1689de82d  push rsi
00007fb1689de82e  push r8
00007fb1689de830  push r9
00007fb1689de832  push r10
00007fb1689de834  push r11
00007fb1689de836  sub rsp, 0xF0
00007fb1689de83d  vmovaps [rsp], xmm0
00007fb1689de842  vmovaps [rsp+0x10], xmm1
00007fb1689de848  vmovaps [rsp+0x20], xmm2
00007fb1689de84e  vmovaps [rsp+0x30], xmm3
00007fb1689de854  vmovaps [rsp+0x40], xmm4
00007fb1689de85a  vmovaps [rsp+0x50], xmm5
00007fb1689de860  vmovaps [rsp+0x60], xmm6
00007fb1689de866  vmovaps [rsp+0x70], xmm7
00007fb1689de86c  vmovaps [rsp+0x80], xmm8
00007fb1689de875  vmovaps [rsp+0x90], xmm9
00007fb1689de87e  vmovaps [rsp+0xA0], xmm10
00007fb1689de887  vmovaps [rsp+0xB0], xmm11
00007fb1689de890  vmovaps [rsp+0xC0], xmm12
00007fb1689de899  vmovaps [rsp+0xD0], xmm13
00007fb1689de8a2  vmovaps [rsp+0xE0], xmm15
00007fb1689de8ab  sub rsp, 0x30
00007fb1689de8af  movaps [rsp], xmm14
00007fb1689de8b4  movaps [rsp+0x10], xmm1
00007fb1689de8b9  movaps [rsp+0x20], xmm7
00007fb1689de8be  lea rdi, [rsp]
00007fb1689de8c2  mov esi, 0x00
00007fb1689de8c7  mov rax, 0x57CCFD419530
00007fb1689de8d1  call rax
00007fb1689de8d3  movaps xmm14, [rsp]
00007fb1689de8d8  add rsp, 0x30
00007fb1689de8dc  vmovaps xmm0, [rsp]
00007fb1689de8e1  vmovaps xmm1, [rsp+0x10]
00007fb1689de8e7  vmovaps xmm2, [rsp+0x20]
00007fb1689de8ed  vmovaps xmm3, [rsp+0x30]
00007fb1689de8f3  vmovaps xmm4, [rsp+0x40]
00007fb1689de8f9  vmovaps xmm5, [rsp+0x50]
00007fb1689de8ff  vmovaps xmm6, [rsp+0x60]
00007fb1689de905  vmovaps xmm7, [rsp+0x70]
00007fb1689de90b  vmovaps xmm8, [rsp+0x80]
00007fb1689de914  vmovaps xmm9, [rsp+0x90]
00007fb1689de91d  vmovaps xmm10, [rsp+0xA0]
00007fb1689de926  vmovaps xmm11, [rsp+0xB0]
00007fb1689de92f  vmovaps xmm12, [rsp+0xC0]
00007fb1689de938  vmovaps xmm13, [rsp+0xD0]
00007fb1689de941  vmovaps xmm15, [rsp+0xE0]
00007fb1689de94a  add rsp, 0xF0
00007fb1689de951  pop r11
00007fb1689de953  pop r10
00007fb1689de955  pop r9
00007fb1689de957  pop r8
00007fb1689de959  pop rsi
00007fb1689de95a  pop rdi
00007fb1689de95b  pop rdx
00007fb1689de95c  pop rcx
00007fb1689de95d  pop rax
00007fb1689de95e  add rsp, 0x08
00007fb1689de962  jmp 0x00007FB1689D9870
00007fb1689de967  sub rsp, 0x08
00007fb1689de96b  push rax
00007fb1689de96c  push rcx
00007fb1689de96d  push rdx
00007fb1689de96e  push rdi
00007fb1689de96f  push rsi
00007fb1689de970  push r8
00007fb1689de972  push r9
00007fb1689de974  push r10
00007fb1689de976  push r11
00007fb1689de978  sub rsp, 0xF0
00007fb1689de97f  vmovaps [rsp], xmm0
00007fb1689de984  vmovaps [rsp+0x10], xmm2
00007fb1689de98a  vmovaps [rsp+0x20], xmm3
00007fb1689de990  vmovaps [rsp+0x30], xmm4
00007fb1689de996  vmovaps [rsp+0x40], xmm5
00007fb1689de99c  vmovaps [rsp+0x50], xmm6
00007fb1689de9a2  vmovaps [rsp+0x60], xmm7
00007fb1689de9a8  vmovaps [rsp+0x70], xmm8
00007fb1689de9ae  vmovaps [rsp+0x80], xmm9
00007fb1689de9b7  vmovaps [rsp+0x90], xmm10
00007fb1689de9c0  vmovaps [rsp+0xA0], xmm11
00007fb1689de9c9  vmovaps [rsp+0xB0], xmm12
00007fb1689de9d2  vmovaps [rsp+0xC0], xmm13
00007fb1689de9db  vmovaps [rsp+0xD0], xmm14
00007fb1689de9e4  vmovaps [rsp+0xE0], xmm15
00007fb1689de9ed  sub rsp, 0x30
00007fb1689de9f1  movaps [rsp], xmm1
00007fb1689de9f5  movaps [rsp+0x10], xmm8
00007fb1689de9fb  movaps [rsp+0x20], xmm9
00007fb1689dea01  lea rdi, [rsp]
00007fb1689dea05  mov esi, 0x00
00007fb1689dea0a  mov rax, 0x57CCFD419530
00007fb1689dea14  call rax
00007fb1689dea16  movaps xmm1, [rsp]
00007fb1689dea1a  add rsp, 0x30
00007fb1689dea1e  vmovaps xmm0, [rsp]
00007fb1689dea23  vmovaps xmm2, [rsp+0x10]
00007fb1689dea29  vmovaps xmm3, [rsp+0x20]
00007fb1689dea2f  vmovaps xmm4, [rsp+0x30]
00007fb1689dea35  vmovaps xmm5, [rsp+0x40]
00007fb1689dea3b  vmovaps xmm6, [rsp+0x50]
00007fb1689dea41  vmovaps xmm7, [rsp+0x60]
00007fb1689dea47  vmovaps xmm8, [rsp+0x70]
00007fb1689dea4d  vmovaps xmm9, [rsp+0x80]
00007fb1689dea56  vmovaps xmm10, [rsp+0x90]
00007fb1689dea5f  vmovaps xmm11, [rsp+0xA0]
00007fb1689dea68  vmovaps xmm12, [rsp+0xB0]
00007fb1689dea71  vmovaps xmm13, [rsp+0xC0]
00007fb1689dea7a  vmovaps xmm14, [rsp+0xD0]
00007fb1689dea83  vmovaps xmm15, [rsp+0xE0]
00007fb1689dea8c  add rsp, 0xF0
00007fb1689dea93  pop r11
00007fb1689dea95  pop r10
00007fb1689dea97  pop r9
00007fb1689dea99  pop r8
00007fb1689dea9b  pop rsi
00007fb1689dea9c  pop rdi
00007fb1689dea9d  pop rdx
00007fb1689dea9e  pop rcx
00007fb1689dea9f  pop rax
00007fb1689deaa0  add rsp, 0x08
00007fb1689deaa4  jmp 0x00007FB1689D9892
00007fb1689deaa9  call 0x00007FB1688B3E40
00007fb1689deaae  jmp 0x00007FB1689D98A0
00007fb1689deab3  call 0x00007FB16880C380
00007fb1689deab8  jmp 0x00007FB1689D98AA
00007fb1689deabd  call 0x00007FB16880D600
00007fb1689deac2  jmp 0x00007FB1689D98B4
00007fb1689deac7  call 0x00007FB1687FF540
00007fb1689deacc  jmp 0x00007FB1689D98BE
00007fb1689dead1  int3
00007fb1689dead2  nop [rax+rax*1], ax
00007fb1689deadb  nop [rax+rax*1], eax
00007fb1689deae0  mov eax, [r15+0x48]
00007fb1689deae4  lea r14d, [eax+0x01]
00007fb1689deae9  mov [rsp+0x10], r14d
00007fb1689deaee  mov r14d, r14d
00007fb1689deaf1  mov [r15+0x48], r14
00007fb1689deaf5  xor eax, eax
00007fb1689deaf7  mov r14d, [rsp+0x10]
00007fb1689deafc  cmp r14d, 0x1F4
00007fb1689deb03  cmc
00007fb1689deb04  lahf
00007fb1689deb05  seto al
00007fb1689deb08  mov [r15+0x108], eax
00007fb1689deb0f  mov eax, [r15+0x108]
00007fb1689deb16  sahf
00007fb1689deb17  jnz 0x00007FB1689DEB49
00007fb1689deb19  cmp dword ptr [r15+0x318], 0x00
00007fb1689deb21  jz 0x00007FB1689E4C90
00007fb1689deb27  nop [rax+rax*1], ax
00007fb1689deb30  nop [rax+rax*1], eax
00007fb1689deb38  mov eax, 0x4106DC
00007fb1689deb3d  mov [r15+0x100], rax
00007fb1689deb44  jmp 0x00007FB1687FE110
00007fb1689deb49  cmp dword ptr [r15+0x318], 0x00
00007fb1689deb51  jz 0x00007FB1689DEB80
00007fb1689deb57  nop [rax+rax*1], ax
00007fb1689deb60  nop [rax+rax*1], eax
00007fb1689deb68  mov eax, 0x410500
00007fb1689deb6d  mov [r15+0x100], rax
00007fb1689deb74  jmp 0x00007FB1687FE110
00007fb1689deb79  int3
00007fb1689deb7a  int3
00007fb1689deb7b  nop [rax+rax*1], eax
00007fb1689deb80  mov rax, [r15+0x40]
00007fb1689deb84  movaps xmm1, [r15+0x1D0]
00007fb1689deb8c  vmovaps [rsp+0x10], xmm1
00007fb1689deb92  vmovaps xmm15, [rsp+0x10]
00007fb1689deb98  por xmm1, xmm15
00007fb1689deb9d  movaps xmm14, [r15+0x1A0]
00007fb1689deba5  vmovaps [rsp+0x10], xmm14
00007fb1689debab  vmovaps xmm13, [rsp+0x10]
00007fb1689debb1  por xmm14, xmm13
00007fb1689debb6  lea r14, [rax+0x30]
00007fb1689debba  mov r12, [r13+r14*1]
00007fb1689debbf  lea r14, [rax+0x38]
00007fb1689debc3  mov r11, [r13+r14*1]
00007fb1689debc8  movq xmm13, r12
00007fb1689debcd  movq xmm12, r11
00007fb1689debd2  movq xmm13, xmm13
00007fb1689debd7  vmovaps [rsp+0x10], xmm13
00007fb1689debdd  movq xmm13, xmm13
00007fb1689debe2  movaps [r15+0x130], xmm13
00007fb1689debea  movq xmm12, xmm12
00007fb1689debef  vmovaps [rsp+0x20], xmm12
00007fb1689debf5  movq xmm12, xmm12
00007fb1689debfa  movaps [r15+0x280], xmm12
00007fb1689dec02  movaps xmm13, [r15+0x270]
00007fb1689dec0a  vmovaps [rsp+0x30], xmm13
00007fb1689dec10  vmovaps xmm12, [rsp+0x30]
00007fb1689dec16  por xmm13, xmm12
00007fb1689dec1b  lea r14, [rax+0x20]
00007fb1689dec1f  mov r12, [r13+r14*1]
00007fb1689dec24  lea r14, [rax+0x28]
00007fb1689dec28  mov r11, [r13+r14*1]
00007fb1689dec2d  movq xmm12, r12
00007fb1689dec32  movq xmm11, r11
00007fb1689dec37  movq xmm12, xmm12
00007fb1689dec3c  vmovaps [rsp+0x30], xmm12
00007fb1689dec42  movq xmm12, xmm12
00007fb1689dec47  movaps [r15+0x150], xmm12
00007fb1689dec4f  movq xmm11, xmm11
00007fb1689dec54  vmovaps [rsp+0x40], xmm11
00007fb1689dec5a  movq xmm11, xmm11
00007fb1689dec5f  movaps [r15+0x140], xmm11
00007fb1689dec67  lea r14, [rax+0x10]
00007fb1689dec6b  mov r12, [r13+r14*1]
00007fb1689dec70  lea r14, [rax+0x18]
00007fb1689dec74  mov r11, [r13+r14*1]
00007fb1689dec79  movq xmm12, r12
00007fb1689dec7e  movq xmm11, r11
00007fb1689dec83  movq xmm12, xmm12
00007fb1689dec88  vmovaps [rsp+0x50], xmm12
00007fb1689dec8e  movq xmm12, xmm12
00007fb1689dec93  movaps [r15+0x170], xmm12
00007fb1689dec9b  movq xmm11, xmm11
00007fb1689deca0  vmovaps [rsp+0x60], xmm11
00007fb1689deca6  movq xmm11, xmm11
00007fb1689decab  movaps [r15+0x160], xmm11
00007fb1689decb3  mov r14, [r13+rax*1]
00007fb1689decb8  vmovq xmm12, r14
00007fb1689decbd  vpbroadcastq xmm12, xmm12
00007fb1689decc2  lea r14, [rax+0x08]
00007fb1689decc6  mov rax, [r13+r14*1]
00007fb1689deccb  movq xmm11, rax
00007fb1689decd0  movaps [r15+0x230], xmm11
00007fb1689decd8  mov rax, [r15+0xF8]
00007fb1689decdf  lea r14, [rax+0x50]
00007fb1689dece3  movups xmm11, [r13+r14*1]
00007fb1689dece9  lea r14, [rax+0x60]
00007fb1689deced  movups xmm10, [r13+r14*1]
00007fb1689decf3  lea r14, [rax+0x30]
00007fb1689decf7  movups xmm9, [r13+r14*1]
00007fb1689decfd  mov r14, [r15+0x50]
00007fb1689ded01  mov [r15+0x60], r14
00007fb1689ded05  mov qword ptr [r15+0x58], 0x40
00007fb1689ded0d  movaps xmm8, xmm12
00007fb1689ded11  mulpd xmm8, xmm15
00007fb1689ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007fb1689ded1c  ptest xmm7, xmm7
00007fb1689ded21  jnz 0x00007FB1689DFB4A
00007fb1689ded27  movq xmm15, qword ptr [r15+0x230]
00007fb1689ded30  vmovaps [rsp+0x70], xmm15
00007fb1689ded36  vpermilpd xmm15, xmm15, 0x00
00007fb1689ded3c  movaps xmm7, xmm9
00007fb1689ded40  mulpd xmm7, xmm15
00007fb1689ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007fb1689ded4a  ptest xmm6, xmm6
00007fb1689ded4f  jnz 0x00007FB1689DFC8E
00007fb1689ded55  vxorps xmm15, xmm15, xmm15
00007fb1689ded5a  vpbroadcastq xmm15, xmm15
00007fb1689ded5f  movaps xmm9, xmm12
00007fb1689ded63  mulpd xmm9, xmm10
00007fb1689ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007fb1689ded6e  ptest xmm6, xmm6
00007fb1689ded73  jnz 0x00007FB1689DFDD0
00007fb1689ded79  movaps xmm10, xmm12
00007fb1689ded7d  mulpd xmm10, xmm11
00007fb1689ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007fb1689ded88  ptest xmm6, xmm6
00007fb1689ded8d  jnz 0x00007FB1689DFF14
00007fb1689ded93  movaps xmm11, [r15+0x1F0]
00007fb1689ded9b  movaps xmm6, xmm12
00007fb1689ded9f  mulpd xmm6, xmm11
00007fb1689deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007fb1689deda9  ptest xmm5, xmm5
00007fb1689dedae  jnz 0x00007FB1689E0058
00007fb1689dedb4  movaps xmm12, [r15+0x2A0]
00007fb1689dedbc  vmovaps [rsp+0x80], xmm12
00007fb1689dedc5  vmovaps xmm11, [rsp+0x80]
00007fb1689dedce  por xmm12, xmm11
00007fb1689dedd3  movaps xmm11, [r15+0x250]
00007fb1689deddb  vmovaps [rsp+0x80], xmm11
00007fb1689dede4  vmovaps xmm5, [rsp+0x80]
00007fb1689deded  por xmm11, xmm5
00007fb1689dedf2  vmovaps xmm4, [rsp+0x70]
00007fb1689dedf8  vpermilpd xmm4, xmm4, 0x00
00007fb1689dedfe  movaps xmm3, xmm5
00007fb1689dee01  mulpd xmm3, xmm4
00007fb1689dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007fb1689dee0a  ptest xmm2, xmm2
00007fb1689dee0f  jnz 0x00007FB1689E019A
00007fb1689dee15  mov [rsp+0x80], rax
00007fb1689dee1d  xor eax, eax
00007fb1689dee1f  mov r12d, 0x40
00007fb1689dee25  mov r11d, 0x200
00007fb1689dee2b  cmp r12, r11
00007fb1689dee2e  cmc
00007fb1689dee2f  lahf
00007fb1689dee30  seto al
00007fb1689dee33  mov [r15+0x108], eax
00007fb1689dee3a  movaps xmm5, xmm8
00007fb1689dee3e  addpd xmm5, xmm15
00007fb1689dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007fb1689dee48  ptest xmm4, xmm4
00007fb1689dee4d  jnz 0x00007FB1689E02DA
00007fb1689dee53  movaps xmm8, [r15+0x1B0]
00007fb1689dee5b  movaps xmm4, xmm9
00007fb1689dee5f  addpd xmm4, xmm8
00007fb1689dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007fb1689dee69  ptest xmm2, xmm2
00007fb1689dee6e  jnz 0x00007FB1689E041C
00007fb1689dee74  movaps xmm9, xmm10
00007fb1689dee78  addpd xmm9, xmm8
00007fb1689dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007fb1689dee83  ptest xmm2, xmm2
00007fb1689dee88  jnz 0x00007FB1689E055E
00007fb1689dee8e  movaps xmm10, [r15+0x2F0]
00007fb1689dee96  vmovaps [rsp+0x90], xmm10
00007fb1689dee9f  vmovaps xmm8, [rsp+0x90]
00007fb1689deea8  por xmm10, xmm8
00007fb1689deead  movaps xmm8, [r15+0x2E0]
00007fb1689deeb5  vmovaps [rsp+0x90], xmm8
00007fb1689deebe  vmovaps xmm2, [rsp+0x90]
00007fb1689deec7  por xmm8, xmm2
00007fb1689deecc  movaps xmm2, [r15+0x2D0]
00007fb1689deed4  vmovaps [rsp+0x90], xmm2
00007fb1689deedd  vmovaps [rsp+0xA0], xmm1
00007fb1689deee6  vmovaps xmm1, [rsp+0x90]
00007fb1689deeef  por xmm2, xmm1
00007fb1689deef3  movaps xmm1, [r15+0x200]
00007fb1689deefb  vmovaps [rsp+0x90], xmm1
00007fb1689def04  vmovaps [rsp+0xB0], xmm15
00007fb1689def0d  vmovaps xmm15, [rsp+0x90]
00007fb1689def16  por xmm1, xmm15
00007fb1689def1b  movaps xmm15, [r15+0x1C0]
00007fb1689def23  vmovaps [rsp+0x90], xmm15
00007fb1689def2c  vmovaps [rsp+0xC0], xmm1
00007fb1689def35  vmovaps xmm1, [rsp+0x90]
00007fb1689def3e  por xmm15, xmm1
00007fb1689def43  movaps xmm1, [r15+0x190]
00007fb1689def4b  vmovaps [rsp+0x90], xmm1
00007fb1689def54  vmovaps [rsp+0xD0], xmm15
00007fb1689def5d  vmovaps xmm15, [rsp+0x90]
00007fb1689def66  por xmm1, xmm15
00007fb1689def6b  movaps xmm15, [r15+0x300]
00007fb1689def73  vmovaps [rsp+0x90], xmm15
00007fb1689def7c  vmovaps [rsp+0xE0], xmm1
00007fb1689def85  vmovaps xmm1, [rsp+0x90]
00007fb1689def8e  por xmm15, xmm1
00007fb1689def93  mov rax, [rsp+0x80]
00007fb1689def9b  lea r12, [rax+0xA0]
00007fb1689defa2  movups xmm1, [r13+r12*1]
00007fb1689defa8  lea r12, [rax+0xB0]
00007fb1689defaf  vmovaps [rsp+0x80], xmm1
00007fb1689defb8  movups xmm1, [r13+r12*1]
00007fb1689defbe  vmovaps [rsp+0x90], xmm1
00007fb1689defc7  vmovaps [rsp+0xF0], xmm15
00007fb1689defd0  vmovaps xmm15, [rsp+0xB0]
00007fb1689defd9  vmovaps [rsp+0xB0], xmm14
00007fb1689defe2  movaps xmm1, xmm6
00007fb1689defe5  addpd xmm1, xmm15
00007fb1689defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007fb1689defef  ptest xmm14, xmm14
00007fb1689deff5  jnz 0x00007FB1689E06B6
00007fb1689deffb  lea r12, [rax+0xF0]
00007fb1689df002  movups xmm15, [r13+r12*1]
00007fb1689df008  movaps xmm14, xmm4
00007fb1689df00c  addpd xmm14, xmm3
00007fb1689df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007fb1689df017  ptest xmm6, xmm6
00007fb1689df01c  jnz 0x00007FB1689E0801
00007fb1689df022  movaps xmm6, xmm9
00007fb1689df026  addpd xmm6, xmm7
00007fb1689df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007fb1689df02f  ptest xmm4, xmm4
00007fb1689df034  jnz 0x00007FB1689E0943
00007fb1689df03a  vmovaps xmm9, [rsp+0x70]
00007fb1689df040  vpermilpd xmm9, xmm9, 0x00
00007fb1689df046  vmovaps xmm4, [rsp+0x90]
00007fb1689df04f  movaps xmm7, xmm4
00007fb1689df052  mulpd xmm7, xmm9
00007fb1689df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007fb1689df05c  ptest xmm3, xmm3
00007fb1689df061  jnz 0x00007FB1689E0A84
00007fb1689df067  vmovaps xmm9, [rsp+0x50]
00007fb1689df06d  vpermilpd xmm9, xmm9, 0x00
00007fb1689df073  movaps xmm4, xmm15
00007fb1689df077  mulpd xmm4, xmm9
00007fb1689df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007fb1689df081  ptest xmm3, xmm3
00007fb1689df086  jnz 0x00007FB1689E0BC5
00007fb1689df08c  lea r12, [rax+0xE0]
00007fb1689df093  movups xmm15, [r13+r12*1]
00007fb1689df099  vmovaps xmm9, [rsp+0x70]
00007fb1689df09f  vpermilpd xmm9, xmm9, 0x00
00007fb1689df0a5  vmovaps [rsp+0x70], xmm1
00007fb1689df0ab  vmovaps xmm1, [rsp+0x80]
00007fb1689df0b4  vmovaps [rsp+0x80], xmm15
00007fb1689df0bd  movaps xmm3, xmm1
00007fb1689df0c0  mulpd xmm3, xmm9
00007fb1689df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007fb1689df0ca  ptest xmm15, xmm15
00007fb1689df0d0  jnz 0x00007FB1689E0D11
00007fb1689df0d6  vmovaps xmm1, [rsp+0xF0]
00007fb1689df0df  vmovaps xmm15, [rsp+0xF0]
00007fb1689df0e8  por xmm1, xmm15
00007fb1689df0ed  movaps [r15+0x300], xmm1
00007fb1689df0f5  vmovaps xmm15, [rsp+0xE0]
00007fb1689df0fe  vmovaps xmm9, [rsp+0xE0]
00007fb1689df107  por xmm15, xmm9
00007fb1689df10c  movaps [r15+0x190], xmm15
00007fb1689df114  vmovaps xmm9, [rsp+0x50]
00007fb1689df11a  vpermilpd xmm9, xmm9, 0x00
00007fb1689df120  vmovaps [rsp+0x90], xmm1
00007fb1689df129  vmovaps [rsp+0xE0], xmm15
00007fb1689df132  vmovaps xmm15, [rsp+0x80]
00007fb1689df13b  vmovaps [rsp+0x80], xmm14
00007fb1689df144  movaps xmm1, xmm15
00007fb1689df148  mulpd xmm1, xmm9
00007fb1689df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007fb1689df152  ptest xmm14, xmm14
00007fb1689df158  jnz 0x00007FB1689E0E52
00007fb1689df15e  lea r12, [rax+0x90]
00007fb1689df165  movups xmm15, [r13+r12*1]
00007fb1689df16b  vmovaps xmm14, [rsp+0xD0]
00007fb1689df174  vmovaps xmm9, [rsp+0xD0]
00007fb1689df17d  por xmm14, xmm9
00007fb1689df182  movaps [r15+0x1C0], xmm14
00007fb1689df18a  vmovaps xmm9, [rsp+0xC0]
00007fb1689df193  vmovaps [rsp+0xD0], xmm1
00007fb1689df19c  vmovaps xmm1, [rsp+0xC0]
00007fb1689df1a5  por xmm9, xmm1
00007fb1689df1aa  movaps [r15+0x200], xmm9
00007fb1689df1b2  vmovaps [rsp+0xC0], xmm2
00007fb1689df1bb  vmovaps xmm1, [rsp+0xC0]
00007fb1689df1c4  por xmm2, xmm1
00007fb1689df1c8  movaps [r15+0x2D0], xmm2
00007fb1689df1d0  vmovaps [rsp+0xC0], xmm8
00007fb1689df1d9  vmovaps xmm1, [rsp+0xC0]
00007fb1689df1e2  por xmm8, xmm1
00007fb1689df1e7  movaps [r15+0x2E0], xmm8
00007fb1689df1ef  vmovaps [rsp+0xC0], xmm15
00007fb1689df1f8  movaps xmm1, xmm5
00007fb1689df1fb  addpd xmm1, xmm7
00007fb1689df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007fb1689df204  ptest xmm15, xmm15
00007fb1689df20a  jnz 0x00007FB1689E0F9E
00007fb1689df210  vmovaps xmm15, [rsp+0x50]
00007fb1689df216  vpermilpd xmm15, xmm15, 0x00
00007fb1689df21c  vmovaps xmm5, [rsp+0xC0]
00007fb1689df225  vmovaps [rsp+0xC0], xmm1
00007fb1689df22e  movaps xmm7, xmm5
00007fb1689df231  mulpd xmm7, xmm15
00007fb1689df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007fb1689df23b  ptest xmm1, xmm1
00007fb1689df240  jnz 0x00007FB1689E10DE
00007fb1689df246  lea r12, [rax+0x80]
00007fb1689df24d  movups xmm1, [r13+r12*1]
00007fb1689df253  vmovaps xmm5, [rsp+0x70]
00007fb1689df259  vmovaps [rsp+0x70], xmm1
00007fb1689df25f  movaps xmm15, xmm5
00007fb1689df263  addpd xmm15, xmm3
00007fb1689df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007fb1689df26e  ptest xmm1, xmm1
00007fb1689df273  jnz 0x00007FB1689E1229
00007fb1689df279  vmovaps xmm5, [rsp+0x80]
00007fb1689df282  movaps xmm1, xmm5
00007fb1689df285  addpd xmm1, xmm4
00007fb1689df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007fb1689df28e  ptest xmm3, xmm3
00007fb1689df293  jnz 0x00007FB1689E136B
00007fb1689df299  vmovaps [rsp+0x80], xmm10
00007fb1689df2a2  vmovaps xmm5, [rsp+0x80]
00007fb1689df2ab  por xmm10, xmm5
00007fb1689df2b0  movaps [r15+0x2F0], xmm10
00007fb1689df2b8  vmovaps xmm5, [rsp+0x50]
00007fb1689df2be  vpermilpd xmm5, xmm5, 0x00
00007fb1689df2c4  vmovaps xmm3, [rsp+0x70]
00007fb1689df2ca  vmovaps [rsp+0x50], xmm1
00007fb1689df2d0  movaps xmm4, xmm3
00007fb1689df2d3  mulpd xmm4, xmm5
00007fb1689df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007fb1689df2dc  ptest xmm1, xmm1
00007fb1689df2e1  jnz 0x00007FB1689E14AB
00007fb1689df2e7  lea r12, [rax+0xD0]
00007fb1689df2ee  movups xmm1, [r13+r12*1]
00007fb1689df2f4  vmovaps xmm3, [rsp+0xD0]
00007fb1689df2fd  vmovaps [rsp+0x70], xmm1
00007fb1689df303  movaps xmm5, xmm6
00007fb1689df306  addpd xmm5, xmm3
00007fb1689df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007fb1689df30f  ptest xmm1, xmm1
00007fb1689df314  jnz 0x00007FB1689E15F5
00007fb1689df31a  vmovaps xmm1, [rsp+0x60]
00007fb1689df320  vpermilpd xmm1, xmm1, 0x00
00007fb1689df326  movaps xmm6, xmm9
00007fb1689df32a  mulpd xmm6, xmm1
00007fb1689df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007fb1689df333  ptest xmm3, xmm3
00007fb1689df338  jnz 0x00007FB1689E1735
00007fb1689df33e  movaps [r15+0x260], xmm6
00007fb1689df346  vxorps xmm1, xmm1, xmm1
00007fb1689df34a  vpbroadcastq xmm1, xmm1
00007fb1689df34f  movaps [r15+0x1B0], xmm1
00007fb1689df357  vmovaps xmm1, [rsp+0x60]
00007fb1689df35d  vpermilpd xmm1, xmm1, 0x00
00007fb1689df363  vmovaps xmm3, [rsp+0x70]
00007fb1689df369  vmovaps [rsp+0x70], xmm15
00007fb1689df36f  movaps xmm9, xmm3
00007fb1689df373  mulpd xmm9, xmm1
00007fb1689df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007fb1689df37e  ptest xmm15, xmm15
00007fb1689df384  jnz 0x00007FB1689E1876
00007fb1689df38a  lea r12, [rax+0xC0]
00007fb1689df391  movups xmm1, [r13+r12*1]
00007fb1689df397  vmovaps xmm3, [rsp+0xC0]
00007fb1689df3a0  vmovaps [rsp+0x80], xmm1
00007fb1689df3a9  movaps xmm15, xmm3
00007fb1689df3ad  addpd xmm15, xmm7
00007fb1689df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007fb1689df3b8  ptest xmm1, xmm1
00007fb1689df3bd  jnz 0x00007FB1689E19C2
00007fb1689df3c3  vmovaps [rsp+0xC0], xmm13
00007fb1689df3cc  vmovaps xmm1, [rsp+0xC0]
00007fb1689df3d5  por xmm13, xmm1
00007fb1689df3da  movaps [r15+0x270], xmm13
00007fb1689df3e2  vmovaps xmm1, [rsp+0xB0]
00007fb1689df3eb  vmovaps xmm7, [rsp+0xB0]
00007fb1689df3f4  por xmm1, xmm7
00007fb1689df3f8  movaps [r15+0x1A0], xmm1
00007fb1689df400  vmovaps xmm1, [rsp+0x60]
00007fb1689df406  vpermilpd xmm1, xmm1, 0x00
00007fb1689df40c  vmovaps [rsp+0xB0], xmm1
00007fb1689df415  vmovaps xmm1, [rsp+0x80]
00007fb1689df41e  vmovaps [rsp+0x80], xmm15
00007fb1689df427  vmovaps xmm15, [rsp+0xB0]
00007fb1689df430  vmovaps [rsp+0xB0], xmm14
00007fb1689df439  movaps xmm3, xmm1
00007fb1689df43c  mulpd xmm3, xmm15
00007fb1689df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007fb1689df446  ptest xmm14, xmm14
00007fb1689df44c  jnz 0x00007FB1689E1B04
00007fb1689df452  lea r12, [rax+0x20]
00007fb1689df456  movups xmm1, [r13+r12*1]
00007fb1689df45c  movaps [r15+0x110], xmm1
00007fb1689df464  vmovaps xmm14, [rsp+0x70]
00007fb1689df46a  vmovaps [rsp+0x70], xmm1
00007fb1689df470  movaps xmm15, xmm14
00007fb1689df474  addpd xmm15, xmm4
00007fb1689df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007fb1689df47f  ptest xmm1, xmm1
00007fb1689df484  jnz 0x00007FB1689E1C4F
00007fb1689df48a  vmovaps xmm1, [rsp+0x60]
00007fb1689df490  vpermilpd xmm1, xmm1, 0x00
00007fb1689df496  movaps xmm14, xmm2
00007fb1689df49a  mulpd xmm14, xmm1
00007fb1689df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007fb1689df4a5  ptest xmm4, xmm4
00007fb1689df4aa  jnz 0x00007FB1689E1D92
00007fb1689df4b0  vmovaps xmm4, [rsp+0x50]
00007fb1689df4b6  movaps xmm1, xmm4
00007fb1689df4b9  addpd xmm1, xmm9
00007fb1689df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007fb1689df4c3  ptest xmm2, xmm2
00007fb1689df4c8  jnz 0x00007FB1689E1ED4
00007fb1689df4ce  vmovaps xmm9, [rsp+0x30]
00007fb1689df4d4  vpermilpd xmm9, xmm9, 0x00
00007fb1689df4da  vmovaps xmm2, [rsp+0x70]
00007fb1689df4e0  vmovaps [rsp+0x50], xmm1
00007fb1689df4e6  movaps xmm4, xmm2
00007fb1689df4e9  mulpd xmm4, xmm9
00007fb1689df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007fb1689df4f3  ptest xmm1, xmm1
00007fb1689df4f8  jnz 0x00007FB1689E2015
00007fb1689df4fe  vmovaps xmm1, [rsp+0x30]
00007fb1689df504  vpermilpd xmm1, xmm1, 0x00
00007fb1689df50a  vmovaps xmm2, [rsp+0x90]
00007fb1689df513  vmovaps [rsp+0x60], xmm15
00007fb1689df519  movaps xmm9, xmm2
00007fb1689df51d  mulpd xmm9, xmm1
00007fb1689df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007fb1689df528  ptest xmm15, xmm15
00007fb1689df52e  jnz 0x00007FB1689E2156
00007fb1689df534  vmovaps xmm15, [rsp+0x80]
00007fb1689df53d  movaps xmm1, xmm15
00007fb1689df541  addpd xmm1, xmm6
00007fb1689df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007fb1689df54a  ptest xmm2, xmm2
00007fb1689df54f  jnz 0x00007FB1689E2298
00007fb1689df555  movaps xmm15, xmm5
00007fb1689df559  addpd xmm15, xmm3
00007fb1689df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007fb1689df564  ptest xmm6, xmm6
00007fb1689df569  jnz 0x00007FB1689E23D9
00007fb1689df56f  vmovaps xmm6, [rsp+0x30]
00007fb1689df575  vpermilpd xmm6, xmm6, 0x00
00007fb1689df57b  movaps xmm5, xmm8
00007fb1689df57f  mulpd xmm5, xmm6
00007fb1689df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007fb1689df588  ptest xmm3, xmm3
00007fb1689df58d  jnz 0x00007FB1689E251B
00007fb1689df593  vmovaps xmm8, [rsp+0x30]
00007fb1689df599  vpermilpd xmm8, xmm8, 0x00
00007fb1689df59f  movaps xmm6, xmm10
00007fb1689df5a3  mulpd xmm6, xmm8
00007fb1689df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007fb1689df5ad  ptest xmm3, xmm3
00007fb1689df5b2  jnz 0x00007FB1689E265C
00007fb1689df5b8  vmovaps xmm8, [rsp+0x60]
00007fb1689df5be  movaps xmm10, xmm8
00007fb1689df5c2  addpd xmm10, xmm14
00007fb1689df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007fb1689df5cd  ptest xmm3, xmm3
00007fb1689df5d2  jnz 0x00007FB1689E279E
00007fb1689df5d8  vmovaps xmm8, [rsp+0x50]
00007fb1689df5de  movaps xmm14, xmm8
00007fb1689df5e2  addpd xmm14, xmm4
00007fb1689df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007fb1689df5ed  ptest xmm3, xmm3
00007fb1689df5f2  jnz 0x00007FB1689E28E2
00007fb1689df5f8  vmovaps xmm8, [rsp+0x40]
00007fb1689df5fe  vpermilpd xmm8, xmm8, 0x00
00007fb1689df604  movaps xmm4, xmm13
00007fb1689df608  mulpd xmm4, xmm8
00007fb1689df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007fb1689df612  ptest xmm3, xmm3
00007fb1689df617  jnz 0x00007FB1689E2A25
00007fb1689df61d  movaps xmm13, xmm15
00007fb1689df621  addpd xmm13, xmm9
00007fb1689df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007fb1689df62c  ptest xmm8, xmm8
00007fb1689df632  jnz 0x00007FB1689E2B67
00007fb1689df638  movaps xmm15, xmm1
00007fb1689df63c  addpd xmm15, xmm5
00007fb1689df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007fb1689df647  ptest xmm9, xmm9
00007fb1689df64d  jnz 0x00007FB1689E2CAB
00007fb1689df653  vmovaps [rsp+0x30], xmm11
00007fb1689df659  vmovaps xmm1, [rsp+0x30]
00007fb1689df65f  por xmm11, xmm1
00007fb1689df664  movaps [r15+0x250], xmm11
00007fb1689df66c  vmovaps [rsp+0x30], xmm12
00007fb1689df672  vmovaps xmm1, [rsp+0x30]
00007fb1689df678  por xmm12, xmm1
00007fb1689df67d  movaps [r15+0x2A0], xmm12
00007fb1689df685  vmovaps xmm1, [rsp+0xA0]
00007fb1689df68e  vmovaps xmm11, [rsp+0xA0]
00007fb1689df697  por xmm1, xmm11
00007fb1689df69c  movaps [r15+0x1D0], xmm1
00007fb1689df6a4  lea r12, [rax+0x40]
00007fb1689df6a8  movups xmm1, [r13+r12*1]
00007fb1689df6ae  movaps [r15+0x2C0], xmm1
00007fb1689df6b6  vmovaps xmm11, [rsp+0x40]
00007fb1689df6bc  vpermilpd xmm11, xmm11, 0x00
00007fb1689df6c2  vmovaps xmm8, [rsp+0xE0]
00007fb1689df6cb  movaps xmm9, xmm8
00007fb1689df6cf  mulpd xmm9, xmm11
00007fb1689df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007fb1689df6da  ptest xmm5, xmm5
00007fb1689df6df  jnz 0x00007FB1689E2DF7
00007fb1689df6e5  movaps xmm11, xmm10
00007fb1689df6e9  addpd xmm11, xmm6
00007fb1689df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007fb1689df6f4  ptest xmm8, xmm8
00007fb1689df6fa  jnz 0x00007FB1689E2F3B
00007fb1689df700  movaps xmm10, xmm14
00007fb1689df704  addpd xmm10, xmm4
00007fb1689df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007fb1689df70f  ptest xmm8, xmm8
00007fb1689df715  jnz 0x00007FB1689E307E
00007fb1689df71b  vmovaps xmm14, [rsp+0x40]
00007fb1689df721  vpermilpd xmm14, xmm14, 0x00
00007fb1689df727  movaps xmm8, xmm1
00007fb1689df72b  mulpd xmm8, xmm14
00007fb1689df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007fb1689df736  ptest xmm6, xmm6
00007fb1689df73b  jnz 0x00007FB1689E31C1
00007fb1689df741  movaps xmm1, [r15+0x2B0]
00007fb1689df749  vmovaps xmm14, [rsp+0x40]
00007fb1689df74f  vpermilpd xmm14, xmm14, 0x00
00007fb1689df755  movaps xmm6, xmm1
00007fb1689df758  mulpd xmm6, xmm14
00007fb1689df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007fb1689df762  ptest xmm5, xmm5
00007fb1689df767  jnz 0x00007FB1689E3304
00007fb1689df76d  vmovaps xmm1, [rsp+0x10]
00007fb1689df773  vpermilpd xmm1, xmm1, 0x00
00007fb1689df779  movaps xmm14, xmm12
00007fb1689df77d  mulpd xmm14, xmm1
00007fb1689df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007fb1689df788  ptest xmm5, xmm5
00007fb1689df78d  jnz 0x00007FB1689E3445
00007fb1689df793  movaps xmm1, xmm13
00007fb1689df797  addpd xmm1, xmm9
00007fb1689df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007fb1689df7a1  ptest xmm12, xmm12
00007fb1689df7a7  jnz 0x00007FB1689E3588
00007fb1689df7ad  vmovaps xmm13, [rsp+0x10]
00007fb1689df7b3  vpermilpd xmm13, xmm13, 0x00
00007fb1689df7b9  movaps xmm12, xmm7
00007fb1689df7bd  mulpd xmm12, xmm13
00007fb1689df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007fb1689df7c8  ptest xmm9, xmm9
00007fb1689df7ce  jnz 0x00007FB1689E36CA
00007fb1689df7d4  movaps xmm13, xmm15
00007fb1689df7d8  addpd xmm13, xmm8
00007fb1689df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007fb1689df7e3  ptest xmm9, xmm9
00007fb1689df7e9  jnz 0x00007FB1689E380D
00007fb1689df7ef  movaps xmm15, [r15+0x290]
00007fb1689df7f7  vmovaps xmm9, [rsp+0x10]
00007fb1689df7fd  vpermilpd xmm9, xmm9, 0x00
00007fb1689df803  movaps xmm8, xmm15
00007fb1689df807  mulpd xmm8, xmm9
00007fb1689df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007fb1689df812  ptest xmm7, xmm7
00007fb1689df817  jnz 0x00007FB1689E3951
00007fb1689df81d  movaps xmm15, xmm11
00007fb1689df821  addpd xmm15, xmm6
00007fb1689df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007fb1689df82c  ptest xmm9, xmm9
00007fb1689df832  jnz 0x00007FB1689E3A95
00007fb1689df838  movaps xmm11, [r15+0x1E0]
00007fb1689df840  vmovaps xmm9, [rsp+0x10]
00007fb1689df846  vpermilpd xmm9, xmm9, 0x00
00007fb1689df84c  movaps xmm7, xmm11
00007fb1689df850  mulpd xmm7, xmm9
00007fb1689df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007fb1689df85a  ptest xmm6, xmm6
00007fb1689df85f  jnz 0x00007FB1689E3BD8
00007fb1689df865  movaps xmm11, xmm10
00007fb1689df869  addpd xmm11, xmm14
00007fb1689df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007fb1689df874  ptest xmm9, xmm9
00007fb1689df87a  jnz 0x00007FB1689E3D1A
00007fb1689df880  lea r12, [rax+0x70]
00007fb1689df884  movups xmm14, [r13+r12*1]
00007fb1689df88a  movaps [r15+0x240], xmm14
00007fb1689df892  movaps xmm10, xmm1
00007fb1689df896  addpd xmm10, xmm12
00007fb1689df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007fb1689df8a1  ptest xmm9, xmm9
00007fb1689df8a7  jnz 0x00007FB1689E3E68
00007fb1689df8ad  movaps [r15+0x170], xmm10
00007fb1689df8b5  vmovaps xmm1, [rsp+0x20]
00007fb1689df8bb  vpermilpd xmm1, xmm1, 0x00
00007fb1689df8c1  movaps xmm12, xmm14
00007fb1689df8c5  mulpd xmm12, xmm1
00007fb1689df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007fb1689df8d0  ptest xmm9, xmm9
00007fb1689df8d6  jnz 0x00007FB1689E3FAB
00007fb1689df8dc  vmovaps xmm1, [rsp+0x20]
00007fb1689df8e2  vpermilpd xmm1, xmm1, 0x00
00007fb1689df8e8  vmovaps xmm9, [rsp+0xB0]
00007fb1689df8f1  movaps xmm14, xmm9
00007fb1689df8f5  mulpd xmm14, xmm1
00007fb1689df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007fb1689df900  ptest xmm6, xmm6
00007fb1689df905  jnz 0x00007FB1689E40EE
00007fb1689df90b  movaps [r15+0x180], xmm14
00007fb1689df913  movaps xmm1, xmm13
00007fb1689df917  addpd xmm1, xmm8
00007fb1689df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007fb1689df921  ptest xmm9, xmm9
00007fb1689df927  jnz 0x00007FB1689E4231
00007fb1689df92d  movaps [r15+0x210], xmm1
00007fb1689df935  movups xmm13, [r13+rax*1]
00007fb1689df93b  lea r12, [rax+0x10]
00007fb1689df93f  movups xmm9, [r13+r12*1]
00007fb1689df945  movaps [r15+0x230], xmm9
00007fb1689df94d  movaps xmm8, xmm15
00007fb1689df951  addpd xmm8, xmm7
00007fb1689df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007fb1689df95c  ptest xmm6, xmm6
00007fb1689df961  jnz 0x00007FB1689E4387
00007fb1689df967  movaps [r15+0x130], xmm8
00007fb1689df96f  vmovaps xmm15, [rsp+0x20]
00007fb1689df975  vpermilpd xmm15, xmm15, 0x00
00007fb1689df97b  movaps xmm7, xmm9
00007fb1689df97f  mulpd xmm7, xmm15
00007fb1689df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007fb1689df989  ptest xmm6, xmm6
00007fb1689df98e  jnz 0x00007FB1689E44CA
00007fb1689df994  movaps [r15+0x220], xmm7
00007fb1689df99c  vmovaps xmm15, [rsp+0x20]
00007fb1689df9a2  vpermilpd xmm15, xmm15, 0x00
00007fb1689df9a8  movaps xmm9, xmm13
00007fb1689df9ac  mulpd xmm9, xmm15
00007fb1689df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007fb1689df9b7  ptest xmm6, xmm6
00007fb1689df9bc  jnz 0x00007FB1689E460C
00007fb1689df9c2  movaps xmm15, xmm11
00007fb1689df9c6  addpd xmm15, xmm12
00007fb1689df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007fb1689df9d1  ptest xmm13, xmm13
00007fb1689df9d7  jnz 0x00007FB1689E4750
00007fb1689df9dd  movaps [r15+0x140], xmm15
00007fb1689df9e5  movaps xmm13, xmm10
00007fb1689df9e9  addpd xmm13, xmm14
00007fb1689df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007fb1689df9f4  ptest xmm12, xmm12
00007fb1689df9fa  jnz 0x00007FB1689E4894
00007fb1689dfa00  movaps [r15+0x150], xmm13
00007fb1689dfa08  movaps xmm14, xmm1
00007fb1689dfa0c  addpd xmm14, xmm7
00007fb1689dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007fb1689dfa17  ptest xmm12, xmm12
00007fb1689dfa1d  jnz 0x00007FB1689E49D8
00007fb1689dfa23  movaps [r15+0x160], xmm14
00007fb1689dfa2b  movaps xmm1, xmm8
00007fb1689dfa2f  addpd xmm1, xmm9
00007fb1689dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007fb1689dfa39  ptest xmm12, xmm12
00007fb1689dfa3f  jnz 0x00007FB1689E4B1A
00007fb1689dfa45  movaps [r15+0x120], xmm1
00007fb1689dfa4d  movups [r13+r14*1], xmm15
00007fb1689dfa53  lea rax, [r14+0x10]
00007fb1689dfa57  movups [r13+rax*1], xmm13
00007fb1689dfa5d  lea rax, [r14+0x20]
00007fb1689dfa61  movups [r13+rax*1], xmm14
00007fb1689dfa67  lea rax, [r14+0x30]
00007fb1689dfa6b  movups [r13+rax*1], xmm1
00007fb1689dfa71  mov eax, [r15+0x108]
00007fb1689dfa78  sahf
00007fb1689dfa79  jnz 0x00007FB1689DFAAB
00007fb1689dfa7b  cmp dword ptr [r15+0x318], 0x00
00007fb1689dfa83  jz 0x00007FB1689DEAE0
00007fb1689dfa89  nop [rax+rax*1], ax
00007fb1689dfa92  nop [rax+rax*1], eax
00007fb1689dfa9a  mov eax, 0x4106D0
00007fb1689dfa9f  mov [r15+0x100], rax
00007fb1689dfaa6  jmp 0x00007FB1687FE110
00007fb1689dfaab  cmp dword ptr [r15+0x318], 0x00
00007fb1689dfab3  jz 0x00007FB1689D89C0
00007fb1689dfab9  nop [rax+rax*1], ax
00007fb1689dfac2  nop [rax+rax*1], eax
00007fb1689dfaca  mov eax, 0x410504
00007fb1689dfacf  mov [r15+0x100], rax
00007fb1689dfad6  jmp 0x00007FB1687FE110
00007fb1689dfadb  int3
00007fb1689dfadc  call 0x00007FB1688E27E0
00007fb1689dfae1  jmp 0x00007FB1689DEBBF
00007fb1689dfae6  call 0x00007FB1688E1570
00007fb1689dfaeb  jmp 0x00007FB1689DEBC8
00007fb1689dfaf0  call 0x00007FB1688E27E0
00007fb1689dfaf5  jmp 0x00007FB1689DEC24
00007fb1689dfafa  call 0x00007FB1688E1570
00007fb1689dfaff  jmp 0x00007FB1689DEC2D
00007fb1689dfb04  call 0x00007FB1688E27E0
00007fb1689dfb09  jmp 0x00007FB1689DEC70
00007fb1689dfb0e  call 0x00007FB1688E1570
00007fb1689dfb13  jmp 0x00007FB1689DEC79
00007fb1689dfb18  call 0x00007FB16880DC20
00007fb1689dfb1d  jmp 0x00007FB1689DECB8
00007fb1689dfb22  call 0x00007FB1688D59C0
00007fb1689dfb27  jmp 0x00007FB1689DECCB
00007fb1689dfb2c  call 0x00007FB1688E0E30
00007fb1689dfb31  jmp 0x00007FB1689DECE9
00007fb1689dfb36  call 0x00007FB1688DFBC0
00007fb1689dfb3b  jmp 0x00007FB1689DECF3
00007fb1689dfb40  call 0x00007FB1688DE950
00007fb1689dfb45  jmp 0x00007FB1689DECFD
00007fb1689dfb4a  sub rsp, 0x08
00007fb1689dfb4e  push rax
00007fb1689dfb4f  push rcx
00007fb1689dfb50  push rdx
00007fb1689dfb51  push rdi
00007fb1689dfb52  push rsi
00007fb1689dfb53  push r8
00007fb1689dfb55  push r9
00007fb1689dfb57  push r10
00007fb1689dfb59  push r11
00007fb1689dfb5b  sub rsp, 0xF0
00007fb1689dfb62  vmovaps [rsp], xmm0
00007fb1689dfb67  vmovaps [rsp+0x10], xmm1
00007fb1689dfb6d  vmovaps [rsp+0x20], xmm2
00007fb1689dfb73  vmovaps [rsp+0x30], xmm3
00007fb1689dfb79  vmovaps [rsp+0x40], xmm4
00007fb1689dfb7f  vmovaps [rsp+0x50], xmm5
00007fb1689dfb85  vmovaps [rsp+0x60], xmm6
00007fb1689dfb8b  vmovaps [rsp+0x70], xmm7
00007fb1689dfb91  vmovaps [rsp+0x80], xmm9
00007fb1689dfb9a  vmovaps [rsp+0x90], xmm10
00007fb1689dfba3  vmovaps [rsp+0xA0], xmm11
00007fb1689dfbac  vmovaps [rsp+0xB0], xmm12
00007fb1689dfbb5  vmovaps [rsp+0xC0], xmm13
00007fb1689dfbbe  vmovaps [rsp+0xD0], xmm14
00007fb1689dfbc7  vmovaps [rsp+0xE0], xmm15
00007fb1689dfbd0  sub rsp, 0x30
00007fb1689dfbd4  movaps [rsp], xmm8
00007fb1689dfbd9  movaps [rsp+0x10], xmm12
00007fb1689dfbdf  movaps [rsp+0x20], xmm15
00007fb1689dfbe5  lea rdi, [rsp]
00007fb1689dfbe9  mov esi, 0x00
00007fb1689dfbee  mov rax, 0x57CCFD419530
00007fb1689dfbf8  call rax
00007fb1689dfbfa  movaps xmm8, [rsp]
00007fb1689dfbff  add rsp, 0x30
00007fb1689dfc03  vmovaps xmm0, [rsp]
00007fb1689dfc08  vmovaps xmm1, [rsp+0x10]
00007fb1689dfc0e  vmovaps xmm2, [rsp+0x20]
00007fb1689dfc14  vmovaps xmm3, [rsp+0x30]
00007fb1689dfc1a  vmovaps xmm4, [rsp+0x40]
00007fb1689dfc20  vmovaps xmm5, [rsp+0x50]
00007fb1689dfc26  vmovaps xmm6, [rsp+0x60]
00007fb1689dfc2c  vmovaps xmm7, [rsp+0x70]
00007fb1689dfc32  vmovaps xmm9, [rsp+0x80]
00007fb1689dfc3b  vmovaps xmm10, [rsp+0x90]
00007fb1689dfc44  vmovaps xmm11, [rsp+0xA0]
00007fb1689dfc4d  vmovaps xmm12, [rsp+0xB0]
00007fb1689dfc56  vmovaps xmm13, [rsp+0xC0]
00007fb1689dfc5f  vmovaps xmm14, [rsp+0xD0]
00007fb1689dfc68  vmovaps xmm15, [rsp+0xE0]
00007fb1689dfc71  add rsp, 0xF0
00007fb1689dfc78  pop r11
00007fb1689dfc7a  pop r10
00007fb1689dfc7c  pop r9
00007fb1689dfc7e  pop r8
00007fb1689dfc80  pop rsi
00007fb1689dfc81  pop rdi
00007fb1689dfc82  pop rdx
00007fb1689dfc83  pop rcx
00007fb1689dfc84  pop rax
00007fb1689dfc85  add rsp, 0x08
00007fb1689dfc89  jmp 0x00007FB1689DED27
00007fb1689dfc8e  sub rsp, 0x08
00007fb1689dfc92  push rax
00007fb1689dfc93  push rcx
00007fb1689dfc94  push rdx
00007fb1689dfc95  push rdi
00007fb1689dfc96  push rsi
00007fb1689dfc97  push r8
00007fb1689dfc99  push r9
00007fb1689dfc9b  push r10
00007fb1689dfc9d  push r11
00007fb1689dfc9f  sub rsp, 0xF0
00007fb1689dfca6  vmovaps [rsp], xmm0
00007fb1689dfcab  vmovaps [rsp+0x10], xmm1
00007fb1689dfcb1  vmovaps [rsp+0x20], xmm2
00007fb1689dfcb7  vmovaps [rsp+0x30], xmm3
00007fb1689dfcbd  vmovaps [rsp+0x40], xmm4
00007fb1689dfcc3  vmovaps [rsp+0x50], xmm5
00007fb1689dfcc9  vmovaps [rsp+0x60], xmm6
00007fb1689dfccf  vmovaps [rsp+0x70], xmm8
00007fb1689dfcd5  vmovaps [rsp+0x80], xmm9
00007fb1689dfcde  vmovaps [rsp+0x90], xmm10
00007fb1689dfce7  vmovaps [rsp+0xA0], xmm11
00007fb1689dfcf0  vmovaps [rsp+0xB0], xmm12
00007fb1689dfcf9  vmovaps [rsp+0xC0], xmm13
00007fb1689dfd02  vmovaps [rsp+0xD0], xmm14
00007fb1689dfd0b  vmovaps [rsp+0xE0], xmm15
00007fb1689dfd14  sub rsp, 0x30
00007fb1689dfd18  movaps [rsp], xmm7
00007fb1689dfd1c  movaps [rsp+0x10], xmm9
00007fb1689dfd22  movaps [rsp+0x20], xmm15
00007fb1689dfd28  lea rdi, [rsp]
00007fb1689dfd2c  mov esi, 0x00
00007fb1689dfd31  mov rax, 0x57CCFD419530
00007fb1689dfd3b  call rax
00007fb1689dfd3d  movaps xmm7, [rsp]
00007fb1689dfd41  add rsp, 0x30
00007fb1689dfd45  vmovaps xmm0, [rsp]
00007fb1689dfd4a  vmovaps xmm1, [rsp+0x10]
00007fb1689dfd50  vmovaps xmm2, [rsp+0x20]
00007fb1689dfd56  vmovaps xmm3, [rsp+0x30]
00007fb1689dfd5c  vmovaps xmm4, [rsp+0x40]
00007fb1689dfd62  vmovaps xmm5, [rsp+0x50]
00007fb1689dfd68  vmovaps xmm6, [rsp+0x60]
00007fb1689dfd6e  vmovaps xmm8, [rsp+0x70]
00007fb1689dfd74  vmovaps xmm9, [rsp+0x80]
00007fb1689dfd7d  vmovaps xmm10, [rsp+0x90]
00007fb1689dfd86  vmovaps xmm11, [rsp+0xA0]
00007fb1689dfd8f  vmovaps xmm12, [rsp+0xB0]
00007fb1689dfd98  vmovaps xmm13, [rsp+0xC0]
00007fb1689dfda1  vmovaps xmm14, [rsp+0xD0]
00007fb1689dfdaa  vmovaps xmm15, [rsp+0xE0]
00007fb1689dfdb3  add rsp, 0xF0
00007fb1689dfdba  pop r11
00007fb1689dfdbc  pop r10
00007fb1689dfdbe  pop r9
00007fb1689dfdc0  pop r8
00007fb1689dfdc2  pop rsi
00007fb1689dfdc3  pop rdi
00007fb1689dfdc4  pop rdx
00007fb1689dfdc5  pop rcx
00007fb1689dfdc6  pop rax
00007fb1689dfdc7  add rsp, 0x08
00007fb1689dfdcb  jmp 0x00007FB1689DED55
00007fb1689dfdd0  sub rsp, 0x08
00007fb1689dfdd4  push rax
00007fb1689dfdd5  push rcx
00007fb1689dfdd6  push rdx
00007fb1689dfdd7  push rdi
00007fb1689dfdd8  push rsi
00007fb1689dfdd9  push r8
00007fb1689dfddb  push r9
00007fb1689dfddd  push r10
00007fb1689dfddf  push r11
00007fb1689dfde1  sub rsp, 0xF0
00007fb1689dfde8  vmovaps [rsp], xmm0
00007fb1689dfded  vmovaps [rsp+0x10], xmm1
00007fb1689dfdf3  vmovaps [rsp+0x20], xmm2
00007fb1689dfdf9  vmovaps [rsp+0x30], xmm3
00007fb1689dfdff  vmovaps [rsp+0x40], xmm4
00007fb1689dfe05  vmovaps [rsp+0x50], xmm5
00007fb1689dfe0b  vmovaps [rsp+0x60], xmm6
00007fb1689dfe11  vmovaps [rsp+0x70], xmm7
00007fb1689dfe17  vmovaps [rsp+0x80], xmm8
00007fb1689dfe20  vmovaps [rsp+0x90], xmm10
00007fb1689dfe29  vmovaps [rsp+0xA0], xmm11
00007fb1689dfe32  vmovaps [rsp+0xB0], xmm12
00007fb1689dfe3b  vmovaps [rsp+0xC0], xmm13
00007fb1689dfe44  vmovaps [rsp+0xD0], xmm14
00007fb1689dfe4d  vmovaps [rsp+0xE0], xmm15
00007fb1689dfe56  sub rsp, 0x30
00007fb1689dfe5a  movaps [rsp], xmm9
00007fb1689dfe5f  movaps [rsp+0x10], xmm12
00007fb1689dfe65  movaps [rsp+0x20], xmm10
00007fb1689dfe6b  lea rdi, [rsp]
00007fb1689dfe6f  mov esi, 0x00
00007fb1689dfe74  mov rax, 0x57CCFD419530
00007fb1689dfe7e  call rax
00007fb1689dfe80  movaps xmm9, [rsp]
00007fb1689dfe85  add rsp, 0x30
00007fb1689dfe89  vmovaps xmm0, [rsp]
00007fb1689dfe8e  vmovaps xmm1, [rsp+0x10]
00007fb1689dfe94  vmovaps xmm2, [rsp+0x20]
00007fb1689dfe9a  vmovaps xmm3, [rsp+0x30]
00007fb1689dfea0  vmovaps xmm4, [rsp+0x40]
00007fb1689dfea6  vmovaps xmm5, [rsp+0x50]
00007fb1689dfeac  vmovaps xmm6, [rsp+0x60]
00007fb1689dfeb2  vmovaps xmm7, [rsp+0x70]
00007fb1689dfeb8  vmovaps xmm8, [rsp+0x80]
00007fb1689dfec1  vmovaps xmm10, [rsp+0x90]
00007fb1689dfeca  vmovaps xmm11, [rsp+0xA0]
00007fb1689dfed3  vmovaps xmm12, [rsp+0xB0]
00007fb1689dfedc  vmovaps xmm13, [rsp+0xC0]
00007fb1689dfee5  vmovaps xmm14, [rsp+0xD0]
00007fb1689dfeee  vmovaps xmm15, [rsp+0xE0]
00007fb1689dfef7  add rsp, 0xF0
00007fb1689dfefe  pop r11
00007fb1689dff00  pop r10
00007fb1689dff02  pop r9
00007fb1689dff04  pop r8
00007fb1689dff06  pop rsi
00007fb1689dff07  pop rdi
00007fb1689dff08  pop rdx
00007fb1689dff09  pop rcx
00007fb1689dff0a  pop rax
00007fb1689dff0b  add rsp, 0x08
00007fb1689dff0f  jmp 0x00007FB1689DED79
00007fb1689dff14  sub rsp, 0x08
00007fb1689dff18  push rax
00007fb1689dff19  push rcx
00007fb1689dff1a  push rdx
00007fb1689dff1b  push rdi
00007fb1689dff1c  push rsi
00007fb1689dff1d  push r8
00007fb1689dff1f  push r9
00007fb1689dff21  push r10
00007fb1689dff23  push r11
00007fb1689dff25  sub rsp, 0xF0
00007fb1689dff2c  vmovaps [rsp], xmm0
00007fb1689dff31  vmovaps [rsp+0x10], xmm1
00007fb1689dff37  vmovaps [rsp+0x20], xmm2
00007fb1689dff3d  vmovaps [rsp+0x30], xmm3
00007fb1689dff43  vmovaps [rsp+0x40], xmm4
00007fb1689dff49  vmovaps [rsp+0x50], xmm5
00007fb1689dff4f  vmovaps [rsp+0x60], xmm6
00007fb1689dff55  vmovaps [rsp+0x70], xmm7
00007fb1689dff5b  vmovaps [rsp+0x80], xmm8
00007fb1689dff64  vmovaps [rsp+0x90], xmm9
00007fb1689dff6d  vmovaps [rsp+0xA0], xmm11
00007fb1689dff76  vmovaps [rsp+0xB0], xmm12
00007fb1689dff7f  vmovaps [rsp+0xC0], xmm13
00007fb1689dff88  vmovaps [rsp+0xD0], xmm14
00007fb1689dff91  vmovaps [rsp+0xE0], xmm15
00007fb1689dff9a  sub rsp, 0x30
00007fb1689dff9e  movaps [rsp], xmm10
00007fb1689dffa3  movaps [rsp+0x10], xmm12
00007fb1689dffa9  movaps [rsp+0x20], xmm11
00007fb1689dffaf  lea rdi, [rsp]
00007fb1689dffb3  mov esi, 0x00
00007fb1689dffb8  mov rax, 0x57CCFD419530
00007fb1689dffc2  call rax
00007fb1689dffc4  movaps xmm10, [rsp]
00007fb1689dffc9  add rsp, 0x30
00007fb1689dffcd  vmovaps xmm0, [rsp]
00007fb1689dffd2  vmovaps xmm1, [rsp+0x10]
00007fb1689dffd8  vmovaps xmm2, [rsp+0x20]
00007fb1689dffde  vmovaps xmm3, [rsp+0x30]
00007fb1689dffe4  vmovaps xmm4, [rsp+0x40]
00007fb1689dffea  vmovaps xmm5, [rsp+0x50]
00007fb1689dfff0  vmovaps xmm6, [rsp+0x60]
00007fb1689dfff6  vmovaps xmm7, [rsp+0x70]
00007fb1689dfffc  vmovaps xmm8, [rsp+0x80]
00007fb1689e0005  vmovaps xmm9, [rsp+0x90]
00007fb1689e000e  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0017  vmovaps xmm12, [rsp+0xB0]
00007fb1689e0020  vmovaps xmm13, [rsp+0xC0]
00007fb1689e0029  vmovaps xmm14, [rsp+0xD0]
00007fb1689e0032  vmovaps xmm15, [rsp+0xE0]
00007fb1689e003b  add rsp, 0xF0
00007fb1689e0042  pop r11
00007fb1689e0044  pop r10
00007fb1689e0046  pop r9
00007fb1689e0048  pop r8
00007fb1689e004a  pop rsi
00007fb1689e004b  pop rdi
00007fb1689e004c  pop rdx
00007fb1689e004d  pop rcx
00007fb1689e004e  pop rax
00007fb1689e004f  add rsp, 0x08
00007fb1689e0053  jmp 0x00007FB1689DED93
00007fb1689e0058  sub rsp, 0x08
00007fb1689e005c  push rax
00007fb1689e005d  push rcx
00007fb1689e005e  push rdx
00007fb1689e005f  push rdi
00007fb1689e0060  push rsi
00007fb1689e0061  push r8
00007fb1689e0063  push r9
00007fb1689e0065  push r10
00007fb1689e0067  push r11
00007fb1689e0069  sub rsp, 0xF0
00007fb1689e0070  vmovaps [rsp], xmm0
00007fb1689e0075  vmovaps [rsp+0x10], xmm1
00007fb1689e007b  vmovaps [rsp+0x20], xmm2
00007fb1689e0081  vmovaps [rsp+0x30], xmm3
00007fb1689e0087  vmovaps [rsp+0x40], xmm4
00007fb1689e008d  vmovaps [rsp+0x50], xmm5
00007fb1689e0093  vmovaps [rsp+0x60], xmm7
00007fb1689e0099  vmovaps [rsp+0x70], xmm8
00007fb1689e009f  vmovaps [rsp+0x80], xmm9
00007fb1689e00a8  vmovaps [rsp+0x90], xmm10
00007fb1689e00b1  vmovaps [rsp+0xA0], xmm11
00007fb1689e00ba  vmovaps [rsp+0xB0], xmm12
00007fb1689e00c3  vmovaps [rsp+0xC0], xmm13
00007fb1689e00cc  vmovaps [rsp+0xD0], xmm14
00007fb1689e00d5  vmovaps [rsp+0xE0], xmm15
00007fb1689e00de  sub rsp, 0x30
00007fb1689e00e2  movaps [rsp], xmm6
00007fb1689e00e6  movaps [rsp+0x10], xmm12
00007fb1689e00ec  movaps [rsp+0x20], xmm11
00007fb1689e00f2  lea rdi, [rsp]
00007fb1689e00f6  mov esi, 0x00
00007fb1689e00fb  mov rax, 0x57CCFD419530
00007fb1689e0105  call rax
00007fb1689e0107  movaps xmm6, [rsp]
00007fb1689e010b  add rsp, 0x30
00007fb1689e010f  vmovaps xmm0, [rsp]
00007fb1689e0114  vmovaps xmm1, [rsp+0x10]
00007fb1689e011a  vmovaps xmm2, [rsp+0x20]
00007fb1689e0120  vmovaps xmm3, [rsp+0x30]
00007fb1689e0126  vmovaps xmm4, [rsp+0x40]
00007fb1689e012c  vmovaps xmm5, [rsp+0x50]
00007fb1689e0132  vmovaps xmm7, [rsp+0x60]
00007fb1689e0138  vmovaps xmm8, [rsp+0x70]
00007fb1689e013e  vmovaps xmm9, [rsp+0x80]
00007fb1689e0147  vmovaps xmm10, [rsp+0x90]
00007fb1689e0150  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0159  vmovaps xmm12, [rsp+0xB0]
00007fb1689e0162  vmovaps xmm13, [rsp+0xC0]
00007fb1689e016b  vmovaps xmm14, [rsp+0xD0]
00007fb1689e0174  vmovaps xmm15, [rsp+0xE0]
00007fb1689e017d  add rsp, 0xF0
00007fb1689e0184  pop r11
00007fb1689e0186  pop r10
00007fb1689e0188  pop r9
00007fb1689e018a  pop r8
00007fb1689e018c  pop rsi
00007fb1689e018d  pop rdi
00007fb1689e018e  pop rdx
00007fb1689e018f  pop rcx
00007fb1689e0190  pop rax
00007fb1689e0191  add rsp, 0x08
00007fb1689e0195  jmp 0x00007FB1689DEDB4
00007fb1689e019a  sub rsp, 0x08
00007fb1689e019e  push rax
00007fb1689e019f  push rcx
00007fb1689e01a0  push rdx
00007fb1689e01a1  push rdi
00007fb1689e01a2  push rsi
00007fb1689e01a3  push r8
00007fb1689e01a5  push r9
00007fb1689e01a7  push r10
00007fb1689e01a9  push r11
00007fb1689e01ab  sub rsp, 0xF0
00007fb1689e01b2  vmovaps [rsp], xmm0
00007fb1689e01b7  vmovaps [rsp+0x10], xmm1
00007fb1689e01bd  vmovaps [rsp+0x20], xmm2
00007fb1689e01c3  vmovaps [rsp+0x30], xmm4
00007fb1689e01c9  vmovaps [rsp+0x40], xmm5
00007fb1689e01cf  vmovaps [rsp+0x50], xmm6
00007fb1689e01d5  vmovaps [rsp+0x60], xmm7
00007fb1689e01db  vmovaps [rsp+0x70], xmm8
00007fb1689e01e1  vmovaps [rsp+0x80], xmm9
00007fb1689e01ea  vmovaps [rsp+0x90], xmm10
00007fb1689e01f3  vmovaps [rsp+0xA0], xmm11
00007fb1689e01fc  vmovaps [rsp+0xB0], xmm12
00007fb1689e0205  vmovaps [rsp+0xC0], xmm13
00007fb1689e020e  vmovaps [rsp+0xD0], xmm14
00007fb1689e0217  vmovaps [rsp+0xE0], xmm15
00007fb1689e0220  sub rsp, 0x30
00007fb1689e0224  movaps [rsp], xmm3
00007fb1689e0228  movaps [rsp+0x10], xmm5
00007fb1689e022d  movaps [rsp+0x20], xmm4
00007fb1689e0232  lea rdi, [rsp]
00007fb1689e0236  mov esi, 0x00
00007fb1689e023b  mov rax, 0x57CCFD419530
00007fb1689e0245  call rax
00007fb1689e0247  movaps xmm3, [rsp]
00007fb1689e024b  add rsp, 0x30
00007fb1689e024f  vmovaps xmm0, [rsp]
00007fb1689e0254  vmovaps xmm1, [rsp+0x10]
00007fb1689e025a  vmovaps xmm2, [rsp+0x20]
00007fb1689e0260  vmovaps xmm4, [rsp+0x30]
00007fb1689e0266  vmovaps xmm5, [rsp+0x40]
00007fb1689e026c  vmovaps xmm6, [rsp+0x50]
00007fb1689e0272  vmovaps xmm7, [rsp+0x60]
00007fb1689e0278  vmovaps xmm8, [rsp+0x70]
00007fb1689e027e  vmovaps xmm9, [rsp+0x80]
00007fb1689e0287  vmovaps xmm10, [rsp+0x90]
00007fb1689e0290  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0299  vmovaps xmm12, [rsp+0xB0]
00007fb1689e02a2  vmovaps xmm13, [rsp+0xC0]
00007fb1689e02ab  vmovaps xmm14, [rsp+0xD0]
00007fb1689e02b4  vmovaps xmm15, [rsp+0xE0]
00007fb1689e02bd  add rsp, 0xF0
00007fb1689e02c4  pop r11
00007fb1689e02c6  pop r10
00007fb1689e02c8  pop r9
00007fb1689e02ca  pop r8
00007fb1689e02cc  pop rsi
00007fb1689e02cd  pop rdi
00007fb1689e02ce  pop rdx
00007fb1689e02cf  pop rcx
00007fb1689e02d0  pop rax
00007fb1689e02d1  add rsp, 0x08
00007fb1689e02d5  jmp 0x00007FB1689DEE15
00007fb1689e02da  sub rsp, 0x08
00007fb1689e02de  push rax
00007fb1689e02df  push rcx
00007fb1689e02e0  push rdx
00007fb1689e02e1  push rdi
00007fb1689e02e2  push rsi
00007fb1689e02e3  push r8
00007fb1689e02e5  push r9
00007fb1689e02e7  push r10
00007fb1689e02e9  push r11
00007fb1689e02eb  sub rsp, 0xF0
00007fb1689e02f2  vmovaps [rsp], xmm0
00007fb1689e02f7  vmovaps [rsp+0x10], xmm1
00007fb1689e02fd  vmovaps [rsp+0x20], xmm2
00007fb1689e0303  vmovaps [rsp+0x30], xmm3
00007fb1689e0309  vmovaps [rsp+0x40], xmm4
00007fb1689e030f  vmovaps [rsp+0x50], xmm6
00007fb1689e0315  vmovaps [rsp+0x60], xmm7
00007fb1689e031b  vmovaps [rsp+0x70], xmm8
00007fb1689e0321  vmovaps [rsp+0x80], xmm9
00007fb1689e032a  vmovaps [rsp+0x90], xmm10
00007fb1689e0333  vmovaps [rsp+0xA0], xmm11
00007fb1689e033c  vmovaps [rsp+0xB0], xmm12
00007fb1689e0345  vmovaps [rsp+0xC0], xmm13
00007fb1689e034e  vmovaps [rsp+0xD0], xmm14
00007fb1689e0357  vmovaps [rsp+0xE0], xmm15
00007fb1689e0360  sub rsp, 0x30
00007fb1689e0364  movaps [rsp], xmm5
00007fb1689e0368  movaps [rsp+0x10], xmm8
00007fb1689e036e  movaps [rsp+0x20], xmm15
00007fb1689e0374  lea rdi, [rsp]
00007fb1689e0378  mov esi, 0x00
00007fb1689e037d  mov rax, 0x57CCFD419530
00007fb1689e0387  call rax
00007fb1689e0389  movaps xmm5, [rsp]
00007fb1689e038d  add rsp, 0x30
00007fb1689e0391  vmovaps xmm0, [rsp]
00007fb1689e0396  vmovaps xmm1, [rsp+0x10]
00007fb1689e039c  vmovaps xmm2, [rsp+0x20]
00007fb1689e03a2  vmovaps xmm3, [rsp+0x30]
00007fb1689e03a8  vmovaps xmm4, [rsp+0x40]
00007fb1689e03ae  vmovaps xmm6, [rsp+0x50]
00007fb1689e03b4  vmovaps xmm7, [rsp+0x60]
00007fb1689e03ba  vmovaps xmm8, [rsp+0x70]
00007fb1689e03c0  vmovaps xmm9, [rsp+0x80]
00007fb1689e03c9  vmovaps xmm10, [rsp+0x90]
00007fb1689e03d2  vmovaps xmm11, [rsp+0xA0]
00007fb1689e03db  vmovaps xmm12, [rsp+0xB0]
00007fb1689e03e4  vmovaps xmm13, [rsp+0xC0]
00007fb1689e03ed  vmovaps xmm14, [rsp+0xD0]
00007fb1689e03f6  vmovaps xmm15, [rsp+0xE0]
00007fb1689e03ff  add rsp, 0xF0
00007fb1689e0406  pop r11
00007fb1689e0408  pop r10
00007fb1689e040a  pop r9
00007fb1689e040c  pop r8
00007fb1689e040e  pop rsi
00007fb1689e040f  pop rdi
00007fb1689e0410  pop rdx
00007fb1689e0411  pop rcx
00007fb1689e0412  pop rax
00007fb1689e0413  add rsp, 0x08
00007fb1689e0417  jmp 0x00007FB1689DEE53
00007fb1689e041c  sub rsp, 0x08
00007fb1689e0420  push rax
00007fb1689e0421  push rcx
00007fb1689e0422  push rdx
00007fb1689e0423  push rdi
00007fb1689e0424  push rsi
00007fb1689e0425  push r8
00007fb1689e0427  push r9
00007fb1689e0429  push r10
00007fb1689e042b  push r11
00007fb1689e042d  sub rsp, 0xF0
00007fb1689e0434  vmovaps [rsp], xmm0
00007fb1689e0439  vmovaps [rsp+0x10], xmm1
00007fb1689e043f  vmovaps [rsp+0x20], xmm2
00007fb1689e0445  vmovaps [rsp+0x30], xmm3
00007fb1689e044b  vmovaps [rsp+0x40], xmm5
00007fb1689e0451  vmovaps [rsp+0x50], xmm6
00007fb1689e0457  vmovaps [rsp+0x60], xmm7
00007fb1689e045d  vmovaps [rsp+0x70], xmm8
00007fb1689e0463  vmovaps [rsp+0x80], xmm9
00007fb1689e046c  vmovaps [rsp+0x90], xmm10
00007fb1689e0475  vmovaps [rsp+0xA0], xmm11
00007fb1689e047e  vmovaps [rsp+0xB0], xmm12
00007fb1689e0487  vmovaps [rsp+0xC0], xmm13
00007fb1689e0490  vmovaps [rsp+0xD0], xmm14
00007fb1689e0499  vmovaps [rsp+0xE0], xmm15
00007fb1689e04a2  sub rsp, 0x30
00007fb1689e04a6  movaps [rsp], xmm4
00007fb1689e04aa  movaps [rsp+0x10], xmm9
00007fb1689e04b0  movaps [rsp+0x20], xmm8
00007fb1689e04b6  lea rdi, [rsp]
00007fb1689e04ba  mov esi, 0x00
00007fb1689e04bf  mov rax, 0x57CCFD419530
00007fb1689e04c9  call rax
00007fb1689e04cb  movaps xmm4, [rsp]
00007fb1689e04cf  add rsp, 0x30
00007fb1689e04d3  vmovaps xmm0, [rsp]
00007fb1689e04d8  vmovaps xmm1, [rsp+0x10]
00007fb1689e04de  vmovaps xmm2, [rsp+0x20]
00007fb1689e04e4  vmovaps xmm3, [rsp+0x30]
00007fb1689e04ea  vmovaps xmm5, [rsp+0x40]
00007fb1689e04f0  vmovaps xmm6, [rsp+0x50]
00007fb1689e04f6  vmovaps xmm7, [rsp+0x60]
00007fb1689e04fc  vmovaps xmm8, [rsp+0x70]
00007fb1689e0502  vmovaps xmm9, [rsp+0x80]
00007fb1689e050b  vmovaps xmm10, [rsp+0x90]
00007fb1689e0514  vmovaps xmm11, [rsp+0xA0]
00007fb1689e051d  vmovaps xmm12, [rsp+0xB0]
00007fb1689e0526  vmovaps xmm13, [rsp+0xC0]
00007fb1689e052f  vmovaps xmm14, [rsp+0xD0]
00007fb1689e0538  vmovaps xmm15, [rsp+0xE0]
00007fb1689e0541  add rsp, 0xF0
00007fb1689e0548  pop r11
00007fb1689e054a  pop r10
00007fb1689e054c  pop r9
00007fb1689e054e  pop r8
00007fb1689e0550  pop rsi
00007fb1689e0551  pop rdi
00007fb1689e0552  pop rdx
00007fb1689e0553  pop rcx
00007fb1689e0554  pop rax
00007fb1689e0555  add rsp, 0x08
00007fb1689e0559  jmp 0x00007FB1689DEE74
00007fb1689e055e  sub rsp, 0x08
00007fb1689e0562  push rax
00007fb1689e0563  push rcx
00007fb1689e0564  push rdx
00007fb1689e0565  push rdi
00007fb1689e0566  push rsi
00007fb1689e0567  push r8
00007fb1689e0569  push r9
00007fb1689e056b  push r10
00007fb1689e056d  push r11
00007fb1689e056f  sub rsp, 0xF0
00007fb1689e0576  vmovaps [rsp], xmm0
00007fb1689e057b  vmovaps [rsp+0x10], xmm1
00007fb1689e0581  vmovaps [rsp+0x20], xmm2
00007fb1689e0587  vmovaps [rsp+0x30], xmm3
00007fb1689e058d  vmovaps [rsp+0x40], xmm4
00007fb1689e0593  vmovaps [rsp+0x50], xmm5
00007fb1689e0599  vmovaps [rsp+0x60], xmm6
00007fb1689e059f  vmovaps [rsp+0x70], xmm7
00007fb1689e05a5  vmovaps [rsp+0x80], xmm8
00007fb1689e05ae  vmovaps [rsp+0x90], xmm10
00007fb1689e05b7  vmovaps [rsp+0xA0], xmm11
00007fb1689e05c0  vmovaps [rsp+0xB0], xmm12
00007fb1689e05c9  vmovaps [rsp+0xC0], xmm13
00007fb1689e05d2  vmovaps [rsp+0xD0], xmm14
00007fb1689e05db  vmovaps [rsp+0xE0], xmm15
00007fb1689e05e4  sub rsp, 0x30
00007fb1689e05e8  movaps [rsp], xmm9
00007fb1689e05ed  movaps [rsp+0x10], xmm10
00007fb1689e05f3  movaps [rsp+0x20], xmm8
00007fb1689e05f9  lea rdi, [rsp]
00007fb1689e05fd  mov esi, 0x00
00007fb1689e0602  mov rax, 0x57CCFD419530
00007fb1689e060c  call rax
00007fb1689e060e  movaps xmm9, [rsp]
00007fb1689e0613  add rsp, 0x30
00007fb1689e0617  vmovaps xmm0, [rsp]
00007fb1689e061c  vmovaps xmm1, [rsp+0x10]
00007fb1689e0622  vmovaps xmm2, [rsp+0x20]
00007fb1689e0628  vmovaps xmm3, [rsp+0x30]
00007fb1689e062e  vmovaps xmm4, [rsp+0x40]
00007fb1689e0634  vmovaps xmm5, [rsp+0x50]
00007fb1689e063a  vmovaps xmm6, [rsp+0x60]
00007fb1689e0640  vmovaps xmm7, [rsp+0x70]
00007fb1689e0646  vmovaps xmm8, [rsp+0x80]
00007fb1689e064f  vmovaps xmm10, [rsp+0x90]
00007fb1689e0658  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0661  vmovaps xmm12, [rsp+0xB0]
00007fb1689e066a  vmovaps xmm13, [rsp+0xC0]
00007fb1689e0673  vmovaps xmm14, [rsp+0xD0]
00007fb1689e067c  vmovaps xmm15, [rsp+0xE0]
00007fb1689e0685  add rsp, 0xF0
00007fb1689e068c  pop r11
00007fb1689e068e  pop r10
00007fb1689e0690  pop r9
00007fb1689e0692  pop r8
00007fb1689e0694  pop rsi
00007fb1689e0695  pop rdi
00007fb1689e0696  pop rdx
00007fb1689e0697  pop rcx
00007fb1689e0698  pop rax
00007fb1689e0699  add rsp, 0x08
00007fb1689e069d  jmp 0x00007FB1689DEE8E
00007fb1689e06a2  call 0x00007FB1688B52F0
00007fb1689e06a7  jmp 0x00007FB1689DEFA8
00007fb1689e06ac  call 0x00007FB1688B52F0
00007fb1689e06b1  jmp 0x00007FB1689DEFBE
00007fb1689e06b6  sub rsp, 0x08
00007fb1689e06ba  push rax
00007fb1689e06bb  push rcx
00007fb1689e06bc  push rdx
00007fb1689e06bd  push rdi
00007fb1689e06be  push rsi
00007fb1689e06bf  push r8
00007fb1689e06c1  push r9
00007fb1689e06c3  push r10
00007fb1689e06c5  push r11
00007fb1689e06c7  sub rsp, 0xF0
00007fb1689e06ce  vmovaps [rsp], xmm0
00007fb1689e06d3  vmovaps [rsp+0x10], xmm2
00007fb1689e06d9  vmovaps [rsp+0x20], xmm3
00007fb1689e06df  vmovaps [rsp+0x30], xmm4
00007fb1689e06e5  vmovaps [rsp+0x40], xmm5
00007fb1689e06eb  vmovaps [rsp+0x50], xmm6
00007fb1689e06f1  vmovaps [rsp+0x60], xmm7
00007fb1689e06f7  vmovaps [rsp+0x70], xmm8
00007fb1689e06fd  vmovaps [rsp+0x80], xmm9
00007fb1689e0706  vmovaps [rsp+0x90], xmm10
00007fb1689e070f  vmovaps [rsp+0xA0], xmm11
00007fb1689e0718  vmovaps [rsp+0xB0], xmm12
00007fb1689e0721  vmovaps [rsp+0xC0], xmm13
00007fb1689e072a  vmovaps [rsp+0xD0], xmm14
00007fb1689e0733  vmovaps [rsp+0xE0], xmm15
00007fb1689e073c  sub rsp, 0x30
00007fb1689e0740  movaps [rsp], xmm1
00007fb1689e0744  movaps [rsp+0x10], xmm6
00007fb1689e0749  movaps [rsp+0x20], xmm15
00007fb1689e074f  lea rdi, [rsp]
00007fb1689e0753  mov esi, 0x00
00007fb1689e0758  mov rax, 0x57CCFD419530
00007fb1689e0762  call rax
00007fb1689e0764  movaps xmm1, [rsp]
00007fb1689e0768  add rsp, 0x30
00007fb1689e076c  vmovaps xmm0, [rsp]
00007fb1689e0771  vmovaps xmm2, [rsp+0x10]
00007fb1689e0777  vmovaps xmm3, [rsp+0x20]
00007fb1689e077d  vmovaps xmm4, [rsp+0x30]
00007fb1689e0783  vmovaps xmm5, [rsp+0x40]
00007fb1689e0789  vmovaps xmm6, [rsp+0x50]
00007fb1689e078f  vmovaps xmm7, [rsp+0x60]
00007fb1689e0795  vmovaps xmm8, [rsp+0x70]
00007fb1689e079b  vmovaps xmm9, [rsp+0x80]
00007fb1689e07a4  vmovaps xmm10, [rsp+0x90]
00007fb1689e07ad  vmovaps xmm11, [rsp+0xA0]
00007fb1689e07b6  vmovaps xmm12, [rsp+0xB0]
00007fb1689e07bf  vmovaps xmm13, [rsp+0xC0]
00007fb1689e07c8  vmovaps xmm14, [rsp+0xD0]
00007fb1689e07d1  vmovaps xmm15, [rsp+0xE0]
00007fb1689e07da  add rsp, 0xF0
00007fb1689e07e1  pop r11
00007fb1689e07e3  pop r10
00007fb1689e07e5  pop r9
00007fb1689e07e7  pop r8
00007fb1689e07e9  pop rsi
00007fb1689e07ea  pop rdi
00007fb1689e07eb  pop rdx
00007fb1689e07ec  pop rcx
00007fb1689e07ed  pop rax
00007fb1689e07ee  add rsp, 0x08
00007fb1689e07f2  jmp 0x00007FB1689DEFFB
00007fb1689e07f7  call 0x00007FB1688C4620
00007fb1689e07fc  jmp 0x00007FB1689DF008
00007fb1689e0801  sub rsp, 0x08
00007fb1689e0805  push rax
00007fb1689e0806  push rcx
00007fb1689e0807  push rdx
00007fb1689e0808  push rdi
00007fb1689e0809  push rsi
00007fb1689e080a  push r8
00007fb1689e080c  push r9
00007fb1689e080e  push r10
00007fb1689e0810  push r11
00007fb1689e0812  sub rsp, 0xF0
00007fb1689e0819  vmovaps [rsp], xmm0
00007fb1689e081e  vmovaps [rsp+0x10], xmm1
00007fb1689e0824  vmovaps [rsp+0x20], xmm2
00007fb1689e082a  vmovaps [rsp+0x30], xmm3
00007fb1689e0830  vmovaps [rsp+0x40], xmm4
00007fb1689e0836  vmovaps [rsp+0x50], xmm5
00007fb1689e083c  vmovaps [rsp+0x60], xmm6
00007fb1689e0842  vmovaps [rsp+0x70], xmm7
00007fb1689e0848  vmovaps [rsp+0x80], xmm8
00007fb1689e0851  vmovaps [rsp+0x90], xmm9
00007fb1689e085a  vmovaps [rsp+0xA0], xmm10
00007fb1689e0863  vmovaps [rsp+0xB0], xmm11
00007fb1689e086c  vmovaps [rsp+0xC0], xmm12
00007fb1689e0875  vmovaps [rsp+0xD0], xmm13
00007fb1689e087e  vmovaps [rsp+0xE0], xmm15
00007fb1689e0887  sub rsp, 0x30
00007fb1689e088b  movaps [rsp], xmm14
00007fb1689e0890  movaps [rsp+0x10], xmm4
00007fb1689e0895  movaps [rsp+0x20], xmm3
00007fb1689e089a  lea rdi, [rsp]
00007fb1689e089e  mov esi, 0x00
00007fb1689e08a3  mov rax, 0x57CCFD419530
00007fb1689e08ad  call rax
00007fb1689e08af  movaps xmm14, [rsp]
00007fb1689e08b4  add rsp, 0x30
00007fb1689e08b8  vmovaps xmm0, [rsp]
00007fb1689e08bd  vmovaps xmm1, [rsp+0x10]
00007fb1689e08c3  vmovaps xmm2, [rsp+0x20]
00007fb1689e08c9  vmovaps xmm3, [rsp+0x30]
00007fb1689e08cf  vmovaps xmm4, [rsp+0x40]
00007fb1689e08d5  vmovaps xmm5, [rsp+0x50]
00007fb1689e08db  vmovaps xmm6, [rsp+0x60]
00007fb1689e08e1  vmovaps xmm7, [rsp+0x70]
00007fb1689e08e7  vmovaps xmm8, [rsp+0x80]
00007fb1689e08f0  vmovaps xmm9, [rsp+0x90]
00007fb1689e08f9  vmovaps xmm10, [rsp+0xA0]
00007fb1689e0902  vmovaps xmm11, [rsp+0xB0]
00007fb1689e090b  vmovaps xmm12, [rsp+0xC0]
00007fb1689e0914  vmovaps xmm13, [rsp+0xD0]
00007fb1689e091d  vmovaps xmm15, [rsp+0xE0]
00007fb1689e0926  add rsp, 0xF0
00007fb1689e092d  pop r11
00007fb1689e092f  pop r10
00007fb1689e0931  pop r9
00007fb1689e0933  pop r8
00007fb1689e0935  pop rsi
00007fb1689e0936  pop rdi
00007fb1689e0937  pop rdx
00007fb1689e0938  pop rcx
00007fb1689e0939  pop rax
00007fb1689e093a  add rsp, 0x08
00007fb1689e093e  jmp 0x00007FB1689DF022
00007fb1689e0943  sub rsp, 0x08
00007fb1689e0947  push rax
00007fb1689e0948  push rcx
00007fb1689e0949  push rdx
00007fb1689e094a  push rdi
00007fb1689e094b  push rsi
00007fb1689e094c  push r8
00007fb1689e094e  push r9
00007fb1689e0950  push r10
00007fb1689e0952  push r11
00007fb1689e0954  sub rsp, 0xF0
00007fb1689e095b  vmovaps [rsp], xmm0
00007fb1689e0960  vmovaps [rsp+0x10], xmm1
00007fb1689e0966  vmovaps [rsp+0x20], xmm2
00007fb1689e096c  vmovaps [rsp+0x30], xmm3
00007fb1689e0972  vmovaps [rsp+0x40], xmm4
00007fb1689e0978  vmovaps [rsp+0x50], xmm5
00007fb1689e097e  vmovaps [rsp+0x60], xmm7
00007fb1689e0984  vmovaps [rsp+0x70], xmm8
00007fb1689e098a  vmovaps [rsp+0x80], xmm9
00007fb1689e0993  vmovaps [rsp+0x90], xmm10
00007fb1689e099c  vmovaps [rsp+0xA0], xmm11
00007fb1689e09a5  vmovaps [rsp+0xB0], xmm12
00007fb1689e09ae  vmovaps [rsp+0xC0], xmm13
00007fb1689e09b7  vmovaps [rsp+0xD0], xmm14
00007fb1689e09c0  vmovaps [rsp+0xE0], xmm15
00007fb1689e09c9  sub rsp, 0x30
00007fb1689e09cd  movaps [rsp], xmm6
00007fb1689e09d1  movaps [rsp+0x10], xmm9
00007fb1689e09d7  movaps [rsp+0x20], xmm7
00007fb1689e09dc  lea rdi, [rsp]
00007fb1689e09e0  mov esi, 0x00
00007fb1689e09e5  mov rax, 0x57CCFD419530
00007fb1689e09ef  call rax
00007fb1689e09f1  movaps xmm6, [rsp]
00007fb1689e09f5  add rsp, 0x30
00007fb1689e09f9  vmovaps xmm0, [rsp]
00007fb1689e09fe  vmovaps xmm1, [rsp+0x10]
00007fb1689e0a04  vmovaps xmm2, [rsp+0x20]
00007fb1689e0a0a  vmovaps xmm3, [rsp+0x30]
00007fb1689e0a10  vmovaps xmm4, [rsp+0x40]
00007fb1689e0a16  vmovaps xmm5, [rsp+0x50]
00007fb1689e0a1c  vmovaps xmm7, [rsp+0x60]
00007fb1689e0a22  vmovaps xmm8, [rsp+0x70]
00007fb1689e0a28  vmovaps xmm9, [rsp+0x80]
00007fb1689e0a31  vmovaps xmm10, [rsp+0x90]
00007fb1689e0a3a  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0a43  vmovaps xmm12, [rsp+0xB0]
00007fb1689e0a4c  vmovaps xmm13, [rsp+0xC0]
00007fb1689e0a55  vmovaps xmm14, [rsp+0xD0]
00007fb1689e0a5e  vmovaps xmm15, [rsp+0xE0]
00007fb1689e0a67  add rsp, 0xF0
00007fb1689e0a6e  pop r11
00007fb1689e0a70  pop r10
00007fb1689e0a72  pop r9
00007fb1689e0a74  pop r8
00007fb1689e0a76  pop rsi
00007fb1689e0a77  pop rdi
00007fb1689e0a78  pop rdx
00007fb1689e0a79  pop rcx
00007fb1689e0a7a  pop rax
00007fb1689e0a7b  add rsp, 0x08
00007fb1689e0a7f  jmp 0x00007FB1689DF03A
00007fb1689e0a84  sub rsp, 0x08
00007fb1689e0a88  push rax
00007fb1689e0a89  push rcx
00007fb1689e0a8a  push rdx
00007fb1689e0a8b  push rdi
00007fb1689e0a8c  push rsi
00007fb1689e0a8d  push r8
00007fb1689e0a8f  push r9
00007fb1689e0a91  push r10
00007fb1689e0a93  push r11
00007fb1689e0a95  sub rsp, 0xF0
00007fb1689e0a9c  vmovaps [rsp], xmm0
00007fb1689e0aa1  vmovaps [rsp+0x10], xmm1
00007fb1689e0aa7  vmovaps [rsp+0x20], xmm2
00007fb1689e0aad  vmovaps [rsp+0x30], xmm3
00007fb1689e0ab3  vmovaps [rsp+0x40], xmm4
00007fb1689e0ab9  vmovaps [rsp+0x50], xmm5
00007fb1689e0abf  vmovaps [rsp+0x60], xmm6
00007fb1689e0ac5  vmovaps [rsp+0x70], xmm8
00007fb1689e0acb  vmovaps [rsp+0x80], xmm9
00007fb1689e0ad4  vmovaps [rsp+0x90], xmm10
00007fb1689e0add  vmovaps [rsp+0xA0], xmm11
00007fb1689e0ae6  vmovaps [rsp+0xB0], xmm12
00007fb1689e0aef  vmovaps [rsp+0xC0], xmm13
00007fb1689e0af8  vmovaps [rsp+0xD0], xmm14
00007fb1689e0b01  vmovaps [rsp+0xE0], xmm15
00007fb1689e0b0a  sub rsp, 0x30
00007fb1689e0b0e  movaps [rsp], xmm7
00007fb1689e0b12  movaps [rsp+0x10], xmm4
00007fb1689e0b17  movaps [rsp+0x20], xmm9
00007fb1689e0b1d  lea rdi, [rsp]
00007fb1689e0b21  mov esi, 0x00
00007fb1689e0b26  mov rax, 0x57CCFD419530
00007fb1689e0b30  call rax
00007fb1689e0b32  movaps xmm7, [rsp]
00007fb1689e0b36  add rsp, 0x30
00007fb1689e0b3a  vmovaps xmm0, [rsp]
00007fb1689e0b3f  vmovaps xmm1, [rsp+0x10]
00007fb1689e0b45  vmovaps xmm2, [rsp+0x20]
00007fb1689e0b4b  vmovaps xmm3, [rsp+0x30]
00007fb1689e0b51  vmovaps xmm4, [rsp+0x40]
00007fb1689e0b57  vmovaps xmm5, [rsp+0x50]
00007fb1689e0b5d  vmovaps xmm6, [rsp+0x60]
00007fb1689e0b63  vmovaps xmm8, [rsp+0x70]
00007fb1689e0b69  vmovaps xmm9, [rsp+0x80]
00007fb1689e0b72  vmovaps xmm10, [rsp+0x90]
00007fb1689e0b7b  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0b84  vmovaps xmm12, [rsp+0xB0]
00007fb1689e0b8d  vmovaps xmm13, [rsp+0xC0]
00007fb1689e0b96  vmovaps xmm14, [rsp+0xD0]
00007fb1689e0b9f  vmovaps xmm15, [rsp+0xE0]
00007fb1689e0ba8  add rsp, 0xF0
00007fb1689e0baf  pop r11
00007fb1689e0bb1  pop r10
00007fb1689e0bb3  pop r9
00007fb1689e0bb5  pop r8
00007fb1689e0bb7  pop rsi
00007fb1689e0bb8  pop rdi
00007fb1689e0bb9  pop rdx
00007fb1689e0bba  pop rcx
00007fb1689e0bbb  pop rax
00007fb1689e0bbc  add rsp, 0x08
00007fb1689e0bc0  jmp 0x00007FB1689DF067
00007fb1689e0bc5  sub rsp, 0x08
00007fb1689e0bc9  push rax
00007fb1689e0bca  push rcx
00007fb1689e0bcb  push rdx
00007fb1689e0bcc  push rdi
00007fb1689e0bcd  push rsi
00007fb1689e0bce  push r8
00007fb1689e0bd0  push r9
00007fb1689e0bd2  push r10
00007fb1689e0bd4  push r11
00007fb1689e0bd6  sub rsp, 0xF0
00007fb1689e0bdd  vmovaps [rsp], xmm0
00007fb1689e0be2  vmovaps [rsp+0x10], xmm1
00007fb1689e0be8  vmovaps [rsp+0x20], xmm2
00007fb1689e0bee  vmovaps [rsp+0x30], xmm3
00007fb1689e0bf4  vmovaps [rsp+0x40], xmm5
00007fb1689e0bfa  vmovaps [rsp+0x50], xmm6
00007fb1689e0c00  vmovaps [rsp+0x60], xmm7
00007fb1689e0c06  vmovaps [rsp+0x70], xmm8
00007fb1689e0c0c  vmovaps [rsp+0x80], xmm9
00007fb1689e0c15  vmovaps [rsp+0x90], xmm10
00007fb1689e0c1e  vmovaps [rsp+0xA0], xmm11
00007fb1689e0c27  vmovaps [rsp+0xB0], xmm12
00007fb1689e0c30  vmovaps [rsp+0xC0], xmm13
00007fb1689e0c39  vmovaps [rsp+0xD0], xmm14
00007fb1689e0c42  vmovaps [rsp+0xE0], xmm15
00007fb1689e0c4b  sub rsp, 0x30
00007fb1689e0c4f  movaps [rsp], xmm4
00007fb1689e0c53  movaps [rsp+0x10], xmm15
00007fb1689e0c59  movaps [rsp+0x20], xmm9
00007fb1689e0c5f  lea rdi, [rsp]
00007fb1689e0c63  mov esi, 0x00
00007fb1689e0c68  mov rax, 0x57CCFD419530
00007fb1689e0c72  call rax
00007fb1689e0c74  movaps xmm4, [rsp]
00007fb1689e0c78  add rsp, 0x30
00007fb1689e0c7c  vmovaps xmm0, [rsp]
00007fb1689e0c81  vmovaps xmm1, [rsp+0x10]
00007fb1689e0c87  vmovaps xmm2, [rsp+0x20]
00007fb1689e0c8d  vmovaps xmm3, [rsp+0x30]
00007fb1689e0c93  vmovaps xmm5, [rsp+0x40]
00007fb1689e0c99  vmovaps xmm6, [rsp+0x50]
00007fb1689e0c9f  vmovaps xmm7, [rsp+0x60]
00007fb1689e0ca5  vmovaps xmm8, [rsp+0x70]
00007fb1689e0cab  vmovaps xmm9, [rsp+0x80]
00007fb1689e0cb4  vmovaps xmm10, [rsp+0x90]
00007fb1689e0cbd  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0cc6  vmovaps xmm12, [rsp+0xB0]
00007fb1689e0ccf  vmovaps xmm13, [rsp+0xC0]
00007fb1689e0cd8  vmovaps xmm14, [rsp+0xD0]
00007fb1689e0ce1  vmovaps xmm15, [rsp+0xE0]
00007fb1689e0cea  add rsp, 0xF0
00007fb1689e0cf1  pop r11
00007fb1689e0cf3  pop r10
00007fb1689e0cf5  pop r9
00007fb1689e0cf7  pop r8
00007fb1689e0cf9  pop rsi
00007fb1689e0cfa  pop rdi
00007fb1689e0cfb  pop rdx
00007fb1689e0cfc  pop rcx
00007fb1689e0cfd  pop rax
00007fb1689e0cfe  add rsp, 0x08
00007fb1689e0d02  jmp 0x00007FB1689DF08C
00007fb1689e0d07  call 0x00007FB1688C4620
00007fb1689e0d0c  jmp 0x00007FB1689DF099
00007fb1689e0d11  sub rsp, 0x08
00007fb1689e0d15  push rax
00007fb1689e0d16  push rcx
00007fb1689e0d17  push rdx
00007fb1689e0d18  push rdi
00007fb1689e0d19  push rsi
00007fb1689e0d1a  push r8
00007fb1689e0d1c  push r9
00007fb1689e0d1e  push r10
00007fb1689e0d20  push r11
00007fb1689e0d22  sub rsp, 0xF0
00007fb1689e0d29  vmovaps [rsp], xmm0
00007fb1689e0d2e  vmovaps [rsp+0x10], xmm1
00007fb1689e0d34  vmovaps [rsp+0x20], xmm2
00007fb1689e0d3a  vmovaps [rsp+0x30], xmm4
00007fb1689e0d40  vmovaps [rsp+0x40], xmm5
00007fb1689e0d46  vmovaps [rsp+0x50], xmm6
00007fb1689e0d4c  vmovaps [rsp+0x60], xmm7
00007fb1689e0d52  vmovaps [rsp+0x70], xmm8
00007fb1689e0d58  vmovaps [rsp+0x80], xmm9
00007fb1689e0d61  vmovaps [rsp+0x90], xmm10
00007fb1689e0d6a  vmovaps [rsp+0xA0], xmm11
00007fb1689e0d73  vmovaps [rsp+0xB0], xmm12
00007fb1689e0d7c  vmovaps [rsp+0xC0], xmm13
00007fb1689e0d85  vmovaps [rsp+0xD0], xmm14
00007fb1689e0d8e  vmovaps [rsp+0xE0], xmm15
00007fb1689e0d97  sub rsp, 0x30
00007fb1689e0d9b  movaps [rsp], xmm3
00007fb1689e0d9f  movaps [rsp+0x10], xmm1
00007fb1689e0da4  movaps [rsp+0x20], xmm9
00007fb1689e0daa  lea rdi, [rsp]
00007fb1689e0dae  mov esi, 0x00
00007fb1689e0db3  mov rax, 0x57CCFD419530
00007fb1689e0dbd  call rax
00007fb1689e0dbf  movaps xmm3, [rsp]
00007fb1689e0dc3  add rsp, 0x30
00007fb1689e0dc7  vmovaps xmm0, [rsp]
00007fb1689e0dcc  vmovaps xmm1, [rsp+0x10]
00007fb1689e0dd2  vmovaps xmm2, [rsp+0x20]
00007fb1689e0dd8  vmovaps xmm4, [rsp+0x30]
00007fb1689e0dde  vmovaps xmm5, [rsp+0x40]
00007fb1689e0de4  vmovaps xmm6, [rsp+0x50]
00007fb1689e0dea  vmovaps xmm7, [rsp+0x60]
00007fb1689e0df0  vmovaps xmm8, [rsp+0x70]
00007fb1689e0df6  vmovaps xmm9, [rsp+0x80]
00007fb1689e0dff  vmovaps xmm10, [rsp+0x90]
00007fb1689e0e08  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0e11  vmovaps xmm12, [rsp+0xB0]
00007fb1689e0e1a  vmovaps xmm13, [rsp+0xC0]
00007fb1689e0e23  vmovaps xmm14, [rsp+0xD0]
00007fb1689e0e2c  vmovaps xmm15, [rsp+0xE0]
00007fb1689e0e35  add rsp, 0xF0
00007fb1689e0e3c  pop r11
00007fb1689e0e3e  pop r10
00007fb1689e0e40  pop r9
00007fb1689e0e42  pop r8
00007fb1689e0e44  pop rsi
00007fb1689e0e45  pop rdi
00007fb1689e0e46  pop rdx
00007fb1689e0e47  pop rcx
00007fb1689e0e48  pop rax
00007fb1689e0e49  add rsp, 0x08
00007fb1689e0e4d  jmp 0x00007FB1689DF0D6
00007fb1689e0e52  sub rsp, 0x08
00007fb1689e0e56  push rax
00007fb1689e0e57  push rcx
00007fb1689e0e58  push rdx
00007fb1689e0e59  push rdi
00007fb1689e0e5a  push rsi
00007fb1689e0e5b  push r8
00007fb1689e0e5d  push r9
00007fb1689e0e5f  push r10
00007fb1689e0e61  push r11
00007fb1689e0e63  sub rsp, 0xF0
00007fb1689e0e6a  vmovaps [rsp], xmm0
00007fb1689e0e6f  vmovaps [rsp+0x10], xmm2
00007fb1689e0e75  vmovaps [rsp+0x20], xmm3
00007fb1689e0e7b  vmovaps [rsp+0x30], xmm4
00007fb1689e0e81  vmovaps [rsp+0x40], xmm5
00007fb1689e0e87  vmovaps [rsp+0x50], xmm6
00007fb1689e0e8d  vmovaps [rsp+0x60], xmm7
00007fb1689e0e93  vmovaps [rsp+0x70], xmm8
00007fb1689e0e99  vmovaps [rsp+0x80], xmm9
00007fb1689e0ea2  vmovaps [rsp+0x90], xmm10
00007fb1689e0eab  vmovaps [rsp+0xA0], xmm11
00007fb1689e0eb4  vmovaps [rsp+0xB0], xmm12
00007fb1689e0ebd  vmovaps [rsp+0xC0], xmm13
00007fb1689e0ec6  vmovaps [rsp+0xD0], xmm14
00007fb1689e0ecf  vmovaps [rsp+0xE0], xmm15
00007fb1689e0ed8  sub rsp, 0x30
00007fb1689e0edc  movaps [rsp], xmm1
00007fb1689e0ee0  movaps [rsp+0x10], xmm15
00007fb1689e0ee6  movaps [rsp+0x20], xmm9
00007fb1689e0eec  lea rdi, [rsp]
00007fb1689e0ef0  mov esi, 0x00
00007fb1689e0ef5  mov rax, 0x57CCFD419530
00007fb1689e0eff  call rax
00007fb1689e0f01  movaps xmm1, [rsp]
00007fb1689e0f05  add rsp, 0x30
00007fb1689e0f09  vmovaps xmm0, [rsp]
00007fb1689e0f0e  vmovaps xmm2, [rsp+0x10]
00007fb1689e0f14  vmovaps xmm3, [rsp+0x20]
00007fb1689e0f1a  vmovaps xmm4, [rsp+0x30]
00007fb1689e0f20  vmovaps xmm5, [rsp+0x40]
00007fb1689e0f26  vmovaps xmm6, [rsp+0x50]
00007fb1689e0f2c  vmovaps xmm7, [rsp+0x60]
00007fb1689e0f32  vmovaps xmm8, [rsp+0x70]
00007fb1689e0f38  vmovaps xmm9, [rsp+0x80]
00007fb1689e0f41  vmovaps xmm10, [rsp+0x90]
00007fb1689e0f4a  vmovaps xmm11, [rsp+0xA0]
00007fb1689e0f53  vmovaps xmm12, [rsp+0xB0]
00007fb1689e0f5c  vmovaps xmm13, [rsp+0xC0]
00007fb1689e0f65  vmovaps xmm14, [rsp+0xD0]
00007fb1689e0f6e  vmovaps xmm15, [rsp+0xE0]
00007fb1689e0f77  add rsp, 0xF0
00007fb1689e0f7e  pop r11
00007fb1689e0f80  pop r10
00007fb1689e0f82  pop r9
00007fb1689e0f84  pop r8
00007fb1689e0f86  pop rsi
00007fb1689e0f87  pop rdi
00007fb1689e0f88  pop rdx
00007fb1689e0f89  pop rcx
00007fb1689e0f8a  pop rax
00007fb1689e0f8b  add rsp, 0x08
00007fb1689e0f8f  jmp 0x00007FB1689DF15E
00007fb1689e0f94  call 0x00007FB1688C4620
00007fb1689e0f99  jmp 0x00007FB1689DF16B
00007fb1689e0f9e  sub rsp, 0x08
00007fb1689e0fa2  push rax
00007fb1689e0fa3  push rcx
00007fb1689e0fa4  push rdx
00007fb1689e0fa5  push rdi
00007fb1689e0fa6  push rsi
00007fb1689e0fa7  push r8
00007fb1689e0fa9  push r9
00007fb1689e0fab  push r10
00007fb1689e0fad  push r11
00007fb1689e0faf  sub rsp, 0xF0
00007fb1689e0fb6  vmovaps [rsp], xmm0
00007fb1689e0fbb  vmovaps [rsp+0x10], xmm2
00007fb1689e0fc1  vmovaps [rsp+0x20], xmm3
00007fb1689e0fc7  vmovaps [rsp+0x30], xmm4
00007fb1689e0fcd  vmovaps [rsp+0x40], xmm5
00007fb1689e0fd3  vmovaps [rsp+0x50], xmm6
00007fb1689e0fd9  vmovaps [rsp+0x60], xmm7
00007fb1689e0fdf  vmovaps [rsp+0x70], xmm8
00007fb1689e0fe5  vmovaps [rsp+0x80], xmm9
00007fb1689e0fee  vmovaps [rsp+0x90], xmm10
00007fb1689e0ff7  vmovaps [rsp+0xA0], xmm11
00007fb1689e1000  vmovaps [rsp+0xB0], xmm12
00007fb1689e1009  vmovaps [rsp+0xC0], xmm13
00007fb1689e1012  vmovaps [rsp+0xD0], xmm14
00007fb1689e101b  vmovaps [rsp+0xE0], xmm15
00007fb1689e1024  sub rsp, 0x30
00007fb1689e1028  movaps [rsp], xmm1
00007fb1689e102c  movaps [rsp+0x10], xmm5
00007fb1689e1031  movaps [rsp+0x20], xmm7
00007fb1689e1036  lea rdi, [rsp]
00007fb1689e103a  mov esi, 0x00
00007fb1689e103f  mov rax, 0x57CCFD419530
00007fb1689e1049  call rax
00007fb1689e104b  movaps xmm1, [rsp]
00007fb1689e104f  add rsp, 0x30
00007fb1689e1053  vmovaps xmm0, [rsp]
00007fb1689e1058  vmovaps xmm2, [rsp+0x10]
00007fb1689e105e  vmovaps xmm3, [rsp+0x20]
00007fb1689e1064  vmovaps xmm4, [rsp+0x30]
00007fb1689e106a  vmovaps xmm5, [rsp+0x40]
00007fb1689e1070  vmovaps xmm6, [rsp+0x50]
00007fb1689e1076  vmovaps xmm7, [rsp+0x60]
00007fb1689e107c  vmovaps xmm8, [rsp+0x70]
00007fb1689e1082  vmovaps xmm9, [rsp+0x80]
00007fb1689e108b  vmovaps xmm10, [rsp+0x90]
00007fb1689e1094  vmovaps xmm11, [rsp+0xA0]
00007fb1689e109d  vmovaps xmm12, [rsp+0xB0]
00007fb1689e10a6  vmovaps xmm13, [rsp+0xC0]
00007fb1689e10af  vmovaps xmm14, [rsp+0xD0]
00007fb1689e10b8  vmovaps xmm15, [rsp+0xE0]
00007fb1689e10c1  add rsp, 0xF0
00007fb1689e10c8  pop r11
00007fb1689e10ca  pop r10
00007fb1689e10cc  pop r9
00007fb1689e10ce  pop r8
00007fb1689e10d0  pop rsi
00007fb1689e10d1  pop rdi
00007fb1689e10d2  pop rdx
00007fb1689e10d3  pop rcx
00007fb1689e10d4  pop rax
00007fb1689e10d5  add rsp, 0x08
00007fb1689e10d9  jmp 0x00007FB1689DF210
00007fb1689e10de  sub rsp, 0x08
00007fb1689e10e2  push rax
00007fb1689e10e3  push rcx
00007fb1689e10e4  push rdx
00007fb1689e10e5  push rdi
00007fb1689e10e6  push rsi
00007fb1689e10e7  push r8
00007fb1689e10e9  push r9
00007fb1689e10eb  push r10
00007fb1689e10ed  push r11
00007fb1689e10ef  sub rsp, 0xF0
00007fb1689e10f6  vmovaps [rsp], xmm0
00007fb1689e10fb  vmovaps [rsp+0x10], xmm1
00007fb1689e1101  vmovaps [rsp+0x20], xmm2
00007fb1689e1107  vmovaps [rsp+0x30], xmm3
00007fb1689e110d  vmovaps [rsp+0x40], xmm4
00007fb1689e1113  vmovaps [rsp+0x50], xmm5
00007fb1689e1119  vmovaps [rsp+0x60], xmm6
00007fb1689e111f  vmovaps [rsp+0x70], xmm8
00007fb1689e1125  vmovaps [rsp+0x80], xmm9
00007fb1689e112e  vmovaps [rsp+0x90], xmm10
00007fb1689e1137  vmovaps [rsp+0xA0], xmm11
00007fb1689e1140  vmovaps [rsp+0xB0], xmm12
00007fb1689e1149  vmovaps [rsp+0xC0], xmm13
00007fb1689e1152  vmovaps [rsp+0xD0], xmm14
00007fb1689e115b  vmovaps [rsp+0xE0], xmm15
00007fb1689e1164  sub rsp, 0x30
00007fb1689e1168  movaps [rsp], xmm7
00007fb1689e116c  movaps [rsp+0x10], xmm5
00007fb1689e1171  movaps [rsp+0x20], xmm15
00007fb1689e1177  lea rdi, [rsp]
00007fb1689e117b  mov esi, 0x00
00007fb1689e1180  mov rax, 0x57CCFD419530
00007fb1689e118a  call rax
00007fb1689e118c  movaps xmm7, [rsp]
00007fb1689e1190  add rsp, 0x30
00007fb1689e1194  vmovaps xmm0, [rsp]
00007fb1689e1199  vmovaps xmm1, [rsp+0x10]
00007fb1689e119f  vmovaps xmm2, [rsp+0x20]
00007fb1689e11a5  vmovaps xmm3, [rsp+0x30]
00007fb1689e11ab  vmovaps xmm4, [rsp+0x40]
00007fb1689e11b1  vmovaps xmm5, [rsp+0x50]
00007fb1689e11b7  vmovaps xmm6, [rsp+0x60]
00007fb1689e11bd  vmovaps xmm8, [rsp+0x70]
00007fb1689e11c3  vmovaps xmm9, [rsp+0x80]
00007fb1689e11cc  vmovaps xmm10, [rsp+0x90]
00007fb1689e11d5  vmovaps xmm11, [rsp+0xA0]
00007fb1689e11de  vmovaps xmm12, [rsp+0xB0]
00007fb1689e11e7  vmovaps xmm13, [rsp+0xC0]
00007fb1689e11f0  vmovaps xmm14, [rsp+0xD0]
00007fb1689e11f9  vmovaps xmm15, [rsp+0xE0]
00007fb1689e1202  add rsp, 0xF0
00007fb1689e1209  pop r11
00007fb1689e120b  pop r10
00007fb1689e120d  pop r9
00007fb1689e120f  pop r8
00007fb1689e1211  pop rsi
00007fb1689e1212  pop rdi
00007fb1689e1213  pop rdx
00007fb1689e1214  pop rcx
00007fb1689e1215  pop rax
00007fb1689e1216  add rsp, 0x08
00007fb1689e121a  jmp 0x00007FB1689DF246
00007fb1689e121f  call 0x00007FB1688B52F0
00007fb1689e1224  jmp 0x00007FB1689DF253
00007fb1689e1229  sub rsp, 0x08
00007fb1689e122d  push rax
00007fb1689e122e  push rcx
00007fb1689e122f  push rdx
00007fb1689e1230  push rdi
00007fb1689e1231  push rsi
00007fb1689e1232  push r8
00007fb1689e1234  push r9
00007fb1689e1236  push r10
00007fb1689e1238  push r11
00007fb1689e123a  sub rsp, 0xF0
00007fb1689e1241  vmovaps [rsp], xmm0
00007fb1689e1246  vmovaps [rsp+0x10], xmm1
00007fb1689e124c  vmovaps [rsp+0x20], xmm2
00007fb1689e1252  vmovaps [rsp+0x30], xmm3
00007fb1689e1258  vmovaps [rsp+0x40], xmm4
00007fb1689e125e  vmovaps [rsp+0x50], xmm5
00007fb1689e1264  vmovaps [rsp+0x60], xmm6
00007fb1689e126a  vmovaps [rsp+0x70], xmm7
00007fb1689e1270  vmovaps [rsp+0x80], xmm8
00007fb1689e1279  vmovaps [rsp+0x90], xmm9
00007fb1689e1282  vmovaps [rsp+0xA0], xmm10
00007fb1689e128b  vmovaps [rsp+0xB0], xmm11
00007fb1689e1294  vmovaps [rsp+0xC0], xmm12
00007fb1689e129d  vmovaps [rsp+0xD0], xmm13
00007fb1689e12a6  vmovaps [rsp+0xE0], xmm14
00007fb1689e12af  sub rsp, 0x30
00007fb1689e12b3  movaps [rsp], xmm15
00007fb1689e12b8  movaps [rsp+0x10], xmm5
00007fb1689e12bd  movaps [rsp+0x20], xmm3
00007fb1689e12c2  lea rdi, [rsp]
00007fb1689e12c6  mov esi, 0x00
00007fb1689e12cb  mov rax, 0x57CCFD419530
00007fb1689e12d5  call rax
00007fb1689e12d7  movaps xmm15, [rsp]
00007fb1689e12dc  add rsp, 0x30
00007fb1689e12e0  vmovaps xmm0, [rsp]
00007fb1689e12e5  vmovaps xmm1, [rsp+0x10]
00007fb1689e12eb  vmovaps xmm2, [rsp+0x20]
00007fb1689e12f1  vmovaps xmm3, [rsp+0x30]
00007fb1689e12f7  vmovaps xmm4, [rsp+0x40]
00007fb1689e12fd  vmovaps xmm5, [rsp+0x50]
00007fb1689e1303  vmovaps xmm6, [rsp+0x60]
00007fb1689e1309  vmovaps xmm7, [rsp+0x70]
00007fb1689e130f  vmovaps xmm8, [rsp+0x80]
00007fb1689e1318  vmovaps xmm9, [rsp+0x90]
00007fb1689e1321  vmovaps xmm10, [rsp+0xA0]
00007fb1689e132a  vmovaps xmm11, [rsp+0xB0]
00007fb1689e1333  vmovaps xmm12, [rsp+0xC0]
00007fb1689e133c  vmovaps xmm13, [rsp+0xD0]
00007fb1689e1345  vmovaps xmm14, [rsp+0xE0]
00007fb1689e134e  add rsp, 0xF0
00007fb1689e1355  pop r11
00007fb1689e1357  pop r10
00007fb1689e1359  pop r9
00007fb1689e135b  pop r8
00007fb1689e135d  pop rsi
00007fb1689e135e  pop rdi
00007fb1689e135f  pop rdx
00007fb1689e1360  pop rcx
00007fb1689e1361  pop rax
00007fb1689e1362  add rsp, 0x08
00007fb1689e1366  jmp 0x00007FB1689DF279
00007fb1689e136b  sub rsp, 0x08
00007fb1689e136f  push rax
00007fb1689e1370  push rcx
00007fb1689e1371  push rdx
00007fb1689e1372  push rdi
00007fb1689e1373  push rsi
00007fb1689e1374  push r8
00007fb1689e1376  push r9
00007fb1689e1378  push r10
00007fb1689e137a  push r11
00007fb1689e137c  sub rsp, 0xF0
00007fb1689e1383  vmovaps [rsp], xmm0
00007fb1689e1388  vmovaps [rsp+0x10], xmm2
00007fb1689e138e  vmovaps [rsp+0x20], xmm3
00007fb1689e1394  vmovaps [rsp+0x30], xmm4
00007fb1689e139a  vmovaps [rsp+0x40], xmm5
00007fb1689e13a0  vmovaps [rsp+0x50], xmm6
00007fb1689e13a6  vmovaps [rsp+0x60], xmm7
00007fb1689e13ac  vmovaps [rsp+0x70], xmm8
00007fb1689e13b2  vmovaps [rsp+0x80], xmm9
00007fb1689e13bb  vmovaps [rsp+0x90], xmm10
00007fb1689e13c4  vmovaps [rsp+0xA0], xmm11
00007fb1689e13cd  vmovaps [rsp+0xB0], xmm12
00007fb1689e13d6  vmovaps [rsp+0xC0], xmm13
00007fb1689e13df  vmovaps [rsp+0xD0], xmm14
00007fb1689e13e8  vmovaps [rsp+0xE0], xmm15
00007fb1689e13f1  sub rsp, 0x30
00007fb1689e13f5  movaps [rsp], xmm1
00007fb1689e13f9  movaps [rsp+0x10], xmm5
00007fb1689e13fe  movaps [rsp+0x20], xmm4
00007fb1689e1403  lea rdi, [rsp]
00007fb1689e1407  mov esi, 0x00
00007fb1689e140c  mov rax, 0x57CCFD419530
00007fb1689e1416  call rax
00007fb1689e1418  movaps xmm1, [rsp]
00007fb1689e141c  add rsp, 0x30
00007fb1689e1420  vmovaps xmm0, [rsp]
00007fb1689e1425  vmovaps xmm2, [rsp+0x10]
00007fb1689e142b  vmovaps xmm3, [rsp+0x20]
00007fb1689e1431  vmovaps xmm4, [rsp+0x30]
00007fb1689e1437  vmovaps xmm5, [rsp+0x40]
00007fb1689e143d  vmovaps xmm6, [rsp+0x50]
00007fb1689e1443  vmovaps xmm7, [rsp+0x60]
00007fb1689e1449  vmovaps xmm8, [rsp+0x70]
00007fb1689e144f  vmovaps xmm9, [rsp+0x80]
00007fb1689e1458  vmovaps xmm10, [rsp+0x90]
00007fb1689e1461  vmovaps xmm11, [rsp+0xA0]
00007fb1689e146a  vmovaps xmm12, [rsp+0xB0]
00007fb1689e1473  vmovaps xmm13, [rsp+0xC0]
00007fb1689e147c  vmovaps xmm14, [rsp+0xD0]
00007fb1689e1485  vmovaps xmm15, [rsp+0xE0]
00007fb1689e148e  add rsp, 0xF0
00007fb1689e1495  pop r11
00007fb1689e1497  pop r10
00007fb1689e1499  pop r9
00007fb1689e149b  pop r8
00007fb1689e149d  pop rsi
00007fb1689e149e  pop rdi
00007fb1689e149f  pop rdx
00007fb1689e14a0  pop rcx
00007fb1689e14a1  pop rax
00007fb1689e14a2  add rsp, 0x08
00007fb1689e14a6  jmp 0x00007FB1689DF299
00007fb1689e14ab  sub rsp, 0x08
00007fb1689e14af  push rax
00007fb1689e14b0  push rcx
00007fb1689e14b1  push rdx
00007fb1689e14b2  push rdi
00007fb1689e14b3  push rsi
00007fb1689e14b4  push r8
00007fb1689e14b6  push r9
00007fb1689e14b8  push r10
00007fb1689e14ba  push r11
00007fb1689e14bc  sub rsp, 0xF0
00007fb1689e14c3  vmovaps [rsp], xmm0
00007fb1689e14c8  vmovaps [rsp+0x10], xmm1
00007fb1689e14ce  vmovaps [rsp+0x20], xmm2
00007fb1689e14d4  vmovaps [rsp+0x30], xmm3
00007fb1689e14da  vmovaps [rsp+0x40], xmm5
00007fb1689e14e0  vmovaps [rsp+0x50], xmm6
00007fb1689e14e6  vmovaps [rsp+0x60], xmm7
00007fb1689e14ec  vmovaps [rsp+0x70], xmm8
00007fb1689e14f2  vmovaps [rsp+0x80], xmm9
00007fb1689e14fb  vmovaps [rsp+0x90], xmm10
00007fb1689e1504  vmovaps [rsp+0xA0], xmm11
00007fb1689e150d  vmovaps [rsp+0xB0], xmm12
00007fb1689e1516  vmovaps [rsp+0xC0], xmm13
00007fb1689e151f  vmovaps [rsp+0xD0], xmm14
00007fb1689e1528  vmovaps [rsp+0xE0], xmm15
00007fb1689e1531  sub rsp, 0x30
00007fb1689e1535  movaps [rsp], xmm4
00007fb1689e1539  movaps [rsp+0x10], xmm3
00007fb1689e153e  movaps [rsp+0x20], xmm5
00007fb1689e1543  lea rdi, [rsp]
00007fb1689e1547  mov esi, 0x00
00007fb1689e154c  mov rax, 0x57CCFD419530
00007fb1689e1556  call rax
00007fb1689e1558  movaps xmm4, [rsp]
00007fb1689e155c  add rsp, 0x30
00007fb1689e1560  vmovaps xmm0, [rsp]
00007fb1689e1565  vmovaps xmm1, [rsp+0x10]
00007fb1689e156b  vmovaps xmm2, [rsp+0x20]
00007fb1689e1571  vmovaps xmm3, [rsp+0x30]
00007fb1689e1577  vmovaps xmm5, [rsp+0x40]
00007fb1689e157d  vmovaps xmm6, [rsp+0x50]
00007fb1689e1583  vmovaps xmm7, [rsp+0x60]
00007fb1689e1589  vmovaps xmm8, [rsp+0x70]
00007fb1689e158f  vmovaps xmm9, [rsp+0x80]
00007fb1689e1598  vmovaps xmm10, [rsp+0x90]
00007fb1689e15a1  vmovaps xmm11, [rsp+0xA0]
00007fb1689e15aa  vmovaps xmm12, [rsp+0xB0]
00007fb1689e15b3  vmovaps xmm13, [rsp+0xC0]
00007fb1689e15bc  vmovaps xmm14, [rsp+0xD0]
00007fb1689e15c5  vmovaps xmm15, [rsp+0xE0]
00007fb1689e15ce  add rsp, 0xF0
00007fb1689e15d5  pop r11
00007fb1689e15d7  pop r10
00007fb1689e15d9  pop r9
00007fb1689e15db  pop r8
00007fb1689e15dd  pop rsi
00007fb1689e15de  pop rdi
00007fb1689e15df  pop rdx
00007fb1689e15e0  pop rcx
00007fb1689e15e1  pop rax
00007fb1689e15e2  add rsp, 0x08
00007fb1689e15e6  jmp 0x00007FB1689DF2E7
00007fb1689e15eb  call 0x00007FB1688B52F0
00007fb1689e15f0  jmp 0x00007FB1689DF2F4
00007fb1689e15f5  sub rsp, 0x08
00007fb1689e15f9  push rax
00007fb1689e15fa  push rcx
00007fb1689e15fb  push rdx
00007fb1689e15fc  push rdi
00007fb1689e15fd  push rsi
00007fb1689e15fe  push r8
00007fb1689e1600  push r9
00007fb1689e1602  push r10
00007fb1689e1604  push r11
00007fb1689e1606  sub rsp, 0xF0
00007fb1689e160d  vmovaps [rsp], xmm0
00007fb1689e1612  vmovaps [rsp+0x10], xmm1
00007fb1689e1618  vmovaps [rsp+0x20], xmm2
00007fb1689e161e  vmovaps [rsp+0x30], xmm3
00007fb1689e1624  vmovaps [rsp+0x40], xmm4
00007fb1689e162a  vmovaps [rsp+0x50], xmm6
00007fb1689e1630  vmovaps [rsp+0x60], xmm7
00007fb1689e1636  vmovaps [rsp+0x70], xmm8
00007fb1689e163c  vmovaps [rsp+0x80], xmm9
00007fb1689e1645  vmovaps [rsp+0x90], xmm10
00007fb1689e164e  vmovaps [rsp+0xA0], xmm11
00007fb1689e1657  vmovaps [rsp+0xB0], xmm12
00007fb1689e1660  vmovaps [rsp+0xC0], xmm13
00007fb1689e1669  vmovaps [rsp+0xD0], xmm14
00007fb1689e1672  vmovaps [rsp+0xE0], xmm15
00007fb1689e167b  sub rsp, 0x30
00007fb1689e167f  movaps [rsp], xmm5
00007fb1689e1683  movaps [rsp+0x10], xmm6
00007fb1689e1688  movaps [rsp+0x20], xmm3
00007fb1689e168d  lea rdi, [rsp]
00007fb1689e1691  mov esi, 0x00
00007fb1689e1696  mov rax, 0x57CCFD419530
00007fb1689e16a0  call rax
00007fb1689e16a2  movaps xmm5, [rsp]
00007fb1689e16a6  add rsp, 0x30
00007fb1689e16aa  vmovaps xmm0, [rsp]
00007fb1689e16af  vmovaps xmm1, [rsp+0x10]
00007fb1689e16b5  vmovaps xmm2, [rsp+0x20]
00007fb1689e16bb  vmovaps xmm3, [rsp+0x30]
00007fb1689e16c1  vmovaps xmm4, [rsp+0x40]
00007fb1689e16c7  vmovaps xmm6, [rsp+0x50]
00007fb1689e16cd  vmovaps xmm7, [rsp+0x60]
00007fb1689e16d3  vmovaps xmm8, [rsp+0x70]
00007fb1689e16d9  vmovaps xmm9, [rsp+0x80]
00007fb1689e16e2  vmovaps xmm10, [rsp+0x90]
00007fb1689e16eb  vmovaps xmm11, [rsp+0xA0]
00007fb1689e16f4  vmovaps xmm12, [rsp+0xB0]
00007fb1689e16fd  vmovaps xmm13, [rsp+0xC0]
00007fb1689e1706  vmovaps xmm14, [rsp+0xD0]
00007fb1689e170f  vmovaps xmm15, [rsp+0xE0]
00007fb1689e1718  add rsp, 0xF0
00007fb1689e171f  pop r11
00007fb1689e1721  pop r10
00007fb1689e1723  pop r9
00007fb1689e1725  pop r8
00007fb1689e1727  pop rsi
00007fb1689e1728  pop rdi
00007fb1689e1729  pop rdx
00007fb1689e172a  pop rcx
00007fb1689e172b  pop rax
00007fb1689e172c  add rsp, 0x08
00007fb1689e1730  jmp 0x00007FB1689DF31A
00007fb1689e1735  sub rsp, 0x08
00007fb1689e1739  push rax
00007fb1689e173a  push rcx
00007fb1689e173b  push rdx
00007fb1689e173c  push rdi
00007fb1689e173d  push rsi
00007fb1689e173e  push r8
00007fb1689e1740  push r9
00007fb1689e1742  push r10
00007fb1689e1744  push r11
00007fb1689e1746  sub rsp, 0xF0
00007fb1689e174d  vmovaps [rsp], xmm0
00007fb1689e1752  vmovaps [rsp+0x10], xmm1
00007fb1689e1758  vmovaps [rsp+0x20], xmm2
00007fb1689e175e  vmovaps [rsp+0x30], xmm3
00007fb1689e1764  vmovaps [rsp+0x40], xmm4
00007fb1689e176a  vmovaps [rsp+0x50], xmm5
00007fb1689e1770  vmovaps [rsp+0x60], xmm7
00007fb1689e1776  vmovaps [rsp+0x70], xmm8
00007fb1689e177c  vmovaps [rsp+0x80], xmm9
00007fb1689e1785  vmovaps [rsp+0x90], xmm10
00007fb1689e178e  vmovaps [rsp+0xA0], xmm11
00007fb1689e1797  vmovaps [rsp+0xB0], xmm12
00007fb1689e17a0  vmovaps [rsp+0xC0], xmm13
00007fb1689e17a9  vmovaps [rsp+0xD0], xmm14
00007fb1689e17b2  vmovaps [rsp+0xE0], xmm15
00007fb1689e17bb  sub rsp, 0x30
00007fb1689e17bf  movaps [rsp], xmm6
00007fb1689e17c3  movaps [rsp+0x10], xmm9
00007fb1689e17c9  movaps [rsp+0x20], xmm1
00007fb1689e17ce  lea rdi, [rsp]
00007fb1689e17d2  mov esi, 0x00
00007fb1689e17d7  mov rax, 0x57CCFD419530
00007fb1689e17e1  call rax
00007fb1689e17e3  movaps xmm6, [rsp]
00007fb1689e17e7  add rsp, 0x30
00007fb1689e17eb  vmovaps xmm0, [rsp]
00007fb1689e17f0  vmovaps xmm1, [rsp+0x10]
00007fb1689e17f6  vmovaps xmm2, [rsp+0x20]
00007fb1689e17fc  vmovaps xmm3, [rsp+0x30]
00007fb1689e1802  vmovaps xmm4, [rsp+0x40]
00007fb1689e1808  vmovaps xmm5, [rsp+0x50]
00007fb1689e180e  vmovaps xmm7, [rsp+0x60]
00007fb1689e1814  vmovaps xmm8, [rsp+0x70]
00007fb1689e181a  vmovaps xmm9, [rsp+0x80]
00007fb1689e1823  vmovaps xmm10, [rsp+0x90]
00007fb1689e182c  vmovaps xmm11, [rsp+0xA0]
00007fb1689e1835  vmovaps xmm12, [rsp+0xB0]
00007fb1689e183e  vmovaps xmm13, [rsp+0xC0]
00007fb1689e1847  vmovaps xmm14, [rsp+0xD0]
00007fb1689e1850  vmovaps xmm15, [rsp+0xE0]
00007fb1689e1859  add rsp, 0xF0
00007fb1689e1860  pop r11
00007fb1689e1862  pop r10
00007fb1689e1864  pop r9
00007fb1689e1866  pop r8
00007fb1689e1868  pop rsi
00007fb1689e1869  pop rdi
00007fb1689e186a  pop rdx
00007fb1689e186b  pop rcx
00007fb1689e186c  pop rax
00007fb1689e186d  add rsp, 0x08
00007fb1689e1871  jmp 0x00007FB1689DF33E
00007fb1689e1876  sub rsp, 0x08
00007fb1689e187a  push rax
00007fb1689e187b  push rcx
00007fb1689e187c  push rdx
00007fb1689e187d  push rdi
00007fb1689e187e  push rsi
00007fb1689e187f  push r8
00007fb1689e1881  push r9
00007fb1689e1883  push r10
00007fb1689e1885  push r11
00007fb1689e1887  sub rsp, 0xF0
00007fb1689e188e  vmovaps [rsp], xmm0
00007fb1689e1893  vmovaps [rsp+0x10], xmm1
00007fb1689e1899  vmovaps [rsp+0x20], xmm2
00007fb1689e189f  vmovaps [rsp+0x30], xmm3
00007fb1689e18a5  vmovaps [rsp+0x40], xmm4
00007fb1689e18ab  vmovaps [rsp+0x50], xmm5
00007fb1689e18b1  vmovaps [rsp+0x60], xmm6
00007fb1689e18b7  vmovaps [rsp+0x70], xmm7
00007fb1689e18bd  vmovaps [rsp+0x80], xmm8
00007fb1689e18c6  vmovaps [rsp+0x90], xmm10
00007fb1689e18cf  vmovaps [rsp+0xA0], xmm11
00007fb1689e18d8  vmovaps [rsp+0xB0], xmm12
00007fb1689e18e1  vmovaps [rsp+0xC0], xmm13
00007fb1689e18ea  vmovaps [rsp+0xD0], xmm14
00007fb1689e18f3  vmovaps [rsp+0xE0], xmm15
00007fb1689e18fc  sub rsp, 0x30
00007fb1689e1900  movaps [rsp], xmm9
00007fb1689e1905  movaps [rsp+0x10], xmm3
00007fb1689e190a  movaps [rsp+0x20], xmm1
00007fb1689e190f  lea rdi, [rsp]
00007fb1689e1913  mov esi, 0x00
00007fb1689e1918  mov rax, 0x57CCFD419530
00007fb1689e1922  call rax
00007fb1689e1924  movaps xmm9, [rsp]
00007fb1689e1929  add rsp, 0x30
00007fb1689e192d  vmovaps xmm0, [rsp]
00007fb1689e1932  vmovaps xmm1, [rsp+0x10]
00007fb1689e1938  vmovaps xmm2, [rsp+0x20]
00007fb1689e193e  vmovaps xmm3, [rsp+0x30]
00007fb1689e1944  vmovaps xmm4, [rsp+0x40]
00007fb1689e194a  vmovaps xmm5, [rsp+0x50]
00007fb1689e1950  vmovaps xmm6, [rsp+0x60]
00007fb1689e1956  vmovaps xmm7, [rsp+0x70]
00007fb1689e195c  vmovaps xmm8, [rsp+0x80]
00007fb1689e1965  vmovaps xmm10, [rsp+0x90]
00007fb1689e196e  vmovaps xmm11, [rsp+0xA0]
00007fb1689e1977  vmovaps xmm12, [rsp+0xB0]
00007fb1689e1980  vmovaps xmm13, [rsp+0xC0]
00007fb1689e1989  vmovaps xmm14, [rsp+0xD0]
00007fb1689e1992  vmovaps xmm15, [rsp+0xE0]
00007fb1689e199b  add rsp, 0xF0
00007fb1689e19a2  pop r11
00007fb1689e19a4  pop r10
00007fb1689e19a6  pop r9
00007fb1689e19a8  pop r8
00007fb1689e19aa  pop rsi
00007fb1689e19ab  pop rdi
00007fb1689e19ac  pop rdx
00007fb1689e19ad  pop rcx
00007fb1689e19ae  pop rax
00007fb1689e19af  add rsp, 0x08
00007fb1689e19b3  jmp 0x00007FB1689DF38A
00007fb1689e19b8  call 0x00007FB1688B52F0
00007fb1689e19bd  jmp 0x00007FB1689DF397
00007fb1689e19c2  sub rsp, 0x08
00007fb1689e19c6  push rax
00007fb1689e19c7  push rcx
00007fb1689e19c8  push rdx
00007fb1689e19c9  push rdi
00007fb1689e19ca  push rsi
00007fb1689e19cb  push r8
00007fb1689e19cd  push r9
00007fb1689e19cf  push r10
00007fb1689e19d1  push r11
00007fb1689e19d3  sub rsp, 0xF0
00007fb1689e19da  vmovaps [rsp], xmm0
00007fb1689e19df  vmovaps [rsp+0x10], xmm1
00007fb1689e19e5  vmovaps [rsp+0x20], xmm2
00007fb1689e19eb  vmovaps [rsp+0x30], xmm3
00007fb1689e19f1  vmovaps [rsp+0x40], xmm4
00007fb1689e19f7  vmovaps [rsp+0x50], xmm5
00007fb1689e19fd  vmovaps [rsp+0x60], xmm6
00007fb1689e1a03  vmovaps [rsp+0x70], xmm7
00007fb1689e1a09  vmovaps [rsp+0x80], xmm8
00007fb1689e1a12  vmovaps [rsp+0x90], xmm9
00007fb1689e1a1b  vmovaps [rsp+0xA0], xmm10
00007fb1689e1a24  vmovaps [rsp+0xB0], xmm11
00007fb1689e1a2d  vmovaps [rsp+0xC0], xmm12
00007fb1689e1a36  vmovaps [rsp+0xD0], xmm13
00007fb1689e1a3f  vmovaps [rsp+0xE0], xmm14
00007fb1689e1a48  sub rsp, 0x30
00007fb1689e1a4c  movaps [rsp], xmm15
00007fb1689e1a51  movaps [rsp+0x10], xmm3
00007fb1689e1a56  movaps [rsp+0x20], xmm7
00007fb1689e1a5b  lea rdi, [rsp]
00007fb1689e1a5f  mov esi, 0x00
00007fb1689e1a64  mov rax, 0x57CCFD419530
00007fb1689e1a6e  call rax
00007fb1689e1a70  movaps xmm15, [rsp]
00007fb1689e1a75  add rsp, 0x30
00007fb1689e1a79  vmovaps xmm0, [rsp]
00007fb1689e1a7e  vmovaps xmm1, [rsp+0x10]
00007fb1689e1a84  vmovaps xmm2, [rsp+0x20]
00007fb1689e1a8a  vmovaps xmm3, [rsp+0x30]
00007fb1689e1a90  vmovaps xmm4, [rsp+0x40]
00007fb1689e1a96  vmovaps xmm5, [rsp+0x50]
00007fb1689e1a9c  vmovaps xmm6, [rsp+0x60]
00007fb1689e1aa2  vmovaps xmm7, [rsp+0x70]
00007fb1689e1aa8  vmovaps xmm8, [rsp+0x80]
00007fb1689e1ab1  vmovaps xmm9, [rsp+0x90]
00007fb1689e1aba  vmovaps xmm10, [rsp+0xA0]
00007fb1689e1ac3  vmovaps xmm11, [rsp+0xB0]
00007fb1689e1acc  vmovaps xmm12, [rsp+0xC0]
00007fb1689e1ad5  vmovaps xmm13, [rsp+0xD0]
00007fb1689e1ade  vmovaps xmm14, [rsp+0xE0]
00007fb1689e1ae7  add rsp, 0xF0
00007fb1689e1aee  pop r11
00007fb1689e1af0  pop r10
00007fb1689e1af2  pop r9
00007fb1689e1af4  pop r8
00007fb1689e1af6  pop rsi
00007fb1689e1af7  pop rdi
00007fb1689e1af8  pop rdx
00007fb1689e1af9  pop rcx
00007fb1689e1afa  pop rax
00007fb1689e1afb  add rsp, 0x08
00007fb1689e1aff  jmp 0x00007FB1689DF3C3
00007fb1689e1b04  sub rsp, 0x08
00007fb1689e1b08  push rax
00007fb1689e1b09  push rcx
00007fb1689e1b0a  push rdx
00007fb1689e1b0b  push rdi
00007fb1689e1b0c  push rsi
00007fb1689e1b0d  push r8
00007fb1689e1b0f  push r9
00007fb1689e1b11  push r10
00007fb1689e1b13  push r11
00007fb1689e1b15  sub rsp, 0xF0
00007fb1689e1b1c  vmovaps [rsp], xmm0
00007fb1689e1b21  vmovaps [rsp+0x10], xmm1
00007fb1689e1b27  vmovaps [rsp+0x20], xmm2
00007fb1689e1b2d  vmovaps [rsp+0x30], xmm4
00007fb1689e1b33  vmovaps [rsp+0x40], xmm5
00007fb1689e1b39  vmovaps [rsp+0x50], xmm6
00007fb1689e1b3f  vmovaps [rsp+0x60], xmm7
00007fb1689e1b45  vmovaps [rsp+0x70], xmm8
00007fb1689e1b4b  vmovaps [rsp+0x80], xmm9
00007fb1689e1b54  vmovaps [rsp+0x90], xmm10
00007fb1689e1b5d  vmovaps [rsp+0xA0], xmm11
00007fb1689e1b66  vmovaps [rsp+0xB0], xmm12
00007fb1689e1b6f  vmovaps [rsp+0xC0], xmm13
00007fb1689e1b78  vmovaps [rsp+0xD0], xmm14
00007fb1689e1b81  vmovaps [rsp+0xE0], xmm15
00007fb1689e1b8a  sub rsp, 0x30
00007fb1689e1b8e  movaps [rsp], xmm3
00007fb1689e1b92  movaps [rsp+0x10], xmm1
00007fb1689e1b97  movaps [rsp+0x20], xmm15
00007fb1689e1b9d  lea rdi, [rsp]
00007fb1689e1ba1  mov esi, 0x00
00007fb1689e1ba6  mov rax, 0x57CCFD419530
00007fb1689e1bb0  call rax
00007fb1689e1bb2  movaps xmm3, [rsp]
00007fb1689e1bb6  add rsp, 0x30
00007fb1689e1bba  vmovaps xmm0, [rsp]
00007fb1689e1bbf  vmovaps xmm1, [rsp+0x10]
00007fb1689e1bc5  vmovaps xmm2, [rsp+0x20]
00007fb1689e1bcb  vmovaps xmm4, [rsp+0x30]
00007fb1689e1bd1  vmovaps xmm5, [rsp+0x40]
00007fb1689e1bd7  vmovaps xmm6, [rsp+0x50]
00007fb1689e1bdd  vmovaps xmm7, [rsp+0x60]
00007fb1689e1be3  vmovaps xmm8, [rsp+0x70]
00007fb1689e1be9  vmovaps xmm9, [rsp+0x80]
00007fb1689e1bf2  vmovaps xmm10, [rsp+0x90]
00007fb1689e1bfb  vmovaps xmm11, [rsp+0xA0]
00007fb1689e1c04  vmovaps xmm12, [rsp+0xB0]
00007fb1689e1c0d  vmovaps xmm13, [rsp+0xC0]
00007fb1689e1c16  vmovaps xmm14, [rsp+0xD0]
00007fb1689e1c1f  vmovaps xmm15, [rsp+0xE0]
00007fb1689e1c28  add rsp, 0xF0
00007fb1689e1c2f  pop r11
00007fb1689e1c31  pop r10
00007fb1689e1c33  pop r9
00007fb1689e1c35  pop r8
00007fb1689e1c37  pop rsi
00007fb1689e1c38  pop rdi
00007fb1689e1c39  pop rdx
00007fb1689e1c3a  pop rcx
00007fb1689e1c3b  pop rax
00007fb1689e1c3c  add rsp, 0x08
00007fb1689e1c40  jmp 0x00007FB1689DF452
00007fb1689e1c45  call 0x00007FB1688B52F0
00007fb1689e1c4a  jmp 0x00007FB1689DF45C
00007fb1689e1c4f  sub rsp, 0x08
00007fb1689e1c53  push rax
00007fb1689e1c54  push rcx
00007fb1689e1c55  push rdx
00007fb1689e1c56  push rdi
00007fb1689e1c57  push rsi
00007fb1689e1c58  push r8
00007fb1689e1c5a  push r9
00007fb1689e1c5c  push r10
00007fb1689e1c5e  push r11
00007fb1689e1c60  sub rsp, 0xF0
00007fb1689e1c67  vmovaps [rsp], xmm0
00007fb1689e1c6c  vmovaps [rsp+0x10], xmm1
00007fb1689e1c72  vmovaps [rsp+0x20], xmm2
00007fb1689e1c78  vmovaps [rsp+0x30], xmm3
00007fb1689e1c7e  vmovaps [rsp+0x40], xmm4
00007fb1689e1c84  vmovaps [rsp+0x50], xmm5
00007fb1689e1c8a  vmovaps [rsp+0x60], xmm6
00007fb1689e1c90  vmovaps [rsp+0x70], xmm7
00007fb1689e1c96  vmovaps [rsp+0x80], xmm8
00007fb1689e1c9f  vmovaps [rsp+0x90], xmm9
00007fb1689e1ca8  vmovaps [rsp+0xA0], xmm10
00007fb1689e1cb1  vmovaps [rsp+0xB0], xmm11
00007fb1689e1cba  vmovaps [rsp+0xC0], xmm12
00007fb1689e1cc3  vmovaps [rsp+0xD0], xmm13
00007fb1689e1ccc  vmovaps [rsp+0xE0], xmm14
00007fb1689e1cd5  sub rsp, 0x30
00007fb1689e1cd9  movaps [rsp], xmm15
00007fb1689e1cde  movaps [rsp+0x10], xmm14
00007fb1689e1ce4  movaps [rsp+0x20], xmm4
00007fb1689e1ce9  lea rdi, [rsp]
00007fb1689e1ced  mov esi, 0x00
00007fb1689e1cf2  mov rax, 0x57CCFD419530
00007fb1689e1cfc  call rax
00007fb1689e1cfe  movaps xmm15, [rsp]
00007fb1689e1d03  add rsp, 0x30
00007fb1689e1d07  vmovaps xmm0, [rsp]
00007fb1689e1d0c  vmovaps xmm1, [rsp+0x10]
00007fb1689e1d12  vmovaps xmm2, [rsp+0x20]
00007fb1689e1d18  vmovaps xmm3, [rsp+0x30]
00007fb1689e1d1e  vmovaps xmm4, [rsp+0x40]
00007fb1689e1d24  vmovaps xmm5, [rsp+0x50]
00007fb1689e1d2a  vmovaps xmm6, [rsp+0x60]
00007fb1689e1d30  vmovaps xmm7, [rsp+0x70]
00007fb1689e1d36  vmovaps xmm8, [rsp+0x80]
00007fb1689e1d3f  vmovaps xmm9, [rsp+0x90]
00007fb1689e1d48  vmovaps xmm10, [rsp+0xA0]
00007fb1689e1d51  vmovaps xmm11, [rsp+0xB0]
00007fb1689e1d5a  vmovaps xmm12, [rsp+0xC0]
00007fb1689e1d63  vmovaps xmm13, [rsp+0xD0]
00007fb1689e1d6c  vmovaps xmm14, [rsp+0xE0]
00007fb1689e1d75  add rsp, 0xF0
00007fb1689e1d7c  pop r11
00007fb1689e1d7e  pop r10
00007fb1689e1d80  pop r9
00007fb1689e1d82  pop r8
00007fb1689e1d84  pop rsi
00007fb1689e1d85  pop rdi
00007fb1689e1d86  pop rdx
00007fb1689e1d87  pop rcx
00007fb1689e1d88  pop rax
00007fb1689e1d89  add rsp, 0x08
00007fb1689e1d8d  jmp 0x00007FB1689DF48A
00007fb1689e1d92  sub rsp, 0x08
00007fb1689e1d96  push rax
00007fb1689e1d97  push rcx
00007fb1689e1d98  push rdx
00007fb1689e1d99  push rdi
00007fb1689e1d9a  push rsi
00007fb1689e1d9b  push r8
00007fb1689e1d9d  push r9
00007fb1689e1d9f  push r10
00007fb1689e1da1  push r11
00007fb1689e1da3  sub rsp, 0xF0
00007fb1689e1daa  vmovaps [rsp], xmm0
00007fb1689e1daf  vmovaps [rsp+0x10], xmm1
00007fb1689e1db5  vmovaps [rsp+0x20], xmm2
00007fb1689e1dbb  vmovaps [rsp+0x30], xmm3
00007fb1689e1dc1  vmovaps [rsp+0x40], xmm4
00007fb1689e1dc7  vmovaps [rsp+0x50], xmm5
00007fb1689e1dcd  vmovaps [rsp+0x60], xmm6
00007fb1689e1dd3  vmovaps [rsp+0x70], xmm7
00007fb1689e1dd9  vmovaps [rsp+0x80], xmm8
00007fb1689e1de2  vmovaps [rsp+0x90], xmm9
00007fb1689e1deb  vmovaps [rsp+0xA0], xmm10
00007fb1689e1df4  vmovaps [rsp+0xB0], xmm11
00007fb1689e1dfd  vmovaps [rsp+0xC0], xmm12
00007fb1689e1e06  vmovaps [rsp+0xD0], xmm13
00007fb1689e1e0f  vmovaps [rsp+0xE0], xmm15
00007fb1689e1e18  sub rsp, 0x30
00007fb1689e1e1c  movaps [rsp], xmm14
00007fb1689e1e21  movaps [rsp+0x10], xmm2
00007fb1689e1e26  movaps [rsp+0x20], xmm1
00007fb1689e1e2b  lea rdi, [rsp]
00007fb1689e1e2f  mov esi, 0x00
00007fb1689e1e34  mov rax, 0x57CCFD419530
00007fb1689e1e3e  call rax
00007fb1689e1e40  movaps xmm14, [rsp]
00007fb1689e1e45  add rsp, 0x30
00007fb1689e1e49  vmovaps xmm0, [rsp]
00007fb1689e1e4e  vmovaps xmm1, [rsp+0x10]
00007fb1689e1e54  vmovaps xmm2, [rsp+0x20]
00007fb1689e1e5a  vmovaps xmm3, [rsp+0x30]
00007fb1689e1e60  vmovaps xmm4, [rsp+0x40]
00007fb1689e1e66  vmovaps xmm5, [rsp+0x50]
00007fb1689e1e6c  vmovaps xmm6, [rsp+0x60]
00007fb1689e1e72  vmovaps xmm7, [rsp+0x70]
00007fb1689e1e78  vmovaps xmm8, [rsp+0x80]
00007fb1689e1e81  vmovaps xmm9, [rsp+0x90]
00007fb1689e1e8a  vmovaps xmm10, [rsp+0xA0]
00007fb1689e1e93  vmovaps xmm11, [rsp+0xB0]
00007fb1689e1e9c  vmovaps xmm12, [rsp+0xC0]
00007fb1689e1ea5  vmovaps xmm13, [rsp+0xD0]
00007fb1689e1eae  vmovaps xmm15, [rsp+0xE0]
00007fb1689e1eb7  add rsp, 0xF0
00007fb1689e1ebe  pop r11
00007fb1689e1ec0  pop r10
00007fb1689e1ec2  pop r9
00007fb1689e1ec4  pop r8
00007fb1689e1ec6  pop rsi
00007fb1689e1ec7  pop rdi
00007fb1689e1ec8  pop rdx
00007fb1689e1ec9  pop rcx
00007fb1689e1eca  pop rax
00007fb1689e1ecb  add rsp, 0x08
00007fb1689e1ecf  jmp 0x00007FB1689DF4B0
00007fb1689e1ed4  sub rsp, 0x08
00007fb1689e1ed8  push rax
00007fb1689e1ed9  push rcx
00007fb1689e1eda  push rdx
00007fb1689e1edb  push rdi
00007fb1689e1edc  push rsi
00007fb1689e1edd  push r8
00007fb1689e1edf  push r9
00007fb1689e1ee1  push r10
00007fb1689e1ee3  push r11
00007fb1689e1ee5  sub rsp, 0xF0
00007fb1689e1eec  vmovaps [rsp], xmm0
00007fb1689e1ef1  vmovaps [rsp+0x10], xmm2
00007fb1689e1ef7  vmovaps [rsp+0x20], xmm3
00007fb1689e1efd  vmovaps [rsp+0x30], xmm4
00007fb1689e1f03  vmovaps [rsp+0x40], xmm5
00007fb1689e1f09  vmovaps [rsp+0x50], xmm6
00007fb1689e1f0f  vmovaps [rsp+0x60], xmm7
00007fb1689e1f15  vmovaps [rsp+0x70], xmm8
00007fb1689e1f1b  vmovaps [rsp+0x80], xmm9
00007fb1689e1f24  vmovaps [rsp+0x90], xmm10
00007fb1689e1f2d  vmovaps [rsp+0xA0], xmm11
00007fb1689e1f36  vmovaps [rsp+0xB0], xmm12
00007fb1689e1f3f  vmovaps [rsp+0xC0], xmm13
00007fb1689e1f48  vmovaps [rsp+0xD0], xmm14
00007fb1689e1f51  vmovaps [rsp+0xE0], xmm15
00007fb1689e1f5a  sub rsp, 0x30
00007fb1689e1f5e  movaps [rsp], xmm1
00007fb1689e1f62  movaps [rsp+0x10], xmm4
00007fb1689e1f67  movaps [rsp+0x20], xmm9
00007fb1689e1f6d  lea rdi, [rsp]
00007fb1689e1f71  mov esi, 0x00
00007fb1689e1f76  mov rax, 0x57CCFD419530
00007fb1689e1f80  call rax
00007fb1689e1f82  movaps xmm1, [rsp]
00007fb1689e1f86  add rsp, 0x30
00007fb1689e1f8a  vmovaps xmm0, [rsp]
00007fb1689e1f8f  vmovaps xmm2, [rsp+0x10]
00007fb1689e1f95  vmovaps xmm3, [rsp+0x20]
00007fb1689e1f9b  vmovaps xmm4, [rsp+0x30]
00007fb1689e1fa1  vmovaps xmm5, [rsp+0x40]
00007fb1689e1fa7  vmovaps xmm6, [rsp+0x50]
00007fb1689e1fad  vmovaps xmm7, [rsp+0x60]
00007fb1689e1fb3  vmovaps xmm8, [rsp+0x70]
00007fb1689e1fb9  vmovaps xmm9, [rsp+0x80]
00007fb1689e1fc2  vmovaps xmm10, [rsp+0x90]
00007fb1689e1fcb  vmovaps xmm11, [rsp+0xA0]
00007fb1689e1fd4  vmovaps xmm12, [rsp+0xB0]
00007fb1689e1fdd  vmovaps xmm13, [rsp+0xC0]
00007fb1689e1fe6  vmovaps xmm14, [rsp+0xD0]
00007fb1689e1fef  vmovaps xmm15, [rsp+0xE0]
00007fb1689e1ff8  add rsp, 0xF0
00007fb1689e1fff  pop r11
00007fb1689e2001  pop r10
00007fb1689e2003  pop r9
00007fb1689e2005  pop r8
00007fb1689e2007  pop rsi
00007fb1689e2008  pop rdi
00007fb1689e2009  pop rdx
00007fb1689e200a  pop rcx
00007fb1689e200b  pop rax
00007fb1689e200c  add rsp, 0x08
00007fb1689e2010  jmp 0x00007FB1689DF4CE
00007fb1689e2015  sub rsp, 0x08
00007fb1689e2019  push rax
00007fb1689e201a  push rcx
00007fb1689e201b  push rdx
00007fb1689e201c  push rdi
00007fb1689e201d  push rsi
00007fb1689e201e  push r8
00007fb1689e2020  push r9
00007fb1689e2022  push r10
00007fb1689e2024  push r11
00007fb1689e2026  sub rsp, 0xF0
00007fb1689e202d  vmovaps [rsp], xmm0
00007fb1689e2032  vmovaps [rsp+0x10], xmm1
00007fb1689e2038  vmovaps [rsp+0x20], xmm2
00007fb1689e203e  vmovaps [rsp+0x30], xmm3
00007fb1689e2044  vmovaps [rsp+0x40], xmm5
00007fb1689e204a  vmovaps [rsp+0x50], xmm6
00007fb1689e2050  vmovaps [rsp+0x60], xmm7
00007fb1689e2056  vmovaps [rsp+0x70], xmm8
00007fb1689e205c  vmovaps [rsp+0x80], xmm9
00007fb1689e2065  vmovaps [rsp+0x90], xmm10
00007fb1689e206e  vmovaps [rsp+0xA0], xmm11
00007fb1689e2077  vmovaps [rsp+0xB0], xmm12
00007fb1689e2080  vmovaps [rsp+0xC0], xmm13
00007fb1689e2089  vmovaps [rsp+0xD0], xmm14
00007fb1689e2092  vmovaps [rsp+0xE0], xmm15
00007fb1689e209b  sub rsp, 0x30
00007fb1689e209f  movaps [rsp], xmm4
00007fb1689e20a3  movaps [rsp+0x10], xmm2
00007fb1689e20a8  movaps [rsp+0x20], xmm9
00007fb1689e20ae  lea rdi, [rsp]
00007fb1689e20b2  mov esi, 0x00
00007fb1689e20b7  mov rax, 0x57CCFD419530
00007fb1689e20c1  call rax
00007fb1689e20c3  movaps xmm4, [rsp]
00007fb1689e20c7  add rsp, 0x30
00007fb1689e20cb  vmovaps xmm0, [rsp]
00007fb1689e20d0  vmovaps xmm1, [rsp+0x10]
00007fb1689e20d6  vmovaps xmm2, [rsp+0x20]
00007fb1689e20dc  vmovaps xmm3, [rsp+0x30]
00007fb1689e20e2  vmovaps xmm5, [rsp+0x40]
00007fb1689e20e8  vmovaps xmm6, [rsp+0x50]
00007fb1689e20ee  vmovaps xmm7, [rsp+0x60]
00007fb1689e20f4  vmovaps xmm8, [rsp+0x70]
00007fb1689e20fa  vmovaps xmm9, [rsp+0x80]
00007fb1689e2103  vmovaps xmm10, [rsp+0x90]
00007fb1689e210c  vmovaps xmm11, [rsp+0xA0]
00007fb1689e2115  vmovaps xmm12, [rsp+0xB0]
00007fb1689e211e  vmovaps xmm13, [rsp+0xC0]
00007fb1689e2127  vmovaps xmm14, [rsp+0xD0]
00007fb1689e2130  vmovaps xmm15, [rsp+0xE0]
00007fb1689e2139  add rsp, 0xF0
00007fb1689e2140  pop r11
00007fb1689e2142  pop r10
00007fb1689e2144  pop r9
00007fb1689e2146  pop r8
00007fb1689e2148  pop rsi
00007fb1689e2149  pop rdi
00007fb1689e214a  pop rdx
00007fb1689e214b  pop rcx
00007fb1689e214c  pop rax
00007fb1689e214d  add rsp, 0x08
00007fb1689e2151  jmp 0x00007FB1689DF4FE
00007fb1689e2156  sub rsp, 0x08
00007fb1689e215a  push rax
00007fb1689e215b  push rcx
00007fb1689e215c  push rdx
00007fb1689e215d  push rdi
00007fb1689e215e  push rsi
00007fb1689e215f  push r8
00007fb1689e2161  push r9
00007fb1689e2163  push r10
00007fb1689e2165  push r11
00007fb1689e2167  sub rsp, 0xF0
00007fb1689e216e  vmovaps [rsp], xmm0
00007fb1689e2173  vmovaps [rsp+0x10], xmm1
00007fb1689e2179  vmovaps [rsp+0x20], xmm2
00007fb1689e217f  vmovaps [rsp+0x30], xmm3
00007fb1689e2185  vmovaps [rsp+0x40], xmm4
00007fb1689e218b  vmovaps [rsp+0x50], xmm5
00007fb1689e2191  vmovaps [rsp+0x60], xmm6
00007fb1689e2197  vmovaps [rsp+0x70], xmm7
00007fb1689e219d  vmovaps [rsp+0x80], xmm8
00007fb1689e21a6  vmovaps [rsp+0x90], xmm10
00007fb1689e21af  vmovaps [rsp+0xA0], xmm11
00007fb1689e21b8  vmovaps [rsp+0xB0], xmm12
00007fb1689e21c1  vmovaps [rsp+0xC0], xmm13
00007fb1689e21ca  vmovaps [rsp+0xD0], xmm14
00007fb1689e21d3  vmovaps [rsp+0xE0], xmm15
00007fb1689e21dc  sub rsp, 0x30
00007fb1689e21e0  movaps [rsp], xmm9
00007fb1689e21e5  movaps [rsp+0x10], xmm2
00007fb1689e21ea  movaps [rsp+0x20], xmm1
00007fb1689e21ef  lea rdi, [rsp]
00007fb1689e21f3  mov esi, 0x00
00007fb1689e21f8  mov rax, 0x57CCFD419530
00007fb1689e2202  call rax
00007fb1689e2204  movaps xmm9, [rsp]
00007fb1689e2209  add rsp, 0x30
00007fb1689e220d  vmovaps xmm0, [rsp]
00007fb1689e2212  vmovaps xmm1, [rsp+0x10]
00007fb1689e2218  vmovaps xmm2, [rsp+0x20]
00007fb1689e221e  vmovaps xmm3, [rsp+0x30]
00007fb1689e2224  vmovaps xmm4, [rsp+0x40]
00007fb1689e222a  vmovaps xmm5, [rsp+0x50]
00007fb1689e2230  vmovaps xmm6, [rsp+0x60]
00007fb1689e2236  vmovaps xmm7, [rsp+0x70]
00007fb1689e223c  vmovaps xmm8, [rsp+0x80]
00007fb1689e2245  vmovaps xmm10, [rsp+0x90]
00007fb1689e224e  vmovaps xmm11, [rsp+0xA0]
00007fb1689e2257  vmovaps xmm12, [rsp+0xB0]
00007fb1689e2260  vmovaps xmm13, [rsp+0xC0]
00007fb1689e2269  vmovaps xmm14, [rsp+0xD0]
00007fb1689e2272  vmovaps xmm15, [rsp+0xE0]
00007fb1689e227b  add rsp, 0xF0
00007fb1689e2282  pop r11
00007fb1689e2284  pop r10
00007fb1689e2286  pop r9
00007fb1689e2288  pop r8
00007fb1689e228a  pop rsi
00007fb1689e228b  pop rdi
00007fb1689e228c  pop rdx
00007fb1689e228d  pop rcx
00007fb1689e228e  pop rax
00007fb1689e228f  add rsp, 0x08
00007fb1689e2293  jmp 0x00007FB1689DF534
00007fb1689e2298  sub rsp, 0x08
00007fb1689e229c  push rax
00007fb1689e229d  push rcx
00007fb1689e229e  push rdx
00007fb1689e229f  push rdi
00007fb1689e22a0  push rsi
00007fb1689e22a1  push r8
00007fb1689e22a3  push r9
00007fb1689e22a5  push r10
00007fb1689e22a7  push r11
00007fb1689e22a9  sub rsp, 0xF0
00007fb1689e22b0  vmovaps [rsp], xmm0
00007fb1689e22b5  vmovaps [rsp+0x10], xmm2
00007fb1689e22bb  vmovaps [rsp+0x20], xmm3
00007fb1689e22c1  vmovaps [rsp+0x30], xmm4
00007fb1689e22c7  vmovaps [rsp+0x40], xmm5
00007fb1689e22cd  vmovaps [rsp+0x50], xmm6
00007fb1689e22d3  vmovaps [rsp+0x60], xmm7
00007fb1689e22d9  vmovaps [rsp+0x70], xmm8
00007fb1689e22df  vmovaps [rsp+0x80], xmm9
00007fb1689e22e8  vmovaps [rsp+0x90], xmm10
00007fb1689e22f1  vmovaps [rsp+0xA0], xmm11
00007fb1689e22fa  vmovaps [rsp+0xB0], xmm12
00007fb1689e2303  vmovaps [rsp+0xC0], xmm13
00007fb1689e230c  vmovaps [rsp+0xD0], xmm14
00007fb1689e2315  vmovaps [rsp+0xE0], xmm15
00007fb1689e231e  sub rsp, 0x30
00007fb1689e2322  movaps [rsp], xmm1
00007fb1689e2326  movaps [rsp+0x10], xmm15
00007fb1689e232c  movaps [rsp+0x20], xmm6
00007fb1689e2331  lea rdi, [rsp]
00007fb1689e2335  mov esi, 0x00
00007fb1689e233a  mov rax, 0x57CCFD419530
00007fb1689e2344  call rax
00007fb1689e2346  movaps xmm1, [rsp]
00007fb1689e234a  add rsp, 0x30
00007fb1689e234e  vmovaps xmm0, [rsp]
00007fb1689e2353  vmovaps xmm2, [rsp+0x10]
00007fb1689e2359  vmovaps xmm3, [rsp+0x20]
00007fb1689e235f  vmovaps xmm4, [rsp+0x30]
00007fb1689e2365  vmovaps xmm5, [rsp+0x40]
00007fb1689e236b  vmovaps xmm6, [rsp+0x50]
00007fb1689e2371  vmovaps xmm7, [rsp+0x60]
00007fb1689e2377  vmovaps xmm8, [rsp+0x70]
00007fb1689e237d  vmovaps xmm9, [rsp+0x80]
00007fb1689e2386  vmovaps xmm10, [rsp+0x90]
00007fb1689e238f  vmovaps xmm11, [rsp+0xA0]
00007fb1689e2398  vmovaps xmm12, [rsp+0xB0]
00007fb1689e23a1  vmovaps xmm13, [rsp+0xC0]
00007fb1689e23aa  vmovaps xmm14, [rsp+0xD0]
00007fb1689e23b3  vmovaps xmm15, [rsp+0xE0]
00007fb1689e23bc  add rsp, 0xF0
00007fb1689e23c3  pop r11
00007fb1689e23c5  pop r10
00007fb1689e23c7  pop r9
00007fb1689e23c9  pop r8
00007fb1689e23cb  pop rsi
00007fb1689e23cc  pop rdi
00007fb1689e23cd  pop rdx
00007fb1689e23ce  pop rcx
00007fb1689e23cf  pop rax
00007fb1689e23d0  add rsp, 0x08
00007fb1689e23d4  jmp 0x00007FB1689DF555
00007fb1689e23d9  sub rsp, 0x08
00007fb1689e23dd  push rax
00007fb1689e23de  push rcx
00007fb1689e23df  push rdx
00007fb1689e23e0  push rdi
00007fb1689e23e1  push rsi
00007fb1689e23e2  push r8
00007fb1689e23e4  push r9
00007fb1689e23e6  push r10
00007fb1689e23e8  push r11
00007fb1689e23ea  sub rsp, 0xF0
00007fb1689e23f1  vmovaps [rsp], xmm0
00007fb1689e23f6  vmovaps [rsp+0x10], xmm1
00007fb1689e23fc  vmovaps [rsp+0x20], xmm2
00007fb1689e2402  vmovaps [rsp+0x30], xmm3
00007fb1689e2408  vmovaps [rsp+0x40], xmm4
00007fb1689e240e  vmovaps [rsp+0x50], xmm5
00007fb1689e2414  vmovaps [rsp+0x60], xmm6
00007fb1689e241a  vmovaps [rsp+0x70], xmm7
00007fb1689e2420  vmovaps [rsp+0x80], xmm8
00007fb1689e2429  vmovaps [rsp+0x90], xmm9
00007fb1689e2432  vmovaps [rsp+0xA0], xmm10
00007fb1689e243b  vmovaps [rsp+0xB0], xmm11
00007fb1689e2444  vmovaps [rsp+0xC0], xmm12
00007fb1689e244d  vmovaps [rsp+0xD0], xmm13
00007fb1689e2456  vmovaps [rsp+0xE0], xmm14
00007fb1689e245f  sub rsp, 0x30
00007fb1689e2463  movaps [rsp], xmm15
00007fb1689e2468  movaps [rsp+0x10], xmm5
00007fb1689e246d  movaps [rsp+0x20], xmm3
00007fb1689e2472  lea rdi, [rsp]
00007fb1689e2476  mov esi, 0x00
00007fb1689e247b  mov rax, 0x57CCFD419530
00007fb1689e2485  call rax
00007fb1689e2487  movaps xmm15, [rsp]
00007fb1689e248c  add rsp, 0x30
00007fb1689e2490  vmovaps xmm0, [rsp]
00007fb1689e2495  vmovaps xmm1, [rsp+0x10]
00007fb1689e249b  vmovaps xmm2, [rsp+0x20]
00007fb1689e24a1  vmovaps xmm3, [rsp+0x30]
00007fb1689e24a7  vmovaps xmm4, [rsp+0x40]
00007fb1689e24ad  vmovaps xmm5, [rsp+0x50]
00007fb1689e24b3  vmovaps xmm6, [rsp+0x60]
00007fb1689e24b9  vmovaps xmm7, [rsp+0x70]
00007fb1689e24bf  vmovaps xmm8, [rsp+0x80]
00007fb1689e24c8  vmovaps xmm9, [rsp+0x90]
00007fb1689e24d1  vmovaps xmm10, [rsp+0xA0]
00007fb1689e24da  vmovaps xmm11, [rsp+0xB0]
00007fb1689e24e3  vmovaps xmm12, [rsp+0xC0]
00007fb1689e24ec  vmovaps xmm13, [rsp+0xD0]
00007fb1689e24f5  vmovaps xmm14, [rsp+0xE0]
00007fb1689e24fe  add rsp, 0xF0
00007fb1689e2505  pop r11
00007fb1689e2507  pop r10
00007fb1689e2509  pop r9
00007fb1689e250b  pop r8
00007fb1689e250d  pop rsi
00007fb1689e250e  pop rdi
00007fb1689e250f  pop rdx
00007fb1689e2510  pop rcx
00007fb1689e2511  pop rax
00007fb1689e2512  add rsp, 0x08
00007fb1689e2516  jmp 0x00007FB1689DF56F
00007fb1689e251b  sub rsp, 0x08
00007fb1689e251f  push rax
00007fb1689e2520  push rcx
00007fb1689e2521  push rdx
00007fb1689e2522  push rdi
00007fb1689e2523  push rsi
00007fb1689e2524  push r8
00007fb1689e2526  push r9
00007fb1689e2528  push r10
00007fb1689e252a  push r11
00007fb1689e252c  sub rsp, 0xF0
00007fb1689e2533  vmovaps [rsp], xmm0
00007fb1689e2538  vmovaps [rsp+0x10], xmm1
00007fb1689e253e  vmovaps [rsp+0x20], xmm2
00007fb1689e2544  vmovaps [rsp+0x30], xmm3
00007fb1689e254a  vmovaps [rsp+0x40], xmm4
00007fb1689e2550  vmovaps [rsp+0x50], xmm6
00007fb1689e2556  vmovaps [rsp+0x60], xmm7
00007fb1689e255c  vmovaps [rsp+0x70], xmm8
00007fb1689e2562  vmovaps [rsp+0x80], xmm9
00007fb1689e256b  vmovaps [rsp+0x90], xmm10
00007fb1689e2574  vmovaps [rsp+0xA0], xmm11
00007fb1689e257d  vmovaps [rsp+0xB0], xmm12
00007fb1689e2586  vmovaps [rsp+0xC0], xmm13
00007fb1689e258f  vmovaps [rsp+0xD0], xmm14
00007fb1689e2598  vmovaps [rsp+0xE0], xmm15
00007fb1689e25a1  sub rsp, 0x30
00007fb1689e25a5  movaps [rsp], xmm5
00007fb1689e25a9  movaps [rsp+0x10], xmm8
00007fb1689e25af  movaps [rsp+0x20], xmm6
00007fb1689e25b4  lea rdi, [rsp]
00007fb1689e25b8  mov esi, 0x00
00007fb1689e25bd  mov rax, 0x57CCFD419530
00007fb1689e25c7  call rax
00007fb1689e25c9  movaps xmm5, [rsp]
00007fb1689e25cd  add rsp, 0x30
00007fb1689e25d1  vmovaps xmm0, [rsp]
00007fb1689e25d6  vmovaps xmm1, [rsp+0x10]
00007fb1689e25dc  vmovaps xmm2, [rsp+0x20]
00007fb1689e25e2  vmovaps xmm3, [rsp+0x30]
00007fb1689e25e8  vmovaps xmm4, [rsp+0x40]
00007fb1689e25ee  vmovaps xmm6, [rsp+0x50]
00007fb1689e25f4  vmovaps xmm7, [rsp+0x60]
00007fb1689e25fa  vmovaps xmm8, [rsp+0x70]
00007fb1689e2600  vmovaps xmm9, [rsp+0x80]
00007fb1689e2609  vmovaps xmm10, [rsp+0x90]
00007fb1689e2612  vmovaps xmm11, [rsp+0xA0]
00007fb1689e261b  vmovaps xmm12, [rsp+0xB0]
00007fb1689e2624  vmovaps xmm13, [rsp+0xC0]
00007fb1689e262d  vmovaps xmm14, [rsp+0xD0]
00007fb1689e2636  vmovaps xmm15, [rsp+0xE0]
00007fb1689e263f  add rsp, 0xF0
00007fb1689e2646  pop r11
00007fb1689e2648  pop r10
00007fb1689e264a  pop r9
00007fb1689e264c  pop r8
00007fb1689e264e  pop rsi
00007fb1689e264f  pop rdi
00007fb1689e2650  pop rdx
00007fb1689e2651  pop rcx
00007fb1689e2652  pop rax
00007fb1689e2653  add rsp, 0x08
00007fb1689e2657  jmp 0x00007FB1689DF593
00007fb1689e265c  sub rsp, 0x08
00007fb1689e2660  push rax
00007fb1689e2661  push rcx
00007fb1689e2662  push rdx
00007fb1689e2663  push rdi
00007fb1689e2664  push rsi
00007fb1689e2665  push r8
00007fb1689e2667  push r9
00007fb1689e2669  push r10
00007fb1689e266b  push r11
00007fb1689e266d  sub rsp, 0xF0
00007fb1689e2674  vmovaps [rsp], xmm0
00007fb1689e2679  vmovaps [rsp+0x10], xmm1
00007fb1689e267f  vmovaps [rsp+0x20], xmm2
00007fb1689e2685  vmovaps [rsp+0x30], xmm3
00007fb1689e268b  vmovaps [rsp+0x40], xmm4
00007fb1689e2691  vmovaps [rsp+0x50], xmm5
00007fb1689e2697  vmovaps [rsp+0x60], xmm7
00007fb1689e269d  vmovaps [rsp+0x70], xmm8
00007fb1689e26a3  vmovaps [rsp+0x80], xmm9
00007fb1689e26ac  vmovaps [rsp+0x90], xmm10
00007fb1689e26b5  vmovaps [rsp+0xA0], xmm11
00007fb1689e26be  vmovaps [rsp+0xB0], xmm12
00007fb1689e26c7  vmovaps [rsp+0xC0], xmm13
00007fb1689e26d0  vmovaps [rsp+0xD0], xmm14
00007fb1689e26d9  vmovaps [rsp+0xE0], xmm15
00007fb1689e26e2  sub rsp, 0x30
00007fb1689e26e6  movaps [rsp], xmm6
00007fb1689e26ea  movaps [rsp+0x10], xmm10
00007fb1689e26f0  movaps [rsp+0x20], xmm8
00007fb1689e26f6  lea rdi, [rsp]
00007fb1689e26fa  mov esi, 0x00
00007fb1689e26ff  mov rax, 0x57CCFD419530
00007fb1689e2709  call rax
00007fb1689e270b  movaps xmm6, [rsp]
00007fb1689e270f  add rsp, 0x30
00007fb1689e2713  vmovaps xmm0, [rsp]
00007fb1689e2718  vmovaps xmm1, [rsp+0x10]
00007fb1689e271e  vmovaps xmm2, [rsp+0x20]
00007fb1689e2724  vmovaps xmm3, [rsp+0x30]
00007fb1689e272a  vmovaps xmm4, [rsp+0x40]
00007fb1689e2730  vmovaps xmm5, [rsp+0x50]
00007fb1689e2736  vmovaps xmm7, [rsp+0x60]
00007fb1689e273c  vmovaps xmm8, [rsp+0x70]
00007fb1689e2742  vmovaps xmm9, [rsp+0x80]
00007fb1689e274b  vmovaps xmm10, [rsp+0x90]
00007fb1689e2754  vmovaps xmm11, [rsp+0xA0]
00007fb1689e275d  vmovaps xmm12, [rsp+0xB0]
00007fb1689e2766  vmovaps xmm13, [rsp+0xC0]
00007fb1689e276f  vmovaps xmm14, [rsp+0xD0]
00007fb1689e2778  vmovaps xmm15, [rsp+0xE0]
00007fb1689e2781  add rsp, 0xF0
00007fb1689e2788  pop r11
00007fb1689e278a  pop r10
00007fb1689e278c  pop r9
00007fb1689e278e  pop r8
00007fb1689e2790  pop rsi
00007fb1689e2791  pop rdi
00007fb1689e2792  pop rdx
00007fb1689e2793  pop rcx
00007fb1689e2794  pop rax
00007fb1689e2795  add rsp, 0x08
00007fb1689e2799  jmp 0x00007FB1689DF5B8
00007fb1689e279e  sub rsp, 0x08
00007fb1689e27a2  push rax
00007fb1689e27a3  push rcx
00007fb1689e27a4  push rdx
00007fb1689e27a5  push rdi
00007fb1689e27a6  push rsi
00007fb1689e27a7  push r8
00007fb1689e27a9  push r9
00007fb1689e27ab  push r10
00007fb1689e27ad  push r11
00007fb1689e27af  sub rsp, 0xF0
00007fb1689e27b6  vmovaps [rsp], xmm0
00007fb1689e27bb  vmovaps [rsp+0x10], xmm1
00007fb1689e27c1  vmovaps [rsp+0x20], xmm2
00007fb1689e27c7  vmovaps [rsp+0x30], xmm3
00007fb1689e27cd  vmovaps [rsp+0x40], xmm4
00007fb1689e27d3  vmovaps [rsp+0x50], xmm5
00007fb1689e27d9  vmovaps [rsp+0x60], xmm6
00007fb1689e27df  vmovaps [rsp+0x70], xmm7
00007fb1689e27e5  vmovaps [rsp+0x80], xmm8
00007fb1689e27ee  vmovaps [rsp+0x90], xmm9
00007fb1689e27f7  vmovaps [rsp+0xA0], xmm11
00007fb1689e2800  vmovaps [rsp+0xB0], xmm12
00007fb1689e2809  vmovaps [rsp+0xC0], xmm13
00007fb1689e2812  vmovaps [rsp+0xD0], xmm14
00007fb1689e281b  vmovaps [rsp+0xE0], xmm15
00007fb1689e2824  sub rsp, 0x30
00007fb1689e2828  movaps [rsp], xmm10
00007fb1689e282d  movaps [rsp+0x10], xmm8
00007fb1689e2833  movaps [rsp+0x20], xmm14
00007fb1689e2839  lea rdi, [rsp]
00007fb1689e283d  mov esi, 0x00
00007fb1689e2842  mov rax, 0x57CCFD419530
00007fb1689e284c  call rax
00007fb1689e284e  movaps xmm10, [rsp]
00007fb1689e2853  add rsp, 0x30
00007fb1689e2857  vmovaps xmm0, [rsp]
00007fb1689e285c  vmovaps xmm1, [rsp+0x10]
00007fb1689e2862  vmovaps xmm2, [rsp+0x20]
00007fb1689e2868  vmovaps xmm3, [rsp+0x30]
00007fb1689e286e  vmovaps xmm4, [rsp+0x40]
00007fb1689e2874  vmovaps xmm5, [rsp+0x50]
00007fb1689e287a  vmovaps xmm6, [rsp+0x60]
00007fb1689e2880  vmovaps xmm7, [rsp+0x70]
00007fb1689e2886  vmovaps xmm8, [rsp+0x80]
00007fb1689e288f  vmovaps xmm9, [rsp+0x90]
00007fb1689e2898  vmovaps xmm11, [rsp+0xA0]
00007fb1689e28a1  vmovaps xmm12, [rsp+0xB0]
00007fb1689e28aa  vmovaps xmm13, [rsp+0xC0]
00007fb1689e28b3  vmovaps xmm14, [rsp+0xD0]
00007fb1689e28bc  vmovaps xmm15, [rsp+0xE0]
00007fb1689e28c5  add rsp, 0xF0
00007fb1689e28cc  pop r11
00007fb1689e28ce  pop r10
00007fb1689e28d0  pop r9
00007fb1689e28d2  pop r8
00007fb1689e28d4  pop rsi
00007fb1689e28d5  pop rdi
00007fb1689e28d6  pop rdx
00007fb1689e28d7  pop rcx
00007fb1689e28d8  pop rax
00007fb1689e28d9  add rsp, 0x08
00007fb1689e28dd  jmp 0x00007FB1689DF5D8
00007fb1689e28e2  sub rsp, 0x08
00007fb1689e28e6  push rax
00007fb1689e28e7  push rcx
00007fb1689e28e8  push rdx
00007fb1689e28e9  push rdi
00007fb1689e28ea  push rsi
00007fb1689e28eb  push r8
00007fb1689e28ed  push r9
00007fb1689e28ef  push r10
00007fb1689e28f1  push r11
00007fb1689e28f3  sub rsp, 0xF0
00007fb1689e28fa  vmovaps [rsp], xmm0
00007fb1689e28ff  vmovaps [rsp+0x10], xmm1
00007fb1689e2905  vmovaps [rsp+0x20], xmm2
00007fb1689e290b  vmovaps [rsp+0x30], xmm3
00007fb1689e2911  vmovaps [rsp+0x40], xmm4
00007fb1689e2917  vmovaps [rsp+0x50], xmm5
00007fb1689e291d  vmovaps [rsp+0x60], xmm6
00007fb1689e2923  vmovaps [rsp+0x70], xmm7
00007fb1689e2929  vmovaps [rsp+0x80], xmm8
00007fb1689e2932  vmovaps [rsp+0x90], xmm9
00007fb1689e293b  vmovaps [rsp+0xA0], xmm10
00007fb1689e2944  vmovaps [rsp+0xB0], xmm11
00007fb1689e294d  vmovaps [rsp+0xC0], xmm12
00007fb1689e2956  vmovaps [rsp+0xD0], xmm13
00007fb1689e295f  vmovaps [rsp+0xE0], xmm15
00007fb1689e2968  sub rsp, 0x30
00007fb1689e296c  movaps [rsp], xmm14
00007fb1689e2971  movaps [rsp+0x10], xmm8
00007fb1689e2977  movaps [rsp+0x20], xmm4
00007fb1689e297c  lea rdi, [rsp]
00007fb1689e2980  mov esi, 0x00
00007fb1689e2985  mov rax, 0x57CCFD419530
00007fb1689e298f  call rax
00007fb1689e2991  movaps xmm14, [rsp]
00007fb1689e2996  add rsp, 0x30
00007fb1689e299a  vmovaps xmm0, [rsp]
00007fb1689e299f  vmovaps xmm1, [rsp+0x10]
00007fb1689e29a5  vmovaps xmm2, [rsp+0x20]
00007fb1689e29ab  vmovaps xmm3, [rsp+0x30]
00007fb1689e29b1  vmovaps xmm4, [rsp+0x40]
00007fb1689e29b7  vmovaps xmm5, [rsp+0x50]
00007fb1689e29bd  vmovaps xmm6, [rsp+0x60]
00007fb1689e29c3  vmovaps xmm7, [rsp+0x70]
00007fb1689e29c9  vmovaps xmm8, [rsp+0x80]
00007fb1689e29d2  vmovaps xmm9, [rsp+0x90]
00007fb1689e29db  vmovaps xmm10, [rsp+0xA0]
00007fb1689e29e4  vmovaps xmm11, [rsp+0xB0]
00007fb1689e29ed  vmovaps xmm12, [rsp+0xC0]
00007fb1689e29f6  vmovaps xmm13, [rsp+0xD0]
00007fb1689e29ff  vmovaps xmm15, [rsp+0xE0]
00007fb1689e2a08  add rsp, 0xF0
00007fb1689e2a0f  pop r11
00007fb1689e2a11  pop r10
00007fb1689e2a13  pop r9
00007fb1689e2a15  pop r8
00007fb1689e2a17  pop rsi
00007fb1689e2a18  pop rdi
00007fb1689e2a19  pop rdx
00007fb1689e2a1a  pop rcx
00007fb1689e2a1b  pop rax
00007fb1689e2a1c  add rsp, 0x08
00007fb1689e2a20  jmp 0x00007FB1689DF5F8
00007fb1689e2a25  sub rsp, 0x08
00007fb1689e2a29  push rax
00007fb1689e2a2a  push rcx
00007fb1689e2a2b  push rdx
00007fb1689e2a2c  push rdi
00007fb1689e2a2d  push rsi
00007fb1689e2a2e  push r8
00007fb1689e2a30  push r9
00007fb1689e2a32  push r10
00007fb1689e2a34  push r11
00007fb1689e2a36  sub rsp, 0xF0
00007fb1689e2a3d  vmovaps [rsp], xmm0
00007fb1689e2a42  vmovaps [rsp+0x10], xmm1
00007fb1689e2a48  vmovaps [rsp+0x20], xmm2
00007fb1689e2a4e  vmovaps [rsp+0x30], xmm3
00007fb1689e2a54  vmovaps [rsp+0x40], xmm5
00007fb1689e2a5a  vmovaps [rsp+0x50], xmm6
00007fb1689e2a60  vmovaps [rsp+0x60], xmm7
00007fb1689e2a66  vmovaps [rsp+0x70], xmm8
00007fb1689e2a6c  vmovaps [rsp+0x80], xmm9
00007fb1689e2a75  vmovaps [rsp+0x90], xmm10
00007fb1689e2a7e  vmovaps [rsp+0xA0], xmm11
00007fb1689e2a87  vmovaps [rsp+0xB0], xmm12
00007fb1689e2a90  vmovaps [rsp+0xC0], xmm13
00007fb1689e2a99  vmovaps [rsp+0xD0], xmm14
00007fb1689e2aa2  vmovaps [rsp+0xE0], xmm15
00007fb1689e2aab  sub rsp, 0x30
00007fb1689e2aaf  movaps [rsp], xmm4
00007fb1689e2ab3  movaps [rsp+0x10], xmm13
00007fb1689e2ab9  movaps [rsp+0x20], xmm8
00007fb1689e2abf  lea rdi, [rsp]
00007fb1689e2ac3  mov esi, 0x00
00007fb1689e2ac8  mov rax, 0x57CCFD419530
00007fb1689e2ad2  call rax
00007fb1689e2ad4  movaps xmm4, [rsp]
00007fb1689e2ad8  add rsp, 0x30
00007fb1689e2adc  vmovaps xmm0, [rsp]
00007fb1689e2ae1  vmovaps xmm1, [rsp+0x10]
00007fb1689e2ae7  vmovaps xmm2, [rsp+0x20]
00007fb1689e2aed  vmovaps xmm3, [rsp+0x30]
00007fb1689e2af3  vmovaps xmm5, [rsp+0x40]
00007fb1689e2af9  vmovaps xmm6, [rsp+0x50]
00007fb1689e2aff  vmovaps xmm7, [rsp+0x60]
00007fb1689e2b05  vmovaps xmm8, [rsp+0x70]
00007fb1689e2b0b  vmovaps xmm9, [rsp+0x80]
00007fb1689e2b14  vmovaps xmm10, [rsp+0x90]
00007fb1689e2b1d  vmovaps xmm11, [rsp+0xA0]
00007fb1689e2b26  vmovaps xmm12, [rsp+0xB0]
00007fb1689e2b2f  vmovaps xmm13, [rsp+0xC0]
00007fb1689e2b38  vmovaps xmm14, [rsp+0xD0]
00007fb1689e2b41  vmovaps xmm15, [rsp+0xE0]
00007fb1689e2b4a  add rsp, 0xF0
00007fb1689e2b51  pop r11
00007fb1689e2b53  pop r10
00007fb1689e2b55  pop r9
00007fb1689e2b57  pop r8
00007fb1689e2b59  pop rsi
00007fb1689e2b5a  pop rdi
00007fb1689e2b5b  pop rdx
00007fb1689e2b5c  pop rcx
00007fb1689e2b5d  pop rax
00007fb1689e2b5e  add rsp, 0x08
00007fb1689e2b62  jmp 0x00007FB1689DF61D
00007fb1689e2b67  sub rsp, 0x08
00007fb1689e2b6b  push rax
00007fb1689e2b6c  push rcx
00007fb1689e2b6d  push rdx
00007fb1689e2b6e  push rdi
00007fb1689e2b6f  push rsi
00007fb1689e2b70  push r8
00007fb1689e2b72  push r9
00007fb1689e2b74  push r10
00007fb1689e2b76  push r11
00007fb1689e2b78  sub rsp, 0xF0
00007fb1689e2b7f  vmovaps [rsp], xmm0
00007fb1689e2b84  vmovaps [rsp+0x10], xmm1
00007fb1689e2b8a  vmovaps [rsp+0x20], xmm2
00007fb1689e2b90  vmovaps [rsp+0x30], xmm3
00007fb1689e2b96  vmovaps [rsp+0x40], xmm4
00007fb1689e2b9c  vmovaps [rsp+0x50], xmm5
00007fb1689e2ba2  vmovaps [rsp+0x60], xmm6
00007fb1689e2ba8  vmovaps [rsp+0x70], xmm7
00007fb1689e2bae  vmovaps [rsp+0x80], xmm8
00007fb1689e2bb7  vmovaps [rsp+0x90], xmm9
00007fb1689e2bc0  vmovaps [rsp+0xA0], xmm10
00007fb1689e2bc9  vmovaps [rsp+0xB0], xmm11
00007fb1689e2bd2  vmovaps [rsp+0xC0], xmm12
00007fb1689e2bdb  vmovaps [rsp+0xD0], xmm14
00007fb1689e2be4  vmovaps [rsp+0xE0], xmm15
00007fb1689e2bed  sub rsp, 0x30
00007fb1689e2bf1  movaps [rsp], xmm13
00007fb1689e2bf6  movaps [rsp+0x10], xmm15
00007fb1689e2bfc  movaps [rsp+0x20], xmm9
00007fb1689e2c02  lea rdi, [rsp]
00007fb1689e2c06  mov esi, 0x00
00007fb1689e2c0b  mov rax, 0x57CCFD419530
00007fb1689e2c15  call rax
00007fb1689e2c17  movaps xmm13, [rsp]
00007fb1689e2c1c  add rsp, 0x30
00007fb1689e2c20  vmovaps xmm0, [rsp]
00007fb1689e2c25  vmovaps xmm1, [rsp+0x10]
00007fb1689e2c2b  vmovaps xmm2, [rsp+0x20]
00007fb1689e2c31  vmovaps xmm3, [rsp+0x30]
00007fb1689e2c37  vmovaps xmm4, [rsp+0x40]
00007fb1689e2c3d  vmovaps xmm5, [rsp+0x50]
00007fb1689e2c43  vmovaps xmm6, [rsp+0x60]
00007fb1689e2c49  vmovaps xmm7, [rsp+0x70]
00007fb1689e2c4f  vmovaps xmm8, [rsp+0x80]
00007fb1689e2c58  vmovaps xmm9, [rsp+0x90]
00007fb1689e2c61  vmovaps xmm10, [rsp+0xA0]
00007fb1689e2c6a  vmovaps xmm11, [rsp+0xB0]
00007fb1689e2c73  vmovaps xmm12, [rsp+0xC0]
00007fb1689e2c7c  vmovaps xmm14, [rsp+0xD0]
00007fb1689e2c85  vmovaps xmm15, [rsp+0xE0]
00007fb1689e2c8e  add rsp, 0xF0
00007fb1689e2c95  pop r11
00007fb1689e2c97  pop r10
00007fb1689e2c99  pop r9
00007fb1689e2c9b  pop r8
00007fb1689e2c9d  pop rsi
00007fb1689e2c9e  pop rdi
00007fb1689e2c9f  pop rdx
00007fb1689e2ca0  pop rcx
00007fb1689e2ca1  pop rax
00007fb1689e2ca2  add rsp, 0x08
00007fb1689e2ca6  jmp 0x00007FB1689DF638
00007fb1689e2cab  sub rsp, 0x08
00007fb1689e2caf  push rax
00007fb1689e2cb0  push rcx
00007fb1689e2cb1  push rdx
00007fb1689e2cb2  push rdi
00007fb1689e2cb3  push rsi
00007fb1689e2cb4  push r8
00007fb1689e2cb6  push r9
00007fb1689e2cb8  push r10
00007fb1689e2cba  push r11
00007fb1689e2cbc  sub rsp, 0xF0
00007fb1689e2cc3  vmovaps [rsp], xmm0
00007fb1689e2cc8  vmovaps [rsp+0x10], xmm1
00007fb1689e2cce  vmovaps [rsp+0x20], xmm2
00007fb1689e2cd4  vmovaps [rsp+0x30], xmm3
00007fb1689e2cda  vmovaps [rsp+0x40], xmm4
00007fb1689e2ce0  vmovaps [rsp+0x50], xmm5
00007fb1689e2ce6  vmovaps [rsp+0x60], xmm6
00007fb1689e2cec  vmovaps [rsp+0x70], xmm7
00007fb1689e2cf2  vmovaps [rsp+0x80], xmm8
00007fb1689e2cfb  vmovaps [rsp+0x90], xmm9
00007fb1689e2d04  vmovaps [rsp+0xA0], xmm10
00007fb1689e2d0d  vmovaps [rsp+0xB0], xmm11
00007fb1689e2d16  vmovaps [rsp+0xC0], xmm12
00007fb1689e2d1f  vmovaps [rsp+0xD0], xmm13
00007fb1689e2d28  vmovaps [rsp+0xE0], xmm14
00007fb1689e2d31  sub rsp, 0x30
00007fb1689e2d35  movaps [rsp], xmm15
00007fb1689e2d3a  movaps [rsp+0x10], xmm1
00007fb1689e2d3f  movaps [rsp+0x20], xmm5
00007fb1689e2d44  lea rdi, [rsp]
00007fb1689e2d48  mov esi, 0x00
00007fb1689e2d4d  mov rax, 0x57CCFD419530
00007fb1689e2d57  call rax
00007fb1689e2d59  movaps xmm15, [rsp]
00007fb1689e2d5e  add rsp, 0x30
00007fb1689e2d62  vmovaps xmm0, [rsp]
00007fb1689e2d67  vmovaps xmm1, [rsp+0x10]
00007fb1689e2d6d  vmovaps xmm2, [rsp+0x20]
00007fb1689e2d73  vmovaps xmm3, [rsp+0x30]
00007fb1689e2d79  vmovaps xmm4, [rsp+0x40]
00007fb1689e2d7f  vmovaps xmm5, [rsp+0x50]
00007fb1689e2d85  vmovaps xmm6, [rsp+0x60]
00007fb1689e2d8b  vmovaps xmm7, [rsp+0x70]
00007fb1689e2d91  vmovaps xmm8, [rsp+0x80]
00007fb1689e2d9a  vmovaps xmm9, [rsp+0x90]
00007fb1689e2da3  vmovaps xmm10, [rsp+0xA0]
00007fb1689e2dac  vmovaps xmm11, [rsp+0xB0]
00007fb1689e2db5  vmovaps xmm12, [rsp+0xC0]
00007fb1689e2dbe  vmovaps xmm13, [rsp+0xD0]
00007fb1689e2dc7  vmovaps xmm14, [rsp+0xE0]
00007fb1689e2dd0  add rsp, 0xF0
00007fb1689e2dd7  pop r11
00007fb1689e2dd9  pop r10
00007fb1689e2ddb  pop r9
00007fb1689e2ddd  pop r8
00007fb1689e2ddf  pop rsi
00007fb1689e2de0  pop rdi
00007fb1689e2de1  pop rdx
00007fb1689e2de2  pop rcx
00007fb1689e2de3  pop rax
00007fb1689e2de4  add rsp, 0x08
00007fb1689e2de8  jmp 0x00007FB1689DF653
00007fb1689e2ded  call 0x00007FB1688B52F0
00007fb1689e2df2  jmp 0x00007FB1689DF6AE
00007fb1689e2df7  sub rsp, 0x08
00007fb1689e2dfb  push rax
00007fb1689e2dfc  push rcx
00007fb1689e2dfd  push rdx
00007fb1689e2dfe  push rdi
00007fb1689e2dff  push rsi
00007fb1689e2e00  push r8
00007fb1689e2e02  push r9
00007fb1689e2e04  push r10
00007fb1689e2e06  push r11
00007fb1689e2e08  sub rsp, 0xF0
00007fb1689e2e0f  vmovaps [rsp], xmm0
00007fb1689e2e14  vmovaps [rsp+0x10], xmm1
00007fb1689e2e1a  vmovaps [rsp+0x20], xmm2
00007fb1689e2e20  vmovaps [rsp+0x30], xmm3
00007fb1689e2e26  vmovaps [rsp+0x40], xmm4
00007fb1689e2e2c  vmovaps [rsp+0x50], xmm5
00007fb1689e2e32  vmovaps [rsp+0x60], xmm6
00007fb1689e2e38  vmovaps [rsp+0x70], xmm7
00007fb1689e2e3e  vmovaps [rsp+0x80], xmm8
00007fb1689e2e47  vmovaps [rsp+0x90], xmm10
00007fb1689e2e50  vmovaps [rsp+0xA0], xmm11
00007fb1689e2e59  vmovaps [rsp+0xB0], xmm12
00007fb1689e2e62  vmovaps [rsp+0xC0], xmm13
00007fb1689e2e6b  vmovaps [rsp+0xD0], xmm14
00007fb1689e2e74  vmovaps [rsp+0xE0], xmm15
00007fb1689e2e7d  sub rsp, 0x30
00007fb1689e2e81  movaps [rsp], xmm9
00007fb1689e2e86  movaps [rsp+0x10], xmm8
00007fb1689e2e8c  movaps [rsp+0x20], xmm11
00007fb1689e2e92  lea rdi, [rsp]
00007fb1689e2e96  mov esi, 0x00
00007fb1689e2e9b  mov rax, 0x57CCFD419530
00007fb1689e2ea5  call rax
00007fb1689e2ea7  movaps xmm9, [rsp]
00007fb1689e2eac  add rsp, 0x30
00007fb1689e2eb0  vmovaps xmm0, [rsp]
00007fb1689e2eb5  vmovaps xmm1, [rsp+0x10]
00007fb1689e2ebb  vmovaps xmm2, [rsp+0x20]
00007fb1689e2ec1  vmovaps xmm3, [rsp+0x30]
00007fb1689e2ec7  vmovaps xmm4, [rsp+0x40]
00007fb1689e2ecd  vmovaps xmm5, [rsp+0x50]
00007fb1689e2ed3  vmovaps xmm6, [rsp+0x60]
00007fb1689e2ed9  vmovaps xmm7, [rsp+0x70]
00007fb1689e2edf  vmovaps xmm8, [rsp+0x80]
00007fb1689e2ee8  vmovaps xmm10, [rsp+0x90]
00007fb1689e2ef1  vmovaps xmm11, [rsp+0xA0]
00007fb1689e2efa  vmovaps xmm12, [rsp+0xB0]
00007fb1689e2f03  vmovaps xmm13, [rsp+0xC0]
00007fb1689e2f0c  vmovaps xmm14, [rsp+0xD0]
00007fb1689e2f15  vmovaps xmm15, [rsp+0xE0]
00007fb1689e2f1e  add rsp, 0xF0
00007fb1689e2f25  pop r11
00007fb1689e2f27  pop r10
00007fb1689e2f29  pop r9
00007fb1689e2f2b  pop r8
00007fb1689e2f2d  pop rsi
00007fb1689e2f2e  pop rdi
00007fb1689e2f2f  pop rdx
00007fb1689e2f30  pop rcx
00007fb1689e2f31  pop rax
00007fb1689e2f32  add rsp, 0x08
00007fb1689e2f36  jmp 0x00007FB1689DF6E5
00007fb1689e2f3b  sub rsp, 0x08
00007fb1689e2f3f  push rax
00007fb1689e2f40  push rcx
00007fb1689e2f41  push rdx
00007fb1689e2f42  push rdi
00007fb1689e2f43  push rsi
00007fb1689e2f44  push r8
00007fb1689e2f46  push r9
00007fb1689e2f48  push r10
00007fb1689e2f4a  push r11
00007fb1689e2f4c  sub rsp, 0xF0
00007fb1689e2f53  vmovaps [rsp], xmm0
00007fb1689e2f58  vmovaps [rsp+0x10], xmm1
00007fb1689e2f5e  vmovaps [rsp+0x20], xmm2
00007fb1689e2f64  vmovaps [rsp+0x30], xmm3
00007fb1689e2f6a  vmovaps [rsp+0x40], xmm4
00007fb1689e2f70  vmovaps [rsp+0x50], xmm5
00007fb1689e2f76  vmovaps [rsp+0x60], xmm6
00007fb1689e2f7c  vmovaps [rsp+0x70], xmm7
00007fb1689e2f82  vmovaps [rsp+0x80], xmm8
00007fb1689e2f8b  vmovaps [rsp+0x90], xmm9
00007fb1689e2f94  vmovaps [rsp+0xA0], xmm10
00007fb1689e2f9d  vmovaps [rsp+0xB0], xmm12
00007fb1689e2fa6  vmovaps [rsp+0xC0], xmm13
00007fb1689e2faf  vmovaps [rsp+0xD0], xmm14
00007fb1689e2fb8  vmovaps [rsp+0xE0], xmm15
00007fb1689e2fc1  sub rsp, 0x30
00007fb1689e2fc5  movaps [rsp], xmm11
00007fb1689e2fca  movaps [rsp+0x10], xmm10
00007fb1689e2fd0  movaps [rsp+0x20], xmm6
00007fb1689e2fd5  lea rdi, [rsp]
00007fb1689e2fd9  mov esi, 0x00
00007fb1689e2fde  mov rax, 0x57CCFD419530
00007fb1689e2fe8  call rax
00007fb1689e2fea  movaps xmm11, [rsp]
00007fb1689e2fef  add rsp, 0x30
00007fb1689e2ff3  vmovaps xmm0, [rsp]
00007fb1689e2ff8  vmovaps xmm1, [rsp+0x10]
00007fb1689e2ffe  vmovaps xmm2, [rsp+0x20]
00007fb1689e3004  vmovaps xmm3, [rsp+0x30]
00007fb1689e300a  vmovaps xmm4, [rsp+0x40]
00007fb1689e3010  vmovaps xmm5, [rsp+0x50]
00007fb1689e3016  vmovaps xmm6, [rsp+0x60]
00007fb1689e301c  vmovaps xmm7, [rsp+0x70]
00007fb1689e3022  vmovaps xmm8, [rsp+0x80]
00007fb1689e302b  vmovaps xmm9, [rsp+0x90]
00007fb1689e3034  vmovaps xmm10, [rsp+0xA0]
00007fb1689e303d  vmovaps xmm12, [rsp+0xB0]
00007fb1689e3046  vmovaps xmm13, [rsp+0xC0]
00007fb1689e304f  vmovaps xmm14, [rsp+0xD0]
00007fb1689e3058  vmovaps xmm15, [rsp+0xE0]
00007fb1689e3061  add rsp, 0xF0
00007fb1689e3068  pop r11
00007fb1689e306a  pop r10
00007fb1689e306c  pop r9
00007fb1689e306e  pop r8
00007fb1689e3070  pop rsi
00007fb1689e3071  pop rdi
00007fb1689e3072  pop rdx
00007fb1689e3073  pop rcx
00007fb1689e3074  pop rax
00007fb1689e3075  add rsp, 0x08
00007fb1689e3079  jmp 0x00007FB1689DF700
00007fb1689e307e  sub rsp, 0x08
00007fb1689e3082  push rax
00007fb1689e3083  push rcx
00007fb1689e3084  push rdx
00007fb1689e3085  push rdi
00007fb1689e3086  push rsi
00007fb1689e3087  push r8
00007fb1689e3089  push r9
00007fb1689e308b  push r10
00007fb1689e308d  push r11
00007fb1689e308f  sub rsp, 0xF0
00007fb1689e3096  vmovaps [rsp], xmm0
00007fb1689e309b  vmovaps [rsp+0x10], xmm1
00007fb1689e30a1  vmovaps [rsp+0x20], xmm2
00007fb1689e30a7  vmovaps [rsp+0x30], xmm3
00007fb1689e30ad  vmovaps [rsp+0x40], xmm4
00007fb1689e30b3  vmovaps [rsp+0x50], xmm5
00007fb1689e30b9  vmovaps [rsp+0x60], xmm6
00007fb1689e30bf  vmovaps [rsp+0x70], xmm7
00007fb1689e30c5  vmovaps [rsp+0x80], xmm8
00007fb1689e30ce  vmovaps [rsp+0x90], xmm9
00007fb1689e30d7  vmovaps [rsp+0xA0], xmm11
00007fb1689e30e0  vmovaps [rsp+0xB0], xmm12
00007fb1689e30e9  vmovaps [rsp+0xC0], xmm13
00007fb1689e30f2  vmovaps [rsp+0xD0], xmm14
00007fb1689e30fb  vmovaps [rsp+0xE0], xmm15
00007fb1689e3104  sub rsp, 0x30
00007fb1689e3108  movaps [rsp], xmm10
00007fb1689e310d  movaps [rsp+0x10], xmm14
00007fb1689e3113  movaps [rsp+0x20], xmm4
00007fb1689e3118  lea rdi, [rsp]
00007fb1689e311c  mov esi, 0x00
00007fb1689e3121  mov rax, 0x57CCFD419530
00007fb1689e312b  call rax
00007fb1689e312d  movaps xmm10, [rsp]
00007fb1689e3132  add rsp, 0x30
00007fb1689e3136  vmovaps xmm0, [rsp]
00007fb1689e313b  vmovaps xmm1, [rsp+0x10]
00007fb1689e3141  vmovaps xmm2, [rsp+0x20]
00007fb1689e3147  vmovaps xmm3, [rsp+0x30]
00007fb1689e314d  vmovaps xmm4, [rsp+0x40]
00007fb1689e3153  vmovaps xmm5, [rsp+0x50]
00007fb1689e3159  vmovaps xmm6, [rsp+0x60]
00007fb1689e315f  vmovaps xmm7, [rsp+0x70]
00007fb1689e3165  vmovaps xmm8, [rsp+0x80]
00007fb1689e316e  vmovaps xmm9, [rsp+0x90]
00007fb1689e3177  vmovaps xmm11, [rsp+0xA0]
00007fb1689e3180  vmovaps xmm12, [rsp+0xB0]
00007fb1689e3189  vmovaps xmm13, [rsp+0xC0]
00007fb1689e3192  vmovaps xmm14, [rsp+0xD0]
00007fb1689e319b  vmovaps xmm15, [rsp+0xE0]
00007fb1689e31a4  add rsp, 0xF0
00007fb1689e31ab  pop r11
00007fb1689e31ad  pop r10
00007fb1689e31af  pop r9
00007fb1689e31b1  pop r8
00007fb1689e31b3  pop rsi
00007fb1689e31b4  pop rdi
00007fb1689e31b5  pop rdx
00007fb1689e31b6  pop rcx
00007fb1689e31b7  pop rax
00007fb1689e31b8  add rsp, 0x08
00007fb1689e31bc  jmp 0x00007FB1689DF71B
00007fb1689e31c1  sub rsp, 0x08
00007fb1689e31c5  push rax
00007fb1689e31c6  push rcx
00007fb1689e31c7  push rdx
00007fb1689e31c8  push rdi
00007fb1689e31c9  push rsi
00007fb1689e31ca  push r8
00007fb1689e31cc  push r9
00007fb1689e31ce  push r10
00007fb1689e31d0  push r11
00007fb1689e31d2  sub rsp, 0xF0
00007fb1689e31d9  vmovaps [rsp], xmm0
00007fb1689e31de  vmovaps [rsp+0x10], xmm1
00007fb1689e31e4  vmovaps [rsp+0x20], xmm2
00007fb1689e31ea  vmovaps [rsp+0x30], xmm3
00007fb1689e31f0  vmovaps [rsp+0x40], xmm4
00007fb1689e31f6  vmovaps [rsp+0x50], xmm5
00007fb1689e31fc  vmovaps [rsp+0x60], xmm6
00007fb1689e3202  vmovaps [rsp+0x70], xmm7
00007fb1689e3208  vmovaps [rsp+0x80], xmm9
00007fb1689e3211  vmovaps [rsp+0x90], xmm10
00007fb1689e321a  vmovaps [rsp+0xA0], xmm11
00007fb1689e3223  vmovaps [rsp+0xB0], xmm12
00007fb1689e322c  vmovaps [rsp+0xC0], xmm13
00007fb1689e3235  vmovaps [rsp+0xD0], xmm14
00007fb1689e323e  vmovaps [rsp+0xE0], xmm15
00007fb1689e3247  sub rsp, 0x30
00007fb1689e324b  movaps [rsp], xmm8
00007fb1689e3250  movaps [rsp+0x10], xmm1
00007fb1689e3255  movaps [rsp+0x20], xmm14
00007fb1689e325b  lea rdi, [rsp]
00007fb1689e325f  mov esi, 0x00
00007fb1689e3264  mov rax, 0x57CCFD419530
00007fb1689e326e  call rax
00007fb1689e3270  movaps xmm8, [rsp]
00007fb1689e3275  add rsp, 0x30
00007fb1689e3279  vmovaps xmm0, [rsp]
00007fb1689e327e  vmovaps xmm1, [rsp+0x10]
00007fb1689e3284  vmovaps xmm2, [rsp+0x20]
00007fb1689e328a  vmovaps xmm3, [rsp+0x30]
00007fb1689e3290  vmovaps xmm4, [rsp+0x40]
00007fb1689e3296  vmovaps xmm5, [rsp+0x50]
00007fb1689e329c  vmovaps xmm6, [rsp+0x60]
00007fb1689e32a2  vmovaps xmm7, [rsp+0x70]
00007fb1689e32a8  vmovaps xmm9, [rsp+0x80]
00007fb1689e32b1  vmovaps xmm10, [rsp+0x90]
00007fb1689e32ba  vmovaps xmm11, [rsp+0xA0]
00007fb1689e32c3  vmovaps xmm12, [rsp+0xB0]
00007fb1689e32cc  vmovaps xmm13, [rsp+0xC0]
00007fb1689e32d5  vmovaps xmm14, [rsp+0xD0]
00007fb1689e32de  vmovaps xmm15, [rsp+0xE0]
00007fb1689e32e7  add rsp, 0xF0
00007fb1689e32ee  pop r11
00007fb1689e32f0  pop r10
00007fb1689e32f2  pop r9
00007fb1689e32f4  pop r8
00007fb1689e32f6  pop rsi
00007fb1689e32f7  pop rdi
00007fb1689e32f8  pop rdx
00007fb1689e32f9  pop rcx
00007fb1689e32fa  pop rax
00007fb1689e32fb  add rsp, 0x08
00007fb1689e32ff  jmp 0x00007FB1689DF741
00007fb1689e3304  sub rsp, 0x08
00007fb1689e3308  push rax
00007fb1689e3309  push rcx
00007fb1689e330a  push rdx
00007fb1689e330b  push rdi
00007fb1689e330c  push rsi
00007fb1689e330d  push r8
00007fb1689e330f  push r9
00007fb1689e3311  push r10
00007fb1689e3313  push r11
00007fb1689e3315  sub rsp, 0xF0
00007fb1689e331c  vmovaps [rsp], xmm0
00007fb1689e3321  vmovaps [rsp+0x10], xmm1
00007fb1689e3327  vmovaps [rsp+0x20], xmm2
00007fb1689e332d  vmovaps [rsp+0x30], xmm3
00007fb1689e3333  vmovaps [rsp+0x40], xmm4
00007fb1689e3339  vmovaps [rsp+0x50], xmm5
00007fb1689e333f  vmovaps [rsp+0x60], xmm7
00007fb1689e3345  vmovaps [rsp+0x70], xmm8
00007fb1689e334b  vmovaps [rsp+0x80], xmm9
00007fb1689e3354  vmovaps [rsp+0x90], xmm10
00007fb1689e335d  vmovaps [rsp+0xA0], xmm11
00007fb1689e3366  vmovaps [rsp+0xB0], xmm12
00007fb1689e336f  vmovaps [rsp+0xC0], xmm13
00007fb1689e3378  vmovaps [rsp+0xD0], xmm14
00007fb1689e3381  vmovaps [rsp+0xE0], xmm15
00007fb1689e338a  sub rsp, 0x30
00007fb1689e338e  movaps [rsp], xmm6
00007fb1689e3392  movaps [rsp+0x10], xmm1
00007fb1689e3397  movaps [rsp+0x20], xmm14
00007fb1689e339d  lea rdi, [rsp]
00007fb1689e33a1  mov esi, 0x00
00007fb1689e33a6  mov rax, 0x57CCFD419530
00007fb1689e33b0  call rax
00007fb1689e33b2  movaps xmm6, [rsp]
00007fb1689e33b6  add rsp, 0x30
00007fb1689e33ba  vmovaps xmm0, [rsp]
00007fb1689e33bf  vmovaps xmm1, [rsp+0x10]
00007fb1689e33c5  vmovaps xmm2, [rsp+0x20]
00007fb1689e33cb  vmovaps xmm3, [rsp+0x30]
00007fb1689e33d1  vmovaps xmm4, [rsp+0x40]
00007fb1689e33d7  vmovaps xmm5, [rsp+0x50]
00007fb1689e33dd  vmovaps xmm7, [rsp+0x60]
00007fb1689e33e3  vmovaps xmm8, [rsp+0x70]
00007fb1689e33e9  vmovaps xmm9, [rsp+0x80]
00007fb1689e33f2  vmovaps xmm10, [rsp+0x90]
00007fb1689e33fb  vmovaps xmm11, [rsp+0xA0]
00007fb1689e3404  vmovaps xmm12, [rsp+0xB0]
00007fb1689e340d  vmovaps xmm13, [rsp+0xC0]
00007fb1689e3416  vmovaps xmm14, [rsp+0xD0]
00007fb1689e341f  vmovaps xmm15, [rsp+0xE0]
00007fb1689e3428  add rsp, 0xF0
00007fb1689e342f  pop r11
00007fb1689e3431  pop r10
00007fb1689e3433  pop r9
00007fb1689e3435  pop r8
00007fb1689e3437  pop rsi
00007fb1689e3438  pop rdi
00007fb1689e3439  pop rdx
00007fb1689e343a  pop rcx
00007fb1689e343b  pop rax
00007fb1689e343c  add rsp, 0x08
00007fb1689e3440  jmp 0x00007FB1689DF76D
00007fb1689e3445  sub rsp, 0x08
00007fb1689e3449  push rax
00007fb1689e344a  push rcx
00007fb1689e344b  push rdx
00007fb1689e344c  push rdi
00007fb1689e344d  push rsi
00007fb1689e344e  push r8
00007fb1689e3450  push r9
00007fb1689e3452  push r10
00007fb1689e3454  push r11
00007fb1689e3456  sub rsp, 0xF0
00007fb1689e345d  vmovaps [rsp], xmm0
00007fb1689e3462  vmovaps [rsp+0x10], xmm1
00007fb1689e3468  vmovaps [rsp+0x20], xmm2
00007fb1689e346e  vmovaps [rsp+0x30], xmm3
00007fb1689e3474  vmovaps [rsp+0x40], xmm4
00007fb1689e347a  vmovaps [rsp+0x50], xmm5
00007fb1689e3480  vmovaps [rsp+0x60], xmm6
00007fb1689e3486  vmovaps [rsp+0x70], xmm7
00007fb1689e348c  vmovaps [rsp+0x80], xmm8
00007fb1689e3495  vmovaps [rsp+0x90], xmm9
00007fb1689e349e  vmovaps [rsp+0xA0], xmm10
00007fb1689e34a7  vmovaps [rsp+0xB0], xmm11
00007fb1689e34b0  vmovaps [rsp+0xC0], xmm12
00007fb1689e34b9  vmovaps [rsp+0xD0], xmm13
00007fb1689e34c2  vmovaps [rsp+0xE0], xmm15
00007fb1689e34cb  sub rsp, 0x30
00007fb1689e34cf  movaps [rsp], xmm14
00007fb1689e34d4  movaps [rsp+0x10], xmm12
00007fb1689e34da  movaps [rsp+0x20], xmm1
00007fb1689e34df  lea rdi, [rsp]
00007fb1689e34e3  mov esi, 0x00
00007fb1689e34e8  mov rax, 0x57CCFD419530
00007fb1689e34f2  call rax
00007fb1689e34f4  movaps xmm14, [rsp]
00007fb1689e34f9  add rsp, 0x30
00007fb1689e34fd  vmovaps xmm0, [rsp]
00007fb1689e3502  vmovaps xmm1, [rsp+0x10]
00007fb1689e3508  vmovaps xmm2, [rsp+0x20]
00007fb1689e350e  vmovaps xmm3, [rsp+0x30]
00007fb1689e3514  vmovaps xmm4, [rsp+0x40]
00007fb1689e351a  vmovaps xmm5, [rsp+0x50]
00007fb1689e3520  vmovaps xmm6, [rsp+0x60]
00007fb1689e3526  vmovaps xmm7, [rsp+0x70]
00007fb1689e352c  vmovaps xmm8, [rsp+0x80]
00007fb1689e3535  vmovaps xmm9, [rsp+0x90]
00007fb1689e353e  vmovaps xmm10, [rsp+0xA0]
00007fb1689e3547  vmovaps xmm11, [rsp+0xB0]
00007fb1689e3550  vmovaps xmm12, [rsp+0xC0]
00007fb1689e3559  vmovaps xmm13, [rsp+0xD0]
00007fb1689e3562  vmovaps xmm15, [rsp+0xE0]
00007fb1689e356b  add rsp, 0xF0
00007fb1689e3572  pop r11
00007fb1689e3574  pop r10
00007fb1689e3576  pop r9
00007fb1689e3578  pop r8
00007fb1689e357a  pop rsi
00007fb1689e357b  pop rdi
00007fb1689e357c  pop rdx
00007fb1689e357d  pop rcx
00007fb1689e357e  pop rax
00007fb1689e357f  add rsp, 0x08
00007fb1689e3583  jmp 0x00007FB1689DF793
00007fb1689e3588  sub rsp, 0x08
00007fb1689e358c  push rax
00007fb1689e358d  push rcx
00007fb1689e358e  push rdx
00007fb1689e358f  push rdi
00007fb1689e3590  push rsi
00007fb1689e3591  push r8
00007fb1689e3593  push r9
00007fb1689e3595  push r10
00007fb1689e3597  push r11
00007fb1689e3599  sub rsp, 0xF0
00007fb1689e35a0  vmovaps [rsp], xmm0
00007fb1689e35a5  vmovaps [rsp+0x10], xmm2
00007fb1689e35ab  vmovaps [rsp+0x20], xmm3
00007fb1689e35b1  vmovaps [rsp+0x30], xmm4
00007fb1689e35b7  vmovaps [rsp+0x40], xmm5
00007fb1689e35bd  vmovaps [rsp+0x50], xmm6
00007fb1689e35c3  vmovaps [rsp+0x60], xmm7
00007fb1689e35c9  vmovaps [rsp+0x70], xmm8
00007fb1689e35cf  vmovaps [rsp+0x80], xmm9
00007fb1689e35d8  vmovaps [rsp+0x90], xmm10
00007fb1689e35e1  vmovaps [rsp+0xA0], xmm11
00007fb1689e35ea  vmovaps [rsp+0xB0], xmm12
00007fb1689e35f3  vmovaps [rsp+0xC0], xmm13
00007fb1689e35fc  vmovaps [rsp+0xD0], xmm14
00007fb1689e3605  vmovaps [rsp+0xE0], xmm15
00007fb1689e360e  sub rsp, 0x30
00007fb1689e3612  movaps [rsp], xmm1
00007fb1689e3616  movaps [rsp+0x10], xmm13
00007fb1689e361c  movaps [rsp+0x20], xmm9
00007fb1689e3622  lea rdi, [rsp]
00007fb1689e3626  mov esi, 0x00
00007fb1689e362b  mov rax, 0x57CCFD419530
00007fb1689e3635  call rax
00007fb1689e3637  movaps xmm1, [rsp]
00007fb1689e363b  add rsp, 0x30
00007fb1689e363f  vmovaps xmm0, [rsp]
00007fb1689e3644  vmovaps xmm2, [rsp+0x10]
00007fb1689e364a  vmovaps xmm3, [rsp+0x20]
00007fb1689e3650  vmovaps xmm4, [rsp+0x30]
00007fb1689e3656  vmovaps xmm5, [rsp+0x40]
00007fb1689e365c  vmovaps xmm6, [rsp+0x50]
00007fb1689e3662  vmovaps xmm7, [rsp+0x60]
00007fb1689e3668  vmovaps xmm8, [rsp+0x70]
00007fb1689e366e  vmovaps xmm9, [rsp+0x80]
00007fb1689e3677  vmovaps xmm10, [rsp+0x90]
00007fb1689e3680  vmovaps xmm11, [rsp+0xA0]
00007fb1689e3689  vmovaps xmm12, [rsp+0xB0]
00007fb1689e3692  vmovaps xmm13, [rsp+0xC0]
00007fb1689e369b  vmovaps xmm14, [rsp+0xD0]
00007fb1689e36a4  vmovaps xmm15, [rsp+0xE0]
00007fb1689e36ad  add rsp, 0xF0
00007fb1689e36b4  pop r11
00007fb1689e36b6  pop r10
00007fb1689e36b8  pop r9
00007fb1689e36ba  pop r8
00007fb1689e36bc  pop rsi
00007fb1689e36bd  pop rdi
00007fb1689e36be  pop rdx
00007fb1689e36bf  pop rcx
00007fb1689e36c0  pop rax
00007fb1689e36c1  add rsp, 0x08
00007fb1689e36c5  jmp 0x00007FB1689DF7AD
00007fb1689e36ca  sub rsp, 0x08
00007fb1689e36ce  push rax
00007fb1689e36cf  push rcx
00007fb1689e36d0  push rdx
00007fb1689e36d1  push rdi
00007fb1689e36d2  push rsi
00007fb1689e36d3  push r8
00007fb1689e36d5  push r9
00007fb1689e36d7  push r10
00007fb1689e36d9  push r11
00007fb1689e36db  sub rsp, 0xF0
00007fb1689e36e2  vmovaps [rsp], xmm0
00007fb1689e36e7  vmovaps [rsp+0x10], xmm1
00007fb1689e36ed  vmovaps [rsp+0x20], xmm2
00007fb1689e36f3  vmovaps [rsp+0x30], xmm3
00007fb1689e36f9  vmovaps [rsp+0x40], xmm4
00007fb1689e36ff  vmovaps [rsp+0x50], xmm5
00007fb1689e3705  vmovaps [rsp+0x60], xmm6
00007fb1689e370b  vmovaps [rsp+0x70], xmm7
00007fb1689e3711  vmovaps [rsp+0x80], xmm8
00007fb1689e371a  vmovaps [rsp+0x90], xmm9
00007fb1689e3723  vmovaps [rsp+0xA0], xmm10
00007fb1689e372c  vmovaps [rsp+0xB0], xmm11
00007fb1689e3735  vmovaps [rsp+0xC0], xmm13
00007fb1689e373e  vmovaps [rsp+0xD0], xmm14
00007fb1689e3747  vmovaps [rsp+0xE0], xmm15
00007fb1689e3750  sub rsp, 0x30
00007fb1689e3754  movaps [rsp], xmm12
00007fb1689e3759  movaps [rsp+0x10], xmm7
00007fb1689e375e  movaps [rsp+0x20], xmm13
00007fb1689e3764  lea rdi, [rsp]
00007fb1689e3768  mov esi, 0x00
00007fb1689e376d  mov rax, 0x57CCFD419530
00007fb1689e3777  call rax
00007fb1689e3779  movaps xmm12, [rsp]
00007fb1689e377e  add rsp, 0x30
00007fb1689e3782  vmovaps xmm0, [rsp]
00007fb1689e3787  vmovaps xmm1, [rsp+0x10]
00007fb1689e378d  vmovaps xmm2, [rsp+0x20]
00007fb1689e3793  vmovaps xmm3, [rsp+0x30]
00007fb1689e3799  vmovaps xmm4, [rsp+0x40]
00007fb1689e379f  vmovaps xmm5, [rsp+0x50]
00007fb1689e37a5  vmovaps xmm6, [rsp+0x60]
00007fb1689e37ab  vmovaps xmm7, [rsp+0x70]
00007fb1689e37b1  vmovaps xmm8, [rsp+0x80]
00007fb1689e37ba  vmovaps xmm9, [rsp+0x90]
00007fb1689e37c3  vmovaps xmm10, [rsp+0xA0]
00007fb1689e37cc  vmovaps xmm11, [rsp+0xB0]
00007fb1689e37d5  vmovaps xmm13, [rsp+0xC0]
00007fb1689e37de  vmovaps xmm14, [rsp+0xD0]
00007fb1689e37e7  vmovaps xmm15, [rsp+0xE0]
00007fb1689e37f0  add rsp, 0xF0
00007fb1689e37f7  pop r11
00007fb1689e37f9  pop r10
00007fb1689e37fb  pop r9
00007fb1689e37fd  pop r8
00007fb1689e37ff  pop rsi
00007fb1689e3800  pop rdi
00007fb1689e3801  pop rdx
00007fb1689e3802  pop rcx
00007fb1689e3803  pop rax
00007fb1689e3804  add rsp, 0x08
00007fb1689e3808  jmp 0x00007FB1689DF7D4
00007fb1689e380d  sub rsp, 0x08
00007fb1689e3811  push rax
00007fb1689e3812  push rcx
00007fb1689e3813  push rdx
00007fb1689e3814  push rdi
00007fb1689e3815  push rsi
00007fb1689e3816  push r8
00007fb1689e3818  push r9
00007fb1689e381a  push r10
00007fb1689e381c  push r11
00007fb1689e381e  sub rsp, 0xF0
00007fb1689e3825  vmovaps [rsp], xmm0
00007fb1689e382a  vmovaps [rsp+0x10], xmm1
00007fb1689e3830  vmovaps [rsp+0x20], xmm2
00007fb1689e3836  vmovaps [rsp+0x30], xmm3
00007fb1689e383c  vmovaps [rsp+0x40], xmm4
00007fb1689e3842  vmovaps [rsp+0x50], xmm5
00007fb1689e3848  vmovaps [rsp+0x60], xmm6
00007fb1689e384e  vmovaps [rsp+0x70], xmm7
00007fb1689e3854  vmovaps [rsp+0x80], xmm8
00007fb1689e385d  vmovaps [rsp+0x90], xmm9
00007fb1689e3866  vmovaps [rsp+0xA0], xmm10
00007fb1689e386f  vmovaps [rsp+0xB0], xmm11
00007fb1689e3878  vmovaps [rsp+0xC0], xmm12
00007fb1689e3881  vmovaps [rsp+0xD0], xmm14
00007fb1689e388a  vmovaps [rsp+0xE0], xmm15
00007fb1689e3893  sub rsp, 0x30
00007fb1689e3897  movaps [rsp], xmm13
00007fb1689e389c  movaps [rsp+0x10], xmm15
00007fb1689e38a2  movaps [rsp+0x20], xmm8
00007fb1689e38a8  lea rdi, [rsp]
00007fb1689e38ac  mov esi, 0x00
00007fb1689e38b1  mov rax, 0x57CCFD419530
00007fb1689e38bb  call rax
00007fb1689e38bd  movaps xmm13, [rsp]
00007fb1689e38c2  add rsp, 0x30
00007fb1689e38c6  vmovaps xmm0, [rsp]
00007fb1689e38cb  vmovaps xmm1, [rsp+0x10]
00007fb1689e38d1  vmovaps xmm2, [rsp+0x20]
00007fb1689e38d7  vmovaps xmm3, [rsp+0x30]
00007fb1689e38dd  vmovaps xmm4, [rsp+0x40]
00007fb1689e38e3  vmovaps xmm5, [rsp+0x50]
00007fb1689e38e9  vmovaps xmm6, [rsp+0x60]
00007fb1689e38ef  vmovaps xmm7, [rsp+0x70]
00007fb1689e38f5  vmovaps xmm8, [rsp+0x80]
00007fb1689e38fe  vmovaps xmm9, [rsp+0x90]
00007fb1689e3907  vmovaps xmm10, [rsp+0xA0]
00007fb1689e3910  vmovaps xmm11, [rsp+0xB0]
00007fb1689e3919  vmovaps xmm12, [rsp+0xC0]
00007fb1689e3922  vmovaps xmm14, [rsp+0xD0]
00007fb1689e392b  vmovaps xmm15, [rsp+0xE0]
00007fb1689e3934  add rsp, 0xF0
00007fb1689e393b  pop r11
00007fb1689e393d  pop r10
00007fb1689e393f  pop r9
00007fb1689e3941  pop r8
00007fb1689e3943  pop rsi
00007fb1689e3944  pop rdi
00007fb1689e3945  pop rdx
00007fb1689e3946  pop rcx
00007fb1689e3947  pop rax
00007fb1689e3948  add rsp, 0x08
00007fb1689e394c  jmp 0x00007FB1689DF7EF
00007fb1689e3951  sub rsp, 0x08
00007fb1689e3955  push rax
00007fb1689e3956  push rcx
00007fb1689e3957  push rdx
00007fb1689e3958  push rdi
00007fb1689e3959  push rsi
00007fb1689e395a  push r8
00007fb1689e395c  push r9
00007fb1689e395e  push r10
00007fb1689e3960  push r11
00007fb1689e3962  sub rsp, 0xF0
00007fb1689e3969  vmovaps [rsp], xmm0
00007fb1689e396e  vmovaps [rsp+0x10], xmm1
00007fb1689e3974  vmovaps [rsp+0x20], xmm2
00007fb1689e397a  vmovaps [rsp+0x30], xmm3
00007fb1689e3980  vmovaps [rsp+0x40], xmm4
00007fb1689e3986  vmovaps [rsp+0x50], xmm5
00007fb1689e398c  vmovaps [rsp+0x60], xmm6
00007fb1689e3992  vmovaps [rsp+0x70], xmm7
00007fb1689e3998  vmovaps [rsp+0x80], xmm9
00007fb1689e39a1  vmovaps [rsp+0x90], xmm10
00007fb1689e39aa  vmovaps [rsp+0xA0], xmm11
00007fb1689e39b3  vmovaps [rsp+0xB0], xmm12
00007fb1689e39bc  vmovaps [rsp+0xC0], xmm13
00007fb1689e39c5  vmovaps [rsp+0xD0], xmm14
00007fb1689e39ce  vmovaps [rsp+0xE0], xmm15
00007fb1689e39d7  sub rsp, 0x30
00007fb1689e39db  movaps [rsp], xmm8
00007fb1689e39e0  movaps [rsp+0x10], xmm15
00007fb1689e39e6  movaps [rsp+0x20], xmm9
00007fb1689e39ec  lea rdi, [rsp]
00007fb1689e39f0  mov esi, 0x00
00007fb1689e39f5  mov rax, 0x57CCFD419530
00007fb1689e39ff  call rax
00007fb1689e3a01  movaps xmm8, [rsp]
00007fb1689e3a06  add rsp, 0x30
00007fb1689e3a0a  vmovaps xmm0, [rsp]
00007fb1689e3a0f  vmovaps xmm1, [rsp+0x10]
00007fb1689e3a15  vmovaps xmm2, [rsp+0x20]
00007fb1689e3a1b  vmovaps xmm3, [rsp+0x30]
00007fb1689e3a21  vmovaps xmm4, [rsp+0x40]
00007fb1689e3a27  vmovaps xmm5, [rsp+0x50]
00007fb1689e3a2d  vmovaps xmm6, [rsp+0x60]
00007fb1689e3a33  vmovaps xmm7, [rsp+0x70]
00007fb1689e3a39  vmovaps xmm9, [rsp+0x80]
00007fb1689e3a42  vmovaps xmm10, [rsp+0x90]
00007fb1689e3a4b  vmovaps xmm11, [rsp+0xA0]
00007fb1689e3a54  vmovaps xmm12, [rsp+0xB0]
00007fb1689e3a5d  vmovaps xmm13, [rsp+0xC0]
00007fb1689e3a66  vmovaps xmm14, [rsp+0xD0]
00007fb1689e3a6f  vmovaps xmm15, [rsp+0xE0]
00007fb1689e3a78  add rsp, 0xF0
00007fb1689e3a7f  pop r11
00007fb1689e3a81  pop r10
00007fb1689e3a83  pop r9
00007fb1689e3a85  pop r8
00007fb1689e3a87  pop rsi
00007fb1689e3a88  pop rdi
00007fb1689e3a89  pop rdx
00007fb1689e3a8a  pop rcx
00007fb1689e3a8b  pop rax
00007fb1689e3a8c  add rsp, 0x08
00007fb1689e3a90  jmp 0x00007FB1689DF81D
00007fb1689e3a95  sub rsp, 0x08
00007fb1689e3a99  push rax
00007fb1689e3a9a  push rcx
00007fb1689e3a9b  push rdx
00007fb1689e3a9c  push rdi
00007fb1689e3a9d  push rsi
00007fb1689e3a9e  push r8
00007fb1689e3aa0  push r9
00007fb1689e3aa2  push r10
00007fb1689e3aa4  push r11
00007fb1689e3aa6  sub rsp, 0xF0
00007fb1689e3aad  vmovaps [rsp], xmm0
00007fb1689e3ab2  vmovaps [rsp+0x10], xmm1
00007fb1689e3ab8  vmovaps [rsp+0x20], xmm2
00007fb1689e3abe  vmovaps [rsp+0x30], xmm3
00007fb1689e3ac4  vmovaps [rsp+0x40], xmm4
00007fb1689e3aca  vmovaps [rsp+0x50], xmm5
00007fb1689e3ad0  vmovaps [rsp+0x60], xmm6
00007fb1689e3ad6  vmovaps [rsp+0x70], xmm7
00007fb1689e3adc  vmovaps [rsp+0x80], xmm8
00007fb1689e3ae5  vmovaps [rsp+0x90], xmm9
00007fb1689e3aee  vmovaps [rsp+0xA0], xmm10
00007fb1689e3af7  vmovaps [rsp+0xB0], xmm11
00007fb1689e3b00  vmovaps [rsp+0xC0], xmm12
00007fb1689e3b09  vmovaps [rsp+0xD0], xmm13
00007fb1689e3b12  vmovaps [rsp+0xE0], xmm14
00007fb1689e3b1b  sub rsp, 0x30
00007fb1689e3b1f  movaps [rsp], xmm15
00007fb1689e3b24  movaps [rsp+0x10], xmm11
00007fb1689e3b2a  movaps [rsp+0x20], xmm6
00007fb1689e3b2f  lea rdi, [rsp]
00007fb1689e3b33  mov esi, 0x00
00007fb1689e3b38  mov rax, 0x57CCFD419530
00007fb1689e3b42  call rax
00007fb1689e3b44  movaps xmm15, [rsp]
00007fb1689e3b49  add rsp, 0x30
00007fb1689e3b4d  vmovaps xmm0, [rsp]
00007fb1689e3b52  vmovaps xmm1, [rsp+0x10]
00007fb1689e3b58  vmovaps xmm2, [rsp+0x20]
00007fb1689e3b5e  vmovaps xmm3, [rsp+0x30]
00007fb1689e3b64  vmovaps xmm4, [rsp+0x40]
00007fb1689e3b6a  vmovaps xmm5, [rsp+0x50]
00007fb1689e3b70  vmovaps xmm6, [rsp+0x60]
00007fb1689e3b76  vmovaps xmm7, [rsp+0x70]
00007fb1689e3b7c  vmovaps xmm8, [rsp+0x80]
00007fb1689e3b85  vmovaps xmm9, [rsp+0x90]
00007fb1689e3b8e  vmovaps xmm10, [rsp+0xA0]
00007fb1689e3b97  vmovaps xmm11, [rsp+0xB0]
00007fb1689e3ba0  vmovaps xmm12, [rsp+0xC0]
00007fb1689e3ba9  vmovaps xmm13, [rsp+0xD0]
00007fb1689e3bb2  vmovaps xmm14, [rsp+0xE0]
00007fb1689e3bbb  add rsp, 0xF0
00007fb1689e3bc2  pop r11
00007fb1689e3bc4  pop r10
00007fb1689e3bc6  pop r9
00007fb1689e3bc8  pop r8
00007fb1689e3bca  pop rsi
00007fb1689e3bcb  pop rdi
00007fb1689e3bcc  pop rdx
00007fb1689e3bcd  pop rcx
00007fb1689e3bce  pop rax
00007fb1689e3bcf  add rsp, 0x08
00007fb1689e3bd3  jmp 0x00007FB1689DF838
00007fb1689e3bd8  sub rsp, 0x08
00007fb1689e3bdc  push rax
00007fb1689e3bdd  push rcx
00007fb1689e3bde  push rdx
00007fb1689e3bdf  push rdi
00007fb1689e3be0  push rsi
00007fb1689e3be1  push r8
00007fb1689e3be3  push r9
00007fb1689e3be5  push r10
00007fb1689e3be7  push r11
00007fb1689e3be9  sub rsp, 0xF0
00007fb1689e3bf0  vmovaps [rsp], xmm0
00007fb1689e3bf5  vmovaps [rsp+0x10], xmm1
00007fb1689e3bfb  vmovaps [rsp+0x20], xmm2
00007fb1689e3c01  vmovaps [rsp+0x30], xmm3
00007fb1689e3c07  vmovaps [rsp+0x40], xmm4
00007fb1689e3c0d  vmovaps [rsp+0x50], xmm5
00007fb1689e3c13  vmovaps [rsp+0x60], xmm6
00007fb1689e3c19  vmovaps [rsp+0x70], xmm8
00007fb1689e3c1f  vmovaps [rsp+0x80], xmm9
00007fb1689e3c28  vmovaps [rsp+0x90], xmm10
00007fb1689e3c31  vmovaps [rsp+0xA0], xmm11
00007fb1689e3c3a  vmovaps [rsp+0xB0], xmm12
00007fb1689e3c43  vmovaps [rsp+0xC0], xmm13
00007fb1689e3c4c  vmovaps [rsp+0xD0], xmm14
00007fb1689e3c55  vmovaps [rsp+0xE0], xmm15
00007fb1689e3c5e  sub rsp, 0x30
00007fb1689e3c62  movaps [rsp], xmm7
00007fb1689e3c66  movaps [rsp+0x10], xmm11
00007fb1689e3c6c  movaps [rsp+0x20], xmm9
00007fb1689e3c72  lea rdi, [rsp]
00007fb1689e3c76  mov esi, 0x00
00007fb1689e3c7b  mov rax, 0x57CCFD419530
00007fb1689e3c85  call rax
00007fb1689e3c87  movaps xmm7, [rsp]
00007fb1689e3c8b  add rsp, 0x30
00007fb1689e3c8f  vmovaps xmm0, [rsp]
00007fb1689e3c94  vmovaps xmm1, [rsp+0x10]
00007fb1689e3c9a  vmovaps xmm2, [rsp+0x20]
00007fb1689e3ca0  vmovaps xmm3, [rsp+0x30]
00007fb1689e3ca6  vmovaps xmm4, [rsp+0x40]
00007fb1689e3cac  vmovaps xmm5, [rsp+0x50]
00007fb1689e3cb2  vmovaps xmm6, [rsp+0x60]
00007fb1689e3cb8  vmovaps xmm8, [rsp+0x70]
00007fb1689e3cbe  vmovaps xmm9, [rsp+0x80]
00007fb1689e3cc7  vmovaps xmm10, [rsp+0x90]
00007fb1689e3cd0  vmovaps xmm11, [rsp+0xA0]
00007fb1689e3cd9  vmovaps xmm12, [rsp+0xB0]
00007fb1689e3ce2  vmovaps xmm13, [rsp+0xC0]
00007fb1689e3ceb  vmovaps xmm14, [rsp+0xD0]
00007fb1689e3cf4  vmovaps xmm15, [rsp+0xE0]
00007fb1689e3cfd  add rsp, 0xF0
00007fb1689e3d04  pop r11
00007fb1689e3d06  pop r10
00007fb1689e3d08  pop r9
00007fb1689e3d0a  pop r8
00007fb1689e3d0c  pop rsi
00007fb1689e3d0d  pop rdi
00007fb1689e3d0e  pop rdx
00007fb1689e3d0f  pop rcx
00007fb1689e3d10  pop rax
00007fb1689e3d11  add rsp, 0x08
00007fb1689e3d15  jmp 0x00007FB1689DF865
00007fb1689e3d1a  sub rsp, 0x08
00007fb1689e3d1e  push rax
00007fb1689e3d1f  push rcx
00007fb1689e3d20  push rdx
00007fb1689e3d21  push rdi
00007fb1689e3d22  push rsi
00007fb1689e3d23  push r8
00007fb1689e3d25  push r9
00007fb1689e3d27  push r10
00007fb1689e3d29  push r11
00007fb1689e3d2b  sub rsp, 0xF0
00007fb1689e3d32  vmovaps [rsp], xmm0
00007fb1689e3d37  vmovaps [rsp+0x10], xmm1
00007fb1689e3d3d  vmovaps [rsp+0x20], xmm2
00007fb1689e3d43  vmovaps [rsp+0x30], xmm3
00007fb1689e3d49  vmovaps [rsp+0x40], xmm4
00007fb1689e3d4f  vmovaps [rsp+0x50], xmm5
00007fb1689e3d55  vmovaps [rsp+0x60], xmm6
00007fb1689e3d5b  vmovaps [rsp+0x70], xmm7
00007fb1689e3d61  vmovaps [rsp+0x80], xmm8
00007fb1689e3d6a  vmovaps [rsp+0x90], xmm9
00007fb1689e3d73  vmovaps [rsp+0xA0], xmm10
00007fb1689e3d7c  vmovaps [rsp+0xB0], xmm12
00007fb1689e3d85  vmovaps [rsp+0xC0], xmm13
00007fb1689e3d8e  vmovaps [rsp+0xD0], xmm14
00007fb1689e3d97  vmovaps [rsp+0xE0], xmm15
00007fb1689e3da0  sub rsp, 0x30
00007fb1689e3da4  movaps [rsp], xmm11
00007fb1689e3da9  movaps [rsp+0x10], xmm10
00007fb1689e3daf  movaps [rsp+0x20], xmm14
00007fb1689e3db5  lea rdi, [rsp]
00007fb1689e3db9  mov esi, 0x00
00007fb1689e3dbe  mov rax, 0x57CCFD419530
00007fb1689e3dc8  call rax
00007fb1689e3dca  movaps xmm11, [rsp]
00007fb1689e3dcf  add rsp, 0x30
00007fb1689e3dd3  vmovaps xmm0, [rsp]
00007fb1689e3dd8  vmovaps xmm1, [rsp+0x10]
00007fb1689e3dde  vmovaps xmm2, [rsp+0x20]
00007fb1689e3de4  vmovaps xmm3, [rsp+0x30]
00007fb1689e3dea  vmovaps xmm4, [rsp+0x40]
00007fb1689e3df0  vmovaps xmm5, [rsp+0x50]
00007fb1689e3df6  vmovaps xmm6, [rsp+0x60]
00007fb1689e3dfc  vmovaps xmm7, [rsp+0x70]
00007fb1689e3e02  vmovaps xmm8, [rsp+0x80]
00007fb1689e3e0b  vmovaps xmm9, [rsp+0x90]
00007fb1689e3e14  vmovaps xmm10, [rsp+0xA0]
00007fb1689e3e1d  vmovaps xmm12, [rsp+0xB0]
00007fb1689e3e26  vmovaps xmm13, [rsp+0xC0]
00007fb1689e3e2f  vmovaps xmm14, [rsp+0xD0]
00007fb1689e3e38  vmovaps xmm15, [rsp+0xE0]
00007fb1689e3e41  add rsp, 0xF0
00007fb1689e3e48  pop r11
00007fb1689e3e4a  pop r10
00007fb1689e3e4c  pop r9
00007fb1689e3e4e  pop r8
00007fb1689e3e50  pop rsi
00007fb1689e3e51  pop rdi
00007fb1689e3e52  pop rdx
00007fb1689e3e53  pop rcx
00007fb1689e3e54  pop rax
00007fb1689e3e55  add rsp, 0x08
00007fb1689e3e59  jmp 0x00007FB1689DF880
00007fb1689e3e5e  call 0x00007FB1688C33A0
00007fb1689e3e63  jmp 0x00007FB1689DF88A
00007fb1689e3e68  sub rsp, 0x08
00007fb1689e3e6c  push rax
00007fb1689e3e6d  push rcx
00007fb1689e3e6e  push rdx
00007fb1689e3e6f  push rdi
00007fb1689e3e70  push rsi
00007fb1689e3e71  push r8
00007fb1689e3e73  push r9
00007fb1689e3e75  push r10
00007fb1689e3e77  push r11
00007fb1689e3e79  sub rsp, 0xF0
00007fb1689e3e80  vmovaps [rsp], xmm0
00007fb1689e3e85  vmovaps [rsp+0x10], xmm1
00007fb1689e3e8b  vmovaps [rsp+0x20], xmm2
00007fb1689e3e91  vmovaps [rsp+0x30], xmm3
00007fb1689e3e97  vmovaps [rsp+0x40], xmm4
00007fb1689e3e9d  vmovaps [rsp+0x50], xmm5
00007fb1689e3ea3  vmovaps [rsp+0x60], xmm6
00007fb1689e3ea9  vmovaps [rsp+0x70], xmm7
00007fb1689e3eaf  vmovaps [rsp+0x80], xmm8
00007fb1689e3eb8  vmovaps [rsp+0x90], xmm9
00007fb1689e3ec1  vmovaps [rsp+0xA0], xmm11
00007fb1689e3eca  vmovaps [rsp+0xB0], xmm12
00007fb1689e3ed3  vmovaps [rsp+0xC0], xmm13
00007fb1689e3edc  vmovaps [rsp+0xD0], xmm14
00007fb1689e3ee5  vmovaps [rsp+0xE0], xmm15
00007fb1689e3eee  sub rsp, 0x30
00007fb1689e3ef2  movaps [rsp], xmm10
00007fb1689e3ef7  movaps [rsp+0x10], xmm1
00007fb1689e3efc  movaps [rsp+0x20], xmm12
00007fb1689e3f02  lea rdi, [rsp]
00007fb1689e3f06  mov esi, 0x00
00007fb1689e3f0b  mov rax, 0x57CCFD419530
00007fb1689e3f15  call rax
00007fb1689e3f17  movaps xmm10, [rsp]
00007fb1689e3f1c  add rsp, 0x30
00007fb1689e3f20  vmovaps xmm0, [rsp]
00007fb1689e3f25  vmovaps xmm1, [rsp+0x10]
00007fb1689e3f2b  vmovaps xmm2, [rsp+0x20]
00007fb1689e3f31  vmovaps xmm3, [rsp+0x30]
00007fb1689e3f37  vmovaps xmm4, [rsp+0x40]
00007fb1689e3f3d  vmovaps xmm5, [rsp+0x50]
00007fb1689e3f43  vmovaps xmm6, [rsp+0x60]
00007fb1689e3f49  vmovaps xmm7, [rsp+0x70]
00007fb1689e3f4f  vmovaps xmm8, [rsp+0x80]
00007fb1689e3f58  vmovaps xmm9, [rsp+0x90]
00007fb1689e3f61  vmovaps xmm11, [rsp+0xA0]
00007fb1689e3f6a  vmovaps xmm12, [rsp+0xB0]
00007fb1689e3f73  vmovaps xmm13, [rsp+0xC0]
00007fb1689e3f7c  vmovaps xmm14, [rsp+0xD0]
00007fb1689e3f85  vmovaps xmm15, [rsp+0xE0]
00007fb1689e3f8e  add rsp, 0xF0
00007fb1689e3f95  pop r11
00007fb1689e3f97  pop r10
00007fb1689e3f99  pop r9
00007fb1689e3f9b  pop r8
00007fb1689e3f9d  pop rsi
00007fb1689e3f9e  pop rdi
00007fb1689e3f9f  pop rdx
00007fb1689e3fa0  pop rcx
00007fb1689e3fa1  pop rax
00007fb1689e3fa2  add rsp, 0x08
00007fb1689e3fa6  jmp 0x00007FB1689DF8AD
00007fb1689e3fab  sub rsp, 0x08
00007fb1689e3faf  push rax
00007fb1689e3fb0  push rcx
00007fb1689e3fb1  push rdx
00007fb1689e3fb2  push rdi
00007fb1689e3fb3  push rsi
00007fb1689e3fb4  push r8
00007fb1689e3fb6  push r9
00007fb1689e3fb8  push r10
00007fb1689e3fba  push r11
00007fb1689e3fbc  sub rsp, 0xF0
00007fb1689e3fc3  vmovaps [rsp], xmm0
00007fb1689e3fc8  vmovaps [rsp+0x10], xmm1
00007fb1689e3fce  vmovaps [rsp+0x20], xmm2
00007fb1689e3fd4  vmovaps [rsp+0x30], xmm3
00007fb1689e3fda  vmovaps [rsp+0x40], xmm4
00007fb1689e3fe0  vmovaps [rsp+0x50], xmm5
00007fb1689e3fe6  vmovaps [rsp+0x60], xmm6
00007fb1689e3fec  vmovaps [rsp+0x70], xmm7
00007fb1689e3ff2  vmovaps [rsp+0x80], xmm8
00007fb1689e3ffb  vmovaps [rsp+0x90], xmm9
00007fb1689e4004  vmovaps [rsp+0xA0], xmm10
00007fb1689e400d  vmovaps [rsp+0xB0], xmm11
00007fb1689e4016  vmovaps [rsp+0xC0], xmm13
00007fb1689e401f  vmovaps [rsp+0xD0], xmm14
00007fb1689e4028  vmovaps [rsp+0xE0], xmm15
00007fb1689e4031  sub rsp, 0x30
00007fb1689e4035  movaps [rsp], xmm12
00007fb1689e403a  movaps [rsp+0x10], xmm14
00007fb1689e4040  movaps [rsp+0x20], xmm1
00007fb1689e4045  lea rdi, [rsp]
00007fb1689e4049  mov esi, 0x00
00007fb1689e404e  mov rax, 0x57CCFD419530
00007fb1689e4058  call rax
00007fb1689e405a  movaps xmm12, [rsp]
00007fb1689e405f  add rsp, 0x30
00007fb1689e4063  vmovaps xmm0, [rsp]
00007fb1689e4068  vmovaps xmm1, [rsp+0x10]
00007fb1689e406e  vmovaps xmm2, [rsp+0x20]
00007fb1689e4074  vmovaps xmm3, [rsp+0x30]
00007fb1689e407a  vmovaps xmm4, [rsp+0x40]
00007fb1689e4080  vmovaps xmm5, [rsp+0x50]
00007fb1689e4086  vmovaps xmm6, [rsp+0x60]
00007fb1689e408c  vmovaps xmm7, [rsp+0x70]
00007fb1689e4092  vmovaps xmm8, [rsp+0x80]
00007fb1689e409b  vmovaps xmm9, [rsp+0x90]
00007fb1689e40a4  vmovaps xmm10, [rsp+0xA0]
00007fb1689e40ad  vmovaps xmm11, [rsp+0xB0]
00007fb1689e40b6  vmovaps xmm13, [rsp+0xC0]
00007fb1689e40bf  vmovaps xmm14, [rsp+0xD0]
00007fb1689e40c8  vmovaps xmm15, [rsp+0xE0]
00007fb1689e40d1  add rsp, 0xF0
00007fb1689e40d8  pop r11
00007fb1689e40da  pop r10
00007fb1689e40dc  pop r9
00007fb1689e40de  pop r8
00007fb1689e40e0  pop rsi
00007fb1689e40e1  pop rdi
00007fb1689e40e2  pop rdx
00007fb1689e40e3  pop rcx
00007fb1689e40e4  pop rax
00007fb1689e40e5  add rsp, 0x08
00007fb1689e40e9  jmp 0x00007FB1689DF8DC
00007fb1689e40ee  sub rsp, 0x08
00007fb1689e40f2  push rax
00007fb1689e40f3  push rcx
00007fb1689e40f4  push rdx
00007fb1689e40f5  push rdi
00007fb1689e40f6  push rsi
00007fb1689e40f7  push r8
00007fb1689e40f9  push r9
00007fb1689e40fb  push r10
00007fb1689e40fd  push r11
00007fb1689e40ff  sub rsp, 0xF0
00007fb1689e4106  vmovaps [rsp], xmm0
00007fb1689e410b  vmovaps [rsp+0x10], xmm1
00007fb1689e4111  vmovaps [rsp+0x20], xmm2
00007fb1689e4117  vmovaps [rsp+0x30], xmm3
00007fb1689e411d  vmovaps [rsp+0x40], xmm4
00007fb1689e4123  vmovaps [rsp+0x50], xmm5
00007fb1689e4129  vmovaps [rsp+0x60], xmm6
00007fb1689e412f  vmovaps [rsp+0x70], xmm7
00007fb1689e4135  vmovaps [rsp+0x80], xmm8
00007fb1689e413e  vmovaps [rsp+0x90], xmm9
00007fb1689e4147  vmovaps [rsp+0xA0], xmm10
00007fb1689e4150  vmovaps [rsp+0xB0], xmm11
00007fb1689e4159  vmovaps [rsp+0xC0], xmm12
00007fb1689e4162  vmovaps [rsp+0xD0], xmm13
00007fb1689e416b  vmovaps [rsp+0xE0], xmm15
00007fb1689e4174  sub rsp, 0x30
00007fb1689e4178  movaps [rsp], xmm14
00007fb1689e417d  movaps [rsp+0x10], xmm9
00007fb1689e4183  movaps [rsp+0x20], xmm1
00007fb1689e4188  lea rdi, [rsp]
00007fb1689e418c  mov esi, 0x00
00007fb1689e4191  mov rax, 0x57CCFD419530
00007fb1689e419b  call rax
00007fb1689e419d  movaps xmm14, [rsp]
00007fb1689e41a2  add rsp, 0x30
00007fb1689e41a6  vmovaps xmm0, [rsp]
00007fb1689e41ab  vmovaps xmm1, [rsp+0x10]
00007fb1689e41b1  vmovaps xmm2, [rsp+0x20]
00007fb1689e41b7  vmovaps xmm3, [rsp+0x30]
00007fb1689e41bd  vmovaps xmm4, [rsp+0x40]
00007fb1689e41c3  vmovaps xmm5, [rsp+0x50]
00007fb1689e41c9  vmovaps xmm6, [rsp+0x60]
00007fb1689e41cf  vmovaps xmm7, [rsp+0x70]
00007fb1689e41d5  vmovaps xmm8, [rsp+0x80]
00007fb1689e41de  vmovaps xmm9, [rsp+0x90]
00007fb1689e41e7  vmovaps xmm10, [rsp+0xA0]
00007fb1689e41f0  vmovaps xmm11, [rsp+0xB0]
00007fb1689e41f9  vmovaps xmm12, [rsp+0xC0]
00007fb1689e4202  vmovaps xmm13, [rsp+0xD0]
00007fb1689e420b  vmovaps xmm15, [rsp+0xE0]
00007fb1689e4214  add rsp, 0xF0
00007fb1689e421b  pop r11
00007fb1689e421d  pop r10
00007fb1689e421f  pop r9
00007fb1689e4221  pop r8
00007fb1689e4223  pop rsi
00007fb1689e4224  pop rdi
00007fb1689e4225  pop rdx
00007fb1689e4226  pop rcx
00007fb1689e4227  pop rax
00007fb1689e4228  add rsp, 0x08
00007fb1689e422c  jmp 0x00007FB1689DF90B
00007fb1689e4231  sub rsp, 0x08
00007fb1689e4235  push rax
00007fb1689e4236  push rcx
00007fb1689e4237  push rdx
00007fb1689e4238  push rdi
00007fb1689e4239  push rsi
00007fb1689e423a  push r8
00007fb1689e423c  push r9
00007fb1689e423e  push r10
00007fb1689e4240  push r11
00007fb1689e4242  sub rsp, 0xF0
00007fb1689e4249  vmovaps [rsp], xmm0
00007fb1689e424e  vmovaps [rsp+0x10], xmm2
00007fb1689e4254  vmovaps [rsp+0x20], xmm3
00007fb1689e425a  vmovaps [rsp+0x30], xmm4
00007fb1689e4260  vmovaps [rsp+0x40], xmm5
00007fb1689e4266  vmovaps [rsp+0x50], xmm6
00007fb1689e426c  vmovaps [rsp+0x60], xmm7
00007fb1689e4272  vmovaps [rsp+0x70], xmm8
00007fb1689e4278  vmovaps [rsp+0x80], xmm9
00007fb1689e4281  vmovaps [rsp+0x90], xmm10
00007fb1689e428a  vmovaps [rsp+0xA0], xmm11
00007fb1689e4293  vmovaps [rsp+0xB0], xmm12
00007fb1689e429c  vmovaps [rsp+0xC0], xmm13
00007fb1689e42a5  vmovaps [rsp+0xD0], xmm14
00007fb1689e42ae  vmovaps [rsp+0xE0], xmm15
00007fb1689e42b7  sub rsp, 0x30
00007fb1689e42bb  movaps [rsp], xmm1
00007fb1689e42bf  movaps [rsp+0x10], xmm13
00007fb1689e42c5  movaps [rsp+0x20], xmm8
00007fb1689e42cb  lea rdi, [rsp]
00007fb1689e42cf  mov esi, 0x00
00007fb1689e42d4  mov rax, 0x57CCFD419530
00007fb1689e42de  call rax
00007fb1689e42e0  movaps xmm1, [rsp]
00007fb1689e42e4  add rsp, 0x30
00007fb1689e42e8  vmovaps xmm0, [rsp]
00007fb1689e42ed  vmovaps xmm2, [rsp+0x10]
00007fb1689e42f3  vmovaps xmm3, [rsp+0x20]
00007fb1689e42f9  vmovaps xmm4, [rsp+0x30]
00007fb1689e42ff  vmovaps xmm5, [rsp+0x40]
00007fb1689e4305  vmovaps xmm6, [rsp+0x50]
00007fb1689e430b  vmovaps xmm7, [rsp+0x60]
00007fb1689e4311  vmovaps xmm8, [rsp+0x70]
00007fb1689e4317  vmovaps xmm9, [rsp+0x80]
00007fb1689e4320  vmovaps xmm10, [rsp+0x90]
00007fb1689e4329  vmovaps xmm11, [rsp+0xA0]
00007fb1689e4332  vmovaps xmm12, [rsp+0xB0]
00007fb1689e433b  vmovaps xmm13, [rsp+0xC0]
00007fb1689e4344  vmovaps xmm14, [rsp+0xD0]
00007fb1689e434d  vmovaps xmm15, [rsp+0xE0]
00007fb1689e4356  add rsp, 0xF0
00007fb1689e435d  pop r11
00007fb1689e435f  pop r10
00007fb1689e4361  pop r9
00007fb1689e4363  pop r8
00007fb1689e4365  pop rsi
00007fb1689e4366  pop rdi
00007fb1689e4367  pop rdx
00007fb1689e4368  pop rcx
00007fb1689e4369  pop rax
00007fb1689e436a  add rsp, 0x08
00007fb1689e436e  jmp 0x00007FB1689DF92D
00007fb1689e4373  call 0x00007FB16880C260
00007fb1689e4378  jmp 0x00007FB1689DF93B
00007fb1689e437d  call 0x00007FB1688BD750
00007fb1689e4382  jmp 0x00007FB1689DF945
00007fb1689e4387  sub rsp, 0x08
00007fb1689e438b  push rax
00007fb1689e438c  push rcx
00007fb1689e438d  push rdx
00007fb1689e438e  push rdi
00007fb1689e438f  push rsi
00007fb1689e4390  push r8
00007fb1689e4392  push r9
00007fb1689e4394  push r10
00007fb1689e4396  push r11
00007fb1689e4398  sub rsp, 0xF0
00007fb1689e439f  vmovaps [rsp], xmm0
00007fb1689e43a4  vmovaps [rsp+0x10], xmm1
00007fb1689e43aa  vmovaps [rsp+0x20], xmm2
00007fb1689e43b0  vmovaps [rsp+0x30], xmm3
00007fb1689e43b6  vmovaps [rsp+0x40], xmm4
00007fb1689e43bc  vmovaps [rsp+0x50], xmm5
00007fb1689e43c2  vmovaps [rsp+0x60], xmm6
00007fb1689e43c8  vmovaps [rsp+0x70], xmm7
00007fb1689e43ce  vmovaps [rsp+0x80], xmm9
00007fb1689e43d7  vmovaps [rsp+0x90], xmm10
00007fb1689e43e0  vmovaps [rsp+0xA0], xmm11
00007fb1689e43e9  vmovaps [rsp+0xB0], xmm12
00007fb1689e43f2  vmovaps [rsp+0xC0], xmm13
00007fb1689e43fb  vmovaps [rsp+0xD0], xmm14
00007fb1689e4404  vmovaps [rsp+0xE0], xmm15
00007fb1689e440d  sub rsp, 0x30
00007fb1689e4411  movaps [rsp], xmm8
00007fb1689e4416  movaps [rsp+0x10], xmm15
00007fb1689e441c  movaps [rsp+0x20], xmm7
00007fb1689e4421  lea rdi, [rsp]
00007fb1689e4425  mov esi, 0x00
00007fb1689e442a  mov rax, 0x57CCFD419530
00007fb1689e4434  call rax
00007fb1689e4436  movaps xmm8, [rsp]
00007fb1689e443b  add rsp, 0x30
00007fb1689e443f  vmovaps xmm0, [rsp]
00007fb1689e4444  vmovaps xmm1, [rsp+0x10]
00007fb1689e444a  vmovaps xmm2, [rsp+0x20]
00007fb1689e4450  vmovaps xmm3, [rsp+0x30]
00007fb1689e4456  vmovaps xmm4, [rsp+0x40]
00007fb1689e445c  vmovaps xmm5, [rsp+0x50]
00007fb1689e4462  vmovaps xmm6, [rsp+0x60]
00007fb1689e4468  vmovaps xmm7, [rsp+0x70]
00007fb1689e446e  vmovaps xmm9, [rsp+0x80]
00007fb1689e4477  vmovaps xmm10, [rsp+0x90]
00007fb1689e4480  vmovaps xmm11, [rsp+0xA0]
00007fb1689e4489  vmovaps xmm12, [rsp+0xB0]
00007fb1689e4492  vmovaps xmm13, [rsp+0xC0]
00007fb1689e449b  vmovaps xmm14, [rsp+0xD0]
00007fb1689e44a4  vmovaps xmm15, [rsp+0xE0]
00007fb1689e44ad  add rsp, 0xF0
00007fb1689e44b4  pop r11
00007fb1689e44b6  pop r10
00007fb1689e44b8  pop r9
00007fb1689e44ba  pop r8
00007fb1689e44bc  pop rsi
00007fb1689e44bd  pop rdi
00007fb1689e44be  pop rdx
00007fb1689e44bf  pop rcx
00007fb1689e44c0  pop rax
00007fb1689e44c1  add rsp, 0x08
00007fb1689e44c5  jmp 0x00007FB1689DF967
00007fb1689e44ca  sub rsp, 0x08
00007fb1689e44ce  push rax
00007fb1689e44cf  push rcx
00007fb1689e44d0  push rdx
00007fb1689e44d1  push rdi
00007fb1689e44d2  push rsi
00007fb1689e44d3  push r8
00007fb1689e44d5  push r9
00007fb1689e44d7  push r10
00007fb1689e44d9  push r11
00007fb1689e44db  sub rsp, 0xF0
00007fb1689e44e2  vmovaps [rsp], xmm0
00007fb1689e44e7  vmovaps [rsp+0x10], xmm1
00007fb1689e44ed  vmovaps [rsp+0x20], xmm2
00007fb1689e44f3  vmovaps [rsp+0x30], xmm3
00007fb1689e44f9  vmovaps [rsp+0x40], xmm4
00007fb1689e44ff  vmovaps [rsp+0x50], xmm5
00007fb1689e4505  vmovaps [rsp+0x60], xmm6
00007fb1689e450b  vmovaps [rsp+0x70], xmm8
00007fb1689e4511  vmovaps [rsp+0x80], xmm9
00007fb1689e451a  vmovaps [rsp+0x90], xmm10
00007fb1689e4523  vmovaps [rsp+0xA0], xmm11
00007fb1689e452c  vmovaps [rsp+0xB0], xmm12
00007fb1689e4535  vmovaps [rsp+0xC0], xmm13
00007fb1689e453e  vmovaps [rsp+0xD0], xmm14
00007fb1689e4547  vmovaps [rsp+0xE0], xmm15
00007fb1689e4550  sub rsp, 0x30
00007fb1689e4554  movaps [rsp], xmm7
00007fb1689e4558  movaps [rsp+0x10], xmm9
00007fb1689e455e  movaps [rsp+0x20], xmm15
00007fb1689e4564  lea rdi, [rsp]
00007fb1689e4568  mov esi, 0x00
00007fb1689e456d  mov rax, 0x57CCFD419530
00007fb1689e4577  call rax
00007fb1689e4579  movaps xmm7, [rsp]
00007fb1689e457d  add rsp, 0x30
00007fb1689e4581  vmovaps xmm0, [rsp]
00007fb1689e4586  vmovaps xmm1, [rsp+0x10]
00007fb1689e458c  vmovaps xmm2, [rsp+0x20]
00007fb1689e4592  vmovaps xmm3, [rsp+0x30]
00007fb1689e4598  vmovaps xmm4, [rsp+0x40]
00007fb1689e459e  vmovaps xmm5, [rsp+0x50]
00007fb1689e45a4  vmovaps xmm6, [rsp+0x60]
00007fb1689e45aa  vmovaps xmm8, [rsp+0x70]
00007fb1689e45b0  vmovaps xmm9, [rsp+0x80]
00007fb1689e45b9  vmovaps xmm10, [rsp+0x90]
00007fb1689e45c2  vmovaps xmm11, [rsp+0xA0]
00007fb1689e45cb  vmovaps xmm12, [rsp+0xB0]
00007fb1689e45d4  vmovaps xmm13, [rsp+0xC0]
00007fb1689e45dd  vmovaps xmm14, [rsp+0xD0]
00007fb1689e45e6  vmovaps xmm15, [rsp+0xE0]
00007fb1689e45ef  add rsp, 0xF0
00007fb1689e45f6  pop r11
00007fb1689e45f8  pop r10
00007fb1689e45fa  pop r9
00007fb1689e45fc  pop r8
00007fb1689e45fe  pop rsi
00007fb1689e45ff  pop rdi
00007fb1689e4600  pop rdx
00007fb1689e4601  pop rcx
00007fb1689e4602  pop rax
00007fb1689e4603  add rsp, 0x08
00007fb1689e4607  jmp 0x00007FB1689DF994
00007fb1689e460c  sub rsp, 0x08
00007fb1689e4610  push rax
00007fb1689e4611  push rcx
00007fb1689e4612  push rdx
00007fb1689e4613  push rdi
00007fb1689e4614  push rsi
00007fb1689e4615  push r8
00007fb1689e4617  push r9
00007fb1689e4619  push r10
00007fb1689e461b  push r11
00007fb1689e461d  sub rsp, 0xF0
00007fb1689e4624  vmovaps [rsp], xmm0
00007fb1689e4629  vmovaps [rsp+0x10], xmm1
00007fb1689e462f  vmovaps [rsp+0x20], xmm2
00007fb1689e4635  vmovaps [rsp+0x30], xmm3
00007fb1689e463b  vmovaps [rsp+0x40], xmm4
00007fb1689e4641  vmovaps [rsp+0x50], xmm5
00007fb1689e4647  vmovaps [rsp+0x60], xmm6
00007fb1689e464d  vmovaps [rsp+0x70], xmm7
00007fb1689e4653  vmovaps [rsp+0x80], xmm8
00007fb1689e465c  vmovaps [rsp+0x90], xmm10
00007fb1689e4665  vmovaps [rsp+0xA0], xmm11
00007fb1689e466e  vmovaps [rsp+0xB0], xmm12
00007fb1689e4677  vmovaps [rsp+0xC0], xmm13
00007fb1689e4680  vmovaps [rsp+0xD0], xmm14
00007fb1689e4689  vmovaps [rsp+0xE0], xmm15
00007fb1689e4692  sub rsp, 0x30
00007fb1689e4696  movaps [rsp], xmm9
00007fb1689e469b  movaps [rsp+0x10], xmm13
00007fb1689e46a1  movaps [rsp+0x20], xmm15
00007fb1689e46a7  lea rdi, [rsp]
00007fb1689e46ab  mov esi, 0x00
00007fb1689e46b0  mov rax, 0x57CCFD419530
00007fb1689e46ba  call rax
00007fb1689e46bc  movaps xmm9, [rsp]
00007fb1689e46c1  add rsp, 0x30
00007fb1689e46c5  vmovaps xmm0, [rsp]
00007fb1689e46ca  vmovaps xmm1, [rsp+0x10]
00007fb1689e46d0  vmovaps xmm2, [rsp+0x20]
00007fb1689e46d6  vmovaps xmm3, [rsp+0x30]
00007fb1689e46dc  vmovaps xmm4, [rsp+0x40]
00007fb1689e46e2  vmovaps xmm5, [rsp+0x50]
00007fb1689e46e8  vmovaps xmm6, [rsp+0x60]
00007fb1689e46ee  vmovaps xmm7, [rsp+0x70]
00007fb1689e46f4  vmovaps xmm8, [rsp+0x80]
00007fb1689e46fd  vmovaps xmm10, [rsp+0x90]
00007fb1689e4706  vmovaps xmm11, [rsp+0xA0]
00007fb1689e470f  vmovaps xmm12, [rsp+0xB0]
00007fb1689e4718  vmovaps xmm13, [rsp+0xC0]
00007fb1689e4721  vmovaps xmm14, [rsp+0xD0]
00007fb1689e472a  vmovaps xmm15, [rsp+0xE0]
00007fb1689e4733  add rsp, 0xF0
00007fb1689e473a  pop r11
00007fb1689e473c  pop r10
00007fb1689e473e  pop r9
00007fb1689e4740  pop r8
00007fb1689e4742  pop rsi
00007fb1689e4743  pop rdi
00007fb1689e4744  pop rdx
00007fb1689e4745  pop rcx
00007fb1689e4746  pop rax
00007fb1689e4747  add rsp, 0x08
00007fb1689e474b  jmp 0x00007FB1689DF9C2
00007fb1689e4750  sub rsp, 0x08
00007fb1689e4754  push rax
00007fb1689e4755  push rcx
00007fb1689e4756  push rdx
00007fb1689e4757  push rdi
00007fb1689e4758  push rsi
00007fb1689e4759  push r8
00007fb1689e475b  push r9
00007fb1689e475d  push r10
00007fb1689e475f  push r11
00007fb1689e4761  sub rsp, 0xF0
00007fb1689e4768  vmovaps [rsp], xmm0
00007fb1689e476d  vmovaps [rsp+0x10], xmm1
00007fb1689e4773  vmovaps [rsp+0x20], xmm2
00007fb1689e4779  vmovaps [rsp+0x30], xmm3
00007fb1689e477f  vmovaps [rsp+0x40], xmm4
00007fb1689e4785  vmovaps [rsp+0x50], xmm5
00007fb1689e478b  vmovaps [rsp+0x60], xmm6
00007fb1689e4791  vmovaps [rsp+0x70], xmm7
00007fb1689e4797  vmovaps [rsp+0x80], xmm8
00007fb1689e47a0  vmovaps [rsp+0x90], xmm9
00007fb1689e47a9  vmovaps [rsp+0xA0], xmm10
00007fb1689e47b2  vmovaps [rsp+0xB0], xmm11
00007fb1689e47bb  vmovaps [rsp+0xC0], xmm12
00007fb1689e47c4  vmovaps [rsp+0xD0], xmm13
00007fb1689e47cd  vmovaps [rsp+0xE0], xmm14
00007fb1689e47d6  sub rsp, 0x30
00007fb1689e47da  movaps [rsp], xmm15
00007fb1689e47df  movaps [rsp+0x10], xmm11
00007fb1689e47e5  movaps [rsp+0x20], xmm12
00007fb1689e47eb  lea rdi, [rsp]
00007fb1689e47ef  mov esi, 0x00
00007fb1689e47f4  mov rax, 0x57CCFD419530
00007fb1689e47fe  call rax
00007fb1689e4800  movaps xmm15, [rsp]
00007fb1689e4805  add rsp, 0x30
00007fb1689e4809  vmovaps xmm0, [rsp]
00007fb1689e480e  vmovaps xmm1, [rsp+0x10]
00007fb1689e4814  vmovaps xmm2, [rsp+0x20]
00007fb1689e481a  vmovaps xmm3, [rsp+0x30]
00007fb1689e4820  vmovaps xmm4, [rsp+0x40]
00007fb1689e4826  vmovaps xmm5, [rsp+0x50]
00007fb1689e482c  vmovaps xmm6, [rsp+0x60]
00007fb1689e4832  vmovaps xmm7, [rsp+0x70]
00007fb1689e4838  vmovaps xmm8, [rsp+0x80]
00007fb1689e4841  vmovaps xmm9, [rsp+0x90]
00007fb1689e484a  vmovaps xmm10, [rsp+0xA0]
00007fb1689e4853  vmovaps xmm11, [rsp+0xB0]
00007fb1689e485c  vmovaps xmm12, [rsp+0xC0]
00007fb1689e4865  vmovaps xmm13, [rsp+0xD0]
00007fb1689e486e  vmovaps xmm14, [rsp+0xE0]
00007fb1689e4877  add rsp, 0xF0
00007fb1689e487e  pop r11
00007fb1689e4880  pop r10
00007fb1689e4882  pop r9
00007fb1689e4884  pop r8
00007fb1689e4886  pop rsi
00007fb1689e4887  pop rdi
00007fb1689e4888  pop rdx
00007fb1689e4889  pop rcx
00007fb1689e488a  pop rax
00007fb1689e488b  add rsp, 0x08
00007fb1689e488f  jmp 0x00007FB1689DF9DD
00007fb1689e4894  sub rsp, 0x08
00007fb1689e4898  push rax
00007fb1689e4899  push rcx
00007fb1689e489a  push rdx
00007fb1689e489b  push rdi
00007fb1689e489c  push rsi
00007fb1689e489d  push r8
00007fb1689e489f  push r9
00007fb1689e48a1  push r10
00007fb1689e48a3  push r11
00007fb1689e48a5  sub rsp, 0xF0
00007fb1689e48ac  vmovaps [rsp], xmm0
00007fb1689e48b1  vmovaps [rsp+0x10], xmm1
00007fb1689e48b7  vmovaps [rsp+0x20], xmm2
00007fb1689e48bd  vmovaps [rsp+0x30], xmm3
00007fb1689e48c3  vmovaps [rsp+0x40], xmm4
00007fb1689e48c9  vmovaps [rsp+0x50], xmm5
00007fb1689e48cf  vmovaps [rsp+0x60], xmm6
00007fb1689e48d5  vmovaps [rsp+0x70], xmm7
00007fb1689e48db  vmovaps [rsp+0x80], xmm8
00007fb1689e48e4  vmovaps [rsp+0x90], xmm9
00007fb1689e48ed  vmovaps [rsp+0xA0], xmm10
00007fb1689e48f6  vmovaps [rsp+0xB0], xmm11
00007fb1689e48ff  vmovaps [rsp+0xC0], xmm12
00007fb1689e4908  vmovaps [rsp+0xD0], xmm14
00007fb1689e4911  vmovaps [rsp+0xE0], xmm15
00007fb1689e491a  sub rsp, 0x30
00007fb1689e491e  movaps [rsp], xmm13
00007fb1689e4923  movaps [rsp+0x10], xmm10
00007fb1689e4929  movaps [rsp+0x20], xmm14
00007fb1689e492f  lea rdi, [rsp]
00007fb1689e4933  mov esi, 0x00
00007fb1689e4938  mov rax, 0x57CCFD419530
00007fb1689e4942  call rax
00007fb1689e4944  movaps xmm13, [rsp]
00007fb1689e4949  add rsp, 0x30
00007fb1689e494d  vmovaps xmm0, [rsp]
00007fb1689e4952  vmovaps xmm1, [rsp+0x10]
00007fb1689e4958  vmovaps xmm2, [rsp+0x20]
00007fb1689e495e  vmovaps xmm3, [rsp+0x30]
00007fb1689e4964  vmovaps xmm4, [rsp+0x40]
00007fb1689e496a  vmovaps xmm5, [rsp+0x50]
00007fb1689e4970  vmovaps xmm6, [rsp+0x60]
00007fb1689e4976  vmovaps xmm7, [rsp+0x70]
00007fb1689e497c  vmovaps xmm8, [rsp+0x80]
00007fb1689e4985  vmovaps xmm9, [rsp+0x90]
00007fb1689e498e  vmovaps xmm10, [rsp+0xA0]
00007fb1689e4997  vmovaps xmm11, [rsp+0xB0]
00007fb1689e49a0  vmovaps xmm12, [rsp+0xC0]
00007fb1689e49a9  vmovaps xmm14, [rsp+0xD0]
00007fb1689e49b2  vmovaps xmm15, [rsp+0xE0]
00007fb1689e49bb  add rsp, 0xF0
00007fb1689e49c2  pop r11
00007fb1689e49c4  pop r10
00007fb1689e49c6  pop r9
00007fb1689e49c8  pop r8
00007fb1689e49ca  pop rsi
00007fb1689e49cb  pop rdi
00007fb1689e49cc  pop rdx
00007fb1689e49cd  pop rcx
00007fb1689e49ce  pop rax
00007fb1689e49cf  add rsp, 0x08
00007fb1689e49d3  jmp 0x00007FB1689DFA00
00007fb1689e49d8  sub rsp, 0x08
00007fb1689e49dc  push rax
00007fb1689e49dd  push rcx
00007fb1689e49de  push rdx
00007fb1689e49df  push rdi
00007fb1689e49e0  push rsi
00007fb1689e49e1  push r8
00007fb1689e49e3  push r9
00007fb1689e49e5  push r10
00007fb1689e49e7  push r11
00007fb1689e49e9  sub rsp, 0xF0
00007fb1689e49f0  vmovaps [rsp], xmm0
00007fb1689e49f5  vmovaps [rsp+0x10], xmm1
00007fb1689e49fb  vmovaps [rsp+0x20], xmm2
00007fb1689e4a01  vmovaps [rsp+0x30], xmm3
00007fb1689e4a07  vmovaps [rsp+0x40], xmm4
00007fb1689e4a0d  vmovaps [rsp+0x50], xmm5
00007fb1689e4a13  vmovaps [rsp+0x60], xmm6
00007fb1689e4a19  vmovaps [rsp+0x70], xmm7
00007fb1689e4a1f  vmovaps [rsp+0x80], xmm8
00007fb1689e4a28  vmovaps [rsp+0x90], xmm9
00007fb1689e4a31  vmovaps [rsp+0xA0], xmm10
00007fb1689e4a3a  vmovaps [rsp+0xB0], xmm11
00007fb1689e4a43  vmovaps [rsp+0xC0], xmm12
00007fb1689e4a4c  vmovaps [rsp+0xD0], xmm13
00007fb1689e4a55  vmovaps [rsp+0xE0], xmm15
00007fb1689e4a5e  sub rsp, 0x30
00007fb1689e4a62  movaps [rsp], xmm14
00007fb1689e4a67  movaps [rsp+0x10], xmm1
00007fb1689e4a6c  movaps [rsp+0x20], xmm7
00007fb1689e4a71  lea rdi, [rsp]
00007fb1689e4a75  mov esi, 0x00
00007fb1689e4a7a  mov rax, 0x57CCFD419530
00007fb1689e4a84  call rax
00007fb1689e4a86  movaps xmm14, [rsp]
00007fb1689e4a8b  add rsp, 0x30
00007fb1689e4a8f  vmovaps xmm0, [rsp]
00007fb1689e4a94  vmovaps xmm1, [rsp+0x10]
00007fb1689e4a9a  vmovaps xmm2, [rsp+0x20]
00007fb1689e4aa0  vmovaps xmm3, [rsp+0x30]
00007fb1689e4aa6  vmovaps xmm4, [rsp+0x40]
00007fb1689e4aac  vmovaps xmm5, [rsp+0x50]
00007fb1689e4ab2  vmovaps xmm6, [rsp+0x60]
00007fb1689e4ab8  vmovaps xmm7, [rsp+0x70]
00007fb1689e4abe  vmovaps xmm8, [rsp+0x80]
00007fb1689e4ac7  vmovaps xmm9, [rsp+0x90]
00007fb1689e4ad0  vmovaps xmm10, [rsp+0xA0]
00007fb1689e4ad9  vmovaps xmm11, [rsp+0xB0]
00007fb1689e4ae2  vmovaps xmm12, [rsp+0xC0]
00007fb1689e4aeb  vmovaps xmm13, [rsp+0xD0]
00007fb1689e4af4  vmovaps xmm15, [rsp+0xE0]
00007fb1689e4afd  add rsp, 0xF0
00007fb1689e4b04  pop r11
00007fb1689e4b06  pop r10
00007fb1689e4b08  pop r9
00007fb1689e4b0a  pop r8
00007fb1689e4b0c  pop rsi
00007fb1689e4b0d  pop rdi
00007fb1689e4b0e  pop rdx
00007fb1689e4b0f  pop rcx
00007fb1689e4b10  pop rax
00007fb1689e4b11  add rsp, 0x08
00007fb1689e4b15  jmp 0x00007FB1689DFA23
00007fb1689e4b1a  sub rsp, 0x08
00007fb1689e4b1e  push rax
00007fb1689e4b1f  push rcx
00007fb1689e4b20  push rdx
00007fb1689e4b21  push rdi
00007fb1689e4b22  push rsi
00007fb1689e4b23  push r8
00007fb1689e4b25  push r9
00007fb1689e4b27  push r10
00007fb1689e4b29  push r11
00007fb1689e4b2b  sub rsp, 0xF0
00007fb1689e4b32  vmovaps [rsp], xmm0
00007fb1689e4b37  vmovaps [rsp+0x10], xmm2
00007fb1689e4b3d  vmovaps [rsp+0x20], xmm3
00007fb1689e4b43  vmovaps [rsp+0x30], xmm4
00007fb1689e4b49  vmovaps [rsp+0x40], xmm5
00007fb1689e4b4f  vmovaps [rsp+0x50], xmm6
00007fb1689e4b55  vmovaps [rsp+0x60], xmm7
00007fb1689e4b5b  vmovaps [rsp+0x70], xmm8
00007fb1689e4b61  vmovaps [rsp+0x80], xmm9
00007fb1689e4b6a  vmovaps [rsp+0x90], xmm10
00007fb1689e4b73  vmovaps [rsp+0xA0], xmm11
00007fb1689e4b7c  vmovaps [rsp+0xB0], xmm12
00007fb1689e4b85  vmovaps [rsp+0xC0], xmm13
00007fb1689e4b8e  vmovaps [rsp+0xD0], xmm14
00007fb1689e4b97  vmovaps [rsp+0xE0], xmm15
00007fb1689e4ba0  sub rsp, 0x30
00007fb1689e4ba4  movaps [rsp], xmm1
00007fb1689e4ba8  movaps [rsp+0x10], xmm8
00007fb1689e4bae  movaps [rsp+0x20], xmm9
00007fb1689e4bb4  lea rdi, [rsp]
00007fb1689e4bb8  mov esi, 0x00
00007fb1689e4bbd  mov rax, 0x57CCFD419530
00007fb1689e4bc7  call rax
00007fb1689e4bc9  movaps xmm1, [rsp]
00007fb1689e4bcd  add rsp, 0x30
00007fb1689e4bd1  vmovaps xmm0, [rsp]
00007fb1689e4bd6  vmovaps xmm2, [rsp+0x10]
00007fb1689e4bdc  vmovaps xmm3, [rsp+0x20]
00007fb1689e4be2  vmovaps xmm4, [rsp+0x30]
00007fb1689e4be8  vmovaps xmm5, [rsp+0x40]
00007fb1689e4bee  vmovaps xmm6, [rsp+0x50]
00007fb1689e4bf4  vmovaps xmm7, [rsp+0x60]
00007fb1689e4bfa  vmovaps xmm8, [rsp+0x70]
00007fb1689e4c00  vmovaps xmm9, [rsp+0x80]
00007fb1689e4c09  vmovaps xmm10, [rsp+0x90]
00007fb1689e4c12  vmovaps xmm11, [rsp+0xA0]
00007fb1689e4c1b  vmovaps xmm12, [rsp+0xB0]
00007fb1689e4c24  vmovaps xmm13, [rsp+0xC0]
00007fb1689e4c2d  vmovaps xmm14, [rsp+0xD0]
00007fb1689e4c36  vmovaps xmm15, [rsp+0xE0]
00007fb1689e4c3f  add rsp, 0xF0
00007fb1689e4c46  pop r11
00007fb1689e4c48  pop r10
00007fb1689e4c4a  pop r9
00007fb1689e4c4c  pop r8
00007fb1689e4c4e  pop rsi
00007fb1689e4c4f  pop rdi
00007fb1689e4c50  pop rdx
00007fb1689e4c51  pop rcx
00007fb1689e4c52  pop rax
00007fb1689e4c53  add rsp, 0x08
00007fb1689e4c57  jmp 0x00007FB1689DFA45
00007fb1689e4c5c  call 0x00007FB1688E5940
00007fb1689e4c61  jmp 0x00007FB1689DFA53
00007fb1689e4c66  call 0x00007FB16880C380
00007fb1689e4c6b  jmp 0x00007FB1689DFA5D
00007fb1689e4c70  call 0x00007FB16880D600
00007fb1689e4c75  jmp 0x00007FB1689DFA67
00007fb1689e4c7a  call 0x00007FB1687FF540
00007fb1689e4c7f  jmp 0x00007FB1689DFA71
00007fb1689e4c84  int3
00007fb1689e4c85  nop [rax+rax*1], ax
00007fb1689e4c8e  nop
00007fb1689e4c90  mov qword ptr [r15+0x40], 0x430000
00007fb1689e4c98  mov eax, 0x430CC0
00007fb1689e4c9d  mov r14, [r13+rax*1]
00007fb1689e4ca2  movq xmm1, r14
00007fb1689e4ca7  mov rax, [r15+0x50]
00007fb1689e4cab  movups xmm15, [r13+rax*1]
00007fb1689e4cb1  movaps [r15+0x120], xmm15
00007fb1689e4cb9  mov qword ptr [r15+0x48], 0x10
00007fb1689e4cc1  xor eax, eax
00007fb1689e4cc3  mov r14d, 0x10
00007fb1689e4cc9  mov r12d, 0x200
00007fb1689e4ccf  cmp r14, r12
00007fb1689e4cd2  cmc
00007fb1689e4cd3  lahf
00007fb1689e4cd4  seto al
00007fb1689e4cd7  mov [r15+0x108], eax
00007fb1689e4cde  pextrq rax, xmm15, 0x01
00007fb1689e4ce5  movq xmm14, rax
00007fb1689e4cea  movaps [r15+0x130], xmm14
00007fb1689e4cf2  movq rax, xmm1
00007fb1689e4cf7  movq r14, xmm15
00007fb1689e4cfc  vmovq xmm1, rax
00007fb1689e4d01  vmovq xmm15, r14
00007fb1689e4d06  movaps xmm13, xmm1
00007fb1689e4d0a  addsd xmm13, xmm15
00007fb1689e4d0f  ucomisd xmm13, xmm13
00007fb1689e4d14  jp 0x00007FB1689E4DD3
00007fb1689e4d1a  movq xmm13, xmm13
00007fb1689e4d1f  movq rax, xmm13
00007fb1689e4d24  movq r14, xmm14
00007fb1689e4d29  vmovq xmm1, rax
00007fb1689e4d2e  vmovq xmm15, r14
00007fb1689e4d33  movaps xmm14, xmm1
00007fb1689e4d37  addsd xmm14, xmm15
00007fb1689e4d3c  ucomisd xmm14, xmm14
00007fb1689e4d41  jp 0x00007FB1689E4E1B
00007fb1689e4d47  movq xmm14, xmm14
00007fb1689e4d4c  movaps [r15+0x110], xmm14
00007fb1689e4d54  mov eax, [r15+0x108]
00007fb1689e4d5b  sahf
00007fb1689e4d5c  jnz 0x00007FB1689E4D8E
00007fb1689e4d5e  cmp dword ptr [r15+0x318], 0x00
00007fb1689e4d66  jz 0x00007FB1689E5030
00007fb1689e4d6c  nop [rax+rax*1], ax
00007fb1689e4d75  nop [rax+rax*1], eax
00007fb1689e4d7d  mov eax, 0x410704
00007fb1689e4d82  mov [r15+0x100], rax
00007fb1689e4d89  jmp 0x00007FB1687FE110
00007fb1689e4d8e  cmp dword ptr [r15+0x318], 0x00
00007fb1689e4d96  jz 0x00007FB1689E4E70
00007fb1689e4d9c  nop [rax+rax*1], ax
00007fb1689e4da5  nop [rax+rax*1], eax
00007fb1689e4dad  mov eax, 0x4106E8
00007fb1689e4db2  mov [r15+0x100], rax
00007fb1689e4db9  jmp 0x00007FB1687FE110
00007fb1689e4dbe  int3
00007fb1689e4dbf  call 0x00007FB16880DC20
00007fb1689e4dc4  jmp 0x00007FB1689E4CA2
00007fb1689e4dc9  call 0x00007FB16880E760
00007fb1689e4dce  jmp 0x00007FB1689E4CB1
00007fb1689e4dd3  ucomisd xmm1, xmm15
00007fb1689e4dd8  jp 0x00007FB1689E4DE7
00007fb1689e4dda  movaps xmm13, [0x00007FB1685FE060]
00007fb1689e4de2  jmp 0x00007FB1689E4D1A
00007fb1689e4de7  vxorps xmm0, xmm1, xmm15
00007fb1689e4dec  pextrw eax, xmm0, 0x03
00007fb1689e4df1  and eax, 0x7FF8
00007fb1689e4df6  cmp eax, 0x08
00007fb1689e4df9  jnz 0x00007FB1689E4D1A
00007fb1689e4dff  movq rax, xmm15
00007fb1689e4e04  shl rax, 0x0D
00007fb1689e4e08  jbe 0x00007FB1689E4D1A
00007fb1689e4e0e  vorps xmm13, xmm15, [0x00007FB1685FE070]
00007fb1689e4e16  jmp 0x00007FB1689E4D1A
00007fb1689e4e1b  ucomisd xmm1, xmm15
00007fb1689e4e20  jp 0x00007FB1689E4E2F
00007fb1689e4e22  movaps xmm14, [0x00007FB1685FE060]
00007fb1689e4e2a  jmp 0x00007FB1689E4D47
00007fb1689e4e2f  vxorps xmm0, xmm1, xmm15
00007fb1689e4e34  pextrw eax, xmm0, 0x03
00007fb1689e4e39  and eax, 0x7FF8
00007fb1689e4e3e  cmp eax, 0x08
00007fb1689e4e41  jnz 0x00007FB1689E4D47
00007fb1689e4e47  movq rax, xmm15
00007fb1689e4e4c  shl rax, 0x0D
00007fb1689e4e50  jbe 0x00007FB1689E4D47
00007fb1689e4e56  vorps xmm14, xmm15, [0x00007FB1685FE070]
00007fb1689e4e5e  jmp 0x00007FB1689E4D47
00007fb1689e4e63  int3
00007fb1689e4e64  nop [rax+rax*1], ax
00007fb1689e4e6d  nop [rax], eax
00007fb1689e4e70  mov rax, [r15+0x48]
00007fb1689e4e74  mov r14, [r15+0x50]
00007fb1689e4e78  lea r12, [r14+rax*1]
00007fb1689e4e7c  movups xmm1, [r13+r12*1]
00007fb1689e4e82  movaps [r15+0x120], xmm1
00007fb1689e4e8a  lea r14, [rax+0x10]
00007fb1689e4e8e  mov [r15+0x48], r14
00007fb1689e4e92  xor eax, eax
00007fb1689e4e94  mov r12d, 0x200
00007fb1689e4e9a  cmp r14, r12
00007fb1689e4e9d  cmc
00007fb1689e4e9e  lahf
00007fb1689e4e9f  seto al
00007fb1689e4ea2  mov [r15+0x108], eax
00007fb1689e4ea9  pextrq rax, xmm1, 0x01
00007fb1689e4eb0  movq xmm15, rax
00007fb1689e4eb5  movaps [r15+0x130], xmm15
00007fb1689e4ebd  movaps xmm14, [r15+0x110]
00007fb1689e4ec5  movq rax, xmm14
00007fb1689e4eca  movq r14, xmm1
00007fb1689e4ecf  vmovq xmm1, rax
00007fb1689e4ed4  vmovq xmm14, r14
00007fb1689e4ed9  movaps xmm13, xmm1
00007fb1689e4edd  addsd xmm13, xmm14
00007fb1689e4ee2  ucomisd xmm13, xmm13
00007fb1689e4ee7  jp 0x00007FB1689E4F9C
00007fb1689e4eed  movq xmm13, xmm13
00007fb1689e4ef2  movq rax, xmm13
00007fb1689e4ef7  movq r14, xmm15
00007fb1689e4efc  vmovq xmm1, rax
00007fb1689e4f01  vmovq xmm15, r14
00007fb1689e4f06  movaps xmm14, xmm1
00007fb1689e4f0a  addsd xmm14, xmm15
00007fb1689e4f0f  ucomisd xmm14, xmm14
00007fb1689e4f14  jp 0x00007FB1689E4FE4
00007fb1689e4f1a  movq xmm14, xmm14
00007fb1689e4f1f  movaps [r15+0x110], xmm14
00007fb1689e4f27  mov eax, [r15+0x108]
00007fb1689e4f2e  sahf
00007fb1689e4f2f  jnz 0x00007FB1689E4F61
00007fb1689e4f31  cmp dword ptr [r15+0x318], 0x00
00007fb1689e4f39  jz 0x00007FB1689E5030
00007fb1689e4f3f  nop [rax+rax*1], ax
00007fb1689e4f48  nop [rax+rax*1], eax
00007fb1689e4f50  mov eax, 0x410704
00007fb1689e4f55  mov [r15+0x100], rax
00007fb1689e4f5c  jmp 0x00007FB1687FE110
00007fb1689e4f61  cmp dword ptr [r15+0x318], 0x00
00007fb1689e4f69  jz 0x00007FB1689E4E70
00007fb1689e4f6f  nop [rax+rax*1], ax
00007fb1689e4f78  nop [rax+rax*1], eax
00007fb1689e4f80  mov eax, 0x4106E8
00007fb1689e4f85  mov [r15+0x100], rax
00007fb1689e4f8c  jmp 0x00007FB1687FE110
00007fb1689e4f91  int3
00007fb1689e4f92  call 0x00007FB1688B52F0
00007fb1689e4f97  jmp 0x00007FB1689E4E82
00007fb1689e4f9c  ucomisd xmm1, xmm14
00007fb1689e4fa1  jp 0x00007FB1689E4FB0
00007fb1689e4fa3  movaps xmm13, [0x00007FB1685FE060]
00007fb1689e4fab  jmp 0x00007FB1689E4EED
00007fb1689e4fb0  vxorps xmm0, xmm1, xmm14
00007fb1689e4fb5  pextrw eax, xmm0, 0x03
00007fb1689e4fba  and eax, 0x7FF8
00007fb1689e4fbf  cmp eax, 0x08
00007fb1689e4fc2  jnz 0x00007FB1689E4EED
00007fb1689e4fc8  movq rax, xmm14
00007fb1689e4fcd  shl rax, 0x0D
00007fb1689e4fd1  jbe 0x00007FB1689E4EED
00007fb1689e4fd7  vorps xmm13, xmm14, [0x00007FB1685FE070]
00007fb1689e4fdf  jmp 0x00007FB1689E4EED
00007fb1689e4fe4  ucomisd xmm1, xmm15
00007fb1689e4fe9  jp 0x00007FB1689E4FF8
00007fb1689e4feb  movaps xmm14, [0x00007FB1685FE060]
00007fb1689e4ff3  jmp 0x00007FB1689E4F1A
00007fb1689e4ff8  vxorps xmm0, xmm1, xmm15
00007fb1689e4ffd  pextrw eax, xmm0, 0x03
00007fb1689e5002  and eax, 0x7FF8
00007fb1689e5007  cmp eax, 0x08
00007fb1689e500a  jnz 0x00007FB1689E4F1A
00007fb1689e5010  movq rax, xmm15
00007fb1689e5015  shl rax, 0x0D
00007fb1689e5019  jbe 0x00007FB1689E4F1A
00007fb1689e501f  vorps xmm14, xmm15, [0x00007FB1685FE070]
00007fb1689e5027  jmp 0x00007FB1689E4F1A
00007fb1689e502c  int3
00007fb1689e502d  nop [rax], eax
00007fb1689e5030  mov rax, [r15+0xF8]
00007fb1689e5037  lea r14, [rax+0x1D0]
00007fb1689e503e  mov r12, [r13+r14*1]
00007fb1689e5043  lea r14, [rax+0x1D8]
00007fb1689e504a  mov r11, [r13+r14*1]
00007fb1689e504f  mov [r15+0xA0], r12
00007fb1689e5056  mov [r15+0x98], r11
00007fb1689e505d  mov r14, [r15+0x40]
00007fb1689e5061  lea r12, [r14+0xCC0]
00007fb1689e5068  movaps xmm1, [r15+0x110]
00007fb1689e5070  movq r14, xmm1
00007fb1689e5075  mov [r13+r12*1], r14
00007fb1689e507a  lea r14, [rax+0x1C0]
00007fb1689e5081  mov r12, [r13+r14*1]
00007fb1689e5086  lea r14, [rax+0x1C8]
00007fb1689e508d  mov r11, [r13+r14*1]
00007fb1689e5092  mov [r15+0xE8], r12
00007fb1689e5099  mov [r15+0xF0], r11
00007fb1689e50a0  lea r14, [rax+0x1B0]
00007fb1689e50a7  mov r12, [r13+r14*1]
00007fb1689e50ac  lea r14, [rax+0x1B8]
00007fb1689e50b3  mov r10, [r13+r14*1]
00007fb1689e50b8  movq xmm1, r12
00007fb1689e50bd  movq xmm15, r10
00007fb1689e50c2  movq xmm1, xmm1
00007fb1689e50c6  movq xmm1, xmm1
00007fb1689e50ca  movaps [r15+0x1A0], xmm1
00007fb1689e50d2  movq xmm15, xmm15
00007fb1689e50d7  movq xmm15, xmm15
00007fb1689e50dc  movaps [r15+0x190], xmm15
00007fb1689e50e4  lea r14, [rax+0x1A0]
00007fb1689e50eb  mov r12, [r13+r14*1]
00007fb1689e50f0  lea r14, [rax+0x1A8]
00007fb1689e50f7  mov r10, [r13+r14*1]
00007fb1689e50fc  movq xmm1, r12
00007fb1689e5101  movq xmm15, r10
00007fb1689e5106  movq xmm1, xmm1
00007fb1689e510a  movq xmm1, xmm1
00007fb1689e510e  movaps [r15+0x1C0], xmm1
00007fb1689e5116  movq xmm15, xmm15
00007fb1689e511b  movq xmm15, xmm15
00007fb1689e5120  movaps [r15+0x1B0], xmm15
00007fb1689e5128  lea r14, [rax+0x190]
00007fb1689e512f  mov r12, [r13+r14*1]
00007fb1689e5134  lea r14, [rax+0x198]
00007fb1689e513b  mov r10, [r13+r14*1]
00007fb1689e5140  movq xmm1, r12
00007fb1689e5145  movq xmm15, r10
00007fb1689e514a  movq xmm1, xmm1
00007fb1689e514e  movq xmm1, xmm1
00007fb1689e5152  movaps [r15+0x1E0], xmm1
00007fb1689e515a  movq xmm15, xmm15
00007fb1689e515f  movq xmm15, xmm15
00007fb1689e5164  movaps [r15+0x1D0], xmm15
00007fb1689e516c  lea r14, [rax+0x180]
00007fb1689e5173  mov r12, [r13+r14*1]
00007fb1689e5178  lea r14, [rax+0x188]
00007fb1689e517f  mov r10, [r13+r14*1]
00007fb1689e5184  movq xmm1, r12
00007fb1689e5189  movq xmm15, r10
00007fb1689e518e  movq xmm1, xmm1
00007fb1689e5192  movq xmm1, xmm1
00007fb1689e5196  movaps [r15+0x200], xmm1
00007fb1689e519e  movq xmm15, xmm15
00007fb1689e51a3  movq xmm15, xmm15
00007fb1689e51a8  movaps [r15+0x1F0], xmm15
00007fb1689e51b0  lea r14, [rax+0x1E0]
00007fb1689e51b7  mov [r15+0xF8], r14
00007fb1689e51be  mov [r15+0x100], r11
00007fb1689e51c5  jmp 0x00007FB1689CE5C0
00007fb1689e51ca  int3
00007fb1689e51cb  call 0x00007FB1688E27E0
00007fb1689e51d0  jmp 0x00007FB1689E5043
00007fb1689e51d5  call 0x00007FB1688E1570
00007fb1689e51da  jmp 0x00007FB1689E504F
00007fb1689e51df  call 0x00007FB1688C3FE0
00007fb1689e51e4  jmp 0x00007FB1689E507A
00007fb1689e51e9  call 0x00007FB1688E27E0
00007fb1689e51ee  jmp 0x00007FB1689E5086
00007fb1689e51f3  call 0x00007FB1688E1570
00007fb1689e51f8  jmp 0x00007FB1689E5092
00007fb1689e51fd  call 0x00007FB1688E27E0
00007fb1689e5202  jmp 0x00007FB1689E50AC
00007fb1689e5207  call 0x00007FB1688E0300
00007fb1689e520c  jmp 0x00007FB1689E50B8
00007fb1689e5211  call 0x00007FB1688E27E0
00007fb1689e5216  jmp 0x00007FB1689E50F0
00007fb1689e521b  call 0x00007FB1688E0300
00007fb1689e5220  jmp 0x00007FB1689E50FC
00007fb1689e5225  call 0x00007FB1688E27E0
00007fb1689e522a  jmp 0x00007FB1689E5134
00007fb1689e522f  call 0x00007FB1688E0300
00007fb1689e5234  jmp 0x00007FB1689E5140
00007fb1689e5239  call 0x00007FB1688E27E0
00007fb1689e523e  jmp 0x00007FB1689E5178
00007fb1689e5243  call 0x00007FB1688E0300
00007fb1689e5248  jmp 0x00007FB1689E5184
00007fb1689e524d  int3
00007fb1689e524e  nop
00007fb1689e5250  mov qword ptr [r15+0x100], 0x04
00007fb1689e525b  mov esi, 0x00
00007fb1689e5260  mov edx, 0x09
00007fb1689e5265  mov rdi, 0x7FFF9ED2BD00
00007fb1689e526f  mov rax, 0x57CCFD2AC970
00007fb1689e5279  call rax
00007fb1689e527b  cmp dword ptr [r15+0x318], 0x00
00007fb1689e5283  jnz 0x00007FB1687FE110
00007fb1689e5289  jmp 0x00007FB1687FE0A0
00007fb1689e528e  int3
00007fb1689e528f  int3
