000079f4d2dce69b  nop [rax+rax*1], eax
000079f4d2dce6a0  mov rax, [r15+0xF8]
000079f4d2dce6a7  lea r14, [rax-0x1E0]
000079f4d2dce6ae  mov [r15+0xF8], r14
000079f4d2dce6b5  lea rax, [r14+0x1D0]
000079f4d2dce6bc  mov r12, [r15+0xA0]
000079f4d2dce6c3  mov r11, [r15+0x98]
000079f4d2dce6ca  mov [r13+rax*1], r12
000079f4d2dce6cf  lea rax, [r14+0x1D8]
000079f4d2dce6d6  mov [r13+rax*1], r11
000079f4d2dce6db  mov eax, 0x420AA0
000079f4d2dce6e0  movups xmm1, [r13+rax*1]
000079f4d2dce6e6  mov eax, 0x420A30
000079f4d2dce6eb  movups xmm15, [r13+rax*1]
000079f4d2dce6f1  mov eax, 0x420AC0
000079f4d2dce6f6  movups xmm14, [r13+rax*1]
000079f4d2dce6fc  mov eax, 0x420A60
000079f4d2dce701  movups xmm13, [r13+rax*1]
000079f4d2dce707  mov qword ptr [r15+0x98], 0x430CD0
000079f4d2dce712  mov eax, 0x420AD0
000079f4d2dce717  movups xmm12, [r13+rax*1]
000079f4d2dce71d  mov eax, 0x430CD0
000079f4d2dce722  movups [r13+rax*1], xmm1
000079f4d2dce728  mov eax, 0x430CE0
000079f4d2dce72d  movups [r13+rax*1], xmm15
000079f4d2dce733  mov eax, 0x430CF0
000079f4d2dce738  movups [r13+rax*1], xmm14
000079f4d2dce73e  mov eax, 0x430D00
000079f4d2dce743  movups [r13+rax*1], xmm13
000079f4d2dce749  mov eax, 0x420A20
000079f4d2dce74e  movups xmm14, [r13+rax*1]
000079f4d2dce754  mov eax, 0x420A10
000079f4d2dce759  movups xmm13, [r13+rax*1]
000079f4d2dce75f  mov eax, 0x430DD0
000079f4d2dce764  movups [r13+rax*1], xmm1
000079f4d2dce76a  mov eax, 0x430DE0
000079f4d2dce76f  movups [r13+rax*1], xmm15
000079f4d2dce775  mov eax, 0x430D10
000079f4d2dce77a  movups [r13+rax*1], xmm12
000079f4d2dce780  mov eax, 0x430D20
000079f4d2dce785  movups [r13+rax*1], xmm14
000079f4d2dce78b  mov eax, 0x420A00
000079f4d2dce790  movups xmm1, [r13+rax*1]
000079f4d2dce796  mov eax, 0x420A70
000079f4d2dce79b  movups xmm15, [r13+rax*1]
000079f4d2dce7a1  mov eax, 0x430D30
000079f4d2dce7a6  movups [r13+rax*1], xmm13
000079f4d2dce7ac  mov eax, 0x430D40
000079f4d2dce7b1  movups [r13+rax*1], xmm1
000079f4d2dce7b7  mov eax, 0x420A80
000079f4d2dce7bc  movups xmm1, [r13+rax*1]
000079f4d2dce7c2  mov eax, 0x420A50
000079f4d2dce7c7  movups xmm14, [r13+rax*1]
000079f4d2dce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000079f4d2dce7d5  mov eax, 0x430D50
000079f4d2dce7da  movups [r13+rax*1], xmm15
000079f4d2dce7e0  mov eax, 0x430D60
000079f4d2dce7e5  movups [r13+rax*1], xmm1
000079f4d2dce7eb  mov eax, 0x420AF0
000079f4d2dce7f0  movups xmm1, [r13+rax*1]
000079f4d2dce7f6  mov eax, 0x420B00
000079f4d2dce7fb  movups xmm15, [r13+rax*1]
000079f4d2dce801  movaps [r15+0x150], xmm15
000079f4d2dce809  mov qword ptr [r15+0xA0], 0x3E8
000079f4d2dce814  mov eax, 0x430D70
000079f4d2dce819  movups [r13+rax*1], xmm14
000079f4d2dce81f  mov eax, 0x430D80
000079f4d2dce824  movups [r13+rax*1], xmm1
000079f4d2dce82a  mov eax, 0x420AE0
000079f4d2dce82f  movups xmm1, [r13+rax*1]
000079f4d2dce835  mov eax, 0x420A90
000079f4d2dce83a  movups xmm14, [r13+rax*1]
000079f4d2dce840  movaps [r15+0x140], xmm14
000079f4d2dce848  lea rax, [r14+0x180]
000079f4d2dce84f  movq xmm13, qword ptr [r15+0x200]
000079f4d2dce858  movq xmm12, qword ptr [r15+0x1F0]
000079f4d2dce861  movq r12, xmm13
000079f4d2dce866  movq r11, xmm12
000079f4d2dce86b  mov [r13+rax*1], r12
000079f4d2dce870  lea rax, [r14+0x188]
000079f4d2dce877  mov [r13+rax*1], r11
000079f4d2dce87c  mov eax, 0x430D90
000079f4d2dce881  movups [r13+rax*1], xmm15
000079f4d2dce887  mov eax, 0x430DA0
000079f4d2dce88c  movups [r13+rax*1], xmm1
000079f4d2dce892  mov eax, 0x420AB0
000079f4d2dce897  movups xmm1, [r13+rax*1]
000079f4d2dce89d  mov eax, 0x420B18
000079f4d2dce8a2  mov r12, [r13+rax*1]
000079f4d2dce8a7  movq xmm15, r12
000079f4d2dce8ac  mov qword ptr [r15+0x40], 0x420B20
000079f4d2dce8b4  mov eax, 0x430DB0
000079f4d2dce8b9  movups [r13+rax*1], xmm14
000079f4d2dce8bf  mov eax, 0x430DC0
000079f4d2dce8c4  movups [r13+rax*1], xmm1
000079f4d2dce8ca  mov eax, 0x420B80
000079f4d2dce8cf  movups xmm1, [r13+rax*1]
000079f4d2dce8d5  movq rax, xmm15
000079f4d2dce8da  mov r12d, 0x430DF0
000079f4d2dce8e0  mov [r13+r12*1], rax
000079f4d2dce8e5  mov eax, 0x420B60
000079f4d2dce8ea  movups xmm15, [r13+rax*1]
000079f4d2dce8f0  mov eax, 0x420B70
000079f4d2dce8f5  movups xmm14, [r13+rax*1]
000079f4d2dce8fb  lea rax, [r14+0x160]
000079f4d2dce902  movups [r13+rax*1], xmm1
000079f4d2dce908  lea rax, [r14+0x190]
000079f4d2dce90f  movq xmm1, qword ptr [r15+0x1E0]
000079f4d2dce918  movq xmm13, qword ptr [r15+0x1D0]
000079f4d2dce921  movq r12, xmm1
000079f4d2dce926  movq r11, xmm13
000079f4d2dce92b  mov [r13+rax*1], r12
000079f4d2dce930  lea rax, [r14+0x198]
000079f4d2dce937  mov [r13+rax*1], r11
000079f4d2dce93c  lea rax, [r14+0x140]
000079f4d2dce943  movups [r13+rax*1], xmm15
000079f4d2dce949  lea rax, [r14+0x150]
000079f4d2dce950  movups [r13+rax*1], xmm14
000079f4d2dce956  mov eax, 0x420B20
000079f4d2dce95b  movups xmm1, [r13+rax*1]
000079f4d2dce961  mov eax, 0x420B30
000079f4d2dce966  movups xmm15, [r13+rax*1]
000079f4d2dce96c  movaps [r15+0x120], xmm15
000079f4d2dce974  lea rax, [r14+0x1A0]
000079f4d2dce97b  movq xmm14, qword ptr [r15+0x1C0]
000079f4d2dce984  movq xmm13, qword ptr [r15+0x1B0]
000079f4d2dce98d  movq r12, xmm14
000079f4d2dce992  movq r11, xmm13
000079f4d2dce997  mov [r13+rax*1], r12
000079f4d2dce99c  lea rax, [r14+0x1A8]
000079f4d2dce9a3  mov [r13+rax*1], r11
000079f4d2dce9a8  lea rax, [r14+0x1B0]
000079f4d2dce9af  movq xmm14, qword ptr [r15+0x1A0]
000079f4d2dce9b8  movq xmm13, qword ptr [r15+0x190]
000079f4d2dce9c1  movq r12, xmm14
000079f4d2dce9c6  movq r11, xmm13
000079f4d2dce9cb  mov [r13+rax*1], r12
000079f4d2dce9d0  lea rax, [r14+0x1B8]
000079f4d2dce9d7  mov [r13+rax*1], r11
000079f4d2dce9dc  lea rax, [r14+0x100]
000079f4d2dce9e3  movups [r13+rax*1], xmm1
000079f4d2dce9e9  lea rax, [r14+0x110]
000079f4d2dce9f0  movups [r13+rax*1], xmm15
000079f4d2dce9f6  mov eax, 0x420B40
000079f4d2dce9fb  movups xmm1, [r13+rax*1]
000079f4d2dcea01  mov eax, 0x420B50
000079f4d2dcea06  movups xmm15, [r13+rax*1]
000079f4d2dcea0c  movaps [r15+0x110], xmm1
000079f4d2dcea14  movaps [r15+0x130], xmm15
000079f4d2dcea1c  lea rax, [r14+0x1C0]
000079f4d2dcea23  mov r12, [r15+0xE8]
000079f4d2dcea2a  mov r11, [r15+0xF0]
000079f4d2dcea31  mov [r13+rax*1], r12
000079f4d2dcea36  lea rax, [r14+0x1C8]
000079f4d2dcea3d  mov [r13+rax*1], r11
000079f4d2dcea42  mov eax, 0x430DF8
000079f4d2dcea47  mov r12d, 0x421DF8D3
000079f4d2dcea4d  mov [r13+rax*1], r12d
000079f4d2dcea52  lea rax, [r14+0x120]
000079f4d2dcea59  movups [r13+rax*1], xmm1
000079f4d2dcea5f  lea rax, [r14+0x130]
000079f4d2dcea66  movups [r13+rax*1], xmm15
000079f4d2dcea6c  lea rax, [r14+0x100]
000079f4d2dcea73  mov [r15], rax
000079f4d2dcea76  mov qword ptr [r15+0x08], 0x430CD0
000079f4d2dcea7e  mov qword ptr [r15+0x10], 0x12C
000079f4d2dcea86  mov qword ptr [r15+0xF0], 0x410284
000079f4d2dcea91  mov r14d, [r15+0x320]
000079f4d2dcea98  mov eax, 0x410284
000079f4d2dcea9d  mov rcx, 0x79F4D2DD07C0
000079f4d2dceaa7  mov [r15+r14*8+0x328], rax
000079f4d2dceaaf  mov [r15+r14*8+0x368], rcx
000079f4d2dceab7  add r14d, 0x01
000079f4d2dceabb  and r14d, 0x07
000079f4d2dceabf  mov [r15+0x320], r14d
000079f4d2dceac6  cmp dword ptr [r15+0x318], 0x00
000079f4d2dceace  jz 0x000079F4D2DCED70
000079f4d2dcead4  nop [rax+rax*1], ax
000079f4d2dceadd  nop [rax+rax*1], eax
000079f4d2dceae5  mov eax, 0x410728
000079f4d2dceaea  mov [r15+0x100], rax
000079f4d2dceaf1  jmp 0x000079F4D2BFE110
000079f4d2dceaf6  int3
000079f4d2dceaf7  call 0x000079F4D2C0BC20
000079f4d2dceafc  jmp 0x000079F4D2DCE6CF
000079f4d2dceb01  call 0x000079F4D2C0A9A0
000079f4d2dceb06  jmp 0x000079F4D2DCE6DB
000079f4d2dceb0b  call 0x000079F4D2BFF430
000079f4d2dceb10  jmp 0x000079F4D2DCE6E6
000079f4d2dceb15  call 0x000079F4D2C0E760
000079f4d2dceb1a  jmp 0x000079F4D2DCE6F1
000079f4d2dceb1f  call 0x000079F4D2C0D4E0
000079f4d2dceb24  jmp 0x000079F4D2DCE6FC
000079f4d2dceb29  call 0x000079F4D2C0C260
000079f4d2dceb2e  jmp 0x000079F4D2DCE707
000079f4d2dceb33  call 0x000079F4D2C0AFE0
000079f4d2dceb38  jmp 0x000079F4D2DCE71D
000079f4d2dceb3d  call 0x000079F4D2BFF540
000079f4d2dceb42  jmp 0x000079F4D2DCE728
000079f4d2dceb47  call 0x000079F4D2C0E880
000079f4d2dceb4c  jmp 0x000079F4D2DCE733
000079f4d2dceb51  call 0x000079F4D2C0D600
000079f4d2dceb56  jmp 0x000079F4D2DCE73E
000079f4d2dceb5b  call 0x000079F4D2C0C380
000079f4d2dceb60  jmp 0x000079F4D2DCE749
000079f4d2dceb65  call 0x000079F4D2C0D4E0
000079f4d2dceb6a  jmp 0x000079F4D2DCE754
000079f4d2dceb6f  call 0x000079F4D2C0C260
000079f4d2dceb74  jmp 0x000079F4D2DCE75F
000079f4d2dceb79  call 0x000079F4D2BFF540
000079f4d2dceb7e  jmp 0x000079F4D2DCE76A
000079f4d2dceb83  call 0x000079F4D2C0E880
000079f4d2dceb88  jmp 0x000079F4D2DCE775
000079f4d2dceb8d  call 0x000079F4D2C0B100
000079f4d2dceb92  jmp 0x000079F4D2DCE780
000079f4d2dceb97  call 0x000079F4D2C0D600
000079f4d2dceb9c  jmp 0x000079F4D2DCE78B
000079f4d2dceba1  call 0x000079F4D2BFF430
000079f4d2dceba6  jmp 0x000079F4D2DCE796
000079f4d2dcebab  call 0x000079F4D2C0E760
000079f4d2dcebb0  jmp 0x000079F4D2DCE7A1
000079f4d2dcebb5  call 0x000079F4D2C0C380
000079f4d2dcebba  jmp 0x000079F4D2DCE7AC
000079f4d2dcebbf  call 0x000079F4D2BFF540
000079f4d2dcebc4  jmp 0x000079F4D2DCE7B7
000079f4d2dcebc9  call 0x000079F4D2BFF430
000079f4d2dcebce  jmp 0x000079F4D2DCE7C2
000079f4d2dcebd3  call 0x000079F4D2C0D4E0
000079f4d2dcebd8  jmp 0x000079F4D2DCE7CD
000079f4d2dcebdd  call 0x000079F4D2C0E880
000079f4d2dcebe2  jmp 0x000079F4D2DCE7E0
000079f4d2dcebe7  call 0x000079F4D2BFF540
000079f4d2dcebec  jmp 0x000079F4D2DCE7EB
000079f4d2dcebf1  call 0x000079F4D2BFF430
000079f4d2dcebf6  jmp 0x000079F4D2DCE7F6
000079f4d2dcebfb  call 0x000079F4D2C0E760
000079f4d2dcec00  jmp 0x000079F4D2DCE801
000079f4d2dcec05  call 0x000079F4D2C0D600
000079f4d2dcec0a  jmp 0x000079F4D2DCE81F
000079f4d2dcec0f  call 0x000079F4D2BFF540
000079f4d2dcec14  jmp 0x000079F4D2DCE82A
000079f4d2dcec19  call 0x000079F4D2BFF430
000079f4d2dcec1e  jmp 0x000079F4D2DCE835
000079f4d2dcec23  call 0x000079F4D2C0D4E0
000079f4d2dcec28  jmp 0x000079F4D2DCE840
000079f4d2dcec2d  call 0x000079F4D2C0BC20
000079f4d2dcec32  jmp 0x000079F4D2DCE870
000079f4d2dcec37  call 0x000079F4D2C0A9A0
000079f4d2dcec3c  jmp 0x000079F4D2DCE87C
000079f4d2dcec41  call 0x000079F4D2C0E880
000079f4d2dcec46  jmp 0x000079F4D2DCE887
000079f4d2dcec4b  call 0x000079F4D2BFF540
000079f4d2dcec50  jmp 0x000079F4D2DCE892
000079f4d2dcec55  call 0x000079F4D2BFF430
000079f4d2dcec5a  jmp 0x000079F4D2DCE89D
000079f4d2dcec5f  call 0x000079F4D2C0B720
000079f4d2dcec64  jmp 0x000079F4D2DCE8A7
000079f4d2dcec69  call 0x000079F4D2C0D600
000079f4d2dcec6e  jmp 0x000079F4D2DCE8BF
000079f4d2dcec73  call 0x000079F4D2BFF540
000079f4d2dcec78  jmp 0x000079F4D2DCE8CA
000079f4d2dcec7d  call 0x000079F4D2BFF430
000079f4d2dcec82  jmp 0x000079F4D2DCE8D5
000079f4d2dcec87  call 0x000079F4D2CB4CB0
000079f4d2dcec8c  jmp 0x000079F4D2DCE8E5
000079f4d2dcec91  call 0x000079F4D2C0E760
000079f4d2dcec96  jmp 0x000079F4D2DCE8F0
000079f4d2dcec9b  call 0x000079F4D2C0D4E0
000079f4d2dceca0  jmp 0x000079F4D2DCE8FB
000079f4d2dceca5  call 0x000079F4D2BFF540
000079f4d2dcecaa  jmp 0x000079F4D2DCE908
000079f4d2dcecaf  call 0x000079F4D2C0BC20
000079f4d2dcecb4  jmp 0x000079F4D2DCE930
000079f4d2dcecb9  call 0x000079F4D2C0A9A0
000079f4d2dcecbe  jmp 0x000079F4D2DCE93C
000079f4d2dcecc3  call 0x000079F4D2C0E880
000079f4d2dcecc8  jmp 0x000079F4D2DCE949
000079f4d2dceccd  call 0x000079F4D2C0D600
000079f4d2dcecd2  jmp 0x000079F4D2DCE956
000079f4d2dcecd7  call 0x000079F4D2BFF430
000079f4d2dcecdc  jmp 0x000079F4D2DCE961
000079f4d2dcece1  call 0x000079F4D2C0E760
000079f4d2dcece6  jmp 0x000079F4D2DCE96C
000079f4d2dceceb  call 0x000079F4D2C0BC20
000079f4d2dcecf0  jmp 0x000079F4D2DCE99C
000079f4d2dcecf5  call 0x000079F4D2C0A9A0
000079f4d2dcecfa  jmp 0x000079F4D2DCE9A8
000079f4d2dcecff  call 0x000079F4D2C0BC20
000079f4d2dced04  jmp 0x000079F4D2DCE9D0
000079f4d2dced09  call 0x000079F4D2C0A9A0
000079f4d2dced0e  jmp 0x000079F4D2DCE9DC
000079f4d2dced13  call 0x000079F4D2BFF540
000079f4d2dced18  jmp 0x000079F4D2DCE9E9
000079f4d2dced1d  call 0x000079F4D2C0E880
000079f4d2dced22  jmp 0x000079F4D2DCE9F6
000079f4d2dced27  call 0x000079F4D2BFF430
000079f4d2dced2c  jmp 0x000079F4D2DCEA01
000079f4d2dced31  call 0x000079F4D2C0E760
000079f4d2dced36  jmp 0x000079F4D2DCEA0C
000079f4d2dced3b  call 0x000079F4D2C0BC20
000079f4d2dced40  jmp 0x000079F4D2DCEA36
000079f4d2dced45  call 0x000079F4D2C0A9A0
000079f4d2dced4a  jmp 0x000079F4D2DCEA42
000079f4d2dced4f  call 0x000079F4D2C0BAE0
000079f4d2dced54  jmp 0x000079F4D2DCEA52
000079f4d2dced59  call 0x000079F4D2BFF540
000079f4d2dced5e  jmp 0x000079F4D2DCEA5F
000079f4d2dced63  call 0x000079F4D2C0E880
000079f4d2dced68  jmp 0x000079F4D2DCEA6C
000079f4d2dced6d  int3
000079f4d2dced6e  nop
000079f4d2dced70  mov rax, [r15]
000079f4d2dced73  lea r14, [rax+0x20]
000079f4d2dced77  mov r12, [r13+r14*1]
000079f4d2dced7c  mov r14, [r15+0x10]
000079f4d2dced80  lea r11, [r12+r14*1]
000079f4d2dced84  mov [r15+0x40], r11
000079f4d2dced88  lea r12, [rax+0x20]
000079f4d2dced8c  mov [r13+r12*1], r11
000079f4d2dced91  test r14, r14
000079f4d2dced94  setz r14b
000079f4d2dced98  movzx r14, r14b
000079f4d2dced9c  mov [rsp+0x414], r14b
000079f4d2dceda4  cmp byte ptr [rsp+0x414], 0x00
000079f4d2dcedac  jz 0x000079F4D2DCEDDE
000079f4d2dcedae  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcedb6  mov eax, 0x4109A0
000079f4d2dcedbb  mov [r15+0x100], rax
000079f4d2dcedc2  jz 0x000079F4D2BFE0A0
000079f4d2dcedc8  nop [rax+rax*1], eax
000079f4d2dcedcd  mov eax, 0x4109A0
000079f4d2dcedd2  mov [r15+0x100], rax
000079f4d2dcedd9  jmp 0x000079F4D2BFE110
000079f4d2dcedde  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcede6  jz 0x000079F4D2DCEE30
000079f4d2dcedec  nop [rax+rax*1], ax
000079f4d2dcedf5  nop [rax+rax*1], eax
000079f4d2dcedfd  mov eax, 0x410738
000079f4d2dcee02  mov [r15+0x100], rax
000079f4d2dcee09  jmp 0x000079F4D2BFE110
000079f4d2dcee0e  int3
000079f4d2dcee0f  call 0x000079F4D2CE27E0
000079f4d2dcee14  jmp 0x000079F4D2DCED7C
000079f4d2dcee19  call 0x000079F4D2CC0860
000079f4d2dcee1e  jmp 0x000079F4D2DCED91
000079f4d2dcee23  int3
000079f4d2dcee24  nop [rax+rax*1], ax
000079f4d2dcee2d  nop [rax], eax
000079f4d2dcee30  mov rax, [r15+0xF8]
000079f4d2dcee37  lea r14, [rax-0x150]
000079f4d2dcee3e  mov [r15+0xF8], r14
000079f4d2dcee45  mov rax, [r15]
000079f4d2dcee48  lea r12, [rax+0x68]
000079f4d2dcee4c  mov r11, [r13+r12*1]
000079f4d2dcee51  mov [r15+0x88], r11
000079f4d2dcee58  lea r12, [rax+0x28]
000079f4d2dcee5c  mov [r15+0x40], r12
000079f4d2dcee60  mov [r15+0x48], r14
000079f4d2dcee64  mov qword ptr [r15+0x50], 0x420B90
000079f4d2dcee6c  lea rax, [r14+0x100]
000079f4d2dcee73  mov r12, [r15+0xE8]
000079f4d2dcee7a  mov r11, [r15+0xD8]
000079f4d2dcee81  mov [r13+rax*1], r12
000079f4d2dcee86  lea rax, [r14+0x108]
000079f4d2dcee8d  mov [r13+rax*1], r11
000079f4d2dcee92  lea rax, [r14+0x110]
000079f4d2dcee99  mov r12, [r15+0xD0]
000079f4d2dceea0  mov r11, [r15+0xC8]
000079f4d2dceea7  mov [r13+rax*1], r12
000079f4d2dceeac  lea rax, [r14+0x118]
000079f4d2dceeb3  mov [r13+rax*1], r11
000079f4d2dceeb8  lea rax, [r14+0x120]
000079f4d2dceebf  mov r12, [r15+0xC0]
000079f4d2dceec6  mov r11, [r15+0xB8]
000079f4d2dceecd  mov [r13+rax*1], r12
000079f4d2dceed2  lea rax, [r14+0x128]
000079f4d2dceed9  mov [r13+rax*1], r11
000079f4d2dceede  lea rax, [r14+0x130]
000079f4d2dceee5  mov r12, [r15+0xB0]
000079f4d2dceeec  mov r11, [r15+0xA8]
000079f4d2dceef3  mov [r13+rax*1], r12
000079f4d2dceef8  lea rax, [r14+0x138]
000079f4d2dceeff  mov [r13+rax*1], r11
000079f4d2dcef04  lea rax, [r14+0x140]
000079f4d2dcef0b  mov r12, [r15+0xA0]
000079f4d2dcef12  mov r11, [r15+0x98]
000079f4d2dcef19  mov [r13+rax*1], r12
000079f4d2dcef1e  lea rax, [r14+0x148]
000079f4d2dcef25  mov [r13+rax*1], r11
000079f4d2dcef2a  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcef32  jz 0x000079F4D2DCEFD0
000079f4d2dcef38  nop [rax+rax*1], ax
000079f4d2dcef41  nop [rax+rax*1], eax
000079f4d2dcef49  mov eax, 0x410770
000079f4d2dcef4e  mov [r15+0x100], rax
000079f4d2dcef55  jmp 0x000079F4D2BFE110
000079f4d2dcef5a  int3
000079f4d2dcef5b  call 0x000079F4D2CC0370
000079f4d2dcef60  jmp 0x000079F4D2DCEE51
000079f4d2dcef65  call 0x000079F4D2C0BC20
000079f4d2dcef6a  jmp 0x000079F4D2DCEE86
000079f4d2dcef6f  call 0x000079F4D2C0A9A0
000079f4d2dcef74  jmp 0x000079F4D2DCEE92
000079f4d2dcef79  call 0x000079F4D2C0BC20
000079f4d2dcef7e  jmp 0x000079F4D2DCEEAC
000079f4d2dcef83  call 0x000079F4D2C0A9A0
000079f4d2dcef88  jmp 0x000079F4D2DCEEB8
000079f4d2dcef8d  call 0x000079F4D2C0BC20
000079f4d2dcef92  jmp 0x000079F4D2DCEED2
000079f4d2dcef97  call 0x000079F4D2C0A9A0
000079f4d2dcef9c  jmp 0x000079F4D2DCEEDE
000079f4d2dcefa1  call 0x000079F4D2C0BC20
000079f4d2dcefa6  jmp 0x000079F4D2DCEEF8
000079f4d2dcefab  call 0x000079F4D2C0A9A0
000079f4d2dcefb0  jmp 0x000079F4D2DCEF04
000079f4d2dcefb5  call 0x000079F4D2C0BC20
000079f4d2dcefba  jmp 0x000079F4D2DCEF1E
000079f4d2dcefbf  call 0x000079F4D2C0A9A0
000079f4d2dcefc4  jmp 0x000079F4D2DCEF2A
000079f4d2dcefc9  int3
000079f4d2dcefca  nop [rax+rax*1], ax
000079f4d2dcefd0  mov rax, [r15+0x08]
000079f4d2dcefd4  movzx r14d, byte ptr [r13+rax*1]
000079f4d2dcefda  movzx r14d, r14b
000079f4d2dcefde  mov [rsp+0x10], r14d
000079f4d2dcefe3  mov r14d, r14d
000079f4d2dcefe6  mov [r15+0x58], r14
000079f4d2dcefea  lea r14, [rax+0x01]
000079f4d2dcefee  mov [r15+0x08], r14
000079f4d2dceff2  mov rax, [r15+0x88]
000079f4d2dceff9  lea r14, [rax+0x01]
000079f4d2dceffd  mov r12, [r15]
000079f4d2dcf000  lea r11, [r12+0x68]
000079f4d2dcf005  mov [r13+r11*1], r14
000079f4d2dcf00a  lea r14, [r12+rax*1]
000079f4d2dcf00e  mov [r15+0x60], r14
000079f4d2dcf012  lea rax, [r14+0x28]
000079f4d2dcf016  mov r11d, [rsp+0x10]
000079f4d2dcf01b  movzx r14d, r11b
000079f4d2dcf01f  mov [r13+rax*1], r14b
000079f4d2dcf024  lea rax, [r12+0x68]
000079f4d2dcf029  mov r14, [r13+rax*1]
000079f4d2dcf02e  mov [r15+0x88], r14
000079f4d2dcf035  xor eax, eax
000079f4d2dcf037  mov r12d, 0x40
000079f4d2dcf03d  cmp r14, r12
000079f4d2dcf040  cmc
000079f4d2dcf041  lahf
000079f4d2dcf042  seto al
000079f4d2dcf045  mov [r15+0x108], eax
000079f4d2dcf04c  mov eax, [r15+0x108]
000079f4d2dcf053  sahf
000079f4d2dcf054  jnz 0x000079F4D2DCF086
000079f4d2dcf056  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcf05e  jz 0x000079F4D2DCF170
000079f4d2dcf064  nop [rax+rax*1], ax
000079f4d2dcf06d  nop [rax+rax*1], eax
000079f4d2dcf075  mov eax, 0x410790
000079f4d2dcf07a  mov [r15+0x100], rax
000079f4d2dcf081  jmp 0x000079F4D2BFE110
000079f4d2dcf086  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcf08e  jz 0x000079F4D2DCF0E0
000079f4d2dcf094  nop [rax+rax*1], ax
000079f4d2dcf09d  nop [rax+rax*1], eax
000079f4d2dcf0a5  mov eax, 0x410768
000079f4d2dcf0aa  mov [r15+0x100], rax
000079f4d2dcf0b1  jmp 0x000079F4D2BFE110
000079f4d2dcf0b6  int3
000079f4d2dcf0b7  call 0x000079F4D2C0D860
000079f4d2dcf0bc  jmp 0x000079F4D2DCEFDA
000079f4d2dcf0c1  call 0x000079F4D2CB36E0
000079f4d2dcf0c6  jmp 0x000079F4D2DCF00A
000079f4d2dcf0cb  call 0x000079F4D2C0DD60
000079f4d2dcf0d0  jmp 0x000079F4D2DCF024
000079f4d2dcf0d5  call 0x000079F4D2C0DC20
000079f4d2dcf0da  jmp 0x000079F4D2DCF02E
000079f4d2dcf0df  int3
000079f4d2dcf0e0  mov rax, [r15+0x10]
000079f4d2dcf0e4  lea r14, [rax-0x01]
000079f4d2dcf0e8  mov [r15+0x10], r14
000079f4d2dcf0ec  test r14, r14
000079f4d2dcf0ef  setz r14b
000079f4d2dcf0f3  movzx r14, r14b
000079f4d2dcf0f7  mov [rsp+0x414], r14b
000079f4d2dcf0ff  cmp byte ptr [rsp+0x414], 0x00
000079f4d2dcf107  jz 0x000079F4D2DCF139
000079f4d2dcf109  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcf111  jz 0x000079F4D2DD0670
000079f4d2dcf117  nop [rax+rax*1], ax
000079f4d2dcf120  nop [rax+rax*1], eax
000079f4d2dcf128  mov eax, 0x410988
000079f4d2dcf12d  mov [r15+0x100], rax
000079f4d2dcf134  jmp 0x000079F4D2BFE110
000079f4d2dcf139  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcf141  jz 0x000079F4D2DCEFD0
000079f4d2dcf147  nop [rax+rax*1], ax
000079f4d2dcf150  nop [rax+rax*1], eax
000079f4d2dcf158  mov eax, 0x410770
000079f4d2dcf15d  mov [r15+0x100], rax
000079f4d2dcf164  jmp 0x000079F4D2BFE110
000079f4d2dcf169  int3
000079f4d2dcf16a  int3
000079f4d2dcf16b  nop [rax+rax*1], eax
000079f4d2dcf170  mov rax, [r15+0x40]
000079f4d2dcf174  movzx r14d, byte ptr [r13+rax*1]
000079f4d2dcf17a  movaps xmm1, [r15+0x110]
000079f4d2dcf182  pinsrb xmm1, r14d, 0x00
000079f4d2dcf189  lea r14, [rax+0x01]
000079f4d2dcf18d  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf193  movaps xmm15, [r15+0x120]
000079f4d2dcf19b  pinsrb xmm15, r12d, 0x00
000079f4d2dcf1a2  lea r14, [rax+0x02]
000079f4d2dcf1a6  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf1ac  movaps xmm14, [r15+0x130]
000079f4d2dcf1b4  pinsrb xmm14, r12d, 0x00
000079f4d2dcf1bb  lea r14, [rax+0x03]
000079f4d2dcf1bf  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf1c5  movaps xmm13, [r15+0x140]
000079f4d2dcf1cd  pinsrb xmm13, r12d, 0x00
000079f4d2dcf1d4  lea r14, [rax+0x04]
000079f4d2dcf1d8  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf1de  pinsrb xmm1, r12d, 0x01
000079f4d2dcf1e5  lea r14, [rax+0x05]
000079f4d2dcf1e9  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf1ef  pinsrb xmm15, r12d, 0x01
000079f4d2dcf1f6  lea r14, [rax+0x06]
000079f4d2dcf1fa  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf200  pinsrb xmm14, r12d, 0x01
000079f4d2dcf207  lea r14, [rax+0x07]
000079f4d2dcf20b  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf211  pinsrb xmm13, r12d, 0x01
000079f4d2dcf218  lea r14, [rax+0x08]
000079f4d2dcf21c  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf222  pinsrb xmm1, r12d, 0x02
000079f4d2dcf229  lea r14, [rax+0x09]
000079f4d2dcf22d  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf233  pinsrb xmm15, r12d, 0x02
000079f4d2dcf23a  lea r14, [rax+0x0A]
000079f4d2dcf23e  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf244  pinsrb xmm14, r12d, 0x02
000079f4d2dcf24b  lea r14, [rax+0x0B]
000079f4d2dcf24f  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf255  pinsrb xmm13, r12d, 0x02
000079f4d2dcf25c  lea r14, [rax+0x0C]
000079f4d2dcf260  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf266  pinsrb xmm1, r12d, 0x03
000079f4d2dcf26d  lea r14, [rax+0x0D]
000079f4d2dcf271  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf277  pinsrb xmm15, r12d, 0x03
000079f4d2dcf27e  lea r14, [rax+0x0E]
000079f4d2dcf282  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf288  pinsrb xmm14, r12d, 0x03
000079f4d2dcf28f  lea r14, [rax+0x0F]
000079f4d2dcf293  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf299  pinsrb xmm13, r12d, 0x03
000079f4d2dcf2a0  lea r14, [rax+0x10]
000079f4d2dcf2a4  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf2aa  pinsrb xmm1, r12d, 0x04
000079f4d2dcf2b1  lea r14, [rax+0x11]
000079f4d2dcf2b5  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf2bb  pinsrb xmm15, r12d, 0x04
000079f4d2dcf2c2  lea r14, [rax+0x12]
000079f4d2dcf2c6  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf2cc  pinsrb xmm14, r12d, 0x04
000079f4d2dcf2d3  lea r14, [rax+0x13]
000079f4d2dcf2d7  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf2dd  pinsrb xmm13, r12d, 0x04
000079f4d2dcf2e4  lea r14, [rax+0x14]
000079f4d2dcf2e8  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf2ee  pinsrb xmm1, r12d, 0x05
000079f4d2dcf2f5  lea r14, [rax+0x15]
000079f4d2dcf2f9  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf2ff  pinsrb xmm15, r12d, 0x05
000079f4d2dcf306  lea r14, [rax+0x16]
000079f4d2dcf30a  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf310  pinsrb xmm14, r12d, 0x05
000079f4d2dcf317  lea r14, [rax+0x17]
000079f4d2dcf31b  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf321  pinsrb xmm13, r12d, 0x05
000079f4d2dcf328  lea r14, [rax+0x18]
000079f4d2dcf32c  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf332  pinsrb xmm1, r12d, 0x06
000079f4d2dcf339  lea r14, [rax+0x19]
000079f4d2dcf33d  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf343  pinsrb xmm15, r12d, 0x06
000079f4d2dcf34a  lea r14, [rax+0x1A]
000079f4d2dcf34e  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf354  pinsrb xmm14, r12d, 0x06
000079f4d2dcf35b  lea r14, [rax+0x1B]
000079f4d2dcf35f  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf365  pinsrb xmm13, r12d, 0x06
000079f4d2dcf36c  lea r14, [rax+0x1C]
000079f4d2dcf370  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf376  pinsrb xmm1, r12d, 0x07
000079f4d2dcf37d  lea r14, [rax+0x1D]
000079f4d2dcf381  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf387  pinsrb xmm15, r12d, 0x07
000079f4d2dcf38e  lea r14, [rax+0x1E]
000079f4d2dcf392  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf398  pinsrb xmm14, r12d, 0x07
000079f4d2dcf39f  lea r14, [rax+0x1F]
000079f4d2dcf3a3  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf3a9  pinsrb xmm13, r12d, 0x07
000079f4d2dcf3b0  lea r14, [rax+0x20]
000079f4d2dcf3b4  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf3ba  pinsrb xmm1, r12d, 0x08
000079f4d2dcf3c1  lea r14, [rax+0x21]
000079f4d2dcf3c5  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf3cb  pinsrb xmm15, r12d, 0x08
000079f4d2dcf3d2  lea r14, [rax+0x22]
000079f4d2dcf3d6  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf3dc  pinsrb xmm14, r12d, 0x08
000079f4d2dcf3e3  lea r14, [rax+0x23]
000079f4d2dcf3e7  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf3ed  pinsrb xmm13, r12d, 0x08
000079f4d2dcf3f4  lea r14, [rax+0x24]
000079f4d2dcf3f8  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf3fe  pinsrb xmm1, r12d, 0x09
000079f4d2dcf405  lea r14, [rax+0x25]
000079f4d2dcf409  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf40f  pinsrb xmm15, r12d, 0x09
000079f4d2dcf416  lea r14, [rax+0x26]
000079f4d2dcf41a  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf420  pinsrb xmm14, r12d, 0x09
000079f4d2dcf427  lea r14, [rax+0x27]
000079f4d2dcf42b  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf431  pinsrb xmm13, r12d, 0x09
000079f4d2dcf438  lea r14, [rax+0x28]
000079f4d2dcf43c  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf442  pinsrb xmm1, r12d, 0x0A
000079f4d2dcf449  lea r14, [rax+0x29]
000079f4d2dcf44d  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf453  pinsrb xmm15, r12d, 0x0A
000079f4d2dcf45a  lea r14, [rax+0x2A]
000079f4d2dcf45e  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf464  pinsrb xmm14, r12d, 0x0A
000079f4d2dcf46b  lea r14, [rax+0x2B]
000079f4d2dcf46f  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf475  pinsrb xmm13, r12d, 0x0A
000079f4d2dcf47c  lea r14, [rax+0x2C]
000079f4d2dcf480  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf486  pinsrb xmm1, r12d, 0x0B
000079f4d2dcf48d  lea r14, [rax+0x2D]
000079f4d2dcf491  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf497  pinsrb xmm15, r12d, 0x0B
000079f4d2dcf49e  lea r14, [rax+0x2E]
000079f4d2dcf4a2  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf4a8  pinsrb xmm14, r12d, 0x0B
000079f4d2dcf4af  lea r14, [rax+0x2F]
000079f4d2dcf4b3  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf4b9  pinsrb xmm13, r12d, 0x0B
000079f4d2dcf4c0  lea r14, [rax+0x30]
000079f4d2dcf4c4  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf4ca  pinsrb xmm1, r12d, 0x0C
000079f4d2dcf4d1  lea r14, [rax+0x31]
000079f4d2dcf4d5  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf4db  pinsrb xmm15, r12d, 0x0C
000079f4d2dcf4e2  lea r14, [rax+0x32]
000079f4d2dcf4e6  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf4ec  pinsrb xmm14, r12d, 0x0C
000079f4d2dcf4f3  lea r14, [rax+0x33]
000079f4d2dcf4f7  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf4fd  pinsrb xmm13, r12d, 0x0C
000079f4d2dcf504  lea r14, [rax+0x34]
000079f4d2dcf508  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf50e  pinsrb xmm1, r12d, 0x0D
000079f4d2dcf515  lea r14, [rax+0x35]
000079f4d2dcf519  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf51f  pinsrb xmm15, r12d, 0x0D
000079f4d2dcf526  lea r14, [rax+0x36]
000079f4d2dcf52a  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf530  pinsrb xmm14, r12d, 0x0D
000079f4d2dcf537  lea r14, [rax+0x37]
000079f4d2dcf53b  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf541  pinsrb xmm13, r12d, 0x0D
000079f4d2dcf548  lea r14, [rax+0x38]
000079f4d2dcf54c  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf552  pinsrb xmm1, r12d, 0x0E
000079f4d2dcf559  lea r14, [rax+0x39]
000079f4d2dcf55d  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf563  pinsrb xmm15, r12d, 0x0E
000079f4d2dcf56a  lea r14, [rax+0x3A]
000079f4d2dcf56e  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf574  pinsrb xmm14, r12d, 0x0E
000079f4d2dcf57b  lea r14, [rax+0x3B]
000079f4d2dcf57f  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf585  pinsrb xmm13, r12d, 0x0E
000079f4d2dcf58c  lea r14, [rax+0x3C]
000079f4d2dcf590  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf596  pinsrb xmm1, r12d, 0x0F
000079f4d2dcf59d  movaps [r15+0x110], xmm1
000079f4d2dcf5a5  lea r14, [rax+0x3D]
000079f4d2dcf5a9  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf5af  pinsrb xmm15, r12d, 0x0F
000079f4d2dcf5b6  movaps [r15+0x120], xmm15
000079f4d2dcf5be  lea r14, [rax+0x3E]
000079f4d2dcf5c2  movzx r12d, byte ptr [r13+r14*1]
000079f4d2dcf5c8  pinsrb xmm14, r12d, 0x0F
000079f4d2dcf5cf  movaps [r15+0x130], xmm14
000079f4d2dcf5d7  lea r14, [rax+0x3F]
000079f4d2dcf5db  movzx eax, byte ptr [r13+r14*1]
000079f4d2dcf5e1  pinsrb xmm13, eax, 0x0F
000079f4d2dcf5e8  movaps [r15+0x140], xmm13
000079f4d2dcf5f0  movq xmm1, qword ptr [r15+0x120]
000079f4d2dcf5f9  pmovzxbw xmm1, xmm1
000079f4d2dcf5fe  psllw xmm1, 0x00
000079f4d2dcf603  movaps [r15+0x150], xmm1
000079f4d2dcf60b  movq xmm1, qword ptr [r15+0x130]
000079f4d2dcf614  pmovzxbw xmm1, xmm1
000079f4d2dcf619  psllw xmm1, 0x00
000079f4d2dcf61e  movaps [r15+0x160], xmm1
000079f4d2dcf626  movq xmm1, qword ptr [r15+0x110]
000079f4d2dcf62f  pmovzxbw xmm1, xmm1
000079f4d2dcf634  psllw xmm1, 0x00
000079f4d2dcf639  movaps [r15+0x170], xmm1
000079f4d2dcf641  movaps xmm15, [r15+0x110]
000079f4d2dcf649  pextrq rax, xmm15, 0x01
000079f4d2dcf650  movq xmm15, rax
000079f4d2dcf655  pmovzxbw xmm15, xmm15
000079f4d2dcf65b  psllw xmm15, 0x00
000079f4d2dcf661  movaps [r15+0x180], xmm15
000079f4d2dcf669  movaps xmm14, [r15+0x120]
000079f4d2dcf671  pextrq rax, xmm14, 0x01
000079f4d2dcf678  movq xmm14, rax
000079f4d2dcf67d  pmovzxbw xmm14, xmm14
000079f4d2dcf683  psllw xmm14, 0x00
000079f4d2dcf689  movaps [r15+0x210], xmm14
000079f4d2dcf691  movaps xmm13, [r15+0x130]
000079f4d2dcf699  pextrq rax, xmm13, 0x01
000079f4d2dcf6a0  movq xmm13, rax
000079f4d2dcf6a5  pmovzxbw xmm13, xmm13
000079f4d2dcf6ab  psllw xmm13, 0x00
000079f4d2dcf6b1  movaps [r15+0x220], xmm13
000079f4d2dcf6b9  movq xmm12, qword ptr [r15+0x140]
000079f4d2dcf6c2  pmovzxbw xmm12, xmm12
000079f4d2dcf6c8  psllw xmm12, 0x00
000079f4d2dcf6ce  movaps [r15+0x250], xmm12
000079f4d2dcf6d6  movaps xmm12, [r15+0x140]
000079f4d2dcf6de  pextrq rax, xmm12, 0x01
000079f4d2dcf6e5  movq xmm12, rax
000079f4d2dcf6ea  pmovzxbw xmm12, xmm12
000079f4d2dcf6f0  psllw xmm12, 0x00
000079f4d2dcf6f6  movaps [r15+0x110], xmm12
000079f4d2dcf6fe  movq xmm11, qword ptr [r15+0x150]
000079f4d2dcf707  pmovzxwd xmm11, xmm11
000079f4d2dcf70d  pslld xmm11, 0x10
000079f4d2dcf713  movq xmm10, qword ptr [r15+0x160]
000079f4d2dcf71c  pmovzxwd xmm10, xmm10
000079f4d2dcf722  pslld xmm10, 0x08
000079f4d2dcf728  pextrq rax, xmm1, 0x01
000079f4d2dcf72f  movq xmm1, rax
000079f4d2dcf734  pmovzxwd xmm1, xmm1
000079f4d2dcf739  pslld xmm1, 0x00
000079f4d2dcf73e  movaps [r15+0x260], xmm1
000079f4d2dcf746  pextrq rax, xmm15, 0x01
000079f4d2dcf74d  movq xmm15, rax
000079f4d2dcf752  pmovzxwd xmm15, xmm15
000079f4d2dcf758  pslld xmm15, 0x00
000079f4d2dcf75e  movaps [r15+0x270], xmm15
000079f4d2dcf766  movq xmm9, qword ptr [r15+0x170]
000079f4d2dcf76f  pmovzxwd xmm9, xmm9
000079f4d2dcf775  pslld xmm9, 0x00
000079f4d2dcf77b  pextrq rax, xmm14, 0x01
000079f4d2dcf782  movq xmm14, rax
000079f4d2dcf787  pmovzxwd xmm14, xmm14
000079f4d2dcf78d  pslld xmm14, 0x10
000079f4d2dcf793  movaps [r15+0x280], xmm14
000079f4d2dcf79b  movq xmm8, qword ptr [r15+0x180]
000079f4d2dcf7a4  pmovzxwd xmm8, xmm8
000079f4d2dcf7aa  pslld xmm8, 0x00
000079f4d2dcf7b0  movq xmm7, qword ptr [r15+0x210]
000079f4d2dcf7b9  pmovzxwd xmm7, xmm7
000079f4d2dcf7be  pslld xmm7, 0x10
000079f4d2dcf7c3  movaps xmm6, [r15+0x150]
000079f4d2dcf7cb  pextrq rax, xmm6, 0x01
000079f4d2dcf7d2  movq xmm6, rax
000079f4d2dcf7d7  pmovzxwd xmm6, xmm6
000079f4d2dcf7dc  pslld xmm6, 0x10
000079f4d2dcf7e1  por xmm11, xmm10
000079f4d2dcf7e6  movaps [r15+0x230], xmm11
000079f4d2dcf7ee  pextrq rax, xmm13, 0x01
000079f4d2dcf7f5  movq xmm13, rax
000079f4d2dcf7fa  pmovzxwd xmm13, xmm13
000079f4d2dcf800  pslld xmm13, 0x08
000079f4d2dcf806  movaps [r15+0x240], xmm13
000079f4d2dcf80e  movq xmm10, qword ptr [r15+0x220]
000079f4d2dcf817  pmovzxwd xmm10, xmm10
000079f4d2dcf81d  pslld xmm10, 0x08
000079f4d2dcf823  movaps xmm5, [r15+0x160]
000079f4d2dcf82b  pextrq rax, xmm5, 0x01
000079f4d2dcf832  movq xmm5, rax
000079f4d2dcf837  pmovzxwd xmm5, xmm5
000079f4d2dcf83c  pslld xmm5, 0x08
000079f4d2dcf841  pslld xmm9, 0x18
000079f4d2dcf847  pslld xmm15, 0x18
000079f4d2dcf84d  pslld xmm8, 0x18
000079f4d2dcf853  movq xmm4, qword ptr [r15+0x250]
000079f4d2dcf85c  pmovzxwd xmm4, xmm4
000079f4d2dcf861  pslld xmm4, 0x00
000079f4d2dcf866  por xmm14, xmm13
000079f4d2dcf86b  por xmm7, xmm10
000079f4d2dcf870  movaps [r15+0x210], xmm7
000079f4d2dcf878  pslld xmm1, 0x18
000079f4d2dcf87d  movaps [r15+0x220], xmm1
000079f4d2dcf885  por xmm6, xmm5
000079f4d2dcf889  por xmm11, xmm9
000079f4d2dcf88e  movaps [r15+0x160], xmm11
000079f4d2dcf896  pextrq rax, xmm12, 0x01
000079f4d2dcf89d  movq xmm13, rax
000079f4d2dcf8a2  pmovzxwd xmm13, xmm13
000079f4d2dcf8a8  pslld xmm13, 0x00
000079f4d2dcf8ae  movaps [r15+0x170], xmm13
000079f4d2dcf8b6  movq xmm12, qword ptr [r15+0x110]
000079f4d2dcf8bf  pmovzxwd xmm12, xmm12
000079f4d2dcf8c5  pslld xmm12, 0x00
000079f4d2dcf8cb  por xmm14, xmm15
000079f4d2dcf8d0  por xmm7, xmm8
000079f4d2dcf8d5  movaps xmm15, [r15+0x250]
000079f4d2dcf8dd  pextrq rax, xmm15, 0x01
000079f4d2dcf8e4  movq xmm15, rax
000079f4d2dcf8e9  pmovzxwd xmm15, xmm15
000079f4d2dcf8ef  pslld xmm15, 0x00
000079f4d2dcf8f5  movaps [r15+0x180], xmm15
000079f4d2dcf8fd  por xmm6, xmm1
000079f4d2dcf901  movaps [r15+0x150], xmm6
000079f4d2dcf909  por xmm11, xmm4
000079f4d2dcf90e  movaps [r15+0x140], xmm11
000079f4d2dcf916  por xmm7, xmm12
000079f4d2dcf91b  movaps [r15+0x110], xmm7
000079f4d2dcf923  por xmm14, xmm13
000079f4d2dcf928  movaps [r15+0x120], xmm14
000079f4d2dcf930  por xmm6, xmm15
000079f4d2dcf935  movaps [r15+0x130], xmm6
000079f4d2dcf93d  mov rax, [r15+0xF8]
000079f4d2dcf944  lea r14, [rax+0x20]
000079f4d2dcf948  movups [r13+r14*1], xmm7
000079f4d2dcf94e  lea r14, [rax+0x30]
000079f4d2dcf952  movups [r13+r14*1], xmm14
000079f4d2dcf958  movups [r13+rax*1], xmm11
000079f4d2dcf95e  lea r14, [rax+0x10]
000079f4d2dcf962  movups [r13+r14*1], xmm6
000079f4d2dcf968  mov r14d, [r13+rax*1]
000079f4d2dcf96d  mov rax, [r15+0x48]
000079f4d2dcf971  mov [r15+0x68], rax
000079f4d2dcf975  mov qword ptr [r15+0x58], 0x04
000079f4d2dcf97d  lea r12, [rax+0x04]
000079f4d2dcf981  mov r11d, [r13+r12*1]
000079f4d2dcf986  mov [rsp+0x10], r11d
000079f4d2dcf98b  mov r11d, r11d
000079f4d2dcf98e  mov [r15+0x70], r11
000079f4d2dcf992  lea r12, [rax+0x38]
000079f4d2dcf996  mov r11d, [r13+r12*1]
000079f4d2dcf99b  lea r12, [rax+0x24]
000079f4d2dcf99f  mov r10d, [r13+r12*1]
000079f4d2dcf9a4  mov [rsp+0x20], r10d
000079f4d2dcf9a9  mov r10d, r10d
000079f4d2dcf9ac  mov [r15+0x90], r10
000079f4d2dcf9b3  mov [rsp+0x30], rax
000079f4d2dcf9b8  xor eax, eax
000079f4d2dcf9ba  mov r12d, 0x04
000079f4d2dcf9c0  mov r10d, 0xC0
000079f4d2dcf9c6  cmp r12, r10
000079f4d2dcf9c9  cmc
000079f4d2dcf9ca  lahf
000079f4d2dcf9cb  seto al
000079f4d2dcf9ce  mov [r15+0x108], eax
000079f4d2dcf9d5  mov eax, [rsp+0x10]
000079f4d2dcf9d9  mov r12d, [rsp+0x10]
000079f4d2dcf9de  shrd eax, r12d, 0x07
000079f4d2dcf9e3  mov [rsp+0x10], r11d
000079f4d2dcf9e8  mov r10d, [rsp+0x10]
000079f4d2dcf9ed  shrd r11d, r10d, 0x11
000079f4d2dcf9f2  mov r9d, [rsp+0x20]
000079f4d2dcf9f7  lea r8d, [r9d+r14d*1]
000079f4d2dcf9fc  rorx r14d, r12d, 0x12
000079f4d2dcfa02  xor eax, r14d
000079f4d2dcfa05  rorx r14d, r10d, 0x13
000079f4d2dcfa0b  xor r11d, r14d
000079f4d2dcfa0e  mov [rsp+0x10], r11d
000079f4d2dcfa13  mov r11d, r11d
000079f4d2dcfa16  mov [r15+0x88], r11
000079f4d2dcfa1d  mov [rsp+0x20], r12d
000079f4d2dcfa22  shr r12d, 0x03
000079f4d2dcfa26  xor eax, r12d
000079f4d2dcfa29  mov [rsp+0x40], eax
000079f4d2dcfa2d  mov eax, eax
000079f4d2dcfa2f  mov [r15+0x80], rax
000079f4d2dcfa36  shr r10d, 0x0A
000079f4d2dcfa3a  mov eax, [rsp+0x10]
000079f4d2dcfa3e  xor eax, r10d
000079f4d2dcfa41  mov [rsp+0x10], eax
000079f4d2dcfa45  mov eax, eax
000079f4d2dcfa47  mov [r15+0x78], rax
000079f4d2dcfa4b  mov eax, [rsp+0x40]
000079f4d2dcfa4f  lea r14d, [r8d+eax*1]
000079f4d2dcfa54  mov eax, [rsp+0x10]
000079f4d2dcfa58  lea r12d, [r14d+eax*1]
000079f4d2dcfa5d  mov rax, [rsp+0x30]
000079f4d2dcfa62  lea r14, [rax+0x40]
000079f4d2dcfa66  mov [r13+r14*1], r12d
000079f4d2dcfa6b  mov eax, [rsp+0x20]
000079f4d2dcfa6f  mov eax, eax
000079f4d2dcfa71  mov [r15+0x60], rax
000079f4d2dcfa75  mov eax, [r15+0x108]
000079f4d2dcfa7c  sahf
000079f4d2dcfa7d  jnz 0x000079F4D2DCFAAF
000079f4d2dcfa7f  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcfa87  jz 0x000079F4D2DCFF70
000079f4d2dcfa8d  nop [rax+rax*1], ax
000079f4d2dcfa96  nop [rax+rax*1], eax
000079f4d2dcfa9e  mov eax, 0x41088C
000079f4d2dcfaa3  mov [r15+0x100], rax
000079f4d2dcfaaa  jmp 0x000079F4D2BFE110
000079f4d2dcfaaf  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcfab7  jz 0x000079F4D2DCFDC0
000079f4d2dcfabd  nop [rax+rax*1], ax
000079f4d2dcfac6  nop [rax+rax*1], eax
000079f4d2dcface  mov eax, 0x410844
000079f4d2dcfad3  mov [r15+0x100], rax
000079f4d2dcfada  jmp 0x000079F4D2BFE110
000079f4d2dcfadf  int3
000079f4d2dcfae0  call 0x000079F4D2C0D860
000079f4d2dcfae5  jmp 0x000079F4D2DCF17A
000079f4d2dcfaea  call 0x000079F4D2CE2420
000079f4d2dcfaef  jmp 0x000079F4D2DCF193
000079f4d2dcfaf4  call 0x000079F4D2CE2420
000079f4d2dcfaf9  jmp 0x000079F4D2DCF1AC
000079f4d2dcfafe  call 0x000079F4D2CE2420
000079f4d2dcfb03  jmp 0x000079F4D2DCF1C5
000079f4d2dcfb08  call 0x000079F4D2CE2420
000079f4d2dcfb0d  jmp 0x000079F4D2DCF1DE
000079f4d2dcfb12  call 0x000079F4D2CE2420
000079f4d2dcfb17  jmp 0x000079F4D2DCF1EF
000079f4d2dcfb1c  call 0x000079F4D2CE2420
000079f4d2dcfb21  jmp 0x000079F4D2DCF200
000079f4d2dcfb26  call 0x000079F4D2CE2420
000079f4d2dcfb2b  jmp 0x000079F4D2DCF211
000079f4d2dcfb30  call 0x000079F4D2CE2420
000079f4d2dcfb35  jmp 0x000079F4D2DCF222
000079f4d2dcfb3a  call 0x000079F4D2CE2420
000079f4d2dcfb3f  jmp 0x000079F4D2DCF233
000079f4d2dcfb44  call 0x000079F4D2CE2420
000079f4d2dcfb49  jmp 0x000079F4D2DCF244
000079f4d2dcfb4e  call 0x000079F4D2CE2420
000079f4d2dcfb53  jmp 0x000079F4D2DCF255
000079f4d2dcfb58  call 0x000079F4D2CE2420
000079f4d2dcfb5d  jmp 0x000079F4D2DCF266
000079f4d2dcfb62  call 0x000079F4D2CE2420
000079f4d2dcfb67  jmp 0x000079F4D2DCF277
000079f4d2dcfb6c  call 0x000079F4D2CE2420
000079f4d2dcfb71  jmp 0x000079F4D2DCF288
000079f4d2dcfb76  call 0x000079F4D2CE2420
000079f4d2dcfb7b  jmp 0x000079F4D2DCF299
000079f4d2dcfb80  call 0x000079F4D2CE2420
000079f4d2dcfb85  jmp 0x000079F4D2DCF2AA
000079f4d2dcfb8a  call 0x000079F4D2CE2420
000079f4d2dcfb8f  jmp 0x000079F4D2DCF2BB
000079f4d2dcfb94  call 0x000079F4D2CE2420
000079f4d2dcfb99  jmp 0x000079F4D2DCF2CC
000079f4d2dcfb9e  call 0x000079F4D2CE2420
000079f4d2dcfba3  jmp 0x000079F4D2DCF2DD
000079f4d2dcfba8  call 0x000079F4D2CE2420
000079f4d2dcfbad  jmp 0x000079F4D2DCF2EE
000079f4d2dcfbb2  call 0x000079F4D2CE2420
000079f4d2dcfbb7  jmp 0x000079F4D2DCF2FF
000079f4d2dcfbbc  call 0x000079F4D2CE2420
000079f4d2dcfbc1  jmp 0x000079F4D2DCF310
000079f4d2dcfbc6  call 0x000079F4D2CE2420
000079f4d2dcfbcb  jmp 0x000079F4D2DCF321
000079f4d2dcfbd0  call 0x000079F4D2CE2420
000079f4d2dcfbd5  jmp 0x000079F4D2DCF332
000079f4d2dcfbda  call 0x000079F4D2CE2420
000079f4d2dcfbdf  jmp 0x000079F4D2DCF343
000079f4d2dcfbe4  call 0x000079F4D2CE2420
000079f4d2dcfbe9  jmp 0x000079F4D2DCF354
000079f4d2dcfbee  call 0x000079F4D2CE2420
000079f4d2dcfbf3  jmp 0x000079F4D2DCF365
000079f4d2dcfbf8  call 0x000079F4D2CE2420
000079f4d2dcfbfd  jmp 0x000079F4D2DCF376
000079f4d2dcfc02  call 0x000079F4D2CE2420
000079f4d2dcfc07  jmp 0x000079F4D2DCF387
000079f4d2dcfc0c  call 0x000079F4D2CE2420
000079f4d2dcfc11  jmp 0x000079F4D2DCF398
000079f4d2dcfc16  call 0x000079F4D2CE2420
000079f4d2dcfc1b  jmp 0x000079F4D2DCF3A9
000079f4d2dcfc20  call 0x000079F4D2CE2420
000079f4d2dcfc25  jmp 0x000079F4D2DCF3BA
000079f4d2dcfc2a  call 0x000079F4D2CE2420
000079f4d2dcfc2f  jmp 0x000079F4D2DCF3CB
000079f4d2dcfc34  call 0x000079F4D2CE2420
000079f4d2dcfc39  jmp 0x000079F4D2DCF3DC
000079f4d2dcfc3e  call 0x000079F4D2CE2420
000079f4d2dcfc43  jmp 0x000079F4D2DCF3ED
000079f4d2dcfc48  call 0x000079F4D2CE2420
000079f4d2dcfc4d  jmp 0x000079F4D2DCF3FE
000079f4d2dcfc52  call 0x000079F4D2CE2420
000079f4d2dcfc57  jmp 0x000079F4D2DCF40F
000079f4d2dcfc5c  call 0x000079F4D2CE2420
000079f4d2dcfc61  jmp 0x000079F4D2DCF420
000079f4d2dcfc66  call 0x000079F4D2CE2420
000079f4d2dcfc6b  jmp 0x000079F4D2DCF431
000079f4d2dcfc70  call 0x000079F4D2CE2420
000079f4d2dcfc75  jmp 0x000079F4D2DCF442
000079f4d2dcfc7a  call 0x000079F4D2CE2420
000079f4d2dcfc7f  jmp 0x000079F4D2DCF453
000079f4d2dcfc84  call 0x000079F4D2CE2420
000079f4d2dcfc89  jmp 0x000079F4D2DCF464
000079f4d2dcfc8e  call 0x000079F4D2CE2420
000079f4d2dcfc93  jmp 0x000079F4D2DCF475
000079f4d2dcfc98  call 0x000079F4D2CE2420
000079f4d2dcfc9d  jmp 0x000079F4D2DCF486
000079f4d2dcfca2  call 0x000079F4D2CE2420
000079f4d2dcfca7  jmp 0x000079F4D2DCF497
000079f4d2dcfcac  call 0x000079F4D2CE2420
000079f4d2dcfcb1  jmp 0x000079F4D2DCF4A8
000079f4d2dcfcb6  call 0x000079F4D2CE2420
000079f4d2dcfcbb  jmp 0x000079F4D2DCF4B9
000079f4d2dcfcc0  call 0x000079F4D2CE2420
000079f4d2dcfcc5  jmp 0x000079F4D2DCF4CA
000079f4d2dcfcca  call 0x000079F4D2CE2420
000079f4d2dcfccf  jmp 0x000079F4D2DCF4DB
000079f4d2dcfcd4  call 0x000079F4D2CE2420
000079f4d2dcfcd9  jmp 0x000079F4D2DCF4EC
000079f4d2dcfcde  call 0x000079F4D2CE2420
000079f4d2dcfce3  jmp 0x000079F4D2DCF4FD
000079f4d2dcfce8  call 0x000079F4D2CE2420
000079f4d2dcfced  jmp 0x000079F4D2DCF50E
000079f4d2dcfcf2  call 0x000079F4D2CE2420
000079f4d2dcfcf7  jmp 0x000079F4D2DCF51F
000079f4d2dcfcfc  call 0x000079F4D2CE2420
000079f4d2dcfd01  jmp 0x000079F4D2DCF530
000079f4d2dcfd06  call 0x000079F4D2CE2420
000079f4d2dcfd0b  jmp 0x000079F4D2DCF541
000079f4d2dcfd10  call 0x000079F4D2CE2420
000079f4d2dcfd15  jmp 0x000079F4D2DCF552
000079f4d2dcfd1a  call 0x000079F4D2CE2420
000079f4d2dcfd1f  jmp 0x000079F4D2DCF563
000079f4d2dcfd24  call 0x000079F4D2CE2420
000079f4d2dcfd29  jmp 0x000079F4D2DCF574
000079f4d2dcfd2e  call 0x000079F4D2CE2420
000079f4d2dcfd33  jmp 0x000079F4D2DCF585
000079f4d2dcfd38  call 0x000079F4D2CE2420
000079f4d2dcfd3d  jmp 0x000079F4D2DCF596
000079f4d2dcfd42  call 0x000079F4D2CE2420
000079f4d2dcfd47  jmp 0x000079F4D2DCF5AF
000079f4d2dcfd4c  call 0x000079F4D2CE2420
000079f4d2dcfd51  jmp 0x000079F4D2DCF5C8
000079f4d2dcfd56  call 0x000079F4D2CD5610
000079f4d2dcfd5b  jmp 0x000079F4D2DCF5E1
000079f4d2dcfd60  call 0x000079F4D2CDC580
000079f4d2dcfd65  jmp 0x000079F4D2DCF94E
000079f4d2dcfd6a  call 0x000079F4D2CE46C0
000079f4d2dcfd6f  jmp 0x000079F4D2DCF958
000079f4d2dcfd74  call 0x000079F4D2C09E90
000079f4d2dcfd79  jmp 0x000079F4D2DCF95E
000079f4d2dcfd7e  call 0x000079F4D2CDB310
000079f4d2dcfd83  jmp 0x000079F4D2DCF968
000079f4d2dcfd88  call 0x000079F4D2C0DAE0
000079f4d2dcfd8d  jmp 0x000079F4D2DCF96D
000079f4d2dcfd92  call 0x000079F4D2CC0230
000079f4d2dcfd97  jmp 0x000079F4D2DCF986
000079f4d2dcfd9c  call 0x000079F4D2CC0230
000079f4d2dcfda1  jmp 0x000079F4D2DCF99B
000079f4d2dcfda6  call 0x000079F4D2CBEFC0
000079f4d2dcfdab  jmp 0x000079F4D2DCF9A4
000079f4d2dcfdb0  call 0x000079F4D2CE2BA0
000079f4d2dcfdb5  jmp 0x000079F4D2DCFA6B
000079f4d2dcfdba  int3
000079f4d2dcfdbb  nop [rax+rax*1], eax
000079f4d2dcfdc0  mov rax, [r15+0x48]
000079f4d2dcfdc4  mov r14, [r15+0x58]
000079f4d2dcfdc8  lea r12, [rax+r14*1]
000079f4d2dcfdcc  mov [r15+0x68], r12
000079f4d2dcfdd0  lea rax, [r14+0x04]
000079f4d2dcfdd4  mov [r15+0x58], rax
000079f4d2dcfdd8  lea r14, [r12+0x04]
000079f4d2dcfddd  mov r11d, [r13+r14*1]
000079f4d2dcfde2  mov [rsp+0x10], r11d
000079f4d2dcfde7  mov r11d, r11d
000079f4d2dcfdea  mov [r15+0x70], r11
000079f4d2dcfdee  lea r14, [r12+0x38]
000079f4d2dcfdf3  mov r11d, [r13+r14*1]
000079f4d2dcfdf8  lea r14, [r12+0x24]
000079f4d2dcfdfd  mov r10d, [r13+r14*1]
000079f4d2dcfe02  mov [rsp+0x20], r10d
000079f4d2dcfe07  mov r10d, r10d
000079f4d2dcfe0a  mov [r15+0x90], r10
000079f4d2dcfe11  mov [rsp+0x30], rax
000079f4d2dcfe16  xor eax, eax
000079f4d2dcfe18  mov r14, [rsp+0x30]
000079f4d2dcfe1d  mov r10d, 0xC0
000079f4d2dcfe23  cmp r14, r10
000079f4d2dcfe26  cmc
000079f4d2dcfe27  lahf
000079f4d2dcfe28  seto al
000079f4d2dcfe2b  mov [r15+0x108], eax
000079f4d2dcfe32  mov eax, [rsp+0x10]
000079f4d2dcfe36  mov r14d, [rsp+0x10]
000079f4d2dcfe3b  shrd eax, r14d, 0x07
000079f4d2dcfe40  mov [rsp+0x10], r11d
000079f4d2dcfe45  mov r10d, [rsp+0x10]
000079f4d2dcfe4a  shrd r11d, r10d, 0x11
000079f4d2dcfe4f  mov r9d, [r15+0x60]
000079f4d2dcfe53  mov r8d, [rsp+0x20]
000079f4d2dcfe58  lea ebp, [r8d+r9d*1]
000079f4d2dcfe5d  rorx r9d, r14d, 0x12
000079f4d2dcfe63  xor eax, r9d
000079f4d2dcfe66  rorx r9d, r10d, 0x13
000079f4d2dcfe6c  xor r11d, r9d
000079f4d2dcfe6f  mov [rsp+0x10], r11d
000079f4d2dcfe74  mov r11d, r11d
000079f4d2dcfe77  mov [r15+0x88], r11
000079f4d2dcfe7e  mov [rsp+0x20], r14d
000079f4d2dcfe83  shr r14d, 0x03
000079f4d2dcfe87  xor eax, r14d
000079f4d2dcfe8a  mov [rsp+0x30], eax
000079f4d2dcfe8e  mov eax, eax
000079f4d2dcfe90  mov [r15+0x80], rax
000079f4d2dcfe97  shr r10d, 0x0A
000079f4d2dcfe9b  mov eax, [rsp+0x10]
000079f4d2dcfe9f  xor eax, r10d
000079f4d2dcfea2  mov [rsp+0x10], eax
000079f4d2dcfea6  mov eax, eax
000079f4d2dcfea8  mov [r15+0x78], rax
000079f4d2dcfeac  mov eax, [rsp+0x30]
000079f4d2dcfeb0  lea r14d, [ebp+eax*1]
000079f4d2dcfeb6  mov eax, [rsp+0x10]
000079f4d2dcfeba  lea r11d, [r14d+eax*1]
000079f4d2dcfebf  lea rax, [r12+0x40]
000079f4d2dcfec4  mov [r13+rax*1], r11d
000079f4d2dcfec9  mov eax, [rsp+0x20]
000079f4d2dcfecd  mov eax, eax
000079f4d2dcfecf  mov [r15+0x60], rax
000079f4d2dcfed3  mov eax, [r15+0x108]
000079f4d2dcfeda  sahf
000079f4d2dcfedb  jnz 0x000079F4D2DCFF0D
000079f4d2dcfedd  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcfee5  jz 0x000079F4D2DCFF70
000079f4d2dcfeeb  nop [rax+rax*1], ax
000079f4d2dcfef4  nop [rax+rax*1], eax
000079f4d2dcfefc  mov eax, 0x41088C
000079f4d2dcff01  mov [r15+0x100], rax
000079f4d2dcff08  jmp 0x000079F4D2BFE110
000079f4d2dcff0d  cmp dword ptr [r15+0x318], 0x00
000079f4d2dcff15  jz 0x000079F4D2DCFDC0
000079f4d2dcff1b  nop [rax+rax*1], ax
000079f4d2dcff24  nop [rax+rax*1], eax
000079f4d2dcff2c  mov eax, 0x410844
000079f4d2dcff31  mov [r15+0x100], rax
000079f4d2dcff38  jmp 0x000079F4D2BFE110
000079f4d2dcff3d  int3
000079f4d2dcff3e  call 0x000079F4D2CE1430
000079f4d2dcff43  jmp 0x000079F4D2DCFDE2
000079f4d2dcff48  call 0x000079F4D2CE1430
000079f4d2dcff4d  jmp 0x000079F4D2DCFDF8
000079f4d2dcff52  call 0x000079F4D2CE01C0
000079f4d2dcff57  jmp 0x000079F4D2DCFE02
000079f4d2dcff5c  call 0x000079F4D2C0A860
000079f4d2dcff61  jmp 0x000079F4D2DCFEC9
000079f4d2dcff66  int3
000079f4d2dcff67  nop [rax+rax*1], ax
000079f4d2dcff70  mov rax, [r15]
000079f4d2dcff73  mov r14d, [r13+rax*1]
000079f4d2dcff78  lea r12, [rax+0x04]
000079f4d2dcff7c  mov r11d, [r13+r12*1]
000079f4d2dcff81  mov [rsp+0x10], r14d
000079f4d2dcff86  mov r14d, r14d
000079f4d2dcff89  mov [r15+0x78], r14
000079f4d2dcff8d  mov [rsp+0x20], r11d
000079f4d2dcff92  mov r11d, r11d
000079f4d2dcff95  mov [r15+0x80], r11
000079f4d2dcff9c  lea r14, [rax+0x08]
000079f4d2dcffa0  mov r12d, [r13+r14*1]
000079f4d2dcffa5  lea r14, [rax+0x0C]
000079f4d2dcffa9  mov r11d, [r13+r14*1]
000079f4d2dcffae  mov [rsp+0x30], r12d
000079f4d2dcffb3  mov r12d, r12d
000079f4d2dcffb6  mov [r15+0x70], r12
000079f4d2dcffba  mov [rsp+0x40], r11d
000079f4d2dcffbf  mov r11d, r11d
000079f4d2dcffc2  mov [r15+0x68], r11
000079f4d2dcffc6  lea r14, [rax+0x18]
000079f4d2dcffca  mov r12d, [r13+r14*1]
000079f4d2dcffcf  lea r14, [rax+0x1C]
000079f4d2dcffd3  mov r11d, [r13+r14*1]
000079f4d2dcffd8  mov [rsp+0x50], r12d
000079f4d2dcffdd  mov r12d, r12d
000079f4d2dcffe0  mov [r15+0x58], r12
000079f4d2dcffe4  mov [rsp+0x60], r11d
000079f4d2dcffe9  mov r11d, r11d
000079f4d2dcffec  mov [r15+0x60], r11
000079f4d2dcfff0  lea r14, [rax+0x10]
000079f4d2dcfff4  mov r12d, [r13+r14*1]
000079f4d2dcfff9  lea r14, [rax+0x14]
000079f4d2dcfffd  mov eax, [r13+r14*1]
000079f4d2dd0002  mov [rsp+0x70], r12d
000079f4d2dd0007  mov r12d, r12d
000079f4d2dd000a  mov [r15+0x18], r12
000079f4d2dd000e  mov [rsp+0x80], eax
000079f4d2dd0015  mov eax, eax
000079f4d2dd0017  mov [r15+0x90], rax
000079f4d2dd001e  mov eax, [rsp+0x70]
000079f4d2dd0022  mov eax, eax
000079f4d2dd0024  mov [r15+0x30], rax
000079f4d2dd0028  mov eax, [rsp+0x50]
000079f4d2dd002c  mov eax, eax
000079f4d2dd002e  mov [r15+0xA0], rax
000079f4d2dd0035  mov eax, [rsp+0x30]
000079f4d2dd0039  mov eax, eax
000079f4d2dd003b  mov [r15+0x28], rax
000079f4d2dd003f  mov eax, [rsp+0x20]
000079f4d2dd0043  mov eax, eax
000079f4d2dd0045  mov [r15+0x98], rax
000079f4d2dd004c  mov eax, [rsp+0x10]
000079f4d2dd0050  mov eax, eax
000079f4d2dd0052  mov [r15+0x38], rax
000079f4d2dd0056  mov eax, [rsp+0x70]
000079f4d2dd005a  mov r14d, [rsp+0x70]
000079f4d2dd005f  shrd eax, r14d, 0x06
000079f4d2dd0064  mov [rsp+0x70], r14d
000079f4d2dd0069  mov r12d, [rsp+0x80]
000079f4d2dd0071  and r14d, r12d
000079f4d2dd0074  mov r11d, [rsp+0x10]
000079f4d2dd0079  mov r10d, [rsp+0x10]
000079f4d2dd007e  shrd r11d, r10d, 0x02
000079f4d2dd0083  mov [rsp+0x10], r12d
000079f4d2dd0088  mov r12d, r12d
000079f4d2dd008b  mov [r15+0x20], r12
000079f4d2dd008f  mov r12, [r15+0x50]
000079f4d2dd0093  mov r9d, [r13+r12*1]
000079f4d2dd0098  mov r12d, [rsp+0x50]
000079f4d2dd009d  mov r8d, [rsp+0x70]
000079f4d2dd00a2  andn ebp, r8d, r12d
000079f4d2dd00a7  mov edi, [rsp+0x60]
000079f4d2dd00ab  lea esi, [r14d+edi*1]
000079f4d2dd00b0  rorx r14d, r8d, 0x0B
000079f4d2dd00b6  xor eax, r14d
000079f4d2dd00b9  rorx r14d, r10d, 0x0D
000079f4d2dd00bf  xor r11d, r14d
000079f4d2dd00c2  lea edi, [esi+ebp*1]
000079f4d2dd00c6  mov r14, [r15+0x48]
000079f4d2dd00ca  mov ebp, [r13+r14*1]
000079f4d2dd00cf  mov r14d, [rsp+0x30]
000079f4d2dd00d4  mov esi, [rsp+0x20]
000079f4d2dd00d8  and r14d, esi
000079f4d2dd00db  mov [rsp+0x20], r14d
000079f4d2dd00e0  mov r14d, r14d
000079f4d2dd00e3  mov [r15+0xD8], r14
000079f4d2dd00ea  lea r14d, [edi+r9d*1]
000079f4d2dd00ef  mov r9d, [rsp+0x30]
000079f4d2dd00f4  xor r9d, esi
000079f4d2dd00f7  rorx edi, r8d, 0x19
000079f4d2dd00fd  xor eax, edi
000079f4d2dd00ff  and r9d, r10d
000079f4d2dd0102  rorx edi, r10d, 0x16
000079f4d2dd0108  xor r11d, edi
000079f4d2dd010b  mov [rsp+0x30], r11d
000079f4d2dd0110  mov r11d, r11d
000079f4d2dd0113  mov [r15+0xD0], r11
000079f4d2dd011a  lea r11d, [r14d+ebp*1]
000079f4d2dd011f  mov r10d, [rsp+0x20]
000079f4d2dd0124  xor r9d, r10d
000079f4d2dd0127  lea r14d, [r11d+eax*1]
000079f4d2dd012c  mov qword ptr [r15+0x88], 0x04
000079f4d2dd0137  mov eax, [rsp+0x30]
000079f4d2dd013b  lea r11d, [r9d+eax*1]
000079f4d2dd0140  mov eax, [rsp+0x40]
000079f4d2dd0144  lea r10d, [r14d+eax*1]
000079f4d2dd0149  mov r10d, r10d
000079f4d2dd014c  mov [r15+0xB8], r10
000079f4d2dd0153  xor eax, eax
000079f4d2dd0155  mov r10d, 0x04
000079f4d2dd015b  mov r9d, 0x100
000079f4d2dd0161  cmp r10, r9
000079f4d2dd0164  cmc
000079f4d2dd0165  lahf
000079f4d2dd0166  seto al
000079f4d2dd0169  mov [r15+0x108], eax
000079f4d2dd0170  lea eax, [r11d+r14d*1]
000079f4d2dd0175  mov eax, eax
000079f4d2dd0177  mov [r15+0xA8], rax
000079f4d2dd017e  mov r12d, r12d
000079f4d2dd0181  mov [r15+0xB0], r12
000079f4d2dd0188  mov eax, [rsp+0x10]
000079f4d2dd018c  mov eax, eax
000079f4d2dd018e  mov [r15+0xC0], rax
000079f4d2dd0195  mov r8d, r8d
000079f4d2dd0198  mov [r15+0xC8], r8
000079f4d2dd019f  mov eax, [r15+0x108]
000079f4d2dd01a6  sahf
000079f4d2dd01a7  jnz 0x000079F4D2DD01D9
000079f4d2dd01a9  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd01b1  jz 0x000079F4D2DD04A0
000079f4d2dd01b7  nop [rax+rax*1], ax
000079f4d2dd01c0  nop [rax+rax*1], eax
000079f4d2dd01c8  mov eax, 0x41094C
000079f4d2dd01cd  mov [r15+0x100], rax
000079f4d2dd01d4  jmp 0x000079F4D2BFE110
000079f4d2dd01d9  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd01e1  jz 0x000079F4D2DD0270
000079f4d2dd01e7  nop [rax+rax*1], ax
000079f4d2dd01f0  nop [rax+rax*1], eax
000079f4d2dd01f8  mov eax, 0x4108C0
000079f4d2dd01fd  mov [r15+0x100], rax
000079f4d2dd0204  jmp 0x000079F4D2BFE110
000079f4d2dd0209  int3
000079f4d2dd020a  call 0x000079F4D2C0DAE0
000079f4d2dd020f  jmp 0x000079F4D2DCFF78
000079f4d2dd0214  call 0x000079F4D2CC0230
000079f4d2dd0219  jmp 0x000079F4D2DCFF81
000079f4d2dd021e  call 0x000079F4D2CE26A0
000079f4d2dd0223  jmp 0x000079F4D2DCFFA5
000079f4d2dd0228  call 0x000079F4D2CE1430
000079f4d2dd022d  jmp 0x000079F4D2DCFFAE
000079f4d2dd0232  call 0x000079F4D2CE26A0
000079f4d2dd0237  jmp 0x000079F4D2DCFFCF
000079f4d2dd023c  call 0x000079F4D2CE1430
000079f4d2dd0241  jmp 0x000079F4D2DCFFD8
000079f4d2dd0246  call 0x000079F4D2CE26A0
000079f4d2dd024b  jmp 0x000079F4D2DCFFF9
000079f4d2dd0250  call 0x000079F4D2CD5890
000079f4d2dd0255  jmp 0x000079F4D2DD0002
000079f4d2dd025a  call 0x000079F4D2CBDD50
000079f4d2dd025f  jmp 0x000079F4D2DD0098
000079f4d2dd0264  call 0x000079F4D2CDA580
000079f4d2dd0269  jmp 0x000079F4D2DD00CF
000079f4d2dd026e  int3
000079f4d2dd026f  nop
000079f4d2dd0270  mov eax, [r15+0xB8]
000079f4d2dd0277  mov [rsp+0x10], eax
000079f4d2dd027b  mov eax, eax
000079f4d2dd027d  mov [r15+0x30], rax
000079f4d2dd0281  mov eax, [r15+0xC0]
000079f4d2dd0288  mov [rsp+0x20], eax
000079f4d2dd028c  mov eax, eax
000079f4d2dd028e  mov [r15+0xA0], rax
000079f4d2dd0295  mov eax, [r15+0x28]
000079f4d2dd0299  mov r14d, [r15+0x98]
000079f4d2dd02a0  mov [rsp+0x30], r14d
000079f4d2dd02a5  mov r14d, r14d
000079f4d2dd02a8  mov [r15+0x28], r14
000079f4d2dd02ac  mov r14d, [r15+0x38]
000079f4d2dd02b0  mov [rsp+0x40], r14d
000079f4d2dd02b5  mov r14d, r14d
000079f4d2dd02b8  mov [r15+0x98], r14
000079f4d2dd02bf  mov r14d, [r15+0xA8]
000079f4d2dd02c6  mov [rsp+0x50], r14d
000079f4d2dd02cb  mov r14d, r14d
000079f4d2dd02ce  mov [r15+0x38], r14
000079f4d2dd02d2  mov r14d, [rsp+0x10]
000079f4d2dd02d7  mov r12d, [rsp+0x10]
000079f4d2dd02dc  shrd r14d, r12d, 0x06
000079f4d2dd02e1  mov r11d, [r15+0xC8]
000079f4d2dd02e8  mov [rsp+0x10], r12d
000079f4d2dd02ed  and r12d, r11d
000079f4d2dd02f0  mov r10d, [rsp+0x50]
000079f4d2dd02f5  mov r9d, [rsp+0x50]
000079f4d2dd02fa  shrd r10d, r9d, 0x02
000079f4d2dd02ff  mov [rsp+0x50], r11d
000079f4d2dd0304  mov r11d, r11d
000079f4d2dd0307  mov [r15+0x20], r11
000079f4d2dd030b  mov r11, [r15+0x88]
000079f4d2dd0312  mov r8, [r15+0x50]
000079f4d2dd0316  lea rbp, [r8+r11*1]
000079f4d2dd031a  mov r8d, [r13+rbp*1]
000079f4d2dd031f  mov ebp, [rsp+0x20]
000079f4d2dd0323  mov edi, [rsp+0x10]
000079f4d2dd0327  andn esi, edi, ebp
000079f4d2dd032c  mov edx, [r15+0xB0]
000079f4d2dd0333  lea ecx, [r12d+edx*1]
000079f4d2dd0338  rorx r12d, edi, 0x0B
000079f4d2dd033e  xor r14d, r12d
000079f4d2dd0341  rorx r12d, r9d, 0x0D
000079f4d2dd0347  xor r10d, r12d
000079f4d2dd034a  lea r12d, [ecx+esi*1]
000079f4d2dd034f  mov rsi, [r15+0x48]
000079f4d2dd0353  lea rdx, [rsi+r11*1]
000079f4d2dd0357  mov esi, [r13+rdx*1]
000079f4d2dd035c  mov edx, [rsp+0x30]
000079f4d2dd0360  mov ecx, [rsp+0x40]
000079f4d2dd0364  and edx, ecx
000079f4d2dd0366  mov [rsp+0x10], edx
000079f4d2dd036a  mov edx, edx
000079f4d2dd036c  mov [r15+0xD8], rdx
000079f4d2dd0373  lea edx, [r12d+r8d*1]
000079f4d2dd0378  mov r12d, [rsp+0x30]
000079f4d2dd037d  xor r12d, ecx
000079f4d2dd0380  rorx r8d, edi, 0x19
000079f4d2dd0386  xor r14d, r8d
000079f4d2dd0389  and r12d, r9d
000079f4d2dd038c  rorx r8d, r9d, 0x16
000079f4d2dd0392  xor r10d, r8d
000079f4d2dd0395  mov [rsp+0x20], r10d
000079f4d2dd039a  mov r10d, r10d
000079f4d2dd039d  mov [r15+0xD0], r10
000079f4d2dd03a4  lea r10d, [edx+esi*1]
000079f4d2dd03a9  mov r9d, [rsp+0x10]
000079f4d2dd03ae  xor r12d, r9d
000079f4d2dd03b1  lea r9d, [r10d+r14d*1]
000079f4d2dd03b6  lea r14, [r11+0x04]
000079f4d2dd03ba  mov [r15+0x88], r14
000079f4d2dd03c1  mov r11d, [rsp+0x20]
000079f4d2dd03c6  lea r10d, [r12d+r11d*1]
000079f4d2dd03cb  lea r11d, [r9d+eax*1]
000079f4d2dd03d0  mov r11d, r11d
000079f4d2dd03d3  mov [r15+0xB8], r11
000079f4d2dd03da  xor eax, eax
000079f4d2dd03dc  mov r12d, 0x100
000079f4d2dd03e2  cmp r14, r12
000079f4d2dd03e5  cmc
000079f4d2dd03e6  lahf
000079f4d2dd03e7  seto al
000079f4d2dd03ea  mov [r15+0x108], eax
000079f4d2dd03f1  lea eax, [r10d+r9d*1]
000079f4d2dd03f6  mov eax, eax
000079f4d2dd03f8  mov [r15+0xA8], rax
000079f4d2dd03ff  mov ebp, ebp
000079f4d2dd0401  mov [r15+0xB0], rbp
000079f4d2dd0408  mov eax, [rsp+0x50]
000079f4d2dd040c  mov eax, eax
000079f4d2dd040e  mov [r15+0xC0], rax
000079f4d2dd0415  mov edi, edi
000079f4d2dd0417  mov [r15+0xC8], rdi
000079f4d2dd041e  mov eax, [r15+0x108]
000079f4d2dd0425  sahf
000079f4d2dd0426  jnz 0x000079F4D2DD0458
000079f4d2dd0428  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0430  jz 0x000079F4D2DD04A0
000079f4d2dd0436  nop [rax+rax*1], ax
000079f4d2dd043f  nop [rax+rax*1], eax
000079f4d2dd0447  mov eax, 0x41094C
000079f4d2dd044c  mov [r15+0x100], rax
000079f4d2dd0453  jmp 0x000079F4D2BFE110
000079f4d2dd0458  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0460  jz 0x000079F4D2DD0270
000079f4d2dd0466  nop [rax+rax*1], ax
000079f4d2dd046f  nop [rax+rax*1], eax
000079f4d2dd0477  mov eax, 0x4108C0
000079f4d2dd047c  mov [r15+0x100], rax
000079f4d2dd0483  jmp 0x000079F4D2BFE110
000079f4d2dd0488  int3
000079f4d2dd0489  call 0x000079F4D2C49010
000079f4d2dd048e  jmp 0x000079F4D2DD031F
000079f4d2dd0493  call 0x000079F4D2C25930
000079f4d2dd0498  jmp 0x000079F4D2DD035C
000079f4d2dd049d  int3
000079f4d2dd049e  nop
000079f4d2dd04a0  mov eax, [r15+0x98]
000079f4d2dd04a7  mov r14d, [r15+0x70]
000079f4d2dd04ab  lea r12d, [eax+r14d*1]
000079f4d2dd04b0  mov eax, [r15+0x28]
000079f4d2dd04b4  mov r14d, [r15+0x68]
000079f4d2dd04b8  lea r11d, [eax+r14d*1]
000079f4d2dd04bd  mov qword ptr [r15+0x88], 0x00
000079f4d2dd04c8  mov eax, [r15+0xA8]
000079f4d2dd04cf  mov r14d, [r15+0x78]
000079f4d2dd04d3  lea r10d, [eax+r14d*1]
000079f4d2dd04d8  mov [rsp+0x10], r10d
000079f4d2dd04dd  mov r10d, r10d
000079f4d2dd04e0  mov [r15+0x78], r10
000079f4d2dd04e4  mov eax, [r15+0x38]
000079f4d2dd04e8  mov r14d, [r15+0x80]
000079f4d2dd04ef  lea r10d, [eax+r14d*1]
000079f4d2dd04f4  mov [rsp+0x20], r10d
000079f4d2dd04f9  mov r10d, r10d
000079f4d2dd04fc  mov [r15+0x80], r10
000079f4d2dd0503  mov rax, [r15]
000079f4d2dd0506  lea r14, [rax+0x08]
000079f4d2dd050a  mov [r13+r14*1], r12d
000079f4d2dd050f  lea r14, [rax+0x0C]
000079f4d2dd0513  mov [r13+r14*1], r11d
000079f4d2dd0518  mov r14d, [r15+0xB8]
000079f4d2dd051f  mov r12d, [r15+0x18]
000079f4d2dd0523  lea r11d, [r14d+r12d*1]
000079f4d2dd0528  mov [rsp+0x30], r11d
000079f4d2dd052d  mov r11d, r11d
000079f4d2dd0530  mov [r15+0x68], r11
000079f4d2dd0534  mov r14d, [r15+0x30]
000079f4d2dd0538  mov r12d, [r15+0x90]
000079f4d2dd053f  lea r11d, [r14d+r12d*1]
000079f4d2dd0544  mov [rsp+0x40], r11d
000079f4d2dd0549  mov r11d, r11d
000079f4d2dd054c  mov [r15+0x70], r11
000079f4d2dd0550  mov r14d, [r15+0x20]
000079f4d2dd0554  mov r12d, [r15+0x58]
000079f4d2dd0558  lea r11d, [r14d+r12d*1]
000079f4d2dd055d  mov [rsp+0x50], r11d
000079f4d2dd0562  mov r11d, r11d
000079f4d2dd0565  mov [r15+0x58], r11
000079f4d2dd0569  mov r14d, [r15+0xA0]
000079f4d2dd0570  mov r12d, [r15+0x60]
000079f4d2dd0574  lea r11d, [r14d+r12d*1]
000079f4d2dd0579  mov [rsp+0x60], r11d
000079f4d2dd057e  mov r11d, r11d
000079f4d2dd0581  mov [r15+0x60], r11
000079f4d2dd0585  mov r14d, [rsp+0x10]
000079f4d2dd058a  mov [r13+rax*1], r14d
000079f4d2dd058f  lea r14, [rax+0x04]
000079f4d2dd0593  mov r12d, [rsp+0x20]
000079f4d2dd0598  mov [r13+r14*1], r12d
000079f4d2dd059d  lea r14, [rax+0x10]
000079f4d2dd05a1  mov r12d, [rsp+0x30]
000079f4d2dd05a6  mov [r13+r14*1], r12d
000079f4d2dd05ab  lea r14, [rax+0x14]
000079f4d2dd05af  mov r12d, [rsp+0x40]
000079f4d2dd05b4  mov [r13+r14*1], r12d
000079f4d2dd05b9  lea r14, [rax+0x18]
000079f4d2dd05bd  mov r12d, [rsp+0x50]
000079f4d2dd05c2  mov [r13+r14*1], r12d
000079f4d2dd05c7  lea r14, [rax+0x1C]
000079f4d2dd05cb  mov r12d, [rsp+0x60]
000079f4d2dd05d0  mov [r13+r14*1], r12d
000079f4d2dd05d5  lea r14, [rax+0x68]
000079f4d2dd05d9  xor eax, eax
000079f4d2dd05db  mov [r13+r14*1], rax
000079f4d2dd05e0  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd05e8  jz 0x000079F4D2DCF0E0
000079f4d2dd05ee  nop [rax+rax*1], ax
000079f4d2dd05f7  nop [rax+rax*1], eax
000079f4d2dd05ff  mov eax, 0x410768
000079f4d2dd0604  mov [r15+0x100], rax
000079f4d2dd060b  jmp 0x000079F4D2BFE110
000079f4d2dd0610  int3
000079f4d2dd0611  call 0x000079F4D2CE2BA0
000079f4d2dd0616  jmp 0x000079F4D2DD050F
000079f4d2dd061b  call 0x000079F4D2CE1920
000079f4d2dd0620  jmp 0x000079F4D2DD0518
000079f4d2dd0625  call 0x000079F4D2C0DFE0
000079f4d2dd062a  jmp 0x000079F4D2DD058F
000079f4d2dd062f  call 0x000079F4D2CE2BA0
000079f4d2dd0634  jmp 0x000079F4D2DD059D
000079f4d2dd0639  call 0x000079F4D2CE2BA0
000079f4d2dd063e  jmp 0x000079F4D2DD05AB
000079f4d2dd0643  call 0x000079F4D2CE2BA0
000079f4d2dd0648  jmp 0x000079F4D2DD05B9
000079f4d2dd064d  call 0x000079F4D2CE2BA0
000079f4d2dd0652  jmp 0x000079F4D2DD05C7
000079f4d2dd0657  call 0x000079F4D2CE2BA0
000079f4d2dd065c  jmp 0x000079F4D2DD05D5
000079f4d2dd0661  call 0x000079F4D2CD5EB0
000079f4d2dd0666  jmp 0x000079F4D2DD05E0
000079f4d2dd066b  int3
000079f4d2dd066c  nop [rax], eax
000079f4d2dd0670  mov rax, [r15+0xF8]
000079f4d2dd0677  lea r14, [rax+0x140]
000079f4d2dd067e  mov r12, [r13+r14*1]
000079f4d2dd0683  lea r14, [rax+0x148]
000079f4d2dd068a  mov r11, [r13+r14*1]
000079f4d2dd068f  mov [r15+0xA0], r12
000079f4d2dd0696  mov [r15+0x98], r11
000079f4d2dd069d  lea r14, [rax+0x130]
000079f4d2dd06a4  mov r12, [r13+r14*1]
000079f4d2dd06a9  lea r14, [rax+0x138]
000079f4d2dd06b0  mov r11, [r13+r14*1]
000079f4d2dd06b5  mov [r15+0xB0], r12
000079f4d2dd06bc  mov [r15+0xA8], r11
000079f4d2dd06c3  lea r14, [rax+0x120]
000079f4d2dd06ca  mov r12, [r13+r14*1]
000079f4d2dd06cf  lea r14, [rax+0x128]
000079f4d2dd06d6  mov r11, [r13+r14*1]
000079f4d2dd06db  mov [r15+0xC0], r12
000079f4d2dd06e2  mov [r15+0xB8], r11
000079f4d2dd06e9  lea r14, [rax+0x110]
000079f4d2dd06f0  mov r12, [r13+r14*1]
000079f4d2dd06f5  lea r14, [rax+0x118]
000079f4d2dd06fc  mov r11, [r13+r14*1]
000079f4d2dd0701  mov [r15+0xD0], r12
000079f4d2dd0708  mov [r15+0xC8], r11
000079f4d2dd070f  lea r14, [rax+0x100]
000079f4d2dd0716  mov r12, [r13+r14*1]
000079f4d2dd071b  lea r14, [rax+0x108]
000079f4d2dd0722  mov r11, [r13+r14*1]
000079f4d2dd0727  mov [r15+0xE8], r12
000079f4d2dd072e  mov [r15+0xD8], r11
000079f4d2dd0735  lea r14, [rax+0x150]
000079f4d2dd073c  mov [r15+0xF8], r14
000079f4d2dd0743  mov rax, [r15+0xF0]
000079f4d2dd074a  mov [r15+0x100], rax
000079f4d2dd0751  jmp 0x000079F4D2DCE5C0
000079f4d2dd0756  int3
000079f4d2dd0757  call 0x000079F4D2CE27E0
000079f4d2dd075c  jmp 0x000079F4D2DD0683
000079f4d2dd0761  call 0x000079F4D2CE1570
000079f4d2dd0766  jmp 0x000079F4D2DD068F
000079f4d2dd076b  call 0x000079F4D2CE27E0
000079f4d2dd0770  jmp 0x000079F4D2DD06A9
000079f4d2dd0775  call 0x000079F4D2CE1570
000079f4d2dd077a  jmp 0x000079F4D2DD06B5
000079f4d2dd077f  call 0x000079F4D2CE27E0
000079f4d2dd0784  jmp 0x000079F4D2DD06CF
000079f4d2dd0789  call 0x000079F4D2CE1570
000079f4d2dd078e  jmp 0x000079F4D2DD06DB
000079f4d2dd0793  call 0x000079F4D2CE27E0
000079f4d2dd0798  jmp 0x000079F4D2DD06F5
000079f4d2dd079d  call 0x000079F4D2CE1570
000079f4d2dd07a2  jmp 0x000079F4D2DD0701
000079f4d2dd07a7  call 0x000079F4D2CE27E0
000079f4d2dd07ac  jmp 0x000079F4D2DD071B
000079f4d2dd07b1  call 0x000079F4D2CE1570
000079f4d2dd07b6  jmp 0x000079F4D2DD0727
000079f4d2dd07bb  int3
000079f4d2dd07bc  nop [rax], eax
000079f4d2dd07c0  mov eax, [r15+0xA0]
000079f4d2dd07c7  mov [rsp+0x10], eax
000079f4d2dd07cb  xor eax, eax
000079f4d2dd07cd  mov r14d, [rsp+0x10]
000079f4d2dd07d2  sub r14d, 0x01
000079f4d2dd07d6  cmc
000079f4d2dd07d7  lahf
000079f4d2dd07d8  seto al
000079f4d2dd07db  mov [r15+0x108], eax
000079f4d2dd07e2  mov r14d, r14d
000079f4d2dd07e5  mov [r15+0xA0], r14
000079f4d2dd07ec  mov eax, [r15+0x108]
000079f4d2dd07f3  sahf
000079f4d2dd07f4  jnz 0x000079F4D2DD0826
000079f4d2dd07f6  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd07fe  jz 0x000079F4D2DD0900
000079f4d2dd0804  nop [rax+rax*1], ax
000079f4d2dd080d  nop [rax+rax*1], eax
000079f4d2dd0815  mov eax, 0x41028C
000079f4d2dd081a  mov [r15+0x100], rax
000079f4d2dd0821  jmp 0x000079F4D2BFE110
000079f4d2dd0826  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd082e  jz 0x000079F4D2DD0860
000079f4d2dd0834  nop [rax+rax*1], ax
000079f4d2dd083d  nop [rax+rax*1], eax
000079f4d2dd0845  mov eax, 0x410274
000079f4d2dd084a  mov [r15+0x100], rax
000079f4d2dd0851  jmp 0x000079F4D2BFE110
000079f4d2dd0856  int3
000079f4d2dd0857  int3
000079f4d2dd0858  nop [rax+rax*1], eax
000079f4d2dd0860  mov rax, [r15+0xF8]
000079f4d2dd0867  lea r14, [rax+0x100]
000079f4d2dd086e  mov [r15], r14
000079f4d2dd0871  mov rax, [r15+0x98]
000079f4d2dd0878  mov [r15+0x08], rax
000079f4d2dd087c  mov qword ptr [r15+0x10], 0x12C
000079f4d2dd0884  mov qword ptr [r15+0xF0], 0x410284
000079f4d2dd088f  mov r14d, [r15+0x320]
000079f4d2dd0896  mov eax, 0x410284
000079f4d2dd089b  mov rcx, 0x79F4D2DD07C0
000079f4d2dd08a5  mov [r15+r14*8+0x328], rax
000079f4d2dd08ad  mov [r15+r14*8+0x368], rcx
000079f4d2dd08b5  add r14d, 0x01
000079f4d2dd08b9  and r14d, 0x07
000079f4d2dd08bd  mov [r15+0x320], r14d
000079f4d2dd08c4  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd08cc  jz 0x000079F4D2DCED70
000079f4d2dd08d2  nop [rax+rax*1], ax
000079f4d2dd08db  nop [rax+rax*1], eax
000079f4d2dd08e3  mov eax, 0x410728
000079f4d2dd08e8  mov [r15+0x100], rax
000079f4d2dd08ef  jmp 0x000079F4D2BFE110
000079f4d2dd08f4  int3
000079f4d2dd08f5  int3
000079f4d2dd08f6  nop [rax+rax*1], ax
000079f4d2dd08ff  nop
000079f4d2dd0900  mov rax, [r15+0xF8]
000079f4d2dd0907  lea r14, [rax+0x120]
000079f4d2dd090e  mov r12, [r13+r14*1]
000079f4d2dd0913  mov [r15+0x98], r12
000079f4d2dd091a  mov qword ptr [r15+0x40], 0x80
000079f4d2dd0922  lea r14, [rax+0x100]
000079f4d2dd0929  mov [r15], r14
000079f4d2dd092c  lea r14, [rax+0x17C]
000079f4d2dd0933  mov [r15+0x08], r14
000079f4d2dd0937  mov qword ptr [r15+0x10], 0x01
000079f4d2dd093f  lea r14, [rax+0x17C]
000079f4d2dd0946  mov eax, 0x80
000079f4d2dd094b  mov [r13+r14*1], al
000079f4d2dd0950  mov qword ptr [r15+0xF0], 0x4102A8
000079f4d2dd095b  mov r14d, [r15+0x320]
000079f4d2dd0962  mov eax, 0x4102A8
000079f4d2dd0967  mov rcx, 0x79F4D2DD09E0
000079f4d2dd0971  mov [r15+r14*8+0x328], rax
000079f4d2dd0979  mov [r15+r14*8+0x368], rcx
000079f4d2dd0981  add r14d, 0x01
000079f4d2dd0985  and r14d, 0x07
000079f4d2dd0989  mov [r15+0x320], r14d
000079f4d2dd0990  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0998  jz 0x000079F4D2DCED70
000079f4d2dd099e  nop [rax+rax*1], ax
000079f4d2dd09a7  nop [rax+rax*1], eax
000079f4d2dd09af  mov eax, 0x410728
000079f4d2dd09b4  mov [r15+0x100], rax
000079f4d2dd09bb  jmp 0x000079F4D2BFE110
000079f4d2dd09c0  int3
000079f4d2dd09c1  call 0x000079F4D2CE27E0
000079f4d2dd09c6  jmp 0x000079F4D2DD0913
000079f4d2dd09cb  call 0x000079F4D2CD5AF0
000079f4d2dd09d0  jmp 0x000079F4D2DD0950
000079f4d2dd09d5  int3
000079f4d2dd09d6  nop [rax+rax*1], ax
000079f4d2dd09df  nop
000079f4d2dd09e0  mov rax, [r15+0xF8]
000079f4d2dd09e7  lea r14, [rax+0x168]
000079f4d2dd09ee  mov r12, [r13+r14*1]
000079f4d2dd09f3  mov [r15+0x40], r12
000079f4d2dd09f7  lea r14, [rax+0x178]
000079f4d2dd09fe  xor eax, eax
000079f4d2dd0a00  mov [r13+r14*1], al
000079f4d2dd0a05  xor eax, eax
000079f4d2dd0a07  mov r14d, 0x38
000079f4d2dd0a0d  cmp r12, r14
000079f4d2dd0a10  cmc
000079f4d2dd0a11  lahf
000079f4d2dd0a12  seto al
000079f4d2dd0a15  mov [r15+0x108], eax
000079f4d2dd0a1c  mov eax, [r15+0x108]
000079f4d2dd0a23  sahf
000079f4d2dd0a24  jz 0x000079F4D2DD0A56
000079f4d2dd0a26  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0a2e  jz 0x000079F4D2DD0AA0
000079f4d2dd0a34  nop [rax+rax*1], ax
000079f4d2dd0a3d  nop [rax+rax*1], eax
000079f4d2dd0a45  mov eax, 0x4102B8
000079f4d2dd0a4a  mov [r15+0x100], rax
000079f4d2dd0a51  jmp 0x000079F4D2BFE110
000079f4d2dd0a56  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0a5e  jz 0x000079F4D2DD0BF0
000079f4d2dd0a64  nop [rax+rax*1], ax
000079f4d2dd0a6d  nop [rax+rax*1], eax
000079f4d2dd0a75  mov eax, 0x4102D4
000079f4d2dd0a7a  mov [r15+0x100], rax
000079f4d2dd0a81  jmp 0x000079F4D2BFE110
000079f4d2dd0a86  int3
000079f4d2dd0a87  call 0x000079F4D2CE27E0
000079f4d2dd0a8c  jmp 0x000079F4D2DD09F3
000079f4d2dd0a91  call 0x000079F4D2CD5AF0
000079f4d2dd0a96  jmp 0x000079F4D2DD0A05
000079f4d2dd0a9b  int3
000079f4d2dd0a9c  nop [rax], eax
000079f4d2dd0aa0  mov rax, [r15+0xF8]
000079f4d2dd0aa7  lea r14, [rax+0x100]
000079f4d2dd0aae  mov [r15], r14
000079f4d2dd0ab1  lea r14, [rax+0x178]
000079f4d2dd0ab8  mov [r15+0x08], r14
000079f4d2dd0abc  mov qword ptr [r15+0x10], 0x01
000079f4d2dd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000079f4d2dd0acf  mov r14d, [r15+0x320]
000079f4d2dd0ad6  mov eax, 0x4102C8
000079f4d2dd0adb  mov rcx, 0x79F4D2DD0B40
000079f4d2dd0ae5  mov [r15+r14*8+0x328], rax
000079f4d2dd0aed  mov [r15+r14*8+0x368], rcx
000079f4d2dd0af5  add r14d, 0x01
000079f4d2dd0af9  and r14d, 0x07
000079f4d2dd0afd  mov [r15+0x320], r14d
000079f4d2dd0b04  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0b0c  jz 0x000079F4D2DCED70
000079f4d2dd0b12  nop [rax+rax*1], ax
000079f4d2dd0b1b  nop [rax+rax*1], eax
000079f4d2dd0b23  mov eax, 0x410728
000079f4d2dd0b28  mov [r15+0x100], rax
000079f4d2dd0b2f  jmp 0x000079F4D2BFE110
000079f4d2dd0b34  int3
000079f4d2dd0b35  int3
000079f4d2dd0b36  nop [rax+rax*1], ax
000079f4d2dd0b3f  nop
000079f4d2dd0b40  mov rax, [r15+0xF8]
000079f4d2dd0b47  lea r14, [rax+0x168]
000079f4d2dd0b4e  mov rax, [r13+r14*1]
000079f4d2dd0b53  mov [r15+0x40], rax
000079f4d2dd0b57  mov [rsp+0x10], rax
000079f4d2dd0b5c  xor eax, eax
000079f4d2dd0b5e  mov r14, [rsp+0x10]
000079f4d2dd0b63  mov r12d, 0x38
000079f4d2dd0b69  cmp r14, r12
000079f4d2dd0b6c  cmc
000079f4d2dd0b6d  lahf
000079f4d2dd0b6e  seto al
000079f4d2dd0b71  mov [r15+0x108], eax
000079f4d2dd0b78  mov eax, [r15+0x108]
000079f4d2dd0b7f  sahf
000079f4d2dd0b80  jnz 0x000079F4D2DD0BB2
000079f4d2dd0b82  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0b8a  jz 0x000079F4D2DD0BF0
000079f4d2dd0b90  nop [rax+rax*1], ax
000079f4d2dd0b99  nop [rax+rax*1], eax
000079f4d2dd0ba1  mov eax, 0x4102D4
000079f4d2dd0ba6  mov [r15+0x100], rax
000079f4d2dd0bad  jmp 0x000079F4D2BFE110
000079f4d2dd0bb2  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0bba  jz 0x000079F4D2DD0AA0
000079f4d2dd0bc0  nop [rax+rax*1], ax
000079f4d2dd0bc9  nop [rax+rax*1], eax
000079f4d2dd0bd1  mov eax, 0x4102B8
000079f4d2dd0bd6  mov [r15+0x100], rax
000079f4d2dd0bdd  jmp 0x000079F4D2BFE110
000079f4d2dd0be2  int3
000079f4d2dd0be3  call 0x000079F4D2CD59C0
000079f4d2dd0be8  jmp 0x000079F4D2DD0B53
000079f4d2dd0bed  int3
000079f4d2dd0bee  nop
000079f4d2dd0bf0  mov rax, [r15+0x98]
000079f4d2dd0bf7  rorx r14, rax, 0x3D
000079f4d2dd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000079f4d2dd0c01  mov rax, [r15+0xF8]
000079f4d2dd0c08  lea r12, [rax+0x100]
000079f4d2dd0c0f  mov [r15], r12
000079f4d2dd0c12  lea r12, [rax+0x170]
000079f4d2dd0c19  mov [r15+0x08], r12
000079f4d2dd0c1d  mov qword ptr [r15+0x10], 0x08
000079f4d2dd0c25  bswap r14
000079f4d2dd0c28  mov [r15+0x40], r14
000079f4d2dd0c2c  lea r12, [rax+0x170]
000079f4d2dd0c33  mov [r13+r12*1], r14
000079f4d2dd0c38  mov qword ptr [r15+0xF0], 0x4102F0
000079f4d2dd0c43  mov r14d, [r15+0x320]
000079f4d2dd0c4a  mov eax, 0x4102F0
000079f4d2dd0c4f  mov rcx, 0x79F4D2DD0CC0
000079f4d2dd0c59  mov [r15+r14*8+0x328], rax
000079f4d2dd0c61  mov [r15+r14*8+0x368], rcx
000079f4d2dd0c69  add r14d, 0x01
000079f4d2dd0c6d  and r14d, 0x07
000079f4d2dd0c71  mov [r15+0x320], r14d
000079f4d2dd0c78  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0c80  jz 0x000079F4D2DCED70
000079f4d2dd0c86  nop [rax+rax*1], ax
000079f4d2dd0c8f  nop [rax+rax*1], eax
000079f4d2dd0c97  mov eax, 0x410728
000079f4d2dd0c9c  mov [r15+0x100], rax
000079f4d2dd0ca3  jmp 0x000079F4D2BFE110
000079f4d2dd0ca8  int3
000079f4d2dd0ca9  call 0x000079F4D2CC3FE0
000079f4d2dd0cae  jmp 0x000079F4D2DD0C38
000079f4d2dd0cb3  int3
000079f4d2dd0cb4  nop [rax+rax*1], ax
000079f4d2dd0cbd  nop [rax], eax
000079f4d2dd0cc0  mov rax, [r15+0xF8]
000079f4d2dd0cc7  lea r14, [rax+0x100]
000079f4d2dd0cce  mov r12d, [r13+r14*1]
000079f4d2dd0cd3  lea r14, [rax+0x104]
000079f4d2dd0cda  mov r11d, [r13+r14*1]
000079f4d2dd0cdf  mov qword ptr [r15+0x48], 0x430C90
000079f4d2dd0ce7  lea r14, [rax+0x108]
000079f4d2dd0cee  mov r10d, [r13+r14*1]
000079f4d2dd0cf3  lea r14, [rax+0x10C]
000079f4d2dd0cfa  mov r9d, [r13+r14*1]
000079f4d2dd0cff  bswap r12d
000079f4d2dd0d02  bswap r11d
000079f4d2dd0d05  mov qword ptr [r15+0xA0], 0x00
000079f4d2dd0d10  mov r14d, 0x430C90
000079f4d2dd0d16  mov [r13+r14*1], r12d
000079f4d2dd0d1b  mov r14d, 0x430C94
000079f4d2dd0d21  mov [r13+r14*1], r11d
000079f4d2dd0d26  bswap r10d
000079f4d2dd0d29  lea r14, [rax+0x110]
000079f4d2dd0d30  mov r12d, [r13+r14*1]
000079f4d2dd0d35  bswap r9d
000079f4d2dd0d38  lea r14, [rax+0x114]
000079f4d2dd0d3f  mov r11d, [r13+r14*1]
000079f4d2dd0d44  mov qword ptr [r15+0x98], 0x430DFC
000079f4d2dd0d4f  mov r14d, 0x430C98
000079f4d2dd0d55  mov [r13+r14*1], r10d
000079f4d2dd0d5a  mov r14d, 0x430C9C
000079f4d2dd0d60  mov [r13+r14*1], r9d
000079f4d2dd0d65  bswap r12d
000079f4d2dd0d68  lea r14, [rax+0x118]
000079f4d2dd0d6f  mov r10d, [r13+r14*1]
000079f4d2dd0d74  bswap r11d
000079f4d2dd0d77  mov [rsp+0x10], r11d
000079f4d2dd0d7c  mov r11d, r11d
000079f4d2dd0d7f  mov [r15+0x58], r11
000079f4d2dd0d83  lea r14, [rax+0x11C]
000079f4d2dd0d8a  mov eax, [r13+r14*1]
000079f4d2dd0d8f  mov [rsp+0x20], eax
000079f4d2dd0d93  mov eax, eax
000079f4d2dd0d95  mov [r15+0x60], rax
000079f4d2dd0d99  mov eax, 0x430CA0
000079f4d2dd0d9e  mov [r13+rax*1], r12d
000079f4d2dd0da3  mov eax, 0x430CA4
000079f4d2dd0da8  mov r14d, [rsp+0x10]
000079f4d2dd0dad  mov [r13+rax*1], r14d
000079f4d2dd0db2  bswap r10d
000079f4d2dd0db5  mov [rsp+0x10], r10d
000079f4d2dd0dba  mov r10d, r10d
000079f4d2dd0dbd  mov [r15+0x40], r10
000079f4d2dd0dc1  mov eax, [rsp+0x20]
000079f4d2dd0dc5  bswap eax
000079f4d2dd0dc7  mov [rsp+0x20], eax
000079f4d2dd0dcb  mov eax, eax
000079f4d2dd0dcd  mov [r15+0x50], rax
000079f4d2dd0dd1  mov eax, 0x430CA8
000079f4d2dd0dd6  mov r14d, [rsp+0x10]
000079f4d2dd0ddb  mov [r13+rax*1], r14d
000079f4d2dd0de0  mov eax, 0x430CAC
000079f4d2dd0de5  mov r14d, [rsp+0x20]
000079f4d2dd0dea  mov [r13+rax*1], r14d
000079f4d2dd0def  mov eax, [r15+0xA0]
000079f4d2dd0df6  lea r14d, [eax+0x11]
000079f4d2dd0dfb  mov r14d, r14d
000079f4d2dd0dfe  mov [r15], r14
000079f4d2dd0e01  mov qword ptr [r15+0xF0], 0x41035C
000079f4d2dd0e0c  mov r14d, [r15+0x320]
000079f4d2dd0e13  mov eax, 0x41035C
000079f4d2dd0e18  mov rcx, 0x79F4D2DD0F90
000079f4d2dd0e22  mov [r15+r14*8+0x328], rax
000079f4d2dd0e2a  mov [r15+r14*8+0x368], rcx
000079f4d2dd0e32  add r14d, 0x01
000079f4d2dd0e36  and r14d, 0x07
000079f4d2dd0e3a  mov [r15+0x320], r14d
000079f4d2dd0e41  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0e49  jz 0x000079F4D2DD0F20
000079f4d2dd0e4f  nop [rax+rax*1], ax
000079f4d2dd0e58  nop [rax+rax*1], eax
000079f4d2dd0e60  mov eax, 0x4109A4
000079f4d2dd0e65  mov [r15+0x100], rax
000079f4d2dd0e6c  jmp 0x000079F4D2BFE110
000079f4d2dd0e71  int3
000079f4d2dd0e72  call 0x000079F4D2CE26A0
000079f4d2dd0e77  jmp 0x000079F4D2DD0CD3
000079f4d2dd0e7c  call 0x000079F4D2CE1430
000079f4d2dd0e81  jmp 0x000079F4D2DD0CDF
000079f4d2dd0e86  call 0x000079F4D2CE01C0
000079f4d2dd0e8b  jmp 0x000079F4D2DD0CF3
000079f4d2dd0e90  call 0x000079F4D2CDEF50
000079f4d2dd0e95  jmp 0x000079F4D2DD0CFF
000079f4d2dd0e9a  call 0x000079F4D2CE2BA0
000079f4d2dd0e9f  jmp 0x000079F4D2DD0D1B
000079f4d2dd0ea4  call 0x000079F4D2CE1920
000079f4d2dd0ea9  jmp 0x000079F4D2DD0D26
000079f4d2dd0eae  call 0x000079F4D2CE26A0
000079f4d2dd0eb3  jmp 0x000079F4D2DD0D35
000079f4d2dd0eb8  call 0x000079F4D2CE1430
000079f4d2dd0ebd  jmp 0x000079F4D2DD0D44
000079f4d2dd0ec2  call 0x000079F4D2CE06B0
000079f4d2dd0ec7  jmp 0x000079F4D2DD0D5A
000079f4d2dd0ecc  call 0x000079F4D2CDF440
000079f4d2dd0ed1  jmp 0x000079F4D2DD0D65
000079f4d2dd0ed6  call 0x000079F4D2CE01C0
000079f4d2dd0edb  jmp 0x000079F4D2DD0D74
000079f4d2dd0ee0  call 0x000079F4D2CD5890
000079f4d2dd0ee5  jmp 0x000079F4D2DD0D8F
000079f4d2dd0eea  call 0x000079F4D2C0BAE0
000079f4d2dd0eef  jmp 0x000079F4D2DD0DA3
000079f4d2dd0ef4  call 0x000079F4D2C0DFE0
000079f4d2dd0ef9  jmp 0x000079F4D2DD0DB2
000079f4d2dd0efe  call 0x000079F4D2C0DFE0
000079f4d2dd0f03  jmp 0x000079F4D2DD0DE0
000079f4d2dd0f08  call 0x000079F4D2C0DFE0
000079f4d2dd0f0d  jmp 0x000079F4D2DD0DEF
000079f4d2dd0f12  int3
000079f4d2dd0f13  nop [rax+rax*1], ax
000079f4d2dd0f1c  nop [rax], eax
000079f4d2dd0f20  mov eax, [r15]
000079f4d2dd0f23  mov [rsp+0x10], eax
000079f4d2dd0f27  shr eax, 0x10
000079f4d2dd0f2a  mov r14d, [rsp+0x10]
000079f4d2dd0f2f  xor r14d, eax
000079f4d2dd0f32  imul r14d, r14d, 0x7FEB352D
000079f4d2dd0f39  mov eax, 0x846CA68B
000079f4d2dd0f3e  mov eax, eax
000079f4d2dd0f40  mov [r15+0x48], rax
000079f4d2dd0f44  mov [rsp+0x10], r14d
000079f4d2dd0f49  shr r14d, 0x0F
000079f4d2dd0f4d  mov eax, [rsp+0x10]
000079f4d2dd0f51  xor eax, r14d
000079f4d2dd0f54  imul eax, eax, 0x846CA68B
000079f4d2dd0f5a  mov [rsp+0x10], eax
000079f4d2dd0f5e  mov eax, eax
000079f4d2dd0f60  mov [r15+0x40], rax
000079f4d2dd0f64  mov eax, [rsp+0x10]
000079f4d2dd0f68  shr eax, 0x10
000079f4d2dd0f6b  mov r14d, [rsp+0x10]
000079f4d2dd0f70  xor r14d, eax
000079f4d2dd0f73  mov r14d, r14d
000079f4d2dd0f76  mov [r15], r14
000079f4d2dd0f79  mov rax, [r15+0xF0]
000079f4d2dd0f80  mov [r15+0x100], rax
000079f4d2dd0f87  jmp 0x000079F4D2DCE5C0
000079f4d2dd0f8c  int3
000079f4d2dd0f8d  int3
000079f4d2dd0f8e  nop
000079f4d2dd0f90  mov rax, [r15+0xA0]
000079f4d2dd0f97  mov [rsp+0x10], rax
000079f4d2dd0f9c  shl rax, 0x02
000079f4d2dd0fa0  mov r14, [r15+0x98]
000079f4d2dd0fa7  lea r12, [r14+rax*1]
000079f4d2dd0fab  mov eax, [r15]
000079f4d2dd0fae  mov [r13+r12*1], eax
000079f4d2dd0fb3  mov rax, [rsp+0x10]
000079f4d2dd0fb8  lea r14, [rax+0x01]
000079f4d2dd0fbc  mov [r15+0xA0], r14
000079f4d2dd0fc3  xor eax, eax
000079f4d2dd0fc5  mov r12d, 0x400
000079f4d2dd0fcb  cmp r14, r12
000079f4d2dd0fce  cmc
000079f4d2dd0fcf  lahf
000079f4d2dd0fd0  seto al
000079f4d2dd0fd3  mov [r15+0x108], eax
000079f4d2dd0fda  mov eax, [r15+0x108]
000079f4d2dd0fe1  sahf
000079f4d2dd0fe2  jnz 0x000079F4D2DD1014
000079f4d2dd0fe4  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd0fec  jz 0x000079F4D2DD10E0
000079f4d2dd0ff2  nop [rax+rax*1], ax
000079f4d2dd0ffb  nop [rax+rax*1], eax
000079f4d2dd1003  mov eax, 0x41036C
000079f4d2dd1008  mov [r15+0x100], rax
000079f4d2dd100f  jmp 0x000079F4D2BFE110
000079f4d2dd1014  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd101c  jz 0x000079F4D2DD1050
000079f4d2dd1022  nop [rax+rax*1], ax
000079f4d2dd102b  nop [rax+rax*1], eax
000079f4d2dd1033  mov eax, 0x410354
000079f4d2dd1038  mov [r15+0x100], rax
000079f4d2dd103f  jmp 0x000079F4D2BFE110
000079f4d2dd1044  int3
000079f4d2dd1045  call 0x000079F4D2CB4B70
000079f4d2dd104a  jmp 0x000079F4D2DD0FB3
000079f4d2dd104f  int3
000079f4d2dd1050  mov eax, [r15+0xA0]
000079f4d2dd1057  lea r14d, [eax+0x11]
000079f4d2dd105c  mov r14d, r14d
000079f4d2dd105f  mov [r15], r14
000079f4d2dd1062  mov qword ptr [r15+0xF0], 0x41035C
000079f4d2dd106d  mov r14d, [r15+0x320]
000079f4d2dd1074  mov eax, 0x41035C
000079f4d2dd1079  mov rcx, 0x79F4D2DD0F90
000079f4d2dd1083  mov [r15+r14*8+0x328], rax
000079f4d2dd108b  mov [r15+r14*8+0x368], rcx
000079f4d2dd1093  add r14d, 0x01
000079f4d2dd1097  and r14d, 0x07
000079f4d2dd109b  mov [r15+0x320], r14d
000079f4d2dd10a2  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd10aa  jz 0x000079F4D2DD0F20
000079f4d2dd10b0  nop [rax+rax*1], ax
000079f4d2dd10b9  nop [rax+rax*1], eax
000079f4d2dd10c1  mov eax, 0x4109A4
000079f4d2dd10c6  mov [r15+0x100], rax
000079f4d2dd10cd  jmp 0x000079F4D2BFE110
000079f4d2dd10d2  int3
000079f4d2dd10d3  int3
000079f4d2dd10d4  nop [rax+rax*1], ax
000079f4d2dd10dd  nop [rax], eax
000079f4d2dd10e0  mov qword ptr [r15+0x40], 0x01
000079f4d2dd10e8  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd10f0  jz 0x000079F4D2DD1120
000079f4d2dd10f6  nop [rax+rax*1], ax
000079f4d2dd10ff  nop [rax+rax*1], eax
000079f4d2dd1107  mov eax, 0x410388
000079f4d2dd110c  mov [r15+0x100], rax
000079f4d2dd1113  jmp 0x000079F4D2BFE110
000079f4d2dd1118  int3
000079f4d2dd1119  int3
000079f4d2dd111a  nop [rax+rax*1], ax
000079f4d2dd1120  mov rax, [r15+0x40]
000079f4d2dd1124  mov [rsp+0x10], rax
000079f4d2dd1129  shl rax, 0x02
000079f4d2dd112d  mov r14, [r15+0x98]
000079f4d2dd1134  lea r12, [r14+rax*1]
000079f4d2dd1138  mov eax, [r13+r12*1]
000079f4d2dd113d  mov [rsp+0x20], eax
000079f4d2dd1141  mov eax, eax
000079f4d2dd1143  mov [r15+0x48], rax
000079f4d2dd1147  mov rax, [rsp+0x10]
000079f4d2dd114c  mov [r15+0x50], rax
000079f4d2dd1150  mov eax, [r15+0x50]
000079f4d2dd1154  lea r12d, [eax-0x01]
000079f4d2dd1159  mov r12d, r12d
000079f4d2dd115c  mov [r15+0x58], r12
000079f4d2dd1160  mov rax, [r15+0x58]
000079f4d2dd1164  mov r12d, eax
000079f4d2dd1167  mov r12d, r12d
000079f4d2dd116a  shl r12, 0x02
000079f4d2dd116e  lea rax, [r14+r12*1]
000079f4d2dd1172  mov r14d, [r13+rax*1]
000079f4d2dd1177  mov [rsp+0x10], r14d
000079f4d2dd117c  mov r14d, r14d
000079f4d2dd117f  mov [r15+0x60], r14
000079f4d2dd1183  xor eax, eax
000079f4d2dd1185  mov r14d, [rsp+0x10]
000079f4d2dd118a  mov r12d, [rsp+0x20]
000079f4d2dd118f  cmp r14d, r12d
000079f4d2dd1192  cmc
000079f4d2dd1193  lahf
000079f4d2dd1194  seto al
000079f4d2dd1197  mov [r15+0x108], eax
000079f4d2dd119e  mov eax, [r15+0x108]
000079f4d2dd11a5  sahf
000079f4d2dd11a6  cmc
000079f4d2dd11a7  jbe 0x000079F4D2DD11D9
000079f4d2dd11a9  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd11b1  jz 0x000079F4D2DD1220
000079f4d2dd11b7  nop [rax+rax*1], ax
000079f4d2dd11c0  nop [rax+rax*1], eax
000079f4d2dd11c8  mov eax, 0x4103A0
000079f4d2dd11cd  mov [r15+0x100], rax
000079f4d2dd11d4  jmp 0x000079F4D2BFE110
000079f4d2dd11d9  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd11e1  jz 0x000079F4D2DD14C0
000079f4d2dd11e7  nop [rax+rax*1], ax
000079f4d2dd11f0  nop [rax+rax*1], eax
000079f4d2dd11f8  mov eax, 0x410378
000079f4d2dd11fd  mov [r15+0x100], rax
000079f4d2dd1204  jmp 0x000079F4D2BFE110
000079f4d2dd1209  int3
000079f4d2dd120a  call 0x000079F4D2CB4690
000079f4d2dd120f  jmp 0x000079F4D2DD113D
000079f4d2dd1214  call 0x000079F4D2C0DAE0
000079f4d2dd1219  jmp 0x000079F4D2DD1177
000079f4d2dd121e  int3
000079f4d2dd121f  nop
000079f4d2dd1220  mov rax, [r15+0x50]
000079f4d2dd1224  mov [rsp+0x10], rax
000079f4d2dd1229  shl rax, 0x02
000079f4d2dd122d  mov r14, [r15+0x98]
000079f4d2dd1234  lea r12, [r14+rax*1]
000079f4d2dd1238  mov eax, [r15+0x60]
000079f4d2dd123c  mov [r13+r12*1], eax
000079f4d2dd1241  mov rax, [rsp+0x10]
000079f4d2dd1246  lea r14, [rax-0x01]
000079f4d2dd124a  mov [r15+0x50], r14
000079f4d2dd124e  mov rax, [r15+0x58]
000079f4d2dd1252  test rax, rax
000079f4d2dd1255  setz al
000079f4d2dd1258  movzx rax, al
000079f4d2dd125c  mov [rsp+0x414], al
000079f4d2dd1263  cmp byte ptr [rsp+0x414], 0x00
000079f4d2dd126b  jz 0x000079F4D2DD129D
000079f4d2dd126d  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd1275  jz 0x000079F4D2DD12E0
000079f4d2dd127b  nop [rax+rax*1], ax
000079f4d2dd1284  nop [rax+rax*1], eax
000079f4d2dd128c  mov eax, 0x4103AC
000079f4d2dd1291  mov [r15+0x100], rax
000079f4d2dd1298  jmp 0x000079F4D2BFE110
000079f4d2dd129d  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd12a5  jz 0x000079F4D2DD13E0
000079f4d2dd12ab  nop [rax+rax*1], ax
000079f4d2dd12b4  nop [rax+rax*1], eax
000079f4d2dd12bc  mov eax, 0x410390
000079f4d2dd12c1  mov [r15+0x100], rax
000079f4d2dd12c8  jmp 0x000079F4D2BFE110
000079f4d2dd12cd  int3
000079f4d2dd12ce  call 0x000079F4D2CB4B70
000079f4d2dd12d3  jmp 0x000079F4D2DD1241
000079f4d2dd12d8  int3
000079f4d2dd12d9  nop [rax], eax
000079f4d2dd12e0  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd12e8  jz 0x000079F4D2DD1320
000079f4d2dd12ee  nop [rax+rax*1], ax
000079f4d2dd12f7  nop [rax+rax*1], eax
000079f4d2dd12ff  mov eax, 0x410374
000079f4d2dd1304  mov [r15+0x100], rax
000079f4d2dd130b  jmp 0x000079F4D2BFE110
000079f4d2dd1310  int3
000079f4d2dd1311  int3
000079f4d2dd1312  nop [rax+rax*1], ax
000079f4d2dd131b  nop [rax+rax*1], eax
000079f4d2dd1320  mov qword ptr [r15+0x50], 0x00
000079f4d2dd1328  mov rax, [r15+0x40]
000079f4d2dd132c  lea r14, [rax+0x01]
000079f4d2dd1330  mov [r15+0x40], r14
000079f4d2dd1334  mov rax, [r15+0x98]
000079f4d2dd133b  mov r12d, [r15+0x48]
000079f4d2dd133f  mov [r13+rax*1], r12d
000079f4d2dd1344  xor eax, eax
000079f4d2dd1346  mov r12d, 0x400
000079f4d2dd134c  cmp r14, r12
000079f4d2dd134f  cmc
000079f4d2dd1350  lahf
000079f4d2dd1351  seto al
000079f4d2dd1354  mov [r15+0x108], eax
000079f4d2dd135b  mov eax, [r15+0x108]
000079f4d2dd1362  sahf
000079f4d2dd1363  jz 0x000079F4D2DD1395
000079f4d2dd1365  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd136d  jz 0x000079F4D2DD1120
000079f4d2dd1373  nop [rax+rax*1], ax
000079f4d2dd137c  nop [rax+rax*1], eax
000079f4d2dd1384  mov eax, 0x410388
000079f4d2dd1389  mov [r15+0x100], rax
000079f4d2dd1390  jmp 0x000079F4D2BFE110
000079f4d2dd1395  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd139d  jz 0x000079F4D2DD1580
000079f4d2dd13a3  nop [rax+rax*1], ax
000079f4d2dd13ac  nop [rax+rax*1], eax
000079f4d2dd13b4  mov eax, 0x4103B0
000079f4d2dd13b9  mov [r15+0x100], rax
000079f4d2dd13c0  jmp 0x000079F4D2BFE110
000079f4d2dd13c5  int3
000079f4d2dd13c6  call 0x000079F4D2C0BAE0
000079f4d2dd13cb  jmp 0x000079F4D2DD1344
000079f4d2dd13d0  int3
000079f4d2dd13d1  nop [rax+rax*1], ax
000079f4d2dd13da  nop [rax+rax*1], ax
000079f4d2dd13e0  mov eax, [r15+0x50]
000079f4d2dd13e4  lea r14d, [eax-0x01]
000079f4d2dd13e9  mov r14d, r14d
000079f4d2dd13ec  mov [r15+0x58], r14
000079f4d2dd13f0  mov rax, [r15+0x58]
000079f4d2dd13f4  mov r14d, eax
000079f4d2dd13f7  mov r14d, r14d
000079f4d2dd13fa  shl r14, 0x02
000079f4d2dd13fe  mov rax, [r15+0x98]
000079f4d2dd1405  lea r12, [rax+r14*1]
000079f4d2dd1409  mov eax, [r13+r12*1]
000079f4d2dd140e  mov [rsp+0x10], eax
000079f4d2dd1412  mov eax, eax
000079f4d2dd1414  mov [r15+0x60], rax
000079f4d2dd1418  mov eax, [r15+0x48]
000079f4d2dd141c  mov [rsp+0x20], eax
000079f4d2dd1420  xor eax, eax
000079f4d2dd1422  mov r14d, [rsp+0x10]
000079f4d2dd1427  mov r12d, [rsp+0x20]
000079f4d2dd142c  cmp r14d, r12d
000079f4d2dd142f  cmc
000079f4d2dd1430  lahf
000079f4d2dd1431  seto al
000079f4d2dd1434  mov [r15+0x108], eax
000079f4d2dd143b  mov eax, [r15+0x108]
000079f4d2dd1442  sahf
000079f4d2dd1443  cmc
000079f4d2dd1444  jbe 0x000079F4D2DD1476
000079f4d2dd1446  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd144e  jz 0x000079F4D2DD1220
000079f4d2dd1454  nop [rax+rax*1], ax
000079f4d2dd145d  nop [rax+rax*1], eax
000079f4d2dd1465  mov eax, 0x4103A0
000079f4d2dd146a  mov [r15+0x100], rax
000079f4d2dd1471  jmp 0x000079F4D2BFE110
000079f4d2dd1476  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd147e  jz 0x000079F4D2DD14C0
000079f4d2dd1484  nop [rax+rax*1], ax
000079f4d2dd148d  nop [rax+rax*1], eax
000079f4d2dd1495  mov eax, 0x410378
000079f4d2dd149a  mov [r15+0x100], rax
000079f4d2dd14a1  jmp 0x000079F4D2BFE110
000079f4d2dd14a6  int3
000079f4d2dd14a7  call 0x000079F4D2CB4690
000079f4d2dd14ac  jmp 0x000079F4D2DD140E
000079f4d2dd14b1  int3
000079f4d2dd14b2  nop [rax+rax*1], ax
000079f4d2dd14bb  nop [rax+rax*1], eax
000079f4d2dd14c0  mov rax, [r15+0x40]
000079f4d2dd14c4  lea r14, [rax+0x01]
000079f4d2dd14c8  mov [r15+0x40], r14
000079f4d2dd14cc  mov rax, [r15+0x50]
000079f4d2dd14d0  mov r12d, eax
000079f4d2dd14d3  mov r12d, r12d
000079f4d2dd14d6  shl r12, 0x02
000079f4d2dd14da  mov rax, [r15+0x98]
000079f4d2dd14e1  lea r11, [rax+r12*1]
000079f4d2dd14e5  mov eax, [r15+0x48]
000079f4d2dd14e9  mov [r13+r11*1], eax
000079f4d2dd14ee  xor eax, eax
000079f4d2dd14f0  mov r12d, 0x400
000079f4d2dd14f6  cmp r14, r12
000079f4d2dd14f9  cmc
000079f4d2dd14fa  lahf
000079f4d2dd14fb  seto al
000079f4d2dd14fe  mov [r15+0x108], eax
000079f4d2dd1505  mov eax, [r15+0x108]
000079f4d2dd150c  sahf
000079f4d2dd150d  jz 0x000079F4D2DD153F
000079f4d2dd150f  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd1517  jz 0x000079F4D2DD1120
000079f4d2dd151d  nop [rax+rax*1], ax
000079f4d2dd1526  nop [rax+rax*1], eax
000079f4d2dd152e  mov eax, 0x410388
000079f4d2dd1533  mov [r15+0x100], rax
000079f4d2dd153a  jmp 0x000079F4D2BFE110
000079f4d2dd153f  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd1547  jz 0x000079F4D2DD1580
000079f4d2dd154d  nop [rax+rax*1], ax
000079f4d2dd1556  nop [rax+rax*1], eax
000079f4d2dd155e  mov eax, 0x4103B0
000079f4d2dd1563  mov [r15+0x100], rax
000079f4d2dd156a  jmp 0x000079F4D2BFE110
000079f4d2dd156f  int3
000079f4d2dd1570  call 0x000079F4D2CA4270
000079f4d2dd1575  jmp 0x000079F4D2DD14EE
000079f4d2dd157a  int3
000079f4d2dd157b  nop [rax+rax*1], eax
000079f4d2dd1580  mov qword ptr [r15+0x40], 0x430000
000079f4d2dd1588  mov eax, 0x430CB0
000079f4d2dd158d  mov r14, [r13+rax*1]
000079f4d2dd1592  mov rax, [r15+0x98]
000079f4d2dd1599  mov r12d, [r13+rax*1]
000079f4d2dd159e  lea r11, [rax+0x04]
000079f4d2dd15a2  mov eax, [r13+r11*1]
000079f4d2dd15a7  mov r12d, r12d
000079f4d2dd15aa  mov [r15+0x68], r12
000079f4d2dd15ae  mov eax, eax
000079f4d2dd15b0  mov [r15+0x60], rax
000079f4d2dd15b4  mov rax, [r15+0x68]
000079f4d2dd15b8  mov [r15+0x68], rax
000079f4d2dd15bc  mov qword ptr [r15+0x58], 0x02
000079f4d2dd15c4  mov [rsp+0x10], rax
000079f4d2dd15c9  xor eax, eax
000079f4d2dd15cb  mov r12d, 0x02
000079f4d2dd15d1  mov r11d, 0x400
000079f4d2dd15d7  cmp r12, r11
000079f4d2dd15da  cmc
000079f4d2dd15db  lahf
000079f4d2dd15dc  seto al
000079f4d2dd15df  mov [r15+0x108], eax
000079f4d2dd15e6  mov rax, [r15+0x60]
000079f4d2dd15ea  mov r12d, 0x02
000079f4d2dd15f0  imul rax, r12
000079f4d2dd15f4  mov [r15+0x50], rax
000079f4d2dd15f8  mov rax, [rsp+0x10]
000079f4d2dd15fd  lea r12, [rax+r14*1]
000079f4d2dd1601  mov [r15+0x48], r12
000079f4d2dd1605  mov eax, [r15+0x108]
000079f4d2dd160c  sahf
000079f4d2dd160d  jnz 0x000079F4D2DD163F
000079f4d2dd160f  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd1617  jz 0x000079F4D2DD17B0
000079f4d2dd161d  nop [rax+rax*1], ax
000079f4d2dd1626  nop [rax+rax*1], eax
000079f4d2dd162e  mov eax, 0x4103E0
000079f4d2dd1633  mov [r15+0x100], rax
000079f4d2dd163a  jmp 0x000079F4D2BFE110
000079f4d2dd163f  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd1647  jz 0x000079F4D2DD1690
000079f4d2dd164d  nop [rax+rax*1], ax
000079f4d2dd1656  nop [rax+rax*1], eax
000079f4d2dd165e  mov eax, 0x4103C0
000079f4d2dd1663  mov [r15+0x100], rax
000079f4d2dd166a  jmp 0x000079F4D2BFE110
000079f4d2dd166f  int3
000079f4d2dd1670  call 0x000079F4D2C0DC20
000079f4d2dd1675  jmp 0x000079F4D2DD1592
000079f4d2dd167a  call 0x000079F4D2C0B5E0
000079f4d2dd167f  jmp 0x000079F4D2DD159E
000079f4d2dd1684  call 0x000079F4D2CA3D90
000079f4d2dd1689  jmp 0x000079F4D2DD15A7
000079f4d2dd168e  int3
000079f4d2dd168f  nop
000079f4d2dd1690  mov rax, [r15+0x98]
000079f4d2dd1697  mov r14, [r15+0x58]
000079f4d2dd169b  mov [rsp+0x10], r14
000079f4d2dd16a0  shl r14, 0x02
000079f4d2dd16a4  lea r12, [rax+r14*1]
000079f4d2dd16a8  mov eax, [r13+r12*1]
000079f4d2dd16ad  lea r14, [r12+0x04]
000079f4d2dd16b2  mov r12d, [r13+r14*1]
000079f4d2dd16b7  mov eax, eax
000079f4d2dd16b9  mov [r15+0x68], rax
000079f4d2dd16bd  mov r12d, r12d
000079f4d2dd16c0  mov [r15+0x60], r12
000079f4d2dd16c4  mov rax, [r15+0x68]
000079f4d2dd16c8  mov [rsp+0x20], rax
000079f4d2dd16cd  mov r14, [rsp+0x10]
000079f4d2dd16d2  imul rax, r14
000079f4d2dd16d6  mov r12, [rsp+0x20]
000079f4d2dd16db  lea r11, [r12+rax*1]
000079f4d2dd16df  mov [r15+0x68], r11
000079f4d2dd16e3  lea rax, [r14+0x02]
000079f4d2dd16e7  mov [r15+0x58], rax
000079f4d2dd16eb  mov [rsp+0x10], rax
000079f4d2dd16f0  xor eax, eax
000079f4d2dd16f2  mov r14, [rsp+0x10]
000079f4d2dd16f7  mov r12d, 0x400
000079f4d2dd16fd  cmp r14, r12
000079f4d2dd1700  cmc
000079f4d2dd1701  lahf
000079f4d2dd1702  seto al
000079f4d2dd1705  mov [r15+0x108], eax
000079f4d2dd170c  mov rax, [r15+0x50]
000079f4d2dd1710  mov r12, [r15+0x60]
000079f4d2dd1714  imul r14, r12
000079f4d2dd1718  lea r12, [rax+r14*1]
000079f4d2dd171c  mov [r15+0x50], r12
000079f4d2dd1720  mov rax, [r15+0x48]
000079f4d2dd1724  lea r14, [r11+rax*1]
000079f4d2dd1728  mov [r15+0x48], r14
000079f4d2dd172c  mov eax, [r15+0x108]
000079f4d2dd1733  sahf
000079f4d2dd1734  jnz 0x000079F4D2DD1766
000079f4d2dd1736  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd173e  jz 0x000079F4D2DD17B0
000079f4d2dd1744  nop [rax+rax*1], ax
000079f4d2dd174d  nop [rax+rax*1], eax
000079f4d2dd1755  mov eax, 0x4103E0
000079f4d2dd175a  mov [r15+0x100], rax
000079f4d2dd1761  jmp 0x000079F4D2BFE110
000079f4d2dd1766  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd176e  jz 0x000079F4D2DD1690
000079f4d2dd1774  nop [rax+rax*1], ax
000079f4d2dd177d  nop [rax+rax*1], eax
000079f4d2dd1785  mov eax, 0x4103C0
000079f4d2dd178a  mov [r15+0x100], rax
000079f4d2dd1791  jmp 0x000079F4D2BFE110
000079f4d2dd1796  int3
000079f4d2dd1797  call 0x000079F4D2CB4690
000079f4d2dd179c  jmp 0x000079F4D2DD16AD
000079f4d2dd17a1  call 0x000079F4D2CE26A0
000079f4d2dd17a6  jmp 0x000079F4D2DD16B7
000079f4d2dd17ab  int3
000079f4d2dd17ac  nop [rax], eax
000079f4d2dd17b0  mov qword ptr [r15+0x98], 0x00
000079f4d2dd17bb  mov rax, [r15+0x50]
000079f4d2dd17bf  mov r14, [r15+0x48]
000079f4d2dd17c3  lea r12, [rax+r14*1]
000079f4d2dd17c7  mov [r15+0x48], r12
000079f4d2dd17cb  mov rax, [r15+0x40]
000079f4d2dd17cf  lea r14, [rax+0xCB0]
000079f4d2dd17d6  mov [r13+r14*1], r12
000079f4d2dd17db  mov qword ptr [r15], 0x01
000079f4d2dd17e2  mov qword ptr [r15+0xF0], 0x4103F8
000079f4d2dd17ed  mov r14d, [r15+0x320]
000079f4d2dd17f4  mov eax, 0x4103F8
000079f4d2dd17f9  mov rcx, 0x79F4D2DD1860
000079f4d2dd1803  mov [r15+r14*8+0x328], rax
000079f4d2dd180b  mov [r15+r14*8+0x368], rcx
000079f4d2dd1813  add r14d, 0x01
000079f4d2dd1817  and r14d, 0x07
000079f4d2dd181b  mov [r15+0x320], r14d
000079f4d2dd1822  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd182a  jz 0x000079F4D2DD0F20
000079f4d2dd1830  nop [rax+rax*1], ax
000079f4d2dd1839  nop [rax+rax*1], eax
000079f4d2dd1841  mov eax, 0x4109A4
000079f4d2dd1846  mov [r15+0x100], rax
000079f4d2dd184d  jmp 0x000079F4D2BFE110
000079f4d2dd1852  int3
000079f4d2dd1853  call 0x000079F4D2CE2CE0
000079f4d2dd1858  jmp 0x000079F4D2DD17DB
000079f4d2dd185d  int3
000079f4d2dd185e  nop
000079f4d2dd1860  mov eax, [r15+0x98]
000079f4d2dd1867  lea r14d, [eax+0x01]
000079f4d2dd186c  mov [rsp+0x10], r14d
000079f4d2dd1871  mov r14d, r14d
000079f4d2dd1874  mov [r15+0x98], r14
000079f4d2dd187b  xor eax, eax
000079f4d2dd187d  mov r14d, [rsp+0x10]
000079f4d2dd1882  cmp r14d, 0x10000
000079f4d2dd1889  cmc
000079f4d2dd188a  lahf
000079f4d2dd188b  seto al
000079f4d2dd188e  mov [r15+0x108], eax
000079f4d2dd1895  mov eax, [r15+0x108]
000079f4d2dd189c  sahf
000079f4d2dd189d  jnz 0x000079F4D2DD18CF
000079f4d2dd189f  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd18a7  jz 0x000079F4D2DD19A0
000079f4d2dd18ad  nop [rax+rax*1], ax
000079f4d2dd18b6  nop [rax+rax*1], eax
000079f4d2dd18be  mov eax, 0x410404
000079f4d2dd18c3  mov [r15+0x100], rax
000079f4d2dd18ca  jmp 0x000079F4D2BFE110
000079f4d2dd18cf  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd18d7  jz 0x000079F4D2DD1910
000079f4d2dd18dd  nop [rax+rax*1], ax
000079f4d2dd18e6  nop [rax+rax*1], eax
000079f4d2dd18ee  mov eax, 0x4103F0
000079f4d2dd18f3  mov [r15+0x100], rax
000079f4d2dd18fa  jmp 0x000079F4D2BFE110
000079f4d2dd18ff  int3
000079f4d2dd1900  int3
000079f4d2dd1901  nop [rax+rax*1], ax
000079f4d2dd190a  nop [rax+rax*1], ax
000079f4d2dd1910  mov eax, [r15]
000079f4d2dd1913  mov r14d, [r15+0x98]
000079f4d2dd191a  lea r12d, [eax+r14d*1]
000079f4d2dd191f  mov r12d, r12d
000079f4d2dd1922  mov [r15], r12
000079f4d2dd1925  mov qword ptr [r15+0xF0], 0x4103F8
000079f4d2dd1930  mov r14d, [r15+0x320]
000079f4d2dd1937  mov eax, 0x4103F8
000079f4d2dd193c  mov rcx, 0x79F4D2DD1860
000079f4d2dd1946  mov [r15+r14*8+0x328], rax
000079f4d2dd194e  mov [r15+r14*8+0x368], rcx
000079f4d2dd1956  add r14d, 0x01
000079f4d2dd195a  and r14d, 0x07
000079f4d2dd195e  mov [r15+0x320], r14d
000079f4d2dd1965  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd196d  jz 0x000079F4D2DD0F20
000079f4d2dd1973  nop [rax+rax*1], ax
000079f4d2dd197c  nop [rax+rax*1], eax
000079f4d2dd1984  mov eax, 0x4109A4
000079f4d2dd1989  mov [r15+0x100], rax
000079f4d2dd1990  jmp 0x000079F4D2BFE110
000079f4d2dd1995  int3
000079f4d2dd1996  int3
000079f4d2dd1997  nop [rax+rax*1], ax
000079f4d2dd19a0  vmovaps xmm1, [0x000079F4D29FE010]
000079f4d2dd19a8  movq xmm1, xmm1
000079f4d2dd19ac  movaps [r15+0x110], xmm1
000079f4d2dd19b4  mov eax, 0x420B10
000079f4d2dd19b9  mov r14, [r13+rax*1]
000079f4d2dd19be  movq xmm1, r14
000079f4d2dd19c3  movaps [r15+0x120], xmm1
000079f4d2dd19cb  vmovaps xmm1, [0x000079F4D29FE020]
000079f4d2dd19d3  movq xmm1, xmm1
000079f4d2dd19d7  movaps [r15+0x140], xmm1
000079f4d2dd19df  vmovaps xmm1, [0x000079F4D29FE030]
000079f4d2dd19e7  vpbroadcastq xmm1, xmm1
000079f4d2dd19ec  movaps [r15+0x150], xmm1
000079f4d2dd19f4  mov qword ptr [r15+0x40], 0x02
000079f4d2dd19fc  vmovaps xmm15, [0x000079F4D29FE040]
000079f4d2dd1a04  movq xmm15, xmm15
000079f4d2dd1a09  movaps [r15+0x160], xmm15
000079f4d2dd1a11  vmovaps xmm15, [0x000079F4D29FE050]
000079f4d2dd1a19  vpbroadcastq xmm15, xmm15
000079f4d2dd1a1e  movaps [r15+0x130], xmm15
000079f4d2dd1a26  mov rax, [r15+0x40]
000079f4d2dd1a2a  vmovq xmm14, rax
000079f4d2dd1a2f  vpbroadcastq xmm14, xmm14
000079f4d2dd1a34  movaps [r15+0x170], xmm14
000079f4d2dd1a3c  mov eax, 0x420A40
000079f4d2dd1a41  movups xmm13, [r13+rax*1]
000079f4d2dd1a47  mov qword ptr [r15+0x40], 0x431E00
000079f4d2dd1a4f  mov eax, [r15]
000079f4d2dd1a52  mov r14d, 0x430CB8
000079f4d2dd1a58  mov [r13+r14*1], eax
000079f4d2dd1a5d  mov qword ptr [r15+0x50], 0x432000
000079f4d2dd1a65  vpmovqd xmm12, xmm13
000079f4d2dd1a6b  pxor xmm11, xmm11
000079f4d2dd1a70  punpcklqdq xmm12, xmm11
000079f4d2dd1a75  movaps [r15+0x210], xmm12
000079f4d2dd1a7d  movq xmm12, qword ptr [r15+0x140]
000079f4d2dd1a86  movq xmm11, qword ptr [r15+0x120]
000079f4d2dd1a8f  psubd xmm12, xmm11
000079f4d2dd1a94  movq xmm12, xmm12
000079f4d2dd1a99  paddq xmm13, xmm14
000079f4d2dd1a9e  movaps [r15+0x180], xmm13
000079f4d2dd1aa6  movq xmm14, qword ptr [r15+0x160]
000079f4d2dd1aaf  paddd xmm11, xmm14
000079f4d2dd1ab4  movq xmm11, xmm11
000079f4d2dd1ab9  movq xmm11, xmm11
000079f4d2dd1abe  movaps [r15+0x120], xmm11
000079f4d2dd1ac6  pmovzxdq xmm12, xmm12
000079f4d2dd1acc  psllq xmm12, 0x00
000079f4d2dd1ad2  movq xmm14, qword ptr [r15+0x210]
000079f4d2dd1adb  movq xmm13, qword ptr [r15+0x110]
000079f4d2dd1ae4  paddd xmm14, xmm13
000079f4d2dd1ae9  movq xmm14, xmm14
000079f4d2dd1aee  vcvtuqq2pd xmm12, xmm12
000079f4d2dd1af4  pmovzxdq xmm14, xmm14
000079f4d2dd1afa  psllq xmm14, 0x00
000079f4d2dd1b00  vcvtuqq2pd xmm14, xmm14
000079f4d2dd1b06  movaps xmm13, xmm12
000079f4d2dd1b0a  mulpd xmm13, xmm1
000079f4d2dd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000079f4d2dd1b15  ptest xmm11, xmm11
000079f4d2dd1b1b  jnz 0x000079F4D2DD1C0F
000079f4d2dd1b21  movaps [r15+0x220], xmm13
000079f4d2dd1b29  mov eax, 0x432000
000079f4d2dd1b2e  movups [r13+rax*1], xmm13
000079f4d2dd1b34  movaps xmm1, xmm14
000079f4d2dd1b38  mulpd xmm1, xmm15
000079f4d2dd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000079f4d2dd1b42  ptest xmm13, xmm13
000079f4d2dd1b48  jnz 0x000079F4D2DD1D5C
000079f4d2dd1b4e  movaps [r15+0x210], xmm1
000079f4d2dd1b56  mov eax, 0x431E00
000079f4d2dd1b5b  movups [r13+rax*1], xmm1
000079f4d2dd1b61  mov qword ptr [r15+0x48], 0x10
000079f4d2dd1b69  xor eax, eax
000079f4d2dd1b6b  mov r14d, 0x10
000079f4d2dd1b71  mov r12d, 0x200
000079f4d2dd1b77  cmp r14, r12
000079f4d2dd1b7a  cmc
000079f4d2dd1b7b  lahf
000079f4d2dd1b7c  seto al
000079f4d2dd1b7f  mov [r15+0x108], eax
000079f4d2dd1b86  mov eax, [r15+0x108]
000079f4d2dd1b8d  sahf
000079f4d2dd1b8e  jnz 0x000079F4D2DD1BC0
000079f4d2dd1b90  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd1b98  jz 0x000079F4D2DD2300
000079f4d2dd1b9e  nop [rax+rax*1], ax
000079f4d2dd1ba7  nop [rax+rax*1], eax
000079f4d2dd1baf  mov eax, 0x410490
000079f4d2dd1bb4  mov [r15+0x100], rax
000079f4d2dd1bbb  jmp 0x000079F4D2BFE110
000079f4d2dd1bc0  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd1bc8  jz 0x000079F4D2DD1EB0
000079f4d2dd1bce  nop [rax+rax*1], ax
000079f4d2dd1bd7  nop [rax+rax*1], eax
000079f4d2dd1bdf  mov eax, 0x410450
000079f4d2dd1be4  mov [r15+0x100], rax
000079f4d2dd1beb  jmp 0x000079F4D2BFE110
000079f4d2dd1bf0  int3
000079f4d2dd1bf1  call 0x000079F4D2C0DC20
000079f4d2dd1bf6  jmp 0x000079F4D2DD19BE
000079f4d2dd1bfb  call 0x000079F4D2C0C260
000079f4d2dd1c00  jmp 0x000079F4D2DD1A47
000079f4d2dd1c05  call 0x000079F4D2CD5D70
000079f4d2dd1c0a  jmp 0x000079F4D2DD1A5D
000079f4d2dd1c0f  sub rsp, 0x08
000079f4d2dd1c13  push rax
000079f4d2dd1c14  push rcx
000079f4d2dd1c15  push rdx
000079f4d2dd1c16  push rdi
000079f4d2dd1c17  push rsi
000079f4d2dd1c18  push r8
000079f4d2dd1c1a  push r9
000079f4d2dd1c1c  push r10
000079f4d2dd1c1e  push r11
000079f4d2dd1c20  sub rsp, 0xF0
000079f4d2dd1c27  vmovaps [rsp], xmm0
000079f4d2dd1c2c  vmovaps [rsp+0x10], xmm1
000079f4d2dd1c32  vmovaps [rsp+0x20], xmm2
000079f4d2dd1c38  vmovaps [rsp+0x30], xmm3
000079f4d2dd1c3e  vmovaps [rsp+0x40], xmm4
000079f4d2dd1c44  vmovaps [rsp+0x50], xmm5
000079f4d2dd1c4a  vmovaps [rsp+0x60], xmm6
000079f4d2dd1c50  vmovaps [rsp+0x70], xmm7
000079f4d2dd1c56  vmovaps [rsp+0x80], xmm8
000079f4d2dd1c5f  vmovaps [rsp+0x90], xmm9
000079f4d2dd1c68  vmovaps [rsp+0xA0], xmm10
000079f4d2dd1c71  vmovaps [rsp+0xB0], xmm11
000079f4d2dd1c7a  vmovaps [rsp+0xC0], xmm12
000079f4d2dd1c83  vmovaps [rsp+0xD0], xmm14
000079f4d2dd1c8c  vmovaps [rsp+0xE0], xmm15
000079f4d2dd1c95  sub rsp, 0x30
000079f4d2dd1c99  movaps [rsp], xmm13
000079f4d2dd1c9e  movaps [rsp+0x10], xmm12
000079f4d2dd1ca4  movaps [rsp+0x20], xmm1
000079f4d2dd1ca9  lea rdi, [rsp]
000079f4d2dd1cad  mov esi, 0x00
000079f4d2dd1cb2  mov rax, 0x5D9EC01E8530
000079f4d2dd1cbc  call rax
000079f4d2dd1cbe  movaps xmm13, [rsp]
000079f4d2dd1cc3  add rsp, 0x30
000079f4d2dd1cc7  vmovaps xmm0, [rsp]
000079f4d2dd1ccc  vmovaps xmm1, [rsp+0x10]
000079f4d2dd1cd2  vmovaps xmm2, [rsp+0x20]
000079f4d2dd1cd8  vmovaps xmm3, [rsp+0x30]
000079f4d2dd1cde  vmovaps xmm4, [rsp+0x40]
000079f4d2dd1ce4  vmovaps xmm5, [rsp+0x50]
000079f4d2dd1cea  vmovaps xmm6, [rsp+0x60]
000079f4d2dd1cf0  vmovaps xmm7, [rsp+0x70]
000079f4d2dd1cf6  vmovaps xmm8, [rsp+0x80]
000079f4d2dd1cff  vmovaps xmm9, [rsp+0x90]
000079f4d2dd1d08  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd1d11  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd1d1a  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd1d23  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd1d2c  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd1d35  add rsp, 0xF0
000079f4d2dd1d3c  pop r11
000079f4d2dd1d3e  pop r10
000079f4d2dd1d40  pop r9
000079f4d2dd1d42  pop r8
000079f4d2dd1d44  pop rsi
000079f4d2dd1d45  pop rdi
000079f4d2dd1d46  pop rdx
000079f4d2dd1d47  pop rcx
000079f4d2dd1d48  pop rax
000079f4d2dd1d49  add rsp, 0x08
000079f4d2dd1d4d  jmp 0x000079F4D2DD1B21
000079f4d2dd1d52  call 0x000079F4D2C0C380
000079f4d2dd1d57  jmp 0x000079F4D2DD1B34
000079f4d2dd1d5c  sub rsp, 0x08
000079f4d2dd1d60  push rax
000079f4d2dd1d61  push rcx
000079f4d2dd1d62  push rdx
000079f4d2dd1d63  push rdi
000079f4d2dd1d64  push rsi
000079f4d2dd1d65  push r8
000079f4d2dd1d67  push r9
000079f4d2dd1d69  push r10
000079f4d2dd1d6b  push r11
000079f4d2dd1d6d  sub rsp, 0xF0
000079f4d2dd1d74  vmovaps [rsp], xmm0
000079f4d2dd1d79  vmovaps [rsp+0x10], xmm2
000079f4d2dd1d7f  vmovaps [rsp+0x20], xmm3
000079f4d2dd1d85  vmovaps [rsp+0x30], xmm4
000079f4d2dd1d8b  vmovaps [rsp+0x40], xmm5
000079f4d2dd1d91  vmovaps [rsp+0x50], xmm6
000079f4d2dd1d97  vmovaps [rsp+0x60], xmm7
000079f4d2dd1d9d  vmovaps [rsp+0x70], xmm8
000079f4d2dd1da3  vmovaps [rsp+0x80], xmm9
000079f4d2dd1dac  vmovaps [rsp+0x90], xmm10
000079f4d2dd1db5  vmovaps [rsp+0xA0], xmm11
000079f4d2dd1dbe  vmovaps [rsp+0xB0], xmm12
000079f4d2dd1dc7  vmovaps [rsp+0xC0], xmm13
000079f4d2dd1dd0  vmovaps [rsp+0xD0], xmm14
000079f4d2dd1dd9  vmovaps [rsp+0xE0], xmm15
000079f4d2dd1de2  sub rsp, 0x30
000079f4d2dd1de6  movaps [rsp], xmm1
000079f4d2dd1dea  movaps [rsp+0x10], xmm14
000079f4d2dd1df0  movaps [rsp+0x20], xmm15
000079f4d2dd1df6  lea rdi, [rsp]
000079f4d2dd1dfa  mov esi, 0x00
000079f4d2dd1dff  mov rax, 0x5D9EC01E8530
000079f4d2dd1e09  call rax
000079f4d2dd1e0b  movaps xmm1, [rsp]
000079f4d2dd1e0f  add rsp, 0x30
000079f4d2dd1e13  vmovaps xmm0, [rsp]
000079f4d2dd1e18  vmovaps xmm2, [rsp+0x10]
000079f4d2dd1e1e  vmovaps xmm3, [rsp+0x20]
000079f4d2dd1e24  vmovaps xmm4, [rsp+0x30]
000079f4d2dd1e2a  vmovaps xmm5, [rsp+0x40]
000079f4d2dd1e30  vmovaps xmm6, [rsp+0x50]
000079f4d2dd1e36  vmovaps xmm7, [rsp+0x60]
000079f4d2dd1e3c  vmovaps xmm8, [rsp+0x70]
000079f4d2dd1e42  vmovaps xmm9, [rsp+0x80]
000079f4d2dd1e4b  vmovaps xmm10, [rsp+0x90]
000079f4d2dd1e54  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd1e5d  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd1e66  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd1e6f  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd1e78  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd1e81  add rsp, 0xF0
000079f4d2dd1e88  pop r11
000079f4d2dd1e8a  pop r10
000079f4d2dd1e8c  pop r9
000079f4d2dd1e8e  pop r8
000079f4d2dd1e90  pop rsi
000079f4d2dd1e91  pop rdi
000079f4d2dd1e92  pop rdx
000079f4d2dd1e93  pop rcx
000079f4d2dd1e94  pop rax
000079f4d2dd1e95  add rsp, 0x08
000079f4d2dd1e99  jmp 0x000079F4D2DD1B4E
000079f4d2dd1e9e  call 0x000079F4D2BFF540
000079f4d2dd1ea3  jmp 0x000079F4D2DD1B61
000079f4d2dd1ea8  int3
000079f4d2dd1ea9  nop [rax], eax
000079f4d2dd1eb0  movaps xmm1, [r15+0x180]
000079f4d2dd1eb8  vpmovqd xmm15, xmm1
000079f4d2dd1ebe  pxor xmm14, xmm14
000079f4d2dd1ec3  punpcklqdq xmm15, xmm14
000079f4d2dd1ec8  movaps [r15+0x210], xmm15
000079f4d2dd1ed0  movq xmm15, qword ptr [r15+0x140]
000079f4d2dd1ed9  movq xmm14, qword ptr [r15+0x120]
000079f4d2dd1ee2  psubd xmm15, xmm14
000079f4d2dd1ee7  movq xmm15, xmm15
000079f4d2dd1eec  movaps xmm13, [r15+0x170]
000079f4d2dd1ef4  paddq xmm1, xmm13
000079f4d2dd1ef9  movaps [r15+0x180], xmm1
000079f4d2dd1f01  movq xmm1, qword ptr [r15+0x160]
000079f4d2dd1f0a  paddd xmm14, xmm1
000079f4d2dd1f0f  movq xmm14, xmm14
000079f4d2dd1f14  movq xmm14, xmm14
000079f4d2dd1f19  movaps [r15+0x120], xmm14
000079f4d2dd1f21  pmovzxdq xmm15, xmm15
000079f4d2dd1f27  psllq xmm15, 0x00
000079f4d2dd1f2d  movq xmm1, qword ptr [r15+0x210]
000079f4d2dd1f36  movq xmm14, qword ptr [r15+0x110]
000079f4d2dd1f3f  paddd xmm1, xmm14
000079f4d2dd1f44  movq xmm1, xmm1
000079f4d2dd1f48  vcvtuqq2pd xmm15, xmm15
000079f4d2dd1f4e  pmovzxdq xmm1, xmm1
000079f4d2dd1f53  psllq xmm1, 0x00
000079f4d2dd1f58  vcvtuqq2pd xmm1, xmm1
000079f4d2dd1f5e  movaps xmm14, [r15+0x150]
000079f4d2dd1f66  movaps xmm13, xmm15
000079f4d2dd1f6a  mulpd xmm13, xmm14
000079f4d2dd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000079f4d2dd1f75  ptest xmm12, xmm12
000079f4d2dd1f7b  jnz 0x000079F4D2DD205E
000079f4d2dd1f81  movaps [r15+0x220], xmm13
000079f4d2dd1f89  mov rax, [r15+0x48]
000079f4d2dd1f8d  mov r14, [r15+0x50]
000079f4d2dd1f91  lea r12, [r14+rax*1]
000079f4d2dd1f95  movups [r13+r12*1], xmm13
000079f4d2dd1f9b  movaps xmm15, [r15+0x130]
000079f4d2dd1fa3  movaps xmm14, xmm1
000079f4d2dd1fa7  mulpd xmm14, xmm15
000079f4d2dd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000079f4d2dd1fb2  ptest xmm13, xmm13
000079f4d2dd1fb8  jnz 0x000079F4D2DD21AC
000079f4d2dd1fbe  movaps [r15+0x210], xmm14
000079f4d2dd1fc6  mov r14, [r15+0x40]
000079f4d2dd1fca  lea r12, [r14+rax*1]
000079f4d2dd1fce  movups [r13+r12*1], xmm14
000079f4d2dd1fd4  lea r14, [rax+0x10]
000079f4d2dd1fd8  mov [r15+0x48], r14
000079f4d2dd1fdc  xor eax, eax
000079f4d2dd1fde  mov r12d, 0x200
000079f4d2dd1fe4  cmp r14, r12
000079f4d2dd1fe7  cmc
000079f4d2dd1fe8  lahf
000079f4d2dd1fe9  seto al
000079f4d2dd1fec  mov [r15+0x108], eax
000079f4d2dd1ff3  mov eax, [r15+0x108]
000079f4d2dd1ffa  sahf
000079f4d2dd1ffb  jnz 0x000079F4D2DD202D
000079f4d2dd1ffd  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd2005  jz 0x000079F4D2DD2300
000079f4d2dd200b  nop [rax+rax*1], ax
000079f4d2dd2014  nop [rax+rax*1], eax
000079f4d2dd201c  mov eax, 0x410490
000079f4d2dd2021  mov [r15+0x100], rax
000079f4d2dd2028  jmp 0x000079F4D2BFE110
000079f4d2dd202d  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd2035  jz 0x000079F4D2DD1EB0
000079f4d2dd203b  nop [rax+rax*1], ax
000079f4d2dd2044  nop [rax+rax*1], eax
000079f4d2dd204c  mov eax, 0x410450
000079f4d2dd2051  mov [r15+0x100], rax
000079f4d2dd2058  jmp 0x000079F4D2BFE110
000079f4d2dd205d  int3
000079f4d2dd205e  sub rsp, 0x08
000079f4d2dd2062  push rax
000079f4d2dd2063  push rcx
000079f4d2dd2064  push rdx
000079f4d2dd2065  push rdi
000079f4d2dd2066  push rsi
000079f4d2dd2067  push r8
000079f4d2dd2069  push r9
000079f4d2dd206b  push r10
000079f4d2dd206d  push r11
000079f4d2dd206f  sub rsp, 0xF0
000079f4d2dd2076  vmovaps [rsp], xmm0
000079f4d2dd207b  vmovaps [rsp+0x10], xmm1
000079f4d2dd2081  vmovaps [rsp+0x20], xmm2
000079f4d2dd2087  vmovaps [rsp+0x30], xmm3
000079f4d2dd208d  vmovaps [rsp+0x40], xmm4
000079f4d2dd2093  vmovaps [rsp+0x50], xmm5
000079f4d2dd2099  vmovaps [rsp+0x60], xmm6
000079f4d2dd209f  vmovaps [rsp+0x70], xmm7
000079f4d2dd20a5  vmovaps [rsp+0x80], xmm8
000079f4d2dd20ae  vmovaps [rsp+0x90], xmm9
000079f4d2dd20b7  vmovaps [rsp+0xA0], xmm10
000079f4d2dd20c0  vmovaps [rsp+0xB0], xmm11
000079f4d2dd20c9  vmovaps [rsp+0xC0], xmm12
000079f4d2dd20d2  vmovaps [rsp+0xD0], xmm14
000079f4d2dd20db  vmovaps [rsp+0xE0], xmm15
000079f4d2dd20e4  sub rsp, 0x30
000079f4d2dd20e8  movaps [rsp], xmm13
000079f4d2dd20ed  movaps [rsp+0x10], xmm15
000079f4d2dd20f3  movaps [rsp+0x20], xmm14
000079f4d2dd20f9  lea rdi, [rsp]
000079f4d2dd20fd  mov esi, 0x00
000079f4d2dd2102  mov rax, 0x5D9EC01E8530
000079f4d2dd210c  call rax
000079f4d2dd210e  movaps xmm13, [rsp]
000079f4d2dd2113  add rsp, 0x30
000079f4d2dd2117  vmovaps xmm0, [rsp]
000079f4d2dd211c  vmovaps xmm1, [rsp+0x10]
000079f4d2dd2122  vmovaps xmm2, [rsp+0x20]
000079f4d2dd2128  vmovaps xmm3, [rsp+0x30]
000079f4d2dd212e  vmovaps xmm4, [rsp+0x40]
000079f4d2dd2134  vmovaps xmm5, [rsp+0x50]
000079f4d2dd213a  vmovaps xmm6, [rsp+0x60]
000079f4d2dd2140  vmovaps xmm7, [rsp+0x70]
000079f4d2dd2146  vmovaps xmm8, [rsp+0x80]
000079f4d2dd214f  vmovaps xmm9, [rsp+0x90]
000079f4d2dd2158  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd2161  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd216a  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd2173  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd217c  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd2185  add rsp, 0xF0
000079f4d2dd218c  pop r11
000079f4d2dd218e  pop r10
000079f4d2dd2190  pop r9
000079f4d2dd2192  pop r8
000079f4d2dd2194  pop rsi
000079f4d2dd2195  pop rdi
000079f4d2dd2196  pop rdx
000079f4d2dd2197  pop rcx
000079f4d2dd2198  pop rax
000079f4d2dd2199  add rsp, 0x08
000079f4d2dd219d  jmp 0x000079F4D2DD1F81
000079f4d2dd21a2  call 0x000079F4D2CC2240
000079f4d2dd21a7  jmp 0x000079F4D2DD1F9B
000079f4d2dd21ac  sub rsp, 0x08
000079f4d2dd21b0  push rax
000079f4d2dd21b1  push rcx
000079f4d2dd21b2  push rdx
000079f4d2dd21b3  push rdi
000079f4d2dd21b4  push rsi
000079f4d2dd21b5  push r8
000079f4d2dd21b7  push r9
000079f4d2dd21b9  push r10
000079f4d2dd21bb  push r11
000079f4d2dd21bd  sub rsp, 0xF0
000079f4d2dd21c4  vmovaps [rsp], xmm0
000079f4d2dd21c9  vmovaps [rsp+0x10], xmm1
000079f4d2dd21cf  vmovaps [rsp+0x20], xmm2
000079f4d2dd21d5  vmovaps [rsp+0x30], xmm3
000079f4d2dd21db  vmovaps [rsp+0x40], xmm4
000079f4d2dd21e1  vmovaps [rsp+0x50], xmm5
000079f4d2dd21e7  vmovaps [rsp+0x60], xmm6
000079f4d2dd21ed  vmovaps [rsp+0x70], xmm7
000079f4d2dd21f3  vmovaps [rsp+0x80], xmm8
000079f4d2dd21fc  vmovaps [rsp+0x90], xmm9
000079f4d2dd2205  vmovaps [rsp+0xA0], xmm10
000079f4d2dd220e  vmovaps [rsp+0xB0], xmm11
000079f4d2dd2217  vmovaps [rsp+0xC0], xmm12
000079f4d2dd2220  vmovaps [rsp+0xD0], xmm13
000079f4d2dd2229  vmovaps [rsp+0xE0], xmm15
000079f4d2dd2232  sub rsp, 0x30
000079f4d2dd2236  movaps [rsp], xmm14
000079f4d2dd223b  movaps [rsp+0x10], xmm1
000079f4d2dd2240  movaps [rsp+0x20], xmm15
000079f4d2dd2246  lea rdi, [rsp]
000079f4d2dd224a  mov esi, 0x00
000079f4d2dd224f  mov rax, 0x5D9EC01E8530
000079f4d2dd2259  call rax
000079f4d2dd225b  movaps xmm14, [rsp]
000079f4d2dd2260  add rsp, 0x30
000079f4d2dd2264  vmovaps xmm0, [rsp]
000079f4d2dd2269  vmovaps xmm1, [rsp+0x10]
000079f4d2dd226f  vmovaps xmm2, [rsp+0x20]
000079f4d2dd2275  vmovaps xmm3, [rsp+0x30]
000079f4d2dd227b  vmovaps xmm4, [rsp+0x40]
000079f4d2dd2281  vmovaps xmm5, [rsp+0x50]
000079f4d2dd2287  vmovaps xmm6, [rsp+0x60]
000079f4d2dd228d  vmovaps xmm7, [rsp+0x70]
000079f4d2dd2293  vmovaps xmm8, [rsp+0x80]
000079f4d2dd229c  vmovaps xmm9, [rsp+0x90]
000079f4d2dd22a5  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd22ae  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd22b7  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd22c0  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd22c9  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd22d2  add rsp, 0xF0
000079f4d2dd22d9  pop r11
000079f4d2dd22db  pop r10
000079f4d2dd22dd  pop r9
000079f4d2dd22df  pop r8
000079f4d2dd22e1  pop rsi
000079f4d2dd22e2  pop rdi
000079f4d2dd22e3  pop rdx
000079f4d2dd22e4  pop rcx
000079f4d2dd22e5  pop rax
000079f4d2dd22e6  add rsp, 0x08
000079f4d2dd22ea  jmp 0x000079F4D2DD1FBE
000079f4d2dd22ef  call 0x000079F4D2CC34C0
000079f4d2dd22f4  jmp 0x000079F4D2DD1FD4
000079f4d2dd22f9  int3
000079f4d2dd22fa  nop [rax+rax*1], ax
000079f4d2dd2300  mov rax, [r15+0x50]
000079f4d2dd2304  lea r14, [rax+0x80]
000079f4d2dd230b  movups xmm1, [r13+r14*1]
000079f4d2dd2311  lea r14, [rax+0x90]
000079f4d2dd2318  movups xmm15, [r13+r14*1]
000079f4d2dd231e  vxorps xmm14, xmm14, xmm14
000079f4d2dd2323  vpbroadcastq xmm14, xmm14
000079f4d2dd2328  lea r14, [rax+0x40]
000079f4d2dd232c  movups xmm13, [r13+r14*1]
000079f4d2dd2332  lea r14, [rax+0x50]
000079f4d2dd2336  movups xmm12, [r13+r14*1]
000079f4d2dd233c  mov qword ptr [r15+0x48], 0x00
000079f4d2dd2344  movups xmm11, [r13+rax*1]
000079f4d2dd234a  lea r14, [rax+0x10]
000079f4d2dd234e  movups xmm10, [r13+r14*1]
000079f4d2dd2354  mov r14, [r15+0xF8]
000079f4d2dd235b  lea r12, [r14+0xE0]
000079f4d2dd2362  movups [r13+r12*1], xmm15
000079f4d2dd2368  lea r12, [r14+0xF0]
000079f4d2dd236f  movups [r13+r12*1], xmm1
000079f4d2dd2375  lea r12, [rax+0xC0]
000079f4d2dd237c  movups xmm1, [r13+r12*1]
000079f4d2dd2382  lea r12, [rax+0xD0]
000079f4d2dd2389  movups xmm15, [r13+r12*1]
000079f4d2dd238f  lea r12, [rax+0x140]
000079f4d2dd2396  movups xmm9, [r13+r12*1]
000079f4d2dd239c  lea r12, [rax+0x150]
000079f4d2dd23a3  movups xmm8, [r13+r12*1]
000079f4d2dd23a9  lea r12, [rax+0x180]
000079f4d2dd23b0  movups xmm7, [r13+r12*1]
000079f4d2dd23b6  lea r12, [rax+0x190]
000079f4d2dd23bd  movups xmm6, [r13+r12*1]
000079f4d2dd23c3  lea r12, [r14+0xC0]
000079f4d2dd23ca  movups [r13+r12*1], xmm15
000079f4d2dd23d0  lea r12, [r14+0xD0]
000079f4d2dd23d7  movups [r13+r12*1], xmm1
000079f4d2dd23dd  lea r12, [rax+0x100]
000079f4d2dd23e4  movups xmm1, [r13+r12*1]
000079f4d2dd23ea  lea r12, [rax+0x110]
000079f4d2dd23f1  movups xmm15, [r13+r12*1]
000079f4d2dd23f7  lea r12, [rax+0x1C0]
000079f4d2dd23fe  movups xmm5, [r13+r12*1]
000079f4d2dd2404  lea r12, [rax+0x1D0]
000079f4d2dd240b  movups xmm4, [r13+r12*1]
000079f4d2dd2411  lea r12, [rax+0x20]
000079f4d2dd2415  movups xmm3, [r13+r12*1]
000079f4d2dd241b  lea r12, [rax+0x30]
000079f4d2dd241f  movups xmm2, [r13+r12*1]
000079f4d2dd2425  movaps [r15+0x1F0], xmm2
000079f4d2dd242d  lea r12, [r14+0x20]
000079f4d2dd2431  movups [r13+r12*1], xmm1
000079f4d2dd2437  lea r12, [r14+0x30]
000079f4d2dd243b  movups [r13+r12*1], xmm12
000079f4d2dd2441  lea r12, [rax+0x60]
000079f4d2dd2445  movups xmm1, [r13+r12*1]
000079f4d2dd244b  lea r12, [rax+0x70]
000079f4d2dd244f  movups xmm12, [r13+r12*1]
000079f4d2dd2455  lea r12, [r14+0x60]
000079f4d2dd2459  movups [r13+r12*1], xmm11
000079f4d2dd245f  lea r12, [r14+0x70]
000079f4d2dd2463  movups [r13+r12*1], xmm5
000079f4d2dd2469  lea r12, [rax+0xE0]
000079f4d2dd2470  movups xmm11, [r13+r12*1]
000079f4d2dd2476  lea r12, [rax+0xF0]
000079f4d2dd247d  movups xmm5, [r13+r12*1]
000079f4d2dd2483  lea r12, [rax+0x120]
000079f4d2dd248a  vmovaps [rsp+0x10], xmm1
000079f4d2dd2490  movups xmm1, [r13+r12*1]
000079f4d2dd2496  lea r12, [rax+0x130]
000079f4d2dd249d  vmovaps [rsp+0x20], xmm1
000079f4d2dd24a3  movups xmm1, [r13+r12*1]
000079f4d2dd24a9  lea r12, [r14+0xA0]
000079f4d2dd24b0  movups [r13+r12*1], xmm12
000079f4d2dd24b6  lea r12, [r14+0xB0]
000079f4d2dd24bd  vmovaps xmm12, [rsp+0x10]
000079f4d2dd24c3  movups [r13+r12*1], xmm12
000079f4d2dd24c9  lea r12, [rax+0xA0]
000079f4d2dd24d0  movups xmm12, [r13+r12*1]
000079f4d2dd24d6  lea r12, [rax+0xB0]
000079f4d2dd24dd  vmovaps [rsp+0x10], xmm1
000079f4d2dd24e3  movups xmm1, [r13+r12*1]
000079f4d2dd24e9  lea r12, [rax+0x160]
000079f4d2dd24f0  vmovaps [rsp+0x30], xmm1
000079f4d2dd24f6  movups xmm1, [r13+r12*1]
000079f4d2dd24fc  lea r12, [rax+0x170]
000079f4d2dd2503  vmovaps [rsp+0x40], xmm1
000079f4d2dd2509  movups xmm1, [r13+r12*1]
000079f4d2dd250f  movaps [r15+0x2B0], xmm1
000079f4d2dd2517  lea r12, [rax+0x1A0]
000079f4d2dd251e  vmovaps [rsp+0x50], xmm1
000079f4d2dd2524  movups xmm1, [r13+r12*1]
000079f4d2dd252a  lea r12, [rax+0x1B0]
000079f4d2dd2531  vmovaps [rsp+0x60], xmm1
000079f4d2dd2537  movups xmm1, [r13+r12*1]
000079f4d2dd253d  vmovaps [rsp+0x70], xmm1
000079f4d2dd2543  vmovaps xmm1, [rsp+0x60]
000079f4d2dd2549  movaps [r15+0x290], xmm1
000079f4d2dd2551  vmovaps [rsp+0x60], xmm1
000079f4d2dd2557  vmovaps xmm1, [rsp+0x70]
000079f4d2dd255d  movaps [r15+0x1E0], xmm1
000079f4d2dd2565  lea r12, [r14+0x80]
000079f4d2dd256c  vmovaps [rsp+0x70], xmm1
000079f4d2dd2572  vmovaps xmm1, [rsp+0x30]
000079f4d2dd2578  movups [r13+r12*1], xmm1
000079f4d2dd257e  lea r12, [r14+0x90]
000079f4d2dd2585  movups [r13+r12*1], xmm12
000079f4d2dd258b  lea r12, [rax+0x1E0]
000079f4d2dd2592  movups xmm1, [r13+r12*1]
000079f4d2dd2598  lea r12, [rax+0x1F0]
000079f4d2dd259f  movups xmm12, [r13+r12*1]
000079f4d2dd25a5  mov qword ptr [r15+0x50], 0x432200
000079f4d2dd25ad  lea rax, [r14+0x40]
000079f4d2dd25b1  vmovaps [rsp+0x30], xmm1
000079f4d2dd25b7  vmovaps xmm1, [rsp+0x40]
000079f4d2dd25bd  movups [r13+rax*1], xmm1
000079f4d2dd25c3  lea rax, [r14+0x50]
000079f4d2dd25c7  movups [r13+rax*1], xmm10
000079f4d2dd25cd  movups [r13+r14*1], xmm12
000079f4d2dd25d3  lea rax, [r14+0x10]
000079f4d2dd25d7  vmovaps xmm1, [rsp+0x30]
000079f4d2dd25dd  movups [r13+rax*1], xmm1
000079f4d2dd25e3  mov rax, [r15+0x40]
000079f4d2dd25e7  vmovaps [rsp+0x30], xmm3
000079f4d2dd25ed  vmovaps xmm1, [rsp+0x30]
000079f4d2dd25f3  por xmm3, xmm1
000079f4d2dd25f7  vmovaps [rsp+0x30], xmm6
000079f4d2dd25fd  vmovaps xmm12, [rsp+0x30]
000079f4d2dd2603  por xmm6, xmm12
000079f4d2dd2608  lea r12, [rax+0x30]
000079f4d2dd260c  mov r11, [r13+r12*1]
000079f4d2dd2611  lea r12, [rax+0x38]
000079f4d2dd2615  mov r10, [r13+r12*1]
000079f4d2dd261a  movq xmm12, r11
000079f4d2dd261f  movq xmm10, r10
000079f4d2dd2624  movq xmm12, xmm12
000079f4d2dd2629  vmovaps [rsp+0x30], xmm12
000079f4d2dd262f  movq xmm12, xmm12
000079f4d2dd2634  movaps [r15+0x130], xmm12
000079f4d2dd263c  movq xmm10, xmm10
000079f4d2dd2641  vmovaps [rsp+0x40], xmm10
000079f4d2dd2647  movq xmm10, xmm10
000079f4d2dd264c  movaps [r15+0x280], xmm10
000079f4d2dd2654  vmovaps [rsp+0x80], xmm9
000079f4d2dd265d  vmovaps xmm12, [rsp+0x80]
000079f4d2dd2666  por xmm9, xmm12
000079f4d2dd266b  lea r12, [rax+0x20]
000079f4d2dd266f  mov r11, [r13+r12*1]
000079f4d2dd2674  lea r12, [rax+0x28]
000079f4d2dd2678  mov r10, [r13+r12*1]
000079f4d2dd267d  movq xmm12, r11
000079f4d2dd2682  movq xmm10, r10
000079f4d2dd2687  movq xmm12, xmm12
000079f4d2dd268c  vmovaps [rsp+0x80], xmm12
000079f4d2dd2695  movq xmm12, xmm12
000079f4d2dd269a  movaps [r15+0x150], xmm12
000079f4d2dd26a2  movq xmm10, xmm10
000079f4d2dd26a7  vmovaps [rsp+0x90], xmm10
000079f4d2dd26b0  movq xmm10, xmm10
000079f4d2dd26b5  movaps [r15+0x140], xmm10
000079f4d2dd26bd  lea r12, [rax+0x10]
000079f4d2dd26c1  mov r11, [r13+r12*1]
000079f4d2dd26c6  lea r12, [rax+0x18]
000079f4d2dd26ca  mov r10, [r13+r12*1]
000079f4d2dd26cf  movq xmm12, r11
000079f4d2dd26d4  movq xmm10, r10
000079f4d2dd26d9  movq xmm12, xmm12
000079f4d2dd26de  vmovaps [rsp+0xA0], xmm12
000079f4d2dd26e7  movq xmm12, xmm12
000079f4d2dd26ec  movaps [r15+0x170], xmm12
000079f4d2dd26f4  movq xmm10, xmm10
000079f4d2dd26f9  vmovaps [rsp+0xB0], xmm10
000079f4d2dd2702  movq xmm10, xmm10
000079f4d2dd2707  movaps [r15+0x160], xmm10
000079f4d2dd270f  mov r12, [r13+rax*1]
000079f4d2dd2714  vmovq xmm12, r12
000079f4d2dd2719  vpbroadcastq xmm12, xmm12
000079f4d2dd271e  lea r12, [rax+0x08]
000079f4d2dd2722  mov rax, [r13+r12*1]
000079f4d2dd2727  movq xmm10, rax
000079f4d2dd272c  movaps [r15+0x230], xmm10
000079f4d2dd2734  lea rax, [r14+0x50]
000079f4d2dd2738  movups xmm10, [r13+rax*1]
000079f4d2dd273e  lea rax, [r14+0x60]
000079f4d2dd2742  vmovaps [rsp+0xC0], xmm1
000079f4d2dd274b  movups xmm1, [r13+rax*1]
000079f4d2dd2751  lea rax, [r14+0x30]
000079f4d2dd2755  vmovaps [rsp+0xD0], xmm1
000079f4d2dd275e  movups xmm1, [r13+rax*1]
000079f4d2dd2764  mov qword ptr [r15+0x60], 0x432200
000079f4d2dd276c  mov qword ptr [r15+0x58], 0x40
000079f4d2dd2774  vmovaps [rsp+0xE0], xmm1
000079f4d2dd277d  vmovaps [rsp+0xF0], xmm15
000079f4d2dd2786  vmovaps xmm15, [rsp+0xC0]
000079f4d2dd278f  vmovaps [rsp+0xC0], xmm14
000079f4d2dd2798  movaps xmm1, xmm12
000079f4d2dd279c  mulpd xmm1, xmm15
000079f4d2dd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000079f4d2dd27a6  ptest xmm14, xmm14
000079f4d2dd27ac  jnz 0x000079F4D2DD3863
000079f4d2dd27b2  movq xmm15, qword ptr [r15+0x230]
000079f4d2dd27bb  vmovaps [rsp+0x100], xmm15
000079f4d2dd27c4  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd27ca  vmovaps [rsp+0x110], xmm1
000079f4d2dd27d3  vmovaps xmm1, [rsp+0xE0]
000079f4d2dd27dc  vmovaps [rsp+0xE0], xmm13
000079f4d2dd27e5  movaps xmm14, xmm1
000079f4d2dd27e9  mulpd xmm14, xmm15
000079f4d2dd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000079f4d2dd27f4  ptest xmm13, xmm13
000079f4d2dd27fa  jnz 0x000079F4D2DD39A5
000079f4d2dd2800  vxorps xmm1, xmm1, xmm1
000079f4d2dd2804  vpbroadcastq xmm1, xmm1
000079f4d2dd2809  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd2812  vmovaps [rsp+0xD0], xmm1
000079f4d2dd281b  movaps xmm15, xmm12
000079f4d2dd281f  mulpd xmm15, xmm13
000079f4d2dd2824  vcmppd xmm1, xmm15, xmm15, 0x03
000079f4d2dd282a  ptest xmm1, xmm1
000079f4d2dd282f  jnz 0x000079F4D2DD3AE8
000079f4d2dd2835  movaps xmm1, xmm12
000079f4d2dd2839  mulpd xmm1, xmm10
000079f4d2dd283e  vcmppd xmm13, xmm1, xmm1, 0x03
000079f4d2dd2843  ptest xmm13, xmm13
000079f4d2dd2849  jnz 0x000079F4D2DD3C2C
000079f4d2dd284f  movaps xmm13, xmm12
000079f4d2dd2853  mulpd xmm13, xmm2
000079f4d2dd2858  vcmppd xmm10, xmm13, xmm13, 0x03
000079f4d2dd285e  ptest xmm10, xmm10
000079f4d2dd2864  jnz 0x000079F4D2DD3D6E
000079f4d2dd286a  vmovaps [rsp+0x120], xmm7
000079f4d2dd2873  vmovaps xmm12, [rsp+0x120]
000079f4d2dd287c  por xmm7, xmm12
000079f4d2dd2881  vmovaps xmm12, [rsp+0xE0]
000079f4d2dd288a  vmovaps xmm10, [rsp+0xE0]
000079f4d2dd2893  por xmm12, xmm10
000079f4d2dd2898  vmovaps xmm2, [rsp+0x100]
000079f4d2dd28a1  vpermilpd xmm2, xmm2, 0x00
000079f4d2dd28a7  vmovaps [rsp+0xE0], xmm1
000079f4d2dd28b0  vmovaps [rsp+0x120], xmm15
000079f4d2dd28b9  movaps xmm1, xmm10
000079f4d2dd28bd  mulpd xmm1, xmm2
000079f4d2dd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000079f4d2dd28c6  ptest xmm15, xmm15
000079f4d2dd28cc  jnz 0x000079F4D2DD3EB1
000079f4d2dd28d2  xor eax, eax
000079f4d2dd28d4  mov r12d, 0x40
000079f4d2dd28da  mov r11d, 0x200
000079f4d2dd28e0  cmp r12, r11
000079f4d2dd28e3  cmc
000079f4d2dd28e4  lahf
000079f4d2dd28e5  seto al
000079f4d2dd28e8  mov [r15+0x108], eax
000079f4d2dd28ef  vmovaps xmm10, [rsp+0x110]
000079f4d2dd28f8  vmovaps xmm2, [rsp+0xD0]
000079f4d2dd2901  vmovaps [rsp+0xD0], xmm1
000079f4d2dd290a  movaps xmm15, xmm10
000079f4d2dd290e  addpd xmm15, xmm2
000079f4d2dd2913  vcmppd xmm1, xmm15, xmm15, 0x03
000079f4d2dd2919  ptest xmm1, xmm1
000079f4d2dd291e  jnz 0x000079F4D2DD3FF2
000079f4d2dd2924  vmovaps xmm10, [rsp+0x120]
000079f4d2dd292d  vmovaps [rsp+0x110], xmm15
000079f4d2dd2936  vmovaps xmm15, [rsp+0xC0]
000079f4d2dd293f  vmovaps [rsp+0xC0], xmm14
000079f4d2dd2948  movaps xmm1, xmm10
000079f4d2dd294c  addpd xmm1, xmm15
000079f4d2dd2951  vcmppd xmm14, xmm1, xmm1, 0x03
000079f4d2dd2956  ptest xmm14, xmm14
000079f4d2dd295c  jnz 0x000079F4D2DD4135
000079f4d2dd2962  vmovaps xmm10, [rsp+0xE0]
000079f4d2dd296b  vmovaps [rsp+0xE0], xmm1
000079f4d2dd2974  movaps xmm14, xmm10
000079f4d2dd2978  addpd xmm14, xmm15
000079f4d2dd297d  vcmppd xmm1, xmm14, xmm14, 0x03
000079f4d2dd2983  ptest xmm1, xmm1
000079f4d2dd2988  jnz 0x000079F4D2DD4277
000079f4d2dd298e  vmovaps xmm1, [rsp+0x10]
000079f4d2dd2994  vmovaps xmm15, [rsp+0x10]
000079f4d2dd299a  por xmm1, xmm15
000079f4d2dd299f  vmovaps xmm15, [rsp+0x20]
000079f4d2dd29a5  vmovaps xmm10, [rsp+0x20]
000079f4d2dd29ab  por xmm15, xmm10
000079f4d2dd29b0  vmovaps [rsp+0x10], xmm5
000079f4d2dd29b6  vmovaps xmm10, [rsp+0x10]
000079f4d2dd29bc  por xmm5, xmm10
000079f4d2dd29c1  vmovaps [rsp+0x10], xmm11
000079f4d2dd29c7  vmovaps xmm10, [rsp+0x10]
000079f4d2dd29cd  por xmm11, xmm10
000079f4d2dd29d2  vmovaps [rsp+0x10], xmm4
000079f4d2dd29d8  vmovaps xmm10, [rsp+0x10]
000079f4d2dd29de  por xmm4, xmm10
000079f4d2dd29e3  vmovaps [rsp+0x10], xmm8
000079f4d2dd29e9  vmovaps xmm10, [rsp+0x10]
000079f4d2dd29ef  por xmm8, xmm10
000079f4d2dd29f4  vmovaps xmm10, [rsp+0xF0]
000079f4d2dd29fd  vmovaps [rsp+0x10], xmm1
000079f4d2dd2a03  vmovaps xmm1, [rsp+0xF0]
000079f4d2dd2a0c  por xmm10, xmm1
000079f4d2dd2a11  lea rax, [r14+0xA0]
000079f4d2dd2a18  movups xmm1, [r13+rax*1]
000079f4d2dd2a1e  lea rax, [r14+0xB0]
000079f4d2dd2a25  vmovaps [rsp+0x20], xmm1
000079f4d2dd2a2b  movups xmm1, [r13+rax*1]
000079f4d2dd2a31  vmovaps [rsp+0xF0], xmm1
000079f4d2dd2a3a  vmovaps [rsp+0x120], xmm15
000079f4d2dd2a43  movaps xmm1, xmm13
000079f4d2dd2a47  addpd xmm1, xmm2
000079f4d2dd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000079f4d2dd2a50  ptest xmm15, xmm15
000079f4d2dd2a56  jnz 0x000079F4D2DD43CF
000079f4d2dd2a5c  lea rax, [r14+0xF0]
000079f4d2dd2a63  movups xmm15, [r13+rax*1]
000079f4d2dd2a69  vmovaps xmm2, [rsp+0xE0]
000079f4d2dd2a72  vmovaps [rsp+0xE0], xmm1
000079f4d2dd2a7b  vmovaps xmm1, [rsp+0xD0]
000079f4d2dd2a84  vmovaps [rsp+0xD0], xmm15
000079f4d2dd2a8d  movaps xmm13, xmm2
000079f4d2dd2a91  addpd xmm13, xmm1
000079f4d2dd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000079f4d2dd2a9c  ptest xmm15, xmm15
000079f4d2dd2aa2  jnz 0x000079F4D2DD451A
000079f4d2dd2aa8  vmovaps xmm15, [rsp+0xC0]
000079f4d2dd2ab1  movaps xmm1, xmm14
000079f4d2dd2ab5  addpd xmm1, xmm15
000079f4d2dd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000079f4d2dd2abf  ptest xmm2, xmm2
000079f4d2dd2ac4  jnz 0x000079F4D2DD465C
000079f4d2dd2aca  vmovaps xmm15, [rsp+0x100]
000079f4d2dd2ad3  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd2ad9  vmovaps xmm2, [rsp+0xF0]
000079f4d2dd2ae2  vmovaps [rsp+0xC0], xmm1
000079f4d2dd2aeb  movaps xmm14, xmm2
000079f4d2dd2aef  mulpd xmm14, xmm15
000079f4d2dd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000079f4d2dd2afa  ptest xmm1, xmm1
000079f4d2dd2aff  jnz 0x000079F4D2DD479E
000079f4d2dd2b05  vmovaps xmm1, [rsp+0xA0]
000079f4d2dd2b0e  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd2b14  vmovaps xmm2, [rsp+0xD0]
000079f4d2dd2b1d  vmovaps [rsp+0xD0], xmm14
000079f4d2dd2b26  movaps xmm15, xmm2
000079f4d2dd2b2a  mulpd xmm15, xmm1
000079f4d2dd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000079f4d2dd2b35  ptest xmm14, xmm14
000079f4d2dd2b3b  jnz 0x000079F4D2DD48E1
000079f4d2dd2b41  lea rax, [r14+0xE0]
000079f4d2dd2b48  movups xmm1, [r13+rax*1]
000079f4d2dd2b4e  vmovaps xmm14, [rsp+0x100]
000079f4d2dd2b57  vpermilpd xmm14, xmm14, 0x00
000079f4d2dd2b5d  vmovaps [rsp+0xF0], xmm1
000079f4d2dd2b66  vmovaps xmm1, [rsp+0x20]
000079f4d2dd2b6c  vmovaps [rsp+0x20], xmm15
000079f4d2dd2b72  movaps xmm2, xmm1
000079f4d2dd2b75  mulpd xmm2, xmm14
000079f4d2dd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000079f4d2dd2b7f  ptest xmm15, xmm15
000079f4d2dd2b85  jnz 0x000079F4D2DD4A2D
000079f4d2dd2b8b  vmovaps [rsp+0x100], xmm10
000079f4d2dd2b94  vmovaps xmm1, [rsp+0x100]
000079f4d2dd2b9d  por xmm10, xmm1
000079f4d2dd2ba2  movaps [r15+0x300], xmm10
000079f4d2dd2baa  vmovaps [rsp+0x100], xmm8
000079f4d2dd2bb3  vmovaps xmm1, [rsp+0x100]
000079f4d2dd2bbc  por xmm8, xmm1
000079f4d2dd2bc1  movaps [r15+0x190], xmm8
000079f4d2dd2bc9  vmovaps xmm1, [rsp+0xA0]
000079f4d2dd2bd2  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd2bd8  vmovaps xmm14, [rsp+0xF0]
000079f4d2dd2be1  vmovaps [rsp+0xF0], xmm13
000079f4d2dd2bea  movaps xmm15, xmm14
000079f4d2dd2bee  mulpd xmm15, xmm1
000079f4d2dd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000079f4d2dd2bf9  ptest xmm13, xmm13
000079f4d2dd2bff  jnz 0x000079F4D2DD4B6E
000079f4d2dd2c05  lea rax, [r14+0x90]
000079f4d2dd2c0c  movups xmm1, [r13+rax*1]
000079f4d2dd2c12  vmovaps [rsp+0x100], xmm4
000079f4d2dd2c1b  vmovaps xmm14, [rsp+0x100]
000079f4d2dd2c24  por xmm4, xmm14
000079f4d2dd2c29  movaps [r15+0x1C0], xmm4
000079f4d2dd2c31  vmovaps [rsp+0x100], xmm11
000079f4d2dd2c3a  vmovaps xmm14, [rsp+0x100]
000079f4d2dd2c43  por xmm11, xmm14
000079f4d2dd2c48  movaps [r15+0x200], xmm11
000079f4d2dd2c50  vmovaps [rsp+0x100], xmm5
000079f4d2dd2c59  vmovaps xmm14, [rsp+0x100]
000079f4d2dd2c62  por xmm5, xmm14
000079f4d2dd2c67  movaps [r15+0x2D0], xmm5
000079f4d2dd2c6f  vmovaps xmm14, [rsp+0x120]
000079f4d2dd2c78  vmovaps xmm13, [rsp+0x120]
000079f4d2dd2c81  por xmm14, xmm13
000079f4d2dd2c86  movaps [r15+0x2E0], xmm14
000079f4d2dd2c8e  vmovaps [rsp+0x100], xmm1
000079f4d2dd2c97  vmovaps xmm1, [rsp+0x110]
000079f4d2dd2ca0  vmovaps [rsp+0x110], xmm15
000079f4d2dd2ca9  vmovaps xmm15, [rsp+0xD0]
000079f4d2dd2cb2  vmovaps [rsp+0xD0], xmm14
000079f4d2dd2cbb  movaps xmm13, xmm1
000079f4d2dd2cbf  addpd xmm13, xmm15
000079f4d2dd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000079f4d2dd2cca  ptest xmm14, xmm14
000079f4d2dd2cd0  jnz 0x000079F4D2DD4CBB
000079f4d2dd2cd6  vmovaps xmm1, [rsp+0xA0]
000079f4d2dd2cdf  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd2ce5  vmovaps xmm14, [rsp+0x100]
000079f4d2dd2cee  vmovaps [rsp+0x100], xmm13
000079f4d2dd2cf7  movaps xmm15, xmm14
000079f4d2dd2cfb  mulpd xmm15, xmm1
000079f4d2dd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000079f4d2dd2d06  ptest xmm13, xmm13
000079f4d2dd2d0c  jnz 0x000079F4D2DD4DFE
000079f4d2dd2d12  lea rax, [r14+0x80]
000079f4d2dd2d19  movups xmm1, [r13+rax*1]
000079f4d2dd2d1f  vmovaps xmm13, [rsp+0xE0]
000079f4d2dd2d28  vmovaps [rsp+0xE0], xmm1
000079f4d2dd2d31  movaps xmm14, xmm13
000079f4d2dd2d35  addpd xmm14, xmm2
000079f4d2dd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000079f4d2dd2d40  ptest xmm1, xmm1
000079f4d2dd2d45  jnz 0x000079F4D2DD4F4B
000079f4d2dd2d4b  vmovaps xmm13, [rsp+0xF0]
000079f4d2dd2d54  vmovaps xmm2, [rsp+0x20]
000079f4d2dd2d5a  vmovaps [rsp+0x20], xmm15
000079f4d2dd2d60  movaps xmm1, xmm13
000079f4d2dd2d64  addpd xmm1, xmm2
000079f4d2dd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000079f4d2dd2d6d  ptest xmm15, xmm15
000079f4d2dd2d73  jnz 0x000079F4D2DD508E
000079f4d2dd2d79  vmovaps xmm15, [rsp+0x10]
000079f4d2dd2d7f  vmovaps xmm13, [rsp+0x10]
000079f4d2dd2d85  por xmm15, xmm13
000079f4d2dd2d8a  movaps [r15+0x2F0], xmm15
000079f4d2dd2d92  vmovaps xmm13, [rsp+0xA0]
000079f4d2dd2d9b  vpermilpd xmm13, xmm13, 0x00
000079f4d2dd2da1  vmovaps [rsp+0x10], xmm1
000079f4d2dd2da7  vmovaps xmm1, [rsp+0xE0]
000079f4d2dd2db0  vmovaps [rsp+0xA0], xmm15
000079f4d2dd2db9  movaps xmm2, xmm1
000079f4d2dd2dbc  mulpd xmm2, xmm13
000079f4d2dd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000079f4d2dd2dc6  ptest xmm15, xmm15
000079f4d2dd2dcc  jnz 0x000079F4D2DD51CF
000079f4d2dd2dd2  lea rax, [r14+0xD0]
000079f4d2dd2dd9  movups xmm1, [r13+rax*1]
000079f4d2dd2ddf  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd2de8  vmovaps [rsp+0xC0], xmm1
000079f4d2dd2df1  vmovaps xmm1, [rsp+0x110]
000079f4d2dd2dfa  vmovaps [rsp+0xE0], xmm14
000079f4d2dd2e03  movaps xmm15, xmm13
000079f4d2dd2e07  addpd xmm15, xmm1
000079f4d2dd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000079f4d2dd2e12  ptest xmm14, xmm14
000079f4d2dd2e18  jnz 0x000079F4D2DD531A
000079f4d2dd2e1e  vmovaps xmm1, [rsp+0xB0]
000079f4d2dd2e27  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd2e2d  movaps xmm14, xmm11
000079f4d2dd2e31  mulpd xmm14, xmm1
000079f4d2dd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000079f4d2dd2e3c  ptest xmm13, xmm13
000079f4d2dd2e42  jnz 0x000079F4D2DD545D
000079f4d2dd2e48  movaps [r15+0x260], xmm14
000079f4d2dd2e50  vxorps xmm1, xmm1, xmm1
000079f4d2dd2e54  vpbroadcastq xmm1, xmm1
000079f4d2dd2e59  movaps [r15+0x1B0], xmm1
000079f4d2dd2e61  vmovaps xmm1, [rsp+0xB0]
000079f4d2dd2e6a  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd2e70  vmovaps xmm11, [rsp+0xC0]
000079f4d2dd2e79  vmovaps [rsp+0xC0], xmm15
000079f4d2dd2e82  movaps xmm13, xmm11
000079f4d2dd2e86  mulpd xmm13, xmm1
000079f4d2dd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000079f4d2dd2e91  ptest xmm15, xmm15
000079f4d2dd2e97  jnz 0x000079F4D2DD55A0
000079f4d2dd2e9d  lea rax, [r14+0xC0]
000079f4d2dd2ea4  movups xmm1, [r13+rax*1]
000079f4d2dd2eaa  vmovaps xmm11, [rsp+0x100]
000079f4d2dd2eb3  vmovaps [rsp+0xF0], xmm1
000079f4d2dd2ebc  vmovaps xmm1, [rsp+0x20]
000079f4d2dd2ec2  vmovaps [rsp+0x20], xmm14
000079f4d2dd2ec8  movaps xmm15, xmm11
000079f4d2dd2ecc  addpd xmm15, xmm1
000079f4d2dd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000079f4d2dd2ed7  ptest xmm14, xmm14
000079f4d2dd2edd  jnz 0x000079F4D2DD56ED
000079f4d2dd2ee3  vmovaps [rsp+0x100], xmm9
000079f4d2dd2eec  vmovaps xmm1, [rsp+0x100]
000079f4d2dd2ef5  por xmm9, xmm1
000079f4d2dd2efa  movaps [r15+0x270], xmm9
000079f4d2dd2f02  vmovaps [rsp+0x100], xmm6
000079f4d2dd2f0b  vmovaps xmm1, [rsp+0x100]
000079f4d2dd2f14  por xmm6, xmm1
000079f4d2dd2f18  movaps [r15+0x1A0], xmm6
000079f4d2dd2f20  vmovaps xmm14, [rsp+0xB0]
000079f4d2dd2f29  vpermilpd xmm14, xmm14, 0x00
000079f4d2dd2f2f  vmovaps xmm6, [rsp+0xF0]
000079f4d2dd2f38  vmovaps [rsp+0xF0], xmm1
000079f4d2dd2f41  movaps xmm11, xmm6
000079f4d2dd2f45  mulpd xmm11, xmm14
000079f4d2dd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000079f4d2dd2f50  ptest xmm1, xmm1
000079f4d2dd2f55  jnz 0x000079F4D2DD5830
000079f4d2dd2f5b  lea rax, [r14+0x20]
000079f4d2dd2f5f  movups xmm1, [r13+rax*1]
000079f4d2dd2f65  movaps [r15+0x110], xmm1
000079f4d2dd2f6d  vmovaps xmm6, [rsp+0xE0]
000079f4d2dd2f76  vmovaps [rsp+0xE0], xmm1
000079f4d2dd2f7f  movaps xmm14, xmm6
000079f4d2dd2f83  addpd xmm14, xmm2
000079f4d2dd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000079f4d2dd2f8e  ptest xmm1, xmm1
000079f4d2dd2f93  jnz 0x000079F4D2DD597D
000079f4d2dd2f99  vmovaps xmm1, [rsp+0xB0]
000079f4d2dd2fa2  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd2fa8  movaps xmm6, xmm5
000079f4d2dd2fab  mulpd xmm6, xmm1
000079f4d2dd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000079f4d2dd2fb4  ptest xmm2, xmm2
000079f4d2dd2fb9  jnz 0x000079F4D2DD5ABF
000079f4d2dd2fbf  vmovaps xmm5, [rsp+0x10]
000079f4d2dd2fc5  movaps xmm1, xmm5
000079f4d2dd2fc8  addpd xmm1, xmm13
000079f4d2dd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000079f4d2dd2fd2  ptest xmm2, xmm2
000079f4d2dd2fd7  jnz 0x000079F4D2DD5BFF
000079f4d2dd2fdd  vmovaps xmm13, [rsp+0x80]
000079f4d2dd2fe6  vpermilpd xmm13, xmm13, 0x00
000079f4d2dd2fec  vmovaps xmm2, [rsp+0xE0]
000079f4d2dd2ff5  vmovaps [rsp+0x10], xmm1
000079f4d2dd2ffb  movaps xmm5, xmm2
000079f4d2dd2ffe  mulpd xmm5, xmm13
000079f4d2dd3003  vcmppd xmm1, xmm5, xmm5, 0x03
000079f4d2dd3008  ptest xmm1, xmm1
000079f4d2dd300d  jnz 0x000079F4D2DD5D40
000079f4d2dd3013  vmovaps xmm1, [rsp+0x80]
000079f4d2dd301c  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd3022  movaps xmm13, xmm10
000079f4d2dd3026  mulpd xmm13, xmm1
000079f4d2dd302b  vcmppd xmm2, xmm13, xmm13, 0x03
000079f4d2dd3031  ptest xmm2, xmm2
000079f4d2dd3036  jnz 0x000079F4D2DD5E81
000079f4d2dd303c  vmovaps xmm10, [rsp+0x20]
000079f4d2dd3042  movaps xmm1, xmm15
000079f4d2dd3046  addpd xmm1, xmm10
000079f4d2dd304b  vcmppd xmm2, xmm1, xmm1, 0x03
000079f4d2dd3050  ptest xmm2, xmm2
000079f4d2dd3055  jnz 0x000079F4D2DD5FC4
000079f4d2dd305b  vmovaps xmm10, [rsp+0xC0]
000079f4d2dd3064  movaps xmm15, xmm10
000079f4d2dd3068  addpd xmm15, xmm11
000079f4d2dd306d  vcmppd xmm2, xmm15, xmm15, 0x03
000079f4d2dd3073  ptest xmm2, xmm2
000079f4d2dd3078  jnz 0x000079F4D2DD6106
000079f4d2dd307e  vmovaps xmm11, [rsp+0x80]
000079f4d2dd3087  vpermilpd xmm11, xmm11, 0x00
000079f4d2dd308d  vmovaps xmm2, [rsp+0xD0]
000079f4d2dd3096  vmovaps [rsp+0x20], xmm1
000079f4d2dd309c  movaps xmm10, xmm2
000079f4d2dd30a0  mulpd xmm10, xmm11
000079f4d2dd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000079f4d2dd30ab  ptest xmm1, xmm1
000079f4d2dd30b0  jnz 0x000079F4D2DD624A
000079f4d2dd30b6  vmovaps xmm1, [rsp+0x80]
000079f4d2dd30bf  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd30c5  vmovaps xmm2, [rsp+0xA0]
000079f4d2dd30ce  vmovaps [rsp+0x80], xmm15
000079f4d2dd30d7  movaps xmm11, xmm2
000079f4d2dd30db  mulpd xmm11, xmm1
000079f4d2dd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000079f4d2dd30e6  ptest xmm15, xmm15
000079f4d2dd30ec  jnz 0x000079F4D2DD638D
000079f4d2dd30f2  movaps xmm1, xmm14
000079f4d2dd30f6  addpd xmm1, xmm6
000079f4d2dd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000079f4d2dd30ff  ptest xmm15, xmm15
000079f4d2dd3105  jnz 0x000079F4D2DD64CF
000079f4d2dd310b  vmovaps xmm14, [rsp+0x10]
000079f4d2dd3111  movaps xmm15, xmm14
000079f4d2dd3115  addpd xmm15, xmm5
000079f4d2dd311a  vcmppd xmm6, xmm15, xmm15, 0x03
000079f4d2dd3120  ptest xmm6, xmm6
000079f4d2dd3125  jnz 0x000079F4D2DD6610
000079f4d2dd312b  vmovaps xmm14, [rsp+0x90]
000079f4d2dd3134  vpermilpd xmm14, xmm14, 0x00
000079f4d2dd313a  movaps xmm6, xmm9
000079f4d2dd313e  mulpd xmm6, xmm14
000079f4d2dd3143  vcmppd xmm5, xmm6, xmm6, 0x03
000079f4d2dd3148  ptest xmm5, xmm5
000079f4d2dd314d  jnz 0x000079F4D2DD6753
000079f4d2dd3153  vmovaps xmm9, [rsp+0x80]
000079f4d2dd315c  movaps xmm14, xmm9
000079f4d2dd3160  addpd xmm14, xmm13
000079f4d2dd3165  vcmppd xmm5, xmm14, xmm14, 0x03
000079f4d2dd316b  ptest xmm5, xmm5
000079f4d2dd3170  jnz 0x000079F4D2DD6895
000079f4d2dd3176  vmovaps xmm9, [rsp+0x20]
000079f4d2dd317c  movaps xmm13, xmm9
000079f4d2dd3180  addpd xmm13, xmm10
000079f4d2dd3185  vcmppd xmm5, xmm13, xmm13, 0x03
000079f4d2dd318b  ptest xmm5, xmm5
000079f4d2dd3190  jnz 0x000079F4D2DD69D9
000079f4d2dd3196  vmovaps [rsp+0x10], xmm12
000079f4d2dd319c  vmovaps xmm10, [rsp+0x10]
000079f4d2dd31a2  por xmm12, xmm10
000079f4d2dd31a7  movaps [r15+0x250], xmm12
000079f4d2dd31af  vmovaps [rsp+0x10], xmm7
000079f4d2dd31b5  vmovaps xmm12, [rsp+0x10]
000079f4d2dd31bb  por xmm7, xmm12
000079f4d2dd31c0  movaps [r15+0x2A0], xmm7
000079f4d2dd31c8  vmovaps [rsp+0x10], xmm3
000079f4d2dd31ce  vmovaps xmm12, [rsp+0x10]
000079f4d2dd31d4  por xmm3, xmm12
000079f4d2dd31d9  movaps [r15+0x1D0], xmm3
000079f4d2dd31e1  lea rax, [r14+0x40]
000079f4d2dd31e5  movups xmm12, [r13+rax*1]
000079f4d2dd31eb  movaps [r15+0x2C0], xmm12
000079f4d2dd31f3  vmovaps xmm10, [rsp+0x90]
000079f4d2dd31fc  vpermilpd xmm10, xmm10, 0x00
000079f4d2dd3202  movaps xmm9, xmm8
000079f4d2dd3206  mulpd xmm9, xmm10
000079f4d2dd320b  vcmppd xmm5, xmm9, xmm9, 0x03
000079f4d2dd3211  ptest xmm5, xmm5
000079f4d2dd3216  jnz 0x000079F4D2DD6B27
000079f4d2dd321c  movaps xmm10, xmm1
000079f4d2dd3220  addpd xmm10, xmm11
000079f4d2dd3225  vcmppd xmm8, xmm10, xmm10, 0x03
000079f4d2dd322b  ptest xmm8, xmm8
000079f4d2dd3231  jnz 0x000079F4D2DD6C6B
000079f4d2dd3237  movaps xmm1, xmm15
000079f4d2dd323b  addpd xmm1, xmm6
000079f4d2dd323f  vcmppd xmm11, xmm1, xmm1, 0x03
000079f4d2dd3244  ptest xmm11, xmm11
000079f4d2dd324a  jnz 0x000079F4D2DD6DAE
000079f4d2dd3250  vmovaps xmm15, [rsp+0x90]
000079f4d2dd3259  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd325f  movaps xmm11, xmm12
000079f4d2dd3263  mulpd xmm11, xmm15
000079f4d2dd3268  vcmppd xmm8, xmm11, xmm11, 0x03
000079f4d2dd326e  ptest xmm8, xmm8
000079f4d2dd3274  jnz 0x000079F4D2DD6EEF
000079f4d2dd327a  vmovaps xmm15, [rsp+0x90]
000079f4d2dd3283  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd3289  vmovaps xmm8, [rsp+0x50]
000079f4d2dd328f  movaps xmm12, xmm8
000079f4d2dd3293  mulpd xmm12, xmm15
000079f4d2dd3298  vcmppd xmm6, xmm12, xmm12, 0x03
000079f4d2dd329e  ptest xmm6, xmm6
000079f4d2dd32a3  jnz 0x000079F4D2DD7033
000079f4d2dd32a9  vmovaps xmm15, [rsp+0x30]
000079f4d2dd32af  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd32b5  movaps xmm8, xmm7
000079f4d2dd32b9  mulpd xmm8, xmm15
000079f4d2dd32be  vcmppd xmm6, xmm8, xmm8, 0x03
000079f4d2dd32c4  ptest xmm6, xmm6
000079f4d2dd32c9  jnz 0x000079F4D2DD7177
000079f4d2dd32cf  movaps xmm15, xmm14
000079f4d2dd32d3  addpd xmm15, xmm9
000079f4d2dd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000079f4d2dd32de  ptest xmm7, xmm7
000079f4d2dd32e3  jnz 0x000079F4D2DD72BA
000079f4d2dd32e9  vmovaps xmm14, [rsp+0x30]
000079f4d2dd32ef  vpermilpd xmm14, xmm14, 0x00
000079f4d2dd32f5  vmovaps xmm7, [rsp+0xF0]
000079f4d2dd32fe  movaps xmm9, xmm7
000079f4d2dd3302  mulpd xmm9, xmm14
000079f4d2dd3307  vcmppd xmm6, xmm9, xmm9, 0x03
000079f4d2dd330d  ptest xmm6, xmm6
000079f4d2dd3312  jnz 0x000079F4D2DD73FE
000079f4d2dd3318  movaps xmm14, xmm13
000079f4d2dd331c  addpd xmm14, xmm11
000079f4d2dd3321  vcmppd xmm7, xmm14, xmm14, 0x03
000079f4d2dd3327  ptest xmm7, xmm7
000079f4d2dd332c  jnz 0x000079F4D2DD7541
000079f4d2dd3332  vmovaps xmm13, [rsp+0x30]
000079f4d2dd3338  vpermilpd xmm13, xmm13, 0x00
000079f4d2dd333e  vmovaps xmm7, [rsp+0x60]
000079f4d2dd3344  movaps xmm11, xmm7
000079f4d2dd3348  mulpd xmm11, xmm13
000079f4d2dd334d  vcmppd xmm6, xmm11, xmm11, 0x03
000079f4d2dd3353  ptest xmm6, xmm6
000079f4d2dd3358  jnz 0x000079F4D2DD7685
000079f4d2dd335e  movaps xmm13, xmm10
000079f4d2dd3362  addpd xmm13, xmm12
000079f4d2dd3367  vcmppd xmm7, xmm13, xmm13, 0x03
000079f4d2dd336d  ptest xmm7, xmm7
000079f4d2dd3372  jnz 0x000079F4D2DD77C8
000079f4d2dd3378  vmovaps xmm12, [rsp+0x30]
000079f4d2dd337e  vpermilpd xmm12, xmm12, 0x00
000079f4d2dd3384  vmovaps xmm7, [rsp+0x70]
000079f4d2dd338a  movaps xmm10, xmm7
000079f4d2dd338e  mulpd xmm10, xmm12
000079f4d2dd3393  vcmppd xmm6, xmm10, xmm10, 0x03
000079f4d2dd3399  ptest xmm6, xmm6
000079f4d2dd339e  jnz 0x000079F4D2DD790C
000079f4d2dd33a4  movaps xmm12, xmm1
000079f4d2dd33a8  addpd xmm12, xmm8
000079f4d2dd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000079f4d2dd33b3  ptest xmm7, xmm7
000079f4d2dd33b8  jnz 0x000079F4D2DD7A4F
000079f4d2dd33be  lea rax, [r14+0x70]
000079f4d2dd33c2  movups xmm1, [r13+rax*1]
000079f4d2dd33c8  movaps [r15+0x240], xmm1
000079f4d2dd33d0  movaps xmm8, xmm15
000079f4d2dd33d4  addpd xmm8, xmm9
000079f4d2dd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000079f4d2dd33df  ptest xmm7, xmm7
000079f4d2dd33e4  jnz 0x000079F4D2DD7B9C
000079f4d2dd33ea  movaps [r15+0x170], xmm8
000079f4d2dd33f2  vmovaps xmm15, [rsp+0x40]
000079f4d2dd33f8  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd33fe  movaps xmm9, xmm1
000079f4d2dd3402  mulpd xmm9, xmm15
000079f4d2dd3407  vcmppd xmm7, xmm9, xmm9, 0x03
000079f4d2dd340d  ptest xmm7, xmm7
000079f4d2dd3412  jnz 0x000079F4D2DD7CE0
000079f4d2dd3418  vmovaps xmm1, [rsp+0x40]
000079f4d2dd341e  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd3424  movaps xmm15, xmm4
000079f4d2dd3428  mulpd xmm15, xmm1
000079f4d2dd342d  vcmppd xmm7, xmm15, xmm15, 0x03
000079f4d2dd3433  ptest xmm7, xmm7
000079f4d2dd3438  jnz 0x000079F4D2DD7E23
000079f4d2dd343e  movaps [r15+0x180], xmm15
000079f4d2dd3446  movaps xmm1, xmm14
000079f4d2dd344a  addpd xmm1, xmm11
000079f4d2dd344f  vcmppd xmm7, xmm1, xmm1, 0x03
000079f4d2dd3454  ptest xmm7, xmm7
000079f4d2dd3459  jnz 0x000079F4D2DD7F65
000079f4d2dd345f  movaps [r15+0x210], xmm1
000079f4d2dd3467  movups xmm14, [r13+r14*1]
000079f4d2dd346d  lea rax, [r14+0x10]
000079f4d2dd3471  movups xmm11, [r13+rax*1]
000079f4d2dd3477  movaps [r15+0x230], xmm11
000079f4d2dd347f  movaps xmm7, xmm13
000079f4d2dd3483  addpd xmm7, xmm10
000079f4d2dd3488  vcmppd xmm6, xmm7, xmm7, 0x03
000079f4d2dd348d  ptest xmm6, xmm6
000079f4d2dd3492  jnz 0x000079F4D2DD80BB
000079f4d2dd3498  movaps [r15+0x130], xmm7
000079f4d2dd34a0  vmovaps xmm13, [rsp+0x40]
000079f4d2dd34a6  vpermilpd xmm13, xmm13, 0x00
000079f4d2dd34ac  movaps xmm10, xmm11
000079f4d2dd34b0  mulpd xmm10, xmm13
000079f4d2dd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000079f4d2dd34bb  ptest xmm6, xmm6
000079f4d2dd34c0  jnz 0x000079F4D2DD81FD
000079f4d2dd34c6  movaps [r15+0x220], xmm10
000079f4d2dd34ce  vmovaps xmm13, [rsp+0x40]
000079f4d2dd34d4  vpermilpd xmm13, xmm13, 0x00
000079f4d2dd34da  movaps xmm11, xmm14
000079f4d2dd34de  mulpd xmm11, xmm13
000079f4d2dd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000079f4d2dd34e9  ptest xmm6, xmm6
000079f4d2dd34ee  jnz 0x000079F4D2DD8341
000079f4d2dd34f4  movaps xmm14, xmm12
000079f4d2dd34f8  addpd xmm14, xmm9
000079f4d2dd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000079f4d2dd3503  ptest xmm13, xmm13
000079f4d2dd3509  jnz 0x000079F4D2DD8485
000079f4d2dd350f  movaps [r15+0x140], xmm14
000079f4d2dd3517  movaps xmm13, xmm8
000079f4d2dd351b  addpd xmm13, xmm15
000079f4d2dd3520  vcmppd xmm12, xmm13, xmm13, 0x03
000079f4d2dd3526  ptest xmm12, xmm12
000079f4d2dd352c  jnz 0x000079F4D2DD85C9
000079f4d2dd3532  movaps [r15+0x150], xmm13
000079f4d2dd353a  movaps xmm15, xmm1
000079f4d2dd353e  addpd xmm15, xmm10
000079f4d2dd3543  vcmppd xmm12, xmm15, xmm15, 0x03
000079f4d2dd3549  ptest xmm12, xmm12
000079f4d2dd354f  jnz 0x000079F4D2DD870D
000079f4d2dd3555  movaps [r15+0x160], xmm15
000079f4d2dd355d  movaps xmm1, xmm7
000079f4d2dd3560  addpd xmm1, xmm11
000079f4d2dd3565  vcmppd xmm12, xmm1, xmm1, 0x03
000079f4d2dd356a  ptest xmm12, xmm12
000079f4d2dd3570  jnz 0x000079F4D2DD8850
000079f4d2dd3576  movaps [r15+0x120], xmm1
000079f4d2dd357e  mov eax, 0x432200
000079f4d2dd3583  movups [r13+rax*1], xmm14
000079f4d2dd3589  mov eax, 0x432210
000079f4d2dd358e  movups [r13+rax*1], xmm13
000079f4d2dd3594  mov eax, 0x432220
000079f4d2dd3599  movups [r13+rax*1], xmm15
000079f4d2dd359f  mov eax, 0x432230
000079f4d2dd35a4  movups [r13+rax*1], xmm1
000079f4d2dd35aa  mov eax, [r15+0x108]
000079f4d2dd35b1  sahf
000079f4d2dd35b2  jnz 0x000079F4D2DD35E4
000079f4d2dd35b4  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd35bc  jz 0x000079F4D2DDEAE0
000079f4d2dd35c2  nop [rax+rax*1], ax
000079f4d2dd35cb  nop [rax+rax*1], eax
000079f4d2dd35d3  mov eax, 0x4106D0
000079f4d2dd35d8  mov [r15+0x100], rax
000079f4d2dd35df  jmp 0x000079F4D2BFE110
000079f4d2dd35e4  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd35ec  jz 0x000079F4D2DD89C0
000079f4d2dd35f2  nop [rax+rax*1], ax
000079f4d2dd35fb  nop [rax+rax*1], eax
000079f4d2dd3603  mov eax, 0x410504
000079f4d2dd3608  mov [r15+0x100], rax
000079f4d2dd360f  jmp 0x000079F4D2BFE110
000079f4d2dd3614  int3
000079f4d2dd3615  call 0x000079F4D2CD64F0
000079f4d2dd361a  jmp 0x000079F4D2DD2311
000079f4d2dd361f  call 0x000079F4D2CE5820
000079f4d2dd3624  jmp 0x000079F4D2DD231E
000079f4d2dd3629  call 0x000079F4D2CE3320
000079f4d2dd362e  jmp 0x000079F4D2DD2332
000079f4d2dd3633  call 0x000079F4D2CE20A0
000079f4d2dd3638  jmp 0x000079F4D2DD233C
000079f4d2dd363d  call 0x000079F4D2C09D70
000079f4d2dd3642  jmp 0x000079F4D2DD234A
000079f4d2dd3647  call 0x000079F4D2CDFBC0
000079f4d2dd364c  jmp 0x000079F4D2DD2354
000079f4d2dd3651  call 0x000079F4D2CC4740
000079f4d2dd3656  jmp 0x000079F4D2DD2368
000079f4d2dd365b  call 0x000079F4D2CB5400
000079f4d2dd3660  jmp 0x000079F4D2DD2375
000079f4d2dd3665  call 0x000079F4D2CB52F0
000079f4d2dd366a  jmp 0x000079F4D2DD2382
000079f4d2dd366f  call 0x000079F4D2CC4620
000079f4d2dd3674  jmp 0x000079F4D2DD238F
000079f4d2dd3679  call 0x000079F4D2CBD750
000079f4d2dd367e  jmp 0x000079F4D2DD239C
000079f4d2dd3683  call 0x000079F4D2CBC4E0
000079f4d2dd3688  jmp 0x000079F4D2DD23A9
000079f4d2dd368d  call 0x000079F4D2CBB270
000079f4d2dd3692  jmp 0x000079F4D2DD23B6
000079f4d2dd3697  call 0x000079F4D2CBA000
000079f4d2dd369c  jmp 0x000079F4D2DD23C3
000079f4d2dd36a1  call 0x000079F4D2CC4740
000079f4d2dd36a6  jmp 0x000079F4D2DD23D0
000079f4d2dd36ab  call 0x000079F4D2CB5400
000079f4d2dd36b0  jmp 0x000079F4D2DD23DD
000079f4d2dd36b5  call 0x000079F4D2CB52F0
000079f4d2dd36ba  jmp 0x000079F4D2DD23EA
000079f4d2dd36bf  call 0x000079F4D2CC4620
000079f4d2dd36c4  jmp 0x000079F4D2DD23F7
000079f4d2dd36c9  call 0x000079F4D2CB8D90
000079f4d2dd36ce  jmp 0x000079F4D2DD2404
000079f4d2dd36d3  call 0x000079F4D2CB8A20
000079f4d2dd36d8  jmp 0x000079F4D2DD2411
000079f4d2dd36dd  call 0x000079F4D2CB77B0
000079f4d2dd36e2  jmp 0x000079F4D2DD241B
000079f4d2dd36e7  call 0x000079F4D2CB6550
000079f4d2dd36ec  jmp 0x000079F4D2DD2425
000079f4d2dd36f1  call 0x000079F4D2CB5400
000079f4d2dd36f6  jmp 0x000079F4D2DD2437
000079f4d2dd36fb  call 0x000079F4D2CC0FC0
000079f4d2dd3700  jmp 0x000079F4D2DD2441
000079f4d2dd3705  call 0x000079F4D2CB52F0
000079f4d2dd370a  jmp 0x000079F4D2DD244B
000079f4d2dd370f  call 0x000079F4D2CC0EA0
000079f4d2dd3714  jmp 0x000079F4D2DD2455
000079f4d2dd3719  call 0x000079F4D2CBFD50
000079f4d2dd371e  jmp 0x000079F4D2DD245F
000079f4d2dd3723  call 0x000079F4D2CB8EA0
000079f4d2dd3728  jmp 0x000079F4D2DD2469
000079f4d2dd372d  call 0x000079F4D2CBFC30
000079f4d2dd3732  jmp 0x000079F4D2DD2476
000079f4d2dd3737  call 0x000079F4D2CB8D90
000079f4d2dd373c  jmp 0x000079F4D2DD2483
000079f4d2dd3741  call 0x000079F4D2CB52F0
000079f4d2dd3746  jmp 0x000079F4D2DD2496
000079f4d2dd374b  call 0x000079F4D2CB52F0
000079f4d2dd3750  jmp 0x000079F4D2DD24A9
000079f4d2dd3755  call 0x000079F4D2CC0FC0
000079f4d2dd375a  jmp 0x000079F4D2DD24B6
000079f4d2dd375f  call 0x000079F4D2CC0FC0
000079f4d2dd3764  jmp 0x000079F4D2DD24C9
000079f4d2dd3769  call 0x000079F4D2CC0EA0
000079f4d2dd376e  jmp 0x000079F4D2DD24D6
000079f4d2dd3773  call 0x000079F4D2CB52F0
000079f4d2dd3778  jmp 0x000079F4D2DD24E9
000079f4d2dd377d  call 0x000079F4D2CB52F0
000079f4d2dd3782  jmp 0x000079F4D2DD24FC
000079f4d2dd3787  call 0x000079F4D2CB52F0
000079f4d2dd378c  jmp 0x000079F4D2DD250F
000079f4d2dd3791  call 0x000079F4D2CB52F0
000079f4d2dd3796  jmp 0x000079F4D2DD252A
000079f4d2dd379b  call 0x000079F4D2CB52F0
000079f4d2dd37a0  jmp 0x000079F4D2DD253D
000079f4d2dd37a5  call 0x000079F4D2CB5400
000079f4d2dd37aa  jmp 0x000079F4D2DD257E
000079f4d2dd37af  call 0x000079F4D2CC0FC0
000079f4d2dd37b4  jmp 0x000079F4D2DD258B
000079f4d2dd37b9  call 0x000079F4D2CB52F0
000079f4d2dd37be  jmp 0x000079F4D2DD2598
000079f4d2dd37c3  call 0x000079F4D2CC0EA0
000079f4d2dd37c8  jmp 0x000079F4D2DD25A5
000079f4d2dd37cd  call 0x000079F4D2BFF540
000079f4d2dd37d2  jmp 0x000079F4D2DD25C3
000079f4d2dd37d7  call 0x000079F4D2C08C20
000079f4d2dd37dc  jmp 0x000079F4D2DD25CD
000079f4d2dd37e1  call 0x000079F4D2CE21C0
000079f4d2dd37e6  jmp 0x000079F4D2DD25D3
000079f4d2dd37eb  call 0x000079F4D2BFF540
000079f4d2dd37f0  jmp 0x000079F4D2DD25E3
000079f4d2dd37f5  call 0x000079F4D2CC0370
000079f4d2dd37fa  jmp 0x000079F4D2DD2611
000079f4d2dd37ff  call 0x000079F4D2CBF100
000079f4d2dd3804  jmp 0x000079F4D2DD261A
000079f4d2dd3809  call 0x000079F4D2CC0370
000079f4d2dd380e  jmp 0x000079F4D2DD2674
000079f4d2dd3813  call 0x000079F4D2CBF100
000079f4d2dd3818  jmp 0x000079F4D2DD267D
000079f4d2dd381d  call 0x000079F4D2CC0370
000079f4d2dd3822  jmp 0x000079F4D2DD26C6
000079f4d2dd3827  call 0x000079F4D2CBF100
000079f4d2dd382c  jmp 0x000079F4D2DD26CF
000079f4d2dd3831  call 0x000079F4D2C0B720
000079f4d2dd3836  jmp 0x000079F4D2DD2714
000079f4d2dd383b  call 0x000079F4D2CB47C0
000079f4d2dd3840  jmp 0x000079F4D2DD2727
000079f4d2dd3845  call 0x000079F4D2C08B00
000079f4d2dd384a  jmp 0x000079F4D2DD273E
000079f4d2dd384f  call 0x000079F4D2BFF430
000079f4d2dd3854  jmp 0x000079F4D2DD2751
000079f4d2dd3859  call 0x000079F4D2BFF430
000079f4d2dd385e  jmp 0x000079F4D2DD2764
000079f4d2dd3863  sub rsp, 0x08
000079f4d2dd3867  push rax
000079f4d2dd3868  push rcx
000079f4d2dd3869  push rdx
000079f4d2dd386a  push rdi
000079f4d2dd386b  push rsi
000079f4d2dd386c  push r8
000079f4d2dd386e  push r9
000079f4d2dd3870  push r10
000079f4d2dd3872  push r11
000079f4d2dd3874  sub rsp, 0xF0
000079f4d2dd387b  vmovaps [rsp], xmm0
000079f4d2dd3880  vmovaps [rsp+0x10], xmm2
000079f4d2dd3886  vmovaps [rsp+0x20], xmm3
000079f4d2dd388c  vmovaps [rsp+0x30], xmm4
000079f4d2dd3892  vmovaps [rsp+0x40], xmm5
000079f4d2dd3898  vmovaps [rsp+0x50], xmm6
000079f4d2dd389e  vmovaps [rsp+0x60], xmm7
000079f4d2dd38a4  vmovaps [rsp+0x70], xmm8
000079f4d2dd38aa  vmovaps [rsp+0x80], xmm9
000079f4d2dd38b3  vmovaps [rsp+0x90], xmm10
000079f4d2dd38bc  vmovaps [rsp+0xA0], xmm11
000079f4d2dd38c5  vmovaps [rsp+0xB0], xmm12
000079f4d2dd38ce  vmovaps [rsp+0xC0], xmm13
000079f4d2dd38d7  vmovaps [rsp+0xD0], xmm14
000079f4d2dd38e0  vmovaps [rsp+0xE0], xmm15
000079f4d2dd38e9  sub rsp, 0x30
000079f4d2dd38ed  movaps [rsp], xmm1
000079f4d2dd38f1  movaps [rsp+0x10], xmm12
000079f4d2dd38f7  movaps [rsp+0x20], xmm15
000079f4d2dd38fd  lea rdi, [rsp]
000079f4d2dd3901  mov esi, 0x00
000079f4d2dd3906  mov rax, 0x5D9EC01E8530
000079f4d2dd3910  call rax
000079f4d2dd3912  movaps xmm1, [rsp]
000079f4d2dd3916  add rsp, 0x30
000079f4d2dd391a  vmovaps xmm0, [rsp]
000079f4d2dd391f  vmovaps xmm2, [rsp+0x10]
000079f4d2dd3925  vmovaps xmm3, [rsp+0x20]
000079f4d2dd392b  vmovaps xmm4, [rsp+0x30]
000079f4d2dd3931  vmovaps xmm5, [rsp+0x40]
000079f4d2dd3937  vmovaps xmm6, [rsp+0x50]
000079f4d2dd393d  vmovaps xmm7, [rsp+0x60]
000079f4d2dd3943  vmovaps xmm8, [rsp+0x70]
000079f4d2dd3949  vmovaps xmm9, [rsp+0x80]
000079f4d2dd3952  vmovaps xmm10, [rsp+0x90]
000079f4d2dd395b  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd3964  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd396d  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd3976  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd397f  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd3988  add rsp, 0xF0
000079f4d2dd398f  pop r11
000079f4d2dd3991  pop r10
000079f4d2dd3993  pop r9
000079f4d2dd3995  pop r8
000079f4d2dd3997  pop rsi
000079f4d2dd3998  pop rdi
000079f4d2dd3999  pop rdx
000079f4d2dd399a  pop rcx
000079f4d2dd399b  pop rax
000079f4d2dd399c  add rsp, 0x08
000079f4d2dd39a0  jmp 0x000079F4D2DD27B2
000079f4d2dd39a5  sub rsp, 0x08
000079f4d2dd39a9  push rax
000079f4d2dd39aa  push rcx
000079f4d2dd39ab  push rdx
000079f4d2dd39ac  push rdi
000079f4d2dd39ad  push rsi
000079f4d2dd39ae  push r8
000079f4d2dd39b0  push r9
000079f4d2dd39b2  push r10
000079f4d2dd39b4  push r11
000079f4d2dd39b6  sub rsp, 0xF0
000079f4d2dd39bd  vmovaps [rsp], xmm0
000079f4d2dd39c2  vmovaps [rsp+0x10], xmm1
000079f4d2dd39c8  vmovaps [rsp+0x20], xmm2
000079f4d2dd39ce  vmovaps [rsp+0x30], xmm3
000079f4d2dd39d4  vmovaps [rsp+0x40], xmm4
000079f4d2dd39da  vmovaps [rsp+0x50], xmm5
000079f4d2dd39e0  vmovaps [rsp+0x60], xmm6
000079f4d2dd39e6  vmovaps [rsp+0x70], xmm7
000079f4d2dd39ec  vmovaps [rsp+0x80], xmm8
000079f4d2dd39f5  vmovaps [rsp+0x90], xmm9
000079f4d2dd39fe  vmovaps [rsp+0xA0], xmm10
000079f4d2dd3a07  vmovaps [rsp+0xB0], xmm11
000079f4d2dd3a10  vmovaps [rsp+0xC0], xmm12
000079f4d2dd3a19  vmovaps [rsp+0xD0], xmm13
000079f4d2dd3a22  vmovaps [rsp+0xE0], xmm15
000079f4d2dd3a2b  sub rsp, 0x30
000079f4d2dd3a2f  movaps [rsp], xmm14
000079f4d2dd3a34  movaps [rsp+0x10], xmm1
000079f4d2dd3a39  movaps [rsp+0x20], xmm15
000079f4d2dd3a3f  lea rdi, [rsp]
000079f4d2dd3a43  mov esi, 0x00
000079f4d2dd3a48  mov rax, 0x5D9EC01E8530
000079f4d2dd3a52  call rax
000079f4d2dd3a54  movaps xmm14, [rsp]
000079f4d2dd3a59  add rsp, 0x30
000079f4d2dd3a5d  vmovaps xmm0, [rsp]
000079f4d2dd3a62  vmovaps xmm1, [rsp+0x10]
000079f4d2dd3a68  vmovaps xmm2, [rsp+0x20]
000079f4d2dd3a6e  vmovaps xmm3, [rsp+0x30]
000079f4d2dd3a74  vmovaps xmm4, [rsp+0x40]
000079f4d2dd3a7a  vmovaps xmm5, [rsp+0x50]
000079f4d2dd3a80  vmovaps xmm6, [rsp+0x60]
000079f4d2dd3a86  vmovaps xmm7, [rsp+0x70]
000079f4d2dd3a8c  vmovaps xmm8, [rsp+0x80]
000079f4d2dd3a95  vmovaps xmm9, [rsp+0x90]
000079f4d2dd3a9e  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd3aa7  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd3ab0  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd3ab9  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd3ac2  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd3acb  add rsp, 0xF0
000079f4d2dd3ad2  pop r11
000079f4d2dd3ad4  pop r10
000079f4d2dd3ad6  pop r9
000079f4d2dd3ad8  pop r8
000079f4d2dd3ada  pop rsi
000079f4d2dd3adb  pop rdi
000079f4d2dd3adc  pop rdx
000079f4d2dd3add  pop rcx
000079f4d2dd3ade  pop rax
000079f4d2dd3adf  add rsp, 0x08
000079f4d2dd3ae3  jmp 0x000079F4D2DD2800
000079f4d2dd3ae8  sub rsp, 0x08
000079f4d2dd3aec  push rax
000079f4d2dd3aed  push rcx
000079f4d2dd3aee  push rdx
000079f4d2dd3aef  push rdi
000079f4d2dd3af0  push rsi
000079f4d2dd3af1  push r8
000079f4d2dd3af3  push r9
000079f4d2dd3af5  push r10
000079f4d2dd3af7  push r11
000079f4d2dd3af9  sub rsp, 0xF0
000079f4d2dd3b00  vmovaps [rsp], xmm0
000079f4d2dd3b05  vmovaps [rsp+0x10], xmm1
000079f4d2dd3b0b  vmovaps [rsp+0x20], xmm2
000079f4d2dd3b11  vmovaps [rsp+0x30], xmm3
000079f4d2dd3b17  vmovaps [rsp+0x40], xmm4
000079f4d2dd3b1d  vmovaps [rsp+0x50], xmm5
000079f4d2dd3b23  vmovaps [rsp+0x60], xmm6
000079f4d2dd3b29  vmovaps [rsp+0x70], xmm7
000079f4d2dd3b2f  vmovaps [rsp+0x80], xmm8
000079f4d2dd3b38  vmovaps [rsp+0x90], xmm9
000079f4d2dd3b41  vmovaps [rsp+0xA0], xmm10
000079f4d2dd3b4a  vmovaps [rsp+0xB0], xmm11
000079f4d2dd3b53  vmovaps [rsp+0xC0], xmm12
000079f4d2dd3b5c  vmovaps [rsp+0xD0], xmm13
000079f4d2dd3b65  vmovaps [rsp+0xE0], xmm14
000079f4d2dd3b6e  sub rsp, 0x30
000079f4d2dd3b72  movaps [rsp], xmm15
000079f4d2dd3b77  movaps [rsp+0x10], xmm12
000079f4d2dd3b7d  movaps [rsp+0x20], xmm13
000079f4d2dd3b83  lea rdi, [rsp]
000079f4d2dd3b87  mov esi, 0x00
000079f4d2dd3b8c  mov rax, 0x5D9EC01E8530
000079f4d2dd3b96  call rax
000079f4d2dd3b98  movaps xmm15, [rsp]
000079f4d2dd3b9d  add rsp, 0x30
000079f4d2dd3ba1  vmovaps xmm0, [rsp]
000079f4d2dd3ba6  vmovaps xmm1, [rsp+0x10]
000079f4d2dd3bac  vmovaps xmm2, [rsp+0x20]
000079f4d2dd3bb2  vmovaps xmm3, [rsp+0x30]
000079f4d2dd3bb8  vmovaps xmm4, [rsp+0x40]
000079f4d2dd3bbe  vmovaps xmm5, [rsp+0x50]
000079f4d2dd3bc4  vmovaps xmm6, [rsp+0x60]
000079f4d2dd3bca  vmovaps xmm7, [rsp+0x70]
000079f4d2dd3bd0  vmovaps xmm8, [rsp+0x80]
000079f4d2dd3bd9  vmovaps xmm9, [rsp+0x90]
000079f4d2dd3be2  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd3beb  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd3bf4  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd3bfd  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd3c06  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd3c0f  add rsp, 0xF0
000079f4d2dd3c16  pop r11
000079f4d2dd3c18  pop r10
000079f4d2dd3c1a  pop r9
000079f4d2dd3c1c  pop r8
000079f4d2dd3c1e  pop rsi
000079f4d2dd3c1f  pop rdi
000079f4d2dd3c20  pop rdx
000079f4d2dd3c21  pop rcx
000079f4d2dd3c22  pop rax
000079f4d2dd3c23  add rsp, 0x08
000079f4d2dd3c27  jmp 0x000079F4D2DD2835
000079f4d2dd3c2c  sub rsp, 0x08
000079f4d2dd3c30  push rax
000079f4d2dd3c31  push rcx
000079f4d2dd3c32  push rdx
000079f4d2dd3c33  push rdi
000079f4d2dd3c34  push rsi
000079f4d2dd3c35  push r8
000079f4d2dd3c37  push r9
000079f4d2dd3c39  push r10
000079f4d2dd3c3b  push r11
000079f4d2dd3c3d  sub rsp, 0xF0
000079f4d2dd3c44  vmovaps [rsp], xmm0
000079f4d2dd3c49  vmovaps [rsp+0x10], xmm2
000079f4d2dd3c4f  vmovaps [rsp+0x20], xmm3
000079f4d2dd3c55  vmovaps [rsp+0x30], xmm4
000079f4d2dd3c5b  vmovaps [rsp+0x40], xmm5
000079f4d2dd3c61  vmovaps [rsp+0x50], xmm6
000079f4d2dd3c67  vmovaps [rsp+0x60], xmm7
000079f4d2dd3c6d  vmovaps [rsp+0x70], xmm8
000079f4d2dd3c73  vmovaps [rsp+0x80], xmm9
000079f4d2dd3c7c  vmovaps [rsp+0x90], xmm10
000079f4d2dd3c85  vmovaps [rsp+0xA0], xmm11
000079f4d2dd3c8e  vmovaps [rsp+0xB0], xmm12
000079f4d2dd3c97  vmovaps [rsp+0xC0], xmm13
000079f4d2dd3ca0  vmovaps [rsp+0xD0], xmm14
000079f4d2dd3ca9  vmovaps [rsp+0xE0], xmm15
000079f4d2dd3cb2  sub rsp, 0x30
000079f4d2dd3cb6  movaps [rsp], xmm1
000079f4d2dd3cba  movaps [rsp+0x10], xmm12
000079f4d2dd3cc0  movaps [rsp+0x20], xmm10
000079f4d2dd3cc6  lea rdi, [rsp]
000079f4d2dd3cca  mov esi, 0x00
000079f4d2dd3ccf  mov rax, 0x5D9EC01E8530
000079f4d2dd3cd9  call rax
000079f4d2dd3cdb  movaps xmm1, [rsp]
000079f4d2dd3cdf  add rsp, 0x30
000079f4d2dd3ce3  vmovaps xmm0, [rsp]
000079f4d2dd3ce8  vmovaps xmm2, [rsp+0x10]
000079f4d2dd3cee  vmovaps xmm3, [rsp+0x20]
000079f4d2dd3cf4  vmovaps xmm4, [rsp+0x30]
000079f4d2dd3cfa  vmovaps xmm5, [rsp+0x40]
000079f4d2dd3d00  vmovaps xmm6, [rsp+0x50]
000079f4d2dd3d06  vmovaps xmm7, [rsp+0x60]
000079f4d2dd3d0c  vmovaps xmm8, [rsp+0x70]
000079f4d2dd3d12  vmovaps xmm9, [rsp+0x80]
000079f4d2dd3d1b  vmovaps xmm10, [rsp+0x90]
000079f4d2dd3d24  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd3d2d  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd3d36  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd3d3f  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd3d48  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd3d51  add rsp, 0xF0
000079f4d2dd3d58  pop r11
000079f4d2dd3d5a  pop r10
000079f4d2dd3d5c  pop r9
000079f4d2dd3d5e  pop r8
000079f4d2dd3d60  pop rsi
000079f4d2dd3d61  pop rdi
000079f4d2dd3d62  pop rdx
000079f4d2dd3d63  pop rcx
000079f4d2dd3d64  pop rax
000079f4d2dd3d65  add rsp, 0x08
000079f4d2dd3d69  jmp 0x000079F4D2DD284F
000079f4d2dd3d6e  sub rsp, 0x08
000079f4d2dd3d72  push rax
000079f4d2dd3d73  push rcx
000079f4d2dd3d74  push rdx
000079f4d2dd3d75  push rdi
000079f4d2dd3d76  push rsi
000079f4d2dd3d77  push r8
000079f4d2dd3d79  push r9
000079f4d2dd3d7b  push r10
000079f4d2dd3d7d  push r11
000079f4d2dd3d7f  sub rsp, 0xF0
000079f4d2dd3d86  vmovaps [rsp], xmm0
000079f4d2dd3d8b  vmovaps [rsp+0x10], xmm1
000079f4d2dd3d91  vmovaps [rsp+0x20], xmm2
000079f4d2dd3d97  vmovaps [rsp+0x30], xmm3
000079f4d2dd3d9d  vmovaps [rsp+0x40], xmm4
000079f4d2dd3da3  vmovaps [rsp+0x50], xmm5
000079f4d2dd3da9  vmovaps [rsp+0x60], xmm6
000079f4d2dd3daf  vmovaps [rsp+0x70], xmm7
000079f4d2dd3db5  vmovaps [rsp+0x80], xmm8
000079f4d2dd3dbe  vmovaps [rsp+0x90], xmm9
000079f4d2dd3dc7  vmovaps [rsp+0xA0], xmm10
000079f4d2dd3dd0  vmovaps [rsp+0xB0], xmm11
000079f4d2dd3dd9  vmovaps [rsp+0xC0], xmm12
000079f4d2dd3de2  vmovaps [rsp+0xD0], xmm14
000079f4d2dd3deb  vmovaps [rsp+0xE0], xmm15
000079f4d2dd3df4  sub rsp, 0x30
000079f4d2dd3df8  movaps [rsp], xmm13
000079f4d2dd3dfd  movaps [rsp+0x10], xmm12
000079f4d2dd3e03  movaps [rsp+0x20], xmm2
000079f4d2dd3e08  lea rdi, [rsp]
000079f4d2dd3e0c  mov esi, 0x00
000079f4d2dd3e11  mov rax, 0x5D9EC01E8530
000079f4d2dd3e1b  call rax
000079f4d2dd3e1d  movaps xmm13, [rsp]
000079f4d2dd3e22  add rsp, 0x30
000079f4d2dd3e26  vmovaps xmm0, [rsp]
000079f4d2dd3e2b  vmovaps xmm1, [rsp+0x10]
000079f4d2dd3e31  vmovaps xmm2, [rsp+0x20]
000079f4d2dd3e37  vmovaps xmm3, [rsp+0x30]
000079f4d2dd3e3d  vmovaps xmm4, [rsp+0x40]
000079f4d2dd3e43  vmovaps xmm5, [rsp+0x50]
000079f4d2dd3e49  vmovaps xmm6, [rsp+0x60]
000079f4d2dd3e4f  vmovaps xmm7, [rsp+0x70]
000079f4d2dd3e55  vmovaps xmm8, [rsp+0x80]
000079f4d2dd3e5e  vmovaps xmm9, [rsp+0x90]
000079f4d2dd3e67  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd3e70  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd3e79  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd3e82  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd3e8b  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd3e94  add rsp, 0xF0
000079f4d2dd3e9b  pop r11
000079f4d2dd3e9d  pop r10
000079f4d2dd3e9f  pop r9
000079f4d2dd3ea1  pop r8
000079f4d2dd3ea3  pop rsi
000079f4d2dd3ea4  pop rdi
000079f4d2dd3ea5  pop rdx
000079f4d2dd3ea6  pop rcx
000079f4d2dd3ea7  pop rax
000079f4d2dd3ea8  add rsp, 0x08
000079f4d2dd3eac  jmp 0x000079F4D2DD286A
000079f4d2dd3eb1  sub rsp, 0x08
000079f4d2dd3eb5  push rax
000079f4d2dd3eb6  push rcx
000079f4d2dd3eb7  push rdx
000079f4d2dd3eb8  push rdi
000079f4d2dd3eb9  push rsi
000079f4d2dd3eba  push r8
000079f4d2dd3ebc  push r9
000079f4d2dd3ebe  push r10
000079f4d2dd3ec0  push r11
000079f4d2dd3ec2  sub rsp, 0xF0
000079f4d2dd3ec9  vmovaps [rsp], xmm0
000079f4d2dd3ece  vmovaps [rsp+0x10], xmm2
000079f4d2dd3ed4  vmovaps [rsp+0x20], xmm3
000079f4d2dd3eda  vmovaps [rsp+0x30], xmm4
000079f4d2dd3ee0  vmovaps [rsp+0x40], xmm5
000079f4d2dd3ee6  vmovaps [rsp+0x50], xmm6
000079f4d2dd3eec  vmovaps [rsp+0x60], xmm7
000079f4d2dd3ef2  vmovaps [rsp+0x70], xmm8
000079f4d2dd3ef8  vmovaps [rsp+0x80], xmm9
000079f4d2dd3f01  vmovaps [rsp+0x90], xmm10
000079f4d2dd3f0a  vmovaps [rsp+0xA0], xmm11
000079f4d2dd3f13  vmovaps [rsp+0xB0], xmm12
000079f4d2dd3f1c  vmovaps [rsp+0xC0], xmm13
000079f4d2dd3f25  vmovaps [rsp+0xD0], xmm14
000079f4d2dd3f2e  vmovaps [rsp+0xE0], xmm15
000079f4d2dd3f37  sub rsp, 0x30
000079f4d2dd3f3b  movaps [rsp], xmm1
000079f4d2dd3f3f  movaps [rsp+0x10], xmm10
000079f4d2dd3f45  movaps [rsp+0x20], xmm2
000079f4d2dd3f4a  lea rdi, [rsp]
000079f4d2dd3f4e  mov esi, 0x00
000079f4d2dd3f53  mov rax, 0x5D9EC01E8530
000079f4d2dd3f5d  call rax
000079f4d2dd3f5f  movaps xmm1, [rsp]
000079f4d2dd3f63  add rsp, 0x30
000079f4d2dd3f67  vmovaps xmm0, [rsp]
000079f4d2dd3f6c  vmovaps xmm2, [rsp+0x10]
000079f4d2dd3f72  vmovaps xmm3, [rsp+0x20]
000079f4d2dd3f78  vmovaps xmm4, [rsp+0x30]
000079f4d2dd3f7e  vmovaps xmm5, [rsp+0x40]
000079f4d2dd3f84  vmovaps xmm6, [rsp+0x50]
000079f4d2dd3f8a  vmovaps xmm7, [rsp+0x60]
000079f4d2dd3f90  vmovaps xmm8, [rsp+0x70]
000079f4d2dd3f96  vmovaps xmm9, [rsp+0x80]
000079f4d2dd3f9f  vmovaps xmm10, [rsp+0x90]
000079f4d2dd3fa8  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd3fb1  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd3fba  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd3fc3  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd3fcc  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd3fd5  add rsp, 0xF0
000079f4d2dd3fdc  pop r11
000079f4d2dd3fde  pop r10
000079f4d2dd3fe0  pop r9
000079f4d2dd3fe2  pop r8
000079f4d2dd3fe4  pop rsi
000079f4d2dd3fe5  pop rdi
000079f4d2dd3fe6  pop rdx
000079f4d2dd3fe7  pop rcx
000079f4d2dd3fe8  pop rax
000079f4d2dd3fe9  add rsp, 0x08
000079f4d2dd3fed  jmp 0x000079F4D2DD28D2
000079f4d2dd3ff2  sub rsp, 0x08
000079f4d2dd3ff6  push rax
000079f4d2dd3ff7  push rcx
000079f4d2dd3ff8  push rdx
000079f4d2dd3ff9  push rdi
000079f4d2dd3ffa  push rsi
000079f4d2dd3ffb  push r8
000079f4d2dd3ffd  push r9
000079f4d2dd3fff  push r10
000079f4d2dd4001  push r11
000079f4d2dd4003  sub rsp, 0xF0
000079f4d2dd400a  vmovaps [rsp], xmm0
000079f4d2dd400f  vmovaps [rsp+0x10], xmm1
000079f4d2dd4015  vmovaps [rsp+0x20], xmm2
000079f4d2dd401b  vmovaps [rsp+0x30], xmm3
000079f4d2dd4021  vmovaps [rsp+0x40], xmm4
000079f4d2dd4027  vmovaps [rsp+0x50], xmm5
000079f4d2dd402d  vmovaps [rsp+0x60], xmm6
000079f4d2dd4033  vmovaps [rsp+0x70], xmm7
000079f4d2dd4039  vmovaps [rsp+0x80], xmm8
000079f4d2dd4042  vmovaps [rsp+0x90], xmm9
000079f4d2dd404b  vmovaps [rsp+0xA0], xmm10
000079f4d2dd4054  vmovaps [rsp+0xB0], xmm11
000079f4d2dd405d  vmovaps [rsp+0xC0], xmm12
000079f4d2dd4066  vmovaps [rsp+0xD0], xmm13
000079f4d2dd406f  vmovaps [rsp+0xE0], xmm14
000079f4d2dd4078  sub rsp, 0x30
000079f4d2dd407c  movaps [rsp], xmm15
000079f4d2dd4081  movaps [rsp+0x10], xmm10
000079f4d2dd4087  movaps [rsp+0x20], xmm2
000079f4d2dd408c  lea rdi, [rsp]
000079f4d2dd4090  mov esi, 0x00
000079f4d2dd4095  mov rax, 0x5D9EC01E8530
000079f4d2dd409f  call rax
000079f4d2dd40a1  movaps xmm15, [rsp]
000079f4d2dd40a6  add rsp, 0x30
000079f4d2dd40aa  vmovaps xmm0, [rsp]
000079f4d2dd40af  vmovaps xmm1, [rsp+0x10]
000079f4d2dd40b5  vmovaps xmm2, [rsp+0x20]
000079f4d2dd40bb  vmovaps xmm3, [rsp+0x30]
000079f4d2dd40c1  vmovaps xmm4, [rsp+0x40]
000079f4d2dd40c7  vmovaps xmm5, [rsp+0x50]
000079f4d2dd40cd  vmovaps xmm6, [rsp+0x60]
000079f4d2dd40d3  vmovaps xmm7, [rsp+0x70]
000079f4d2dd40d9  vmovaps xmm8, [rsp+0x80]
000079f4d2dd40e2  vmovaps xmm9, [rsp+0x90]
000079f4d2dd40eb  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd40f4  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd40fd  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd4106  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd410f  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd4118  add rsp, 0xF0
000079f4d2dd411f  pop r11
000079f4d2dd4121  pop r10
000079f4d2dd4123  pop r9
000079f4d2dd4125  pop r8
000079f4d2dd4127  pop rsi
000079f4d2dd4128  pop rdi
000079f4d2dd4129  pop rdx
000079f4d2dd412a  pop rcx
000079f4d2dd412b  pop rax
000079f4d2dd412c  add rsp, 0x08
000079f4d2dd4130  jmp 0x000079F4D2DD2924
000079f4d2dd4135  sub rsp, 0x08
000079f4d2dd4139  push rax
000079f4d2dd413a  push rcx
000079f4d2dd413b  push rdx
000079f4d2dd413c  push rdi
000079f4d2dd413d  push rsi
000079f4d2dd413e  push r8
000079f4d2dd4140  push r9
000079f4d2dd4142  push r10
000079f4d2dd4144  push r11
000079f4d2dd4146  sub rsp, 0xF0
000079f4d2dd414d  vmovaps [rsp], xmm0
000079f4d2dd4152  vmovaps [rsp+0x10], xmm2
000079f4d2dd4158  vmovaps [rsp+0x20], xmm3
000079f4d2dd415e  vmovaps [rsp+0x30], xmm4
000079f4d2dd4164  vmovaps [rsp+0x40], xmm5
000079f4d2dd416a  vmovaps [rsp+0x50], xmm6
000079f4d2dd4170  vmovaps [rsp+0x60], xmm7
000079f4d2dd4176  vmovaps [rsp+0x70], xmm8
000079f4d2dd417c  vmovaps [rsp+0x80], xmm9
000079f4d2dd4185  vmovaps [rsp+0x90], xmm10
000079f4d2dd418e  vmovaps [rsp+0xA0], xmm11
000079f4d2dd4197  vmovaps [rsp+0xB0], xmm12
000079f4d2dd41a0  vmovaps [rsp+0xC0], xmm13
000079f4d2dd41a9  vmovaps [rsp+0xD0], xmm14
000079f4d2dd41b2  vmovaps [rsp+0xE0], xmm15
000079f4d2dd41bb  sub rsp, 0x30
000079f4d2dd41bf  movaps [rsp], xmm1
000079f4d2dd41c3  movaps [rsp+0x10], xmm10
000079f4d2dd41c9  movaps [rsp+0x20], xmm15
000079f4d2dd41cf  lea rdi, [rsp]
000079f4d2dd41d3  mov esi, 0x00
000079f4d2dd41d8  mov rax, 0x5D9EC01E8530
000079f4d2dd41e2  call rax
000079f4d2dd41e4  movaps xmm1, [rsp]
000079f4d2dd41e8  add rsp, 0x30
000079f4d2dd41ec  vmovaps xmm0, [rsp]
000079f4d2dd41f1  vmovaps xmm2, [rsp+0x10]
000079f4d2dd41f7  vmovaps xmm3, [rsp+0x20]
000079f4d2dd41fd  vmovaps xmm4, [rsp+0x30]
000079f4d2dd4203  vmovaps xmm5, [rsp+0x40]
000079f4d2dd4209  vmovaps xmm6, [rsp+0x50]
000079f4d2dd420f  vmovaps xmm7, [rsp+0x60]
000079f4d2dd4215  vmovaps xmm8, [rsp+0x70]
000079f4d2dd421b  vmovaps xmm9, [rsp+0x80]
000079f4d2dd4224  vmovaps xmm10, [rsp+0x90]
000079f4d2dd422d  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd4236  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd423f  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd4248  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd4251  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd425a  add rsp, 0xF0
000079f4d2dd4261  pop r11
000079f4d2dd4263  pop r10
000079f4d2dd4265  pop r9
000079f4d2dd4267  pop r8
000079f4d2dd4269  pop rsi
000079f4d2dd426a  pop rdi
000079f4d2dd426b  pop rdx
000079f4d2dd426c  pop rcx
000079f4d2dd426d  pop rax
000079f4d2dd426e  add rsp, 0x08
000079f4d2dd4272  jmp 0x000079F4D2DD2962
000079f4d2dd4277  sub rsp, 0x08
000079f4d2dd427b  push rax
000079f4d2dd427c  push rcx
000079f4d2dd427d  push rdx
000079f4d2dd427e  push rdi
000079f4d2dd427f  push rsi
000079f4d2dd4280  push r8
000079f4d2dd4282  push r9
000079f4d2dd4284  push r10
000079f4d2dd4286  push r11
000079f4d2dd4288  sub rsp, 0xF0
000079f4d2dd428f  vmovaps [rsp], xmm0
000079f4d2dd4294  vmovaps [rsp+0x10], xmm1
000079f4d2dd429a  vmovaps [rsp+0x20], xmm2
000079f4d2dd42a0  vmovaps [rsp+0x30], xmm3
000079f4d2dd42a6  vmovaps [rsp+0x40], xmm4
000079f4d2dd42ac  vmovaps [rsp+0x50], xmm5
000079f4d2dd42b2  vmovaps [rsp+0x60], xmm6
000079f4d2dd42b8  vmovaps [rsp+0x70], xmm7
000079f4d2dd42be  vmovaps [rsp+0x80], xmm8
000079f4d2dd42c7  vmovaps [rsp+0x90], xmm9
000079f4d2dd42d0  vmovaps [rsp+0xA0], xmm10
000079f4d2dd42d9  vmovaps [rsp+0xB0], xmm11
000079f4d2dd42e2  vmovaps [rsp+0xC0], xmm12
000079f4d2dd42eb  vmovaps [rsp+0xD0], xmm13
000079f4d2dd42f4  vmovaps [rsp+0xE0], xmm15
000079f4d2dd42fd  sub rsp, 0x30
000079f4d2dd4301  movaps [rsp], xmm14
000079f4d2dd4306  movaps [rsp+0x10], xmm10
000079f4d2dd430c  movaps [rsp+0x20], xmm15
000079f4d2dd4312  lea rdi, [rsp]
000079f4d2dd4316  mov esi, 0x00
000079f4d2dd431b  mov rax, 0x5D9EC01E8530
000079f4d2dd4325  call rax
000079f4d2dd4327  movaps xmm14, [rsp]
000079f4d2dd432c  add rsp, 0x30
000079f4d2dd4330  vmovaps xmm0, [rsp]
000079f4d2dd4335  vmovaps xmm1, [rsp+0x10]
000079f4d2dd433b  vmovaps xmm2, [rsp+0x20]
000079f4d2dd4341  vmovaps xmm3, [rsp+0x30]
000079f4d2dd4347  vmovaps xmm4, [rsp+0x40]
000079f4d2dd434d  vmovaps xmm5, [rsp+0x50]
000079f4d2dd4353  vmovaps xmm6, [rsp+0x60]
000079f4d2dd4359  vmovaps xmm7, [rsp+0x70]
000079f4d2dd435f  vmovaps xmm8, [rsp+0x80]
000079f4d2dd4368  vmovaps xmm9, [rsp+0x90]
000079f4d2dd4371  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd437a  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd4383  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd438c  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd4395  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd439e  add rsp, 0xF0
000079f4d2dd43a5  pop r11
000079f4d2dd43a7  pop r10
000079f4d2dd43a9  pop r9
000079f4d2dd43ab  pop r8
000079f4d2dd43ad  pop rsi
000079f4d2dd43ae  pop rdi
000079f4d2dd43af  pop rdx
000079f4d2dd43b0  pop rcx
000079f4d2dd43b1  pop rax
000079f4d2dd43b2  add rsp, 0x08
000079f4d2dd43b6  jmp 0x000079F4D2DD298E
000079f4d2dd43bb  call 0x000079F4D2BFF430
000079f4d2dd43c0  jmp 0x000079F4D2DD2A1E
000079f4d2dd43c5  call 0x000079F4D2BFF430
000079f4d2dd43ca  jmp 0x000079F4D2DD2A31
000079f4d2dd43cf  sub rsp, 0x08
000079f4d2dd43d3  push rax
000079f4d2dd43d4  push rcx
000079f4d2dd43d5  push rdx
000079f4d2dd43d6  push rdi
000079f4d2dd43d7  push rsi
000079f4d2dd43d8  push r8
000079f4d2dd43da  push r9
000079f4d2dd43dc  push r10
000079f4d2dd43de  push r11
000079f4d2dd43e0  sub rsp, 0xF0
000079f4d2dd43e7  vmovaps [rsp], xmm0
000079f4d2dd43ec  vmovaps [rsp+0x10], xmm2
000079f4d2dd43f2  vmovaps [rsp+0x20], xmm3
000079f4d2dd43f8  vmovaps [rsp+0x30], xmm4
000079f4d2dd43fe  vmovaps [rsp+0x40], xmm5
000079f4d2dd4404  vmovaps [rsp+0x50], xmm6
000079f4d2dd440a  vmovaps [rsp+0x60], xmm7
000079f4d2dd4410  vmovaps [rsp+0x70], xmm8
000079f4d2dd4416  vmovaps [rsp+0x80], xmm9
000079f4d2dd441f  vmovaps [rsp+0x90], xmm10
000079f4d2dd4428  vmovaps [rsp+0xA0], xmm11
000079f4d2dd4431  vmovaps [rsp+0xB0], xmm12
000079f4d2dd443a  vmovaps [rsp+0xC0], xmm13
000079f4d2dd4443  vmovaps [rsp+0xD0], xmm14
000079f4d2dd444c  vmovaps [rsp+0xE0], xmm15
000079f4d2dd4455  sub rsp, 0x30
000079f4d2dd4459  movaps [rsp], xmm1
000079f4d2dd445d  movaps [rsp+0x10], xmm13
000079f4d2dd4463  movaps [rsp+0x20], xmm2
000079f4d2dd4468  lea rdi, [rsp]
000079f4d2dd446c  mov esi, 0x00
000079f4d2dd4471  mov rax, 0x5D9EC01E8530
000079f4d2dd447b  call rax
000079f4d2dd447d  movaps xmm1, [rsp]
000079f4d2dd4481  add rsp, 0x30
000079f4d2dd4485  vmovaps xmm0, [rsp]
000079f4d2dd448a  vmovaps xmm2, [rsp+0x10]
000079f4d2dd4490  vmovaps xmm3, [rsp+0x20]
000079f4d2dd4496  vmovaps xmm4, [rsp+0x30]
000079f4d2dd449c  vmovaps xmm5, [rsp+0x40]
000079f4d2dd44a2  vmovaps xmm6, [rsp+0x50]
000079f4d2dd44a8  vmovaps xmm7, [rsp+0x60]
000079f4d2dd44ae  vmovaps xmm8, [rsp+0x70]
000079f4d2dd44b4  vmovaps xmm9, [rsp+0x80]
000079f4d2dd44bd  vmovaps xmm10, [rsp+0x90]
000079f4d2dd44c6  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd44cf  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd44d8  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd44e1  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd44ea  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd44f3  add rsp, 0xF0
000079f4d2dd44fa  pop r11
000079f4d2dd44fc  pop r10
000079f4d2dd44fe  pop r9
000079f4d2dd4500  pop r8
000079f4d2dd4502  pop rsi
000079f4d2dd4503  pop rdi
000079f4d2dd4504  pop rdx
000079f4d2dd4505  pop rcx
000079f4d2dd4506  pop rax
000079f4d2dd4507  add rsp, 0x08
000079f4d2dd450b  jmp 0x000079F4D2DD2A5C
000079f4d2dd4510  call 0x000079F4D2C0E760
000079f4d2dd4515  jmp 0x000079F4D2DD2A69
000079f4d2dd451a  sub rsp, 0x08
000079f4d2dd451e  push rax
000079f4d2dd451f  push rcx
000079f4d2dd4520  push rdx
000079f4d2dd4521  push rdi
000079f4d2dd4522  push rsi
000079f4d2dd4523  push r8
000079f4d2dd4525  push r9
000079f4d2dd4527  push r10
000079f4d2dd4529  push r11
000079f4d2dd452b  sub rsp, 0xF0
000079f4d2dd4532  vmovaps [rsp], xmm0
000079f4d2dd4537  vmovaps [rsp+0x10], xmm1
000079f4d2dd453d  vmovaps [rsp+0x20], xmm2
000079f4d2dd4543  vmovaps [rsp+0x30], xmm3
000079f4d2dd4549  vmovaps [rsp+0x40], xmm4
000079f4d2dd454f  vmovaps [rsp+0x50], xmm5
000079f4d2dd4555  vmovaps [rsp+0x60], xmm6
000079f4d2dd455b  vmovaps [rsp+0x70], xmm7
000079f4d2dd4561  vmovaps [rsp+0x80], xmm8
000079f4d2dd456a  vmovaps [rsp+0x90], xmm9
000079f4d2dd4573  vmovaps [rsp+0xA0], xmm10
000079f4d2dd457c  vmovaps [rsp+0xB0], xmm11
000079f4d2dd4585  vmovaps [rsp+0xC0], xmm12
000079f4d2dd458e  vmovaps [rsp+0xD0], xmm14
000079f4d2dd4597  vmovaps [rsp+0xE0], xmm15
000079f4d2dd45a0  sub rsp, 0x30
000079f4d2dd45a4  movaps [rsp], xmm13
000079f4d2dd45a9  movaps [rsp+0x10], xmm2
000079f4d2dd45ae  movaps [rsp+0x20], xmm1
000079f4d2dd45b3  lea rdi, [rsp]
000079f4d2dd45b7  mov esi, 0x00
000079f4d2dd45bc  mov rax, 0x5D9EC01E8530
000079f4d2dd45c6  call rax
000079f4d2dd45c8  movaps xmm13, [rsp]
000079f4d2dd45cd  add rsp, 0x30
000079f4d2dd45d1  vmovaps xmm0, [rsp]
000079f4d2dd45d6  vmovaps xmm1, [rsp+0x10]
000079f4d2dd45dc  vmovaps xmm2, [rsp+0x20]
000079f4d2dd45e2  vmovaps xmm3, [rsp+0x30]
000079f4d2dd45e8  vmovaps xmm4, [rsp+0x40]
000079f4d2dd45ee  vmovaps xmm5, [rsp+0x50]
000079f4d2dd45f4  vmovaps xmm6, [rsp+0x60]
000079f4d2dd45fa  vmovaps xmm7, [rsp+0x70]
000079f4d2dd4600  vmovaps xmm8, [rsp+0x80]
000079f4d2dd4609  vmovaps xmm9, [rsp+0x90]
000079f4d2dd4612  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd461b  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd4624  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd462d  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd4636  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd463f  add rsp, 0xF0
000079f4d2dd4646  pop r11
000079f4d2dd4648  pop r10
000079f4d2dd464a  pop r9
000079f4d2dd464c  pop r8
000079f4d2dd464e  pop rsi
000079f4d2dd464f  pop rdi
000079f4d2dd4650  pop rdx
000079f4d2dd4651  pop rcx
000079f4d2dd4652  pop rax
000079f4d2dd4653  add rsp, 0x08
000079f4d2dd4657  jmp 0x000079F4D2DD2AA8
000079f4d2dd465c  sub rsp, 0x08
000079f4d2dd4660  push rax
000079f4d2dd4661  push rcx
000079f4d2dd4662  push rdx
000079f4d2dd4663  push rdi
000079f4d2dd4664  push rsi
000079f4d2dd4665  push r8
000079f4d2dd4667  push r9
000079f4d2dd4669  push r10
000079f4d2dd466b  push r11
000079f4d2dd466d  sub rsp, 0xF0
000079f4d2dd4674  vmovaps [rsp], xmm0
000079f4d2dd4679  vmovaps [rsp+0x10], xmm2
000079f4d2dd467f  vmovaps [rsp+0x20], xmm3
000079f4d2dd4685  vmovaps [rsp+0x30], xmm4
000079f4d2dd468b  vmovaps [rsp+0x40], xmm5
000079f4d2dd4691  vmovaps [rsp+0x50], xmm6
000079f4d2dd4697  vmovaps [rsp+0x60], xmm7
000079f4d2dd469d  vmovaps [rsp+0x70], xmm8
000079f4d2dd46a3  vmovaps [rsp+0x80], xmm9
000079f4d2dd46ac  vmovaps [rsp+0x90], xmm10
000079f4d2dd46b5  vmovaps [rsp+0xA0], xmm11
000079f4d2dd46be  vmovaps [rsp+0xB0], xmm12
000079f4d2dd46c7  vmovaps [rsp+0xC0], xmm13
000079f4d2dd46d0  vmovaps [rsp+0xD0], xmm14
000079f4d2dd46d9  vmovaps [rsp+0xE0], xmm15
000079f4d2dd46e2  sub rsp, 0x30
000079f4d2dd46e6  movaps [rsp], xmm1
000079f4d2dd46ea  movaps [rsp+0x10], xmm14
000079f4d2dd46f0  movaps [rsp+0x20], xmm15
000079f4d2dd46f6  lea rdi, [rsp]
000079f4d2dd46fa  mov esi, 0x00
000079f4d2dd46ff  mov rax, 0x5D9EC01E8530
000079f4d2dd4709  call rax
000079f4d2dd470b  movaps xmm1, [rsp]
000079f4d2dd470f  add rsp, 0x30
000079f4d2dd4713  vmovaps xmm0, [rsp]
000079f4d2dd4718  vmovaps xmm2, [rsp+0x10]
000079f4d2dd471e  vmovaps xmm3, [rsp+0x20]
000079f4d2dd4724  vmovaps xmm4, [rsp+0x30]
000079f4d2dd472a  vmovaps xmm5, [rsp+0x40]
000079f4d2dd4730  vmovaps xmm6, [rsp+0x50]
000079f4d2dd4736  vmovaps xmm7, [rsp+0x60]
000079f4d2dd473c  vmovaps xmm8, [rsp+0x70]
000079f4d2dd4742  vmovaps xmm9, [rsp+0x80]
000079f4d2dd474b  vmovaps xmm10, [rsp+0x90]
000079f4d2dd4754  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd475d  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd4766  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd476f  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd4778  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd4781  add rsp, 0xF0
000079f4d2dd4788  pop r11
000079f4d2dd478a  pop r10
000079f4d2dd478c  pop r9
000079f4d2dd478e  pop r8
000079f4d2dd4790  pop rsi
000079f4d2dd4791  pop rdi
000079f4d2dd4792  pop rdx
000079f4d2dd4793  pop rcx
000079f4d2dd4794  pop rax
000079f4d2dd4795  add rsp, 0x08
000079f4d2dd4799  jmp 0x000079F4D2DD2ACA
000079f4d2dd479e  sub rsp, 0x08
000079f4d2dd47a2  push rax
000079f4d2dd47a3  push rcx
000079f4d2dd47a4  push rdx
000079f4d2dd47a5  push rdi
000079f4d2dd47a6  push rsi
000079f4d2dd47a7  push r8
000079f4d2dd47a9  push r9
000079f4d2dd47ab  push r10
000079f4d2dd47ad  push r11
000079f4d2dd47af  sub rsp, 0xF0
000079f4d2dd47b6  vmovaps [rsp], xmm0
000079f4d2dd47bb  vmovaps [rsp+0x10], xmm1
000079f4d2dd47c1  vmovaps [rsp+0x20], xmm2
000079f4d2dd47c7  vmovaps [rsp+0x30], xmm3
000079f4d2dd47cd  vmovaps [rsp+0x40], xmm4
000079f4d2dd47d3  vmovaps [rsp+0x50], xmm5
000079f4d2dd47d9  vmovaps [rsp+0x60], xmm6
000079f4d2dd47df  vmovaps [rsp+0x70], xmm7
000079f4d2dd47e5  vmovaps [rsp+0x80], xmm8
000079f4d2dd47ee  vmovaps [rsp+0x90], xmm9
000079f4d2dd47f7  vmovaps [rsp+0xA0], xmm10
000079f4d2dd4800  vmovaps [rsp+0xB0], xmm11
000079f4d2dd4809  vmovaps [rsp+0xC0], xmm12
000079f4d2dd4812  vmovaps [rsp+0xD0], xmm13
000079f4d2dd481b  vmovaps [rsp+0xE0], xmm15
000079f4d2dd4824  sub rsp, 0x30
000079f4d2dd4828  movaps [rsp], xmm14
000079f4d2dd482d  movaps [rsp+0x10], xmm2
000079f4d2dd4832  movaps [rsp+0x20], xmm15
000079f4d2dd4838  lea rdi, [rsp]
000079f4d2dd483c  mov esi, 0x00
000079f4d2dd4841  mov rax, 0x5D9EC01E8530
000079f4d2dd484b  call rax
000079f4d2dd484d  movaps xmm14, [rsp]
000079f4d2dd4852  add rsp, 0x30
000079f4d2dd4856  vmovaps xmm0, [rsp]
000079f4d2dd485b  vmovaps xmm1, [rsp+0x10]
000079f4d2dd4861  vmovaps xmm2, [rsp+0x20]
000079f4d2dd4867  vmovaps xmm3, [rsp+0x30]
000079f4d2dd486d  vmovaps xmm4, [rsp+0x40]
000079f4d2dd4873  vmovaps xmm5, [rsp+0x50]
000079f4d2dd4879  vmovaps xmm6, [rsp+0x60]
000079f4d2dd487f  vmovaps xmm7, [rsp+0x70]
000079f4d2dd4885  vmovaps xmm8, [rsp+0x80]
000079f4d2dd488e  vmovaps xmm9, [rsp+0x90]
000079f4d2dd4897  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd48a0  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd48a9  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd48b2  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd48bb  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd48c4  add rsp, 0xF0
000079f4d2dd48cb  pop r11
000079f4d2dd48cd  pop r10
000079f4d2dd48cf  pop r9
000079f4d2dd48d1  pop r8
000079f4d2dd48d3  pop rsi
000079f4d2dd48d4  pop rdi
000079f4d2dd48d5  pop rdx
000079f4d2dd48d6  pop rcx
000079f4d2dd48d7  pop rax
000079f4d2dd48d8  add rsp, 0x08
000079f4d2dd48dc  jmp 0x000079F4D2DD2B05
000079f4d2dd48e1  sub rsp, 0x08
000079f4d2dd48e5  push rax
000079f4d2dd48e6  push rcx
000079f4d2dd48e7  push rdx
000079f4d2dd48e8  push rdi
000079f4d2dd48e9  push rsi
000079f4d2dd48ea  push r8
000079f4d2dd48ec  push r9
000079f4d2dd48ee  push r10
000079f4d2dd48f0  push r11
000079f4d2dd48f2  sub rsp, 0xF0
000079f4d2dd48f9  vmovaps [rsp], xmm0
000079f4d2dd48fe  vmovaps [rsp+0x10], xmm1
000079f4d2dd4904  vmovaps [rsp+0x20], xmm2
000079f4d2dd490a  vmovaps [rsp+0x30], xmm3
000079f4d2dd4910  vmovaps [rsp+0x40], xmm4
000079f4d2dd4916  vmovaps [rsp+0x50], xmm5
000079f4d2dd491c  vmovaps [rsp+0x60], xmm6
000079f4d2dd4922  vmovaps [rsp+0x70], xmm7
000079f4d2dd4928  vmovaps [rsp+0x80], xmm8
000079f4d2dd4931  vmovaps [rsp+0x90], xmm9
000079f4d2dd493a  vmovaps [rsp+0xA0], xmm10
000079f4d2dd4943  vmovaps [rsp+0xB0], xmm11
000079f4d2dd494c  vmovaps [rsp+0xC0], xmm12
000079f4d2dd4955  vmovaps [rsp+0xD0], xmm13
000079f4d2dd495e  vmovaps [rsp+0xE0], xmm14
000079f4d2dd4967  sub rsp, 0x30
000079f4d2dd496b  movaps [rsp], xmm15
000079f4d2dd4970  movaps [rsp+0x10], xmm2
000079f4d2dd4975  movaps [rsp+0x20], xmm1
000079f4d2dd497a  lea rdi, [rsp]
000079f4d2dd497e  mov esi, 0x00
000079f4d2dd4983  mov rax, 0x5D9EC01E8530
000079f4d2dd498d  call rax
000079f4d2dd498f  movaps xmm15, [rsp]
000079f4d2dd4994  add rsp, 0x30
000079f4d2dd4998  vmovaps xmm0, [rsp]
000079f4d2dd499d  vmovaps xmm1, [rsp+0x10]
000079f4d2dd49a3  vmovaps xmm2, [rsp+0x20]
000079f4d2dd49a9  vmovaps xmm3, [rsp+0x30]
000079f4d2dd49af  vmovaps xmm4, [rsp+0x40]
000079f4d2dd49b5  vmovaps xmm5, [rsp+0x50]
000079f4d2dd49bb  vmovaps xmm6, [rsp+0x60]
000079f4d2dd49c1  vmovaps xmm7, [rsp+0x70]
000079f4d2dd49c7  vmovaps xmm8, [rsp+0x80]
000079f4d2dd49d0  vmovaps xmm9, [rsp+0x90]
000079f4d2dd49d9  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd49e2  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd49eb  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd49f4  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd49fd  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd4a06  add rsp, 0xF0
000079f4d2dd4a0d  pop r11
000079f4d2dd4a0f  pop r10
000079f4d2dd4a11  pop r9
000079f4d2dd4a13  pop r8
000079f4d2dd4a15  pop rsi
000079f4d2dd4a16  pop rdi
000079f4d2dd4a17  pop rdx
000079f4d2dd4a18  pop rcx
000079f4d2dd4a19  pop rax
000079f4d2dd4a1a  add rsp, 0x08
000079f4d2dd4a1e  jmp 0x000079F4D2DD2B41
000079f4d2dd4a23  call 0x000079F4D2BFF430
000079f4d2dd4a28  jmp 0x000079F4D2DD2B4E
000079f4d2dd4a2d  sub rsp, 0x08
000079f4d2dd4a31  push rax
000079f4d2dd4a32  push rcx
000079f4d2dd4a33  push rdx
000079f4d2dd4a34  push rdi
000079f4d2dd4a35  push rsi
000079f4d2dd4a36  push r8
000079f4d2dd4a38  push r9
000079f4d2dd4a3a  push r10
000079f4d2dd4a3c  push r11
000079f4d2dd4a3e  sub rsp, 0xF0
000079f4d2dd4a45  vmovaps [rsp], xmm0
000079f4d2dd4a4a  vmovaps [rsp+0x10], xmm1
000079f4d2dd4a50  vmovaps [rsp+0x20], xmm3
000079f4d2dd4a56  vmovaps [rsp+0x30], xmm4
000079f4d2dd4a5c  vmovaps [rsp+0x40], xmm5
000079f4d2dd4a62  vmovaps [rsp+0x50], xmm6
000079f4d2dd4a68  vmovaps [rsp+0x60], xmm7
000079f4d2dd4a6e  vmovaps [rsp+0x70], xmm8
000079f4d2dd4a74  vmovaps [rsp+0x80], xmm9
000079f4d2dd4a7d  vmovaps [rsp+0x90], xmm10
000079f4d2dd4a86  vmovaps [rsp+0xA0], xmm11
000079f4d2dd4a8f  vmovaps [rsp+0xB0], xmm12
000079f4d2dd4a98  vmovaps [rsp+0xC0], xmm13
000079f4d2dd4aa1  vmovaps [rsp+0xD0], xmm14
000079f4d2dd4aaa  vmovaps [rsp+0xE0], xmm15
000079f4d2dd4ab3  sub rsp, 0x30
000079f4d2dd4ab7  movaps [rsp], xmm2
000079f4d2dd4abb  movaps [rsp+0x10], xmm1
000079f4d2dd4ac0  movaps [rsp+0x20], xmm14
000079f4d2dd4ac6  lea rdi, [rsp]
000079f4d2dd4aca  mov esi, 0x00
000079f4d2dd4acf  mov rax, 0x5D9EC01E8530
000079f4d2dd4ad9  call rax
000079f4d2dd4adb  movaps xmm2, [rsp]
000079f4d2dd4adf  add rsp, 0x30
000079f4d2dd4ae3  vmovaps xmm0, [rsp]
000079f4d2dd4ae8  vmovaps xmm1, [rsp+0x10]
000079f4d2dd4aee  vmovaps xmm3, [rsp+0x20]
000079f4d2dd4af4  vmovaps xmm4, [rsp+0x30]
000079f4d2dd4afa  vmovaps xmm5, [rsp+0x40]
000079f4d2dd4b00  vmovaps xmm6, [rsp+0x50]
000079f4d2dd4b06  vmovaps xmm7, [rsp+0x60]
000079f4d2dd4b0c  vmovaps xmm8, [rsp+0x70]
000079f4d2dd4b12  vmovaps xmm9, [rsp+0x80]
000079f4d2dd4b1b  vmovaps xmm10, [rsp+0x90]
000079f4d2dd4b24  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd4b2d  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd4b36  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd4b3f  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd4b48  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd4b51  add rsp, 0xF0
000079f4d2dd4b58  pop r11
000079f4d2dd4b5a  pop r10
000079f4d2dd4b5c  pop r9
000079f4d2dd4b5e  pop r8
000079f4d2dd4b60  pop rsi
000079f4d2dd4b61  pop rdi
000079f4d2dd4b62  pop rdx
000079f4d2dd4b63  pop rcx
000079f4d2dd4b64  pop rax
000079f4d2dd4b65  add rsp, 0x08
000079f4d2dd4b69  jmp 0x000079F4D2DD2B8B
000079f4d2dd4b6e  sub rsp, 0x08
000079f4d2dd4b72  push rax
000079f4d2dd4b73  push rcx
000079f4d2dd4b74  push rdx
000079f4d2dd4b75  push rdi
000079f4d2dd4b76  push rsi
000079f4d2dd4b77  push r8
000079f4d2dd4b79  push r9
000079f4d2dd4b7b  push r10
000079f4d2dd4b7d  push r11
000079f4d2dd4b7f  sub rsp, 0xF0
000079f4d2dd4b86  vmovaps [rsp], xmm0
000079f4d2dd4b8b  vmovaps [rsp+0x10], xmm1
000079f4d2dd4b91  vmovaps [rsp+0x20], xmm2
000079f4d2dd4b97  vmovaps [rsp+0x30], xmm3
000079f4d2dd4b9d  vmovaps [rsp+0x40], xmm4
000079f4d2dd4ba3  vmovaps [rsp+0x50], xmm5
000079f4d2dd4ba9  vmovaps [rsp+0x60], xmm6
000079f4d2dd4baf  vmovaps [rsp+0x70], xmm7
000079f4d2dd4bb5  vmovaps [rsp+0x80], xmm8
000079f4d2dd4bbe  vmovaps [rsp+0x90], xmm9
000079f4d2dd4bc7  vmovaps [rsp+0xA0], xmm10
000079f4d2dd4bd0  vmovaps [rsp+0xB0], xmm11
000079f4d2dd4bd9  vmovaps [rsp+0xC0], xmm12
000079f4d2dd4be2  vmovaps [rsp+0xD0], xmm13
000079f4d2dd4beb  vmovaps [rsp+0xE0], xmm14
000079f4d2dd4bf4  sub rsp, 0x30
000079f4d2dd4bf8  movaps [rsp], xmm15
000079f4d2dd4bfd  movaps [rsp+0x10], xmm14
000079f4d2dd4c03  movaps [rsp+0x20], xmm1
000079f4d2dd4c08  lea rdi, [rsp]
000079f4d2dd4c0c  mov esi, 0x00
000079f4d2dd4c11  mov rax, 0x5D9EC01E8530
000079f4d2dd4c1b  call rax
000079f4d2dd4c1d  movaps xmm15, [rsp]
000079f4d2dd4c22  add rsp, 0x30
000079f4d2dd4c26  vmovaps xmm0, [rsp]
000079f4d2dd4c2b  vmovaps xmm1, [rsp+0x10]
000079f4d2dd4c31  vmovaps xmm2, [rsp+0x20]
000079f4d2dd4c37  vmovaps xmm3, [rsp+0x30]
000079f4d2dd4c3d  vmovaps xmm4, [rsp+0x40]
000079f4d2dd4c43  vmovaps xmm5, [rsp+0x50]
000079f4d2dd4c49  vmovaps xmm6, [rsp+0x60]
000079f4d2dd4c4f  vmovaps xmm7, [rsp+0x70]
000079f4d2dd4c55  vmovaps xmm8, [rsp+0x80]
000079f4d2dd4c5e  vmovaps xmm9, [rsp+0x90]
000079f4d2dd4c67  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd4c70  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd4c79  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd4c82  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd4c8b  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd4c94  add rsp, 0xF0
000079f4d2dd4c9b  pop r11
000079f4d2dd4c9d  pop r10
000079f4d2dd4c9f  pop r9
000079f4d2dd4ca1  pop r8
000079f4d2dd4ca3  pop rsi
000079f4d2dd4ca4  pop rdi
000079f4d2dd4ca5  pop rdx
000079f4d2dd4ca6  pop rcx
000079f4d2dd4ca7  pop rax
000079f4d2dd4ca8  add rsp, 0x08
000079f4d2dd4cac  jmp 0x000079F4D2DD2C05
000079f4d2dd4cb1  call 0x000079F4D2BFF430
000079f4d2dd4cb6  jmp 0x000079F4D2DD2C12
000079f4d2dd4cbb  sub rsp, 0x08
000079f4d2dd4cbf  push rax
000079f4d2dd4cc0  push rcx
000079f4d2dd4cc1  push rdx
000079f4d2dd4cc2  push rdi
000079f4d2dd4cc3  push rsi
000079f4d2dd4cc4  push r8
000079f4d2dd4cc6  push r9
000079f4d2dd4cc8  push r10
000079f4d2dd4cca  push r11
000079f4d2dd4ccc  sub rsp, 0xF0
000079f4d2dd4cd3  vmovaps [rsp], xmm0
000079f4d2dd4cd8  vmovaps [rsp+0x10], xmm1
000079f4d2dd4cde  vmovaps [rsp+0x20], xmm2
000079f4d2dd4ce4  vmovaps [rsp+0x30], xmm3
000079f4d2dd4cea  vmovaps [rsp+0x40], xmm4
000079f4d2dd4cf0  vmovaps [rsp+0x50], xmm5
000079f4d2dd4cf6  vmovaps [rsp+0x60], xmm6
000079f4d2dd4cfc  vmovaps [rsp+0x70], xmm7
000079f4d2dd4d02  vmovaps [rsp+0x80], xmm8
000079f4d2dd4d0b  vmovaps [rsp+0x90], xmm9
000079f4d2dd4d14  vmovaps [rsp+0xA0], xmm10
000079f4d2dd4d1d  vmovaps [rsp+0xB0], xmm11
000079f4d2dd4d26  vmovaps [rsp+0xC0], xmm12
000079f4d2dd4d2f  vmovaps [rsp+0xD0], xmm14
000079f4d2dd4d38  vmovaps [rsp+0xE0], xmm15
000079f4d2dd4d41  sub rsp, 0x30
000079f4d2dd4d45  movaps [rsp], xmm13
000079f4d2dd4d4a  movaps [rsp+0x10], xmm1
000079f4d2dd4d4f  movaps [rsp+0x20], xmm15
000079f4d2dd4d55  lea rdi, [rsp]
000079f4d2dd4d59  mov esi, 0x00
000079f4d2dd4d5e  mov rax, 0x5D9EC01E8530
000079f4d2dd4d68  call rax
000079f4d2dd4d6a  movaps xmm13, [rsp]
000079f4d2dd4d6f  add rsp, 0x30
000079f4d2dd4d73  vmovaps xmm0, [rsp]
000079f4d2dd4d78  vmovaps xmm1, [rsp+0x10]
000079f4d2dd4d7e  vmovaps xmm2, [rsp+0x20]
000079f4d2dd4d84  vmovaps xmm3, [rsp+0x30]
000079f4d2dd4d8a  vmovaps xmm4, [rsp+0x40]
000079f4d2dd4d90  vmovaps xmm5, [rsp+0x50]
000079f4d2dd4d96  vmovaps xmm6, [rsp+0x60]
000079f4d2dd4d9c  vmovaps xmm7, [rsp+0x70]
000079f4d2dd4da2  vmovaps xmm8, [rsp+0x80]
000079f4d2dd4dab  vmovaps xmm9, [rsp+0x90]
000079f4d2dd4db4  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd4dbd  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd4dc6  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd4dcf  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd4dd8  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd4de1  add rsp, 0xF0
000079f4d2dd4de8  pop r11
000079f4d2dd4dea  pop r10
000079f4d2dd4dec  pop r9
000079f4d2dd4dee  pop r8
000079f4d2dd4df0  pop rsi
000079f4d2dd4df1  pop rdi
000079f4d2dd4df2  pop rdx
000079f4d2dd4df3  pop rcx
000079f4d2dd4df4  pop rax
000079f4d2dd4df5  add rsp, 0x08
000079f4d2dd4df9  jmp 0x000079F4D2DD2CD6
000079f4d2dd4dfe  sub rsp, 0x08
000079f4d2dd4e02  push rax
000079f4d2dd4e03  push rcx
000079f4d2dd4e04  push rdx
000079f4d2dd4e05  push rdi
000079f4d2dd4e06  push rsi
000079f4d2dd4e07  push r8
000079f4d2dd4e09  push r9
000079f4d2dd4e0b  push r10
000079f4d2dd4e0d  push r11
000079f4d2dd4e0f  sub rsp, 0xF0
000079f4d2dd4e16  vmovaps [rsp], xmm0
000079f4d2dd4e1b  vmovaps [rsp+0x10], xmm1
000079f4d2dd4e21  vmovaps [rsp+0x20], xmm2
000079f4d2dd4e27  vmovaps [rsp+0x30], xmm3
000079f4d2dd4e2d  vmovaps [rsp+0x40], xmm4
000079f4d2dd4e33  vmovaps [rsp+0x50], xmm5
000079f4d2dd4e39  vmovaps [rsp+0x60], xmm6
000079f4d2dd4e3f  vmovaps [rsp+0x70], xmm7
000079f4d2dd4e45  vmovaps [rsp+0x80], xmm8
000079f4d2dd4e4e  vmovaps [rsp+0x90], xmm9
000079f4d2dd4e57  vmovaps [rsp+0xA0], xmm10
000079f4d2dd4e60  vmovaps [rsp+0xB0], xmm11
000079f4d2dd4e69  vmovaps [rsp+0xC0], xmm12
000079f4d2dd4e72  vmovaps [rsp+0xD0], xmm13
000079f4d2dd4e7b  vmovaps [rsp+0xE0], xmm14
000079f4d2dd4e84  sub rsp, 0x30
000079f4d2dd4e88  movaps [rsp], xmm15
000079f4d2dd4e8d  movaps [rsp+0x10], xmm14
000079f4d2dd4e93  movaps [rsp+0x20], xmm1
000079f4d2dd4e98  lea rdi, [rsp]
000079f4d2dd4e9c  mov esi, 0x00
000079f4d2dd4ea1  mov rax, 0x5D9EC01E8530
000079f4d2dd4eab  call rax
000079f4d2dd4ead  movaps xmm15, [rsp]
000079f4d2dd4eb2  add rsp, 0x30
000079f4d2dd4eb6  vmovaps xmm0, [rsp]
000079f4d2dd4ebb  vmovaps xmm1, [rsp+0x10]
000079f4d2dd4ec1  vmovaps xmm2, [rsp+0x20]
000079f4d2dd4ec7  vmovaps xmm3, [rsp+0x30]
000079f4d2dd4ecd  vmovaps xmm4, [rsp+0x40]
000079f4d2dd4ed3  vmovaps xmm5, [rsp+0x50]
000079f4d2dd4ed9  vmovaps xmm6, [rsp+0x60]
000079f4d2dd4edf  vmovaps xmm7, [rsp+0x70]
000079f4d2dd4ee5  vmovaps xmm8, [rsp+0x80]
000079f4d2dd4eee  vmovaps xmm9, [rsp+0x90]
000079f4d2dd4ef7  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd4f00  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd4f09  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd4f12  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd4f1b  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd4f24  add rsp, 0xF0
000079f4d2dd4f2b  pop r11
000079f4d2dd4f2d  pop r10
000079f4d2dd4f2f  pop r9
000079f4d2dd4f31  pop r8
000079f4d2dd4f33  pop rsi
000079f4d2dd4f34  pop rdi
000079f4d2dd4f35  pop rdx
000079f4d2dd4f36  pop rcx
000079f4d2dd4f37  pop rax
000079f4d2dd4f38  add rsp, 0x08
000079f4d2dd4f3c  jmp 0x000079F4D2DD2D12
000079f4d2dd4f41  call 0x000079F4D2BFF430
000079f4d2dd4f46  jmp 0x000079F4D2DD2D1F
000079f4d2dd4f4b  sub rsp, 0x08
000079f4d2dd4f4f  push rax
000079f4d2dd4f50  push rcx
000079f4d2dd4f51  push rdx
000079f4d2dd4f52  push rdi
000079f4d2dd4f53  push rsi
000079f4d2dd4f54  push r8
000079f4d2dd4f56  push r9
000079f4d2dd4f58  push r10
000079f4d2dd4f5a  push r11
000079f4d2dd4f5c  sub rsp, 0xF0
000079f4d2dd4f63  vmovaps [rsp], xmm0
000079f4d2dd4f68  vmovaps [rsp+0x10], xmm1
000079f4d2dd4f6e  vmovaps [rsp+0x20], xmm2
000079f4d2dd4f74  vmovaps [rsp+0x30], xmm3
000079f4d2dd4f7a  vmovaps [rsp+0x40], xmm4
000079f4d2dd4f80  vmovaps [rsp+0x50], xmm5
000079f4d2dd4f86  vmovaps [rsp+0x60], xmm6
000079f4d2dd4f8c  vmovaps [rsp+0x70], xmm7
000079f4d2dd4f92  vmovaps [rsp+0x80], xmm8
000079f4d2dd4f9b  vmovaps [rsp+0x90], xmm9
000079f4d2dd4fa4  vmovaps [rsp+0xA0], xmm10
000079f4d2dd4fad  vmovaps [rsp+0xB0], xmm11
000079f4d2dd4fb6  vmovaps [rsp+0xC0], xmm12
000079f4d2dd4fbf  vmovaps [rsp+0xD0], xmm13
000079f4d2dd4fc8  vmovaps [rsp+0xE0], xmm15
000079f4d2dd4fd1  sub rsp, 0x30
000079f4d2dd4fd5  movaps [rsp], xmm14
000079f4d2dd4fda  movaps [rsp+0x10], xmm13
000079f4d2dd4fe0  movaps [rsp+0x20], xmm2
000079f4d2dd4fe5  lea rdi, [rsp]
000079f4d2dd4fe9  mov esi, 0x00
000079f4d2dd4fee  mov rax, 0x5D9EC01E8530
000079f4d2dd4ff8  call rax
000079f4d2dd4ffa  movaps xmm14, [rsp]
000079f4d2dd4fff  add rsp, 0x30
000079f4d2dd5003  vmovaps xmm0, [rsp]
000079f4d2dd5008  vmovaps xmm1, [rsp+0x10]
000079f4d2dd500e  vmovaps xmm2, [rsp+0x20]
000079f4d2dd5014  vmovaps xmm3, [rsp+0x30]
000079f4d2dd501a  vmovaps xmm4, [rsp+0x40]
000079f4d2dd5020  vmovaps xmm5, [rsp+0x50]
000079f4d2dd5026  vmovaps xmm6, [rsp+0x60]
000079f4d2dd502c  vmovaps xmm7, [rsp+0x70]
000079f4d2dd5032  vmovaps xmm8, [rsp+0x80]
000079f4d2dd503b  vmovaps xmm9, [rsp+0x90]
000079f4d2dd5044  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd504d  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd5056  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd505f  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd5068  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd5071  add rsp, 0xF0
000079f4d2dd5078  pop r11
000079f4d2dd507a  pop r10
000079f4d2dd507c  pop r9
000079f4d2dd507e  pop r8
000079f4d2dd5080  pop rsi
000079f4d2dd5081  pop rdi
000079f4d2dd5082  pop rdx
000079f4d2dd5083  pop rcx
000079f4d2dd5084  pop rax
000079f4d2dd5085  add rsp, 0x08
000079f4d2dd5089  jmp 0x000079F4D2DD2D4B
000079f4d2dd508e  sub rsp, 0x08
000079f4d2dd5092  push rax
000079f4d2dd5093  push rcx
000079f4d2dd5094  push rdx
000079f4d2dd5095  push rdi
000079f4d2dd5096  push rsi
000079f4d2dd5097  push r8
000079f4d2dd5099  push r9
000079f4d2dd509b  push r10
000079f4d2dd509d  push r11
000079f4d2dd509f  sub rsp, 0xF0
000079f4d2dd50a6  vmovaps [rsp], xmm0
000079f4d2dd50ab  vmovaps [rsp+0x10], xmm2
000079f4d2dd50b1  vmovaps [rsp+0x20], xmm3
000079f4d2dd50b7  vmovaps [rsp+0x30], xmm4
000079f4d2dd50bd  vmovaps [rsp+0x40], xmm5
000079f4d2dd50c3  vmovaps [rsp+0x50], xmm6
000079f4d2dd50c9  vmovaps [rsp+0x60], xmm7
000079f4d2dd50cf  vmovaps [rsp+0x70], xmm8
000079f4d2dd50d5  vmovaps [rsp+0x80], xmm9
000079f4d2dd50de  vmovaps [rsp+0x90], xmm10
000079f4d2dd50e7  vmovaps [rsp+0xA0], xmm11
000079f4d2dd50f0  vmovaps [rsp+0xB0], xmm12
000079f4d2dd50f9  vmovaps [rsp+0xC0], xmm13
000079f4d2dd5102  vmovaps [rsp+0xD0], xmm14
000079f4d2dd510b  vmovaps [rsp+0xE0], xmm15
000079f4d2dd5114  sub rsp, 0x30
000079f4d2dd5118  movaps [rsp], xmm1
000079f4d2dd511c  movaps [rsp+0x10], xmm13
000079f4d2dd5122  movaps [rsp+0x20], xmm2
000079f4d2dd5127  lea rdi, [rsp]
000079f4d2dd512b  mov esi, 0x00
000079f4d2dd5130  mov rax, 0x5D9EC01E8530
000079f4d2dd513a  call rax
000079f4d2dd513c  movaps xmm1, [rsp]
000079f4d2dd5140  add rsp, 0x30
000079f4d2dd5144  vmovaps xmm0, [rsp]
000079f4d2dd5149  vmovaps xmm2, [rsp+0x10]
000079f4d2dd514f  vmovaps xmm3, [rsp+0x20]
000079f4d2dd5155  vmovaps xmm4, [rsp+0x30]
000079f4d2dd515b  vmovaps xmm5, [rsp+0x40]
000079f4d2dd5161  vmovaps xmm6, [rsp+0x50]
000079f4d2dd5167  vmovaps xmm7, [rsp+0x60]
000079f4d2dd516d  vmovaps xmm8, [rsp+0x70]
000079f4d2dd5173  vmovaps xmm9, [rsp+0x80]
000079f4d2dd517c  vmovaps xmm10, [rsp+0x90]
000079f4d2dd5185  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd518e  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd5197  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd51a0  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd51a9  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd51b2  add rsp, 0xF0
000079f4d2dd51b9  pop r11
000079f4d2dd51bb  pop r10
000079f4d2dd51bd  pop r9
000079f4d2dd51bf  pop r8
000079f4d2dd51c1  pop rsi
000079f4d2dd51c2  pop rdi
000079f4d2dd51c3  pop rdx
000079f4d2dd51c4  pop rcx
000079f4d2dd51c5  pop rax
000079f4d2dd51c6  add rsp, 0x08
000079f4d2dd51ca  jmp 0x000079F4D2DD2D79
000079f4d2dd51cf  sub rsp, 0x08
000079f4d2dd51d3  push rax
000079f4d2dd51d4  push rcx
000079f4d2dd51d5  push rdx
000079f4d2dd51d6  push rdi
000079f4d2dd51d7  push rsi
000079f4d2dd51d8  push r8
000079f4d2dd51da  push r9
000079f4d2dd51dc  push r10
000079f4d2dd51de  push r11
000079f4d2dd51e0  sub rsp, 0xF0
000079f4d2dd51e7  vmovaps [rsp], xmm0
000079f4d2dd51ec  vmovaps [rsp+0x10], xmm1
000079f4d2dd51f2  vmovaps [rsp+0x20], xmm3
000079f4d2dd51f8  vmovaps [rsp+0x30], xmm4
000079f4d2dd51fe  vmovaps [rsp+0x40], xmm5
000079f4d2dd5204  vmovaps [rsp+0x50], xmm6
000079f4d2dd520a  vmovaps [rsp+0x60], xmm7
000079f4d2dd5210  vmovaps [rsp+0x70], xmm8
000079f4d2dd5216  vmovaps [rsp+0x80], xmm9
000079f4d2dd521f  vmovaps [rsp+0x90], xmm10
000079f4d2dd5228  vmovaps [rsp+0xA0], xmm11
000079f4d2dd5231  vmovaps [rsp+0xB0], xmm12
000079f4d2dd523a  vmovaps [rsp+0xC0], xmm13
000079f4d2dd5243  vmovaps [rsp+0xD0], xmm14
000079f4d2dd524c  vmovaps [rsp+0xE0], xmm15
000079f4d2dd5255  sub rsp, 0x30
000079f4d2dd5259  movaps [rsp], xmm2
000079f4d2dd525d  movaps [rsp+0x10], xmm1
000079f4d2dd5262  movaps [rsp+0x20], xmm13
000079f4d2dd5268  lea rdi, [rsp]
000079f4d2dd526c  mov esi, 0x00
000079f4d2dd5271  mov rax, 0x5D9EC01E8530
000079f4d2dd527b  call rax
000079f4d2dd527d  movaps xmm2, [rsp]
000079f4d2dd5281  add rsp, 0x30
000079f4d2dd5285  vmovaps xmm0, [rsp]
000079f4d2dd528a  vmovaps xmm1, [rsp+0x10]
000079f4d2dd5290  vmovaps xmm3, [rsp+0x20]
000079f4d2dd5296  vmovaps xmm4, [rsp+0x30]
000079f4d2dd529c  vmovaps xmm5, [rsp+0x40]
000079f4d2dd52a2  vmovaps xmm6, [rsp+0x50]
000079f4d2dd52a8  vmovaps xmm7, [rsp+0x60]
000079f4d2dd52ae  vmovaps xmm8, [rsp+0x70]
000079f4d2dd52b4  vmovaps xmm9, [rsp+0x80]
000079f4d2dd52bd  vmovaps xmm10, [rsp+0x90]
000079f4d2dd52c6  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd52cf  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd52d8  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd52e1  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd52ea  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd52f3  add rsp, 0xF0
000079f4d2dd52fa  pop r11
000079f4d2dd52fc  pop r10
000079f4d2dd52fe  pop r9
000079f4d2dd5300  pop r8
000079f4d2dd5302  pop rsi
000079f4d2dd5303  pop rdi
000079f4d2dd5304  pop rdx
000079f4d2dd5305  pop rcx
000079f4d2dd5306  pop rax
000079f4d2dd5307  add rsp, 0x08
000079f4d2dd530b  jmp 0x000079F4D2DD2DD2
000079f4d2dd5310  call 0x000079F4D2BFF430
000079f4d2dd5315  jmp 0x000079F4D2DD2DDF
000079f4d2dd531a  sub rsp, 0x08
000079f4d2dd531e  push rax
000079f4d2dd531f  push rcx
000079f4d2dd5320  push rdx
000079f4d2dd5321  push rdi
000079f4d2dd5322  push rsi
000079f4d2dd5323  push r8
000079f4d2dd5325  push r9
000079f4d2dd5327  push r10
000079f4d2dd5329  push r11
000079f4d2dd532b  sub rsp, 0xF0
000079f4d2dd5332  vmovaps [rsp], xmm0
000079f4d2dd5337  vmovaps [rsp+0x10], xmm1
000079f4d2dd533d  vmovaps [rsp+0x20], xmm2
000079f4d2dd5343  vmovaps [rsp+0x30], xmm3
000079f4d2dd5349  vmovaps [rsp+0x40], xmm4
000079f4d2dd534f  vmovaps [rsp+0x50], xmm5
000079f4d2dd5355  vmovaps [rsp+0x60], xmm6
000079f4d2dd535b  vmovaps [rsp+0x70], xmm7
000079f4d2dd5361  vmovaps [rsp+0x80], xmm8
000079f4d2dd536a  vmovaps [rsp+0x90], xmm9
000079f4d2dd5373  vmovaps [rsp+0xA0], xmm10
000079f4d2dd537c  vmovaps [rsp+0xB0], xmm11
000079f4d2dd5385  vmovaps [rsp+0xC0], xmm12
000079f4d2dd538e  vmovaps [rsp+0xD0], xmm13
000079f4d2dd5397  vmovaps [rsp+0xE0], xmm14
000079f4d2dd53a0  sub rsp, 0x30
000079f4d2dd53a4  movaps [rsp], xmm15
000079f4d2dd53a9  movaps [rsp+0x10], xmm13
000079f4d2dd53af  movaps [rsp+0x20], xmm1
000079f4d2dd53b4  lea rdi, [rsp]
000079f4d2dd53b8  mov esi, 0x00
000079f4d2dd53bd  mov rax, 0x5D9EC01E8530
000079f4d2dd53c7  call rax
000079f4d2dd53c9  movaps xmm15, [rsp]
000079f4d2dd53ce  add rsp, 0x30
000079f4d2dd53d2  vmovaps xmm0, [rsp]
000079f4d2dd53d7  vmovaps xmm1, [rsp+0x10]
000079f4d2dd53dd  vmovaps xmm2, [rsp+0x20]
000079f4d2dd53e3  vmovaps xmm3, [rsp+0x30]
000079f4d2dd53e9  vmovaps xmm4, [rsp+0x40]
000079f4d2dd53ef  vmovaps xmm5, [rsp+0x50]
000079f4d2dd53f5  vmovaps xmm6, [rsp+0x60]
000079f4d2dd53fb  vmovaps xmm7, [rsp+0x70]
000079f4d2dd5401  vmovaps xmm8, [rsp+0x80]
000079f4d2dd540a  vmovaps xmm9, [rsp+0x90]
000079f4d2dd5413  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd541c  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd5425  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd542e  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd5437  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd5440  add rsp, 0xF0
000079f4d2dd5447  pop r11
000079f4d2dd5449  pop r10
000079f4d2dd544b  pop r9
000079f4d2dd544d  pop r8
000079f4d2dd544f  pop rsi
000079f4d2dd5450  pop rdi
000079f4d2dd5451  pop rdx
000079f4d2dd5452  pop rcx
000079f4d2dd5453  pop rax
000079f4d2dd5454  add rsp, 0x08
000079f4d2dd5458  jmp 0x000079F4D2DD2E1E
000079f4d2dd545d  sub rsp, 0x08
000079f4d2dd5461  push rax
000079f4d2dd5462  push rcx
000079f4d2dd5463  push rdx
000079f4d2dd5464  push rdi
000079f4d2dd5465  push rsi
000079f4d2dd5466  push r8
000079f4d2dd5468  push r9
000079f4d2dd546a  push r10
000079f4d2dd546c  push r11
000079f4d2dd546e  sub rsp, 0xF0
000079f4d2dd5475  vmovaps [rsp], xmm0
000079f4d2dd547a  vmovaps [rsp+0x10], xmm1
000079f4d2dd5480  vmovaps [rsp+0x20], xmm2
000079f4d2dd5486  vmovaps [rsp+0x30], xmm3
000079f4d2dd548c  vmovaps [rsp+0x40], xmm4
000079f4d2dd5492  vmovaps [rsp+0x50], xmm5
000079f4d2dd5498  vmovaps [rsp+0x60], xmm6
000079f4d2dd549e  vmovaps [rsp+0x70], xmm7
000079f4d2dd54a4  vmovaps [rsp+0x80], xmm8
000079f4d2dd54ad  vmovaps [rsp+0x90], xmm9
000079f4d2dd54b6  vmovaps [rsp+0xA0], xmm10
000079f4d2dd54bf  vmovaps [rsp+0xB0], xmm11
000079f4d2dd54c8  vmovaps [rsp+0xC0], xmm12
000079f4d2dd54d1  vmovaps [rsp+0xD0], xmm13
000079f4d2dd54da  vmovaps [rsp+0xE0], xmm15
000079f4d2dd54e3  sub rsp, 0x30
000079f4d2dd54e7  movaps [rsp], xmm14
000079f4d2dd54ec  movaps [rsp+0x10], xmm11
000079f4d2dd54f2  movaps [rsp+0x20], xmm1
000079f4d2dd54f7  lea rdi, [rsp]
000079f4d2dd54fb  mov esi, 0x00
000079f4d2dd5500  mov rax, 0x5D9EC01E8530
000079f4d2dd550a  call rax
000079f4d2dd550c  movaps xmm14, [rsp]
000079f4d2dd5511  add rsp, 0x30
000079f4d2dd5515  vmovaps xmm0, [rsp]
000079f4d2dd551a  vmovaps xmm1, [rsp+0x10]
000079f4d2dd5520  vmovaps xmm2, [rsp+0x20]
000079f4d2dd5526  vmovaps xmm3, [rsp+0x30]
000079f4d2dd552c  vmovaps xmm4, [rsp+0x40]
000079f4d2dd5532  vmovaps xmm5, [rsp+0x50]
000079f4d2dd5538  vmovaps xmm6, [rsp+0x60]
000079f4d2dd553e  vmovaps xmm7, [rsp+0x70]
000079f4d2dd5544  vmovaps xmm8, [rsp+0x80]
000079f4d2dd554d  vmovaps xmm9, [rsp+0x90]
000079f4d2dd5556  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd555f  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd5568  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd5571  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd557a  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd5583  add rsp, 0xF0
000079f4d2dd558a  pop r11
000079f4d2dd558c  pop r10
000079f4d2dd558e  pop r9
000079f4d2dd5590  pop r8
000079f4d2dd5592  pop rsi
000079f4d2dd5593  pop rdi
000079f4d2dd5594  pop rdx
000079f4d2dd5595  pop rcx
000079f4d2dd5596  pop rax
000079f4d2dd5597  add rsp, 0x08
000079f4d2dd559b  jmp 0x000079F4D2DD2E48
000079f4d2dd55a0  sub rsp, 0x08
000079f4d2dd55a4  push rax
000079f4d2dd55a5  push rcx
000079f4d2dd55a6  push rdx
000079f4d2dd55a7  push rdi
000079f4d2dd55a8  push rsi
000079f4d2dd55a9  push r8
000079f4d2dd55ab  push r9
000079f4d2dd55ad  push r10
000079f4d2dd55af  push r11
000079f4d2dd55b1  sub rsp, 0xF0
000079f4d2dd55b8  vmovaps [rsp], xmm0
000079f4d2dd55bd  vmovaps [rsp+0x10], xmm1
000079f4d2dd55c3  vmovaps [rsp+0x20], xmm2
000079f4d2dd55c9  vmovaps [rsp+0x30], xmm3
000079f4d2dd55cf  vmovaps [rsp+0x40], xmm4
000079f4d2dd55d5  vmovaps [rsp+0x50], xmm5
000079f4d2dd55db  vmovaps [rsp+0x60], xmm6
000079f4d2dd55e1  vmovaps [rsp+0x70], xmm7
000079f4d2dd55e7  vmovaps [rsp+0x80], xmm8
000079f4d2dd55f0  vmovaps [rsp+0x90], xmm9
000079f4d2dd55f9  vmovaps [rsp+0xA0], xmm10
000079f4d2dd5602  vmovaps [rsp+0xB0], xmm11
000079f4d2dd560b  vmovaps [rsp+0xC0], xmm12
000079f4d2dd5614  vmovaps [rsp+0xD0], xmm14
000079f4d2dd561d  vmovaps [rsp+0xE0], xmm15
000079f4d2dd5626  sub rsp, 0x30
000079f4d2dd562a  movaps [rsp], xmm13
000079f4d2dd562f  movaps [rsp+0x10], xmm11
000079f4d2dd5635  movaps [rsp+0x20], xmm1
000079f4d2dd563a  lea rdi, [rsp]
000079f4d2dd563e  mov esi, 0x00
000079f4d2dd5643  mov rax, 0x5D9EC01E8530
000079f4d2dd564d  call rax
000079f4d2dd564f  movaps xmm13, [rsp]
000079f4d2dd5654  add rsp, 0x30
000079f4d2dd5658  vmovaps xmm0, [rsp]
000079f4d2dd565d  vmovaps xmm1, [rsp+0x10]
000079f4d2dd5663  vmovaps xmm2, [rsp+0x20]
000079f4d2dd5669  vmovaps xmm3, [rsp+0x30]
000079f4d2dd566f  vmovaps xmm4, [rsp+0x40]
000079f4d2dd5675  vmovaps xmm5, [rsp+0x50]
000079f4d2dd567b  vmovaps xmm6, [rsp+0x60]
000079f4d2dd5681  vmovaps xmm7, [rsp+0x70]
000079f4d2dd5687  vmovaps xmm8, [rsp+0x80]
000079f4d2dd5690  vmovaps xmm9, [rsp+0x90]
000079f4d2dd5699  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd56a2  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd56ab  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd56b4  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd56bd  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd56c6  add rsp, 0xF0
000079f4d2dd56cd  pop r11
000079f4d2dd56cf  pop r10
000079f4d2dd56d1  pop r9
000079f4d2dd56d3  pop r8
000079f4d2dd56d5  pop rsi
000079f4d2dd56d6  pop rdi
000079f4d2dd56d7  pop rdx
000079f4d2dd56d8  pop rcx
000079f4d2dd56d9  pop rax
000079f4d2dd56da  add rsp, 0x08
000079f4d2dd56de  jmp 0x000079F4D2DD2E9D
000079f4d2dd56e3  call 0x000079F4D2BFF430
000079f4d2dd56e8  jmp 0x000079F4D2DD2EAA
000079f4d2dd56ed  sub rsp, 0x08
000079f4d2dd56f1  push rax
000079f4d2dd56f2  push rcx
000079f4d2dd56f3  push rdx
000079f4d2dd56f4  push rdi
000079f4d2dd56f5  push rsi
000079f4d2dd56f6  push r8
000079f4d2dd56f8  push r9
000079f4d2dd56fa  push r10
000079f4d2dd56fc  push r11
000079f4d2dd56fe  sub rsp, 0xF0
000079f4d2dd5705  vmovaps [rsp], xmm0
000079f4d2dd570a  vmovaps [rsp+0x10], xmm1
000079f4d2dd5710  vmovaps [rsp+0x20], xmm2
000079f4d2dd5716  vmovaps [rsp+0x30], xmm3
000079f4d2dd571c  vmovaps [rsp+0x40], xmm4
000079f4d2dd5722  vmovaps [rsp+0x50], xmm5
000079f4d2dd5728  vmovaps [rsp+0x60], xmm6
000079f4d2dd572e  vmovaps [rsp+0x70], xmm7
000079f4d2dd5734  vmovaps [rsp+0x80], xmm8
000079f4d2dd573d  vmovaps [rsp+0x90], xmm9
000079f4d2dd5746  vmovaps [rsp+0xA0], xmm10
000079f4d2dd574f  vmovaps [rsp+0xB0], xmm11
000079f4d2dd5758  vmovaps [rsp+0xC0], xmm12
000079f4d2dd5761  vmovaps [rsp+0xD0], xmm13
000079f4d2dd576a  vmovaps [rsp+0xE0], xmm14
000079f4d2dd5773  sub rsp, 0x30
000079f4d2dd5777  movaps [rsp], xmm15
000079f4d2dd577c  movaps [rsp+0x10], xmm11
000079f4d2dd5782  movaps [rsp+0x20], xmm1
000079f4d2dd5787  lea rdi, [rsp]
000079f4d2dd578b  mov esi, 0x00
000079f4d2dd5790  mov rax, 0x5D9EC01E8530
000079f4d2dd579a  call rax
000079f4d2dd579c  movaps xmm15, [rsp]
000079f4d2dd57a1  add rsp, 0x30
000079f4d2dd57a5  vmovaps xmm0, [rsp]
000079f4d2dd57aa  vmovaps xmm1, [rsp+0x10]
000079f4d2dd57b0  vmovaps xmm2, [rsp+0x20]
000079f4d2dd57b6  vmovaps xmm3, [rsp+0x30]
000079f4d2dd57bc  vmovaps xmm4, [rsp+0x40]
000079f4d2dd57c2  vmovaps xmm5, [rsp+0x50]
000079f4d2dd57c8  vmovaps xmm6, [rsp+0x60]
000079f4d2dd57ce  vmovaps xmm7, [rsp+0x70]
000079f4d2dd57d4  vmovaps xmm8, [rsp+0x80]
000079f4d2dd57dd  vmovaps xmm9, [rsp+0x90]
000079f4d2dd57e6  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd57ef  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd57f8  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd5801  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd580a  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd5813  add rsp, 0xF0
000079f4d2dd581a  pop r11
000079f4d2dd581c  pop r10
000079f4d2dd581e  pop r9
000079f4d2dd5820  pop r8
000079f4d2dd5822  pop rsi
000079f4d2dd5823  pop rdi
000079f4d2dd5824  pop rdx
000079f4d2dd5825  pop rcx
000079f4d2dd5826  pop rax
000079f4d2dd5827  add rsp, 0x08
000079f4d2dd582b  jmp 0x000079F4D2DD2EE3
000079f4d2dd5830  sub rsp, 0x08
000079f4d2dd5834  push rax
000079f4d2dd5835  push rcx
000079f4d2dd5836  push rdx
000079f4d2dd5837  push rdi
000079f4d2dd5838  push rsi
000079f4d2dd5839  push r8
000079f4d2dd583b  push r9
000079f4d2dd583d  push r10
000079f4d2dd583f  push r11
000079f4d2dd5841  sub rsp, 0xF0
000079f4d2dd5848  vmovaps [rsp], xmm0
000079f4d2dd584d  vmovaps [rsp+0x10], xmm1
000079f4d2dd5853  vmovaps [rsp+0x20], xmm2
000079f4d2dd5859  vmovaps [rsp+0x30], xmm3
000079f4d2dd585f  vmovaps [rsp+0x40], xmm4
000079f4d2dd5865  vmovaps [rsp+0x50], xmm5
000079f4d2dd586b  vmovaps [rsp+0x60], xmm6
000079f4d2dd5871  vmovaps [rsp+0x70], xmm7
000079f4d2dd5877  vmovaps [rsp+0x80], xmm8
000079f4d2dd5880  vmovaps [rsp+0x90], xmm9
000079f4d2dd5889  vmovaps [rsp+0xA0], xmm10
000079f4d2dd5892  vmovaps [rsp+0xB0], xmm12
000079f4d2dd589b  vmovaps [rsp+0xC0], xmm13
000079f4d2dd58a4  vmovaps [rsp+0xD0], xmm14
000079f4d2dd58ad  vmovaps [rsp+0xE0], xmm15
000079f4d2dd58b6  sub rsp, 0x30
000079f4d2dd58ba  movaps [rsp], xmm11
000079f4d2dd58bf  movaps [rsp+0x10], xmm6
000079f4d2dd58c4  movaps [rsp+0x20], xmm14
000079f4d2dd58ca  lea rdi, [rsp]
000079f4d2dd58ce  mov esi, 0x00
000079f4d2dd58d3  mov rax, 0x5D9EC01E8530
000079f4d2dd58dd  call rax
000079f4d2dd58df  movaps xmm11, [rsp]
000079f4d2dd58e4  add rsp, 0x30
000079f4d2dd58e8  vmovaps xmm0, [rsp]
000079f4d2dd58ed  vmovaps xmm1, [rsp+0x10]
000079f4d2dd58f3  vmovaps xmm2, [rsp+0x20]
000079f4d2dd58f9  vmovaps xmm3, [rsp+0x30]
000079f4d2dd58ff  vmovaps xmm4, [rsp+0x40]
000079f4d2dd5905  vmovaps xmm5, [rsp+0x50]
000079f4d2dd590b  vmovaps xmm6, [rsp+0x60]
000079f4d2dd5911  vmovaps xmm7, [rsp+0x70]
000079f4d2dd5917  vmovaps xmm8, [rsp+0x80]
000079f4d2dd5920  vmovaps xmm9, [rsp+0x90]
000079f4d2dd5929  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd5932  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd593b  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd5944  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd594d  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd5956  add rsp, 0xF0
000079f4d2dd595d  pop r11
000079f4d2dd595f  pop r10
000079f4d2dd5961  pop r9
000079f4d2dd5963  pop r8
000079f4d2dd5965  pop rsi
000079f4d2dd5966  pop rdi
000079f4d2dd5967  pop rdx
000079f4d2dd5968  pop rcx
000079f4d2dd5969  pop rax
000079f4d2dd596a  add rsp, 0x08
000079f4d2dd596e  jmp 0x000079F4D2DD2F5B
000079f4d2dd5973  call 0x000079F4D2BFF430
000079f4d2dd5978  jmp 0x000079F4D2DD2F65
000079f4d2dd597d  sub rsp, 0x08
000079f4d2dd5981  push rax
000079f4d2dd5982  push rcx
000079f4d2dd5983  push rdx
000079f4d2dd5984  push rdi
000079f4d2dd5985  push rsi
000079f4d2dd5986  push r8
000079f4d2dd5988  push r9
000079f4d2dd598a  push r10
000079f4d2dd598c  push r11
000079f4d2dd598e  sub rsp, 0xF0
000079f4d2dd5995  vmovaps [rsp], xmm0
000079f4d2dd599a  vmovaps [rsp+0x10], xmm1
000079f4d2dd59a0  vmovaps [rsp+0x20], xmm2
000079f4d2dd59a6  vmovaps [rsp+0x30], xmm3
000079f4d2dd59ac  vmovaps [rsp+0x40], xmm4
000079f4d2dd59b2  vmovaps [rsp+0x50], xmm5
000079f4d2dd59b8  vmovaps [rsp+0x60], xmm6
000079f4d2dd59be  vmovaps [rsp+0x70], xmm7
000079f4d2dd59c4  vmovaps [rsp+0x80], xmm8
000079f4d2dd59cd  vmovaps [rsp+0x90], xmm9
000079f4d2dd59d6  vmovaps [rsp+0xA0], xmm10
000079f4d2dd59df  vmovaps [rsp+0xB0], xmm11
000079f4d2dd59e8  vmovaps [rsp+0xC0], xmm12
000079f4d2dd59f1  vmovaps [rsp+0xD0], xmm13
000079f4d2dd59fa  vmovaps [rsp+0xE0], xmm15
000079f4d2dd5a03  sub rsp, 0x30
000079f4d2dd5a07  movaps [rsp], xmm14
000079f4d2dd5a0c  movaps [rsp+0x10], xmm6
000079f4d2dd5a11  movaps [rsp+0x20], xmm2
000079f4d2dd5a16  lea rdi, [rsp]
000079f4d2dd5a1a  mov esi, 0x00
000079f4d2dd5a1f  mov rax, 0x5D9EC01E8530
000079f4d2dd5a29  call rax
000079f4d2dd5a2b  movaps xmm14, [rsp]
000079f4d2dd5a30  add rsp, 0x30
000079f4d2dd5a34  vmovaps xmm0, [rsp]
000079f4d2dd5a39  vmovaps xmm1, [rsp+0x10]
000079f4d2dd5a3f  vmovaps xmm2, [rsp+0x20]
000079f4d2dd5a45  vmovaps xmm3, [rsp+0x30]
000079f4d2dd5a4b  vmovaps xmm4, [rsp+0x40]
000079f4d2dd5a51  vmovaps xmm5, [rsp+0x50]
000079f4d2dd5a57  vmovaps xmm6, [rsp+0x60]
000079f4d2dd5a5d  vmovaps xmm7, [rsp+0x70]
000079f4d2dd5a63  vmovaps xmm8, [rsp+0x80]
000079f4d2dd5a6c  vmovaps xmm9, [rsp+0x90]
000079f4d2dd5a75  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd5a7e  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd5a87  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd5a90  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd5a99  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd5aa2  add rsp, 0xF0
000079f4d2dd5aa9  pop r11
000079f4d2dd5aab  pop r10
000079f4d2dd5aad  pop r9
000079f4d2dd5aaf  pop r8
000079f4d2dd5ab1  pop rsi
000079f4d2dd5ab2  pop rdi
000079f4d2dd5ab3  pop rdx
000079f4d2dd5ab4  pop rcx
000079f4d2dd5ab5  pop rax
000079f4d2dd5ab6  add rsp, 0x08
000079f4d2dd5aba  jmp 0x000079F4D2DD2F99
000079f4d2dd5abf  sub rsp, 0x08
000079f4d2dd5ac3  push rax
000079f4d2dd5ac4  push rcx
000079f4d2dd5ac5  push rdx
000079f4d2dd5ac6  push rdi
000079f4d2dd5ac7  push rsi
000079f4d2dd5ac8  push r8
000079f4d2dd5aca  push r9
000079f4d2dd5acc  push r10
000079f4d2dd5ace  push r11
000079f4d2dd5ad0  sub rsp, 0xF0
000079f4d2dd5ad7  vmovaps [rsp], xmm0
000079f4d2dd5adc  vmovaps [rsp+0x10], xmm1
000079f4d2dd5ae2  vmovaps [rsp+0x20], xmm2
000079f4d2dd5ae8  vmovaps [rsp+0x30], xmm3
000079f4d2dd5aee  vmovaps [rsp+0x40], xmm4
000079f4d2dd5af4  vmovaps [rsp+0x50], xmm5
000079f4d2dd5afa  vmovaps [rsp+0x60], xmm7
000079f4d2dd5b00  vmovaps [rsp+0x70], xmm8
000079f4d2dd5b06  vmovaps [rsp+0x80], xmm9
000079f4d2dd5b0f  vmovaps [rsp+0x90], xmm10
000079f4d2dd5b18  vmovaps [rsp+0xA0], xmm11
000079f4d2dd5b21  vmovaps [rsp+0xB0], xmm12
000079f4d2dd5b2a  vmovaps [rsp+0xC0], xmm13
000079f4d2dd5b33  vmovaps [rsp+0xD0], xmm14
000079f4d2dd5b3c  vmovaps [rsp+0xE0], xmm15
000079f4d2dd5b45  sub rsp, 0x30
000079f4d2dd5b49  movaps [rsp], xmm6
000079f4d2dd5b4d  movaps [rsp+0x10], xmm5
000079f4d2dd5b52  movaps [rsp+0x20], xmm1
000079f4d2dd5b57  lea rdi, [rsp]
000079f4d2dd5b5b  mov esi, 0x00
000079f4d2dd5b60  mov rax, 0x5D9EC01E8530
000079f4d2dd5b6a  call rax
000079f4d2dd5b6c  movaps xmm6, [rsp]
000079f4d2dd5b70  add rsp, 0x30
000079f4d2dd5b74  vmovaps xmm0, [rsp]
000079f4d2dd5b79  vmovaps xmm1, [rsp+0x10]
000079f4d2dd5b7f  vmovaps xmm2, [rsp+0x20]
000079f4d2dd5b85  vmovaps xmm3, [rsp+0x30]
000079f4d2dd5b8b  vmovaps xmm4, [rsp+0x40]
000079f4d2dd5b91  vmovaps xmm5, [rsp+0x50]
000079f4d2dd5b97  vmovaps xmm7, [rsp+0x60]
000079f4d2dd5b9d  vmovaps xmm8, [rsp+0x70]
000079f4d2dd5ba3  vmovaps xmm9, [rsp+0x80]
000079f4d2dd5bac  vmovaps xmm10, [rsp+0x90]
000079f4d2dd5bb5  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd5bbe  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd5bc7  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd5bd0  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd5bd9  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd5be2  add rsp, 0xF0
000079f4d2dd5be9  pop r11
000079f4d2dd5beb  pop r10
000079f4d2dd5bed  pop r9
000079f4d2dd5bef  pop r8
000079f4d2dd5bf1  pop rsi
000079f4d2dd5bf2  pop rdi
000079f4d2dd5bf3  pop rdx
000079f4d2dd5bf4  pop rcx
000079f4d2dd5bf5  pop rax
000079f4d2dd5bf6  add rsp, 0x08
000079f4d2dd5bfa  jmp 0x000079F4D2DD2FBF
000079f4d2dd5bff  sub rsp, 0x08
000079f4d2dd5c03  push rax
000079f4d2dd5c04  push rcx
000079f4d2dd5c05  push rdx
000079f4d2dd5c06  push rdi
000079f4d2dd5c07  push rsi
000079f4d2dd5c08  push r8
000079f4d2dd5c0a  push r9
000079f4d2dd5c0c  push r10
000079f4d2dd5c0e  push r11
000079f4d2dd5c10  sub rsp, 0xF0
000079f4d2dd5c17  vmovaps [rsp], xmm0
000079f4d2dd5c1c  vmovaps [rsp+0x10], xmm2
000079f4d2dd5c22  vmovaps [rsp+0x20], xmm3
000079f4d2dd5c28  vmovaps [rsp+0x30], xmm4
000079f4d2dd5c2e  vmovaps [rsp+0x40], xmm5
000079f4d2dd5c34  vmovaps [rsp+0x50], xmm6
000079f4d2dd5c3a  vmovaps [rsp+0x60], xmm7
000079f4d2dd5c40  vmovaps [rsp+0x70], xmm8
000079f4d2dd5c46  vmovaps [rsp+0x80], xmm9
000079f4d2dd5c4f  vmovaps [rsp+0x90], xmm10
000079f4d2dd5c58  vmovaps [rsp+0xA0], xmm11
000079f4d2dd5c61  vmovaps [rsp+0xB0], xmm12
000079f4d2dd5c6a  vmovaps [rsp+0xC0], xmm13
000079f4d2dd5c73  vmovaps [rsp+0xD0], xmm14
000079f4d2dd5c7c  vmovaps [rsp+0xE0], xmm15
000079f4d2dd5c85  sub rsp, 0x30
000079f4d2dd5c89  movaps [rsp], xmm1
000079f4d2dd5c8d  movaps [rsp+0x10], xmm5
000079f4d2dd5c92  movaps [rsp+0x20], xmm13
000079f4d2dd5c98  lea rdi, [rsp]
000079f4d2dd5c9c  mov esi, 0x00
000079f4d2dd5ca1  mov rax, 0x5D9EC01E8530
000079f4d2dd5cab  call rax
000079f4d2dd5cad  movaps xmm1, [rsp]
000079f4d2dd5cb1  add rsp, 0x30
000079f4d2dd5cb5  vmovaps xmm0, [rsp]
000079f4d2dd5cba  vmovaps xmm2, [rsp+0x10]
000079f4d2dd5cc0  vmovaps xmm3, [rsp+0x20]
000079f4d2dd5cc6  vmovaps xmm4, [rsp+0x30]
000079f4d2dd5ccc  vmovaps xmm5, [rsp+0x40]
000079f4d2dd5cd2  vmovaps xmm6, [rsp+0x50]
000079f4d2dd5cd8  vmovaps xmm7, [rsp+0x60]
000079f4d2dd5cde  vmovaps xmm8, [rsp+0x70]
000079f4d2dd5ce4  vmovaps xmm9, [rsp+0x80]
000079f4d2dd5ced  vmovaps xmm10, [rsp+0x90]
000079f4d2dd5cf6  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd5cff  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd5d08  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd5d11  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd5d1a  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd5d23  add rsp, 0xF0
000079f4d2dd5d2a  pop r11
000079f4d2dd5d2c  pop r10
000079f4d2dd5d2e  pop r9
000079f4d2dd5d30  pop r8
000079f4d2dd5d32  pop rsi
000079f4d2dd5d33  pop rdi
000079f4d2dd5d34  pop rdx
000079f4d2dd5d35  pop rcx
000079f4d2dd5d36  pop rax
000079f4d2dd5d37  add rsp, 0x08
000079f4d2dd5d3b  jmp 0x000079F4D2DD2FDD
000079f4d2dd5d40  sub rsp, 0x08
000079f4d2dd5d44  push rax
000079f4d2dd5d45  push rcx
000079f4d2dd5d46  push rdx
000079f4d2dd5d47  push rdi
000079f4d2dd5d48  push rsi
000079f4d2dd5d49  push r8
000079f4d2dd5d4b  push r9
000079f4d2dd5d4d  push r10
000079f4d2dd5d4f  push r11
000079f4d2dd5d51  sub rsp, 0xF0
000079f4d2dd5d58  vmovaps [rsp], xmm0
000079f4d2dd5d5d  vmovaps [rsp+0x10], xmm1
000079f4d2dd5d63  vmovaps [rsp+0x20], xmm2
000079f4d2dd5d69  vmovaps [rsp+0x30], xmm3
000079f4d2dd5d6f  vmovaps [rsp+0x40], xmm4
000079f4d2dd5d75  vmovaps [rsp+0x50], xmm6
000079f4d2dd5d7b  vmovaps [rsp+0x60], xmm7
000079f4d2dd5d81  vmovaps [rsp+0x70], xmm8
000079f4d2dd5d87  vmovaps [rsp+0x80], xmm9
000079f4d2dd5d90  vmovaps [rsp+0x90], xmm10
000079f4d2dd5d99  vmovaps [rsp+0xA0], xmm11
000079f4d2dd5da2  vmovaps [rsp+0xB0], xmm12
000079f4d2dd5dab  vmovaps [rsp+0xC0], xmm13
000079f4d2dd5db4  vmovaps [rsp+0xD0], xmm14
000079f4d2dd5dbd  vmovaps [rsp+0xE0], xmm15
000079f4d2dd5dc6  sub rsp, 0x30
000079f4d2dd5dca  movaps [rsp], xmm5
000079f4d2dd5dce  movaps [rsp+0x10], xmm2
000079f4d2dd5dd3  movaps [rsp+0x20], xmm13
000079f4d2dd5dd9  lea rdi, [rsp]
000079f4d2dd5ddd  mov esi, 0x00
000079f4d2dd5de2  mov rax, 0x5D9EC01E8530
000079f4d2dd5dec  call rax
000079f4d2dd5dee  movaps xmm5, [rsp]
000079f4d2dd5df2  add rsp, 0x30
000079f4d2dd5df6  vmovaps xmm0, [rsp]
000079f4d2dd5dfb  vmovaps xmm1, [rsp+0x10]
000079f4d2dd5e01  vmovaps xmm2, [rsp+0x20]
000079f4d2dd5e07  vmovaps xmm3, [rsp+0x30]
000079f4d2dd5e0d  vmovaps xmm4, [rsp+0x40]
000079f4d2dd5e13  vmovaps xmm6, [rsp+0x50]
000079f4d2dd5e19  vmovaps xmm7, [rsp+0x60]
000079f4d2dd5e1f  vmovaps xmm8, [rsp+0x70]
000079f4d2dd5e25  vmovaps xmm9, [rsp+0x80]
000079f4d2dd5e2e  vmovaps xmm10, [rsp+0x90]
000079f4d2dd5e37  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd5e40  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd5e49  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd5e52  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd5e5b  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd5e64  add rsp, 0xF0
000079f4d2dd5e6b  pop r11
000079f4d2dd5e6d  pop r10
000079f4d2dd5e6f  pop r9
000079f4d2dd5e71  pop r8
000079f4d2dd5e73  pop rsi
000079f4d2dd5e74  pop rdi
000079f4d2dd5e75  pop rdx
000079f4d2dd5e76  pop rcx
000079f4d2dd5e77  pop rax
000079f4d2dd5e78  add rsp, 0x08
000079f4d2dd5e7c  jmp 0x000079F4D2DD3013
000079f4d2dd5e81  sub rsp, 0x08
000079f4d2dd5e85  push rax
000079f4d2dd5e86  push rcx
000079f4d2dd5e87  push rdx
000079f4d2dd5e88  push rdi
000079f4d2dd5e89  push rsi
000079f4d2dd5e8a  push r8
000079f4d2dd5e8c  push r9
000079f4d2dd5e8e  push r10
000079f4d2dd5e90  push r11
000079f4d2dd5e92  sub rsp, 0xF0
000079f4d2dd5e99  vmovaps [rsp], xmm0
000079f4d2dd5e9e  vmovaps [rsp+0x10], xmm1
000079f4d2dd5ea4  vmovaps [rsp+0x20], xmm2
000079f4d2dd5eaa  vmovaps [rsp+0x30], xmm3
000079f4d2dd5eb0  vmovaps [rsp+0x40], xmm4
000079f4d2dd5eb6  vmovaps [rsp+0x50], xmm5
000079f4d2dd5ebc  vmovaps [rsp+0x60], xmm6
000079f4d2dd5ec2  vmovaps [rsp+0x70], xmm7
000079f4d2dd5ec8  vmovaps [rsp+0x80], xmm8
000079f4d2dd5ed1  vmovaps [rsp+0x90], xmm9
000079f4d2dd5eda  vmovaps [rsp+0xA0], xmm10
000079f4d2dd5ee3  vmovaps [rsp+0xB0], xmm11
000079f4d2dd5eec  vmovaps [rsp+0xC0], xmm12
000079f4d2dd5ef5  vmovaps [rsp+0xD0], xmm14
000079f4d2dd5efe  vmovaps [rsp+0xE0], xmm15
000079f4d2dd5f07  sub rsp, 0x30
000079f4d2dd5f0b  movaps [rsp], xmm13
000079f4d2dd5f10  movaps [rsp+0x10], xmm10
000079f4d2dd5f16  movaps [rsp+0x20], xmm1
000079f4d2dd5f1b  lea rdi, [rsp]
000079f4d2dd5f1f  mov esi, 0x00
000079f4d2dd5f24  mov rax, 0x5D9EC01E8530
000079f4d2dd5f2e  call rax
000079f4d2dd5f30  movaps xmm13, [rsp]
000079f4d2dd5f35  add rsp, 0x30
000079f4d2dd5f39  vmovaps xmm0, [rsp]
000079f4d2dd5f3e  vmovaps xmm1, [rsp+0x10]
000079f4d2dd5f44  vmovaps xmm2, [rsp+0x20]
000079f4d2dd5f4a  vmovaps xmm3, [rsp+0x30]
000079f4d2dd5f50  vmovaps xmm4, [rsp+0x40]
000079f4d2dd5f56  vmovaps xmm5, [rsp+0x50]
000079f4d2dd5f5c  vmovaps xmm6, [rsp+0x60]
000079f4d2dd5f62  vmovaps xmm7, [rsp+0x70]
000079f4d2dd5f68  vmovaps xmm8, [rsp+0x80]
000079f4d2dd5f71  vmovaps xmm9, [rsp+0x90]
000079f4d2dd5f7a  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd5f83  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd5f8c  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd5f95  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd5f9e  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd5fa7  add rsp, 0xF0
000079f4d2dd5fae  pop r11
000079f4d2dd5fb0  pop r10
000079f4d2dd5fb2  pop r9
000079f4d2dd5fb4  pop r8
000079f4d2dd5fb6  pop rsi
000079f4d2dd5fb7  pop rdi
000079f4d2dd5fb8  pop rdx
000079f4d2dd5fb9  pop rcx
000079f4d2dd5fba  pop rax
000079f4d2dd5fbb  add rsp, 0x08
000079f4d2dd5fbf  jmp 0x000079F4D2DD303C
000079f4d2dd5fc4  sub rsp, 0x08
000079f4d2dd5fc8  push rax
000079f4d2dd5fc9  push rcx
000079f4d2dd5fca  push rdx
000079f4d2dd5fcb  push rdi
000079f4d2dd5fcc  push rsi
000079f4d2dd5fcd  push r8
000079f4d2dd5fcf  push r9
000079f4d2dd5fd1  push r10
000079f4d2dd5fd3  push r11
000079f4d2dd5fd5  sub rsp, 0xF0
000079f4d2dd5fdc  vmovaps [rsp], xmm0
000079f4d2dd5fe1  vmovaps [rsp+0x10], xmm2
000079f4d2dd5fe7  vmovaps [rsp+0x20], xmm3
000079f4d2dd5fed  vmovaps [rsp+0x30], xmm4
000079f4d2dd5ff3  vmovaps [rsp+0x40], xmm5
000079f4d2dd5ff9  vmovaps [rsp+0x50], xmm6
000079f4d2dd5fff  vmovaps [rsp+0x60], xmm7
000079f4d2dd6005  vmovaps [rsp+0x70], xmm8
000079f4d2dd600b  vmovaps [rsp+0x80], xmm9
000079f4d2dd6014  vmovaps [rsp+0x90], xmm10
000079f4d2dd601d  vmovaps [rsp+0xA0], xmm11
000079f4d2dd6026  vmovaps [rsp+0xB0], xmm12
000079f4d2dd602f  vmovaps [rsp+0xC0], xmm13
000079f4d2dd6038  vmovaps [rsp+0xD0], xmm14
000079f4d2dd6041  vmovaps [rsp+0xE0], xmm15
000079f4d2dd604a  sub rsp, 0x30
000079f4d2dd604e  movaps [rsp], xmm1
000079f4d2dd6052  movaps [rsp+0x10], xmm15
000079f4d2dd6058  movaps [rsp+0x20], xmm10
000079f4d2dd605e  lea rdi, [rsp]
000079f4d2dd6062  mov esi, 0x00
000079f4d2dd6067  mov rax, 0x5D9EC01E8530
000079f4d2dd6071  call rax
000079f4d2dd6073  movaps xmm1, [rsp]
000079f4d2dd6077  add rsp, 0x30
000079f4d2dd607b  vmovaps xmm0, [rsp]
000079f4d2dd6080  vmovaps xmm2, [rsp+0x10]
000079f4d2dd6086  vmovaps xmm3, [rsp+0x20]
000079f4d2dd608c  vmovaps xmm4, [rsp+0x30]
000079f4d2dd6092  vmovaps xmm5, [rsp+0x40]
000079f4d2dd6098  vmovaps xmm6, [rsp+0x50]
000079f4d2dd609e  vmovaps xmm7, [rsp+0x60]
000079f4d2dd60a4  vmovaps xmm8, [rsp+0x70]
000079f4d2dd60aa  vmovaps xmm9, [rsp+0x80]
000079f4d2dd60b3  vmovaps xmm10, [rsp+0x90]
000079f4d2dd60bc  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd60c5  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd60ce  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd60d7  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd60e0  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd60e9  add rsp, 0xF0
000079f4d2dd60f0  pop r11
000079f4d2dd60f2  pop r10
000079f4d2dd60f4  pop r9
000079f4d2dd60f6  pop r8
000079f4d2dd60f8  pop rsi
000079f4d2dd60f9  pop rdi
000079f4d2dd60fa  pop rdx
000079f4d2dd60fb  pop rcx
000079f4d2dd60fc  pop rax
000079f4d2dd60fd  add rsp, 0x08
000079f4d2dd6101  jmp 0x000079F4D2DD305B
000079f4d2dd6106  sub rsp, 0x08
000079f4d2dd610a  push rax
000079f4d2dd610b  push rcx
000079f4d2dd610c  push rdx
000079f4d2dd610d  push rdi
000079f4d2dd610e  push rsi
000079f4d2dd610f  push r8
000079f4d2dd6111  push r9
000079f4d2dd6113  push r10
000079f4d2dd6115  push r11
000079f4d2dd6117  sub rsp, 0xF0
000079f4d2dd611e  vmovaps [rsp], xmm0
000079f4d2dd6123  vmovaps [rsp+0x10], xmm1
000079f4d2dd6129  vmovaps [rsp+0x20], xmm2
000079f4d2dd612f  vmovaps [rsp+0x30], xmm3
000079f4d2dd6135  vmovaps [rsp+0x40], xmm4
000079f4d2dd613b  vmovaps [rsp+0x50], xmm5
000079f4d2dd6141  vmovaps [rsp+0x60], xmm6
000079f4d2dd6147  vmovaps [rsp+0x70], xmm7
000079f4d2dd614d  vmovaps [rsp+0x80], xmm8
000079f4d2dd6156  vmovaps [rsp+0x90], xmm9
000079f4d2dd615f  vmovaps [rsp+0xA0], xmm10
000079f4d2dd6168  vmovaps [rsp+0xB0], xmm11
000079f4d2dd6171  vmovaps [rsp+0xC0], xmm12
000079f4d2dd617a  vmovaps [rsp+0xD0], xmm13
000079f4d2dd6183  vmovaps [rsp+0xE0], xmm14
000079f4d2dd618c  sub rsp, 0x30
000079f4d2dd6190  movaps [rsp], xmm15
000079f4d2dd6195  movaps [rsp+0x10], xmm10
000079f4d2dd619b  movaps [rsp+0x20], xmm11
000079f4d2dd61a1  lea rdi, [rsp]
000079f4d2dd61a5  mov esi, 0x00
000079f4d2dd61aa  mov rax, 0x5D9EC01E8530
000079f4d2dd61b4  call rax
000079f4d2dd61b6  movaps xmm15, [rsp]
000079f4d2dd61bb  add rsp, 0x30
000079f4d2dd61bf  vmovaps xmm0, [rsp]
000079f4d2dd61c4  vmovaps xmm1, [rsp+0x10]
000079f4d2dd61ca  vmovaps xmm2, [rsp+0x20]
000079f4d2dd61d0  vmovaps xmm3, [rsp+0x30]
000079f4d2dd61d6  vmovaps xmm4, [rsp+0x40]
000079f4d2dd61dc  vmovaps xmm5, [rsp+0x50]
000079f4d2dd61e2  vmovaps xmm6, [rsp+0x60]
000079f4d2dd61e8  vmovaps xmm7, [rsp+0x70]
000079f4d2dd61ee  vmovaps xmm8, [rsp+0x80]
000079f4d2dd61f7  vmovaps xmm9, [rsp+0x90]
000079f4d2dd6200  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd6209  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd6212  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd621b  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd6224  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd622d  add rsp, 0xF0
000079f4d2dd6234  pop r11
000079f4d2dd6236  pop r10
000079f4d2dd6238  pop r9
000079f4d2dd623a  pop r8
000079f4d2dd623c  pop rsi
000079f4d2dd623d  pop rdi
000079f4d2dd623e  pop rdx
000079f4d2dd623f  pop rcx
000079f4d2dd6240  pop rax
000079f4d2dd6241  add rsp, 0x08
000079f4d2dd6245  jmp 0x000079F4D2DD307E
000079f4d2dd624a  sub rsp, 0x08
000079f4d2dd624e  push rax
000079f4d2dd624f  push rcx
000079f4d2dd6250  push rdx
000079f4d2dd6251  push rdi
000079f4d2dd6252  push rsi
000079f4d2dd6253  push r8
000079f4d2dd6255  push r9
000079f4d2dd6257  push r10
000079f4d2dd6259  push r11
000079f4d2dd625b  sub rsp, 0xF0
000079f4d2dd6262  vmovaps [rsp], xmm0
000079f4d2dd6267  vmovaps [rsp+0x10], xmm1
000079f4d2dd626d  vmovaps [rsp+0x20], xmm2
000079f4d2dd6273  vmovaps [rsp+0x30], xmm3
000079f4d2dd6279  vmovaps [rsp+0x40], xmm4
000079f4d2dd627f  vmovaps [rsp+0x50], xmm5
000079f4d2dd6285  vmovaps [rsp+0x60], xmm6
000079f4d2dd628b  vmovaps [rsp+0x70], xmm7
000079f4d2dd6291  vmovaps [rsp+0x80], xmm8
000079f4d2dd629a  vmovaps [rsp+0x90], xmm9
000079f4d2dd62a3  vmovaps [rsp+0xA0], xmm11
000079f4d2dd62ac  vmovaps [rsp+0xB0], xmm12
000079f4d2dd62b5  vmovaps [rsp+0xC0], xmm13
000079f4d2dd62be  vmovaps [rsp+0xD0], xmm14
000079f4d2dd62c7  vmovaps [rsp+0xE0], xmm15
000079f4d2dd62d0  sub rsp, 0x30
000079f4d2dd62d4  movaps [rsp], xmm10
000079f4d2dd62d9  movaps [rsp+0x10], xmm2
000079f4d2dd62de  movaps [rsp+0x20], xmm11
000079f4d2dd62e4  lea rdi, [rsp]
000079f4d2dd62e8  mov esi, 0x00
000079f4d2dd62ed  mov rax, 0x5D9EC01E8530
000079f4d2dd62f7  call rax
000079f4d2dd62f9  movaps xmm10, [rsp]
000079f4d2dd62fe  add rsp, 0x30
000079f4d2dd6302  vmovaps xmm0, [rsp]
000079f4d2dd6307  vmovaps xmm1, [rsp+0x10]
000079f4d2dd630d  vmovaps xmm2, [rsp+0x20]
000079f4d2dd6313  vmovaps xmm3, [rsp+0x30]
000079f4d2dd6319  vmovaps xmm4, [rsp+0x40]
000079f4d2dd631f  vmovaps xmm5, [rsp+0x50]
000079f4d2dd6325  vmovaps xmm6, [rsp+0x60]
000079f4d2dd632b  vmovaps xmm7, [rsp+0x70]
000079f4d2dd6331  vmovaps xmm8, [rsp+0x80]
000079f4d2dd633a  vmovaps xmm9, [rsp+0x90]
000079f4d2dd6343  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd634c  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd6355  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd635e  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd6367  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd6370  add rsp, 0xF0
000079f4d2dd6377  pop r11
000079f4d2dd6379  pop r10
000079f4d2dd637b  pop r9
000079f4d2dd637d  pop r8
000079f4d2dd637f  pop rsi
000079f4d2dd6380  pop rdi
000079f4d2dd6381  pop rdx
000079f4d2dd6382  pop rcx
000079f4d2dd6383  pop rax
000079f4d2dd6384  add rsp, 0x08
000079f4d2dd6388  jmp 0x000079F4D2DD30B6
000079f4d2dd638d  sub rsp, 0x08
000079f4d2dd6391  push rax
000079f4d2dd6392  push rcx
000079f4d2dd6393  push rdx
000079f4d2dd6394  push rdi
000079f4d2dd6395  push rsi
000079f4d2dd6396  push r8
000079f4d2dd6398  push r9
000079f4d2dd639a  push r10
000079f4d2dd639c  push r11
000079f4d2dd639e  sub rsp, 0xF0
000079f4d2dd63a5  vmovaps [rsp], xmm0
000079f4d2dd63aa  vmovaps [rsp+0x10], xmm1
000079f4d2dd63b0  vmovaps [rsp+0x20], xmm2
000079f4d2dd63b6  vmovaps [rsp+0x30], xmm3
000079f4d2dd63bc  vmovaps [rsp+0x40], xmm4
000079f4d2dd63c2  vmovaps [rsp+0x50], xmm5
000079f4d2dd63c8  vmovaps [rsp+0x60], xmm6
000079f4d2dd63ce  vmovaps [rsp+0x70], xmm7
000079f4d2dd63d4  vmovaps [rsp+0x80], xmm8
000079f4d2dd63dd  vmovaps [rsp+0x90], xmm9
000079f4d2dd63e6  vmovaps [rsp+0xA0], xmm10
000079f4d2dd63ef  vmovaps [rsp+0xB0], xmm12
000079f4d2dd63f8  vmovaps [rsp+0xC0], xmm13
000079f4d2dd6401  vmovaps [rsp+0xD0], xmm14
000079f4d2dd640a  vmovaps [rsp+0xE0], xmm15
000079f4d2dd6413  sub rsp, 0x30
000079f4d2dd6417  movaps [rsp], xmm11
000079f4d2dd641c  movaps [rsp+0x10], xmm2
000079f4d2dd6421  movaps [rsp+0x20], xmm1
000079f4d2dd6426  lea rdi, [rsp]
000079f4d2dd642a  mov esi, 0x00
000079f4d2dd642f  mov rax, 0x5D9EC01E8530
000079f4d2dd6439  call rax
000079f4d2dd643b  movaps xmm11, [rsp]
000079f4d2dd6440  add rsp, 0x30
000079f4d2dd6444  vmovaps xmm0, [rsp]
000079f4d2dd6449  vmovaps xmm1, [rsp+0x10]
000079f4d2dd644f  vmovaps xmm2, [rsp+0x20]
000079f4d2dd6455  vmovaps xmm3, [rsp+0x30]
000079f4d2dd645b  vmovaps xmm4, [rsp+0x40]
000079f4d2dd6461  vmovaps xmm5, [rsp+0x50]
000079f4d2dd6467  vmovaps xmm6, [rsp+0x60]
000079f4d2dd646d  vmovaps xmm7, [rsp+0x70]
000079f4d2dd6473  vmovaps xmm8, [rsp+0x80]
000079f4d2dd647c  vmovaps xmm9, [rsp+0x90]
000079f4d2dd6485  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd648e  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd6497  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd64a0  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd64a9  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd64b2  add rsp, 0xF0
000079f4d2dd64b9  pop r11
000079f4d2dd64bb  pop r10
000079f4d2dd64bd  pop r9
000079f4d2dd64bf  pop r8
000079f4d2dd64c1  pop rsi
000079f4d2dd64c2  pop rdi
000079f4d2dd64c3  pop rdx
000079f4d2dd64c4  pop rcx
000079f4d2dd64c5  pop rax
000079f4d2dd64c6  add rsp, 0x08
000079f4d2dd64ca  jmp 0x000079F4D2DD30F2
000079f4d2dd64cf  sub rsp, 0x08
000079f4d2dd64d3  push rax
000079f4d2dd64d4  push rcx
000079f4d2dd64d5  push rdx
000079f4d2dd64d6  push rdi
000079f4d2dd64d7  push rsi
000079f4d2dd64d8  push r8
000079f4d2dd64da  push r9
000079f4d2dd64dc  push r10
000079f4d2dd64de  push r11
000079f4d2dd64e0  sub rsp, 0xF0
000079f4d2dd64e7  vmovaps [rsp], xmm0
000079f4d2dd64ec  vmovaps [rsp+0x10], xmm2
000079f4d2dd64f2  vmovaps [rsp+0x20], xmm3
000079f4d2dd64f8  vmovaps [rsp+0x30], xmm4
000079f4d2dd64fe  vmovaps [rsp+0x40], xmm5
000079f4d2dd6504  vmovaps [rsp+0x50], xmm6
000079f4d2dd650a  vmovaps [rsp+0x60], xmm7
000079f4d2dd6510  vmovaps [rsp+0x70], xmm8
000079f4d2dd6516  vmovaps [rsp+0x80], xmm9
000079f4d2dd651f  vmovaps [rsp+0x90], xmm10
000079f4d2dd6528  vmovaps [rsp+0xA0], xmm11
000079f4d2dd6531  vmovaps [rsp+0xB0], xmm12
000079f4d2dd653a  vmovaps [rsp+0xC0], xmm13
000079f4d2dd6543  vmovaps [rsp+0xD0], xmm14
000079f4d2dd654c  vmovaps [rsp+0xE0], xmm15
000079f4d2dd6555  sub rsp, 0x30
000079f4d2dd6559  movaps [rsp], xmm1
000079f4d2dd655d  movaps [rsp+0x10], xmm14
000079f4d2dd6563  movaps [rsp+0x20], xmm6
000079f4d2dd6568  lea rdi, [rsp]
000079f4d2dd656c  mov esi, 0x00
000079f4d2dd6571  mov rax, 0x5D9EC01E8530
000079f4d2dd657b  call rax
000079f4d2dd657d  movaps xmm1, [rsp]
000079f4d2dd6581  add rsp, 0x30
000079f4d2dd6585  vmovaps xmm0, [rsp]
000079f4d2dd658a  vmovaps xmm2, [rsp+0x10]
000079f4d2dd6590  vmovaps xmm3, [rsp+0x20]
000079f4d2dd6596  vmovaps xmm4, [rsp+0x30]
000079f4d2dd659c  vmovaps xmm5, [rsp+0x40]
000079f4d2dd65a2  vmovaps xmm6, [rsp+0x50]
000079f4d2dd65a8  vmovaps xmm7, [rsp+0x60]
000079f4d2dd65ae  vmovaps xmm8, [rsp+0x70]
000079f4d2dd65b4  vmovaps xmm9, [rsp+0x80]
000079f4d2dd65bd  vmovaps xmm10, [rsp+0x90]
000079f4d2dd65c6  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd65cf  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd65d8  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd65e1  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd65ea  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd65f3  add rsp, 0xF0
000079f4d2dd65fa  pop r11
000079f4d2dd65fc  pop r10
000079f4d2dd65fe  pop r9
000079f4d2dd6600  pop r8
000079f4d2dd6602  pop rsi
000079f4d2dd6603  pop rdi
000079f4d2dd6604  pop rdx
000079f4d2dd6605  pop rcx
000079f4d2dd6606  pop rax
000079f4d2dd6607  add rsp, 0x08
000079f4d2dd660b  jmp 0x000079F4D2DD310B
000079f4d2dd6610  sub rsp, 0x08
000079f4d2dd6614  push rax
000079f4d2dd6615  push rcx
000079f4d2dd6616  push rdx
000079f4d2dd6617  push rdi
000079f4d2dd6618  push rsi
000079f4d2dd6619  push r8
000079f4d2dd661b  push r9
000079f4d2dd661d  push r10
000079f4d2dd661f  push r11
000079f4d2dd6621  sub rsp, 0xF0
000079f4d2dd6628  vmovaps [rsp], xmm0
000079f4d2dd662d  vmovaps [rsp+0x10], xmm1
000079f4d2dd6633  vmovaps [rsp+0x20], xmm2
000079f4d2dd6639  vmovaps [rsp+0x30], xmm3
000079f4d2dd663f  vmovaps [rsp+0x40], xmm4
000079f4d2dd6645  vmovaps [rsp+0x50], xmm5
000079f4d2dd664b  vmovaps [rsp+0x60], xmm6
000079f4d2dd6651  vmovaps [rsp+0x70], xmm7
000079f4d2dd6657  vmovaps [rsp+0x80], xmm8
000079f4d2dd6660  vmovaps [rsp+0x90], xmm9
000079f4d2dd6669  vmovaps [rsp+0xA0], xmm10
000079f4d2dd6672  vmovaps [rsp+0xB0], xmm11
000079f4d2dd667b  vmovaps [rsp+0xC0], xmm12
000079f4d2dd6684  vmovaps [rsp+0xD0], xmm13
000079f4d2dd668d  vmovaps [rsp+0xE0], xmm14
000079f4d2dd6696  sub rsp, 0x30
000079f4d2dd669a  movaps [rsp], xmm15
000079f4d2dd669f  movaps [rsp+0x10], xmm14
000079f4d2dd66a5  movaps [rsp+0x20], xmm5
000079f4d2dd66aa  lea rdi, [rsp]
000079f4d2dd66ae  mov esi, 0x00
000079f4d2dd66b3  mov rax, 0x5D9EC01E8530
000079f4d2dd66bd  call rax
000079f4d2dd66bf  movaps xmm15, [rsp]
000079f4d2dd66c4  add rsp, 0x30
000079f4d2dd66c8  vmovaps xmm0, [rsp]
000079f4d2dd66cd  vmovaps xmm1, [rsp+0x10]
000079f4d2dd66d3  vmovaps xmm2, [rsp+0x20]
000079f4d2dd66d9  vmovaps xmm3, [rsp+0x30]
000079f4d2dd66df  vmovaps xmm4, [rsp+0x40]
000079f4d2dd66e5  vmovaps xmm5, [rsp+0x50]
000079f4d2dd66eb  vmovaps xmm6, [rsp+0x60]
000079f4d2dd66f1  vmovaps xmm7, [rsp+0x70]
000079f4d2dd66f7  vmovaps xmm8, [rsp+0x80]
000079f4d2dd6700  vmovaps xmm9, [rsp+0x90]
000079f4d2dd6709  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd6712  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd671b  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd6724  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd672d  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd6736  add rsp, 0xF0
000079f4d2dd673d  pop r11
000079f4d2dd673f  pop r10
000079f4d2dd6741  pop r9
000079f4d2dd6743  pop r8
000079f4d2dd6745  pop rsi
000079f4d2dd6746  pop rdi
000079f4d2dd6747  pop rdx
000079f4d2dd6748  pop rcx
000079f4d2dd6749  pop rax
000079f4d2dd674a  add rsp, 0x08
000079f4d2dd674e  jmp 0x000079F4D2DD312B
000079f4d2dd6753  sub rsp, 0x08
000079f4d2dd6757  push rax
000079f4d2dd6758  push rcx
000079f4d2dd6759  push rdx
000079f4d2dd675a  push rdi
000079f4d2dd675b  push rsi
000079f4d2dd675c  push r8
000079f4d2dd675e  push r9
000079f4d2dd6760  push r10
000079f4d2dd6762  push r11
000079f4d2dd6764  sub rsp, 0xF0
000079f4d2dd676b  vmovaps [rsp], xmm0
000079f4d2dd6770  vmovaps [rsp+0x10], xmm1
000079f4d2dd6776  vmovaps [rsp+0x20], xmm2
000079f4d2dd677c  vmovaps [rsp+0x30], xmm3
000079f4d2dd6782  vmovaps [rsp+0x40], xmm4
000079f4d2dd6788  vmovaps [rsp+0x50], xmm5
000079f4d2dd678e  vmovaps [rsp+0x60], xmm7
000079f4d2dd6794  vmovaps [rsp+0x70], xmm8
000079f4d2dd679a  vmovaps [rsp+0x80], xmm9
000079f4d2dd67a3  vmovaps [rsp+0x90], xmm10
000079f4d2dd67ac  vmovaps [rsp+0xA0], xmm11
000079f4d2dd67b5  vmovaps [rsp+0xB0], xmm12
000079f4d2dd67be  vmovaps [rsp+0xC0], xmm13
000079f4d2dd67c7  vmovaps [rsp+0xD0], xmm14
000079f4d2dd67d0  vmovaps [rsp+0xE0], xmm15
000079f4d2dd67d9  sub rsp, 0x30
000079f4d2dd67dd  movaps [rsp], xmm6
000079f4d2dd67e1  movaps [rsp+0x10], xmm9
000079f4d2dd67e7  movaps [rsp+0x20], xmm14
000079f4d2dd67ed  lea rdi, [rsp]
000079f4d2dd67f1  mov esi, 0x00
000079f4d2dd67f6  mov rax, 0x5D9EC01E8530
000079f4d2dd6800  call rax
000079f4d2dd6802  movaps xmm6, [rsp]
000079f4d2dd6806  add rsp, 0x30
000079f4d2dd680a  vmovaps xmm0, [rsp]
000079f4d2dd680f  vmovaps xmm1, [rsp+0x10]
000079f4d2dd6815  vmovaps xmm2, [rsp+0x20]
000079f4d2dd681b  vmovaps xmm3, [rsp+0x30]
000079f4d2dd6821  vmovaps xmm4, [rsp+0x40]
000079f4d2dd6827  vmovaps xmm5, [rsp+0x50]
000079f4d2dd682d  vmovaps xmm7, [rsp+0x60]
000079f4d2dd6833  vmovaps xmm8, [rsp+0x70]
000079f4d2dd6839  vmovaps xmm9, [rsp+0x80]
000079f4d2dd6842  vmovaps xmm10, [rsp+0x90]
000079f4d2dd684b  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd6854  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd685d  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd6866  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd686f  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd6878  add rsp, 0xF0
000079f4d2dd687f  pop r11
000079f4d2dd6881  pop r10
000079f4d2dd6883  pop r9
000079f4d2dd6885  pop r8
000079f4d2dd6887  pop rsi
000079f4d2dd6888  pop rdi
000079f4d2dd6889  pop rdx
000079f4d2dd688a  pop rcx
000079f4d2dd688b  pop rax
000079f4d2dd688c  add rsp, 0x08
000079f4d2dd6890  jmp 0x000079F4D2DD3153
000079f4d2dd6895  sub rsp, 0x08
000079f4d2dd6899  push rax
000079f4d2dd689a  push rcx
000079f4d2dd689b  push rdx
000079f4d2dd689c  push rdi
000079f4d2dd689d  push rsi
000079f4d2dd689e  push r8
000079f4d2dd68a0  push r9
000079f4d2dd68a2  push r10
000079f4d2dd68a4  push r11
000079f4d2dd68a6  sub rsp, 0xF0
000079f4d2dd68ad  vmovaps [rsp], xmm0
000079f4d2dd68b2  vmovaps [rsp+0x10], xmm1
000079f4d2dd68b8  vmovaps [rsp+0x20], xmm2
000079f4d2dd68be  vmovaps [rsp+0x30], xmm3
000079f4d2dd68c4  vmovaps [rsp+0x40], xmm4
000079f4d2dd68ca  vmovaps [rsp+0x50], xmm5
000079f4d2dd68d0  vmovaps [rsp+0x60], xmm6
000079f4d2dd68d6  vmovaps [rsp+0x70], xmm7
000079f4d2dd68dc  vmovaps [rsp+0x80], xmm8
000079f4d2dd68e5  vmovaps [rsp+0x90], xmm9
000079f4d2dd68ee  vmovaps [rsp+0xA0], xmm10
000079f4d2dd68f7  vmovaps [rsp+0xB0], xmm11
000079f4d2dd6900  vmovaps [rsp+0xC0], xmm12
000079f4d2dd6909  vmovaps [rsp+0xD0], xmm13
000079f4d2dd6912  vmovaps [rsp+0xE0], xmm15
000079f4d2dd691b  sub rsp, 0x30
000079f4d2dd691f  movaps [rsp], xmm14
000079f4d2dd6924  movaps [rsp+0x10], xmm9
000079f4d2dd692a  movaps [rsp+0x20], xmm13
000079f4d2dd6930  lea rdi, [rsp]
000079f4d2dd6934  mov esi, 0x00
000079f4d2dd6939  mov rax, 0x5D9EC01E8530
000079f4d2dd6943  call rax
000079f4d2dd6945  movaps xmm14, [rsp]
000079f4d2dd694a  add rsp, 0x30
000079f4d2dd694e  vmovaps xmm0, [rsp]
000079f4d2dd6953  vmovaps xmm1, [rsp+0x10]
000079f4d2dd6959  vmovaps xmm2, [rsp+0x20]
000079f4d2dd695f  vmovaps xmm3, [rsp+0x30]
000079f4d2dd6965  vmovaps xmm4, [rsp+0x40]
000079f4d2dd696b  vmovaps xmm5, [rsp+0x50]
000079f4d2dd6971  vmovaps xmm6, [rsp+0x60]
000079f4d2dd6977  vmovaps xmm7, [rsp+0x70]
000079f4d2dd697d  vmovaps xmm8, [rsp+0x80]
000079f4d2dd6986  vmovaps xmm9, [rsp+0x90]
000079f4d2dd698f  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd6998  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd69a1  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd69aa  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd69b3  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd69bc  add rsp, 0xF0
000079f4d2dd69c3  pop r11
000079f4d2dd69c5  pop r10
000079f4d2dd69c7  pop r9
000079f4d2dd69c9  pop r8
000079f4d2dd69cb  pop rsi
000079f4d2dd69cc  pop rdi
000079f4d2dd69cd  pop rdx
000079f4d2dd69ce  pop rcx
000079f4d2dd69cf  pop rax
000079f4d2dd69d0  add rsp, 0x08
000079f4d2dd69d4  jmp 0x000079F4D2DD3176
000079f4d2dd69d9  sub rsp, 0x08
000079f4d2dd69dd  push rax
000079f4d2dd69de  push rcx
000079f4d2dd69df  push rdx
000079f4d2dd69e0  push rdi
000079f4d2dd69e1  push rsi
000079f4d2dd69e2  push r8
000079f4d2dd69e4  push r9
000079f4d2dd69e6  push r10
000079f4d2dd69e8  push r11
000079f4d2dd69ea  sub rsp, 0xF0
000079f4d2dd69f1  vmovaps [rsp], xmm0
000079f4d2dd69f6  vmovaps [rsp+0x10], xmm1
000079f4d2dd69fc  vmovaps [rsp+0x20], xmm2
000079f4d2dd6a02  vmovaps [rsp+0x30], xmm3
000079f4d2dd6a08  vmovaps [rsp+0x40], xmm4
000079f4d2dd6a0e  vmovaps [rsp+0x50], xmm5
000079f4d2dd6a14  vmovaps [rsp+0x60], xmm6
000079f4d2dd6a1a  vmovaps [rsp+0x70], xmm7
000079f4d2dd6a20  vmovaps [rsp+0x80], xmm8
000079f4d2dd6a29  vmovaps [rsp+0x90], xmm9
000079f4d2dd6a32  vmovaps [rsp+0xA0], xmm10
000079f4d2dd6a3b  vmovaps [rsp+0xB0], xmm11
000079f4d2dd6a44  vmovaps [rsp+0xC0], xmm12
000079f4d2dd6a4d  vmovaps [rsp+0xD0], xmm14
000079f4d2dd6a56  vmovaps [rsp+0xE0], xmm15
000079f4d2dd6a5f  sub rsp, 0x30
000079f4d2dd6a63  movaps [rsp], xmm13
000079f4d2dd6a68  movaps [rsp+0x10], xmm9
000079f4d2dd6a6e  movaps [rsp+0x20], xmm10
000079f4d2dd6a74  lea rdi, [rsp]
000079f4d2dd6a78  mov esi, 0x00
000079f4d2dd6a7d  mov rax, 0x5D9EC01E8530
000079f4d2dd6a87  call rax
000079f4d2dd6a89  movaps xmm13, [rsp]
000079f4d2dd6a8e  add rsp, 0x30
000079f4d2dd6a92  vmovaps xmm0, [rsp]
000079f4d2dd6a97  vmovaps xmm1, [rsp+0x10]
000079f4d2dd6a9d  vmovaps xmm2, [rsp+0x20]
000079f4d2dd6aa3  vmovaps xmm3, [rsp+0x30]
000079f4d2dd6aa9  vmovaps xmm4, [rsp+0x40]
000079f4d2dd6aaf  vmovaps xmm5, [rsp+0x50]
000079f4d2dd6ab5  vmovaps xmm6, [rsp+0x60]
000079f4d2dd6abb  vmovaps xmm7, [rsp+0x70]
000079f4d2dd6ac1  vmovaps xmm8, [rsp+0x80]
000079f4d2dd6aca  vmovaps xmm9, [rsp+0x90]
000079f4d2dd6ad3  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd6adc  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd6ae5  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd6aee  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd6af7  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd6b00  add rsp, 0xF0
000079f4d2dd6b07  pop r11
000079f4d2dd6b09  pop r10
000079f4d2dd6b0b  pop r9
000079f4d2dd6b0d  pop r8
000079f4d2dd6b0f  pop rsi
000079f4d2dd6b10  pop rdi
000079f4d2dd6b11  pop rdx
000079f4d2dd6b12  pop rcx
000079f4d2dd6b13  pop rax
000079f4d2dd6b14  add rsp, 0x08
000079f4d2dd6b18  jmp 0x000079F4D2DD3196
000079f4d2dd6b1d  call 0x000079F4D2C0AFE0
000079f4d2dd6b22  jmp 0x000079F4D2DD31EB
000079f4d2dd6b27  sub rsp, 0x08
000079f4d2dd6b2b  push rax
000079f4d2dd6b2c  push rcx
000079f4d2dd6b2d  push rdx
000079f4d2dd6b2e  push rdi
000079f4d2dd6b2f  push rsi
000079f4d2dd6b30  push r8
000079f4d2dd6b32  push r9
000079f4d2dd6b34  push r10
000079f4d2dd6b36  push r11
000079f4d2dd6b38  sub rsp, 0xF0
000079f4d2dd6b3f  vmovaps [rsp], xmm0
000079f4d2dd6b44  vmovaps [rsp+0x10], xmm1
000079f4d2dd6b4a  vmovaps [rsp+0x20], xmm2
000079f4d2dd6b50  vmovaps [rsp+0x30], xmm3
000079f4d2dd6b56  vmovaps [rsp+0x40], xmm4
000079f4d2dd6b5c  vmovaps [rsp+0x50], xmm5
000079f4d2dd6b62  vmovaps [rsp+0x60], xmm6
000079f4d2dd6b68  vmovaps [rsp+0x70], xmm7
000079f4d2dd6b6e  vmovaps [rsp+0x80], xmm8
000079f4d2dd6b77  vmovaps [rsp+0x90], xmm10
000079f4d2dd6b80  vmovaps [rsp+0xA0], xmm11
000079f4d2dd6b89  vmovaps [rsp+0xB0], xmm12
000079f4d2dd6b92  vmovaps [rsp+0xC0], xmm13
000079f4d2dd6b9b  vmovaps [rsp+0xD0], xmm14
000079f4d2dd6ba4  vmovaps [rsp+0xE0], xmm15
000079f4d2dd6bad  sub rsp, 0x30
000079f4d2dd6bb1  movaps [rsp], xmm9
000079f4d2dd6bb6  movaps [rsp+0x10], xmm8
000079f4d2dd6bbc  movaps [rsp+0x20], xmm10
000079f4d2dd6bc2  lea rdi, [rsp]
000079f4d2dd6bc6  mov esi, 0x00
000079f4d2dd6bcb  mov rax, 0x5D9EC01E8530
000079f4d2dd6bd5  call rax
000079f4d2dd6bd7  movaps xmm9, [rsp]
000079f4d2dd6bdc  add rsp, 0x30
000079f4d2dd6be0  vmovaps xmm0, [rsp]
000079f4d2dd6be5  vmovaps xmm1, [rsp+0x10]
000079f4d2dd6beb  vmovaps xmm2, [rsp+0x20]
000079f4d2dd6bf1  vmovaps xmm3, [rsp+0x30]
000079f4d2dd6bf7  vmovaps xmm4, [rsp+0x40]
000079f4d2dd6bfd  vmovaps xmm5, [rsp+0x50]
000079f4d2dd6c03  vmovaps xmm6, [rsp+0x60]
000079f4d2dd6c09  vmovaps xmm7, [rsp+0x70]
000079f4d2dd6c0f  vmovaps xmm8, [rsp+0x80]
000079f4d2dd6c18  vmovaps xmm10, [rsp+0x90]
000079f4d2dd6c21  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd6c2a  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd6c33  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd6c3c  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd6c45  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd6c4e  add rsp, 0xF0
000079f4d2dd6c55  pop r11
000079f4d2dd6c57  pop r10
000079f4d2dd6c59  pop r9
000079f4d2dd6c5b  pop r8
000079f4d2dd6c5d  pop rsi
000079f4d2dd6c5e  pop rdi
000079f4d2dd6c5f  pop rdx
000079f4d2dd6c60  pop rcx
000079f4d2dd6c61  pop rax
000079f4d2dd6c62  add rsp, 0x08
000079f4d2dd6c66  jmp 0x000079F4D2DD321C
000079f4d2dd6c6b  sub rsp, 0x08
000079f4d2dd6c6f  push rax
000079f4d2dd6c70  push rcx
000079f4d2dd6c71  push rdx
000079f4d2dd6c72  push rdi
000079f4d2dd6c73  push rsi
000079f4d2dd6c74  push r8
000079f4d2dd6c76  push r9
000079f4d2dd6c78  push r10
000079f4d2dd6c7a  push r11
000079f4d2dd6c7c  sub rsp, 0xF0
000079f4d2dd6c83  vmovaps [rsp], xmm0
000079f4d2dd6c88  vmovaps [rsp+0x10], xmm1
000079f4d2dd6c8e  vmovaps [rsp+0x20], xmm2
000079f4d2dd6c94  vmovaps [rsp+0x30], xmm3
000079f4d2dd6c9a  vmovaps [rsp+0x40], xmm4
000079f4d2dd6ca0  vmovaps [rsp+0x50], xmm5
000079f4d2dd6ca6  vmovaps [rsp+0x60], xmm6
000079f4d2dd6cac  vmovaps [rsp+0x70], xmm7
000079f4d2dd6cb2  vmovaps [rsp+0x80], xmm8
000079f4d2dd6cbb  vmovaps [rsp+0x90], xmm9
000079f4d2dd6cc4  vmovaps [rsp+0xA0], xmm11
000079f4d2dd6ccd  vmovaps [rsp+0xB0], xmm12
000079f4d2dd6cd6  vmovaps [rsp+0xC0], xmm13
000079f4d2dd6cdf  vmovaps [rsp+0xD0], xmm14
000079f4d2dd6ce8  vmovaps [rsp+0xE0], xmm15
000079f4d2dd6cf1  sub rsp, 0x30
000079f4d2dd6cf5  movaps [rsp], xmm10
000079f4d2dd6cfa  movaps [rsp+0x10], xmm1
000079f4d2dd6cff  movaps [rsp+0x20], xmm11
000079f4d2dd6d05  lea rdi, [rsp]
000079f4d2dd6d09  mov esi, 0x00
000079f4d2dd6d0e  mov rax, 0x5D9EC01E8530
000079f4d2dd6d18  call rax
000079f4d2dd6d1a  movaps xmm10, [rsp]
000079f4d2dd6d1f  add rsp, 0x30
000079f4d2dd6d23  vmovaps xmm0, [rsp]
000079f4d2dd6d28  vmovaps xmm1, [rsp+0x10]
000079f4d2dd6d2e  vmovaps xmm2, [rsp+0x20]
000079f4d2dd6d34  vmovaps xmm3, [rsp+0x30]
000079f4d2dd6d3a  vmovaps xmm4, [rsp+0x40]
000079f4d2dd6d40  vmovaps xmm5, [rsp+0x50]
000079f4d2dd6d46  vmovaps xmm6, [rsp+0x60]
000079f4d2dd6d4c  vmovaps xmm7, [rsp+0x70]
000079f4d2dd6d52  vmovaps xmm8, [rsp+0x80]
000079f4d2dd6d5b  vmovaps xmm9, [rsp+0x90]
000079f4d2dd6d64  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd6d6d  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd6d76  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd6d7f  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd6d88  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd6d91  add rsp, 0xF0
000079f4d2dd6d98  pop r11
000079f4d2dd6d9a  pop r10
000079f4d2dd6d9c  pop r9
000079f4d2dd6d9e  pop r8
000079f4d2dd6da0  pop rsi
000079f4d2dd6da1  pop rdi
000079f4d2dd6da2  pop rdx
000079f4d2dd6da3  pop rcx
000079f4d2dd6da4  pop rax
000079f4d2dd6da5  add rsp, 0x08
000079f4d2dd6da9  jmp 0x000079F4D2DD3237
000079f4d2dd6dae  sub rsp, 0x08
000079f4d2dd6db2  push rax
000079f4d2dd6db3  push rcx
000079f4d2dd6db4  push rdx
000079f4d2dd6db5  push rdi
000079f4d2dd6db6  push rsi
000079f4d2dd6db7  push r8
000079f4d2dd6db9  push r9
000079f4d2dd6dbb  push r10
000079f4d2dd6dbd  push r11
000079f4d2dd6dbf  sub rsp, 0xF0
000079f4d2dd6dc6  vmovaps [rsp], xmm0
000079f4d2dd6dcb  vmovaps [rsp+0x10], xmm2
000079f4d2dd6dd1  vmovaps [rsp+0x20], xmm3
000079f4d2dd6dd7  vmovaps [rsp+0x30], xmm4
000079f4d2dd6ddd  vmovaps [rsp+0x40], xmm5
000079f4d2dd6de3  vmovaps [rsp+0x50], xmm6
000079f4d2dd6de9  vmovaps [rsp+0x60], xmm7
000079f4d2dd6def  vmovaps [rsp+0x70], xmm8
000079f4d2dd6df5  vmovaps [rsp+0x80], xmm9
000079f4d2dd6dfe  vmovaps [rsp+0x90], xmm10
000079f4d2dd6e07  vmovaps [rsp+0xA0], xmm11
000079f4d2dd6e10  vmovaps [rsp+0xB0], xmm12
000079f4d2dd6e19  vmovaps [rsp+0xC0], xmm13
000079f4d2dd6e22  vmovaps [rsp+0xD0], xmm14
000079f4d2dd6e2b  vmovaps [rsp+0xE0], xmm15
000079f4d2dd6e34  sub rsp, 0x30
000079f4d2dd6e38  movaps [rsp], xmm1
000079f4d2dd6e3c  movaps [rsp+0x10], xmm15
000079f4d2dd6e42  movaps [rsp+0x20], xmm6
000079f4d2dd6e47  lea rdi, [rsp]
000079f4d2dd6e4b  mov esi, 0x00
000079f4d2dd6e50  mov rax, 0x5D9EC01E8530
000079f4d2dd6e5a  call rax
000079f4d2dd6e5c  movaps xmm1, [rsp]
000079f4d2dd6e60  add rsp, 0x30
000079f4d2dd6e64  vmovaps xmm0, [rsp]
000079f4d2dd6e69  vmovaps xmm2, [rsp+0x10]
000079f4d2dd6e6f  vmovaps xmm3, [rsp+0x20]
000079f4d2dd6e75  vmovaps xmm4, [rsp+0x30]
000079f4d2dd6e7b  vmovaps xmm5, [rsp+0x40]
000079f4d2dd6e81  vmovaps xmm6, [rsp+0x50]
000079f4d2dd6e87  vmovaps xmm7, [rsp+0x60]
000079f4d2dd6e8d  vmovaps xmm8, [rsp+0x70]
000079f4d2dd6e93  vmovaps xmm9, [rsp+0x80]
000079f4d2dd6e9c  vmovaps xmm10, [rsp+0x90]
000079f4d2dd6ea5  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd6eae  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd6eb7  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd6ec0  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd6ec9  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd6ed2  add rsp, 0xF0
000079f4d2dd6ed9  pop r11
000079f4d2dd6edb  pop r10
000079f4d2dd6edd  pop r9
000079f4d2dd6edf  pop r8
000079f4d2dd6ee1  pop rsi
000079f4d2dd6ee2  pop rdi
000079f4d2dd6ee3  pop rdx
000079f4d2dd6ee4  pop rcx
000079f4d2dd6ee5  pop rax
000079f4d2dd6ee6  add rsp, 0x08
000079f4d2dd6eea  jmp 0x000079F4D2DD3250
000079f4d2dd6eef  sub rsp, 0x08
000079f4d2dd6ef3  push rax
000079f4d2dd6ef4  push rcx
000079f4d2dd6ef5  push rdx
000079f4d2dd6ef6  push rdi
000079f4d2dd6ef7  push rsi
000079f4d2dd6ef8  push r8
000079f4d2dd6efa  push r9
000079f4d2dd6efc  push r10
000079f4d2dd6efe  push r11
000079f4d2dd6f00  sub rsp, 0xF0
000079f4d2dd6f07  vmovaps [rsp], xmm0
000079f4d2dd6f0c  vmovaps [rsp+0x10], xmm1
000079f4d2dd6f12  vmovaps [rsp+0x20], xmm2
000079f4d2dd6f18  vmovaps [rsp+0x30], xmm3
000079f4d2dd6f1e  vmovaps [rsp+0x40], xmm4
000079f4d2dd6f24  vmovaps [rsp+0x50], xmm5
000079f4d2dd6f2a  vmovaps [rsp+0x60], xmm6
000079f4d2dd6f30  vmovaps [rsp+0x70], xmm7
000079f4d2dd6f36  vmovaps [rsp+0x80], xmm8
000079f4d2dd6f3f  vmovaps [rsp+0x90], xmm9
000079f4d2dd6f48  vmovaps [rsp+0xA0], xmm10
000079f4d2dd6f51  vmovaps [rsp+0xB0], xmm12
000079f4d2dd6f5a  vmovaps [rsp+0xC0], xmm13
000079f4d2dd6f63  vmovaps [rsp+0xD0], xmm14
000079f4d2dd6f6c  vmovaps [rsp+0xE0], xmm15
000079f4d2dd6f75  sub rsp, 0x30
000079f4d2dd6f79  movaps [rsp], xmm11
000079f4d2dd6f7e  movaps [rsp+0x10], xmm12
000079f4d2dd6f84  movaps [rsp+0x20], xmm15
000079f4d2dd6f8a  lea rdi, [rsp]
000079f4d2dd6f8e  mov esi, 0x00
000079f4d2dd6f93  mov rax, 0x5D9EC01E8530
000079f4d2dd6f9d  call rax
000079f4d2dd6f9f  movaps xmm11, [rsp]
000079f4d2dd6fa4  add rsp, 0x30
000079f4d2dd6fa8  vmovaps xmm0, [rsp]
000079f4d2dd6fad  vmovaps xmm1, [rsp+0x10]
000079f4d2dd6fb3  vmovaps xmm2, [rsp+0x20]
000079f4d2dd6fb9  vmovaps xmm3, [rsp+0x30]
000079f4d2dd6fbf  vmovaps xmm4, [rsp+0x40]
000079f4d2dd6fc5  vmovaps xmm5, [rsp+0x50]
000079f4d2dd6fcb  vmovaps xmm6, [rsp+0x60]
000079f4d2dd6fd1  vmovaps xmm7, [rsp+0x70]
000079f4d2dd6fd7  vmovaps xmm8, [rsp+0x80]
000079f4d2dd6fe0  vmovaps xmm9, [rsp+0x90]
000079f4d2dd6fe9  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd6ff2  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd6ffb  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd7004  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd700d  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd7016  add rsp, 0xF0
000079f4d2dd701d  pop r11
000079f4d2dd701f  pop r10
000079f4d2dd7021  pop r9
000079f4d2dd7023  pop r8
000079f4d2dd7025  pop rsi
000079f4d2dd7026  pop rdi
000079f4d2dd7027  pop rdx
000079f4d2dd7028  pop rcx
000079f4d2dd7029  pop rax
000079f4d2dd702a  add rsp, 0x08
000079f4d2dd702e  jmp 0x000079F4D2DD327A
000079f4d2dd7033  sub rsp, 0x08
000079f4d2dd7037  push rax
000079f4d2dd7038  push rcx
000079f4d2dd7039  push rdx
000079f4d2dd703a  push rdi
000079f4d2dd703b  push rsi
000079f4d2dd703c  push r8
000079f4d2dd703e  push r9
000079f4d2dd7040  push r10
000079f4d2dd7042  push r11
000079f4d2dd7044  sub rsp, 0xF0
000079f4d2dd704b  vmovaps [rsp], xmm0
000079f4d2dd7050  vmovaps [rsp+0x10], xmm1
000079f4d2dd7056  vmovaps [rsp+0x20], xmm2
000079f4d2dd705c  vmovaps [rsp+0x30], xmm3
000079f4d2dd7062  vmovaps [rsp+0x40], xmm4
000079f4d2dd7068  vmovaps [rsp+0x50], xmm5
000079f4d2dd706e  vmovaps [rsp+0x60], xmm6
000079f4d2dd7074  vmovaps [rsp+0x70], xmm7
000079f4d2dd707a  vmovaps [rsp+0x80], xmm8
000079f4d2dd7083  vmovaps [rsp+0x90], xmm9
000079f4d2dd708c  vmovaps [rsp+0xA0], xmm10
000079f4d2dd7095  vmovaps [rsp+0xB0], xmm11
000079f4d2dd709e  vmovaps [rsp+0xC0], xmm13
000079f4d2dd70a7  vmovaps [rsp+0xD0], xmm14
000079f4d2dd70b0  vmovaps [rsp+0xE0], xmm15
000079f4d2dd70b9  sub rsp, 0x30
000079f4d2dd70bd  movaps [rsp], xmm12
000079f4d2dd70c2  movaps [rsp+0x10], xmm8
000079f4d2dd70c8  movaps [rsp+0x20], xmm15
000079f4d2dd70ce  lea rdi, [rsp]
000079f4d2dd70d2  mov esi, 0x00
000079f4d2dd70d7  mov rax, 0x5D9EC01E8530
000079f4d2dd70e1  call rax
000079f4d2dd70e3  movaps xmm12, [rsp]
000079f4d2dd70e8  add rsp, 0x30
000079f4d2dd70ec  vmovaps xmm0, [rsp]
000079f4d2dd70f1  vmovaps xmm1, [rsp+0x10]
000079f4d2dd70f7  vmovaps xmm2, [rsp+0x20]
000079f4d2dd70fd  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7103  vmovaps xmm4, [rsp+0x40]
000079f4d2dd7109  vmovaps xmm5, [rsp+0x50]
000079f4d2dd710f  vmovaps xmm6, [rsp+0x60]
000079f4d2dd7115  vmovaps xmm7, [rsp+0x70]
000079f4d2dd711b  vmovaps xmm8, [rsp+0x80]
000079f4d2dd7124  vmovaps xmm9, [rsp+0x90]
000079f4d2dd712d  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd7136  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd713f  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd7148  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd7151  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd715a  add rsp, 0xF0
000079f4d2dd7161  pop r11
000079f4d2dd7163  pop r10
000079f4d2dd7165  pop r9
000079f4d2dd7167  pop r8
000079f4d2dd7169  pop rsi
000079f4d2dd716a  pop rdi
000079f4d2dd716b  pop rdx
000079f4d2dd716c  pop rcx
000079f4d2dd716d  pop rax
000079f4d2dd716e  add rsp, 0x08
000079f4d2dd7172  jmp 0x000079F4D2DD32A9
000079f4d2dd7177  sub rsp, 0x08
000079f4d2dd717b  push rax
000079f4d2dd717c  push rcx
000079f4d2dd717d  push rdx
000079f4d2dd717e  push rdi
000079f4d2dd717f  push rsi
000079f4d2dd7180  push r8
000079f4d2dd7182  push r9
000079f4d2dd7184  push r10
000079f4d2dd7186  push r11
000079f4d2dd7188  sub rsp, 0xF0
000079f4d2dd718f  vmovaps [rsp], xmm0
000079f4d2dd7194  vmovaps [rsp+0x10], xmm1
000079f4d2dd719a  vmovaps [rsp+0x20], xmm2
000079f4d2dd71a0  vmovaps [rsp+0x30], xmm3
000079f4d2dd71a6  vmovaps [rsp+0x40], xmm4
000079f4d2dd71ac  vmovaps [rsp+0x50], xmm5
000079f4d2dd71b2  vmovaps [rsp+0x60], xmm6
000079f4d2dd71b8  vmovaps [rsp+0x70], xmm7
000079f4d2dd71be  vmovaps [rsp+0x80], xmm9
000079f4d2dd71c7  vmovaps [rsp+0x90], xmm10
000079f4d2dd71d0  vmovaps [rsp+0xA0], xmm11
000079f4d2dd71d9  vmovaps [rsp+0xB0], xmm12
000079f4d2dd71e2  vmovaps [rsp+0xC0], xmm13
000079f4d2dd71eb  vmovaps [rsp+0xD0], xmm14
000079f4d2dd71f4  vmovaps [rsp+0xE0], xmm15
000079f4d2dd71fd  sub rsp, 0x30
000079f4d2dd7201  movaps [rsp], xmm8
000079f4d2dd7206  movaps [rsp+0x10], xmm7
000079f4d2dd720b  movaps [rsp+0x20], xmm15
000079f4d2dd7211  lea rdi, [rsp]
000079f4d2dd7215  mov esi, 0x00
000079f4d2dd721a  mov rax, 0x5D9EC01E8530
000079f4d2dd7224  call rax
000079f4d2dd7226  movaps xmm8, [rsp]
000079f4d2dd722b  add rsp, 0x30
000079f4d2dd722f  vmovaps xmm0, [rsp]
000079f4d2dd7234  vmovaps xmm1, [rsp+0x10]
000079f4d2dd723a  vmovaps xmm2, [rsp+0x20]
000079f4d2dd7240  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7246  vmovaps xmm4, [rsp+0x40]
000079f4d2dd724c  vmovaps xmm5, [rsp+0x50]
000079f4d2dd7252  vmovaps xmm6, [rsp+0x60]
000079f4d2dd7258  vmovaps xmm7, [rsp+0x70]
000079f4d2dd725e  vmovaps xmm9, [rsp+0x80]
000079f4d2dd7267  vmovaps xmm10, [rsp+0x90]
000079f4d2dd7270  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd7279  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd7282  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd728b  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd7294  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd729d  add rsp, 0xF0
000079f4d2dd72a4  pop r11
000079f4d2dd72a6  pop r10
000079f4d2dd72a8  pop r9
000079f4d2dd72aa  pop r8
000079f4d2dd72ac  pop rsi
000079f4d2dd72ad  pop rdi
000079f4d2dd72ae  pop rdx
000079f4d2dd72af  pop rcx
000079f4d2dd72b0  pop rax
000079f4d2dd72b1  add rsp, 0x08
000079f4d2dd72b5  jmp 0x000079F4D2DD32CF
000079f4d2dd72ba  sub rsp, 0x08
000079f4d2dd72be  push rax
000079f4d2dd72bf  push rcx
000079f4d2dd72c0  push rdx
000079f4d2dd72c1  push rdi
000079f4d2dd72c2  push rsi
000079f4d2dd72c3  push r8
000079f4d2dd72c5  push r9
000079f4d2dd72c7  push r10
000079f4d2dd72c9  push r11
000079f4d2dd72cb  sub rsp, 0xF0
000079f4d2dd72d2  vmovaps [rsp], xmm0
000079f4d2dd72d7  vmovaps [rsp+0x10], xmm1
000079f4d2dd72dd  vmovaps [rsp+0x20], xmm2
000079f4d2dd72e3  vmovaps [rsp+0x30], xmm3
000079f4d2dd72e9  vmovaps [rsp+0x40], xmm4
000079f4d2dd72ef  vmovaps [rsp+0x50], xmm5
000079f4d2dd72f5  vmovaps [rsp+0x60], xmm6
000079f4d2dd72fb  vmovaps [rsp+0x70], xmm7
000079f4d2dd7301  vmovaps [rsp+0x80], xmm8
000079f4d2dd730a  vmovaps [rsp+0x90], xmm9
000079f4d2dd7313  vmovaps [rsp+0xA0], xmm10
000079f4d2dd731c  vmovaps [rsp+0xB0], xmm11
000079f4d2dd7325  vmovaps [rsp+0xC0], xmm12
000079f4d2dd732e  vmovaps [rsp+0xD0], xmm13
000079f4d2dd7337  vmovaps [rsp+0xE0], xmm14
000079f4d2dd7340  sub rsp, 0x30
000079f4d2dd7344  movaps [rsp], xmm15
000079f4d2dd7349  movaps [rsp+0x10], xmm14
000079f4d2dd734f  movaps [rsp+0x20], xmm9
000079f4d2dd7355  lea rdi, [rsp]
000079f4d2dd7359  mov esi, 0x00
000079f4d2dd735e  mov rax, 0x5D9EC01E8530
000079f4d2dd7368  call rax
000079f4d2dd736a  movaps xmm15, [rsp]
000079f4d2dd736f  add rsp, 0x30
000079f4d2dd7373  vmovaps xmm0, [rsp]
000079f4d2dd7378  vmovaps xmm1, [rsp+0x10]
000079f4d2dd737e  vmovaps xmm2, [rsp+0x20]
000079f4d2dd7384  vmovaps xmm3, [rsp+0x30]
000079f4d2dd738a  vmovaps xmm4, [rsp+0x40]
000079f4d2dd7390  vmovaps xmm5, [rsp+0x50]
000079f4d2dd7396  vmovaps xmm6, [rsp+0x60]
000079f4d2dd739c  vmovaps xmm7, [rsp+0x70]
000079f4d2dd73a2  vmovaps xmm8, [rsp+0x80]
000079f4d2dd73ab  vmovaps xmm9, [rsp+0x90]
000079f4d2dd73b4  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd73bd  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd73c6  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd73cf  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd73d8  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd73e1  add rsp, 0xF0
000079f4d2dd73e8  pop r11
000079f4d2dd73ea  pop r10
000079f4d2dd73ec  pop r9
000079f4d2dd73ee  pop r8
000079f4d2dd73f0  pop rsi
000079f4d2dd73f1  pop rdi
000079f4d2dd73f2  pop rdx
000079f4d2dd73f3  pop rcx
000079f4d2dd73f4  pop rax
000079f4d2dd73f5  add rsp, 0x08
000079f4d2dd73f9  jmp 0x000079F4D2DD32E9
000079f4d2dd73fe  sub rsp, 0x08
000079f4d2dd7402  push rax
000079f4d2dd7403  push rcx
000079f4d2dd7404  push rdx
000079f4d2dd7405  push rdi
000079f4d2dd7406  push rsi
000079f4d2dd7407  push r8
000079f4d2dd7409  push r9
000079f4d2dd740b  push r10
000079f4d2dd740d  push r11
000079f4d2dd740f  sub rsp, 0xF0
000079f4d2dd7416  vmovaps [rsp], xmm0
000079f4d2dd741b  vmovaps [rsp+0x10], xmm1
000079f4d2dd7421  vmovaps [rsp+0x20], xmm2
000079f4d2dd7427  vmovaps [rsp+0x30], xmm3
000079f4d2dd742d  vmovaps [rsp+0x40], xmm4
000079f4d2dd7433  vmovaps [rsp+0x50], xmm5
000079f4d2dd7439  vmovaps [rsp+0x60], xmm6
000079f4d2dd743f  vmovaps [rsp+0x70], xmm7
000079f4d2dd7445  vmovaps [rsp+0x80], xmm8
000079f4d2dd744e  vmovaps [rsp+0x90], xmm10
000079f4d2dd7457  vmovaps [rsp+0xA0], xmm11
000079f4d2dd7460  vmovaps [rsp+0xB0], xmm12
000079f4d2dd7469  vmovaps [rsp+0xC0], xmm13
000079f4d2dd7472  vmovaps [rsp+0xD0], xmm14
000079f4d2dd747b  vmovaps [rsp+0xE0], xmm15
000079f4d2dd7484  sub rsp, 0x30
000079f4d2dd7488  movaps [rsp], xmm9
000079f4d2dd748d  movaps [rsp+0x10], xmm7
000079f4d2dd7492  movaps [rsp+0x20], xmm14
000079f4d2dd7498  lea rdi, [rsp]
000079f4d2dd749c  mov esi, 0x00
000079f4d2dd74a1  mov rax, 0x5D9EC01E8530
000079f4d2dd74ab  call rax
000079f4d2dd74ad  movaps xmm9, [rsp]
000079f4d2dd74b2  add rsp, 0x30
000079f4d2dd74b6  vmovaps xmm0, [rsp]
000079f4d2dd74bb  vmovaps xmm1, [rsp+0x10]
000079f4d2dd74c1  vmovaps xmm2, [rsp+0x20]
000079f4d2dd74c7  vmovaps xmm3, [rsp+0x30]
000079f4d2dd74cd  vmovaps xmm4, [rsp+0x40]
000079f4d2dd74d3  vmovaps xmm5, [rsp+0x50]
000079f4d2dd74d9  vmovaps xmm6, [rsp+0x60]
000079f4d2dd74df  vmovaps xmm7, [rsp+0x70]
000079f4d2dd74e5  vmovaps xmm8, [rsp+0x80]
000079f4d2dd74ee  vmovaps xmm10, [rsp+0x90]
000079f4d2dd74f7  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd7500  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd7509  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd7512  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd751b  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd7524  add rsp, 0xF0
000079f4d2dd752b  pop r11
000079f4d2dd752d  pop r10
000079f4d2dd752f  pop r9
000079f4d2dd7531  pop r8
000079f4d2dd7533  pop rsi
000079f4d2dd7534  pop rdi
000079f4d2dd7535  pop rdx
000079f4d2dd7536  pop rcx
000079f4d2dd7537  pop rax
000079f4d2dd7538  add rsp, 0x08
000079f4d2dd753c  jmp 0x000079F4D2DD3318
000079f4d2dd7541  sub rsp, 0x08
000079f4d2dd7545  push rax
000079f4d2dd7546  push rcx
000079f4d2dd7547  push rdx
000079f4d2dd7548  push rdi
000079f4d2dd7549  push rsi
000079f4d2dd754a  push r8
000079f4d2dd754c  push r9
000079f4d2dd754e  push r10
000079f4d2dd7550  push r11
000079f4d2dd7552  sub rsp, 0xF0
000079f4d2dd7559  vmovaps [rsp], xmm0
000079f4d2dd755e  vmovaps [rsp+0x10], xmm1
000079f4d2dd7564  vmovaps [rsp+0x20], xmm2
000079f4d2dd756a  vmovaps [rsp+0x30], xmm3
000079f4d2dd7570  vmovaps [rsp+0x40], xmm4
000079f4d2dd7576  vmovaps [rsp+0x50], xmm5
000079f4d2dd757c  vmovaps [rsp+0x60], xmm6
000079f4d2dd7582  vmovaps [rsp+0x70], xmm7
000079f4d2dd7588  vmovaps [rsp+0x80], xmm8
000079f4d2dd7591  vmovaps [rsp+0x90], xmm9
000079f4d2dd759a  vmovaps [rsp+0xA0], xmm10
000079f4d2dd75a3  vmovaps [rsp+0xB0], xmm11
000079f4d2dd75ac  vmovaps [rsp+0xC0], xmm12
000079f4d2dd75b5  vmovaps [rsp+0xD0], xmm13
000079f4d2dd75be  vmovaps [rsp+0xE0], xmm15
000079f4d2dd75c7  sub rsp, 0x30
000079f4d2dd75cb  movaps [rsp], xmm14
000079f4d2dd75d0  movaps [rsp+0x10], xmm13
000079f4d2dd75d6  movaps [rsp+0x20], xmm11
000079f4d2dd75dc  lea rdi, [rsp]
000079f4d2dd75e0  mov esi, 0x00
000079f4d2dd75e5  mov rax, 0x5D9EC01E8530
000079f4d2dd75ef  call rax
000079f4d2dd75f1  movaps xmm14, [rsp]
000079f4d2dd75f6  add rsp, 0x30
000079f4d2dd75fa  vmovaps xmm0, [rsp]
000079f4d2dd75ff  vmovaps xmm1, [rsp+0x10]
000079f4d2dd7605  vmovaps xmm2, [rsp+0x20]
000079f4d2dd760b  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7611  vmovaps xmm4, [rsp+0x40]
000079f4d2dd7617  vmovaps xmm5, [rsp+0x50]
000079f4d2dd761d  vmovaps xmm6, [rsp+0x60]
000079f4d2dd7623  vmovaps xmm7, [rsp+0x70]
000079f4d2dd7629  vmovaps xmm8, [rsp+0x80]
000079f4d2dd7632  vmovaps xmm9, [rsp+0x90]
000079f4d2dd763b  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd7644  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd764d  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd7656  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd765f  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd7668  add rsp, 0xF0
000079f4d2dd766f  pop r11
000079f4d2dd7671  pop r10
000079f4d2dd7673  pop r9
000079f4d2dd7675  pop r8
000079f4d2dd7677  pop rsi
000079f4d2dd7678  pop rdi
000079f4d2dd7679  pop rdx
000079f4d2dd767a  pop rcx
000079f4d2dd767b  pop rax
000079f4d2dd767c  add rsp, 0x08
000079f4d2dd7680  jmp 0x000079F4D2DD3332
000079f4d2dd7685  sub rsp, 0x08
000079f4d2dd7689  push rax
000079f4d2dd768a  push rcx
000079f4d2dd768b  push rdx
000079f4d2dd768c  push rdi
000079f4d2dd768d  push rsi
000079f4d2dd768e  push r8
000079f4d2dd7690  push r9
000079f4d2dd7692  push r10
000079f4d2dd7694  push r11
000079f4d2dd7696  sub rsp, 0xF0
000079f4d2dd769d  vmovaps [rsp], xmm0
000079f4d2dd76a2  vmovaps [rsp+0x10], xmm1
000079f4d2dd76a8  vmovaps [rsp+0x20], xmm2
000079f4d2dd76ae  vmovaps [rsp+0x30], xmm3
000079f4d2dd76b4  vmovaps [rsp+0x40], xmm4
000079f4d2dd76ba  vmovaps [rsp+0x50], xmm5
000079f4d2dd76c0  vmovaps [rsp+0x60], xmm6
000079f4d2dd76c6  vmovaps [rsp+0x70], xmm7
000079f4d2dd76cc  vmovaps [rsp+0x80], xmm8
000079f4d2dd76d5  vmovaps [rsp+0x90], xmm9
000079f4d2dd76de  vmovaps [rsp+0xA0], xmm10
000079f4d2dd76e7  vmovaps [rsp+0xB0], xmm12
000079f4d2dd76f0  vmovaps [rsp+0xC0], xmm13
000079f4d2dd76f9  vmovaps [rsp+0xD0], xmm14
000079f4d2dd7702  vmovaps [rsp+0xE0], xmm15
000079f4d2dd770b  sub rsp, 0x30
000079f4d2dd770f  movaps [rsp], xmm11
000079f4d2dd7714  movaps [rsp+0x10], xmm7
000079f4d2dd7719  movaps [rsp+0x20], xmm13
000079f4d2dd771f  lea rdi, [rsp]
000079f4d2dd7723  mov esi, 0x00
000079f4d2dd7728  mov rax, 0x5D9EC01E8530
000079f4d2dd7732  call rax
000079f4d2dd7734  movaps xmm11, [rsp]
000079f4d2dd7739  add rsp, 0x30
000079f4d2dd773d  vmovaps xmm0, [rsp]
000079f4d2dd7742  vmovaps xmm1, [rsp+0x10]
000079f4d2dd7748  vmovaps xmm2, [rsp+0x20]
000079f4d2dd774e  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7754  vmovaps xmm4, [rsp+0x40]
000079f4d2dd775a  vmovaps xmm5, [rsp+0x50]
000079f4d2dd7760  vmovaps xmm6, [rsp+0x60]
000079f4d2dd7766  vmovaps xmm7, [rsp+0x70]
000079f4d2dd776c  vmovaps xmm8, [rsp+0x80]
000079f4d2dd7775  vmovaps xmm9, [rsp+0x90]
000079f4d2dd777e  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd7787  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd7790  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd7799  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd77a2  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd77ab  add rsp, 0xF0
000079f4d2dd77b2  pop r11
000079f4d2dd77b4  pop r10
000079f4d2dd77b6  pop r9
000079f4d2dd77b8  pop r8
000079f4d2dd77ba  pop rsi
000079f4d2dd77bb  pop rdi
000079f4d2dd77bc  pop rdx
000079f4d2dd77bd  pop rcx
000079f4d2dd77be  pop rax
000079f4d2dd77bf  add rsp, 0x08
000079f4d2dd77c3  jmp 0x000079F4D2DD335E
000079f4d2dd77c8  sub rsp, 0x08
000079f4d2dd77cc  push rax
000079f4d2dd77cd  push rcx
000079f4d2dd77ce  push rdx
000079f4d2dd77cf  push rdi
000079f4d2dd77d0  push rsi
000079f4d2dd77d1  push r8
000079f4d2dd77d3  push r9
000079f4d2dd77d5  push r10
000079f4d2dd77d7  push r11
000079f4d2dd77d9  sub rsp, 0xF0
000079f4d2dd77e0  vmovaps [rsp], xmm0
000079f4d2dd77e5  vmovaps [rsp+0x10], xmm1
000079f4d2dd77eb  vmovaps [rsp+0x20], xmm2
000079f4d2dd77f1  vmovaps [rsp+0x30], xmm3
000079f4d2dd77f7  vmovaps [rsp+0x40], xmm4
000079f4d2dd77fd  vmovaps [rsp+0x50], xmm5
000079f4d2dd7803  vmovaps [rsp+0x60], xmm6
000079f4d2dd7809  vmovaps [rsp+0x70], xmm7
000079f4d2dd780f  vmovaps [rsp+0x80], xmm8
000079f4d2dd7818  vmovaps [rsp+0x90], xmm9
000079f4d2dd7821  vmovaps [rsp+0xA0], xmm10
000079f4d2dd782a  vmovaps [rsp+0xB0], xmm11
000079f4d2dd7833  vmovaps [rsp+0xC0], xmm12
000079f4d2dd783c  vmovaps [rsp+0xD0], xmm14
000079f4d2dd7845  vmovaps [rsp+0xE0], xmm15
000079f4d2dd784e  sub rsp, 0x30
000079f4d2dd7852  movaps [rsp], xmm13
000079f4d2dd7857  movaps [rsp+0x10], xmm10
000079f4d2dd785d  movaps [rsp+0x20], xmm12
000079f4d2dd7863  lea rdi, [rsp]
000079f4d2dd7867  mov esi, 0x00
000079f4d2dd786c  mov rax, 0x5D9EC01E8530
000079f4d2dd7876  call rax
000079f4d2dd7878  movaps xmm13, [rsp]
000079f4d2dd787d  add rsp, 0x30
000079f4d2dd7881  vmovaps xmm0, [rsp]
000079f4d2dd7886  vmovaps xmm1, [rsp+0x10]
000079f4d2dd788c  vmovaps xmm2, [rsp+0x20]
000079f4d2dd7892  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7898  vmovaps xmm4, [rsp+0x40]
000079f4d2dd789e  vmovaps xmm5, [rsp+0x50]
000079f4d2dd78a4  vmovaps xmm6, [rsp+0x60]
000079f4d2dd78aa  vmovaps xmm7, [rsp+0x70]
000079f4d2dd78b0  vmovaps xmm8, [rsp+0x80]
000079f4d2dd78b9  vmovaps xmm9, [rsp+0x90]
000079f4d2dd78c2  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd78cb  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd78d4  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd78dd  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd78e6  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd78ef  add rsp, 0xF0
000079f4d2dd78f6  pop r11
000079f4d2dd78f8  pop r10
000079f4d2dd78fa  pop r9
000079f4d2dd78fc  pop r8
000079f4d2dd78fe  pop rsi
000079f4d2dd78ff  pop rdi
000079f4d2dd7900  pop rdx
000079f4d2dd7901  pop rcx
000079f4d2dd7902  pop rax
000079f4d2dd7903  add rsp, 0x08
000079f4d2dd7907  jmp 0x000079F4D2DD3378
000079f4d2dd790c  sub rsp, 0x08
000079f4d2dd7910  push rax
000079f4d2dd7911  push rcx
000079f4d2dd7912  push rdx
000079f4d2dd7913  push rdi
000079f4d2dd7914  push rsi
000079f4d2dd7915  push r8
000079f4d2dd7917  push r9
000079f4d2dd7919  push r10
000079f4d2dd791b  push r11
000079f4d2dd791d  sub rsp, 0xF0
000079f4d2dd7924  vmovaps [rsp], xmm0
000079f4d2dd7929  vmovaps [rsp+0x10], xmm1
000079f4d2dd792f  vmovaps [rsp+0x20], xmm2
000079f4d2dd7935  vmovaps [rsp+0x30], xmm3
000079f4d2dd793b  vmovaps [rsp+0x40], xmm4
000079f4d2dd7941  vmovaps [rsp+0x50], xmm5
000079f4d2dd7947  vmovaps [rsp+0x60], xmm6
000079f4d2dd794d  vmovaps [rsp+0x70], xmm7
000079f4d2dd7953  vmovaps [rsp+0x80], xmm8
000079f4d2dd795c  vmovaps [rsp+0x90], xmm9
000079f4d2dd7965  vmovaps [rsp+0xA0], xmm11
000079f4d2dd796e  vmovaps [rsp+0xB0], xmm12
000079f4d2dd7977  vmovaps [rsp+0xC0], xmm13
000079f4d2dd7980  vmovaps [rsp+0xD0], xmm14
000079f4d2dd7989  vmovaps [rsp+0xE0], xmm15
000079f4d2dd7992  sub rsp, 0x30
000079f4d2dd7996  movaps [rsp], xmm10
000079f4d2dd799b  movaps [rsp+0x10], xmm7
000079f4d2dd79a0  movaps [rsp+0x20], xmm12
000079f4d2dd79a6  lea rdi, [rsp]
000079f4d2dd79aa  mov esi, 0x00
000079f4d2dd79af  mov rax, 0x5D9EC01E8530
000079f4d2dd79b9  call rax
000079f4d2dd79bb  movaps xmm10, [rsp]
000079f4d2dd79c0  add rsp, 0x30
000079f4d2dd79c4  vmovaps xmm0, [rsp]
000079f4d2dd79c9  vmovaps xmm1, [rsp+0x10]
000079f4d2dd79cf  vmovaps xmm2, [rsp+0x20]
000079f4d2dd79d5  vmovaps xmm3, [rsp+0x30]
000079f4d2dd79db  vmovaps xmm4, [rsp+0x40]
000079f4d2dd79e1  vmovaps xmm5, [rsp+0x50]
000079f4d2dd79e7  vmovaps xmm6, [rsp+0x60]
000079f4d2dd79ed  vmovaps xmm7, [rsp+0x70]
000079f4d2dd79f3  vmovaps xmm8, [rsp+0x80]
000079f4d2dd79fc  vmovaps xmm9, [rsp+0x90]
000079f4d2dd7a05  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd7a0e  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd7a17  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd7a20  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd7a29  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd7a32  add rsp, 0xF0
000079f4d2dd7a39  pop r11
000079f4d2dd7a3b  pop r10
000079f4d2dd7a3d  pop r9
000079f4d2dd7a3f  pop r8
000079f4d2dd7a41  pop rsi
000079f4d2dd7a42  pop rdi
000079f4d2dd7a43  pop rdx
000079f4d2dd7a44  pop rcx
000079f4d2dd7a45  pop rax
000079f4d2dd7a46  add rsp, 0x08
000079f4d2dd7a4a  jmp 0x000079F4D2DD33A4
000079f4d2dd7a4f  sub rsp, 0x08
000079f4d2dd7a53  push rax
000079f4d2dd7a54  push rcx
000079f4d2dd7a55  push rdx
000079f4d2dd7a56  push rdi
000079f4d2dd7a57  push rsi
000079f4d2dd7a58  push r8
000079f4d2dd7a5a  push r9
000079f4d2dd7a5c  push r10
000079f4d2dd7a5e  push r11
000079f4d2dd7a60  sub rsp, 0xF0
000079f4d2dd7a67  vmovaps [rsp], xmm0
000079f4d2dd7a6c  vmovaps [rsp+0x10], xmm1
000079f4d2dd7a72  vmovaps [rsp+0x20], xmm2
000079f4d2dd7a78  vmovaps [rsp+0x30], xmm3
000079f4d2dd7a7e  vmovaps [rsp+0x40], xmm4
000079f4d2dd7a84  vmovaps [rsp+0x50], xmm5
000079f4d2dd7a8a  vmovaps [rsp+0x60], xmm6
000079f4d2dd7a90  vmovaps [rsp+0x70], xmm7
000079f4d2dd7a96  vmovaps [rsp+0x80], xmm8
000079f4d2dd7a9f  vmovaps [rsp+0x90], xmm9
000079f4d2dd7aa8  vmovaps [rsp+0xA0], xmm10
000079f4d2dd7ab1  vmovaps [rsp+0xB0], xmm11
000079f4d2dd7aba  vmovaps [rsp+0xC0], xmm13
000079f4d2dd7ac3  vmovaps [rsp+0xD0], xmm14
000079f4d2dd7acc  vmovaps [rsp+0xE0], xmm15
000079f4d2dd7ad5  sub rsp, 0x30
000079f4d2dd7ad9  movaps [rsp], xmm12
000079f4d2dd7ade  movaps [rsp+0x10], xmm1
000079f4d2dd7ae3  movaps [rsp+0x20], xmm8
000079f4d2dd7ae9  lea rdi, [rsp]
000079f4d2dd7aed  mov esi, 0x00
000079f4d2dd7af2  mov rax, 0x5D9EC01E8530
000079f4d2dd7afc  call rax
000079f4d2dd7afe  movaps xmm12, [rsp]
000079f4d2dd7b03  add rsp, 0x30
000079f4d2dd7b07  vmovaps xmm0, [rsp]
000079f4d2dd7b0c  vmovaps xmm1, [rsp+0x10]
000079f4d2dd7b12  vmovaps xmm2, [rsp+0x20]
000079f4d2dd7b18  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7b1e  vmovaps xmm4, [rsp+0x40]
000079f4d2dd7b24  vmovaps xmm5, [rsp+0x50]
000079f4d2dd7b2a  vmovaps xmm6, [rsp+0x60]
000079f4d2dd7b30  vmovaps xmm7, [rsp+0x70]
000079f4d2dd7b36  vmovaps xmm8, [rsp+0x80]
000079f4d2dd7b3f  vmovaps xmm9, [rsp+0x90]
000079f4d2dd7b48  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd7b51  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd7b5a  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd7b63  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd7b6c  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd7b75  add rsp, 0xF0
000079f4d2dd7b7c  pop r11
000079f4d2dd7b7e  pop r10
000079f4d2dd7b80  pop r9
000079f4d2dd7b82  pop r8
000079f4d2dd7b84  pop rsi
000079f4d2dd7b85  pop rdi
000079f4d2dd7b86  pop rdx
000079f4d2dd7b87  pop rcx
000079f4d2dd7b88  pop rax
000079f4d2dd7b89  add rsp, 0x08
000079f4d2dd7b8d  jmp 0x000079F4D2DD33BE
000079f4d2dd7b92  call 0x000079F4D2BFF430
000079f4d2dd7b97  jmp 0x000079F4D2DD33C8
000079f4d2dd7b9c  sub rsp, 0x08
000079f4d2dd7ba0  push rax
000079f4d2dd7ba1  push rcx
000079f4d2dd7ba2  push rdx
000079f4d2dd7ba3  push rdi
000079f4d2dd7ba4  push rsi
000079f4d2dd7ba5  push r8
000079f4d2dd7ba7  push r9
000079f4d2dd7ba9  push r10
000079f4d2dd7bab  push r11
000079f4d2dd7bad  sub rsp, 0xF0
000079f4d2dd7bb4  vmovaps [rsp], xmm0
000079f4d2dd7bb9  vmovaps [rsp+0x10], xmm1
000079f4d2dd7bbf  vmovaps [rsp+0x20], xmm2
000079f4d2dd7bc5  vmovaps [rsp+0x30], xmm3
000079f4d2dd7bcb  vmovaps [rsp+0x40], xmm4
000079f4d2dd7bd1  vmovaps [rsp+0x50], xmm5
000079f4d2dd7bd7  vmovaps [rsp+0x60], xmm6
000079f4d2dd7bdd  vmovaps [rsp+0x70], xmm7
000079f4d2dd7be3  vmovaps [rsp+0x80], xmm9
000079f4d2dd7bec  vmovaps [rsp+0x90], xmm10
000079f4d2dd7bf5  vmovaps [rsp+0xA0], xmm11
000079f4d2dd7bfe  vmovaps [rsp+0xB0], xmm12
000079f4d2dd7c07  vmovaps [rsp+0xC0], xmm13
000079f4d2dd7c10  vmovaps [rsp+0xD0], xmm14
000079f4d2dd7c19  vmovaps [rsp+0xE0], xmm15
000079f4d2dd7c22  sub rsp, 0x30
000079f4d2dd7c26  movaps [rsp], xmm8
000079f4d2dd7c2b  movaps [rsp+0x10], xmm15
000079f4d2dd7c31  movaps [rsp+0x20], xmm9
000079f4d2dd7c37  lea rdi, [rsp]
000079f4d2dd7c3b  mov esi, 0x00
000079f4d2dd7c40  mov rax, 0x5D9EC01E8530
000079f4d2dd7c4a  call rax
000079f4d2dd7c4c  movaps xmm8, [rsp]
000079f4d2dd7c51  add rsp, 0x30
000079f4d2dd7c55  vmovaps xmm0, [rsp]
000079f4d2dd7c5a  vmovaps xmm1, [rsp+0x10]
000079f4d2dd7c60  vmovaps xmm2, [rsp+0x20]
000079f4d2dd7c66  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7c6c  vmovaps xmm4, [rsp+0x40]
000079f4d2dd7c72  vmovaps xmm5, [rsp+0x50]
000079f4d2dd7c78  vmovaps xmm6, [rsp+0x60]
000079f4d2dd7c7e  vmovaps xmm7, [rsp+0x70]
000079f4d2dd7c84  vmovaps xmm9, [rsp+0x80]
000079f4d2dd7c8d  vmovaps xmm10, [rsp+0x90]
000079f4d2dd7c96  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd7c9f  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd7ca8  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd7cb1  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd7cba  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd7cc3  add rsp, 0xF0
000079f4d2dd7cca  pop r11
000079f4d2dd7ccc  pop r10
000079f4d2dd7cce  pop r9
000079f4d2dd7cd0  pop r8
000079f4d2dd7cd2  pop rsi
000079f4d2dd7cd3  pop rdi
000079f4d2dd7cd4  pop rdx
000079f4d2dd7cd5  pop rcx
000079f4d2dd7cd6  pop rax
000079f4d2dd7cd7  add rsp, 0x08
000079f4d2dd7cdb  jmp 0x000079F4D2DD33EA
000079f4d2dd7ce0  sub rsp, 0x08
000079f4d2dd7ce4  push rax
000079f4d2dd7ce5  push rcx
000079f4d2dd7ce6  push rdx
000079f4d2dd7ce7  push rdi
000079f4d2dd7ce8  push rsi
000079f4d2dd7ce9  push r8
000079f4d2dd7ceb  push r9
000079f4d2dd7ced  push r10
000079f4d2dd7cef  push r11
000079f4d2dd7cf1  sub rsp, 0xF0
000079f4d2dd7cf8  vmovaps [rsp], xmm0
000079f4d2dd7cfd  vmovaps [rsp+0x10], xmm1
000079f4d2dd7d03  vmovaps [rsp+0x20], xmm2
000079f4d2dd7d09  vmovaps [rsp+0x30], xmm3
000079f4d2dd7d0f  vmovaps [rsp+0x40], xmm4
000079f4d2dd7d15  vmovaps [rsp+0x50], xmm5
000079f4d2dd7d1b  vmovaps [rsp+0x60], xmm6
000079f4d2dd7d21  vmovaps [rsp+0x70], xmm7
000079f4d2dd7d27  vmovaps [rsp+0x80], xmm8
000079f4d2dd7d30  vmovaps [rsp+0x90], xmm10
000079f4d2dd7d39  vmovaps [rsp+0xA0], xmm11
000079f4d2dd7d42  vmovaps [rsp+0xB0], xmm12
000079f4d2dd7d4b  vmovaps [rsp+0xC0], xmm13
000079f4d2dd7d54  vmovaps [rsp+0xD0], xmm14
000079f4d2dd7d5d  vmovaps [rsp+0xE0], xmm15
000079f4d2dd7d66  sub rsp, 0x30
000079f4d2dd7d6a  movaps [rsp], xmm9
000079f4d2dd7d6f  movaps [rsp+0x10], xmm1
000079f4d2dd7d74  movaps [rsp+0x20], xmm15
000079f4d2dd7d7a  lea rdi, [rsp]
000079f4d2dd7d7e  mov esi, 0x00
000079f4d2dd7d83  mov rax, 0x5D9EC01E8530
000079f4d2dd7d8d  call rax
000079f4d2dd7d8f  movaps xmm9, [rsp]
000079f4d2dd7d94  add rsp, 0x30
000079f4d2dd7d98  vmovaps xmm0, [rsp]
000079f4d2dd7d9d  vmovaps xmm1, [rsp+0x10]
000079f4d2dd7da3  vmovaps xmm2, [rsp+0x20]
000079f4d2dd7da9  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7daf  vmovaps xmm4, [rsp+0x40]
000079f4d2dd7db5  vmovaps xmm5, [rsp+0x50]
000079f4d2dd7dbb  vmovaps xmm6, [rsp+0x60]
000079f4d2dd7dc1  vmovaps xmm7, [rsp+0x70]
000079f4d2dd7dc7  vmovaps xmm8, [rsp+0x80]
000079f4d2dd7dd0  vmovaps xmm10, [rsp+0x90]
000079f4d2dd7dd9  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd7de2  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd7deb  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd7df4  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd7dfd  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd7e06  add rsp, 0xF0
000079f4d2dd7e0d  pop r11
000079f4d2dd7e0f  pop r10
000079f4d2dd7e11  pop r9
000079f4d2dd7e13  pop r8
000079f4d2dd7e15  pop rsi
000079f4d2dd7e16  pop rdi
000079f4d2dd7e17  pop rdx
000079f4d2dd7e18  pop rcx
000079f4d2dd7e19  pop rax
000079f4d2dd7e1a  add rsp, 0x08
000079f4d2dd7e1e  jmp 0x000079F4D2DD3418
000079f4d2dd7e23  sub rsp, 0x08
000079f4d2dd7e27  push rax
000079f4d2dd7e28  push rcx
000079f4d2dd7e29  push rdx
000079f4d2dd7e2a  push rdi
000079f4d2dd7e2b  push rsi
000079f4d2dd7e2c  push r8
000079f4d2dd7e2e  push r9
000079f4d2dd7e30  push r10
000079f4d2dd7e32  push r11
000079f4d2dd7e34  sub rsp, 0xF0
000079f4d2dd7e3b  vmovaps [rsp], xmm0
000079f4d2dd7e40  vmovaps [rsp+0x10], xmm1
000079f4d2dd7e46  vmovaps [rsp+0x20], xmm2
000079f4d2dd7e4c  vmovaps [rsp+0x30], xmm3
000079f4d2dd7e52  vmovaps [rsp+0x40], xmm4
000079f4d2dd7e58  vmovaps [rsp+0x50], xmm5
000079f4d2dd7e5e  vmovaps [rsp+0x60], xmm6
000079f4d2dd7e64  vmovaps [rsp+0x70], xmm7
000079f4d2dd7e6a  vmovaps [rsp+0x80], xmm8
000079f4d2dd7e73  vmovaps [rsp+0x90], xmm9
000079f4d2dd7e7c  vmovaps [rsp+0xA0], xmm10
000079f4d2dd7e85  vmovaps [rsp+0xB0], xmm11
000079f4d2dd7e8e  vmovaps [rsp+0xC0], xmm12
000079f4d2dd7e97  vmovaps [rsp+0xD0], xmm13
000079f4d2dd7ea0  vmovaps [rsp+0xE0], xmm14
000079f4d2dd7ea9  sub rsp, 0x30
000079f4d2dd7ead  movaps [rsp], xmm15
000079f4d2dd7eb2  movaps [rsp+0x10], xmm4
000079f4d2dd7eb7  movaps [rsp+0x20], xmm1
000079f4d2dd7ebc  lea rdi, [rsp]
000079f4d2dd7ec0  mov esi, 0x00
000079f4d2dd7ec5  mov rax, 0x5D9EC01E8530
000079f4d2dd7ecf  call rax
000079f4d2dd7ed1  movaps xmm15, [rsp]
000079f4d2dd7ed6  add rsp, 0x30
000079f4d2dd7eda  vmovaps xmm0, [rsp]
000079f4d2dd7edf  vmovaps xmm1, [rsp+0x10]
000079f4d2dd7ee5  vmovaps xmm2, [rsp+0x20]
000079f4d2dd7eeb  vmovaps xmm3, [rsp+0x30]
000079f4d2dd7ef1  vmovaps xmm4, [rsp+0x40]
000079f4d2dd7ef7  vmovaps xmm5, [rsp+0x50]
000079f4d2dd7efd  vmovaps xmm6, [rsp+0x60]
000079f4d2dd7f03  vmovaps xmm7, [rsp+0x70]
000079f4d2dd7f09  vmovaps xmm8, [rsp+0x80]
000079f4d2dd7f12  vmovaps xmm9, [rsp+0x90]
000079f4d2dd7f1b  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd7f24  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd7f2d  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd7f36  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd7f3f  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd7f48  add rsp, 0xF0
000079f4d2dd7f4f  pop r11
000079f4d2dd7f51  pop r10
000079f4d2dd7f53  pop r9
000079f4d2dd7f55  pop r8
000079f4d2dd7f57  pop rsi
000079f4d2dd7f58  pop rdi
000079f4d2dd7f59  pop rdx
000079f4d2dd7f5a  pop rcx
000079f4d2dd7f5b  pop rax
000079f4d2dd7f5c  add rsp, 0x08
000079f4d2dd7f60  jmp 0x000079F4D2DD343E
000079f4d2dd7f65  sub rsp, 0x08
000079f4d2dd7f69  push rax
000079f4d2dd7f6a  push rcx
000079f4d2dd7f6b  push rdx
000079f4d2dd7f6c  push rdi
000079f4d2dd7f6d  push rsi
000079f4d2dd7f6e  push r8
000079f4d2dd7f70  push r9
000079f4d2dd7f72  push r10
000079f4d2dd7f74  push r11
000079f4d2dd7f76  sub rsp, 0xF0
000079f4d2dd7f7d  vmovaps [rsp], xmm0
000079f4d2dd7f82  vmovaps [rsp+0x10], xmm2
000079f4d2dd7f88  vmovaps [rsp+0x20], xmm3
000079f4d2dd7f8e  vmovaps [rsp+0x30], xmm4
000079f4d2dd7f94  vmovaps [rsp+0x40], xmm5
000079f4d2dd7f9a  vmovaps [rsp+0x50], xmm6
000079f4d2dd7fa0  vmovaps [rsp+0x60], xmm7
000079f4d2dd7fa6  vmovaps [rsp+0x70], xmm8
000079f4d2dd7fac  vmovaps [rsp+0x80], xmm9
000079f4d2dd7fb5  vmovaps [rsp+0x90], xmm10
000079f4d2dd7fbe  vmovaps [rsp+0xA0], xmm11
000079f4d2dd7fc7  vmovaps [rsp+0xB0], xmm12
000079f4d2dd7fd0  vmovaps [rsp+0xC0], xmm13
000079f4d2dd7fd9  vmovaps [rsp+0xD0], xmm14
000079f4d2dd7fe2  vmovaps [rsp+0xE0], xmm15
000079f4d2dd7feb  sub rsp, 0x30
000079f4d2dd7fef  movaps [rsp], xmm1
000079f4d2dd7ff3  movaps [rsp+0x10], xmm14
000079f4d2dd7ff9  movaps [rsp+0x20], xmm11
000079f4d2dd7fff  lea rdi, [rsp]
000079f4d2dd8003  mov esi, 0x00
000079f4d2dd8008  mov rax, 0x5D9EC01E8530
000079f4d2dd8012  call rax
000079f4d2dd8014  movaps xmm1, [rsp]
000079f4d2dd8018  add rsp, 0x30
000079f4d2dd801c  vmovaps xmm0, [rsp]
000079f4d2dd8021  vmovaps xmm2, [rsp+0x10]
000079f4d2dd8027  vmovaps xmm3, [rsp+0x20]
000079f4d2dd802d  vmovaps xmm4, [rsp+0x30]
000079f4d2dd8033  vmovaps xmm5, [rsp+0x40]
000079f4d2dd8039  vmovaps xmm6, [rsp+0x50]
000079f4d2dd803f  vmovaps xmm7, [rsp+0x60]
000079f4d2dd8045  vmovaps xmm8, [rsp+0x70]
000079f4d2dd804b  vmovaps xmm9, [rsp+0x80]
000079f4d2dd8054  vmovaps xmm10, [rsp+0x90]
000079f4d2dd805d  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd8066  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd806f  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd8078  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd8081  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd808a  add rsp, 0xF0
000079f4d2dd8091  pop r11
000079f4d2dd8093  pop r10
000079f4d2dd8095  pop r9
000079f4d2dd8097  pop r8
000079f4d2dd8099  pop rsi
000079f4d2dd809a  pop rdi
000079f4d2dd809b  pop rdx
000079f4d2dd809c  pop rcx
000079f4d2dd809d  pop rax
000079f4d2dd809e  add rsp, 0x08
000079f4d2dd80a2  jmp 0x000079F4D2DD345F
000079f4d2dd80a7  call 0x000079F4D2CE45A0
000079f4d2dd80ac  jmp 0x000079F4D2DD346D
000079f4d2dd80b1  call 0x000079F4D2C09D70
000079f4d2dd80b6  jmp 0x000079F4D2DD3477
000079f4d2dd80bb  sub rsp, 0x08
000079f4d2dd80bf  push rax
000079f4d2dd80c0  push rcx
000079f4d2dd80c1  push rdx
000079f4d2dd80c2  push rdi
000079f4d2dd80c3  push rsi
000079f4d2dd80c4  push r8
000079f4d2dd80c6  push r9
000079f4d2dd80c8  push r10
000079f4d2dd80ca  push r11
000079f4d2dd80cc  sub rsp, 0xF0
000079f4d2dd80d3  vmovaps [rsp], xmm0
000079f4d2dd80d8  vmovaps [rsp+0x10], xmm1
000079f4d2dd80de  vmovaps [rsp+0x20], xmm2
000079f4d2dd80e4  vmovaps [rsp+0x30], xmm3
000079f4d2dd80ea  vmovaps [rsp+0x40], xmm4
000079f4d2dd80f0  vmovaps [rsp+0x50], xmm5
000079f4d2dd80f6  vmovaps [rsp+0x60], xmm6
000079f4d2dd80fc  vmovaps [rsp+0x70], xmm8
000079f4d2dd8102  vmovaps [rsp+0x80], xmm9
000079f4d2dd810b  vmovaps [rsp+0x90], xmm10
000079f4d2dd8114  vmovaps [rsp+0xA0], xmm11
000079f4d2dd811d  vmovaps [rsp+0xB0], xmm12
000079f4d2dd8126  vmovaps [rsp+0xC0], xmm13
000079f4d2dd812f  vmovaps [rsp+0xD0], xmm14
000079f4d2dd8138  vmovaps [rsp+0xE0], xmm15
000079f4d2dd8141  sub rsp, 0x30
000079f4d2dd8145  movaps [rsp], xmm7
000079f4d2dd8149  movaps [rsp+0x10], xmm13
000079f4d2dd814f  movaps [rsp+0x20], xmm10
000079f4d2dd8155  lea rdi, [rsp]
000079f4d2dd8159  mov esi, 0x00
000079f4d2dd815e  mov rax, 0x5D9EC01E8530
000079f4d2dd8168  call rax
000079f4d2dd816a  movaps xmm7, [rsp]
000079f4d2dd816e  add rsp, 0x30
000079f4d2dd8172  vmovaps xmm0, [rsp]
000079f4d2dd8177  vmovaps xmm1, [rsp+0x10]
000079f4d2dd817d  vmovaps xmm2, [rsp+0x20]
000079f4d2dd8183  vmovaps xmm3, [rsp+0x30]
000079f4d2dd8189  vmovaps xmm4, [rsp+0x40]
000079f4d2dd818f  vmovaps xmm5, [rsp+0x50]
000079f4d2dd8195  vmovaps xmm6, [rsp+0x60]
000079f4d2dd819b  vmovaps xmm8, [rsp+0x70]
000079f4d2dd81a1  vmovaps xmm9, [rsp+0x80]
000079f4d2dd81aa  vmovaps xmm10, [rsp+0x90]
000079f4d2dd81b3  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd81bc  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd81c5  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd81ce  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd81d7  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd81e0  add rsp, 0xF0
000079f4d2dd81e7  pop r11
000079f4d2dd81e9  pop r10
000079f4d2dd81eb  pop r9
000079f4d2dd81ed  pop r8
000079f4d2dd81ef  pop rsi
000079f4d2dd81f0  pop rdi
000079f4d2dd81f1  pop rdx
000079f4d2dd81f2  pop rcx
000079f4d2dd81f3  pop rax
000079f4d2dd81f4  add rsp, 0x08
000079f4d2dd81f8  jmp 0x000079F4D2DD3498
000079f4d2dd81fd  sub rsp, 0x08
000079f4d2dd8201  push rax
000079f4d2dd8202  push rcx
000079f4d2dd8203  push rdx
000079f4d2dd8204  push rdi
000079f4d2dd8205  push rsi
000079f4d2dd8206  push r8
000079f4d2dd8208  push r9
000079f4d2dd820a  push r10
000079f4d2dd820c  push r11
000079f4d2dd820e  sub rsp, 0xF0
000079f4d2dd8215  vmovaps [rsp], xmm0
000079f4d2dd821a  vmovaps [rsp+0x10], xmm1
000079f4d2dd8220  vmovaps [rsp+0x20], xmm2
000079f4d2dd8226  vmovaps [rsp+0x30], xmm3
000079f4d2dd822c  vmovaps [rsp+0x40], xmm4
000079f4d2dd8232  vmovaps [rsp+0x50], xmm5
000079f4d2dd8238  vmovaps [rsp+0x60], xmm6
000079f4d2dd823e  vmovaps [rsp+0x70], xmm7
000079f4d2dd8244  vmovaps [rsp+0x80], xmm8
000079f4d2dd824d  vmovaps [rsp+0x90], xmm9
000079f4d2dd8256  vmovaps [rsp+0xA0], xmm11
000079f4d2dd825f  vmovaps [rsp+0xB0], xmm12
000079f4d2dd8268  vmovaps [rsp+0xC0], xmm13
000079f4d2dd8271  vmovaps [rsp+0xD0], xmm14
000079f4d2dd827a  vmovaps [rsp+0xE0], xmm15
000079f4d2dd8283  sub rsp, 0x30
000079f4d2dd8287  movaps [rsp], xmm10
000079f4d2dd828c  movaps [rsp+0x10], xmm11
000079f4d2dd8292  movaps [rsp+0x20], xmm13
000079f4d2dd8298  lea rdi, [rsp]
000079f4d2dd829c  mov esi, 0x00
000079f4d2dd82a1  mov rax, 0x5D9EC01E8530
000079f4d2dd82ab  call rax
000079f4d2dd82ad  movaps xmm10, [rsp]
000079f4d2dd82b2  add rsp, 0x30
000079f4d2dd82b6  vmovaps xmm0, [rsp]
000079f4d2dd82bb  vmovaps xmm1, [rsp+0x10]
000079f4d2dd82c1  vmovaps xmm2, [rsp+0x20]
000079f4d2dd82c7  vmovaps xmm3, [rsp+0x30]
000079f4d2dd82cd  vmovaps xmm4, [rsp+0x40]
000079f4d2dd82d3  vmovaps xmm5, [rsp+0x50]
000079f4d2dd82d9  vmovaps xmm6, [rsp+0x60]
000079f4d2dd82df  vmovaps xmm7, [rsp+0x70]
000079f4d2dd82e5  vmovaps xmm8, [rsp+0x80]
000079f4d2dd82ee  vmovaps xmm9, [rsp+0x90]
000079f4d2dd82f7  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd8300  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd8309  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd8312  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd831b  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd8324  add rsp, 0xF0
000079f4d2dd832b  pop r11
000079f4d2dd832d  pop r10
000079f4d2dd832f  pop r9
000079f4d2dd8331  pop r8
000079f4d2dd8333  pop rsi
000079f4d2dd8334  pop rdi
000079f4d2dd8335  pop rdx
000079f4d2dd8336  pop rcx
000079f4d2dd8337  pop rax
000079f4d2dd8338  add rsp, 0x08
000079f4d2dd833c  jmp 0x000079F4D2DD34C6
000079f4d2dd8341  sub rsp, 0x08
000079f4d2dd8345  push rax
000079f4d2dd8346  push rcx
000079f4d2dd8347  push rdx
000079f4d2dd8348  push rdi
000079f4d2dd8349  push rsi
000079f4d2dd834a  push r8
000079f4d2dd834c  push r9
000079f4d2dd834e  push r10
000079f4d2dd8350  push r11
000079f4d2dd8352  sub rsp, 0xF0
000079f4d2dd8359  vmovaps [rsp], xmm0
000079f4d2dd835e  vmovaps [rsp+0x10], xmm1
000079f4d2dd8364  vmovaps [rsp+0x20], xmm2
000079f4d2dd836a  vmovaps [rsp+0x30], xmm3
000079f4d2dd8370  vmovaps [rsp+0x40], xmm4
000079f4d2dd8376  vmovaps [rsp+0x50], xmm5
000079f4d2dd837c  vmovaps [rsp+0x60], xmm6
000079f4d2dd8382  vmovaps [rsp+0x70], xmm7
000079f4d2dd8388  vmovaps [rsp+0x80], xmm8
000079f4d2dd8391  vmovaps [rsp+0x90], xmm9
000079f4d2dd839a  vmovaps [rsp+0xA0], xmm10
000079f4d2dd83a3  vmovaps [rsp+0xB0], xmm12
000079f4d2dd83ac  vmovaps [rsp+0xC0], xmm13
000079f4d2dd83b5  vmovaps [rsp+0xD0], xmm14
000079f4d2dd83be  vmovaps [rsp+0xE0], xmm15
000079f4d2dd83c7  sub rsp, 0x30
000079f4d2dd83cb  movaps [rsp], xmm11
000079f4d2dd83d0  movaps [rsp+0x10], xmm14
000079f4d2dd83d6  movaps [rsp+0x20], xmm13
000079f4d2dd83dc  lea rdi, [rsp]
000079f4d2dd83e0  mov esi, 0x00
000079f4d2dd83e5  mov rax, 0x5D9EC01E8530
000079f4d2dd83ef  call rax
000079f4d2dd83f1  movaps xmm11, [rsp]
000079f4d2dd83f6  add rsp, 0x30
000079f4d2dd83fa  vmovaps xmm0, [rsp]
000079f4d2dd83ff  vmovaps xmm1, [rsp+0x10]
000079f4d2dd8405  vmovaps xmm2, [rsp+0x20]
000079f4d2dd840b  vmovaps xmm3, [rsp+0x30]
000079f4d2dd8411  vmovaps xmm4, [rsp+0x40]
000079f4d2dd8417  vmovaps xmm5, [rsp+0x50]
000079f4d2dd841d  vmovaps xmm6, [rsp+0x60]
000079f4d2dd8423  vmovaps xmm7, [rsp+0x70]
000079f4d2dd8429  vmovaps xmm8, [rsp+0x80]
000079f4d2dd8432  vmovaps xmm9, [rsp+0x90]
000079f4d2dd843b  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd8444  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd844d  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd8456  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd845f  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd8468  add rsp, 0xF0
000079f4d2dd846f  pop r11
000079f4d2dd8471  pop r10
000079f4d2dd8473  pop r9
000079f4d2dd8475  pop r8
000079f4d2dd8477  pop rsi
000079f4d2dd8478  pop rdi
000079f4d2dd8479  pop rdx
000079f4d2dd847a  pop rcx
000079f4d2dd847b  pop rax
000079f4d2dd847c  add rsp, 0x08
000079f4d2dd8480  jmp 0x000079F4D2DD34F4
000079f4d2dd8485  sub rsp, 0x08
000079f4d2dd8489  push rax
000079f4d2dd848a  push rcx
000079f4d2dd848b  push rdx
000079f4d2dd848c  push rdi
000079f4d2dd848d  push rsi
000079f4d2dd848e  push r8
000079f4d2dd8490  push r9
000079f4d2dd8492  push r10
000079f4d2dd8494  push r11
000079f4d2dd8496  sub rsp, 0xF0
000079f4d2dd849d  vmovaps [rsp], xmm0
000079f4d2dd84a2  vmovaps [rsp+0x10], xmm1
000079f4d2dd84a8  vmovaps [rsp+0x20], xmm2
000079f4d2dd84ae  vmovaps [rsp+0x30], xmm3
000079f4d2dd84b4  vmovaps [rsp+0x40], xmm4
000079f4d2dd84ba  vmovaps [rsp+0x50], xmm5
000079f4d2dd84c0  vmovaps [rsp+0x60], xmm6
000079f4d2dd84c6  vmovaps [rsp+0x70], xmm7
000079f4d2dd84cc  vmovaps [rsp+0x80], xmm8
000079f4d2dd84d5  vmovaps [rsp+0x90], xmm9
000079f4d2dd84de  vmovaps [rsp+0xA0], xmm10
000079f4d2dd84e7  vmovaps [rsp+0xB0], xmm11
000079f4d2dd84f0  vmovaps [rsp+0xC0], xmm12
000079f4d2dd84f9  vmovaps [rsp+0xD0], xmm13
000079f4d2dd8502  vmovaps [rsp+0xE0], xmm15
000079f4d2dd850b  sub rsp, 0x30
000079f4d2dd850f  movaps [rsp], xmm14
000079f4d2dd8514  movaps [rsp+0x10], xmm12
000079f4d2dd851a  movaps [rsp+0x20], xmm9
000079f4d2dd8520  lea rdi, [rsp]
000079f4d2dd8524  mov esi, 0x00
000079f4d2dd8529  mov rax, 0x5D9EC01E8530
000079f4d2dd8533  call rax
000079f4d2dd8535  movaps xmm14, [rsp]
000079f4d2dd853a  add rsp, 0x30
000079f4d2dd853e  vmovaps xmm0, [rsp]
000079f4d2dd8543  vmovaps xmm1, [rsp+0x10]
000079f4d2dd8549  vmovaps xmm2, [rsp+0x20]
000079f4d2dd854f  vmovaps xmm3, [rsp+0x30]
000079f4d2dd8555  vmovaps xmm4, [rsp+0x40]
000079f4d2dd855b  vmovaps xmm5, [rsp+0x50]
000079f4d2dd8561  vmovaps xmm6, [rsp+0x60]
000079f4d2dd8567  vmovaps xmm7, [rsp+0x70]
000079f4d2dd856d  vmovaps xmm8, [rsp+0x80]
000079f4d2dd8576  vmovaps xmm9, [rsp+0x90]
000079f4d2dd857f  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd8588  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd8591  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd859a  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd85a3  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd85ac  add rsp, 0xF0
000079f4d2dd85b3  pop r11
000079f4d2dd85b5  pop r10
000079f4d2dd85b7  pop r9
000079f4d2dd85b9  pop r8
000079f4d2dd85bb  pop rsi
000079f4d2dd85bc  pop rdi
000079f4d2dd85bd  pop rdx
000079f4d2dd85be  pop rcx
000079f4d2dd85bf  pop rax
000079f4d2dd85c0  add rsp, 0x08
000079f4d2dd85c4  jmp 0x000079F4D2DD350F
000079f4d2dd85c9  sub rsp, 0x08
000079f4d2dd85cd  push rax
000079f4d2dd85ce  push rcx
000079f4d2dd85cf  push rdx
000079f4d2dd85d0  push rdi
000079f4d2dd85d1  push rsi
000079f4d2dd85d2  push r8
000079f4d2dd85d4  push r9
000079f4d2dd85d6  push r10
000079f4d2dd85d8  push r11
000079f4d2dd85da  sub rsp, 0xF0
000079f4d2dd85e1  vmovaps [rsp], xmm0
000079f4d2dd85e6  vmovaps [rsp+0x10], xmm1
000079f4d2dd85ec  vmovaps [rsp+0x20], xmm2
000079f4d2dd85f2  vmovaps [rsp+0x30], xmm3
000079f4d2dd85f8  vmovaps [rsp+0x40], xmm4
000079f4d2dd85fe  vmovaps [rsp+0x50], xmm5
000079f4d2dd8604  vmovaps [rsp+0x60], xmm6
000079f4d2dd860a  vmovaps [rsp+0x70], xmm7
000079f4d2dd8610  vmovaps [rsp+0x80], xmm8
000079f4d2dd8619  vmovaps [rsp+0x90], xmm9
000079f4d2dd8622  vmovaps [rsp+0xA0], xmm10
000079f4d2dd862b  vmovaps [rsp+0xB0], xmm11
000079f4d2dd8634  vmovaps [rsp+0xC0], xmm12
000079f4d2dd863d  vmovaps [rsp+0xD0], xmm14
000079f4d2dd8646  vmovaps [rsp+0xE0], xmm15
000079f4d2dd864f  sub rsp, 0x30
000079f4d2dd8653  movaps [rsp], xmm13
000079f4d2dd8658  movaps [rsp+0x10], xmm8
000079f4d2dd865e  movaps [rsp+0x20], xmm15
000079f4d2dd8664  lea rdi, [rsp]
000079f4d2dd8668  mov esi, 0x00
000079f4d2dd866d  mov rax, 0x5D9EC01E8530
000079f4d2dd8677  call rax
000079f4d2dd8679  movaps xmm13, [rsp]
000079f4d2dd867e  add rsp, 0x30
000079f4d2dd8682  vmovaps xmm0, [rsp]
000079f4d2dd8687  vmovaps xmm1, [rsp+0x10]
000079f4d2dd868d  vmovaps xmm2, [rsp+0x20]
000079f4d2dd8693  vmovaps xmm3, [rsp+0x30]
000079f4d2dd8699  vmovaps xmm4, [rsp+0x40]
000079f4d2dd869f  vmovaps xmm5, [rsp+0x50]
000079f4d2dd86a5  vmovaps xmm6, [rsp+0x60]
000079f4d2dd86ab  vmovaps xmm7, [rsp+0x70]
000079f4d2dd86b1  vmovaps xmm8, [rsp+0x80]
000079f4d2dd86ba  vmovaps xmm9, [rsp+0x90]
000079f4d2dd86c3  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd86cc  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd86d5  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd86de  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd86e7  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd86f0  add rsp, 0xF0
000079f4d2dd86f7  pop r11
000079f4d2dd86f9  pop r10
000079f4d2dd86fb  pop r9
000079f4d2dd86fd  pop r8
000079f4d2dd86ff  pop rsi
000079f4d2dd8700  pop rdi
000079f4d2dd8701  pop rdx
000079f4d2dd8702  pop rcx
000079f4d2dd8703  pop rax
000079f4d2dd8704  add rsp, 0x08
000079f4d2dd8708  jmp 0x000079F4D2DD3532
000079f4d2dd870d  sub rsp, 0x08
000079f4d2dd8711  push rax
000079f4d2dd8712  push rcx
000079f4d2dd8713  push rdx
000079f4d2dd8714  push rdi
000079f4d2dd8715  push rsi
000079f4d2dd8716  push r8
000079f4d2dd8718  push r9
000079f4d2dd871a  push r10
000079f4d2dd871c  push r11
000079f4d2dd871e  sub rsp, 0xF0
000079f4d2dd8725  vmovaps [rsp], xmm0
000079f4d2dd872a  vmovaps [rsp+0x10], xmm1
000079f4d2dd8730  vmovaps [rsp+0x20], xmm2
000079f4d2dd8736  vmovaps [rsp+0x30], xmm3
000079f4d2dd873c  vmovaps [rsp+0x40], xmm4
000079f4d2dd8742  vmovaps [rsp+0x50], xmm5
000079f4d2dd8748  vmovaps [rsp+0x60], xmm6
000079f4d2dd874e  vmovaps [rsp+0x70], xmm7
000079f4d2dd8754  vmovaps [rsp+0x80], xmm8
000079f4d2dd875d  vmovaps [rsp+0x90], xmm9
000079f4d2dd8766  vmovaps [rsp+0xA0], xmm10
000079f4d2dd876f  vmovaps [rsp+0xB0], xmm11
000079f4d2dd8778  vmovaps [rsp+0xC0], xmm12
000079f4d2dd8781  vmovaps [rsp+0xD0], xmm13
000079f4d2dd878a  vmovaps [rsp+0xE0], xmm14
000079f4d2dd8793  sub rsp, 0x30
000079f4d2dd8797  movaps [rsp], xmm15
000079f4d2dd879c  movaps [rsp+0x10], xmm1
000079f4d2dd87a1  movaps [rsp+0x20], xmm10
000079f4d2dd87a7  lea rdi, [rsp]
000079f4d2dd87ab  mov esi, 0x00
000079f4d2dd87b0  mov rax, 0x5D9EC01E8530
000079f4d2dd87ba  call rax
000079f4d2dd87bc  movaps xmm15, [rsp]
000079f4d2dd87c1  add rsp, 0x30
000079f4d2dd87c5  vmovaps xmm0, [rsp]
000079f4d2dd87ca  vmovaps xmm1, [rsp+0x10]
000079f4d2dd87d0  vmovaps xmm2, [rsp+0x20]
000079f4d2dd87d6  vmovaps xmm3, [rsp+0x30]
000079f4d2dd87dc  vmovaps xmm4, [rsp+0x40]
000079f4d2dd87e2  vmovaps xmm5, [rsp+0x50]
000079f4d2dd87e8  vmovaps xmm6, [rsp+0x60]
000079f4d2dd87ee  vmovaps xmm7, [rsp+0x70]
000079f4d2dd87f4  vmovaps xmm8, [rsp+0x80]
000079f4d2dd87fd  vmovaps xmm9, [rsp+0x90]
000079f4d2dd8806  vmovaps xmm10, [rsp+0xA0]
000079f4d2dd880f  vmovaps xmm11, [rsp+0xB0]
000079f4d2dd8818  vmovaps xmm12, [rsp+0xC0]
000079f4d2dd8821  vmovaps xmm13, [rsp+0xD0]
000079f4d2dd882a  vmovaps xmm14, [rsp+0xE0]
000079f4d2dd8833  add rsp, 0xF0
000079f4d2dd883a  pop r11
000079f4d2dd883c  pop r10
000079f4d2dd883e  pop r9
000079f4d2dd8840  pop r8
000079f4d2dd8842  pop rsi
000079f4d2dd8843  pop rdi
000079f4d2dd8844  pop rdx
000079f4d2dd8845  pop rcx
000079f4d2dd8846  pop rax
000079f4d2dd8847  add rsp, 0x08
000079f4d2dd884b  jmp 0x000079F4D2DD3555
000079f4d2dd8850  sub rsp, 0x08
000079f4d2dd8854  push rax
000079f4d2dd8855  push rcx
000079f4d2dd8856  push rdx
000079f4d2dd8857  push rdi
000079f4d2dd8858  push rsi
000079f4d2dd8859  push r8
000079f4d2dd885b  push r9
000079f4d2dd885d  push r10
000079f4d2dd885f  push r11
000079f4d2dd8861  sub rsp, 0xF0
000079f4d2dd8868  vmovaps [rsp], xmm0
000079f4d2dd886d  vmovaps [rsp+0x10], xmm2
000079f4d2dd8873  vmovaps [rsp+0x20], xmm3
000079f4d2dd8879  vmovaps [rsp+0x30], xmm4
000079f4d2dd887f  vmovaps [rsp+0x40], xmm5
000079f4d2dd8885  vmovaps [rsp+0x50], xmm6
000079f4d2dd888b  vmovaps [rsp+0x60], xmm7
000079f4d2dd8891  vmovaps [rsp+0x70], xmm8
000079f4d2dd8897  vmovaps [rsp+0x80], xmm9
000079f4d2dd88a0  vmovaps [rsp+0x90], xmm10
000079f4d2dd88a9  vmovaps [rsp+0xA0], xmm11
000079f4d2dd88b2  vmovaps [rsp+0xB0], xmm12
000079f4d2dd88bb  vmovaps [rsp+0xC0], xmm13
000079f4d2dd88c4  vmovaps [rsp+0xD0], xmm14
000079f4d2dd88cd  vmovaps [rsp+0xE0], xmm15
000079f4d2dd88d6  sub rsp, 0x30
000079f4d2dd88da  movaps [rsp], xmm1
000079f4d2dd88de  movaps [rsp+0x10], xmm7
000079f4d2dd88e3  movaps [rsp+0x20], xmm11
000079f4d2dd88e9  lea rdi, [rsp]
000079f4d2dd88ed  mov esi, 0x00
000079f4d2dd88f2  mov rax, 0x5D9EC01E8530
000079f4d2dd88fc  call rax
000079f4d2dd88fe  movaps xmm1, [rsp]
000079f4d2dd8902  add rsp, 0x30
000079f4d2dd8906  vmovaps xmm0, [rsp]
000079f4d2dd890b  vmovaps xmm2, [rsp+0x10]
000079f4d2dd8911  vmovaps xmm3, [rsp+0x20]
000079f4d2dd8917  vmovaps xmm4, [rsp+0x30]
000079f4d2dd891d  vmovaps xmm5, [rsp+0x40]
000079f4d2dd8923  vmovaps xmm6, [rsp+0x50]
000079f4d2dd8929  vmovaps xmm7, [rsp+0x60]
000079f4d2dd892f  vmovaps xmm8, [rsp+0x70]
000079f4d2dd8935  vmovaps xmm9, [rsp+0x80]
000079f4d2dd893e  vmovaps xmm10, [rsp+0x90]
000079f4d2dd8947  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd8950  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd8959  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd8962  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd896b  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd8974  add rsp, 0xF0
000079f4d2dd897b  pop r11
000079f4d2dd897d  pop r10
000079f4d2dd897f  pop r9
000079f4d2dd8981  pop r8
000079f4d2dd8983  pop rsi
000079f4d2dd8984  pop rdi
000079f4d2dd8985  pop rdx
000079f4d2dd8986  pop rcx
000079f4d2dd8987  pop rax
000079f4d2dd8988  add rsp, 0x08
000079f4d2dd898c  jmp 0x000079F4D2DD3576
000079f4d2dd8991  call 0x000079F4D2C0D600
000079f4d2dd8996  jmp 0x000079F4D2DD3589
000079f4d2dd899b  call 0x000079F4D2C0C380
000079f4d2dd89a0  jmp 0x000079F4D2DD3594
000079f4d2dd89a5  call 0x000079F4D2C0E880
000079f4d2dd89aa  jmp 0x000079F4D2DD359F
000079f4d2dd89af  call 0x000079F4D2BFF540
000079f4d2dd89b4  jmp 0x000079F4D2DD35AA
000079f4d2dd89b9  int3
000079f4d2dd89ba  nop [rax+rax*1], ax
000079f4d2dd89c0  mov rax, [r15+0x40]
000079f4d2dd89c4  mov r14, [r15+0x58]
000079f4d2dd89c8  lea r12, [rax+r14*1]
000079f4d2dd89cc  movaps xmm1, [r15+0x1D0]
000079f4d2dd89d4  vmovaps [rsp+0x10], xmm1
000079f4d2dd89da  vmovaps xmm15, [rsp+0x10]
000079f4d2dd89e0  por xmm1, xmm15
000079f4d2dd89e5  movaps xmm14, [r15+0x1A0]
000079f4d2dd89ed  vmovaps [rsp+0x10], xmm14
000079f4d2dd89f3  vmovaps xmm13, [rsp+0x10]
000079f4d2dd89f9  por xmm14, xmm13
000079f4d2dd89fe  lea rax, [r12+0x30]
000079f4d2dd8a03  mov r11, [r13+rax*1]
000079f4d2dd8a08  lea rax, [r12+0x38]
000079f4d2dd8a0d  mov r10, [r13+rax*1]
000079f4d2dd8a12  movq xmm13, r11
000079f4d2dd8a17  movq xmm12, r10
000079f4d2dd8a1c  movq xmm13, xmm13
000079f4d2dd8a21  vmovaps [rsp+0x10], xmm13
000079f4d2dd8a27  movq xmm13, xmm13
000079f4d2dd8a2c  movaps [r15+0x130], xmm13
000079f4d2dd8a34  movq xmm12, xmm12
000079f4d2dd8a39  vmovaps [rsp+0x20], xmm12
000079f4d2dd8a3f  movq xmm12, xmm12
000079f4d2dd8a44  movaps [r15+0x280], xmm12
000079f4d2dd8a4c  movaps xmm13, [r15+0x270]
000079f4d2dd8a54  vmovaps [rsp+0x30], xmm13
000079f4d2dd8a5a  vmovaps xmm12, [rsp+0x30]
000079f4d2dd8a60  por xmm13, xmm12
000079f4d2dd8a65  lea rax, [r12+0x20]
000079f4d2dd8a6a  mov r11, [r13+rax*1]
000079f4d2dd8a6f  lea rax, [r12+0x28]
000079f4d2dd8a74  mov r10, [r13+rax*1]
000079f4d2dd8a79  movq xmm12, r11
000079f4d2dd8a7e  movq xmm11, r10
000079f4d2dd8a83  movq xmm12, xmm12
000079f4d2dd8a88  vmovaps [rsp+0x30], xmm12
000079f4d2dd8a8e  movq xmm12, xmm12
000079f4d2dd8a93  movaps [r15+0x150], xmm12
000079f4d2dd8a9b  movq xmm11, xmm11
000079f4d2dd8aa0  vmovaps [rsp+0x40], xmm11
000079f4d2dd8aa6  movq xmm11, xmm11
000079f4d2dd8aab  movaps [r15+0x140], xmm11
000079f4d2dd8ab3  lea rax, [r12+0x10]
000079f4d2dd8ab8  mov r11, [r13+rax*1]
000079f4d2dd8abd  lea rax, [r12+0x18]
000079f4d2dd8ac2  mov r10, [r13+rax*1]
000079f4d2dd8ac7  movq xmm12, r11
000079f4d2dd8acc  movq xmm11, r10
000079f4d2dd8ad1  movq xmm12, xmm12
000079f4d2dd8ad6  vmovaps [rsp+0x50], xmm12
000079f4d2dd8adc  movq xmm12, xmm12
000079f4d2dd8ae1  movaps [r15+0x170], xmm12
000079f4d2dd8ae9  movq xmm11, xmm11
000079f4d2dd8aee  vmovaps [rsp+0x60], xmm11
000079f4d2dd8af4  movq xmm11, xmm11
000079f4d2dd8af9  movaps [r15+0x160], xmm11
000079f4d2dd8b01  mov rax, [r13+r12*1]
000079f4d2dd8b06  vmovq xmm12, rax
000079f4d2dd8b0b  vpbroadcastq xmm12, xmm12
000079f4d2dd8b10  lea rax, [r12+0x08]
000079f4d2dd8b15  mov r12, [r13+rax*1]
000079f4d2dd8b1a  movq xmm11, r12
000079f4d2dd8b1f  movaps [r15+0x230], xmm11
000079f4d2dd8b27  mov rax, [r15+0xF8]
000079f4d2dd8b2e  lea r12, [rax+0x50]
000079f4d2dd8b32  movups xmm11, [r13+r12*1]
000079f4d2dd8b38  lea r12, [rax+0x60]
000079f4d2dd8b3c  movups xmm10, [r13+r12*1]
000079f4d2dd8b42  lea r12, [rax+0x30]
000079f4d2dd8b46  movups xmm9, [r13+r12*1]
000079f4d2dd8b4c  mov r12, [r15+0x50]
000079f4d2dd8b50  lea r11, [r12+r14*1]
000079f4d2dd8b54  mov [r15+0x60], r11
000079f4d2dd8b58  lea r12, [r14+0x40]
000079f4d2dd8b5c  mov [r15+0x58], r12
000079f4d2dd8b60  movaps xmm8, xmm12
000079f4d2dd8b64  mulpd xmm8, xmm15
000079f4d2dd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000079f4d2dd8b6f  ptest xmm7, xmm7
000079f4d2dd8b74  jnz 0x000079F4D2DD9997
000079f4d2dd8b7a  movq xmm15, qword ptr [r15+0x230]
000079f4d2dd8b83  vmovaps [rsp+0x70], xmm15
000079f4d2dd8b89  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd8b8f  movaps xmm7, xmm9
000079f4d2dd8b93  mulpd xmm7, xmm15
000079f4d2dd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000079f4d2dd8b9d  ptest xmm6, xmm6
000079f4d2dd8ba2  jnz 0x000079F4D2DD9ADB
000079f4d2dd8ba8  vxorps xmm15, xmm15, xmm15
000079f4d2dd8bad  vpbroadcastq xmm15, xmm15
000079f4d2dd8bb2  movaps xmm9, xmm12
000079f4d2dd8bb6  mulpd xmm9, xmm10
000079f4d2dd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000079f4d2dd8bc1  ptest xmm6, xmm6
000079f4d2dd8bc6  jnz 0x000079F4D2DD9C1D
000079f4d2dd8bcc  movaps xmm10, xmm12
000079f4d2dd8bd0  mulpd xmm10, xmm11
000079f4d2dd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000079f4d2dd8bdb  ptest xmm6, xmm6
000079f4d2dd8be0  jnz 0x000079F4D2DD9D61
000079f4d2dd8be6  movaps xmm11, [r15+0x1F0]
000079f4d2dd8bee  movaps xmm6, xmm12
000079f4d2dd8bf2  mulpd xmm6, xmm11
000079f4d2dd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000079f4d2dd8bfc  ptest xmm5, xmm5
000079f4d2dd8c01  jnz 0x000079F4D2DD9EA5
000079f4d2dd8c07  movaps xmm12, [r15+0x2A0]
000079f4d2dd8c0f  vmovaps [rsp+0x80], xmm12
000079f4d2dd8c18  vmovaps xmm11, [rsp+0x80]
000079f4d2dd8c21  por xmm12, xmm11
000079f4d2dd8c26  movaps xmm11, [r15+0x250]
000079f4d2dd8c2e  vmovaps [rsp+0x80], xmm11
000079f4d2dd8c37  vmovaps xmm5, [rsp+0x80]
000079f4d2dd8c40  por xmm11, xmm5
000079f4d2dd8c45  vmovaps xmm4, [rsp+0x70]
000079f4d2dd8c4b  vpermilpd xmm4, xmm4, 0x00
000079f4d2dd8c51  movaps xmm3, xmm5
000079f4d2dd8c54  mulpd xmm3, xmm4
000079f4d2dd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000079f4d2dd8c5d  ptest xmm2, xmm2
000079f4d2dd8c62  jnz 0x000079F4D2DD9FE7
000079f4d2dd8c68  mov [rsp+0x80], rax
000079f4d2dd8c70  xor eax, eax
000079f4d2dd8c72  mov r14d, 0x200
000079f4d2dd8c78  cmp r12, r14
000079f4d2dd8c7b  cmc
000079f4d2dd8c7c  lahf
000079f4d2dd8c7d  seto al
000079f4d2dd8c80  mov [r15+0x108], eax
000079f4d2dd8c87  movaps xmm5, xmm8
000079f4d2dd8c8b  addpd xmm5, xmm15
000079f4d2dd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000079f4d2dd8c95  ptest xmm4, xmm4
000079f4d2dd8c9a  jnz 0x000079F4D2DDA127
000079f4d2dd8ca0  movaps xmm8, [r15+0x1B0]
000079f4d2dd8ca8  movaps xmm4, xmm9
000079f4d2dd8cac  addpd xmm4, xmm8
000079f4d2dd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000079f4d2dd8cb6  ptest xmm2, xmm2
000079f4d2dd8cbb  jnz 0x000079F4D2DDA269
000079f4d2dd8cc1  movaps xmm9, xmm10
000079f4d2dd8cc5  addpd xmm9, xmm8
000079f4d2dd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000079f4d2dd8cd0  ptest xmm2, xmm2
000079f4d2dd8cd5  jnz 0x000079F4D2DDA3AB
000079f4d2dd8cdb  movaps xmm10, [r15+0x2F0]
000079f4d2dd8ce3  vmovaps [rsp+0x90], xmm10
000079f4d2dd8cec  vmovaps xmm8, [rsp+0x90]
000079f4d2dd8cf5  por xmm10, xmm8
000079f4d2dd8cfa  movaps xmm8, [r15+0x2E0]
000079f4d2dd8d02  vmovaps [rsp+0x90], xmm8
000079f4d2dd8d0b  vmovaps xmm2, [rsp+0x90]
000079f4d2dd8d14  por xmm8, xmm2
000079f4d2dd8d19  movaps xmm2, [r15+0x2D0]
000079f4d2dd8d21  vmovaps [rsp+0x90], xmm2
000079f4d2dd8d2a  vmovaps [rsp+0xA0], xmm1
000079f4d2dd8d33  vmovaps xmm1, [rsp+0x90]
000079f4d2dd8d3c  por xmm2, xmm1
000079f4d2dd8d40  movaps xmm1, [r15+0x200]
000079f4d2dd8d48  vmovaps [rsp+0x90], xmm1
000079f4d2dd8d51  vmovaps [rsp+0xB0], xmm15
000079f4d2dd8d5a  vmovaps xmm15, [rsp+0x90]
000079f4d2dd8d63  por xmm1, xmm15
000079f4d2dd8d68  movaps xmm15, [r15+0x1C0]
000079f4d2dd8d70  vmovaps [rsp+0x90], xmm15
000079f4d2dd8d79  vmovaps [rsp+0xC0], xmm1
000079f4d2dd8d82  vmovaps xmm1, [rsp+0x90]
000079f4d2dd8d8b  por xmm15, xmm1
000079f4d2dd8d90  movaps xmm1, [r15+0x190]
000079f4d2dd8d98  vmovaps [rsp+0x90], xmm1
000079f4d2dd8da1  vmovaps [rsp+0xD0], xmm15
000079f4d2dd8daa  vmovaps xmm15, [rsp+0x90]
000079f4d2dd8db3  por xmm1, xmm15
000079f4d2dd8db8  movaps xmm15, [r15+0x300]
000079f4d2dd8dc0  vmovaps [rsp+0x90], xmm15
000079f4d2dd8dc9  vmovaps [rsp+0xE0], xmm1
000079f4d2dd8dd2  vmovaps xmm1, [rsp+0x90]
000079f4d2dd8ddb  por xmm15, xmm1
000079f4d2dd8de0  mov rax, [rsp+0x80]
000079f4d2dd8de8  lea r14, [rax+0xA0]
000079f4d2dd8def  movups xmm1, [r13+r14*1]
000079f4d2dd8df5  lea r14, [rax+0xB0]
000079f4d2dd8dfc  vmovaps [rsp+0x80], xmm1
000079f4d2dd8e05  movups xmm1, [r13+r14*1]
000079f4d2dd8e0b  vmovaps [rsp+0x90], xmm1
000079f4d2dd8e14  vmovaps [rsp+0xF0], xmm15
000079f4d2dd8e1d  vmovaps xmm15, [rsp+0xB0]
000079f4d2dd8e26  vmovaps [rsp+0xB0], xmm14
000079f4d2dd8e2f  movaps xmm1, xmm6
000079f4d2dd8e32  addpd xmm1, xmm15
000079f4d2dd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000079f4d2dd8e3c  ptest xmm14, xmm14
000079f4d2dd8e42  jnz 0x000079F4D2DDA503
000079f4d2dd8e48  lea r14, [rax+0xF0]
000079f4d2dd8e4f  movups xmm15, [r13+r14*1]
000079f4d2dd8e55  movaps xmm14, xmm4
000079f4d2dd8e59  addpd xmm14, xmm3
000079f4d2dd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000079f4d2dd8e64  ptest xmm6, xmm6
000079f4d2dd8e69  jnz 0x000079F4D2DDA64E
000079f4d2dd8e6f  movaps xmm6, xmm9
000079f4d2dd8e73  addpd xmm6, xmm7
000079f4d2dd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000079f4d2dd8e7c  ptest xmm4, xmm4
000079f4d2dd8e81  jnz 0x000079F4D2DDA790
000079f4d2dd8e87  vmovaps xmm9, [rsp+0x70]
000079f4d2dd8e8d  vpermilpd xmm9, xmm9, 0x00
000079f4d2dd8e93  vmovaps xmm4, [rsp+0x90]
000079f4d2dd8e9c  movaps xmm7, xmm4
000079f4d2dd8e9f  mulpd xmm7, xmm9
000079f4d2dd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000079f4d2dd8ea9  ptest xmm3, xmm3
000079f4d2dd8eae  jnz 0x000079F4D2DDA8D1
000079f4d2dd8eb4  vmovaps xmm9, [rsp+0x50]
000079f4d2dd8eba  vpermilpd xmm9, xmm9, 0x00
000079f4d2dd8ec0  movaps xmm4, xmm15
000079f4d2dd8ec4  mulpd xmm4, xmm9
000079f4d2dd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000079f4d2dd8ece  ptest xmm3, xmm3
000079f4d2dd8ed3  jnz 0x000079F4D2DDAA12
000079f4d2dd8ed9  lea r14, [rax+0xE0]
000079f4d2dd8ee0  movups xmm15, [r13+r14*1]
000079f4d2dd8ee6  vmovaps xmm9, [rsp+0x70]
000079f4d2dd8eec  vpermilpd xmm9, xmm9, 0x00
000079f4d2dd8ef2  vmovaps [rsp+0x70], xmm1
000079f4d2dd8ef8  vmovaps xmm1, [rsp+0x80]
000079f4d2dd8f01  vmovaps [rsp+0x80], xmm15
000079f4d2dd8f0a  movaps xmm3, xmm1
000079f4d2dd8f0d  mulpd xmm3, xmm9
000079f4d2dd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000079f4d2dd8f17  ptest xmm15, xmm15
000079f4d2dd8f1d  jnz 0x000079F4D2DDAB5E
000079f4d2dd8f23  vmovaps xmm1, [rsp+0xF0]
000079f4d2dd8f2c  vmovaps xmm15, [rsp+0xF0]
000079f4d2dd8f35  por xmm1, xmm15
000079f4d2dd8f3a  movaps [r15+0x300], xmm1
000079f4d2dd8f42  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd8f4b  vmovaps xmm9, [rsp+0xE0]
000079f4d2dd8f54  por xmm15, xmm9
000079f4d2dd8f59  movaps [r15+0x190], xmm15
000079f4d2dd8f61  vmovaps xmm9, [rsp+0x50]
000079f4d2dd8f67  vpermilpd xmm9, xmm9, 0x00
000079f4d2dd8f6d  vmovaps [rsp+0x90], xmm1
000079f4d2dd8f76  vmovaps [rsp+0xE0], xmm15
000079f4d2dd8f7f  vmovaps xmm15, [rsp+0x80]
000079f4d2dd8f88  vmovaps [rsp+0x80], xmm14
000079f4d2dd8f91  movaps xmm1, xmm15
000079f4d2dd8f95  mulpd xmm1, xmm9
000079f4d2dd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000079f4d2dd8f9f  ptest xmm14, xmm14
000079f4d2dd8fa5  jnz 0x000079F4D2DDAC9F
000079f4d2dd8fab  lea r14, [rax+0x90]
000079f4d2dd8fb2  movups xmm15, [r13+r14*1]
000079f4d2dd8fb8  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd8fc1  vmovaps xmm9, [rsp+0xD0]
000079f4d2dd8fca  por xmm14, xmm9
000079f4d2dd8fcf  movaps [r15+0x1C0], xmm14
000079f4d2dd8fd7  vmovaps xmm9, [rsp+0xC0]
000079f4d2dd8fe0  vmovaps [rsp+0xD0], xmm1
000079f4d2dd8fe9  vmovaps xmm1, [rsp+0xC0]
000079f4d2dd8ff2  por xmm9, xmm1
000079f4d2dd8ff7  movaps [r15+0x200], xmm9
000079f4d2dd8fff  vmovaps [rsp+0xC0], xmm2
000079f4d2dd9008  vmovaps xmm1, [rsp+0xC0]
000079f4d2dd9011  por xmm2, xmm1
000079f4d2dd9015  movaps [r15+0x2D0], xmm2
000079f4d2dd901d  vmovaps [rsp+0xC0], xmm8
000079f4d2dd9026  vmovaps xmm1, [rsp+0xC0]
000079f4d2dd902f  por xmm8, xmm1
000079f4d2dd9034  movaps [r15+0x2E0], xmm8
000079f4d2dd903c  vmovaps [rsp+0xC0], xmm15
000079f4d2dd9045  movaps xmm1, xmm5
000079f4d2dd9048  addpd xmm1, xmm7
000079f4d2dd904c  vcmppd xmm15, xmm1, xmm1, 0x03
000079f4d2dd9051  ptest xmm15, xmm15
000079f4d2dd9057  jnz 0x000079F4D2DDADEB
000079f4d2dd905d  vmovaps xmm15, [rsp+0x50]
000079f4d2dd9063  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd9069  vmovaps xmm5, [rsp+0xC0]
000079f4d2dd9072  vmovaps [rsp+0xC0], xmm1
000079f4d2dd907b  movaps xmm7, xmm5
000079f4d2dd907e  mulpd xmm7, xmm15
000079f4d2dd9083  vcmppd xmm1, xmm7, xmm7, 0x03
000079f4d2dd9088  ptest xmm1, xmm1
000079f4d2dd908d  jnz 0x000079F4D2DDAF2B
000079f4d2dd9093  lea r14, [rax+0x80]
000079f4d2dd909a  movups xmm1, [r13+r14*1]
000079f4d2dd90a0  vmovaps xmm5, [rsp+0x70]
000079f4d2dd90a6  vmovaps [rsp+0x70], xmm1
000079f4d2dd90ac  movaps xmm15, xmm5
000079f4d2dd90b0  addpd xmm15, xmm3
000079f4d2dd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000079f4d2dd90bb  ptest xmm1, xmm1
000079f4d2dd90c0  jnz 0x000079F4D2DDB076
000079f4d2dd90c6  vmovaps xmm5, [rsp+0x80]
000079f4d2dd90cf  movaps xmm1, xmm5
000079f4d2dd90d2  addpd xmm1, xmm4
000079f4d2dd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000079f4d2dd90db  ptest xmm3, xmm3
000079f4d2dd90e0  jnz 0x000079F4D2DDB1B8
000079f4d2dd90e6  vmovaps [rsp+0x80], xmm10
000079f4d2dd90ef  vmovaps xmm5, [rsp+0x80]
000079f4d2dd90f8  por xmm10, xmm5
000079f4d2dd90fd  movaps [r15+0x2F0], xmm10
000079f4d2dd9105  vmovaps xmm5, [rsp+0x50]
000079f4d2dd910b  vpermilpd xmm5, xmm5, 0x00
000079f4d2dd9111  vmovaps xmm3, [rsp+0x70]
000079f4d2dd9117  vmovaps [rsp+0x50], xmm1
000079f4d2dd911d  movaps xmm4, xmm3
000079f4d2dd9120  mulpd xmm4, xmm5
000079f4d2dd9124  vcmppd xmm1, xmm4, xmm4, 0x03
000079f4d2dd9129  ptest xmm1, xmm1
000079f4d2dd912e  jnz 0x000079F4D2DDB2F8
000079f4d2dd9134  lea r14, [rax+0xD0]
000079f4d2dd913b  movups xmm1, [r13+r14*1]
000079f4d2dd9141  vmovaps xmm3, [rsp+0xD0]
000079f4d2dd914a  vmovaps [rsp+0x70], xmm1
000079f4d2dd9150  movaps xmm5, xmm6
000079f4d2dd9153  addpd xmm5, xmm3
000079f4d2dd9157  vcmppd xmm1, xmm5, xmm5, 0x03
000079f4d2dd915c  ptest xmm1, xmm1
000079f4d2dd9161  jnz 0x000079F4D2DDB442
000079f4d2dd9167  vmovaps xmm1, [rsp+0x60]
000079f4d2dd916d  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd9173  movaps xmm6, xmm9
000079f4d2dd9177  mulpd xmm6, xmm1
000079f4d2dd917b  vcmppd xmm3, xmm6, xmm6, 0x03
000079f4d2dd9180  ptest xmm3, xmm3
000079f4d2dd9185  jnz 0x000079F4D2DDB582
000079f4d2dd918b  movaps [r15+0x260], xmm6
000079f4d2dd9193  vxorps xmm1, xmm1, xmm1
000079f4d2dd9197  vpbroadcastq xmm1, xmm1
000079f4d2dd919c  movaps [r15+0x1B0], xmm1
000079f4d2dd91a4  vmovaps xmm1, [rsp+0x60]
000079f4d2dd91aa  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd91b0  vmovaps xmm3, [rsp+0x70]
000079f4d2dd91b6  vmovaps [rsp+0x70], xmm15
000079f4d2dd91bc  movaps xmm9, xmm3
000079f4d2dd91c0  mulpd xmm9, xmm1
000079f4d2dd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000079f4d2dd91cb  ptest xmm15, xmm15
000079f4d2dd91d1  jnz 0x000079F4D2DDB6C3
000079f4d2dd91d7  lea r14, [rax+0xC0]
000079f4d2dd91de  movups xmm1, [r13+r14*1]
000079f4d2dd91e4  vmovaps xmm3, [rsp+0xC0]
000079f4d2dd91ed  vmovaps [rsp+0x80], xmm1
000079f4d2dd91f6  movaps xmm15, xmm3
000079f4d2dd91fa  addpd xmm15, xmm7
000079f4d2dd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000079f4d2dd9205  ptest xmm1, xmm1
000079f4d2dd920a  jnz 0x000079F4D2DDB80F
000079f4d2dd9210  vmovaps [rsp+0xC0], xmm13
000079f4d2dd9219  vmovaps xmm1, [rsp+0xC0]
000079f4d2dd9222  por xmm13, xmm1
000079f4d2dd9227  movaps [r15+0x270], xmm13
000079f4d2dd922f  vmovaps xmm1, [rsp+0xB0]
000079f4d2dd9238  vmovaps xmm7, [rsp+0xB0]
000079f4d2dd9241  por xmm1, xmm7
000079f4d2dd9245  movaps [r15+0x1A0], xmm1
000079f4d2dd924d  vmovaps xmm1, [rsp+0x60]
000079f4d2dd9253  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd9259  vmovaps [rsp+0xB0], xmm1
000079f4d2dd9262  vmovaps xmm1, [rsp+0x80]
000079f4d2dd926b  vmovaps [rsp+0x80], xmm15
000079f4d2dd9274  vmovaps xmm15, [rsp+0xB0]
000079f4d2dd927d  vmovaps [rsp+0xB0], xmm14
000079f4d2dd9286  movaps xmm3, xmm1
000079f4d2dd9289  mulpd xmm3, xmm15
000079f4d2dd928e  vcmppd xmm14, xmm3, xmm3, 0x03
000079f4d2dd9293  ptest xmm14, xmm14
000079f4d2dd9299  jnz 0x000079F4D2DDB951
000079f4d2dd929f  lea r14, [rax+0x20]
000079f4d2dd92a3  movups xmm1, [r13+r14*1]
000079f4d2dd92a9  movaps [r15+0x110], xmm1
000079f4d2dd92b1  vmovaps xmm14, [rsp+0x70]
000079f4d2dd92b7  vmovaps [rsp+0x70], xmm1
000079f4d2dd92bd  movaps xmm15, xmm14
000079f4d2dd92c1  addpd xmm15, xmm4
000079f4d2dd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000079f4d2dd92cc  ptest xmm1, xmm1
000079f4d2dd92d1  jnz 0x000079F4D2DDBA9C
000079f4d2dd92d7  vmovaps xmm1, [rsp+0x60]
000079f4d2dd92dd  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd92e3  movaps xmm14, xmm2
000079f4d2dd92e7  mulpd xmm14, xmm1
000079f4d2dd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000079f4d2dd92f2  ptest xmm4, xmm4
000079f4d2dd92f7  jnz 0x000079F4D2DDBBDF
000079f4d2dd92fd  vmovaps xmm4, [rsp+0x50]
000079f4d2dd9303  movaps xmm1, xmm4
000079f4d2dd9306  addpd xmm1, xmm9
000079f4d2dd930b  vcmppd xmm2, xmm1, xmm1, 0x03
000079f4d2dd9310  ptest xmm2, xmm2
000079f4d2dd9315  jnz 0x000079F4D2DDBD21
000079f4d2dd931b  vmovaps xmm9, [rsp+0x30]
000079f4d2dd9321  vpermilpd xmm9, xmm9, 0x00
000079f4d2dd9327  vmovaps xmm2, [rsp+0x70]
000079f4d2dd932d  vmovaps [rsp+0x50], xmm1
000079f4d2dd9333  movaps xmm4, xmm2
000079f4d2dd9336  mulpd xmm4, xmm9
000079f4d2dd933b  vcmppd xmm1, xmm4, xmm4, 0x03
000079f4d2dd9340  ptest xmm1, xmm1
000079f4d2dd9345  jnz 0x000079F4D2DDBE62
000079f4d2dd934b  vmovaps xmm1, [rsp+0x30]
000079f4d2dd9351  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd9357  vmovaps xmm2, [rsp+0x90]
000079f4d2dd9360  vmovaps [rsp+0x60], xmm15
000079f4d2dd9366  movaps xmm9, xmm2
000079f4d2dd936a  mulpd xmm9, xmm1
000079f4d2dd936f  vcmppd xmm15, xmm9, xmm9, 0x03
000079f4d2dd9375  ptest xmm15, xmm15
000079f4d2dd937b  jnz 0x000079F4D2DDBFA3
000079f4d2dd9381  vmovaps xmm15, [rsp+0x80]
000079f4d2dd938a  movaps xmm1, xmm15
000079f4d2dd938e  addpd xmm1, xmm6
000079f4d2dd9392  vcmppd xmm2, xmm1, xmm1, 0x03
000079f4d2dd9397  ptest xmm2, xmm2
000079f4d2dd939c  jnz 0x000079F4D2DDC0E5
000079f4d2dd93a2  movaps xmm15, xmm5
000079f4d2dd93a6  addpd xmm15, xmm3
000079f4d2dd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000079f4d2dd93b1  ptest xmm6, xmm6
000079f4d2dd93b6  jnz 0x000079F4D2DDC226
000079f4d2dd93bc  vmovaps xmm6, [rsp+0x30]
000079f4d2dd93c2  vpermilpd xmm6, xmm6, 0x00
000079f4d2dd93c8  movaps xmm5, xmm8
000079f4d2dd93cc  mulpd xmm5, xmm6
000079f4d2dd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000079f4d2dd93d5  ptest xmm3, xmm3
000079f4d2dd93da  jnz 0x000079F4D2DDC368
000079f4d2dd93e0  vmovaps xmm8, [rsp+0x30]
000079f4d2dd93e6  vpermilpd xmm8, xmm8, 0x00
000079f4d2dd93ec  movaps xmm6, xmm10
000079f4d2dd93f0  mulpd xmm6, xmm8
000079f4d2dd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000079f4d2dd93fa  ptest xmm3, xmm3
000079f4d2dd93ff  jnz 0x000079F4D2DDC4A9
000079f4d2dd9405  vmovaps xmm8, [rsp+0x60]
000079f4d2dd940b  movaps xmm10, xmm8
000079f4d2dd940f  addpd xmm10, xmm14
000079f4d2dd9414  vcmppd xmm3, xmm10, xmm10, 0x03
000079f4d2dd941a  ptest xmm3, xmm3
000079f4d2dd941f  jnz 0x000079F4D2DDC5EB
000079f4d2dd9425  vmovaps xmm8, [rsp+0x50]
000079f4d2dd942b  movaps xmm14, xmm8
000079f4d2dd942f  addpd xmm14, xmm4
000079f4d2dd9434  vcmppd xmm3, xmm14, xmm14, 0x03
000079f4d2dd943a  ptest xmm3, xmm3
000079f4d2dd943f  jnz 0x000079F4D2DDC72F
000079f4d2dd9445  vmovaps xmm8, [rsp+0x40]
000079f4d2dd944b  vpermilpd xmm8, xmm8, 0x00
000079f4d2dd9451  movaps xmm4, xmm13
000079f4d2dd9455  mulpd xmm4, xmm8
000079f4d2dd945a  vcmppd xmm3, xmm4, xmm4, 0x03
000079f4d2dd945f  ptest xmm3, xmm3
000079f4d2dd9464  jnz 0x000079F4D2DDC872
000079f4d2dd946a  movaps xmm13, xmm15
000079f4d2dd946e  addpd xmm13, xmm9
000079f4d2dd9473  vcmppd xmm8, xmm13, xmm13, 0x03
000079f4d2dd9479  ptest xmm8, xmm8
000079f4d2dd947f  jnz 0x000079F4D2DDC9B4
000079f4d2dd9485  movaps xmm15, xmm1
000079f4d2dd9489  addpd xmm15, xmm5
000079f4d2dd948e  vcmppd xmm9, xmm15, xmm15, 0x03
000079f4d2dd9494  ptest xmm9, xmm9
000079f4d2dd949a  jnz 0x000079F4D2DDCAF8
000079f4d2dd94a0  vmovaps [rsp+0x30], xmm11
000079f4d2dd94a6  vmovaps xmm1, [rsp+0x30]
000079f4d2dd94ac  por xmm11, xmm1
000079f4d2dd94b1  movaps [r15+0x250], xmm11
000079f4d2dd94b9  vmovaps [rsp+0x30], xmm12
000079f4d2dd94bf  vmovaps xmm1, [rsp+0x30]
000079f4d2dd94c5  por xmm12, xmm1
000079f4d2dd94ca  movaps [r15+0x2A0], xmm12
000079f4d2dd94d2  vmovaps xmm1, [rsp+0xA0]
000079f4d2dd94db  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd94e4  por xmm1, xmm11
000079f4d2dd94e9  movaps [r15+0x1D0], xmm1
000079f4d2dd94f1  lea r14, [rax+0x40]
000079f4d2dd94f5  movups xmm1, [r13+r14*1]
000079f4d2dd94fb  movaps [r15+0x2C0], xmm1
000079f4d2dd9503  vmovaps xmm11, [rsp+0x40]
000079f4d2dd9509  vpermilpd xmm11, xmm11, 0x00
000079f4d2dd950f  vmovaps xmm8, [rsp+0xE0]
000079f4d2dd9518  movaps xmm9, xmm8
000079f4d2dd951c  mulpd xmm9, xmm11
000079f4d2dd9521  vcmppd xmm5, xmm9, xmm9, 0x03
000079f4d2dd9527  ptest xmm5, xmm5
000079f4d2dd952c  jnz 0x000079F4D2DDCC44
000079f4d2dd9532  movaps xmm11, xmm10
000079f4d2dd9536  addpd xmm11, xmm6
000079f4d2dd953b  vcmppd xmm8, xmm11, xmm11, 0x03
000079f4d2dd9541  ptest xmm8, xmm8
000079f4d2dd9547  jnz 0x000079F4D2DDCD88
000079f4d2dd954d  movaps xmm10, xmm14
000079f4d2dd9551  addpd xmm10, xmm4
000079f4d2dd9556  vcmppd xmm8, xmm10, xmm10, 0x03
000079f4d2dd955c  ptest xmm8, xmm8
000079f4d2dd9562  jnz 0x000079F4D2DDCECB
000079f4d2dd9568  vmovaps xmm14, [rsp+0x40]
000079f4d2dd956e  vpermilpd xmm14, xmm14, 0x00
000079f4d2dd9574  movaps xmm8, xmm1
000079f4d2dd9578  mulpd xmm8, xmm14
000079f4d2dd957d  vcmppd xmm6, xmm8, xmm8, 0x03
000079f4d2dd9583  ptest xmm6, xmm6
000079f4d2dd9588  jnz 0x000079F4D2DDD00E
000079f4d2dd958e  movaps xmm1, [r15+0x2B0]
000079f4d2dd9596  vmovaps xmm14, [rsp+0x40]
000079f4d2dd959c  vpermilpd xmm14, xmm14, 0x00
000079f4d2dd95a2  movaps xmm6, xmm1
000079f4d2dd95a5  mulpd xmm6, xmm14
000079f4d2dd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000079f4d2dd95af  ptest xmm5, xmm5
000079f4d2dd95b4  jnz 0x000079F4D2DDD151
000079f4d2dd95ba  vmovaps xmm1, [rsp+0x10]
000079f4d2dd95c0  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd95c6  movaps xmm14, xmm12
000079f4d2dd95ca  mulpd xmm14, xmm1
000079f4d2dd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000079f4d2dd95d5  ptest xmm5, xmm5
000079f4d2dd95da  jnz 0x000079F4D2DDD292
000079f4d2dd95e0  movaps xmm1, xmm13
000079f4d2dd95e4  addpd xmm1, xmm9
000079f4d2dd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000079f4d2dd95ee  ptest xmm12, xmm12
000079f4d2dd95f4  jnz 0x000079F4D2DDD3D5
000079f4d2dd95fa  vmovaps xmm13, [rsp+0x10]
000079f4d2dd9600  vpermilpd xmm13, xmm13, 0x00
000079f4d2dd9606  movaps xmm12, xmm7
000079f4d2dd960a  mulpd xmm12, xmm13
000079f4d2dd960f  vcmppd xmm9, xmm12, xmm12, 0x03
000079f4d2dd9615  ptest xmm9, xmm9
000079f4d2dd961b  jnz 0x000079F4D2DDD517
000079f4d2dd9621  movaps xmm13, xmm15
000079f4d2dd9625  addpd xmm13, xmm8
000079f4d2dd962a  vcmppd xmm9, xmm13, xmm13, 0x03
000079f4d2dd9630  ptest xmm9, xmm9
000079f4d2dd9636  jnz 0x000079F4D2DDD65A
000079f4d2dd963c  movaps xmm15, [r15+0x290]
000079f4d2dd9644  vmovaps xmm9, [rsp+0x10]
000079f4d2dd964a  vpermilpd xmm9, xmm9, 0x00
000079f4d2dd9650  movaps xmm8, xmm15
000079f4d2dd9654  mulpd xmm8, xmm9
000079f4d2dd9659  vcmppd xmm7, xmm8, xmm8, 0x03
000079f4d2dd965f  ptest xmm7, xmm7
000079f4d2dd9664  jnz 0x000079F4D2DDD79E
000079f4d2dd966a  movaps xmm15, xmm11
000079f4d2dd966e  addpd xmm15, xmm6
000079f4d2dd9673  vcmppd xmm9, xmm15, xmm15, 0x03
000079f4d2dd9679  ptest xmm9, xmm9
000079f4d2dd967f  jnz 0x000079F4D2DDD8E2
000079f4d2dd9685  movaps xmm11, [r15+0x1E0]
000079f4d2dd968d  vmovaps xmm9, [rsp+0x10]
000079f4d2dd9693  vpermilpd xmm9, xmm9, 0x00
000079f4d2dd9699  movaps xmm7, xmm11
000079f4d2dd969d  mulpd xmm7, xmm9
000079f4d2dd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000079f4d2dd96a7  ptest xmm6, xmm6
000079f4d2dd96ac  jnz 0x000079F4D2DDDA25
000079f4d2dd96b2  movaps xmm11, xmm10
000079f4d2dd96b6  addpd xmm11, xmm14
000079f4d2dd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000079f4d2dd96c1  ptest xmm9, xmm9
000079f4d2dd96c7  jnz 0x000079F4D2DDDB67
000079f4d2dd96cd  lea r14, [rax+0x70]
000079f4d2dd96d1  movups xmm14, [r13+r14*1]
000079f4d2dd96d7  movaps [r15+0x240], xmm14
000079f4d2dd96df  movaps xmm10, xmm1
000079f4d2dd96e3  addpd xmm10, xmm12
000079f4d2dd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000079f4d2dd96ee  ptest xmm9, xmm9
000079f4d2dd96f4  jnz 0x000079F4D2DDDCB5
000079f4d2dd96fa  movaps [r15+0x170], xmm10
000079f4d2dd9702  vmovaps xmm1, [rsp+0x20]
000079f4d2dd9708  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd970e  movaps xmm12, xmm14
000079f4d2dd9712  mulpd xmm12, xmm1
000079f4d2dd9717  vcmppd xmm9, xmm12, xmm12, 0x03
000079f4d2dd971d  ptest xmm9, xmm9
000079f4d2dd9723  jnz 0x000079F4D2DDDDF8
000079f4d2dd9729  vmovaps xmm1, [rsp+0x20]
000079f4d2dd972f  vpermilpd xmm1, xmm1, 0x00
000079f4d2dd9735  vmovaps xmm9, [rsp+0xB0]
000079f4d2dd973e  movaps xmm14, xmm9
000079f4d2dd9742  mulpd xmm14, xmm1
000079f4d2dd9747  vcmppd xmm6, xmm14, xmm14, 0x03
000079f4d2dd974d  ptest xmm6, xmm6
000079f4d2dd9752  jnz 0x000079F4D2DDDF3B
000079f4d2dd9758  movaps [r15+0x180], xmm14
000079f4d2dd9760  movaps xmm1, xmm13
000079f4d2dd9764  addpd xmm1, xmm8
000079f4d2dd9769  vcmppd xmm9, xmm1, xmm1, 0x03
000079f4d2dd976e  ptest xmm9, xmm9
000079f4d2dd9774  jnz 0x000079F4D2DDE07E
000079f4d2dd977a  movaps [r15+0x210], xmm1
000079f4d2dd9782  movups xmm13, [r13+rax*1]
000079f4d2dd9788  lea r14, [rax+0x10]
000079f4d2dd978c  movups xmm9, [r13+r14*1]
000079f4d2dd9792  movaps [r15+0x230], xmm9
000079f4d2dd979a  movaps xmm8, xmm15
000079f4d2dd979e  addpd xmm8, xmm7
000079f4d2dd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000079f4d2dd97a9  ptest xmm6, xmm6
000079f4d2dd97ae  jnz 0x000079F4D2DDE1D4
000079f4d2dd97b4  movaps [r15+0x130], xmm8
000079f4d2dd97bc  vmovaps xmm15, [rsp+0x20]
000079f4d2dd97c2  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd97c8  movaps xmm7, xmm9
000079f4d2dd97cc  mulpd xmm7, xmm15
000079f4d2dd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000079f4d2dd97d6  ptest xmm6, xmm6
000079f4d2dd97db  jnz 0x000079F4D2DDE317
000079f4d2dd97e1  movaps [r15+0x220], xmm7
000079f4d2dd97e9  vmovaps xmm15, [rsp+0x20]
000079f4d2dd97ef  vpermilpd xmm15, xmm15, 0x00
000079f4d2dd97f5  movaps xmm9, xmm13
000079f4d2dd97f9  mulpd xmm9, xmm15
000079f4d2dd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000079f4d2dd9804  ptest xmm6, xmm6
000079f4d2dd9809  jnz 0x000079F4D2DDE459
000079f4d2dd980f  movaps xmm15, xmm11
000079f4d2dd9813  addpd xmm15, xmm12
000079f4d2dd9818  vcmppd xmm13, xmm15, xmm15, 0x03
000079f4d2dd981e  ptest xmm13, xmm13
000079f4d2dd9824  jnz 0x000079F4D2DDE59D
000079f4d2dd982a  movaps [r15+0x140], xmm15
000079f4d2dd9832  movaps xmm13, xmm10
000079f4d2dd9836  addpd xmm13, xmm14
000079f4d2dd983b  vcmppd xmm12, xmm13, xmm13, 0x03
000079f4d2dd9841  ptest xmm12, xmm12
000079f4d2dd9847  jnz 0x000079F4D2DDE6E1
000079f4d2dd984d  movaps [r15+0x150], xmm13
000079f4d2dd9855  movaps xmm14, xmm1
000079f4d2dd9859  addpd xmm14, xmm7
000079f4d2dd985e  vcmppd xmm12, xmm14, xmm14, 0x03
000079f4d2dd9864  ptest xmm12, xmm12
000079f4d2dd986a  jnz 0x000079F4D2DDE825
000079f4d2dd9870  movaps [r15+0x160], xmm14
000079f4d2dd9878  movaps xmm1, xmm8
000079f4d2dd987c  addpd xmm1, xmm9
000079f4d2dd9881  vcmppd xmm12, xmm1, xmm1, 0x03
000079f4d2dd9886  ptest xmm12, xmm12
000079f4d2dd988c  jnz 0x000079F4D2DDE967
000079f4d2dd9892  movaps [r15+0x120], xmm1
000079f4d2dd989a  movups [r13+r11*1], xmm15
000079f4d2dd98a0  lea rax, [r11+0x10]
000079f4d2dd98a4  movups [r13+rax*1], xmm13
000079f4d2dd98aa  lea rax, [r11+0x20]
000079f4d2dd98ae  movups [r13+rax*1], xmm14
000079f4d2dd98b4  lea rax, [r11+0x30]
000079f4d2dd98b8  movups [r13+rax*1], xmm1
000079f4d2dd98be  mov eax, [r15+0x108]
000079f4d2dd98c5  sahf
000079f4d2dd98c6  jnz 0x000079F4D2DD98F8
000079f4d2dd98c8  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd98d0  jz 0x000079F4D2DDEAE0
000079f4d2dd98d6  nop [rax+rax*1], ax
000079f4d2dd98df  nop [rax+rax*1], eax
000079f4d2dd98e7  mov eax, 0x4106D0
000079f4d2dd98ec  mov [r15+0x100], rax
000079f4d2dd98f3  jmp 0x000079F4D2BFE110
000079f4d2dd98f8  cmp dword ptr [r15+0x318], 0x00
000079f4d2dd9900  jz 0x000079F4D2DD89C0
000079f4d2dd9906  nop [rax+rax*1], ax
000079f4d2dd990f  nop [rax+rax*1], eax
000079f4d2dd9917  mov eax, 0x410504
000079f4d2dd991c  mov [r15+0x100], rax
000079f4d2dd9923  jmp 0x000079F4D2BFE110
000079f4d2dd9928  int3
000079f4d2dd9929  call 0x000079F4D2C0A4B0
000079f4d2dd992e  jmp 0x000079F4D2DD8A08
000079f4d2dd9933  call 0x000079F4D2C09240
000079f4d2dd9938  jmp 0x000079F4D2DD8A12
000079f4d2dd993d  call 0x000079F4D2C0A4B0
000079f4d2dd9942  jmp 0x000079F4D2DD8A6F
000079f4d2dd9947  call 0x000079F4D2C09240
000079f4d2dd994c  jmp 0x000079F4D2DD8A79
000079f4d2dd9951  call 0x000079F4D2C0A4B0
000079f4d2dd9956  jmp 0x000079F4D2DD8ABD
000079f4d2dd995b  call 0x000079F4D2C09240
000079f4d2dd9960  jmp 0x000079F4D2DD8AC7
000079f4d2dd9965  call 0x000079F4D2CB47C0
000079f4d2dd996a  jmp 0x000079F4D2DD8B06
000079f4d2dd996f  call 0x000079F4D2C0B720
000079f4d2dd9974  jmp 0x000079F4D2DD8B1A
000079f4d2dd9979  call 0x000079F4D2CBFC30
000079f4d2dd997e  jmp 0x000079F4D2DD8B38
000079f4d2dd9983  call 0x000079F4D2CBE9C0
000079f4d2dd9988  jmp 0x000079F4D2DD8B42
000079f4d2dd998d  call 0x000079F4D2CBD750
000079f4d2dd9992  jmp 0x000079F4D2DD8B4C
000079f4d2dd9997  sub rsp, 0x08
000079f4d2dd999b  push rax
000079f4d2dd999c  push rcx
000079f4d2dd999d  push rdx
000079f4d2dd999e  push rdi
000079f4d2dd999f  push rsi
000079f4d2dd99a0  push r8
000079f4d2dd99a2  push r9
000079f4d2dd99a4  push r10
000079f4d2dd99a6  push r11
000079f4d2dd99a8  sub rsp, 0xF0
000079f4d2dd99af  vmovaps [rsp], xmm0
000079f4d2dd99b4  vmovaps [rsp+0x10], xmm1
000079f4d2dd99ba  vmovaps [rsp+0x20], xmm2
000079f4d2dd99c0  vmovaps [rsp+0x30], xmm3
000079f4d2dd99c6  vmovaps [rsp+0x40], xmm4
000079f4d2dd99cc  vmovaps [rsp+0x50], xmm5
000079f4d2dd99d2  vmovaps [rsp+0x60], xmm6
000079f4d2dd99d8  vmovaps [rsp+0x70], xmm7
000079f4d2dd99de  vmovaps [rsp+0x80], xmm9
000079f4d2dd99e7  vmovaps [rsp+0x90], xmm10
000079f4d2dd99f0  vmovaps [rsp+0xA0], xmm11
000079f4d2dd99f9  vmovaps [rsp+0xB0], xmm12
000079f4d2dd9a02  vmovaps [rsp+0xC0], xmm13
000079f4d2dd9a0b  vmovaps [rsp+0xD0], xmm14
000079f4d2dd9a14  vmovaps [rsp+0xE0], xmm15
000079f4d2dd9a1d  sub rsp, 0x30
000079f4d2dd9a21  movaps [rsp], xmm8
000079f4d2dd9a26  movaps [rsp+0x10], xmm12
000079f4d2dd9a2c  movaps [rsp+0x20], xmm15
000079f4d2dd9a32  lea rdi, [rsp]
000079f4d2dd9a36  mov esi, 0x00
000079f4d2dd9a3b  mov rax, 0x5D9EC01E8530
000079f4d2dd9a45  call rax
000079f4d2dd9a47  movaps xmm8, [rsp]
000079f4d2dd9a4c  add rsp, 0x30
000079f4d2dd9a50  vmovaps xmm0, [rsp]
000079f4d2dd9a55  vmovaps xmm1, [rsp+0x10]
000079f4d2dd9a5b  vmovaps xmm2, [rsp+0x20]
000079f4d2dd9a61  vmovaps xmm3, [rsp+0x30]
000079f4d2dd9a67  vmovaps xmm4, [rsp+0x40]
000079f4d2dd9a6d  vmovaps xmm5, [rsp+0x50]
000079f4d2dd9a73  vmovaps xmm6, [rsp+0x60]
000079f4d2dd9a79  vmovaps xmm7, [rsp+0x70]
000079f4d2dd9a7f  vmovaps xmm9, [rsp+0x80]
000079f4d2dd9a88  vmovaps xmm10, [rsp+0x90]
000079f4d2dd9a91  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd9a9a  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd9aa3  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd9aac  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd9ab5  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd9abe  add rsp, 0xF0
000079f4d2dd9ac5  pop r11
000079f4d2dd9ac7  pop r10
000079f4d2dd9ac9  pop r9
000079f4d2dd9acb  pop r8
000079f4d2dd9acd  pop rsi
000079f4d2dd9ace  pop rdi
000079f4d2dd9acf  pop rdx
000079f4d2dd9ad0  pop rcx
000079f4d2dd9ad1  pop rax
000079f4d2dd9ad2  add rsp, 0x08
000079f4d2dd9ad6  jmp 0x000079F4D2DD8B7A
000079f4d2dd9adb  sub rsp, 0x08
000079f4d2dd9adf  push rax
000079f4d2dd9ae0  push rcx
000079f4d2dd9ae1  push rdx
000079f4d2dd9ae2  push rdi
000079f4d2dd9ae3  push rsi
000079f4d2dd9ae4  push r8
000079f4d2dd9ae6  push r9
000079f4d2dd9ae8  push r10
000079f4d2dd9aea  push r11
000079f4d2dd9aec  sub rsp, 0xF0
000079f4d2dd9af3  vmovaps [rsp], xmm0
000079f4d2dd9af8  vmovaps [rsp+0x10], xmm1
000079f4d2dd9afe  vmovaps [rsp+0x20], xmm2
000079f4d2dd9b04  vmovaps [rsp+0x30], xmm3
000079f4d2dd9b0a  vmovaps [rsp+0x40], xmm4
000079f4d2dd9b10  vmovaps [rsp+0x50], xmm5
000079f4d2dd9b16  vmovaps [rsp+0x60], xmm6
000079f4d2dd9b1c  vmovaps [rsp+0x70], xmm8
000079f4d2dd9b22  vmovaps [rsp+0x80], xmm9
000079f4d2dd9b2b  vmovaps [rsp+0x90], xmm10
000079f4d2dd9b34  vmovaps [rsp+0xA0], xmm11
000079f4d2dd9b3d  vmovaps [rsp+0xB0], xmm12
000079f4d2dd9b46  vmovaps [rsp+0xC0], xmm13
000079f4d2dd9b4f  vmovaps [rsp+0xD0], xmm14
000079f4d2dd9b58  vmovaps [rsp+0xE0], xmm15
000079f4d2dd9b61  sub rsp, 0x30
000079f4d2dd9b65  movaps [rsp], xmm7
000079f4d2dd9b69  movaps [rsp+0x10], xmm9
000079f4d2dd9b6f  movaps [rsp+0x20], xmm15
000079f4d2dd9b75  lea rdi, [rsp]
000079f4d2dd9b79  mov esi, 0x00
000079f4d2dd9b7e  mov rax, 0x5D9EC01E8530
000079f4d2dd9b88  call rax
000079f4d2dd9b8a  movaps xmm7, [rsp]
000079f4d2dd9b8e  add rsp, 0x30
000079f4d2dd9b92  vmovaps xmm0, [rsp]
000079f4d2dd9b97  vmovaps xmm1, [rsp+0x10]
000079f4d2dd9b9d  vmovaps xmm2, [rsp+0x20]
000079f4d2dd9ba3  vmovaps xmm3, [rsp+0x30]
000079f4d2dd9ba9  vmovaps xmm4, [rsp+0x40]
000079f4d2dd9baf  vmovaps xmm5, [rsp+0x50]
000079f4d2dd9bb5  vmovaps xmm6, [rsp+0x60]
000079f4d2dd9bbb  vmovaps xmm8, [rsp+0x70]
000079f4d2dd9bc1  vmovaps xmm9, [rsp+0x80]
000079f4d2dd9bca  vmovaps xmm10, [rsp+0x90]
000079f4d2dd9bd3  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd9bdc  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd9be5  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd9bee  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd9bf7  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd9c00  add rsp, 0xF0
000079f4d2dd9c07  pop r11
000079f4d2dd9c09  pop r10
000079f4d2dd9c0b  pop r9
000079f4d2dd9c0d  pop r8
000079f4d2dd9c0f  pop rsi
000079f4d2dd9c10  pop rdi
000079f4d2dd9c11  pop rdx
000079f4d2dd9c12  pop rcx
000079f4d2dd9c13  pop rax
000079f4d2dd9c14  add rsp, 0x08
000079f4d2dd9c18  jmp 0x000079F4D2DD8BA8
000079f4d2dd9c1d  sub rsp, 0x08
000079f4d2dd9c21  push rax
000079f4d2dd9c22  push rcx
000079f4d2dd9c23  push rdx
000079f4d2dd9c24  push rdi
000079f4d2dd9c25  push rsi
000079f4d2dd9c26  push r8
000079f4d2dd9c28  push r9
000079f4d2dd9c2a  push r10
000079f4d2dd9c2c  push r11
000079f4d2dd9c2e  sub rsp, 0xF0
000079f4d2dd9c35  vmovaps [rsp], xmm0
000079f4d2dd9c3a  vmovaps [rsp+0x10], xmm1
000079f4d2dd9c40  vmovaps [rsp+0x20], xmm2
000079f4d2dd9c46  vmovaps [rsp+0x30], xmm3
000079f4d2dd9c4c  vmovaps [rsp+0x40], xmm4
000079f4d2dd9c52  vmovaps [rsp+0x50], xmm5
000079f4d2dd9c58  vmovaps [rsp+0x60], xmm6
000079f4d2dd9c5e  vmovaps [rsp+0x70], xmm7
000079f4d2dd9c64  vmovaps [rsp+0x80], xmm8
000079f4d2dd9c6d  vmovaps [rsp+0x90], xmm10
000079f4d2dd9c76  vmovaps [rsp+0xA0], xmm11
000079f4d2dd9c7f  vmovaps [rsp+0xB0], xmm12
000079f4d2dd9c88  vmovaps [rsp+0xC0], xmm13
000079f4d2dd9c91  vmovaps [rsp+0xD0], xmm14
000079f4d2dd9c9a  vmovaps [rsp+0xE0], xmm15
000079f4d2dd9ca3  sub rsp, 0x30
000079f4d2dd9ca7  movaps [rsp], xmm9
000079f4d2dd9cac  movaps [rsp+0x10], xmm12
000079f4d2dd9cb2  movaps [rsp+0x20], xmm10
000079f4d2dd9cb8  lea rdi, [rsp]
000079f4d2dd9cbc  mov esi, 0x00
000079f4d2dd9cc1  mov rax, 0x5D9EC01E8530
000079f4d2dd9ccb  call rax
000079f4d2dd9ccd  movaps xmm9, [rsp]
000079f4d2dd9cd2  add rsp, 0x30
000079f4d2dd9cd6  vmovaps xmm0, [rsp]
000079f4d2dd9cdb  vmovaps xmm1, [rsp+0x10]
000079f4d2dd9ce1  vmovaps xmm2, [rsp+0x20]
000079f4d2dd9ce7  vmovaps xmm3, [rsp+0x30]
000079f4d2dd9ced  vmovaps xmm4, [rsp+0x40]
000079f4d2dd9cf3  vmovaps xmm5, [rsp+0x50]
000079f4d2dd9cf9  vmovaps xmm6, [rsp+0x60]
000079f4d2dd9cff  vmovaps xmm7, [rsp+0x70]
000079f4d2dd9d05  vmovaps xmm8, [rsp+0x80]
000079f4d2dd9d0e  vmovaps xmm10, [rsp+0x90]
000079f4d2dd9d17  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd9d20  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd9d29  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd9d32  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd9d3b  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd9d44  add rsp, 0xF0
000079f4d2dd9d4b  pop r11
000079f4d2dd9d4d  pop r10
000079f4d2dd9d4f  pop r9
000079f4d2dd9d51  pop r8
000079f4d2dd9d53  pop rsi
000079f4d2dd9d54  pop rdi
000079f4d2dd9d55  pop rdx
000079f4d2dd9d56  pop rcx
000079f4d2dd9d57  pop rax
000079f4d2dd9d58  add rsp, 0x08
000079f4d2dd9d5c  jmp 0x000079F4D2DD8BCC
000079f4d2dd9d61  sub rsp, 0x08
000079f4d2dd9d65  push rax
000079f4d2dd9d66  push rcx
000079f4d2dd9d67  push rdx
000079f4d2dd9d68  push rdi
000079f4d2dd9d69  push rsi
000079f4d2dd9d6a  push r8
000079f4d2dd9d6c  push r9
000079f4d2dd9d6e  push r10
000079f4d2dd9d70  push r11
000079f4d2dd9d72  sub rsp, 0xF0
000079f4d2dd9d79  vmovaps [rsp], xmm0
000079f4d2dd9d7e  vmovaps [rsp+0x10], xmm1
000079f4d2dd9d84  vmovaps [rsp+0x20], xmm2
000079f4d2dd9d8a  vmovaps [rsp+0x30], xmm3
000079f4d2dd9d90  vmovaps [rsp+0x40], xmm4
000079f4d2dd9d96  vmovaps [rsp+0x50], xmm5
000079f4d2dd9d9c  vmovaps [rsp+0x60], xmm6
000079f4d2dd9da2  vmovaps [rsp+0x70], xmm7
000079f4d2dd9da8  vmovaps [rsp+0x80], xmm8
000079f4d2dd9db1  vmovaps [rsp+0x90], xmm9
000079f4d2dd9dba  vmovaps [rsp+0xA0], xmm11
000079f4d2dd9dc3  vmovaps [rsp+0xB0], xmm12
000079f4d2dd9dcc  vmovaps [rsp+0xC0], xmm13
000079f4d2dd9dd5  vmovaps [rsp+0xD0], xmm14
000079f4d2dd9dde  vmovaps [rsp+0xE0], xmm15
000079f4d2dd9de7  sub rsp, 0x30
000079f4d2dd9deb  movaps [rsp], xmm10
000079f4d2dd9df0  movaps [rsp+0x10], xmm12
000079f4d2dd9df6  movaps [rsp+0x20], xmm11
000079f4d2dd9dfc  lea rdi, [rsp]
000079f4d2dd9e00  mov esi, 0x00
000079f4d2dd9e05  mov rax, 0x5D9EC01E8530
000079f4d2dd9e0f  call rax
000079f4d2dd9e11  movaps xmm10, [rsp]
000079f4d2dd9e16  add rsp, 0x30
000079f4d2dd9e1a  vmovaps xmm0, [rsp]
000079f4d2dd9e1f  vmovaps xmm1, [rsp+0x10]
000079f4d2dd9e25  vmovaps xmm2, [rsp+0x20]
000079f4d2dd9e2b  vmovaps xmm3, [rsp+0x30]
000079f4d2dd9e31  vmovaps xmm4, [rsp+0x40]
000079f4d2dd9e37  vmovaps xmm5, [rsp+0x50]
000079f4d2dd9e3d  vmovaps xmm6, [rsp+0x60]
000079f4d2dd9e43  vmovaps xmm7, [rsp+0x70]
000079f4d2dd9e49  vmovaps xmm8, [rsp+0x80]
000079f4d2dd9e52  vmovaps xmm9, [rsp+0x90]
000079f4d2dd9e5b  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd9e64  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd9e6d  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd9e76  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd9e7f  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd9e88  add rsp, 0xF0
000079f4d2dd9e8f  pop r11
000079f4d2dd9e91  pop r10
000079f4d2dd9e93  pop r9
000079f4d2dd9e95  pop r8
000079f4d2dd9e97  pop rsi
000079f4d2dd9e98  pop rdi
000079f4d2dd9e99  pop rdx
000079f4d2dd9e9a  pop rcx
000079f4d2dd9e9b  pop rax
000079f4d2dd9e9c  add rsp, 0x08
000079f4d2dd9ea0  jmp 0x000079F4D2DD8BE6
000079f4d2dd9ea5  sub rsp, 0x08
000079f4d2dd9ea9  push rax
000079f4d2dd9eaa  push rcx
000079f4d2dd9eab  push rdx
000079f4d2dd9eac  push rdi
000079f4d2dd9ead  push rsi
000079f4d2dd9eae  push r8
000079f4d2dd9eb0  push r9
000079f4d2dd9eb2  push r10
000079f4d2dd9eb4  push r11
000079f4d2dd9eb6  sub rsp, 0xF0
000079f4d2dd9ebd  vmovaps [rsp], xmm0
000079f4d2dd9ec2  vmovaps [rsp+0x10], xmm1
000079f4d2dd9ec8  vmovaps [rsp+0x20], xmm2
000079f4d2dd9ece  vmovaps [rsp+0x30], xmm3
000079f4d2dd9ed4  vmovaps [rsp+0x40], xmm4
000079f4d2dd9eda  vmovaps [rsp+0x50], xmm5
000079f4d2dd9ee0  vmovaps [rsp+0x60], xmm7
000079f4d2dd9ee6  vmovaps [rsp+0x70], xmm8
000079f4d2dd9eec  vmovaps [rsp+0x80], xmm9
000079f4d2dd9ef5  vmovaps [rsp+0x90], xmm10
000079f4d2dd9efe  vmovaps [rsp+0xA0], xmm11
000079f4d2dd9f07  vmovaps [rsp+0xB0], xmm12
000079f4d2dd9f10  vmovaps [rsp+0xC0], xmm13
000079f4d2dd9f19  vmovaps [rsp+0xD0], xmm14
000079f4d2dd9f22  vmovaps [rsp+0xE0], xmm15
000079f4d2dd9f2b  sub rsp, 0x30
000079f4d2dd9f2f  movaps [rsp], xmm6
000079f4d2dd9f33  movaps [rsp+0x10], xmm12
000079f4d2dd9f39  movaps [rsp+0x20], xmm11
000079f4d2dd9f3f  lea rdi, [rsp]
000079f4d2dd9f43  mov esi, 0x00
000079f4d2dd9f48  mov rax, 0x5D9EC01E8530
000079f4d2dd9f52  call rax
000079f4d2dd9f54  movaps xmm6, [rsp]
000079f4d2dd9f58  add rsp, 0x30
000079f4d2dd9f5c  vmovaps xmm0, [rsp]
000079f4d2dd9f61  vmovaps xmm1, [rsp+0x10]
000079f4d2dd9f67  vmovaps xmm2, [rsp+0x20]
000079f4d2dd9f6d  vmovaps xmm3, [rsp+0x30]
000079f4d2dd9f73  vmovaps xmm4, [rsp+0x40]
000079f4d2dd9f79  vmovaps xmm5, [rsp+0x50]
000079f4d2dd9f7f  vmovaps xmm7, [rsp+0x60]
000079f4d2dd9f85  vmovaps xmm8, [rsp+0x70]
000079f4d2dd9f8b  vmovaps xmm9, [rsp+0x80]
000079f4d2dd9f94  vmovaps xmm10, [rsp+0x90]
000079f4d2dd9f9d  vmovaps xmm11, [rsp+0xA0]
000079f4d2dd9fa6  vmovaps xmm12, [rsp+0xB0]
000079f4d2dd9faf  vmovaps xmm13, [rsp+0xC0]
000079f4d2dd9fb8  vmovaps xmm14, [rsp+0xD0]
000079f4d2dd9fc1  vmovaps xmm15, [rsp+0xE0]
000079f4d2dd9fca  add rsp, 0xF0
000079f4d2dd9fd1  pop r11
000079f4d2dd9fd3  pop r10
000079f4d2dd9fd5  pop r9
000079f4d2dd9fd7  pop r8
000079f4d2dd9fd9  pop rsi
000079f4d2dd9fda  pop rdi
000079f4d2dd9fdb  pop rdx
000079f4d2dd9fdc  pop rcx
000079f4d2dd9fdd  pop rax
000079f4d2dd9fde  add rsp, 0x08
000079f4d2dd9fe2  jmp 0x000079F4D2DD8C07
000079f4d2dd9fe7  sub rsp, 0x08
000079f4d2dd9feb  push rax
000079f4d2dd9fec  push rcx
000079f4d2dd9fed  push rdx
000079f4d2dd9fee  push rdi
000079f4d2dd9fef  push rsi
000079f4d2dd9ff0  push r8
000079f4d2dd9ff2  push r9
000079f4d2dd9ff4  push r10
000079f4d2dd9ff6  push r11
000079f4d2dd9ff8  sub rsp, 0xF0
000079f4d2dd9fff  vmovaps [rsp], xmm0
000079f4d2dda004  vmovaps [rsp+0x10], xmm1
000079f4d2dda00a  vmovaps [rsp+0x20], xmm2
000079f4d2dda010  vmovaps [rsp+0x30], xmm4
000079f4d2dda016  vmovaps [rsp+0x40], xmm5
000079f4d2dda01c  vmovaps [rsp+0x50], xmm6
000079f4d2dda022  vmovaps [rsp+0x60], xmm7
000079f4d2dda028  vmovaps [rsp+0x70], xmm8
000079f4d2dda02e  vmovaps [rsp+0x80], xmm9
000079f4d2dda037  vmovaps [rsp+0x90], xmm10
000079f4d2dda040  vmovaps [rsp+0xA0], xmm11
000079f4d2dda049  vmovaps [rsp+0xB0], xmm12
000079f4d2dda052  vmovaps [rsp+0xC0], xmm13
000079f4d2dda05b  vmovaps [rsp+0xD0], xmm14
000079f4d2dda064  vmovaps [rsp+0xE0], xmm15
000079f4d2dda06d  sub rsp, 0x30
000079f4d2dda071  movaps [rsp], xmm3
000079f4d2dda075  movaps [rsp+0x10], xmm5
000079f4d2dda07a  movaps [rsp+0x20], xmm4
000079f4d2dda07f  lea rdi, [rsp]
000079f4d2dda083  mov esi, 0x00
000079f4d2dda088  mov rax, 0x5D9EC01E8530
000079f4d2dda092  call rax
000079f4d2dda094  movaps xmm3, [rsp]
000079f4d2dda098  add rsp, 0x30
000079f4d2dda09c  vmovaps xmm0, [rsp]
000079f4d2dda0a1  vmovaps xmm1, [rsp+0x10]
000079f4d2dda0a7  vmovaps xmm2, [rsp+0x20]
000079f4d2dda0ad  vmovaps xmm4, [rsp+0x30]
000079f4d2dda0b3  vmovaps xmm5, [rsp+0x40]
000079f4d2dda0b9  vmovaps xmm6, [rsp+0x50]
000079f4d2dda0bf  vmovaps xmm7, [rsp+0x60]
000079f4d2dda0c5  vmovaps xmm8, [rsp+0x70]
000079f4d2dda0cb  vmovaps xmm9, [rsp+0x80]
000079f4d2dda0d4  vmovaps xmm10, [rsp+0x90]
000079f4d2dda0dd  vmovaps xmm11, [rsp+0xA0]
000079f4d2dda0e6  vmovaps xmm12, [rsp+0xB0]
000079f4d2dda0ef  vmovaps xmm13, [rsp+0xC0]
000079f4d2dda0f8  vmovaps xmm14, [rsp+0xD0]
000079f4d2dda101  vmovaps xmm15, [rsp+0xE0]
000079f4d2dda10a  add rsp, 0xF0
000079f4d2dda111  pop r11
000079f4d2dda113  pop r10
000079f4d2dda115  pop r9
000079f4d2dda117  pop r8
000079f4d2dda119  pop rsi
000079f4d2dda11a  pop rdi
000079f4d2dda11b  pop rdx
000079f4d2dda11c  pop rcx
000079f4d2dda11d  pop rax
000079f4d2dda11e  add rsp, 0x08
000079f4d2dda122  jmp 0x000079F4D2DD8C68
000079f4d2dda127  sub rsp, 0x08
000079f4d2dda12b  push rax
000079f4d2dda12c  push rcx
000079f4d2dda12d  push rdx
000079f4d2dda12e  push rdi
000079f4d2dda12f  push rsi
000079f4d2dda130  push r8
000079f4d2dda132  push r9
000079f4d2dda134  push r10
000079f4d2dda136  push r11
000079f4d2dda138  sub rsp, 0xF0
000079f4d2dda13f  vmovaps [rsp], xmm0
000079f4d2dda144  vmovaps [rsp+0x10], xmm1
000079f4d2dda14a  vmovaps [rsp+0x20], xmm2
000079f4d2dda150  vmovaps [rsp+0x30], xmm3
000079f4d2dda156  vmovaps [rsp+0x40], xmm4
000079f4d2dda15c  vmovaps [rsp+0x50], xmm6
000079f4d2dda162  vmovaps [rsp+0x60], xmm7
000079f4d2dda168  vmovaps [rsp+0x70], xmm8
000079f4d2dda16e  vmovaps [rsp+0x80], xmm9
000079f4d2dda177  vmovaps [rsp+0x90], xmm10
000079f4d2dda180  vmovaps [rsp+0xA0], xmm11
000079f4d2dda189  vmovaps [rsp+0xB0], xmm12
000079f4d2dda192  vmovaps [rsp+0xC0], xmm13
000079f4d2dda19b  vmovaps [rsp+0xD0], xmm14
000079f4d2dda1a4  vmovaps [rsp+0xE0], xmm15
000079f4d2dda1ad  sub rsp, 0x30
000079f4d2dda1b1  movaps [rsp], xmm5
000079f4d2dda1b5  movaps [rsp+0x10], xmm8
000079f4d2dda1bb  movaps [rsp+0x20], xmm15
000079f4d2dda1c1  lea rdi, [rsp]
000079f4d2dda1c5  mov esi, 0x00
000079f4d2dda1ca  mov rax, 0x5D9EC01E8530
000079f4d2dda1d4  call rax
000079f4d2dda1d6  movaps xmm5, [rsp]
000079f4d2dda1da  add rsp, 0x30
000079f4d2dda1de  vmovaps xmm0, [rsp]
000079f4d2dda1e3  vmovaps xmm1, [rsp+0x10]
000079f4d2dda1e9  vmovaps xmm2, [rsp+0x20]
000079f4d2dda1ef  vmovaps xmm3, [rsp+0x30]
000079f4d2dda1f5  vmovaps xmm4, [rsp+0x40]
000079f4d2dda1fb  vmovaps xmm6, [rsp+0x50]
000079f4d2dda201  vmovaps xmm7, [rsp+0x60]
000079f4d2dda207  vmovaps xmm8, [rsp+0x70]
000079f4d2dda20d  vmovaps xmm9, [rsp+0x80]
000079f4d2dda216  vmovaps xmm10, [rsp+0x90]
000079f4d2dda21f  vmovaps xmm11, [rsp+0xA0]
000079f4d2dda228  vmovaps xmm12, [rsp+0xB0]
000079f4d2dda231  vmovaps xmm13, [rsp+0xC0]
000079f4d2dda23a  vmovaps xmm14, [rsp+0xD0]
000079f4d2dda243  vmovaps xmm15, [rsp+0xE0]
000079f4d2dda24c  add rsp, 0xF0
000079f4d2dda253  pop r11
000079f4d2dda255  pop r10
000079f4d2dda257  pop r9
000079f4d2dda259  pop r8
000079f4d2dda25b  pop rsi
000079f4d2dda25c  pop rdi
000079f4d2dda25d  pop rdx
000079f4d2dda25e  pop rcx
000079f4d2dda25f  pop rax
000079f4d2dda260  add rsp, 0x08
000079f4d2dda264  jmp 0x000079F4D2DD8CA0
000079f4d2dda269  sub rsp, 0x08
000079f4d2dda26d  push rax
000079f4d2dda26e  push rcx
000079f4d2dda26f  push rdx
000079f4d2dda270  push rdi
000079f4d2dda271  push rsi
000079f4d2dda272  push r8
000079f4d2dda274  push r9
000079f4d2dda276  push r10
000079f4d2dda278  push r11
000079f4d2dda27a  sub rsp, 0xF0
000079f4d2dda281  vmovaps [rsp], xmm0
000079f4d2dda286  vmovaps [rsp+0x10], xmm1
000079f4d2dda28c  vmovaps [rsp+0x20], xmm2
000079f4d2dda292  vmovaps [rsp+0x30], xmm3
000079f4d2dda298  vmovaps [rsp+0x40], xmm5
000079f4d2dda29e  vmovaps [rsp+0x50], xmm6
000079f4d2dda2a4  vmovaps [rsp+0x60], xmm7
000079f4d2dda2aa  vmovaps [rsp+0x70], xmm8
000079f4d2dda2b0  vmovaps [rsp+0x80], xmm9
000079f4d2dda2b9  vmovaps [rsp+0x90], xmm10
000079f4d2dda2c2  vmovaps [rsp+0xA0], xmm11
000079f4d2dda2cb  vmovaps [rsp+0xB0], xmm12
000079f4d2dda2d4  vmovaps [rsp+0xC0], xmm13
000079f4d2dda2dd  vmovaps [rsp+0xD0], xmm14
000079f4d2dda2e6  vmovaps [rsp+0xE0], xmm15
000079f4d2dda2ef  sub rsp, 0x30
000079f4d2dda2f3  movaps [rsp], xmm4
000079f4d2dda2f7  movaps [rsp+0x10], xmm9
000079f4d2dda2fd  movaps [rsp+0x20], xmm8
000079f4d2dda303  lea rdi, [rsp]
000079f4d2dda307  mov esi, 0x00
000079f4d2dda30c  mov rax, 0x5D9EC01E8530
000079f4d2dda316  call rax
000079f4d2dda318  movaps xmm4, [rsp]
000079f4d2dda31c  add rsp, 0x30
000079f4d2dda320  vmovaps xmm0, [rsp]
000079f4d2dda325  vmovaps xmm1, [rsp+0x10]
000079f4d2dda32b  vmovaps xmm2, [rsp+0x20]
000079f4d2dda331  vmovaps xmm3, [rsp+0x30]
000079f4d2dda337  vmovaps xmm5, [rsp+0x40]
000079f4d2dda33d  vmovaps xmm6, [rsp+0x50]
000079f4d2dda343  vmovaps xmm7, [rsp+0x60]
000079f4d2dda349  vmovaps xmm8, [rsp+0x70]
000079f4d2dda34f  vmovaps xmm9, [rsp+0x80]
000079f4d2dda358  vmovaps xmm10, [rsp+0x90]
000079f4d2dda361  vmovaps xmm11, [rsp+0xA0]
000079f4d2dda36a  vmovaps xmm12, [rsp+0xB0]
000079f4d2dda373  vmovaps xmm13, [rsp+0xC0]
000079f4d2dda37c  vmovaps xmm14, [rsp+0xD0]
000079f4d2dda385  vmovaps xmm15, [rsp+0xE0]
000079f4d2dda38e  add rsp, 0xF0
000079f4d2dda395  pop r11
000079f4d2dda397  pop r10
000079f4d2dda399  pop r9
000079f4d2dda39b  pop r8
000079f4d2dda39d  pop rsi
000079f4d2dda39e  pop rdi
000079f4d2dda39f  pop rdx
000079f4d2dda3a0  pop rcx
000079f4d2dda3a1  pop rax
000079f4d2dda3a2  add rsp, 0x08
000079f4d2dda3a6  jmp 0x000079F4D2DD8CC1
000079f4d2dda3ab  sub rsp, 0x08
000079f4d2dda3af  push rax
000079f4d2dda3b0  push rcx
000079f4d2dda3b1  push rdx
000079f4d2dda3b2  push rdi
000079f4d2dda3b3  push rsi
000079f4d2dda3b4  push r8
000079f4d2dda3b6  push r9
000079f4d2dda3b8  push r10
000079f4d2dda3ba  push r11
000079f4d2dda3bc  sub rsp, 0xF0
000079f4d2dda3c3  vmovaps [rsp], xmm0
000079f4d2dda3c8  vmovaps [rsp+0x10], xmm1
000079f4d2dda3ce  vmovaps [rsp+0x20], xmm2
000079f4d2dda3d4  vmovaps [rsp+0x30], xmm3
000079f4d2dda3da  vmovaps [rsp+0x40], xmm4
000079f4d2dda3e0  vmovaps [rsp+0x50], xmm5
000079f4d2dda3e6  vmovaps [rsp+0x60], xmm6
000079f4d2dda3ec  vmovaps [rsp+0x70], xmm7
000079f4d2dda3f2  vmovaps [rsp+0x80], xmm8
000079f4d2dda3fb  vmovaps [rsp+0x90], xmm10
000079f4d2dda404  vmovaps [rsp+0xA0], xmm11
000079f4d2dda40d  vmovaps [rsp+0xB0], xmm12
000079f4d2dda416  vmovaps [rsp+0xC0], xmm13
000079f4d2dda41f  vmovaps [rsp+0xD0], xmm14
000079f4d2dda428  vmovaps [rsp+0xE0], xmm15
000079f4d2dda431  sub rsp, 0x30
000079f4d2dda435  movaps [rsp], xmm9
000079f4d2dda43a  movaps [rsp+0x10], xmm10
000079f4d2dda440  movaps [rsp+0x20], xmm8
000079f4d2dda446  lea rdi, [rsp]
000079f4d2dda44a  mov esi, 0x00
000079f4d2dda44f  mov rax, 0x5D9EC01E8530
000079f4d2dda459  call rax
000079f4d2dda45b  movaps xmm9, [rsp]
000079f4d2dda460  add rsp, 0x30
000079f4d2dda464  vmovaps xmm0, [rsp]
000079f4d2dda469  vmovaps xmm1, [rsp+0x10]
000079f4d2dda46f  vmovaps xmm2, [rsp+0x20]
000079f4d2dda475  vmovaps xmm3, [rsp+0x30]
000079f4d2dda47b  vmovaps xmm4, [rsp+0x40]
000079f4d2dda481  vmovaps xmm5, [rsp+0x50]
000079f4d2dda487  vmovaps xmm6, [rsp+0x60]
000079f4d2dda48d  vmovaps xmm7, [rsp+0x70]
000079f4d2dda493  vmovaps xmm8, [rsp+0x80]
000079f4d2dda49c  vmovaps xmm10, [rsp+0x90]
000079f4d2dda4a5  vmovaps xmm11, [rsp+0xA0]
000079f4d2dda4ae  vmovaps xmm12, [rsp+0xB0]
000079f4d2dda4b7  vmovaps xmm13, [rsp+0xC0]
000079f4d2dda4c0  vmovaps xmm14, [rsp+0xD0]
000079f4d2dda4c9  vmovaps xmm15, [rsp+0xE0]
000079f4d2dda4d2  add rsp, 0xF0
000079f4d2dda4d9  pop r11
000079f4d2dda4db  pop r10
000079f4d2dda4dd  pop r9
000079f4d2dda4df  pop r8
000079f4d2dda4e1  pop rsi
000079f4d2dda4e2  pop rdi
000079f4d2dda4e3  pop rdx
000079f4d2dda4e4  pop rcx
000079f4d2dda4e5  pop rax
000079f4d2dda4e6  add rsp, 0x08
000079f4d2dda4ea  jmp 0x000079F4D2DD8CDB
000079f4d2dda4ef  call 0x000079F4D2CD64F0
000079f4d2dda4f4  jmp 0x000079F4D2DD8DF5
000079f4d2dda4f9  call 0x000079F4D2CD64F0
000079f4d2dda4fe  jmp 0x000079F4D2DD8E0B
000079f4d2dda503  sub rsp, 0x08
000079f4d2dda507  push rax
000079f4d2dda508  push rcx
000079f4d2dda509  push rdx
000079f4d2dda50a  push rdi
000079f4d2dda50b  push rsi
000079f4d2dda50c  push r8
000079f4d2dda50e  push r9
000079f4d2dda510  push r10
000079f4d2dda512  push r11
000079f4d2dda514  sub rsp, 0xF0
000079f4d2dda51b  vmovaps [rsp], xmm0
000079f4d2dda520  vmovaps [rsp+0x10], xmm2
000079f4d2dda526  vmovaps [rsp+0x20], xmm3
000079f4d2dda52c  vmovaps [rsp+0x30], xmm4
000079f4d2dda532  vmovaps [rsp+0x40], xmm5
000079f4d2dda538  vmovaps [rsp+0x50], xmm6
000079f4d2dda53e  vmovaps [rsp+0x60], xmm7
000079f4d2dda544  vmovaps [rsp+0x70], xmm8
000079f4d2dda54a  vmovaps [rsp+0x80], xmm9
000079f4d2dda553  vmovaps [rsp+0x90], xmm10
000079f4d2dda55c  vmovaps [rsp+0xA0], xmm11
000079f4d2dda565  vmovaps [rsp+0xB0], xmm12
000079f4d2dda56e  vmovaps [rsp+0xC0], xmm13
000079f4d2dda577  vmovaps [rsp+0xD0], xmm14
000079f4d2dda580  vmovaps [rsp+0xE0], xmm15
000079f4d2dda589  sub rsp, 0x30
000079f4d2dda58d  movaps [rsp], xmm1
000079f4d2dda591  movaps [rsp+0x10], xmm6
000079f4d2dda596  movaps [rsp+0x20], xmm15
000079f4d2dda59c  lea rdi, [rsp]
000079f4d2dda5a0  mov esi, 0x00
000079f4d2dda5a5  mov rax, 0x5D9EC01E8530
000079f4d2dda5af  call rax
000079f4d2dda5b1  movaps xmm1, [rsp]
000079f4d2dda5b5  add rsp, 0x30
000079f4d2dda5b9  vmovaps xmm0, [rsp]
000079f4d2dda5be  vmovaps xmm2, [rsp+0x10]
000079f4d2dda5c4  vmovaps xmm3, [rsp+0x20]
000079f4d2dda5ca  vmovaps xmm4, [rsp+0x30]
000079f4d2dda5d0  vmovaps xmm5, [rsp+0x40]
000079f4d2dda5d6  vmovaps xmm6, [rsp+0x50]
000079f4d2dda5dc  vmovaps xmm7, [rsp+0x60]
000079f4d2dda5e2  vmovaps xmm8, [rsp+0x70]
000079f4d2dda5e8  vmovaps xmm9, [rsp+0x80]
000079f4d2dda5f1  vmovaps xmm10, [rsp+0x90]
000079f4d2dda5fa  vmovaps xmm11, [rsp+0xA0]
000079f4d2dda603  vmovaps xmm12, [rsp+0xB0]
000079f4d2dda60c  vmovaps xmm13, [rsp+0xC0]
000079f4d2dda615  vmovaps xmm14, [rsp+0xD0]
000079f4d2dda61e  vmovaps xmm15, [rsp+0xE0]
000079f4d2dda627  add rsp, 0xF0
000079f4d2dda62e  pop r11
000079f4d2dda630  pop r10
000079f4d2dda632  pop r9
000079f4d2dda634  pop r8
000079f4d2dda636  pop rsi
000079f4d2dda637  pop rdi
000079f4d2dda638  pop rdx
000079f4d2dda639  pop rcx
000079f4d2dda63a  pop rax
000079f4d2dda63b  add rsp, 0x08
000079f4d2dda63f  jmp 0x000079F4D2DD8E48
000079f4d2dda644  call 0x000079F4D2CE5820
000079f4d2dda649  jmp 0x000079F4D2DD8E55
000079f4d2dda64e  sub rsp, 0x08
000079f4d2dda652  push rax
000079f4d2dda653  push rcx
000079f4d2dda654  push rdx
000079f4d2dda655  push rdi
000079f4d2dda656  push rsi
000079f4d2dda657  push r8
000079f4d2dda659  push r9
000079f4d2dda65b  push r10
000079f4d2dda65d  push r11
000079f4d2dda65f  sub rsp, 0xF0
000079f4d2dda666  vmovaps [rsp], xmm0
000079f4d2dda66b  vmovaps [rsp+0x10], xmm1
000079f4d2dda671  vmovaps [rsp+0x20], xmm2
000079f4d2dda677  vmovaps [rsp+0x30], xmm3
000079f4d2dda67d  vmovaps [rsp+0x40], xmm4
000079f4d2dda683  vmovaps [rsp+0x50], xmm5
000079f4d2dda689  vmovaps [rsp+0x60], xmm6
000079f4d2dda68f  vmovaps [rsp+0x70], xmm7
000079f4d2dda695  vmovaps [rsp+0x80], xmm8
000079f4d2dda69e  vmovaps [rsp+0x90], xmm9
000079f4d2dda6a7  vmovaps [rsp+0xA0], xmm10
000079f4d2dda6b0  vmovaps [rsp+0xB0], xmm11
000079f4d2dda6b9  vmovaps [rsp+0xC0], xmm12
000079f4d2dda6c2  vmovaps [rsp+0xD0], xmm13
000079f4d2dda6cb  vmovaps [rsp+0xE0], xmm15
000079f4d2dda6d4  sub rsp, 0x30
000079f4d2dda6d8  movaps [rsp], xmm14
000079f4d2dda6dd  movaps [rsp+0x10], xmm4
000079f4d2dda6e2  movaps [rsp+0x20], xmm3
000079f4d2dda6e7  lea rdi, [rsp]
000079f4d2dda6eb  mov esi, 0x00
000079f4d2dda6f0  mov rax, 0x5D9EC01E8530
000079f4d2dda6fa  call rax
000079f4d2dda6fc  movaps xmm14, [rsp]
000079f4d2dda701  add rsp, 0x30
000079f4d2dda705  vmovaps xmm0, [rsp]
000079f4d2dda70a  vmovaps xmm1, [rsp+0x10]
000079f4d2dda710  vmovaps xmm2, [rsp+0x20]
000079f4d2dda716  vmovaps xmm3, [rsp+0x30]
000079f4d2dda71c  vmovaps xmm4, [rsp+0x40]
000079f4d2dda722  vmovaps xmm5, [rsp+0x50]
000079f4d2dda728  vmovaps xmm6, [rsp+0x60]
000079f4d2dda72e  vmovaps xmm7, [rsp+0x70]
000079f4d2dda734  vmovaps xmm8, [rsp+0x80]
000079f4d2dda73d  vmovaps xmm9, [rsp+0x90]
000079f4d2dda746  vmovaps xmm10, [rsp+0xA0]
000079f4d2dda74f  vmovaps xmm11, [rsp+0xB0]
000079f4d2dda758  vmovaps xmm12, [rsp+0xC0]
000079f4d2dda761  vmovaps xmm13, [rsp+0xD0]
000079f4d2dda76a  vmovaps xmm15, [rsp+0xE0]
000079f4d2dda773  add rsp, 0xF0
000079f4d2dda77a  pop r11
000079f4d2dda77c  pop r10
000079f4d2dda77e  pop r9
000079f4d2dda780  pop r8
000079f4d2dda782  pop rsi
000079f4d2dda783  pop rdi
000079f4d2dda784  pop rdx
000079f4d2dda785  pop rcx
000079f4d2dda786  pop rax
000079f4d2dda787  add rsp, 0x08
000079f4d2dda78b  jmp 0x000079F4D2DD8E6F
000079f4d2dda790  sub rsp, 0x08
000079f4d2dda794  push rax
000079f4d2dda795  push rcx
000079f4d2dda796  push rdx
000079f4d2dda797  push rdi
000079f4d2dda798  push rsi
000079f4d2dda799  push r8
000079f4d2dda79b  push r9
000079f4d2dda79d  push r10
000079f4d2dda79f  push r11
000079f4d2dda7a1  sub rsp, 0xF0
000079f4d2dda7a8  vmovaps [rsp], xmm0
000079f4d2dda7ad  vmovaps [rsp+0x10], xmm1
000079f4d2dda7b3  vmovaps [rsp+0x20], xmm2
000079f4d2dda7b9  vmovaps [rsp+0x30], xmm3
000079f4d2dda7bf  vmovaps [rsp+0x40], xmm4
000079f4d2dda7c5  vmovaps [rsp+0x50], xmm5
000079f4d2dda7cb  vmovaps [rsp+0x60], xmm7
000079f4d2dda7d1  vmovaps [rsp+0x70], xmm8
000079f4d2dda7d7  vmovaps [rsp+0x80], xmm9
000079f4d2dda7e0  vmovaps [rsp+0x90], xmm10
000079f4d2dda7e9  vmovaps [rsp+0xA0], xmm11
000079f4d2dda7f2  vmovaps [rsp+0xB0], xmm12
000079f4d2dda7fb  vmovaps [rsp+0xC0], xmm13
000079f4d2dda804  vmovaps [rsp+0xD0], xmm14
000079f4d2dda80d  vmovaps [rsp+0xE0], xmm15
000079f4d2dda816  sub rsp, 0x30
000079f4d2dda81a  movaps [rsp], xmm6
000079f4d2dda81e  movaps [rsp+0x10], xmm9
000079f4d2dda824  movaps [rsp+0x20], xmm7
000079f4d2dda829  lea rdi, [rsp]
000079f4d2dda82d  mov esi, 0x00
000079f4d2dda832  mov rax, 0x5D9EC01E8530
000079f4d2dda83c  call rax
000079f4d2dda83e  movaps xmm6, [rsp]
000079f4d2dda842  add rsp, 0x30
000079f4d2dda846  vmovaps xmm0, [rsp]
000079f4d2dda84b  vmovaps xmm1, [rsp+0x10]
000079f4d2dda851  vmovaps xmm2, [rsp+0x20]
000079f4d2dda857  vmovaps xmm3, [rsp+0x30]
000079f4d2dda85d  vmovaps xmm4, [rsp+0x40]
000079f4d2dda863  vmovaps xmm5, [rsp+0x50]
000079f4d2dda869  vmovaps xmm7, [rsp+0x60]
000079f4d2dda86f  vmovaps xmm8, [rsp+0x70]
000079f4d2dda875  vmovaps xmm9, [rsp+0x80]
000079f4d2dda87e  vmovaps xmm10, [rsp+0x90]
000079f4d2dda887  vmovaps xmm11, [rsp+0xA0]
000079f4d2dda890  vmovaps xmm12, [rsp+0xB0]
000079f4d2dda899  vmovaps xmm13, [rsp+0xC0]
000079f4d2dda8a2  vmovaps xmm14, [rsp+0xD0]
000079f4d2dda8ab  vmovaps xmm15, [rsp+0xE0]
000079f4d2dda8b4  add rsp, 0xF0
000079f4d2dda8bb  pop r11
000079f4d2dda8bd  pop r10
000079f4d2dda8bf  pop r9
000079f4d2dda8c1  pop r8
000079f4d2dda8c3  pop rsi
000079f4d2dda8c4  pop rdi
000079f4d2dda8c5  pop rdx
000079f4d2dda8c6  pop rcx
000079f4d2dda8c7  pop rax
000079f4d2dda8c8  add rsp, 0x08
000079f4d2dda8cc  jmp 0x000079F4D2DD8E87
000079f4d2dda8d1  sub rsp, 0x08
000079f4d2dda8d5  push rax
000079f4d2dda8d6  push rcx
000079f4d2dda8d7  push rdx
000079f4d2dda8d8  push rdi
000079f4d2dda8d9  push rsi
000079f4d2dda8da  push r8
000079f4d2dda8dc  push r9
000079f4d2dda8de  push r10
000079f4d2dda8e0  push r11
000079f4d2dda8e2  sub rsp, 0xF0
000079f4d2dda8e9  vmovaps [rsp], xmm0
000079f4d2dda8ee  vmovaps [rsp+0x10], xmm1
000079f4d2dda8f4  vmovaps [rsp+0x20], xmm2
000079f4d2dda8fa  vmovaps [rsp+0x30], xmm3
000079f4d2dda900  vmovaps [rsp+0x40], xmm4
000079f4d2dda906  vmovaps [rsp+0x50], xmm5
000079f4d2dda90c  vmovaps [rsp+0x60], xmm6
000079f4d2dda912  vmovaps [rsp+0x70], xmm8
000079f4d2dda918  vmovaps [rsp+0x80], xmm9
000079f4d2dda921  vmovaps [rsp+0x90], xmm10
000079f4d2dda92a  vmovaps [rsp+0xA0], xmm11
000079f4d2dda933  vmovaps [rsp+0xB0], xmm12
000079f4d2dda93c  vmovaps [rsp+0xC0], xmm13
000079f4d2dda945  vmovaps [rsp+0xD0], xmm14
000079f4d2dda94e  vmovaps [rsp+0xE0], xmm15
000079f4d2dda957  sub rsp, 0x30
000079f4d2dda95b  movaps [rsp], xmm7
000079f4d2dda95f  movaps [rsp+0x10], xmm4
000079f4d2dda964  movaps [rsp+0x20], xmm9
000079f4d2dda96a  lea rdi, [rsp]
000079f4d2dda96e  mov esi, 0x00
000079f4d2dda973  mov rax, 0x5D9EC01E8530
000079f4d2dda97d  call rax
000079f4d2dda97f  movaps xmm7, [rsp]
000079f4d2dda983  add rsp, 0x30
000079f4d2dda987  vmovaps xmm0, [rsp]
000079f4d2dda98c  vmovaps xmm1, [rsp+0x10]
000079f4d2dda992  vmovaps xmm2, [rsp+0x20]
000079f4d2dda998  vmovaps xmm3, [rsp+0x30]
000079f4d2dda99e  vmovaps xmm4, [rsp+0x40]
000079f4d2dda9a4  vmovaps xmm5, [rsp+0x50]
000079f4d2dda9aa  vmovaps xmm6, [rsp+0x60]
000079f4d2dda9b0  vmovaps xmm8, [rsp+0x70]
000079f4d2dda9b6  vmovaps xmm9, [rsp+0x80]
000079f4d2dda9bf  vmovaps xmm10, [rsp+0x90]
000079f4d2dda9c8  vmovaps xmm11, [rsp+0xA0]
000079f4d2dda9d1  vmovaps xmm12, [rsp+0xB0]
000079f4d2dda9da  vmovaps xmm13, [rsp+0xC0]
000079f4d2dda9e3  vmovaps xmm14, [rsp+0xD0]
000079f4d2dda9ec  vmovaps xmm15, [rsp+0xE0]
000079f4d2dda9f5  add rsp, 0xF0
000079f4d2dda9fc  pop r11
000079f4d2dda9fe  pop r10
000079f4d2ddaa00  pop r9
000079f4d2ddaa02  pop r8
000079f4d2ddaa04  pop rsi
000079f4d2ddaa05  pop rdi
000079f4d2ddaa06  pop rdx
000079f4d2ddaa07  pop rcx
000079f4d2ddaa08  pop rax
000079f4d2ddaa09  add rsp, 0x08
000079f4d2ddaa0d  jmp 0x000079F4D2DD8EB4
000079f4d2ddaa12  sub rsp, 0x08
000079f4d2ddaa16  push rax
000079f4d2ddaa17  push rcx
000079f4d2ddaa18  push rdx
000079f4d2ddaa19  push rdi
000079f4d2ddaa1a  push rsi
000079f4d2ddaa1b  push r8
000079f4d2ddaa1d  push r9
000079f4d2ddaa1f  push r10
000079f4d2ddaa21  push r11
000079f4d2ddaa23  sub rsp, 0xF0
000079f4d2ddaa2a  vmovaps [rsp], xmm0
000079f4d2ddaa2f  vmovaps [rsp+0x10], xmm1
000079f4d2ddaa35  vmovaps [rsp+0x20], xmm2
000079f4d2ddaa3b  vmovaps [rsp+0x30], xmm3
000079f4d2ddaa41  vmovaps [rsp+0x40], xmm5
000079f4d2ddaa47  vmovaps [rsp+0x50], xmm6
000079f4d2ddaa4d  vmovaps [rsp+0x60], xmm7
000079f4d2ddaa53  vmovaps [rsp+0x70], xmm8
000079f4d2ddaa59  vmovaps [rsp+0x80], xmm9
000079f4d2ddaa62  vmovaps [rsp+0x90], xmm10
000079f4d2ddaa6b  vmovaps [rsp+0xA0], xmm11
000079f4d2ddaa74  vmovaps [rsp+0xB0], xmm12
000079f4d2ddaa7d  vmovaps [rsp+0xC0], xmm13
000079f4d2ddaa86  vmovaps [rsp+0xD0], xmm14
000079f4d2ddaa8f  vmovaps [rsp+0xE0], xmm15
000079f4d2ddaa98  sub rsp, 0x30
000079f4d2ddaa9c  movaps [rsp], xmm4
000079f4d2ddaaa0  movaps [rsp+0x10], xmm15
000079f4d2ddaaa6  movaps [rsp+0x20], xmm9
000079f4d2ddaaac  lea rdi, [rsp]
000079f4d2ddaab0  mov esi, 0x00
000079f4d2ddaab5  mov rax, 0x5D9EC01E8530
000079f4d2ddaabf  call rax
000079f4d2ddaac1  movaps xmm4, [rsp]
000079f4d2ddaac5  add rsp, 0x30
000079f4d2ddaac9  vmovaps xmm0, [rsp]
000079f4d2ddaace  vmovaps xmm1, [rsp+0x10]
000079f4d2ddaad4  vmovaps xmm2, [rsp+0x20]
000079f4d2ddaada  vmovaps xmm3, [rsp+0x30]
000079f4d2ddaae0  vmovaps xmm5, [rsp+0x40]
000079f4d2ddaae6  vmovaps xmm6, [rsp+0x50]
000079f4d2ddaaec  vmovaps xmm7, [rsp+0x60]
000079f4d2ddaaf2  vmovaps xmm8, [rsp+0x70]
000079f4d2ddaaf8  vmovaps xmm9, [rsp+0x80]
000079f4d2ddab01  vmovaps xmm10, [rsp+0x90]
000079f4d2ddab0a  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddab13  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddab1c  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddab25  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddab2e  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddab37  add rsp, 0xF0
000079f4d2ddab3e  pop r11
000079f4d2ddab40  pop r10
000079f4d2ddab42  pop r9
000079f4d2ddab44  pop r8
000079f4d2ddab46  pop rsi
000079f4d2ddab47  pop rdi
000079f4d2ddab48  pop rdx
000079f4d2ddab49  pop rcx
000079f4d2ddab4a  pop rax
000079f4d2ddab4b  add rsp, 0x08
000079f4d2ddab4f  jmp 0x000079F4D2DD8ED9
000079f4d2ddab54  call 0x000079F4D2CE5820
000079f4d2ddab59  jmp 0x000079F4D2DD8EE6
000079f4d2ddab5e  sub rsp, 0x08
000079f4d2ddab62  push rax
000079f4d2ddab63  push rcx
000079f4d2ddab64  push rdx
000079f4d2ddab65  push rdi
000079f4d2ddab66  push rsi
000079f4d2ddab67  push r8
000079f4d2ddab69  push r9
000079f4d2ddab6b  push r10
000079f4d2ddab6d  push r11
000079f4d2ddab6f  sub rsp, 0xF0
000079f4d2ddab76  vmovaps [rsp], xmm0
000079f4d2ddab7b  vmovaps [rsp+0x10], xmm1
000079f4d2ddab81  vmovaps [rsp+0x20], xmm2
000079f4d2ddab87  vmovaps [rsp+0x30], xmm4
000079f4d2ddab8d  vmovaps [rsp+0x40], xmm5
000079f4d2ddab93  vmovaps [rsp+0x50], xmm6
000079f4d2ddab99  vmovaps [rsp+0x60], xmm7
000079f4d2ddab9f  vmovaps [rsp+0x70], xmm8
000079f4d2ddaba5  vmovaps [rsp+0x80], xmm9
000079f4d2ddabae  vmovaps [rsp+0x90], xmm10
000079f4d2ddabb7  vmovaps [rsp+0xA0], xmm11
000079f4d2ddabc0  vmovaps [rsp+0xB0], xmm12
000079f4d2ddabc9  vmovaps [rsp+0xC0], xmm13
000079f4d2ddabd2  vmovaps [rsp+0xD0], xmm14
000079f4d2ddabdb  vmovaps [rsp+0xE0], xmm15
000079f4d2ddabe4  sub rsp, 0x30
000079f4d2ddabe8  movaps [rsp], xmm3
000079f4d2ddabec  movaps [rsp+0x10], xmm1
000079f4d2ddabf1  movaps [rsp+0x20], xmm9
000079f4d2ddabf7  lea rdi, [rsp]
000079f4d2ddabfb  mov esi, 0x00
000079f4d2ddac00  mov rax, 0x5D9EC01E8530
000079f4d2ddac0a  call rax
000079f4d2ddac0c  movaps xmm3, [rsp]
000079f4d2ddac10  add rsp, 0x30
000079f4d2ddac14  vmovaps xmm0, [rsp]
000079f4d2ddac19  vmovaps xmm1, [rsp+0x10]
000079f4d2ddac1f  vmovaps xmm2, [rsp+0x20]
000079f4d2ddac25  vmovaps xmm4, [rsp+0x30]
000079f4d2ddac2b  vmovaps xmm5, [rsp+0x40]
000079f4d2ddac31  vmovaps xmm6, [rsp+0x50]
000079f4d2ddac37  vmovaps xmm7, [rsp+0x60]
000079f4d2ddac3d  vmovaps xmm8, [rsp+0x70]
000079f4d2ddac43  vmovaps xmm9, [rsp+0x80]
000079f4d2ddac4c  vmovaps xmm10, [rsp+0x90]
000079f4d2ddac55  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddac5e  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddac67  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddac70  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddac79  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddac82  add rsp, 0xF0
000079f4d2ddac89  pop r11
000079f4d2ddac8b  pop r10
000079f4d2ddac8d  pop r9
000079f4d2ddac8f  pop r8
000079f4d2ddac91  pop rsi
000079f4d2ddac92  pop rdi
000079f4d2ddac93  pop rdx
000079f4d2ddac94  pop rcx
000079f4d2ddac95  pop rax
000079f4d2ddac96  add rsp, 0x08
000079f4d2ddac9a  jmp 0x000079F4D2DD8F23
000079f4d2ddac9f  sub rsp, 0x08
000079f4d2ddaca3  push rax
000079f4d2ddaca4  push rcx
000079f4d2ddaca5  push rdx
000079f4d2ddaca6  push rdi
000079f4d2ddaca7  push rsi
000079f4d2ddaca8  push r8
000079f4d2ddacaa  push r9
000079f4d2ddacac  push r10
000079f4d2ddacae  push r11
000079f4d2ddacb0  sub rsp, 0xF0
000079f4d2ddacb7  vmovaps [rsp], xmm0
000079f4d2ddacbc  vmovaps [rsp+0x10], xmm2
000079f4d2ddacc2  vmovaps [rsp+0x20], xmm3
000079f4d2ddacc8  vmovaps [rsp+0x30], xmm4
000079f4d2ddacce  vmovaps [rsp+0x40], xmm5
000079f4d2ddacd4  vmovaps [rsp+0x50], xmm6
000079f4d2ddacda  vmovaps [rsp+0x60], xmm7
000079f4d2ddace0  vmovaps [rsp+0x70], xmm8
000079f4d2ddace6  vmovaps [rsp+0x80], xmm9
000079f4d2ddacef  vmovaps [rsp+0x90], xmm10
000079f4d2ddacf8  vmovaps [rsp+0xA0], xmm11
000079f4d2ddad01  vmovaps [rsp+0xB0], xmm12
000079f4d2ddad0a  vmovaps [rsp+0xC0], xmm13
000079f4d2ddad13  vmovaps [rsp+0xD0], xmm14
000079f4d2ddad1c  vmovaps [rsp+0xE0], xmm15
000079f4d2ddad25  sub rsp, 0x30
000079f4d2ddad29  movaps [rsp], xmm1
000079f4d2ddad2d  movaps [rsp+0x10], xmm15
000079f4d2ddad33  movaps [rsp+0x20], xmm9
000079f4d2ddad39  lea rdi, [rsp]
000079f4d2ddad3d  mov esi, 0x00
000079f4d2ddad42  mov rax, 0x5D9EC01E8530
000079f4d2ddad4c  call rax
000079f4d2ddad4e  movaps xmm1, [rsp]
000079f4d2ddad52  add rsp, 0x30
000079f4d2ddad56  vmovaps xmm0, [rsp]
000079f4d2ddad5b  vmovaps xmm2, [rsp+0x10]
000079f4d2ddad61  vmovaps xmm3, [rsp+0x20]
000079f4d2ddad67  vmovaps xmm4, [rsp+0x30]
000079f4d2ddad6d  vmovaps xmm5, [rsp+0x40]
000079f4d2ddad73  vmovaps xmm6, [rsp+0x50]
000079f4d2ddad79  vmovaps xmm7, [rsp+0x60]
000079f4d2ddad7f  vmovaps xmm8, [rsp+0x70]
000079f4d2ddad85  vmovaps xmm9, [rsp+0x80]
000079f4d2ddad8e  vmovaps xmm10, [rsp+0x90]
000079f4d2ddad97  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddada0  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddada9  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddadb2  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddadbb  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddadc4  add rsp, 0xF0
000079f4d2ddadcb  pop r11
000079f4d2ddadcd  pop r10
000079f4d2ddadcf  pop r9
000079f4d2ddadd1  pop r8
000079f4d2ddadd3  pop rsi
000079f4d2ddadd4  pop rdi
000079f4d2ddadd5  pop rdx
000079f4d2ddadd6  pop rcx
000079f4d2ddadd7  pop rax
000079f4d2ddadd8  add rsp, 0x08
000079f4d2ddaddc  jmp 0x000079F4D2DD8FAB
000079f4d2ddade1  call 0x000079F4D2CE5820
000079f4d2ddade6  jmp 0x000079F4D2DD8FB8
000079f4d2ddadeb  sub rsp, 0x08
000079f4d2ddadef  push rax
000079f4d2ddadf0  push rcx
000079f4d2ddadf1  push rdx
000079f4d2ddadf2  push rdi
000079f4d2ddadf3  push rsi
000079f4d2ddadf4  push r8
000079f4d2ddadf6  push r9
000079f4d2ddadf8  push r10
000079f4d2ddadfa  push r11
000079f4d2ddadfc  sub rsp, 0xF0
000079f4d2ddae03  vmovaps [rsp], xmm0
000079f4d2ddae08  vmovaps [rsp+0x10], xmm2
000079f4d2ddae0e  vmovaps [rsp+0x20], xmm3
000079f4d2ddae14  vmovaps [rsp+0x30], xmm4
000079f4d2ddae1a  vmovaps [rsp+0x40], xmm5
000079f4d2ddae20  vmovaps [rsp+0x50], xmm6
000079f4d2ddae26  vmovaps [rsp+0x60], xmm7
000079f4d2ddae2c  vmovaps [rsp+0x70], xmm8
000079f4d2ddae32  vmovaps [rsp+0x80], xmm9
000079f4d2ddae3b  vmovaps [rsp+0x90], xmm10
000079f4d2ddae44  vmovaps [rsp+0xA0], xmm11
000079f4d2ddae4d  vmovaps [rsp+0xB0], xmm12
000079f4d2ddae56  vmovaps [rsp+0xC0], xmm13
000079f4d2ddae5f  vmovaps [rsp+0xD0], xmm14
000079f4d2ddae68  vmovaps [rsp+0xE0], xmm15
000079f4d2ddae71  sub rsp, 0x30
000079f4d2ddae75  movaps [rsp], xmm1
000079f4d2ddae79  movaps [rsp+0x10], xmm5
000079f4d2ddae7e  movaps [rsp+0x20], xmm7
000079f4d2ddae83  lea rdi, [rsp]
000079f4d2ddae87  mov esi, 0x00
000079f4d2ddae8c  mov rax, 0x5D9EC01E8530
000079f4d2ddae96  call rax
000079f4d2ddae98  movaps xmm1, [rsp]
000079f4d2ddae9c  add rsp, 0x30
000079f4d2ddaea0  vmovaps xmm0, [rsp]
000079f4d2ddaea5  vmovaps xmm2, [rsp+0x10]
000079f4d2ddaeab  vmovaps xmm3, [rsp+0x20]
000079f4d2ddaeb1  vmovaps xmm4, [rsp+0x30]
000079f4d2ddaeb7  vmovaps xmm5, [rsp+0x40]
000079f4d2ddaebd  vmovaps xmm6, [rsp+0x50]
000079f4d2ddaec3  vmovaps xmm7, [rsp+0x60]
000079f4d2ddaec9  vmovaps xmm8, [rsp+0x70]
000079f4d2ddaecf  vmovaps xmm9, [rsp+0x80]
000079f4d2ddaed8  vmovaps xmm10, [rsp+0x90]
000079f4d2ddaee1  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddaeea  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddaef3  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddaefc  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddaf05  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddaf0e  add rsp, 0xF0
000079f4d2ddaf15  pop r11
000079f4d2ddaf17  pop r10
000079f4d2ddaf19  pop r9
000079f4d2ddaf1b  pop r8
000079f4d2ddaf1d  pop rsi
000079f4d2ddaf1e  pop rdi
000079f4d2ddaf1f  pop rdx
000079f4d2ddaf20  pop rcx
000079f4d2ddaf21  pop rax
000079f4d2ddaf22  add rsp, 0x08
000079f4d2ddaf26  jmp 0x000079F4D2DD905D
000079f4d2ddaf2b  sub rsp, 0x08
000079f4d2ddaf2f  push rax
000079f4d2ddaf30  push rcx
000079f4d2ddaf31  push rdx
000079f4d2ddaf32  push rdi
000079f4d2ddaf33  push rsi
000079f4d2ddaf34  push r8
000079f4d2ddaf36  push r9
000079f4d2ddaf38  push r10
000079f4d2ddaf3a  push r11
000079f4d2ddaf3c  sub rsp, 0xF0
000079f4d2ddaf43  vmovaps [rsp], xmm0
000079f4d2ddaf48  vmovaps [rsp+0x10], xmm1
000079f4d2ddaf4e  vmovaps [rsp+0x20], xmm2
000079f4d2ddaf54  vmovaps [rsp+0x30], xmm3
000079f4d2ddaf5a  vmovaps [rsp+0x40], xmm4
000079f4d2ddaf60  vmovaps [rsp+0x50], xmm5
000079f4d2ddaf66  vmovaps [rsp+0x60], xmm6
000079f4d2ddaf6c  vmovaps [rsp+0x70], xmm8
000079f4d2ddaf72  vmovaps [rsp+0x80], xmm9
000079f4d2ddaf7b  vmovaps [rsp+0x90], xmm10
000079f4d2ddaf84  vmovaps [rsp+0xA0], xmm11
000079f4d2ddaf8d  vmovaps [rsp+0xB0], xmm12
000079f4d2ddaf96  vmovaps [rsp+0xC0], xmm13
000079f4d2ddaf9f  vmovaps [rsp+0xD0], xmm14
000079f4d2ddafa8  vmovaps [rsp+0xE0], xmm15
000079f4d2ddafb1  sub rsp, 0x30
000079f4d2ddafb5  movaps [rsp], xmm7
000079f4d2ddafb9  movaps [rsp+0x10], xmm5
000079f4d2ddafbe  movaps [rsp+0x20], xmm15
000079f4d2ddafc4  lea rdi, [rsp]
000079f4d2ddafc8  mov esi, 0x00
000079f4d2ddafcd  mov rax, 0x5D9EC01E8530
000079f4d2ddafd7  call rax
000079f4d2ddafd9  movaps xmm7, [rsp]
000079f4d2ddafdd  add rsp, 0x30
000079f4d2ddafe1  vmovaps xmm0, [rsp]
000079f4d2ddafe6  vmovaps xmm1, [rsp+0x10]
000079f4d2ddafec  vmovaps xmm2, [rsp+0x20]
000079f4d2ddaff2  vmovaps xmm3, [rsp+0x30]
000079f4d2ddaff8  vmovaps xmm4, [rsp+0x40]
000079f4d2ddaffe  vmovaps xmm5, [rsp+0x50]
000079f4d2ddb004  vmovaps xmm6, [rsp+0x60]
000079f4d2ddb00a  vmovaps xmm8, [rsp+0x70]
000079f4d2ddb010  vmovaps xmm9, [rsp+0x80]
000079f4d2ddb019  vmovaps xmm10, [rsp+0x90]
000079f4d2ddb022  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddb02b  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddb034  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddb03d  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddb046  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddb04f  add rsp, 0xF0
000079f4d2ddb056  pop r11
000079f4d2ddb058  pop r10
000079f4d2ddb05a  pop r9
000079f4d2ddb05c  pop r8
000079f4d2ddb05e  pop rsi
000079f4d2ddb05f  pop rdi
000079f4d2ddb060  pop rdx
000079f4d2ddb061  pop rcx
000079f4d2ddb062  pop rax
000079f4d2ddb063  add rsp, 0x08
000079f4d2ddb067  jmp 0x000079F4D2DD9093
000079f4d2ddb06c  call 0x000079F4D2CD64F0
000079f4d2ddb071  jmp 0x000079F4D2DD90A0
000079f4d2ddb076  sub rsp, 0x08
000079f4d2ddb07a  push rax
000079f4d2ddb07b  push rcx
000079f4d2ddb07c  push rdx
000079f4d2ddb07d  push rdi
000079f4d2ddb07e  push rsi
000079f4d2ddb07f  push r8
000079f4d2ddb081  push r9
000079f4d2ddb083  push r10
000079f4d2ddb085  push r11
000079f4d2ddb087  sub rsp, 0xF0
000079f4d2ddb08e  vmovaps [rsp], xmm0
000079f4d2ddb093  vmovaps [rsp+0x10], xmm1
000079f4d2ddb099  vmovaps [rsp+0x20], xmm2
000079f4d2ddb09f  vmovaps [rsp+0x30], xmm3
000079f4d2ddb0a5  vmovaps [rsp+0x40], xmm4
000079f4d2ddb0ab  vmovaps [rsp+0x50], xmm5
000079f4d2ddb0b1  vmovaps [rsp+0x60], xmm6
000079f4d2ddb0b7  vmovaps [rsp+0x70], xmm7
000079f4d2ddb0bd  vmovaps [rsp+0x80], xmm8
000079f4d2ddb0c6  vmovaps [rsp+0x90], xmm9
000079f4d2ddb0cf  vmovaps [rsp+0xA0], xmm10
000079f4d2ddb0d8  vmovaps [rsp+0xB0], xmm11
000079f4d2ddb0e1  vmovaps [rsp+0xC0], xmm12
000079f4d2ddb0ea  vmovaps [rsp+0xD0], xmm13
000079f4d2ddb0f3  vmovaps [rsp+0xE0], xmm14
000079f4d2ddb0fc  sub rsp, 0x30
000079f4d2ddb100  movaps [rsp], xmm15
000079f4d2ddb105  movaps [rsp+0x10], xmm5
000079f4d2ddb10a  movaps [rsp+0x20], xmm3
000079f4d2ddb10f  lea rdi, [rsp]
000079f4d2ddb113  mov esi, 0x00
000079f4d2ddb118  mov rax, 0x5D9EC01E8530
000079f4d2ddb122  call rax
000079f4d2ddb124  movaps xmm15, [rsp]
000079f4d2ddb129  add rsp, 0x30
000079f4d2ddb12d  vmovaps xmm0, [rsp]
000079f4d2ddb132  vmovaps xmm1, [rsp+0x10]
000079f4d2ddb138  vmovaps xmm2, [rsp+0x20]
000079f4d2ddb13e  vmovaps xmm3, [rsp+0x30]
000079f4d2ddb144  vmovaps xmm4, [rsp+0x40]
000079f4d2ddb14a  vmovaps xmm5, [rsp+0x50]
000079f4d2ddb150  vmovaps xmm6, [rsp+0x60]
000079f4d2ddb156  vmovaps xmm7, [rsp+0x70]
000079f4d2ddb15c  vmovaps xmm8, [rsp+0x80]
000079f4d2ddb165  vmovaps xmm9, [rsp+0x90]
000079f4d2ddb16e  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddb177  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddb180  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddb189  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddb192  vmovaps xmm14, [rsp+0xE0]
000079f4d2ddb19b  add rsp, 0xF0
000079f4d2ddb1a2  pop r11
000079f4d2ddb1a4  pop r10
000079f4d2ddb1a6  pop r9
000079f4d2ddb1a8  pop r8
000079f4d2ddb1aa  pop rsi
000079f4d2ddb1ab  pop rdi
000079f4d2ddb1ac  pop rdx
000079f4d2ddb1ad  pop rcx
000079f4d2ddb1ae  pop rax
000079f4d2ddb1af  add rsp, 0x08
000079f4d2ddb1b3  jmp 0x000079F4D2DD90C6
000079f4d2ddb1b8  sub rsp, 0x08
000079f4d2ddb1bc  push rax
000079f4d2ddb1bd  push rcx
000079f4d2ddb1be  push rdx
000079f4d2ddb1bf  push rdi
000079f4d2ddb1c0  push rsi
000079f4d2ddb1c1  push r8
000079f4d2ddb1c3  push r9
000079f4d2ddb1c5  push r10
000079f4d2ddb1c7  push r11
000079f4d2ddb1c9  sub rsp, 0xF0
000079f4d2ddb1d0  vmovaps [rsp], xmm0
000079f4d2ddb1d5  vmovaps [rsp+0x10], xmm2
000079f4d2ddb1db  vmovaps [rsp+0x20], xmm3
000079f4d2ddb1e1  vmovaps [rsp+0x30], xmm4
000079f4d2ddb1e7  vmovaps [rsp+0x40], xmm5
000079f4d2ddb1ed  vmovaps [rsp+0x50], xmm6
000079f4d2ddb1f3  vmovaps [rsp+0x60], xmm7
000079f4d2ddb1f9  vmovaps [rsp+0x70], xmm8
000079f4d2ddb1ff  vmovaps [rsp+0x80], xmm9
000079f4d2ddb208  vmovaps [rsp+0x90], xmm10
000079f4d2ddb211  vmovaps [rsp+0xA0], xmm11
000079f4d2ddb21a  vmovaps [rsp+0xB0], xmm12
000079f4d2ddb223  vmovaps [rsp+0xC0], xmm13
000079f4d2ddb22c  vmovaps [rsp+0xD0], xmm14
000079f4d2ddb235  vmovaps [rsp+0xE0], xmm15
000079f4d2ddb23e  sub rsp, 0x30
000079f4d2ddb242  movaps [rsp], xmm1
000079f4d2ddb246  movaps [rsp+0x10], xmm5
000079f4d2ddb24b  movaps [rsp+0x20], xmm4
000079f4d2ddb250  lea rdi, [rsp]
000079f4d2ddb254  mov esi, 0x00
000079f4d2ddb259  mov rax, 0x5D9EC01E8530
000079f4d2ddb263  call rax
000079f4d2ddb265  movaps xmm1, [rsp]
000079f4d2ddb269  add rsp, 0x30
000079f4d2ddb26d  vmovaps xmm0, [rsp]
000079f4d2ddb272  vmovaps xmm2, [rsp+0x10]
000079f4d2ddb278  vmovaps xmm3, [rsp+0x20]
000079f4d2ddb27e  vmovaps xmm4, [rsp+0x30]
000079f4d2ddb284  vmovaps xmm5, [rsp+0x40]
000079f4d2ddb28a  vmovaps xmm6, [rsp+0x50]
000079f4d2ddb290  vmovaps xmm7, [rsp+0x60]
000079f4d2ddb296  vmovaps xmm8, [rsp+0x70]
000079f4d2ddb29c  vmovaps xmm9, [rsp+0x80]
000079f4d2ddb2a5  vmovaps xmm10, [rsp+0x90]
000079f4d2ddb2ae  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddb2b7  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddb2c0  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddb2c9  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddb2d2  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddb2db  add rsp, 0xF0
000079f4d2ddb2e2  pop r11
000079f4d2ddb2e4  pop r10
000079f4d2ddb2e6  pop r9
000079f4d2ddb2e8  pop r8
000079f4d2ddb2ea  pop rsi
000079f4d2ddb2eb  pop rdi
000079f4d2ddb2ec  pop rdx
000079f4d2ddb2ed  pop rcx
000079f4d2ddb2ee  pop rax
000079f4d2ddb2ef  add rsp, 0x08
000079f4d2ddb2f3  jmp 0x000079F4D2DD90E6
000079f4d2ddb2f8  sub rsp, 0x08
000079f4d2ddb2fc  push rax
000079f4d2ddb2fd  push rcx
000079f4d2ddb2fe  push rdx
000079f4d2ddb2ff  push rdi
000079f4d2ddb300  push rsi
000079f4d2ddb301  push r8
000079f4d2ddb303  push r9
000079f4d2ddb305  push r10
000079f4d2ddb307  push r11
000079f4d2ddb309  sub rsp, 0xF0
000079f4d2ddb310  vmovaps [rsp], xmm0
000079f4d2ddb315  vmovaps [rsp+0x10], xmm1
000079f4d2ddb31b  vmovaps [rsp+0x20], xmm2
000079f4d2ddb321  vmovaps [rsp+0x30], xmm3
000079f4d2ddb327  vmovaps [rsp+0x40], xmm5
000079f4d2ddb32d  vmovaps [rsp+0x50], xmm6
000079f4d2ddb333  vmovaps [rsp+0x60], xmm7
000079f4d2ddb339  vmovaps [rsp+0x70], xmm8
000079f4d2ddb33f  vmovaps [rsp+0x80], xmm9
000079f4d2ddb348  vmovaps [rsp+0x90], xmm10
000079f4d2ddb351  vmovaps [rsp+0xA0], xmm11
000079f4d2ddb35a  vmovaps [rsp+0xB0], xmm12
000079f4d2ddb363  vmovaps [rsp+0xC0], xmm13
000079f4d2ddb36c  vmovaps [rsp+0xD0], xmm14
000079f4d2ddb375  vmovaps [rsp+0xE0], xmm15
000079f4d2ddb37e  sub rsp, 0x30
000079f4d2ddb382  movaps [rsp], xmm4
000079f4d2ddb386  movaps [rsp+0x10], xmm3
000079f4d2ddb38b  movaps [rsp+0x20], xmm5
000079f4d2ddb390  lea rdi, [rsp]
000079f4d2ddb394  mov esi, 0x00
000079f4d2ddb399  mov rax, 0x5D9EC01E8530
000079f4d2ddb3a3  call rax
000079f4d2ddb3a5  movaps xmm4, [rsp]
000079f4d2ddb3a9  add rsp, 0x30
000079f4d2ddb3ad  vmovaps xmm0, [rsp]
000079f4d2ddb3b2  vmovaps xmm1, [rsp+0x10]
000079f4d2ddb3b8  vmovaps xmm2, [rsp+0x20]
000079f4d2ddb3be  vmovaps xmm3, [rsp+0x30]
000079f4d2ddb3c4  vmovaps xmm5, [rsp+0x40]
000079f4d2ddb3ca  vmovaps xmm6, [rsp+0x50]
000079f4d2ddb3d0  vmovaps xmm7, [rsp+0x60]
000079f4d2ddb3d6  vmovaps xmm8, [rsp+0x70]
000079f4d2ddb3dc  vmovaps xmm9, [rsp+0x80]
000079f4d2ddb3e5  vmovaps xmm10, [rsp+0x90]
000079f4d2ddb3ee  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddb3f7  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddb400  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddb409  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddb412  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddb41b  add rsp, 0xF0
000079f4d2ddb422  pop r11
000079f4d2ddb424  pop r10
000079f4d2ddb426  pop r9
000079f4d2ddb428  pop r8
000079f4d2ddb42a  pop rsi
000079f4d2ddb42b  pop rdi
000079f4d2ddb42c  pop rdx
000079f4d2ddb42d  pop rcx
000079f4d2ddb42e  pop rax
000079f4d2ddb42f  add rsp, 0x08
000079f4d2ddb433  jmp 0x000079F4D2DD9134
000079f4d2ddb438  call 0x000079F4D2CD64F0
000079f4d2ddb43d  jmp 0x000079F4D2DD9141
000079f4d2ddb442  sub rsp, 0x08
000079f4d2ddb446  push rax
000079f4d2ddb447  push rcx
000079f4d2ddb448  push rdx
000079f4d2ddb449  push rdi
000079f4d2ddb44a  push rsi
000079f4d2ddb44b  push r8
000079f4d2ddb44d  push r9
000079f4d2ddb44f  push r10
000079f4d2ddb451  push r11
000079f4d2ddb453  sub rsp, 0xF0
000079f4d2ddb45a  vmovaps [rsp], xmm0
000079f4d2ddb45f  vmovaps [rsp+0x10], xmm1
000079f4d2ddb465  vmovaps [rsp+0x20], xmm2
000079f4d2ddb46b  vmovaps [rsp+0x30], xmm3
000079f4d2ddb471  vmovaps [rsp+0x40], xmm4
000079f4d2ddb477  vmovaps [rsp+0x50], xmm6
000079f4d2ddb47d  vmovaps [rsp+0x60], xmm7
000079f4d2ddb483  vmovaps [rsp+0x70], xmm8
000079f4d2ddb489  vmovaps [rsp+0x80], xmm9
000079f4d2ddb492  vmovaps [rsp+0x90], xmm10
000079f4d2ddb49b  vmovaps [rsp+0xA0], xmm11
000079f4d2ddb4a4  vmovaps [rsp+0xB0], xmm12
000079f4d2ddb4ad  vmovaps [rsp+0xC0], xmm13
000079f4d2ddb4b6  vmovaps [rsp+0xD0], xmm14
000079f4d2ddb4bf  vmovaps [rsp+0xE0], xmm15
000079f4d2ddb4c8  sub rsp, 0x30
000079f4d2ddb4cc  movaps [rsp], xmm5
000079f4d2ddb4d0  movaps [rsp+0x10], xmm6
000079f4d2ddb4d5  movaps [rsp+0x20], xmm3
000079f4d2ddb4da  lea rdi, [rsp]
000079f4d2ddb4de  mov esi, 0x00
000079f4d2ddb4e3  mov rax, 0x5D9EC01E8530
000079f4d2ddb4ed  call rax
000079f4d2ddb4ef  movaps xmm5, [rsp]
000079f4d2ddb4f3  add rsp, 0x30
000079f4d2ddb4f7  vmovaps xmm0, [rsp]
000079f4d2ddb4fc  vmovaps xmm1, [rsp+0x10]
000079f4d2ddb502  vmovaps xmm2, [rsp+0x20]
000079f4d2ddb508  vmovaps xmm3, [rsp+0x30]
000079f4d2ddb50e  vmovaps xmm4, [rsp+0x40]
000079f4d2ddb514  vmovaps xmm6, [rsp+0x50]
000079f4d2ddb51a  vmovaps xmm7, [rsp+0x60]
000079f4d2ddb520  vmovaps xmm8, [rsp+0x70]
000079f4d2ddb526  vmovaps xmm9, [rsp+0x80]
000079f4d2ddb52f  vmovaps xmm10, [rsp+0x90]
000079f4d2ddb538  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddb541  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddb54a  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddb553  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddb55c  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddb565  add rsp, 0xF0
000079f4d2ddb56c  pop r11
000079f4d2ddb56e  pop r10
000079f4d2ddb570  pop r9
000079f4d2ddb572  pop r8
000079f4d2ddb574  pop rsi
000079f4d2ddb575  pop rdi
000079f4d2ddb576  pop rdx
000079f4d2ddb577  pop rcx
000079f4d2ddb578  pop rax
000079f4d2ddb579  add rsp, 0x08
000079f4d2ddb57d  jmp 0x000079F4D2DD9167
000079f4d2ddb582  sub rsp, 0x08
000079f4d2ddb586  push rax
000079f4d2ddb587  push rcx
000079f4d2ddb588  push rdx
000079f4d2ddb589  push rdi
000079f4d2ddb58a  push rsi
000079f4d2ddb58b  push r8
000079f4d2ddb58d  push r9
000079f4d2ddb58f  push r10
000079f4d2ddb591  push r11
000079f4d2ddb593  sub rsp, 0xF0
000079f4d2ddb59a  vmovaps [rsp], xmm0
000079f4d2ddb59f  vmovaps [rsp+0x10], xmm1
000079f4d2ddb5a5  vmovaps [rsp+0x20], xmm2
000079f4d2ddb5ab  vmovaps [rsp+0x30], xmm3
000079f4d2ddb5b1  vmovaps [rsp+0x40], xmm4
000079f4d2ddb5b7  vmovaps [rsp+0x50], xmm5
000079f4d2ddb5bd  vmovaps [rsp+0x60], xmm7
000079f4d2ddb5c3  vmovaps [rsp+0x70], xmm8
000079f4d2ddb5c9  vmovaps [rsp+0x80], xmm9
000079f4d2ddb5d2  vmovaps [rsp+0x90], xmm10
000079f4d2ddb5db  vmovaps [rsp+0xA0], xmm11
000079f4d2ddb5e4  vmovaps [rsp+0xB0], xmm12
000079f4d2ddb5ed  vmovaps [rsp+0xC0], xmm13
000079f4d2ddb5f6  vmovaps [rsp+0xD0], xmm14
000079f4d2ddb5ff  vmovaps [rsp+0xE0], xmm15
000079f4d2ddb608  sub rsp, 0x30
000079f4d2ddb60c  movaps [rsp], xmm6
000079f4d2ddb610  movaps [rsp+0x10], xmm9
000079f4d2ddb616  movaps [rsp+0x20], xmm1
000079f4d2ddb61b  lea rdi, [rsp]
000079f4d2ddb61f  mov esi, 0x00
000079f4d2ddb624  mov rax, 0x5D9EC01E8530
000079f4d2ddb62e  call rax
000079f4d2ddb630  movaps xmm6, [rsp]
000079f4d2ddb634  add rsp, 0x30
000079f4d2ddb638  vmovaps xmm0, [rsp]
000079f4d2ddb63d  vmovaps xmm1, [rsp+0x10]
000079f4d2ddb643  vmovaps xmm2, [rsp+0x20]
000079f4d2ddb649  vmovaps xmm3, [rsp+0x30]
000079f4d2ddb64f  vmovaps xmm4, [rsp+0x40]
000079f4d2ddb655  vmovaps xmm5, [rsp+0x50]
000079f4d2ddb65b  vmovaps xmm7, [rsp+0x60]
000079f4d2ddb661  vmovaps xmm8, [rsp+0x70]
000079f4d2ddb667  vmovaps xmm9, [rsp+0x80]
000079f4d2ddb670  vmovaps xmm10, [rsp+0x90]
000079f4d2ddb679  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddb682  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddb68b  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddb694  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddb69d  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddb6a6  add rsp, 0xF0
000079f4d2ddb6ad  pop r11
000079f4d2ddb6af  pop r10
000079f4d2ddb6b1  pop r9
000079f4d2ddb6b3  pop r8
000079f4d2ddb6b5  pop rsi
000079f4d2ddb6b6  pop rdi
000079f4d2ddb6b7  pop rdx
000079f4d2ddb6b8  pop rcx
000079f4d2ddb6b9  pop rax
000079f4d2ddb6ba  add rsp, 0x08
000079f4d2ddb6be  jmp 0x000079F4D2DD918B
000079f4d2ddb6c3  sub rsp, 0x08
000079f4d2ddb6c7  push rax
000079f4d2ddb6c8  push rcx
000079f4d2ddb6c9  push rdx
000079f4d2ddb6ca  push rdi
000079f4d2ddb6cb  push rsi
000079f4d2ddb6cc  push r8
000079f4d2ddb6ce  push r9
000079f4d2ddb6d0  push r10
000079f4d2ddb6d2  push r11
000079f4d2ddb6d4  sub rsp, 0xF0
000079f4d2ddb6db  vmovaps [rsp], xmm0
000079f4d2ddb6e0  vmovaps [rsp+0x10], xmm1
000079f4d2ddb6e6  vmovaps [rsp+0x20], xmm2
000079f4d2ddb6ec  vmovaps [rsp+0x30], xmm3
000079f4d2ddb6f2  vmovaps [rsp+0x40], xmm4
000079f4d2ddb6f8  vmovaps [rsp+0x50], xmm5
000079f4d2ddb6fe  vmovaps [rsp+0x60], xmm6
000079f4d2ddb704  vmovaps [rsp+0x70], xmm7
000079f4d2ddb70a  vmovaps [rsp+0x80], xmm8
000079f4d2ddb713  vmovaps [rsp+0x90], xmm10
000079f4d2ddb71c  vmovaps [rsp+0xA0], xmm11
000079f4d2ddb725  vmovaps [rsp+0xB0], xmm12
000079f4d2ddb72e  vmovaps [rsp+0xC0], xmm13
000079f4d2ddb737  vmovaps [rsp+0xD0], xmm14
000079f4d2ddb740  vmovaps [rsp+0xE0], xmm15
000079f4d2ddb749  sub rsp, 0x30
000079f4d2ddb74d  movaps [rsp], xmm9
000079f4d2ddb752  movaps [rsp+0x10], xmm3
000079f4d2ddb757  movaps [rsp+0x20], xmm1
000079f4d2ddb75c  lea rdi, [rsp]
000079f4d2ddb760  mov esi, 0x00
000079f4d2ddb765  mov rax, 0x5D9EC01E8530
000079f4d2ddb76f  call rax
000079f4d2ddb771  movaps xmm9, [rsp]
000079f4d2ddb776  add rsp, 0x30
000079f4d2ddb77a  vmovaps xmm0, [rsp]
000079f4d2ddb77f  vmovaps xmm1, [rsp+0x10]
000079f4d2ddb785  vmovaps xmm2, [rsp+0x20]
000079f4d2ddb78b  vmovaps xmm3, [rsp+0x30]
000079f4d2ddb791  vmovaps xmm4, [rsp+0x40]
000079f4d2ddb797  vmovaps xmm5, [rsp+0x50]
000079f4d2ddb79d  vmovaps xmm6, [rsp+0x60]
000079f4d2ddb7a3  vmovaps xmm7, [rsp+0x70]
000079f4d2ddb7a9  vmovaps xmm8, [rsp+0x80]
000079f4d2ddb7b2  vmovaps xmm10, [rsp+0x90]
000079f4d2ddb7bb  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddb7c4  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddb7cd  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddb7d6  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddb7df  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddb7e8  add rsp, 0xF0
000079f4d2ddb7ef  pop r11
000079f4d2ddb7f1  pop r10
000079f4d2ddb7f3  pop r9
000079f4d2ddb7f5  pop r8
000079f4d2ddb7f7  pop rsi
000079f4d2ddb7f8  pop rdi
000079f4d2ddb7f9  pop rdx
000079f4d2ddb7fa  pop rcx
000079f4d2ddb7fb  pop rax
000079f4d2ddb7fc  add rsp, 0x08
000079f4d2ddb800  jmp 0x000079F4D2DD91D7
000079f4d2ddb805  call 0x000079F4D2CD64F0
000079f4d2ddb80a  jmp 0x000079F4D2DD91E4
000079f4d2ddb80f  sub rsp, 0x08
000079f4d2ddb813  push rax
000079f4d2ddb814  push rcx
000079f4d2ddb815  push rdx
000079f4d2ddb816  push rdi
000079f4d2ddb817  push rsi
000079f4d2ddb818  push r8
000079f4d2ddb81a  push r9
000079f4d2ddb81c  push r10
000079f4d2ddb81e  push r11
000079f4d2ddb820  sub rsp, 0xF0
000079f4d2ddb827  vmovaps [rsp], xmm0
000079f4d2ddb82c  vmovaps [rsp+0x10], xmm1
000079f4d2ddb832  vmovaps [rsp+0x20], xmm2
000079f4d2ddb838  vmovaps [rsp+0x30], xmm3
000079f4d2ddb83e  vmovaps [rsp+0x40], xmm4
000079f4d2ddb844  vmovaps [rsp+0x50], xmm5
000079f4d2ddb84a  vmovaps [rsp+0x60], xmm6
000079f4d2ddb850  vmovaps [rsp+0x70], xmm7
000079f4d2ddb856  vmovaps [rsp+0x80], xmm8
000079f4d2ddb85f  vmovaps [rsp+0x90], xmm9
000079f4d2ddb868  vmovaps [rsp+0xA0], xmm10
000079f4d2ddb871  vmovaps [rsp+0xB0], xmm11
000079f4d2ddb87a  vmovaps [rsp+0xC0], xmm12
000079f4d2ddb883  vmovaps [rsp+0xD0], xmm13
000079f4d2ddb88c  vmovaps [rsp+0xE0], xmm14
000079f4d2ddb895  sub rsp, 0x30
000079f4d2ddb899  movaps [rsp], xmm15
000079f4d2ddb89e  movaps [rsp+0x10], xmm3
000079f4d2ddb8a3  movaps [rsp+0x20], xmm7
000079f4d2ddb8a8  lea rdi, [rsp]
000079f4d2ddb8ac  mov esi, 0x00
000079f4d2ddb8b1  mov rax, 0x5D9EC01E8530
000079f4d2ddb8bb  call rax
000079f4d2ddb8bd  movaps xmm15, [rsp]
000079f4d2ddb8c2  add rsp, 0x30
000079f4d2ddb8c6  vmovaps xmm0, [rsp]
000079f4d2ddb8cb  vmovaps xmm1, [rsp+0x10]
000079f4d2ddb8d1  vmovaps xmm2, [rsp+0x20]
000079f4d2ddb8d7  vmovaps xmm3, [rsp+0x30]
000079f4d2ddb8dd  vmovaps xmm4, [rsp+0x40]
000079f4d2ddb8e3  vmovaps xmm5, [rsp+0x50]
000079f4d2ddb8e9  vmovaps xmm6, [rsp+0x60]
000079f4d2ddb8ef  vmovaps xmm7, [rsp+0x70]
000079f4d2ddb8f5  vmovaps xmm8, [rsp+0x80]
000079f4d2ddb8fe  vmovaps xmm9, [rsp+0x90]
000079f4d2ddb907  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddb910  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddb919  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddb922  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddb92b  vmovaps xmm14, [rsp+0xE0]
000079f4d2ddb934  add rsp, 0xF0
000079f4d2ddb93b  pop r11
000079f4d2ddb93d  pop r10
000079f4d2ddb93f  pop r9
000079f4d2ddb941  pop r8
000079f4d2ddb943  pop rsi
000079f4d2ddb944  pop rdi
000079f4d2ddb945  pop rdx
000079f4d2ddb946  pop rcx
000079f4d2ddb947  pop rax
000079f4d2ddb948  add rsp, 0x08
000079f4d2ddb94c  jmp 0x000079F4D2DD9210
000079f4d2ddb951  sub rsp, 0x08
000079f4d2ddb955  push rax
000079f4d2ddb956  push rcx
000079f4d2ddb957  push rdx
000079f4d2ddb958  push rdi
000079f4d2ddb959  push rsi
000079f4d2ddb95a  push r8
000079f4d2ddb95c  push r9
000079f4d2ddb95e  push r10
000079f4d2ddb960  push r11
000079f4d2ddb962  sub rsp, 0xF0
000079f4d2ddb969  vmovaps [rsp], xmm0
000079f4d2ddb96e  vmovaps [rsp+0x10], xmm1
000079f4d2ddb974  vmovaps [rsp+0x20], xmm2
000079f4d2ddb97a  vmovaps [rsp+0x30], xmm4
000079f4d2ddb980  vmovaps [rsp+0x40], xmm5
000079f4d2ddb986  vmovaps [rsp+0x50], xmm6
000079f4d2ddb98c  vmovaps [rsp+0x60], xmm7
000079f4d2ddb992  vmovaps [rsp+0x70], xmm8
000079f4d2ddb998  vmovaps [rsp+0x80], xmm9
000079f4d2ddb9a1  vmovaps [rsp+0x90], xmm10
000079f4d2ddb9aa  vmovaps [rsp+0xA0], xmm11
000079f4d2ddb9b3  vmovaps [rsp+0xB0], xmm12
000079f4d2ddb9bc  vmovaps [rsp+0xC0], xmm13
000079f4d2ddb9c5  vmovaps [rsp+0xD0], xmm14
000079f4d2ddb9ce  vmovaps [rsp+0xE0], xmm15
000079f4d2ddb9d7  sub rsp, 0x30
000079f4d2ddb9db  movaps [rsp], xmm3
000079f4d2ddb9df  movaps [rsp+0x10], xmm1
000079f4d2ddb9e4  movaps [rsp+0x20], xmm15
000079f4d2ddb9ea  lea rdi, [rsp]
000079f4d2ddb9ee  mov esi, 0x00
000079f4d2ddb9f3  mov rax, 0x5D9EC01E8530
000079f4d2ddb9fd  call rax
000079f4d2ddb9ff  movaps xmm3, [rsp]
000079f4d2ddba03  add rsp, 0x30
000079f4d2ddba07  vmovaps xmm0, [rsp]
000079f4d2ddba0c  vmovaps xmm1, [rsp+0x10]
000079f4d2ddba12  vmovaps xmm2, [rsp+0x20]
000079f4d2ddba18  vmovaps xmm4, [rsp+0x30]
000079f4d2ddba1e  vmovaps xmm5, [rsp+0x40]
000079f4d2ddba24  vmovaps xmm6, [rsp+0x50]
000079f4d2ddba2a  vmovaps xmm7, [rsp+0x60]
000079f4d2ddba30  vmovaps xmm8, [rsp+0x70]
000079f4d2ddba36  vmovaps xmm9, [rsp+0x80]
000079f4d2ddba3f  vmovaps xmm10, [rsp+0x90]
000079f4d2ddba48  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddba51  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddba5a  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddba63  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddba6c  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddba75  add rsp, 0xF0
000079f4d2ddba7c  pop r11
000079f4d2ddba7e  pop r10
000079f4d2ddba80  pop r9
000079f4d2ddba82  pop r8
000079f4d2ddba84  pop rsi
000079f4d2ddba85  pop rdi
000079f4d2ddba86  pop rdx
000079f4d2ddba87  pop rcx
000079f4d2ddba88  pop rax
000079f4d2ddba89  add rsp, 0x08
000079f4d2ddba8d  jmp 0x000079F4D2DD929F
000079f4d2ddba92  call 0x000079F4D2CD64F0
000079f4d2ddba97  jmp 0x000079F4D2DD92A9
000079f4d2ddba9c  sub rsp, 0x08
000079f4d2ddbaa0  push rax
000079f4d2ddbaa1  push rcx
000079f4d2ddbaa2  push rdx
000079f4d2ddbaa3  push rdi
000079f4d2ddbaa4  push rsi
000079f4d2ddbaa5  push r8
000079f4d2ddbaa7  push r9
000079f4d2ddbaa9  push r10
000079f4d2ddbaab  push r11
000079f4d2ddbaad  sub rsp, 0xF0
000079f4d2ddbab4  vmovaps [rsp], xmm0
000079f4d2ddbab9  vmovaps [rsp+0x10], xmm1
000079f4d2ddbabf  vmovaps [rsp+0x20], xmm2
000079f4d2ddbac5  vmovaps [rsp+0x30], xmm3
000079f4d2ddbacb  vmovaps [rsp+0x40], xmm4
000079f4d2ddbad1  vmovaps [rsp+0x50], xmm5
000079f4d2ddbad7  vmovaps [rsp+0x60], xmm6
000079f4d2ddbadd  vmovaps [rsp+0x70], xmm7
000079f4d2ddbae3  vmovaps [rsp+0x80], xmm8
000079f4d2ddbaec  vmovaps [rsp+0x90], xmm9
000079f4d2ddbaf5  vmovaps [rsp+0xA0], xmm10
000079f4d2ddbafe  vmovaps [rsp+0xB0], xmm11
000079f4d2ddbb07  vmovaps [rsp+0xC0], xmm12
000079f4d2ddbb10  vmovaps [rsp+0xD0], xmm13
000079f4d2ddbb19  vmovaps [rsp+0xE0], xmm14
000079f4d2ddbb22  sub rsp, 0x30
000079f4d2ddbb26  movaps [rsp], xmm15
000079f4d2ddbb2b  movaps [rsp+0x10], xmm14
000079f4d2ddbb31  movaps [rsp+0x20], xmm4
000079f4d2ddbb36  lea rdi, [rsp]
000079f4d2ddbb3a  mov esi, 0x00
000079f4d2ddbb3f  mov rax, 0x5D9EC01E8530
000079f4d2ddbb49  call rax
000079f4d2ddbb4b  movaps xmm15, [rsp]
000079f4d2ddbb50  add rsp, 0x30
000079f4d2ddbb54  vmovaps xmm0, [rsp]
000079f4d2ddbb59  vmovaps xmm1, [rsp+0x10]
000079f4d2ddbb5f  vmovaps xmm2, [rsp+0x20]
000079f4d2ddbb65  vmovaps xmm3, [rsp+0x30]
000079f4d2ddbb6b  vmovaps xmm4, [rsp+0x40]
000079f4d2ddbb71  vmovaps xmm5, [rsp+0x50]
000079f4d2ddbb77  vmovaps xmm6, [rsp+0x60]
000079f4d2ddbb7d  vmovaps xmm7, [rsp+0x70]
000079f4d2ddbb83  vmovaps xmm8, [rsp+0x80]
000079f4d2ddbb8c  vmovaps xmm9, [rsp+0x90]
000079f4d2ddbb95  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddbb9e  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddbba7  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddbbb0  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddbbb9  vmovaps xmm14, [rsp+0xE0]
000079f4d2ddbbc2  add rsp, 0xF0
000079f4d2ddbbc9  pop r11
000079f4d2ddbbcb  pop r10
000079f4d2ddbbcd  pop r9
000079f4d2ddbbcf  pop r8
000079f4d2ddbbd1  pop rsi
000079f4d2ddbbd2  pop rdi
000079f4d2ddbbd3  pop rdx
000079f4d2ddbbd4  pop rcx
000079f4d2ddbbd5  pop rax
000079f4d2ddbbd6  add rsp, 0x08
000079f4d2ddbbda  jmp 0x000079F4D2DD92D7
000079f4d2ddbbdf  sub rsp, 0x08
000079f4d2ddbbe3  push rax
000079f4d2ddbbe4  push rcx
000079f4d2ddbbe5  push rdx
000079f4d2ddbbe6  push rdi
000079f4d2ddbbe7  push rsi
000079f4d2ddbbe8  push r8
000079f4d2ddbbea  push r9
000079f4d2ddbbec  push r10
000079f4d2ddbbee  push r11
000079f4d2ddbbf0  sub rsp, 0xF0
000079f4d2ddbbf7  vmovaps [rsp], xmm0
000079f4d2ddbbfc  vmovaps [rsp+0x10], xmm1
000079f4d2ddbc02  vmovaps [rsp+0x20], xmm2
000079f4d2ddbc08  vmovaps [rsp+0x30], xmm3
000079f4d2ddbc0e  vmovaps [rsp+0x40], xmm4
000079f4d2ddbc14  vmovaps [rsp+0x50], xmm5
000079f4d2ddbc1a  vmovaps [rsp+0x60], xmm6
000079f4d2ddbc20  vmovaps [rsp+0x70], xmm7
000079f4d2ddbc26  vmovaps [rsp+0x80], xmm8
000079f4d2ddbc2f  vmovaps [rsp+0x90], xmm9
000079f4d2ddbc38  vmovaps [rsp+0xA0], xmm10
000079f4d2ddbc41  vmovaps [rsp+0xB0], xmm11
000079f4d2ddbc4a  vmovaps [rsp+0xC0], xmm12
000079f4d2ddbc53  vmovaps [rsp+0xD0], xmm13
000079f4d2ddbc5c  vmovaps [rsp+0xE0], xmm15
000079f4d2ddbc65  sub rsp, 0x30
000079f4d2ddbc69  movaps [rsp], xmm14
000079f4d2ddbc6e  movaps [rsp+0x10], xmm2
000079f4d2ddbc73  movaps [rsp+0x20], xmm1
000079f4d2ddbc78  lea rdi, [rsp]
000079f4d2ddbc7c  mov esi, 0x00
000079f4d2ddbc81  mov rax, 0x5D9EC01E8530
000079f4d2ddbc8b  call rax
000079f4d2ddbc8d  movaps xmm14, [rsp]
000079f4d2ddbc92  add rsp, 0x30
000079f4d2ddbc96  vmovaps xmm0, [rsp]
000079f4d2ddbc9b  vmovaps xmm1, [rsp+0x10]
000079f4d2ddbca1  vmovaps xmm2, [rsp+0x20]
000079f4d2ddbca7  vmovaps xmm3, [rsp+0x30]
000079f4d2ddbcad  vmovaps xmm4, [rsp+0x40]
000079f4d2ddbcb3  vmovaps xmm5, [rsp+0x50]
000079f4d2ddbcb9  vmovaps xmm6, [rsp+0x60]
000079f4d2ddbcbf  vmovaps xmm7, [rsp+0x70]
000079f4d2ddbcc5  vmovaps xmm8, [rsp+0x80]
000079f4d2ddbcce  vmovaps xmm9, [rsp+0x90]
000079f4d2ddbcd7  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddbce0  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddbce9  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddbcf2  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddbcfb  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddbd04  add rsp, 0xF0
000079f4d2ddbd0b  pop r11
000079f4d2ddbd0d  pop r10
000079f4d2ddbd0f  pop r9
000079f4d2ddbd11  pop r8
000079f4d2ddbd13  pop rsi
000079f4d2ddbd14  pop rdi
000079f4d2ddbd15  pop rdx
000079f4d2ddbd16  pop rcx
000079f4d2ddbd17  pop rax
000079f4d2ddbd18  add rsp, 0x08
000079f4d2ddbd1c  jmp 0x000079F4D2DD92FD
000079f4d2ddbd21  sub rsp, 0x08
000079f4d2ddbd25  push rax
000079f4d2ddbd26  push rcx
000079f4d2ddbd27  push rdx
000079f4d2ddbd28  push rdi
000079f4d2ddbd29  push rsi
000079f4d2ddbd2a  push r8
000079f4d2ddbd2c  push r9
000079f4d2ddbd2e  push r10
000079f4d2ddbd30  push r11
000079f4d2ddbd32  sub rsp, 0xF0
000079f4d2ddbd39  vmovaps [rsp], xmm0
000079f4d2ddbd3e  vmovaps [rsp+0x10], xmm2
000079f4d2ddbd44  vmovaps [rsp+0x20], xmm3
000079f4d2ddbd4a  vmovaps [rsp+0x30], xmm4
000079f4d2ddbd50  vmovaps [rsp+0x40], xmm5
000079f4d2ddbd56  vmovaps [rsp+0x50], xmm6
000079f4d2ddbd5c  vmovaps [rsp+0x60], xmm7
000079f4d2ddbd62  vmovaps [rsp+0x70], xmm8
000079f4d2ddbd68  vmovaps [rsp+0x80], xmm9
000079f4d2ddbd71  vmovaps [rsp+0x90], xmm10
000079f4d2ddbd7a  vmovaps [rsp+0xA0], xmm11
000079f4d2ddbd83  vmovaps [rsp+0xB0], xmm12
000079f4d2ddbd8c  vmovaps [rsp+0xC0], xmm13
000079f4d2ddbd95  vmovaps [rsp+0xD0], xmm14
000079f4d2ddbd9e  vmovaps [rsp+0xE0], xmm15
000079f4d2ddbda7  sub rsp, 0x30
000079f4d2ddbdab  movaps [rsp], xmm1
000079f4d2ddbdaf  movaps [rsp+0x10], xmm4
000079f4d2ddbdb4  movaps [rsp+0x20], xmm9
000079f4d2ddbdba  lea rdi, [rsp]
000079f4d2ddbdbe  mov esi, 0x00
000079f4d2ddbdc3  mov rax, 0x5D9EC01E8530
000079f4d2ddbdcd  call rax
000079f4d2ddbdcf  movaps xmm1, [rsp]
000079f4d2ddbdd3  add rsp, 0x30
000079f4d2ddbdd7  vmovaps xmm0, [rsp]
000079f4d2ddbddc  vmovaps xmm2, [rsp+0x10]
000079f4d2ddbde2  vmovaps xmm3, [rsp+0x20]
000079f4d2ddbde8  vmovaps xmm4, [rsp+0x30]
000079f4d2ddbdee  vmovaps xmm5, [rsp+0x40]
000079f4d2ddbdf4  vmovaps xmm6, [rsp+0x50]
000079f4d2ddbdfa  vmovaps xmm7, [rsp+0x60]
000079f4d2ddbe00  vmovaps xmm8, [rsp+0x70]
000079f4d2ddbe06  vmovaps xmm9, [rsp+0x80]
000079f4d2ddbe0f  vmovaps xmm10, [rsp+0x90]
000079f4d2ddbe18  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddbe21  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddbe2a  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddbe33  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddbe3c  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddbe45  add rsp, 0xF0
000079f4d2ddbe4c  pop r11
000079f4d2ddbe4e  pop r10
000079f4d2ddbe50  pop r9
000079f4d2ddbe52  pop r8
000079f4d2ddbe54  pop rsi
000079f4d2ddbe55  pop rdi
000079f4d2ddbe56  pop rdx
000079f4d2ddbe57  pop rcx
000079f4d2ddbe58  pop rax
000079f4d2ddbe59  add rsp, 0x08
000079f4d2ddbe5d  jmp 0x000079F4D2DD931B
000079f4d2ddbe62  sub rsp, 0x08
000079f4d2ddbe66  push rax
000079f4d2ddbe67  push rcx
000079f4d2ddbe68  push rdx
000079f4d2ddbe69  push rdi
000079f4d2ddbe6a  push rsi
000079f4d2ddbe6b  push r8
000079f4d2ddbe6d  push r9
000079f4d2ddbe6f  push r10
000079f4d2ddbe71  push r11
000079f4d2ddbe73  sub rsp, 0xF0
000079f4d2ddbe7a  vmovaps [rsp], xmm0
000079f4d2ddbe7f  vmovaps [rsp+0x10], xmm1
000079f4d2ddbe85  vmovaps [rsp+0x20], xmm2
000079f4d2ddbe8b  vmovaps [rsp+0x30], xmm3
000079f4d2ddbe91  vmovaps [rsp+0x40], xmm5
000079f4d2ddbe97  vmovaps [rsp+0x50], xmm6
000079f4d2ddbe9d  vmovaps [rsp+0x60], xmm7
000079f4d2ddbea3  vmovaps [rsp+0x70], xmm8
000079f4d2ddbea9  vmovaps [rsp+0x80], xmm9
000079f4d2ddbeb2  vmovaps [rsp+0x90], xmm10
000079f4d2ddbebb  vmovaps [rsp+0xA0], xmm11
000079f4d2ddbec4  vmovaps [rsp+0xB0], xmm12
000079f4d2ddbecd  vmovaps [rsp+0xC0], xmm13
000079f4d2ddbed6  vmovaps [rsp+0xD0], xmm14
000079f4d2ddbedf  vmovaps [rsp+0xE0], xmm15
000079f4d2ddbee8  sub rsp, 0x30
000079f4d2ddbeec  movaps [rsp], xmm4
000079f4d2ddbef0  movaps [rsp+0x10], xmm2
000079f4d2ddbef5  movaps [rsp+0x20], xmm9
000079f4d2ddbefb  lea rdi, [rsp]
000079f4d2ddbeff  mov esi, 0x00
000079f4d2ddbf04  mov rax, 0x5D9EC01E8530
000079f4d2ddbf0e  call rax
000079f4d2ddbf10  movaps xmm4, [rsp]
000079f4d2ddbf14  add rsp, 0x30
000079f4d2ddbf18  vmovaps xmm0, [rsp]
000079f4d2ddbf1d  vmovaps xmm1, [rsp+0x10]
000079f4d2ddbf23  vmovaps xmm2, [rsp+0x20]
000079f4d2ddbf29  vmovaps xmm3, [rsp+0x30]
000079f4d2ddbf2f  vmovaps xmm5, [rsp+0x40]
000079f4d2ddbf35  vmovaps xmm6, [rsp+0x50]
000079f4d2ddbf3b  vmovaps xmm7, [rsp+0x60]
000079f4d2ddbf41  vmovaps xmm8, [rsp+0x70]
000079f4d2ddbf47  vmovaps xmm9, [rsp+0x80]
000079f4d2ddbf50  vmovaps xmm10, [rsp+0x90]
000079f4d2ddbf59  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddbf62  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddbf6b  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddbf74  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddbf7d  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddbf86  add rsp, 0xF0
000079f4d2ddbf8d  pop r11
000079f4d2ddbf8f  pop r10
000079f4d2ddbf91  pop r9
000079f4d2ddbf93  pop r8
000079f4d2ddbf95  pop rsi
000079f4d2ddbf96  pop rdi
000079f4d2ddbf97  pop rdx
000079f4d2ddbf98  pop rcx
000079f4d2ddbf99  pop rax
000079f4d2ddbf9a  add rsp, 0x08
000079f4d2ddbf9e  jmp 0x000079F4D2DD934B
000079f4d2ddbfa3  sub rsp, 0x08
000079f4d2ddbfa7  push rax
000079f4d2ddbfa8  push rcx
000079f4d2ddbfa9  push rdx
000079f4d2ddbfaa  push rdi
000079f4d2ddbfab  push rsi
000079f4d2ddbfac  push r8
000079f4d2ddbfae  push r9
000079f4d2ddbfb0  push r10
000079f4d2ddbfb2  push r11
000079f4d2ddbfb4  sub rsp, 0xF0
000079f4d2ddbfbb  vmovaps [rsp], xmm0
000079f4d2ddbfc0  vmovaps [rsp+0x10], xmm1
000079f4d2ddbfc6  vmovaps [rsp+0x20], xmm2
000079f4d2ddbfcc  vmovaps [rsp+0x30], xmm3
000079f4d2ddbfd2  vmovaps [rsp+0x40], xmm4
000079f4d2ddbfd8  vmovaps [rsp+0x50], xmm5
000079f4d2ddbfde  vmovaps [rsp+0x60], xmm6
000079f4d2ddbfe4  vmovaps [rsp+0x70], xmm7
000079f4d2ddbfea  vmovaps [rsp+0x80], xmm8
000079f4d2ddbff3  vmovaps [rsp+0x90], xmm10
000079f4d2ddbffc  vmovaps [rsp+0xA0], xmm11
000079f4d2ddc005  vmovaps [rsp+0xB0], xmm12
000079f4d2ddc00e  vmovaps [rsp+0xC0], xmm13
000079f4d2ddc017  vmovaps [rsp+0xD0], xmm14
000079f4d2ddc020  vmovaps [rsp+0xE0], xmm15
000079f4d2ddc029  sub rsp, 0x30
000079f4d2ddc02d  movaps [rsp], xmm9
000079f4d2ddc032  movaps [rsp+0x10], xmm2
000079f4d2ddc037  movaps [rsp+0x20], xmm1
000079f4d2ddc03c  lea rdi, [rsp]
000079f4d2ddc040  mov esi, 0x00
000079f4d2ddc045  mov rax, 0x5D9EC01E8530
000079f4d2ddc04f  call rax
000079f4d2ddc051  movaps xmm9, [rsp]
000079f4d2ddc056  add rsp, 0x30
000079f4d2ddc05a  vmovaps xmm0, [rsp]
000079f4d2ddc05f  vmovaps xmm1, [rsp+0x10]
000079f4d2ddc065  vmovaps xmm2, [rsp+0x20]
000079f4d2ddc06b  vmovaps xmm3, [rsp+0x30]
000079f4d2ddc071  vmovaps xmm4, [rsp+0x40]
000079f4d2ddc077  vmovaps xmm5, [rsp+0x50]
000079f4d2ddc07d  vmovaps xmm6, [rsp+0x60]
000079f4d2ddc083  vmovaps xmm7, [rsp+0x70]
000079f4d2ddc089  vmovaps xmm8, [rsp+0x80]
000079f4d2ddc092  vmovaps xmm10, [rsp+0x90]
000079f4d2ddc09b  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddc0a4  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddc0ad  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddc0b6  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddc0bf  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddc0c8  add rsp, 0xF0
000079f4d2ddc0cf  pop r11
000079f4d2ddc0d1  pop r10
000079f4d2ddc0d3  pop r9
000079f4d2ddc0d5  pop r8
000079f4d2ddc0d7  pop rsi
000079f4d2ddc0d8  pop rdi
000079f4d2ddc0d9  pop rdx
000079f4d2ddc0da  pop rcx
000079f4d2ddc0db  pop rax
000079f4d2ddc0dc  add rsp, 0x08
000079f4d2ddc0e0  jmp 0x000079F4D2DD9381
000079f4d2ddc0e5  sub rsp, 0x08
000079f4d2ddc0e9  push rax
000079f4d2ddc0ea  push rcx
000079f4d2ddc0eb  push rdx
000079f4d2ddc0ec  push rdi
000079f4d2ddc0ed  push rsi
000079f4d2ddc0ee  push r8
000079f4d2ddc0f0  push r9
000079f4d2ddc0f2  push r10
000079f4d2ddc0f4  push r11
000079f4d2ddc0f6  sub rsp, 0xF0
000079f4d2ddc0fd  vmovaps [rsp], xmm0
000079f4d2ddc102  vmovaps [rsp+0x10], xmm2
000079f4d2ddc108  vmovaps [rsp+0x20], xmm3
000079f4d2ddc10e  vmovaps [rsp+0x30], xmm4
000079f4d2ddc114  vmovaps [rsp+0x40], xmm5
000079f4d2ddc11a  vmovaps [rsp+0x50], xmm6
000079f4d2ddc120  vmovaps [rsp+0x60], xmm7
000079f4d2ddc126  vmovaps [rsp+0x70], xmm8
000079f4d2ddc12c  vmovaps [rsp+0x80], xmm9
000079f4d2ddc135  vmovaps [rsp+0x90], xmm10
000079f4d2ddc13e  vmovaps [rsp+0xA0], xmm11
000079f4d2ddc147  vmovaps [rsp+0xB0], xmm12
000079f4d2ddc150  vmovaps [rsp+0xC0], xmm13
000079f4d2ddc159  vmovaps [rsp+0xD0], xmm14
000079f4d2ddc162  vmovaps [rsp+0xE0], xmm15
000079f4d2ddc16b  sub rsp, 0x30
000079f4d2ddc16f  movaps [rsp], xmm1
000079f4d2ddc173  movaps [rsp+0x10], xmm15
000079f4d2ddc179  movaps [rsp+0x20], xmm6
000079f4d2ddc17e  lea rdi, [rsp]
000079f4d2ddc182  mov esi, 0x00
000079f4d2ddc187  mov rax, 0x5D9EC01E8530
000079f4d2ddc191  call rax
000079f4d2ddc193  movaps xmm1, [rsp]
000079f4d2ddc197  add rsp, 0x30
000079f4d2ddc19b  vmovaps xmm0, [rsp]
000079f4d2ddc1a0  vmovaps xmm2, [rsp+0x10]
000079f4d2ddc1a6  vmovaps xmm3, [rsp+0x20]
000079f4d2ddc1ac  vmovaps xmm4, [rsp+0x30]
000079f4d2ddc1b2  vmovaps xmm5, [rsp+0x40]
000079f4d2ddc1b8  vmovaps xmm6, [rsp+0x50]
000079f4d2ddc1be  vmovaps xmm7, [rsp+0x60]
000079f4d2ddc1c4  vmovaps xmm8, [rsp+0x70]
000079f4d2ddc1ca  vmovaps xmm9, [rsp+0x80]
000079f4d2ddc1d3  vmovaps xmm10, [rsp+0x90]
000079f4d2ddc1dc  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddc1e5  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddc1ee  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddc1f7  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddc200  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddc209  add rsp, 0xF0
000079f4d2ddc210  pop r11
000079f4d2ddc212  pop r10
000079f4d2ddc214  pop r9
000079f4d2ddc216  pop r8
000079f4d2ddc218  pop rsi
000079f4d2ddc219  pop rdi
000079f4d2ddc21a  pop rdx
000079f4d2ddc21b  pop rcx
000079f4d2ddc21c  pop rax
000079f4d2ddc21d  add rsp, 0x08
000079f4d2ddc221  jmp 0x000079F4D2DD93A2
000079f4d2ddc226  sub rsp, 0x08
000079f4d2ddc22a  push rax
000079f4d2ddc22b  push rcx
000079f4d2ddc22c  push rdx
000079f4d2ddc22d  push rdi
000079f4d2ddc22e  push rsi
000079f4d2ddc22f  push r8
000079f4d2ddc231  push r9
000079f4d2ddc233  push r10
000079f4d2ddc235  push r11
000079f4d2ddc237  sub rsp, 0xF0
000079f4d2ddc23e  vmovaps [rsp], xmm0
000079f4d2ddc243  vmovaps [rsp+0x10], xmm1
000079f4d2ddc249  vmovaps [rsp+0x20], xmm2
000079f4d2ddc24f  vmovaps [rsp+0x30], xmm3
000079f4d2ddc255  vmovaps [rsp+0x40], xmm4
000079f4d2ddc25b  vmovaps [rsp+0x50], xmm5
000079f4d2ddc261  vmovaps [rsp+0x60], xmm6
000079f4d2ddc267  vmovaps [rsp+0x70], xmm7
000079f4d2ddc26d  vmovaps [rsp+0x80], xmm8
000079f4d2ddc276  vmovaps [rsp+0x90], xmm9
000079f4d2ddc27f  vmovaps [rsp+0xA0], xmm10
000079f4d2ddc288  vmovaps [rsp+0xB0], xmm11
000079f4d2ddc291  vmovaps [rsp+0xC0], xmm12
000079f4d2ddc29a  vmovaps [rsp+0xD0], xmm13
000079f4d2ddc2a3  vmovaps [rsp+0xE0], xmm14
000079f4d2ddc2ac  sub rsp, 0x30
000079f4d2ddc2b0  movaps [rsp], xmm15
000079f4d2ddc2b5  movaps [rsp+0x10], xmm5
000079f4d2ddc2ba  movaps [rsp+0x20], xmm3
000079f4d2ddc2bf  lea rdi, [rsp]
000079f4d2ddc2c3  mov esi, 0x00
000079f4d2ddc2c8  mov rax, 0x5D9EC01E8530
000079f4d2ddc2d2  call rax
000079f4d2ddc2d4  movaps xmm15, [rsp]
000079f4d2ddc2d9  add rsp, 0x30
000079f4d2ddc2dd  vmovaps xmm0, [rsp]
000079f4d2ddc2e2  vmovaps xmm1, [rsp+0x10]
000079f4d2ddc2e8  vmovaps xmm2, [rsp+0x20]
000079f4d2ddc2ee  vmovaps xmm3, [rsp+0x30]
000079f4d2ddc2f4  vmovaps xmm4, [rsp+0x40]
000079f4d2ddc2fa  vmovaps xmm5, [rsp+0x50]
000079f4d2ddc300  vmovaps xmm6, [rsp+0x60]
000079f4d2ddc306  vmovaps xmm7, [rsp+0x70]
000079f4d2ddc30c  vmovaps xmm8, [rsp+0x80]
000079f4d2ddc315  vmovaps xmm9, [rsp+0x90]
000079f4d2ddc31e  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddc327  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddc330  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddc339  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddc342  vmovaps xmm14, [rsp+0xE0]
000079f4d2ddc34b  add rsp, 0xF0
000079f4d2ddc352  pop r11
000079f4d2ddc354  pop r10
000079f4d2ddc356  pop r9
000079f4d2ddc358  pop r8
000079f4d2ddc35a  pop rsi
000079f4d2ddc35b  pop rdi
000079f4d2ddc35c  pop rdx
000079f4d2ddc35d  pop rcx
000079f4d2ddc35e  pop rax
000079f4d2ddc35f  add rsp, 0x08
000079f4d2ddc363  jmp 0x000079F4D2DD93BC
000079f4d2ddc368  sub rsp, 0x08
000079f4d2ddc36c  push rax
000079f4d2ddc36d  push rcx
000079f4d2ddc36e  push rdx
000079f4d2ddc36f  push rdi
000079f4d2ddc370  push rsi
000079f4d2ddc371  push r8
000079f4d2ddc373  push r9
000079f4d2ddc375  push r10
000079f4d2ddc377  push r11
000079f4d2ddc379  sub rsp, 0xF0
000079f4d2ddc380  vmovaps [rsp], xmm0
000079f4d2ddc385  vmovaps [rsp+0x10], xmm1
000079f4d2ddc38b  vmovaps [rsp+0x20], xmm2
000079f4d2ddc391  vmovaps [rsp+0x30], xmm3
000079f4d2ddc397  vmovaps [rsp+0x40], xmm4
000079f4d2ddc39d  vmovaps [rsp+0x50], xmm6
000079f4d2ddc3a3  vmovaps [rsp+0x60], xmm7
000079f4d2ddc3a9  vmovaps [rsp+0x70], xmm8
000079f4d2ddc3af  vmovaps [rsp+0x80], xmm9
000079f4d2ddc3b8  vmovaps [rsp+0x90], xmm10
000079f4d2ddc3c1  vmovaps [rsp+0xA0], xmm11
000079f4d2ddc3ca  vmovaps [rsp+0xB0], xmm12
000079f4d2ddc3d3  vmovaps [rsp+0xC0], xmm13
000079f4d2ddc3dc  vmovaps [rsp+0xD0], xmm14
000079f4d2ddc3e5  vmovaps [rsp+0xE0], xmm15
000079f4d2ddc3ee  sub rsp, 0x30
000079f4d2ddc3f2  movaps [rsp], xmm5
000079f4d2ddc3f6  movaps [rsp+0x10], xmm8
000079f4d2ddc3fc  movaps [rsp+0x20], xmm6
000079f4d2ddc401  lea rdi, [rsp]
000079f4d2ddc405  mov esi, 0x00
000079f4d2ddc40a  mov rax, 0x5D9EC01E8530
000079f4d2ddc414  call rax
000079f4d2ddc416  movaps xmm5, [rsp]
000079f4d2ddc41a  add rsp, 0x30
000079f4d2ddc41e  vmovaps xmm0, [rsp]
000079f4d2ddc423  vmovaps xmm1, [rsp+0x10]
000079f4d2ddc429  vmovaps xmm2, [rsp+0x20]
000079f4d2ddc42f  vmovaps xmm3, [rsp+0x30]
000079f4d2ddc435  vmovaps xmm4, [rsp+0x40]
000079f4d2ddc43b  vmovaps xmm6, [rsp+0x50]
000079f4d2ddc441  vmovaps xmm7, [rsp+0x60]
000079f4d2ddc447  vmovaps xmm8, [rsp+0x70]
000079f4d2ddc44d  vmovaps xmm9, [rsp+0x80]
000079f4d2ddc456  vmovaps xmm10, [rsp+0x90]
000079f4d2ddc45f  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddc468  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddc471  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddc47a  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddc483  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddc48c  add rsp, 0xF0
000079f4d2ddc493  pop r11
000079f4d2ddc495  pop r10
000079f4d2ddc497  pop r9
000079f4d2ddc499  pop r8
000079f4d2ddc49b  pop rsi
000079f4d2ddc49c  pop rdi
000079f4d2ddc49d  pop rdx
000079f4d2ddc49e  pop rcx
000079f4d2ddc49f  pop rax
000079f4d2ddc4a0  add rsp, 0x08
000079f4d2ddc4a4  jmp 0x000079F4D2DD93E0
000079f4d2ddc4a9  sub rsp, 0x08
000079f4d2ddc4ad  push rax
000079f4d2ddc4ae  push rcx
000079f4d2ddc4af  push rdx
000079f4d2ddc4b0  push rdi
000079f4d2ddc4b1  push rsi
000079f4d2ddc4b2  push r8
000079f4d2ddc4b4  push r9
000079f4d2ddc4b6  push r10
000079f4d2ddc4b8  push r11
000079f4d2ddc4ba  sub rsp, 0xF0
000079f4d2ddc4c1  vmovaps [rsp], xmm0
000079f4d2ddc4c6  vmovaps [rsp+0x10], xmm1
000079f4d2ddc4cc  vmovaps [rsp+0x20], xmm2
000079f4d2ddc4d2  vmovaps [rsp+0x30], xmm3
000079f4d2ddc4d8  vmovaps [rsp+0x40], xmm4
000079f4d2ddc4de  vmovaps [rsp+0x50], xmm5
000079f4d2ddc4e4  vmovaps [rsp+0x60], xmm7
000079f4d2ddc4ea  vmovaps [rsp+0x70], xmm8
000079f4d2ddc4f0  vmovaps [rsp+0x80], xmm9
000079f4d2ddc4f9  vmovaps [rsp+0x90], xmm10
000079f4d2ddc502  vmovaps [rsp+0xA0], xmm11
000079f4d2ddc50b  vmovaps [rsp+0xB0], xmm12
000079f4d2ddc514  vmovaps [rsp+0xC0], xmm13
000079f4d2ddc51d  vmovaps [rsp+0xD0], xmm14
000079f4d2ddc526  vmovaps [rsp+0xE0], xmm15
000079f4d2ddc52f  sub rsp, 0x30
000079f4d2ddc533  movaps [rsp], xmm6
000079f4d2ddc537  movaps [rsp+0x10], xmm10
000079f4d2ddc53d  movaps [rsp+0x20], xmm8
000079f4d2ddc543  lea rdi, [rsp]
000079f4d2ddc547  mov esi, 0x00
000079f4d2ddc54c  mov rax, 0x5D9EC01E8530
000079f4d2ddc556  call rax
000079f4d2ddc558  movaps xmm6, [rsp]
000079f4d2ddc55c  add rsp, 0x30
000079f4d2ddc560  vmovaps xmm0, [rsp]
000079f4d2ddc565  vmovaps xmm1, [rsp+0x10]
000079f4d2ddc56b  vmovaps xmm2, [rsp+0x20]
000079f4d2ddc571  vmovaps xmm3, [rsp+0x30]
000079f4d2ddc577  vmovaps xmm4, [rsp+0x40]
000079f4d2ddc57d  vmovaps xmm5, [rsp+0x50]
000079f4d2ddc583  vmovaps xmm7, [rsp+0x60]
000079f4d2ddc589  vmovaps xmm8, [rsp+0x70]
000079f4d2ddc58f  vmovaps xmm9, [rsp+0x80]
000079f4d2ddc598  vmovaps xmm10, [rsp+0x90]
000079f4d2ddc5a1  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddc5aa  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddc5b3  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddc5bc  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddc5c5  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddc5ce  add rsp, 0xF0
000079f4d2ddc5d5  pop r11
000079f4d2ddc5d7  pop r10
000079f4d2ddc5d9  pop r9
000079f4d2ddc5db  pop r8
000079f4d2ddc5dd  pop rsi
000079f4d2ddc5de  pop rdi
000079f4d2ddc5df  pop rdx
000079f4d2ddc5e0  pop rcx
000079f4d2ddc5e1  pop rax
000079f4d2ddc5e2  add rsp, 0x08
000079f4d2ddc5e6  jmp 0x000079F4D2DD9405
000079f4d2ddc5eb  sub rsp, 0x08
000079f4d2ddc5ef  push rax
000079f4d2ddc5f0  push rcx
000079f4d2ddc5f1  push rdx
000079f4d2ddc5f2  push rdi
000079f4d2ddc5f3  push rsi
000079f4d2ddc5f4  push r8
000079f4d2ddc5f6  push r9
000079f4d2ddc5f8  push r10
000079f4d2ddc5fa  push r11
000079f4d2ddc5fc  sub rsp, 0xF0
000079f4d2ddc603  vmovaps [rsp], xmm0
000079f4d2ddc608  vmovaps [rsp+0x10], xmm1
000079f4d2ddc60e  vmovaps [rsp+0x20], xmm2
000079f4d2ddc614  vmovaps [rsp+0x30], xmm3
000079f4d2ddc61a  vmovaps [rsp+0x40], xmm4
000079f4d2ddc620  vmovaps [rsp+0x50], xmm5
000079f4d2ddc626  vmovaps [rsp+0x60], xmm6
000079f4d2ddc62c  vmovaps [rsp+0x70], xmm7
000079f4d2ddc632  vmovaps [rsp+0x80], xmm8
000079f4d2ddc63b  vmovaps [rsp+0x90], xmm9
000079f4d2ddc644  vmovaps [rsp+0xA0], xmm11
000079f4d2ddc64d  vmovaps [rsp+0xB0], xmm12
000079f4d2ddc656  vmovaps [rsp+0xC0], xmm13
000079f4d2ddc65f  vmovaps [rsp+0xD0], xmm14
000079f4d2ddc668  vmovaps [rsp+0xE0], xmm15
000079f4d2ddc671  sub rsp, 0x30
000079f4d2ddc675  movaps [rsp], xmm10
000079f4d2ddc67a  movaps [rsp+0x10], xmm8
000079f4d2ddc680  movaps [rsp+0x20], xmm14
000079f4d2ddc686  lea rdi, [rsp]
000079f4d2ddc68a  mov esi, 0x00
000079f4d2ddc68f  mov rax, 0x5D9EC01E8530
000079f4d2ddc699  call rax
000079f4d2ddc69b  movaps xmm10, [rsp]
000079f4d2ddc6a0  add rsp, 0x30
000079f4d2ddc6a4  vmovaps xmm0, [rsp]
000079f4d2ddc6a9  vmovaps xmm1, [rsp+0x10]
000079f4d2ddc6af  vmovaps xmm2, [rsp+0x20]
000079f4d2ddc6b5  vmovaps xmm3, [rsp+0x30]
000079f4d2ddc6bb  vmovaps xmm4, [rsp+0x40]
000079f4d2ddc6c1  vmovaps xmm5, [rsp+0x50]
000079f4d2ddc6c7  vmovaps xmm6, [rsp+0x60]
000079f4d2ddc6cd  vmovaps xmm7, [rsp+0x70]
000079f4d2ddc6d3  vmovaps xmm8, [rsp+0x80]
000079f4d2ddc6dc  vmovaps xmm9, [rsp+0x90]
000079f4d2ddc6e5  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddc6ee  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddc6f7  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddc700  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddc709  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddc712  add rsp, 0xF0
000079f4d2ddc719  pop r11
000079f4d2ddc71b  pop r10
000079f4d2ddc71d  pop r9
000079f4d2ddc71f  pop r8
000079f4d2ddc721  pop rsi
000079f4d2ddc722  pop rdi
000079f4d2ddc723  pop rdx
000079f4d2ddc724  pop rcx
000079f4d2ddc725  pop rax
000079f4d2ddc726  add rsp, 0x08
000079f4d2ddc72a  jmp 0x000079F4D2DD9425
000079f4d2ddc72f  sub rsp, 0x08
000079f4d2ddc733  push rax
000079f4d2ddc734  push rcx
000079f4d2ddc735  push rdx
000079f4d2ddc736  push rdi
000079f4d2ddc737  push rsi
000079f4d2ddc738  push r8
000079f4d2ddc73a  push r9
000079f4d2ddc73c  push r10
000079f4d2ddc73e  push r11
000079f4d2ddc740  sub rsp, 0xF0
000079f4d2ddc747  vmovaps [rsp], xmm0
000079f4d2ddc74c  vmovaps [rsp+0x10], xmm1
000079f4d2ddc752  vmovaps [rsp+0x20], xmm2
000079f4d2ddc758  vmovaps [rsp+0x30], xmm3
000079f4d2ddc75e  vmovaps [rsp+0x40], xmm4
000079f4d2ddc764  vmovaps [rsp+0x50], xmm5
000079f4d2ddc76a  vmovaps [rsp+0x60], xmm6
000079f4d2ddc770  vmovaps [rsp+0x70], xmm7
000079f4d2ddc776  vmovaps [rsp+0x80], xmm8
000079f4d2ddc77f  vmovaps [rsp+0x90], xmm9
000079f4d2ddc788  vmovaps [rsp+0xA0], xmm10
000079f4d2ddc791  vmovaps [rsp+0xB0], xmm11
000079f4d2ddc79a  vmovaps [rsp+0xC0], xmm12
000079f4d2ddc7a3  vmovaps [rsp+0xD0], xmm13
000079f4d2ddc7ac  vmovaps [rsp+0xE0], xmm15
000079f4d2ddc7b5  sub rsp, 0x30
000079f4d2ddc7b9  movaps [rsp], xmm14
000079f4d2ddc7be  movaps [rsp+0x10], xmm8
000079f4d2ddc7c4  movaps [rsp+0x20], xmm4
000079f4d2ddc7c9  lea rdi, [rsp]
000079f4d2ddc7cd  mov esi, 0x00
000079f4d2ddc7d2  mov rax, 0x5D9EC01E8530
000079f4d2ddc7dc  call rax
000079f4d2ddc7de  movaps xmm14, [rsp]
000079f4d2ddc7e3  add rsp, 0x30
000079f4d2ddc7e7  vmovaps xmm0, [rsp]
000079f4d2ddc7ec  vmovaps xmm1, [rsp+0x10]
000079f4d2ddc7f2  vmovaps xmm2, [rsp+0x20]
000079f4d2ddc7f8  vmovaps xmm3, [rsp+0x30]
000079f4d2ddc7fe  vmovaps xmm4, [rsp+0x40]
000079f4d2ddc804  vmovaps xmm5, [rsp+0x50]
000079f4d2ddc80a  vmovaps xmm6, [rsp+0x60]
000079f4d2ddc810  vmovaps xmm7, [rsp+0x70]
000079f4d2ddc816  vmovaps xmm8, [rsp+0x80]
000079f4d2ddc81f  vmovaps xmm9, [rsp+0x90]
000079f4d2ddc828  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddc831  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddc83a  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddc843  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddc84c  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddc855  add rsp, 0xF0
000079f4d2ddc85c  pop r11
000079f4d2ddc85e  pop r10
000079f4d2ddc860  pop r9
000079f4d2ddc862  pop r8
000079f4d2ddc864  pop rsi
000079f4d2ddc865  pop rdi
000079f4d2ddc866  pop rdx
000079f4d2ddc867  pop rcx
000079f4d2ddc868  pop rax
000079f4d2ddc869  add rsp, 0x08
000079f4d2ddc86d  jmp 0x000079F4D2DD9445
000079f4d2ddc872  sub rsp, 0x08
000079f4d2ddc876  push rax
000079f4d2ddc877  push rcx
000079f4d2ddc878  push rdx
000079f4d2ddc879  push rdi
000079f4d2ddc87a  push rsi
000079f4d2ddc87b  push r8
000079f4d2ddc87d  push r9
000079f4d2ddc87f  push r10
000079f4d2ddc881  push r11
000079f4d2ddc883  sub rsp, 0xF0
000079f4d2ddc88a  vmovaps [rsp], xmm0
000079f4d2ddc88f  vmovaps [rsp+0x10], xmm1
000079f4d2ddc895  vmovaps [rsp+0x20], xmm2
000079f4d2ddc89b  vmovaps [rsp+0x30], xmm3
000079f4d2ddc8a1  vmovaps [rsp+0x40], xmm5
000079f4d2ddc8a7  vmovaps [rsp+0x50], xmm6
000079f4d2ddc8ad  vmovaps [rsp+0x60], xmm7
000079f4d2ddc8b3  vmovaps [rsp+0x70], xmm8
000079f4d2ddc8b9  vmovaps [rsp+0x80], xmm9
000079f4d2ddc8c2  vmovaps [rsp+0x90], xmm10
000079f4d2ddc8cb  vmovaps [rsp+0xA0], xmm11
000079f4d2ddc8d4  vmovaps [rsp+0xB0], xmm12
000079f4d2ddc8dd  vmovaps [rsp+0xC0], xmm13
000079f4d2ddc8e6  vmovaps [rsp+0xD0], xmm14
000079f4d2ddc8ef  vmovaps [rsp+0xE0], xmm15
000079f4d2ddc8f8  sub rsp, 0x30
000079f4d2ddc8fc  movaps [rsp], xmm4
000079f4d2ddc900  movaps [rsp+0x10], xmm13
000079f4d2ddc906  movaps [rsp+0x20], xmm8
000079f4d2ddc90c  lea rdi, [rsp]
000079f4d2ddc910  mov esi, 0x00
000079f4d2ddc915  mov rax, 0x5D9EC01E8530
000079f4d2ddc91f  call rax
000079f4d2ddc921  movaps xmm4, [rsp]
000079f4d2ddc925  add rsp, 0x30
000079f4d2ddc929  vmovaps xmm0, [rsp]
000079f4d2ddc92e  vmovaps xmm1, [rsp+0x10]
000079f4d2ddc934  vmovaps xmm2, [rsp+0x20]
000079f4d2ddc93a  vmovaps xmm3, [rsp+0x30]
000079f4d2ddc940  vmovaps xmm5, [rsp+0x40]
000079f4d2ddc946  vmovaps xmm6, [rsp+0x50]
000079f4d2ddc94c  vmovaps xmm7, [rsp+0x60]
000079f4d2ddc952  vmovaps xmm8, [rsp+0x70]
000079f4d2ddc958  vmovaps xmm9, [rsp+0x80]
000079f4d2ddc961  vmovaps xmm10, [rsp+0x90]
000079f4d2ddc96a  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddc973  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddc97c  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddc985  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddc98e  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddc997  add rsp, 0xF0
000079f4d2ddc99e  pop r11
000079f4d2ddc9a0  pop r10
000079f4d2ddc9a2  pop r9
000079f4d2ddc9a4  pop r8
000079f4d2ddc9a6  pop rsi
000079f4d2ddc9a7  pop rdi
000079f4d2ddc9a8  pop rdx
000079f4d2ddc9a9  pop rcx
000079f4d2ddc9aa  pop rax
000079f4d2ddc9ab  add rsp, 0x08
000079f4d2ddc9af  jmp 0x000079F4D2DD946A
000079f4d2ddc9b4  sub rsp, 0x08
000079f4d2ddc9b8  push rax
000079f4d2ddc9b9  push rcx
000079f4d2ddc9ba  push rdx
000079f4d2ddc9bb  push rdi
000079f4d2ddc9bc  push rsi
000079f4d2ddc9bd  push r8
000079f4d2ddc9bf  push r9
000079f4d2ddc9c1  push r10
000079f4d2ddc9c3  push r11
000079f4d2ddc9c5  sub rsp, 0xF0
000079f4d2ddc9cc  vmovaps [rsp], xmm0
000079f4d2ddc9d1  vmovaps [rsp+0x10], xmm1
000079f4d2ddc9d7  vmovaps [rsp+0x20], xmm2
000079f4d2ddc9dd  vmovaps [rsp+0x30], xmm3
000079f4d2ddc9e3  vmovaps [rsp+0x40], xmm4
000079f4d2ddc9e9  vmovaps [rsp+0x50], xmm5
000079f4d2ddc9ef  vmovaps [rsp+0x60], xmm6
000079f4d2ddc9f5  vmovaps [rsp+0x70], xmm7
000079f4d2ddc9fb  vmovaps [rsp+0x80], xmm8
000079f4d2ddca04  vmovaps [rsp+0x90], xmm9
000079f4d2ddca0d  vmovaps [rsp+0xA0], xmm10
000079f4d2ddca16  vmovaps [rsp+0xB0], xmm11
000079f4d2ddca1f  vmovaps [rsp+0xC0], xmm12
000079f4d2ddca28  vmovaps [rsp+0xD0], xmm14
000079f4d2ddca31  vmovaps [rsp+0xE0], xmm15
000079f4d2ddca3a  sub rsp, 0x30
000079f4d2ddca3e  movaps [rsp], xmm13
000079f4d2ddca43  movaps [rsp+0x10], xmm15
000079f4d2ddca49  movaps [rsp+0x20], xmm9
000079f4d2ddca4f  lea rdi, [rsp]
000079f4d2ddca53  mov esi, 0x00
000079f4d2ddca58  mov rax, 0x5D9EC01E8530
000079f4d2ddca62  call rax
000079f4d2ddca64  movaps xmm13, [rsp]
000079f4d2ddca69  add rsp, 0x30
000079f4d2ddca6d  vmovaps xmm0, [rsp]
000079f4d2ddca72  vmovaps xmm1, [rsp+0x10]
000079f4d2ddca78  vmovaps xmm2, [rsp+0x20]
000079f4d2ddca7e  vmovaps xmm3, [rsp+0x30]
000079f4d2ddca84  vmovaps xmm4, [rsp+0x40]
000079f4d2ddca8a  vmovaps xmm5, [rsp+0x50]
000079f4d2ddca90  vmovaps xmm6, [rsp+0x60]
000079f4d2ddca96  vmovaps xmm7, [rsp+0x70]
000079f4d2ddca9c  vmovaps xmm8, [rsp+0x80]
000079f4d2ddcaa5  vmovaps xmm9, [rsp+0x90]
000079f4d2ddcaae  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddcab7  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddcac0  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddcac9  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddcad2  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddcadb  add rsp, 0xF0
000079f4d2ddcae2  pop r11
000079f4d2ddcae4  pop r10
000079f4d2ddcae6  pop r9
000079f4d2ddcae8  pop r8
000079f4d2ddcaea  pop rsi
000079f4d2ddcaeb  pop rdi
000079f4d2ddcaec  pop rdx
000079f4d2ddcaed  pop rcx
000079f4d2ddcaee  pop rax
000079f4d2ddcaef  add rsp, 0x08
000079f4d2ddcaf3  jmp 0x000079F4D2DD9485
000079f4d2ddcaf8  sub rsp, 0x08
000079f4d2ddcafc  push rax
000079f4d2ddcafd  push rcx
000079f4d2ddcafe  push rdx
000079f4d2ddcaff  push rdi
000079f4d2ddcb00  push rsi
000079f4d2ddcb01  push r8
000079f4d2ddcb03  push r9
000079f4d2ddcb05  push r10
000079f4d2ddcb07  push r11
000079f4d2ddcb09  sub rsp, 0xF0
000079f4d2ddcb10  vmovaps [rsp], xmm0
000079f4d2ddcb15  vmovaps [rsp+0x10], xmm1
000079f4d2ddcb1b  vmovaps [rsp+0x20], xmm2
000079f4d2ddcb21  vmovaps [rsp+0x30], xmm3
000079f4d2ddcb27  vmovaps [rsp+0x40], xmm4
000079f4d2ddcb2d  vmovaps [rsp+0x50], xmm5
000079f4d2ddcb33  vmovaps [rsp+0x60], xmm6
000079f4d2ddcb39  vmovaps [rsp+0x70], xmm7
000079f4d2ddcb3f  vmovaps [rsp+0x80], xmm8
000079f4d2ddcb48  vmovaps [rsp+0x90], xmm9
000079f4d2ddcb51  vmovaps [rsp+0xA0], xmm10
000079f4d2ddcb5a  vmovaps [rsp+0xB0], xmm11
000079f4d2ddcb63  vmovaps [rsp+0xC0], xmm12
000079f4d2ddcb6c  vmovaps [rsp+0xD0], xmm13
000079f4d2ddcb75  vmovaps [rsp+0xE0], xmm14
000079f4d2ddcb7e  sub rsp, 0x30
000079f4d2ddcb82  movaps [rsp], xmm15
000079f4d2ddcb87  movaps [rsp+0x10], xmm1
000079f4d2ddcb8c  movaps [rsp+0x20], xmm5
000079f4d2ddcb91  lea rdi, [rsp]
000079f4d2ddcb95  mov esi, 0x00
000079f4d2ddcb9a  mov rax, 0x5D9EC01E8530
000079f4d2ddcba4  call rax
000079f4d2ddcba6  movaps xmm15, [rsp]
000079f4d2ddcbab  add rsp, 0x30
000079f4d2ddcbaf  vmovaps xmm0, [rsp]
000079f4d2ddcbb4  vmovaps xmm1, [rsp+0x10]
000079f4d2ddcbba  vmovaps xmm2, [rsp+0x20]
000079f4d2ddcbc0  vmovaps xmm3, [rsp+0x30]
000079f4d2ddcbc6  vmovaps xmm4, [rsp+0x40]
000079f4d2ddcbcc  vmovaps xmm5, [rsp+0x50]
000079f4d2ddcbd2  vmovaps xmm6, [rsp+0x60]
000079f4d2ddcbd8  vmovaps xmm7, [rsp+0x70]
000079f4d2ddcbde  vmovaps xmm8, [rsp+0x80]
000079f4d2ddcbe7  vmovaps xmm9, [rsp+0x90]
000079f4d2ddcbf0  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddcbf9  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddcc02  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddcc0b  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddcc14  vmovaps xmm14, [rsp+0xE0]
000079f4d2ddcc1d  add rsp, 0xF0
000079f4d2ddcc24  pop r11
000079f4d2ddcc26  pop r10
000079f4d2ddcc28  pop r9
000079f4d2ddcc2a  pop r8
000079f4d2ddcc2c  pop rsi
000079f4d2ddcc2d  pop rdi
000079f4d2ddcc2e  pop rdx
000079f4d2ddcc2f  pop rcx
000079f4d2ddcc30  pop rax
000079f4d2ddcc31  add rsp, 0x08
000079f4d2ddcc35  jmp 0x000079F4D2DD94A0
000079f4d2ddcc3a  call 0x000079F4D2CD64F0
000079f4d2ddcc3f  jmp 0x000079F4D2DD94FB
000079f4d2ddcc44  sub rsp, 0x08
000079f4d2ddcc48  push rax
000079f4d2ddcc49  push rcx
000079f4d2ddcc4a  push rdx
000079f4d2ddcc4b  push rdi
000079f4d2ddcc4c  push rsi
000079f4d2ddcc4d  push r8
000079f4d2ddcc4f  push r9
000079f4d2ddcc51  push r10
000079f4d2ddcc53  push r11
000079f4d2ddcc55  sub rsp, 0xF0
000079f4d2ddcc5c  vmovaps [rsp], xmm0
000079f4d2ddcc61  vmovaps [rsp+0x10], xmm1
000079f4d2ddcc67  vmovaps [rsp+0x20], xmm2
000079f4d2ddcc6d  vmovaps [rsp+0x30], xmm3
000079f4d2ddcc73  vmovaps [rsp+0x40], xmm4
000079f4d2ddcc79  vmovaps [rsp+0x50], xmm5
000079f4d2ddcc7f  vmovaps [rsp+0x60], xmm6
000079f4d2ddcc85  vmovaps [rsp+0x70], xmm7
000079f4d2ddcc8b  vmovaps [rsp+0x80], xmm8
000079f4d2ddcc94  vmovaps [rsp+0x90], xmm10
000079f4d2ddcc9d  vmovaps [rsp+0xA0], xmm11
000079f4d2ddcca6  vmovaps [rsp+0xB0], xmm12
000079f4d2ddccaf  vmovaps [rsp+0xC0], xmm13
000079f4d2ddccb8  vmovaps [rsp+0xD0], xmm14
000079f4d2ddccc1  vmovaps [rsp+0xE0], xmm15
000079f4d2ddccca  sub rsp, 0x30
000079f4d2ddccce  movaps [rsp], xmm9
000079f4d2ddccd3  movaps [rsp+0x10], xmm8
000079f4d2ddccd9  movaps [rsp+0x20], xmm11
000079f4d2ddccdf  lea rdi, [rsp]
000079f4d2ddcce3  mov esi, 0x00
000079f4d2ddcce8  mov rax, 0x5D9EC01E8530
000079f4d2ddccf2  call rax
000079f4d2ddccf4  movaps xmm9, [rsp]
000079f4d2ddccf9  add rsp, 0x30
000079f4d2ddccfd  vmovaps xmm0, [rsp]
000079f4d2ddcd02  vmovaps xmm1, [rsp+0x10]
000079f4d2ddcd08  vmovaps xmm2, [rsp+0x20]
000079f4d2ddcd0e  vmovaps xmm3, [rsp+0x30]
000079f4d2ddcd14  vmovaps xmm4, [rsp+0x40]
000079f4d2ddcd1a  vmovaps xmm5, [rsp+0x50]
000079f4d2ddcd20  vmovaps xmm6, [rsp+0x60]
000079f4d2ddcd26  vmovaps xmm7, [rsp+0x70]
000079f4d2ddcd2c  vmovaps xmm8, [rsp+0x80]
000079f4d2ddcd35  vmovaps xmm10, [rsp+0x90]
000079f4d2ddcd3e  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddcd47  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddcd50  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddcd59  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddcd62  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddcd6b  add rsp, 0xF0
000079f4d2ddcd72  pop r11
000079f4d2ddcd74  pop r10
000079f4d2ddcd76  pop r9
000079f4d2ddcd78  pop r8
000079f4d2ddcd7a  pop rsi
000079f4d2ddcd7b  pop rdi
000079f4d2ddcd7c  pop rdx
000079f4d2ddcd7d  pop rcx
000079f4d2ddcd7e  pop rax
000079f4d2ddcd7f  add rsp, 0x08
000079f4d2ddcd83  jmp 0x000079F4D2DD9532
000079f4d2ddcd88  sub rsp, 0x08
000079f4d2ddcd8c  push rax
000079f4d2ddcd8d  push rcx
000079f4d2ddcd8e  push rdx
000079f4d2ddcd8f  push rdi
000079f4d2ddcd90  push rsi
000079f4d2ddcd91  push r8
000079f4d2ddcd93  push r9
000079f4d2ddcd95  push r10
000079f4d2ddcd97  push r11
000079f4d2ddcd99  sub rsp, 0xF0
000079f4d2ddcda0  vmovaps [rsp], xmm0
000079f4d2ddcda5  vmovaps [rsp+0x10], xmm1
000079f4d2ddcdab  vmovaps [rsp+0x20], xmm2
000079f4d2ddcdb1  vmovaps [rsp+0x30], xmm3
000079f4d2ddcdb7  vmovaps [rsp+0x40], xmm4
000079f4d2ddcdbd  vmovaps [rsp+0x50], xmm5
000079f4d2ddcdc3  vmovaps [rsp+0x60], xmm6
000079f4d2ddcdc9  vmovaps [rsp+0x70], xmm7
000079f4d2ddcdcf  vmovaps [rsp+0x80], xmm8
000079f4d2ddcdd8  vmovaps [rsp+0x90], xmm9
000079f4d2ddcde1  vmovaps [rsp+0xA0], xmm10
000079f4d2ddcdea  vmovaps [rsp+0xB0], xmm12
000079f4d2ddcdf3  vmovaps [rsp+0xC0], xmm13
000079f4d2ddcdfc  vmovaps [rsp+0xD0], xmm14
000079f4d2ddce05  vmovaps [rsp+0xE0], xmm15
000079f4d2ddce0e  sub rsp, 0x30
000079f4d2ddce12  movaps [rsp], xmm11
000079f4d2ddce17  movaps [rsp+0x10], xmm10
000079f4d2ddce1d  movaps [rsp+0x20], xmm6
000079f4d2ddce22  lea rdi, [rsp]
000079f4d2ddce26  mov esi, 0x00
000079f4d2ddce2b  mov rax, 0x5D9EC01E8530
000079f4d2ddce35  call rax
000079f4d2ddce37  movaps xmm11, [rsp]
000079f4d2ddce3c  add rsp, 0x30
000079f4d2ddce40  vmovaps xmm0, [rsp]
000079f4d2ddce45  vmovaps xmm1, [rsp+0x10]
000079f4d2ddce4b  vmovaps xmm2, [rsp+0x20]
000079f4d2ddce51  vmovaps xmm3, [rsp+0x30]
000079f4d2ddce57  vmovaps xmm4, [rsp+0x40]
000079f4d2ddce5d  vmovaps xmm5, [rsp+0x50]
000079f4d2ddce63  vmovaps xmm6, [rsp+0x60]
000079f4d2ddce69  vmovaps xmm7, [rsp+0x70]
000079f4d2ddce6f  vmovaps xmm8, [rsp+0x80]
000079f4d2ddce78  vmovaps xmm9, [rsp+0x90]
000079f4d2ddce81  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddce8a  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddce93  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddce9c  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddcea5  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddceae  add rsp, 0xF0
000079f4d2ddceb5  pop r11
000079f4d2ddceb7  pop r10
000079f4d2ddceb9  pop r9
000079f4d2ddcebb  pop r8
000079f4d2ddcebd  pop rsi
000079f4d2ddcebe  pop rdi
000079f4d2ddcebf  pop rdx
000079f4d2ddcec0  pop rcx
000079f4d2ddcec1  pop rax
000079f4d2ddcec2  add rsp, 0x08
000079f4d2ddcec6  jmp 0x000079F4D2DD954D
000079f4d2ddcecb  sub rsp, 0x08
000079f4d2ddcecf  push rax
000079f4d2ddced0  push rcx
000079f4d2ddced1  push rdx
000079f4d2ddced2  push rdi
000079f4d2ddced3  push rsi
000079f4d2ddced4  push r8
000079f4d2ddced6  push r9
000079f4d2ddced8  push r10
000079f4d2ddceda  push r11
000079f4d2ddcedc  sub rsp, 0xF0
000079f4d2ddcee3  vmovaps [rsp], xmm0
000079f4d2ddcee8  vmovaps [rsp+0x10], xmm1
000079f4d2ddceee  vmovaps [rsp+0x20], xmm2
000079f4d2ddcef4  vmovaps [rsp+0x30], xmm3
000079f4d2ddcefa  vmovaps [rsp+0x40], xmm4
000079f4d2ddcf00  vmovaps [rsp+0x50], xmm5
000079f4d2ddcf06  vmovaps [rsp+0x60], xmm6
000079f4d2ddcf0c  vmovaps [rsp+0x70], xmm7
000079f4d2ddcf12  vmovaps [rsp+0x80], xmm8
000079f4d2ddcf1b  vmovaps [rsp+0x90], xmm9
000079f4d2ddcf24  vmovaps [rsp+0xA0], xmm11
000079f4d2ddcf2d  vmovaps [rsp+0xB0], xmm12
000079f4d2ddcf36  vmovaps [rsp+0xC0], xmm13
000079f4d2ddcf3f  vmovaps [rsp+0xD0], xmm14
000079f4d2ddcf48  vmovaps [rsp+0xE0], xmm15
000079f4d2ddcf51  sub rsp, 0x30
000079f4d2ddcf55  movaps [rsp], xmm10
000079f4d2ddcf5a  movaps [rsp+0x10], xmm14
000079f4d2ddcf60  movaps [rsp+0x20], xmm4
000079f4d2ddcf65  lea rdi, [rsp]
000079f4d2ddcf69  mov esi, 0x00
000079f4d2ddcf6e  mov rax, 0x5D9EC01E8530
000079f4d2ddcf78  call rax
000079f4d2ddcf7a  movaps xmm10, [rsp]
000079f4d2ddcf7f  add rsp, 0x30
000079f4d2ddcf83  vmovaps xmm0, [rsp]
000079f4d2ddcf88  vmovaps xmm1, [rsp+0x10]
000079f4d2ddcf8e  vmovaps xmm2, [rsp+0x20]
000079f4d2ddcf94  vmovaps xmm3, [rsp+0x30]
000079f4d2ddcf9a  vmovaps xmm4, [rsp+0x40]
000079f4d2ddcfa0  vmovaps xmm5, [rsp+0x50]
000079f4d2ddcfa6  vmovaps xmm6, [rsp+0x60]
000079f4d2ddcfac  vmovaps xmm7, [rsp+0x70]
000079f4d2ddcfb2  vmovaps xmm8, [rsp+0x80]
000079f4d2ddcfbb  vmovaps xmm9, [rsp+0x90]
000079f4d2ddcfc4  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddcfcd  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddcfd6  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddcfdf  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddcfe8  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddcff1  add rsp, 0xF0
000079f4d2ddcff8  pop r11
000079f4d2ddcffa  pop r10
000079f4d2ddcffc  pop r9
000079f4d2ddcffe  pop r8
000079f4d2ddd000  pop rsi
000079f4d2ddd001  pop rdi
000079f4d2ddd002  pop rdx
000079f4d2ddd003  pop rcx
000079f4d2ddd004  pop rax
000079f4d2ddd005  add rsp, 0x08
000079f4d2ddd009  jmp 0x000079F4D2DD9568
000079f4d2ddd00e  sub rsp, 0x08
000079f4d2ddd012  push rax
000079f4d2ddd013  push rcx
000079f4d2ddd014  push rdx
000079f4d2ddd015  push rdi
000079f4d2ddd016  push rsi
000079f4d2ddd017  push r8
000079f4d2ddd019  push r9
000079f4d2ddd01b  push r10
000079f4d2ddd01d  push r11
000079f4d2ddd01f  sub rsp, 0xF0
000079f4d2ddd026  vmovaps [rsp], xmm0
000079f4d2ddd02b  vmovaps [rsp+0x10], xmm1
000079f4d2ddd031  vmovaps [rsp+0x20], xmm2
000079f4d2ddd037  vmovaps [rsp+0x30], xmm3
000079f4d2ddd03d  vmovaps [rsp+0x40], xmm4
000079f4d2ddd043  vmovaps [rsp+0x50], xmm5
000079f4d2ddd049  vmovaps [rsp+0x60], xmm6
000079f4d2ddd04f  vmovaps [rsp+0x70], xmm7
000079f4d2ddd055  vmovaps [rsp+0x80], xmm9
000079f4d2ddd05e  vmovaps [rsp+0x90], xmm10
000079f4d2ddd067  vmovaps [rsp+0xA0], xmm11
000079f4d2ddd070  vmovaps [rsp+0xB0], xmm12
000079f4d2ddd079  vmovaps [rsp+0xC0], xmm13
000079f4d2ddd082  vmovaps [rsp+0xD0], xmm14
000079f4d2ddd08b  vmovaps [rsp+0xE0], xmm15
000079f4d2ddd094  sub rsp, 0x30
000079f4d2ddd098  movaps [rsp], xmm8
000079f4d2ddd09d  movaps [rsp+0x10], xmm1
000079f4d2ddd0a2  movaps [rsp+0x20], xmm14
000079f4d2ddd0a8  lea rdi, [rsp]
000079f4d2ddd0ac  mov esi, 0x00
000079f4d2ddd0b1  mov rax, 0x5D9EC01E8530
000079f4d2ddd0bb  call rax
000079f4d2ddd0bd  movaps xmm8, [rsp]
000079f4d2ddd0c2  add rsp, 0x30
000079f4d2ddd0c6  vmovaps xmm0, [rsp]
000079f4d2ddd0cb  vmovaps xmm1, [rsp+0x10]
000079f4d2ddd0d1  vmovaps xmm2, [rsp+0x20]
000079f4d2ddd0d7  vmovaps xmm3, [rsp+0x30]
000079f4d2ddd0dd  vmovaps xmm4, [rsp+0x40]
000079f4d2ddd0e3  vmovaps xmm5, [rsp+0x50]
000079f4d2ddd0e9  vmovaps xmm6, [rsp+0x60]
000079f4d2ddd0ef  vmovaps xmm7, [rsp+0x70]
000079f4d2ddd0f5  vmovaps xmm9, [rsp+0x80]
000079f4d2ddd0fe  vmovaps xmm10, [rsp+0x90]
000079f4d2ddd107  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddd110  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddd119  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddd122  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddd12b  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddd134  add rsp, 0xF0
000079f4d2ddd13b  pop r11
000079f4d2ddd13d  pop r10
000079f4d2ddd13f  pop r9
000079f4d2ddd141  pop r8
000079f4d2ddd143  pop rsi
000079f4d2ddd144  pop rdi
000079f4d2ddd145  pop rdx
000079f4d2ddd146  pop rcx
000079f4d2ddd147  pop rax
000079f4d2ddd148  add rsp, 0x08
000079f4d2ddd14c  jmp 0x000079F4D2DD958E
000079f4d2ddd151  sub rsp, 0x08
000079f4d2ddd155  push rax
000079f4d2ddd156  push rcx
000079f4d2ddd157  push rdx
000079f4d2ddd158  push rdi
000079f4d2ddd159  push rsi
000079f4d2ddd15a  push r8
000079f4d2ddd15c  push r9
000079f4d2ddd15e  push r10
000079f4d2ddd160  push r11
000079f4d2ddd162  sub rsp, 0xF0
000079f4d2ddd169  vmovaps [rsp], xmm0
000079f4d2ddd16e  vmovaps [rsp+0x10], xmm1
000079f4d2ddd174  vmovaps [rsp+0x20], xmm2
000079f4d2ddd17a  vmovaps [rsp+0x30], xmm3
000079f4d2ddd180  vmovaps [rsp+0x40], xmm4
000079f4d2ddd186  vmovaps [rsp+0x50], xmm5
000079f4d2ddd18c  vmovaps [rsp+0x60], xmm7
000079f4d2ddd192  vmovaps [rsp+0x70], xmm8
000079f4d2ddd198  vmovaps [rsp+0x80], xmm9
000079f4d2ddd1a1  vmovaps [rsp+0x90], xmm10
000079f4d2ddd1aa  vmovaps [rsp+0xA0], xmm11
000079f4d2ddd1b3  vmovaps [rsp+0xB0], xmm12
000079f4d2ddd1bc  vmovaps [rsp+0xC0], xmm13
000079f4d2ddd1c5  vmovaps [rsp+0xD0], xmm14
000079f4d2ddd1ce  vmovaps [rsp+0xE0], xmm15
000079f4d2ddd1d7  sub rsp, 0x30
000079f4d2ddd1db  movaps [rsp], xmm6
000079f4d2ddd1df  movaps [rsp+0x10], xmm1
000079f4d2ddd1e4  movaps [rsp+0x20], xmm14
000079f4d2ddd1ea  lea rdi, [rsp]
000079f4d2ddd1ee  mov esi, 0x00
000079f4d2ddd1f3  mov rax, 0x5D9EC01E8530
000079f4d2ddd1fd  call rax
000079f4d2ddd1ff  movaps xmm6, [rsp]
000079f4d2ddd203  add rsp, 0x30
000079f4d2ddd207  vmovaps xmm0, [rsp]
000079f4d2ddd20c  vmovaps xmm1, [rsp+0x10]
000079f4d2ddd212  vmovaps xmm2, [rsp+0x20]
000079f4d2ddd218  vmovaps xmm3, [rsp+0x30]
000079f4d2ddd21e  vmovaps xmm4, [rsp+0x40]
000079f4d2ddd224  vmovaps xmm5, [rsp+0x50]
000079f4d2ddd22a  vmovaps xmm7, [rsp+0x60]
000079f4d2ddd230  vmovaps xmm8, [rsp+0x70]
000079f4d2ddd236  vmovaps xmm9, [rsp+0x80]
000079f4d2ddd23f  vmovaps xmm10, [rsp+0x90]
000079f4d2ddd248  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddd251  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddd25a  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddd263  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddd26c  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddd275  add rsp, 0xF0
000079f4d2ddd27c  pop r11
000079f4d2ddd27e  pop r10
000079f4d2ddd280  pop r9
000079f4d2ddd282  pop r8
000079f4d2ddd284  pop rsi
000079f4d2ddd285  pop rdi
000079f4d2ddd286  pop rdx
000079f4d2ddd287  pop rcx
000079f4d2ddd288  pop rax
000079f4d2ddd289  add rsp, 0x08
000079f4d2ddd28d  jmp 0x000079F4D2DD95BA
000079f4d2ddd292  sub rsp, 0x08
000079f4d2ddd296  push rax
000079f4d2ddd297  push rcx
000079f4d2ddd298  push rdx
000079f4d2ddd299  push rdi
000079f4d2ddd29a  push rsi
000079f4d2ddd29b  push r8
000079f4d2ddd29d  push r9
000079f4d2ddd29f  push r10
000079f4d2ddd2a1  push r11
000079f4d2ddd2a3  sub rsp, 0xF0
000079f4d2ddd2aa  vmovaps [rsp], xmm0
000079f4d2ddd2af  vmovaps [rsp+0x10], xmm1
000079f4d2ddd2b5  vmovaps [rsp+0x20], xmm2
000079f4d2ddd2bb  vmovaps [rsp+0x30], xmm3
000079f4d2ddd2c1  vmovaps [rsp+0x40], xmm4
000079f4d2ddd2c7  vmovaps [rsp+0x50], xmm5
000079f4d2ddd2cd  vmovaps [rsp+0x60], xmm6
000079f4d2ddd2d3  vmovaps [rsp+0x70], xmm7
000079f4d2ddd2d9  vmovaps [rsp+0x80], xmm8
000079f4d2ddd2e2  vmovaps [rsp+0x90], xmm9
000079f4d2ddd2eb  vmovaps [rsp+0xA0], xmm10
000079f4d2ddd2f4  vmovaps [rsp+0xB0], xmm11
000079f4d2ddd2fd  vmovaps [rsp+0xC0], xmm12
000079f4d2ddd306  vmovaps [rsp+0xD0], xmm13
000079f4d2ddd30f  vmovaps [rsp+0xE0], xmm15
000079f4d2ddd318  sub rsp, 0x30
000079f4d2ddd31c  movaps [rsp], xmm14
000079f4d2ddd321  movaps [rsp+0x10], xmm12
000079f4d2ddd327  movaps [rsp+0x20], xmm1
000079f4d2ddd32c  lea rdi, [rsp]
000079f4d2ddd330  mov esi, 0x00
000079f4d2ddd335  mov rax, 0x5D9EC01E8530
000079f4d2ddd33f  call rax
000079f4d2ddd341  movaps xmm14, [rsp]
000079f4d2ddd346  add rsp, 0x30
000079f4d2ddd34a  vmovaps xmm0, [rsp]
000079f4d2ddd34f  vmovaps xmm1, [rsp+0x10]
000079f4d2ddd355  vmovaps xmm2, [rsp+0x20]
000079f4d2ddd35b  vmovaps xmm3, [rsp+0x30]
000079f4d2ddd361  vmovaps xmm4, [rsp+0x40]
000079f4d2ddd367  vmovaps xmm5, [rsp+0x50]
000079f4d2ddd36d  vmovaps xmm6, [rsp+0x60]
000079f4d2ddd373  vmovaps xmm7, [rsp+0x70]
000079f4d2ddd379  vmovaps xmm8, [rsp+0x80]
000079f4d2ddd382  vmovaps xmm9, [rsp+0x90]
000079f4d2ddd38b  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddd394  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddd39d  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddd3a6  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddd3af  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddd3b8  add rsp, 0xF0
000079f4d2ddd3bf  pop r11
000079f4d2ddd3c1  pop r10
000079f4d2ddd3c3  pop r9
000079f4d2ddd3c5  pop r8
000079f4d2ddd3c7  pop rsi
000079f4d2ddd3c8  pop rdi
000079f4d2ddd3c9  pop rdx
000079f4d2ddd3ca  pop rcx
000079f4d2ddd3cb  pop rax
000079f4d2ddd3cc  add rsp, 0x08
000079f4d2ddd3d0  jmp 0x000079F4D2DD95E0
000079f4d2ddd3d5  sub rsp, 0x08
000079f4d2ddd3d9  push rax
000079f4d2ddd3da  push rcx
000079f4d2ddd3db  push rdx
000079f4d2ddd3dc  push rdi
000079f4d2ddd3dd  push rsi
000079f4d2ddd3de  push r8
000079f4d2ddd3e0  push r9
000079f4d2ddd3e2  push r10
000079f4d2ddd3e4  push r11
000079f4d2ddd3e6  sub rsp, 0xF0
000079f4d2ddd3ed  vmovaps [rsp], xmm0
000079f4d2ddd3f2  vmovaps [rsp+0x10], xmm2
000079f4d2ddd3f8  vmovaps [rsp+0x20], xmm3
000079f4d2ddd3fe  vmovaps [rsp+0x30], xmm4
000079f4d2ddd404  vmovaps [rsp+0x40], xmm5
000079f4d2ddd40a  vmovaps [rsp+0x50], xmm6
000079f4d2ddd410  vmovaps [rsp+0x60], xmm7
000079f4d2ddd416  vmovaps [rsp+0x70], xmm8
000079f4d2ddd41c  vmovaps [rsp+0x80], xmm9
000079f4d2ddd425  vmovaps [rsp+0x90], xmm10
000079f4d2ddd42e  vmovaps [rsp+0xA0], xmm11
000079f4d2ddd437  vmovaps [rsp+0xB0], xmm12
000079f4d2ddd440  vmovaps [rsp+0xC0], xmm13
000079f4d2ddd449  vmovaps [rsp+0xD0], xmm14
000079f4d2ddd452  vmovaps [rsp+0xE0], xmm15
000079f4d2ddd45b  sub rsp, 0x30
000079f4d2ddd45f  movaps [rsp], xmm1
000079f4d2ddd463  movaps [rsp+0x10], xmm13
000079f4d2ddd469  movaps [rsp+0x20], xmm9
000079f4d2ddd46f  lea rdi, [rsp]
000079f4d2ddd473  mov esi, 0x00
000079f4d2ddd478  mov rax, 0x5D9EC01E8530
000079f4d2ddd482  call rax
000079f4d2ddd484  movaps xmm1, [rsp]
000079f4d2ddd488  add rsp, 0x30
000079f4d2ddd48c  vmovaps xmm0, [rsp]
000079f4d2ddd491  vmovaps xmm2, [rsp+0x10]
000079f4d2ddd497  vmovaps xmm3, [rsp+0x20]
000079f4d2ddd49d  vmovaps xmm4, [rsp+0x30]
000079f4d2ddd4a3  vmovaps xmm5, [rsp+0x40]
000079f4d2ddd4a9  vmovaps xmm6, [rsp+0x50]
000079f4d2ddd4af  vmovaps xmm7, [rsp+0x60]
000079f4d2ddd4b5  vmovaps xmm8, [rsp+0x70]
000079f4d2ddd4bb  vmovaps xmm9, [rsp+0x80]
000079f4d2ddd4c4  vmovaps xmm10, [rsp+0x90]
000079f4d2ddd4cd  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddd4d6  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddd4df  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddd4e8  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddd4f1  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddd4fa  add rsp, 0xF0
000079f4d2ddd501  pop r11
000079f4d2ddd503  pop r10
000079f4d2ddd505  pop r9
000079f4d2ddd507  pop r8
000079f4d2ddd509  pop rsi
000079f4d2ddd50a  pop rdi
000079f4d2ddd50b  pop rdx
000079f4d2ddd50c  pop rcx
000079f4d2ddd50d  pop rax
000079f4d2ddd50e  add rsp, 0x08
000079f4d2ddd512  jmp 0x000079F4D2DD95FA
000079f4d2ddd517  sub rsp, 0x08
000079f4d2ddd51b  push rax
000079f4d2ddd51c  push rcx
000079f4d2ddd51d  push rdx
000079f4d2ddd51e  push rdi
000079f4d2ddd51f  push rsi
000079f4d2ddd520  push r8
000079f4d2ddd522  push r9
000079f4d2ddd524  push r10
000079f4d2ddd526  push r11
000079f4d2ddd528  sub rsp, 0xF0
000079f4d2ddd52f  vmovaps [rsp], xmm0
000079f4d2ddd534  vmovaps [rsp+0x10], xmm1
000079f4d2ddd53a  vmovaps [rsp+0x20], xmm2
000079f4d2ddd540  vmovaps [rsp+0x30], xmm3
000079f4d2ddd546  vmovaps [rsp+0x40], xmm4
000079f4d2ddd54c  vmovaps [rsp+0x50], xmm5
000079f4d2ddd552  vmovaps [rsp+0x60], xmm6
000079f4d2ddd558  vmovaps [rsp+0x70], xmm7
000079f4d2ddd55e  vmovaps [rsp+0x80], xmm8
000079f4d2ddd567  vmovaps [rsp+0x90], xmm9
000079f4d2ddd570  vmovaps [rsp+0xA0], xmm10
000079f4d2ddd579  vmovaps [rsp+0xB0], xmm11
000079f4d2ddd582  vmovaps [rsp+0xC0], xmm13
000079f4d2ddd58b  vmovaps [rsp+0xD0], xmm14
000079f4d2ddd594  vmovaps [rsp+0xE0], xmm15
000079f4d2ddd59d  sub rsp, 0x30
000079f4d2ddd5a1  movaps [rsp], xmm12
000079f4d2ddd5a6  movaps [rsp+0x10], xmm7
000079f4d2ddd5ab  movaps [rsp+0x20], xmm13
000079f4d2ddd5b1  lea rdi, [rsp]
000079f4d2ddd5b5  mov esi, 0x00
000079f4d2ddd5ba  mov rax, 0x5D9EC01E8530
000079f4d2ddd5c4  call rax
000079f4d2ddd5c6  movaps xmm12, [rsp]
000079f4d2ddd5cb  add rsp, 0x30
000079f4d2ddd5cf  vmovaps xmm0, [rsp]
000079f4d2ddd5d4  vmovaps xmm1, [rsp+0x10]
000079f4d2ddd5da  vmovaps xmm2, [rsp+0x20]
000079f4d2ddd5e0  vmovaps xmm3, [rsp+0x30]
000079f4d2ddd5e6  vmovaps xmm4, [rsp+0x40]
000079f4d2ddd5ec  vmovaps xmm5, [rsp+0x50]
000079f4d2ddd5f2  vmovaps xmm6, [rsp+0x60]
000079f4d2ddd5f8  vmovaps xmm7, [rsp+0x70]
000079f4d2ddd5fe  vmovaps xmm8, [rsp+0x80]
000079f4d2ddd607  vmovaps xmm9, [rsp+0x90]
000079f4d2ddd610  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddd619  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddd622  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddd62b  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddd634  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddd63d  add rsp, 0xF0
000079f4d2ddd644  pop r11
000079f4d2ddd646  pop r10
000079f4d2ddd648  pop r9
000079f4d2ddd64a  pop r8
000079f4d2ddd64c  pop rsi
000079f4d2ddd64d  pop rdi
000079f4d2ddd64e  pop rdx
000079f4d2ddd64f  pop rcx
000079f4d2ddd650  pop rax
000079f4d2ddd651  add rsp, 0x08
000079f4d2ddd655  jmp 0x000079F4D2DD9621
000079f4d2ddd65a  sub rsp, 0x08
000079f4d2ddd65e  push rax
000079f4d2ddd65f  push rcx
000079f4d2ddd660  push rdx
000079f4d2ddd661  push rdi
000079f4d2ddd662  push rsi
000079f4d2ddd663  push r8
000079f4d2ddd665  push r9
000079f4d2ddd667  push r10
000079f4d2ddd669  push r11
000079f4d2ddd66b  sub rsp, 0xF0
000079f4d2ddd672  vmovaps [rsp], xmm0
000079f4d2ddd677  vmovaps [rsp+0x10], xmm1
000079f4d2ddd67d  vmovaps [rsp+0x20], xmm2
000079f4d2ddd683  vmovaps [rsp+0x30], xmm3
000079f4d2ddd689  vmovaps [rsp+0x40], xmm4
000079f4d2ddd68f  vmovaps [rsp+0x50], xmm5
000079f4d2ddd695  vmovaps [rsp+0x60], xmm6
000079f4d2ddd69b  vmovaps [rsp+0x70], xmm7
000079f4d2ddd6a1  vmovaps [rsp+0x80], xmm8
000079f4d2ddd6aa  vmovaps [rsp+0x90], xmm9
000079f4d2ddd6b3  vmovaps [rsp+0xA0], xmm10
000079f4d2ddd6bc  vmovaps [rsp+0xB0], xmm11
000079f4d2ddd6c5  vmovaps [rsp+0xC0], xmm12
000079f4d2ddd6ce  vmovaps [rsp+0xD0], xmm14
000079f4d2ddd6d7  vmovaps [rsp+0xE0], xmm15
000079f4d2ddd6e0  sub rsp, 0x30
000079f4d2ddd6e4  movaps [rsp], xmm13
000079f4d2ddd6e9  movaps [rsp+0x10], xmm15
000079f4d2ddd6ef  movaps [rsp+0x20], xmm8
000079f4d2ddd6f5  lea rdi, [rsp]
000079f4d2ddd6f9  mov esi, 0x00
000079f4d2ddd6fe  mov rax, 0x5D9EC01E8530
000079f4d2ddd708  call rax
000079f4d2ddd70a  movaps xmm13, [rsp]
000079f4d2ddd70f  add rsp, 0x30
000079f4d2ddd713  vmovaps xmm0, [rsp]
000079f4d2ddd718  vmovaps xmm1, [rsp+0x10]
000079f4d2ddd71e  vmovaps xmm2, [rsp+0x20]
000079f4d2ddd724  vmovaps xmm3, [rsp+0x30]
000079f4d2ddd72a  vmovaps xmm4, [rsp+0x40]
000079f4d2ddd730  vmovaps xmm5, [rsp+0x50]
000079f4d2ddd736  vmovaps xmm6, [rsp+0x60]
000079f4d2ddd73c  vmovaps xmm7, [rsp+0x70]
000079f4d2ddd742  vmovaps xmm8, [rsp+0x80]
000079f4d2ddd74b  vmovaps xmm9, [rsp+0x90]
000079f4d2ddd754  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddd75d  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddd766  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddd76f  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddd778  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddd781  add rsp, 0xF0
000079f4d2ddd788  pop r11
000079f4d2ddd78a  pop r10
000079f4d2ddd78c  pop r9
000079f4d2ddd78e  pop r8
000079f4d2ddd790  pop rsi
000079f4d2ddd791  pop rdi
000079f4d2ddd792  pop rdx
000079f4d2ddd793  pop rcx
000079f4d2ddd794  pop rax
000079f4d2ddd795  add rsp, 0x08
000079f4d2ddd799  jmp 0x000079F4D2DD963C
000079f4d2ddd79e  sub rsp, 0x08
000079f4d2ddd7a2  push rax
000079f4d2ddd7a3  push rcx
000079f4d2ddd7a4  push rdx
000079f4d2ddd7a5  push rdi
000079f4d2ddd7a6  push rsi
000079f4d2ddd7a7  push r8
000079f4d2ddd7a9  push r9
000079f4d2ddd7ab  push r10
000079f4d2ddd7ad  push r11
000079f4d2ddd7af  sub rsp, 0xF0
000079f4d2ddd7b6  vmovaps [rsp], xmm0
000079f4d2ddd7bb  vmovaps [rsp+0x10], xmm1
000079f4d2ddd7c1  vmovaps [rsp+0x20], xmm2
000079f4d2ddd7c7  vmovaps [rsp+0x30], xmm3
000079f4d2ddd7cd  vmovaps [rsp+0x40], xmm4
000079f4d2ddd7d3  vmovaps [rsp+0x50], xmm5
000079f4d2ddd7d9  vmovaps [rsp+0x60], xmm6
000079f4d2ddd7df  vmovaps [rsp+0x70], xmm7
000079f4d2ddd7e5  vmovaps [rsp+0x80], xmm9
000079f4d2ddd7ee  vmovaps [rsp+0x90], xmm10
000079f4d2ddd7f7  vmovaps [rsp+0xA0], xmm11
000079f4d2ddd800  vmovaps [rsp+0xB0], xmm12
000079f4d2ddd809  vmovaps [rsp+0xC0], xmm13
000079f4d2ddd812  vmovaps [rsp+0xD0], xmm14
000079f4d2ddd81b  vmovaps [rsp+0xE0], xmm15
000079f4d2ddd824  sub rsp, 0x30
000079f4d2ddd828  movaps [rsp], xmm8
000079f4d2ddd82d  movaps [rsp+0x10], xmm15
000079f4d2ddd833  movaps [rsp+0x20], xmm9
000079f4d2ddd839  lea rdi, [rsp]
000079f4d2ddd83d  mov esi, 0x00
000079f4d2ddd842  mov rax, 0x5D9EC01E8530
000079f4d2ddd84c  call rax
000079f4d2ddd84e  movaps xmm8, [rsp]
000079f4d2ddd853  add rsp, 0x30
000079f4d2ddd857  vmovaps xmm0, [rsp]
000079f4d2ddd85c  vmovaps xmm1, [rsp+0x10]
000079f4d2ddd862  vmovaps xmm2, [rsp+0x20]
000079f4d2ddd868  vmovaps xmm3, [rsp+0x30]
000079f4d2ddd86e  vmovaps xmm4, [rsp+0x40]
000079f4d2ddd874  vmovaps xmm5, [rsp+0x50]
000079f4d2ddd87a  vmovaps xmm6, [rsp+0x60]
000079f4d2ddd880  vmovaps xmm7, [rsp+0x70]
000079f4d2ddd886  vmovaps xmm9, [rsp+0x80]
000079f4d2ddd88f  vmovaps xmm10, [rsp+0x90]
000079f4d2ddd898  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddd8a1  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddd8aa  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddd8b3  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddd8bc  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddd8c5  add rsp, 0xF0
000079f4d2ddd8cc  pop r11
000079f4d2ddd8ce  pop r10
000079f4d2ddd8d0  pop r9
000079f4d2ddd8d2  pop r8
000079f4d2ddd8d4  pop rsi
000079f4d2ddd8d5  pop rdi
000079f4d2ddd8d6  pop rdx
000079f4d2ddd8d7  pop rcx
000079f4d2ddd8d8  pop rax
000079f4d2ddd8d9  add rsp, 0x08
000079f4d2ddd8dd  jmp 0x000079F4D2DD966A
000079f4d2ddd8e2  sub rsp, 0x08
000079f4d2ddd8e6  push rax
000079f4d2ddd8e7  push rcx
000079f4d2ddd8e8  push rdx
000079f4d2ddd8e9  push rdi
000079f4d2ddd8ea  push rsi
000079f4d2ddd8eb  push r8
000079f4d2ddd8ed  push r9
000079f4d2ddd8ef  push r10
000079f4d2ddd8f1  push r11
000079f4d2ddd8f3  sub rsp, 0xF0
000079f4d2ddd8fa  vmovaps [rsp], xmm0
000079f4d2ddd8ff  vmovaps [rsp+0x10], xmm1
000079f4d2ddd905  vmovaps [rsp+0x20], xmm2
000079f4d2ddd90b  vmovaps [rsp+0x30], xmm3
000079f4d2ddd911  vmovaps [rsp+0x40], xmm4
000079f4d2ddd917  vmovaps [rsp+0x50], xmm5
000079f4d2ddd91d  vmovaps [rsp+0x60], xmm6
000079f4d2ddd923  vmovaps [rsp+0x70], xmm7
000079f4d2ddd929  vmovaps [rsp+0x80], xmm8
000079f4d2ddd932  vmovaps [rsp+0x90], xmm9
000079f4d2ddd93b  vmovaps [rsp+0xA0], xmm10
000079f4d2ddd944  vmovaps [rsp+0xB0], xmm11
000079f4d2ddd94d  vmovaps [rsp+0xC0], xmm12
000079f4d2ddd956  vmovaps [rsp+0xD0], xmm13
000079f4d2ddd95f  vmovaps [rsp+0xE0], xmm14
000079f4d2ddd968  sub rsp, 0x30
000079f4d2ddd96c  movaps [rsp], xmm15
000079f4d2ddd971  movaps [rsp+0x10], xmm11
000079f4d2ddd977  movaps [rsp+0x20], xmm6
000079f4d2ddd97c  lea rdi, [rsp]
000079f4d2ddd980  mov esi, 0x00
000079f4d2ddd985  mov rax, 0x5D9EC01E8530
000079f4d2ddd98f  call rax
000079f4d2ddd991  movaps xmm15, [rsp]
000079f4d2ddd996  add rsp, 0x30
000079f4d2ddd99a  vmovaps xmm0, [rsp]
000079f4d2ddd99f  vmovaps xmm1, [rsp+0x10]
000079f4d2ddd9a5  vmovaps xmm2, [rsp+0x20]
000079f4d2ddd9ab  vmovaps xmm3, [rsp+0x30]
000079f4d2ddd9b1  vmovaps xmm4, [rsp+0x40]
000079f4d2ddd9b7  vmovaps xmm5, [rsp+0x50]
000079f4d2ddd9bd  vmovaps xmm6, [rsp+0x60]
000079f4d2ddd9c3  vmovaps xmm7, [rsp+0x70]
000079f4d2ddd9c9  vmovaps xmm8, [rsp+0x80]
000079f4d2ddd9d2  vmovaps xmm9, [rsp+0x90]
000079f4d2ddd9db  vmovaps xmm10, [rsp+0xA0]
000079f4d2ddd9e4  vmovaps xmm11, [rsp+0xB0]
000079f4d2ddd9ed  vmovaps xmm12, [rsp+0xC0]
000079f4d2ddd9f6  vmovaps xmm13, [rsp+0xD0]
000079f4d2ddd9ff  vmovaps xmm14, [rsp+0xE0]
000079f4d2ddda08  add rsp, 0xF0
000079f4d2ddda0f  pop r11
000079f4d2ddda11  pop r10
000079f4d2ddda13  pop r9
000079f4d2ddda15  pop r8
000079f4d2ddda17  pop rsi
000079f4d2ddda18  pop rdi
000079f4d2ddda19  pop rdx
000079f4d2ddda1a  pop rcx
000079f4d2ddda1b  pop rax
000079f4d2ddda1c  add rsp, 0x08
000079f4d2ddda20  jmp 0x000079F4D2DD9685
000079f4d2ddda25  sub rsp, 0x08
000079f4d2ddda29  push rax
000079f4d2ddda2a  push rcx
000079f4d2ddda2b  push rdx
000079f4d2ddda2c  push rdi
000079f4d2ddda2d  push rsi
000079f4d2ddda2e  push r8
000079f4d2ddda30  push r9
000079f4d2ddda32  push r10
000079f4d2ddda34  push r11
000079f4d2ddda36  sub rsp, 0xF0
000079f4d2ddda3d  vmovaps [rsp], xmm0
000079f4d2ddda42  vmovaps [rsp+0x10], xmm1
000079f4d2ddda48  vmovaps [rsp+0x20], xmm2
000079f4d2ddda4e  vmovaps [rsp+0x30], xmm3
000079f4d2ddda54  vmovaps [rsp+0x40], xmm4
000079f4d2ddda5a  vmovaps [rsp+0x50], xmm5
000079f4d2ddda60  vmovaps [rsp+0x60], xmm6
000079f4d2ddda66  vmovaps [rsp+0x70], xmm8
000079f4d2ddda6c  vmovaps [rsp+0x80], xmm9
000079f4d2ddda75  vmovaps [rsp+0x90], xmm10
000079f4d2ddda7e  vmovaps [rsp+0xA0], xmm11
000079f4d2ddda87  vmovaps [rsp+0xB0], xmm12
000079f4d2ddda90  vmovaps [rsp+0xC0], xmm13
000079f4d2ddda99  vmovaps [rsp+0xD0], xmm14
000079f4d2dddaa2  vmovaps [rsp+0xE0], xmm15
000079f4d2dddaab  sub rsp, 0x30
000079f4d2dddaaf  movaps [rsp], xmm7
000079f4d2dddab3  movaps [rsp+0x10], xmm11
000079f4d2dddab9  movaps [rsp+0x20], xmm9
000079f4d2dddabf  lea rdi, [rsp]
000079f4d2dddac3  mov esi, 0x00
000079f4d2dddac8  mov rax, 0x5D9EC01E8530
000079f4d2dddad2  call rax
000079f4d2dddad4  movaps xmm7, [rsp]
000079f4d2dddad8  add rsp, 0x30
000079f4d2dddadc  vmovaps xmm0, [rsp]
000079f4d2dddae1  vmovaps xmm1, [rsp+0x10]
000079f4d2dddae7  vmovaps xmm2, [rsp+0x20]
000079f4d2dddaed  vmovaps xmm3, [rsp+0x30]
000079f4d2dddaf3  vmovaps xmm4, [rsp+0x40]
000079f4d2dddaf9  vmovaps xmm5, [rsp+0x50]
000079f4d2dddaff  vmovaps xmm6, [rsp+0x60]
000079f4d2dddb05  vmovaps xmm8, [rsp+0x70]
000079f4d2dddb0b  vmovaps xmm9, [rsp+0x80]
000079f4d2dddb14  vmovaps xmm10, [rsp+0x90]
000079f4d2dddb1d  vmovaps xmm11, [rsp+0xA0]
000079f4d2dddb26  vmovaps xmm12, [rsp+0xB0]
000079f4d2dddb2f  vmovaps xmm13, [rsp+0xC0]
000079f4d2dddb38  vmovaps xmm14, [rsp+0xD0]
000079f4d2dddb41  vmovaps xmm15, [rsp+0xE0]
000079f4d2dddb4a  add rsp, 0xF0
000079f4d2dddb51  pop r11
000079f4d2dddb53  pop r10
000079f4d2dddb55  pop r9
000079f4d2dddb57  pop r8
000079f4d2dddb59  pop rsi
000079f4d2dddb5a  pop rdi
000079f4d2dddb5b  pop rdx
000079f4d2dddb5c  pop rcx
000079f4d2dddb5d  pop rax
000079f4d2dddb5e  add rsp, 0x08
000079f4d2dddb62  jmp 0x000079F4D2DD96B2
000079f4d2dddb67  sub rsp, 0x08
000079f4d2dddb6b  push rax
000079f4d2dddb6c  push rcx
000079f4d2dddb6d  push rdx
000079f4d2dddb6e  push rdi
000079f4d2dddb6f  push rsi
000079f4d2dddb70  push r8
000079f4d2dddb72  push r9
000079f4d2dddb74  push r10
000079f4d2dddb76  push r11
000079f4d2dddb78  sub rsp, 0xF0
000079f4d2dddb7f  vmovaps [rsp], xmm0
000079f4d2dddb84  vmovaps [rsp+0x10], xmm1
000079f4d2dddb8a  vmovaps [rsp+0x20], xmm2
000079f4d2dddb90  vmovaps [rsp+0x30], xmm3
000079f4d2dddb96  vmovaps [rsp+0x40], xmm4
000079f4d2dddb9c  vmovaps [rsp+0x50], xmm5
000079f4d2dddba2  vmovaps [rsp+0x60], xmm6
000079f4d2dddba8  vmovaps [rsp+0x70], xmm7
000079f4d2dddbae  vmovaps [rsp+0x80], xmm8
000079f4d2dddbb7  vmovaps [rsp+0x90], xmm9
000079f4d2dddbc0  vmovaps [rsp+0xA0], xmm10
000079f4d2dddbc9  vmovaps [rsp+0xB0], xmm12
000079f4d2dddbd2  vmovaps [rsp+0xC0], xmm13
000079f4d2dddbdb  vmovaps [rsp+0xD0], xmm14
000079f4d2dddbe4  vmovaps [rsp+0xE0], xmm15
000079f4d2dddbed  sub rsp, 0x30
000079f4d2dddbf1  movaps [rsp], xmm11
000079f4d2dddbf6  movaps [rsp+0x10], xmm10
000079f4d2dddbfc  movaps [rsp+0x20], xmm14
000079f4d2dddc02  lea rdi, [rsp]
000079f4d2dddc06  mov esi, 0x00
000079f4d2dddc0b  mov rax, 0x5D9EC01E8530
000079f4d2dddc15  call rax
000079f4d2dddc17  movaps xmm11, [rsp]
000079f4d2dddc1c  add rsp, 0x30
000079f4d2dddc20  vmovaps xmm0, [rsp]
000079f4d2dddc25  vmovaps xmm1, [rsp+0x10]
000079f4d2dddc2b  vmovaps xmm2, [rsp+0x20]
000079f4d2dddc31  vmovaps xmm3, [rsp+0x30]
000079f4d2dddc37  vmovaps xmm4, [rsp+0x40]
000079f4d2dddc3d  vmovaps xmm5, [rsp+0x50]
000079f4d2dddc43  vmovaps xmm6, [rsp+0x60]
000079f4d2dddc49  vmovaps xmm7, [rsp+0x70]
000079f4d2dddc4f  vmovaps xmm8, [rsp+0x80]
000079f4d2dddc58  vmovaps xmm9, [rsp+0x90]
000079f4d2dddc61  vmovaps xmm10, [rsp+0xA0]
000079f4d2dddc6a  vmovaps xmm12, [rsp+0xB0]
000079f4d2dddc73  vmovaps xmm13, [rsp+0xC0]
000079f4d2dddc7c  vmovaps xmm14, [rsp+0xD0]
000079f4d2dddc85  vmovaps xmm15, [rsp+0xE0]
000079f4d2dddc8e  add rsp, 0xF0
000079f4d2dddc95  pop r11
000079f4d2dddc97  pop r10
000079f4d2dddc99  pop r9
000079f4d2dddc9b  pop r8
000079f4d2dddc9d  pop rsi
000079f4d2dddc9e  pop rdi
000079f4d2dddc9f  pop rdx
000079f4d2dddca0  pop rcx
000079f4d2dddca1  pop rax
000079f4d2dddca2  add rsp, 0x08
000079f4d2dddca6  jmp 0x000079F4D2DD96CD
000079f4d2dddcab  call 0x000079F4D2CE45A0
000079f4d2dddcb0  jmp 0x000079F4D2DD96D7
000079f4d2dddcb5  sub rsp, 0x08
000079f4d2dddcb9  push rax
000079f4d2dddcba  push rcx
000079f4d2dddcbb  push rdx
000079f4d2dddcbc  push rdi
000079f4d2dddcbd  push rsi
000079f4d2dddcbe  push r8
000079f4d2dddcc0  push r9
000079f4d2dddcc2  push r10
000079f4d2dddcc4  push r11
000079f4d2dddcc6  sub rsp, 0xF0
000079f4d2dddccd  vmovaps [rsp], xmm0
000079f4d2dddcd2  vmovaps [rsp+0x10], xmm1
000079f4d2dddcd8  vmovaps [rsp+0x20], xmm2
000079f4d2dddcde  vmovaps [rsp+0x30], xmm3
000079f4d2dddce4  vmovaps [rsp+0x40], xmm4
000079f4d2dddcea  vmovaps [rsp+0x50], xmm5
000079f4d2dddcf0  vmovaps [rsp+0x60], xmm6
000079f4d2dddcf6  vmovaps [rsp+0x70], xmm7
000079f4d2dddcfc  vmovaps [rsp+0x80], xmm8
000079f4d2dddd05  vmovaps [rsp+0x90], xmm9
000079f4d2dddd0e  vmovaps [rsp+0xA0], xmm11
000079f4d2dddd17  vmovaps [rsp+0xB0], xmm12
000079f4d2dddd20  vmovaps [rsp+0xC0], xmm13
000079f4d2dddd29  vmovaps [rsp+0xD0], xmm14
000079f4d2dddd32  vmovaps [rsp+0xE0], xmm15
000079f4d2dddd3b  sub rsp, 0x30
000079f4d2dddd3f  movaps [rsp], xmm10
000079f4d2dddd44  movaps [rsp+0x10], xmm1
000079f4d2dddd49  movaps [rsp+0x20], xmm12
000079f4d2dddd4f  lea rdi, [rsp]
000079f4d2dddd53  mov esi, 0x00
000079f4d2dddd58  mov rax, 0x5D9EC01E8530
000079f4d2dddd62  call rax
000079f4d2dddd64  movaps xmm10, [rsp]
000079f4d2dddd69  add rsp, 0x30
000079f4d2dddd6d  vmovaps xmm0, [rsp]
000079f4d2dddd72  vmovaps xmm1, [rsp+0x10]
000079f4d2dddd78  vmovaps xmm2, [rsp+0x20]
000079f4d2dddd7e  vmovaps xmm3, [rsp+0x30]
000079f4d2dddd84  vmovaps xmm4, [rsp+0x40]
000079f4d2dddd8a  vmovaps xmm5, [rsp+0x50]
000079f4d2dddd90  vmovaps xmm6, [rsp+0x60]
000079f4d2dddd96  vmovaps xmm7, [rsp+0x70]
000079f4d2dddd9c  vmovaps xmm8, [rsp+0x80]
000079f4d2dddda5  vmovaps xmm9, [rsp+0x90]
000079f4d2ddddae  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddddb7  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddddc0  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddddc9  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddddd2  vmovaps xmm15, [rsp+0xE0]
000079f4d2dddddb  add rsp, 0xF0
000079f4d2dddde2  pop r11
000079f4d2dddde4  pop r10
000079f4d2dddde6  pop r9
000079f4d2dddde8  pop r8
000079f4d2ddddea  pop rsi
000079f4d2ddddeb  pop rdi
000079f4d2ddddec  pop rdx
000079f4d2dddded  pop rcx
000079f4d2ddddee  pop rax
000079f4d2ddddef  add rsp, 0x08
000079f4d2ddddf3  jmp 0x000079F4D2DD96FA
000079f4d2ddddf8  sub rsp, 0x08
000079f4d2ddddfc  push rax
000079f4d2ddddfd  push rcx
000079f4d2ddddfe  push rdx
000079f4d2ddddff  push rdi
000079f4d2ddde00  push rsi
000079f4d2ddde01  push r8
000079f4d2ddde03  push r9
000079f4d2ddde05  push r10
000079f4d2ddde07  push r11
000079f4d2ddde09  sub rsp, 0xF0
000079f4d2ddde10  vmovaps [rsp], xmm0
000079f4d2ddde15  vmovaps [rsp+0x10], xmm1
000079f4d2ddde1b  vmovaps [rsp+0x20], xmm2
000079f4d2ddde21  vmovaps [rsp+0x30], xmm3
000079f4d2ddde27  vmovaps [rsp+0x40], xmm4
000079f4d2ddde2d  vmovaps [rsp+0x50], xmm5
000079f4d2ddde33  vmovaps [rsp+0x60], xmm6
000079f4d2ddde39  vmovaps [rsp+0x70], xmm7
000079f4d2ddde3f  vmovaps [rsp+0x80], xmm8
000079f4d2ddde48  vmovaps [rsp+0x90], xmm9
000079f4d2ddde51  vmovaps [rsp+0xA0], xmm10
000079f4d2ddde5a  vmovaps [rsp+0xB0], xmm11
000079f4d2ddde63  vmovaps [rsp+0xC0], xmm13
000079f4d2ddde6c  vmovaps [rsp+0xD0], xmm14
000079f4d2ddde75  vmovaps [rsp+0xE0], xmm15
000079f4d2ddde7e  sub rsp, 0x30
000079f4d2ddde82  movaps [rsp], xmm12
000079f4d2ddde87  movaps [rsp+0x10], xmm14
000079f4d2ddde8d  movaps [rsp+0x20], xmm1
000079f4d2ddde92  lea rdi, [rsp]
000079f4d2ddde96  mov esi, 0x00
000079f4d2ddde9b  mov rax, 0x5D9EC01E8530
000079f4d2dddea5  call rax
000079f4d2dddea7  movaps xmm12, [rsp]
000079f4d2dddeac  add rsp, 0x30
000079f4d2dddeb0  vmovaps xmm0, [rsp]
000079f4d2dddeb5  vmovaps xmm1, [rsp+0x10]
000079f4d2dddebb  vmovaps xmm2, [rsp+0x20]
000079f4d2dddec1  vmovaps xmm3, [rsp+0x30]
000079f4d2dddec7  vmovaps xmm4, [rsp+0x40]
000079f4d2dddecd  vmovaps xmm5, [rsp+0x50]
000079f4d2ddded3  vmovaps xmm6, [rsp+0x60]
000079f4d2ddded9  vmovaps xmm7, [rsp+0x70]
000079f4d2dddedf  vmovaps xmm8, [rsp+0x80]
000079f4d2dddee8  vmovaps xmm9, [rsp+0x90]
000079f4d2dddef1  vmovaps xmm10, [rsp+0xA0]
000079f4d2dddefa  vmovaps xmm11, [rsp+0xB0]
000079f4d2dddf03  vmovaps xmm13, [rsp+0xC0]
000079f4d2dddf0c  vmovaps xmm14, [rsp+0xD0]
000079f4d2dddf15  vmovaps xmm15, [rsp+0xE0]
000079f4d2dddf1e  add rsp, 0xF0
000079f4d2dddf25  pop r11
000079f4d2dddf27  pop r10
000079f4d2dddf29  pop r9
000079f4d2dddf2b  pop r8
000079f4d2dddf2d  pop rsi
000079f4d2dddf2e  pop rdi
000079f4d2dddf2f  pop rdx
000079f4d2dddf30  pop rcx
000079f4d2dddf31  pop rax
000079f4d2dddf32  add rsp, 0x08
000079f4d2dddf36  jmp 0x000079F4D2DD9729
000079f4d2dddf3b  sub rsp, 0x08
000079f4d2dddf3f  push rax
000079f4d2dddf40  push rcx
000079f4d2dddf41  push rdx
000079f4d2dddf42  push rdi
000079f4d2dddf43  push rsi
000079f4d2dddf44  push r8
000079f4d2dddf46  push r9
000079f4d2dddf48  push r10
000079f4d2dddf4a  push r11
000079f4d2dddf4c  sub rsp, 0xF0
000079f4d2dddf53  vmovaps [rsp], xmm0
000079f4d2dddf58  vmovaps [rsp+0x10], xmm1
000079f4d2dddf5e  vmovaps [rsp+0x20], xmm2
000079f4d2dddf64  vmovaps [rsp+0x30], xmm3
000079f4d2dddf6a  vmovaps [rsp+0x40], xmm4
000079f4d2dddf70  vmovaps [rsp+0x50], xmm5
000079f4d2dddf76  vmovaps [rsp+0x60], xmm6
000079f4d2dddf7c  vmovaps [rsp+0x70], xmm7
000079f4d2dddf82  vmovaps [rsp+0x80], xmm8
000079f4d2dddf8b  vmovaps [rsp+0x90], xmm9
000079f4d2dddf94  vmovaps [rsp+0xA0], xmm10
000079f4d2dddf9d  vmovaps [rsp+0xB0], xmm11
000079f4d2dddfa6  vmovaps [rsp+0xC0], xmm12
000079f4d2dddfaf  vmovaps [rsp+0xD0], xmm13
000079f4d2dddfb8  vmovaps [rsp+0xE0], xmm15
000079f4d2dddfc1  sub rsp, 0x30
000079f4d2dddfc5  movaps [rsp], xmm14
000079f4d2dddfca  movaps [rsp+0x10], xmm9
000079f4d2dddfd0  movaps [rsp+0x20], xmm1
000079f4d2dddfd5  lea rdi, [rsp]
000079f4d2dddfd9  mov esi, 0x00
000079f4d2dddfde  mov rax, 0x5D9EC01E8530
000079f4d2dddfe8  call rax
000079f4d2dddfea  movaps xmm14, [rsp]
000079f4d2dddfef  add rsp, 0x30
000079f4d2dddff3  vmovaps xmm0, [rsp]
000079f4d2dddff8  vmovaps xmm1, [rsp+0x10]
000079f4d2dddffe  vmovaps xmm2, [rsp+0x20]
000079f4d2dde004  vmovaps xmm3, [rsp+0x30]
000079f4d2dde00a  vmovaps xmm4, [rsp+0x40]
000079f4d2dde010  vmovaps xmm5, [rsp+0x50]
000079f4d2dde016  vmovaps xmm6, [rsp+0x60]
000079f4d2dde01c  vmovaps xmm7, [rsp+0x70]
000079f4d2dde022  vmovaps xmm8, [rsp+0x80]
000079f4d2dde02b  vmovaps xmm9, [rsp+0x90]
000079f4d2dde034  vmovaps xmm10, [rsp+0xA0]
000079f4d2dde03d  vmovaps xmm11, [rsp+0xB0]
000079f4d2dde046  vmovaps xmm12, [rsp+0xC0]
000079f4d2dde04f  vmovaps xmm13, [rsp+0xD0]
000079f4d2dde058  vmovaps xmm15, [rsp+0xE0]
000079f4d2dde061  add rsp, 0xF0
000079f4d2dde068  pop r11
000079f4d2dde06a  pop r10
000079f4d2dde06c  pop r9
000079f4d2dde06e  pop r8
000079f4d2dde070  pop rsi
000079f4d2dde071  pop rdi
000079f4d2dde072  pop rdx
000079f4d2dde073  pop rcx
000079f4d2dde074  pop rax
000079f4d2dde075  add rsp, 0x08
000079f4d2dde079  jmp 0x000079F4D2DD9758
000079f4d2dde07e  sub rsp, 0x08
000079f4d2dde082  push rax
000079f4d2dde083  push rcx
000079f4d2dde084  push rdx
000079f4d2dde085  push rdi
000079f4d2dde086  push rsi
000079f4d2dde087  push r8
000079f4d2dde089  push r9
000079f4d2dde08b  push r10
000079f4d2dde08d  push r11
000079f4d2dde08f  sub rsp, 0xF0
000079f4d2dde096  vmovaps [rsp], xmm0
000079f4d2dde09b  vmovaps [rsp+0x10], xmm2
000079f4d2dde0a1  vmovaps [rsp+0x20], xmm3
000079f4d2dde0a7  vmovaps [rsp+0x30], xmm4
000079f4d2dde0ad  vmovaps [rsp+0x40], xmm5
000079f4d2dde0b3  vmovaps [rsp+0x50], xmm6
000079f4d2dde0b9  vmovaps [rsp+0x60], xmm7
000079f4d2dde0bf  vmovaps [rsp+0x70], xmm8
000079f4d2dde0c5  vmovaps [rsp+0x80], xmm9
000079f4d2dde0ce  vmovaps [rsp+0x90], xmm10
000079f4d2dde0d7  vmovaps [rsp+0xA0], xmm11
000079f4d2dde0e0  vmovaps [rsp+0xB0], xmm12
000079f4d2dde0e9  vmovaps [rsp+0xC0], xmm13
000079f4d2dde0f2  vmovaps [rsp+0xD0], xmm14
000079f4d2dde0fb  vmovaps [rsp+0xE0], xmm15
000079f4d2dde104  sub rsp, 0x30
000079f4d2dde108  movaps [rsp], xmm1
000079f4d2dde10c  movaps [rsp+0x10], xmm13
000079f4d2dde112  movaps [rsp+0x20], xmm8
000079f4d2dde118  lea rdi, [rsp]
000079f4d2dde11c  mov esi, 0x00
000079f4d2dde121  mov rax, 0x5D9EC01E8530
000079f4d2dde12b  call rax
000079f4d2dde12d  movaps xmm1, [rsp]
000079f4d2dde131  add rsp, 0x30
000079f4d2dde135  vmovaps xmm0, [rsp]
000079f4d2dde13a  vmovaps xmm2, [rsp+0x10]
000079f4d2dde140  vmovaps xmm3, [rsp+0x20]
000079f4d2dde146  vmovaps xmm4, [rsp+0x30]
000079f4d2dde14c  vmovaps xmm5, [rsp+0x40]
000079f4d2dde152  vmovaps xmm6, [rsp+0x50]
000079f4d2dde158  vmovaps xmm7, [rsp+0x60]
000079f4d2dde15e  vmovaps xmm8, [rsp+0x70]
000079f4d2dde164  vmovaps xmm9, [rsp+0x80]
000079f4d2dde16d  vmovaps xmm10, [rsp+0x90]
000079f4d2dde176  vmovaps xmm11, [rsp+0xA0]
000079f4d2dde17f  vmovaps xmm12, [rsp+0xB0]
000079f4d2dde188  vmovaps xmm13, [rsp+0xC0]
000079f4d2dde191  vmovaps xmm14, [rsp+0xD0]
000079f4d2dde19a  vmovaps xmm15, [rsp+0xE0]
000079f4d2dde1a3  add rsp, 0xF0
000079f4d2dde1aa  pop r11
000079f4d2dde1ac  pop r10
000079f4d2dde1ae  pop r9
000079f4d2dde1b0  pop r8
000079f4d2dde1b2  pop rsi
000079f4d2dde1b3  pop rdi
000079f4d2dde1b4  pop rdx
000079f4d2dde1b5  pop rcx
000079f4d2dde1b6  pop rax
000079f4d2dde1b7  add rsp, 0x08
000079f4d2dde1bb  jmp 0x000079F4D2DD977A
000079f4d2dde1c0  call 0x000079F4D2C0C260
000079f4d2dde1c5  jmp 0x000079F4D2DD9788
000079f4d2dde1ca  call 0x000079F4D2CDE950
000079f4d2dde1cf  jmp 0x000079F4D2DD9792
000079f4d2dde1d4  sub rsp, 0x08
000079f4d2dde1d8  push rax
000079f4d2dde1d9  push rcx
000079f4d2dde1da  push rdx
000079f4d2dde1db  push rdi
000079f4d2dde1dc  push rsi
000079f4d2dde1dd  push r8
000079f4d2dde1df  push r9
000079f4d2dde1e1  push r10
000079f4d2dde1e3  push r11
000079f4d2dde1e5  sub rsp, 0xF0
000079f4d2dde1ec  vmovaps [rsp], xmm0
000079f4d2dde1f1  vmovaps [rsp+0x10], xmm1
000079f4d2dde1f7  vmovaps [rsp+0x20], xmm2
000079f4d2dde1fd  vmovaps [rsp+0x30], xmm3
000079f4d2dde203  vmovaps [rsp+0x40], xmm4
000079f4d2dde209  vmovaps [rsp+0x50], xmm5
000079f4d2dde20f  vmovaps [rsp+0x60], xmm6
000079f4d2dde215  vmovaps [rsp+0x70], xmm7
000079f4d2dde21b  vmovaps [rsp+0x80], xmm9
000079f4d2dde224  vmovaps [rsp+0x90], xmm10
000079f4d2dde22d  vmovaps [rsp+0xA0], xmm11
000079f4d2dde236  vmovaps [rsp+0xB0], xmm12
000079f4d2dde23f  vmovaps [rsp+0xC0], xmm13
000079f4d2dde248  vmovaps [rsp+0xD0], xmm14
000079f4d2dde251  vmovaps [rsp+0xE0], xmm15
000079f4d2dde25a  sub rsp, 0x30
000079f4d2dde25e  movaps [rsp], xmm8
000079f4d2dde263  movaps [rsp+0x10], xmm15
000079f4d2dde269  movaps [rsp+0x20], xmm7
000079f4d2dde26e  lea rdi, [rsp]
000079f4d2dde272  mov esi, 0x00
000079f4d2dde277  mov rax, 0x5D9EC01E8530
000079f4d2dde281  call rax
000079f4d2dde283  movaps xmm8, [rsp]
000079f4d2dde288  add rsp, 0x30
000079f4d2dde28c  vmovaps xmm0, [rsp]
000079f4d2dde291  vmovaps xmm1, [rsp+0x10]
000079f4d2dde297  vmovaps xmm2, [rsp+0x20]
000079f4d2dde29d  vmovaps xmm3, [rsp+0x30]
000079f4d2dde2a3  vmovaps xmm4, [rsp+0x40]
000079f4d2dde2a9  vmovaps xmm5, [rsp+0x50]
000079f4d2dde2af  vmovaps xmm6, [rsp+0x60]
000079f4d2dde2b5  vmovaps xmm7, [rsp+0x70]
000079f4d2dde2bb  vmovaps xmm9, [rsp+0x80]
000079f4d2dde2c4  vmovaps xmm10, [rsp+0x90]
000079f4d2dde2cd  vmovaps xmm11, [rsp+0xA0]
000079f4d2dde2d6  vmovaps xmm12, [rsp+0xB0]
000079f4d2dde2df  vmovaps xmm13, [rsp+0xC0]
000079f4d2dde2e8  vmovaps xmm14, [rsp+0xD0]
000079f4d2dde2f1  vmovaps xmm15, [rsp+0xE0]
000079f4d2dde2fa  add rsp, 0xF0
000079f4d2dde301  pop r11
000079f4d2dde303  pop r10
000079f4d2dde305  pop r9
000079f4d2dde307  pop r8
000079f4d2dde309  pop rsi
000079f4d2dde30a  pop rdi
000079f4d2dde30b  pop rdx
000079f4d2dde30c  pop rcx
000079f4d2dde30d  pop rax
000079f4d2dde30e  add rsp, 0x08
000079f4d2dde312  jmp 0x000079F4D2DD97B4
000079f4d2dde317  sub rsp, 0x08
000079f4d2dde31b  push rax
000079f4d2dde31c  push rcx
000079f4d2dde31d  push rdx
000079f4d2dde31e  push rdi
000079f4d2dde31f  push rsi
000079f4d2dde320  push r8
000079f4d2dde322  push r9
000079f4d2dde324  push r10
000079f4d2dde326  push r11
000079f4d2dde328  sub rsp, 0xF0
000079f4d2dde32f  vmovaps [rsp], xmm0
000079f4d2dde334  vmovaps [rsp+0x10], xmm1
000079f4d2dde33a  vmovaps [rsp+0x20], xmm2
000079f4d2dde340  vmovaps [rsp+0x30], xmm3
000079f4d2dde346  vmovaps [rsp+0x40], xmm4
000079f4d2dde34c  vmovaps [rsp+0x50], xmm5
000079f4d2dde352  vmovaps [rsp+0x60], xmm6
000079f4d2dde358  vmovaps [rsp+0x70], xmm8
000079f4d2dde35e  vmovaps [rsp+0x80], xmm9
000079f4d2dde367  vmovaps [rsp+0x90], xmm10
000079f4d2dde370  vmovaps [rsp+0xA0], xmm11
000079f4d2dde379  vmovaps [rsp+0xB0], xmm12
000079f4d2dde382  vmovaps [rsp+0xC0], xmm13
000079f4d2dde38b  vmovaps [rsp+0xD0], xmm14
000079f4d2dde394  vmovaps [rsp+0xE0], xmm15
000079f4d2dde39d  sub rsp, 0x30
000079f4d2dde3a1  movaps [rsp], xmm7
000079f4d2dde3a5  movaps [rsp+0x10], xmm9
000079f4d2dde3ab  movaps [rsp+0x20], xmm15
000079f4d2dde3b1  lea rdi, [rsp]
000079f4d2dde3b5  mov esi, 0x00
000079f4d2dde3ba  mov rax, 0x5D9EC01E8530
000079f4d2dde3c4  call rax
000079f4d2dde3c6  movaps xmm7, [rsp]
000079f4d2dde3ca  add rsp, 0x30
000079f4d2dde3ce  vmovaps xmm0, [rsp]
000079f4d2dde3d3  vmovaps xmm1, [rsp+0x10]
000079f4d2dde3d9  vmovaps xmm2, [rsp+0x20]
000079f4d2dde3df  vmovaps xmm3, [rsp+0x30]
000079f4d2dde3e5  vmovaps xmm4, [rsp+0x40]
000079f4d2dde3eb  vmovaps xmm5, [rsp+0x50]
000079f4d2dde3f1  vmovaps xmm6, [rsp+0x60]
000079f4d2dde3f7  vmovaps xmm8, [rsp+0x70]
000079f4d2dde3fd  vmovaps xmm9, [rsp+0x80]
000079f4d2dde406  vmovaps xmm10, [rsp+0x90]
000079f4d2dde40f  vmovaps xmm11, [rsp+0xA0]
000079f4d2dde418  vmovaps xmm12, [rsp+0xB0]
000079f4d2dde421  vmovaps xmm13, [rsp+0xC0]
000079f4d2dde42a  vmovaps xmm14, [rsp+0xD0]
000079f4d2dde433  vmovaps xmm15, [rsp+0xE0]
000079f4d2dde43c  add rsp, 0xF0
000079f4d2dde443  pop r11
000079f4d2dde445  pop r10
000079f4d2dde447  pop r9
000079f4d2dde449  pop r8
000079f4d2dde44b  pop rsi
000079f4d2dde44c  pop rdi
000079f4d2dde44d  pop rdx
000079f4d2dde44e  pop rcx
000079f4d2dde44f  pop rax
000079f4d2dde450  add rsp, 0x08
000079f4d2dde454  jmp 0x000079F4D2DD97E1
000079f4d2dde459  sub rsp, 0x08
000079f4d2dde45d  push rax
000079f4d2dde45e  push rcx
000079f4d2dde45f  push rdx
000079f4d2dde460  push rdi
000079f4d2dde461  push rsi
000079f4d2dde462  push r8
000079f4d2dde464  push r9
000079f4d2dde466  push r10
000079f4d2dde468  push r11
000079f4d2dde46a  sub rsp, 0xF0
000079f4d2dde471  vmovaps [rsp], xmm0
000079f4d2dde476  vmovaps [rsp+0x10], xmm1
000079f4d2dde47c  vmovaps [rsp+0x20], xmm2
000079f4d2dde482  vmovaps [rsp+0x30], xmm3
000079f4d2dde488  vmovaps [rsp+0x40], xmm4
000079f4d2dde48e  vmovaps [rsp+0x50], xmm5
000079f4d2dde494  vmovaps [rsp+0x60], xmm6
000079f4d2dde49a  vmovaps [rsp+0x70], xmm7
000079f4d2dde4a0  vmovaps [rsp+0x80], xmm8
000079f4d2dde4a9  vmovaps [rsp+0x90], xmm10
000079f4d2dde4b2  vmovaps [rsp+0xA0], xmm11
000079f4d2dde4bb  vmovaps [rsp+0xB0], xmm12
000079f4d2dde4c4  vmovaps [rsp+0xC0], xmm13
000079f4d2dde4cd  vmovaps [rsp+0xD0], xmm14
000079f4d2dde4d6  vmovaps [rsp+0xE0], xmm15
000079f4d2dde4df  sub rsp, 0x30
000079f4d2dde4e3  movaps [rsp], xmm9
000079f4d2dde4e8  movaps [rsp+0x10], xmm13
000079f4d2dde4ee  movaps [rsp+0x20], xmm15
000079f4d2dde4f4  lea rdi, [rsp]
000079f4d2dde4f8  mov esi, 0x00
000079f4d2dde4fd  mov rax, 0x5D9EC01E8530
000079f4d2dde507  call rax
000079f4d2dde509  movaps xmm9, [rsp]
000079f4d2dde50e  add rsp, 0x30
000079f4d2dde512  vmovaps xmm0, [rsp]
000079f4d2dde517  vmovaps xmm1, [rsp+0x10]
000079f4d2dde51d  vmovaps xmm2, [rsp+0x20]
000079f4d2dde523  vmovaps xmm3, [rsp+0x30]
000079f4d2dde529  vmovaps xmm4, [rsp+0x40]
000079f4d2dde52f  vmovaps xmm5, [rsp+0x50]
000079f4d2dde535  vmovaps xmm6, [rsp+0x60]
000079f4d2dde53b  vmovaps xmm7, [rsp+0x70]
000079f4d2dde541  vmovaps xmm8, [rsp+0x80]
000079f4d2dde54a  vmovaps xmm10, [rsp+0x90]
000079f4d2dde553  vmovaps xmm11, [rsp+0xA0]
000079f4d2dde55c  vmovaps xmm12, [rsp+0xB0]
000079f4d2dde565  vmovaps xmm13, [rsp+0xC0]
000079f4d2dde56e  vmovaps xmm14, [rsp+0xD0]
000079f4d2dde577  vmovaps xmm15, [rsp+0xE0]
000079f4d2dde580  add rsp, 0xF0
000079f4d2dde587  pop r11
000079f4d2dde589  pop r10
000079f4d2dde58b  pop r9
000079f4d2dde58d  pop r8
000079f4d2dde58f  pop rsi
000079f4d2dde590  pop rdi
000079f4d2dde591  pop rdx
000079f4d2dde592  pop rcx
000079f4d2dde593  pop rax
000079f4d2dde594  add rsp, 0x08
000079f4d2dde598  jmp 0x000079F4D2DD980F
000079f4d2dde59d  sub rsp, 0x08
000079f4d2dde5a1  push rax
000079f4d2dde5a2  push rcx
000079f4d2dde5a3  push rdx
000079f4d2dde5a4  push rdi
000079f4d2dde5a5  push rsi
000079f4d2dde5a6  push r8
000079f4d2dde5a8  push r9
000079f4d2dde5aa  push r10
000079f4d2dde5ac  push r11
000079f4d2dde5ae  sub rsp, 0xF0
000079f4d2dde5b5  vmovaps [rsp], xmm0
000079f4d2dde5ba  vmovaps [rsp+0x10], xmm1
000079f4d2dde5c0  vmovaps [rsp+0x20], xmm2
000079f4d2dde5c6  vmovaps [rsp+0x30], xmm3
000079f4d2dde5cc  vmovaps [rsp+0x40], xmm4
000079f4d2dde5d2  vmovaps [rsp+0x50], xmm5
000079f4d2dde5d8  vmovaps [rsp+0x60], xmm6
000079f4d2dde5de  vmovaps [rsp+0x70], xmm7
000079f4d2dde5e4  vmovaps [rsp+0x80], xmm8
000079f4d2dde5ed  vmovaps [rsp+0x90], xmm9
000079f4d2dde5f6  vmovaps [rsp+0xA0], xmm10
000079f4d2dde5ff  vmovaps [rsp+0xB0], xmm11
000079f4d2dde608  vmovaps [rsp+0xC0], xmm12
000079f4d2dde611  vmovaps [rsp+0xD0], xmm13
000079f4d2dde61a  vmovaps [rsp+0xE0], xmm14
000079f4d2dde623  sub rsp, 0x30
000079f4d2dde627  movaps [rsp], xmm15
000079f4d2dde62c  movaps [rsp+0x10], xmm11
000079f4d2dde632  movaps [rsp+0x20], xmm12
000079f4d2dde638  lea rdi, [rsp]
000079f4d2dde63c  mov esi, 0x00
000079f4d2dde641  mov rax, 0x5D9EC01E8530
000079f4d2dde64b  call rax
000079f4d2dde64d  movaps xmm15, [rsp]
000079f4d2dde652  add rsp, 0x30
000079f4d2dde656  vmovaps xmm0, [rsp]
000079f4d2dde65b  vmovaps xmm1, [rsp+0x10]
000079f4d2dde661  vmovaps xmm2, [rsp+0x20]
000079f4d2dde667  vmovaps xmm3, [rsp+0x30]
000079f4d2dde66d  vmovaps xmm4, [rsp+0x40]
000079f4d2dde673  vmovaps xmm5, [rsp+0x50]
000079f4d2dde679  vmovaps xmm6, [rsp+0x60]
000079f4d2dde67f  vmovaps xmm7, [rsp+0x70]
000079f4d2dde685  vmovaps xmm8, [rsp+0x80]
000079f4d2dde68e  vmovaps xmm9, [rsp+0x90]
000079f4d2dde697  vmovaps xmm10, [rsp+0xA0]
000079f4d2dde6a0  vmovaps xmm11, [rsp+0xB0]
000079f4d2dde6a9  vmovaps xmm12, [rsp+0xC0]
000079f4d2dde6b2  vmovaps xmm13, [rsp+0xD0]
000079f4d2dde6bb  vmovaps xmm14, [rsp+0xE0]
000079f4d2dde6c4  add rsp, 0xF0
000079f4d2dde6cb  pop r11
000079f4d2dde6cd  pop r10
000079f4d2dde6cf  pop r9
000079f4d2dde6d1  pop r8
000079f4d2dde6d3  pop rsi
000079f4d2dde6d4  pop rdi
000079f4d2dde6d5  pop rdx
000079f4d2dde6d6  pop rcx
000079f4d2dde6d7  pop rax
000079f4d2dde6d8  add rsp, 0x08
000079f4d2dde6dc  jmp 0x000079F4D2DD982A
000079f4d2dde6e1  sub rsp, 0x08
000079f4d2dde6e5  push rax
000079f4d2dde6e6  push rcx
000079f4d2dde6e7  push rdx
000079f4d2dde6e8  push rdi
000079f4d2dde6e9  push rsi
000079f4d2dde6ea  push r8
000079f4d2dde6ec  push r9
000079f4d2dde6ee  push r10
000079f4d2dde6f0  push r11
000079f4d2dde6f2  sub rsp, 0xF0
000079f4d2dde6f9  vmovaps [rsp], xmm0
000079f4d2dde6fe  vmovaps [rsp+0x10], xmm1
000079f4d2dde704  vmovaps [rsp+0x20], xmm2
000079f4d2dde70a  vmovaps [rsp+0x30], xmm3
000079f4d2dde710  vmovaps [rsp+0x40], xmm4
000079f4d2dde716  vmovaps [rsp+0x50], xmm5
000079f4d2dde71c  vmovaps [rsp+0x60], xmm6
000079f4d2dde722  vmovaps [rsp+0x70], xmm7
000079f4d2dde728  vmovaps [rsp+0x80], xmm8
000079f4d2dde731  vmovaps [rsp+0x90], xmm9
000079f4d2dde73a  vmovaps [rsp+0xA0], xmm10
000079f4d2dde743  vmovaps [rsp+0xB0], xmm11
000079f4d2dde74c  vmovaps [rsp+0xC0], xmm12
000079f4d2dde755  vmovaps [rsp+0xD0], xmm14
000079f4d2dde75e  vmovaps [rsp+0xE0], xmm15
000079f4d2dde767  sub rsp, 0x30
000079f4d2dde76b  movaps [rsp], xmm13
000079f4d2dde770  movaps [rsp+0x10], xmm10
000079f4d2dde776  movaps [rsp+0x20], xmm14
000079f4d2dde77c  lea rdi, [rsp]
000079f4d2dde780  mov esi, 0x00
000079f4d2dde785  mov rax, 0x5D9EC01E8530
000079f4d2dde78f  call rax
000079f4d2dde791  movaps xmm13, [rsp]
000079f4d2dde796  add rsp, 0x30
000079f4d2dde79a  vmovaps xmm0, [rsp]
000079f4d2dde79f  vmovaps xmm1, [rsp+0x10]
000079f4d2dde7a5  vmovaps xmm2, [rsp+0x20]
000079f4d2dde7ab  vmovaps xmm3, [rsp+0x30]
000079f4d2dde7b1  vmovaps xmm4, [rsp+0x40]
000079f4d2dde7b7  vmovaps xmm5, [rsp+0x50]
000079f4d2dde7bd  vmovaps xmm6, [rsp+0x60]
000079f4d2dde7c3  vmovaps xmm7, [rsp+0x70]
000079f4d2dde7c9  vmovaps xmm8, [rsp+0x80]
000079f4d2dde7d2  vmovaps xmm9, [rsp+0x90]
000079f4d2dde7db  vmovaps xmm10, [rsp+0xA0]
000079f4d2dde7e4  vmovaps xmm11, [rsp+0xB0]
000079f4d2dde7ed  vmovaps xmm12, [rsp+0xC0]
000079f4d2dde7f6  vmovaps xmm14, [rsp+0xD0]
000079f4d2dde7ff  vmovaps xmm15, [rsp+0xE0]
000079f4d2dde808  add rsp, 0xF0
000079f4d2dde80f  pop r11
000079f4d2dde811  pop r10
000079f4d2dde813  pop r9
000079f4d2dde815  pop r8
000079f4d2dde817  pop rsi
000079f4d2dde818  pop rdi
000079f4d2dde819  pop rdx
000079f4d2dde81a  pop rcx
000079f4d2dde81b  pop rax
000079f4d2dde81c  add rsp, 0x08
000079f4d2dde820  jmp 0x000079F4D2DD984D
000079f4d2dde825  sub rsp, 0x08
000079f4d2dde829  push rax
000079f4d2dde82a  push rcx
000079f4d2dde82b  push rdx
000079f4d2dde82c  push rdi
000079f4d2dde82d  push rsi
000079f4d2dde82e  push r8
000079f4d2dde830  push r9
000079f4d2dde832  push r10
000079f4d2dde834  push r11
000079f4d2dde836  sub rsp, 0xF0
000079f4d2dde83d  vmovaps [rsp], xmm0
000079f4d2dde842  vmovaps [rsp+0x10], xmm1
000079f4d2dde848  vmovaps [rsp+0x20], xmm2
000079f4d2dde84e  vmovaps [rsp+0x30], xmm3
000079f4d2dde854  vmovaps [rsp+0x40], xmm4
000079f4d2dde85a  vmovaps [rsp+0x50], xmm5
000079f4d2dde860  vmovaps [rsp+0x60], xmm6
000079f4d2dde866  vmovaps [rsp+0x70], xmm7
000079f4d2dde86c  vmovaps [rsp+0x80], xmm8
000079f4d2dde875  vmovaps [rsp+0x90], xmm9
000079f4d2dde87e  vmovaps [rsp+0xA0], xmm10
000079f4d2dde887  vmovaps [rsp+0xB0], xmm11
000079f4d2dde890  vmovaps [rsp+0xC0], xmm12
000079f4d2dde899  vmovaps [rsp+0xD0], xmm13
000079f4d2dde8a2  vmovaps [rsp+0xE0], xmm15
000079f4d2dde8ab  sub rsp, 0x30
000079f4d2dde8af  movaps [rsp], xmm14
000079f4d2dde8b4  movaps [rsp+0x10], xmm1
000079f4d2dde8b9  movaps [rsp+0x20], xmm7
000079f4d2dde8be  lea rdi, [rsp]
000079f4d2dde8c2  mov esi, 0x00
000079f4d2dde8c7  mov rax, 0x5D9EC01E8530
000079f4d2dde8d1  call rax
000079f4d2dde8d3  movaps xmm14, [rsp]
000079f4d2dde8d8  add rsp, 0x30
000079f4d2dde8dc  vmovaps xmm0, [rsp]
000079f4d2dde8e1  vmovaps xmm1, [rsp+0x10]
000079f4d2dde8e7  vmovaps xmm2, [rsp+0x20]
000079f4d2dde8ed  vmovaps xmm3, [rsp+0x30]
000079f4d2dde8f3  vmovaps xmm4, [rsp+0x40]
000079f4d2dde8f9  vmovaps xmm5, [rsp+0x50]
000079f4d2dde8ff  vmovaps xmm6, [rsp+0x60]
000079f4d2dde905  vmovaps xmm7, [rsp+0x70]
000079f4d2dde90b  vmovaps xmm8, [rsp+0x80]
000079f4d2dde914  vmovaps xmm9, [rsp+0x90]
000079f4d2dde91d  vmovaps xmm10, [rsp+0xA0]
000079f4d2dde926  vmovaps xmm11, [rsp+0xB0]
000079f4d2dde92f  vmovaps xmm12, [rsp+0xC0]
000079f4d2dde938  vmovaps xmm13, [rsp+0xD0]
000079f4d2dde941  vmovaps xmm15, [rsp+0xE0]
000079f4d2dde94a  add rsp, 0xF0
000079f4d2dde951  pop r11
000079f4d2dde953  pop r10
000079f4d2dde955  pop r9
000079f4d2dde957  pop r8
000079f4d2dde959  pop rsi
000079f4d2dde95a  pop rdi
000079f4d2dde95b  pop rdx
000079f4d2dde95c  pop rcx
000079f4d2dde95d  pop rax
000079f4d2dde95e  add rsp, 0x08
000079f4d2dde962  jmp 0x000079F4D2DD9870
000079f4d2dde967  sub rsp, 0x08
000079f4d2dde96b  push rax
000079f4d2dde96c  push rcx
000079f4d2dde96d  push rdx
000079f4d2dde96e  push rdi
000079f4d2dde96f  push rsi
000079f4d2dde970  push r8
000079f4d2dde972  push r9
000079f4d2dde974  push r10
000079f4d2dde976  push r11
000079f4d2dde978  sub rsp, 0xF0
000079f4d2dde97f  vmovaps [rsp], xmm0
000079f4d2dde984  vmovaps [rsp+0x10], xmm2
000079f4d2dde98a  vmovaps [rsp+0x20], xmm3
000079f4d2dde990  vmovaps [rsp+0x30], xmm4
000079f4d2dde996  vmovaps [rsp+0x40], xmm5
000079f4d2dde99c  vmovaps [rsp+0x50], xmm6
000079f4d2dde9a2  vmovaps [rsp+0x60], xmm7
000079f4d2dde9a8  vmovaps [rsp+0x70], xmm8
000079f4d2dde9ae  vmovaps [rsp+0x80], xmm9
000079f4d2dde9b7  vmovaps [rsp+0x90], xmm10
000079f4d2dde9c0  vmovaps [rsp+0xA0], xmm11
000079f4d2dde9c9  vmovaps [rsp+0xB0], xmm12
000079f4d2dde9d2  vmovaps [rsp+0xC0], xmm13
000079f4d2dde9db  vmovaps [rsp+0xD0], xmm14
000079f4d2dde9e4  vmovaps [rsp+0xE0], xmm15
000079f4d2dde9ed  sub rsp, 0x30
000079f4d2dde9f1  movaps [rsp], xmm1
000079f4d2dde9f5  movaps [rsp+0x10], xmm8
000079f4d2dde9fb  movaps [rsp+0x20], xmm9
000079f4d2ddea01  lea rdi, [rsp]
000079f4d2ddea05  mov esi, 0x00
000079f4d2ddea0a  mov rax, 0x5D9EC01E8530
000079f4d2ddea14  call rax
000079f4d2ddea16  movaps xmm1, [rsp]
000079f4d2ddea1a  add rsp, 0x30
000079f4d2ddea1e  vmovaps xmm0, [rsp]
000079f4d2ddea23  vmovaps xmm2, [rsp+0x10]
000079f4d2ddea29  vmovaps xmm3, [rsp+0x20]
000079f4d2ddea2f  vmovaps xmm4, [rsp+0x30]
000079f4d2ddea35  vmovaps xmm5, [rsp+0x40]
000079f4d2ddea3b  vmovaps xmm6, [rsp+0x50]
000079f4d2ddea41  vmovaps xmm7, [rsp+0x60]
000079f4d2ddea47  vmovaps xmm8, [rsp+0x70]
000079f4d2ddea4d  vmovaps xmm9, [rsp+0x80]
000079f4d2ddea56  vmovaps xmm10, [rsp+0x90]
000079f4d2ddea5f  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddea68  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddea71  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddea7a  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddea83  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddea8c  add rsp, 0xF0
000079f4d2ddea93  pop r11
000079f4d2ddea95  pop r10
000079f4d2ddea97  pop r9
000079f4d2ddea99  pop r8
000079f4d2ddea9b  pop rsi
000079f4d2ddea9c  pop rdi
000079f4d2ddea9d  pop rdx
000079f4d2ddea9e  pop rcx
000079f4d2ddea9f  pop rax
000079f4d2ddeaa0  add rsp, 0x08
000079f4d2ddeaa4  jmp 0x000079F4D2DD9892
000079f4d2ddeaa9  call 0x000079F4D2CB3E40
000079f4d2ddeaae  jmp 0x000079F4D2DD98A0
000079f4d2ddeab3  call 0x000079F4D2C0C380
000079f4d2ddeab8  jmp 0x000079F4D2DD98AA
000079f4d2ddeabd  call 0x000079F4D2C0D600
000079f4d2ddeac2  jmp 0x000079F4D2DD98B4
000079f4d2ddeac7  call 0x000079F4D2BFF540
000079f4d2ddeacc  jmp 0x000079F4D2DD98BE
000079f4d2ddead1  int3
000079f4d2ddead2  nop [rax+rax*1], ax
000079f4d2ddeadb  nop [rax+rax*1], eax
000079f4d2ddeae0  mov eax, [r15+0x48]
000079f4d2ddeae4  lea r14d, [eax+0x01]
000079f4d2ddeae9  mov [rsp+0x10], r14d
000079f4d2ddeaee  mov r14d, r14d
000079f4d2ddeaf1  mov [r15+0x48], r14
000079f4d2ddeaf5  xor eax, eax
000079f4d2ddeaf7  mov r14d, [rsp+0x10]
000079f4d2ddeafc  cmp r14d, 0x1F4
000079f4d2ddeb03  cmc
000079f4d2ddeb04  lahf
000079f4d2ddeb05  seto al
000079f4d2ddeb08  mov [r15+0x108], eax
000079f4d2ddeb0f  mov eax, [r15+0x108]
000079f4d2ddeb16  sahf
000079f4d2ddeb17  jnz 0x000079F4D2DDEB49
000079f4d2ddeb19  cmp dword ptr [r15+0x318], 0x00
000079f4d2ddeb21  jz 0x000079F4D2DE4C90
000079f4d2ddeb27  nop [rax+rax*1], ax
000079f4d2ddeb30  nop [rax+rax*1], eax
000079f4d2ddeb38  mov eax, 0x4106DC
000079f4d2ddeb3d  mov [r15+0x100], rax
000079f4d2ddeb44  jmp 0x000079F4D2BFE110
000079f4d2ddeb49  cmp dword ptr [r15+0x318], 0x00
000079f4d2ddeb51  jz 0x000079F4D2DDEB80
000079f4d2ddeb57  nop [rax+rax*1], ax
000079f4d2ddeb60  nop [rax+rax*1], eax
000079f4d2ddeb68  mov eax, 0x410500
000079f4d2ddeb6d  mov [r15+0x100], rax
000079f4d2ddeb74  jmp 0x000079F4D2BFE110
000079f4d2ddeb79  int3
000079f4d2ddeb7a  int3
000079f4d2ddeb7b  nop [rax+rax*1], eax
000079f4d2ddeb80  mov rax, [r15+0x40]
000079f4d2ddeb84  movaps xmm1, [r15+0x1D0]
000079f4d2ddeb8c  vmovaps [rsp+0x10], xmm1
000079f4d2ddeb92  vmovaps xmm15, [rsp+0x10]
000079f4d2ddeb98  por xmm1, xmm15
000079f4d2ddeb9d  movaps xmm14, [r15+0x1A0]
000079f4d2ddeba5  vmovaps [rsp+0x10], xmm14
000079f4d2ddebab  vmovaps xmm13, [rsp+0x10]
000079f4d2ddebb1  por xmm14, xmm13
000079f4d2ddebb6  lea r14, [rax+0x30]
000079f4d2ddebba  mov r12, [r13+r14*1]
000079f4d2ddebbf  lea r14, [rax+0x38]
000079f4d2ddebc3  mov r11, [r13+r14*1]
000079f4d2ddebc8  movq xmm13, r12
000079f4d2ddebcd  movq xmm12, r11
000079f4d2ddebd2  movq xmm13, xmm13
000079f4d2ddebd7  vmovaps [rsp+0x10], xmm13
000079f4d2ddebdd  movq xmm13, xmm13
000079f4d2ddebe2  movaps [r15+0x130], xmm13
000079f4d2ddebea  movq xmm12, xmm12
000079f4d2ddebef  vmovaps [rsp+0x20], xmm12
000079f4d2ddebf5  movq xmm12, xmm12
000079f4d2ddebfa  movaps [r15+0x280], xmm12
000079f4d2ddec02  movaps xmm13, [r15+0x270]
000079f4d2ddec0a  vmovaps [rsp+0x30], xmm13
000079f4d2ddec10  vmovaps xmm12, [rsp+0x30]
000079f4d2ddec16  por xmm13, xmm12
000079f4d2ddec1b  lea r14, [rax+0x20]
000079f4d2ddec1f  mov r12, [r13+r14*1]
000079f4d2ddec24  lea r14, [rax+0x28]
000079f4d2ddec28  mov r11, [r13+r14*1]
000079f4d2ddec2d  movq xmm12, r12
000079f4d2ddec32  movq xmm11, r11
000079f4d2ddec37  movq xmm12, xmm12
000079f4d2ddec3c  vmovaps [rsp+0x30], xmm12
000079f4d2ddec42  movq xmm12, xmm12
000079f4d2ddec47  movaps [r15+0x150], xmm12
000079f4d2ddec4f  movq xmm11, xmm11
000079f4d2ddec54  vmovaps [rsp+0x40], xmm11
000079f4d2ddec5a  movq xmm11, xmm11
000079f4d2ddec5f  movaps [r15+0x140], xmm11
000079f4d2ddec67  lea r14, [rax+0x10]
000079f4d2ddec6b  mov r12, [r13+r14*1]
000079f4d2ddec70  lea r14, [rax+0x18]
000079f4d2ddec74  mov r11, [r13+r14*1]
000079f4d2ddec79  movq xmm12, r12
000079f4d2ddec7e  movq xmm11, r11
000079f4d2ddec83  movq xmm12, xmm12
000079f4d2ddec88  vmovaps [rsp+0x50], xmm12
000079f4d2ddec8e  movq xmm12, xmm12
000079f4d2ddec93  movaps [r15+0x170], xmm12
000079f4d2ddec9b  movq xmm11, xmm11
000079f4d2ddeca0  vmovaps [rsp+0x60], xmm11
000079f4d2ddeca6  movq xmm11, xmm11
000079f4d2ddecab  movaps [r15+0x160], xmm11
000079f4d2ddecb3  mov r14, [r13+rax*1]
000079f4d2ddecb8  vmovq xmm12, r14
000079f4d2ddecbd  vpbroadcastq xmm12, xmm12
000079f4d2ddecc2  lea r14, [rax+0x08]
000079f4d2ddecc6  mov rax, [r13+r14*1]
000079f4d2ddeccb  movq xmm11, rax
000079f4d2ddecd0  movaps [r15+0x230], xmm11
000079f4d2ddecd8  mov rax, [r15+0xF8]
000079f4d2ddecdf  lea r14, [rax+0x50]
000079f4d2ddece3  movups xmm11, [r13+r14*1]
000079f4d2ddece9  lea r14, [rax+0x60]
000079f4d2ddeced  movups xmm10, [r13+r14*1]
000079f4d2ddecf3  lea r14, [rax+0x30]
000079f4d2ddecf7  movups xmm9, [r13+r14*1]
000079f4d2ddecfd  mov r14, [r15+0x50]
000079f4d2dded01  mov [r15+0x60], r14
000079f4d2dded05  mov qword ptr [r15+0x58], 0x40
000079f4d2dded0d  movaps xmm8, xmm12
000079f4d2dded11  mulpd xmm8, xmm15
000079f4d2dded16  vcmppd xmm7, xmm8, xmm8, 0x03
000079f4d2dded1c  ptest xmm7, xmm7
000079f4d2dded21  jnz 0x000079F4D2DDFB4A
000079f4d2dded27  movq xmm15, qword ptr [r15+0x230]
000079f4d2dded30  vmovaps [rsp+0x70], xmm15
000079f4d2dded36  vpermilpd xmm15, xmm15, 0x00
000079f4d2dded3c  movaps xmm7, xmm9
000079f4d2dded40  mulpd xmm7, xmm15
000079f4d2dded45  vcmppd xmm6, xmm7, xmm7, 0x03
000079f4d2dded4a  ptest xmm6, xmm6
000079f4d2dded4f  jnz 0x000079F4D2DDFC8E
000079f4d2dded55  vxorps xmm15, xmm15, xmm15
000079f4d2dded5a  vpbroadcastq xmm15, xmm15
000079f4d2dded5f  movaps xmm9, xmm12
000079f4d2dded63  mulpd xmm9, xmm10
000079f4d2dded68  vcmppd xmm6, xmm9, xmm9, 0x03
000079f4d2dded6e  ptest xmm6, xmm6
000079f4d2dded73  jnz 0x000079F4D2DDFDD0
000079f4d2dded79  movaps xmm10, xmm12
000079f4d2dded7d  mulpd xmm10, xmm11
000079f4d2dded82  vcmppd xmm6, xmm10, xmm10, 0x03
000079f4d2dded88  ptest xmm6, xmm6
000079f4d2dded8d  jnz 0x000079F4D2DDFF14
000079f4d2dded93  movaps xmm11, [r15+0x1F0]
000079f4d2dded9b  movaps xmm6, xmm12
000079f4d2dded9f  mulpd xmm6, xmm11
000079f4d2ddeda4  vcmppd xmm5, xmm6, xmm6, 0x03
000079f4d2ddeda9  ptest xmm5, xmm5
000079f4d2ddedae  jnz 0x000079F4D2DE0058
000079f4d2ddedb4  movaps xmm12, [r15+0x2A0]
000079f4d2ddedbc  vmovaps [rsp+0x80], xmm12
000079f4d2ddedc5  vmovaps xmm11, [rsp+0x80]
000079f4d2ddedce  por xmm12, xmm11
000079f4d2ddedd3  movaps xmm11, [r15+0x250]
000079f4d2ddeddb  vmovaps [rsp+0x80], xmm11
000079f4d2ddede4  vmovaps xmm5, [rsp+0x80]
000079f4d2ddeded  por xmm11, xmm5
000079f4d2ddedf2  vmovaps xmm4, [rsp+0x70]
000079f4d2ddedf8  vpermilpd xmm4, xmm4, 0x00
000079f4d2ddedfe  movaps xmm3, xmm5
000079f4d2ddee01  mulpd xmm3, xmm4
000079f4d2ddee05  vcmppd xmm2, xmm3, xmm3, 0x03
000079f4d2ddee0a  ptest xmm2, xmm2
000079f4d2ddee0f  jnz 0x000079F4D2DE019A
000079f4d2ddee15  mov [rsp+0x80], rax
000079f4d2ddee1d  xor eax, eax
000079f4d2ddee1f  mov r12d, 0x40
000079f4d2ddee25  mov r11d, 0x200
000079f4d2ddee2b  cmp r12, r11
000079f4d2ddee2e  cmc
000079f4d2ddee2f  lahf
000079f4d2ddee30  seto al
000079f4d2ddee33  mov [r15+0x108], eax
000079f4d2ddee3a  movaps xmm5, xmm8
000079f4d2ddee3e  addpd xmm5, xmm15
000079f4d2ddee43  vcmppd xmm4, xmm5, xmm5, 0x03
000079f4d2ddee48  ptest xmm4, xmm4
000079f4d2ddee4d  jnz 0x000079F4D2DE02DA
000079f4d2ddee53  movaps xmm8, [r15+0x1B0]
000079f4d2ddee5b  movaps xmm4, xmm9
000079f4d2ddee5f  addpd xmm4, xmm8
000079f4d2ddee64  vcmppd xmm2, xmm4, xmm4, 0x03
000079f4d2ddee69  ptest xmm2, xmm2
000079f4d2ddee6e  jnz 0x000079F4D2DE041C
000079f4d2ddee74  movaps xmm9, xmm10
000079f4d2ddee78  addpd xmm9, xmm8
000079f4d2ddee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000079f4d2ddee83  ptest xmm2, xmm2
000079f4d2ddee88  jnz 0x000079F4D2DE055E
000079f4d2ddee8e  movaps xmm10, [r15+0x2F0]
000079f4d2ddee96  vmovaps [rsp+0x90], xmm10
000079f4d2ddee9f  vmovaps xmm8, [rsp+0x90]
000079f4d2ddeea8  por xmm10, xmm8
000079f4d2ddeead  movaps xmm8, [r15+0x2E0]
000079f4d2ddeeb5  vmovaps [rsp+0x90], xmm8
000079f4d2ddeebe  vmovaps xmm2, [rsp+0x90]
000079f4d2ddeec7  por xmm8, xmm2
000079f4d2ddeecc  movaps xmm2, [r15+0x2D0]
000079f4d2ddeed4  vmovaps [rsp+0x90], xmm2
000079f4d2ddeedd  vmovaps [rsp+0xA0], xmm1
000079f4d2ddeee6  vmovaps xmm1, [rsp+0x90]
000079f4d2ddeeef  por xmm2, xmm1
000079f4d2ddeef3  movaps xmm1, [r15+0x200]
000079f4d2ddeefb  vmovaps [rsp+0x90], xmm1
000079f4d2ddef04  vmovaps [rsp+0xB0], xmm15
000079f4d2ddef0d  vmovaps xmm15, [rsp+0x90]
000079f4d2ddef16  por xmm1, xmm15
000079f4d2ddef1b  movaps xmm15, [r15+0x1C0]
000079f4d2ddef23  vmovaps [rsp+0x90], xmm15
000079f4d2ddef2c  vmovaps [rsp+0xC0], xmm1
000079f4d2ddef35  vmovaps xmm1, [rsp+0x90]
000079f4d2ddef3e  por xmm15, xmm1
000079f4d2ddef43  movaps xmm1, [r15+0x190]
000079f4d2ddef4b  vmovaps [rsp+0x90], xmm1
000079f4d2ddef54  vmovaps [rsp+0xD0], xmm15
000079f4d2ddef5d  vmovaps xmm15, [rsp+0x90]
000079f4d2ddef66  por xmm1, xmm15
000079f4d2ddef6b  movaps xmm15, [r15+0x300]
000079f4d2ddef73  vmovaps [rsp+0x90], xmm15
000079f4d2ddef7c  vmovaps [rsp+0xE0], xmm1
000079f4d2ddef85  vmovaps xmm1, [rsp+0x90]
000079f4d2ddef8e  por xmm15, xmm1
000079f4d2ddef93  mov rax, [rsp+0x80]
000079f4d2ddef9b  lea r12, [rax+0xA0]
000079f4d2ddefa2  movups xmm1, [r13+r12*1]
000079f4d2ddefa8  lea r12, [rax+0xB0]
000079f4d2ddefaf  vmovaps [rsp+0x80], xmm1
000079f4d2ddefb8  movups xmm1, [r13+r12*1]
000079f4d2ddefbe  vmovaps [rsp+0x90], xmm1
000079f4d2ddefc7  vmovaps [rsp+0xF0], xmm15
000079f4d2ddefd0  vmovaps xmm15, [rsp+0xB0]
000079f4d2ddefd9  vmovaps [rsp+0xB0], xmm14
000079f4d2ddefe2  movaps xmm1, xmm6
000079f4d2ddefe5  addpd xmm1, xmm15
000079f4d2ddefea  vcmppd xmm14, xmm1, xmm1, 0x03
000079f4d2ddefef  ptest xmm14, xmm14
000079f4d2ddeff5  jnz 0x000079F4D2DE06B6
000079f4d2ddeffb  lea r12, [rax+0xF0]
000079f4d2ddf002  movups xmm15, [r13+r12*1]
000079f4d2ddf008  movaps xmm14, xmm4
000079f4d2ddf00c  addpd xmm14, xmm3
000079f4d2ddf011  vcmppd xmm6, xmm14, xmm14, 0x03
000079f4d2ddf017  ptest xmm6, xmm6
000079f4d2ddf01c  jnz 0x000079F4D2DE0801
000079f4d2ddf022  movaps xmm6, xmm9
000079f4d2ddf026  addpd xmm6, xmm7
000079f4d2ddf02a  vcmppd xmm4, xmm6, xmm6, 0x03
000079f4d2ddf02f  ptest xmm4, xmm4
000079f4d2ddf034  jnz 0x000079F4D2DE0943
000079f4d2ddf03a  vmovaps xmm9, [rsp+0x70]
000079f4d2ddf040  vpermilpd xmm9, xmm9, 0x00
000079f4d2ddf046  vmovaps xmm4, [rsp+0x90]
000079f4d2ddf04f  movaps xmm7, xmm4
000079f4d2ddf052  mulpd xmm7, xmm9
000079f4d2ddf057  vcmppd xmm3, xmm7, xmm7, 0x03
000079f4d2ddf05c  ptest xmm3, xmm3
000079f4d2ddf061  jnz 0x000079F4D2DE0A84
000079f4d2ddf067  vmovaps xmm9, [rsp+0x50]
000079f4d2ddf06d  vpermilpd xmm9, xmm9, 0x00
000079f4d2ddf073  movaps xmm4, xmm15
000079f4d2ddf077  mulpd xmm4, xmm9
000079f4d2ddf07c  vcmppd xmm3, xmm4, xmm4, 0x03
000079f4d2ddf081  ptest xmm3, xmm3
000079f4d2ddf086  jnz 0x000079F4D2DE0BC5
000079f4d2ddf08c  lea r12, [rax+0xE0]
000079f4d2ddf093  movups xmm15, [r13+r12*1]
000079f4d2ddf099  vmovaps xmm9, [rsp+0x70]
000079f4d2ddf09f  vpermilpd xmm9, xmm9, 0x00
000079f4d2ddf0a5  vmovaps [rsp+0x70], xmm1
000079f4d2ddf0ab  vmovaps xmm1, [rsp+0x80]
000079f4d2ddf0b4  vmovaps [rsp+0x80], xmm15
000079f4d2ddf0bd  movaps xmm3, xmm1
000079f4d2ddf0c0  mulpd xmm3, xmm9
000079f4d2ddf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000079f4d2ddf0ca  ptest xmm15, xmm15
000079f4d2ddf0d0  jnz 0x000079F4D2DE0D11
000079f4d2ddf0d6  vmovaps xmm1, [rsp+0xF0]
000079f4d2ddf0df  vmovaps xmm15, [rsp+0xF0]
000079f4d2ddf0e8  por xmm1, xmm15
000079f4d2ddf0ed  movaps [r15+0x300], xmm1
000079f4d2ddf0f5  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddf0fe  vmovaps xmm9, [rsp+0xE0]
000079f4d2ddf107  por xmm15, xmm9
000079f4d2ddf10c  movaps [r15+0x190], xmm15
000079f4d2ddf114  vmovaps xmm9, [rsp+0x50]
000079f4d2ddf11a  vpermilpd xmm9, xmm9, 0x00
000079f4d2ddf120  vmovaps [rsp+0x90], xmm1
000079f4d2ddf129  vmovaps [rsp+0xE0], xmm15
000079f4d2ddf132  vmovaps xmm15, [rsp+0x80]
000079f4d2ddf13b  vmovaps [rsp+0x80], xmm14
000079f4d2ddf144  movaps xmm1, xmm15
000079f4d2ddf148  mulpd xmm1, xmm9
000079f4d2ddf14d  vcmppd xmm14, xmm1, xmm1, 0x03
000079f4d2ddf152  ptest xmm14, xmm14
000079f4d2ddf158  jnz 0x000079F4D2DE0E52
000079f4d2ddf15e  lea r12, [rax+0x90]
000079f4d2ddf165  movups xmm15, [r13+r12*1]
000079f4d2ddf16b  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddf174  vmovaps xmm9, [rsp+0xD0]
000079f4d2ddf17d  por xmm14, xmm9
000079f4d2ddf182  movaps [r15+0x1C0], xmm14
000079f4d2ddf18a  vmovaps xmm9, [rsp+0xC0]
000079f4d2ddf193  vmovaps [rsp+0xD0], xmm1
000079f4d2ddf19c  vmovaps xmm1, [rsp+0xC0]
000079f4d2ddf1a5  por xmm9, xmm1
000079f4d2ddf1aa  movaps [r15+0x200], xmm9
000079f4d2ddf1b2  vmovaps [rsp+0xC0], xmm2
000079f4d2ddf1bb  vmovaps xmm1, [rsp+0xC0]
000079f4d2ddf1c4  por xmm2, xmm1
000079f4d2ddf1c8  movaps [r15+0x2D0], xmm2
000079f4d2ddf1d0  vmovaps [rsp+0xC0], xmm8
000079f4d2ddf1d9  vmovaps xmm1, [rsp+0xC0]
000079f4d2ddf1e2  por xmm8, xmm1
000079f4d2ddf1e7  movaps [r15+0x2E0], xmm8
000079f4d2ddf1ef  vmovaps [rsp+0xC0], xmm15
000079f4d2ddf1f8  movaps xmm1, xmm5
000079f4d2ddf1fb  addpd xmm1, xmm7
000079f4d2ddf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000079f4d2ddf204  ptest xmm15, xmm15
000079f4d2ddf20a  jnz 0x000079F4D2DE0F9E
000079f4d2ddf210  vmovaps xmm15, [rsp+0x50]
000079f4d2ddf216  vpermilpd xmm15, xmm15, 0x00
000079f4d2ddf21c  vmovaps xmm5, [rsp+0xC0]
000079f4d2ddf225  vmovaps [rsp+0xC0], xmm1
000079f4d2ddf22e  movaps xmm7, xmm5
000079f4d2ddf231  mulpd xmm7, xmm15
000079f4d2ddf236  vcmppd xmm1, xmm7, xmm7, 0x03
000079f4d2ddf23b  ptest xmm1, xmm1
000079f4d2ddf240  jnz 0x000079F4D2DE10DE
000079f4d2ddf246  lea r12, [rax+0x80]
000079f4d2ddf24d  movups xmm1, [r13+r12*1]
000079f4d2ddf253  vmovaps xmm5, [rsp+0x70]
000079f4d2ddf259  vmovaps [rsp+0x70], xmm1
000079f4d2ddf25f  movaps xmm15, xmm5
000079f4d2ddf263  addpd xmm15, xmm3
000079f4d2ddf268  vcmppd xmm1, xmm15, xmm15, 0x03
000079f4d2ddf26e  ptest xmm1, xmm1
000079f4d2ddf273  jnz 0x000079F4D2DE1229
000079f4d2ddf279  vmovaps xmm5, [rsp+0x80]
000079f4d2ddf282  movaps xmm1, xmm5
000079f4d2ddf285  addpd xmm1, xmm4
000079f4d2ddf289  vcmppd xmm3, xmm1, xmm1, 0x03
000079f4d2ddf28e  ptest xmm3, xmm3
000079f4d2ddf293  jnz 0x000079F4D2DE136B
000079f4d2ddf299  vmovaps [rsp+0x80], xmm10
000079f4d2ddf2a2  vmovaps xmm5, [rsp+0x80]
000079f4d2ddf2ab  por xmm10, xmm5
000079f4d2ddf2b0  movaps [r15+0x2F0], xmm10
000079f4d2ddf2b8  vmovaps xmm5, [rsp+0x50]
000079f4d2ddf2be  vpermilpd xmm5, xmm5, 0x00
000079f4d2ddf2c4  vmovaps xmm3, [rsp+0x70]
000079f4d2ddf2ca  vmovaps [rsp+0x50], xmm1
000079f4d2ddf2d0  movaps xmm4, xmm3
000079f4d2ddf2d3  mulpd xmm4, xmm5
000079f4d2ddf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000079f4d2ddf2dc  ptest xmm1, xmm1
000079f4d2ddf2e1  jnz 0x000079F4D2DE14AB
000079f4d2ddf2e7  lea r12, [rax+0xD0]
000079f4d2ddf2ee  movups xmm1, [r13+r12*1]
000079f4d2ddf2f4  vmovaps xmm3, [rsp+0xD0]
000079f4d2ddf2fd  vmovaps [rsp+0x70], xmm1
000079f4d2ddf303  movaps xmm5, xmm6
000079f4d2ddf306  addpd xmm5, xmm3
000079f4d2ddf30a  vcmppd xmm1, xmm5, xmm5, 0x03
000079f4d2ddf30f  ptest xmm1, xmm1
000079f4d2ddf314  jnz 0x000079F4D2DE15F5
000079f4d2ddf31a  vmovaps xmm1, [rsp+0x60]
000079f4d2ddf320  vpermilpd xmm1, xmm1, 0x00
000079f4d2ddf326  movaps xmm6, xmm9
000079f4d2ddf32a  mulpd xmm6, xmm1
000079f4d2ddf32e  vcmppd xmm3, xmm6, xmm6, 0x03
000079f4d2ddf333  ptest xmm3, xmm3
000079f4d2ddf338  jnz 0x000079F4D2DE1735
000079f4d2ddf33e  movaps [r15+0x260], xmm6
000079f4d2ddf346  vxorps xmm1, xmm1, xmm1
000079f4d2ddf34a  vpbroadcastq xmm1, xmm1
000079f4d2ddf34f  movaps [r15+0x1B0], xmm1
000079f4d2ddf357  vmovaps xmm1, [rsp+0x60]
000079f4d2ddf35d  vpermilpd xmm1, xmm1, 0x00
000079f4d2ddf363  vmovaps xmm3, [rsp+0x70]
000079f4d2ddf369  vmovaps [rsp+0x70], xmm15
000079f4d2ddf36f  movaps xmm9, xmm3
000079f4d2ddf373  mulpd xmm9, xmm1
000079f4d2ddf378  vcmppd xmm15, xmm9, xmm9, 0x03
000079f4d2ddf37e  ptest xmm15, xmm15
000079f4d2ddf384  jnz 0x000079F4D2DE1876
000079f4d2ddf38a  lea r12, [rax+0xC0]
000079f4d2ddf391  movups xmm1, [r13+r12*1]
000079f4d2ddf397  vmovaps xmm3, [rsp+0xC0]
000079f4d2ddf3a0  vmovaps [rsp+0x80], xmm1
000079f4d2ddf3a9  movaps xmm15, xmm3
000079f4d2ddf3ad  addpd xmm15, xmm7
000079f4d2ddf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000079f4d2ddf3b8  ptest xmm1, xmm1
000079f4d2ddf3bd  jnz 0x000079F4D2DE19C2
000079f4d2ddf3c3  vmovaps [rsp+0xC0], xmm13
000079f4d2ddf3cc  vmovaps xmm1, [rsp+0xC0]
000079f4d2ddf3d5  por xmm13, xmm1
000079f4d2ddf3da  movaps [r15+0x270], xmm13
000079f4d2ddf3e2  vmovaps xmm1, [rsp+0xB0]
000079f4d2ddf3eb  vmovaps xmm7, [rsp+0xB0]
000079f4d2ddf3f4  por xmm1, xmm7
000079f4d2ddf3f8  movaps [r15+0x1A0], xmm1
000079f4d2ddf400  vmovaps xmm1, [rsp+0x60]
000079f4d2ddf406  vpermilpd xmm1, xmm1, 0x00
000079f4d2ddf40c  vmovaps [rsp+0xB0], xmm1
000079f4d2ddf415  vmovaps xmm1, [rsp+0x80]
000079f4d2ddf41e  vmovaps [rsp+0x80], xmm15
000079f4d2ddf427  vmovaps xmm15, [rsp+0xB0]
000079f4d2ddf430  vmovaps [rsp+0xB0], xmm14
000079f4d2ddf439  movaps xmm3, xmm1
000079f4d2ddf43c  mulpd xmm3, xmm15
000079f4d2ddf441  vcmppd xmm14, xmm3, xmm3, 0x03
000079f4d2ddf446  ptest xmm14, xmm14
000079f4d2ddf44c  jnz 0x000079F4D2DE1B04
000079f4d2ddf452  lea r12, [rax+0x20]
000079f4d2ddf456  movups xmm1, [r13+r12*1]
000079f4d2ddf45c  movaps [r15+0x110], xmm1
000079f4d2ddf464  vmovaps xmm14, [rsp+0x70]
000079f4d2ddf46a  vmovaps [rsp+0x70], xmm1
000079f4d2ddf470  movaps xmm15, xmm14
000079f4d2ddf474  addpd xmm15, xmm4
000079f4d2ddf479  vcmppd xmm1, xmm15, xmm15, 0x03
000079f4d2ddf47f  ptest xmm1, xmm1
000079f4d2ddf484  jnz 0x000079F4D2DE1C4F
000079f4d2ddf48a  vmovaps xmm1, [rsp+0x60]
000079f4d2ddf490  vpermilpd xmm1, xmm1, 0x00
000079f4d2ddf496  movaps xmm14, xmm2
000079f4d2ddf49a  mulpd xmm14, xmm1
000079f4d2ddf49f  vcmppd xmm4, xmm14, xmm14, 0x03
000079f4d2ddf4a5  ptest xmm4, xmm4
000079f4d2ddf4aa  jnz 0x000079F4D2DE1D92
000079f4d2ddf4b0  vmovaps xmm4, [rsp+0x50]
000079f4d2ddf4b6  movaps xmm1, xmm4
000079f4d2ddf4b9  addpd xmm1, xmm9
000079f4d2ddf4be  vcmppd xmm2, xmm1, xmm1, 0x03
000079f4d2ddf4c3  ptest xmm2, xmm2
000079f4d2ddf4c8  jnz 0x000079F4D2DE1ED4
000079f4d2ddf4ce  vmovaps xmm9, [rsp+0x30]
000079f4d2ddf4d4  vpermilpd xmm9, xmm9, 0x00
000079f4d2ddf4da  vmovaps xmm2, [rsp+0x70]
000079f4d2ddf4e0  vmovaps [rsp+0x50], xmm1
000079f4d2ddf4e6  movaps xmm4, xmm2
000079f4d2ddf4e9  mulpd xmm4, xmm9
000079f4d2ddf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000079f4d2ddf4f3  ptest xmm1, xmm1
000079f4d2ddf4f8  jnz 0x000079F4D2DE2015
000079f4d2ddf4fe  vmovaps xmm1, [rsp+0x30]
000079f4d2ddf504  vpermilpd xmm1, xmm1, 0x00
000079f4d2ddf50a  vmovaps xmm2, [rsp+0x90]
000079f4d2ddf513  vmovaps [rsp+0x60], xmm15
000079f4d2ddf519  movaps xmm9, xmm2
000079f4d2ddf51d  mulpd xmm9, xmm1
000079f4d2ddf522  vcmppd xmm15, xmm9, xmm9, 0x03
000079f4d2ddf528  ptest xmm15, xmm15
000079f4d2ddf52e  jnz 0x000079F4D2DE2156
000079f4d2ddf534  vmovaps xmm15, [rsp+0x80]
000079f4d2ddf53d  movaps xmm1, xmm15
000079f4d2ddf541  addpd xmm1, xmm6
000079f4d2ddf545  vcmppd xmm2, xmm1, xmm1, 0x03
000079f4d2ddf54a  ptest xmm2, xmm2
000079f4d2ddf54f  jnz 0x000079F4D2DE2298
000079f4d2ddf555  movaps xmm15, xmm5
000079f4d2ddf559  addpd xmm15, xmm3
000079f4d2ddf55e  vcmppd xmm6, xmm15, xmm15, 0x03
000079f4d2ddf564  ptest xmm6, xmm6
000079f4d2ddf569  jnz 0x000079F4D2DE23D9
000079f4d2ddf56f  vmovaps xmm6, [rsp+0x30]
000079f4d2ddf575  vpermilpd xmm6, xmm6, 0x00
000079f4d2ddf57b  movaps xmm5, xmm8
000079f4d2ddf57f  mulpd xmm5, xmm6
000079f4d2ddf583  vcmppd xmm3, xmm5, xmm5, 0x03
000079f4d2ddf588  ptest xmm3, xmm3
000079f4d2ddf58d  jnz 0x000079F4D2DE251B
000079f4d2ddf593  vmovaps xmm8, [rsp+0x30]
000079f4d2ddf599  vpermilpd xmm8, xmm8, 0x00
000079f4d2ddf59f  movaps xmm6, xmm10
000079f4d2ddf5a3  mulpd xmm6, xmm8
000079f4d2ddf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000079f4d2ddf5ad  ptest xmm3, xmm3
000079f4d2ddf5b2  jnz 0x000079F4D2DE265C
000079f4d2ddf5b8  vmovaps xmm8, [rsp+0x60]
000079f4d2ddf5be  movaps xmm10, xmm8
000079f4d2ddf5c2  addpd xmm10, xmm14
000079f4d2ddf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000079f4d2ddf5cd  ptest xmm3, xmm3
000079f4d2ddf5d2  jnz 0x000079F4D2DE279E
000079f4d2ddf5d8  vmovaps xmm8, [rsp+0x50]
000079f4d2ddf5de  movaps xmm14, xmm8
000079f4d2ddf5e2  addpd xmm14, xmm4
000079f4d2ddf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000079f4d2ddf5ed  ptest xmm3, xmm3
000079f4d2ddf5f2  jnz 0x000079F4D2DE28E2
000079f4d2ddf5f8  vmovaps xmm8, [rsp+0x40]
000079f4d2ddf5fe  vpermilpd xmm8, xmm8, 0x00
000079f4d2ddf604  movaps xmm4, xmm13
000079f4d2ddf608  mulpd xmm4, xmm8
000079f4d2ddf60d  vcmppd xmm3, xmm4, xmm4, 0x03
000079f4d2ddf612  ptest xmm3, xmm3
000079f4d2ddf617  jnz 0x000079F4D2DE2A25
000079f4d2ddf61d  movaps xmm13, xmm15
000079f4d2ddf621  addpd xmm13, xmm9
000079f4d2ddf626  vcmppd xmm8, xmm13, xmm13, 0x03
000079f4d2ddf62c  ptest xmm8, xmm8
000079f4d2ddf632  jnz 0x000079F4D2DE2B67
000079f4d2ddf638  movaps xmm15, xmm1
000079f4d2ddf63c  addpd xmm15, xmm5
000079f4d2ddf641  vcmppd xmm9, xmm15, xmm15, 0x03
000079f4d2ddf647  ptest xmm9, xmm9
000079f4d2ddf64d  jnz 0x000079F4D2DE2CAB
000079f4d2ddf653  vmovaps [rsp+0x30], xmm11
000079f4d2ddf659  vmovaps xmm1, [rsp+0x30]
000079f4d2ddf65f  por xmm11, xmm1
000079f4d2ddf664  movaps [r15+0x250], xmm11
000079f4d2ddf66c  vmovaps [rsp+0x30], xmm12
000079f4d2ddf672  vmovaps xmm1, [rsp+0x30]
000079f4d2ddf678  por xmm12, xmm1
000079f4d2ddf67d  movaps [r15+0x2A0], xmm12
000079f4d2ddf685  vmovaps xmm1, [rsp+0xA0]
000079f4d2ddf68e  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddf697  por xmm1, xmm11
000079f4d2ddf69c  movaps [r15+0x1D0], xmm1
000079f4d2ddf6a4  lea r12, [rax+0x40]
000079f4d2ddf6a8  movups xmm1, [r13+r12*1]
000079f4d2ddf6ae  movaps [r15+0x2C0], xmm1
000079f4d2ddf6b6  vmovaps xmm11, [rsp+0x40]
000079f4d2ddf6bc  vpermilpd xmm11, xmm11, 0x00
000079f4d2ddf6c2  vmovaps xmm8, [rsp+0xE0]
000079f4d2ddf6cb  movaps xmm9, xmm8
000079f4d2ddf6cf  mulpd xmm9, xmm11
000079f4d2ddf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000079f4d2ddf6da  ptest xmm5, xmm5
000079f4d2ddf6df  jnz 0x000079F4D2DE2DF7
000079f4d2ddf6e5  movaps xmm11, xmm10
000079f4d2ddf6e9  addpd xmm11, xmm6
000079f4d2ddf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000079f4d2ddf6f4  ptest xmm8, xmm8
000079f4d2ddf6fa  jnz 0x000079F4D2DE2F3B
000079f4d2ddf700  movaps xmm10, xmm14
000079f4d2ddf704  addpd xmm10, xmm4
000079f4d2ddf709  vcmppd xmm8, xmm10, xmm10, 0x03
000079f4d2ddf70f  ptest xmm8, xmm8
000079f4d2ddf715  jnz 0x000079F4D2DE307E
000079f4d2ddf71b  vmovaps xmm14, [rsp+0x40]
000079f4d2ddf721  vpermilpd xmm14, xmm14, 0x00
000079f4d2ddf727  movaps xmm8, xmm1
000079f4d2ddf72b  mulpd xmm8, xmm14
000079f4d2ddf730  vcmppd xmm6, xmm8, xmm8, 0x03
000079f4d2ddf736  ptest xmm6, xmm6
000079f4d2ddf73b  jnz 0x000079F4D2DE31C1
000079f4d2ddf741  movaps xmm1, [r15+0x2B0]
000079f4d2ddf749  vmovaps xmm14, [rsp+0x40]
000079f4d2ddf74f  vpermilpd xmm14, xmm14, 0x00
000079f4d2ddf755  movaps xmm6, xmm1
000079f4d2ddf758  mulpd xmm6, xmm14
000079f4d2ddf75d  vcmppd xmm5, xmm6, xmm6, 0x03
000079f4d2ddf762  ptest xmm5, xmm5
000079f4d2ddf767  jnz 0x000079F4D2DE3304
000079f4d2ddf76d  vmovaps xmm1, [rsp+0x10]
000079f4d2ddf773  vpermilpd xmm1, xmm1, 0x00
000079f4d2ddf779  movaps xmm14, xmm12
000079f4d2ddf77d  mulpd xmm14, xmm1
000079f4d2ddf782  vcmppd xmm5, xmm14, xmm14, 0x03
000079f4d2ddf788  ptest xmm5, xmm5
000079f4d2ddf78d  jnz 0x000079F4D2DE3445
000079f4d2ddf793  movaps xmm1, xmm13
000079f4d2ddf797  addpd xmm1, xmm9
000079f4d2ddf79c  vcmppd xmm12, xmm1, xmm1, 0x03
000079f4d2ddf7a1  ptest xmm12, xmm12
000079f4d2ddf7a7  jnz 0x000079F4D2DE3588
000079f4d2ddf7ad  vmovaps xmm13, [rsp+0x10]
000079f4d2ddf7b3  vpermilpd xmm13, xmm13, 0x00
000079f4d2ddf7b9  movaps xmm12, xmm7
000079f4d2ddf7bd  mulpd xmm12, xmm13
000079f4d2ddf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000079f4d2ddf7c8  ptest xmm9, xmm9
000079f4d2ddf7ce  jnz 0x000079F4D2DE36CA
000079f4d2ddf7d4  movaps xmm13, xmm15
000079f4d2ddf7d8  addpd xmm13, xmm8
000079f4d2ddf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000079f4d2ddf7e3  ptest xmm9, xmm9
000079f4d2ddf7e9  jnz 0x000079F4D2DE380D
000079f4d2ddf7ef  movaps xmm15, [r15+0x290]
000079f4d2ddf7f7  vmovaps xmm9, [rsp+0x10]
000079f4d2ddf7fd  vpermilpd xmm9, xmm9, 0x00
000079f4d2ddf803  movaps xmm8, xmm15
000079f4d2ddf807  mulpd xmm8, xmm9
000079f4d2ddf80c  vcmppd xmm7, xmm8, xmm8, 0x03
000079f4d2ddf812  ptest xmm7, xmm7
000079f4d2ddf817  jnz 0x000079F4D2DE3951
000079f4d2ddf81d  movaps xmm15, xmm11
000079f4d2ddf821  addpd xmm15, xmm6
000079f4d2ddf826  vcmppd xmm9, xmm15, xmm15, 0x03
000079f4d2ddf82c  ptest xmm9, xmm9
000079f4d2ddf832  jnz 0x000079F4D2DE3A95
000079f4d2ddf838  movaps xmm11, [r15+0x1E0]
000079f4d2ddf840  vmovaps xmm9, [rsp+0x10]
000079f4d2ddf846  vpermilpd xmm9, xmm9, 0x00
000079f4d2ddf84c  movaps xmm7, xmm11
000079f4d2ddf850  mulpd xmm7, xmm9
000079f4d2ddf855  vcmppd xmm6, xmm7, xmm7, 0x03
000079f4d2ddf85a  ptest xmm6, xmm6
000079f4d2ddf85f  jnz 0x000079F4D2DE3BD8
000079f4d2ddf865  movaps xmm11, xmm10
000079f4d2ddf869  addpd xmm11, xmm14
000079f4d2ddf86e  vcmppd xmm9, xmm11, xmm11, 0x03
000079f4d2ddf874  ptest xmm9, xmm9
000079f4d2ddf87a  jnz 0x000079F4D2DE3D1A
000079f4d2ddf880  lea r12, [rax+0x70]
000079f4d2ddf884  movups xmm14, [r13+r12*1]
000079f4d2ddf88a  movaps [r15+0x240], xmm14
000079f4d2ddf892  movaps xmm10, xmm1
000079f4d2ddf896  addpd xmm10, xmm12
000079f4d2ddf89b  vcmppd xmm9, xmm10, xmm10, 0x03
000079f4d2ddf8a1  ptest xmm9, xmm9
000079f4d2ddf8a7  jnz 0x000079F4D2DE3E68
000079f4d2ddf8ad  movaps [r15+0x170], xmm10
000079f4d2ddf8b5  vmovaps xmm1, [rsp+0x20]
000079f4d2ddf8bb  vpermilpd xmm1, xmm1, 0x00
000079f4d2ddf8c1  movaps xmm12, xmm14
000079f4d2ddf8c5  mulpd xmm12, xmm1
000079f4d2ddf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000079f4d2ddf8d0  ptest xmm9, xmm9
000079f4d2ddf8d6  jnz 0x000079F4D2DE3FAB
000079f4d2ddf8dc  vmovaps xmm1, [rsp+0x20]
000079f4d2ddf8e2  vpermilpd xmm1, xmm1, 0x00
000079f4d2ddf8e8  vmovaps xmm9, [rsp+0xB0]
000079f4d2ddf8f1  movaps xmm14, xmm9
000079f4d2ddf8f5  mulpd xmm14, xmm1
000079f4d2ddf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000079f4d2ddf900  ptest xmm6, xmm6
000079f4d2ddf905  jnz 0x000079F4D2DE40EE
000079f4d2ddf90b  movaps [r15+0x180], xmm14
000079f4d2ddf913  movaps xmm1, xmm13
000079f4d2ddf917  addpd xmm1, xmm8
000079f4d2ddf91c  vcmppd xmm9, xmm1, xmm1, 0x03
000079f4d2ddf921  ptest xmm9, xmm9
000079f4d2ddf927  jnz 0x000079F4D2DE4231
000079f4d2ddf92d  movaps [r15+0x210], xmm1
000079f4d2ddf935  movups xmm13, [r13+rax*1]
000079f4d2ddf93b  lea r12, [rax+0x10]
000079f4d2ddf93f  movups xmm9, [r13+r12*1]
000079f4d2ddf945  movaps [r15+0x230], xmm9
000079f4d2ddf94d  movaps xmm8, xmm15
000079f4d2ddf951  addpd xmm8, xmm7
000079f4d2ddf956  vcmppd xmm6, xmm8, xmm8, 0x03
000079f4d2ddf95c  ptest xmm6, xmm6
000079f4d2ddf961  jnz 0x000079F4D2DE4387
000079f4d2ddf967  movaps [r15+0x130], xmm8
000079f4d2ddf96f  vmovaps xmm15, [rsp+0x20]
000079f4d2ddf975  vpermilpd xmm15, xmm15, 0x00
000079f4d2ddf97b  movaps xmm7, xmm9
000079f4d2ddf97f  mulpd xmm7, xmm15
000079f4d2ddf984  vcmppd xmm6, xmm7, xmm7, 0x03
000079f4d2ddf989  ptest xmm6, xmm6
000079f4d2ddf98e  jnz 0x000079F4D2DE44CA
000079f4d2ddf994  movaps [r15+0x220], xmm7
000079f4d2ddf99c  vmovaps xmm15, [rsp+0x20]
000079f4d2ddf9a2  vpermilpd xmm15, xmm15, 0x00
000079f4d2ddf9a8  movaps xmm9, xmm13
000079f4d2ddf9ac  mulpd xmm9, xmm15
000079f4d2ddf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000079f4d2ddf9b7  ptest xmm6, xmm6
000079f4d2ddf9bc  jnz 0x000079F4D2DE460C
000079f4d2ddf9c2  movaps xmm15, xmm11
000079f4d2ddf9c6  addpd xmm15, xmm12
000079f4d2ddf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000079f4d2ddf9d1  ptest xmm13, xmm13
000079f4d2ddf9d7  jnz 0x000079F4D2DE4750
000079f4d2ddf9dd  movaps [r15+0x140], xmm15
000079f4d2ddf9e5  movaps xmm13, xmm10
000079f4d2ddf9e9  addpd xmm13, xmm14
000079f4d2ddf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000079f4d2ddf9f4  ptest xmm12, xmm12
000079f4d2ddf9fa  jnz 0x000079F4D2DE4894
000079f4d2ddfa00  movaps [r15+0x150], xmm13
000079f4d2ddfa08  movaps xmm14, xmm1
000079f4d2ddfa0c  addpd xmm14, xmm7
000079f4d2ddfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000079f4d2ddfa17  ptest xmm12, xmm12
000079f4d2ddfa1d  jnz 0x000079F4D2DE49D8
000079f4d2ddfa23  movaps [r15+0x160], xmm14
000079f4d2ddfa2b  movaps xmm1, xmm8
000079f4d2ddfa2f  addpd xmm1, xmm9
000079f4d2ddfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000079f4d2ddfa39  ptest xmm12, xmm12
000079f4d2ddfa3f  jnz 0x000079F4D2DE4B1A
000079f4d2ddfa45  movaps [r15+0x120], xmm1
000079f4d2ddfa4d  movups [r13+r14*1], xmm15
000079f4d2ddfa53  lea rax, [r14+0x10]
000079f4d2ddfa57  movups [r13+rax*1], xmm13
000079f4d2ddfa5d  lea rax, [r14+0x20]
000079f4d2ddfa61  movups [r13+rax*1], xmm14
000079f4d2ddfa67  lea rax, [r14+0x30]
000079f4d2ddfa6b  movups [r13+rax*1], xmm1
000079f4d2ddfa71  mov eax, [r15+0x108]
000079f4d2ddfa78  sahf
000079f4d2ddfa79  jnz 0x000079F4D2DDFAAB
000079f4d2ddfa7b  cmp dword ptr [r15+0x318], 0x00
000079f4d2ddfa83  jz 0x000079F4D2DDEAE0
000079f4d2ddfa89  nop [rax+rax*1], ax
000079f4d2ddfa92  nop [rax+rax*1], eax
000079f4d2ddfa9a  mov eax, 0x4106D0
000079f4d2ddfa9f  mov [r15+0x100], rax
000079f4d2ddfaa6  jmp 0x000079F4D2BFE110
000079f4d2ddfaab  cmp dword ptr [r15+0x318], 0x00
000079f4d2ddfab3  jz 0x000079F4D2DD89C0
000079f4d2ddfab9  nop [rax+rax*1], ax
000079f4d2ddfac2  nop [rax+rax*1], eax
000079f4d2ddfaca  mov eax, 0x410504
000079f4d2ddfacf  mov [r15+0x100], rax
000079f4d2ddfad6  jmp 0x000079F4D2BFE110
000079f4d2ddfadb  int3
000079f4d2ddfadc  call 0x000079F4D2CE27E0
000079f4d2ddfae1  jmp 0x000079F4D2DDEBBF
000079f4d2ddfae6  call 0x000079F4D2CE1570
000079f4d2ddfaeb  jmp 0x000079F4D2DDEBC8
000079f4d2ddfaf0  call 0x000079F4D2CE27E0
000079f4d2ddfaf5  jmp 0x000079F4D2DDEC24
000079f4d2ddfafa  call 0x000079F4D2CE1570
000079f4d2ddfaff  jmp 0x000079F4D2DDEC2D
000079f4d2ddfb04  call 0x000079F4D2CE27E0
000079f4d2ddfb09  jmp 0x000079F4D2DDEC70
000079f4d2ddfb0e  call 0x000079F4D2CE1570
000079f4d2ddfb13  jmp 0x000079F4D2DDEC79
000079f4d2ddfb18  call 0x000079F4D2C0DC20
000079f4d2ddfb1d  jmp 0x000079F4D2DDECB8
000079f4d2ddfb22  call 0x000079F4D2CD59C0
000079f4d2ddfb27  jmp 0x000079F4D2DDECCB
000079f4d2ddfb2c  call 0x000079F4D2CE0E30
000079f4d2ddfb31  jmp 0x000079F4D2DDECE9
000079f4d2ddfb36  call 0x000079F4D2CDFBC0
000079f4d2ddfb3b  jmp 0x000079F4D2DDECF3
000079f4d2ddfb40  call 0x000079F4D2CDE950
000079f4d2ddfb45  jmp 0x000079F4D2DDECFD
000079f4d2ddfb4a  sub rsp, 0x08
000079f4d2ddfb4e  push rax
000079f4d2ddfb4f  push rcx
000079f4d2ddfb50  push rdx
000079f4d2ddfb51  push rdi
000079f4d2ddfb52  push rsi
000079f4d2ddfb53  push r8
000079f4d2ddfb55  push r9
000079f4d2ddfb57  push r10
000079f4d2ddfb59  push r11
000079f4d2ddfb5b  sub rsp, 0xF0
000079f4d2ddfb62  vmovaps [rsp], xmm0
000079f4d2ddfb67  vmovaps [rsp+0x10], xmm1
000079f4d2ddfb6d  vmovaps [rsp+0x20], xmm2
000079f4d2ddfb73  vmovaps [rsp+0x30], xmm3
000079f4d2ddfb79  vmovaps [rsp+0x40], xmm4
000079f4d2ddfb7f  vmovaps [rsp+0x50], xmm5
000079f4d2ddfb85  vmovaps [rsp+0x60], xmm6
000079f4d2ddfb8b  vmovaps [rsp+0x70], xmm7
000079f4d2ddfb91  vmovaps [rsp+0x80], xmm9
000079f4d2ddfb9a  vmovaps [rsp+0x90], xmm10
000079f4d2ddfba3  vmovaps [rsp+0xA0], xmm11
000079f4d2ddfbac  vmovaps [rsp+0xB0], xmm12
000079f4d2ddfbb5  vmovaps [rsp+0xC0], xmm13
000079f4d2ddfbbe  vmovaps [rsp+0xD0], xmm14
000079f4d2ddfbc7  vmovaps [rsp+0xE0], xmm15
000079f4d2ddfbd0  sub rsp, 0x30
000079f4d2ddfbd4  movaps [rsp], xmm8
000079f4d2ddfbd9  movaps [rsp+0x10], xmm12
000079f4d2ddfbdf  movaps [rsp+0x20], xmm15
000079f4d2ddfbe5  lea rdi, [rsp]
000079f4d2ddfbe9  mov esi, 0x00
000079f4d2ddfbee  mov rax, 0x5D9EC01E8530
000079f4d2ddfbf8  call rax
000079f4d2ddfbfa  movaps xmm8, [rsp]
000079f4d2ddfbff  add rsp, 0x30
000079f4d2ddfc03  vmovaps xmm0, [rsp]
000079f4d2ddfc08  vmovaps xmm1, [rsp+0x10]
000079f4d2ddfc0e  vmovaps xmm2, [rsp+0x20]
000079f4d2ddfc14  vmovaps xmm3, [rsp+0x30]
000079f4d2ddfc1a  vmovaps xmm4, [rsp+0x40]
000079f4d2ddfc20  vmovaps xmm5, [rsp+0x50]
000079f4d2ddfc26  vmovaps xmm6, [rsp+0x60]
000079f4d2ddfc2c  vmovaps xmm7, [rsp+0x70]
000079f4d2ddfc32  vmovaps xmm9, [rsp+0x80]
000079f4d2ddfc3b  vmovaps xmm10, [rsp+0x90]
000079f4d2ddfc44  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddfc4d  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddfc56  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddfc5f  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddfc68  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddfc71  add rsp, 0xF0
000079f4d2ddfc78  pop r11
000079f4d2ddfc7a  pop r10
000079f4d2ddfc7c  pop r9
000079f4d2ddfc7e  pop r8
000079f4d2ddfc80  pop rsi
000079f4d2ddfc81  pop rdi
000079f4d2ddfc82  pop rdx
000079f4d2ddfc83  pop rcx
000079f4d2ddfc84  pop rax
000079f4d2ddfc85  add rsp, 0x08
000079f4d2ddfc89  jmp 0x000079F4D2DDED27
000079f4d2ddfc8e  sub rsp, 0x08
000079f4d2ddfc92  push rax
000079f4d2ddfc93  push rcx
000079f4d2ddfc94  push rdx
000079f4d2ddfc95  push rdi
000079f4d2ddfc96  push rsi
000079f4d2ddfc97  push r8
000079f4d2ddfc99  push r9
000079f4d2ddfc9b  push r10
000079f4d2ddfc9d  push r11
000079f4d2ddfc9f  sub rsp, 0xF0
000079f4d2ddfca6  vmovaps [rsp], xmm0
000079f4d2ddfcab  vmovaps [rsp+0x10], xmm1
000079f4d2ddfcb1  vmovaps [rsp+0x20], xmm2
000079f4d2ddfcb7  vmovaps [rsp+0x30], xmm3
000079f4d2ddfcbd  vmovaps [rsp+0x40], xmm4
000079f4d2ddfcc3  vmovaps [rsp+0x50], xmm5
000079f4d2ddfcc9  vmovaps [rsp+0x60], xmm6
000079f4d2ddfccf  vmovaps [rsp+0x70], xmm8
000079f4d2ddfcd5  vmovaps [rsp+0x80], xmm9
000079f4d2ddfcde  vmovaps [rsp+0x90], xmm10
000079f4d2ddfce7  vmovaps [rsp+0xA0], xmm11
000079f4d2ddfcf0  vmovaps [rsp+0xB0], xmm12
000079f4d2ddfcf9  vmovaps [rsp+0xC0], xmm13
000079f4d2ddfd02  vmovaps [rsp+0xD0], xmm14
000079f4d2ddfd0b  vmovaps [rsp+0xE0], xmm15
000079f4d2ddfd14  sub rsp, 0x30
000079f4d2ddfd18  movaps [rsp], xmm7
000079f4d2ddfd1c  movaps [rsp+0x10], xmm9
000079f4d2ddfd22  movaps [rsp+0x20], xmm15
000079f4d2ddfd28  lea rdi, [rsp]
000079f4d2ddfd2c  mov esi, 0x00
000079f4d2ddfd31  mov rax, 0x5D9EC01E8530
000079f4d2ddfd3b  call rax
000079f4d2ddfd3d  movaps xmm7, [rsp]
000079f4d2ddfd41  add rsp, 0x30
000079f4d2ddfd45  vmovaps xmm0, [rsp]
000079f4d2ddfd4a  vmovaps xmm1, [rsp+0x10]
000079f4d2ddfd50  vmovaps xmm2, [rsp+0x20]
000079f4d2ddfd56  vmovaps xmm3, [rsp+0x30]
000079f4d2ddfd5c  vmovaps xmm4, [rsp+0x40]
000079f4d2ddfd62  vmovaps xmm5, [rsp+0x50]
000079f4d2ddfd68  vmovaps xmm6, [rsp+0x60]
000079f4d2ddfd6e  vmovaps xmm8, [rsp+0x70]
000079f4d2ddfd74  vmovaps xmm9, [rsp+0x80]
000079f4d2ddfd7d  vmovaps xmm10, [rsp+0x90]
000079f4d2ddfd86  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddfd8f  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddfd98  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddfda1  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddfdaa  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddfdb3  add rsp, 0xF0
000079f4d2ddfdba  pop r11
000079f4d2ddfdbc  pop r10
000079f4d2ddfdbe  pop r9
000079f4d2ddfdc0  pop r8
000079f4d2ddfdc2  pop rsi
000079f4d2ddfdc3  pop rdi
000079f4d2ddfdc4  pop rdx
000079f4d2ddfdc5  pop rcx
000079f4d2ddfdc6  pop rax
000079f4d2ddfdc7  add rsp, 0x08
000079f4d2ddfdcb  jmp 0x000079F4D2DDED55
000079f4d2ddfdd0  sub rsp, 0x08
000079f4d2ddfdd4  push rax
000079f4d2ddfdd5  push rcx
000079f4d2ddfdd6  push rdx
000079f4d2ddfdd7  push rdi
000079f4d2ddfdd8  push rsi
000079f4d2ddfdd9  push r8
000079f4d2ddfddb  push r9
000079f4d2ddfddd  push r10
000079f4d2ddfddf  push r11
000079f4d2ddfde1  sub rsp, 0xF0
000079f4d2ddfde8  vmovaps [rsp], xmm0
000079f4d2ddfded  vmovaps [rsp+0x10], xmm1
000079f4d2ddfdf3  vmovaps [rsp+0x20], xmm2
000079f4d2ddfdf9  vmovaps [rsp+0x30], xmm3
000079f4d2ddfdff  vmovaps [rsp+0x40], xmm4
000079f4d2ddfe05  vmovaps [rsp+0x50], xmm5
000079f4d2ddfe0b  vmovaps [rsp+0x60], xmm6
000079f4d2ddfe11  vmovaps [rsp+0x70], xmm7
000079f4d2ddfe17  vmovaps [rsp+0x80], xmm8
000079f4d2ddfe20  vmovaps [rsp+0x90], xmm10
000079f4d2ddfe29  vmovaps [rsp+0xA0], xmm11
000079f4d2ddfe32  vmovaps [rsp+0xB0], xmm12
000079f4d2ddfe3b  vmovaps [rsp+0xC0], xmm13
000079f4d2ddfe44  vmovaps [rsp+0xD0], xmm14
000079f4d2ddfe4d  vmovaps [rsp+0xE0], xmm15
000079f4d2ddfe56  sub rsp, 0x30
000079f4d2ddfe5a  movaps [rsp], xmm9
000079f4d2ddfe5f  movaps [rsp+0x10], xmm12
000079f4d2ddfe65  movaps [rsp+0x20], xmm10
000079f4d2ddfe6b  lea rdi, [rsp]
000079f4d2ddfe6f  mov esi, 0x00
000079f4d2ddfe74  mov rax, 0x5D9EC01E8530
000079f4d2ddfe7e  call rax
000079f4d2ddfe80  movaps xmm9, [rsp]
000079f4d2ddfe85  add rsp, 0x30
000079f4d2ddfe89  vmovaps xmm0, [rsp]
000079f4d2ddfe8e  vmovaps xmm1, [rsp+0x10]
000079f4d2ddfe94  vmovaps xmm2, [rsp+0x20]
000079f4d2ddfe9a  vmovaps xmm3, [rsp+0x30]
000079f4d2ddfea0  vmovaps xmm4, [rsp+0x40]
000079f4d2ddfea6  vmovaps xmm5, [rsp+0x50]
000079f4d2ddfeac  vmovaps xmm6, [rsp+0x60]
000079f4d2ddfeb2  vmovaps xmm7, [rsp+0x70]
000079f4d2ddfeb8  vmovaps xmm8, [rsp+0x80]
000079f4d2ddfec1  vmovaps xmm10, [rsp+0x90]
000079f4d2ddfeca  vmovaps xmm11, [rsp+0xA0]
000079f4d2ddfed3  vmovaps xmm12, [rsp+0xB0]
000079f4d2ddfedc  vmovaps xmm13, [rsp+0xC0]
000079f4d2ddfee5  vmovaps xmm14, [rsp+0xD0]
000079f4d2ddfeee  vmovaps xmm15, [rsp+0xE0]
000079f4d2ddfef7  add rsp, 0xF0
000079f4d2ddfefe  pop r11
000079f4d2ddff00  pop r10
000079f4d2ddff02  pop r9
000079f4d2ddff04  pop r8
000079f4d2ddff06  pop rsi
000079f4d2ddff07  pop rdi
000079f4d2ddff08  pop rdx
000079f4d2ddff09  pop rcx
000079f4d2ddff0a  pop rax
000079f4d2ddff0b  add rsp, 0x08
000079f4d2ddff0f  jmp 0x000079F4D2DDED79
000079f4d2ddff14  sub rsp, 0x08
000079f4d2ddff18  push rax
000079f4d2ddff19  push rcx
000079f4d2ddff1a  push rdx
000079f4d2ddff1b  push rdi
000079f4d2ddff1c  push rsi
000079f4d2ddff1d  push r8
000079f4d2ddff1f  push r9
000079f4d2ddff21  push r10
000079f4d2ddff23  push r11
000079f4d2ddff25  sub rsp, 0xF0
000079f4d2ddff2c  vmovaps [rsp], xmm0
000079f4d2ddff31  vmovaps [rsp+0x10], xmm1
000079f4d2ddff37  vmovaps [rsp+0x20], xmm2
000079f4d2ddff3d  vmovaps [rsp+0x30], xmm3
000079f4d2ddff43  vmovaps [rsp+0x40], xmm4
000079f4d2ddff49  vmovaps [rsp+0x50], xmm5
000079f4d2ddff4f  vmovaps [rsp+0x60], xmm6
000079f4d2ddff55  vmovaps [rsp+0x70], xmm7
000079f4d2ddff5b  vmovaps [rsp+0x80], xmm8
000079f4d2ddff64  vmovaps [rsp+0x90], xmm9
000079f4d2ddff6d  vmovaps [rsp+0xA0], xmm11
000079f4d2ddff76  vmovaps [rsp+0xB0], xmm12
000079f4d2ddff7f  vmovaps [rsp+0xC0], xmm13
000079f4d2ddff88  vmovaps [rsp+0xD0], xmm14
000079f4d2ddff91  vmovaps [rsp+0xE0], xmm15
000079f4d2ddff9a  sub rsp, 0x30
000079f4d2ddff9e  movaps [rsp], xmm10
000079f4d2ddffa3  movaps [rsp+0x10], xmm12
000079f4d2ddffa9  movaps [rsp+0x20], xmm11
000079f4d2ddffaf  lea rdi, [rsp]
000079f4d2ddffb3  mov esi, 0x00
000079f4d2ddffb8  mov rax, 0x5D9EC01E8530
000079f4d2ddffc2  call rax
000079f4d2ddffc4  movaps xmm10, [rsp]
000079f4d2ddffc9  add rsp, 0x30
000079f4d2ddffcd  vmovaps xmm0, [rsp]
000079f4d2ddffd2  vmovaps xmm1, [rsp+0x10]
000079f4d2ddffd8  vmovaps xmm2, [rsp+0x20]
000079f4d2ddffde  vmovaps xmm3, [rsp+0x30]
000079f4d2ddffe4  vmovaps xmm4, [rsp+0x40]
000079f4d2ddffea  vmovaps xmm5, [rsp+0x50]
000079f4d2ddfff0  vmovaps xmm6, [rsp+0x60]
000079f4d2ddfff6  vmovaps xmm7, [rsp+0x70]
000079f4d2ddfffc  vmovaps xmm8, [rsp+0x80]
000079f4d2de0005  vmovaps xmm9, [rsp+0x90]
000079f4d2de000e  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0017  vmovaps xmm12, [rsp+0xB0]
000079f4d2de0020  vmovaps xmm13, [rsp+0xC0]
000079f4d2de0029  vmovaps xmm14, [rsp+0xD0]
000079f4d2de0032  vmovaps xmm15, [rsp+0xE0]
000079f4d2de003b  add rsp, 0xF0
000079f4d2de0042  pop r11
000079f4d2de0044  pop r10
000079f4d2de0046  pop r9
000079f4d2de0048  pop r8
000079f4d2de004a  pop rsi
000079f4d2de004b  pop rdi
000079f4d2de004c  pop rdx
000079f4d2de004d  pop rcx
000079f4d2de004e  pop rax
000079f4d2de004f  add rsp, 0x08
000079f4d2de0053  jmp 0x000079F4D2DDED93
000079f4d2de0058  sub rsp, 0x08
000079f4d2de005c  push rax
000079f4d2de005d  push rcx
000079f4d2de005e  push rdx
000079f4d2de005f  push rdi
000079f4d2de0060  push rsi
000079f4d2de0061  push r8
000079f4d2de0063  push r9
000079f4d2de0065  push r10
000079f4d2de0067  push r11
000079f4d2de0069  sub rsp, 0xF0
000079f4d2de0070  vmovaps [rsp], xmm0
000079f4d2de0075  vmovaps [rsp+0x10], xmm1
000079f4d2de007b  vmovaps [rsp+0x20], xmm2
000079f4d2de0081  vmovaps [rsp+0x30], xmm3
000079f4d2de0087  vmovaps [rsp+0x40], xmm4
000079f4d2de008d  vmovaps [rsp+0x50], xmm5
000079f4d2de0093  vmovaps [rsp+0x60], xmm7
000079f4d2de0099  vmovaps [rsp+0x70], xmm8
000079f4d2de009f  vmovaps [rsp+0x80], xmm9
000079f4d2de00a8  vmovaps [rsp+0x90], xmm10
000079f4d2de00b1  vmovaps [rsp+0xA0], xmm11
000079f4d2de00ba  vmovaps [rsp+0xB0], xmm12
000079f4d2de00c3  vmovaps [rsp+0xC0], xmm13
000079f4d2de00cc  vmovaps [rsp+0xD0], xmm14
000079f4d2de00d5  vmovaps [rsp+0xE0], xmm15
000079f4d2de00de  sub rsp, 0x30
000079f4d2de00e2  movaps [rsp], xmm6
000079f4d2de00e6  movaps [rsp+0x10], xmm12
000079f4d2de00ec  movaps [rsp+0x20], xmm11
000079f4d2de00f2  lea rdi, [rsp]
000079f4d2de00f6  mov esi, 0x00
000079f4d2de00fb  mov rax, 0x5D9EC01E8530
000079f4d2de0105  call rax
000079f4d2de0107  movaps xmm6, [rsp]
000079f4d2de010b  add rsp, 0x30
000079f4d2de010f  vmovaps xmm0, [rsp]
000079f4d2de0114  vmovaps xmm1, [rsp+0x10]
000079f4d2de011a  vmovaps xmm2, [rsp+0x20]
000079f4d2de0120  vmovaps xmm3, [rsp+0x30]
000079f4d2de0126  vmovaps xmm4, [rsp+0x40]
000079f4d2de012c  vmovaps xmm5, [rsp+0x50]
000079f4d2de0132  vmovaps xmm7, [rsp+0x60]
000079f4d2de0138  vmovaps xmm8, [rsp+0x70]
000079f4d2de013e  vmovaps xmm9, [rsp+0x80]
000079f4d2de0147  vmovaps xmm10, [rsp+0x90]
000079f4d2de0150  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0159  vmovaps xmm12, [rsp+0xB0]
000079f4d2de0162  vmovaps xmm13, [rsp+0xC0]
000079f4d2de016b  vmovaps xmm14, [rsp+0xD0]
000079f4d2de0174  vmovaps xmm15, [rsp+0xE0]
000079f4d2de017d  add rsp, 0xF0
000079f4d2de0184  pop r11
000079f4d2de0186  pop r10
000079f4d2de0188  pop r9
000079f4d2de018a  pop r8
000079f4d2de018c  pop rsi
000079f4d2de018d  pop rdi
000079f4d2de018e  pop rdx
000079f4d2de018f  pop rcx
000079f4d2de0190  pop rax
000079f4d2de0191  add rsp, 0x08
000079f4d2de0195  jmp 0x000079F4D2DDEDB4
000079f4d2de019a  sub rsp, 0x08
000079f4d2de019e  push rax
000079f4d2de019f  push rcx
000079f4d2de01a0  push rdx
000079f4d2de01a1  push rdi
000079f4d2de01a2  push rsi
000079f4d2de01a3  push r8
000079f4d2de01a5  push r9
000079f4d2de01a7  push r10
000079f4d2de01a9  push r11
000079f4d2de01ab  sub rsp, 0xF0
000079f4d2de01b2  vmovaps [rsp], xmm0
000079f4d2de01b7  vmovaps [rsp+0x10], xmm1
000079f4d2de01bd  vmovaps [rsp+0x20], xmm2
000079f4d2de01c3  vmovaps [rsp+0x30], xmm4
000079f4d2de01c9  vmovaps [rsp+0x40], xmm5
000079f4d2de01cf  vmovaps [rsp+0x50], xmm6
000079f4d2de01d5  vmovaps [rsp+0x60], xmm7
000079f4d2de01db  vmovaps [rsp+0x70], xmm8
000079f4d2de01e1  vmovaps [rsp+0x80], xmm9
000079f4d2de01ea  vmovaps [rsp+0x90], xmm10
000079f4d2de01f3  vmovaps [rsp+0xA0], xmm11
000079f4d2de01fc  vmovaps [rsp+0xB0], xmm12
000079f4d2de0205  vmovaps [rsp+0xC0], xmm13
000079f4d2de020e  vmovaps [rsp+0xD0], xmm14
000079f4d2de0217  vmovaps [rsp+0xE0], xmm15
000079f4d2de0220  sub rsp, 0x30
000079f4d2de0224  movaps [rsp], xmm3
000079f4d2de0228  movaps [rsp+0x10], xmm5
000079f4d2de022d  movaps [rsp+0x20], xmm4
000079f4d2de0232  lea rdi, [rsp]
000079f4d2de0236  mov esi, 0x00
000079f4d2de023b  mov rax, 0x5D9EC01E8530
000079f4d2de0245  call rax
000079f4d2de0247  movaps xmm3, [rsp]
000079f4d2de024b  add rsp, 0x30
000079f4d2de024f  vmovaps xmm0, [rsp]
000079f4d2de0254  vmovaps xmm1, [rsp+0x10]
000079f4d2de025a  vmovaps xmm2, [rsp+0x20]
000079f4d2de0260  vmovaps xmm4, [rsp+0x30]
000079f4d2de0266  vmovaps xmm5, [rsp+0x40]
000079f4d2de026c  vmovaps xmm6, [rsp+0x50]
000079f4d2de0272  vmovaps xmm7, [rsp+0x60]
000079f4d2de0278  vmovaps xmm8, [rsp+0x70]
000079f4d2de027e  vmovaps xmm9, [rsp+0x80]
000079f4d2de0287  vmovaps xmm10, [rsp+0x90]
000079f4d2de0290  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0299  vmovaps xmm12, [rsp+0xB0]
000079f4d2de02a2  vmovaps xmm13, [rsp+0xC0]
000079f4d2de02ab  vmovaps xmm14, [rsp+0xD0]
000079f4d2de02b4  vmovaps xmm15, [rsp+0xE0]
000079f4d2de02bd  add rsp, 0xF0
000079f4d2de02c4  pop r11
000079f4d2de02c6  pop r10
000079f4d2de02c8  pop r9
000079f4d2de02ca  pop r8
000079f4d2de02cc  pop rsi
000079f4d2de02cd  pop rdi
000079f4d2de02ce  pop rdx
000079f4d2de02cf  pop rcx
000079f4d2de02d0  pop rax
000079f4d2de02d1  add rsp, 0x08
000079f4d2de02d5  jmp 0x000079F4D2DDEE15
000079f4d2de02da  sub rsp, 0x08
000079f4d2de02de  push rax
000079f4d2de02df  push rcx
000079f4d2de02e0  push rdx
000079f4d2de02e1  push rdi
000079f4d2de02e2  push rsi
000079f4d2de02e3  push r8
000079f4d2de02e5  push r9
000079f4d2de02e7  push r10
000079f4d2de02e9  push r11
000079f4d2de02eb  sub rsp, 0xF0
000079f4d2de02f2  vmovaps [rsp], xmm0
000079f4d2de02f7  vmovaps [rsp+0x10], xmm1
000079f4d2de02fd  vmovaps [rsp+0x20], xmm2
000079f4d2de0303  vmovaps [rsp+0x30], xmm3
000079f4d2de0309  vmovaps [rsp+0x40], xmm4
000079f4d2de030f  vmovaps [rsp+0x50], xmm6
000079f4d2de0315  vmovaps [rsp+0x60], xmm7
000079f4d2de031b  vmovaps [rsp+0x70], xmm8
000079f4d2de0321  vmovaps [rsp+0x80], xmm9
000079f4d2de032a  vmovaps [rsp+0x90], xmm10
000079f4d2de0333  vmovaps [rsp+0xA0], xmm11
000079f4d2de033c  vmovaps [rsp+0xB0], xmm12
000079f4d2de0345  vmovaps [rsp+0xC0], xmm13
000079f4d2de034e  vmovaps [rsp+0xD0], xmm14
000079f4d2de0357  vmovaps [rsp+0xE0], xmm15
000079f4d2de0360  sub rsp, 0x30
000079f4d2de0364  movaps [rsp], xmm5
000079f4d2de0368  movaps [rsp+0x10], xmm8
000079f4d2de036e  movaps [rsp+0x20], xmm15
000079f4d2de0374  lea rdi, [rsp]
000079f4d2de0378  mov esi, 0x00
000079f4d2de037d  mov rax, 0x5D9EC01E8530
000079f4d2de0387  call rax
000079f4d2de0389  movaps xmm5, [rsp]
000079f4d2de038d  add rsp, 0x30
000079f4d2de0391  vmovaps xmm0, [rsp]
000079f4d2de0396  vmovaps xmm1, [rsp+0x10]
000079f4d2de039c  vmovaps xmm2, [rsp+0x20]
000079f4d2de03a2  vmovaps xmm3, [rsp+0x30]
000079f4d2de03a8  vmovaps xmm4, [rsp+0x40]
000079f4d2de03ae  vmovaps xmm6, [rsp+0x50]
000079f4d2de03b4  vmovaps xmm7, [rsp+0x60]
000079f4d2de03ba  vmovaps xmm8, [rsp+0x70]
000079f4d2de03c0  vmovaps xmm9, [rsp+0x80]
000079f4d2de03c9  vmovaps xmm10, [rsp+0x90]
000079f4d2de03d2  vmovaps xmm11, [rsp+0xA0]
000079f4d2de03db  vmovaps xmm12, [rsp+0xB0]
000079f4d2de03e4  vmovaps xmm13, [rsp+0xC0]
000079f4d2de03ed  vmovaps xmm14, [rsp+0xD0]
000079f4d2de03f6  vmovaps xmm15, [rsp+0xE0]
000079f4d2de03ff  add rsp, 0xF0
000079f4d2de0406  pop r11
000079f4d2de0408  pop r10
000079f4d2de040a  pop r9
000079f4d2de040c  pop r8
000079f4d2de040e  pop rsi
000079f4d2de040f  pop rdi
000079f4d2de0410  pop rdx
000079f4d2de0411  pop rcx
000079f4d2de0412  pop rax
000079f4d2de0413  add rsp, 0x08
000079f4d2de0417  jmp 0x000079F4D2DDEE53
000079f4d2de041c  sub rsp, 0x08
000079f4d2de0420  push rax
000079f4d2de0421  push rcx
000079f4d2de0422  push rdx
000079f4d2de0423  push rdi
000079f4d2de0424  push rsi
000079f4d2de0425  push r8
000079f4d2de0427  push r9
000079f4d2de0429  push r10
000079f4d2de042b  push r11
000079f4d2de042d  sub rsp, 0xF0
000079f4d2de0434  vmovaps [rsp], xmm0
000079f4d2de0439  vmovaps [rsp+0x10], xmm1
000079f4d2de043f  vmovaps [rsp+0x20], xmm2
000079f4d2de0445  vmovaps [rsp+0x30], xmm3
000079f4d2de044b  vmovaps [rsp+0x40], xmm5
000079f4d2de0451  vmovaps [rsp+0x50], xmm6
000079f4d2de0457  vmovaps [rsp+0x60], xmm7
000079f4d2de045d  vmovaps [rsp+0x70], xmm8
000079f4d2de0463  vmovaps [rsp+0x80], xmm9
000079f4d2de046c  vmovaps [rsp+0x90], xmm10
000079f4d2de0475  vmovaps [rsp+0xA0], xmm11
000079f4d2de047e  vmovaps [rsp+0xB0], xmm12
000079f4d2de0487  vmovaps [rsp+0xC0], xmm13
000079f4d2de0490  vmovaps [rsp+0xD0], xmm14
000079f4d2de0499  vmovaps [rsp+0xE0], xmm15
000079f4d2de04a2  sub rsp, 0x30
000079f4d2de04a6  movaps [rsp], xmm4
000079f4d2de04aa  movaps [rsp+0x10], xmm9
000079f4d2de04b0  movaps [rsp+0x20], xmm8
000079f4d2de04b6  lea rdi, [rsp]
000079f4d2de04ba  mov esi, 0x00
000079f4d2de04bf  mov rax, 0x5D9EC01E8530
000079f4d2de04c9  call rax
000079f4d2de04cb  movaps xmm4, [rsp]
000079f4d2de04cf  add rsp, 0x30
000079f4d2de04d3  vmovaps xmm0, [rsp]
000079f4d2de04d8  vmovaps xmm1, [rsp+0x10]
000079f4d2de04de  vmovaps xmm2, [rsp+0x20]
000079f4d2de04e4  vmovaps xmm3, [rsp+0x30]
000079f4d2de04ea  vmovaps xmm5, [rsp+0x40]
000079f4d2de04f0  vmovaps xmm6, [rsp+0x50]
000079f4d2de04f6  vmovaps xmm7, [rsp+0x60]
000079f4d2de04fc  vmovaps xmm8, [rsp+0x70]
000079f4d2de0502  vmovaps xmm9, [rsp+0x80]
000079f4d2de050b  vmovaps xmm10, [rsp+0x90]
000079f4d2de0514  vmovaps xmm11, [rsp+0xA0]
000079f4d2de051d  vmovaps xmm12, [rsp+0xB0]
000079f4d2de0526  vmovaps xmm13, [rsp+0xC0]
000079f4d2de052f  vmovaps xmm14, [rsp+0xD0]
000079f4d2de0538  vmovaps xmm15, [rsp+0xE0]
000079f4d2de0541  add rsp, 0xF0
000079f4d2de0548  pop r11
000079f4d2de054a  pop r10
000079f4d2de054c  pop r9
000079f4d2de054e  pop r8
000079f4d2de0550  pop rsi
000079f4d2de0551  pop rdi
000079f4d2de0552  pop rdx
000079f4d2de0553  pop rcx
000079f4d2de0554  pop rax
000079f4d2de0555  add rsp, 0x08
000079f4d2de0559  jmp 0x000079F4D2DDEE74
000079f4d2de055e  sub rsp, 0x08
000079f4d2de0562  push rax
000079f4d2de0563  push rcx
000079f4d2de0564  push rdx
000079f4d2de0565  push rdi
000079f4d2de0566  push rsi
000079f4d2de0567  push r8
000079f4d2de0569  push r9
000079f4d2de056b  push r10
000079f4d2de056d  push r11
000079f4d2de056f  sub rsp, 0xF0
000079f4d2de0576  vmovaps [rsp], xmm0
000079f4d2de057b  vmovaps [rsp+0x10], xmm1
000079f4d2de0581  vmovaps [rsp+0x20], xmm2
000079f4d2de0587  vmovaps [rsp+0x30], xmm3
000079f4d2de058d  vmovaps [rsp+0x40], xmm4
000079f4d2de0593  vmovaps [rsp+0x50], xmm5
000079f4d2de0599  vmovaps [rsp+0x60], xmm6
000079f4d2de059f  vmovaps [rsp+0x70], xmm7
000079f4d2de05a5  vmovaps [rsp+0x80], xmm8
000079f4d2de05ae  vmovaps [rsp+0x90], xmm10
000079f4d2de05b7  vmovaps [rsp+0xA0], xmm11
000079f4d2de05c0  vmovaps [rsp+0xB0], xmm12
000079f4d2de05c9  vmovaps [rsp+0xC0], xmm13
000079f4d2de05d2  vmovaps [rsp+0xD0], xmm14
000079f4d2de05db  vmovaps [rsp+0xE0], xmm15
000079f4d2de05e4  sub rsp, 0x30
000079f4d2de05e8  movaps [rsp], xmm9
000079f4d2de05ed  movaps [rsp+0x10], xmm10
000079f4d2de05f3  movaps [rsp+0x20], xmm8
000079f4d2de05f9  lea rdi, [rsp]
000079f4d2de05fd  mov esi, 0x00
000079f4d2de0602  mov rax, 0x5D9EC01E8530
000079f4d2de060c  call rax
000079f4d2de060e  movaps xmm9, [rsp]
000079f4d2de0613  add rsp, 0x30
000079f4d2de0617  vmovaps xmm0, [rsp]
000079f4d2de061c  vmovaps xmm1, [rsp+0x10]
000079f4d2de0622  vmovaps xmm2, [rsp+0x20]
000079f4d2de0628  vmovaps xmm3, [rsp+0x30]
000079f4d2de062e  vmovaps xmm4, [rsp+0x40]
000079f4d2de0634  vmovaps xmm5, [rsp+0x50]
000079f4d2de063a  vmovaps xmm6, [rsp+0x60]
000079f4d2de0640  vmovaps xmm7, [rsp+0x70]
000079f4d2de0646  vmovaps xmm8, [rsp+0x80]
000079f4d2de064f  vmovaps xmm10, [rsp+0x90]
000079f4d2de0658  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0661  vmovaps xmm12, [rsp+0xB0]
000079f4d2de066a  vmovaps xmm13, [rsp+0xC0]
000079f4d2de0673  vmovaps xmm14, [rsp+0xD0]
000079f4d2de067c  vmovaps xmm15, [rsp+0xE0]
000079f4d2de0685  add rsp, 0xF0
000079f4d2de068c  pop r11
000079f4d2de068e  pop r10
000079f4d2de0690  pop r9
000079f4d2de0692  pop r8
000079f4d2de0694  pop rsi
000079f4d2de0695  pop rdi
000079f4d2de0696  pop rdx
000079f4d2de0697  pop rcx
000079f4d2de0698  pop rax
000079f4d2de0699  add rsp, 0x08
000079f4d2de069d  jmp 0x000079F4D2DDEE8E
000079f4d2de06a2  call 0x000079F4D2CB52F0
000079f4d2de06a7  jmp 0x000079F4D2DDEFA8
000079f4d2de06ac  call 0x000079F4D2CB52F0
000079f4d2de06b1  jmp 0x000079F4D2DDEFBE
000079f4d2de06b6  sub rsp, 0x08
000079f4d2de06ba  push rax
000079f4d2de06bb  push rcx
000079f4d2de06bc  push rdx
000079f4d2de06bd  push rdi
000079f4d2de06be  push rsi
000079f4d2de06bf  push r8
000079f4d2de06c1  push r9
000079f4d2de06c3  push r10
000079f4d2de06c5  push r11
000079f4d2de06c7  sub rsp, 0xF0
000079f4d2de06ce  vmovaps [rsp], xmm0
000079f4d2de06d3  vmovaps [rsp+0x10], xmm2
000079f4d2de06d9  vmovaps [rsp+0x20], xmm3
000079f4d2de06df  vmovaps [rsp+0x30], xmm4
000079f4d2de06e5  vmovaps [rsp+0x40], xmm5
000079f4d2de06eb  vmovaps [rsp+0x50], xmm6
000079f4d2de06f1  vmovaps [rsp+0x60], xmm7
000079f4d2de06f7  vmovaps [rsp+0x70], xmm8
000079f4d2de06fd  vmovaps [rsp+0x80], xmm9
000079f4d2de0706  vmovaps [rsp+0x90], xmm10
000079f4d2de070f  vmovaps [rsp+0xA0], xmm11
000079f4d2de0718  vmovaps [rsp+0xB0], xmm12
000079f4d2de0721  vmovaps [rsp+0xC0], xmm13
000079f4d2de072a  vmovaps [rsp+0xD0], xmm14
000079f4d2de0733  vmovaps [rsp+0xE0], xmm15
000079f4d2de073c  sub rsp, 0x30
000079f4d2de0740  movaps [rsp], xmm1
000079f4d2de0744  movaps [rsp+0x10], xmm6
000079f4d2de0749  movaps [rsp+0x20], xmm15
000079f4d2de074f  lea rdi, [rsp]
000079f4d2de0753  mov esi, 0x00
000079f4d2de0758  mov rax, 0x5D9EC01E8530
000079f4d2de0762  call rax
000079f4d2de0764  movaps xmm1, [rsp]
000079f4d2de0768  add rsp, 0x30
000079f4d2de076c  vmovaps xmm0, [rsp]
000079f4d2de0771  vmovaps xmm2, [rsp+0x10]
000079f4d2de0777  vmovaps xmm3, [rsp+0x20]
000079f4d2de077d  vmovaps xmm4, [rsp+0x30]
000079f4d2de0783  vmovaps xmm5, [rsp+0x40]
000079f4d2de0789  vmovaps xmm6, [rsp+0x50]
000079f4d2de078f  vmovaps xmm7, [rsp+0x60]
000079f4d2de0795  vmovaps xmm8, [rsp+0x70]
000079f4d2de079b  vmovaps xmm9, [rsp+0x80]
000079f4d2de07a4  vmovaps xmm10, [rsp+0x90]
000079f4d2de07ad  vmovaps xmm11, [rsp+0xA0]
000079f4d2de07b6  vmovaps xmm12, [rsp+0xB0]
000079f4d2de07bf  vmovaps xmm13, [rsp+0xC0]
000079f4d2de07c8  vmovaps xmm14, [rsp+0xD0]
000079f4d2de07d1  vmovaps xmm15, [rsp+0xE0]
000079f4d2de07da  add rsp, 0xF0
000079f4d2de07e1  pop r11
000079f4d2de07e3  pop r10
000079f4d2de07e5  pop r9
000079f4d2de07e7  pop r8
000079f4d2de07e9  pop rsi
000079f4d2de07ea  pop rdi
000079f4d2de07eb  pop rdx
000079f4d2de07ec  pop rcx
000079f4d2de07ed  pop rax
000079f4d2de07ee  add rsp, 0x08
000079f4d2de07f2  jmp 0x000079F4D2DDEFFB
000079f4d2de07f7  call 0x000079F4D2CC4620
000079f4d2de07fc  jmp 0x000079F4D2DDF008
000079f4d2de0801  sub rsp, 0x08
000079f4d2de0805  push rax
000079f4d2de0806  push rcx
000079f4d2de0807  push rdx
000079f4d2de0808  push rdi
000079f4d2de0809  push rsi
000079f4d2de080a  push r8
000079f4d2de080c  push r9
000079f4d2de080e  push r10
000079f4d2de0810  push r11
000079f4d2de0812  sub rsp, 0xF0
000079f4d2de0819  vmovaps [rsp], xmm0
000079f4d2de081e  vmovaps [rsp+0x10], xmm1
000079f4d2de0824  vmovaps [rsp+0x20], xmm2
000079f4d2de082a  vmovaps [rsp+0x30], xmm3
000079f4d2de0830  vmovaps [rsp+0x40], xmm4
000079f4d2de0836  vmovaps [rsp+0x50], xmm5
000079f4d2de083c  vmovaps [rsp+0x60], xmm6
000079f4d2de0842  vmovaps [rsp+0x70], xmm7
000079f4d2de0848  vmovaps [rsp+0x80], xmm8
000079f4d2de0851  vmovaps [rsp+0x90], xmm9
000079f4d2de085a  vmovaps [rsp+0xA0], xmm10
000079f4d2de0863  vmovaps [rsp+0xB0], xmm11
000079f4d2de086c  vmovaps [rsp+0xC0], xmm12
000079f4d2de0875  vmovaps [rsp+0xD0], xmm13
000079f4d2de087e  vmovaps [rsp+0xE0], xmm15
000079f4d2de0887  sub rsp, 0x30
000079f4d2de088b  movaps [rsp], xmm14
000079f4d2de0890  movaps [rsp+0x10], xmm4
000079f4d2de0895  movaps [rsp+0x20], xmm3
000079f4d2de089a  lea rdi, [rsp]
000079f4d2de089e  mov esi, 0x00
000079f4d2de08a3  mov rax, 0x5D9EC01E8530
000079f4d2de08ad  call rax
000079f4d2de08af  movaps xmm14, [rsp]
000079f4d2de08b4  add rsp, 0x30
000079f4d2de08b8  vmovaps xmm0, [rsp]
000079f4d2de08bd  vmovaps xmm1, [rsp+0x10]
000079f4d2de08c3  vmovaps xmm2, [rsp+0x20]
000079f4d2de08c9  vmovaps xmm3, [rsp+0x30]
000079f4d2de08cf  vmovaps xmm4, [rsp+0x40]
000079f4d2de08d5  vmovaps xmm5, [rsp+0x50]
000079f4d2de08db  vmovaps xmm6, [rsp+0x60]
000079f4d2de08e1  vmovaps xmm7, [rsp+0x70]
000079f4d2de08e7  vmovaps xmm8, [rsp+0x80]
000079f4d2de08f0  vmovaps xmm9, [rsp+0x90]
000079f4d2de08f9  vmovaps xmm10, [rsp+0xA0]
000079f4d2de0902  vmovaps xmm11, [rsp+0xB0]
000079f4d2de090b  vmovaps xmm12, [rsp+0xC0]
000079f4d2de0914  vmovaps xmm13, [rsp+0xD0]
000079f4d2de091d  vmovaps xmm15, [rsp+0xE0]
000079f4d2de0926  add rsp, 0xF0
000079f4d2de092d  pop r11
000079f4d2de092f  pop r10
000079f4d2de0931  pop r9
000079f4d2de0933  pop r8
000079f4d2de0935  pop rsi
000079f4d2de0936  pop rdi
000079f4d2de0937  pop rdx
000079f4d2de0938  pop rcx
000079f4d2de0939  pop rax
000079f4d2de093a  add rsp, 0x08
000079f4d2de093e  jmp 0x000079F4D2DDF022
000079f4d2de0943  sub rsp, 0x08
000079f4d2de0947  push rax
000079f4d2de0948  push rcx
000079f4d2de0949  push rdx
000079f4d2de094a  push rdi
000079f4d2de094b  push rsi
000079f4d2de094c  push r8
000079f4d2de094e  push r9
000079f4d2de0950  push r10
000079f4d2de0952  push r11
000079f4d2de0954  sub rsp, 0xF0
000079f4d2de095b  vmovaps [rsp], xmm0
000079f4d2de0960  vmovaps [rsp+0x10], xmm1
000079f4d2de0966  vmovaps [rsp+0x20], xmm2
000079f4d2de096c  vmovaps [rsp+0x30], xmm3
000079f4d2de0972  vmovaps [rsp+0x40], xmm4
000079f4d2de0978  vmovaps [rsp+0x50], xmm5
000079f4d2de097e  vmovaps [rsp+0x60], xmm7
000079f4d2de0984  vmovaps [rsp+0x70], xmm8
000079f4d2de098a  vmovaps [rsp+0x80], xmm9
000079f4d2de0993  vmovaps [rsp+0x90], xmm10
000079f4d2de099c  vmovaps [rsp+0xA0], xmm11
000079f4d2de09a5  vmovaps [rsp+0xB0], xmm12
000079f4d2de09ae  vmovaps [rsp+0xC0], xmm13
000079f4d2de09b7  vmovaps [rsp+0xD0], xmm14
000079f4d2de09c0  vmovaps [rsp+0xE0], xmm15
000079f4d2de09c9  sub rsp, 0x30
000079f4d2de09cd  movaps [rsp], xmm6
000079f4d2de09d1  movaps [rsp+0x10], xmm9
000079f4d2de09d7  movaps [rsp+0x20], xmm7
000079f4d2de09dc  lea rdi, [rsp]
000079f4d2de09e0  mov esi, 0x00
000079f4d2de09e5  mov rax, 0x5D9EC01E8530
000079f4d2de09ef  call rax
000079f4d2de09f1  movaps xmm6, [rsp]
000079f4d2de09f5  add rsp, 0x30
000079f4d2de09f9  vmovaps xmm0, [rsp]
000079f4d2de09fe  vmovaps xmm1, [rsp+0x10]
000079f4d2de0a04  vmovaps xmm2, [rsp+0x20]
000079f4d2de0a0a  vmovaps xmm3, [rsp+0x30]
000079f4d2de0a10  vmovaps xmm4, [rsp+0x40]
000079f4d2de0a16  vmovaps xmm5, [rsp+0x50]
000079f4d2de0a1c  vmovaps xmm7, [rsp+0x60]
000079f4d2de0a22  vmovaps xmm8, [rsp+0x70]
000079f4d2de0a28  vmovaps xmm9, [rsp+0x80]
000079f4d2de0a31  vmovaps xmm10, [rsp+0x90]
000079f4d2de0a3a  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0a43  vmovaps xmm12, [rsp+0xB0]
000079f4d2de0a4c  vmovaps xmm13, [rsp+0xC0]
000079f4d2de0a55  vmovaps xmm14, [rsp+0xD0]
000079f4d2de0a5e  vmovaps xmm15, [rsp+0xE0]
000079f4d2de0a67  add rsp, 0xF0
000079f4d2de0a6e  pop r11
000079f4d2de0a70  pop r10
000079f4d2de0a72  pop r9
000079f4d2de0a74  pop r8
000079f4d2de0a76  pop rsi
000079f4d2de0a77  pop rdi
000079f4d2de0a78  pop rdx
000079f4d2de0a79  pop rcx
000079f4d2de0a7a  pop rax
000079f4d2de0a7b  add rsp, 0x08
000079f4d2de0a7f  jmp 0x000079F4D2DDF03A
000079f4d2de0a84  sub rsp, 0x08
000079f4d2de0a88  push rax
000079f4d2de0a89  push rcx
000079f4d2de0a8a  push rdx
000079f4d2de0a8b  push rdi
000079f4d2de0a8c  push rsi
000079f4d2de0a8d  push r8
000079f4d2de0a8f  push r9
000079f4d2de0a91  push r10
000079f4d2de0a93  push r11
000079f4d2de0a95  sub rsp, 0xF0
000079f4d2de0a9c  vmovaps [rsp], xmm0
000079f4d2de0aa1  vmovaps [rsp+0x10], xmm1
000079f4d2de0aa7  vmovaps [rsp+0x20], xmm2
000079f4d2de0aad  vmovaps [rsp+0x30], xmm3
000079f4d2de0ab3  vmovaps [rsp+0x40], xmm4
000079f4d2de0ab9  vmovaps [rsp+0x50], xmm5
000079f4d2de0abf  vmovaps [rsp+0x60], xmm6
000079f4d2de0ac5  vmovaps [rsp+0x70], xmm8
000079f4d2de0acb  vmovaps [rsp+0x80], xmm9
000079f4d2de0ad4  vmovaps [rsp+0x90], xmm10
000079f4d2de0add  vmovaps [rsp+0xA0], xmm11
000079f4d2de0ae6  vmovaps [rsp+0xB0], xmm12
000079f4d2de0aef  vmovaps [rsp+0xC0], xmm13
000079f4d2de0af8  vmovaps [rsp+0xD0], xmm14
000079f4d2de0b01  vmovaps [rsp+0xE0], xmm15
000079f4d2de0b0a  sub rsp, 0x30
000079f4d2de0b0e  movaps [rsp], xmm7
000079f4d2de0b12  movaps [rsp+0x10], xmm4
000079f4d2de0b17  movaps [rsp+0x20], xmm9
000079f4d2de0b1d  lea rdi, [rsp]
000079f4d2de0b21  mov esi, 0x00
000079f4d2de0b26  mov rax, 0x5D9EC01E8530
000079f4d2de0b30  call rax
000079f4d2de0b32  movaps xmm7, [rsp]
000079f4d2de0b36  add rsp, 0x30
000079f4d2de0b3a  vmovaps xmm0, [rsp]
000079f4d2de0b3f  vmovaps xmm1, [rsp+0x10]
000079f4d2de0b45  vmovaps xmm2, [rsp+0x20]
000079f4d2de0b4b  vmovaps xmm3, [rsp+0x30]
000079f4d2de0b51  vmovaps xmm4, [rsp+0x40]
000079f4d2de0b57  vmovaps xmm5, [rsp+0x50]
000079f4d2de0b5d  vmovaps xmm6, [rsp+0x60]
000079f4d2de0b63  vmovaps xmm8, [rsp+0x70]
000079f4d2de0b69  vmovaps xmm9, [rsp+0x80]
000079f4d2de0b72  vmovaps xmm10, [rsp+0x90]
000079f4d2de0b7b  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0b84  vmovaps xmm12, [rsp+0xB0]
000079f4d2de0b8d  vmovaps xmm13, [rsp+0xC0]
000079f4d2de0b96  vmovaps xmm14, [rsp+0xD0]
000079f4d2de0b9f  vmovaps xmm15, [rsp+0xE0]
000079f4d2de0ba8  add rsp, 0xF0
000079f4d2de0baf  pop r11
000079f4d2de0bb1  pop r10
000079f4d2de0bb3  pop r9
000079f4d2de0bb5  pop r8
000079f4d2de0bb7  pop rsi
000079f4d2de0bb8  pop rdi
000079f4d2de0bb9  pop rdx
000079f4d2de0bba  pop rcx
000079f4d2de0bbb  pop rax
000079f4d2de0bbc  add rsp, 0x08
000079f4d2de0bc0  jmp 0x000079F4D2DDF067
000079f4d2de0bc5  sub rsp, 0x08
000079f4d2de0bc9  push rax
000079f4d2de0bca  push rcx
000079f4d2de0bcb  push rdx
000079f4d2de0bcc  push rdi
000079f4d2de0bcd  push rsi
000079f4d2de0bce  push r8
000079f4d2de0bd0  push r9
000079f4d2de0bd2  push r10
000079f4d2de0bd4  push r11
000079f4d2de0bd6  sub rsp, 0xF0
000079f4d2de0bdd  vmovaps [rsp], xmm0
000079f4d2de0be2  vmovaps [rsp+0x10], xmm1
000079f4d2de0be8  vmovaps [rsp+0x20], xmm2
000079f4d2de0bee  vmovaps [rsp+0x30], xmm3
000079f4d2de0bf4  vmovaps [rsp+0x40], xmm5
000079f4d2de0bfa  vmovaps [rsp+0x50], xmm6
000079f4d2de0c00  vmovaps [rsp+0x60], xmm7
000079f4d2de0c06  vmovaps [rsp+0x70], xmm8
000079f4d2de0c0c  vmovaps [rsp+0x80], xmm9
000079f4d2de0c15  vmovaps [rsp+0x90], xmm10
000079f4d2de0c1e  vmovaps [rsp+0xA0], xmm11
000079f4d2de0c27  vmovaps [rsp+0xB0], xmm12
000079f4d2de0c30  vmovaps [rsp+0xC0], xmm13
000079f4d2de0c39  vmovaps [rsp+0xD0], xmm14
000079f4d2de0c42  vmovaps [rsp+0xE0], xmm15
000079f4d2de0c4b  sub rsp, 0x30
000079f4d2de0c4f  movaps [rsp], xmm4
000079f4d2de0c53  movaps [rsp+0x10], xmm15
000079f4d2de0c59  movaps [rsp+0x20], xmm9
000079f4d2de0c5f  lea rdi, [rsp]
000079f4d2de0c63  mov esi, 0x00
000079f4d2de0c68  mov rax, 0x5D9EC01E8530
000079f4d2de0c72  call rax
000079f4d2de0c74  movaps xmm4, [rsp]
000079f4d2de0c78  add rsp, 0x30
000079f4d2de0c7c  vmovaps xmm0, [rsp]
000079f4d2de0c81  vmovaps xmm1, [rsp+0x10]
000079f4d2de0c87  vmovaps xmm2, [rsp+0x20]
000079f4d2de0c8d  vmovaps xmm3, [rsp+0x30]
000079f4d2de0c93  vmovaps xmm5, [rsp+0x40]
000079f4d2de0c99  vmovaps xmm6, [rsp+0x50]
000079f4d2de0c9f  vmovaps xmm7, [rsp+0x60]
000079f4d2de0ca5  vmovaps xmm8, [rsp+0x70]
000079f4d2de0cab  vmovaps xmm9, [rsp+0x80]
000079f4d2de0cb4  vmovaps xmm10, [rsp+0x90]
000079f4d2de0cbd  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0cc6  vmovaps xmm12, [rsp+0xB0]
000079f4d2de0ccf  vmovaps xmm13, [rsp+0xC0]
000079f4d2de0cd8  vmovaps xmm14, [rsp+0xD0]
000079f4d2de0ce1  vmovaps xmm15, [rsp+0xE0]
000079f4d2de0cea  add rsp, 0xF0
000079f4d2de0cf1  pop r11
000079f4d2de0cf3  pop r10
000079f4d2de0cf5  pop r9
000079f4d2de0cf7  pop r8
000079f4d2de0cf9  pop rsi
000079f4d2de0cfa  pop rdi
000079f4d2de0cfb  pop rdx
000079f4d2de0cfc  pop rcx
000079f4d2de0cfd  pop rax
000079f4d2de0cfe  add rsp, 0x08
000079f4d2de0d02  jmp 0x000079F4D2DDF08C
000079f4d2de0d07  call 0x000079F4D2CC4620
000079f4d2de0d0c  jmp 0x000079F4D2DDF099
000079f4d2de0d11  sub rsp, 0x08
000079f4d2de0d15  push rax
000079f4d2de0d16  push rcx
000079f4d2de0d17  push rdx
000079f4d2de0d18  push rdi
000079f4d2de0d19  push rsi
000079f4d2de0d1a  push r8
000079f4d2de0d1c  push r9
000079f4d2de0d1e  push r10
000079f4d2de0d20  push r11
000079f4d2de0d22  sub rsp, 0xF0
000079f4d2de0d29  vmovaps [rsp], xmm0
000079f4d2de0d2e  vmovaps [rsp+0x10], xmm1
000079f4d2de0d34  vmovaps [rsp+0x20], xmm2
000079f4d2de0d3a  vmovaps [rsp+0x30], xmm4
000079f4d2de0d40  vmovaps [rsp+0x40], xmm5
000079f4d2de0d46  vmovaps [rsp+0x50], xmm6
000079f4d2de0d4c  vmovaps [rsp+0x60], xmm7
000079f4d2de0d52  vmovaps [rsp+0x70], xmm8
000079f4d2de0d58  vmovaps [rsp+0x80], xmm9
000079f4d2de0d61  vmovaps [rsp+0x90], xmm10
000079f4d2de0d6a  vmovaps [rsp+0xA0], xmm11
000079f4d2de0d73  vmovaps [rsp+0xB0], xmm12
000079f4d2de0d7c  vmovaps [rsp+0xC0], xmm13
000079f4d2de0d85  vmovaps [rsp+0xD0], xmm14
000079f4d2de0d8e  vmovaps [rsp+0xE0], xmm15
000079f4d2de0d97  sub rsp, 0x30
000079f4d2de0d9b  movaps [rsp], xmm3
000079f4d2de0d9f  movaps [rsp+0x10], xmm1
000079f4d2de0da4  movaps [rsp+0x20], xmm9
000079f4d2de0daa  lea rdi, [rsp]
000079f4d2de0dae  mov esi, 0x00
000079f4d2de0db3  mov rax, 0x5D9EC01E8530
000079f4d2de0dbd  call rax
000079f4d2de0dbf  movaps xmm3, [rsp]
000079f4d2de0dc3  add rsp, 0x30
000079f4d2de0dc7  vmovaps xmm0, [rsp]
000079f4d2de0dcc  vmovaps xmm1, [rsp+0x10]
000079f4d2de0dd2  vmovaps xmm2, [rsp+0x20]
000079f4d2de0dd8  vmovaps xmm4, [rsp+0x30]
000079f4d2de0dde  vmovaps xmm5, [rsp+0x40]
000079f4d2de0de4  vmovaps xmm6, [rsp+0x50]
000079f4d2de0dea  vmovaps xmm7, [rsp+0x60]
000079f4d2de0df0  vmovaps xmm8, [rsp+0x70]
000079f4d2de0df6  vmovaps xmm9, [rsp+0x80]
000079f4d2de0dff  vmovaps xmm10, [rsp+0x90]
000079f4d2de0e08  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0e11  vmovaps xmm12, [rsp+0xB0]
000079f4d2de0e1a  vmovaps xmm13, [rsp+0xC0]
000079f4d2de0e23  vmovaps xmm14, [rsp+0xD0]
000079f4d2de0e2c  vmovaps xmm15, [rsp+0xE0]
000079f4d2de0e35  add rsp, 0xF0
000079f4d2de0e3c  pop r11
000079f4d2de0e3e  pop r10
000079f4d2de0e40  pop r9
000079f4d2de0e42  pop r8
000079f4d2de0e44  pop rsi
000079f4d2de0e45  pop rdi
000079f4d2de0e46  pop rdx
000079f4d2de0e47  pop rcx
000079f4d2de0e48  pop rax
000079f4d2de0e49  add rsp, 0x08
000079f4d2de0e4d  jmp 0x000079F4D2DDF0D6
000079f4d2de0e52  sub rsp, 0x08
000079f4d2de0e56  push rax
000079f4d2de0e57  push rcx
000079f4d2de0e58  push rdx
000079f4d2de0e59  push rdi
000079f4d2de0e5a  push rsi
000079f4d2de0e5b  push r8
000079f4d2de0e5d  push r9
000079f4d2de0e5f  push r10
000079f4d2de0e61  push r11
000079f4d2de0e63  sub rsp, 0xF0
000079f4d2de0e6a  vmovaps [rsp], xmm0
000079f4d2de0e6f  vmovaps [rsp+0x10], xmm2
000079f4d2de0e75  vmovaps [rsp+0x20], xmm3
000079f4d2de0e7b  vmovaps [rsp+0x30], xmm4
000079f4d2de0e81  vmovaps [rsp+0x40], xmm5
000079f4d2de0e87  vmovaps [rsp+0x50], xmm6
000079f4d2de0e8d  vmovaps [rsp+0x60], xmm7
000079f4d2de0e93  vmovaps [rsp+0x70], xmm8
000079f4d2de0e99  vmovaps [rsp+0x80], xmm9
000079f4d2de0ea2  vmovaps [rsp+0x90], xmm10
000079f4d2de0eab  vmovaps [rsp+0xA0], xmm11
000079f4d2de0eb4  vmovaps [rsp+0xB0], xmm12
000079f4d2de0ebd  vmovaps [rsp+0xC0], xmm13
000079f4d2de0ec6  vmovaps [rsp+0xD0], xmm14
000079f4d2de0ecf  vmovaps [rsp+0xE0], xmm15
000079f4d2de0ed8  sub rsp, 0x30
000079f4d2de0edc  movaps [rsp], xmm1
000079f4d2de0ee0  movaps [rsp+0x10], xmm15
000079f4d2de0ee6  movaps [rsp+0x20], xmm9
000079f4d2de0eec  lea rdi, [rsp]
000079f4d2de0ef0  mov esi, 0x00
000079f4d2de0ef5  mov rax, 0x5D9EC01E8530
000079f4d2de0eff  call rax
000079f4d2de0f01  movaps xmm1, [rsp]
000079f4d2de0f05  add rsp, 0x30
000079f4d2de0f09  vmovaps xmm0, [rsp]
000079f4d2de0f0e  vmovaps xmm2, [rsp+0x10]
000079f4d2de0f14  vmovaps xmm3, [rsp+0x20]
000079f4d2de0f1a  vmovaps xmm4, [rsp+0x30]
000079f4d2de0f20  vmovaps xmm5, [rsp+0x40]
000079f4d2de0f26  vmovaps xmm6, [rsp+0x50]
000079f4d2de0f2c  vmovaps xmm7, [rsp+0x60]
000079f4d2de0f32  vmovaps xmm8, [rsp+0x70]
000079f4d2de0f38  vmovaps xmm9, [rsp+0x80]
000079f4d2de0f41  vmovaps xmm10, [rsp+0x90]
000079f4d2de0f4a  vmovaps xmm11, [rsp+0xA0]
000079f4d2de0f53  vmovaps xmm12, [rsp+0xB0]
000079f4d2de0f5c  vmovaps xmm13, [rsp+0xC0]
000079f4d2de0f65  vmovaps xmm14, [rsp+0xD0]
000079f4d2de0f6e  vmovaps xmm15, [rsp+0xE0]
000079f4d2de0f77  add rsp, 0xF0
000079f4d2de0f7e  pop r11
000079f4d2de0f80  pop r10
000079f4d2de0f82  pop r9
000079f4d2de0f84  pop r8
000079f4d2de0f86  pop rsi
000079f4d2de0f87  pop rdi
000079f4d2de0f88  pop rdx
000079f4d2de0f89  pop rcx
000079f4d2de0f8a  pop rax
000079f4d2de0f8b  add rsp, 0x08
000079f4d2de0f8f  jmp 0x000079F4D2DDF15E
000079f4d2de0f94  call 0x000079F4D2CC4620
000079f4d2de0f99  jmp 0x000079F4D2DDF16B
000079f4d2de0f9e  sub rsp, 0x08
000079f4d2de0fa2  push rax
000079f4d2de0fa3  push rcx
000079f4d2de0fa4  push rdx
000079f4d2de0fa5  push rdi
000079f4d2de0fa6  push rsi
000079f4d2de0fa7  push r8
000079f4d2de0fa9  push r9
000079f4d2de0fab  push r10
000079f4d2de0fad  push r11
000079f4d2de0faf  sub rsp, 0xF0
000079f4d2de0fb6  vmovaps [rsp], xmm0
000079f4d2de0fbb  vmovaps [rsp+0x10], xmm2
000079f4d2de0fc1  vmovaps [rsp+0x20], xmm3
000079f4d2de0fc7  vmovaps [rsp+0x30], xmm4
000079f4d2de0fcd  vmovaps [rsp+0x40], xmm5
000079f4d2de0fd3  vmovaps [rsp+0x50], xmm6
000079f4d2de0fd9  vmovaps [rsp+0x60], xmm7
000079f4d2de0fdf  vmovaps [rsp+0x70], xmm8
000079f4d2de0fe5  vmovaps [rsp+0x80], xmm9
000079f4d2de0fee  vmovaps [rsp+0x90], xmm10
000079f4d2de0ff7  vmovaps [rsp+0xA0], xmm11
000079f4d2de1000  vmovaps [rsp+0xB0], xmm12
000079f4d2de1009  vmovaps [rsp+0xC0], xmm13
000079f4d2de1012  vmovaps [rsp+0xD0], xmm14
000079f4d2de101b  vmovaps [rsp+0xE0], xmm15
000079f4d2de1024  sub rsp, 0x30
000079f4d2de1028  movaps [rsp], xmm1
000079f4d2de102c  movaps [rsp+0x10], xmm5
000079f4d2de1031  movaps [rsp+0x20], xmm7
000079f4d2de1036  lea rdi, [rsp]
000079f4d2de103a  mov esi, 0x00
000079f4d2de103f  mov rax, 0x5D9EC01E8530
000079f4d2de1049  call rax
000079f4d2de104b  movaps xmm1, [rsp]
000079f4d2de104f  add rsp, 0x30
000079f4d2de1053  vmovaps xmm0, [rsp]
000079f4d2de1058  vmovaps xmm2, [rsp+0x10]
000079f4d2de105e  vmovaps xmm3, [rsp+0x20]
000079f4d2de1064  vmovaps xmm4, [rsp+0x30]
000079f4d2de106a  vmovaps xmm5, [rsp+0x40]
000079f4d2de1070  vmovaps xmm6, [rsp+0x50]
000079f4d2de1076  vmovaps xmm7, [rsp+0x60]
000079f4d2de107c  vmovaps xmm8, [rsp+0x70]
000079f4d2de1082  vmovaps xmm9, [rsp+0x80]
000079f4d2de108b  vmovaps xmm10, [rsp+0x90]
000079f4d2de1094  vmovaps xmm11, [rsp+0xA0]
000079f4d2de109d  vmovaps xmm12, [rsp+0xB0]
000079f4d2de10a6  vmovaps xmm13, [rsp+0xC0]
000079f4d2de10af  vmovaps xmm14, [rsp+0xD0]
000079f4d2de10b8  vmovaps xmm15, [rsp+0xE0]
000079f4d2de10c1  add rsp, 0xF0
000079f4d2de10c8  pop r11
000079f4d2de10ca  pop r10
000079f4d2de10cc  pop r9
000079f4d2de10ce  pop r8
000079f4d2de10d0  pop rsi
000079f4d2de10d1  pop rdi
000079f4d2de10d2  pop rdx
000079f4d2de10d3  pop rcx
000079f4d2de10d4  pop rax
000079f4d2de10d5  add rsp, 0x08
000079f4d2de10d9  jmp 0x000079F4D2DDF210
000079f4d2de10de  sub rsp, 0x08
000079f4d2de10e2  push rax
000079f4d2de10e3  push rcx
000079f4d2de10e4  push rdx
000079f4d2de10e5  push rdi
000079f4d2de10e6  push rsi
000079f4d2de10e7  push r8
000079f4d2de10e9  push r9
000079f4d2de10eb  push r10
000079f4d2de10ed  push r11
000079f4d2de10ef  sub rsp, 0xF0
000079f4d2de10f6  vmovaps [rsp], xmm0
000079f4d2de10fb  vmovaps [rsp+0x10], xmm1
000079f4d2de1101  vmovaps [rsp+0x20], xmm2
000079f4d2de1107  vmovaps [rsp+0x30], xmm3
000079f4d2de110d  vmovaps [rsp+0x40], xmm4
000079f4d2de1113  vmovaps [rsp+0x50], xmm5
000079f4d2de1119  vmovaps [rsp+0x60], xmm6
000079f4d2de111f  vmovaps [rsp+0x70], xmm8
000079f4d2de1125  vmovaps [rsp+0x80], xmm9
000079f4d2de112e  vmovaps [rsp+0x90], xmm10
000079f4d2de1137  vmovaps [rsp+0xA0], xmm11
000079f4d2de1140  vmovaps [rsp+0xB0], xmm12
000079f4d2de1149  vmovaps [rsp+0xC0], xmm13
000079f4d2de1152  vmovaps [rsp+0xD0], xmm14
000079f4d2de115b  vmovaps [rsp+0xE0], xmm15
000079f4d2de1164  sub rsp, 0x30
000079f4d2de1168  movaps [rsp], xmm7
000079f4d2de116c  movaps [rsp+0x10], xmm5
000079f4d2de1171  movaps [rsp+0x20], xmm15
000079f4d2de1177  lea rdi, [rsp]
000079f4d2de117b  mov esi, 0x00
000079f4d2de1180  mov rax, 0x5D9EC01E8530
000079f4d2de118a  call rax
000079f4d2de118c  movaps xmm7, [rsp]
000079f4d2de1190  add rsp, 0x30
000079f4d2de1194  vmovaps xmm0, [rsp]
000079f4d2de1199  vmovaps xmm1, [rsp+0x10]
000079f4d2de119f  vmovaps xmm2, [rsp+0x20]
000079f4d2de11a5  vmovaps xmm3, [rsp+0x30]
000079f4d2de11ab  vmovaps xmm4, [rsp+0x40]
000079f4d2de11b1  vmovaps xmm5, [rsp+0x50]
000079f4d2de11b7  vmovaps xmm6, [rsp+0x60]
000079f4d2de11bd  vmovaps xmm8, [rsp+0x70]
000079f4d2de11c3  vmovaps xmm9, [rsp+0x80]
000079f4d2de11cc  vmovaps xmm10, [rsp+0x90]
000079f4d2de11d5  vmovaps xmm11, [rsp+0xA0]
000079f4d2de11de  vmovaps xmm12, [rsp+0xB0]
000079f4d2de11e7  vmovaps xmm13, [rsp+0xC0]
000079f4d2de11f0  vmovaps xmm14, [rsp+0xD0]
000079f4d2de11f9  vmovaps xmm15, [rsp+0xE0]
000079f4d2de1202  add rsp, 0xF0
000079f4d2de1209  pop r11
000079f4d2de120b  pop r10
000079f4d2de120d  pop r9
000079f4d2de120f  pop r8
000079f4d2de1211  pop rsi
000079f4d2de1212  pop rdi
000079f4d2de1213  pop rdx
000079f4d2de1214  pop rcx
000079f4d2de1215  pop rax
000079f4d2de1216  add rsp, 0x08
000079f4d2de121a  jmp 0x000079F4D2DDF246
000079f4d2de121f  call 0x000079F4D2CB52F0
000079f4d2de1224  jmp 0x000079F4D2DDF253
000079f4d2de1229  sub rsp, 0x08
000079f4d2de122d  push rax
000079f4d2de122e  push rcx
000079f4d2de122f  push rdx
000079f4d2de1230  push rdi
000079f4d2de1231  push rsi
000079f4d2de1232  push r8
000079f4d2de1234  push r9
000079f4d2de1236  push r10
000079f4d2de1238  push r11
000079f4d2de123a  sub rsp, 0xF0
000079f4d2de1241  vmovaps [rsp], xmm0
000079f4d2de1246  vmovaps [rsp+0x10], xmm1
000079f4d2de124c  vmovaps [rsp+0x20], xmm2
000079f4d2de1252  vmovaps [rsp+0x30], xmm3
000079f4d2de1258  vmovaps [rsp+0x40], xmm4
000079f4d2de125e  vmovaps [rsp+0x50], xmm5
000079f4d2de1264  vmovaps [rsp+0x60], xmm6
000079f4d2de126a  vmovaps [rsp+0x70], xmm7
000079f4d2de1270  vmovaps [rsp+0x80], xmm8
000079f4d2de1279  vmovaps [rsp+0x90], xmm9
000079f4d2de1282  vmovaps [rsp+0xA0], xmm10
000079f4d2de128b  vmovaps [rsp+0xB0], xmm11
000079f4d2de1294  vmovaps [rsp+0xC0], xmm12
000079f4d2de129d  vmovaps [rsp+0xD0], xmm13
000079f4d2de12a6  vmovaps [rsp+0xE0], xmm14
000079f4d2de12af  sub rsp, 0x30
000079f4d2de12b3  movaps [rsp], xmm15
000079f4d2de12b8  movaps [rsp+0x10], xmm5
000079f4d2de12bd  movaps [rsp+0x20], xmm3
000079f4d2de12c2  lea rdi, [rsp]
000079f4d2de12c6  mov esi, 0x00
000079f4d2de12cb  mov rax, 0x5D9EC01E8530
000079f4d2de12d5  call rax
000079f4d2de12d7  movaps xmm15, [rsp]
000079f4d2de12dc  add rsp, 0x30
000079f4d2de12e0  vmovaps xmm0, [rsp]
000079f4d2de12e5  vmovaps xmm1, [rsp+0x10]
000079f4d2de12eb  vmovaps xmm2, [rsp+0x20]
000079f4d2de12f1  vmovaps xmm3, [rsp+0x30]
000079f4d2de12f7  vmovaps xmm4, [rsp+0x40]
000079f4d2de12fd  vmovaps xmm5, [rsp+0x50]
000079f4d2de1303  vmovaps xmm6, [rsp+0x60]
000079f4d2de1309  vmovaps xmm7, [rsp+0x70]
000079f4d2de130f  vmovaps xmm8, [rsp+0x80]
000079f4d2de1318  vmovaps xmm9, [rsp+0x90]
000079f4d2de1321  vmovaps xmm10, [rsp+0xA0]
000079f4d2de132a  vmovaps xmm11, [rsp+0xB0]
000079f4d2de1333  vmovaps xmm12, [rsp+0xC0]
000079f4d2de133c  vmovaps xmm13, [rsp+0xD0]
000079f4d2de1345  vmovaps xmm14, [rsp+0xE0]
000079f4d2de134e  add rsp, 0xF0
000079f4d2de1355  pop r11
000079f4d2de1357  pop r10
000079f4d2de1359  pop r9
000079f4d2de135b  pop r8
000079f4d2de135d  pop rsi
000079f4d2de135e  pop rdi
000079f4d2de135f  pop rdx
000079f4d2de1360  pop rcx
000079f4d2de1361  pop rax
000079f4d2de1362  add rsp, 0x08
000079f4d2de1366  jmp 0x000079F4D2DDF279
000079f4d2de136b  sub rsp, 0x08
000079f4d2de136f  push rax
000079f4d2de1370  push rcx
000079f4d2de1371  push rdx
000079f4d2de1372  push rdi
000079f4d2de1373  push rsi
000079f4d2de1374  push r8
000079f4d2de1376  push r9
000079f4d2de1378  push r10
000079f4d2de137a  push r11
000079f4d2de137c  sub rsp, 0xF0
000079f4d2de1383  vmovaps [rsp], xmm0
000079f4d2de1388  vmovaps [rsp+0x10], xmm2
000079f4d2de138e  vmovaps [rsp+0x20], xmm3
000079f4d2de1394  vmovaps [rsp+0x30], xmm4
000079f4d2de139a  vmovaps [rsp+0x40], xmm5
000079f4d2de13a0  vmovaps [rsp+0x50], xmm6
000079f4d2de13a6  vmovaps [rsp+0x60], xmm7
000079f4d2de13ac  vmovaps [rsp+0x70], xmm8
000079f4d2de13b2  vmovaps [rsp+0x80], xmm9
000079f4d2de13bb  vmovaps [rsp+0x90], xmm10
000079f4d2de13c4  vmovaps [rsp+0xA0], xmm11
000079f4d2de13cd  vmovaps [rsp+0xB0], xmm12
000079f4d2de13d6  vmovaps [rsp+0xC0], xmm13
000079f4d2de13df  vmovaps [rsp+0xD0], xmm14
000079f4d2de13e8  vmovaps [rsp+0xE0], xmm15
000079f4d2de13f1  sub rsp, 0x30
000079f4d2de13f5  movaps [rsp], xmm1
000079f4d2de13f9  movaps [rsp+0x10], xmm5
000079f4d2de13fe  movaps [rsp+0x20], xmm4
000079f4d2de1403  lea rdi, [rsp]
000079f4d2de1407  mov esi, 0x00
000079f4d2de140c  mov rax, 0x5D9EC01E8530
000079f4d2de1416  call rax
000079f4d2de1418  movaps xmm1, [rsp]
000079f4d2de141c  add rsp, 0x30
000079f4d2de1420  vmovaps xmm0, [rsp]
000079f4d2de1425  vmovaps xmm2, [rsp+0x10]
000079f4d2de142b  vmovaps xmm3, [rsp+0x20]
000079f4d2de1431  vmovaps xmm4, [rsp+0x30]
000079f4d2de1437  vmovaps xmm5, [rsp+0x40]
000079f4d2de143d  vmovaps xmm6, [rsp+0x50]
000079f4d2de1443  vmovaps xmm7, [rsp+0x60]
000079f4d2de1449  vmovaps xmm8, [rsp+0x70]
000079f4d2de144f  vmovaps xmm9, [rsp+0x80]
000079f4d2de1458  vmovaps xmm10, [rsp+0x90]
000079f4d2de1461  vmovaps xmm11, [rsp+0xA0]
000079f4d2de146a  vmovaps xmm12, [rsp+0xB0]
000079f4d2de1473  vmovaps xmm13, [rsp+0xC0]
000079f4d2de147c  vmovaps xmm14, [rsp+0xD0]
000079f4d2de1485  vmovaps xmm15, [rsp+0xE0]
000079f4d2de148e  add rsp, 0xF0
000079f4d2de1495  pop r11
000079f4d2de1497  pop r10
000079f4d2de1499  pop r9
000079f4d2de149b  pop r8
000079f4d2de149d  pop rsi
000079f4d2de149e  pop rdi
000079f4d2de149f  pop rdx
000079f4d2de14a0  pop rcx
000079f4d2de14a1  pop rax
000079f4d2de14a2  add rsp, 0x08
000079f4d2de14a6  jmp 0x000079F4D2DDF299
000079f4d2de14ab  sub rsp, 0x08
000079f4d2de14af  push rax
000079f4d2de14b0  push rcx
000079f4d2de14b1  push rdx
000079f4d2de14b2  push rdi
000079f4d2de14b3  push rsi
000079f4d2de14b4  push r8
000079f4d2de14b6  push r9
000079f4d2de14b8  push r10
000079f4d2de14ba  push r11
000079f4d2de14bc  sub rsp, 0xF0
000079f4d2de14c3  vmovaps [rsp], xmm0
000079f4d2de14c8  vmovaps [rsp+0x10], xmm1
000079f4d2de14ce  vmovaps [rsp+0x20], xmm2
000079f4d2de14d4  vmovaps [rsp+0x30], xmm3
000079f4d2de14da  vmovaps [rsp+0x40], xmm5
000079f4d2de14e0  vmovaps [rsp+0x50], xmm6
000079f4d2de14e6  vmovaps [rsp+0x60], xmm7
000079f4d2de14ec  vmovaps [rsp+0x70], xmm8
000079f4d2de14f2  vmovaps [rsp+0x80], xmm9
000079f4d2de14fb  vmovaps [rsp+0x90], xmm10
000079f4d2de1504  vmovaps [rsp+0xA0], xmm11
000079f4d2de150d  vmovaps [rsp+0xB0], xmm12
000079f4d2de1516  vmovaps [rsp+0xC0], xmm13
000079f4d2de151f  vmovaps [rsp+0xD0], xmm14
000079f4d2de1528  vmovaps [rsp+0xE0], xmm15
000079f4d2de1531  sub rsp, 0x30
000079f4d2de1535  movaps [rsp], xmm4
000079f4d2de1539  movaps [rsp+0x10], xmm3
000079f4d2de153e  movaps [rsp+0x20], xmm5
000079f4d2de1543  lea rdi, [rsp]
000079f4d2de1547  mov esi, 0x00
000079f4d2de154c  mov rax, 0x5D9EC01E8530
000079f4d2de1556  call rax
000079f4d2de1558  movaps xmm4, [rsp]
000079f4d2de155c  add rsp, 0x30
000079f4d2de1560  vmovaps xmm0, [rsp]
000079f4d2de1565  vmovaps xmm1, [rsp+0x10]
000079f4d2de156b  vmovaps xmm2, [rsp+0x20]
000079f4d2de1571  vmovaps xmm3, [rsp+0x30]
000079f4d2de1577  vmovaps xmm5, [rsp+0x40]
000079f4d2de157d  vmovaps xmm6, [rsp+0x50]
000079f4d2de1583  vmovaps xmm7, [rsp+0x60]
000079f4d2de1589  vmovaps xmm8, [rsp+0x70]
000079f4d2de158f  vmovaps xmm9, [rsp+0x80]
000079f4d2de1598  vmovaps xmm10, [rsp+0x90]
000079f4d2de15a1  vmovaps xmm11, [rsp+0xA0]
000079f4d2de15aa  vmovaps xmm12, [rsp+0xB0]
000079f4d2de15b3  vmovaps xmm13, [rsp+0xC0]
000079f4d2de15bc  vmovaps xmm14, [rsp+0xD0]
000079f4d2de15c5  vmovaps xmm15, [rsp+0xE0]
000079f4d2de15ce  add rsp, 0xF0
000079f4d2de15d5  pop r11
000079f4d2de15d7  pop r10
000079f4d2de15d9  pop r9
000079f4d2de15db  pop r8
000079f4d2de15dd  pop rsi
000079f4d2de15de  pop rdi
000079f4d2de15df  pop rdx
000079f4d2de15e0  pop rcx
000079f4d2de15e1  pop rax
000079f4d2de15e2  add rsp, 0x08
000079f4d2de15e6  jmp 0x000079F4D2DDF2E7
000079f4d2de15eb  call 0x000079F4D2CB52F0
000079f4d2de15f0  jmp 0x000079F4D2DDF2F4
000079f4d2de15f5  sub rsp, 0x08
000079f4d2de15f9  push rax
000079f4d2de15fa  push rcx
000079f4d2de15fb  push rdx
000079f4d2de15fc  push rdi
000079f4d2de15fd  push rsi
000079f4d2de15fe  push r8
000079f4d2de1600  push r9
000079f4d2de1602  push r10
000079f4d2de1604  push r11
000079f4d2de1606  sub rsp, 0xF0
000079f4d2de160d  vmovaps [rsp], xmm0
000079f4d2de1612  vmovaps [rsp+0x10], xmm1
000079f4d2de1618  vmovaps [rsp+0x20], xmm2
000079f4d2de161e  vmovaps [rsp+0x30], xmm3
000079f4d2de1624  vmovaps [rsp+0x40], xmm4
000079f4d2de162a  vmovaps [rsp+0x50], xmm6
000079f4d2de1630  vmovaps [rsp+0x60], xmm7
000079f4d2de1636  vmovaps [rsp+0x70], xmm8
000079f4d2de163c  vmovaps [rsp+0x80], xmm9
000079f4d2de1645  vmovaps [rsp+0x90], xmm10
000079f4d2de164e  vmovaps [rsp+0xA0], xmm11
000079f4d2de1657  vmovaps [rsp+0xB0], xmm12
000079f4d2de1660  vmovaps [rsp+0xC0], xmm13
000079f4d2de1669  vmovaps [rsp+0xD0], xmm14
000079f4d2de1672  vmovaps [rsp+0xE0], xmm15
000079f4d2de167b  sub rsp, 0x30
000079f4d2de167f  movaps [rsp], xmm5
000079f4d2de1683  movaps [rsp+0x10], xmm6
000079f4d2de1688  movaps [rsp+0x20], xmm3
000079f4d2de168d  lea rdi, [rsp]
000079f4d2de1691  mov esi, 0x00
000079f4d2de1696  mov rax, 0x5D9EC01E8530
000079f4d2de16a0  call rax
000079f4d2de16a2  movaps xmm5, [rsp]
000079f4d2de16a6  add rsp, 0x30
000079f4d2de16aa  vmovaps xmm0, [rsp]
000079f4d2de16af  vmovaps xmm1, [rsp+0x10]
000079f4d2de16b5  vmovaps xmm2, [rsp+0x20]
000079f4d2de16bb  vmovaps xmm3, [rsp+0x30]
000079f4d2de16c1  vmovaps xmm4, [rsp+0x40]
000079f4d2de16c7  vmovaps xmm6, [rsp+0x50]
000079f4d2de16cd  vmovaps xmm7, [rsp+0x60]
000079f4d2de16d3  vmovaps xmm8, [rsp+0x70]
000079f4d2de16d9  vmovaps xmm9, [rsp+0x80]
000079f4d2de16e2  vmovaps xmm10, [rsp+0x90]
000079f4d2de16eb  vmovaps xmm11, [rsp+0xA0]
000079f4d2de16f4  vmovaps xmm12, [rsp+0xB0]
000079f4d2de16fd  vmovaps xmm13, [rsp+0xC0]
000079f4d2de1706  vmovaps xmm14, [rsp+0xD0]
000079f4d2de170f  vmovaps xmm15, [rsp+0xE0]
000079f4d2de1718  add rsp, 0xF0
000079f4d2de171f  pop r11
000079f4d2de1721  pop r10
000079f4d2de1723  pop r9
000079f4d2de1725  pop r8
000079f4d2de1727  pop rsi
000079f4d2de1728  pop rdi
000079f4d2de1729  pop rdx
000079f4d2de172a  pop rcx
000079f4d2de172b  pop rax
000079f4d2de172c  add rsp, 0x08
000079f4d2de1730  jmp 0x000079F4D2DDF31A
000079f4d2de1735  sub rsp, 0x08
000079f4d2de1739  push rax
000079f4d2de173a  push rcx
000079f4d2de173b  push rdx
000079f4d2de173c  push rdi
000079f4d2de173d  push rsi
000079f4d2de173e  push r8
000079f4d2de1740  push r9
000079f4d2de1742  push r10
000079f4d2de1744  push r11
000079f4d2de1746  sub rsp, 0xF0
000079f4d2de174d  vmovaps [rsp], xmm0
000079f4d2de1752  vmovaps [rsp+0x10], xmm1
000079f4d2de1758  vmovaps [rsp+0x20], xmm2
000079f4d2de175e  vmovaps [rsp+0x30], xmm3
000079f4d2de1764  vmovaps [rsp+0x40], xmm4
000079f4d2de176a  vmovaps [rsp+0x50], xmm5
000079f4d2de1770  vmovaps [rsp+0x60], xmm7
000079f4d2de1776  vmovaps [rsp+0x70], xmm8
000079f4d2de177c  vmovaps [rsp+0x80], xmm9
000079f4d2de1785  vmovaps [rsp+0x90], xmm10
000079f4d2de178e  vmovaps [rsp+0xA0], xmm11
000079f4d2de1797  vmovaps [rsp+0xB0], xmm12
000079f4d2de17a0  vmovaps [rsp+0xC0], xmm13
000079f4d2de17a9  vmovaps [rsp+0xD0], xmm14
000079f4d2de17b2  vmovaps [rsp+0xE0], xmm15
000079f4d2de17bb  sub rsp, 0x30
000079f4d2de17bf  movaps [rsp], xmm6
000079f4d2de17c3  movaps [rsp+0x10], xmm9
000079f4d2de17c9  movaps [rsp+0x20], xmm1
000079f4d2de17ce  lea rdi, [rsp]
000079f4d2de17d2  mov esi, 0x00
000079f4d2de17d7  mov rax, 0x5D9EC01E8530
000079f4d2de17e1  call rax
000079f4d2de17e3  movaps xmm6, [rsp]
000079f4d2de17e7  add rsp, 0x30
000079f4d2de17eb  vmovaps xmm0, [rsp]
000079f4d2de17f0  vmovaps xmm1, [rsp+0x10]
000079f4d2de17f6  vmovaps xmm2, [rsp+0x20]
000079f4d2de17fc  vmovaps xmm3, [rsp+0x30]
000079f4d2de1802  vmovaps xmm4, [rsp+0x40]
000079f4d2de1808  vmovaps xmm5, [rsp+0x50]
000079f4d2de180e  vmovaps xmm7, [rsp+0x60]
000079f4d2de1814  vmovaps xmm8, [rsp+0x70]
000079f4d2de181a  vmovaps xmm9, [rsp+0x80]
000079f4d2de1823  vmovaps xmm10, [rsp+0x90]
000079f4d2de182c  vmovaps xmm11, [rsp+0xA0]
000079f4d2de1835  vmovaps xmm12, [rsp+0xB0]
000079f4d2de183e  vmovaps xmm13, [rsp+0xC0]
000079f4d2de1847  vmovaps xmm14, [rsp+0xD0]
000079f4d2de1850  vmovaps xmm15, [rsp+0xE0]
000079f4d2de1859  add rsp, 0xF0
000079f4d2de1860  pop r11
000079f4d2de1862  pop r10
000079f4d2de1864  pop r9
000079f4d2de1866  pop r8
000079f4d2de1868  pop rsi
000079f4d2de1869  pop rdi
000079f4d2de186a  pop rdx
000079f4d2de186b  pop rcx
000079f4d2de186c  pop rax
000079f4d2de186d  add rsp, 0x08
000079f4d2de1871  jmp 0x000079F4D2DDF33E
000079f4d2de1876  sub rsp, 0x08
000079f4d2de187a  push rax
000079f4d2de187b  push rcx
000079f4d2de187c  push rdx
000079f4d2de187d  push rdi
000079f4d2de187e  push rsi
000079f4d2de187f  push r8
000079f4d2de1881  push r9
000079f4d2de1883  push r10
000079f4d2de1885  push r11
000079f4d2de1887  sub rsp, 0xF0
000079f4d2de188e  vmovaps [rsp], xmm0
000079f4d2de1893  vmovaps [rsp+0x10], xmm1
000079f4d2de1899  vmovaps [rsp+0x20], xmm2
000079f4d2de189f  vmovaps [rsp+0x30], xmm3
000079f4d2de18a5  vmovaps [rsp+0x40], xmm4
000079f4d2de18ab  vmovaps [rsp+0x50], xmm5
000079f4d2de18b1  vmovaps [rsp+0x60], xmm6
000079f4d2de18b7  vmovaps [rsp+0x70], xmm7
000079f4d2de18bd  vmovaps [rsp+0x80], xmm8
000079f4d2de18c6  vmovaps [rsp+0x90], xmm10
000079f4d2de18cf  vmovaps [rsp+0xA0], xmm11
000079f4d2de18d8  vmovaps [rsp+0xB0], xmm12
000079f4d2de18e1  vmovaps [rsp+0xC0], xmm13
000079f4d2de18ea  vmovaps [rsp+0xD0], xmm14
000079f4d2de18f3  vmovaps [rsp+0xE0], xmm15
000079f4d2de18fc  sub rsp, 0x30
000079f4d2de1900  movaps [rsp], xmm9
000079f4d2de1905  movaps [rsp+0x10], xmm3
000079f4d2de190a  movaps [rsp+0x20], xmm1
000079f4d2de190f  lea rdi, [rsp]
000079f4d2de1913  mov esi, 0x00
000079f4d2de1918  mov rax, 0x5D9EC01E8530
000079f4d2de1922  call rax
000079f4d2de1924  movaps xmm9, [rsp]
000079f4d2de1929  add rsp, 0x30
000079f4d2de192d  vmovaps xmm0, [rsp]
000079f4d2de1932  vmovaps xmm1, [rsp+0x10]
000079f4d2de1938  vmovaps xmm2, [rsp+0x20]
000079f4d2de193e  vmovaps xmm3, [rsp+0x30]
000079f4d2de1944  vmovaps xmm4, [rsp+0x40]
000079f4d2de194a  vmovaps xmm5, [rsp+0x50]
000079f4d2de1950  vmovaps xmm6, [rsp+0x60]
000079f4d2de1956  vmovaps xmm7, [rsp+0x70]
000079f4d2de195c  vmovaps xmm8, [rsp+0x80]
000079f4d2de1965  vmovaps xmm10, [rsp+0x90]
000079f4d2de196e  vmovaps xmm11, [rsp+0xA0]
000079f4d2de1977  vmovaps xmm12, [rsp+0xB0]
000079f4d2de1980  vmovaps xmm13, [rsp+0xC0]
000079f4d2de1989  vmovaps xmm14, [rsp+0xD0]
000079f4d2de1992  vmovaps xmm15, [rsp+0xE0]
000079f4d2de199b  add rsp, 0xF0
000079f4d2de19a2  pop r11
000079f4d2de19a4  pop r10
000079f4d2de19a6  pop r9
000079f4d2de19a8  pop r8
000079f4d2de19aa  pop rsi
000079f4d2de19ab  pop rdi
000079f4d2de19ac  pop rdx
000079f4d2de19ad  pop rcx
000079f4d2de19ae  pop rax
000079f4d2de19af  add rsp, 0x08
000079f4d2de19b3  jmp 0x000079F4D2DDF38A
000079f4d2de19b8  call 0x000079F4D2CB52F0
000079f4d2de19bd  jmp 0x000079F4D2DDF397
000079f4d2de19c2  sub rsp, 0x08
000079f4d2de19c6  push rax
000079f4d2de19c7  push rcx
000079f4d2de19c8  push rdx
000079f4d2de19c9  push rdi
000079f4d2de19ca  push rsi
000079f4d2de19cb  push r8
000079f4d2de19cd  push r9
000079f4d2de19cf  push r10
000079f4d2de19d1  push r11
000079f4d2de19d3  sub rsp, 0xF0
000079f4d2de19da  vmovaps [rsp], xmm0
000079f4d2de19df  vmovaps [rsp+0x10], xmm1
000079f4d2de19e5  vmovaps [rsp+0x20], xmm2
000079f4d2de19eb  vmovaps [rsp+0x30], xmm3
000079f4d2de19f1  vmovaps [rsp+0x40], xmm4
000079f4d2de19f7  vmovaps [rsp+0x50], xmm5
000079f4d2de19fd  vmovaps [rsp+0x60], xmm6
000079f4d2de1a03  vmovaps [rsp+0x70], xmm7
000079f4d2de1a09  vmovaps [rsp+0x80], xmm8
000079f4d2de1a12  vmovaps [rsp+0x90], xmm9
000079f4d2de1a1b  vmovaps [rsp+0xA0], xmm10
000079f4d2de1a24  vmovaps [rsp+0xB0], xmm11
000079f4d2de1a2d  vmovaps [rsp+0xC0], xmm12
000079f4d2de1a36  vmovaps [rsp+0xD0], xmm13
000079f4d2de1a3f  vmovaps [rsp+0xE0], xmm14
000079f4d2de1a48  sub rsp, 0x30
000079f4d2de1a4c  movaps [rsp], xmm15
000079f4d2de1a51  movaps [rsp+0x10], xmm3
000079f4d2de1a56  movaps [rsp+0x20], xmm7
000079f4d2de1a5b  lea rdi, [rsp]
000079f4d2de1a5f  mov esi, 0x00
000079f4d2de1a64  mov rax, 0x5D9EC01E8530
000079f4d2de1a6e  call rax
000079f4d2de1a70  movaps xmm15, [rsp]
000079f4d2de1a75  add rsp, 0x30
000079f4d2de1a79  vmovaps xmm0, [rsp]
000079f4d2de1a7e  vmovaps xmm1, [rsp+0x10]
000079f4d2de1a84  vmovaps xmm2, [rsp+0x20]
000079f4d2de1a8a  vmovaps xmm3, [rsp+0x30]
000079f4d2de1a90  vmovaps xmm4, [rsp+0x40]
000079f4d2de1a96  vmovaps xmm5, [rsp+0x50]
000079f4d2de1a9c  vmovaps xmm6, [rsp+0x60]
000079f4d2de1aa2  vmovaps xmm7, [rsp+0x70]
000079f4d2de1aa8  vmovaps xmm8, [rsp+0x80]
000079f4d2de1ab1  vmovaps xmm9, [rsp+0x90]
000079f4d2de1aba  vmovaps xmm10, [rsp+0xA0]
000079f4d2de1ac3  vmovaps xmm11, [rsp+0xB0]
000079f4d2de1acc  vmovaps xmm12, [rsp+0xC0]
000079f4d2de1ad5  vmovaps xmm13, [rsp+0xD0]
000079f4d2de1ade  vmovaps xmm14, [rsp+0xE0]
000079f4d2de1ae7  add rsp, 0xF0
000079f4d2de1aee  pop r11
000079f4d2de1af0  pop r10
000079f4d2de1af2  pop r9
000079f4d2de1af4  pop r8
000079f4d2de1af6  pop rsi
000079f4d2de1af7  pop rdi
000079f4d2de1af8  pop rdx
000079f4d2de1af9  pop rcx
000079f4d2de1afa  pop rax
000079f4d2de1afb  add rsp, 0x08
000079f4d2de1aff  jmp 0x000079F4D2DDF3C3
000079f4d2de1b04  sub rsp, 0x08
000079f4d2de1b08  push rax
000079f4d2de1b09  push rcx
000079f4d2de1b0a  push rdx
000079f4d2de1b0b  push rdi
000079f4d2de1b0c  push rsi
000079f4d2de1b0d  push r8
000079f4d2de1b0f  push r9
000079f4d2de1b11  push r10
000079f4d2de1b13  push r11
000079f4d2de1b15  sub rsp, 0xF0
000079f4d2de1b1c  vmovaps [rsp], xmm0
000079f4d2de1b21  vmovaps [rsp+0x10], xmm1
000079f4d2de1b27  vmovaps [rsp+0x20], xmm2
000079f4d2de1b2d  vmovaps [rsp+0x30], xmm4
000079f4d2de1b33  vmovaps [rsp+0x40], xmm5
000079f4d2de1b39  vmovaps [rsp+0x50], xmm6
000079f4d2de1b3f  vmovaps [rsp+0x60], xmm7
000079f4d2de1b45  vmovaps [rsp+0x70], xmm8
000079f4d2de1b4b  vmovaps [rsp+0x80], xmm9
000079f4d2de1b54  vmovaps [rsp+0x90], xmm10
000079f4d2de1b5d  vmovaps [rsp+0xA0], xmm11
000079f4d2de1b66  vmovaps [rsp+0xB0], xmm12
000079f4d2de1b6f  vmovaps [rsp+0xC0], xmm13
000079f4d2de1b78  vmovaps [rsp+0xD0], xmm14
000079f4d2de1b81  vmovaps [rsp+0xE0], xmm15
000079f4d2de1b8a  sub rsp, 0x30
000079f4d2de1b8e  movaps [rsp], xmm3
000079f4d2de1b92  movaps [rsp+0x10], xmm1
000079f4d2de1b97  movaps [rsp+0x20], xmm15
000079f4d2de1b9d  lea rdi, [rsp]
000079f4d2de1ba1  mov esi, 0x00
000079f4d2de1ba6  mov rax, 0x5D9EC01E8530
000079f4d2de1bb0  call rax
000079f4d2de1bb2  movaps xmm3, [rsp]
000079f4d2de1bb6  add rsp, 0x30
000079f4d2de1bba  vmovaps xmm0, [rsp]
000079f4d2de1bbf  vmovaps xmm1, [rsp+0x10]
000079f4d2de1bc5  vmovaps xmm2, [rsp+0x20]
000079f4d2de1bcb  vmovaps xmm4, [rsp+0x30]
000079f4d2de1bd1  vmovaps xmm5, [rsp+0x40]
000079f4d2de1bd7  vmovaps xmm6, [rsp+0x50]
000079f4d2de1bdd  vmovaps xmm7, [rsp+0x60]
000079f4d2de1be3  vmovaps xmm8, [rsp+0x70]
000079f4d2de1be9  vmovaps xmm9, [rsp+0x80]
000079f4d2de1bf2  vmovaps xmm10, [rsp+0x90]
000079f4d2de1bfb  vmovaps xmm11, [rsp+0xA0]
000079f4d2de1c04  vmovaps xmm12, [rsp+0xB0]
000079f4d2de1c0d  vmovaps xmm13, [rsp+0xC0]
000079f4d2de1c16  vmovaps xmm14, [rsp+0xD0]
000079f4d2de1c1f  vmovaps xmm15, [rsp+0xE0]
000079f4d2de1c28  add rsp, 0xF0
000079f4d2de1c2f  pop r11
000079f4d2de1c31  pop r10
000079f4d2de1c33  pop r9
000079f4d2de1c35  pop r8
000079f4d2de1c37  pop rsi
000079f4d2de1c38  pop rdi
000079f4d2de1c39  pop rdx
000079f4d2de1c3a  pop rcx
000079f4d2de1c3b  pop rax
000079f4d2de1c3c  add rsp, 0x08
000079f4d2de1c40  jmp 0x000079F4D2DDF452
000079f4d2de1c45  call 0x000079F4D2CB52F0
000079f4d2de1c4a  jmp 0x000079F4D2DDF45C
000079f4d2de1c4f  sub rsp, 0x08
000079f4d2de1c53  push rax
000079f4d2de1c54  push rcx
000079f4d2de1c55  push rdx
000079f4d2de1c56  push rdi
000079f4d2de1c57  push rsi
000079f4d2de1c58  push r8
000079f4d2de1c5a  push r9
000079f4d2de1c5c  push r10
000079f4d2de1c5e  push r11
000079f4d2de1c60  sub rsp, 0xF0
000079f4d2de1c67  vmovaps [rsp], xmm0
000079f4d2de1c6c  vmovaps [rsp+0x10], xmm1
000079f4d2de1c72  vmovaps [rsp+0x20], xmm2
000079f4d2de1c78  vmovaps [rsp+0x30], xmm3
000079f4d2de1c7e  vmovaps [rsp+0x40], xmm4
000079f4d2de1c84  vmovaps [rsp+0x50], xmm5
000079f4d2de1c8a  vmovaps [rsp+0x60], xmm6
000079f4d2de1c90  vmovaps [rsp+0x70], xmm7
000079f4d2de1c96  vmovaps [rsp+0x80], xmm8
000079f4d2de1c9f  vmovaps [rsp+0x90], xmm9
000079f4d2de1ca8  vmovaps [rsp+0xA0], xmm10
000079f4d2de1cb1  vmovaps [rsp+0xB0], xmm11
000079f4d2de1cba  vmovaps [rsp+0xC0], xmm12
000079f4d2de1cc3  vmovaps [rsp+0xD0], xmm13
000079f4d2de1ccc  vmovaps [rsp+0xE0], xmm14
000079f4d2de1cd5  sub rsp, 0x30
000079f4d2de1cd9  movaps [rsp], xmm15
000079f4d2de1cde  movaps [rsp+0x10], xmm14
000079f4d2de1ce4  movaps [rsp+0x20], xmm4
000079f4d2de1ce9  lea rdi, [rsp]
000079f4d2de1ced  mov esi, 0x00
000079f4d2de1cf2  mov rax, 0x5D9EC01E8530
000079f4d2de1cfc  call rax
000079f4d2de1cfe  movaps xmm15, [rsp]
000079f4d2de1d03  add rsp, 0x30
000079f4d2de1d07  vmovaps xmm0, [rsp]
000079f4d2de1d0c  vmovaps xmm1, [rsp+0x10]
000079f4d2de1d12  vmovaps xmm2, [rsp+0x20]
000079f4d2de1d18  vmovaps xmm3, [rsp+0x30]
000079f4d2de1d1e  vmovaps xmm4, [rsp+0x40]
000079f4d2de1d24  vmovaps xmm5, [rsp+0x50]
000079f4d2de1d2a  vmovaps xmm6, [rsp+0x60]
000079f4d2de1d30  vmovaps xmm7, [rsp+0x70]
000079f4d2de1d36  vmovaps xmm8, [rsp+0x80]
000079f4d2de1d3f  vmovaps xmm9, [rsp+0x90]
000079f4d2de1d48  vmovaps xmm10, [rsp+0xA0]
000079f4d2de1d51  vmovaps xmm11, [rsp+0xB0]
000079f4d2de1d5a  vmovaps xmm12, [rsp+0xC0]
000079f4d2de1d63  vmovaps xmm13, [rsp+0xD0]
000079f4d2de1d6c  vmovaps xmm14, [rsp+0xE0]
000079f4d2de1d75  add rsp, 0xF0
000079f4d2de1d7c  pop r11
000079f4d2de1d7e  pop r10
000079f4d2de1d80  pop r9
000079f4d2de1d82  pop r8
000079f4d2de1d84  pop rsi
000079f4d2de1d85  pop rdi
000079f4d2de1d86  pop rdx
000079f4d2de1d87  pop rcx
000079f4d2de1d88  pop rax
000079f4d2de1d89  add rsp, 0x08
000079f4d2de1d8d  jmp 0x000079F4D2DDF48A
000079f4d2de1d92  sub rsp, 0x08
000079f4d2de1d96  push rax
000079f4d2de1d97  push rcx
000079f4d2de1d98  push rdx
000079f4d2de1d99  push rdi
000079f4d2de1d9a  push rsi
000079f4d2de1d9b  push r8
000079f4d2de1d9d  push r9
000079f4d2de1d9f  push r10
000079f4d2de1da1  push r11
000079f4d2de1da3  sub rsp, 0xF0
000079f4d2de1daa  vmovaps [rsp], xmm0
000079f4d2de1daf  vmovaps [rsp+0x10], xmm1
000079f4d2de1db5  vmovaps [rsp+0x20], xmm2
000079f4d2de1dbb  vmovaps [rsp+0x30], xmm3
000079f4d2de1dc1  vmovaps [rsp+0x40], xmm4
000079f4d2de1dc7  vmovaps [rsp+0x50], xmm5
000079f4d2de1dcd  vmovaps [rsp+0x60], xmm6
000079f4d2de1dd3  vmovaps [rsp+0x70], xmm7
000079f4d2de1dd9  vmovaps [rsp+0x80], xmm8
000079f4d2de1de2  vmovaps [rsp+0x90], xmm9
000079f4d2de1deb  vmovaps [rsp+0xA0], xmm10
000079f4d2de1df4  vmovaps [rsp+0xB0], xmm11
000079f4d2de1dfd  vmovaps [rsp+0xC0], xmm12
000079f4d2de1e06  vmovaps [rsp+0xD0], xmm13
000079f4d2de1e0f  vmovaps [rsp+0xE0], xmm15
000079f4d2de1e18  sub rsp, 0x30
000079f4d2de1e1c  movaps [rsp], xmm14
000079f4d2de1e21  movaps [rsp+0x10], xmm2
000079f4d2de1e26  movaps [rsp+0x20], xmm1
000079f4d2de1e2b  lea rdi, [rsp]
000079f4d2de1e2f  mov esi, 0x00
000079f4d2de1e34  mov rax, 0x5D9EC01E8530
000079f4d2de1e3e  call rax
000079f4d2de1e40  movaps xmm14, [rsp]
000079f4d2de1e45  add rsp, 0x30
000079f4d2de1e49  vmovaps xmm0, [rsp]
000079f4d2de1e4e  vmovaps xmm1, [rsp+0x10]
000079f4d2de1e54  vmovaps xmm2, [rsp+0x20]
000079f4d2de1e5a  vmovaps xmm3, [rsp+0x30]
000079f4d2de1e60  vmovaps xmm4, [rsp+0x40]
000079f4d2de1e66  vmovaps xmm5, [rsp+0x50]
000079f4d2de1e6c  vmovaps xmm6, [rsp+0x60]
000079f4d2de1e72  vmovaps xmm7, [rsp+0x70]
000079f4d2de1e78  vmovaps xmm8, [rsp+0x80]
000079f4d2de1e81  vmovaps xmm9, [rsp+0x90]
000079f4d2de1e8a  vmovaps xmm10, [rsp+0xA0]
000079f4d2de1e93  vmovaps xmm11, [rsp+0xB0]
000079f4d2de1e9c  vmovaps xmm12, [rsp+0xC0]
000079f4d2de1ea5  vmovaps xmm13, [rsp+0xD0]
000079f4d2de1eae  vmovaps xmm15, [rsp+0xE0]
000079f4d2de1eb7  add rsp, 0xF0
000079f4d2de1ebe  pop r11
000079f4d2de1ec0  pop r10
000079f4d2de1ec2  pop r9
000079f4d2de1ec4  pop r8
000079f4d2de1ec6  pop rsi
000079f4d2de1ec7  pop rdi
000079f4d2de1ec8  pop rdx
000079f4d2de1ec9  pop rcx
000079f4d2de1eca  pop rax
000079f4d2de1ecb  add rsp, 0x08
000079f4d2de1ecf  jmp 0x000079F4D2DDF4B0
000079f4d2de1ed4  sub rsp, 0x08
000079f4d2de1ed8  push rax
000079f4d2de1ed9  push rcx
000079f4d2de1eda  push rdx
000079f4d2de1edb  push rdi
000079f4d2de1edc  push rsi
000079f4d2de1edd  push r8
000079f4d2de1edf  push r9
000079f4d2de1ee1  push r10
000079f4d2de1ee3  push r11
000079f4d2de1ee5  sub rsp, 0xF0
000079f4d2de1eec  vmovaps [rsp], xmm0
000079f4d2de1ef1  vmovaps [rsp+0x10], xmm2
000079f4d2de1ef7  vmovaps [rsp+0x20], xmm3
000079f4d2de1efd  vmovaps [rsp+0x30], xmm4
000079f4d2de1f03  vmovaps [rsp+0x40], xmm5
000079f4d2de1f09  vmovaps [rsp+0x50], xmm6
000079f4d2de1f0f  vmovaps [rsp+0x60], xmm7
000079f4d2de1f15  vmovaps [rsp+0x70], xmm8
000079f4d2de1f1b  vmovaps [rsp+0x80], xmm9
000079f4d2de1f24  vmovaps [rsp+0x90], xmm10
000079f4d2de1f2d  vmovaps [rsp+0xA0], xmm11
000079f4d2de1f36  vmovaps [rsp+0xB0], xmm12
000079f4d2de1f3f  vmovaps [rsp+0xC0], xmm13
000079f4d2de1f48  vmovaps [rsp+0xD0], xmm14
000079f4d2de1f51  vmovaps [rsp+0xE0], xmm15
000079f4d2de1f5a  sub rsp, 0x30
000079f4d2de1f5e  movaps [rsp], xmm1
000079f4d2de1f62  movaps [rsp+0x10], xmm4
000079f4d2de1f67  movaps [rsp+0x20], xmm9
000079f4d2de1f6d  lea rdi, [rsp]
000079f4d2de1f71  mov esi, 0x00
000079f4d2de1f76  mov rax, 0x5D9EC01E8530
000079f4d2de1f80  call rax
000079f4d2de1f82  movaps xmm1, [rsp]
000079f4d2de1f86  add rsp, 0x30
000079f4d2de1f8a  vmovaps xmm0, [rsp]
000079f4d2de1f8f  vmovaps xmm2, [rsp+0x10]
000079f4d2de1f95  vmovaps xmm3, [rsp+0x20]
000079f4d2de1f9b  vmovaps xmm4, [rsp+0x30]
000079f4d2de1fa1  vmovaps xmm5, [rsp+0x40]
000079f4d2de1fa7  vmovaps xmm6, [rsp+0x50]
000079f4d2de1fad  vmovaps xmm7, [rsp+0x60]
000079f4d2de1fb3  vmovaps xmm8, [rsp+0x70]
000079f4d2de1fb9  vmovaps xmm9, [rsp+0x80]
000079f4d2de1fc2  vmovaps xmm10, [rsp+0x90]
000079f4d2de1fcb  vmovaps xmm11, [rsp+0xA0]
000079f4d2de1fd4  vmovaps xmm12, [rsp+0xB0]
000079f4d2de1fdd  vmovaps xmm13, [rsp+0xC0]
000079f4d2de1fe6  vmovaps xmm14, [rsp+0xD0]
000079f4d2de1fef  vmovaps xmm15, [rsp+0xE0]
000079f4d2de1ff8  add rsp, 0xF0
000079f4d2de1fff  pop r11
000079f4d2de2001  pop r10
000079f4d2de2003  pop r9
000079f4d2de2005  pop r8
000079f4d2de2007  pop rsi
000079f4d2de2008  pop rdi
000079f4d2de2009  pop rdx
000079f4d2de200a  pop rcx
000079f4d2de200b  pop rax
000079f4d2de200c  add rsp, 0x08
000079f4d2de2010  jmp 0x000079F4D2DDF4CE
000079f4d2de2015  sub rsp, 0x08
000079f4d2de2019  push rax
000079f4d2de201a  push rcx
000079f4d2de201b  push rdx
000079f4d2de201c  push rdi
000079f4d2de201d  push rsi
000079f4d2de201e  push r8
000079f4d2de2020  push r9
000079f4d2de2022  push r10
000079f4d2de2024  push r11
000079f4d2de2026  sub rsp, 0xF0
000079f4d2de202d  vmovaps [rsp], xmm0
000079f4d2de2032  vmovaps [rsp+0x10], xmm1
000079f4d2de2038  vmovaps [rsp+0x20], xmm2
000079f4d2de203e  vmovaps [rsp+0x30], xmm3
000079f4d2de2044  vmovaps [rsp+0x40], xmm5
000079f4d2de204a  vmovaps [rsp+0x50], xmm6
000079f4d2de2050  vmovaps [rsp+0x60], xmm7
000079f4d2de2056  vmovaps [rsp+0x70], xmm8
000079f4d2de205c  vmovaps [rsp+0x80], xmm9
000079f4d2de2065  vmovaps [rsp+0x90], xmm10
000079f4d2de206e  vmovaps [rsp+0xA0], xmm11
000079f4d2de2077  vmovaps [rsp+0xB0], xmm12
000079f4d2de2080  vmovaps [rsp+0xC0], xmm13
000079f4d2de2089  vmovaps [rsp+0xD0], xmm14
000079f4d2de2092  vmovaps [rsp+0xE0], xmm15
000079f4d2de209b  sub rsp, 0x30
000079f4d2de209f  movaps [rsp], xmm4
000079f4d2de20a3  movaps [rsp+0x10], xmm2
000079f4d2de20a8  movaps [rsp+0x20], xmm9
000079f4d2de20ae  lea rdi, [rsp]
000079f4d2de20b2  mov esi, 0x00
000079f4d2de20b7  mov rax, 0x5D9EC01E8530
000079f4d2de20c1  call rax
000079f4d2de20c3  movaps xmm4, [rsp]
000079f4d2de20c7  add rsp, 0x30
000079f4d2de20cb  vmovaps xmm0, [rsp]
000079f4d2de20d0  vmovaps xmm1, [rsp+0x10]
000079f4d2de20d6  vmovaps xmm2, [rsp+0x20]
000079f4d2de20dc  vmovaps xmm3, [rsp+0x30]
000079f4d2de20e2  vmovaps xmm5, [rsp+0x40]
000079f4d2de20e8  vmovaps xmm6, [rsp+0x50]
000079f4d2de20ee  vmovaps xmm7, [rsp+0x60]
000079f4d2de20f4  vmovaps xmm8, [rsp+0x70]
000079f4d2de20fa  vmovaps xmm9, [rsp+0x80]
000079f4d2de2103  vmovaps xmm10, [rsp+0x90]
000079f4d2de210c  vmovaps xmm11, [rsp+0xA0]
000079f4d2de2115  vmovaps xmm12, [rsp+0xB0]
000079f4d2de211e  vmovaps xmm13, [rsp+0xC0]
000079f4d2de2127  vmovaps xmm14, [rsp+0xD0]
000079f4d2de2130  vmovaps xmm15, [rsp+0xE0]
000079f4d2de2139  add rsp, 0xF0
000079f4d2de2140  pop r11
000079f4d2de2142  pop r10
000079f4d2de2144  pop r9
000079f4d2de2146  pop r8
000079f4d2de2148  pop rsi
000079f4d2de2149  pop rdi
000079f4d2de214a  pop rdx
000079f4d2de214b  pop rcx
000079f4d2de214c  pop rax
000079f4d2de214d  add rsp, 0x08
000079f4d2de2151  jmp 0x000079F4D2DDF4FE
000079f4d2de2156  sub rsp, 0x08
000079f4d2de215a  push rax
000079f4d2de215b  push rcx
000079f4d2de215c  push rdx
000079f4d2de215d  push rdi
000079f4d2de215e  push rsi
000079f4d2de215f  push r8
000079f4d2de2161  push r9
000079f4d2de2163  push r10
000079f4d2de2165  push r11
000079f4d2de2167  sub rsp, 0xF0
000079f4d2de216e  vmovaps [rsp], xmm0
000079f4d2de2173  vmovaps [rsp+0x10], xmm1
000079f4d2de2179  vmovaps [rsp+0x20], xmm2
000079f4d2de217f  vmovaps [rsp+0x30], xmm3
000079f4d2de2185  vmovaps [rsp+0x40], xmm4
000079f4d2de218b  vmovaps [rsp+0x50], xmm5
000079f4d2de2191  vmovaps [rsp+0x60], xmm6
000079f4d2de2197  vmovaps [rsp+0x70], xmm7
000079f4d2de219d  vmovaps [rsp+0x80], xmm8
000079f4d2de21a6  vmovaps [rsp+0x90], xmm10
000079f4d2de21af  vmovaps [rsp+0xA0], xmm11
000079f4d2de21b8  vmovaps [rsp+0xB0], xmm12
000079f4d2de21c1  vmovaps [rsp+0xC0], xmm13
000079f4d2de21ca  vmovaps [rsp+0xD0], xmm14
000079f4d2de21d3  vmovaps [rsp+0xE0], xmm15
000079f4d2de21dc  sub rsp, 0x30
000079f4d2de21e0  movaps [rsp], xmm9
000079f4d2de21e5  movaps [rsp+0x10], xmm2
000079f4d2de21ea  movaps [rsp+0x20], xmm1
000079f4d2de21ef  lea rdi, [rsp]
000079f4d2de21f3  mov esi, 0x00
000079f4d2de21f8  mov rax, 0x5D9EC01E8530
000079f4d2de2202  call rax
000079f4d2de2204  movaps xmm9, [rsp]
000079f4d2de2209  add rsp, 0x30
000079f4d2de220d  vmovaps xmm0, [rsp]
000079f4d2de2212  vmovaps xmm1, [rsp+0x10]
000079f4d2de2218  vmovaps xmm2, [rsp+0x20]
000079f4d2de221e  vmovaps xmm3, [rsp+0x30]
000079f4d2de2224  vmovaps xmm4, [rsp+0x40]
000079f4d2de222a  vmovaps xmm5, [rsp+0x50]
000079f4d2de2230  vmovaps xmm6, [rsp+0x60]
000079f4d2de2236  vmovaps xmm7, [rsp+0x70]
000079f4d2de223c  vmovaps xmm8, [rsp+0x80]
000079f4d2de2245  vmovaps xmm10, [rsp+0x90]
000079f4d2de224e  vmovaps xmm11, [rsp+0xA0]
000079f4d2de2257  vmovaps xmm12, [rsp+0xB0]
000079f4d2de2260  vmovaps xmm13, [rsp+0xC0]
000079f4d2de2269  vmovaps xmm14, [rsp+0xD0]
000079f4d2de2272  vmovaps xmm15, [rsp+0xE0]
000079f4d2de227b  add rsp, 0xF0
000079f4d2de2282  pop r11
000079f4d2de2284  pop r10
000079f4d2de2286  pop r9
000079f4d2de2288  pop r8
000079f4d2de228a  pop rsi
000079f4d2de228b  pop rdi
000079f4d2de228c  pop rdx
000079f4d2de228d  pop rcx
000079f4d2de228e  pop rax
000079f4d2de228f  add rsp, 0x08
000079f4d2de2293  jmp 0x000079F4D2DDF534
000079f4d2de2298  sub rsp, 0x08
000079f4d2de229c  push rax
000079f4d2de229d  push rcx
000079f4d2de229e  push rdx
000079f4d2de229f  push rdi
000079f4d2de22a0  push rsi
000079f4d2de22a1  push r8
000079f4d2de22a3  push r9
000079f4d2de22a5  push r10
000079f4d2de22a7  push r11
000079f4d2de22a9  sub rsp, 0xF0
000079f4d2de22b0  vmovaps [rsp], xmm0
000079f4d2de22b5  vmovaps [rsp+0x10], xmm2
000079f4d2de22bb  vmovaps [rsp+0x20], xmm3
000079f4d2de22c1  vmovaps [rsp+0x30], xmm4
000079f4d2de22c7  vmovaps [rsp+0x40], xmm5
000079f4d2de22cd  vmovaps [rsp+0x50], xmm6
000079f4d2de22d3  vmovaps [rsp+0x60], xmm7
000079f4d2de22d9  vmovaps [rsp+0x70], xmm8
000079f4d2de22df  vmovaps [rsp+0x80], xmm9
000079f4d2de22e8  vmovaps [rsp+0x90], xmm10
000079f4d2de22f1  vmovaps [rsp+0xA0], xmm11
000079f4d2de22fa  vmovaps [rsp+0xB0], xmm12
000079f4d2de2303  vmovaps [rsp+0xC0], xmm13
000079f4d2de230c  vmovaps [rsp+0xD0], xmm14
000079f4d2de2315  vmovaps [rsp+0xE0], xmm15
000079f4d2de231e  sub rsp, 0x30
000079f4d2de2322  movaps [rsp], xmm1
000079f4d2de2326  movaps [rsp+0x10], xmm15
000079f4d2de232c  movaps [rsp+0x20], xmm6
000079f4d2de2331  lea rdi, [rsp]
000079f4d2de2335  mov esi, 0x00
000079f4d2de233a  mov rax, 0x5D9EC01E8530
000079f4d2de2344  call rax
000079f4d2de2346  movaps xmm1, [rsp]
000079f4d2de234a  add rsp, 0x30
000079f4d2de234e  vmovaps xmm0, [rsp]
000079f4d2de2353  vmovaps xmm2, [rsp+0x10]
000079f4d2de2359  vmovaps xmm3, [rsp+0x20]
000079f4d2de235f  vmovaps xmm4, [rsp+0x30]
000079f4d2de2365  vmovaps xmm5, [rsp+0x40]
000079f4d2de236b  vmovaps xmm6, [rsp+0x50]
000079f4d2de2371  vmovaps xmm7, [rsp+0x60]
000079f4d2de2377  vmovaps xmm8, [rsp+0x70]
000079f4d2de237d  vmovaps xmm9, [rsp+0x80]
000079f4d2de2386  vmovaps xmm10, [rsp+0x90]
000079f4d2de238f  vmovaps xmm11, [rsp+0xA0]
000079f4d2de2398  vmovaps xmm12, [rsp+0xB0]
000079f4d2de23a1  vmovaps xmm13, [rsp+0xC0]
000079f4d2de23aa  vmovaps xmm14, [rsp+0xD0]
000079f4d2de23b3  vmovaps xmm15, [rsp+0xE0]
000079f4d2de23bc  add rsp, 0xF0
000079f4d2de23c3  pop r11
000079f4d2de23c5  pop r10
000079f4d2de23c7  pop r9
000079f4d2de23c9  pop r8
000079f4d2de23cb  pop rsi
000079f4d2de23cc  pop rdi
000079f4d2de23cd  pop rdx
000079f4d2de23ce  pop rcx
000079f4d2de23cf  pop rax
000079f4d2de23d0  add rsp, 0x08
000079f4d2de23d4  jmp 0x000079F4D2DDF555
000079f4d2de23d9  sub rsp, 0x08
000079f4d2de23dd  push rax
000079f4d2de23de  push rcx
000079f4d2de23df  push rdx
000079f4d2de23e0  push rdi
000079f4d2de23e1  push rsi
000079f4d2de23e2  push r8
000079f4d2de23e4  push r9
000079f4d2de23e6  push r10
000079f4d2de23e8  push r11
000079f4d2de23ea  sub rsp, 0xF0
000079f4d2de23f1  vmovaps [rsp], xmm0
000079f4d2de23f6  vmovaps [rsp+0x10], xmm1
000079f4d2de23fc  vmovaps [rsp+0x20], xmm2
000079f4d2de2402  vmovaps [rsp+0x30], xmm3
000079f4d2de2408  vmovaps [rsp+0x40], xmm4
000079f4d2de240e  vmovaps [rsp+0x50], xmm5
000079f4d2de2414  vmovaps [rsp+0x60], xmm6
000079f4d2de241a  vmovaps [rsp+0x70], xmm7
000079f4d2de2420  vmovaps [rsp+0x80], xmm8
000079f4d2de2429  vmovaps [rsp+0x90], xmm9
000079f4d2de2432  vmovaps [rsp+0xA0], xmm10
000079f4d2de243b  vmovaps [rsp+0xB0], xmm11
000079f4d2de2444  vmovaps [rsp+0xC0], xmm12
000079f4d2de244d  vmovaps [rsp+0xD0], xmm13
000079f4d2de2456  vmovaps [rsp+0xE0], xmm14
000079f4d2de245f  sub rsp, 0x30
000079f4d2de2463  movaps [rsp], xmm15
000079f4d2de2468  movaps [rsp+0x10], xmm5
000079f4d2de246d  movaps [rsp+0x20], xmm3
000079f4d2de2472  lea rdi, [rsp]
000079f4d2de2476  mov esi, 0x00
000079f4d2de247b  mov rax, 0x5D9EC01E8530
000079f4d2de2485  call rax
000079f4d2de2487  movaps xmm15, [rsp]
000079f4d2de248c  add rsp, 0x30
000079f4d2de2490  vmovaps xmm0, [rsp]
000079f4d2de2495  vmovaps xmm1, [rsp+0x10]
000079f4d2de249b  vmovaps xmm2, [rsp+0x20]
000079f4d2de24a1  vmovaps xmm3, [rsp+0x30]
000079f4d2de24a7  vmovaps xmm4, [rsp+0x40]
000079f4d2de24ad  vmovaps xmm5, [rsp+0x50]
000079f4d2de24b3  vmovaps xmm6, [rsp+0x60]
000079f4d2de24b9  vmovaps xmm7, [rsp+0x70]
000079f4d2de24bf  vmovaps xmm8, [rsp+0x80]
000079f4d2de24c8  vmovaps xmm9, [rsp+0x90]
000079f4d2de24d1  vmovaps xmm10, [rsp+0xA0]
000079f4d2de24da  vmovaps xmm11, [rsp+0xB0]
000079f4d2de24e3  vmovaps xmm12, [rsp+0xC0]
000079f4d2de24ec  vmovaps xmm13, [rsp+0xD0]
000079f4d2de24f5  vmovaps xmm14, [rsp+0xE0]
000079f4d2de24fe  add rsp, 0xF0
000079f4d2de2505  pop r11
000079f4d2de2507  pop r10
000079f4d2de2509  pop r9
000079f4d2de250b  pop r8
000079f4d2de250d  pop rsi
000079f4d2de250e  pop rdi
000079f4d2de250f  pop rdx
000079f4d2de2510  pop rcx
000079f4d2de2511  pop rax
000079f4d2de2512  add rsp, 0x08
000079f4d2de2516  jmp 0x000079F4D2DDF56F
000079f4d2de251b  sub rsp, 0x08
000079f4d2de251f  push rax
000079f4d2de2520  push rcx
000079f4d2de2521  push rdx
000079f4d2de2522  push rdi
000079f4d2de2523  push rsi
000079f4d2de2524  push r8
000079f4d2de2526  push r9
000079f4d2de2528  push r10
000079f4d2de252a  push r11
000079f4d2de252c  sub rsp, 0xF0
000079f4d2de2533  vmovaps [rsp], xmm0
000079f4d2de2538  vmovaps [rsp+0x10], xmm1
000079f4d2de253e  vmovaps [rsp+0x20], xmm2
000079f4d2de2544  vmovaps [rsp+0x30], xmm3
000079f4d2de254a  vmovaps [rsp+0x40], xmm4
000079f4d2de2550  vmovaps [rsp+0x50], xmm6
000079f4d2de2556  vmovaps [rsp+0x60], xmm7
000079f4d2de255c  vmovaps [rsp+0x70], xmm8
000079f4d2de2562  vmovaps [rsp+0x80], xmm9
000079f4d2de256b  vmovaps [rsp+0x90], xmm10
000079f4d2de2574  vmovaps [rsp+0xA0], xmm11
000079f4d2de257d  vmovaps [rsp+0xB0], xmm12
000079f4d2de2586  vmovaps [rsp+0xC0], xmm13
000079f4d2de258f  vmovaps [rsp+0xD0], xmm14
000079f4d2de2598  vmovaps [rsp+0xE0], xmm15
000079f4d2de25a1  sub rsp, 0x30
000079f4d2de25a5  movaps [rsp], xmm5
000079f4d2de25a9  movaps [rsp+0x10], xmm8
000079f4d2de25af  movaps [rsp+0x20], xmm6
000079f4d2de25b4  lea rdi, [rsp]
000079f4d2de25b8  mov esi, 0x00
000079f4d2de25bd  mov rax, 0x5D9EC01E8530
000079f4d2de25c7  call rax
000079f4d2de25c9  movaps xmm5, [rsp]
000079f4d2de25cd  add rsp, 0x30
000079f4d2de25d1  vmovaps xmm0, [rsp]
000079f4d2de25d6  vmovaps xmm1, [rsp+0x10]
000079f4d2de25dc  vmovaps xmm2, [rsp+0x20]
000079f4d2de25e2  vmovaps xmm3, [rsp+0x30]
000079f4d2de25e8  vmovaps xmm4, [rsp+0x40]
000079f4d2de25ee  vmovaps xmm6, [rsp+0x50]
000079f4d2de25f4  vmovaps xmm7, [rsp+0x60]
000079f4d2de25fa  vmovaps xmm8, [rsp+0x70]
000079f4d2de2600  vmovaps xmm9, [rsp+0x80]
000079f4d2de2609  vmovaps xmm10, [rsp+0x90]
000079f4d2de2612  vmovaps xmm11, [rsp+0xA0]
000079f4d2de261b  vmovaps xmm12, [rsp+0xB0]
000079f4d2de2624  vmovaps xmm13, [rsp+0xC0]
000079f4d2de262d  vmovaps xmm14, [rsp+0xD0]
000079f4d2de2636  vmovaps xmm15, [rsp+0xE0]
000079f4d2de263f  add rsp, 0xF0
000079f4d2de2646  pop r11
000079f4d2de2648  pop r10
000079f4d2de264a  pop r9
000079f4d2de264c  pop r8
000079f4d2de264e  pop rsi
000079f4d2de264f  pop rdi
000079f4d2de2650  pop rdx
000079f4d2de2651  pop rcx
000079f4d2de2652  pop rax
000079f4d2de2653  add rsp, 0x08
000079f4d2de2657  jmp 0x000079F4D2DDF593
000079f4d2de265c  sub rsp, 0x08
000079f4d2de2660  push rax
000079f4d2de2661  push rcx
000079f4d2de2662  push rdx
000079f4d2de2663  push rdi
000079f4d2de2664  push rsi
000079f4d2de2665  push r8
000079f4d2de2667  push r9
000079f4d2de2669  push r10
000079f4d2de266b  push r11
000079f4d2de266d  sub rsp, 0xF0
000079f4d2de2674  vmovaps [rsp], xmm0
000079f4d2de2679  vmovaps [rsp+0x10], xmm1
000079f4d2de267f  vmovaps [rsp+0x20], xmm2
000079f4d2de2685  vmovaps [rsp+0x30], xmm3
000079f4d2de268b  vmovaps [rsp+0x40], xmm4
000079f4d2de2691  vmovaps [rsp+0x50], xmm5
000079f4d2de2697  vmovaps [rsp+0x60], xmm7
000079f4d2de269d  vmovaps [rsp+0x70], xmm8
000079f4d2de26a3  vmovaps [rsp+0x80], xmm9
000079f4d2de26ac  vmovaps [rsp+0x90], xmm10
000079f4d2de26b5  vmovaps [rsp+0xA0], xmm11
000079f4d2de26be  vmovaps [rsp+0xB0], xmm12
000079f4d2de26c7  vmovaps [rsp+0xC0], xmm13
000079f4d2de26d0  vmovaps [rsp+0xD0], xmm14
000079f4d2de26d9  vmovaps [rsp+0xE0], xmm15
000079f4d2de26e2  sub rsp, 0x30
000079f4d2de26e6  movaps [rsp], xmm6
000079f4d2de26ea  movaps [rsp+0x10], xmm10
000079f4d2de26f0  movaps [rsp+0x20], xmm8
000079f4d2de26f6  lea rdi, [rsp]
000079f4d2de26fa  mov esi, 0x00
000079f4d2de26ff  mov rax, 0x5D9EC01E8530
000079f4d2de2709  call rax
000079f4d2de270b  movaps xmm6, [rsp]
000079f4d2de270f  add rsp, 0x30
000079f4d2de2713  vmovaps xmm0, [rsp]
000079f4d2de2718  vmovaps xmm1, [rsp+0x10]
000079f4d2de271e  vmovaps xmm2, [rsp+0x20]
000079f4d2de2724  vmovaps xmm3, [rsp+0x30]
000079f4d2de272a  vmovaps xmm4, [rsp+0x40]
000079f4d2de2730  vmovaps xmm5, [rsp+0x50]
000079f4d2de2736  vmovaps xmm7, [rsp+0x60]
000079f4d2de273c  vmovaps xmm8, [rsp+0x70]
000079f4d2de2742  vmovaps xmm9, [rsp+0x80]
000079f4d2de274b  vmovaps xmm10, [rsp+0x90]
000079f4d2de2754  vmovaps xmm11, [rsp+0xA0]
000079f4d2de275d  vmovaps xmm12, [rsp+0xB0]
000079f4d2de2766  vmovaps xmm13, [rsp+0xC0]
000079f4d2de276f  vmovaps xmm14, [rsp+0xD0]
000079f4d2de2778  vmovaps xmm15, [rsp+0xE0]
000079f4d2de2781  add rsp, 0xF0
000079f4d2de2788  pop r11
000079f4d2de278a  pop r10
000079f4d2de278c  pop r9
000079f4d2de278e  pop r8
000079f4d2de2790  pop rsi
000079f4d2de2791  pop rdi
000079f4d2de2792  pop rdx
000079f4d2de2793  pop rcx
000079f4d2de2794  pop rax
000079f4d2de2795  add rsp, 0x08
000079f4d2de2799  jmp 0x000079F4D2DDF5B8
000079f4d2de279e  sub rsp, 0x08
000079f4d2de27a2  push rax
000079f4d2de27a3  push rcx
000079f4d2de27a4  push rdx
000079f4d2de27a5  push rdi
000079f4d2de27a6  push rsi
000079f4d2de27a7  push r8
000079f4d2de27a9  push r9
000079f4d2de27ab  push r10
000079f4d2de27ad  push r11
000079f4d2de27af  sub rsp, 0xF0
000079f4d2de27b6  vmovaps [rsp], xmm0
000079f4d2de27bb  vmovaps [rsp+0x10], xmm1
000079f4d2de27c1  vmovaps [rsp+0x20], xmm2
000079f4d2de27c7  vmovaps [rsp+0x30], xmm3
000079f4d2de27cd  vmovaps [rsp+0x40], xmm4
000079f4d2de27d3  vmovaps [rsp+0x50], xmm5
000079f4d2de27d9  vmovaps [rsp+0x60], xmm6
000079f4d2de27df  vmovaps [rsp+0x70], xmm7
000079f4d2de27e5  vmovaps [rsp+0x80], xmm8
000079f4d2de27ee  vmovaps [rsp+0x90], xmm9
000079f4d2de27f7  vmovaps [rsp+0xA0], xmm11
000079f4d2de2800  vmovaps [rsp+0xB0], xmm12
000079f4d2de2809  vmovaps [rsp+0xC0], xmm13
000079f4d2de2812  vmovaps [rsp+0xD0], xmm14
000079f4d2de281b  vmovaps [rsp+0xE0], xmm15
000079f4d2de2824  sub rsp, 0x30
000079f4d2de2828  movaps [rsp], xmm10
000079f4d2de282d  movaps [rsp+0x10], xmm8
000079f4d2de2833  movaps [rsp+0x20], xmm14
000079f4d2de2839  lea rdi, [rsp]
000079f4d2de283d  mov esi, 0x00
000079f4d2de2842  mov rax, 0x5D9EC01E8530
000079f4d2de284c  call rax
000079f4d2de284e  movaps xmm10, [rsp]
000079f4d2de2853  add rsp, 0x30
000079f4d2de2857  vmovaps xmm0, [rsp]
000079f4d2de285c  vmovaps xmm1, [rsp+0x10]
000079f4d2de2862  vmovaps xmm2, [rsp+0x20]
000079f4d2de2868  vmovaps xmm3, [rsp+0x30]
000079f4d2de286e  vmovaps xmm4, [rsp+0x40]
000079f4d2de2874  vmovaps xmm5, [rsp+0x50]
000079f4d2de287a  vmovaps xmm6, [rsp+0x60]
000079f4d2de2880  vmovaps xmm7, [rsp+0x70]
000079f4d2de2886  vmovaps xmm8, [rsp+0x80]
000079f4d2de288f  vmovaps xmm9, [rsp+0x90]
000079f4d2de2898  vmovaps xmm11, [rsp+0xA0]
000079f4d2de28a1  vmovaps xmm12, [rsp+0xB0]
000079f4d2de28aa  vmovaps xmm13, [rsp+0xC0]
000079f4d2de28b3  vmovaps xmm14, [rsp+0xD0]
000079f4d2de28bc  vmovaps xmm15, [rsp+0xE0]
000079f4d2de28c5  add rsp, 0xF0
000079f4d2de28cc  pop r11
000079f4d2de28ce  pop r10
000079f4d2de28d0  pop r9
000079f4d2de28d2  pop r8
000079f4d2de28d4  pop rsi
000079f4d2de28d5  pop rdi
000079f4d2de28d6  pop rdx
000079f4d2de28d7  pop rcx
000079f4d2de28d8  pop rax
000079f4d2de28d9  add rsp, 0x08
000079f4d2de28dd  jmp 0x000079F4D2DDF5D8
000079f4d2de28e2  sub rsp, 0x08
000079f4d2de28e6  push rax
000079f4d2de28e7  push rcx
000079f4d2de28e8  push rdx
000079f4d2de28e9  push rdi
000079f4d2de28ea  push rsi
000079f4d2de28eb  push r8
000079f4d2de28ed  push r9
000079f4d2de28ef  push r10
000079f4d2de28f1  push r11
000079f4d2de28f3  sub rsp, 0xF0
000079f4d2de28fa  vmovaps [rsp], xmm0
000079f4d2de28ff  vmovaps [rsp+0x10], xmm1
000079f4d2de2905  vmovaps [rsp+0x20], xmm2
000079f4d2de290b  vmovaps [rsp+0x30], xmm3
000079f4d2de2911  vmovaps [rsp+0x40], xmm4
000079f4d2de2917  vmovaps [rsp+0x50], xmm5
000079f4d2de291d  vmovaps [rsp+0x60], xmm6
000079f4d2de2923  vmovaps [rsp+0x70], xmm7
000079f4d2de2929  vmovaps [rsp+0x80], xmm8
000079f4d2de2932  vmovaps [rsp+0x90], xmm9
000079f4d2de293b  vmovaps [rsp+0xA0], xmm10
000079f4d2de2944  vmovaps [rsp+0xB0], xmm11
000079f4d2de294d  vmovaps [rsp+0xC0], xmm12
000079f4d2de2956  vmovaps [rsp+0xD0], xmm13
000079f4d2de295f  vmovaps [rsp+0xE0], xmm15
000079f4d2de2968  sub rsp, 0x30
000079f4d2de296c  movaps [rsp], xmm14
000079f4d2de2971  movaps [rsp+0x10], xmm8
000079f4d2de2977  movaps [rsp+0x20], xmm4
000079f4d2de297c  lea rdi, [rsp]
000079f4d2de2980  mov esi, 0x00
000079f4d2de2985  mov rax, 0x5D9EC01E8530
000079f4d2de298f  call rax
000079f4d2de2991  movaps xmm14, [rsp]
000079f4d2de2996  add rsp, 0x30
000079f4d2de299a  vmovaps xmm0, [rsp]
000079f4d2de299f  vmovaps xmm1, [rsp+0x10]
000079f4d2de29a5  vmovaps xmm2, [rsp+0x20]
000079f4d2de29ab  vmovaps xmm3, [rsp+0x30]
000079f4d2de29b1  vmovaps xmm4, [rsp+0x40]
000079f4d2de29b7  vmovaps xmm5, [rsp+0x50]
000079f4d2de29bd  vmovaps xmm6, [rsp+0x60]
000079f4d2de29c3  vmovaps xmm7, [rsp+0x70]
000079f4d2de29c9  vmovaps xmm8, [rsp+0x80]
000079f4d2de29d2  vmovaps xmm9, [rsp+0x90]
000079f4d2de29db  vmovaps xmm10, [rsp+0xA0]
000079f4d2de29e4  vmovaps xmm11, [rsp+0xB0]
000079f4d2de29ed  vmovaps xmm12, [rsp+0xC0]
000079f4d2de29f6  vmovaps xmm13, [rsp+0xD0]
000079f4d2de29ff  vmovaps xmm15, [rsp+0xE0]
000079f4d2de2a08  add rsp, 0xF0
000079f4d2de2a0f  pop r11
000079f4d2de2a11  pop r10
000079f4d2de2a13  pop r9
000079f4d2de2a15  pop r8
000079f4d2de2a17  pop rsi
000079f4d2de2a18  pop rdi
000079f4d2de2a19  pop rdx
000079f4d2de2a1a  pop rcx
000079f4d2de2a1b  pop rax
000079f4d2de2a1c  add rsp, 0x08
000079f4d2de2a20  jmp 0x000079F4D2DDF5F8
000079f4d2de2a25  sub rsp, 0x08
000079f4d2de2a29  push rax
000079f4d2de2a2a  push rcx
000079f4d2de2a2b  push rdx
000079f4d2de2a2c  push rdi
000079f4d2de2a2d  push rsi
000079f4d2de2a2e  push r8
000079f4d2de2a30  push r9
000079f4d2de2a32  push r10
000079f4d2de2a34  push r11
000079f4d2de2a36  sub rsp, 0xF0
000079f4d2de2a3d  vmovaps [rsp], xmm0
000079f4d2de2a42  vmovaps [rsp+0x10], xmm1
000079f4d2de2a48  vmovaps [rsp+0x20], xmm2
000079f4d2de2a4e  vmovaps [rsp+0x30], xmm3
000079f4d2de2a54  vmovaps [rsp+0x40], xmm5
000079f4d2de2a5a  vmovaps [rsp+0x50], xmm6
000079f4d2de2a60  vmovaps [rsp+0x60], xmm7
000079f4d2de2a66  vmovaps [rsp+0x70], xmm8
000079f4d2de2a6c  vmovaps [rsp+0x80], xmm9
000079f4d2de2a75  vmovaps [rsp+0x90], xmm10
000079f4d2de2a7e  vmovaps [rsp+0xA0], xmm11
000079f4d2de2a87  vmovaps [rsp+0xB0], xmm12
000079f4d2de2a90  vmovaps [rsp+0xC0], xmm13
000079f4d2de2a99  vmovaps [rsp+0xD0], xmm14
000079f4d2de2aa2  vmovaps [rsp+0xE0], xmm15
000079f4d2de2aab  sub rsp, 0x30
000079f4d2de2aaf  movaps [rsp], xmm4
000079f4d2de2ab3  movaps [rsp+0x10], xmm13
000079f4d2de2ab9  movaps [rsp+0x20], xmm8
000079f4d2de2abf  lea rdi, [rsp]
000079f4d2de2ac3  mov esi, 0x00
000079f4d2de2ac8  mov rax, 0x5D9EC01E8530
000079f4d2de2ad2  call rax
000079f4d2de2ad4  movaps xmm4, [rsp]
000079f4d2de2ad8  add rsp, 0x30
000079f4d2de2adc  vmovaps xmm0, [rsp]
000079f4d2de2ae1  vmovaps xmm1, [rsp+0x10]
000079f4d2de2ae7  vmovaps xmm2, [rsp+0x20]
000079f4d2de2aed  vmovaps xmm3, [rsp+0x30]
000079f4d2de2af3  vmovaps xmm5, [rsp+0x40]
000079f4d2de2af9  vmovaps xmm6, [rsp+0x50]
000079f4d2de2aff  vmovaps xmm7, [rsp+0x60]
000079f4d2de2b05  vmovaps xmm8, [rsp+0x70]
000079f4d2de2b0b  vmovaps xmm9, [rsp+0x80]
000079f4d2de2b14  vmovaps xmm10, [rsp+0x90]
000079f4d2de2b1d  vmovaps xmm11, [rsp+0xA0]
000079f4d2de2b26  vmovaps xmm12, [rsp+0xB0]
000079f4d2de2b2f  vmovaps xmm13, [rsp+0xC0]
000079f4d2de2b38  vmovaps xmm14, [rsp+0xD0]
000079f4d2de2b41  vmovaps xmm15, [rsp+0xE0]
000079f4d2de2b4a  add rsp, 0xF0
000079f4d2de2b51  pop r11
000079f4d2de2b53  pop r10
000079f4d2de2b55  pop r9
000079f4d2de2b57  pop r8
000079f4d2de2b59  pop rsi
000079f4d2de2b5a  pop rdi
000079f4d2de2b5b  pop rdx
000079f4d2de2b5c  pop rcx
000079f4d2de2b5d  pop rax
000079f4d2de2b5e  add rsp, 0x08
000079f4d2de2b62  jmp 0x000079F4D2DDF61D
000079f4d2de2b67  sub rsp, 0x08
000079f4d2de2b6b  push rax
000079f4d2de2b6c  push rcx
000079f4d2de2b6d  push rdx
000079f4d2de2b6e  push rdi
000079f4d2de2b6f  push rsi
000079f4d2de2b70  push r8
000079f4d2de2b72  push r9
000079f4d2de2b74  push r10
000079f4d2de2b76  push r11
000079f4d2de2b78  sub rsp, 0xF0
000079f4d2de2b7f  vmovaps [rsp], xmm0
000079f4d2de2b84  vmovaps [rsp+0x10], xmm1
000079f4d2de2b8a  vmovaps [rsp+0x20], xmm2
000079f4d2de2b90  vmovaps [rsp+0x30], xmm3
000079f4d2de2b96  vmovaps [rsp+0x40], xmm4
000079f4d2de2b9c  vmovaps [rsp+0x50], xmm5
000079f4d2de2ba2  vmovaps [rsp+0x60], xmm6
000079f4d2de2ba8  vmovaps [rsp+0x70], xmm7
000079f4d2de2bae  vmovaps [rsp+0x80], xmm8
000079f4d2de2bb7  vmovaps [rsp+0x90], xmm9
000079f4d2de2bc0  vmovaps [rsp+0xA0], xmm10
000079f4d2de2bc9  vmovaps [rsp+0xB0], xmm11
000079f4d2de2bd2  vmovaps [rsp+0xC0], xmm12
000079f4d2de2bdb  vmovaps [rsp+0xD0], xmm14
000079f4d2de2be4  vmovaps [rsp+0xE0], xmm15
000079f4d2de2bed  sub rsp, 0x30
000079f4d2de2bf1  movaps [rsp], xmm13
000079f4d2de2bf6  movaps [rsp+0x10], xmm15
000079f4d2de2bfc  movaps [rsp+0x20], xmm9
000079f4d2de2c02  lea rdi, [rsp]
000079f4d2de2c06  mov esi, 0x00
000079f4d2de2c0b  mov rax, 0x5D9EC01E8530
000079f4d2de2c15  call rax
000079f4d2de2c17  movaps xmm13, [rsp]
000079f4d2de2c1c  add rsp, 0x30
000079f4d2de2c20  vmovaps xmm0, [rsp]
000079f4d2de2c25  vmovaps xmm1, [rsp+0x10]
000079f4d2de2c2b  vmovaps xmm2, [rsp+0x20]
000079f4d2de2c31  vmovaps xmm3, [rsp+0x30]
000079f4d2de2c37  vmovaps xmm4, [rsp+0x40]
000079f4d2de2c3d  vmovaps xmm5, [rsp+0x50]
000079f4d2de2c43  vmovaps xmm6, [rsp+0x60]
000079f4d2de2c49  vmovaps xmm7, [rsp+0x70]
000079f4d2de2c4f  vmovaps xmm8, [rsp+0x80]
000079f4d2de2c58  vmovaps xmm9, [rsp+0x90]
000079f4d2de2c61  vmovaps xmm10, [rsp+0xA0]
000079f4d2de2c6a  vmovaps xmm11, [rsp+0xB0]
000079f4d2de2c73  vmovaps xmm12, [rsp+0xC0]
000079f4d2de2c7c  vmovaps xmm14, [rsp+0xD0]
000079f4d2de2c85  vmovaps xmm15, [rsp+0xE0]
000079f4d2de2c8e  add rsp, 0xF0
000079f4d2de2c95  pop r11
000079f4d2de2c97  pop r10
000079f4d2de2c99  pop r9
000079f4d2de2c9b  pop r8
000079f4d2de2c9d  pop rsi
000079f4d2de2c9e  pop rdi
000079f4d2de2c9f  pop rdx
000079f4d2de2ca0  pop rcx
000079f4d2de2ca1  pop rax
000079f4d2de2ca2  add rsp, 0x08
000079f4d2de2ca6  jmp 0x000079F4D2DDF638
000079f4d2de2cab  sub rsp, 0x08
000079f4d2de2caf  push rax
000079f4d2de2cb0  push rcx
000079f4d2de2cb1  push rdx
000079f4d2de2cb2  push rdi
000079f4d2de2cb3  push rsi
000079f4d2de2cb4  push r8
000079f4d2de2cb6  push r9
000079f4d2de2cb8  push r10
000079f4d2de2cba  push r11
000079f4d2de2cbc  sub rsp, 0xF0
000079f4d2de2cc3  vmovaps [rsp], xmm0
000079f4d2de2cc8  vmovaps [rsp+0x10], xmm1
000079f4d2de2cce  vmovaps [rsp+0x20], xmm2
000079f4d2de2cd4  vmovaps [rsp+0x30], xmm3
000079f4d2de2cda  vmovaps [rsp+0x40], xmm4
000079f4d2de2ce0  vmovaps [rsp+0x50], xmm5
000079f4d2de2ce6  vmovaps [rsp+0x60], xmm6
000079f4d2de2cec  vmovaps [rsp+0x70], xmm7
000079f4d2de2cf2  vmovaps [rsp+0x80], xmm8
000079f4d2de2cfb  vmovaps [rsp+0x90], xmm9
000079f4d2de2d04  vmovaps [rsp+0xA0], xmm10
000079f4d2de2d0d  vmovaps [rsp+0xB0], xmm11
000079f4d2de2d16  vmovaps [rsp+0xC0], xmm12
000079f4d2de2d1f  vmovaps [rsp+0xD0], xmm13
000079f4d2de2d28  vmovaps [rsp+0xE0], xmm14
000079f4d2de2d31  sub rsp, 0x30
000079f4d2de2d35  movaps [rsp], xmm15
000079f4d2de2d3a  movaps [rsp+0x10], xmm1
000079f4d2de2d3f  movaps [rsp+0x20], xmm5
000079f4d2de2d44  lea rdi, [rsp]
000079f4d2de2d48  mov esi, 0x00
000079f4d2de2d4d  mov rax, 0x5D9EC01E8530
000079f4d2de2d57  call rax
000079f4d2de2d59  movaps xmm15, [rsp]
000079f4d2de2d5e  add rsp, 0x30
000079f4d2de2d62  vmovaps xmm0, [rsp]
000079f4d2de2d67  vmovaps xmm1, [rsp+0x10]
000079f4d2de2d6d  vmovaps xmm2, [rsp+0x20]
000079f4d2de2d73  vmovaps xmm3, [rsp+0x30]
000079f4d2de2d79  vmovaps xmm4, [rsp+0x40]
000079f4d2de2d7f  vmovaps xmm5, [rsp+0x50]
000079f4d2de2d85  vmovaps xmm6, [rsp+0x60]
000079f4d2de2d8b  vmovaps xmm7, [rsp+0x70]
000079f4d2de2d91  vmovaps xmm8, [rsp+0x80]
000079f4d2de2d9a  vmovaps xmm9, [rsp+0x90]
000079f4d2de2da3  vmovaps xmm10, [rsp+0xA0]
000079f4d2de2dac  vmovaps xmm11, [rsp+0xB0]
000079f4d2de2db5  vmovaps xmm12, [rsp+0xC0]
000079f4d2de2dbe  vmovaps xmm13, [rsp+0xD0]
000079f4d2de2dc7  vmovaps xmm14, [rsp+0xE0]
000079f4d2de2dd0  add rsp, 0xF0
000079f4d2de2dd7  pop r11
000079f4d2de2dd9  pop r10
000079f4d2de2ddb  pop r9
000079f4d2de2ddd  pop r8
000079f4d2de2ddf  pop rsi
000079f4d2de2de0  pop rdi
000079f4d2de2de1  pop rdx
000079f4d2de2de2  pop rcx
000079f4d2de2de3  pop rax
000079f4d2de2de4  add rsp, 0x08
000079f4d2de2de8  jmp 0x000079F4D2DDF653
000079f4d2de2ded  call 0x000079F4D2CB52F0
000079f4d2de2df2  jmp 0x000079F4D2DDF6AE
000079f4d2de2df7  sub rsp, 0x08
000079f4d2de2dfb  push rax
000079f4d2de2dfc  push rcx
000079f4d2de2dfd  push rdx
000079f4d2de2dfe  push rdi
000079f4d2de2dff  push rsi
000079f4d2de2e00  push r8
000079f4d2de2e02  push r9
000079f4d2de2e04  push r10
000079f4d2de2e06  push r11
000079f4d2de2e08  sub rsp, 0xF0
000079f4d2de2e0f  vmovaps [rsp], xmm0
000079f4d2de2e14  vmovaps [rsp+0x10], xmm1
000079f4d2de2e1a  vmovaps [rsp+0x20], xmm2
000079f4d2de2e20  vmovaps [rsp+0x30], xmm3
000079f4d2de2e26  vmovaps [rsp+0x40], xmm4
000079f4d2de2e2c  vmovaps [rsp+0x50], xmm5
000079f4d2de2e32  vmovaps [rsp+0x60], xmm6
000079f4d2de2e38  vmovaps [rsp+0x70], xmm7
000079f4d2de2e3e  vmovaps [rsp+0x80], xmm8
000079f4d2de2e47  vmovaps [rsp+0x90], xmm10
000079f4d2de2e50  vmovaps [rsp+0xA0], xmm11
000079f4d2de2e59  vmovaps [rsp+0xB0], xmm12
000079f4d2de2e62  vmovaps [rsp+0xC0], xmm13
000079f4d2de2e6b  vmovaps [rsp+0xD0], xmm14
000079f4d2de2e74  vmovaps [rsp+0xE0], xmm15
000079f4d2de2e7d  sub rsp, 0x30
000079f4d2de2e81  movaps [rsp], xmm9
000079f4d2de2e86  movaps [rsp+0x10], xmm8
000079f4d2de2e8c  movaps [rsp+0x20], xmm11
000079f4d2de2e92  lea rdi, [rsp]
000079f4d2de2e96  mov esi, 0x00
000079f4d2de2e9b  mov rax, 0x5D9EC01E8530
000079f4d2de2ea5  call rax
000079f4d2de2ea7  movaps xmm9, [rsp]
000079f4d2de2eac  add rsp, 0x30
000079f4d2de2eb0  vmovaps xmm0, [rsp]
000079f4d2de2eb5  vmovaps xmm1, [rsp+0x10]
000079f4d2de2ebb  vmovaps xmm2, [rsp+0x20]
000079f4d2de2ec1  vmovaps xmm3, [rsp+0x30]
000079f4d2de2ec7  vmovaps xmm4, [rsp+0x40]
000079f4d2de2ecd  vmovaps xmm5, [rsp+0x50]
000079f4d2de2ed3  vmovaps xmm6, [rsp+0x60]
000079f4d2de2ed9  vmovaps xmm7, [rsp+0x70]
000079f4d2de2edf  vmovaps xmm8, [rsp+0x80]
000079f4d2de2ee8  vmovaps xmm10, [rsp+0x90]
000079f4d2de2ef1  vmovaps xmm11, [rsp+0xA0]
000079f4d2de2efa  vmovaps xmm12, [rsp+0xB0]
000079f4d2de2f03  vmovaps xmm13, [rsp+0xC0]
000079f4d2de2f0c  vmovaps xmm14, [rsp+0xD0]
000079f4d2de2f15  vmovaps xmm15, [rsp+0xE0]
000079f4d2de2f1e  add rsp, 0xF0
000079f4d2de2f25  pop r11
000079f4d2de2f27  pop r10
000079f4d2de2f29  pop r9
000079f4d2de2f2b  pop r8
000079f4d2de2f2d  pop rsi
000079f4d2de2f2e  pop rdi
000079f4d2de2f2f  pop rdx
000079f4d2de2f30  pop rcx
000079f4d2de2f31  pop rax
000079f4d2de2f32  add rsp, 0x08
000079f4d2de2f36  jmp 0x000079F4D2DDF6E5
000079f4d2de2f3b  sub rsp, 0x08
000079f4d2de2f3f  push rax
000079f4d2de2f40  push rcx
000079f4d2de2f41  push rdx
000079f4d2de2f42  push rdi
000079f4d2de2f43  push rsi
000079f4d2de2f44  push r8
000079f4d2de2f46  push r9
000079f4d2de2f48  push r10
000079f4d2de2f4a  push r11
000079f4d2de2f4c  sub rsp, 0xF0
000079f4d2de2f53  vmovaps [rsp], xmm0
000079f4d2de2f58  vmovaps [rsp+0x10], xmm1
000079f4d2de2f5e  vmovaps [rsp+0x20], xmm2
000079f4d2de2f64  vmovaps [rsp+0x30], xmm3
000079f4d2de2f6a  vmovaps [rsp+0x40], xmm4
000079f4d2de2f70  vmovaps [rsp+0x50], xmm5
000079f4d2de2f76  vmovaps [rsp+0x60], xmm6
000079f4d2de2f7c  vmovaps [rsp+0x70], xmm7
000079f4d2de2f82  vmovaps [rsp+0x80], xmm8
000079f4d2de2f8b  vmovaps [rsp+0x90], xmm9
000079f4d2de2f94  vmovaps [rsp+0xA0], xmm10
000079f4d2de2f9d  vmovaps [rsp+0xB0], xmm12
000079f4d2de2fa6  vmovaps [rsp+0xC0], xmm13
000079f4d2de2faf  vmovaps [rsp+0xD0], xmm14
000079f4d2de2fb8  vmovaps [rsp+0xE0], xmm15
000079f4d2de2fc1  sub rsp, 0x30
000079f4d2de2fc5  movaps [rsp], xmm11
000079f4d2de2fca  movaps [rsp+0x10], xmm10
000079f4d2de2fd0  movaps [rsp+0x20], xmm6
000079f4d2de2fd5  lea rdi, [rsp]
000079f4d2de2fd9  mov esi, 0x00
000079f4d2de2fde  mov rax, 0x5D9EC01E8530
000079f4d2de2fe8  call rax
000079f4d2de2fea  movaps xmm11, [rsp]
000079f4d2de2fef  add rsp, 0x30
000079f4d2de2ff3  vmovaps xmm0, [rsp]
000079f4d2de2ff8  vmovaps xmm1, [rsp+0x10]
000079f4d2de2ffe  vmovaps xmm2, [rsp+0x20]
000079f4d2de3004  vmovaps xmm3, [rsp+0x30]
000079f4d2de300a  vmovaps xmm4, [rsp+0x40]
000079f4d2de3010  vmovaps xmm5, [rsp+0x50]
000079f4d2de3016  vmovaps xmm6, [rsp+0x60]
000079f4d2de301c  vmovaps xmm7, [rsp+0x70]
000079f4d2de3022  vmovaps xmm8, [rsp+0x80]
000079f4d2de302b  vmovaps xmm9, [rsp+0x90]
000079f4d2de3034  vmovaps xmm10, [rsp+0xA0]
000079f4d2de303d  vmovaps xmm12, [rsp+0xB0]
000079f4d2de3046  vmovaps xmm13, [rsp+0xC0]
000079f4d2de304f  vmovaps xmm14, [rsp+0xD0]
000079f4d2de3058  vmovaps xmm15, [rsp+0xE0]
000079f4d2de3061  add rsp, 0xF0
000079f4d2de3068  pop r11
000079f4d2de306a  pop r10
000079f4d2de306c  pop r9
000079f4d2de306e  pop r8
000079f4d2de3070  pop rsi
000079f4d2de3071  pop rdi
000079f4d2de3072  pop rdx
000079f4d2de3073  pop rcx
000079f4d2de3074  pop rax
000079f4d2de3075  add rsp, 0x08
000079f4d2de3079  jmp 0x000079F4D2DDF700
000079f4d2de307e  sub rsp, 0x08
000079f4d2de3082  push rax
000079f4d2de3083  push rcx
000079f4d2de3084  push rdx
000079f4d2de3085  push rdi
000079f4d2de3086  push rsi
000079f4d2de3087  push r8
000079f4d2de3089  push r9
000079f4d2de308b  push r10
000079f4d2de308d  push r11
000079f4d2de308f  sub rsp, 0xF0
000079f4d2de3096  vmovaps [rsp], xmm0
000079f4d2de309b  vmovaps [rsp+0x10], xmm1
000079f4d2de30a1  vmovaps [rsp+0x20], xmm2
000079f4d2de30a7  vmovaps [rsp+0x30], xmm3
000079f4d2de30ad  vmovaps [rsp+0x40], xmm4
000079f4d2de30b3  vmovaps [rsp+0x50], xmm5
000079f4d2de30b9  vmovaps [rsp+0x60], xmm6
000079f4d2de30bf  vmovaps [rsp+0x70], xmm7
000079f4d2de30c5  vmovaps [rsp+0x80], xmm8
000079f4d2de30ce  vmovaps [rsp+0x90], xmm9
000079f4d2de30d7  vmovaps [rsp+0xA0], xmm11
000079f4d2de30e0  vmovaps [rsp+0xB0], xmm12
000079f4d2de30e9  vmovaps [rsp+0xC0], xmm13
000079f4d2de30f2  vmovaps [rsp+0xD0], xmm14
000079f4d2de30fb  vmovaps [rsp+0xE0], xmm15
000079f4d2de3104  sub rsp, 0x30
000079f4d2de3108  movaps [rsp], xmm10
000079f4d2de310d  movaps [rsp+0x10], xmm14
000079f4d2de3113  movaps [rsp+0x20], xmm4
000079f4d2de3118  lea rdi, [rsp]
000079f4d2de311c  mov esi, 0x00
000079f4d2de3121  mov rax, 0x5D9EC01E8530
000079f4d2de312b  call rax
000079f4d2de312d  movaps xmm10, [rsp]
000079f4d2de3132  add rsp, 0x30
000079f4d2de3136  vmovaps xmm0, [rsp]
000079f4d2de313b  vmovaps xmm1, [rsp+0x10]
000079f4d2de3141  vmovaps xmm2, [rsp+0x20]
000079f4d2de3147  vmovaps xmm3, [rsp+0x30]
000079f4d2de314d  vmovaps xmm4, [rsp+0x40]
000079f4d2de3153  vmovaps xmm5, [rsp+0x50]
000079f4d2de3159  vmovaps xmm6, [rsp+0x60]
000079f4d2de315f  vmovaps xmm7, [rsp+0x70]
000079f4d2de3165  vmovaps xmm8, [rsp+0x80]
000079f4d2de316e  vmovaps xmm9, [rsp+0x90]
000079f4d2de3177  vmovaps xmm11, [rsp+0xA0]
000079f4d2de3180  vmovaps xmm12, [rsp+0xB0]
000079f4d2de3189  vmovaps xmm13, [rsp+0xC0]
000079f4d2de3192  vmovaps xmm14, [rsp+0xD0]
000079f4d2de319b  vmovaps xmm15, [rsp+0xE0]
000079f4d2de31a4  add rsp, 0xF0
000079f4d2de31ab  pop r11
000079f4d2de31ad  pop r10
000079f4d2de31af  pop r9
000079f4d2de31b1  pop r8
000079f4d2de31b3  pop rsi
000079f4d2de31b4  pop rdi
000079f4d2de31b5  pop rdx
000079f4d2de31b6  pop rcx
000079f4d2de31b7  pop rax
000079f4d2de31b8  add rsp, 0x08
000079f4d2de31bc  jmp 0x000079F4D2DDF71B
000079f4d2de31c1  sub rsp, 0x08
000079f4d2de31c5  push rax
000079f4d2de31c6  push rcx
000079f4d2de31c7  push rdx
000079f4d2de31c8  push rdi
000079f4d2de31c9  push rsi
000079f4d2de31ca  push r8
000079f4d2de31cc  push r9
000079f4d2de31ce  push r10
000079f4d2de31d0  push r11
000079f4d2de31d2  sub rsp, 0xF0
000079f4d2de31d9  vmovaps [rsp], xmm0
000079f4d2de31de  vmovaps [rsp+0x10], xmm1
000079f4d2de31e4  vmovaps [rsp+0x20], xmm2
000079f4d2de31ea  vmovaps [rsp+0x30], xmm3
000079f4d2de31f0  vmovaps [rsp+0x40], xmm4
000079f4d2de31f6  vmovaps [rsp+0x50], xmm5
000079f4d2de31fc  vmovaps [rsp+0x60], xmm6
000079f4d2de3202  vmovaps [rsp+0x70], xmm7
000079f4d2de3208  vmovaps [rsp+0x80], xmm9
000079f4d2de3211  vmovaps [rsp+0x90], xmm10
000079f4d2de321a  vmovaps [rsp+0xA0], xmm11
000079f4d2de3223  vmovaps [rsp+0xB0], xmm12
000079f4d2de322c  vmovaps [rsp+0xC0], xmm13
000079f4d2de3235  vmovaps [rsp+0xD0], xmm14
000079f4d2de323e  vmovaps [rsp+0xE0], xmm15
000079f4d2de3247  sub rsp, 0x30
000079f4d2de324b  movaps [rsp], xmm8
000079f4d2de3250  movaps [rsp+0x10], xmm1
000079f4d2de3255  movaps [rsp+0x20], xmm14
000079f4d2de325b  lea rdi, [rsp]
000079f4d2de325f  mov esi, 0x00
000079f4d2de3264  mov rax, 0x5D9EC01E8530
000079f4d2de326e  call rax
000079f4d2de3270  movaps xmm8, [rsp]
000079f4d2de3275  add rsp, 0x30
000079f4d2de3279  vmovaps xmm0, [rsp]
000079f4d2de327e  vmovaps xmm1, [rsp+0x10]
000079f4d2de3284  vmovaps xmm2, [rsp+0x20]
000079f4d2de328a  vmovaps xmm3, [rsp+0x30]
000079f4d2de3290  vmovaps xmm4, [rsp+0x40]
000079f4d2de3296  vmovaps xmm5, [rsp+0x50]
000079f4d2de329c  vmovaps xmm6, [rsp+0x60]
000079f4d2de32a2  vmovaps xmm7, [rsp+0x70]
000079f4d2de32a8  vmovaps xmm9, [rsp+0x80]
000079f4d2de32b1  vmovaps xmm10, [rsp+0x90]
000079f4d2de32ba  vmovaps xmm11, [rsp+0xA0]
000079f4d2de32c3  vmovaps xmm12, [rsp+0xB0]
000079f4d2de32cc  vmovaps xmm13, [rsp+0xC0]
000079f4d2de32d5  vmovaps xmm14, [rsp+0xD0]
000079f4d2de32de  vmovaps xmm15, [rsp+0xE0]
000079f4d2de32e7  add rsp, 0xF0
000079f4d2de32ee  pop r11
000079f4d2de32f0  pop r10
000079f4d2de32f2  pop r9
000079f4d2de32f4  pop r8
000079f4d2de32f6  pop rsi
000079f4d2de32f7  pop rdi
000079f4d2de32f8  pop rdx
000079f4d2de32f9  pop rcx
000079f4d2de32fa  pop rax
000079f4d2de32fb  add rsp, 0x08
000079f4d2de32ff  jmp 0x000079F4D2DDF741
000079f4d2de3304  sub rsp, 0x08
000079f4d2de3308  push rax
000079f4d2de3309  push rcx
000079f4d2de330a  push rdx
000079f4d2de330b  push rdi
000079f4d2de330c  push rsi
000079f4d2de330d  push r8
000079f4d2de330f  push r9
000079f4d2de3311  push r10
000079f4d2de3313  push r11
000079f4d2de3315  sub rsp, 0xF0
000079f4d2de331c  vmovaps [rsp], xmm0
000079f4d2de3321  vmovaps [rsp+0x10], xmm1
000079f4d2de3327  vmovaps [rsp+0x20], xmm2
000079f4d2de332d  vmovaps [rsp+0x30], xmm3
000079f4d2de3333  vmovaps [rsp+0x40], xmm4
000079f4d2de3339  vmovaps [rsp+0x50], xmm5
000079f4d2de333f  vmovaps [rsp+0x60], xmm7
000079f4d2de3345  vmovaps [rsp+0x70], xmm8
000079f4d2de334b  vmovaps [rsp+0x80], xmm9
000079f4d2de3354  vmovaps [rsp+0x90], xmm10
000079f4d2de335d  vmovaps [rsp+0xA0], xmm11
000079f4d2de3366  vmovaps [rsp+0xB0], xmm12
000079f4d2de336f  vmovaps [rsp+0xC0], xmm13
000079f4d2de3378  vmovaps [rsp+0xD0], xmm14
000079f4d2de3381  vmovaps [rsp+0xE0], xmm15
000079f4d2de338a  sub rsp, 0x30
000079f4d2de338e  movaps [rsp], xmm6
000079f4d2de3392  movaps [rsp+0x10], xmm1
000079f4d2de3397  movaps [rsp+0x20], xmm14
000079f4d2de339d  lea rdi, [rsp]
000079f4d2de33a1  mov esi, 0x00
000079f4d2de33a6  mov rax, 0x5D9EC01E8530
000079f4d2de33b0  call rax
000079f4d2de33b2  movaps xmm6, [rsp]
000079f4d2de33b6  add rsp, 0x30
000079f4d2de33ba  vmovaps xmm0, [rsp]
000079f4d2de33bf  vmovaps xmm1, [rsp+0x10]
000079f4d2de33c5  vmovaps xmm2, [rsp+0x20]
000079f4d2de33cb  vmovaps xmm3, [rsp+0x30]
000079f4d2de33d1  vmovaps xmm4, [rsp+0x40]
000079f4d2de33d7  vmovaps xmm5, [rsp+0x50]
000079f4d2de33dd  vmovaps xmm7, [rsp+0x60]
000079f4d2de33e3  vmovaps xmm8, [rsp+0x70]
000079f4d2de33e9  vmovaps xmm9, [rsp+0x80]
000079f4d2de33f2  vmovaps xmm10, [rsp+0x90]
000079f4d2de33fb  vmovaps xmm11, [rsp+0xA0]
000079f4d2de3404  vmovaps xmm12, [rsp+0xB0]
000079f4d2de340d  vmovaps xmm13, [rsp+0xC0]
000079f4d2de3416  vmovaps xmm14, [rsp+0xD0]
000079f4d2de341f  vmovaps xmm15, [rsp+0xE0]
000079f4d2de3428  add rsp, 0xF0
000079f4d2de342f  pop r11
000079f4d2de3431  pop r10
000079f4d2de3433  pop r9
000079f4d2de3435  pop r8
000079f4d2de3437  pop rsi
000079f4d2de3438  pop rdi
000079f4d2de3439  pop rdx
000079f4d2de343a  pop rcx
000079f4d2de343b  pop rax
000079f4d2de343c  add rsp, 0x08
000079f4d2de3440  jmp 0x000079F4D2DDF76D
000079f4d2de3445  sub rsp, 0x08
000079f4d2de3449  push rax
000079f4d2de344a  push rcx
000079f4d2de344b  push rdx
000079f4d2de344c  push rdi
000079f4d2de344d  push rsi
000079f4d2de344e  push r8
000079f4d2de3450  push r9
000079f4d2de3452  push r10
000079f4d2de3454  push r11
000079f4d2de3456  sub rsp, 0xF0
000079f4d2de345d  vmovaps [rsp], xmm0
000079f4d2de3462  vmovaps [rsp+0x10], xmm1
000079f4d2de3468  vmovaps [rsp+0x20], xmm2
000079f4d2de346e  vmovaps [rsp+0x30], xmm3
000079f4d2de3474  vmovaps [rsp+0x40], xmm4
000079f4d2de347a  vmovaps [rsp+0x50], xmm5
000079f4d2de3480  vmovaps [rsp+0x60], xmm6
000079f4d2de3486  vmovaps [rsp+0x70], xmm7
000079f4d2de348c  vmovaps [rsp+0x80], xmm8
000079f4d2de3495  vmovaps [rsp+0x90], xmm9
000079f4d2de349e  vmovaps [rsp+0xA0], xmm10
000079f4d2de34a7  vmovaps [rsp+0xB0], xmm11
000079f4d2de34b0  vmovaps [rsp+0xC0], xmm12
000079f4d2de34b9  vmovaps [rsp+0xD0], xmm13
000079f4d2de34c2  vmovaps [rsp+0xE0], xmm15
000079f4d2de34cb  sub rsp, 0x30
000079f4d2de34cf  movaps [rsp], xmm14
000079f4d2de34d4  movaps [rsp+0x10], xmm12
000079f4d2de34da  movaps [rsp+0x20], xmm1
000079f4d2de34df  lea rdi, [rsp]
000079f4d2de34e3  mov esi, 0x00
000079f4d2de34e8  mov rax, 0x5D9EC01E8530
000079f4d2de34f2  call rax
000079f4d2de34f4  movaps xmm14, [rsp]
000079f4d2de34f9  add rsp, 0x30
000079f4d2de34fd  vmovaps xmm0, [rsp]
000079f4d2de3502  vmovaps xmm1, [rsp+0x10]
000079f4d2de3508  vmovaps xmm2, [rsp+0x20]
000079f4d2de350e  vmovaps xmm3, [rsp+0x30]
000079f4d2de3514  vmovaps xmm4, [rsp+0x40]
000079f4d2de351a  vmovaps xmm5, [rsp+0x50]
000079f4d2de3520  vmovaps xmm6, [rsp+0x60]
000079f4d2de3526  vmovaps xmm7, [rsp+0x70]
000079f4d2de352c  vmovaps xmm8, [rsp+0x80]
000079f4d2de3535  vmovaps xmm9, [rsp+0x90]
000079f4d2de353e  vmovaps xmm10, [rsp+0xA0]
000079f4d2de3547  vmovaps xmm11, [rsp+0xB0]
000079f4d2de3550  vmovaps xmm12, [rsp+0xC0]
000079f4d2de3559  vmovaps xmm13, [rsp+0xD0]
000079f4d2de3562  vmovaps xmm15, [rsp+0xE0]
000079f4d2de356b  add rsp, 0xF0
000079f4d2de3572  pop r11
000079f4d2de3574  pop r10
000079f4d2de3576  pop r9
000079f4d2de3578  pop r8
000079f4d2de357a  pop rsi
000079f4d2de357b  pop rdi
000079f4d2de357c  pop rdx
000079f4d2de357d  pop rcx
000079f4d2de357e  pop rax
000079f4d2de357f  add rsp, 0x08
000079f4d2de3583  jmp 0x000079F4D2DDF793
000079f4d2de3588  sub rsp, 0x08
000079f4d2de358c  push rax
000079f4d2de358d  push rcx
000079f4d2de358e  push rdx
000079f4d2de358f  push rdi
000079f4d2de3590  push rsi
000079f4d2de3591  push r8
000079f4d2de3593  push r9
000079f4d2de3595  push r10
000079f4d2de3597  push r11
000079f4d2de3599  sub rsp, 0xF0
000079f4d2de35a0  vmovaps [rsp], xmm0
000079f4d2de35a5  vmovaps [rsp+0x10], xmm2
000079f4d2de35ab  vmovaps [rsp+0x20], xmm3
000079f4d2de35b1  vmovaps [rsp+0x30], xmm4
000079f4d2de35b7  vmovaps [rsp+0x40], xmm5
000079f4d2de35bd  vmovaps [rsp+0x50], xmm6
000079f4d2de35c3  vmovaps [rsp+0x60], xmm7
000079f4d2de35c9  vmovaps [rsp+0x70], xmm8
000079f4d2de35cf  vmovaps [rsp+0x80], xmm9
000079f4d2de35d8  vmovaps [rsp+0x90], xmm10
000079f4d2de35e1  vmovaps [rsp+0xA0], xmm11
000079f4d2de35ea  vmovaps [rsp+0xB0], xmm12
000079f4d2de35f3  vmovaps [rsp+0xC0], xmm13
000079f4d2de35fc  vmovaps [rsp+0xD0], xmm14
000079f4d2de3605  vmovaps [rsp+0xE0], xmm15
000079f4d2de360e  sub rsp, 0x30
000079f4d2de3612  movaps [rsp], xmm1
000079f4d2de3616  movaps [rsp+0x10], xmm13
000079f4d2de361c  movaps [rsp+0x20], xmm9
000079f4d2de3622  lea rdi, [rsp]
000079f4d2de3626  mov esi, 0x00
000079f4d2de362b  mov rax, 0x5D9EC01E8530
000079f4d2de3635  call rax
000079f4d2de3637  movaps xmm1, [rsp]
000079f4d2de363b  add rsp, 0x30
000079f4d2de363f  vmovaps xmm0, [rsp]
000079f4d2de3644  vmovaps xmm2, [rsp+0x10]
000079f4d2de364a  vmovaps xmm3, [rsp+0x20]
000079f4d2de3650  vmovaps xmm4, [rsp+0x30]
000079f4d2de3656  vmovaps xmm5, [rsp+0x40]
000079f4d2de365c  vmovaps xmm6, [rsp+0x50]
000079f4d2de3662  vmovaps xmm7, [rsp+0x60]
000079f4d2de3668  vmovaps xmm8, [rsp+0x70]
000079f4d2de366e  vmovaps xmm9, [rsp+0x80]
000079f4d2de3677  vmovaps xmm10, [rsp+0x90]
000079f4d2de3680  vmovaps xmm11, [rsp+0xA0]
000079f4d2de3689  vmovaps xmm12, [rsp+0xB0]
000079f4d2de3692  vmovaps xmm13, [rsp+0xC0]
000079f4d2de369b  vmovaps xmm14, [rsp+0xD0]
000079f4d2de36a4  vmovaps xmm15, [rsp+0xE0]
000079f4d2de36ad  add rsp, 0xF0
000079f4d2de36b4  pop r11
000079f4d2de36b6  pop r10
000079f4d2de36b8  pop r9
000079f4d2de36ba  pop r8
000079f4d2de36bc  pop rsi
000079f4d2de36bd  pop rdi
000079f4d2de36be  pop rdx
000079f4d2de36bf  pop rcx
000079f4d2de36c0  pop rax
000079f4d2de36c1  add rsp, 0x08
000079f4d2de36c5  jmp 0x000079F4D2DDF7AD
000079f4d2de36ca  sub rsp, 0x08
000079f4d2de36ce  push rax
000079f4d2de36cf  push rcx
000079f4d2de36d0  push rdx
000079f4d2de36d1  push rdi
000079f4d2de36d2  push rsi
000079f4d2de36d3  push r8
000079f4d2de36d5  push r9
000079f4d2de36d7  push r10
000079f4d2de36d9  push r11
000079f4d2de36db  sub rsp, 0xF0
000079f4d2de36e2  vmovaps [rsp], xmm0
000079f4d2de36e7  vmovaps [rsp+0x10], xmm1
000079f4d2de36ed  vmovaps [rsp+0x20], xmm2
000079f4d2de36f3  vmovaps [rsp+0x30], xmm3
000079f4d2de36f9  vmovaps [rsp+0x40], xmm4
000079f4d2de36ff  vmovaps [rsp+0x50], xmm5
000079f4d2de3705  vmovaps [rsp+0x60], xmm6
000079f4d2de370b  vmovaps [rsp+0x70], xmm7
000079f4d2de3711  vmovaps [rsp+0x80], xmm8
000079f4d2de371a  vmovaps [rsp+0x90], xmm9
000079f4d2de3723  vmovaps [rsp+0xA0], xmm10
000079f4d2de372c  vmovaps [rsp+0xB0], xmm11
000079f4d2de3735  vmovaps [rsp+0xC0], xmm13
000079f4d2de373e  vmovaps [rsp+0xD0], xmm14
000079f4d2de3747  vmovaps [rsp+0xE0], xmm15
000079f4d2de3750  sub rsp, 0x30
000079f4d2de3754  movaps [rsp], xmm12
000079f4d2de3759  movaps [rsp+0x10], xmm7
000079f4d2de375e  movaps [rsp+0x20], xmm13
000079f4d2de3764  lea rdi, [rsp]
000079f4d2de3768  mov esi, 0x00
000079f4d2de376d  mov rax, 0x5D9EC01E8530
000079f4d2de3777  call rax
000079f4d2de3779  movaps xmm12, [rsp]
000079f4d2de377e  add rsp, 0x30
000079f4d2de3782  vmovaps xmm0, [rsp]
000079f4d2de3787  vmovaps xmm1, [rsp+0x10]
000079f4d2de378d  vmovaps xmm2, [rsp+0x20]
000079f4d2de3793  vmovaps xmm3, [rsp+0x30]
000079f4d2de3799  vmovaps xmm4, [rsp+0x40]
000079f4d2de379f  vmovaps xmm5, [rsp+0x50]
000079f4d2de37a5  vmovaps xmm6, [rsp+0x60]
000079f4d2de37ab  vmovaps xmm7, [rsp+0x70]
000079f4d2de37b1  vmovaps xmm8, [rsp+0x80]
000079f4d2de37ba  vmovaps xmm9, [rsp+0x90]
000079f4d2de37c3  vmovaps xmm10, [rsp+0xA0]
000079f4d2de37cc  vmovaps xmm11, [rsp+0xB0]
000079f4d2de37d5  vmovaps xmm13, [rsp+0xC0]
000079f4d2de37de  vmovaps xmm14, [rsp+0xD0]
000079f4d2de37e7  vmovaps xmm15, [rsp+0xE0]
000079f4d2de37f0  add rsp, 0xF0
000079f4d2de37f7  pop r11
000079f4d2de37f9  pop r10
000079f4d2de37fb  pop r9
000079f4d2de37fd  pop r8
000079f4d2de37ff  pop rsi
000079f4d2de3800  pop rdi
000079f4d2de3801  pop rdx
000079f4d2de3802  pop rcx
000079f4d2de3803  pop rax
000079f4d2de3804  add rsp, 0x08
000079f4d2de3808  jmp 0x000079F4D2DDF7D4
000079f4d2de380d  sub rsp, 0x08
000079f4d2de3811  push rax
000079f4d2de3812  push rcx
000079f4d2de3813  push rdx
000079f4d2de3814  push rdi
000079f4d2de3815  push rsi
000079f4d2de3816  push r8
000079f4d2de3818  push r9
000079f4d2de381a  push r10
000079f4d2de381c  push r11
000079f4d2de381e  sub rsp, 0xF0
000079f4d2de3825  vmovaps [rsp], xmm0
000079f4d2de382a  vmovaps [rsp+0x10], xmm1
000079f4d2de3830  vmovaps [rsp+0x20], xmm2
000079f4d2de3836  vmovaps [rsp+0x30], xmm3
000079f4d2de383c  vmovaps [rsp+0x40], xmm4
000079f4d2de3842  vmovaps [rsp+0x50], xmm5
000079f4d2de3848  vmovaps [rsp+0x60], xmm6
000079f4d2de384e  vmovaps [rsp+0x70], xmm7
000079f4d2de3854  vmovaps [rsp+0x80], xmm8
000079f4d2de385d  vmovaps [rsp+0x90], xmm9
000079f4d2de3866  vmovaps [rsp+0xA0], xmm10
000079f4d2de386f  vmovaps [rsp+0xB0], xmm11
000079f4d2de3878  vmovaps [rsp+0xC0], xmm12
000079f4d2de3881  vmovaps [rsp+0xD0], xmm14
000079f4d2de388a  vmovaps [rsp+0xE0], xmm15
000079f4d2de3893  sub rsp, 0x30
000079f4d2de3897  movaps [rsp], xmm13
000079f4d2de389c  movaps [rsp+0x10], xmm15
000079f4d2de38a2  movaps [rsp+0x20], xmm8
000079f4d2de38a8  lea rdi, [rsp]
000079f4d2de38ac  mov esi, 0x00
000079f4d2de38b1  mov rax, 0x5D9EC01E8530
000079f4d2de38bb  call rax
000079f4d2de38bd  movaps xmm13, [rsp]
000079f4d2de38c2  add rsp, 0x30
000079f4d2de38c6  vmovaps xmm0, [rsp]
000079f4d2de38cb  vmovaps xmm1, [rsp+0x10]
000079f4d2de38d1  vmovaps xmm2, [rsp+0x20]
000079f4d2de38d7  vmovaps xmm3, [rsp+0x30]
000079f4d2de38dd  vmovaps xmm4, [rsp+0x40]
000079f4d2de38e3  vmovaps xmm5, [rsp+0x50]
000079f4d2de38e9  vmovaps xmm6, [rsp+0x60]
000079f4d2de38ef  vmovaps xmm7, [rsp+0x70]
000079f4d2de38f5  vmovaps xmm8, [rsp+0x80]
000079f4d2de38fe  vmovaps xmm9, [rsp+0x90]
000079f4d2de3907  vmovaps xmm10, [rsp+0xA0]
000079f4d2de3910  vmovaps xmm11, [rsp+0xB0]
000079f4d2de3919  vmovaps xmm12, [rsp+0xC0]
000079f4d2de3922  vmovaps xmm14, [rsp+0xD0]
000079f4d2de392b  vmovaps xmm15, [rsp+0xE0]
000079f4d2de3934  add rsp, 0xF0
000079f4d2de393b  pop r11
000079f4d2de393d  pop r10
000079f4d2de393f  pop r9
000079f4d2de3941  pop r8
000079f4d2de3943  pop rsi
000079f4d2de3944  pop rdi
000079f4d2de3945  pop rdx
000079f4d2de3946  pop rcx
000079f4d2de3947  pop rax
000079f4d2de3948  add rsp, 0x08
000079f4d2de394c  jmp 0x000079F4D2DDF7EF
000079f4d2de3951  sub rsp, 0x08
000079f4d2de3955  push rax
000079f4d2de3956  push rcx
000079f4d2de3957  push rdx
000079f4d2de3958  push rdi
000079f4d2de3959  push rsi
000079f4d2de395a  push r8
000079f4d2de395c  push r9
000079f4d2de395e  push r10
000079f4d2de3960  push r11
000079f4d2de3962  sub rsp, 0xF0
000079f4d2de3969  vmovaps [rsp], xmm0
000079f4d2de396e  vmovaps [rsp+0x10], xmm1
000079f4d2de3974  vmovaps [rsp+0x20], xmm2
000079f4d2de397a  vmovaps [rsp+0x30], xmm3
000079f4d2de3980  vmovaps [rsp+0x40], xmm4
000079f4d2de3986  vmovaps [rsp+0x50], xmm5
000079f4d2de398c  vmovaps [rsp+0x60], xmm6
000079f4d2de3992  vmovaps [rsp+0x70], xmm7
000079f4d2de3998  vmovaps [rsp+0x80], xmm9
000079f4d2de39a1  vmovaps [rsp+0x90], xmm10
000079f4d2de39aa  vmovaps [rsp+0xA0], xmm11
000079f4d2de39b3  vmovaps [rsp+0xB0], xmm12
000079f4d2de39bc  vmovaps [rsp+0xC0], xmm13
000079f4d2de39c5  vmovaps [rsp+0xD0], xmm14
000079f4d2de39ce  vmovaps [rsp+0xE0], xmm15
000079f4d2de39d7  sub rsp, 0x30
000079f4d2de39db  movaps [rsp], xmm8
000079f4d2de39e0  movaps [rsp+0x10], xmm15
000079f4d2de39e6  movaps [rsp+0x20], xmm9
000079f4d2de39ec  lea rdi, [rsp]
000079f4d2de39f0  mov esi, 0x00
000079f4d2de39f5  mov rax, 0x5D9EC01E8530
000079f4d2de39ff  call rax
000079f4d2de3a01  movaps xmm8, [rsp]
000079f4d2de3a06  add rsp, 0x30
000079f4d2de3a0a  vmovaps xmm0, [rsp]
000079f4d2de3a0f  vmovaps xmm1, [rsp+0x10]
000079f4d2de3a15  vmovaps xmm2, [rsp+0x20]
000079f4d2de3a1b  vmovaps xmm3, [rsp+0x30]
000079f4d2de3a21  vmovaps xmm4, [rsp+0x40]
000079f4d2de3a27  vmovaps xmm5, [rsp+0x50]
000079f4d2de3a2d  vmovaps xmm6, [rsp+0x60]
000079f4d2de3a33  vmovaps xmm7, [rsp+0x70]
000079f4d2de3a39  vmovaps xmm9, [rsp+0x80]
000079f4d2de3a42  vmovaps xmm10, [rsp+0x90]
000079f4d2de3a4b  vmovaps xmm11, [rsp+0xA0]
000079f4d2de3a54  vmovaps xmm12, [rsp+0xB0]
000079f4d2de3a5d  vmovaps xmm13, [rsp+0xC0]
000079f4d2de3a66  vmovaps xmm14, [rsp+0xD0]
000079f4d2de3a6f  vmovaps xmm15, [rsp+0xE0]
000079f4d2de3a78  add rsp, 0xF0
000079f4d2de3a7f  pop r11
000079f4d2de3a81  pop r10
000079f4d2de3a83  pop r9
000079f4d2de3a85  pop r8
000079f4d2de3a87  pop rsi
000079f4d2de3a88  pop rdi
000079f4d2de3a89  pop rdx
000079f4d2de3a8a  pop rcx
000079f4d2de3a8b  pop rax
000079f4d2de3a8c  add rsp, 0x08
000079f4d2de3a90  jmp 0x000079F4D2DDF81D
000079f4d2de3a95  sub rsp, 0x08
000079f4d2de3a99  push rax
000079f4d2de3a9a  push rcx
000079f4d2de3a9b  push rdx
000079f4d2de3a9c  push rdi
000079f4d2de3a9d  push rsi
000079f4d2de3a9e  push r8
000079f4d2de3aa0  push r9
000079f4d2de3aa2  push r10
000079f4d2de3aa4  push r11
000079f4d2de3aa6  sub rsp, 0xF0
000079f4d2de3aad  vmovaps [rsp], xmm0
000079f4d2de3ab2  vmovaps [rsp+0x10], xmm1
000079f4d2de3ab8  vmovaps [rsp+0x20], xmm2
000079f4d2de3abe  vmovaps [rsp+0x30], xmm3
000079f4d2de3ac4  vmovaps [rsp+0x40], xmm4
000079f4d2de3aca  vmovaps [rsp+0x50], xmm5
000079f4d2de3ad0  vmovaps [rsp+0x60], xmm6
000079f4d2de3ad6  vmovaps [rsp+0x70], xmm7
000079f4d2de3adc  vmovaps [rsp+0x80], xmm8
000079f4d2de3ae5  vmovaps [rsp+0x90], xmm9
000079f4d2de3aee  vmovaps [rsp+0xA0], xmm10
000079f4d2de3af7  vmovaps [rsp+0xB0], xmm11
000079f4d2de3b00  vmovaps [rsp+0xC0], xmm12
000079f4d2de3b09  vmovaps [rsp+0xD0], xmm13
000079f4d2de3b12  vmovaps [rsp+0xE0], xmm14
000079f4d2de3b1b  sub rsp, 0x30
000079f4d2de3b1f  movaps [rsp], xmm15
000079f4d2de3b24  movaps [rsp+0x10], xmm11
000079f4d2de3b2a  movaps [rsp+0x20], xmm6
000079f4d2de3b2f  lea rdi, [rsp]
000079f4d2de3b33  mov esi, 0x00
000079f4d2de3b38  mov rax, 0x5D9EC01E8530
000079f4d2de3b42  call rax
000079f4d2de3b44  movaps xmm15, [rsp]
000079f4d2de3b49  add rsp, 0x30
000079f4d2de3b4d  vmovaps xmm0, [rsp]
000079f4d2de3b52  vmovaps xmm1, [rsp+0x10]
000079f4d2de3b58  vmovaps xmm2, [rsp+0x20]
000079f4d2de3b5e  vmovaps xmm3, [rsp+0x30]
000079f4d2de3b64  vmovaps xmm4, [rsp+0x40]
000079f4d2de3b6a  vmovaps xmm5, [rsp+0x50]
000079f4d2de3b70  vmovaps xmm6, [rsp+0x60]
000079f4d2de3b76  vmovaps xmm7, [rsp+0x70]
000079f4d2de3b7c  vmovaps xmm8, [rsp+0x80]
000079f4d2de3b85  vmovaps xmm9, [rsp+0x90]
000079f4d2de3b8e  vmovaps xmm10, [rsp+0xA0]
000079f4d2de3b97  vmovaps xmm11, [rsp+0xB0]
000079f4d2de3ba0  vmovaps xmm12, [rsp+0xC0]
000079f4d2de3ba9  vmovaps xmm13, [rsp+0xD0]
000079f4d2de3bb2  vmovaps xmm14, [rsp+0xE0]
000079f4d2de3bbb  add rsp, 0xF0
000079f4d2de3bc2  pop r11
000079f4d2de3bc4  pop r10
000079f4d2de3bc6  pop r9
000079f4d2de3bc8  pop r8
000079f4d2de3bca  pop rsi
000079f4d2de3bcb  pop rdi
000079f4d2de3bcc  pop rdx
000079f4d2de3bcd  pop rcx
000079f4d2de3bce  pop rax
000079f4d2de3bcf  add rsp, 0x08
000079f4d2de3bd3  jmp 0x000079F4D2DDF838
000079f4d2de3bd8  sub rsp, 0x08
000079f4d2de3bdc  push rax
000079f4d2de3bdd  push rcx
000079f4d2de3bde  push rdx
000079f4d2de3bdf  push rdi
000079f4d2de3be0  push rsi
000079f4d2de3be1  push r8
000079f4d2de3be3  push r9
000079f4d2de3be5  push r10
000079f4d2de3be7  push r11
000079f4d2de3be9  sub rsp, 0xF0
000079f4d2de3bf0  vmovaps [rsp], xmm0
000079f4d2de3bf5  vmovaps [rsp+0x10], xmm1
000079f4d2de3bfb  vmovaps [rsp+0x20], xmm2
000079f4d2de3c01  vmovaps [rsp+0x30], xmm3
000079f4d2de3c07  vmovaps [rsp+0x40], xmm4
000079f4d2de3c0d  vmovaps [rsp+0x50], xmm5
000079f4d2de3c13  vmovaps [rsp+0x60], xmm6
000079f4d2de3c19  vmovaps [rsp+0x70], xmm8
000079f4d2de3c1f  vmovaps [rsp+0x80], xmm9
000079f4d2de3c28  vmovaps [rsp+0x90], xmm10
000079f4d2de3c31  vmovaps [rsp+0xA0], xmm11
000079f4d2de3c3a  vmovaps [rsp+0xB0], xmm12
000079f4d2de3c43  vmovaps [rsp+0xC0], xmm13
000079f4d2de3c4c  vmovaps [rsp+0xD0], xmm14
000079f4d2de3c55  vmovaps [rsp+0xE0], xmm15
000079f4d2de3c5e  sub rsp, 0x30
000079f4d2de3c62  movaps [rsp], xmm7
000079f4d2de3c66  movaps [rsp+0x10], xmm11
000079f4d2de3c6c  movaps [rsp+0x20], xmm9
000079f4d2de3c72  lea rdi, [rsp]
000079f4d2de3c76  mov esi, 0x00
000079f4d2de3c7b  mov rax, 0x5D9EC01E8530
000079f4d2de3c85  call rax
000079f4d2de3c87  movaps xmm7, [rsp]
000079f4d2de3c8b  add rsp, 0x30
000079f4d2de3c8f  vmovaps xmm0, [rsp]
000079f4d2de3c94  vmovaps xmm1, [rsp+0x10]
000079f4d2de3c9a  vmovaps xmm2, [rsp+0x20]
000079f4d2de3ca0  vmovaps xmm3, [rsp+0x30]
000079f4d2de3ca6  vmovaps xmm4, [rsp+0x40]
000079f4d2de3cac  vmovaps xmm5, [rsp+0x50]
000079f4d2de3cb2  vmovaps xmm6, [rsp+0x60]
000079f4d2de3cb8  vmovaps xmm8, [rsp+0x70]
000079f4d2de3cbe  vmovaps xmm9, [rsp+0x80]
000079f4d2de3cc7  vmovaps xmm10, [rsp+0x90]
000079f4d2de3cd0  vmovaps xmm11, [rsp+0xA0]
000079f4d2de3cd9  vmovaps xmm12, [rsp+0xB0]
000079f4d2de3ce2  vmovaps xmm13, [rsp+0xC0]
000079f4d2de3ceb  vmovaps xmm14, [rsp+0xD0]
000079f4d2de3cf4  vmovaps xmm15, [rsp+0xE0]
000079f4d2de3cfd  add rsp, 0xF0
000079f4d2de3d04  pop r11
000079f4d2de3d06  pop r10
000079f4d2de3d08  pop r9
000079f4d2de3d0a  pop r8
000079f4d2de3d0c  pop rsi
000079f4d2de3d0d  pop rdi
000079f4d2de3d0e  pop rdx
000079f4d2de3d0f  pop rcx
000079f4d2de3d10  pop rax
000079f4d2de3d11  add rsp, 0x08
000079f4d2de3d15  jmp 0x000079F4D2DDF865
000079f4d2de3d1a  sub rsp, 0x08
000079f4d2de3d1e  push rax
000079f4d2de3d1f  push rcx
000079f4d2de3d20  push rdx
000079f4d2de3d21  push rdi
000079f4d2de3d22  push rsi
000079f4d2de3d23  push r8
000079f4d2de3d25  push r9
000079f4d2de3d27  push r10
000079f4d2de3d29  push r11
000079f4d2de3d2b  sub rsp, 0xF0
000079f4d2de3d32  vmovaps [rsp], xmm0
000079f4d2de3d37  vmovaps [rsp+0x10], xmm1
000079f4d2de3d3d  vmovaps [rsp+0x20], xmm2
000079f4d2de3d43  vmovaps [rsp+0x30], xmm3
000079f4d2de3d49  vmovaps [rsp+0x40], xmm4
000079f4d2de3d4f  vmovaps [rsp+0x50], xmm5
000079f4d2de3d55  vmovaps [rsp+0x60], xmm6
000079f4d2de3d5b  vmovaps [rsp+0x70], xmm7
000079f4d2de3d61  vmovaps [rsp+0x80], xmm8
000079f4d2de3d6a  vmovaps [rsp+0x90], xmm9
000079f4d2de3d73  vmovaps [rsp+0xA0], xmm10
000079f4d2de3d7c  vmovaps [rsp+0xB0], xmm12
000079f4d2de3d85  vmovaps [rsp+0xC0], xmm13
000079f4d2de3d8e  vmovaps [rsp+0xD0], xmm14
000079f4d2de3d97  vmovaps [rsp+0xE0], xmm15
000079f4d2de3da0  sub rsp, 0x30
000079f4d2de3da4  movaps [rsp], xmm11
000079f4d2de3da9  movaps [rsp+0x10], xmm10
000079f4d2de3daf  movaps [rsp+0x20], xmm14
000079f4d2de3db5  lea rdi, [rsp]
000079f4d2de3db9  mov esi, 0x00
000079f4d2de3dbe  mov rax, 0x5D9EC01E8530
000079f4d2de3dc8  call rax
000079f4d2de3dca  movaps xmm11, [rsp]
000079f4d2de3dcf  add rsp, 0x30
000079f4d2de3dd3  vmovaps xmm0, [rsp]
000079f4d2de3dd8  vmovaps xmm1, [rsp+0x10]
000079f4d2de3dde  vmovaps xmm2, [rsp+0x20]
000079f4d2de3de4  vmovaps xmm3, [rsp+0x30]
000079f4d2de3dea  vmovaps xmm4, [rsp+0x40]
000079f4d2de3df0  vmovaps xmm5, [rsp+0x50]
000079f4d2de3df6  vmovaps xmm6, [rsp+0x60]
000079f4d2de3dfc  vmovaps xmm7, [rsp+0x70]
000079f4d2de3e02  vmovaps xmm8, [rsp+0x80]
000079f4d2de3e0b  vmovaps xmm9, [rsp+0x90]
000079f4d2de3e14  vmovaps xmm10, [rsp+0xA0]
000079f4d2de3e1d  vmovaps xmm12, [rsp+0xB0]
000079f4d2de3e26  vmovaps xmm13, [rsp+0xC0]
000079f4d2de3e2f  vmovaps xmm14, [rsp+0xD0]
000079f4d2de3e38  vmovaps xmm15, [rsp+0xE0]
000079f4d2de3e41  add rsp, 0xF0
000079f4d2de3e48  pop r11
000079f4d2de3e4a  pop r10
000079f4d2de3e4c  pop r9
000079f4d2de3e4e  pop r8
000079f4d2de3e50  pop rsi
000079f4d2de3e51  pop rdi
000079f4d2de3e52  pop rdx
000079f4d2de3e53  pop rcx
000079f4d2de3e54  pop rax
000079f4d2de3e55  add rsp, 0x08
000079f4d2de3e59  jmp 0x000079F4D2DDF880
000079f4d2de3e5e  call 0x000079F4D2CC33A0
000079f4d2de3e63  jmp 0x000079F4D2DDF88A
000079f4d2de3e68  sub rsp, 0x08
000079f4d2de3e6c  push rax
000079f4d2de3e6d  push rcx
000079f4d2de3e6e  push rdx
000079f4d2de3e6f  push rdi
000079f4d2de3e70  push rsi
000079f4d2de3e71  push r8
000079f4d2de3e73  push r9
000079f4d2de3e75  push r10
000079f4d2de3e77  push r11
000079f4d2de3e79  sub rsp, 0xF0
000079f4d2de3e80  vmovaps [rsp], xmm0
000079f4d2de3e85  vmovaps [rsp+0x10], xmm1
000079f4d2de3e8b  vmovaps [rsp+0x20], xmm2
000079f4d2de3e91  vmovaps [rsp+0x30], xmm3
000079f4d2de3e97  vmovaps [rsp+0x40], xmm4
000079f4d2de3e9d  vmovaps [rsp+0x50], xmm5
000079f4d2de3ea3  vmovaps [rsp+0x60], xmm6
000079f4d2de3ea9  vmovaps [rsp+0x70], xmm7
000079f4d2de3eaf  vmovaps [rsp+0x80], xmm8
000079f4d2de3eb8  vmovaps [rsp+0x90], xmm9
000079f4d2de3ec1  vmovaps [rsp+0xA0], xmm11
000079f4d2de3eca  vmovaps [rsp+0xB0], xmm12
000079f4d2de3ed3  vmovaps [rsp+0xC0], xmm13
000079f4d2de3edc  vmovaps [rsp+0xD0], xmm14
000079f4d2de3ee5  vmovaps [rsp+0xE0], xmm15
000079f4d2de3eee  sub rsp, 0x30
000079f4d2de3ef2  movaps [rsp], xmm10
000079f4d2de3ef7  movaps [rsp+0x10], xmm1
000079f4d2de3efc  movaps [rsp+0x20], xmm12
000079f4d2de3f02  lea rdi, [rsp]
000079f4d2de3f06  mov esi, 0x00
000079f4d2de3f0b  mov rax, 0x5D9EC01E8530
000079f4d2de3f15  call rax
000079f4d2de3f17  movaps xmm10, [rsp]
000079f4d2de3f1c  add rsp, 0x30
000079f4d2de3f20  vmovaps xmm0, [rsp]
000079f4d2de3f25  vmovaps xmm1, [rsp+0x10]
000079f4d2de3f2b  vmovaps xmm2, [rsp+0x20]
000079f4d2de3f31  vmovaps xmm3, [rsp+0x30]
000079f4d2de3f37  vmovaps xmm4, [rsp+0x40]
000079f4d2de3f3d  vmovaps xmm5, [rsp+0x50]
000079f4d2de3f43  vmovaps xmm6, [rsp+0x60]
000079f4d2de3f49  vmovaps xmm7, [rsp+0x70]
000079f4d2de3f4f  vmovaps xmm8, [rsp+0x80]
000079f4d2de3f58  vmovaps xmm9, [rsp+0x90]
000079f4d2de3f61  vmovaps xmm11, [rsp+0xA0]
000079f4d2de3f6a  vmovaps xmm12, [rsp+0xB0]
000079f4d2de3f73  vmovaps xmm13, [rsp+0xC0]
000079f4d2de3f7c  vmovaps xmm14, [rsp+0xD0]
000079f4d2de3f85  vmovaps xmm15, [rsp+0xE0]
000079f4d2de3f8e  add rsp, 0xF0
000079f4d2de3f95  pop r11
000079f4d2de3f97  pop r10
000079f4d2de3f99  pop r9
000079f4d2de3f9b  pop r8
000079f4d2de3f9d  pop rsi
000079f4d2de3f9e  pop rdi
000079f4d2de3f9f  pop rdx
000079f4d2de3fa0  pop rcx
000079f4d2de3fa1  pop rax
000079f4d2de3fa2  add rsp, 0x08
000079f4d2de3fa6  jmp 0x000079F4D2DDF8AD
000079f4d2de3fab  sub rsp, 0x08
000079f4d2de3faf  push rax
000079f4d2de3fb0  push rcx
000079f4d2de3fb1  push rdx
000079f4d2de3fb2  push rdi
000079f4d2de3fb3  push rsi
000079f4d2de3fb4  push r8
000079f4d2de3fb6  push r9
000079f4d2de3fb8  push r10
000079f4d2de3fba  push r11
000079f4d2de3fbc  sub rsp, 0xF0
000079f4d2de3fc3  vmovaps [rsp], xmm0
000079f4d2de3fc8  vmovaps [rsp+0x10], xmm1
000079f4d2de3fce  vmovaps [rsp+0x20], xmm2
000079f4d2de3fd4  vmovaps [rsp+0x30], xmm3
000079f4d2de3fda  vmovaps [rsp+0x40], xmm4
000079f4d2de3fe0  vmovaps [rsp+0x50], xmm5
000079f4d2de3fe6  vmovaps [rsp+0x60], xmm6
000079f4d2de3fec  vmovaps [rsp+0x70], xmm7
000079f4d2de3ff2  vmovaps [rsp+0x80], xmm8
000079f4d2de3ffb  vmovaps [rsp+0x90], xmm9
000079f4d2de4004  vmovaps [rsp+0xA0], xmm10
000079f4d2de400d  vmovaps [rsp+0xB0], xmm11
000079f4d2de4016  vmovaps [rsp+0xC0], xmm13
000079f4d2de401f  vmovaps [rsp+0xD0], xmm14
000079f4d2de4028  vmovaps [rsp+0xE0], xmm15
000079f4d2de4031  sub rsp, 0x30
000079f4d2de4035  movaps [rsp], xmm12
000079f4d2de403a  movaps [rsp+0x10], xmm14
000079f4d2de4040  movaps [rsp+0x20], xmm1
000079f4d2de4045  lea rdi, [rsp]
000079f4d2de4049  mov esi, 0x00
000079f4d2de404e  mov rax, 0x5D9EC01E8530
000079f4d2de4058  call rax
000079f4d2de405a  movaps xmm12, [rsp]
000079f4d2de405f  add rsp, 0x30
000079f4d2de4063  vmovaps xmm0, [rsp]
000079f4d2de4068  vmovaps xmm1, [rsp+0x10]
000079f4d2de406e  vmovaps xmm2, [rsp+0x20]
000079f4d2de4074  vmovaps xmm3, [rsp+0x30]
000079f4d2de407a  vmovaps xmm4, [rsp+0x40]
000079f4d2de4080  vmovaps xmm5, [rsp+0x50]
000079f4d2de4086  vmovaps xmm6, [rsp+0x60]
000079f4d2de408c  vmovaps xmm7, [rsp+0x70]
000079f4d2de4092  vmovaps xmm8, [rsp+0x80]
000079f4d2de409b  vmovaps xmm9, [rsp+0x90]
000079f4d2de40a4  vmovaps xmm10, [rsp+0xA0]
000079f4d2de40ad  vmovaps xmm11, [rsp+0xB0]
000079f4d2de40b6  vmovaps xmm13, [rsp+0xC0]
000079f4d2de40bf  vmovaps xmm14, [rsp+0xD0]
000079f4d2de40c8  vmovaps xmm15, [rsp+0xE0]
000079f4d2de40d1  add rsp, 0xF0
000079f4d2de40d8  pop r11
000079f4d2de40da  pop r10
000079f4d2de40dc  pop r9
000079f4d2de40de  pop r8
000079f4d2de40e0  pop rsi
000079f4d2de40e1  pop rdi
000079f4d2de40e2  pop rdx
000079f4d2de40e3  pop rcx
000079f4d2de40e4  pop rax
000079f4d2de40e5  add rsp, 0x08
000079f4d2de40e9  jmp 0x000079F4D2DDF8DC
000079f4d2de40ee  sub rsp, 0x08
000079f4d2de40f2  push rax
000079f4d2de40f3  push rcx
000079f4d2de40f4  push rdx
000079f4d2de40f5  push rdi
000079f4d2de40f6  push rsi
000079f4d2de40f7  push r8
000079f4d2de40f9  push r9
000079f4d2de40fb  push r10
000079f4d2de40fd  push r11
000079f4d2de40ff  sub rsp, 0xF0
000079f4d2de4106  vmovaps [rsp], xmm0
000079f4d2de410b  vmovaps [rsp+0x10], xmm1
000079f4d2de4111  vmovaps [rsp+0x20], xmm2
000079f4d2de4117  vmovaps [rsp+0x30], xmm3
000079f4d2de411d  vmovaps [rsp+0x40], xmm4
000079f4d2de4123  vmovaps [rsp+0x50], xmm5
000079f4d2de4129  vmovaps [rsp+0x60], xmm6
000079f4d2de412f  vmovaps [rsp+0x70], xmm7
000079f4d2de4135  vmovaps [rsp+0x80], xmm8
000079f4d2de413e  vmovaps [rsp+0x90], xmm9
000079f4d2de4147  vmovaps [rsp+0xA0], xmm10
000079f4d2de4150  vmovaps [rsp+0xB0], xmm11
000079f4d2de4159  vmovaps [rsp+0xC0], xmm12
000079f4d2de4162  vmovaps [rsp+0xD0], xmm13
000079f4d2de416b  vmovaps [rsp+0xE0], xmm15
000079f4d2de4174  sub rsp, 0x30
000079f4d2de4178  movaps [rsp], xmm14
000079f4d2de417d  movaps [rsp+0x10], xmm9
000079f4d2de4183  movaps [rsp+0x20], xmm1
000079f4d2de4188  lea rdi, [rsp]
000079f4d2de418c  mov esi, 0x00
000079f4d2de4191  mov rax, 0x5D9EC01E8530
000079f4d2de419b  call rax
000079f4d2de419d  movaps xmm14, [rsp]
000079f4d2de41a2  add rsp, 0x30
000079f4d2de41a6  vmovaps xmm0, [rsp]
000079f4d2de41ab  vmovaps xmm1, [rsp+0x10]
000079f4d2de41b1  vmovaps xmm2, [rsp+0x20]
000079f4d2de41b7  vmovaps xmm3, [rsp+0x30]
000079f4d2de41bd  vmovaps xmm4, [rsp+0x40]
000079f4d2de41c3  vmovaps xmm5, [rsp+0x50]
000079f4d2de41c9  vmovaps xmm6, [rsp+0x60]
000079f4d2de41cf  vmovaps xmm7, [rsp+0x70]
000079f4d2de41d5  vmovaps xmm8, [rsp+0x80]
000079f4d2de41de  vmovaps xmm9, [rsp+0x90]
000079f4d2de41e7  vmovaps xmm10, [rsp+0xA0]
000079f4d2de41f0  vmovaps xmm11, [rsp+0xB0]
000079f4d2de41f9  vmovaps xmm12, [rsp+0xC0]
000079f4d2de4202  vmovaps xmm13, [rsp+0xD0]
000079f4d2de420b  vmovaps xmm15, [rsp+0xE0]
000079f4d2de4214  add rsp, 0xF0
000079f4d2de421b  pop r11
000079f4d2de421d  pop r10
000079f4d2de421f  pop r9
000079f4d2de4221  pop r8
000079f4d2de4223  pop rsi
000079f4d2de4224  pop rdi
000079f4d2de4225  pop rdx
000079f4d2de4226  pop rcx
000079f4d2de4227  pop rax
000079f4d2de4228  add rsp, 0x08
000079f4d2de422c  jmp 0x000079F4D2DDF90B
000079f4d2de4231  sub rsp, 0x08
000079f4d2de4235  push rax
000079f4d2de4236  push rcx
000079f4d2de4237  push rdx
000079f4d2de4238  push rdi
000079f4d2de4239  push rsi
000079f4d2de423a  push r8
000079f4d2de423c  push r9
000079f4d2de423e  push r10
000079f4d2de4240  push r11
000079f4d2de4242  sub rsp, 0xF0
000079f4d2de4249  vmovaps [rsp], xmm0
000079f4d2de424e  vmovaps [rsp+0x10], xmm2
000079f4d2de4254  vmovaps [rsp+0x20], xmm3
000079f4d2de425a  vmovaps [rsp+0x30], xmm4
000079f4d2de4260  vmovaps [rsp+0x40], xmm5
000079f4d2de4266  vmovaps [rsp+0x50], xmm6
000079f4d2de426c  vmovaps [rsp+0x60], xmm7
000079f4d2de4272  vmovaps [rsp+0x70], xmm8
000079f4d2de4278  vmovaps [rsp+0x80], xmm9
000079f4d2de4281  vmovaps [rsp+0x90], xmm10
000079f4d2de428a  vmovaps [rsp+0xA0], xmm11
000079f4d2de4293  vmovaps [rsp+0xB0], xmm12
000079f4d2de429c  vmovaps [rsp+0xC0], xmm13
000079f4d2de42a5  vmovaps [rsp+0xD0], xmm14
000079f4d2de42ae  vmovaps [rsp+0xE0], xmm15
000079f4d2de42b7  sub rsp, 0x30
000079f4d2de42bb  movaps [rsp], xmm1
000079f4d2de42bf  movaps [rsp+0x10], xmm13
000079f4d2de42c5  movaps [rsp+0x20], xmm8
000079f4d2de42cb  lea rdi, [rsp]
000079f4d2de42cf  mov esi, 0x00
000079f4d2de42d4  mov rax, 0x5D9EC01E8530
000079f4d2de42de  call rax
000079f4d2de42e0  movaps xmm1, [rsp]
000079f4d2de42e4  add rsp, 0x30
000079f4d2de42e8  vmovaps xmm0, [rsp]
000079f4d2de42ed  vmovaps xmm2, [rsp+0x10]
000079f4d2de42f3  vmovaps xmm3, [rsp+0x20]
000079f4d2de42f9  vmovaps xmm4, [rsp+0x30]
000079f4d2de42ff  vmovaps xmm5, [rsp+0x40]
000079f4d2de4305  vmovaps xmm6, [rsp+0x50]
000079f4d2de430b  vmovaps xmm7, [rsp+0x60]
000079f4d2de4311  vmovaps xmm8, [rsp+0x70]
000079f4d2de4317  vmovaps xmm9, [rsp+0x80]
000079f4d2de4320  vmovaps xmm10, [rsp+0x90]
000079f4d2de4329  vmovaps xmm11, [rsp+0xA0]
000079f4d2de4332  vmovaps xmm12, [rsp+0xB0]
000079f4d2de433b  vmovaps xmm13, [rsp+0xC0]
000079f4d2de4344  vmovaps xmm14, [rsp+0xD0]
000079f4d2de434d  vmovaps xmm15, [rsp+0xE0]
000079f4d2de4356  add rsp, 0xF0
000079f4d2de435d  pop r11
000079f4d2de435f  pop r10
000079f4d2de4361  pop r9
000079f4d2de4363  pop r8
000079f4d2de4365  pop rsi
000079f4d2de4366  pop rdi
000079f4d2de4367  pop rdx
000079f4d2de4368  pop rcx
000079f4d2de4369  pop rax
000079f4d2de436a  add rsp, 0x08
000079f4d2de436e  jmp 0x000079F4D2DDF92D
000079f4d2de4373  call 0x000079F4D2C0C260
000079f4d2de4378  jmp 0x000079F4D2DDF93B
000079f4d2de437d  call 0x000079F4D2CBD750
000079f4d2de4382  jmp 0x000079F4D2DDF945
000079f4d2de4387  sub rsp, 0x08
000079f4d2de438b  push rax
000079f4d2de438c  push rcx
000079f4d2de438d  push rdx
000079f4d2de438e  push rdi
000079f4d2de438f  push rsi
000079f4d2de4390  push r8
000079f4d2de4392  push r9
000079f4d2de4394  push r10
000079f4d2de4396  push r11
000079f4d2de4398  sub rsp, 0xF0
000079f4d2de439f  vmovaps [rsp], xmm0
000079f4d2de43a4  vmovaps [rsp+0x10], xmm1
000079f4d2de43aa  vmovaps [rsp+0x20], xmm2
000079f4d2de43b0  vmovaps [rsp+0x30], xmm3
000079f4d2de43b6  vmovaps [rsp+0x40], xmm4
000079f4d2de43bc  vmovaps [rsp+0x50], xmm5
000079f4d2de43c2  vmovaps [rsp+0x60], xmm6
000079f4d2de43c8  vmovaps [rsp+0x70], xmm7
000079f4d2de43ce  vmovaps [rsp+0x80], xmm9
000079f4d2de43d7  vmovaps [rsp+0x90], xmm10
000079f4d2de43e0  vmovaps [rsp+0xA0], xmm11
000079f4d2de43e9  vmovaps [rsp+0xB0], xmm12
000079f4d2de43f2  vmovaps [rsp+0xC0], xmm13
000079f4d2de43fb  vmovaps [rsp+0xD0], xmm14
000079f4d2de4404  vmovaps [rsp+0xE0], xmm15
000079f4d2de440d  sub rsp, 0x30
000079f4d2de4411  movaps [rsp], xmm8
000079f4d2de4416  movaps [rsp+0x10], xmm15
000079f4d2de441c  movaps [rsp+0x20], xmm7
000079f4d2de4421  lea rdi, [rsp]
000079f4d2de4425  mov esi, 0x00
000079f4d2de442a  mov rax, 0x5D9EC01E8530
000079f4d2de4434  call rax
000079f4d2de4436  movaps xmm8, [rsp]
000079f4d2de443b  add rsp, 0x30
000079f4d2de443f  vmovaps xmm0, [rsp]
000079f4d2de4444  vmovaps xmm1, [rsp+0x10]
000079f4d2de444a  vmovaps xmm2, [rsp+0x20]
000079f4d2de4450  vmovaps xmm3, [rsp+0x30]
000079f4d2de4456  vmovaps xmm4, [rsp+0x40]
000079f4d2de445c  vmovaps xmm5, [rsp+0x50]
000079f4d2de4462  vmovaps xmm6, [rsp+0x60]
000079f4d2de4468  vmovaps xmm7, [rsp+0x70]
000079f4d2de446e  vmovaps xmm9, [rsp+0x80]
000079f4d2de4477  vmovaps xmm10, [rsp+0x90]
000079f4d2de4480  vmovaps xmm11, [rsp+0xA0]
000079f4d2de4489  vmovaps xmm12, [rsp+0xB0]
000079f4d2de4492  vmovaps xmm13, [rsp+0xC0]
000079f4d2de449b  vmovaps xmm14, [rsp+0xD0]
000079f4d2de44a4  vmovaps xmm15, [rsp+0xE0]
000079f4d2de44ad  add rsp, 0xF0
000079f4d2de44b4  pop r11
000079f4d2de44b6  pop r10
000079f4d2de44b8  pop r9
000079f4d2de44ba  pop r8
000079f4d2de44bc  pop rsi
000079f4d2de44bd  pop rdi
000079f4d2de44be  pop rdx
000079f4d2de44bf  pop rcx
000079f4d2de44c0  pop rax
000079f4d2de44c1  add rsp, 0x08
000079f4d2de44c5  jmp 0x000079F4D2DDF967
000079f4d2de44ca  sub rsp, 0x08
000079f4d2de44ce  push rax
000079f4d2de44cf  push rcx
000079f4d2de44d0  push rdx
000079f4d2de44d1  push rdi
000079f4d2de44d2  push rsi
000079f4d2de44d3  push r8
000079f4d2de44d5  push r9
000079f4d2de44d7  push r10
000079f4d2de44d9  push r11
000079f4d2de44db  sub rsp, 0xF0
000079f4d2de44e2  vmovaps [rsp], xmm0
000079f4d2de44e7  vmovaps [rsp+0x10], xmm1
000079f4d2de44ed  vmovaps [rsp+0x20], xmm2
000079f4d2de44f3  vmovaps [rsp+0x30], xmm3
000079f4d2de44f9  vmovaps [rsp+0x40], xmm4
000079f4d2de44ff  vmovaps [rsp+0x50], xmm5
000079f4d2de4505  vmovaps [rsp+0x60], xmm6
000079f4d2de450b  vmovaps [rsp+0x70], xmm8
000079f4d2de4511  vmovaps [rsp+0x80], xmm9
000079f4d2de451a  vmovaps [rsp+0x90], xmm10
000079f4d2de4523  vmovaps [rsp+0xA0], xmm11
000079f4d2de452c  vmovaps [rsp+0xB0], xmm12
000079f4d2de4535  vmovaps [rsp+0xC0], xmm13
000079f4d2de453e  vmovaps [rsp+0xD0], xmm14
000079f4d2de4547  vmovaps [rsp+0xE0], xmm15
000079f4d2de4550  sub rsp, 0x30
000079f4d2de4554  movaps [rsp], xmm7
000079f4d2de4558  movaps [rsp+0x10], xmm9
000079f4d2de455e  movaps [rsp+0x20], xmm15
000079f4d2de4564  lea rdi, [rsp]
000079f4d2de4568  mov esi, 0x00
000079f4d2de456d  mov rax, 0x5D9EC01E8530
000079f4d2de4577  call rax
000079f4d2de4579  movaps xmm7, [rsp]
000079f4d2de457d  add rsp, 0x30
000079f4d2de4581  vmovaps xmm0, [rsp]
000079f4d2de4586  vmovaps xmm1, [rsp+0x10]
000079f4d2de458c  vmovaps xmm2, [rsp+0x20]
000079f4d2de4592  vmovaps xmm3, [rsp+0x30]
000079f4d2de4598  vmovaps xmm4, [rsp+0x40]
000079f4d2de459e  vmovaps xmm5, [rsp+0x50]
000079f4d2de45a4  vmovaps xmm6, [rsp+0x60]
000079f4d2de45aa  vmovaps xmm8, [rsp+0x70]
000079f4d2de45b0  vmovaps xmm9, [rsp+0x80]
000079f4d2de45b9  vmovaps xmm10, [rsp+0x90]
000079f4d2de45c2  vmovaps xmm11, [rsp+0xA0]
000079f4d2de45cb  vmovaps xmm12, [rsp+0xB0]
000079f4d2de45d4  vmovaps xmm13, [rsp+0xC0]
000079f4d2de45dd  vmovaps xmm14, [rsp+0xD0]
000079f4d2de45e6  vmovaps xmm15, [rsp+0xE0]
000079f4d2de45ef  add rsp, 0xF0
000079f4d2de45f6  pop r11
000079f4d2de45f8  pop r10
000079f4d2de45fa  pop r9
000079f4d2de45fc  pop r8
000079f4d2de45fe  pop rsi
000079f4d2de45ff  pop rdi
000079f4d2de4600  pop rdx
000079f4d2de4601  pop rcx
000079f4d2de4602  pop rax
000079f4d2de4603  add rsp, 0x08
000079f4d2de4607  jmp 0x000079F4D2DDF994
000079f4d2de460c  sub rsp, 0x08
000079f4d2de4610  push rax
000079f4d2de4611  push rcx
000079f4d2de4612  push rdx
000079f4d2de4613  push rdi
000079f4d2de4614  push rsi
000079f4d2de4615  push r8
000079f4d2de4617  push r9
000079f4d2de4619  push r10
000079f4d2de461b  push r11
000079f4d2de461d  sub rsp, 0xF0
000079f4d2de4624  vmovaps [rsp], xmm0
000079f4d2de4629  vmovaps [rsp+0x10], xmm1
000079f4d2de462f  vmovaps [rsp+0x20], xmm2
000079f4d2de4635  vmovaps [rsp+0x30], xmm3
000079f4d2de463b  vmovaps [rsp+0x40], xmm4
000079f4d2de4641  vmovaps [rsp+0x50], xmm5
000079f4d2de4647  vmovaps [rsp+0x60], xmm6
000079f4d2de464d  vmovaps [rsp+0x70], xmm7
000079f4d2de4653  vmovaps [rsp+0x80], xmm8
000079f4d2de465c  vmovaps [rsp+0x90], xmm10
000079f4d2de4665  vmovaps [rsp+0xA0], xmm11
000079f4d2de466e  vmovaps [rsp+0xB0], xmm12
000079f4d2de4677  vmovaps [rsp+0xC0], xmm13
000079f4d2de4680  vmovaps [rsp+0xD0], xmm14
000079f4d2de4689  vmovaps [rsp+0xE0], xmm15
000079f4d2de4692  sub rsp, 0x30
000079f4d2de4696  movaps [rsp], xmm9
000079f4d2de469b  movaps [rsp+0x10], xmm13
000079f4d2de46a1  movaps [rsp+0x20], xmm15
000079f4d2de46a7  lea rdi, [rsp]
000079f4d2de46ab  mov esi, 0x00
000079f4d2de46b0  mov rax, 0x5D9EC01E8530
000079f4d2de46ba  call rax
000079f4d2de46bc  movaps xmm9, [rsp]
000079f4d2de46c1  add rsp, 0x30
000079f4d2de46c5  vmovaps xmm0, [rsp]
000079f4d2de46ca  vmovaps xmm1, [rsp+0x10]
000079f4d2de46d0  vmovaps xmm2, [rsp+0x20]
000079f4d2de46d6  vmovaps xmm3, [rsp+0x30]
000079f4d2de46dc  vmovaps xmm4, [rsp+0x40]
000079f4d2de46e2  vmovaps xmm5, [rsp+0x50]
000079f4d2de46e8  vmovaps xmm6, [rsp+0x60]
000079f4d2de46ee  vmovaps xmm7, [rsp+0x70]
000079f4d2de46f4  vmovaps xmm8, [rsp+0x80]
000079f4d2de46fd  vmovaps xmm10, [rsp+0x90]
000079f4d2de4706  vmovaps xmm11, [rsp+0xA0]
000079f4d2de470f  vmovaps xmm12, [rsp+0xB0]
000079f4d2de4718  vmovaps xmm13, [rsp+0xC0]
000079f4d2de4721  vmovaps xmm14, [rsp+0xD0]
000079f4d2de472a  vmovaps xmm15, [rsp+0xE0]
000079f4d2de4733  add rsp, 0xF0
000079f4d2de473a  pop r11
000079f4d2de473c  pop r10
000079f4d2de473e  pop r9
000079f4d2de4740  pop r8
000079f4d2de4742  pop rsi
000079f4d2de4743  pop rdi
000079f4d2de4744  pop rdx
000079f4d2de4745  pop rcx
000079f4d2de4746  pop rax
000079f4d2de4747  add rsp, 0x08
000079f4d2de474b  jmp 0x000079F4D2DDF9C2
000079f4d2de4750  sub rsp, 0x08
000079f4d2de4754  push rax
000079f4d2de4755  push rcx
000079f4d2de4756  push rdx
000079f4d2de4757  push rdi
000079f4d2de4758  push rsi
000079f4d2de4759  push r8
000079f4d2de475b  push r9
000079f4d2de475d  push r10
000079f4d2de475f  push r11
000079f4d2de4761  sub rsp, 0xF0
000079f4d2de4768  vmovaps [rsp], xmm0
000079f4d2de476d  vmovaps [rsp+0x10], xmm1
000079f4d2de4773  vmovaps [rsp+0x20], xmm2
000079f4d2de4779  vmovaps [rsp+0x30], xmm3
000079f4d2de477f  vmovaps [rsp+0x40], xmm4
000079f4d2de4785  vmovaps [rsp+0x50], xmm5
000079f4d2de478b  vmovaps [rsp+0x60], xmm6
000079f4d2de4791  vmovaps [rsp+0x70], xmm7
000079f4d2de4797  vmovaps [rsp+0x80], xmm8
000079f4d2de47a0  vmovaps [rsp+0x90], xmm9
000079f4d2de47a9  vmovaps [rsp+0xA0], xmm10
000079f4d2de47b2  vmovaps [rsp+0xB0], xmm11
000079f4d2de47bb  vmovaps [rsp+0xC0], xmm12
000079f4d2de47c4  vmovaps [rsp+0xD0], xmm13
000079f4d2de47cd  vmovaps [rsp+0xE0], xmm14
000079f4d2de47d6  sub rsp, 0x30
000079f4d2de47da  movaps [rsp], xmm15
000079f4d2de47df  movaps [rsp+0x10], xmm11
000079f4d2de47e5  movaps [rsp+0x20], xmm12
000079f4d2de47eb  lea rdi, [rsp]
000079f4d2de47ef  mov esi, 0x00
000079f4d2de47f4  mov rax, 0x5D9EC01E8530
000079f4d2de47fe  call rax
000079f4d2de4800  movaps xmm15, [rsp]
000079f4d2de4805  add rsp, 0x30
000079f4d2de4809  vmovaps xmm0, [rsp]
000079f4d2de480e  vmovaps xmm1, [rsp+0x10]
000079f4d2de4814  vmovaps xmm2, [rsp+0x20]
000079f4d2de481a  vmovaps xmm3, [rsp+0x30]
000079f4d2de4820  vmovaps xmm4, [rsp+0x40]
000079f4d2de4826  vmovaps xmm5, [rsp+0x50]
000079f4d2de482c  vmovaps xmm6, [rsp+0x60]
000079f4d2de4832  vmovaps xmm7, [rsp+0x70]
000079f4d2de4838  vmovaps xmm8, [rsp+0x80]
000079f4d2de4841  vmovaps xmm9, [rsp+0x90]
000079f4d2de484a  vmovaps xmm10, [rsp+0xA0]
000079f4d2de4853  vmovaps xmm11, [rsp+0xB0]
000079f4d2de485c  vmovaps xmm12, [rsp+0xC0]
000079f4d2de4865  vmovaps xmm13, [rsp+0xD0]
000079f4d2de486e  vmovaps xmm14, [rsp+0xE0]
000079f4d2de4877  add rsp, 0xF0
000079f4d2de487e  pop r11
000079f4d2de4880  pop r10
000079f4d2de4882  pop r9
000079f4d2de4884  pop r8
000079f4d2de4886  pop rsi
000079f4d2de4887  pop rdi
000079f4d2de4888  pop rdx
000079f4d2de4889  pop rcx
000079f4d2de488a  pop rax
000079f4d2de488b  add rsp, 0x08
000079f4d2de488f  jmp 0x000079F4D2DDF9DD
000079f4d2de4894  sub rsp, 0x08
000079f4d2de4898  push rax
000079f4d2de4899  push rcx
000079f4d2de489a  push rdx
000079f4d2de489b  push rdi
000079f4d2de489c  push rsi
000079f4d2de489d  push r8
000079f4d2de489f  push r9
000079f4d2de48a1  push r10
000079f4d2de48a3  push r11
000079f4d2de48a5  sub rsp, 0xF0
000079f4d2de48ac  vmovaps [rsp], xmm0
000079f4d2de48b1  vmovaps [rsp+0x10], xmm1
000079f4d2de48b7  vmovaps [rsp+0x20], xmm2
000079f4d2de48bd  vmovaps [rsp+0x30], xmm3
000079f4d2de48c3  vmovaps [rsp+0x40], xmm4
000079f4d2de48c9  vmovaps [rsp+0x50], xmm5
000079f4d2de48cf  vmovaps [rsp+0x60], xmm6
000079f4d2de48d5  vmovaps [rsp+0x70], xmm7
000079f4d2de48db  vmovaps [rsp+0x80], xmm8
000079f4d2de48e4  vmovaps [rsp+0x90], xmm9
000079f4d2de48ed  vmovaps [rsp+0xA0], xmm10
000079f4d2de48f6  vmovaps [rsp+0xB0], xmm11
000079f4d2de48ff  vmovaps [rsp+0xC0], xmm12
000079f4d2de4908  vmovaps [rsp+0xD0], xmm14
000079f4d2de4911  vmovaps [rsp+0xE0], xmm15
000079f4d2de491a  sub rsp, 0x30
000079f4d2de491e  movaps [rsp], xmm13
000079f4d2de4923  movaps [rsp+0x10], xmm10
000079f4d2de4929  movaps [rsp+0x20], xmm14
000079f4d2de492f  lea rdi, [rsp]
000079f4d2de4933  mov esi, 0x00
000079f4d2de4938  mov rax, 0x5D9EC01E8530
000079f4d2de4942  call rax
000079f4d2de4944  movaps xmm13, [rsp]
000079f4d2de4949  add rsp, 0x30
000079f4d2de494d  vmovaps xmm0, [rsp]
000079f4d2de4952  vmovaps xmm1, [rsp+0x10]
000079f4d2de4958  vmovaps xmm2, [rsp+0x20]
000079f4d2de495e  vmovaps xmm3, [rsp+0x30]
000079f4d2de4964  vmovaps xmm4, [rsp+0x40]
000079f4d2de496a  vmovaps xmm5, [rsp+0x50]
000079f4d2de4970  vmovaps xmm6, [rsp+0x60]
000079f4d2de4976  vmovaps xmm7, [rsp+0x70]
000079f4d2de497c  vmovaps xmm8, [rsp+0x80]
000079f4d2de4985  vmovaps xmm9, [rsp+0x90]
000079f4d2de498e  vmovaps xmm10, [rsp+0xA0]
000079f4d2de4997  vmovaps xmm11, [rsp+0xB0]
000079f4d2de49a0  vmovaps xmm12, [rsp+0xC0]
000079f4d2de49a9  vmovaps xmm14, [rsp+0xD0]
000079f4d2de49b2  vmovaps xmm15, [rsp+0xE0]
000079f4d2de49bb  add rsp, 0xF0
000079f4d2de49c2  pop r11
000079f4d2de49c4  pop r10
000079f4d2de49c6  pop r9
000079f4d2de49c8  pop r8
000079f4d2de49ca  pop rsi
000079f4d2de49cb  pop rdi
000079f4d2de49cc  pop rdx
000079f4d2de49cd  pop rcx
000079f4d2de49ce  pop rax
000079f4d2de49cf  add rsp, 0x08
000079f4d2de49d3  jmp 0x000079F4D2DDFA00
000079f4d2de49d8  sub rsp, 0x08
000079f4d2de49dc  push rax
000079f4d2de49dd  push rcx
000079f4d2de49de  push rdx
000079f4d2de49df  push rdi
000079f4d2de49e0  push rsi
000079f4d2de49e1  push r8
000079f4d2de49e3  push r9
000079f4d2de49e5  push r10
000079f4d2de49e7  push r11
000079f4d2de49e9  sub rsp, 0xF0
000079f4d2de49f0  vmovaps [rsp], xmm0
000079f4d2de49f5  vmovaps [rsp+0x10], xmm1
000079f4d2de49fb  vmovaps [rsp+0x20], xmm2
000079f4d2de4a01  vmovaps [rsp+0x30], xmm3
000079f4d2de4a07  vmovaps [rsp+0x40], xmm4
000079f4d2de4a0d  vmovaps [rsp+0x50], xmm5
000079f4d2de4a13  vmovaps [rsp+0x60], xmm6
000079f4d2de4a19  vmovaps [rsp+0x70], xmm7
000079f4d2de4a1f  vmovaps [rsp+0x80], xmm8
000079f4d2de4a28  vmovaps [rsp+0x90], xmm9
000079f4d2de4a31  vmovaps [rsp+0xA0], xmm10
000079f4d2de4a3a  vmovaps [rsp+0xB0], xmm11
000079f4d2de4a43  vmovaps [rsp+0xC0], xmm12
000079f4d2de4a4c  vmovaps [rsp+0xD0], xmm13
000079f4d2de4a55  vmovaps [rsp+0xE0], xmm15
000079f4d2de4a5e  sub rsp, 0x30
000079f4d2de4a62  movaps [rsp], xmm14
000079f4d2de4a67  movaps [rsp+0x10], xmm1
000079f4d2de4a6c  movaps [rsp+0x20], xmm7
000079f4d2de4a71  lea rdi, [rsp]
000079f4d2de4a75  mov esi, 0x00
000079f4d2de4a7a  mov rax, 0x5D9EC01E8530
000079f4d2de4a84  call rax
000079f4d2de4a86  movaps xmm14, [rsp]
000079f4d2de4a8b  add rsp, 0x30
000079f4d2de4a8f  vmovaps xmm0, [rsp]
000079f4d2de4a94  vmovaps xmm1, [rsp+0x10]
000079f4d2de4a9a  vmovaps xmm2, [rsp+0x20]
000079f4d2de4aa0  vmovaps xmm3, [rsp+0x30]
000079f4d2de4aa6  vmovaps xmm4, [rsp+0x40]
000079f4d2de4aac  vmovaps xmm5, [rsp+0x50]
000079f4d2de4ab2  vmovaps xmm6, [rsp+0x60]
000079f4d2de4ab8  vmovaps xmm7, [rsp+0x70]
000079f4d2de4abe  vmovaps xmm8, [rsp+0x80]
000079f4d2de4ac7  vmovaps xmm9, [rsp+0x90]
000079f4d2de4ad0  vmovaps xmm10, [rsp+0xA0]
000079f4d2de4ad9  vmovaps xmm11, [rsp+0xB0]
000079f4d2de4ae2  vmovaps xmm12, [rsp+0xC0]
000079f4d2de4aeb  vmovaps xmm13, [rsp+0xD0]
000079f4d2de4af4  vmovaps xmm15, [rsp+0xE0]
000079f4d2de4afd  add rsp, 0xF0
000079f4d2de4b04  pop r11
000079f4d2de4b06  pop r10
000079f4d2de4b08  pop r9
000079f4d2de4b0a  pop r8
000079f4d2de4b0c  pop rsi
000079f4d2de4b0d  pop rdi
000079f4d2de4b0e  pop rdx
000079f4d2de4b0f  pop rcx
000079f4d2de4b10  pop rax
000079f4d2de4b11  add rsp, 0x08
000079f4d2de4b15  jmp 0x000079F4D2DDFA23
000079f4d2de4b1a  sub rsp, 0x08
000079f4d2de4b1e  push rax
000079f4d2de4b1f  push rcx
000079f4d2de4b20  push rdx
000079f4d2de4b21  push rdi
000079f4d2de4b22  push rsi
000079f4d2de4b23  push r8
000079f4d2de4b25  push r9
000079f4d2de4b27  push r10
000079f4d2de4b29  push r11
000079f4d2de4b2b  sub rsp, 0xF0
000079f4d2de4b32  vmovaps [rsp], xmm0
000079f4d2de4b37  vmovaps [rsp+0x10], xmm2
000079f4d2de4b3d  vmovaps [rsp+0x20], xmm3
000079f4d2de4b43  vmovaps [rsp+0x30], xmm4
000079f4d2de4b49  vmovaps [rsp+0x40], xmm5
000079f4d2de4b4f  vmovaps [rsp+0x50], xmm6
000079f4d2de4b55  vmovaps [rsp+0x60], xmm7
000079f4d2de4b5b  vmovaps [rsp+0x70], xmm8
000079f4d2de4b61  vmovaps [rsp+0x80], xmm9
000079f4d2de4b6a  vmovaps [rsp+0x90], xmm10
000079f4d2de4b73  vmovaps [rsp+0xA0], xmm11
000079f4d2de4b7c  vmovaps [rsp+0xB0], xmm12
000079f4d2de4b85  vmovaps [rsp+0xC0], xmm13
000079f4d2de4b8e  vmovaps [rsp+0xD0], xmm14
000079f4d2de4b97  vmovaps [rsp+0xE0], xmm15
000079f4d2de4ba0  sub rsp, 0x30
000079f4d2de4ba4  movaps [rsp], xmm1
000079f4d2de4ba8  movaps [rsp+0x10], xmm8
000079f4d2de4bae  movaps [rsp+0x20], xmm9
000079f4d2de4bb4  lea rdi, [rsp]
000079f4d2de4bb8  mov esi, 0x00
000079f4d2de4bbd  mov rax, 0x5D9EC01E8530
000079f4d2de4bc7  call rax
000079f4d2de4bc9  movaps xmm1, [rsp]
000079f4d2de4bcd  add rsp, 0x30
000079f4d2de4bd1  vmovaps xmm0, [rsp]
000079f4d2de4bd6  vmovaps xmm2, [rsp+0x10]
000079f4d2de4bdc  vmovaps xmm3, [rsp+0x20]
000079f4d2de4be2  vmovaps xmm4, [rsp+0x30]
000079f4d2de4be8  vmovaps xmm5, [rsp+0x40]
000079f4d2de4bee  vmovaps xmm6, [rsp+0x50]
000079f4d2de4bf4  vmovaps xmm7, [rsp+0x60]
000079f4d2de4bfa  vmovaps xmm8, [rsp+0x70]
000079f4d2de4c00  vmovaps xmm9, [rsp+0x80]
000079f4d2de4c09  vmovaps xmm10, [rsp+0x90]
000079f4d2de4c12  vmovaps xmm11, [rsp+0xA0]
000079f4d2de4c1b  vmovaps xmm12, [rsp+0xB0]
000079f4d2de4c24  vmovaps xmm13, [rsp+0xC0]
000079f4d2de4c2d  vmovaps xmm14, [rsp+0xD0]
000079f4d2de4c36  vmovaps xmm15, [rsp+0xE0]
000079f4d2de4c3f  add rsp, 0xF0
000079f4d2de4c46  pop r11
000079f4d2de4c48  pop r10
000079f4d2de4c4a  pop r9
000079f4d2de4c4c  pop r8
000079f4d2de4c4e  pop rsi
000079f4d2de4c4f  pop rdi
000079f4d2de4c50  pop rdx
000079f4d2de4c51  pop rcx
000079f4d2de4c52  pop rax
000079f4d2de4c53  add rsp, 0x08
000079f4d2de4c57  jmp 0x000079F4D2DDFA45
000079f4d2de4c5c  call 0x000079F4D2CE5940
000079f4d2de4c61  jmp 0x000079F4D2DDFA53
000079f4d2de4c66  call 0x000079F4D2C0C380
000079f4d2de4c6b  jmp 0x000079F4D2DDFA5D
000079f4d2de4c70  call 0x000079F4D2C0D600
000079f4d2de4c75  jmp 0x000079F4D2DDFA67
000079f4d2de4c7a  call 0x000079F4D2BFF540
000079f4d2de4c7f  jmp 0x000079F4D2DDFA71
000079f4d2de4c84  int3
000079f4d2de4c85  nop [rax+rax*1], ax
000079f4d2de4c8e  nop
000079f4d2de4c90  mov qword ptr [r15+0x40], 0x430000
000079f4d2de4c98  mov eax, 0x430CC0
000079f4d2de4c9d  mov r14, [r13+rax*1]
000079f4d2de4ca2  movq xmm1, r14
000079f4d2de4ca7  mov rax, [r15+0x50]
000079f4d2de4cab  movups xmm15, [r13+rax*1]
000079f4d2de4cb1  movaps [r15+0x120], xmm15
000079f4d2de4cb9  mov qword ptr [r15+0x48], 0x10
000079f4d2de4cc1  xor eax, eax
000079f4d2de4cc3  mov r14d, 0x10
000079f4d2de4cc9  mov r12d, 0x200
000079f4d2de4ccf  cmp r14, r12
000079f4d2de4cd2  cmc
000079f4d2de4cd3  lahf
000079f4d2de4cd4  seto al
000079f4d2de4cd7  mov [r15+0x108], eax
000079f4d2de4cde  pextrq rax, xmm15, 0x01
000079f4d2de4ce5  movq xmm14, rax
000079f4d2de4cea  movaps [r15+0x130], xmm14
000079f4d2de4cf2  movq rax, xmm1
000079f4d2de4cf7  movq r14, xmm15
000079f4d2de4cfc  vmovq xmm1, rax
000079f4d2de4d01  vmovq xmm15, r14
000079f4d2de4d06  movaps xmm13, xmm1
000079f4d2de4d0a  addsd xmm13, xmm15
000079f4d2de4d0f  ucomisd xmm13, xmm13
000079f4d2de4d14  jp 0x000079F4D2DE4DD3
000079f4d2de4d1a  movq xmm13, xmm13
000079f4d2de4d1f  movq rax, xmm13
000079f4d2de4d24  movq r14, xmm14
000079f4d2de4d29  vmovq xmm1, rax
000079f4d2de4d2e  vmovq xmm15, r14
000079f4d2de4d33  movaps xmm14, xmm1
000079f4d2de4d37  addsd xmm14, xmm15
000079f4d2de4d3c  ucomisd xmm14, xmm14
000079f4d2de4d41  jp 0x000079F4D2DE4E1B
000079f4d2de4d47  movq xmm14, xmm14
000079f4d2de4d4c  movaps [r15+0x110], xmm14
000079f4d2de4d54  mov eax, [r15+0x108]
000079f4d2de4d5b  sahf
000079f4d2de4d5c  jnz 0x000079F4D2DE4D8E
000079f4d2de4d5e  cmp dword ptr [r15+0x318], 0x00
000079f4d2de4d66  jz 0x000079F4D2DE5030
000079f4d2de4d6c  nop [rax+rax*1], ax
000079f4d2de4d75  nop [rax+rax*1], eax
000079f4d2de4d7d  mov eax, 0x410704
000079f4d2de4d82  mov [r15+0x100], rax
000079f4d2de4d89  jmp 0x000079F4D2BFE110
000079f4d2de4d8e  cmp dword ptr [r15+0x318], 0x00
000079f4d2de4d96  jz 0x000079F4D2DE4E70
000079f4d2de4d9c  nop [rax+rax*1], ax
000079f4d2de4da5  nop [rax+rax*1], eax
000079f4d2de4dad  mov eax, 0x4106E8
000079f4d2de4db2  mov [r15+0x100], rax
000079f4d2de4db9  jmp 0x000079F4D2BFE110
000079f4d2de4dbe  int3
000079f4d2de4dbf  call 0x000079F4D2C0DC20
000079f4d2de4dc4  jmp 0x000079F4D2DE4CA2
000079f4d2de4dc9  call 0x000079F4D2C0E760
000079f4d2de4dce  jmp 0x000079F4D2DE4CB1
000079f4d2de4dd3  ucomisd xmm1, xmm15
000079f4d2de4dd8  jp 0x000079F4D2DE4DE7
000079f4d2de4dda  movaps xmm13, [0x000079F4D29FE060]
000079f4d2de4de2  jmp 0x000079F4D2DE4D1A
000079f4d2de4de7  vxorps xmm0, xmm1, xmm15
000079f4d2de4dec  pextrw eax, xmm0, 0x03
000079f4d2de4df1  and eax, 0x7FF8
000079f4d2de4df6  cmp eax, 0x08
000079f4d2de4df9  jnz 0x000079F4D2DE4D1A
000079f4d2de4dff  movq rax, xmm15
000079f4d2de4e04  shl rax, 0x0D
000079f4d2de4e08  jbe 0x000079F4D2DE4D1A
000079f4d2de4e0e  vorps xmm13, xmm15, [0x000079F4D29FE070]
000079f4d2de4e16  jmp 0x000079F4D2DE4D1A
000079f4d2de4e1b  ucomisd xmm1, xmm15
000079f4d2de4e20  jp 0x000079F4D2DE4E2F
000079f4d2de4e22  movaps xmm14, [0x000079F4D29FE060]
000079f4d2de4e2a  jmp 0x000079F4D2DE4D47
000079f4d2de4e2f  vxorps xmm0, xmm1, xmm15
000079f4d2de4e34  pextrw eax, xmm0, 0x03
000079f4d2de4e39  and eax, 0x7FF8
000079f4d2de4e3e  cmp eax, 0x08
000079f4d2de4e41  jnz 0x000079F4D2DE4D47
000079f4d2de4e47  movq rax, xmm15
000079f4d2de4e4c  shl rax, 0x0D
000079f4d2de4e50  jbe 0x000079F4D2DE4D47
000079f4d2de4e56  vorps xmm14, xmm15, [0x000079F4D29FE070]
000079f4d2de4e5e  jmp 0x000079F4D2DE4D47
000079f4d2de4e63  int3
000079f4d2de4e64  nop [rax+rax*1], ax
000079f4d2de4e6d  nop [rax], eax
000079f4d2de4e70  mov rax, [r15+0x48]
000079f4d2de4e74  mov r14, [r15+0x50]
000079f4d2de4e78  lea r12, [r14+rax*1]
000079f4d2de4e7c  movups xmm1, [r13+r12*1]
000079f4d2de4e82  movaps [r15+0x120], xmm1
000079f4d2de4e8a  lea r14, [rax+0x10]
000079f4d2de4e8e  mov [r15+0x48], r14
000079f4d2de4e92  xor eax, eax
000079f4d2de4e94  mov r12d, 0x200
000079f4d2de4e9a  cmp r14, r12
000079f4d2de4e9d  cmc
000079f4d2de4e9e  lahf
000079f4d2de4e9f  seto al
000079f4d2de4ea2  mov [r15+0x108], eax
000079f4d2de4ea9  pextrq rax, xmm1, 0x01
000079f4d2de4eb0  movq xmm15, rax
000079f4d2de4eb5  movaps [r15+0x130], xmm15
000079f4d2de4ebd  movaps xmm14, [r15+0x110]
000079f4d2de4ec5  movq rax, xmm14
000079f4d2de4eca  movq r14, xmm1
000079f4d2de4ecf  vmovq xmm1, rax
000079f4d2de4ed4  vmovq xmm14, r14
000079f4d2de4ed9  movaps xmm13, xmm1
000079f4d2de4edd  addsd xmm13, xmm14
000079f4d2de4ee2  ucomisd xmm13, xmm13
000079f4d2de4ee7  jp 0x000079F4D2DE4F9C
000079f4d2de4eed  movq xmm13, xmm13
000079f4d2de4ef2  movq rax, xmm13
000079f4d2de4ef7  movq r14, xmm15
000079f4d2de4efc  vmovq xmm1, rax
000079f4d2de4f01  vmovq xmm15, r14
000079f4d2de4f06  movaps xmm14, xmm1
000079f4d2de4f0a  addsd xmm14, xmm15
000079f4d2de4f0f  ucomisd xmm14, xmm14
000079f4d2de4f14  jp 0x000079F4D2DE4FE4
000079f4d2de4f1a  movq xmm14, xmm14
000079f4d2de4f1f  movaps [r15+0x110], xmm14
000079f4d2de4f27  mov eax, [r15+0x108]
000079f4d2de4f2e  sahf
000079f4d2de4f2f  jnz 0x000079F4D2DE4F61
000079f4d2de4f31  cmp dword ptr [r15+0x318], 0x00
000079f4d2de4f39  jz 0x000079F4D2DE5030
000079f4d2de4f3f  nop [rax+rax*1], ax
000079f4d2de4f48  nop [rax+rax*1], eax
000079f4d2de4f50  mov eax, 0x410704
000079f4d2de4f55  mov [r15+0x100], rax
000079f4d2de4f5c  jmp 0x000079F4D2BFE110
000079f4d2de4f61  cmp dword ptr [r15+0x318], 0x00
000079f4d2de4f69  jz 0x000079F4D2DE4E70
000079f4d2de4f6f  nop [rax+rax*1], ax
000079f4d2de4f78  nop [rax+rax*1], eax
000079f4d2de4f80  mov eax, 0x4106E8
000079f4d2de4f85  mov [r15+0x100], rax
000079f4d2de4f8c  jmp 0x000079F4D2BFE110
000079f4d2de4f91  int3
000079f4d2de4f92  call 0x000079F4D2CB52F0
000079f4d2de4f97  jmp 0x000079F4D2DE4E82
000079f4d2de4f9c  ucomisd xmm1, xmm14
000079f4d2de4fa1  jp 0x000079F4D2DE4FB0
000079f4d2de4fa3  movaps xmm13, [0x000079F4D29FE060]
000079f4d2de4fab  jmp 0x000079F4D2DE4EED
000079f4d2de4fb0  vxorps xmm0, xmm1, xmm14
000079f4d2de4fb5  pextrw eax, xmm0, 0x03
000079f4d2de4fba  and eax, 0x7FF8
000079f4d2de4fbf  cmp eax, 0x08
000079f4d2de4fc2  jnz 0x000079F4D2DE4EED
000079f4d2de4fc8  movq rax, xmm14
000079f4d2de4fcd  shl rax, 0x0D
000079f4d2de4fd1  jbe 0x000079F4D2DE4EED
000079f4d2de4fd7  vorps xmm13, xmm14, [0x000079F4D29FE070]
000079f4d2de4fdf  jmp 0x000079F4D2DE4EED
000079f4d2de4fe4  ucomisd xmm1, xmm15
000079f4d2de4fe9  jp 0x000079F4D2DE4FF8
000079f4d2de4feb  movaps xmm14, [0x000079F4D29FE060]
000079f4d2de4ff3  jmp 0x000079F4D2DE4F1A
000079f4d2de4ff8  vxorps xmm0, xmm1, xmm15
000079f4d2de4ffd  pextrw eax, xmm0, 0x03
000079f4d2de5002  and eax, 0x7FF8
000079f4d2de5007  cmp eax, 0x08
000079f4d2de500a  jnz 0x000079F4D2DE4F1A
000079f4d2de5010  movq rax, xmm15
000079f4d2de5015  shl rax, 0x0D
000079f4d2de5019  jbe 0x000079F4D2DE4F1A
000079f4d2de501f  vorps xmm14, xmm15, [0x000079F4D29FE070]
000079f4d2de5027  jmp 0x000079F4D2DE4F1A
000079f4d2de502c  int3
000079f4d2de502d  nop [rax], eax
000079f4d2de5030  mov rax, [r15+0xF8]
000079f4d2de5037  lea r14, [rax+0x1D0]
000079f4d2de503e  mov r12, [r13+r14*1]
000079f4d2de5043  lea r14, [rax+0x1D8]
000079f4d2de504a  mov r11, [r13+r14*1]
000079f4d2de504f  mov [r15+0xA0], r12
000079f4d2de5056  mov [r15+0x98], r11
000079f4d2de505d  mov r14, [r15+0x40]
000079f4d2de5061  lea r12, [r14+0xCC0]
000079f4d2de5068  movaps xmm1, [r15+0x110]
000079f4d2de5070  movq r14, xmm1
000079f4d2de5075  mov [r13+r12*1], r14
000079f4d2de507a  lea r14, [rax+0x1C0]
000079f4d2de5081  mov r12, [r13+r14*1]
000079f4d2de5086  lea r14, [rax+0x1C8]
000079f4d2de508d  mov r11, [r13+r14*1]
000079f4d2de5092  mov [r15+0xE8], r12
000079f4d2de5099  mov [r15+0xF0], r11
000079f4d2de50a0  lea r14, [rax+0x1B0]
000079f4d2de50a7  mov r12, [r13+r14*1]
000079f4d2de50ac  lea r14, [rax+0x1B8]
000079f4d2de50b3  mov r10, [r13+r14*1]
000079f4d2de50b8  movq xmm1, r12
000079f4d2de50bd  movq xmm15, r10
000079f4d2de50c2  movq xmm1, xmm1
000079f4d2de50c6  movq xmm1, xmm1
000079f4d2de50ca  movaps [r15+0x1A0], xmm1
000079f4d2de50d2  movq xmm15, xmm15
000079f4d2de50d7  movq xmm15, xmm15
000079f4d2de50dc  movaps [r15+0x190], xmm15
000079f4d2de50e4  lea r14, [rax+0x1A0]
000079f4d2de50eb  mov r12, [r13+r14*1]
000079f4d2de50f0  lea r14, [rax+0x1A8]
000079f4d2de50f7  mov r10, [r13+r14*1]
000079f4d2de50fc  movq xmm1, r12
000079f4d2de5101  movq xmm15, r10
000079f4d2de5106  movq xmm1, xmm1
000079f4d2de510a  movq xmm1, xmm1
000079f4d2de510e  movaps [r15+0x1C0], xmm1
000079f4d2de5116  movq xmm15, xmm15
000079f4d2de511b  movq xmm15, xmm15
000079f4d2de5120  movaps [r15+0x1B0], xmm15
000079f4d2de5128  lea r14, [rax+0x190]
000079f4d2de512f  mov r12, [r13+r14*1]
000079f4d2de5134  lea r14, [rax+0x198]
000079f4d2de513b  mov r10, [r13+r14*1]
000079f4d2de5140  movq xmm1, r12
000079f4d2de5145  movq xmm15, r10
000079f4d2de514a  movq xmm1, xmm1
000079f4d2de514e  movq xmm1, xmm1
000079f4d2de5152  movaps [r15+0x1E0], xmm1
000079f4d2de515a  movq xmm15, xmm15
000079f4d2de515f  movq xmm15, xmm15
000079f4d2de5164  movaps [r15+0x1D0], xmm15
000079f4d2de516c  lea r14, [rax+0x180]
000079f4d2de5173  mov r12, [r13+r14*1]
000079f4d2de5178  lea r14, [rax+0x188]
000079f4d2de517f  mov r10, [r13+r14*1]
000079f4d2de5184  movq xmm1, r12
000079f4d2de5189  movq xmm15, r10
000079f4d2de518e  movq xmm1, xmm1
000079f4d2de5192  movq xmm1, xmm1
000079f4d2de5196  movaps [r15+0x200], xmm1
000079f4d2de519e  movq xmm15, xmm15
000079f4d2de51a3  movq xmm15, xmm15
000079f4d2de51a8  movaps [r15+0x1F0], xmm15
000079f4d2de51b0  lea r14, [rax+0x1E0]
000079f4d2de51b7  mov [r15+0xF8], r14
000079f4d2de51be  mov [r15+0x100], r11
000079f4d2de51c5  jmp 0x000079F4D2DCE5C0
000079f4d2de51ca  int3
000079f4d2de51cb  call 0x000079F4D2CE27E0
000079f4d2de51d0  jmp 0x000079F4D2DE5043
000079f4d2de51d5  call 0x000079F4D2CE1570
000079f4d2de51da  jmp 0x000079F4D2DE504F
000079f4d2de51df  call 0x000079F4D2CC3FE0
000079f4d2de51e4  jmp 0x000079F4D2DE507A
000079f4d2de51e9  call 0x000079F4D2CE27E0
000079f4d2de51ee  jmp 0x000079F4D2DE5086
000079f4d2de51f3  call 0x000079F4D2CE1570
000079f4d2de51f8  jmp 0x000079F4D2DE5092
000079f4d2de51fd  call 0x000079F4D2CE27E0
000079f4d2de5202  jmp 0x000079F4D2DE50AC
000079f4d2de5207  call 0x000079F4D2CE0300
000079f4d2de520c  jmp 0x000079F4D2DE50B8
000079f4d2de5211  call 0x000079F4D2CE27E0
000079f4d2de5216  jmp 0x000079F4D2DE50F0
000079f4d2de521b  call 0x000079F4D2CE0300
000079f4d2de5220  jmp 0x000079F4D2DE50FC
000079f4d2de5225  call 0x000079F4D2CE27E0
000079f4d2de522a  jmp 0x000079F4D2DE5134
000079f4d2de522f  call 0x000079F4D2CE0300
000079f4d2de5234  jmp 0x000079F4D2DE5140
000079f4d2de5239  call 0x000079F4D2CE27E0
000079f4d2de523e  jmp 0x000079F4D2DE5178
000079f4d2de5243  call 0x000079F4D2CE0300
000079f4d2de5248  jmp 0x000079F4D2DE5184
000079f4d2de524d  int3
000079f4d2de524e  nop
000079f4d2de5250  mov qword ptr [r15+0x100], 0x04
000079f4d2de525b  mov esi, 0x00
000079f4d2de5260  mov edx, 0x09
000079f4d2de5265  mov rdi, 0x7FFFBABDFD00
000079f4d2de526f  mov rax, 0x5D9EC007B970
000079f4d2de5279  call rax
000079f4d2de527b  cmp dword ptr [r15+0x318], 0x00
000079f4d2de5283  jnz 0x000079F4D2BFE110
000079f4d2de5289  jmp 0x000079F4D2BFE0A0
000079f4d2de528e  int3
000079f4d2de528f  int3
