00007981ddfce69b  nop [rax+rax*1], eax
00007981ddfce6a0  mov rax, [r15+0xF8]
00007981ddfce6a7  lea r14, [rax-0x1E0]
00007981ddfce6ae  mov [r15+0xF8], r14
00007981ddfce6b5  lea rax, [r14+0x1D0]
00007981ddfce6bc  mov r12, [r15+0xA0]
00007981ddfce6c3  mov r11, [r15+0x98]
00007981ddfce6ca  mov [r13+rax*1], r12
00007981ddfce6cf  lea rax, [r14+0x1D8]
00007981ddfce6d6  mov [r13+rax*1], r11
00007981ddfce6db  mov eax, 0x420AA0
00007981ddfce6e0  movups xmm1, [r13+rax*1]
00007981ddfce6e6  mov eax, 0x420A30
00007981ddfce6eb  movups xmm15, [r13+rax*1]
00007981ddfce6f1  mov eax, 0x420AC0
00007981ddfce6f6  movups xmm14, [r13+rax*1]
00007981ddfce6fc  mov eax, 0x420A60
00007981ddfce701  movups xmm13, [r13+rax*1]
00007981ddfce707  mov qword ptr [r15+0x98], 0x430CD0
00007981ddfce712  mov eax, 0x420AD0
00007981ddfce717  movups xmm12, [r13+rax*1]
00007981ddfce71d  mov eax, 0x430CD0
00007981ddfce722  movups [r13+rax*1], xmm1
00007981ddfce728  mov eax, 0x430CE0
00007981ddfce72d  movups [r13+rax*1], xmm15
00007981ddfce733  mov eax, 0x430CF0
00007981ddfce738  movups [r13+rax*1], xmm14
00007981ddfce73e  mov eax, 0x430D00
00007981ddfce743  movups [r13+rax*1], xmm13
00007981ddfce749  mov eax, 0x420A20
00007981ddfce74e  movups xmm14, [r13+rax*1]
00007981ddfce754  mov eax, 0x420A10
00007981ddfce759  movups xmm13, [r13+rax*1]
00007981ddfce75f  mov eax, 0x430DD0
00007981ddfce764  movups [r13+rax*1], xmm1
00007981ddfce76a  mov eax, 0x430DE0
00007981ddfce76f  movups [r13+rax*1], xmm15
00007981ddfce775  mov eax, 0x430D10
00007981ddfce77a  movups [r13+rax*1], xmm12
00007981ddfce780  mov eax, 0x430D20
00007981ddfce785  movups [r13+rax*1], xmm14
00007981ddfce78b  mov eax, 0x420A00
00007981ddfce790  movups xmm1, [r13+rax*1]
00007981ddfce796  mov eax, 0x420A70
00007981ddfce79b  movups xmm15, [r13+rax*1]
00007981ddfce7a1  mov eax, 0x430D30
00007981ddfce7a6  movups [r13+rax*1], xmm13
00007981ddfce7ac  mov eax, 0x430D40
00007981ddfce7b1  movups [r13+rax*1], xmm1
00007981ddfce7b7  mov eax, 0x420A80
00007981ddfce7bc  movups xmm1, [r13+rax*1]
00007981ddfce7c2  mov eax, 0x420A50
00007981ddfce7c7  movups xmm14, [r13+rax*1]
00007981ddfce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007981ddfce7d5  mov eax, 0x430D50
00007981ddfce7da  movups [r13+rax*1], xmm15
00007981ddfce7e0  mov eax, 0x430D60
00007981ddfce7e5  movups [r13+rax*1], xmm1
00007981ddfce7eb  mov eax, 0x420AF0
00007981ddfce7f0  movups xmm1, [r13+rax*1]
00007981ddfce7f6  mov eax, 0x420B00
00007981ddfce7fb  movups xmm15, [r13+rax*1]
00007981ddfce801  movaps [r15+0x150], xmm15
00007981ddfce809  mov qword ptr [r15+0xA0], 0x3E8
00007981ddfce814  mov eax, 0x430D70
00007981ddfce819  movups [r13+rax*1], xmm14
00007981ddfce81f  mov eax, 0x430D80
00007981ddfce824  movups [r13+rax*1], xmm1
00007981ddfce82a  mov eax, 0x420AE0
00007981ddfce82f  movups xmm1, [r13+rax*1]
00007981ddfce835  mov eax, 0x420A90
00007981ddfce83a  movups xmm14, [r13+rax*1]
00007981ddfce840  movaps [r15+0x140], xmm14
00007981ddfce848  lea rax, [r14+0x180]
00007981ddfce84f  movq xmm13, qword ptr [r15+0x200]
00007981ddfce858  movq xmm12, qword ptr [r15+0x1F0]
00007981ddfce861  movq r12, xmm13
00007981ddfce866  movq r11, xmm12
00007981ddfce86b  mov [r13+rax*1], r12
00007981ddfce870  lea rax, [r14+0x188]
00007981ddfce877  mov [r13+rax*1], r11
00007981ddfce87c  mov eax, 0x430D90
00007981ddfce881  movups [r13+rax*1], xmm15
00007981ddfce887  mov eax, 0x430DA0
00007981ddfce88c  movups [r13+rax*1], xmm1
00007981ddfce892  mov eax, 0x420AB0
00007981ddfce897  movups xmm1, [r13+rax*1]
00007981ddfce89d  mov eax, 0x420B18
00007981ddfce8a2  mov r12, [r13+rax*1]
00007981ddfce8a7  movq xmm15, r12
00007981ddfce8ac  mov qword ptr [r15+0x40], 0x420B20
00007981ddfce8b4  mov eax, 0x430DB0
00007981ddfce8b9  movups [r13+rax*1], xmm14
00007981ddfce8bf  mov eax, 0x430DC0
00007981ddfce8c4  movups [r13+rax*1], xmm1
00007981ddfce8ca  mov eax, 0x420B80
00007981ddfce8cf  movups xmm1, [r13+rax*1]
00007981ddfce8d5  movq rax, xmm15
00007981ddfce8da  mov r12d, 0x430DF0
00007981ddfce8e0  mov [r13+r12*1], rax
00007981ddfce8e5  mov eax, 0x420B60
00007981ddfce8ea  movups xmm15, [r13+rax*1]
00007981ddfce8f0  mov eax, 0x420B70
00007981ddfce8f5  movups xmm14, [r13+rax*1]
00007981ddfce8fb  lea rax, [r14+0x160]
00007981ddfce902  movups [r13+rax*1], xmm1
00007981ddfce908  lea rax, [r14+0x190]
00007981ddfce90f  movq xmm1, qword ptr [r15+0x1E0]
00007981ddfce918  movq xmm13, qword ptr [r15+0x1D0]
00007981ddfce921  movq r12, xmm1
00007981ddfce926  movq r11, xmm13
00007981ddfce92b  mov [r13+rax*1], r12
00007981ddfce930  lea rax, [r14+0x198]
00007981ddfce937  mov [r13+rax*1], r11
00007981ddfce93c  lea rax, [r14+0x140]
00007981ddfce943  movups [r13+rax*1], xmm15
00007981ddfce949  lea rax, [r14+0x150]
00007981ddfce950  movups [r13+rax*1], xmm14
00007981ddfce956  mov eax, 0x420B20
00007981ddfce95b  movups xmm1, [r13+rax*1]
00007981ddfce961  mov eax, 0x420B30
00007981ddfce966  movups xmm15, [r13+rax*1]
00007981ddfce96c  movaps [r15+0x120], xmm15
00007981ddfce974  lea rax, [r14+0x1A0]
00007981ddfce97b  movq xmm14, qword ptr [r15+0x1C0]
00007981ddfce984  movq xmm13, qword ptr [r15+0x1B0]
00007981ddfce98d  movq r12, xmm14
00007981ddfce992  movq r11, xmm13
00007981ddfce997  mov [r13+rax*1], r12
00007981ddfce99c  lea rax, [r14+0x1A8]
00007981ddfce9a3  mov [r13+rax*1], r11
00007981ddfce9a8  lea rax, [r14+0x1B0]
00007981ddfce9af  movq xmm14, qword ptr [r15+0x1A0]
00007981ddfce9b8  movq xmm13, qword ptr [r15+0x190]
00007981ddfce9c1  movq r12, xmm14
00007981ddfce9c6  movq r11, xmm13
00007981ddfce9cb  mov [r13+rax*1], r12
00007981ddfce9d0  lea rax, [r14+0x1B8]
00007981ddfce9d7  mov [r13+rax*1], r11
00007981ddfce9dc  lea rax, [r14+0x100]
00007981ddfce9e3  movups [r13+rax*1], xmm1
00007981ddfce9e9  lea rax, [r14+0x110]
00007981ddfce9f0  movups [r13+rax*1], xmm15
00007981ddfce9f6  mov eax, 0x420B40
00007981ddfce9fb  movups xmm1, [r13+rax*1]
00007981ddfcea01  mov eax, 0x420B50
00007981ddfcea06  movups xmm15, [r13+rax*1]
00007981ddfcea0c  movaps [r15+0x110], xmm1
00007981ddfcea14  movaps [r15+0x130], xmm15
00007981ddfcea1c  lea rax, [r14+0x1C0]
00007981ddfcea23  mov r12, [r15+0xE8]
00007981ddfcea2a  mov r11, [r15+0xF0]
00007981ddfcea31  mov [r13+rax*1], r12
00007981ddfcea36  lea rax, [r14+0x1C8]
00007981ddfcea3d  mov [r13+rax*1], r11
00007981ddfcea42  mov eax, 0x430DF8
00007981ddfcea47  mov r12d, 0x421DF8D3
00007981ddfcea4d  mov [r13+rax*1], r12d
00007981ddfcea52  lea rax, [r14+0x120]
00007981ddfcea59  movups [r13+rax*1], xmm1
00007981ddfcea5f  lea rax, [r14+0x130]
00007981ddfcea66  movups [r13+rax*1], xmm15
00007981ddfcea6c  lea rax, [r14+0x100]
00007981ddfcea73  mov [r15], rax
00007981ddfcea76  mov qword ptr [r15+0x08], 0x430CD0
00007981ddfcea7e  mov qword ptr [r15+0x10], 0x12C
00007981ddfcea86  mov qword ptr [r15+0xF0], 0x410284
00007981ddfcea91  mov r14d, [r15+0x320]
00007981ddfcea98  mov eax, 0x410284
00007981ddfcea9d  mov rcx, 0x7981DDFD07C0
00007981ddfceaa7  mov [r15+r14*8+0x328], rax
00007981ddfceaaf  mov [r15+r14*8+0x368], rcx
00007981ddfceab7  add r14d, 0x01
00007981ddfceabb  and r14d, 0x07
00007981ddfceabf  mov [r15+0x320], r14d
00007981ddfceac6  cmp dword ptr [r15+0x318], 0x00
00007981ddfceace  jz 0x00007981DDFCED70
00007981ddfcead4  nop [rax+rax*1], ax
00007981ddfceadd  nop [rax+rax*1], eax
00007981ddfceae5  mov eax, 0x410728
00007981ddfceaea  mov [r15+0x100], rax
00007981ddfceaf1  jmp 0x00007981DDDFE110
00007981ddfceaf6  int3
00007981ddfceaf7  call 0x00007981DDE0BC20
00007981ddfceafc  jmp 0x00007981DDFCE6CF
00007981ddfceb01  call 0x00007981DDE0A9A0
00007981ddfceb06  jmp 0x00007981DDFCE6DB
00007981ddfceb0b  call 0x00007981DDDFF430
00007981ddfceb10  jmp 0x00007981DDFCE6E6
00007981ddfceb15  call 0x00007981DDE0E760
00007981ddfceb1a  jmp 0x00007981DDFCE6F1
00007981ddfceb1f  call 0x00007981DDE0D4E0
00007981ddfceb24  jmp 0x00007981DDFCE6FC
00007981ddfceb29  call 0x00007981DDE0C260
00007981ddfceb2e  jmp 0x00007981DDFCE707
00007981ddfceb33  call 0x00007981DDE0AFE0
00007981ddfceb38  jmp 0x00007981DDFCE71D
00007981ddfceb3d  call 0x00007981DDDFF540
00007981ddfceb42  jmp 0x00007981DDFCE728
00007981ddfceb47  call 0x00007981DDE0E880
00007981ddfceb4c  jmp 0x00007981DDFCE733
00007981ddfceb51  call 0x00007981DDE0D600
00007981ddfceb56  jmp 0x00007981DDFCE73E
00007981ddfceb5b  call 0x00007981DDE0C380
00007981ddfceb60  jmp 0x00007981DDFCE749
00007981ddfceb65  call 0x00007981DDE0D4E0
00007981ddfceb6a  jmp 0x00007981DDFCE754
00007981ddfceb6f  call 0x00007981DDE0C260
00007981ddfceb74  jmp 0x00007981DDFCE75F
00007981ddfceb79  call 0x00007981DDDFF540
00007981ddfceb7e  jmp 0x00007981DDFCE76A
00007981ddfceb83  call 0x00007981DDE0E880
00007981ddfceb88  jmp 0x00007981DDFCE775
00007981ddfceb8d  call 0x00007981DDE0B100
00007981ddfceb92  jmp 0x00007981DDFCE780
00007981ddfceb97  call 0x00007981DDE0D600
00007981ddfceb9c  jmp 0x00007981DDFCE78B
00007981ddfceba1  call 0x00007981DDDFF430
00007981ddfceba6  jmp 0x00007981DDFCE796
00007981ddfcebab  call 0x00007981DDE0E760
00007981ddfcebb0  jmp 0x00007981DDFCE7A1
00007981ddfcebb5  call 0x00007981DDE0C380
00007981ddfcebba  jmp 0x00007981DDFCE7AC
00007981ddfcebbf  call 0x00007981DDDFF540
00007981ddfcebc4  jmp 0x00007981DDFCE7B7
00007981ddfcebc9  call 0x00007981DDDFF430
00007981ddfcebce  jmp 0x00007981DDFCE7C2
00007981ddfcebd3  call 0x00007981DDE0D4E0
00007981ddfcebd8  jmp 0x00007981DDFCE7CD
00007981ddfcebdd  call 0x00007981DDE0E880
00007981ddfcebe2  jmp 0x00007981DDFCE7E0
00007981ddfcebe7  call 0x00007981DDDFF540
00007981ddfcebec  jmp 0x00007981DDFCE7EB
00007981ddfcebf1  call 0x00007981DDDFF430
00007981ddfcebf6  jmp 0x00007981DDFCE7F6
00007981ddfcebfb  call 0x00007981DDE0E760
00007981ddfcec00  jmp 0x00007981DDFCE801
00007981ddfcec05  call 0x00007981DDE0D600
00007981ddfcec0a  jmp 0x00007981DDFCE81F
00007981ddfcec0f  call 0x00007981DDDFF540
00007981ddfcec14  jmp 0x00007981DDFCE82A
00007981ddfcec19  call 0x00007981DDDFF430
00007981ddfcec1e  jmp 0x00007981DDFCE835
00007981ddfcec23  call 0x00007981DDE0D4E0
00007981ddfcec28  jmp 0x00007981DDFCE840
00007981ddfcec2d  call 0x00007981DDE0BC20
00007981ddfcec32  jmp 0x00007981DDFCE870
00007981ddfcec37  call 0x00007981DDE0A9A0
00007981ddfcec3c  jmp 0x00007981DDFCE87C
00007981ddfcec41  call 0x00007981DDE0E880
00007981ddfcec46  jmp 0x00007981DDFCE887
00007981ddfcec4b  call 0x00007981DDDFF540
00007981ddfcec50  jmp 0x00007981DDFCE892
00007981ddfcec55  call 0x00007981DDDFF430
00007981ddfcec5a  jmp 0x00007981DDFCE89D
00007981ddfcec5f  call 0x00007981DDE0B720
00007981ddfcec64  jmp 0x00007981DDFCE8A7
00007981ddfcec69  call 0x00007981DDE0D600
00007981ddfcec6e  jmp 0x00007981DDFCE8BF
00007981ddfcec73  call 0x00007981DDDFF540
00007981ddfcec78  jmp 0x00007981DDFCE8CA
00007981ddfcec7d  call 0x00007981DDDFF430
00007981ddfcec82  jmp 0x00007981DDFCE8D5
00007981ddfcec87  call 0x00007981DDEB4CB0
00007981ddfcec8c  jmp 0x00007981DDFCE8E5
00007981ddfcec91  call 0x00007981DDE0E760
00007981ddfcec96  jmp 0x00007981DDFCE8F0
00007981ddfcec9b  call 0x00007981DDE0D4E0
00007981ddfceca0  jmp 0x00007981DDFCE8FB
00007981ddfceca5  call 0x00007981DDDFF540
00007981ddfcecaa  jmp 0x00007981DDFCE908
00007981ddfcecaf  call 0x00007981DDE0BC20
00007981ddfcecb4  jmp 0x00007981DDFCE930
00007981ddfcecb9  call 0x00007981DDE0A9A0
00007981ddfcecbe  jmp 0x00007981DDFCE93C
00007981ddfcecc3  call 0x00007981DDE0E880
00007981ddfcecc8  jmp 0x00007981DDFCE949
00007981ddfceccd  call 0x00007981DDE0D600
00007981ddfcecd2  jmp 0x00007981DDFCE956
00007981ddfcecd7  call 0x00007981DDDFF430
00007981ddfcecdc  jmp 0x00007981DDFCE961
00007981ddfcece1  call 0x00007981DDE0E760
00007981ddfcece6  jmp 0x00007981DDFCE96C
00007981ddfceceb  call 0x00007981DDE0BC20
00007981ddfcecf0  jmp 0x00007981DDFCE99C
00007981ddfcecf5  call 0x00007981DDE0A9A0
00007981ddfcecfa  jmp 0x00007981DDFCE9A8
00007981ddfcecff  call 0x00007981DDE0BC20
00007981ddfced04  jmp 0x00007981DDFCE9D0
00007981ddfced09  call 0x00007981DDE0A9A0
00007981ddfced0e  jmp 0x00007981DDFCE9DC
00007981ddfced13  call 0x00007981DDDFF540
00007981ddfced18  jmp 0x00007981DDFCE9E9
00007981ddfced1d  call 0x00007981DDE0E880
00007981ddfced22  jmp 0x00007981DDFCE9F6
00007981ddfced27  call 0x00007981DDDFF430
00007981ddfced2c  jmp 0x00007981DDFCEA01
00007981ddfced31  call 0x00007981DDE0E760
00007981ddfced36  jmp 0x00007981DDFCEA0C
00007981ddfced3b  call 0x00007981DDE0BC20
00007981ddfced40  jmp 0x00007981DDFCEA36
00007981ddfced45  call 0x00007981DDE0A9A0
00007981ddfced4a  jmp 0x00007981DDFCEA42
00007981ddfced4f  call 0x00007981DDE0BAE0
00007981ddfced54  jmp 0x00007981DDFCEA52
00007981ddfced59  call 0x00007981DDDFF540
00007981ddfced5e  jmp 0x00007981DDFCEA5F
00007981ddfced63  call 0x00007981DDE0E880
00007981ddfced68  jmp 0x00007981DDFCEA6C
00007981ddfced6d  int3
00007981ddfced6e  nop
00007981ddfced70  mov rax, [r15]
00007981ddfced73  lea r14, [rax+0x20]
00007981ddfced77  mov r12, [r13+r14*1]
00007981ddfced7c  mov r14, [r15+0x10]
00007981ddfced80  lea r11, [r12+r14*1]
00007981ddfced84  mov [r15+0x40], r11
00007981ddfced88  lea r12, [rax+0x20]
00007981ddfced8c  mov [r13+r12*1], r11
00007981ddfced91  test r14, r14
00007981ddfced94  setz r14b
00007981ddfced98  movzx r14, r14b
00007981ddfced9c  mov [rsp+0x414], r14b
00007981ddfceda4  cmp byte ptr [rsp+0x414], 0x00
00007981ddfcedac  jz 0x00007981DDFCEDDE
00007981ddfcedae  cmp dword ptr [r15+0x318], 0x00
00007981ddfcedb6  mov eax, 0x4109A0
00007981ddfcedbb  mov [r15+0x100], rax
00007981ddfcedc2  jz 0x00007981DDDFE0A0
00007981ddfcedc8  nop [rax+rax*1], eax
00007981ddfcedcd  mov eax, 0x4109A0
00007981ddfcedd2  mov [r15+0x100], rax
00007981ddfcedd9  jmp 0x00007981DDDFE110
00007981ddfcedde  cmp dword ptr [r15+0x318], 0x00
00007981ddfcede6  jz 0x00007981DDFCEE30
00007981ddfcedec  nop [rax+rax*1], ax
00007981ddfcedf5  nop [rax+rax*1], eax
00007981ddfcedfd  mov eax, 0x410738
00007981ddfcee02  mov [r15+0x100], rax
00007981ddfcee09  jmp 0x00007981DDDFE110
00007981ddfcee0e  int3
00007981ddfcee0f  call 0x00007981DDEE27E0
00007981ddfcee14  jmp 0x00007981DDFCED7C
00007981ddfcee19  call 0x00007981DDEC0860
00007981ddfcee1e  jmp 0x00007981DDFCED91
00007981ddfcee23  int3
00007981ddfcee24  nop [rax+rax*1], ax
00007981ddfcee2d  nop [rax], eax
00007981ddfcee30  mov rax, [r15+0xF8]
00007981ddfcee37  lea r14, [rax-0x150]
00007981ddfcee3e  mov [r15+0xF8], r14
00007981ddfcee45  mov rax, [r15]
00007981ddfcee48  lea r12, [rax+0x68]
00007981ddfcee4c  mov r11, [r13+r12*1]
00007981ddfcee51  mov [r15+0x88], r11
00007981ddfcee58  lea r12, [rax+0x28]
00007981ddfcee5c  mov [r15+0x40], r12
00007981ddfcee60  mov [r15+0x48], r14
00007981ddfcee64  mov qword ptr [r15+0x50], 0x420B90
00007981ddfcee6c  lea rax, [r14+0x100]
00007981ddfcee73  mov r12, [r15+0xE8]
00007981ddfcee7a  mov r11, [r15+0xD8]
00007981ddfcee81  mov [r13+rax*1], r12
00007981ddfcee86  lea rax, [r14+0x108]
00007981ddfcee8d  mov [r13+rax*1], r11
00007981ddfcee92  lea rax, [r14+0x110]
00007981ddfcee99  mov r12, [r15+0xD0]
00007981ddfceea0  mov r11, [r15+0xC8]
00007981ddfceea7  mov [r13+rax*1], r12
00007981ddfceeac  lea rax, [r14+0x118]
00007981ddfceeb3  mov [r13+rax*1], r11
00007981ddfceeb8  lea rax, [r14+0x120]
00007981ddfceebf  mov r12, [r15+0xC0]
00007981ddfceec6  mov r11, [r15+0xB8]
00007981ddfceecd  mov [r13+rax*1], r12
00007981ddfceed2  lea rax, [r14+0x128]
00007981ddfceed9  mov [r13+rax*1], r11
00007981ddfceede  lea rax, [r14+0x130]
00007981ddfceee5  mov r12, [r15+0xB0]
00007981ddfceeec  mov r11, [r15+0xA8]
00007981ddfceef3  mov [r13+rax*1], r12
00007981ddfceef8  lea rax, [r14+0x138]
00007981ddfceeff  mov [r13+rax*1], r11
00007981ddfcef04  lea rax, [r14+0x140]
00007981ddfcef0b  mov r12, [r15+0xA0]
00007981ddfcef12  mov r11, [r15+0x98]
00007981ddfcef19  mov [r13+rax*1], r12
00007981ddfcef1e  lea rax, [r14+0x148]
00007981ddfcef25  mov [r13+rax*1], r11
00007981ddfcef2a  cmp dword ptr [r15+0x318], 0x00
00007981ddfcef32  jz 0x00007981DDFCEFD0
00007981ddfcef38  nop [rax+rax*1], ax
00007981ddfcef41  nop [rax+rax*1], eax
00007981ddfcef49  mov eax, 0x410770
00007981ddfcef4e  mov [r15+0x100], rax
00007981ddfcef55  jmp 0x00007981DDDFE110
00007981ddfcef5a  int3
00007981ddfcef5b  call 0x00007981DDEC0370
00007981ddfcef60  jmp 0x00007981DDFCEE51
00007981ddfcef65  call 0x00007981DDE0BC20
00007981ddfcef6a  jmp 0x00007981DDFCEE86
00007981ddfcef6f  call 0x00007981DDE0A9A0
00007981ddfcef74  jmp 0x00007981DDFCEE92
00007981ddfcef79  call 0x00007981DDE0BC20
00007981ddfcef7e  jmp 0x00007981DDFCEEAC
00007981ddfcef83  call 0x00007981DDE0A9A0
00007981ddfcef88  jmp 0x00007981DDFCEEB8
00007981ddfcef8d  call 0x00007981DDE0BC20
00007981ddfcef92  jmp 0x00007981DDFCEED2
00007981ddfcef97  call 0x00007981DDE0A9A0
00007981ddfcef9c  jmp 0x00007981DDFCEEDE
00007981ddfcefa1  call 0x00007981DDE0BC20
00007981ddfcefa6  jmp 0x00007981DDFCEEF8
00007981ddfcefab  call 0x00007981DDE0A9A0
00007981ddfcefb0  jmp 0x00007981DDFCEF04
00007981ddfcefb5  call 0x00007981DDE0BC20
00007981ddfcefba  jmp 0x00007981DDFCEF1E
00007981ddfcefbf  call 0x00007981DDE0A9A0
00007981ddfcefc4  jmp 0x00007981DDFCEF2A
00007981ddfcefc9  int3
00007981ddfcefca  nop [rax+rax*1], ax
00007981ddfcefd0  mov rax, [r15+0x08]
00007981ddfcefd4  movzx r14d, byte ptr [r13+rax*1]
00007981ddfcefda  movzx r14d, r14b
00007981ddfcefde  mov [rsp+0x10], r14d
00007981ddfcefe3  mov r14d, r14d
00007981ddfcefe6  mov [r15+0x58], r14
00007981ddfcefea  lea r14, [rax+0x01]
00007981ddfcefee  mov [r15+0x08], r14
00007981ddfceff2  mov rax, [r15+0x88]
00007981ddfceff9  lea r14, [rax+0x01]
00007981ddfceffd  mov r12, [r15]
00007981ddfcf000  lea r11, [r12+0x68]
00007981ddfcf005  mov [r13+r11*1], r14
00007981ddfcf00a  lea r14, [r12+rax*1]
00007981ddfcf00e  mov [r15+0x60], r14
00007981ddfcf012  lea rax, [r14+0x28]
00007981ddfcf016  mov r11d, [rsp+0x10]
00007981ddfcf01b  movzx r14d, r11b
00007981ddfcf01f  mov [r13+rax*1], r14b
00007981ddfcf024  lea rax, [r12+0x68]
00007981ddfcf029  mov r14, [r13+rax*1]
00007981ddfcf02e  mov [r15+0x88], r14
00007981ddfcf035  xor eax, eax
00007981ddfcf037  mov r12d, 0x40
00007981ddfcf03d  cmp r14, r12
00007981ddfcf040  cmc
00007981ddfcf041  lahf
00007981ddfcf042  seto al
00007981ddfcf045  mov [r15+0x108], eax
00007981ddfcf04c  mov eax, [r15+0x108]
00007981ddfcf053  sahf
00007981ddfcf054  jnz 0x00007981DDFCF086
00007981ddfcf056  cmp dword ptr [r15+0x318], 0x00
00007981ddfcf05e  jz 0x00007981DDFCF170
00007981ddfcf064  nop [rax+rax*1], ax
00007981ddfcf06d  nop [rax+rax*1], eax
00007981ddfcf075  mov eax, 0x410790
00007981ddfcf07a  mov [r15+0x100], rax
00007981ddfcf081  jmp 0x00007981DDDFE110
00007981ddfcf086  cmp dword ptr [r15+0x318], 0x00
00007981ddfcf08e  jz 0x00007981DDFCF0E0
00007981ddfcf094  nop [rax+rax*1], ax
00007981ddfcf09d  nop [rax+rax*1], eax
00007981ddfcf0a5  mov eax, 0x410768
00007981ddfcf0aa  mov [r15+0x100], rax
00007981ddfcf0b1  jmp 0x00007981DDDFE110
00007981ddfcf0b6  int3
00007981ddfcf0b7  call 0x00007981DDE0D860
00007981ddfcf0bc  jmp 0x00007981DDFCEFDA
00007981ddfcf0c1  call 0x00007981DDEB36E0
00007981ddfcf0c6  jmp 0x00007981DDFCF00A
00007981ddfcf0cb  call 0x00007981DDE0DD60
00007981ddfcf0d0  jmp 0x00007981DDFCF024
00007981ddfcf0d5  call 0x00007981DDE0DC20
00007981ddfcf0da  jmp 0x00007981DDFCF02E
00007981ddfcf0df  int3
00007981ddfcf0e0  mov rax, [r15+0x10]
00007981ddfcf0e4  lea r14, [rax-0x01]
00007981ddfcf0e8  mov [r15+0x10], r14
00007981ddfcf0ec  test r14, r14
00007981ddfcf0ef  setz r14b
00007981ddfcf0f3  movzx r14, r14b
00007981ddfcf0f7  mov [rsp+0x414], r14b
00007981ddfcf0ff  cmp byte ptr [rsp+0x414], 0x00
00007981ddfcf107  jz 0x00007981DDFCF139
00007981ddfcf109  cmp dword ptr [r15+0x318], 0x00
00007981ddfcf111  jz 0x00007981DDFD0670
00007981ddfcf117  nop [rax+rax*1], ax
00007981ddfcf120  nop [rax+rax*1], eax
00007981ddfcf128  mov eax, 0x410988
00007981ddfcf12d  mov [r15+0x100], rax
00007981ddfcf134  jmp 0x00007981DDDFE110
00007981ddfcf139  cmp dword ptr [r15+0x318], 0x00
00007981ddfcf141  jz 0x00007981DDFCEFD0
00007981ddfcf147  nop [rax+rax*1], ax
00007981ddfcf150  nop [rax+rax*1], eax
00007981ddfcf158  mov eax, 0x410770
00007981ddfcf15d  mov [r15+0x100], rax
00007981ddfcf164  jmp 0x00007981DDDFE110
00007981ddfcf169  int3
00007981ddfcf16a  int3
00007981ddfcf16b  nop [rax+rax*1], eax
00007981ddfcf170  mov rax, [r15+0x40]
00007981ddfcf174  movzx r14d, byte ptr [r13+rax*1]
00007981ddfcf17a  movaps xmm1, [r15+0x110]
00007981ddfcf182  pinsrb xmm1, r14d, 0x00
00007981ddfcf189  lea r14, [rax+0x01]
00007981ddfcf18d  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf193  movaps xmm15, [r15+0x120]
00007981ddfcf19b  pinsrb xmm15, r12d, 0x00
00007981ddfcf1a2  lea r14, [rax+0x02]
00007981ddfcf1a6  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf1ac  movaps xmm14, [r15+0x130]
00007981ddfcf1b4  pinsrb xmm14, r12d, 0x00
00007981ddfcf1bb  lea r14, [rax+0x03]
00007981ddfcf1bf  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf1c5  movaps xmm13, [r15+0x140]
00007981ddfcf1cd  pinsrb xmm13, r12d, 0x00
00007981ddfcf1d4  lea r14, [rax+0x04]
00007981ddfcf1d8  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf1de  pinsrb xmm1, r12d, 0x01
00007981ddfcf1e5  lea r14, [rax+0x05]
00007981ddfcf1e9  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf1ef  pinsrb xmm15, r12d, 0x01
00007981ddfcf1f6  lea r14, [rax+0x06]
00007981ddfcf1fa  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf200  pinsrb xmm14, r12d, 0x01
00007981ddfcf207  lea r14, [rax+0x07]
00007981ddfcf20b  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf211  pinsrb xmm13, r12d, 0x01
00007981ddfcf218  lea r14, [rax+0x08]
00007981ddfcf21c  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf222  pinsrb xmm1, r12d, 0x02
00007981ddfcf229  lea r14, [rax+0x09]
00007981ddfcf22d  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf233  pinsrb xmm15, r12d, 0x02
00007981ddfcf23a  lea r14, [rax+0x0A]
00007981ddfcf23e  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf244  pinsrb xmm14, r12d, 0x02
00007981ddfcf24b  lea r14, [rax+0x0B]
00007981ddfcf24f  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf255  pinsrb xmm13, r12d, 0x02
00007981ddfcf25c  lea r14, [rax+0x0C]
00007981ddfcf260  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf266  pinsrb xmm1, r12d, 0x03
00007981ddfcf26d  lea r14, [rax+0x0D]
00007981ddfcf271  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf277  pinsrb xmm15, r12d, 0x03
00007981ddfcf27e  lea r14, [rax+0x0E]
00007981ddfcf282  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf288  pinsrb xmm14, r12d, 0x03
00007981ddfcf28f  lea r14, [rax+0x0F]
00007981ddfcf293  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf299  pinsrb xmm13, r12d, 0x03
00007981ddfcf2a0  lea r14, [rax+0x10]
00007981ddfcf2a4  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf2aa  pinsrb xmm1, r12d, 0x04
00007981ddfcf2b1  lea r14, [rax+0x11]
00007981ddfcf2b5  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf2bb  pinsrb xmm15, r12d, 0x04
00007981ddfcf2c2  lea r14, [rax+0x12]
00007981ddfcf2c6  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf2cc  pinsrb xmm14, r12d, 0x04
00007981ddfcf2d3  lea r14, [rax+0x13]
00007981ddfcf2d7  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf2dd  pinsrb xmm13, r12d, 0x04
00007981ddfcf2e4  lea r14, [rax+0x14]
00007981ddfcf2e8  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf2ee  pinsrb xmm1, r12d, 0x05
00007981ddfcf2f5  lea r14, [rax+0x15]
00007981ddfcf2f9  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf2ff  pinsrb xmm15, r12d, 0x05
00007981ddfcf306  lea r14, [rax+0x16]
00007981ddfcf30a  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf310  pinsrb xmm14, r12d, 0x05
00007981ddfcf317  lea r14, [rax+0x17]
00007981ddfcf31b  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf321  pinsrb xmm13, r12d, 0x05
00007981ddfcf328  lea r14, [rax+0x18]
00007981ddfcf32c  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf332  pinsrb xmm1, r12d, 0x06
00007981ddfcf339  lea r14, [rax+0x19]
00007981ddfcf33d  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf343  pinsrb xmm15, r12d, 0x06
00007981ddfcf34a  lea r14, [rax+0x1A]
00007981ddfcf34e  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf354  pinsrb xmm14, r12d, 0x06
00007981ddfcf35b  lea r14, [rax+0x1B]
00007981ddfcf35f  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf365  pinsrb xmm13, r12d, 0x06
00007981ddfcf36c  lea r14, [rax+0x1C]
00007981ddfcf370  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf376  pinsrb xmm1, r12d, 0x07
00007981ddfcf37d  lea r14, [rax+0x1D]
00007981ddfcf381  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf387  pinsrb xmm15, r12d, 0x07
00007981ddfcf38e  lea r14, [rax+0x1E]
00007981ddfcf392  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf398  pinsrb xmm14, r12d, 0x07
00007981ddfcf39f  lea r14, [rax+0x1F]
00007981ddfcf3a3  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf3a9  pinsrb xmm13, r12d, 0x07
00007981ddfcf3b0  lea r14, [rax+0x20]
00007981ddfcf3b4  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf3ba  pinsrb xmm1, r12d, 0x08
00007981ddfcf3c1  lea r14, [rax+0x21]
00007981ddfcf3c5  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf3cb  pinsrb xmm15, r12d, 0x08
00007981ddfcf3d2  lea r14, [rax+0x22]
00007981ddfcf3d6  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf3dc  pinsrb xmm14, r12d, 0x08
00007981ddfcf3e3  lea r14, [rax+0x23]
00007981ddfcf3e7  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf3ed  pinsrb xmm13, r12d, 0x08
00007981ddfcf3f4  lea r14, [rax+0x24]
00007981ddfcf3f8  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf3fe  pinsrb xmm1, r12d, 0x09
00007981ddfcf405  lea r14, [rax+0x25]
00007981ddfcf409  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf40f  pinsrb xmm15, r12d, 0x09
00007981ddfcf416  lea r14, [rax+0x26]
00007981ddfcf41a  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf420  pinsrb xmm14, r12d, 0x09
00007981ddfcf427  lea r14, [rax+0x27]
00007981ddfcf42b  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf431  pinsrb xmm13, r12d, 0x09
00007981ddfcf438  lea r14, [rax+0x28]
00007981ddfcf43c  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf442  pinsrb xmm1, r12d, 0x0A
00007981ddfcf449  lea r14, [rax+0x29]
00007981ddfcf44d  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf453  pinsrb xmm15, r12d, 0x0A
00007981ddfcf45a  lea r14, [rax+0x2A]
00007981ddfcf45e  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf464  pinsrb xmm14, r12d, 0x0A
00007981ddfcf46b  lea r14, [rax+0x2B]
00007981ddfcf46f  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf475  pinsrb xmm13, r12d, 0x0A
00007981ddfcf47c  lea r14, [rax+0x2C]
00007981ddfcf480  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf486  pinsrb xmm1, r12d, 0x0B
00007981ddfcf48d  lea r14, [rax+0x2D]
00007981ddfcf491  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf497  pinsrb xmm15, r12d, 0x0B
00007981ddfcf49e  lea r14, [rax+0x2E]
00007981ddfcf4a2  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf4a8  pinsrb xmm14, r12d, 0x0B
00007981ddfcf4af  lea r14, [rax+0x2F]
00007981ddfcf4b3  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf4b9  pinsrb xmm13, r12d, 0x0B
00007981ddfcf4c0  lea r14, [rax+0x30]
00007981ddfcf4c4  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf4ca  pinsrb xmm1, r12d, 0x0C
00007981ddfcf4d1  lea r14, [rax+0x31]
00007981ddfcf4d5  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf4db  pinsrb xmm15, r12d, 0x0C
00007981ddfcf4e2  lea r14, [rax+0x32]
00007981ddfcf4e6  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf4ec  pinsrb xmm14, r12d, 0x0C
00007981ddfcf4f3  lea r14, [rax+0x33]
00007981ddfcf4f7  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf4fd  pinsrb xmm13, r12d, 0x0C
00007981ddfcf504  lea r14, [rax+0x34]
00007981ddfcf508  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf50e  pinsrb xmm1, r12d, 0x0D
00007981ddfcf515  lea r14, [rax+0x35]
00007981ddfcf519  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf51f  pinsrb xmm15, r12d, 0x0D
00007981ddfcf526  lea r14, [rax+0x36]
00007981ddfcf52a  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf530  pinsrb xmm14, r12d, 0x0D
00007981ddfcf537  lea r14, [rax+0x37]
00007981ddfcf53b  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf541  pinsrb xmm13, r12d, 0x0D
00007981ddfcf548  lea r14, [rax+0x38]
00007981ddfcf54c  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf552  pinsrb xmm1, r12d, 0x0E
00007981ddfcf559  lea r14, [rax+0x39]
00007981ddfcf55d  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf563  pinsrb xmm15, r12d, 0x0E
00007981ddfcf56a  lea r14, [rax+0x3A]
00007981ddfcf56e  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf574  pinsrb xmm14, r12d, 0x0E
00007981ddfcf57b  lea r14, [rax+0x3B]
00007981ddfcf57f  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf585  pinsrb xmm13, r12d, 0x0E
00007981ddfcf58c  lea r14, [rax+0x3C]
00007981ddfcf590  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf596  pinsrb xmm1, r12d, 0x0F
00007981ddfcf59d  movaps [r15+0x110], xmm1
00007981ddfcf5a5  lea r14, [rax+0x3D]
00007981ddfcf5a9  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf5af  pinsrb xmm15, r12d, 0x0F
00007981ddfcf5b6  movaps [r15+0x120], xmm15
00007981ddfcf5be  lea r14, [rax+0x3E]
00007981ddfcf5c2  movzx r12d, byte ptr [r13+r14*1]
00007981ddfcf5c8  pinsrb xmm14, r12d, 0x0F
00007981ddfcf5cf  movaps [r15+0x130], xmm14
00007981ddfcf5d7  lea r14, [rax+0x3F]
00007981ddfcf5db  movzx eax, byte ptr [r13+r14*1]
00007981ddfcf5e1  pinsrb xmm13, eax, 0x0F
00007981ddfcf5e8  movaps [r15+0x140], xmm13
00007981ddfcf5f0  movq xmm1, qword ptr [r15+0x120]
00007981ddfcf5f9  pmovzxbw xmm1, xmm1
00007981ddfcf5fe  psllw xmm1, 0x00
00007981ddfcf603  movaps [r15+0x150], xmm1
00007981ddfcf60b  movq xmm1, qword ptr [r15+0x130]
00007981ddfcf614  pmovzxbw xmm1, xmm1
00007981ddfcf619  psllw xmm1, 0x00
00007981ddfcf61e  movaps [r15+0x160], xmm1
00007981ddfcf626  movq xmm1, qword ptr [r15+0x110]
00007981ddfcf62f  pmovzxbw xmm1, xmm1
00007981ddfcf634  psllw xmm1, 0x00
00007981ddfcf639  movaps [r15+0x170], xmm1
00007981ddfcf641  movaps xmm15, [r15+0x110]
00007981ddfcf649  pextrq rax, xmm15, 0x01
00007981ddfcf650  movq xmm15, rax
00007981ddfcf655  pmovzxbw xmm15, xmm15
00007981ddfcf65b  psllw xmm15, 0x00
00007981ddfcf661  movaps [r15+0x180], xmm15
00007981ddfcf669  movaps xmm14, [r15+0x120]
00007981ddfcf671  pextrq rax, xmm14, 0x01
00007981ddfcf678  movq xmm14, rax
00007981ddfcf67d  pmovzxbw xmm14, xmm14
00007981ddfcf683  psllw xmm14, 0x00
00007981ddfcf689  movaps [r15+0x210], xmm14
00007981ddfcf691  movaps xmm13, [r15+0x130]
00007981ddfcf699  pextrq rax, xmm13, 0x01
00007981ddfcf6a0  movq xmm13, rax
00007981ddfcf6a5  pmovzxbw xmm13, xmm13
00007981ddfcf6ab  psllw xmm13, 0x00
00007981ddfcf6b1  movaps [r15+0x220], xmm13
00007981ddfcf6b9  movq xmm12, qword ptr [r15+0x140]
00007981ddfcf6c2  pmovzxbw xmm12, xmm12
00007981ddfcf6c8  psllw xmm12, 0x00
00007981ddfcf6ce  movaps [r15+0x250], xmm12
00007981ddfcf6d6  movaps xmm12, [r15+0x140]
00007981ddfcf6de  pextrq rax, xmm12, 0x01
00007981ddfcf6e5  movq xmm12, rax
00007981ddfcf6ea  pmovzxbw xmm12, xmm12
00007981ddfcf6f0  psllw xmm12, 0x00
00007981ddfcf6f6  movaps [r15+0x110], xmm12
00007981ddfcf6fe  movq xmm11, qword ptr [r15+0x150]
00007981ddfcf707  pmovzxwd xmm11, xmm11
00007981ddfcf70d  pslld xmm11, 0x10
00007981ddfcf713  movq xmm10, qword ptr [r15+0x160]
00007981ddfcf71c  pmovzxwd xmm10, xmm10
00007981ddfcf722  pslld xmm10, 0x08
00007981ddfcf728  pextrq rax, xmm1, 0x01
00007981ddfcf72f  movq xmm1, rax
00007981ddfcf734  pmovzxwd xmm1, xmm1
00007981ddfcf739  pslld xmm1, 0x00
00007981ddfcf73e  movaps [r15+0x260], xmm1
00007981ddfcf746  pextrq rax, xmm15, 0x01
00007981ddfcf74d  movq xmm15, rax
00007981ddfcf752  pmovzxwd xmm15, xmm15
00007981ddfcf758  pslld xmm15, 0x00
00007981ddfcf75e  movaps [r15+0x270], xmm15
00007981ddfcf766  movq xmm9, qword ptr [r15+0x170]
00007981ddfcf76f  pmovzxwd xmm9, xmm9
00007981ddfcf775  pslld xmm9, 0x00
00007981ddfcf77b  pextrq rax, xmm14, 0x01
00007981ddfcf782  movq xmm14, rax
00007981ddfcf787  pmovzxwd xmm14, xmm14
00007981ddfcf78d  pslld xmm14, 0x10
00007981ddfcf793  movaps [r15+0x280], xmm14
00007981ddfcf79b  movq xmm8, qword ptr [r15+0x180]
00007981ddfcf7a4  pmovzxwd xmm8, xmm8
00007981ddfcf7aa  pslld xmm8, 0x00
00007981ddfcf7b0  movq xmm7, qword ptr [r15+0x210]
00007981ddfcf7b9  pmovzxwd xmm7, xmm7
00007981ddfcf7be  pslld xmm7, 0x10
00007981ddfcf7c3  movaps xmm6, [r15+0x150]
00007981ddfcf7cb  pextrq rax, xmm6, 0x01
00007981ddfcf7d2  movq xmm6, rax
00007981ddfcf7d7  pmovzxwd xmm6, xmm6
00007981ddfcf7dc  pslld xmm6, 0x10
00007981ddfcf7e1  por xmm11, xmm10
00007981ddfcf7e6  movaps [r15+0x230], xmm11
00007981ddfcf7ee  pextrq rax, xmm13, 0x01
00007981ddfcf7f5  movq xmm13, rax
00007981ddfcf7fa  pmovzxwd xmm13, xmm13
00007981ddfcf800  pslld xmm13, 0x08
00007981ddfcf806  movaps [r15+0x240], xmm13
00007981ddfcf80e  movq xmm10, qword ptr [r15+0x220]
00007981ddfcf817  pmovzxwd xmm10, xmm10
00007981ddfcf81d  pslld xmm10, 0x08
00007981ddfcf823  movaps xmm5, [r15+0x160]
00007981ddfcf82b  pextrq rax, xmm5, 0x01
00007981ddfcf832  movq xmm5, rax
00007981ddfcf837  pmovzxwd xmm5, xmm5
00007981ddfcf83c  pslld xmm5, 0x08
00007981ddfcf841  pslld xmm9, 0x18
00007981ddfcf847  pslld xmm15, 0x18
00007981ddfcf84d  pslld xmm8, 0x18
00007981ddfcf853  movq xmm4, qword ptr [r15+0x250]
00007981ddfcf85c  pmovzxwd xmm4, xmm4
00007981ddfcf861  pslld xmm4, 0x00
00007981ddfcf866  por xmm14, xmm13
00007981ddfcf86b  por xmm7, xmm10
00007981ddfcf870  movaps [r15+0x210], xmm7
00007981ddfcf878  pslld xmm1, 0x18
00007981ddfcf87d  movaps [r15+0x220], xmm1
00007981ddfcf885  por xmm6, xmm5
00007981ddfcf889  por xmm11, xmm9
00007981ddfcf88e  movaps [r15+0x160], xmm11
00007981ddfcf896  pextrq rax, xmm12, 0x01
00007981ddfcf89d  movq xmm13, rax
00007981ddfcf8a2  pmovzxwd xmm13, xmm13
00007981ddfcf8a8  pslld xmm13, 0x00
00007981ddfcf8ae  movaps [r15+0x170], xmm13
00007981ddfcf8b6  movq xmm12, qword ptr [r15+0x110]
00007981ddfcf8bf  pmovzxwd xmm12, xmm12
00007981ddfcf8c5  pslld xmm12, 0x00
00007981ddfcf8cb  por xmm14, xmm15
00007981ddfcf8d0  por xmm7, xmm8
00007981ddfcf8d5  movaps xmm15, [r15+0x250]
00007981ddfcf8dd  pextrq rax, xmm15, 0x01
00007981ddfcf8e4  movq xmm15, rax
00007981ddfcf8e9  pmovzxwd xmm15, xmm15
00007981ddfcf8ef  pslld xmm15, 0x00
00007981ddfcf8f5  movaps [r15+0x180], xmm15
00007981ddfcf8fd  por xmm6, xmm1
00007981ddfcf901  movaps [r15+0x150], xmm6
00007981ddfcf909  por xmm11, xmm4
00007981ddfcf90e  movaps [r15+0x140], xmm11
00007981ddfcf916  por xmm7, xmm12
00007981ddfcf91b  movaps [r15+0x110], xmm7
00007981ddfcf923  por xmm14, xmm13
00007981ddfcf928  movaps [r15+0x120], xmm14
00007981ddfcf930  por xmm6, xmm15
00007981ddfcf935  movaps [r15+0x130], xmm6
00007981ddfcf93d  mov rax, [r15+0xF8]
00007981ddfcf944  lea r14, [rax+0x20]
00007981ddfcf948  movups [r13+r14*1], xmm7
00007981ddfcf94e  lea r14, [rax+0x30]
00007981ddfcf952  movups [r13+r14*1], xmm14
00007981ddfcf958  movups [r13+rax*1], xmm11
00007981ddfcf95e  lea r14, [rax+0x10]
00007981ddfcf962  movups [r13+r14*1], xmm6
00007981ddfcf968  mov r14d, [r13+rax*1]
00007981ddfcf96d  mov rax, [r15+0x48]
00007981ddfcf971  mov [r15+0x68], rax
00007981ddfcf975  mov qword ptr [r15+0x58], 0x04
00007981ddfcf97d  lea r12, [rax+0x04]
00007981ddfcf981  mov r11d, [r13+r12*1]
00007981ddfcf986  mov [rsp+0x10], r11d
00007981ddfcf98b  mov r11d, r11d
00007981ddfcf98e  mov [r15+0x70], r11
00007981ddfcf992  lea r12, [rax+0x38]
00007981ddfcf996  mov r11d, [r13+r12*1]
00007981ddfcf99b  lea r12, [rax+0x24]
00007981ddfcf99f  mov r10d, [r13+r12*1]
00007981ddfcf9a4  mov [rsp+0x20], r10d
00007981ddfcf9a9  mov r10d, r10d
00007981ddfcf9ac  mov [r15+0x90], r10
00007981ddfcf9b3  mov [rsp+0x30], rax
00007981ddfcf9b8  xor eax, eax
00007981ddfcf9ba  mov r12d, 0x04
00007981ddfcf9c0  mov r10d, 0xC0
00007981ddfcf9c6  cmp r12, r10
00007981ddfcf9c9  cmc
00007981ddfcf9ca  lahf
00007981ddfcf9cb  seto al
00007981ddfcf9ce  mov [r15+0x108], eax
00007981ddfcf9d5  mov eax, [rsp+0x10]
00007981ddfcf9d9  mov r12d, [rsp+0x10]
00007981ddfcf9de  shrd eax, r12d, 0x07
00007981ddfcf9e3  mov [rsp+0x10], r11d
00007981ddfcf9e8  mov r10d, [rsp+0x10]
00007981ddfcf9ed  shrd r11d, r10d, 0x11
00007981ddfcf9f2  mov r9d, [rsp+0x20]
00007981ddfcf9f7  lea r8d, [r9d+r14d*1]
00007981ddfcf9fc  rorx r14d, r12d, 0x12
00007981ddfcfa02  xor eax, r14d
00007981ddfcfa05  rorx r14d, r10d, 0x13
00007981ddfcfa0b  xor r11d, r14d
00007981ddfcfa0e  mov [rsp+0x10], r11d
00007981ddfcfa13  mov r11d, r11d
00007981ddfcfa16  mov [r15+0x88], r11
00007981ddfcfa1d  mov [rsp+0x20], r12d
00007981ddfcfa22  shr r12d, 0x03
00007981ddfcfa26  xor eax, r12d
00007981ddfcfa29  mov [rsp+0x40], eax
00007981ddfcfa2d  mov eax, eax
00007981ddfcfa2f  mov [r15+0x80], rax
00007981ddfcfa36  shr r10d, 0x0A
00007981ddfcfa3a  mov eax, [rsp+0x10]
00007981ddfcfa3e  xor eax, r10d
00007981ddfcfa41  mov [rsp+0x10], eax
00007981ddfcfa45  mov eax, eax
00007981ddfcfa47  mov [r15+0x78], rax
00007981ddfcfa4b  mov eax, [rsp+0x40]
00007981ddfcfa4f  lea r14d, [r8d+eax*1]
00007981ddfcfa54  mov eax, [rsp+0x10]
00007981ddfcfa58  lea r12d, [r14d+eax*1]
00007981ddfcfa5d  mov rax, [rsp+0x30]
00007981ddfcfa62  lea r14, [rax+0x40]
00007981ddfcfa66  mov [r13+r14*1], r12d
00007981ddfcfa6b  mov eax, [rsp+0x20]
00007981ddfcfa6f  mov eax, eax
00007981ddfcfa71  mov [r15+0x60], rax
00007981ddfcfa75  mov eax, [r15+0x108]
00007981ddfcfa7c  sahf
00007981ddfcfa7d  jnz 0x00007981DDFCFAAF
00007981ddfcfa7f  cmp dword ptr [r15+0x318], 0x00
00007981ddfcfa87  jz 0x00007981DDFCFF70
00007981ddfcfa8d  nop [rax+rax*1], ax
00007981ddfcfa96  nop [rax+rax*1], eax
00007981ddfcfa9e  mov eax, 0x41088C
00007981ddfcfaa3  mov [r15+0x100], rax
00007981ddfcfaaa  jmp 0x00007981DDDFE110
00007981ddfcfaaf  cmp dword ptr [r15+0x318], 0x00
00007981ddfcfab7  jz 0x00007981DDFCFDC0
00007981ddfcfabd  nop [rax+rax*1], ax
00007981ddfcfac6  nop [rax+rax*1], eax
00007981ddfcface  mov eax, 0x410844
00007981ddfcfad3  mov [r15+0x100], rax
00007981ddfcfada  jmp 0x00007981DDDFE110
00007981ddfcfadf  int3
00007981ddfcfae0  call 0x00007981DDE0D860
00007981ddfcfae5  jmp 0x00007981DDFCF17A
00007981ddfcfaea  call 0x00007981DDEE2420
00007981ddfcfaef  jmp 0x00007981DDFCF193
00007981ddfcfaf4  call 0x00007981DDEE2420
00007981ddfcfaf9  jmp 0x00007981DDFCF1AC
00007981ddfcfafe  call 0x00007981DDEE2420
00007981ddfcfb03  jmp 0x00007981DDFCF1C5
00007981ddfcfb08  call 0x00007981DDEE2420
00007981ddfcfb0d  jmp 0x00007981DDFCF1DE
00007981ddfcfb12  call 0x00007981DDEE2420
00007981ddfcfb17  jmp 0x00007981DDFCF1EF
00007981ddfcfb1c  call 0x00007981DDEE2420
00007981ddfcfb21  jmp 0x00007981DDFCF200
00007981ddfcfb26  call 0x00007981DDEE2420
00007981ddfcfb2b  jmp 0x00007981DDFCF211
00007981ddfcfb30  call 0x00007981DDEE2420
00007981ddfcfb35  jmp 0x00007981DDFCF222
00007981ddfcfb3a  call 0x00007981DDEE2420
00007981ddfcfb3f  jmp 0x00007981DDFCF233
00007981ddfcfb44  call 0x00007981DDEE2420
00007981ddfcfb49  jmp 0x00007981DDFCF244
00007981ddfcfb4e  call 0x00007981DDEE2420
00007981ddfcfb53  jmp 0x00007981DDFCF255
00007981ddfcfb58  call 0x00007981DDEE2420
00007981ddfcfb5d  jmp 0x00007981DDFCF266
00007981ddfcfb62  call 0x00007981DDEE2420
00007981ddfcfb67  jmp 0x00007981DDFCF277
00007981ddfcfb6c  call 0x00007981DDEE2420
00007981ddfcfb71  jmp 0x00007981DDFCF288
00007981ddfcfb76  call 0x00007981DDEE2420
00007981ddfcfb7b  jmp 0x00007981DDFCF299
00007981ddfcfb80  call 0x00007981DDEE2420
00007981ddfcfb85  jmp 0x00007981DDFCF2AA
00007981ddfcfb8a  call 0x00007981DDEE2420
00007981ddfcfb8f  jmp 0x00007981DDFCF2BB
00007981ddfcfb94  call 0x00007981DDEE2420
00007981ddfcfb99  jmp 0x00007981DDFCF2CC
00007981ddfcfb9e  call 0x00007981DDEE2420
00007981ddfcfba3  jmp 0x00007981DDFCF2DD
00007981ddfcfba8  call 0x00007981DDEE2420
00007981ddfcfbad  jmp 0x00007981DDFCF2EE
00007981ddfcfbb2  call 0x00007981DDEE2420
00007981ddfcfbb7  jmp 0x00007981DDFCF2FF
00007981ddfcfbbc  call 0x00007981DDEE2420
00007981ddfcfbc1  jmp 0x00007981DDFCF310
00007981ddfcfbc6  call 0x00007981DDEE2420
00007981ddfcfbcb  jmp 0x00007981DDFCF321
00007981ddfcfbd0  call 0x00007981DDEE2420
00007981ddfcfbd5  jmp 0x00007981DDFCF332
00007981ddfcfbda  call 0x00007981DDEE2420
00007981ddfcfbdf  jmp 0x00007981DDFCF343
00007981ddfcfbe4  call 0x00007981DDEE2420
00007981ddfcfbe9  jmp 0x00007981DDFCF354
00007981ddfcfbee  call 0x00007981DDEE2420
00007981ddfcfbf3  jmp 0x00007981DDFCF365
00007981ddfcfbf8  call 0x00007981DDEE2420
00007981ddfcfbfd  jmp 0x00007981DDFCF376
00007981ddfcfc02  call 0x00007981DDEE2420
00007981ddfcfc07  jmp 0x00007981DDFCF387
00007981ddfcfc0c  call 0x00007981DDEE2420
00007981ddfcfc11  jmp 0x00007981DDFCF398
00007981ddfcfc16  call 0x00007981DDEE2420
00007981ddfcfc1b  jmp 0x00007981DDFCF3A9
00007981ddfcfc20  call 0x00007981DDEE2420
00007981ddfcfc25  jmp 0x00007981DDFCF3BA
00007981ddfcfc2a  call 0x00007981DDEE2420
00007981ddfcfc2f  jmp 0x00007981DDFCF3CB
00007981ddfcfc34  call 0x00007981DDEE2420
00007981ddfcfc39  jmp 0x00007981DDFCF3DC
00007981ddfcfc3e  call 0x00007981DDEE2420
00007981ddfcfc43  jmp 0x00007981DDFCF3ED
00007981ddfcfc48  call 0x00007981DDEE2420
00007981ddfcfc4d  jmp 0x00007981DDFCF3FE
00007981ddfcfc52  call 0x00007981DDEE2420
00007981ddfcfc57  jmp 0x00007981DDFCF40F
00007981ddfcfc5c  call 0x00007981DDEE2420
00007981ddfcfc61  jmp 0x00007981DDFCF420
00007981ddfcfc66  call 0x00007981DDEE2420
00007981ddfcfc6b  jmp 0x00007981DDFCF431
00007981ddfcfc70  call 0x00007981DDEE2420
00007981ddfcfc75  jmp 0x00007981DDFCF442
00007981ddfcfc7a  call 0x00007981DDEE2420
00007981ddfcfc7f  jmp 0x00007981DDFCF453
00007981ddfcfc84  call 0x00007981DDEE2420
00007981ddfcfc89  jmp 0x00007981DDFCF464
00007981ddfcfc8e  call 0x00007981DDEE2420
00007981ddfcfc93  jmp 0x00007981DDFCF475
00007981ddfcfc98  call 0x00007981DDEE2420
00007981ddfcfc9d  jmp 0x00007981DDFCF486
00007981ddfcfca2  call 0x00007981DDEE2420
00007981ddfcfca7  jmp 0x00007981DDFCF497
00007981ddfcfcac  call 0x00007981DDEE2420
00007981ddfcfcb1  jmp 0x00007981DDFCF4A8
00007981ddfcfcb6  call 0x00007981DDEE2420
00007981ddfcfcbb  jmp 0x00007981DDFCF4B9
00007981ddfcfcc0  call 0x00007981DDEE2420
00007981ddfcfcc5  jmp 0x00007981DDFCF4CA
00007981ddfcfcca  call 0x00007981DDEE2420
00007981ddfcfccf  jmp 0x00007981DDFCF4DB
00007981ddfcfcd4  call 0x00007981DDEE2420
00007981ddfcfcd9  jmp 0x00007981DDFCF4EC
00007981ddfcfcde  call 0x00007981DDEE2420
00007981ddfcfce3  jmp 0x00007981DDFCF4FD
00007981ddfcfce8  call 0x00007981DDEE2420
00007981ddfcfced  jmp 0x00007981DDFCF50E
00007981ddfcfcf2  call 0x00007981DDEE2420
00007981ddfcfcf7  jmp 0x00007981DDFCF51F
00007981ddfcfcfc  call 0x00007981DDEE2420
00007981ddfcfd01  jmp 0x00007981DDFCF530
00007981ddfcfd06  call 0x00007981DDEE2420
00007981ddfcfd0b  jmp 0x00007981DDFCF541
00007981ddfcfd10  call 0x00007981DDEE2420
00007981ddfcfd15  jmp 0x00007981DDFCF552
00007981ddfcfd1a  call 0x00007981DDEE2420
00007981ddfcfd1f  jmp 0x00007981DDFCF563
00007981ddfcfd24  call 0x00007981DDEE2420
00007981ddfcfd29  jmp 0x00007981DDFCF574
00007981ddfcfd2e  call 0x00007981DDEE2420
00007981ddfcfd33  jmp 0x00007981DDFCF585
00007981ddfcfd38  call 0x00007981DDEE2420
00007981ddfcfd3d  jmp 0x00007981DDFCF596
00007981ddfcfd42  call 0x00007981DDEE2420
00007981ddfcfd47  jmp 0x00007981DDFCF5AF
00007981ddfcfd4c  call 0x00007981DDEE2420
00007981ddfcfd51  jmp 0x00007981DDFCF5C8
00007981ddfcfd56  call 0x00007981DDED5610
00007981ddfcfd5b  jmp 0x00007981DDFCF5E1
00007981ddfcfd60  call 0x00007981DDEDC580
00007981ddfcfd65  jmp 0x00007981DDFCF94E
00007981ddfcfd6a  call 0x00007981DDEE46C0
00007981ddfcfd6f  jmp 0x00007981DDFCF958
00007981ddfcfd74  call 0x00007981DDE09E90
00007981ddfcfd79  jmp 0x00007981DDFCF95E
00007981ddfcfd7e  call 0x00007981DDEDB310
00007981ddfcfd83  jmp 0x00007981DDFCF968
00007981ddfcfd88  call 0x00007981DDE0DAE0
00007981ddfcfd8d  jmp 0x00007981DDFCF96D
00007981ddfcfd92  call 0x00007981DDEC0230
00007981ddfcfd97  jmp 0x00007981DDFCF986
00007981ddfcfd9c  call 0x00007981DDEC0230
00007981ddfcfda1  jmp 0x00007981DDFCF99B
00007981ddfcfda6  call 0x00007981DDEBEFC0
00007981ddfcfdab  jmp 0x00007981DDFCF9A4
00007981ddfcfdb0  call 0x00007981DDEE2BA0
00007981ddfcfdb5  jmp 0x00007981DDFCFA6B
00007981ddfcfdba  int3
00007981ddfcfdbb  nop [rax+rax*1], eax
00007981ddfcfdc0  mov rax, [r15+0x48]
00007981ddfcfdc4  mov r14, [r15+0x58]
00007981ddfcfdc8  lea r12, [rax+r14*1]
00007981ddfcfdcc  mov [r15+0x68], r12
00007981ddfcfdd0  lea rax, [r14+0x04]
00007981ddfcfdd4  mov [r15+0x58], rax
00007981ddfcfdd8  lea r14, [r12+0x04]
00007981ddfcfddd  mov r11d, [r13+r14*1]
00007981ddfcfde2  mov [rsp+0x10], r11d
00007981ddfcfde7  mov r11d, r11d
00007981ddfcfdea  mov [r15+0x70], r11
00007981ddfcfdee  lea r14, [r12+0x38]
00007981ddfcfdf3  mov r11d, [r13+r14*1]
00007981ddfcfdf8  lea r14, [r12+0x24]
00007981ddfcfdfd  mov r10d, [r13+r14*1]
00007981ddfcfe02  mov [rsp+0x20], r10d
00007981ddfcfe07  mov r10d, r10d
00007981ddfcfe0a  mov [r15+0x90], r10
00007981ddfcfe11  mov [rsp+0x30], rax
00007981ddfcfe16  xor eax, eax
00007981ddfcfe18  mov r14, [rsp+0x30]
00007981ddfcfe1d  mov r10d, 0xC0
00007981ddfcfe23  cmp r14, r10
00007981ddfcfe26  cmc
00007981ddfcfe27  lahf
00007981ddfcfe28  seto al
00007981ddfcfe2b  mov [r15+0x108], eax
00007981ddfcfe32  mov eax, [rsp+0x10]
00007981ddfcfe36  mov r14d, [rsp+0x10]
00007981ddfcfe3b  shrd eax, r14d, 0x07
00007981ddfcfe40  mov [rsp+0x10], r11d
00007981ddfcfe45  mov r10d, [rsp+0x10]
00007981ddfcfe4a  shrd r11d, r10d, 0x11
00007981ddfcfe4f  mov r9d, [r15+0x60]
00007981ddfcfe53  mov r8d, [rsp+0x20]
00007981ddfcfe58  lea ebp, [r8d+r9d*1]
00007981ddfcfe5d  rorx r9d, r14d, 0x12
00007981ddfcfe63  xor eax, r9d
00007981ddfcfe66  rorx r9d, r10d, 0x13
00007981ddfcfe6c  xor r11d, r9d
00007981ddfcfe6f  mov [rsp+0x10], r11d
00007981ddfcfe74  mov r11d, r11d
00007981ddfcfe77  mov [r15+0x88], r11
00007981ddfcfe7e  mov [rsp+0x20], r14d
00007981ddfcfe83  shr r14d, 0x03
00007981ddfcfe87  xor eax, r14d
00007981ddfcfe8a  mov [rsp+0x30], eax
00007981ddfcfe8e  mov eax, eax
00007981ddfcfe90  mov [r15+0x80], rax
00007981ddfcfe97  shr r10d, 0x0A
00007981ddfcfe9b  mov eax, [rsp+0x10]
00007981ddfcfe9f  xor eax, r10d
00007981ddfcfea2  mov [rsp+0x10], eax
00007981ddfcfea6  mov eax, eax
00007981ddfcfea8  mov [r15+0x78], rax
00007981ddfcfeac  mov eax, [rsp+0x30]
00007981ddfcfeb0  lea r14d, [ebp+eax*1]
00007981ddfcfeb6  mov eax, [rsp+0x10]
00007981ddfcfeba  lea r11d, [r14d+eax*1]
00007981ddfcfebf  lea rax, [r12+0x40]
00007981ddfcfec4  mov [r13+rax*1], r11d
00007981ddfcfec9  mov eax, [rsp+0x20]
00007981ddfcfecd  mov eax, eax
00007981ddfcfecf  mov [r15+0x60], rax
00007981ddfcfed3  mov eax, [r15+0x108]
00007981ddfcfeda  sahf
00007981ddfcfedb  jnz 0x00007981DDFCFF0D
00007981ddfcfedd  cmp dword ptr [r15+0x318], 0x00
00007981ddfcfee5  jz 0x00007981DDFCFF70
00007981ddfcfeeb  nop [rax+rax*1], ax
00007981ddfcfef4  nop [rax+rax*1], eax
00007981ddfcfefc  mov eax, 0x41088C
00007981ddfcff01  mov [r15+0x100], rax
00007981ddfcff08  jmp 0x00007981DDDFE110
00007981ddfcff0d  cmp dword ptr [r15+0x318], 0x00
00007981ddfcff15  jz 0x00007981DDFCFDC0
00007981ddfcff1b  nop [rax+rax*1], ax
00007981ddfcff24  nop [rax+rax*1], eax
00007981ddfcff2c  mov eax, 0x410844
00007981ddfcff31  mov [r15+0x100], rax
00007981ddfcff38  jmp 0x00007981DDDFE110
00007981ddfcff3d  int3
00007981ddfcff3e  call 0x00007981DDEE1430
00007981ddfcff43  jmp 0x00007981DDFCFDE2
00007981ddfcff48  call 0x00007981DDEE1430
00007981ddfcff4d  jmp 0x00007981DDFCFDF8
00007981ddfcff52  call 0x00007981DDEE01C0
00007981ddfcff57  jmp 0x00007981DDFCFE02
00007981ddfcff5c  call 0x00007981DDE0A860
00007981ddfcff61  jmp 0x00007981DDFCFEC9
00007981ddfcff66  int3
00007981ddfcff67  nop [rax+rax*1], ax
00007981ddfcff70  mov rax, [r15]
00007981ddfcff73  mov r14d, [r13+rax*1]
00007981ddfcff78  lea r12, [rax+0x04]
00007981ddfcff7c  mov r11d, [r13+r12*1]
00007981ddfcff81  mov [rsp+0x10], r14d
00007981ddfcff86  mov r14d, r14d
00007981ddfcff89  mov [r15+0x78], r14
00007981ddfcff8d  mov [rsp+0x20], r11d
00007981ddfcff92  mov r11d, r11d
00007981ddfcff95  mov [r15+0x80], r11
00007981ddfcff9c  lea r14, [rax+0x08]
00007981ddfcffa0  mov r12d, [r13+r14*1]
00007981ddfcffa5  lea r14, [rax+0x0C]
00007981ddfcffa9  mov r11d, [r13+r14*1]
00007981ddfcffae  mov [rsp+0x30], r12d
00007981ddfcffb3  mov r12d, r12d
00007981ddfcffb6  mov [r15+0x70], r12
00007981ddfcffba  mov [rsp+0x40], r11d
00007981ddfcffbf  mov r11d, r11d
00007981ddfcffc2  mov [r15+0x68], r11
00007981ddfcffc6  lea r14, [rax+0x18]
00007981ddfcffca  mov r12d, [r13+r14*1]
00007981ddfcffcf  lea r14, [rax+0x1C]
00007981ddfcffd3  mov r11d, [r13+r14*1]
00007981ddfcffd8  mov [rsp+0x50], r12d
00007981ddfcffdd  mov r12d, r12d
00007981ddfcffe0  mov [r15+0x58], r12
00007981ddfcffe4  mov [rsp+0x60], r11d
00007981ddfcffe9  mov r11d, r11d
00007981ddfcffec  mov [r15+0x60], r11
00007981ddfcfff0  lea r14, [rax+0x10]
00007981ddfcfff4  mov r12d, [r13+r14*1]
00007981ddfcfff9  lea r14, [rax+0x14]
00007981ddfcfffd  mov eax, [r13+r14*1]
00007981ddfd0002  mov [rsp+0x70], r12d
00007981ddfd0007  mov r12d, r12d
00007981ddfd000a  mov [r15+0x18], r12
00007981ddfd000e  mov [rsp+0x80], eax
00007981ddfd0015  mov eax, eax
00007981ddfd0017  mov [r15+0x90], rax
00007981ddfd001e  mov eax, [rsp+0x70]
00007981ddfd0022  mov eax, eax
00007981ddfd0024  mov [r15+0x30], rax
00007981ddfd0028  mov eax, [rsp+0x50]
00007981ddfd002c  mov eax, eax
00007981ddfd002e  mov [r15+0xA0], rax
00007981ddfd0035  mov eax, [rsp+0x30]
00007981ddfd0039  mov eax, eax
00007981ddfd003b  mov [r15+0x28], rax
00007981ddfd003f  mov eax, [rsp+0x20]
00007981ddfd0043  mov eax, eax
00007981ddfd0045  mov [r15+0x98], rax
00007981ddfd004c  mov eax, [rsp+0x10]
00007981ddfd0050  mov eax, eax
00007981ddfd0052  mov [r15+0x38], rax
00007981ddfd0056  mov eax, [rsp+0x70]
00007981ddfd005a  mov r14d, [rsp+0x70]
00007981ddfd005f  shrd eax, r14d, 0x06
00007981ddfd0064  mov [rsp+0x70], r14d
00007981ddfd0069  mov r12d, [rsp+0x80]
00007981ddfd0071  and r14d, r12d
00007981ddfd0074  mov r11d, [rsp+0x10]
00007981ddfd0079  mov r10d, [rsp+0x10]
00007981ddfd007e  shrd r11d, r10d, 0x02
00007981ddfd0083  mov [rsp+0x10], r12d
00007981ddfd0088  mov r12d, r12d
00007981ddfd008b  mov [r15+0x20], r12
00007981ddfd008f  mov r12, [r15+0x50]
00007981ddfd0093  mov r9d, [r13+r12*1]
00007981ddfd0098  mov r12d, [rsp+0x50]
00007981ddfd009d  mov r8d, [rsp+0x70]
00007981ddfd00a2  andn ebp, r8d, r12d
00007981ddfd00a7  mov edi, [rsp+0x60]
00007981ddfd00ab  lea esi, [r14d+edi*1]
00007981ddfd00b0  rorx r14d, r8d, 0x0B
00007981ddfd00b6  xor eax, r14d
00007981ddfd00b9  rorx r14d, r10d, 0x0D
00007981ddfd00bf  xor r11d, r14d
00007981ddfd00c2  lea edi, [esi+ebp*1]
00007981ddfd00c6  mov r14, [r15+0x48]
00007981ddfd00ca  mov ebp, [r13+r14*1]
00007981ddfd00cf  mov r14d, [rsp+0x30]
00007981ddfd00d4  mov esi, [rsp+0x20]
00007981ddfd00d8  and r14d, esi
00007981ddfd00db  mov [rsp+0x20], r14d
00007981ddfd00e0  mov r14d, r14d
00007981ddfd00e3  mov [r15+0xD8], r14
00007981ddfd00ea  lea r14d, [edi+r9d*1]
00007981ddfd00ef  mov r9d, [rsp+0x30]
00007981ddfd00f4  xor r9d, esi
00007981ddfd00f7  rorx edi, r8d, 0x19
00007981ddfd00fd  xor eax, edi
00007981ddfd00ff  and r9d, r10d
00007981ddfd0102  rorx edi, r10d, 0x16
00007981ddfd0108  xor r11d, edi
00007981ddfd010b  mov [rsp+0x30], r11d
00007981ddfd0110  mov r11d, r11d
00007981ddfd0113  mov [r15+0xD0], r11
00007981ddfd011a  lea r11d, [r14d+ebp*1]
00007981ddfd011f  mov r10d, [rsp+0x20]
00007981ddfd0124  xor r9d, r10d
00007981ddfd0127  lea r14d, [r11d+eax*1]
00007981ddfd012c  mov qword ptr [r15+0x88], 0x04
00007981ddfd0137  mov eax, [rsp+0x30]
00007981ddfd013b  lea r11d, [r9d+eax*1]
00007981ddfd0140  mov eax, [rsp+0x40]
00007981ddfd0144  lea r10d, [r14d+eax*1]
00007981ddfd0149  mov r10d, r10d
00007981ddfd014c  mov [r15+0xB8], r10
00007981ddfd0153  xor eax, eax
00007981ddfd0155  mov r10d, 0x04
00007981ddfd015b  mov r9d, 0x100
00007981ddfd0161  cmp r10, r9
00007981ddfd0164  cmc
00007981ddfd0165  lahf
00007981ddfd0166  seto al
00007981ddfd0169  mov [r15+0x108], eax
00007981ddfd0170  lea eax, [r11d+r14d*1]
00007981ddfd0175  mov eax, eax
00007981ddfd0177  mov [r15+0xA8], rax
00007981ddfd017e  mov r12d, r12d
00007981ddfd0181  mov [r15+0xB0], r12
00007981ddfd0188  mov eax, [rsp+0x10]
00007981ddfd018c  mov eax, eax
00007981ddfd018e  mov [r15+0xC0], rax
00007981ddfd0195  mov r8d, r8d
00007981ddfd0198  mov [r15+0xC8], r8
00007981ddfd019f  mov eax, [r15+0x108]
00007981ddfd01a6  sahf
00007981ddfd01a7  jnz 0x00007981DDFD01D9
00007981ddfd01a9  cmp dword ptr [r15+0x318], 0x00
00007981ddfd01b1  jz 0x00007981DDFD04A0
00007981ddfd01b7  nop [rax+rax*1], ax
00007981ddfd01c0  nop [rax+rax*1], eax
00007981ddfd01c8  mov eax, 0x41094C
00007981ddfd01cd  mov [r15+0x100], rax
00007981ddfd01d4  jmp 0x00007981DDDFE110
00007981ddfd01d9  cmp dword ptr [r15+0x318], 0x00
00007981ddfd01e1  jz 0x00007981DDFD0270
00007981ddfd01e7  nop [rax+rax*1], ax
00007981ddfd01f0  nop [rax+rax*1], eax
00007981ddfd01f8  mov eax, 0x4108C0
00007981ddfd01fd  mov [r15+0x100], rax
00007981ddfd0204  jmp 0x00007981DDDFE110
00007981ddfd0209  int3
00007981ddfd020a  call 0x00007981DDE0DAE0
00007981ddfd020f  jmp 0x00007981DDFCFF78
00007981ddfd0214  call 0x00007981DDEC0230
00007981ddfd0219  jmp 0x00007981DDFCFF81
00007981ddfd021e  call 0x00007981DDEE26A0
00007981ddfd0223  jmp 0x00007981DDFCFFA5
00007981ddfd0228  call 0x00007981DDEE1430
00007981ddfd022d  jmp 0x00007981DDFCFFAE
00007981ddfd0232  call 0x00007981DDEE26A0
00007981ddfd0237  jmp 0x00007981DDFCFFCF
00007981ddfd023c  call 0x00007981DDEE1430
00007981ddfd0241  jmp 0x00007981DDFCFFD8
00007981ddfd0246  call 0x00007981DDEE26A0
00007981ddfd024b  jmp 0x00007981DDFCFFF9
00007981ddfd0250  call 0x00007981DDED5890
00007981ddfd0255  jmp 0x00007981DDFD0002
00007981ddfd025a  call 0x00007981DDEBDD50
00007981ddfd025f  jmp 0x00007981DDFD0098
00007981ddfd0264  call 0x00007981DDEDA580
00007981ddfd0269  jmp 0x00007981DDFD00CF
00007981ddfd026e  int3
00007981ddfd026f  nop
00007981ddfd0270  mov eax, [r15+0xB8]
00007981ddfd0277  mov [rsp+0x10], eax
00007981ddfd027b  mov eax, eax
00007981ddfd027d  mov [r15+0x30], rax
00007981ddfd0281  mov eax, [r15+0xC0]
00007981ddfd0288  mov [rsp+0x20], eax
00007981ddfd028c  mov eax, eax
00007981ddfd028e  mov [r15+0xA0], rax
00007981ddfd0295  mov eax, [r15+0x28]
00007981ddfd0299  mov r14d, [r15+0x98]
00007981ddfd02a0  mov [rsp+0x30], r14d
00007981ddfd02a5  mov r14d, r14d
00007981ddfd02a8  mov [r15+0x28], r14
00007981ddfd02ac  mov r14d, [r15+0x38]
00007981ddfd02b0  mov [rsp+0x40], r14d
00007981ddfd02b5  mov r14d, r14d
00007981ddfd02b8  mov [r15+0x98], r14
00007981ddfd02bf  mov r14d, [r15+0xA8]
00007981ddfd02c6  mov [rsp+0x50], r14d
00007981ddfd02cb  mov r14d, r14d
00007981ddfd02ce  mov [r15+0x38], r14
00007981ddfd02d2  mov r14d, [rsp+0x10]
00007981ddfd02d7  mov r12d, [rsp+0x10]
00007981ddfd02dc  shrd r14d, r12d, 0x06
00007981ddfd02e1  mov r11d, [r15+0xC8]
00007981ddfd02e8  mov [rsp+0x10], r12d
00007981ddfd02ed  and r12d, r11d
00007981ddfd02f0  mov r10d, [rsp+0x50]
00007981ddfd02f5  mov r9d, [rsp+0x50]
00007981ddfd02fa  shrd r10d, r9d, 0x02
00007981ddfd02ff  mov [rsp+0x50], r11d
00007981ddfd0304  mov r11d, r11d
00007981ddfd0307  mov [r15+0x20], r11
00007981ddfd030b  mov r11, [r15+0x88]
00007981ddfd0312  mov r8, [r15+0x50]
00007981ddfd0316  lea rbp, [r8+r11*1]
00007981ddfd031a  mov r8d, [r13+rbp*1]
00007981ddfd031f  mov ebp, [rsp+0x20]
00007981ddfd0323  mov edi, [rsp+0x10]
00007981ddfd0327  andn esi, edi, ebp
00007981ddfd032c  mov edx, [r15+0xB0]
00007981ddfd0333  lea ecx, [r12d+edx*1]
00007981ddfd0338  rorx r12d, edi, 0x0B
00007981ddfd033e  xor r14d, r12d
00007981ddfd0341  rorx r12d, r9d, 0x0D
00007981ddfd0347  xor r10d, r12d
00007981ddfd034a  lea r12d, [ecx+esi*1]
00007981ddfd034f  mov rsi, [r15+0x48]
00007981ddfd0353  lea rdx, [rsi+r11*1]
00007981ddfd0357  mov esi, [r13+rdx*1]
00007981ddfd035c  mov edx, [rsp+0x30]
00007981ddfd0360  mov ecx, [rsp+0x40]
00007981ddfd0364  and edx, ecx
00007981ddfd0366  mov [rsp+0x10], edx
00007981ddfd036a  mov edx, edx
00007981ddfd036c  mov [r15+0xD8], rdx
00007981ddfd0373  lea edx, [r12d+r8d*1]
00007981ddfd0378  mov r12d, [rsp+0x30]
00007981ddfd037d  xor r12d, ecx
00007981ddfd0380  rorx r8d, edi, 0x19
00007981ddfd0386  xor r14d, r8d
00007981ddfd0389  and r12d, r9d
00007981ddfd038c  rorx r8d, r9d, 0x16
00007981ddfd0392  xor r10d, r8d
00007981ddfd0395  mov [rsp+0x20], r10d
00007981ddfd039a  mov r10d, r10d
00007981ddfd039d  mov [r15+0xD0], r10
00007981ddfd03a4  lea r10d, [edx+esi*1]
00007981ddfd03a9  mov r9d, [rsp+0x10]
00007981ddfd03ae  xor r12d, r9d
00007981ddfd03b1  lea r9d, [r10d+r14d*1]
00007981ddfd03b6  lea r14, [r11+0x04]
00007981ddfd03ba  mov [r15+0x88], r14
00007981ddfd03c1  mov r11d, [rsp+0x20]
00007981ddfd03c6  lea r10d, [r12d+r11d*1]
00007981ddfd03cb  lea r11d, [r9d+eax*1]
00007981ddfd03d0  mov r11d, r11d
00007981ddfd03d3  mov [r15+0xB8], r11
00007981ddfd03da  xor eax, eax
00007981ddfd03dc  mov r12d, 0x100
00007981ddfd03e2  cmp r14, r12
00007981ddfd03e5  cmc
00007981ddfd03e6  lahf
00007981ddfd03e7  seto al
00007981ddfd03ea  mov [r15+0x108], eax
00007981ddfd03f1  lea eax, [r10d+r9d*1]
00007981ddfd03f6  mov eax, eax
00007981ddfd03f8  mov [r15+0xA8], rax
00007981ddfd03ff  mov ebp, ebp
00007981ddfd0401  mov [r15+0xB0], rbp
00007981ddfd0408  mov eax, [rsp+0x50]
00007981ddfd040c  mov eax, eax
00007981ddfd040e  mov [r15+0xC0], rax
00007981ddfd0415  mov edi, edi
00007981ddfd0417  mov [r15+0xC8], rdi
00007981ddfd041e  mov eax, [r15+0x108]
00007981ddfd0425  sahf
00007981ddfd0426  jnz 0x00007981DDFD0458
00007981ddfd0428  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0430  jz 0x00007981DDFD04A0
00007981ddfd0436  nop [rax+rax*1], ax
00007981ddfd043f  nop [rax+rax*1], eax
00007981ddfd0447  mov eax, 0x41094C
00007981ddfd044c  mov [r15+0x100], rax
00007981ddfd0453  jmp 0x00007981DDDFE110
00007981ddfd0458  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0460  jz 0x00007981DDFD0270
00007981ddfd0466  nop [rax+rax*1], ax
00007981ddfd046f  nop [rax+rax*1], eax
00007981ddfd0477  mov eax, 0x4108C0
00007981ddfd047c  mov [r15+0x100], rax
00007981ddfd0483  jmp 0x00007981DDDFE110
00007981ddfd0488  int3
00007981ddfd0489  call 0x00007981DDE49010
00007981ddfd048e  jmp 0x00007981DDFD031F
00007981ddfd0493  call 0x00007981DDE25930
00007981ddfd0498  jmp 0x00007981DDFD035C
00007981ddfd049d  int3
00007981ddfd049e  nop
00007981ddfd04a0  mov eax, [r15+0x98]
00007981ddfd04a7  mov r14d, [r15+0x70]
00007981ddfd04ab  lea r12d, [eax+r14d*1]
00007981ddfd04b0  mov eax, [r15+0x28]
00007981ddfd04b4  mov r14d, [r15+0x68]
00007981ddfd04b8  lea r11d, [eax+r14d*1]
00007981ddfd04bd  mov qword ptr [r15+0x88], 0x00
00007981ddfd04c8  mov eax, [r15+0xA8]
00007981ddfd04cf  mov r14d, [r15+0x78]
00007981ddfd04d3  lea r10d, [eax+r14d*1]
00007981ddfd04d8  mov [rsp+0x10], r10d
00007981ddfd04dd  mov r10d, r10d
00007981ddfd04e0  mov [r15+0x78], r10
00007981ddfd04e4  mov eax, [r15+0x38]
00007981ddfd04e8  mov r14d, [r15+0x80]
00007981ddfd04ef  lea r10d, [eax+r14d*1]
00007981ddfd04f4  mov [rsp+0x20], r10d
00007981ddfd04f9  mov r10d, r10d
00007981ddfd04fc  mov [r15+0x80], r10
00007981ddfd0503  mov rax, [r15]
00007981ddfd0506  lea r14, [rax+0x08]
00007981ddfd050a  mov [r13+r14*1], r12d
00007981ddfd050f  lea r14, [rax+0x0C]
00007981ddfd0513  mov [r13+r14*1], r11d
00007981ddfd0518  mov r14d, [r15+0xB8]
00007981ddfd051f  mov r12d, [r15+0x18]
00007981ddfd0523  lea r11d, [r14d+r12d*1]
00007981ddfd0528  mov [rsp+0x30], r11d
00007981ddfd052d  mov r11d, r11d
00007981ddfd0530  mov [r15+0x68], r11
00007981ddfd0534  mov r14d, [r15+0x30]
00007981ddfd0538  mov r12d, [r15+0x90]
00007981ddfd053f  lea r11d, [r14d+r12d*1]
00007981ddfd0544  mov [rsp+0x40], r11d
00007981ddfd0549  mov r11d, r11d
00007981ddfd054c  mov [r15+0x70], r11
00007981ddfd0550  mov r14d, [r15+0x20]
00007981ddfd0554  mov r12d, [r15+0x58]
00007981ddfd0558  lea r11d, [r14d+r12d*1]
00007981ddfd055d  mov [rsp+0x50], r11d
00007981ddfd0562  mov r11d, r11d
00007981ddfd0565  mov [r15+0x58], r11
00007981ddfd0569  mov r14d, [r15+0xA0]
00007981ddfd0570  mov r12d, [r15+0x60]
00007981ddfd0574  lea r11d, [r14d+r12d*1]
00007981ddfd0579  mov [rsp+0x60], r11d
00007981ddfd057e  mov r11d, r11d
00007981ddfd0581  mov [r15+0x60], r11
00007981ddfd0585  mov r14d, [rsp+0x10]
00007981ddfd058a  mov [r13+rax*1], r14d
00007981ddfd058f  lea r14, [rax+0x04]
00007981ddfd0593  mov r12d, [rsp+0x20]
00007981ddfd0598  mov [r13+r14*1], r12d
00007981ddfd059d  lea r14, [rax+0x10]
00007981ddfd05a1  mov r12d, [rsp+0x30]
00007981ddfd05a6  mov [r13+r14*1], r12d
00007981ddfd05ab  lea r14, [rax+0x14]
00007981ddfd05af  mov r12d, [rsp+0x40]
00007981ddfd05b4  mov [r13+r14*1], r12d
00007981ddfd05b9  lea r14, [rax+0x18]
00007981ddfd05bd  mov r12d, [rsp+0x50]
00007981ddfd05c2  mov [r13+r14*1], r12d
00007981ddfd05c7  lea r14, [rax+0x1C]
00007981ddfd05cb  mov r12d, [rsp+0x60]
00007981ddfd05d0  mov [r13+r14*1], r12d
00007981ddfd05d5  lea r14, [rax+0x68]
00007981ddfd05d9  xor eax, eax
00007981ddfd05db  mov [r13+r14*1], rax
00007981ddfd05e0  cmp dword ptr [r15+0x318], 0x00
00007981ddfd05e8  jz 0x00007981DDFCF0E0
00007981ddfd05ee  nop [rax+rax*1], ax
00007981ddfd05f7  nop [rax+rax*1], eax
00007981ddfd05ff  mov eax, 0x410768
00007981ddfd0604  mov [r15+0x100], rax
00007981ddfd060b  jmp 0x00007981DDDFE110
00007981ddfd0610  int3
00007981ddfd0611  call 0x00007981DDEE2BA0
00007981ddfd0616  jmp 0x00007981DDFD050F
00007981ddfd061b  call 0x00007981DDEE1920
00007981ddfd0620  jmp 0x00007981DDFD0518
00007981ddfd0625  call 0x00007981DDE0DFE0
00007981ddfd062a  jmp 0x00007981DDFD058F
00007981ddfd062f  call 0x00007981DDEE2BA0
00007981ddfd0634  jmp 0x00007981DDFD059D
00007981ddfd0639  call 0x00007981DDEE2BA0
00007981ddfd063e  jmp 0x00007981DDFD05AB
00007981ddfd0643  call 0x00007981DDEE2BA0
00007981ddfd0648  jmp 0x00007981DDFD05B9
00007981ddfd064d  call 0x00007981DDEE2BA0
00007981ddfd0652  jmp 0x00007981DDFD05C7
00007981ddfd0657  call 0x00007981DDEE2BA0
00007981ddfd065c  jmp 0x00007981DDFD05D5
00007981ddfd0661  call 0x00007981DDED5EB0
00007981ddfd0666  jmp 0x00007981DDFD05E0
00007981ddfd066b  int3
00007981ddfd066c  nop [rax], eax
00007981ddfd0670  mov rax, [r15+0xF8]
00007981ddfd0677  lea r14, [rax+0x140]
00007981ddfd067e  mov r12, [r13+r14*1]
00007981ddfd0683  lea r14, [rax+0x148]
00007981ddfd068a  mov r11, [r13+r14*1]
00007981ddfd068f  mov [r15+0xA0], r12
00007981ddfd0696  mov [r15+0x98], r11
00007981ddfd069d  lea r14, [rax+0x130]
00007981ddfd06a4  mov r12, [r13+r14*1]
00007981ddfd06a9  lea r14, [rax+0x138]
00007981ddfd06b0  mov r11, [r13+r14*1]
00007981ddfd06b5  mov [r15+0xB0], r12
00007981ddfd06bc  mov [r15+0xA8], r11
00007981ddfd06c3  lea r14, [rax+0x120]
00007981ddfd06ca  mov r12, [r13+r14*1]
00007981ddfd06cf  lea r14, [rax+0x128]
00007981ddfd06d6  mov r11, [r13+r14*1]
00007981ddfd06db  mov [r15+0xC0], r12
00007981ddfd06e2  mov [r15+0xB8], r11
00007981ddfd06e9  lea r14, [rax+0x110]
00007981ddfd06f0  mov r12, [r13+r14*1]
00007981ddfd06f5  lea r14, [rax+0x118]
00007981ddfd06fc  mov r11, [r13+r14*1]
00007981ddfd0701  mov [r15+0xD0], r12
00007981ddfd0708  mov [r15+0xC8], r11
00007981ddfd070f  lea r14, [rax+0x100]
00007981ddfd0716  mov r12, [r13+r14*1]
00007981ddfd071b  lea r14, [rax+0x108]
00007981ddfd0722  mov r11, [r13+r14*1]
00007981ddfd0727  mov [r15+0xE8], r12
00007981ddfd072e  mov [r15+0xD8], r11
00007981ddfd0735  lea r14, [rax+0x150]
00007981ddfd073c  mov [r15+0xF8], r14
00007981ddfd0743  mov rax, [r15+0xF0]
00007981ddfd074a  mov [r15+0x100], rax
00007981ddfd0751  jmp 0x00007981DDFCE5C0
00007981ddfd0756  int3
00007981ddfd0757  call 0x00007981DDEE27E0
00007981ddfd075c  jmp 0x00007981DDFD0683
00007981ddfd0761  call 0x00007981DDEE1570
00007981ddfd0766  jmp 0x00007981DDFD068F
00007981ddfd076b  call 0x00007981DDEE27E0
00007981ddfd0770  jmp 0x00007981DDFD06A9
00007981ddfd0775  call 0x00007981DDEE1570
00007981ddfd077a  jmp 0x00007981DDFD06B5
00007981ddfd077f  call 0x00007981DDEE27E0
00007981ddfd0784  jmp 0x00007981DDFD06CF
00007981ddfd0789  call 0x00007981DDEE1570
00007981ddfd078e  jmp 0x00007981DDFD06DB
00007981ddfd0793  call 0x00007981DDEE27E0
00007981ddfd0798  jmp 0x00007981DDFD06F5
00007981ddfd079d  call 0x00007981DDEE1570
00007981ddfd07a2  jmp 0x00007981DDFD0701
00007981ddfd07a7  call 0x00007981DDEE27E0
00007981ddfd07ac  jmp 0x00007981DDFD071B
00007981ddfd07b1  call 0x00007981DDEE1570
00007981ddfd07b6  jmp 0x00007981DDFD0727
00007981ddfd07bb  int3
00007981ddfd07bc  nop [rax], eax
00007981ddfd07c0  mov eax, [r15+0xA0]
00007981ddfd07c7  mov [rsp+0x10], eax
00007981ddfd07cb  xor eax, eax
00007981ddfd07cd  mov r14d, [rsp+0x10]
00007981ddfd07d2  sub r14d, 0x01
00007981ddfd07d6  cmc
00007981ddfd07d7  lahf
00007981ddfd07d8  seto al
00007981ddfd07db  mov [r15+0x108], eax
00007981ddfd07e2  mov r14d, r14d
00007981ddfd07e5  mov [r15+0xA0], r14
00007981ddfd07ec  mov eax, [r15+0x108]
00007981ddfd07f3  sahf
00007981ddfd07f4  jnz 0x00007981DDFD0826
00007981ddfd07f6  cmp dword ptr [r15+0x318], 0x00
00007981ddfd07fe  jz 0x00007981DDFD0900
00007981ddfd0804  nop [rax+rax*1], ax
00007981ddfd080d  nop [rax+rax*1], eax
00007981ddfd0815  mov eax, 0x41028C
00007981ddfd081a  mov [r15+0x100], rax
00007981ddfd0821  jmp 0x00007981DDDFE110
00007981ddfd0826  cmp dword ptr [r15+0x318], 0x00
00007981ddfd082e  jz 0x00007981DDFD0860
00007981ddfd0834  nop [rax+rax*1], ax
00007981ddfd083d  nop [rax+rax*1], eax
00007981ddfd0845  mov eax, 0x410274
00007981ddfd084a  mov [r15+0x100], rax
00007981ddfd0851  jmp 0x00007981DDDFE110
00007981ddfd0856  int3
00007981ddfd0857  int3
00007981ddfd0858  nop [rax+rax*1], eax
00007981ddfd0860  mov rax, [r15+0xF8]
00007981ddfd0867  lea r14, [rax+0x100]
00007981ddfd086e  mov [r15], r14
00007981ddfd0871  mov rax, [r15+0x98]
00007981ddfd0878  mov [r15+0x08], rax
00007981ddfd087c  mov qword ptr [r15+0x10], 0x12C
00007981ddfd0884  mov qword ptr [r15+0xF0], 0x410284
00007981ddfd088f  mov r14d, [r15+0x320]
00007981ddfd0896  mov eax, 0x410284
00007981ddfd089b  mov rcx, 0x7981DDFD07C0
00007981ddfd08a5  mov [r15+r14*8+0x328], rax
00007981ddfd08ad  mov [r15+r14*8+0x368], rcx
00007981ddfd08b5  add r14d, 0x01
00007981ddfd08b9  and r14d, 0x07
00007981ddfd08bd  mov [r15+0x320], r14d
00007981ddfd08c4  cmp dword ptr [r15+0x318], 0x00
00007981ddfd08cc  jz 0x00007981DDFCED70
00007981ddfd08d2  nop [rax+rax*1], ax
00007981ddfd08db  nop [rax+rax*1], eax
00007981ddfd08e3  mov eax, 0x410728
00007981ddfd08e8  mov [r15+0x100], rax
00007981ddfd08ef  jmp 0x00007981DDDFE110
00007981ddfd08f4  int3
00007981ddfd08f5  int3
00007981ddfd08f6  nop [rax+rax*1], ax
00007981ddfd08ff  nop
00007981ddfd0900  mov rax, [r15+0xF8]
00007981ddfd0907  lea r14, [rax+0x120]
00007981ddfd090e  mov r12, [r13+r14*1]
00007981ddfd0913  mov [r15+0x98], r12
00007981ddfd091a  mov qword ptr [r15+0x40], 0x80
00007981ddfd0922  lea r14, [rax+0x100]
00007981ddfd0929  mov [r15], r14
00007981ddfd092c  lea r14, [rax+0x17C]
00007981ddfd0933  mov [r15+0x08], r14
00007981ddfd0937  mov qword ptr [r15+0x10], 0x01
00007981ddfd093f  lea r14, [rax+0x17C]
00007981ddfd0946  mov eax, 0x80
00007981ddfd094b  mov [r13+r14*1], al
00007981ddfd0950  mov qword ptr [r15+0xF0], 0x4102A8
00007981ddfd095b  mov r14d, [r15+0x320]
00007981ddfd0962  mov eax, 0x4102A8
00007981ddfd0967  mov rcx, 0x7981DDFD09E0
00007981ddfd0971  mov [r15+r14*8+0x328], rax
00007981ddfd0979  mov [r15+r14*8+0x368], rcx
00007981ddfd0981  add r14d, 0x01
00007981ddfd0985  and r14d, 0x07
00007981ddfd0989  mov [r15+0x320], r14d
00007981ddfd0990  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0998  jz 0x00007981DDFCED70
00007981ddfd099e  nop [rax+rax*1], ax
00007981ddfd09a7  nop [rax+rax*1], eax
00007981ddfd09af  mov eax, 0x410728
00007981ddfd09b4  mov [r15+0x100], rax
00007981ddfd09bb  jmp 0x00007981DDDFE110
00007981ddfd09c0  int3
00007981ddfd09c1  call 0x00007981DDEE27E0
00007981ddfd09c6  jmp 0x00007981DDFD0913
00007981ddfd09cb  call 0x00007981DDED5AF0
00007981ddfd09d0  jmp 0x00007981DDFD0950
00007981ddfd09d5  int3
00007981ddfd09d6  nop [rax+rax*1], ax
00007981ddfd09df  nop
00007981ddfd09e0  mov rax, [r15+0xF8]
00007981ddfd09e7  lea r14, [rax+0x168]
00007981ddfd09ee  mov r12, [r13+r14*1]
00007981ddfd09f3  mov [r15+0x40], r12
00007981ddfd09f7  lea r14, [rax+0x178]
00007981ddfd09fe  xor eax, eax
00007981ddfd0a00  mov [r13+r14*1], al
00007981ddfd0a05  xor eax, eax
00007981ddfd0a07  mov r14d, 0x38
00007981ddfd0a0d  cmp r12, r14
00007981ddfd0a10  cmc
00007981ddfd0a11  lahf
00007981ddfd0a12  seto al
00007981ddfd0a15  mov [r15+0x108], eax
00007981ddfd0a1c  mov eax, [r15+0x108]
00007981ddfd0a23  sahf
00007981ddfd0a24  jz 0x00007981DDFD0A56
00007981ddfd0a26  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0a2e  jz 0x00007981DDFD0AA0
00007981ddfd0a34  nop [rax+rax*1], ax
00007981ddfd0a3d  nop [rax+rax*1], eax
00007981ddfd0a45  mov eax, 0x4102B8
00007981ddfd0a4a  mov [r15+0x100], rax
00007981ddfd0a51  jmp 0x00007981DDDFE110
00007981ddfd0a56  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0a5e  jz 0x00007981DDFD0BF0
00007981ddfd0a64  nop [rax+rax*1], ax
00007981ddfd0a6d  nop [rax+rax*1], eax
00007981ddfd0a75  mov eax, 0x4102D4
00007981ddfd0a7a  mov [r15+0x100], rax
00007981ddfd0a81  jmp 0x00007981DDDFE110
00007981ddfd0a86  int3
00007981ddfd0a87  call 0x00007981DDEE27E0
00007981ddfd0a8c  jmp 0x00007981DDFD09F3
00007981ddfd0a91  call 0x00007981DDED5AF0
00007981ddfd0a96  jmp 0x00007981DDFD0A05
00007981ddfd0a9b  int3
00007981ddfd0a9c  nop [rax], eax
00007981ddfd0aa0  mov rax, [r15+0xF8]
00007981ddfd0aa7  lea r14, [rax+0x100]
00007981ddfd0aae  mov [r15], r14
00007981ddfd0ab1  lea r14, [rax+0x178]
00007981ddfd0ab8  mov [r15+0x08], r14
00007981ddfd0abc  mov qword ptr [r15+0x10], 0x01
00007981ddfd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007981ddfd0acf  mov r14d, [r15+0x320]
00007981ddfd0ad6  mov eax, 0x4102C8
00007981ddfd0adb  mov rcx, 0x7981DDFD0B40
00007981ddfd0ae5  mov [r15+r14*8+0x328], rax
00007981ddfd0aed  mov [r15+r14*8+0x368], rcx
00007981ddfd0af5  add r14d, 0x01
00007981ddfd0af9  and r14d, 0x07
00007981ddfd0afd  mov [r15+0x320], r14d
00007981ddfd0b04  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0b0c  jz 0x00007981DDFCED70
00007981ddfd0b12  nop [rax+rax*1], ax
00007981ddfd0b1b  nop [rax+rax*1], eax
00007981ddfd0b23  mov eax, 0x410728
00007981ddfd0b28  mov [r15+0x100], rax
00007981ddfd0b2f  jmp 0x00007981DDDFE110
00007981ddfd0b34  int3
00007981ddfd0b35  int3
00007981ddfd0b36  nop [rax+rax*1], ax
00007981ddfd0b3f  nop
00007981ddfd0b40  mov rax, [r15+0xF8]
00007981ddfd0b47  lea r14, [rax+0x168]
00007981ddfd0b4e  mov rax, [r13+r14*1]
00007981ddfd0b53  mov [r15+0x40], rax
00007981ddfd0b57  mov [rsp+0x10], rax
00007981ddfd0b5c  xor eax, eax
00007981ddfd0b5e  mov r14, [rsp+0x10]
00007981ddfd0b63  mov r12d, 0x38
00007981ddfd0b69  cmp r14, r12
00007981ddfd0b6c  cmc
00007981ddfd0b6d  lahf
00007981ddfd0b6e  seto al
00007981ddfd0b71  mov [r15+0x108], eax
00007981ddfd0b78  mov eax, [r15+0x108]
00007981ddfd0b7f  sahf
00007981ddfd0b80  jnz 0x00007981DDFD0BB2
00007981ddfd0b82  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0b8a  jz 0x00007981DDFD0BF0
00007981ddfd0b90  nop [rax+rax*1], ax
00007981ddfd0b99  nop [rax+rax*1], eax
00007981ddfd0ba1  mov eax, 0x4102D4
00007981ddfd0ba6  mov [r15+0x100], rax
00007981ddfd0bad  jmp 0x00007981DDDFE110
00007981ddfd0bb2  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0bba  jz 0x00007981DDFD0AA0
00007981ddfd0bc0  nop [rax+rax*1], ax
00007981ddfd0bc9  nop [rax+rax*1], eax
00007981ddfd0bd1  mov eax, 0x4102B8
00007981ddfd0bd6  mov [r15+0x100], rax
00007981ddfd0bdd  jmp 0x00007981DDDFE110
00007981ddfd0be2  int3
00007981ddfd0be3  call 0x00007981DDED59C0
00007981ddfd0be8  jmp 0x00007981DDFD0B53
00007981ddfd0bed  int3
00007981ddfd0bee  nop
00007981ddfd0bf0  mov rax, [r15+0x98]
00007981ddfd0bf7  rorx r14, rax, 0x3D
00007981ddfd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007981ddfd0c01  mov rax, [r15+0xF8]
00007981ddfd0c08  lea r12, [rax+0x100]
00007981ddfd0c0f  mov [r15], r12
00007981ddfd0c12  lea r12, [rax+0x170]
00007981ddfd0c19  mov [r15+0x08], r12
00007981ddfd0c1d  mov qword ptr [r15+0x10], 0x08
00007981ddfd0c25  bswap r14
00007981ddfd0c28  mov [r15+0x40], r14
00007981ddfd0c2c  lea r12, [rax+0x170]
00007981ddfd0c33  mov [r13+r12*1], r14
00007981ddfd0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007981ddfd0c43  mov r14d, [r15+0x320]
00007981ddfd0c4a  mov eax, 0x4102F0
00007981ddfd0c4f  mov rcx, 0x7981DDFD0CC0
00007981ddfd0c59  mov [r15+r14*8+0x328], rax
00007981ddfd0c61  mov [r15+r14*8+0x368], rcx
00007981ddfd0c69  add r14d, 0x01
00007981ddfd0c6d  and r14d, 0x07
00007981ddfd0c71  mov [r15+0x320], r14d
00007981ddfd0c78  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0c80  jz 0x00007981DDFCED70
00007981ddfd0c86  nop [rax+rax*1], ax
00007981ddfd0c8f  nop [rax+rax*1], eax
00007981ddfd0c97  mov eax, 0x410728
00007981ddfd0c9c  mov [r15+0x100], rax
00007981ddfd0ca3  jmp 0x00007981DDDFE110
00007981ddfd0ca8  int3
00007981ddfd0ca9  call 0x00007981DDEC3FE0
00007981ddfd0cae  jmp 0x00007981DDFD0C38
00007981ddfd0cb3  int3
00007981ddfd0cb4  nop [rax+rax*1], ax
00007981ddfd0cbd  nop [rax], eax
00007981ddfd0cc0  mov rax, [r15+0xF8]
00007981ddfd0cc7  lea r14, [rax+0x100]
00007981ddfd0cce  mov r12d, [r13+r14*1]
00007981ddfd0cd3  lea r14, [rax+0x104]
00007981ddfd0cda  mov r11d, [r13+r14*1]
00007981ddfd0cdf  mov qword ptr [r15+0x48], 0x430C90
00007981ddfd0ce7  lea r14, [rax+0x108]
00007981ddfd0cee  mov r10d, [r13+r14*1]
00007981ddfd0cf3  lea r14, [rax+0x10C]
00007981ddfd0cfa  mov r9d, [r13+r14*1]
00007981ddfd0cff  bswap r12d
00007981ddfd0d02  bswap r11d
00007981ddfd0d05  mov qword ptr [r15+0xA0], 0x00
00007981ddfd0d10  mov r14d, 0x430C90
00007981ddfd0d16  mov [r13+r14*1], r12d
00007981ddfd0d1b  mov r14d, 0x430C94
00007981ddfd0d21  mov [r13+r14*1], r11d
00007981ddfd0d26  bswap r10d
00007981ddfd0d29  lea r14, [rax+0x110]
00007981ddfd0d30  mov r12d, [r13+r14*1]
00007981ddfd0d35  bswap r9d
00007981ddfd0d38  lea r14, [rax+0x114]
00007981ddfd0d3f  mov r11d, [r13+r14*1]
00007981ddfd0d44  mov qword ptr [r15+0x98], 0x430DFC
00007981ddfd0d4f  mov r14d, 0x430C98
00007981ddfd0d55  mov [r13+r14*1], r10d
00007981ddfd0d5a  mov r14d, 0x430C9C
00007981ddfd0d60  mov [r13+r14*1], r9d
00007981ddfd0d65  bswap r12d
00007981ddfd0d68  lea r14, [rax+0x118]
00007981ddfd0d6f  mov r10d, [r13+r14*1]
00007981ddfd0d74  bswap r11d
00007981ddfd0d77  mov [rsp+0x10], r11d
00007981ddfd0d7c  mov r11d, r11d
00007981ddfd0d7f  mov [r15+0x58], r11
00007981ddfd0d83  lea r14, [rax+0x11C]
00007981ddfd0d8a  mov eax, [r13+r14*1]
00007981ddfd0d8f  mov [rsp+0x20], eax
00007981ddfd0d93  mov eax, eax
00007981ddfd0d95  mov [r15+0x60], rax
00007981ddfd0d99  mov eax, 0x430CA0
00007981ddfd0d9e  mov [r13+rax*1], r12d
00007981ddfd0da3  mov eax, 0x430CA4
00007981ddfd0da8  mov r14d, [rsp+0x10]
00007981ddfd0dad  mov [r13+rax*1], r14d
00007981ddfd0db2  bswap r10d
00007981ddfd0db5  mov [rsp+0x10], r10d
00007981ddfd0dba  mov r10d, r10d
00007981ddfd0dbd  mov [r15+0x40], r10
00007981ddfd0dc1  mov eax, [rsp+0x20]
00007981ddfd0dc5  bswap eax
00007981ddfd0dc7  mov [rsp+0x20], eax
00007981ddfd0dcb  mov eax, eax
00007981ddfd0dcd  mov [r15+0x50], rax
00007981ddfd0dd1  mov eax, 0x430CA8
00007981ddfd0dd6  mov r14d, [rsp+0x10]
00007981ddfd0ddb  mov [r13+rax*1], r14d
00007981ddfd0de0  mov eax, 0x430CAC
00007981ddfd0de5  mov r14d, [rsp+0x20]
00007981ddfd0dea  mov [r13+rax*1], r14d
00007981ddfd0def  mov eax, [r15+0xA0]
00007981ddfd0df6  lea r14d, [eax+0x11]
00007981ddfd0dfb  mov r14d, r14d
00007981ddfd0dfe  mov [r15], r14
00007981ddfd0e01  mov qword ptr [r15+0xF0], 0x41035C
00007981ddfd0e0c  mov r14d, [r15+0x320]
00007981ddfd0e13  mov eax, 0x41035C
00007981ddfd0e18  mov rcx, 0x7981DDFD0F90
00007981ddfd0e22  mov [r15+r14*8+0x328], rax
00007981ddfd0e2a  mov [r15+r14*8+0x368], rcx
00007981ddfd0e32  add r14d, 0x01
00007981ddfd0e36  and r14d, 0x07
00007981ddfd0e3a  mov [r15+0x320], r14d
00007981ddfd0e41  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0e49  jz 0x00007981DDFD0F20
00007981ddfd0e4f  nop [rax+rax*1], ax
00007981ddfd0e58  nop [rax+rax*1], eax
00007981ddfd0e60  mov eax, 0x4109A4
00007981ddfd0e65  mov [r15+0x100], rax
00007981ddfd0e6c  jmp 0x00007981DDDFE110
00007981ddfd0e71  int3
00007981ddfd0e72  call 0x00007981DDEE26A0
00007981ddfd0e77  jmp 0x00007981DDFD0CD3
00007981ddfd0e7c  call 0x00007981DDEE1430
00007981ddfd0e81  jmp 0x00007981DDFD0CDF
00007981ddfd0e86  call 0x00007981DDEE01C0
00007981ddfd0e8b  jmp 0x00007981DDFD0CF3
00007981ddfd0e90  call 0x00007981DDEDEF50
00007981ddfd0e95  jmp 0x00007981DDFD0CFF
00007981ddfd0e9a  call 0x00007981DDEE2BA0
00007981ddfd0e9f  jmp 0x00007981DDFD0D1B
00007981ddfd0ea4  call 0x00007981DDEE1920
00007981ddfd0ea9  jmp 0x00007981DDFD0D26
00007981ddfd0eae  call 0x00007981DDEE26A0
00007981ddfd0eb3  jmp 0x00007981DDFD0D35
00007981ddfd0eb8  call 0x00007981DDEE1430
00007981ddfd0ebd  jmp 0x00007981DDFD0D44
00007981ddfd0ec2  call 0x00007981DDEE06B0
00007981ddfd0ec7  jmp 0x00007981DDFD0D5A
00007981ddfd0ecc  call 0x00007981DDEDF440
00007981ddfd0ed1  jmp 0x00007981DDFD0D65
00007981ddfd0ed6  call 0x00007981DDEE01C0
00007981ddfd0edb  jmp 0x00007981DDFD0D74
00007981ddfd0ee0  call 0x00007981DDED5890
00007981ddfd0ee5  jmp 0x00007981DDFD0D8F
00007981ddfd0eea  call 0x00007981DDE0BAE0
00007981ddfd0eef  jmp 0x00007981DDFD0DA3
00007981ddfd0ef4  call 0x00007981DDE0DFE0
00007981ddfd0ef9  jmp 0x00007981DDFD0DB2
00007981ddfd0efe  call 0x00007981DDE0DFE0
00007981ddfd0f03  jmp 0x00007981DDFD0DE0
00007981ddfd0f08  call 0x00007981DDE0DFE0
00007981ddfd0f0d  jmp 0x00007981DDFD0DEF
00007981ddfd0f12  int3
00007981ddfd0f13  nop [rax+rax*1], ax
00007981ddfd0f1c  nop [rax], eax
00007981ddfd0f20  mov eax, [r15]
00007981ddfd0f23  mov [rsp+0x10], eax
00007981ddfd0f27  shr eax, 0x10
00007981ddfd0f2a  mov r14d, [rsp+0x10]
00007981ddfd0f2f  xor r14d, eax
00007981ddfd0f32  imul r14d, r14d, 0x7FEB352D
00007981ddfd0f39  mov eax, 0x846CA68B
00007981ddfd0f3e  mov eax, eax
00007981ddfd0f40  mov [r15+0x48], rax
00007981ddfd0f44  mov [rsp+0x10], r14d
00007981ddfd0f49  shr r14d, 0x0F
00007981ddfd0f4d  mov eax, [rsp+0x10]
00007981ddfd0f51  xor eax, r14d
00007981ddfd0f54  imul eax, eax, 0x846CA68B
00007981ddfd0f5a  mov [rsp+0x10], eax
00007981ddfd0f5e  mov eax, eax
00007981ddfd0f60  mov [r15+0x40], rax
00007981ddfd0f64  mov eax, [rsp+0x10]
00007981ddfd0f68  shr eax, 0x10
00007981ddfd0f6b  mov r14d, [rsp+0x10]
00007981ddfd0f70  xor r14d, eax
00007981ddfd0f73  mov r14d, r14d
00007981ddfd0f76  mov [r15], r14
00007981ddfd0f79  mov rax, [r15+0xF0]
00007981ddfd0f80  mov [r15+0x100], rax
00007981ddfd0f87  jmp 0x00007981DDFCE5C0
00007981ddfd0f8c  int3
00007981ddfd0f8d  int3
00007981ddfd0f8e  nop
00007981ddfd0f90  mov rax, [r15+0xA0]
00007981ddfd0f97  mov [rsp+0x10], rax
00007981ddfd0f9c  shl rax, 0x02
00007981ddfd0fa0  mov r14, [r15+0x98]
00007981ddfd0fa7  lea r12, [r14+rax*1]
00007981ddfd0fab  mov eax, [r15]
00007981ddfd0fae  mov [r13+r12*1], eax
00007981ddfd0fb3  mov rax, [rsp+0x10]
00007981ddfd0fb8  lea r14, [rax+0x01]
00007981ddfd0fbc  mov [r15+0xA0], r14
00007981ddfd0fc3  xor eax, eax
00007981ddfd0fc5  mov r12d, 0x400
00007981ddfd0fcb  cmp r14, r12
00007981ddfd0fce  cmc
00007981ddfd0fcf  lahf
00007981ddfd0fd0  seto al
00007981ddfd0fd3  mov [r15+0x108], eax
00007981ddfd0fda  mov eax, [r15+0x108]
00007981ddfd0fe1  sahf
00007981ddfd0fe2  jnz 0x00007981DDFD1014
00007981ddfd0fe4  cmp dword ptr [r15+0x318], 0x00
00007981ddfd0fec  jz 0x00007981DDFD10E0
00007981ddfd0ff2  nop [rax+rax*1], ax
00007981ddfd0ffb  nop [rax+rax*1], eax
00007981ddfd1003  mov eax, 0x41036C
00007981ddfd1008  mov [r15+0x100], rax
00007981ddfd100f  jmp 0x00007981DDDFE110
00007981ddfd1014  cmp dword ptr [r15+0x318], 0x00
00007981ddfd101c  jz 0x00007981DDFD1050
00007981ddfd1022  nop [rax+rax*1], ax
00007981ddfd102b  nop [rax+rax*1], eax
00007981ddfd1033  mov eax, 0x410354
00007981ddfd1038  mov [r15+0x100], rax
00007981ddfd103f  jmp 0x00007981DDDFE110
00007981ddfd1044  int3
00007981ddfd1045  call 0x00007981DDEB4B70
00007981ddfd104a  jmp 0x00007981DDFD0FB3
00007981ddfd104f  int3
00007981ddfd1050  mov eax, [r15+0xA0]
00007981ddfd1057  lea r14d, [eax+0x11]
00007981ddfd105c  mov r14d, r14d
00007981ddfd105f  mov [r15], r14
00007981ddfd1062  mov qword ptr [r15+0xF0], 0x41035C
00007981ddfd106d  mov r14d, [r15+0x320]
00007981ddfd1074  mov eax, 0x41035C
00007981ddfd1079  mov rcx, 0x7981DDFD0F90
00007981ddfd1083  mov [r15+r14*8+0x328], rax
00007981ddfd108b  mov [r15+r14*8+0x368], rcx
00007981ddfd1093  add r14d, 0x01
00007981ddfd1097  and r14d, 0x07
00007981ddfd109b  mov [r15+0x320], r14d
00007981ddfd10a2  cmp dword ptr [r15+0x318], 0x00
00007981ddfd10aa  jz 0x00007981DDFD0F20
00007981ddfd10b0  nop [rax+rax*1], ax
00007981ddfd10b9  nop [rax+rax*1], eax
00007981ddfd10c1  mov eax, 0x4109A4
00007981ddfd10c6  mov [r15+0x100], rax
00007981ddfd10cd  jmp 0x00007981DDDFE110
00007981ddfd10d2  int3
00007981ddfd10d3  int3
00007981ddfd10d4  nop [rax+rax*1], ax
00007981ddfd10dd  nop [rax], eax
00007981ddfd10e0  mov qword ptr [r15+0x40], 0x01
00007981ddfd10e8  cmp dword ptr [r15+0x318], 0x00
00007981ddfd10f0  jz 0x00007981DDFD1120
00007981ddfd10f6  nop [rax+rax*1], ax
00007981ddfd10ff  nop [rax+rax*1], eax
00007981ddfd1107  mov eax, 0x410388
00007981ddfd110c  mov [r15+0x100], rax
00007981ddfd1113  jmp 0x00007981DDDFE110
00007981ddfd1118  int3
00007981ddfd1119  int3
00007981ddfd111a  nop [rax+rax*1], ax
00007981ddfd1120  mov rax, [r15+0x40]
00007981ddfd1124  mov [rsp+0x10], rax
00007981ddfd1129  shl rax, 0x02
00007981ddfd112d  mov r14, [r15+0x98]
00007981ddfd1134  lea r12, [r14+rax*1]
00007981ddfd1138  mov eax, [r13+r12*1]
00007981ddfd113d  mov [rsp+0x20], eax
00007981ddfd1141  mov eax, eax
00007981ddfd1143  mov [r15+0x48], rax
00007981ddfd1147  mov rax, [rsp+0x10]
00007981ddfd114c  mov [r15+0x50], rax
00007981ddfd1150  mov eax, [r15+0x50]
00007981ddfd1154  lea r12d, [eax-0x01]
00007981ddfd1159  mov r12d, r12d
00007981ddfd115c  mov [r15+0x58], r12
00007981ddfd1160  mov rax, [r15+0x58]
00007981ddfd1164  mov r12d, eax
00007981ddfd1167  mov r12d, r12d
00007981ddfd116a  shl r12, 0x02
00007981ddfd116e  lea rax, [r14+r12*1]
00007981ddfd1172  mov r14d, [r13+rax*1]
00007981ddfd1177  mov [rsp+0x10], r14d
00007981ddfd117c  mov r14d, r14d
00007981ddfd117f  mov [r15+0x60], r14
00007981ddfd1183  xor eax, eax
00007981ddfd1185  mov r14d, [rsp+0x10]
00007981ddfd118a  mov r12d, [rsp+0x20]
00007981ddfd118f  cmp r14d, r12d
00007981ddfd1192  cmc
00007981ddfd1193  lahf
00007981ddfd1194  seto al
00007981ddfd1197  mov [r15+0x108], eax
00007981ddfd119e  mov eax, [r15+0x108]
00007981ddfd11a5  sahf
00007981ddfd11a6  cmc
00007981ddfd11a7  jbe 0x00007981DDFD11D9
00007981ddfd11a9  cmp dword ptr [r15+0x318], 0x00
00007981ddfd11b1  jz 0x00007981DDFD1220
00007981ddfd11b7  nop [rax+rax*1], ax
00007981ddfd11c0  nop [rax+rax*1], eax
00007981ddfd11c8  mov eax, 0x4103A0
00007981ddfd11cd  mov [r15+0x100], rax
00007981ddfd11d4  jmp 0x00007981DDDFE110
00007981ddfd11d9  cmp dword ptr [r15+0x318], 0x00
00007981ddfd11e1  jz 0x00007981DDFD14C0
00007981ddfd11e7  nop [rax+rax*1], ax
00007981ddfd11f0  nop [rax+rax*1], eax
00007981ddfd11f8  mov eax, 0x410378
00007981ddfd11fd  mov [r15+0x100], rax
00007981ddfd1204  jmp 0x00007981DDDFE110
00007981ddfd1209  int3
00007981ddfd120a  call 0x00007981DDEB4690
00007981ddfd120f  jmp 0x00007981DDFD113D
00007981ddfd1214  call 0x00007981DDE0DAE0
00007981ddfd1219  jmp 0x00007981DDFD1177
00007981ddfd121e  int3
00007981ddfd121f  nop
00007981ddfd1220  mov rax, [r15+0x50]
00007981ddfd1224  mov [rsp+0x10], rax
00007981ddfd1229  shl rax, 0x02
00007981ddfd122d  mov r14, [r15+0x98]
00007981ddfd1234  lea r12, [r14+rax*1]
00007981ddfd1238  mov eax, [r15+0x60]
00007981ddfd123c  mov [r13+r12*1], eax
00007981ddfd1241  mov rax, [rsp+0x10]
00007981ddfd1246  lea r14, [rax-0x01]
00007981ddfd124a  mov [r15+0x50], r14
00007981ddfd124e  mov rax, [r15+0x58]
00007981ddfd1252  test rax, rax
00007981ddfd1255  setz al
00007981ddfd1258  movzx rax, al
00007981ddfd125c  mov [rsp+0x414], al
00007981ddfd1263  cmp byte ptr [rsp+0x414], 0x00
00007981ddfd126b  jz 0x00007981DDFD129D
00007981ddfd126d  cmp dword ptr [r15+0x318], 0x00
00007981ddfd1275  jz 0x00007981DDFD12E0
00007981ddfd127b  nop [rax+rax*1], ax
00007981ddfd1284  nop [rax+rax*1], eax
00007981ddfd128c  mov eax, 0x4103AC
00007981ddfd1291  mov [r15+0x100], rax
00007981ddfd1298  jmp 0x00007981DDDFE110
00007981ddfd129d  cmp dword ptr [r15+0x318], 0x00
00007981ddfd12a5  jz 0x00007981DDFD13E0
00007981ddfd12ab  nop [rax+rax*1], ax
00007981ddfd12b4  nop [rax+rax*1], eax
00007981ddfd12bc  mov eax, 0x410390
00007981ddfd12c1  mov [r15+0x100], rax
00007981ddfd12c8  jmp 0x00007981DDDFE110
00007981ddfd12cd  int3
00007981ddfd12ce  call 0x00007981DDEB4B70
00007981ddfd12d3  jmp 0x00007981DDFD1241
00007981ddfd12d8  int3
00007981ddfd12d9  nop [rax], eax
00007981ddfd12e0  cmp dword ptr [r15+0x318], 0x00
00007981ddfd12e8  jz 0x00007981DDFD1320
00007981ddfd12ee  nop [rax+rax*1], ax
00007981ddfd12f7  nop [rax+rax*1], eax
00007981ddfd12ff  mov eax, 0x410374
00007981ddfd1304  mov [r15+0x100], rax
00007981ddfd130b  jmp 0x00007981DDDFE110
00007981ddfd1310  int3
00007981ddfd1311  int3
00007981ddfd1312  nop [rax+rax*1], ax
00007981ddfd131b  nop [rax+rax*1], eax
00007981ddfd1320  mov qword ptr [r15+0x50], 0x00
00007981ddfd1328  mov rax, [r15+0x40]
00007981ddfd132c  lea r14, [rax+0x01]
00007981ddfd1330  mov [r15+0x40], r14
00007981ddfd1334  mov rax, [r15+0x98]
00007981ddfd133b  mov r12d, [r15+0x48]
00007981ddfd133f  mov [r13+rax*1], r12d
00007981ddfd1344  xor eax, eax
00007981ddfd1346  mov r12d, 0x400
00007981ddfd134c  cmp r14, r12
00007981ddfd134f  cmc
00007981ddfd1350  lahf
00007981ddfd1351  seto al
00007981ddfd1354  mov [r15+0x108], eax
00007981ddfd135b  mov eax, [r15+0x108]
00007981ddfd1362  sahf
00007981ddfd1363  jz 0x00007981DDFD1395
00007981ddfd1365  cmp dword ptr [r15+0x318], 0x00
00007981ddfd136d  jz 0x00007981DDFD1120
00007981ddfd1373  nop [rax+rax*1], ax
00007981ddfd137c  nop [rax+rax*1], eax
00007981ddfd1384  mov eax, 0x410388
00007981ddfd1389  mov [r15+0x100], rax
00007981ddfd1390  jmp 0x00007981DDDFE110
00007981ddfd1395  cmp dword ptr [r15+0x318], 0x00
00007981ddfd139d  jz 0x00007981DDFD1580
00007981ddfd13a3  nop [rax+rax*1], ax
00007981ddfd13ac  nop [rax+rax*1], eax
00007981ddfd13b4  mov eax, 0x4103B0
00007981ddfd13b9  mov [r15+0x100], rax
00007981ddfd13c0  jmp 0x00007981DDDFE110
00007981ddfd13c5  int3
00007981ddfd13c6  call 0x00007981DDE0BAE0
00007981ddfd13cb  jmp 0x00007981DDFD1344
00007981ddfd13d0  int3
00007981ddfd13d1  nop [rax+rax*1], ax
00007981ddfd13da  nop [rax+rax*1], ax
00007981ddfd13e0  mov eax, [r15+0x50]
00007981ddfd13e4  lea r14d, [eax-0x01]
00007981ddfd13e9  mov r14d, r14d
00007981ddfd13ec  mov [r15+0x58], r14
00007981ddfd13f0  mov rax, [r15+0x58]
00007981ddfd13f4  mov r14d, eax
00007981ddfd13f7  mov r14d, r14d
00007981ddfd13fa  shl r14, 0x02
00007981ddfd13fe  mov rax, [r15+0x98]
00007981ddfd1405  lea r12, [rax+r14*1]
00007981ddfd1409  mov eax, [r13+r12*1]
00007981ddfd140e  mov [rsp+0x10], eax
00007981ddfd1412  mov eax, eax
00007981ddfd1414  mov [r15+0x60], rax
00007981ddfd1418  mov eax, [r15+0x48]
00007981ddfd141c  mov [rsp+0x20], eax
00007981ddfd1420  xor eax, eax
00007981ddfd1422  mov r14d, [rsp+0x10]
00007981ddfd1427  mov r12d, [rsp+0x20]
00007981ddfd142c  cmp r14d, r12d
00007981ddfd142f  cmc
00007981ddfd1430  lahf
00007981ddfd1431  seto al
00007981ddfd1434  mov [r15+0x108], eax
00007981ddfd143b  mov eax, [r15+0x108]
00007981ddfd1442  sahf
00007981ddfd1443  cmc
00007981ddfd1444  jbe 0x00007981DDFD1476
00007981ddfd1446  cmp dword ptr [r15+0x318], 0x00
00007981ddfd144e  jz 0x00007981DDFD1220
00007981ddfd1454  nop [rax+rax*1], ax
00007981ddfd145d  nop [rax+rax*1], eax
00007981ddfd1465  mov eax, 0x4103A0
00007981ddfd146a  mov [r15+0x100], rax
00007981ddfd1471  jmp 0x00007981DDDFE110
00007981ddfd1476  cmp dword ptr [r15+0x318], 0x00
00007981ddfd147e  jz 0x00007981DDFD14C0
00007981ddfd1484  nop [rax+rax*1], ax
00007981ddfd148d  nop [rax+rax*1], eax
00007981ddfd1495  mov eax, 0x410378
00007981ddfd149a  mov [r15+0x100], rax
00007981ddfd14a1  jmp 0x00007981DDDFE110
00007981ddfd14a6  int3
00007981ddfd14a7  call 0x00007981DDEB4690
00007981ddfd14ac  jmp 0x00007981DDFD140E
00007981ddfd14b1  int3
00007981ddfd14b2  nop [rax+rax*1], ax
00007981ddfd14bb  nop [rax+rax*1], eax
00007981ddfd14c0  mov rax, [r15+0x40]
00007981ddfd14c4  lea r14, [rax+0x01]
00007981ddfd14c8  mov [r15+0x40], r14
00007981ddfd14cc  mov rax, [r15+0x50]
00007981ddfd14d0  mov r12d, eax
00007981ddfd14d3  mov r12d, r12d
00007981ddfd14d6  shl r12, 0x02
00007981ddfd14da  mov rax, [r15+0x98]
00007981ddfd14e1  lea r11, [rax+r12*1]
00007981ddfd14e5  mov eax, [r15+0x48]
00007981ddfd14e9  mov [r13+r11*1], eax
00007981ddfd14ee  xor eax, eax
00007981ddfd14f0  mov r12d, 0x400
00007981ddfd14f6  cmp r14, r12
00007981ddfd14f9  cmc
00007981ddfd14fa  lahf
00007981ddfd14fb  seto al
00007981ddfd14fe  mov [r15+0x108], eax
00007981ddfd1505  mov eax, [r15+0x108]
00007981ddfd150c  sahf
00007981ddfd150d  jz 0x00007981DDFD153F
00007981ddfd150f  cmp dword ptr [r15+0x318], 0x00
00007981ddfd1517  jz 0x00007981DDFD1120
00007981ddfd151d  nop [rax+rax*1], ax
00007981ddfd1526  nop [rax+rax*1], eax
00007981ddfd152e  mov eax, 0x410388
00007981ddfd1533  mov [r15+0x100], rax
00007981ddfd153a  jmp 0x00007981DDDFE110
00007981ddfd153f  cmp dword ptr [r15+0x318], 0x00
00007981ddfd1547  jz 0x00007981DDFD1580
00007981ddfd154d  nop [rax+rax*1], ax
00007981ddfd1556  nop [rax+rax*1], eax
00007981ddfd155e  mov eax, 0x4103B0
00007981ddfd1563  mov [r15+0x100], rax
00007981ddfd156a  jmp 0x00007981DDDFE110
00007981ddfd156f  int3
00007981ddfd1570  call 0x00007981DDEA4270
00007981ddfd1575  jmp 0x00007981DDFD14EE
00007981ddfd157a  int3
00007981ddfd157b  nop [rax+rax*1], eax
00007981ddfd1580  mov qword ptr [r15+0x40], 0x430000
00007981ddfd1588  mov eax, 0x430CB0
00007981ddfd158d  mov r14, [r13+rax*1]
00007981ddfd1592  mov rax, [r15+0x98]
00007981ddfd1599  mov r12d, [r13+rax*1]
00007981ddfd159e  lea r11, [rax+0x04]
00007981ddfd15a2  mov eax, [r13+r11*1]
00007981ddfd15a7  mov r12d, r12d
00007981ddfd15aa  mov [r15+0x68], r12
00007981ddfd15ae  mov eax, eax
00007981ddfd15b0  mov [r15+0x60], rax
00007981ddfd15b4  mov rax, [r15+0x68]
00007981ddfd15b8  mov [r15+0x68], rax
00007981ddfd15bc  mov qword ptr [r15+0x58], 0x02
00007981ddfd15c4  mov [rsp+0x10], rax
00007981ddfd15c9  xor eax, eax
00007981ddfd15cb  mov r12d, 0x02
00007981ddfd15d1  mov r11d, 0x400
00007981ddfd15d7  cmp r12, r11
00007981ddfd15da  cmc
00007981ddfd15db  lahf
00007981ddfd15dc  seto al
00007981ddfd15df  mov [r15+0x108], eax
00007981ddfd15e6  mov rax, [r15+0x60]
00007981ddfd15ea  mov r12d, 0x02
00007981ddfd15f0  imul rax, r12
00007981ddfd15f4  mov [r15+0x50], rax
00007981ddfd15f8  mov rax, [rsp+0x10]
00007981ddfd15fd  lea r12, [rax+r14*1]
00007981ddfd1601  mov [r15+0x48], r12
00007981ddfd1605  mov eax, [r15+0x108]
00007981ddfd160c  sahf
00007981ddfd160d  jnz 0x00007981DDFD163F
00007981ddfd160f  cmp dword ptr [r15+0x318], 0x00
00007981ddfd1617  jz 0x00007981DDFD17B0
00007981ddfd161d  nop [rax+rax*1], ax
00007981ddfd1626  nop [rax+rax*1], eax
00007981ddfd162e  mov eax, 0x4103E0
00007981ddfd1633  mov [r15+0x100], rax
00007981ddfd163a  jmp 0x00007981DDDFE110
00007981ddfd163f  cmp dword ptr [r15+0x318], 0x00
00007981ddfd1647  jz 0x00007981DDFD1690
00007981ddfd164d  nop [rax+rax*1], ax
00007981ddfd1656  nop [rax+rax*1], eax
00007981ddfd165e  mov eax, 0x4103C0
00007981ddfd1663  mov [r15+0x100], rax
00007981ddfd166a  jmp 0x00007981DDDFE110
00007981ddfd166f  int3
00007981ddfd1670  call 0x00007981DDE0DC20
00007981ddfd1675  jmp 0x00007981DDFD1592
00007981ddfd167a  call 0x00007981DDE0B5E0
00007981ddfd167f  jmp 0x00007981DDFD159E
00007981ddfd1684  call 0x00007981DDEA3D90
00007981ddfd1689  jmp 0x00007981DDFD15A7
00007981ddfd168e  int3
00007981ddfd168f  nop
00007981ddfd1690  mov rax, [r15+0x98]
00007981ddfd1697  mov r14, [r15+0x58]
00007981ddfd169b  mov [rsp+0x10], r14
00007981ddfd16a0  shl r14, 0x02
00007981ddfd16a4  lea r12, [rax+r14*1]
00007981ddfd16a8  mov eax, [r13+r12*1]
00007981ddfd16ad  lea r14, [r12+0x04]
00007981ddfd16b2  mov r12d, [r13+r14*1]
00007981ddfd16b7  mov eax, eax
00007981ddfd16b9  mov [r15+0x68], rax
00007981ddfd16bd  mov r12d, r12d
00007981ddfd16c0  mov [r15+0x60], r12
00007981ddfd16c4  mov rax, [r15+0x68]
00007981ddfd16c8  mov [rsp+0x20], rax
00007981ddfd16cd  mov r14, [rsp+0x10]
00007981ddfd16d2  imul rax, r14
00007981ddfd16d6  mov r12, [rsp+0x20]
00007981ddfd16db  lea r11, [r12+rax*1]
00007981ddfd16df  mov [r15+0x68], r11
00007981ddfd16e3  lea rax, [r14+0x02]
00007981ddfd16e7  mov [r15+0x58], rax
00007981ddfd16eb  mov [rsp+0x10], rax
00007981ddfd16f0  xor eax, eax
00007981ddfd16f2  mov r14, [rsp+0x10]
00007981ddfd16f7  mov r12d, 0x400
00007981ddfd16fd  cmp r14, r12
00007981ddfd1700  cmc
00007981ddfd1701  lahf
00007981ddfd1702  seto al
00007981ddfd1705  mov [r15+0x108], eax
00007981ddfd170c  mov rax, [r15+0x50]
00007981ddfd1710  mov r12, [r15+0x60]
00007981ddfd1714  imul r14, r12
00007981ddfd1718  lea r12, [rax+r14*1]
00007981ddfd171c  mov [r15+0x50], r12
00007981ddfd1720  mov rax, [r15+0x48]
00007981ddfd1724  lea r14, [r11+rax*1]
00007981ddfd1728  mov [r15+0x48], r14
00007981ddfd172c  mov eax, [r15+0x108]
00007981ddfd1733  sahf
00007981ddfd1734  jnz 0x00007981DDFD1766
00007981ddfd1736  cmp dword ptr [r15+0x318], 0x00
00007981ddfd173e  jz 0x00007981DDFD17B0
00007981ddfd1744  nop [rax+rax*1], ax
00007981ddfd174d  nop [rax+rax*1], eax
00007981ddfd1755  mov eax, 0x4103E0
00007981ddfd175a  mov [r15+0x100], rax
00007981ddfd1761  jmp 0x00007981DDDFE110
00007981ddfd1766  cmp dword ptr [r15+0x318], 0x00
00007981ddfd176e  jz 0x00007981DDFD1690
00007981ddfd1774  nop [rax+rax*1], ax
00007981ddfd177d  nop [rax+rax*1], eax
00007981ddfd1785  mov eax, 0x4103C0
00007981ddfd178a  mov [r15+0x100], rax
00007981ddfd1791  jmp 0x00007981DDDFE110
00007981ddfd1796  int3
00007981ddfd1797  call 0x00007981DDEB4690
00007981ddfd179c  jmp 0x00007981DDFD16AD
00007981ddfd17a1  call 0x00007981DDEE26A0
00007981ddfd17a6  jmp 0x00007981DDFD16B7
00007981ddfd17ab  int3
00007981ddfd17ac  nop [rax], eax
00007981ddfd17b0  mov qword ptr [r15+0x98], 0x00
00007981ddfd17bb  mov rax, [r15+0x50]
00007981ddfd17bf  mov r14, [r15+0x48]
00007981ddfd17c3  lea r12, [rax+r14*1]
00007981ddfd17c7  mov [r15+0x48], r12
00007981ddfd17cb  mov rax, [r15+0x40]
00007981ddfd17cf  lea r14, [rax+0xCB0]
00007981ddfd17d6  mov [r13+r14*1], r12
00007981ddfd17db  mov qword ptr [r15], 0x01
00007981ddfd17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007981ddfd17ed  mov r14d, [r15+0x320]
00007981ddfd17f4  mov eax, 0x4103F8
00007981ddfd17f9  mov rcx, 0x7981DDFD1860
00007981ddfd1803  mov [r15+r14*8+0x328], rax
00007981ddfd180b  mov [r15+r14*8+0x368], rcx
00007981ddfd1813  add r14d, 0x01
00007981ddfd1817  and r14d, 0x07
00007981ddfd181b  mov [r15+0x320], r14d
00007981ddfd1822  cmp dword ptr [r15+0x318], 0x00
00007981ddfd182a  jz 0x00007981DDFD0F20
00007981ddfd1830  nop [rax+rax*1], ax
00007981ddfd1839  nop [rax+rax*1], eax
00007981ddfd1841  mov eax, 0x4109A4
00007981ddfd1846  mov [r15+0x100], rax
00007981ddfd184d  jmp 0x00007981DDDFE110
00007981ddfd1852  int3
00007981ddfd1853  call 0x00007981DDEE2CE0
00007981ddfd1858  jmp 0x00007981DDFD17DB
00007981ddfd185d  int3
00007981ddfd185e  nop
00007981ddfd1860  mov eax, [r15+0x98]
00007981ddfd1867  lea r14d, [eax+0x01]
00007981ddfd186c  mov [rsp+0x10], r14d
00007981ddfd1871  mov r14d, r14d
00007981ddfd1874  mov [r15+0x98], r14
00007981ddfd187b  xor eax, eax
00007981ddfd187d  mov r14d, [rsp+0x10]
00007981ddfd1882  cmp r14d, 0x10000
00007981ddfd1889  cmc
00007981ddfd188a  lahf
00007981ddfd188b  seto al
00007981ddfd188e  mov [r15+0x108], eax
00007981ddfd1895  mov eax, [r15+0x108]
00007981ddfd189c  sahf
00007981ddfd189d  jnz 0x00007981DDFD18CF
00007981ddfd189f  cmp dword ptr [r15+0x318], 0x00
00007981ddfd18a7  jz 0x00007981DDFD19A0
00007981ddfd18ad  nop [rax+rax*1], ax
00007981ddfd18b6  nop [rax+rax*1], eax
00007981ddfd18be  mov eax, 0x410404
00007981ddfd18c3  mov [r15+0x100], rax
00007981ddfd18ca  jmp 0x00007981DDDFE110
00007981ddfd18cf  cmp dword ptr [r15+0x318], 0x00
00007981ddfd18d7  jz 0x00007981DDFD1910
00007981ddfd18dd  nop [rax+rax*1], ax
00007981ddfd18e6  nop [rax+rax*1], eax
00007981ddfd18ee  mov eax, 0x4103F0
00007981ddfd18f3  mov [r15+0x100], rax
00007981ddfd18fa  jmp 0x00007981DDDFE110
00007981ddfd18ff  int3
00007981ddfd1900  int3
00007981ddfd1901  nop [rax+rax*1], ax
00007981ddfd190a  nop [rax+rax*1], ax
00007981ddfd1910  mov eax, [r15]
00007981ddfd1913  mov r14d, [r15+0x98]
00007981ddfd191a  lea r12d, [eax+r14d*1]
00007981ddfd191f  mov r12d, r12d
00007981ddfd1922  mov [r15], r12
00007981ddfd1925  mov qword ptr [r15+0xF0], 0x4103F8
00007981ddfd1930  mov r14d, [r15+0x320]
00007981ddfd1937  mov eax, 0x4103F8
00007981ddfd193c  mov rcx, 0x7981DDFD1860
00007981ddfd1946  mov [r15+r14*8+0x328], rax
00007981ddfd194e  mov [r15+r14*8+0x368], rcx
00007981ddfd1956  add r14d, 0x01
00007981ddfd195a  and r14d, 0x07
00007981ddfd195e  mov [r15+0x320], r14d
00007981ddfd1965  cmp dword ptr [r15+0x318], 0x00
00007981ddfd196d  jz 0x00007981DDFD0F20
00007981ddfd1973  nop [rax+rax*1], ax
00007981ddfd197c  nop [rax+rax*1], eax
00007981ddfd1984  mov eax, 0x4109A4
00007981ddfd1989  mov [r15+0x100], rax
00007981ddfd1990  jmp 0x00007981DDDFE110
00007981ddfd1995  int3
00007981ddfd1996  int3
00007981ddfd1997  nop [rax+rax*1], ax
00007981ddfd19a0  vmovaps xmm1, [0x00007981DDBFE010]
00007981ddfd19a8  movq xmm1, xmm1
00007981ddfd19ac  movaps [r15+0x110], xmm1
00007981ddfd19b4  mov eax, 0x420B10
00007981ddfd19b9  mov r14, [r13+rax*1]
00007981ddfd19be  movq xmm1, r14
00007981ddfd19c3  movaps [r15+0x120], xmm1
00007981ddfd19cb  vmovaps xmm1, [0x00007981DDBFE020]
00007981ddfd19d3  movq xmm1, xmm1
00007981ddfd19d7  movaps [r15+0x140], xmm1
00007981ddfd19df  vmovaps xmm1, [0x00007981DDBFE030]
00007981ddfd19e7  vpbroadcastq xmm1, xmm1
00007981ddfd19ec  movaps [r15+0x150], xmm1
00007981ddfd19f4  mov qword ptr [r15+0x40], 0x02
00007981ddfd19fc  vmovaps xmm15, [0x00007981DDBFE040]
00007981ddfd1a04  movq xmm15, xmm15
00007981ddfd1a09  movaps [r15+0x160], xmm15
00007981ddfd1a11  vmovaps xmm15, [0x00007981DDBFE050]
00007981ddfd1a19  vpbroadcastq xmm15, xmm15
00007981ddfd1a1e  movaps [r15+0x130], xmm15
00007981ddfd1a26  mov rax, [r15+0x40]
00007981ddfd1a2a  vmovq xmm14, rax
00007981ddfd1a2f  vpbroadcastq xmm14, xmm14
00007981ddfd1a34  movaps [r15+0x170], xmm14
00007981ddfd1a3c  mov eax, 0x420A40
00007981ddfd1a41  movups xmm13, [r13+rax*1]
00007981ddfd1a47  mov qword ptr [r15+0x40], 0x431E00
00007981ddfd1a4f  mov eax, [r15]
00007981ddfd1a52  mov r14d, 0x430CB8
00007981ddfd1a58  mov [r13+r14*1], eax
00007981ddfd1a5d  mov qword ptr [r15+0x50], 0x432000
00007981ddfd1a65  vpmovqd xmm12, xmm13
00007981ddfd1a6b  pxor xmm11, xmm11
00007981ddfd1a70  punpcklqdq xmm12, xmm11
00007981ddfd1a75  movaps [r15+0x210], xmm12
00007981ddfd1a7d  movq xmm12, qword ptr [r15+0x140]
00007981ddfd1a86  movq xmm11, qword ptr [r15+0x120]
00007981ddfd1a8f  psubd xmm12, xmm11
00007981ddfd1a94  movq xmm12, xmm12
00007981ddfd1a99  paddq xmm13, xmm14
00007981ddfd1a9e  movaps [r15+0x180], xmm13
00007981ddfd1aa6  movq xmm14, qword ptr [r15+0x160]
00007981ddfd1aaf  paddd xmm11, xmm14
00007981ddfd1ab4  movq xmm11, xmm11
00007981ddfd1ab9  movq xmm11, xmm11
00007981ddfd1abe  movaps [r15+0x120], xmm11
00007981ddfd1ac6  pmovzxdq xmm12, xmm12
00007981ddfd1acc  psllq xmm12, 0x00
00007981ddfd1ad2  movq xmm14, qword ptr [r15+0x210]
00007981ddfd1adb  movq xmm13, qword ptr [r15+0x110]
00007981ddfd1ae4  paddd xmm14, xmm13
00007981ddfd1ae9  movq xmm14, xmm14
00007981ddfd1aee  vcvtuqq2pd xmm12, xmm12
00007981ddfd1af4  pmovzxdq xmm14, xmm14
00007981ddfd1afa  psllq xmm14, 0x00
00007981ddfd1b00  vcvtuqq2pd xmm14, xmm14
00007981ddfd1b06  movaps xmm13, xmm12
00007981ddfd1b0a  mulpd xmm13, xmm1
00007981ddfd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007981ddfd1b15  ptest xmm11, xmm11
00007981ddfd1b1b  jnz 0x00007981DDFD1C0F
00007981ddfd1b21  movaps [r15+0x220], xmm13
00007981ddfd1b29  mov eax, 0x432000
00007981ddfd1b2e  movups [r13+rax*1], xmm13
00007981ddfd1b34  movaps xmm1, xmm14
00007981ddfd1b38  mulpd xmm1, xmm15
00007981ddfd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007981ddfd1b42  ptest xmm13, xmm13
00007981ddfd1b48  jnz 0x00007981DDFD1D5C
00007981ddfd1b4e  movaps [r15+0x210], xmm1
00007981ddfd1b56  mov eax, 0x431E00
00007981ddfd1b5b  movups [r13+rax*1], xmm1
00007981ddfd1b61  mov qword ptr [r15+0x48], 0x10
00007981ddfd1b69  xor eax, eax
00007981ddfd1b6b  mov r14d, 0x10
00007981ddfd1b71  mov r12d, 0x200
00007981ddfd1b77  cmp r14, r12
00007981ddfd1b7a  cmc
00007981ddfd1b7b  lahf
00007981ddfd1b7c  seto al
00007981ddfd1b7f  mov [r15+0x108], eax
00007981ddfd1b86  mov eax, [r15+0x108]
00007981ddfd1b8d  sahf
00007981ddfd1b8e  jnz 0x00007981DDFD1BC0
00007981ddfd1b90  cmp dword ptr [r15+0x318], 0x00
00007981ddfd1b98  jz 0x00007981DDFD2300
00007981ddfd1b9e  nop [rax+rax*1], ax
00007981ddfd1ba7  nop [rax+rax*1], eax
00007981ddfd1baf  mov eax, 0x410490
00007981ddfd1bb4  mov [r15+0x100], rax
00007981ddfd1bbb  jmp 0x00007981DDDFE110
00007981ddfd1bc0  cmp dword ptr [r15+0x318], 0x00
00007981ddfd1bc8  jz 0x00007981DDFD1EB0
00007981ddfd1bce  nop [rax+rax*1], ax
00007981ddfd1bd7  nop [rax+rax*1], eax
00007981ddfd1bdf  mov eax, 0x410450
00007981ddfd1be4  mov [r15+0x100], rax
00007981ddfd1beb  jmp 0x00007981DDDFE110
00007981ddfd1bf0  int3
00007981ddfd1bf1  call 0x00007981DDE0DC20
00007981ddfd1bf6  jmp 0x00007981DDFD19BE
00007981ddfd1bfb  call 0x00007981DDE0C260
00007981ddfd1c00  jmp 0x00007981DDFD1A47
00007981ddfd1c05  call 0x00007981DDED5D70
00007981ddfd1c0a  jmp 0x00007981DDFD1A5D
00007981ddfd1c0f  sub rsp, 0x08
00007981ddfd1c13  push rax
00007981ddfd1c14  push rcx
00007981ddfd1c15  push rdx
00007981ddfd1c16  push rdi
00007981ddfd1c17  push rsi
00007981ddfd1c18  push r8
00007981ddfd1c1a  push r9
00007981ddfd1c1c  push r10
00007981ddfd1c1e  push r11
00007981ddfd1c20  sub rsp, 0xF0
00007981ddfd1c27  vmovaps [rsp], xmm0
00007981ddfd1c2c  vmovaps [rsp+0x10], xmm1
00007981ddfd1c32  vmovaps [rsp+0x20], xmm2
00007981ddfd1c38  vmovaps [rsp+0x30], xmm3
00007981ddfd1c3e  vmovaps [rsp+0x40], xmm4
00007981ddfd1c44  vmovaps [rsp+0x50], xmm5
00007981ddfd1c4a  vmovaps [rsp+0x60], xmm6
00007981ddfd1c50  vmovaps [rsp+0x70], xmm7
00007981ddfd1c56  vmovaps [rsp+0x80], xmm8
00007981ddfd1c5f  vmovaps [rsp+0x90], xmm9
00007981ddfd1c68  vmovaps [rsp+0xA0], xmm10
00007981ddfd1c71  vmovaps [rsp+0xB0], xmm11
00007981ddfd1c7a  vmovaps [rsp+0xC0], xmm12
00007981ddfd1c83  vmovaps [rsp+0xD0], xmm14
00007981ddfd1c8c  vmovaps [rsp+0xE0], xmm15
00007981ddfd1c95  sub rsp, 0x30
00007981ddfd1c99  movaps [rsp], xmm13
00007981ddfd1c9e  movaps [rsp+0x10], xmm12
00007981ddfd1ca4  movaps [rsp+0x20], xmm1
00007981ddfd1ca9  lea rdi, [rsp]
00007981ddfd1cad  mov esi, 0x00
00007981ddfd1cb2  mov rax, 0x5782A6EB3530
00007981ddfd1cbc  call rax
00007981ddfd1cbe  movaps xmm13, [rsp]
00007981ddfd1cc3  add rsp, 0x30
00007981ddfd1cc7  vmovaps xmm0, [rsp]
00007981ddfd1ccc  vmovaps xmm1, [rsp+0x10]
00007981ddfd1cd2  vmovaps xmm2, [rsp+0x20]
00007981ddfd1cd8  vmovaps xmm3, [rsp+0x30]
00007981ddfd1cde  vmovaps xmm4, [rsp+0x40]
00007981ddfd1ce4  vmovaps xmm5, [rsp+0x50]
00007981ddfd1cea  vmovaps xmm6, [rsp+0x60]
00007981ddfd1cf0  vmovaps xmm7, [rsp+0x70]
00007981ddfd1cf6  vmovaps xmm8, [rsp+0x80]
00007981ddfd1cff  vmovaps xmm9, [rsp+0x90]
00007981ddfd1d08  vmovaps xmm10, [rsp+0xA0]
00007981ddfd1d11  vmovaps xmm11, [rsp+0xB0]
00007981ddfd1d1a  vmovaps xmm12, [rsp+0xC0]
00007981ddfd1d23  vmovaps xmm14, [rsp+0xD0]
00007981ddfd1d2c  vmovaps xmm15, [rsp+0xE0]
00007981ddfd1d35  add rsp, 0xF0
00007981ddfd1d3c  pop r11
00007981ddfd1d3e  pop r10
00007981ddfd1d40  pop r9
00007981ddfd1d42  pop r8
00007981ddfd1d44  pop rsi
00007981ddfd1d45  pop rdi
00007981ddfd1d46  pop rdx
00007981ddfd1d47  pop rcx
00007981ddfd1d48  pop rax
00007981ddfd1d49  add rsp, 0x08
00007981ddfd1d4d  jmp 0x00007981DDFD1B21
00007981ddfd1d52  call 0x00007981DDE0C380
00007981ddfd1d57  jmp 0x00007981DDFD1B34
00007981ddfd1d5c  sub rsp, 0x08
00007981ddfd1d60  push rax
00007981ddfd1d61  push rcx
00007981ddfd1d62  push rdx
00007981ddfd1d63  push rdi
00007981ddfd1d64  push rsi
00007981ddfd1d65  push r8
00007981ddfd1d67  push r9
00007981ddfd1d69  push r10
00007981ddfd1d6b  push r11
00007981ddfd1d6d  sub rsp, 0xF0
00007981ddfd1d74  vmovaps [rsp], xmm0
00007981ddfd1d79  vmovaps [rsp+0x10], xmm2
00007981ddfd1d7f  vmovaps [rsp+0x20], xmm3
00007981ddfd1d85  vmovaps [rsp+0x30], xmm4
00007981ddfd1d8b  vmovaps [rsp+0x40], xmm5
00007981ddfd1d91  vmovaps [rsp+0x50], xmm6
00007981ddfd1d97  vmovaps [rsp+0x60], xmm7
00007981ddfd1d9d  vmovaps [rsp+0x70], xmm8
00007981ddfd1da3  vmovaps [rsp+0x80], xmm9
00007981ddfd1dac  vmovaps [rsp+0x90], xmm10
00007981ddfd1db5  vmovaps [rsp+0xA0], xmm11
00007981ddfd1dbe  vmovaps [rsp+0xB0], xmm12
00007981ddfd1dc7  vmovaps [rsp+0xC0], xmm13
00007981ddfd1dd0  vmovaps [rsp+0xD0], xmm14
00007981ddfd1dd9  vmovaps [rsp+0xE0], xmm15
00007981ddfd1de2  sub rsp, 0x30
00007981ddfd1de6  movaps [rsp], xmm1
00007981ddfd1dea  movaps [rsp+0x10], xmm14
00007981ddfd1df0  movaps [rsp+0x20], xmm15
00007981ddfd1df6  lea rdi, [rsp]
00007981ddfd1dfa  mov esi, 0x00
00007981ddfd1dff  mov rax, 0x5782A6EB3530
00007981ddfd1e09  call rax
00007981ddfd1e0b  movaps xmm1, [rsp]
00007981ddfd1e0f  add rsp, 0x30
00007981ddfd1e13  vmovaps xmm0, [rsp]
00007981ddfd1e18  vmovaps xmm2, [rsp+0x10]
00007981ddfd1e1e  vmovaps xmm3, [rsp+0x20]
00007981ddfd1e24  vmovaps xmm4, [rsp+0x30]
00007981ddfd1e2a  vmovaps xmm5, [rsp+0x40]
00007981ddfd1e30  vmovaps xmm6, [rsp+0x50]
00007981ddfd1e36  vmovaps xmm7, [rsp+0x60]
00007981ddfd1e3c  vmovaps xmm8, [rsp+0x70]
00007981ddfd1e42  vmovaps xmm9, [rsp+0x80]
00007981ddfd1e4b  vmovaps xmm10, [rsp+0x90]
00007981ddfd1e54  vmovaps xmm11, [rsp+0xA0]
00007981ddfd1e5d  vmovaps xmm12, [rsp+0xB0]
00007981ddfd1e66  vmovaps xmm13, [rsp+0xC0]
00007981ddfd1e6f  vmovaps xmm14, [rsp+0xD0]
00007981ddfd1e78  vmovaps xmm15, [rsp+0xE0]
00007981ddfd1e81  add rsp, 0xF0
00007981ddfd1e88  pop r11
00007981ddfd1e8a  pop r10
00007981ddfd1e8c  pop r9
00007981ddfd1e8e  pop r8
00007981ddfd1e90  pop rsi
00007981ddfd1e91  pop rdi
00007981ddfd1e92  pop rdx
00007981ddfd1e93  pop rcx
00007981ddfd1e94  pop rax
00007981ddfd1e95  add rsp, 0x08
00007981ddfd1e99  jmp 0x00007981DDFD1B4E
00007981ddfd1e9e  call 0x00007981DDDFF540
00007981ddfd1ea3  jmp 0x00007981DDFD1B61
00007981ddfd1ea8  int3
00007981ddfd1ea9  nop [rax], eax
00007981ddfd1eb0  movaps xmm1, [r15+0x180]
00007981ddfd1eb8  vpmovqd xmm15, xmm1
00007981ddfd1ebe  pxor xmm14, xmm14
00007981ddfd1ec3  punpcklqdq xmm15, xmm14
00007981ddfd1ec8  movaps [r15+0x210], xmm15
00007981ddfd1ed0  movq xmm15, qword ptr [r15+0x140]
00007981ddfd1ed9  movq xmm14, qword ptr [r15+0x120]
00007981ddfd1ee2  psubd xmm15, xmm14
00007981ddfd1ee7  movq xmm15, xmm15
00007981ddfd1eec  movaps xmm13, [r15+0x170]
00007981ddfd1ef4  paddq xmm1, xmm13
00007981ddfd1ef9  movaps [r15+0x180], xmm1
00007981ddfd1f01  movq xmm1, qword ptr [r15+0x160]
00007981ddfd1f0a  paddd xmm14, xmm1
00007981ddfd1f0f  movq xmm14, xmm14
00007981ddfd1f14  movq xmm14, xmm14
00007981ddfd1f19  movaps [r15+0x120], xmm14
00007981ddfd1f21  pmovzxdq xmm15, xmm15
00007981ddfd1f27  psllq xmm15, 0x00
00007981ddfd1f2d  movq xmm1, qword ptr [r15+0x210]
00007981ddfd1f36  movq xmm14, qword ptr [r15+0x110]
00007981ddfd1f3f  paddd xmm1, xmm14
00007981ddfd1f44  movq xmm1, xmm1
00007981ddfd1f48  vcvtuqq2pd xmm15, xmm15
00007981ddfd1f4e  pmovzxdq xmm1, xmm1
00007981ddfd1f53  psllq xmm1, 0x00
00007981ddfd1f58  vcvtuqq2pd xmm1, xmm1
00007981ddfd1f5e  movaps xmm14, [r15+0x150]
00007981ddfd1f66  movaps xmm13, xmm15
00007981ddfd1f6a  mulpd xmm13, xmm14
00007981ddfd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007981ddfd1f75  ptest xmm12, xmm12
00007981ddfd1f7b  jnz 0x00007981DDFD205E
00007981ddfd1f81  movaps [r15+0x220], xmm13
00007981ddfd1f89  mov rax, [r15+0x48]
00007981ddfd1f8d  mov r14, [r15+0x50]
00007981ddfd1f91  lea r12, [r14+rax*1]
00007981ddfd1f95  movups [r13+r12*1], xmm13
00007981ddfd1f9b  movaps xmm15, [r15+0x130]
00007981ddfd1fa3  movaps xmm14, xmm1
00007981ddfd1fa7  mulpd xmm14, xmm15
00007981ddfd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007981ddfd1fb2  ptest xmm13, xmm13
00007981ddfd1fb8  jnz 0x00007981DDFD21AC
00007981ddfd1fbe  movaps [r15+0x210], xmm14
00007981ddfd1fc6  mov r14, [r15+0x40]
00007981ddfd1fca  lea r12, [r14+rax*1]
00007981ddfd1fce  movups [r13+r12*1], xmm14
00007981ddfd1fd4  lea r14, [rax+0x10]
00007981ddfd1fd8  mov [r15+0x48], r14
00007981ddfd1fdc  xor eax, eax
00007981ddfd1fde  mov r12d, 0x200
00007981ddfd1fe4  cmp r14, r12
00007981ddfd1fe7  cmc
00007981ddfd1fe8  lahf
00007981ddfd1fe9  seto al
00007981ddfd1fec  mov [r15+0x108], eax
00007981ddfd1ff3  mov eax, [r15+0x108]
00007981ddfd1ffa  sahf
00007981ddfd1ffb  jnz 0x00007981DDFD202D
00007981ddfd1ffd  cmp dword ptr [r15+0x318], 0x00
00007981ddfd2005  jz 0x00007981DDFD2300
00007981ddfd200b  nop [rax+rax*1], ax
00007981ddfd2014  nop [rax+rax*1], eax
00007981ddfd201c  mov eax, 0x410490
00007981ddfd2021  mov [r15+0x100], rax
00007981ddfd2028  jmp 0x00007981DDDFE110
00007981ddfd202d  cmp dword ptr [r15+0x318], 0x00
00007981ddfd2035  jz 0x00007981DDFD1EB0
00007981ddfd203b  nop [rax+rax*1], ax
00007981ddfd2044  nop [rax+rax*1], eax
00007981ddfd204c  mov eax, 0x410450
00007981ddfd2051  mov [r15+0x100], rax
00007981ddfd2058  jmp 0x00007981DDDFE110
00007981ddfd205d  int3
00007981ddfd205e  sub rsp, 0x08
00007981ddfd2062  push rax
00007981ddfd2063  push rcx
00007981ddfd2064  push rdx
00007981ddfd2065  push rdi
00007981ddfd2066  push rsi
00007981ddfd2067  push r8
00007981ddfd2069  push r9
00007981ddfd206b  push r10
00007981ddfd206d  push r11
00007981ddfd206f  sub rsp, 0xF0
00007981ddfd2076  vmovaps [rsp], xmm0
00007981ddfd207b  vmovaps [rsp+0x10], xmm1
00007981ddfd2081  vmovaps [rsp+0x20], xmm2
00007981ddfd2087  vmovaps [rsp+0x30], xmm3
00007981ddfd208d  vmovaps [rsp+0x40], xmm4
00007981ddfd2093  vmovaps [rsp+0x50], xmm5
00007981ddfd2099  vmovaps [rsp+0x60], xmm6
00007981ddfd209f  vmovaps [rsp+0x70], xmm7
00007981ddfd20a5  vmovaps [rsp+0x80], xmm8
00007981ddfd20ae  vmovaps [rsp+0x90], xmm9
00007981ddfd20b7  vmovaps [rsp+0xA0], xmm10
00007981ddfd20c0  vmovaps [rsp+0xB0], xmm11
00007981ddfd20c9  vmovaps [rsp+0xC0], xmm12
00007981ddfd20d2  vmovaps [rsp+0xD0], xmm14
00007981ddfd20db  vmovaps [rsp+0xE0], xmm15
00007981ddfd20e4  sub rsp, 0x30
00007981ddfd20e8  movaps [rsp], xmm13
00007981ddfd20ed  movaps [rsp+0x10], xmm15
00007981ddfd20f3  movaps [rsp+0x20], xmm14
00007981ddfd20f9  lea rdi, [rsp]
00007981ddfd20fd  mov esi, 0x00
00007981ddfd2102  mov rax, 0x5782A6EB3530
00007981ddfd210c  call rax
00007981ddfd210e  movaps xmm13, [rsp]
00007981ddfd2113  add rsp, 0x30
00007981ddfd2117  vmovaps xmm0, [rsp]
00007981ddfd211c  vmovaps xmm1, [rsp+0x10]
00007981ddfd2122  vmovaps xmm2, [rsp+0x20]
00007981ddfd2128  vmovaps xmm3, [rsp+0x30]
00007981ddfd212e  vmovaps xmm4, [rsp+0x40]
00007981ddfd2134  vmovaps xmm5, [rsp+0x50]
00007981ddfd213a  vmovaps xmm6, [rsp+0x60]
00007981ddfd2140  vmovaps xmm7, [rsp+0x70]
00007981ddfd2146  vmovaps xmm8, [rsp+0x80]
00007981ddfd214f  vmovaps xmm9, [rsp+0x90]
00007981ddfd2158  vmovaps xmm10, [rsp+0xA0]
00007981ddfd2161  vmovaps xmm11, [rsp+0xB0]
00007981ddfd216a  vmovaps xmm12, [rsp+0xC0]
00007981ddfd2173  vmovaps xmm14, [rsp+0xD0]
00007981ddfd217c  vmovaps xmm15, [rsp+0xE0]
00007981ddfd2185  add rsp, 0xF0
00007981ddfd218c  pop r11
00007981ddfd218e  pop r10
00007981ddfd2190  pop r9
00007981ddfd2192  pop r8
00007981ddfd2194  pop rsi
00007981ddfd2195  pop rdi
00007981ddfd2196  pop rdx
00007981ddfd2197  pop rcx
00007981ddfd2198  pop rax
00007981ddfd2199  add rsp, 0x08
00007981ddfd219d  jmp 0x00007981DDFD1F81
00007981ddfd21a2  call 0x00007981DDEC2240
00007981ddfd21a7  jmp 0x00007981DDFD1F9B
00007981ddfd21ac  sub rsp, 0x08
00007981ddfd21b0  push rax
00007981ddfd21b1  push rcx
00007981ddfd21b2  push rdx
00007981ddfd21b3  push rdi
00007981ddfd21b4  push rsi
00007981ddfd21b5  push r8
00007981ddfd21b7  push r9
00007981ddfd21b9  push r10
00007981ddfd21bb  push r11
00007981ddfd21bd  sub rsp, 0xF0
00007981ddfd21c4  vmovaps [rsp], xmm0
00007981ddfd21c9  vmovaps [rsp+0x10], xmm1
00007981ddfd21cf  vmovaps [rsp+0x20], xmm2
00007981ddfd21d5  vmovaps [rsp+0x30], xmm3
00007981ddfd21db  vmovaps [rsp+0x40], xmm4
00007981ddfd21e1  vmovaps [rsp+0x50], xmm5
00007981ddfd21e7  vmovaps [rsp+0x60], xmm6
00007981ddfd21ed  vmovaps [rsp+0x70], xmm7
00007981ddfd21f3  vmovaps [rsp+0x80], xmm8
00007981ddfd21fc  vmovaps [rsp+0x90], xmm9
00007981ddfd2205  vmovaps [rsp+0xA0], xmm10
00007981ddfd220e  vmovaps [rsp+0xB0], xmm11
00007981ddfd2217  vmovaps [rsp+0xC0], xmm12
00007981ddfd2220  vmovaps [rsp+0xD0], xmm13
00007981ddfd2229  vmovaps [rsp+0xE0], xmm15
00007981ddfd2232  sub rsp, 0x30
00007981ddfd2236  movaps [rsp], xmm14
00007981ddfd223b  movaps [rsp+0x10], xmm1
00007981ddfd2240  movaps [rsp+0x20], xmm15
00007981ddfd2246  lea rdi, [rsp]
00007981ddfd224a  mov esi, 0x00
00007981ddfd224f  mov rax, 0x5782A6EB3530
00007981ddfd2259  call rax
00007981ddfd225b  movaps xmm14, [rsp]
00007981ddfd2260  add rsp, 0x30
00007981ddfd2264  vmovaps xmm0, [rsp]
00007981ddfd2269  vmovaps xmm1, [rsp+0x10]
00007981ddfd226f  vmovaps xmm2, [rsp+0x20]
00007981ddfd2275  vmovaps xmm3, [rsp+0x30]
00007981ddfd227b  vmovaps xmm4, [rsp+0x40]
00007981ddfd2281  vmovaps xmm5, [rsp+0x50]
00007981ddfd2287  vmovaps xmm6, [rsp+0x60]
00007981ddfd228d  vmovaps xmm7, [rsp+0x70]
00007981ddfd2293  vmovaps xmm8, [rsp+0x80]
00007981ddfd229c  vmovaps xmm9, [rsp+0x90]
00007981ddfd22a5  vmovaps xmm10, [rsp+0xA0]
00007981ddfd22ae  vmovaps xmm11, [rsp+0xB0]
00007981ddfd22b7  vmovaps xmm12, [rsp+0xC0]
00007981ddfd22c0  vmovaps xmm13, [rsp+0xD0]
00007981ddfd22c9  vmovaps xmm15, [rsp+0xE0]
00007981ddfd22d2  add rsp, 0xF0
00007981ddfd22d9  pop r11
00007981ddfd22db  pop r10
00007981ddfd22dd  pop r9
00007981ddfd22df  pop r8
00007981ddfd22e1  pop rsi
00007981ddfd22e2  pop rdi
00007981ddfd22e3  pop rdx
00007981ddfd22e4  pop rcx
00007981ddfd22e5  pop rax
00007981ddfd22e6  add rsp, 0x08
00007981ddfd22ea  jmp 0x00007981DDFD1FBE
00007981ddfd22ef  call 0x00007981DDEC34C0
00007981ddfd22f4  jmp 0x00007981DDFD1FD4
00007981ddfd22f9  int3
00007981ddfd22fa  nop [rax+rax*1], ax
00007981ddfd2300  mov rax, [r15+0x50]
00007981ddfd2304  lea r14, [rax+0x80]
00007981ddfd230b  movups xmm1, [r13+r14*1]
00007981ddfd2311  lea r14, [rax+0x90]
00007981ddfd2318  movups xmm15, [r13+r14*1]
00007981ddfd231e  vxorps xmm14, xmm14, xmm14
00007981ddfd2323  vpbroadcastq xmm14, xmm14
00007981ddfd2328  lea r14, [rax+0x40]
00007981ddfd232c  movups xmm13, [r13+r14*1]
00007981ddfd2332  lea r14, [rax+0x50]
00007981ddfd2336  movups xmm12, [r13+r14*1]
00007981ddfd233c  mov qword ptr [r15+0x48], 0x00
00007981ddfd2344  movups xmm11, [r13+rax*1]
00007981ddfd234a  lea r14, [rax+0x10]
00007981ddfd234e  movups xmm10, [r13+r14*1]
00007981ddfd2354  mov r14, [r15+0xF8]
00007981ddfd235b  lea r12, [r14+0xE0]
00007981ddfd2362  movups [r13+r12*1], xmm15
00007981ddfd2368  lea r12, [r14+0xF0]
00007981ddfd236f  movups [r13+r12*1], xmm1
00007981ddfd2375  lea r12, [rax+0xC0]
00007981ddfd237c  movups xmm1, [r13+r12*1]
00007981ddfd2382  lea r12, [rax+0xD0]
00007981ddfd2389  movups xmm15, [r13+r12*1]
00007981ddfd238f  lea r12, [rax+0x140]
00007981ddfd2396  movups xmm9, [r13+r12*1]
00007981ddfd239c  lea r12, [rax+0x150]
00007981ddfd23a3  movups xmm8, [r13+r12*1]
00007981ddfd23a9  lea r12, [rax+0x180]
00007981ddfd23b0  movups xmm7, [r13+r12*1]
00007981ddfd23b6  lea r12, [rax+0x190]
00007981ddfd23bd  movups xmm6, [r13+r12*1]
00007981ddfd23c3  lea r12, [r14+0xC0]
00007981ddfd23ca  movups [r13+r12*1], xmm15
00007981ddfd23d0  lea r12, [r14+0xD0]
00007981ddfd23d7  movups [r13+r12*1], xmm1
00007981ddfd23dd  lea r12, [rax+0x100]
00007981ddfd23e4  movups xmm1, [r13+r12*1]
00007981ddfd23ea  lea r12, [rax+0x110]
00007981ddfd23f1  movups xmm15, [r13+r12*1]
00007981ddfd23f7  lea r12, [rax+0x1C0]
00007981ddfd23fe  movups xmm5, [r13+r12*1]
00007981ddfd2404  lea r12, [rax+0x1D0]
00007981ddfd240b  movups xmm4, [r13+r12*1]
00007981ddfd2411  lea r12, [rax+0x20]
00007981ddfd2415  movups xmm3, [r13+r12*1]
00007981ddfd241b  lea r12, [rax+0x30]
00007981ddfd241f  movups xmm2, [r13+r12*1]
00007981ddfd2425  movaps [r15+0x1F0], xmm2
00007981ddfd242d  lea r12, [r14+0x20]
00007981ddfd2431  movups [r13+r12*1], xmm1
00007981ddfd2437  lea r12, [r14+0x30]
00007981ddfd243b  movups [r13+r12*1], xmm12
00007981ddfd2441  lea r12, [rax+0x60]
00007981ddfd2445  movups xmm1, [r13+r12*1]
00007981ddfd244b  lea r12, [rax+0x70]
00007981ddfd244f  movups xmm12, [r13+r12*1]
00007981ddfd2455  lea r12, [r14+0x60]
00007981ddfd2459  movups [r13+r12*1], xmm11
00007981ddfd245f  lea r12, [r14+0x70]
00007981ddfd2463  movups [r13+r12*1], xmm5
00007981ddfd2469  lea r12, [rax+0xE0]
00007981ddfd2470  movups xmm11, [r13+r12*1]
00007981ddfd2476  lea r12, [rax+0xF0]
00007981ddfd247d  movups xmm5, [r13+r12*1]
00007981ddfd2483  lea r12, [rax+0x120]
00007981ddfd248a  vmovaps [rsp+0x10], xmm1
00007981ddfd2490  movups xmm1, [r13+r12*1]
00007981ddfd2496  lea r12, [rax+0x130]
00007981ddfd249d  vmovaps [rsp+0x20], xmm1
00007981ddfd24a3  movups xmm1, [r13+r12*1]
00007981ddfd24a9  lea r12, [r14+0xA0]
00007981ddfd24b0  movups [r13+r12*1], xmm12
00007981ddfd24b6  lea r12, [r14+0xB0]
00007981ddfd24bd  vmovaps xmm12, [rsp+0x10]
00007981ddfd24c3  movups [r13+r12*1], xmm12
00007981ddfd24c9  lea r12, [rax+0xA0]
00007981ddfd24d0  movups xmm12, [r13+r12*1]
00007981ddfd24d6  lea r12, [rax+0xB0]
00007981ddfd24dd  vmovaps [rsp+0x10], xmm1
00007981ddfd24e3  movups xmm1, [r13+r12*1]
00007981ddfd24e9  lea r12, [rax+0x160]
00007981ddfd24f0  vmovaps [rsp+0x30], xmm1
00007981ddfd24f6  movups xmm1, [r13+r12*1]
00007981ddfd24fc  lea r12, [rax+0x170]
00007981ddfd2503  vmovaps [rsp+0x40], xmm1
00007981ddfd2509  movups xmm1, [r13+r12*1]
00007981ddfd250f  movaps [r15+0x2B0], xmm1
00007981ddfd2517  lea r12, [rax+0x1A0]
00007981ddfd251e  vmovaps [rsp+0x50], xmm1
00007981ddfd2524  movups xmm1, [r13+r12*1]
00007981ddfd252a  lea r12, [rax+0x1B0]
00007981ddfd2531  vmovaps [rsp+0x60], xmm1
00007981ddfd2537  movups xmm1, [r13+r12*1]
00007981ddfd253d  vmovaps [rsp+0x70], xmm1
00007981ddfd2543  vmovaps xmm1, [rsp+0x60]
00007981ddfd2549  movaps [r15+0x290], xmm1
00007981ddfd2551  vmovaps [rsp+0x60], xmm1
00007981ddfd2557  vmovaps xmm1, [rsp+0x70]
00007981ddfd255d  movaps [r15+0x1E0], xmm1
00007981ddfd2565  lea r12, [r14+0x80]
00007981ddfd256c  vmovaps [rsp+0x70], xmm1
00007981ddfd2572  vmovaps xmm1, [rsp+0x30]
00007981ddfd2578  movups [r13+r12*1], xmm1
00007981ddfd257e  lea r12, [r14+0x90]
00007981ddfd2585  movups [r13+r12*1], xmm12
00007981ddfd258b  lea r12, [rax+0x1E0]
00007981ddfd2592  movups xmm1, [r13+r12*1]
00007981ddfd2598  lea r12, [rax+0x1F0]
00007981ddfd259f  movups xmm12, [r13+r12*1]
00007981ddfd25a5  mov qword ptr [r15+0x50], 0x432200
00007981ddfd25ad  lea rax, [r14+0x40]
00007981ddfd25b1  vmovaps [rsp+0x30], xmm1
00007981ddfd25b7  vmovaps xmm1, [rsp+0x40]
00007981ddfd25bd  movups [r13+rax*1], xmm1
00007981ddfd25c3  lea rax, [r14+0x50]
00007981ddfd25c7  movups [r13+rax*1], xmm10
00007981ddfd25cd  movups [r13+r14*1], xmm12
00007981ddfd25d3  lea rax, [r14+0x10]
00007981ddfd25d7  vmovaps xmm1, [rsp+0x30]
00007981ddfd25dd  movups [r13+rax*1], xmm1
00007981ddfd25e3  mov rax, [r15+0x40]
00007981ddfd25e7  vmovaps [rsp+0x30], xmm3
00007981ddfd25ed  vmovaps xmm1, [rsp+0x30]
00007981ddfd25f3  por xmm3, xmm1
00007981ddfd25f7  vmovaps [rsp+0x30], xmm6
00007981ddfd25fd  vmovaps xmm12, [rsp+0x30]
00007981ddfd2603  por xmm6, xmm12
00007981ddfd2608  lea r12, [rax+0x30]
00007981ddfd260c  mov r11, [r13+r12*1]
00007981ddfd2611  lea r12, [rax+0x38]
00007981ddfd2615  mov r10, [r13+r12*1]
00007981ddfd261a  movq xmm12, r11
00007981ddfd261f  movq xmm10, r10
00007981ddfd2624  movq xmm12, xmm12
00007981ddfd2629  vmovaps [rsp+0x30], xmm12
00007981ddfd262f  movq xmm12, xmm12
00007981ddfd2634  movaps [r15+0x130], xmm12
00007981ddfd263c  movq xmm10, xmm10
00007981ddfd2641  vmovaps [rsp+0x40], xmm10
00007981ddfd2647  movq xmm10, xmm10
00007981ddfd264c  movaps [r15+0x280], xmm10
00007981ddfd2654  vmovaps [rsp+0x80], xmm9
00007981ddfd265d  vmovaps xmm12, [rsp+0x80]
00007981ddfd2666  por xmm9, xmm12
00007981ddfd266b  lea r12, [rax+0x20]
00007981ddfd266f  mov r11, [r13+r12*1]
00007981ddfd2674  lea r12, [rax+0x28]
00007981ddfd2678  mov r10, [r13+r12*1]
00007981ddfd267d  movq xmm12, r11
00007981ddfd2682  movq xmm10, r10
00007981ddfd2687  movq xmm12, xmm12
00007981ddfd268c  vmovaps [rsp+0x80], xmm12
00007981ddfd2695  movq xmm12, xmm12
00007981ddfd269a  movaps [r15+0x150], xmm12
00007981ddfd26a2  movq xmm10, xmm10
00007981ddfd26a7  vmovaps [rsp+0x90], xmm10
00007981ddfd26b0  movq xmm10, xmm10
00007981ddfd26b5  movaps [r15+0x140], xmm10
00007981ddfd26bd  lea r12, [rax+0x10]
00007981ddfd26c1  mov r11, [r13+r12*1]
00007981ddfd26c6  lea r12, [rax+0x18]
00007981ddfd26ca  mov r10, [r13+r12*1]
00007981ddfd26cf  movq xmm12, r11
00007981ddfd26d4  movq xmm10, r10
00007981ddfd26d9  movq xmm12, xmm12
00007981ddfd26de  vmovaps [rsp+0xA0], xmm12
00007981ddfd26e7  movq xmm12, xmm12
00007981ddfd26ec  movaps [r15+0x170], xmm12
00007981ddfd26f4  movq xmm10, xmm10
00007981ddfd26f9  vmovaps [rsp+0xB0], xmm10
00007981ddfd2702  movq xmm10, xmm10
00007981ddfd2707  movaps [r15+0x160], xmm10
00007981ddfd270f  mov r12, [r13+rax*1]
00007981ddfd2714  vmovq xmm12, r12
00007981ddfd2719  vpbroadcastq xmm12, xmm12
00007981ddfd271e  lea r12, [rax+0x08]
00007981ddfd2722  mov rax, [r13+r12*1]
00007981ddfd2727  movq xmm10, rax
00007981ddfd272c  movaps [r15+0x230], xmm10
00007981ddfd2734  lea rax, [r14+0x50]
00007981ddfd2738  movups xmm10, [r13+rax*1]
00007981ddfd273e  lea rax, [r14+0x60]
00007981ddfd2742  vmovaps [rsp+0xC0], xmm1
00007981ddfd274b  movups xmm1, [r13+rax*1]
00007981ddfd2751  lea rax, [r14+0x30]
00007981ddfd2755  vmovaps [rsp+0xD0], xmm1
00007981ddfd275e  movups xmm1, [r13+rax*1]
00007981ddfd2764  mov qword ptr [r15+0x60], 0x432200
00007981ddfd276c  mov qword ptr [r15+0x58], 0x40
00007981ddfd2774  vmovaps [rsp+0xE0], xmm1
00007981ddfd277d  vmovaps [rsp+0xF0], xmm15
00007981ddfd2786  vmovaps xmm15, [rsp+0xC0]
00007981ddfd278f  vmovaps [rsp+0xC0], xmm14
00007981ddfd2798  movaps xmm1, xmm12
00007981ddfd279c  mulpd xmm1, xmm15
00007981ddfd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007981ddfd27a6  ptest xmm14, xmm14
00007981ddfd27ac  jnz 0x00007981DDFD3863
00007981ddfd27b2  movq xmm15, qword ptr [r15+0x230]
00007981ddfd27bb  vmovaps [rsp+0x100], xmm15
00007981ddfd27c4  vpermilpd xmm15, xmm15, 0x00
00007981ddfd27ca  vmovaps [rsp+0x110], xmm1
00007981ddfd27d3  vmovaps xmm1, [rsp+0xE0]
00007981ddfd27dc  vmovaps [rsp+0xE0], xmm13
00007981ddfd27e5  movaps xmm14, xmm1
00007981ddfd27e9  mulpd xmm14, xmm15
00007981ddfd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007981ddfd27f4  ptest xmm13, xmm13
00007981ddfd27fa  jnz 0x00007981DDFD39A5
00007981ddfd2800  vxorps xmm1, xmm1, xmm1
00007981ddfd2804  vpbroadcastq xmm1, xmm1
00007981ddfd2809  vmovaps xmm13, [rsp+0xD0]
00007981ddfd2812  vmovaps [rsp+0xD0], xmm1
00007981ddfd281b  movaps xmm15, xmm12
00007981ddfd281f  mulpd xmm15, xmm13
00007981ddfd2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007981ddfd282a  ptest xmm1, xmm1
00007981ddfd282f  jnz 0x00007981DDFD3AE8
00007981ddfd2835  movaps xmm1, xmm12
00007981ddfd2839  mulpd xmm1, xmm10
00007981ddfd283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007981ddfd2843  ptest xmm13, xmm13
00007981ddfd2849  jnz 0x00007981DDFD3C2C
00007981ddfd284f  movaps xmm13, xmm12
00007981ddfd2853  mulpd xmm13, xmm2
00007981ddfd2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007981ddfd285e  ptest xmm10, xmm10
00007981ddfd2864  jnz 0x00007981DDFD3D6E
00007981ddfd286a  vmovaps [rsp+0x120], xmm7
00007981ddfd2873  vmovaps xmm12, [rsp+0x120]
00007981ddfd287c  por xmm7, xmm12
00007981ddfd2881  vmovaps xmm12, [rsp+0xE0]
00007981ddfd288a  vmovaps xmm10, [rsp+0xE0]
00007981ddfd2893  por xmm12, xmm10
00007981ddfd2898  vmovaps xmm2, [rsp+0x100]
00007981ddfd28a1  vpermilpd xmm2, xmm2, 0x00
00007981ddfd28a7  vmovaps [rsp+0xE0], xmm1
00007981ddfd28b0  vmovaps [rsp+0x120], xmm15
00007981ddfd28b9  movaps xmm1, xmm10
00007981ddfd28bd  mulpd xmm1, xmm2
00007981ddfd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007981ddfd28c6  ptest xmm15, xmm15
00007981ddfd28cc  jnz 0x00007981DDFD3EB1
00007981ddfd28d2  xor eax, eax
00007981ddfd28d4  mov r12d, 0x40
00007981ddfd28da  mov r11d, 0x200
00007981ddfd28e0  cmp r12, r11
00007981ddfd28e3  cmc
00007981ddfd28e4  lahf
00007981ddfd28e5  seto al
00007981ddfd28e8  mov [r15+0x108], eax
00007981ddfd28ef  vmovaps xmm10, [rsp+0x110]
00007981ddfd28f8  vmovaps xmm2, [rsp+0xD0]
00007981ddfd2901  vmovaps [rsp+0xD0], xmm1
00007981ddfd290a  movaps xmm15, xmm10
00007981ddfd290e  addpd xmm15, xmm2
00007981ddfd2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007981ddfd2919  ptest xmm1, xmm1
00007981ddfd291e  jnz 0x00007981DDFD3FF2
00007981ddfd2924  vmovaps xmm10, [rsp+0x120]
00007981ddfd292d  vmovaps [rsp+0x110], xmm15
00007981ddfd2936  vmovaps xmm15, [rsp+0xC0]
00007981ddfd293f  vmovaps [rsp+0xC0], xmm14
00007981ddfd2948  movaps xmm1, xmm10
00007981ddfd294c  addpd xmm1, xmm15
00007981ddfd2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007981ddfd2956  ptest xmm14, xmm14
00007981ddfd295c  jnz 0x00007981DDFD4135
00007981ddfd2962  vmovaps xmm10, [rsp+0xE0]
00007981ddfd296b  vmovaps [rsp+0xE0], xmm1
00007981ddfd2974  movaps xmm14, xmm10
00007981ddfd2978  addpd xmm14, xmm15
00007981ddfd297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007981ddfd2983  ptest xmm1, xmm1
00007981ddfd2988  jnz 0x00007981DDFD4277
00007981ddfd298e  vmovaps xmm1, [rsp+0x10]
00007981ddfd2994  vmovaps xmm15, [rsp+0x10]
00007981ddfd299a  por xmm1, xmm15
00007981ddfd299f  vmovaps xmm15, [rsp+0x20]
00007981ddfd29a5  vmovaps xmm10, [rsp+0x20]
00007981ddfd29ab  por xmm15, xmm10
00007981ddfd29b0  vmovaps [rsp+0x10], xmm5
00007981ddfd29b6  vmovaps xmm10, [rsp+0x10]
00007981ddfd29bc  por xmm5, xmm10
00007981ddfd29c1  vmovaps [rsp+0x10], xmm11
00007981ddfd29c7  vmovaps xmm10, [rsp+0x10]
00007981ddfd29cd  por xmm11, xmm10
00007981ddfd29d2  vmovaps [rsp+0x10], xmm4
00007981ddfd29d8  vmovaps xmm10, [rsp+0x10]
00007981ddfd29de  por xmm4, xmm10
00007981ddfd29e3  vmovaps [rsp+0x10], xmm8
00007981ddfd29e9  vmovaps xmm10, [rsp+0x10]
00007981ddfd29ef  por xmm8, xmm10
00007981ddfd29f4  vmovaps xmm10, [rsp+0xF0]
00007981ddfd29fd  vmovaps [rsp+0x10], xmm1
00007981ddfd2a03  vmovaps xmm1, [rsp+0xF0]
00007981ddfd2a0c  por xmm10, xmm1
00007981ddfd2a11  lea rax, [r14+0xA0]
00007981ddfd2a18  movups xmm1, [r13+rax*1]
00007981ddfd2a1e  lea rax, [r14+0xB0]
00007981ddfd2a25  vmovaps [rsp+0x20], xmm1
00007981ddfd2a2b  movups xmm1, [r13+rax*1]
00007981ddfd2a31  vmovaps [rsp+0xF0], xmm1
00007981ddfd2a3a  vmovaps [rsp+0x120], xmm15
00007981ddfd2a43  movaps xmm1, xmm13
00007981ddfd2a47  addpd xmm1, xmm2
00007981ddfd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007981ddfd2a50  ptest xmm15, xmm15
00007981ddfd2a56  jnz 0x00007981DDFD43CF
00007981ddfd2a5c  lea rax, [r14+0xF0]
00007981ddfd2a63  movups xmm15, [r13+rax*1]
00007981ddfd2a69  vmovaps xmm2, [rsp+0xE0]
00007981ddfd2a72  vmovaps [rsp+0xE0], xmm1
00007981ddfd2a7b  vmovaps xmm1, [rsp+0xD0]
00007981ddfd2a84  vmovaps [rsp+0xD0], xmm15
00007981ddfd2a8d  movaps xmm13, xmm2
00007981ddfd2a91  addpd xmm13, xmm1
00007981ddfd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007981ddfd2a9c  ptest xmm15, xmm15
00007981ddfd2aa2  jnz 0x00007981DDFD451A
00007981ddfd2aa8  vmovaps xmm15, [rsp+0xC0]
00007981ddfd2ab1  movaps xmm1, xmm14
00007981ddfd2ab5  addpd xmm1, xmm15
00007981ddfd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007981ddfd2abf  ptest xmm2, xmm2
00007981ddfd2ac4  jnz 0x00007981DDFD465C
00007981ddfd2aca  vmovaps xmm15, [rsp+0x100]
00007981ddfd2ad3  vpermilpd xmm15, xmm15, 0x00
00007981ddfd2ad9  vmovaps xmm2, [rsp+0xF0]
00007981ddfd2ae2  vmovaps [rsp+0xC0], xmm1
00007981ddfd2aeb  movaps xmm14, xmm2
00007981ddfd2aef  mulpd xmm14, xmm15
00007981ddfd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007981ddfd2afa  ptest xmm1, xmm1
00007981ddfd2aff  jnz 0x00007981DDFD479E
00007981ddfd2b05  vmovaps xmm1, [rsp+0xA0]
00007981ddfd2b0e  vpermilpd xmm1, xmm1, 0x00
00007981ddfd2b14  vmovaps xmm2, [rsp+0xD0]
00007981ddfd2b1d  vmovaps [rsp+0xD0], xmm14
00007981ddfd2b26  movaps xmm15, xmm2
00007981ddfd2b2a  mulpd xmm15, xmm1
00007981ddfd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007981ddfd2b35  ptest xmm14, xmm14
00007981ddfd2b3b  jnz 0x00007981DDFD48E1
00007981ddfd2b41  lea rax, [r14+0xE0]
00007981ddfd2b48  movups xmm1, [r13+rax*1]
00007981ddfd2b4e  vmovaps xmm14, [rsp+0x100]
00007981ddfd2b57  vpermilpd xmm14, xmm14, 0x00
00007981ddfd2b5d  vmovaps [rsp+0xF0], xmm1
00007981ddfd2b66  vmovaps xmm1, [rsp+0x20]
00007981ddfd2b6c  vmovaps [rsp+0x20], xmm15
00007981ddfd2b72  movaps xmm2, xmm1
00007981ddfd2b75  mulpd xmm2, xmm14
00007981ddfd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007981ddfd2b7f  ptest xmm15, xmm15
00007981ddfd2b85  jnz 0x00007981DDFD4A2D
00007981ddfd2b8b  vmovaps [rsp+0x100], xmm10
00007981ddfd2b94  vmovaps xmm1, [rsp+0x100]
00007981ddfd2b9d  por xmm10, xmm1
00007981ddfd2ba2  movaps [r15+0x300], xmm10
00007981ddfd2baa  vmovaps [rsp+0x100], xmm8
00007981ddfd2bb3  vmovaps xmm1, [rsp+0x100]
00007981ddfd2bbc  por xmm8, xmm1
00007981ddfd2bc1  movaps [r15+0x190], xmm8
00007981ddfd2bc9  vmovaps xmm1, [rsp+0xA0]
00007981ddfd2bd2  vpermilpd xmm1, xmm1, 0x00
00007981ddfd2bd8  vmovaps xmm14, [rsp+0xF0]
00007981ddfd2be1  vmovaps [rsp+0xF0], xmm13
00007981ddfd2bea  movaps xmm15, xmm14
00007981ddfd2bee  mulpd xmm15, xmm1
00007981ddfd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007981ddfd2bf9  ptest xmm13, xmm13
00007981ddfd2bff  jnz 0x00007981DDFD4B6E
00007981ddfd2c05  lea rax, [r14+0x90]
00007981ddfd2c0c  movups xmm1, [r13+rax*1]
00007981ddfd2c12  vmovaps [rsp+0x100], xmm4
00007981ddfd2c1b  vmovaps xmm14, [rsp+0x100]
00007981ddfd2c24  por xmm4, xmm14
00007981ddfd2c29  movaps [r15+0x1C0], xmm4
00007981ddfd2c31  vmovaps [rsp+0x100], xmm11
00007981ddfd2c3a  vmovaps xmm14, [rsp+0x100]
00007981ddfd2c43  por xmm11, xmm14
00007981ddfd2c48  movaps [r15+0x200], xmm11
00007981ddfd2c50  vmovaps [rsp+0x100], xmm5
00007981ddfd2c59  vmovaps xmm14, [rsp+0x100]
00007981ddfd2c62  por xmm5, xmm14
00007981ddfd2c67  movaps [r15+0x2D0], xmm5
00007981ddfd2c6f  vmovaps xmm14, [rsp+0x120]
00007981ddfd2c78  vmovaps xmm13, [rsp+0x120]
00007981ddfd2c81  por xmm14, xmm13
00007981ddfd2c86  movaps [r15+0x2E0], xmm14
00007981ddfd2c8e  vmovaps [rsp+0x100], xmm1
00007981ddfd2c97  vmovaps xmm1, [rsp+0x110]
00007981ddfd2ca0  vmovaps [rsp+0x110], xmm15
00007981ddfd2ca9  vmovaps xmm15, [rsp+0xD0]
00007981ddfd2cb2  vmovaps [rsp+0xD0], xmm14
00007981ddfd2cbb  movaps xmm13, xmm1
00007981ddfd2cbf  addpd xmm13, xmm15
00007981ddfd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007981ddfd2cca  ptest xmm14, xmm14
00007981ddfd2cd0  jnz 0x00007981DDFD4CBB
00007981ddfd2cd6  vmovaps xmm1, [rsp+0xA0]
00007981ddfd2cdf  vpermilpd xmm1, xmm1, 0x00
00007981ddfd2ce5  vmovaps xmm14, [rsp+0x100]
00007981ddfd2cee  vmovaps [rsp+0x100], xmm13
00007981ddfd2cf7  movaps xmm15, xmm14
00007981ddfd2cfb  mulpd xmm15, xmm1
00007981ddfd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007981ddfd2d06  ptest xmm13, xmm13
00007981ddfd2d0c  jnz 0x00007981DDFD4DFE
00007981ddfd2d12  lea rax, [r14+0x80]
00007981ddfd2d19  movups xmm1, [r13+rax*1]
00007981ddfd2d1f  vmovaps xmm13, [rsp+0xE0]
00007981ddfd2d28  vmovaps [rsp+0xE0], xmm1
00007981ddfd2d31  movaps xmm14, xmm13
00007981ddfd2d35  addpd xmm14, xmm2
00007981ddfd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007981ddfd2d40  ptest xmm1, xmm1
00007981ddfd2d45  jnz 0x00007981DDFD4F4B
00007981ddfd2d4b  vmovaps xmm13, [rsp+0xF0]
00007981ddfd2d54  vmovaps xmm2, [rsp+0x20]
00007981ddfd2d5a  vmovaps [rsp+0x20], xmm15
00007981ddfd2d60  movaps xmm1, xmm13
00007981ddfd2d64  addpd xmm1, xmm2
00007981ddfd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007981ddfd2d6d  ptest xmm15, xmm15
00007981ddfd2d73  jnz 0x00007981DDFD508E
00007981ddfd2d79  vmovaps xmm15, [rsp+0x10]
00007981ddfd2d7f  vmovaps xmm13, [rsp+0x10]
00007981ddfd2d85  por xmm15, xmm13
00007981ddfd2d8a  movaps [r15+0x2F0], xmm15
00007981ddfd2d92  vmovaps xmm13, [rsp+0xA0]
00007981ddfd2d9b  vpermilpd xmm13, xmm13, 0x00
00007981ddfd2da1  vmovaps [rsp+0x10], xmm1
00007981ddfd2da7  vmovaps xmm1, [rsp+0xE0]
00007981ddfd2db0  vmovaps [rsp+0xA0], xmm15
00007981ddfd2db9  movaps xmm2, xmm1
00007981ddfd2dbc  mulpd xmm2, xmm13
00007981ddfd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007981ddfd2dc6  ptest xmm15, xmm15
00007981ddfd2dcc  jnz 0x00007981DDFD51CF
00007981ddfd2dd2  lea rax, [r14+0xD0]
00007981ddfd2dd9  movups xmm1, [r13+rax*1]
00007981ddfd2ddf  vmovaps xmm13, [rsp+0xC0]
00007981ddfd2de8  vmovaps [rsp+0xC0], xmm1
00007981ddfd2df1  vmovaps xmm1, [rsp+0x110]
00007981ddfd2dfa  vmovaps [rsp+0xE0], xmm14
00007981ddfd2e03  movaps xmm15, xmm13
00007981ddfd2e07  addpd xmm15, xmm1
00007981ddfd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007981ddfd2e12  ptest xmm14, xmm14
00007981ddfd2e18  jnz 0x00007981DDFD531A
00007981ddfd2e1e  vmovaps xmm1, [rsp+0xB0]
00007981ddfd2e27  vpermilpd xmm1, xmm1, 0x00
00007981ddfd2e2d  movaps xmm14, xmm11
00007981ddfd2e31  mulpd xmm14, xmm1
00007981ddfd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007981ddfd2e3c  ptest xmm13, xmm13
00007981ddfd2e42  jnz 0x00007981DDFD545D
00007981ddfd2e48  movaps [r15+0x260], xmm14
00007981ddfd2e50  vxorps xmm1, xmm1, xmm1
00007981ddfd2e54  vpbroadcastq xmm1, xmm1
00007981ddfd2e59  movaps [r15+0x1B0], xmm1
00007981ddfd2e61  vmovaps xmm1, [rsp+0xB0]
00007981ddfd2e6a  vpermilpd xmm1, xmm1, 0x00
00007981ddfd2e70  vmovaps xmm11, [rsp+0xC0]
00007981ddfd2e79  vmovaps [rsp+0xC0], xmm15
00007981ddfd2e82  movaps xmm13, xmm11
00007981ddfd2e86  mulpd xmm13, xmm1
00007981ddfd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007981ddfd2e91  ptest xmm15, xmm15
00007981ddfd2e97  jnz 0x00007981DDFD55A0
00007981ddfd2e9d  lea rax, [r14+0xC0]
00007981ddfd2ea4  movups xmm1, [r13+rax*1]
00007981ddfd2eaa  vmovaps xmm11, [rsp+0x100]
00007981ddfd2eb3  vmovaps [rsp+0xF0], xmm1
00007981ddfd2ebc  vmovaps xmm1, [rsp+0x20]
00007981ddfd2ec2  vmovaps [rsp+0x20], xmm14
00007981ddfd2ec8  movaps xmm15, xmm11
00007981ddfd2ecc  addpd xmm15, xmm1
00007981ddfd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007981ddfd2ed7  ptest xmm14, xmm14
00007981ddfd2edd  jnz 0x00007981DDFD56ED
00007981ddfd2ee3  vmovaps [rsp+0x100], xmm9
00007981ddfd2eec  vmovaps xmm1, [rsp+0x100]
00007981ddfd2ef5  por xmm9, xmm1
00007981ddfd2efa  movaps [r15+0x270], xmm9
00007981ddfd2f02  vmovaps [rsp+0x100], xmm6
00007981ddfd2f0b  vmovaps xmm1, [rsp+0x100]
00007981ddfd2f14  por xmm6, xmm1
00007981ddfd2f18  movaps [r15+0x1A0], xmm6
00007981ddfd2f20  vmovaps xmm14, [rsp+0xB0]
00007981ddfd2f29  vpermilpd xmm14, xmm14, 0x00
00007981ddfd2f2f  vmovaps xmm6, [rsp+0xF0]
00007981ddfd2f38  vmovaps [rsp+0xF0], xmm1
00007981ddfd2f41  movaps xmm11, xmm6
00007981ddfd2f45  mulpd xmm11, xmm14
00007981ddfd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007981ddfd2f50  ptest xmm1, xmm1
00007981ddfd2f55  jnz 0x00007981DDFD5830
00007981ddfd2f5b  lea rax, [r14+0x20]
00007981ddfd2f5f  movups xmm1, [r13+rax*1]
00007981ddfd2f65  movaps [r15+0x110], xmm1
00007981ddfd2f6d  vmovaps xmm6, [rsp+0xE0]
00007981ddfd2f76  vmovaps [rsp+0xE0], xmm1
00007981ddfd2f7f  movaps xmm14, xmm6
00007981ddfd2f83  addpd xmm14, xmm2
00007981ddfd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007981ddfd2f8e  ptest xmm1, xmm1
00007981ddfd2f93  jnz 0x00007981DDFD597D
00007981ddfd2f99  vmovaps xmm1, [rsp+0xB0]
00007981ddfd2fa2  vpermilpd xmm1, xmm1, 0x00
00007981ddfd2fa8  movaps xmm6, xmm5
00007981ddfd2fab  mulpd xmm6, xmm1
00007981ddfd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007981ddfd2fb4  ptest xmm2, xmm2
00007981ddfd2fb9  jnz 0x00007981DDFD5ABF
00007981ddfd2fbf  vmovaps xmm5, [rsp+0x10]
00007981ddfd2fc5  movaps xmm1, xmm5
00007981ddfd2fc8  addpd xmm1, xmm13
00007981ddfd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007981ddfd2fd2  ptest xmm2, xmm2
00007981ddfd2fd7  jnz 0x00007981DDFD5BFF
00007981ddfd2fdd  vmovaps xmm13, [rsp+0x80]
00007981ddfd2fe6  vpermilpd xmm13, xmm13, 0x00
00007981ddfd2fec  vmovaps xmm2, [rsp+0xE0]
00007981ddfd2ff5  vmovaps [rsp+0x10], xmm1
00007981ddfd2ffb  movaps xmm5, xmm2
00007981ddfd2ffe  mulpd xmm5, xmm13
00007981ddfd3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007981ddfd3008  ptest xmm1, xmm1
00007981ddfd300d  jnz 0x00007981DDFD5D40
00007981ddfd3013  vmovaps xmm1, [rsp+0x80]
00007981ddfd301c  vpermilpd xmm1, xmm1, 0x00
00007981ddfd3022  movaps xmm13, xmm10
00007981ddfd3026  mulpd xmm13, xmm1
00007981ddfd302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007981ddfd3031  ptest xmm2, xmm2
00007981ddfd3036  jnz 0x00007981DDFD5E81
00007981ddfd303c  vmovaps xmm10, [rsp+0x20]
00007981ddfd3042  movaps xmm1, xmm15
00007981ddfd3046  addpd xmm1, xmm10
00007981ddfd304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007981ddfd3050  ptest xmm2, xmm2
00007981ddfd3055  jnz 0x00007981DDFD5FC4
00007981ddfd305b  vmovaps xmm10, [rsp+0xC0]
00007981ddfd3064  movaps xmm15, xmm10
00007981ddfd3068  addpd xmm15, xmm11
00007981ddfd306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007981ddfd3073  ptest xmm2, xmm2
00007981ddfd3078  jnz 0x00007981DDFD6106
00007981ddfd307e  vmovaps xmm11, [rsp+0x80]
00007981ddfd3087  vpermilpd xmm11, xmm11, 0x00
00007981ddfd308d  vmovaps xmm2, [rsp+0xD0]
00007981ddfd3096  vmovaps [rsp+0x20], xmm1
00007981ddfd309c  movaps xmm10, xmm2
00007981ddfd30a0  mulpd xmm10, xmm11
00007981ddfd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007981ddfd30ab  ptest xmm1, xmm1
00007981ddfd30b0  jnz 0x00007981DDFD624A
00007981ddfd30b6  vmovaps xmm1, [rsp+0x80]
00007981ddfd30bf  vpermilpd xmm1, xmm1, 0x00
00007981ddfd30c5  vmovaps xmm2, [rsp+0xA0]
00007981ddfd30ce  vmovaps [rsp+0x80], xmm15
00007981ddfd30d7  movaps xmm11, xmm2
00007981ddfd30db  mulpd xmm11, xmm1
00007981ddfd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007981ddfd30e6  ptest xmm15, xmm15
00007981ddfd30ec  jnz 0x00007981DDFD638D
00007981ddfd30f2  movaps xmm1, xmm14
00007981ddfd30f6  addpd xmm1, xmm6
00007981ddfd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007981ddfd30ff  ptest xmm15, xmm15
00007981ddfd3105  jnz 0x00007981DDFD64CF
00007981ddfd310b  vmovaps xmm14, [rsp+0x10]
00007981ddfd3111  movaps xmm15, xmm14
00007981ddfd3115  addpd xmm15, xmm5
00007981ddfd311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007981ddfd3120  ptest xmm6, xmm6
00007981ddfd3125  jnz 0x00007981DDFD6610
00007981ddfd312b  vmovaps xmm14, [rsp+0x90]
00007981ddfd3134  vpermilpd xmm14, xmm14, 0x00
00007981ddfd313a  movaps xmm6, xmm9
00007981ddfd313e  mulpd xmm6, xmm14
00007981ddfd3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007981ddfd3148  ptest xmm5, xmm5
00007981ddfd314d  jnz 0x00007981DDFD6753
00007981ddfd3153  vmovaps xmm9, [rsp+0x80]
00007981ddfd315c  movaps xmm14, xmm9
00007981ddfd3160  addpd xmm14, xmm13
00007981ddfd3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007981ddfd316b  ptest xmm5, xmm5
00007981ddfd3170  jnz 0x00007981DDFD6895
00007981ddfd3176  vmovaps xmm9, [rsp+0x20]
00007981ddfd317c  movaps xmm13, xmm9
00007981ddfd3180  addpd xmm13, xmm10
00007981ddfd3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007981ddfd318b  ptest xmm5, xmm5
00007981ddfd3190  jnz 0x00007981DDFD69D9
00007981ddfd3196  vmovaps [rsp+0x10], xmm12
00007981ddfd319c  vmovaps xmm10, [rsp+0x10]
00007981ddfd31a2  por xmm12, xmm10
00007981ddfd31a7  movaps [r15+0x250], xmm12
00007981ddfd31af  vmovaps [rsp+0x10], xmm7
00007981ddfd31b5  vmovaps xmm12, [rsp+0x10]
00007981ddfd31bb  por xmm7, xmm12
00007981ddfd31c0  movaps [r15+0x2A0], xmm7
00007981ddfd31c8  vmovaps [rsp+0x10], xmm3
00007981ddfd31ce  vmovaps xmm12, [rsp+0x10]
00007981ddfd31d4  por xmm3, xmm12
00007981ddfd31d9  movaps [r15+0x1D0], xmm3
00007981ddfd31e1  lea rax, [r14+0x40]
00007981ddfd31e5  movups xmm12, [r13+rax*1]
00007981ddfd31eb  movaps [r15+0x2C0], xmm12
00007981ddfd31f3  vmovaps xmm10, [rsp+0x90]
00007981ddfd31fc  vpermilpd xmm10, xmm10, 0x00
00007981ddfd3202  movaps xmm9, xmm8
00007981ddfd3206  mulpd xmm9, xmm10
00007981ddfd320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007981ddfd3211  ptest xmm5, xmm5
00007981ddfd3216  jnz 0x00007981DDFD6B27
00007981ddfd321c  movaps xmm10, xmm1
00007981ddfd3220  addpd xmm10, xmm11
00007981ddfd3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007981ddfd322b  ptest xmm8, xmm8
00007981ddfd3231  jnz 0x00007981DDFD6C6B
00007981ddfd3237  movaps xmm1, xmm15
00007981ddfd323b  addpd xmm1, xmm6
00007981ddfd323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007981ddfd3244  ptest xmm11, xmm11
00007981ddfd324a  jnz 0x00007981DDFD6DAE
00007981ddfd3250  vmovaps xmm15, [rsp+0x90]
00007981ddfd3259  vpermilpd xmm15, xmm15, 0x00
00007981ddfd325f  movaps xmm11, xmm12
00007981ddfd3263  mulpd xmm11, xmm15
00007981ddfd3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007981ddfd326e  ptest xmm8, xmm8
00007981ddfd3274  jnz 0x00007981DDFD6EEF
00007981ddfd327a  vmovaps xmm15, [rsp+0x90]
00007981ddfd3283  vpermilpd xmm15, xmm15, 0x00
00007981ddfd3289  vmovaps xmm8, [rsp+0x50]
00007981ddfd328f  movaps xmm12, xmm8
00007981ddfd3293  mulpd xmm12, xmm15
00007981ddfd3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007981ddfd329e  ptest xmm6, xmm6
00007981ddfd32a3  jnz 0x00007981DDFD7033
00007981ddfd32a9  vmovaps xmm15, [rsp+0x30]
00007981ddfd32af  vpermilpd xmm15, xmm15, 0x00
00007981ddfd32b5  movaps xmm8, xmm7
00007981ddfd32b9  mulpd xmm8, xmm15
00007981ddfd32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007981ddfd32c4  ptest xmm6, xmm6
00007981ddfd32c9  jnz 0x00007981DDFD7177
00007981ddfd32cf  movaps xmm15, xmm14
00007981ddfd32d3  addpd xmm15, xmm9
00007981ddfd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007981ddfd32de  ptest xmm7, xmm7
00007981ddfd32e3  jnz 0x00007981DDFD72BA
00007981ddfd32e9  vmovaps xmm14, [rsp+0x30]
00007981ddfd32ef  vpermilpd xmm14, xmm14, 0x00
00007981ddfd32f5  vmovaps xmm7, [rsp+0xF0]
00007981ddfd32fe  movaps xmm9, xmm7
00007981ddfd3302  mulpd xmm9, xmm14
00007981ddfd3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007981ddfd330d  ptest xmm6, xmm6
00007981ddfd3312  jnz 0x00007981DDFD73FE
00007981ddfd3318  movaps xmm14, xmm13
00007981ddfd331c  addpd xmm14, xmm11
00007981ddfd3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007981ddfd3327  ptest xmm7, xmm7
00007981ddfd332c  jnz 0x00007981DDFD7541
00007981ddfd3332  vmovaps xmm13, [rsp+0x30]
00007981ddfd3338  vpermilpd xmm13, xmm13, 0x00
00007981ddfd333e  vmovaps xmm7, [rsp+0x60]
00007981ddfd3344  movaps xmm11, xmm7
00007981ddfd3348  mulpd xmm11, xmm13
00007981ddfd334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007981ddfd3353  ptest xmm6, xmm6
00007981ddfd3358  jnz 0x00007981DDFD7685
00007981ddfd335e  movaps xmm13, xmm10
00007981ddfd3362  addpd xmm13, xmm12
00007981ddfd3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007981ddfd336d  ptest xmm7, xmm7
00007981ddfd3372  jnz 0x00007981DDFD77C8
00007981ddfd3378  vmovaps xmm12, [rsp+0x30]
00007981ddfd337e  vpermilpd xmm12, xmm12, 0x00
00007981ddfd3384  vmovaps xmm7, [rsp+0x70]
00007981ddfd338a  movaps xmm10, xmm7
00007981ddfd338e  mulpd xmm10, xmm12
00007981ddfd3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007981ddfd3399  ptest xmm6, xmm6
00007981ddfd339e  jnz 0x00007981DDFD790C
00007981ddfd33a4  movaps xmm12, xmm1
00007981ddfd33a8  addpd xmm12, xmm8
00007981ddfd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007981ddfd33b3  ptest xmm7, xmm7
00007981ddfd33b8  jnz 0x00007981DDFD7A4F
00007981ddfd33be  lea rax, [r14+0x70]
00007981ddfd33c2  movups xmm1, [r13+rax*1]
00007981ddfd33c8  movaps [r15+0x240], xmm1
00007981ddfd33d0  movaps xmm8, xmm15
00007981ddfd33d4  addpd xmm8, xmm9
00007981ddfd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007981ddfd33df  ptest xmm7, xmm7
00007981ddfd33e4  jnz 0x00007981DDFD7B9C
00007981ddfd33ea  movaps [r15+0x170], xmm8
00007981ddfd33f2  vmovaps xmm15, [rsp+0x40]
00007981ddfd33f8  vpermilpd xmm15, xmm15, 0x00
00007981ddfd33fe  movaps xmm9, xmm1
00007981ddfd3402  mulpd xmm9, xmm15
00007981ddfd3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007981ddfd340d  ptest xmm7, xmm7
00007981ddfd3412  jnz 0x00007981DDFD7CE0
00007981ddfd3418  vmovaps xmm1, [rsp+0x40]
00007981ddfd341e  vpermilpd xmm1, xmm1, 0x00
00007981ddfd3424  movaps xmm15, xmm4
00007981ddfd3428  mulpd xmm15, xmm1
00007981ddfd342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007981ddfd3433  ptest xmm7, xmm7
00007981ddfd3438  jnz 0x00007981DDFD7E23
00007981ddfd343e  movaps [r15+0x180], xmm15
00007981ddfd3446  movaps xmm1, xmm14
00007981ddfd344a  addpd xmm1, xmm11
00007981ddfd344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007981ddfd3454  ptest xmm7, xmm7
00007981ddfd3459  jnz 0x00007981DDFD7F65
00007981ddfd345f  movaps [r15+0x210], xmm1
00007981ddfd3467  movups xmm14, [r13+r14*1]
00007981ddfd346d  lea rax, [r14+0x10]
00007981ddfd3471  movups xmm11, [r13+rax*1]
00007981ddfd3477  movaps [r15+0x230], xmm11
00007981ddfd347f  movaps xmm7, xmm13
00007981ddfd3483  addpd xmm7, xmm10
00007981ddfd3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007981ddfd348d  ptest xmm6, xmm6
00007981ddfd3492  jnz 0x00007981DDFD80BB
00007981ddfd3498  movaps [r15+0x130], xmm7
00007981ddfd34a0  vmovaps xmm13, [rsp+0x40]
00007981ddfd34a6  vpermilpd xmm13, xmm13, 0x00
00007981ddfd34ac  movaps xmm10, xmm11
00007981ddfd34b0  mulpd xmm10, xmm13
00007981ddfd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007981ddfd34bb  ptest xmm6, xmm6
00007981ddfd34c0  jnz 0x00007981DDFD81FD
00007981ddfd34c6  movaps [r15+0x220], xmm10
00007981ddfd34ce  vmovaps xmm13, [rsp+0x40]
00007981ddfd34d4  vpermilpd xmm13, xmm13, 0x00
00007981ddfd34da  movaps xmm11, xmm14
00007981ddfd34de  mulpd xmm11, xmm13
00007981ddfd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007981ddfd34e9  ptest xmm6, xmm6
00007981ddfd34ee  jnz 0x00007981DDFD8341
00007981ddfd34f4  movaps xmm14, xmm12
00007981ddfd34f8  addpd xmm14, xmm9
00007981ddfd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007981ddfd3503  ptest xmm13, xmm13
00007981ddfd3509  jnz 0x00007981DDFD8485
00007981ddfd350f  movaps [r15+0x140], xmm14
00007981ddfd3517  movaps xmm13, xmm8
00007981ddfd351b  addpd xmm13, xmm15
00007981ddfd3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007981ddfd3526  ptest xmm12, xmm12
00007981ddfd352c  jnz 0x00007981DDFD85C9
00007981ddfd3532  movaps [r15+0x150], xmm13
00007981ddfd353a  movaps xmm15, xmm1
00007981ddfd353e  addpd xmm15, xmm10
00007981ddfd3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007981ddfd3549  ptest xmm12, xmm12
00007981ddfd354f  jnz 0x00007981DDFD870D
00007981ddfd3555  movaps [r15+0x160], xmm15
00007981ddfd355d  movaps xmm1, xmm7
00007981ddfd3560  addpd xmm1, xmm11
00007981ddfd3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007981ddfd356a  ptest xmm12, xmm12
00007981ddfd3570  jnz 0x00007981DDFD8850
00007981ddfd3576  movaps [r15+0x120], xmm1
00007981ddfd357e  mov eax, 0x432200
00007981ddfd3583  movups [r13+rax*1], xmm14
00007981ddfd3589  mov eax, 0x432210
00007981ddfd358e  movups [r13+rax*1], xmm13
00007981ddfd3594  mov eax, 0x432220
00007981ddfd3599  movups [r13+rax*1], xmm15
00007981ddfd359f  mov eax, 0x432230
00007981ddfd35a4  movups [r13+rax*1], xmm1
00007981ddfd35aa  mov eax, [r15+0x108]
00007981ddfd35b1  sahf
00007981ddfd35b2  jnz 0x00007981DDFD35E4
00007981ddfd35b4  cmp dword ptr [r15+0x318], 0x00
00007981ddfd35bc  jz 0x00007981DDFDEAE0
00007981ddfd35c2  nop [rax+rax*1], ax
00007981ddfd35cb  nop [rax+rax*1], eax
00007981ddfd35d3  mov eax, 0x4106D0
00007981ddfd35d8  mov [r15+0x100], rax
00007981ddfd35df  jmp 0x00007981DDDFE110
00007981ddfd35e4  cmp dword ptr [r15+0x318], 0x00
00007981ddfd35ec  jz 0x00007981DDFD89C0
00007981ddfd35f2  nop [rax+rax*1], ax
00007981ddfd35fb  nop [rax+rax*1], eax
00007981ddfd3603  mov eax, 0x410504
00007981ddfd3608  mov [r15+0x100], rax
00007981ddfd360f  jmp 0x00007981DDDFE110
00007981ddfd3614  int3
00007981ddfd3615  call 0x00007981DDED64F0
00007981ddfd361a  jmp 0x00007981DDFD2311
00007981ddfd361f  call 0x00007981DDEE5820
00007981ddfd3624  jmp 0x00007981DDFD231E
00007981ddfd3629  call 0x00007981DDEE3320
00007981ddfd362e  jmp 0x00007981DDFD2332
00007981ddfd3633  call 0x00007981DDEE20A0
00007981ddfd3638  jmp 0x00007981DDFD233C
00007981ddfd363d  call 0x00007981DDE09D70
00007981ddfd3642  jmp 0x00007981DDFD234A
00007981ddfd3647  call 0x00007981DDEDFBC0
00007981ddfd364c  jmp 0x00007981DDFD2354
00007981ddfd3651  call 0x00007981DDEC4740
00007981ddfd3656  jmp 0x00007981DDFD2368
00007981ddfd365b  call 0x00007981DDEB5400
00007981ddfd3660  jmp 0x00007981DDFD2375
00007981ddfd3665  call 0x00007981DDEB52F0
00007981ddfd366a  jmp 0x00007981DDFD2382
00007981ddfd366f  call 0x00007981DDEC4620
00007981ddfd3674  jmp 0x00007981DDFD238F
00007981ddfd3679  call 0x00007981DDEBD750
00007981ddfd367e  jmp 0x00007981DDFD239C
00007981ddfd3683  call 0x00007981DDEBC4E0
00007981ddfd3688  jmp 0x00007981DDFD23A9
00007981ddfd368d  call 0x00007981DDEBB270
00007981ddfd3692  jmp 0x00007981DDFD23B6
00007981ddfd3697  call 0x00007981DDEBA000
00007981ddfd369c  jmp 0x00007981DDFD23C3
00007981ddfd36a1  call 0x00007981DDEC4740
00007981ddfd36a6  jmp 0x00007981DDFD23D0
00007981ddfd36ab  call 0x00007981DDEB5400
00007981ddfd36b0  jmp 0x00007981DDFD23DD
00007981ddfd36b5  call 0x00007981DDEB52F0
00007981ddfd36ba  jmp 0x00007981DDFD23EA
00007981ddfd36bf  call 0x00007981DDEC4620
00007981ddfd36c4  jmp 0x00007981DDFD23F7
00007981ddfd36c9  call 0x00007981DDEB8D90
00007981ddfd36ce  jmp 0x00007981DDFD2404
00007981ddfd36d3  call 0x00007981DDEB8A20
00007981ddfd36d8  jmp 0x00007981DDFD2411
00007981ddfd36dd  call 0x00007981DDEB77B0
00007981ddfd36e2  jmp 0x00007981DDFD241B
00007981ddfd36e7  call 0x00007981DDEB6550
00007981ddfd36ec  jmp 0x00007981DDFD2425
00007981ddfd36f1  call 0x00007981DDEB5400
00007981ddfd36f6  jmp 0x00007981DDFD2437
00007981ddfd36fb  call 0x00007981DDEC0FC0
00007981ddfd3700  jmp 0x00007981DDFD2441
00007981ddfd3705  call 0x00007981DDEB52F0
00007981ddfd370a  jmp 0x00007981DDFD244B
00007981ddfd370f  call 0x00007981DDEC0EA0
00007981ddfd3714  jmp 0x00007981DDFD2455
00007981ddfd3719  call 0x00007981DDEBFD50
00007981ddfd371e  jmp 0x00007981DDFD245F
00007981ddfd3723  call 0x00007981DDEB8EA0
00007981ddfd3728  jmp 0x00007981DDFD2469
00007981ddfd372d  call 0x00007981DDEBFC30
00007981ddfd3732  jmp 0x00007981DDFD2476
00007981ddfd3737  call 0x00007981DDEB8D90
00007981ddfd373c  jmp 0x00007981DDFD2483
00007981ddfd3741  call 0x00007981DDEB52F0
00007981ddfd3746  jmp 0x00007981DDFD2496
00007981ddfd374b  call 0x00007981DDEB52F0
00007981ddfd3750  jmp 0x00007981DDFD24A9
00007981ddfd3755  call 0x00007981DDEC0FC0
00007981ddfd375a  jmp 0x00007981DDFD24B6
00007981ddfd375f  call 0x00007981DDEC0FC0
00007981ddfd3764  jmp 0x00007981DDFD24C9
00007981ddfd3769  call 0x00007981DDEC0EA0
00007981ddfd376e  jmp 0x00007981DDFD24D6
00007981ddfd3773  call 0x00007981DDEB52F0
00007981ddfd3778  jmp 0x00007981DDFD24E9
00007981ddfd377d  call 0x00007981DDEB52F0
00007981ddfd3782  jmp 0x00007981DDFD24FC
00007981ddfd3787  call 0x00007981DDEB52F0
00007981ddfd378c  jmp 0x00007981DDFD250F
00007981ddfd3791  call 0x00007981DDEB52F0
00007981ddfd3796  jmp 0x00007981DDFD252A
00007981ddfd379b  call 0x00007981DDEB52F0
00007981ddfd37a0  jmp 0x00007981DDFD253D
00007981ddfd37a5  call 0x00007981DDEB5400
00007981ddfd37aa  jmp 0x00007981DDFD257E
00007981ddfd37af  call 0x00007981DDEC0FC0
00007981ddfd37b4  jmp 0x00007981DDFD258B
00007981ddfd37b9  call 0x00007981DDEB52F0
00007981ddfd37be  jmp 0x00007981DDFD2598
00007981ddfd37c3  call 0x00007981DDEC0EA0
00007981ddfd37c8  jmp 0x00007981DDFD25A5
00007981ddfd37cd  call 0x00007981DDDFF540
00007981ddfd37d2  jmp 0x00007981DDFD25C3
00007981ddfd37d7  call 0x00007981DDE08C20
00007981ddfd37dc  jmp 0x00007981DDFD25CD
00007981ddfd37e1  call 0x00007981DDEE21C0
00007981ddfd37e6  jmp 0x00007981DDFD25D3
00007981ddfd37eb  call 0x00007981DDDFF540
00007981ddfd37f0  jmp 0x00007981DDFD25E3
00007981ddfd37f5  call 0x00007981DDEC0370
00007981ddfd37fa  jmp 0x00007981DDFD2611
00007981ddfd37ff  call 0x00007981DDEBF100
00007981ddfd3804  jmp 0x00007981DDFD261A
00007981ddfd3809  call 0x00007981DDEC0370
00007981ddfd380e  jmp 0x00007981DDFD2674
00007981ddfd3813  call 0x00007981DDEBF100
00007981ddfd3818  jmp 0x00007981DDFD267D
00007981ddfd381d  call 0x00007981DDEC0370
00007981ddfd3822  jmp 0x00007981DDFD26C6
00007981ddfd3827  call 0x00007981DDEBF100
00007981ddfd382c  jmp 0x00007981DDFD26CF
00007981ddfd3831  call 0x00007981DDE0B720
00007981ddfd3836  jmp 0x00007981DDFD2714
00007981ddfd383b  call 0x00007981DDEB47C0
00007981ddfd3840  jmp 0x00007981DDFD2727
00007981ddfd3845  call 0x00007981DDE08B00
00007981ddfd384a  jmp 0x00007981DDFD273E
00007981ddfd384f  call 0x00007981DDDFF430
00007981ddfd3854  jmp 0x00007981DDFD2751
00007981ddfd3859  call 0x00007981DDDFF430
00007981ddfd385e  jmp 0x00007981DDFD2764
00007981ddfd3863  sub rsp, 0x08
00007981ddfd3867  push rax
00007981ddfd3868  push rcx
00007981ddfd3869  push rdx
00007981ddfd386a  push rdi
00007981ddfd386b  push rsi
00007981ddfd386c  push r8
00007981ddfd386e  push r9
00007981ddfd3870  push r10
00007981ddfd3872  push r11
00007981ddfd3874  sub rsp, 0xF0
00007981ddfd387b  vmovaps [rsp], xmm0
00007981ddfd3880  vmovaps [rsp+0x10], xmm2
00007981ddfd3886  vmovaps [rsp+0x20], xmm3
00007981ddfd388c  vmovaps [rsp+0x30], xmm4
00007981ddfd3892  vmovaps [rsp+0x40], xmm5
00007981ddfd3898  vmovaps [rsp+0x50], xmm6
00007981ddfd389e  vmovaps [rsp+0x60], xmm7
00007981ddfd38a4  vmovaps [rsp+0x70], xmm8
00007981ddfd38aa  vmovaps [rsp+0x80], xmm9
00007981ddfd38b3  vmovaps [rsp+0x90], xmm10
00007981ddfd38bc  vmovaps [rsp+0xA0], xmm11
00007981ddfd38c5  vmovaps [rsp+0xB0], xmm12
00007981ddfd38ce  vmovaps [rsp+0xC0], xmm13
00007981ddfd38d7  vmovaps [rsp+0xD0], xmm14
00007981ddfd38e0  vmovaps [rsp+0xE0], xmm15
00007981ddfd38e9  sub rsp, 0x30
00007981ddfd38ed  movaps [rsp], xmm1
00007981ddfd38f1  movaps [rsp+0x10], xmm12
00007981ddfd38f7  movaps [rsp+0x20], xmm15
00007981ddfd38fd  lea rdi, [rsp]
00007981ddfd3901  mov esi, 0x00
00007981ddfd3906  mov rax, 0x5782A6EB3530
00007981ddfd3910  call rax
00007981ddfd3912  movaps xmm1, [rsp]
00007981ddfd3916  add rsp, 0x30
00007981ddfd391a  vmovaps xmm0, [rsp]
00007981ddfd391f  vmovaps xmm2, [rsp+0x10]
00007981ddfd3925  vmovaps xmm3, [rsp+0x20]
00007981ddfd392b  vmovaps xmm4, [rsp+0x30]
00007981ddfd3931  vmovaps xmm5, [rsp+0x40]
00007981ddfd3937  vmovaps xmm6, [rsp+0x50]
00007981ddfd393d  vmovaps xmm7, [rsp+0x60]
00007981ddfd3943  vmovaps xmm8, [rsp+0x70]
00007981ddfd3949  vmovaps xmm9, [rsp+0x80]
00007981ddfd3952  vmovaps xmm10, [rsp+0x90]
00007981ddfd395b  vmovaps xmm11, [rsp+0xA0]
00007981ddfd3964  vmovaps xmm12, [rsp+0xB0]
00007981ddfd396d  vmovaps xmm13, [rsp+0xC0]
00007981ddfd3976  vmovaps xmm14, [rsp+0xD0]
00007981ddfd397f  vmovaps xmm15, [rsp+0xE0]
00007981ddfd3988  add rsp, 0xF0
00007981ddfd398f  pop r11
00007981ddfd3991  pop r10
00007981ddfd3993  pop r9
00007981ddfd3995  pop r8
00007981ddfd3997  pop rsi
00007981ddfd3998  pop rdi
00007981ddfd3999  pop rdx
00007981ddfd399a  pop rcx
00007981ddfd399b  pop rax
00007981ddfd399c  add rsp, 0x08
00007981ddfd39a0  jmp 0x00007981DDFD27B2
00007981ddfd39a5  sub rsp, 0x08
00007981ddfd39a9  push rax
00007981ddfd39aa  push rcx
00007981ddfd39ab  push rdx
00007981ddfd39ac  push rdi
00007981ddfd39ad  push rsi
00007981ddfd39ae  push r8
00007981ddfd39b0  push r9
00007981ddfd39b2  push r10
00007981ddfd39b4  push r11
00007981ddfd39b6  sub rsp, 0xF0
00007981ddfd39bd  vmovaps [rsp], xmm0
00007981ddfd39c2  vmovaps [rsp+0x10], xmm1
00007981ddfd39c8  vmovaps [rsp+0x20], xmm2
00007981ddfd39ce  vmovaps [rsp+0x30], xmm3
00007981ddfd39d4  vmovaps [rsp+0x40], xmm4
00007981ddfd39da  vmovaps [rsp+0x50], xmm5
00007981ddfd39e0  vmovaps [rsp+0x60], xmm6
00007981ddfd39e6  vmovaps [rsp+0x70], xmm7
00007981ddfd39ec  vmovaps [rsp+0x80], xmm8
00007981ddfd39f5  vmovaps [rsp+0x90], xmm9
00007981ddfd39fe  vmovaps [rsp+0xA0], xmm10
00007981ddfd3a07  vmovaps [rsp+0xB0], xmm11
00007981ddfd3a10  vmovaps [rsp+0xC0], xmm12
00007981ddfd3a19  vmovaps [rsp+0xD0], xmm13
00007981ddfd3a22  vmovaps [rsp+0xE0], xmm15
00007981ddfd3a2b  sub rsp, 0x30
00007981ddfd3a2f  movaps [rsp], xmm14
00007981ddfd3a34  movaps [rsp+0x10], xmm1
00007981ddfd3a39  movaps [rsp+0x20], xmm15
00007981ddfd3a3f  lea rdi, [rsp]
00007981ddfd3a43  mov esi, 0x00
00007981ddfd3a48  mov rax, 0x5782A6EB3530
00007981ddfd3a52  call rax
00007981ddfd3a54  movaps xmm14, [rsp]
00007981ddfd3a59  add rsp, 0x30
00007981ddfd3a5d  vmovaps xmm0, [rsp]
00007981ddfd3a62  vmovaps xmm1, [rsp+0x10]
00007981ddfd3a68  vmovaps xmm2, [rsp+0x20]
00007981ddfd3a6e  vmovaps xmm3, [rsp+0x30]
00007981ddfd3a74  vmovaps xmm4, [rsp+0x40]
00007981ddfd3a7a  vmovaps xmm5, [rsp+0x50]
00007981ddfd3a80  vmovaps xmm6, [rsp+0x60]
00007981ddfd3a86  vmovaps xmm7, [rsp+0x70]
00007981ddfd3a8c  vmovaps xmm8, [rsp+0x80]
00007981ddfd3a95  vmovaps xmm9, [rsp+0x90]
00007981ddfd3a9e  vmovaps xmm10, [rsp+0xA0]
00007981ddfd3aa7  vmovaps xmm11, [rsp+0xB0]
00007981ddfd3ab0  vmovaps xmm12, [rsp+0xC0]
00007981ddfd3ab9  vmovaps xmm13, [rsp+0xD0]
00007981ddfd3ac2  vmovaps xmm15, [rsp+0xE0]
00007981ddfd3acb  add rsp, 0xF0
00007981ddfd3ad2  pop r11
00007981ddfd3ad4  pop r10
00007981ddfd3ad6  pop r9
00007981ddfd3ad8  pop r8
00007981ddfd3ada  pop rsi
00007981ddfd3adb  pop rdi
00007981ddfd3adc  pop rdx
00007981ddfd3add  pop rcx
00007981ddfd3ade  pop rax
00007981ddfd3adf  add rsp, 0x08
00007981ddfd3ae3  jmp 0x00007981DDFD2800
00007981ddfd3ae8  sub rsp, 0x08
00007981ddfd3aec  push rax
00007981ddfd3aed  push rcx
00007981ddfd3aee  push rdx
00007981ddfd3aef  push rdi
00007981ddfd3af0  push rsi
00007981ddfd3af1  push r8
00007981ddfd3af3  push r9
00007981ddfd3af5  push r10
00007981ddfd3af7  push r11
00007981ddfd3af9  sub rsp, 0xF0
00007981ddfd3b00  vmovaps [rsp], xmm0
00007981ddfd3b05  vmovaps [rsp+0x10], xmm1
00007981ddfd3b0b  vmovaps [rsp+0x20], xmm2
00007981ddfd3b11  vmovaps [rsp+0x30], xmm3
00007981ddfd3b17  vmovaps [rsp+0x40], xmm4
00007981ddfd3b1d  vmovaps [rsp+0x50], xmm5
00007981ddfd3b23  vmovaps [rsp+0x60], xmm6
00007981ddfd3b29  vmovaps [rsp+0x70], xmm7
00007981ddfd3b2f  vmovaps [rsp+0x80], xmm8
00007981ddfd3b38  vmovaps [rsp+0x90], xmm9
00007981ddfd3b41  vmovaps [rsp+0xA0], xmm10
00007981ddfd3b4a  vmovaps [rsp+0xB0], xmm11
00007981ddfd3b53  vmovaps [rsp+0xC0], xmm12
00007981ddfd3b5c  vmovaps [rsp+0xD0], xmm13
00007981ddfd3b65  vmovaps [rsp+0xE0], xmm14
00007981ddfd3b6e  sub rsp, 0x30
00007981ddfd3b72  movaps [rsp], xmm15
00007981ddfd3b77  movaps [rsp+0x10], xmm12
00007981ddfd3b7d  movaps [rsp+0x20], xmm13
00007981ddfd3b83  lea rdi, [rsp]
00007981ddfd3b87  mov esi, 0x00
00007981ddfd3b8c  mov rax, 0x5782A6EB3530
00007981ddfd3b96  call rax
00007981ddfd3b98  movaps xmm15, [rsp]
00007981ddfd3b9d  add rsp, 0x30
00007981ddfd3ba1  vmovaps xmm0, [rsp]
00007981ddfd3ba6  vmovaps xmm1, [rsp+0x10]
00007981ddfd3bac  vmovaps xmm2, [rsp+0x20]
00007981ddfd3bb2  vmovaps xmm3, [rsp+0x30]
00007981ddfd3bb8  vmovaps xmm4, [rsp+0x40]
00007981ddfd3bbe  vmovaps xmm5, [rsp+0x50]
00007981ddfd3bc4  vmovaps xmm6, [rsp+0x60]
00007981ddfd3bca  vmovaps xmm7, [rsp+0x70]
00007981ddfd3bd0  vmovaps xmm8, [rsp+0x80]
00007981ddfd3bd9  vmovaps xmm9, [rsp+0x90]
00007981ddfd3be2  vmovaps xmm10, [rsp+0xA0]
00007981ddfd3beb  vmovaps xmm11, [rsp+0xB0]
00007981ddfd3bf4  vmovaps xmm12, [rsp+0xC0]
00007981ddfd3bfd  vmovaps xmm13, [rsp+0xD0]
00007981ddfd3c06  vmovaps xmm14, [rsp+0xE0]
00007981ddfd3c0f  add rsp, 0xF0
00007981ddfd3c16  pop r11
00007981ddfd3c18  pop r10
00007981ddfd3c1a  pop r9
00007981ddfd3c1c  pop r8
00007981ddfd3c1e  pop rsi
00007981ddfd3c1f  pop rdi
00007981ddfd3c20  pop rdx
00007981ddfd3c21  pop rcx
00007981ddfd3c22  pop rax
00007981ddfd3c23  add rsp, 0x08
00007981ddfd3c27  jmp 0x00007981DDFD2835
00007981ddfd3c2c  sub rsp, 0x08
00007981ddfd3c30  push rax
00007981ddfd3c31  push rcx
00007981ddfd3c32  push rdx
00007981ddfd3c33  push rdi
00007981ddfd3c34  push rsi
00007981ddfd3c35  push r8
00007981ddfd3c37  push r9
00007981ddfd3c39  push r10
00007981ddfd3c3b  push r11
00007981ddfd3c3d  sub rsp, 0xF0
00007981ddfd3c44  vmovaps [rsp], xmm0
00007981ddfd3c49  vmovaps [rsp+0x10], xmm2
00007981ddfd3c4f  vmovaps [rsp+0x20], xmm3
00007981ddfd3c55  vmovaps [rsp+0x30], xmm4
00007981ddfd3c5b  vmovaps [rsp+0x40], xmm5
00007981ddfd3c61  vmovaps [rsp+0x50], xmm6
00007981ddfd3c67  vmovaps [rsp+0x60], xmm7
00007981ddfd3c6d  vmovaps [rsp+0x70], xmm8
00007981ddfd3c73  vmovaps [rsp+0x80], xmm9
00007981ddfd3c7c  vmovaps [rsp+0x90], xmm10
00007981ddfd3c85  vmovaps [rsp+0xA0], xmm11
00007981ddfd3c8e  vmovaps [rsp+0xB0], xmm12
00007981ddfd3c97  vmovaps [rsp+0xC0], xmm13
00007981ddfd3ca0  vmovaps [rsp+0xD0], xmm14
00007981ddfd3ca9  vmovaps [rsp+0xE0], xmm15
00007981ddfd3cb2  sub rsp, 0x30
00007981ddfd3cb6  movaps [rsp], xmm1
00007981ddfd3cba  movaps [rsp+0x10], xmm12
00007981ddfd3cc0  movaps [rsp+0x20], xmm10
00007981ddfd3cc6  lea rdi, [rsp]
00007981ddfd3cca  mov esi, 0x00
00007981ddfd3ccf  mov rax, 0x5782A6EB3530
00007981ddfd3cd9  call rax
00007981ddfd3cdb  movaps xmm1, [rsp]
00007981ddfd3cdf  add rsp, 0x30
00007981ddfd3ce3  vmovaps xmm0, [rsp]
00007981ddfd3ce8  vmovaps xmm2, [rsp+0x10]
00007981ddfd3cee  vmovaps xmm3, [rsp+0x20]
00007981ddfd3cf4  vmovaps xmm4, [rsp+0x30]
00007981ddfd3cfa  vmovaps xmm5, [rsp+0x40]
00007981ddfd3d00  vmovaps xmm6, [rsp+0x50]
00007981ddfd3d06  vmovaps xmm7, [rsp+0x60]
00007981ddfd3d0c  vmovaps xmm8, [rsp+0x70]
00007981ddfd3d12  vmovaps xmm9, [rsp+0x80]
00007981ddfd3d1b  vmovaps xmm10, [rsp+0x90]
00007981ddfd3d24  vmovaps xmm11, [rsp+0xA0]
00007981ddfd3d2d  vmovaps xmm12, [rsp+0xB0]
00007981ddfd3d36  vmovaps xmm13, [rsp+0xC0]
00007981ddfd3d3f  vmovaps xmm14, [rsp+0xD0]
00007981ddfd3d48  vmovaps xmm15, [rsp+0xE0]
00007981ddfd3d51  add rsp, 0xF0
00007981ddfd3d58  pop r11
00007981ddfd3d5a  pop r10
00007981ddfd3d5c  pop r9
00007981ddfd3d5e  pop r8
00007981ddfd3d60  pop rsi
00007981ddfd3d61  pop rdi
00007981ddfd3d62  pop rdx
00007981ddfd3d63  pop rcx
00007981ddfd3d64  pop rax
00007981ddfd3d65  add rsp, 0x08
00007981ddfd3d69  jmp 0x00007981DDFD284F
00007981ddfd3d6e  sub rsp, 0x08
00007981ddfd3d72  push rax
00007981ddfd3d73  push rcx
00007981ddfd3d74  push rdx
00007981ddfd3d75  push rdi
00007981ddfd3d76  push rsi
00007981ddfd3d77  push r8
00007981ddfd3d79  push r9
00007981ddfd3d7b  push r10
00007981ddfd3d7d  push r11
00007981ddfd3d7f  sub rsp, 0xF0
00007981ddfd3d86  vmovaps [rsp], xmm0
00007981ddfd3d8b  vmovaps [rsp+0x10], xmm1
00007981ddfd3d91  vmovaps [rsp+0x20], xmm2
00007981ddfd3d97  vmovaps [rsp+0x30], xmm3
00007981ddfd3d9d  vmovaps [rsp+0x40], xmm4
00007981ddfd3da3  vmovaps [rsp+0x50], xmm5
00007981ddfd3da9  vmovaps [rsp+0x60], xmm6
00007981ddfd3daf  vmovaps [rsp+0x70], xmm7
00007981ddfd3db5  vmovaps [rsp+0x80], xmm8
00007981ddfd3dbe  vmovaps [rsp+0x90], xmm9
00007981ddfd3dc7  vmovaps [rsp+0xA0], xmm10
00007981ddfd3dd0  vmovaps [rsp+0xB0], xmm11
00007981ddfd3dd9  vmovaps [rsp+0xC0], xmm12
00007981ddfd3de2  vmovaps [rsp+0xD0], xmm14
00007981ddfd3deb  vmovaps [rsp+0xE0], xmm15
00007981ddfd3df4  sub rsp, 0x30
00007981ddfd3df8  movaps [rsp], xmm13
00007981ddfd3dfd  movaps [rsp+0x10], xmm12
00007981ddfd3e03  movaps [rsp+0x20], xmm2
00007981ddfd3e08  lea rdi, [rsp]
00007981ddfd3e0c  mov esi, 0x00
00007981ddfd3e11  mov rax, 0x5782A6EB3530
00007981ddfd3e1b  call rax
00007981ddfd3e1d  movaps xmm13, [rsp]
00007981ddfd3e22  add rsp, 0x30
00007981ddfd3e26  vmovaps xmm0, [rsp]
00007981ddfd3e2b  vmovaps xmm1, [rsp+0x10]
00007981ddfd3e31  vmovaps xmm2, [rsp+0x20]
00007981ddfd3e37  vmovaps xmm3, [rsp+0x30]
00007981ddfd3e3d  vmovaps xmm4, [rsp+0x40]
00007981ddfd3e43  vmovaps xmm5, [rsp+0x50]
00007981ddfd3e49  vmovaps xmm6, [rsp+0x60]
00007981ddfd3e4f  vmovaps xmm7, [rsp+0x70]
00007981ddfd3e55  vmovaps xmm8, [rsp+0x80]
00007981ddfd3e5e  vmovaps xmm9, [rsp+0x90]
00007981ddfd3e67  vmovaps xmm10, [rsp+0xA0]
00007981ddfd3e70  vmovaps xmm11, [rsp+0xB0]
00007981ddfd3e79  vmovaps xmm12, [rsp+0xC0]
00007981ddfd3e82  vmovaps xmm14, [rsp+0xD0]
00007981ddfd3e8b  vmovaps xmm15, [rsp+0xE0]
00007981ddfd3e94  add rsp, 0xF0
00007981ddfd3e9b  pop r11
00007981ddfd3e9d  pop r10
00007981ddfd3e9f  pop r9
00007981ddfd3ea1  pop r8
00007981ddfd3ea3  pop rsi
00007981ddfd3ea4  pop rdi
00007981ddfd3ea5  pop rdx
00007981ddfd3ea6  pop rcx
00007981ddfd3ea7  pop rax
00007981ddfd3ea8  add rsp, 0x08
00007981ddfd3eac  jmp 0x00007981DDFD286A
00007981ddfd3eb1  sub rsp, 0x08
00007981ddfd3eb5  push rax
00007981ddfd3eb6  push rcx
00007981ddfd3eb7  push rdx
00007981ddfd3eb8  push rdi
00007981ddfd3eb9  push rsi
00007981ddfd3eba  push r8
00007981ddfd3ebc  push r9
00007981ddfd3ebe  push r10
00007981ddfd3ec0  push r11
00007981ddfd3ec2  sub rsp, 0xF0
00007981ddfd3ec9  vmovaps [rsp], xmm0
00007981ddfd3ece  vmovaps [rsp+0x10], xmm2
00007981ddfd3ed4  vmovaps [rsp+0x20], xmm3
00007981ddfd3eda  vmovaps [rsp+0x30], xmm4
00007981ddfd3ee0  vmovaps [rsp+0x40], xmm5
00007981ddfd3ee6  vmovaps [rsp+0x50], xmm6
00007981ddfd3eec  vmovaps [rsp+0x60], xmm7
00007981ddfd3ef2  vmovaps [rsp+0x70], xmm8
00007981ddfd3ef8  vmovaps [rsp+0x80], xmm9
00007981ddfd3f01  vmovaps [rsp+0x90], xmm10
00007981ddfd3f0a  vmovaps [rsp+0xA0], xmm11
00007981ddfd3f13  vmovaps [rsp+0xB0], xmm12
00007981ddfd3f1c  vmovaps [rsp+0xC0], xmm13
00007981ddfd3f25  vmovaps [rsp+0xD0], xmm14
00007981ddfd3f2e  vmovaps [rsp+0xE0], xmm15
00007981ddfd3f37  sub rsp, 0x30
00007981ddfd3f3b  movaps [rsp], xmm1
00007981ddfd3f3f  movaps [rsp+0x10], xmm10
00007981ddfd3f45  movaps [rsp+0x20], xmm2
00007981ddfd3f4a  lea rdi, [rsp]
00007981ddfd3f4e  mov esi, 0x00
00007981ddfd3f53  mov rax, 0x5782A6EB3530
00007981ddfd3f5d  call rax
00007981ddfd3f5f  movaps xmm1, [rsp]
00007981ddfd3f63  add rsp, 0x30
00007981ddfd3f67  vmovaps xmm0, [rsp]
00007981ddfd3f6c  vmovaps xmm2, [rsp+0x10]
00007981ddfd3f72  vmovaps xmm3, [rsp+0x20]
00007981ddfd3f78  vmovaps xmm4, [rsp+0x30]
00007981ddfd3f7e  vmovaps xmm5, [rsp+0x40]
00007981ddfd3f84  vmovaps xmm6, [rsp+0x50]
00007981ddfd3f8a  vmovaps xmm7, [rsp+0x60]
00007981ddfd3f90  vmovaps xmm8, [rsp+0x70]
00007981ddfd3f96  vmovaps xmm9, [rsp+0x80]
00007981ddfd3f9f  vmovaps xmm10, [rsp+0x90]
00007981ddfd3fa8  vmovaps xmm11, [rsp+0xA0]
00007981ddfd3fb1  vmovaps xmm12, [rsp+0xB0]
00007981ddfd3fba  vmovaps xmm13, [rsp+0xC0]
00007981ddfd3fc3  vmovaps xmm14, [rsp+0xD0]
00007981ddfd3fcc  vmovaps xmm15, [rsp+0xE0]
00007981ddfd3fd5  add rsp, 0xF0
00007981ddfd3fdc  pop r11
00007981ddfd3fde  pop r10
00007981ddfd3fe0  pop r9
00007981ddfd3fe2  pop r8
00007981ddfd3fe4  pop rsi
00007981ddfd3fe5  pop rdi
00007981ddfd3fe6  pop rdx
00007981ddfd3fe7  pop rcx
00007981ddfd3fe8  pop rax
00007981ddfd3fe9  add rsp, 0x08
00007981ddfd3fed  jmp 0x00007981DDFD28D2
00007981ddfd3ff2  sub rsp, 0x08
00007981ddfd3ff6  push rax
00007981ddfd3ff7  push rcx
00007981ddfd3ff8  push rdx
00007981ddfd3ff9  push rdi
00007981ddfd3ffa  push rsi
00007981ddfd3ffb  push r8
00007981ddfd3ffd  push r9
00007981ddfd3fff  push r10
00007981ddfd4001  push r11
00007981ddfd4003  sub rsp, 0xF0
00007981ddfd400a  vmovaps [rsp], xmm0
00007981ddfd400f  vmovaps [rsp+0x10], xmm1
00007981ddfd4015  vmovaps [rsp+0x20], xmm2
00007981ddfd401b  vmovaps [rsp+0x30], xmm3
00007981ddfd4021  vmovaps [rsp+0x40], xmm4
00007981ddfd4027  vmovaps [rsp+0x50], xmm5
00007981ddfd402d  vmovaps [rsp+0x60], xmm6
00007981ddfd4033  vmovaps [rsp+0x70], xmm7
00007981ddfd4039  vmovaps [rsp+0x80], xmm8
00007981ddfd4042  vmovaps [rsp+0x90], xmm9
00007981ddfd404b  vmovaps [rsp+0xA0], xmm10
00007981ddfd4054  vmovaps [rsp+0xB0], xmm11
00007981ddfd405d  vmovaps [rsp+0xC0], xmm12
00007981ddfd4066  vmovaps [rsp+0xD0], xmm13
00007981ddfd406f  vmovaps [rsp+0xE0], xmm14
00007981ddfd4078  sub rsp, 0x30
00007981ddfd407c  movaps [rsp], xmm15
00007981ddfd4081  movaps [rsp+0x10], xmm10
00007981ddfd4087  movaps [rsp+0x20], xmm2
00007981ddfd408c  lea rdi, [rsp]
00007981ddfd4090  mov esi, 0x00
00007981ddfd4095  mov rax, 0x5782A6EB3530
00007981ddfd409f  call rax
00007981ddfd40a1  movaps xmm15, [rsp]
00007981ddfd40a6  add rsp, 0x30
00007981ddfd40aa  vmovaps xmm0, [rsp]
00007981ddfd40af  vmovaps xmm1, [rsp+0x10]
00007981ddfd40b5  vmovaps xmm2, [rsp+0x20]
00007981ddfd40bb  vmovaps xmm3, [rsp+0x30]
00007981ddfd40c1  vmovaps xmm4, [rsp+0x40]
00007981ddfd40c7  vmovaps xmm5, [rsp+0x50]
00007981ddfd40cd  vmovaps xmm6, [rsp+0x60]
00007981ddfd40d3  vmovaps xmm7, [rsp+0x70]
00007981ddfd40d9  vmovaps xmm8, [rsp+0x80]
00007981ddfd40e2  vmovaps xmm9, [rsp+0x90]
00007981ddfd40eb  vmovaps xmm10, [rsp+0xA0]
00007981ddfd40f4  vmovaps xmm11, [rsp+0xB0]
00007981ddfd40fd  vmovaps xmm12, [rsp+0xC0]
00007981ddfd4106  vmovaps xmm13, [rsp+0xD0]
00007981ddfd410f  vmovaps xmm14, [rsp+0xE0]
00007981ddfd4118  add rsp, 0xF0
00007981ddfd411f  pop r11
00007981ddfd4121  pop r10
00007981ddfd4123  pop r9
00007981ddfd4125  pop r8
00007981ddfd4127  pop rsi
00007981ddfd4128  pop rdi
00007981ddfd4129  pop rdx
00007981ddfd412a  pop rcx
00007981ddfd412b  pop rax
00007981ddfd412c  add rsp, 0x08
00007981ddfd4130  jmp 0x00007981DDFD2924
00007981ddfd4135  sub rsp, 0x08
00007981ddfd4139  push rax
00007981ddfd413a  push rcx
00007981ddfd413b  push rdx
00007981ddfd413c  push rdi
00007981ddfd413d  push rsi
00007981ddfd413e  push r8
00007981ddfd4140  push r9
00007981ddfd4142  push r10
00007981ddfd4144  push r11
00007981ddfd4146  sub rsp, 0xF0
00007981ddfd414d  vmovaps [rsp], xmm0
00007981ddfd4152  vmovaps [rsp+0x10], xmm2
00007981ddfd4158  vmovaps [rsp+0x20], xmm3
00007981ddfd415e  vmovaps [rsp+0x30], xmm4
00007981ddfd4164  vmovaps [rsp+0x40], xmm5
00007981ddfd416a  vmovaps [rsp+0x50], xmm6
00007981ddfd4170  vmovaps [rsp+0x60], xmm7
00007981ddfd4176  vmovaps [rsp+0x70], xmm8
00007981ddfd417c  vmovaps [rsp+0x80], xmm9
00007981ddfd4185  vmovaps [rsp+0x90], xmm10
00007981ddfd418e  vmovaps [rsp+0xA0], xmm11
00007981ddfd4197  vmovaps [rsp+0xB0], xmm12
00007981ddfd41a0  vmovaps [rsp+0xC0], xmm13
00007981ddfd41a9  vmovaps [rsp+0xD0], xmm14
00007981ddfd41b2  vmovaps [rsp+0xE0], xmm15
00007981ddfd41bb  sub rsp, 0x30
00007981ddfd41bf  movaps [rsp], xmm1
00007981ddfd41c3  movaps [rsp+0x10], xmm10
00007981ddfd41c9  movaps [rsp+0x20], xmm15
00007981ddfd41cf  lea rdi, [rsp]
00007981ddfd41d3  mov esi, 0x00
00007981ddfd41d8  mov rax, 0x5782A6EB3530
00007981ddfd41e2  call rax
00007981ddfd41e4  movaps xmm1, [rsp]
00007981ddfd41e8  add rsp, 0x30
00007981ddfd41ec  vmovaps xmm0, [rsp]
00007981ddfd41f1  vmovaps xmm2, [rsp+0x10]
00007981ddfd41f7  vmovaps xmm3, [rsp+0x20]
00007981ddfd41fd  vmovaps xmm4, [rsp+0x30]
00007981ddfd4203  vmovaps xmm5, [rsp+0x40]
00007981ddfd4209  vmovaps xmm6, [rsp+0x50]
00007981ddfd420f  vmovaps xmm7, [rsp+0x60]
00007981ddfd4215  vmovaps xmm8, [rsp+0x70]
00007981ddfd421b  vmovaps xmm9, [rsp+0x80]
00007981ddfd4224  vmovaps xmm10, [rsp+0x90]
00007981ddfd422d  vmovaps xmm11, [rsp+0xA0]
00007981ddfd4236  vmovaps xmm12, [rsp+0xB0]
00007981ddfd423f  vmovaps xmm13, [rsp+0xC0]
00007981ddfd4248  vmovaps xmm14, [rsp+0xD0]
00007981ddfd4251  vmovaps xmm15, [rsp+0xE0]
00007981ddfd425a  add rsp, 0xF0
00007981ddfd4261  pop r11
00007981ddfd4263  pop r10
00007981ddfd4265  pop r9
00007981ddfd4267  pop r8
00007981ddfd4269  pop rsi
00007981ddfd426a  pop rdi
00007981ddfd426b  pop rdx
00007981ddfd426c  pop rcx
00007981ddfd426d  pop rax
00007981ddfd426e  add rsp, 0x08
00007981ddfd4272  jmp 0x00007981DDFD2962
00007981ddfd4277  sub rsp, 0x08
00007981ddfd427b  push rax
00007981ddfd427c  push rcx
00007981ddfd427d  push rdx
00007981ddfd427e  push rdi
00007981ddfd427f  push rsi
00007981ddfd4280  push r8
00007981ddfd4282  push r9
00007981ddfd4284  push r10
00007981ddfd4286  push r11
00007981ddfd4288  sub rsp, 0xF0
00007981ddfd428f  vmovaps [rsp], xmm0
00007981ddfd4294  vmovaps [rsp+0x10], xmm1
00007981ddfd429a  vmovaps [rsp+0x20], xmm2
00007981ddfd42a0  vmovaps [rsp+0x30], xmm3
00007981ddfd42a6  vmovaps [rsp+0x40], xmm4
00007981ddfd42ac  vmovaps [rsp+0x50], xmm5
00007981ddfd42b2  vmovaps [rsp+0x60], xmm6
00007981ddfd42b8  vmovaps [rsp+0x70], xmm7
00007981ddfd42be  vmovaps [rsp+0x80], xmm8
00007981ddfd42c7  vmovaps [rsp+0x90], xmm9
00007981ddfd42d0  vmovaps [rsp+0xA0], xmm10
00007981ddfd42d9  vmovaps [rsp+0xB0], xmm11
00007981ddfd42e2  vmovaps [rsp+0xC0], xmm12
00007981ddfd42eb  vmovaps [rsp+0xD0], xmm13
00007981ddfd42f4  vmovaps [rsp+0xE0], xmm15
00007981ddfd42fd  sub rsp, 0x30
00007981ddfd4301  movaps [rsp], xmm14
00007981ddfd4306  movaps [rsp+0x10], xmm10
00007981ddfd430c  movaps [rsp+0x20], xmm15
00007981ddfd4312  lea rdi, [rsp]
00007981ddfd4316  mov esi, 0x00
00007981ddfd431b  mov rax, 0x5782A6EB3530
00007981ddfd4325  call rax
00007981ddfd4327  movaps xmm14, [rsp]
00007981ddfd432c  add rsp, 0x30
00007981ddfd4330  vmovaps xmm0, [rsp]
00007981ddfd4335  vmovaps xmm1, [rsp+0x10]
00007981ddfd433b  vmovaps xmm2, [rsp+0x20]
00007981ddfd4341  vmovaps xmm3, [rsp+0x30]
00007981ddfd4347  vmovaps xmm4, [rsp+0x40]
00007981ddfd434d  vmovaps xmm5, [rsp+0x50]
00007981ddfd4353  vmovaps xmm6, [rsp+0x60]
00007981ddfd4359  vmovaps xmm7, [rsp+0x70]
00007981ddfd435f  vmovaps xmm8, [rsp+0x80]
00007981ddfd4368  vmovaps xmm9, [rsp+0x90]
00007981ddfd4371  vmovaps xmm10, [rsp+0xA0]
00007981ddfd437a  vmovaps xmm11, [rsp+0xB0]
00007981ddfd4383  vmovaps xmm12, [rsp+0xC0]
00007981ddfd438c  vmovaps xmm13, [rsp+0xD0]
00007981ddfd4395  vmovaps xmm15, [rsp+0xE0]
00007981ddfd439e  add rsp, 0xF0
00007981ddfd43a5  pop r11
00007981ddfd43a7  pop r10
00007981ddfd43a9  pop r9
00007981ddfd43ab  pop r8
00007981ddfd43ad  pop rsi
00007981ddfd43ae  pop rdi
00007981ddfd43af  pop rdx
00007981ddfd43b0  pop rcx
00007981ddfd43b1  pop rax
00007981ddfd43b2  add rsp, 0x08
00007981ddfd43b6  jmp 0x00007981DDFD298E
00007981ddfd43bb  call 0x00007981DDDFF430
00007981ddfd43c0  jmp 0x00007981DDFD2A1E
00007981ddfd43c5  call 0x00007981DDDFF430
00007981ddfd43ca  jmp 0x00007981DDFD2A31
00007981ddfd43cf  sub rsp, 0x08
00007981ddfd43d3  push rax
00007981ddfd43d4  push rcx
00007981ddfd43d5  push rdx
00007981ddfd43d6  push rdi
00007981ddfd43d7  push rsi
00007981ddfd43d8  push r8
00007981ddfd43da  push r9
00007981ddfd43dc  push r10
00007981ddfd43de  push r11
00007981ddfd43e0  sub rsp, 0xF0
00007981ddfd43e7  vmovaps [rsp], xmm0
00007981ddfd43ec  vmovaps [rsp+0x10], xmm2
00007981ddfd43f2  vmovaps [rsp+0x20], xmm3
00007981ddfd43f8  vmovaps [rsp+0x30], xmm4
00007981ddfd43fe  vmovaps [rsp+0x40], xmm5
00007981ddfd4404  vmovaps [rsp+0x50], xmm6
00007981ddfd440a  vmovaps [rsp+0x60], xmm7
00007981ddfd4410  vmovaps [rsp+0x70], xmm8
00007981ddfd4416  vmovaps [rsp+0x80], xmm9
00007981ddfd441f  vmovaps [rsp+0x90], xmm10
00007981ddfd4428  vmovaps [rsp+0xA0], xmm11
00007981ddfd4431  vmovaps [rsp+0xB0], xmm12
00007981ddfd443a  vmovaps [rsp+0xC0], xmm13
00007981ddfd4443  vmovaps [rsp+0xD0], xmm14
00007981ddfd444c  vmovaps [rsp+0xE0], xmm15
00007981ddfd4455  sub rsp, 0x30
00007981ddfd4459  movaps [rsp], xmm1
00007981ddfd445d  movaps [rsp+0x10], xmm13
00007981ddfd4463  movaps [rsp+0x20], xmm2
00007981ddfd4468  lea rdi, [rsp]
00007981ddfd446c  mov esi, 0x00
00007981ddfd4471  mov rax, 0x5782A6EB3530
00007981ddfd447b  call rax
00007981ddfd447d  movaps xmm1, [rsp]
00007981ddfd4481  add rsp, 0x30
00007981ddfd4485  vmovaps xmm0, [rsp]
00007981ddfd448a  vmovaps xmm2, [rsp+0x10]
00007981ddfd4490  vmovaps xmm3, [rsp+0x20]
00007981ddfd4496  vmovaps xmm4, [rsp+0x30]
00007981ddfd449c  vmovaps xmm5, [rsp+0x40]
00007981ddfd44a2  vmovaps xmm6, [rsp+0x50]
00007981ddfd44a8  vmovaps xmm7, [rsp+0x60]
00007981ddfd44ae  vmovaps xmm8, [rsp+0x70]
00007981ddfd44b4  vmovaps xmm9, [rsp+0x80]
00007981ddfd44bd  vmovaps xmm10, [rsp+0x90]
00007981ddfd44c6  vmovaps xmm11, [rsp+0xA0]
00007981ddfd44cf  vmovaps xmm12, [rsp+0xB0]
00007981ddfd44d8  vmovaps xmm13, [rsp+0xC0]
00007981ddfd44e1  vmovaps xmm14, [rsp+0xD0]
00007981ddfd44ea  vmovaps xmm15, [rsp+0xE0]
00007981ddfd44f3  add rsp, 0xF0
00007981ddfd44fa  pop r11
00007981ddfd44fc  pop r10
00007981ddfd44fe  pop r9
00007981ddfd4500  pop r8
00007981ddfd4502  pop rsi
00007981ddfd4503  pop rdi
00007981ddfd4504  pop rdx
00007981ddfd4505  pop rcx
00007981ddfd4506  pop rax
00007981ddfd4507  add rsp, 0x08
00007981ddfd450b  jmp 0x00007981DDFD2A5C
00007981ddfd4510  call 0x00007981DDE0E760
00007981ddfd4515  jmp 0x00007981DDFD2A69
00007981ddfd451a  sub rsp, 0x08
00007981ddfd451e  push rax
00007981ddfd451f  push rcx
00007981ddfd4520  push rdx
00007981ddfd4521  push rdi
00007981ddfd4522  push rsi
00007981ddfd4523  push r8
00007981ddfd4525  push r9
00007981ddfd4527  push r10
00007981ddfd4529  push r11
00007981ddfd452b  sub rsp, 0xF0
00007981ddfd4532  vmovaps [rsp], xmm0
00007981ddfd4537  vmovaps [rsp+0x10], xmm1
00007981ddfd453d  vmovaps [rsp+0x20], xmm2
00007981ddfd4543  vmovaps [rsp+0x30], xmm3
00007981ddfd4549  vmovaps [rsp+0x40], xmm4
00007981ddfd454f  vmovaps [rsp+0x50], xmm5
00007981ddfd4555  vmovaps [rsp+0x60], xmm6
00007981ddfd455b  vmovaps [rsp+0x70], xmm7
00007981ddfd4561  vmovaps [rsp+0x80], xmm8
00007981ddfd456a  vmovaps [rsp+0x90], xmm9
00007981ddfd4573  vmovaps [rsp+0xA0], xmm10
00007981ddfd457c  vmovaps [rsp+0xB0], xmm11
00007981ddfd4585  vmovaps [rsp+0xC0], xmm12
00007981ddfd458e  vmovaps [rsp+0xD0], xmm14
00007981ddfd4597  vmovaps [rsp+0xE0], xmm15
00007981ddfd45a0  sub rsp, 0x30
00007981ddfd45a4  movaps [rsp], xmm13
00007981ddfd45a9  movaps [rsp+0x10], xmm2
00007981ddfd45ae  movaps [rsp+0x20], xmm1
00007981ddfd45b3  lea rdi, [rsp]
00007981ddfd45b7  mov esi, 0x00
00007981ddfd45bc  mov rax, 0x5782A6EB3530
00007981ddfd45c6  call rax
00007981ddfd45c8  movaps xmm13, [rsp]
00007981ddfd45cd  add rsp, 0x30
00007981ddfd45d1  vmovaps xmm0, [rsp]
00007981ddfd45d6  vmovaps xmm1, [rsp+0x10]
00007981ddfd45dc  vmovaps xmm2, [rsp+0x20]
00007981ddfd45e2  vmovaps xmm3, [rsp+0x30]
00007981ddfd45e8  vmovaps xmm4, [rsp+0x40]
00007981ddfd45ee  vmovaps xmm5, [rsp+0x50]
00007981ddfd45f4  vmovaps xmm6, [rsp+0x60]
00007981ddfd45fa  vmovaps xmm7, [rsp+0x70]
00007981ddfd4600  vmovaps xmm8, [rsp+0x80]
00007981ddfd4609  vmovaps xmm9, [rsp+0x90]
00007981ddfd4612  vmovaps xmm10, [rsp+0xA0]
00007981ddfd461b  vmovaps xmm11, [rsp+0xB0]
00007981ddfd4624  vmovaps xmm12, [rsp+0xC0]
00007981ddfd462d  vmovaps xmm14, [rsp+0xD0]
00007981ddfd4636  vmovaps xmm15, [rsp+0xE0]
00007981ddfd463f  add rsp, 0xF0
00007981ddfd4646  pop r11
00007981ddfd4648  pop r10
00007981ddfd464a  pop r9
00007981ddfd464c  pop r8
00007981ddfd464e  pop rsi
00007981ddfd464f  pop rdi
00007981ddfd4650  pop rdx
00007981ddfd4651  pop rcx
00007981ddfd4652  pop rax
00007981ddfd4653  add rsp, 0x08
00007981ddfd4657  jmp 0x00007981DDFD2AA8
00007981ddfd465c  sub rsp, 0x08
00007981ddfd4660  push rax
00007981ddfd4661  push rcx
00007981ddfd4662  push rdx
00007981ddfd4663  push rdi
00007981ddfd4664  push rsi
00007981ddfd4665  push r8
00007981ddfd4667  push r9
00007981ddfd4669  push r10
00007981ddfd466b  push r11
00007981ddfd466d  sub rsp, 0xF0
00007981ddfd4674  vmovaps [rsp], xmm0
00007981ddfd4679  vmovaps [rsp+0x10], xmm2
00007981ddfd467f  vmovaps [rsp+0x20], xmm3
00007981ddfd4685  vmovaps [rsp+0x30], xmm4
00007981ddfd468b  vmovaps [rsp+0x40], xmm5
00007981ddfd4691  vmovaps [rsp+0x50], xmm6
00007981ddfd4697  vmovaps [rsp+0x60], xmm7
00007981ddfd469d  vmovaps [rsp+0x70], xmm8
00007981ddfd46a3  vmovaps [rsp+0x80], xmm9
00007981ddfd46ac  vmovaps [rsp+0x90], xmm10
00007981ddfd46b5  vmovaps [rsp+0xA0], xmm11
00007981ddfd46be  vmovaps [rsp+0xB0], xmm12
00007981ddfd46c7  vmovaps [rsp+0xC0], xmm13
00007981ddfd46d0  vmovaps [rsp+0xD0], xmm14
00007981ddfd46d9  vmovaps [rsp+0xE0], xmm15
00007981ddfd46e2  sub rsp, 0x30
00007981ddfd46e6  movaps [rsp], xmm1
00007981ddfd46ea  movaps [rsp+0x10], xmm14
00007981ddfd46f0  movaps [rsp+0x20], xmm15
00007981ddfd46f6  lea rdi, [rsp]
00007981ddfd46fa  mov esi, 0x00
00007981ddfd46ff  mov rax, 0x5782A6EB3530
00007981ddfd4709  call rax
00007981ddfd470b  movaps xmm1, [rsp]
00007981ddfd470f  add rsp, 0x30
00007981ddfd4713  vmovaps xmm0, [rsp]
00007981ddfd4718  vmovaps xmm2, [rsp+0x10]
00007981ddfd471e  vmovaps xmm3, [rsp+0x20]
00007981ddfd4724  vmovaps xmm4, [rsp+0x30]
00007981ddfd472a  vmovaps xmm5, [rsp+0x40]
00007981ddfd4730  vmovaps xmm6, [rsp+0x50]
00007981ddfd4736  vmovaps xmm7, [rsp+0x60]
00007981ddfd473c  vmovaps xmm8, [rsp+0x70]
00007981ddfd4742  vmovaps xmm9, [rsp+0x80]
00007981ddfd474b  vmovaps xmm10, [rsp+0x90]
00007981ddfd4754  vmovaps xmm11, [rsp+0xA0]
00007981ddfd475d  vmovaps xmm12, [rsp+0xB0]
00007981ddfd4766  vmovaps xmm13, [rsp+0xC0]
00007981ddfd476f  vmovaps xmm14, [rsp+0xD0]
00007981ddfd4778  vmovaps xmm15, [rsp+0xE0]
00007981ddfd4781  add rsp, 0xF0
00007981ddfd4788  pop r11
00007981ddfd478a  pop r10
00007981ddfd478c  pop r9
00007981ddfd478e  pop r8
00007981ddfd4790  pop rsi
00007981ddfd4791  pop rdi
00007981ddfd4792  pop rdx
00007981ddfd4793  pop rcx
00007981ddfd4794  pop rax
00007981ddfd4795  add rsp, 0x08
00007981ddfd4799  jmp 0x00007981DDFD2ACA
00007981ddfd479e  sub rsp, 0x08
00007981ddfd47a2  push rax
00007981ddfd47a3  push rcx
00007981ddfd47a4  push rdx
00007981ddfd47a5  push rdi
00007981ddfd47a6  push rsi
00007981ddfd47a7  push r8
00007981ddfd47a9  push r9
00007981ddfd47ab  push r10
00007981ddfd47ad  push r11
00007981ddfd47af  sub rsp, 0xF0
00007981ddfd47b6  vmovaps [rsp], xmm0
00007981ddfd47bb  vmovaps [rsp+0x10], xmm1
00007981ddfd47c1  vmovaps [rsp+0x20], xmm2
00007981ddfd47c7  vmovaps [rsp+0x30], xmm3
00007981ddfd47cd  vmovaps [rsp+0x40], xmm4
00007981ddfd47d3  vmovaps [rsp+0x50], xmm5
00007981ddfd47d9  vmovaps [rsp+0x60], xmm6
00007981ddfd47df  vmovaps [rsp+0x70], xmm7
00007981ddfd47e5  vmovaps [rsp+0x80], xmm8
00007981ddfd47ee  vmovaps [rsp+0x90], xmm9
00007981ddfd47f7  vmovaps [rsp+0xA0], xmm10
00007981ddfd4800  vmovaps [rsp+0xB0], xmm11
00007981ddfd4809  vmovaps [rsp+0xC0], xmm12
00007981ddfd4812  vmovaps [rsp+0xD0], xmm13
00007981ddfd481b  vmovaps [rsp+0xE0], xmm15
00007981ddfd4824  sub rsp, 0x30
00007981ddfd4828  movaps [rsp], xmm14
00007981ddfd482d  movaps [rsp+0x10], xmm2
00007981ddfd4832  movaps [rsp+0x20], xmm15
00007981ddfd4838  lea rdi, [rsp]
00007981ddfd483c  mov esi, 0x00
00007981ddfd4841  mov rax, 0x5782A6EB3530
00007981ddfd484b  call rax
00007981ddfd484d  movaps xmm14, [rsp]
00007981ddfd4852  add rsp, 0x30
00007981ddfd4856  vmovaps xmm0, [rsp]
00007981ddfd485b  vmovaps xmm1, [rsp+0x10]
00007981ddfd4861  vmovaps xmm2, [rsp+0x20]
00007981ddfd4867  vmovaps xmm3, [rsp+0x30]
00007981ddfd486d  vmovaps xmm4, [rsp+0x40]
00007981ddfd4873  vmovaps xmm5, [rsp+0x50]
00007981ddfd4879  vmovaps xmm6, [rsp+0x60]
00007981ddfd487f  vmovaps xmm7, [rsp+0x70]
00007981ddfd4885  vmovaps xmm8, [rsp+0x80]
00007981ddfd488e  vmovaps xmm9, [rsp+0x90]
00007981ddfd4897  vmovaps xmm10, [rsp+0xA0]
00007981ddfd48a0  vmovaps xmm11, [rsp+0xB0]
00007981ddfd48a9  vmovaps xmm12, [rsp+0xC0]
00007981ddfd48b2  vmovaps xmm13, [rsp+0xD0]
00007981ddfd48bb  vmovaps xmm15, [rsp+0xE0]
00007981ddfd48c4  add rsp, 0xF0
00007981ddfd48cb  pop r11
00007981ddfd48cd  pop r10
00007981ddfd48cf  pop r9
00007981ddfd48d1  pop r8
00007981ddfd48d3  pop rsi
00007981ddfd48d4  pop rdi
00007981ddfd48d5  pop rdx
00007981ddfd48d6  pop rcx
00007981ddfd48d7  pop rax
00007981ddfd48d8  add rsp, 0x08
00007981ddfd48dc  jmp 0x00007981DDFD2B05
00007981ddfd48e1  sub rsp, 0x08
00007981ddfd48e5  push rax
00007981ddfd48e6  push rcx
00007981ddfd48e7  push rdx
00007981ddfd48e8  push rdi
00007981ddfd48e9  push rsi
00007981ddfd48ea  push r8
00007981ddfd48ec  push r9
00007981ddfd48ee  push r10
00007981ddfd48f0  push r11
00007981ddfd48f2  sub rsp, 0xF0
00007981ddfd48f9  vmovaps [rsp], xmm0
00007981ddfd48fe  vmovaps [rsp+0x10], xmm1
00007981ddfd4904  vmovaps [rsp+0x20], xmm2
00007981ddfd490a  vmovaps [rsp+0x30], xmm3
00007981ddfd4910  vmovaps [rsp+0x40], xmm4
00007981ddfd4916  vmovaps [rsp+0x50], xmm5
00007981ddfd491c  vmovaps [rsp+0x60], xmm6
00007981ddfd4922  vmovaps [rsp+0x70], xmm7
00007981ddfd4928  vmovaps [rsp+0x80], xmm8
00007981ddfd4931  vmovaps [rsp+0x90], xmm9
00007981ddfd493a  vmovaps [rsp+0xA0], xmm10
00007981ddfd4943  vmovaps [rsp+0xB0], xmm11
00007981ddfd494c  vmovaps [rsp+0xC0], xmm12
00007981ddfd4955  vmovaps [rsp+0xD0], xmm13
00007981ddfd495e  vmovaps [rsp+0xE0], xmm14
00007981ddfd4967  sub rsp, 0x30
00007981ddfd496b  movaps [rsp], xmm15
00007981ddfd4970  movaps [rsp+0x10], xmm2
00007981ddfd4975  movaps [rsp+0x20], xmm1
00007981ddfd497a  lea rdi, [rsp]
00007981ddfd497e  mov esi, 0x00
00007981ddfd4983  mov rax, 0x5782A6EB3530
00007981ddfd498d  call rax
00007981ddfd498f  movaps xmm15, [rsp]
00007981ddfd4994  add rsp, 0x30
00007981ddfd4998  vmovaps xmm0, [rsp]
00007981ddfd499d  vmovaps xmm1, [rsp+0x10]
00007981ddfd49a3  vmovaps xmm2, [rsp+0x20]
00007981ddfd49a9  vmovaps xmm3, [rsp+0x30]
00007981ddfd49af  vmovaps xmm4, [rsp+0x40]
00007981ddfd49b5  vmovaps xmm5, [rsp+0x50]
00007981ddfd49bb  vmovaps xmm6, [rsp+0x60]
00007981ddfd49c1  vmovaps xmm7, [rsp+0x70]
00007981ddfd49c7  vmovaps xmm8, [rsp+0x80]
00007981ddfd49d0  vmovaps xmm9, [rsp+0x90]
00007981ddfd49d9  vmovaps xmm10, [rsp+0xA0]
00007981ddfd49e2  vmovaps xmm11, [rsp+0xB0]
00007981ddfd49eb  vmovaps xmm12, [rsp+0xC0]
00007981ddfd49f4  vmovaps xmm13, [rsp+0xD0]
00007981ddfd49fd  vmovaps xmm14, [rsp+0xE0]
00007981ddfd4a06  add rsp, 0xF0
00007981ddfd4a0d  pop r11
00007981ddfd4a0f  pop r10
00007981ddfd4a11  pop r9
00007981ddfd4a13  pop r8
00007981ddfd4a15  pop rsi
00007981ddfd4a16  pop rdi
00007981ddfd4a17  pop rdx
00007981ddfd4a18  pop rcx
00007981ddfd4a19  pop rax
00007981ddfd4a1a  add rsp, 0x08
00007981ddfd4a1e  jmp 0x00007981DDFD2B41
00007981ddfd4a23  call 0x00007981DDDFF430
00007981ddfd4a28  jmp 0x00007981DDFD2B4E
00007981ddfd4a2d  sub rsp, 0x08
00007981ddfd4a31  push rax
00007981ddfd4a32  push rcx
00007981ddfd4a33  push rdx
00007981ddfd4a34  push rdi
00007981ddfd4a35  push rsi
00007981ddfd4a36  push r8
00007981ddfd4a38  push r9
00007981ddfd4a3a  push r10
00007981ddfd4a3c  push r11
00007981ddfd4a3e  sub rsp, 0xF0
00007981ddfd4a45  vmovaps [rsp], xmm0
00007981ddfd4a4a  vmovaps [rsp+0x10], xmm1
00007981ddfd4a50  vmovaps [rsp+0x20], xmm3
00007981ddfd4a56  vmovaps [rsp+0x30], xmm4
00007981ddfd4a5c  vmovaps [rsp+0x40], xmm5
00007981ddfd4a62  vmovaps [rsp+0x50], xmm6
00007981ddfd4a68  vmovaps [rsp+0x60], xmm7
00007981ddfd4a6e  vmovaps [rsp+0x70], xmm8
00007981ddfd4a74  vmovaps [rsp+0x80], xmm9
00007981ddfd4a7d  vmovaps [rsp+0x90], xmm10
00007981ddfd4a86  vmovaps [rsp+0xA0], xmm11
00007981ddfd4a8f  vmovaps [rsp+0xB0], xmm12
00007981ddfd4a98  vmovaps [rsp+0xC0], xmm13
00007981ddfd4aa1  vmovaps [rsp+0xD0], xmm14
00007981ddfd4aaa  vmovaps [rsp+0xE0], xmm15
00007981ddfd4ab3  sub rsp, 0x30
00007981ddfd4ab7  movaps [rsp], xmm2
00007981ddfd4abb  movaps [rsp+0x10], xmm1
00007981ddfd4ac0  movaps [rsp+0x20], xmm14
00007981ddfd4ac6  lea rdi, [rsp]
00007981ddfd4aca  mov esi, 0x00
00007981ddfd4acf  mov rax, 0x5782A6EB3530
00007981ddfd4ad9  call rax
00007981ddfd4adb  movaps xmm2, [rsp]
00007981ddfd4adf  add rsp, 0x30
00007981ddfd4ae3  vmovaps xmm0, [rsp]
00007981ddfd4ae8  vmovaps xmm1, [rsp+0x10]
00007981ddfd4aee  vmovaps xmm3, [rsp+0x20]
00007981ddfd4af4  vmovaps xmm4, [rsp+0x30]
00007981ddfd4afa  vmovaps xmm5, [rsp+0x40]
00007981ddfd4b00  vmovaps xmm6, [rsp+0x50]
00007981ddfd4b06  vmovaps xmm7, [rsp+0x60]
00007981ddfd4b0c  vmovaps xmm8, [rsp+0x70]
00007981ddfd4b12  vmovaps xmm9, [rsp+0x80]
00007981ddfd4b1b  vmovaps xmm10, [rsp+0x90]
00007981ddfd4b24  vmovaps xmm11, [rsp+0xA0]
00007981ddfd4b2d  vmovaps xmm12, [rsp+0xB0]
00007981ddfd4b36  vmovaps xmm13, [rsp+0xC0]
00007981ddfd4b3f  vmovaps xmm14, [rsp+0xD0]
00007981ddfd4b48  vmovaps xmm15, [rsp+0xE0]
00007981ddfd4b51  add rsp, 0xF0
00007981ddfd4b58  pop r11
00007981ddfd4b5a  pop r10
00007981ddfd4b5c  pop r9
00007981ddfd4b5e  pop r8
00007981ddfd4b60  pop rsi
00007981ddfd4b61  pop rdi
00007981ddfd4b62  pop rdx
00007981ddfd4b63  pop rcx
00007981ddfd4b64  pop rax
00007981ddfd4b65  add rsp, 0x08
00007981ddfd4b69  jmp 0x00007981DDFD2B8B
00007981ddfd4b6e  sub rsp, 0x08
00007981ddfd4b72  push rax
00007981ddfd4b73  push rcx
00007981ddfd4b74  push rdx
00007981ddfd4b75  push rdi
00007981ddfd4b76  push rsi
00007981ddfd4b77  push r8
00007981ddfd4b79  push r9
00007981ddfd4b7b  push r10
00007981ddfd4b7d  push r11
00007981ddfd4b7f  sub rsp, 0xF0
00007981ddfd4b86  vmovaps [rsp], xmm0
00007981ddfd4b8b  vmovaps [rsp+0x10], xmm1
00007981ddfd4b91  vmovaps [rsp+0x20], xmm2
00007981ddfd4b97  vmovaps [rsp+0x30], xmm3
00007981ddfd4b9d  vmovaps [rsp+0x40], xmm4
00007981ddfd4ba3  vmovaps [rsp+0x50], xmm5
00007981ddfd4ba9  vmovaps [rsp+0x60], xmm6
00007981ddfd4baf  vmovaps [rsp+0x70], xmm7
00007981ddfd4bb5  vmovaps [rsp+0x80], xmm8
00007981ddfd4bbe  vmovaps [rsp+0x90], xmm9
00007981ddfd4bc7  vmovaps [rsp+0xA0], xmm10
00007981ddfd4bd0  vmovaps [rsp+0xB0], xmm11
00007981ddfd4bd9  vmovaps [rsp+0xC0], xmm12
00007981ddfd4be2  vmovaps [rsp+0xD0], xmm13
00007981ddfd4beb  vmovaps [rsp+0xE0], xmm14
00007981ddfd4bf4  sub rsp, 0x30
00007981ddfd4bf8  movaps [rsp], xmm15
00007981ddfd4bfd  movaps [rsp+0x10], xmm14
00007981ddfd4c03  movaps [rsp+0x20], xmm1
00007981ddfd4c08  lea rdi, [rsp]
00007981ddfd4c0c  mov esi, 0x00
00007981ddfd4c11  mov rax, 0x5782A6EB3530
00007981ddfd4c1b  call rax
00007981ddfd4c1d  movaps xmm15, [rsp]
00007981ddfd4c22  add rsp, 0x30
00007981ddfd4c26  vmovaps xmm0, [rsp]
00007981ddfd4c2b  vmovaps xmm1, [rsp+0x10]
00007981ddfd4c31  vmovaps xmm2, [rsp+0x20]
00007981ddfd4c37  vmovaps xmm3, [rsp+0x30]
00007981ddfd4c3d  vmovaps xmm4, [rsp+0x40]
00007981ddfd4c43  vmovaps xmm5, [rsp+0x50]
00007981ddfd4c49  vmovaps xmm6, [rsp+0x60]
00007981ddfd4c4f  vmovaps xmm7, [rsp+0x70]
00007981ddfd4c55  vmovaps xmm8, [rsp+0x80]
00007981ddfd4c5e  vmovaps xmm9, [rsp+0x90]
00007981ddfd4c67  vmovaps xmm10, [rsp+0xA0]
00007981ddfd4c70  vmovaps xmm11, [rsp+0xB0]
00007981ddfd4c79  vmovaps xmm12, [rsp+0xC0]
00007981ddfd4c82  vmovaps xmm13, [rsp+0xD0]
00007981ddfd4c8b  vmovaps xmm14, [rsp+0xE0]
00007981ddfd4c94  add rsp, 0xF0
00007981ddfd4c9b  pop r11
00007981ddfd4c9d  pop r10
00007981ddfd4c9f  pop r9
00007981ddfd4ca1  pop r8
00007981ddfd4ca3  pop rsi
00007981ddfd4ca4  pop rdi
00007981ddfd4ca5  pop rdx
00007981ddfd4ca6  pop rcx
00007981ddfd4ca7  pop rax
00007981ddfd4ca8  add rsp, 0x08
00007981ddfd4cac  jmp 0x00007981DDFD2C05
00007981ddfd4cb1  call 0x00007981DDDFF430
00007981ddfd4cb6  jmp 0x00007981DDFD2C12
00007981ddfd4cbb  sub rsp, 0x08
00007981ddfd4cbf  push rax
00007981ddfd4cc0  push rcx
00007981ddfd4cc1  push rdx
00007981ddfd4cc2  push rdi
00007981ddfd4cc3  push rsi
00007981ddfd4cc4  push r8
00007981ddfd4cc6  push r9
00007981ddfd4cc8  push r10
00007981ddfd4cca  push r11
00007981ddfd4ccc  sub rsp, 0xF0
00007981ddfd4cd3  vmovaps [rsp], xmm0
00007981ddfd4cd8  vmovaps [rsp+0x10], xmm1
00007981ddfd4cde  vmovaps [rsp+0x20], xmm2
00007981ddfd4ce4  vmovaps [rsp+0x30], xmm3
00007981ddfd4cea  vmovaps [rsp+0x40], xmm4
00007981ddfd4cf0  vmovaps [rsp+0x50], xmm5
00007981ddfd4cf6  vmovaps [rsp+0x60], xmm6
00007981ddfd4cfc  vmovaps [rsp+0x70], xmm7
00007981ddfd4d02  vmovaps [rsp+0x80], xmm8
00007981ddfd4d0b  vmovaps [rsp+0x90], xmm9
00007981ddfd4d14  vmovaps [rsp+0xA0], xmm10
00007981ddfd4d1d  vmovaps [rsp+0xB0], xmm11
00007981ddfd4d26  vmovaps [rsp+0xC0], xmm12
00007981ddfd4d2f  vmovaps [rsp+0xD0], xmm14
00007981ddfd4d38  vmovaps [rsp+0xE0], xmm15
00007981ddfd4d41  sub rsp, 0x30
00007981ddfd4d45  movaps [rsp], xmm13
00007981ddfd4d4a  movaps [rsp+0x10], xmm1
00007981ddfd4d4f  movaps [rsp+0x20], xmm15
00007981ddfd4d55  lea rdi, [rsp]
00007981ddfd4d59  mov esi, 0x00
00007981ddfd4d5e  mov rax, 0x5782A6EB3530
00007981ddfd4d68  call rax
00007981ddfd4d6a  movaps xmm13, [rsp]
00007981ddfd4d6f  add rsp, 0x30
00007981ddfd4d73  vmovaps xmm0, [rsp]
00007981ddfd4d78  vmovaps xmm1, [rsp+0x10]
00007981ddfd4d7e  vmovaps xmm2, [rsp+0x20]
00007981ddfd4d84  vmovaps xmm3, [rsp+0x30]
00007981ddfd4d8a  vmovaps xmm4, [rsp+0x40]
00007981ddfd4d90  vmovaps xmm5, [rsp+0x50]
00007981ddfd4d96  vmovaps xmm6, [rsp+0x60]
00007981ddfd4d9c  vmovaps xmm7, [rsp+0x70]
00007981ddfd4da2  vmovaps xmm8, [rsp+0x80]
00007981ddfd4dab  vmovaps xmm9, [rsp+0x90]
00007981ddfd4db4  vmovaps xmm10, [rsp+0xA0]
00007981ddfd4dbd  vmovaps xmm11, [rsp+0xB0]
00007981ddfd4dc6  vmovaps xmm12, [rsp+0xC0]
00007981ddfd4dcf  vmovaps xmm14, [rsp+0xD0]
00007981ddfd4dd8  vmovaps xmm15, [rsp+0xE0]
00007981ddfd4de1  add rsp, 0xF0
00007981ddfd4de8  pop r11
00007981ddfd4dea  pop r10
00007981ddfd4dec  pop r9
00007981ddfd4dee  pop r8
00007981ddfd4df0  pop rsi
00007981ddfd4df1  pop rdi
00007981ddfd4df2  pop rdx
00007981ddfd4df3  pop rcx
00007981ddfd4df4  pop rax
00007981ddfd4df5  add rsp, 0x08
00007981ddfd4df9  jmp 0x00007981DDFD2CD6
00007981ddfd4dfe  sub rsp, 0x08
00007981ddfd4e02  push rax
00007981ddfd4e03  push rcx
00007981ddfd4e04  push rdx
00007981ddfd4e05  push rdi
00007981ddfd4e06  push rsi
00007981ddfd4e07  push r8
00007981ddfd4e09  push r9
00007981ddfd4e0b  push r10
00007981ddfd4e0d  push r11
00007981ddfd4e0f  sub rsp, 0xF0
00007981ddfd4e16  vmovaps [rsp], xmm0
00007981ddfd4e1b  vmovaps [rsp+0x10], xmm1
00007981ddfd4e21  vmovaps [rsp+0x20], xmm2
00007981ddfd4e27  vmovaps [rsp+0x30], xmm3
00007981ddfd4e2d  vmovaps [rsp+0x40], xmm4
00007981ddfd4e33  vmovaps [rsp+0x50], xmm5
00007981ddfd4e39  vmovaps [rsp+0x60], xmm6
00007981ddfd4e3f  vmovaps [rsp+0x70], xmm7
00007981ddfd4e45  vmovaps [rsp+0x80], xmm8
00007981ddfd4e4e  vmovaps [rsp+0x90], xmm9
00007981ddfd4e57  vmovaps [rsp+0xA0], xmm10
00007981ddfd4e60  vmovaps [rsp+0xB0], xmm11
00007981ddfd4e69  vmovaps [rsp+0xC0], xmm12
00007981ddfd4e72  vmovaps [rsp+0xD0], xmm13
00007981ddfd4e7b  vmovaps [rsp+0xE0], xmm14
00007981ddfd4e84  sub rsp, 0x30
00007981ddfd4e88  movaps [rsp], xmm15
00007981ddfd4e8d  movaps [rsp+0x10], xmm14
00007981ddfd4e93  movaps [rsp+0x20], xmm1
00007981ddfd4e98  lea rdi, [rsp]
00007981ddfd4e9c  mov esi, 0x00
00007981ddfd4ea1  mov rax, 0x5782A6EB3530
00007981ddfd4eab  call rax
00007981ddfd4ead  movaps xmm15, [rsp]
00007981ddfd4eb2  add rsp, 0x30
00007981ddfd4eb6  vmovaps xmm0, [rsp]
00007981ddfd4ebb  vmovaps xmm1, [rsp+0x10]
00007981ddfd4ec1  vmovaps xmm2, [rsp+0x20]
00007981ddfd4ec7  vmovaps xmm3, [rsp+0x30]
00007981ddfd4ecd  vmovaps xmm4, [rsp+0x40]
00007981ddfd4ed3  vmovaps xmm5, [rsp+0x50]
00007981ddfd4ed9  vmovaps xmm6, [rsp+0x60]
00007981ddfd4edf  vmovaps xmm7, [rsp+0x70]
00007981ddfd4ee5  vmovaps xmm8, [rsp+0x80]
00007981ddfd4eee  vmovaps xmm9, [rsp+0x90]
00007981ddfd4ef7  vmovaps xmm10, [rsp+0xA0]
00007981ddfd4f00  vmovaps xmm11, [rsp+0xB0]
00007981ddfd4f09  vmovaps xmm12, [rsp+0xC0]
00007981ddfd4f12  vmovaps xmm13, [rsp+0xD0]
00007981ddfd4f1b  vmovaps xmm14, [rsp+0xE0]
00007981ddfd4f24  add rsp, 0xF0
00007981ddfd4f2b  pop r11
00007981ddfd4f2d  pop r10
00007981ddfd4f2f  pop r9
00007981ddfd4f31  pop r8
00007981ddfd4f33  pop rsi
00007981ddfd4f34  pop rdi
00007981ddfd4f35  pop rdx
00007981ddfd4f36  pop rcx
00007981ddfd4f37  pop rax
00007981ddfd4f38  add rsp, 0x08
00007981ddfd4f3c  jmp 0x00007981DDFD2D12
00007981ddfd4f41  call 0x00007981DDDFF430
00007981ddfd4f46  jmp 0x00007981DDFD2D1F
00007981ddfd4f4b  sub rsp, 0x08
00007981ddfd4f4f  push rax
00007981ddfd4f50  push rcx
00007981ddfd4f51  push rdx
00007981ddfd4f52  push rdi
00007981ddfd4f53  push rsi
00007981ddfd4f54  push r8
00007981ddfd4f56  push r9
00007981ddfd4f58  push r10
00007981ddfd4f5a  push r11
00007981ddfd4f5c  sub rsp, 0xF0
00007981ddfd4f63  vmovaps [rsp], xmm0
00007981ddfd4f68  vmovaps [rsp+0x10], xmm1
00007981ddfd4f6e  vmovaps [rsp+0x20], xmm2
00007981ddfd4f74  vmovaps [rsp+0x30], xmm3
00007981ddfd4f7a  vmovaps [rsp+0x40], xmm4
00007981ddfd4f80  vmovaps [rsp+0x50], xmm5
00007981ddfd4f86  vmovaps [rsp+0x60], xmm6
00007981ddfd4f8c  vmovaps [rsp+0x70], xmm7
00007981ddfd4f92  vmovaps [rsp+0x80], xmm8
00007981ddfd4f9b  vmovaps [rsp+0x90], xmm9
00007981ddfd4fa4  vmovaps [rsp+0xA0], xmm10
00007981ddfd4fad  vmovaps [rsp+0xB0], xmm11
00007981ddfd4fb6  vmovaps [rsp+0xC0], xmm12
00007981ddfd4fbf  vmovaps [rsp+0xD0], xmm13
00007981ddfd4fc8  vmovaps [rsp+0xE0], xmm15
00007981ddfd4fd1  sub rsp, 0x30
00007981ddfd4fd5  movaps [rsp], xmm14
00007981ddfd4fda  movaps [rsp+0x10], xmm13
00007981ddfd4fe0  movaps [rsp+0x20], xmm2
00007981ddfd4fe5  lea rdi, [rsp]
00007981ddfd4fe9  mov esi, 0x00
00007981ddfd4fee  mov rax, 0x5782A6EB3530
00007981ddfd4ff8  call rax
00007981ddfd4ffa  movaps xmm14, [rsp]
00007981ddfd4fff  add rsp, 0x30
00007981ddfd5003  vmovaps xmm0, [rsp]
00007981ddfd5008  vmovaps xmm1, [rsp+0x10]
00007981ddfd500e  vmovaps xmm2, [rsp+0x20]
00007981ddfd5014  vmovaps xmm3, [rsp+0x30]
00007981ddfd501a  vmovaps xmm4, [rsp+0x40]
00007981ddfd5020  vmovaps xmm5, [rsp+0x50]
00007981ddfd5026  vmovaps xmm6, [rsp+0x60]
00007981ddfd502c  vmovaps xmm7, [rsp+0x70]
00007981ddfd5032  vmovaps xmm8, [rsp+0x80]
00007981ddfd503b  vmovaps xmm9, [rsp+0x90]
00007981ddfd5044  vmovaps xmm10, [rsp+0xA0]
00007981ddfd504d  vmovaps xmm11, [rsp+0xB0]
00007981ddfd5056  vmovaps xmm12, [rsp+0xC0]
00007981ddfd505f  vmovaps xmm13, [rsp+0xD0]
00007981ddfd5068  vmovaps xmm15, [rsp+0xE0]
00007981ddfd5071  add rsp, 0xF0
00007981ddfd5078  pop r11
00007981ddfd507a  pop r10
00007981ddfd507c  pop r9
00007981ddfd507e  pop r8
00007981ddfd5080  pop rsi
00007981ddfd5081  pop rdi
00007981ddfd5082  pop rdx
00007981ddfd5083  pop rcx
00007981ddfd5084  pop rax
00007981ddfd5085  add rsp, 0x08
00007981ddfd5089  jmp 0x00007981DDFD2D4B
00007981ddfd508e  sub rsp, 0x08
00007981ddfd5092  push rax
00007981ddfd5093  push rcx
00007981ddfd5094  push rdx
00007981ddfd5095  push rdi
00007981ddfd5096  push rsi
00007981ddfd5097  push r8
00007981ddfd5099  push r9
00007981ddfd509b  push r10
00007981ddfd509d  push r11
00007981ddfd509f  sub rsp, 0xF0
00007981ddfd50a6  vmovaps [rsp], xmm0
00007981ddfd50ab  vmovaps [rsp+0x10], xmm2
00007981ddfd50b1  vmovaps [rsp+0x20], xmm3
00007981ddfd50b7  vmovaps [rsp+0x30], xmm4
00007981ddfd50bd  vmovaps [rsp+0x40], xmm5
00007981ddfd50c3  vmovaps [rsp+0x50], xmm6
00007981ddfd50c9  vmovaps [rsp+0x60], xmm7
00007981ddfd50cf  vmovaps [rsp+0x70], xmm8
00007981ddfd50d5  vmovaps [rsp+0x80], xmm9
00007981ddfd50de  vmovaps [rsp+0x90], xmm10
00007981ddfd50e7  vmovaps [rsp+0xA0], xmm11
00007981ddfd50f0  vmovaps [rsp+0xB0], xmm12
00007981ddfd50f9  vmovaps [rsp+0xC0], xmm13
00007981ddfd5102  vmovaps [rsp+0xD0], xmm14
00007981ddfd510b  vmovaps [rsp+0xE0], xmm15
00007981ddfd5114  sub rsp, 0x30
00007981ddfd5118  movaps [rsp], xmm1
00007981ddfd511c  movaps [rsp+0x10], xmm13
00007981ddfd5122  movaps [rsp+0x20], xmm2
00007981ddfd5127  lea rdi, [rsp]
00007981ddfd512b  mov esi, 0x00
00007981ddfd5130  mov rax, 0x5782A6EB3530
00007981ddfd513a  call rax
00007981ddfd513c  movaps xmm1, [rsp]
00007981ddfd5140  add rsp, 0x30
00007981ddfd5144  vmovaps xmm0, [rsp]
00007981ddfd5149  vmovaps xmm2, [rsp+0x10]
00007981ddfd514f  vmovaps xmm3, [rsp+0x20]
00007981ddfd5155  vmovaps xmm4, [rsp+0x30]
00007981ddfd515b  vmovaps xmm5, [rsp+0x40]
00007981ddfd5161  vmovaps xmm6, [rsp+0x50]
00007981ddfd5167  vmovaps xmm7, [rsp+0x60]
00007981ddfd516d  vmovaps xmm8, [rsp+0x70]
00007981ddfd5173  vmovaps xmm9, [rsp+0x80]
00007981ddfd517c  vmovaps xmm10, [rsp+0x90]
00007981ddfd5185  vmovaps xmm11, [rsp+0xA0]
00007981ddfd518e  vmovaps xmm12, [rsp+0xB0]
00007981ddfd5197  vmovaps xmm13, [rsp+0xC0]
00007981ddfd51a0  vmovaps xmm14, [rsp+0xD0]
00007981ddfd51a9  vmovaps xmm15, [rsp+0xE0]
00007981ddfd51b2  add rsp, 0xF0
00007981ddfd51b9  pop r11
00007981ddfd51bb  pop r10
00007981ddfd51bd  pop r9
00007981ddfd51bf  pop r8
00007981ddfd51c1  pop rsi
00007981ddfd51c2  pop rdi
00007981ddfd51c3  pop rdx
00007981ddfd51c4  pop rcx
00007981ddfd51c5  pop rax
00007981ddfd51c6  add rsp, 0x08
00007981ddfd51ca  jmp 0x00007981DDFD2D79
00007981ddfd51cf  sub rsp, 0x08
00007981ddfd51d3  push rax
00007981ddfd51d4  push rcx
00007981ddfd51d5  push rdx
00007981ddfd51d6  push rdi
00007981ddfd51d7  push rsi
00007981ddfd51d8  push r8
00007981ddfd51da  push r9
00007981ddfd51dc  push r10
00007981ddfd51de  push r11
00007981ddfd51e0  sub rsp, 0xF0
00007981ddfd51e7  vmovaps [rsp], xmm0
00007981ddfd51ec  vmovaps [rsp+0x10], xmm1
00007981ddfd51f2  vmovaps [rsp+0x20], xmm3
00007981ddfd51f8  vmovaps [rsp+0x30], xmm4
00007981ddfd51fe  vmovaps [rsp+0x40], xmm5
00007981ddfd5204  vmovaps [rsp+0x50], xmm6
00007981ddfd520a  vmovaps [rsp+0x60], xmm7
00007981ddfd5210  vmovaps [rsp+0x70], xmm8
00007981ddfd5216  vmovaps [rsp+0x80], xmm9
00007981ddfd521f  vmovaps [rsp+0x90], xmm10
00007981ddfd5228  vmovaps [rsp+0xA0], xmm11
00007981ddfd5231  vmovaps [rsp+0xB0], xmm12
00007981ddfd523a  vmovaps [rsp+0xC0], xmm13
00007981ddfd5243  vmovaps [rsp+0xD0], xmm14
00007981ddfd524c  vmovaps [rsp+0xE0], xmm15
00007981ddfd5255  sub rsp, 0x30
00007981ddfd5259  movaps [rsp], xmm2
00007981ddfd525d  movaps [rsp+0x10], xmm1
00007981ddfd5262  movaps [rsp+0x20], xmm13
00007981ddfd5268  lea rdi, [rsp]
00007981ddfd526c  mov esi, 0x00
00007981ddfd5271  mov rax, 0x5782A6EB3530
00007981ddfd527b  call rax
00007981ddfd527d  movaps xmm2, [rsp]
00007981ddfd5281  add rsp, 0x30
00007981ddfd5285  vmovaps xmm0, [rsp]
00007981ddfd528a  vmovaps xmm1, [rsp+0x10]
00007981ddfd5290  vmovaps xmm3, [rsp+0x20]
00007981ddfd5296  vmovaps xmm4, [rsp+0x30]
00007981ddfd529c  vmovaps xmm5, [rsp+0x40]
00007981ddfd52a2  vmovaps xmm6, [rsp+0x50]
00007981ddfd52a8  vmovaps xmm7, [rsp+0x60]
00007981ddfd52ae  vmovaps xmm8, [rsp+0x70]
00007981ddfd52b4  vmovaps xmm9, [rsp+0x80]
00007981ddfd52bd  vmovaps xmm10, [rsp+0x90]
00007981ddfd52c6  vmovaps xmm11, [rsp+0xA0]
00007981ddfd52cf  vmovaps xmm12, [rsp+0xB0]
00007981ddfd52d8  vmovaps xmm13, [rsp+0xC0]
00007981ddfd52e1  vmovaps xmm14, [rsp+0xD0]
00007981ddfd52ea  vmovaps xmm15, [rsp+0xE0]
00007981ddfd52f3  add rsp, 0xF0
00007981ddfd52fa  pop r11
00007981ddfd52fc  pop r10
00007981ddfd52fe  pop r9
00007981ddfd5300  pop r8
00007981ddfd5302  pop rsi
00007981ddfd5303  pop rdi
00007981ddfd5304  pop rdx
00007981ddfd5305  pop rcx
00007981ddfd5306  pop rax
00007981ddfd5307  add rsp, 0x08
00007981ddfd530b  jmp 0x00007981DDFD2DD2
00007981ddfd5310  call 0x00007981DDDFF430
00007981ddfd5315  jmp 0x00007981DDFD2DDF
00007981ddfd531a  sub rsp, 0x08
00007981ddfd531e  push rax
00007981ddfd531f  push rcx
00007981ddfd5320  push rdx
00007981ddfd5321  push rdi
00007981ddfd5322  push rsi
00007981ddfd5323  push r8
00007981ddfd5325  push r9
00007981ddfd5327  push r10
00007981ddfd5329  push r11
00007981ddfd532b  sub rsp, 0xF0
00007981ddfd5332  vmovaps [rsp], xmm0
00007981ddfd5337  vmovaps [rsp+0x10], xmm1
00007981ddfd533d  vmovaps [rsp+0x20], xmm2
00007981ddfd5343  vmovaps [rsp+0x30], xmm3
00007981ddfd5349  vmovaps [rsp+0x40], xmm4
00007981ddfd534f  vmovaps [rsp+0x50], xmm5
00007981ddfd5355  vmovaps [rsp+0x60], xmm6
00007981ddfd535b  vmovaps [rsp+0x70], xmm7
00007981ddfd5361  vmovaps [rsp+0x80], xmm8
00007981ddfd536a  vmovaps [rsp+0x90], xmm9
00007981ddfd5373  vmovaps [rsp+0xA0], xmm10
00007981ddfd537c  vmovaps [rsp+0xB0], xmm11
00007981ddfd5385  vmovaps [rsp+0xC0], xmm12
00007981ddfd538e  vmovaps [rsp+0xD0], xmm13
00007981ddfd5397  vmovaps [rsp+0xE0], xmm14
00007981ddfd53a0  sub rsp, 0x30
00007981ddfd53a4  movaps [rsp], xmm15
00007981ddfd53a9  movaps [rsp+0x10], xmm13
00007981ddfd53af  movaps [rsp+0x20], xmm1
00007981ddfd53b4  lea rdi, [rsp]
00007981ddfd53b8  mov esi, 0x00
00007981ddfd53bd  mov rax, 0x5782A6EB3530
00007981ddfd53c7  call rax
00007981ddfd53c9  movaps xmm15, [rsp]
00007981ddfd53ce  add rsp, 0x30
00007981ddfd53d2  vmovaps xmm0, [rsp]
00007981ddfd53d7  vmovaps xmm1, [rsp+0x10]
00007981ddfd53dd  vmovaps xmm2, [rsp+0x20]
00007981ddfd53e3  vmovaps xmm3, [rsp+0x30]
00007981ddfd53e9  vmovaps xmm4, [rsp+0x40]
00007981ddfd53ef  vmovaps xmm5, [rsp+0x50]
00007981ddfd53f5  vmovaps xmm6, [rsp+0x60]
00007981ddfd53fb  vmovaps xmm7, [rsp+0x70]
00007981ddfd5401  vmovaps xmm8, [rsp+0x80]
00007981ddfd540a  vmovaps xmm9, [rsp+0x90]
00007981ddfd5413  vmovaps xmm10, [rsp+0xA0]
00007981ddfd541c  vmovaps xmm11, [rsp+0xB0]
00007981ddfd5425  vmovaps xmm12, [rsp+0xC0]
00007981ddfd542e  vmovaps xmm13, [rsp+0xD0]
00007981ddfd5437  vmovaps xmm14, [rsp+0xE0]
00007981ddfd5440  add rsp, 0xF0
00007981ddfd5447  pop r11
00007981ddfd5449  pop r10
00007981ddfd544b  pop r9
00007981ddfd544d  pop r8
00007981ddfd544f  pop rsi
00007981ddfd5450  pop rdi
00007981ddfd5451  pop rdx
00007981ddfd5452  pop rcx
00007981ddfd5453  pop rax
00007981ddfd5454  add rsp, 0x08
00007981ddfd5458  jmp 0x00007981DDFD2E1E
00007981ddfd545d  sub rsp, 0x08
00007981ddfd5461  push rax
00007981ddfd5462  push rcx
00007981ddfd5463  push rdx
00007981ddfd5464  push rdi
00007981ddfd5465  push rsi
00007981ddfd5466  push r8
00007981ddfd5468  push r9
00007981ddfd546a  push r10
00007981ddfd546c  push r11
00007981ddfd546e  sub rsp, 0xF0
00007981ddfd5475  vmovaps [rsp], xmm0
00007981ddfd547a  vmovaps [rsp+0x10], xmm1
00007981ddfd5480  vmovaps [rsp+0x20], xmm2
00007981ddfd5486  vmovaps [rsp+0x30], xmm3
00007981ddfd548c  vmovaps [rsp+0x40], xmm4
00007981ddfd5492  vmovaps [rsp+0x50], xmm5
00007981ddfd5498  vmovaps [rsp+0x60], xmm6
00007981ddfd549e  vmovaps [rsp+0x70], xmm7
00007981ddfd54a4  vmovaps [rsp+0x80], xmm8
00007981ddfd54ad  vmovaps [rsp+0x90], xmm9
00007981ddfd54b6  vmovaps [rsp+0xA0], xmm10
00007981ddfd54bf  vmovaps [rsp+0xB0], xmm11
00007981ddfd54c8  vmovaps [rsp+0xC0], xmm12
00007981ddfd54d1  vmovaps [rsp+0xD0], xmm13
00007981ddfd54da  vmovaps [rsp+0xE0], xmm15
00007981ddfd54e3  sub rsp, 0x30
00007981ddfd54e7  movaps [rsp], xmm14
00007981ddfd54ec  movaps [rsp+0x10], xmm11
00007981ddfd54f2  movaps [rsp+0x20], xmm1
00007981ddfd54f7  lea rdi, [rsp]
00007981ddfd54fb  mov esi, 0x00
00007981ddfd5500  mov rax, 0x5782A6EB3530
00007981ddfd550a  call rax
00007981ddfd550c  movaps xmm14, [rsp]
00007981ddfd5511  add rsp, 0x30
00007981ddfd5515  vmovaps xmm0, [rsp]
00007981ddfd551a  vmovaps xmm1, [rsp+0x10]
00007981ddfd5520  vmovaps xmm2, [rsp+0x20]
00007981ddfd5526  vmovaps xmm3, [rsp+0x30]
00007981ddfd552c  vmovaps xmm4, [rsp+0x40]
00007981ddfd5532  vmovaps xmm5, [rsp+0x50]
00007981ddfd5538  vmovaps xmm6, [rsp+0x60]
00007981ddfd553e  vmovaps xmm7, [rsp+0x70]
00007981ddfd5544  vmovaps xmm8, [rsp+0x80]
00007981ddfd554d  vmovaps xmm9, [rsp+0x90]
00007981ddfd5556  vmovaps xmm10, [rsp+0xA0]
00007981ddfd555f  vmovaps xmm11, [rsp+0xB0]
00007981ddfd5568  vmovaps xmm12, [rsp+0xC0]
00007981ddfd5571  vmovaps xmm13, [rsp+0xD0]
00007981ddfd557a  vmovaps xmm15, [rsp+0xE0]
00007981ddfd5583  add rsp, 0xF0
00007981ddfd558a  pop r11
00007981ddfd558c  pop r10
00007981ddfd558e  pop r9
00007981ddfd5590  pop r8
00007981ddfd5592  pop rsi
00007981ddfd5593  pop rdi
00007981ddfd5594  pop rdx
00007981ddfd5595  pop rcx
00007981ddfd5596  pop rax
00007981ddfd5597  add rsp, 0x08
00007981ddfd559b  jmp 0x00007981DDFD2E48
00007981ddfd55a0  sub rsp, 0x08
00007981ddfd55a4  push rax
00007981ddfd55a5  push rcx
00007981ddfd55a6  push rdx
00007981ddfd55a7  push rdi
00007981ddfd55a8  push rsi
00007981ddfd55a9  push r8
00007981ddfd55ab  push r9
00007981ddfd55ad  push r10
00007981ddfd55af  push r11
00007981ddfd55b1  sub rsp, 0xF0
00007981ddfd55b8  vmovaps [rsp], xmm0
00007981ddfd55bd  vmovaps [rsp+0x10], xmm1
00007981ddfd55c3  vmovaps [rsp+0x20], xmm2
00007981ddfd55c9  vmovaps [rsp+0x30], xmm3
00007981ddfd55cf  vmovaps [rsp+0x40], xmm4
00007981ddfd55d5  vmovaps [rsp+0x50], xmm5
00007981ddfd55db  vmovaps [rsp+0x60], xmm6
00007981ddfd55e1  vmovaps [rsp+0x70], xmm7
00007981ddfd55e7  vmovaps [rsp+0x80], xmm8
00007981ddfd55f0  vmovaps [rsp+0x90], xmm9
00007981ddfd55f9  vmovaps [rsp+0xA0], xmm10
00007981ddfd5602  vmovaps [rsp+0xB0], xmm11
00007981ddfd560b  vmovaps [rsp+0xC0], xmm12
00007981ddfd5614  vmovaps [rsp+0xD0], xmm14
00007981ddfd561d  vmovaps [rsp+0xE0], xmm15
00007981ddfd5626  sub rsp, 0x30
00007981ddfd562a  movaps [rsp], xmm13
00007981ddfd562f  movaps [rsp+0x10], xmm11
00007981ddfd5635  movaps [rsp+0x20], xmm1
00007981ddfd563a  lea rdi, [rsp]
00007981ddfd563e  mov esi, 0x00
00007981ddfd5643  mov rax, 0x5782A6EB3530
00007981ddfd564d  call rax
00007981ddfd564f  movaps xmm13, [rsp]
00007981ddfd5654  add rsp, 0x30
00007981ddfd5658  vmovaps xmm0, [rsp]
00007981ddfd565d  vmovaps xmm1, [rsp+0x10]
00007981ddfd5663  vmovaps xmm2, [rsp+0x20]
00007981ddfd5669  vmovaps xmm3, [rsp+0x30]
00007981ddfd566f  vmovaps xmm4, [rsp+0x40]
00007981ddfd5675  vmovaps xmm5, [rsp+0x50]
00007981ddfd567b  vmovaps xmm6, [rsp+0x60]
00007981ddfd5681  vmovaps xmm7, [rsp+0x70]
00007981ddfd5687  vmovaps xmm8, [rsp+0x80]
00007981ddfd5690  vmovaps xmm9, [rsp+0x90]
00007981ddfd5699  vmovaps xmm10, [rsp+0xA0]
00007981ddfd56a2  vmovaps xmm11, [rsp+0xB0]
00007981ddfd56ab  vmovaps xmm12, [rsp+0xC0]
00007981ddfd56b4  vmovaps xmm14, [rsp+0xD0]
00007981ddfd56bd  vmovaps xmm15, [rsp+0xE0]
00007981ddfd56c6  add rsp, 0xF0
00007981ddfd56cd  pop r11
00007981ddfd56cf  pop r10
00007981ddfd56d1  pop r9
00007981ddfd56d3  pop r8
00007981ddfd56d5  pop rsi
00007981ddfd56d6  pop rdi
00007981ddfd56d7  pop rdx
00007981ddfd56d8  pop rcx
00007981ddfd56d9  pop rax
00007981ddfd56da  add rsp, 0x08
00007981ddfd56de  jmp 0x00007981DDFD2E9D
00007981ddfd56e3  call 0x00007981DDDFF430
00007981ddfd56e8  jmp 0x00007981DDFD2EAA
00007981ddfd56ed  sub rsp, 0x08
00007981ddfd56f1  push rax
00007981ddfd56f2  push rcx
00007981ddfd56f3  push rdx
00007981ddfd56f4  push rdi
00007981ddfd56f5  push rsi
00007981ddfd56f6  push r8
00007981ddfd56f8  push r9
00007981ddfd56fa  push r10
00007981ddfd56fc  push r11
00007981ddfd56fe  sub rsp, 0xF0
00007981ddfd5705  vmovaps [rsp], xmm0
00007981ddfd570a  vmovaps [rsp+0x10], xmm1
00007981ddfd5710  vmovaps [rsp+0x20], xmm2
00007981ddfd5716  vmovaps [rsp+0x30], xmm3
00007981ddfd571c  vmovaps [rsp+0x40], xmm4
00007981ddfd5722  vmovaps [rsp+0x50], xmm5
00007981ddfd5728  vmovaps [rsp+0x60], xmm6
00007981ddfd572e  vmovaps [rsp+0x70], xmm7
00007981ddfd5734  vmovaps [rsp+0x80], xmm8
00007981ddfd573d  vmovaps [rsp+0x90], xmm9
00007981ddfd5746  vmovaps [rsp+0xA0], xmm10
00007981ddfd574f  vmovaps [rsp+0xB0], xmm11
00007981ddfd5758  vmovaps [rsp+0xC0], xmm12
00007981ddfd5761  vmovaps [rsp+0xD0], xmm13
00007981ddfd576a  vmovaps [rsp+0xE0], xmm14
00007981ddfd5773  sub rsp, 0x30
00007981ddfd5777  movaps [rsp], xmm15
00007981ddfd577c  movaps [rsp+0x10], xmm11
00007981ddfd5782  movaps [rsp+0x20], xmm1
00007981ddfd5787  lea rdi, [rsp]
00007981ddfd578b  mov esi, 0x00
00007981ddfd5790  mov rax, 0x5782A6EB3530
00007981ddfd579a  call rax
00007981ddfd579c  movaps xmm15, [rsp]
00007981ddfd57a1  add rsp, 0x30
00007981ddfd57a5  vmovaps xmm0, [rsp]
00007981ddfd57aa  vmovaps xmm1, [rsp+0x10]
00007981ddfd57b0  vmovaps xmm2, [rsp+0x20]
00007981ddfd57b6  vmovaps xmm3, [rsp+0x30]
00007981ddfd57bc  vmovaps xmm4, [rsp+0x40]
00007981ddfd57c2  vmovaps xmm5, [rsp+0x50]
00007981ddfd57c8  vmovaps xmm6, [rsp+0x60]
00007981ddfd57ce  vmovaps xmm7, [rsp+0x70]
00007981ddfd57d4  vmovaps xmm8, [rsp+0x80]
00007981ddfd57dd  vmovaps xmm9, [rsp+0x90]
00007981ddfd57e6  vmovaps xmm10, [rsp+0xA0]
00007981ddfd57ef  vmovaps xmm11, [rsp+0xB0]
00007981ddfd57f8  vmovaps xmm12, [rsp+0xC0]
00007981ddfd5801  vmovaps xmm13, [rsp+0xD0]
00007981ddfd580a  vmovaps xmm14, [rsp+0xE0]
00007981ddfd5813  add rsp, 0xF0
00007981ddfd581a  pop r11
00007981ddfd581c  pop r10
00007981ddfd581e  pop r9
00007981ddfd5820  pop r8
00007981ddfd5822  pop rsi
00007981ddfd5823  pop rdi
00007981ddfd5824  pop rdx
00007981ddfd5825  pop rcx
00007981ddfd5826  pop rax
00007981ddfd5827  add rsp, 0x08
00007981ddfd582b  jmp 0x00007981DDFD2EE3
00007981ddfd5830  sub rsp, 0x08
00007981ddfd5834  push rax
00007981ddfd5835  push rcx
00007981ddfd5836  push rdx
00007981ddfd5837  push rdi
00007981ddfd5838  push rsi
00007981ddfd5839  push r8
00007981ddfd583b  push r9
00007981ddfd583d  push r10
00007981ddfd583f  push r11
00007981ddfd5841  sub rsp, 0xF0
00007981ddfd5848  vmovaps [rsp], xmm0
00007981ddfd584d  vmovaps [rsp+0x10], xmm1
00007981ddfd5853  vmovaps [rsp+0x20], xmm2
00007981ddfd5859  vmovaps [rsp+0x30], xmm3
00007981ddfd585f  vmovaps [rsp+0x40], xmm4
00007981ddfd5865  vmovaps [rsp+0x50], xmm5
00007981ddfd586b  vmovaps [rsp+0x60], xmm6
00007981ddfd5871  vmovaps [rsp+0x70], xmm7
00007981ddfd5877  vmovaps [rsp+0x80], xmm8
00007981ddfd5880  vmovaps [rsp+0x90], xmm9
00007981ddfd5889  vmovaps [rsp+0xA0], xmm10
00007981ddfd5892  vmovaps [rsp+0xB0], xmm12
00007981ddfd589b  vmovaps [rsp+0xC0], xmm13
00007981ddfd58a4  vmovaps [rsp+0xD0], xmm14
00007981ddfd58ad  vmovaps [rsp+0xE0], xmm15
00007981ddfd58b6  sub rsp, 0x30
00007981ddfd58ba  movaps [rsp], xmm11
00007981ddfd58bf  movaps [rsp+0x10], xmm6
00007981ddfd58c4  movaps [rsp+0x20], xmm14
00007981ddfd58ca  lea rdi, [rsp]
00007981ddfd58ce  mov esi, 0x00
00007981ddfd58d3  mov rax, 0x5782A6EB3530
00007981ddfd58dd  call rax
00007981ddfd58df  movaps xmm11, [rsp]
00007981ddfd58e4  add rsp, 0x30
00007981ddfd58e8  vmovaps xmm0, [rsp]
00007981ddfd58ed  vmovaps xmm1, [rsp+0x10]
00007981ddfd58f3  vmovaps xmm2, [rsp+0x20]
00007981ddfd58f9  vmovaps xmm3, [rsp+0x30]
00007981ddfd58ff  vmovaps xmm4, [rsp+0x40]
00007981ddfd5905  vmovaps xmm5, [rsp+0x50]
00007981ddfd590b  vmovaps xmm6, [rsp+0x60]
00007981ddfd5911  vmovaps xmm7, [rsp+0x70]
00007981ddfd5917  vmovaps xmm8, [rsp+0x80]
00007981ddfd5920  vmovaps xmm9, [rsp+0x90]
00007981ddfd5929  vmovaps xmm10, [rsp+0xA0]
00007981ddfd5932  vmovaps xmm12, [rsp+0xB0]
00007981ddfd593b  vmovaps xmm13, [rsp+0xC0]
00007981ddfd5944  vmovaps xmm14, [rsp+0xD0]
00007981ddfd594d  vmovaps xmm15, [rsp+0xE0]
00007981ddfd5956  add rsp, 0xF0
00007981ddfd595d  pop r11
00007981ddfd595f  pop r10
00007981ddfd5961  pop r9
00007981ddfd5963  pop r8
00007981ddfd5965  pop rsi
00007981ddfd5966  pop rdi
00007981ddfd5967  pop rdx
00007981ddfd5968  pop rcx
00007981ddfd5969  pop rax
00007981ddfd596a  add rsp, 0x08
00007981ddfd596e  jmp 0x00007981DDFD2F5B
00007981ddfd5973  call 0x00007981DDDFF430
00007981ddfd5978  jmp 0x00007981DDFD2F65
00007981ddfd597d  sub rsp, 0x08
00007981ddfd5981  push rax
00007981ddfd5982  push rcx
00007981ddfd5983  push rdx
00007981ddfd5984  push rdi
00007981ddfd5985  push rsi
00007981ddfd5986  push r8
00007981ddfd5988  push r9
00007981ddfd598a  push r10
00007981ddfd598c  push r11
00007981ddfd598e  sub rsp, 0xF0
00007981ddfd5995  vmovaps [rsp], xmm0
00007981ddfd599a  vmovaps [rsp+0x10], xmm1
00007981ddfd59a0  vmovaps [rsp+0x20], xmm2
00007981ddfd59a6  vmovaps [rsp+0x30], xmm3
00007981ddfd59ac  vmovaps [rsp+0x40], xmm4
00007981ddfd59b2  vmovaps [rsp+0x50], xmm5
00007981ddfd59b8  vmovaps [rsp+0x60], xmm6
00007981ddfd59be  vmovaps [rsp+0x70], xmm7
00007981ddfd59c4  vmovaps [rsp+0x80], xmm8
00007981ddfd59cd  vmovaps [rsp+0x90], xmm9
00007981ddfd59d6  vmovaps [rsp+0xA0], xmm10
00007981ddfd59df  vmovaps [rsp+0xB0], xmm11
00007981ddfd59e8  vmovaps [rsp+0xC0], xmm12
00007981ddfd59f1  vmovaps [rsp+0xD0], xmm13
00007981ddfd59fa  vmovaps [rsp+0xE0], xmm15
00007981ddfd5a03  sub rsp, 0x30
00007981ddfd5a07  movaps [rsp], xmm14
00007981ddfd5a0c  movaps [rsp+0x10], xmm6
00007981ddfd5a11  movaps [rsp+0x20], xmm2
00007981ddfd5a16  lea rdi, [rsp]
00007981ddfd5a1a  mov esi, 0x00
00007981ddfd5a1f  mov rax, 0x5782A6EB3530
00007981ddfd5a29  call rax
00007981ddfd5a2b  movaps xmm14, [rsp]
00007981ddfd5a30  add rsp, 0x30
00007981ddfd5a34  vmovaps xmm0, [rsp]
00007981ddfd5a39  vmovaps xmm1, [rsp+0x10]
00007981ddfd5a3f  vmovaps xmm2, [rsp+0x20]
00007981ddfd5a45  vmovaps xmm3, [rsp+0x30]
00007981ddfd5a4b  vmovaps xmm4, [rsp+0x40]
00007981ddfd5a51  vmovaps xmm5, [rsp+0x50]
00007981ddfd5a57  vmovaps xmm6, [rsp+0x60]
00007981ddfd5a5d  vmovaps xmm7, [rsp+0x70]
00007981ddfd5a63  vmovaps xmm8, [rsp+0x80]
00007981ddfd5a6c  vmovaps xmm9, [rsp+0x90]
00007981ddfd5a75  vmovaps xmm10, [rsp+0xA0]
00007981ddfd5a7e  vmovaps xmm11, [rsp+0xB0]
00007981ddfd5a87  vmovaps xmm12, [rsp+0xC0]
00007981ddfd5a90  vmovaps xmm13, [rsp+0xD0]
00007981ddfd5a99  vmovaps xmm15, [rsp+0xE0]
00007981ddfd5aa2  add rsp, 0xF0
00007981ddfd5aa9  pop r11
00007981ddfd5aab  pop r10
00007981ddfd5aad  pop r9
00007981ddfd5aaf  pop r8
00007981ddfd5ab1  pop rsi
00007981ddfd5ab2  pop rdi
00007981ddfd5ab3  pop rdx
00007981ddfd5ab4  pop rcx
00007981ddfd5ab5  pop rax
00007981ddfd5ab6  add rsp, 0x08
00007981ddfd5aba  jmp 0x00007981DDFD2F99
00007981ddfd5abf  sub rsp, 0x08
00007981ddfd5ac3  push rax
00007981ddfd5ac4  push rcx
00007981ddfd5ac5  push rdx
00007981ddfd5ac6  push rdi
00007981ddfd5ac7  push rsi
00007981ddfd5ac8  push r8
00007981ddfd5aca  push r9
00007981ddfd5acc  push r10
00007981ddfd5ace  push r11
00007981ddfd5ad0  sub rsp, 0xF0
00007981ddfd5ad7  vmovaps [rsp], xmm0
00007981ddfd5adc  vmovaps [rsp+0x10], xmm1
00007981ddfd5ae2  vmovaps [rsp+0x20], xmm2
00007981ddfd5ae8  vmovaps [rsp+0x30], xmm3
00007981ddfd5aee  vmovaps [rsp+0x40], xmm4
00007981ddfd5af4  vmovaps [rsp+0x50], xmm5
00007981ddfd5afa  vmovaps [rsp+0x60], xmm7
00007981ddfd5b00  vmovaps [rsp+0x70], xmm8
00007981ddfd5b06  vmovaps [rsp+0x80], xmm9
00007981ddfd5b0f  vmovaps [rsp+0x90], xmm10
00007981ddfd5b18  vmovaps [rsp+0xA0], xmm11
00007981ddfd5b21  vmovaps [rsp+0xB0], xmm12
00007981ddfd5b2a  vmovaps [rsp+0xC0], xmm13
00007981ddfd5b33  vmovaps [rsp+0xD0], xmm14
00007981ddfd5b3c  vmovaps [rsp+0xE0], xmm15
00007981ddfd5b45  sub rsp, 0x30
00007981ddfd5b49  movaps [rsp], xmm6
00007981ddfd5b4d  movaps [rsp+0x10], xmm5
00007981ddfd5b52  movaps [rsp+0x20], xmm1
00007981ddfd5b57  lea rdi, [rsp]
00007981ddfd5b5b  mov esi, 0x00
00007981ddfd5b60  mov rax, 0x5782A6EB3530
00007981ddfd5b6a  call rax
00007981ddfd5b6c  movaps xmm6, [rsp]
00007981ddfd5b70  add rsp, 0x30
00007981ddfd5b74  vmovaps xmm0, [rsp]
00007981ddfd5b79  vmovaps xmm1, [rsp+0x10]
00007981ddfd5b7f  vmovaps xmm2, [rsp+0x20]
00007981ddfd5b85  vmovaps xmm3, [rsp+0x30]
00007981ddfd5b8b  vmovaps xmm4, [rsp+0x40]
00007981ddfd5b91  vmovaps xmm5, [rsp+0x50]
00007981ddfd5b97  vmovaps xmm7, [rsp+0x60]
00007981ddfd5b9d  vmovaps xmm8, [rsp+0x70]
00007981ddfd5ba3  vmovaps xmm9, [rsp+0x80]
00007981ddfd5bac  vmovaps xmm10, [rsp+0x90]
00007981ddfd5bb5  vmovaps xmm11, [rsp+0xA0]
00007981ddfd5bbe  vmovaps xmm12, [rsp+0xB0]
00007981ddfd5bc7  vmovaps xmm13, [rsp+0xC0]
00007981ddfd5bd0  vmovaps xmm14, [rsp+0xD0]
00007981ddfd5bd9  vmovaps xmm15, [rsp+0xE0]
00007981ddfd5be2  add rsp, 0xF0
00007981ddfd5be9  pop r11
00007981ddfd5beb  pop r10
00007981ddfd5bed  pop r9
00007981ddfd5bef  pop r8
00007981ddfd5bf1  pop rsi
00007981ddfd5bf2  pop rdi
00007981ddfd5bf3  pop rdx
00007981ddfd5bf4  pop rcx
00007981ddfd5bf5  pop rax
00007981ddfd5bf6  add rsp, 0x08
00007981ddfd5bfa  jmp 0x00007981DDFD2FBF
00007981ddfd5bff  sub rsp, 0x08
00007981ddfd5c03  push rax
00007981ddfd5c04  push rcx
00007981ddfd5c05  push rdx
00007981ddfd5c06  push rdi
00007981ddfd5c07  push rsi
00007981ddfd5c08  push r8
00007981ddfd5c0a  push r9
00007981ddfd5c0c  push r10
00007981ddfd5c0e  push r11
00007981ddfd5c10  sub rsp, 0xF0
00007981ddfd5c17  vmovaps [rsp], xmm0
00007981ddfd5c1c  vmovaps [rsp+0x10], xmm2
00007981ddfd5c22  vmovaps [rsp+0x20], xmm3
00007981ddfd5c28  vmovaps [rsp+0x30], xmm4
00007981ddfd5c2e  vmovaps [rsp+0x40], xmm5
00007981ddfd5c34  vmovaps [rsp+0x50], xmm6
00007981ddfd5c3a  vmovaps [rsp+0x60], xmm7
00007981ddfd5c40  vmovaps [rsp+0x70], xmm8
00007981ddfd5c46  vmovaps [rsp+0x80], xmm9
00007981ddfd5c4f  vmovaps [rsp+0x90], xmm10
00007981ddfd5c58  vmovaps [rsp+0xA0], xmm11
00007981ddfd5c61  vmovaps [rsp+0xB0], xmm12
00007981ddfd5c6a  vmovaps [rsp+0xC0], xmm13
00007981ddfd5c73  vmovaps [rsp+0xD0], xmm14
00007981ddfd5c7c  vmovaps [rsp+0xE0], xmm15
00007981ddfd5c85  sub rsp, 0x30
00007981ddfd5c89  movaps [rsp], xmm1
00007981ddfd5c8d  movaps [rsp+0x10], xmm5
00007981ddfd5c92  movaps [rsp+0x20], xmm13
00007981ddfd5c98  lea rdi, [rsp]
00007981ddfd5c9c  mov esi, 0x00
00007981ddfd5ca1  mov rax, 0x5782A6EB3530
00007981ddfd5cab  call rax
00007981ddfd5cad  movaps xmm1, [rsp]
00007981ddfd5cb1  add rsp, 0x30
00007981ddfd5cb5  vmovaps xmm0, [rsp]
00007981ddfd5cba  vmovaps xmm2, [rsp+0x10]
00007981ddfd5cc0  vmovaps xmm3, [rsp+0x20]
00007981ddfd5cc6  vmovaps xmm4, [rsp+0x30]
00007981ddfd5ccc  vmovaps xmm5, [rsp+0x40]
00007981ddfd5cd2  vmovaps xmm6, [rsp+0x50]
00007981ddfd5cd8  vmovaps xmm7, [rsp+0x60]
00007981ddfd5cde  vmovaps xmm8, [rsp+0x70]
00007981ddfd5ce4  vmovaps xmm9, [rsp+0x80]
00007981ddfd5ced  vmovaps xmm10, [rsp+0x90]
00007981ddfd5cf6  vmovaps xmm11, [rsp+0xA0]
00007981ddfd5cff  vmovaps xmm12, [rsp+0xB0]
00007981ddfd5d08  vmovaps xmm13, [rsp+0xC0]
00007981ddfd5d11  vmovaps xmm14, [rsp+0xD0]
00007981ddfd5d1a  vmovaps xmm15, [rsp+0xE0]
00007981ddfd5d23  add rsp, 0xF0
00007981ddfd5d2a  pop r11
00007981ddfd5d2c  pop r10
00007981ddfd5d2e  pop r9
00007981ddfd5d30  pop r8
00007981ddfd5d32  pop rsi
00007981ddfd5d33  pop rdi
00007981ddfd5d34  pop rdx
00007981ddfd5d35  pop rcx
00007981ddfd5d36  pop rax
00007981ddfd5d37  add rsp, 0x08
00007981ddfd5d3b  jmp 0x00007981DDFD2FDD
00007981ddfd5d40  sub rsp, 0x08
00007981ddfd5d44  push rax
00007981ddfd5d45  push rcx
00007981ddfd5d46  push rdx
00007981ddfd5d47  push rdi
00007981ddfd5d48  push rsi
00007981ddfd5d49  push r8
00007981ddfd5d4b  push r9
00007981ddfd5d4d  push r10
00007981ddfd5d4f  push r11
00007981ddfd5d51  sub rsp, 0xF0
00007981ddfd5d58  vmovaps [rsp], xmm0
00007981ddfd5d5d  vmovaps [rsp+0x10], xmm1
00007981ddfd5d63  vmovaps [rsp+0x20], xmm2
00007981ddfd5d69  vmovaps [rsp+0x30], xmm3
00007981ddfd5d6f  vmovaps [rsp+0x40], xmm4
00007981ddfd5d75  vmovaps [rsp+0x50], xmm6
00007981ddfd5d7b  vmovaps [rsp+0x60], xmm7
00007981ddfd5d81  vmovaps [rsp+0x70], xmm8
00007981ddfd5d87  vmovaps [rsp+0x80], xmm9
00007981ddfd5d90  vmovaps [rsp+0x90], xmm10
00007981ddfd5d99  vmovaps [rsp+0xA0], xmm11
00007981ddfd5da2  vmovaps [rsp+0xB0], xmm12
00007981ddfd5dab  vmovaps [rsp+0xC0], xmm13
00007981ddfd5db4  vmovaps [rsp+0xD0], xmm14
00007981ddfd5dbd  vmovaps [rsp+0xE0], xmm15
00007981ddfd5dc6  sub rsp, 0x30
00007981ddfd5dca  movaps [rsp], xmm5
00007981ddfd5dce  movaps [rsp+0x10], xmm2
00007981ddfd5dd3  movaps [rsp+0x20], xmm13
00007981ddfd5dd9  lea rdi, [rsp]
00007981ddfd5ddd  mov esi, 0x00
00007981ddfd5de2  mov rax, 0x5782A6EB3530
00007981ddfd5dec  call rax
00007981ddfd5dee  movaps xmm5, [rsp]
00007981ddfd5df2  add rsp, 0x30
00007981ddfd5df6  vmovaps xmm0, [rsp]
00007981ddfd5dfb  vmovaps xmm1, [rsp+0x10]
00007981ddfd5e01  vmovaps xmm2, [rsp+0x20]
00007981ddfd5e07  vmovaps xmm3, [rsp+0x30]
00007981ddfd5e0d  vmovaps xmm4, [rsp+0x40]
00007981ddfd5e13  vmovaps xmm6, [rsp+0x50]
00007981ddfd5e19  vmovaps xmm7, [rsp+0x60]
00007981ddfd5e1f  vmovaps xmm8, [rsp+0x70]
00007981ddfd5e25  vmovaps xmm9, [rsp+0x80]
00007981ddfd5e2e  vmovaps xmm10, [rsp+0x90]
00007981ddfd5e37  vmovaps xmm11, [rsp+0xA0]
00007981ddfd5e40  vmovaps xmm12, [rsp+0xB0]
00007981ddfd5e49  vmovaps xmm13, [rsp+0xC0]
00007981ddfd5e52  vmovaps xmm14, [rsp+0xD0]
00007981ddfd5e5b  vmovaps xmm15, [rsp+0xE0]
00007981ddfd5e64  add rsp, 0xF0
00007981ddfd5e6b  pop r11
00007981ddfd5e6d  pop r10
00007981ddfd5e6f  pop r9
00007981ddfd5e71  pop r8
00007981ddfd5e73  pop rsi
00007981ddfd5e74  pop rdi
00007981ddfd5e75  pop rdx
00007981ddfd5e76  pop rcx
00007981ddfd5e77  pop rax
00007981ddfd5e78  add rsp, 0x08
00007981ddfd5e7c  jmp 0x00007981DDFD3013
00007981ddfd5e81  sub rsp, 0x08
00007981ddfd5e85  push rax
00007981ddfd5e86  push rcx
00007981ddfd5e87  push rdx
00007981ddfd5e88  push rdi
00007981ddfd5e89  push rsi
00007981ddfd5e8a  push r8
00007981ddfd5e8c  push r9
00007981ddfd5e8e  push r10
00007981ddfd5e90  push r11
00007981ddfd5e92  sub rsp, 0xF0
00007981ddfd5e99  vmovaps [rsp], xmm0
00007981ddfd5e9e  vmovaps [rsp+0x10], xmm1
00007981ddfd5ea4  vmovaps [rsp+0x20], xmm2
00007981ddfd5eaa  vmovaps [rsp+0x30], xmm3
00007981ddfd5eb0  vmovaps [rsp+0x40], xmm4
00007981ddfd5eb6  vmovaps [rsp+0x50], xmm5
00007981ddfd5ebc  vmovaps [rsp+0x60], xmm6
00007981ddfd5ec2  vmovaps [rsp+0x70], xmm7
00007981ddfd5ec8  vmovaps [rsp+0x80], xmm8
00007981ddfd5ed1  vmovaps [rsp+0x90], xmm9
00007981ddfd5eda  vmovaps [rsp+0xA0], xmm10
00007981ddfd5ee3  vmovaps [rsp+0xB0], xmm11
00007981ddfd5eec  vmovaps [rsp+0xC0], xmm12
00007981ddfd5ef5  vmovaps [rsp+0xD0], xmm14
00007981ddfd5efe  vmovaps [rsp+0xE0], xmm15
00007981ddfd5f07  sub rsp, 0x30
00007981ddfd5f0b  movaps [rsp], xmm13
00007981ddfd5f10  movaps [rsp+0x10], xmm10
00007981ddfd5f16  movaps [rsp+0x20], xmm1
00007981ddfd5f1b  lea rdi, [rsp]
00007981ddfd5f1f  mov esi, 0x00
00007981ddfd5f24  mov rax, 0x5782A6EB3530
00007981ddfd5f2e  call rax
00007981ddfd5f30  movaps xmm13, [rsp]
00007981ddfd5f35  add rsp, 0x30
00007981ddfd5f39  vmovaps xmm0, [rsp]
00007981ddfd5f3e  vmovaps xmm1, [rsp+0x10]
00007981ddfd5f44  vmovaps xmm2, [rsp+0x20]
00007981ddfd5f4a  vmovaps xmm3, [rsp+0x30]
00007981ddfd5f50  vmovaps xmm4, [rsp+0x40]
00007981ddfd5f56  vmovaps xmm5, [rsp+0x50]
00007981ddfd5f5c  vmovaps xmm6, [rsp+0x60]
00007981ddfd5f62  vmovaps xmm7, [rsp+0x70]
00007981ddfd5f68  vmovaps xmm8, [rsp+0x80]
00007981ddfd5f71  vmovaps xmm9, [rsp+0x90]
00007981ddfd5f7a  vmovaps xmm10, [rsp+0xA0]
00007981ddfd5f83  vmovaps xmm11, [rsp+0xB0]
00007981ddfd5f8c  vmovaps xmm12, [rsp+0xC0]
00007981ddfd5f95  vmovaps xmm14, [rsp+0xD0]
00007981ddfd5f9e  vmovaps xmm15, [rsp+0xE0]
00007981ddfd5fa7  add rsp, 0xF0
00007981ddfd5fae  pop r11
00007981ddfd5fb0  pop r10
00007981ddfd5fb2  pop r9
00007981ddfd5fb4  pop r8
00007981ddfd5fb6  pop rsi
00007981ddfd5fb7  pop rdi
00007981ddfd5fb8  pop rdx
00007981ddfd5fb9  pop rcx
00007981ddfd5fba  pop rax
00007981ddfd5fbb  add rsp, 0x08
00007981ddfd5fbf  jmp 0x00007981DDFD303C
00007981ddfd5fc4  sub rsp, 0x08
00007981ddfd5fc8  push rax
00007981ddfd5fc9  push rcx
00007981ddfd5fca  push rdx
00007981ddfd5fcb  push rdi
00007981ddfd5fcc  push rsi
00007981ddfd5fcd  push r8
00007981ddfd5fcf  push r9
00007981ddfd5fd1  push r10
00007981ddfd5fd3  push r11
00007981ddfd5fd5  sub rsp, 0xF0
00007981ddfd5fdc  vmovaps [rsp], xmm0
00007981ddfd5fe1  vmovaps [rsp+0x10], xmm2
00007981ddfd5fe7  vmovaps [rsp+0x20], xmm3
00007981ddfd5fed  vmovaps [rsp+0x30], xmm4
00007981ddfd5ff3  vmovaps [rsp+0x40], xmm5
00007981ddfd5ff9  vmovaps [rsp+0x50], xmm6
00007981ddfd5fff  vmovaps [rsp+0x60], xmm7
00007981ddfd6005  vmovaps [rsp+0x70], xmm8
00007981ddfd600b  vmovaps [rsp+0x80], xmm9
00007981ddfd6014  vmovaps [rsp+0x90], xmm10
00007981ddfd601d  vmovaps [rsp+0xA0], xmm11
00007981ddfd6026  vmovaps [rsp+0xB0], xmm12
00007981ddfd602f  vmovaps [rsp+0xC0], xmm13
00007981ddfd6038  vmovaps [rsp+0xD0], xmm14
00007981ddfd6041  vmovaps [rsp+0xE0], xmm15
00007981ddfd604a  sub rsp, 0x30
00007981ddfd604e  movaps [rsp], xmm1
00007981ddfd6052  movaps [rsp+0x10], xmm15
00007981ddfd6058  movaps [rsp+0x20], xmm10
00007981ddfd605e  lea rdi, [rsp]
00007981ddfd6062  mov esi, 0x00
00007981ddfd6067  mov rax, 0x5782A6EB3530
00007981ddfd6071  call rax
00007981ddfd6073  movaps xmm1, [rsp]
00007981ddfd6077  add rsp, 0x30
00007981ddfd607b  vmovaps xmm0, [rsp]
00007981ddfd6080  vmovaps xmm2, [rsp+0x10]
00007981ddfd6086  vmovaps xmm3, [rsp+0x20]
00007981ddfd608c  vmovaps xmm4, [rsp+0x30]
00007981ddfd6092  vmovaps xmm5, [rsp+0x40]
00007981ddfd6098  vmovaps xmm6, [rsp+0x50]
00007981ddfd609e  vmovaps xmm7, [rsp+0x60]
00007981ddfd60a4  vmovaps xmm8, [rsp+0x70]
00007981ddfd60aa  vmovaps xmm9, [rsp+0x80]
00007981ddfd60b3  vmovaps xmm10, [rsp+0x90]
00007981ddfd60bc  vmovaps xmm11, [rsp+0xA0]
00007981ddfd60c5  vmovaps xmm12, [rsp+0xB0]
00007981ddfd60ce  vmovaps xmm13, [rsp+0xC0]
00007981ddfd60d7  vmovaps xmm14, [rsp+0xD0]
00007981ddfd60e0  vmovaps xmm15, [rsp+0xE0]
00007981ddfd60e9  add rsp, 0xF0
00007981ddfd60f0  pop r11
00007981ddfd60f2  pop r10
00007981ddfd60f4  pop r9
00007981ddfd60f6  pop r8
00007981ddfd60f8  pop rsi
00007981ddfd60f9  pop rdi
00007981ddfd60fa  pop rdx
00007981ddfd60fb  pop rcx
00007981ddfd60fc  pop rax
00007981ddfd60fd  add rsp, 0x08
00007981ddfd6101  jmp 0x00007981DDFD305B
00007981ddfd6106  sub rsp, 0x08
00007981ddfd610a  push rax
00007981ddfd610b  push rcx
00007981ddfd610c  push rdx
00007981ddfd610d  push rdi
00007981ddfd610e  push rsi
00007981ddfd610f  push r8
00007981ddfd6111  push r9
00007981ddfd6113  push r10
00007981ddfd6115  push r11
00007981ddfd6117  sub rsp, 0xF0
00007981ddfd611e  vmovaps [rsp], xmm0
00007981ddfd6123  vmovaps [rsp+0x10], xmm1
00007981ddfd6129  vmovaps [rsp+0x20], xmm2
00007981ddfd612f  vmovaps [rsp+0x30], xmm3
00007981ddfd6135  vmovaps [rsp+0x40], xmm4
00007981ddfd613b  vmovaps [rsp+0x50], xmm5
00007981ddfd6141  vmovaps [rsp+0x60], xmm6
00007981ddfd6147  vmovaps [rsp+0x70], xmm7
00007981ddfd614d  vmovaps [rsp+0x80], xmm8
00007981ddfd6156  vmovaps [rsp+0x90], xmm9
00007981ddfd615f  vmovaps [rsp+0xA0], xmm10
00007981ddfd6168  vmovaps [rsp+0xB0], xmm11
00007981ddfd6171  vmovaps [rsp+0xC0], xmm12
00007981ddfd617a  vmovaps [rsp+0xD0], xmm13
00007981ddfd6183  vmovaps [rsp+0xE0], xmm14
00007981ddfd618c  sub rsp, 0x30
00007981ddfd6190  movaps [rsp], xmm15
00007981ddfd6195  movaps [rsp+0x10], xmm10
00007981ddfd619b  movaps [rsp+0x20], xmm11
00007981ddfd61a1  lea rdi, [rsp]
00007981ddfd61a5  mov esi, 0x00
00007981ddfd61aa  mov rax, 0x5782A6EB3530
00007981ddfd61b4  call rax
00007981ddfd61b6  movaps xmm15, [rsp]
00007981ddfd61bb  add rsp, 0x30
00007981ddfd61bf  vmovaps xmm0, [rsp]
00007981ddfd61c4  vmovaps xmm1, [rsp+0x10]
00007981ddfd61ca  vmovaps xmm2, [rsp+0x20]
00007981ddfd61d0  vmovaps xmm3, [rsp+0x30]
00007981ddfd61d6  vmovaps xmm4, [rsp+0x40]
00007981ddfd61dc  vmovaps xmm5, [rsp+0x50]
00007981ddfd61e2  vmovaps xmm6, [rsp+0x60]
00007981ddfd61e8  vmovaps xmm7, [rsp+0x70]
00007981ddfd61ee  vmovaps xmm8, [rsp+0x80]
00007981ddfd61f7  vmovaps xmm9, [rsp+0x90]
00007981ddfd6200  vmovaps xmm10, [rsp+0xA0]
00007981ddfd6209  vmovaps xmm11, [rsp+0xB0]
00007981ddfd6212  vmovaps xmm12, [rsp+0xC0]
00007981ddfd621b  vmovaps xmm13, [rsp+0xD0]
00007981ddfd6224  vmovaps xmm14, [rsp+0xE0]
00007981ddfd622d  add rsp, 0xF0
00007981ddfd6234  pop r11
00007981ddfd6236  pop r10
00007981ddfd6238  pop r9
00007981ddfd623a  pop r8
00007981ddfd623c  pop rsi
00007981ddfd623d  pop rdi
00007981ddfd623e  pop rdx
00007981ddfd623f  pop rcx
00007981ddfd6240  pop rax
00007981ddfd6241  add rsp, 0x08
00007981ddfd6245  jmp 0x00007981DDFD307E
00007981ddfd624a  sub rsp, 0x08
00007981ddfd624e  push rax
00007981ddfd624f  push rcx
00007981ddfd6250  push rdx
00007981ddfd6251  push rdi
00007981ddfd6252  push rsi
00007981ddfd6253  push r8
00007981ddfd6255  push r9
00007981ddfd6257  push r10
00007981ddfd6259  push r11
00007981ddfd625b  sub rsp, 0xF0
00007981ddfd6262  vmovaps [rsp], xmm0
00007981ddfd6267  vmovaps [rsp+0x10], xmm1
00007981ddfd626d  vmovaps [rsp+0x20], xmm2
00007981ddfd6273  vmovaps [rsp+0x30], xmm3
00007981ddfd6279  vmovaps [rsp+0x40], xmm4
00007981ddfd627f  vmovaps [rsp+0x50], xmm5
00007981ddfd6285  vmovaps [rsp+0x60], xmm6
00007981ddfd628b  vmovaps [rsp+0x70], xmm7
00007981ddfd6291  vmovaps [rsp+0x80], xmm8
00007981ddfd629a  vmovaps [rsp+0x90], xmm9
00007981ddfd62a3  vmovaps [rsp+0xA0], xmm11
00007981ddfd62ac  vmovaps [rsp+0xB0], xmm12
00007981ddfd62b5  vmovaps [rsp+0xC0], xmm13
00007981ddfd62be  vmovaps [rsp+0xD0], xmm14
00007981ddfd62c7  vmovaps [rsp+0xE0], xmm15
00007981ddfd62d0  sub rsp, 0x30
00007981ddfd62d4  movaps [rsp], xmm10
00007981ddfd62d9  movaps [rsp+0x10], xmm2
00007981ddfd62de  movaps [rsp+0x20], xmm11
00007981ddfd62e4  lea rdi, [rsp]
00007981ddfd62e8  mov esi, 0x00
00007981ddfd62ed  mov rax, 0x5782A6EB3530
00007981ddfd62f7  call rax
00007981ddfd62f9  movaps xmm10, [rsp]
00007981ddfd62fe  add rsp, 0x30
00007981ddfd6302  vmovaps xmm0, [rsp]
00007981ddfd6307  vmovaps xmm1, [rsp+0x10]
00007981ddfd630d  vmovaps xmm2, [rsp+0x20]
00007981ddfd6313  vmovaps xmm3, [rsp+0x30]
00007981ddfd6319  vmovaps xmm4, [rsp+0x40]
00007981ddfd631f  vmovaps xmm5, [rsp+0x50]
00007981ddfd6325  vmovaps xmm6, [rsp+0x60]
00007981ddfd632b  vmovaps xmm7, [rsp+0x70]
00007981ddfd6331  vmovaps xmm8, [rsp+0x80]
00007981ddfd633a  vmovaps xmm9, [rsp+0x90]
00007981ddfd6343  vmovaps xmm11, [rsp+0xA0]
00007981ddfd634c  vmovaps xmm12, [rsp+0xB0]
00007981ddfd6355  vmovaps xmm13, [rsp+0xC0]
00007981ddfd635e  vmovaps xmm14, [rsp+0xD0]
00007981ddfd6367  vmovaps xmm15, [rsp+0xE0]
00007981ddfd6370  add rsp, 0xF0
00007981ddfd6377  pop r11
00007981ddfd6379  pop r10
00007981ddfd637b  pop r9
00007981ddfd637d  pop r8
00007981ddfd637f  pop rsi
00007981ddfd6380  pop rdi
00007981ddfd6381  pop rdx
00007981ddfd6382  pop rcx
00007981ddfd6383  pop rax
00007981ddfd6384  add rsp, 0x08
00007981ddfd6388  jmp 0x00007981DDFD30B6
00007981ddfd638d  sub rsp, 0x08
00007981ddfd6391  push rax
00007981ddfd6392  push rcx
00007981ddfd6393  push rdx
00007981ddfd6394  push rdi
00007981ddfd6395  push rsi
00007981ddfd6396  push r8
00007981ddfd6398  push r9
00007981ddfd639a  push r10
00007981ddfd639c  push r11
00007981ddfd639e  sub rsp, 0xF0
00007981ddfd63a5  vmovaps [rsp], xmm0
00007981ddfd63aa  vmovaps [rsp+0x10], xmm1
00007981ddfd63b0  vmovaps [rsp+0x20], xmm2
00007981ddfd63b6  vmovaps [rsp+0x30], xmm3
00007981ddfd63bc  vmovaps [rsp+0x40], xmm4
00007981ddfd63c2  vmovaps [rsp+0x50], xmm5
00007981ddfd63c8  vmovaps [rsp+0x60], xmm6
00007981ddfd63ce  vmovaps [rsp+0x70], xmm7
00007981ddfd63d4  vmovaps [rsp+0x80], xmm8
00007981ddfd63dd  vmovaps [rsp+0x90], xmm9
00007981ddfd63e6  vmovaps [rsp+0xA0], xmm10
00007981ddfd63ef  vmovaps [rsp+0xB0], xmm12
00007981ddfd63f8  vmovaps [rsp+0xC0], xmm13
00007981ddfd6401  vmovaps [rsp+0xD0], xmm14
00007981ddfd640a  vmovaps [rsp+0xE0], xmm15
00007981ddfd6413  sub rsp, 0x30
00007981ddfd6417  movaps [rsp], xmm11
00007981ddfd641c  movaps [rsp+0x10], xmm2
00007981ddfd6421  movaps [rsp+0x20], xmm1
00007981ddfd6426  lea rdi, [rsp]
00007981ddfd642a  mov esi, 0x00
00007981ddfd642f  mov rax, 0x5782A6EB3530
00007981ddfd6439  call rax
00007981ddfd643b  movaps xmm11, [rsp]
00007981ddfd6440  add rsp, 0x30
00007981ddfd6444  vmovaps xmm0, [rsp]
00007981ddfd6449  vmovaps xmm1, [rsp+0x10]
00007981ddfd644f  vmovaps xmm2, [rsp+0x20]
00007981ddfd6455  vmovaps xmm3, [rsp+0x30]
00007981ddfd645b  vmovaps xmm4, [rsp+0x40]
00007981ddfd6461  vmovaps xmm5, [rsp+0x50]
00007981ddfd6467  vmovaps xmm6, [rsp+0x60]
00007981ddfd646d  vmovaps xmm7, [rsp+0x70]
00007981ddfd6473  vmovaps xmm8, [rsp+0x80]
00007981ddfd647c  vmovaps xmm9, [rsp+0x90]
00007981ddfd6485  vmovaps xmm10, [rsp+0xA0]
00007981ddfd648e  vmovaps xmm12, [rsp+0xB0]
00007981ddfd6497  vmovaps xmm13, [rsp+0xC0]
00007981ddfd64a0  vmovaps xmm14, [rsp+0xD0]
00007981ddfd64a9  vmovaps xmm15, [rsp+0xE0]
00007981ddfd64b2  add rsp, 0xF0
00007981ddfd64b9  pop r11
00007981ddfd64bb  pop r10
00007981ddfd64bd  pop r9
00007981ddfd64bf  pop r8
00007981ddfd64c1  pop rsi
00007981ddfd64c2  pop rdi
00007981ddfd64c3  pop rdx
00007981ddfd64c4  pop rcx
00007981ddfd64c5  pop rax
00007981ddfd64c6  add rsp, 0x08
00007981ddfd64ca  jmp 0x00007981DDFD30F2
00007981ddfd64cf  sub rsp, 0x08
00007981ddfd64d3  push rax
00007981ddfd64d4  push rcx
00007981ddfd64d5  push rdx
00007981ddfd64d6  push rdi
00007981ddfd64d7  push rsi
00007981ddfd64d8  push r8
00007981ddfd64da  push r9
00007981ddfd64dc  push r10
00007981ddfd64de  push r11
00007981ddfd64e0  sub rsp, 0xF0
00007981ddfd64e7  vmovaps [rsp], xmm0
00007981ddfd64ec  vmovaps [rsp+0x10], xmm2
00007981ddfd64f2  vmovaps [rsp+0x20], xmm3
00007981ddfd64f8  vmovaps [rsp+0x30], xmm4
00007981ddfd64fe  vmovaps [rsp+0x40], xmm5
00007981ddfd6504  vmovaps [rsp+0x50], xmm6
00007981ddfd650a  vmovaps [rsp+0x60], xmm7
00007981ddfd6510  vmovaps [rsp+0x70], xmm8
00007981ddfd6516  vmovaps [rsp+0x80], xmm9
00007981ddfd651f  vmovaps [rsp+0x90], xmm10
00007981ddfd6528  vmovaps [rsp+0xA0], xmm11
00007981ddfd6531  vmovaps [rsp+0xB0], xmm12
00007981ddfd653a  vmovaps [rsp+0xC0], xmm13
00007981ddfd6543  vmovaps [rsp+0xD0], xmm14
00007981ddfd654c  vmovaps [rsp+0xE0], xmm15
00007981ddfd6555  sub rsp, 0x30
00007981ddfd6559  movaps [rsp], xmm1
00007981ddfd655d  movaps [rsp+0x10], xmm14
00007981ddfd6563  movaps [rsp+0x20], xmm6
00007981ddfd6568  lea rdi, [rsp]
00007981ddfd656c  mov esi, 0x00
00007981ddfd6571  mov rax, 0x5782A6EB3530
00007981ddfd657b  call rax
00007981ddfd657d  movaps xmm1, [rsp]
00007981ddfd6581  add rsp, 0x30
00007981ddfd6585  vmovaps xmm0, [rsp]
00007981ddfd658a  vmovaps xmm2, [rsp+0x10]
00007981ddfd6590  vmovaps xmm3, [rsp+0x20]
00007981ddfd6596  vmovaps xmm4, [rsp+0x30]
00007981ddfd659c  vmovaps xmm5, [rsp+0x40]
00007981ddfd65a2  vmovaps xmm6, [rsp+0x50]
00007981ddfd65a8  vmovaps xmm7, [rsp+0x60]
00007981ddfd65ae  vmovaps xmm8, [rsp+0x70]
00007981ddfd65b4  vmovaps xmm9, [rsp+0x80]
00007981ddfd65bd  vmovaps xmm10, [rsp+0x90]
00007981ddfd65c6  vmovaps xmm11, [rsp+0xA0]
00007981ddfd65cf  vmovaps xmm12, [rsp+0xB0]
00007981ddfd65d8  vmovaps xmm13, [rsp+0xC0]
00007981ddfd65e1  vmovaps xmm14, [rsp+0xD0]
00007981ddfd65ea  vmovaps xmm15, [rsp+0xE0]
00007981ddfd65f3  add rsp, 0xF0
00007981ddfd65fa  pop r11
00007981ddfd65fc  pop r10
00007981ddfd65fe  pop r9
00007981ddfd6600  pop r8
00007981ddfd6602  pop rsi
00007981ddfd6603  pop rdi
00007981ddfd6604  pop rdx
00007981ddfd6605  pop rcx
00007981ddfd6606  pop rax
00007981ddfd6607  add rsp, 0x08
00007981ddfd660b  jmp 0x00007981DDFD310B
00007981ddfd6610  sub rsp, 0x08
00007981ddfd6614  push rax
00007981ddfd6615  push rcx
00007981ddfd6616  push rdx
00007981ddfd6617  push rdi
00007981ddfd6618  push rsi
00007981ddfd6619  push r8
00007981ddfd661b  push r9
00007981ddfd661d  push r10
00007981ddfd661f  push r11
00007981ddfd6621  sub rsp, 0xF0
00007981ddfd6628  vmovaps [rsp], xmm0
00007981ddfd662d  vmovaps [rsp+0x10], xmm1
00007981ddfd6633  vmovaps [rsp+0x20], xmm2
00007981ddfd6639  vmovaps [rsp+0x30], xmm3
00007981ddfd663f  vmovaps [rsp+0x40], xmm4
00007981ddfd6645  vmovaps [rsp+0x50], xmm5
00007981ddfd664b  vmovaps [rsp+0x60], xmm6
00007981ddfd6651  vmovaps [rsp+0x70], xmm7
00007981ddfd6657  vmovaps [rsp+0x80], xmm8
00007981ddfd6660  vmovaps [rsp+0x90], xmm9
00007981ddfd6669  vmovaps [rsp+0xA0], xmm10
00007981ddfd6672  vmovaps [rsp+0xB0], xmm11
00007981ddfd667b  vmovaps [rsp+0xC0], xmm12
00007981ddfd6684  vmovaps [rsp+0xD0], xmm13
00007981ddfd668d  vmovaps [rsp+0xE0], xmm14
00007981ddfd6696  sub rsp, 0x30
00007981ddfd669a  movaps [rsp], xmm15
00007981ddfd669f  movaps [rsp+0x10], xmm14
00007981ddfd66a5  movaps [rsp+0x20], xmm5
00007981ddfd66aa  lea rdi, [rsp]
00007981ddfd66ae  mov esi, 0x00
00007981ddfd66b3  mov rax, 0x5782A6EB3530
00007981ddfd66bd  call rax
00007981ddfd66bf  movaps xmm15, [rsp]
00007981ddfd66c4  add rsp, 0x30
00007981ddfd66c8  vmovaps xmm0, [rsp]
00007981ddfd66cd  vmovaps xmm1, [rsp+0x10]
00007981ddfd66d3  vmovaps xmm2, [rsp+0x20]
00007981ddfd66d9  vmovaps xmm3, [rsp+0x30]
00007981ddfd66df  vmovaps xmm4, [rsp+0x40]
00007981ddfd66e5  vmovaps xmm5, [rsp+0x50]
00007981ddfd66eb  vmovaps xmm6, [rsp+0x60]
00007981ddfd66f1  vmovaps xmm7, [rsp+0x70]
00007981ddfd66f7  vmovaps xmm8, [rsp+0x80]
00007981ddfd6700  vmovaps xmm9, [rsp+0x90]
00007981ddfd6709  vmovaps xmm10, [rsp+0xA0]
00007981ddfd6712  vmovaps xmm11, [rsp+0xB0]
00007981ddfd671b  vmovaps xmm12, [rsp+0xC0]
00007981ddfd6724  vmovaps xmm13, [rsp+0xD0]
00007981ddfd672d  vmovaps xmm14, [rsp+0xE0]
00007981ddfd6736  add rsp, 0xF0
00007981ddfd673d  pop r11
00007981ddfd673f  pop r10
00007981ddfd6741  pop r9
00007981ddfd6743  pop r8
00007981ddfd6745  pop rsi
00007981ddfd6746  pop rdi
00007981ddfd6747  pop rdx
00007981ddfd6748  pop rcx
00007981ddfd6749  pop rax
00007981ddfd674a  add rsp, 0x08
00007981ddfd674e  jmp 0x00007981DDFD312B
00007981ddfd6753  sub rsp, 0x08
00007981ddfd6757  push rax
00007981ddfd6758  push rcx
00007981ddfd6759  push rdx
00007981ddfd675a  push rdi
00007981ddfd675b  push rsi
00007981ddfd675c  push r8
00007981ddfd675e  push r9
00007981ddfd6760  push r10
00007981ddfd6762  push r11
00007981ddfd6764  sub rsp, 0xF0
00007981ddfd676b  vmovaps [rsp], xmm0
00007981ddfd6770  vmovaps [rsp+0x10], xmm1
00007981ddfd6776  vmovaps [rsp+0x20], xmm2
00007981ddfd677c  vmovaps [rsp+0x30], xmm3
00007981ddfd6782  vmovaps [rsp+0x40], xmm4
00007981ddfd6788  vmovaps [rsp+0x50], xmm5
00007981ddfd678e  vmovaps [rsp+0x60], xmm7
00007981ddfd6794  vmovaps [rsp+0x70], xmm8
00007981ddfd679a  vmovaps [rsp+0x80], xmm9
00007981ddfd67a3  vmovaps [rsp+0x90], xmm10
00007981ddfd67ac  vmovaps [rsp+0xA0], xmm11
00007981ddfd67b5  vmovaps [rsp+0xB0], xmm12
00007981ddfd67be  vmovaps [rsp+0xC0], xmm13
00007981ddfd67c7  vmovaps [rsp+0xD0], xmm14
00007981ddfd67d0  vmovaps [rsp+0xE0], xmm15
00007981ddfd67d9  sub rsp, 0x30
00007981ddfd67dd  movaps [rsp], xmm6
00007981ddfd67e1  movaps [rsp+0x10], xmm9
00007981ddfd67e7  movaps [rsp+0x20], xmm14
00007981ddfd67ed  lea rdi, [rsp]
00007981ddfd67f1  mov esi, 0x00
00007981ddfd67f6  mov rax, 0x5782A6EB3530
00007981ddfd6800  call rax
00007981ddfd6802  movaps xmm6, [rsp]
00007981ddfd6806  add rsp, 0x30
00007981ddfd680a  vmovaps xmm0, [rsp]
00007981ddfd680f  vmovaps xmm1, [rsp+0x10]
00007981ddfd6815  vmovaps xmm2, [rsp+0x20]
00007981ddfd681b  vmovaps xmm3, [rsp+0x30]
00007981ddfd6821  vmovaps xmm4, [rsp+0x40]
00007981ddfd6827  vmovaps xmm5, [rsp+0x50]
00007981ddfd682d  vmovaps xmm7, [rsp+0x60]
00007981ddfd6833  vmovaps xmm8, [rsp+0x70]
00007981ddfd6839  vmovaps xmm9, [rsp+0x80]
00007981ddfd6842  vmovaps xmm10, [rsp+0x90]
00007981ddfd684b  vmovaps xmm11, [rsp+0xA0]
00007981ddfd6854  vmovaps xmm12, [rsp+0xB0]
00007981ddfd685d  vmovaps xmm13, [rsp+0xC0]
00007981ddfd6866  vmovaps xmm14, [rsp+0xD0]
00007981ddfd686f  vmovaps xmm15, [rsp+0xE0]
00007981ddfd6878  add rsp, 0xF0
00007981ddfd687f  pop r11
00007981ddfd6881  pop r10
00007981ddfd6883  pop r9
00007981ddfd6885  pop r8
00007981ddfd6887  pop rsi
00007981ddfd6888  pop rdi
00007981ddfd6889  pop rdx
00007981ddfd688a  pop rcx
00007981ddfd688b  pop rax
00007981ddfd688c  add rsp, 0x08
00007981ddfd6890  jmp 0x00007981DDFD3153
00007981ddfd6895  sub rsp, 0x08
00007981ddfd6899  push rax
00007981ddfd689a  push rcx
00007981ddfd689b  push rdx
00007981ddfd689c  push rdi
00007981ddfd689d  push rsi
00007981ddfd689e  push r8
00007981ddfd68a0  push r9
00007981ddfd68a2  push r10
00007981ddfd68a4  push r11
00007981ddfd68a6  sub rsp, 0xF0
00007981ddfd68ad  vmovaps [rsp], xmm0
00007981ddfd68b2  vmovaps [rsp+0x10], xmm1
00007981ddfd68b8  vmovaps [rsp+0x20], xmm2
00007981ddfd68be  vmovaps [rsp+0x30], xmm3
00007981ddfd68c4  vmovaps [rsp+0x40], xmm4
00007981ddfd68ca  vmovaps [rsp+0x50], xmm5
00007981ddfd68d0  vmovaps [rsp+0x60], xmm6
00007981ddfd68d6  vmovaps [rsp+0x70], xmm7
00007981ddfd68dc  vmovaps [rsp+0x80], xmm8
00007981ddfd68e5  vmovaps [rsp+0x90], xmm9
00007981ddfd68ee  vmovaps [rsp+0xA0], xmm10
00007981ddfd68f7  vmovaps [rsp+0xB0], xmm11
00007981ddfd6900  vmovaps [rsp+0xC0], xmm12
00007981ddfd6909  vmovaps [rsp+0xD0], xmm13
00007981ddfd6912  vmovaps [rsp+0xE0], xmm15
00007981ddfd691b  sub rsp, 0x30
00007981ddfd691f  movaps [rsp], xmm14
00007981ddfd6924  movaps [rsp+0x10], xmm9
00007981ddfd692a  movaps [rsp+0x20], xmm13
00007981ddfd6930  lea rdi, [rsp]
00007981ddfd6934  mov esi, 0x00
00007981ddfd6939  mov rax, 0x5782A6EB3530
00007981ddfd6943  call rax
00007981ddfd6945  movaps xmm14, [rsp]
00007981ddfd694a  add rsp, 0x30
00007981ddfd694e  vmovaps xmm0, [rsp]
00007981ddfd6953  vmovaps xmm1, [rsp+0x10]
00007981ddfd6959  vmovaps xmm2, [rsp+0x20]
00007981ddfd695f  vmovaps xmm3, [rsp+0x30]
00007981ddfd6965  vmovaps xmm4, [rsp+0x40]
00007981ddfd696b  vmovaps xmm5, [rsp+0x50]
00007981ddfd6971  vmovaps xmm6, [rsp+0x60]
00007981ddfd6977  vmovaps xmm7, [rsp+0x70]
00007981ddfd697d  vmovaps xmm8, [rsp+0x80]
00007981ddfd6986  vmovaps xmm9, [rsp+0x90]
00007981ddfd698f  vmovaps xmm10, [rsp+0xA0]
00007981ddfd6998  vmovaps xmm11, [rsp+0xB0]
00007981ddfd69a1  vmovaps xmm12, [rsp+0xC0]
00007981ddfd69aa  vmovaps xmm13, [rsp+0xD0]
00007981ddfd69b3  vmovaps xmm15, [rsp+0xE0]
00007981ddfd69bc  add rsp, 0xF0
00007981ddfd69c3  pop r11
00007981ddfd69c5  pop r10
00007981ddfd69c7  pop r9
00007981ddfd69c9  pop r8
00007981ddfd69cb  pop rsi
00007981ddfd69cc  pop rdi
00007981ddfd69cd  pop rdx
00007981ddfd69ce  pop rcx
00007981ddfd69cf  pop rax
00007981ddfd69d0  add rsp, 0x08
00007981ddfd69d4  jmp 0x00007981DDFD3176
00007981ddfd69d9  sub rsp, 0x08
00007981ddfd69dd  push rax
00007981ddfd69de  push rcx
00007981ddfd69df  push rdx
00007981ddfd69e0  push rdi
00007981ddfd69e1  push rsi
00007981ddfd69e2  push r8
00007981ddfd69e4  push r9
00007981ddfd69e6  push r10
00007981ddfd69e8  push r11
00007981ddfd69ea  sub rsp, 0xF0
00007981ddfd69f1  vmovaps [rsp], xmm0
00007981ddfd69f6  vmovaps [rsp+0x10], xmm1
00007981ddfd69fc  vmovaps [rsp+0x20], xmm2
00007981ddfd6a02  vmovaps [rsp+0x30], xmm3
00007981ddfd6a08  vmovaps [rsp+0x40], xmm4
00007981ddfd6a0e  vmovaps [rsp+0x50], xmm5
00007981ddfd6a14  vmovaps [rsp+0x60], xmm6
00007981ddfd6a1a  vmovaps [rsp+0x70], xmm7
00007981ddfd6a20  vmovaps [rsp+0x80], xmm8
00007981ddfd6a29  vmovaps [rsp+0x90], xmm9
00007981ddfd6a32  vmovaps [rsp+0xA0], xmm10
00007981ddfd6a3b  vmovaps [rsp+0xB0], xmm11
00007981ddfd6a44  vmovaps [rsp+0xC0], xmm12
00007981ddfd6a4d  vmovaps [rsp+0xD0], xmm14
00007981ddfd6a56  vmovaps [rsp+0xE0], xmm15
00007981ddfd6a5f  sub rsp, 0x30
00007981ddfd6a63  movaps [rsp], xmm13
00007981ddfd6a68  movaps [rsp+0x10], xmm9
00007981ddfd6a6e  movaps [rsp+0x20], xmm10
00007981ddfd6a74  lea rdi, [rsp]
00007981ddfd6a78  mov esi, 0x00
00007981ddfd6a7d  mov rax, 0x5782A6EB3530
00007981ddfd6a87  call rax
00007981ddfd6a89  movaps xmm13, [rsp]
00007981ddfd6a8e  add rsp, 0x30
00007981ddfd6a92  vmovaps xmm0, [rsp]
00007981ddfd6a97  vmovaps xmm1, [rsp+0x10]
00007981ddfd6a9d  vmovaps xmm2, [rsp+0x20]
00007981ddfd6aa3  vmovaps xmm3, [rsp+0x30]
00007981ddfd6aa9  vmovaps xmm4, [rsp+0x40]
00007981ddfd6aaf  vmovaps xmm5, [rsp+0x50]
00007981ddfd6ab5  vmovaps xmm6, [rsp+0x60]
00007981ddfd6abb  vmovaps xmm7, [rsp+0x70]
00007981ddfd6ac1  vmovaps xmm8, [rsp+0x80]
00007981ddfd6aca  vmovaps xmm9, [rsp+0x90]
00007981ddfd6ad3  vmovaps xmm10, [rsp+0xA0]
00007981ddfd6adc  vmovaps xmm11, [rsp+0xB0]
00007981ddfd6ae5  vmovaps xmm12, [rsp+0xC0]
00007981ddfd6aee  vmovaps xmm14, [rsp+0xD0]
00007981ddfd6af7  vmovaps xmm15, [rsp+0xE0]
00007981ddfd6b00  add rsp, 0xF0
00007981ddfd6b07  pop r11
00007981ddfd6b09  pop r10
00007981ddfd6b0b  pop r9
00007981ddfd6b0d  pop r8
00007981ddfd6b0f  pop rsi
00007981ddfd6b10  pop rdi
00007981ddfd6b11  pop rdx
00007981ddfd6b12  pop rcx
00007981ddfd6b13  pop rax
00007981ddfd6b14  add rsp, 0x08
00007981ddfd6b18  jmp 0x00007981DDFD3196
00007981ddfd6b1d  call 0x00007981DDE0AFE0
00007981ddfd6b22  jmp 0x00007981DDFD31EB
00007981ddfd6b27  sub rsp, 0x08
00007981ddfd6b2b  push rax
00007981ddfd6b2c  push rcx
00007981ddfd6b2d  push rdx
00007981ddfd6b2e  push rdi
00007981ddfd6b2f  push rsi
00007981ddfd6b30  push r8
00007981ddfd6b32  push r9
00007981ddfd6b34  push r10
00007981ddfd6b36  push r11
00007981ddfd6b38  sub rsp, 0xF0
00007981ddfd6b3f  vmovaps [rsp], xmm0
00007981ddfd6b44  vmovaps [rsp+0x10], xmm1
00007981ddfd6b4a  vmovaps [rsp+0x20], xmm2
00007981ddfd6b50  vmovaps [rsp+0x30], xmm3
00007981ddfd6b56  vmovaps [rsp+0x40], xmm4
00007981ddfd6b5c  vmovaps [rsp+0x50], xmm5
00007981ddfd6b62  vmovaps [rsp+0x60], xmm6
00007981ddfd6b68  vmovaps [rsp+0x70], xmm7
00007981ddfd6b6e  vmovaps [rsp+0x80], xmm8
00007981ddfd6b77  vmovaps [rsp+0x90], xmm10
00007981ddfd6b80  vmovaps [rsp+0xA0], xmm11
00007981ddfd6b89  vmovaps [rsp+0xB0], xmm12
00007981ddfd6b92  vmovaps [rsp+0xC0], xmm13
00007981ddfd6b9b  vmovaps [rsp+0xD0], xmm14
00007981ddfd6ba4  vmovaps [rsp+0xE0], xmm15
00007981ddfd6bad  sub rsp, 0x30
00007981ddfd6bb1  movaps [rsp], xmm9
00007981ddfd6bb6  movaps [rsp+0x10], xmm8
00007981ddfd6bbc  movaps [rsp+0x20], xmm10
00007981ddfd6bc2  lea rdi, [rsp]
00007981ddfd6bc6  mov esi, 0x00
00007981ddfd6bcb  mov rax, 0x5782A6EB3530
00007981ddfd6bd5  call rax
00007981ddfd6bd7  movaps xmm9, [rsp]
00007981ddfd6bdc  add rsp, 0x30
00007981ddfd6be0  vmovaps xmm0, [rsp]
00007981ddfd6be5  vmovaps xmm1, [rsp+0x10]
00007981ddfd6beb  vmovaps xmm2, [rsp+0x20]
00007981ddfd6bf1  vmovaps xmm3, [rsp+0x30]
00007981ddfd6bf7  vmovaps xmm4, [rsp+0x40]
00007981ddfd6bfd  vmovaps xmm5, [rsp+0x50]
00007981ddfd6c03  vmovaps xmm6, [rsp+0x60]
00007981ddfd6c09  vmovaps xmm7, [rsp+0x70]
00007981ddfd6c0f  vmovaps xmm8, [rsp+0x80]
00007981ddfd6c18  vmovaps xmm10, [rsp+0x90]
00007981ddfd6c21  vmovaps xmm11, [rsp+0xA0]
00007981ddfd6c2a  vmovaps xmm12, [rsp+0xB0]
00007981ddfd6c33  vmovaps xmm13, [rsp+0xC0]
00007981ddfd6c3c  vmovaps xmm14, [rsp+0xD0]
00007981ddfd6c45  vmovaps xmm15, [rsp+0xE0]
00007981ddfd6c4e  add rsp, 0xF0
00007981ddfd6c55  pop r11
00007981ddfd6c57  pop r10
00007981ddfd6c59  pop r9
00007981ddfd6c5b  pop r8
00007981ddfd6c5d  pop rsi
00007981ddfd6c5e  pop rdi
00007981ddfd6c5f  pop rdx
00007981ddfd6c60  pop rcx
00007981ddfd6c61  pop rax
00007981ddfd6c62  add rsp, 0x08
00007981ddfd6c66  jmp 0x00007981DDFD321C
00007981ddfd6c6b  sub rsp, 0x08
00007981ddfd6c6f  push rax
00007981ddfd6c70  push rcx
00007981ddfd6c71  push rdx
00007981ddfd6c72  push rdi
00007981ddfd6c73  push rsi
00007981ddfd6c74  push r8
00007981ddfd6c76  push r9
00007981ddfd6c78  push r10
00007981ddfd6c7a  push r11
00007981ddfd6c7c  sub rsp, 0xF0
00007981ddfd6c83  vmovaps [rsp], xmm0
00007981ddfd6c88  vmovaps [rsp+0x10], xmm1
00007981ddfd6c8e  vmovaps [rsp+0x20], xmm2
00007981ddfd6c94  vmovaps [rsp+0x30], xmm3
00007981ddfd6c9a  vmovaps [rsp+0x40], xmm4
00007981ddfd6ca0  vmovaps [rsp+0x50], xmm5
00007981ddfd6ca6  vmovaps [rsp+0x60], xmm6
00007981ddfd6cac  vmovaps [rsp+0x70], xmm7
00007981ddfd6cb2  vmovaps [rsp+0x80], xmm8
00007981ddfd6cbb  vmovaps [rsp+0x90], xmm9
00007981ddfd6cc4  vmovaps [rsp+0xA0], xmm11
00007981ddfd6ccd  vmovaps [rsp+0xB0], xmm12
00007981ddfd6cd6  vmovaps [rsp+0xC0], xmm13
00007981ddfd6cdf  vmovaps [rsp+0xD0], xmm14
00007981ddfd6ce8  vmovaps [rsp+0xE0], xmm15
00007981ddfd6cf1  sub rsp, 0x30
00007981ddfd6cf5  movaps [rsp], xmm10
00007981ddfd6cfa  movaps [rsp+0x10], xmm1
00007981ddfd6cff  movaps [rsp+0x20], xmm11
00007981ddfd6d05  lea rdi, [rsp]
00007981ddfd6d09  mov esi, 0x00
00007981ddfd6d0e  mov rax, 0x5782A6EB3530
00007981ddfd6d18  call rax
00007981ddfd6d1a  movaps xmm10, [rsp]
00007981ddfd6d1f  add rsp, 0x30
00007981ddfd6d23  vmovaps xmm0, [rsp]
00007981ddfd6d28  vmovaps xmm1, [rsp+0x10]
00007981ddfd6d2e  vmovaps xmm2, [rsp+0x20]
00007981ddfd6d34  vmovaps xmm3, [rsp+0x30]
00007981ddfd6d3a  vmovaps xmm4, [rsp+0x40]
00007981ddfd6d40  vmovaps xmm5, [rsp+0x50]
00007981ddfd6d46  vmovaps xmm6, [rsp+0x60]
00007981ddfd6d4c  vmovaps xmm7, [rsp+0x70]
00007981ddfd6d52  vmovaps xmm8, [rsp+0x80]
00007981ddfd6d5b  vmovaps xmm9, [rsp+0x90]
00007981ddfd6d64  vmovaps xmm11, [rsp+0xA0]
00007981ddfd6d6d  vmovaps xmm12, [rsp+0xB0]
00007981ddfd6d76  vmovaps xmm13, [rsp+0xC0]
00007981ddfd6d7f  vmovaps xmm14, [rsp+0xD0]
00007981ddfd6d88  vmovaps xmm15, [rsp+0xE0]
00007981ddfd6d91  add rsp, 0xF0
00007981ddfd6d98  pop r11
00007981ddfd6d9a  pop r10
00007981ddfd6d9c  pop r9
00007981ddfd6d9e  pop r8
00007981ddfd6da0  pop rsi
00007981ddfd6da1  pop rdi
00007981ddfd6da2  pop rdx
00007981ddfd6da3  pop rcx
00007981ddfd6da4  pop rax
00007981ddfd6da5  add rsp, 0x08
00007981ddfd6da9  jmp 0x00007981DDFD3237
00007981ddfd6dae  sub rsp, 0x08
00007981ddfd6db2  push rax
00007981ddfd6db3  push rcx
00007981ddfd6db4  push rdx
00007981ddfd6db5  push rdi
00007981ddfd6db6  push rsi
00007981ddfd6db7  push r8
00007981ddfd6db9  push r9
00007981ddfd6dbb  push r10
00007981ddfd6dbd  push r11
00007981ddfd6dbf  sub rsp, 0xF0
00007981ddfd6dc6  vmovaps [rsp], xmm0
00007981ddfd6dcb  vmovaps [rsp+0x10], xmm2
00007981ddfd6dd1  vmovaps [rsp+0x20], xmm3
00007981ddfd6dd7  vmovaps [rsp+0x30], xmm4
00007981ddfd6ddd  vmovaps [rsp+0x40], xmm5
00007981ddfd6de3  vmovaps [rsp+0x50], xmm6
00007981ddfd6de9  vmovaps [rsp+0x60], xmm7
00007981ddfd6def  vmovaps [rsp+0x70], xmm8
00007981ddfd6df5  vmovaps [rsp+0x80], xmm9
00007981ddfd6dfe  vmovaps [rsp+0x90], xmm10
00007981ddfd6e07  vmovaps [rsp+0xA0], xmm11
00007981ddfd6e10  vmovaps [rsp+0xB0], xmm12
00007981ddfd6e19  vmovaps [rsp+0xC0], xmm13
00007981ddfd6e22  vmovaps [rsp+0xD0], xmm14
00007981ddfd6e2b  vmovaps [rsp+0xE0], xmm15
00007981ddfd6e34  sub rsp, 0x30
00007981ddfd6e38  movaps [rsp], xmm1
00007981ddfd6e3c  movaps [rsp+0x10], xmm15
00007981ddfd6e42  movaps [rsp+0x20], xmm6
00007981ddfd6e47  lea rdi, [rsp]
00007981ddfd6e4b  mov esi, 0x00
00007981ddfd6e50  mov rax, 0x5782A6EB3530
00007981ddfd6e5a  call rax
00007981ddfd6e5c  movaps xmm1, [rsp]
00007981ddfd6e60  add rsp, 0x30
00007981ddfd6e64  vmovaps xmm0, [rsp]
00007981ddfd6e69  vmovaps xmm2, [rsp+0x10]
00007981ddfd6e6f  vmovaps xmm3, [rsp+0x20]
00007981ddfd6e75  vmovaps xmm4, [rsp+0x30]
00007981ddfd6e7b  vmovaps xmm5, [rsp+0x40]
00007981ddfd6e81  vmovaps xmm6, [rsp+0x50]
00007981ddfd6e87  vmovaps xmm7, [rsp+0x60]
00007981ddfd6e8d  vmovaps xmm8, [rsp+0x70]
00007981ddfd6e93  vmovaps xmm9, [rsp+0x80]
00007981ddfd6e9c  vmovaps xmm10, [rsp+0x90]
00007981ddfd6ea5  vmovaps xmm11, [rsp+0xA0]
00007981ddfd6eae  vmovaps xmm12, [rsp+0xB0]
00007981ddfd6eb7  vmovaps xmm13, [rsp+0xC0]
00007981ddfd6ec0  vmovaps xmm14, [rsp+0xD0]
00007981ddfd6ec9  vmovaps xmm15, [rsp+0xE0]
00007981ddfd6ed2  add rsp, 0xF0
00007981ddfd6ed9  pop r11
00007981ddfd6edb  pop r10
00007981ddfd6edd  pop r9
00007981ddfd6edf  pop r8
00007981ddfd6ee1  pop rsi
00007981ddfd6ee2  pop rdi
00007981ddfd6ee3  pop rdx
00007981ddfd6ee4  pop rcx
00007981ddfd6ee5  pop rax
00007981ddfd6ee6  add rsp, 0x08
00007981ddfd6eea  jmp 0x00007981DDFD3250
00007981ddfd6eef  sub rsp, 0x08
00007981ddfd6ef3  push rax
00007981ddfd6ef4  push rcx
00007981ddfd6ef5  push rdx
00007981ddfd6ef6  push rdi
00007981ddfd6ef7  push rsi
00007981ddfd6ef8  push r8
00007981ddfd6efa  push r9
00007981ddfd6efc  push r10
00007981ddfd6efe  push r11
00007981ddfd6f00  sub rsp, 0xF0
00007981ddfd6f07  vmovaps [rsp], xmm0
00007981ddfd6f0c  vmovaps [rsp+0x10], xmm1
00007981ddfd6f12  vmovaps [rsp+0x20], xmm2
00007981ddfd6f18  vmovaps [rsp+0x30], xmm3
00007981ddfd6f1e  vmovaps [rsp+0x40], xmm4
00007981ddfd6f24  vmovaps [rsp+0x50], xmm5
00007981ddfd6f2a  vmovaps [rsp+0x60], xmm6
00007981ddfd6f30  vmovaps [rsp+0x70], xmm7
00007981ddfd6f36  vmovaps [rsp+0x80], xmm8
00007981ddfd6f3f  vmovaps [rsp+0x90], xmm9
00007981ddfd6f48  vmovaps [rsp+0xA0], xmm10
00007981ddfd6f51  vmovaps [rsp+0xB0], xmm12
00007981ddfd6f5a  vmovaps [rsp+0xC0], xmm13
00007981ddfd6f63  vmovaps [rsp+0xD0], xmm14
00007981ddfd6f6c  vmovaps [rsp+0xE0], xmm15
00007981ddfd6f75  sub rsp, 0x30
00007981ddfd6f79  movaps [rsp], xmm11
00007981ddfd6f7e  movaps [rsp+0x10], xmm12
00007981ddfd6f84  movaps [rsp+0x20], xmm15
00007981ddfd6f8a  lea rdi, [rsp]
00007981ddfd6f8e  mov esi, 0x00
00007981ddfd6f93  mov rax, 0x5782A6EB3530
00007981ddfd6f9d  call rax
00007981ddfd6f9f  movaps xmm11, [rsp]
00007981ddfd6fa4  add rsp, 0x30
00007981ddfd6fa8  vmovaps xmm0, [rsp]
00007981ddfd6fad  vmovaps xmm1, [rsp+0x10]
00007981ddfd6fb3  vmovaps xmm2, [rsp+0x20]
00007981ddfd6fb9  vmovaps xmm3, [rsp+0x30]
00007981ddfd6fbf  vmovaps xmm4, [rsp+0x40]
00007981ddfd6fc5  vmovaps xmm5, [rsp+0x50]
00007981ddfd6fcb  vmovaps xmm6, [rsp+0x60]
00007981ddfd6fd1  vmovaps xmm7, [rsp+0x70]
00007981ddfd6fd7  vmovaps xmm8, [rsp+0x80]
00007981ddfd6fe0  vmovaps xmm9, [rsp+0x90]
00007981ddfd6fe9  vmovaps xmm10, [rsp+0xA0]
00007981ddfd6ff2  vmovaps xmm12, [rsp+0xB0]
00007981ddfd6ffb  vmovaps xmm13, [rsp+0xC0]
00007981ddfd7004  vmovaps xmm14, [rsp+0xD0]
00007981ddfd700d  vmovaps xmm15, [rsp+0xE0]
00007981ddfd7016  add rsp, 0xF0
00007981ddfd701d  pop r11
00007981ddfd701f  pop r10
00007981ddfd7021  pop r9
00007981ddfd7023  pop r8
00007981ddfd7025  pop rsi
00007981ddfd7026  pop rdi
00007981ddfd7027  pop rdx
00007981ddfd7028  pop rcx
00007981ddfd7029  pop rax
00007981ddfd702a  add rsp, 0x08
00007981ddfd702e  jmp 0x00007981DDFD327A
00007981ddfd7033  sub rsp, 0x08
00007981ddfd7037  push rax
00007981ddfd7038  push rcx
00007981ddfd7039  push rdx
00007981ddfd703a  push rdi
00007981ddfd703b  push rsi
00007981ddfd703c  push r8
00007981ddfd703e  push r9
00007981ddfd7040  push r10
00007981ddfd7042  push r11
00007981ddfd7044  sub rsp, 0xF0
00007981ddfd704b  vmovaps [rsp], xmm0
00007981ddfd7050  vmovaps [rsp+0x10], xmm1
00007981ddfd7056  vmovaps [rsp+0x20], xmm2
00007981ddfd705c  vmovaps [rsp+0x30], xmm3
00007981ddfd7062  vmovaps [rsp+0x40], xmm4
00007981ddfd7068  vmovaps [rsp+0x50], xmm5
00007981ddfd706e  vmovaps [rsp+0x60], xmm6
00007981ddfd7074  vmovaps [rsp+0x70], xmm7
00007981ddfd707a  vmovaps [rsp+0x80], xmm8
00007981ddfd7083  vmovaps [rsp+0x90], xmm9
00007981ddfd708c  vmovaps [rsp+0xA0], xmm10
00007981ddfd7095  vmovaps [rsp+0xB0], xmm11
00007981ddfd709e  vmovaps [rsp+0xC0], xmm13
00007981ddfd70a7  vmovaps [rsp+0xD0], xmm14
00007981ddfd70b0  vmovaps [rsp+0xE0], xmm15
00007981ddfd70b9  sub rsp, 0x30
00007981ddfd70bd  movaps [rsp], xmm12
00007981ddfd70c2  movaps [rsp+0x10], xmm8
00007981ddfd70c8  movaps [rsp+0x20], xmm15
00007981ddfd70ce  lea rdi, [rsp]
00007981ddfd70d2  mov esi, 0x00
00007981ddfd70d7  mov rax, 0x5782A6EB3530
00007981ddfd70e1  call rax
00007981ddfd70e3  movaps xmm12, [rsp]
00007981ddfd70e8  add rsp, 0x30
00007981ddfd70ec  vmovaps xmm0, [rsp]
00007981ddfd70f1  vmovaps xmm1, [rsp+0x10]
00007981ddfd70f7  vmovaps xmm2, [rsp+0x20]
00007981ddfd70fd  vmovaps xmm3, [rsp+0x30]
00007981ddfd7103  vmovaps xmm4, [rsp+0x40]
00007981ddfd7109  vmovaps xmm5, [rsp+0x50]
00007981ddfd710f  vmovaps xmm6, [rsp+0x60]
00007981ddfd7115  vmovaps xmm7, [rsp+0x70]
00007981ddfd711b  vmovaps xmm8, [rsp+0x80]
00007981ddfd7124  vmovaps xmm9, [rsp+0x90]
00007981ddfd712d  vmovaps xmm10, [rsp+0xA0]
00007981ddfd7136  vmovaps xmm11, [rsp+0xB0]
00007981ddfd713f  vmovaps xmm13, [rsp+0xC0]
00007981ddfd7148  vmovaps xmm14, [rsp+0xD0]
00007981ddfd7151  vmovaps xmm15, [rsp+0xE0]
00007981ddfd715a  add rsp, 0xF0
00007981ddfd7161  pop r11
00007981ddfd7163  pop r10
00007981ddfd7165  pop r9
00007981ddfd7167  pop r8
00007981ddfd7169  pop rsi
00007981ddfd716a  pop rdi
00007981ddfd716b  pop rdx
00007981ddfd716c  pop rcx
00007981ddfd716d  pop rax
00007981ddfd716e  add rsp, 0x08
00007981ddfd7172  jmp 0x00007981DDFD32A9
00007981ddfd7177  sub rsp, 0x08
00007981ddfd717b  push rax
00007981ddfd717c  push rcx
00007981ddfd717d  push rdx
00007981ddfd717e  push rdi
00007981ddfd717f  push rsi
00007981ddfd7180  push r8
00007981ddfd7182  push r9
00007981ddfd7184  push r10
00007981ddfd7186  push r11
00007981ddfd7188  sub rsp, 0xF0
00007981ddfd718f  vmovaps [rsp], xmm0
00007981ddfd7194  vmovaps [rsp+0x10], xmm1
00007981ddfd719a  vmovaps [rsp+0x20], xmm2
00007981ddfd71a0  vmovaps [rsp+0x30], xmm3
00007981ddfd71a6  vmovaps [rsp+0x40], xmm4
00007981ddfd71ac  vmovaps [rsp+0x50], xmm5
00007981ddfd71b2  vmovaps [rsp+0x60], xmm6
00007981ddfd71b8  vmovaps [rsp+0x70], xmm7
00007981ddfd71be  vmovaps [rsp+0x80], xmm9
00007981ddfd71c7  vmovaps [rsp+0x90], xmm10
00007981ddfd71d0  vmovaps [rsp+0xA0], xmm11
00007981ddfd71d9  vmovaps [rsp+0xB0], xmm12
00007981ddfd71e2  vmovaps [rsp+0xC0], xmm13
00007981ddfd71eb  vmovaps [rsp+0xD0], xmm14
00007981ddfd71f4  vmovaps [rsp+0xE0], xmm15
00007981ddfd71fd  sub rsp, 0x30
00007981ddfd7201  movaps [rsp], xmm8
00007981ddfd7206  movaps [rsp+0x10], xmm7
00007981ddfd720b  movaps [rsp+0x20], xmm15
00007981ddfd7211  lea rdi, [rsp]
00007981ddfd7215  mov esi, 0x00
00007981ddfd721a  mov rax, 0x5782A6EB3530
00007981ddfd7224  call rax
00007981ddfd7226  movaps xmm8, [rsp]
00007981ddfd722b  add rsp, 0x30
00007981ddfd722f  vmovaps xmm0, [rsp]
00007981ddfd7234  vmovaps xmm1, [rsp+0x10]
00007981ddfd723a  vmovaps xmm2, [rsp+0x20]
00007981ddfd7240  vmovaps xmm3, [rsp+0x30]
00007981ddfd7246  vmovaps xmm4, [rsp+0x40]
00007981ddfd724c  vmovaps xmm5, [rsp+0x50]
00007981ddfd7252  vmovaps xmm6, [rsp+0x60]
00007981ddfd7258  vmovaps xmm7, [rsp+0x70]
00007981ddfd725e  vmovaps xmm9, [rsp+0x80]
00007981ddfd7267  vmovaps xmm10, [rsp+0x90]
00007981ddfd7270  vmovaps xmm11, [rsp+0xA0]
00007981ddfd7279  vmovaps xmm12, [rsp+0xB0]
00007981ddfd7282  vmovaps xmm13, [rsp+0xC0]
00007981ddfd728b  vmovaps xmm14, [rsp+0xD0]
00007981ddfd7294  vmovaps xmm15, [rsp+0xE0]
00007981ddfd729d  add rsp, 0xF0
00007981ddfd72a4  pop r11
00007981ddfd72a6  pop r10
00007981ddfd72a8  pop r9
00007981ddfd72aa  pop r8
00007981ddfd72ac  pop rsi
00007981ddfd72ad  pop rdi
00007981ddfd72ae  pop rdx
00007981ddfd72af  pop rcx
00007981ddfd72b0  pop rax
00007981ddfd72b1  add rsp, 0x08
00007981ddfd72b5  jmp 0x00007981DDFD32CF
00007981ddfd72ba  sub rsp, 0x08
00007981ddfd72be  push rax
00007981ddfd72bf  push rcx
00007981ddfd72c0  push rdx
00007981ddfd72c1  push rdi
00007981ddfd72c2  push rsi
00007981ddfd72c3  push r8
00007981ddfd72c5  push r9
00007981ddfd72c7  push r10
00007981ddfd72c9  push r11
00007981ddfd72cb  sub rsp, 0xF0
00007981ddfd72d2  vmovaps [rsp], xmm0
00007981ddfd72d7  vmovaps [rsp+0x10], xmm1
00007981ddfd72dd  vmovaps [rsp+0x20], xmm2
00007981ddfd72e3  vmovaps [rsp+0x30], xmm3
00007981ddfd72e9  vmovaps [rsp+0x40], xmm4
00007981ddfd72ef  vmovaps [rsp+0x50], xmm5
00007981ddfd72f5  vmovaps [rsp+0x60], xmm6
00007981ddfd72fb  vmovaps [rsp+0x70], xmm7
00007981ddfd7301  vmovaps [rsp+0x80], xmm8
00007981ddfd730a  vmovaps [rsp+0x90], xmm9
00007981ddfd7313  vmovaps [rsp+0xA0], xmm10
00007981ddfd731c  vmovaps [rsp+0xB0], xmm11
00007981ddfd7325  vmovaps [rsp+0xC0], xmm12
00007981ddfd732e  vmovaps [rsp+0xD0], xmm13
00007981ddfd7337  vmovaps [rsp+0xE0], xmm14
00007981ddfd7340  sub rsp, 0x30
00007981ddfd7344  movaps [rsp], xmm15
00007981ddfd7349  movaps [rsp+0x10], xmm14
00007981ddfd734f  movaps [rsp+0x20], xmm9
00007981ddfd7355  lea rdi, [rsp]
00007981ddfd7359  mov esi, 0x00
00007981ddfd735e  mov rax, 0x5782A6EB3530
00007981ddfd7368  call rax
00007981ddfd736a  movaps xmm15, [rsp]
00007981ddfd736f  add rsp, 0x30
00007981ddfd7373  vmovaps xmm0, [rsp]
00007981ddfd7378  vmovaps xmm1, [rsp+0x10]
00007981ddfd737e  vmovaps xmm2, [rsp+0x20]
00007981ddfd7384  vmovaps xmm3, [rsp+0x30]
00007981ddfd738a  vmovaps xmm4, [rsp+0x40]
00007981ddfd7390  vmovaps xmm5, [rsp+0x50]
00007981ddfd7396  vmovaps xmm6, [rsp+0x60]
00007981ddfd739c  vmovaps xmm7, [rsp+0x70]
00007981ddfd73a2  vmovaps xmm8, [rsp+0x80]
00007981ddfd73ab  vmovaps xmm9, [rsp+0x90]
00007981ddfd73b4  vmovaps xmm10, [rsp+0xA0]
00007981ddfd73bd  vmovaps xmm11, [rsp+0xB0]
00007981ddfd73c6  vmovaps xmm12, [rsp+0xC0]
00007981ddfd73cf  vmovaps xmm13, [rsp+0xD0]
00007981ddfd73d8  vmovaps xmm14, [rsp+0xE0]
00007981ddfd73e1  add rsp, 0xF0
00007981ddfd73e8  pop r11
00007981ddfd73ea  pop r10
00007981ddfd73ec  pop r9
00007981ddfd73ee  pop r8
00007981ddfd73f0  pop rsi
00007981ddfd73f1  pop rdi
00007981ddfd73f2  pop rdx
00007981ddfd73f3  pop rcx
00007981ddfd73f4  pop rax
00007981ddfd73f5  add rsp, 0x08
00007981ddfd73f9  jmp 0x00007981DDFD32E9
00007981ddfd73fe  sub rsp, 0x08
00007981ddfd7402  push rax
00007981ddfd7403  push rcx
00007981ddfd7404  push rdx
00007981ddfd7405  push rdi
00007981ddfd7406  push rsi
00007981ddfd7407  push r8
00007981ddfd7409  push r9
00007981ddfd740b  push r10
00007981ddfd740d  push r11
00007981ddfd740f  sub rsp, 0xF0
00007981ddfd7416  vmovaps [rsp], xmm0
00007981ddfd741b  vmovaps [rsp+0x10], xmm1
00007981ddfd7421  vmovaps [rsp+0x20], xmm2
00007981ddfd7427  vmovaps [rsp+0x30], xmm3
00007981ddfd742d  vmovaps [rsp+0x40], xmm4
00007981ddfd7433  vmovaps [rsp+0x50], xmm5
00007981ddfd7439  vmovaps [rsp+0x60], xmm6
00007981ddfd743f  vmovaps [rsp+0x70], xmm7
00007981ddfd7445  vmovaps [rsp+0x80], xmm8
00007981ddfd744e  vmovaps [rsp+0x90], xmm10
00007981ddfd7457  vmovaps [rsp+0xA0], xmm11
00007981ddfd7460  vmovaps [rsp+0xB0], xmm12
00007981ddfd7469  vmovaps [rsp+0xC0], xmm13
00007981ddfd7472  vmovaps [rsp+0xD0], xmm14
00007981ddfd747b  vmovaps [rsp+0xE0], xmm15
00007981ddfd7484  sub rsp, 0x30
00007981ddfd7488  movaps [rsp], xmm9
00007981ddfd748d  movaps [rsp+0x10], xmm7
00007981ddfd7492  movaps [rsp+0x20], xmm14
00007981ddfd7498  lea rdi, [rsp]
00007981ddfd749c  mov esi, 0x00
00007981ddfd74a1  mov rax, 0x5782A6EB3530
00007981ddfd74ab  call rax
00007981ddfd74ad  movaps xmm9, [rsp]
00007981ddfd74b2  add rsp, 0x30
00007981ddfd74b6  vmovaps xmm0, [rsp]
00007981ddfd74bb  vmovaps xmm1, [rsp+0x10]
00007981ddfd74c1  vmovaps xmm2, [rsp+0x20]
00007981ddfd74c7  vmovaps xmm3, [rsp+0x30]
00007981ddfd74cd  vmovaps xmm4, [rsp+0x40]
00007981ddfd74d3  vmovaps xmm5, [rsp+0x50]
00007981ddfd74d9  vmovaps xmm6, [rsp+0x60]
00007981ddfd74df  vmovaps xmm7, [rsp+0x70]
00007981ddfd74e5  vmovaps xmm8, [rsp+0x80]
00007981ddfd74ee  vmovaps xmm10, [rsp+0x90]
00007981ddfd74f7  vmovaps xmm11, [rsp+0xA0]
00007981ddfd7500  vmovaps xmm12, [rsp+0xB0]
00007981ddfd7509  vmovaps xmm13, [rsp+0xC0]
00007981ddfd7512  vmovaps xmm14, [rsp+0xD0]
00007981ddfd751b  vmovaps xmm15, [rsp+0xE0]
00007981ddfd7524  add rsp, 0xF0
00007981ddfd752b  pop r11
00007981ddfd752d  pop r10
00007981ddfd752f  pop r9
00007981ddfd7531  pop r8
00007981ddfd7533  pop rsi
00007981ddfd7534  pop rdi
00007981ddfd7535  pop rdx
00007981ddfd7536  pop rcx
00007981ddfd7537  pop rax
00007981ddfd7538  add rsp, 0x08
00007981ddfd753c  jmp 0x00007981DDFD3318
00007981ddfd7541  sub rsp, 0x08
00007981ddfd7545  push rax
00007981ddfd7546  push rcx
00007981ddfd7547  push rdx
00007981ddfd7548  push rdi
00007981ddfd7549  push rsi
00007981ddfd754a  push r8
00007981ddfd754c  push r9
00007981ddfd754e  push r10
00007981ddfd7550  push r11
00007981ddfd7552  sub rsp, 0xF0
00007981ddfd7559  vmovaps [rsp], xmm0
00007981ddfd755e  vmovaps [rsp+0x10], xmm1
00007981ddfd7564  vmovaps [rsp+0x20], xmm2
00007981ddfd756a  vmovaps [rsp+0x30], xmm3
00007981ddfd7570  vmovaps [rsp+0x40], xmm4
00007981ddfd7576  vmovaps [rsp+0x50], xmm5
00007981ddfd757c  vmovaps [rsp+0x60], xmm6
00007981ddfd7582  vmovaps [rsp+0x70], xmm7
00007981ddfd7588  vmovaps [rsp+0x80], xmm8
00007981ddfd7591  vmovaps [rsp+0x90], xmm9
00007981ddfd759a  vmovaps [rsp+0xA0], xmm10
00007981ddfd75a3  vmovaps [rsp+0xB0], xmm11
00007981ddfd75ac  vmovaps [rsp+0xC0], xmm12
00007981ddfd75b5  vmovaps [rsp+0xD0], xmm13
00007981ddfd75be  vmovaps [rsp+0xE0], xmm15
00007981ddfd75c7  sub rsp, 0x30
00007981ddfd75cb  movaps [rsp], xmm14
00007981ddfd75d0  movaps [rsp+0x10], xmm13
00007981ddfd75d6  movaps [rsp+0x20], xmm11
00007981ddfd75dc  lea rdi, [rsp]
00007981ddfd75e0  mov esi, 0x00
00007981ddfd75e5  mov rax, 0x5782A6EB3530
00007981ddfd75ef  call rax
00007981ddfd75f1  movaps xmm14, [rsp]
00007981ddfd75f6  add rsp, 0x30
00007981ddfd75fa  vmovaps xmm0, [rsp]
00007981ddfd75ff  vmovaps xmm1, [rsp+0x10]
00007981ddfd7605  vmovaps xmm2, [rsp+0x20]
00007981ddfd760b  vmovaps xmm3, [rsp+0x30]
00007981ddfd7611  vmovaps xmm4, [rsp+0x40]
00007981ddfd7617  vmovaps xmm5, [rsp+0x50]
00007981ddfd761d  vmovaps xmm6, [rsp+0x60]
00007981ddfd7623  vmovaps xmm7, [rsp+0x70]
00007981ddfd7629  vmovaps xmm8, [rsp+0x80]
00007981ddfd7632  vmovaps xmm9, [rsp+0x90]
00007981ddfd763b  vmovaps xmm10, [rsp+0xA0]
00007981ddfd7644  vmovaps xmm11, [rsp+0xB0]
00007981ddfd764d  vmovaps xmm12, [rsp+0xC0]
00007981ddfd7656  vmovaps xmm13, [rsp+0xD0]
00007981ddfd765f  vmovaps xmm15, [rsp+0xE0]
00007981ddfd7668  add rsp, 0xF0
00007981ddfd766f  pop r11
00007981ddfd7671  pop r10
00007981ddfd7673  pop r9
00007981ddfd7675  pop r8
00007981ddfd7677  pop rsi
00007981ddfd7678  pop rdi
00007981ddfd7679  pop rdx
00007981ddfd767a  pop rcx
00007981ddfd767b  pop rax
00007981ddfd767c  add rsp, 0x08
00007981ddfd7680  jmp 0x00007981DDFD3332
00007981ddfd7685  sub rsp, 0x08
00007981ddfd7689  push rax
00007981ddfd768a  push rcx
00007981ddfd768b  push rdx
00007981ddfd768c  push rdi
00007981ddfd768d  push rsi
00007981ddfd768e  push r8
00007981ddfd7690  push r9
00007981ddfd7692  push r10
00007981ddfd7694  push r11
00007981ddfd7696  sub rsp, 0xF0
00007981ddfd769d  vmovaps [rsp], xmm0
00007981ddfd76a2  vmovaps [rsp+0x10], xmm1
00007981ddfd76a8  vmovaps [rsp+0x20], xmm2
00007981ddfd76ae  vmovaps [rsp+0x30], xmm3
00007981ddfd76b4  vmovaps [rsp+0x40], xmm4
00007981ddfd76ba  vmovaps [rsp+0x50], xmm5
00007981ddfd76c0  vmovaps [rsp+0x60], xmm6
00007981ddfd76c6  vmovaps [rsp+0x70], xmm7
00007981ddfd76cc  vmovaps [rsp+0x80], xmm8
00007981ddfd76d5  vmovaps [rsp+0x90], xmm9
00007981ddfd76de  vmovaps [rsp+0xA0], xmm10
00007981ddfd76e7  vmovaps [rsp+0xB0], xmm12
00007981ddfd76f0  vmovaps [rsp+0xC0], xmm13
00007981ddfd76f9  vmovaps [rsp+0xD0], xmm14
00007981ddfd7702  vmovaps [rsp+0xE0], xmm15
00007981ddfd770b  sub rsp, 0x30
00007981ddfd770f  movaps [rsp], xmm11
00007981ddfd7714  movaps [rsp+0x10], xmm7
00007981ddfd7719  movaps [rsp+0x20], xmm13
00007981ddfd771f  lea rdi, [rsp]
00007981ddfd7723  mov esi, 0x00
00007981ddfd7728  mov rax, 0x5782A6EB3530
00007981ddfd7732  call rax
00007981ddfd7734  movaps xmm11, [rsp]
00007981ddfd7739  add rsp, 0x30
00007981ddfd773d  vmovaps xmm0, [rsp]
00007981ddfd7742  vmovaps xmm1, [rsp+0x10]
00007981ddfd7748  vmovaps xmm2, [rsp+0x20]
00007981ddfd774e  vmovaps xmm3, [rsp+0x30]
00007981ddfd7754  vmovaps xmm4, [rsp+0x40]
00007981ddfd775a  vmovaps xmm5, [rsp+0x50]
00007981ddfd7760  vmovaps xmm6, [rsp+0x60]
00007981ddfd7766  vmovaps xmm7, [rsp+0x70]
00007981ddfd776c  vmovaps xmm8, [rsp+0x80]
00007981ddfd7775  vmovaps xmm9, [rsp+0x90]
00007981ddfd777e  vmovaps xmm10, [rsp+0xA0]
00007981ddfd7787  vmovaps xmm12, [rsp+0xB0]
00007981ddfd7790  vmovaps xmm13, [rsp+0xC0]
00007981ddfd7799  vmovaps xmm14, [rsp+0xD0]
00007981ddfd77a2  vmovaps xmm15, [rsp+0xE0]
00007981ddfd77ab  add rsp, 0xF0
00007981ddfd77b2  pop r11
00007981ddfd77b4  pop r10
00007981ddfd77b6  pop r9
00007981ddfd77b8  pop r8
00007981ddfd77ba  pop rsi
00007981ddfd77bb  pop rdi
00007981ddfd77bc  pop rdx
00007981ddfd77bd  pop rcx
00007981ddfd77be  pop rax
00007981ddfd77bf  add rsp, 0x08
00007981ddfd77c3  jmp 0x00007981DDFD335E
00007981ddfd77c8  sub rsp, 0x08
00007981ddfd77cc  push rax
00007981ddfd77cd  push rcx
00007981ddfd77ce  push rdx
00007981ddfd77cf  push rdi
00007981ddfd77d0  push rsi
00007981ddfd77d1  push r8
00007981ddfd77d3  push r9
00007981ddfd77d5  push r10
00007981ddfd77d7  push r11
00007981ddfd77d9  sub rsp, 0xF0
00007981ddfd77e0  vmovaps [rsp], xmm0
00007981ddfd77e5  vmovaps [rsp+0x10], xmm1
00007981ddfd77eb  vmovaps [rsp+0x20], xmm2
00007981ddfd77f1  vmovaps [rsp+0x30], xmm3
00007981ddfd77f7  vmovaps [rsp+0x40], xmm4
00007981ddfd77fd  vmovaps [rsp+0x50], xmm5
00007981ddfd7803  vmovaps [rsp+0x60], xmm6
00007981ddfd7809  vmovaps [rsp+0x70], xmm7
00007981ddfd780f  vmovaps [rsp+0x80], xmm8
00007981ddfd7818  vmovaps [rsp+0x90], xmm9
00007981ddfd7821  vmovaps [rsp+0xA0], xmm10
00007981ddfd782a  vmovaps [rsp+0xB0], xmm11
00007981ddfd7833  vmovaps [rsp+0xC0], xmm12
00007981ddfd783c  vmovaps [rsp+0xD0], xmm14
00007981ddfd7845  vmovaps [rsp+0xE0], xmm15
00007981ddfd784e  sub rsp, 0x30
00007981ddfd7852  movaps [rsp], xmm13
00007981ddfd7857  movaps [rsp+0x10], xmm10
00007981ddfd785d  movaps [rsp+0x20], xmm12
00007981ddfd7863  lea rdi, [rsp]
00007981ddfd7867  mov esi, 0x00
00007981ddfd786c  mov rax, 0x5782A6EB3530
00007981ddfd7876  call rax
00007981ddfd7878  movaps xmm13, [rsp]
00007981ddfd787d  add rsp, 0x30
00007981ddfd7881  vmovaps xmm0, [rsp]
00007981ddfd7886  vmovaps xmm1, [rsp+0x10]
00007981ddfd788c  vmovaps xmm2, [rsp+0x20]
00007981ddfd7892  vmovaps xmm3, [rsp+0x30]
00007981ddfd7898  vmovaps xmm4, [rsp+0x40]
00007981ddfd789e  vmovaps xmm5, [rsp+0x50]
00007981ddfd78a4  vmovaps xmm6, [rsp+0x60]
00007981ddfd78aa  vmovaps xmm7, [rsp+0x70]
00007981ddfd78b0  vmovaps xmm8, [rsp+0x80]
00007981ddfd78b9  vmovaps xmm9, [rsp+0x90]
00007981ddfd78c2  vmovaps xmm10, [rsp+0xA0]
00007981ddfd78cb  vmovaps xmm11, [rsp+0xB0]
00007981ddfd78d4  vmovaps xmm12, [rsp+0xC0]
00007981ddfd78dd  vmovaps xmm14, [rsp+0xD0]
00007981ddfd78e6  vmovaps xmm15, [rsp+0xE0]
00007981ddfd78ef  add rsp, 0xF0
00007981ddfd78f6  pop r11
00007981ddfd78f8  pop r10
00007981ddfd78fa  pop r9
00007981ddfd78fc  pop r8
00007981ddfd78fe  pop rsi
00007981ddfd78ff  pop rdi
00007981ddfd7900  pop rdx
00007981ddfd7901  pop rcx
00007981ddfd7902  pop rax
00007981ddfd7903  add rsp, 0x08
00007981ddfd7907  jmp 0x00007981DDFD3378
00007981ddfd790c  sub rsp, 0x08
00007981ddfd7910  push rax
00007981ddfd7911  push rcx
00007981ddfd7912  push rdx
00007981ddfd7913  push rdi
00007981ddfd7914  push rsi
00007981ddfd7915  push r8
00007981ddfd7917  push r9
00007981ddfd7919  push r10
00007981ddfd791b  push r11
00007981ddfd791d  sub rsp, 0xF0
00007981ddfd7924  vmovaps [rsp], xmm0
00007981ddfd7929  vmovaps [rsp+0x10], xmm1
00007981ddfd792f  vmovaps [rsp+0x20], xmm2
00007981ddfd7935  vmovaps [rsp+0x30], xmm3
00007981ddfd793b  vmovaps [rsp+0x40], xmm4
00007981ddfd7941  vmovaps [rsp+0x50], xmm5
00007981ddfd7947  vmovaps [rsp+0x60], xmm6
00007981ddfd794d  vmovaps [rsp+0x70], xmm7
00007981ddfd7953  vmovaps [rsp+0x80], xmm8
00007981ddfd795c  vmovaps [rsp+0x90], xmm9
00007981ddfd7965  vmovaps [rsp+0xA0], xmm11
00007981ddfd796e  vmovaps [rsp+0xB0], xmm12
00007981ddfd7977  vmovaps [rsp+0xC0], xmm13
00007981ddfd7980  vmovaps [rsp+0xD0], xmm14
00007981ddfd7989  vmovaps [rsp+0xE0], xmm15
00007981ddfd7992  sub rsp, 0x30
00007981ddfd7996  movaps [rsp], xmm10
00007981ddfd799b  movaps [rsp+0x10], xmm7
00007981ddfd79a0  movaps [rsp+0x20], xmm12
00007981ddfd79a6  lea rdi, [rsp]
00007981ddfd79aa  mov esi, 0x00
00007981ddfd79af  mov rax, 0x5782A6EB3530
00007981ddfd79b9  call rax
00007981ddfd79bb  movaps xmm10, [rsp]
00007981ddfd79c0  add rsp, 0x30
00007981ddfd79c4  vmovaps xmm0, [rsp]
00007981ddfd79c9  vmovaps xmm1, [rsp+0x10]
00007981ddfd79cf  vmovaps xmm2, [rsp+0x20]
00007981ddfd79d5  vmovaps xmm3, [rsp+0x30]
00007981ddfd79db  vmovaps xmm4, [rsp+0x40]
00007981ddfd79e1  vmovaps xmm5, [rsp+0x50]
00007981ddfd79e7  vmovaps xmm6, [rsp+0x60]
00007981ddfd79ed  vmovaps xmm7, [rsp+0x70]
00007981ddfd79f3  vmovaps xmm8, [rsp+0x80]
00007981ddfd79fc  vmovaps xmm9, [rsp+0x90]
00007981ddfd7a05  vmovaps xmm11, [rsp+0xA0]
00007981ddfd7a0e  vmovaps xmm12, [rsp+0xB0]
00007981ddfd7a17  vmovaps xmm13, [rsp+0xC0]
00007981ddfd7a20  vmovaps xmm14, [rsp+0xD0]
00007981ddfd7a29  vmovaps xmm15, [rsp+0xE0]
00007981ddfd7a32  add rsp, 0xF0
00007981ddfd7a39  pop r11
00007981ddfd7a3b  pop r10
00007981ddfd7a3d  pop r9
00007981ddfd7a3f  pop r8
00007981ddfd7a41  pop rsi
00007981ddfd7a42  pop rdi
00007981ddfd7a43  pop rdx
00007981ddfd7a44  pop rcx
00007981ddfd7a45  pop rax
00007981ddfd7a46  add rsp, 0x08
00007981ddfd7a4a  jmp 0x00007981DDFD33A4
00007981ddfd7a4f  sub rsp, 0x08
00007981ddfd7a53  push rax
00007981ddfd7a54  push rcx
00007981ddfd7a55  push rdx
00007981ddfd7a56  push rdi
00007981ddfd7a57  push rsi
00007981ddfd7a58  push r8
00007981ddfd7a5a  push r9
00007981ddfd7a5c  push r10
00007981ddfd7a5e  push r11
00007981ddfd7a60  sub rsp, 0xF0
00007981ddfd7a67  vmovaps [rsp], xmm0
00007981ddfd7a6c  vmovaps [rsp+0x10], xmm1
00007981ddfd7a72  vmovaps [rsp+0x20], xmm2
00007981ddfd7a78  vmovaps [rsp+0x30], xmm3
00007981ddfd7a7e  vmovaps [rsp+0x40], xmm4
00007981ddfd7a84  vmovaps [rsp+0x50], xmm5
00007981ddfd7a8a  vmovaps [rsp+0x60], xmm6
00007981ddfd7a90  vmovaps [rsp+0x70], xmm7
00007981ddfd7a96  vmovaps [rsp+0x80], xmm8
00007981ddfd7a9f  vmovaps [rsp+0x90], xmm9
00007981ddfd7aa8  vmovaps [rsp+0xA0], xmm10
00007981ddfd7ab1  vmovaps [rsp+0xB0], xmm11
00007981ddfd7aba  vmovaps [rsp+0xC0], xmm13
00007981ddfd7ac3  vmovaps [rsp+0xD0], xmm14
00007981ddfd7acc  vmovaps [rsp+0xE0], xmm15
00007981ddfd7ad5  sub rsp, 0x30
00007981ddfd7ad9  movaps [rsp], xmm12
00007981ddfd7ade  movaps [rsp+0x10], xmm1
00007981ddfd7ae3  movaps [rsp+0x20], xmm8
00007981ddfd7ae9  lea rdi, [rsp]
00007981ddfd7aed  mov esi, 0x00
00007981ddfd7af2  mov rax, 0x5782A6EB3530
00007981ddfd7afc  call rax
00007981ddfd7afe  movaps xmm12, [rsp]
00007981ddfd7b03  add rsp, 0x30
00007981ddfd7b07  vmovaps xmm0, [rsp]
00007981ddfd7b0c  vmovaps xmm1, [rsp+0x10]
00007981ddfd7b12  vmovaps xmm2, [rsp+0x20]
00007981ddfd7b18  vmovaps xmm3, [rsp+0x30]
00007981ddfd7b1e  vmovaps xmm4, [rsp+0x40]
00007981ddfd7b24  vmovaps xmm5, [rsp+0x50]
00007981ddfd7b2a  vmovaps xmm6, [rsp+0x60]
00007981ddfd7b30  vmovaps xmm7, [rsp+0x70]
00007981ddfd7b36  vmovaps xmm8, [rsp+0x80]
00007981ddfd7b3f  vmovaps xmm9, [rsp+0x90]
00007981ddfd7b48  vmovaps xmm10, [rsp+0xA0]
00007981ddfd7b51  vmovaps xmm11, [rsp+0xB0]
00007981ddfd7b5a  vmovaps xmm13, [rsp+0xC0]
00007981ddfd7b63  vmovaps xmm14, [rsp+0xD0]
00007981ddfd7b6c  vmovaps xmm15, [rsp+0xE0]
00007981ddfd7b75  add rsp, 0xF0
00007981ddfd7b7c  pop r11
00007981ddfd7b7e  pop r10
00007981ddfd7b80  pop r9
00007981ddfd7b82  pop r8
00007981ddfd7b84  pop rsi
00007981ddfd7b85  pop rdi
00007981ddfd7b86  pop rdx
00007981ddfd7b87  pop rcx
00007981ddfd7b88  pop rax
00007981ddfd7b89  add rsp, 0x08
00007981ddfd7b8d  jmp 0x00007981DDFD33BE
00007981ddfd7b92  call 0x00007981DDDFF430
00007981ddfd7b97  jmp 0x00007981DDFD33C8
00007981ddfd7b9c  sub rsp, 0x08
00007981ddfd7ba0  push rax
00007981ddfd7ba1  push rcx
00007981ddfd7ba2  push rdx
00007981ddfd7ba3  push rdi
00007981ddfd7ba4  push rsi
00007981ddfd7ba5  push r8
00007981ddfd7ba7  push r9
00007981ddfd7ba9  push r10
00007981ddfd7bab  push r11
00007981ddfd7bad  sub rsp, 0xF0
00007981ddfd7bb4  vmovaps [rsp], xmm0
00007981ddfd7bb9  vmovaps [rsp+0x10], xmm1
00007981ddfd7bbf  vmovaps [rsp+0x20], xmm2
00007981ddfd7bc5  vmovaps [rsp+0x30], xmm3
00007981ddfd7bcb  vmovaps [rsp+0x40], xmm4
00007981ddfd7bd1  vmovaps [rsp+0x50], xmm5
00007981ddfd7bd7  vmovaps [rsp+0x60], xmm6
00007981ddfd7bdd  vmovaps [rsp+0x70], xmm7
00007981ddfd7be3  vmovaps [rsp+0x80], xmm9
00007981ddfd7bec  vmovaps [rsp+0x90], xmm10
00007981ddfd7bf5  vmovaps [rsp+0xA0], xmm11
00007981ddfd7bfe  vmovaps [rsp+0xB0], xmm12
00007981ddfd7c07  vmovaps [rsp+0xC0], xmm13
00007981ddfd7c10  vmovaps [rsp+0xD0], xmm14
00007981ddfd7c19  vmovaps [rsp+0xE0], xmm15
00007981ddfd7c22  sub rsp, 0x30
00007981ddfd7c26  movaps [rsp], xmm8
00007981ddfd7c2b  movaps [rsp+0x10], xmm15
00007981ddfd7c31  movaps [rsp+0x20], xmm9
00007981ddfd7c37  lea rdi, [rsp]
00007981ddfd7c3b  mov esi, 0x00
00007981ddfd7c40  mov rax, 0x5782A6EB3530
00007981ddfd7c4a  call rax
00007981ddfd7c4c  movaps xmm8, [rsp]
00007981ddfd7c51  add rsp, 0x30
00007981ddfd7c55  vmovaps xmm0, [rsp]
00007981ddfd7c5a  vmovaps xmm1, [rsp+0x10]
00007981ddfd7c60  vmovaps xmm2, [rsp+0x20]
00007981ddfd7c66  vmovaps xmm3, [rsp+0x30]
00007981ddfd7c6c  vmovaps xmm4, [rsp+0x40]
00007981ddfd7c72  vmovaps xmm5, [rsp+0x50]
00007981ddfd7c78  vmovaps xmm6, [rsp+0x60]
00007981ddfd7c7e  vmovaps xmm7, [rsp+0x70]
00007981ddfd7c84  vmovaps xmm9, [rsp+0x80]
00007981ddfd7c8d  vmovaps xmm10, [rsp+0x90]
00007981ddfd7c96  vmovaps xmm11, [rsp+0xA0]
00007981ddfd7c9f  vmovaps xmm12, [rsp+0xB0]
00007981ddfd7ca8  vmovaps xmm13, [rsp+0xC0]
00007981ddfd7cb1  vmovaps xmm14, [rsp+0xD0]
00007981ddfd7cba  vmovaps xmm15, [rsp+0xE0]
00007981ddfd7cc3  add rsp, 0xF0
00007981ddfd7cca  pop r11
00007981ddfd7ccc  pop r10
00007981ddfd7cce  pop r9
00007981ddfd7cd0  pop r8
00007981ddfd7cd2  pop rsi
00007981ddfd7cd3  pop rdi
00007981ddfd7cd4  pop rdx
00007981ddfd7cd5  pop rcx
00007981ddfd7cd6  pop rax
00007981ddfd7cd7  add rsp, 0x08
00007981ddfd7cdb  jmp 0x00007981DDFD33EA
00007981ddfd7ce0  sub rsp, 0x08
00007981ddfd7ce4  push rax
00007981ddfd7ce5  push rcx
00007981ddfd7ce6  push rdx
00007981ddfd7ce7  push rdi
00007981ddfd7ce8  push rsi
00007981ddfd7ce9  push r8
00007981ddfd7ceb  push r9
00007981ddfd7ced  push r10
00007981ddfd7cef  push r11
00007981ddfd7cf1  sub rsp, 0xF0
00007981ddfd7cf8  vmovaps [rsp], xmm0
00007981ddfd7cfd  vmovaps [rsp+0x10], xmm1
00007981ddfd7d03  vmovaps [rsp+0x20], xmm2
00007981ddfd7d09  vmovaps [rsp+0x30], xmm3
00007981ddfd7d0f  vmovaps [rsp+0x40], xmm4
00007981ddfd7d15  vmovaps [rsp+0x50], xmm5
00007981ddfd7d1b  vmovaps [rsp+0x60], xmm6
00007981ddfd7d21  vmovaps [rsp+0x70], xmm7
00007981ddfd7d27  vmovaps [rsp+0x80], xmm8
00007981ddfd7d30  vmovaps [rsp+0x90], xmm10
00007981ddfd7d39  vmovaps [rsp+0xA0], xmm11
00007981ddfd7d42  vmovaps [rsp+0xB0], xmm12
00007981ddfd7d4b  vmovaps [rsp+0xC0], xmm13
00007981ddfd7d54  vmovaps [rsp+0xD0], xmm14
00007981ddfd7d5d  vmovaps [rsp+0xE0], xmm15
00007981ddfd7d66  sub rsp, 0x30
00007981ddfd7d6a  movaps [rsp], xmm9
00007981ddfd7d6f  movaps [rsp+0x10], xmm1
00007981ddfd7d74  movaps [rsp+0x20], xmm15
00007981ddfd7d7a  lea rdi, [rsp]
00007981ddfd7d7e  mov esi, 0x00
00007981ddfd7d83  mov rax, 0x5782A6EB3530
00007981ddfd7d8d  call rax
00007981ddfd7d8f  movaps xmm9, [rsp]
00007981ddfd7d94  add rsp, 0x30
00007981ddfd7d98  vmovaps xmm0, [rsp]
00007981ddfd7d9d  vmovaps xmm1, [rsp+0x10]
00007981ddfd7da3  vmovaps xmm2, [rsp+0x20]
00007981ddfd7da9  vmovaps xmm3, [rsp+0x30]
00007981ddfd7daf  vmovaps xmm4, [rsp+0x40]
00007981ddfd7db5  vmovaps xmm5, [rsp+0x50]
00007981ddfd7dbb  vmovaps xmm6, [rsp+0x60]
00007981ddfd7dc1  vmovaps xmm7, [rsp+0x70]
00007981ddfd7dc7  vmovaps xmm8, [rsp+0x80]
00007981ddfd7dd0  vmovaps xmm10, [rsp+0x90]
00007981ddfd7dd9  vmovaps xmm11, [rsp+0xA0]
00007981ddfd7de2  vmovaps xmm12, [rsp+0xB0]
00007981ddfd7deb  vmovaps xmm13, [rsp+0xC0]
00007981ddfd7df4  vmovaps xmm14, [rsp+0xD0]
00007981ddfd7dfd  vmovaps xmm15, [rsp+0xE0]
00007981ddfd7e06  add rsp, 0xF0
00007981ddfd7e0d  pop r11
00007981ddfd7e0f  pop r10
00007981ddfd7e11  pop r9
00007981ddfd7e13  pop r8
00007981ddfd7e15  pop rsi
00007981ddfd7e16  pop rdi
00007981ddfd7e17  pop rdx
00007981ddfd7e18  pop rcx
00007981ddfd7e19  pop rax
00007981ddfd7e1a  add rsp, 0x08
00007981ddfd7e1e  jmp 0x00007981DDFD3418
00007981ddfd7e23  sub rsp, 0x08
00007981ddfd7e27  push rax
00007981ddfd7e28  push rcx
00007981ddfd7e29  push rdx
00007981ddfd7e2a  push rdi
00007981ddfd7e2b  push rsi
00007981ddfd7e2c  push r8
00007981ddfd7e2e  push r9
00007981ddfd7e30  push r10
00007981ddfd7e32  push r11
00007981ddfd7e34  sub rsp, 0xF0
00007981ddfd7e3b  vmovaps [rsp], xmm0
00007981ddfd7e40  vmovaps [rsp+0x10], xmm1
00007981ddfd7e46  vmovaps [rsp+0x20], xmm2
00007981ddfd7e4c  vmovaps [rsp+0x30], xmm3
00007981ddfd7e52  vmovaps [rsp+0x40], xmm4
00007981ddfd7e58  vmovaps [rsp+0x50], xmm5
00007981ddfd7e5e  vmovaps [rsp+0x60], xmm6
00007981ddfd7e64  vmovaps [rsp+0x70], xmm7
00007981ddfd7e6a  vmovaps [rsp+0x80], xmm8
00007981ddfd7e73  vmovaps [rsp+0x90], xmm9
00007981ddfd7e7c  vmovaps [rsp+0xA0], xmm10
00007981ddfd7e85  vmovaps [rsp+0xB0], xmm11
00007981ddfd7e8e  vmovaps [rsp+0xC0], xmm12
00007981ddfd7e97  vmovaps [rsp+0xD0], xmm13
00007981ddfd7ea0  vmovaps [rsp+0xE0], xmm14
00007981ddfd7ea9  sub rsp, 0x30
00007981ddfd7ead  movaps [rsp], xmm15
00007981ddfd7eb2  movaps [rsp+0x10], xmm4
00007981ddfd7eb7  movaps [rsp+0x20], xmm1
00007981ddfd7ebc  lea rdi, [rsp]
00007981ddfd7ec0  mov esi, 0x00
00007981ddfd7ec5  mov rax, 0x5782A6EB3530
00007981ddfd7ecf  call rax
00007981ddfd7ed1  movaps xmm15, [rsp]
00007981ddfd7ed6  add rsp, 0x30
00007981ddfd7eda  vmovaps xmm0, [rsp]
00007981ddfd7edf  vmovaps xmm1, [rsp+0x10]
00007981ddfd7ee5  vmovaps xmm2, [rsp+0x20]
00007981ddfd7eeb  vmovaps xmm3, [rsp+0x30]
00007981ddfd7ef1  vmovaps xmm4, [rsp+0x40]
00007981ddfd7ef7  vmovaps xmm5, [rsp+0x50]
00007981ddfd7efd  vmovaps xmm6, [rsp+0x60]
00007981ddfd7f03  vmovaps xmm7, [rsp+0x70]
00007981ddfd7f09  vmovaps xmm8, [rsp+0x80]
00007981ddfd7f12  vmovaps xmm9, [rsp+0x90]
00007981ddfd7f1b  vmovaps xmm10, [rsp+0xA0]
00007981ddfd7f24  vmovaps xmm11, [rsp+0xB0]
00007981ddfd7f2d  vmovaps xmm12, [rsp+0xC0]
00007981ddfd7f36  vmovaps xmm13, [rsp+0xD0]
00007981ddfd7f3f  vmovaps xmm14, [rsp+0xE0]
00007981ddfd7f48  add rsp, 0xF0
00007981ddfd7f4f  pop r11
00007981ddfd7f51  pop r10
00007981ddfd7f53  pop r9
00007981ddfd7f55  pop r8
00007981ddfd7f57  pop rsi
00007981ddfd7f58  pop rdi
00007981ddfd7f59  pop rdx
00007981ddfd7f5a  pop rcx
00007981ddfd7f5b  pop rax
00007981ddfd7f5c  add rsp, 0x08
00007981ddfd7f60  jmp 0x00007981DDFD343E
00007981ddfd7f65  sub rsp, 0x08
00007981ddfd7f69  push rax
00007981ddfd7f6a  push rcx
00007981ddfd7f6b  push rdx
00007981ddfd7f6c  push rdi
00007981ddfd7f6d  push rsi
00007981ddfd7f6e  push r8
00007981ddfd7f70  push r9
00007981ddfd7f72  push r10
00007981ddfd7f74  push r11
00007981ddfd7f76  sub rsp, 0xF0
00007981ddfd7f7d  vmovaps [rsp], xmm0
00007981ddfd7f82  vmovaps [rsp+0x10], xmm2
00007981ddfd7f88  vmovaps [rsp+0x20], xmm3
00007981ddfd7f8e  vmovaps [rsp+0x30], xmm4
00007981ddfd7f94  vmovaps [rsp+0x40], xmm5
00007981ddfd7f9a  vmovaps [rsp+0x50], xmm6
00007981ddfd7fa0  vmovaps [rsp+0x60], xmm7
00007981ddfd7fa6  vmovaps [rsp+0x70], xmm8
00007981ddfd7fac  vmovaps [rsp+0x80], xmm9
00007981ddfd7fb5  vmovaps [rsp+0x90], xmm10
00007981ddfd7fbe  vmovaps [rsp+0xA0], xmm11
00007981ddfd7fc7  vmovaps [rsp+0xB0], xmm12
00007981ddfd7fd0  vmovaps [rsp+0xC0], xmm13
00007981ddfd7fd9  vmovaps [rsp+0xD0], xmm14
00007981ddfd7fe2  vmovaps [rsp+0xE0], xmm15
00007981ddfd7feb  sub rsp, 0x30
00007981ddfd7fef  movaps [rsp], xmm1
00007981ddfd7ff3  movaps [rsp+0x10], xmm14
00007981ddfd7ff9  movaps [rsp+0x20], xmm11
00007981ddfd7fff  lea rdi, [rsp]
00007981ddfd8003  mov esi, 0x00
00007981ddfd8008  mov rax, 0x5782A6EB3530
00007981ddfd8012  call rax
00007981ddfd8014  movaps xmm1, [rsp]
00007981ddfd8018  add rsp, 0x30
00007981ddfd801c  vmovaps xmm0, [rsp]
00007981ddfd8021  vmovaps xmm2, [rsp+0x10]
00007981ddfd8027  vmovaps xmm3, [rsp+0x20]
00007981ddfd802d  vmovaps xmm4, [rsp+0x30]
00007981ddfd8033  vmovaps xmm5, [rsp+0x40]
00007981ddfd8039  vmovaps xmm6, [rsp+0x50]
00007981ddfd803f  vmovaps xmm7, [rsp+0x60]
00007981ddfd8045  vmovaps xmm8, [rsp+0x70]
00007981ddfd804b  vmovaps xmm9, [rsp+0x80]
00007981ddfd8054  vmovaps xmm10, [rsp+0x90]
00007981ddfd805d  vmovaps xmm11, [rsp+0xA0]
00007981ddfd8066  vmovaps xmm12, [rsp+0xB0]
00007981ddfd806f  vmovaps xmm13, [rsp+0xC0]
00007981ddfd8078  vmovaps xmm14, [rsp+0xD0]
00007981ddfd8081  vmovaps xmm15, [rsp+0xE0]
00007981ddfd808a  add rsp, 0xF0
00007981ddfd8091  pop r11
00007981ddfd8093  pop r10
00007981ddfd8095  pop r9
00007981ddfd8097  pop r8
00007981ddfd8099  pop rsi
00007981ddfd809a  pop rdi
00007981ddfd809b  pop rdx
00007981ddfd809c  pop rcx
00007981ddfd809d  pop rax
00007981ddfd809e  add rsp, 0x08
00007981ddfd80a2  jmp 0x00007981DDFD345F
00007981ddfd80a7  call 0x00007981DDEE45A0
00007981ddfd80ac  jmp 0x00007981DDFD346D
00007981ddfd80b1  call 0x00007981DDE09D70
00007981ddfd80b6  jmp 0x00007981DDFD3477
00007981ddfd80bb  sub rsp, 0x08
00007981ddfd80bf  push rax
00007981ddfd80c0  push rcx
00007981ddfd80c1  push rdx
00007981ddfd80c2  push rdi
00007981ddfd80c3  push rsi
00007981ddfd80c4  push r8
00007981ddfd80c6  push r9
00007981ddfd80c8  push r10
00007981ddfd80ca  push r11
00007981ddfd80cc  sub rsp, 0xF0
00007981ddfd80d3  vmovaps [rsp], xmm0
00007981ddfd80d8  vmovaps [rsp+0x10], xmm1
00007981ddfd80de  vmovaps [rsp+0x20], xmm2
00007981ddfd80e4  vmovaps [rsp+0x30], xmm3
00007981ddfd80ea  vmovaps [rsp+0x40], xmm4
00007981ddfd80f0  vmovaps [rsp+0x50], xmm5
00007981ddfd80f6  vmovaps [rsp+0x60], xmm6
00007981ddfd80fc  vmovaps [rsp+0x70], xmm8
00007981ddfd8102  vmovaps [rsp+0x80], xmm9
00007981ddfd810b  vmovaps [rsp+0x90], xmm10
00007981ddfd8114  vmovaps [rsp+0xA0], xmm11
00007981ddfd811d  vmovaps [rsp+0xB0], xmm12
00007981ddfd8126  vmovaps [rsp+0xC0], xmm13
00007981ddfd812f  vmovaps [rsp+0xD0], xmm14
00007981ddfd8138  vmovaps [rsp+0xE0], xmm15
00007981ddfd8141  sub rsp, 0x30
00007981ddfd8145  movaps [rsp], xmm7
00007981ddfd8149  movaps [rsp+0x10], xmm13
00007981ddfd814f  movaps [rsp+0x20], xmm10
00007981ddfd8155  lea rdi, [rsp]
00007981ddfd8159  mov esi, 0x00
00007981ddfd815e  mov rax, 0x5782A6EB3530
00007981ddfd8168  call rax
00007981ddfd816a  movaps xmm7, [rsp]
00007981ddfd816e  add rsp, 0x30
00007981ddfd8172  vmovaps xmm0, [rsp]
00007981ddfd8177  vmovaps xmm1, [rsp+0x10]
00007981ddfd817d  vmovaps xmm2, [rsp+0x20]
00007981ddfd8183  vmovaps xmm3, [rsp+0x30]
00007981ddfd8189  vmovaps xmm4, [rsp+0x40]
00007981ddfd818f  vmovaps xmm5, [rsp+0x50]
00007981ddfd8195  vmovaps xmm6, [rsp+0x60]
00007981ddfd819b  vmovaps xmm8, [rsp+0x70]
00007981ddfd81a1  vmovaps xmm9, [rsp+0x80]
00007981ddfd81aa  vmovaps xmm10, [rsp+0x90]
00007981ddfd81b3  vmovaps xmm11, [rsp+0xA0]
00007981ddfd81bc  vmovaps xmm12, [rsp+0xB0]
00007981ddfd81c5  vmovaps xmm13, [rsp+0xC0]
00007981ddfd81ce  vmovaps xmm14, [rsp+0xD0]
00007981ddfd81d7  vmovaps xmm15, [rsp+0xE0]
00007981ddfd81e0  add rsp, 0xF0
00007981ddfd81e7  pop r11
00007981ddfd81e9  pop r10
00007981ddfd81eb  pop r9
00007981ddfd81ed  pop r8
00007981ddfd81ef  pop rsi
00007981ddfd81f0  pop rdi
00007981ddfd81f1  pop rdx
00007981ddfd81f2  pop rcx
00007981ddfd81f3  pop rax
00007981ddfd81f4  add rsp, 0x08
00007981ddfd81f8  jmp 0x00007981DDFD3498
00007981ddfd81fd  sub rsp, 0x08
00007981ddfd8201  push rax
00007981ddfd8202  push rcx
00007981ddfd8203  push rdx
00007981ddfd8204  push rdi
00007981ddfd8205  push rsi
00007981ddfd8206  push r8
00007981ddfd8208  push r9
00007981ddfd820a  push r10
00007981ddfd820c  push r11
00007981ddfd820e  sub rsp, 0xF0
00007981ddfd8215  vmovaps [rsp], xmm0
00007981ddfd821a  vmovaps [rsp+0x10], xmm1
00007981ddfd8220  vmovaps [rsp+0x20], xmm2
00007981ddfd8226  vmovaps [rsp+0x30], xmm3
00007981ddfd822c  vmovaps [rsp+0x40], xmm4
00007981ddfd8232  vmovaps [rsp+0x50], xmm5
00007981ddfd8238  vmovaps [rsp+0x60], xmm6
00007981ddfd823e  vmovaps [rsp+0x70], xmm7
00007981ddfd8244  vmovaps [rsp+0x80], xmm8
00007981ddfd824d  vmovaps [rsp+0x90], xmm9
00007981ddfd8256  vmovaps [rsp+0xA0], xmm11
00007981ddfd825f  vmovaps [rsp+0xB0], xmm12
00007981ddfd8268  vmovaps [rsp+0xC0], xmm13
00007981ddfd8271  vmovaps [rsp+0xD0], xmm14
00007981ddfd827a  vmovaps [rsp+0xE0], xmm15
00007981ddfd8283  sub rsp, 0x30
00007981ddfd8287  movaps [rsp], xmm10
00007981ddfd828c  movaps [rsp+0x10], xmm11
00007981ddfd8292  movaps [rsp+0x20], xmm13
00007981ddfd8298  lea rdi, [rsp]
00007981ddfd829c  mov esi, 0x00
00007981ddfd82a1  mov rax, 0x5782A6EB3530
00007981ddfd82ab  call rax
00007981ddfd82ad  movaps xmm10, [rsp]
00007981ddfd82b2  add rsp, 0x30
00007981ddfd82b6  vmovaps xmm0, [rsp]
00007981ddfd82bb  vmovaps xmm1, [rsp+0x10]
00007981ddfd82c1  vmovaps xmm2, [rsp+0x20]
00007981ddfd82c7  vmovaps xmm3, [rsp+0x30]
00007981ddfd82cd  vmovaps xmm4, [rsp+0x40]
00007981ddfd82d3  vmovaps xmm5, [rsp+0x50]
00007981ddfd82d9  vmovaps xmm6, [rsp+0x60]
00007981ddfd82df  vmovaps xmm7, [rsp+0x70]
00007981ddfd82e5  vmovaps xmm8, [rsp+0x80]
00007981ddfd82ee  vmovaps xmm9, [rsp+0x90]
00007981ddfd82f7  vmovaps xmm11, [rsp+0xA0]
00007981ddfd8300  vmovaps xmm12, [rsp+0xB0]
00007981ddfd8309  vmovaps xmm13, [rsp+0xC0]
00007981ddfd8312  vmovaps xmm14, [rsp+0xD0]
00007981ddfd831b  vmovaps xmm15, [rsp+0xE0]
00007981ddfd8324  add rsp, 0xF0
00007981ddfd832b  pop r11
00007981ddfd832d  pop r10
00007981ddfd832f  pop r9
00007981ddfd8331  pop r8
00007981ddfd8333  pop rsi
00007981ddfd8334  pop rdi
00007981ddfd8335  pop rdx
00007981ddfd8336  pop rcx
00007981ddfd8337  pop rax
00007981ddfd8338  add rsp, 0x08
00007981ddfd833c  jmp 0x00007981DDFD34C6
00007981ddfd8341  sub rsp, 0x08
00007981ddfd8345  push rax
00007981ddfd8346  push rcx
00007981ddfd8347  push rdx
00007981ddfd8348  push rdi
00007981ddfd8349  push rsi
00007981ddfd834a  push r8
00007981ddfd834c  push r9
00007981ddfd834e  push r10
00007981ddfd8350  push r11
00007981ddfd8352  sub rsp, 0xF0
00007981ddfd8359  vmovaps [rsp], xmm0
00007981ddfd835e  vmovaps [rsp+0x10], xmm1
00007981ddfd8364  vmovaps [rsp+0x20], xmm2
00007981ddfd836a  vmovaps [rsp+0x30], xmm3
00007981ddfd8370  vmovaps [rsp+0x40], xmm4
00007981ddfd8376  vmovaps [rsp+0x50], xmm5
00007981ddfd837c  vmovaps [rsp+0x60], xmm6
00007981ddfd8382  vmovaps [rsp+0x70], xmm7
00007981ddfd8388  vmovaps [rsp+0x80], xmm8
00007981ddfd8391  vmovaps [rsp+0x90], xmm9
00007981ddfd839a  vmovaps [rsp+0xA0], xmm10
00007981ddfd83a3  vmovaps [rsp+0xB0], xmm12
00007981ddfd83ac  vmovaps [rsp+0xC0], xmm13
00007981ddfd83b5  vmovaps [rsp+0xD0], xmm14
00007981ddfd83be  vmovaps [rsp+0xE0], xmm15
00007981ddfd83c7  sub rsp, 0x30
00007981ddfd83cb  movaps [rsp], xmm11
00007981ddfd83d0  movaps [rsp+0x10], xmm14
00007981ddfd83d6  movaps [rsp+0x20], xmm13
00007981ddfd83dc  lea rdi, [rsp]
00007981ddfd83e0  mov esi, 0x00
00007981ddfd83e5  mov rax, 0x5782A6EB3530
00007981ddfd83ef  call rax
00007981ddfd83f1  movaps xmm11, [rsp]
00007981ddfd83f6  add rsp, 0x30
00007981ddfd83fa  vmovaps xmm0, [rsp]
00007981ddfd83ff  vmovaps xmm1, [rsp+0x10]
00007981ddfd8405  vmovaps xmm2, [rsp+0x20]
00007981ddfd840b  vmovaps xmm3, [rsp+0x30]
00007981ddfd8411  vmovaps xmm4, [rsp+0x40]
00007981ddfd8417  vmovaps xmm5, [rsp+0x50]
00007981ddfd841d  vmovaps xmm6, [rsp+0x60]
00007981ddfd8423  vmovaps xmm7, [rsp+0x70]
00007981ddfd8429  vmovaps xmm8, [rsp+0x80]
00007981ddfd8432  vmovaps xmm9, [rsp+0x90]
00007981ddfd843b  vmovaps xmm10, [rsp+0xA0]
00007981ddfd8444  vmovaps xmm12, [rsp+0xB0]
00007981ddfd844d  vmovaps xmm13, [rsp+0xC0]
00007981ddfd8456  vmovaps xmm14, [rsp+0xD0]
00007981ddfd845f  vmovaps xmm15, [rsp+0xE0]
00007981ddfd8468  add rsp, 0xF0
00007981ddfd846f  pop r11
00007981ddfd8471  pop r10
00007981ddfd8473  pop r9
00007981ddfd8475  pop r8
00007981ddfd8477  pop rsi
00007981ddfd8478  pop rdi
00007981ddfd8479  pop rdx
00007981ddfd847a  pop rcx
00007981ddfd847b  pop rax
00007981ddfd847c  add rsp, 0x08
00007981ddfd8480  jmp 0x00007981DDFD34F4
00007981ddfd8485  sub rsp, 0x08
00007981ddfd8489  push rax
00007981ddfd848a  push rcx
00007981ddfd848b  push rdx
00007981ddfd848c  push rdi
00007981ddfd848d  push rsi
00007981ddfd848e  push r8
00007981ddfd8490  push r9
00007981ddfd8492  push r10
00007981ddfd8494  push r11
00007981ddfd8496  sub rsp, 0xF0
00007981ddfd849d  vmovaps [rsp], xmm0
00007981ddfd84a2  vmovaps [rsp+0x10], xmm1
00007981ddfd84a8  vmovaps [rsp+0x20], xmm2
00007981ddfd84ae  vmovaps [rsp+0x30], xmm3
00007981ddfd84b4  vmovaps [rsp+0x40], xmm4
00007981ddfd84ba  vmovaps [rsp+0x50], xmm5
00007981ddfd84c0  vmovaps [rsp+0x60], xmm6
00007981ddfd84c6  vmovaps [rsp+0x70], xmm7
00007981ddfd84cc  vmovaps [rsp+0x80], xmm8
00007981ddfd84d5  vmovaps [rsp+0x90], xmm9
00007981ddfd84de  vmovaps [rsp+0xA0], xmm10
00007981ddfd84e7  vmovaps [rsp+0xB0], xmm11
00007981ddfd84f0  vmovaps [rsp+0xC0], xmm12
00007981ddfd84f9  vmovaps [rsp+0xD0], xmm13
00007981ddfd8502  vmovaps [rsp+0xE0], xmm15
00007981ddfd850b  sub rsp, 0x30
00007981ddfd850f  movaps [rsp], xmm14
00007981ddfd8514  movaps [rsp+0x10], xmm12
00007981ddfd851a  movaps [rsp+0x20], xmm9
00007981ddfd8520  lea rdi, [rsp]
00007981ddfd8524  mov esi, 0x00
00007981ddfd8529  mov rax, 0x5782A6EB3530
00007981ddfd8533  call rax
00007981ddfd8535  movaps xmm14, [rsp]
00007981ddfd853a  add rsp, 0x30
00007981ddfd853e  vmovaps xmm0, [rsp]
00007981ddfd8543  vmovaps xmm1, [rsp+0x10]
00007981ddfd8549  vmovaps xmm2, [rsp+0x20]
00007981ddfd854f  vmovaps xmm3, [rsp+0x30]
00007981ddfd8555  vmovaps xmm4, [rsp+0x40]
00007981ddfd855b  vmovaps xmm5, [rsp+0x50]
00007981ddfd8561  vmovaps xmm6, [rsp+0x60]
00007981ddfd8567  vmovaps xmm7, [rsp+0x70]
00007981ddfd856d  vmovaps xmm8, [rsp+0x80]
00007981ddfd8576  vmovaps xmm9, [rsp+0x90]
00007981ddfd857f  vmovaps xmm10, [rsp+0xA0]
00007981ddfd8588  vmovaps xmm11, [rsp+0xB0]
00007981ddfd8591  vmovaps xmm12, [rsp+0xC0]
00007981ddfd859a  vmovaps xmm13, [rsp+0xD0]
00007981ddfd85a3  vmovaps xmm15, [rsp+0xE0]
00007981ddfd85ac  add rsp, 0xF0
00007981ddfd85b3  pop r11
00007981ddfd85b5  pop r10
00007981ddfd85b7  pop r9
00007981ddfd85b9  pop r8
00007981ddfd85bb  pop rsi
00007981ddfd85bc  pop rdi
00007981ddfd85bd  pop rdx
00007981ddfd85be  pop rcx
00007981ddfd85bf  pop rax
00007981ddfd85c0  add rsp, 0x08
00007981ddfd85c4  jmp 0x00007981DDFD350F
00007981ddfd85c9  sub rsp, 0x08
00007981ddfd85cd  push rax
00007981ddfd85ce  push rcx
00007981ddfd85cf  push rdx
00007981ddfd85d0  push rdi
00007981ddfd85d1  push rsi
00007981ddfd85d2  push r8
00007981ddfd85d4  push r9
00007981ddfd85d6  push r10
00007981ddfd85d8  push r11
00007981ddfd85da  sub rsp, 0xF0
00007981ddfd85e1  vmovaps [rsp], xmm0
00007981ddfd85e6  vmovaps [rsp+0x10], xmm1
00007981ddfd85ec  vmovaps [rsp+0x20], xmm2
00007981ddfd85f2  vmovaps [rsp+0x30], xmm3
00007981ddfd85f8  vmovaps [rsp+0x40], xmm4
00007981ddfd85fe  vmovaps [rsp+0x50], xmm5
00007981ddfd8604  vmovaps [rsp+0x60], xmm6
00007981ddfd860a  vmovaps [rsp+0x70], xmm7
00007981ddfd8610  vmovaps [rsp+0x80], xmm8
00007981ddfd8619  vmovaps [rsp+0x90], xmm9
00007981ddfd8622  vmovaps [rsp+0xA0], xmm10
00007981ddfd862b  vmovaps [rsp+0xB0], xmm11
00007981ddfd8634  vmovaps [rsp+0xC0], xmm12
00007981ddfd863d  vmovaps [rsp+0xD0], xmm14
00007981ddfd8646  vmovaps [rsp+0xE0], xmm15
00007981ddfd864f  sub rsp, 0x30
00007981ddfd8653  movaps [rsp], xmm13
00007981ddfd8658  movaps [rsp+0x10], xmm8
00007981ddfd865e  movaps [rsp+0x20], xmm15
00007981ddfd8664  lea rdi, [rsp]
00007981ddfd8668  mov esi, 0x00
00007981ddfd866d  mov rax, 0x5782A6EB3530
00007981ddfd8677  call rax
00007981ddfd8679  movaps xmm13, [rsp]
00007981ddfd867e  add rsp, 0x30
00007981ddfd8682  vmovaps xmm0, [rsp]
00007981ddfd8687  vmovaps xmm1, [rsp+0x10]
00007981ddfd868d  vmovaps xmm2, [rsp+0x20]
00007981ddfd8693  vmovaps xmm3, [rsp+0x30]
00007981ddfd8699  vmovaps xmm4, [rsp+0x40]
00007981ddfd869f  vmovaps xmm5, [rsp+0x50]
00007981ddfd86a5  vmovaps xmm6, [rsp+0x60]
00007981ddfd86ab  vmovaps xmm7, [rsp+0x70]
00007981ddfd86b1  vmovaps xmm8, [rsp+0x80]
00007981ddfd86ba  vmovaps xmm9, [rsp+0x90]
00007981ddfd86c3  vmovaps xmm10, [rsp+0xA0]
00007981ddfd86cc  vmovaps xmm11, [rsp+0xB0]
00007981ddfd86d5  vmovaps xmm12, [rsp+0xC0]
00007981ddfd86de  vmovaps xmm14, [rsp+0xD0]
00007981ddfd86e7  vmovaps xmm15, [rsp+0xE0]
00007981ddfd86f0  add rsp, 0xF0
00007981ddfd86f7  pop r11
00007981ddfd86f9  pop r10
00007981ddfd86fb  pop r9
00007981ddfd86fd  pop r8
00007981ddfd86ff  pop rsi
00007981ddfd8700  pop rdi
00007981ddfd8701  pop rdx
00007981ddfd8702  pop rcx
00007981ddfd8703  pop rax
00007981ddfd8704  add rsp, 0x08
00007981ddfd8708  jmp 0x00007981DDFD3532
00007981ddfd870d  sub rsp, 0x08
00007981ddfd8711  push rax
00007981ddfd8712  push rcx
00007981ddfd8713  push rdx
00007981ddfd8714  push rdi
00007981ddfd8715  push rsi
00007981ddfd8716  push r8
00007981ddfd8718  push r9
00007981ddfd871a  push r10
00007981ddfd871c  push r11
00007981ddfd871e  sub rsp, 0xF0
00007981ddfd8725  vmovaps [rsp], xmm0
00007981ddfd872a  vmovaps [rsp+0x10], xmm1
00007981ddfd8730  vmovaps [rsp+0x20], xmm2
00007981ddfd8736  vmovaps [rsp+0x30], xmm3
00007981ddfd873c  vmovaps [rsp+0x40], xmm4
00007981ddfd8742  vmovaps [rsp+0x50], xmm5
00007981ddfd8748  vmovaps [rsp+0x60], xmm6
00007981ddfd874e  vmovaps [rsp+0x70], xmm7
00007981ddfd8754  vmovaps [rsp+0x80], xmm8
00007981ddfd875d  vmovaps [rsp+0x90], xmm9
00007981ddfd8766  vmovaps [rsp+0xA0], xmm10
00007981ddfd876f  vmovaps [rsp+0xB0], xmm11
00007981ddfd8778  vmovaps [rsp+0xC0], xmm12
00007981ddfd8781  vmovaps [rsp+0xD0], xmm13
00007981ddfd878a  vmovaps [rsp+0xE0], xmm14
00007981ddfd8793  sub rsp, 0x30
00007981ddfd8797  movaps [rsp], xmm15
00007981ddfd879c  movaps [rsp+0x10], xmm1
00007981ddfd87a1  movaps [rsp+0x20], xmm10
00007981ddfd87a7  lea rdi, [rsp]
00007981ddfd87ab  mov esi, 0x00
00007981ddfd87b0  mov rax, 0x5782A6EB3530
00007981ddfd87ba  call rax
00007981ddfd87bc  movaps xmm15, [rsp]
00007981ddfd87c1  add rsp, 0x30
00007981ddfd87c5  vmovaps xmm0, [rsp]
00007981ddfd87ca  vmovaps xmm1, [rsp+0x10]
00007981ddfd87d0  vmovaps xmm2, [rsp+0x20]
00007981ddfd87d6  vmovaps xmm3, [rsp+0x30]
00007981ddfd87dc  vmovaps xmm4, [rsp+0x40]
00007981ddfd87e2  vmovaps xmm5, [rsp+0x50]
00007981ddfd87e8  vmovaps xmm6, [rsp+0x60]
00007981ddfd87ee  vmovaps xmm7, [rsp+0x70]
00007981ddfd87f4  vmovaps xmm8, [rsp+0x80]
00007981ddfd87fd  vmovaps xmm9, [rsp+0x90]
00007981ddfd8806  vmovaps xmm10, [rsp+0xA0]
00007981ddfd880f  vmovaps xmm11, [rsp+0xB0]
00007981ddfd8818  vmovaps xmm12, [rsp+0xC0]
00007981ddfd8821  vmovaps xmm13, [rsp+0xD0]
00007981ddfd882a  vmovaps xmm14, [rsp+0xE0]
00007981ddfd8833  add rsp, 0xF0
00007981ddfd883a  pop r11
00007981ddfd883c  pop r10
00007981ddfd883e  pop r9
00007981ddfd8840  pop r8
00007981ddfd8842  pop rsi
00007981ddfd8843  pop rdi
00007981ddfd8844  pop rdx
00007981ddfd8845  pop rcx
00007981ddfd8846  pop rax
00007981ddfd8847  add rsp, 0x08
00007981ddfd884b  jmp 0x00007981DDFD3555
00007981ddfd8850  sub rsp, 0x08
00007981ddfd8854  push rax
00007981ddfd8855  push rcx
00007981ddfd8856  push rdx
00007981ddfd8857  push rdi
00007981ddfd8858  push rsi
00007981ddfd8859  push r8
00007981ddfd885b  push r9
00007981ddfd885d  push r10
00007981ddfd885f  push r11
00007981ddfd8861  sub rsp, 0xF0
00007981ddfd8868  vmovaps [rsp], xmm0
00007981ddfd886d  vmovaps [rsp+0x10], xmm2
00007981ddfd8873  vmovaps [rsp+0x20], xmm3
00007981ddfd8879  vmovaps [rsp+0x30], xmm4
00007981ddfd887f  vmovaps [rsp+0x40], xmm5
00007981ddfd8885  vmovaps [rsp+0x50], xmm6
00007981ddfd888b  vmovaps [rsp+0x60], xmm7
00007981ddfd8891  vmovaps [rsp+0x70], xmm8
00007981ddfd8897  vmovaps [rsp+0x80], xmm9
00007981ddfd88a0  vmovaps [rsp+0x90], xmm10
00007981ddfd88a9  vmovaps [rsp+0xA0], xmm11
00007981ddfd88b2  vmovaps [rsp+0xB0], xmm12
00007981ddfd88bb  vmovaps [rsp+0xC0], xmm13
00007981ddfd88c4  vmovaps [rsp+0xD0], xmm14
00007981ddfd88cd  vmovaps [rsp+0xE0], xmm15
00007981ddfd88d6  sub rsp, 0x30
00007981ddfd88da  movaps [rsp], xmm1
00007981ddfd88de  movaps [rsp+0x10], xmm7
00007981ddfd88e3  movaps [rsp+0x20], xmm11
00007981ddfd88e9  lea rdi, [rsp]
00007981ddfd88ed  mov esi, 0x00
00007981ddfd88f2  mov rax, 0x5782A6EB3530
00007981ddfd88fc  call rax
00007981ddfd88fe  movaps xmm1, [rsp]
00007981ddfd8902  add rsp, 0x30
00007981ddfd8906  vmovaps xmm0, [rsp]
00007981ddfd890b  vmovaps xmm2, [rsp+0x10]
00007981ddfd8911  vmovaps xmm3, [rsp+0x20]
00007981ddfd8917  vmovaps xmm4, [rsp+0x30]
00007981ddfd891d  vmovaps xmm5, [rsp+0x40]
00007981ddfd8923  vmovaps xmm6, [rsp+0x50]
00007981ddfd8929  vmovaps xmm7, [rsp+0x60]
00007981ddfd892f  vmovaps xmm8, [rsp+0x70]
00007981ddfd8935  vmovaps xmm9, [rsp+0x80]
00007981ddfd893e  vmovaps xmm10, [rsp+0x90]
00007981ddfd8947  vmovaps xmm11, [rsp+0xA0]
00007981ddfd8950  vmovaps xmm12, [rsp+0xB0]
00007981ddfd8959  vmovaps xmm13, [rsp+0xC0]
00007981ddfd8962  vmovaps xmm14, [rsp+0xD0]
00007981ddfd896b  vmovaps xmm15, [rsp+0xE0]
00007981ddfd8974  add rsp, 0xF0
00007981ddfd897b  pop r11
00007981ddfd897d  pop r10
00007981ddfd897f  pop r9
00007981ddfd8981  pop r8
00007981ddfd8983  pop rsi
00007981ddfd8984  pop rdi
00007981ddfd8985  pop rdx
00007981ddfd8986  pop rcx
00007981ddfd8987  pop rax
00007981ddfd8988  add rsp, 0x08
00007981ddfd898c  jmp 0x00007981DDFD3576
00007981ddfd8991  call 0x00007981DDE0D600
00007981ddfd8996  jmp 0x00007981DDFD3589
00007981ddfd899b  call 0x00007981DDE0C380
00007981ddfd89a0  jmp 0x00007981DDFD3594
00007981ddfd89a5  call 0x00007981DDE0E880
00007981ddfd89aa  jmp 0x00007981DDFD359F
00007981ddfd89af  call 0x00007981DDDFF540
00007981ddfd89b4  jmp 0x00007981DDFD35AA
00007981ddfd89b9  int3
00007981ddfd89ba  nop [rax+rax*1], ax
00007981ddfd89c0  mov rax, [r15+0x40]
00007981ddfd89c4  mov r14, [r15+0x58]
00007981ddfd89c8  lea r12, [rax+r14*1]
00007981ddfd89cc  movaps xmm1, [r15+0x1D0]
00007981ddfd89d4  vmovaps [rsp+0x10], xmm1
00007981ddfd89da  vmovaps xmm15, [rsp+0x10]
00007981ddfd89e0  por xmm1, xmm15
00007981ddfd89e5  movaps xmm14, [r15+0x1A0]
00007981ddfd89ed  vmovaps [rsp+0x10], xmm14
00007981ddfd89f3  vmovaps xmm13, [rsp+0x10]
00007981ddfd89f9  por xmm14, xmm13
00007981ddfd89fe  lea rax, [r12+0x30]
00007981ddfd8a03  mov r11, [r13+rax*1]
00007981ddfd8a08  lea rax, [r12+0x38]
00007981ddfd8a0d  mov r10, [r13+rax*1]
00007981ddfd8a12  movq xmm13, r11
00007981ddfd8a17  movq xmm12, r10
00007981ddfd8a1c  movq xmm13, xmm13
00007981ddfd8a21  vmovaps [rsp+0x10], xmm13
00007981ddfd8a27  movq xmm13, xmm13
00007981ddfd8a2c  movaps [r15+0x130], xmm13
00007981ddfd8a34  movq xmm12, xmm12
00007981ddfd8a39  vmovaps [rsp+0x20], xmm12
00007981ddfd8a3f  movq xmm12, xmm12
00007981ddfd8a44  movaps [r15+0x280], xmm12
00007981ddfd8a4c  movaps xmm13, [r15+0x270]
00007981ddfd8a54  vmovaps [rsp+0x30], xmm13
00007981ddfd8a5a  vmovaps xmm12, [rsp+0x30]
00007981ddfd8a60  por xmm13, xmm12
00007981ddfd8a65  lea rax, [r12+0x20]
00007981ddfd8a6a  mov r11, [r13+rax*1]
00007981ddfd8a6f  lea rax, [r12+0x28]
00007981ddfd8a74  mov r10, [r13+rax*1]
00007981ddfd8a79  movq xmm12, r11
00007981ddfd8a7e  movq xmm11, r10
00007981ddfd8a83  movq xmm12, xmm12
00007981ddfd8a88  vmovaps [rsp+0x30], xmm12
00007981ddfd8a8e  movq xmm12, xmm12
00007981ddfd8a93  movaps [r15+0x150], xmm12
00007981ddfd8a9b  movq xmm11, xmm11
00007981ddfd8aa0  vmovaps [rsp+0x40], xmm11
00007981ddfd8aa6  movq xmm11, xmm11
00007981ddfd8aab  movaps [r15+0x140], xmm11
00007981ddfd8ab3  lea rax, [r12+0x10]
00007981ddfd8ab8  mov r11, [r13+rax*1]
00007981ddfd8abd  lea rax, [r12+0x18]
00007981ddfd8ac2  mov r10, [r13+rax*1]
00007981ddfd8ac7  movq xmm12, r11
00007981ddfd8acc  movq xmm11, r10
00007981ddfd8ad1  movq xmm12, xmm12
00007981ddfd8ad6  vmovaps [rsp+0x50], xmm12
00007981ddfd8adc  movq xmm12, xmm12
00007981ddfd8ae1  movaps [r15+0x170], xmm12
00007981ddfd8ae9  movq xmm11, xmm11
00007981ddfd8aee  vmovaps [rsp+0x60], xmm11
00007981ddfd8af4  movq xmm11, xmm11
00007981ddfd8af9  movaps [r15+0x160], xmm11
00007981ddfd8b01  mov rax, [r13+r12*1]
00007981ddfd8b06  vmovq xmm12, rax
00007981ddfd8b0b  vpbroadcastq xmm12, xmm12
00007981ddfd8b10  lea rax, [r12+0x08]
00007981ddfd8b15  mov r12, [r13+rax*1]
00007981ddfd8b1a  movq xmm11, r12
00007981ddfd8b1f  movaps [r15+0x230], xmm11
00007981ddfd8b27  mov rax, [r15+0xF8]
00007981ddfd8b2e  lea r12, [rax+0x50]
00007981ddfd8b32  movups xmm11, [r13+r12*1]
00007981ddfd8b38  lea r12, [rax+0x60]
00007981ddfd8b3c  movups xmm10, [r13+r12*1]
00007981ddfd8b42  lea r12, [rax+0x30]
00007981ddfd8b46  movups xmm9, [r13+r12*1]
00007981ddfd8b4c  mov r12, [r15+0x50]
00007981ddfd8b50  lea r11, [r12+r14*1]
00007981ddfd8b54  mov [r15+0x60], r11
00007981ddfd8b58  lea r12, [r14+0x40]
00007981ddfd8b5c  mov [r15+0x58], r12
00007981ddfd8b60  movaps xmm8, xmm12
00007981ddfd8b64  mulpd xmm8, xmm15
00007981ddfd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007981ddfd8b6f  ptest xmm7, xmm7
00007981ddfd8b74  jnz 0x00007981DDFD9997
00007981ddfd8b7a  movq xmm15, qword ptr [r15+0x230]
00007981ddfd8b83  vmovaps [rsp+0x70], xmm15
00007981ddfd8b89  vpermilpd xmm15, xmm15, 0x00
00007981ddfd8b8f  movaps xmm7, xmm9
00007981ddfd8b93  mulpd xmm7, xmm15
00007981ddfd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007981ddfd8b9d  ptest xmm6, xmm6
00007981ddfd8ba2  jnz 0x00007981DDFD9ADB
00007981ddfd8ba8  vxorps xmm15, xmm15, xmm15
00007981ddfd8bad  vpbroadcastq xmm15, xmm15
00007981ddfd8bb2  movaps xmm9, xmm12
00007981ddfd8bb6  mulpd xmm9, xmm10
00007981ddfd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007981ddfd8bc1  ptest xmm6, xmm6
00007981ddfd8bc6  jnz 0x00007981DDFD9C1D
00007981ddfd8bcc  movaps xmm10, xmm12
00007981ddfd8bd0  mulpd xmm10, xmm11
00007981ddfd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007981ddfd8bdb  ptest xmm6, xmm6
00007981ddfd8be0  jnz 0x00007981DDFD9D61
00007981ddfd8be6  movaps xmm11, [r15+0x1F0]
00007981ddfd8bee  movaps xmm6, xmm12
00007981ddfd8bf2  mulpd xmm6, xmm11
00007981ddfd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007981ddfd8bfc  ptest xmm5, xmm5
00007981ddfd8c01  jnz 0x00007981DDFD9EA5
00007981ddfd8c07  movaps xmm12, [r15+0x2A0]
00007981ddfd8c0f  vmovaps [rsp+0x80], xmm12
00007981ddfd8c18  vmovaps xmm11, [rsp+0x80]
00007981ddfd8c21  por xmm12, xmm11
00007981ddfd8c26  movaps xmm11, [r15+0x250]
00007981ddfd8c2e  vmovaps [rsp+0x80], xmm11
00007981ddfd8c37  vmovaps xmm5, [rsp+0x80]
00007981ddfd8c40  por xmm11, xmm5
00007981ddfd8c45  vmovaps xmm4, [rsp+0x70]
00007981ddfd8c4b  vpermilpd xmm4, xmm4, 0x00
00007981ddfd8c51  movaps xmm3, xmm5
00007981ddfd8c54  mulpd xmm3, xmm4
00007981ddfd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007981ddfd8c5d  ptest xmm2, xmm2
00007981ddfd8c62  jnz 0x00007981DDFD9FE7
00007981ddfd8c68  mov [rsp+0x80], rax
00007981ddfd8c70  xor eax, eax
00007981ddfd8c72  mov r14d, 0x200
00007981ddfd8c78  cmp r12, r14
00007981ddfd8c7b  cmc
00007981ddfd8c7c  lahf
00007981ddfd8c7d  seto al
00007981ddfd8c80  mov [r15+0x108], eax
00007981ddfd8c87  movaps xmm5, xmm8
00007981ddfd8c8b  addpd xmm5, xmm15
00007981ddfd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007981ddfd8c95  ptest xmm4, xmm4
00007981ddfd8c9a  jnz 0x00007981DDFDA127
00007981ddfd8ca0  movaps xmm8, [r15+0x1B0]
00007981ddfd8ca8  movaps xmm4, xmm9
00007981ddfd8cac  addpd xmm4, xmm8
00007981ddfd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007981ddfd8cb6  ptest xmm2, xmm2
00007981ddfd8cbb  jnz 0x00007981DDFDA269
00007981ddfd8cc1  movaps xmm9, xmm10
00007981ddfd8cc5  addpd xmm9, xmm8
00007981ddfd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007981ddfd8cd0  ptest xmm2, xmm2
00007981ddfd8cd5  jnz 0x00007981DDFDA3AB
00007981ddfd8cdb  movaps xmm10, [r15+0x2F0]
00007981ddfd8ce3  vmovaps [rsp+0x90], xmm10
00007981ddfd8cec  vmovaps xmm8, [rsp+0x90]
00007981ddfd8cf5  por xmm10, xmm8
00007981ddfd8cfa  movaps xmm8, [r15+0x2E0]
00007981ddfd8d02  vmovaps [rsp+0x90], xmm8
00007981ddfd8d0b  vmovaps xmm2, [rsp+0x90]
00007981ddfd8d14  por xmm8, xmm2
00007981ddfd8d19  movaps xmm2, [r15+0x2D0]
00007981ddfd8d21  vmovaps [rsp+0x90], xmm2
00007981ddfd8d2a  vmovaps [rsp+0xA0], xmm1
00007981ddfd8d33  vmovaps xmm1, [rsp+0x90]
00007981ddfd8d3c  por xmm2, xmm1
00007981ddfd8d40  movaps xmm1, [r15+0x200]
00007981ddfd8d48  vmovaps [rsp+0x90], xmm1
00007981ddfd8d51  vmovaps [rsp+0xB0], xmm15
00007981ddfd8d5a  vmovaps xmm15, [rsp+0x90]
00007981ddfd8d63  por xmm1, xmm15
00007981ddfd8d68  movaps xmm15, [r15+0x1C0]
00007981ddfd8d70  vmovaps [rsp+0x90], xmm15
00007981ddfd8d79  vmovaps [rsp+0xC0], xmm1
00007981ddfd8d82  vmovaps xmm1, [rsp+0x90]
00007981ddfd8d8b  por xmm15, xmm1
00007981ddfd8d90  movaps xmm1, [r15+0x190]
00007981ddfd8d98  vmovaps [rsp+0x90], xmm1
00007981ddfd8da1  vmovaps [rsp+0xD0], xmm15
00007981ddfd8daa  vmovaps xmm15, [rsp+0x90]
00007981ddfd8db3  por xmm1, xmm15
00007981ddfd8db8  movaps xmm15, [r15+0x300]
00007981ddfd8dc0  vmovaps [rsp+0x90], xmm15
00007981ddfd8dc9  vmovaps [rsp+0xE0], xmm1
00007981ddfd8dd2  vmovaps xmm1, [rsp+0x90]
00007981ddfd8ddb  por xmm15, xmm1
00007981ddfd8de0  mov rax, [rsp+0x80]
00007981ddfd8de8  lea r14, [rax+0xA0]
00007981ddfd8def  movups xmm1, [r13+r14*1]
00007981ddfd8df5  lea r14, [rax+0xB0]
00007981ddfd8dfc  vmovaps [rsp+0x80], xmm1
00007981ddfd8e05  movups xmm1, [r13+r14*1]
00007981ddfd8e0b  vmovaps [rsp+0x90], xmm1
00007981ddfd8e14  vmovaps [rsp+0xF0], xmm15
00007981ddfd8e1d  vmovaps xmm15, [rsp+0xB0]
00007981ddfd8e26  vmovaps [rsp+0xB0], xmm14
00007981ddfd8e2f  movaps xmm1, xmm6
00007981ddfd8e32  addpd xmm1, xmm15
00007981ddfd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007981ddfd8e3c  ptest xmm14, xmm14
00007981ddfd8e42  jnz 0x00007981DDFDA503
00007981ddfd8e48  lea r14, [rax+0xF0]
00007981ddfd8e4f  movups xmm15, [r13+r14*1]
00007981ddfd8e55  movaps xmm14, xmm4
00007981ddfd8e59  addpd xmm14, xmm3
00007981ddfd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007981ddfd8e64  ptest xmm6, xmm6
00007981ddfd8e69  jnz 0x00007981DDFDA64E
00007981ddfd8e6f  movaps xmm6, xmm9
00007981ddfd8e73  addpd xmm6, xmm7
00007981ddfd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007981ddfd8e7c  ptest xmm4, xmm4
00007981ddfd8e81  jnz 0x00007981DDFDA790
00007981ddfd8e87  vmovaps xmm9, [rsp+0x70]
00007981ddfd8e8d  vpermilpd xmm9, xmm9, 0x00
00007981ddfd8e93  vmovaps xmm4, [rsp+0x90]
00007981ddfd8e9c  movaps xmm7, xmm4
00007981ddfd8e9f  mulpd xmm7, xmm9
00007981ddfd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007981ddfd8ea9  ptest xmm3, xmm3
00007981ddfd8eae  jnz 0x00007981DDFDA8D1
00007981ddfd8eb4  vmovaps xmm9, [rsp+0x50]
00007981ddfd8eba  vpermilpd xmm9, xmm9, 0x00
00007981ddfd8ec0  movaps xmm4, xmm15
00007981ddfd8ec4  mulpd xmm4, xmm9
00007981ddfd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007981ddfd8ece  ptest xmm3, xmm3
00007981ddfd8ed3  jnz 0x00007981DDFDAA12
00007981ddfd8ed9  lea r14, [rax+0xE0]
00007981ddfd8ee0  movups xmm15, [r13+r14*1]
00007981ddfd8ee6  vmovaps xmm9, [rsp+0x70]
00007981ddfd8eec  vpermilpd xmm9, xmm9, 0x00
00007981ddfd8ef2  vmovaps [rsp+0x70], xmm1
00007981ddfd8ef8  vmovaps xmm1, [rsp+0x80]
00007981ddfd8f01  vmovaps [rsp+0x80], xmm15
00007981ddfd8f0a  movaps xmm3, xmm1
00007981ddfd8f0d  mulpd xmm3, xmm9
00007981ddfd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007981ddfd8f17  ptest xmm15, xmm15
00007981ddfd8f1d  jnz 0x00007981DDFDAB5E
00007981ddfd8f23  vmovaps xmm1, [rsp+0xF0]
00007981ddfd8f2c  vmovaps xmm15, [rsp+0xF0]
00007981ddfd8f35  por xmm1, xmm15
00007981ddfd8f3a  movaps [r15+0x300], xmm1
00007981ddfd8f42  vmovaps xmm15, [rsp+0xE0]
00007981ddfd8f4b  vmovaps xmm9, [rsp+0xE0]
00007981ddfd8f54  por xmm15, xmm9
00007981ddfd8f59  movaps [r15+0x190], xmm15
00007981ddfd8f61  vmovaps xmm9, [rsp+0x50]
00007981ddfd8f67  vpermilpd xmm9, xmm9, 0x00
00007981ddfd8f6d  vmovaps [rsp+0x90], xmm1
00007981ddfd8f76  vmovaps [rsp+0xE0], xmm15
00007981ddfd8f7f  vmovaps xmm15, [rsp+0x80]
00007981ddfd8f88  vmovaps [rsp+0x80], xmm14
00007981ddfd8f91  movaps xmm1, xmm15
00007981ddfd8f95  mulpd xmm1, xmm9
00007981ddfd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007981ddfd8f9f  ptest xmm14, xmm14
00007981ddfd8fa5  jnz 0x00007981DDFDAC9F
00007981ddfd8fab  lea r14, [rax+0x90]
00007981ddfd8fb2  movups xmm15, [r13+r14*1]
00007981ddfd8fb8  vmovaps xmm14, [rsp+0xD0]
00007981ddfd8fc1  vmovaps xmm9, [rsp+0xD0]
00007981ddfd8fca  por xmm14, xmm9
00007981ddfd8fcf  movaps [r15+0x1C0], xmm14
00007981ddfd8fd7  vmovaps xmm9, [rsp+0xC0]
00007981ddfd8fe0  vmovaps [rsp+0xD0], xmm1
00007981ddfd8fe9  vmovaps xmm1, [rsp+0xC0]
00007981ddfd8ff2  por xmm9, xmm1
00007981ddfd8ff7  movaps [r15+0x200], xmm9
00007981ddfd8fff  vmovaps [rsp+0xC0], xmm2
00007981ddfd9008  vmovaps xmm1, [rsp+0xC0]
00007981ddfd9011  por xmm2, xmm1
00007981ddfd9015  movaps [r15+0x2D0], xmm2
00007981ddfd901d  vmovaps [rsp+0xC0], xmm8
00007981ddfd9026  vmovaps xmm1, [rsp+0xC0]
00007981ddfd902f  por xmm8, xmm1
00007981ddfd9034  movaps [r15+0x2E0], xmm8
00007981ddfd903c  vmovaps [rsp+0xC0], xmm15
00007981ddfd9045  movaps xmm1, xmm5
00007981ddfd9048  addpd xmm1, xmm7
00007981ddfd904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007981ddfd9051  ptest xmm15, xmm15
00007981ddfd9057  jnz 0x00007981DDFDADEB
00007981ddfd905d  vmovaps xmm15, [rsp+0x50]
00007981ddfd9063  vpermilpd xmm15, xmm15, 0x00
00007981ddfd9069  vmovaps xmm5, [rsp+0xC0]
00007981ddfd9072  vmovaps [rsp+0xC0], xmm1
00007981ddfd907b  movaps xmm7, xmm5
00007981ddfd907e  mulpd xmm7, xmm15
00007981ddfd9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007981ddfd9088  ptest xmm1, xmm1
00007981ddfd908d  jnz 0x00007981DDFDAF2B
00007981ddfd9093  lea r14, [rax+0x80]
00007981ddfd909a  movups xmm1, [r13+r14*1]
00007981ddfd90a0  vmovaps xmm5, [rsp+0x70]
00007981ddfd90a6  vmovaps [rsp+0x70], xmm1
00007981ddfd90ac  movaps xmm15, xmm5
00007981ddfd90b0  addpd xmm15, xmm3
00007981ddfd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007981ddfd90bb  ptest xmm1, xmm1
00007981ddfd90c0  jnz 0x00007981DDFDB076
00007981ddfd90c6  vmovaps xmm5, [rsp+0x80]
00007981ddfd90cf  movaps xmm1, xmm5
00007981ddfd90d2  addpd xmm1, xmm4
00007981ddfd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007981ddfd90db  ptest xmm3, xmm3
00007981ddfd90e0  jnz 0x00007981DDFDB1B8
00007981ddfd90e6  vmovaps [rsp+0x80], xmm10
00007981ddfd90ef  vmovaps xmm5, [rsp+0x80]
00007981ddfd90f8  por xmm10, xmm5
00007981ddfd90fd  movaps [r15+0x2F0], xmm10
00007981ddfd9105  vmovaps xmm5, [rsp+0x50]
00007981ddfd910b  vpermilpd xmm5, xmm5, 0x00
00007981ddfd9111  vmovaps xmm3, [rsp+0x70]
00007981ddfd9117  vmovaps [rsp+0x50], xmm1
00007981ddfd911d  movaps xmm4, xmm3
00007981ddfd9120  mulpd xmm4, xmm5
00007981ddfd9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007981ddfd9129  ptest xmm1, xmm1
00007981ddfd912e  jnz 0x00007981DDFDB2F8
00007981ddfd9134  lea r14, [rax+0xD0]
00007981ddfd913b  movups xmm1, [r13+r14*1]
00007981ddfd9141  vmovaps xmm3, [rsp+0xD0]
00007981ddfd914a  vmovaps [rsp+0x70], xmm1
00007981ddfd9150  movaps xmm5, xmm6
00007981ddfd9153  addpd xmm5, xmm3
00007981ddfd9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007981ddfd915c  ptest xmm1, xmm1
00007981ddfd9161  jnz 0x00007981DDFDB442
00007981ddfd9167  vmovaps xmm1, [rsp+0x60]
00007981ddfd916d  vpermilpd xmm1, xmm1, 0x00
00007981ddfd9173  movaps xmm6, xmm9
00007981ddfd9177  mulpd xmm6, xmm1
00007981ddfd917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007981ddfd9180  ptest xmm3, xmm3
00007981ddfd9185  jnz 0x00007981DDFDB582
00007981ddfd918b  movaps [r15+0x260], xmm6
00007981ddfd9193  vxorps xmm1, xmm1, xmm1
00007981ddfd9197  vpbroadcastq xmm1, xmm1
00007981ddfd919c  movaps [r15+0x1B0], xmm1
00007981ddfd91a4  vmovaps xmm1, [rsp+0x60]
00007981ddfd91aa  vpermilpd xmm1, xmm1, 0x00
00007981ddfd91b0  vmovaps xmm3, [rsp+0x70]
00007981ddfd91b6  vmovaps [rsp+0x70], xmm15
00007981ddfd91bc  movaps xmm9, xmm3
00007981ddfd91c0  mulpd xmm9, xmm1
00007981ddfd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007981ddfd91cb  ptest xmm15, xmm15
00007981ddfd91d1  jnz 0x00007981DDFDB6C3
00007981ddfd91d7  lea r14, [rax+0xC0]
00007981ddfd91de  movups xmm1, [r13+r14*1]
00007981ddfd91e4  vmovaps xmm3, [rsp+0xC0]
00007981ddfd91ed  vmovaps [rsp+0x80], xmm1
00007981ddfd91f6  movaps xmm15, xmm3
00007981ddfd91fa  addpd xmm15, xmm7
00007981ddfd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007981ddfd9205  ptest xmm1, xmm1
00007981ddfd920a  jnz 0x00007981DDFDB80F
00007981ddfd9210  vmovaps [rsp+0xC0], xmm13
00007981ddfd9219  vmovaps xmm1, [rsp+0xC0]
00007981ddfd9222  por xmm13, xmm1
00007981ddfd9227  movaps [r15+0x270], xmm13
00007981ddfd922f  vmovaps xmm1, [rsp+0xB0]
00007981ddfd9238  vmovaps xmm7, [rsp+0xB0]
00007981ddfd9241  por xmm1, xmm7
00007981ddfd9245  movaps [r15+0x1A0], xmm1
00007981ddfd924d  vmovaps xmm1, [rsp+0x60]
00007981ddfd9253  vpermilpd xmm1, xmm1, 0x00
00007981ddfd9259  vmovaps [rsp+0xB0], xmm1
00007981ddfd9262  vmovaps xmm1, [rsp+0x80]
00007981ddfd926b  vmovaps [rsp+0x80], xmm15
00007981ddfd9274  vmovaps xmm15, [rsp+0xB0]
00007981ddfd927d  vmovaps [rsp+0xB0], xmm14
00007981ddfd9286  movaps xmm3, xmm1
00007981ddfd9289  mulpd xmm3, xmm15
00007981ddfd928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007981ddfd9293  ptest xmm14, xmm14
00007981ddfd9299  jnz 0x00007981DDFDB951
00007981ddfd929f  lea r14, [rax+0x20]
00007981ddfd92a3  movups xmm1, [r13+r14*1]
00007981ddfd92a9  movaps [r15+0x110], xmm1
00007981ddfd92b1  vmovaps xmm14, [rsp+0x70]
00007981ddfd92b7  vmovaps [rsp+0x70], xmm1
00007981ddfd92bd  movaps xmm15, xmm14
00007981ddfd92c1  addpd xmm15, xmm4
00007981ddfd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007981ddfd92cc  ptest xmm1, xmm1
00007981ddfd92d1  jnz 0x00007981DDFDBA9C
00007981ddfd92d7  vmovaps xmm1, [rsp+0x60]
00007981ddfd92dd  vpermilpd xmm1, xmm1, 0x00
00007981ddfd92e3  movaps xmm14, xmm2
00007981ddfd92e7  mulpd xmm14, xmm1
00007981ddfd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007981ddfd92f2  ptest xmm4, xmm4
00007981ddfd92f7  jnz 0x00007981DDFDBBDF
00007981ddfd92fd  vmovaps xmm4, [rsp+0x50]
00007981ddfd9303  movaps xmm1, xmm4
00007981ddfd9306  addpd xmm1, xmm9
00007981ddfd930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007981ddfd9310  ptest xmm2, xmm2
00007981ddfd9315  jnz 0x00007981DDFDBD21
00007981ddfd931b  vmovaps xmm9, [rsp+0x30]
00007981ddfd9321  vpermilpd xmm9, xmm9, 0x00
00007981ddfd9327  vmovaps xmm2, [rsp+0x70]
00007981ddfd932d  vmovaps [rsp+0x50], xmm1
00007981ddfd9333  movaps xmm4, xmm2
00007981ddfd9336  mulpd xmm4, xmm9
00007981ddfd933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007981ddfd9340  ptest xmm1, xmm1
00007981ddfd9345  jnz 0x00007981DDFDBE62
00007981ddfd934b  vmovaps xmm1, [rsp+0x30]
00007981ddfd9351  vpermilpd xmm1, xmm1, 0x00
00007981ddfd9357  vmovaps xmm2, [rsp+0x90]
00007981ddfd9360  vmovaps [rsp+0x60], xmm15
00007981ddfd9366  movaps xmm9, xmm2
00007981ddfd936a  mulpd xmm9, xmm1
00007981ddfd936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007981ddfd9375  ptest xmm15, xmm15
00007981ddfd937b  jnz 0x00007981DDFDBFA3
00007981ddfd9381  vmovaps xmm15, [rsp+0x80]
00007981ddfd938a  movaps xmm1, xmm15
00007981ddfd938e  addpd xmm1, xmm6
00007981ddfd9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007981ddfd9397  ptest xmm2, xmm2
00007981ddfd939c  jnz 0x00007981DDFDC0E5
00007981ddfd93a2  movaps xmm15, xmm5
00007981ddfd93a6  addpd xmm15, xmm3
00007981ddfd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007981ddfd93b1  ptest xmm6, xmm6
00007981ddfd93b6  jnz 0x00007981DDFDC226
00007981ddfd93bc  vmovaps xmm6, [rsp+0x30]
00007981ddfd93c2  vpermilpd xmm6, xmm6, 0x00
00007981ddfd93c8  movaps xmm5, xmm8
00007981ddfd93cc  mulpd xmm5, xmm6
00007981ddfd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007981ddfd93d5  ptest xmm3, xmm3
00007981ddfd93da  jnz 0x00007981DDFDC368
00007981ddfd93e0  vmovaps xmm8, [rsp+0x30]
00007981ddfd93e6  vpermilpd xmm8, xmm8, 0x00
00007981ddfd93ec  movaps xmm6, xmm10
00007981ddfd93f0  mulpd xmm6, xmm8
00007981ddfd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007981ddfd93fa  ptest xmm3, xmm3
00007981ddfd93ff  jnz 0x00007981DDFDC4A9
00007981ddfd9405  vmovaps xmm8, [rsp+0x60]
00007981ddfd940b  movaps xmm10, xmm8
00007981ddfd940f  addpd xmm10, xmm14
00007981ddfd9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007981ddfd941a  ptest xmm3, xmm3
00007981ddfd941f  jnz 0x00007981DDFDC5EB
00007981ddfd9425  vmovaps xmm8, [rsp+0x50]
00007981ddfd942b  movaps xmm14, xmm8
00007981ddfd942f  addpd xmm14, xmm4
00007981ddfd9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007981ddfd943a  ptest xmm3, xmm3
00007981ddfd943f  jnz 0x00007981DDFDC72F
00007981ddfd9445  vmovaps xmm8, [rsp+0x40]
00007981ddfd944b  vpermilpd xmm8, xmm8, 0x00
00007981ddfd9451  movaps xmm4, xmm13
00007981ddfd9455  mulpd xmm4, xmm8
00007981ddfd945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007981ddfd945f  ptest xmm3, xmm3
00007981ddfd9464  jnz 0x00007981DDFDC872
00007981ddfd946a  movaps xmm13, xmm15
00007981ddfd946e  addpd xmm13, xmm9
00007981ddfd9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007981ddfd9479  ptest xmm8, xmm8
00007981ddfd947f  jnz 0x00007981DDFDC9B4
00007981ddfd9485  movaps xmm15, xmm1
00007981ddfd9489  addpd xmm15, xmm5
00007981ddfd948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007981ddfd9494  ptest xmm9, xmm9
00007981ddfd949a  jnz 0x00007981DDFDCAF8
00007981ddfd94a0  vmovaps [rsp+0x30], xmm11
00007981ddfd94a6  vmovaps xmm1, [rsp+0x30]
00007981ddfd94ac  por xmm11, xmm1
00007981ddfd94b1  movaps [r15+0x250], xmm11
00007981ddfd94b9  vmovaps [rsp+0x30], xmm12
00007981ddfd94bf  vmovaps xmm1, [rsp+0x30]
00007981ddfd94c5  por xmm12, xmm1
00007981ddfd94ca  movaps [r15+0x2A0], xmm12
00007981ddfd94d2  vmovaps xmm1, [rsp+0xA0]
00007981ddfd94db  vmovaps xmm11, [rsp+0xA0]
00007981ddfd94e4  por xmm1, xmm11
00007981ddfd94e9  movaps [r15+0x1D0], xmm1
00007981ddfd94f1  lea r14, [rax+0x40]
00007981ddfd94f5  movups xmm1, [r13+r14*1]
00007981ddfd94fb  movaps [r15+0x2C0], xmm1
00007981ddfd9503  vmovaps xmm11, [rsp+0x40]
00007981ddfd9509  vpermilpd xmm11, xmm11, 0x00
00007981ddfd950f  vmovaps xmm8, [rsp+0xE0]
00007981ddfd9518  movaps xmm9, xmm8
00007981ddfd951c  mulpd xmm9, xmm11
00007981ddfd9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007981ddfd9527  ptest xmm5, xmm5
00007981ddfd952c  jnz 0x00007981DDFDCC44
00007981ddfd9532  movaps xmm11, xmm10
00007981ddfd9536  addpd xmm11, xmm6
00007981ddfd953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007981ddfd9541  ptest xmm8, xmm8
00007981ddfd9547  jnz 0x00007981DDFDCD88
00007981ddfd954d  movaps xmm10, xmm14
00007981ddfd9551  addpd xmm10, xmm4
00007981ddfd9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007981ddfd955c  ptest xmm8, xmm8
00007981ddfd9562  jnz 0x00007981DDFDCECB
00007981ddfd9568  vmovaps xmm14, [rsp+0x40]
00007981ddfd956e  vpermilpd xmm14, xmm14, 0x00
00007981ddfd9574  movaps xmm8, xmm1
00007981ddfd9578  mulpd xmm8, xmm14
00007981ddfd957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007981ddfd9583  ptest xmm6, xmm6
00007981ddfd9588  jnz 0x00007981DDFDD00E
00007981ddfd958e  movaps xmm1, [r15+0x2B0]
00007981ddfd9596  vmovaps xmm14, [rsp+0x40]
00007981ddfd959c  vpermilpd xmm14, xmm14, 0x00
00007981ddfd95a2  movaps xmm6, xmm1
00007981ddfd95a5  mulpd xmm6, xmm14
00007981ddfd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007981ddfd95af  ptest xmm5, xmm5
00007981ddfd95b4  jnz 0x00007981DDFDD151
00007981ddfd95ba  vmovaps xmm1, [rsp+0x10]
00007981ddfd95c0  vpermilpd xmm1, xmm1, 0x00
00007981ddfd95c6  movaps xmm14, xmm12
00007981ddfd95ca  mulpd xmm14, xmm1
00007981ddfd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007981ddfd95d5  ptest xmm5, xmm5
00007981ddfd95da  jnz 0x00007981DDFDD292
00007981ddfd95e0  movaps xmm1, xmm13
00007981ddfd95e4  addpd xmm1, xmm9
00007981ddfd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007981ddfd95ee  ptest xmm12, xmm12
00007981ddfd95f4  jnz 0x00007981DDFDD3D5
00007981ddfd95fa  vmovaps xmm13, [rsp+0x10]
00007981ddfd9600  vpermilpd xmm13, xmm13, 0x00
00007981ddfd9606  movaps xmm12, xmm7
00007981ddfd960a  mulpd xmm12, xmm13
00007981ddfd960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007981ddfd9615  ptest xmm9, xmm9
00007981ddfd961b  jnz 0x00007981DDFDD517
00007981ddfd9621  movaps xmm13, xmm15
00007981ddfd9625  addpd xmm13, xmm8
00007981ddfd962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007981ddfd9630  ptest xmm9, xmm9
00007981ddfd9636  jnz 0x00007981DDFDD65A
00007981ddfd963c  movaps xmm15, [r15+0x290]
00007981ddfd9644  vmovaps xmm9, [rsp+0x10]
00007981ddfd964a  vpermilpd xmm9, xmm9, 0x00
00007981ddfd9650  movaps xmm8, xmm15
00007981ddfd9654  mulpd xmm8, xmm9
00007981ddfd9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007981ddfd965f  ptest xmm7, xmm7
00007981ddfd9664  jnz 0x00007981DDFDD79E
00007981ddfd966a  movaps xmm15, xmm11
00007981ddfd966e  addpd xmm15, xmm6
00007981ddfd9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007981ddfd9679  ptest xmm9, xmm9
00007981ddfd967f  jnz 0x00007981DDFDD8E2
00007981ddfd9685  movaps xmm11, [r15+0x1E0]
00007981ddfd968d  vmovaps xmm9, [rsp+0x10]
00007981ddfd9693  vpermilpd xmm9, xmm9, 0x00
00007981ddfd9699  movaps xmm7, xmm11
00007981ddfd969d  mulpd xmm7, xmm9
00007981ddfd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007981ddfd96a7  ptest xmm6, xmm6
00007981ddfd96ac  jnz 0x00007981DDFDDA25
00007981ddfd96b2  movaps xmm11, xmm10
00007981ddfd96b6  addpd xmm11, xmm14
00007981ddfd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007981ddfd96c1  ptest xmm9, xmm9
00007981ddfd96c7  jnz 0x00007981DDFDDB67
00007981ddfd96cd  lea r14, [rax+0x70]
00007981ddfd96d1  movups xmm14, [r13+r14*1]
00007981ddfd96d7  movaps [r15+0x240], xmm14
00007981ddfd96df  movaps xmm10, xmm1
00007981ddfd96e3  addpd xmm10, xmm12
00007981ddfd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007981ddfd96ee  ptest xmm9, xmm9
00007981ddfd96f4  jnz 0x00007981DDFDDCB5
00007981ddfd96fa  movaps [r15+0x170], xmm10
00007981ddfd9702  vmovaps xmm1, [rsp+0x20]
00007981ddfd9708  vpermilpd xmm1, xmm1, 0x00
00007981ddfd970e  movaps xmm12, xmm14
00007981ddfd9712  mulpd xmm12, xmm1
00007981ddfd9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007981ddfd971d  ptest xmm9, xmm9
00007981ddfd9723  jnz 0x00007981DDFDDDF8
00007981ddfd9729  vmovaps xmm1, [rsp+0x20]
00007981ddfd972f  vpermilpd xmm1, xmm1, 0x00
00007981ddfd9735  vmovaps xmm9, [rsp+0xB0]
00007981ddfd973e  movaps xmm14, xmm9
00007981ddfd9742  mulpd xmm14, xmm1
00007981ddfd9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007981ddfd974d  ptest xmm6, xmm6
00007981ddfd9752  jnz 0x00007981DDFDDF3B
00007981ddfd9758  movaps [r15+0x180], xmm14
00007981ddfd9760  movaps xmm1, xmm13
00007981ddfd9764  addpd xmm1, xmm8
00007981ddfd9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007981ddfd976e  ptest xmm9, xmm9
00007981ddfd9774  jnz 0x00007981DDFDE07E
00007981ddfd977a  movaps [r15+0x210], xmm1
00007981ddfd9782  movups xmm13, [r13+rax*1]
00007981ddfd9788  lea r14, [rax+0x10]
00007981ddfd978c  movups xmm9, [r13+r14*1]
00007981ddfd9792  movaps [r15+0x230], xmm9
00007981ddfd979a  movaps xmm8, xmm15
00007981ddfd979e  addpd xmm8, xmm7
00007981ddfd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007981ddfd97a9  ptest xmm6, xmm6
00007981ddfd97ae  jnz 0x00007981DDFDE1D4
00007981ddfd97b4  movaps [r15+0x130], xmm8
00007981ddfd97bc  vmovaps xmm15, [rsp+0x20]
00007981ddfd97c2  vpermilpd xmm15, xmm15, 0x00
00007981ddfd97c8  movaps xmm7, xmm9
00007981ddfd97cc  mulpd xmm7, xmm15
00007981ddfd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007981ddfd97d6  ptest xmm6, xmm6
00007981ddfd97db  jnz 0x00007981DDFDE317
00007981ddfd97e1  movaps [r15+0x220], xmm7
00007981ddfd97e9  vmovaps xmm15, [rsp+0x20]
00007981ddfd97ef  vpermilpd xmm15, xmm15, 0x00
00007981ddfd97f5  movaps xmm9, xmm13
00007981ddfd97f9  mulpd xmm9, xmm15
00007981ddfd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007981ddfd9804  ptest xmm6, xmm6
00007981ddfd9809  jnz 0x00007981DDFDE459
00007981ddfd980f  movaps xmm15, xmm11
00007981ddfd9813  addpd xmm15, xmm12
00007981ddfd9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007981ddfd981e  ptest xmm13, xmm13
00007981ddfd9824  jnz 0x00007981DDFDE59D
00007981ddfd982a  movaps [r15+0x140], xmm15
00007981ddfd9832  movaps xmm13, xmm10
00007981ddfd9836  addpd xmm13, xmm14
00007981ddfd983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007981ddfd9841  ptest xmm12, xmm12
00007981ddfd9847  jnz 0x00007981DDFDE6E1
00007981ddfd984d  movaps [r15+0x150], xmm13
00007981ddfd9855  movaps xmm14, xmm1
00007981ddfd9859  addpd xmm14, xmm7
00007981ddfd985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007981ddfd9864  ptest xmm12, xmm12
00007981ddfd986a  jnz 0x00007981DDFDE825
00007981ddfd9870  movaps [r15+0x160], xmm14
00007981ddfd9878  movaps xmm1, xmm8
00007981ddfd987c  addpd xmm1, xmm9
00007981ddfd9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007981ddfd9886  ptest xmm12, xmm12
00007981ddfd988c  jnz 0x00007981DDFDE967
00007981ddfd9892  movaps [r15+0x120], xmm1
00007981ddfd989a  movups [r13+r11*1], xmm15
00007981ddfd98a0  lea rax, [r11+0x10]
00007981ddfd98a4  movups [r13+rax*1], xmm13
00007981ddfd98aa  lea rax, [r11+0x20]
00007981ddfd98ae  movups [r13+rax*1], xmm14
00007981ddfd98b4  lea rax, [r11+0x30]
00007981ddfd98b8  movups [r13+rax*1], xmm1
00007981ddfd98be  mov eax, [r15+0x108]
00007981ddfd98c5  sahf
00007981ddfd98c6  jnz 0x00007981DDFD98F8
00007981ddfd98c8  cmp dword ptr [r15+0x318], 0x00
00007981ddfd98d0  jz 0x00007981DDFDEAE0
00007981ddfd98d6  nop [rax+rax*1], ax
00007981ddfd98df  nop [rax+rax*1], eax
00007981ddfd98e7  mov eax, 0x4106D0
00007981ddfd98ec  mov [r15+0x100], rax
00007981ddfd98f3  jmp 0x00007981DDDFE110
00007981ddfd98f8  cmp dword ptr [r15+0x318], 0x00
00007981ddfd9900  jz 0x00007981DDFD89C0
00007981ddfd9906  nop [rax+rax*1], ax
00007981ddfd990f  nop [rax+rax*1], eax
00007981ddfd9917  mov eax, 0x410504
00007981ddfd991c  mov [r15+0x100], rax
00007981ddfd9923  jmp 0x00007981DDDFE110
00007981ddfd9928  int3
00007981ddfd9929  call 0x00007981DDE0A4B0
00007981ddfd992e  jmp 0x00007981DDFD8A08
00007981ddfd9933  call 0x00007981DDE09240
00007981ddfd9938  jmp 0x00007981DDFD8A12
00007981ddfd993d  call 0x00007981DDE0A4B0
00007981ddfd9942  jmp 0x00007981DDFD8A6F
00007981ddfd9947  call 0x00007981DDE09240
00007981ddfd994c  jmp 0x00007981DDFD8A79
00007981ddfd9951  call 0x00007981DDE0A4B0
00007981ddfd9956  jmp 0x00007981DDFD8ABD
00007981ddfd995b  call 0x00007981DDE09240
00007981ddfd9960  jmp 0x00007981DDFD8AC7
00007981ddfd9965  call 0x00007981DDEB47C0
00007981ddfd996a  jmp 0x00007981DDFD8B06
00007981ddfd996f  call 0x00007981DDE0B720
00007981ddfd9974  jmp 0x00007981DDFD8B1A
00007981ddfd9979  call 0x00007981DDEBFC30
00007981ddfd997e  jmp 0x00007981DDFD8B38
00007981ddfd9983  call 0x00007981DDEBE9C0
00007981ddfd9988  jmp 0x00007981DDFD8B42
00007981ddfd998d  call 0x00007981DDEBD750
00007981ddfd9992  jmp 0x00007981DDFD8B4C
00007981ddfd9997  sub rsp, 0x08
00007981ddfd999b  push rax
00007981ddfd999c  push rcx
00007981ddfd999d  push rdx
00007981ddfd999e  push rdi
00007981ddfd999f  push rsi
00007981ddfd99a0  push r8
00007981ddfd99a2  push r9
00007981ddfd99a4  push r10
00007981ddfd99a6  push r11
00007981ddfd99a8  sub rsp, 0xF0
00007981ddfd99af  vmovaps [rsp], xmm0
00007981ddfd99b4  vmovaps [rsp+0x10], xmm1
00007981ddfd99ba  vmovaps [rsp+0x20], xmm2
00007981ddfd99c0  vmovaps [rsp+0x30], xmm3
00007981ddfd99c6  vmovaps [rsp+0x40], xmm4
00007981ddfd99cc  vmovaps [rsp+0x50], xmm5
00007981ddfd99d2  vmovaps [rsp+0x60], xmm6
00007981ddfd99d8  vmovaps [rsp+0x70], xmm7
00007981ddfd99de  vmovaps [rsp+0x80], xmm9
00007981ddfd99e7  vmovaps [rsp+0x90], xmm10
00007981ddfd99f0  vmovaps [rsp+0xA0], xmm11
00007981ddfd99f9  vmovaps [rsp+0xB0], xmm12
00007981ddfd9a02  vmovaps [rsp+0xC0], xmm13
00007981ddfd9a0b  vmovaps [rsp+0xD0], xmm14
00007981ddfd9a14  vmovaps [rsp+0xE0], xmm15
00007981ddfd9a1d  sub rsp, 0x30
00007981ddfd9a21  movaps [rsp], xmm8
00007981ddfd9a26  movaps [rsp+0x10], xmm12
00007981ddfd9a2c  movaps [rsp+0x20], xmm15
00007981ddfd9a32  lea rdi, [rsp]
00007981ddfd9a36  mov esi, 0x00
00007981ddfd9a3b  mov rax, 0x5782A6EB3530
00007981ddfd9a45  call rax
00007981ddfd9a47  movaps xmm8, [rsp]
00007981ddfd9a4c  add rsp, 0x30
00007981ddfd9a50  vmovaps xmm0, [rsp]
00007981ddfd9a55  vmovaps xmm1, [rsp+0x10]
00007981ddfd9a5b  vmovaps xmm2, [rsp+0x20]
00007981ddfd9a61  vmovaps xmm3, [rsp+0x30]
00007981ddfd9a67  vmovaps xmm4, [rsp+0x40]
00007981ddfd9a6d  vmovaps xmm5, [rsp+0x50]
00007981ddfd9a73  vmovaps xmm6, [rsp+0x60]
00007981ddfd9a79  vmovaps xmm7, [rsp+0x70]
00007981ddfd9a7f  vmovaps xmm9, [rsp+0x80]
00007981ddfd9a88  vmovaps xmm10, [rsp+0x90]
00007981ddfd9a91  vmovaps xmm11, [rsp+0xA0]
00007981ddfd9a9a  vmovaps xmm12, [rsp+0xB0]
00007981ddfd9aa3  vmovaps xmm13, [rsp+0xC0]
00007981ddfd9aac  vmovaps xmm14, [rsp+0xD0]
00007981ddfd9ab5  vmovaps xmm15, [rsp+0xE0]
00007981ddfd9abe  add rsp, 0xF0
00007981ddfd9ac5  pop r11
00007981ddfd9ac7  pop r10
00007981ddfd9ac9  pop r9
00007981ddfd9acb  pop r8
00007981ddfd9acd  pop rsi
00007981ddfd9ace  pop rdi
00007981ddfd9acf  pop rdx
00007981ddfd9ad0  pop rcx
00007981ddfd9ad1  pop rax
00007981ddfd9ad2  add rsp, 0x08
00007981ddfd9ad6  jmp 0x00007981DDFD8B7A
00007981ddfd9adb  sub rsp, 0x08
00007981ddfd9adf  push rax
00007981ddfd9ae0  push rcx
00007981ddfd9ae1  push rdx
00007981ddfd9ae2  push rdi
00007981ddfd9ae3  push rsi
00007981ddfd9ae4  push r8
00007981ddfd9ae6  push r9
00007981ddfd9ae8  push r10
00007981ddfd9aea  push r11
00007981ddfd9aec  sub rsp, 0xF0
00007981ddfd9af3  vmovaps [rsp], xmm0
00007981ddfd9af8  vmovaps [rsp+0x10], xmm1
00007981ddfd9afe  vmovaps [rsp+0x20], xmm2
00007981ddfd9b04  vmovaps [rsp+0x30], xmm3
00007981ddfd9b0a  vmovaps [rsp+0x40], xmm4
00007981ddfd9b10  vmovaps [rsp+0x50], xmm5
00007981ddfd9b16  vmovaps [rsp+0x60], xmm6
00007981ddfd9b1c  vmovaps [rsp+0x70], xmm8
00007981ddfd9b22  vmovaps [rsp+0x80], xmm9
00007981ddfd9b2b  vmovaps [rsp+0x90], xmm10
00007981ddfd9b34  vmovaps [rsp+0xA0], xmm11
00007981ddfd9b3d  vmovaps [rsp+0xB0], xmm12
00007981ddfd9b46  vmovaps [rsp+0xC0], xmm13
00007981ddfd9b4f  vmovaps [rsp+0xD0], xmm14
00007981ddfd9b58  vmovaps [rsp+0xE0], xmm15
00007981ddfd9b61  sub rsp, 0x30
00007981ddfd9b65  movaps [rsp], xmm7
00007981ddfd9b69  movaps [rsp+0x10], xmm9
00007981ddfd9b6f  movaps [rsp+0x20], xmm15
00007981ddfd9b75  lea rdi, [rsp]
00007981ddfd9b79  mov esi, 0x00
00007981ddfd9b7e  mov rax, 0x5782A6EB3530
00007981ddfd9b88  call rax
00007981ddfd9b8a  movaps xmm7, [rsp]
00007981ddfd9b8e  add rsp, 0x30
00007981ddfd9b92  vmovaps xmm0, [rsp]
00007981ddfd9b97  vmovaps xmm1, [rsp+0x10]
00007981ddfd9b9d  vmovaps xmm2, [rsp+0x20]
00007981ddfd9ba3  vmovaps xmm3, [rsp+0x30]
00007981ddfd9ba9  vmovaps xmm4, [rsp+0x40]
00007981ddfd9baf  vmovaps xmm5, [rsp+0x50]
00007981ddfd9bb5  vmovaps xmm6, [rsp+0x60]
00007981ddfd9bbb  vmovaps xmm8, [rsp+0x70]
00007981ddfd9bc1  vmovaps xmm9, [rsp+0x80]
00007981ddfd9bca  vmovaps xmm10, [rsp+0x90]
00007981ddfd9bd3  vmovaps xmm11, [rsp+0xA0]
00007981ddfd9bdc  vmovaps xmm12, [rsp+0xB0]
00007981ddfd9be5  vmovaps xmm13, [rsp+0xC0]
00007981ddfd9bee  vmovaps xmm14, [rsp+0xD0]
00007981ddfd9bf7  vmovaps xmm15, [rsp+0xE0]
00007981ddfd9c00  add rsp, 0xF0
00007981ddfd9c07  pop r11
00007981ddfd9c09  pop r10
00007981ddfd9c0b  pop r9
00007981ddfd9c0d  pop r8
00007981ddfd9c0f  pop rsi
00007981ddfd9c10  pop rdi
00007981ddfd9c11  pop rdx
00007981ddfd9c12  pop rcx
00007981ddfd9c13  pop rax
00007981ddfd9c14  add rsp, 0x08
00007981ddfd9c18  jmp 0x00007981DDFD8BA8
00007981ddfd9c1d  sub rsp, 0x08
00007981ddfd9c21  push rax
00007981ddfd9c22  push rcx
00007981ddfd9c23  push rdx
00007981ddfd9c24  push rdi
00007981ddfd9c25  push rsi
00007981ddfd9c26  push r8
00007981ddfd9c28  push r9
00007981ddfd9c2a  push r10
00007981ddfd9c2c  push r11
00007981ddfd9c2e  sub rsp, 0xF0
00007981ddfd9c35  vmovaps [rsp], xmm0
00007981ddfd9c3a  vmovaps [rsp+0x10], xmm1
00007981ddfd9c40  vmovaps [rsp+0x20], xmm2
00007981ddfd9c46  vmovaps [rsp+0x30], xmm3
00007981ddfd9c4c  vmovaps [rsp+0x40], xmm4
00007981ddfd9c52  vmovaps [rsp+0x50], xmm5
00007981ddfd9c58  vmovaps [rsp+0x60], xmm6
00007981ddfd9c5e  vmovaps [rsp+0x70], xmm7
00007981ddfd9c64  vmovaps [rsp+0x80], xmm8
00007981ddfd9c6d  vmovaps [rsp+0x90], xmm10
00007981ddfd9c76  vmovaps [rsp+0xA0], xmm11
00007981ddfd9c7f  vmovaps [rsp+0xB0], xmm12
00007981ddfd9c88  vmovaps [rsp+0xC0], xmm13
00007981ddfd9c91  vmovaps [rsp+0xD0], xmm14
00007981ddfd9c9a  vmovaps [rsp+0xE0], xmm15
00007981ddfd9ca3  sub rsp, 0x30
00007981ddfd9ca7  movaps [rsp], xmm9
00007981ddfd9cac  movaps [rsp+0x10], xmm12
00007981ddfd9cb2  movaps [rsp+0x20], xmm10
00007981ddfd9cb8  lea rdi, [rsp]
00007981ddfd9cbc  mov esi, 0x00
00007981ddfd9cc1  mov rax, 0x5782A6EB3530
00007981ddfd9ccb  call rax
00007981ddfd9ccd  movaps xmm9, [rsp]
00007981ddfd9cd2  add rsp, 0x30
00007981ddfd9cd6  vmovaps xmm0, [rsp]
00007981ddfd9cdb  vmovaps xmm1, [rsp+0x10]
00007981ddfd9ce1  vmovaps xmm2, [rsp+0x20]
00007981ddfd9ce7  vmovaps xmm3, [rsp+0x30]
00007981ddfd9ced  vmovaps xmm4, [rsp+0x40]
00007981ddfd9cf3  vmovaps xmm5, [rsp+0x50]
00007981ddfd9cf9  vmovaps xmm6, [rsp+0x60]
00007981ddfd9cff  vmovaps xmm7, [rsp+0x70]
00007981ddfd9d05  vmovaps xmm8, [rsp+0x80]
00007981ddfd9d0e  vmovaps xmm10, [rsp+0x90]
00007981ddfd9d17  vmovaps xmm11, [rsp+0xA0]
00007981ddfd9d20  vmovaps xmm12, [rsp+0xB0]
00007981ddfd9d29  vmovaps xmm13, [rsp+0xC0]
00007981ddfd9d32  vmovaps xmm14, [rsp+0xD0]
00007981ddfd9d3b  vmovaps xmm15, [rsp+0xE0]
00007981ddfd9d44  add rsp, 0xF0
00007981ddfd9d4b  pop r11
00007981ddfd9d4d  pop r10
00007981ddfd9d4f  pop r9
00007981ddfd9d51  pop r8
00007981ddfd9d53  pop rsi
00007981ddfd9d54  pop rdi
00007981ddfd9d55  pop rdx
00007981ddfd9d56  pop rcx
00007981ddfd9d57  pop rax
00007981ddfd9d58  add rsp, 0x08
00007981ddfd9d5c  jmp 0x00007981DDFD8BCC
00007981ddfd9d61  sub rsp, 0x08
00007981ddfd9d65  push rax
00007981ddfd9d66  push rcx
00007981ddfd9d67  push rdx
00007981ddfd9d68  push rdi
00007981ddfd9d69  push rsi
00007981ddfd9d6a  push r8
00007981ddfd9d6c  push r9
00007981ddfd9d6e  push r10
00007981ddfd9d70  push r11
00007981ddfd9d72  sub rsp, 0xF0
00007981ddfd9d79  vmovaps [rsp], xmm0
00007981ddfd9d7e  vmovaps [rsp+0x10], xmm1
00007981ddfd9d84  vmovaps [rsp+0x20], xmm2
00007981ddfd9d8a  vmovaps [rsp+0x30], xmm3
00007981ddfd9d90  vmovaps [rsp+0x40], xmm4
00007981ddfd9d96  vmovaps [rsp+0x50], xmm5
00007981ddfd9d9c  vmovaps [rsp+0x60], xmm6
00007981ddfd9da2  vmovaps [rsp+0x70], xmm7
00007981ddfd9da8  vmovaps [rsp+0x80], xmm8
00007981ddfd9db1  vmovaps [rsp+0x90], xmm9
00007981ddfd9dba  vmovaps [rsp+0xA0], xmm11
00007981ddfd9dc3  vmovaps [rsp+0xB0], xmm12
00007981ddfd9dcc  vmovaps [rsp+0xC0], xmm13
00007981ddfd9dd5  vmovaps [rsp+0xD0], xmm14
00007981ddfd9dde  vmovaps [rsp+0xE0], xmm15
00007981ddfd9de7  sub rsp, 0x30
00007981ddfd9deb  movaps [rsp], xmm10
00007981ddfd9df0  movaps [rsp+0x10], xmm12
00007981ddfd9df6  movaps [rsp+0x20], xmm11
00007981ddfd9dfc  lea rdi, [rsp]
00007981ddfd9e00  mov esi, 0x00
00007981ddfd9e05  mov rax, 0x5782A6EB3530
00007981ddfd9e0f  call rax
00007981ddfd9e11  movaps xmm10, [rsp]
00007981ddfd9e16  add rsp, 0x30
00007981ddfd9e1a  vmovaps xmm0, [rsp]
00007981ddfd9e1f  vmovaps xmm1, [rsp+0x10]
00007981ddfd9e25  vmovaps xmm2, [rsp+0x20]
00007981ddfd9e2b  vmovaps xmm3, [rsp+0x30]
00007981ddfd9e31  vmovaps xmm4, [rsp+0x40]
00007981ddfd9e37  vmovaps xmm5, [rsp+0x50]
00007981ddfd9e3d  vmovaps xmm6, [rsp+0x60]
00007981ddfd9e43  vmovaps xmm7, [rsp+0x70]
00007981ddfd9e49  vmovaps xmm8, [rsp+0x80]
00007981ddfd9e52  vmovaps xmm9, [rsp+0x90]
00007981ddfd9e5b  vmovaps xmm11, [rsp+0xA0]
00007981ddfd9e64  vmovaps xmm12, [rsp+0xB0]
00007981ddfd9e6d  vmovaps xmm13, [rsp+0xC0]
00007981ddfd9e76  vmovaps xmm14, [rsp+0xD0]
00007981ddfd9e7f  vmovaps xmm15, [rsp+0xE0]
00007981ddfd9e88  add rsp, 0xF0
00007981ddfd9e8f  pop r11
00007981ddfd9e91  pop r10
00007981ddfd9e93  pop r9
00007981ddfd9e95  pop r8
00007981ddfd9e97  pop rsi
00007981ddfd9e98  pop rdi
00007981ddfd9e99  pop rdx
00007981ddfd9e9a  pop rcx
00007981ddfd9e9b  pop rax
00007981ddfd9e9c  add rsp, 0x08
00007981ddfd9ea0  jmp 0x00007981DDFD8BE6
00007981ddfd9ea5  sub rsp, 0x08
00007981ddfd9ea9  push rax
00007981ddfd9eaa  push rcx
00007981ddfd9eab  push rdx
00007981ddfd9eac  push rdi
00007981ddfd9ead  push rsi
00007981ddfd9eae  push r8
00007981ddfd9eb0  push r9
00007981ddfd9eb2  push r10
00007981ddfd9eb4  push r11
00007981ddfd9eb6  sub rsp, 0xF0
00007981ddfd9ebd  vmovaps [rsp], xmm0
00007981ddfd9ec2  vmovaps [rsp+0x10], xmm1
00007981ddfd9ec8  vmovaps [rsp+0x20], xmm2
00007981ddfd9ece  vmovaps [rsp+0x30], xmm3
00007981ddfd9ed4  vmovaps [rsp+0x40], xmm4
00007981ddfd9eda  vmovaps [rsp+0x50], xmm5
00007981ddfd9ee0  vmovaps [rsp+0x60], xmm7
00007981ddfd9ee6  vmovaps [rsp+0x70], xmm8
00007981ddfd9eec  vmovaps [rsp+0x80], xmm9
00007981ddfd9ef5  vmovaps [rsp+0x90], xmm10
00007981ddfd9efe  vmovaps [rsp+0xA0], xmm11
00007981ddfd9f07  vmovaps [rsp+0xB0], xmm12
00007981ddfd9f10  vmovaps [rsp+0xC0], xmm13
00007981ddfd9f19  vmovaps [rsp+0xD0], xmm14
00007981ddfd9f22  vmovaps [rsp+0xE0], xmm15
00007981ddfd9f2b  sub rsp, 0x30
00007981ddfd9f2f  movaps [rsp], xmm6
00007981ddfd9f33  movaps [rsp+0x10], xmm12
00007981ddfd9f39  movaps [rsp+0x20], xmm11
00007981ddfd9f3f  lea rdi, [rsp]
00007981ddfd9f43  mov esi, 0x00
00007981ddfd9f48  mov rax, 0x5782A6EB3530
00007981ddfd9f52  call rax
00007981ddfd9f54  movaps xmm6, [rsp]
00007981ddfd9f58  add rsp, 0x30
00007981ddfd9f5c  vmovaps xmm0, [rsp]
00007981ddfd9f61  vmovaps xmm1, [rsp+0x10]
00007981ddfd9f67  vmovaps xmm2, [rsp+0x20]
00007981ddfd9f6d  vmovaps xmm3, [rsp+0x30]
00007981ddfd9f73  vmovaps xmm4, [rsp+0x40]
00007981ddfd9f79  vmovaps xmm5, [rsp+0x50]
00007981ddfd9f7f  vmovaps xmm7, [rsp+0x60]
00007981ddfd9f85  vmovaps xmm8, [rsp+0x70]
00007981ddfd9f8b  vmovaps xmm9, [rsp+0x80]
00007981ddfd9f94  vmovaps xmm10, [rsp+0x90]
00007981ddfd9f9d  vmovaps xmm11, [rsp+0xA0]
00007981ddfd9fa6  vmovaps xmm12, [rsp+0xB0]
00007981ddfd9faf  vmovaps xmm13, [rsp+0xC0]
00007981ddfd9fb8  vmovaps xmm14, [rsp+0xD0]
00007981ddfd9fc1  vmovaps xmm15, [rsp+0xE0]
00007981ddfd9fca  add rsp, 0xF0
00007981ddfd9fd1  pop r11
00007981ddfd9fd3  pop r10
00007981ddfd9fd5  pop r9
00007981ddfd9fd7  pop r8
00007981ddfd9fd9  pop rsi
00007981ddfd9fda  pop rdi
00007981ddfd9fdb  pop rdx
00007981ddfd9fdc  pop rcx
00007981ddfd9fdd  pop rax
00007981ddfd9fde  add rsp, 0x08
00007981ddfd9fe2  jmp 0x00007981DDFD8C07
00007981ddfd9fe7  sub rsp, 0x08
00007981ddfd9feb  push rax
00007981ddfd9fec  push rcx
00007981ddfd9fed  push rdx
00007981ddfd9fee  push rdi
00007981ddfd9fef  push rsi
00007981ddfd9ff0  push r8
00007981ddfd9ff2  push r9
00007981ddfd9ff4  push r10
00007981ddfd9ff6  push r11
00007981ddfd9ff8  sub rsp, 0xF0
00007981ddfd9fff  vmovaps [rsp], xmm0
00007981ddfda004  vmovaps [rsp+0x10], xmm1
00007981ddfda00a  vmovaps [rsp+0x20], xmm2
00007981ddfda010  vmovaps [rsp+0x30], xmm4
00007981ddfda016  vmovaps [rsp+0x40], xmm5
00007981ddfda01c  vmovaps [rsp+0x50], xmm6
00007981ddfda022  vmovaps [rsp+0x60], xmm7
00007981ddfda028  vmovaps [rsp+0x70], xmm8
00007981ddfda02e  vmovaps [rsp+0x80], xmm9
00007981ddfda037  vmovaps [rsp+0x90], xmm10
00007981ddfda040  vmovaps [rsp+0xA0], xmm11
00007981ddfda049  vmovaps [rsp+0xB0], xmm12
00007981ddfda052  vmovaps [rsp+0xC0], xmm13
00007981ddfda05b  vmovaps [rsp+0xD0], xmm14
00007981ddfda064  vmovaps [rsp+0xE0], xmm15
00007981ddfda06d  sub rsp, 0x30
00007981ddfda071  movaps [rsp], xmm3
00007981ddfda075  movaps [rsp+0x10], xmm5
00007981ddfda07a  movaps [rsp+0x20], xmm4
00007981ddfda07f  lea rdi, [rsp]
00007981ddfda083  mov esi, 0x00
00007981ddfda088  mov rax, 0x5782A6EB3530
00007981ddfda092  call rax
00007981ddfda094  movaps xmm3, [rsp]
00007981ddfda098  add rsp, 0x30
00007981ddfda09c  vmovaps xmm0, [rsp]
00007981ddfda0a1  vmovaps xmm1, [rsp+0x10]
00007981ddfda0a7  vmovaps xmm2, [rsp+0x20]
00007981ddfda0ad  vmovaps xmm4, [rsp+0x30]
00007981ddfda0b3  vmovaps xmm5, [rsp+0x40]
00007981ddfda0b9  vmovaps xmm6, [rsp+0x50]
00007981ddfda0bf  vmovaps xmm7, [rsp+0x60]
00007981ddfda0c5  vmovaps xmm8, [rsp+0x70]
00007981ddfda0cb  vmovaps xmm9, [rsp+0x80]
00007981ddfda0d4  vmovaps xmm10, [rsp+0x90]
00007981ddfda0dd  vmovaps xmm11, [rsp+0xA0]
00007981ddfda0e6  vmovaps xmm12, [rsp+0xB0]
00007981ddfda0ef  vmovaps xmm13, [rsp+0xC0]
00007981ddfda0f8  vmovaps xmm14, [rsp+0xD0]
00007981ddfda101  vmovaps xmm15, [rsp+0xE0]
00007981ddfda10a  add rsp, 0xF0
00007981ddfda111  pop r11
00007981ddfda113  pop r10
00007981ddfda115  pop r9
00007981ddfda117  pop r8
00007981ddfda119  pop rsi
00007981ddfda11a  pop rdi
00007981ddfda11b  pop rdx
00007981ddfda11c  pop rcx
00007981ddfda11d  pop rax
00007981ddfda11e  add rsp, 0x08
00007981ddfda122  jmp 0x00007981DDFD8C68
00007981ddfda127  sub rsp, 0x08
00007981ddfda12b  push rax
00007981ddfda12c  push rcx
00007981ddfda12d  push rdx
00007981ddfda12e  push rdi
00007981ddfda12f  push rsi
00007981ddfda130  push r8
00007981ddfda132  push r9
00007981ddfda134  push r10
00007981ddfda136  push r11
00007981ddfda138  sub rsp, 0xF0
00007981ddfda13f  vmovaps [rsp], xmm0
00007981ddfda144  vmovaps [rsp+0x10], xmm1
00007981ddfda14a  vmovaps [rsp+0x20], xmm2
00007981ddfda150  vmovaps [rsp+0x30], xmm3
00007981ddfda156  vmovaps [rsp+0x40], xmm4
00007981ddfda15c  vmovaps [rsp+0x50], xmm6
00007981ddfda162  vmovaps [rsp+0x60], xmm7
00007981ddfda168  vmovaps [rsp+0x70], xmm8
00007981ddfda16e  vmovaps [rsp+0x80], xmm9
00007981ddfda177  vmovaps [rsp+0x90], xmm10
00007981ddfda180  vmovaps [rsp+0xA0], xmm11
00007981ddfda189  vmovaps [rsp+0xB0], xmm12
00007981ddfda192  vmovaps [rsp+0xC0], xmm13
00007981ddfda19b  vmovaps [rsp+0xD0], xmm14
00007981ddfda1a4  vmovaps [rsp+0xE0], xmm15
00007981ddfda1ad  sub rsp, 0x30
00007981ddfda1b1  movaps [rsp], xmm5
00007981ddfda1b5  movaps [rsp+0x10], xmm8
00007981ddfda1bb  movaps [rsp+0x20], xmm15
00007981ddfda1c1  lea rdi, [rsp]
00007981ddfda1c5  mov esi, 0x00
00007981ddfda1ca  mov rax, 0x5782A6EB3530
00007981ddfda1d4  call rax
00007981ddfda1d6  movaps xmm5, [rsp]
00007981ddfda1da  add rsp, 0x30
00007981ddfda1de  vmovaps xmm0, [rsp]
00007981ddfda1e3  vmovaps xmm1, [rsp+0x10]
00007981ddfda1e9  vmovaps xmm2, [rsp+0x20]
00007981ddfda1ef  vmovaps xmm3, [rsp+0x30]
00007981ddfda1f5  vmovaps xmm4, [rsp+0x40]
00007981ddfda1fb  vmovaps xmm6, [rsp+0x50]
00007981ddfda201  vmovaps xmm7, [rsp+0x60]
00007981ddfda207  vmovaps xmm8, [rsp+0x70]
00007981ddfda20d  vmovaps xmm9, [rsp+0x80]
00007981ddfda216  vmovaps xmm10, [rsp+0x90]
00007981ddfda21f  vmovaps xmm11, [rsp+0xA0]
00007981ddfda228  vmovaps xmm12, [rsp+0xB0]
00007981ddfda231  vmovaps xmm13, [rsp+0xC0]
00007981ddfda23a  vmovaps xmm14, [rsp+0xD0]
00007981ddfda243  vmovaps xmm15, [rsp+0xE0]
00007981ddfda24c  add rsp, 0xF0
00007981ddfda253  pop r11
00007981ddfda255  pop r10
00007981ddfda257  pop r9
00007981ddfda259  pop r8
00007981ddfda25b  pop rsi
00007981ddfda25c  pop rdi
00007981ddfda25d  pop rdx
00007981ddfda25e  pop rcx
00007981ddfda25f  pop rax
00007981ddfda260  add rsp, 0x08
00007981ddfda264  jmp 0x00007981DDFD8CA0
00007981ddfda269  sub rsp, 0x08
00007981ddfda26d  push rax
00007981ddfda26e  push rcx
00007981ddfda26f  push rdx
00007981ddfda270  push rdi
00007981ddfda271  push rsi
00007981ddfda272  push r8
00007981ddfda274  push r9
00007981ddfda276  push r10
00007981ddfda278  push r11
00007981ddfda27a  sub rsp, 0xF0
00007981ddfda281  vmovaps [rsp], xmm0
00007981ddfda286  vmovaps [rsp+0x10], xmm1
00007981ddfda28c  vmovaps [rsp+0x20], xmm2
00007981ddfda292  vmovaps [rsp+0x30], xmm3
00007981ddfda298  vmovaps [rsp+0x40], xmm5
00007981ddfda29e  vmovaps [rsp+0x50], xmm6
00007981ddfda2a4  vmovaps [rsp+0x60], xmm7
00007981ddfda2aa  vmovaps [rsp+0x70], xmm8
00007981ddfda2b0  vmovaps [rsp+0x80], xmm9
00007981ddfda2b9  vmovaps [rsp+0x90], xmm10
00007981ddfda2c2  vmovaps [rsp+0xA0], xmm11
00007981ddfda2cb  vmovaps [rsp+0xB0], xmm12
00007981ddfda2d4  vmovaps [rsp+0xC0], xmm13
00007981ddfda2dd  vmovaps [rsp+0xD0], xmm14
00007981ddfda2e6  vmovaps [rsp+0xE0], xmm15
00007981ddfda2ef  sub rsp, 0x30
00007981ddfda2f3  movaps [rsp], xmm4
00007981ddfda2f7  movaps [rsp+0x10], xmm9
00007981ddfda2fd  movaps [rsp+0x20], xmm8
00007981ddfda303  lea rdi, [rsp]
00007981ddfda307  mov esi, 0x00
00007981ddfda30c  mov rax, 0x5782A6EB3530
00007981ddfda316  call rax
00007981ddfda318  movaps xmm4, [rsp]
00007981ddfda31c  add rsp, 0x30
00007981ddfda320  vmovaps xmm0, [rsp]
00007981ddfda325  vmovaps xmm1, [rsp+0x10]
00007981ddfda32b  vmovaps xmm2, [rsp+0x20]
00007981ddfda331  vmovaps xmm3, [rsp+0x30]
00007981ddfda337  vmovaps xmm5, [rsp+0x40]
00007981ddfda33d  vmovaps xmm6, [rsp+0x50]
00007981ddfda343  vmovaps xmm7, [rsp+0x60]
00007981ddfda349  vmovaps xmm8, [rsp+0x70]
00007981ddfda34f  vmovaps xmm9, [rsp+0x80]
00007981ddfda358  vmovaps xmm10, [rsp+0x90]
00007981ddfda361  vmovaps xmm11, [rsp+0xA0]
00007981ddfda36a  vmovaps xmm12, [rsp+0xB0]
00007981ddfda373  vmovaps xmm13, [rsp+0xC0]
00007981ddfda37c  vmovaps xmm14, [rsp+0xD0]
00007981ddfda385  vmovaps xmm15, [rsp+0xE0]
00007981ddfda38e  add rsp, 0xF0
00007981ddfda395  pop r11
00007981ddfda397  pop r10
00007981ddfda399  pop r9
00007981ddfda39b  pop r8
00007981ddfda39d  pop rsi
00007981ddfda39e  pop rdi
00007981ddfda39f  pop rdx
00007981ddfda3a0  pop rcx
00007981ddfda3a1  pop rax
00007981ddfda3a2  add rsp, 0x08
00007981ddfda3a6  jmp 0x00007981DDFD8CC1
00007981ddfda3ab  sub rsp, 0x08
00007981ddfda3af  push rax
00007981ddfda3b0  push rcx
00007981ddfda3b1  push rdx
00007981ddfda3b2  push rdi
00007981ddfda3b3  push rsi
00007981ddfda3b4  push r8
00007981ddfda3b6  push r9
00007981ddfda3b8  push r10
00007981ddfda3ba  push r11
00007981ddfda3bc  sub rsp, 0xF0
00007981ddfda3c3  vmovaps [rsp], xmm0
00007981ddfda3c8  vmovaps [rsp+0x10], xmm1
00007981ddfda3ce  vmovaps [rsp+0x20], xmm2
00007981ddfda3d4  vmovaps [rsp+0x30], xmm3
00007981ddfda3da  vmovaps [rsp+0x40], xmm4
00007981ddfda3e0  vmovaps [rsp+0x50], xmm5
00007981ddfda3e6  vmovaps [rsp+0x60], xmm6
00007981ddfda3ec  vmovaps [rsp+0x70], xmm7
00007981ddfda3f2  vmovaps [rsp+0x80], xmm8
00007981ddfda3fb  vmovaps [rsp+0x90], xmm10
00007981ddfda404  vmovaps [rsp+0xA0], xmm11
00007981ddfda40d  vmovaps [rsp+0xB0], xmm12
00007981ddfda416  vmovaps [rsp+0xC0], xmm13
00007981ddfda41f  vmovaps [rsp+0xD0], xmm14
00007981ddfda428  vmovaps [rsp+0xE0], xmm15
00007981ddfda431  sub rsp, 0x30
00007981ddfda435  movaps [rsp], xmm9
00007981ddfda43a  movaps [rsp+0x10], xmm10
00007981ddfda440  movaps [rsp+0x20], xmm8
00007981ddfda446  lea rdi, [rsp]
00007981ddfda44a  mov esi, 0x00
00007981ddfda44f  mov rax, 0x5782A6EB3530
00007981ddfda459  call rax
00007981ddfda45b  movaps xmm9, [rsp]
00007981ddfda460  add rsp, 0x30
00007981ddfda464  vmovaps xmm0, [rsp]
00007981ddfda469  vmovaps xmm1, [rsp+0x10]
00007981ddfda46f  vmovaps xmm2, [rsp+0x20]
00007981ddfda475  vmovaps xmm3, [rsp+0x30]
00007981ddfda47b  vmovaps xmm4, [rsp+0x40]
00007981ddfda481  vmovaps xmm5, [rsp+0x50]
00007981ddfda487  vmovaps xmm6, [rsp+0x60]
00007981ddfda48d  vmovaps xmm7, [rsp+0x70]
00007981ddfda493  vmovaps xmm8, [rsp+0x80]
00007981ddfda49c  vmovaps xmm10, [rsp+0x90]
00007981ddfda4a5  vmovaps xmm11, [rsp+0xA0]
00007981ddfda4ae  vmovaps xmm12, [rsp+0xB0]
00007981ddfda4b7  vmovaps xmm13, [rsp+0xC0]
00007981ddfda4c0  vmovaps xmm14, [rsp+0xD0]
00007981ddfda4c9  vmovaps xmm15, [rsp+0xE0]
00007981ddfda4d2  add rsp, 0xF0
00007981ddfda4d9  pop r11
00007981ddfda4db  pop r10
00007981ddfda4dd  pop r9
00007981ddfda4df  pop r8
00007981ddfda4e1  pop rsi
00007981ddfda4e2  pop rdi
00007981ddfda4e3  pop rdx
00007981ddfda4e4  pop rcx
00007981ddfda4e5  pop rax
00007981ddfda4e6  add rsp, 0x08
00007981ddfda4ea  jmp 0x00007981DDFD8CDB
00007981ddfda4ef  call 0x00007981DDED64F0
00007981ddfda4f4  jmp 0x00007981DDFD8DF5
00007981ddfda4f9  call 0x00007981DDED64F0
00007981ddfda4fe  jmp 0x00007981DDFD8E0B
00007981ddfda503  sub rsp, 0x08
00007981ddfda507  push rax
00007981ddfda508  push rcx
00007981ddfda509  push rdx
00007981ddfda50a  push rdi
00007981ddfda50b  push rsi
00007981ddfda50c  push r8
00007981ddfda50e  push r9
00007981ddfda510  push r10
00007981ddfda512  push r11
00007981ddfda514  sub rsp, 0xF0
00007981ddfda51b  vmovaps [rsp], xmm0
00007981ddfda520  vmovaps [rsp+0x10], xmm2
00007981ddfda526  vmovaps [rsp+0x20], xmm3
00007981ddfda52c  vmovaps [rsp+0x30], xmm4
00007981ddfda532  vmovaps [rsp+0x40], xmm5
00007981ddfda538  vmovaps [rsp+0x50], xmm6
00007981ddfda53e  vmovaps [rsp+0x60], xmm7
00007981ddfda544  vmovaps [rsp+0x70], xmm8
00007981ddfda54a  vmovaps [rsp+0x80], xmm9
00007981ddfda553  vmovaps [rsp+0x90], xmm10
00007981ddfda55c  vmovaps [rsp+0xA0], xmm11
00007981ddfda565  vmovaps [rsp+0xB0], xmm12
00007981ddfda56e  vmovaps [rsp+0xC0], xmm13
00007981ddfda577  vmovaps [rsp+0xD0], xmm14
00007981ddfda580  vmovaps [rsp+0xE0], xmm15
00007981ddfda589  sub rsp, 0x30
00007981ddfda58d  movaps [rsp], xmm1
00007981ddfda591  movaps [rsp+0x10], xmm6
00007981ddfda596  movaps [rsp+0x20], xmm15
00007981ddfda59c  lea rdi, [rsp]
00007981ddfda5a0  mov esi, 0x00
00007981ddfda5a5  mov rax, 0x5782A6EB3530
00007981ddfda5af  call rax
00007981ddfda5b1  movaps xmm1, [rsp]
00007981ddfda5b5  add rsp, 0x30
00007981ddfda5b9  vmovaps xmm0, [rsp]
00007981ddfda5be  vmovaps xmm2, [rsp+0x10]
00007981ddfda5c4  vmovaps xmm3, [rsp+0x20]
00007981ddfda5ca  vmovaps xmm4, [rsp+0x30]
00007981ddfda5d0  vmovaps xmm5, [rsp+0x40]
00007981ddfda5d6  vmovaps xmm6, [rsp+0x50]
00007981ddfda5dc  vmovaps xmm7, [rsp+0x60]
00007981ddfda5e2  vmovaps xmm8, [rsp+0x70]
00007981ddfda5e8  vmovaps xmm9, [rsp+0x80]
00007981ddfda5f1  vmovaps xmm10, [rsp+0x90]
00007981ddfda5fa  vmovaps xmm11, [rsp+0xA0]
00007981ddfda603  vmovaps xmm12, [rsp+0xB0]
00007981ddfda60c  vmovaps xmm13, [rsp+0xC0]
00007981ddfda615  vmovaps xmm14, [rsp+0xD0]
00007981ddfda61e  vmovaps xmm15, [rsp+0xE0]
00007981ddfda627  add rsp, 0xF0
00007981ddfda62e  pop r11
00007981ddfda630  pop r10
00007981ddfda632  pop r9
00007981ddfda634  pop r8
00007981ddfda636  pop rsi
00007981ddfda637  pop rdi
00007981ddfda638  pop rdx
00007981ddfda639  pop rcx
00007981ddfda63a  pop rax
00007981ddfda63b  add rsp, 0x08
00007981ddfda63f  jmp 0x00007981DDFD8E48
00007981ddfda644  call 0x00007981DDEE5820
00007981ddfda649  jmp 0x00007981DDFD8E55
00007981ddfda64e  sub rsp, 0x08
00007981ddfda652  push rax
00007981ddfda653  push rcx
00007981ddfda654  push rdx
00007981ddfda655  push rdi
00007981ddfda656  push rsi
00007981ddfda657  push r8
00007981ddfda659  push r9
00007981ddfda65b  push r10
00007981ddfda65d  push r11
00007981ddfda65f  sub rsp, 0xF0
00007981ddfda666  vmovaps [rsp], xmm0
00007981ddfda66b  vmovaps [rsp+0x10], xmm1
00007981ddfda671  vmovaps [rsp+0x20], xmm2
00007981ddfda677  vmovaps [rsp+0x30], xmm3
00007981ddfda67d  vmovaps [rsp+0x40], xmm4
00007981ddfda683  vmovaps [rsp+0x50], xmm5
00007981ddfda689  vmovaps [rsp+0x60], xmm6
00007981ddfda68f  vmovaps [rsp+0x70], xmm7
00007981ddfda695  vmovaps [rsp+0x80], xmm8
00007981ddfda69e  vmovaps [rsp+0x90], xmm9
00007981ddfda6a7  vmovaps [rsp+0xA0], xmm10
00007981ddfda6b0  vmovaps [rsp+0xB0], xmm11
00007981ddfda6b9  vmovaps [rsp+0xC0], xmm12
00007981ddfda6c2  vmovaps [rsp+0xD0], xmm13
00007981ddfda6cb  vmovaps [rsp+0xE0], xmm15
00007981ddfda6d4  sub rsp, 0x30
00007981ddfda6d8  movaps [rsp], xmm14
00007981ddfda6dd  movaps [rsp+0x10], xmm4
00007981ddfda6e2  movaps [rsp+0x20], xmm3
00007981ddfda6e7  lea rdi, [rsp]
00007981ddfda6eb  mov esi, 0x00
00007981ddfda6f0  mov rax, 0x5782A6EB3530
00007981ddfda6fa  call rax
00007981ddfda6fc  movaps xmm14, [rsp]
00007981ddfda701  add rsp, 0x30
00007981ddfda705  vmovaps xmm0, [rsp]
00007981ddfda70a  vmovaps xmm1, [rsp+0x10]
00007981ddfda710  vmovaps xmm2, [rsp+0x20]
00007981ddfda716  vmovaps xmm3, [rsp+0x30]
00007981ddfda71c  vmovaps xmm4, [rsp+0x40]
00007981ddfda722  vmovaps xmm5, [rsp+0x50]
00007981ddfda728  vmovaps xmm6, [rsp+0x60]
00007981ddfda72e  vmovaps xmm7, [rsp+0x70]
00007981ddfda734  vmovaps xmm8, [rsp+0x80]
00007981ddfda73d  vmovaps xmm9, [rsp+0x90]
00007981ddfda746  vmovaps xmm10, [rsp+0xA0]
00007981ddfda74f  vmovaps xmm11, [rsp+0xB0]
00007981ddfda758  vmovaps xmm12, [rsp+0xC0]
00007981ddfda761  vmovaps xmm13, [rsp+0xD0]
00007981ddfda76a  vmovaps xmm15, [rsp+0xE0]
00007981ddfda773  add rsp, 0xF0
00007981ddfda77a  pop r11
00007981ddfda77c  pop r10
00007981ddfda77e  pop r9
00007981ddfda780  pop r8
00007981ddfda782  pop rsi
00007981ddfda783  pop rdi
00007981ddfda784  pop rdx
00007981ddfda785  pop rcx
00007981ddfda786  pop rax
00007981ddfda787  add rsp, 0x08
00007981ddfda78b  jmp 0x00007981DDFD8E6F
00007981ddfda790  sub rsp, 0x08
00007981ddfda794  push rax
00007981ddfda795  push rcx
00007981ddfda796  push rdx
00007981ddfda797  push rdi
00007981ddfda798  push rsi
00007981ddfda799  push r8
00007981ddfda79b  push r9
00007981ddfda79d  push r10
00007981ddfda79f  push r11
00007981ddfda7a1  sub rsp, 0xF0
00007981ddfda7a8  vmovaps [rsp], xmm0
00007981ddfda7ad  vmovaps [rsp+0x10], xmm1
00007981ddfda7b3  vmovaps [rsp+0x20], xmm2
00007981ddfda7b9  vmovaps [rsp+0x30], xmm3
00007981ddfda7bf  vmovaps [rsp+0x40], xmm4
00007981ddfda7c5  vmovaps [rsp+0x50], xmm5
00007981ddfda7cb  vmovaps [rsp+0x60], xmm7
00007981ddfda7d1  vmovaps [rsp+0x70], xmm8
00007981ddfda7d7  vmovaps [rsp+0x80], xmm9
00007981ddfda7e0  vmovaps [rsp+0x90], xmm10
00007981ddfda7e9  vmovaps [rsp+0xA0], xmm11
00007981ddfda7f2  vmovaps [rsp+0xB0], xmm12
00007981ddfda7fb  vmovaps [rsp+0xC0], xmm13
00007981ddfda804  vmovaps [rsp+0xD0], xmm14
00007981ddfda80d  vmovaps [rsp+0xE0], xmm15
00007981ddfda816  sub rsp, 0x30
00007981ddfda81a  movaps [rsp], xmm6
00007981ddfda81e  movaps [rsp+0x10], xmm9
00007981ddfda824  movaps [rsp+0x20], xmm7
00007981ddfda829  lea rdi, [rsp]
00007981ddfda82d  mov esi, 0x00
00007981ddfda832  mov rax, 0x5782A6EB3530
00007981ddfda83c  call rax
00007981ddfda83e  movaps xmm6, [rsp]
00007981ddfda842  add rsp, 0x30
00007981ddfda846  vmovaps xmm0, [rsp]
00007981ddfda84b  vmovaps xmm1, [rsp+0x10]
00007981ddfda851  vmovaps xmm2, [rsp+0x20]
00007981ddfda857  vmovaps xmm3, [rsp+0x30]
00007981ddfda85d  vmovaps xmm4, [rsp+0x40]
00007981ddfda863  vmovaps xmm5, [rsp+0x50]
00007981ddfda869  vmovaps xmm7, [rsp+0x60]
00007981ddfda86f  vmovaps xmm8, [rsp+0x70]
00007981ddfda875  vmovaps xmm9, [rsp+0x80]
00007981ddfda87e  vmovaps xmm10, [rsp+0x90]
00007981ddfda887  vmovaps xmm11, [rsp+0xA0]
00007981ddfda890  vmovaps xmm12, [rsp+0xB0]
00007981ddfda899  vmovaps xmm13, [rsp+0xC0]
00007981ddfda8a2  vmovaps xmm14, [rsp+0xD0]
00007981ddfda8ab  vmovaps xmm15, [rsp+0xE0]
00007981ddfda8b4  add rsp, 0xF0
00007981ddfda8bb  pop r11
00007981ddfda8bd  pop r10
00007981ddfda8bf  pop r9
00007981ddfda8c1  pop r8
00007981ddfda8c3  pop rsi
00007981ddfda8c4  pop rdi
00007981ddfda8c5  pop rdx
00007981ddfda8c6  pop rcx
00007981ddfda8c7  pop rax
00007981ddfda8c8  add rsp, 0x08
00007981ddfda8cc  jmp 0x00007981DDFD8E87
00007981ddfda8d1  sub rsp, 0x08
00007981ddfda8d5  push rax
00007981ddfda8d6  push rcx
00007981ddfda8d7  push rdx
00007981ddfda8d8  push rdi
00007981ddfda8d9  push rsi
00007981ddfda8da  push r8
00007981ddfda8dc  push r9
00007981ddfda8de  push r10
00007981ddfda8e0  push r11
00007981ddfda8e2  sub rsp, 0xF0
00007981ddfda8e9  vmovaps [rsp], xmm0
00007981ddfda8ee  vmovaps [rsp+0x10], xmm1
00007981ddfda8f4  vmovaps [rsp+0x20], xmm2
00007981ddfda8fa  vmovaps [rsp+0x30], xmm3
00007981ddfda900  vmovaps [rsp+0x40], xmm4
00007981ddfda906  vmovaps [rsp+0x50], xmm5
00007981ddfda90c  vmovaps [rsp+0x60], xmm6
00007981ddfda912  vmovaps [rsp+0x70], xmm8
00007981ddfda918  vmovaps [rsp+0x80], xmm9
00007981ddfda921  vmovaps [rsp+0x90], xmm10
00007981ddfda92a  vmovaps [rsp+0xA0], xmm11
00007981ddfda933  vmovaps [rsp+0xB0], xmm12
00007981ddfda93c  vmovaps [rsp+0xC0], xmm13
00007981ddfda945  vmovaps [rsp+0xD0], xmm14
00007981ddfda94e  vmovaps [rsp+0xE0], xmm15
00007981ddfda957  sub rsp, 0x30
00007981ddfda95b  movaps [rsp], xmm7
00007981ddfda95f  movaps [rsp+0x10], xmm4
00007981ddfda964  movaps [rsp+0x20], xmm9
00007981ddfda96a  lea rdi, [rsp]
00007981ddfda96e  mov esi, 0x00
00007981ddfda973  mov rax, 0x5782A6EB3530
00007981ddfda97d  call rax
00007981ddfda97f  movaps xmm7, [rsp]
00007981ddfda983  add rsp, 0x30
00007981ddfda987  vmovaps xmm0, [rsp]
00007981ddfda98c  vmovaps xmm1, [rsp+0x10]
00007981ddfda992  vmovaps xmm2, [rsp+0x20]
00007981ddfda998  vmovaps xmm3, [rsp+0x30]
00007981ddfda99e  vmovaps xmm4, [rsp+0x40]
00007981ddfda9a4  vmovaps xmm5, [rsp+0x50]
00007981ddfda9aa  vmovaps xmm6, [rsp+0x60]
00007981ddfda9b0  vmovaps xmm8, [rsp+0x70]
00007981ddfda9b6  vmovaps xmm9, [rsp+0x80]
00007981ddfda9bf  vmovaps xmm10, [rsp+0x90]
00007981ddfda9c8  vmovaps xmm11, [rsp+0xA0]
00007981ddfda9d1  vmovaps xmm12, [rsp+0xB0]
00007981ddfda9da  vmovaps xmm13, [rsp+0xC0]
00007981ddfda9e3  vmovaps xmm14, [rsp+0xD0]
00007981ddfda9ec  vmovaps xmm15, [rsp+0xE0]
00007981ddfda9f5  add rsp, 0xF0
00007981ddfda9fc  pop r11
00007981ddfda9fe  pop r10
00007981ddfdaa00  pop r9
00007981ddfdaa02  pop r8
00007981ddfdaa04  pop rsi
00007981ddfdaa05  pop rdi
00007981ddfdaa06  pop rdx
00007981ddfdaa07  pop rcx
00007981ddfdaa08  pop rax
00007981ddfdaa09  add rsp, 0x08
00007981ddfdaa0d  jmp 0x00007981DDFD8EB4
00007981ddfdaa12  sub rsp, 0x08
00007981ddfdaa16  push rax
00007981ddfdaa17  push rcx
00007981ddfdaa18  push rdx
00007981ddfdaa19  push rdi
00007981ddfdaa1a  push rsi
00007981ddfdaa1b  push r8
00007981ddfdaa1d  push r9
00007981ddfdaa1f  push r10
00007981ddfdaa21  push r11
00007981ddfdaa23  sub rsp, 0xF0
00007981ddfdaa2a  vmovaps [rsp], xmm0
00007981ddfdaa2f  vmovaps [rsp+0x10], xmm1
00007981ddfdaa35  vmovaps [rsp+0x20], xmm2
00007981ddfdaa3b  vmovaps [rsp+0x30], xmm3
00007981ddfdaa41  vmovaps [rsp+0x40], xmm5
00007981ddfdaa47  vmovaps [rsp+0x50], xmm6
00007981ddfdaa4d  vmovaps [rsp+0x60], xmm7
00007981ddfdaa53  vmovaps [rsp+0x70], xmm8
00007981ddfdaa59  vmovaps [rsp+0x80], xmm9
00007981ddfdaa62  vmovaps [rsp+0x90], xmm10
00007981ddfdaa6b  vmovaps [rsp+0xA0], xmm11
00007981ddfdaa74  vmovaps [rsp+0xB0], xmm12
00007981ddfdaa7d  vmovaps [rsp+0xC0], xmm13
00007981ddfdaa86  vmovaps [rsp+0xD0], xmm14
00007981ddfdaa8f  vmovaps [rsp+0xE0], xmm15
00007981ddfdaa98  sub rsp, 0x30
00007981ddfdaa9c  movaps [rsp], xmm4
00007981ddfdaaa0  movaps [rsp+0x10], xmm15
00007981ddfdaaa6  movaps [rsp+0x20], xmm9
00007981ddfdaaac  lea rdi, [rsp]
00007981ddfdaab0  mov esi, 0x00
00007981ddfdaab5  mov rax, 0x5782A6EB3530
00007981ddfdaabf  call rax
00007981ddfdaac1  movaps xmm4, [rsp]
00007981ddfdaac5  add rsp, 0x30
00007981ddfdaac9  vmovaps xmm0, [rsp]
00007981ddfdaace  vmovaps xmm1, [rsp+0x10]
00007981ddfdaad4  vmovaps xmm2, [rsp+0x20]
00007981ddfdaada  vmovaps xmm3, [rsp+0x30]
00007981ddfdaae0  vmovaps xmm5, [rsp+0x40]
00007981ddfdaae6  vmovaps xmm6, [rsp+0x50]
00007981ddfdaaec  vmovaps xmm7, [rsp+0x60]
00007981ddfdaaf2  vmovaps xmm8, [rsp+0x70]
00007981ddfdaaf8  vmovaps xmm9, [rsp+0x80]
00007981ddfdab01  vmovaps xmm10, [rsp+0x90]
00007981ddfdab0a  vmovaps xmm11, [rsp+0xA0]
00007981ddfdab13  vmovaps xmm12, [rsp+0xB0]
00007981ddfdab1c  vmovaps xmm13, [rsp+0xC0]
00007981ddfdab25  vmovaps xmm14, [rsp+0xD0]
00007981ddfdab2e  vmovaps xmm15, [rsp+0xE0]
00007981ddfdab37  add rsp, 0xF0
00007981ddfdab3e  pop r11
00007981ddfdab40  pop r10
00007981ddfdab42  pop r9
00007981ddfdab44  pop r8
00007981ddfdab46  pop rsi
00007981ddfdab47  pop rdi
00007981ddfdab48  pop rdx
00007981ddfdab49  pop rcx
00007981ddfdab4a  pop rax
00007981ddfdab4b  add rsp, 0x08
00007981ddfdab4f  jmp 0x00007981DDFD8ED9
00007981ddfdab54  call 0x00007981DDEE5820
00007981ddfdab59  jmp 0x00007981DDFD8EE6
00007981ddfdab5e  sub rsp, 0x08
00007981ddfdab62  push rax
00007981ddfdab63  push rcx
00007981ddfdab64  push rdx
00007981ddfdab65  push rdi
00007981ddfdab66  push rsi
00007981ddfdab67  push r8
00007981ddfdab69  push r9
00007981ddfdab6b  push r10
00007981ddfdab6d  push r11
00007981ddfdab6f  sub rsp, 0xF0
00007981ddfdab76  vmovaps [rsp], xmm0
00007981ddfdab7b  vmovaps [rsp+0x10], xmm1
00007981ddfdab81  vmovaps [rsp+0x20], xmm2
00007981ddfdab87  vmovaps [rsp+0x30], xmm4
00007981ddfdab8d  vmovaps [rsp+0x40], xmm5
00007981ddfdab93  vmovaps [rsp+0x50], xmm6
00007981ddfdab99  vmovaps [rsp+0x60], xmm7
00007981ddfdab9f  vmovaps [rsp+0x70], xmm8
00007981ddfdaba5  vmovaps [rsp+0x80], xmm9
00007981ddfdabae  vmovaps [rsp+0x90], xmm10
00007981ddfdabb7  vmovaps [rsp+0xA0], xmm11
00007981ddfdabc0  vmovaps [rsp+0xB0], xmm12
00007981ddfdabc9  vmovaps [rsp+0xC0], xmm13
00007981ddfdabd2  vmovaps [rsp+0xD0], xmm14
00007981ddfdabdb  vmovaps [rsp+0xE0], xmm15
00007981ddfdabe4  sub rsp, 0x30
00007981ddfdabe8  movaps [rsp], xmm3
00007981ddfdabec  movaps [rsp+0x10], xmm1
00007981ddfdabf1  movaps [rsp+0x20], xmm9
00007981ddfdabf7  lea rdi, [rsp]
00007981ddfdabfb  mov esi, 0x00
00007981ddfdac00  mov rax, 0x5782A6EB3530
00007981ddfdac0a  call rax
00007981ddfdac0c  movaps xmm3, [rsp]
00007981ddfdac10  add rsp, 0x30
00007981ddfdac14  vmovaps xmm0, [rsp]
00007981ddfdac19  vmovaps xmm1, [rsp+0x10]
00007981ddfdac1f  vmovaps xmm2, [rsp+0x20]
00007981ddfdac25  vmovaps xmm4, [rsp+0x30]
00007981ddfdac2b  vmovaps xmm5, [rsp+0x40]
00007981ddfdac31  vmovaps xmm6, [rsp+0x50]
00007981ddfdac37  vmovaps xmm7, [rsp+0x60]
00007981ddfdac3d  vmovaps xmm8, [rsp+0x70]
00007981ddfdac43  vmovaps xmm9, [rsp+0x80]
00007981ddfdac4c  vmovaps xmm10, [rsp+0x90]
00007981ddfdac55  vmovaps xmm11, [rsp+0xA0]
00007981ddfdac5e  vmovaps xmm12, [rsp+0xB0]
00007981ddfdac67  vmovaps xmm13, [rsp+0xC0]
00007981ddfdac70  vmovaps xmm14, [rsp+0xD0]
00007981ddfdac79  vmovaps xmm15, [rsp+0xE0]
00007981ddfdac82  add rsp, 0xF0
00007981ddfdac89  pop r11
00007981ddfdac8b  pop r10
00007981ddfdac8d  pop r9
00007981ddfdac8f  pop r8
00007981ddfdac91  pop rsi
00007981ddfdac92  pop rdi
00007981ddfdac93  pop rdx
00007981ddfdac94  pop rcx
00007981ddfdac95  pop rax
00007981ddfdac96  add rsp, 0x08
00007981ddfdac9a  jmp 0x00007981DDFD8F23
00007981ddfdac9f  sub rsp, 0x08
00007981ddfdaca3  push rax
00007981ddfdaca4  push rcx
00007981ddfdaca5  push rdx
00007981ddfdaca6  push rdi
00007981ddfdaca7  push rsi
00007981ddfdaca8  push r8
00007981ddfdacaa  push r9
00007981ddfdacac  push r10
00007981ddfdacae  push r11
00007981ddfdacb0  sub rsp, 0xF0
00007981ddfdacb7  vmovaps [rsp], xmm0
00007981ddfdacbc  vmovaps [rsp+0x10], xmm2
00007981ddfdacc2  vmovaps [rsp+0x20], xmm3
00007981ddfdacc8  vmovaps [rsp+0x30], xmm4
00007981ddfdacce  vmovaps [rsp+0x40], xmm5
00007981ddfdacd4  vmovaps [rsp+0x50], xmm6
00007981ddfdacda  vmovaps [rsp+0x60], xmm7
00007981ddfdace0  vmovaps [rsp+0x70], xmm8
00007981ddfdace6  vmovaps [rsp+0x80], xmm9
00007981ddfdacef  vmovaps [rsp+0x90], xmm10
00007981ddfdacf8  vmovaps [rsp+0xA0], xmm11
00007981ddfdad01  vmovaps [rsp+0xB0], xmm12
00007981ddfdad0a  vmovaps [rsp+0xC0], xmm13
00007981ddfdad13  vmovaps [rsp+0xD0], xmm14
00007981ddfdad1c  vmovaps [rsp+0xE0], xmm15
00007981ddfdad25  sub rsp, 0x30
00007981ddfdad29  movaps [rsp], xmm1
00007981ddfdad2d  movaps [rsp+0x10], xmm15
00007981ddfdad33  movaps [rsp+0x20], xmm9
00007981ddfdad39  lea rdi, [rsp]
00007981ddfdad3d  mov esi, 0x00
00007981ddfdad42  mov rax, 0x5782A6EB3530
00007981ddfdad4c  call rax
00007981ddfdad4e  movaps xmm1, [rsp]
00007981ddfdad52  add rsp, 0x30
00007981ddfdad56  vmovaps xmm0, [rsp]
00007981ddfdad5b  vmovaps xmm2, [rsp+0x10]
00007981ddfdad61  vmovaps xmm3, [rsp+0x20]
00007981ddfdad67  vmovaps xmm4, [rsp+0x30]
00007981ddfdad6d  vmovaps xmm5, [rsp+0x40]
00007981ddfdad73  vmovaps xmm6, [rsp+0x50]
00007981ddfdad79  vmovaps xmm7, [rsp+0x60]
00007981ddfdad7f  vmovaps xmm8, [rsp+0x70]
00007981ddfdad85  vmovaps xmm9, [rsp+0x80]
00007981ddfdad8e  vmovaps xmm10, [rsp+0x90]
00007981ddfdad97  vmovaps xmm11, [rsp+0xA0]
00007981ddfdada0  vmovaps xmm12, [rsp+0xB0]
00007981ddfdada9  vmovaps xmm13, [rsp+0xC0]
00007981ddfdadb2  vmovaps xmm14, [rsp+0xD0]
00007981ddfdadbb  vmovaps xmm15, [rsp+0xE0]
00007981ddfdadc4  add rsp, 0xF0
00007981ddfdadcb  pop r11
00007981ddfdadcd  pop r10
00007981ddfdadcf  pop r9
00007981ddfdadd1  pop r8
00007981ddfdadd3  pop rsi
00007981ddfdadd4  pop rdi
00007981ddfdadd5  pop rdx
00007981ddfdadd6  pop rcx
00007981ddfdadd7  pop rax
00007981ddfdadd8  add rsp, 0x08
00007981ddfdaddc  jmp 0x00007981DDFD8FAB
00007981ddfdade1  call 0x00007981DDEE5820
00007981ddfdade6  jmp 0x00007981DDFD8FB8
00007981ddfdadeb  sub rsp, 0x08
00007981ddfdadef  push rax
00007981ddfdadf0  push rcx
00007981ddfdadf1  push rdx
00007981ddfdadf2  push rdi
00007981ddfdadf3  push rsi
00007981ddfdadf4  push r8
00007981ddfdadf6  push r9
00007981ddfdadf8  push r10
00007981ddfdadfa  push r11
00007981ddfdadfc  sub rsp, 0xF0
00007981ddfdae03  vmovaps [rsp], xmm0
00007981ddfdae08  vmovaps [rsp+0x10], xmm2
00007981ddfdae0e  vmovaps [rsp+0x20], xmm3
00007981ddfdae14  vmovaps [rsp+0x30], xmm4
00007981ddfdae1a  vmovaps [rsp+0x40], xmm5
00007981ddfdae20  vmovaps [rsp+0x50], xmm6
00007981ddfdae26  vmovaps [rsp+0x60], xmm7
00007981ddfdae2c  vmovaps [rsp+0x70], xmm8
00007981ddfdae32  vmovaps [rsp+0x80], xmm9
00007981ddfdae3b  vmovaps [rsp+0x90], xmm10
00007981ddfdae44  vmovaps [rsp+0xA0], xmm11
00007981ddfdae4d  vmovaps [rsp+0xB0], xmm12
00007981ddfdae56  vmovaps [rsp+0xC0], xmm13
00007981ddfdae5f  vmovaps [rsp+0xD0], xmm14
00007981ddfdae68  vmovaps [rsp+0xE0], xmm15
00007981ddfdae71  sub rsp, 0x30
00007981ddfdae75  movaps [rsp], xmm1
00007981ddfdae79  movaps [rsp+0x10], xmm5
00007981ddfdae7e  movaps [rsp+0x20], xmm7
00007981ddfdae83  lea rdi, [rsp]
00007981ddfdae87  mov esi, 0x00
00007981ddfdae8c  mov rax, 0x5782A6EB3530
00007981ddfdae96  call rax
00007981ddfdae98  movaps xmm1, [rsp]
00007981ddfdae9c  add rsp, 0x30
00007981ddfdaea0  vmovaps xmm0, [rsp]
00007981ddfdaea5  vmovaps xmm2, [rsp+0x10]
00007981ddfdaeab  vmovaps xmm3, [rsp+0x20]
00007981ddfdaeb1  vmovaps xmm4, [rsp+0x30]
00007981ddfdaeb7  vmovaps xmm5, [rsp+0x40]
00007981ddfdaebd  vmovaps xmm6, [rsp+0x50]
00007981ddfdaec3  vmovaps xmm7, [rsp+0x60]
00007981ddfdaec9  vmovaps xmm8, [rsp+0x70]
00007981ddfdaecf  vmovaps xmm9, [rsp+0x80]
00007981ddfdaed8  vmovaps xmm10, [rsp+0x90]
00007981ddfdaee1  vmovaps xmm11, [rsp+0xA0]
00007981ddfdaeea  vmovaps xmm12, [rsp+0xB0]
00007981ddfdaef3  vmovaps xmm13, [rsp+0xC0]
00007981ddfdaefc  vmovaps xmm14, [rsp+0xD0]
00007981ddfdaf05  vmovaps xmm15, [rsp+0xE0]
00007981ddfdaf0e  add rsp, 0xF0
00007981ddfdaf15  pop r11
00007981ddfdaf17  pop r10
00007981ddfdaf19  pop r9
00007981ddfdaf1b  pop r8
00007981ddfdaf1d  pop rsi
00007981ddfdaf1e  pop rdi
00007981ddfdaf1f  pop rdx
00007981ddfdaf20  pop rcx
00007981ddfdaf21  pop rax
00007981ddfdaf22  add rsp, 0x08
00007981ddfdaf26  jmp 0x00007981DDFD905D
00007981ddfdaf2b  sub rsp, 0x08
00007981ddfdaf2f  push rax
00007981ddfdaf30  push rcx
00007981ddfdaf31  push rdx
00007981ddfdaf32  push rdi
00007981ddfdaf33  push rsi
00007981ddfdaf34  push r8
00007981ddfdaf36  push r9
00007981ddfdaf38  push r10
00007981ddfdaf3a  push r11
00007981ddfdaf3c  sub rsp, 0xF0
00007981ddfdaf43  vmovaps [rsp], xmm0
00007981ddfdaf48  vmovaps [rsp+0x10], xmm1
00007981ddfdaf4e  vmovaps [rsp+0x20], xmm2
00007981ddfdaf54  vmovaps [rsp+0x30], xmm3
00007981ddfdaf5a  vmovaps [rsp+0x40], xmm4
00007981ddfdaf60  vmovaps [rsp+0x50], xmm5
00007981ddfdaf66  vmovaps [rsp+0x60], xmm6
00007981ddfdaf6c  vmovaps [rsp+0x70], xmm8
00007981ddfdaf72  vmovaps [rsp+0x80], xmm9
00007981ddfdaf7b  vmovaps [rsp+0x90], xmm10
00007981ddfdaf84  vmovaps [rsp+0xA0], xmm11
00007981ddfdaf8d  vmovaps [rsp+0xB0], xmm12
00007981ddfdaf96  vmovaps [rsp+0xC0], xmm13
00007981ddfdaf9f  vmovaps [rsp+0xD0], xmm14
00007981ddfdafa8  vmovaps [rsp+0xE0], xmm15
00007981ddfdafb1  sub rsp, 0x30
00007981ddfdafb5  movaps [rsp], xmm7
00007981ddfdafb9  movaps [rsp+0x10], xmm5
00007981ddfdafbe  movaps [rsp+0x20], xmm15
00007981ddfdafc4  lea rdi, [rsp]
00007981ddfdafc8  mov esi, 0x00
00007981ddfdafcd  mov rax, 0x5782A6EB3530
00007981ddfdafd7  call rax
00007981ddfdafd9  movaps xmm7, [rsp]
00007981ddfdafdd  add rsp, 0x30
00007981ddfdafe1  vmovaps xmm0, [rsp]
00007981ddfdafe6  vmovaps xmm1, [rsp+0x10]
00007981ddfdafec  vmovaps xmm2, [rsp+0x20]
00007981ddfdaff2  vmovaps xmm3, [rsp+0x30]
00007981ddfdaff8  vmovaps xmm4, [rsp+0x40]
00007981ddfdaffe  vmovaps xmm5, [rsp+0x50]
00007981ddfdb004  vmovaps xmm6, [rsp+0x60]
00007981ddfdb00a  vmovaps xmm8, [rsp+0x70]
00007981ddfdb010  vmovaps xmm9, [rsp+0x80]
00007981ddfdb019  vmovaps xmm10, [rsp+0x90]
00007981ddfdb022  vmovaps xmm11, [rsp+0xA0]
00007981ddfdb02b  vmovaps xmm12, [rsp+0xB0]
00007981ddfdb034  vmovaps xmm13, [rsp+0xC0]
00007981ddfdb03d  vmovaps xmm14, [rsp+0xD0]
00007981ddfdb046  vmovaps xmm15, [rsp+0xE0]
00007981ddfdb04f  add rsp, 0xF0
00007981ddfdb056  pop r11
00007981ddfdb058  pop r10
00007981ddfdb05a  pop r9
00007981ddfdb05c  pop r8
00007981ddfdb05e  pop rsi
00007981ddfdb05f  pop rdi
00007981ddfdb060  pop rdx
00007981ddfdb061  pop rcx
00007981ddfdb062  pop rax
00007981ddfdb063  add rsp, 0x08
00007981ddfdb067  jmp 0x00007981DDFD9093
00007981ddfdb06c  call 0x00007981DDED64F0
00007981ddfdb071  jmp 0x00007981DDFD90A0
00007981ddfdb076  sub rsp, 0x08
00007981ddfdb07a  push rax
00007981ddfdb07b  push rcx
00007981ddfdb07c  push rdx
00007981ddfdb07d  push rdi
00007981ddfdb07e  push rsi
00007981ddfdb07f  push r8
00007981ddfdb081  push r9
00007981ddfdb083  push r10
00007981ddfdb085  push r11
00007981ddfdb087  sub rsp, 0xF0
00007981ddfdb08e  vmovaps [rsp], xmm0
00007981ddfdb093  vmovaps [rsp+0x10], xmm1
00007981ddfdb099  vmovaps [rsp+0x20], xmm2
00007981ddfdb09f  vmovaps [rsp+0x30], xmm3
00007981ddfdb0a5  vmovaps [rsp+0x40], xmm4
00007981ddfdb0ab  vmovaps [rsp+0x50], xmm5
00007981ddfdb0b1  vmovaps [rsp+0x60], xmm6
00007981ddfdb0b7  vmovaps [rsp+0x70], xmm7
00007981ddfdb0bd  vmovaps [rsp+0x80], xmm8
00007981ddfdb0c6  vmovaps [rsp+0x90], xmm9
00007981ddfdb0cf  vmovaps [rsp+0xA0], xmm10
00007981ddfdb0d8  vmovaps [rsp+0xB0], xmm11
00007981ddfdb0e1  vmovaps [rsp+0xC0], xmm12
00007981ddfdb0ea  vmovaps [rsp+0xD0], xmm13
00007981ddfdb0f3  vmovaps [rsp+0xE0], xmm14
00007981ddfdb0fc  sub rsp, 0x30
00007981ddfdb100  movaps [rsp], xmm15
00007981ddfdb105  movaps [rsp+0x10], xmm5
00007981ddfdb10a  movaps [rsp+0x20], xmm3
00007981ddfdb10f  lea rdi, [rsp]
00007981ddfdb113  mov esi, 0x00
00007981ddfdb118  mov rax, 0x5782A6EB3530
00007981ddfdb122  call rax
00007981ddfdb124  movaps xmm15, [rsp]
00007981ddfdb129  add rsp, 0x30
00007981ddfdb12d  vmovaps xmm0, [rsp]
00007981ddfdb132  vmovaps xmm1, [rsp+0x10]
00007981ddfdb138  vmovaps xmm2, [rsp+0x20]
00007981ddfdb13e  vmovaps xmm3, [rsp+0x30]
00007981ddfdb144  vmovaps xmm4, [rsp+0x40]
00007981ddfdb14a  vmovaps xmm5, [rsp+0x50]
00007981ddfdb150  vmovaps xmm6, [rsp+0x60]
00007981ddfdb156  vmovaps xmm7, [rsp+0x70]
00007981ddfdb15c  vmovaps xmm8, [rsp+0x80]
00007981ddfdb165  vmovaps xmm9, [rsp+0x90]
00007981ddfdb16e  vmovaps xmm10, [rsp+0xA0]
00007981ddfdb177  vmovaps xmm11, [rsp+0xB0]
00007981ddfdb180  vmovaps xmm12, [rsp+0xC0]
00007981ddfdb189  vmovaps xmm13, [rsp+0xD0]
00007981ddfdb192  vmovaps xmm14, [rsp+0xE0]
00007981ddfdb19b  add rsp, 0xF0
00007981ddfdb1a2  pop r11
00007981ddfdb1a4  pop r10
00007981ddfdb1a6  pop r9
00007981ddfdb1a8  pop r8
00007981ddfdb1aa  pop rsi
00007981ddfdb1ab  pop rdi
00007981ddfdb1ac  pop rdx
00007981ddfdb1ad  pop rcx
00007981ddfdb1ae  pop rax
00007981ddfdb1af  add rsp, 0x08
00007981ddfdb1b3  jmp 0x00007981DDFD90C6
00007981ddfdb1b8  sub rsp, 0x08
00007981ddfdb1bc  push rax
00007981ddfdb1bd  push rcx
00007981ddfdb1be  push rdx
00007981ddfdb1bf  push rdi
00007981ddfdb1c0  push rsi
00007981ddfdb1c1  push r8
00007981ddfdb1c3  push r9
00007981ddfdb1c5  push r10
00007981ddfdb1c7  push r11
00007981ddfdb1c9  sub rsp, 0xF0
00007981ddfdb1d0  vmovaps [rsp], xmm0
00007981ddfdb1d5  vmovaps [rsp+0x10], xmm2
00007981ddfdb1db  vmovaps [rsp+0x20], xmm3
00007981ddfdb1e1  vmovaps [rsp+0x30], xmm4
00007981ddfdb1e7  vmovaps [rsp+0x40], xmm5
00007981ddfdb1ed  vmovaps [rsp+0x50], xmm6
00007981ddfdb1f3  vmovaps [rsp+0x60], xmm7
00007981ddfdb1f9  vmovaps [rsp+0x70], xmm8
00007981ddfdb1ff  vmovaps [rsp+0x80], xmm9
00007981ddfdb208  vmovaps [rsp+0x90], xmm10
00007981ddfdb211  vmovaps [rsp+0xA0], xmm11
00007981ddfdb21a  vmovaps [rsp+0xB0], xmm12
00007981ddfdb223  vmovaps [rsp+0xC0], xmm13
00007981ddfdb22c  vmovaps [rsp+0xD0], xmm14
00007981ddfdb235  vmovaps [rsp+0xE0], xmm15
00007981ddfdb23e  sub rsp, 0x30
00007981ddfdb242  movaps [rsp], xmm1
00007981ddfdb246  movaps [rsp+0x10], xmm5
00007981ddfdb24b  movaps [rsp+0x20], xmm4
00007981ddfdb250  lea rdi, [rsp]
00007981ddfdb254  mov esi, 0x00
00007981ddfdb259  mov rax, 0x5782A6EB3530
00007981ddfdb263  call rax
00007981ddfdb265  movaps xmm1, [rsp]
00007981ddfdb269  add rsp, 0x30
00007981ddfdb26d  vmovaps xmm0, [rsp]
00007981ddfdb272  vmovaps xmm2, [rsp+0x10]
00007981ddfdb278  vmovaps xmm3, [rsp+0x20]
00007981ddfdb27e  vmovaps xmm4, [rsp+0x30]
00007981ddfdb284  vmovaps xmm5, [rsp+0x40]
00007981ddfdb28a  vmovaps xmm6, [rsp+0x50]
00007981ddfdb290  vmovaps xmm7, [rsp+0x60]
00007981ddfdb296  vmovaps xmm8, [rsp+0x70]
00007981ddfdb29c  vmovaps xmm9, [rsp+0x80]
00007981ddfdb2a5  vmovaps xmm10, [rsp+0x90]
00007981ddfdb2ae  vmovaps xmm11, [rsp+0xA0]
00007981ddfdb2b7  vmovaps xmm12, [rsp+0xB0]
00007981ddfdb2c0  vmovaps xmm13, [rsp+0xC0]
00007981ddfdb2c9  vmovaps xmm14, [rsp+0xD0]
00007981ddfdb2d2  vmovaps xmm15, [rsp+0xE0]
00007981ddfdb2db  add rsp, 0xF0
00007981ddfdb2e2  pop r11
00007981ddfdb2e4  pop r10
00007981ddfdb2e6  pop r9
00007981ddfdb2e8  pop r8
00007981ddfdb2ea  pop rsi
00007981ddfdb2eb  pop rdi
00007981ddfdb2ec  pop rdx
00007981ddfdb2ed  pop rcx
00007981ddfdb2ee  pop rax
00007981ddfdb2ef  add rsp, 0x08
00007981ddfdb2f3  jmp 0x00007981DDFD90E6
00007981ddfdb2f8  sub rsp, 0x08
00007981ddfdb2fc  push rax
00007981ddfdb2fd  push rcx
00007981ddfdb2fe  push rdx
00007981ddfdb2ff  push rdi
00007981ddfdb300  push rsi
00007981ddfdb301  push r8
00007981ddfdb303  push r9
00007981ddfdb305  push r10
00007981ddfdb307  push r11
00007981ddfdb309  sub rsp, 0xF0
00007981ddfdb310  vmovaps [rsp], xmm0
00007981ddfdb315  vmovaps [rsp+0x10], xmm1
00007981ddfdb31b  vmovaps [rsp+0x20], xmm2
00007981ddfdb321  vmovaps [rsp+0x30], xmm3
00007981ddfdb327  vmovaps [rsp+0x40], xmm5
00007981ddfdb32d  vmovaps [rsp+0x50], xmm6
00007981ddfdb333  vmovaps [rsp+0x60], xmm7
00007981ddfdb339  vmovaps [rsp+0x70], xmm8
00007981ddfdb33f  vmovaps [rsp+0x80], xmm9
00007981ddfdb348  vmovaps [rsp+0x90], xmm10
00007981ddfdb351  vmovaps [rsp+0xA0], xmm11
00007981ddfdb35a  vmovaps [rsp+0xB0], xmm12
00007981ddfdb363  vmovaps [rsp+0xC0], xmm13
00007981ddfdb36c  vmovaps [rsp+0xD0], xmm14
00007981ddfdb375  vmovaps [rsp+0xE0], xmm15
00007981ddfdb37e  sub rsp, 0x30
00007981ddfdb382  movaps [rsp], xmm4
00007981ddfdb386  movaps [rsp+0x10], xmm3
00007981ddfdb38b  movaps [rsp+0x20], xmm5
00007981ddfdb390  lea rdi, [rsp]
00007981ddfdb394  mov esi, 0x00
00007981ddfdb399  mov rax, 0x5782A6EB3530
00007981ddfdb3a3  call rax
00007981ddfdb3a5  movaps xmm4, [rsp]
00007981ddfdb3a9  add rsp, 0x30
00007981ddfdb3ad  vmovaps xmm0, [rsp]
00007981ddfdb3b2  vmovaps xmm1, [rsp+0x10]
00007981ddfdb3b8  vmovaps xmm2, [rsp+0x20]
00007981ddfdb3be  vmovaps xmm3, [rsp+0x30]
00007981ddfdb3c4  vmovaps xmm5, [rsp+0x40]
00007981ddfdb3ca  vmovaps xmm6, [rsp+0x50]
00007981ddfdb3d0  vmovaps xmm7, [rsp+0x60]
00007981ddfdb3d6  vmovaps xmm8, [rsp+0x70]
00007981ddfdb3dc  vmovaps xmm9, [rsp+0x80]
00007981ddfdb3e5  vmovaps xmm10, [rsp+0x90]
00007981ddfdb3ee  vmovaps xmm11, [rsp+0xA0]
00007981ddfdb3f7  vmovaps xmm12, [rsp+0xB0]
00007981ddfdb400  vmovaps xmm13, [rsp+0xC0]
00007981ddfdb409  vmovaps xmm14, [rsp+0xD0]
00007981ddfdb412  vmovaps xmm15, [rsp+0xE0]
00007981ddfdb41b  add rsp, 0xF0
00007981ddfdb422  pop r11
00007981ddfdb424  pop r10
00007981ddfdb426  pop r9
00007981ddfdb428  pop r8
00007981ddfdb42a  pop rsi
00007981ddfdb42b  pop rdi
00007981ddfdb42c  pop rdx
00007981ddfdb42d  pop rcx
00007981ddfdb42e  pop rax
00007981ddfdb42f  add rsp, 0x08
00007981ddfdb433  jmp 0x00007981DDFD9134
00007981ddfdb438  call 0x00007981DDED64F0
00007981ddfdb43d  jmp 0x00007981DDFD9141
00007981ddfdb442  sub rsp, 0x08
00007981ddfdb446  push rax
00007981ddfdb447  push rcx
00007981ddfdb448  push rdx
00007981ddfdb449  push rdi
00007981ddfdb44a  push rsi
00007981ddfdb44b  push r8
00007981ddfdb44d  push r9
00007981ddfdb44f  push r10
00007981ddfdb451  push r11
00007981ddfdb453  sub rsp, 0xF0
00007981ddfdb45a  vmovaps [rsp], xmm0
00007981ddfdb45f  vmovaps [rsp+0x10], xmm1
00007981ddfdb465  vmovaps [rsp+0x20], xmm2
00007981ddfdb46b  vmovaps [rsp+0x30], xmm3
00007981ddfdb471  vmovaps [rsp+0x40], xmm4
00007981ddfdb477  vmovaps [rsp+0x50], xmm6
00007981ddfdb47d  vmovaps [rsp+0x60], xmm7
00007981ddfdb483  vmovaps [rsp+0x70], xmm8
00007981ddfdb489  vmovaps [rsp+0x80], xmm9
00007981ddfdb492  vmovaps [rsp+0x90], xmm10
00007981ddfdb49b  vmovaps [rsp+0xA0], xmm11
00007981ddfdb4a4  vmovaps [rsp+0xB0], xmm12
00007981ddfdb4ad  vmovaps [rsp+0xC0], xmm13
00007981ddfdb4b6  vmovaps [rsp+0xD0], xmm14
00007981ddfdb4bf  vmovaps [rsp+0xE0], xmm15
00007981ddfdb4c8  sub rsp, 0x30
00007981ddfdb4cc  movaps [rsp], xmm5
00007981ddfdb4d0  movaps [rsp+0x10], xmm6
00007981ddfdb4d5  movaps [rsp+0x20], xmm3
00007981ddfdb4da  lea rdi, [rsp]
00007981ddfdb4de  mov esi, 0x00
00007981ddfdb4e3  mov rax, 0x5782A6EB3530
00007981ddfdb4ed  call rax
00007981ddfdb4ef  movaps xmm5, [rsp]
00007981ddfdb4f3  add rsp, 0x30
00007981ddfdb4f7  vmovaps xmm0, [rsp]
00007981ddfdb4fc  vmovaps xmm1, [rsp+0x10]
00007981ddfdb502  vmovaps xmm2, [rsp+0x20]
00007981ddfdb508  vmovaps xmm3, [rsp+0x30]
00007981ddfdb50e  vmovaps xmm4, [rsp+0x40]
00007981ddfdb514  vmovaps xmm6, [rsp+0x50]
00007981ddfdb51a  vmovaps xmm7, [rsp+0x60]
00007981ddfdb520  vmovaps xmm8, [rsp+0x70]
00007981ddfdb526  vmovaps xmm9, [rsp+0x80]
00007981ddfdb52f  vmovaps xmm10, [rsp+0x90]
00007981ddfdb538  vmovaps xmm11, [rsp+0xA0]
00007981ddfdb541  vmovaps xmm12, [rsp+0xB0]
00007981ddfdb54a  vmovaps xmm13, [rsp+0xC0]
00007981ddfdb553  vmovaps xmm14, [rsp+0xD0]
00007981ddfdb55c  vmovaps xmm15, [rsp+0xE0]
00007981ddfdb565  add rsp, 0xF0
00007981ddfdb56c  pop r11
00007981ddfdb56e  pop r10
00007981ddfdb570  pop r9
00007981ddfdb572  pop r8
00007981ddfdb574  pop rsi
00007981ddfdb575  pop rdi
00007981ddfdb576  pop rdx
00007981ddfdb577  pop rcx
00007981ddfdb578  pop rax
00007981ddfdb579  add rsp, 0x08
00007981ddfdb57d  jmp 0x00007981DDFD9167
00007981ddfdb582  sub rsp, 0x08
00007981ddfdb586  push rax
00007981ddfdb587  push rcx
00007981ddfdb588  push rdx
00007981ddfdb589  push rdi
00007981ddfdb58a  push rsi
00007981ddfdb58b  push r8
00007981ddfdb58d  push r9
00007981ddfdb58f  push r10
00007981ddfdb591  push r11
00007981ddfdb593  sub rsp, 0xF0
00007981ddfdb59a  vmovaps [rsp], xmm0
00007981ddfdb59f  vmovaps [rsp+0x10], xmm1
00007981ddfdb5a5  vmovaps [rsp+0x20], xmm2
00007981ddfdb5ab  vmovaps [rsp+0x30], xmm3
00007981ddfdb5b1  vmovaps [rsp+0x40], xmm4
00007981ddfdb5b7  vmovaps [rsp+0x50], xmm5
00007981ddfdb5bd  vmovaps [rsp+0x60], xmm7
00007981ddfdb5c3  vmovaps [rsp+0x70], xmm8
00007981ddfdb5c9  vmovaps [rsp+0x80], xmm9
00007981ddfdb5d2  vmovaps [rsp+0x90], xmm10
00007981ddfdb5db  vmovaps [rsp+0xA0], xmm11
00007981ddfdb5e4  vmovaps [rsp+0xB0], xmm12
00007981ddfdb5ed  vmovaps [rsp+0xC0], xmm13
00007981ddfdb5f6  vmovaps [rsp+0xD0], xmm14
00007981ddfdb5ff  vmovaps [rsp+0xE0], xmm15
00007981ddfdb608  sub rsp, 0x30
00007981ddfdb60c  movaps [rsp], xmm6
00007981ddfdb610  movaps [rsp+0x10], xmm9
00007981ddfdb616  movaps [rsp+0x20], xmm1
00007981ddfdb61b  lea rdi, [rsp]
00007981ddfdb61f  mov esi, 0x00
00007981ddfdb624  mov rax, 0x5782A6EB3530
00007981ddfdb62e  call rax
00007981ddfdb630  movaps xmm6, [rsp]
00007981ddfdb634  add rsp, 0x30
00007981ddfdb638  vmovaps xmm0, [rsp]
00007981ddfdb63d  vmovaps xmm1, [rsp+0x10]
00007981ddfdb643  vmovaps xmm2, [rsp+0x20]
00007981ddfdb649  vmovaps xmm3, [rsp+0x30]
00007981ddfdb64f  vmovaps xmm4, [rsp+0x40]
00007981ddfdb655  vmovaps xmm5, [rsp+0x50]
00007981ddfdb65b  vmovaps xmm7, [rsp+0x60]
00007981ddfdb661  vmovaps xmm8, [rsp+0x70]
00007981ddfdb667  vmovaps xmm9, [rsp+0x80]
00007981ddfdb670  vmovaps xmm10, [rsp+0x90]
00007981ddfdb679  vmovaps xmm11, [rsp+0xA0]
00007981ddfdb682  vmovaps xmm12, [rsp+0xB0]
00007981ddfdb68b  vmovaps xmm13, [rsp+0xC0]
00007981ddfdb694  vmovaps xmm14, [rsp+0xD0]
00007981ddfdb69d  vmovaps xmm15, [rsp+0xE0]
00007981ddfdb6a6  add rsp, 0xF0
00007981ddfdb6ad  pop r11
00007981ddfdb6af  pop r10
00007981ddfdb6b1  pop r9
00007981ddfdb6b3  pop r8
00007981ddfdb6b5  pop rsi
00007981ddfdb6b6  pop rdi
00007981ddfdb6b7  pop rdx
00007981ddfdb6b8  pop rcx
00007981ddfdb6b9  pop rax
00007981ddfdb6ba  add rsp, 0x08
00007981ddfdb6be  jmp 0x00007981DDFD918B
00007981ddfdb6c3  sub rsp, 0x08
00007981ddfdb6c7  push rax
00007981ddfdb6c8  push rcx
00007981ddfdb6c9  push rdx
00007981ddfdb6ca  push rdi
00007981ddfdb6cb  push rsi
00007981ddfdb6cc  push r8
00007981ddfdb6ce  push r9
00007981ddfdb6d0  push r10
00007981ddfdb6d2  push r11
00007981ddfdb6d4  sub rsp, 0xF0
00007981ddfdb6db  vmovaps [rsp], xmm0
00007981ddfdb6e0  vmovaps [rsp+0x10], xmm1
00007981ddfdb6e6  vmovaps [rsp+0x20], xmm2
00007981ddfdb6ec  vmovaps [rsp+0x30], xmm3
00007981ddfdb6f2  vmovaps [rsp+0x40], xmm4
00007981ddfdb6f8  vmovaps [rsp+0x50], xmm5
00007981ddfdb6fe  vmovaps [rsp+0x60], xmm6
00007981ddfdb704  vmovaps [rsp+0x70], xmm7
00007981ddfdb70a  vmovaps [rsp+0x80], xmm8
00007981ddfdb713  vmovaps [rsp+0x90], xmm10
00007981ddfdb71c  vmovaps [rsp+0xA0], xmm11
00007981ddfdb725  vmovaps [rsp+0xB0], xmm12
00007981ddfdb72e  vmovaps [rsp+0xC0], xmm13
00007981ddfdb737  vmovaps [rsp+0xD0], xmm14
00007981ddfdb740  vmovaps [rsp+0xE0], xmm15
00007981ddfdb749  sub rsp, 0x30
00007981ddfdb74d  movaps [rsp], xmm9
00007981ddfdb752  movaps [rsp+0x10], xmm3
00007981ddfdb757  movaps [rsp+0x20], xmm1
00007981ddfdb75c  lea rdi, [rsp]
00007981ddfdb760  mov esi, 0x00
00007981ddfdb765  mov rax, 0x5782A6EB3530
00007981ddfdb76f  call rax
00007981ddfdb771  movaps xmm9, [rsp]
00007981ddfdb776  add rsp, 0x30
00007981ddfdb77a  vmovaps xmm0, [rsp]
00007981ddfdb77f  vmovaps xmm1, [rsp+0x10]
00007981ddfdb785  vmovaps xmm2, [rsp+0x20]
00007981ddfdb78b  vmovaps xmm3, [rsp+0x30]
00007981ddfdb791  vmovaps xmm4, [rsp+0x40]
00007981ddfdb797  vmovaps xmm5, [rsp+0x50]
00007981ddfdb79d  vmovaps xmm6, [rsp+0x60]
00007981ddfdb7a3  vmovaps xmm7, [rsp+0x70]
00007981ddfdb7a9  vmovaps xmm8, [rsp+0x80]
00007981ddfdb7b2  vmovaps xmm10, [rsp+0x90]
00007981ddfdb7bb  vmovaps xmm11, [rsp+0xA0]
00007981ddfdb7c4  vmovaps xmm12, [rsp+0xB0]
00007981ddfdb7cd  vmovaps xmm13, [rsp+0xC0]
00007981ddfdb7d6  vmovaps xmm14, [rsp+0xD0]
00007981ddfdb7df  vmovaps xmm15, [rsp+0xE0]
00007981ddfdb7e8  add rsp, 0xF0
00007981ddfdb7ef  pop r11
00007981ddfdb7f1  pop r10
00007981ddfdb7f3  pop r9
00007981ddfdb7f5  pop r8
00007981ddfdb7f7  pop rsi
00007981ddfdb7f8  pop rdi
00007981ddfdb7f9  pop rdx
00007981ddfdb7fa  pop rcx
00007981ddfdb7fb  pop rax
00007981ddfdb7fc  add rsp, 0x08
00007981ddfdb800  jmp 0x00007981DDFD91D7
00007981ddfdb805  call 0x00007981DDED64F0
00007981ddfdb80a  jmp 0x00007981DDFD91E4
00007981ddfdb80f  sub rsp, 0x08
00007981ddfdb813  push rax
00007981ddfdb814  push rcx
00007981ddfdb815  push rdx
00007981ddfdb816  push rdi
00007981ddfdb817  push rsi
00007981ddfdb818  push r8
00007981ddfdb81a  push r9
00007981ddfdb81c  push r10
00007981ddfdb81e  push r11
00007981ddfdb820  sub rsp, 0xF0
00007981ddfdb827  vmovaps [rsp], xmm0
00007981ddfdb82c  vmovaps [rsp+0x10], xmm1
00007981ddfdb832  vmovaps [rsp+0x20], xmm2
00007981ddfdb838  vmovaps [rsp+0x30], xmm3
00007981ddfdb83e  vmovaps [rsp+0x40], xmm4
00007981ddfdb844  vmovaps [rsp+0x50], xmm5
00007981ddfdb84a  vmovaps [rsp+0x60], xmm6
00007981ddfdb850  vmovaps [rsp+0x70], xmm7
00007981ddfdb856  vmovaps [rsp+0x80], xmm8
00007981ddfdb85f  vmovaps [rsp+0x90], xmm9
00007981ddfdb868  vmovaps [rsp+0xA0], xmm10
00007981ddfdb871  vmovaps [rsp+0xB0], xmm11
00007981ddfdb87a  vmovaps [rsp+0xC0], xmm12
00007981ddfdb883  vmovaps [rsp+0xD0], xmm13
00007981ddfdb88c  vmovaps [rsp+0xE0], xmm14
00007981ddfdb895  sub rsp, 0x30
00007981ddfdb899  movaps [rsp], xmm15
00007981ddfdb89e  movaps [rsp+0x10], xmm3
00007981ddfdb8a3  movaps [rsp+0x20], xmm7
00007981ddfdb8a8  lea rdi, [rsp]
00007981ddfdb8ac  mov esi, 0x00
00007981ddfdb8b1  mov rax, 0x5782A6EB3530
00007981ddfdb8bb  call rax
00007981ddfdb8bd  movaps xmm15, [rsp]
00007981ddfdb8c2  add rsp, 0x30
00007981ddfdb8c6  vmovaps xmm0, [rsp]
00007981ddfdb8cb  vmovaps xmm1, [rsp+0x10]
00007981ddfdb8d1  vmovaps xmm2, [rsp+0x20]
00007981ddfdb8d7  vmovaps xmm3, [rsp+0x30]
00007981ddfdb8dd  vmovaps xmm4, [rsp+0x40]
00007981ddfdb8e3  vmovaps xmm5, [rsp+0x50]
00007981ddfdb8e9  vmovaps xmm6, [rsp+0x60]
00007981ddfdb8ef  vmovaps xmm7, [rsp+0x70]
00007981ddfdb8f5  vmovaps xmm8, [rsp+0x80]
00007981ddfdb8fe  vmovaps xmm9, [rsp+0x90]
00007981ddfdb907  vmovaps xmm10, [rsp+0xA0]
00007981ddfdb910  vmovaps xmm11, [rsp+0xB0]
00007981ddfdb919  vmovaps xmm12, [rsp+0xC0]
00007981ddfdb922  vmovaps xmm13, [rsp+0xD0]
00007981ddfdb92b  vmovaps xmm14, [rsp+0xE0]
00007981ddfdb934  add rsp, 0xF0
00007981ddfdb93b  pop r11
00007981ddfdb93d  pop r10
00007981ddfdb93f  pop r9
00007981ddfdb941  pop r8
00007981ddfdb943  pop rsi
00007981ddfdb944  pop rdi
00007981ddfdb945  pop rdx
00007981ddfdb946  pop rcx
00007981ddfdb947  pop rax
00007981ddfdb948  add rsp, 0x08
00007981ddfdb94c  jmp 0x00007981DDFD9210
00007981ddfdb951  sub rsp, 0x08
00007981ddfdb955  push rax
00007981ddfdb956  push rcx
00007981ddfdb957  push rdx
00007981ddfdb958  push rdi
00007981ddfdb959  push rsi
00007981ddfdb95a  push r8
00007981ddfdb95c  push r9
00007981ddfdb95e  push r10
00007981ddfdb960  push r11
00007981ddfdb962  sub rsp, 0xF0
00007981ddfdb969  vmovaps [rsp], xmm0
00007981ddfdb96e  vmovaps [rsp+0x10], xmm1
00007981ddfdb974  vmovaps [rsp+0x20], xmm2
00007981ddfdb97a  vmovaps [rsp+0x30], xmm4
00007981ddfdb980  vmovaps [rsp+0x40], xmm5
00007981ddfdb986  vmovaps [rsp+0x50], xmm6
00007981ddfdb98c  vmovaps [rsp+0x60], xmm7
00007981ddfdb992  vmovaps [rsp+0x70], xmm8
00007981ddfdb998  vmovaps [rsp+0x80], xmm9
00007981ddfdb9a1  vmovaps [rsp+0x90], xmm10
00007981ddfdb9aa  vmovaps [rsp+0xA0], xmm11
00007981ddfdb9b3  vmovaps [rsp+0xB0], xmm12
00007981ddfdb9bc  vmovaps [rsp+0xC0], xmm13
00007981ddfdb9c5  vmovaps [rsp+0xD0], xmm14
00007981ddfdb9ce  vmovaps [rsp+0xE0], xmm15
00007981ddfdb9d7  sub rsp, 0x30
00007981ddfdb9db  movaps [rsp], xmm3
00007981ddfdb9df  movaps [rsp+0x10], xmm1
00007981ddfdb9e4  movaps [rsp+0x20], xmm15
00007981ddfdb9ea  lea rdi, [rsp]
00007981ddfdb9ee  mov esi, 0x00
00007981ddfdb9f3  mov rax, 0x5782A6EB3530
00007981ddfdb9fd  call rax
00007981ddfdb9ff  movaps xmm3, [rsp]
00007981ddfdba03  add rsp, 0x30
00007981ddfdba07  vmovaps xmm0, [rsp]
00007981ddfdba0c  vmovaps xmm1, [rsp+0x10]
00007981ddfdba12  vmovaps xmm2, [rsp+0x20]
00007981ddfdba18  vmovaps xmm4, [rsp+0x30]
00007981ddfdba1e  vmovaps xmm5, [rsp+0x40]
00007981ddfdba24  vmovaps xmm6, [rsp+0x50]
00007981ddfdba2a  vmovaps xmm7, [rsp+0x60]
00007981ddfdba30  vmovaps xmm8, [rsp+0x70]
00007981ddfdba36  vmovaps xmm9, [rsp+0x80]
00007981ddfdba3f  vmovaps xmm10, [rsp+0x90]
00007981ddfdba48  vmovaps xmm11, [rsp+0xA0]
00007981ddfdba51  vmovaps xmm12, [rsp+0xB0]
00007981ddfdba5a  vmovaps xmm13, [rsp+0xC0]
00007981ddfdba63  vmovaps xmm14, [rsp+0xD0]
00007981ddfdba6c  vmovaps xmm15, [rsp+0xE0]
00007981ddfdba75  add rsp, 0xF0
00007981ddfdba7c  pop r11
00007981ddfdba7e  pop r10
00007981ddfdba80  pop r9
00007981ddfdba82  pop r8
00007981ddfdba84  pop rsi
00007981ddfdba85  pop rdi
00007981ddfdba86  pop rdx
00007981ddfdba87  pop rcx
00007981ddfdba88  pop rax
00007981ddfdba89  add rsp, 0x08
00007981ddfdba8d  jmp 0x00007981DDFD929F
00007981ddfdba92  call 0x00007981DDED64F0
00007981ddfdba97  jmp 0x00007981DDFD92A9
00007981ddfdba9c  sub rsp, 0x08
00007981ddfdbaa0  push rax
00007981ddfdbaa1  push rcx
00007981ddfdbaa2  push rdx
00007981ddfdbaa3  push rdi
00007981ddfdbaa4  push rsi
00007981ddfdbaa5  push r8
00007981ddfdbaa7  push r9
00007981ddfdbaa9  push r10
00007981ddfdbaab  push r11
00007981ddfdbaad  sub rsp, 0xF0
00007981ddfdbab4  vmovaps [rsp], xmm0
00007981ddfdbab9  vmovaps [rsp+0x10], xmm1
00007981ddfdbabf  vmovaps [rsp+0x20], xmm2
00007981ddfdbac5  vmovaps [rsp+0x30], xmm3
00007981ddfdbacb  vmovaps [rsp+0x40], xmm4
00007981ddfdbad1  vmovaps [rsp+0x50], xmm5
00007981ddfdbad7  vmovaps [rsp+0x60], xmm6
00007981ddfdbadd  vmovaps [rsp+0x70], xmm7
00007981ddfdbae3  vmovaps [rsp+0x80], xmm8
00007981ddfdbaec  vmovaps [rsp+0x90], xmm9
00007981ddfdbaf5  vmovaps [rsp+0xA0], xmm10
00007981ddfdbafe  vmovaps [rsp+0xB0], xmm11
00007981ddfdbb07  vmovaps [rsp+0xC0], xmm12
00007981ddfdbb10  vmovaps [rsp+0xD0], xmm13
00007981ddfdbb19  vmovaps [rsp+0xE0], xmm14
00007981ddfdbb22  sub rsp, 0x30
00007981ddfdbb26  movaps [rsp], xmm15
00007981ddfdbb2b  movaps [rsp+0x10], xmm14
00007981ddfdbb31  movaps [rsp+0x20], xmm4
00007981ddfdbb36  lea rdi, [rsp]
00007981ddfdbb3a  mov esi, 0x00
00007981ddfdbb3f  mov rax, 0x5782A6EB3530
00007981ddfdbb49  call rax
00007981ddfdbb4b  movaps xmm15, [rsp]
00007981ddfdbb50  add rsp, 0x30
00007981ddfdbb54  vmovaps xmm0, [rsp]
00007981ddfdbb59  vmovaps xmm1, [rsp+0x10]
00007981ddfdbb5f  vmovaps xmm2, [rsp+0x20]
00007981ddfdbb65  vmovaps xmm3, [rsp+0x30]
00007981ddfdbb6b  vmovaps xmm4, [rsp+0x40]
00007981ddfdbb71  vmovaps xmm5, [rsp+0x50]
00007981ddfdbb77  vmovaps xmm6, [rsp+0x60]
00007981ddfdbb7d  vmovaps xmm7, [rsp+0x70]
00007981ddfdbb83  vmovaps xmm8, [rsp+0x80]
00007981ddfdbb8c  vmovaps xmm9, [rsp+0x90]
00007981ddfdbb95  vmovaps xmm10, [rsp+0xA0]
00007981ddfdbb9e  vmovaps xmm11, [rsp+0xB0]
00007981ddfdbba7  vmovaps xmm12, [rsp+0xC0]
00007981ddfdbbb0  vmovaps xmm13, [rsp+0xD0]
00007981ddfdbbb9  vmovaps xmm14, [rsp+0xE0]
00007981ddfdbbc2  add rsp, 0xF0
00007981ddfdbbc9  pop r11
00007981ddfdbbcb  pop r10
00007981ddfdbbcd  pop r9
00007981ddfdbbcf  pop r8
00007981ddfdbbd1  pop rsi
00007981ddfdbbd2  pop rdi
00007981ddfdbbd3  pop rdx
00007981ddfdbbd4  pop rcx
00007981ddfdbbd5  pop rax
00007981ddfdbbd6  add rsp, 0x08
00007981ddfdbbda  jmp 0x00007981DDFD92D7
00007981ddfdbbdf  sub rsp, 0x08
00007981ddfdbbe3  push rax
00007981ddfdbbe4  push rcx
00007981ddfdbbe5  push rdx
00007981ddfdbbe6  push rdi
00007981ddfdbbe7  push rsi
00007981ddfdbbe8  push r8
00007981ddfdbbea  push r9
00007981ddfdbbec  push r10
00007981ddfdbbee  push r11
00007981ddfdbbf0  sub rsp, 0xF0
00007981ddfdbbf7  vmovaps [rsp], xmm0
00007981ddfdbbfc  vmovaps [rsp+0x10], xmm1
00007981ddfdbc02  vmovaps [rsp+0x20], xmm2
00007981ddfdbc08  vmovaps [rsp+0x30], xmm3
00007981ddfdbc0e  vmovaps [rsp+0x40], xmm4
00007981ddfdbc14  vmovaps [rsp+0x50], xmm5
00007981ddfdbc1a  vmovaps [rsp+0x60], xmm6
00007981ddfdbc20  vmovaps [rsp+0x70], xmm7
00007981ddfdbc26  vmovaps [rsp+0x80], xmm8
00007981ddfdbc2f  vmovaps [rsp+0x90], xmm9
00007981ddfdbc38  vmovaps [rsp+0xA0], xmm10
00007981ddfdbc41  vmovaps [rsp+0xB0], xmm11
00007981ddfdbc4a  vmovaps [rsp+0xC0], xmm12
00007981ddfdbc53  vmovaps [rsp+0xD0], xmm13
00007981ddfdbc5c  vmovaps [rsp+0xE0], xmm15
00007981ddfdbc65  sub rsp, 0x30
00007981ddfdbc69  movaps [rsp], xmm14
00007981ddfdbc6e  movaps [rsp+0x10], xmm2
00007981ddfdbc73  movaps [rsp+0x20], xmm1
00007981ddfdbc78  lea rdi, [rsp]
00007981ddfdbc7c  mov esi, 0x00
00007981ddfdbc81  mov rax, 0x5782A6EB3530
00007981ddfdbc8b  call rax
00007981ddfdbc8d  movaps xmm14, [rsp]
00007981ddfdbc92  add rsp, 0x30
00007981ddfdbc96  vmovaps xmm0, [rsp]
00007981ddfdbc9b  vmovaps xmm1, [rsp+0x10]
00007981ddfdbca1  vmovaps xmm2, [rsp+0x20]
00007981ddfdbca7  vmovaps xmm3, [rsp+0x30]
00007981ddfdbcad  vmovaps xmm4, [rsp+0x40]
00007981ddfdbcb3  vmovaps xmm5, [rsp+0x50]
00007981ddfdbcb9  vmovaps xmm6, [rsp+0x60]
00007981ddfdbcbf  vmovaps xmm7, [rsp+0x70]
00007981ddfdbcc5  vmovaps xmm8, [rsp+0x80]
00007981ddfdbcce  vmovaps xmm9, [rsp+0x90]
00007981ddfdbcd7  vmovaps xmm10, [rsp+0xA0]
00007981ddfdbce0  vmovaps xmm11, [rsp+0xB0]
00007981ddfdbce9  vmovaps xmm12, [rsp+0xC0]
00007981ddfdbcf2  vmovaps xmm13, [rsp+0xD0]
00007981ddfdbcfb  vmovaps xmm15, [rsp+0xE0]
00007981ddfdbd04  add rsp, 0xF0
00007981ddfdbd0b  pop r11
00007981ddfdbd0d  pop r10
00007981ddfdbd0f  pop r9
00007981ddfdbd11  pop r8
00007981ddfdbd13  pop rsi
00007981ddfdbd14  pop rdi
00007981ddfdbd15  pop rdx
00007981ddfdbd16  pop rcx
00007981ddfdbd17  pop rax
00007981ddfdbd18  add rsp, 0x08
00007981ddfdbd1c  jmp 0x00007981DDFD92FD
00007981ddfdbd21  sub rsp, 0x08
00007981ddfdbd25  push rax
00007981ddfdbd26  push rcx
00007981ddfdbd27  push rdx
00007981ddfdbd28  push rdi
00007981ddfdbd29  push rsi
00007981ddfdbd2a  push r8
00007981ddfdbd2c  push r9
00007981ddfdbd2e  push r10
00007981ddfdbd30  push r11
00007981ddfdbd32  sub rsp, 0xF0
00007981ddfdbd39  vmovaps [rsp], xmm0
00007981ddfdbd3e  vmovaps [rsp+0x10], xmm2
00007981ddfdbd44  vmovaps [rsp+0x20], xmm3
00007981ddfdbd4a  vmovaps [rsp+0x30], xmm4
00007981ddfdbd50  vmovaps [rsp+0x40], xmm5
00007981ddfdbd56  vmovaps [rsp+0x50], xmm6
00007981ddfdbd5c  vmovaps [rsp+0x60], xmm7
00007981ddfdbd62  vmovaps [rsp+0x70], xmm8
00007981ddfdbd68  vmovaps [rsp+0x80], xmm9
00007981ddfdbd71  vmovaps [rsp+0x90], xmm10
00007981ddfdbd7a  vmovaps [rsp+0xA0], xmm11
00007981ddfdbd83  vmovaps [rsp+0xB0], xmm12
00007981ddfdbd8c  vmovaps [rsp+0xC0], xmm13
00007981ddfdbd95  vmovaps [rsp+0xD0], xmm14
00007981ddfdbd9e  vmovaps [rsp+0xE0], xmm15
00007981ddfdbda7  sub rsp, 0x30
00007981ddfdbdab  movaps [rsp], xmm1
00007981ddfdbdaf  movaps [rsp+0x10], xmm4
00007981ddfdbdb4  movaps [rsp+0x20], xmm9
00007981ddfdbdba  lea rdi, [rsp]
00007981ddfdbdbe  mov esi, 0x00
00007981ddfdbdc3  mov rax, 0x5782A6EB3530
00007981ddfdbdcd  call rax
00007981ddfdbdcf  movaps xmm1, [rsp]
00007981ddfdbdd3  add rsp, 0x30
00007981ddfdbdd7  vmovaps xmm0, [rsp]
00007981ddfdbddc  vmovaps xmm2, [rsp+0x10]
00007981ddfdbde2  vmovaps xmm3, [rsp+0x20]
00007981ddfdbde8  vmovaps xmm4, [rsp+0x30]
00007981ddfdbdee  vmovaps xmm5, [rsp+0x40]
00007981ddfdbdf4  vmovaps xmm6, [rsp+0x50]
00007981ddfdbdfa  vmovaps xmm7, [rsp+0x60]
00007981ddfdbe00  vmovaps xmm8, [rsp+0x70]
00007981ddfdbe06  vmovaps xmm9, [rsp+0x80]
00007981ddfdbe0f  vmovaps xmm10, [rsp+0x90]
00007981ddfdbe18  vmovaps xmm11, [rsp+0xA0]
00007981ddfdbe21  vmovaps xmm12, [rsp+0xB0]
00007981ddfdbe2a  vmovaps xmm13, [rsp+0xC0]
00007981ddfdbe33  vmovaps xmm14, [rsp+0xD0]
00007981ddfdbe3c  vmovaps xmm15, [rsp+0xE0]
00007981ddfdbe45  add rsp, 0xF0
00007981ddfdbe4c  pop r11
00007981ddfdbe4e  pop r10
00007981ddfdbe50  pop r9
00007981ddfdbe52  pop r8
00007981ddfdbe54  pop rsi
00007981ddfdbe55  pop rdi
00007981ddfdbe56  pop rdx
00007981ddfdbe57  pop rcx
00007981ddfdbe58  pop rax
00007981ddfdbe59  add rsp, 0x08
00007981ddfdbe5d  jmp 0x00007981DDFD931B
00007981ddfdbe62  sub rsp, 0x08
00007981ddfdbe66  push rax
00007981ddfdbe67  push rcx
00007981ddfdbe68  push rdx
00007981ddfdbe69  push rdi
00007981ddfdbe6a  push rsi
00007981ddfdbe6b  push r8
00007981ddfdbe6d  push r9
00007981ddfdbe6f  push r10
00007981ddfdbe71  push r11
00007981ddfdbe73  sub rsp, 0xF0
00007981ddfdbe7a  vmovaps [rsp], xmm0
00007981ddfdbe7f  vmovaps [rsp+0x10], xmm1
00007981ddfdbe85  vmovaps [rsp+0x20], xmm2
00007981ddfdbe8b  vmovaps [rsp+0x30], xmm3
00007981ddfdbe91  vmovaps [rsp+0x40], xmm5
00007981ddfdbe97  vmovaps [rsp+0x50], xmm6
00007981ddfdbe9d  vmovaps [rsp+0x60], xmm7
00007981ddfdbea3  vmovaps [rsp+0x70], xmm8
00007981ddfdbea9  vmovaps [rsp+0x80], xmm9
00007981ddfdbeb2  vmovaps [rsp+0x90], xmm10
00007981ddfdbebb  vmovaps [rsp+0xA0], xmm11
00007981ddfdbec4  vmovaps [rsp+0xB0], xmm12
00007981ddfdbecd  vmovaps [rsp+0xC0], xmm13
00007981ddfdbed6  vmovaps [rsp+0xD0], xmm14
00007981ddfdbedf  vmovaps [rsp+0xE0], xmm15
00007981ddfdbee8  sub rsp, 0x30
00007981ddfdbeec  movaps [rsp], xmm4
00007981ddfdbef0  movaps [rsp+0x10], xmm2
00007981ddfdbef5  movaps [rsp+0x20], xmm9
00007981ddfdbefb  lea rdi, [rsp]
00007981ddfdbeff  mov esi, 0x00
00007981ddfdbf04  mov rax, 0x5782A6EB3530
00007981ddfdbf0e  call rax
00007981ddfdbf10  movaps xmm4, [rsp]
00007981ddfdbf14  add rsp, 0x30
00007981ddfdbf18  vmovaps xmm0, [rsp]
00007981ddfdbf1d  vmovaps xmm1, [rsp+0x10]
00007981ddfdbf23  vmovaps xmm2, [rsp+0x20]
00007981ddfdbf29  vmovaps xmm3, [rsp+0x30]
00007981ddfdbf2f  vmovaps xmm5, [rsp+0x40]
00007981ddfdbf35  vmovaps xmm6, [rsp+0x50]
00007981ddfdbf3b  vmovaps xmm7, [rsp+0x60]
00007981ddfdbf41  vmovaps xmm8, [rsp+0x70]
00007981ddfdbf47  vmovaps xmm9, [rsp+0x80]
00007981ddfdbf50  vmovaps xmm10, [rsp+0x90]
00007981ddfdbf59  vmovaps xmm11, [rsp+0xA0]
00007981ddfdbf62  vmovaps xmm12, [rsp+0xB0]
00007981ddfdbf6b  vmovaps xmm13, [rsp+0xC0]
00007981ddfdbf74  vmovaps xmm14, [rsp+0xD0]
00007981ddfdbf7d  vmovaps xmm15, [rsp+0xE0]
00007981ddfdbf86  add rsp, 0xF0
00007981ddfdbf8d  pop r11
00007981ddfdbf8f  pop r10
00007981ddfdbf91  pop r9
00007981ddfdbf93  pop r8
00007981ddfdbf95  pop rsi
00007981ddfdbf96  pop rdi
00007981ddfdbf97  pop rdx
00007981ddfdbf98  pop rcx
00007981ddfdbf99  pop rax
00007981ddfdbf9a  add rsp, 0x08
00007981ddfdbf9e  jmp 0x00007981DDFD934B
00007981ddfdbfa3  sub rsp, 0x08
00007981ddfdbfa7  push rax
00007981ddfdbfa8  push rcx
00007981ddfdbfa9  push rdx
00007981ddfdbfaa  push rdi
00007981ddfdbfab  push rsi
00007981ddfdbfac  push r8
00007981ddfdbfae  push r9
00007981ddfdbfb0  push r10
00007981ddfdbfb2  push r11
00007981ddfdbfb4  sub rsp, 0xF0
00007981ddfdbfbb  vmovaps [rsp], xmm0
00007981ddfdbfc0  vmovaps [rsp+0x10], xmm1
00007981ddfdbfc6  vmovaps [rsp+0x20], xmm2
00007981ddfdbfcc  vmovaps [rsp+0x30], xmm3
00007981ddfdbfd2  vmovaps [rsp+0x40], xmm4
00007981ddfdbfd8  vmovaps [rsp+0x50], xmm5
00007981ddfdbfde  vmovaps [rsp+0x60], xmm6
00007981ddfdbfe4  vmovaps [rsp+0x70], xmm7
00007981ddfdbfea  vmovaps [rsp+0x80], xmm8
00007981ddfdbff3  vmovaps [rsp+0x90], xmm10
00007981ddfdbffc  vmovaps [rsp+0xA0], xmm11
00007981ddfdc005  vmovaps [rsp+0xB0], xmm12
00007981ddfdc00e  vmovaps [rsp+0xC0], xmm13
00007981ddfdc017  vmovaps [rsp+0xD0], xmm14
00007981ddfdc020  vmovaps [rsp+0xE0], xmm15
00007981ddfdc029  sub rsp, 0x30
00007981ddfdc02d  movaps [rsp], xmm9
00007981ddfdc032  movaps [rsp+0x10], xmm2
00007981ddfdc037  movaps [rsp+0x20], xmm1
00007981ddfdc03c  lea rdi, [rsp]
00007981ddfdc040  mov esi, 0x00
00007981ddfdc045  mov rax, 0x5782A6EB3530
00007981ddfdc04f  call rax
00007981ddfdc051  movaps xmm9, [rsp]
00007981ddfdc056  add rsp, 0x30
00007981ddfdc05a  vmovaps xmm0, [rsp]
00007981ddfdc05f  vmovaps xmm1, [rsp+0x10]
00007981ddfdc065  vmovaps xmm2, [rsp+0x20]
00007981ddfdc06b  vmovaps xmm3, [rsp+0x30]
00007981ddfdc071  vmovaps xmm4, [rsp+0x40]
00007981ddfdc077  vmovaps xmm5, [rsp+0x50]
00007981ddfdc07d  vmovaps xmm6, [rsp+0x60]
00007981ddfdc083  vmovaps xmm7, [rsp+0x70]
00007981ddfdc089  vmovaps xmm8, [rsp+0x80]
00007981ddfdc092  vmovaps xmm10, [rsp+0x90]
00007981ddfdc09b  vmovaps xmm11, [rsp+0xA0]
00007981ddfdc0a4  vmovaps xmm12, [rsp+0xB0]
00007981ddfdc0ad  vmovaps xmm13, [rsp+0xC0]
00007981ddfdc0b6  vmovaps xmm14, [rsp+0xD0]
00007981ddfdc0bf  vmovaps xmm15, [rsp+0xE0]
00007981ddfdc0c8  add rsp, 0xF0
00007981ddfdc0cf  pop r11
00007981ddfdc0d1  pop r10
00007981ddfdc0d3  pop r9
00007981ddfdc0d5  pop r8
00007981ddfdc0d7  pop rsi
00007981ddfdc0d8  pop rdi
00007981ddfdc0d9  pop rdx
00007981ddfdc0da  pop rcx
00007981ddfdc0db  pop rax
00007981ddfdc0dc  add rsp, 0x08
00007981ddfdc0e0  jmp 0x00007981DDFD9381
00007981ddfdc0e5  sub rsp, 0x08
00007981ddfdc0e9  push rax
00007981ddfdc0ea  push rcx
00007981ddfdc0eb  push rdx
00007981ddfdc0ec  push rdi
00007981ddfdc0ed  push rsi
00007981ddfdc0ee  push r8
00007981ddfdc0f0  push r9
00007981ddfdc0f2  push r10
00007981ddfdc0f4  push r11
00007981ddfdc0f6  sub rsp, 0xF0
00007981ddfdc0fd  vmovaps [rsp], xmm0
00007981ddfdc102  vmovaps [rsp+0x10], xmm2
00007981ddfdc108  vmovaps [rsp+0x20], xmm3
00007981ddfdc10e  vmovaps [rsp+0x30], xmm4
00007981ddfdc114  vmovaps [rsp+0x40], xmm5
00007981ddfdc11a  vmovaps [rsp+0x50], xmm6
00007981ddfdc120  vmovaps [rsp+0x60], xmm7
00007981ddfdc126  vmovaps [rsp+0x70], xmm8
00007981ddfdc12c  vmovaps [rsp+0x80], xmm9
00007981ddfdc135  vmovaps [rsp+0x90], xmm10
00007981ddfdc13e  vmovaps [rsp+0xA0], xmm11
00007981ddfdc147  vmovaps [rsp+0xB0], xmm12
00007981ddfdc150  vmovaps [rsp+0xC0], xmm13
00007981ddfdc159  vmovaps [rsp+0xD0], xmm14
00007981ddfdc162  vmovaps [rsp+0xE0], xmm15
00007981ddfdc16b  sub rsp, 0x30
00007981ddfdc16f  movaps [rsp], xmm1
00007981ddfdc173  movaps [rsp+0x10], xmm15
00007981ddfdc179  movaps [rsp+0x20], xmm6
00007981ddfdc17e  lea rdi, [rsp]
00007981ddfdc182  mov esi, 0x00
00007981ddfdc187  mov rax, 0x5782A6EB3530
00007981ddfdc191  call rax
00007981ddfdc193  movaps xmm1, [rsp]
00007981ddfdc197  add rsp, 0x30
00007981ddfdc19b  vmovaps xmm0, [rsp]
00007981ddfdc1a0  vmovaps xmm2, [rsp+0x10]
00007981ddfdc1a6  vmovaps xmm3, [rsp+0x20]
00007981ddfdc1ac  vmovaps xmm4, [rsp+0x30]
00007981ddfdc1b2  vmovaps xmm5, [rsp+0x40]
00007981ddfdc1b8  vmovaps xmm6, [rsp+0x50]
00007981ddfdc1be  vmovaps xmm7, [rsp+0x60]
00007981ddfdc1c4  vmovaps xmm8, [rsp+0x70]
00007981ddfdc1ca  vmovaps xmm9, [rsp+0x80]
00007981ddfdc1d3  vmovaps xmm10, [rsp+0x90]
00007981ddfdc1dc  vmovaps xmm11, [rsp+0xA0]
00007981ddfdc1e5  vmovaps xmm12, [rsp+0xB0]
00007981ddfdc1ee  vmovaps xmm13, [rsp+0xC0]
00007981ddfdc1f7  vmovaps xmm14, [rsp+0xD0]
00007981ddfdc200  vmovaps xmm15, [rsp+0xE0]
00007981ddfdc209  add rsp, 0xF0
00007981ddfdc210  pop r11
00007981ddfdc212  pop r10
00007981ddfdc214  pop r9
00007981ddfdc216  pop r8
00007981ddfdc218  pop rsi
00007981ddfdc219  pop rdi
00007981ddfdc21a  pop rdx
00007981ddfdc21b  pop rcx
00007981ddfdc21c  pop rax
00007981ddfdc21d  add rsp, 0x08
00007981ddfdc221  jmp 0x00007981DDFD93A2
00007981ddfdc226  sub rsp, 0x08
00007981ddfdc22a  push rax
00007981ddfdc22b  push rcx
00007981ddfdc22c  push rdx
00007981ddfdc22d  push rdi
00007981ddfdc22e  push rsi
00007981ddfdc22f  push r8
00007981ddfdc231  push r9
00007981ddfdc233  push r10
00007981ddfdc235  push r11
00007981ddfdc237  sub rsp, 0xF0
00007981ddfdc23e  vmovaps [rsp], xmm0
00007981ddfdc243  vmovaps [rsp+0x10], xmm1
00007981ddfdc249  vmovaps [rsp+0x20], xmm2
00007981ddfdc24f  vmovaps [rsp+0x30], xmm3
00007981ddfdc255  vmovaps [rsp+0x40], xmm4
00007981ddfdc25b  vmovaps [rsp+0x50], xmm5
00007981ddfdc261  vmovaps [rsp+0x60], xmm6
00007981ddfdc267  vmovaps [rsp+0x70], xmm7
00007981ddfdc26d  vmovaps [rsp+0x80], xmm8
00007981ddfdc276  vmovaps [rsp+0x90], xmm9
00007981ddfdc27f  vmovaps [rsp+0xA0], xmm10
00007981ddfdc288  vmovaps [rsp+0xB0], xmm11
00007981ddfdc291  vmovaps [rsp+0xC0], xmm12
00007981ddfdc29a  vmovaps [rsp+0xD0], xmm13
00007981ddfdc2a3  vmovaps [rsp+0xE0], xmm14
00007981ddfdc2ac  sub rsp, 0x30
00007981ddfdc2b0  movaps [rsp], xmm15
00007981ddfdc2b5  movaps [rsp+0x10], xmm5
00007981ddfdc2ba  movaps [rsp+0x20], xmm3
00007981ddfdc2bf  lea rdi, [rsp]
00007981ddfdc2c3  mov esi, 0x00
00007981ddfdc2c8  mov rax, 0x5782A6EB3530
00007981ddfdc2d2  call rax
00007981ddfdc2d4  movaps xmm15, [rsp]
00007981ddfdc2d9  add rsp, 0x30
00007981ddfdc2dd  vmovaps xmm0, [rsp]
00007981ddfdc2e2  vmovaps xmm1, [rsp+0x10]
00007981ddfdc2e8  vmovaps xmm2, [rsp+0x20]
00007981ddfdc2ee  vmovaps xmm3, [rsp+0x30]
00007981ddfdc2f4  vmovaps xmm4, [rsp+0x40]
00007981ddfdc2fa  vmovaps xmm5, [rsp+0x50]
00007981ddfdc300  vmovaps xmm6, [rsp+0x60]
00007981ddfdc306  vmovaps xmm7, [rsp+0x70]
00007981ddfdc30c  vmovaps xmm8, [rsp+0x80]
00007981ddfdc315  vmovaps xmm9, [rsp+0x90]
00007981ddfdc31e  vmovaps xmm10, [rsp+0xA0]
00007981ddfdc327  vmovaps xmm11, [rsp+0xB0]
00007981ddfdc330  vmovaps xmm12, [rsp+0xC0]
00007981ddfdc339  vmovaps xmm13, [rsp+0xD0]
00007981ddfdc342  vmovaps xmm14, [rsp+0xE0]
00007981ddfdc34b  add rsp, 0xF0
00007981ddfdc352  pop r11
00007981ddfdc354  pop r10
00007981ddfdc356  pop r9
00007981ddfdc358  pop r8
00007981ddfdc35a  pop rsi
00007981ddfdc35b  pop rdi
00007981ddfdc35c  pop rdx
00007981ddfdc35d  pop rcx
00007981ddfdc35e  pop rax
00007981ddfdc35f  add rsp, 0x08
00007981ddfdc363  jmp 0x00007981DDFD93BC
00007981ddfdc368  sub rsp, 0x08
00007981ddfdc36c  push rax
00007981ddfdc36d  push rcx
00007981ddfdc36e  push rdx
00007981ddfdc36f  push rdi
00007981ddfdc370  push rsi
00007981ddfdc371  push r8
00007981ddfdc373  push r9
00007981ddfdc375  push r10
00007981ddfdc377  push r11
00007981ddfdc379  sub rsp, 0xF0
00007981ddfdc380  vmovaps [rsp], xmm0
00007981ddfdc385  vmovaps [rsp+0x10], xmm1
00007981ddfdc38b  vmovaps [rsp+0x20], xmm2
00007981ddfdc391  vmovaps [rsp+0x30], xmm3
00007981ddfdc397  vmovaps [rsp+0x40], xmm4
00007981ddfdc39d  vmovaps [rsp+0x50], xmm6
00007981ddfdc3a3  vmovaps [rsp+0x60], xmm7
00007981ddfdc3a9  vmovaps [rsp+0x70], xmm8
00007981ddfdc3af  vmovaps [rsp+0x80], xmm9
00007981ddfdc3b8  vmovaps [rsp+0x90], xmm10
00007981ddfdc3c1  vmovaps [rsp+0xA0], xmm11
00007981ddfdc3ca  vmovaps [rsp+0xB0], xmm12
00007981ddfdc3d3  vmovaps [rsp+0xC0], xmm13
00007981ddfdc3dc  vmovaps [rsp+0xD0], xmm14
00007981ddfdc3e5  vmovaps [rsp+0xE0], xmm15
00007981ddfdc3ee  sub rsp, 0x30
00007981ddfdc3f2  movaps [rsp], xmm5
00007981ddfdc3f6  movaps [rsp+0x10], xmm8
00007981ddfdc3fc  movaps [rsp+0x20], xmm6
00007981ddfdc401  lea rdi, [rsp]
00007981ddfdc405  mov esi, 0x00
00007981ddfdc40a  mov rax, 0x5782A6EB3530
00007981ddfdc414  call rax
00007981ddfdc416  movaps xmm5, [rsp]
00007981ddfdc41a  add rsp, 0x30
00007981ddfdc41e  vmovaps xmm0, [rsp]
00007981ddfdc423  vmovaps xmm1, [rsp+0x10]
00007981ddfdc429  vmovaps xmm2, [rsp+0x20]
00007981ddfdc42f  vmovaps xmm3, [rsp+0x30]
00007981ddfdc435  vmovaps xmm4, [rsp+0x40]
00007981ddfdc43b  vmovaps xmm6, [rsp+0x50]
00007981ddfdc441  vmovaps xmm7, [rsp+0x60]
00007981ddfdc447  vmovaps xmm8, [rsp+0x70]
00007981ddfdc44d  vmovaps xmm9, [rsp+0x80]
00007981ddfdc456  vmovaps xmm10, [rsp+0x90]
00007981ddfdc45f  vmovaps xmm11, [rsp+0xA0]
00007981ddfdc468  vmovaps xmm12, [rsp+0xB0]
00007981ddfdc471  vmovaps xmm13, [rsp+0xC0]
00007981ddfdc47a  vmovaps xmm14, [rsp+0xD0]
00007981ddfdc483  vmovaps xmm15, [rsp+0xE0]
00007981ddfdc48c  add rsp, 0xF0
00007981ddfdc493  pop r11
00007981ddfdc495  pop r10
00007981ddfdc497  pop r9
00007981ddfdc499  pop r8
00007981ddfdc49b  pop rsi
00007981ddfdc49c  pop rdi
00007981ddfdc49d  pop rdx
00007981ddfdc49e  pop rcx
00007981ddfdc49f  pop rax
00007981ddfdc4a0  add rsp, 0x08
00007981ddfdc4a4  jmp 0x00007981DDFD93E0
00007981ddfdc4a9  sub rsp, 0x08
00007981ddfdc4ad  push rax
00007981ddfdc4ae  push rcx
00007981ddfdc4af  push rdx
00007981ddfdc4b0  push rdi
00007981ddfdc4b1  push rsi
00007981ddfdc4b2  push r8
00007981ddfdc4b4  push r9
00007981ddfdc4b6  push r10
00007981ddfdc4b8  push r11
00007981ddfdc4ba  sub rsp, 0xF0
00007981ddfdc4c1  vmovaps [rsp], xmm0
00007981ddfdc4c6  vmovaps [rsp+0x10], xmm1
00007981ddfdc4cc  vmovaps [rsp+0x20], xmm2
00007981ddfdc4d2  vmovaps [rsp+0x30], xmm3
00007981ddfdc4d8  vmovaps [rsp+0x40], xmm4
00007981ddfdc4de  vmovaps [rsp+0x50], xmm5
00007981ddfdc4e4  vmovaps [rsp+0x60], xmm7
00007981ddfdc4ea  vmovaps [rsp+0x70], xmm8
00007981ddfdc4f0  vmovaps [rsp+0x80], xmm9
00007981ddfdc4f9  vmovaps [rsp+0x90], xmm10
00007981ddfdc502  vmovaps [rsp+0xA0], xmm11
00007981ddfdc50b  vmovaps [rsp+0xB0], xmm12
00007981ddfdc514  vmovaps [rsp+0xC0], xmm13
00007981ddfdc51d  vmovaps [rsp+0xD0], xmm14
00007981ddfdc526  vmovaps [rsp+0xE0], xmm15
00007981ddfdc52f  sub rsp, 0x30
00007981ddfdc533  movaps [rsp], xmm6
00007981ddfdc537  movaps [rsp+0x10], xmm10
00007981ddfdc53d  movaps [rsp+0x20], xmm8
00007981ddfdc543  lea rdi, [rsp]
00007981ddfdc547  mov esi, 0x00
00007981ddfdc54c  mov rax, 0x5782A6EB3530
00007981ddfdc556  call rax
00007981ddfdc558  movaps xmm6, [rsp]
00007981ddfdc55c  add rsp, 0x30
00007981ddfdc560  vmovaps xmm0, [rsp]
00007981ddfdc565  vmovaps xmm1, [rsp+0x10]
00007981ddfdc56b  vmovaps xmm2, [rsp+0x20]
00007981ddfdc571  vmovaps xmm3, [rsp+0x30]
00007981ddfdc577  vmovaps xmm4, [rsp+0x40]
00007981ddfdc57d  vmovaps xmm5, [rsp+0x50]
00007981ddfdc583  vmovaps xmm7, [rsp+0x60]
00007981ddfdc589  vmovaps xmm8, [rsp+0x70]
00007981ddfdc58f  vmovaps xmm9, [rsp+0x80]
00007981ddfdc598  vmovaps xmm10, [rsp+0x90]
00007981ddfdc5a1  vmovaps xmm11, [rsp+0xA0]
00007981ddfdc5aa  vmovaps xmm12, [rsp+0xB0]
00007981ddfdc5b3  vmovaps xmm13, [rsp+0xC0]
00007981ddfdc5bc  vmovaps xmm14, [rsp+0xD0]
00007981ddfdc5c5  vmovaps xmm15, [rsp+0xE0]
00007981ddfdc5ce  add rsp, 0xF0
00007981ddfdc5d5  pop r11
00007981ddfdc5d7  pop r10
00007981ddfdc5d9  pop r9
00007981ddfdc5db  pop r8
00007981ddfdc5dd  pop rsi
00007981ddfdc5de  pop rdi
00007981ddfdc5df  pop rdx
00007981ddfdc5e0  pop rcx
00007981ddfdc5e1  pop rax
00007981ddfdc5e2  add rsp, 0x08
00007981ddfdc5e6  jmp 0x00007981DDFD9405
00007981ddfdc5eb  sub rsp, 0x08
00007981ddfdc5ef  push rax
00007981ddfdc5f0  push rcx
00007981ddfdc5f1  push rdx
00007981ddfdc5f2  push rdi
00007981ddfdc5f3  push rsi
00007981ddfdc5f4  push r8
00007981ddfdc5f6  push r9
00007981ddfdc5f8  push r10
00007981ddfdc5fa  push r11
00007981ddfdc5fc  sub rsp, 0xF0
00007981ddfdc603  vmovaps [rsp], xmm0
00007981ddfdc608  vmovaps [rsp+0x10], xmm1
00007981ddfdc60e  vmovaps [rsp+0x20], xmm2
00007981ddfdc614  vmovaps [rsp+0x30], xmm3
00007981ddfdc61a  vmovaps [rsp+0x40], xmm4
00007981ddfdc620  vmovaps [rsp+0x50], xmm5
00007981ddfdc626  vmovaps [rsp+0x60], xmm6
00007981ddfdc62c  vmovaps [rsp+0x70], xmm7
00007981ddfdc632  vmovaps [rsp+0x80], xmm8
00007981ddfdc63b  vmovaps [rsp+0x90], xmm9
00007981ddfdc644  vmovaps [rsp+0xA0], xmm11
00007981ddfdc64d  vmovaps [rsp+0xB0], xmm12
00007981ddfdc656  vmovaps [rsp+0xC0], xmm13
00007981ddfdc65f  vmovaps [rsp+0xD0], xmm14
00007981ddfdc668  vmovaps [rsp+0xE0], xmm15
00007981ddfdc671  sub rsp, 0x30
00007981ddfdc675  movaps [rsp], xmm10
00007981ddfdc67a  movaps [rsp+0x10], xmm8
00007981ddfdc680  movaps [rsp+0x20], xmm14
00007981ddfdc686  lea rdi, [rsp]
00007981ddfdc68a  mov esi, 0x00
00007981ddfdc68f  mov rax, 0x5782A6EB3530
00007981ddfdc699  call rax
00007981ddfdc69b  movaps xmm10, [rsp]
00007981ddfdc6a0  add rsp, 0x30
00007981ddfdc6a4  vmovaps xmm0, [rsp]
00007981ddfdc6a9  vmovaps xmm1, [rsp+0x10]
00007981ddfdc6af  vmovaps xmm2, [rsp+0x20]
00007981ddfdc6b5  vmovaps xmm3, [rsp+0x30]
00007981ddfdc6bb  vmovaps xmm4, [rsp+0x40]
00007981ddfdc6c1  vmovaps xmm5, [rsp+0x50]
00007981ddfdc6c7  vmovaps xmm6, [rsp+0x60]
00007981ddfdc6cd  vmovaps xmm7, [rsp+0x70]
00007981ddfdc6d3  vmovaps xmm8, [rsp+0x80]
00007981ddfdc6dc  vmovaps xmm9, [rsp+0x90]
00007981ddfdc6e5  vmovaps xmm11, [rsp+0xA0]
00007981ddfdc6ee  vmovaps xmm12, [rsp+0xB0]
00007981ddfdc6f7  vmovaps xmm13, [rsp+0xC0]
00007981ddfdc700  vmovaps xmm14, [rsp+0xD0]
00007981ddfdc709  vmovaps xmm15, [rsp+0xE0]
00007981ddfdc712  add rsp, 0xF0
00007981ddfdc719  pop r11
00007981ddfdc71b  pop r10
00007981ddfdc71d  pop r9
00007981ddfdc71f  pop r8
00007981ddfdc721  pop rsi
00007981ddfdc722  pop rdi
00007981ddfdc723  pop rdx
00007981ddfdc724  pop rcx
00007981ddfdc725  pop rax
00007981ddfdc726  add rsp, 0x08
00007981ddfdc72a  jmp 0x00007981DDFD9425
00007981ddfdc72f  sub rsp, 0x08
00007981ddfdc733  push rax
00007981ddfdc734  push rcx
00007981ddfdc735  push rdx
00007981ddfdc736  push rdi
00007981ddfdc737  push rsi
00007981ddfdc738  push r8
00007981ddfdc73a  push r9
00007981ddfdc73c  push r10
00007981ddfdc73e  push r11
00007981ddfdc740  sub rsp, 0xF0
00007981ddfdc747  vmovaps [rsp], xmm0
00007981ddfdc74c  vmovaps [rsp+0x10], xmm1
00007981ddfdc752  vmovaps [rsp+0x20], xmm2
00007981ddfdc758  vmovaps [rsp+0x30], xmm3
00007981ddfdc75e  vmovaps [rsp+0x40], xmm4
00007981ddfdc764  vmovaps [rsp+0x50], xmm5
00007981ddfdc76a  vmovaps [rsp+0x60], xmm6
00007981ddfdc770  vmovaps [rsp+0x70], xmm7
00007981ddfdc776  vmovaps [rsp+0x80], xmm8
00007981ddfdc77f  vmovaps [rsp+0x90], xmm9
00007981ddfdc788  vmovaps [rsp+0xA0], xmm10
00007981ddfdc791  vmovaps [rsp+0xB0], xmm11
00007981ddfdc79a  vmovaps [rsp+0xC0], xmm12
00007981ddfdc7a3  vmovaps [rsp+0xD0], xmm13
00007981ddfdc7ac  vmovaps [rsp+0xE0], xmm15
00007981ddfdc7b5  sub rsp, 0x30
00007981ddfdc7b9  movaps [rsp], xmm14
00007981ddfdc7be  movaps [rsp+0x10], xmm8
00007981ddfdc7c4  movaps [rsp+0x20], xmm4
00007981ddfdc7c9  lea rdi, [rsp]
00007981ddfdc7cd  mov esi, 0x00
00007981ddfdc7d2  mov rax, 0x5782A6EB3530
00007981ddfdc7dc  call rax
00007981ddfdc7de  movaps xmm14, [rsp]
00007981ddfdc7e3  add rsp, 0x30
00007981ddfdc7e7  vmovaps xmm0, [rsp]
00007981ddfdc7ec  vmovaps xmm1, [rsp+0x10]
00007981ddfdc7f2  vmovaps xmm2, [rsp+0x20]
00007981ddfdc7f8  vmovaps xmm3, [rsp+0x30]
00007981ddfdc7fe  vmovaps xmm4, [rsp+0x40]
00007981ddfdc804  vmovaps xmm5, [rsp+0x50]
00007981ddfdc80a  vmovaps xmm6, [rsp+0x60]
00007981ddfdc810  vmovaps xmm7, [rsp+0x70]
00007981ddfdc816  vmovaps xmm8, [rsp+0x80]
00007981ddfdc81f  vmovaps xmm9, [rsp+0x90]
00007981ddfdc828  vmovaps xmm10, [rsp+0xA0]
00007981ddfdc831  vmovaps xmm11, [rsp+0xB0]
00007981ddfdc83a  vmovaps xmm12, [rsp+0xC0]
00007981ddfdc843  vmovaps xmm13, [rsp+0xD0]
00007981ddfdc84c  vmovaps xmm15, [rsp+0xE0]
00007981ddfdc855  add rsp, 0xF0
00007981ddfdc85c  pop r11
00007981ddfdc85e  pop r10
00007981ddfdc860  pop r9
00007981ddfdc862  pop r8
00007981ddfdc864  pop rsi
00007981ddfdc865  pop rdi
00007981ddfdc866  pop rdx
00007981ddfdc867  pop rcx
00007981ddfdc868  pop rax
00007981ddfdc869  add rsp, 0x08
00007981ddfdc86d  jmp 0x00007981DDFD9445
00007981ddfdc872  sub rsp, 0x08
00007981ddfdc876  push rax
00007981ddfdc877  push rcx
00007981ddfdc878  push rdx
00007981ddfdc879  push rdi
00007981ddfdc87a  push rsi
00007981ddfdc87b  push r8
00007981ddfdc87d  push r9
00007981ddfdc87f  push r10
00007981ddfdc881  push r11
00007981ddfdc883  sub rsp, 0xF0
00007981ddfdc88a  vmovaps [rsp], xmm0
00007981ddfdc88f  vmovaps [rsp+0x10], xmm1
00007981ddfdc895  vmovaps [rsp+0x20], xmm2
00007981ddfdc89b  vmovaps [rsp+0x30], xmm3
00007981ddfdc8a1  vmovaps [rsp+0x40], xmm5
00007981ddfdc8a7  vmovaps [rsp+0x50], xmm6
00007981ddfdc8ad  vmovaps [rsp+0x60], xmm7
00007981ddfdc8b3  vmovaps [rsp+0x70], xmm8
00007981ddfdc8b9  vmovaps [rsp+0x80], xmm9
00007981ddfdc8c2  vmovaps [rsp+0x90], xmm10
00007981ddfdc8cb  vmovaps [rsp+0xA0], xmm11
00007981ddfdc8d4  vmovaps [rsp+0xB0], xmm12
00007981ddfdc8dd  vmovaps [rsp+0xC0], xmm13
00007981ddfdc8e6  vmovaps [rsp+0xD0], xmm14
00007981ddfdc8ef  vmovaps [rsp+0xE0], xmm15
00007981ddfdc8f8  sub rsp, 0x30
00007981ddfdc8fc  movaps [rsp], xmm4
00007981ddfdc900  movaps [rsp+0x10], xmm13
00007981ddfdc906  movaps [rsp+0x20], xmm8
00007981ddfdc90c  lea rdi, [rsp]
00007981ddfdc910  mov esi, 0x00
00007981ddfdc915  mov rax, 0x5782A6EB3530
00007981ddfdc91f  call rax
00007981ddfdc921  movaps xmm4, [rsp]
00007981ddfdc925  add rsp, 0x30
00007981ddfdc929  vmovaps xmm0, [rsp]
00007981ddfdc92e  vmovaps xmm1, [rsp+0x10]
00007981ddfdc934  vmovaps xmm2, [rsp+0x20]
00007981ddfdc93a  vmovaps xmm3, [rsp+0x30]
00007981ddfdc940  vmovaps xmm5, [rsp+0x40]
00007981ddfdc946  vmovaps xmm6, [rsp+0x50]
00007981ddfdc94c  vmovaps xmm7, [rsp+0x60]
00007981ddfdc952  vmovaps xmm8, [rsp+0x70]
00007981ddfdc958  vmovaps xmm9, [rsp+0x80]
00007981ddfdc961  vmovaps xmm10, [rsp+0x90]
00007981ddfdc96a  vmovaps xmm11, [rsp+0xA0]
00007981ddfdc973  vmovaps xmm12, [rsp+0xB0]
00007981ddfdc97c  vmovaps xmm13, [rsp+0xC0]
00007981ddfdc985  vmovaps xmm14, [rsp+0xD0]
00007981ddfdc98e  vmovaps xmm15, [rsp+0xE0]
00007981ddfdc997  add rsp, 0xF0
00007981ddfdc99e  pop r11
00007981ddfdc9a0  pop r10
00007981ddfdc9a2  pop r9
00007981ddfdc9a4  pop r8
00007981ddfdc9a6  pop rsi
00007981ddfdc9a7  pop rdi
00007981ddfdc9a8  pop rdx
00007981ddfdc9a9  pop rcx
00007981ddfdc9aa  pop rax
00007981ddfdc9ab  add rsp, 0x08
00007981ddfdc9af  jmp 0x00007981DDFD946A
00007981ddfdc9b4  sub rsp, 0x08
00007981ddfdc9b8  push rax
00007981ddfdc9b9  push rcx
00007981ddfdc9ba  push rdx
00007981ddfdc9bb  push rdi
00007981ddfdc9bc  push rsi
00007981ddfdc9bd  push r8
00007981ddfdc9bf  push r9
00007981ddfdc9c1  push r10
00007981ddfdc9c3  push r11
00007981ddfdc9c5  sub rsp, 0xF0
00007981ddfdc9cc  vmovaps [rsp], xmm0
00007981ddfdc9d1  vmovaps [rsp+0x10], xmm1
00007981ddfdc9d7  vmovaps [rsp+0x20], xmm2
00007981ddfdc9dd  vmovaps [rsp+0x30], xmm3
00007981ddfdc9e3  vmovaps [rsp+0x40], xmm4
00007981ddfdc9e9  vmovaps [rsp+0x50], xmm5
00007981ddfdc9ef  vmovaps [rsp+0x60], xmm6
00007981ddfdc9f5  vmovaps [rsp+0x70], xmm7
00007981ddfdc9fb  vmovaps [rsp+0x80], xmm8
00007981ddfdca04  vmovaps [rsp+0x90], xmm9
00007981ddfdca0d  vmovaps [rsp+0xA0], xmm10
00007981ddfdca16  vmovaps [rsp+0xB0], xmm11
00007981ddfdca1f  vmovaps [rsp+0xC0], xmm12
00007981ddfdca28  vmovaps [rsp+0xD0], xmm14
00007981ddfdca31  vmovaps [rsp+0xE0], xmm15
00007981ddfdca3a  sub rsp, 0x30
00007981ddfdca3e  movaps [rsp], xmm13
00007981ddfdca43  movaps [rsp+0x10], xmm15
00007981ddfdca49  movaps [rsp+0x20], xmm9
00007981ddfdca4f  lea rdi, [rsp]
00007981ddfdca53  mov esi, 0x00
00007981ddfdca58  mov rax, 0x5782A6EB3530
00007981ddfdca62  call rax
00007981ddfdca64  movaps xmm13, [rsp]
00007981ddfdca69  add rsp, 0x30
00007981ddfdca6d  vmovaps xmm0, [rsp]
00007981ddfdca72  vmovaps xmm1, [rsp+0x10]
00007981ddfdca78  vmovaps xmm2, [rsp+0x20]
00007981ddfdca7e  vmovaps xmm3, [rsp+0x30]
00007981ddfdca84  vmovaps xmm4, [rsp+0x40]
00007981ddfdca8a  vmovaps xmm5, [rsp+0x50]
00007981ddfdca90  vmovaps xmm6, [rsp+0x60]
00007981ddfdca96  vmovaps xmm7, [rsp+0x70]
00007981ddfdca9c  vmovaps xmm8, [rsp+0x80]
00007981ddfdcaa5  vmovaps xmm9, [rsp+0x90]
00007981ddfdcaae  vmovaps xmm10, [rsp+0xA0]
00007981ddfdcab7  vmovaps xmm11, [rsp+0xB0]
00007981ddfdcac0  vmovaps xmm12, [rsp+0xC0]
00007981ddfdcac9  vmovaps xmm14, [rsp+0xD0]
00007981ddfdcad2  vmovaps xmm15, [rsp+0xE0]
00007981ddfdcadb  add rsp, 0xF0
00007981ddfdcae2  pop r11
00007981ddfdcae4  pop r10
00007981ddfdcae6  pop r9
00007981ddfdcae8  pop r8
00007981ddfdcaea  pop rsi
00007981ddfdcaeb  pop rdi
00007981ddfdcaec  pop rdx
00007981ddfdcaed  pop rcx
00007981ddfdcaee  pop rax
00007981ddfdcaef  add rsp, 0x08
00007981ddfdcaf3  jmp 0x00007981DDFD9485
00007981ddfdcaf8  sub rsp, 0x08
00007981ddfdcafc  push rax
00007981ddfdcafd  push rcx
00007981ddfdcafe  push rdx
00007981ddfdcaff  push rdi
00007981ddfdcb00  push rsi
00007981ddfdcb01  push r8
00007981ddfdcb03  push r9
00007981ddfdcb05  push r10
00007981ddfdcb07  push r11
00007981ddfdcb09  sub rsp, 0xF0
00007981ddfdcb10  vmovaps [rsp], xmm0
00007981ddfdcb15  vmovaps [rsp+0x10], xmm1
00007981ddfdcb1b  vmovaps [rsp+0x20], xmm2
00007981ddfdcb21  vmovaps [rsp+0x30], xmm3
00007981ddfdcb27  vmovaps [rsp+0x40], xmm4
00007981ddfdcb2d  vmovaps [rsp+0x50], xmm5
00007981ddfdcb33  vmovaps [rsp+0x60], xmm6
00007981ddfdcb39  vmovaps [rsp+0x70], xmm7
00007981ddfdcb3f  vmovaps [rsp+0x80], xmm8
00007981ddfdcb48  vmovaps [rsp+0x90], xmm9
00007981ddfdcb51  vmovaps [rsp+0xA0], xmm10
00007981ddfdcb5a  vmovaps [rsp+0xB0], xmm11
00007981ddfdcb63  vmovaps [rsp+0xC0], xmm12
00007981ddfdcb6c  vmovaps [rsp+0xD0], xmm13
00007981ddfdcb75  vmovaps [rsp+0xE0], xmm14
00007981ddfdcb7e  sub rsp, 0x30
00007981ddfdcb82  movaps [rsp], xmm15
00007981ddfdcb87  movaps [rsp+0x10], xmm1
00007981ddfdcb8c  movaps [rsp+0x20], xmm5
00007981ddfdcb91  lea rdi, [rsp]
00007981ddfdcb95  mov esi, 0x00
00007981ddfdcb9a  mov rax, 0x5782A6EB3530
00007981ddfdcba4  call rax
00007981ddfdcba6  movaps xmm15, [rsp]
00007981ddfdcbab  add rsp, 0x30
00007981ddfdcbaf  vmovaps xmm0, [rsp]
00007981ddfdcbb4  vmovaps xmm1, [rsp+0x10]
00007981ddfdcbba  vmovaps xmm2, [rsp+0x20]
00007981ddfdcbc0  vmovaps xmm3, [rsp+0x30]
00007981ddfdcbc6  vmovaps xmm4, [rsp+0x40]
00007981ddfdcbcc  vmovaps xmm5, [rsp+0x50]
00007981ddfdcbd2  vmovaps xmm6, [rsp+0x60]
00007981ddfdcbd8  vmovaps xmm7, [rsp+0x70]
00007981ddfdcbde  vmovaps xmm8, [rsp+0x80]
00007981ddfdcbe7  vmovaps xmm9, [rsp+0x90]
00007981ddfdcbf0  vmovaps xmm10, [rsp+0xA0]
00007981ddfdcbf9  vmovaps xmm11, [rsp+0xB0]
00007981ddfdcc02  vmovaps xmm12, [rsp+0xC0]
00007981ddfdcc0b  vmovaps xmm13, [rsp+0xD0]
00007981ddfdcc14  vmovaps xmm14, [rsp+0xE0]
00007981ddfdcc1d  add rsp, 0xF0
00007981ddfdcc24  pop r11
00007981ddfdcc26  pop r10
00007981ddfdcc28  pop r9
00007981ddfdcc2a  pop r8
00007981ddfdcc2c  pop rsi
00007981ddfdcc2d  pop rdi
00007981ddfdcc2e  pop rdx
00007981ddfdcc2f  pop rcx
00007981ddfdcc30  pop rax
00007981ddfdcc31  add rsp, 0x08
00007981ddfdcc35  jmp 0x00007981DDFD94A0
00007981ddfdcc3a  call 0x00007981DDED64F0
00007981ddfdcc3f  jmp 0x00007981DDFD94FB
00007981ddfdcc44  sub rsp, 0x08
00007981ddfdcc48  push rax
00007981ddfdcc49  push rcx
00007981ddfdcc4a  push rdx
00007981ddfdcc4b  push rdi
00007981ddfdcc4c  push rsi
00007981ddfdcc4d  push r8
00007981ddfdcc4f  push r9
00007981ddfdcc51  push r10
00007981ddfdcc53  push r11
00007981ddfdcc55  sub rsp, 0xF0
00007981ddfdcc5c  vmovaps [rsp], xmm0
00007981ddfdcc61  vmovaps [rsp+0x10], xmm1
00007981ddfdcc67  vmovaps [rsp+0x20], xmm2
00007981ddfdcc6d  vmovaps [rsp+0x30], xmm3
00007981ddfdcc73  vmovaps [rsp+0x40], xmm4
00007981ddfdcc79  vmovaps [rsp+0x50], xmm5
00007981ddfdcc7f  vmovaps [rsp+0x60], xmm6
00007981ddfdcc85  vmovaps [rsp+0x70], xmm7
00007981ddfdcc8b  vmovaps [rsp+0x80], xmm8
00007981ddfdcc94  vmovaps [rsp+0x90], xmm10
00007981ddfdcc9d  vmovaps [rsp+0xA0], xmm11
00007981ddfdcca6  vmovaps [rsp+0xB0], xmm12
00007981ddfdccaf  vmovaps [rsp+0xC0], xmm13
00007981ddfdccb8  vmovaps [rsp+0xD0], xmm14
00007981ddfdccc1  vmovaps [rsp+0xE0], xmm15
00007981ddfdccca  sub rsp, 0x30
00007981ddfdccce  movaps [rsp], xmm9
00007981ddfdccd3  movaps [rsp+0x10], xmm8
00007981ddfdccd9  movaps [rsp+0x20], xmm11
00007981ddfdccdf  lea rdi, [rsp]
00007981ddfdcce3  mov esi, 0x00
00007981ddfdcce8  mov rax, 0x5782A6EB3530
00007981ddfdccf2  call rax
00007981ddfdccf4  movaps xmm9, [rsp]
00007981ddfdccf9  add rsp, 0x30
00007981ddfdccfd  vmovaps xmm0, [rsp]
00007981ddfdcd02  vmovaps xmm1, [rsp+0x10]
00007981ddfdcd08  vmovaps xmm2, [rsp+0x20]
00007981ddfdcd0e  vmovaps xmm3, [rsp+0x30]
00007981ddfdcd14  vmovaps xmm4, [rsp+0x40]
00007981ddfdcd1a  vmovaps xmm5, [rsp+0x50]
00007981ddfdcd20  vmovaps xmm6, [rsp+0x60]
00007981ddfdcd26  vmovaps xmm7, [rsp+0x70]
00007981ddfdcd2c  vmovaps xmm8, [rsp+0x80]
00007981ddfdcd35  vmovaps xmm10, [rsp+0x90]
00007981ddfdcd3e  vmovaps xmm11, [rsp+0xA0]
00007981ddfdcd47  vmovaps xmm12, [rsp+0xB0]
00007981ddfdcd50  vmovaps xmm13, [rsp+0xC0]
00007981ddfdcd59  vmovaps xmm14, [rsp+0xD0]
00007981ddfdcd62  vmovaps xmm15, [rsp+0xE0]
00007981ddfdcd6b  add rsp, 0xF0
00007981ddfdcd72  pop r11
00007981ddfdcd74  pop r10
00007981ddfdcd76  pop r9
00007981ddfdcd78  pop r8
00007981ddfdcd7a  pop rsi
00007981ddfdcd7b  pop rdi
00007981ddfdcd7c  pop rdx
00007981ddfdcd7d  pop rcx
00007981ddfdcd7e  pop rax
00007981ddfdcd7f  add rsp, 0x08
00007981ddfdcd83  jmp 0x00007981DDFD9532
00007981ddfdcd88  sub rsp, 0x08
00007981ddfdcd8c  push rax
00007981ddfdcd8d  push rcx
00007981ddfdcd8e  push rdx
00007981ddfdcd8f  push rdi
00007981ddfdcd90  push rsi
00007981ddfdcd91  push r8
00007981ddfdcd93  push r9
00007981ddfdcd95  push r10
00007981ddfdcd97  push r11
00007981ddfdcd99  sub rsp, 0xF0
00007981ddfdcda0  vmovaps [rsp], xmm0
00007981ddfdcda5  vmovaps [rsp+0x10], xmm1
00007981ddfdcdab  vmovaps [rsp+0x20], xmm2
00007981ddfdcdb1  vmovaps [rsp+0x30], xmm3
00007981ddfdcdb7  vmovaps [rsp+0x40], xmm4
00007981ddfdcdbd  vmovaps [rsp+0x50], xmm5
00007981ddfdcdc3  vmovaps [rsp+0x60], xmm6
00007981ddfdcdc9  vmovaps [rsp+0x70], xmm7
00007981ddfdcdcf  vmovaps [rsp+0x80], xmm8
00007981ddfdcdd8  vmovaps [rsp+0x90], xmm9
00007981ddfdcde1  vmovaps [rsp+0xA0], xmm10
00007981ddfdcdea  vmovaps [rsp+0xB0], xmm12
00007981ddfdcdf3  vmovaps [rsp+0xC0], xmm13
00007981ddfdcdfc  vmovaps [rsp+0xD0], xmm14
00007981ddfdce05  vmovaps [rsp+0xE0], xmm15
00007981ddfdce0e  sub rsp, 0x30
00007981ddfdce12  movaps [rsp], xmm11
00007981ddfdce17  movaps [rsp+0x10], xmm10
00007981ddfdce1d  movaps [rsp+0x20], xmm6
00007981ddfdce22  lea rdi, [rsp]
00007981ddfdce26  mov esi, 0x00
00007981ddfdce2b  mov rax, 0x5782A6EB3530
00007981ddfdce35  call rax
00007981ddfdce37  movaps xmm11, [rsp]
00007981ddfdce3c  add rsp, 0x30
00007981ddfdce40  vmovaps xmm0, [rsp]
00007981ddfdce45  vmovaps xmm1, [rsp+0x10]
00007981ddfdce4b  vmovaps xmm2, [rsp+0x20]
00007981ddfdce51  vmovaps xmm3, [rsp+0x30]
00007981ddfdce57  vmovaps xmm4, [rsp+0x40]
00007981ddfdce5d  vmovaps xmm5, [rsp+0x50]
00007981ddfdce63  vmovaps xmm6, [rsp+0x60]
00007981ddfdce69  vmovaps xmm7, [rsp+0x70]
00007981ddfdce6f  vmovaps xmm8, [rsp+0x80]
00007981ddfdce78  vmovaps xmm9, [rsp+0x90]
00007981ddfdce81  vmovaps xmm10, [rsp+0xA0]
00007981ddfdce8a  vmovaps xmm12, [rsp+0xB0]
00007981ddfdce93  vmovaps xmm13, [rsp+0xC0]
00007981ddfdce9c  vmovaps xmm14, [rsp+0xD0]
00007981ddfdcea5  vmovaps xmm15, [rsp+0xE0]
00007981ddfdceae  add rsp, 0xF0
00007981ddfdceb5  pop r11
00007981ddfdceb7  pop r10
00007981ddfdceb9  pop r9
00007981ddfdcebb  pop r8
00007981ddfdcebd  pop rsi
00007981ddfdcebe  pop rdi
00007981ddfdcebf  pop rdx
00007981ddfdcec0  pop rcx
00007981ddfdcec1  pop rax
00007981ddfdcec2  add rsp, 0x08
00007981ddfdcec6  jmp 0x00007981DDFD954D
00007981ddfdcecb  sub rsp, 0x08
00007981ddfdcecf  push rax
00007981ddfdced0  push rcx
00007981ddfdced1  push rdx
00007981ddfdced2  push rdi
00007981ddfdced3  push rsi
00007981ddfdced4  push r8
00007981ddfdced6  push r9
00007981ddfdced8  push r10
00007981ddfdceda  push r11
00007981ddfdcedc  sub rsp, 0xF0
00007981ddfdcee3  vmovaps [rsp], xmm0
00007981ddfdcee8  vmovaps [rsp+0x10], xmm1
00007981ddfdceee  vmovaps [rsp+0x20], xmm2
00007981ddfdcef4  vmovaps [rsp+0x30], xmm3
00007981ddfdcefa  vmovaps [rsp+0x40], xmm4
00007981ddfdcf00  vmovaps [rsp+0x50], xmm5
00007981ddfdcf06  vmovaps [rsp+0x60], xmm6
00007981ddfdcf0c  vmovaps [rsp+0x70], xmm7
00007981ddfdcf12  vmovaps [rsp+0x80], xmm8
00007981ddfdcf1b  vmovaps [rsp+0x90], xmm9
00007981ddfdcf24  vmovaps [rsp+0xA0], xmm11
00007981ddfdcf2d  vmovaps [rsp+0xB0], xmm12
00007981ddfdcf36  vmovaps [rsp+0xC0], xmm13
00007981ddfdcf3f  vmovaps [rsp+0xD0], xmm14
00007981ddfdcf48  vmovaps [rsp+0xE0], xmm15
00007981ddfdcf51  sub rsp, 0x30
00007981ddfdcf55  movaps [rsp], xmm10
00007981ddfdcf5a  movaps [rsp+0x10], xmm14
00007981ddfdcf60  movaps [rsp+0x20], xmm4
00007981ddfdcf65  lea rdi, [rsp]
00007981ddfdcf69  mov esi, 0x00
00007981ddfdcf6e  mov rax, 0x5782A6EB3530
00007981ddfdcf78  call rax
00007981ddfdcf7a  movaps xmm10, [rsp]
00007981ddfdcf7f  add rsp, 0x30
00007981ddfdcf83  vmovaps xmm0, [rsp]
00007981ddfdcf88  vmovaps xmm1, [rsp+0x10]
00007981ddfdcf8e  vmovaps xmm2, [rsp+0x20]
00007981ddfdcf94  vmovaps xmm3, [rsp+0x30]
00007981ddfdcf9a  vmovaps xmm4, [rsp+0x40]
00007981ddfdcfa0  vmovaps xmm5, [rsp+0x50]
00007981ddfdcfa6  vmovaps xmm6, [rsp+0x60]
00007981ddfdcfac  vmovaps xmm7, [rsp+0x70]
00007981ddfdcfb2  vmovaps xmm8, [rsp+0x80]
00007981ddfdcfbb  vmovaps xmm9, [rsp+0x90]
00007981ddfdcfc4  vmovaps xmm11, [rsp+0xA0]
00007981ddfdcfcd  vmovaps xmm12, [rsp+0xB0]
00007981ddfdcfd6  vmovaps xmm13, [rsp+0xC0]
00007981ddfdcfdf  vmovaps xmm14, [rsp+0xD0]
00007981ddfdcfe8  vmovaps xmm15, [rsp+0xE0]
00007981ddfdcff1  add rsp, 0xF0
00007981ddfdcff8  pop r11
00007981ddfdcffa  pop r10
00007981ddfdcffc  pop r9
00007981ddfdcffe  pop r8
00007981ddfdd000  pop rsi
00007981ddfdd001  pop rdi
00007981ddfdd002  pop rdx
00007981ddfdd003  pop rcx
00007981ddfdd004  pop rax
00007981ddfdd005  add rsp, 0x08
00007981ddfdd009  jmp 0x00007981DDFD9568
00007981ddfdd00e  sub rsp, 0x08
00007981ddfdd012  push rax
00007981ddfdd013  push rcx
00007981ddfdd014  push rdx
00007981ddfdd015  push rdi
00007981ddfdd016  push rsi
00007981ddfdd017  push r8
00007981ddfdd019  push r9
00007981ddfdd01b  push r10
00007981ddfdd01d  push r11
00007981ddfdd01f  sub rsp, 0xF0
00007981ddfdd026  vmovaps [rsp], xmm0
00007981ddfdd02b  vmovaps [rsp+0x10], xmm1
00007981ddfdd031  vmovaps [rsp+0x20], xmm2
00007981ddfdd037  vmovaps [rsp+0x30], xmm3
00007981ddfdd03d  vmovaps [rsp+0x40], xmm4
00007981ddfdd043  vmovaps [rsp+0x50], xmm5
00007981ddfdd049  vmovaps [rsp+0x60], xmm6
00007981ddfdd04f  vmovaps [rsp+0x70], xmm7
00007981ddfdd055  vmovaps [rsp+0x80], xmm9
00007981ddfdd05e  vmovaps [rsp+0x90], xmm10
00007981ddfdd067  vmovaps [rsp+0xA0], xmm11
00007981ddfdd070  vmovaps [rsp+0xB0], xmm12
00007981ddfdd079  vmovaps [rsp+0xC0], xmm13
00007981ddfdd082  vmovaps [rsp+0xD0], xmm14
00007981ddfdd08b  vmovaps [rsp+0xE0], xmm15
00007981ddfdd094  sub rsp, 0x30
00007981ddfdd098  movaps [rsp], xmm8
00007981ddfdd09d  movaps [rsp+0x10], xmm1
00007981ddfdd0a2  movaps [rsp+0x20], xmm14
00007981ddfdd0a8  lea rdi, [rsp]
00007981ddfdd0ac  mov esi, 0x00
00007981ddfdd0b1  mov rax, 0x5782A6EB3530
00007981ddfdd0bb  call rax
00007981ddfdd0bd  movaps xmm8, [rsp]
00007981ddfdd0c2  add rsp, 0x30
00007981ddfdd0c6  vmovaps xmm0, [rsp]
00007981ddfdd0cb  vmovaps xmm1, [rsp+0x10]
00007981ddfdd0d1  vmovaps xmm2, [rsp+0x20]
00007981ddfdd0d7  vmovaps xmm3, [rsp+0x30]
00007981ddfdd0dd  vmovaps xmm4, [rsp+0x40]
00007981ddfdd0e3  vmovaps xmm5, [rsp+0x50]
00007981ddfdd0e9  vmovaps xmm6, [rsp+0x60]
00007981ddfdd0ef  vmovaps xmm7, [rsp+0x70]
00007981ddfdd0f5  vmovaps xmm9, [rsp+0x80]
00007981ddfdd0fe  vmovaps xmm10, [rsp+0x90]
00007981ddfdd107  vmovaps xmm11, [rsp+0xA0]
00007981ddfdd110  vmovaps xmm12, [rsp+0xB0]
00007981ddfdd119  vmovaps xmm13, [rsp+0xC0]
00007981ddfdd122  vmovaps xmm14, [rsp+0xD0]
00007981ddfdd12b  vmovaps xmm15, [rsp+0xE0]
00007981ddfdd134  add rsp, 0xF0
00007981ddfdd13b  pop r11
00007981ddfdd13d  pop r10
00007981ddfdd13f  pop r9
00007981ddfdd141  pop r8
00007981ddfdd143  pop rsi
00007981ddfdd144  pop rdi
00007981ddfdd145  pop rdx
00007981ddfdd146  pop rcx
00007981ddfdd147  pop rax
00007981ddfdd148  add rsp, 0x08
00007981ddfdd14c  jmp 0x00007981DDFD958E
00007981ddfdd151  sub rsp, 0x08
00007981ddfdd155  push rax
00007981ddfdd156  push rcx
00007981ddfdd157  push rdx
00007981ddfdd158  push rdi
00007981ddfdd159  push rsi
00007981ddfdd15a  push r8
00007981ddfdd15c  push r9
00007981ddfdd15e  push r10
00007981ddfdd160  push r11
00007981ddfdd162  sub rsp, 0xF0
00007981ddfdd169  vmovaps [rsp], xmm0
00007981ddfdd16e  vmovaps [rsp+0x10], xmm1
00007981ddfdd174  vmovaps [rsp+0x20], xmm2
00007981ddfdd17a  vmovaps [rsp+0x30], xmm3
00007981ddfdd180  vmovaps [rsp+0x40], xmm4
00007981ddfdd186  vmovaps [rsp+0x50], xmm5
00007981ddfdd18c  vmovaps [rsp+0x60], xmm7
00007981ddfdd192  vmovaps [rsp+0x70], xmm8
00007981ddfdd198  vmovaps [rsp+0x80], xmm9
00007981ddfdd1a1  vmovaps [rsp+0x90], xmm10
00007981ddfdd1aa  vmovaps [rsp+0xA0], xmm11
00007981ddfdd1b3  vmovaps [rsp+0xB0], xmm12
00007981ddfdd1bc  vmovaps [rsp+0xC0], xmm13
00007981ddfdd1c5  vmovaps [rsp+0xD0], xmm14
00007981ddfdd1ce  vmovaps [rsp+0xE0], xmm15
00007981ddfdd1d7  sub rsp, 0x30
00007981ddfdd1db  movaps [rsp], xmm6
00007981ddfdd1df  movaps [rsp+0x10], xmm1
00007981ddfdd1e4  movaps [rsp+0x20], xmm14
00007981ddfdd1ea  lea rdi, [rsp]
00007981ddfdd1ee  mov esi, 0x00
00007981ddfdd1f3  mov rax, 0x5782A6EB3530
00007981ddfdd1fd  call rax
00007981ddfdd1ff  movaps xmm6, [rsp]
00007981ddfdd203  add rsp, 0x30
00007981ddfdd207  vmovaps xmm0, [rsp]
00007981ddfdd20c  vmovaps xmm1, [rsp+0x10]
00007981ddfdd212  vmovaps xmm2, [rsp+0x20]
00007981ddfdd218  vmovaps xmm3, [rsp+0x30]
00007981ddfdd21e  vmovaps xmm4, [rsp+0x40]
00007981ddfdd224  vmovaps xmm5, [rsp+0x50]
00007981ddfdd22a  vmovaps xmm7, [rsp+0x60]
00007981ddfdd230  vmovaps xmm8, [rsp+0x70]
00007981ddfdd236  vmovaps xmm9, [rsp+0x80]
00007981ddfdd23f  vmovaps xmm10, [rsp+0x90]
00007981ddfdd248  vmovaps xmm11, [rsp+0xA0]
00007981ddfdd251  vmovaps xmm12, [rsp+0xB0]
00007981ddfdd25a  vmovaps xmm13, [rsp+0xC0]
00007981ddfdd263  vmovaps xmm14, [rsp+0xD0]
00007981ddfdd26c  vmovaps xmm15, [rsp+0xE0]
00007981ddfdd275  add rsp, 0xF0
00007981ddfdd27c  pop r11
00007981ddfdd27e  pop r10
00007981ddfdd280  pop r9
00007981ddfdd282  pop r8
00007981ddfdd284  pop rsi
00007981ddfdd285  pop rdi
00007981ddfdd286  pop rdx
00007981ddfdd287  pop rcx
00007981ddfdd288  pop rax
00007981ddfdd289  add rsp, 0x08
00007981ddfdd28d  jmp 0x00007981DDFD95BA
00007981ddfdd292  sub rsp, 0x08
00007981ddfdd296  push rax
00007981ddfdd297  push rcx
00007981ddfdd298  push rdx
00007981ddfdd299  push rdi
00007981ddfdd29a  push rsi
00007981ddfdd29b  push r8
00007981ddfdd29d  push r9
00007981ddfdd29f  push r10
00007981ddfdd2a1  push r11
00007981ddfdd2a3  sub rsp, 0xF0
00007981ddfdd2aa  vmovaps [rsp], xmm0
00007981ddfdd2af  vmovaps [rsp+0x10], xmm1
00007981ddfdd2b5  vmovaps [rsp+0x20], xmm2
00007981ddfdd2bb  vmovaps [rsp+0x30], xmm3
00007981ddfdd2c1  vmovaps [rsp+0x40], xmm4
00007981ddfdd2c7  vmovaps [rsp+0x50], xmm5
00007981ddfdd2cd  vmovaps [rsp+0x60], xmm6
00007981ddfdd2d3  vmovaps [rsp+0x70], xmm7
00007981ddfdd2d9  vmovaps [rsp+0x80], xmm8
00007981ddfdd2e2  vmovaps [rsp+0x90], xmm9
00007981ddfdd2eb  vmovaps [rsp+0xA0], xmm10
00007981ddfdd2f4  vmovaps [rsp+0xB0], xmm11
00007981ddfdd2fd  vmovaps [rsp+0xC0], xmm12
00007981ddfdd306  vmovaps [rsp+0xD0], xmm13
00007981ddfdd30f  vmovaps [rsp+0xE0], xmm15
00007981ddfdd318  sub rsp, 0x30
00007981ddfdd31c  movaps [rsp], xmm14
00007981ddfdd321  movaps [rsp+0x10], xmm12
00007981ddfdd327  movaps [rsp+0x20], xmm1
00007981ddfdd32c  lea rdi, [rsp]
00007981ddfdd330  mov esi, 0x00
00007981ddfdd335  mov rax, 0x5782A6EB3530
00007981ddfdd33f  call rax
00007981ddfdd341  movaps xmm14, [rsp]
00007981ddfdd346  add rsp, 0x30
00007981ddfdd34a  vmovaps xmm0, [rsp]
00007981ddfdd34f  vmovaps xmm1, [rsp+0x10]
00007981ddfdd355  vmovaps xmm2, [rsp+0x20]
00007981ddfdd35b  vmovaps xmm3, [rsp+0x30]
00007981ddfdd361  vmovaps xmm4, [rsp+0x40]
00007981ddfdd367  vmovaps xmm5, [rsp+0x50]
00007981ddfdd36d  vmovaps xmm6, [rsp+0x60]
00007981ddfdd373  vmovaps xmm7, [rsp+0x70]
00007981ddfdd379  vmovaps xmm8, [rsp+0x80]
00007981ddfdd382  vmovaps xmm9, [rsp+0x90]
00007981ddfdd38b  vmovaps xmm10, [rsp+0xA0]
00007981ddfdd394  vmovaps xmm11, [rsp+0xB0]
00007981ddfdd39d  vmovaps xmm12, [rsp+0xC0]
00007981ddfdd3a6  vmovaps xmm13, [rsp+0xD0]
00007981ddfdd3af  vmovaps xmm15, [rsp+0xE0]
00007981ddfdd3b8  add rsp, 0xF0
00007981ddfdd3bf  pop r11
00007981ddfdd3c1  pop r10
00007981ddfdd3c3  pop r9
00007981ddfdd3c5  pop r8
00007981ddfdd3c7  pop rsi
00007981ddfdd3c8  pop rdi
00007981ddfdd3c9  pop rdx
00007981ddfdd3ca  pop rcx
00007981ddfdd3cb  pop rax
00007981ddfdd3cc  add rsp, 0x08
00007981ddfdd3d0  jmp 0x00007981DDFD95E0
00007981ddfdd3d5  sub rsp, 0x08
00007981ddfdd3d9  push rax
00007981ddfdd3da  push rcx
00007981ddfdd3db  push rdx
00007981ddfdd3dc  push rdi
00007981ddfdd3dd  push rsi
00007981ddfdd3de  push r8
00007981ddfdd3e0  push r9
00007981ddfdd3e2  push r10
00007981ddfdd3e4  push r11
00007981ddfdd3e6  sub rsp, 0xF0
00007981ddfdd3ed  vmovaps [rsp], xmm0
00007981ddfdd3f2  vmovaps [rsp+0x10], xmm2
00007981ddfdd3f8  vmovaps [rsp+0x20], xmm3
00007981ddfdd3fe  vmovaps [rsp+0x30], xmm4
00007981ddfdd404  vmovaps [rsp+0x40], xmm5
00007981ddfdd40a  vmovaps [rsp+0x50], xmm6
00007981ddfdd410  vmovaps [rsp+0x60], xmm7
00007981ddfdd416  vmovaps [rsp+0x70], xmm8
00007981ddfdd41c  vmovaps [rsp+0x80], xmm9
00007981ddfdd425  vmovaps [rsp+0x90], xmm10
00007981ddfdd42e  vmovaps [rsp+0xA0], xmm11
00007981ddfdd437  vmovaps [rsp+0xB0], xmm12
00007981ddfdd440  vmovaps [rsp+0xC0], xmm13
00007981ddfdd449  vmovaps [rsp+0xD0], xmm14
00007981ddfdd452  vmovaps [rsp+0xE0], xmm15
00007981ddfdd45b  sub rsp, 0x30
00007981ddfdd45f  movaps [rsp], xmm1
00007981ddfdd463  movaps [rsp+0x10], xmm13
00007981ddfdd469  movaps [rsp+0x20], xmm9
00007981ddfdd46f  lea rdi, [rsp]
00007981ddfdd473  mov esi, 0x00
00007981ddfdd478  mov rax, 0x5782A6EB3530
00007981ddfdd482  call rax
00007981ddfdd484  movaps xmm1, [rsp]
00007981ddfdd488  add rsp, 0x30
00007981ddfdd48c  vmovaps xmm0, [rsp]
00007981ddfdd491  vmovaps xmm2, [rsp+0x10]
00007981ddfdd497  vmovaps xmm3, [rsp+0x20]
00007981ddfdd49d  vmovaps xmm4, [rsp+0x30]
00007981ddfdd4a3  vmovaps xmm5, [rsp+0x40]
00007981ddfdd4a9  vmovaps xmm6, [rsp+0x50]
00007981ddfdd4af  vmovaps xmm7, [rsp+0x60]
00007981ddfdd4b5  vmovaps xmm8, [rsp+0x70]
00007981ddfdd4bb  vmovaps xmm9, [rsp+0x80]
00007981ddfdd4c4  vmovaps xmm10, [rsp+0x90]
00007981ddfdd4cd  vmovaps xmm11, [rsp+0xA0]
00007981ddfdd4d6  vmovaps xmm12, [rsp+0xB0]
00007981ddfdd4df  vmovaps xmm13, [rsp+0xC0]
00007981ddfdd4e8  vmovaps xmm14, [rsp+0xD0]
00007981ddfdd4f1  vmovaps xmm15, [rsp+0xE0]
00007981ddfdd4fa  add rsp, 0xF0
00007981ddfdd501  pop r11
00007981ddfdd503  pop r10
00007981ddfdd505  pop r9
00007981ddfdd507  pop r8
00007981ddfdd509  pop rsi
00007981ddfdd50a  pop rdi
00007981ddfdd50b  pop rdx
00007981ddfdd50c  pop rcx
00007981ddfdd50d  pop rax
00007981ddfdd50e  add rsp, 0x08
00007981ddfdd512  jmp 0x00007981DDFD95FA
00007981ddfdd517  sub rsp, 0x08
00007981ddfdd51b  push rax
00007981ddfdd51c  push rcx
00007981ddfdd51d  push rdx
00007981ddfdd51e  push rdi
00007981ddfdd51f  push rsi
00007981ddfdd520  push r8
00007981ddfdd522  push r9
00007981ddfdd524  push r10
00007981ddfdd526  push r11
00007981ddfdd528  sub rsp, 0xF0
00007981ddfdd52f  vmovaps [rsp], xmm0
00007981ddfdd534  vmovaps [rsp+0x10], xmm1
00007981ddfdd53a  vmovaps [rsp+0x20], xmm2
00007981ddfdd540  vmovaps [rsp+0x30], xmm3
00007981ddfdd546  vmovaps [rsp+0x40], xmm4
00007981ddfdd54c  vmovaps [rsp+0x50], xmm5
00007981ddfdd552  vmovaps [rsp+0x60], xmm6
00007981ddfdd558  vmovaps [rsp+0x70], xmm7
00007981ddfdd55e  vmovaps [rsp+0x80], xmm8
00007981ddfdd567  vmovaps [rsp+0x90], xmm9
00007981ddfdd570  vmovaps [rsp+0xA0], xmm10
00007981ddfdd579  vmovaps [rsp+0xB0], xmm11
00007981ddfdd582  vmovaps [rsp+0xC0], xmm13
00007981ddfdd58b  vmovaps [rsp+0xD0], xmm14
00007981ddfdd594  vmovaps [rsp+0xE0], xmm15
00007981ddfdd59d  sub rsp, 0x30
00007981ddfdd5a1  movaps [rsp], xmm12
00007981ddfdd5a6  movaps [rsp+0x10], xmm7
00007981ddfdd5ab  movaps [rsp+0x20], xmm13
00007981ddfdd5b1  lea rdi, [rsp]
00007981ddfdd5b5  mov esi, 0x00
00007981ddfdd5ba  mov rax, 0x5782A6EB3530
00007981ddfdd5c4  call rax
00007981ddfdd5c6  movaps xmm12, [rsp]
00007981ddfdd5cb  add rsp, 0x30
00007981ddfdd5cf  vmovaps xmm0, [rsp]
00007981ddfdd5d4  vmovaps xmm1, [rsp+0x10]
00007981ddfdd5da  vmovaps xmm2, [rsp+0x20]
00007981ddfdd5e0  vmovaps xmm3, [rsp+0x30]
00007981ddfdd5e6  vmovaps xmm4, [rsp+0x40]
00007981ddfdd5ec  vmovaps xmm5, [rsp+0x50]
00007981ddfdd5f2  vmovaps xmm6, [rsp+0x60]
00007981ddfdd5f8  vmovaps xmm7, [rsp+0x70]
00007981ddfdd5fe  vmovaps xmm8, [rsp+0x80]
00007981ddfdd607  vmovaps xmm9, [rsp+0x90]
00007981ddfdd610  vmovaps xmm10, [rsp+0xA0]
00007981ddfdd619  vmovaps xmm11, [rsp+0xB0]
00007981ddfdd622  vmovaps xmm13, [rsp+0xC0]
00007981ddfdd62b  vmovaps xmm14, [rsp+0xD0]
00007981ddfdd634  vmovaps xmm15, [rsp+0xE0]
00007981ddfdd63d  add rsp, 0xF0
00007981ddfdd644  pop r11
00007981ddfdd646  pop r10
00007981ddfdd648  pop r9
00007981ddfdd64a  pop r8
00007981ddfdd64c  pop rsi
00007981ddfdd64d  pop rdi
00007981ddfdd64e  pop rdx
00007981ddfdd64f  pop rcx
00007981ddfdd650  pop rax
00007981ddfdd651  add rsp, 0x08
00007981ddfdd655  jmp 0x00007981DDFD9621
00007981ddfdd65a  sub rsp, 0x08
00007981ddfdd65e  push rax
00007981ddfdd65f  push rcx
00007981ddfdd660  push rdx
00007981ddfdd661  push rdi
00007981ddfdd662  push rsi
00007981ddfdd663  push r8
00007981ddfdd665  push r9
00007981ddfdd667  push r10
00007981ddfdd669  push r11
00007981ddfdd66b  sub rsp, 0xF0
00007981ddfdd672  vmovaps [rsp], xmm0
00007981ddfdd677  vmovaps [rsp+0x10], xmm1
00007981ddfdd67d  vmovaps [rsp+0x20], xmm2
00007981ddfdd683  vmovaps [rsp+0x30], xmm3
00007981ddfdd689  vmovaps [rsp+0x40], xmm4
00007981ddfdd68f  vmovaps [rsp+0x50], xmm5
00007981ddfdd695  vmovaps [rsp+0x60], xmm6
00007981ddfdd69b  vmovaps [rsp+0x70], xmm7
00007981ddfdd6a1  vmovaps [rsp+0x80], xmm8
00007981ddfdd6aa  vmovaps [rsp+0x90], xmm9
00007981ddfdd6b3  vmovaps [rsp+0xA0], xmm10
00007981ddfdd6bc  vmovaps [rsp+0xB0], xmm11
00007981ddfdd6c5  vmovaps [rsp+0xC0], xmm12
00007981ddfdd6ce  vmovaps [rsp+0xD0], xmm14
00007981ddfdd6d7  vmovaps [rsp+0xE0], xmm15
00007981ddfdd6e0  sub rsp, 0x30
00007981ddfdd6e4  movaps [rsp], xmm13
00007981ddfdd6e9  movaps [rsp+0x10], xmm15
00007981ddfdd6ef  movaps [rsp+0x20], xmm8
00007981ddfdd6f5  lea rdi, [rsp]
00007981ddfdd6f9  mov esi, 0x00
00007981ddfdd6fe  mov rax, 0x5782A6EB3530
00007981ddfdd708  call rax
00007981ddfdd70a  movaps xmm13, [rsp]
00007981ddfdd70f  add rsp, 0x30
00007981ddfdd713  vmovaps xmm0, [rsp]
00007981ddfdd718  vmovaps xmm1, [rsp+0x10]
00007981ddfdd71e  vmovaps xmm2, [rsp+0x20]
00007981ddfdd724  vmovaps xmm3, [rsp+0x30]
00007981ddfdd72a  vmovaps xmm4, [rsp+0x40]
00007981ddfdd730  vmovaps xmm5, [rsp+0x50]
00007981ddfdd736  vmovaps xmm6, [rsp+0x60]
00007981ddfdd73c  vmovaps xmm7, [rsp+0x70]
00007981ddfdd742  vmovaps xmm8, [rsp+0x80]
00007981ddfdd74b  vmovaps xmm9, [rsp+0x90]
00007981ddfdd754  vmovaps xmm10, [rsp+0xA0]
00007981ddfdd75d  vmovaps xmm11, [rsp+0xB0]
00007981ddfdd766  vmovaps xmm12, [rsp+0xC0]
00007981ddfdd76f  vmovaps xmm14, [rsp+0xD0]
00007981ddfdd778  vmovaps xmm15, [rsp+0xE0]
00007981ddfdd781  add rsp, 0xF0
00007981ddfdd788  pop r11
00007981ddfdd78a  pop r10
00007981ddfdd78c  pop r9
00007981ddfdd78e  pop r8
00007981ddfdd790  pop rsi
00007981ddfdd791  pop rdi
00007981ddfdd792  pop rdx
00007981ddfdd793  pop rcx
00007981ddfdd794  pop rax
00007981ddfdd795  add rsp, 0x08
00007981ddfdd799  jmp 0x00007981DDFD963C
00007981ddfdd79e  sub rsp, 0x08
00007981ddfdd7a2  push rax
00007981ddfdd7a3  push rcx
00007981ddfdd7a4  push rdx
00007981ddfdd7a5  push rdi
00007981ddfdd7a6  push rsi
00007981ddfdd7a7  push r8
00007981ddfdd7a9  push r9
00007981ddfdd7ab  push r10
00007981ddfdd7ad  push r11
00007981ddfdd7af  sub rsp, 0xF0
00007981ddfdd7b6  vmovaps [rsp], xmm0
00007981ddfdd7bb  vmovaps [rsp+0x10], xmm1
00007981ddfdd7c1  vmovaps [rsp+0x20], xmm2
00007981ddfdd7c7  vmovaps [rsp+0x30], xmm3
00007981ddfdd7cd  vmovaps [rsp+0x40], xmm4
00007981ddfdd7d3  vmovaps [rsp+0x50], xmm5
00007981ddfdd7d9  vmovaps [rsp+0x60], xmm6
00007981ddfdd7df  vmovaps [rsp+0x70], xmm7
00007981ddfdd7e5  vmovaps [rsp+0x80], xmm9
00007981ddfdd7ee  vmovaps [rsp+0x90], xmm10
00007981ddfdd7f7  vmovaps [rsp+0xA0], xmm11
00007981ddfdd800  vmovaps [rsp+0xB0], xmm12
00007981ddfdd809  vmovaps [rsp+0xC0], xmm13
00007981ddfdd812  vmovaps [rsp+0xD0], xmm14
00007981ddfdd81b  vmovaps [rsp+0xE0], xmm15
00007981ddfdd824  sub rsp, 0x30
00007981ddfdd828  movaps [rsp], xmm8
00007981ddfdd82d  movaps [rsp+0x10], xmm15
00007981ddfdd833  movaps [rsp+0x20], xmm9
00007981ddfdd839  lea rdi, [rsp]
00007981ddfdd83d  mov esi, 0x00
00007981ddfdd842  mov rax, 0x5782A6EB3530
00007981ddfdd84c  call rax
00007981ddfdd84e  movaps xmm8, [rsp]
00007981ddfdd853  add rsp, 0x30
00007981ddfdd857  vmovaps xmm0, [rsp]
00007981ddfdd85c  vmovaps xmm1, [rsp+0x10]
00007981ddfdd862  vmovaps xmm2, [rsp+0x20]
00007981ddfdd868  vmovaps xmm3, [rsp+0x30]
00007981ddfdd86e  vmovaps xmm4, [rsp+0x40]
00007981ddfdd874  vmovaps xmm5, [rsp+0x50]
00007981ddfdd87a  vmovaps xmm6, [rsp+0x60]
00007981ddfdd880  vmovaps xmm7, [rsp+0x70]
00007981ddfdd886  vmovaps xmm9, [rsp+0x80]
00007981ddfdd88f  vmovaps xmm10, [rsp+0x90]
00007981ddfdd898  vmovaps xmm11, [rsp+0xA0]
00007981ddfdd8a1  vmovaps xmm12, [rsp+0xB0]
00007981ddfdd8aa  vmovaps xmm13, [rsp+0xC0]
00007981ddfdd8b3  vmovaps xmm14, [rsp+0xD0]
00007981ddfdd8bc  vmovaps xmm15, [rsp+0xE0]
00007981ddfdd8c5  add rsp, 0xF0
00007981ddfdd8cc  pop r11
00007981ddfdd8ce  pop r10
00007981ddfdd8d0  pop r9
00007981ddfdd8d2  pop r8
00007981ddfdd8d4  pop rsi
00007981ddfdd8d5  pop rdi
00007981ddfdd8d6  pop rdx
00007981ddfdd8d7  pop rcx
00007981ddfdd8d8  pop rax
00007981ddfdd8d9  add rsp, 0x08
00007981ddfdd8dd  jmp 0x00007981DDFD966A
00007981ddfdd8e2  sub rsp, 0x08
00007981ddfdd8e6  push rax
00007981ddfdd8e7  push rcx
00007981ddfdd8e8  push rdx
00007981ddfdd8e9  push rdi
00007981ddfdd8ea  push rsi
00007981ddfdd8eb  push r8
00007981ddfdd8ed  push r9
00007981ddfdd8ef  push r10
00007981ddfdd8f1  push r11
00007981ddfdd8f3  sub rsp, 0xF0
00007981ddfdd8fa  vmovaps [rsp], xmm0
00007981ddfdd8ff  vmovaps [rsp+0x10], xmm1
00007981ddfdd905  vmovaps [rsp+0x20], xmm2
00007981ddfdd90b  vmovaps [rsp+0x30], xmm3
00007981ddfdd911  vmovaps [rsp+0x40], xmm4
00007981ddfdd917  vmovaps [rsp+0x50], xmm5
00007981ddfdd91d  vmovaps [rsp+0x60], xmm6
00007981ddfdd923  vmovaps [rsp+0x70], xmm7
00007981ddfdd929  vmovaps [rsp+0x80], xmm8
00007981ddfdd932  vmovaps [rsp+0x90], xmm9
00007981ddfdd93b  vmovaps [rsp+0xA0], xmm10
00007981ddfdd944  vmovaps [rsp+0xB0], xmm11
00007981ddfdd94d  vmovaps [rsp+0xC0], xmm12
00007981ddfdd956  vmovaps [rsp+0xD0], xmm13
00007981ddfdd95f  vmovaps [rsp+0xE0], xmm14
00007981ddfdd968  sub rsp, 0x30
00007981ddfdd96c  movaps [rsp], xmm15
00007981ddfdd971  movaps [rsp+0x10], xmm11
00007981ddfdd977  movaps [rsp+0x20], xmm6
00007981ddfdd97c  lea rdi, [rsp]
00007981ddfdd980  mov esi, 0x00
00007981ddfdd985  mov rax, 0x5782A6EB3530
00007981ddfdd98f  call rax
00007981ddfdd991  movaps xmm15, [rsp]
00007981ddfdd996  add rsp, 0x30
00007981ddfdd99a  vmovaps xmm0, [rsp]
00007981ddfdd99f  vmovaps xmm1, [rsp+0x10]
00007981ddfdd9a5  vmovaps xmm2, [rsp+0x20]
00007981ddfdd9ab  vmovaps xmm3, [rsp+0x30]
00007981ddfdd9b1  vmovaps xmm4, [rsp+0x40]
00007981ddfdd9b7  vmovaps xmm5, [rsp+0x50]
00007981ddfdd9bd  vmovaps xmm6, [rsp+0x60]
00007981ddfdd9c3  vmovaps xmm7, [rsp+0x70]
00007981ddfdd9c9  vmovaps xmm8, [rsp+0x80]
00007981ddfdd9d2  vmovaps xmm9, [rsp+0x90]
00007981ddfdd9db  vmovaps xmm10, [rsp+0xA0]
00007981ddfdd9e4  vmovaps xmm11, [rsp+0xB0]
00007981ddfdd9ed  vmovaps xmm12, [rsp+0xC0]
00007981ddfdd9f6  vmovaps xmm13, [rsp+0xD0]
00007981ddfdd9ff  vmovaps xmm14, [rsp+0xE0]
00007981ddfdda08  add rsp, 0xF0
00007981ddfdda0f  pop r11
00007981ddfdda11  pop r10
00007981ddfdda13  pop r9
00007981ddfdda15  pop r8
00007981ddfdda17  pop rsi
00007981ddfdda18  pop rdi
00007981ddfdda19  pop rdx
00007981ddfdda1a  pop rcx
00007981ddfdda1b  pop rax
00007981ddfdda1c  add rsp, 0x08
00007981ddfdda20  jmp 0x00007981DDFD9685
00007981ddfdda25  sub rsp, 0x08
00007981ddfdda29  push rax
00007981ddfdda2a  push rcx
00007981ddfdda2b  push rdx
00007981ddfdda2c  push rdi
00007981ddfdda2d  push rsi
00007981ddfdda2e  push r8
00007981ddfdda30  push r9
00007981ddfdda32  push r10
00007981ddfdda34  push r11
00007981ddfdda36  sub rsp, 0xF0
00007981ddfdda3d  vmovaps [rsp], xmm0
00007981ddfdda42  vmovaps [rsp+0x10], xmm1
00007981ddfdda48  vmovaps [rsp+0x20], xmm2
00007981ddfdda4e  vmovaps [rsp+0x30], xmm3
00007981ddfdda54  vmovaps [rsp+0x40], xmm4
00007981ddfdda5a  vmovaps [rsp+0x50], xmm5
00007981ddfdda60  vmovaps [rsp+0x60], xmm6
00007981ddfdda66  vmovaps [rsp+0x70], xmm8
00007981ddfdda6c  vmovaps [rsp+0x80], xmm9
00007981ddfdda75  vmovaps [rsp+0x90], xmm10
00007981ddfdda7e  vmovaps [rsp+0xA0], xmm11
00007981ddfdda87  vmovaps [rsp+0xB0], xmm12
00007981ddfdda90  vmovaps [rsp+0xC0], xmm13
00007981ddfdda99  vmovaps [rsp+0xD0], xmm14
00007981ddfddaa2  vmovaps [rsp+0xE0], xmm15
00007981ddfddaab  sub rsp, 0x30
00007981ddfddaaf  movaps [rsp], xmm7
00007981ddfddab3  movaps [rsp+0x10], xmm11
00007981ddfddab9  movaps [rsp+0x20], xmm9
00007981ddfddabf  lea rdi, [rsp]
00007981ddfddac3  mov esi, 0x00
00007981ddfddac8  mov rax, 0x5782A6EB3530
00007981ddfddad2  call rax
00007981ddfddad4  movaps xmm7, [rsp]
00007981ddfddad8  add rsp, 0x30
00007981ddfddadc  vmovaps xmm0, [rsp]
00007981ddfddae1  vmovaps xmm1, [rsp+0x10]
00007981ddfddae7  vmovaps xmm2, [rsp+0x20]
00007981ddfddaed  vmovaps xmm3, [rsp+0x30]
00007981ddfddaf3  vmovaps xmm4, [rsp+0x40]
00007981ddfddaf9  vmovaps xmm5, [rsp+0x50]
00007981ddfddaff  vmovaps xmm6, [rsp+0x60]
00007981ddfddb05  vmovaps xmm8, [rsp+0x70]
00007981ddfddb0b  vmovaps xmm9, [rsp+0x80]
00007981ddfddb14  vmovaps xmm10, [rsp+0x90]
00007981ddfddb1d  vmovaps xmm11, [rsp+0xA0]
00007981ddfddb26  vmovaps xmm12, [rsp+0xB0]
00007981ddfddb2f  vmovaps xmm13, [rsp+0xC0]
00007981ddfddb38  vmovaps xmm14, [rsp+0xD0]
00007981ddfddb41  vmovaps xmm15, [rsp+0xE0]
00007981ddfddb4a  add rsp, 0xF0
00007981ddfddb51  pop r11
00007981ddfddb53  pop r10
00007981ddfddb55  pop r9
00007981ddfddb57  pop r8
00007981ddfddb59  pop rsi
00007981ddfddb5a  pop rdi
00007981ddfddb5b  pop rdx
00007981ddfddb5c  pop rcx
00007981ddfddb5d  pop rax
00007981ddfddb5e  add rsp, 0x08
00007981ddfddb62  jmp 0x00007981DDFD96B2
00007981ddfddb67  sub rsp, 0x08
00007981ddfddb6b  push rax
00007981ddfddb6c  push rcx
00007981ddfddb6d  push rdx
00007981ddfddb6e  push rdi
00007981ddfddb6f  push rsi
00007981ddfddb70  push r8
00007981ddfddb72  push r9
00007981ddfddb74  push r10
00007981ddfddb76  push r11
00007981ddfddb78  sub rsp, 0xF0
00007981ddfddb7f  vmovaps [rsp], xmm0
00007981ddfddb84  vmovaps [rsp+0x10], xmm1
00007981ddfddb8a  vmovaps [rsp+0x20], xmm2
00007981ddfddb90  vmovaps [rsp+0x30], xmm3
00007981ddfddb96  vmovaps [rsp+0x40], xmm4
00007981ddfddb9c  vmovaps [rsp+0x50], xmm5
00007981ddfddba2  vmovaps [rsp+0x60], xmm6
00007981ddfddba8  vmovaps [rsp+0x70], xmm7
00007981ddfddbae  vmovaps [rsp+0x80], xmm8
00007981ddfddbb7  vmovaps [rsp+0x90], xmm9
00007981ddfddbc0  vmovaps [rsp+0xA0], xmm10
00007981ddfddbc9  vmovaps [rsp+0xB0], xmm12
00007981ddfddbd2  vmovaps [rsp+0xC0], xmm13
00007981ddfddbdb  vmovaps [rsp+0xD0], xmm14
00007981ddfddbe4  vmovaps [rsp+0xE0], xmm15
00007981ddfddbed  sub rsp, 0x30
00007981ddfddbf1  movaps [rsp], xmm11
00007981ddfddbf6  movaps [rsp+0x10], xmm10
00007981ddfddbfc  movaps [rsp+0x20], xmm14
00007981ddfddc02  lea rdi, [rsp]
00007981ddfddc06  mov esi, 0x00
00007981ddfddc0b  mov rax, 0x5782A6EB3530
00007981ddfddc15  call rax
00007981ddfddc17  movaps xmm11, [rsp]
00007981ddfddc1c  add rsp, 0x30
00007981ddfddc20  vmovaps xmm0, [rsp]
00007981ddfddc25  vmovaps xmm1, [rsp+0x10]
00007981ddfddc2b  vmovaps xmm2, [rsp+0x20]
00007981ddfddc31  vmovaps xmm3, [rsp+0x30]
00007981ddfddc37  vmovaps xmm4, [rsp+0x40]
00007981ddfddc3d  vmovaps xmm5, [rsp+0x50]
00007981ddfddc43  vmovaps xmm6, [rsp+0x60]
00007981ddfddc49  vmovaps xmm7, [rsp+0x70]
00007981ddfddc4f  vmovaps xmm8, [rsp+0x80]
00007981ddfddc58  vmovaps xmm9, [rsp+0x90]
00007981ddfddc61  vmovaps xmm10, [rsp+0xA0]
00007981ddfddc6a  vmovaps xmm12, [rsp+0xB0]
00007981ddfddc73  vmovaps xmm13, [rsp+0xC0]
00007981ddfddc7c  vmovaps xmm14, [rsp+0xD0]
00007981ddfddc85  vmovaps xmm15, [rsp+0xE0]
00007981ddfddc8e  add rsp, 0xF0
00007981ddfddc95  pop r11
00007981ddfddc97  pop r10
00007981ddfddc99  pop r9
00007981ddfddc9b  pop r8
00007981ddfddc9d  pop rsi
00007981ddfddc9e  pop rdi
00007981ddfddc9f  pop rdx
00007981ddfddca0  pop rcx
00007981ddfddca1  pop rax
00007981ddfddca2  add rsp, 0x08
00007981ddfddca6  jmp 0x00007981DDFD96CD
00007981ddfddcab  call 0x00007981DDEE45A0
00007981ddfddcb0  jmp 0x00007981DDFD96D7
00007981ddfddcb5  sub rsp, 0x08
00007981ddfddcb9  push rax
00007981ddfddcba  push rcx
00007981ddfddcbb  push rdx
00007981ddfddcbc  push rdi
00007981ddfddcbd  push rsi
00007981ddfddcbe  push r8
00007981ddfddcc0  push r9
00007981ddfddcc2  push r10
00007981ddfddcc4  push r11
00007981ddfddcc6  sub rsp, 0xF0
00007981ddfddccd  vmovaps [rsp], xmm0
00007981ddfddcd2  vmovaps [rsp+0x10], xmm1
00007981ddfddcd8  vmovaps [rsp+0x20], xmm2
00007981ddfddcde  vmovaps [rsp+0x30], xmm3
00007981ddfddce4  vmovaps [rsp+0x40], xmm4
00007981ddfddcea  vmovaps [rsp+0x50], xmm5
00007981ddfddcf0  vmovaps [rsp+0x60], xmm6
00007981ddfddcf6  vmovaps [rsp+0x70], xmm7
00007981ddfddcfc  vmovaps [rsp+0x80], xmm8
00007981ddfddd05  vmovaps [rsp+0x90], xmm9
00007981ddfddd0e  vmovaps [rsp+0xA0], xmm11
00007981ddfddd17  vmovaps [rsp+0xB0], xmm12
00007981ddfddd20  vmovaps [rsp+0xC0], xmm13
00007981ddfddd29  vmovaps [rsp+0xD0], xmm14
00007981ddfddd32  vmovaps [rsp+0xE0], xmm15
00007981ddfddd3b  sub rsp, 0x30
00007981ddfddd3f  movaps [rsp], xmm10
00007981ddfddd44  movaps [rsp+0x10], xmm1
00007981ddfddd49  movaps [rsp+0x20], xmm12
00007981ddfddd4f  lea rdi, [rsp]
00007981ddfddd53  mov esi, 0x00
00007981ddfddd58  mov rax, 0x5782A6EB3530
00007981ddfddd62  call rax
00007981ddfddd64  movaps xmm10, [rsp]
00007981ddfddd69  add rsp, 0x30
00007981ddfddd6d  vmovaps xmm0, [rsp]
00007981ddfddd72  vmovaps xmm1, [rsp+0x10]
00007981ddfddd78  vmovaps xmm2, [rsp+0x20]
00007981ddfddd7e  vmovaps xmm3, [rsp+0x30]
00007981ddfddd84  vmovaps xmm4, [rsp+0x40]
00007981ddfddd8a  vmovaps xmm5, [rsp+0x50]
00007981ddfddd90  vmovaps xmm6, [rsp+0x60]
00007981ddfddd96  vmovaps xmm7, [rsp+0x70]
00007981ddfddd9c  vmovaps xmm8, [rsp+0x80]
00007981ddfddda5  vmovaps xmm9, [rsp+0x90]
00007981ddfdddae  vmovaps xmm11, [rsp+0xA0]
00007981ddfdddb7  vmovaps xmm12, [rsp+0xB0]
00007981ddfdddc0  vmovaps xmm13, [rsp+0xC0]
00007981ddfdddc9  vmovaps xmm14, [rsp+0xD0]
00007981ddfdddd2  vmovaps xmm15, [rsp+0xE0]
00007981ddfddddb  add rsp, 0xF0
00007981ddfddde2  pop r11
00007981ddfddde4  pop r10
00007981ddfddde6  pop r9
00007981ddfddde8  pop r8
00007981ddfdddea  pop rsi
00007981ddfdddeb  pop rdi
00007981ddfdddec  pop rdx
00007981ddfddded  pop rcx
00007981ddfdddee  pop rax
00007981ddfdddef  add rsp, 0x08
00007981ddfdddf3  jmp 0x00007981DDFD96FA
00007981ddfdddf8  sub rsp, 0x08
00007981ddfdddfc  push rax
00007981ddfdddfd  push rcx
00007981ddfdddfe  push rdx
00007981ddfdddff  push rdi
00007981ddfdde00  push rsi
00007981ddfdde01  push r8
00007981ddfdde03  push r9
00007981ddfdde05  push r10
00007981ddfdde07  push r11
00007981ddfdde09  sub rsp, 0xF0
00007981ddfdde10  vmovaps [rsp], xmm0
00007981ddfdde15  vmovaps [rsp+0x10], xmm1
00007981ddfdde1b  vmovaps [rsp+0x20], xmm2
00007981ddfdde21  vmovaps [rsp+0x30], xmm3
00007981ddfdde27  vmovaps [rsp+0x40], xmm4
00007981ddfdde2d  vmovaps [rsp+0x50], xmm5
00007981ddfdde33  vmovaps [rsp+0x60], xmm6
00007981ddfdde39  vmovaps [rsp+0x70], xmm7
00007981ddfdde3f  vmovaps [rsp+0x80], xmm8
00007981ddfdde48  vmovaps [rsp+0x90], xmm9
00007981ddfdde51  vmovaps [rsp+0xA0], xmm10
00007981ddfdde5a  vmovaps [rsp+0xB0], xmm11
00007981ddfdde63  vmovaps [rsp+0xC0], xmm13
00007981ddfdde6c  vmovaps [rsp+0xD0], xmm14
00007981ddfdde75  vmovaps [rsp+0xE0], xmm15
00007981ddfdde7e  sub rsp, 0x30
00007981ddfdde82  movaps [rsp], xmm12
00007981ddfdde87  movaps [rsp+0x10], xmm14
00007981ddfdde8d  movaps [rsp+0x20], xmm1
00007981ddfdde92  lea rdi, [rsp]
00007981ddfdde96  mov esi, 0x00
00007981ddfdde9b  mov rax, 0x5782A6EB3530
00007981ddfddea5  call rax
00007981ddfddea7  movaps xmm12, [rsp]
00007981ddfddeac  add rsp, 0x30
00007981ddfddeb0  vmovaps xmm0, [rsp]
00007981ddfddeb5  vmovaps xmm1, [rsp+0x10]
00007981ddfddebb  vmovaps xmm2, [rsp+0x20]
00007981ddfddec1  vmovaps xmm3, [rsp+0x30]
00007981ddfddec7  vmovaps xmm4, [rsp+0x40]
00007981ddfddecd  vmovaps xmm5, [rsp+0x50]
00007981ddfdded3  vmovaps xmm6, [rsp+0x60]
00007981ddfdded9  vmovaps xmm7, [rsp+0x70]
00007981ddfddedf  vmovaps xmm8, [rsp+0x80]
00007981ddfddee8  vmovaps xmm9, [rsp+0x90]
00007981ddfddef1  vmovaps xmm10, [rsp+0xA0]
00007981ddfddefa  vmovaps xmm11, [rsp+0xB0]
00007981ddfddf03  vmovaps xmm13, [rsp+0xC0]
00007981ddfddf0c  vmovaps xmm14, [rsp+0xD0]
00007981ddfddf15  vmovaps xmm15, [rsp+0xE0]
00007981ddfddf1e  add rsp, 0xF0
00007981ddfddf25  pop r11
00007981ddfddf27  pop r10
00007981ddfddf29  pop r9
00007981ddfddf2b  pop r8
00007981ddfddf2d  pop rsi
00007981ddfddf2e  pop rdi
00007981ddfddf2f  pop rdx
00007981ddfddf30  pop rcx
00007981ddfddf31  pop rax
00007981ddfddf32  add rsp, 0x08
00007981ddfddf36  jmp 0x00007981DDFD9729
00007981ddfddf3b  sub rsp, 0x08
00007981ddfddf3f  push rax
00007981ddfddf40  push rcx
00007981ddfddf41  push rdx
00007981ddfddf42  push rdi
00007981ddfddf43  push rsi
00007981ddfddf44  push r8
00007981ddfddf46  push r9
00007981ddfddf48  push r10
00007981ddfddf4a  push r11
00007981ddfddf4c  sub rsp, 0xF0
00007981ddfddf53  vmovaps [rsp], xmm0
00007981ddfddf58  vmovaps [rsp+0x10], xmm1
00007981ddfddf5e  vmovaps [rsp+0x20], xmm2
00007981ddfddf64  vmovaps [rsp+0x30], xmm3
00007981ddfddf6a  vmovaps [rsp+0x40], xmm4
00007981ddfddf70  vmovaps [rsp+0x50], xmm5
00007981ddfddf76  vmovaps [rsp+0x60], xmm6
00007981ddfddf7c  vmovaps [rsp+0x70], xmm7
00007981ddfddf82  vmovaps [rsp+0x80], xmm8
00007981ddfddf8b  vmovaps [rsp+0x90], xmm9
00007981ddfddf94  vmovaps [rsp+0xA0], xmm10
00007981ddfddf9d  vmovaps [rsp+0xB0], xmm11
00007981ddfddfa6  vmovaps [rsp+0xC0], xmm12
00007981ddfddfaf  vmovaps [rsp+0xD0], xmm13
00007981ddfddfb8  vmovaps [rsp+0xE0], xmm15
00007981ddfddfc1  sub rsp, 0x30
00007981ddfddfc5  movaps [rsp], xmm14
00007981ddfddfca  movaps [rsp+0x10], xmm9
00007981ddfddfd0  movaps [rsp+0x20], xmm1
00007981ddfddfd5  lea rdi, [rsp]
00007981ddfddfd9  mov esi, 0x00
00007981ddfddfde  mov rax, 0x5782A6EB3530
00007981ddfddfe8  call rax
00007981ddfddfea  movaps xmm14, [rsp]
00007981ddfddfef  add rsp, 0x30
00007981ddfddff3  vmovaps xmm0, [rsp]
00007981ddfddff8  vmovaps xmm1, [rsp+0x10]
00007981ddfddffe  vmovaps xmm2, [rsp+0x20]
00007981ddfde004  vmovaps xmm3, [rsp+0x30]
00007981ddfde00a  vmovaps xmm4, [rsp+0x40]
00007981ddfde010  vmovaps xmm5, [rsp+0x50]
00007981ddfde016  vmovaps xmm6, [rsp+0x60]
00007981ddfde01c  vmovaps xmm7, [rsp+0x70]
00007981ddfde022  vmovaps xmm8, [rsp+0x80]
00007981ddfde02b  vmovaps xmm9, [rsp+0x90]
00007981ddfde034  vmovaps xmm10, [rsp+0xA0]
00007981ddfde03d  vmovaps xmm11, [rsp+0xB0]
00007981ddfde046  vmovaps xmm12, [rsp+0xC0]
00007981ddfde04f  vmovaps xmm13, [rsp+0xD0]
00007981ddfde058  vmovaps xmm15, [rsp+0xE0]
00007981ddfde061  add rsp, 0xF0
00007981ddfde068  pop r11
00007981ddfde06a  pop r10
00007981ddfde06c  pop r9
00007981ddfde06e  pop r8
00007981ddfde070  pop rsi
00007981ddfde071  pop rdi
00007981ddfde072  pop rdx
00007981ddfde073  pop rcx
00007981ddfde074  pop rax
00007981ddfde075  add rsp, 0x08
00007981ddfde079  jmp 0x00007981DDFD9758
00007981ddfde07e  sub rsp, 0x08
00007981ddfde082  push rax
00007981ddfde083  push rcx
00007981ddfde084  push rdx
00007981ddfde085  push rdi
00007981ddfde086  push rsi
00007981ddfde087  push r8
00007981ddfde089  push r9
00007981ddfde08b  push r10
00007981ddfde08d  push r11
00007981ddfde08f  sub rsp, 0xF0
00007981ddfde096  vmovaps [rsp], xmm0
00007981ddfde09b  vmovaps [rsp+0x10], xmm2
00007981ddfde0a1  vmovaps [rsp+0x20], xmm3
00007981ddfde0a7  vmovaps [rsp+0x30], xmm4
00007981ddfde0ad  vmovaps [rsp+0x40], xmm5
00007981ddfde0b3  vmovaps [rsp+0x50], xmm6
00007981ddfde0b9  vmovaps [rsp+0x60], xmm7
00007981ddfde0bf  vmovaps [rsp+0x70], xmm8
00007981ddfde0c5  vmovaps [rsp+0x80], xmm9
00007981ddfde0ce  vmovaps [rsp+0x90], xmm10
00007981ddfde0d7  vmovaps [rsp+0xA0], xmm11
00007981ddfde0e0  vmovaps [rsp+0xB0], xmm12
00007981ddfde0e9  vmovaps [rsp+0xC0], xmm13
00007981ddfde0f2  vmovaps [rsp+0xD0], xmm14
00007981ddfde0fb  vmovaps [rsp+0xE0], xmm15
00007981ddfde104  sub rsp, 0x30
00007981ddfde108  movaps [rsp], xmm1
00007981ddfde10c  movaps [rsp+0x10], xmm13
00007981ddfde112  movaps [rsp+0x20], xmm8
00007981ddfde118  lea rdi, [rsp]
00007981ddfde11c  mov esi, 0x00
00007981ddfde121  mov rax, 0x5782A6EB3530
00007981ddfde12b  call rax
00007981ddfde12d  movaps xmm1, [rsp]
00007981ddfde131  add rsp, 0x30
00007981ddfde135  vmovaps xmm0, [rsp]
00007981ddfde13a  vmovaps xmm2, [rsp+0x10]
00007981ddfde140  vmovaps xmm3, [rsp+0x20]
00007981ddfde146  vmovaps xmm4, [rsp+0x30]
00007981ddfde14c  vmovaps xmm5, [rsp+0x40]
00007981ddfde152  vmovaps xmm6, [rsp+0x50]
00007981ddfde158  vmovaps xmm7, [rsp+0x60]
00007981ddfde15e  vmovaps xmm8, [rsp+0x70]
00007981ddfde164  vmovaps xmm9, [rsp+0x80]
00007981ddfde16d  vmovaps xmm10, [rsp+0x90]
00007981ddfde176  vmovaps xmm11, [rsp+0xA0]
00007981ddfde17f  vmovaps xmm12, [rsp+0xB0]
00007981ddfde188  vmovaps xmm13, [rsp+0xC0]
00007981ddfde191  vmovaps xmm14, [rsp+0xD0]
00007981ddfde19a  vmovaps xmm15, [rsp+0xE0]
00007981ddfde1a3  add rsp, 0xF0
00007981ddfde1aa  pop r11
00007981ddfde1ac  pop r10
00007981ddfde1ae  pop r9
00007981ddfde1b0  pop r8
00007981ddfde1b2  pop rsi
00007981ddfde1b3  pop rdi
00007981ddfde1b4  pop rdx
00007981ddfde1b5  pop rcx
00007981ddfde1b6  pop rax
00007981ddfde1b7  add rsp, 0x08
00007981ddfde1bb  jmp 0x00007981DDFD977A
00007981ddfde1c0  call 0x00007981DDE0C260
00007981ddfde1c5  jmp 0x00007981DDFD9788
00007981ddfde1ca  call 0x00007981DDEDE950
00007981ddfde1cf  jmp 0x00007981DDFD9792
00007981ddfde1d4  sub rsp, 0x08
00007981ddfde1d8  push rax
00007981ddfde1d9  push rcx
00007981ddfde1da  push rdx
00007981ddfde1db  push rdi
00007981ddfde1dc  push rsi
00007981ddfde1dd  push r8
00007981ddfde1df  push r9
00007981ddfde1e1  push r10
00007981ddfde1e3  push r11
00007981ddfde1e5  sub rsp, 0xF0
00007981ddfde1ec  vmovaps [rsp], xmm0
00007981ddfde1f1  vmovaps [rsp+0x10], xmm1
00007981ddfde1f7  vmovaps [rsp+0x20], xmm2
00007981ddfde1fd  vmovaps [rsp+0x30], xmm3
00007981ddfde203  vmovaps [rsp+0x40], xmm4
00007981ddfde209  vmovaps [rsp+0x50], xmm5
00007981ddfde20f  vmovaps [rsp+0x60], xmm6
00007981ddfde215  vmovaps [rsp+0x70], xmm7
00007981ddfde21b  vmovaps [rsp+0x80], xmm9
00007981ddfde224  vmovaps [rsp+0x90], xmm10
00007981ddfde22d  vmovaps [rsp+0xA0], xmm11
00007981ddfde236  vmovaps [rsp+0xB0], xmm12
00007981ddfde23f  vmovaps [rsp+0xC0], xmm13
00007981ddfde248  vmovaps [rsp+0xD0], xmm14
00007981ddfde251  vmovaps [rsp+0xE0], xmm15
00007981ddfde25a  sub rsp, 0x30
00007981ddfde25e  movaps [rsp], xmm8
00007981ddfde263  movaps [rsp+0x10], xmm15
00007981ddfde269  movaps [rsp+0x20], xmm7
00007981ddfde26e  lea rdi, [rsp]
00007981ddfde272  mov esi, 0x00
00007981ddfde277  mov rax, 0x5782A6EB3530
00007981ddfde281  call rax
00007981ddfde283  movaps xmm8, [rsp]
00007981ddfde288  add rsp, 0x30
00007981ddfde28c  vmovaps xmm0, [rsp]
00007981ddfde291  vmovaps xmm1, [rsp+0x10]
00007981ddfde297  vmovaps xmm2, [rsp+0x20]
00007981ddfde29d  vmovaps xmm3, [rsp+0x30]
00007981ddfde2a3  vmovaps xmm4, [rsp+0x40]
00007981ddfde2a9  vmovaps xmm5, [rsp+0x50]
00007981ddfde2af  vmovaps xmm6, [rsp+0x60]
00007981ddfde2b5  vmovaps xmm7, [rsp+0x70]
00007981ddfde2bb  vmovaps xmm9, [rsp+0x80]
00007981ddfde2c4  vmovaps xmm10, [rsp+0x90]
00007981ddfde2cd  vmovaps xmm11, [rsp+0xA0]
00007981ddfde2d6  vmovaps xmm12, [rsp+0xB0]
00007981ddfde2df  vmovaps xmm13, [rsp+0xC0]
00007981ddfde2e8  vmovaps xmm14, [rsp+0xD0]
00007981ddfde2f1  vmovaps xmm15, [rsp+0xE0]
00007981ddfde2fa  add rsp, 0xF0
00007981ddfde301  pop r11
00007981ddfde303  pop r10
00007981ddfde305  pop r9
00007981ddfde307  pop r8
00007981ddfde309  pop rsi
00007981ddfde30a  pop rdi
00007981ddfde30b  pop rdx
00007981ddfde30c  pop rcx
00007981ddfde30d  pop rax
00007981ddfde30e  add rsp, 0x08
00007981ddfde312  jmp 0x00007981DDFD97B4
00007981ddfde317  sub rsp, 0x08
00007981ddfde31b  push rax
00007981ddfde31c  push rcx
00007981ddfde31d  push rdx
00007981ddfde31e  push rdi
00007981ddfde31f  push rsi
00007981ddfde320  push r8
00007981ddfde322  push r9
00007981ddfde324  push r10
00007981ddfde326  push r11
00007981ddfde328  sub rsp, 0xF0
00007981ddfde32f  vmovaps [rsp], xmm0
00007981ddfde334  vmovaps [rsp+0x10], xmm1
00007981ddfde33a  vmovaps [rsp+0x20], xmm2
00007981ddfde340  vmovaps [rsp+0x30], xmm3
00007981ddfde346  vmovaps [rsp+0x40], xmm4
00007981ddfde34c  vmovaps [rsp+0x50], xmm5
00007981ddfde352  vmovaps [rsp+0x60], xmm6
00007981ddfde358  vmovaps [rsp+0x70], xmm8
00007981ddfde35e  vmovaps [rsp+0x80], xmm9
00007981ddfde367  vmovaps [rsp+0x90], xmm10
00007981ddfde370  vmovaps [rsp+0xA0], xmm11
00007981ddfde379  vmovaps [rsp+0xB0], xmm12
00007981ddfde382  vmovaps [rsp+0xC0], xmm13
00007981ddfde38b  vmovaps [rsp+0xD0], xmm14
00007981ddfde394  vmovaps [rsp+0xE0], xmm15
00007981ddfde39d  sub rsp, 0x30
00007981ddfde3a1  movaps [rsp], xmm7
00007981ddfde3a5  movaps [rsp+0x10], xmm9
00007981ddfde3ab  movaps [rsp+0x20], xmm15
00007981ddfde3b1  lea rdi, [rsp]
00007981ddfde3b5  mov esi, 0x00
00007981ddfde3ba  mov rax, 0x5782A6EB3530
00007981ddfde3c4  call rax
00007981ddfde3c6  movaps xmm7, [rsp]
00007981ddfde3ca  add rsp, 0x30
00007981ddfde3ce  vmovaps xmm0, [rsp]
00007981ddfde3d3  vmovaps xmm1, [rsp+0x10]
00007981ddfde3d9  vmovaps xmm2, [rsp+0x20]
00007981ddfde3df  vmovaps xmm3, [rsp+0x30]
00007981ddfde3e5  vmovaps xmm4, [rsp+0x40]
00007981ddfde3eb  vmovaps xmm5, [rsp+0x50]
00007981ddfde3f1  vmovaps xmm6, [rsp+0x60]
00007981ddfde3f7  vmovaps xmm8, [rsp+0x70]
00007981ddfde3fd  vmovaps xmm9, [rsp+0x80]
00007981ddfde406  vmovaps xmm10, [rsp+0x90]
00007981ddfde40f  vmovaps xmm11, [rsp+0xA0]
00007981ddfde418  vmovaps xmm12, [rsp+0xB0]
00007981ddfde421  vmovaps xmm13, [rsp+0xC0]
00007981ddfde42a  vmovaps xmm14, [rsp+0xD0]
00007981ddfde433  vmovaps xmm15, [rsp+0xE0]
00007981ddfde43c  add rsp, 0xF0
00007981ddfde443  pop r11
00007981ddfde445  pop r10
00007981ddfde447  pop r9
00007981ddfde449  pop r8
00007981ddfde44b  pop rsi
00007981ddfde44c  pop rdi
00007981ddfde44d  pop rdx
00007981ddfde44e  pop rcx
00007981ddfde44f  pop rax
00007981ddfde450  add rsp, 0x08
00007981ddfde454  jmp 0x00007981DDFD97E1
00007981ddfde459  sub rsp, 0x08
00007981ddfde45d  push rax
00007981ddfde45e  push rcx
00007981ddfde45f  push rdx
00007981ddfde460  push rdi
00007981ddfde461  push rsi
00007981ddfde462  push r8
00007981ddfde464  push r9
00007981ddfde466  push r10
00007981ddfde468  push r11
00007981ddfde46a  sub rsp, 0xF0
00007981ddfde471  vmovaps [rsp], xmm0
00007981ddfde476  vmovaps [rsp+0x10], xmm1
00007981ddfde47c  vmovaps [rsp+0x20], xmm2
00007981ddfde482  vmovaps [rsp+0x30], xmm3
00007981ddfde488  vmovaps [rsp+0x40], xmm4
00007981ddfde48e  vmovaps [rsp+0x50], xmm5
00007981ddfde494  vmovaps [rsp+0x60], xmm6
00007981ddfde49a  vmovaps [rsp+0x70], xmm7
00007981ddfde4a0  vmovaps [rsp+0x80], xmm8
00007981ddfde4a9  vmovaps [rsp+0x90], xmm10
00007981ddfde4b2  vmovaps [rsp+0xA0], xmm11
00007981ddfde4bb  vmovaps [rsp+0xB0], xmm12
00007981ddfde4c4  vmovaps [rsp+0xC0], xmm13
00007981ddfde4cd  vmovaps [rsp+0xD0], xmm14
00007981ddfde4d6  vmovaps [rsp+0xE0], xmm15
00007981ddfde4df  sub rsp, 0x30
00007981ddfde4e3  movaps [rsp], xmm9
00007981ddfde4e8  movaps [rsp+0x10], xmm13
00007981ddfde4ee  movaps [rsp+0x20], xmm15
00007981ddfde4f4  lea rdi, [rsp]
00007981ddfde4f8  mov esi, 0x00
00007981ddfde4fd  mov rax, 0x5782A6EB3530
00007981ddfde507  call rax
00007981ddfde509  movaps xmm9, [rsp]
00007981ddfde50e  add rsp, 0x30
00007981ddfde512  vmovaps xmm0, [rsp]
00007981ddfde517  vmovaps xmm1, [rsp+0x10]
00007981ddfde51d  vmovaps xmm2, [rsp+0x20]
00007981ddfde523  vmovaps xmm3, [rsp+0x30]
00007981ddfde529  vmovaps xmm4, [rsp+0x40]
00007981ddfde52f  vmovaps xmm5, [rsp+0x50]
00007981ddfde535  vmovaps xmm6, [rsp+0x60]
00007981ddfde53b  vmovaps xmm7, [rsp+0x70]
00007981ddfde541  vmovaps xmm8, [rsp+0x80]
00007981ddfde54a  vmovaps xmm10, [rsp+0x90]
00007981ddfde553  vmovaps xmm11, [rsp+0xA0]
00007981ddfde55c  vmovaps xmm12, [rsp+0xB0]
00007981ddfde565  vmovaps xmm13, [rsp+0xC0]
00007981ddfde56e  vmovaps xmm14, [rsp+0xD0]
00007981ddfde577  vmovaps xmm15, [rsp+0xE0]
00007981ddfde580  add rsp, 0xF0
00007981ddfde587  pop r11
00007981ddfde589  pop r10
00007981ddfde58b  pop r9
00007981ddfde58d  pop r8
00007981ddfde58f  pop rsi
00007981ddfde590  pop rdi
00007981ddfde591  pop rdx
00007981ddfde592  pop rcx
00007981ddfde593  pop rax
00007981ddfde594  add rsp, 0x08
00007981ddfde598  jmp 0x00007981DDFD980F
00007981ddfde59d  sub rsp, 0x08
00007981ddfde5a1  push rax
00007981ddfde5a2  push rcx
00007981ddfde5a3  push rdx
00007981ddfde5a4  push rdi
00007981ddfde5a5  push rsi
00007981ddfde5a6  push r8
00007981ddfde5a8  push r9
00007981ddfde5aa  push r10
00007981ddfde5ac  push r11
00007981ddfde5ae  sub rsp, 0xF0
00007981ddfde5b5  vmovaps [rsp], xmm0
00007981ddfde5ba  vmovaps [rsp+0x10], xmm1
00007981ddfde5c0  vmovaps [rsp+0x20], xmm2
00007981ddfde5c6  vmovaps [rsp+0x30], xmm3
00007981ddfde5cc  vmovaps [rsp+0x40], xmm4
00007981ddfde5d2  vmovaps [rsp+0x50], xmm5
00007981ddfde5d8  vmovaps [rsp+0x60], xmm6
00007981ddfde5de  vmovaps [rsp+0x70], xmm7
00007981ddfde5e4  vmovaps [rsp+0x80], xmm8
00007981ddfde5ed  vmovaps [rsp+0x90], xmm9
00007981ddfde5f6  vmovaps [rsp+0xA0], xmm10
00007981ddfde5ff  vmovaps [rsp+0xB0], xmm11
00007981ddfde608  vmovaps [rsp+0xC0], xmm12
00007981ddfde611  vmovaps [rsp+0xD0], xmm13
00007981ddfde61a  vmovaps [rsp+0xE0], xmm14
00007981ddfde623  sub rsp, 0x30
00007981ddfde627  movaps [rsp], xmm15
00007981ddfde62c  movaps [rsp+0x10], xmm11
00007981ddfde632  movaps [rsp+0x20], xmm12
00007981ddfde638  lea rdi, [rsp]
00007981ddfde63c  mov esi, 0x00
00007981ddfde641  mov rax, 0x5782A6EB3530
00007981ddfde64b  call rax
00007981ddfde64d  movaps xmm15, [rsp]
00007981ddfde652  add rsp, 0x30
00007981ddfde656  vmovaps xmm0, [rsp]
00007981ddfde65b  vmovaps xmm1, [rsp+0x10]
00007981ddfde661  vmovaps xmm2, [rsp+0x20]
00007981ddfde667  vmovaps xmm3, [rsp+0x30]
00007981ddfde66d  vmovaps xmm4, [rsp+0x40]
00007981ddfde673  vmovaps xmm5, [rsp+0x50]
00007981ddfde679  vmovaps xmm6, [rsp+0x60]
00007981ddfde67f  vmovaps xmm7, [rsp+0x70]
00007981ddfde685  vmovaps xmm8, [rsp+0x80]
00007981ddfde68e  vmovaps xmm9, [rsp+0x90]
00007981ddfde697  vmovaps xmm10, [rsp+0xA0]
00007981ddfde6a0  vmovaps xmm11, [rsp+0xB0]
00007981ddfde6a9  vmovaps xmm12, [rsp+0xC0]
00007981ddfde6b2  vmovaps xmm13, [rsp+0xD0]
00007981ddfde6bb  vmovaps xmm14, [rsp+0xE0]
00007981ddfde6c4  add rsp, 0xF0
00007981ddfde6cb  pop r11
00007981ddfde6cd  pop r10
00007981ddfde6cf  pop r9
00007981ddfde6d1  pop r8
00007981ddfde6d3  pop rsi
00007981ddfde6d4  pop rdi
00007981ddfde6d5  pop rdx
00007981ddfde6d6  pop rcx
00007981ddfde6d7  pop rax
00007981ddfde6d8  add rsp, 0x08
00007981ddfde6dc  jmp 0x00007981DDFD982A
00007981ddfde6e1  sub rsp, 0x08
00007981ddfde6e5  push rax
00007981ddfde6e6  push rcx
00007981ddfde6e7  push rdx
00007981ddfde6e8  push rdi
00007981ddfde6e9  push rsi
00007981ddfde6ea  push r8
00007981ddfde6ec  push r9
00007981ddfde6ee  push r10
00007981ddfde6f0  push r11
00007981ddfde6f2  sub rsp, 0xF0
00007981ddfde6f9  vmovaps [rsp], xmm0
00007981ddfde6fe  vmovaps [rsp+0x10], xmm1
00007981ddfde704  vmovaps [rsp+0x20], xmm2
00007981ddfde70a  vmovaps [rsp+0x30], xmm3
00007981ddfde710  vmovaps [rsp+0x40], xmm4
00007981ddfde716  vmovaps [rsp+0x50], xmm5
00007981ddfde71c  vmovaps [rsp+0x60], xmm6
00007981ddfde722  vmovaps [rsp+0x70], xmm7
00007981ddfde728  vmovaps [rsp+0x80], xmm8
00007981ddfde731  vmovaps [rsp+0x90], xmm9
00007981ddfde73a  vmovaps [rsp+0xA0], xmm10
00007981ddfde743  vmovaps [rsp+0xB0], xmm11
00007981ddfde74c  vmovaps [rsp+0xC0], xmm12
00007981ddfde755  vmovaps [rsp+0xD0], xmm14
00007981ddfde75e  vmovaps [rsp+0xE0], xmm15
00007981ddfde767  sub rsp, 0x30
00007981ddfde76b  movaps [rsp], xmm13
00007981ddfde770  movaps [rsp+0x10], xmm10
00007981ddfde776  movaps [rsp+0x20], xmm14
00007981ddfde77c  lea rdi, [rsp]
00007981ddfde780  mov esi, 0x00
00007981ddfde785  mov rax, 0x5782A6EB3530
00007981ddfde78f  call rax
00007981ddfde791  movaps xmm13, [rsp]
00007981ddfde796  add rsp, 0x30
00007981ddfde79a  vmovaps xmm0, [rsp]
00007981ddfde79f  vmovaps xmm1, [rsp+0x10]
00007981ddfde7a5  vmovaps xmm2, [rsp+0x20]
00007981ddfde7ab  vmovaps xmm3, [rsp+0x30]
00007981ddfde7b1  vmovaps xmm4, [rsp+0x40]
00007981ddfde7b7  vmovaps xmm5, [rsp+0x50]
00007981ddfde7bd  vmovaps xmm6, [rsp+0x60]
00007981ddfde7c3  vmovaps xmm7, [rsp+0x70]
00007981ddfde7c9  vmovaps xmm8, [rsp+0x80]
00007981ddfde7d2  vmovaps xmm9, [rsp+0x90]
00007981ddfde7db  vmovaps xmm10, [rsp+0xA0]
00007981ddfde7e4  vmovaps xmm11, [rsp+0xB0]
00007981ddfde7ed  vmovaps xmm12, [rsp+0xC0]
00007981ddfde7f6  vmovaps xmm14, [rsp+0xD0]
00007981ddfde7ff  vmovaps xmm15, [rsp+0xE0]
00007981ddfde808  add rsp, 0xF0
00007981ddfde80f  pop r11
00007981ddfde811  pop r10
00007981ddfde813  pop r9
00007981ddfde815  pop r8
00007981ddfde817  pop rsi
00007981ddfde818  pop rdi
00007981ddfde819  pop rdx
00007981ddfde81a  pop rcx
00007981ddfde81b  pop rax
00007981ddfde81c  add rsp, 0x08
00007981ddfde820  jmp 0x00007981DDFD984D
00007981ddfde825  sub rsp, 0x08
00007981ddfde829  push rax
00007981ddfde82a  push rcx
00007981ddfde82b  push rdx
00007981ddfde82c  push rdi
00007981ddfde82d  push rsi
00007981ddfde82e  push r8
00007981ddfde830  push r9
00007981ddfde832  push r10
00007981ddfde834  push r11
00007981ddfde836  sub rsp, 0xF0
00007981ddfde83d  vmovaps [rsp], xmm0
00007981ddfde842  vmovaps [rsp+0x10], xmm1
00007981ddfde848  vmovaps [rsp+0x20], xmm2
00007981ddfde84e  vmovaps [rsp+0x30], xmm3
00007981ddfde854  vmovaps [rsp+0x40], xmm4
00007981ddfde85a  vmovaps [rsp+0x50], xmm5
00007981ddfde860  vmovaps [rsp+0x60], xmm6
00007981ddfde866  vmovaps [rsp+0x70], xmm7
00007981ddfde86c  vmovaps [rsp+0x80], xmm8
00007981ddfde875  vmovaps [rsp+0x90], xmm9
00007981ddfde87e  vmovaps [rsp+0xA0], xmm10
00007981ddfde887  vmovaps [rsp+0xB0], xmm11
00007981ddfde890  vmovaps [rsp+0xC0], xmm12
00007981ddfde899  vmovaps [rsp+0xD0], xmm13
00007981ddfde8a2  vmovaps [rsp+0xE0], xmm15
00007981ddfde8ab  sub rsp, 0x30
00007981ddfde8af  movaps [rsp], xmm14
00007981ddfde8b4  movaps [rsp+0x10], xmm1
00007981ddfde8b9  movaps [rsp+0x20], xmm7
00007981ddfde8be  lea rdi, [rsp]
00007981ddfde8c2  mov esi, 0x00
00007981ddfde8c7  mov rax, 0x5782A6EB3530
00007981ddfde8d1  call rax
00007981ddfde8d3  movaps xmm14, [rsp]
00007981ddfde8d8  add rsp, 0x30
00007981ddfde8dc  vmovaps xmm0, [rsp]
00007981ddfde8e1  vmovaps xmm1, [rsp+0x10]
00007981ddfde8e7  vmovaps xmm2, [rsp+0x20]
00007981ddfde8ed  vmovaps xmm3, [rsp+0x30]
00007981ddfde8f3  vmovaps xmm4, [rsp+0x40]
00007981ddfde8f9  vmovaps xmm5, [rsp+0x50]
00007981ddfde8ff  vmovaps xmm6, [rsp+0x60]
00007981ddfde905  vmovaps xmm7, [rsp+0x70]
00007981ddfde90b  vmovaps xmm8, [rsp+0x80]
00007981ddfde914  vmovaps xmm9, [rsp+0x90]
00007981ddfde91d  vmovaps xmm10, [rsp+0xA0]
00007981ddfde926  vmovaps xmm11, [rsp+0xB0]
00007981ddfde92f  vmovaps xmm12, [rsp+0xC0]
00007981ddfde938  vmovaps xmm13, [rsp+0xD0]
00007981ddfde941  vmovaps xmm15, [rsp+0xE0]
00007981ddfde94a  add rsp, 0xF0
00007981ddfde951  pop r11
00007981ddfde953  pop r10
00007981ddfde955  pop r9
00007981ddfde957  pop r8
00007981ddfde959  pop rsi
00007981ddfde95a  pop rdi
00007981ddfde95b  pop rdx
00007981ddfde95c  pop rcx
00007981ddfde95d  pop rax
00007981ddfde95e  add rsp, 0x08
00007981ddfde962  jmp 0x00007981DDFD9870
00007981ddfde967  sub rsp, 0x08
00007981ddfde96b  push rax
00007981ddfde96c  push rcx
00007981ddfde96d  push rdx
00007981ddfde96e  push rdi
00007981ddfde96f  push rsi
00007981ddfde970  push r8
00007981ddfde972  push r9
00007981ddfde974  push r10
00007981ddfde976  push r11
00007981ddfde978  sub rsp, 0xF0
00007981ddfde97f  vmovaps [rsp], xmm0
00007981ddfde984  vmovaps [rsp+0x10], xmm2
00007981ddfde98a  vmovaps [rsp+0x20], xmm3
00007981ddfde990  vmovaps [rsp+0x30], xmm4
00007981ddfde996  vmovaps [rsp+0x40], xmm5
00007981ddfde99c  vmovaps [rsp+0x50], xmm6
00007981ddfde9a2  vmovaps [rsp+0x60], xmm7
00007981ddfde9a8  vmovaps [rsp+0x70], xmm8
00007981ddfde9ae  vmovaps [rsp+0x80], xmm9
00007981ddfde9b7  vmovaps [rsp+0x90], xmm10
00007981ddfde9c0  vmovaps [rsp+0xA0], xmm11
00007981ddfde9c9  vmovaps [rsp+0xB0], xmm12
00007981ddfde9d2  vmovaps [rsp+0xC0], xmm13
00007981ddfde9db  vmovaps [rsp+0xD0], xmm14
00007981ddfde9e4  vmovaps [rsp+0xE0], xmm15
00007981ddfde9ed  sub rsp, 0x30
00007981ddfde9f1  movaps [rsp], xmm1
00007981ddfde9f5  movaps [rsp+0x10], xmm8
00007981ddfde9fb  movaps [rsp+0x20], xmm9
00007981ddfdea01  lea rdi, [rsp]
00007981ddfdea05  mov esi, 0x00
00007981ddfdea0a  mov rax, 0x5782A6EB3530
00007981ddfdea14  call rax
00007981ddfdea16  movaps xmm1, [rsp]
00007981ddfdea1a  add rsp, 0x30
00007981ddfdea1e  vmovaps xmm0, [rsp]
00007981ddfdea23  vmovaps xmm2, [rsp+0x10]
00007981ddfdea29  vmovaps xmm3, [rsp+0x20]
00007981ddfdea2f  vmovaps xmm4, [rsp+0x30]
00007981ddfdea35  vmovaps xmm5, [rsp+0x40]
00007981ddfdea3b  vmovaps xmm6, [rsp+0x50]
00007981ddfdea41  vmovaps xmm7, [rsp+0x60]
00007981ddfdea47  vmovaps xmm8, [rsp+0x70]
00007981ddfdea4d  vmovaps xmm9, [rsp+0x80]
00007981ddfdea56  vmovaps xmm10, [rsp+0x90]
00007981ddfdea5f  vmovaps xmm11, [rsp+0xA0]
00007981ddfdea68  vmovaps xmm12, [rsp+0xB0]
00007981ddfdea71  vmovaps xmm13, [rsp+0xC0]
00007981ddfdea7a  vmovaps xmm14, [rsp+0xD0]
00007981ddfdea83  vmovaps xmm15, [rsp+0xE0]
00007981ddfdea8c  add rsp, 0xF0
00007981ddfdea93  pop r11
00007981ddfdea95  pop r10
00007981ddfdea97  pop r9
00007981ddfdea99  pop r8
00007981ddfdea9b  pop rsi
00007981ddfdea9c  pop rdi
00007981ddfdea9d  pop rdx
00007981ddfdea9e  pop rcx
00007981ddfdea9f  pop rax
00007981ddfdeaa0  add rsp, 0x08
00007981ddfdeaa4  jmp 0x00007981DDFD9892
00007981ddfdeaa9  call 0x00007981DDEB3E40
00007981ddfdeaae  jmp 0x00007981DDFD98A0
00007981ddfdeab3  call 0x00007981DDE0C380
00007981ddfdeab8  jmp 0x00007981DDFD98AA
00007981ddfdeabd  call 0x00007981DDE0D600
00007981ddfdeac2  jmp 0x00007981DDFD98B4
00007981ddfdeac7  call 0x00007981DDDFF540
00007981ddfdeacc  jmp 0x00007981DDFD98BE
00007981ddfdead1  int3
00007981ddfdead2  nop [rax+rax*1], ax
00007981ddfdeadb  nop [rax+rax*1], eax
00007981ddfdeae0  mov eax, [r15+0x48]
00007981ddfdeae4  lea r14d, [eax+0x01]
00007981ddfdeae9  mov [rsp+0x10], r14d
00007981ddfdeaee  mov r14d, r14d
00007981ddfdeaf1  mov [r15+0x48], r14
00007981ddfdeaf5  xor eax, eax
00007981ddfdeaf7  mov r14d, [rsp+0x10]
00007981ddfdeafc  cmp r14d, 0x1F4
00007981ddfdeb03  cmc
00007981ddfdeb04  lahf
00007981ddfdeb05  seto al
00007981ddfdeb08  mov [r15+0x108], eax
00007981ddfdeb0f  mov eax, [r15+0x108]
00007981ddfdeb16  sahf
00007981ddfdeb17  jnz 0x00007981DDFDEB49
00007981ddfdeb19  cmp dword ptr [r15+0x318], 0x00
00007981ddfdeb21  jz 0x00007981DDFE4C90
00007981ddfdeb27  nop [rax+rax*1], ax
00007981ddfdeb30  nop [rax+rax*1], eax
00007981ddfdeb38  mov eax, 0x4106DC
00007981ddfdeb3d  mov [r15+0x100], rax
00007981ddfdeb44  jmp 0x00007981DDDFE110
00007981ddfdeb49  cmp dword ptr [r15+0x318], 0x00
00007981ddfdeb51  jz 0x00007981DDFDEB80
00007981ddfdeb57  nop [rax+rax*1], ax
00007981ddfdeb60  nop [rax+rax*1], eax
00007981ddfdeb68  mov eax, 0x410500
00007981ddfdeb6d  mov [r15+0x100], rax
00007981ddfdeb74  jmp 0x00007981DDDFE110
00007981ddfdeb79  int3
00007981ddfdeb7a  int3
00007981ddfdeb7b  nop [rax+rax*1], eax
00007981ddfdeb80  mov rax, [r15+0x40]
00007981ddfdeb84  movaps xmm1, [r15+0x1D0]
00007981ddfdeb8c  vmovaps [rsp+0x10], xmm1
00007981ddfdeb92  vmovaps xmm15, [rsp+0x10]
00007981ddfdeb98  por xmm1, xmm15
00007981ddfdeb9d  movaps xmm14, [r15+0x1A0]
00007981ddfdeba5  vmovaps [rsp+0x10], xmm14
00007981ddfdebab  vmovaps xmm13, [rsp+0x10]
00007981ddfdebb1  por xmm14, xmm13
00007981ddfdebb6  lea r14, [rax+0x30]
00007981ddfdebba  mov r12, [r13+r14*1]
00007981ddfdebbf  lea r14, [rax+0x38]
00007981ddfdebc3  mov r11, [r13+r14*1]
00007981ddfdebc8  movq xmm13, r12
00007981ddfdebcd  movq xmm12, r11
00007981ddfdebd2  movq xmm13, xmm13
00007981ddfdebd7  vmovaps [rsp+0x10], xmm13
00007981ddfdebdd  movq xmm13, xmm13
00007981ddfdebe2  movaps [r15+0x130], xmm13
00007981ddfdebea  movq xmm12, xmm12
00007981ddfdebef  vmovaps [rsp+0x20], xmm12
00007981ddfdebf5  movq xmm12, xmm12
00007981ddfdebfa  movaps [r15+0x280], xmm12
00007981ddfdec02  movaps xmm13, [r15+0x270]
00007981ddfdec0a  vmovaps [rsp+0x30], xmm13
00007981ddfdec10  vmovaps xmm12, [rsp+0x30]
00007981ddfdec16  por xmm13, xmm12
00007981ddfdec1b  lea r14, [rax+0x20]
00007981ddfdec1f  mov r12, [r13+r14*1]
00007981ddfdec24  lea r14, [rax+0x28]
00007981ddfdec28  mov r11, [r13+r14*1]
00007981ddfdec2d  movq xmm12, r12
00007981ddfdec32  movq xmm11, r11
00007981ddfdec37  movq xmm12, xmm12
00007981ddfdec3c  vmovaps [rsp+0x30], xmm12
00007981ddfdec42  movq xmm12, xmm12
00007981ddfdec47  movaps [r15+0x150], xmm12
00007981ddfdec4f  movq xmm11, xmm11
00007981ddfdec54  vmovaps [rsp+0x40], xmm11
00007981ddfdec5a  movq xmm11, xmm11
00007981ddfdec5f  movaps [r15+0x140], xmm11
00007981ddfdec67  lea r14, [rax+0x10]
00007981ddfdec6b  mov r12, [r13+r14*1]
00007981ddfdec70  lea r14, [rax+0x18]
00007981ddfdec74  mov r11, [r13+r14*1]
00007981ddfdec79  movq xmm12, r12
00007981ddfdec7e  movq xmm11, r11
00007981ddfdec83  movq xmm12, xmm12
00007981ddfdec88  vmovaps [rsp+0x50], xmm12
00007981ddfdec8e  movq xmm12, xmm12
00007981ddfdec93  movaps [r15+0x170], xmm12
00007981ddfdec9b  movq xmm11, xmm11
00007981ddfdeca0  vmovaps [rsp+0x60], xmm11
00007981ddfdeca6  movq xmm11, xmm11
00007981ddfdecab  movaps [r15+0x160], xmm11
00007981ddfdecb3  mov r14, [r13+rax*1]
00007981ddfdecb8  vmovq xmm12, r14
00007981ddfdecbd  vpbroadcastq xmm12, xmm12
00007981ddfdecc2  lea r14, [rax+0x08]
00007981ddfdecc6  mov rax, [r13+r14*1]
00007981ddfdeccb  movq xmm11, rax
00007981ddfdecd0  movaps [r15+0x230], xmm11
00007981ddfdecd8  mov rax, [r15+0xF8]
00007981ddfdecdf  lea r14, [rax+0x50]
00007981ddfdece3  movups xmm11, [r13+r14*1]
00007981ddfdece9  lea r14, [rax+0x60]
00007981ddfdeced  movups xmm10, [r13+r14*1]
00007981ddfdecf3  lea r14, [rax+0x30]
00007981ddfdecf7  movups xmm9, [r13+r14*1]
00007981ddfdecfd  mov r14, [r15+0x50]
00007981ddfded01  mov [r15+0x60], r14
00007981ddfded05  mov qword ptr [r15+0x58], 0x40
00007981ddfded0d  movaps xmm8, xmm12
00007981ddfded11  mulpd xmm8, xmm15
00007981ddfded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007981ddfded1c  ptest xmm7, xmm7
00007981ddfded21  jnz 0x00007981DDFDFB4A
00007981ddfded27  movq xmm15, qword ptr [r15+0x230]
00007981ddfded30  vmovaps [rsp+0x70], xmm15
00007981ddfded36  vpermilpd xmm15, xmm15, 0x00
00007981ddfded3c  movaps xmm7, xmm9
00007981ddfded40  mulpd xmm7, xmm15
00007981ddfded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007981ddfded4a  ptest xmm6, xmm6
00007981ddfded4f  jnz 0x00007981DDFDFC8E
00007981ddfded55  vxorps xmm15, xmm15, xmm15
00007981ddfded5a  vpbroadcastq xmm15, xmm15
00007981ddfded5f  movaps xmm9, xmm12
00007981ddfded63  mulpd xmm9, xmm10
00007981ddfded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007981ddfded6e  ptest xmm6, xmm6
00007981ddfded73  jnz 0x00007981DDFDFDD0
00007981ddfded79  movaps xmm10, xmm12
00007981ddfded7d  mulpd xmm10, xmm11
00007981ddfded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007981ddfded88  ptest xmm6, xmm6
00007981ddfded8d  jnz 0x00007981DDFDFF14
00007981ddfded93  movaps xmm11, [r15+0x1F0]
00007981ddfded9b  movaps xmm6, xmm12
00007981ddfded9f  mulpd xmm6, xmm11
00007981ddfdeda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007981ddfdeda9  ptest xmm5, xmm5
00007981ddfdedae  jnz 0x00007981DDFE0058
00007981ddfdedb4  movaps xmm12, [r15+0x2A0]
00007981ddfdedbc  vmovaps [rsp+0x80], xmm12
00007981ddfdedc5  vmovaps xmm11, [rsp+0x80]
00007981ddfdedce  por xmm12, xmm11
00007981ddfdedd3  movaps xmm11, [r15+0x250]
00007981ddfdeddb  vmovaps [rsp+0x80], xmm11
00007981ddfdede4  vmovaps xmm5, [rsp+0x80]
00007981ddfdeded  por xmm11, xmm5
00007981ddfdedf2  vmovaps xmm4, [rsp+0x70]
00007981ddfdedf8  vpermilpd xmm4, xmm4, 0x00
00007981ddfdedfe  movaps xmm3, xmm5
00007981ddfdee01  mulpd xmm3, xmm4
00007981ddfdee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007981ddfdee0a  ptest xmm2, xmm2
00007981ddfdee0f  jnz 0x00007981DDFE019A
00007981ddfdee15  mov [rsp+0x80], rax
00007981ddfdee1d  xor eax, eax
00007981ddfdee1f  mov r12d, 0x40
00007981ddfdee25  mov r11d, 0x200
00007981ddfdee2b  cmp r12, r11
00007981ddfdee2e  cmc
00007981ddfdee2f  lahf
00007981ddfdee30  seto al
00007981ddfdee33  mov [r15+0x108], eax
00007981ddfdee3a  movaps xmm5, xmm8
00007981ddfdee3e  addpd xmm5, xmm15
00007981ddfdee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007981ddfdee48  ptest xmm4, xmm4
00007981ddfdee4d  jnz 0x00007981DDFE02DA
00007981ddfdee53  movaps xmm8, [r15+0x1B0]
00007981ddfdee5b  movaps xmm4, xmm9
00007981ddfdee5f  addpd xmm4, xmm8
00007981ddfdee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007981ddfdee69  ptest xmm2, xmm2
00007981ddfdee6e  jnz 0x00007981DDFE041C
00007981ddfdee74  movaps xmm9, xmm10
00007981ddfdee78  addpd xmm9, xmm8
00007981ddfdee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007981ddfdee83  ptest xmm2, xmm2
00007981ddfdee88  jnz 0x00007981DDFE055E
00007981ddfdee8e  movaps xmm10, [r15+0x2F0]
00007981ddfdee96  vmovaps [rsp+0x90], xmm10
00007981ddfdee9f  vmovaps xmm8, [rsp+0x90]
00007981ddfdeea8  por xmm10, xmm8
00007981ddfdeead  movaps xmm8, [r15+0x2E0]
00007981ddfdeeb5  vmovaps [rsp+0x90], xmm8
00007981ddfdeebe  vmovaps xmm2, [rsp+0x90]
00007981ddfdeec7  por xmm8, xmm2
00007981ddfdeecc  movaps xmm2, [r15+0x2D0]
00007981ddfdeed4  vmovaps [rsp+0x90], xmm2
00007981ddfdeedd  vmovaps [rsp+0xA0], xmm1
00007981ddfdeee6  vmovaps xmm1, [rsp+0x90]
00007981ddfdeeef  por xmm2, xmm1
00007981ddfdeef3  movaps xmm1, [r15+0x200]
00007981ddfdeefb  vmovaps [rsp+0x90], xmm1
00007981ddfdef04  vmovaps [rsp+0xB0], xmm15
00007981ddfdef0d  vmovaps xmm15, [rsp+0x90]
00007981ddfdef16  por xmm1, xmm15
00007981ddfdef1b  movaps xmm15, [r15+0x1C0]
00007981ddfdef23  vmovaps [rsp+0x90], xmm15
00007981ddfdef2c  vmovaps [rsp+0xC0], xmm1
00007981ddfdef35  vmovaps xmm1, [rsp+0x90]
00007981ddfdef3e  por xmm15, xmm1
00007981ddfdef43  movaps xmm1, [r15+0x190]
00007981ddfdef4b  vmovaps [rsp+0x90], xmm1
00007981ddfdef54  vmovaps [rsp+0xD0], xmm15
00007981ddfdef5d  vmovaps xmm15, [rsp+0x90]
00007981ddfdef66  por xmm1, xmm15
00007981ddfdef6b  movaps xmm15, [r15+0x300]
00007981ddfdef73  vmovaps [rsp+0x90], xmm15
00007981ddfdef7c  vmovaps [rsp+0xE0], xmm1
00007981ddfdef85  vmovaps xmm1, [rsp+0x90]
00007981ddfdef8e  por xmm15, xmm1
00007981ddfdef93  mov rax, [rsp+0x80]
00007981ddfdef9b  lea r12, [rax+0xA0]
00007981ddfdefa2  movups xmm1, [r13+r12*1]
00007981ddfdefa8  lea r12, [rax+0xB0]
00007981ddfdefaf  vmovaps [rsp+0x80], xmm1
00007981ddfdefb8  movups xmm1, [r13+r12*1]
00007981ddfdefbe  vmovaps [rsp+0x90], xmm1
00007981ddfdefc7  vmovaps [rsp+0xF0], xmm15
00007981ddfdefd0  vmovaps xmm15, [rsp+0xB0]
00007981ddfdefd9  vmovaps [rsp+0xB0], xmm14
00007981ddfdefe2  movaps xmm1, xmm6
00007981ddfdefe5  addpd xmm1, xmm15
00007981ddfdefea  vcmppd xmm14, xmm1, xmm1, 0x03
00007981ddfdefef  ptest xmm14, xmm14
00007981ddfdeff5  jnz 0x00007981DDFE06B6
00007981ddfdeffb  lea r12, [rax+0xF0]
00007981ddfdf002  movups xmm15, [r13+r12*1]
00007981ddfdf008  movaps xmm14, xmm4
00007981ddfdf00c  addpd xmm14, xmm3
00007981ddfdf011  vcmppd xmm6, xmm14, xmm14, 0x03
00007981ddfdf017  ptest xmm6, xmm6
00007981ddfdf01c  jnz 0x00007981DDFE0801
00007981ddfdf022  movaps xmm6, xmm9
00007981ddfdf026  addpd xmm6, xmm7
00007981ddfdf02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007981ddfdf02f  ptest xmm4, xmm4
00007981ddfdf034  jnz 0x00007981DDFE0943
00007981ddfdf03a  vmovaps xmm9, [rsp+0x70]
00007981ddfdf040  vpermilpd xmm9, xmm9, 0x00
00007981ddfdf046  vmovaps xmm4, [rsp+0x90]
00007981ddfdf04f  movaps xmm7, xmm4
00007981ddfdf052  mulpd xmm7, xmm9
00007981ddfdf057  vcmppd xmm3, xmm7, xmm7, 0x03
00007981ddfdf05c  ptest xmm3, xmm3
00007981ddfdf061  jnz 0x00007981DDFE0A84
00007981ddfdf067  vmovaps xmm9, [rsp+0x50]
00007981ddfdf06d  vpermilpd xmm9, xmm9, 0x00
00007981ddfdf073  movaps xmm4, xmm15
00007981ddfdf077  mulpd xmm4, xmm9
00007981ddfdf07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007981ddfdf081  ptest xmm3, xmm3
00007981ddfdf086  jnz 0x00007981DDFE0BC5
00007981ddfdf08c  lea r12, [rax+0xE0]
00007981ddfdf093  movups xmm15, [r13+r12*1]
00007981ddfdf099  vmovaps xmm9, [rsp+0x70]
00007981ddfdf09f  vpermilpd xmm9, xmm9, 0x00
00007981ddfdf0a5  vmovaps [rsp+0x70], xmm1
00007981ddfdf0ab  vmovaps xmm1, [rsp+0x80]
00007981ddfdf0b4  vmovaps [rsp+0x80], xmm15
00007981ddfdf0bd  movaps xmm3, xmm1
00007981ddfdf0c0  mulpd xmm3, xmm9
00007981ddfdf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007981ddfdf0ca  ptest xmm15, xmm15
00007981ddfdf0d0  jnz 0x00007981DDFE0D11
00007981ddfdf0d6  vmovaps xmm1, [rsp+0xF0]
00007981ddfdf0df  vmovaps xmm15, [rsp+0xF0]
00007981ddfdf0e8  por xmm1, xmm15
00007981ddfdf0ed  movaps [r15+0x300], xmm1
00007981ddfdf0f5  vmovaps xmm15, [rsp+0xE0]
00007981ddfdf0fe  vmovaps xmm9, [rsp+0xE0]
00007981ddfdf107  por xmm15, xmm9
00007981ddfdf10c  movaps [r15+0x190], xmm15
00007981ddfdf114  vmovaps xmm9, [rsp+0x50]
00007981ddfdf11a  vpermilpd xmm9, xmm9, 0x00
00007981ddfdf120  vmovaps [rsp+0x90], xmm1
00007981ddfdf129  vmovaps [rsp+0xE0], xmm15
00007981ddfdf132  vmovaps xmm15, [rsp+0x80]
00007981ddfdf13b  vmovaps [rsp+0x80], xmm14
00007981ddfdf144  movaps xmm1, xmm15
00007981ddfdf148  mulpd xmm1, xmm9
00007981ddfdf14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007981ddfdf152  ptest xmm14, xmm14
00007981ddfdf158  jnz 0x00007981DDFE0E52
00007981ddfdf15e  lea r12, [rax+0x90]
00007981ddfdf165  movups xmm15, [r13+r12*1]
00007981ddfdf16b  vmovaps xmm14, [rsp+0xD0]
00007981ddfdf174  vmovaps xmm9, [rsp+0xD0]
00007981ddfdf17d  por xmm14, xmm9
00007981ddfdf182  movaps [r15+0x1C0], xmm14
00007981ddfdf18a  vmovaps xmm9, [rsp+0xC0]
00007981ddfdf193  vmovaps [rsp+0xD0], xmm1
00007981ddfdf19c  vmovaps xmm1, [rsp+0xC0]
00007981ddfdf1a5  por xmm9, xmm1
00007981ddfdf1aa  movaps [r15+0x200], xmm9
00007981ddfdf1b2  vmovaps [rsp+0xC0], xmm2
00007981ddfdf1bb  vmovaps xmm1, [rsp+0xC0]
00007981ddfdf1c4  por xmm2, xmm1
00007981ddfdf1c8  movaps [r15+0x2D0], xmm2
00007981ddfdf1d0  vmovaps [rsp+0xC0], xmm8
00007981ddfdf1d9  vmovaps xmm1, [rsp+0xC0]
00007981ddfdf1e2  por xmm8, xmm1
00007981ddfdf1e7  movaps [r15+0x2E0], xmm8
00007981ddfdf1ef  vmovaps [rsp+0xC0], xmm15
00007981ddfdf1f8  movaps xmm1, xmm5
00007981ddfdf1fb  addpd xmm1, xmm7
00007981ddfdf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007981ddfdf204  ptest xmm15, xmm15
00007981ddfdf20a  jnz 0x00007981DDFE0F9E
00007981ddfdf210  vmovaps xmm15, [rsp+0x50]
00007981ddfdf216  vpermilpd xmm15, xmm15, 0x00
00007981ddfdf21c  vmovaps xmm5, [rsp+0xC0]
00007981ddfdf225  vmovaps [rsp+0xC0], xmm1
00007981ddfdf22e  movaps xmm7, xmm5
00007981ddfdf231  mulpd xmm7, xmm15
00007981ddfdf236  vcmppd xmm1, xmm7, xmm7, 0x03
00007981ddfdf23b  ptest xmm1, xmm1
00007981ddfdf240  jnz 0x00007981DDFE10DE
00007981ddfdf246  lea r12, [rax+0x80]
00007981ddfdf24d  movups xmm1, [r13+r12*1]
00007981ddfdf253  vmovaps xmm5, [rsp+0x70]
00007981ddfdf259  vmovaps [rsp+0x70], xmm1
00007981ddfdf25f  movaps xmm15, xmm5
00007981ddfdf263  addpd xmm15, xmm3
00007981ddfdf268  vcmppd xmm1, xmm15, xmm15, 0x03
00007981ddfdf26e  ptest xmm1, xmm1
00007981ddfdf273  jnz 0x00007981DDFE1229
00007981ddfdf279  vmovaps xmm5, [rsp+0x80]
00007981ddfdf282  movaps xmm1, xmm5
00007981ddfdf285  addpd xmm1, xmm4
00007981ddfdf289  vcmppd xmm3, xmm1, xmm1, 0x03
00007981ddfdf28e  ptest xmm3, xmm3
00007981ddfdf293  jnz 0x00007981DDFE136B
00007981ddfdf299  vmovaps [rsp+0x80], xmm10
00007981ddfdf2a2  vmovaps xmm5, [rsp+0x80]
00007981ddfdf2ab  por xmm10, xmm5
00007981ddfdf2b0  movaps [r15+0x2F0], xmm10
00007981ddfdf2b8  vmovaps xmm5, [rsp+0x50]
00007981ddfdf2be  vpermilpd xmm5, xmm5, 0x00
00007981ddfdf2c4  vmovaps xmm3, [rsp+0x70]
00007981ddfdf2ca  vmovaps [rsp+0x50], xmm1
00007981ddfdf2d0  movaps xmm4, xmm3
00007981ddfdf2d3  mulpd xmm4, xmm5
00007981ddfdf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007981ddfdf2dc  ptest xmm1, xmm1
00007981ddfdf2e1  jnz 0x00007981DDFE14AB
00007981ddfdf2e7  lea r12, [rax+0xD0]
00007981ddfdf2ee  movups xmm1, [r13+r12*1]
00007981ddfdf2f4  vmovaps xmm3, [rsp+0xD0]
00007981ddfdf2fd  vmovaps [rsp+0x70], xmm1
00007981ddfdf303  movaps xmm5, xmm6
00007981ddfdf306  addpd xmm5, xmm3
00007981ddfdf30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007981ddfdf30f  ptest xmm1, xmm1
00007981ddfdf314  jnz 0x00007981DDFE15F5
00007981ddfdf31a  vmovaps xmm1, [rsp+0x60]
00007981ddfdf320  vpermilpd xmm1, xmm1, 0x00
00007981ddfdf326  movaps xmm6, xmm9
00007981ddfdf32a  mulpd xmm6, xmm1
00007981ddfdf32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007981ddfdf333  ptest xmm3, xmm3
00007981ddfdf338  jnz 0x00007981DDFE1735
00007981ddfdf33e  movaps [r15+0x260], xmm6
00007981ddfdf346  vxorps xmm1, xmm1, xmm1
00007981ddfdf34a  vpbroadcastq xmm1, xmm1
00007981ddfdf34f  movaps [r15+0x1B0], xmm1
00007981ddfdf357  vmovaps xmm1, [rsp+0x60]
00007981ddfdf35d  vpermilpd xmm1, xmm1, 0x00
00007981ddfdf363  vmovaps xmm3, [rsp+0x70]
00007981ddfdf369  vmovaps [rsp+0x70], xmm15
00007981ddfdf36f  movaps xmm9, xmm3
00007981ddfdf373  mulpd xmm9, xmm1
00007981ddfdf378  vcmppd xmm15, xmm9, xmm9, 0x03
00007981ddfdf37e  ptest xmm15, xmm15
00007981ddfdf384  jnz 0x00007981DDFE1876
00007981ddfdf38a  lea r12, [rax+0xC0]
00007981ddfdf391  movups xmm1, [r13+r12*1]
00007981ddfdf397  vmovaps xmm3, [rsp+0xC0]
00007981ddfdf3a0  vmovaps [rsp+0x80], xmm1
00007981ddfdf3a9  movaps xmm15, xmm3
00007981ddfdf3ad  addpd xmm15, xmm7
00007981ddfdf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007981ddfdf3b8  ptest xmm1, xmm1
00007981ddfdf3bd  jnz 0x00007981DDFE19C2
00007981ddfdf3c3  vmovaps [rsp+0xC0], xmm13
00007981ddfdf3cc  vmovaps xmm1, [rsp+0xC0]
00007981ddfdf3d5  por xmm13, xmm1
00007981ddfdf3da  movaps [r15+0x270], xmm13
00007981ddfdf3e2  vmovaps xmm1, [rsp+0xB0]
00007981ddfdf3eb  vmovaps xmm7, [rsp+0xB0]
00007981ddfdf3f4  por xmm1, xmm7
00007981ddfdf3f8  movaps [r15+0x1A0], xmm1
00007981ddfdf400  vmovaps xmm1, [rsp+0x60]
00007981ddfdf406  vpermilpd xmm1, xmm1, 0x00
00007981ddfdf40c  vmovaps [rsp+0xB0], xmm1
00007981ddfdf415  vmovaps xmm1, [rsp+0x80]
00007981ddfdf41e  vmovaps [rsp+0x80], xmm15
00007981ddfdf427  vmovaps xmm15, [rsp+0xB0]
00007981ddfdf430  vmovaps [rsp+0xB0], xmm14
00007981ddfdf439  movaps xmm3, xmm1
00007981ddfdf43c  mulpd xmm3, xmm15
00007981ddfdf441  vcmppd xmm14, xmm3, xmm3, 0x03
00007981ddfdf446  ptest xmm14, xmm14
00007981ddfdf44c  jnz 0x00007981DDFE1B04
00007981ddfdf452  lea r12, [rax+0x20]
00007981ddfdf456  movups xmm1, [r13+r12*1]
00007981ddfdf45c  movaps [r15+0x110], xmm1
00007981ddfdf464  vmovaps xmm14, [rsp+0x70]
00007981ddfdf46a  vmovaps [rsp+0x70], xmm1
00007981ddfdf470  movaps xmm15, xmm14
00007981ddfdf474  addpd xmm15, xmm4
00007981ddfdf479  vcmppd xmm1, xmm15, xmm15, 0x03
00007981ddfdf47f  ptest xmm1, xmm1
00007981ddfdf484  jnz 0x00007981DDFE1C4F
00007981ddfdf48a  vmovaps xmm1, [rsp+0x60]
00007981ddfdf490  vpermilpd xmm1, xmm1, 0x00
00007981ddfdf496  movaps xmm14, xmm2
00007981ddfdf49a  mulpd xmm14, xmm1
00007981ddfdf49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007981ddfdf4a5  ptest xmm4, xmm4
00007981ddfdf4aa  jnz 0x00007981DDFE1D92
00007981ddfdf4b0  vmovaps xmm4, [rsp+0x50]
00007981ddfdf4b6  movaps xmm1, xmm4
00007981ddfdf4b9  addpd xmm1, xmm9
00007981ddfdf4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007981ddfdf4c3  ptest xmm2, xmm2
00007981ddfdf4c8  jnz 0x00007981DDFE1ED4
00007981ddfdf4ce  vmovaps xmm9, [rsp+0x30]
00007981ddfdf4d4  vpermilpd xmm9, xmm9, 0x00
00007981ddfdf4da  vmovaps xmm2, [rsp+0x70]
00007981ddfdf4e0  vmovaps [rsp+0x50], xmm1
00007981ddfdf4e6  movaps xmm4, xmm2
00007981ddfdf4e9  mulpd xmm4, xmm9
00007981ddfdf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007981ddfdf4f3  ptest xmm1, xmm1
00007981ddfdf4f8  jnz 0x00007981DDFE2015
00007981ddfdf4fe  vmovaps xmm1, [rsp+0x30]
00007981ddfdf504  vpermilpd xmm1, xmm1, 0x00
00007981ddfdf50a  vmovaps xmm2, [rsp+0x90]
00007981ddfdf513  vmovaps [rsp+0x60], xmm15
00007981ddfdf519  movaps xmm9, xmm2
00007981ddfdf51d  mulpd xmm9, xmm1
00007981ddfdf522  vcmppd xmm15, xmm9, xmm9, 0x03
00007981ddfdf528  ptest xmm15, xmm15
00007981ddfdf52e  jnz 0x00007981DDFE2156
00007981ddfdf534  vmovaps xmm15, [rsp+0x80]
00007981ddfdf53d  movaps xmm1, xmm15
00007981ddfdf541  addpd xmm1, xmm6
00007981ddfdf545  vcmppd xmm2, xmm1, xmm1, 0x03
00007981ddfdf54a  ptest xmm2, xmm2
00007981ddfdf54f  jnz 0x00007981DDFE2298
00007981ddfdf555  movaps xmm15, xmm5
00007981ddfdf559  addpd xmm15, xmm3
00007981ddfdf55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007981ddfdf564  ptest xmm6, xmm6
00007981ddfdf569  jnz 0x00007981DDFE23D9
00007981ddfdf56f  vmovaps xmm6, [rsp+0x30]
00007981ddfdf575  vpermilpd xmm6, xmm6, 0x00
00007981ddfdf57b  movaps xmm5, xmm8
00007981ddfdf57f  mulpd xmm5, xmm6
00007981ddfdf583  vcmppd xmm3, xmm5, xmm5, 0x03
00007981ddfdf588  ptest xmm3, xmm3
00007981ddfdf58d  jnz 0x00007981DDFE251B
00007981ddfdf593  vmovaps xmm8, [rsp+0x30]
00007981ddfdf599  vpermilpd xmm8, xmm8, 0x00
00007981ddfdf59f  movaps xmm6, xmm10
00007981ddfdf5a3  mulpd xmm6, xmm8
00007981ddfdf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007981ddfdf5ad  ptest xmm3, xmm3
00007981ddfdf5b2  jnz 0x00007981DDFE265C
00007981ddfdf5b8  vmovaps xmm8, [rsp+0x60]
00007981ddfdf5be  movaps xmm10, xmm8
00007981ddfdf5c2  addpd xmm10, xmm14
00007981ddfdf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007981ddfdf5cd  ptest xmm3, xmm3
00007981ddfdf5d2  jnz 0x00007981DDFE279E
00007981ddfdf5d8  vmovaps xmm8, [rsp+0x50]
00007981ddfdf5de  movaps xmm14, xmm8
00007981ddfdf5e2  addpd xmm14, xmm4
00007981ddfdf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007981ddfdf5ed  ptest xmm3, xmm3
00007981ddfdf5f2  jnz 0x00007981DDFE28E2
00007981ddfdf5f8  vmovaps xmm8, [rsp+0x40]
00007981ddfdf5fe  vpermilpd xmm8, xmm8, 0x00
00007981ddfdf604  movaps xmm4, xmm13
00007981ddfdf608  mulpd xmm4, xmm8
00007981ddfdf60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007981ddfdf612  ptest xmm3, xmm3
00007981ddfdf617  jnz 0x00007981DDFE2A25
00007981ddfdf61d  movaps xmm13, xmm15
00007981ddfdf621  addpd xmm13, xmm9
00007981ddfdf626  vcmppd xmm8, xmm13, xmm13, 0x03
00007981ddfdf62c  ptest xmm8, xmm8
00007981ddfdf632  jnz 0x00007981DDFE2B67
00007981ddfdf638  movaps xmm15, xmm1
00007981ddfdf63c  addpd xmm15, xmm5
00007981ddfdf641  vcmppd xmm9, xmm15, xmm15, 0x03
00007981ddfdf647  ptest xmm9, xmm9
00007981ddfdf64d  jnz 0x00007981DDFE2CAB
00007981ddfdf653  vmovaps [rsp+0x30], xmm11
00007981ddfdf659  vmovaps xmm1, [rsp+0x30]
00007981ddfdf65f  por xmm11, xmm1
00007981ddfdf664  movaps [r15+0x250], xmm11
00007981ddfdf66c  vmovaps [rsp+0x30], xmm12
00007981ddfdf672  vmovaps xmm1, [rsp+0x30]
00007981ddfdf678  por xmm12, xmm1
00007981ddfdf67d  movaps [r15+0x2A0], xmm12
00007981ddfdf685  vmovaps xmm1, [rsp+0xA0]
00007981ddfdf68e  vmovaps xmm11, [rsp+0xA0]
00007981ddfdf697  por xmm1, xmm11
00007981ddfdf69c  movaps [r15+0x1D0], xmm1
00007981ddfdf6a4  lea r12, [rax+0x40]
00007981ddfdf6a8  movups xmm1, [r13+r12*1]
00007981ddfdf6ae  movaps [r15+0x2C0], xmm1
00007981ddfdf6b6  vmovaps xmm11, [rsp+0x40]
00007981ddfdf6bc  vpermilpd xmm11, xmm11, 0x00
00007981ddfdf6c2  vmovaps xmm8, [rsp+0xE0]
00007981ddfdf6cb  movaps xmm9, xmm8
00007981ddfdf6cf  mulpd xmm9, xmm11
00007981ddfdf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007981ddfdf6da  ptest xmm5, xmm5
00007981ddfdf6df  jnz 0x00007981DDFE2DF7
00007981ddfdf6e5  movaps xmm11, xmm10
00007981ddfdf6e9  addpd xmm11, xmm6
00007981ddfdf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007981ddfdf6f4  ptest xmm8, xmm8
00007981ddfdf6fa  jnz 0x00007981DDFE2F3B
00007981ddfdf700  movaps xmm10, xmm14
00007981ddfdf704  addpd xmm10, xmm4
00007981ddfdf709  vcmppd xmm8, xmm10, xmm10, 0x03
00007981ddfdf70f  ptest xmm8, xmm8
00007981ddfdf715  jnz 0x00007981DDFE307E
00007981ddfdf71b  vmovaps xmm14, [rsp+0x40]
00007981ddfdf721  vpermilpd xmm14, xmm14, 0x00
00007981ddfdf727  movaps xmm8, xmm1
00007981ddfdf72b  mulpd xmm8, xmm14
00007981ddfdf730  vcmppd xmm6, xmm8, xmm8, 0x03
00007981ddfdf736  ptest xmm6, xmm6
00007981ddfdf73b  jnz 0x00007981DDFE31C1
00007981ddfdf741  movaps xmm1, [r15+0x2B0]
00007981ddfdf749  vmovaps xmm14, [rsp+0x40]
00007981ddfdf74f  vpermilpd xmm14, xmm14, 0x00
00007981ddfdf755  movaps xmm6, xmm1
00007981ddfdf758  mulpd xmm6, xmm14
00007981ddfdf75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007981ddfdf762  ptest xmm5, xmm5
00007981ddfdf767  jnz 0x00007981DDFE3304
00007981ddfdf76d  vmovaps xmm1, [rsp+0x10]
00007981ddfdf773  vpermilpd xmm1, xmm1, 0x00
00007981ddfdf779  movaps xmm14, xmm12
00007981ddfdf77d  mulpd xmm14, xmm1
00007981ddfdf782  vcmppd xmm5, xmm14, xmm14, 0x03
00007981ddfdf788  ptest xmm5, xmm5
00007981ddfdf78d  jnz 0x00007981DDFE3445
00007981ddfdf793  movaps xmm1, xmm13
00007981ddfdf797  addpd xmm1, xmm9
00007981ddfdf79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007981ddfdf7a1  ptest xmm12, xmm12
00007981ddfdf7a7  jnz 0x00007981DDFE3588
00007981ddfdf7ad  vmovaps xmm13, [rsp+0x10]
00007981ddfdf7b3  vpermilpd xmm13, xmm13, 0x00
00007981ddfdf7b9  movaps xmm12, xmm7
00007981ddfdf7bd  mulpd xmm12, xmm13
00007981ddfdf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007981ddfdf7c8  ptest xmm9, xmm9
00007981ddfdf7ce  jnz 0x00007981DDFE36CA
00007981ddfdf7d4  movaps xmm13, xmm15
00007981ddfdf7d8  addpd xmm13, xmm8
00007981ddfdf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007981ddfdf7e3  ptest xmm9, xmm9
00007981ddfdf7e9  jnz 0x00007981DDFE380D
00007981ddfdf7ef  movaps xmm15, [r15+0x290]
00007981ddfdf7f7  vmovaps xmm9, [rsp+0x10]
00007981ddfdf7fd  vpermilpd xmm9, xmm9, 0x00
00007981ddfdf803  movaps xmm8, xmm15
00007981ddfdf807  mulpd xmm8, xmm9
00007981ddfdf80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007981ddfdf812  ptest xmm7, xmm7
00007981ddfdf817  jnz 0x00007981DDFE3951
00007981ddfdf81d  movaps xmm15, xmm11
00007981ddfdf821  addpd xmm15, xmm6
00007981ddfdf826  vcmppd xmm9, xmm15, xmm15, 0x03
00007981ddfdf82c  ptest xmm9, xmm9
00007981ddfdf832  jnz 0x00007981DDFE3A95
00007981ddfdf838  movaps xmm11, [r15+0x1E0]
00007981ddfdf840  vmovaps xmm9, [rsp+0x10]
00007981ddfdf846  vpermilpd xmm9, xmm9, 0x00
00007981ddfdf84c  movaps xmm7, xmm11
00007981ddfdf850  mulpd xmm7, xmm9
00007981ddfdf855  vcmppd xmm6, xmm7, xmm7, 0x03
00007981ddfdf85a  ptest xmm6, xmm6
00007981ddfdf85f  jnz 0x00007981DDFE3BD8
00007981ddfdf865  movaps xmm11, xmm10
00007981ddfdf869  addpd xmm11, xmm14
00007981ddfdf86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007981ddfdf874  ptest xmm9, xmm9
00007981ddfdf87a  jnz 0x00007981DDFE3D1A
00007981ddfdf880  lea r12, [rax+0x70]
00007981ddfdf884  movups xmm14, [r13+r12*1]
00007981ddfdf88a  movaps [r15+0x240], xmm14
00007981ddfdf892  movaps xmm10, xmm1
00007981ddfdf896  addpd xmm10, xmm12
00007981ddfdf89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007981ddfdf8a1  ptest xmm9, xmm9
00007981ddfdf8a7  jnz 0x00007981DDFE3E68
00007981ddfdf8ad  movaps [r15+0x170], xmm10
00007981ddfdf8b5  vmovaps xmm1, [rsp+0x20]
00007981ddfdf8bb  vpermilpd xmm1, xmm1, 0x00
00007981ddfdf8c1  movaps xmm12, xmm14
00007981ddfdf8c5  mulpd xmm12, xmm1
00007981ddfdf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007981ddfdf8d0  ptest xmm9, xmm9
00007981ddfdf8d6  jnz 0x00007981DDFE3FAB
00007981ddfdf8dc  vmovaps xmm1, [rsp+0x20]
00007981ddfdf8e2  vpermilpd xmm1, xmm1, 0x00
00007981ddfdf8e8  vmovaps xmm9, [rsp+0xB0]
00007981ddfdf8f1  movaps xmm14, xmm9
00007981ddfdf8f5  mulpd xmm14, xmm1
00007981ddfdf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007981ddfdf900  ptest xmm6, xmm6
00007981ddfdf905  jnz 0x00007981DDFE40EE
00007981ddfdf90b  movaps [r15+0x180], xmm14
00007981ddfdf913  movaps xmm1, xmm13
00007981ddfdf917  addpd xmm1, xmm8
00007981ddfdf91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007981ddfdf921  ptest xmm9, xmm9
00007981ddfdf927  jnz 0x00007981DDFE4231
00007981ddfdf92d  movaps [r15+0x210], xmm1
00007981ddfdf935  movups xmm13, [r13+rax*1]
00007981ddfdf93b  lea r12, [rax+0x10]
00007981ddfdf93f  movups xmm9, [r13+r12*1]
00007981ddfdf945  movaps [r15+0x230], xmm9
00007981ddfdf94d  movaps xmm8, xmm15
00007981ddfdf951  addpd xmm8, xmm7
00007981ddfdf956  vcmppd xmm6, xmm8, xmm8, 0x03
00007981ddfdf95c  ptest xmm6, xmm6
00007981ddfdf961  jnz 0x00007981DDFE4387
00007981ddfdf967  movaps [r15+0x130], xmm8
00007981ddfdf96f  vmovaps xmm15, [rsp+0x20]
00007981ddfdf975  vpermilpd xmm15, xmm15, 0x00
00007981ddfdf97b  movaps xmm7, xmm9
00007981ddfdf97f  mulpd xmm7, xmm15
00007981ddfdf984  vcmppd xmm6, xmm7, xmm7, 0x03
00007981ddfdf989  ptest xmm6, xmm6
00007981ddfdf98e  jnz 0x00007981DDFE44CA
00007981ddfdf994  movaps [r15+0x220], xmm7
00007981ddfdf99c  vmovaps xmm15, [rsp+0x20]
00007981ddfdf9a2  vpermilpd xmm15, xmm15, 0x00
00007981ddfdf9a8  movaps xmm9, xmm13
00007981ddfdf9ac  mulpd xmm9, xmm15
00007981ddfdf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007981ddfdf9b7  ptest xmm6, xmm6
00007981ddfdf9bc  jnz 0x00007981DDFE460C
00007981ddfdf9c2  movaps xmm15, xmm11
00007981ddfdf9c6  addpd xmm15, xmm12
00007981ddfdf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007981ddfdf9d1  ptest xmm13, xmm13
00007981ddfdf9d7  jnz 0x00007981DDFE4750
00007981ddfdf9dd  movaps [r15+0x140], xmm15
00007981ddfdf9e5  movaps xmm13, xmm10
00007981ddfdf9e9  addpd xmm13, xmm14
00007981ddfdf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007981ddfdf9f4  ptest xmm12, xmm12
00007981ddfdf9fa  jnz 0x00007981DDFE4894
00007981ddfdfa00  movaps [r15+0x150], xmm13
00007981ddfdfa08  movaps xmm14, xmm1
00007981ddfdfa0c  addpd xmm14, xmm7
00007981ddfdfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007981ddfdfa17  ptest xmm12, xmm12
00007981ddfdfa1d  jnz 0x00007981DDFE49D8
00007981ddfdfa23  movaps [r15+0x160], xmm14
00007981ddfdfa2b  movaps xmm1, xmm8
00007981ddfdfa2f  addpd xmm1, xmm9
00007981ddfdfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007981ddfdfa39  ptest xmm12, xmm12
00007981ddfdfa3f  jnz 0x00007981DDFE4B1A
00007981ddfdfa45  movaps [r15+0x120], xmm1
00007981ddfdfa4d  movups [r13+r14*1], xmm15
00007981ddfdfa53  lea rax, [r14+0x10]
00007981ddfdfa57  movups [r13+rax*1], xmm13
00007981ddfdfa5d  lea rax, [r14+0x20]
00007981ddfdfa61  movups [r13+rax*1], xmm14
00007981ddfdfa67  lea rax, [r14+0x30]
00007981ddfdfa6b  movups [r13+rax*1], xmm1
00007981ddfdfa71  mov eax, [r15+0x108]
00007981ddfdfa78  sahf
00007981ddfdfa79  jnz 0x00007981DDFDFAAB
00007981ddfdfa7b  cmp dword ptr [r15+0x318], 0x00
00007981ddfdfa83  jz 0x00007981DDFDEAE0
00007981ddfdfa89  nop [rax+rax*1], ax
00007981ddfdfa92  nop [rax+rax*1], eax
00007981ddfdfa9a  mov eax, 0x4106D0
00007981ddfdfa9f  mov [r15+0x100], rax
00007981ddfdfaa6  jmp 0x00007981DDDFE110
00007981ddfdfaab  cmp dword ptr [r15+0x318], 0x00
00007981ddfdfab3  jz 0x00007981DDFD89C0
00007981ddfdfab9  nop [rax+rax*1], ax
00007981ddfdfac2  nop [rax+rax*1], eax
00007981ddfdfaca  mov eax, 0x410504
00007981ddfdfacf  mov [r15+0x100], rax
00007981ddfdfad6  jmp 0x00007981DDDFE110
00007981ddfdfadb  int3
00007981ddfdfadc  call 0x00007981DDEE27E0
00007981ddfdfae1  jmp 0x00007981DDFDEBBF
00007981ddfdfae6  call 0x00007981DDEE1570
00007981ddfdfaeb  jmp 0x00007981DDFDEBC8
00007981ddfdfaf0  call 0x00007981DDEE27E0
00007981ddfdfaf5  jmp 0x00007981DDFDEC24
00007981ddfdfafa  call 0x00007981DDEE1570
00007981ddfdfaff  jmp 0x00007981DDFDEC2D
00007981ddfdfb04  call 0x00007981DDEE27E0
00007981ddfdfb09  jmp 0x00007981DDFDEC70
00007981ddfdfb0e  call 0x00007981DDEE1570
00007981ddfdfb13  jmp 0x00007981DDFDEC79
00007981ddfdfb18  call 0x00007981DDE0DC20
00007981ddfdfb1d  jmp 0x00007981DDFDECB8
00007981ddfdfb22  call 0x00007981DDED59C0
00007981ddfdfb27  jmp 0x00007981DDFDECCB
00007981ddfdfb2c  call 0x00007981DDEE0E30
00007981ddfdfb31  jmp 0x00007981DDFDECE9
00007981ddfdfb36  call 0x00007981DDEDFBC0
00007981ddfdfb3b  jmp 0x00007981DDFDECF3
00007981ddfdfb40  call 0x00007981DDEDE950
00007981ddfdfb45  jmp 0x00007981DDFDECFD
00007981ddfdfb4a  sub rsp, 0x08
00007981ddfdfb4e  push rax
00007981ddfdfb4f  push rcx
00007981ddfdfb50  push rdx
00007981ddfdfb51  push rdi
00007981ddfdfb52  push rsi
00007981ddfdfb53  push r8
00007981ddfdfb55  push r9
00007981ddfdfb57  push r10
00007981ddfdfb59  push r11
00007981ddfdfb5b  sub rsp, 0xF0
00007981ddfdfb62  vmovaps [rsp], xmm0
00007981ddfdfb67  vmovaps [rsp+0x10], xmm1
00007981ddfdfb6d  vmovaps [rsp+0x20], xmm2
00007981ddfdfb73  vmovaps [rsp+0x30], xmm3
00007981ddfdfb79  vmovaps [rsp+0x40], xmm4
00007981ddfdfb7f  vmovaps [rsp+0x50], xmm5
00007981ddfdfb85  vmovaps [rsp+0x60], xmm6
00007981ddfdfb8b  vmovaps [rsp+0x70], xmm7
00007981ddfdfb91  vmovaps [rsp+0x80], xmm9
00007981ddfdfb9a  vmovaps [rsp+0x90], xmm10
00007981ddfdfba3  vmovaps [rsp+0xA0], xmm11
00007981ddfdfbac  vmovaps [rsp+0xB0], xmm12
00007981ddfdfbb5  vmovaps [rsp+0xC0], xmm13
00007981ddfdfbbe  vmovaps [rsp+0xD0], xmm14
00007981ddfdfbc7  vmovaps [rsp+0xE0], xmm15
00007981ddfdfbd0  sub rsp, 0x30
00007981ddfdfbd4  movaps [rsp], xmm8
00007981ddfdfbd9  movaps [rsp+0x10], xmm12
00007981ddfdfbdf  movaps [rsp+0x20], xmm15
00007981ddfdfbe5  lea rdi, [rsp]
00007981ddfdfbe9  mov esi, 0x00
00007981ddfdfbee  mov rax, 0x5782A6EB3530
00007981ddfdfbf8  call rax
00007981ddfdfbfa  movaps xmm8, [rsp]
00007981ddfdfbff  add rsp, 0x30
00007981ddfdfc03  vmovaps xmm0, [rsp]
00007981ddfdfc08  vmovaps xmm1, [rsp+0x10]
00007981ddfdfc0e  vmovaps xmm2, [rsp+0x20]
00007981ddfdfc14  vmovaps xmm3, [rsp+0x30]
00007981ddfdfc1a  vmovaps xmm4, [rsp+0x40]
00007981ddfdfc20  vmovaps xmm5, [rsp+0x50]
00007981ddfdfc26  vmovaps xmm6, [rsp+0x60]
00007981ddfdfc2c  vmovaps xmm7, [rsp+0x70]
00007981ddfdfc32  vmovaps xmm9, [rsp+0x80]
00007981ddfdfc3b  vmovaps xmm10, [rsp+0x90]
00007981ddfdfc44  vmovaps xmm11, [rsp+0xA0]
00007981ddfdfc4d  vmovaps xmm12, [rsp+0xB0]
00007981ddfdfc56  vmovaps xmm13, [rsp+0xC0]
00007981ddfdfc5f  vmovaps xmm14, [rsp+0xD0]
00007981ddfdfc68  vmovaps xmm15, [rsp+0xE0]
00007981ddfdfc71  add rsp, 0xF0
00007981ddfdfc78  pop r11
00007981ddfdfc7a  pop r10
00007981ddfdfc7c  pop r9
00007981ddfdfc7e  pop r8
00007981ddfdfc80  pop rsi
00007981ddfdfc81  pop rdi
00007981ddfdfc82  pop rdx
00007981ddfdfc83  pop rcx
00007981ddfdfc84  pop rax
00007981ddfdfc85  add rsp, 0x08
00007981ddfdfc89  jmp 0x00007981DDFDED27
00007981ddfdfc8e  sub rsp, 0x08
00007981ddfdfc92  push rax
00007981ddfdfc93  push rcx
00007981ddfdfc94  push rdx
00007981ddfdfc95  push rdi
00007981ddfdfc96  push rsi
00007981ddfdfc97  push r8
00007981ddfdfc99  push r9
00007981ddfdfc9b  push r10
00007981ddfdfc9d  push r11
00007981ddfdfc9f  sub rsp, 0xF0
00007981ddfdfca6  vmovaps [rsp], xmm0
00007981ddfdfcab  vmovaps [rsp+0x10], xmm1
00007981ddfdfcb1  vmovaps [rsp+0x20], xmm2
00007981ddfdfcb7  vmovaps [rsp+0x30], xmm3
00007981ddfdfcbd  vmovaps [rsp+0x40], xmm4
00007981ddfdfcc3  vmovaps [rsp+0x50], xmm5
00007981ddfdfcc9  vmovaps [rsp+0x60], xmm6
00007981ddfdfccf  vmovaps [rsp+0x70], xmm8
00007981ddfdfcd5  vmovaps [rsp+0x80], xmm9
00007981ddfdfcde  vmovaps [rsp+0x90], xmm10
00007981ddfdfce7  vmovaps [rsp+0xA0], xmm11
00007981ddfdfcf0  vmovaps [rsp+0xB0], xmm12
00007981ddfdfcf9  vmovaps [rsp+0xC0], xmm13
00007981ddfdfd02  vmovaps [rsp+0xD0], xmm14
00007981ddfdfd0b  vmovaps [rsp+0xE0], xmm15
00007981ddfdfd14  sub rsp, 0x30
00007981ddfdfd18  movaps [rsp], xmm7
00007981ddfdfd1c  movaps [rsp+0x10], xmm9
00007981ddfdfd22  movaps [rsp+0x20], xmm15
00007981ddfdfd28  lea rdi, [rsp]
00007981ddfdfd2c  mov esi, 0x00
00007981ddfdfd31  mov rax, 0x5782A6EB3530
00007981ddfdfd3b  call rax
00007981ddfdfd3d  movaps xmm7, [rsp]
00007981ddfdfd41  add rsp, 0x30
00007981ddfdfd45  vmovaps xmm0, [rsp]
00007981ddfdfd4a  vmovaps xmm1, [rsp+0x10]
00007981ddfdfd50  vmovaps xmm2, [rsp+0x20]
00007981ddfdfd56  vmovaps xmm3, [rsp+0x30]
00007981ddfdfd5c  vmovaps xmm4, [rsp+0x40]
00007981ddfdfd62  vmovaps xmm5, [rsp+0x50]
00007981ddfdfd68  vmovaps xmm6, [rsp+0x60]
00007981ddfdfd6e  vmovaps xmm8, [rsp+0x70]
00007981ddfdfd74  vmovaps xmm9, [rsp+0x80]
00007981ddfdfd7d  vmovaps xmm10, [rsp+0x90]
00007981ddfdfd86  vmovaps xmm11, [rsp+0xA0]
00007981ddfdfd8f  vmovaps xmm12, [rsp+0xB0]
00007981ddfdfd98  vmovaps xmm13, [rsp+0xC0]
00007981ddfdfda1  vmovaps xmm14, [rsp+0xD0]
00007981ddfdfdaa  vmovaps xmm15, [rsp+0xE0]
00007981ddfdfdb3  add rsp, 0xF0
00007981ddfdfdba  pop r11
00007981ddfdfdbc  pop r10
00007981ddfdfdbe  pop r9
00007981ddfdfdc0  pop r8
00007981ddfdfdc2  pop rsi
00007981ddfdfdc3  pop rdi
00007981ddfdfdc4  pop rdx
00007981ddfdfdc5  pop rcx
00007981ddfdfdc6  pop rax
00007981ddfdfdc7  add rsp, 0x08
00007981ddfdfdcb  jmp 0x00007981DDFDED55
00007981ddfdfdd0  sub rsp, 0x08
00007981ddfdfdd4  push rax
00007981ddfdfdd5  push rcx
00007981ddfdfdd6  push rdx
00007981ddfdfdd7  push rdi
00007981ddfdfdd8  push rsi
00007981ddfdfdd9  push r8
00007981ddfdfddb  push r9
00007981ddfdfddd  push r10
00007981ddfdfddf  push r11
00007981ddfdfde1  sub rsp, 0xF0
00007981ddfdfde8  vmovaps [rsp], xmm0
00007981ddfdfded  vmovaps [rsp+0x10], xmm1
00007981ddfdfdf3  vmovaps [rsp+0x20], xmm2
00007981ddfdfdf9  vmovaps [rsp+0x30], xmm3
00007981ddfdfdff  vmovaps [rsp+0x40], xmm4
00007981ddfdfe05  vmovaps [rsp+0x50], xmm5
00007981ddfdfe0b  vmovaps [rsp+0x60], xmm6
00007981ddfdfe11  vmovaps [rsp+0x70], xmm7
00007981ddfdfe17  vmovaps [rsp+0x80], xmm8
00007981ddfdfe20  vmovaps [rsp+0x90], xmm10
00007981ddfdfe29  vmovaps [rsp+0xA0], xmm11
00007981ddfdfe32  vmovaps [rsp+0xB0], xmm12
00007981ddfdfe3b  vmovaps [rsp+0xC0], xmm13
00007981ddfdfe44  vmovaps [rsp+0xD0], xmm14
00007981ddfdfe4d  vmovaps [rsp+0xE0], xmm15
00007981ddfdfe56  sub rsp, 0x30
00007981ddfdfe5a  movaps [rsp], xmm9
00007981ddfdfe5f  movaps [rsp+0x10], xmm12
00007981ddfdfe65  movaps [rsp+0x20], xmm10
00007981ddfdfe6b  lea rdi, [rsp]
00007981ddfdfe6f  mov esi, 0x00
00007981ddfdfe74  mov rax, 0x5782A6EB3530
00007981ddfdfe7e  call rax
00007981ddfdfe80  movaps xmm9, [rsp]
00007981ddfdfe85  add rsp, 0x30
00007981ddfdfe89  vmovaps xmm0, [rsp]
00007981ddfdfe8e  vmovaps xmm1, [rsp+0x10]
00007981ddfdfe94  vmovaps xmm2, [rsp+0x20]
00007981ddfdfe9a  vmovaps xmm3, [rsp+0x30]
00007981ddfdfea0  vmovaps xmm4, [rsp+0x40]
00007981ddfdfea6  vmovaps xmm5, [rsp+0x50]
00007981ddfdfeac  vmovaps xmm6, [rsp+0x60]
00007981ddfdfeb2  vmovaps xmm7, [rsp+0x70]
00007981ddfdfeb8  vmovaps xmm8, [rsp+0x80]
00007981ddfdfec1  vmovaps xmm10, [rsp+0x90]
00007981ddfdfeca  vmovaps xmm11, [rsp+0xA0]
00007981ddfdfed3  vmovaps xmm12, [rsp+0xB0]
00007981ddfdfedc  vmovaps xmm13, [rsp+0xC0]
00007981ddfdfee5  vmovaps xmm14, [rsp+0xD0]
00007981ddfdfeee  vmovaps xmm15, [rsp+0xE0]
00007981ddfdfef7  add rsp, 0xF0
00007981ddfdfefe  pop r11
00007981ddfdff00  pop r10
00007981ddfdff02  pop r9
00007981ddfdff04  pop r8
00007981ddfdff06  pop rsi
00007981ddfdff07  pop rdi
00007981ddfdff08  pop rdx
00007981ddfdff09  pop rcx
00007981ddfdff0a  pop rax
00007981ddfdff0b  add rsp, 0x08
00007981ddfdff0f  jmp 0x00007981DDFDED79
00007981ddfdff14  sub rsp, 0x08
00007981ddfdff18  push rax
00007981ddfdff19  push rcx
00007981ddfdff1a  push rdx
00007981ddfdff1b  push rdi
00007981ddfdff1c  push rsi
00007981ddfdff1d  push r8
00007981ddfdff1f  push r9
00007981ddfdff21  push r10
00007981ddfdff23  push r11
00007981ddfdff25  sub rsp, 0xF0
00007981ddfdff2c  vmovaps [rsp], xmm0
00007981ddfdff31  vmovaps [rsp+0x10], xmm1
00007981ddfdff37  vmovaps [rsp+0x20], xmm2
00007981ddfdff3d  vmovaps [rsp+0x30], xmm3
00007981ddfdff43  vmovaps [rsp+0x40], xmm4
00007981ddfdff49  vmovaps [rsp+0x50], xmm5
00007981ddfdff4f  vmovaps [rsp+0x60], xmm6
00007981ddfdff55  vmovaps [rsp+0x70], xmm7
00007981ddfdff5b  vmovaps [rsp+0x80], xmm8
00007981ddfdff64  vmovaps [rsp+0x90], xmm9
00007981ddfdff6d  vmovaps [rsp+0xA0], xmm11
00007981ddfdff76  vmovaps [rsp+0xB0], xmm12
00007981ddfdff7f  vmovaps [rsp+0xC0], xmm13
00007981ddfdff88  vmovaps [rsp+0xD0], xmm14
00007981ddfdff91  vmovaps [rsp+0xE0], xmm15
00007981ddfdff9a  sub rsp, 0x30
00007981ddfdff9e  movaps [rsp], xmm10
00007981ddfdffa3  movaps [rsp+0x10], xmm12
00007981ddfdffa9  movaps [rsp+0x20], xmm11
00007981ddfdffaf  lea rdi, [rsp]
00007981ddfdffb3  mov esi, 0x00
00007981ddfdffb8  mov rax, 0x5782A6EB3530
00007981ddfdffc2  call rax
00007981ddfdffc4  movaps xmm10, [rsp]
00007981ddfdffc9  add rsp, 0x30
00007981ddfdffcd  vmovaps xmm0, [rsp]
00007981ddfdffd2  vmovaps xmm1, [rsp+0x10]
00007981ddfdffd8  vmovaps xmm2, [rsp+0x20]
00007981ddfdffde  vmovaps xmm3, [rsp+0x30]
00007981ddfdffe4  vmovaps xmm4, [rsp+0x40]
00007981ddfdffea  vmovaps xmm5, [rsp+0x50]
00007981ddfdfff0  vmovaps xmm6, [rsp+0x60]
00007981ddfdfff6  vmovaps xmm7, [rsp+0x70]
00007981ddfdfffc  vmovaps xmm8, [rsp+0x80]
00007981ddfe0005  vmovaps xmm9, [rsp+0x90]
00007981ddfe000e  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0017  vmovaps xmm12, [rsp+0xB0]
00007981ddfe0020  vmovaps xmm13, [rsp+0xC0]
00007981ddfe0029  vmovaps xmm14, [rsp+0xD0]
00007981ddfe0032  vmovaps xmm15, [rsp+0xE0]
00007981ddfe003b  add rsp, 0xF0
00007981ddfe0042  pop r11
00007981ddfe0044  pop r10
00007981ddfe0046  pop r9
00007981ddfe0048  pop r8
00007981ddfe004a  pop rsi
00007981ddfe004b  pop rdi
00007981ddfe004c  pop rdx
00007981ddfe004d  pop rcx
00007981ddfe004e  pop rax
00007981ddfe004f  add rsp, 0x08
00007981ddfe0053  jmp 0x00007981DDFDED93
00007981ddfe0058  sub rsp, 0x08
00007981ddfe005c  push rax
00007981ddfe005d  push rcx
00007981ddfe005e  push rdx
00007981ddfe005f  push rdi
00007981ddfe0060  push rsi
00007981ddfe0061  push r8
00007981ddfe0063  push r9
00007981ddfe0065  push r10
00007981ddfe0067  push r11
00007981ddfe0069  sub rsp, 0xF0
00007981ddfe0070  vmovaps [rsp], xmm0
00007981ddfe0075  vmovaps [rsp+0x10], xmm1
00007981ddfe007b  vmovaps [rsp+0x20], xmm2
00007981ddfe0081  vmovaps [rsp+0x30], xmm3
00007981ddfe0087  vmovaps [rsp+0x40], xmm4
00007981ddfe008d  vmovaps [rsp+0x50], xmm5
00007981ddfe0093  vmovaps [rsp+0x60], xmm7
00007981ddfe0099  vmovaps [rsp+0x70], xmm8
00007981ddfe009f  vmovaps [rsp+0x80], xmm9
00007981ddfe00a8  vmovaps [rsp+0x90], xmm10
00007981ddfe00b1  vmovaps [rsp+0xA0], xmm11
00007981ddfe00ba  vmovaps [rsp+0xB0], xmm12
00007981ddfe00c3  vmovaps [rsp+0xC0], xmm13
00007981ddfe00cc  vmovaps [rsp+0xD0], xmm14
00007981ddfe00d5  vmovaps [rsp+0xE0], xmm15
00007981ddfe00de  sub rsp, 0x30
00007981ddfe00e2  movaps [rsp], xmm6
00007981ddfe00e6  movaps [rsp+0x10], xmm12
00007981ddfe00ec  movaps [rsp+0x20], xmm11
00007981ddfe00f2  lea rdi, [rsp]
00007981ddfe00f6  mov esi, 0x00
00007981ddfe00fb  mov rax, 0x5782A6EB3530
00007981ddfe0105  call rax
00007981ddfe0107  movaps xmm6, [rsp]
00007981ddfe010b  add rsp, 0x30
00007981ddfe010f  vmovaps xmm0, [rsp]
00007981ddfe0114  vmovaps xmm1, [rsp+0x10]
00007981ddfe011a  vmovaps xmm2, [rsp+0x20]
00007981ddfe0120  vmovaps xmm3, [rsp+0x30]
00007981ddfe0126  vmovaps xmm4, [rsp+0x40]
00007981ddfe012c  vmovaps xmm5, [rsp+0x50]
00007981ddfe0132  vmovaps xmm7, [rsp+0x60]
00007981ddfe0138  vmovaps xmm8, [rsp+0x70]
00007981ddfe013e  vmovaps xmm9, [rsp+0x80]
00007981ddfe0147  vmovaps xmm10, [rsp+0x90]
00007981ddfe0150  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0159  vmovaps xmm12, [rsp+0xB0]
00007981ddfe0162  vmovaps xmm13, [rsp+0xC0]
00007981ddfe016b  vmovaps xmm14, [rsp+0xD0]
00007981ddfe0174  vmovaps xmm15, [rsp+0xE0]
00007981ddfe017d  add rsp, 0xF0
00007981ddfe0184  pop r11
00007981ddfe0186  pop r10
00007981ddfe0188  pop r9
00007981ddfe018a  pop r8
00007981ddfe018c  pop rsi
00007981ddfe018d  pop rdi
00007981ddfe018e  pop rdx
00007981ddfe018f  pop rcx
00007981ddfe0190  pop rax
00007981ddfe0191  add rsp, 0x08
00007981ddfe0195  jmp 0x00007981DDFDEDB4
00007981ddfe019a  sub rsp, 0x08
00007981ddfe019e  push rax
00007981ddfe019f  push rcx
00007981ddfe01a0  push rdx
00007981ddfe01a1  push rdi
00007981ddfe01a2  push rsi
00007981ddfe01a3  push r8
00007981ddfe01a5  push r9
00007981ddfe01a7  push r10
00007981ddfe01a9  push r11
00007981ddfe01ab  sub rsp, 0xF0
00007981ddfe01b2  vmovaps [rsp], xmm0
00007981ddfe01b7  vmovaps [rsp+0x10], xmm1
00007981ddfe01bd  vmovaps [rsp+0x20], xmm2
00007981ddfe01c3  vmovaps [rsp+0x30], xmm4
00007981ddfe01c9  vmovaps [rsp+0x40], xmm5
00007981ddfe01cf  vmovaps [rsp+0x50], xmm6
00007981ddfe01d5  vmovaps [rsp+0x60], xmm7
00007981ddfe01db  vmovaps [rsp+0x70], xmm8
00007981ddfe01e1  vmovaps [rsp+0x80], xmm9
00007981ddfe01ea  vmovaps [rsp+0x90], xmm10
00007981ddfe01f3  vmovaps [rsp+0xA0], xmm11
00007981ddfe01fc  vmovaps [rsp+0xB0], xmm12
00007981ddfe0205  vmovaps [rsp+0xC0], xmm13
00007981ddfe020e  vmovaps [rsp+0xD0], xmm14
00007981ddfe0217  vmovaps [rsp+0xE0], xmm15
00007981ddfe0220  sub rsp, 0x30
00007981ddfe0224  movaps [rsp], xmm3
00007981ddfe0228  movaps [rsp+0x10], xmm5
00007981ddfe022d  movaps [rsp+0x20], xmm4
00007981ddfe0232  lea rdi, [rsp]
00007981ddfe0236  mov esi, 0x00
00007981ddfe023b  mov rax, 0x5782A6EB3530
00007981ddfe0245  call rax
00007981ddfe0247  movaps xmm3, [rsp]
00007981ddfe024b  add rsp, 0x30
00007981ddfe024f  vmovaps xmm0, [rsp]
00007981ddfe0254  vmovaps xmm1, [rsp+0x10]
00007981ddfe025a  vmovaps xmm2, [rsp+0x20]
00007981ddfe0260  vmovaps xmm4, [rsp+0x30]
00007981ddfe0266  vmovaps xmm5, [rsp+0x40]
00007981ddfe026c  vmovaps xmm6, [rsp+0x50]
00007981ddfe0272  vmovaps xmm7, [rsp+0x60]
00007981ddfe0278  vmovaps xmm8, [rsp+0x70]
00007981ddfe027e  vmovaps xmm9, [rsp+0x80]
00007981ddfe0287  vmovaps xmm10, [rsp+0x90]
00007981ddfe0290  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0299  vmovaps xmm12, [rsp+0xB0]
00007981ddfe02a2  vmovaps xmm13, [rsp+0xC0]
00007981ddfe02ab  vmovaps xmm14, [rsp+0xD0]
00007981ddfe02b4  vmovaps xmm15, [rsp+0xE0]
00007981ddfe02bd  add rsp, 0xF0
00007981ddfe02c4  pop r11
00007981ddfe02c6  pop r10
00007981ddfe02c8  pop r9
00007981ddfe02ca  pop r8
00007981ddfe02cc  pop rsi
00007981ddfe02cd  pop rdi
00007981ddfe02ce  pop rdx
00007981ddfe02cf  pop rcx
00007981ddfe02d0  pop rax
00007981ddfe02d1  add rsp, 0x08
00007981ddfe02d5  jmp 0x00007981DDFDEE15
00007981ddfe02da  sub rsp, 0x08
00007981ddfe02de  push rax
00007981ddfe02df  push rcx
00007981ddfe02e0  push rdx
00007981ddfe02e1  push rdi
00007981ddfe02e2  push rsi
00007981ddfe02e3  push r8
00007981ddfe02e5  push r9
00007981ddfe02e7  push r10
00007981ddfe02e9  push r11
00007981ddfe02eb  sub rsp, 0xF0
00007981ddfe02f2  vmovaps [rsp], xmm0
00007981ddfe02f7  vmovaps [rsp+0x10], xmm1
00007981ddfe02fd  vmovaps [rsp+0x20], xmm2
00007981ddfe0303  vmovaps [rsp+0x30], xmm3
00007981ddfe0309  vmovaps [rsp+0x40], xmm4
00007981ddfe030f  vmovaps [rsp+0x50], xmm6
00007981ddfe0315  vmovaps [rsp+0x60], xmm7
00007981ddfe031b  vmovaps [rsp+0x70], xmm8
00007981ddfe0321  vmovaps [rsp+0x80], xmm9
00007981ddfe032a  vmovaps [rsp+0x90], xmm10
00007981ddfe0333  vmovaps [rsp+0xA0], xmm11
00007981ddfe033c  vmovaps [rsp+0xB0], xmm12
00007981ddfe0345  vmovaps [rsp+0xC0], xmm13
00007981ddfe034e  vmovaps [rsp+0xD0], xmm14
00007981ddfe0357  vmovaps [rsp+0xE0], xmm15
00007981ddfe0360  sub rsp, 0x30
00007981ddfe0364  movaps [rsp], xmm5
00007981ddfe0368  movaps [rsp+0x10], xmm8
00007981ddfe036e  movaps [rsp+0x20], xmm15
00007981ddfe0374  lea rdi, [rsp]
00007981ddfe0378  mov esi, 0x00
00007981ddfe037d  mov rax, 0x5782A6EB3530
00007981ddfe0387  call rax
00007981ddfe0389  movaps xmm5, [rsp]
00007981ddfe038d  add rsp, 0x30
00007981ddfe0391  vmovaps xmm0, [rsp]
00007981ddfe0396  vmovaps xmm1, [rsp+0x10]
00007981ddfe039c  vmovaps xmm2, [rsp+0x20]
00007981ddfe03a2  vmovaps xmm3, [rsp+0x30]
00007981ddfe03a8  vmovaps xmm4, [rsp+0x40]
00007981ddfe03ae  vmovaps xmm6, [rsp+0x50]
00007981ddfe03b4  vmovaps xmm7, [rsp+0x60]
00007981ddfe03ba  vmovaps xmm8, [rsp+0x70]
00007981ddfe03c0  vmovaps xmm9, [rsp+0x80]
00007981ddfe03c9  vmovaps xmm10, [rsp+0x90]
00007981ddfe03d2  vmovaps xmm11, [rsp+0xA0]
00007981ddfe03db  vmovaps xmm12, [rsp+0xB0]
00007981ddfe03e4  vmovaps xmm13, [rsp+0xC0]
00007981ddfe03ed  vmovaps xmm14, [rsp+0xD0]
00007981ddfe03f6  vmovaps xmm15, [rsp+0xE0]
00007981ddfe03ff  add rsp, 0xF0
00007981ddfe0406  pop r11
00007981ddfe0408  pop r10
00007981ddfe040a  pop r9
00007981ddfe040c  pop r8
00007981ddfe040e  pop rsi
00007981ddfe040f  pop rdi
00007981ddfe0410  pop rdx
00007981ddfe0411  pop rcx
00007981ddfe0412  pop rax
00007981ddfe0413  add rsp, 0x08
00007981ddfe0417  jmp 0x00007981DDFDEE53
00007981ddfe041c  sub rsp, 0x08
00007981ddfe0420  push rax
00007981ddfe0421  push rcx
00007981ddfe0422  push rdx
00007981ddfe0423  push rdi
00007981ddfe0424  push rsi
00007981ddfe0425  push r8
00007981ddfe0427  push r9
00007981ddfe0429  push r10
00007981ddfe042b  push r11
00007981ddfe042d  sub rsp, 0xF0
00007981ddfe0434  vmovaps [rsp], xmm0
00007981ddfe0439  vmovaps [rsp+0x10], xmm1
00007981ddfe043f  vmovaps [rsp+0x20], xmm2
00007981ddfe0445  vmovaps [rsp+0x30], xmm3
00007981ddfe044b  vmovaps [rsp+0x40], xmm5
00007981ddfe0451  vmovaps [rsp+0x50], xmm6
00007981ddfe0457  vmovaps [rsp+0x60], xmm7
00007981ddfe045d  vmovaps [rsp+0x70], xmm8
00007981ddfe0463  vmovaps [rsp+0x80], xmm9
00007981ddfe046c  vmovaps [rsp+0x90], xmm10
00007981ddfe0475  vmovaps [rsp+0xA0], xmm11
00007981ddfe047e  vmovaps [rsp+0xB0], xmm12
00007981ddfe0487  vmovaps [rsp+0xC0], xmm13
00007981ddfe0490  vmovaps [rsp+0xD0], xmm14
00007981ddfe0499  vmovaps [rsp+0xE0], xmm15
00007981ddfe04a2  sub rsp, 0x30
00007981ddfe04a6  movaps [rsp], xmm4
00007981ddfe04aa  movaps [rsp+0x10], xmm9
00007981ddfe04b0  movaps [rsp+0x20], xmm8
00007981ddfe04b6  lea rdi, [rsp]
00007981ddfe04ba  mov esi, 0x00
00007981ddfe04bf  mov rax, 0x5782A6EB3530
00007981ddfe04c9  call rax
00007981ddfe04cb  movaps xmm4, [rsp]
00007981ddfe04cf  add rsp, 0x30
00007981ddfe04d3  vmovaps xmm0, [rsp]
00007981ddfe04d8  vmovaps xmm1, [rsp+0x10]
00007981ddfe04de  vmovaps xmm2, [rsp+0x20]
00007981ddfe04e4  vmovaps xmm3, [rsp+0x30]
00007981ddfe04ea  vmovaps xmm5, [rsp+0x40]
00007981ddfe04f0  vmovaps xmm6, [rsp+0x50]
00007981ddfe04f6  vmovaps xmm7, [rsp+0x60]
00007981ddfe04fc  vmovaps xmm8, [rsp+0x70]
00007981ddfe0502  vmovaps xmm9, [rsp+0x80]
00007981ddfe050b  vmovaps xmm10, [rsp+0x90]
00007981ddfe0514  vmovaps xmm11, [rsp+0xA0]
00007981ddfe051d  vmovaps xmm12, [rsp+0xB0]
00007981ddfe0526  vmovaps xmm13, [rsp+0xC0]
00007981ddfe052f  vmovaps xmm14, [rsp+0xD0]
00007981ddfe0538  vmovaps xmm15, [rsp+0xE0]
00007981ddfe0541  add rsp, 0xF0
00007981ddfe0548  pop r11
00007981ddfe054a  pop r10
00007981ddfe054c  pop r9
00007981ddfe054e  pop r8
00007981ddfe0550  pop rsi
00007981ddfe0551  pop rdi
00007981ddfe0552  pop rdx
00007981ddfe0553  pop rcx
00007981ddfe0554  pop rax
00007981ddfe0555  add rsp, 0x08
00007981ddfe0559  jmp 0x00007981DDFDEE74
00007981ddfe055e  sub rsp, 0x08
00007981ddfe0562  push rax
00007981ddfe0563  push rcx
00007981ddfe0564  push rdx
00007981ddfe0565  push rdi
00007981ddfe0566  push rsi
00007981ddfe0567  push r8
00007981ddfe0569  push r9
00007981ddfe056b  push r10
00007981ddfe056d  push r11
00007981ddfe056f  sub rsp, 0xF0
00007981ddfe0576  vmovaps [rsp], xmm0
00007981ddfe057b  vmovaps [rsp+0x10], xmm1
00007981ddfe0581  vmovaps [rsp+0x20], xmm2
00007981ddfe0587  vmovaps [rsp+0x30], xmm3
00007981ddfe058d  vmovaps [rsp+0x40], xmm4
00007981ddfe0593  vmovaps [rsp+0x50], xmm5
00007981ddfe0599  vmovaps [rsp+0x60], xmm6
00007981ddfe059f  vmovaps [rsp+0x70], xmm7
00007981ddfe05a5  vmovaps [rsp+0x80], xmm8
00007981ddfe05ae  vmovaps [rsp+0x90], xmm10
00007981ddfe05b7  vmovaps [rsp+0xA0], xmm11
00007981ddfe05c0  vmovaps [rsp+0xB0], xmm12
00007981ddfe05c9  vmovaps [rsp+0xC0], xmm13
00007981ddfe05d2  vmovaps [rsp+0xD0], xmm14
00007981ddfe05db  vmovaps [rsp+0xE0], xmm15
00007981ddfe05e4  sub rsp, 0x30
00007981ddfe05e8  movaps [rsp], xmm9
00007981ddfe05ed  movaps [rsp+0x10], xmm10
00007981ddfe05f3  movaps [rsp+0x20], xmm8
00007981ddfe05f9  lea rdi, [rsp]
00007981ddfe05fd  mov esi, 0x00
00007981ddfe0602  mov rax, 0x5782A6EB3530
00007981ddfe060c  call rax
00007981ddfe060e  movaps xmm9, [rsp]
00007981ddfe0613  add rsp, 0x30
00007981ddfe0617  vmovaps xmm0, [rsp]
00007981ddfe061c  vmovaps xmm1, [rsp+0x10]
00007981ddfe0622  vmovaps xmm2, [rsp+0x20]
00007981ddfe0628  vmovaps xmm3, [rsp+0x30]
00007981ddfe062e  vmovaps xmm4, [rsp+0x40]
00007981ddfe0634  vmovaps xmm5, [rsp+0x50]
00007981ddfe063a  vmovaps xmm6, [rsp+0x60]
00007981ddfe0640  vmovaps xmm7, [rsp+0x70]
00007981ddfe0646  vmovaps xmm8, [rsp+0x80]
00007981ddfe064f  vmovaps xmm10, [rsp+0x90]
00007981ddfe0658  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0661  vmovaps xmm12, [rsp+0xB0]
00007981ddfe066a  vmovaps xmm13, [rsp+0xC0]
00007981ddfe0673  vmovaps xmm14, [rsp+0xD0]
00007981ddfe067c  vmovaps xmm15, [rsp+0xE0]
00007981ddfe0685  add rsp, 0xF0
00007981ddfe068c  pop r11
00007981ddfe068e  pop r10
00007981ddfe0690  pop r9
00007981ddfe0692  pop r8
00007981ddfe0694  pop rsi
00007981ddfe0695  pop rdi
00007981ddfe0696  pop rdx
00007981ddfe0697  pop rcx
00007981ddfe0698  pop rax
00007981ddfe0699  add rsp, 0x08
00007981ddfe069d  jmp 0x00007981DDFDEE8E
00007981ddfe06a2  call 0x00007981DDEB52F0
00007981ddfe06a7  jmp 0x00007981DDFDEFA8
00007981ddfe06ac  call 0x00007981DDEB52F0
00007981ddfe06b1  jmp 0x00007981DDFDEFBE
00007981ddfe06b6  sub rsp, 0x08
00007981ddfe06ba  push rax
00007981ddfe06bb  push rcx
00007981ddfe06bc  push rdx
00007981ddfe06bd  push rdi
00007981ddfe06be  push rsi
00007981ddfe06bf  push r8
00007981ddfe06c1  push r9
00007981ddfe06c3  push r10
00007981ddfe06c5  push r11
00007981ddfe06c7  sub rsp, 0xF0
00007981ddfe06ce  vmovaps [rsp], xmm0
00007981ddfe06d3  vmovaps [rsp+0x10], xmm2
00007981ddfe06d9  vmovaps [rsp+0x20], xmm3
00007981ddfe06df  vmovaps [rsp+0x30], xmm4
00007981ddfe06e5  vmovaps [rsp+0x40], xmm5
00007981ddfe06eb  vmovaps [rsp+0x50], xmm6
00007981ddfe06f1  vmovaps [rsp+0x60], xmm7
00007981ddfe06f7  vmovaps [rsp+0x70], xmm8
00007981ddfe06fd  vmovaps [rsp+0x80], xmm9
00007981ddfe0706  vmovaps [rsp+0x90], xmm10
00007981ddfe070f  vmovaps [rsp+0xA0], xmm11
00007981ddfe0718  vmovaps [rsp+0xB0], xmm12
00007981ddfe0721  vmovaps [rsp+0xC0], xmm13
00007981ddfe072a  vmovaps [rsp+0xD0], xmm14
00007981ddfe0733  vmovaps [rsp+0xE0], xmm15
00007981ddfe073c  sub rsp, 0x30
00007981ddfe0740  movaps [rsp], xmm1
00007981ddfe0744  movaps [rsp+0x10], xmm6
00007981ddfe0749  movaps [rsp+0x20], xmm15
00007981ddfe074f  lea rdi, [rsp]
00007981ddfe0753  mov esi, 0x00
00007981ddfe0758  mov rax, 0x5782A6EB3530
00007981ddfe0762  call rax
00007981ddfe0764  movaps xmm1, [rsp]
00007981ddfe0768  add rsp, 0x30
00007981ddfe076c  vmovaps xmm0, [rsp]
00007981ddfe0771  vmovaps xmm2, [rsp+0x10]
00007981ddfe0777  vmovaps xmm3, [rsp+0x20]
00007981ddfe077d  vmovaps xmm4, [rsp+0x30]
00007981ddfe0783  vmovaps xmm5, [rsp+0x40]
00007981ddfe0789  vmovaps xmm6, [rsp+0x50]
00007981ddfe078f  vmovaps xmm7, [rsp+0x60]
00007981ddfe0795  vmovaps xmm8, [rsp+0x70]
00007981ddfe079b  vmovaps xmm9, [rsp+0x80]
00007981ddfe07a4  vmovaps xmm10, [rsp+0x90]
00007981ddfe07ad  vmovaps xmm11, [rsp+0xA0]
00007981ddfe07b6  vmovaps xmm12, [rsp+0xB0]
00007981ddfe07bf  vmovaps xmm13, [rsp+0xC0]
00007981ddfe07c8  vmovaps xmm14, [rsp+0xD0]
00007981ddfe07d1  vmovaps xmm15, [rsp+0xE0]
00007981ddfe07da  add rsp, 0xF0
00007981ddfe07e1  pop r11
00007981ddfe07e3  pop r10
00007981ddfe07e5  pop r9
00007981ddfe07e7  pop r8
00007981ddfe07e9  pop rsi
00007981ddfe07ea  pop rdi
00007981ddfe07eb  pop rdx
00007981ddfe07ec  pop rcx
00007981ddfe07ed  pop rax
00007981ddfe07ee  add rsp, 0x08
00007981ddfe07f2  jmp 0x00007981DDFDEFFB
00007981ddfe07f7  call 0x00007981DDEC4620
00007981ddfe07fc  jmp 0x00007981DDFDF008
00007981ddfe0801  sub rsp, 0x08
00007981ddfe0805  push rax
00007981ddfe0806  push rcx
00007981ddfe0807  push rdx
00007981ddfe0808  push rdi
00007981ddfe0809  push rsi
00007981ddfe080a  push r8
00007981ddfe080c  push r9
00007981ddfe080e  push r10
00007981ddfe0810  push r11
00007981ddfe0812  sub rsp, 0xF0
00007981ddfe0819  vmovaps [rsp], xmm0
00007981ddfe081e  vmovaps [rsp+0x10], xmm1
00007981ddfe0824  vmovaps [rsp+0x20], xmm2
00007981ddfe082a  vmovaps [rsp+0x30], xmm3
00007981ddfe0830  vmovaps [rsp+0x40], xmm4
00007981ddfe0836  vmovaps [rsp+0x50], xmm5
00007981ddfe083c  vmovaps [rsp+0x60], xmm6
00007981ddfe0842  vmovaps [rsp+0x70], xmm7
00007981ddfe0848  vmovaps [rsp+0x80], xmm8
00007981ddfe0851  vmovaps [rsp+0x90], xmm9
00007981ddfe085a  vmovaps [rsp+0xA0], xmm10
00007981ddfe0863  vmovaps [rsp+0xB0], xmm11
00007981ddfe086c  vmovaps [rsp+0xC0], xmm12
00007981ddfe0875  vmovaps [rsp+0xD0], xmm13
00007981ddfe087e  vmovaps [rsp+0xE0], xmm15
00007981ddfe0887  sub rsp, 0x30
00007981ddfe088b  movaps [rsp], xmm14
00007981ddfe0890  movaps [rsp+0x10], xmm4
00007981ddfe0895  movaps [rsp+0x20], xmm3
00007981ddfe089a  lea rdi, [rsp]
00007981ddfe089e  mov esi, 0x00
00007981ddfe08a3  mov rax, 0x5782A6EB3530
00007981ddfe08ad  call rax
00007981ddfe08af  movaps xmm14, [rsp]
00007981ddfe08b4  add rsp, 0x30
00007981ddfe08b8  vmovaps xmm0, [rsp]
00007981ddfe08bd  vmovaps xmm1, [rsp+0x10]
00007981ddfe08c3  vmovaps xmm2, [rsp+0x20]
00007981ddfe08c9  vmovaps xmm3, [rsp+0x30]
00007981ddfe08cf  vmovaps xmm4, [rsp+0x40]
00007981ddfe08d5  vmovaps xmm5, [rsp+0x50]
00007981ddfe08db  vmovaps xmm6, [rsp+0x60]
00007981ddfe08e1  vmovaps xmm7, [rsp+0x70]
00007981ddfe08e7  vmovaps xmm8, [rsp+0x80]
00007981ddfe08f0  vmovaps xmm9, [rsp+0x90]
00007981ddfe08f9  vmovaps xmm10, [rsp+0xA0]
00007981ddfe0902  vmovaps xmm11, [rsp+0xB0]
00007981ddfe090b  vmovaps xmm12, [rsp+0xC0]
00007981ddfe0914  vmovaps xmm13, [rsp+0xD0]
00007981ddfe091d  vmovaps xmm15, [rsp+0xE0]
00007981ddfe0926  add rsp, 0xF0
00007981ddfe092d  pop r11
00007981ddfe092f  pop r10
00007981ddfe0931  pop r9
00007981ddfe0933  pop r8
00007981ddfe0935  pop rsi
00007981ddfe0936  pop rdi
00007981ddfe0937  pop rdx
00007981ddfe0938  pop rcx
00007981ddfe0939  pop rax
00007981ddfe093a  add rsp, 0x08
00007981ddfe093e  jmp 0x00007981DDFDF022
00007981ddfe0943  sub rsp, 0x08
00007981ddfe0947  push rax
00007981ddfe0948  push rcx
00007981ddfe0949  push rdx
00007981ddfe094a  push rdi
00007981ddfe094b  push rsi
00007981ddfe094c  push r8
00007981ddfe094e  push r9
00007981ddfe0950  push r10
00007981ddfe0952  push r11
00007981ddfe0954  sub rsp, 0xF0
00007981ddfe095b  vmovaps [rsp], xmm0
00007981ddfe0960  vmovaps [rsp+0x10], xmm1
00007981ddfe0966  vmovaps [rsp+0x20], xmm2
00007981ddfe096c  vmovaps [rsp+0x30], xmm3
00007981ddfe0972  vmovaps [rsp+0x40], xmm4
00007981ddfe0978  vmovaps [rsp+0x50], xmm5
00007981ddfe097e  vmovaps [rsp+0x60], xmm7
00007981ddfe0984  vmovaps [rsp+0x70], xmm8
00007981ddfe098a  vmovaps [rsp+0x80], xmm9
00007981ddfe0993  vmovaps [rsp+0x90], xmm10
00007981ddfe099c  vmovaps [rsp+0xA0], xmm11
00007981ddfe09a5  vmovaps [rsp+0xB0], xmm12
00007981ddfe09ae  vmovaps [rsp+0xC0], xmm13
00007981ddfe09b7  vmovaps [rsp+0xD0], xmm14
00007981ddfe09c0  vmovaps [rsp+0xE0], xmm15
00007981ddfe09c9  sub rsp, 0x30
00007981ddfe09cd  movaps [rsp], xmm6
00007981ddfe09d1  movaps [rsp+0x10], xmm9
00007981ddfe09d7  movaps [rsp+0x20], xmm7
00007981ddfe09dc  lea rdi, [rsp]
00007981ddfe09e0  mov esi, 0x00
00007981ddfe09e5  mov rax, 0x5782A6EB3530
00007981ddfe09ef  call rax
00007981ddfe09f1  movaps xmm6, [rsp]
00007981ddfe09f5  add rsp, 0x30
00007981ddfe09f9  vmovaps xmm0, [rsp]
00007981ddfe09fe  vmovaps xmm1, [rsp+0x10]
00007981ddfe0a04  vmovaps xmm2, [rsp+0x20]
00007981ddfe0a0a  vmovaps xmm3, [rsp+0x30]
00007981ddfe0a10  vmovaps xmm4, [rsp+0x40]
00007981ddfe0a16  vmovaps xmm5, [rsp+0x50]
00007981ddfe0a1c  vmovaps xmm7, [rsp+0x60]
00007981ddfe0a22  vmovaps xmm8, [rsp+0x70]
00007981ddfe0a28  vmovaps xmm9, [rsp+0x80]
00007981ddfe0a31  vmovaps xmm10, [rsp+0x90]
00007981ddfe0a3a  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0a43  vmovaps xmm12, [rsp+0xB0]
00007981ddfe0a4c  vmovaps xmm13, [rsp+0xC0]
00007981ddfe0a55  vmovaps xmm14, [rsp+0xD0]
00007981ddfe0a5e  vmovaps xmm15, [rsp+0xE0]
00007981ddfe0a67  add rsp, 0xF0
00007981ddfe0a6e  pop r11
00007981ddfe0a70  pop r10
00007981ddfe0a72  pop r9
00007981ddfe0a74  pop r8
00007981ddfe0a76  pop rsi
00007981ddfe0a77  pop rdi
00007981ddfe0a78  pop rdx
00007981ddfe0a79  pop rcx
00007981ddfe0a7a  pop rax
00007981ddfe0a7b  add rsp, 0x08
00007981ddfe0a7f  jmp 0x00007981DDFDF03A
00007981ddfe0a84  sub rsp, 0x08
00007981ddfe0a88  push rax
00007981ddfe0a89  push rcx
00007981ddfe0a8a  push rdx
00007981ddfe0a8b  push rdi
00007981ddfe0a8c  push rsi
00007981ddfe0a8d  push r8
00007981ddfe0a8f  push r9
00007981ddfe0a91  push r10
00007981ddfe0a93  push r11
00007981ddfe0a95  sub rsp, 0xF0
00007981ddfe0a9c  vmovaps [rsp], xmm0
00007981ddfe0aa1  vmovaps [rsp+0x10], xmm1
00007981ddfe0aa7  vmovaps [rsp+0x20], xmm2
00007981ddfe0aad  vmovaps [rsp+0x30], xmm3
00007981ddfe0ab3  vmovaps [rsp+0x40], xmm4
00007981ddfe0ab9  vmovaps [rsp+0x50], xmm5
00007981ddfe0abf  vmovaps [rsp+0x60], xmm6
00007981ddfe0ac5  vmovaps [rsp+0x70], xmm8
00007981ddfe0acb  vmovaps [rsp+0x80], xmm9
00007981ddfe0ad4  vmovaps [rsp+0x90], xmm10
00007981ddfe0add  vmovaps [rsp+0xA0], xmm11
00007981ddfe0ae6  vmovaps [rsp+0xB0], xmm12
00007981ddfe0aef  vmovaps [rsp+0xC0], xmm13
00007981ddfe0af8  vmovaps [rsp+0xD0], xmm14
00007981ddfe0b01  vmovaps [rsp+0xE0], xmm15
00007981ddfe0b0a  sub rsp, 0x30
00007981ddfe0b0e  movaps [rsp], xmm7
00007981ddfe0b12  movaps [rsp+0x10], xmm4
00007981ddfe0b17  movaps [rsp+0x20], xmm9
00007981ddfe0b1d  lea rdi, [rsp]
00007981ddfe0b21  mov esi, 0x00
00007981ddfe0b26  mov rax, 0x5782A6EB3530
00007981ddfe0b30  call rax
00007981ddfe0b32  movaps xmm7, [rsp]
00007981ddfe0b36  add rsp, 0x30
00007981ddfe0b3a  vmovaps xmm0, [rsp]
00007981ddfe0b3f  vmovaps xmm1, [rsp+0x10]
00007981ddfe0b45  vmovaps xmm2, [rsp+0x20]
00007981ddfe0b4b  vmovaps xmm3, [rsp+0x30]
00007981ddfe0b51  vmovaps xmm4, [rsp+0x40]
00007981ddfe0b57  vmovaps xmm5, [rsp+0x50]
00007981ddfe0b5d  vmovaps xmm6, [rsp+0x60]
00007981ddfe0b63  vmovaps xmm8, [rsp+0x70]
00007981ddfe0b69  vmovaps xmm9, [rsp+0x80]
00007981ddfe0b72  vmovaps xmm10, [rsp+0x90]
00007981ddfe0b7b  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0b84  vmovaps xmm12, [rsp+0xB0]
00007981ddfe0b8d  vmovaps xmm13, [rsp+0xC0]
00007981ddfe0b96  vmovaps xmm14, [rsp+0xD0]
00007981ddfe0b9f  vmovaps xmm15, [rsp+0xE0]
00007981ddfe0ba8  add rsp, 0xF0
00007981ddfe0baf  pop r11
00007981ddfe0bb1  pop r10
00007981ddfe0bb3  pop r9
00007981ddfe0bb5  pop r8
00007981ddfe0bb7  pop rsi
00007981ddfe0bb8  pop rdi
00007981ddfe0bb9  pop rdx
00007981ddfe0bba  pop rcx
00007981ddfe0bbb  pop rax
00007981ddfe0bbc  add rsp, 0x08
00007981ddfe0bc0  jmp 0x00007981DDFDF067
00007981ddfe0bc5  sub rsp, 0x08
00007981ddfe0bc9  push rax
00007981ddfe0bca  push rcx
00007981ddfe0bcb  push rdx
00007981ddfe0bcc  push rdi
00007981ddfe0bcd  push rsi
00007981ddfe0bce  push r8
00007981ddfe0bd0  push r9
00007981ddfe0bd2  push r10
00007981ddfe0bd4  push r11
00007981ddfe0bd6  sub rsp, 0xF0
00007981ddfe0bdd  vmovaps [rsp], xmm0
00007981ddfe0be2  vmovaps [rsp+0x10], xmm1
00007981ddfe0be8  vmovaps [rsp+0x20], xmm2
00007981ddfe0bee  vmovaps [rsp+0x30], xmm3
00007981ddfe0bf4  vmovaps [rsp+0x40], xmm5
00007981ddfe0bfa  vmovaps [rsp+0x50], xmm6
00007981ddfe0c00  vmovaps [rsp+0x60], xmm7
00007981ddfe0c06  vmovaps [rsp+0x70], xmm8
00007981ddfe0c0c  vmovaps [rsp+0x80], xmm9
00007981ddfe0c15  vmovaps [rsp+0x90], xmm10
00007981ddfe0c1e  vmovaps [rsp+0xA0], xmm11
00007981ddfe0c27  vmovaps [rsp+0xB0], xmm12
00007981ddfe0c30  vmovaps [rsp+0xC0], xmm13
00007981ddfe0c39  vmovaps [rsp+0xD0], xmm14
00007981ddfe0c42  vmovaps [rsp+0xE0], xmm15
00007981ddfe0c4b  sub rsp, 0x30
00007981ddfe0c4f  movaps [rsp], xmm4
00007981ddfe0c53  movaps [rsp+0x10], xmm15
00007981ddfe0c59  movaps [rsp+0x20], xmm9
00007981ddfe0c5f  lea rdi, [rsp]
00007981ddfe0c63  mov esi, 0x00
00007981ddfe0c68  mov rax, 0x5782A6EB3530
00007981ddfe0c72  call rax
00007981ddfe0c74  movaps xmm4, [rsp]
00007981ddfe0c78  add rsp, 0x30
00007981ddfe0c7c  vmovaps xmm0, [rsp]
00007981ddfe0c81  vmovaps xmm1, [rsp+0x10]
00007981ddfe0c87  vmovaps xmm2, [rsp+0x20]
00007981ddfe0c8d  vmovaps xmm3, [rsp+0x30]
00007981ddfe0c93  vmovaps xmm5, [rsp+0x40]
00007981ddfe0c99  vmovaps xmm6, [rsp+0x50]
00007981ddfe0c9f  vmovaps xmm7, [rsp+0x60]
00007981ddfe0ca5  vmovaps xmm8, [rsp+0x70]
00007981ddfe0cab  vmovaps xmm9, [rsp+0x80]
00007981ddfe0cb4  vmovaps xmm10, [rsp+0x90]
00007981ddfe0cbd  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0cc6  vmovaps xmm12, [rsp+0xB0]
00007981ddfe0ccf  vmovaps xmm13, [rsp+0xC0]
00007981ddfe0cd8  vmovaps xmm14, [rsp+0xD0]
00007981ddfe0ce1  vmovaps xmm15, [rsp+0xE0]
00007981ddfe0cea  add rsp, 0xF0
00007981ddfe0cf1  pop r11
00007981ddfe0cf3  pop r10
00007981ddfe0cf5  pop r9
00007981ddfe0cf7  pop r8
00007981ddfe0cf9  pop rsi
00007981ddfe0cfa  pop rdi
00007981ddfe0cfb  pop rdx
00007981ddfe0cfc  pop rcx
00007981ddfe0cfd  pop rax
00007981ddfe0cfe  add rsp, 0x08
00007981ddfe0d02  jmp 0x00007981DDFDF08C
00007981ddfe0d07  call 0x00007981DDEC4620
00007981ddfe0d0c  jmp 0x00007981DDFDF099
00007981ddfe0d11  sub rsp, 0x08
00007981ddfe0d15  push rax
00007981ddfe0d16  push rcx
00007981ddfe0d17  push rdx
00007981ddfe0d18  push rdi
00007981ddfe0d19  push rsi
00007981ddfe0d1a  push r8
00007981ddfe0d1c  push r9
00007981ddfe0d1e  push r10
00007981ddfe0d20  push r11
00007981ddfe0d22  sub rsp, 0xF0
00007981ddfe0d29  vmovaps [rsp], xmm0
00007981ddfe0d2e  vmovaps [rsp+0x10], xmm1
00007981ddfe0d34  vmovaps [rsp+0x20], xmm2
00007981ddfe0d3a  vmovaps [rsp+0x30], xmm4
00007981ddfe0d40  vmovaps [rsp+0x40], xmm5
00007981ddfe0d46  vmovaps [rsp+0x50], xmm6
00007981ddfe0d4c  vmovaps [rsp+0x60], xmm7
00007981ddfe0d52  vmovaps [rsp+0x70], xmm8
00007981ddfe0d58  vmovaps [rsp+0x80], xmm9
00007981ddfe0d61  vmovaps [rsp+0x90], xmm10
00007981ddfe0d6a  vmovaps [rsp+0xA0], xmm11
00007981ddfe0d73  vmovaps [rsp+0xB0], xmm12
00007981ddfe0d7c  vmovaps [rsp+0xC0], xmm13
00007981ddfe0d85  vmovaps [rsp+0xD0], xmm14
00007981ddfe0d8e  vmovaps [rsp+0xE0], xmm15
00007981ddfe0d97  sub rsp, 0x30
00007981ddfe0d9b  movaps [rsp], xmm3
00007981ddfe0d9f  movaps [rsp+0x10], xmm1
00007981ddfe0da4  movaps [rsp+0x20], xmm9
00007981ddfe0daa  lea rdi, [rsp]
00007981ddfe0dae  mov esi, 0x00
00007981ddfe0db3  mov rax, 0x5782A6EB3530
00007981ddfe0dbd  call rax
00007981ddfe0dbf  movaps xmm3, [rsp]
00007981ddfe0dc3  add rsp, 0x30
00007981ddfe0dc7  vmovaps xmm0, [rsp]
00007981ddfe0dcc  vmovaps xmm1, [rsp+0x10]
00007981ddfe0dd2  vmovaps xmm2, [rsp+0x20]
00007981ddfe0dd8  vmovaps xmm4, [rsp+0x30]
00007981ddfe0dde  vmovaps xmm5, [rsp+0x40]
00007981ddfe0de4  vmovaps xmm6, [rsp+0x50]
00007981ddfe0dea  vmovaps xmm7, [rsp+0x60]
00007981ddfe0df0  vmovaps xmm8, [rsp+0x70]
00007981ddfe0df6  vmovaps xmm9, [rsp+0x80]
00007981ddfe0dff  vmovaps xmm10, [rsp+0x90]
00007981ddfe0e08  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0e11  vmovaps xmm12, [rsp+0xB0]
00007981ddfe0e1a  vmovaps xmm13, [rsp+0xC0]
00007981ddfe0e23  vmovaps xmm14, [rsp+0xD0]
00007981ddfe0e2c  vmovaps xmm15, [rsp+0xE0]
00007981ddfe0e35  add rsp, 0xF0
00007981ddfe0e3c  pop r11
00007981ddfe0e3e  pop r10
00007981ddfe0e40  pop r9
00007981ddfe0e42  pop r8
00007981ddfe0e44  pop rsi
00007981ddfe0e45  pop rdi
00007981ddfe0e46  pop rdx
00007981ddfe0e47  pop rcx
00007981ddfe0e48  pop rax
00007981ddfe0e49  add rsp, 0x08
00007981ddfe0e4d  jmp 0x00007981DDFDF0D6
00007981ddfe0e52  sub rsp, 0x08
00007981ddfe0e56  push rax
00007981ddfe0e57  push rcx
00007981ddfe0e58  push rdx
00007981ddfe0e59  push rdi
00007981ddfe0e5a  push rsi
00007981ddfe0e5b  push r8
00007981ddfe0e5d  push r9
00007981ddfe0e5f  push r10
00007981ddfe0e61  push r11
00007981ddfe0e63  sub rsp, 0xF0
00007981ddfe0e6a  vmovaps [rsp], xmm0
00007981ddfe0e6f  vmovaps [rsp+0x10], xmm2
00007981ddfe0e75  vmovaps [rsp+0x20], xmm3
00007981ddfe0e7b  vmovaps [rsp+0x30], xmm4
00007981ddfe0e81  vmovaps [rsp+0x40], xmm5
00007981ddfe0e87  vmovaps [rsp+0x50], xmm6
00007981ddfe0e8d  vmovaps [rsp+0x60], xmm7
00007981ddfe0e93  vmovaps [rsp+0x70], xmm8
00007981ddfe0e99  vmovaps [rsp+0x80], xmm9
00007981ddfe0ea2  vmovaps [rsp+0x90], xmm10
00007981ddfe0eab  vmovaps [rsp+0xA0], xmm11
00007981ddfe0eb4  vmovaps [rsp+0xB0], xmm12
00007981ddfe0ebd  vmovaps [rsp+0xC0], xmm13
00007981ddfe0ec6  vmovaps [rsp+0xD0], xmm14
00007981ddfe0ecf  vmovaps [rsp+0xE0], xmm15
00007981ddfe0ed8  sub rsp, 0x30
00007981ddfe0edc  movaps [rsp], xmm1
00007981ddfe0ee0  movaps [rsp+0x10], xmm15
00007981ddfe0ee6  movaps [rsp+0x20], xmm9
00007981ddfe0eec  lea rdi, [rsp]
00007981ddfe0ef0  mov esi, 0x00
00007981ddfe0ef5  mov rax, 0x5782A6EB3530
00007981ddfe0eff  call rax
00007981ddfe0f01  movaps xmm1, [rsp]
00007981ddfe0f05  add rsp, 0x30
00007981ddfe0f09  vmovaps xmm0, [rsp]
00007981ddfe0f0e  vmovaps xmm2, [rsp+0x10]
00007981ddfe0f14  vmovaps xmm3, [rsp+0x20]
00007981ddfe0f1a  vmovaps xmm4, [rsp+0x30]
00007981ddfe0f20  vmovaps xmm5, [rsp+0x40]
00007981ddfe0f26  vmovaps xmm6, [rsp+0x50]
00007981ddfe0f2c  vmovaps xmm7, [rsp+0x60]
00007981ddfe0f32  vmovaps xmm8, [rsp+0x70]
00007981ddfe0f38  vmovaps xmm9, [rsp+0x80]
00007981ddfe0f41  vmovaps xmm10, [rsp+0x90]
00007981ddfe0f4a  vmovaps xmm11, [rsp+0xA0]
00007981ddfe0f53  vmovaps xmm12, [rsp+0xB0]
00007981ddfe0f5c  vmovaps xmm13, [rsp+0xC0]
00007981ddfe0f65  vmovaps xmm14, [rsp+0xD0]
00007981ddfe0f6e  vmovaps xmm15, [rsp+0xE0]
00007981ddfe0f77  add rsp, 0xF0
00007981ddfe0f7e  pop r11
00007981ddfe0f80  pop r10
00007981ddfe0f82  pop r9
00007981ddfe0f84  pop r8
00007981ddfe0f86  pop rsi
00007981ddfe0f87  pop rdi
00007981ddfe0f88  pop rdx
00007981ddfe0f89  pop rcx
00007981ddfe0f8a  pop rax
00007981ddfe0f8b  add rsp, 0x08
00007981ddfe0f8f  jmp 0x00007981DDFDF15E
00007981ddfe0f94  call 0x00007981DDEC4620
00007981ddfe0f99  jmp 0x00007981DDFDF16B
00007981ddfe0f9e  sub rsp, 0x08
00007981ddfe0fa2  push rax
00007981ddfe0fa3  push rcx
00007981ddfe0fa4  push rdx
00007981ddfe0fa5  push rdi
00007981ddfe0fa6  push rsi
00007981ddfe0fa7  push r8
00007981ddfe0fa9  push r9
00007981ddfe0fab  push r10
00007981ddfe0fad  push r11
00007981ddfe0faf  sub rsp, 0xF0
00007981ddfe0fb6  vmovaps [rsp], xmm0
00007981ddfe0fbb  vmovaps [rsp+0x10], xmm2
00007981ddfe0fc1  vmovaps [rsp+0x20], xmm3
00007981ddfe0fc7  vmovaps [rsp+0x30], xmm4
00007981ddfe0fcd  vmovaps [rsp+0x40], xmm5
00007981ddfe0fd3  vmovaps [rsp+0x50], xmm6
00007981ddfe0fd9  vmovaps [rsp+0x60], xmm7
00007981ddfe0fdf  vmovaps [rsp+0x70], xmm8
00007981ddfe0fe5  vmovaps [rsp+0x80], xmm9
00007981ddfe0fee  vmovaps [rsp+0x90], xmm10
00007981ddfe0ff7  vmovaps [rsp+0xA0], xmm11
00007981ddfe1000  vmovaps [rsp+0xB0], xmm12
00007981ddfe1009  vmovaps [rsp+0xC0], xmm13
00007981ddfe1012  vmovaps [rsp+0xD0], xmm14
00007981ddfe101b  vmovaps [rsp+0xE0], xmm15
00007981ddfe1024  sub rsp, 0x30
00007981ddfe1028  movaps [rsp], xmm1
00007981ddfe102c  movaps [rsp+0x10], xmm5
00007981ddfe1031  movaps [rsp+0x20], xmm7
00007981ddfe1036  lea rdi, [rsp]
00007981ddfe103a  mov esi, 0x00
00007981ddfe103f  mov rax, 0x5782A6EB3530
00007981ddfe1049  call rax
00007981ddfe104b  movaps xmm1, [rsp]
00007981ddfe104f  add rsp, 0x30
00007981ddfe1053  vmovaps xmm0, [rsp]
00007981ddfe1058  vmovaps xmm2, [rsp+0x10]
00007981ddfe105e  vmovaps xmm3, [rsp+0x20]
00007981ddfe1064  vmovaps xmm4, [rsp+0x30]
00007981ddfe106a  vmovaps xmm5, [rsp+0x40]
00007981ddfe1070  vmovaps xmm6, [rsp+0x50]
00007981ddfe1076  vmovaps xmm7, [rsp+0x60]
00007981ddfe107c  vmovaps xmm8, [rsp+0x70]
00007981ddfe1082  vmovaps xmm9, [rsp+0x80]
00007981ddfe108b  vmovaps xmm10, [rsp+0x90]
00007981ddfe1094  vmovaps xmm11, [rsp+0xA0]
00007981ddfe109d  vmovaps xmm12, [rsp+0xB0]
00007981ddfe10a6  vmovaps xmm13, [rsp+0xC0]
00007981ddfe10af  vmovaps xmm14, [rsp+0xD0]
00007981ddfe10b8  vmovaps xmm15, [rsp+0xE0]
00007981ddfe10c1  add rsp, 0xF0
00007981ddfe10c8  pop r11
00007981ddfe10ca  pop r10
00007981ddfe10cc  pop r9
00007981ddfe10ce  pop r8
00007981ddfe10d0  pop rsi
00007981ddfe10d1  pop rdi
00007981ddfe10d2  pop rdx
00007981ddfe10d3  pop rcx
00007981ddfe10d4  pop rax
00007981ddfe10d5  add rsp, 0x08
00007981ddfe10d9  jmp 0x00007981DDFDF210
00007981ddfe10de  sub rsp, 0x08
00007981ddfe10e2  push rax
00007981ddfe10e3  push rcx
00007981ddfe10e4  push rdx
00007981ddfe10e5  push rdi
00007981ddfe10e6  push rsi
00007981ddfe10e7  push r8
00007981ddfe10e9  push r9
00007981ddfe10eb  push r10
00007981ddfe10ed  push r11
00007981ddfe10ef  sub rsp, 0xF0
00007981ddfe10f6  vmovaps [rsp], xmm0
00007981ddfe10fb  vmovaps [rsp+0x10], xmm1
00007981ddfe1101  vmovaps [rsp+0x20], xmm2
00007981ddfe1107  vmovaps [rsp+0x30], xmm3
00007981ddfe110d  vmovaps [rsp+0x40], xmm4
00007981ddfe1113  vmovaps [rsp+0x50], xmm5
00007981ddfe1119  vmovaps [rsp+0x60], xmm6
00007981ddfe111f  vmovaps [rsp+0x70], xmm8
00007981ddfe1125  vmovaps [rsp+0x80], xmm9
00007981ddfe112e  vmovaps [rsp+0x90], xmm10
00007981ddfe1137  vmovaps [rsp+0xA0], xmm11
00007981ddfe1140  vmovaps [rsp+0xB0], xmm12
00007981ddfe1149  vmovaps [rsp+0xC0], xmm13
00007981ddfe1152  vmovaps [rsp+0xD0], xmm14
00007981ddfe115b  vmovaps [rsp+0xE0], xmm15
00007981ddfe1164  sub rsp, 0x30
00007981ddfe1168  movaps [rsp], xmm7
00007981ddfe116c  movaps [rsp+0x10], xmm5
00007981ddfe1171  movaps [rsp+0x20], xmm15
00007981ddfe1177  lea rdi, [rsp]
00007981ddfe117b  mov esi, 0x00
00007981ddfe1180  mov rax, 0x5782A6EB3530
00007981ddfe118a  call rax
00007981ddfe118c  movaps xmm7, [rsp]
00007981ddfe1190  add rsp, 0x30
00007981ddfe1194  vmovaps xmm0, [rsp]
00007981ddfe1199  vmovaps xmm1, [rsp+0x10]
00007981ddfe119f  vmovaps xmm2, [rsp+0x20]
00007981ddfe11a5  vmovaps xmm3, [rsp+0x30]
00007981ddfe11ab  vmovaps xmm4, [rsp+0x40]
00007981ddfe11b1  vmovaps xmm5, [rsp+0x50]
00007981ddfe11b7  vmovaps xmm6, [rsp+0x60]
00007981ddfe11bd  vmovaps xmm8, [rsp+0x70]
00007981ddfe11c3  vmovaps xmm9, [rsp+0x80]
00007981ddfe11cc  vmovaps xmm10, [rsp+0x90]
00007981ddfe11d5  vmovaps xmm11, [rsp+0xA0]
00007981ddfe11de  vmovaps xmm12, [rsp+0xB0]
00007981ddfe11e7  vmovaps xmm13, [rsp+0xC0]
00007981ddfe11f0  vmovaps xmm14, [rsp+0xD0]
00007981ddfe11f9  vmovaps xmm15, [rsp+0xE0]
00007981ddfe1202  add rsp, 0xF0
00007981ddfe1209  pop r11
00007981ddfe120b  pop r10
00007981ddfe120d  pop r9
00007981ddfe120f  pop r8
00007981ddfe1211  pop rsi
00007981ddfe1212  pop rdi
00007981ddfe1213  pop rdx
00007981ddfe1214  pop rcx
00007981ddfe1215  pop rax
00007981ddfe1216  add rsp, 0x08
00007981ddfe121a  jmp 0x00007981DDFDF246
00007981ddfe121f  call 0x00007981DDEB52F0
00007981ddfe1224  jmp 0x00007981DDFDF253
00007981ddfe1229  sub rsp, 0x08
00007981ddfe122d  push rax
00007981ddfe122e  push rcx
00007981ddfe122f  push rdx
00007981ddfe1230  push rdi
00007981ddfe1231  push rsi
00007981ddfe1232  push r8
00007981ddfe1234  push r9
00007981ddfe1236  push r10
00007981ddfe1238  push r11
00007981ddfe123a  sub rsp, 0xF0
00007981ddfe1241  vmovaps [rsp], xmm0
00007981ddfe1246  vmovaps [rsp+0x10], xmm1
00007981ddfe124c  vmovaps [rsp+0x20], xmm2
00007981ddfe1252  vmovaps [rsp+0x30], xmm3
00007981ddfe1258  vmovaps [rsp+0x40], xmm4
00007981ddfe125e  vmovaps [rsp+0x50], xmm5
00007981ddfe1264  vmovaps [rsp+0x60], xmm6
00007981ddfe126a  vmovaps [rsp+0x70], xmm7
00007981ddfe1270  vmovaps [rsp+0x80], xmm8
00007981ddfe1279  vmovaps [rsp+0x90], xmm9
00007981ddfe1282  vmovaps [rsp+0xA0], xmm10
00007981ddfe128b  vmovaps [rsp+0xB0], xmm11
00007981ddfe1294  vmovaps [rsp+0xC0], xmm12
00007981ddfe129d  vmovaps [rsp+0xD0], xmm13
00007981ddfe12a6  vmovaps [rsp+0xE0], xmm14
00007981ddfe12af  sub rsp, 0x30
00007981ddfe12b3  movaps [rsp], xmm15
00007981ddfe12b8  movaps [rsp+0x10], xmm5
00007981ddfe12bd  movaps [rsp+0x20], xmm3
00007981ddfe12c2  lea rdi, [rsp]
00007981ddfe12c6  mov esi, 0x00
00007981ddfe12cb  mov rax, 0x5782A6EB3530
00007981ddfe12d5  call rax
00007981ddfe12d7  movaps xmm15, [rsp]
00007981ddfe12dc  add rsp, 0x30
00007981ddfe12e0  vmovaps xmm0, [rsp]
00007981ddfe12e5  vmovaps xmm1, [rsp+0x10]
00007981ddfe12eb  vmovaps xmm2, [rsp+0x20]
00007981ddfe12f1  vmovaps xmm3, [rsp+0x30]
00007981ddfe12f7  vmovaps xmm4, [rsp+0x40]
00007981ddfe12fd  vmovaps xmm5, [rsp+0x50]
00007981ddfe1303  vmovaps xmm6, [rsp+0x60]
00007981ddfe1309  vmovaps xmm7, [rsp+0x70]
00007981ddfe130f  vmovaps xmm8, [rsp+0x80]
00007981ddfe1318  vmovaps xmm9, [rsp+0x90]
00007981ddfe1321  vmovaps xmm10, [rsp+0xA0]
00007981ddfe132a  vmovaps xmm11, [rsp+0xB0]
00007981ddfe1333  vmovaps xmm12, [rsp+0xC0]
00007981ddfe133c  vmovaps xmm13, [rsp+0xD0]
00007981ddfe1345  vmovaps xmm14, [rsp+0xE0]
00007981ddfe134e  add rsp, 0xF0
00007981ddfe1355  pop r11
00007981ddfe1357  pop r10
00007981ddfe1359  pop r9
00007981ddfe135b  pop r8
00007981ddfe135d  pop rsi
00007981ddfe135e  pop rdi
00007981ddfe135f  pop rdx
00007981ddfe1360  pop rcx
00007981ddfe1361  pop rax
00007981ddfe1362  add rsp, 0x08
00007981ddfe1366  jmp 0x00007981DDFDF279
00007981ddfe136b  sub rsp, 0x08
00007981ddfe136f  push rax
00007981ddfe1370  push rcx
00007981ddfe1371  push rdx
00007981ddfe1372  push rdi
00007981ddfe1373  push rsi
00007981ddfe1374  push r8
00007981ddfe1376  push r9
00007981ddfe1378  push r10
00007981ddfe137a  push r11
00007981ddfe137c  sub rsp, 0xF0
00007981ddfe1383  vmovaps [rsp], xmm0
00007981ddfe1388  vmovaps [rsp+0x10], xmm2
00007981ddfe138e  vmovaps [rsp+0x20], xmm3
00007981ddfe1394  vmovaps [rsp+0x30], xmm4
00007981ddfe139a  vmovaps [rsp+0x40], xmm5
00007981ddfe13a0  vmovaps [rsp+0x50], xmm6
00007981ddfe13a6  vmovaps [rsp+0x60], xmm7
00007981ddfe13ac  vmovaps [rsp+0x70], xmm8
00007981ddfe13b2  vmovaps [rsp+0x80], xmm9
00007981ddfe13bb  vmovaps [rsp+0x90], xmm10
00007981ddfe13c4  vmovaps [rsp+0xA0], xmm11
00007981ddfe13cd  vmovaps [rsp+0xB0], xmm12
00007981ddfe13d6  vmovaps [rsp+0xC0], xmm13
00007981ddfe13df  vmovaps [rsp+0xD0], xmm14
00007981ddfe13e8  vmovaps [rsp+0xE0], xmm15
00007981ddfe13f1  sub rsp, 0x30
00007981ddfe13f5  movaps [rsp], xmm1
00007981ddfe13f9  movaps [rsp+0x10], xmm5
00007981ddfe13fe  movaps [rsp+0x20], xmm4
00007981ddfe1403  lea rdi, [rsp]
00007981ddfe1407  mov esi, 0x00
00007981ddfe140c  mov rax, 0x5782A6EB3530
00007981ddfe1416  call rax
00007981ddfe1418  movaps xmm1, [rsp]
00007981ddfe141c  add rsp, 0x30
00007981ddfe1420  vmovaps xmm0, [rsp]
00007981ddfe1425  vmovaps xmm2, [rsp+0x10]
00007981ddfe142b  vmovaps xmm3, [rsp+0x20]
00007981ddfe1431  vmovaps xmm4, [rsp+0x30]
00007981ddfe1437  vmovaps xmm5, [rsp+0x40]
00007981ddfe143d  vmovaps xmm6, [rsp+0x50]
00007981ddfe1443  vmovaps xmm7, [rsp+0x60]
00007981ddfe1449  vmovaps xmm8, [rsp+0x70]
00007981ddfe144f  vmovaps xmm9, [rsp+0x80]
00007981ddfe1458  vmovaps xmm10, [rsp+0x90]
00007981ddfe1461  vmovaps xmm11, [rsp+0xA0]
00007981ddfe146a  vmovaps xmm12, [rsp+0xB0]
00007981ddfe1473  vmovaps xmm13, [rsp+0xC0]
00007981ddfe147c  vmovaps xmm14, [rsp+0xD0]
00007981ddfe1485  vmovaps xmm15, [rsp+0xE0]
00007981ddfe148e  add rsp, 0xF0
00007981ddfe1495  pop r11
00007981ddfe1497  pop r10
00007981ddfe1499  pop r9
00007981ddfe149b  pop r8
00007981ddfe149d  pop rsi
00007981ddfe149e  pop rdi
00007981ddfe149f  pop rdx
00007981ddfe14a0  pop rcx
00007981ddfe14a1  pop rax
00007981ddfe14a2  add rsp, 0x08
00007981ddfe14a6  jmp 0x00007981DDFDF299
00007981ddfe14ab  sub rsp, 0x08
00007981ddfe14af  push rax
00007981ddfe14b0  push rcx
00007981ddfe14b1  push rdx
00007981ddfe14b2  push rdi
00007981ddfe14b3  push rsi
00007981ddfe14b4  push r8
00007981ddfe14b6  push r9
00007981ddfe14b8  push r10
00007981ddfe14ba  push r11
00007981ddfe14bc  sub rsp, 0xF0
00007981ddfe14c3  vmovaps [rsp], xmm0
00007981ddfe14c8  vmovaps [rsp+0x10], xmm1
00007981ddfe14ce  vmovaps [rsp+0x20], xmm2
00007981ddfe14d4  vmovaps [rsp+0x30], xmm3
00007981ddfe14da  vmovaps [rsp+0x40], xmm5
00007981ddfe14e0  vmovaps [rsp+0x50], xmm6
00007981ddfe14e6  vmovaps [rsp+0x60], xmm7
00007981ddfe14ec  vmovaps [rsp+0x70], xmm8
00007981ddfe14f2  vmovaps [rsp+0x80], xmm9
00007981ddfe14fb  vmovaps [rsp+0x90], xmm10
00007981ddfe1504  vmovaps [rsp+0xA0], xmm11
00007981ddfe150d  vmovaps [rsp+0xB0], xmm12
00007981ddfe1516  vmovaps [rsp+0xC0], xmm13
00007981ddfe151f  vmovaps [rsp+0xD0], xmm14
00007981ddfe1528  vmovaps [rsp+0xE0], xmm15
00007981ddfe1531  sub rsp, 0x30
00007981ddfe1535  movaps [rsp], xmm4
00007981ddfe1539  movaps [rsp+0x10], xmm3
00007981ddfe153e  movaps [rsp+0x20], xmm5
00007981ddfe1543  lea rdi, [rsp]
00007981ddfe1547  mov esi, 0x00
00007981ddfe154c  mov rax, 0x5782A6EB3530
00007981ddfe1556  call rax
00007981ddfe1558  movaps xmm4, [rsp]
00007981ddfe155c  add rsp, 0x30
00007981ddfe1560  vmovaps xmm0, [rsp]
00007981ddfe1565  vmovaps xmm1, [rsp+0x10]
00007981ddfe156b  vmovaps xmm2, [rsp+0x20]
00007981ddfe1571  vmovaps xmm3, [rsp+0x30]
00007981ddfe1577  vmovaps xmm5, [rsp+0x40]
00007981ddfe157d  vmovaps xmm6, [rsp+0x50]
00007981ddfe1583  vmovaps xmm7, [rsp+0x60]
00007981ddfe1589  vmovaps xmm8, [rsp+0x70]
00007981ddfe158f  vmovaps xmm9, [rsp+0x80]
00007981ddfe1598  vmovaps xmm10, [rsp+0x90]
00007981ddfe15a1  vmovaps xmm11, [rsp+0xA0]
00007981ddfe15aa  vmovaps xmm12, [rsp+0xB0]
00007981ddfe15b3  vmovaps xmm13, [rsp+0xC0]
00007981ddfe15bc  vmovaps xmm14, [rsp+0xD0]
00007981ddfe15c5  vmovaps xmm15, [rsp+0xE0]
00007981ddfe15ce  add rsp, 0xF0
00007981ddfe15d5  pop r11
00007981ddfe15d7  pop r10
00007981ddfe15d9  pop r9
00007981ddfe15db  pop r8
00007981ddfe15dd  pop rsi
00007981ddfe15de  pop rdi
00007981ddfe15df  pop rdx
00007981ddfe15e0  pop rcx
00007981ddfe15e1  pop rax
00007981ddfe15e2  add rsp, 0x08
00007981ddfe15e6  jmp 0x00007981DDFDF2E7
00007981ddfe15eb  call 0x00007981DDEB52F0
00007981ddfe15f0  jmp 0x00007981DDFDF2F4
00007981ddfe15f5  sub rsp, 0x08
00007981ddfe15f9  push rax
00007981ddfe15fa  push rcx
00007981ddfe15fb  push rdx
00007981ddfe15fc  push rdi
00007981ddfe15fd  push rsi
00007981ddfe15fe  push r8
00007981ddfe1600  push r9
00007981ddfe1602  push r10
00007981ddfe1604  push r11
00007981ddfe1606  sub rsp, 0xF0
00007981ddfe160d  vmovaps [rsp], xmm0
00007981ddfe1612  vmovaps [rsp+0x10], xmm1
00007981ddfe1618  vmovaps [rsp+0x20], xmm2
00007981ddfe161e  vmovaps [rsp+0x30], xmm3
00007981ddfe1624  vmovaps [rsp+0x40], xmm4
00007981ddfe162a  vmovaps [rsp+0x50], xmm6
00007981ddfe1630  vmovaps [rsp+0x60], xmm7
00007981ddfe1636  vmovaps [rsp+0x70], xmm8
00007981ddfe163c  vmovaps [rsp+0x80], xmm9
00007981ddfe1645  vmovaps [rsp+0x90], xmm10
00007981ddfe164e  vmovaps [rsp+0xA0], xmm11
00007981ddfe1657  vmovaps [rsp+0xB0], xmm12
00007981ddfe1660  vmovaps [rsp+0xC0], xmm13
00007981ddfe1669  vmovaps [rsp+0xD0], xmm14
00007981ddfe1672  vmovaps [rsp+0xE0], xmm15
00007981ddfe167b  sub rsp, 0x30
00007981ddfe167f  movaps [rsp], xmm5
00007981ddfe1683  movaps [rsp+0x10], xmm6
00007981ddfe1688  movaps [rsp+0x20], xmm3
00007981ddfe168d  lea rdi, [rsp]
00007981ddfe1691  mov esi, 0x00
00007981ddfe1696  mov rax, 0x5782A6EB3530
00007981ddfe16a0  call rax
00007981ddfe16a2  movaps xmm5, [rsp]
00007981ddfe16a6  add rsp, 0x30
00007981ddfe16aa  vmovaps xmm0, [rsp]
00007981ddfe16af  vmovaps xmm1, [rsp+0x10]
00007981ddfe16b5  vmovaps xmm2, [rsp+0x20]
00007981ddfe16bb  vmovaps xmm3, [rsp+0x30]
00007981ddfe16c1  vmovaps xmm4, [rsp+0x40]
00007981ddfe16c7  vmovaps xmm6, [rsp+0x50]
00007981ddfe16cd  vmovaps xmm7, [rsp+0x60]
00007981ddfe16d3  vmovaps xmm8, [rsp+0x70]
00007981ddfe16d9  vmovaps xmm9, [rsp+0x80]
00007981ddfe16e2  vmovaps xmm10, [rsp+0x90]
00007981ddfe16eb  vmovaps xmm11, [rsp+0xA0]
00007981ddfe16f4  vmovaps xmm12, [rsp+0xB0]
00007981ddfe16fd  vmovaps xmm13, [rsp+0xC0]
00007981ddfe1706  vmovaps xmm14, [rsp+0xD0]
00007981ddfe170f  vmovaps xmm15, [rsp+0xE0]
00007981ddfe1718  add rsp, 0xF0
00007981ddfe171f  pop r11
00007981ddfe1721  pop r10
00007981ddfe1723  pop r9
00007981ddfe1725  pop r8
00007981ddfe1727  pop rsi
00007981ddfe1728  pop rdi
00007981ddfe1729  pop rdx
00007981ddfe172a  pop rcx
00007981ddfe172b  pop rax
00007981ddfe172c  add rsp, 0x08
00007981ddfe1730  jmp 0x00007981DDFDF31A
00007981ddfe1735  sub rsp, 0x08
00007981ddfe1739  push rax
00007981ddfe173a  push rcx
00007981ddfe173b  push rdx
00007981ddfe173c  push rdi
00007981ddfe173d  push rsi
00007981ddfe173e  push r8
00007981ddfe1740  push r9
00007981ddfe1742  push r10
00007981ddfe1744  push r11
00007981ddfe1746  sub rsp, 0xF0
00007981ddfe174d  vmovaps [rsp], xmm0
00007981ddfe1752  vmovaps [rsp+0x10], xmm1
00007981ddfe1758  vmovaps [rsp+0x20], xmm2
00007981ddfe175e  vmovaps [rsp+0x30], xmm3
00007981ddfe1764  vmovaps [rsp+0x40], xmm4
00007981ddfe176a  vmovaps [rsp+0x50], xmm5
00007981ddfe1770  vmovaps [rsp+0x60], xmm7
00007981ddfe1776  vmovaps [rsp+0x70], xmm8
00007981ddfe177c  vmovaps [rsp+0x80], xmm9
00007981ddfe1785  vmovaps [rsp+0x90], xmm10
00007981ddfe178e  vmovaps [rsp+0xA0], xmm11
00007981ddfe1797  vmovaps [rsp+0xB0], xmm12
00007981ddfe17a0  vmovaps [rsp+0xC0], xmm13
00007981ddfe17a9  vmovaps [rsp+0xD0], xmm14
00007981ddfe17b2  vmovaps [rsp+0xE0], xmm15
00007981ddfe17bb  sub rsp, 0x30
00007981ddfe17bf  movaps [rsp], xmm6
00007981ddfe17c3  movaps [rsp+0x10], xmm9
00007981ddfe17c9  movaps [rsp+0x20], xmm1
00007981ddfe17ce  lea rdi, [rsp]
00007981ddfe17d2  mov esi, 0x00
00007981ddfe17d7  mov rax, 0x5782A6EB3530
00007981ddfe17e1  call rax
00007981ddfe17e3  movaps xmm6, [rsp]
00007981ddfe17e7  add rsp, 0x30
00007981ddfe17eb  vmovaps xmm0, [rsp]
00007981ddfe17f0  vmovaps xmm1, [rsp+0x10]
00007981ddfe17f6  vmovaps xmm2, [rsp+0x20]
00007981ddfe17fc  vmovaps xmm3, [rsp+0x30]
00007981ddfe1802  vmovaps xmm4, [rsp+0x40]
00007981ddfe1808  vmovaps xmm5, [rsp+0x50]
00007981ddfe180e  vmovaps xmm7, [rsp+0x60]
00007981ddfe1814  vmovaps xmm8, [rsp+0x70]
00007981ddfe181a  vmovaps xmm9, [rsp+0x80]
00007981ddfe1823  vmovaps xmm10, [rsp+0x90]
00007981ddfe182c  vmovaps xmm11, [rsp+0xA0]
00007981ddfe1835  vmovaps xmm12, [rsp+0xB0]
00007981ddfe183e  vmovaps xmm13, [rsp+0xC0]
00007981ddfe1847  vmovaps xmm14, [rsp+0xD0]
00007981ddfe1850  vmovaps xmm15, [rsp+0xE0]
00007981ddfe1859  add rsp, 0xF0
00007981ddfe1860  pop r11
00007981ddfe1862  pop r10
00007981ddfe1864  pop r9
00007981ddfe1866  pop r8
00007981ddfe1868  pop rsi
00007981ddfe1869  pop rdi
00007981ddfe186a  pop rdx
00007981ddfe186b  pop rcx
00007981ddfe186c  pop rax
00007981ddfe186d  add rsp, 0x08
00007981ddfe1871  jmp 0x00007981DDFDF33E
00007981ddfe1876  sub rsp, 0x08
00007981ddfe187a  push rax
00007981ddfe187b  push rcx
00007981ddfe187c  push rdx
00007981ddfe187d  push rdi
00007981ddfe187e  push rsi
00007981ddfe187f  push r8
00007981ddfe1881  push r9
00007981ddfe1883  push r10
00007981ddfe1885  push r11
00007981ddfe1887  sub rsp, 0xF0
00007981ddfe188e  vmovaps [rsp], xmm0
00007981ddfe1893  vmovaps [rsp+0x10], xmm1
00007981ddfe1899  vmovaps [rsp+0x20], xmm2
00007981ddfe189f  vmovaps [rsp+0x30], xmm3
00007981ddfe18a5  vmovaps [rsp+0x40], xmm4
00007981ddfe18ab  vmovaps [rsp+0x50], xmm5
00007981ddfe18b1  vmovaps [rsp+0x60], xmm6
00007981ddfe18b7  vmovaps [rsp+0x70], xmm7
00007981ddfe18bd  vmovaps [rsp+0x80], xmm8
00007981ddfe18c6  vmovaps [rsp+0x90], xmm10
00007981ddfe18cf  vmovaps [rsp+0xA0], xmm11
00007981ddfe18d8  vmovaps [rsp+0xB0], xmm12
00007981ddfe18e1  vmovaps [rsp+0xC0], xmm13
00007981ddfe18ea  vmovaps [rsp+0xD0], xmm14
00007981ddfe18f3  vmovaps [rsp+0xE0], xmm15
00007981ddfe18fc  sub rsp, 0x30
00007981ddfe1900  movaps [rsp], xmm9
00007981ddfe1905  movaps [rsp+0x10], xmm3
00007981ddfe190a  movaps [rsp+0x20], xmm1
00007981ddfe190f  lea rdi, [rsp]
00007981ddfe1913  mov esi, 0x00
00007981ddfe1918  mov rax, 0x5782A6EB3530
00007981ddfe1922  call rax
00007981ddfe1924  movaps xmm9, [rsp]
00007981ddfe1929  add rsp, 0x30
00007981ddfe192d  vmovaps xmm0, [rsp]
00007981ddfe1932  vmovaps xmm1, [rsp+0x10]
00007981ddfe1938  vmovaps xmm2, [rsp+0x20]
00007981ddfe193e  vmovaps xmm3, [rsp+0x30]
00007981ddfe1944  vmovaps xmm4, [rsp+0x40]
00007981ddfe194a  vmovaps xmm5, [rsp+0x50]
00007981ddfe1950  vmovaps xmm6, [rsp+0x60]
00007981ddfe1956  vmovaps xmm7, [rsp+0x70]
00007981ddfe195c  vmovaps xmm8, [rsp+0x80]
00007981ddfe1965  vmovaps xmm10, [rsp+0x90]
00007981ddfe196e  vmovaps xmm11, [rsp+0xA0]
00007981ddfe1977  vmovaps xmm12, [rsp+0xB0]
00007981ddfe1980  vmovaps xmm13, [rsp+0xC0]
00007981ddfe1989  vmovaps xmm14, [rsp+0xD0]
00007981ddfe1992  vmovaps xmm15, [rsp+0xE0]
00007981ddfe199b  add rsp, 0xF0
00007981ddfe19a2  pop r11
00007981ddfe19a4  pop r10
00007981ddfe19a6  pop r9
00007981ddfe19a8  pop r8
00007981ddfe19aa  pop rsi
00007981ddfe19ab  pop rdi
00007981ddfe19ac  pop rdx
00007981ddfe19ad  pop rcx
00007981ddfe19ae  pop rax
00007981ddfe19af  add rsp, 0x08
00007981ddfe19b3  jmp 0x00007981DDFDF38A
00007981ddfe19b8  call 0x00007981DDEB52F0
00007981ddfe19bd  jmp 0x00007981DDFDF397
00007981ddfe19c2  sub rsp, 0x08
00007981ddfe19c6  push rax
00007981ddfe19c7  push rcx
00007981ddfe19c8  push rdx
00007981ddfe19c9  push rdi
00007981ddfe19ca  push rsi
00007981ddfe19cb  push r8
00007981ddfe19cd  push r9
00007981ddfe19cf  push r10
00007981ddfe19d1  push r11
00007981ddfe19d3  sub rsp, 0xF0
00007981ddfe19da  vmovaps [rsp], xmm0
00007981ddfe19df  vmovaps [rsp+0x10], xmm1
00007981ddfe19e5  vmovaps [rsp+0x20], xmm2
00007981ddfe19eb  vmovaps [rsp+0x30], xmm3
00007981ddfe19f1  vmovaps [rsp+0x40], xmm4
00007981ddfe19f7  vmovaps [rsp+0x50], xmm5
00007981ddfe19fd  vmovaps [rsp+0x60], xmm6
00007981ddfe1a03  vmovaps [rsp+0x70], xmm7
00007981ddfe1a09  vmovaps [rsp+0x80], xmm8
00007981ddfe1a12  vmovaps [rsp+0x90], xmm9
00007981ddfe1a1b  vmovaps [rsp+0xA0], xmm10
00007981ddfe1a24  vmovaps [rsp+0xB0], xmm11
00007981ddfe1a2d  vmovaps [rsp+0xC0], xmm12
00007981ddfe1a36  vmovaps [rsp+0xD0], xmm13
00007981ddfe1a3f  vmovaps [rsp+0xE0], xmm14
00007981ddfe1a48  sub rsp, 0x30
00007981ddfe1a4c  movaps [rsp], xmm15
00007981ddfe1a51  movaps [rsp+0x10], xmm3
00007981ddfe1a56  movaps [rsp+0x20], xmm7
00007981ddfe1a5b  lea rdi, [rsp]
00007981ddfe1a5f  mov esi, 0x00
00007981ddfe1a64  mov rax, 0x5782A6EB3530
00007981ddfe1a6e  call rax
00007981ddfe1a70  movaps xmm15, [rsp]
00007981ddfe1a75  add rsp, 0x30
00007981ddfe1a79  vmovaps xmm0, [rsp]
00007981ddfe1a7e  vmovaps xmm1, [rsp+0x10]
00007981ddfe1a84  vmovaps xmm2, [rsp+0x20]
00007981ddfe1a8a  vmovaps xmm3, [rsp+0x30]
00007981ddfe1a90  vmovaps xmm4, [rsp+0x40]
00007981ddfe1a96  vmovaps xmm5, [rsp+0x50]
00007981ddfe1a9c  vmovaps xmm6, [rsp+0x60]
00007981ddfe1aa2  vmovaps xmm7, [rsp+0x70]
00007981ddfe1aa8  vmovaps xmm8, [rsp+0x80]
00007981ddfe1ab1  vmovaps xmm9, [rsp+0x90]
00007981ddfe1aba  vmovaps xmm10, [rsp+0xA0]
00007981ddfe1ac3  vmovaps xmm11, [rsp+0xB0]
00007981ddfe1acc  vmovaps xmm12, [rsp+0xC0]
00007981ddfe1ad5  vmovaps xmm13, [rsp+0xD0]
00007981ddfe1ade  vmovaps xmm14, [rsp+0xE0]
00007981ddfe1ae7  add rsp, 0xF0
00007981ddfe1aee  pop r11
00007981ddfe1af0  pop r10
00007981ddfe1af2  pop r9
00007981ddfe1af4  pop r8
00007981ddfe1af6  pop rsi
00007981ddfe1af7  pop rdi
00007981ddfe1af8  pop rdx
00007981ddfe1af9  pop rcx
00007981ddfe1afa  pop rax
00007981ddfe1afb  add rsp, 0x08
00007981ddfe1aff  jmp 0x00007981DDFDF3C3
00007981ddfe1b04  sub rsp, 0x08
00007981ddfe1b08  push rax
00007981ddfe1b09  push rcx
00007981ddfe1b0a  push rdx
00007981ddfe1b0b  push rdi
00007981ddfe1b0c  push rsi
00007981ddfe1b0d  push r8
00007981ddfe1b0f  push r9
00007981ddfe1b11  push r10
00007981ddfe1b13  push r11
00007981ddfe1b15  sub rsp, 0xF0
00007981ddfe1b1c  vmovaps [rsp], xmm0
00007981ddfe1b21  vmovaps [rsp+0x10], xmm1
00007981ddfe1b27  vmovaps [rsp+0x20], xmm2
00007981ddfe1b2d  vmovaps [rsp+0x30], xmm4
00007981ddfe1b33  vmovaps [rsp+0x40], xmm5
00007981ddfe1b39  vmovaps [rsp+0x50], xmm6
00007981ddfe1b3f  vmovaps [rsp+0x60], xmm7
00007981ddfe1b45  vmovaps [rsp+0x70], xmm8
00007981ddfe1b4b  vmovaps [rsp+0x80], xmm9
00007981ddfe1b54  vmovaps [rsp+0x90], xmm10
00007981ddfe1b5d  vmovaps [rsp+0xA0], xmm11
00007981ddfe1b66  vmovaps [rsp+0xB0], xmm12
00007981ddfe1b6f  vmovaps [rsp+0xC0], xmm13
00007981ddfe1b78  vmovaps [rsp+0xD0], xmm14
00007981ddfe1b81  vmovaps [rsp+0xE0], xmm15
00007981ddfe1b8a  sub rsp, 0x30
00007981ddfe1b8e  movaps [rsp], xmm3
00007981ddfe1b92  movaps [rsp+0x10], xmm1
00007981ddfe1b97  movaps [rsp+0x20], xmm15
00007981ddfe1b9d  lea rdi, [rsp]
00007981ddfe1ba1  mov esi, 0x00
00007981ddfe1ba6  mov rax, 0x5782A6EB3530
00007981ddfe1bb0  call rax
00007981ddfe1bb2  movaps xmm3, [rsp]
00007981ddfe1bb6  add rsp, 0x30
00007981ddfe1bba  vmovaps xmm0, [rsp]
00007981ddfe1bbf  vmovaps xmm1, [rsp+0x10]
00007981ddfe1bc5  vmovaps xmm2, [rsp+0x20]
00007981ddfe1bcb  vmovaps xmm4, [rsp+0x30]
00007981ddfe1bd1  vmovaps xmm5, [rsp+0x40]
00007981ddfe1bd7  vmovaps xmm6, [rsp+0x50]
00007981ddfe1bdd  vmovaps xmm7, [rsp+0x60]
00007981ddfe1be3  vmovaps xmm8, [rsp+0x70]
00007981ddfe1be9  vmovaps xmm9, [rsp+0x80]
00007981ddfe1bf2  vmovaps xmm10, [rsp+0x90]
00007981ddfe1bfb  vmovaps xmm11, [rsp+0xA0]
00007981ddfe1c04  vmovaps xmm12, [rsp+0xB0]
00007981ddfe1c0d  vmovaps xmm13, [rsp+0xC0]
00007981ddfe1c16  vmovaps xmm14, [rsp+0xD0]
00007981ddfe1c1f  vmovaps xmm15, [rsp+0xE0]
00007981ddfe1c28  add rsp, 0xF0
00007981ddfe1c2f  pop r11
00007981ddfe1c31  pop r10
00007981ddfe1c33  pop r9
00007981ddfe1c35  pop r8
00007981ddfe1c37  pop rsi
00007981ddfe1c38  pop rdi
00007981ddfe1c39  pop rdx
00007981ddfe1c3a  pop rcx
00007981ddfe1c3b  pop rax
00007981ddfe1c3c  add rsp, 0x08
00007981ddfe1c40  jmp 0x00007981DDFDF452
00007981ddfe1c45  call 0x00007981DDEB52F0
00007981ddfe1c4a  jmp 0x00007981DDFDF45C
00007981ddfe1c4f  sub rsp, 0x08
00007981ddfe1c53  push rax
00007981ddfe1c54  push rcx
00007981ddfe1c55  push rdx
00007981ddfe1c56  push rdi
00007981ddfe1c57  push rsi
00007981ddfe1c58  push r8
00007981ddfe1c5a  push r9
00007981ddfe1c5c  push r10
00007981ddfe1c5e  push r11
00007981ddfe1c60  sub rsp, 0xF0
00007981ddfe1c67  vmovaps [rsp], xmm0
00007981ddfe1c6c  vmovaps [rsp+0x10], xmm1
00007981ddfe1c72  vmovaps [rsp+0x20], xmm2
00007981ddfe1c78  vmovaps [rsp+0x30], xmm3
00007981ddfe1c7e  vmovaps [rsp+0x40], xmm4
00007981ddfe1c84  vmovaps [rsp+0x50], xmm5
00007981ddfe1c8a  vmovaps [rsp+0x60], xmm6
00007981ddfe1c90  vmovaps [rsp+0x70], xmm7
00007981ddfe1c96  vmovaps [rsp+0x80], xmm8
00007981ddfe1c9f  vmovaps [rsp+0x90], xmm9
00007981ddfe1ca8  vmovaps [rsp+0xA0], xmm10
00007981ddfe1cb1  vmovaps [rsp+0xB0], xmm11
00007981ddfe1cba  vmovaps [rsp+0xC0], xmm12
00007981ddfe1cc3  vmovaps [rsp+0xD0], xmm13
00007981ddfe1ccc  vmovaps [rsp+0xE0], xmm14
00007981ddfe1cd5  sub rsp, 0x30
00007981ddfe1cd9  movaps [rsp], xmm15
00007981ddfe1cde  movaps [rsp+0x10], xmm14
00007981ddfe1ce4  movaps [rsp+0x20], xmm4
00007981ddfe1ce9  lea rdi, [rsp]
00007981ddfe1ced  mov esi, 0x00
00007981ddfe1cf2  mov rax, 0x5782A6EB3530
00007981ddfe1cfc  call rax
00007981ddfe1cfe  movaps xmm15, [rsp]
00007981ddfe1d03  add rsp, 0x30
00007981ddfe1d07  vmovaps xmm0, [rsp]
00007981ddfe1d0c  vmovaps xmm1, [rsp+0x10]
00007981ddfe1d12  vmovaps xmm2, [rsp+0x20]
00007981ddfe1d18  vmovaps xmm3, [rsp+0x30]
00007981ddfe1d1e  vmovaps xmm4, [rsp+0x40]
00007981ddfe1d24  vmovaps xmm5, [rsp+0x50]
00007981ddfe1d2a  vmovaps xmm6, [rsp+0x60]
00007981ddfe1d30  vmovaps xmm7, [rsp+0x70]
00007981ddfe1d36  vmovaps xmm8, [rsp+0x80]
00007981ddfe1d3f  vmovaps xmm9, [rsp+0x90]
00007981ddfe1d48  vmovaps xmm10, [rsp+0xA0]
00007981ddfe1d51  vmovaps xmm11, [rsp+0xB0]
00007981ddfe1d5a  vmovaps xmm12, [rsp+0xC0]
00007981ddfe1d63  vmovaps xmm13, [rsp+0xD0]
00007981ddfe1d6c  vmovaps xmm14, [rsp+0xE0]
00007981ddfe1d75  add rsp, 0xF0
00007981ddfe1d7c  pop r11
00007981ddfe1d7e  pop r10
00007981ddfe1d80  pop r9
00007981ddfe1d82  pop r8
00007981ddfe1d84  pop rsi
00007981ddfe1d85  pop rdi
00007981ddfe1d86  pop rdx
00007981ddfe1d87  pop rcx
00007981ddfe1d88  pop rax
00007981ddfe1d89  add rsp, 0x08
00007981ddfe1d8d  jmp 0x00007981DDFDF48A
00007981ddfe1d92  sub rsp, 0x08
00007981ddfe1d96  push rax
00007981ddfe1d97  push rcx
00007981ddfe1d98  push rdx
00007981ddfe1d99  push rdi
00007981ddfe1d9a  push rsi
00007981ddfe1d9b  push r8
00007981ddfe1d9d  push r9
00007981ddfe1d9f  push r10
00007981ddfe1da1  push r11
00007981ddfe1da3  sub rsp, 0xF0
00007981ddfe1daa  vmovaps [rsp], xmm0
00007981ddfe1daf  vmovaps [rsp+0x10], xmm1
00007981ddfe1db5  vmovaps [rsp+0x20], xmm2
00007981ddfe1dbb  vmovaps [rsp+0x30], xmm3
00007981ddfe1dc1  vmovaps [rsp+0x40], xmm4
00007981ddfe1dc7  vmovaps [rsp+0x50], xmm5
00007981ddfe1dcd  vmovaps [rsp+0x60], xmm6
00007981ddfe1dd3  vmovaps [rsp+0x70], xmm7
00007981ddfe1dd9  vmovaps [rsp+0x80], xmm8
00007981ddfe1de2  vmovaps [rsp+0x90], xmm9
00007981ddfe1deb  vmovaps [rsp+0xA0], xmm10
00007981ddfe1df4  vmovaps [rsp+0xB0], xmm11
00007981ddfe1dfd  vmovaps [rsp+0xC0], xmm12
00007981ddfe1e06  vmovaps [rsp+0xD0], xmm13
00007981ddfe1e0f  vmovaps [rsp+0xE0], xmm15
00007981ddfe1e18  sub rsp, 0x30
00007981ddfe1e1c  movaps [rsp], xmm14
00007981ddfe1e21  movaps [rsp+0x10], xmm2
00007981ddfe1e26  movaps [rsp+0x20], xmm1
00007981ddfe1e2b  lea rdi, [rsp]
00007981ddfe1e2f  mov esi, 0x00
00007981ddfe1e34  mov rax, 0x5782A6EB3530
00007981ddfe1e3e  call rax
00007981ddfe1e40  movaps xmm14, [rsp]
00007981ddfe1e45  add rsp, 0x30
00007981ddfe1e49  vmovaps xmm0, [rsp]
00007981ddfe1e4e  vmovaps xmm1, [rsp+0x10]
00007981ddfe1e54  vmovaps xmm2, [rsp+0x20]
00007981ddfe1e5a  vmovaps xmm3, [rsp+0x30]
00007981ddfe1e60  vmovaps xmm4, [rsp+0x40]
00007981ddfe1e66  vmovaps xmm5, [rsp+0x50]
00007981ddfe1e6c  vmovaps xmm6, [rsp+0x60]
00007981ddfe1e72  vmovaps xmm7, [rsp+0x70]
00007981ddfe1e78  vmovaps xmm8, [rsp+0x80]
00007981ddfe1e81  vmovaps xmm9, [rsp+0x90]
00007981ddfe1e8a  vmovaps xmm10, [rsp+0xA0]
00007981ddfe1e93  vmovaps xmm11, [rsp+0xB0]
00007981ddfe1e9c  vmovaps xmm12, [rsp+0xC0]
00007981ddfe1ea5  vmovaps xmm13, [rsp+0xD0]
00007981ddfe1eae  vmovaps xmm15, [rsp+0xE0]
00007981ddfe1eb7  add rsp, 0xF0
00007981ddfe1ebe  pop r11
00007981ddfe1ec0  pop r10
00007981ddfe1ec2  pop r9
00007981ddfe1ec4  pop r8
00007981ddfe1ec6  pop rsi
00007981ddfe1ec7  pop rdi
00007981ddfe1ec8  pop rdx
00007981ddfe1ec9  pop rcx
00007981ddfe1eca  pop rax
00007981ddfe1ecb  add rsp, 0x08
00007981ddfe1ecf  jmp 0x00007981DDFDF4B0
00007981ddfe1ed4  sub rsp, 0x08
00007981ddfe1ed8  push rax
00007981ddfe1ed9  push rcx
00007981ddfe1eda  push rdx
00007981ddfe1edb  push rdi
00007981ddfe1edc  push rsi
00007981ddfe1edd  push r8
00007981ddfe1edf  push r9
00007981ddfe1ee1  push r10
00007981ddfe1ee3  push r11
00007981ddfe1ee5  sub rsp, 0xF0
00007981ddfe1eec  vmovaps [rsp], xmm0
00007981ddfe1ef1  vmovaps [rsp+0x10], xmm2
00007981ddfe1ef7  vmovaps [rsp+0x20], xmm3
00007981ddfe1efd  vmovaps [rsp+0x30], xmm4
00007981ddfe1f03  vmovaps [rsp+0x40], xmm5
00007981ddfe1f09  vmovaps [rsp+0x50], xmm6
00007981ddfe1f0f  vmovaps [rsp+0x60], xmm7
00007981ddfe1f15  vmovaps [rsp+0x70], xmm8
00007981ddfe1f1b  vmovaps [rsp+0x80], xmm9
00007981ddfe1f24  vmovaps [rsp+0x90], xmm10
00007981ddfe1f2d  vmovaps [rsp+0xA0], xmm11
00007981ddfe1f36  vmovaps [rsp+0xB0], xmm12
00007981ddfe1f3f  vmovaps [rsp+0xC0], xmm13
00007981ddfe1f48  vmovaps [rsp+0xD0], xmm14
00007981ddfe1f51  vmovaps [rsp+0xE0], xmm15
00007981ddfe1f5a  sub rsp, 0x30
00007981ddfe1f5e  movaps [rsp], xmm1
00007981ddfe1f62  movaps [rsp+0x10], xmm4
00007981ddfe1f67  movaps [rsp+0x20], xmm9
00007981ddfe1f6d  lea rdi, [rsp]
00007981ddfe1f71  mov esi, 0x00
00007981ddfe1f76  mov rax, 0x5782A6EB3530
00007981ddfe1f80  call rax
00007981ddfe1f82  movaps xmm1, [rsp]
00007981ddfe1f86  add rsp, 0x30
00007981ddfe1f8a  vmovaps xmm0, [rsp]
00007981ddfe1f8f  vmovaps xmm2, [rsp+0x10]
00007981ddfe1f95  vmovaps xmm3, [rsp+0x20]
00007981ddfe1f9b  vmovaps xmm4, [rsp+0x30]
00007981ddfe1fa1  vmovaps xmm5, [rsp+0x40]
00007981ddfe1fa7  vmovaps xmm6, [rsp+0x50]
00007981ddfe1fad  vmovaps xmm7, [rsp+0x60]
00007981ddfe1fb3  vmovaps xmm8, [rsp+0x70]
00007981ddfe1fb9  vmovaps xmm9, [rsp+0x80]
00007981ddfe1fc2  vmovaps xmm10, [rsp+0x90]
00007981ddfe1fcb  vmovaps xmm11, [rsp+0xA0]
00007981ddfe1fd4  vmovaps xmm12, [rsp+0xB0]
00007981ddfe1fdd  vmovaps xmm13, [rsp+0xC0]
00007981ddfe1fe6  vmovaps xmm14, [rsp+0xD0]
00007981ddfe1fef  vmovaps xmm15, [rsp+0xE0]
00007981ddfe1ff8  add rsp, 0xF0
00007981ddfe1fff  pop r11
00007981ddfe2001  pop r10
00007981ddfe2003  pop r9
00007981ddfe2005  pop r8
00007981ddfe2007  pop rsi
00007981ddfe2008  pop rdi
00007981ddfe2009  pop rdx
00007981ddfe200a  pop rcx
00007981ddfe200b  pop rax
00007981ddfe200c  add rsp, 0x08
00007981ddfe2010  jmp 0x00007981DDFDF4CE
00007981ddfe2015  sub rsp, 0x08
00007981ddfe2019  push rax
00007981ddfe201a  push rcx
00007981ddfe201b  push rdx
00007981ddfe201c  push rdi
00007981ddfe201d  push rsi
00007981ddfe201e  push r8
00007981ddfe2020  push r9
00007981ddfe2022  push r10
00007981ddfe2024  push r11
00007981ddfe2026  sub rsp, 0xF0
00007981ddfe202d  vmovaps [rsp], xmm0
00007981ddfe2032  vmovaps [rsp+0x10], xmm1
00007981ddfe2038  vmovaps [rsp+0x20], xmm2
00007981ddfe203e  vmovaps [rsp+0x30], xmm3
00007981ddfe2044  vmovaps [rsp+0x40], xmm5
00007981ddfe204a  vmovaps [rsp+0x50], xmm6
00007981ddfe2050  vmovaps [rsp+0x60], xmm7
00007981ddfe2056  vmovaps [rsp+0x70], xmm8
00007981ddfe205c  vmovaps [rsp+0x80], xmm9
00007981ddfe2065  vmovaps [rsp+0x90], xmm10
00007981ddfe206e  vmovaps [rsp+0xA0], xmm11
00007981ddfe2077  vmovaps [rsp+0xB0], xmm12
00007981ddfe2080  vmovaps [rsp+0xC0], xmm13
00007981ddfe2089  vmovaps [rsp+0xD0], xmm14
00007981ddfe2092  vmovaps [rsp+0xE0], xmm15
00007981ddfe209b  sub rsp, 0x30
00007981ddfe209f  movaps [rsp], xmm4
00007981ddfe20a3  movaps [rsp+0x10], xmm2
00007981ddfe20a8  movaps [rsp+0x20], xmm9
00007981ddfe20ae  lea rdi, [rsp]
00007981ddfe20b2  mov esi, 0x00
00007981ddfe20b7  mov rax, 0x5782A6EB3530
00007981ddfe20c1  call rax
00007981ddfe20c3  movaps xmm4, [rsp]
00007981ddfe20c7  add rsp, 0x30
00007981ddfe20cb  vmovaps xmm0, [rsp]
00007981ddfe20d0  vmovaps xmm1, [rsp+0x10]
00007981ddfe20d6  vmovaps xmm2, [rsp+0x20]
00007981ddfe20dc  vmovaps xmm3, [rsp+0x30]
00007981ddfe20e2  vmovaps xmm5, [rsp+0x40]
00007981ddfe20e8  vmovaps xmm6, [rsp+0x50]
00007981ddfe20ee  vmovaps xmm7, [rsp+0x60]
00007981ddfe20f4  vmovaps xmm8, [rsp+0x70]
00007981ddfe20fa  vmovaps xmm9, [rsp+0x80]
00007981ddfe2103  vmovaps xmm10, [rsp+0x90]
00007981ddfe210c  vmovaps xmm11, [rsp+0xA0]
00007981ddfe2115  vmovaps xmm12, [rsp+0xB0]
00007981ddfe211e  vmovaps xmm13, [rsp+0xC0]
00007981ddfe2127  vmovaps xmm14, [rsp+0xD0]
00007981ddfe2130  vmovaps xmm15, [rsp+0xE0]
00007981ddfe2139  add rsp, 0xF0
00007981ddfe2140  pop r11
00007981ddfe2142  pop r10
00007981ddfe2144  pop r9
00007981ddfe2146  pop r8
00007981ddfe2148  pop rsi
00007981ddfe2149  pop rdi
00007981ddfe214a  pop rdx
00007981ddfe214b  pop rcx
00007981ddfe214c  pop rax
00007981ddfe214d  add rsp, 0x08
00007981ddfe2151  jmp 0x00007981DDFDF4FE
00007981ddfe2156  sub rsp, 0x08
00007981ddfe215a  push rax
00007981ddfe215b  push rcx
00007981ddfe215c  push rdx
00007981ddfe215d  push rdi
00007981ddfe215e  push rsi
00007981ddfe215f  push r8
00007981ddfe2161  push r9
00007981ddfe2163  push r10
00007981ddfe2165  push r11
00007981ddfe2167  sub rsp, 0xF0
00007981ddfe216e  vmovaps [rsp], xmm0
00007981ddfe2173  vmovaps [rsp+0x10], xmm1
00007981ddfe2179  vmovaps [rsp+0x20], xmm2
00007981ddfe217f  vmovaps [rsp+0x30], xmm3
00007981ddfe2185  vmovaps [rsp+0x40], xmm4
00007981ddfe218b  vmovaps [rsp+0x50], xmm5
00007981ddfe2191  vmovaps [rsp+0x60], xmm6
00007981ddfe2197  vmovaps [rsp+0x70], xmm7
00007981ddfe219d  vmovaps [rsp+0x80], xmm8
00007981ddfe21a6  vmovaps [rsp+0x90], xmm10
00007981ddfe21af  vmovaps [rsp+0xA0], xmm11
00007981ddfe21b8  vmovaps [rsp+0xB0], xmm12
00007981ddfe21c1  vmovaps [rsp+0xC0], xmm13
00007981ddfe21ca  vmovaps [rsp+0xD0], xmm14
00007981ddfe21d3  vmovaps [rsp+0xE0], xmm15
00007981ddfe21dc  sub rsp, 0x30
00007981ddfe21e0  movaps [rsp], xmm9
00007981ddfe21e5  movaps [rsp+0x10], xmm2
00007981ddfe21ea  movaps [rsp+0x20], xmm1
00007981ddfe21ef  lea rdi, [rsp]
00007981ddfe21f3  mov esi, 0x00
00007981ddfe21f8  mov rax, 0x5782A6EB3530
00007981ddfe2202  call rax
00007981ddfe2204  movaps xmm9, [rsp]
00007981ddfe2209  add rsp, 0x30
00007981ddfe220d  vmovaps xmm0, [rsp]
00007981ddfe2212  vmovaps xmm1, [rsp+0x10]
00007981ddfe2218  vmovaps xmm2, [rsp+0x20]
00007981ddfe221e  vmovaps xmm3, [rsp+0x30]
00007981ddfe2224  vmovaps xmm4, [rsp+0x40]
00007981ddfe222a  vmovaps xmm5, [rsp+0x50]
00007981ddfe2230  vmovaps xmm6, [rsp+0x60]
00007981ddfe2236  vmovaps xmm7, [rsp+0x70]
00007981ddfe223c  vmovaps xmm8, [rsp+0x80]
00007981ddfe2245  vmovaps xmm10, [rsp+0x90]
00007981ddfe224e  vmovaps xmm11, [rsp+0xA0]
00007981ddfe2257  vmovaps xmm12, [rsp+0xB0]
00007981ddfe2260  vmovaps xmm13, [rsp+0xC0]
00007981ddfe2269  vmovaps xmm14, [rsp+0xD0]
00007981ddfe2272  vmovaps xmm15, [rsp+0xE0]
00007981ddfe227b  add rsp, 0xF0
00007981ddfe2282  pop r11
00007981ddfe2284  pop r10
00007981ddfe2286  pop r9
00007981ddfe2288  pop r8
00007981ddfe228a  pop rsi
00007981ddfe228b  pop rdi
00007981ddfe228c  pop rdx
00007981ddfe228d  pop rcx
00007981ddfe228e  pop rax
00007981ddfe228f  add rsp, 0x08
00007981ddfe2293  jmp 0x00007981DDFDF534
00007981ddfe2298  sub rsp, 0x08
00007981ddfe229c  push rax
00007981ddfe229d  push rcx
00007981ddfe229e  push rdx
00007981ddfe229f  push rdi
00007981ddfe22a0  push rsi
00007981ddfe22a1  push r8
00007981ddfe22a3  push r9
00007981ddfe22a5  push r10
00007981ddfe22a7  push r11
00007981ddfe22a9  sub rsp, 0xF0
00007981ddfe22b0  vmovaps [rsp], xmm0
00007981ddfe22b5  vmovaps [rsp+0x10], xmm2
00007981ddfe22bb  vmovaps [rsp+0x20], xmm3
00007981ddfe22c1  vmovaps [rsp+0x30], xmm4
00007981ddfe22c7  vmovaps [rsp+0x40], xmm5
00007981ddfe22cd  vmovaps [rsp+0x50], xmm6
00007981ddfe22d3  vmovaps [rsp+0x60], xmm7
00007981ddfe22d9  vmovaps [rsp+0x70], xmm8
00007981ddfe22df  vmovaps [rsp+0x80], xmm9
00007981ddfe22e8  vmovaps [rsp+0x90], xmm10
00007981ddfe22f1  vmovaps [rsp+0xA0], xmm11
00007981ddfe22fa  vmovaps [rsp+0xB0], xmm12
00007981ddfe2303  vmovaps [rsp+0xC0], xmm13
00007981ddfe230c  vmovaps [rsp+0xD0], xmm14
00007981ddfe2315  vmovaps [rsp+0xE0], xmm15
00007981ddfe231e  sub rsp, 0x30
00007981ddfe2322  movaps [rsp], xmm1
00007981ddfe2326  movaps [rsp+0x10], xmm15
00007981ddfe232c  movaps [rsp+0x20], xmm6
00007981ddfe2331  lea rdi, [rsp]
00007981ddfe2335  mov esi, 0x00
00007981ddfe233a  mov rax, 0x5782A6EB3530
00007981ddfe2344  call rax
00007981ddfe2346  movaps xmm1, [rsp]
00007981ddfe234a  add rsp, 0x30
00007981ddfe234e  vmovaps xmm0, [rsp]
00007981ddfe2353  vmovaps xmm2, [rsp+0x10]
00007981ddfe2359  vmovaps xmm3, [rsp+0x20]
00007981ddfe235f  vmovaps xmm4, [rsp+0x30]
00007981ddfe2365  vmovaps xmm5, [rsp+0x40]
00007981ddfe236b  vmovaps xmm6, [rsp+0x50]
00007981ddfe2371  vmovaps xmm7, [rsp+0x60]
00007981ddfe2377  vmovaps xmm8, [rsp+0x70]
00007981ddfe237d  vmovaps xmm9, [rsp+0x80]
00007981ddfe2386  vmovaps xmm10, [rsp+0x90]
00007981ddfe238f  vmovaps xmm11, [rsp+0xA0]
00007981ddfe2398  vmovaps xmm12, [rsp+0xB0]
00007981ddfe23a1  vmovaps xmm13, [rsp+0xC0]
00007981ddfe23aa  vmovaps xmm14, [rsp+0xD0]
00007981ddfe23b3  vmovaps xmm15, [rsp+0xE0]
00007981ddfe23bc  add rsp, 0xF0
00007981ddfe23c3  pop r11
00007981ddfe23c5  pop r10
00007981ddfe23c7  pop r9
00007981ddfe23c9  pop r8
00007981ddfe23cb  pop rsi
00007981ddfe23cc  pop rdi
00007981ddfe23cd  pop rdx
00007981ddfe23ce  pop rcx
00007981ddfe23cf  pop rax
00007981ddfe23d0  add rsp, 0x08
00007981ddfe23d4  jmp 0x00007981DDFDF555
00007981ddfe23d9  sub rsp, 0x08
00007981ddfe23dd  push rax
00007981ddfe23de  push rcx
00007981ddfe23df  push rdx
00007981ddfe23e0  push rdi
00007981ddfe23e1  push rsi
00007981ddfe23e2  push r8
00007981ddfe23e4  push r9
00007981ddfe23e6  push r10
00007981ddfe23e8  push r11
00007981ddfe23ea  sub rsp, 0xF0
00007981ddfe23f1  vmovaps [rsp], xmm0
00007981ddfe23f6  vmovaps [rsp+0x10], xmm1
00007981ddfe23fc  vmovaps [rsp+0x20], xmm2
00007981ddfe2402  vmovaps [rsp+0x30], xmm3
00007981ddfe2408  vmovaps [rsp+0x40], xmm4
00007981ddfe240e  vmovaps [rsp+0x50], xmm5
00007981ddfe2414  vmovaps [rsp+0x60], xmm6
00007981ddfe241a  vmovaps [rsp+0x70], xmm7
00007981ddfe2420  vmovaps [rsp+0x80], xmm8
00007981ddfe2429  vmovaps [rsp+0x90], xmm9
00007981ddfe2432  vmovaps [rsp+0xA0], xmm10
00007981ddfe243b  vmovaps [rsp+0xB0], xmm11
00007981ddfe2444  vmovaps [rsp+0xC0], xmm12
00007981ddfe244d  vmovaps [rsp+0xD0], xmm13
00007981ddfe2456  vmovaps [rsp+0xE0], xmm14
00007981ddfe245f  sub rsp, 0x30
00007981ddfe2463  movaps [rsp], xmm15
00007981ddfe2468  movaps [rsp+0x10], xmm5
00007981ddfe246d  movaps [rsp+0x20], xmm3
00007981ddfe2472  lea rdi, [rsp]
00007981ddfe2476  mov esi, 0x00
00007981ddfe247b  mov rax, 0x5782A6EB3530
00007981ddfe2485  call rax
00007981ddfe2487  movaps xmm15, [rsp]
00007981ddfe248c  add rsp, 0x30
00007981ddfe2490  vmovaps xmm0, [rsp]
00007981ddfe2495  vmovaps xmm1, [rsp+0x10]
00007981ddfe249b  vmovaps xmm2, [rsp+0x20]
00007981ddfe24a1  vmovaps xmm3, [rsp+0x30]
00007981ddfe24a7  vmovaps xmm4, [rsp+0x40]
00007981ddfe24ad  vmovaps xmm5, [rsp+0x50]
00007981ddfe24b3  vmovaps xmm6, [rsp+0x60]
00007981ddfe24b9  vmovaps xmm7, [rsp+0x70]
00007981ddfe24bf  vmovaps xmm8, [rsp+0x80]
00007981ddfe24c8  vmovaps xmm9, [rsp+0x90]
00007981ddfe24d1  vmovaps xmm10, [rsp+0xA0]
00007981ddfe24da  vmovaps xmm11, [rsp+0xB0]
00007981ddfe24e3  vmovaps xmm12, [rsp+0xC0]
00007981ddfe24ec  vmovaps xmm13, [rsp+0xD0]
00007981ddfe24f5  vmovaps xmm14, [rsp+0xE0]
00007981ddfe24fe  add rsp, 0xF0
00007981ddfe2505  pop r11
00007981ddfe2507  pop r10
00007981ddfe2509  pop r9
00007981ddfe250b  pop r8
00007981ddfe250d  pop rsi
00007981ddfe250e  pop rdi
00007981ddfe250f  pop rdx
00007981ddfe2510  pop rcx
00007981ddfe2511  pop rax
00007981ddfe2512  add rsp, 0x08
00007981ddfe2516  jmp 0x00007981DDFDF56F
00007981ddfe251b  sub rsp, 0x08
00007981ddfe251f  push rax
00007981ddfe2520  push rcx
00007981ddfe2521  push rdx
00007981ddfe2522  push rdi
00007981ddfe2523  push rsi
00007981ddfe2524  push r8
00007981ddfe2526  push r9
00007981ddfe2528  push r10
00007981ddfe252a  push r11
00007981ddfe252c  sub rsp, 0xF0
00007981ddfe2533  vmovaps [rsp], xmm0
00007981ddfe2538  vmovaps [rsp+0x10], xmm1
00007981ddfe253e  vmovaps [rsp+0x20], xmm2
00007981ddfe2544  vmovaps [rsp+0x30], xmm3
00007981ddfe254a  vmovaps [rsp+0x40], xmm4
00007981ddfe2550  vmovaps [rsp+0x50], xmm6
00007981ddfe2556  vmovaps [rsp+0x60], xmm7
00007981ddfe255c  vmovaps [rsp+0x70], xmm8
00007981ddfe2562  vmovaps [rsp+0x80], xmm9
00007981ddfe256b  vmovaps [rsp+0x90], xmm10
00007981ddfe2574  vmovaps [rsp+0xA0], xmm11
00007981ddfe257d  vmovaps [rsp+0xB0], xmm12
00007981ddfe2586  vmovaps [rsp+0xC0], xmm13
00007981ddfe258f  vmovaps [rsp+0xD0], xmm14
00007981ddfe2598  vmovaps [rsp+0xE0], xmm15
00007981ddfe25a1  sub rsp, 0x30
00007981ddfe25a5  movaps [rsp], xmm5
00007981ddfe25a9  movaps [rsp+0x10], xmm8
00007981ddfe25af  movaps [rsp+0x20], xmm6
00007981ddfe25b4  lea rdi, [rsp]
00007981ddfe25b8  mov esi, 0x00
00007981ddfe25bd  mov rax, 0x5782A6EB3530
00007981ddfe25c7  call rax
00007981ddfe25c9  movaps xmm5, [rsp]
00007981ddfe25cd  add rsp, 0x30
00007981ddfe25d1  vmovaps xmm0, [rsp]
00007981ddfe25d6  vmovaps xmm1, [rsp+0x10]
00007981ddfe25dc  vmovaps xmm2, [rsp+0x20]
00007981ddfe25e2  vmovaps xmm3, [rsp+0x30]
00007981ddfe25e8  vmovaps xmm4, [rsp+0x40]
00007981ddfe25ee  vmovaps xmm6, [rsp+0x50]
00007981ddfe25f4  vmovaps xmm7, [rsp+0x60]
00007981ddfe25fa  vmovaps xmm8, [rsp+0x70]
00007981ddfe2600  vmovaps xmm9, [rsp+0x80]
00007981ddfe2609  vmovaps xmm10, [rsp+0x90]
00007981ddfe2612  vmovaps xmm11, [rsp+0xA0]
00007981ddfe261b  vmovaps xmm12, [rsp+0xB0]
00007981ddfe2624  vmovaps xmm13, [rsp+0xC0]
00007981ddfe262d  vmovaps xmm14, [rsp+0xD0]
00007981ddfe2636  vmovaps xmm15, [rsp+0xE0]
00007981ddfe263f  add rsp, 0xF0
00007981ddfe2646  pop r11
00007981ddfe2648  pop r10
00007981ddfe264a  pop r9
00007981ddfe264c  pop r8
00007981ddfe264e  pop rsi
00007981ddfe264f  pop rdi
00007981ddfe2650  pop rdx
00007981ddfe2651  pop rcx
00007981ddfe2652  pop rax
00007981ddfe2653  add rsp, 0x08
00007981ddfe2657  jmp 0x00007981DDFDF593
00007981ddfe265c  sub rsp, 0x08
00007981ddfe2660  push rax
00007981ddfe2661  push rcx
00007981ddfe2662  push rdx
00007981ddfe2663  push rdi
00007981ddfe2664  push rsi
00007981ddfe2665  push r8
00007981ddfe2667  push r9
00007981ddfe2669  push r10
00007981ddfe266b  push r11
00007981ddfe266d  sub rsp, 0xF0
00007981ddfe2674  vmovaps [rsp], xmm0
00007981ddfe2679  vmovaps [rsp+0x10], xmm1
00007981ddfe267f  vmovaps [rsp+0x20], xmm2
00007981ddfe2685  vmovaps [rsp+0x30], xmm3
00007981ddfe268b  vmovaps [rsp+0x40], xmm4
00007981ddfe2691  vmovaps [rsp+0x50], xmm5
00007981ddfe2697  vmovaps [rsp+0x60], xmm7
00007981ddfe269d  vmovaps [rsp+0x70], xmm8
00007981ddfe26a3  vmovaps [rsp+0x80], xmm9
00007981ddfe26ac  vmovaps [rsp+0x90], xmm10
00007981ddfe26b5  vmovaps [rsp+0xA0], xmm11
00007981ddfe26be  vmovaps [rsp+0xB0], xmm12
00007981ddfe26c7  vmovaps [rsp+0xC0], xmm13
00007981ddfe26d0  vmovaps [rsp+0xD0], xmm14
00007981ddfe26d9  vmovaps [rsp+0xE0], xmm15
00007981ddfe26e2  sub rsp, 0x30
00007981ddfe26e6  movaps [rsp], xmm6
00007981ddfe26ea  movaps [rsp+0x10], xmm10
00007981ddfe26f0  movaps [rsp+0x20], xmm8
00007981ddfe26f6  lea rdi, [rsp]
00007981ddfe26fa  mov esi, 0x00
00007981ddfe26ff  mov rax, 0x5782A6EB3530
00007981ddfe2709  call rax
00007981ddfe270b  movaps xmm6, [rsp]
00007981ddfe270f  add rsp, 0x30
00007981ddfe2713  vmovaps xmm0, [rsp]
00007981ddfe2718  vmovaps xmm1, [rsp+0x10]
00007981ddfe271e  vmovaps xmm2, [rsp+0x20]
00007981ddfe2724  vmovaps xmm3, [rsp+0x30]
00007981ddfe272a  vmovaps xmm4, [rsp+0x40]
00007981ddfe2730  vmovaps xmm5, [rsp+0x50]
00007981ddfe2736  vmovaps xmm7, [rsp+0x60]
00007981ddfe273c  vmovaps xmm8, [rsp+0x70]
00007981ddfe2742  vmovaps xmm9, [rsp+0x80]
00007981ddfe274b  vmovaps xmm10, [rsp+0x90]
00007981ddfe2754  vmovaps xmm11, [rsp+0xA0]
00007981ddfe275d  vmovaps xmm12, [rsp+0xB0]
00007981ddfe2766  vmovaps xmm13, [rsp+0xC0]
00007981ddfe276f  vmovaps xmm14, [rsp+0xD0]
00007981ddfe2778  vmovaps xmm15, [rsp+0xE0]
00007981ddfe2781  add rsp, 0xF0
00007981ddfe2788  pop r11
00007981ddfe278a  pop r10
00007981ddfe278c  pop r9
00007981ddfe278e  pop r8
00007981ddfe2790  pop rsi
00007981ddfe2791  pop rdi
00007981ddfe2792  pop rdx
00007981ddfe2793  pop rcx
00007981ddfe2794  pop rax
00007981ddfe2795  add rsp, 0x08
00007981ddfe2799  jmp 0x00007981DDFDF5B8
00007981ddfe279e  sub rsp, 0x08
00007981ddfe27a2  push rax
00007981ddfe27a3  push rcx
00007981ddfe27a4  push rdx
00007981ddfe27a5  push rdi
00007981ddfe27a6  push rsi
00007981ddfe27a7  push r8
00007981ddfe27a9  push r9
00007981ddfe27ab  push r10
00007981ddfe27ad  push r11
00007981ddfe27af  sub rsp, 0xF0
00007981ddfe27b6  vmovaps [rsp], xmm0
00007981ddfe27bb  vmovaps [rsp+0x10], xmm1
00007981ddfe27c1  vmovaps [rsp+0x20], xmm2
00007981ddfe27c7  vmovaps [rsp+0x30], xmm3
00007981ddfe27cd  vmovaps [rsp+0x40], xmm4
00007981ddfe27d3  vmovaps [rsp+0x50], xmm5
00007981ddfe27d9  vmovaps [rsp+0x60], xmm6
00007981ddfe27df  vmovaps [rsp+0x70], xmm7
00007981ddfe27e5  vmovaps [rsp+0x80], xmm8
00007981ddfe27ee  vmovaps [rsp+0x90], xmm9
00007981ddfe27f7  vmovaps [rsp+0xA0], xmm11
00007981ddfe2800  vmovaps [rsp+0xB0], xmm12
00007981ddfe2809  vmovaps [rsp+0xC0], xmm13
00007981ddfe2812  vmovaps [rsp+0xD0], xmm14
00007981ddfe281b  vmovaps [rsp+0xE0], xmm15
00007981ddfe2824  sub rsp, 0x30
00007981ddfe2828  movaps [rsp], xmm10
00007981ddfe282d  movaps [rsp+0x10], xmm8
00007981ddfe2833  movaps [rsp+0x20], xmm14
00007981ddfe2839  lea rdi, [rsp]
00007981ddfe283d  mov esi, 0x00
00007981ddfe2842  mov rax, 0x5782A6EB3530
00007981ddfe284c  call rax
00007981ddfe284e  movaps xmm10, [rsp]
00007981ddfe2853  add rsp, 0x30
00007981ddfe2857  vmovaps xmm0, [rsp]
00007981ddfe285c  vmovaps xmm1, [rsp+0x10]
00007981ddfe2862  vmovaps xmm2, [rsp+0x20]
00007981ddfe2868  vmovaps xmm3, [rsp+0x30]
00007981ddfe286e  vmovaps xmm4, [rsp+0x40]
00007981ddfe2874  vmovaps xmm5, [rsp+0x50]
00007981ddfe287a  vmovaps xmm6, [rsp+0x60]
00007981ddfe2880  vmovaps xmm7, [rsp+0x70]
00007981ddfe2886  vmovaps xmm8, [rsp+0x80]
00007981ddfe288f  vmovaps xmm9, [rsp+0x90]
00007981ddfe2898  vmovaps xmm11, [rsp+0xA0]
00007981ddfe28a1  vmovaps xmm12, [rsp+0xB0]
00007981ddfe28aa  vmovaps xmm13, [rsp+0xC0]
00007981ddfe28b3  vmovaps xmm14, [rsp+0xD0]
00007981ddfe28bc  vmovaps xmm15, [rsp+0xE0]
00007981ddfe28c5  add rsp, 0xF0
00007981ddfe28cc  pop r11
00007981ddfe28ce  pop r10
00007981ddfe28d0  pop r9
00007981ddfe28d2  pop r8
00007981ddfe28d4  pop rsi
00007981ddfe28d5  pop rdi
00007981ddfe28d6  pop rdx
00007981ddfe28d7  pop rcx
00007981ddfe28d8  pop rax
00007981ddfe28d9  add rsp, 0x08
00007981ddfe28dd  jmp 0x00007981DDFDF5D8
00007981ddfe28e2  sub rsp, 0x08
00007981ddfe28e6  push rax
00007981ddfe28e7  push rcx
00007981ddfe28e8  push rdx
00007981ddfe28e9  push rdi
00007981ddfe28ea  push rsi
00007981ddfe28eb  push r8
00007981ddfe28ed  push r9
00007981ddfe28ef  push r10
00007981ddfe28f1  push r11
00007981ddfe28f3  sub rsp, 0xF0
00007981ddfe28fa  vmovaps [rsp], xmm0
00007981ddfe28ff  vmovaps [rsp+0x10], xmm1
00007981ddfe2905  vmovaps [rsp+0x20], xmm2
00007981ddfe290b  vmovaps [rsp+0x30], xmm3
00007981ddfe2911  vmovaps [rsp+0x40], xmm4
00007981ddfe2917  vmovaps [rsp+0x50], xmm5
00007981ddfe291d  vmovaps [rsp+0x60], xmm6
00007981ddfe2923  vmovaps [rsp+0x70], xmm7
00007981ddfe2929  vmovaps [rsp+0x80], xmm8
00007981ddfe2932  vmovaps [rsp+0x90], xmm9
00007981ddfe293b  vmovaps [rsp+0xA0], xmm10
00007981ddfe2944  vmovaps [rsp+0xB0], xmm11
00007981ddfe294d  vmovaps [rsp+0xC0], xmm12
00007981ddfe2956  vmovaps [rsp+0xD0], xmm13
00007981ddfe295f  vmovaps [rsp+0xE0], xmm15
00007981ddfe2968  sub rsp, 0x30
00007981ddfe296c  movaps [rsp], xmm14
00007981ddfe2971  movaps [rsp+0x10], xmm8
00007981ddfe2977  movaps [rsp+0x20], xmm4
00007981ddfe297c  lea rdi, [rsp]
00007981ddfe2980  mov esi, 0x00
00007981ddfe2985  mov rax, 0x5782A6EB3530
00007981ddfe298f  call rax
00007981ddfe2991  movaps xmm14, [rsp]
00007981ddfe2996  add rsp, 0x30
00007981ddfe299a  vmovaps xmm0, [rsp]
00007981ddfe299f  vmovaps xmm1, [rsp+0x10]
00007981ddfe29a5  vmovaps xmm2, [rsp+0x20]
00007981ddfe29ab  vmovaps xmm3, [rsp+0x30]
00007981ddfe29b1  vmovaps xmm4, [rsp+0x40]
00007981ddfe29b7  vmovaps xmm5, [rsp+0x50]
00007981ddfe29bd  vmovaps xmm6, [rsp+0x60]
00007981ddfe29c3  vmovaps xmm7, [rsp+0x70]
00007981ddfe29c9  vmovaps xmm8, [rsp+0x80]
00007981ddfe29d2  vmovaps xmm9, [rsp+0x90]
00007981ddfe29db  vmovaps xmm10, [rsp+0xA0]
00007981ddfe29e4  vmovaps xmm11, [rsp+0xB0]
00007981ddfe29ed  vmovaps xmm12, [rsp+0xC0]
00007981ddfe29f6  vmovaps xmm13, [rsp+0xD0]
00007981ddfe29ff  vmovaps xmm15, [rsp+0xE0]
00007981ddfe2a08  add rsp, 0xF0
00007981ddfe2a0f  pop r11
00007981ddfe2a11  pop r10
00007981ddfe2a13  pop r9
00007981ddfe2a15  pop r8
00007981ddfe2a17  pop rsi
00007981ddfe2a18  pop rdi
00007981ddfe2a19  pop rdx
00007981ddfe2a1a  pop rcx
00007981ddfe2a1b  pop rax
00007981ddfe2a1c  add rsp, 0x08
00007981ddfe2a20  jmp 0x00007981DDFDF5F8
00007981ddfe2a25  sub rsp, 0x08
00007981ddfe2a29  push rax
00007981ddfe2a2a  push rcx
00007981ddfe2a2b  push rdx
00007981ddfe2a2c  push rdi
00007981ddfe2a2d  push rsi
00007981ddfe2a2e  push r8
00007981ddfe2a30  push r9
00007981ddfe2a32  push r10
00007981ddfe2a34  push r11
00007981ddfe2a36  sub rsp, 0xF0
00007981ddfe2a3d  vmovaps [rsp], xmm0
00007981ddfe2a42  vmovaps [rsp+0x10], xmm1
00007981ddfe2a48  vmovaps [rsp+0x20], xmm2
00007981ddfe2a4e  vmovaps [rsp+0x30], xmm3
00007981ddfe2a54  vmovaps [rsp+0x40], xmm5
00007981ddfe2a5a  vmovaps [rsp+0x50], xmm6
00007981ddfe2a60  vmovaps [rsp+0x60], xmm7
00007981ddfe2a66  vmovaps [rsp+0x70], xmm8
00007981ddfe2a6c  vmovaps [rsp+0x80], xmm9
00007981ddfe2a75  vmovaps [rsp+0x90], xmm10
00007981ddfe2a7e  vmovaps [rsp+0xA0], xmm11
00007981ddfe2a87  vmovaps [rsp+0xB0], xmm12
00007981ddfe2a90  vmovaps [rsp+0xC0], xmm13
00007981ddfe2a99  vmovaps [rsp+0xD0], xmm14
00007981ddfe2aa2  vmovaps [rsp+0xE0], xmm15
00007981ddfe2aab  sub rsp, 0x30
00007981ddfe2aaf  movaps [rsp], xmm4
00007981ddfe2ab3  movaps [rsp+0x10], xmm13
00007981ddfe2ab9  movaps [rsp+0x20], xmm8
00007981ddfe2abf  lea rdi, [rsp]
00007981ddfe2ac3  mov esi, 0x00
00007981ddfe2ac8  mov rax, 0x5782A6EB3530
00007981ddfe2ad2  call rax
00007981ddfe2ad4  movaps xmm4, [rsp]
00007981ddfe2ad8  add rsp, 0x30
00007981ddfe2adc  vmovaps xmm0, [rsp]
00007981ddfe2ae1  vmovaps xmm1, [rsp+0x10]
00007981ddfe2ae7  vmovaps xmm2, [rsp+0x20]
00007981ddfe2aed  vmovaps xmm3, [rsp+0x30]
00007981ddfe2af3  vmovaps xmm5, [rsp+0x40]
00007981ddfe2af9  vmovaps xmm6, [rsp+0x50]
00007981ddfe2aff  vmovaps xmm7, [rsp+0x60]
00007981ddfe2b05  vmovaps xmm8, [rsp+0x70]
00007981ddfe2b0b  vmovaps xmm9, [rsp+0x80]
00007981ddfe2b14  vmovaps xmm10, [rsp+0x90]
00007981ddfe2b1d  vmovaps xmm11, [rsp+0xA0]
00007981ddfe2b26  vmovaps xmm12, [rsp+0xB0]
00007981ddfe2b2f  vmovaps xmm13, [rsp+0xC0]
00007981ddfe2b38  vmovaps xmm14, [rsp+0xD0]
00007981ddfe2b41  vmovaps xmm15, [rsp+0xE0]
00007981ddfe2b4a  add rsp, 0xF0
00007981ddfe2b51  pop r11
00007981ddfe2b53  pop r10
00007981ddfe2b55  pop r9
00007981ddfe2b57  pop r8
00007981ddfe2b59  pop rsi
00007981ddfe2b5a  pop rdi
00007981ddfe2b5b  pop rdx
00007981ddfe2b5c  pop rcx
00007981ddfe2b5d  pop rax
00007981ddfe2b5e  add rsp, 0x08
00007981ddfe2b62  jmp 0x00007981DDFDF61D
00007981ddfe2b67  sub rsp, 0x08
00007981ddfe2b6b  push rax
00007981ddfe2b6c  push rcx
00007981ddfe2b6d  push rdx
00007981ddfe2b6e  push rdi
00007981ddfe2b6f  push rsi
00007981ddfe2b70  push r8
00007981ddfe2b72  push r9
00007981ddfe2b74  push r10
00007981ddfe2b76  push r11
00007981ddfe2b78  sub rsp, 0xF0
00007981ddfe2b7f  vmovaps [rsp], xmm0
00007981ddfe2b84  vmovaps [rsp+0x10], xmm1
00007981ddfe2b8a  vmovaps [rsp+0x20], xmm2
00007981ddfe2b90  vmovaps [rsp+0x30], xmm3
00007981ddfe2b96  vmovaps [rsp+0x40], xmm4
00007981ddfe2b9c  vmovaps [rsp+0x50], xmm5
00007981ddfe2ba2  vmovaps [rsp+0x60], xmm6
00007981ddfe2ba8  vmovaps [rsp+0x70], xmm7
00007981ddfe2bae  vmovaps [rsp+0x80], xmm8
00007981ddfe2bb7  vmovaps [rsp+0x90], xmm9
00007981ddfe2bc0  vmovaps [rsp+0xA0], xmm10
00007981ddfe2bc9  vmovaps [rsp+0xB0], xmm11
00007981ddfe2bd2  vmovaps [rsp+0xC0], xmm12
00007981ddfe2bdb  vmovaps [rsp+0xD0], xmm14
00007981ddfe2be4  vmovaps [rsp+0xE0], xmm15
00007981ddfe2bed  sub rsp, 0x30
00007981ddfe2bf1  movaps [rsp], xmm13
00007981ddfe2bf6  movaps [rsp+0x10], xmm15
00007981ddfe2bfc  movaps [rsp+0x20], xmm9
00007981ddfe2c02  lea rdi, [rsp]
00007981ddfe2c06  mov esi, 0x00
00007981ddfe2c0b  mov rax, 0x5782A6EB3530
00007981ddfe2c15  call rax
00007981ddfe2c17  movaps xmm13, [rsp]
00007981ddfe2c1c  add rsp, 0x30
00007981ddfe2c20  vmovaps xmm0, [rsp]
00007981ddfe2c25  vmovaps xmm1, [rsp+0x10]
00007981ddfe2c2b  vmovaps xmm2, [rsp+0x20]
00007981ddfe2c31  vmovaps xmm3, [rsp+0x30]
00007981ddfe2c37  vmovaps xmm4, [rsp+0x40]
00007981ddfe2c3d  vmovaps xmm5, [rsp+0x50]
00007981ddfe2c43  vmovaps xmm6, [rsp+0x60]
00007981ddfe2c49  vmovaps xmm7, [rsp+0x70]
00007981ddfe2c4f  vmovaps xmm8, [rsp+0x80]
00007981ddfe2c58  vmovaps xmm9, [rsp+0x90]
00007981ddfe2c61  vmovaps xmm10, [rsp+0xA0]
00007981ddfe2c6a  vmovaps xmm11, [rsp+0xB0]
00007981ddfe2c73  vmovaps xmm12, [rsp+0xC0]
00007981ddfe2c7c  vmovaps xmm14, [rsp+0xD0]
00007981ddfe2c85  vmovaps xmm15, [rsp+0xE0]
00007981ddfe2c8e  add rsp, 0xF0
00007981ddfe2c95  pop r11
00007981ddfe2c97  pop r10
00007981ddfe2c99  pop r9
00007981ddfe2c9b  pop r8
00007981ddfe2c9d  pop rsi
00007981ddfe2c9e  pop rdi
00007981ddfe2c9f  pop rdx
00007981ddfe2ca0  pop rcx
00007981ddfe2ca1  pop rax
00007981ddfe2ca2  add rsp, 0x08
00007981ddfe2ca6  jmp 0x00007981DDFDF638
00007981ddfe2cab  sub rsp, 0x08
00007981ddfe2caf  push rax
00007981ddfe2cb0  push rcx
00007981ddfe2cb1  push rdx
00007981ddfe2cb2  push rdi
00007981ddfe2cb3  push rsi
00007981ddfe2cb4  push r8
00007981ddfe2cb6  push r9
00007981ddfe2cb8  push r10
00007981ddfe2cba  push r11
00007981ddfe2cbc  sub rsp, 0xF0
00007981ddfe2cc3  vmovaps [rsp], xmm0
00007981ddfe2cc8  vmovaps [rsp+0x10], xmm1
00007981ddfe2cce  vmovaps [rsp+0x20], xmm2
00007981ddfe2cd4  vmovaps [rsp+0x30], xmm3
00007981ddfe2cda  vmovaps [rsp+0x40], xmm4
00007981ddfe2ce0  vmovaps [rsp+0x50], xmm5
00007981ddfe2ce6  vmovaps [rsp+0x60], xmm6
00007981ddfe2cec  vmovaps [rsp+0x70], xmm7
00007981ddfe2cf2  vmovaps [rsp+0x80], xmm8
00007981ddfe2cfb  vmovaps [rsp+0x90], xmm9
00007981ddfe2d04  vmovaps [rsp+0xA0], xmm10
00007981ddfe2d0d  vmovaps [rsp+0xB0], xmm11
00007981ddfe2d16  vmovaps [rsp+0xC0], xmm12
00007981ddfe2d1f  vmovaps [rsp+0xD0], xmm13
00007981ddfe2d28  vmovaps [rsp+0xE0], xmm14
00007981ddfe2d31  sub rsp, 0x30
00007981ddfe2d35  movaps [rsp], xmm15
00007981ddfe2d3a  movaps [rsp+0x10], xmm1
00007981ddfe2d3f  movaps [rsp+0x20], xmm5
00007981ddfe2d44  lea rdi, [rsp]
00007981ddfe2d48  mov esi, 0x00
00007981ddfe2d4d  mov rax, 0x5782A6EB3530
00007981ddfe2d57  call rax
00007981ddfe2d59  movaps xmm15, [rsp]
00007981ddfe2d5e  add rsp, 0x30
00007981ddfe2d62  vmovaps xmm0, [rsp]
00007981ddfe2d67  vmovaps xmm1, [rsp+0x10]
00007981ddfe2d6d  vmovaps xmm2, [rsp+0x20]
00007981ddfe2d73  vmovaps xmm3, [rsp+0x30]
00007981ddfe2d79  vmovaps xmm4, [rsp+0x40]
00007981ddfe2d7f  vmovaps xmm5, [rsp+0x50]
00007981ddfe2d85  vmovaps xmm6, [rsp+0x60]
00007981ddfe2d8b  vmovaps xmm7, [rsp+0x70]
00007981ddfe2d91  vmovaps xmm8, [rsp+0x80]
00007981ddfe2d9a  vmovaps xmm9, [rsp+0x90]
00007981ddfe2da3  vmovaps xmm10, [rsp+0xA0]
00007981ddfe2dac  vmovaps xmm11, [rsp+0xB0]
00007981ddfe2db5  vmovaps xmm12, [rsp+0xC0]
00007981ddfe2dbe  vmovaps xmm13, [rsp+0xD0]
00007981ddfe2dc7  vmovaps xmm14, [rsp+0xE0]
00007981ddfe2dd0  add rsp, 0xF0
00007981ddfe2dd7  pop r11
00007981ddfe2dd9  pop r10
00007981ddfe2ddb  pop r9
00007981ddfe2ddd  pop r8
00007981ddfe2ddf  pop rsi
00007981ddfe2de0  pop rdi
00007981ddfe2de1  pop rdx
00007981ddfe2de2  pop rcx
00007981ddfe2de3  pop rax
00007981ddfe2de4  add rsp, 0x08
00007981ddfe2de8  jmp 0x00007981DDFDF653
00007981ddfe2ded  call 0x00007981DDEB52F0
00007981ddfe2df2  jmp 0x00007981DDFDF6AE
00007981ddfe2df7  sub rsp, 0x08
00007981ddfe2dfb  push rax
00007981ddfe2dfc  push rcx
00007981ddfe2dfd  push rdx
00007981ddfe2dfe  push rdi
00007981ddfe2dff  push rsi
00007981ddfe2e00  push r8
00007981ddfe2e02  push r9
00007981ddfe2e04  push r10
00007981ddfe2e06  push r11
00007981ddfe2e08  sub rsp, 0xF0
00007981ddfe2e0f  vmovaps [rsp], xmm0
00007981ddfe2e14  vmovaps [rsp+0x10], xmm1
00007981ddfe2e1a  vmovaps [rsp+0x20], xmm2
00007981ddfe2e20  vmovaps [rsp+0x30], xmm3
00007981ddfe2e26  vmovaps [rsp+0x40], xmm4
00007981ddfe2e2c  vmovaps [rsp+0x50], xmm5
00007981ddfe2e32  vmovaps [rsp+0x60], xmm6
00007981ddfe2e38  vmovaps [rsp+0x70], xmm7
00007981ddfe2e3e  vmovaps [rsp+0x80], xmm8
00007981ddfe2e47  vmovaps [rsp+0x90], xmm10
00007981ddfe2e50  vmovaps [rsp+0xA0], xmm11
00007981ddfe2e59  vmovaps [rsp+0xB0], xmm12
00007981ddfe2e62  vmovaps [rsp+0xC0], xmm13
00007981ddfe2e6b  vmovaps [rsp+0xD0], xmm14
00007981ddfe2e74  vmovaps [rsp+0xE0], xmm15
00007981ddfe2e7d  sub rsp, 0x30
00007981ddfe2e81  movaps [rsp], xmm9
00007981ddfe2e86  movaps [rsp+0x10], xmm8
00007981ddfe2e8c  movaps [rsp+0x20], xmm11
00007981ddfe2e92  lea rdi, [rsp]
00007981ddfe2e96  mov esi, 0x00
00007981ddfe2e9b  mov rax, 0x5782A6EB3530
00007981ddfe2ea5  call rax
00007981ddfe2ea7  movaps xmm9, [rsp]
00007981ddfe2eac  add rsp, 0x30
00007981ddfe2eb0  vmovaps xmm0, [rsp]
00007981ddfe2eb5  vmovaps xmm1, [rsp+0x10]
00007981ddfe2ebb  vmovaps xmm2, [rsp+0x20]
00007981ddfe2ec1  vmovaps xmm3, [rsp+0x30]
00007981ddfe2ec7  vmovaps xmm4, [rsp+0x40]
00007981ddfe2ecd  vmovaps xmm5, [rsp+0x50]
00007981ddfe2ed3  vmovaps xmm6, [rsp+0x60]
00007981ddfe2ed9  vmovaps xmm7, [rsp+0x70]
00007981ddfe2edf  vmovaps xmm8, [rsp+0x80]
00007981ddfe2ee8  vmovaps xmm10, [rsp+0x90]
00007981ddfe2ef1  vmovaps xmm11, [rsp+0xA0]
00007981ddfe2efa  vmovaps xmm12, [rsp+0xB0]
00007981ddfe2f03  vmovaps xmm13, [rsp+0xC0]
00007981ddfe2f0c  vmovaps xmm14, [rsp+0xD0]
00007981ddfe2f15  vmovaps xmm15, [rsp+0xE0]
00007981ddfe2f1e  add rsp, 0xF0
00007981ddfe2f25  pop r11
00007981ddfe2f27  pop r10
00007981ddfe2f29  pop r9
00007981ddfe2f2b  pop r8
00007981ddfe2f2d  pop rsi
00007981ddfe2f2e  pop rdi
00007981ddfe2f2f  pop rdx
00007981ddfe2f30  pop rcx
00007981ddfe2f31  pop rax
00007981ddfe2f32  add rsp, 0x08
00007981ddfe2f36  jmp 0x00007981DDFDF6E5
00007981ddfe2f3b  sub rsp, 0x08
00007981ddfe2f3f  push rax
00007981ddfe2f40  push rcx
00007981ddfe2f41  push rdx
00007981ddfe2f42  push rdi
00007981ddfe2f43  push rsi
00007981ddfe2f44  push r8
00007981ddfe2f46  push r9
00007981ddfe2f48  push r10
00007981ddfe2f4a  push r11
00007981ddfe2f4c  sub rsp, 0xF0
00007981ddfe2f53  vmovaps [rsp], xmm0
00007981ddfe2f58  vmovaps [rsp+0x10], xmm1
00007981ddfe2f5e  vmovaps [rsp+0x20], xmm2
00007981ddfe2f64  vmovaps [rsp+0x30], xmm3
00007981ddfe2f6a  vmovaps [rsp+0x40], xmm4
00007981ddfe2f70  vmovaps [rsp+0x50], xmm5
00007981ddfe2f76  vmovaps [rsp+0x60], xmm6
00007981ddfe2f7c  vmovaps [rsp+0x70], xmm7
00007981ddfe2f82  vmovaps [rsp+0x80], xmm8
00007981ddfe2f8b  vmovaps [rsp+0x90], xmm9
00007981ddfe2f94  vmovaps [rsp+0xA0], xmm10
00007981ddfe2f9d  vmovaps [rsp+0xB0], xmm12
00007981ddfe2fa6  vmovaps [rsp+0xC0], xmm13
00007981ddfe2faf  vmovaps [rsp+0xD0], xmm14
00007981ddfe2fb8  vmovaps [rsp+0xE0], xmm15
00007981ddfe2fc1  sub rsp, 0x30
00007981ddfe2fc5  movaps [rsp], xmm11
00007981ddfe2fca  movaps [rsp+0x10], xmm10
00007981ddfe2fd0  movaps [rsp+0x20], xmm6
00007981ddfe2fd5  lea rdi, [rsp]
00007981ddfe2fd9  mov esi, 0x00
00007981ddfe2fde  mov rax, 0x5782A6EB3530
00007981ddfe2fe8  call rax
00007981ddfe2fea  movaps xmm11, [rsp]
00007981ddfe2fef  add rsp, 0x30
00007981ddfe2ff3  vmovaps xmm0, [rsp]
00007981ddfe2ff8  vmovaps xmm1, [rsp+0x10]
00007981ddfe2ffe  vmovaps xmm2, [rsp+0x20]
00007981ddfe3004  vmovaps xmm3, [rsp+0x30]
00007981ddfe300a  vmovaps xmm4, [rsp+0x40]
00007981ddfe3010  vmovaps xmm5, [rsp+0x50]
00007981ddfe3016  vmovaps xmm6, [rsp+0x60]
00007981ddfe301c  vmovaps xmm7, [rsp+0x70]
00007981ddfe3022  vmovaps xmm8, [rsp+0x80]
00007981ddfe302b  vmovaps xmm9, [rsp+0x90]
00007981ddfe3034  vmovaps xmm10, [rsp+0xA0]
00007981ddfe303d  vmovaps xmm12, [rsp+0xB0]
00007981ddfe3046  vmovaps xmm13, [rsp+0xC0]
00007981ddfe304f  vmovaps xmm14, [rsp+0xD0]
00007981ddfe3058  vmovaps xmm15, [rsp+0xE0]
00007981ddfe3061  add rsp, 0xF0
00007981ddfe3068  pop r11
00007981ddfe306a  pop r10
00007981ddfe306c  pop r9
00007981ddfe306e  pop r8
00007981ddfe3070  pop rsi
00007981ddfe3071  pop rdi
00007981ddfe3072  pop rdx
00007981ddfe3073  pop rcx
00007981ddfe3074  pop rax
00007981ddfe3075  add rsp, 0x08
00007981ddfe3079  jmp 0x00007981DDFDF700
00007981ddfe307e  sub rsp, 0x08
00007981ddfe3082  push rax
00007981ddfe3083  push rcx
00007981ddfe3084  push rdx
00007981ddfe3085  push rdi
00007981ddfe3086  push rsi
00007981ddfe3087  push r8
00007981ddfe3089  push r9
00007981ddfe308b  push r10
00007981ddfe308d  push r11
00007981ddfe308f  sub rsp, 0xF0
00007981ddfe3096  vmovaps [rsp], xmm0
00007981ddfe309b  vmovaps [rsp+0x10], xmm1
00007981ddfe30a1  vmovaps [rsp+0x20], xmm2
00007981ddfe30a7  vmovaps [rsp+0x30], xmm3
00007981ddfe30ad  vmovaps [rsp+0x40], xmm4
00007981ddfe30b3  vmovaps [rsp+0x50], xmm5
00007981ddfe30b9  vmovaps [rsp+0x60], xmm6
00007981ddfe30bf  vmovaps [rsp+0x70], xmm7
00007981ddfe30c5  vmovaps [rsp+0x80], xmm8
00007981ddfe30ce  vmovaps [rsp+0x90], xmm9
00007981ddfe30d7  vmovaps [rsp+0xA0], xmm11
00007981ddfe30e0  vmovaps [rsp+0xB0], xmm12
00007981ddfe30e9  vmovaps [rsp+0xC0], xmm13
00007981ddfe30f2  vmovaps [rsp+0xD0], xmm14
00007981ddfe30fb  vmovaps [rsp+0xE0], xmm15
00007981ddfe3104  sub rsp, 0x30
00007981ddfe3108  movaps [rsp], xmm10
00007981ddfe310d  movaps [rsp+0x10], xmm14
00007981ddfe3113  movaps [rsp+0x20], xmm4
00007981ddfe3118  lea rdi, [rsp]
00007981ddfe311c  mov esi, 0x00
00007981ddfe3121  mov rax, 0x5782A6EB3530
00007981ddfe312b  call rax
00007981ddfe312d  movaps xmm10, [rsp]
00007981ddfe3132  add rsp, 0x30
00007981ddfe3136  vmovaps xmm0, [rsp]
00007981ddfe313b  vmovaps xmm1, [rsp+0x10]
00007981ddfe3141  vmovaps xmm2, [rsp+0x20]
00007981ddfe3147  vmovaps xmm3, [rsp+0x30]
00007981ddfe314d  vmovaps xmm4, [rsp+0x40]
00007981ddfe3153  vmovaps xmm5, [rsp+0x50]
00007981ddfe3159  vmovaps xmm6, [rsp+0x60]
00007981ddfe315f  vmovaps xmm7, [rsp+0x70]
00007981ddfe3165  vmovaps xmm8, [rsp+0x80]
00007981ddfe316e  vmovaps xmm9, [rsp+0x90]
00007981ddfe3177  vmovaps xmm11, [rsp+0xA0]
00007981ddfe3180  vmovaps xmm12, [rsp+0xB0]
00007981ddfe3189  vmovaps xmm13, [rsp+0xC0]
00007981ddfe3192  vmovaps xmm14, [rsp+0xD0]
00007981ddfe319b  vmovaps xmm15, [rsp+0xE0]
00007981ddfe31a4  add rsp, 0xF0
00007981ddfe31ab  pop r11
00007981ddfe31ad  pop r10
00007981ddfe31af  pop r9
00007981ddfe31b1  pop r8
00007981ddfe31b3  pop rsi
00007981ddfe31b4  pop rdi
00007981ddfe31b5  pop rdx
00007981ddfe31b6  pop rcx
00007981ddfe31b7  pop rax
00007981ddfe31b8  add rsp, 0x08
00007981ddfe31bc  jmp 0x00007981DDFDF71B
00007981ddfe31c1  sub rsp, 0x08
00007981ddfe31c5  push rax
00007981ddfe31c6  push rcx
00007981ddfe31c7  push rdx
00007981ddfe31c8  push rdi
00007981ddfe31c9  push rsi
00007981ddfe31ca  push r8
00007981ddfe31cc  push r9
00007981ddfe31ce  push r10
00007981ddfe31d0  push r11
00007981ddfe31d2  sub rsp, 0xF0
00007981ddfe31d9  vmovaps [rsp], xmm0
00007981ddfe31de  vmovaps [rsp+0x10], xmm1
00007981ddfe31e4  vmovaps [rsp+0x20], xmm2
00007981ddfe31ea  vmovaps [rsp+0x30], xmm3
00007981ddfe31f0  vmovaps [rsp+0x40], xmm4
00007981ddfe31f6  vmovaps [rsp+0x50], xmm5
00007981ddfe31fc  vmovaps [rsp+0x60], xmm6
00007981ddfe3202  vmovaps [rsp+0x70], xmm7
00007981ddfe3208  vmovaps [rsp+0x80], xmm9
00007981ddfe3211  vmovaps [rsp+0x90], xmm10
00007981ddfe321a  vmovaps [rsp+0xA0], xmm11
00007981ddfe3223  vmovaps [rsp+0xB0], xmm12
00007981ddfe322c  vmovaps [rsp+0xC0], xmm13
00007981ddfe3235  vmovaps [rsp+0xD0], xmm14
00007981ddfe323e  vmovaps [rsp+0xE0], xmm15
00007981ddfe3247  sub rsp, 0x30
00007981ddfe324b  movaps [rsp], xmm8
00007981ddfe3250  movaps [rsp+0x10], xmm1
00007981ddfe3255  movaps [rsp+0x20], xmm14
00007981ddfe325b  lea rdi, [rsp]
00007981ddfe325f  mov esi, 0x00
00007981ddfe3264  mov rax, 0x5782A6EB3530
00007981ddfe326e  call rax
00007981ddfe3270  movaps xmm8, [rsp]
00007981ddfe3275  add rsp, 0x30
00007981ddfe3279  vmovaps xmm0, [rsp]
00007981ddfe327e  vmovaps xmm1, [rsp+0x10]
00007981ddfe3284  vmovaps xmm2, [rsp+0x20]
00007981ddfe328a  vmovaps xmm3, [rsp+0x30]
00007981ddfe3290  vmovaps xmm4, [rsp+0x40]
00007981ddfe3296  vmovaps xmm5, [rsp+0x50]
00007981ddfe329c  vmovaps xmm6, [rsp+0x60]
00007981ddfe32a2  vmovaps xmm7, [rsp+0x70]
00007981ddfe32a8  vmovaps xmm9, [rsp+0x80]
00007981ddfe32b1  vmovaps xmm10, [rsp+0x90]
00007981ddfe32ba  vmovaps xmm11, [rsp+0xA0]
00007981ddfe32c3  vmovaps xmm12, [rsp+0xB0]
00007981ddfe32cc  vmovaps xmm13, [rsp+0xC0]
00007981ddfe32d5  vmovaps xmm14, [rsp+0xD0]
00007981ddfe32de  vmovaps xmm15, [rsp+0xE0]
00007981ddfe32e7  add rsp, 0xF0
00007981ddfe32ee  pop r11
00007981ddfe32f0  pop r10
00007981ddfe32f2  pop r9
00007981ddfe32f4  pop r8
00007981ddfe32f6  pop rsi
00007981ddfe32f7  pop rdi
00007981ddfe32f8  pop rdx
00007981ddfe32f9  pop rcx
00007981ddfe32fa  pop rax
00007981ddfe32fb  add rsp, 0x08
00007981ddfe32ff  jmp 0x00007981DDFDF741
00007981ddfe3304  sub rsp, 0x08
00007981ddfe3308  push rax
00007981ddfe3309  push rcx
00007981ddfe330a  push rdx
00007981ddfe330b  push rdi
00007981ddfe330c  push rsi
00007981ddfe330d  push r8
00007981ddfe330f  push r9
00007981ddfe3311  push r10
00007981ddfe3313  push r11
00007981ddfe3315  sub rsp, 0xF0
00007981ddfe331c  vmovaps [rsp], xmm0
00007981ddfe3321  vmovaps [rsp+0x10], xmm1
00007981ddfe3327  vmovaps [rsp+0x20], xmm2
00007981ddfe332d  vmovaps [rsp+0x30], xmm3
00007981ddfe3333  vmovaps [rsp+0x40], xmm4
00007981ddfe3339  vmovaps [rsp+0x50], xmm5
00007981ddfe333f  vmovaps [rsp+0x60], xmm7
00007981ddfe3345  vmovaps [rsp+0x70], xmm8
00007981ddfe334b  vmovaps [rsp+0x80], xmm9
00007981ddfe3354  vmovaps [rsp+0x90], xmm10
00007981ddfe335d  vmovaps [rsp+0xA0], xmm11
00007981ddfe3366  vmovaps [rsp+0xB0], xmm12
00007981ddfe336f  vmovaps [rsp+0xC0], xmm13
00007981ddfe3378  vmovaps [rsp+0xD0], xmm14
00007981ddfe3381  vmovaps [rsp+0xE0], xmm15
00007981ddfe338a  sub rsp, 0x30
00007981ddfe338e  movaps [rsp], xmm6
00007981ddfe3392  movaps [rsp+0x10], xmm1
00007981ddfe3397  movaps [rsp+0x20], xmm14
00007981ddfe339d  lea rdi, [rsp]
00007981ddfe33a1  mov esi, 0x00
00007981ddfe33a6  mov rax, 0x5782A6EB3530
00007981ddfe33b0  call rax
00007981ddfe33b2  movaps xmm6, [rsp]
00007981ddfe33b6  add rsp, 0x30
00007981ddfe33ba  vmovaps xmm0, [rsp]
00007981ddfe33bf  vmovaps xmm1, [rsp+0x10]
00007981ddfe33c5  vmovaps xmm2, [rsp+0x20]
00007981ddfe33cb  vmovaps xmm3, [rsp+0x30]
00007981ddfe33d1  vmovaps xmm4, [rsp+0x40]
00007981ddfe33d7  vmovaps xmm5, [rsp+0x50]
00007981ddfe33dd  vmovaps xmm7, [rsp+0x60]
00007981ddfe33e3  vmovaps xmm8, [rsp+0x70]
00007981ddfe33e9  vmovaps xmm9, [rsp+0x80]
00007981ddfe33f2  vmovaps xmm10, [rsp+0x90]
00007981ddfe33fb  vmovaps xmm11, [rsp+0xA0]
00007981ddfe3404  vmovaps xmm12, [rsp+0xB0]
00007981ddfe340d  vmovaps xmm13, [rsp+0xC0]
00007981ddfe3416  vmovaps xmm14, [rsp+0xD0]
00007981ddfe341f  vmovaps xmm15, [rsp+0xE0]
00007981ddfe3428  add rsp, 0xF0
00007981ddfe342f  pop r11
00007981ddfe3431  pop r10
00007981ddfe3433  pop r9
00007981ddfe3435  pop r8
00007981ddfe3437  pop rsi
00007981ddfe3438  pop rdi
00007981ddfe3439  pop rdx
00007981ddfe343a  pop rcx
00007981ddfe343b  pop rax
00007981ddfe343c  add rsp, 0x08
00007981ddfe3440  jmp 0x00007981DDFDF76D
00007981ddfe3445  sub rsp, 0x08
00007981ddfe3449  push rax
00007981ddfe344a  push rcx
00007981ddfe344b  push rdx
00007981ddfe344c  push rdi
00007981ddfe344d  push rsi
00007981ddfe344e  push r8
00007981ddfe3450  push r9
00007981ddfe3452  push r10
00007981ddfe3454  push r11
00007981ddfe3456  sub rsp, 0xF0
00007981ddfe345d  vmovaps [rsp], xmm0
00007981ddfe3462  vmovaps [rsp+0x10], xmm1
00007981ddfe3468  vmovaps [rsp+0x20], xmm2
00007981ddfe346e  vmovaps [rsp+0x30], xmm3
00007981ddfe3474  vmovaps [rsp+0x40], xmm4
00007981ddfe347a  vmovaps [rsp+0x50], xmm5
00007981ddfe3480  vmovaps [rsp+0x60], xmm6
00007981ddfe3486  vmovaps [rsp+0x70], xmm7
00007981ddfe348c  vmovaps [rsp+0x80], xmm8
00007981ddfe3495  vmovaps [rsp+0x90], xmm9
00007981ddfe349e  vmovaps [rsp+0xA0], xmm10
00007981ddfe34a7  vmovaps [rsp+0xB0], xmm11
00007981ddfe34b0  vmovaps [rsp+0xC0], xmm12
00007981ddfe34b9  vmovaps [rsp+0xD0], xmm13
00007981ddfe34c2  vmovaps [rsp+0xE0], xmm15
00007981ddfe34cb  sub rsp, 0x30
00007981ddfe34cf  movaps [rsp], xmm14
00007981ddfe34d4  movaps [rsp+0x10], xmm12
00007981ddfe34da  movaps [rsp+0x20], xmm1
00007981ddfe34df  lea rdi, [rsp]
00007981ddfe34e3  mov esi, 0x00
00007981ddfe34e8  mov rax, 0x5782A6EB3530
00007981ddfe34f2  call rax
00007981ddfe34f4  movaps xmm14, [rsp]
00007981ddfe34f9  add rsp, 0x30
00007981ddfe34fd  vmovaps xmm0, [rsp]
00007981ddfe3502  vmovaps xmm1, [rsp+0x10]
00007981ddfe3508  vmovaps xmm2, [rsp+0x20]
00007981ddfe350e  vmovaps xmm3, [rsp+0x30]
00007981ddfe3514  vmovaps xmm4, [rsp+0x40]
00007981ddfe351a  vmovaps xmm5, [rsp+0x50]
00007981ddfe3520  vmovaps xmm6, [rsp+0x60]
00007981ddfe3526  vmovaps xmm7, [rsp+0x70]
00007981ddfe352c  vmovaps xmm8, [rsp+0x80]
00007981ddfe3535  vmovaps xmm9, [rsp+0x90]
00007981ddfe353e  vmovaps xmm10, [rsp+0xA0]
00007981ddfe3547  vmovaps xmm11, [rsp+0xB0]
00007981ddfe3550  vmovaps xmm12, [rsp+0xC0]
00007981ddfe3559  vmovaps xmm13, [rsp+0xD0]
00007981ddfe3562  vmovaps xmm15, [rsp+0xE0]
00007981ddfe356b  add rsp, 0xF0
00007981ddfe3572  pop r11
00007981ddfe3574  pop r10
00007981ddfe3576  pop r9
00007981ddfe3578  pop r8
00007981ddfe357a  pop rsi
00007981ddfe357b  pop rdi
00007981ddfe357c  pop rdx
00007981ddfe357d  pop rcx
00007981ddfe357e  pop rax
00007981ddfe357f  add rsp, 0x08
00007981ddfe3583  jmp 0x00007981DDFDF793
00007981ddfe3588  sub rsp, 0x08
00007981ddfe358c  push rax
00007981ddfe358d  push rcx
00007981ddfe358e  push rdx
00007981ddfe358f  push rdi
00007981ddfe3590  push rsi
00007981ddfe3591  push r8
00007981ddfe3593  push r9
00007981ddfe3595  push r10
00007981ddfe3597  push r11
00007981ddfe3599  sub rsp, 0xF0
00007981ddfe35a0  vmovaps [rsp], xmm0
00007981ddfe35a5  vmovaps [rsp+0x10], xmm2
00007981ddfe35ab  vmovaps [rsp+0x20], xmm3
00007981ddfe35b1  vmovaps [rsp+0x30], xmm4
00007981ddfe35b7  vmovaps [rsp+0x40], xmm5
00007981ddfe35bd  vmovaps [rsp+0x50], xmm6
00007981ddfe35c3  vmovaps [rsp+0x60], xmm7
00007981ddfe35c9  vmovaps [rsp+0x70], xmm8
00007981ddfe35cf  vmovaps [rsp+0x80], xmm9
00007981ddfe35d8  vmovaps [rsp+0x90], xmm10
00007981ddfe35e1  vmovaps [rsp+0xA0], xmm11
00007981ddfe35ea  vmovaps [rsp+0xB0], xmm12
00007981ddfe35f3  vmovaps [rsp+0xC0], xmm13
00007981ddfe35fc  vmovaps [rsp+0xD0], xmm14
00007981ddfe3605  vmovaps [rsp+0xE0], xmm15
00007981ddfe360e  sub rsp, 0x30
00007981ddfe3612  movaps [rsp], xmm1
00007981ddfe3616  movaps [rsp+0x10], xmm13
00007981ddfe361c  movaps [rsp+0x20], xmm9
00007981ddfe3622  lea rdi, [rsp]
00007981ddfe3626  mov esi, 0x00
00007981ddfe362b  mov rax, 0x5782A6EB3530
00007981ddfe3635  call rax
00007981ddfe3637  movaps xmm1, [rsp]
00007981ddfe363b  add rsp, 0x30
00007981ddfe363f  vmovaps xmm0, [rsp]
00007981ddfe3644  vmovaps xmm2, [rsp+0x10]
00007981ddfe364a  vmovaps xmm3, [rsp+0x20]
00007981ddfe3650  vmovaps xmm4, [rsp+0x30]
00007981ddfe3656  vmovaps xmm5, [rsp+0x40]
00007981ddfe365c  vmovaps xmm6, [rsp+0x50]
00007981ddfe3662  vmovaps xmm7, [rsp+0x60]
00007981ddfe3668  vmovaps xmm8, [rsp+0x70]
00007981ddfe366e  vmovaps xmm9, [rsp+0x80]
00007981ddfe3677  vmovaps xmm10, [rsp+0x90]
00007981ddfe3680  vmovaps xmm11, [rsp+0xA0]
00007981ddfe3689  vmovaps xmm12, [rsp+0xB0]
00007981ddfe3692  vmovaps xmm13, [rsp+0xC0]
00007981ddfe369b  vmovaps xmm14, [rsp+0xD0]
00007981ddfe36a4  vmovaps xmm15, [rsp+0xE0]
00007981ddfe36ad  add rsp, 0xF0
00007981ddfe36b4  pop r11
00007981ddfe36b6  pop r10
00007981ddfe36b8  pop r9
00007981ddfe36ba  pop r8
00007981ddfe36bc  pop rsi
00007981ddfe36bd  pop rdi
00007981ddfe36be  pop rdx
00007981ddfe36bf  pop rcx
00007981ddfe36c0  pop rax
00007981ddfe36c1  add rsp, 0x08
00007981ddfe36c5  jmp 0x00007981DDFDF7AD
00007981ddfe36ca  sub rsp, 0x08
00007981ddfe36ce  push rax
00007981ddfe36cf  push rcx
00007981ddfe36d0  push rdx
00007981ddfe36d1  push rdi
00007981ddfe36d2  push rsi
00007981ddfe36d3  push r8
00007981ddfe36d5  push r9
00007981ddfe36d7  push r10
00007981ddfe36d9  push r11
00007981ddfe36db  sub rsp, 0xF0
00007981ddfe36e2  vmovaps [rsp], xmm0
00007981ddfe36e7  vmovaps [rsp+0x10], xmm1
00007981ddfe36ed  vmovaps [rsp+0x20], xmm2
00007981ddfe36f3  vmovaps [rsp+0x30], xmm3
00007981ddfe36f9  vmovaps [rsp+0x40], xmm4
00007981ddfe36ff  vmovaps [rsp+0x50], xmm5
00007981ddfe3705  vmovaps [rsp+0x60], xmm6
00007981ddfe370b  vmovaps [rsp+0x70], xmm7
00007981ddfe3711  vmovaps [rsp+0x80], xmm8
00007981ddfe371a  vmovaps [rsp+0x90], xmm9
00007981ddfe3723  vmovaps [rsp+0xA0], xmm10
00007981ddfe372c  vmovaps [rsp+0xB0], xmm11
00007981ddfe3735  vmovaps [rsp+0xC0], xmm13
00007981ddfe373e  vmovaps [rsp+0xD0], xmm14
00007981ddfe3747  vmovaps [rsp+0xE0], xmm15
00007981ddfe3750  sub rsp, 0x30
00007981ddfe3754  movaps [rsp], xmm12
00007981ddfe3759  movaps [rsp+0x10], xmm7
00007981ddfe375e  movaps [rsp+0x20], xmm13
00007981ddfe3764  lea rdi, [rsp]
00007981ddfe3768  mov esi, 0x00
00007981ddfe376d  mov rax, 0x5782A6EB3530
00007981ddfe3777  call rax
00007981ddfe3779  movaps xmm12, [rsp]
00007981ddfe377e  add rsp, 0x30
00007981ddfe3782  vmovaps xmm0, [rsp]
00007981ddfe3787  vmovaps xmm1, [rsp+0x10]
00007981ddfe378d  vmovaps xmm2, [rsp+0x20]
00007981ddfe3793  vmovaps xmm3, [rsp+0x30]
00007981ddfe3799  vmovaps xmm4, [rsp+0x40]
00007981ddfe379f  vmovaps xmm5, [rsp+0x50]
00007981ddfe37a5  vmovaps xmm6, [rsp+0x60]
00007981ddfe37ab  vmovaps xmm7, [rsp+0x70]
00007981ddfe37b1  vmovaps xmm8, [rsp+0x80]
00007981ddfe37ba  vmovaps xmm9, [rsp+0x90]
00007981ddfe37c3  vmovaps xmm10, [rsp+0xA0]
00007981ddfe37cc  vmovaps xmm11, [rsp+0xB0]
00007981ddfe37d5  vmovaps xmm13, [rsp+0xC0]
00007981ddfe37de  vmovaps xmm14, [rsp+0xD0]
00007981ddfe37e7  vmovaps xmm15, [rsp+0xE0]
00007981ddfe37f0  add rsp, 0xF0
00007981ddfe37f7  pop r11
00007981ddfe37f9  pop r10
00007981ddfe37fb  pop r9
00007981ddfe37fd  pop r8
00007981ddfe37ff  pop rsi
00007981ddfe3800  pop rdi
00007981ddfe3801  pop rdx
00007981ddfe3802  pop rcx
00007981ddfe3803  pop rax
00007981ddfe3804  add rsp, 0x08
00007981ddfe3808  jmp 0x00007981DDFDF7D4
00007981ddfe380d  sub rsp, 0x08
00007981ddfe3811  push rax
00007981ddfe3812  push rcx
00007981ddfe3813  push rdx
00007981ddfe3814  push rdi
00007981ddfe3815  push rsi
00007981ddfe3816  push r8
00007981ddfe3818  push r9
00007981ddfe381a  push r10
00007981ddfe381c  push r11
00007981ddfe381e  sub rsp, 0xF0
00007981ddfe3825  vmovaps [rsp], xmm0
00007981ddfe382a  vmovaps [rsp+0x10], xmm1
00007981ddfe3830  vmovaps [rsp+0x20], xmm2
00007981ddfe3836  vmovaps [rsp+0x30], xmm3
00007981ddfe383c  vmovaps [rsp+0x40], xmm4
00007981ddfe3842  vmovaps [rsp+0x50], xmm5
00007981ddfe3848  vmovaps [rsp+0x60], xmm6
00007981ddfe384e  vmovaps [rsp+0x70], xmm7
00007981ddfe3854  vmovaps [rsp+0x80], xmm8
00007981ddfe385d  vmovaps [rsp+0x90], xmm9
00007981ddfe3866  vmovaps [rsp+0xA0], xmm10
00007981ddfe386f  vmovaps [rsp+0xB0], xmm11
00007981ddfe3878  vmovaps [rsp+0xC0], xmm12
00007981ddfe3881  vmovaps [rsp+0xD0], xmm14
00007981ddfe388a  vmovaps [rsp+0xE0], xmm15
00007981ddfe3893  sub rsp, 0x30
00007981ddfe3897  movaps [rsp], xmm13
00007981ddfe389c  movaps [rsp+0x10], xmm15
00007981ddfe38a2  movaps [rsp+0x20], xmm8
00007981ddfe38a8  lea rdi, [rsp]
00007981ddfe38ac  mov esi, 0x00
00007981ddfe38b1  mov rax, 0x5782A6EB3530
00007981ddfe38bb  call rax
00007981ddfe38bd  movaps xmm13, [rsp]
00007981ddfe38c2  add rsp, 0x30
00007981ddfe38c6  vmovaps xmm0, [rsp]
00007981ddfe38cb  vmovaps xmm1, [rsp+0x10]
00007981ddfe38d1  vmovaps xmm2, [rsp+0x20]
00007981ddfe38d7  vmovaps xmm3, [rsp+0x30]
00007981ddfe38dd  vmovaps xmm4, [rsp+0x40]
00007981ddfe38e3  vmovaps xmm5, [rsp+0x50]
00007981ddfe38e9  vmovaps xmm6, [rsp+0x60]
00007981ddfe38ef  vmovaps xmm7, [rsp+0x70]
00007981ddfe38f5  vmovaps xmm8, [rsp+0x80]
00007981ddfe38fe  vmovaps xmm9, [rsp+0x90]
00007981ddfe3907  vmovaps xmm10, [rsp+0xA0]
00007981ddfe3910  vmovaps xmm11, [rsp+0xB0]
00007981ddfe3919  vmovaps xmm12, [rsp+0xC0]
00007981ddfe3922  vmovaps xmm14, [rsp+0xD0]
00007981ddfe392b  vmovaps xmm15, [rsp+0xE0]
00007981ddfe3934  add rsp, 0xF0
00007981ddfe393b  pop r11
00007981ddfe393d  pop r10
00007981ddfe393f  pop r9
00007981ddfe3941  pop r8
00007981ddfe3943  pop rsi
00007981ddfe3944  pop rdi
00007981ddfe3945  pop rdx
00007981ddfe3946  pop rcx
00007981ddfe3947  pop rax
00007981ddfe3948  add rsp, 0x08
00007981ddfe394c  jmp 0x00007981DDFDF7EF
00007981ddfe3951  sub rsp, 0x08
00007981ddfe3955  push rax
00007981ddfe3956  push rcx
00007981ddfe3957  push rdx
00007981ddfe3958  push rdi
00007981ddfe3959  push rsi
00007981ddfe395a  push r8
00007981ddfe395c  push r9
00007981ddfe395e  push r10
00007981ddfe3960  push r11
00007981ddfe3962  sub rsp, 0xF0
00007981ddfe3969  vmovaps [rsp], xmm0
00007981ddfe396e  vmovaps [rsp+0x10], xmm1
00007981ddfe3974  vmovaps [rsp+0x20], xmm2
00007981ddfe397a  vmovaps [rsp+0x30], xmm3
00007981ddfe3980  vmovaps [rsp+0x40], xmm4
00007981ddfe3986  vmovaps [rsp+0x50], xmm5
00007981ddfe398c  vmovaps [rsp+0x60], xmm6
00007981ddfe3992  vmovaps [rsp+0x70], xmm7
00007981ddfe3998  vmovaps [rsp+0x80], xmm9
00007981ddfe39a1  vmovaps [rsp+0x90], xmm10
00007981ddfe39aa  vmovaps [rsp+0xA0], xmm11
00007981ddfe39b3  vmovaps [rsp+0xB0], xmm12
00007981ddfe39bc  vmovaps [rsp+0xC0], xmm13
00007981ddfe39c5  vmovaps [rsp+0xD0], xmm14
00007981ddfe39ce  vmovaps [rsp+0xE0], xmm15
00007981ddfe39d7  sub rsp, 0x30
00007981ddfe39db  movaps [rsp], xmm8
00007981ddfe39e0  movaps [rsp+0x10], xmm15
00007981ddfe39e6  movaps [rsp+0x20], xmm9
00007981ddfe39ec  lea rdi, [rsp]
00007981ddfe39f0  mov esi, 0x00
00007981ddfe39f5  mov rax, 0x5782A6EB3530
00007981ddfe39ff  call rax
00007981ddfe3a01  movaps xmm8, [rsp]
00007981ddfe3a06  add rsp, 0x30
00007981ddfe3a0a  vmovaps xmm0, [rsp]
00007981ddfe3a0f  vmovaps xmm1, [rsp+0x10]
00007981ddfe3a15  vmovaps xmm2, [rsp+0x20]
00007981ddfe3a1b  vmovaps xmm3, [rsp+0x30]
00007981ddfe3a21  vmovaps xmm4, [rsp+0x40]
00007981ddfe3a27  vmovaps xmm5, [rsp+0x50]
00007981ddfe3a2d  vmovaps xmm6, [rsp+0x60]
00007981ddfe3a33  vmovaps xmm7, [rsp+0x70]
00007981ddfe3a39  vmovaps xmm9, [rsp+0x80]
00007981ddfe3a42  vmovaps xmm10, [rsp+0x90]
00007981ddfe3a4b  vmovaps xmm11, [rsp+0xA0]
00007981ddfe3a54  vmovaps xmm12, [rsp+0xB0]
00007981ddfe3a5d  vmovaps xmm13, [rsp+0xC0]
00007981ddfe3a66  vmovaps xmm14, [rsp+0xD0]
00007981ddfe3a6f  vmovaps xmm15, [rsp+0xE0]
00007981ddfe3a78  add rsp, 0xF0
00007981ddfe3a7f  pop r11
00007981ddfe3a81  pop r10
00007981ddfe3a83  pop r9
00007981ddfe3a85  pop r8
00007981ddfe3a87  pop rsi
00007981ddfe3a88  pop rdi
00007981ddfe3a89  pop rdx
00007981ddfe3a8a  pop rcx
00007981ddfe3a8b  pop rax
00007981ddfe3a8c  add rsp, 0x08
00007981ddfe3a90  jmp 0x00007981DDFDF81D
00007981ddfe3a95  sub rsp, 0x08
00007981ddfe3a99  push rax
00007981ddfe3a9a  push rcx
00007981ddfe3a9b  push rdx
00007981ddfe3a9c  push rdi
00007981ddfe3a9d  push rsi
00007981ddfe3a9e  push r8
00007981ddfe3aa0  push r9
00007981ddfe3aa2  push r10
00007981ddfe3aa4  push r11
00007981ddfe3aa6  sub rsp, 0xF0
00007981ddfe3aad  vmovaps [rsp], xmm0
00007981ddfe3ab2  vmovaps [rsp+0x10], xmm1
00007981ddfe3ab8  vmovaps [rsp+0x20], xmm2
00007981ddfe3abe  vmovaps [rsp+0x30], xmm3
00007981ddfe3ac4  vmovaps [rsp+0x40], xmm4
00007981ddfe3aca  vmovaps [rsp+0x50], xmm5
00007981ddfe3ad0  vmovaps [rsp+0x60], xmm6
00007981ddfe3ad6  vmovaps [rsp+0x70], xmm7
00007981ddfe3adc  vmovaps [rsp+0x80], xmm8
00007981ddfe3ae5  vmovaps [rsp+0x90], xmm9
00007981ddfe3aee  vmovaps [rsp+0xA0], xmm10
00007981ddfe3af7  vmovaps [rsp+0xB0], xmm11
00007981ddfe3b00  vmovaps [rsp+0xC0], xmm12
00007981ddfe3b09  vmovaps [rsp+0xD0], xmm13
00007981ddfe3b12  vmovaps [rsp+0xE0], xmm14
00007981ddfe3b1b  sub rsp, 0x30
00007981ddfe3b1f  movaps [rsp], xmm15
00007981ddfe3b24  movaps [rsp+0x10], xmm11
00007981ddfe3b2a  movaps [rsp+0x20], xmm6
00007981ddfe3b2f  lea rdi, [rsp]
00007981ddfe3b33  mov esi, 0x00
00007981ddfe3b38  mov rax, 0x5782A6EB3530
00007981ddfe3b42  call rax
00007981ddfe3b44  movaps xmm15, [rsp]
00007981ddfe3b49  add rsp, 0x30
00007981ddfe3b4d  vmovaps xmm0, [rsp]
00007981ddfe3b52  vmovaps xmm1, [rsp+0x10]
00007981ddfe3b58  vmovaps xmm2, [rsp+0x20]
00007981ddfe3b5e  vmovaps xmm3, [rsp+0x30]
00007981ddfe3b64  vmovaps xmm4, [rsp+0x40]
00007981ddfe3b6a  vmovaps xmm5, [rsp+0x50]
00007981ddfe3b70  vmovaps xmm6, [rsp+0x60]
00007981ddfe3b76  vmovaps xmm7, [rsp+0x70]
00007981ddfe3b7c  vmovaps xmm8, [rsp+0x80]
00007981ddfe3b85  vmovaps xmm9, [rsp+0x90]
00007981ddfe3b8e  vmovaps xmm10, [rsp+0xA0]
00007981ddfe3b97  vmovaps xmm11, [rsp+0xB0]
00007981ddfe3ba0  vmovaps xmm12, [rsp+0xC0]
00007981ddfe3ba9  vmovaps xmm13, [rsp+0xD0]
00007981ddfe3bb2  vmovaps xmm14, [rsp+0xE0]
00007981ddfe3bbb  add rsp, 0xF0
00007981ddfe3bc2  pop r11
00007981ddfe3bc4  pop r10
00007981ddfe3bc6  pop r9
00007981ddfe3bc8  pop r8
00007981ddfe3bca  pop rsi
00007981ddfe3bcb  pop rdi
00007981ddfe3bcc  pop rdx
00007981ddfe3bcd  pop rcx
00007981ddfe3bce  pop rax
00007981ddfe3bcf  add rsp, 0x08
00007981ddfe3bd3  jmp 0x00007981DDFDF838
00007981ddfe3bd8  sub rsp, 0x08
00007981ddfe3bdc  push rax
00007981ddfe3bdd  push rcx
00007981ddfe3bde  push rdx
00007981ddfe3bdf  push rdi
00007981ddfe3be0  push rsi
00007981ddfe3be1  push r8
00007981ddfe3be3  push r9
00007981ddfe3be5  push r10
00007981ddfe3be7  push r11
00007981ddfe3be9  sub rsp, 0xF0
00007981ddfe3bf0  vmovaps [rsp], xmm0
00007981ddfe3bf5  vmovaps [rsp+0x10], xmm1
00007981ddfe3bfb  vmovaps [rsp+0x20], xmm2
00007981ddfe3c01  vmovaps [rsp+0x30], xmm3
00007981ddfe3c07  vmovaps [rsp+0x40], xmm4
00007981ddfe3c0d  vmovaps [rsp+0x50], xmm5
00007981ddfe3c13  vmovaps [rsp+0x60], xmm6
00007981ddfe3c19  vmovaps [rsp+0x70], xmm8
00007981ddfe3c1f  vmovaps [rsp+0x80], xmm9
00007981ddfe3c28  vmovaps [rsp+0x90], xmm10
00007981ddfe3c31  vmovaps [rsp+0xA0], xmm11
00007981ddfe3c3a  vmovaps [rsp+0xB0], xmm12
00007981ddfe3c43  vmovaps [rsp+0xC0], xmm13
00007981ddfe3c4c  vmovaps [rsp+0xD0], xmm14
00007981ddfe3c55  vmovaps [rsp+0xE0], xmm15
00007981ddfe3c5e  sub rsp, 0x30
00007981ddfe3c62  movaps [rsp], xmm7
00007981ddfe3c66  movaps [rsp+0x10], xmm11
00007981ddfe3c6c  movaps [rsp+0x20], xmm9
00007981ddfe3c72  lea rdi, [rsp]
00007981ddfe3c76  mov esi, 0x00
00007981ddfe3c7b  mov rax, 0x5782A6EB3530
00007981ddfe3c85  call rax
00007981ddfe3c87  movaps xmm7, [rsp]
00007981ddfe3c8b  add rsp, 0x30
00007981ddfe3c8f  vmovaps xmm0, [rsp]
00007981ddfe3c94  vmovaps xmm1, [rsp+0x10]
00007981ddfe3c9a  vmovaps xmm2, [rsp+0x20]
00007981ddfe3ca0  vmovaps xmm3, [rsp+0x30]
00007981ddfe3ca6  vmovaps xmm4, [rsp+0x40]
00007981ddfe3cac  vmovaps xmm5, [rsp+0x50]
00007981ddfe3cb2  vmovaps xmm6, [rsp+0x60]
00007981ddfe3cb8  vmovaps xmm8, [rsp+0x70]
00007981ddfe3cbe  vmovaps xmm9, [rsp+0x80]
00007981ddfe3cc7  vmovaps xmm10, [rsp+0x90]
00007981ddfe3cd0  vmovaps xmm11, [rsp+0xA0]
00007981ddfe3cd9  vmovaps xmm12, [rsp+0xB0]
00007981ddfe3ce2  vmovaps xmm13, [rsp+0xC0]
00007981ddfe3ceb  vmovaps xmm14, [rsp+0xD0]
00007981ddfe3cf4  vmovaps xmm15, [rsp+0xE0]
00007981ddfe3cfd  add rsp, 0xF0
00007981ddfe3d04  pop r11
00007981ddfe3d06  pop r10
00007981ddfe3d08  pop r9
00007981ddfe3d0a  pop r8
00007981ddfe3d0c  pop rsi
00007981ddfe3d0d  pop rdi
00007981ddfe3d0e  pop rdx
00007981ddfe3d0f  pop rcx
00007981ddfe3d10  pop rax
00007981ddfe3d11  add rsp, 0x08
00007981ddfe3d15  jmp 0x00007981DDFDF865
00007981ddfe3d1a  sub rsp, 0x08
00007981ddfe3d1e  push rax
00007981ddfe3d1f  push rcx
00007981ddfe3d20  push rdx
00007981ddfe3d21  push rdi
00007981ddfe3d22  push rsi
00007981ddfe3d23  push r8
00007981ddfe3d25  push r9
00007981ddfe3d27  push r10
00007981ddfe3d29  push r11
00007981ddfe3d2b  sub rsp, 0xF0
00007981ddfe3d32  vmovaps [rsp], xmm0
00007981ddfe3d37  vmovaps [rsp+0x10], xmm1
00007981ddfe3d3d  vmovaps [rsp+0x20], xmm2
00007981ddfe3d43  vmovaps [rsp+0x30], xmm3
00007981ddfe3d49  vmovaps [rsp+0x40], xmm4
00007981ddfe3d4f  vmovaps [rsp+0x50], xmm5
00007981ddfe3d55  vmovaps [rsp+0x60], xmm6
00007981ddfe3d5b  vmovaps [rsp+0x70], xmm7
00007981ddfe3d61  vmovaps [rsp+0x80], xmm8
00007981ddfe3d6a  vmovaps [rsp+0x90], xmm9
00007981ddfe3d73  vmovaps [rsp+0xA0], xmm10
00007981ddfe3d7c  vmovaps [rsp+0xB0], xmm12
00007981ddfe3d85  vmovaps [rsp+0xC0], xmm13
00007981ddfe3d8e  vmovaps [rsp+0xD0], xmm14
00007981ddfe3d97  vmovaps [rsp+0xE0], xmm15
00007981ddfe3da0  sub rsp, 0x30
00007981ddfe3da4  movaps [rsp], xmm11
00007981ddfe3da9  movaps [rsp+0x10], xmm10
00007981ddfe3daf  movaps [rsp+0x20], xmm14
00007981ddfe3db5  lea rdi, [rsp]
00007981ddfe3db9  mov esi, 0x00
00007981ddfe3dbe  mov rax, 0x5782A6EB3530
00007981ddfe3dc8  call rax
00007981ddfe3dca  movaps xmm11, [rsp]
00007981ddfe3dcf  add rsp, 0x30
00007981ddfe3dd3  vmovaps xmm0, [rsp]
00007981ddfe3dd8  vmovaps xmm1, [rsp+0x10]
00007981ddfe3dde  vmovaps xmm2, [rsp+0x20]
00007981ddfe3de4  vmovaps xmm3, [rsp+0x30]
00007981ddfe3dea  vmovaps xmm4, [rsp+0x40]
00007981ddfe3df0  vmovaps xmm5, [rsp+0x50]
00007981ddfe3df6  vmovaps xmm6, [rsp+0x60]
00007981ddfe3dfc  vmovaps xmm7, [rsp+0x70]
00007981ddfe3e02  vmovaps xmm8, [rsp+0x80]
00007981ddfe3e0b  vmovaps xmm9, [rsp+0x90]
00007981ddfe3e14  vmovaps xmm10, [rsp+0xA0]
00007981ddfe3e1d  vmovaps xmm12, [rsp+0xB0]
00007981ddfe3e26  vmovaps xmm13, [rsp+0xC0]
00007981ddfe3e2f  vmovaps xmm14, [rsp+0xD0]
00007981ddfe3e38  vmovaps xmm15, [rsp+0xE0]
00007981ddfe3e41  add rsp, 0xF0
00007981ddfe3e48  pop r11
00007981ddfe3e4a  pop r10
00007981ddfe3e4c  pop r9
00007981ddfe3e4e  pop r8
00007981ddfe3e50  pop rsi
00007981ddfe3e51  pop rdi
00007981ddfe3e52  pop rdx
00007981ddfe3e53  pop rcx
00007981ddfe3e54  pop rax
00007981ddfe3e55  add rsp, 0x08
00007981ddfe3e59  jmp 0x00007981DDFDF880
00007981ddfe3e5e  call 0x00007981DDEC33A0
00007981ddfe3e63  jmp 0x00007981DDFDF88A
00007981ddfe3e68  sub rsp, 0x08
00007981ddfe3e6c  push rax
00007981ddfe3e6d  push rcx
00007981ddfe3e6e  push rdx
00007981ddfe3e6f  push rdi
00007981ddfe3e70  push rsi
00007981ddfe3e71  push r8
00007981ddfe3e73  push r9
00007981ddfe3e75  push r10
00007981ddfe3e77  push r11
00007981ddfe3e79  sub rsp, 0xF0
00007981ddfe3e80  vmovaps [rsp], xmm0
00007981ddfe3e85  vmovaps [rsp+0x10], xmm1
00007981ddfe3e8b  vmovaps [rsp+0x20], xmm2
00007981ddfe3e91  vmovaps [rsp+0x30], xmm3
00007981ddfe3e97  vmovaps [rsp+0x40], xmm4
00007981ddfe3e9d  vmovaps [rsp+0x50], xmm5
00007981ddfe3ea3  vmovaps [rsp+0x60], xmm6
00007981ddfe3ea9  vmovaps [rsp+0x70], xmm7
00007981ddfe3eaf  vmovaps [rsp+0x80], xmm8
00007981ddfe3eb8  vmovaps [rsp+0x90], xmm9
00007981ddfe3ec1  vmovaps [rsp+0xA0], xmm11
00007981ddfe3eca  vmovaps [rsp+0xB0], xmm12
00007981ddfe3ed3  vmovaps [rsp+0xC0], xmm13
00007981ddfe3edc  vmovaps [rsp+0xD0], xmm14
00007981ddfe3ee5  vmovaps [rsp+0xE0], xmm15
00007981ddfe3eee  sub rsp, 0x30
00007981ddfe3ef2  movaps [rsp], xmm10
00007981ddfe3ef7  movaps [rsp+0x10], xmm1
00007981ddfe3efc  movaps [rsp+0x20], xmm12
00007981ddfe3f02  lea rdi, [rsp]
00007981ddfe3f06  mov esi, 0x00
00007981ddfe3f0b  mov rax, 0x5782A6EB3530
00007981ddfe3f15  call rax
00007981ddfe3f17  movaps xmm10, [rsp]
00007981ddfe3f1c  add rsp, 0x30
00007981ddfe3f20  vmovaps xmm0, [rsp]
00007981ddfe3f25  vmovaps xmm1, [rsp+0x10]
00007981ddfe3f2b  vmovaps xmm2, [rsp+0x20]
00007981ddfe3f31  vmovaps xmm3, [rsp+0x30]
00007981ddfe3f37  vmovaps xmm4, [rsp+0x40]
00007981ddfe3f3d  vmovaps xmm5, [rsp+0x50]
00007981ddfe3f43  vmovaps xmm6, [rsp+0x60]
00007981ddfe3f49  vmovaps xmm7, [rsp+0x70]
00007981ddfe3f4f  vmovaps xmm8, [rsp+0x80]
00007981ddfe3f58  vmovaps xmm9, [rsp+0x90]
00007981ddfe3f61  vmovaps xmm11, [rsp+0xA0]
00007981ddfe3f6a  vmovaps xmm12, [rsp+0xB0]
00007981ddfe3f73  vmovaps xmm13, [rsp+0xC0]
00007981ddfe3f7c  vmovaps xmm14, [rsp+0xD0]
00007981ddfe3f85  vmovaps xmm15, [rsp+0xE0]
00007981ddfe3f8e  add rsp, 0xF0
00007981ddfe3f95  pop r11
00007981ddfe3f97  pop r10
00007981ddfe3f99  pop r9
00007981ddfe3f9b  pop r8
00007981ddfe3f9d  pop rsi
00007981ddfe3f9e  pop rdi
00007981ddfe3f9f  pop rdx
00007981ddfe3fa0  pop rcx
00007981ddfe3fa1  pop rax
00007981ddfe3fa2  add rsp, 0x08
00007981ddfe3fa6  jmp 0x00007981DDFDF8AD
00007981ddfe3fab  sub rsp, 0x08
00007981ddfe3faf  push rax
00007981ddfe3fb0  push rcx
00007981ddfe3fb1  push rdx
00007981ddfe3fb2  push rdi
00007981ddfe3fb3  push rsi
00007981ddfe3fb4  push r8
00007981ddfe3fb6  push r9
00007981ddfe3fb8  push r10
00007981ddfe3fba  push r11
00007981ddfe3fbc  sub rsp, 0xF0
00007981ddfe3fc3  vmovaps [rsp], xmm0
00007981ddfe3fc8  vmovaps [rsp+0x10], xmm1
00007981ddfe3fce  vmovaps [rsp+0x20], xmm2
00007981ddfe3fd4  vmovaps [rsp+0x30], xmm3
00007981ddfe3fda  vmovaps [rsp+0x40], xmm4
00007981ddfe3fe0  vmovaps [rsp+0x50], xmm5
00007981ddfe3fe6  vmovaps [rsp+0x60], xmm6
00007981ddfe3fec  vmovaps [rsp+0x70], xmm7
00007981ddfe3ff2  vmovaps [rsp+0x80], xmm8
00007981ddfe3ffb  vmovaps [rsp+0x90], xmm9
00007981ddfe4004  vmovaps [rsp+0xA0], xmm10
00007981ddfe400d  vmovaps [rsp+0xB0], xmm11
00007981ddfe4016  vmovaps [rsp+0xC0], xmm13
00007981ddfe401f  vmovaps [rsp+0xD0], xmm14
00007981ddfe4028  vmovaps [rsp+0xE0], xmm15
00007981ddfe4031  sub rsp, 0x30
00007981ddfe4035  movaps [rsp], xmm12
00007981ddfe403a  movaps [rsp+0x10], xmm14
00007981ddfe4040  movaps [rsp+0x20], xmm1
00007981ddfe4045  lea rdi, [rsp]
00007981ddfe4049  mov esi, 0x00
00007981ddfe404e  mov rax, 0x5782A6EB3530
00007981ddfe4058  call rax
00007981ddfe405a  movaps xmm12, [rsp]
00007981ddfe405f  add rsp, 0x30
00007981ddfe4063  vmovaps xmm0, [rsp]
00007981ddfe4068  vmovaps xmm1, [rsp+0x10]
00007981ddfe406e  vmovaps xmm2, [rsp+0x20]
00007981ddfe4074  vmovaps xmm3, [rsp+0x30]
00007981ddfe407a  vmovaps xmm4, [rsp+0x40]
00007981ddfe4080  vmovaps xmm5, [rsp+0x50]
00007981ddfe4086  vmovaps xmm6, [rsp+0x60]
00007981ddfe408c  vmovaps xmm7, [rsp+0x70]
00007981ddfe4092  vmovaps xmm8, [rsp+0x80]
00007981ddfe409b  vmovaps xmm9, [rsp+0x90]
00007981ddfe40a4  vmovaps xmm10, [rsp+0xA0]
00007981ddfe40ad  vmovaps xmm11, [rsp+0xB0]
00007981ddfe40b6  vmovaps xmm13, [rsp+0xC0]
00007981ddfe40bf  vmovaps xmm14, [rsp+0xD0]
00007981ddfe40c8  vmovaps xmm15, [rsp+0xE0]
00007981ddfe40d1  add rsp, 0xF0
00007981ddfe40d8  pop r11
00007981ddfe40da  pop r10
00007981ddfe40dc  pop r9
00007981ddfe40de  pop r8
00007981ddfe40e0  pop rsi
00007981ddfe40e1  pop rdi
00007981ddfe40e2  pop rdx
00007981ddfe40e3  pop rcx
00007981ddfe40e4  pop rax
00007981ddfe40e5  add rsp, 0x08
00007981ddfe40e9  jmp 0x00007981DDFDF8DC
00007981ddfe40ee  sub rsp, 0x08
00007981ddfe40f2  push rax
00007981ddfe40f3  push rcx
00007981ddfe40f4  push rdx
00007981ddfe40f5  push rdi
00007981ddfe40f6  push rsi
00007981ddfe40f7  push r8
00007981ddfe40f9  push r9
00007981ddfe40fb  push r10
00007981ddfe40fd  push r11
00007981ddfe40ff  sub rsp, 0xF0
00007981ddfe4106  vmovaps [rsp], xmm0
00007981ddfe410b  vmovaps [rsp+0x10], xmm1
00007981ddfe4111  vmovaps [rsp+0x20], xmm2
00007981ddfe4117  vmovaps [rsp+0x30], xmm3
00007981ddfe411d  vmovaps [rsp+0x40], xmm4
00007981ddfe4123  vmovaps [rsp+0x50], xmm5
00007981ddfe4129  vmovaps [rsp+0x60], xmm6
00007981ddfe412f  vmovaps [rsp+0x70], xmm7
00007981ddfe4135  vmovaps [rsp+0x80], xmm8
00007981ddfe413e  vmovaps [rsp+0x90], xmm9
00007981ddfe4147  vmovaps [rsp+0xA0], xmm10
00007981ddfe4150  vmovaps [rsp+0xB0], xmm11
00007981ddfe4159  vmovaps [rsp+0xC0], xmm12
00007981ddfe4162  vmovaps [rsp+0xD0], xmm13
00007981ddfe416b  vmovaps [rsp+0xE0], xmm15
00007981ddfe4174  sub rsp, 0x30
00007981ddfe4178  movaps [rsp], xmm14
00007981ddfe417d  movaps [rsp+0x10], xmm9
00007981ddfe4183  movaps [rsp+0x20], xmm1
00007981ddfe4188  lea rdi, [rsp]
00007981ddfe418c  mov esi, 0x00
00007981ddfe4191  mov rax, 0x5782A6EB3530
00007981ddfe419b  call rax
00007981ddfe419d  movaps xmm14, [rsp]
00007981ddfe41a2  add rsp, 0x30
00007981ddfe41a6  vmovaps xmm0, [rsp]
00007981ddfe41ab  vmovaps xmm1, [rsp+0x10]
00007981ddfe41b1  vmovaps xmm2, [rsp+0x20]
00007981ddfe41b7  vmovaps xmm3, [rsp+0x30]
00007981ddfe41bd  vmovaps xmm4, [rsp+0x40]
00007981ddfe41c3  vmovaps xmm5, [rsp+0x50]
00007981ddfe41c9  vmovaps xmm6, [rsp+0x60]
00007981ddfe41cf  vmovaps xmm7, [rsp+0x70]
00007981ddfe41d5  vmovaps xmm8, [rsp+0x80]
00007981ddfe41de  vmovaps xmm9, [rsp+0x90]
00007981ddfe41e7  vmovaps xmm10, [rsp+0xA0]
00007981ddfe41f0  vmovaps xmm11, [rsp+0xB0]
00007981ddfe41f9  vmovaps xmm12, [rsp+0xC0]
00007981ddfe4202  vmovaps xmm13, [rsp+0xD0]
00007981ddfe420b  vmovaps xmm15, [rsp+0xE0]
00007981ddfe4214  add rsp, 0xF0
00007981ddfe421b  pop r11
00007981ddfe421d  pop r10
00007981ddfe421f  pop r9
00007981ddfe4221  pop r8
00007981ddfe4223  pop rsi
00007981ddfe4224  pop rdi
00007981ddfe4225  pop rdx
00007981ddfe4226  pop rcx
00007981ddfe4227  pop rax
00007981ddfe4228  add rsp, 0x08
00007981ddfe422c  jmp 0x00007981DDFDF90B
00007981ddfe4231  sub rsp, 0x08
00007981ddfe4235  push rax
00007981ddfe4236  push rcx
00007981ddfe4237  push rdx
00007981ddfe4238  push rdi
00007981ddfe4239  push rsi
00007981ddfe423a  push r8
00007981ddfe423c  push r9
00007981ddfe423e  push r10
00007981ddfe4240  push r11
00007981ddfe4242  sub rsp, 0xF0
00007981ddfe4249  vmovaps [rsp], xmm0
00007981ddfe424e  vmovaps [rsp+0x10], xmm2
00007981ddfe4254  vmovaps [rsp+0x20], xmm3
00007981ddfe425a  vmovaps [rsp+0x30], xmm4
00007981ddfe4260  vmovaps [rsp+0x40], xmm5
00007981ddfe4266  vmovaps [rsp+0x50], xmm6
00007981ddfe426c  vmovaps [rsp+0x60], xmm7
00007981ddfe4272  vmovaps [rsp+0x70], xmm8
00007981ddfe4278  vmovaps [rsp+0x80], xmm9
00007981ddfe4281  vmovaps [rsp+0x90], xmm10
00007981ddfe428a  vmovaps [rsp+0xA0], xmm11
00007981ddfe4293  vmovaps [rsp+0xB0], xmm12
00007981ddfe429c  vmovaps [rsp+0xC0], xmm13
00007981ddfe42a5  vmovaps [rsp+0xD0], xmm14
00007981ddfe42ae  vmovaps [rsp+0xE0], xmm15
00007981ddfe42b7  sub rsp, 0x30
00007981ddfe42bb  movaps [rsp], xmm1
00007981ddfe42bf  movaps [rsp+0x10], xmm13
00007981ddfe42c5  movaps [rsp+0x20], xmm8
00007981ddfe42cb  lea rdi, [rsp]
00007981ddfe42cf  mov esi, 0x00
00007981ddfe42d4  mov rax, 0x5782A6EB3530
00007981ddfe42de  call rax
00007981ddfe42e0  movaps xmm1, [rsp]
00007981ddfe42e4  add rsp, 0x30
00007981ddfe42e8  vmovaps xmm0, [rsp]
00007981ddfe42ed  vmovaps xmm2, [rsp+0x10]
00007981ddfe42f3  vmovaps xmm3, [rsp+0x20]
00007981ddfe42f9  vmovaps xmm4, [rsp+0x30]
00007981ddfe42ff  vmovaps xmm5, [rsp+0x40]
00007981ddfe4305  vmovaps xmm6, [rsp+0x50]
00007981ddfe430b  vmovaps xmm7, [rsp+0x60]
00007981ddfe4311  vmovaps xmm8, [rsp+0x70]
00007981ddfe4317  vmovaps xmm9, [rsp+0x80]
00007981ddfe4320  vmovaps xmm10, [rsp+0x90]
00007981ddfe4329  vmovaps xmm11, [rsp+0xA0]
00007981ddfe4332  vmovaps xmm12, [rsp+0xB0]
00007981ddfe433b  vmovaps xmm13, [rsp+0xC0]
00007981ddfe4344  vmovaps xmm14, [rsp+0xD0]
00007981ddfe434d  vmovaps xmm15, [rsp+0xE0]
00007981ddfe4356  add rsp, 0xF0
00007981ddfe435d  pop r11
00007981ddfe435f  pop r10
00007981ddfe4361  pop r9
00007981ddfe4363  pop r8
00007981ddfe4365  pop rsi
00007981ddfe4366  pop rdi
00007981ddfe4367  pop rdx
00007981ddfe4368  pop rcx
00007981ddfe4369  pop rax
00007981ddfe436a  add rsp, 0x08
00007981ddfe436e  jmp 0x00007981DDFDF92D
00007981ddfe4373  call 0x00007981DDE0C260
00007981ddfe4378  jmp 0x00007981DDFDF93B
00007981ddfe437d  call 0x00007981DDEBD750
00007981ddfe4382  jmp 0x00007981DDFDF945
00007981ddfe4387  sub rsp, 0x08
00007981ddfe438b  push rax
00007981ddfe438c  push rcx
00007981ddfe438d  push rdx
00007981ddfe438e  push rdi
00007981ddfe438f  push rsi
00007981ddfe4390  push r8
00007981ddfe4392  push r9
00007981ddfe4394  push r10
00007981ddfe4396  push r11
00007981ddfe4398  sub rsp, 0xF0
00007981ddfe439f  vmovaps [rsp], xmm0
00007981ddfe43a4  vmovaps [rsp+0x10], xmm1
00007981ddfe43aa  vmovaps [rsp+0x20], xmm2
00007981ddfe43b0  vmovaps [rsp+0x30], xmm3
00007981ddfe43b6  vmovaps [rsp+0x40], xmm4
00007981ddfe43bc  vmovaps [rsp+0x50], xmm5
00007981ddfe43c2  vmovaps [rsp+0x60], xmm6
00007981ddfe43c8  vmovaps [rsp+0x70], xmm7
00007981ddfe43ce  vmovaps [rsp+0x80], xmm9
00007981ddfe43d7  vmovaps [rsp+0x90], xmm10
00007981ddfe43e0  vmovaps [rsp+0xA0], xmm11
00007981ddfe43e9  vmovaps [rsp+0xB0], xmm12
00007981ddfe43f2  vmovaps [rsp+0xC0], xmm13
00007981ddfe43fb  vmovaps [rsp+0xD0], xmm14
00007981ddfe4404  vmovaps [rsp+0xE0], xmm15
00007981ddfe440d  sub rsp, 0x30
00007981ddfe4411  movaps [rsp], xmm8
00007981ddfe4416  movaps [rsp+0x10], xmm15
00007981ddfe441c  movaps [rsp+0x20], xmm7
00007981ddfe4421  lea rdi, [rsp]
00007981ddfe4425  mov esi, 0x00
00007981ddfe442a  mov rax, 0x5782A6EB3530
00007981ddfe4434  call rax
00007981ddfe4436  movaps xmm8, [rsp]
00007981ddfe443b  add rsp, 0x30
00007981ddfe443f  vmovaps xmm0, [rsp]
00007981ddfe4444  vmovaps xmm1, [rsp+0x10]
00007981ddfe444a  vmovaps xmm2, [rsp+0x20]
00007981ddfe4450  vmovaps xmm3, [rsp+0x30]
00007981ddfe4456  vmovaps xmm4, [rsp+0x40]
00007981ddfe445c  vmovaps xmm5, [rsp+0x50]
00007981ddfe4462  vmovaps xmm6, [rsp+0x60]
00007981ddfe4468  vmovaps xmm7, [rsp+0x70]
00007981ddfe446e  vmovaps xmm9, [rsp+0x80]
00007981ddfe4477  vmovaps xmm10, [rsp+0x90]
00007981ddfe4480  vmovaps xmm11, [rsp+0xA0]
00007981ddfe4489  vmovaps xmm12, [rsp+0xB0]
00007981ddfe4492  vmovaps xmm13, [rsp+0xC0]
00007981ddfe449b  vmovaps xmm14, [rsp+0xD0]
00007981ddfe44a4  vmovaps xmm15, [rsp+0xE0]
00007981ddfe44ad  add rsp, 0xF0
00007981ddfe44b4  pop r11
00007981ddfe44b6  pop r10
00007981ddfe44b8  pop r9
00007981ddfe44ba  pop r8
00007981ddfe44bc  pop rsi
00007981ddfe44bd  pop rdi
00007981ddfe44be  pop rdx
00007981ddfe44bf  pop rcx
00007981ddfe44c0  pop rax
00007981ddfe44c1  add rsp, 0x08
00007981ddfe44c5  jmp 0x00007981DDFDF967
00007981ddfe44ca  sub rsp, 0x08
00007981ddfe44ce  push rax
00007981ddfe44cf  push rcx
00007981ddfe44d0  push rdx
00007981ddfe44d1  push rdi
00007981ddfe44d2  push rsi
00007981ddfe44d3  push r8
00007981ddfe44d5  push r9
00007981ddfe44d7  push r10
00007981ddfe44d9  push r11
00007981ddfe44db  sub rsp, 0xF0
00007981ddfe44e2  vmovaps [rsp], xmm0
00007981ddfe44e7  vmovaps [rsp+0x10], xmm1
00007981ddfe44ed  vmovaps [rsp+0x20], xmm2
00007981ddfe44f3  vmovaps [rsp+0x30], xmm3
00007981ddfe44f9  vmovaps [rsp+0x40], xmm4
00007981ddfe44ff  vmovaps [rsp+0x50], xmm5
00007981ddfe4505  vmovaps [rsp+0x60], xmm6
00007981ddfe450b  vmovaps [rsp+0x70], xmm8
00007981ddfe4511  vmovaps [rsp+0x80], xmm9
00007981ddfe451a  vmovaps [rsp+0x90], xmm10
00007981ddfe4523  vmovaps [rsp+0xA0], xmm11
00007981ddfe452c  vmovaps [rsp+0xB0], xmm12
00007981ddfe4535  vmovaps [rsp+0xC0], xmm13
00007981ddfe453e  vmovaps [rsp+0xD0], xmm14
00007981ddfe4547  vmovaps [rsp+0xE0], xmm15
00007981ddfe4550  sub rsp, 0x30
00007981ddfe4554  movaps [rsp], xmm7
00007981ddfe4558  movaps [rsp+0x10], xmm9
00007981ddfe455e  movaps [rsp+0x20], xmm15
00007981ddfe4564  lea rdi, [rsp]
00007981ddfe4568  mov esi, 0x00
00007981ddfe456d  mov rax, 0x5782A6EB3530
00007981ddfe4577  call rax
00007981ddfe4579  movaps xmm7, [rsp]
00007981ddfe457d  add rsp, 0x30
00007981ddfe4581  vmovaps xmm0, [rsp]
00007981ddfe4586  vmovaps xmm1, [rsp+0x10]
00007981ddfe458c  vmovaps xmm2, [rsp+0x20]
00007981ddfe4592  vmovaps xmm3, [rsp+0x30]
00007981ddfe4598  vmovaps xmm4, [rsp+0x40]
00007981ddfe459e  vmovaps xmm5, [rsp+0x50]
00007981ddfe45a4  vmovaps xmm6, [rsp+0x60]
00007981ddfe45aa  vmovaps xmm8, [rsp+0x70]
00007981ddfe45b0  vmovaps xmm9, [rsp+0x80]
00007981ddfe45b9  vmovaps xmm10, [rsp+0x90]
00007981ddfe45c2  vmovaps xmm11, [rsp+0xA0]
00007981ddfe45cb  vmovaps xmm12, [rsp+0xB0]
00007981ddfe45d4  vmovaps xmm13, [rsp+0xC0]
00007981ddfe45dd  vmovaps xmm14, [rsp+0xD0]
00007981ddfe45e6  vmovaps xmm15, [rsp+0xE0]
00007981ddfe45ef  add rsp, 0xF0
00007981ddfe45f6  pop r11
00007981ddfe45f8  pop r10
00007981ddfe45fa  pop r9
00007981ddfe45fc  pop r8
00007981ddfe45fe  pop rsi
00007981ddfe45ff  pop rdi
00007981ddfe4600  pop rdx
00007981ddfe4601  pop rcx
00007981ddfe4602  pop rax
00007981ddfe4603  add rsp, 0x08
00007981ddfe4607  jmp 0x00007981DDFDF994
00007981ddfe460c  sub rsp, 0x08
00007981ddfe4610  push rax
00007981ddfe4611  push rcx
00007981ddfe4612  push rdx
00007981ddfe4613  push rdi
00007981ddfe4614  push rsi
00007981ddfe4615  push r8
00007981ddfe4617  push r9
00007981ddfe4619  push r10
00007981ddfe461b  push r11
00007981ddfe461d  sub rsp, 0xF0
00007981ddfe4624  vmovaps [rsp], xmm0
00007981ddfe4629  vmovaps [rsp+0x10], xmm1
00007981ddfe462f  vmovaps [rsp+0x20], xmm2
00007981ddfe4635  vmovaps [rsp+0x30], xmm3
00007981ddfe463b  vmovaps [rsp+0x40], xmm4
00007981ddfe4641  vmovaps [rsp+0x50], xmm5
00007981ddfe4647  vmovaps [rsp+0x60], xmm6
00007981ddfe464d  vmovaps [rsp+0x70], xmm7
00007981ddfe4653  vmovaps [rsp+0x80], xmm8
00007981ddfe465c  vmovaps [rsp+0x90], xmm10
00007981ddfe4665  vmovaps [rsp+0xA0], xmm11
00007981ddfe466e  vmovaps [rsp+0xB0], xmm12
00007981ddfe4677  vmovaps [rsp+0xC0], xmm13
00007981ddfe4680  vmovaps [rsp+0xD0], xmm14
00007981ddfe4689  vmovaps [rsp+0xE0], xmm15
00007981ddfe4692  sub rsp, 0x30
00007981ddfe4696  movaps [rsp], xmm9
00007981ddfe469b  movaps [rsp+0x10], xmm13
00007981ddfe46a1  movaps [rsp+0x20], xmm15
00007981ddfe46a7  lea rdi, [rsp]
00007981ddfe46ab  mov esi, 0x00
00007981ddfe46b0  mov rax, 0x5782A6EB3530
00007981ddfe46ba  call rax
00007981ddfe46bc  movaps xmm9, [rsp]
00007981ddfe46c1  add rsp, 0x30
00007981ddfe46c5  vmovaps xmm0, [rsp]
00007981ddfe46ca  vmovaps xmm1, [rsp+0x10]
00007981ddfe46d0  vmovaps xmm2, [rsp+0x20]
00007981ddfe46d6  vmovaps xmm3, [rsp+0x30]
00007981ddfe46dc  vmovaps xmm4, [rsp+0x40]
00007981ddfe46e2  vmovaps xmm5, [rsp+0x50]
00007981ddfe46e8  vmovaps xmm6, [rsp+0x60]
00007981ddfe46ee  vmovaps xmm7, [rsp+0x70]
00007981ddfe46f4  vmovaps xmm8, [rsp+0x80]
00007981ddfe46fd  vmovaps xmm10, [rsp+0x90]
00007981ddfe4706  vmovaps xmm11, [rsp+0xA0]
00007981ddfe470f  vmovaps xmm12, [rsp+0xB0]
00007981ddfe4718  vmovaps xmm13, [rsp+0xC0]
00007981ddfe4721  vmovaps xmm14, [rsp+0xD0]
00007981ddfe472a  vmovaps xmm15, [rsp+0xE0]
00007981ddfe4733  add rsp, 0xF0
00007981ddfe473a  pop r11
00007981ddfe473c  pop r10
00007981ddfe473e  pop r9
00007981ddfe4740  pop r8
00007981ddfe4742  pop rsi
00007981ddfe4743  pop rdi
00007981ddfe4744  pop rdx
00007981ddfe4745  pop rcx
00007981ddfe4746  pop rax
00007981ddfe4747  add rsp, 0x08
00007981ddfe474b  jmp 0x00007981DDFDF9C2
00007981ddfe4750  sub rsp, 0x08
00007981ddfe4754  push rax
00007981ddfe4755  push rcx
00007981ddfe4756  push rdx
00007981ddfe4757  push rdi
00007981ddfe4758  push rsi
00007981ddfe4759  push r8
00007981ddfe475b  push r9
00007981ddfe475d  push r10
00007981ddfe475f  push r11
00007981ddfe4761  sub rsp, 0xF0
00007981ddfe4768  vmovaps [rsp], xmm0
00007981ddfe476d  vmovaps [rsp+0x10], xmm1
00007981ddfe4773  vmovaps [rsp+0x20], xmm2
00007981ddfe4779  vmovaps [rsp+0x30], xmm3
00007981ddfe477f  vmovaps [rsp+0x40], xmm4
00007981ddfe4785  vmovaps [rsp+0x50], xmm5
00007981ddfe478b  vmovaps [rsp+0x60], xmm6
00007981ddfe4791  vmovaps [rsp+0x70], xmm7
00007981ddfe4797  vmovaps [rsp+0x80], xmm8
00007981ddfe47a0  vmovaps [rsp+0x90], xmm9
00007981ddfe47a9  vmovaps [rsp+0xA0], xmm10
00007981ddfe47b2  vmovaps [rsp+0xB0], xmm11
00007981ddfe47bb  vmovaps [rsp+0xC0], xmm12
00007981ddfe47c4  vmovaps [rsp+0xD0], xmm13
00007981ddfe47cd  vmovaps [rsp+0xE0], xmm14
00007981ddfe47d6  sub rsp, 0x30
00007981ddfe47da  movaps [rsp], xmm15
00007981ddfe47df  movaps [rsp+0x10], xmm11
00007981ddfe47e5  movaps [rsp+0x20], xmm12
00007981ddfe47eb  lea rdi, [rsp]
00007981ddfe47ef  mov esi, 0x00
00007981ddfe47f4  mov rax, 0x5782A6EB3530
00007981ddfe47fe  call rax
00007981ddfe4800  movaps xmm15, [rsp]
00007981ddfe4805  add rsp, 0x30
00007981ddfe4809  vmovaps xmm0, [rsp]
00007981ddfe480e  vmovaps xmm1, [rsp+0x10]
00007981ddfe4814  vmovaps xmm2, [rsp+0x20]
00007981ddfe481a  vmovaps xmm3, [rsp+0x30]
00007981ddfe4820  vmovaps xmm4, [rsp+0x40]
00007981ddfe4826  vmovaps xmm5, [rsp+0x50]
00007981ddfe482c  vmovaps xmm6, [rsp+0x60]
00007981ddfe4832  vmovaps xmm7, [rsp+0x70]
00007981ddfe4838  vmovaps xmm8, [rsp+0x80]
00007981ddfe4841  vmovaps xmm9, [rsp+0x90]
00007981ddfe484a  vmovaps xmm10, [rsp+0xA0]
00007981ddfe4853  vmovaps xmm11, [rsp+0xB0]
00007981ddfe485c  vmovaps xmm12, [rsp+0xC0]
00007981ddfe4865  vmovaps xmm13, [rsp+0xD0]
00007981ddfe486e  vmovaps xmm14, [rsp+0xE0]
00007981ddfe4877  add rsp, 0xF0
00007981ddfe487e  pop r11
00007981ddfe4880  pop r10
00007981ddfe4882  pop r9
00007981ddfe4884  pop r8
00007981ddfe4886  pop rsi
00007981ddfe4887  pop rdi
00007981ddfe4888  pop rdx
00007981ddfe4889  pop rcx
00007981ddfe488a  pop rax
00007981ddfe488b  add rsp, 0x08
00007981ddfe488f  jmp 0x00007981DDFDF9DD
00007981ddfe4894  sub rsp, 0x08
00007981ddfe4898  push rax
00007981ddfe4899  push rcx
00007981ddfe489a  push rdx
00007981ddfe489b  push rdi
00007981ddfe489c  push rsi
00007981ddfe489d  push r8
00007981ddfe489f  push r9
00007981ddfe48a1  push r10
00007981ddfe48a3  push r11
00007981ddfe48a5  sub rsp, 0xF0
00007981ddfe48ac  vmovaps [rsp], xmm0
00007981ddfe48b1  vmovaps [rsp+0x10], xmm1
00007981ddfe48b7  vmovaps [rsp+0x20], xmm2
00007981ddfe48bd  vmovaps [rsp+0x30], xmm3
00007981ddfe48c3  vmovaps [rsp+0x40], xmm4
00007981ddfe48c9  vmovaps [rsp+0x50], xmm5
00007981ddfe48cf  vmovaps [rsp+0x60], xmm6
00007981ddfe48d5  vmovaps [rsp+0x70], xmm7
00007981ddfe48db  vmovaps [rsp+0x80], xmm8
00007981ddfe48e4  vmovaps [rsp+0x90], xmm9
00007981ddfe48ed  vmovaps [rsp+0xA0], xmm10
00007981ddfe48f6  vmovaps [rsp+0xB0], xmm11
00007981ddfe48ff  vmovaps [rsp+0xC0], xmm12
00007981ddfe4908  vmovaps [rsp+0xD0], xmm14
00007981ddfe4911  vmovaps [rsp+0xE0], xmm15
00007981ddfe491a  sub rsp, 0x30
00007981ddfe491e  movaps [rsp], xmm13
00007981ddfe4923  movaps [rsp+0x10], xmm10
00007981ddfe4929  movaps [rsp+0x20], xmm14
00007981ddfe492f  lea rdi, [rsp]
00007981ddfe4933  mov esi, 0x00
00007981ddfe4938  mov rax, 0x5782A6EB3530
00007981ddfe4942  call rax
00007981ddfe4944  movaps xmm13, [rsp]
00007981ddfe4949  add rsp, 0x30
00007981ddfe494d  vmovaps xmm0, [rsp]
00007981ddfe4952  vmovaps xmm1, [rsp+0x10]
00007981ddfe4958  vmovaps xmm2, [rsp+0x20]
00007981ddfe495e  vmovaps xmm3, [rsp+0x30]
00007981ddfe4964  vmovaps xmm4, [rsp+0x40]
00007981ddfe496a  vmovaps xmm5, [rsp+0x50]
00007981ddfe4970  vmovaps xmm6, [rsp+0x60]
00007981ddfe4976  vmovaps xmm7, [rsp+0x70]
00007981ddfe497c  vmovaps xmm8, [rsp+0x80]
00007981ddfe4985  vmovaps xmm9, [rsp+0x90]
00007981ddfe498e  vmovaps xmm10, [rsp+0xA0]
00007981ddfe4997  vmovaps xmm11, [rsp+0xB0]
00007981ddfe49a0  vmovaps xmm12, [rsp+0xC0]
00007981ddfe49a9  vmovaps xmm14, [rsp+0xD0]
00007981ddfe49b2  vmovaps xmm15, [rsp+0xE0]
00007981ddfe49bb  add rsp, 0xF0
00007981ddfe49c2  pop r11
00007981ddfe49c4  pop r10
00007981ddfe49c6  pop r9
00007981ddfe49c8  pop r8
00007981ddfe49ca  pop rsi
00007981ddfe49cb  pop rdi
00007981ddfe49cc  pop rdx
00007981ddfe49cd  pop rcx
00007981ddfe49ce  pop rax
00007981ddfe49cf  add rsp, 0x08
00007981ddfe49d3  jmp 0x00007981DDFDFA00
00007981ddfe49d8  sub rsp, 0x08
00007981ddfe49dc  push rax
00007981ddfe49dd  push rcx
00007981ddfe49de  push rdx
00007981ddfe49df  push rdi
00007981ddfe49e0  push rsi
00007981ddfe49e1  push r8
00007981ddfe49e3  push r9
00007981ddfe49e5  push r10
00007981ddfe49e7  push r11
00007981ddfe49e9  sub rsp, 0xF0
00007981ddfe49f0  vmovaps [rsp], xmm0
00007981ddfe49f5  vmovaps [rsp+0x10], xmm1
00007981ddfe49fb  vmovaps [rsp+0x20], xmm2
00007981ddfe4a01  vmovaps [rsp+0x30], xmm3
00007981ddfe4a07  vmovaps [rsp+0x40], xmm4
00007981ddfe4a0d  vmovaps [rsp+0x50], xmm5
00007981ddfe4a13  vmovaps [rsp+0x60], xmm6
00007981ddfe4a19  vmovaps [rsp+0x70], xmm7
00007981ddfe4a1f  vmovaps [rsp+0x80], xmm8
00007981ddfe4a28  vmovaps [rsp+0x90], xmm9
00007981ddfe4a31  vmovaps [rsp+0xA0], xmm10
00007981ddfe4a3a  vmovaps [rsp+0xB0], xmm11
00007981ddfe4a43  vmovaps [rsp+0xC0], xmm12
00007981ddfe4a4c  vmovaps [rsp+0xD0], xmm13
00007981ddfe4a55  vmovaps [rsp+0xE0], xmm15
00007981ddfe4a5e  sub rsp, 0x30
00007981ddfe4a62  movaps [rsp], xmm14
00007981ddfe4a67  movaps [rsp+0x10], xmm1
00007981ddfe4a6c  movaps [rsp+0x20], xmm7
00007981ddfe4a71  lea rdi, [rsp]
00007981ddfe4a75  mov esi, 0x00
00007981ddfe4a7a  mov rax, 0x5782A6EB3530
00007981ddfe4a84  call rax
00007981ddfe4a86  movaps xmm14, [rsp]
00007981ddfe4a8b  add rsp, 0x30
00007981ddfe4a8f  vmovaps xmm0, [rsp]
00007981ddfe4a94  vmovaps xmm1, [rsp+0x10]
00007981ddfe4a9a  vmovaps xmm2, [rsp+0x20]
00007981ddfe4aa0  vmovaps xmm3, [rsp+0x30]
00007981ddfe4aa6  vmovaps xmm4, [rsp+0x40]
00007981ddfe4aac  vmovaps xmm5, [rsp+0x50]
00007981ddfe4ab2  vmovaps xmm6, [rsp+0x60]
00007981ddfe4ab8  vmovaps xmm7, [rsp+0x70]
00007981ddfe4abe  vmovaps xmm8, [rsp+0x80]
00007981ddfe4ac7  vmovaps xmm9, [rsp+0x90]
00007981ddfe4ad0  vmovaps xmm10, [rsp+0xA0]
00007981ddfe4ad9  vmovaps xmm11, [rsp+0xB0]
00007981ddfe4ae2  vmovaps xmm12, [rsp+0xC0]
00007981ddfe4aeb  vmovaps xmm13, [rsp+0xD0]
00007981ddfe4af4  vmovaps xmm15, [rsp+0xE0]
00007981ddfe4afd  add rsp, 0xF0
00007981ddfe4b04  pop r11
00007981ddfe4b06  pop r10
00007981ddfe4b08  pop r9
00007981ddfe4b0a  pop r8
00007981ddfe4b0c  pop rsi
00007981ddfe4b0d  pop rdi
00007981ddfe4b0e  pop rdx
00007981ddfe4b0f  pop rcx
00007981ddfe4b10  pop rax
00007981ddfe4b11  add rsp, 0x08
00007981ddfe4b15  jmp 0x00007981DDFDFA23
00007981ddfe4b1a  sub rsp, 0x08
00007981ddfe4b1e  push rax
00007981ddfe4b1f  push rcx
00007981ddfe4b20  push rdx
00007981ddfe4b21  push rdi
00007981ddfe4b22  push rsi
00007981ddfe4b23  push r8
00007981ddfe4b25  push r9
00007981ddfe4b27  push r10
00007981ddfe4b29  push r11
00007981ddfe4b2b  sub rsp, 0xF0
00007981ddfe4b32  vmovaps [rsp], xmm0
00007981ddfe4b37  vmovaps [rsp+0x10], xmm2
00007981ddfe4b3d  vmovaps [rsp+0x20], xmm3
00007981ddfe4b43  vmovaps [rsp+0x30], xmm4
00007981ddfe4b49  vmovaps [rsp+0x40], xmm5
00007981ddfe4b4f  vmovaps [rsp+0x50], xmm6
00007981ddfe4b55  vmovaps [rsp+0x60], xmm7
00007981ddfe4b5b  vmovaps [rsp+0x70], xmm8
00007981ddfe4b61  vmovaps [rsp+0x80], xmm9
00007981ddfe4b6a  vmovaps [rsp+0x90], xmm10
00007981ddfe4b73  vmovaps [rsp+0xA0], xmm11
00007981ddfe4b7c  vmovaps [rsp+0xB0], xmm12
00007981ddfe4b85  vmovaps [rsp+0xC0], xmm13
00007981ddfe4b8e  vmovaps [rsp+0xD0], xmm14
00007981ddfe4b97  vmovaps [rsp+0xE0], xmm15
00007981ddfe4ba0  sub rsp, 0x30
00007981ddfe4ba4  movaps [rsp], xmm1
00007981ddfe4ba8  movaps [rsp+0x10], xmm8
00007981ddfe4bae  movaps [rsp+0x20], xmm9
00007981ddfe4bb4  lea rdi, [rsp]
00007981ddfe4bb8  mov esi, 0x00
00007981ddfe4bbd  mov rax, 0x5782A6EB3530
00007981ddfe4bc7  call rax
00007981ddfe4bc9  movaps xmm1, [rsp]
00007981ddfe4bcd  add rsp, 0x30
00007981ddfe4bd1  vmovaps xmm0, [rsp]
00007981ddfe4bd6  vmovaps xmm2, [rsp+0x10]
00007981ddfe4bdc  vmovaps xmm3, [rsp+0x20]
00007981ddfe4be2  vmovaps xmm4, [rsp+0x30]
00007981ddfe4be8  vmovaps xmm5, [rsp+0x40]
00007981ddfe4bee  vmovaps xmm6, [rsp+0x50]
00007981ddfe4bf4  vmovaps xmm7, [rsp+0x60]
00007981ddfe4bfa  vmovaps xmm8, [rsp+0x70]
00007981ddfe4c00  vmovaps xmm9, [rsp+0x80]
00007981ddfe4c09  vmovaps xmm10, [rsp+0x90]
00007981ddfe4c12  vmovaps xmm11, [rsp+0xA0]
00007981ddfe4c1b  vmovaps xmm12, [rsp+0xB0]
00007981ddfe4c24  vmovaps xmm13, [rsp+0xC0]
00007981ddfe4c2d  vmovaps xmm14, [rsp+0xD0]
00007981ddfe4c36  vmovaps xmm15, [rsp+0xE0]
00007981ddfe4c3f  add rsp, 0xF0
00007981ddfe4c46  pop r11
00007981ddfe4c48  pop r10
00007981ddfe4c4a  pop r9
00007981ddfe4c4c  pop r8
00007981ddfe4c4e  pop rsi
00007981ddfe4c4f  pop rdi
00007981ddfe4c50  pop rdx
00007981ddfe4c51  pop rcx
00007981ddfe4c52  pop rax
00007981ddfe4c53  add rsp, 0x08
00007981ddfe4c57  jmp 0x00007981DDFDFA45
00007981ddfe4c5c  call 0x00007981DDEE5940
00007981ddfe4c61  jmp 0x00007981DDFDFA53
00007981ddfe4c66  call 0x00007981DDE0C380
00007981ddfe4c6b  jmp 0x00007981DDFDFA5D
00007981ddfe4c70  call 0x00007981DDE0D600
00007981ddfe4c75  jmp 0x00007981DDFDFA67
00007981ddfe4c7a  call 0x00007981DDDFF540
00007981ddfe4c7f  jmp 0x00007981DDFDFA71
00007981ddfe4c84  int3
00007981ddfe4c85  nop [rax+rax*1], ax
00007981ddfe4c8e  nop
00007981ddfe4c90  mov qword ptr [r15+0x40], 0x430000
00007981ddfe4c98  mov eax, 0x430CC0
00007981ddfe4c9d  mov r14, [r13+rax*1]
00007981ddfe4ca2  movq xmm1, r14
00007981ddfe4ca7  mov rax, [r15+0x50]
00007981ddfe4cab  movups xmm15, [r13+rax*1]
00007981ddfe4cb1  movaps [r15+0x120], xmm15
00007981ddfe4cb9  mov qword ptr [r15+0x48], 0x10
00007981ddfe4cc1  xor eax, eax
00007981ddfe4cc3  mov r14d, 0x10
00007981ddfe4cc9  mov r12d, 0x200
00007981ddfe4ccf  cmp r14, r12
00007981ddfe4cd2  cmc
00007981ddfe4cd3  lahf
00007981ddfe4cd4  seto al
00007981ddfe4cd7  mov [r15+0x108], eax
00007981ddfe4cde  pextrq rax, xmm15, 0x01
00007981ddfe4ce5  movq xmm14, rax
00007981ddfe4cea  movaps [r15+0x130], xmm14
00007981ddfe4cf2  movq rax, xmm1
00007981ddfe4cf7  movq r14, xmm15
00007981ddfe4cfc  vmovq xmm1, rax
00007981ddfe4d01  vmovq xmm15, r14
00007981ddfe4d06  movaps xmm13, xmm1
00007981ddfe4d0a  addsd xmm13, xmm15
00007981ddfe4d0f  ucomisd xmm13, xmm13
00007981ddfe4d14  jp 0x00007981DDFE4DD3
00007981ddfe4d1a  movq xmm13, xmm13
00007981ddfe4d1f  movq rax, xmm13
00007981ddfe4d24  movq r14, xmm14
00007981ddfe4d29  vmovq xmm1, rax
00007981ddfe4d2e  vmovq xmm15, r14
00007981ddfe4d33  movaps xmm14, xmm1
00007981ddfe4d37  addsd xmm14, xmm15
00007981ddfe4d3c  ucomisd xmm14, xmm14
00007981ddfe4d41  jp 0x00007981DDFE4E1B
00007981ddfe4d47  movq xmm14, xmm14
00007981ddfe4d4c  movaps [r15+0x110], xmm14
00007981ddfe4d54  mov eax, [r15+0x108]
00007981ddfe4d5b  sahf
00007981ddfe4d5c  jnz 0x00007981DDFE4D8E
00007981ddfe4d5e  cmp dword ptr [r15+0x318], 0x00
00007981ddfe4d66  jz 0x00007981DDFE5030
00007981ddfe4d6c  nop [rax+rax*1], ax
00007981ddfe4d75  nop [rax+rax*1], eax
00007981ddfe4d7d  mov eax, 0x410704
00007981ddfe4d82  mov [r15+0x100], rax
00007981ddfe4d89  jmp 0x00007981DDDFE110
00007981ddfe4d8e  cmp dword ptr [r15+0x318], 0x00
00007981ddfe4d96  jz 0x00007981DDFE4E70
00007981ddfe4d9c  nop [rax+rax*1], ax
00007981ddfe4da5  nop [rax+rax*1], eax
00007981ddfe4dad  mov eax, 0x4106E8
00007981ddfe4db2  mov [r15+0x100], rax
00007981ddfe4db9  jmp 0x00007981DDDFE110
00007981ddfe4dbe  int3
00007981ddfe4dbf  call 0x00007981DDE0DC20
00007981ddfe4dc4  jmp 0x00007981DDFE4CA2
00007981ddfe4dc9  call 0x00007981DDE0E760
00007981ddfe4dce  jmp 0x00007981DDFE4CB1
00007981ddfe4dd3  ucomisd xmm1, xmm15
00007981ddfe4dd8  jp 0x00007981DDFE4DE7
00007981ddfe4dda  movaps xmm13, [0x00007981DDBFE060]
00007981ddfe4de2  jmp 0x00007981DDFE4D1A
00007981ddfe4de7  vxorps xmm0, xmm1, xmm15
00007981ddfe4dec  pextrw eax, xmm0, 0x03
00007981ddfe4df1  and eax, 0x7FF8
00007981ddfe4df6  cmp eax, 0x08
00007981ddfe4df9  jnz 0x00007981DDFE4D1A
00007981ddfe4dff  movq rax, xmm15
00007981ddfe4e04  shl rax, 0x0D
00007981ddfe4e08  jbe 0x00007981DDFE4D1A
00007981ddfe4e0e  vorps xmm13, xmm15, [0x00007981DDBFE070]
00007981ddfe4e16  jmp 0x00007981DDFE4D1A
00007981ddfe4e1b  ucomisd xmm1, xmm15
00007981ddfe4e20  jp 0x00007981DDFE4E2F
00007981ddfe4e22  movaps xmm14, [0x00007981DDBFE060]
00007981ddfe4e2a  jmp 0x00007981DDFE4D47
00007981ddfe4e2f  vxorps xmm0, xmm1, xmm15
00007981ddfe4e34  pextrw eax, xmm0, 0x03
00007981ddfe4e39  and eax, 0x7FF8
00007981ddfe4e3e  cmp eax, 0x08
00007981ddfe4e41  jnz 0x00007981DDFE4D47
00007981ddfe4e47  movq rax, xmm15
00007981ddfe4e4c  shl rax, 0x0D
00007981ddfe4e50  jbe 0x00007981DDFE4D47
00007981ddfe4e56  vorps xmm14, xmm15, [0x00007981DDBFE070]
00007981ddfe4e5e  jmp 0x00007981DDFE4D47
00007981ddfe4e63  int3
00007981ddfe4e64  nop [rax+rax*1], ax
00007981ddfe4e6d  nop [rax], eax
00007981ddfe4e70  mov rax, [r15+0x48]
00007981ddfe4e74  mov r14, [r15+0x50]
00007981ddfe4e78  lea r12, [r14+rax*1]
00007981ddfe4e7c  movups xmm1, [r13+r12*1]
00007981ddfe4e82  movaps [r15+0x120], xmm1
00007981ddfe4e8a  lea r14, [rax+0x10]
00007981ddfe4e8e  mov [r15+0x48], r14
00007981ddfe4e92  xor eax, eax
00007981ddfe4e94  mov r12d, 0x200
00007981ddfe4e9a  cmp r14, r12
00007981ddfe4e9d  cmc
00007981ddfe4e9e  lahf
00007981ddfe4e9f  seto al
00007981ddfe4ea2  mov [r15+0x108], eax
00007981ddfe4ea9  pextrq rax, xmm1, 0x01
00007981ddfe4eb0  movq xmm15, rax
00007981ddfe4eb5  movaps [r15+0x130], xmm15
00007981ddfe4ebd  movaps xmm14, [r15+0x110]
00007981ddfe4ec5  movq rax, xmm14
00007981ddfe4eca  movq r14, xmm1
00007981ddfe4ecf  vmovq xmm1, rax
00007981ddfe4ed4  vmovq xmm14, r14
00007981ddfe4ed9  movaps xmm13, xmm1
00007981ddfe4edd  addsd xmm13, xmm14
00007981ddfe4ee2  ucomisd xmm13, xmm13
00007981ddfe4ee7  jp 0x00007981DDFE4F9C
00007981ddfe4eed  movq xmm13, xmm13
00007981ddfe4ef2  movq rax, xmm13
00007981ddfe4ef7  movq r14, xmm15
00007981ddfe4efc  vmovq xmm1, rax
00007981ddfe4f01  vmovq xmm15, r14
00007981ddfe4f06  movaps xmm14, xmm1
00007981ddfe4f0a  addsd xmm14, xmm15
00007981ddfe4f0f  ucomisd xmm14, xmm14
00007981ddfe4f14  jp 0x00007981DDFE4FE4
00007981ddfe4f1a  movq xmm14, xmm14
00007981ddfe4f1f  movaps [r15+0x110], xmm14
00007981ddfe4f27  mov eax, [r15+0x108]
00007981ddfe4f2e  sahf
00007981ddfe4f2f  jnz 0x00007981DDFE4F61
00007981ddfe4f31  cmp dword ptr [r15+0x318], 0x00
00007981ddfe4f39  jz 0x00007981DDFE5030
00007981ddfe4f3f  nop [rax+rax*1], ax
00007981ddfe4f48  nop [rax+rax*1], eax
00007981ddfe4f50  mov eax, 0x410704
00007981ddfe4f55  mov [r15+0x100], rax
00007981ddfe4f5c  jmp 0x00007981DDDFE110
00007981ddfe4f61  cmp dword ptr [r15+0x318], 0x00
00007981ddfe4f69  jz 0x00007981DDFE4E70
00007981ddfe4f6f  nop [rax+rax*1], ax
00007981ddfe4f78  nop [rax+rax*1], eax
00007981ddfe4f80  mov eax, 0x4106E8
00007981ddfe4f85  mov [r15+0x100], rax
00007981ddfe4f8c  jmp 0x00007981DDDFE110
00007981ddfe4f91  int3
00007981ddfe4f92  call 0x00007981DDEB52F0
00007981ddfe4f97  jmp 0x00007981DDFE4E82
00007981ddfe4f9c  ucomisd xmm1, xmm14
00007981ddfe4fa1  jp 0x00007981DDFE4FB0
00007981ddfe4fa3  movaps xmm13, [0x00007981DDBFE060]
00007981ddfe4fab  jmp 0x00007981DDFE4EED
00007981ddfe4fb0  vxorps xmm0, xmm1, xmm14
00007981ddfe4fb5  pextrw eax, xmm0, 0x03
00007981ddfe4fba  and eax, 0x7FF8
00007981ddfe4fbf  cmp eax, 0x08
00007981ddfe4fc2  jnz 0x00007981DDFE4EED
00007981ddfe4fc8  movq rax, xmm14
00007981ddfe4fcd  shl rax, 0x0D
00007981ddfe4fd1  jbe 0x00007981DDFE4EED
00007981ddfe4fd7  vorps xmm13, xmm14, [0x00007981DDBFE070]
00007981ddfe4fdf  jmp 0x00007981DDFE4EED
00007981ddfe4fe4  ucomisd xmm1, xmm15
00007981ddfe4fe9  jp 0x00007981DDFE4FF8
00007981ddfe4feb  movaps xmm14, [0x00007981DDBFE060]
00007981ddfe4ff3  jmp 0x00007981DDFE4F1A
00007981ddfe4ff8  vxorps xmm0, xmm1, xmm15
00007981ddfe4ffd  pextrw eax, xmm0, 0x03
00007981ddfe5002  and eax, 0x7FF8
00007981ddfe5007  cmp eax, 0x08
00007981ddfe500a  jnz 0x00007981DDFE4F1A
00007981ddfe5010  movq rax, xmm15
00007981ddfe5015  shl rax, 0x0D
00007981ddfe5019  jbe 0x00007981DDFE4F1A
00007981ddfe501f  vorps xmm14, xmm15, [0x00007981DDBFE070]
00007981ddfe5027  jmp 0x00007981DDFE4F1A
00007981ddfe502c  int3
00007981ddfe502d  nop [rax], eax
00007981ddfe5030  mov rax, [r15+0xF8]
00007981ddfe5037  lea r14, [rax+0x1D0]
00007981ddfe503e  mov r12, [r13+r14*1]
00007981ddfe5043  lea r14, [rax+0x1D8]
00007981ddfe504a  mov r11, [r13+r14*1]
00007981ddfe504f  mov [r15+0xA0], r12
00007981ddfe5056  mov [r15+0x98], r11
00007981ddfe505d  mov r14, [r15+0x40]
00007981ddfe5061  lea r12, [r14+0xCC0]
00007981ddfe5068  movaps xmm1, [r15+0x110]
00007981ddfe5070  movq r14, xmm1
00007981ddfe5075  mov [r13+r12*1], r14
00007981ddfe507a  lea r14, [rax+0x1C0]
00007981ddfe5081  mov r12, [r13+r14*1]
00007981ddfe5086  lea r14, [rax+0x1C8]
00007981ddfe508d  mov r11, [r13+r14*1]
00007981ddfe5092  mov [r15+0xE8], r12
00007981ddfe5099  mov [r15+0xF0], r11
00007981ddfe50a0  lea r14, [rax+0x1B0]
00007981ddfe50a7  mov r12, [r13+r14*1]
00007981ddfe50ac  lea r14, [rax+0x1B8]
00007981ddfe50b3  mov r10, [r13+r14*1]
00007981ddfe50b8  movq xmm1, r12
00007981ddfe50bd  movq xmm15, r10
00007981ddfe50c2  movq xmm1, xmm1
00007981ddfe50c6  movq xmm1, xmm1
00007981ddfe50ca  movaps [r15+0x1A0], xmm1
00007981ddfe50d2  movq xmm15, xmm15
00007981ddfe50d7  movq xmm15, xmm15
00007981ddfe50dc  movaps [r15+0x190], xmm15
00007981ddfe50e4  lea r14, [rax+0x1A0]
00007981ddfe50eb  mov r12, [r13+r14*1]
00007981ddfe50f0  lea r14, [rax+0x1A8]
00007981ddfe50f7  mov r10, [r13+r14*1]
00007981ddfe50fc  movq xmm1, r12
00007981ddfe5101  movq xmm15, r10
00007981ddfe5106  movq xmm1, xmm1
00007981ddfe510a  movq xmm1, xmm1
00007981ddfe510e  movaps [r15+0x1C0], xmm1
00007981ddfe5116  movq xmm15, xmm15
00007981ddfe511b  movq xmm15, xmm15
00007981ddfe5120  movaps [r15+0x1B0], xmm15
00007981ddfe5128  lea r14, [rax+0x190]
00007981ddfe512f  mov r12, [r13+r14*1]
00007981ddfe5134  lea r14, [rax+0x198]
00007981ddfe513b  mov r10, [r13+r14*1]
00007981ddfe5140  movq xmm1, r12
00007981ddfe5145  movq xmm15, r10
00007981ddfe514a  movq xmm1, xmm1
00007981ddfe514e  movq xmm1, xmm1
00007981ddfe5152  movaps [r15+0x1E0], xmm1
00007981ddfe515a  movq xmm15, xmm15
00007981ddfe515f  movq xmm15, xmm15
00007981ddfe5164  movaps [r15+0x1D0], xmm15
00007981ddfe516c  lea r14, [rax+0x180]
00007981ddfe5173  mov r12, [r13+r14*1]
00007981ddfe5178  lea r14, [rax+0x188]
00007981ddfe517f  mov r10, [r13+r14*1]
00007981ddfe5184  movq xmm1, r12
00007981ddfe5189  movq xmm15, r10
00007981ddfe518e  movq xmm1, xmm1
00007981ddfe5192  movq xmm1, xmm1
00007981ddfe5196  movaps [r15+0x200], xmm1
00007981ddfe519e  movq xmm15, xmm15
00007981ddfe51a3  movq xmm15, xmm15
00007981ddfe51a8  movaps [r15+0x1F0], xmm15
00007981ddfe51b0  lea r14, [rax+0x1E0]
00007981ddfe51b7  mov [r15+0xF8], r14
00007981ddfe51be  mov [r15+0x100], r11
00007981ddfe51c5  jmp 0x00007981DDFCE5C0
00007981ddfe51ca  int3
00007981ddfe51cb  call 0x00007981DDEE27E0
00007981ddfe51d0  jmp 0x00007981DDFE5043
00007981ddfe51d5  call 0x00007981DDEE1570
00007981ddfe51da  jmp 0x00007981DDFE504F
00007981ddfe51df  call 0x00007981DDEC3FE0
00007981ddfe51e4  jmp 0x00007981DDFE507A
00007981ddfe51e9  call 0x00007981DDEE27E0
00007981ddfe51ee  jmp 0x00007981DDFE5086
00007981ddfe51f3  call 0x00007981DDEE1570
00007981ddfe51f8  jmp 0x00007981DDFE5092
00007981ddfe51fd  call 0x00007981DDEE27E0
00007981ddfe5202  jmp 0x00007981DDFE50AC
00007981ddfe5207  call 0x00007981DDEE0300
00007981ddfe520c  jmp 0x00007981DDFE50B8
00007981ddfe5211  call 0x00007981DDEE27E0
00007981ddfe5216  jmp 0x00007981DDFE50F0
00007981ddfe521b  call 0x00007981DDEE0300
00007981ddfe5220  jmp 0x00007981DDFE50FC
00007981ddfe5225  call 0x00007981DDEE27E0
00007981ddfe522a  jmp 0x00007981DDFE5134
00007981ddfe522f  call 0x00007981DDEE0300
00007981ddfe5234  jmp 0x00007981DDFE5140
00007981ddfe5239  call 0x00007981DDEE27E0
00007981ddfe523e  jmp 0x00007981DDFE5178
00007981ddfe5243  call 0x00007981DDEE0300
00007981ddfe5248  jmp 0x00007981DDFE5184
00007981ddfe524d  int3
00007981ddfe524e  nop
00007981ddfe5250  mov qword ptr [r15+0x100], 0x04
00007981ddfe525b  mov esi, 0x00
00007981ddfe5260  mov edx, 0x09
00007981ddfe5265  mov rdi, 0x7FFF8877D4F0
00007981ddfe526f  mov rax, 0x5782A6D46970
00007981ddfe5279  call rax
00007981ddfe527b  cmp dword ptr [r15+0x318], 0x00
00007981ddfe5283  jnz 0x00007981DDDFE110
00007981ddfe5289  jmp 0x00007981DDDFE0A0
00007981ddfe528e  int3
00007981ddfe528f  int3
