000074ad747ce69b  nop [rax+rax*1], eax
000074ad747ce6a0  mov rax, [r15+0xF8]
000074ad747ce6a7  lea r14, [rax-0x1B0]
000074ad747ce6ae  mov [r15+0xF8], r14
000074ad747ce6b5  lea rax, [r14+0x1A0]
000074ad747ce6bc  mov r12, [r15+0xA0]
000074ad747ce6c3  mov r11, [r15+0x98]
000074ad747ce6ca  mov [r13+rax*1], r12
000074ad747ce6cf  lea rax, [r14+0x1A8]
000074ad747ce6d6  mov [r13+rax*1], r11
000074ad747ce6db  mov eax, 0x420A30
000074ad747ce6e0  movups xmm1, [r13+rax*1]
000074ad747ce6e6  mov eax, 0x4209C0
000074ad747ce6eb  movups xmm15, [r13+rax*1]
000074ad747ce6f1  mov eax, 0x420A50
000074ad747ce6f6  movups xmm14, [r13+rax*1]
000074ad747ce6fc  mov eax, 0x4209F0
000074ad747ce701  movups xmm13, [r13+rax*1]
000074ad747ce707  mov qword ptr [r15+0x98], 0x430C60
000074ad747ce712  mov eax, 0x420A60
000074ad747ce717  movups xmm12, [r13+rax*1]
000074ad747ce71d  mov eax, 0x430C60
000074ad747ce722  movups [r13+rax*1], xmm1
000074ad747ce728  mov eax, 0x430C70
000074ad747ce72d  movups [r13+rax*1], xmm15
000074ad747ce733  mov eax, 0x430C80
000074ad747ce738  movups [r13+rax*1], xmm14
000074ad747ce73e  mov eax, 0x430C90
000074ad747ce743  movups [r13+rax*1], xmm13
000074ad747ce749  mov eax, 0x4209B0
000074ad747ce74e  movups xmm14, [r13+rax*1]
000074ad747ce754  mov eax, 0x4209A0
000074ad747ce759  movups xmm13, [r13+rax*1]
000074ad747ce75f  mov eax, 0x430D60
000074ad747ce764  movups [r13+rax*1], xmm1
000074ad747ce76a  mov eax, 0x430D70
000074ad747ce76f  movups [r13+rax*1], xmm15
000074ad747ce775  mov eax, 0x430CA0
000074ad747ce77a  movups [r13+rax*1], xmm12
000074ad747ce780  mov eax, 0x430CB0
000074ad747ce785  movups [r13+rax*1], xmm14
000074ad747ce78b  mov eax, 0x420990
000074ad747ce790  movups xmm1, [r13+rax*1]
000074ad747ce796  mov eax, 0x420A00
000074ad747ce79b  movups xmm15, [r13+rax*1]
000074ad747ce7a1  mov eax, 0x430CC0
000074ad747ce7a6  movups [r13+rax*1], xmm13
000074ad747ce7ac  mov eax, 0x430CD0
000074ad747ce7b1  movups [r13+rax*1], xmm1
000074ad747ce7b7  mov eax, 0x420A10
000074ad747ce7bc  movups xmm1, [r13+rax*1]
000074ad747ce7c2  mov eax, 0x4209E0
000074ad747ce7c7  movups xmm14, [r13+rax*1]
000074ad747ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000074ad747ce7d5  mov eax, 0x430CE0
000074ad747ce7da  movups [r13+rax*1], xmm15
000074ad747ce7e0  mov eax, 0x430CF0
000074ad747ce7e5  movups [r13+rax*1], xmm1
000074ad747ce7eb  mov eax, 0x420A80
000074ad747ce7f0  movups xmm1, [r13+rax*1]
000074ad747ce7f6  mov eax, 0x420A90
000074ad747ce7fb  movups xmm15, [r13+rax*1]
000074ad747ce801  movaps [r15+0x150], xmm15
000074ad747ce809  mov qword ptr [r15+0xA0], 0x3E8
000074ad747ce814  mov eax, 0x430D00
000074ad747ce819  movups [r13+rax*1], xmm14
000074ad747ce81f  mov eax, 0x430D10
000074ad747ce824  movups [r13+rax*1], xmm1
000074ad747ce82a  mov eax, 0x420A70
000074ad747ce82f  movups xmm1, [r13+rax*1]
000074ad747ce835  mov eax, 0x420A20
000074ad747ce83a  movups xmm14, [r13+rax*1]
000074ad747ce840  movaps [r15+0x140], xmm14
000074ad747ce848  lea rax, [r14+0x150]
000074ad747ce84f  movq xmm13, qword ptr [r15+0x200]
000074ad747ce858  movq xmm12, qword ptr [r15+0x1F0]
000074ad747ce861  movq r12, xmm13
000074ad747ce866  movq r11, xmm12
000074ad747ce86b  mov [r13+rax*1], r12
000074ad747ce870  lea rax, [r14+0x158]
000074ad747ce877  mov [r13+rax*1], r11
000074ad747ce87c  mov eax, 0x430D20
000074ad747ce881  movups [r13+rax*1], xmm15
000074ad747ce887  mov eax, 0x430D30
000074ad747ce88c  movups [r13+rax*1], xmm1
000074ad747ce892  mov eax, 0x420A40
000074ad747ce897  movups xmm1, [r13+rax*1]
000074ad747ce89d  mov eax, 0x420AA8
000074ad747ce8a2  mov r12, [r13+rax*1]
000074ad747ce8a7  movq xmm15, r12
000074ad747ce8ac  mov qword ptr [r15+0x40], 0x420AB0
000074ad747ce8b4  mov eax, 0x430D40
000074ad747ce8b9  movups [r13+rax*1], xmm14
000074ad747ce8bf  mov eax, 0x430D50
000074ad747ce8c4  movups [r13+rax*1], xmm1
000074ad747ce8ca  mov eax, 0x420B10
000074ad747ce8cf  movups xmm1, [r13+rax*1]
000074ad747ce8d5  movq rax, xmm15
000074ad747ce8da  mov r12d, 0x430D80
000074ad747ce8e0  mov [r13+r12*1], rax
000074ad747ce8e5  mov eax, 0x420AF0
000074ad747ce8ea  movups xmm15, [r13+rax*1]
000074ad747ce8f0  mov eax, 0x420B00
000074ad747ce8f5  movups xmm14, [r13+rax*1]
000074ad747ce8fb  lea rax, [r14+0x130]
000074ad747ce902  movups [r13+rax*1], xmm1
000074ad747ce908  lea rax, [r14+0x160]
000074ad747ce90f  movq xmm1, qword ptr [r15+0x1E0]
000074ad747ce918  movq xmm13, qword ptr [r15+0x1D0]
000074ad747ce921  movq r12, xmm1
000074ad747ce926  movq r11, xmm13
000074ad747ce92b  mov [r13+rax*1], r12
000074ad747ce930  lea rax, [r14+0x168]
000074ad747ce937  mov [r13+rax*1], r11
000074ad747ce93c  lea rax, [r14+0x110]
000074ad747ce943  movups [r13+rax*1], xmm15
000074ad747ce949  lea rax, [r14+0x120]
000074ad747ce950  movups [r13+rax*1], xmm14
000074ad747ce956  mov eax, 0x420AB0
000074ad747ce95b  movups xmm1, [r13+rax*1]
000074ad747ce961  mov eax, 0x420AC0
000074ad747ce966  movups xmm15, [r13+rax*1]
000074ad747ce96c  movaps [r15+0x120], xmm15
000074ad747ce974  lea rax, [r14+0x170]
000074ad747ce97b  movq xmm14, qword ptr [r15+0x1C0]
000074ad747ce984  movq xmm13, qword ptr [r15+0x1B0]
000074ad747ce98d  movq r12, xmm14
000074ad747ce992  movq r11, xmm13
000074ad747ce997  mov [r13+rax*1], r12
000074ad747ce99c  lea rax, [r14+0x178]
000074ad747ce9a3  mov [r13+rax*1], r11
000074ad747ce9a8  lea rax, [r14+0x180]
000074ad747ce9af  movq xmm14, qword ptr [r15+0x1A0]
000074ad747ce9b8  movq xmm13, qword ptr [r15+0x190]
000074ad747ce9c1  movq r12, xmm14
000074ad747ce9c6  movq r11, xmm13
000074ad747ce9cb  mov [r13+rax*1], r12
000074ad747ce9d0  lea rax, [r14+0x188]
000074ad747ce9d7  mov [r13+rax*1], r11
000074ad747ce9dc  lea rax, [r14+0xD0]
000074ad747ce9e3  movups [r13+rax*1], xmm1
000074ad747ce9e9  lea rax, [r14+0xE0]
000074ad747ce9f0  movups [r13+rax*1], xmm15
000074ad747ce9f6  mov eax, 0x420AD0
000074ad747ce9fb  movups xmm1, [r13+rax*1]
000074ad747cea01  mov eax, 0x420AE0
000074ad747cea06  movups xmm15, [r13+rax*1]
000074ad747cea0c  movaps [r15+0x110], xmm1
000074ad747cea14  movaps [r15+0x130], xmm15
000074ad747cea1c  lea rax, [r14+0x190]
000074ad747cea23  mov r12, [r15+0xE8]
000074ad747cea2a  mov r11, [r15+0xF0]
000074ad747cea31  mov [r13+rax*1], r12
000074ad747cea36  lea rax, [r14+0x198]
000074ad747cea3d  mov [r13+rax*1], r11
000074ad747cea42  mov eax, 0x430D88
000074ad747cea47  mov r12d, 0x421DF8D3
000074ad747cea4d  mov [r13+rax*1], r12d
000074ad747cea52  lea rax, [r14+0xF0]
000074ad747cea59  movups [r13+rax*1], xmm1
000074ad747cea5f  lea rax, [r14+0x100]
000074ad747cea66  movups [r13+rax*1], xmm15
000074ad747cea6c  lea rax, [r14+0xD0]
000074ad747cea73  mov [r15], rax
000074ad747cea76  mov qword ptr [r15+0x08], 0x430C60
000074ad747cea7e  mov qword ptr [r15+0x10], 0x12C
000074ad747cea86  mov qword ptr [r15+0xF0], 0x410284
000074ad747cea91  mov r14d, [r15+0x320]
000074ad747cea98  mov eax, 0x410284
000074ad747cea9d  mov rcx, 0x74AD747D07C0
000074ad747ceaa7  mov [r15+r14*8+0x328], rax
000074ad747ceaaf  mov [r15+r14*8+0x368], rcx
000074ad747ceab7  add r14d, 0x01
000074ad747ceabb  and r14d, 0x07
000074ad747ceabf  mov [r15+0x320], r14d
000074ad747ceac6  cmp dword ptr [r15+0x318], 0x00
000074ad747ceace  jz 0x000074AD747CED70
000074ad747cead4  nop [rax+rax*1], ax
000074ad747ceadd  nop [rax+rax*1], eax
000074ad747ceae5  mov eax, 0x4106BC
000074ad747ceaea  mov [r15+0x100], rax
000074ad747ceaf1  jmp 0x000074AD745FE110
000074ad747ceaf6  int3
000074ad747ceaf7  call 0x000074AD7460BC20
000074ad747ceafc  jmp 0x000074AD747CE6CF
000074ad747ceb01  call 0x000074AD7460A9A0
000074ad747ceb06  jmp 0x000074AD747CE6DB
000074ad747ceb0b  call 0x000074AD745FF430
000074ad747ceb10  jmp 0x000074AD747CE6E6
000074ad747ceb15  call 0x000074AD7460E760
000074ad747ceb1a  jmp 0x000074AD747CE6F1
000074ad747ceb1f  call 0x000074AD7460D4E0
000074ad747ceb24  jmp 0x000074AD747CE6FC
000074ad747ceb29  call 0x000074AD7460C260
000074ad747ceb2e  jmp 0x000074AD747CE707
000074ad747ceb33  call 0x000074AD7460AFE0
000074ad747ceb38  jmp 0x000074AD747CE71D
000074ad747ceb3d  call 0x000074AD745FF540
000074ad747ceb42  jmp 0x000074AD747CE728
000074ad747ceb47  call 0x000074AD7460E880
000074ad747ceb4c  jmp 0x000074AD747CE733
000074ad747ceb51  call 0x000074AD7460D600
000074ad747ceb56  jmp 0x000074AD747CE73E
000074ad747ceb5b  call 0x000074AD7460C380
000074ad747ceb60  jmp 0x000074AD747CE749
000074ad747ceb65  call 0x000074AD7460D4E0
000074ad747ceb6a  jmp 0x000074AD747CE754
000074ad747ceb6f  call 0x000074AD7460C260
000074ad747ceb74  jmp 0x000074AD747CE75F
000074ad747ceb79  call 0x000074AD745FF540
000074ad747ceb7e  jmp 0x000074AD747CE76A
000074ad747ceb83  call 0x000074AD7460E880
000074ad747ceb88  jmp 0x000074AD747CE775
000074ad747ceb8d  call 0x000074AD7460B100
000074ad747ceb92  jmp 0x000074AD747CE780
000074ad747ceb97  call 0x000074AD7460D600
000074ad747ceb9c  jmp 0x000074AD747CE78B
000074ad747ceba1  call 0x000074AD745FF430
000074ad747ceba6  jmp 0x000074AD747CE796
000074ad747cebab  call 0x000074AD7460E760
000074ad747cebb0  jmp 0x000074AD747CE7A1
000074ad747cebb5  call 0x000074AD7460C380
000074ad747cebba  jmp 0x000074AD747CE7AC
000074ad747cebbf  call 0x000074AD745FF540
000074ad747cebc4  jmp 0x000074AD747CE7B7
000074ad747cebc9  call 0x000074AD745FF430
000074ad747cebce  jmp 0x000074AD747CE7C2
000074ad747cebd3  call 0x000074AD7460D4E0
000074ad747cebd8  jmp 0x000074AD747CE7CD
000074ad747cebdd  call 0x000074AD7460E880
000074ad747cebe2  jmp 0x000074AD747CE7E0
000074ad747cebe7  call 0x000074AD745FF540
000074ad747cebec  jmp 0x000074AD747CE7EB
000074ad747cebf1  call 0x000074AD745FF430
000074ad747cebf6  jmp 0x000074AD747CE7F6
000074ad747cebfb  call 0x000074AD7460E760
000074ad747cec00  jmp 0x000074AD747CE801
000074ad747cec05  call 0x000074AD7460D600
000074ad747cec0a  jmp 0x000074AD747CE81F
000074ad747cec0f  call 0x000074AD745FF540
000074ad747cec14  jmp 0x000074AD747CE82A
000074ad747cec19  call 0x000074AD745FF430
000074ad747cec1e  jmp 0x000074AD747CE835
000074ad747cec23  call 0x000074AD7460D4E0
000074ad747cec28  jmp 0x000074AD747CE840
000074ad747cec2d  call 0x000074AD7460BC20
000074ad747cec32  jmp 0x000074AD747CE870
000074ad747cec37  call 0x000074AD7460A9A0
000074ad747cec3c  jmp 0x000074AD747CE87C
000074ad747cec41  call 0x000074AD7460E880
000074ad747cec46  jmp 0x000074AD747CE887
000074ad747cec4b  call 0x000074AD745FF540
000074ad747cec50  jmp 0x000074AD747CE892
000074ad747cec55  call 0x000074AD745FF430
000074ad747cec5a  jmp 0x000074AD747CE89D
000074ad747cec5f  call 0x000074AD7460B720
000074ad747cec64  jmp 0x000074AD747CE8A7
000074ad747cec69  call 0x000074AD7460D600
000074ad747cec6e  jmp 0x000074AD747CE8BF
000074ad747cec73  call 0x000074AD745FF540
000074ad747cec78  jmp 0x000074AD747CE8CA
000074ad747cec7d  call 0x000074AD745FF430
000074ad747cec82  jmp 0x000074AD747CE8D5
000074ad747cec87  call 0x000074AD746B4CB0
000074ad747cec8c  jmp 0x000074AD747CE8E5
000074ad747cec91  call 0x000074AD7460E760
000074ad747cec96  jmp 0x000074AD747CE8F0
000074ad747cec9b  call 0x000074AD7460D4E0
000074ad747ceca0  jmp 0x000074AD747CE8FB
000074ad747ceca5  call 0x000074AD745FF540
000074ad747cecaa  jmp 0x000074AD747CE908
000074ad747cecaf  call 0x000074AD7460BC20
000074ad747cecb4  jmp 0x000074AD747CE930
000074ad747cecb9  call 0x000074AD7460A9A0
000074ad747cecbe  jmp 0x000074AD747CE93C
000074ad747cecc3  call 0x000074AD7460E880
000074ad747cecc8  jmp 0x000074AD747CE949
000074ad747ceccd  call 0x000074AD7460D600
000074ad747cecd2  jmp 0x000074AD747CE956
000074ad747cecd7  call 0x000074AD745FF430
000074ad747cecdc  jmp 0x000074AD747CE961
000074ad747cece1  call 0x000074AD7460E760
000074ad747cece6  jmp 0x000074AD747CE96C
000074ad747ceceb  call 0x000074AD7460BC20
000074ad747cecf0  jmp 0x000074AD747CE99C
000074ad747cecf5  call 0x000074AD7460A9A0
000074ad747cecfa  jmp 0x000074AD747CE9A8
000074ad747cecff  call 0x000074AD7460BC20
000074ad747ced04  jmp 0x000074AD747CE9D0
000074ad747ced09  call 0x000074AD7460A9A0
000074ad747ced0e  jmp 0x000074AD747CE9DC
000074ad747ced13  call 0x000074AD745FF540
000074ad747ced18  jmp 0x000074AD747CE9E9
000074ad747ced1d  call 0x000074AD7460E880
000074ad747ced22  jmp 0x000074AD747CE9F6
000074ad747ced27  call 0x000074AD745FF430
000074ad747ced2c  jmp 0x000074AD747CEA01
000074ad747ced31  call 0x000074AD7460E760
000074ad747ced36  jmp 0x000074AD747CEA0C
000074ad747ced3b  call 0x000074AD7460BC20
000074ad747ced40  jmp 0x000074AD747CEA36
000074ad747ced45  call 0x000074AD7460A9A0
000074ad747ced4a  jmp 0x000074AD747CEA42
000074ad747ced4f  call 0x000074AD7460BAE0
000074ad747ced54  jmp 0x000074AD747CEA52
000074ad747ced59  call 0x000074AD745FF540
000074ad747ced5e  jmp 0x000074AD747CEA5F
000074ad747ced63  call 0x000074AD7460E880
000074ad747ced68  jmp 0x000074AD747CEA6C
000074ad747ced6d  int3
000074ad747ced6e  nop
000074ad747ced70  mov rax, [r15]
000074ad747ced73  lea r14, [rax+0x20]
000074ad747ced77  mov r12, [r13+r14*1]
000074ad747ced7c  mov r14, [r15+0x10]
000074ad747ced80  lea r11, [r12+r14*1]
000074ad747ced84  mov [r15+0x40], r11
000074ad747ced88  lea r12, [rax+0x20]
000074ad747ced8c  mov [r13+r12*1], r11
000074ad747ced91  test r14, r14
000074ad747ced94  setz r14b
000074ad747ced98  movzx r14, r14b
000074ad747ced9c  mov [rsp+0x414], r14b
000074ad747ceda4  cmp byte ptr [rsp+0x414], 0x00
000074ad747cedac  jz 0x000074AD747CEDDE
000074ad747cedae  cmp dword ptr [r15+0x318], 0x00
000074ad747cedb6  mov eax, 0x410934
000074ad747cedbb  mov [r15+0x100], rax
000074ad747cedc2  jz 0x000074AD745FE0A0
000074ad747cedc8  nop [rax+rax*1], eax
000074ad747cedcd  mov eax, 0x410934
000074ad747cedd2  mov [r15+0x100], rax
000074ad747cedd9  jmp 0x000074AD745FE110
000074ad747cedde  cmp dword ptr [r15+0x318], 0x00
000074ad747cede6  jz 0x000074AD747CEE30
000074ad747cedec  nop [rax+rax*1], ax
000074ad747cedf5  nop [rax+rax*1], eax
000074ad747cedfd  mov eax, 0x4106CC
000074ad747cee02  mov [r15+0x100], rax
000074ad747cee09  jmp 0x000074AD745FE110
000074ad747cee0e  int3
000074ad747cee0f  call 0x000074AD746E27E0
000074ad747cee14  jmp 0x000074AD747CED7C
000074ad747cee19  call 0x000074AD746C0860
000074ad747cee1e  jmp 0x000074AD747CED91
000074ad747cee23  int3
000074ad747cee24  nop [rax+rax*1], ax
000074ad747cee2d  nop [rax], eax
000074ad747cee30  mov rax, [r15+0xF8]
000074ad747cee37  lea r14, [rax-0x150]
000074ad747cee3e  mov [r15+0xF8], r14
000074ad747cee45  mov rax, [r15]
000074ad747cee48  lea r12, [rax+0x68]
000074ad747cee4c  mov r11, [r13+r12*1]
000074ad747cee51  mov [r15+0x88], r11
000074ad747cee58  lea r12, [rax+0x28]
000074ad747cee5c  mov [r15+0x40], r12
000074ad747cee60  mov [r15+0x48], r14
000074ad747cee64  mov qword ptr [r15+0x50], 0x420B20
000074ad747cee6c  lea rax, [r14+0x100]
000074ad747cee73  mov r12, [r15+0xE8]
000074ad747cee7a  mov r11, [r15+0xD8]
000074ad747cee81  mov [r13+rax*1], r12
000074ad747cee86  lea rax, [r14+0x108]
000074ad747cee8d  mov [r13+rax*1], r11
000074ad747cee92  lea rax, [r14+0x110]
000074ad747cee99  mov r12, [r15+0xD0]
000074ad747ceea0  mov r11, [r15+0xC8]
000074ad747ceea7  mov [r13+rax*1], r12
000074ad747ceeac  lea rax, [r14+0x118]
000074ad747ceeb3  mov [r13+rax*1], r11
000074ad747ceeb8  lea rax, [r14+0x120]
000074ad747ceebf  mov r12, [r15+0xC0]
000074ad747ceec6  mov r11, [r15+0xB8]
000074ad747ceecd  mov [r13+rax*1], r12
000074ad747ceed2  lea rax, [r14+0x128]
000074ad747ceed9  mov [r13+rax*1], r11
000074ad747ceede  lea rax, [r14+0x130]
000074ad747ceee5  mov r12, [r15+0xB0]
000074ad747ceeec  mov r11, [r15+0xA8]
000074ad747ceef3  mov [r13+rax*1], r12
000074ad747ceef8  lea rax, [r14+0x138]
000074ad747ceeff  mov [r13+rax*1], r11
000074ad747cef04  lea rax, [r14+0x140]
000074ad747cef0b  mov r12, [r15+0xA0]
000074ad747cef12  mov r11, [r15+0x98]
000074ad747cef19  mov [r13+rax*1], r12
000074ad747cef1e  lea rax, [r14+0x148]
000074ad747cef25  mov [r13+rax*1], r11
000074ad747cef2a  cmp dword ptr [r15+0x318], 0x00
000074ad747cef32  jz 0x000074AD747CEFD0
000074ad747cef38  nop [rax+rax*1], ax
000074ad747cef41  nop [rax+rax*1], eax
000074ad747cef49  mov eax, 0x410704
000074ad747cef4e  mov [r15+0x100], rax
000074ad747cef55  jmp 0x000074AD745FE110
000074ad747cef5a  int3
000074ad747cef5b  call 0x000074AD746C0370
000074ad747cef60  jmp 0x000074AD747CEE51
000074ad747cef65  call 0x000074AD7460BC20
000074ad747cef6a  jmp 0x000074AD747CEE86
000074ad747cef6f  call 0x000074AD7460A9A0
000074ad747cef74  jmp 0x000074AD747CEE92
000074ad747cef79  call 0x000074AD7460BC20
000074ad747cef7e  jmp 0x000074AD747CEEAC
000074ad747cef83  call 0x000074AD7460A9A0
000074ad747cef88  jmp 0x000074AD747CEEB8
000074ad747cef8d  call 0x000074AD7460BC20
000074ad747cef92  jmp 0x000074AD747CEED2
000074ad747cef97  call 0x000074AD7460A9A0
000074ad747cef9c  jmp 0x000074AD747CEEDE
000074ad747cefa1  call 0x000074AD7460BC20
000074ad747cefa6  jmp 0x000074AD747CEEF8
000074ad747cefab  call 0x000074AD7460A9A0
000074ad747cefb0  jmp 0x000074AD747CEF04
000074ad747cefb5  call 0x000074AD7460BC20
000074ad747cefba  jmp 0x000074AD747CEF1E
000074ad747cefbf  call 0x000074AD7460A9A0
000074ad747cefc4  jmp 0x000074AD747CEF2A
000074ad747cefc9  int3
000074ad747cefca  nop [rax+rax*1], ax
000074ad747cefd0  mov rax, [r15+0x08]
000074ad747cefd4  movzx r14d, byte ptr [r13+rax*1]
000074ad747cefda  movzx r14d, r14b
000074ad747cefde  mov [rsp+0x10], r14d
000074ad747cefe3  mov r14d, r14d
000074ad747cefe6  mov [r15+0x58], r14
000074ad747cefea  lea r14, [rax+0x01]
000074ad747cefee  mov [r15+0x08], r14
000074ad747ceff2  mov rax, [r15+0x88]
000074ad747ceff9  lea r14, [rax+0x01]
000074ad747ceffd  mov r12, [r15]
000074ad747cf000  lea r11, [r12+0x68]
000074ad747cf005  mov [r13+r11*1], r14
000074ad747cf00a  lea r14, [r12+rax*1]
000074ad747cf00e  mov [r15+0x60], r14
000074ad747cf012  lea rax, [r14+0x28]
000074ad747cf016  mov r11d, [rsp+0x10]
000074ad747cf01b  movzx r14d, r11b
000074ad747cf01f  mov [r13+rax*1], r14b
000074ad747cf024  lea rax, [r12+0x68]
000074ad747cf029  mov r14, [r13+rax*1]
000074ad747cf02e  mov [r15+0x88], r14
000074ad747cf035  xor eax, eax
000074ad747cf037  mov r12d, 0x40
000074ad747cf03d  cmp r14, r12
000074ad747cf040  cmc
000074ad747cf041  lahf
000074ad747cf042  seto al
000074ad747cf045  mov [r15+0x108], eax
000074ad747cf04c  mov eax, [r15+0x108]
000074ad747cf053  sahf
000074ad747cf054  jnz 0x000074AD747CF086
000074ad747cf056  cmp dword ptr [r15+0x318], 0x00
000074ad747cf05e  jz 0x000074AD747CF170
000074ad747cf064  nop [rax+rax*1], ax
000074ad747cf06d  nop [rax+rax*1], eax
000074ad747cf075  mov eax, 0x410724
000074ad747cf07a  mov [r15+0x100], rax
000074ad747cf081  jmp 0x000074AD745FE110
000074ad747cf086  cmp dword ptr [r15+0x318], 0x00
000074ad747cf08e  jz 0x000074AD747CF0E0
000074ad747cf094  nop [rax+rax*1], ax
000074ad747cf09d  nop [rax+rax*1], eax
000074ad747cf0a5  mov eax, 0x4106FC
000074ad747cf0aa  mov [r15+0x100], rax
000074ad747cf0b1  jmp 0x000074AD745FE110
000074ad747cf0b6  int3
000074ad747cf0b7  call 0x000074AD7460D860
000074ad747cf0bc  jmp 0x000074AD747CEFDA
000074ad747cf0c1  call 0x000074AD746B36E0
000074ad747cf0c6  jmp 0x000074AD747CF00A
000074ad747cf0cb  call 0x000074AD7460DD60
000074ad747cf0d0  jmp 0x000074AD747CF024
000074ad747cf0d5  call 0x000074AD7460DC20
000074ad747cf0da  jmp 0x000074AD747CF02E
000074ad747cf0df  int3
000074ad747cf0e0  mov rax, [r15+0x10]
000074ad747cf0e4  lea r14, [rax-0x01]
000074ad747cf0e8  mov [r15+0x10], r14
000074ad747cf0ec  test r14, r14
000074ad747cf0ef  setz r14b
000074ad747cf0f3  movzx r14, r14b
000074ad747cf0f7  mov [rsp+0x414], r14b
000074ad747cf0ff  cmp byte ptr [rsp+0x414], 0x00
000074ad747cf107  jz 0x000074AD747CF139
000074ad747cf109  cmp dword ptr [r15+0x318], 0x00
000074ad747cf111  jz 0x000074AD747D0670
000074ad747cf117  nop [rax+rax*1], ax
000074ad747cf120  nop [rax+rax*1], eax
000074ad747cf128  mov eax, 0x41091C
000074ad747cf12d  mov [r15+0x100], rax
000074ad747cf134  jmp 0x000074AD745FE110
000074ad747cf139  cmp dword ptr [r15+0x318], 0x00
000074ad747cf141  jz 0x000074AD747CEFD0
000074ad747cf147  nop [rax+rax*1], ax
000074ad747cf150  nop [rax+rax*1], eax
000074ad747cf158  mov eax, 0x410704
000074ad747cf15d  mov [r15+0x100], rax
000074ad747cf164  jmp 0x000074AD745FE110
000074ad747cf169  int3
000074ad747cf16a  int3
000074ad747cf16b  nop [rax+rax*1], eax
000074ad747cf170  mov rax, [r15+0x40]
000074ad747cf174  movzx r14d, byte ptr [r13+rax*1]
000074ad747cf17a  movaps xmm1, [r15+0x110]
000074ad747cf182  pinsrb xmm1, r14d, 0x00
000074ad747cf189  lea r14, [rax+0x01]
000074ad747cf18d  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf193  movaps xmm15, [r15+0x120]
000074ad747cf19b  pinsrb xmm15, r12d, 0x00
000074ad747cf1a2  lea r14, [rax+0x02]
000074ad747cf1a6  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf1ac  movaps xmm14, [r15+0x130]
000074ad747cf1b4  pinsrb xmm14, r12d, 0x00
000074ad747cf1bb  lea r14, [rax+0x03]
000074ad747cf1bf  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf1c5  movaps xmm13, [r15+0x140]
000074ad747cf1cd  pinsrb xmm13, r12d, 0x00
000074ad747cf1d4  lea r14, [rax+0x04]
000074ad747cf1d8  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf1de  pinsrb xmm1, r12d, 0x01
000074ad747cf1e5  lea r14, [rax+0x05]
000074ad747cf1e9  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf1ef  pinsrb xmm15, r12d, 0x01
000074ad747cf1f6  lea r14, [rax+0x06]
000074ad747cf1fa  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf200  pinsrb xmm14, r12d, 0x01
000074ad747cf207  lea r14, [rax+0x07]
000074ad747cf20b  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf211  pinsrb xmm13, r12d, 0x01
000074ad747cf218  lea r14, [rax+0x08]
000074ad747cf21c  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf222  pinsrb xmm1, r12d, 0x02
000074ad747cf229  lea r14, [rax+0x09]
000074ad747cf22d  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf233  pinsrb xmm15, r12d, 0x02
000074ad747cf23a  lea r14, [rax+0x0A]
000074ad747cf23e  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf244  pinsrb xmm14, r12d, 0x02
000074ad747cf24b  lea r14, [rax+0x0B]
000074ad747cf24f  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf255  pinsrb xmm13, r12d, 0x02
000074ad747cf25c  lea r14, [rax+0x0C]
000074ad747cf260  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf266  pinsrb xmm1, r12d, 0x03
000074ad747cf26d  lea r14, [rax+0x0D]
000074ad747cf271  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf277  pinsrb xmm15, r12d, 0x03
000074ad747cf27e  lea r14, [rax+0x0E]
000074ad747cf282  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf288  pinsrb xmm14, r12d, 0x03
000074ad747cf28f  lea r14, [rax+0x0F]
000074ad747cf293  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf299  pinsrb xmm13, r12d, 0x03
000074ad747cf2a0  lea r14, [rax+0x10]
000074ad747cf2a4  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf2aa  pinsrb xmm1, r12d, 0x04
000074ad747cf2b1  lea r14, [rax+0x11]
000074ad747cf2b5  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf2bb  pinsrb xmm15, r12d, 0x04
000074ad747cf2c2  lea r14, [rax+0x12]
000074ad747cf2c6  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf2cc  pinsrb xmm14, r12d, 0x04
000074ad747cf2d3  lea r14, [rax+0x13]
000074ad747cf2d7  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf2dd  pinsrb xmm13, r12d, 0x04
000074ad747cf2e4  lea r14, [rax+0x14]
000074ad747cf2e8  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf2ee  pinsrb xmm1, r12d, 0x05
000074ad747cf2f5  lea r14, [rax+0x15]
000074ad747cf2f9  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf2ff  pinsrb xmm15, r12d, 0x05
000074ad747cf306  lea r14, [rax+0x16]
000074ad747cf30a  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf310  pinsrb xmm14, r12d, 0x05
000074ad747cf317  lea r14, [rax+0x17]
000074ad747cf31b  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf321  pinsrb xmm13, r12d, 0x05
000074ad747cf328  lea r14, [rax+0x18]
000074ad747cf32c  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf332  pinsrb xmm1, r12d, 0x06
000074ad747cf339  lea r14, [rax+0x19]
000074ad747cf33d  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf343  pinsrb xmm15, r12d, 0x06
000074ad747cf34a  lea r14, [rax+0x1A]
000074ad747cf34e  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf354  pinsrb xmm14, r12d, 0x06
000074ad747cf35b  lea r14, [rax+0x1B]
000074ad747cf35f  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf365  pinsrb xmm13, r12d, 0x06
000074ad747cf36c  lea r14, [rax+0x1C]
000074ad747cf370  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf376  pinsrb xmm1, r12d, 0x07
000074ad747cf37d  lea r14, [rax+0x1D]
000074ad747cf381  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf387  pinsrb xmm15, r12d, 0x07
000074ad747cf38e  lea r14, [rax+0x1E]
000074ad747cf392  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf398  pinsrb xmm14, r12d, 0x07
000074ad747cf39f  lea r14, [rax+0x1F]
000074ad747cf3a3  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf3a9  pinsrb xmm13, r12d, 0x07
000074ad747cf3b0  lea r14, [rax+0x20]
000074ad747cf3b4  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf3ba  pinsrb xmm1, r12d, 0x08
000074ad747cf3c1  lea r14, [rax+0x21]
000074ad747cf3c5  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf3cb  pinsrb xmm15, r12d, 0x08
000074ad747cf3d2  lea r14, [rax+0x22]
000074ad747cf3d6  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf3dc  pinsrb xmm14, r12d, 0x08
000074ad747cf3e3  lea r14, [rax+0x23]
000074ad747cf3e7  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf3ed  pinsrb xmm13, r12d, 0x08
000074ad747cf3f4  lea r14, [rax+0x24]
000074ad747cf3f8  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf3fe  pinsrb xmm1, r12d, 0x09
000074ad747cf405  lea r14, [rax+0x25]
000074ad747cf409  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf40f  pinsrb xmm15, r12d, 0x09
000074ad747cf416  lea r14, [rax+0x26]
000074ad747cf41a  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf420  pinsrb xmm14, r12d, 0x09
000074ad747cf427  lea r14, [rax+0x27]
000074ad747cf42b  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf431  pinsrb xmm13, r12d, 0x09
000074ad747cf438  lea r14, [rax+0x28]
000074ad747cf43c  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf442  pinsrb xmm1, r12d, 0x0A
000074ad747cf449  lea r14, [rax+0x29]
000074ad747cf44d  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf453  pinsrb xmm15, r12d, 0x0A
000074ad747cf45a  lea r14, [rax+0x2A]
000074ad747cf45e  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf464  pinsrb xmm14, r12d, 0x0A
000074ad747cf46b  lea r14, [rax+0x2B]
000074ad747cf46f  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf475  pinsrb xmm13, r12d, 0x0A
000074ad747cf47c  lea r14, [rax+0x2C]
000074ad747cf480  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf486  pinsrb xmm1, r12d, 0x0B
000074ad747cf48d  lea r14, [rax+0x2D]
000074ad747cf491  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf497  pinsrb xmm15, r12d, 0x0B
000074ad747cf49e  lea r14, [rax+0x2E]
000074ad747cf4a2  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf4a8  pinsrb xmm14, r12d, 0x0B
000074ad747cf4af  lea r14, [rax+0x2F]
000074ad747cf4b3  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf4b9  pinsrb xmm13, r12d, 0x0B
000074ad747cf4c0  lea r14, [rax+0x30]
000074ad747cf4c4  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf4ca  pinsrb xmm1, r12d, 0x0C
000074ad747cf4d1  lea r14, [rax+0x31]
000074ad747cf4d5  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf4db  pinsrb xmm15, r12d, 0x0C
000074ad747cf4e2  lea r14, [rax+0x32]
000074ad747cf4e6  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf4ec  pinsrb xmm14, r12d, 0x0C
000074ad747cf4f3  lea r14, [rax+0x33]
000074ad747cf4f7  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf4fd  pinsrb xmm13, r12d, 0x0C
000074ad747cf504  lea r14, [rax+0x34]
000074ad747cf508  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf50e  pinsrb xmm1, r12d, 0x0D
000074ad747cf515  lea r14, [rax+0x35]
000074ad747cf519  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf51f  pinsrb xmm15, r12d, 0x0D
000074ad747cf526  lea r14, [rax+0x36]
000074ad747cf52a  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf530  pinsrb xmm14, r12d, 0x0D
000074ad747cf537  lea r14, [rax+0x37]
000074ad747cf53b  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf541  pinsrb xmm13, r12d, 0x0D
000074ad747cf548  lea r14, [rax+0x38]
000074ad747cf54c  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf552  pinsrb xmm1, r12d, 0x0E
000074ad747cf559  lea r14, [rax+0x39]
000074ad747cf55d  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf563  pinsrb xmm15, r12d, 0x0E
000074ad747cf56a  lea r14, [rax+0x3A]
000074ad747cf56e  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf574  pinsrb xmm14, r12d, 0x0E
000074ad747cf57b  lea r14, [rax+0x3B]
000074ad747cf57f  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf585  pinsrb xmm13, r12d, 0x0E
000074ad747cf58c  lea r14, [rax+0x3C]
000074ad747cf590  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf596  pinsrb xmm1, r12d, 0x0F
000074ad747cf59d  movaps [r15+0x110], xmm1
000074ad747cf5a5  lea r14, [rax+0x3D]
000074ad747cf5a9  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf5af  pinsrb xmm15, r12d, 0x0F
000074ad747cf5b6  movaps [r15+0x120], xmm15
000074ad747cf5be  lea r14, [rax+0x3E]
000074ad747cf5c2  movzx r12d, byte ptr [r13+r14*1]
000074ad747cf5c8  pinsrb xmm14, r12d, 0x0F
000074ad747cf5cf  movaps [r15+0x130], xmm14
000074ad747cf5d7  lea r14, [rax+0x3F]
000074ad747cf5db  movzx eax, byte ptr [r13+r14*1]
000074ad747cf5e1  pinsrb xmm13, eax, 0x0F
000074ad747cf5e8  movaps [r15+0x140], xmm13
000074ad747cf5f0  movq xmm1, qword ptr [r15+0x120]
000074ad747cf5f9  pmovzxbw xmm1, xmm1
000074ad747cf5fe  psllw xmm1, 0x00
000074ad747cf603  movaps [r15+0x150], xmm1
000074ad747cf60b  movq xmm1, qword ptr [r15+0x130]
000074ad747cf614  pmovzxbw xmm1, xmm1
000074ad747cf619  psllw xmm1, 0x00
000074ad747cf61e  movaps [r15+0x160], xmm1
000074ad747cf626  movq xmm1, qword ptr [r15+0x110]
000074ad747cf62f  pmovzxbw xmm1, xmm1
000074ad747cf634  psllw xmm1, 0x00
000074ad747cf639  movaps [r15+0x170], xmm1
000074ad747cf641  movaps xmm15, [r15+0x110]
000074ad747cf649  pextrq rax, xmm15, 0x01
000074ad747cf650  movq xmm15, rax
000074ad747cf655  pmovzxbw xmm15, xmm15
000074ad747cf65b  psllw xmm15, 0x00
000074ad747cf661  movaps [r15+0x180], xmm15
000074ad747cf669  movaps xmm14, [r15+0x120]
000074ad747cf671  pextrq rax, xmm14, 0x01
000074ad747cf678  movq xmm14, rax
000074ad747cf67d  pmovzxbw xmm14, xmm14
000074ad747cf683  psllw xmm14, 0x00
000074ad747cf689  movaps [r15+0x210], xmm14
000074ad747cf691  movaps xmm13, [r15+0x130]
000074ad747cf699  pextrq rax, xmm13, 0x01
000074ad747cf6a0  movq xmm13, rax
000074ad747cf6a5  pmovzxbw xmm13, xmm13
000074ad747cf6ab  psllw xmm13, 0x00
000074ad747cf6b1  movaps [r15+0x220], xmm13
000074ad747cf6b9  movq xmm12, qword ptr [r15+0x140]
000074ad747cf6c2  pmovzxbw xmm12, xmm12
000074ad747cf6c8  psllw xmm12, 0x00
000074ad747cf6ce  movaps [r15+0x250], xmm12
000074ad747cf6d6  movaps xmm12, [r15+0x140]
000074ad747cf6de  pextrq rax, xmm12, 0x01
000074ad747cf6e5  movq xmm12, rax
000074ad747cf6ea  pmovzxbw xmm12, xmm12
000074ad747cf6f0  psllw xmm12, 0x00
000074ad747cf6f6  movaps [r15+0x110], xmm12
000074ad747cf6fe  movq xmm11, qword ptr [r15+0x150]
000074ad747cf707  pmovzxwd xmm11, xmm11
000074ad747cf70d  pslld xmm11, 0x10
000074ad747cf713  movq xmm10, qword ptr [r15+0x160]
000074ad747cf71c  pmovzxwd xmm10, xmm10
000074ad747cf722  pslld xmm10, 0x08
000074ad747cf728  pextrq rax, xmm1, 0x01
000074ad747cf72f  movq xmm1, rax
000074ad747cf734  pmovzxwd xmm1, xmm1
000074ad747cf739  pslld xmm1, 0x00
000074ad747cf73e  movaps [r15+0x260], xmm1
000074ad747cf746  pextrq rax, xmm15, 0x01
000074ad747cf74d  movq xmm15, rax
000074ad747cf752  pmovzxwd xmm15, xmm15
000074ad747cf758  pslld xmm15, 0x00
000074ad747cf75e  movaps [r15+0x270], xmm15
000074ad747cf766  movq xmm9, qword ptr [r15+0x170]
000074ad747cf76f  pmovzxwd xmm9, xmm9
000074ad747cf775  pslld xmm9, 0x00
000074ad747cf77b  pextrq rax, xmm14, 0x01
000074ad747cf782  movq xmm14, rax
000074ad747cf787  pmovzxwd xmm14, xmm14
000074ad747cf78d  pslld xmm14, 0x10
000074ad747cf793  movaps [r15+0x280], xmm14
000074ad747cf79b  movq xmm8, qword ptr [r15+0x180]
000074ad747cf7a4  pmovzxwd xmm8, xmm8
000074ad747cf7aa  pslld xmm8, 0x00
000074ad747cf7b0  movq xmm7, qword ptr [r15+0x210]
000074ad747cf7b9  pmovzxwd xmm7, xmm7
000074ad747cf7be  pslld xmm7, 0x10
000074ad747cf7c3  movaps xmm6, [r15+0x150]
000074ad747cf7cb  pextrq rax, xmm6, 0x01
000074ad747cf7d2  movq xmm6, rax
000074ad747cf7d7  pmovzxwd xmm6, xmm6
000074ad747cf7dc  pslld xmm6, 0x10
000074ad747cf7e1  por xmm11, xmm10
000074ad747cf7e6  movaps [r15+0x230], xmm11
000074ad747cf7ee  pextrq rax, xmm13, 0x01
000074ad747cf7f5  movq xmm13, rax
000074ad747cf7fa  pmovzxwd xmm13, xmm13
000074ad747cf800  pslld xmm13, 0x08
000074ad747cf806  movaps [r15+0x240], xmm13
000074ad747cf80e  movq xmm10, qword ptr [r15+0x220]
000074ad747cf817  pmovzxwd xmm10, xmm10
000074ad747cf81d  pslld xmm10, 0x08
000074ad747cf823  movaps xmm5, [r15+0x160]
000074ad747cf82b  pextrq rax, xmm5, 0x01
000074ad747cf832  movq xmm5, rax
000074ad747cf837  pmovzxwd xmm5, xmm5
000074ad747cf83c  pslld xmm5, 0x08
000074ad747cf841  pslld xmm9, 0x18
000074ad747cf847  pslld xmm15, 0x18
000074ad747cf84d  pslld xmm8, 0x18
000074ad747cf853  movq xmm4, qword ptr [r15+0x250]
000074ad747cf85c  pmovzxwd xmm4, xmm4
000074ad747cf861  pslld xmm4, 0x00
000074ad747cf866  por xmm14, xmm13
000074ad747cf86b  por xmm7, xmm10
000074ad747cf870  movaps [r15+0x210], xmm7
000074ad747cf878  pslld xmm1, 0x18
000074ad747cf87d  movaps [r15+0x220], xmm1
000074ad747cf885  por xmm6, xmm5
000074ad747cf889  por xmm11, xmm9
000074ad747cf88e  movaps [r15+0x160], xmm11
000074ad747cf896  pextrq rax, xmm12, 0x01
000074ad747cf89d  movq xmm13, rax
000074ad747cf8a2  pmovzxwd xmm13, xmm13
000074ad747cf8a8  pslld xmm13, 0x00
000074ad747cf8ae  movaps [r15+0x170], xmm13
000074ad747cf8b6  movq xmm12, qword ptr [r15+0x110]
000074ad747cf8bf  pmovzxwd xmm12, xmm12
000074ad747cf8c5  pslld xmm12, 0x00
000074ad747cf8cb  por xmm14, xmm15
000074ad747cf8d0  por xmm7, xmm8
000074ad747cf8d5  movaps xmm15, [r15+0x250]
000074ad747cf8dd  pextrq rax, xmm15, 0x01
000074ad747cf8e4  movq xmm15, rax
000074ad747cf8e9  pmovzxwd xmm15, xmm15
000074ad747cf8ef  pslld xmm15, 0x00
000074ad747cf8f5  movaps [r15+0x180], xmm15
000074ad747cf8fd  por xmm6, xmm1
000074ad747cf901  movaps [r15+0x150], xmm6
000074ad747cf909  por xmm11, xmm4
000074ad747cf90e  movaps [r15+0x140], xmm11
000074ad747cf916  por xmm7, xmm12
000074ad747cf91b  movaps [r15+0x110], xmm7
000074ad747cf923  por xmm14, xmm13
000074ad747cf928  movaps [r15+0x120], xmm14
000074ad747cf930  por xmm6, xmm15
000074ad747cf935  movaps [r15+0x130], xmm6
000074ad747cf93d  mov rax, [r15+0xF8]
000074ad747cf944  lea r14, [rax+0x20]
000074ad747cf948  movups [r13+r14*1], xmm7
000074ad747cf94e  lea r14, [rax+0x30]
000074ad747cf952  movups [r13+r14*1], xmm14
000074ad747cf958  movups [r13+rax*1], xmm11
000074ad747cf95e  lea r14, [rax+0x10]
000074ad747cf962  movups [r13+r14*1], xmm6
000074ad747cf968  mov r14d, [r13+rax*1]
000074ad747cf96d  mov rax, [r15+0x48]
000074ad747cf971  mov [r15+0x68], rax
000074ad747cf975  mov qword ptr [r15+0x58], 0x04
000074ad747cf97d  lea r12, [rax+0x04]
000074ad747cf981  mov r11d, [r13+r12*1]
000074ad747cf986  mov [rsp+0x10], r11d
000074ad747cf98b  mov r11d, r11d
000074ad747cf98e  mov [r15+0x70], r11
000074ad747cf992  lea r12, [rax+0x38]
000074ad747cf996  mov r11d, [r13+r12*1]
000074ad747cf99b  lea r12, [rax+0x24]
000074ad747cf99f  mov r10d, [r13+r12*1]
000074ad747cf9a4  mov [rsp+0x20], r10d
000074ad747cf9a9  mov r10d, r10d
000074ad747cf9ac  mov [r15+0x90], r10
000074ad747cf9b3  mov [rsp+0x30], rax
000074ad747cf9b8  xor eax, eax
000074ad747cf9ba  mov r12d, 0x04
000074ad747cf9c0  mov r10d, 0xC0
000074ad747cf9c6  cmp r12, r10
000074ad747cf9c9  cmc
000074ad747cf9ca  lahf
000074ad747cf9cb  seto al
000074ad747cf9ce  mov [r15+0x108], eax
000074ad747cf9d5  mov eax, [rsp+0x10]
000074ad747cf9d9  mov r12d, [rsp+0x10]
000074ad747cf9de  shrd eax, r12d, 0x07
000074ad747cf9e3  mov [rsp+0x10], r11d
000074ad747cf9e8  mov r10d, [rsp+0x10]
000074ad747cf9ed  shrd r11d, r10d, 0x11
000074ad747cf9f2  mov r9d, [rsp+0x20]
000074ad747cf9f7  lea r8d, [r9d+r14d*1]
000074ad747cf9fc  rorx r14d, r12d, 0x12
000074ad747cfa02  xor eax, r14d
000074ad747cfa05  rorx r14d, r10d, 0x13
000074ad747cfa0b  xor r11d, r14d
000074ad747cfa0e  mov [rsp+0x10], r11d
000074ad747cfa13  mov r11d, r11d
000074ad747cfa16  mov [r15+0x88], r11
000074ad747cfa1d  mov [rsp+0x20], r12d
000074ad747cfa22  shr r12d, 0x03
000074ad747cfa26  xor eax, r12d
000074ad747cfa29  mov [rsp+0x40], eax
000074ad747cfa2d  mov eax, eax
000074ad747cfa2f  mov [r15+0x80], rax
000074ad747cfa36  shr r10d, 0x0A
000074ad747cfa3a  mov eax, [rsp+0x10]
000074ad747cfa3e  xor eax, r10d
000074ad747cfa41  mov [rsp+0x10], eax
000074ad747cfa45  mov eax, eax
000074ad747cfa47  mov [r15+0x78], rax
000074ad747cfa4b  mov eax, [rsp+0x40]
000074ad747cfa4f  lea r14d, [r8d+eax*1]
000074ad747cfa54  mov eax, [rsp+0x10]
000074ad747cfa58  lea r12d, [r14d+eax*1]
000074ad747cfa5d  mov rax, [rsp+0x30]
000074ad747cfa62  lea r14, [rax+0x40]
000074ad747cfa66  mov [r13+r14*1], r12d
000074ad747cfa6b  mov eax, [rsp+0x20]
000074ad747cfa6f  mov eax, eax
000074ad747cfa71  mov [r15+0x60], rax
000074ad747cfa75  mov eax, [r15+0x108]
000074ad747cfa7c  sahf
000074ad747cfa7d  jnz 0x000074AD747CFAAF
000074ad747cfa7f  cmp dword ptr [r15+0x318], 0x00
000074ad747cfa87  jz 0x000074AD747CFF70
000074ad747cfa8d  nop [rax+rax*1], ax
000074ad747cfa96  nop [rax+rax*1], eax
000074ad747cfa9e  mov eax, 0x410820
000074ad747cfaa3  mov [r15+0x100], rax
000074ad747cfaaa  jmp 0x000074AD745FE110
000074ad747cfaaf  cmp dword ptr [r15+0x318], 0x00
000074ad747cfab7  jz 0x000074AD747CFDC0
000074ad747cfabd  nop [rax+rax*1], ax
000074ad747cfac6  nop [rax+rax*1], eax
000074ad747cface  mov eax, 0x4107D8
000074ad747cfad3  mov [r15+0x100], rax
000074ad747cfada  jmp 0x000074AD745FE110
000074ad747cfadf  int3
000074ad747cfae0  call 0x000074AD7460D860
000074ad747cfae5  jmp 0x000074AD747CF17A
000074ad747cfaea  call 0x000074AD746E2420
000074ad747cfaef  jmp 0x000074AD747CF193
000074ad747cfaf4  call 0x000074AD746E2420
000074ad747cfaf9  jmp 0x000074AD747CF1AC
000074ad747cfafe  call 0x000074AD746E2420
000074ad747cfb03  jmp 0x000074AD747CF1C5
000074ad747cfb08  call 0x000074AD746E2420
000074ad747cfb0d  jmp 0x000074AD747CF1DE
000074ad747cfb12  call 0x000074AD746E2420
000074ad747cfb17  jmp 0x000074AD747CF1EF
000074ad747cfb1c  call 0x000074AD746E2420
000074ad747cfb21  jmp 0x000074AD747CF200
000074ad747cfb26  call 0x000074AD746E2420
000074ad747cfb2b  jmp 0x000074AD747CF211
000074ad747cfb30  call 0x000074AD746E2420
000074ad747cfb35  jmp 0x000074AD747CF222
000074ad747cfb3a  call 0x000074AD746E2420
000074ad747cfb3f  jmp 0x000074AD747CF233
000074ad747cfb44  call 0x000074AD746E2420
000074ad747cfb49  jmp 0x000074AD747CF244
000074ad747cfb4e  call 0x000074AD746E2420
000074ad747cfb53  jmp 0x000074AD747CF255
000074ad747cfb58  call 0x000074AD746E2420
000074ad747cfb5d  jmp 0x000074AD747CF266
000074ad747cfb62  call 0x000074AD746E2420
000074ad747cfb67  jmp 0x000074AD747CF277
000074ad747cfb6c  call 0x000074AD746E2420
000074ad747cfb71  jmp 0x000074AD747CF288
000074ad747cfb76  call 0x000074AD746E2420
000074ad747cfb7b  jmp 0x000074AD747CF299
000074ad747cfb80  call 0x000074AD746E2420
000074ad747cfb85  jmp 0x000074AD747CF2AA
000074ad747cfb8a  call 0x000074AD746E2420
000074ad747cfb8f  jmp 0x000074AD747CF2BB
000074ad747cfb94  call 0x000074AD746E2420
000074ad747cfb99  jmp 0x000074AD747CF2CC
000074ad747cfb9e  call 0x000074AD746E2420
000074ad747cfba3  jmp 0x000074AD747CF2DD
000074ad747cfba8  call 0x000074AD746E2420
000074ad747cfbad  jmp 0x000074AD747CF2EE
000074ad747cfbb2  call 0x000074AD746E2420
000074ad747cfbb7  jmp 0x000074AD747CF2FF
000074ad747cfbbc  call 0x000074AD746E2420
000074ad747cfbc1  jmp 0x000074AD747CF310
000074ad747cfbc6  call 0x000074AD746E2420
000074ad747cfbcb  jmp 0x000074AD747CF321
000074ad747cfbd0  call 0x000074AD746E2420
000074ad747cfbd5  jmp 0x000074AD747CF332
000074ad747cfbda  call 0x000074AD746E2420
000074ad747cfbdf  jmp 0x000074AD747CF343
000074ad747cfbe4  call 0x000074AD746E2420
000074ad747cfbe9  jmp 0x000074AD747CF354
000074ad747cfbee  call 0x000074AD746E2420
000074ad747cfbf3  jmp 0x000074AD747CF365
000074ad747cfbf8  call 0x000074AD746E2420
000074ad747cfbfd  jmp 0x000074AD747CF376
000074ad747cfc02  call 0x000074AD746E2420
000074ad747cfc07  jmp 0x000074AD747CF387
000074ad747cfc0c  call 0x000074AD746E2420
000074ad747cfc11  jmp 0x000074AD747CF398
000074ad747cfc16  call 0x000074AD746E2420
000074ad747cfc1b  jmp 0x000074AD747CF3A9
000074ad747cfc20  call 0x000074AD746E2420
000074ad747cfc25  jmp 0x000074AD747CF3BA
000074ad747cfc2a  call 0x000074AD746E2420
000074ad747cfc2f  jmp 0x000074AD747CF3CB
000074ad747cfc34  call 0x000074AD746E2420
000074ad747cfc39  jmp 0x000074AD747CF3DC
000074ad747cfc3e  call 0x000074AD746E2420
000074ad747cfc43  jmp 0x000074AD747CF3ED
000074ad747cfc48  call 0x000074AD746E2420
000074ad747cfc4d  jmp 0x000074AD747CF3FE
000074ad747cfc52  call 0x000074AD746E2420
000074ad747cfc57  jmp 0x000074AD747CF40F
000074ad747cfc5c  call 0x000074AD746E2420
000074ad747cfc61  jmp 0x000074AD747CF420
000074ad747cfc66  call 0x000074AD746E2420
000074ad747cfc6b  jmp 0x000074AD747CF431
000074ad747cfc70  call 0x000074AD746E2420
000074ad747cfc75  jmp 0x000074AD747CF442
000074ad747cfc7a  call 0x000074AD746E2420
000074ad747cfc7f  jmp 0x000074AD747CF453
000074ad747cfc84  call 0x000074AD746E2420
000074ad747cfc89  jmp 0x000074AD747CF464
000074ad747cfc8e  call 0x000074AD746E2420
000074ad747cfc93  jmp 0x000074AD747CF475
000074ad747cfc98  call 0x000074AD746E2420
000074ad747cfc9d  jmp 0x000074AD747CF486
000074ad747cfca2  call 0x000074AD746E2420
000074ad747cfca7  jmp 0x000074AD747CF497
000074ad747cfcac  call 0x000074AD746E2420
000074ad747cfcb1  jmp 0x000074AD747CF4A8
000074ad747cfcb6  call 0x000074AD746E2420
000074ad747cfcbb  jmp 0x000074AD747CF4B9
000074ad747cfcc0  call 0x000074AD746E2420
000074ad747cfcc5  jmp 0x000074AD747CF4CA
000074ad747cfcca  call 0x000074AD746E2420
000074ad747cfccf  jmp 0x000074AD747CF4DB
000074ad747cfcd4  call 0x000074AD746E2420
000074ad747cfcd9  jmp 0x000074AD747CF4EC
000074ad747cfcde  call 0x000074AD746E2420
000074ad747cfce3  jmp 0x000074AD747CF4FD
000074ad747cfce8  call 0x000074AD746E2420
000074ad747cfced  jmp 0x000074AD747CF50E
000074ad747cfcf2  call 0x000074AD746E2420
000074ad747cfcf7  jmp 0x000074AD747CF51F
000074ad747cfcfc  call 0x000074AD746E2420
000074ad747cfd01  jmp 0x000074AD747CF530
000074ad747cfd06  call 0x000074AD746E2420
000074ad747cfd0b  jmp 0x000074AD747CF541
000074ad747cfd10  call 0x000074AD746E2420
000074ad747cfd15  jmp 0x000074AD747CF552
000074ad747cfd1a  call 0x000074AD746E2420
000074ad747cfd1f  jmp 0x000074AD747CF563
000074ad747cfd24  call 0x000074AD746E2420
000074ad747cfd29  jmp 0x000074AD747CF574
000074ad747cfd2e  call 0x000074AD746E2420
000074ad747cfd33  jmp 0x000074AD747CF585
000074ad747cfd38  call 0x000074AD746E2420
000074ad747cfd3d  jmp 0x000074AD747CF596
000074ad747cfd42  call 0x000074AD746E2420
000074ad747cfd47  jmp 0x000074AD747CF5AF
000074ad747cfd4c  call 0x000074AD746E2420
000074ad747cfd51  jmp 0x000074AD747CF5C8
000074ad747cfd56  call 0x000074AD746D5610
000074ad747cfd5b  jmp 0x000074AD747CF5E1
000074ad747cfd60  call 0x000074AD746DC580
000074ad747cfd65  jmp 0x000074AD747CF94E
000074ad747cfd6a  call 0x000074AD746E46C0
000074ad747cfd6f  jmp 0x000074AD747CF958
000074ad747cfd74  call 0x000074AD74609E90
000074ad747cfd79  jmp 0x000074AD747CF95E
000074ad747cfd7e  call 0x000074AD746DB310
000074ad747cfd83  jmp 0x000074AD747CF968
000074ad747cfd88  call 0x000074AD7460DAE0
000074ad747cfd8d  jmp 0x000074AD747CF96D
000074ad747cfd92  call 0x000074AD746C0230
000074ad747cfd97  jmp 0x000074AD747CF986
000074ad747cfd9c  call 0x000074AD746C0230
000074ad747cfda1  jmp 0x000074AD747CF99B
000074ad747cfda6  call 0x000074AD746BEFC0
000074ad747cfdab  jmp 0x000074AD747CF9A4
000074ad747cfdb0  call 0x000074AD746E2BA0
000074ad747cfdb5  jmp 0x000074AD747CFA6B
000074ad747cfdba  int3
000074ad747cfdbb  nop [rax+rax*1], eax
000074ad747cfdc0  mov rax, [r15+0x48]
000074ad747cfdc4  mov r14, [r15+0x58]
000074ad747cfdc8  lea r12, [rax+r14*1]
000074ad747cfdcc  mov [r15+0x68], r12
000074ad747cfdd0  lea rax, [r14+0x04]
000074ad747cfdd4  mov [r15+0x58], rax
000074ad747cfdd8  lea r14, [r12+0x04]
000074ad747cfddd  mov r11d, [r13+r14*1]
000074ad747cfde2  mov [rsp+0x10], r11d
000074ad747cfde7  mov r11d, r11d
000074ad747cfdea  mov [r15+0x70], r11
000074ad747cfdee  lea r14, [r12+0x38]
000074ad747cfdf3  mov r11d, [r13+r14*1]
000074ad747cfdf8  lea r14, [r12+0x24]
000074ad747cfdfd  mov r10d, [r13+r14*1]
000074ad747cfe02  mov [rsp+0x20], r10d
000074ad747cfe07  mov r10d, r10d
000074ad747cfe0a  mov [r15+0x90], r10
000074ad747cfe11  mov [rsp+0x30], rax
000074ad747cfe16  xor eax, eax
000074ad747cfe18  mov r14, [rsp+0x30]
000074ad747cfe1d  mov r10d, 0xC0
000074ad747cfe23  cmp r14, r10
000074ad747cfe26  cmc
000074ad747cfe27  lahf
000074ad747cfe28  seto al
000074ad747cfe2b  mov [r15+0x108], eax
000074ad747cfe32  mov eax, [rsp+0x10]
000074ad747cfe36  mov r14d, [rsp+0x10]
000074ad747cfe3b  shrd eax, r14d, 0x07
000074ad747cfe40  mov [rsp+0x10], r11d
000074ad747cfe45  mov r10d, [rsp+0x10]
000074ad747cfe4a  shrd r11d, r10d, 0x11
000074ad747cfe4f  mov r9d, [r15+0x60]
000074ad747cfe53  mov r8d, [rsp+0x20]
000074ad747cfe58  lea ebp, [r8d+r9d*1]
000074ad747cfe5d  rorx r9d, r14d, 0x12
000074ad747cfe63  xor eax, r9d
000074ad747cfe66  rorx r9d, r10d, 0x13
000074ad747cfe6c  xor r11d, r9d
000074ad747cfe6f  mov [rsp+0x10], r11d
000074ad747cfe74  mov r11d, r11d
000074ad747cfe77  mov [r15+0x88], r11
000074ad747cfe7e  mov [rsp+0x20], r14d
000074ad747cfe83  shr r14d, 0x03
000074ad747cfe87  xor eax, r14d
000074ad747cfe8a  mov [rsp+0x30], eax
000074ad747cfe8e  mov eax, eax
000074ad747cfe90  mov [r15+0x80], rax
000074ad747cfe97  shr r10d, 0x0A
000074ad747cfe9b  mov eax, [rsp+0x10]
000074ad747cfe9f  xor eax, r10d
000074ad747cfea2  mov [rsp+0x10], eax
000074ad747cfea6  mov eax, eax
000074ad747cfea8  mov [r15+0x78], rax
000074ad747cfeac  mov eax, [rsp+0x30]
000074ad747cfeb0  lea r14d, [ebp+eax*1]
000074ad747cfeb6  mov eax, [rsp+0x10]
000074ad747cfeba  lea r11d, [r14d+eax*1]
000074ad747cfebf  lea rax, [r12+0x40]
000074ad747cfec4  mov [r13+rax*1], r11d
000074ad747cfec9  mov eax, [rsp+0x20]
000074ad747cfecd  mov eax, eax
000074ad747cfecf  mov [r15+0x60], rax
000074ad747cfed3  mov eax, [r15+0x108]
000074ad747cfeda  sahf
000074ad747cfedb  jnz 0x000074AD747CFF0D
000074ad747cfedd  cmp dword ptr [r15+0x318], 0x00
000074ad747cfee5  jz 0x000074AD747CFF70
000074ad747cfeeb  nop [rax+rax*1], ax
000074ad747cfef4  nop [rax+rax*1], eax
000074ad747cfefc  mov eax, 0x410820
000074ad747cff01  mov [r15+0x100], rax
000074ad747cff08  jmp 0x000074AD745FE110
000074ad747cff0d  cmp dword ptr [r15+0x318], 0x00
000074ad747cff15  jz 0x000074AD747CFDC0
000074ad747cff1b  nop [rax+rax*1], ax
000074ad747cff24  nop [rax+rax*1], eax
000074ad747cff2c  mov eax, 0x4107D8
000074ad747cff31  mov [r15+0x100], rax
000074ad747cff38  jmp 0x000074AD745FE110
000074ad747cff3d  int3
000074ad747cff3e  call 0x000074AD746E1430
000074ad747cff43  jmp 0x000074AD747CFDE2
000074ad747cff48  call 0x000074AD746E1430
000074ad747cff4d  jmp 0x000074AD747CFDF8
000074ad747cff52  call 0x000074AD746E01C0
000074ad747cff57  jmp 0x000074AD747CFE02
000074ad747cff5c  call 0x000074AD7460A860
000074ad747cff61  jmp 0x000074AD747CFEC9
000074ad747cff66  int3
000074ad747cff67  nop [rax+rax*1], ax
000074ad747cff70  mov rax, [r15]
000074ad747cff73  mov r14d, [r13+rax*1]
000074ad747cff78  lea r12, [rax+0x04]
000074ad747cff7c  mov r11d, [r13+r12*1]
000074ad747cff81  mov [rsp+0x10], r14d
000074ad747cff86  mov r14d, r14d
000074ad747cff89  mov [r15+0x78], r14
000074ad747cff8d  mov [rsp+0x20], r11d
000074ad747cff92  mov r11d, r11d
000074ad747cff95  mov [r15+0x80], r11
000074ad747cff9c  lea r14, [rax+0x08]
000074ad747cffa0  mov r12d, [r13+r14*1]
000074ad747cffa5  lea r14, [rax+0x0C]
000074ad747cffa9  mov r11d, [r13+r14*1]
000074ad747cffae  mov [rsp+0x30], r12d
000074ad747cffb3  mov r12d, r12d
000074ad747cffb6  mov [r15+0x70], r12
000074ad747cffba  mov [rsp+0x40], r11d
000074ad747cffbf  mov r11d, r11d
000074ad747cffc2  mov [r15+0x68], r11
000074ad747cffc6  lea r14, [rax+0x18]
000074ad747cffca  mov r12d, [r13+r14*1]
000074ad747cffcf  lea r14, [rax+0x1C]
000074ad747cffd3  mov r11d, [r13+r14*1]
000074ad747cffd8  mov [rsp+0x50], r12d
000074ad747cffdd  mov r12d, r12d
000074ad747cffe0  mov [r15+0x58], r12
000074ad747cffe4  mov [rsp+0x60], r11d
000074ad747cffe9  mov r11d, r11d
000074ad747cffec  mov [r15+0x60], r11
000074ad747cfff0  lea r14, [rax+0x10]
000074ad747cfff4  mov r12d, [r13+r14*1]
000074ad747cfff9  lea r14, [rax+0x14]
000074ad747cfffd  mov eax, [r13+r14*1]
000074ad747d0002  mov [rsp+0x70], r12d
000074ad747d0007  mov r12d, r12d
000074ad747d000a  mov [r15+0x18], r12
000074ad747d000e  mov [rsp+0x80], eax
000074ad747d0015  mov eax, eax
000074ad747d0017  mov [r15+0x90], rax
000074ad747d001e  mov eax, [rsp+0x70]
000074ad747d0022  mov eax, eax
000074ad747d0024  mov [r15+0x30], rax
000074ad747d0028  mov eax, [rsp+0x50]
000074ad747d002c  mov eax, eax
000074ad747d002e  mov [r15+0xA0], rax
000074ad747d0035  mov eax, [rsp+0x30]
000074ad747d0039  mov eax, eax
000074ad747d003b  mov [r15+0x28], rax
000074ad747d003f  mov eax, [rsp+0x20]
000074ad747d0043  mov eax, eax
000074ad747d0045  mov [r15+0x98], rax
000074ad747d004c  mov eax, [rsp+0x10]
000074ad747d0050  mov eax, eax
000074ad747d0052  mov [r15+0x38], rax
000074ad747d0056  mov eax, [rsp+0x70]
000074ad747d005a  mov r14d, [rsp+0x70]
000074ad747d005f  shrd eax, r14d, 0x06
000074ad747d0064  mov [rsp+0x70], r14d
000074ad747d0069  mov r12d, [rsp+0x80]
000074ad747d0071  and r14d, r12d
000074ad747d0074  mov r11d, [rsp+0x10]
000074ad747d0079  mov r10d, [rsp+0x10]
000074ad747d007e  shrd r11d, r10d, 0x02
000074ad747d0083  mov [rsp+0x10], r12d
000074ad747d0088  mov r12d, r12d
000074ad747d008b  mov [r15+0x20], r12
000074ad747d008f  mov r12, [r15+0x50]
000074ad747d0093  mov r9d, [r13+r12*1]
000074ad747d0098  mov r12d, [rsp+0x50]
000074ad747d009d  mov r8d, [rsp+0x70]
000074ad747d00a2  andn ebp, r8d, r12d
000074ad747d00a7  mov edi, [rsp+0x60]
000074ad747d00ab  lea esi, [r14d+edi*1]
000074ad747d00b0  rorx r14d, r8d, 0x0B
000074ad747d00b6  xor eax, r14d
000074ad747d00b9  rorx r14d, r10d, 0x0D
000074ad747d00bf  xor r11d, r14d
000074ad747d00c2  lea edi, [esi+ebp*1]
000074ad747d00c6  mov r14, [r15+0x48]
000074ad747d00ca  mov ebp, [r13+r14*1]
000074ad747d00cf  mov r14d, [rsp+0x30]
000074ad747d00d4  mov esi, [rsp+0x20]
000074ad747d00d8  and r14d, esi
000074ad747d00db  mov [rsp+0x20], r14d
000074ad747d00e0  mov r14d, r14d
000074ad747d00e3  mov [r15+0xD8], r14
000074ad747d00ea  lea r14d, [edi+r9d*1]
000074ad747d00ef  mov r9d, [rsp+0x30]
000074ad747d00f4  xor r9d, esi
000074ad747d00f7  rorx edi, r8d, 0x19
000074ad747d00fd  xor eax, edi
000074ad747d00ff  and r9d, r10d
000074ad747d0102  rorx edi, r10d, 0x16
000074ad747d0108  xor r11d, edi
000074ad747d010b  mov [rsp+0x30], r11d
000074ad747d0110  mov r11d, r11d
000074ad747d0113  mov [r15+0xD0], r11
000074ad747d011a  lea r11d, [r14d+ebp*1]
000074ad747d011f  mov r10d, [rsp+0x20]
000074ad747d0124  xor r9d, r10d
000074ad747d0127  lea r14d, [r11d+eax*1]
000074ad747d012c  mov qword ptr [r15+0x88], 0x04
000074ad747d0137  mov eax, [rsp+0x30]
000074ad747d013b  lea r11d, [r9d+eax*1]
000074ad747d0140  mov eax, [rsp+0x40]
000074ad747d0144  lea r10d, [r14d+eax*1]
000074ad747d0149  mov r10d, r10d
000074ad747d014c  mov [r15+0xB8], r10
000074ad747d0153  xor eax, eax
000074ad747d0155  mov r10d, 0x04
000074ad747d015b  mov r9d, 0x100
000074ad747d0161  cmp r10, r9
000074ad747d0164  cmc
000074ad747d0165  lahf
000074ad747d0166  seto al
000074ad747d0169  mov [r15+0x108], eax
000074ad747d0170  lea eax, [r11d+r14d*1]
000074ad747d0175  mov eax, eax
000074ad747d0177  mov [r15+0xA8], rax
000074ad747d017e  mov r12d, r12d
000074ad747d0181  mov [r15+0xB0], r12
000074ad747d0188  mov eax, [rsp+0x10]
000074ad747d018c  mov eax, eax
000074ad747d018e  mov [r15+0xC0], rax
000074ad747d0195  mov r8d, r8d
000074ad747d0198  mov [r15+0xC8], r8
000074ad747d019f  mov eax, [r15+0x108]
000074ad747d01a6  sahf
000074ad747d01a7  jnz 0x000074AD747D01D9
000074ad747d01a9  cmp dword ptr [r15+0x318], 0x00
000074ad747d01b1  jz 0x000074AD747D04A0
000074ad747d01b7  nop [rax+rax*1], ax
000074ad747d01c0  nop [rax+rax*1], eax
000074ad747d01c8  mov eax, 0x4108E0
000074ad747d01cd  mov [r15+0x100], rax
000074ad747d01d4  jmp 0x000074AD745FE110
000074ad747d01d9  cmp dword ptr [r15+0x318], 0x00
000074ad747d01e1  jz 0x000074AD747D0270
000074ad747d01e7  nop [rax+rax*1], ax
000074ad747d01f0  nop [rax+rax*1], eax
000074ad747d01f8  mov eax, 0x410854
000074ad747d01fd  mov [r15+0x100], rax
000074ad747d0204  jmp 0x000074AD745FE110
000074ad747d0209  int3
000074ad747d020a  call 0x000074AD7460DAE0
000074ad747d020f  jmp 0x000074AD747CFF78
000074ad747d0214  call 0x000074AD746C0230
000074ad747d0219  jmp 0x000074AD747CFF81
000074ad747d021e  call 0x000074AD746E26A0
000074ad747d0223  jmp 0x000074AD747CFFA5
000074ad747d0228  call 0x000074AD746E1430
000074ad747d022d  jmp 0x000074AD747CFFAE
000074ad747d0232  call 0x000074AD746E26A0
000074ad747d0237  jmp 0x000074AD747CFFCF
000074ad747d023c  call 0x000074AD746E1430
000074ad747d0241  jmp 0x000074AD747CFFD8
000074ad747d0246  call 0x000074AD746E26A0
000074ad747d024b  jmp 0x000074AD747CFFF9
000074ad747d0250  call 0x000074AD746D5890
000074ad747d0255  jmp 0x000074AD747D0002
000074ad747d025a  call 0x000074AD746BDD50
000074ad747d025f  jmp 0x000074AD747D0098
000074ad747d0264  call 0x000074AD746DA580
000074ad747d0269  jmp 0x000074AD747D00CF
000074ad747d026e  int3
000074ad747d026f  nop
000074ad747d0270  mov eax, [r15+0xB8]
000074ad747d0277  mov [rsp+0x10], eax
000074ad747d027b  mov eax, eax
000074ad747d027d  mov [r15+0x30], rax
000074ad747d0281  mov eax, [r15+0xC0]
000074ad747d0288  mov [rsp+0x20], eax
000074ad747d028c  mov eax, eax
000074ad747d028e  mov [r15+0xA0], rax
000074ad747d0295  mov eax, [r15+0x28]
000074ad747d0299  mov r14d, [r15+0x98]
000074ad747d02a0  mov [rsp+0x30], r14d
000074ad747d02a5  mov r14d, r14d
000074ad747d02a8  mov [r15+0x28], r14
000074ad747d02ac  mov r14d, [r15+0x38]
000074ad747d02b0  mov [rsp+0x40], r14d
000074ad747d02b5  mov r14d, r14d
000074ad747d02b8  mov [r15+0x98], r14
000074ad747d02bf  mov r14d, [r15+0xA8]
000074ad747d02c6  mov [rsp+0x50], r14d
000074ad747d02cb  mov r14d, r14d
000074ad747d02ce  mov [r15+0x38], r14
000074ad747d02d2  mov r14d, [rsp+0x10]
000074ad747d02d7  mov r12d, [rsp+0x10]
000074ad747d02dc  shrd r14d, r12d, 0x06
000074ad747d02e1  mov r11d, [r15+0xC8]
000074ad747d02e8  mov [rsp+0x10], r12d
000074ad747d02ed  and r12d, r11d
000074ad747d02f0  mov r10d, [rsp+0x50]
000074ad747d02f5  mov r9d, [rsp+0x50]
000074ad747d02fa  shrd r10d, r9d, 0x02
000074ad747d02ff  mov [rsp+0x50], r11d
000074ad747d0304  mov r11d, r11d
000074ad747d0307  mov [r15+0x20], r11
000074ad747d030b  mov r11, [r15+0x88]
000074ad747d0312  mov r8, [r15+0x50]
000074ad747d0316  lea rbp, [r8+r11*1]
000074ad747d031a  mov r8d, [r13+rbp*1]
000074ad747d031f  mov ebp, [rsp+0x20]
000074ad747d0323  mov edi, [rsp+0x10]
000074ad747d0327  andn esi, edi, ebp
000074ad747d032c  mov edx, [r15+0xB0]
000074ad747d0333  lea ecx, [r12d+edx*1]
000074ad747d0338  rorx r12d, edi, 0x0B
000074ad747d033e  xor r14d, r12d
000074ad747d0341  rorx r12d, r9d, 0x0D
000074ad747d0347  xor r10d, r12d
000074ad747d034a  lea r12d, [ecx+esi*1]
000074ad747d034f  mov rsi, [r15+0x48]
000074ad747d0353  lea rdx, [rsi+r11*1]
000074ad747d0357  mov esi, [r13+rdx*1]
000074ad747d035c  mov edx, [rsp+0x30]
000074ad747d0360  mov ecx, [rsp+0x40]
000074ad747d0364  and edx, ecx
000074ad747d0366  mov [rsp+0x10], edx
000074ad747d036a  mov edx, edx
000074ad747d036c  mov [r15+0xD8], rdx
000074ad747d0373  lea edx, [r12d+r8d*1]
000074ad747d0378  mov r12d, [rsp+0x30]
000074ad747d037d  xor r12d, ecx
000074ad747d0380  rorx r8d, edi, 0x19
000074ad747d0386  xor r14d, r8d
000074ad747d0389  and r12d, r9d
000074ad747d038c  rorx r8d, r9d, 0x16
000074ad747d0392  xor r10d, r8d
000074ad747d0395  mov [rsp+0x20], r10d
000074ad747d039a  mov r10d, r10d
000074ad747d039d  mov [r15+0xD0], r10
000074ad747d03a4  lea r10d, [edx+esi*1]
000074ad747d03a9  mov r9d, [rsp+0x10]
000074ad747d03ae  xor r12d, r9d
000074ad747d03b1  lea r9d, [r10d+r14d*1]
000074ad747d03b6  lea r14, [r11+0x04]
000074ad747d03ba  mov [r15+0x88], r14
000074ad747d03c1  mov r11d, [rsp+0x20]
000074ad747d03c6  lea r10d, [r12d+r11d*1]
000074ad747d03cb  lea r11d, [r9d+eax*1]
000074ad747d03d0  mov r11d, r11d
000074ad747d03d3  mov [r15+0xB8], r11
000074ad747d03da  xor eax, eax
000074ad747d03dc  mov r12d, 0x100
000074ad747d03e2  cmp r14, r12
000074ad747d03e5  cmc
000074ad747d03e6  lahf
000074ad747d03e7  seto al
000074ad747d03ea  mov [r15+0x108], eax
000074ad747d03f1  lea eax, [r10d+r9d*1]
000074ad747d03f6  mov eax, eax
000074ad747d03f8  mov [r15+0xA8], rax
000074ad747d03ff  mov ebp, ebp
000074ad747d0401  mov [r15+0xB0], rbp
000074ad747d0408  mov eax, [rsp+0x50]
000074ad747d040c  mov eax, eax
000074ad747d040e  mov [r15+0xC0], rax
000074ad747d0415  mov edi, edi
000074ad747d0417  mov [r15+0xC8], rdi
000074ad747d041e  mov eax, [r15+0x108]
000074ad747d0425  sahf
000074ad747d0426  jnz 0x000074AD747D0458
000074ad747d0428  cmp dword ptr [r15+0x318], 0x00
000074ad747d0430  jz 0x000074AD747D04A0
000074ad747d0436  nop [rax+rax*1], ax
000074ad747d043f  nop [rax+rax*1], eax
000074ad747d0447  mov eax, 0x4108E0
000074ad747d044c  mov [r15+0x100], rax
000074ad747d0453  jmp 0x000074AD745FE110
000074ad747d0458  cmp dword ptr [r15+0x318], 0x00
000074ad747d0460  jz 0x000074AD747D0270
000074ad747d0466  nop [rax+rax*1], ax
000074ad747d046f  nop [rax+rax*1], eax
000074ad747d0477  mov eax, 0x410854
000074ad747d047c  mov [r15+0x100], rax
000074ad747d0483  jmp 0x000074AD745FE110
000074ad747d0488  int3
000074ad747d0489  call 0x000074AD74649010
000074ad747d048e  jmp 0x000074AD747D031F
000074ad747d0493  call 0x000074AD74625930
000074ad747d0498  jmp 0x000074AD747D035C
000074ad747d049d  int3
000074ad747d049e  nop
000074ad747d04a0  mov eax, [r15+0x98]
000074ad747d04a7  mov r14d, [r15+0x70]
000074ad747d04ab  lea r12d, [eax+r14d*1]
000074ad747d04b0  mov eax, [r15+0x28]
000074ad747d04b4  mov r14d, [r15+0x68]
000074ad747d04b8  lea r11d, [eax+r14d*1]
000074ad747d04bd  mov qword ptr [r15+0x88], 0x00
000074ad747d04c8  mov eax, [r15+0xA8]
000074ad747d04cf  mov r14d, [r15+0x78]
000074ad747d04d3  lea r10d, [eax+r14d*1]
000074ad747d04d8  mov [rsp+0x10], r10d
000074ad747d04dd  mov r10d, r10d
000074ad747d04e0  mov [r15+0x78], r10
000074ad747d04e4  mov eax, [r15+0x38]
000074ad747d04e8  mov r14d, [r15+0x80]
000074ad747d04ef  lea r10d, [eax+r14d*1]
000074ad747d04f4  mov [rsp+0x20], r10d
000074ad747d04f9  mov r10d, r10d
000074ad747d04fc  mov [r15+0x80], r10
000074ad747d0503  mov rax, [r15]
000074ad747d0506  lea r14, [rax+0x08]
000074ad747d050a  mov [r13+r14*1], r12d
000074ad747d050f  lea r14, [rax+0x0C]
000074ad747d0513  mov [r13+r14*1], r11d
000074ad747d0518  mov r14d, [r15+0xB8]
000074ad747d051f  mov r12d, [r15+0x18]
000074ad747d0523  lea r11d, [r14d+r12d*1]
000074ad747d0528  mov [rsp+0x30], r11d
000074ad747d052d  mov r11d, r11d
000074ad747d0530  mov [r15+0x68], r11
000074ad747d0534  mov r14d, [r15+0x30]
000074ad747d0538  mov r12d, [r15+0x90]
000074ad747d053f  lea r11d, [r14d+r12d*1]
000074ad747d0544  mov [rsp+0x40], r11d
000074ad747d0549  mov r11d, r11d
000074ad747d054c  mov [r15+0x70], r11
000074ad747d0550  mov r14d, [r15+0x20]
000074ad747d0554  mov r12d, [r15+0x58]
000074ad747d0558  lea r11d, [r14d+r12d*1]
000074ad747d055d  mov [rsp+0x50], r11d
000074ad747d0562  mov r11d, r11d
000074ad747d0565  mov [r15+0x58], r11
000074ad747d0569  mov r14d, [r15+0xA0]
000074ad747d0570  mov r12d, [r15+0x60]
000074ad747d0574  lea r11d, [r14d+r12d*1]
000074ad747d0579  mov [rsp+0x60], r11d
000074ad747d057e  mov r11d, r11d
000074ad747d0581  mov [r15+0x60], r11
000074ad747d0585  mov r14d, [rsp+0x10]
000074ad747d058a  mov [r13+rax*1], r14d
000074ad747d058f  lea r14, [rax+0x04]
000074ad747d0593  mov r12d, [rsp+0x20]
000074ad747d0598  mov [r13+r14*1], r12d
000074ad747d059d  lea r14, [rax+0x10]
000074ad747d05a1  mov r12d, [rsp+0x30]
000074ad747d05a6  mov [r13+r14*1], r12d
000074ad747d05ab  lea r14, [rax+0x14]
000074ad747d05af  mov r12d, [rsp+0x40]
000074ad747d05b4  mov [r13+r14*1], r12d
000074ad747d05b9  lea r14, [rax+0x18]
000074ad747d05bd  mov r12d, [rsp+0x50]
000074ad747d05c2  mov [r13+r14*1], r12d
000074ad747d05c7  lea r14, [rax+0x1C]
000074ad747d05cb  mov r12d, [rsp+0x60]
000074ad747d05d0  mov [r13+r14*1], r12d
000074ad747d05d5  lea r14, [rax+0x68]
000074ad747d05d9  xor eax, eax
000074ad747d05db  mov [r13+r14*1], rax
000074ad747d05e0  cmp dword ptr [r15+0x318], 0x00
000074ad747d05e8  jz 0x000074AD747CF0E0
000074ad747d05ee  nop [rax+rax*1], ax
000074ad747d05f7  nop [rax+rax*1], eax
000074ad747d05ff  mov eax, 0x4106FC
000074ad747d0604  mov [r15+0x100], rax
000074ad747d060b  jmp 0x000074AD745FE110
000074ad747d0610  int3
000074ad747d0611  call 0x000074AD746E2BA0
000074ad747d0616  jmp 0x000074AD747D050F
000074ad747d061b  call 0x000074AD746E1920
000074ad747d0620  jmp 0x000074AD747D0518
000074ad747d0625  call 0x000074AD7460DFE0
000074ad747d062a  jmp 0x000074AD747D058F
000074ad747d062f  call 0x000074AD746E2BA0
000074ad747d0634  jmp 0x000074AD747D059D
000074ad747d0639  call 0x000074AD746E2BA0
000074ad747d063e  jmp 0x000074AD747D05AB
000074ad747d0643  call 0x000074AD746E2BA0
000074ad747d0648  jmp 0x000074AD747D05B9
000074ad747d064d  call 0x000074AD746E2BA0
000074ad747d0652  jmp 0x000074AD747D05C7
000074ad747d0657  call 0x000074AD746E2BA0
000074ad747d065c  jmp 0x000074AD747D05D5
000074ad747d0661  call 0x000074AD746D5EB0
000074ad747d0666  jmp 0x000074AD747D05E0
000074ad747d066b  int3
000074ad747d066c  nop [rax], eax
000074ad747d0670  mov rax, [r15+0xF8]
000074ad747d0677  lea r14, [rax+0x140]
000074ad747d067e  mov r12, [r13+r14*1]
000074ad747d0683  lea r14, [rax+0x148]
000074ad747d068a  mov r11, [r13+r14*1]
000074ad747d068f  mov [r15+0xA0], r12
000074ad747d0696  mov [r15+0x98], r11
000074ad747d069d  lea r14, [rax+0x130]
000074ad747d06a4  mov r12, [r13+r14*1]
000074ad747d06a9  lea r14, [rax+0x138]
000074ad747d06b0  mov r11, [r13+r14*1]
000074ad747d06b5  mov [r15+0xB0], r12
000074ad747d06bc  mov [r15+0xA8], r11
000074ad747d06c3  lea r14, [rax+0x120]
000074ad747d06ca  mov r12, [r13+r14*1]
000074ad747d06cf  lea r14, [rax+0x128]
000074ad747d06d6  mov r11, [r13+r14*1]
000074ad747d06db  mov [r15+0xC0], r12
000074ad747d06e2  mov [r15+0xB8], r11
000074ad747d06e9  lea r14, [rax+0x110]
000074ad747d06f0  mov r12, [r13+r14*1]
000074ad747d06f5  lea r14, [rax+0x118]
000074ad747d06fc  mov r11, [r13+r14*1]
000074ad747d0701  mov [r15+0xD0], r12
000074ad747d0708  mov [r15+0xC8], r11
000074ad747d070f  lea r14, [rax+0x100]
000074ad747d0716  mov r12, [r13+r14*1]
000074ad747d071b  lea r14, [rax+0x108]
000074ad747d0722  mov r11, [r13+r14*1]
000074ad747d0727  mov [r15+0xE8], r12
000074ad747d072e  mov [r15+0xD8], r11
000074ad747d0735  lea r14, [rax+0x150]
000074ad747d073c  mov [r15+0xF8], r14
000074ad747d0743  mov rax, [r15+0xF0]
000074ad747d074a  mov [r15+0x100], rax
000074ad747d0751  jmp 0x000074AD747CE5C0
000074ad747d0756  int3
000074ad747d0757  call 0x000074AD746E27E0
000074ad747d075c  jmp 0x000074AD747D0683
000074ad747d0761  call 0x000074AD746E1570
000074ad747d0766  jmp 0x000074AD747D068F
000074ad747d076b  call 0x000074AD746E27E0
000074ad747d0770  jmp 0x000074AD747D06A9
000074ad747d0775  call 0x000074AD746E1570
000074ad747d077a  jmp 0x000074AD747D06B5
000074ad747d077f  call 0x000074AD746E27E0
000074ad747d0784  jmp 0x000074AD747D06CF
000074ad747d0789  call 0x000074AD746E1570
000074ad747d078e  jmp 0x000074AD747D06DB
000074ad747d0793  call 0x000074AD746E27E0
000074ad747d0798  jmp 0x000074AD747D06F5
000074ad747d079d  call 0x000074AD746E1570
000074ad747d07a2  jmp 0x000074AD747D0701
000074ad747d07a7  call 0x000074AD746E27E0
000074ad747d07ac  jmp 0x000074AD747D071B
000074ad747d07b1  call 0x000074AD746E1570
000074ad747d07b6  jmp 0x000074AD747D0727
000074ad747d07bb  int3
000074ad747d07bc  nop [rax], eax
000074ad747d07c0  mov eax, [r15+0xA0]
000074ad747d07c7  mov [rsp+0x10], eax
000074ad747d07cb  xor eax, eax
000074ad747d07cd  mov r14d, [rsp+0x10]
000074ad747d07d2  sub r14d, 0x01
000074ad747d07d6  cmc
000074ad747d07d7  lahf
000074ad747d07d8  seto al
000074ad747d07db  mov [r15+0x108], eax
000074ad747d07e2  mov r14d, r14d
000074ad747d07e5  mov [r15+0xA0], r14
000074ad747d07ec  mov eax, [r15+0x108]
000074ad747d07f3  sahf
000074ad747d07f4  jnz 0x000074AD747D0826
000074ad747d07f6  cmp dword ptr [r15+0x318], 0x00
000074ad747d07fe  jz 0x000074AD747D0900
000074ad747d0804  nop [rax+rax*1], ax
000074ad747d080d  nop [rax+rax*1], eax
000074ad747d0815  mov eax, 0x41028C
000074ad747d081a  mov [r15+0x100], rax
000074ad747d0821  jmp 0x000074AD745FE110
000074ad747d0826  cmp dword ptr [r15+0x318], 0x00
000074ad747d082e  jz 0x000074AD747D0860
000074ad747d0834  nop [rax+rax*1], ax
000074ad747d083d  nop [rax+rax*1], eax
000074ad747d0845  mov eax, 0x410274
000074ad747d084a  mov [r15+0x100], rax
000074ad747d0851  jmp 0x000074AD745FE110
000074ad747d0856  int3
000074ad747d0857  int3
000074ad747d0858  nop [rax+rax*1], eax
000074ad747d0860  mov rax, [r15+0xF8]
000074ad747d0867  lea r14, [rax+0xD0]
000074ad747d086e  mov [r15], r14
000074ad747d0871  mov rax, [r15+0x98]
000074ad747d0878  mov [r15+0x08], rax
000074ad747d087c  mov qword ptr [r15+0x10], 0x12C
000074ad747d0884  mov qword ptr [r15+0xF0], 0x410284
000074ad747d088f  mov r14d, [r15+0x320]
000074ad747d0896  mov eax, 0x410284
000074ad747d089b  mov rcx, 0x74AD747D07C0
000074ad747d08a5  mov [r15+r14*8+0x328], rax
000074ad747d08ad  mov [r15+r14*8+0x368], rcx
000074ad747d08b5  add r14d, 0x01
000074ad747d08b9  and r14d, 0x07
000074ad747d08bd  mov [r15+0x320], r14d
000074ad747d08c4  cmp dword ptr [r15+0x318], 0x00
000074ad747d08cc  jz 0x000074AD747CED70
000074ad747d08d2  nop [rax+rax*1], ax
000074ad747d08db  nop [rax+rax*1], eax
000074ad747d08e3  mov eax, 0x4106BC
000074ad747d08e8  mov [r15+0x100], rax
000074ad747d08ef  jmp 0x000074AD745FE110
000074ad747d08f4  int3
000074ad747d08f5  int3
000074ad747d08f6  nop [rax+rax*1], ax
000074ad747d08ff  nop
000074ad747d0900  mov rax, [r15+0xF8]
000074ad747d0907  lea r14, [rax+0xF0]
000074ad747d090e  mov r12, [r13+r14*1]
000074ad747d0913  mov [r15+0x98], r12
000074ad747d091a  mov qword ptr [r15+0x40], 0x80
000074ad747d0922  lea r14, [rax+0xD0]
000074ad747d0929  mov [r15], r14
000074ad747d092c  lea r14, [rax+0x14C]
000074ad747d0933  mov [r15+0x08], r14
000074ad747d0937  mov qword ptr [r15+0x10], 0x01
000074ad747d093f  lea r14, [rax+0x14C]
000074ad747d0946  mov eax, 0x80
000074ad747d094b  mov [r13+r14*1], al
000074ad747d0950  mov qword ptr [r15+0xF0], 0x4102A8
000074ad747d095b  mov r14d, [r15+0x320]
000074ad747d0962  mov eax, 0x4102A8
000074ad747d0967  mov rcx, 0x74AD747D09E0
000074ad747d0971  mov [r15+r14*8+0x328], rax
000074ad747d0979  mov [r15+r14*8+0x368], rcx
000074ad747d0981  add r14d, 0x01
000074ad747d0985  and r14d, 0x07
000074ad747d0989  mov [r15+0x320], r14d
000074ad747d0990  cmp dword ptr [r15+0x318], 0x00
000074ad747d0998  jz 0x000074AD747CED70
000074ad747d099e  nop [rax+rax*1], ax
000074ad747d09a7  nop [rax+rax*1], eax
000074ad747d09af  mov eax, 0x4106BC
000074ad747d09b4  mov [r15+0x100], rax
000074ad747d09bb  jmp 0x000074AD745FE110
000074ad747d09c0  int3
000074ad747d09c1  call 0x000074AD746E27E0
000074ad747d09c6  jmp 0x000074AD747D0913
000074ad747d09cb  call 0x000074AD746D5AF0
000074ad747d09d0  jmp 0x000074AD747D0950
000074ad747d09d5  int3
000074ad747d09d6  nop [rax+rax*1], ax
000074ad747d09df  nop
000074ad747d09e0  mov rax, [r15+0xF8]
000074ad747d09e7  lea r14, [rax+0x138]
000074ad747d09ee  mov r12, [r13+r14*1]
000074ad747d09f3  mov [r15+0x40], r12
000074ad747d09f7  lea r14, [rax+0x148]
000074ad747d09fe  xor eax, eax
000074ad747d0a00  mov [r13+r14*1], al
000074ad747d0a05  xor eax, eax
000074ad747d0a07  mov r14d, 0x38
000074ad747d0a0d  cmp r12, r14
000074ad747d0a10  cmc
000074ad747d0a11  lahf
000074ad747d0a12  seto al
000074ad747d0a15  mov [r15+0x108], eax
000074ad747d0a1c  mov eax, [r15+0x108]
000074ad747d0a23  sahf
000074ad747d0a24  jz 0x000074AD747D0A56
000074ad747d0a26  cmp dword ptr [r15+0x318], 0x00
000074ad747d0a2e  jz 0x000074AD747D0AA0
000074ad747d0a34  nop [rax+rax*1], ax
000074ad747d0a3d  nop [rax+rax*1], eax
000074ad747d0a45  mov eax, 0x4102B8
000074ad747d0a4a  mov [r15+0x100], rax
000074ad747d0a51  jmp 0x000074AD745FE110
000074ad747d0a56  cmp dword ptr [r15+0x318], 0x00
000074ad747d0a5e  jz 0x000074AD747D0BF0
000074ad747d0a64  nop [rax+rax*1], ax
000074ad747d0a6d  nop [rax+rax*1], eax
000074ad747d0a75  mov eax, 0x4102D4
000074ad747d0a7a  mov [r15+0x100], rax
000074ad747d0a81  jmp 0x000074AD745FE110
000074ad747d0a86  int3
000074ad747d0a87  call 0x000074AD746E27E0
000074ad747d0a8c  jmp 0x000074AD747D09F3
000074ad747d0a91  call 0x000074AD746D5AF0
000074ad747d0a96  jmp 0x000074AD747D0A05
000074ad747d0a9b  int3
000074ad747d0a9c  nop [rax], eax
000074ad747d0aa0  mov rax, [r15+0xF8]
000074ad747d0aa7  lea r14, [rax+0xD0]
000074ad747d0aae  mov [r15], r14
000074ad747d0ab1  lea r14, [rax+0x148]
000074ad747d0ab8  mov [r15+0x08], r14
000074ad747d0abc  mov qword ptr [r15+0x10], 0x01
000074ad747d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000074ad747d0acf  mov r14d, [r15+0x320]
000074ad747d0ad6  mov eax, 0x4102C8
000074ad747d0adb  mov rcx, 0x74AD747D0B40
000074ad747d0ae5  mov [r15+r14*8+0x328], rax
000074ad747d0aed  mov [r15+r14*8+0x368], rcx
000074ad747d0af5  add r14d, 0x01
000074ad747d0af9  and r14d, 0x07
000074ad747d0afd  mov [r15+0x320], r14d
000074ad747d0b04  cmp dword ptr [r15+0x318], 0x00
000074ad747d0b0c  jz 0x000074AD747CED70
000074ad747d0b12  nop [rax+rax*1], ax
000074ad747d0b1b  nop [rax+rax*1], eax
000074ad747d0b23  mov eax, 0x4106BC
000074ad747d0b28  mov [r15+0x100], rax
000074ad747d0b2f  jmp 0x000074AD745FE110
000074ad747d0b34  int3
000074ad747d0b35  int3
000074ad747d0b36  nop [rax+rax*1], ax
000074ad747d0b3f  nop
000074ad747d0b40  mov rax, [r15+0xF8]
000074ad747d0b47  lea r14, [rax+0x138]
000074ad747d0b4e  mov rax, [r13+r14*1]
000074ad747d0b53  mov [r15+0x40], rax
000074ad747d0b57  mov [rsp+0x10], rax
000074ad747d0b5c  xor eax, eax
000074ad747d0b5e  mov r14, [rsp+0x10]
000074ad747d0b63  mov r12d, 0x38
000074ad747d0b69  cmp r14, r12
000074ad747d0b6c  cmc
000074ad747d0b6d  lahf
000074ad747d0b6e  seto al
000074ad747d0b71  mov [r15+0x108], eax
000074ad747d0b78  mov eax, [r15+0x108]
000074ad747d0b7f  sahf
000074ad747d0b80  jnz 0x000074AD747D0BB2
000074ad747d0b82  cmp dword ptr [r15+0x318], 0x00
000074ad747d0b8a  jz 0x000074AD747D0BF0
000074ad747d0b90  nop [rax+rax*1], ax
000074ad747d0b99  nop [rax+rax*1], eax
000074ad747d0ba1  mov eax, 0x4102D4
000074ad747d0ba6  mov [r15+0x100], rax
000074ad747d0bad  jmp 0x000074AD745FE110
000074ad747d0bb2  cmp dword ptr [r15+0x318], 0x00
000074ad747d0bba  jz 0x000074AD747D0AA0
000074ad747d0bc0  nop [rax+rax*1], ax
000074ad747d0bc9  nop [rax+rax*1], eax
000074ad747d0bd1  mov eax, 0x4102B8
000074ad747d0bd6  mov [r15+0x100], rax
000074ad747d0bdd  jmp 0x000074AD745FE110
000074ad747d0be2  int3
000074ad747d0be3  call 0x000074AD746D59C0
000074ad747d0be8  jmp 0x000074AD747D0B53
000074ad747d0bed  int3
000074ad747d0bee  nop
000074ad747d0bf0  mov rax, [r15+0x98]
000074ad747d0bf7  rorx r14, rax, 0x3D
000074ad747d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000074ad747d0c01  mov rax, [r15+0xF8]
000074ad747d0c08  lea r12, [rax+0xD0]
000074ad747d0c0f  mov [r15], r12
000074ad747d0c12  lea r12, [rax+0x140]
000074ad747d0c19  mov [r15+0x08], r12
000074ad747d0c1d  mov qword ptr [r15+0x10], 0x08
000074ad747d0c25  bswap r14
000074ad747d0c28  mov [r15+0x40], r14
000074ad747d0c2c  lea r12, [rax+0x140]
000074ad747d0c33  mov [r13+r12*1], r14
000074ad747d0c38  mov qword ptr [r15+0xF0], 0x4102F0
000074ad747d0c43  mov r14d, [r15+0x320]
000074ad747d0c4a  mov eax, 0x4102F0
000074ad747d0c4f  mov rcx, 0x74AD747D0CC0
000074ad747d0c59  mov [r15+r14*8+0x328], rax
000074ad747d0c61  mov [r15+r14*8+0x368], rcx
000074ad747d0c69  add r14d, 0x01
000074ad747d0c6d  and r14d, 0x07
000074ad747d0c71  mov [r15+0x320], r14d
000074ad747d0c78  cmp dword ptr [r15+0x318], 0x00
000074ad747d0c80  jz 0x000074AD747CED70
000074ad747d0c86  nop [rax+rax*1], ax
000074ad747d0c8f  nop [rax+rax*1], eax
000074ad747d0c97  mov eax, 0x4106BC
000074ad747d0c9c  mov [r15+0x100], rax
000074ad747d0ca3  jmp 0x000074AD745FE110
000074ad747d0ca8  int3
000074ad747d0ca9  call 0x000074AD746C3FE0
000074ad747d0cae  jmp 0x000074AD747D0C38
000074ad747d0cb3  int3
000074ad747d0cb4  nop [rax+rax*1], ax
000074ad747d0cbd  nop [rax], eax
000074ad747d0cc0  mov rax, [r15+0xF8]
000074ad747d0cc7  lea r14, [rax+0xD0]
000074ad747d0cce  mov r12d, [r13+r14*1]
000074ad747d0cd3  lea r14, [rax+0xD4]
000074ad747d0cda  mov r11d, [r13+r14*1]
000074ad747d0cdf  lea r14, [rax+0xD8]
000074ad747d0ce6  mov r10d, [r13+r14*1]
000074ad747d0ceb  lea r14, [rax+0xDC]
000074ad747d0cf2  mov r9d, [r13+r14*1]
000074ad747d0cf7  mov qword ptr [r15+0x48], 0x430C20
000074ad747d0cff  mov qword ptr [r15+0xA0], 0x00
000074ad747d0d0a  bswap r12d
000074ad747d0d0d  bswap r11d
000074ad747d0d10  mov qword ptr [r15+0x98], 0x430D8C
000074ad747d0d1b  mov r14d, 0x430C20
000074ad747d0d21  mov [r13+r14*1], r12d
000074ad747d0d26  mov r14d, 0x430C24
000074ad747d0d2c  mov [r13+r14*1], r11d
000074ad747d0d31  bswap r10d
000074ad747d0d34  bswap r9d
000074ad747d0d37  lea r14, [rax+0xE0]
000074ad747d0d3e  mov r12d, [r13+r14*1]
000074ad747d0d43  lea r14, [rax+0xE4]
000074ad747d0d4a  mov r11d, [r13+r14*1]
000074ad747d0d4f  mov r14d, 0x430C28
000074ad747d0d55  mov [r13+r14*1], r10d
000074ad747d0d5a  mov r14d, 0x430C2C
000074ad747d0d60  mov [r13+r14*1], r9d
000074ad747d0d65  bswap r12d
000074ad747d0d68  bswap r11d
000074ad747d0d6b  mov [rsp+0x10], r11d
000074ad747d0d70  mov r11d, r11d
000074ad747d0d73  mov [r15+0x58], r11
000074ad747d0d77  lea r14, [rax+0xE8]
000074ad747d0d7e  mov r11d, [r13+r14*1]
000074ad747d0d83  lea r14, [rax+0xEC]
000074ad747d0d8a  mov eax, [r13+r14*1]
000074ad747d0d8f  mov [rsp+0x20], eax
000074ad747d0d93  mov eax, eax
000074ad747d0d95  mov [r15+0x60], rax
000074ad747d0d99  mov eax, 0x430C30
000074ad747d0d9e  mov [r13+rax*1], r12d
000074ad747d0da3  mov eax, 0x430C34
000074ad747d0da8  mov r14d, [rsp+0x10]
000074ad747d0dad  mov [r13+rax*1], r14d
000074ad747d0db2  bswap r11d
000074ad747d0db5  mov [rsp+0x10], r11d
000074ad747d0dba  mov r11d, r11d
000074ad747d0dbd  mov [r15+0x40], r11
000074ad747d0dc1  mov eax, [rsp+0x20]
000074ad747d0dc5  bswap eax
000074ad747d0dc7  mov [rsp+0x20], eax
000074ad747d0dcb  mov eax, eax
000074ad747d0dcd  mov [r15+0x50], rax
000074ad747d0dd1  mov eax, 0x430C38
000074ad747d0dd6  mov r14d, [rsp+0x10]
000074ad747d0ddb  mov [r13+rax*1], r14d
000074ad747d0de0  mov eax, 0x430C3C
000074ad747d0de5  mov r14d, [rsp+0x20]
000074ad747d0dea  mov [r13+rax*1], r14d
000074ad747d0def  mov eax, [r15+0xA0]
000074ad747d0df6  lea r14d, [eax+0x11]
000074ad747d0dfb  mov r14d, r14d
000074ad747d0dfe  mov [r15], r14
000074ad747d0e01  mov qword ptr [r15+0xF0], 0x41034C
000074ad747d0e0c  mov r14d, [r15+0x320]
000074ad747d0e13  mov eax, 0x41034C
000074ad747d0e18  mov rcx, 0x74AD747D0F90
000074ad747d0e22  mov [r15+r14*8+0x328], rax
000074ad747d0e2a  mov [r15+r14*8+0x368], rcx
000074ad747d0e32  add r14d, 0x01
000074ad747d0e36  and r14d, 0x07
000074ad747d0e3a  mov [r15+0x320], r14d
000074ad747d0e41  cmp dword ptr [r15+0x318], 0x00
000074ad747d0e49  jz 0x000074AD747D0F20
000074ad747d0e4f  nop [rax+rax*1], ax
000074ad747d0e58  nop [rax+rax*1], eax
000074ad747d0e60  mov eax, 0x410938
000074ad747d0e65  mov [r15+0x100], rax
000074ad747d0e6c  jmp 0x000074AD745FE110
000074ad747d0e71  int3
000074ad747d0e72  call 0x000074AD746E26A0
000074ad747d0e77  jmp 0x000074AD747D0CD3
000074ad747d0e7c  call 0x000074AD746E1430
000074ad747d0e81  jmp 0x000074AD747D0CDF
000074ad747d0e86  call 0x000074AD746E01C0
000074ad747d0e8b  jmp 0x000074AD747D0CEB
000074ad747d0e90  call 0x000074AD746DEF50
000074ad747d0e95  jmp 0x000074AD747D0CF7
000074ad747d0e9a  call 0x000074AD746E2BA0
000074ad747d0e9f  jmp 0x000074AD747D0D26
000074ad747d0ea4  call 0x000074AD746E1920
000074ad747d0ea9  jmp 0x000074AD747D0D31
000074ad747d0eae  call 0x000074AD746E26A0
000074ad747d0eb3  jmp 0x000074AD747D0D43
000074ad747d0eb8  call 0x000074AD746E1430
000074ad747d0ebd  jmp 0x000074AD747D0D4F
000074ad747d0ec2  call 0x000074AD746E06B0
000074ad747d0ec7  jmp 0x000074AD747D0D5A
000074ad747d0ecc  call 0x000074AD746DF440
000074ad747d0ed1  jmp 0x000074AD747D0D65
000074ad747d0ed6  call 0x000074AD746E1430
000074ad747d0edb  jmp 0x000074AD747D0D83
000074ad747d0ee0  call 0x000074AD746D5890
000074ad747d0ee5  jmp 0x000074AD747D0D8F
000074ad747d0eea  call 0x000074AD7460BAE0
000074ad747d0eef  jmp 0x000074AD747D0DA3
000074ad747d0ef4  call 0x000074AD7460DFE0
000074ad747d0ef9  jmp 0x000074AD747D0DB2
000074ad747d0efe  call 0x000074AD7460DFE0
000074ad747d0f03  jmp 0x000074AD747D0DE0
000074ad747d0f08  call 0x000074AD7460DFE0
000074ad747d0f0d  jmp 0x000074AD747D0DEF
000074ad747d0f12  int3
000074ad747d0f13  nop [rax+rax*1], ax
000074ad747d0f1c  nop [rax], eax
000074ad747d0f20  mov eax, [r15]
000074ad747d0f23  mov [rsp+0x10], eax
000074ad747d0f27  shr eax, 0x10
000074ad747d0f2a  mov r14d, [rsp+0x10]
000074ad747d0f2f  xor r14d, eax
000074ad747d0f32  imul r14d, r14d, 0x7FEB352D
000074ad747d0f39  mov eax, 0x846CA68B
000074ad747d0f3e  mov eax, eax
000074ad747d0f40  mov [r15+0x48], rax
000074ad747d0f44  mov [rsp+0x10], r14d
000074ad747d0f49  shr r14d, 0x0F
000074ad747d0f4d  mov eax, [rsp+0x10]
000074ad747d0f51  xor eax, r14d
000074ad747d0f54  imul eax, eax, 0x846CA68B
000074ad747d0f5a  mov [rsp+0x10], eax
000074ad747d0f5e  mov eax, eax
000074ad747d0f60  mov [r15+0x40], rax
000074ad747d0f64  mov eax, [rsp+0x10]
000074ad747d0f68  shr eax, 0x10
000074ad747d0f6b  mov r14d, [rsp+0x10]
000074ad747d0f70  xor r14d, eax
000074ad747d0f73  mov r14d, r14d
000074ad747d0f76  mov [r15], r14
000074ad747d0f79  mov rax, [r15+0xF0]
000074ad747d0f80  mov [r15+0x100], rax
000074ad747d0f87  jmp 0x000074AD747CE5C0
000074ad747d0f8c  int3
000074ad747d0f8d  int3
000074ad747d0f8e  nop
000074ad747d0f90  mov rax, [r15+0xA0]
000074ad747d0f97  mov [rsp+0x10], rax
000074ad747d0f9c  shl rax, 0x02
000074ad747d0fa0  mov r14, [r15+0x98]
000074ad747d0fa7  lea r12, [r14+rax*1]
000074ad747d0fab  mov eax, [r15]
000074ad747d0fae  mov [r13+r12*1], eax
000074ad747d0fb3  mov rax, [rsp+0x10]
000074ad747d0fb8  lea r14, [rax+0x01]
000074ad747d0fbc  mov [r15+0xA0], r14
000074ad747d0fc3  xor eax, eax
000074ad747d0fc5  mov r12d, 0x400
000074ad747d0fcb  cmp r14, r12
000074ad747d0fce  cmc
000074ad747d0fcf  lahf
000074ad747d0fd0  seto al
000074ad747d0fd3  mov [r15+0x108], eax
000074ad747d0fda  mov eax, [r15+0x108]
000074ad747d0fe1  sahf
000074ad747d0fe2  jnz 0x000074AD747D1014
000074ad747d0fe4  cmp dword ptr [r15+0x318], 0x00
000074ad747d0fec  jz 0x000074AD747D10E0
000074ad747d0ff2  nop [rax+rax*1], ax
000074ad747d0ffb  nop [rax+rax*1], eax
000074ad747d1003  mov eax, 0x41035C
000074ad747d1008  mov [r15+0x100], rax
000074ad747d100f  jmp 0x000074AD745FE110
000074ad747d1014  cmp dword ptr [r15+0x318], 0x00
000074ad747d101c  jz 0x000074AD747D1050
000074ad747d1022  nop [rax+rax*1], ax
000074ad747d102b  nop [rax+rax*1], eax
000074ad747d1033  mov eax, 0x410344
000074ad747d1038  mov [r15+0x100], rax
000074ad747d103f  jmp 0x000074AD745FE110
000074ad747d1044  int3
000074ad747d1045  call 0x000074AD746B4B70
000074ad747d104a  jmp 0x000074AD747D0FB3
000074ad747d104f  int3
000074ad747d1050  mov eax, [r15+0xA0]
000074ad747d1057  lea r14d, [eax+0x11]
000074ad747d105c  mov r14d, r14d
000074ad747d105f  mov [r15], r14
000074ad747d1062  mov qword ptr [r15+0xF0], 0x41034C
000074ad747d106d  mov r14d, [r15+0x320]
000074ad747d1074  mov eax, 0x41034C
000074ad747d1079  mov rcx, 0x74AD747D0F90
000074ad747d1083  mov [r15+r14*8+0x328], rax
000074ad747d108b  mov [r15+r14*8+0x368], rcx
000074ad747d1093  add r14d, 0x01
000074ad747d1097  and r14d, 0x07
000074ad747d109b  mov [r15+0x320], r14d
000074ad747d10a2  cmp dword ptr [r15+0x318], 0x00
000074ad747d10aa  jz 0x000074AD747D0F20
000074ad747d10b0  nop [rax+rax*1], ax
000074ad747d10b9  nop [rax+rax*1], eax
000074ad747d10c1  mov eax, 0x410938
000074ad747d10c6  mov [r15+0x100], rax
000074ad747d10cd  jmp 0x000074AD745FE110
000074ad747d10d2  int3
000074ad747d10d3  int3
000074ad747d10d4  nop [rax+rax*1], ax
000074ad747d10dd  nop [rax], eax
000074ad747d10e0  mov qword ptr [r15+0x40], 0x01
000074ad747d10e8  cmp dword ptr [r15+0x318], 0x00
000074ad747d10f0  jz 0x000074AD747D1120
000074ad747d10f6  nop [rax+rax*1], ax
000074ad747d10ff  nop [rax+rax*1], eax
000074ad747d1107  mov eax, 0x410378
000074ad747d110c  mov [r15+0x100], rax
000074ad747d1113  jmp 0x000074AD745FE110
000074ad747d1118  int3
000074ad747d1119  int3
000074ad747d111a  nop [rax+rax*1], ax
000074ad747d1120  mov rax, [r15+0x40]
000074ad747d1124  mov [rsp+0x10], rax
000074ad747d1129  shl rax, 0x02
000074ad747d112d  mov r14, [r15+0x98]
000074ad747d1134  lea r12, [r14+rax*1]
000074ad747d1138  mov eax, [r13+r12*1]
000074ad747d113d  mov [rsp+0x20], eax
000074ad747d1141  mov eax, eax
000074ad747d1143  mov [r15+0x48], rax
000074ad747d1147  mov rax, [rsp+0x10]
000074ad747d114c  mov [r15+0x50], rax
000074ad747d1150  mov eax, [r15+0x50]
000074ad747d1154  lea r12d, [eax-0x01]
000074ad747d1159  mov r12d, r12d
000074ad747d115c  mov [r15+0x58], r12
000074ad747d1160  mov rax, [r15+0x58]
000074ad747d1164  mov r12d, eax
000074ad747d1167  mov r12d, r12d
000074ad747d116a  shl r12, 0x02
000074ad747d116e  lea rax, [r14+r12*1]
000074ad747d1172  mov r14d, [r13+rax*1]
000074ad747d1177  mov [rsp+0x10], r14d
000074ad747d117c  mov r14d, r14d
000074ad747d117f  mov [r15+0x60], r14
000074ad747d1183  xor eax, eax
000074ad747d1185  mov r14d, [rsp+0x10]
000074ad747d118a  mov r12d, [rsp+0x20]
000074ad747d118f  cmp r14d, r12d
000074ad747d1192  cmc
000074ad747d1193  lahf
000074ad747d1194  seto al
000074ad747d1197  mov [r15+0x108], eax
000074ad747d119e  mov eax, [r15+0x108]
000074ad747d11a5  sahf
000074ad747d11a6  cmc
000074ad747d11a7  jbe 0x000074AD747D11D9
000074ad747d11a9  cmp dword ptr [r15+0x318], 0x00
000074ad747d11b1  jz 0x000074AD747D1220
000074ad747d11b7  nop [rax+rax*1], ax
000074ad747d11c0  nop [rax+rax*1], eax
000074ad747d11c8  mov eax, 0x410390
000074ad747d11cd  mov [r15+0x100], rax
000074ad747d11d4  jmp 0x000074AD745FE110
000074ad747d11d9  cmp dword ptr [r15+0x318], 0x00
000074ad747d11e1  jz 0x000074AD747D14C0
000074ad747d11e7  nop [rax+rax*1], ax
000074ad747d11f0  nop [rax+rax*1], eax
000074ad747d11f8  mov eax, 0x410368
000074ad747d11fd  mov [r15+0x100], rax
000074ad747d1204  jmp 0x000074AD745FE110
000074ad747d1209  int3
000074ad747d120a  call 0x000074AD746B4690
000074ad747d120f  jmp 0x000074AD747D113D
000074ad747d1214  call 0x000074AD7460DAE0
000074ad747d1219  jmp 0x000074AD747D1177
000074ad747d121e  int3
000074ad747d121f  nop
000074ad747d1220  mov rax, [r15+0x50]
000074ad747d1224  mov [rsp+0x10], rax
000074ad747d1229  shl rax, 0x02
000074ad747d122d  mov r14, [r15+0x98]
000074ad747d1234  lea r12, [r14+rax*1]
000074ad747d1238  mov eax, [r15+0x60]
000074ad747d123c  mov [r13+r12*1], eax
000074ad747d1241  mov rax, [rsp+0x10]
000074ad747d1246  lea r14, [rax-0x01]
000074ad747d124a  mov [r15+0x50], r14
000074ad747d124e  mov rax, [r15+0x58]
000074ad747d1252  test rax, rax
000074ad747d1255  setz al
000074ad747d1258  movzx rax, al
000074ad747d125c  mov [rsp+0x414], al
000074ad747d1263  cmp byte ptr [rsp+0x414], 0x00
000074ad747d126b  jz 0x000074AD747D129D
000074ad747d126d  cmp dword ptr [r15+0x318], 0x00
000074ad747d1275  jz 0x000074AD747D12E0
000074ad747d127b  nop [rax+rax*1], ax
000074ad747d1284  nop [rax+rax*1], eax
000074ad747d128c  mov eax, 0x41039C
000074ad747d1291  mov [r15+0x100], rax
000074ad747d1298  jmp 0x000074AD745FE110
000074ad747d129d  cmp dword ptr [r15+0x318], 0x00
000074ad747d12a5  jz 0x000074AD747D13E0
000074ad747d12ab  nop [rax+rax*1], ax
000074ad747d12b4  nop [rax+rax*1], eax
000074ad747d12bc  mov eax, 0x410380
000074ad747d12c1  mov [r15+0x100], rax
000074ad747d12c8  jmp 0x000074AD745FE110
000074ad747d12cd  int3
000074ad747d12ce  call 0x000074AD746B4B70
000074ad747d12d3  jmp 0x000074AD747D1241
000074ad747d12d8  int3
000074ad747d12d9  nop [rax], eax
000074ad747d12e0  cmp dword ptr [r15+0x318], 0x00
000074ad747d12e8  jz 0x000074AD747D1320
000074ad747d12ee  nop [rax+rax*1], ax
000074ad747d12f7  nop [rax+rax*1], eax
000074ad747d12ff  mov eax, 0x410364
000074ad747d1304  mov [r15+0x100], rax
000074ad747d130b  jmp 0x000074AD745FE110
000074ad747d1310  int3
000074ad747d1311  int3
000074ad747d1312  nop [rax+rax*1], ax
000074ad747d131b  nop [rax+rax*1], eax
000074ad747d1320  mov qword ptr [r15+0x50], 0x00
000074ad747d1328  mov rax, [r15+0x40]
000074ad747d132c  lea r14, [rax+0x01]
000074ad747d1330  mov [r15+0x40], r14
000074ad747d1334  mov rax, [r15+0x98]
000074ad747d133b  mov r12d, [r15+0x48]
000074ad747d133f  mov [r13+rax*1], r12d
000074ad747d1344  xor eax, eax
000074ad747d1346  mov r12d, 0x400
000074ad747d134c  cmp r14, r12
000074ad747d134f  cmc
000074ad747d1350  lahf
000074ad747d1351  seto al
000074ad747d1354  mov [r15+0x108], eax
000074ad747d135b  mov eax, [r15+0x108]
000074ad747d1362  sahf
000074ad747d1363  jz 0x000074AD747D1395
000074ad747d1365  cmp dword ptr [r15+0x318], 0x00
000074ad747d136d  jz 0x000074AD747D1120
000074ad747d1373  nop [rax+rax*1], ax
000074ad747d137c  nop [rax+rax*1], eax
000074ad747d1384  mov eax, 0x410378
000074ad747d1389  mov [r15+0x100], rax
000074ad747d1390  jmp 0x000074AD745FE110
000074ad747d1395  cmp dword ptr [r15+0x318], 0x00
000074ad747d139d  jz 0x000074AD747D1580
000074ad747d13a3  nop [rax+rax*1], ax
000074ad747d13ac  nop [rax+rax*1], eax
000074ad747d13b4  mov eax, 0x4103A0
000074ad747d13b9  mov [r15+0x100], rax
000074ad747d13c0  jmp 0x000074AD745FE110
000074ad747d13c5  int3
000074ad747d13c6  call 0x000074AD7460BAE0
000074ad747d13cb  jmp 0x000074AD747D1344
000074ad747d13d0  int3
000074ad747d13d1  nop [rax+rax*1], ax
000074ad747d13da  nop [rax+rax*1], ax
000074ad747d13e0  mov eax, [r15+0x50]
000074ad747d13e4  lea r14d, [eax-0x01]
000074ad747d13e9  mov r14d, r14d
000074ad747d13ec  mov [r15+0x58], r14
000074ad747d13f0  mov rax, [r15+0x58]
000074ad747d13f4  mov r14d, eax
000074ad747d13f7  mov r14d, r14d
000074ad747d13fa  shl r14, 0x02
000074ad747d13fe  mov rax, [r15+0x98]
000074ad747d1405  lea r12, [rax+r14*1]
000074ad747d1409  mov eax, [r13+r12*1]
000074ad747d140e  mov [rsp+0x10], eax
000074ad747d1412  mov eax, eax
000074ad747d1414  mov [r15+0x60], rax
000074ad747d1418  mov eax, [r15+0x48]
000074ad747d141c  mov [rsp+0x20], eax
000074ad747d1420  xor eax, eax
000074ad747d1422  mov r14d, [rsp+0x10]
000074ad747d1427  mov r12d, [rsp+0x20]
000074ad747d142c  cmp r14d, r12d
000074ad747d142f  cmc
000074ad747d1430  lahf
000074ad747d1431  seto al
000074ad747d1434  mov [r15+0x108], eax
000074ad747d143b  mov eax, [r15+0x108]
000074ad747d1442  sahf
000074ad747d1443  cmc
000074ad747d1444  jbe 0x000074AD747D1476
000074ad747d1446  cmp dword ptr [r15+0x318], 0x00
000074ad747d144e  jz 0x000074AD747D1220
000074ad747d1454  nop [rax+rax*1], ax
000074ad747d145d  nop [rax+rax*1], eax
000074ad747d1465  mov eax, 0x410390
000074ad747d146a  mov [r15+0x100], rax
000074ad747d1471  jmp 0x000074AD745FE110
000074ad747d1476  cmp dword ptr [r15+0x318], 0x00
000074ad747d147e  jz 0x000074AD747D14C0
000074ad747d1484  nop [rax+rax*1], ax
000074ad747d148d  nop [rax+rax*1], eax
000074ad747d1495  mov eax, 0x410368
000074ad747d149a  mov [r15+0x100], rax
000074ad747d14a1  jmp 0x000074AD745FE110
000074ad747d14a6  int3
000074ad747d14a7  call 0x000074AD746B4690
000074ad747d14ac  jmp 0x000074AD747D140E
000074ad747d14b1  int3
000074ad747d14b2  nop [rax+rax*1], ax
000074ad747d14bb  nop [rax+rax*1], eax
000074ad747d14c0  mov rax, [r15+0x40]
000074ad747d14c4  lea r14, [rax+0x01]
000074ad747d14c8  mov [r15+0x40], r14
000074ad747d14cc  mov rax, [r15+0x50]
000074ad747d14d0  mov r12d, eax
000074ad747d14d3  mov r12d, r12d
000074ad747d14d6  shl r12, 0x02
000074ad747d14da  mov rax, [r15+0x98]
000074ad747d14e1  lea r11, [rax+r12*1]
000074ad747d14e5  mov eax, [r15+0x48]
000074ad747d14e9  mov [r13+r11*1], eax
000074ad747d14ee  xor eax, eax
000074ad747d14f0  mov r12d, 0x400
000074ad747d14f6  cmp r14, r12
000074ad747d14f9  cmc
000074ad747d14fa  lahf
000074ad747d14fb  seto al
000074ad747d14fe  mov [r15+0x108], eax
000074ad747d1505  mov eax, [r15+0x108]
000074ad747d150c  sahf
000074ad747d150d  jz 0x000074AD747D153F
000074ad747d150f  cmp dword ptr [r15+0x318], 0x00
000074ad747d1517  jz 0x000074AD747D1120
000074ad747d151d  nop [rax+rax*1], ax
000074ad747d1526  nop [rax+rax*1], eax
000074ad747d152e  mov eax, 0x410378
000074ad747d1533  mov [r15+0x100], rax
000074ad747d153a  jmp 0x000074AD745FE110
000074ad747d153f  cmp dword ptr [r15+0x318], 0x00
000074ad747d1547  jz 0x000074AD747D1580
000074ad747d154d  nop [rax+rax*1], ax
000074ad747d1556  nop [rax+rax*1], eax
000074ad747d155e  mov eax, 0x4103A0
000074ad747d1563  mov [r15+0x100], rax
000074ad747d156a  jmp 0x000074AD745FE110
000074ad747d156f  int3
000074ad747d1570  call 0x000074AD746A4270
000074ad747d1575  jmp 0x000074AD747D14EE
000074ad747d157a  int3
000074ad747d157b  nop [rax+rax*1], eax
000074ad747d1580  mov qword ptr [r15+0x40], 0x430000
000074ad747d1588  mov eax, 0x430C40
000074ad747d158d  mov r14, [r13+rax*1]
000074ad747d1592  mov rax, [r15+0x98]
000074ad747d1599  mov r12d, [r13+rax*1]
000074ad747d159e  lea r11, [rax+0x04]
000074ad747d15a2  mov eax, [r13+r11*1]
000074ad747d15a7  mov r12d, r12d
000074ad747d15aa  mov [r15+0x68], r12
000074ad747d15ae  mov eax, eax
000074ad747d15b0  mov [r15+0x60], rax
000074ad747d15b4  mov rax, [r15+0x68]
000074ad747d15b8  mov [r15+0x68], rax
000074ad747d15bc  mov qword ptr [r15+0x58], 0x02
000074ad747d15c4  mov [rsp+0x10], rax
000074ad747d15c9  xor eax, eax
000074ad747d15cb  mov r12d, 0x02
000074ad747d15d1  mov r11d, 0x400
000074ad747d15d7  cmp r12, r11
000074ad747d15da  cmc
000074ad747d15db  lahf
000074ad747d15dc  seto al
000074ad747d15df  mov [r15+0x108], eax
000074ad747d15e6  mov rax, [r15+0x60]
000074ad747d15ea  mov r12d, 0x02
000074ad747d15f0  imul rax, r12
000074ad747d15f4  mov [r15+0x50], rax
000074ad747d15f8  mov rax, [rsp+0x10]
000074ad747d15fd  lea r12, [rax+r14*1]
000074ad747d1601  mov [r15+0x48], r12
000074ad747d1605  mov eax, [r15+0x108]
000074ad747d160c  sahf
000074ad747d160d  jnz 0x000074AD747D163F
000074ad747d160f  cmp dword ptr [r15+0x318], 0x00
000074ad747d1617  jz 0x000074AD747D17B0
000074ad747d161d  nop [rax+rax*1], ax
000074ad747d1626  nop [rax+rax*1], eax
000074ad747d162e  mov eax, 0x4103D0
000074ad747d1633  mov [r15+0x100], rax
000074ad747d163a  jmp 0x000074AD745FE110
000074ad747d163f  cmp dword ptr [r15+0x318], 0x00
000074ad747d1647  jz 0x000074AD747D1690
000074ad747d164d  nop [rax+rax*1], ax
000074ad747d1656  nop [rax+rax*1], eax
000074ad747d165e  mov eax, 0x4103B0
000074ad747d1663  mov [r15+0x100], rax
000074ad747d166a  jmp 0x000074AD745FE110
000074ad747d166f  int3
000074ad747d1670  call 0x000074AD7460DC20
000074ad747d1675  jmp 0x000074AD747D1592
000074ad747d167a  call 0x000074AD7460B5E0
000074ad747d167f  jmp 0x000074AD747D159E
000074ad747d1684  call 0x000074AD746A3D90
000074ad747d1689  jmp 0x000074AD747D15A7
000074ad747d168e  int3
000074ad747d168f  nop
000074ad747d1690  mov rax, [r15+0x98]
000074ad747d1697  mov r14, [r15+0x58]
000074ad747d169b  mov [rsp+0x10], r14
000074ad747d16a0  shl r14, 0x02
000074ad747d16a4  lea r12, [rax+r14*1]
000074ad747d16a8  mov eax, [r13+r12*1]
000074ad747d16ad  lea r14, [r12+0x04]
000074ad747d16b2  mov r12d, [r13+r14*1]
000074ad747d16b7  mov eax, eax
000074ad747d16b9  mov [r15+0x68], rax
000074ad747d16bd  mov r12d, r12d
000074ad747d16c0  mov [r15+0x60], r12
000074ad747d16c4  mov rax, [r15+0x68]
000074ad747d16c8  mov [rsp+0x20], rax
000074ad747d16cd  mov r14, [rsp+0x10]
000074ad747d16d2  imul rax, r14
000074ad747d16d6  mov r12, [rsp+0x20]
000074ad747d16db  lea r11, [r12+rax*1]
000074ad747d16df  mov [r15+0x68], r11
000074ad747d16e3  lea rax, [r14+0x02]
000074ad747d16e7  mov [r15+0x58], rax
000074ad747d16eb  mov [rsp+0x10], rax
000074ad747d16f0  xor eax, eax
000074ad747d16f2  mov r14, [rsp+0x10]
000074ad747d16f7  mov r12d, 0x400
000074ad747d16fd  cmp r14, r12
000074ad747d1700  cmc
000074ad747d1701  lahf
000074ad747d1702  seto al
000074ad747d1705  mov [r15+0x108], eax
000074ad747d170c  mov rax, [r15+0x50]
000074ad747d1710  mov r12, [r15+0x60]
000074ad747d1714  imul r14, r12
000074ad747d1718  lea r12, [rax+r14*1]
000074ad747d171c  mov [r15+0x50], r12
000074ad747d1720  mov rax, [r15+0x48]
000074ad747d1724  lea r14, [r11+rax*1]
000074ad747d1728  mov [r15+0x48], r14
000074ad747d172c  mov eax, [r15+0x108]
000074ad747d1733  sahf
000074ad747d1734  jnz 0x000074AD747D1766
000074ad747d1736  cmp dword ptr [r15+0x318], 0x00
000074ad747d173e  jz 0x000074AD747D17B0
000074ad747d1744  nop [rax+rax*1], ax
000074ad747d174d  nop [rax+rax*1], eax
000074ad747d1755  mov eax, 0x4103D0
000074ad747d175a  mov [r15+0x100], rax
000074ad747d1761  jmp 0x000074AD745FE110
000074ad747d1766  cmp dword ptr [r15+0x318], 0x00
000074ad747d176e  jz 0x000074AD747D1690
000074ad747d1774  nop [rax+rax*1], ax
000074ad747d177d  nop [rax+rax*1], eax
000074ad747d1785  mov eax, 0x4103B0
000074ad747d178a  mov [r15+0x100], rax
000074ad747d1791  jmp 0x000074AD745FE110
000074ad747d1796  int3
000074ad747d1797  call 0x000074AD746B4690
000074ad747d179c  jmp 0x000074AD747D16AD
000074ad747d17a1  call 0x000074AD746E26A0
000074ad747d17a6  jmp 0x000074AD747D16B7
000074ad747d17ab  int3
000074ad747d17ac  nop [rax], eax
000074ad747d17b0  mov qword ptr [r15+0x98], 0x00
000074ad747d17bb  mov rax, [r15+0x50]
000074ad747d17bf  mov r14, [r15+0x48]
000074ad747d17c3  lea r12, [rax+r14*1]
000074ad747d17c7  mov [r15+0x48], r12
000074ad747d17cb  mov rax, [r15+0x40]
000074ad747d17cf  lea r14, [rax+0xC40]
000074ad747d17d6  mov [r13+r14*1], r12
000074ad747d17db  mov qword ptr [r15], 0x01
000074ad747d17e2  mov qword ptr [r15+0xF0], 0x4103E8
000074ad747d17ed  mov r14d, [r15+0x320]
000074ad747d17f4  mov eax, 0x4103E8
000074ad747d17f9  mov rcx, 0x74AD747D1860
000074ad747d1803  mov [r15+r14*8+0x328], rax
000074ad747d180b  mov [r15+r14*8+0x368], rcx
000074ad747d1813  add r14d, 0x01
000074ad747d1817  and r14d, 0x07
000074ad747d181b  mov [r15+0x320], r14d
000074ad747d1822  cmp dword ptr [r15+0x318], 0x00
000074ad747d182a  jz 0x000074AD747D0F20
000074ad747d1830  nop [rax+rax*1], ax
000074ad747d1839  nop [rax+rax*1], eax
000074ad747d1841  mov eax, 0x410938
000074ad747d1846  mov [r15+0x100], rax
000074ad747d184d  jmp 0x000074AD745FE110
000074ad747d1852  int3
000074ad747d1853  call 0x000074AD746E2CE0
000074ad747d1858  jmp 0x000074AD747D17DB
000074ad747d185d  int3
000074ad747d185e  nop
000074ad747d1860  mov eax, [r15+0x98]
000074ad747d1867  lea r14d, [eax+0x01]
000074ad747d186c  mov [rsp+0x10], r14d
000074ad747d1871  mov r14d, r14d
000074ad747d1874  mov [r15+0x98], r14
000074ad747d187b  xor eax, eax
000074ad747d187d  mov r14d, [rsp+0x10]
000074ad747d1882  cmp r14d, 0x10000
000074ad747d1889  cmc
000074ad747d188a  lahf
000074ad747d188b  seto al
000074ad747d188e  mov [r15+0x108], eax
000074ad747d1895  mov eax, [r15+0x108]
000074ad747d189c  sahf
000074ad747d189d  jnz 0x000074AD747D18CF
000074ad747d189f  cmp dword ptr [r15+0x318], 0x00
000074ad747d18a7  jz 0x000074AD747D19A0
000074ad747d18ad  nop [rax+rax*1], ax
000074ad747d18b6  nop [rax+rax*1], eax
000074ad747d18be  mov eax, 0x4103F4
000074ad747d18c3  mov [r15+0x100], rax
000074ad747d18ca  jmp 0x000074AD745FE110
000074ad747d18cf  cmp dword ptr [r15+0x318], 0x00
000074ad747d18d7  jz 0x000074AD747D1910
000074ad747d18dd  nop [rax+rax*1], ax
000074ad747d18e6  nop [rax+rax*1], eax
000074ad747d18ee  mov eax, 0x4103E0
000074ad747d18f3  mov [r15+0x100], rax
000074ad747d18fa  jmp 0x000074AD745FE110
000074ad747d18ff  int3
000074ad747d1900  int3
000074ad747d1901  nop [rax+rax*1], ax
000074ad747d190a  nop [rax+rax*1], ax
000074ad747d1910  mov eax, [r15]
000074ad747d1913  mov r14d, [r15+0x98]
000074ad747d191a  lea r12d, [eax+r14d*1]
000074ad747d191f  mov r12d, r12d
000074ad747d1922  mov [r15], r12
000074ad747d1925  mov qword ptr [r15+0xF0], 0x4103E8
000074ad747d1930  mov r14d, [r15+0x320]
000074ad747d1937  mov eax, 0x4103E8
000074ad747d193c  mov rcx, 0x74AD747D1860
000074ad747d1946  mov [r15+r14*8+0x328], rax
000074ad747d194e  mov [r15+r14*8+0x368], rcx
000074ad747d1956  add r14d, 0x01
000074ad747d195a  and r14d, 0x07
000074ad747d195e  mov [r15+0x320], r14d
000074ad747d1965  cmp dword ptr [r15+0x318], 0x00
000074ad747d196d  jz 0x000074AD747D0F20
000074ad747d1973  nop [rax+rax*1], ax
000074ad747d197c  nop [rax+rax*1], eax
000074ad747d1984  mov eax, 0x410938
000074ad747d1989  mov [r15+0x100], rax
000074ad747d1990  jmp 0x000074AD745FE110
000074ad747d1995  int3
000074ad747d1996  int3
000074ad747d1997  nop [rax+rax*1], ax
000074ad747d19a0  vmovaps xmm1, [0x000074AD743FE010]
000074ad747d19a8  movq xmm1, xmm1
000074ad747d19ac  movaps [r15+0x110], xmm1
000074ad747d19b4  mov eax, 0x420AA0
000074ad747d19b9  mov r14, [r13+rax*1]
000074ad747d19be  movq xmm1, r14
000074ad747d19c3  movaps [r15+0x120], xmm1
000074ad747d19cb  vmovaps xmm1, [0x000074AD743FE020]
000074ad747d19d3  movq xmm1, xmm1
000074ad747d19d7  movaps [r15+0x140], xmm1
000074ad747d19df  vmovaps xmm1, [0x000074AD743FE030]
000074ad747d19e7  vpbroadcastq xmm1, xmm1
000074ad747d19ec  movaps [r15+0x150], xmm1
000074ad747d19f4  mov qword ptr [r15+0x40], 0x02
000074ad747d19fc  vmovaps xmm15, [0x000074AD743FE040]
000074ad747d1a04  movq xmm15, xmm15
000074ad747d1a09  movaps [r15+0x160], xmm15
000074ad747d1a11  vmovaps xmm15, [0x000074AD743FE050]
000074ad747d1a19  vpbroadcastq xmm15, xmm15
000074ad747d1a1e  movaps [r15+0x130], xmm15
000074ad747d1a26  mov rax, [r15+0x40]
000074ad747d1a2a  vmovq xmm14, rax
000074ad747d1a2f  vpbroadcastq xmm14, xmm14
000074ad747d1a34  movaps [r15+0x170], xmm14
000074ad747d1a3c  mov eax, 0x4209D0
000074ad747d1a41  movups xmm13, [r13+rax*1]
000074ad747d1a47  mov qword ptr [r15+0x40], 0x431D90
000074ad747d1a4f  mov eax, [r15]
000074ad747d1a52  mov r14d, 0x430C48
000074ad747d1a58  mov [r13+r14*1], eax
000074ad747d1a5d  mov qword ptr [r15+0x50], 0x431F90
000074ad747d1a65  vpmovqd xmm12, xmm13
000074ad747d1a6b  pxor xmm11, xmm11
000074ad747d1a70  punpcklqdq xmm12, xmm11
000074ad747d1a75  movaps [r15+0x210], xmm12
000074ad747d1a7d  movq xmm12, qword ptr [r15+0x140]
000074ad747d1a86  movq xmm11, qword ptr [r15+0x120]
000074ad747d1a8f  psubd xmm12, xmm11
000074ad747d1a94  movq xmm12, xmm12
000074ad747d1a99  paddq xmm13, xmm14
000074ad747d1a9e  movaps [r15+0x180], xmm13
000074ad747d1aa6  movq xmm14, qword ptr [r15+0x160]
000074ad747d1aaf  paddd xmm11, xmm14
000074ad747d1ab4  movq xmm11, xmm11
000074ad747d1ab9  movq xmm11, xmm11
000074ad747d1abe  movaps [r15+0x120], xmm11
000074ad747d1ac6  pmovzxdq xmm12, xmm12
000074ad747d1acc  psllq xmm12, 0x00
000074ad747d1ad2  movq xmm14, qword ptr [r15+0x210]
000074ad747d1adb  movq xmm13, qword ptr [r15+0x110]
000074ad747d1ae4  paddd xmm14, xmm13
000074ad747d1ae9  movq xmm14, xmm14
000074ad747d1aee  vcvtuqq2pd xmm12, xmm12
000074ad747d1af4  pmovzxdq xmm14, xmm14
000074ad747d1afa  psllq xmm14, 0x00
000074ad747d1b00  vcvtuqq2pd xmm14, xmm14
000074ad747d1b06  movaps xmm13, xmm12
000074ad747d1b0a  mulpd xmm13, xmm1
000074ad747d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000074ad747d1b15  ptest xmm11, xmm11
000074ad747d1b1b  jnz 0x000074AD747D1C0F
000074ad747d1b21  movaps [r15+0x220], xmm13
000074ad747d1b29  mov eax, 0x431F90
000074ad747d1b2e  movups [r13+rax*1], xmm13
000074ad747d1b34  movaps xmm1, xmm14
000074ad747d1b38  mulpd xmm1, xmm15
000074ad747d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000074ad747d1b42  ptest xmm13, xmm13
000074ad747d1b48  jnz 0x000074AD747D1D5C
000074ad747d1b4e  movaps [r15+0x210], xmm1
000074ad747d1b56  mov eax, 0x431D90
000074ad747d1b5b  movups [r13+rax*1], xmm1
000074ad747d1b61  mov qword ptr [r15+0x48], 0x10
000074ad747d1b69  xor eax, eax
000074ad747d1b6b  mov r14d, 0x10
000074ad747d1b71  mov r12d, 0x200
000074ad747d1b77  cmp r14, r12
000074ad747d1b7a  cmc
000074ad747d1b7b  lahf
000074ad747d1b7c  seto al
000074ad747d1b7f  mov [r15+0x108], eax
000074ad747d1b86  mov eax, [r15+0x108]
000074ad747d1b8d  sahf
000074ad747d1b8e  jnz 0x000074AD747D1BC0
000074ad747d1b90  cmp dword ptr [r15+0x318], 0x00
000074ad747d1b98  jz 0x000074AD747D2300
000074ad747d1b9e  nop [rax+rax*1], ax
000074ad747d1ba7  nop [rax+rax*1], eax
000074ad747d1baf  mov eax, 0x410480
000074ad747d1bb4  mov [r15+0x100], rax
000074ad747d1bbb  jmp 0x000074AD745FE110
000074ad747d1bc0  cmp dword ptr [r15+0x318], 0x00
000074ad747d1bc8  jz 0x000074AD747D1EB0
000074ad747d1bce  nop [rax+rax*1], ax
000074ad747d1bd7  nop [rax+rax*1], eax
000074ad747d1bdf  mov eax, 0x410440
000074ad747d1be4  mov [r15+0x100], rax
000074ad747d1beb  jmp 0x000074AD745FE110
000074ad747d1bf0  int3
000074ad747d1bf1  call 0x000074AD7460DC20
000074ad747d1bf6  jmp 0x000074AD747D19BE
000074ad747d1bfb  call 0x000074AD7460C260
000074ad747d1c00  jmp 0x000074AD747D1A47
000074ad747d1c05  call 0x000074AD746D5D70
000074ad747d1c0a  jmp 0x000074AD747D1A5D
000074ad747d1c0f  sub rsp, 0x08
000074ad747d1c13  push rax
000074ad747d1c14  push rcx
000074ad747d1c15  push rdx
000074ad747d1c16  push rdi
000074ad747d1c17  push rsi
000074ad747d1c18  push r8
000074ad747d1c1a  push r9
000074ad747d1c1c  push r10
000074ad747d1c1e  push r11
000074ad747d1c20  sub rsp, 0xF0
000074ad747d1c27  vmovaps [rsp], xmm0
000074ad747d1c2c  vmovaps [rsp+0x10], xmm1
000074ad747d1c32  vmovaps [rsp+0x20], xmm2
000074ad747d1c38  vmovaps [rsp+0x30], xmm3
000074ad747d1c3e  vmovaps [rsp+0x40], xmm4
000074ad747d1c44  vmovaps [rsp+0x50], xmm5
000074ad747d1c4a  vmovaps [rsp+0x60], xmm6
000074ad747d1c50  vmovaps [rsp+0x70], xmm7
000074ad747d1c56  vmovaps [rsp+0x80], xmm8
000074ad747d1c5f  vmovaps [rsp+0x90], xmm9
000074ad747d1c68  vmovaps [rsp+0xA0], xmm10
000074ad747d1c71  vmovaps [rsp+0xB0], xmm11
000074ad747d1c7a  vmovaps [rsp+0xC0], xmm12
000074ad747d1c83  vmovaps [rsp+0xD0], xmm14
000074ad747d1c8c  vmovaps [rsp+0xE0], xmm15
000074ad747d1c95  sub rsp, 0x30
000074ad747d1c99  movaps [rsp], xmm13
000074ad747d1c9e  movaps [rsp+0x10], xmm12
000074ad747d1ca4  movaps [rsp+0x20], xmm1
000074ad747d1ca9  lea rdi, [rsp]
000074ad747d1cad  mov esi, 0x00
000074ad747d1cb2  mov rax, 0x5C17501CE530
000074ad747d1cbc  call rax
000074ad747d1cbe  movaps xmm13, [rsp]
000074ad747d1cc3  add rsp, 0x30
000074ad747d1cc7  vmovaps xmm0, [rsp]
000074ad747d1ccc  vmovaps xmm1, [rsp+0x10]
000074ad747d1cd2  vmovaps xmm2, [rsp+0x20]
000074ad747d1cd8  vmovaps xmm3, [rsp+0x30]
000074ad747d1cde  vmovaps xmm4, [rsp+0x40]
000074ad747d1ce4  vmovaps xmm5, [rsp+0x50]
000074ad747d1cea  vmovaps xmm6, [rsp+0x60]
000074ad747d1cf0  vmovaps xmm7, [rsp+0x70]
000074ad747d1cf6  vmovaps xmm8, [rsp+0x80]
000074ad747d1cff  vmovaps xmm9, [rsp+0x90]
000074ad747d1d08  vmovaps xmm10, [rsp+0xA0]
000074ad747d1d11  vmovaps xmm11, [rsp+0xB0]
000074ad747d1d1a  vmovaps xmm12, [rsp+0xC0]
000074ad747d1d23  vmovaps xmm14, [rsp+0xD0]
000074ad747d1d2c  vmovaps xmm15, [rsp+0xE0]
000074ad747d1d35  add rsp, 0xF0
000074ad747d1d3c  pop r11
000074ad747d1d3e  pop r10
000074ad747d1d40  pop r9
000074ad747d1d42  pop r8
000074ad747d1d44  pop rsi
000074ad747d1d45  pop rdi
000074ad747d1d46  pop rdx
000074ad747d1d47  pop rcx
000074ad747d1d48  pop rax
000074ad747d1d49  add rsp, 0x08
000074ad747d1d4d  jmp 0x000074AD747D1B21
000074ad747d1d52  call 0x000074AD7460C380
000074ad747d1d57  jmp 0x000074AD747D1B34
000074ad747d1d5c  sub rsp, 0x08
000074ad747d1d60  push rax
000074ad747d1d61  push rcx
000074ad747d1d62  push rdx
000074ad747d1d63  push rdi
000074ad747d1d64  push rsi
000074ad747d1d65  push r8
000074ad747d1d67  push r9
000074ad747d1d69  push r10
000074ad747d1d6b  push r11
000074ad747d1d6d  sub rsp, 0xF0
000074ad747d1d74  vmovaps [rsp], xmm0
000074ad747d1d79  vmovaps [rsp+0x10], xmm2
000074ad747d1d7f  vmovaps [rsp+0x20], xmm3
000074ad747d1d85  vmovaps [rsp+0x30], xmm4
000074ad747d1d8b  vmovaps [rsp+0x40], xmm5
000074ad747d1d91  vmovaps [rsp+0x50], xmm6
000074ad747d1d97  vmovaps [rsp+0x60], xmm7
000074ad747d1d9d  vmovaps [rsp+0x70], xmm8
000074ad747d1da3  vmovaps [rsp+0x80], xmm9
000074ad747d1dac  vmovaps [rsp+0x90], xmm10
000074ad747d1db5  vmovaps [rsp+0xA0], xmm11
000074ad747d1dbe  vmovaps [rsp+0xB0], xmm12
000074ad747d1dc7  vmovaps [rsp+0xC0], xmm13
000074ad747d1dd0  vmovaps [rsp+0xD0], xmm14
000074ad747d1dd9  vmovaps [rsp+0xE0], xmm15
000074ad747d1de2  sub rsp, 0x30
000074ad747d1de6  movaps [rsp], xmm1
000074ad747d1dea  movaps [rsp+0x10], xmm14
000074ad747d1df0  movaps [rsp+0x20], xmm15
000074ad747d1df6  lea rdi, [rsp]
000074ad747d1dfa  mov esi, 0x00
000074ad747d1dff  mov rax, 0x5C17501CE530
000074ad747d1e09  call rax
000074ad747d1e0b  movaps xmm1, [rsp]
000074ad747d1e0f  add rsp, 0x30
000074ad747d1e13  vmovaps xmm0, [rsp]
000074ad747d1e18  vmovaps xmm2, [rsp+0x10]
000074ad747d1e1e  vmovaps xmm3, [rsp+0x20]
000074ad747d1e24  vmovaps xmm4, [rsp+0x30]
000074ad747d1e2a  vmovaps xmm5, [rsp+0x40]
000074ad747d1e30  vmovaps xmm6, [rsp+0x50]
000074ad747d1e36  vmovaps xmm7, [rsp+0x60]
000074ad747d1e3c  vmovaps xmm8, [rsp+0x70]
000074ad747d1e42  vmovaps xmm9, [rsp+0x80]
000074ad747d1e4b  vmovaps xmm10, [rsp+0x90]
000074ad747d1e54  vmovaps xmm11, [rsp+0xA0]
000074ad747d1e5d  vmovaps xmm12, [rsp+0xB0]
000074ad747d1e66  vmovaps xmm13, [rsp+0xC0]
000074ad747d1e6f  vmovaps xmm14, [rsp+0xD0]
000074ad747d1e78  vmovaps xmm15, [rsp+0xE0]
000074ad747d1e81  add rsp, 0xF0
000074ad747d1e88  pop r11
000074ad747d1e8a  pop r10
000074ad747d1e8c  pop r9
000074ad747d1e8e  pop r8
000074ad747d1e90  pop rsi
000074ad747d1e91  pop rdi
000074ad747d1e92  pop rdx
000074ad747d1e93  pop rcx
000074ad747d1e94  pop rax
000074ad747d1e95  add rsp, 0x08
000074ad747d1e99  jmp 0x000074AD747D1B4E
000074ad747d1e9e  call 0x000074AD745FF540
000074ad747d1ea3  jmp 0x000074AD747D1B61
000074ad747d1ea8  int3
000074ad747d1ea9  nop [rax], eax
000074ad747d1eb0  movaps xmm1, [r15+0x180]
000074ad747d1eb8  vpmovqd xmm15, xmm1
000074ad747d1ebe  pxor xmm14, xmm14
000074ad747d1ec3  punpcklqdq xmm15, xmm14
000074ad747d1ec8  movaps [r15+0x210], xmm15
000074ad747d1ed0  movq xmm15, qword ptr [r15+0x140]
000074ad747d1ed9  movq xmm14, qword ptr [r15+0x120]
000074ad747d1ee2  psubd xmm15, xmm14
000074ad747d1ee7  movq xmm15, xmm15
000074ad747d1eec  movaps xmm13, [r15+0x170]
000074ad747d1ef4  paddq xmm1, xmm13
000074ad747d1ef9  movaps [r15+0x180], xmm1
000074ad747d1f01  movq xmm1, qword ptr [r15+0x160]
000074ad747d1f0a  paddd xmm14, xmm1
000074ad747d1f0f  movq xmm14, xmm14
000074ad747d1f14  movq xmm14, xmm14
000074ad747d1f19  movaps [r15+0x120], xmm14
000074ad747d1f21  pmovzxdq xmm15, xmm15
000074ad747d1f27  psllq xmm15, 0x00
000074ad747d1f2d  movq xmm1, qword ptr [r15+0x210]
000074ad747d1f36  movq xmm14, qword ptr [r15+0x110]
000074ad747d1f3f  paddd xmm1, xmm14
000074ad747d1f44  movq xmm1, xmm1
000074ad747d1f48  vcvtuqq2pd xmm15, xmm15
000074ad747d1f4e  pmovzxdq xmm1, xmm1
000074ad747d1f53  psllq xmm1, 0x00
000074ad747d1f58  vcvtuqq2pd xmm1, xmm1
000074ad747d1f5e  movaps xmm14, [r15+0x150]
000074ad747d1f66  movaps xmm13, xmm15
000074ad747d1f6a  mulpd xmm13, xmm14
000074ad747d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d1f75  ptest xmm12, xmm12
000074ad747d1f7b  jnz 0x000074AD747D205E
000074ad747d1f81  movaps [r15+0x220], xmm13
000074ad747d1f89  mov rax, [r15+0x48]
000074ad747d1f8d  mov r14, [r15+0x50]
000074ad747d1f91  lea r12, [r14+rax*1]
000074ad747d1f95  movups [r13+r12*1], xmm13
000074ad747d1f9b  movaps xmm15, [r15+0x130]
000074ad747d1fa3  movaps xmm14, xmm1
000074ad747d1fa7  mulpd xmm14, xmm15
000074ad747d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000074ad747d1fb2  ptest xmm13, xmm13
000074ad747d1fb8  jnz 0x000074AD747D21AC
000074ad747d1fbe  movaps [r15+0x210], xmm14
000074ad747d1fc6  mov r14, [r15+0x40]
000074ad747d1fca  lea r12, [r14+rax*1]
000074ad747d1fce  movups [r13+r12*1], xmm14
000074ad747d1fd4  lea r14, [rax+0x10]
000074ad747d1fd8  mov [r15+0x48], r14
000074ad747d1fdc  xor eax, eax
000074ad747d1fde  mov r12d, 0x200
000074ad747d1fe4  cmp r14, r12
000074ad747d1fe7  cmc
000074ad747d1fe8  lahf
000074ad747d1fe9  seto al
000074ad747d1fec  mov [r15+0x108], eax
000074ad747d1ff3  mov eax, [r15+0x108]
000074ad747d1ffa  sahf
000074ad747d1ffb  jnz 0x000074AD747D202D
000074ad747d1ffd  cmp dword ptr [r15+0x318], 0x00
000074ad747d2005  jz 0x000074AD747D2300
000074ad747d200b  nop [rax+rax*1], ax
000074ad747d2014  nop [rax+rax*1], eax
000074ad747d201c  mov eax, 0x410480
000074ad747d2021  mov [r15+0x100], rax
000074ad747d2028  jmp 0x000074AD745FE110
000074ad747d202d  cmp dword ptr [r15+0x318], 0x00
000074ad747d2035  jz 0x000074AD747D1EB0
000074ad747d203b  nop [rax+rax*1], ax
000074ad747d2044  nop [rax+rax*1], eax
000074ad747d204c  mov eax, 0x410440
000074ad747d2051  mov [r15+0x100], rax
000074ad747d2058  jmp 0x000074AD745FE110
000074ad747d205d  int3
000074ad747d205e  sub rsp, 0x08
000074ad747d2062  push rax
000074ad747d2063  push rcx
000074ad747d2064  push rdx
000074ad747d2065  push rdi
000074ad747d2066  push rsi
000074ad747d2067  push r8
000074ad747d2069  push r9
000074ad747d206b  push r10
000074ad747d206d  push r11
000074ad747d206f  sub rsp, 0xF0
000074ad747d2076  vmovaps [rsp], xmm0
000074ad747d207b  vmovaps [rsp+0x10], xmm1
000074ad747d2081  vmovaps [rsp+0x20], xmm2
000074ad747d2087  vmovaps [rsp+0x30], xmm3
000074ad747d208d  vmovaps [rsp+0x40], xmm4
000074ad747d2093  vmovaps [rsp+0x50], xmm5
000074ad747d2099  vmovaps [rsp+0x60], xmm6
000074ad747d209f  vmovaps [rsp+0x70], xmm7
000074ad747d20a5  vmovaps [rsp+0x80], xmm8
000074ad747d20ae  vmovaps [rsp+0x90], xmm9
000074ad747d20b7  vmovaps [rsp+0xA0], xmm10
000074ad747d20c0  vmovaps [rsp+0xB0], xmm11
000074ad747d20c9  vmovaps [rsp+0xC0], xmm12
000074ad747d20d2  vmovaps [rsp+0xD0], xmm14
000074ad747d20db  vmovaps [rsp+0xE0], xmm15
000074ad747d20e4  sub rsp, 0x30
000074ad747d20e8  movaps [rsp], xmm13
000074ad747d20ed  movaps [rsp+0x10], xmm15
000074ad747d20f3  movaps [rsp+0x20], xmm14
000074ad747d20f9  lea rdi, [rsp]
000074ad747d20fd  mov esi, 0x00
000074ad747d2102  mov rax, 0x5C17501CE530
000074ad747d210c  call rax
000074ad747d210e  movaps xmm13, [rsp]
000074ad747d2113  add rsp, 0x30
000074ad747d2117  vmovaps xmm0, [rsp]
000074ad747d211c  vmovaps xmm1, [rsp+0x10]
000074ad747d2122  vmovaps xmm2, [rsp+0x20]
000074ad747d2128  vmovaps xmm3, [rsp+0x30]
000074ad747d212e  vmovaps xmm4, [rsp+0x40]
000074ad747d2134  vmovaps xmm5, [rsp+0x50]
000074ad747d213a  vmovaps xmm6, [rsp+0x60]
000074ad747d2140  vmovaps xmm7, [rsp+0x70]
000074ad747d2146  vmovaps xmm8, [rsp+0x80]
000074ad747d214f  vmovaps xmm9, [rsp+0x90]
000074ad747d2158  vmovaps xmm10, [rsp+0xA0]
000074ad747d2161  vmovaps xmm11, [rsp+0xB0]
000074ad747d216a  vmovaps xmm12, [rsp+0xC0]
000074ad747d2173  vmovaps xmm14, [rsp+0xD0]
000074ad747d217c  vmovaps xmm15, [rsp+0xE0]
000074ad747d2185  add rsp, 0xF0
000074ad747d218c  pop r11
000074ad747d218e  pop r10
000074ad747d2190  pop r9
000074ad747d2192  pop r8
000074ad747d2194  pop rsi
000074ad747d2195  pop rdi
000074ad747d2196  pop rdx
000074ad747d2197  pop rcx
000074ad747d2198  pop rax
000074ad747d2199  add rsp, 0x08
000074ad747d219d  jmp 0x000074AD747D1F81
000074ad747d21a2  call 0x000074AD746C2240
000074ad747d21a7  jmp 0x000074AD747D1F9B
000074ad747d21ac  sub rsp, 0x08
000074ad747d21b0  push rax
000074ad747d21b1  push rcx
000074ad747d21b2  push rdx
000074ad747d21b3  push rdi
000074ad747d21b4  push rsi
000074ad747d21b5  push r8
000074ad747d21b7  push r9
000074ad747d21b9  push r10
000074ad747d21bb  push r11
000074ad747d21bd  sub rsp, 0xF0
000074ad747d21c4  vmovaps [rsp], xmm0
000074ad747d21c9  vmovaps [rsp+0x10], xmm1
000074ad747d21cf  vmovaps [rsp+0x20], xmm2
000074ad747d21d5  vmovaps [rsp+0x30], xmm3
000074ad747d21db  vmovaps [rsp+0x40], xmm4
000074ad747d21e1  vmovaps [rsp+0x50], xmm5
000074ad747d21e7  vmovaps [rsp+0x60], xmm6
000074ad747d21ed  vmovaps [rsp+0x70], xmm7
000074ad747d21f3  vmovaps [rsp+0x80], xmm8
000074ad747d21fc  vmovaps [rsp+0x90], xmm9
000074ad747d2205  vmovaps [rsp+0xA0], xmm10
000074ad747d220e  vmovaps [rsp+0xB0], xmm11
000074ad747d2217  vmovaps [rsp+0xC0], xmm12
000074ad747d2220  vmovaps [rsp+0xD0], xmm13
000074ad747d2229  vmovaps [rsp+0xE0], xmm15
000074ad747d2232  sub rsp, 0x30
000074ad747d2236  movaps [rsp], xmm14
000074ad747d223b  movaps [rsp+0x10], xmm1
000074ad747d2240  movaps [rsp+0x20], xmm15
000074ad747d2246  lea rdi, [rsp]
000074ad747d224a  mov esi, 0x00
000074ad747d224f  mov rax, 0x5C17501CE530
000074ad747d2259  call rax
000074ad747d225b  movaps xmm14, [rsp]
000074ad747d2260  add rsp, 0x30
000074ad747d2264  vmovaps xmm0, [rsp]
000074ad747d2269  vmovaps xmm1, [rsp+0x10]
000074ad747d226f  vmovaps xmm2, [rsp+0x20]
000074ad747d2275  vmovaps xmm3, [rsp+0x30]
000074ad747d227b  vmovaps xmm4, [rsp+0x40]
000074ad747d2281  vmovaps xmm5, [rsp+0x50]
000074ad747d2287  vmovaps xmm6, [rsp+0x60]
000074ad747d228d  vmovaps xmm7, [rsp+0x70]
000074ad747d2293  vmovaps xmm8, [rsp+0x80]
000074ad747d229c  vmovaps xmm9, [rsp+0x90]
000074ad747d22a5  vmovaps xmm10, [rsp+0xA0]
000074ad747d22ae  vmovaps xmm11, [rsp+0xB0]
000074ad747d22b7  vmovaps xmm12, [rsp+0xC0]
000074ad747d22c0  vmovaps xmm13, [rsp+0xD0]
000074ad747d22c9  vmovaps xmm15, [rsp+0xE0]
000074ad747d22d2  add rsp, 0xF0
000074ad747d22d9  pop r11
000074ad747d22db  pop r10
000074ad747d22dd  pop r9
000074ad747d22df  pop r8
000074ad747d22e1  pop rsi
000074ad747d22e2  pop rdi
000074ad747d22e3  pop rdx
000074ad747d22e4  pop rcx
000074ad747d22e5  pop rax
000074ad747d22e6  add rsp, 0x08
000074ad747d22ea  jmp 0x000074AD747D1FBE
000074ad747d22ef  call 0x000074AD746C34C0
000074ad747d22f4  jmp 0x000074AD747D1FD4
000074ad747d22f9  int3
000074ad747d22fa  nop [rax+rax*1], ax
000074ad747d2300  mov rax, [r15+0x50]
000074ad747d2304  movups xmm1, [r13+rax*1]
000074ad747d230a  lea r14, [rax+0x10]
000074ad747d230e  movups xmm15, [r13+r14*1]
000074ad747d2314  mov qword ptr [r15+0x48], 0x00
000074ad747d231c  lea r14, [rax+0x40]
000074ad747d2320  movups xmm14, [r13+r14*1]
000074ad747d2326  lea r14, [rax+0x50]
000074ad747d232a  movups xmm13, [r13+r14*1]
000074ad747d2330  lea r14, [rax+0x80]
000074ad747d2337  movups xmm12, [r13+r14*1]
000074ad747d233d  lea r14, [rax+0x90]
000074ad747d2344  movups xmm11, [r13+r14*1]
000074ad747d234a  mov r14, [r15+0xF8]
000074ad747d2351  movups [r13+r14*1], xmm1
000074ad747d2357  lea r12, [rax+0x20]
000074ad747d235b  movups xmm1, [r13+r12*1]
000074ad747d2361  lea r12, [rax+0x30]
000074ad747d2365  movups xmm10, [r13+r12*1]
000074ad747d236b  lea r12, [rax+0xC0]
000074ad747d2372  movups xmm9, [r13+r12*1]
000074ad747d2378  lea r12, [rax+0xD0]
000074ad747d237f  movups xmm8, [r13+r12*1]
000074ad747d2385  lea r12, [rax+0x100]
000074ad747d238c  movups xmm7, [r13+r12*1]
000074ad747d2392  lea r12, [rax+0x110]
000074ad747d2399  movups xmm6, [r13+r12*1]
000074ad747d239f  lea r12, [rax+0x140]
000074ad747d23a6  movups xmm5, [r13+r12*1]
000074ad747d23ac  lea r12, [rax+0x150]
000074ad747d23b3  movups xmm4, [r13+r12*1]
000074ad747d23b9  lea r12, [r14+0xB0]
000074ad747d23c0  movups [r13+r12*1], xmm10
000074ad747d23c6  lea r12, [r14+0xC0]
000074ad747d23cd  movups [r13+r12*1], xmm1
000074ad747d23d3  lea r12, [rax+0x180]
000074ad747d23da  movups xmm1, [r13+r12*1]
000074ad747d23e0  lea r12, [rax+0x190]
000074ad747d23e7  movups xmm10, [r13+r12*1]
000074ad747d23ed  lea r12, [rax+0x1C0]
000074ad747d23f4  movups xmm3, [r13+r12*1]
000074ad747d23fa  lea r12, [rax+0x1D0]
000074ad747d2401  movups xmm2, [r13+r12*1]
000074ad747d2407  lea r12, [rax+0x60]
000074ad747d240b  vmovaps [rsp+0x10], xmm1
000074ad747d2411  movups xmm1, [r13+r12*1]
000074ad747d2417  lea r12, [rax+0x70]
000074ad747d241b  vmovaps [rsp+0x20], xmm1
000074ad747d2421  movups xmm1, [r13+r12*1]
000074ad747d2427  lea r12, [r14+0x70]
000074ad747d242b  movups [r13+r12*1], xmm10
000074ad747d2431  lea r12, [r14+0x80]
000074ad747d2438  vmovaps xmm10, [rsp+0x10]
000074ad747d243e  movups [r13+r12*1], xmm10
000074ad747d2444  lea r12, [rax+0xA0]
000074ad747d244b  movups xmm10, [r13+r12*1]
000074ad747d2451  lea r12, [rax+0xB0]
000074ad747d2458  vmovaps [rsp+0x10], xmm1
000074ad747d245e  movups xmm1, [r13+r12*1]
000074ad747d2464  lea r12, [r14+0x90]
000074ad747d246b  movups [r13+r12*1], xmm2
000074ad747d2471  lea r12, [r14+0xA0]
000074ad747d2478  movups [r13+r12*1], xmm3
000074ad747d247e  lea r12, [rax+0xE0]
000074ad747d2485  movups xmm3, [r13+r12*1]
000074ad747d248b  lea r12, [rax+0xF0]
000074ad747d2492  movups xmm2, [r13+r12*1]
000074ad747d2498  lea r12, [rax+0x120]
000074ad747d249f  vmovaps [rsp+0x30], xmm1
000074ad747d24a5  movups xmm1, [r13+r12*1]
000074ad747d24ab  lea r12, [rax+0x130]
000074ad747d24b2  vmovaps [rsp+0x40], xmm1
000074ad747d24b8  movups xmm1, [r13+r12*1]
000074ad747d24be  vmovaps [rsp+0x50], xmm1
000074ad747d24c4  vmovaps xmm1, [rsp+0x40]
000074ad747d24ca  movaps [r15+0x190], xmm1
000074ad747d24d2  lea r12, [rax+0x160]
000074ad747d24d9  vmovaps [rsp+0x40], xmm1
000074ad747d24df  movups xmm1, [r13+r12*1]
000074ad747d24e5  lea r12, [rax+0x170]
000074ad747d24ec  vmovaps [rsp+0x60], xmm1
000074ad747d24f2  movups xmm1, [r13+r12*1]
000074ad747d24f8  lea r12, [rax+0x1A0]
000074ad747d24ff  vmovaps [rsp+0x70], xmm1
000074ad747d2505  movups xmm1, [r13+r12*1]
000074ad747d250b  lea r12, [rax+0x1B0]
000074ad747d2512  vmovaps [rsp+0x80], xmm1
000074ad747d251b  movups xmm1, [r13+r12*1]
000074ad747d2521  lea r12, [rax+0x1E0]
000074ad747d2528  vmovaps [rsp+0x90], xmm1
000074ad747d2531  movups xmm1, [r13+r12*1]
000074ad747d2537  lea r12, [rax+0x1F0]
000074ad747d253e  vmovaps [rsp+0xA0], xmm1
000074ad747d2547  movups xmm1, [r13+r12*1]
000074ad747d254d  mov qword ptr [r15+0x50], 0x432190
000074ad747d2555  lea rax, [r14+0x50]
000074ad747d2559  vmovaps [rsp+0xB0], xmm1
000074ad747d2562  vmovaps xmm1, [rsp+0x60]
000074ad747d2568  movups [r13+rax*1], xmm1
000074ad747d256e  lea rax, [r14+0x60]
000074ad747d2572  movups [r13+rax*1], xmm5
000074ad747d2578  lea rax, [r14+0x40]
000074ad747d257c  vmovaps xmm1, [rsp+0x70]
000074ad747d2582  movups [r13+rax*1], xmm1
000074ad747d2588  lea rax, [r14+0x20]
000074ad747d258c  vmovaps xmm1, [rsp+0xA0]
000074ad747d2595  movups [r13+rax*1], xmm1
000074ad747d259b  lea rax, [r14+0x30]
000074ad747d259f  vmovaps xmm1, [rsp+0x90]
000074ad747d25a8  movups [r13+rax*1], xmm1
000074ad747d25ae  lea rax, [r14+0x10]
000074ad747d25b2  vmovaps xmm1, [rsp+0xB0]
000074ad747d25bb  movups [r13+rax*1], xmm1
000074ad747d25c1  mov rax, [r15+0x40]
000074ad747d25c5  vxorps xmm1, xmm1, xmm1
000074ad747d25c9  vpbroadcastq xmm1, xmm1
000074ad747d25ce  vxorps xmm5, xmm5, xmm5
000074ad747d25d2  vpbroadcastq xmm5, xmm5
000074ad747d25d7  lea r12, [rax+0x30]
000074ad747d25db  mov r11, [r13+r12*1]
000074ad747d25e0  lea r12, [rax+0x38]
000074ad747d25e4  mov r10, [r13+r12*1]
000074ad747d25e9  vmovaps [rsp+0x60], xmm1
000074ad747d25ef  movq xmm1, r11
000074ad747d25f4  vmovaps [rsp+0x70], xmm1
000074ad747d25fa  movq xmm1, r10
000074ad747d25ff  vmovaps [rsp+0x90], xmm1
000074ad747d2608  vmovaps xmm1, [rsp+0x70]
000074ad747d260e  movq xmm1, xmm1
000074ad747d2612  vmovaps [rsp+0x70], xmm1
000074ad747d2618  vmovaps xmm1, [rsp+0x90]
000074ad747d2621  movq xmm1, xmm1
000074ad747d2625  vmovaps [rsp+0x90], xmm1
000074ad747d262e  movq xmm1, xmm1
000074ad747d2632  movaps [r15+0x270], xmm1
000074ad747d263a  vmovaps [rsp+0xA0], xmm7
000074ad747d2643  vmovaps xmm1, [rsp+0xA0]
000074ad747d264c  por xmm7, xmm1
000074ad747d2650  lea r12, [rax+0x20]
000074ad747d2654  mov r11, [r13+r12*1]
000074ad747d2659  lea r12, [rax+0x28]
000074ad747d265d  mov r10, [r13+r12*1]
000074ad747d2662  movq xmm1, r11
000074ad747d2667  vmovaps [rsp+0xA0], xmm1
000074ad747d2670  movq xmm1, r10
000074ad747d2675  vmovaps [rsp+0xB0], xmm1
000074ad747d267e  vmovaps xmm1, [rsp+0xA0]
000074ad747d2687  movq xmm1, xmm1
000074ad747d268b  vmovaps [rsp+0xA0], xmm1
000074ad747d2694  vmovaps xmm1, [rsp+0xB0]
000074ad747d269d  movq xmm1, xmm1
000074ad747d26a1  vmovaps [rsp+0xB0], xmm2
000074ad747d26aa  vmovaps [rsp+0xC0], xmm1
000074ad747d26b3  vmovaps xmm1, [rsp+0xB0]
000074ad747d26bc  por xmm2, xmm1
000074ad747d26c0  vmovaps [rsp+0xB0], xmm3
000074ad747d26c9  vmovaps xmm1, [rsp+0xB0]
000074ad747d26d2  por xmm3, xmm1
000074ad747d26d6  vmovaps [rsp+0xB0], xmm4
000074ad747d26df  vmovaps xmm1, [rsp+0xB0]
000074ad747d26e8  por xmm4, xmm1
000074ad747d26ec  vmovaps [rsp+0xB0], xmm9
000074ad747d26f5  vmovaps xmm1, [rsp+0xB0]
000074ad747d26fe  por xmm9, xmm1
000074ad747d2703  lea r12, [rax+0x10]
000074ad747d2707  mov r11, [r13+r12*1]
000074ad747d270c  lea r12, [rax+0x18]
000074ad747d2710  mov r10, [r13+r12*1]
000074ad747d2715  movq xmm1, r11
000074ad747d271a  vmovaps [rsp+0xB0], xmm1
000074ad747d2723  movq xmm1, r10
000074ad747d2728  vmovaps [rsp+0xD0], xmm1
000074ad747d2731  vmovaps xmm1, [rsp+0xB0]
000074ad747d273a  movq xmm1, xmm1
000074ad747d273e  vmovaps [rsp+0xB0], xmm1
000074ad747d2747  vmovaps xmm1, [rsp+0xD0]
000074ad747d2750  movq xmm1, xmm1
000074ad747d2754  vmovaps [rsp+0xD0], xmm1
000074ad747d275d  vmovaps xmm1, [rsp+0x80]
000074ad747d2766  vmovaps [rsp+0xE0], xmm15
000074ad747d276f  vmovaps xmm15, [rsp+0x80]
000074ad747d2778  por xmm1, xmm15
000074ad747d277d  vmovaps xmm15, [rsp+0x10]
000074ad747d2783  vmovaps [rsp+0x80], xmm1
000074ad747d278c  vmovaps xmm1, [rsp+0x10]
000074ad747d2792  por xmm15, xmm1
000074ad747d2797  vmovaps xmm1, [rsp+0x20]
000074ad747d279d  vmovaps [rsp+0x10], xmm15
000074ad747d27a3  vmovaps xmm15, [rsp+0x20]
000074ad747d27a9  por xmm1, xmm15
000074ad747d27ae  vmovaps [rsp+0x20], xmm6
000074ad747d27b4  vmovaps xmm15, [rsp+0x20]
000074ad747d27ba  por xmm6, xmm15
000074ad747d27bf  vmovaps [rsp+0x20], xmm11
000074ad747d27c5  vmovaps xmm15, [rsp+0x20]
000074ad747d27cb  por xmm11, xmm15
000074ad747d27d0  vmovaps [rsp+0x20], xmm13
000074ad747d27d6  vmovaps xmm15, [rsp+0x20]
000074ad747d27dc  por xmm13, xmm15
000074ad747d27e1  vmovaps [rsp+0x20], xmm14
000074ad747d27e7  vmovaps xmm15, [rsp+0x20]
000074ad747d27ed  por xmm14, xmm15
000074ad747d27f2  mov r12, [r13+rax*1]
000074ad747d27f7  vmovq xmm15, r12
000074ad747d27fc  vpbroadcastq xmm15, xmm15
000074ad747d2801  vmovaps [rsp+0x20], xmm1
000074ad747d2807  vxorps xmm1, xmm1, xmm1
000074ad747d280b  vpbroadcastq xmm1, xmm1
000074ad747d2810  vmovaps [rsp+0xF0], xmm1
000074ad747d2819  movups xmm1, [r13+r14*1]
000074ad747d281f  vmovaps [rsp+0x100], xmm1
000074ad747d2828  vxorps xmm1, xmm1, xmm1
000074ad747d282c  vpbroadcastq xmm1, xmm1
000074ad747d2831  lea r12, [rax+0x08]
000074ad747d2835  mov rax, [r13+r12*1]
000074ad747d283a  vmovaps [rsp+0x110], xmm1
000074ad747d2843  movq xmm1, rax
000074ad747d2848  movaps [r15+0x240], xmm1
000074ad747d2850  mov qword ptr [r15+0x60], 0x432190
000074ad747d2858  mov qword ptr [r15+0x58], 0x40
000074ad747d2860  vmovaps xmm1, [rsp+0x60]
000074ad747d2866  vmovaps [rsp+0x60], xmm15
000074ad747d286c  vmovaps xmm15, [rsp+0x100]
000074ad747d2875  vmovaps [rsp+0x100], xmm14
000074ad747d287e  vmovaps xmm14, [rsp+0x60]
000074ad747d2884  vmovaps [rsp+0x60], xmm13
000074ad747d288a  vmovaps [rsp+0x120], xmm12
000074ad747d2893  movaps xmm13, xmm1
000074ad747d2897  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d289c  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d28a2  vptest xmm12, xmm12
000074ad747d28a7  jnz 0x000074AD747D3482
000074ad747d28ad  vmovaps xmm1, [rsp+0xE0]
000074ad747d28b6  movaps xmm15, xmm5
000074ad747d28ba  vfmadd231pd xmm15, xmm1, xmm14
000074ad747d28bf  vcmppd xmm12, xmm15, xmm15, 0x03
000074ad747d28c5  vptest xmm12, xmm12
000074ad747d28ca  jnz 0x000074AD747D35DB
000074ad747d28d0  vmovaps xmm12, [rsp+0x50]
000074ad747d28d6  vmovaps xmm5, [rsp+0x50]
000074ad747d28dc  por xmm12, xmm5
000074ad747d28e1  vmovaps xmm5, [rsp+0x30]
000074ad747d28e7  vmovaps [rsp+0x50], xmm1
000074ad747d28ed  vmovaps xmm1, [rsp+0x30]
000074ad747d28f3  por xmm5, xmm1
000074ad747d28f7  vmovaps [rsp+0x30], xmm10
000074ad747d28fd  vmovaps xmm1, [rsp+0x30]
000074ad747d2903  por xmm10, xmm1
000074ad747d2908  vmovaps [rsp+0x30], xmm8
000074ad747d290e  vmovaps xmm1, [rsp+0x30]
000074ad747d2914  por xmm8, xmm1
000074ad747d2919  vmovaps xmm1, [rsp+0x120]
000074ad747d2922  vmovaps [rsp+0x30], xmm15
000074ad747d2928  vmovaps xmm15, [rsp+0x120]
000074ad747d2931  por xmm1, xmm15
000074ad747d2936  vmovaps xmm15, [rsp+0x50]
000074ad747d293c  vmovaps [rsp+0xE0], xmm1
000074ad747d2945  vmovaps xmm1, [rsp+0x50]
000074ad747d294b  por xmm15, xmm1
000074ad747d2950  lea rax, [r14+0xC0]
000074ad747d2957  movups xmm1, [r13+rax*1]
000074ad747d295d  xor eax, eax
000074ad747d295f  mov r12d, 0x40
000074ad747d2965  mov r11d, 0x200
000074ad747d296b  cmp r12, r11
000074ad747d296e  cmc
000074ad747d296f  lahf
000074ad747d2970  seto al
000074ad747d2973  mov [r15+0x108], eax
000074ad747d297a  vmovaps [rsp+0x50], xmm1
000074ad747d2980  vmovaps xmm1, [rsp+0xF0]
000074ad747d2989  vmovaps [rsp+0xF0], xmm15
000074ad747d2992  vmovaps xmm15, [rsp+0x50]
000074ad747d2998  vmovaps [rsp+0x50], xmm13
000074ad747d299e  vmovaps [rsp+0x120], xmm12
000074ad747d29a7  movaps xmm13, xmm1
000074ad747d29ab  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d29b0  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d29b6  vptest xmm12, xmm12
000074ad747d29bb  jnz 0x000074AD747D373D
000074ad747d29c1  lea rax, [r14+0xB0]
000074ad747d29c8  movups xmm1, [r13+rax*1]
000074ad747d29ce  vmovaps xmm15, [rsp+0x110]
000074ad747d29d7  vmovaps [rsp+0x110], xmm13
000074ad747d29e0  movaps xmm12, xmm15
000074ad747d29e4  vfmadd231pd xmm12, xmm1, xmm14
000074ad747d29e9  vcmppd xmm13, xmm12, xmm12, 0x03
000074ad747d29ef  vptest xmm13, xmm13
000074ad747d29f4  jnz 0x000074AD747D38A0
000074ad747d29fa  vmovaps xmm1, [rsp+0x100]
000074ad747d2a03  vmovaps xmm15, [rsp+0x100]
000074ad747d2a0c  por xmm1, xmm15
000074ad747d2a11  movaps [r15+0x210], xmm1
000074ad747d2a19  vmovaps xmm15, [rsp+0x60]
000074ad747d2a1f  vmovaps xmm14, [rsp+0x60]
000074ad747d2a25  por xmm15, xmm14
000074ad747d2a2a  movaps [r15+0x1C0], xmm15
000074ad747d2a32  vmovaps [rsp+0x60], xmm11
000074ad747d2a38  vmovaps xmm14, [rsp+0x60]
000074ad747d2a3e  por xmm11, xmm14
000074ad747d2a43  movaps [r15+0x280], xmm11
000074ad747d2a4b  vmovaps [rsp+0x60], xmm6
000074ad747d2a51  vmovaps xmm14, [rsp+0x60]
000074ad747d2a57  por xmm6, xmm14
000074ad747d2a5c  movaps [r15+0x2A0], xmm6
000074ad747d2a64  vmovaps xmm14, [rsp+0x20]
000074ad747d2a6a  vmovaps xmm13, [rsp+0x20]
000074ad747d2a70  por xmm14, xmm13
000074ad747d2a75  movaps [r15+0x2E0], xmm14
000074ad747d2a7d  vmovaps xmm13, [rsp+0x10]
000074ad747d2a83  vmovaps [rsp+0x20], xmm1
000074ad747d2a89  vmovaps xmm1, [rsp+0x10]
000074ad747d2a8f  por xmm13, xmm1
000074ad747d2a94  movaps [r15+0x1F0], xmm13
000074ad747d2a9c  vmovaps xmm1, [rsp+0xF0]
000074ad747d2aa5  vmovaps [rsp+0x10], xmm15
000074ad747d2aab  vmovaps xmm15, [rsp+0xF0]
000074ad747d2ab4  por xmm1, xmm15
000074ad747d2ab9  movaps [r15+0x250], xmm1
000074ad747d2ac1  vmovaps xmm1, [rsp+0xE0]
000074ad747d2aca  vmovaps xmm15, [rsp+0xE0]
000074ad747d2ad3  por xmm1, xmm15
000074ad747d2ad8  movaps [r15+0x260], xmm1
000074ad747d2ae0  vmovaps [rsp+0x60], xmm8
000074ad747d2ae6  vmovaps xmm15, [rsp+0x60]
000074ad747d2aec  por xmm8, xmm15
000074ad747d2af1  movaps [r15+0x290], xmm8
000074ad747d2af9  vmovaps [rsp+0x60], xmm10
000074ad747d2aff  vmovaps xmm15, [rsp+0x60]
000074ad747d2b05  por xmm10, xmm15
000074ad747d2b0a  movaps [r15+0x2C0], xmm10
000074ad747d2b12  movq xmm15, qword ptr [r15+0x240]
000074ad747d2b1b  vmovaps [rsp+0x60], xmm15
000074ad747d2b21  vpermilpd xmm15, xmm15, 0x00
000074ad747d2b27  vmovaps [rsp+0xE0], xmm1
000074ad747d2b30  vmovaps xmm1, [rsp+0x50]
000074ad747d2b36  vmovaps [rsp+0x50], xmm15
000074ad747d2b3c  vmovaps xmm15, [rsp+0x20]
000074ad747d2b42  vmovaps [rsp+0x20], xmm14
000074ad747d2b48  vmovaps xmm14, [rsp+0x50]
000074ad747d2b4e  vmovaps [rsp+0x50], xmm13
000074ad747d2b54  vmovaps [rsp+0xF0], xmm12
000074ad747d2b5d  movaps xmm13, xmm1
000074ad747d2b61  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d2b66  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d2b6c  vptest xmm12, xmm12
000074ad747d2b71  jnz 0x000074AD747D39F9
000074ad747d2b77  vmovaps xmm1, [rsp+0x60]
000074ad747d2b7d  vpermilpd xmm1, xmm1, 0x00
000074ad747d2b83  vmovaps xmm15, [rsp+0x110]
000074ad747d2b8c  vmovaps xmm14, [rsp+0x20]
000074ad747d2b92  vmovaps [rsp+0x20], xmm13
000074ad747d2b98  movaps xmm12, xmm15
000074ad747d2b9c  vfmadd231pd xmm12, xmm14, xmm1
000074ad747d2ba1  vcmppd xmm13, xmm12, xmm12, 0x03
000074ad747d2ba7  vptest xmm13, xmm13
000074ad747d2bac  jnz 0x000074AD747D3B52
000074ad747d2bb2  vmovaps xmm1, [rsp+0x60]
000074ad747d2bb8  vpermilpd xmm1, xmm1, 0x00
000074ad747d2bbe  vmovaps xmm15, [rsp+0x30]
000074ad747d2bc4  vmovaps xmm14, [rsp+0x10]
000074ad747d2bca  vmovaps [rsp+0x10], xmm12
000074ad747d2bd0  movaps xmm13, xmm15
000074ad747d2bd4  vfmadd231pd xmm13, xmm14, xmm1
000074ad747d2bd9  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d2bdf  vptest xmm12, xmm12
000074ad747d2be4  jnz 0x000074AD747D3CAB
000074ad747d2bea  vmovaps [rsp+0x30], xmm5
000074ad747d2bf0  vmovaps xmm1, [rsp+0x30]
000074ad747d2bf6  por xmm5, xmm1
000074ad747d2bfa  movaps [r15+0x1D0], xmm5
000074ad747d2c02  vmovaps xmm1, [rsp+0x60]
000074ad747d2c08  vpermilpd xmm1, xmm1, 0x00
000074ad747d2c0e  vmovaps xmm15, [rsp+0xF0]
000074ad747d2c17  vmovaps xmm14, [rsp+0x50]
000074ad747d2c1d  vmovaps [rsp+0x30], xmm13
000074ad747d2c23  movaps xmm12, xmm15
000074ad747d2c27  vfmadd231pd xmm12, xmm14, xmm1
000074ad747d2c2c  vcmppd xmm13, xmm12, xmm12, 0x03
000074ad747d2c32  vptest xmm13, xmm13
000074ad747d2c37  jnz 0x000074AD747D3E04
000074ad747d2c3d  vmovaps xmm1, [rsp+0x80]
000074ad747d2c46  vmovaps xmm15, [rsp+0x80]
000074ad747d2c4f  por xmm1, xmm15
000074ad747d2c54  movaps [r15+0x200], xmm1
000074ad747d2c5c  vmovaps xmm15, [rsp+0x120]
000074ad747d2c65  vmovaps xmm14, [rsp+0x120]
000074ad747d2c6e  por xmm15, xmm14
000074ad747d2c73  movaps [r15+0x1E0], xmm15
000074ad747d2c7b  vmovaps [rsp+0x50], xmm4
000074ad747d2c81  vmovaps xmm13, [rsp+0x50]
000074ad747d2c87  por xmm4, xmm13
000074ad747d2c8c  movaps [r15+0x2B0], xmm4
000074ad747d2c94  vmovaps [rsp+0x50], xmm3
000074ad747d2c9a  vmovaps xmm13, [rsp+0x50]
000074ad747d2ca0  por xmm3, xmm13
000074ad747d2ca5  movaps [r15+0x300], xmm3
000074ad747d2cad  vmovaps xmm15, [rsp+0xB0]
000074ad747d2cb6  vpermilpd xmm15, xmm15, 0x00
000074ad747d2cbc  vmovaps xmm3, [rsp+0x20]
000074ad747d2cc2  vmovaps [rsp+0x20], xmm1
000074ad747d2cc8  vmovaps xmm1, [rsp+0xE0]
000074ad747d2cd1  vmovaps [rsp+0x50], xmm14
000074ad747d2cd7  vmovaps [rsp+0x60], xmm13
000074ad747d2cdd  movaps xmm14, xmm3
000074ad747d2ce1  vfmadd231pd xmm14, xmm1, xmm15
000074ad747d2ce6  vcmppd xmm13, xmm14, xmm14, 0x03
000074ad747d2cec  vptest xmm13, xmm13
000074ad747d2cf1  jnz 0x000074AD747D3F5D
000074ad747d2cf7  vmovaps xmm1, [rsp+0xB0]
000074ad747d2d00  vpermilpd xmm1, xmm1, 0x00
000074ad747d2d06  vmovaps xmm15, [rsp+0x10]
000074ad747d2d0c  movaps xmm13, xmm15
000074ad747d2d10  vfmadd231pd xmm13, xmm10, xmm1
000074ad747d2d15  vcmppd xmm3, xmm13, xmm13, 0x03
000074ad747d2d1b  vptest xmm3, xmm3
000074ad747d2d20  jnz 0x000074AD747D40B5
000074ad747d2d26  vmovaps xmm1, [rsp+0xB0]
000074ad747d2d2f  vpermilpd xmm1, xmm1, 0x00
000074ad747d2d35  vmovaps xmm15, [rsp+0x30]
000074ad747d2d3b  movaps xmm10, xmm15
000074ad747d2d3f  vfmadd231pd xmm10, xmm11, xmm1
000074ad747d2d44  vcmppd xmm3, xmm10, xmm10, 0x03
000074ad747d2d4a  vptest xmm3, xmm3
000074ad747d2d4f  jnz 0x000074AD747D420E
000074ad747d2d55  vmovaps xmm1, [rsp+0xB0]
000074ad747d2d5e  vpermilpd xmm1, xmm1, 0x00
000074ad747d2d64  movaps xmm15, xmm12
000074ad747d2d68  vfmadd231pd xmm15, xmm5, xmm1
000074ad747d2d6d  vcmppd xmm11, xmm15, xmm15, 0x03
000074ad747d2d73  vptest xmm11, xmm11
000074ad747d2d78  jnz 0x000074AD747D4367
000074ad747d2d7e  vmovaps [rsp+0x10], xmm9
000074ad747d2d84  vmovaps xmm1, [rsp+0x10]
000074ad747d2d8a  por xmm9, xmm1
000074ad747d2d8f  movaps [r15+0x180], xmm9
000074ad747d2d97  vmovaps [rsp+0x10], xmm2
000074ad747d2d9d  vmovaps xmm1, [rsp+0x10]
000074ad747d2da3  por xmm2, xmm1
000074ad747d2da7  movaps [r15+0x2D0], xmm2
000074ad747d2daf  vmovaps xmm12, [rsp+0xD0]
000074ad747d2db8  vpermilpd xmm12, xmm12, 0x00
000074ad747d2dbe  vmovaps xmm11, [rsp+0x60]
000074ad747d2dc4  movaps xmm5, xmm13
000074ad747d2dc8  vfmadd231pd xmm5, xmm11, xmm12
000074ad747d2dcd  vcmppd xmm3, xmm5, xmm5, 0x03
000074ad747d2dd2  vptest xmm3, xmm3
000074ad747d2dd7  jnz 0x000074AD747D44BF
000074ad747d2ddd  vmovaps xmm13, [rsp+0xD0]
000074ad747d2de6  vpermilpd xmm13, xmm13, 0x00
000074ad747d2dec  movaps xmm12, xmm14
000074ad747d2df0  vfmadd231pd xmm12, xmm9, xmm13
000074ad747d2df5  vcmppd xmm11, xmm12, xmm12, 0x03
000074ad747d2dfb  vptest xmm11, xmm11
000074ad747d2e00  jnz 0x000074AD747D4617
000074ad747d2e06  lea rax, [r14+0x80]
000074ad747d2e0d  movups xmm14, [r13+rax*1]
000074ad747d2e13  movaps [r15+0x2F0], xmm14
000074ad747d2e1b  vmovaps xmm13, [rsp+0xD0]
000074ad747d2e24  vpermilpd xmm13, xmm13, 0x00
000074ad747d2e2a  movaps xmm11, xmm10
000074ad747d2e2e  vfmadd231pd xmm11, xmm8, xmm13
000074ad747d2e33  vcmppd xmm9, xmm11, xmm11, 0x03
000074ad747d2e39  vptest xmm9, xmm9
000074ad747d2e3e  jnz 0x000074AD747D477B
000074ad747d2e44  vmovaps xmm13, [rsp+0xD0]
000074ad747d2e4d  vpermilpd xmm13, xmm13, 0x00
000074ad747d2e53  movaps xmm10, xmm15
000074ad747d2e57  vfmadd231pd xmm10, xmm1, xmm13
000074ad747d2e5c  vcmppd xmm9, xmm10, xmm10, 0x03
000074ad747d2e62  vptest xmm9, xmm9
000074ad747d2e67  jnz 0x000074AD747D48D5
000074ad747d2e6d  vmovaps [rsp+0x10], xmm7
000074ad747d2e73  vmovaps xmm1, [rsp+0x10]
000074ad747d2e79  por xmm7, xmm1
000074ad747d2e7d  movaps [r15+0x160], xmm7
000074ad747d2e85  lea rax, [r14+0x40]
000074ad747d2e89  movups xmm1, [r13+rax*1]
000074ad747d2e8f  lea rax, [r14+0x50]
000074ad747d2e93  movups xmm15, [r13+rax*1]
000074ad747d2e99  movaps [r15+0x1B0], xmm1
000074ad747d2ea1  movaps [r15+0x1A0], xmm15
000074ad747d2ea9  vmovaps xmm13, [rsp+0xA0]
000074ad747d2eb2  vpermilpd xmm13, xmm13, 0x00
000074ad747d2eb8  vmovaps xmm9, [rsp+0x40]
000074ad747d2ebe  movaps xmm8, xmm5
000074ad747d2ec2  vfmadd231pd xmm8, xmm9, xmm13
000074ad747d2ec7  vcmppd xmm3, xmm8, xmm8, 0x03
000074ad747d2ecd  vptest xmm3, xmm3
000074ad747d2ed2  jnz 0x000074AD747D4A42
000074ad747d2ed8  vmovaps xmm13, [rsp+0xA0]
000074ad747d2ee1  vpermilpd xmm13, xmm13, 0x00
000074ad747d2ee7  movaps xmm9, xmm12
000074ad747d2eeb  vfmadd231pd xmm9, xmm7, xmm13
000074ad747d2ef0  vcmppd xmm5, xmm9, xmm9, 0x03
000074ad747d2ef6  vptest xmm5, xmm5
000074ad747d2efb  jnz 0x000074AD747D4B9B
000074ad747d2f01  vmovaps xmm13, [rsp+0xA0]
000074ad747d2f0a  vpermilpd xmm13, xmm13, 0x00
000074ad747d2f10  movaps xmm12, xmm11
000074ad747d2f14  vfmadd231pd xmm12, xmm6, xmm13
000074ad747d2f19  vcmppd xmm7, xmm12, xmm12, 0x03
000074ad747d2f1f  vptest xmm7, xmm7
000074ad747d2f24  jnz 0x000074AD747D4CF4
000074ad747d2f2a  vmovaps xmm13, [rsp+0xA0]
000074ad747d2f33  vpermilpd xmm13, xmm13, 0x00
000074ad747d2f39  vmovaps xmm11, [rsp+0x50]
000074ad747d2f3f  movaps xmm7, xmm10
000074ad747d2f43  vfmadd231pd xmm7, xmm11, xmm13
000074ad747d2f48  vcmppd xmm6, xmm7, xmm7, 0x03
000074ad747d2f4d  vptest xmm6, xmm6
000074ad747d2f52  jnz 0x000074AD747D4E4D
000074ad747d2f58  lea rax, [r14+0x60]
000074ad747d2f5c  movups xmm13, [r13+rax*1]
000074ad747d2f62  lea rax, [r14+0x70]
000074ad747d2f66  movups xmm11, [r13+rax*1]
000074ad747d2f6c  movaps [r15+0x150], xmm13
000074ad747d2f74  movaps [r15+0x120], xmm11
000074ad747d2f7c  vmovaps xmm10, [rsp+0xC0]
000074ad747d2f85  vpermilpd xmm10, xmm10, 0x00
000074ad747d2f8b  movaps xmm6, xmm8
000074ad747d2f8f  vfmadd231pd xmm6, xmm15, xmm10
000074ad747d2f94  vcmppd xmm5, xmm6, xmm6, 0x03
000074ad747d2f99  vptest xmm5, xmm5
000074ad747d2f9e  jnz 0x000074AD747D4FB9
000074ad747d2fa4  vmovaps xmm15, [rsp+0xC0]
000074ad747d2fad  vpermilpd xmm15, xmm15, 0x00
000074ad747d2fb3  movaps xmm10, xmm9
000074ad747d2fb7  vfmadd231pd xmm10, xmm13, xmm15
000074ad747d2fbc  vcmppd xmm8, xmm10, xmm10, 0x03
000074ad747d2fc2  vptest xmm8, xmm8
000074ad747d2fc7  jnz 0x000074AD747D5111
000074ad747d2fcd  vmovaps xmm15, [rsp+0xC0]
000074ad747d2fd6  vpermilpd xmm15, xmm15, 0x00
000074ad747d2fdc  movaps xmm13, xmm12
000074ad747d2fe0  vfmadd231pd xmm13, xmm4, xmm15
000074ad747d2fe5  vcmppd xmm9, xmm13, xmm13, 0x03
000074ad747d2feb  vptest xmm9, xmm9
000074ad747d2ff0  jnz 0x000074AD747D526B
000074ad747d2ff6  vmovaps xmm15, [rsp+0xC0]
000074ad747d2fff  vpermilpd xmm15, xmm15, 0x00
000074ad747d3005  movaps xmm12, xmm7
000074ad747d3009  vfmadd231pd xmm12, xmm1, xmm15
000074ad747d300e  vcmppd xmm9, xmm12, xmm12, 0x03
000074ad747d3014  vptest xmm9, xmm9
000074ad747d3019  jnz 0x000074AD747D53C4
000074ad747d301f  lea rax, [r14+0x20]
000074ad747d3023  movups xmm1, [r13+rax*1]
000074ad747d3029  lea rax, [r14+0x30]
000074ad747d302d  movups xmm15, [r13+rax*1]
000074ad747d3033  vmovaps xmm9, [rsp+0x70]
000074ad747d3039  vpermilpd xmm9, xmm9, 0x00
000074ad747d303f  vmovaps xmm8, [rsp+0x20]
000074ad747d3045  movaps xmm7, xmm6
000074ad747d3048  vfmadd231pd xmm7, xmm8, xmm9
000074ad747d304d  vcmppd xmm5, xmm7, xmm7, 0x03
000074ad747d3052  vptest xmm5, xmm5
000074ad747d3057  jnz 0x000074AD747D5530
000074ad747d305d  vmovaps xmm9, [rsp+0x70]
000074ad747d3063  vpermilpd xmm9, xmm9, 0x00
000074ad747d3069  movaps xmm8, xmm10
000074ad747d306d  vfmadd231pd xmm8, xmm14, xmm9
000074ad747d3072  vcmppd xmm6, xmm8, xmm8, 0x03
000074ad747d3078  vptest xmm6, xmm6
000074ad747d307d  jnz 0x000074AD747D5687
000074ad747d3083  vmovaps xmm14, [rsp+0x70]
000074ad747d3089  vpermilpd xmm14, xmm14, 0x00
000074ad747d308f  movaps xmm10, xmm13
000074ad747d3093  vfmadd231pd xmm10, xmm11, xmm14
000074ad747d3098  vcmppd xmm9, xmm10, xmm10, 0x03
000074ad747d309e  vptest xmm9, xmm9
000074ad747d30a3  jnz 0x000074AD747D57E1
000074ad747d30a9  vmovaps xmm14, [rsp+0x70]
000074ad747d30af  vpermilpd xmm14, xmm14, 0x00
000074ad747d30b5  movaps xmm13, xmm12
000074ad747d30b9  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d30be  vcmppd xmm11, xmm13, xmm13, 0x03
000074ad747d30c4  vptest xmm11, xmm11
000074ad747d30c9  jnz 0x000074AD747D593B
000074ad747d30cf  lea rax, [r14+0x90]
000074ad747d30d6  movups xmm15, [r13+rax*1]
000074ad747d30dc  lea rax, [r14+0xA0]
000074ad747d30e3  movups xmm14, [r13+rax*1]
000074ad747d30e9  movaps [r15+0x140], xmm15
000074ad747d30f1  movaps [r15+0x130], xmm14
000074ad747d30f9  vmovaps xmm12, [rsp+0x90]
000074ad747d3102  vpermilpd xmm12, xmm12, 0x00
000074ad747d3108  movaps xmm11, xmm7
000074ad747d310c  vfmadd231pd xmm11, xmm1, xmm12
000074ad747d3111  vcmppd xmm9, xmm11, xmm11, 0x03
000074ad747d3117  vptest xmm9, xmm9
000074ad747d311c  jnz 0x000074AD747D5AA9
000074ad747d3122  movaps [r15+0x220], xmm11
000074ad747d312a  lea rax, [r14+0x10]
000074ad747d312e  movups xmm1, [r13+rax*1]
000074ad747d3134  movaps [r15+0x240], xmm1
000074ad747d313c  vmovaps xmm12, [rsp+0x90]
000074ad747d3145  vpermilpd xmm12, xmm12, 0x00
000074ad747d314b  movaps xmm9, xmm8
000074ad747d314f  vfmadd231pd xmm9, xmm14, xmm12
000074ad747d3154  vcmppd xmm7, xmm9, xmm9, 0x03
000074ad747d315a  vptest xmm7, xmm7
000074ad747d315f  jnz 0x000074AD747D5C0B
000074ad747d3165  movaps [r15+0x110], xmm9
000074ad747d316d  vmovaps xmm14, [rsp+0x90]
000074ad747d3176  vpermilpd xmm14, xmm14, 0x00
000074ad747d317c  movaps xmm12, xmm10
000074ad747d3180  vfmadd231pd xmm12, xmm15, xmm14
000074ad747d3185  vcmppd xmm8, xmm12, xmm12, 0x03
000074ad747d318b  vptest xmm8, xmm8
000074ad747d3190  jnz 0x000074AD747D5D65
000074ad747d3196  movaps [r15+0x170], xmm12
000074ad747d319e  vmovaps xmm15, [rsp+0x90]
000074ad747d31a7  vpermilpd xmm15, xmm15, 0x00
000074ad747d31ad  movaps xmm14, xmm13
000074ad747d31b1  vfmadd231pd xmm14, xmm1, xmm15
000074ad747d31b6  vcmppd xmm10, xmm14, xmm14, 0x03
000074ad747d31bc  vptest xmm10, xmm10
000074ad747d31c1  jnz 0x000074AD747D5EBF
000074ad747d31c7  movaps [r15+0x230], xmm14
000074ad747d31cf  mov eax, 0x432190
000074ad747d31d4  movups [r13+rax*1], xmm9
000074ad747d31da  mov eax, 0x4321A0
000074ad747d31df  movups [r13+rax*1], xmm12
000074ad747d31e5  mov eax, 0x4321B0
000074ad747d31ea  movups [r13+rax*1], xmm11
000074ad747d31f0  mov eax, 0x4321C0
000074ad747d31f5  movups [r13+rax*1], xmm14
000074ad747d31fb  mov eax, [r15+0x108]
000074ad747d3202  sahf
000074ad747d3203  jnz 0x000074AD747D3235
000074ad747d3205  cmp dword ptr [r15+0x318], 0x00
000074ad747d320d  jz 0x000074AD747D9950
000074ad747d3213  nop [rax+rax*1], ax
000074ad747d321c  nop [rax+rax*1], eax
000074ad747d3224  mov eax, 0x410664
000074ad747d3229  mov [r15+0x100], rax
000074ad747d3230  jmp 0x000074AD745FE110
000074ad747d3235  cmp dword ptr [r15+0x318], 0x00
000074ad747d323d  jz 0x000074AD747D6050
000074ad747d3243  nop [rax+rax*1], ax
000074ad747d324c  nop [rax+rax*1], eax
000074ad747d3254  mov eax, 0x4104F0
000074ad747d3259  mov [r15+0x100], rax
000074ad747d3260  jmp 0x000074AD745FE110
000074ad747d3265  int3
000074ad747d3266  call 0x000074AD745FF430
000074ad747d326b  jmp 0x000074AD747D230A
000074ad747d3270  call 0x000074AD746E5820
000074ad747d3275  jmp 0x000074AD747D2314
000074ad747d327a  call 0x000074AD746E45A0
000074ad747d327f  jmp 0x000074AD747D2326
000074ad747d3284  call 0x000074AD746E3320
000074ad747d3289  jmp 0x000074AD747D2330
000074ad747d328e  call 0x000074AD746E20A0
000074ad747d3293  jmp 0x000074AD747D233D
000074ad747d3298  call 0x000074AD746E0E30
000074ad747d329d  jmp 0x000074AD747D234A
000074ad747d32a2  call 0x000074AD746D6600
000074ad747d32a7  jmp 0x000074AD747D2357
000074ad747d32ac  call 0x000074AD746B52F0
000074ad747d32b1  jmp 0x000074AD747D2361
000074ad747d32b6  call 0x000074AD746BE9C0
000074ad747d32bb  jmp 0x000074AD747D236B
000074ad747d32c0  call 0x000074AD746BD750
000074ad747d32c5  jmp 0x000074AD747D2378
000074ad747d32ca  call 0x000074AD746BC4E0
000074ad747d32cf  jmp 0x000074AD747D2385
000074ad747d32d4  call 0x000074AD746BB270
000074ad747d32d9  jmp 0x000074AD747D2392
000074ad747d32de  call 0x000074AD746BA000
000074ad747d32e3  jmp 0x000074AD747D239F
000074ad747d32e8  call 0x000074AD746B8D90
000074ad747d32ed  jmp 0x000074AD747D23AC
000074ad747d32f2  call 0x000074AD746B8A20
000074ad747d32f7  jmp 0x000074AD747D23B9
000074ad747d32fc  call 0x000074AD746BEAE0
000074ad747d3301  jmp 0x000074AD747D23C6
000074ad747d3306  call 0x000074AD746B5400
000074ad747d330b  jmp 0x000074AD747D23D3
000074ad747d3310  call 0x000074AD746B52F0
000074ad747d3315  jmp 0x000074AD747D23E0
000074ad747d331a  call 0x000074AD746BE9C0
000074ad747d331f  jmp 0x000074AD747D23ED
000074ad747d3324  call 0x000074AD746B77B0
000074ad747d3329  jmp 0x000074AD747D23FA
000074ad747d332e  call 0x000074AD746B6550
000074ad747d3333  jmp 0x000074AD747D2407
000074ad747d3338  call 0x000074AD746B52F0
000074ad747d333d  jmp 0x000074AD747D2417
000074ad747d3342  call 0x000074AD746B52F0
000074ad747d3347  jmp 0x000074AD747D2427
000074ad747d334c  call 0x000074AD746BEAE0
000074ad747d3351  jmp 0x000074AD747D2431
000074ad747d3356  call 0x000074AD746BEAE0
000074ad747d335b  jmp 0x000074AD747D2444
000074ad747d3360  call 0x000074AD746BE9C0
000074ad747d3365  jmp 0x000074AD747D2451
000074ad747d336a  call 0x000074AD746B52F0
000074ad747d336f  jmp 0x000074AD747D2464
000074ad747d3374  call 0x000074AD746B6660
000074ad747d3379  jmp 0x000074AD747D2471
000074ad747d337e  call 0x000074AD746B78C0
000074ad747d3383  jmp 0x000074AD747D247E
000074ad747d3388  call 0x000074AD746B77B0
000074ad747d338d  jmp 0x000074AD747D248B
000074ad747d3392  call 0x000074AD746B6550
000074ad747d3397  jmp 0x000074AD747D2498
000074ad747d339c  call 0x000074AD746B52F0
000074ad747d33a1  jmp 0x000074AD747D24AB
000074ad747d33a6  call 0x000074AD746B52F0
000074ad747d33ab  jmp 0x000074AD747D24BE
000074ad747d33b0  call 0x000074AD746B52F0
000074ad747d33b5  jmp 0x000074AD747D24E5
000074ad747d33ba  call 0x000074AD746B52F0
000074ad747d33bf  jmp 0x000074AD747D24F8
000074ad747d33c4  call 0x000074AD746B52F0
000074ad747d33c9  jmp 0x000074AD747D250B
000074ad747d33ce  call 0x000074AD746B52F0
000074ad747d33d3  jmp 0x000074AD747D2521
000074ad747d33d8  call 0x000074AD746B52F0
000074ad747d33dd  jmp 0x000074AD747D2537
000074ad747d33e2  call 0x000074AD746B52F0
000074ad747d33e7  jmp 0x000074AD747D254D
000074ad747d33ec  call 0x000074AD745FF540
000074ad747d33f1  jmp 0x000074AD747D256E
000074ad747d33f6  call 0x000074AD74602FE0
000074ad747d33fb  jmp 0x000074AD747D2578
000074ad747d3400  call 0x000074AD745FF540
000074ad747d3405  jmp 0x000074AD747D2588
000074ad747d340a  call 0x000074AD745FF540
000074ad747d340f  jmp 0x000074AD747D259B
000074ad747d3414  call 0x000074AD745FF540
000074ad747d3419  jmp 0x000074AD747D25AE
000074ad747d341e  call 0x000074AD745FF540
000074ad747d3423  jmp 0x000074AD747D25C1
000074ad747d3428  call 0x000074AD746C0370
000074ad747d342d  jmp 0x000074AD747D25E0
000074ad747d3432  call 0x000074AD746BF100
000074ad747d3437  jmp 0x000074AD747D25E9
000074ad747d343c  call 0x000074AD746C0370
000074ad747d3441  jmp 0x000074AD747D2659
000074ad747d3446  call 0x000074AD746BF100
000074ad747d344b  jmp 0x000074AD747D2662
000074ad747d3450  call 0x000074AD746C0370
000074ad747d3455  jmp 0x000074AD747D270C
000074ad747d345a  call 0x000074AD746BF100
000074ad747d345f  jmp 0x000074AD747D2715
000074ad747d3464  call 0x000074AD7460B720
000074ad747d3469  jmp 0x000074AD747D27F7
000074ad747d346e  call 0x000074AD746D64F0
000074ad747d3473  jmp 0x000074AD747D281F
000074ad747d3478  call 0x000074AD746B47C0
000074ad747d347d  jmp 0x000074AD747D283A
000074ad747d3482  sub rsp, 0x08
000074ad747d3486  push rax
000074ad747d3487  push rcx
000074ad747d3488  push rdx
000074ad747d3489  push rdi
000074ad747d348a  push rsi
000074ad747d348b  push r8
000074ad747d348d  push r9
000074ad747d348f  push r10
000074ad747d3491  push r11
000074ad747d3493  sub rsp, 0xF0
000074ad747d349a  vmovaps [rsp], xmm0
000074ad747d349f  vmovaps [rsp+0x10], xmm1
000074ad747d34a5  vmovaps [rsp+0x20], xmm2
000074ad747d34ab  vmovaps [rsp+0x30], xmm3
000074ad747d34b1  vmovaps [rsp+0x40], xmm4
000074ad747d34b7  vmovaps [rsp+0x50], xmm5
000074ad747d34bd  vmovaps [rsp+0x60], xmm6
000074ad747d34c3  vmovaps [rsp+0x70], xmm7
000074ad747d34c9  vmovaps [rsp+0x80], xmm8
000074ad747d34d2  vmovaps [rsp+0x90], xmm9
000074ad747d34db  vmovaps [rsp+0xA0], xmm10
000074ad747d34e4  vmovaps [rsp+0xB0], xmm11
000074ad747d34ed  vmovaps [rsp+0xC0], xmm12
000074ad747d34f6  vmovaps [rsp+0xD0], xmm14
000074ad747d34ff  vmovaps [rsp+0xE0], xmm15
000074ad747d3508  sub rsp, 0x40
000074ad747d350c  lea rdi, [rsp]
000074ad747d3510  lea rsi, [rsp+0x10]
000074ad747d3515  lea rdx, [rsp+0x20]
000074ad747d351a  lea rcx, [rsp+0x30]
000074ad747d351f  mov r8d, 0x00
000074ad747d3525  lea r9, [r15+0x3A8]
000074ad747d352c  movaps [rdi], xmm13
000074ad747d3530  movaps [rsi], xmm1
000074ad747d3533  movaps [rdx], xmm15
000074ad747d3537  movaps [rcx], xmm14
000074ad747d353b  mov rax, 0x5C17501CEA50
000074ad747d3545  call rax
000074ad747d3547  movaps xmm13, [rsp]
000074ad747d354c  add rsp, 0x40
000074ad747d3550  vmovaps xmm0, [rsp]
000074ad747d3555  vmovaps xmm1, [rsp+0x10]
000074ad747d355b  vmovaps xmm2, [rsp+0x20]
000074ad747d3561  vmovaps xmm3, [rsp+0x30]
000074ad747d3567  vmovaps xmm4, [rsp+0x40]
000074ad747d356d  vmovaps xmm5, [rsp+0x50]
000074ad747d3573  vmovaps xmm6, [rsp+0x60]
000074ad747d3579  vmovaps xmm7, [rsp+0x70]
000074ad747d357f  vmovaps xmm8, [rsp+0x80]
000074ad747d3588  vmovaps xmm9, [rsp+0x90]
000074ad747d3591  vmovaps xmm10, [rsp+0xA0]
000074ad747d359a  vmovaps xmm11, [rsp+0xB0]
000074ad747d35a3  vmovaps xmm12, [rsp+0xC0]
000074ad747d35ac  vmovaps xmm14, [rsp+0xD0]
000074ad747d35b5  vmovaps xmm15, [rsp+0xE0]
000074ad747d35be  add rsp, 0xF0
000074ad747d35c5  pop r11
000074ad747d35c7  pop r10
000074ad747d35c9  pop r9
000074ad747d35cb  pop r8
000074ad747d35cd  pop rsi
000074ad747d35ce  pop rdi
000074ad747d35cf  pop rdx
000074ad747d35d0  pop rcx
000074ad747d35d1  pop rax
000074ad747d35d2  add rsp, 0x08
000074ad747d35d6  jmp 0x000074AD747D28AD
000074ad747d35db  sub rsp, 0x08
000074ad747d35df  push rax
000074ad747d35e0  push rcx
000074ad747d35e1  push rdx
000074ad747d35e2  push rdi
000074ad747d35e3  push rsi
000074ad747d35e4  push r8
000074ad747d35e6  push r9
000074ad747d35e8  push r10
000074ad747d35ea  push r11
000074ad747d35ec  sub rsp, 0xF0
000074ad747d35f3  vmovaps [rsp], xmm0
000074ad747d35f8  vmovaps [rsp+0x10], xmm1
000074ad747d35fe  vmovaps [rsp+0x20], xmm2
000074ad747d3604  vmovaps [rsp+0x30], xmm3
000074ad747d360a  vmovaps [rsp+0x40], xmm4
000074ad747d3610  vmovaps [rsp+0x50], xmm5
000074ad747d3616  vmovaps [rsp+0x60], xmm6
000074ad747d361c  vmovaps [rsp+0x70], xmm7
000074ad747d3622  vmovaps [rsp+0x80], xmm8
000074ad747d362b  vmovaps [rsp+0x90], xmm9
000074ad747d3634  vmovaps [rsp+0xA0], xmm10
000074ad747d363d  vmovaps [rsp+0xB0], xmm11
000074ad747d3646  vmovaps [rsp+0xC0], xmm12
000074ad747d364f  vmovaps [rsp+0xD0], xmm13
000074ad747d3658  vmovaps [rsp+0xE0], xmm14
000074ad747d3661  sub rsp, 0x40
000074ad747d3665  lea rdi, [rsp]
000074ad747d3669  lea rsi, [rsp+0x10]
000074ad747d366e  lea rdx, [rsp+0x20]
000074ad747d3673  lea rcx, [rsp+0x30]
000074ad747d3678  mov r8d, 0x00
000074ad747d367e  lea r9, [r15+0x3A8]
000074ad747d3685  movaps [rdi], xmm15
000074ad747d3689  movaps [rsi], xmm5
000074ad747d368c  movaps [rdx], xmm1
000074ad747d368f  movaps [rcx], xmm14
000074ad747d3693  mov rax, 0x5C17501CEA50
000074ad747d369d  call rax
000074ad747d369f  movaps xmm15, [rsp]
000074ad747d36a4  add rsp, 0x40
000074ad747d36a8  vmovaps xmm0, [rsp]
000074ad747d36ad  vmovaps xmm1, [rsp+0x10]
000074ad747d36b3  vmovaps xmm2, [rsp+0x20]
000074ad747d36b9  vmovaps xmm3, [rsp+0x30]
000074ad747d36bf  vmovaps xmm4, [rsp+0x40]
000074ad747d36c5  vmovaps xmm5, [rsp+0x50]
000074ad747d36cb  vmovaps xmm6, [rsp+0x60]
000074ad747d36d1  vmovaps xmm7, [rsp+0x70]
000074ad747d36d7  vmovaps xmm8, [rsp+0x80]
000074ad747d36e0  vmovaps xmm9, [rsp+0x90]
000074ad747d36e9  vmovaps xmm10, [rsp+0xA0]
000074ad747d36f2  vmovaps xmm11, [rsp+0xB0]
000074ad747d36fb  vmovaps xmm12, [rsp+0xC0]
000074ad747d3704  vmovaps xmm13, [rsp+0xD0]
000074ad747d370d  vmovaps xmm14, [rsp+0xE0]
000074ad747d3716  add rsp, 0xF0
000074ad747d371d  pop r11
000074ad747d371f  pop r10
000074ad747d3721  pop r9
000074ad747d3723  pop r8
000074ad747d3725  pop rsi
000074ad747d3726  pop rdi
000074ad747d3727  pop rdx
000074ad747d3728  pop rcx
000074ad747d3729  pop rax
000074ad747d372a  add rsp, 0x08
000074ad747d372e  jmp 0x000074AD747D28D0
000074ad747d3733  call 0x000074AD745FF430
000074ad747d3738  jmp 0x000074AD747D295D
000074ad747d373d  sub rsp, 0x08
000074ad747d3741  push rax
000074ad747d3742  push rcx
000074ad747d3743  push rdx
000074ad747d3744  push rdi
000074ad747d3745  push rsi
000074ad747d3746  push r8
000074ad747d3748  push r9
000074ad747d374a  push r10
000074ad747d374c  push r11
000074ad747d374e  sub rsp, 0xF0
000074ad747d3755  vmovaps [rsp], xmm0
000074ad747d375a  vmovaps [rsp+0x10], xmm1
000074ad747d3760  vmovaps [rsp+0x20], xmm2
000074ad747d3766  vmovaps [rsp+0x30], xmm3
000074ad747d376c  vmovaps [rsp+0x40], xmm4
000074ad747d3772  vmovaps [rsp+0x50], xmm5
000074ad747d3778  vmovaps [rsp+0x60], xmm6
000074ad747d377e  vmovaps [rsp+0x70], xmm7
000074ad747d3784  vmovaps [rsp+0x80], xmm8
000074ad747d378d  vmovaps [rsp+0x90], xmm9
000074ad747d3796  vmovaps [rsp+0xA0], xmm10
000074ad747d379f  vmovaps [rsp+0xB0], xmm11
000074ad747d37a8  vmovaps [rsp+0xC0], xmm12
000074ad747d37b1  vmovaps [rsp+0xD0], xmm14
000074ad747d37ba  vmovaps [rsp+0xE0], xmm15
000074ad747d37c3  sub rsp, 0x40
000074ad747d37c7  lea rdi, [rsp]
000074ad747d37cb  lea rsi, [rsp+0x10]
000074ad747d37d0  lea rdx, [rsp+0x20]
000074ad747d37d5  lea rcx, [rsp+0x30]
000074ad747d37da  mov r8d, 0x00
000074ad747d37e0  lea r9, [r15+0x3A8]
000074ad747d37e7  movaps [rdi], xmm13
000074ad747d37eb  movaps [rsi], xmm1
000074ad747d37ee  movaps [rdx], xmm15
000074ad747d37f2  movaps [rcx], xmm14
000074ad747d37f6  mov rax, 0x5C17501CEA50
000074ad747d3800  call rax
000074ad747d3802  movaps xmm13, [rsp]
000074ad747d3807  add rsp, 0x40
000074ad747d380b  vmovaps xmm0, [rsp]
000074ad747d3810  vmovaps xmm1, [rsp+0x10]
000074ad747d3816  vmovaps xmm2, [rsp+0x20]
000074ad747d381c  vmovaps xmm3, [rsp+0x30]
000074ad747d3822  vmovaps xmm4, [rsp+0x40]
000074ad747d3828  vmovaps xmm5, [rsp+0x50]
000074ad747d382e  vmovaps xmm6, [rsp+0x60]
000074ad747d3834  vmovaps xmm7, [rsp+0x70]
000074ad747d383a  vmovaps xmm8, [rsp+0x80]
000074ad747d3843  vmovaps xmm9, [rsp+0x90]
000074ad747d384c  vmovaps xmm10, [rsp+0xA0]
000074ad747d3855  vmovaps xmm11, [rsp+0xB0]
000074ad747d385e  vmovaps xmm12, [rsp+0xC0]
000074ad747d3867  vmovaps xmm14, [rsp+0xD0]
000074ad747d3870  vmovaps xmm15, [rsp+0xE0]
000074ad747d3879  add rsp, 0xF0
000074ad747d3880  pop r11
000074ad747d3882  pop r10
000074ad747d3884  pop r9
000074ad747d3886  pop r8
000074ad747d3888  pop rsi
000074ad747d3889  pop rdi
000074ad747d388a  pop rdx
000074ad747d388b  pop rcx
000074ad747d388c  pop rax
000074ad747d388d  add rsp, 0x08
000074ad747d3891  jmp 0x000074AD747D29C1
000074ad747d3896  call 0x000074AD745FF430
000074ad747d389b  jmp 0x000074AD747D29CE
000074ad747d38a0  sub rsp, 0x08
000074ad747d38a4  push rax
000074ad747d38a5  push rcx
000074ad747d38a6  push rdx
000074ad747d38a7  push rdi
000074ad747d38a8  push rsi
000074ad747d38a9  push r8
000074ad747d38ab  push r9
000074ad747d38ad  push r10
000074ad747d38af  push r11
000074ad747d38b1  sub rsp, 0xF0
000074ad747d38b8  vmovaps [rsp], xmm0
000074ad747d38bd  vmovaps [rsp+0x10], xmm1
000074ad747d38c3  vmovaps [rsp+0x20], xmm2
000074ad747d38c9  vmovaps [rsp+0x30], xmm3
000074ad747d38cf  vmovaps [rsp+0x40], xmm4
000074ad747d38d5  vmovaps [rsp+0x50], xmm5
000074ad747d38db  vmovaps [rsp+0x60], xmm6
000074ad747d38e1  vmovaps [rsp+0x70], xmm7
000074ad747d38e7  vmovaps [rsp+0x80], xmm8
000074ad747d38f0  vmovaps [rsp+0x90], xmm9
000074ad747d38f9  vmovaps [rsp+0xA0], xmm10
000074ad747d3902  vmovaps [rsp+0xB0], xmm11
000074ad747d390b  vmovaps [rsp+0xC0], xmm13
000074ad747d3914  vmovaps [rsp+0xD0], xmm14
000074ad747d391d  vmovaps [rsp+0xE0], xmm15
000074ad747d3926  sub rsp, 0x40
000074ad747d392a  lea rdi, [rsp]
000074ad747d392e  lea rsi, [rsp+0x10]
000074ad747d3933  lea rdx, [rsp+0x20]
000074ad747d3938  lea rcx, [rsp+0x30]
000074ad747d393d  mov r8d, 0x00
000074ad747d3943  lea r9, [r15+0x3A8]
000074ad747d394a  movaps [rdi], xmm12
000074ad747d394e  movaps [rsi], xmm15
000074ad747d3952  movaps [rdx], xmm1
000074ad747d3955  movaps [rcx], xmm14
000074ad747d3959  mov rax, 0x5C17501CEA50
000074ad747d3963  call rax
000074ad747d3965  movaps xmm12, [rsp]
000074ad747d396a  add rsp, 0x40
000074ad747d396e  vmovaps xmm0, [rsp]
000074ad747d3973  vmovaps xmm1, [rsp+0x10]
000074ad747d3979  vmovaps xmm2, [rsp+0x20]
000074ad747d397f  vmovaps xmm3, [rsp+0x30]
000074ad747d3985  vmovaps xmm4, [rsp+0x40]
000074ad747d398b  vmovaps xmm5, [rsp+0x50]
000074ad747d3991  vmovaps xmm6, [rsp+0x60]
000074ad747d3997  vmovaps xmm7, [rsp+0x70]
000074ad747d399d  vmovaps xmm8, [rsp+0x80]
000074ad747d39a6  vmovaps xmm9, [rsp+0x90]
000074ad747d39af  vmovaps xmm10, [rsp+0xA0]
000074ad747d39b8  vmovaps xmm11, [rsp+0xB0]
000074ad747d39c1  vmovaps xmm13, [rsp+0xC0]
000074ad747d39ca  vmovaps xmm14, [rsp+0xD0]
000074ad747d39d3  vmovaps xmm15, [rsp+0xE0]
000074ad747d39dc  add rsp, 0xF0
000074ad747d39e3  pop r11
000074ad747d39e5  pop r10
000074ad747d39e7  pop r9
000074ad747d39e9  pop r8
000074ad747d39eb  pop rsi
000074ad747d39ec  pop rdi
000074ad747d39ed  pop rdx
000074ad747d39ee  pop rcx
000074ad747d39ef  pop rax
000074ad747d39f0  add rsp, 0x08
000074ad747d39f4  jmp 0x000074AD747D29FA
000074ad747d39f9  sub rsp, 0x08
000074ad747d39fd  push rax
000074ad747d39fe  push rcx
000074ad747d39ff  push rdx
000074ad747d3a00  push rdi
000074ad747d3a01  push rsi
000074ad747d3a02  push r8
000074ad747d3a04  push r9
000074ad747d3a06  push r10
000074ad747d3a08  push r11
000074ad747d3a0a  sub rsp, 0xF0
000074ad747d3a11  vmovaps [rsp], xmm0
000074ad747d3a16  vmovaps [rsp+0x10], xmm1
000074ad747d3a1c  vmovaps [rsp+0x20], xmm2
000074ad747d3a22  vmovaps [rsp+0x30], xmm3
000074ad747d3a28  vmovaps [rsp+0x40], xmm4
000074ad747d3a2e  vmovaps [rsp+0x50], xmm5
000074ad747d3a34  vmovaps [rsp+0x60], xmm6
000074ad747d3a3a  vmovaps [rsp+0x70], xmm7
000074ad747d3a40  vmovaps [rsp+0x80], xmm8
000074ad747d3a49  vmovaps [rsp+0x90], xmm9
000074ad747d3a52  vmovaps [rsp+0xA0], xmm10
000074ad747d3a5b  vmovaps [rsp+0xB0], xmm11
000074ad747d3a64  vmovaps [rsp+0xC0], xmm12
000074ad747d3a6d  vmovaps [rsp+0xD0], xmm14
000074ad747d3a76  vmovaps [rsp+0xE0], xmm15
000074ad747d3a7f  sub rsp, 0x40
000074ad747d3a83  lea rdi, [rsp]
000074ad747d3a87  lea rsi, [rsp+0x10]
000074ad747d3a8c  lea rdx, [rsp+0x20]
000074ad747d3a91  lea rcx, [rsp+0x30]
000074ad747d3a96  mov r8d, 0x00
000074ad747d3a9c  lea r9, [r15+0x3A8]
000074ad747d3aa3  movaps [rdi], xmm13
000074ad747d3aa7  movaps [rsi], xmm1
000074ad747d3aaa  movaps [rdx], xmm15
000074ad747d3aae  movaps [rcx], xmm14
000074ad747d3ab2  mov rax, 0x5C17501CEA50
000074ad747d3abc  call rax
000074ad747d3abe  movaps xmm13, [rsp]
000074ad747d3ac3  add rsp, 0x40
000074ad747d3ac7  vmovaps xmm0, [rsp]
000074ad747d3acc  vmovaps xmm1, [rsp+0x10]
000074ad747d3ad2  vmovaps xmm2, [rsp+0x20]
000074ad747d3ad8  vmovaps xmm3, [rsp+0x30]
000074ad747d3ade  vmovaps xmm4, [rsp+0x40]
000074ad747d3ae4  vmovaps xmm5, [rsp+0x50]
000074ad747d3aea  vmovaps xmm6, [rsp+0x60]
000074ad747d3af0  vmovaps xmm7, [rsp+0x70]
000074ad747d3af6  vmovaps xmm8, [rsp+0x80]
000074ad747d3aff  vmovaps xmm9, [rsp+0x90]
000074ad747d3b08  vmovaps xmm10, [rsp+0xA0]
000074ad747d3b11  vmovaps xmm11, [rsp+0xB0]
000074ad747d3b1a  vmovaps xmm12, [rsp+0xC0]
000074ad747d3b23  vmovaps xmm14, [rsp+0xD0]
000074ad747d3b2c  vmovaps xmm15, [rsp+0xE0]
000074ad747d3b35  add rsp, 0xF0
000074ad747d3b3c  pop r11
000074ad747d3b3e  pop r10
000074ad747d3b40  pop r9
000074ad747d3b42  pop r8
000074ad747d3b44  pop rsi
000074ad747d3b45  pop rdi
000074ad747d3b46  pop rdx
000074ad747d3b47  pop rcx
000074ad747d3b48  pop rax
000074ad747d3b49  add rsp, 0x08
000074ad747d3b4d  jmp 0x000074AD747D2B77
000074ad747d3b52  sub rsp, 0x08
000074ad747d3b56  push rax
000074ad747d3b57  push rcx
000074ad747d3b58  push rdx
000074ad747d3b59  push rdi
000074ad747d3b5a  push rsi
000074ad747d3b5b  push r8
000074ad747d3b5d  push r9
000074ad747d3b5f  push r10
000074ad747d3b61  push r11
000074ad747d3b63  sub rsp, 0xF0
000074ad747d3b6a  vmovaps [rsp], xmm0
000074ad747d3b6f  vmovaps [rsp+0x10], xmm1
000074ad747d3b75  vmovaps [rsp+0x20], xmm2
000074ad747d3b7b  vmovaps [rsp+0x30], xmm3
000074ad747d3b81  vmovaps [rsp+0x40], xmm4
000074ad747d3b87  vmovaps [rsp+0x50], xmm5
000074ad747d3b8d  vmovaps [rsp+0x60], xmm6
000074ad747d3b93  vmovaps [rsp+0x70], xmm7
000074ad747d3b99  vmovaps [rsp+0x80], xmm8
000074ad747d3ba2  vmovaps [rsp+0x90], xmm9
000074ad747d3bab  vmovaps [rsp+0xA0], xmm10
000074ad747d3bb4  vmovaps [rsp+0xB0], xmm11
000074ad747d3bbd  vmovaps [rsp+0xC0], xmm13
000074ad747d3bc6  vmovaps [rsp+0xD0], xmm14
000074ad747d3bcf  vmovaps [rsp+0xE0], xmm15
000074ad747d3bd8  sub rsp, 0x40
000074ad747d3bdc  lea rdi, [rsp]
000074ad747d3be0  lea rsi, [rsp+0x10]
000074ad747d3be5  lea rdx, [rsp+0x20]
000074ad747d3bea  lea rcx, [rsp+0x30]
000074ad747d3bef  mov r8d, 0x00
000074ad747d3bf5  lea r9, [r15+0x3A8]
000074ad747d3bfc  movaps [rdi], xmm12
000074ad747d3c00  movaps [rsi], xmm15
000074ad747d3c04  movaps [rdx], xmm14
000074ad747d3c08  movaps [rcx], xmm1
000074ad747d3c0b  mov rax, 0x5C17501CEA50
000074ad747d3c15  call rax
000074ad747d3c17  movaps xmm12, [rsp]
000074ad747d3c1c  add rsp, 0x40
000074ad747d3c20  vmovaps xmm0, [rsp]
000074ad747d3c25  vmovaps xmm1, [rsp+0x10]
000074ad747d3c2b  vmovaps xmm2, [rsp+0x20]
000074ad747d3c31  vmovaps xmm3, [rsp+0x30]
000074ad747d3c37  vmovaps xmm4, [rsp+0x40]
000074ad747d3c3d  vmovaps xmm5, [rsp+0x50]
000074ad747d3c43  vmovaps xmm6, [rsp+0x60]
000074ad747d3c49  vmovaps xmm7, [rsp+0x70]
000074ad747d3c4f  vmovaps xmm8, [rsp+0x80]
000074ad747d3c58  vmovaps xmm9, [rsp+0x90]
000074ad747d3c61  vmovaps xmm10, [rsp+0xA0]
000074ad747d3c6a  vmovaps xmm11, [rsp+0xB0]
000074ad747d3c73  vmovaps xmm13, [rsp+0xC0]
000074ad747d3c7c  vmovaps xmm14, [rsp+0xD0]
000074ad747d3c85  vmovaps xmm15, [rsp+0xE0]
000074ad747d3c8e  add rsp, 0xF0
000074ad747d3c95  pop r11
000074ad747d3c97  pop r10
000074ad747d3c99  pop r9
000074ad747d3c9b  pop r8
000074ad747d3c9d  pop rsi
000074ad747d3c9e  pop rdi
000074ad747d3c9f  pop rdx
000074ad747d3ca0  pop rcx
000074ad747d3ca1  pop rax
000074ad747d3ca2  add rsp, 0x08
000074ad747d3ca6  jmp 0x000074AD747D2BB2
000074ad747d3cab  sub rsp, 0x08
000074ad747d3caf  push rax
000074ad747d3cb0  push rcx
000074ad747d3cb1  push rdx
000074ad747d3cb2  push rdi
000074ad747d3cb3  push rsi
000074ad747d3cb4  push r8
000074ad747d3cb6  push r9
000074ad747d3cb8  push r10
000074ad747d3cba  push r11
000074ad747d3cbc  sub rsp, 0xF0
000074ad747d3cc3  vmovaps [rsp], xmm0
000074ad747d3cc8  vmovaps [rsp+0x10], xmm1
000074ad747d3cce  vmovaps [rsp+0x20], xmm2
000074ad747d3cd4  vmovaps [rsp+0x30], xmm3
000074ad747d3cda  vmovaps [rsp+0x40], xmm4
000074ad747d3ce0  vmovaps [rsp+0x50], xmm5
000074ad747d3ce6  vmovaps [rsp+0x60], xmm6
000074ad747d3cec  vmovaps [rsp+0x70], xmm7
000074ad747d3cf2  vmovaps [rsp+0x80], xmm8
000074ad747d3cfb  vmovaps [rsp+0x90], xmm9
000074ad747d3d04  vmovaps [rsp+0xA0], xmm10
000074ad747d3d0d  vmovaps [rsp+0xB0], xmm11
000074ad747d3d16  vmovaps [rsp+0xC0], xmm12
000074ad747d3d1f  vmovaps [rsp+0xD0], xmm14
000074ad747d3d28  vmovaps [rsp+0xE0], xmm15
000074ad747d3d31  sub rsp, 0x40
000074ad747d3d35  lea rdi, [rsp]
000074ad747d3d39  lea rsi, [rsp+0x10]
000074ad747d3d3e  lea rdx, [rsp+0x20]
000074ad747d3d43  lea rcx, [rsp+0x30]
000074ad747d3d48  mov r8d, 0x00
000074ad747d3d4e  lea r9, [r15+0x3A8]
000074ad747d3d55  movaps [rdi], xmm13
000074ad747d3d59  movaps [rsi], xmm15
000074ad747d3d5d  movaps [rdx], xmm14
000074ad747d3d61  movaps [rcx], xmm1
000074ad747d3d64  mov rax, 0x5C17501CEA50
000074ad747d3d6e  call rax
000074ad747d3d70  movaps xmm13, [rsp]
000074ad747d3d75  add rsp, 0x40
000074ad747d3d79  vmovaps xmm0, [rsp]
000074ad747d3d7e  vmovaps xmm1, [rsp+0x10]
000074ad747d3d84  vmovaps xmm2, [rsp+0x20]
000074ad747d3d8a  vmovaps xmm3, [rsp+0x30]
000074ad747d3d90  vmovaps xmm4, [rsp+0x40]
000074ad747d3d96  vmovaps xmm5, [rsp+0x50]
000074ad747d3d9c  vmovaps xmm6, [rsp+0x60]
000074ad747d3da2  vmovaps xmm7, [rsp+0x70]
000074ad747d3da8  vmovaps xmm8, [rsp+0x80]
000074ad747d3db1  vmovaps xmm9, [rsp+0x90]
000074ad747d3dba  vmovaps xmm10, [rsp+0xA0]
000074ad747d3dc3  vmovaps xmm11, [rsp+0xB0]
000074ad747d3dcc  vmovaps xmm12, [rsp+0xC0]
000074ad747d3dd5  vmovaps xmm14, [rsp+0xD0]
000074ad747d3dde  vmovaps xmm15, [rsp+0xE0]
000074ad747d3de7  add rsp, 0xF0
000074ad747d3dee  pop r11
000074ad747d3df0  pop r10
000074ad747d3df2  pop r9
000074ad747d3df4  pop r8
000074ad747d3df6  pop rsi
000074ad747d3df7  pop rdi
000074ad747d3df8  pop rdx
000074ad747d3df9  pop rcx
000074ad747d3dfa  pop rax
000074ad747d3dfb  add rsp, 0x08
000074ad747d3dff  jmp 0x000074AD747D2BEA
000074ad747d3e04  sub rsp, 0x08
000074ad747d3e08  push rax
000074ad747d3e09  push rcx
000074ad747d3e0a  push rdx
000074ad747d3e0b  push rdi
000074ad747d3e0c  push rsi
000074ad747d3e0d  push r8
000074ad747d3e0f  push r9
000074ad747d3e11  push r10
000074ad747d3e13  push r11
000074ad747d3e15  sub rsp, 0xF0
000074ad747d3e1c  vmovaps [rsp], xmm0
000074ad747d3e21  vmovaps [rsp+0x10], xmm1
000074ad747d3e27  vmovaps [rsp+0x20], xmm2
000074ad747d3e2d  vmovaps [rsp+0x30], xmm3
000074ad747d3e33  vmovaps [rsp+0x40], xmm4
000074ad747d3e39  vmovaps [rsp+0x50], xmm5
000074ad747d3e3f  vmovaps [rsp+0x60], xmm6
000074ad747d3e45  vmovaps [rsp+0x70], xmm7
000074ad747d3e4b  vmovaps [rsp+0x80], xmm8
000074ad747d3e54  vmovaps [rsp+0x90], xmm9
000074ad747d3e5d  vmovaps [rsp+0xA0], xmm10
000074ad747d3e66  vmovaps [rsp+0xB0], xmm11
000074ad747d3e6f  vmovaps [rsp+0xC0], xmm13
000074ad747d3e78  vmovaps [rsp+0xD0], xmm14
000074ad747d3e81  vmovaps [rsp+0xE0], xmm15
000074ad747d3e8a  sub rsp, 0x40
000074ad747d3e8e  lea rdi, [rsp]
000074ad747d3e92  lea rsi, [rsp+0x10]
000074ad747d3e97  lea rdx, [rsp+0x20]
000074ad747d3e9c  lea rcx, [rsp+0x30]
000074ad747d3ea1  mov r8d, 0x00
000074ad747d3ea7  lea r9, [r15+0x3A8]
000074ad747d3eae  movaps [rdi], xmm12
000074ad747d3eb2  movaps [rsi], xmm15
000074ad747d3eb6  movaps [rdx], xmm14
000074ad747d3eba  movaps [rcx], xmm1
000074ad747d3ebd  mov rax, 0x5C17501CEA50
000074ad747d3ec7  call rax
000074ad747d3ec9  movaps xmm12, [rsp]
000074ad747d3ece  add rsp, 0x40
000074ad747d3ed2  vmovaps xmm0, [rsp]
000074ad747d3ed7  vmovaps xmm1, [rsp+0x10]
000074ad747d3edd  vmovaps xmm2, [rsp+0x20]
000074ad747d3ee3  vmovaps xmm3, [rsp+0x30]
000074ad747d3ee9  vmovaps xmm4, [rsp+0x40]
000074ad747d3eef  vmovaps xmm5, [rsp+0x50]
000074ad747d3ef5  vmovaps xmm6, [rsp+0x60]
000074ad747d3efb  vmovaps xmm7, [rsp+0x70]
000074ad747d3f01  vmovaps xmm8, [rsp+0x80]
000074ad747d3f0a  vmovaps xmm9, [rsp+0x90]
000074ad747d3f13  vmovaps xmm10, [rsp+0xA0]
000074ad747d3f1c  vmovaps xmm11, [rsp+0xB0]
000074ad747d3f25  vmovaps xmm13, [rsp+0xC0]
000074ad747d3f2e  vmovaps xmm14, [rsp+0xD0]
000074ad747d3f37  vmovaps xmm15, [rsp+0xE0]
000074ad747d3f40  add rsp, 0xF0
000074ad747d3f47  pop r11
000074ad747d3f49  pop r10
000074ad747d3f4b  pop r9
000074ad747d3f4d  pop r8
000074ad747d3f4f  pop rsi
000074ad747d3f50  pop rdi
000074ad747d3f51  pop rdx
000074ad747d3f52  pop rcx
000074ad747d3f53  pop rax
000074ad747d3f54  add rsp, 0x08
000074ad747d3f58  jmp 0x000074AD747D2C3D
000074ad747d3f5d  sub rsp, 0x08
000074ad747d3f61  push rax
000074ad747d3f62  push rcx
000074ad747d3f63  push rdx
000074ad747d3f64  push rdi
000074ad747d3f65  push rsi
000074ad747d3f66  push r8
000074ad747d3f68  push r9
000074ad747d3f6a  push r10
000074ad747d3f6c  push r11
000074ad747d3f6e  sub rsp, 0xF0
000074ad747d3f75  vmovaps [rsp], xmm0
000074ad747d3f7a  vmovaps [rsp+0x10], xmm1
000074ad747d3f80  vmovaps [rsp+0x20], xmm2
000074ad747d3f86  vmovaps [rsp+0x30], xmm3
000074ad747d3f8c  vmovaps [rsp+0x40], xmm4
000074ad747d3f92  vmovaps [rsp+0x50], xmm5
000074ad747d3f98  vmovaps [rsp+0x60], xmm6
000074ad747d3f9e  vmovaps [rsp+0x70], xmm7
000074ad747d3fa4  vmovaps [rsp+0x80], xmm8
000074ad747d3fad  vmovaps [rsp+0x90], xmm9
000074ad747d3fb6  vmovaps [rsp+0xA0], xmm10
000074ad747d3fbf  vmovaps [rsp+0xB0], xmm11
000074ad747d3fc8  vmovaps [rsp+0xC0], xmm12
000074ad747d3fd1  vmovaps [rsp+0xD0], xmm13
000074ad747d3fda  vmovaps [rsp+0xE0], xmm15
000074ad747d3fe3  sub rsp, 0x40
000074ad747d3fe7  lea rdi, [rsp]
000074ad747d3feb  lea rsi, [rsp+0x10]
000074ad747d3ff0  lea rdx, [rsp+0x20]
000074ad747d3ff5  lea rcx, [rsp+0x30]
000074ad747d3ffa  mov r8d, 0x00
000074ad747d4000  lea r9, [r15+0x3A8]
000074ad747d4007  movaps [rdi], xmm14
000074ad747d400b  movaps [rsi], xmm3
000074ad747d400e  movaps [rdx], xmm1
000074ad747d4011  movaps [rcx], xmm15
000074ad747d4015  mov rax, 0x5C17501CEA50
000074ad747d401f  call rax
000074ad747d4021  movaps xmm14, [rsp]
000074ad747d4026  add rsp, 0x40
000074ad747d402a  vmovaps xmm0, [rsp]
000074ad747d402f  vmovaps xmm1, [rsp+0x10]
000074ad747d4035  vmovaps xmm2, [rsp+0x20]
000074ad747d403b  vmovaps xmm3, [rsp+0x30]
000074ad747d4041  vmovaps xmm4, [rsp+0x40]
000074ad747d4047  vmovaps xmm5, [rsp+0x50]
000074ad747d404d  vmovaps xmm6, [rsp+0x60]
000074ad747d4053  vmovaps xmm7, [rsp+0x70]
000074ad747d4059  vmovaps xmm8, [rsp+0x80]
000074ad747d4062  vmovaps xmm9, [rsp+0x90]
000074ad747d406b  vmovaps xmm10, [rsp+0xA0]
000074ad747d4074  vmovaps xmm11, [rsp+0xB0]
000074ad747d407d  vmovaps xmm12, [rsp+0xC0]
000074ad747d4086  vmovaps xmm13, [rsp+0xD0]
000074ad747d408f  vmovaps xmm15, [rsp+0xE0]
000074ad747d4098  add rsp, 0xF0
000074ad747d409f  pop r11
000074ad747d40a1  pop r10
000074ad747d40a3  pop r9
000074ad747d40a5  pop r8
000074ad747d40a7  pop rsi
000074ad747d40a8  pop rdi
000074ad747d40a9  pop rdx
000074ad747d40aa  pop rcx
000074ad747d40ab  pop rax
000074ad747d40ac  add rsp, 0x08
000074ad747d40b0  jmp 0x000074AD747D2CF7
000074ad747d40b5  sub rsp, 0x08
000074ad747d40b9  push rax
000074ad747d40ba  push rcx
000074ad747d40bb  push rdx
000074ad747d40bc  push rdi
000074ad747d40bd  push rsi
000074ad747d40be  push r8
000074ad747d40c0  push r9
000074ad747d40c2  push r10
000074ad747d40c4  push r11
000074ad747d40c6  sub rsp, 0xF0
000074ad747d40cd  vmovaps [rsp], xmm0
000074ad747d40d2  vmovaps [rsp+0x10], xmm1
000074ad747d40d8  vmovaps [rsp+0x20], xmm2
000074ad747d40de  vmovaps [rsp+0x30], xmm3
000074ad747d40e4  vmovaps [rsp+0x40], xmm4
000074ad747d40ea  vmovaps [rsp+0x50], xmm5
000074ad747d40f0  vmovaps [rsp+0x60], xmm6
000074ad747d40f6  vmovaps [rsp+0x70], xmm7
000074ad747d40fc  vmovaps [rsp+0x80], xmm8
000074ad747d4105  vmovaps [rsp+0x90], xmm9
000074ad747d410e  vmovaps [rsp+0xA0], xmm10
000074ad747d4117  vmovaps [rsp+0xB0], xmm11
000074ad747d4120  vmovaps [rsp+0xC0], xmm12
000074ad747d4129  vmovaps [rsp+0xD0], xmm14
000074ad747d4132  vmovaps [rsp+0xE0], xmm15
000074ad747d413b  sub rsp, 0x40
000074ad747d413f  lea rdi, [rsp]
000074ad747d4143  lea rsi, [rsp+0x10]
000074ad747d4148  lea rdx, [rsp+0x20]
000074ad747d414d  lea rcx, [rsp+0x30]
000074ad747d4152  mov r8d, 0x00
000074ad747d4158  lea r9, [r15+0x3A8]
000074ad747d415f  movaps [rdi], xmm13
000074ad747d4163  movaps [rsi], xmm15
000074ad747d4167  movaps [rdx], xmm10
000074ad747d416b  movaps [rcx], xmm1
000074ad747d416e  mov rax, 0x5C17501CEA50
000074ad747d4178  call rax
000074ad747d417a  movaps xmm13, [rsp]
000074ad747d417f  add rsp, 0x40
000074ad747d4183  vmovaps xmm0, [rsp]
000074ad747d4188  vmovaps xmm1, [rsp+0x10]
000074ad747d418e  vmovaps xmm2, [rsp+0x20]
000074ad747d4194  vmovaps xmm3, [rsp+0x30]
000074ad747d419a  vmovaps xmm4, [rsp+0x40]
000074ad747d41a0  vmovaps xmm5, [rsp+0x50]
000074ad747d41a6  vmovaps xmm6, [rsp+0x60]
000074ad747d41ac  vmovaps xmm7, [rsp+0x70]
000074ad747d41b2  vmovaps xmm8, [rsp+0x80]
000074ad747d41bb  vmovaps xmm9, [rsp+0x90]
000074ad747d41c4  vmovaps xmm10, [rsp+0xA0]
000074ad747d41cd  vmovaps xmm11, [rsp+0xB0]
000074ad747d41d6  vmovaps xmm12, [rsp+0xC0]
000074ad747d41df  vmovaps xmm14, [rsp+0xD0]
000074ad747d41e8  vmovaps xmm15, [rsp+0xE0]
000074ad747d41f1  add rsp, 0xF0
000074ad747d41f8  pop r11
000074ad747d41fa  pop r10
000074ad747d41fc  pop r9
000074ad747d41fe  pop r8
000074ad747d4200  pop rsi
000074ad747d4201  pop rdi
000074ad747d4202  pop rdx
000074ad747d4203  pop rcx
000074ad747d4204  pop rax
000074ad747d4205  add rsp, 0x08
000074ad747d4209  jmp 0x000074AD747D2D26
000074ad747d420e  sub rsp, 0x08
000074ad747d4212  push rax
000074ad747d4213  push rcx
000074ad747d4214  push rdx
000074ad747d4215  push rdi
000074ad747d4216  push rsi
000074ad747d4217  push r8
000074ad747d4219  push r9
000074ad747d421b  push r10
000074ad747d421d  push r11
000074ad747d421f  sub rsp, 0xF0
000074ad747d4226  vmovaps [rsp], xmm0
000074ad747d422b  vmovaps [rsp+0x10], xmm1
000074ad747d4231  vmovaps [rsp+0x20], xmm2
000074ad747d4237  vmovaps [rsp+0x30], xmm3
000074ad747d423d  vmovaps [rsp+0x40], xmm4
000074ad747d4243  vmovaps [rsp+0x50], xmm5
000074ad747d4249  vmovaps [rsp+0x60], xmm6
000074ad747d424f  vmovaps [rsp+0x70], xmm7
000074ad747d4255  vmovaps [rsp+0x80], xmm8
000074ad747d425e  vmovaps [rsp+0x90], xmm9
000074ad747d4267  vmovaps [rsp+0xA0], xmm11
000074ad747d4270  vmovaps [rsp+0xB0], xmm12
000074ad747d4279  vmovaps [rsp+0xC0], xmm13
000074ad747d4282  vmovaps [rsp+0xD0], xmm14
000074ad747d428b  vmovaps [rsp+0xE0], xmm15
000074ad747d4294  sub rsp, 0x40
000074ad747d4298  lea rdi, [rsp]
000074ad747d429c  lea rsi, [rsp+0x10]
000074ad747d42a1  lea rdx, [rsp+0x20]
000074ad747d42a6  lea rcx, [rsp+0x30]
000074ad747d42ab  mov r8d, 0x00
000074ad747d42b1  lea r9, [r15+0x3A8]
000074ad747d42b8  movaps [rdi], xmm10
000074ad747d42bc  movaps [rsi], xmm15
000074ad747d42c0  movaps [rdx], xmm11
000074ad747d42c4  movaps [rcx], xmm1
000074ad747d42c7  mov rax, 0x5C17501CEA50
000074ad747d42d1  call rax
000074ad747d42d3  movaps xmm10, [rsp]
000074ad747d42d8  add rsp, 0x40
000074ad747d42dc  vmovaps xmm0, [rsp]
000074ad747d42e1  vmovaps xmm1, [rsp+0x10]
000074ad747d42e7  vmovaps xmm2, [rsp+0x20]
000074ad747d42ed  vmovaps xmm3, [rsp+0x30]
000074ad747d42f3  vmovaps xmm4, [rsp+0x40]
000074ad747d42f9  vmovaps xmm5, [rsp+0x50]
000074ad747d42ff  vmovaps xmm6, [rsp+0x60]
000074ad747d4305  vmovaps xmm7, [rsp+0x70]
000074ad747d430b  vmovaps xmm8, [rsp+0x80]
000074ad747d4314  vmovaps xmm9, [rsp+0x90]
000074ad747d431d  vmovaps xmm11, [rsp+0xA0]
000074ad747d4326  vmovaps xmm12, [rsp+0xB0]
000074ad747d432f  vmovaps xmm13, [rsp+0xC0]
000074ad747d4338  vmovaps xmm14, [rsp+0xD0]
000074ad747d4341  vmovaps xmm15, [rsp+0xE0]
000074ad747d434a  add rsp, 0xF0
000074ad747d4351  pop r11
000074ad747d4353  pop r10
000074ad747d4355  pop r9
000074ad747d4357  pop r8
000074ad747d4359  pop rsi
000074ad747d435a  pop rdi
000074ad747d435b  pop rdx
000074ad747d435c  pop rcx
000074ad747d435d  pop rax
000074ad747d435e  add rsp, 0x08
000074ad747d4362  jmp 0x000074AD747D2D55
000074ad747d4367  sub rsp, 0x08
000074ad747d436b  push rax
000074ad747d436c  push rcx
000074ad747d436d  push rdx
000074ad747d436e  push rdi
000074ad747d436f  push rsi
000074ad747d4370  push r8
000074ad747d4372  push r9
000074ad747d4374  push r10
000074ad747d4376  push r11
000074ad747d4378  sub rsp, 0xF0
000074ad747d437f  vmovaps [rsp], xmm0
000074ad747d4384  vmovaps [rsp+0x10], xmm1
000074ad747d438a  vmovaps [rsp+0x20], xmm2
000074ad747d4390  vmovaps [rsp+0x30], xmm3
000074ad747d4396  vmovaps [rsp+0x40], xmm4
000074ad747d439c  vmovaps [rsp+0x50], xmm5
000074ad747d43a2  vmovaps [rsp+0x60], xmm6
000074ad747d43a8  vmovaps [rsp+0x70], xmm7
000074ad747d43ae  vmovaps [rsp+0x80], xmm8
000074ad747d43b7  vmovaps [rsp+0x90], xmm9
000074ad747d43c0  vmovaps [rsp+0xA0], xmm10
000074ad747d43c9  vmovaps [rsp+0xB0], xmm11
000074ad747d43d2  vmovaps [rsp+0xC0], xmm12
000074ad747d43db  vmovaps [rsp+0xD0], xmm13
000074ad747d43e4  vmovaps [rsp+0xE0], xmm14
000074ad747d43ed  sub rsp, 0x40
000074ad747d43f1  lea rdi, [rsp]
000074ad747d43f5  lea rsi, [rsp+0x10]
000074ad747d43fa  lea rdx, [rsp+0x20]
000074ad747d43ff  lea rcx, [rsp+0x30]
000074ad747d4404  mov r8d, 0x00
000074ad747d440a  lea r9, [r15+0x3A8]
000074ad747d4411  movaps [rdi], xmm15
000074ad747d4415  movaps [rsi], xmm12
000074ad747d4419  movaps [rdx], xmm5
000074ad747d441c  movaps [rcx], xmm1
000074ad747d441f  mov rax, 0x5C17501CEA50
000074ad747d4429  call rax
000074ad747d442b  movaps xmm15, [rsp]
000074ad747d4430  add rsp, 0x40
000074ad747d4434  vmovaps xmm0, [rsp]
000074ad747d4439  vmovaps xmm1, [rsp+0x10]
000074ad747d443f  vmovaps xmm2, [rsp+0x20]
000074ad747d4445  vmovaps xmm3, [rsp+0x30]
000074ad747d444b  vmovaps xmm4, [rsp+0x40]
000074ad747d4451  vmovaps xmm5, [rsp+0x50]
000074ad747d4457  vmovaps xmm6, [rsp+0x60]
000074ad747d445d  vmovaps xmm7, [rsp+0x70]
000074ad747d4463  vmovaps xmm8, [rsp+0x80]
000074ad747d446c  vmovaps xmm9, [rsp+0x90]
000074ad747d4475  vmovaps xmm10, [rsp+0xA0]
000074ad747d447e  vmovaps xmm11, [rsp+0xB0]
000074ad747d4487  vmovaps xmm12, [rsp+0xC0]
000074ad747d4490  vmovaps xmm13, [rsp+0xD0]
000074ad747d4499  vmovaps xmm14, [rsp+0xE0]
000074ad747d44a2  add rsp, 0xF0
000074ad747d44a9  pop r11
000074ad747d44ab  pop r10
000074ad747d44ad  pop r9
000074ad747d44af  pop r8
000074ad747d44b1  pop rsi
000074ad747d44b2  pop rdi
000074ad747d44b3  pop rdx
000074ad747d44b4  pop rcx
000074ad747d44b5  pop rax
000074ad747d44b6  add rsp, 0x08
000074ad747d44ba  jmp 0x000074AD747D2D7E
000074ad747d44bf  sub rsp, 0x08
000074ad747d44c3  push rax
000074ad747d44c4  push rcx
000074ad747d44c5  push rdx
000074ad747d44c6  push rdi
000074ad747d44c7  push rsi
000074ad747d44c8  push r8
000074ad747d44ca  push r9
000074ad747d44cc  push r10
000074ad747d44ce  push r11
000074ad747d44d0  sub rsp, 0xF0
000074ad747d44d7  vmovaps [rsp], xmm0
000074ad747d44dc  vmovaps [rsp+0x10], xmm1
000074ad747d44e2  vmovaps [rsp+0x20], xmm2
000074ad747d44e8  vmovaps [rsp+0x30], xmm3
000074ad747d44ee  vmovaps [rsp+0x40], xmm4
000074ad747d44f4  vmovaps [rsp+0x50], xmm6
000074ad747d44fa  vmovaps [rsp+0x60], xmm7
000074ad747d4500  vmovaps [rsp+0x70], xmm8
000074ad747d4506  vmovaps [rsp+0x80], xmm9
000074ad747d450f  vmovaps [rsp+0x90], xmm10
000074ad747d4518  vmovaps [rsp+0xA0], xmm11
000074ad747d4521  vmovaps [rsp+0xB0], xmm12
000074ad747d452a  vmovaps [rsp+0xC0], xmm13
000074ad747d4533  vmovaps [rsp+0xD0], xmm14
000074ad747d453c  vmovaps [rsp+0xE0], xmm15
000074ad747d4545  sub rsp, 0x40
000074ad747d4549  lea rdi, [rsp]
000074ad747d454d  lea rsi, [rsp+0x10]
000074ad747d4552  lea rdx, [rsp+0x20]
000074ad747d4557  lea rcx, [rsp+0x30]
000074ad747d455c  mov r8d, 0x00
000074ad747d4562  lea r9, [r15+0x3A8]
000074ad747d4569  movaps [rdi], xmm5
000074ad747d456c  movaps [rsi], xmm13
000074ad747d4570  movaps [rdx], xmm11
000074ad747d4574  movaps [rcx], xmm12
000074ad747d4578  mov rax, 0x5C17501CEA50
000074ad747d4582  call rax
000074ad747d4584  movaps xmm5, [rsp]
000074ad747d4588  add rsp, 0x40
000074ad747d458c  vmovaps xmm0, [rsp]
000074ad747d4591  vmovaps xmm1, [rsp+0x10]
000074ad747d4597  vmovaps xmm2, [rsp+0x20]
000074ad747d459d  vmovaps xmm3, [rsp+0x30]
000074ad747d45a3  vmovaps xmm4, [rsp+0x40]
000074ad747d45a9  vmovaps xmm6, [rsp+0x50]
000074ad747d45af  vmovaps xmm7, [rsp+0x60]
000074ad747d45b5  vmovaps xmm8, [rsp+0x70]
000074ad747d45bb  vmovaps xmm9, [rsp+0x80]
000074ad747d45c4  vmovaps xmm10, [rsp+0x90]
000074ad747d45cd  vmovaps xmm11, [rsp+0xA0]
000074ad747d45d6  vmovaps xmm12, [rsp+0xB0]
000074ad747d45df  vmovaps xmm13, [rsp+0xC0]
000074ad747d45e8  vmovaps xmm14, [rsp+0xD0]
000074ad747d45f1  vmovaps xmm15, [rsp+0xE0]
000074ad747d45fa  add rsp, 0xF0
000074ad747d4601  pop r11
000074ad747d4603  pop r10
000074ad747d4605  pop r9
000074ad747d4607  pop r8
000074ad747d4609  pop rsi
000074ad747d460a  pop rdi
000074ad747d460b  pop rdx
000074ad747d460c  pop rcx
000074ad747d460d  pop rax
000074ad747d460e  add rsp, 0x08
000074ad747d4612  jmp 0x000074AD747D2DDD
000074ad747d4617  sub rsp, 0x08
000074ad747d461b  push rax
000074ad747d461c  push rcx
000074ad747d461d  push rdx
000074ad747d461e  push rdi
000074ad747d461f  push rsi
000074ad747d4620  push r8
000074ad747d4622  push r9
000074ad747d4624  push r10
000074ad747d4626  push r11
000074ad747d4628  sub rsp, 0xF0
000074ad747d462f  vmovaps [rsp], xmm0
000074ad747d4634  vmovaps [rsp+0x10], xmm1
000074ad747d463a  vmovaps [rsp+0x20], xmm2
000074ad747d4640  vmovaps [rsp+0x30], xmm3
000074ad747d4646  vmovaps [rsp+0x40], xmm4
000074ad747d464c  vmovaps [rsp+0x50], xmm5
000074ad747d4652  vmovaps [rsp+0x60], xmm6
000074ad747d4658  vmovaps [rsp+0x70], xmm7
000074ad747d465e  vmovaps [rsp+0x80], xmm8
000074ad747d4667  vmovaps [rsp+0x90], xmm9
000074ad747d4670  vmovaps [rsp+0xA0], xmm10
000074ad747d4679  vmovaps [rsp+0xB0], xmm11
000074ad747d4682  vmovaps [rsp+0xC0], xmm13
000074ad747d468b  vmovaps [rsp+0xD0], xmm14
000074ad747d4694  vmovaps [rsp+0xE0], xmm15
000074ad747d469d  sub rsp, 0x40
000074ad747d46a1  lea rdi, [rsp]
000074ad747d46a5  lea rsi, [rsp+0x10]
000074ad747d46aa  lea rdx, [rsp+0x20]
000074ad747d46af  lea rcx, [rsp+0x30]
000074ad747d46b4  mov r8d, 0x00
000074ad747d46ba  lea r9, [r15+0x3A8]
000074ad747d46c1  movaps [rdi], xmm12
000074ad747d46c5  movaps [rsi], xmm14
000074ad747d46c9  movaps [rdx], xmm9
000074ad747d46cd  movaps [rcx], xmm13
000074ad747d46d1  mov rax, 0x5C17501CEA50
000074ad747d46db  call rax
000074ad747d46dd  movaps xmm12, [rsp]
000074ad747d46e2  add rsp, 0x40
000074ad747d46e6  vmovaps xmm0, [rsp]
000074ad747d46eb  vmovaps xmm1, [rsp+0x10]
000074ad747d46f1  vmovaps xmm2, [rsp+0x20]
000074ad747d46f7  vmovaps xmm3, [rsp+0x30]
000074ad747d46fd  vmovaps xmm4, [rsp+0x40]
000074ad747d4703  vmovaps xmm5, [rsp+0x50]
000074ad747d4709  vmovaps xmm6, [rsp+0x60]
000074ad747d470f  vmovaps xmm7, [rsp+0x70]
000074ad747d4715  vmovaps xmm8, [rsp+0x80]
000074ad747d471e  vmovaps xmm9, [rsp+0x90]
000074ad747d4727  vmovaps xmm10, [rsp+0xA0]
000074ad747d4730  vmovaps xmm11, [rsp+0xB0]
000074ad747d4739  vmovaps xmm13, [rsp+0xC0]
000074ad747d4742  vmovaps xmm14, [rsp+0xD0]
000074ad747d474b  vmovaps xmm15, [rsp+0xE0]
000074ad747d4754  add rsp, 0xF0
000074ad747d475b  pop r11
000074ad747d475d  pop r10
000074ad747d475f  pop r9
000074ad747d4761  pop r8
000074ad747d4763  pop rsi
000074ad747d4764  pop rdi
000074ad747d4765  pop rdx
000074ad747d4766  pop rcx
000074ad747d4767  pop rax
000074ad747d4768  add rsp, 0x08
000074ad747d476c  jmp 0x000074AD747D2E06
000074ad747d4771  call 0x000074AD7460D4E0
000074ad747d4776  jmp 0x000074AD747D2E13
000074ad747d477b  sub rsp, 0x08
000074ad747d477f  push rax
000074ad747d4780  push rcx
000074ad747d4781  push rdx
000074ad747d4782  push rdi
000074ad747d4783  push rsi
000074ad747d4784  push r8
000074ad747d4786  push r9
000074ad747d4788  push r10
000074ad747d478a  push r11
000074ad747d478c  sub rsp, 0xF0
000074ad747d4793  vmovaps [rsp], xmm0
000074ad747d4798  vmovaps [rsp+0x10], xmm1
000074ad747d479e  vmovaps [rsp+0x20], xmm2
000074ad747d47a4  vmovaps [rsp+0x30], xmm3
000074ad747d47aa  vmovaps [rsp+0x40], xmm4
000074ad747d47b0  vmovaps [rsp+0x50], xmm5
000074ad747d47b6  vmovaps [rsp+0x60], xmm6
000074ad747d47bc  vmovaps [rsp+0x70], xmm7
000074ad747d47c2  vmovaps [rsp+0x80], xmm8
000074ad747d47cb  vmovaps [rsp+0x90], xmm9
000074ad747d47d4  vmovaps [rsp+0xA0], xmm10
000074ad747d47dd  vmovaps [rsp+0xB0], xmm12
000074ad747d47e6  vmovaps [rsp+0xC0], xmm13
000074ad747d47ef  vmovaps [rsp+0xD0], xmm14
000074ad747d47f8  vmovaps [rsp+0xE0], xmm15
000074ad747d4801  sub rsp, 0x40
000074ad747d4805  lea rdi, [rsp]
000074ad747d4809  lea rsi, [rsp+0x10]
000074ad747d480e  lea rdx, [rsp+0x20]
000074ad747d4813  lea rcx, [rsp+0x30]
000074ad747d4818  mov r8d, 0x00
000074ad747d481e  lea r9, [r15+0x3A8]
000074ad747d4825  movaps [rdi], xmm11
000074ad747d4829  movaps [rsi], xmm10
000074ad747d482d  movaps [rdx], xmm8
000074ad747d4831  movaps [rcx], xmm13
000074ad747d4835  mov rax, 0x5C17501CEA50
000074ad747d483f  call rax
000074ad747d4841  movaps xmm11, [rsp]
000074ad747d4846  add rsp, 0x40
000074ad747d484a  vmovaps xmm0, [rsp]
000074ad747d484f  vmovaps xmm1, [rsp+0x10]
000074ad747d4855  vmovaps xmm2, [rsp+0x20]
000074ad747d485b  vmovaps xmm3, [rsp+0x30]
000074ad747d4861  vmovaps xmm4, [rsp+0x40]
000074ad747d4867  vmovaps xmm5, [rsp+0x50]
000074ad747d486d  vmovaps xmm6, [rsp+0x60]
000074ad747d4873  vmovaps xmm7, [rsp+0x70]
000074ad747d4879  vmovaps xmm8, [rsp+0x80]
000074ad747d4882  vmovaps xmm9, [rsp+0x90]
000074ad747d488b  vmovaps xmm10, [rsp+0xA0]
000074ad747d4894  vmovaps xmm12, [rsp+0xB0]
000074ad747d489d  vmovaps xmm13, [rsp+0xC0]
000074ad747d48a6  vmovaps xmm14, [rsp+0xD0]
000074ad747d48af  vmovaps xmm15, [rsp+0xE0]
000074ad747d48b8  add rsp, 0xF0
000074ad747d48bf  pop r11
000074ad747d48c1  pop r10
000074ad747d48c3  pop r9
000074ad747d48c5  pop r8
000074ad747d48c7  pop rsi
000074ad747d48c8  pop rdi
000074ad747d48c9  pop rdx
000074ad747d48ca  pop rcx
000074ad747d48cb  pop rax
000074ad747d48cc  add rsp, 0x08
000074ad747d48d0  jmp 0x000074AD747D2E44
000074ad747d48d5  sub rsp, 0x08
000074ad747d48d9  push rax
000074ad747d48da  push rcx
000074ad747d48db  push rdx
000074ad747d48dc  push rdi
000074ad747d48dd  push rsi
000074ad747d48de  push r8
000074ad747d48e0  push r9
000074ad747d48e2  push r10
000074ad747d48e4  push r11
000074ad747d48e6  sub rsp, 0xF0
000074ad747d48ed  vmovaps [rsp], xmm0
000074ad747d48f2  vmovaps [rsp+0x10], xmm1
000074ad747d48f8  vmovaps [rsp+0x20], xmm2
000074ad747d48fe  vmovaps [rsp+0x30], xmm3
000074ad747d4904  vmovaps [rsp+0x40], xmm4
000074ad747d490a  vmovaps [rsp+0x50], xmm5
000074ad747d4910  vmovaps [rsp+0x60], xmm6
000074ad747d4916  vmovaps [rsp+0x70], xmm7
000074ad747d491c  vmovaps [rsp+0x80], xmm8
000074ad747d4925  vmovaps [rsp+0x90], xmm9
000074ad747d492e  vmovaps [rsp+0xA0], xmm11
000074ad747d4937  vmovaps [rsp+0xB0], xmm12
000074ad747d4940  vmovaps [rsp+0xC0], xmm13
000074ad747d4949  vmovaps [rsp+0xD0], xmm14
000074ad747d4952  vmovaps [rsp+0xE0], xmm15
000074ad747d495b  sub rsp, 0x40
000074ad747d495f  lea rdi, [rsp]
000074ad747d4963  lea rsi, [rsp+0x10]
000074ad747d4968  lea rdx, [rsp+0x20]
000074ad747d496d  lea rcx, [rsp+0x30]
000074ad747d4972  mov r8d, 0x00
000074ad747d4978  lea r9, [r15+0x3A8]
000074ad747d497f  movaps [rdi], xmm10
000074ad747d4983  movaps [rsi], xmm15
000074ad747d4987  movaps [rdx], xmm1
000074ad747d498a  movaps [rcx], xmm13
000074ad747d498e  mov rax, 0x5C17501CEA50
000074ad747d4998  call rax
000074ad747d499a  movaps xmm10, [rsp]
000074ad747d499f  add rsp, 0x40
000074ad747d49a3  vmovaps xmm0, [rsp]
000074ad747d49a8  vmovaps xmm1, [rsp+0x10]
000074ad747d49ae  vmovaps xmm2, [rsp+0x20]
000074ad747d49b4  vmovaps xmm3, [rsp+0x30]
000074ad747d49ba  vmovaps xmm4, [rsp+0x40]
000074ad747d49c0  vmovaps xmm5, [rsp+0x50]
000074ad747d49c6  vmovaps xmm6, [rsp+0x60]
000074ad747d49cc  vmovaps xmm7, [rsp+0x70]
000074ad747d49d2  vmovaps xmm8, [rsp+0x80]
000074ad747d49db  vmovaps xmm9, [rsp+0x90]
000074ad747d49e4  vmovaps xmm11, [rsp+0xA0]
000074ad747d49ed  vmovaps xmm12, [rsp+0xB0]
000074ad747d49f6  vmovaps xmm13, [rsp+0xC0]
000074ad747d49ff  vmovaps xmm14, [rsp+0xD0]
000074ad747d4a08  vmovaps xmm15, [rsp+0xE0]
000074ad747d4a11  add rsp, 0xF0
000074ad747d4a18  pop r11
000074ad747d4a1a  pop r10
000074ad747d4a1c  pop r9
000074ad747d4a1e  pop r8
000074ad747d4a20  pop rsi
000074ad747d4a21  pop rdi
000074ad747d4a22  pop rdx
000074ad747d4a23  pop rcx
000074ad747d4a24  pop rax
000074ad747d4a25  add rsp, 0x08
000074ad747d4a29  jmp 0x000074AD747D2E6D
000074ad747d4a2e  call 0x000074AD745FF430
000074ad747d4a33  jmp 0x000074AD747D2E8F
000074ad747d4a38  call 0x000074AD7460E760
000074ad747d4a3d  jmp 0x000074AD747D2E99
000074ad747d4a42  sub rsp, 0x08
000074ad747d4a46  push rax
000074ad747d4a47  push rcx
000074ad747d4a48  push rdx
000074ad747d4a49  push rdi
000074ad747d4a4a  push rsi
000074ad747d4a4b  push r8
000074ad747d4a4d  push r9
000074ad747d4a4f  push r10
000074ad747d4a51  push r11
000074ad747d4a53  sub rsp, 0xF0
000074ad747d4a5a  vmovaps [rsp], xmm0
000074ad747d4a5f  vmovaps [rsp+0x10], xmm1
000074ad747d4a65  vmovaps [rsp+0x20], xmm2
000074ad747d4a6b  vmovaps [rsp+0x30], xmm3
000074ad747d4a71  vmovaps [rsp+0x40], xmm4
000074ad747d4a77  vmovaps [rsp+0x50], xmm5
000074ad747d4a7d  vmovaps [rsp+0x60], xmm6
000074ad747d4a83  vmovaps [rsp+0x70], xmm7
000074ad747d4a89  vmovaps [rsp+0x80], xmm9
000074ad747d4a92  vmovaps [rsp+0x90], xmm10
000074ad747d4a9b  vmovaps [rsp+0xA0], xmm11
000074ad747d4aa4  vmovaps [rsp+0xB0], xmm12
000074ad747d4aad  vmovaps [rsp+0xC0], xmm13
000074ad747d4ab6  vmovaps [rsp+0xD0], xmm14
000074ad747d4abf  vmovaps [rsp+0xE0], xmm15
000074ad747d4ac8  sub rsp, 0x40
000074ad747d4acc  lea rdi, [rsp]
000074ad747d4ad0  lea rsi, [rsp+0x10]
000074ad747d4ad5  lea rdx, [rsp+0x20]
000074ad747d4ada  lea rcx, [rsp+0x30]
000074ad747d4adf  mov r8d, 0x00
000074ad747d4ae5  lea r9, [r15+0x3A8]
000074ad747d4aec  movaps [rdi], xmm8
000074ad747d4af0  movaps [rsi], xmm5
000074ad747d4af3  movaps [rdx], xmm9
000074ad747d4af7  movaps [rcx], xmm13
000074ad747d4afb  mov rax, 0x5C17501CEA50
000074ad747d4b05  call rax
000074ad747d4b07  movaps xmm8, [rsp]
000074ad747d4b0c  add rsp, 0x40
000074ad747d4b10  vmovaps xmm0, [rsp]
000074ad747d4b15  vmovaps xmm1, [rsp+0x10]
000074ad747d4b1b  vmovaps xmm2, [rsp+0x20]
000074ad747d4b21  vmovaps xmm3, [rsp+0x30]
000074ad747d4b27  vmovaps xmm4, [rsp+0x40]
000074ad747d4b2d  vmovaps xmm5, [rsp+0x50]
000074ad747d4b33  vmovaps xmm6, [rsp+0x60]
000074ad747d4b39  vmovaps xmm7, [rsp+0x70]
000074ad747d4b3f  vmovaps xmm9, [rsp+0x80]
000074ad747d4b48  vmovaps xmm10, [rsp+0x90]
000074ad747d4b51  vmovaps xmm11, [rsp+0xA0]
000074ad747d4b5a  vmovaps xmm12, [rsp+0xB0]
000074ad747d4b63  vmovaps xmm13, [rsp+0xC0]
000074ad747d4b6c  vmovaps xmm14, [rsp+0xD0]
000074ad747d4b75  vmovaps xmm15, [rsp+0xE0]
000074ad747d4b7e  add rsp, 0xF0
000074ad747d4b85  pop r11
000074ad747d4b87  pop r10
000074ad747d4b89  pop r9
000074ad747d4b8b  pop r8
000074ad747d4b8d  pop rsi
000074ad747d4b8e  pop rdi
000074ad747d4b8f  pop rdx
000074ad747d4b90  pop rcx
000074ad747d4b91  pop rax
000074ad747d4b92  add rsp, 0x08
000074ad747d4b96  jmp 0x000074AD747D2ED8
000074ad747d4b9b  sub rsp, 0x08
000074ad747d4b9f  push rax
000074ad747d4ba0  push rcx
000074ad747d4ba1  push rdx
000074ad747d4ba2  push rdi
000074ad747d4ba3  push rsi
000074ad747d4ba4  push r8
000074ad747d4ba6  push r9
000074ad747d4ba8  push r10
000074ad747d4baa  push r11
000074ad747d4bac  sub rsp, 0xF0
000074ad747d4bb3  vmovaps [rsp], xmm0
000074ad747d4bb8  vmovaps [rsp+0x10], xmm1
000074ad747d4bbe  vmovaps [rsp+0x20], xmm2
000074ad747d4bc4  vmovaps [rsp+0x30], xmm3
000074ad747d4bca  vmovaps [rsp+0x40], xmm4
000074ad747d4bd0  vmovaps [rsp+0x50], xmm5
000074ad747d4bd6  vmovaps [rsp+0x60], xmm6
000074ad747d4bdc  vmovaps [rsp+0x70], xmm7
000074ad747d4be2  vmovaps [rsp+0x80], xmm8
000074ad747d4beb  vmovaps [rsp+0x90], xmm10
000074ad747d4bf4  vmovaps [rsp+0xA0], xmm11
000074ad747d4bfd  vmovaps [rsp+0xB0], xmm12
000074ad747d4c06  vmovaps [rsp+0xC0], xmm13
000074ad747d4c0f  vmovaps [rsp+0xD0], xmm14
000074ad747d4c18  vmovaps [rsp+0xE0], xmm15
000074ad747d4c21  sub rsp, 0x40
000074ad747d4c25  lea rdi, [rsp]
000074ad747d4c29  lea rsi, [rsp+0x10]
000074ad747d4c2e  lea rdx, [rsp+0x20]
000074ad747d4c33  lea rcx, [rsp+0x30]
000074ad747d4c38  mov r8d, 0x00
000074ad747d4c3e  lea r9, [r15+0x3A8]
000074ad747d4c45  movaps [rdi], xmm9
000074ad747d4c49  movaps [rsi], xmm12
000074ad747d4c4d  movaps [rdx], xmm7
000074ad747d4c50  movaps [rcx], xmm13
000074ad747d4c54  mov rax, 0x5C17501CEA50
000074ad747d4c5e  call rax
000074ad747d4c60  movaps xmm9, [rsp]
000074ad747d4c65  add rsp, 0x40
000074ad747d4c69  vmovaps xmm0, [rsp]
000074ad747d4c6e  vmovaps xmm1, [rsp+0x10]
000074ad747d4c74  vmovaps xmm2, [rsp+0x20]
000074ad747d4c7a  vmovaps xmm3, [rsp+0x30]
000074ad747d4c80  vmovaps xmm4, [rsp+0x40]
000074ad747d4c86  vmovaps xmm5, [rsp+0x50]
000074ad747d4c8c  vmovaps xmm6, [rsp+0x60]
000074ad747d4c92  vmovaps xmm7, [rsp+0x70]
000074ad747d4c98  vmovaps xmm8, [rsp+0x80]
000074ad747d4ca1  vmovaps xmm10, [rsp+0x90]
000074ad747d4caa  vmovaps xmm11, [rsp+0xA0]
000074ad747d4cb3  vmovaps xmm12, [rsp+0xB0]
000074ad747d4cbc  vmovaps xmm13, [rsp+0xC0]
000074ad747d4cc5  vmovaps xmm14, [rsp+0xD0]
000074ad747d4cce  vmovaps xmm15, [rsp+0xE0]
000074ad747d4cd7  add rsp, 0xF0
000074ad747d4cde  pop r11
000074ad747d4ce0  pop r10
000074ad747d4ce2  pop r9
000074ad747d4ce4  pop r8
000074ad747d4ce6  pop rsi
000074ad747d4ce7  pop rdi
000074ad747d4ce8  pop rdx
000074ad747d4ce9  pop rcx
000074ad747d4cea  pop rax
000074ad747d4ceb  add rsp, 0x08
000074ad747d4cef  jmp 0x000074AD747D2F01
000074ad747d4cf4  sub rsp, 0x08
000074ad747d4cf8  push rax
000074ad747d4cf9  push rcx
000074ad747d4cfa  push rdx
000074ad747d4cfb  push rdi
000074ad747d4cfc  push rsi
000074ad747d4cfd  push r8
000074ad747d4cff  push r9
000074ad747d4d01  push r10
000074ad747d4d03  push r11
000074ad747d4d05  sub rsp, 0xF0
000074ad747d4d0c  vmovaps [rsp], xmm0
000074ad747d4d11  vmovaps [rsp+0x10], xmm1
000074ad747d4d17  vmovaps [rsp+0x20], xmm2
000074ad747d4d1d  vmovaps [rsp+0x30], xmm3
000074ad747d4d23  vmovaps [rsp+0x40], xmm4
000074ad747d4d29  vmovaps [rsp+0x50], xmm5
000074ad747d4d2f  vmovaps [rsp+0x60], xmm6
000074ad747d4d35  vmovaps [rsp+0x70], xmm7
000074ad747d4d3b  vmovaps [rsp+0x80], xmm8
000074ad747d4d44  vmovaps [rsp+0x90], xmm9
000074ad747d4d4d  vmovaps [rsp+0xA0], xmm10
000074ad747d4d56  vmovaps [rsp+0xB0], xmm11
000074ad747d4d5f  vmovaps [rsp+0xC0], xmm13
000074ad747d4d68  vmovaps [rsp+0xD0], xmm14
000074ad747d4d71  vmovaps [rsp+0xE0], xmm15
000074ad747d4d7a  sub rsp, 0x40
000074ad747d4d7e  lea rdi, [rsp]
000074ad747d4d82  lea rsi, [rsp+0x10]
000074ad747d4d87  lea rdx, [rsp+0x20]
000074ad747d4d8c  lea rcx, [rsp+0x30]
000074ad747d4d91  mov r8d, 0x00
000074ad747d4d97  lea r9, [r15+0x3A8]
000074ad747d4d9e  movaps [rdi], xmm12
000074ad747d4da2  movaps [rsi], xmm11
000074ad747d4da6  movaps [rdx], xmm6
000074ad747d4da9  movaps [rcx], xmm13
000074ad747d4dad  mov rax, 0x5C17501CEA50
000074ad747d4db7  call rax
000074ad747d4db9  movaps xmm12, [rsp]
000074ad747d4dbe  add rsp, 0x40
000074ad747d4dc2  vmovaps xmm0, [rsp]
000074ad747d4dc7  vmovaps xmm1, [rsp+0x10]
000074ad747d4dcd  vmovaps xmm2, [rsp+0x20]
000074ad747d4dd3  vmovaps xmm3, [rsp+0x30]
000074ad747d4dd9  vmovaps xmm4, [rsp+0x40]
000074ad747d4ddf  vmovaps xmm5, [rsp+0x50]
000074ad747d4de5  vmovaps xmm6, [rsp+0x60]
000074ad747d4deb  vmovaps xmm7, [rsp+0x70]
000074ad747d4df1  vmovaps xmm8, [rsp+0x80]
000074ad747d4dfa  vmovaps xmm9, [rsp+0x90]
000074ad747d4e03  vmovaps xmm10, [rsp+0xA0]
000074ad747d4e0c  vmovaps xmm11, [rsp+0xB0]
000074ad747d4e15  vmovaps xmm13, [rsp+0xC0]
000074ad747d4e1e  vmovaps xmm14, [rsp+0xD0]
000074ad747d4e27  vmovaps xmm15, [rsp+0xE0]
000074ad747d4e30  add rsp, 0xF0
000074ad747d4e37  pop r11
000074ad747d4e39  pop r10
000074ad747d4e3b  pop r9
000074ad747d4e3d  pop r8
000074ad747d4e3f  pop rsi
000074ad747d4e40  pop rdi
000074ad747d4e41  pop rdx
000074ad747d4e42  pop rcx
000074ad747d4e43  pop rax
000074ad747d4e44  add rsp, 0x08
000074ad747d4e48  jmp 0x000074AD747D2F2A
000074ad747d4e4d  sub rsp, 0x08
000074ad747d4e51  push rax
000074ad747d4e52  push rcx
000074ad747d4e53  push rdx
000074ad747d4e54  push rdi
000074ad747d4e55  push rsi
000074ad747d4e56  push r8
000074ad747d4e58  push r9
000074ad747d4e5a  push r10
000074ad747d4e5c  push r11
000074ad747d4e5e  sub rsp, 0xF0
000074ad747d4e65  vmovaps [rsp], xmm0
000074ad747d4e6a  vmovaps [rsp+0x10], xmm1
000074ad747d4e70  vmovaps [rsp+0x20], xmm2
000074ad747d4e76  vmovaps [rsp+0x30], xmm3
000074ad747d4e7c  vmovaps [rsp+0x40], xmm4
000074ad747d4e82  vmovaps [rsp+0x50], xmm5
000074ad747d4e88  vmovaps [rsp+0x60], xmm6
000074ad747d4e8e  vmovaps [rsp+0x70], xmm8
000074ad747d4e94  vmovaps [rsp+0x80], xmm9
000074ad747d4e9d  vmovaps [rsp+0x90], xmm10
000074ad747d4ea6  vmovaps [rsp+0xA0], xmm11
000074ad747d4eaf  vmovaps [rsp+0xB0], xmm12
000074ad747d4eb8  vmovaps [rsp+0xC0], xmm13
000074ad747d4ec1  vmovaps [rsp+0xD0], xmm14
000074ad747d4eca  vmovaps [rsp+0xE0], xmm15
000074ad747d4ed3  sub rsp, 0x40
000074ad747d4ed7  lea rdi, [rsp]
000074ad747d4edb  lea rsi, [rsp+0x10]
000074ad747d4ee0  lea rdx, [rsp+0x20]
000074ad747d4ee5  lea rcx, [rsp+0x30]
000074ad747d4eea  mov r8d, 0x00
000074ad747d4ef0  lea r9, [r15+0x3A8]
000074ad747d4ef7  movaps [rdi], xmm7
000074ad747d4efa  movaps [rsi], xmm10
000074ad747d4efe  movaps [rdx], xmm11
000074ad747d4f02  movaps [rcx], xmm13
000074ad747d4f06  mov rax, 0x5C17501CEA50
000074ad747d4f10  call rax
000074ad747d4f12  movaps xmm7, [rsp]
000074ad747d4f16  add rsp, 0x40
000074ad747d4f1a  vmovaps xmm0, [rsp]
000074ad747d4f1f  vmovaps xmm1, [rsp+0x10]
000074ad747d4f25  vmovaps xmm2, [rsp+0x20]
000074ad747d4f2b  vmovaps xmm3, [rsp+0x30]
000074ad747d4f31  vmovaps xmm4, [rsp+0x40]
000074ad747d4f37  vmovaps xmm5, [rsp+0x50]
000074ad747d4f3d  vmovaps xmm6, [rsp+0x60]
000074ad747d4f43  vmovaps xmm8, [rsp+0x70]
000074ad747d4f49  vmovaps xmm9, [rsp+0x80]
000074ad747d4f52  vmovaps xmm10, [rsp+0x90]
000074ad747d4f5b  vmovaps xmm11, [rsp+0xA0]
000074ad747d4f64  vmovaps xmm12, [rsp+0xB0]
000074ad747d4f6d  vmovaps xmm13, [rsp+0xC0]
000074ad747d4f76  vmovaps xmm14, [rsp+0xD0]
000074ad747d4f7f  vmovaps xmm15, [rsp+0xE0]
000074ad747d4f88  add rsp, 0xF0
000074ad747d4f8f  pop r11
000074ad747d4f91  pop r10
000074ad747d4f93  pop r9
000074ad747d4f95  pop r8
000074ad747d4f97  pop rsi
000074ad747d4f98  pop rdi
000074ad747d4f99  pop rdx
000074ad747d4f9a  pop rcx
000074ad747d4f9b  pop rax
000074ad747d4f9c  add rsp, 0x08
000074ad747d4fa0  jmp 0x000074AD747D2F58
000074ad747d4fa5  call 0x000074AD7460C260
000074ad747d4faa  jmp 0x000074AD747D2F62
000074ad747d4faf  call 0x000074AD74609D70
000074ad747d4fb4  jmp 0x000074AD747D2F6C
000074ad747d4fb9  sub rsp, 0x08
000074ad747d4fbd  push rax
000074ad747d4fbe  push rcx
000074ad747d4fbf  push rdx
000074ad747d4fc0  push rdi
000074ad747d4fc1  push rsi
000074ad747d4fc2  push r8
000074ad747d4fc4  push r9
000074ad747d4fc6  push r10
000074ad747d4fc8  push r11
000074ad747d4fca  sub rsp, 0xF0
000074ad747d4fd1  vmovaps [rsp], xmm0
000074ad747d4fd6  vmovaps [rsp+0x10], xmm1
000074ad747d4fdc  vmovaps [rsp+0x20], xmm2
000074ad747d4fe2  vmovaps [rsp+0x30], xmm3
000074ad747d4fe8  vmovaps [rsp+0x40], xmm4
000074ad747d4fee  vmovaps [rsp+0x50], xmm5
000074ad747d4ff4  vmovaps [rsp+0x60], xmm7
000074ad747d4ffa  vmovaps [rsp+0x70], xmm8
000074ad747d5000  vmovaps [rsp+0x80], xmm9
000074ad747d5009  vmovaps [rsp+0x90], xmm10
000074ad747d5012  vmovaps [rsp+0xA0], xmm11
000074ad747d501b  vmovaps [rsp+0xB0], xmm12
000074ad747d5024  vmovaps [rsp+0xC0], xmm13
000074ad747d502d  vmovaps [rsp+0xD0], xmm14
000074ad747d5036  vmovaps [rsp+0xE0], xmm15
000074ad747d503f  sub rsp, 0x40
000074ad747d5043  lea rdi, [rsp]
000074ad747d5047  lea rsi, [rsp+0x10]
000074ad747d504c  lea rdx, [rsp+0x20]
000074ad747d5051  lea rcx, [rsp+0x30]
000074ad747d5056  mov r8d, 0x00
000074ad747d505c  lea r9, [r15+0x3A8]
000074ad747d5063  movaps [rdi], xmm6
000074ad747d5066  movaps [rsi], xmm8
000074ad747d506a  movaps [rdx], xmm15
000074ad747d506e  movaps [rcx], xmm10
000074ad747d5072  mov rax, 0x5C17501CEA50
000074ad747d507c  call rax
000074ad747d507e  movaps xmm6, [rsp]
000074ad747d5082  add rsp, 0x40
000074ad747d5086  vmovaps xmm0, [rsp]
000074ad747d508b  vmovaps xmm1, [rsp+0x10]
000074ad747d5091  vmovaps xmm2, [rsp+0x20]
000074ad747d5097  vmovaps xmm3, [rsp+0x30]
000074ad747d509d  vmovaps xmm4, [rsp+0x40]
000074ad747d50a3  vmovaps xmm5, [rsp+0x50]
000074ad747d50a9  vmovaps xmm7, [rsp+0x60]
000074ad747d50af  vmovaps xmm8, [rsp+0x70]
000074ad747d50b5  vmovaps xmm9, [rsp+0x80]
000074ad747d50be  vmovaps xmm10, [rsp+0x90]
000074ad747d50c7  vmovaps xmm11, [rsp+0xA0]
000074ad747d50d0  vmovaps xmm12, [rsp+0xB0]
000074ad747d50d9  vmovaps xmm13, [rsp+0xC0]
000074ad747d50e2  vmovaps xmm14, [rsp+0xD0]
000074ad747d50eb  vmovaps xmm15, [rsp+0xE0]
000074ad747d50f4  add rsp, 0xF0
000074ad747d50fb  pop r11
000074ad747d50fd  pop r10
000074ad747d50ff  pop r9
000074ad747d5101  pop r8
000074ad747d5103  pop rsi
000074ad747d5104  pop rdi
000074ad747d5105  pop rdx
000074ad747d5106  pop rcx
000074ad747d5107  pop rax
000074ad747d5108  add rsp, 0x08
000074ad747d510c  jmp 0x000074AD747D2FA4
000074ad747d5111  sub rsp, 0x08
000074ad747d5115  push rax
000074ad747d5116  push rcx
000074ad747d5117  push rdx
000074ad747d5118  push rdi
000074ad747d5119  push rsi
000074ad747d511a  push r8
000074ad747d511c  push r9
000074ad747d511e  push r10
000074ad747d5120  push r11
000074ad747d5122  sub rsp, 0xF0
000074ad747d5129  vmovaps [rsp], xmm0
000074ad747d512e  vmovaps [rsp+0x10], xmm1
000074ad747d5134  vmovaps [rsp+0x20], xmm2
000074ad747d513a  vmovaps [rsp+0x30], xmm3
000074ad747d5140  vmovaps [rsp+0x40], xmm4
000074ad747d5146  vmovaps [rsp+0x50], xmm5
000074ad747d514c  vmovaps [rsp+0x60], xmm6
000074ad747d5152  vmovaps [rsp+0x70], xmm7
000074ad747d5158  vmovaps [rsp+0x80], xmm8
000074ad747d5161  vmovaps [rsp+0x90], xmm9
000074ad747d516a  vmovaps [rsp+0xA0], xmm11
000074ad747d5173  vmovaps [rsp+0xB0], xmm12
000074ad747d517c  vmovaps [rsp+0xC0], xmm13
000074ad747d5185  vmovaps [rsp+0xD0], xmm14
000074ad747d518e  vmovaps [rsp+0xE0], xmm15
000074ad747d5197  sub rsp, 0x40
000074ad747d519b  lea rdi, [rsp]
000074ad747d519f  lea rsi, [rsp+0x10]
000074ad747d51a4  lea rdx, [rsp+0x20]
000074ad747d51a9  lea rcx, [rsp+0x30]
000074ad747d51ae  mov r8d, 0x00
000074ad747d51b4  lea r9, [r15+0x3A8]
000074ad747d51bb  movaps [rdi], xmm10
000074ad747d51bf  movaps [rsi], xmm9
000074ad747d51c3  movaps [rdx], xmm13
000074ad747d51c7  movaps [rcx], xmm15
000074ad747d51cb  mov rax, 0x5C17501CEA50
000074ad747d51d5  call rax
000074ad747d51d7  movaps xmm10, [rsp]
000074ad747d51dc  add rsp, 0x40
000074ad747d51e0  vmovaps xmm0, [rsp]
000074ad747d51e5  vmovaps xmm1, [rsp+0x10]
000074ad747d51eb  vmovaps xmm2, [rsp+0x20]
000074ad747d51f1  vmovaps xmm3, [rsp+0x30]
000074ad747d51f7  vmovaps xmm4, [rsp+0x40]
000074ad747d51fd  vmovaps xmm5, [rsp+0x50]
000074ad747d5203  vmovaps xmm6, [rsp+0x60]
000074ad747d5209  vmovaps xmm7, [rsp+0x70]
000074ad747d520f  vmovaps xmm8, [rsp+0x80]
000074ad747d5218  vmovaps xmm9, [rsp+0x90]
000074ad747d5221  vmovaps xmm11, [rsp+0xA0]
000074ad747d522a  vmovaps xmm12, [rsp+0xB0]
000074ad747d5233  vmovaps xmm13, [rsp+0xC0]
000074ad747d523c  vmovaps xmm14, [rsp+0xD0]
000074ad747d5245  vmovaps xmm15, [rsp+0xE0]
000074ad747d524e  add rsp, 0xF0
000074ad747d5255  pop r11
000074ad747d5257  pop r10
000074ad747d5259  pop r9
000074ad747d525b  pop r8
000074ad747d525d  pop rsi
000074ad747d525e  pop rdi
000074ad747d525f  pop rdx
000074ad747d5260  pop rcx
000074ad747d5261  pop rax
000074ad747d5262  add rsp, 0x08
000074ad747d5266  jmp 0x000074AD747D2FCD
000074ad747d526b  sub rsp, 0x08
000074ad747d526f  push rax
000074ad747d5270  push rcx
000074ad747d5271  push rdx
000074ad747d5272  push rdi
000074ad747d5273  push rsi
000074ad747d5274  push r8
000074ad747d5276  push r9
000074ad747d5278  push r10
000074ad747d527a  push r11
000074ad747d527c  sub rsp, 0xF0
000074ad747d5283  vmovaps [rsp], xmm0
000074ad747d5288  vmovaps [rsp+0x10], xmm1
000074ad747d528e  vmovaps [rsp+0x20], xmm2
000074ad747d5294  vmovaps [rsp+0x30], xmm3
000074ad747d529a  vmovaps [rsp+0x40], xmm4
000074ad747d52a0  vmovaps [rsp+0x50], xmm5
000074ad747d52a6  vmovaps [rsp+0x60], xmm6
000074ad747d52ac  vmovaps [rsp+0x70], xmm7
000074ad747d52b2  vmovaps [rsp+0x80], xmm8
000074ad747d52bb  vmovaps [rsp+0x90], xmm9
000074ad747d52c4  vmovaps [rsp+0xA0], xmm10
000074ad747d52cd  vmovaps [rsp+0xB0], xmm11
000074ad747d52d6  vmovaps [rsp+0xC0], xmm12
000074ad747d52df  vmovaps [rsp+0xD0], xmm14
000074ad747d52e8  vmovaps [rsp+0xE0], xmm15
000074ad747d52f1  sub rsp, 0x40
000074ad747d52f5  lea rdi, [rsp]
000074ad747d52f9  lea rsi, [rsp+0x10]
000074ad747d52fe  lea rdx, [rsp+0x20]
000074ad747d5303  lea rcx, [rsp+0x30]
000074ad747d5308  mov r8d, 0x00
000074ad747d530e  lea r9, [r15+0x3A8]
000074ad747d5315  movaps [rdi], xmm13
000074ad747d5319  movaps [rsi], xmm12
000074ad747d531d  movaps [rdx], xmm4
000074ad747d5320  movaps [rcx], xmm15
000074ad747d5324  mov rax, 0x5C17501CEA50
000074ad747d532e  call rax
000074ad747d5330  movaps xmm13, [rsp]
000074ad747d5335  add rsp, 0x40
000074ad747d5339  vmovaps xmm0, [rsp]
000074ad747d533e  vmovaps xmm1, [rsp+0x10]
000074ad747d5344  vmovaps xmm2, [rsp+0x20]
000074ad747d534a  vmovaps xmm3, [rsp+0x30]
000074ad747d5350  vmovaps xmm4, [rsp+0x40]
000074ad747d5356  vmovaps xmm5, [rsp+0x50]
000074ad747d535c  vmovaps xmm6, [rsp+0x60]
000074ad747d5362  vmovaps xmm7, [rsp+0x70]
000074ad747d5368  vmovaps xmm8, [rsp+0x80]
000074ad747d5371  vmovaps xmm9, [rsp+0x90]
000074ad747d537a  vmovaps xmm10, [rsp+0xA0]
000074ad747d5383  vmovaps xmm11, [rsp+0xB0]
000074ad747d538c  vmovaps xmm12, [rsp+0xC0]
000074ad747d5395  vmovaps xmm14, [rsp+0xD0]
000074ad747d539e  vmovaps xmm15, [rsp+0xE0]
000074ad747d53a7  add rsp, 0xF0
000074ad747d53ae  pop r11
000074ad747d53b0  pop r10
000074ad747d53b2  pop r9
000074ad747d53b4  pop r8
000074ad747d53b6  pop rsi
000074ad747d53b7  pop rdi
000074ad747d53b8  pop rdx
000074ad747d53b9  pop rcx
000074ad747d53ba  pop rax
000074ad747d53bb  add rsp, 0x08
000074ad747d53bf  jmp 0x000074AD747D2FF6
000074ad747d53c4  sub rsp, 0x08
000074ad747d53c8  push rax
000074ad747d53c9  push rcx
000074ad747d53ca  push rdx
000074ad747d53cb  push rdi
000074ad747d53cc  push rsi
000074ad747d53cd  push r8
000074ad747d53cf  push r9
000074ad747d53d1  push r10
000074ad747d53d3  push r11
000074ad747d53d5  sub rsp, 0xF0
000074ad747d53dc  vmovaps [rsp], xmm0
000074ad747d53e1  vmovaps [rsp+0x10], xmm1
000074ad747d53e7  vmovaps [rsp+0x20], xmm2
000074ad747d53ed  vmovaps [rsp+0x30], xmm3
000074ad747d53f3  vmovaps [rsp+0x40], xmm4
000074ad747d53f9  vmovaps [rsp+0x50], xmm5
000074ad747d53ff  vmovaps [rsp+0x60], xmm6
000074ad747d5405  vmovaps [rsp+0x70], xmm7
000074ad747d540b  vmovaps [rsp+0x80], xmm8
000074ad747d5414  vmovaps [rsp+0x90], xmm9
000074ad747d541d  vmovaps [rsp+0xA0], xmm10
000074ad747d5426  vmovaps [rsp+0xB0], xmm11
000074ad747d542f  vmovaps [rsp+0xC0], xmm13
000074ad747d5438  vmovaps [rsp+0xD0], xmm14
000074ad747d5441  vmovaps [rsp+0xE0], xmm15
000074ad747d544a  sub rsp, 0x40
000074ad747d544e  lea rdi, [rsp]
000074ad747d5452  lea rsi, [rsp+0x10]
000074ad747d5457  lea rdx, [rsp+0x20]
000074ad747d545c  lea rcx, [rsp+0x30]
000074ad747d5461  mov r8d, 0x00
000074ad747d5467  lea r9, [r15+0x3A8]
000074ad747d546e  movaps [rdi], xmm12
000074ad747d5472  movaps [rsi], xmm7
000074ad747d5475  movaps [rdx], xmm1
000074ad747d5478  movaps [rcx], xmm15
000074ad747d547c  mov rax, 0x5C17501CEA50
000074ad747d5486  call rax
000074ad747d5488  movaps xmm12, [rsp]
000074ad747d548d  add rsp, 0x40
000074ad747d5491  vmovaps xmm0, [rsp]
000074ad747d5496  vmovaps xmm1, [rsp+0x10]
000074ad747d549c  vmovaps xmm2, [rsp+0x20]
000074ad747d54a2  vmovaps xmm3, [rsp+0x30]
000074ad747d54a8  vmovaps xmm4, [rsp+0x40]
000074ad747d54ae  vmovaps xmm5, [rsp+0x50]
000074ad747d54b4  vmovaps xmm6, [rsp+0x60]
000074ad747d54ba  vmovaps xmm7, [rsp+0x70]
000074ad747d54c0  vmovaps xmm8, [rsp+0x80]
000074ad747d54c9  vmovaps xmm9, [rsp+0x90]
000074ad747d54d2  vmovaps xmm10, [rsp+0xA0]
000074ad747d54db  vmovaps xmm11, [rsp+0xB0]
000074ad747d54e4  vmovaps xmm13, [rsp+0xC0]
000074ad747d54ed  vmovaps xmm14, [rsp+0xD0]
000074ad747d54f6  vmovaps xmm15, [rsp+0xE0]
000074ad747d54ff  add rsp, 0xF0
000074ad747d5506  pop r11
000074ad747d5508  pop r10
000074ad747d550a  pop r9
000074ad747d550c  pop r8
000074ad747d550e  pop rsi
000074ad747d550f  pop rdi
000074ad747d5510  pop rdx
000074ad747d5511  pop rcx
000074ad747d5512  pop rax
000074ad747d5513  add rsp, 0x08
000074ad747d5517  jmp 0x000074AD747D301F
000074ad747d551c  call 0x000074AD745FF430
000074ad747d5521  jmp 0x000074AD747D3029
000074ad747d5526  call 0x000074AD7460E760
000074ad747d552b  jmp 0x000074AD747D3033
000074ad747d5530  sub rsp, 0x08
000074ad747d5534  push rax
000074ad747d5535  push rcx
000074ad747d5536  push rdx
000074ad747d5537  push rdi
000074ad747d5538  push rsi
000074ad747d5539  push r8
000074ad747d553b  push r9
000074ad747d553d  push r10
000074ad747d553f  push r11
000074ad747d5541  sub rsp, 0xF0
000074ad747d5548  vmovaps [rsp], xmm0
000074ad747d554d  vmovaps [rsp+0x10], xmm1
000074ad747d5553  vmovaps [rsp+0x20], xmm2
000074ad747d5559  vmovaps [rsp+0x30], xmm3
000074ad747d555f  vmovaps [rsp+0x40], xmm4
000074ad747d5565  vmovaps [rsp+0x50], xmm5
000074ad747d556b  vmovaps [rsp+0x60], xmm6
000074ad747d5571  vmovaps [rsp+0x70], xmm8
000074ad747d5577  vmovaps [rsp+0x80], xmm9
000074ad747d5580  vmovaps [rsp+0x90], xmm10
000074ad747d5589  vmovaps [rsp+0xA0], xmm11
000074ad747d5592  vmovaps [rsp+0xB0], xmm12
000074ad747d559b  vmovaps [rsp+0xC0], xmm13
000074ad747d55a4  vmovaps [rsp+0xD0], xmm14
000074ad747d55ad  vmovaps [rsp+0xE0], xmm15
000074ad747d55b6  sub rsp, 0x40
000074ad747d55ba  lea rdi, [rsp]
000074ad747d55be  lea rsi, [rsp+0x10]
000074ad747d55c3  lea rdx, [rsp+0x20]
000074ad747d55c8  lea rcx, [rsp+0x30]
000074ad747d55cd  mov r8d, 0x00
000074ad747d55d3  lea r9, [r15+0x3A8]
000074ad747d55da  movaps [rdi], xmm7
000074ad747d55dd  movaps [rsi], xmm6
000074ad747d55e0  movaps [rdx], xmm8
000074ad747d55e4  movaps [rcx], xmm9
000074ad747d55e8  mov rax, 0x5C17501CEA50
000074ad747d55f2  call rax
000074ad747d55f4  movaps xmm7, [rsp]
000074ad747d55f8  add rsp, 0x40
000074ad747d55fc  vmovaps xmm0, [rsp]
000074ad747d5601  vmovaps xmm1, [rsp+0x10]
000074ad747d5607  vmovaps xmm2, [rsp+0x20]
000074ad747d560d  vmovaps xmm3, [rsp+0x30]
000074ad747d5613  vmovaps xmm4, [rsp+0x40]
000074ad747d5619  vmovaps xmm5, [rsp+0x50]
000074ad747d561f  vmovaps xmm6, [rsp+0x60]
000074ad747d5625  vmovaps xmm8, [rsp+0x70]
000074ad747d562b  vmovaps xmm9, [rsp+0x80]
000074ad747d5634  vmovaps xmm10, [rsp+0x90]
000074ad747d563d  vmovaps xmm11, [rsp+0xA0]
000074ad747d5646  vmovaps xmm12, [rsp+0xB0]
000074ad747d564f  vmovaps xmm13, [rsp+0xC0]
000074ad747d5658  vmovaps xmm14, [rsp+0xD0]
000074ad747d5661  vmovaps xmm15, [rsp+0xE0]
000074ad747d566a  add rsp, 0xF0
000074ad747d5671  pop r11
000074ad747d5673  pop r10
000074ad747d5675  pop r9
000074ad747d5677  pop r8
000074ad747d5679  pop rsi
000074ad747d567a  pop rdi
000074ad747d567b  pop rdx
000074ad747d567c  pop rcx
000074ad747d567d  pop rax
000074ad747d567e  add rsp, 0x08
000074ad747d5682  jmp 0x000074AD747D305D
000074ad747d5687  sub rsp, 0x08
000074ad747d568b  push rax
000074ad747d568c  push rcx
000074ad747d568d  push rdx
000074ad747d568e  push rdi
000074ad747d568f  push rsi
000074ad747d5690  push r8
000074ad747d5692  push r9
000074ad747d5694  push r10
000074ad747d5696  push r11
000074ad747d5698  sub rsp, 0xF0
000074ad747d569f  vmovaps [rsp], xmm0
000074ad747d56a4  vmovaps [rsp+0x10], xmm1
000074ad747d56aa  vmovaps [rsp+0x20], xmm2
000074ad747d56b0  vmovaps [rsp+0x30], xmm3
000074ad747d56b6  vmovaps [rsp+0x40], xmm4
000074ad747d56bc  vmovaps [rsp+0x50], xmm5
000074ad747d56c2  vmovaps [rsp+0x60], xmm6
000074ad747d56c8  vmovaps [rsp+0x70], xmm7
000074ad747d56ce  vmovaps [rsp+0x80], xmm9
000074ad747d56d7  vmovaps [rsp+0x90], xmm10
000074ad747d56e0  vmovaps [rsp+0xA0], xmm11
000074ad747d56e9  vmovaps [rsp+0xB0], xmm12
000074ad747d56f2  vmovaps [rsp+0xC0], xmm13
000074ad747d56fb  vmovaps [rsp+0xD0], xmm14
000074ad747d5704  vmovaps [rsp+0xE0], xmm15
000074ad747d570d  sub rsp, 0x40
000074ad747d5711  lea rdi, [rsp]
000074ad747d5715  lea rsi, [rsp+0x10]
000074ad747d571a  lea rdx, [rsp+0x20]
000074ad747d571f  lea rcx, [rsp+0x30]
000074ad747d5724  mov r8d, 0x00
000074ad747d572a  lea r9, [r15+0x3A8]
000074ad747d5731  movaps [rdi], xmm8
000074ad747d5735  movaps [rsi], xmm10
000074ad747d5739  movaps [rdx], xmm14
000074ad747d573d  movaps [rcx], xmm9
000074ad747d5741  mov rax, 0x5C17501CEA50
000074ad747d574b  call rax
000074ad747d574d  movaps xmm8, [rsp]
000074ad747d5752  add rsp, 0x40
000074ad747d5756  vmovaps xmm0, [rsp]
000074ad747d575b  vmovaps xmm1, [rsp+0x10]
000074ad747d5761  vmovaps xmm2, [rsp+0x20]
000074ad747d5767  vmovaps xmm3, [rsp+0x30]
000074ad747d576d  vmovaps xmm4, [rsp+0x40]
000074ad747d5773  vmovaps xmm5, [rsp+0x50]
000074ad747d5779  vmovaps xmm6, [rsp+0x60]
000074ad747d577f  vmovaps xmm7, [rsp+0x70]
000074ad747d5785  vmovaps xmm9, [rsp+0x80]
000074ad747d578e  vmovaps xmm10, [rsp+0x90]
000074ad747d5797  vmovaps xmm11, [rsp+0xA0]
000074ad747d57a0  vmovaps xmm12, [rsp+0xB0]
000074ad747d57a9  vmovaps xmm13, [rsp+0xC0]
000074ad747d57b2  vmovaps xmm14, [rsp+0xD0]
000074ad747d57bb  vmovaps xmm15, [rsp+0xE0]
000074ad747d57c4  add rsp, 0xF0
000074ad747d57cb  pop r11
000074ad747d57cd  pop r10
000074ad747d57cf  pop r9
000074ad747d57d1  pop r8
000074ad747d57d3  pop rsi
000074ad747d57d4  pop rdi
000074ad747d57d5  pop rdx
000074ad747d57d6  pop rcx
000074ad747d57d7  pop rax
000074ad747d57d8  add rsp, 0x08
000074ad747d57dc  jmp 0x000074AD747D3083
000074ad747d57e1  sub rsp, 0x08
000074ad747d57e5  push rax
000074ad747d57e6  push rcx
000074ad747d57e7  push rdx
000074ad747d57e8  push rdi
000074ad747d57e9  push rsi
000074ad747d57ea  push r8
000074ad747d57ec  push r9
000074ad747d57ee  push r10
000074ad747d57f0  push r11
000074ad747d57f2  sub rsp, 0xF0
000074ad747d57f9  vmovaps [rsp], xmm0
000074ad747d57fe  vmovaps [rsp+0x10], xmm1
000074ad747d5804  vmovaps [rsp+0x20], xmm2
000074ad747d580a  vmovaps [rsp+0x30], xmm3
000074ad747d5810  vmovaps [rsp+0x40], xmm4
000074ad747d5816  vmovaps [rsp+0x50], xmm5
000074ad747d581c  vmovaps [rsp+0x60], xmm6
000074ad747d5822  vmovaps [rsp+0x70], xmm7
000074ad747d5828  vmovaps [rsp+0x80], xmm8
000074ad747d5831  vmovaps [rsp+0x90], xmm9
000074ad747d583a  vmovaps [rsp+0xA0], xmm11
000074ad747d5843  vmovaps [rsp+0xB0], xmm12
000074ad747d584c  vmovaps [rsp+0xC0], xmm13
000074ad747d5855  vmovaps [rsp+0xD0], xmm14
000074ad747d585e  vmovaps [rsp+0xE0], xmm15
000074ad747d5867  sub rsp, 0x40
000074ad747d586b  lea rdi, [rsp]
000074ad747d586f  lea rsi, [rsp+0x10]
000074ad747d5874  lea rdx, [rsp+0x20]
000074ad747d5879  lea rcx, [rsp+0x30]
000074ad747d587e  mov r8d, 0x00
000074ad747d5884  lea r9, [r15+0x3A8]
000074ad747d588b  movaps [rdi], xmm10
000074ad747d588f  movaps [rsi], xmm13
000074ad747d5893  movaps [rdx], xmm11
000074ad747d5897  movaps [rcx], xmm14
000074ad747d589b  mov rax, 0x5C17501CEA50
000074ad747d58a5  call rax
000074ad747d58a7  movaps xmm10, [rsp]
000074ad747d58ac  add rsp, 0x40
000074ad747d58b0  vmovaps xmm0, [rsp]
000074ad747d58b5  vmovaps xmm1, [rsp+0x10]
000074ad747d58bb  vmovaps xmm2, [rsp+0x20]
000074ad747d58c1  vmovaps xmm3, [rsp+0x30]
000074ad747d58c7  vmovaps xmm4, [rsp+0x40]
000074ad747d58cd  vmovaps xmm5, [rsp+0x50]
000074ad747d58d3  vmovaps xmm6, [rsp+0x60]
000074ad747d58d9  vmovaps xmm7, [rsp+0x70]
000074ad747d58df  vmovaps xmm8, [rsp+0x80]
000074ad747d58e8  vmovaps xmm9, [rsp+0x90]
000074ad747d58f1  vmovaps xmm11, [rsp+0xA0]
000074ad747d58fa  vmovaps xmm12, [rsp+0xB0]
000074ad747d5903  vmovaps xmm13, [rsp+0xC0]
000074ad747d590c  vmovaps xmm14, [rsp+0xD0]
000074ad747d5915  vmovaps xmm15, [rsp+0xE0]
000074ad747d591e  add rsp, 0xF0
000074ad747d5925  pop r11
000074ad747d5927  pop r10
000074ad747d5929  pop r9
000074ad747d592b  pop r8
000074ad747d592d  pop rsi
000074ad747d592e  pop rdi
000074ad747d592f  pop rdx
000074ad747d5930  pop rcx
000074ad747d5931  pop rax
000074ad747d5932  add rsp, 0x08
000074ad747d5936  jmp 0x000074AD747D30A9
000074ad747d593b  sub rsp, 0x08
000074ad747d593f  push rax
000074ad747d5940  push rcx
000074ad747d5941  push rdx
000074ad747d5942  push rdi
000074ad747d5943  push rsi
000074ad747d5944  push r8
000074ad747d5946  push r9
000074ad747d5948  push r10
000074ad747d594a  push r11
000074ad747d594c  sub rsp, 0xF0
000074ad747d5953  vmovaps [rsp], xmm0
000074ad747d5958  vmovaps [rsp+0x10], xmm1
000074ad747d595e  vmovaps [rsp+0x20], xmm2
000074ad747d5964  vmovaps [rsp+0x30], xmm3
000074ad747d596a  vmovaps [rsp+0x40], xmm4
000074ad747d5970  vmovaps [rsp+0x50], xmm5
000074ad747d5976  vmovaps [rsp+0x60], xmm6
000074ad747d597c  vmovaps [rsp+0x70], xmm7
000074ad747d5982  vmovaps [rsp+0x80], xmm8
000074ad747d598b  vmovaps [rsp+0x90], xmm9
000074ad747d5994  vmovaps [rsp+0xA0], xmm10
000074ad747d599d  vmovaps [rsp+0xB0], xmm11
000074ad747d59a6  vmovaps [rsp+0xC0], xmm12
000074ad747d59af  vmovaps [rsp+0xD0], xmm14
000074ad747d59b8  vmovaps [rsp+0xE0], xmm15
000074ad747d59c1  sub rsp, 0x40
000074ad747d59c5  lea rdi, [rsp]
000074ad747d59c9  lea rsi, [rsp+0x10]
000074ad747d59ce  lea rdx, [rsp+0x20]
000074ad747d59d3  lea rcx, [rsp+0x30]
000074ad747d59d8  mov r8d, 0x00
000074ad747d59de  lea r9, [r15+0x3A8]
000074ad747d59e5  movaps [rdi], xmm13
000074ad747d59e9  movaps [rsi], xmm12
000074ad747d59ed  movaps [rdx], xmm15
000074ad747d59f1  movaps [rcx], xmm14
000074ad747d59f5  mov rax, 0x5C17501CEA50
000074ad747d59ff  call rax
000074ad747d5a01  movaps xmm13, [rsp]
000074ad747d5a06  add rsp, 0x40
000074ad747d5a0a  vmovaps xmm0, [rsp]
000074ad747d5a0f  vmovaps xmm1, [rsp+0x10]
000074ad747d5a15  vmovaps xmm2, [rsp+0x20]
000074ad747d5a1b  vmovaps xmm3, [rsp+0x30]
000074ad747d5a21  vmovaps xmm4, [rsp+0x40]
000074ad747d5a27  vmovaps xmm5, [rsp+0x50]
000074ad747d5a2d  vmovaps xmm6, [rsp+0x60]
000074ad747d5a33  vmovaps xmm7, [rsp+0x70]
000074ad747d5a39  vmovaps xmm8, [rsp+0x80]
000074ad747d5a42  vmovaps xmm9, [rsp+0x90]
000074ad747d5a4b  vmovaps xmm10, [rsp+0xA0]
000074ad747d5a54  vmovaps xmm11, [rsp+0xB0]
000074ad747d5a5d  vmovaps xmm12, [rsp+0xC0]
000074ad747d5a66  vmovaps xmm14, [rsp+0xD0]
000074ad747d5a6f  vmovaps xmm15, [rsp+0xE0]
000074ad747d5a78  add rsp, 0xF0
000074ad747d5a7f  pop r11
000074ad747d5a81  pop r10
000074ad747d5a83  pop r9
000074ad747d5a85  pop r8
000074ad747d5a87  pop rsi
000074ad747d5a88  pop rdi
000074ad747d5a89  pop rdx
000074ad747d5a8a  pop rcx
000074ad747d5a8b  pop rax
000074ad747d5a8c  add rsp, 0x08
000074ad747d5a90  jmp 0x000074AD747D30CF
000074ad747d5a95  call 0x000074AD7460E760
000074ad747d5a9a  jmp 0x000074AD747D30DC
000074ad747d5a9f  call 0x000074AD7460D4E0
000074ad747d5aa4  jmp 0x000074AD747D30E9
000074ad747d5aa9  sub rsp, 0x08
000074ad747d5aad  push rax
000074ad747d5aae  push rcx
000074ad747d5aaf  push rdx
000074ad747d5ab0  push rdi
000074ad747d5ab1  push rsi
000074ad747d5ab2  push r8
000074ad747d5ab4  push r9
000074ad747d5ab6  push r10
000074ad747d5ab8  push r11
000074ad747d5aba  sub rsp, 0xF0
000074ad747d5ac1  vmovaps [rsp], xmm0
000074ad747d5ac6  vmovaps [rsp+0x10], xmm1
000074ad747d5acc  vmovaps [rsp+0x20], xmm2
000074ad747d5ad2  vmovaps [rsp+0x30], xmm3
000074ad747d5ad8  vmovaps [rsp+0x40], xmm4
000074ad747d5ade  vmovaps [rsp+0x50], xmm5
000074ad747d5ae4  vmovaps [rsp+0x60], xmm6
000074ad747d5aea  vmovaps [rsp+0x70], xmm7
000074ad747d5af0  vmovaps [rsp+0x80], xmm8
000074ad747d5af9  vmovaps [rsp+0x90], xmm9
000074ad747d5b02  vmovaps [rsp+0xA0], xmm10
000074ad747d5b0b  vmovaps [rsp+0xB0], xmm12
000074ad747d5b14  vmovaps [rsp+0xC0], xmm13
000074ad747d5b1d  vmovaps [rsp+0xD0], xmm14
000074ad747d5b26  vmovaps [rsp+0xE0], xmm15
000074ad747d5b2f  sub rsp, 0x40
000074ad747d5b33  lea rdi, [rsp]
000074ad747d5b37  lea rsi, [rsp+0x10]
000074ad747d5b3c  lea rdx, [rsp+0x20]
000074ad747d5b41  lea rcx, [rsp+0x30]
000074ad747d5b46  mov r8d, 0x00
000074ad747d5b4c  lea r9, [r15+0x3A8]
000074ad747d5b53  movaps [rdi], xmm11
000074ad747d5b57  movaps [rsi], xmm7
000074ad747d5b5a  movaps [rdx], xmm1
000074ad747d5b5d  movaps [rcx], xmm12
000074ad747d5b61  mov rax, 0x5C17501CEA50
000074ad747d5b6b  call rax
000074ad747d5b6d  movaps xmm11, [rsp]
000074ad747d5b72  add rsp, 0x40
000074ad747d5b76  vmovaps xmm0, [rsp]
000074ad747d5b7b  vmovaps xmm1, [rsp+0x10]
000074ad747d5b81  vmovaps xmm2, [rsp+0x20]
000074ad747d5b87  vmovaps xmm3, [rsp+0x30]
000074ad747d5b8d  vmovaps xmm4, [rsp+0x40]
000074ad747d5b93  vmovaps xmm5, [rsp+0x50]
000074ad747d5b99  vmovaps xmm6, [rsp+0x60]
000074ad747d5b9f  vmovaps xmm7, [rsp+0x70]
000074ad747d5ba5  vmovaps xmm8, [rsp+0x80]
000074ad747d5bae  vmovaps xmm9, [rsp+0x90]
000074ad747d5bb7  vmovaps xmm10, [rsp+0xA0]
000074ad747d5bc0  vmovaps xmm12, [rsp+0xB0]
000074ad747d5bc9  vmovaps xmm13, [rsp+0xC0]
000074ad747d5bd2  vmovaps xmm14, [rsp+0xD0]
000074ad747d5bdb  vmovaps xmm15, [rsp+0xE0]
000074ad747d5be4  add rsp, 0xF0
000074ad747d5beb  pop r11
000074ad747d5bed  pop r10
000074ad747d5bef  pop r9
000074ad747d5bf1  pop r8
000074ad747d5bf3  pop rsi
000074ad747d5bf4  pop rdi
000074ad747d5bf5  pop rdx
000074ad747d5bf6  pop rcx
000074ad747d5bf7  pop rax
000074ad747d5bf8  add rsp, 0x08
000074ad747d5bfc  jmp 0x000074AD747D3122
000074ad747d5c01  call 0x000074AD745FF430
000074ad747d5c06  jmp 0x000074AD747D3134
000074ad747d5c0b  sub rsp, 0x08
000074ad747d5c0f  push rax
000074ad747d5c10  push rcx
000074ad747d5c11  push rdx
000074ad747d5c12  push rdi
000074ad747d5c13  push rsi
000074ad747d5c14  push r8
000074ad747d5c16  push r9
000074ad747d5c18  push r10
000074ad747d5c1a  push r11
000074ad747d5c1c  sub rsp, 0xF0
000074ad747d5c23  vmovaps [rsp], xmm0
000074ad747d5c28  vmovaps [rsp+0x10], xmm1
000074ad747d5c2e  vmovaps [rsp+0x20], xmm2
000074ad747d5c34  vmovaps [rsp+0x30], xmm3
000074ad747d5c3a  vmovaps [rsp+0x40], xmm4
000074ad747d5c40  vmovaps [rsp+0x50], xmm5
000074ad747d5c46  vmovaps [rsp+0x60], xmm6
000074ad747d5c4c  vmovaps [rsp+0x70], xmm7
000074ad747d5c52  vmovaps [rsp+0x80], xmm8
000074ad747d5c5b  vmovaps [rsp+0x90], xmm10
000074ad747d5c64  vmovaps [rsp+0xA0], xmm11
000074ad747d5c6d  vmovaps [rsp+0xB0], xmm12
000074ad747d5c76  vmovaps [rsp+0xC0], xmm13
000074ad747d5c7f  vmovaps [rsp+0xD0], xmm14
000074ad747d5c88  vmovaps [rsp+0xE0], xmm15
000074ad747d5c91  sub rsp, 0x40
000074ad747d5c95  lea rdi, [rsp]
000074ad747d5c99  lea rsi, [rsp+0x10]
000074ad747d5c9e  lea rdx, [rsp+0x20]
000074ad747d5ca3  lea rcx, [rsp+0x30]
000074ad747d5ca8  mov r8d, 0x00
000074ad747d5cae  lea r9, [r15+0x3A8]
000074ad747d5cb5  movaps [rdi], xmm9
000074ad747d5cb9  movaps [rsi], xmm8
000074ad747d5cbd  movaps [rdx], xmm14
000074ad747d5cc1  movaps [rcx], xmm12
000074ad747d5cc5  mov rax, 0x5C17501CEA50
000074ad747d5ccf  call rax
000074ad747d5cd1  movaps xmm9, [rsp]
000074ad747d5cd6  add rsp, 0x40
000074ad747d5cda  vmovaps xmm0, [rsp]
000074ad747d5cdf  vmovaps xmm1, [rsp+0x10]
000074ad747d5ce5  vmovaps xmm2, [rsp+0x20]
000074ad747d5ceb  vmovaps xmm3, [rsp+0x30]
000074ad747d5cf1  vmovaps xmm4, [rsp+0x40]
000074ad747d5cf7  vmovaps xmm5, [rsp+0x50]
000074ad747d5cfd  vmovaps xmm6, [rsp+0x60]
000074ad747d5d03  vmovaps xmm7, [rsp+0x70]
000074ad747d5d09  vmovaps xmm8, [rsp+0x80]
000074ad747d5d12  vmovaps xmm10, [rsp+0x90]
000074ad747d5d1b  vmovaps xmm11, [rsp+0xA0]
000074ad747d5d24  vmovaps xmm12, [rsp+0xB0]
000074ad747d5d2d  vmovaps xmm13, [rsp+0xC0]
000074ad747d5d36  vmovaps xmm14, [rsp+0xD0]
000074ad747d5d3f  vmovaps xmm15, [rsp+0xE0]
000074ad747d5d48  add rsp, 0xF0
000074ad747d5d4f  pop r11
000074ad747d5d51  pop r10
000074ad747d5d53  pop r9
000074ad747d5d55  pop r8
000074ad747d5d57  pop rsi
000074ad747d5d58  pop rdi
000074ad747d5d59  pop rdx
000074ad747d5d5a  pop rcx
000074ad747d5d5b  pop rax
000074ad747d5d5c  add rsp, 0x08
000074ad747d5d60  jmp 0x000074AD747D3165
000074ad747d5d65  sub rsp, 0x08
000074ad747d5d69  push rax
000074ad747d5d6a  push rcx
000074ad747d5d6b  push rdx
000074ad747d5d6c  push rdi
000074ad747d5d6d  push rsi
000074ad747d5d6e  push r8
000074ad747d5d70  push r9
000074ad747d5d72  push r10
000074ad747d5d74  push r11
000074ad747d5d76  sub rsp, 0xF0
000074ad747d5d7d  vmovaps [rsp], xmm0
000074ad747d5d82  vmovaps [rsp+0x10], xmm1
000074ad747d5d88  vmovaps [rsp+0x20], xmm2
000074ad747d5d8e  vmovaps [rsp+0x30], xmm3
000074ad747d5d94  vmovaps [rsp+0x40], xmm4
000074ad747d5d9a  vmovaps [rsp+0x50], xmm5
000074ad747d5da0  vmovaps [rsp+0x60], xmm6
000074ad747d5da6  vmovaps [rsp+0x70], xmm7
000074ad747d5dac  vmovaps [rsp+0x80], xmm8
000074ad747d5db5  vmovaps [rsp+0x90], xmm9
000074ad747d5dbe  vmovaps [rsp+0xA0], xmm10
000074ad747d5dc7  vmovaps [rsp+0xB0], xmm11
000074ad747d5dd0  vmovaps [rsp+0xC0], xmm13
000074ad747d5dd9  vmovaps [rsp+0xD0], xmm14
000074ad747d5de2  vmovaps [rsp+0xE0], xmm15
000074ad747d5deb  sub rsp, 0x40
000074ad747d5def  lea rdi, [rsp]
000074ad747d5df3  lea rsi, [rsp+0x10]
000074ad747d5df8  lea rdx, [rsp+0x20]
000074ad747d5dfd  lea rcx, [rsp+0x30]
000074ad747d5e02  mov r8d, 0x00
000074ad747d5e08  lea r9, [r15+0x3A8]
000074ad747d5e0f  movaps [rdi], xmm12
000074ad747d5e13  movaps [rsi], xmm10
000074ad747d5e17  movaps [rdx], xmm15
000074ad747d5e1b  movaps [rcx], xmm14
000074ad747d5e1f  mov rax, 0x5C17501CEA50
000074ad747d5e29  call rax
000074ad747d5e2b  movaps xmm12, [rsp]
000074ad747d5e30  add rsp, 0x40
000074ad747d5e34  vmovaps xmm0, [rsp]
000074ad747d5e39  vmovaps xmm1, [rsp+0x10]
000074ad747d5e3f  vmovaps xmm2, [rsp+0x20]
000074ad747d5e45  vmovaps xmm3, [rsp+0x30]
000074ad747d5e4b  vmovaps xmm4, [rsp+0x40]
000074ad747d5e51  vmovaps xmm5, [rsp+0x50]
000074ad747d5e57  vmovaps xmm6, [rsp+0x60]
000074ad747d5e5d  vmovaps xmm7, [rsp+0x70]
000074ad747d5e63  vmovaps xmm8, [rsp+0x80]
000074ad747d5e6c  vmovaps xmm9, [rsp+0x90]
000074ad747d5e75  vmovaps xmm10, [rsp+0xA0]
000074ad747d5e7e  vmovaps xmm11, [rsp+0xB0]
000074ad747d5e87  vmovaps xmm13, [rsp+0xC0]
000074ad747d5e90  vmovaps xmm14, [rsp+0xD0]
000074ad747d5e99  vmovaps xmm15, [rsp+0xE0]
000074ad747d5ea2  add rsp, 0xF0
000074ad747d5ea9  pop r11
000074ad747d5eab  pop r10
000074ad747d5ead  pop r9
000074ad747d5eaf  pop r8
000074ad747d5eb1  pop rsi
000074ad747d5eb2  pop rdi
000074ad747d5eb3  pop rdx
000074ad747d5eb4  pop rcx
000074ad747d5eb5  pop rax
000074ad747d5eb6  add rsp, 0x08
000074ad747d5eba  jmp 0x000074AD747D3196
000074ad747d5ebf  sub rsp, 0x08
000074ad747d5ec3  push rax
000074ad747d5ec4  push rcx
000074ad747d5ec5  push rdx
000074ad747d5ec6  push rdi
000074ad747d5ec7  push rsi
000074ad747d5ec8  push r8
000074ad747d5eca  push r9
000074ad747d5ecc  push r10
000074ad747d5ece  push r11
000074ad747d5ed0  sub rsp, 0xF0
000074ad747d5ed7  vmovaps [rsp], xmm0
000074ad747d5edc  vmovaps [rsp+0x10], xmm1
000074ad747d5ee2  vmovaps [rsp+0x20], xmm2
000074ad747d5ee8  vmovaps [rsp+0x30], xmm3
000074ad747d5eee  vmovaps [rsp+0x40], xmm4
000074ad747d5ef4  vmovaps [rsp+0x50], xmm5
000074ad747d5efa  vmovaps [rsp+0x60], xmm6
000074ad747d5f00  vmovaps [rsp+0x70], xmm7
000074ad747d5f06  vmovaps [rsp+0x80], xmm8
000074ad747d5f0f  vmovaps [rsp+0x90], xmm9
000074ad747d5f18  vmovaps [rsp+0xA0], xmm10
000074ad747d5f21  vmovaps [rsp+0xB0], xmm11
000074ad747d5f2a  vmovaps [rsp+0xC0], xmm12
000074ad747d5f33  vmovaps [rsp+0xD0], xmm13
000074ad747d5f3c  vmovaps [rsp+0xE0], xmm15
000074ad747d5f45  sub rsp, 0x40
000074ad747d5f49  lea rdi, [rsp]
000074ad747d5f4d  lea rsi, [rsp+0x10]
000074ad747d5f52  lea rdx, [rsp+0x20]
000074ad747d5f57  lea rcx, [rsp+0x30]
000074ad747d5f5c  mov r8d, 0x00
000074ad747d5f62  lea r9, [r15+0x3A8]
000074ad747d5f69  movaps [rdi], xmm14
000074ad747d5f6d  movaps [rsi], xmm13
000074ad747d5f71  movaps [rdx], xmm1
000074ad747d5f74  movaps [rcx], xmm15
000074ad747d5f78  mov rax, 0x5C17501CEA50
000074ad747d5f82  call rax
000074ad747d5f84  movaps xmm14, [rsp]
000074ad747d5f89  add rsp, 0x40
000074ad747d5f8d  vmovaps xmm0, [rsp]
000074ad747d5f92  vmovaps xmm1, [rsp+0x10]
000074ad747d5f98  vmovaps xmm2, [rsp+0x20]
000074ad747d5f9e  vmovaps xmm3, [rsp+0x30]
000074ad747d5fa4  vmovaps xmm4, [rsp+0x40]
000074ad747d5faa  vmovaps xmm5, [rsp+0x50]
000074ad747d5fb0  vmovaps xmm6, [rsp+0x60]
000074ad747d5fb6  vmovaps xmm7, [rsp+0x70]
000074ad747d5fbc  vmovaps xmm8, [rsp+0x80]
000074ad747d5fc5  vmovaps xmm9, [rsp+0x90]
000074ad747d5fce  vmovaps xmm10, [rsp+0xA0]
000074ad747d5fd7  vmovaps xmm11, [rsp+0xB0]
000074ad747d5fe0  vmovaps xmm12, [rsp+0xC0]
000074ad747d5fe9  vmovaps xmm13, [rsp+0xD0]
000074ad747d5ff2  vmovaps xmm15, [rsp+0xE0]
000074ad747d5ffb  add rsp, 0xF0
000074ad747d6002  pop r11
000074ad747d6004  pop r10
000074ad747d6006  pop r9
000074ad747d6008  pop r8
000074ad747d600a  pop rsi
000074ad747d600b  pop rdi
000074ad747d600c  pop rdx
000074ad747d600d  pop rcx
000074ad747d600e  pop rax
000074ad747d600f  add rsp, 0x08
000074ad747d6013  jmp 0x000074AD747D31C7
000074ad747d6018  call 0x000074AD746079B0
000074ad747d601d  jmp 0x000074AD747D31DA
000074ad747d6022  call 0x000074AD7460B100
000074ad747d6027  jmp 0x000074AD747D31E5
000074ad747d602c  call 0x000074AD74609E90
000074ad747d6031  jmp 0x000074AD747D31F0
000074ad747d6036  call 0x000074AD7460D600
000074ad747d603b  jmp 0x000074AD747D31FB
000074ad747d6040  int3
000074ad747d6041  nop [rax+rax*1], ax
000074ad747d604a  nop [rax+rax*1], ax
000074ad747d6050  mov rax, [r15+0x40]
000074ad747d6054  mov r14, [r15+0x58]
000074ad747d6058  lea r12, [rax+r14*1]
000074ad747d605c  vxorps xmm1, xmm1, xmm1
000074ad747d6060  vpbroadcastq xmm1, xmm1
000074ad747d6065  vxorps xmm15, xmm15, xmm15
000074ad747d606a  vpbroadcastq xmm15, xmm15
000074ad747d606f  lea rax, [r12+0x30]
000074ad747d6074  mov r11, [r13+rax*1]
000074ad747d6079  lea rax, [r12+0x38]
000074ad747d607e  mov r10, [r13+rax*1]
000074ad747d6083  movq xmm14, r11
000074ad747d6088  movq xmm13, r10
000074ad747d608d  movq xmm14, xmm14
000074ad747d6092  movq xmm13, xmm13
000074ad747d6097  vmovaps [rsp+0x10], xmm13
000074ad747d609d  movq xmm13, xmm13
000074ad747d60a2  movaps [r15+0x270], xmm13
000074ad747d60aa  movaps xmm13, [r15+0x160]
000074ad747d60b2  vmovaps [rsp+0x20], xmm13
000074ad747d60b8  vmovaps xmm12, [rsp+0x20]
000074ad747d60be  por xmm13, xmm12
000074ad747d60c3  lea rax, [r12+0x20]
000074ad747d60c8  mov r11, [r13+rax*1]
000074ad747d60cd  lea rax, [r12+0x28]
000074ad747d60d2  mov r10, [r13+rax*1]
000074ad747d60d7  movq xmm12, r11
000074ad747d60dc  movq xmm11, r10
000074ad747d60e1  movq xmm12, xmm12
000074ad747d60e6  movq xmm11, xmm11
000074ad747d60eb  movaps xmm10, [r15+0x2D0]
000074ad747d60f3  vmovaps [rsp+0x20], xmm10
000074ad747d60f9  vmovaps xmm9, [rsp+0x20]
000074ad747d60ff  por xmm10, xmm9
000074ad747d6104  movaps xmm9, [r15+0x300]
000074ad747d610c  vmovaps [rsp+0x20], xmm9
000074ad747d6112  vmovaps xmm8, [rsp+0x20]
000074ad747d6118  por xmm9, xmm8
000074ad747d611d  movaps xmm8, [r15+0x2B0]
000074ad747d6125  vmovaps [rsp+0x20], xmm8
000074ad747d612b  vmovaps xmm7, [rsp+0x20]
000074ad747d6131  por xmm8, xmm7
000074ad747d6136  movaps xmm7, [r15+0x180]
000074ad747d613e  vmovaps [rsp+0x20], xmm7
000074ad747d6144  vmovaps xmm6, [rsp+0x20]
000074ad747d614a  por xmm7, xmm6
000074ad747d614e  lea rax, [r12+0x10]
000074ad747d6153  mov r11, [r13+rax*1]
000074ad747d6158  lea rax, [r12+0x18]
000074ad747d615d  mov r10, [r13+rax*1]
000074ad747d6162  movq xmm6, r11
000074ad747d6167  movq xmm5, r10
000074ad747d616c  movq xmm6, xmm6
000074ad747d6170  movq xmm5, xmm5
000074ad747d6174  movaps xmm4, [r15+0x200]
000074ad747d617c  vmovaps [rsp+0x20], xmm4
000074ad747d6182  vmovaps xmm3, [rsp+0x20]
000074ad747d6188  por xmm4, xmm3
000074ad747d618c  movaps xmm3, [r15+0x1F0]
000074ad747d6194  vmovaps [rsp+0x20], xmm3
000074ad747d619a  vmovaps xmm2, [rsp+0x20]
000074ad747d61a0  por xmm3, xmm2
000074ad747d61a4  movaps xmm2, [r15+0x2E0]
000074ad747d61ac  vmovaps [rsp+0x20], xmm2
000074ad747d61b2  vmovaps [rsp+0x30], xmm1
000074ad747d61b8  vmovaps xmm1, [rsp+0x20]
000074ad747d61be  por xmm2, xmm1
000074ad747d61c2  movaps xmm1, [r15+0x2A0]
000074ad747d61ca  vmovaps [rsp+0x20], xmm1
000074ad747d61d0  vmovaps [rsp+0x40], xmm15
000074ad747d61d6  vmovaps xmm15, [rsp+0x20]
000074ad747d61dc  por xmm1, xmm15
000074ad747d61e1  movaps xmm15, [r15+0x280]
000074ad747d61e9  vmovaps [rsp+0x20], xmm15
000074ad747d61ef  vmovaps [rsp+0x50], xmm1
000074ad747d61f5  vmovaps xmm1, [rsp+0x20]
000074ad747d61fb  por xmm15, xmm1
000074ad747d6200  movaps xmm1, [r15+0x1C0]
000074ad747d6208  vmovaps [rsp+0x20], xmm1
000074ad747d620e  vmovaps [rsp+0x60], xmm15
000074ad747d6214  vmovaps xmm15, [rsp+0x20]
000074ad747d621a  por xmm1, xmm15
000074ad747d621f  movaps xmm15, [r15+0x210]
000074ad747d6227  vmovaps [rsp+0x20], xmm15
000074ad747d622d  vmovaps [rsp+0x70], xmm1
000074ad747d6233  vmovaps xmm1, [rsp+0x20]
000074ad747d6239  por xmm15, xmm1
000074ad747d623e  mov rax, [r13+r12*1]
000074ad747d6243  vmovq xmm1, rax
000074ad747d6248  vpbroadcastq xmm1, xmm1
000074ad747d624d  vmovaps [rsp+0x20], xmm1
000074ad747d6253  vxorps xmm1, xmm1, xmm1
000074ad747d6257  vpbroadcastq xmm1, xmm1
000074ad747d625c  mov rax, [r15+0xF8]
000074ad747d6263  vmovaps [rsp+0x80], xmm1
000074ad747d626c  movups xmm1, [r13+rax*1]
000074ad747d6272  vmovaps [rsp+0x90], xmm1
000074ad747d627b  vxorps xmm1, xmm1, xmm1
000074ad747d627f  vpbroadcastq xmm1, xmm1
000074ad747d6284  lea r11, [r12+0x08]
000074ad747d6289  mov r12, [r13+r11*1]
000074ad747d628e  vmovaps [rsp+0xA0], xmm1
000074ad747d6297  movq xmm1, r12
000074ad747d629c  movaps [r15+0x240], xmm1
000074ad747d62a4  mov r12, [r15+0x50]
000074ad747d62a8  lea r11, [r12+r14*1]
000074ad747d62ac  mov [r15+0x60], r11
000074ad747d62b0  lea r12, [r14+0x40]
000074ad747d62b4  mov [r15+0x58], r12
000074ad747d62b8  vmovaps xmm1, [rsp+0x30]
000074ad747d62be  vmovaps [rsp+0x30], xmm15
000074ad747d62c4  vmovaps xmm15, [rsp+0x90]
000074ad747d62cd  vmovaps [rsp+0x90], xmm14
000074ad747d62d6  vmovaps xmm14, [rsp+0x20]
000074ad747d62dc  vmovaps [rsp+0x20], xmm13
000074ad747d62e2  vmovaps [rsp+0xB0], xmm12
000074ad747d62eb  movaps xmm13, xmm1
000074ad747d62ef  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d62f4  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d62fa  vptest xmm12, xmm12
000074ad747d62ff  jnz 0x000074AD747D6D9C
000074ad747d6305  movaps xmm1, [r15+0x250]
000074ad747d630d  vmovaps xmm15, [rsp+0x40]
000074ad747d6313  vmovaps [rsp+0x40], xmm13
000074ad747d6319  movaps xmm12, xmm15
000074ad747d631d  vfmadd231pd xmm12, xmm1, xmm14
000074ad747d6322  vcmppd xmm13, xmm12, xmm12, 0x03
000074ad747d6328  vptest xmm13, xmm13
000074ad747d632d  jnz 0x000074AD747D6EF5
000074ad747d6333  movaps xmm15, [r15+0x1E0]
000074ad747d633b  vmovaps [rsp+0xC0], xmm15
000074ad747d6344  vmovaps xmm13, [rsp+0xC0]
000074ad747d634d  por xmm15, xmm13
000074ad747d6352  movaps xmm13, [r15+0x1D0]
000074ad747d635a  vmovaps [rsp+0xC0], xmm13
000074ad747d6363  vmovaps [rsp+0xD0], xmm1
000074ad747d636c  vmovaps xmm1, [rsp+0xC0]
000074ad747d6375  por xmm13, xmm1
000074ad747d637a  movaps xmm1, [r15+0x2C0]
000074ad747d6382  vmovaps [rsp+0xC0], xmm1
000074ad747d638b  vmovaps [rsp+0xE0], xmm15
000074ad747d6394  vmovaps xmm15, [rsp+0xC0]
000074ad747d639d  por xmm1, xmm15
000074ad747d63a2  movaps xmm15, [r15+0x290]
000074ad747d63aa  vmovaps [rsp+0xC0], xmm15
000074ad747d63b3  vmovaps [rsp+0xF0], xmm1
000074ad747d63bc  vmovaps xmm1, [rsp+0xC0]
000074ad747d63c5  por xmm15, xmm1
000074ad747d63ca  movaps xmm1, [r15+0x260]
000074ad747d63d2  vmovaps [rsp+0xC0], xmm1
000074ad747d63db  vmovaps [rsp+0x100], xmm15
000074ad747d63e4  vmovaps xmm15, [rsp+0xC0]
000074ad747d63ed  por xmm1, xmm15
000074ad747d63f2  vmovaps xmm15, [rsp+0xD0]
000074ad747d63fb  vmovaps [rsp+0xC0], xmm1
000074ad747d6404  vmovaps xmm1, [rsp+0xD0]
000074ad747d640d  por xmm15, xmm1
000074ad747d6412  lea r14, [rax+0xC0]
000074ad747d6419  movups xmm1, [r13+r14*1]
000074ad747d641f  mov [rsp+0xD0], rax
000074ad747d6427  xor eax, eax
000074ad747d6429  mov r14d, 0x200
000074ad747d642f  cmp r12, r14
000074ad747d6432  cmc
000074ad747d6433  lahf
000074ad747d6434  seto al
000074ad747d6437  mov [r15+0x108], eax
000074ad747d643e  vmovaps [rsp+0x110], xmm1
000074ad747d6447  vmovaps xmm1, [rsp+0x80]
000074ad747d6450  vmovaps [rsp+0x80], xmm15
000074ad747d6459  vmovaps xmm15, [rsp+0x110]
000074ad747d6462  vmovaps [rsp+0x110], xmm13
000074ad747d646b  vmovaps [rsp+0x120], xmm12
000074ad747d6474  movaps xmm13, xmm1
000074ad747d6478  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d647d  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d6483  vptest xmm12, xmm12
000074ad747d6488  jnz 0x000074AD747D7058
000074ad747d648e  mov rax, [rsp+0xD0]
000074ad747d6496  lea r14, [rax+0xB0]
000074ad747d649d  movups xmm1, [r13+r14*1]
000074ad747d64a3  vmovaps xmm15, [rsp+0xA0]
000074ad747d64ac  vmovaps [rsp+0xA0], xmm13
000074ad747d64b5  movaps xmm12, xmm15
000074ad747d64b9  vfmadd231pd xmm12, xmm1, xmm14
000074ad747d64be  vcmppd xmm13, xmm12, xmm12, 0x03
000074ad747d64c4  vptest xmm13, xmm13
000074ad747d64c9  jnz 0x000074AD747D71BB
000074ad747d64cf  vmovaps xmm1, [rsp+0x30]
000074ad747d64d5  vmovaps xmm15, [rsp+0x30]
000074ad747d64db  por xmm1, xmm15
000074ad747d64e0  movaps [r15+0x210], xmm1
000074ad747d64e8  vmovaps xmm15, [rsp+0x70]
000074ad747d64ee  vmovaps xmm14, [rsp+0x70]
000074ad747d64f4  por xmm15, xmm14
000074ad747d64f9  movaps [r15+0x1C0], xmm15
000074ad747d6501  vmovaps xmm14, [rsp+0x60]
000074ad747d6507  vmovaps xmm13, [rsp+0x60]
000074ad747d650d  por xmm14, xmm13
000074ad747d6512  movaps [r15+0x280], xmm14
000074ad747d651a  vmovaps xmm13, [rsp+0x50]
000074ad747d6520  vmovaps [rsp+0x30], xmm1
000074ad747d6526  vmovaps xmm1, [rsp+0x50]
000074ad747d652c  por xmm13, xmm1
000074ad747d6531  movaps [r15+0x2A0], xmm13
000074ad747d6539  vmovaps [rsp+0x50], xmm2
000074ad747d653f  vmovaps xmm1, [rsp+0x50]
000074ad747d6545  por xmm2, xmm1
000074ad747d6549  movaps [r15+0x2E0], xmm2
000074ad747d6551  vmovaps [rsp+0x50], xmm3
000074ad747d6557  vmovaps xmm1, [rsp+0x50]
000074ad747d655d  por xmm3, xmm1
000074ad747d6561  movaps [r15+0x1F0], xmm3
000074ad747d6569  vmovaps xmm1, [rsp+0x80]
000074ad747d6572  vmovaps [rsp+0x50], xmm15
000074ad747d6578  vmovaps xmm15, [rsp+0x80]
000074ad747d6581  por xmm1, xmm15
000074ad747d6586  movaps [r15+0x250], xmm1
000074ad747d658e  vmovaps xmm1, [rsp+0xC0]
000074ad747d6597  vmovaps xmm15, [rsp+0xC0]
000074ad747d65a0  por xmm1, xmm15
000074ad747d65a5  movaps [r15+0x260], xmm1
000074ad747d65ad  vmovaps xmm15, [rsp+0x100]
000074ad747d65b6  vmovaps [rsp+0x60], xmm1
000074ad747d65bc  vmovaps xmm1, [rsp+0x100]
000074ad747d65c5  por xmm15, xmm1
000074ad747d65ca  movaps [r15+0x290], xmm15
000074ad747d65d2  vmovaps xmm1, [rsp+0xF0]
000074ad747d65db  vmovaps [rsp+0x70], xmm15
000074ad747d65e1  vmovaps xmm15, [rsp+0xF0]
000074ad747d65ea  por xmm1, xmm15
000074ad747d65ef  movaps [r15+0x2C0], xmm1
000074ad747d65f7  movq xmm15, qword ptr [r15+0x240]
000074ad747d6600  vmovaps [rsp+0x80], xmm15
000074ad747d6609  vpermilpd xmm15, xmm15, 0x00
000074ad747d660f  vmovaps [rsp+0xC0], xmm1
000074ad747d6618  vmovaps xmm1, [rsp+0x40]
000074ad747d661e  vmovaps [rsp+0x40], xmm15
000074ad747d6624  vmovaps xmm15, [rsp+0x30]
000074ad747d662a  vmovaps [rsp+0x30], xmm14
000074ad747d6630  vmovaps xmm14, [rsp+0x40]
000074ad747d6636  vmovaps [rsp+0x40], xmm13
000074ad747d663c  vmovaps [rsp+0xD0], xmm12
000074ad747d6645  movaps xmm13, xmm1
000074ad747d6649  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d664e  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d6654  vptest xmm12, xmm12
000074ad747d6659  jnz 0x000074AD747D7314
000074ad747d665f  vmovaps xmm1, [rsp+0x80]
000074ad747d6668  vpermilpd xmm1, xmm1, 0x00
000074ad747d666e  vmovaps xmm15, [rsp+0xA0]
000074ad747d6677  movaps xmm14, xmm15
000074ad747d667b  vfmadd231pd xmm14, xmm2, xmm1
000074ad747d6680  vcmppd xmm12, xmm14, xmm14, 0x03
000074ad747d6686  vptest xmm12, xmm12
000074ad747d668b  jnz 0x000074AD747D746D
000074ad747d6691  vmovaps xmm1, [rsp+0x80]
000074ad747d669a  vpermilpd xmm1, xmm1, 0x00
000074ad747d66a0  vmovaps xmm15, [rsp+0x120]
000074ad747d66a9  vmovaps xmm12, [rsp+0x50]
000074ad747d66af  vmovaps [rsp+0x50], xmm14
000074ad747d66b5  movaps xmm2, xmm15
000074ad747d66b9  vfmadd231pd xmm2, xmm12, xmm1
000074ad747d66be  vcmppd xmm14, xmm2, xmm2, 0x03
000074ad747d66c3  vptest xmm14, xmm14
000074ad747d66c8  jnz 0x000074AD747D75C5
000074ad747d66ce  vmovaps xmm1, [rsp+0x110]
000074ad747d66d7  vmovaps xmm15, [rsp+0x110]
000074ad747d66e0  por xmm1, xmm15
000074ad747d66e5  movaps [r15+0x1D0], xmm1
000074ad747d66ed  vmovaps xmm15, [rsp+0x80]
000074ad747d66f6  vpermilpd xmm15, xmm15, 0x00
000074ad747d66fc  vmovaps xmm14, [rsp+0xD0]
000074ad747d6705  vmovaps [rsp+0x80], xmm1
000074ad747d670e  movaps xmm12, xmm14
000074ad747d6712  vfmadd231pd xmm12, xmm3, xmm15
000074ad747d6717  vcmppd xmm1, xmm12, xmm12, 0x03
000074ad747d671d  vptest xmm1, xmm1
000074ad747d6722  jnz 0x000074AD747D771C
000074ad747d6728  vmovaps [rsp+0xA0], xmm4
000074ad747d6731  vmovaps xmm1, [rsp+0xA0]
000074ad747d673a  por xmm4, xmm1
000074ad747d673e  movaps [r15+0x200], xmm4
000074ad747d6746  vmovaps xmm1, [rsp+0xE0]
000074ad747d674f  vmovaps xmm15, [rsp+0xE0]
000074ad747d6758  por xmm1, xmm15
000074ad747d675d  movaps [r15+0x1E0], xmm1
000074ad747d6765  vmovaps [rsp+0xA0], xmm8
000074ad747d676e  vmovaps xmm1, [rsp+0xA0]
000074ad747d6777  por xmm8, xmm1
000074ad747d677c  movaps [r15+0x2B0], xmm8
000074ad747d6784  vmovaps [rsp+0xA0], xmm9
000074ad747d678d  vmovaps xmm1, [rsp+0xA0]
000074ad747d6796  por xmm9, xmm1
000074ad747d679b  movaps [r15+0x300], xmm9
000074ad747d67a3  vmovaps [rsp+0xA0], xmm6
000074ad747d67ac  vpermilpd xmm6, xmm6, 0x00
000074ad747d67b2  vmovaps xmm14, [rsp+0x60]
000074ad747d67b8  movaps xmm9, xmm13
000074ad747d67bc  vfmadd231pd xmm9, xmm14, xmm6
000074ad747d67c1  vcmppd xmm3, xmm9, xmm9, 0x03
000074ad747d67c7  vptest xmm3, xmm3
000074ad747d67cc  jnz 0x000074AD747D7875
000074ad747d67d2  vmovaps xmm14, [rsp+0xA0]
000074ad747d67db  vpermilpd xmm14, xmm14, 0x00
000074ad747d67e1  vmovaps xmm13, [rsp+0x50]
000074ad747d67e7  vmovaps xmm6, [rsp+0xC0]
000074ad747d67f0  vmovaps [rsp+0x50], xmm1
000074ad747d67f6  movaps xmm3, xmm13
000074ad747d67fa  vfmadd231pd xmm3, xmm6, xmm14
000074ad747d67ff  vcmppd xmm1, xmm3, xmm3, 0x03
000074ad747d6804  vptest xmm1, xmm1
000074ad747d6809  jnz 0x000074AD747D79CE
000074ad747d680f  vmovaps xmm1, [rsp+0xA0]
000074ad747d6818  vpermilpd xmm1, xmm1, 0x00
000074ad747d681e  vmovaps xmm14, [rsp+0x30]
000074ad747d6824  movaps xmm6, xmm2
000074ad747d6827  vfmadd231pd xmm6, xmm14, xmm1
000074ad747d682c  vcmppd xmm13, xmm6, xmm6, 0x03
000074ad747d6831  vptest xmm13, xmm13
000074ad747d6836  jnz 0x000074AD747D7B25
000074ad747d683c  vmovaps xmm1, [rsp+0xA0]
000074ad747d6845  vpermilpd xmm1, xmm1, 0x00
000074ad747d684b  vmovaps xmm14, [rsp+0x80]
000074ad747d6854  movaps xmm13, xmm12
000074ad747d6858  vfmadd231pd xmm13, xmm14, xmm1
000074ad747d685d  vcmppd xmm2, xmm13, xmm13, 0x03
000074ad747d6863  vptest xmm2, xmm2
000074ad747d6868  jnz 0x000074AD747D7C7B
000074ad747d686e  vmovaps [rsp+0x30], xmm7
000074ad747d6874  vmovaps xmm1, [rsp+0x30]
000074ad747d687a  por xmm7, xmm1
000074ad747d687e  movaps [r15+0x180], xmm7
000074ad747d6886  vmovaps [rsp+0x30], xmm10
000074ad747d688c  vmovaps xmm1, [rsp+0x30]
000074ad747d6892  por xmm10, xmm1
000074ad747d6897  movaps [r15+0x2D0], xmm10
000074ad747d689f  vmovaps [rsp+0x30], xmm5
000074ad747d68a5  vpermilpd xmm5, xmm5, 0x00
000074ad747d68ab  vmovaps xmm14, [rsp+0x50]
000074ad747d68b1  movaps xmm12, xmm3
000074ad747d68b5  vfmadd231pd xmm12, xmm14, xmm5
000074ad747d68ba  vcmppd xmm10, xmm12, xmm12, 0x03
000074ad747d68c0  vptest xmm10, xmm10
000074ad747d68c5  jnz 0x000074AD747D7DD4
000074ad747d68cb  vmovaps xmm14, [rsp+0x30]
000074ad747d68d1  vpermilpd xmm14, xmm14, 0x00
000074ad747d68d7  movaps xmm10, xmm9
000074ad747d68db  vfmadd231pd xmm10, xmm7, xmm14
000074ad747d68e0  vcmppd xmm5, xmm10, xmm10, 0x03
000074ad747d68e6  vptest xmm5, xmm5
000074ad747d68eb  jnz 0x000074AD747D7F2C
000074ad747d68f1  lea r14, [rax+0x80]
000074ad747d68f8  movups xmm14, [r13+r14*1]
000074ad747d68fe  movaps [r15+0x2F0], xmm14
000074ad747d6906  vmovaps xmm9, [rsp+0x30]
000074ad747d690c  vpermilpd xmm9, xmm9, 0x00
000074ad747d6912  vmovaps xmm7, [rsp+0x70]
000074ad747d6918  movaps xmm5, xmm6
000074ad747d691b  vfmadd231pd xmm5, xmm7, xmm9
000074ad747d6920  vcmppd xmm3, xmm5, xmm5, 0x03
000074ad747d6925  vptest xmm3, xmm3
000074ad747d692a  jnz 0x000074AD747D808F
000074ad747d6930  vmovaps xmm9, [rsp+0x30]
000074ad747d6936  vpermilpd xmm9, xmm9, 0x00
000074ad747d693c  movaps xmm7, xmm13
000074ad747d6940  vfmadd231pd xmm7, xmm1, xmm9
000074ad747d6945  vcmppd xmm6, xmm7, xmm7, 0x03
000074ad747d694a  vptest xmm6, xmm6
000074ad747d694f  jnz 0x000074AD747D81E5
000074ad747d6955  vmovaps xmm1, [rsp+0x20]
000074ad747d695b  vmovaps xmm13, [rsp+0x20]
000074ad747d6961  por xmm1, xmm13
000074ad747d6966  movaps [r15+0x160], xmm1
000074ad747d696e  lea r14, [rax+0x40]
000074ad747d6972  movups xmm13, [r13+r14*1]
000074ad747d6978  lea r14, [rax+0x50]
000074ad747d697c  movups xmm9, [r13+r14*1]
000074ad747d6982  movaps [r15+0x1B0], xmm13
000074ad747d698a  movaps [r15+0x1A0], xmm9
000074ad747d6992  movaps xmm6, [r15+0x190]
000074ad747d699a  vmovaps xmm3, [rsp+0xB0]
000074ad747d69a3  vpermilpd xmm3, xmm3, 0x00
000074ad747d69a9  vmovaps [rsp+0x20], xmm1
000074ad747d69af  movaps xmm2, xmm12
000074ad747d69b3  vfmadd231pd xmm2, xmm6, xmm3
000074ad747d69b8  vcmppd xmm1, xmm2, xmm2, 0x03
000074ad747d69bd  vptest xmm1, xmm1
000074ad747d69c2  jnz 0x000074AD747D8350
000074ad747d69c8  vmovaps xmm1, [rsp+0xB0]
000074ad747d69d1  vpermilpd xmm1, xmm1, 0x00
000074ad747d69d7  vmovaps xmm12, [rsp+0x20]
000074ad747d69dd  movaps xmm6, xmm10
000074ad747d69e1  vfmadd231pd xmm6, xmm12, xmm1
000074ad747d69e6  vcmppd xmm3, xmm6, xmm6, 0x03
000074ad747d69eb  vptest xmm3, xmm3
000074ad747d69f0  jnz 0x000074AD747D84A6
000074ad747d69f6  vmovaps xmm1, [rsp+0xB0]
000074ad747d69ff  vpermilpd xmm1, xmm1, 0x00
000074ad747d6a05  vmovaps xmm12, [rsp+0x40]
000074ad747d6a0b  movaps xmm10, xmm5
000074ad747d6a0f  vfmadd231pd xmm10, xmm12, xmm1
000074ad747d6a14  vcmppd xmm3, xmm10, xmm10, 0x03
000074ad747d6a1a  vptest xmm3, xmm3
000074ad747d6a1f  jnz 0x000074AD747D85FD
000074ad747d6a25  vmovaps xmm1, [rsp+0xB0]
000074ad747d6a2e  vpermilpd xmm1, xmm1, 0x00
000074ad747d6a34  movaps xmm12, xmm7
000074ad747d6a38  vfmadd231pd xmm12, xmm15, xmm1
000074ad747d6a3d  vcmppd xmm5, xmm12, xmm12, 0x03
000074ad747d6a43  vptest xmm5, xmm5
000074ad747d6a48  jnz 0x000074AD747D8755
000074ad747d6a4e  lea r14, [rax+0x60]
000074ad747d6a52  movups xmm1, [r13+r14*1]
000074ad747d6a58  lea r14, [rax+0x70]
000074ad747d6a5c  movups xmm15, [r13+r14*1]
000074ad747d6a62  movaps [r15+0x150], xmm1
000074ad747d6a6a  movaps [r15+0x120], xmm15
000074ad747d6a72  vmovaps [rsp+0x20], xmm11
000074ad747d6a78  vpermilpd xmm11, xmm11, 0x00
000074ad747d6a7e  movaps xmm7, xmm2
000074ad747d6a81  vfmadd231pd xmm7, xmm9, xmm11
000074ad747d6a86  vcmppd xmm5, xmm7, xmm7, 0x03
000074ad747d6a8b  vptest xmm5, xmm5
000074ad747d6a90  jnz 0x000074AD747D88C1
000074ad747d6a96  vmovaps xmm11, [rsp+0x20]
000074ad747d6a9c  vpermilpd xmm11, xmm11, 0x00
000074ad747d6aa2  movaps xmm9, xmm6
000074ad747d6aa6  vfmadd231pd xmm9, xmm1, xmm11
000074ad747d6aab  vcmppd xmm5, xmm9, xmm9, 0x03
000074ad747d6ab1  vptest xmm5, xmm5
000074ad747d6ab6  jnz 0x000074AD747D8A18
000074ad747d6abc  vmovaps xmm1, [rsp+0x20]
000074ad747d6ac2  vpermilpd xmm1, xmm1, 0x00
000074ad747d6ac8  movaps xmm11, xmm10
000074ad747d6acc  vfmadd231pd xmm11, xmm8, xmm1
000074ad747d6ad1  vcmppd xmm6, xmm11, xmm11, 0x03
000074ad747d6ad7  vptest xmm6, xmm6
000074ad747d6adc  jnz 0x000074AD747D8B70
000074ad747d6ae2  vmovaps xmm1, [rsp+0x20]
000074ad747d6ae8  vpermilpd xmm1, xmm1, 0x00
000074ad747d6aee  movaps xmm10, xmm12
000074ad747d6af2  vfmadd231pd xmm10, xmm13, xmm1
000074ad747d6af7  vcmppd xmm8, xmm10, xmm10, 0x03
000074ad747d6afd  vptest xmm8, xmm8
000074ad747d6b02  jnz 0x000074AD747D8CC9
000074ad747d6b08  lea r14, [rax+0x20]
000074ad747d6b0c  movups xmm1, [r13+r14*1]
000074ad747d6b12  lea r14, [rax+0x30]
000074ad747d6b16  movups xmm13, [r13+r14*1]
000074ad747d6b1c  vmovaps xmm12, [rsp+0x90]
000074ad747d6b25  vpermilpd xmm12, xmm12, 0x00
000074ad747d6b2b  movaps xmm8, xmm7
000074ad747d6b2f  vfmadd231pd xmm8, xmm4, xmm12
000074ad747d6b34  vcmppd xmm6, xmm8, xmm8, 0x03
000074ad747d6b3a  vptest xmm6, xmm6
000074ad747d6b3f  jnz 0x000074AD747D8E36
000074ad747d6b45  vmovaps xmm12, [rsp+0x90]
000074ad747d6b4e  vpermilpd xmm12, xmm12, 0x00
000074ad747d6b54  movaps xmm7, xmm9
000074ad747d6b58  vfmadd231pd xmm7, xmm14, xmm12
000074ad747d6b5d  vcmppd xmm6, xmm7, xmm7, 0x03
000074ad747d6b62  vptest xmm6, xmm6
000074ad747d6b67  jnz 0x000074AD747D8F8E
000074ad747d6b6d  vmovaps xmm14, [rsp+0x90]
000074ad747d6b76  vpermilpd xmm14, xmm14, 0x00
000074ad747d6b7c  movaps xmm12, xmm11
000074ad747d6b80  vfmadd231pd xmm12, xmm15, xmm14
000074ad747d6b85  vcmppd xmm9, xmm12, xmm12, 0x03
000074ad747d6b8b  vptest xmm9, xmm9
000074ad747d6b90  jnz 0x000074AD747D90E6
000074ad747d6b96  vmovaps xmm15, [rsp+0x90]
000074ad747d6b9f  vpermilpd xmm15, xmm15, 0x00
000074ad747d6ba5  movaps xmm11, xmm10
000074ad747d6ba9  vfmadd231pd xmm11, xmm13, xmm15
000074ad747d6bae  vcmppd xmm14, xmm11, xmm11, 0x03
000074ad747d6bb4  vptest xmm14, xmm14
000074ad747d6bb9  jnz 0x000074AD747D9240
000074ad747d6bbf  lea r14, [rax+0x90]
000074ad747d6bc6  movups xmm15, [r13+r14*1]
000074ad747d6bcc  lea r14, [rax+0xA0]
000074ad747d6bd3  movups xmm14, [r13+r14*1]
000074ad747d6bd9  movaps [r15+0x140], xmm15
000074ad747d6be1  movaps [r15+0x130], xmm14
000074ad747d6be9  vmovaps xmm13, [rsp+0x10]
000074ad747d6bef  vpermilpd xmm13, xmm13, 0x00
000074ad747d6bf5  movaps xmm10, xmm8
000074ad747d6bf9  vfmadd231pd xmm10, xmm1, xmm13
000074ad747d6bfe  vcmppd xmm9, xmm10, xmm10, 0x03
000074ad747d6c04  vptest xmm9, xmm9
000074ad747d6c09  jnz 0x000074AD747D93AE
000074ad747d6c0f  movaps [r15+0x220], xmm10
000074ad747d6c17  lea r14, [rax+0x10]
000074ad747d6c1b  movups xmm1, [r13+r14*1]
000074ad747d6c21  movaps [r15+0x240], xmm1
000074ad747d6c29  vmovaps xmm13, [rsp+0x10]
000074ad747d6c2f  vpermilpd xmm13, xmm13, 0x00
000074ad747d6c35  movaps xmm9, xmm7
000074ad747d6c39  vfmadd231pd xmm9, xmm14, xmm13
000074ad747d6c3e  vcmppd xmm8, xmm9, xmm9, 0x03
000074ad747d6c44  vptest xmm8, xmm8
000074ad747d6c49  jnz 0x000074AD747D9511
000074ad747d6c4f  movaps [r15+0x110], xmm9
000074ad747d6c57  vmovaps xmm14, [rsp+0x10]
000074ad747d6c5d  vpermilpd xmm14, xmm14, 0x00
000074ad747d6c63  movaps xmm13, xmm12
000074ad747d6c67  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d6c6c  vcmppd xmm8, xmm13, xmm13, 0x03
000074ad747d6c72  vptest xmm8, xmm8
000074ad747d6c77  jnz 0x000074AD747D966A
000074ad747d6c7d  movaps [r15+0x170], xmm13
000074ad747d6c85  vmovaps xmm15, [rsp+0x10]
000074ad747d6c8b  vpermilpd xmm15, xmm15, 0x00
000074ad747d6c91  movaps xmm14, xmm11
000074ad747d6c95  vfmadd231pd xmm14, xmm1, xmm15
000074ad747d6c9a  vcmppd xmm12, xmm14, xmm14, 0x03
000074ad747d6ca0  vptest xmm12, xmm12
000074ad747d6ca5  jnz 0x000074AD747D97C4
000074ad747d6cab  movaps [r15+0x230], xmm14
000074ad747d6cb3  movups [r13+r11*1], xmm9
000074ad747d6cb9  lea rax, [r11+0x10]
000074ad747d6cbd  movups [r13+rax*1], xmm13
000074ad747d6cc3  lea rax, [r11+0x20]
000074ad747d6cc7  movups [r13+rax*1], xmm10
000074ad747d6ccd  lea rax, [r11+0x30]
000074ad747d6cd1  movups [r13+rax*1], xmm14
000074ad747d6cd7  mov eax, [r15+0x108]
000074ad747d6cde  sahf
000074ad747d6cdf  jnz 0x000074AD747D6D11
000074ad747d6ce1  cmp dword ptr [r15+0x318], 0x00
000074ad747d6ce9  jz 0x000074AD747D9950
000074ad747d6cef  nop [rax+rax*1], ax
000074ad747d6cf8  nop [rax+rax*1], eax
000074ad747d6d00  mov eax, 0x410664
000074ad747d6d05  mov [r15+0x100], rax
000074ad747d6d0c  jmp 0x000074AD745FE110
000074ad747d6d11  cmp dword ptr [r15+0x318], 0x00
000074ad747d6d19  jz 0x000074AD747D6050
000074ad747d6d1f  nop [rax+rax*1], ax
000074ad747d6d28  nop [rax+rax*1], eax
000074ad747d6d30  mov eax, 0x4104F0
000074ad747d6d35  mov [r15+0x100], rax
000074ad747d6d3c  jmp 0x000074AD745FE110
000074ad747d6d41  int3
000074ad747d6d42  call 0x000074AD7460A4B0
000074ad747d6d47  jmp 0x000074AD747D6079
000074ad747d6d4c  call 0x000074AD74609240
000074ad747d6d51  jmp 0x000074AD747D6083
000074ad747d6d56  call 0x000074AD7460A4B0
000074ad747d6d5b  jmp 0x000074AD747D60CD
000074ad747d6d60  call 0x000074AD74609240
000074ad747d6d65  jmp 0x000074AD747D60D7
000074ad747d6d6a  call 0x000074AD7460A4B0
000074ad747d6d6f  jmp 0x000074AD747D6158
000074ad747d6d74  call 0x000074AD74609240
000074ad747d6d79  jmp 0x000074AD747D6162
000074ad747d6d7e  call 0x000074AD746B47C0
000074ad747d6d83  jmp 0x000074AD747D6243
000074ad747d6d88  call 0x000074AD745FF430
000074ad747d6d8d  jmp 0x000074AD747D6272
000074ad747d6d92  call 0x000074AD746B0CE0
000074ad747d6d97  jmp 0x000074AD747D628E
000074ad747d6d9c  sub rsp, 0x08
000074ad747d6da0  push rax
000074ad747d6da1  push rcx
000074ad747d6da2  push rdx
000074ad747d6da3  push rdi
000074ad747d6da4  push rsi
000074ad747d6da5  push r8
000074ad747d6da7  push r9
000074ad747d6da9  push r10
000074ad747d6dab  push r11
000074ad747d6dad  sub rsp, 0xF0
000074ad747d6db4  vmovaps [rsp], xmm0
000074ad747d6db9  vmovaps [rsp+0x10], xmm1
000074ad747d6dbf  vmovaps [rsp+0x20], xmm2
000074ad747d6dc5  vmovaps [rsp+0x30], xmm3
000074ad747d6dcb  vmovaps [rsp+0x40], xmm4
000074ad747d6dd1  vmovaps [rsp+0x50], xmm5
000074ad747d6dd7  vmovaps [rsp+0x60], xmm6
000074ad747d6ddd  vmovaps [rsp+0x70], xmm7
000074ad747d6de3  vmovaps [rsp+0x80], xmm8
000074ad747d6dec  vmovaps [rsp+0x90], xmm9
000074ad747d6df5  vmovaps [rsp+0xA0], xmm10
000074ad747d6dfe  vmovaps [rsp+0xB0], xmm11
000074ad747d6e07  vmovaps [rsp+0xC0], xmm12
000074ad747d6e10  vmovaps [rsp+0xD0], xmm14
000074ad747d6e19  vmovaps [rsp+0xE0], xmm15
000074ad747d6e22  sub rsp, 0x40
000074ad747d6e26  lea rdi, [rsp]
000074ad747d6e2a  lea rsi, [rsp+0x10]
000074ad747d6e2f  lea rdx, [rsp+0x20]
000074ad747d6e34  lea rcx, [rsp+0x30]
000074ad747d6e39  mov r8d, 0x00
000074ad747d6e3f  lea r9, [r15+0x3A8]
000074ad747d6e46  movaps [rdi], xmm13
000074ad747d6e4a  movaps [rsi], xmm1
000074ad747d6e4d  movaps [rdx], xmm15
000074ad747d6e51  movaps [rcx], xmm14
000074ad747d6e55  mov rax, 0x5C17501CEA50
000074ad747d6e5f  call rax
000074ad747d6e61  movaps xmm13, [rsp]
000074ad747d6e66  add rsp, 0x40
000074ad747d6e6a  vmovaps xmm0, [rsp]
000074ad747d6e6f  vmovaps xmm1, [rsp+0x10]
000074ad747d6e75  vmovaps xmm2, [rsp+0x20]
000074ad747d6e7b  vmovaps xmm3, [rsp+0x30]
000074ad747d6e81  vmovaps xmm4, [rsp+0x40]
000074ad747d6e87  vmovaps xmm5, [rsp+0x50]
000074ad747d6e8d  vmovaps xmm6, [rsp+0x60]
000074ad747d6e93  vmovaps xmm7, [rsp+0x70]
000074ad747d6e99  vmovaps xmm8, [rsp+0x80]
000074ad747d6ea2  vmovaps xmm9, [rsp+0x90]
000074ad747d6eab  vmovaps xmm10, [rsp+0xA0]
000074ad747d6eb4  vmovaps xmm11, [rsp+0xB0]
000074ad747d6ebd  vmovaps xmm12, [rsp+0xC0]
000074ad747d6ec6  vmovaps xmm14, [rsp+0xD0]
000074ad747d6ecf  vmovaps xmm15, [rsp+0xE0]
000074ad747d6ed8  add rsp, 0xF0
000074ad747d6edf  pop r11
000074ad747d6ee1  pop r10
000074ad747d6ee3  pop r9
000074ad747d6ee5  pop r8
000074ad747d6ee7  pop rsi
000074ad747d6ee8  pop rdi
000074ad747d6ee9  pop rdx
000074ad747d6eea  pop rcx
000074ad747d6eeb  pop rax
000074ad747d6eec  add rsp, 0x08
000074ad747d6ef0  jmp 0x000074AD747D6305
000074ad747d6ef5  sub rsp, 0x08
000074ad747d6ef9  push rax
000074ad747d6efa  push rcx
000074ad747d6efb  push rdx
000074ad747d6efc  push rdi
000074ad747d6efd  push rsi
000074ad747d6efe  push r8
000074ad747d6f00  push r9
000074ad747d6f02  push r10
000074ad747d6f04  push r11
000074ad747d6f06  sub rsp, 0xF0
000074ad747d6f0d  vmovaps [rsp], xmm0
000074ad747d6f12  vmovaps [rsp+0x10], xmm1
000074ad747d6f18  vmovaps [rsp+0x20], xmm2
000074ad747d6f1e  vmovaps [rsp+0x30], xmm3
000074ad747d6f24  vmovaps [rsp+0x40], xmm4
000074ad747d6f2a  vmovaps [rsp+0x50], xmm5
000074ad747d6f30  vmovaps [rsp+0x60], xmm6
000074ad747d6f36  vmovaps [rsp+0x70], xmm7
000074ad747d6f3c  vmovaps [rsp+0x80], xmm8
000074ad747d6f45  vmovaps [rsp+0x90], xmm9
000074ad747d6f4e  vmovaps [rsp+0xA0], xmm10
000074ad747d6f57  vmovaps [rsp+0xB0], xmm11
000074ad747d6f60  vmovaps [rsp+0xC0], xmm13
000074ad747d6f69  vmovaps [rsp+0xD0], xmm14
000074ad747d6f72  vmovaps [rsp+0xE0], xmm15
000074ad747d6f7b  sub rsp, 0x40
000074ad747d6f7f  lea rdi, [rsp]
000074ad747d6f83  lea rsi, [rsp+0x10]
000074ad747d6f88  lea rdx, [rsp+0x20]
000074ad747d6f8d  lea rcx, [rsp+0x30]
000074ad747d6f92  mov r8d, 0x00
000074ad747d6f98  lea r9, [r15+0x3A8]
000074ad747d6f9f  movaps [rdi], xmm12
000074ad747d6fa3  movaps [rsi], xmm15
000074ad747d6fa7  movaps [rdx], xmm1
000074ad747d6faa  movaps [rcx], xmm14
000074ad747d6fae  mov rax, 0x5C17501CEA50
000074ad747d6fb8  call rax
000074ad747d6fba  movaps xmm12, [rsp]
000074ad747d6fbf  add rsp, 0x40
000074ad747d6fc3  vmovaps xmm0, [rsp]
000074ad747d6fc8  vmovaps xmm1, [rsp+0x10]
000074ad747d6fce  vmovaps xmm2, [rsp+0x20]
000074ad747d6fd4  vmovaps xmm3, [rsp+0x30]
000074ad747d6fda  vmovaps xmm4, [rsp+0x40]
000074ad747d6fe0  vmovaps xmm5, [rsp+0x50]
000074ad747d6fe6  vmovaps xmm6, [rsp+0x60]
000074ad747d6fec  vmovaps xmm7, [rsp+0x70]
000074ad747d6ff2  vmovaps xmm8, [rsp+0x80]
000074ad747d6ffb  vmovaps xmm9, [rsp+0x90]
000074ad747d7004  vmovaps xmm10, [rsp+0xA0]
000074ad747d700d  vmovaps xmm11, [rsp+0xB0]
000074ad747d7016  vmovaps xmm13, [rsp+0xC0]
000074ad747d701f  vmovaps xmm14, [rsp+0xD0]
000074ad747d7028  vmovaps xmm15, [rsp+0xE0]
000074ad747d7031  add rsp, 0xF0
000074ad747d7038  pop r11
000074ad747d703a  pop r10
000074ad747d703c  pop r9
000074ad747d703e  pop r8
000074ad747d7040  pop rsi
000074ad747d7041  pop rdi
000074ad747d7042  pop rdx
000074ad747d7043  pop rcx
000074ad747d7044  pop rax
000074ad747d7045  add rsp, 0x08
000074ad747d7049  jmp 0x000074AD747D6333
000074ad747d704e  call 0x000074AD746D64F0
000074ad747d7053  jmp 0x000074AD747D641F
000074ad747d7058  sub rsp, 0x08
000074ad747d705c  push rax
000074ad747d705d  push rcx
000074ad747d705e  push rdx
000074ad747d705f  push rdi
000074ad747d7060  push rsi
000074ad747d7061  push r8
000074ad747d7063  push r9
000074ad747d7065  push r10
000074ad747d7067  push r11
000074ad747d7069  sub rsp, 0xF0
000074ad747d7070  vmovaps [rsp], xmm0
000074ad747d7075  vmovaps [rsp+0x10], xmm1
000074ad747d707b  vmovaps [rsp+0x20], xmm2
000074ad747d7081  vmovaps [rsp+0x30], xmm3
000074ad747d7087  vmovaps [rsp+0x40], xmm4
000074ad747d708d  vmovaps [rsp+0x50], xmm5
000074ad747d7093  vmovaps [rsp+0x60], xmm6
000074ad747d7099  vmovaps [rsp+0x70], xmm7
000074ad747d709f  vmovaps [rsp+0x80], xmm8
000074ad747d70a8  vmovaps [rsp+0x90], xmm9
000074ad747d70b1  vmovaps [rsp+0xA0], xmm10
000074ad747d70ba  vmovaps [rsp+0xB0], xmm11
000074ad747d70c3  vmovaps [rsp+0xC0], xmm12
000074ad747d70cc  vmovaps [rsp+0xD0], xmm14
000074ad747d70d5  vmovaps [rsp+0xE0], xmm15
000074ad747d70de  sub rsp, 0x40
000074ad747d70e2  lea rdi, [rsp]
000074ad747d70e6  lea rsi, [rsp+0x10]
000074ad747d70eb  lea rdx, [rsp+0x20]
000074ad747d70f0  lea rcx, [rsp+0x30]
000074ad747d70f5  mov r8d, 0x00
000074ad747d70fb  lea r9, [r15+0x3A8]
000074ad747d7102  movaps [rdi], xmm13
000074ad747d7106  movaps [rsi], xmm1
000074ad747d7109  movaps [rdx], xmm15
000074ad747d710d  movaps [rcx], xmm14
000074ad747d7111  mov rax, 0x5C17501CEA50
000074ad747d711b  call rax
000074ad747d711d  movaps xmm13, [rsp]
000074ad747d7122  add rsp, 0x40
000074ad747d7126  vmovaps xmm0, [rsp]
000074ad747d712b  vmovaps xmm1, [rsp+0x10]
000074ad747d7131  vmovaps xmm2, [rsp+0x20]
000074ad747d7137  vmovaps xmm3, [rsp+0x30]
000074ad747d713d  vmovaps xmm4, [rsp+0x40]
000074ad747d7143  vmovaps xmm5, [rsp+0x50]
000074ad747d7149  vmovaps xmm6, [rsp+0x60]
000074ad747d714f  vmovaps xmm7, [rsp+0x70]
000074ad747d7155  vmovaps xmm8, [rsp+0x80]
000074ad747d715e  vmovaps xmm9, [rsp+0x90]
000074ad747d7167  vmovaps xmm10, [rsp+0xA0]
000074ad747d7170  vmovaps xmm11, [rsp+0xB0]
000074ad747d7179  vmovaps xmm12, [rsp+0xC0]
000074ad747d7182  vmovaps xmm14, [rsp+0xD0]
000074ad747d718b  vmovaps xmm15, [rsp+0xE0]
000074ad747d7194  add rsp, 0xF0
000074ad747d719b  pop r11
000074ad747d719d  pop r10
000074ad747d719f  pop r9
000074ad747d71a1  pop r8
000074ad747d71a3  pop rsi
000074ad747d71a4  pop rdi
000074ad747d71a5  pop rdx
000074ad747d71a6  pop rcx
000074ad747d71a7  pop rax
000074ad747d71a8  add rsp, 0x08
000074ad747d71ac  jmp 0x000074AD747D648E
000074ad747d71b1  call 0x000074AD746D64F0
000074ad747d71b6  jmp 0x000074AD747D64A3
000074ad747d71bb  sub rsp, 0x08
000074ad747d71bf  push rax
000074ad747d71c0  push rcx
000074ad747d71c1  push rdx
000074ad747d71c2  push rdi
000074ad747d71c3  push rsi
000074ad747d71c4  push r8
000074ad747d71c6  push r9
000074ad747d71c8  push r10
000074ad747d71ca  push r11
000074ad747d71cc  sub rsp, 0xF0
000074ad747d71d3  vmovaps [rsp], xmm0
000074ad747d71d8  vmovaps [rsp+0x10], xmm1
000074ad747d71de  vmovaps [rsp+0x20], xmm2
000074ad747d71e4  vmovaps [rsp+0x30], xmm3
000074ad747d71ea  vmovaps [rsp+0x40], xmm4
000074ad747d71f0  vmovaps [rsp+0x50], xmm5
000074ad747d71f6  vmovaps [rsp+0x60], xmm6
000074ad747d71fc  vmovaps [rsp+0x70], xmm7
000074ad747d7202  vmovaps [rsp+0x80], xmm8
000074ad747d720b  vmovaps [rsp+0x90], xmm9
000074ad747d7214  vmovaps [rsp+0xA0], xmm10
000074ad747d721d  vmovaps [rsp+0xB0], xmm11
000074ad747d7226  vmovaps [rsp+0xC0], xmm13
000074ad747d722f  vmovaps [rsp+0xD0], xmm14
000074ad747d7238  vmovaps [rsp+0xE0], xmm15
000074ad747d7241  sub rsp, 0x40
000074ad747d7245  lea rdi, [rsp]
000074ad747d7249  lea rsi, [rsp+0x10]
000074ad747d724e  lea rdx, [rsp+0x20]
000074ad747d7253  lea rcx, [rsp+0x30]
000074ad747d7258  mov r8d, 0x00
000074ad747d725e  lea r9, [r15+0x3A8]
000074ad747d7265  movaps [rdi], xmm12
000074ad747d7269  movaps [rsi], xmm15
000074ad747d726d  movaps [rdx], xmm1
000074ad747d7270  movaps [rcx], xmm14
000074ad747d7274  mov rax, 0x5C17501CEA50
000074ad747d727e  call rax
000074ad747d7280  movaps xmm12, [rsp]
000074ad747d7285  add rsp, 0x40
000074ad747d7289  vmovaps xmm0, [rsp]
000074ad747d728e  vmovaps xmm1, [rsp+0x10]
000074ad747d7294  vmovaps xmm2, [rsp+0x20]
000074ad747d729a  vmovaps xmm3, [rsp+0x30]
000074ad747d72a0  vmovaps xmm4, [rsp+0x40]
000074ad747d72a6  vmovaps xmm5, [rsp+0x50]
000074ad747d72ac  vmovaps xmm6, [rsp+0x60]
000074ad747d72b2  vmovaps xmm7, [rsp+0x70]
000074ad747d72b8  vmovaps xmm8, [rsp+0x80]
000074ad747d72c1  vmovaps xmm9, [rsp+0x90]
000074ad747d72ca  vmovaps xmm10, [rsp+0xA0]
000074ad747d72d3  vmovaps xmm11, [rsp+0xB0]
000074ad747d72dc  vmovaps xmm13, [rsp+0xC0]
000074ad747d72e5  vmovaps xmm14, [rsp+0xD0]
000074ad747d72ee  vmovaps xmm15, [rsp+0xE0]
000074ad747d72f7  add rsp, 0xF0
000074ad747d72fe  pop r11
000074ad747d7300  pop r10
000074ad747d7302  pop r9
000074ad747d7304  pop r8
000074ad747d7306  pop rsi
000074ad747d7307  pop rdi
000074ad747d7308  pop rdx
000074ad747d7309  pop rcx
000074ad747d730a  pop rax
000074ad747d730b  add rsp, 0x08
000074ad747d730f  jmp 0x000074AD747D64CF
000074ad747d7314  sub rsp, 0x08
000074ad747d7318  push rax
000074ad747d7319  push rcx
000074ad747d731a  push rdx
000074ad747d731b  push rdi
000074ad747d731c  push rsi
000074ad747d731d  push r8
000074ad747d731f  push r9
000074ad747d7321  push r10
000074ad747d7323  push r11
000074ad747d7325  sub rsp, 0xF0
000074ad747d732c  vmovaps [rsp], xmm0
000074ad747d7331  vmovaps [rsp+0x10], xmm1
000074ad747d7337  vmovaps [rsp+0x20], xmm2
000074ad747d733d  vmovaps [rsp+0x30], xmm3
000074ad747d7343  vmovaps [rsp+0x40], xmm4
000074ad747d7349  vmovaps [rsp+0x50], xmm5
000074ad747d734f  vmovaps [rsp+0x60], xmm6
000074ad747d7355  vmovaps [rsp+0x70], xmm7
000074ad747d735b  vmovaps [rsp+0x80], xmm8
000074ad747d7364  vmovaps [rsp+0x90], xmm9
000074ad747d736d  vmovaps [rsp+0xA0], xmm10
000074ad747d7376  vmovaps [rsp+0xB0], xmm11
000074ad747d737f  vmovaps [rsp+0xC0], xmm12
000074ad747d7388  vmovaps [rsp+0xD0], xmm14
000074ad747d7391  vmovaps [rsp+0xE0], xmm15
000074ad747d739a  sub rsp, 0x40
000074ad747d739e  lea rdi, [rsp]
000074ad747d73a2  lea rsi, [rsp+0x10]
000074ad747d73a7  lea rdx, [rsp+0x20]
000074ad747d73ac  lea rcx, [rsp+0x30]
000074ad747d73b1  mov r8d, 0x00
000074ad747d73b7  lea r9, [r15+0x3A8]
000074ad747d73be  movaps [rdi], xmm13
000074ad747d73c2  movaps [rsi], xmm1
000074ad747d73c5  movaps [rdx], xmm15
000074ad747d73c9  movaps [rcx], xmm14
000074ad747d73cd  mov rax, 0x5C17501CEA50
000074ad747d73d7  call rax
000074ad747d73d9  movaps xmm13, [rsp]
000074ad747d73de  add rsp, 0x40
000074ad747d73e2  vmovaps xmm0, [rsp]
000074ad747d73e7  vmovaps xmm1, [rsp+0x10]
000074ad747d73ed  vmovaps xmm2, [rsp+0x20]
000074ad747d73f3  vmovaps xmm3, [rsp+0x30]
000074ad747d73f9  vmovaps xmm4, [rsp+0x40]
000074ad747d73ff  vmovaps xmm5, [rsp+0x50]
000074ad747d7405  vmovaps xmm6, [rsp+0x60]
000074ad747d740b  vmovaps xmm7, [rsp+0x70]
000074ad747d7411  vmovaps xmm8, [rsp+0x80]
000074ad747d741a  vmovaps xmm9, [rsp+0x90]
000074ad747d7423  vmovaps xmm10, [rsp+0xA0]
000074ad747d742c  vmovaps xmm11, [rsp+0xB0]
000074ad747d7435  vmovaps xmm12, [rsp+0xC0]
000074ad747d743e  vmovaps xmm14, [rsp+0xD0]
000074ad747d7447  vmovaps xmm15, [rsp+0xE0]
000074ad747d7450  add rsp, 0xF0
000074ad747d7457  pop r11
000074ad747d7459  pop r10
000074ad747d745b  pop r9
000074ad747d745d  pop r8
000074ad747d745f  pop rsi
000074ad747d7460  pop rdi
000074ad747d7461  pop rdx
000074ad747d7462  pop rcx
000074ad747d7463  pop rax
000074ad747d7464  add rsp, 0x08
000074ad747d7468  jmp 0x000074AD747D665F
000074ad747d746d  sub rsp, 0x08
000074ad747d7471  push rax
000074ad747d7472  push rcx
000074ad747d7473  push rdx
000074ad747d7474  push rdi
000074ad747d7475  push rsi
000074ad747d7476  push r8
000074ad747d7478  push r9
000074ad747d747a  push r10
000074ad747d747c  push r11
000074ad747d747e  sub rsp, 0xF0
000074ad747d7485  vmovaps [rsp], xmm0
000074ad747d748a  vmovaps [rsp+0x10], xmm1
000074ad747d7490  vmovaps [rsp+0x20], xmm2
000074ad747d7496  vmovaps [rsp+0x30], xmm3
000074ad747d749c  vmovaps [rsp+0x40], xmm4
000074ad747d74a2  vmovaps [rsp+0x50], xmm5
000074ad747d74a8  vmovaps [rsp+0x60], xmm6
000074ad747d74ae  vmovaps [rsp+0x70], xmm7
000074ad747d74b4  vmovaps [rsp+0x80], xmm8
000074ad747d74bd  vmovaps [rsp+0x90], xmm9
000074ad747d74c6  vmovaps [rsp+0xA0], xmm10
000074ad747d74cf  vmovaps [rsp+0xB0], xmm11
000074ad747d74d8  vmovaps [rsp+0xC0], xmm12
000074ad747d74e1  vmovaps [rsp+0xD0], xmm13
000074ad747d74ea  vmovaps [rsp+0xE0], xmm15
000074ad747d74f3  sub rsp, 0x40
000074ad747d74f7  lea rdi, [rsp]
000074ad747d74fb  lea rsi, [rsp+0x10]
000074ad747d7500  lea rdx, [rsp+0x20]
000074ad747d7505  lea rcx, [rsp+0x30]
000074ad747d750a  mov r8d, 0x00
000074ad747d7510  lea r9, [r15+0x3A8]
000074ad747d7517  movaps [rdi], xmm14
000074ad747d751b  movaps [rsi], xmm15
000074ad747d751f  movaps [rdx], xmm2
000074ad747d7522  movaps [rcx], xmm1
000074ad747d7525  mov rax, 0x5C17501CEA50
000074ad747d752f  call rax
000074ad747d7531  movaps xmm14, [rsp]
000074ad747d7536  add rsp, 0x40
000074ad747d753a  vmovaps xmm0, [rsp]
000074ad747d753f  vmovaps xmm1, [rsp+0x10]
000074ad747d7545  vmovaps xmm2, [rsp+0x20]
000074ad747d754b  vmovaps xmm3, [rsp+0x30]
000074ad747d7551  vmovaps xmm4, [rsp+0x40]
000074ad747d7557  vmovaps xmm5, [rsp+0x50]
000074ad747d755d  vmovaps xmm6, [rsp+0x60]
000074ad747d7563  vmovaps xmm7, [rsp+0x70]
000074ad747d7569  vmovaps xmm8, [rsp+0x80]
000074ad747d7572  vmovaps xmm9, [rsp+0x90]
000074ad747d757b  vmovaps xmm10, [rsp+0xA0]
000074ad747d7584  vmovaps xmm11, [rsp+0xB0]
000074ad747d758d  vmovaps xmm12, [rsp+0xC0]
000074ad747d7596  vmovaps xmm13, [rsp+0xD0]
000074ad747d759f  vmovaps xmm15, [rsp+0xE0]
000074ad747d75a8  add rsp, 0xF0
000074ad747d75af  pop r11
000074ad747d75b1  pop r10
000074ad747d75b3  pop r9
000074ad747d75b5  pop r8
000074ad747d75b7  pop rsi
000074ad747d75b8  pop rdi
000074ad747d75b9  pop rdx
000074ad747d75ba  pop rcx
000074ad747d75bb  pop rax
000074ad747d75bc  add rsp, 0x08
000074ad747d75c0  jmp 0x000074AD747D6691
000074ad747d75c5  sub rsp, 0x08
000074ad747d75c9  push rax
000074ad747d75ca  push rcx
000074ad747d75cb  push rdx
000074ad747d75cc  push rdi
000074ad747d75cd  push rsi
000074ad747d75ce  push r8
000074ad747d75d0  push r9
000074ad747d75d2  push r10
000074ad747d75d4  push r11
000074ad747d75d6  sub rsp, 0xF0
000074ad747d75dd  vmovaps [rsp], xmm0
000074ad747d75e2  vmovaps [rsp+0x10], xmm1
000074ad747d75e8  vmovaps [rsp+0x20], xmm3
000074ad747d75ee  vmovaps [rsp+0x30], xmm4
000074ad747d75f4  vmovaps [rsp+0x40], xmm5
000074ad747d75fa  vmovaps [rsp+0x50], xmm6
000074ad747d7600  vmovaps [rsp+0x60], xmm7
000074ad747d7606  vmovaps [rsp+0x70], xmm8
000074ad747d760c  vmovaps [rsp+0x80], xmm9
000074ad747d7615  vmovaps [rsp+0x90], xmm10
000074ad747d761e  vmovaps [rsp+0xA0], xmm11
000074ad747d7627  vmovaps [rsp+0xB0], xmm12
000074ad747d7630  vmovaps [rsp+0xC0], xmm13
000074ad747d7639  vmovaps [rsp+0xD0], xmm14
000074ad747d7642  vmovaps [rsp+0xE0], xmm15
000074ad747d764b  sub rsp, 0x40
000074ad747d764f  lea rdi, [rsp]
000074ad747d7653  lea rsi, [rsp+0x10]
000074ad747d7658  lea rdx, [rsp+0x20]
000074ad747d765d  lea rcx, [rsp+0x30]
000074ad747d7662  mov r8d, 0x00
000074ad747d7668  lea r9, [r15+0x3A8]
000074ad747d766f  movaps [rdi], xmm2
000074ad747d7672  movaps [rsi], xmm15
000074ad747d7676  movaps [rdx], xmm12
000074ad747d767a  movaps [rcx], xmm1
000074ad747d767d  mov rax, 0x5C17501CEA50
000074ad747d7687  call rax
000074ad747d7689  movaps xmm2, [rsp]
000074ad747d768d  add rsp, 0x40
000074ad747d7691  vmovaps xmm0, [rsp]
000074ad747d7696  vmovaps xmm1, [rsp+0x10]
000074ad747d769c  vmovaps xmm3, [rsp+0x20]
000074ad747d76a2  vmovaps xmm4, [rsp+0x30]
000074ad747d76a8  vmovaps xmm5, [rsp+0x40]
000074ad747d76ae  vmovaps xmm6, [rsp+0x50]
000074ad747d76b4  vmovaps xmm7, [rsp+0x60]
000074ad747d76ba  vmovaps xmm8, [rsp+0x70]
000074ad747d76c0  vmovaps xmm9, [rsp+0x80]
000074ad747d76c9  vmovaps xmm10, [rsp+0x90]
000074ad747d76d2  vmovaps xmm11, [rsp+0xA0]
000074ad747d76db  vmovaps xmm12, [rsp+0xB0]
000074ad747d76e4  vmovaps xmm13, [rsp+0xC0]
000074ad747d76ed  vmovaps xmm14, [rsp+0xD0]
000074ad747d76f6  vmovaps xmm15, [rsp+0xE0]
000074ad747d76ff  add rsp, 0xF0
000074ad747d7706  pop r11
000074ad747d7708  pop r10
000074ad747d770a  pop r9
000074ad747d770c  pop r8
000074ad747d770e  pop rsi
000074ad747d770f  pop rdi
000074ad747d7710  pop rdx
000074ad747d7711  pop rcx
000074ad747d7712  pop rax
000074ad747d7713  add rsp, 0x08
000074ad747d7717  jmp 0x000074AD747D66CE
000074ad747d771c  sub rsp, 0x08
000074ad747d7720  push rax
000074ad747d7721  push rcx
000074ad747d7722  push rdx
000074ad747d7723  push rdi
000074ad747d7724  push rsi
000074ad747d7725  push r8
000074ad747d7727  push r9
000074ad747d7729  push r10
000074ad747d772b  push r11
000074ad747d772d  sub rsp, 0xF0
000074ad747d7734  vmovaps [rsp], xmm0
000074ad747d7739  vmovaps [rsp+0x10], xmm1
000074ad747d773f  vmovaps [rsp+0x20], xmm2
000074ad747d7745  vmovaps [rsp+0x30], xmm3
000074ad747d774b  vmovaps [rsp+0x40], xmm4
000074ad747d7751  vmovaps [rsp+0x50], xmm5
000074ad747d7757  vmovaps [rsp+0x60], xmm6
000074ad747d775d  vmovaps [rsp+0x70], xmm7
000074ad747d7763  vmovaps [rsp+0x80], xmm8
000074ad747d776c  vmovaps [rsp+0x90], xmm9
000074ad747d7775  vmovaps [rsp+0xA0], xmm10
000074ad747d777e  vmovaps [rsp+0xB0], xmm11
000074ad747d7787  vmovaps [rsp+0xC0], xmm13
000074ad747d7790  vmovaps [rsp+0xD0], xmm14
000074ad747d7799  vmovaps [rsp+0xE0], xmm15
000074ad747d77a2  sub rsp, 0x40
000074ad747d77a6  lea rdi, [rsp]
000074ad747d77aa  lea rsi, [rsp+0x10]
000074ad747d77af  lea rdx, [rsp+0x20]
000074ad747d77b4  lea rcx, [rsp+0x30]
000074ad747d77b9  mov r8d, 0x00
000074ad747d77bf  lea r9, [r15+0x3A8]
000074ad747d77c6  movaps [rdi], xmm12
000074ad747d77ca  movaps [rsi], xmm14
000074ad747d77ce  movaps [rdx], xmm3
000074ad747d77d1  movaps [rcx], xmm15
000074ad747d77d5  mov rax, 0x5C17501CEA50
000074ad747d77df  call rax
000074ad747d77e1  movaps xmm12, [rsp]
000074ad747d77e6  add rsp, 0x40
000074ad747d77ea  vmovaps xmm0, [rsp]
000074ad747d77ef  vmovaps xmm1, [rsp+0x10]
000074ad747d77f5  vmovaps xmm2, [rsp+0x20]
000074ad747d77fb  vmovaps xmm3, [rsp+0x30]
000074ad747d7801  vmovaps xmm4, [rsp+0x40]
000074ad747d7807  vmovaps xmm5, [rsp+0x50]
000074ad747d780d  vmovaps xmm6, [rsp+0x60]
000074ad747d7813  vmovaps xmm7, [rsp+0x70]
000074ad747d7819  vmovaps xmm8, [rsp+0x80]
000074ad747d7822  vmovaps xmm9, [rsp+0x90]
000074ad747d782b  vmovaps xmm10, [rsp+0xA0]
000074ad747d7834  vmovaps xmm11, [rsp+0xB0]
000074ad747d783d  vmovaps xmm13, [rsp+0xC0]
000074ad747d7846  vmovaps xmm14, [rsp+0xD0]
000074ad747d784f  vmovaps xmm15, [rsp+0xE0]
000074ad747d7858  add rsp, 0xF0
000074ad747d785f  pop r11
000074ad747d7861  pop r10
000074ad747d7863  pop r9
000074ad747d7865  pop r8
000074ad747d7867  pop rsi
000074ad747d7868  pop rdi
000074ad747d7869  pop rdx
000074ad747d786a  pop rcx
000074ad747d786b  pop rax
000074ad747d786c  add rsp, 0x08
000074ad747d7870  jmp 0x000074AD747D6728
000074ad747d7875  sub rsp, 0x08
000074ad747d7879  push rax
000074ad747d787a  push rcx
000074ad747d787b  push rdx
000074ad747d787c  push rdi
000074ad747d787d  push rsi
000074ad747d787e  push r8
000074ad747d7880  push r9
000074ad747d7882  push r10
000074ad747d7884  push r11
000074ad747d7886  sub rsp, 0xF0
000074ad747d788d  vmovaps [rsp], xmm0
000074ad747d7892  vmovaps [rsp+0x10], xmm1
000074ad747d7898  vmovaps [rsp+0x20], xmm2
000074ad747d789e  vmovaps [rsp+0x30], xmm3
000074ad747d78a4  vmovaps [rsp+0x40], xmm4
000074ad747d78aa  vmovaps [rsp+0x50], xmm5
000074ad747d78b0  vmovaps [rsp+0x60], xmm6
000074ad747d78b6  vmovaps [rsp+0x70], xmm7
000074ad747d78bc  vmovaps [rsp+0x80], xmm8
000074ad747d78c5  vmovaps [rsp+0x90], xmm10
000074ad747d78ce  vmovaps [rsp+0xA0], xmm11
000074ad747d78d7  vmovaps [rsp+0xB0], xmm12
000074ad747d78e0  vmovaps [rsp+0xC0], xmm13
000074ad747d78e9  vmovaps [rsp+0xD0], xmm14
000074ad747d78f2  vmovaps [rsp+0xE0], xmm15
000074ad747d78fb  sub rsp, 0x40
000074ad747d78ff  lea rdi, [rsp]
000074ad747d7903  lea rsi, [rsp+0x10]
000074ad747d7908  lea rdx, [rsp+0x20]
000074ad747d790d  lea rcx, [rsp+0x30]
000074ad747d7912  mov r8d, 0x00
000074ad747d7918  lea r9, [r15+0x3A8]
000074ad747d791f  movaps [rdi], xmm9
000074ad747d7923  movaps [rsi], xmm13
000074ad747d7927  movaps [rdx], xmm14
000074ad747d792b  movaps [rcx], xmm6
000074ad747d792e  mov rax, 0x5C17501CEA50
000074ad747d7938  call rax
000074ad747d793a  movaps xmm9, [rsp]
000074ad747d793f  add rsp, 0x40
000074ad747d7943  vmovaps xmm0, [rsp]
000074ad747d7948  vmovaps xmm1, [rsp+0x10]
000074ad747d794e  vmovaps xmm2, [rsp+0x20]
000074ad747d7954  vmovaps xmm3, [rsp+0x30]
000074ad747d795a  vmovaps xmm4, [rsp+0x40]
000074ad747d7960  vmovaps xmm5, [rsp+0x50]
000074ad747d7966  vmovaps xmm6, [rsp+0x60]
000074ad747d796c  vmovaps xmm7, [rsp+0x70]
000074ad747d7972  vmovaps xmm8, [rsp+0x80]
000074ad747d797b  vmovaps xmm10, [rsp+0x90]
000074ad747d7984  vmovaps xmm11, [rsp+0xA0]
000074ad747d798d  vmovaps xmm12, [rsp+0xB0]
000074ad747d7996  vmovaps xmm13, [rsp+0xC0]
000074ad747d799f  vmovaps xmm14, [rsp+0xD0]
000074ad747d79a8  vmovaps xmm15, [rsp+0xE0]
000074ad747d79b1  add rsp, 0xF0
000074ad747d79b8  pop r11
000074ad747d79ba  pop r10
000074ad747d79bc  pop r9
000074ad747d79be  pop r8
000074ad747d79c0  pop rsi
000074ad747d79c1  pop rdi
000074ad747d79c2  pop rdx
000074ad747d79c3  pop rcx
000074ad747d79c4  pop rax
000074ad747d79c5  add rsp, 0x08
000074ad747d79c9  jmp 0x000074AD747D67D2
000074ad747d79ce  sub rsp, 0x08
000074ad747d79d2  push rax
000074ad747d79d3  push rcx
000074ad747d79d4  push rdx
000074ad747d79d5  push rdi
000074ad747d79d6  push rsi
000074ad747d79d7  push r8
000074ad747d79d9  push r9
000074ad747d79db  push r10
000074ad747d79dd  push r11
000074ad747d79df  sub rsp, 0xF0
000074ad747d79e6  vmovaps [rsp], xmm0
000074ad747d79eb  vmovaps [rsp+0x10], xmm1
000074ad747d79f1  vmovaps [rsp+0x20], xmm2
000074ad747d79f7  vmovaps [rsp+0x30], xmm4
000074ad747d79fd  vmovaps [rsp+0x40], xmm5
000074ad747d7a03  vmovaps [rsp+0x50], xmm6
000074ad747d7a09  vmovaps [rsp+0x60], xmm7
000074ad747d7a0f  vmovaps [rsp+0x70], xmm8
000074ad747d7a15  vmovaps [rsp+0x80], xmm9
000074ad747d7a1e  vmovaps [rsp+0x90], xmm10
000074ad747d7a27  vmovaps [rsp+0xA0], xmm11
000074ad747d7a30  vmovaps [rsp+0xB0], xmm12
000074ad747d7a39  vmovaps [rsp+0xC0], xmm13
000074ad747d7a42  vmovaps [rsp+0xD0], xmm14
000074ad747d7a4b  vmovaps [rsp+0xE0], xmm15
000074ad747d7a54  sub rsp, 0x40
000074ad747d7a58  lea rdi, [rsp]
000074ad747d7a5c  lea rsi, [rsp+0x10]
000074ad747d7a61  lea rdx, [rsp+0x20]
000074ad747d7a66  lea rcx, [rsp+0x30]
000074ad747d7a6b  mov r8d, 0x00
000074ad747d7a71  lea r9, [r15+0x3A8]
000074ad747d7a78  movaps [rdi], xmm3
000074ad747d7a7b  movaps [rsi], xmm13
000074ad747d7a7f  movaps [rdx], xmm6
000074ad747d7a82  movaps [rcx], xmm14
000074ad747d7a86  mov rax, 0x5C17501CEA50
000074ad747d7a90  call rax
000074ad747d7a92  movaps xmm3, [rsp]
000074ad747d7a96  add rsp, 0x40
000074ad747d7a9a  vmovaps xmm0, [rsp]
000074ad747d7a9f  vmovaps xmm1, [rsp+0x10]
000074ad747d7aa5  vmovaps xmm2, [rsp+0x20]
000074ad747d7aab  vmovaps xmm4, [rsp+0x30]
000074ad747d7ab1  vmovaps xmm5, [rsp+0x40]
000074ad747d7ab7  vmovaps xmm6, [rsp+0x50]
000074ad747d7abd  vmovaps xmm7, [rsp+0x60]
000074ad747d7ac3  vmovaps xmm8, [rsp+0x70]
000074ad747d7ac9  vmovaps xmm9, [rsp+0x80]
000074ad747d7ad2  vmovaps xmm10, [rsp+0x90]
000074ad747d7adb  vmovaps xmm11, [rsp+0xA0]
000074ad747d7ae4  vmovaps xmm12, [rsp+0xB0]
000074ad747d7aed  vmovaps xmm13, [rsp+0xC0]
000074ad747d7af6  vmovaps xmm14, [rsp+0xD0]
000074ad747d7aff  vmovaps xmm15, [rsp+0xE0]
000074ad747d7b08  add rsp, 0xF0
000074ad747d7b0f  pop r11
000074ad747d7b11  pop r10
000074ad747d7b13  pop r9
000074ad747d7b15  pop r8
000074ad747d7b17  pop rsi
000074ad747d7b18  pop rdi
000074ad747d7b19  pop rdx
000074ad747d7b1a  pop rcx
000074ad747d7b1b  pop rax
000074ad747d7b1c  add rsp, 0x08
000074ad747d7b20  jmp 0x000074AD747D680F
000074ad747d7b25  sub rsp, 0x08
000074ad747d7b29  push rax
000074ad747d7b2a  push rcx
000074ad747d7b2b  push rdx
000074ad747d7b2c  push rdi
000074ad747d7b2d  push rsi
000074ad747d7b2e  push r8
000074ad747d7b30  push r9
000074ad747d7b32  push r10
000074ad747d7b34  push r11
000074ad747d7b36  sub rsp, 0xF0
000074ad747d7b3d  vmovaps [rsp], xmm0
000074ad747d7b42  vmovaps [rsp+0x10], xmm1
000074ad747d7b48  vmovaps [rsp+0x20], xmm2
000074ad747d7b4e  vmovaps [rsp+0x30], xmm3
000074ad747d7b54  vmovaps [rsp+0x40], xmm4
000074ad747d7b5a  vmovaps [rsp+0x50], xmm5
000074ad747d7b60  vmovaps [rsp+0x60], xmm7
000074ad747d7b66  vmovaps [rsp+0x70], xmm8
000074ad747d7b6c  vmovaps [rsp+0x80], xmm9
000074ad747d7b75  vmovaps [rsp+0x90], xmm10
000074ad747d7b7e  vmovaps [rsp+0xA0], xmm11
000074ad747d7b87  vmovaps [rsp+0xB0], xmm12
000074ad747d7b90  vmovaps [rsp+0xC0], xmm13
000074ad747d7b99  vmovaps [rsp+0xD0], xmm14
000074ad747d7ba2  vmovaps [rsp+0xE0], xmm15
000074ad747d7bab  sub rsp, 0x40
000074ad747d7baf  lea rdi, [rsp]
000074ad747d7bb3  lea rsi, [rsp+0x10]
000074ad747d7bb8  lea rdx, [rsp+0x20]
000074ad747d7bbd  lea rcx, [rsp+0x30]
000074ad747d7bc2  mov r8d, 0x00
000074ad747d7bc8  lea r9, [r15+0x3A8]
000074ad747d7bcf  movaps [rdi], xmm6
000074ad747d7bd2  movaps [rsi], xmm2
000074ad747d7bd5  movaps [rdx], xmm14
000074ad747d7bd9  movaps [rcx], xmm1
000074ad747d7bdc  mov rax, 0x5C17501CEA50
000074ad747d7be6  call rax
000074ad747d7be8  movaps xmm6, [rsp]
000074ad747d7bec  add rsp, 0x40
000074ad747d7bf0  vmovaps xmm0, [rsp]
000074ad747d7bf5  vmovaps xmm1, [rsp+0x10]
000074ad747d7bfb  vmovaps xmm2, [rsp+0x20]
000074ad747d7c01  vmovaps xmm3, [rsp+0x30]
000074ad747d7c07  vmovaps xmm4, [rsp+0x40]
000074ad747d7c0d  vmovaps xmm5, [rsp+0x50]
000074ad747d7c13  vmovaps xmm7, [rsp+0x60]
000074ad747d7c19  vmovaps xmm8, [rsp+0x70]
000074ad747d7c1f  vmovaps xmm9, [rsp+0x80]
000074ad747d7c28  vmovaps xmm10, [rsp+0x90]
000074ad747d7c31  vmovaps xmm11, [rsp+0xA0]
000074ad747d7c3a  vmovaps xmm12, [rsp+0xB0]
000074ad747d7c43  vmovaps xmm13, [rsp+0xC0]
000074ad747d7c4c  vmovaps xmm14, [rsp+0xD0]
000074ad747d7c55  vmovaps xmm15, [rsp+0xE0]
000074ad747d7c5e  add rsp, 0xF0
000074ad747d7c65  pop r11
000074ad747d7c67  pop r10
000074ad747d7c69  pop r9
000074ad747d7c6b  pop r8
000074ad747d7c6d  pop rsi
000074ad747d7c6e  pop rdi
000074ad747d7c6f  pop rdx
000074ad747d7c70  pop rcx
000074ad747d7c71  pop rax
000074ad747d7c72  add rsp, 0x08
000074ad747d7c76  jmp 0x000074AD747D683C
000074ad747d7c7b  sub rsp, 0x08
000074ad747d7c7f  push rax
000074ad747d7c80  push rcx
000074ad747d7c81  push rdx
000074ad747d7c82  push rdi
000074ad747d7c83  push rsi
000074ad747d7c84  push r8
000074ad747d7c86  push r9
000074ad747d7c88  push r10
000074ad747d7c8a  push r11
000074ad747d7c8c  sub rsp, 0xF0
000074ad747d7c93  vmovaps [rsp], xmm0
000074ad747d7c98  vmovaps [rsp+0x10], xmm1
000074ad747d7c9e  vmovaps [rsp+0x20], xmm2
000074ad747d7ca4  vmovaps [rsp+0x30], xmm3
000074ad747d7caa  vmovaps [rsp+0x40], xmm4
000074ad747d7cb0  vmovaps [rsp+0x50], xmm5
000074ad747d7cb6  vmovaps [rsp+0x60], xmm6
000074ad747d7cbc  vmovaps [rsp+0x70], xmm7
000074ad747d7cc2  vmovaps [rsp+0x80], xmm8
000074ad747d7ccb  vmovaps [rsp+0x90], xmm9
000074ad747d7cd4  vmovaps [rsp+0xA0], xmm10
000074ad747d7cdd  vmovaps [rsp+0xB0], xmm11
000074ad747d7ce6  vmovaps [rsp+0xC0], xmm12
000074ad747d7cef  vmovaps [rsp+0xD0], xmm14
000074ad747d7cf8  vmovaps [rsp+0xE0], xmm15
000074ad747d7d01  sub rsp, 0x40
000074ad747d7d05  lea rdi, [rsp]
000074ad747d7d09  lea rsi, [rsp+0x10]
000074ad747d7d0e  lea rdx, [rsp+0x20]
000074ad747d7d13  lea rcx, [rsp+0x30]
000074ad747d7d18  mov r8d, 0x00
000074ad747d7d1e  lea r9, [r15+0x3A8]
000074ad747d7d25  movaps [rdi], xmm13
000074ad747d7d29  movaps [rsi], xmm12
000074ad747d7d2d  movaps [rdx], xmm14
000074ad747d7d31  movaps [rcx], xmm1
000074ad747d7d34  mov rax, 0x5C17501CEA50
000074ad747d7d3e  call rax
000074ad747d7d40  movaps xmm13, [rsp]
000074ad747d7d45  add rsp, 0x40
000074ad747d7d49  vmovaps xmm0, [rsp]
000074ad747d7d4e  vmovaps xmm1, [rsp+0x10]
000074ad747d7d54  vmovaps xmm2, [rsp+0x20]
000074ad747d7d5a  vmovaps xmm3, [rsp+0x30]
000074ad747d7d60  vmovaps xmm4, [rsp+0x40]
000074ad747d7d66  vmovaps xmm5, [rsp+0x50]
000074ad747d7d6c  vmovaps xmm6, [rsp+0x60]
000074ad747d7d72  vmovaps xmm7, [rsp+0x70]
000074ad747d7d78  vmovaps xmm8, [rsp+0x80]
000074ad747d7d81  vmovaps xmm9, [rsp+0x90]
000074ad747d7d8a  vmovaps xmm10, [rsp+0xA0]
000074ad747d7d93  vmovaps xmm11, [rsp+0xB0]
000074ad747d7d9c  vmovaps xmm12, [rsp+0xC0]
000074ad747d7da5  vmovaps xmm14, [rsp+0xD0]
000074ad747d7dae  vmovaps xmm15, [rsp+0xE0]
000074ad747d7db7  add rsp, 0xF0
000074ad747d7dbe  pop r11
000074ad747d7dc0  pop r10
000074ad747d7dc2  pop r9
000074ad747d7dc4  pop r8
000074ad747d7dc6  pop rsi
000074ad747d7dc7  pop rdi
000074ad747d7dc8  pop rdx
000074ad747d7dc9  pop rcx
000074ad747d7dca  pop rax
000074ad747d7dcb  add rsp, 0x08
000074ad747d7dcf  jmp 0x000074AD747D686E
000074ad747d7dd4  sub rsp, 0x08
000074ad747d7dd8  push rax
000074ad747d7dd9  push rcx
000074ad747d7dda  push rdx
000074ad747d7ddb  push rdi
000074ad747d7ddc  push rsi
000074ad747d7ddd  push r8
000074ad747d7ddf  push r9
000074ad747d7de1  push r10
000074ad747d7de3  push r11
000074ad747d7de5  sub rsp, 0xF0
000074ad747d7dec  vmovaps [rsp], xmm0
000074ad747d7df1  vmovaps [rsp+0x10], xmm1
000074ad747d7df7  vmovaps [rsp+0x20], xmm2
000074ad747d7dfd  vmovaps [rsp+0x30], xmm3
000074ad747d7e03  vmovaps [rsp+0x40], xmm4
000074ad747d7e09  vmovaps [rsp+0x50], xmm5
000074ad747d7e0f  vmovaps [rsp+0x60], xmm6
000074ad747d7e15  vmovaps [rsp+0x70], xmm7
000074ad747d7e1b  vmovaps [rsp+0x80], xmm8
000074ad747d7e24  vmovaps [rsp+0x90], xmm9
000074ad747d7e2d  vmovaps [rsp+0xA0], xmm10
000074ad747d7e36  vmovaps [rsp+0xB0], xmm11
000074ad747d7e3f  vmovaps [rsp+0xC0], xmm13
000074ad747d7e48  vmovaps [rsp+0xD0], xmm14
000074ad747d7e51  vmovaps [rsp+0xE0], xmm15
000074ad747d7e5a  sub rsp, 0x40
000074ad747d7e5e  lea rdi, [rsp]
000074ad747d7e62  lea rsi, [rsp+0x10]
000074ad747d7e67  lea rdx, [rsp+0x20]
000074ad747d7e6c  lea rcx, [rsp+0x30]
000074ad747d7e71  mov r8d, 0x00
000074ad747d7e77  lea r9, [r15+0x3A8]
000074ad747d7e7e  movaps [rdi], xmm12
000074ad747d7e82  movaps [rsi], xmm3
000074ad747d7e85  movaps [rdx], xmm14
000074ad747d7e89  movaps [rcx], xmm5
000074ad747d7e8c  mov rax, 0x5C17501CEA50
000074ad747d7e96  call rax
000074ad747d7e98  movaps xmm12, [rsp]
000074ad747d7e9d  add rsp, 0x40
000074ad747d7ea1  vmovaps xmm0, [rsp]
000074ad747d7ea6  vmovaps xmm1, [rsp+0x10]
000074ad747d7eac  vmovaps xmm2, [rsp+0x20]
000074ad747d7eb2  vmovaps xmm3, [rsp+0x30]
000074ad747d7eb8  vmovaps xmm4, [rsp+0x40]
000074ad747d7ebe  vmovaps xmm5, [rsp+0x50]
000074ad747d7ec4  vmovaps xmm6, [rsp+0x60]
000074ad747d7eca  vmovaps xmm7, [rsp+0x70]
000074ad747d7ed0  vmovaps xmm8, [rsp+0x80]
000074ad747d7ed9  vmovaps xmm9, [rsp+0x90]
000074ad747d7ee2  vmovaps xmm10, [rsp+0xA0]
000074ad747d7eeb  vmovaps xmm11, [rsp+0xB0]
000074ad747d7ef4  vmovaps xmm13, [rsp+0xC0]
000074ad747d7efd  vmovaps xmm14, [rsp+0xD0]
000074ad747d7f06  vmovaps xmm15, [rsp+0xE0]
000074ad747d7f0f  add rsp, 0xF0
000074ad747d7f16  pop r11
000074ad747d7f18  pop r10
000074ad747d7f1a  pop r9
000074ad747d7f1c  pop r8
000074ad747d7f1e  pop rsi
000074ad747d7f1f  pop rdi
000074ad747d7f20  pop rdx
000074ad747d7f21  pop rcx
000074ad747d7f22  pop rax
000074ad747d7f23  add rsp, 0x08
000074ad747d7f27  jmp 0x000074AD747D68CB
000074ad747d7f2c  sub rsp, 0x08
000074ad747d7f30  push rax
000074ad747d7f31  push rcx
000074ad747d7f32  push rdx
000074ad747d7f33  push rdi
000074ad747d7f34  push rsi
000074ad747d7f35  push r8
000074ad747d7f37  push r9
000074ad747d7f39  push r10
000074ad747d7f3b  push r11
000074ad747d7f3d  sub rsp, 0xF0
000074ad747d7f44  vmovaps [rsp], xmm0
000074ad747d7f49  vmovaps [rsp+0x10], xmm1
000074ad747d7f4f  vmovaps [rsp+0x20], xmm2
000074ad747d7f55  vmovaps [rsp+0x30], xmm3
000074ad747d7f5b  vmovaps [rsp+0x40], xmm4
000074ad747d7f61  vmovaps [rsp+0x50], xmm5
000074ad747d7f67  vmovaps [rsp+0x60], xmm6
000074ad747d7f6d  vmovaps [rsp+0x70], xmm7
000074ad747d7f73  vmovaps [rsp+0x80], xmm8
000074ad747d7f7c  vmovaps [rsp+0x90], xmm9
000074ad747d7f85  vmovaps [rsp+0xA0], xmm11
000074ad747d7f8e  vmovaps [rsp+0xB0], xmm12
000074ad747d7f97  vmovaps [rsp+0xC0], xmm13
000074ad747d7fa0  vmovaps [rsp+0xD0], xmm14
000074ad747d7fa9  vmovaps [rsp+0xE0], xmm15
000074ad747d7fb2  sub rsp, 0x40
000074ad747d7fb6  lea rdi, [rsp]
000074ad747d7fba  lea rsi, [rsp+0x10]
000074ad747d7fbf  lea rdx, [rsp+0x20]
000074ad747d7fc4  lea rcx, [rsp+0x30]
000074ad747d7fc9  mov r8d, 0x00
000074ad747d7fcf  lea r9, [r15+0x3A8]
000074ad747d7fd6  movaps [rdi], xmm10
000074ad747d7fda  movaps [rsi], xmm9
000074ad747d7fde  movaps [rdx], xmm7
000074ad747d7fe1  movaps [rcx], xmm14
000074ad747d7fe5  mov rax, 0x5C17501CEA50
000074ad747d7fef  call rax
000074ad747d7ff1  movaps xmm10, [rsp]
000074ad747d7ff6  add rsp, 0x40
000074ad747d7ffa  vmovaps xmm0, [rsp]
000074ad747d7fff  vmovaps xmm1, [rsp+0x10]
000074ad747d8005  vmovaps xmm2, [rsp+0x20]
000074ad747d800b  vmovaps xmm3, [rsp+0x30]
000074ad747d8011  vmovaps xmm4, [rsp+0x40]
000074ad747d8017  vmovaps xmm5, [rsp+0x50]
000074ad747d801d  vmovaps xmm6, [rsp+0x60]
000074ad747d8023  vmovaps xmm7, [rsp+0x70]
000074ad747d8029  vmovaps xmm8, [rsp+0x80]
000074ad747d8032  vmovaps xmm9, [rsp+0x90]
000074ad747d803b  vmovaps xmm11, [rsp+0xA0]
000074ad747d8044  vmovaps xmm12, [rsp+0xB0]
000074ad747d804d  vmovaps xmm13, [rsp+0xC0]
000074ad747d8056  vmovaps xmm14, [rsp+0xD0]
000074ad747d805f  vmovaps xmm15, [rsp+0xE0]
000074ad747d8068  add rsp, 0xF0
000074ad747d806f  pop r11
000074ad747d8071  pop r10
000074ad747d8073  pop r9
000074ad747d8075  pop r8
000074ad747d8077  pop rsi
000074ad747d8078  pop rdi
000074ad747d8079  pop rdx
000074ad747d807a  pop rcx
000074ad747d807b  pop rax
000074ad747d807c  add rsp, 0x08
000074ad747d8080  jmp 0x000074AD747D68F1
000074ad747d8085  call 0x000074AD746E45A0
000074ad747d808a  jmp 0x000074AD747D68FE
000074ad747d808f  sub rsp, 0x08
000074ad747d8093  push rax
000074ad747d8094  push rcx
000074ad747d8095  push rdx
000074ad747d8096  push rdi
000074ad747d8097  push rsi
000074ad747d8098  push r8
000074ad747d809a  push r9
000074ad747d809c  push r10
000074ad747d809e  push r11
000074ad747d80a0  sub rsp, 0xF0
000074ad747d80a7  vmovaps [rsp], xmm0
000074ad747d80ac  vmovaps [rsp+0x10], xmm1
000074ad747d80b2  vmovaps [rsp+0x20], xmm2
000074ad747d80b8  vmovaps [rsp+0x30], xmm3
000074ad747d80be  vmovaps [rsp+0x40], xmm4
000074ad747d80c4  vmovaps [rsp+0x50], xmm6
000074ad747d80ca  vmovaps [rsp+0x60], xmm7
000074ad747d80d0  vmovaps [rsp+0x70], xmm8
000074ad747d80d6  vmovaps [rsp+0x80], xmm9
000074ad747d80df  vmovaps [rsp+0x90], xmm10
000074ad747d80e8  vmovaps [rsp+0xA0], xmm11
000074ad747d80f1  vmovaps [rsp+0xB0], xmm12
000074ad747d80fa  vmovaps [rsp+0xC0], xmm13
000074ad747d8103  vmovaps [rsp+0xD0], xmm14
000074ad747d810c  vmovaps [rsp+0xE0], xmm15
000074ad747d8115  sub rsp, 0x40
000074ad747d8119  lea rdi, [rsp]
000074ad747d811d  lea rsi, [rsp+0x10]
000074ad747d8122  lea rdx, [rsp+0x20]
000074ad747d8127  lea rcx, [rsp+0x30]
000074ad747d812c  mov r8d, 0x00
000074ad747d8132  lea r9, [r15+0x3A8]
000074ad747d8139  movaps [rdi], xmm5
000074ad747d813c  movaps [rsi], xmm6
000074ad747d813f  movaps [rdx], xmm7
000074ad747d8142  movaps [rcx], xmm9
000074ad747d8146  mov rax, 0x5C17501CEA50
000074ad747d8150  call rax
000074ad747d8152  movaps xmm5, [rsp]
000074ad747d8156  add rsp, 0x40
000074ad747d815a  vmovaps xmm0, [rsp]
000074ad747d815f  vmovaps xmm1, [rsp+0x10]
000074ad747d8165  vmovaps xmm2, [rsp+0x20]
000074ad747d816b  vmovaps xmm3, [rsp+0x30]
000074ad747d8171  vmovaps xmm4, [rsp+0x40]
000074ad747d8177  vmovaps xmm6, [rsp+0x50]
000074ad747d817d  vmovaps xmm7, [rsp+0x60]
000074ad747d8183  vmovaps xmm8, [rsp+0x70]
000074ad747d8189  vmovaps xmm9, [rsp+0x80]
000074ad747d8192  vmovaps xmm10, [rsp+0x90]
000074ad747d819b  vmovaps xmm11, [rsp+0xA0]
000074ad747d81a4  vmovaps xmm12, [rsp+0xB0]
000074ad747d81ad  vmovaps xmm13, [rsp+0xC0]
000074ad747d81b6  vmovaps xmm14, [rsp+0xD0]
000074ad747d81bf  vmovaps xmm15, [rsp+0xE0]
000074ad747d81c8  add rsp, 0xF0
000074ad747d81cf  pop r11
000074ad747d81d1  pop r10
000074ad747d81d3  pop r9
000074ad747d81d5  pop r8
000074ad747d81d7  pop rsi
000074ad747d81d8  pop rdi
000074ad747d81d9  pop rdx
000074ad747d81da  pop rcx
000074ad747d81db  pop rax
000074ad747d81dc  add rsp, 0x08
000074ad747d81e0  jmp 0x000074AD747D6930
000074ad747d81e5  sub rsp, 0x08
000074ad747d81e9  push rax
000074ad747d81ea  push rcx
000074ad747d81eb  push rdx
000074ad747d81ec  push rdi
000074ad747d81ed  push rsi
000074ad747d81ee  push r8
000074ad747d81f0  push r9
000074ad747d81f2  push r10
000074ad747d81f4  push r11
000074ad747d81f6  sub rsp, 0xF0
000074ad747d81fd  vmovaps [rsp], xmm0
000074ad747d8202  vmovaps [rsp+0x10], xmm1
000074ad747d8208  vmovaps [rsp+0x20], xmm2
000074ad747d820e  vmovaps [rsp+0x30], xmm3
000074ad747d8214  vmovaps [rsp+0x40], xmm4
000074ad747d821a  vmovaps [rsp+0x50], xmm5
000074ad747d8220  vmovaps [rsp+0x60], xmm6
000074ad747d8226  vmovaps [rsp+0x70], xmm8
000074ad747d822c  vmovaps [rsp+0x80], xmm9
000074ad747d8235  vmovaps [rsp+0x90], xmm10
000074ad747d823e  vmovaps [rsp+0xA0], xmm11
000074ad747d8247  vmovaps [rsp+0xB0], xmm12
000074ad747d8250  vmovaps [rsp+0xC0], xmm13
000074ad747d8259  vmovaps [rsp+0xD0], xmm14
000074ad747d8262  vmovaps [rsp+0xE0], xmm15
000074ad747d826b  sub rsp, 0x40
000074ad747d826f  lea rdi, [rsp]
000074ad747d8273  lea rsi, [rsp+0x10]
000074ad747d8278  lea rdx, [rsp+0x20]
000074ad747d827d  lea rcx, [rsp+0x30]
000074ad747d8282  mov r8d, 0x00
000074ad747d8288  lea r9, [r15+0x3A8]
000074ad747d828f  movaps [rdi], xmm7
000074ad747d8292  movaps [rsi], xmm13
000074ad747d8296  movaps [rdx], xmm1
000074ad747d8299  movaps [rcx], xmm9
000074ad747d829d  mov rax, 0x5C17501CEA50
000074ad747d82a7  call rax
000074ad747d82a9  movaps xmm7, [rsp]
000074ad747d82ad  add rsp, 0x40
000074ad747d82b1  vmovaps xmm0, [rsp]
000074ad747d82b6  vmovaps xmm1, [rsp+0x10]
000074ad747d82bc  vmovaps xmm2, [rsp+0x20]
000074ad747d82c2  vmovaps xmm3, [rsp+0x30]
000074ad747d82c8  vmovaps xmm4, [rsp+0x40]
000074ad747d82ce  vmovaps xmm5, [rsp+0x50]
000074ad747d82d4  vmovaps xmm6, [rsp+0x60]
000074ad747d82da  vmovaps xmm8, [rsp+0x70]
000074ad747d82e0  vmovaps xmm9, [rsp+0x80]
000074ad747d82e9  vmovaps xmm10, [rsp+0x90]
000074ad747d82f2  vmovaps xmm11, [rsp+0xA0]
000074ad747d82fb  vmovaps xmm12, [rsp+0xB0]
000074ad747d8304  vmovaps xmm13, [rsp+0xC0]
000074ad747d830d  vmovaps xmm14, [rsp+0xD0]
000074ad747d8316  vmovaps xmm15, [rsp+0xE0]
000074ad747d831f  add rsp, 0xF0
000074ad747d8326  pop r11
000074ad747d8328  pop r10
000074ad747d832a  pop r9
000074ad747d832c  pop r8
000074ad747d832e  pop rsi
000074ad747d832f  pop rdi
000074ad747d8330  pop rdx
000074ad747d8331  pop rcx
000074ad747d8332  pop rax
000074ad747d8333  add rsp, 0x08
000074ad747d8337  jmp 0x000074AD747D6955
000074ad747d833c  call 0x000074AD746E3320
000074ad747d8341  jmp 0x000074AD747D6978
000074ad747d8346  call 0x000074AD746DE950
000074ad747d834b  jmp 0x000074AD747D6982
000074ad747d8350  sub rsp, 0x08
000074ad747d8354  push rax
000074ad747d8355  push rcx
000074ad747d8356  push rdx
000074ad747d8357  push rdi
000074ad747d8358  push rsi
000074ad747d8359  push r8
000074ad747d835b  push r9
000074ad747d835d  push r10
000074ad747d835f  push r11
000074ad747d8361  sub rsp, 0xF0
000074ad747d8368  vmovaps [rsp], xmm0
000074ad747d836d  vmovaps [rsp+0x10], xmm1
000074ad747d8373  vmovaps [rsp+0x20], xmm3
000074ad747d8379  vmovaps [rsp+0x30], xmm4
000074ad747d837f  vmovaps [rsp+0x40], xmm5
000074ad747d8385  vmovaps [rsp+0x50], xmm6
000074ad747d838b  vmovaps [rsp+0x60], xmm7
000074ad747d8391  vmovaps [rsp+0x70], xmm8
000074ad747d8397  vmovaps [rsp+0x80], xmm9
000074ad747d83a0  vmovaps [rsp+0x90], xmm10
000074ad747d83a9  vmovaps [rsp+0xA0], xmm11
000074ad747d83b2  vmovaps [rsp+0xB0], xmm12
000074ad747d83bb  vmovaps [rsp+0xC0], xmm13
000074ad747d83c4  vmovaps [rsp+0xD0], xmm14
000074ad747d83cd  vmovaps [rsp+0xE0], xmm15
000074ad747d83d6  sub rsp, 0x40
000074ad747d83da  lea rdi, [rsp]
000074ad747d83de  lea rsi, [rsp+0x10]
000074ad747d83e3  lea rdx, [rsp+0x20]
000074ad747d83e8  lea rcx, [rsp+0x30]
000074ad747d83ed  mov r8d, 0x00
000074ad747d83f3  lea r9, [r15+0x3A8]
000074ad747d83fa  movaps [rdi], xmm2
000074ad747d83fd  movaps [rsi], xmm12
000074ad747d8401  movaps [rdx], xmm6
000074ad747d8404  movaps [rcx], xmm3
000074ad747d8407  mov rax, 0x5C17501CEA50
000074ad747d8411  call rax
000074ad747d8413  movaps xmm2, [rsp]
000074ad747d8417  add rsp, 0x40
000074ad747d841b  vmovaps xmm0, [rsp]
000074ad747d8420  vmovaps xmm1, [rsp+0x10]
000074ad747d8426  vmovaps xmm3, [rsp+0x20]
000074ad747d842c  vmovaps xmm4, [rsp+0x30]
000074ad747d8432  vmovaps xmm5, [rsp+0x40]
000074ad747d8438  vmovaps xmm6, [rsp+0x50]
000074ad747d843e  vmovaps xmm7, [rsp+0x60]
000074ad747d8444  vmovaps xmm8, [rsp+0x70]
000074ad747d844a  vmovaps xmm9, [rsp+0x80]
000074ad747d8453  vmovaps xmm10, [rsp+0x90]
000074ad747d845c  vmovaps xmm11, [rsp+0xA0]
000074ad747d8465  vmovaps xmm12, [rsp+0xB0]
000074ad747d846e  vmovaps xmm13, [rsp+0xC0]
000074ad747d8477  vmovaps xmm14, [rsp+0xD0]
000074ad747d8480  vmovaps xmm15, [rsp+0xE0]
000074ad747d8489  add rsp, 0xF0
000074ad747d8490  pop r11
000074ad747d8492  pop r10
000074ad747d8494  pop r9
000074ad747d8496  pop r8
000074ad747d8498  pop rsi
000074ad747d8499  pop rdi
000074ad747d849a  pop rdx
000074ad747d849b  pop rcx
000074ad747d849c  pop rax
000074ad747d849d  add rsp, 0x08
000074ad747d84a1  jmp 0x000074AD747D69C8
000074ad747d84a6  sub rsp, 0x08
000074ad747d84aa  push rax
000074ad747d84ab  push rcx
000074ad747d84ac  push rdx
000074ad747d84ad  push rdi
000074ad747d84ae  push rsi
000074ad747d84af  push r8
000074ad747d84b1  push r9
000074ad747d84b3  push r10
000074ad747d84b5  push r11
000074ad747d84b7  sub rsp, 0xF0
000074ad747d84be  vmovaps [rsp], xmm0
000074ad747d84c3  vmovaps [rsp+0x10], xmm1
000074ad747d84c9  vmovaps [rsp+0x20], xmm2
000074ad747d84cf  vmovaps [rsp+0x30], xmm3
000074ad747d84d5  vmovaps [rsp+0x40], xmm4
000074ad747d84db  vmovaps [rsp+0x50], xmm5
000074ad747d84e1  vmovaps [rsp+0x60], xmm7
000074ad747d84e7  vmovaps [rsp+0x70], xmm8
000074ad747d84ed  vmovaps [rsp+0x80], xmm9
000074ad747d84f6  vmovaps [rsp+0x90], xmm10
000074ad747d84ff  vmovaps [rsp+0xA0], xmm11
000074ad747d8508  vmovaps [rsp+0xB0], xmm12
000074ad747d8511  vmovaps [rsp+0xC0], xmm13
000074ad747d851a  vmovaps [rsp+0xD0], xmm14
000074ad747d8523  vmovaps [rsp+0xE0], xmm15
000074ad747d852c  sub rsp, 0x40
000074ad747d8530  lea rdi, [rsp]
000074ad747d8534  lea rsi, [rsp+0x10]
000074ad747d8539  lea rdx, [rsp+0x20]
000074ad747d853e  lea rcx, [rsp+0x30]
000074ad747d8543  mov r8d, 0x00
000074ad747d8549  lea r9, [r15+0x3A8]
000074ad747d8550  movaps [rdi], xmm6
000074ad747d8553  movaps [rsi], xmm10
000074ad747d8557  movaps [rdx], xmm12
000074ad747d855b  movaps [rcx], xmm1
000074ad747d855e  mov rax, 0x5C17501CEA50
000074ad747d8568  call rax
000074ad747d856a  movaps xmm6, [rsp]
000074ad747d856e  add rsp, 0x40
000074ad747d8572  vmovaps xmm0, [rsp]
000074ad747d8577  vmovaps xmm1, [rsp+0x10]
000074ad747d857d  vmovaps xmm2, [rsp+0x20]
000074ad747d8583  vmovaps xmm3, [rsp+0x30]
000074ad747d8589  vmovaps xmm4, [rsp+0x40]
000074ad747d858f  vmovaps xmm5, [rsp+0x50]
000074ad747d8595  vmovaps xmm7, [rsp+0x60]
000074ad747d859b  vmovaps xmm8, [rsp+0x70]
000074ad747d85a1  vmovaps xmm9, [rsp+0x80]
000074ad747d85aa  vmovaps xmm10, [rsp+0x90]
000074ad747d85b3  vmovaps xmm11, [rsp+0xA0]
000074ad747d85bc  vmovaps xmm12, [rsp+0xB0]
000074ad747d85c5  vmovaps xmm13, [rsp+0xC0]
000074ad747d85ce  vmovaps xmm14, [rsp+0xD0]
000074ad747d85d7  vmovaps xmm15, [rsp+0xE0]
000074ad747d85e0  add rsp, 0xF0
000074ad747d85e7  pop r11
000074ad747d85e9  pop r10
000074ad747d85eb  pop r9
000074ad747d85ed  pop r8
000074ad747d85ef  pop rsi
000074ad747d85f0  pop rdi
000074ad747d85f1  pop rdx
000074ad747d85f2  pop rcx
000074ad747d85f3  pop rax
000074ad747d85f4  add rsp, 0x08
000074ad747d85f8  jmp 0x000074AD747D69F6
000074ad747d85fd  sub rsp, 0x08
000074ad747d8601  push rax
000074ad747d8602  push rcx
000074ad747d8603  push rdx
000074ad747d8604  push rdi
000074ad747d8605  push rsi
000074ad747d8606  push r8
000074ad747d8608  push r9
000074ad747d860a  push r10
000074ad747d860c  push r11
000074ad747d860e  sub rsp, 0xF0
000074ad747d8615  vmovaps [rsp], xmm0
000074ad747d861a  vmovaps [rsp+0x10], xmm1
000074ad747d8620  vmovaps [rsp+0x20], xmm2
000074ad747d8626  vmovaps [rsp+0x30], xmm3
000074ad747d862c  vmovaps [rsp+0x40], xmm4
000074ad747d8632  vmovaps [rsp+0x50], xmm5
000074ad747d8638  vmovaps [rsp+0x60], xmm6
000074ad747d863e  vmovaps [rsp+0x70], xmm7
000074ad747d8644  vmovaps [rsp+0x80], xmm8
000074ad747d864d  vmovaps [rsp+0x90], xmm9
000074ad747d8656  vmovaps [rsp+0xA0], xmm11
000074ad747d865f  vmovaps [rsp+0xB0], xmm12
000074ad747d8668  vmovaps [rsp+0xC0], xmm13
000074ad747d8671  vmovaps [rsp+0xD0], xmm14
000074ad747d867a  vmovaps [rsp+0xE0], xmm15
000074ad747d8683  sub rsp, 0x40
000074ad747d8687  lea rdi, [rsp]
000074ad747d868b  lea rsi, [rsp+0x10]
000074ad747d8690  lea rdx, [rsp+0x20]
000074ad747d8695  lea rcx, [rsp+0x30]
000074ad747d869a  mov r8d, 0x00
000074ad747d86a0  lea r9, [r15+0x3A8]
000074ad747d86a7  movaps [rdi], xmm10
000074ad747d86ab  movaps [rsi], xmm5
000074ad747d86ae  movaps [rdx], xmm12
000074ad747d86b2  movaps [rcx], xmm1
000074ad747d86b5  mov rax, 0x5C17501CEA50
000074ad747d86bf  call rax
000074ad747d86c1  movaps xmm10, [rsp]
000074ad747d86c6  add rsp, 0x40
000074ad747d86ca  vmovaps xmm0, [rsp]
000074ad747d86cf  vmovaps xmm1, [rsp+0x10]
000074ad747d86d5  vmovaps xmm2, [rsp+0x20]
000074ad747d86db  vmovaps xmm3, [rsp+0x30]
000074ad747d86e1  vmovaps xmm4, [rsp+0x40]
000074ad747d86e7  vmovaps xmm5, [rsp+0x50]
000074ad747d86ed  vmovaps xmm6, [rsp+0x60]
000074ad747d86f3  vmovaps xmm7, [rsp+0x70]
000074ad747d86f9  vmovaps xmm8, [rsp+0x80]
000074ad747d8702  vmovaps xmm9, [rsp+0x90]
000074ad747d870b  vmovaps xmm11, [rsp+0xA0]
000074ad747d8714  vmovaps xmm12, [rsp+0xB0]
000074ad747d871d  vmovaps xmm13, [rsp+0xC0]
000074ad747d8726  vmovaps xmm14, [rsp+0xD0]
000074ad747d872f  vmovaps xmm15, [rsp+0xE0]
000074ad747d8738  add rsp, 0xF0
000074ad747d873f  pop r11
000074ad747d8741  pop r10
000074ad747d8743  pop r9
000074ad747d8745  pop r8
000074ad747d8747  pop rsi
000074ad747d8748  pop rdi
000074ad747d8749  pop rdx
000074ad747d874a  pop rcx
000074ad747d874b  pop rax
000074ad747d874c  add rsp, 0x08
000074ad747d8750  jmp 0x000074AD747D6A25
000074ad747d8755  sub rsp, 0x08
000074ad747d8759  push rax
000074ad747d875a  push rcx
000074ad747d875b  push rdx
000074ad747d875c  push rdi
000074ad747d875d  push rsi
000074ad747d875e  push r8
000074ad747d8760  push r9
000074ad747d8762  push r10
000074ad747d8764  push r11
000074ad747d8766  sub rsp, 0xF0
000074ad747d876d  vmovaps [rsp], xmm0
000074ad747d8772  vmovaps [rsp+0x10], xmm1
000074ad747d8778  vmovaps [rsp+0x20], xmm2
000074ad747d877e  vmovaps [rsp+0x30], xmm3
000074ad747d8784  vmovaps [rsp+0x40], xmm4
000074ad747d878a  vmovaps [rsp+0x50], xmm5
000074ad747d8790  vmovaps [rsp+0x60], xmm6
000074ad747d8796  vmovaps [rsp+0x70], xmm7
000074ad747d879c  vmovaps [rsp+0x80], xmm8
000074ad747d87a5  vmovaps [rsp+0x90], xmm9
000074ad747d87ae  vmovaps [rsp+0xA0], xmm10
000074ad747d87b7  vmovaps [rsp+0xB0], xmm11
000074ad747d87c0  vmovaps [rsp+0xC0], xmm13
000074ad747d87c9  vmovaps [rsp+0xD0], xmm14
000074ad747d87d2  vmovaps [rsp+0xE0], xmm15
000074ad747d87db  sub rsp, 0x40
000074ad747d87df  lea rdi, [rsp]
000074ad747d87e3  lea rsi, [rsp+0x10]
000074ad747d87e8  lea rdx, [rsp+0x20]
000074ad747d87ed  lea rcx, [rsp+0x30]
000074ad747d87f2  mov r8d, 0x00
000074ad747d87f8  lea r9, [r15+0x3A8]
000074ad747d87ff  movaps [rdi], xmm12
000074ad747d8803  movaps [rsi], xmm7
000074ad747d8806  movaps [rdx], xmm15
000074ad747d880a  movaps [rcx], xmm1
000074ad747d880d  mov rax, 0x5C17501CEA50
000074ad747d8817  call rax
000074ad747d8819  movaps xmm12, [rsp]
000074ad747d881e  add rsp, 0x40
000074ad747d8822  vmovaps xmm0, [rsp]
000074ad747d8827  vmovaps xmm1, [rsp+0x10]
000074ad747d882d  vmovaps xmm2, [rsp+0x20]
000074ad747d8833  vmovaps xmm3, [rsp+0x30]
000074ad747d8839  vmovaps xmm4, [rsp+0x40]
000074ad747d883f  vmovaps xmm5, [rsp+0x50]
000074ad747d8845  vmovaps xmm6, [rsp+0x60]
000074ad747d884b  vmovaps xmm7, [rsp+0x70]
000074ad747d8851  vmovaps xmm8, [rsp+0x80]
000074ad747d885a  vmovaps xmm9, [rsp+0x90]
000074ad747d8863  vmovaps xmm10, [rsp+0xA0]
000074ad747d886c  vmovaps xmm11, [rsp+0xB0]
000074ad747d8875  vmovaps xmm13, [rsp+0xC0]
000074ad747d887e  vmovaps xmm14, [rsp+0xD0]
000074ad747d8887  vmovaps xmm15, [rsp+0xE0]
000074ad747d8890  add rsp, 0xF0
000074ad747d8897  pop r11
000074ad747d8899  pop r10
000074ad747d889b  pop r9
000074ad747d889d  pop r8
000074ad747d889f  pop rsi
000074ad747d88a0  pop rdi
000074ad747d88a1  pop rdx
000074ad747d88a2  pop rcx
000074ad747d88a3  pop rax
000074ad747d88a4  add rsp, 0x08
000074ad747d88a8  jmp 0x000074AD747D6A4E
000074ad747d88ad  call 0x000074AD746D64F0
000074ad747d88b2  jmp 0x000074AD747D6A58
000074ad747d88b7  call 0x000074AD746E5820
000074ad747d88bc  jmp 0x000074AD747D6A62
000074ad747d88c1  sub rsp, 0x08
000074ad747d88c5  push rax
000074ad747d88c6  push rcx
000074ad747d88c7  push rdx
000074ad747d88c8  push rdi
000074ad747d88c9  push rsi
000074ad747d88ca  push r8
000074ad747d88cc  push r9
000074ad747d88ce  push r10
000074ad747d88d0  push r11
000074ad747d88d2  sub rsp, 0xF0
000074ad747d88d9  vmovaps [rsp], xmm0
000074ad747d88de  vmovaps [rsp+0x10], xmm1
000074ad747d88e4  vmovaps [rsp+0x20], xmm2
000074ad747d88ea  vmovaps [rsp+0x30], xmm3
000074ad747d88f0  vmovaps [rsp+0x40], xmm4
000074ad747d88f6  vmovaps [rsp+0x50], xmm5
000074ad747d88fc  vmovaps [rsp+0x60], xmm6
000074ad747d8902  vmovaps [rsp+0x70], xmm8
000074ad747d8908  vmovaps [rsp+0x80], xmm9
000074ad747d8911  vmovaps [rsp+0x90], xmm10
000074ad747d891a  vmovaps [rsp+0xA0], xmm11
000074ad747d8923  vmovaps [rsp+0xB0], xmm12
000074ad747d892c  vmovaps [rsp+0xC0], xmm13
000074ad747d8935  vmovaps [rsp+0xD0], xmm14
000074ad747d893e  vmovaps [rsp+0xE0], xmm15
000074ad747d8947  sub rsp, 0x40
000074ad747d894b  lea rdi, [rsp]
000074ad747d894f  lea rsi, [rsp+0x10]
000074ad747d8954  lea rdx, [rsp+0x20]
000074ad747d8959  lea rcx, [rsp+0x30]
000074ad747d895e  mov r8d, 0x00
000074ad747d8964  lea r9, [r15+0x3A8]
000074ad747d896b  movaps [rdi], xmm7
000074ad747d896e  movaps [rsi], xmm2
000074ad747d8971  movaps [rdx], xmm9
000074ad747d8975  movaps [rcx], xmm11
000074ad747d8979  mov rax, 0x5C17501CEA50
000074ad747d8983  call rax
000074ad747d8985  movaps xmm7, [rsp]
000074ad747d8989  add rsp, 0x40
000074ad747d898d  vmovaps xmm0, [rsp]
000074ad747d8992  vmovaps xmm1, [rsp+0x10]
000074ad747d8998  vmovaps xmm2, [rsp+0x20]
000074ad747d899e  vmovaps xmm3, [rsp+0x30]
000074ad747d89a4  vmovaps xmm4, [rsp+0x40]
000074ad747d89aa  vmovaps xmm5, [rsp+0x50]
000074ad747d89b0  vmovaps xmm6, [rsp+0x60]
000074ad747d89b6  vmovaps xmm8, [rsp+0x70]
000074ad747d89bc  vmovaps xmm9, [rsp+0x80]
000074ad747d89c5  vmovaps xmm10, [rsp+0x90]
000074ad747d89ce  vmovaps xmm11, [rsp+0xA0]
000074ad747d89d7  vmovaps xmm12, [rsp+0xB0]
000074ad747d89e0  vmovaps xmm13, [rsp+0xC0]
000074ad747d89e9  vmovaps xmm14, [rsp+0xD0]
000074ad747d89f2  vmovaps xmm15, [rsp+0xE0]
000074ad747d89fb  add rsp, 0xF0
000074ad747d8a02  pop r11
000074ad747d8a04  pop r10
000074ad747d8a06  pop r9
000074ad747d8a08  pop r8
000074ad747d8a0a  pop rsi
000074ad747d8a0b  pop rdi
000074ad747d8a0c  pop rdx
000074ad747d8a0d  pop rcx
000074ad747d8a0e  pop rax
000074ad747d8a0f  add rsp, 0x08
000074ad747d8a13  jmp 0x000074AD747D6A96
000074ad747d8a18  sub rsp, 0x08
000074ad747d8a1c  push rax
000074ad747d8a1d  push rcx
000074ad747d8a1e  push rdx
000074ad747d8a1f  push rdi
000074ad747d8a20  push rsi
000074ad747d8a21  push r8
000074ad747d8a23  push r9
000074ad747d8a25  push r10
000074ad747d8a27  push r11
000074ad747d8a29  sub rsp, 0xF0
000074ad747d8a30  vmovaps [rsp], xmm0
000074ad747d8a35  vmovaps [rsp+0x10], xmm1
000074ad747d8a3b  vmovaps [rsp+0x20], xmm2
000074ad747d8a41  vmovaps [rsp+0x30], xmm3
000074ad747d8a47  vmovaps [rsp+0x40], xmm4
000074ad747d8a4d  vmovaps [rsp+0x50], xmm5
000074ad747d8a53  vmovaps [rsp+0x60], xmm6
000074ad747d8a59  vmovaps [rsp+0x70], xmm7
000074ad747d8a5f  vmovaps [rsp+0x80], xmm8
000074ad747d8a68  vmovaps [rsp+0x90], xmm10
000074ad747d8a71  vmovaps [rsp+0xA0], xmm11
000074ad747d8a7a  vmovaps [rsp+0xB0], xmm12
000074ad747d8a83  vmovaps [rsp+0xC0], xmm13
000074ad747d8a8c  vmovaps [rsp+0xD0], xmm14
000074ad747d8a95  vmovaps [rsp+0xE0], xmm15
000074ad747d8a9e  sub rsp, 0x40
000074ad747d8aa2  lea rdi, [rsp]
000074ad747d8aa6  lea rsi, [rsp+0x10]
000074ad747d8aab  lea rdx, [rsp+0x20]
000074ad747d8ab0  lea rcx, [rsp+0x30]
000074ad747d8ab5  mov r8d, 0x00
000074ad747d8abb  lea r9, [r15+0x3A8]
000074ad747d8ac2  movaps [rdi], xmm9
000074ad747d8ac6  movaps [rsi], xmm6
000074ad747d8ac9  movaps [rdx], xmm1
000074ad747d8acc  movaps [rcx], xmm11
000074ad747d8ad0  mov rax, 0x5C17501CEA50
000074ad747d8ada  call rax
000074ad747d8adc  movaps xmm9, [rsp]
000074ad747d8ae1  add rsp, 0x40
000074ad747d8ae5  vmovaps xmm0, [rsp]
000074ad747d8aea  vmovaps xmm1, [rsp+0x10]
000074ad747d8af0  vmovaps xmm2, [rsp+0x20]
000074ad747d8af6  vmovaps xmm3, [rsp+0x30]
000074ad747d8afc  vmovaps xmm4, [rsp+0x40]
000074ad747d8b02  vmovaps xmm5, [rsp+0x50]
000074ad747d8b08  vmovaps xmm6, [rsp+0x60]
000074ad747d8b0e  vmovaps xmm7, [rsp+0x70]
000074ad747d8b14  vmovaps xmm8, [rsp+0x80]
000074ad747d8b1d  vmovaps xmm10, [rsp+0x90]
000074ad747d8b26  vmovaps xmm11, [rsp+0xA0]
000074ad747d8b2f  vmovaps xmm12, [rsp+0xB0]
000074ad747d8b38  vmovaps xmm13, [rsp+0xC0]
000074ad747d8b41  vmovaps xmm14, [rsp+0xD0]
000074ad747d8b4a  vmovaps xmm15, [rsp+0xE0]
000074ad747d8b53  add rsp, 0xF0
000074ad747d8b5a  pop r11
000074ad747d8b5c  pop r10
000074ad747d8b5e  pop r9
000074ad747d8b60  pop r8
000074ad747d8b62  pop rsi
000074ad747d8b63  pop rdi
000074ad747d8b64  pop rdx
000074ad747d8b65  pop rcx
000074ad747d8b66  pop rax
000074ad747d8b67  add rsp, 0x08
000074ad747d8b6b  jmp 0x000074AD747D6ABC
000074ad747d8b70  sub rsp, 0x08
000074ad747d8b74  push rax
000074ad747d8b75  push rcx
000074ad747d8b76  push rdx
000074ad747d8b77  push rdi
000074ad747d8b78  push rsi
000074ad747d8b79  push r8
000074ad747d8b7b  push r9
000074ad747d8b7d  push r10
000074ad747d8b7f  push r11
000074ad747d8b81  sub rsp, 0xF0
000074ad747d8b88  vmovaps [rsp], xmm0
000074ad747d8b8d  vmovaps [rsp+0x10], xmm1
000074ad747d8b93  vmovaps [rsp+0x20], xmm2
000074ad747d8b99  vmovaps [rsp+0x30], xmm3
000074ad747d8b9f  vmovaps [rsp+0x40], xmm4
000074ad747d8ba5  vmovaps [rsp+0x50], xmm5
000074ad747d8bab  vmovaps [rsp+0x60], xmm6
000074ad747d8bb1  vmovaps [rsp+0x70], xmm7
000074ad747d8bb7  vmovaps [rsp+0x80], xmm8
000074ad747d8bc0  vmovaps [rsp+0x90], xmm9
000074ad747d8bc9  vmovaps [rsp+0xA0], xmm10
000074ad747d8bd2  vmovaps [rsp+0xB0], xmm12
000074ad747d8bdb  vmovaps [rsp+0xC0], xmm13
000074ad747d8be4  vmovaps [rsp+0xD0], xmm14
000074ad747d8bed  vmovaps [rsp+0xE0], xmm15
000074ad747d8bf6  sub rsp, 0x40
000074ad747d8bfa  lea rdi, [rsp]
000074ad747d8bfe  lea rsi, [rsp+0x10]
000074ad747d8c03  lea rdx, [rsp+0x20]
000074ad747d8c08  lea rcx, [rsp+0x30]
000074ad747d8c0d  mov r8d, 0x00
000074ad747d8c13  lea r9, [r15+0x3A8]
000074ad747d8c1a  movaps [rdi], xmm11
000074ad747d8c1e  movaps [rsi], xmm10
000074ad747d8c22  movaps [rdx], xmm8
000074ad747d8c26  movaps [rcx], xmm1
000074ad747d8c29  mov rax, 0x5C17501CEA50
000074ad747d8c33  call rax
000074ad747d8c35  movaps xmm11, [rsp]
000074ad747d8c3a  add rsp, 0x40
000074ad747d8c3e  vmovaps xmm0, [rsp]
000074ad747d8c43  vmovaps xmm1, [rsp+0x10]
000074ad747d8c49  vmovaps xmm2, [rsp+0x20]
000074ad747d8c4f  vmovaps xmm3, [rsp+0x30]
000074ad747d8c55  vmovaps xmm4, [rsp+0x40]
000074ad747d8c5b  vmovaps xmm5, [rsp+0x50]
000074ad747d8c61  vmovaps xmm6, [rsp+0x60]
000074ad747d8c67  vmovaps xmm7, [rsp+0x70]
000074ad747d8c6d  vmovaps xmm8, [rsp+0x80]
000074ad747d8c76  vmovaps xmm9, [rsp+0x90]
000074ad747d8c7f  vmovaps xmm10, [rsp+0xA0]
000074ad747d8c88  vmovaps xmm12, [rsp+0xB0]
000074ad747d8c91  vmovaps xmm13, [rsp+0xC0]
000074ad747d8c9a  vmovaps xmm14, [rsp+0xD0]
000074ad747d8ca3  vmovaps xmm15, [rsp+0xE0]
000074ad747d8cac  add rsp, 0xF0
000074ad747d8cb3  pop r11
000074ad747d8cb5  pop r10
000074ad747d8cb7  pop r9
000074ad747d8cb9  pop r8
000074ad747d8cbb  pop rsi
000074ad747d8cbc  pop rdi
000074ad747d8cbd  pop rdx
000074ad747d8cbe  pop rcx
000074ad747d8cbf  pop rax
000074ad747d8cc0  add rsp, 0x08
000074ad747d8cc4  jmp 0x000074AD747D6AE2
000074ad747d8cc9  sub rsp, 0x08
000074ad747d8ccd  push rax
000074ad747d8cce  push rcx
000074ad747d8ccf  push rdx
000074ad747d8cd0  push rdi
000074ad747d8cd1  push rsi
000074ad747d8cd2  push r8
000074ad747d8cd4  push r9
000074ad747d8cd6  push r10
000074ad747d8cd8  push r11
000074ad747d8cda  sub rsp, 0xF0
000074ad747d8ce1  vmovaps [rsp], xmm0
000074ad747d8ce6  vmovaps [rsp+0x10], xmm1
000074ad747d8cec  vmovaps [rsp+0x20], xmm2
000074ad747d8cf2  vmovaps [rsp+0x30], xmm3
000074ad747d8cf8  vmovaps [rsp+0x40], xmm4
000074ad747d8cfe  vmovaps [rsp+0x50], xmm5
000074ad747d8d04  vmovaps [rsp+0x60], xmm6
000074ad747d8d0a  vmovaps [rsp+0x70], xmm7
000074ad747d8d10  vmovaps [rsp+0x80], xmm8
000074ad747d8d19  vmovaps [rsp+0x90], xmm9
000074ad747d8d22  vmovaps [rsp+0xA0], xmm11
000074ad747d8d2b  vmovaps [rsp+0xB0], xmm12
000074ad747d8d34  vmovaps [rsp+0xC0], xmm13
000074ad747d8d3d  vmovaps [rsp+0xD0], xmm14
000074ad747d8d46  vmovaps [rsp+0xE0], xmm15
000074ad747d8d4f  sub rsp, 0x40
000074ad747d8d53  lea rdi, [rsp]
000074ad747d8d57  lea rsi, [rsp+0x10]
000074ad747d8d5c  lea rdx, [rsp+0x20]
000074ad747d8d61  lea rcx, [rsp+0x30]
000074ad747d8d66  mov r8d, 0x00
000074ad747d8d6c  lea r9, [r15+0x3A8]
000074ad747d8d73  movaps [rdi], xmm10
000074ad747d8d77  movaps [rsi], xmm12
000074ad747d8d7b  movaps [rdx], xmm13
000074ad747d8d7f  movaps [rcx], xmm1
000074ad747d8d82  mov rax, 0x5C17501CEA50
000074ad747d8d8c  call rax
000074ad747d8d8e  movaps xmm10, [rsp]
000074ad747d8d93  add rsp, 0x40
000074ad747d8d97  vmovaps xmm0, [rsp]
000074ad747d8d9c  vmovaps xmm1, [rsp+0x10]
000074ad747d8da2  vmovaps xmm2, [rsp+0x20]
000074ad747d8da8  vmovaps xmm3, [rsp+0x30]
000074ad747d8dae  vmovaps xmm4, [rsp+0x40]
000074ad747d8db4  vmovaps xmm5, [rsp+0x50]
000074ad747d8dba  vmovaps xmm6, [rsp+0x60]
000074ad747d8dc0  vmovaps xmm7, [rsp+0x70]
000074ad747d8dc6  vmovaps xmm8, [rsp+0x80]
000074ad747d8dcf  vmovaps xmm9, [rsp+0x90]
000074ad747d8dd8  vmovaps xmm11, [rsp+0xA0]
000074ad747d8de1  vmovaps xmm12, [rsp+0xB0]
000074ad747d8dea  vmovaps xmm13, [rsp+0xC0]
000074ad747d8df3  vmovaps xmm14, [rsp+0xD0]
000074ad747d8dfc  vmovaps xmm15, [rsp+0xE0]
000074ad747d8e05  add rsp, 0xF0
000074ad747d8e0c  pop r11
000074ad747d8e0e  pop r10
000074ad747d8e10  pop r9
000074ad747d8e12  pop r8
000074ad747d8e14  pop rsi
000074ad747d8e15  pop rdi
000074ad747d8e16  pop rdx
000074ad747d8e17  pop rcx
000074ad747d8e18  pop rax
000074ad747d8e19  add rsp, 0x08
000074ad747d8e1d  jmp 0x000074AD747D6B08
000074ad747d8e22  call 0x000074AD746D64F0
000074ad747d8e27  jmp 0x000074AD747D6B12
000074ad747d8e2c  call 0x000074AD746E3320
000074ad747d8e31  jmp 0x000074AD747D6B1C
000074ad747d8e36  sub rsp, 0x08
000074ad747d8e3a  push rax
000074ad747d8e3b  push rcx
000074ad747d8e3c  push rdx
000074ad747d8e3d  push rdi
000074ad747d8e3e  push rsi
000074ad747d8e3f  push r8
000074ad747d8e41  push r9
000074ad747d8e43  push r10
000074ad747d8e45  push r11
000074ad747d8e47  sub rsp, 0xF0
000074ad747d8e4e  vmovaps [rsp], xmm0
000074ad747d8e53  vmovaps [rsp+0x10], xmm1
000074ad747d8e59  vmovaps [rsp+0x20], xmm2
000074ad747d8e5f  vmovaps [rsp+0x30], xmm3
000074ad747d8e65  vmovaps [rsp+0x40], xmm4
000074ad747d8e6b  vmovaps [rsp+0x50], xmm5
000074ad747d8e71  vmovaps [rsp+0x60], xmm6
000074ad747d8e77  vmovaps [rsp+0x70], xmm7
000074ad747d8e7d  vmovaps [rsp+0x80], xmm9
000074ad747d8e86  vmovaps [rsp+0x90], xmm10
000074ad747d8e8f  vmovaps [rsp+0xA0], xmm11
000074ad747d8e98  vmovaps [rsp+0xB0], xmm12
000074ad747d8ea1  vmovaps [rsp+0xC0], xmm13
000074ad747d8eaa  vmovaps [rsp+0xD0], xmm14
000074ad747d8eb3  vmovaps [rsp+0xE0], xmm15
000074ad747d8ebc  sub rsp, 0x40
000074ad747d8ec0  lea rdi, [rsp]
000074ad747d8ec4  lea rsi, [rsp+0x10]
000074ad747d8ec9  lea rdx, [rsp+0x20]
000074ad747d8ece  lea rcx, [rsp+0x30]
000074ad747d8ed3  mov r8d, 0x00
000074ad747d8ed9  lea r9, [r15+0x3A8]
000074ad747d8ee0  movaps [rdi], xmm8
000074ad747d8ee4  movaps [rsi], xmm7
000074ad747d8ee7  movaps [rdx], xmm4
000074ad747d8eea  movaps [rcx], xmm12
000074ad747d8eee  mov rax, 0x5C17501CEA50
000074ad747d8ef8  call rax
000074ad747d8efa  movaps xmm8, [rsp]
000074ad747d8eff  add rsp, 0x40
000074ad747d8f03  vmovaps xmm0, [rsp]
000074ad747d8f08  vmovaps xmm1, [rsp+0x10]
000074ad747d8f0e  vmovaps xmm2, [rsp+0x20]
000074ad747d8f14  vmovaps xmm3, [rsp+0x30]
000074ad747d8f1a  vmovaps xmm4, [rsp+0x40]
000074ad747d8f20  vmovaps xmm5, [rsp+0x50]
000074ad747d8f26  vmovaps xmm6, [rsp+0x60]
000074ad747d8f2c  vmovaps xmm7, [rsp+0x70]
000074ad747d8f32  vmovaps xmm9, [rsp+0x80]
000074ad747d8f3b  vmovaps xmm10, [rsp+0x90]
000074ad747d8f44  vmovaps xmm11, [rsp+0xA0]
000074ad747d8f4d  vmovaps xmm12, [rsp+0xB0]
000074ad747d8f56  vmovaps xmm13, [rsp+0xC0]
000074ad747d8f5f  vmovaps xmm14, [rsp+0xD0]
000074ad747d8f68  vmovaps xmm15, [rsp+0xE0]
000074ad747d8f71  add rsp, 0xF0
000074ad747d8f78  pop r11
000074ad747d8f7a  pop r10
000074ad747d8f7c  pop r9
000074ad747d8f7e  pop r8
000074ad747d8f80  pop rsi
000074ad747d8f81  pop rdi
000074ad747d8f82  pop rdx
000074ad747d8f83  pop rcx
000074ad747d8f84  pop rax
000074ad747d8f85  add rsp, 0x08
000074ad747d8f89  jmp 0x000074AD747D6B45
000074ad747d8f8e  sub rsp, 0x08
000074ad747d8f92  push rax
000074ad747d8f93  push rcx
000074ad747d8f94  push rdx
000074ad747d8f95  push rdi
000074ad747d8f96  push rsi
000074ad747d8f97  push r8
000074ad747d8f99  push r9
000074ad747d8f9b  push r10
000074ad747d8f9d  push r11
000074ad747d8f9f  sub rsp, 0xF0
000074ad747d8fa6  vmovaps [rsp], xmm0
000074ad747d8fab  vmovaps [rsp+0x10], xmm1
000074ad747d8fb1  vmovaps [rsp+0x20], xmm2
000074ad747d8fb7  vmovaps [rsp+0x30], xmm3
000074ad747d8fbd  vmovaps [rsp+0x40], xmm4
000074ad747d8fc3  vmovaps [rsp+0x50], xmm5
000074ad747d8fc9  vmovaps [rsp+0x60], xmm6
000074ad747d8fcf  vmovaps [rsp+0x70], xmm8
000074ad747d8fd5  vmovaps [rsp+0x80], xmm9
000074ad747d8fde  vmovaps [rsp+0x90], xmm10
000074ad747d8fe7  vmovaps [rsp+0xA0], xmm11
000074ad747d8ff0  vmovaps [rsp+0xB0], xmm12
000074ad747d8ff9  vmovaps [rsp+0xC0], xmm13
000074ad747d9002  vmovaps [rsp+0xD0], xmm14
000074ad747d900b  vmovaps [rsp+0xE0], xmm15
000074ad747d9014  sub rsp, 0x40
000074ad747d9018  lea rdi, [rsp]
000074ad747d901c  lea rsi, [rsp+0x10]
000074ad747d9021  lea rdx, [rsp+0x20]
000074ad747d9026  lea rcx, [rsp+0x30]
000074ad747d902b  mov r8d, 0x00
000074ad747d9031  lea r9, [r15+0x3A8]
000074ad747d9038  movaps [rdi], xmm7
000074ad747d903b  movaps [rsi], xmm9
000074ad747d903f  movaps [rdx], xmm14
000074ad747d9043  movaps [rcx], xmm12
000074ad747d9047  mov rax, 0x5C17501CEA50
000074ad747d9051  call rax
000074ad747d9053  movaps xmm7, [rsp]
000074ad747d9057  add rsp, 0x40
000074ad747d905b  vmovaps xmm0, [rsp]
000074ad747d9060  vmovaps xmm1, [rsp+0x10]
000074ad747d9066  vmovaps xmm2, [rsp+0x20]
000074ad747d906c  vmovaps xmm3, [rsp+0x30]
000074ad747d9072  vmovaps xmm4, [rsp+0x40]
000074ad747d9078  vmovaps xmm5, [rsp+0x50]
000074ad747d907e  vmovaps xmm6, [rsp+0x60]
000074ad747d9084  vmovaps xmm8, [rsp+0x70]
000074ad747d908a  vmovaps xmm9, [rsp+0x80]
000074ad747d9093  vmovaps xmm10, [rsp+0x90]
000074ad747d909c  vmovaps xmm11, [rsp+0xA0]
000074ad747d90a5  vmovaps xmm12, [rsp+0xB0]
000074ad747d90ae  vmovaps xmm13, [rsp+0xC0]
000074ad747d90b7  vmovaps xmm14, [rsp+0xD0]
000074ad747d90c0  vmovaps xmm15, [rsp+0xE0]
000074ad747d90c9  add rsp, 0xF0
000074ad747d90d0  pop r11
000074ad747d90d2  pop r10
000074ad747d90d4  pop r9
000074ad747d90d6  pop r8
000074ad747d90d8  pop rsi
000074ad747d90d9  pop rdi
000074ad747d90da  pop rdx
000074ad747d90db  pop rcx
000074ad747d90dc  pop rax
000074ad747d90dd  add rsp, 0x08
000074ad747d90e1  jmp 0x000074AD747D6B6D
000074ad747d90e6  sub rsp, 0x08
000074ad747d90ea  push rax
000074ad747d90eb  push rcx
000074ad747d90ec  push rdx
000074ad747d90ed  push rdi
000074ad747d90ee  push rsi
000074ad747d90ef  push r8
000074ad747d90f1  push r9
000074ad747d90f3  push r10
000074ad747d90f5  push r11
000074ad747d90f7  sub rsp, 0xF0
000074ad747d90fe  vmovaps [rsp], xmm0
000074ad747d9103  vmovaps [rsp+0x10], xmm1
000074ad747d9109  vmovaps [rsp+0x20], xmm2
000074ad747d910f  vmovaps [rsp+0x30], xmm3
000074ad747d9115  vmovaps [rsp+0x40], xmm4
000074ad747d911b  vmovaps [rsp+0x50], xmm5
000074ad747d9121  vmovaps [rsp+0x60], xmm6
000074ad747d9127  vmovaps [rsp+0x70], xmm7
000074ad747d912d  vmovaps [rsp+0x80], xmm8
000074ad747d9136  vmovaps [rsp+0x90], xmm9
000074ad747d913f  vmovaps [rsp+0xA0], xmm10
000074ad747d9148  vmovaps [rsp+0xB0], xmm11
000074ad747d9151  vmovaps [rsp+0xC0], xmm13
000074ad747d915a  vmovaps [rsp+0xD0], xmm14
000074ad747d9163  vmovaps [rsp+0xE0], xmm15
000074ad747d916c  sub rsp, 0x40
000074ad747d9170  lea rdi, [rsp]
000074ad747d9174  lea rsi, [rsp+0x10]
000074ad747d9179  lea rdx, [rsp+0x20]
000074ad747d917e  lea rcx, [rsp+0x30]
000074ad747d9183  mov r8d, 0x00
000074ad747d9189  lea r9, [r15+0x3A8]
000074ad747d9190  movaps [rdi], xmm12
000074ad747d9194  movaps [rsi], xmm11
000074ad747d9198  movaps [rdx], xmm15
000074ad747d919c  movaps [rcx], xmm14
000074ad747d91a0  mov rax, 0x5C17501CEA50
000074ad747d91aa  call rax
000074ad747d91ac  movaps xmm12, [rsp]
000074ad747d91b1  add rsp, 0x40
000074ad747d91b5  vmovaps xmm0, [rsp]
000074ad747d91ba  vmovaps xmm1, [rsp+0x10]
000074ad747d91c0  vmovaps xmm2, [rsp+0x20]
000074ad747d91c6  vmovaps xmm3, [rsp+0x30]
000074ad747d91cc  vmovaps xmm4, [rsp+0x40]
000074ad747d91d2  vmovaps xmm5, [rsp+0x50]
000074ad747d91d8  vmovaps xmm6, [rsp+0x60]
000074ad747d91de  vmovaps xmm7, [rsp+0x70]
000074ad747d91e4  vmovaps xmm8, [rsp+0x80]
000074ad747d91ed  vmovaps xmm9, [rsp+0x90]
000074ad747d91f6  vmovaps xmm10, [rsp+0xA0]
000074ad747d91ff  vmovaps xmm11, [rsp+0xB0]
000074ad747d9208  vmovaps xmm13, [rsp+0xC0]
000074ad747d9211  vmovaps xmm14, [rsp+0xD0]
000074ad747d921a  vmovaps xmm15, [rsp+0xE0]
000074ad747d9223  add rsp, 0xF0
000074ad747d922a  pop r11
000074ad747d922c  pop r10
000074ad747d922e  pop r9
000074ad747d9230  pop r8
000074ad747d9232  pop rsi
000074ad747d9233  pop rdi
000074ad747d9234  pop rdx
000074ad747d9235  pop rcx
000074ad747d9236  pop rax
000074ad747d9237  add rsp, 0x08
000074ad747d923b  jmp 0x000074AD747D6B96
000074ad747d9240  sub rsp, 0x08
000074ad747d9244  push rax
000074ad747d9245  push rcx
000074ad747d9246  push rdx
000074ad747d9247  push rdi
000074ad747d9248  push rsi
000074ad747d9249  push r8
000074ad747d924b  push r9
000074ad747d924d  push r10
000074ad747d924f  push r11
000074ad747d9251  sub rsp, 0xF0
000074ad747d9258  vmovaps [rsp], xmm0
000074ad747d925d  vmovaps [rsp+0x10], xmm1
000074ad747d9263  vmovaps [rsp+0x20], xmm2
000074ad747d9269  vmovaps [rsp+0x30], xmm3
000074ad747d926f  vmovaps [rsp+0x40], xmm4
000074ad747d9275  vmovaps [rsp+0x50], xmm5
000074ad747d927b  vmovaps [rsp+0x60], xmm6
000074ad747d9281  vmovaps [rsp+0x70], xmm7
000074ad747d9287  vmovaps [rsp+0x80], xmm8
000074ad747d9290  vmovaps [rsp+0x90], xmm9
000074ad747d9299  vmovaps [rsp+0xA0], xmm10
000074ad747d92a2  vmovaps [rsp+0xB0], xmm12
000074ad747d92ab  vmovaps [rsp+0xC0], xmm13
000074ad747d92b4  vmovaps [rsp+0xD0], xmm14
000074ad747d92bd  vmovaps [rsp+0xE0], xmm15
000074ad747d92c6  sub rsp, 0x40
000074ad747d92ca  lea rdi, [rsp]
000074ad747d92ce  lea rsi, [rsp+0x10]
000074ad747d92d3  lea rdx, [rsp+0x20]
000074ad747d92d8  lea rcx, [rsp+0x30]
000074ad747d92dd  mov r8d, 0x00
000074ad747d92e3  lea r9, [r15+0x3A8]
000074ad747d92ea  movaps [rdi], xmm11
000074ad747d92ee  movaps [rsi], xmm10
000074ad747d92f2  movaps [rdx], xmm13
000074ad747d92f6  movaps [rcx], xmm15
000074ad747d92fa  mov rax, 0x5C17501CEA50
000074ad747d9304  call rax
000074ad747d9306  movaps xmm11, [rsp]
000074ad747d930b  add rsp, 0x40
000074ad747d930f  vmovaps xmm0, [rsp]
000074ad747d9314  vmovaps xmm1, [rsp+0x10]
000074ad747d931a  vmovaps xmm2, [rsp+0x20]
000074ad747d9320  vmovaps xmm3, [rsp+0x30]
000074ad747d9326  vmovaps xmm4, [rsp+0x40]
000074ad747d932c  vmovaps xmm5, [rsp+0x50]
000074ad747d9332  vmovaps xmm6, [rsp+0x60]
000074ad747d9338  vmovaps xmm7, [rsp+0x70]
000074ad747d933e  vmovaps xmm8, [rsp+0x80]
000074ad747d9347  vmovaps xmm9, [rsp+0x90]
000074ad747d9350  vmovaps xmm10, [rsp+0xA0]
000074ad747d9359  vmovaps xmm12, [rsp+0xB0]
000074ad747d9362  vmovaps xmm13, [rsp+0xC0]
000074ad747d936b  vmovaps xmm14, [rsp+0xD0]
000074ad747d9374  vmovaps xmm15, [rsp+0xE0]
000074ad747d937d  add rsp, 0xF0
000074ad747d9384  pop r11
000074ad747d9386  pop r10
000074ad747d9388  pop r9
000074ad747d938a  pop r8
000074ad747d938c  pop rsi
000074ad747d938d  pop rdi
000074ad747d938e  pop rdx
000074ad747d938f  pop rcx
000074ad747d9390  pop rax
000074ad747d9391  add rsp, 0x08
000074ad747d9395  jmp 0x000074AD747D6BBF
000074ad747d939a  call 0x000074AD746E5820
000074ad747d939f  jmp 0x000074AD747D6BCC
000074ad747d93a4  call 0x000074AD746E45A0
000074ad747d93a9  jmp 0x000074AD747D6BD9
000074ad747d93ae  sub rsp, 0x08
000074ad747d93b2  push rax
000074ad747d93b3  push rcx
000074ad747d93b4  push rdx
000074ad747d93b5  push rdi
000074ad747d93b6  push rsi
000074ad747d93b7  push r8
000074ad747d93b9  push r9
000074ad747d93bb  push r10
000074ad747d93bd  push r11
000074ad747d93bf  sub rsp, 0xF0
000074ad747d93c6  vmovaps [rsp], xmm0
000074ad747d93cb  vmovaps [rsp+0x10], xmm1
000074ad747d93d1  vmovaps [rsp+0x20], xmm2
000074ad747d93d7  vmovaps [rsp+0x30], xmm3
000074ad747d93dd  vmovaps [rsp+0x40], xmm4
000074ad747d93e3  vmovaps [rsp+0x50], xmm5
000074ad747d93e9  vmovaps [rsp+0x60], xmm6
000074ad747d93ef  vmovaps [rsp+0x70], xmm7
000074ad747d93f5  vmovaps [rsp+0x80], xmm8
000074ad747d93fe  vmovaps [rsp+0x90], xmm9
000074ad747d9407  vmovaps [rsp+0xA0], xmm11
000074ad747d9410  vmovaps [rsp+0xB0], xmm12
000074ad747d9419  vmovaps [rsp+0xC0], xmm13
000074ad747d9422  vmovaps [rsp+0xD0], xmm14
000074ad747d942b  vmovaps [rsp+0xE0], xmm15
000074ad747d9434  sub rsp, 0x40
000074ad747d9438  lea rdi, [rsp]
000074ad747d943c  lea rsi, [rsp+0x10]
000074ad747d9441  lea rdx, [rsp+0x20]
000074ad747d9446  lea rcx, [rsp+0x30]
000074ad747d944b  mov r8d, 0x00
000074ad747d9451  lea r9, [r15+0x3A8]
000074ad747d9458  movaps [rdi], xmm10
000074ad747d945c  movaps [rsi], xmm8
000074ad747d9460  movaps [rdx], xmm1
000074ad747d9463  movaps [rcx], xmm13
000074ad747d9467  mov rax, 0x5C17501CEA50
000074ad747d9471  call rax
000074ad747d9473  movaps xmm10, [rsp]
000074ad747d9478  add rsp, 0x40
000074ad747d947c  vmovaps xmm0, [rsp]
000074ad747d9481  vmovaps xmm1, [rsp+0x10]
000074ad747d9487  vmovaps xmm2, [rsp+0x20]
000074ad747d948d  vmovaps xmm3, [rsp+0x30]
000074ad747d9493  vmovaps xmm4, [rsp+0x40]
000074ad747d9499  vmovaps xmm5, [rsp+0x50]
000074ad747d949f  vmovaps xmm6, [rsp+0x60]
000074ad747d94a5  vmovaps xmm7, [rsp+0x70]
000074ad747d94ab  vmovaps xmm8, [rsp+0x80]
000074ad747d94b4  vmovaps xmm9, [rsp+0x90]
000074ad747d94bd  vmovaps xmm11, [rsp+0xA0]
000074ad747d94c6  vmovaps xmm12, [rsp+0xB0]
000074ad747d94cf  vmovaps xmm13, [rsp+0xC0]
000074ad747d94d8  vmovaps xmm14, [rsp+0xD0]
000074ad747d94e1  vmovaps xmm15, [rsp+0xE0]
000074ad747d94ea  add rsp, 0xF0
000074ad747d94f1  pop r11
000074ad747d94f3  pop r10
000074ad747d94f5  pop r9
000074ad747d94f7  pop r8
000074ad747d94f9  pop rsi
000074ad747d94fa  pop rdi
000074ad747d94fb  pop rdx
000074ad747d94fc  pop rcx
000074ad747d94fd  pop rax
000074ad747d94fe  add rsp, 0x08
000074ad747d9502  jmp 0x000074AD747D6C0F
000074ad747d9507  call 0x000074AD746D64F0
000074ad747d950c  jmp 0x000074AD747D6C21
000074ad747d9511  sub rsp, 0x08
000074ad747d9515  push rax
000074ad747d9516  push rcx
000074ad747d9517  push rdx
000074ad747d9518  push rdi
000074ad747d9519  push rsi
000074ad747d951a  push r8
000074ad747d951c  push r9
000074ad747d951e  push r10
000074ad747d9520  push r11
000074ad747d9522  sub rsp, 0xF0
000074ad747d9529  vmovaps [rsp], xmm0
000074ad747d952e  vmovaps [rsp+0x10], xmm1
000074ad747d9534  vmovaps [rsp+0x20], xmm2
000074ad747d953a  vmovaps [rsp+0x30], xmm3
000074ad747d9540  vmovaps [rsp+0x40], xmm4
000074ad747d9546  vmovaps [rsp+0x50], xmm5
000074ad747d954c  vmovaps [rsp+0x60], xmm6
000074ad747d9552  vmovaps [rsp+0x70], xmm7
000074ad747d9558  vmovaps [rsp+0x80], xmm8
000074ad747d9561  vmovaps [rsp+0x90], xmm10
000074ad747d956a  vmovaps [rsp+0xA0], xmm11
000074ad747d9573  vmovaps [rsp+0xB0], xmm12
000074ad747d957c  vmovaps [rsp+0xC0], xmm13
000074ad747d9585  vmovaps [rsp+0xD0], xmm14
000074ad747d958e  vmovaps [rsp+0xE0], xmm15
000074ad747d9597  sub rsp, 0x40
000074ad747d959b  lea rdi, [rsp]
000074ad747d959f  lea rsi, [rsp+0x10]
000074ad747d95a4  lea rdx, [rsp+0x20]
000074ad747d95a9  lea rcx, [rsp+0x30]
000074ad747d95ae  mov r8d, 0x00
000074ad747d95b4  lea r9, [r15+0x3A8]
000074ad747d95bb  movaps [rdi], xmm9
000074ad747d95bf  movaps [rsi], xmm7
000074ad747d95c2  movaps [rdx], xmm14
000074ad747d95c6  movaps [rcx], xmm13
000074ad747d95ca  mov rax, 0x5C17501CEA50
000074ad747d95d4  call rax
000074ad747d95d6  movaps xmm9, [rsp]
000074ad747d95db  add rsp, 0x40
000074ad747d95df  vmovaps xmm0, [rsp]
000074ad747d95e4  vmovaps xmm1, [rsp+0x10]
000074ad747d95ea  vmovaps xmm2, [rsp+0x20]
000074ad747d95f0  vmovaps xmm3, [rsp+0x30]
000074ad747d95f6  vmovaps xmm4, [rsp+0x40]
000074ad747d95fc  vmovaps xmm5, [rsp+0x50]
000074ad747d9602  vmovaps xmm6, [rsp+0x60]
000074ad747d9608  vmovaps xmm7, [rsp+0x70]
000074ad747d960e  vmovaps xmm8, [rsp+0x80]
000074ad747d9617  vmovaps xmm10, [rsp+0x90]
000074ad747d9620  vmovaps xmm11, [rsp+0xA0]
000074ad747d9629  vmovaps xmm12, [rsp+0xB0]
000074ad747d9632  vmovaps xmm13, [rsp+0xC0]
000074ad747d963b  vmovaps xmm14, [rsp+0xD0]
000074ad747d9644  vmovaps xmm15, [rsp+0xE0]
000074ad747d964d  add rsp, 0xF0
000074ad747d9654  pop r11
000074ad747d9656  pop r10
000074ad747d9658  pop r9
000074ad747d965a  pop r8
000074ad747d965c  pop rsi
000074ad747d965d  pop rdi
000074ad747d965e  pop rdx
000074ad747d965f  pop rcx
000074ad747d9660  pop rax
000074ad747d9661  add rsp, 0x08
000074ad747d9665  jmp 0x000074AD747D6C4F
000074ad747d966a  sub rsp, 0x08
000074ad747d966e  push rax
000074ad747d966f  push rcx
000074ad747d9670  push rdx
000074ad747d9671  push rdi
000074ad747d9672  push rsi
000074ad747d9673  push r8
000074ad747d9675  push r9
000074ad747d9677  push r10
000074ad747d9679  push r11
000074ad747d967b  sub rsp, 0xF0
000074ad747d9682  vmovaps [rsp], xmm0
000074ad747d9687  vmovaps [rsp+0x10], xmm1
000074ad747d968d  vmovaps [rsp+0x20], xmm2
000074ad747d9693  vmovaps [rsp+0x30], xmm3
000074ad747d9699  vmovaps [rsp+0x40], xmm4
000074ad747d969f  vmovaps [rsp+0x50], xmm5
000074ad747d96a5  vmovaps [rsp+0x60], xmm6
000074ad747d96ab  vmovaps [rsp+0x70], xmm7
000074ad747d96b1  vmovaps [rsp+0x80], xmm8
000074ad747d96ba  vmovaps [rsp+0x90], xmm9
000074ad747d96c3  vmovaps [rsp+0xA0], xmm10
000074ad747d96cc  vmovaps [rsp+0xB0], xmm11
000074ad747d96d5  vmovaps [rsp+0xC0], xmm12
000074ad747d96de  vmovaps [rsp+0xD0], xmm14
000074ad747d96e7  vmovaps [rsp+0xE0], xmm15
000074ad747d96f0  sub rsp, 0x40
000074ad747d96f4  lea rdi, [rsp]
000074ad747d96f8  lea rsi, [rsp+0x10]
000074ad747d96fd  lea rdx, [rsp+0x20]
000074ad747d9702  lea rcx, [rsp+0x30]
000074ad747d9707  mov r8d, 0x00
000074ad747d970d  lea r9, [r15+0x3A8]
000074ad747d9714  movaps [rdi], xmm13
000074ad747d9718  movaps [rsi], xmm12
000074ad747d971c  movaps [rdx], xmm15
000074ad747d9720  movaps [rcx], xmm14
000074ad747d9724  mov rax, 0x5C17501CEA50
000074ad747d972e  call rax
000074ad747d9730  movaps xmm13, [rsp]
000074ad747d9735  add rsp, 0x40
000074ad747d9739  vmovaps xmm0, [rsp]
000074ad747d973e  vmovaps xmm1, [rsp+0x10]
000074ad747d9744  vmovaps xmm2, [rsp+0x20]
000074ad747d974a  vmovaps xmm3, [rsp+0x30]
000074ad747d9750  vmovaps xmm4, [rsp+0x40]
000074ad747d9756  vmovaps xmm5, [rsp+0x50]
000074ad747d975c  vmovaps xmm6, [rsp+0x60]
000074ad747d9762  vmovaps xmm7, [rsp+0x70]
000074ad747d9768  vmovaps xmm8, [rsp+0x80]
000074ad747d9771  vmovaps xmm9, [rsp+0x90]
000074ad747d977a  vmovaps xmm10, [rsp+0xA0]
000074ad747d9783  vmovaps xmm11, [rsp+0xB0]
000074ad747d978c  vmovaps xmm12, [rsp+0xC0]
000074ad747d9795  vmovaps xmm14, [rsp+0xD0]
000074ad747d979e  vmovaps xmm15, [rsp+0xE0]
000074ad747d97a7  add rsp, 0xF0
000074ad747d97ae  pop r11
000074ad747d97b0  pop r10
000074ad747d97b2  pop r9
000074ad747d97b4  pop r8
000074ad747d97b6  pop rsi
000074ad747d97b7  pop rdi
000074ad747d97b8  pop rdx
000074ad747d97b9  pop rcx
000074ad747d97ba  pop rax
000074ad747d97bb  add rsp, 0x08
000074ad747d97bf  jmp 0x000074AD747D6C7D
000074ad747d97c4  sub rsp, 0x08
000074ad747d97c8  push rax
000074ad747d97c9  push rcx
000074ad747d97ca  push rdx
000074ad747d97cb  push rdi
000074ad747d97cc  push rsi
000074ad747d97cd  push r8
000074ad747d97cf  push r9
000074ad747d97d1  push r10
000074ad747d97d3  push r11
000074ad747d97d5  sub rsp, 0xF0
000074ad747d97dc  vmovaps [rsp], xmm0
000074ad747d97e1  vmovaps [rsp+0x10], xmm1
000074ad747d97e7  vmovaps [rsp+0x20], xmm2
000074ad747d97ed  vmovaps [rsp+0x30], xmm3
000074ad747d97f3  vmovaps [rsp+0x40], xmm4
000074ad747d97f9  vmovaps [rsp+0x50], xmm5
000074ad747d97ff  vmovaps [rsp+0x60], xmm6
000074ad747d9805  vmovaps [rsp+0x70], xmm7
000074ad747d980b  vmovaps [rsp+0x80], xmm8
000074ad747d9814  vmovaps [rsp+0x90], xmm9
000074ad747d981d  vmovaps [rsp+0xA0], xmm10
000074ad747d9826  vmovaps [rsp+0xB0], xmm11
000074ad747d982f  vmovaps [rsp+0xC0], xmm12
000074ad747d9838  vmovaps [rsp+0xD0], xmm13
000074ad747d9841  vmovaps [rsp+0xE0], xmm15
000074ad747d984a  sub rsp, 0x40
000074ad747d984e  lea rdi, [rsp]
000074ad747d9852  lea rsi, [rsp+0x10]
000074ad747d9857  lea rdx, [rsp+0x20]
000074ad747d985c  lea rcx, [rsp+0x30]
000074ad747d9861  mov r8d, 0x00
000074ad747d9867  lea r9, [r15+0x3A8]
000074ad747d986e  movaps [rdi], xmm14
000074ad747d9872  movaps [rsi], xmm11
000074ad747d9876  movaps [rdx], xmm1
000074ad747d9879  movaps [rcx], xmm15
000074ad747d987d  mov rax, 0x5C17501CEA50
000074ad747d9887  call rax
000074ad747d9889  movaps xmm14, [rsp]
000074ad747d988e  add rsp, 0x40
000074ad747d9892  vmovaps xmm0, [rsp]
000074ad747d9897  vmovaps xmm1, [rsp+0x10]
000074ad747d989d  vmovaps xmm2, [rsp+0x20]
000074ad747d98a3  vmovaps xmm3, [rsp+0x30]
000074ad747d98a9  vmovaps xmm4, [rsp+0x40]
000074ad747d98af  vmovaps xmm5, [rsp+0x50]
000074ad747d98b5  vmovaps xmm6, [rsp+0x60]
000074ad747d98bb  vmovaps xmm7, [rsp+0x70]
000074ad747d98c1  vmovaps xmm8, [rsp+0x80]
000074ad747d98ca  vmovaps xmm9, [rsp+0x90]
000074ad747d98d3  vmovaps xmm10, [rsp+0xA0]
000074ad747d98dc  vmovaps xmm11, [rsp+0xB0]
000074ad747d98e5  vmovaps xmm12, [rsp+0xC0]
000074ad747d98ee  vmovaps xmm13, [rsp+0xD0]
000074ad747d98f7  vmovaps xmm15, [rsp+0xE0]
000074ad747d9900  add rsp, 0xF0
000074ad747d9907  pop r11
000074ad747d9909  pop r10
000074ad747d990b  pop r9
000074ad747d990d  pop r8
000074ad747d990f  pop rsi
000074ad747d9910  pop rdi
000074ad747d9911  pop rdx
000074ad747d9912  pop rcx
000074ad747d9913  pop rax
000074ad747d9914  add rsp, 0x08
000074ad747d9918  jmp 0x000074AD747D6CAB
000074ad747d991d  call 0x000074AD746ACF70
000074ad747d9922  jmp 0x000074AD747D6CB9
000074ad747d9927  call 0x000074AD7460C380
000074ad747d992c  jmp 0x000074AD747D6CC3
000074ad747d9931  call 0x000074AD74608C20
000074ad747d9936  jmp 0x000074AD747D6CCD
000074ad747d993b  call 0x000074AD7460D600
000074ad747d9940  jmp 0x000074AD747D6CD7
000074ad747d9945  int3
000074ad747d9946  nop [rax+rax*1], ax
000074ad747d994f  nop
000074ad747d9950  mov eax, [r15+0x48]
000074ad747d9954  lea r14d, [eax+0x01]
000074ad747d9959  mov [rsp+0x10], r14d
000074ad747d995e  mov r14d, r14d
000074ad747d9961  mov [r15+0x48], r14
000074ad747d9965  xor eax, eax
000074ad747d9967  mov r14d, [rsp+0x10]
000074ad747d996c  cmp r14d, 0x1F4
000074ad747d9973  cmc
000074ad747d9974  lahf
000074ad747d9975  seto al
000074ad747d9978  mov [r15+0x108], eax
000074ad747d997f  mov eax, [r15+0x108]
000074ad747d9986  sahf
000074ad747d9987  jnz 0x000074AD747D99B9
000074ad747d9989  cmp dword ptr [r15+0x318], 0x00
000074ad747d9991  jz 0x000074AD747DD2E0
000074ad747d9997  nop [rax+rax*1], ax
000074ad747d99a0  nop [rax+rax*1], eax
000074ad747d99a8  mov eax, 0x410670
000074ad747d99ad  mov [r15+0x100], rax
000074ad747d99b4  jmp 0x000074AD745FE110
000074ad747d99b9  cmp dword ptr [r15+0x318], 0x00
000074ad747d99c1  jz 0x000074AD747D99F0
000074ad747d99c7  nop [rax+rax*1], ax
000074ad747d99d0  nop [rax+rax*1], eax
000074ad747d99d8  mov eax, 0x4104EC
000074ad747d99dd  mov [r15+0x100], rax
000074ad747d99e4  jmp 0x000074AD745FE110
000074ad747d99e9  int3
000074ad747d99ea  int3
000074ad747d99eb  nop [rax+rax*1], eax
000074ad747d99f0  mov rax, [r15+0x40]
000074ad747d99f4  vxorps xmm1, xmm1, xmm1
000074ad747d99f8  vpbroadcastq xmm1, xmm1
000074ad747d99fd  vxorps xmm15, xmm15, xmm15
000074ad747d9a02  vpbroadcastq xmm15, xmm15
000074ad747d9a07  lea r14, [rax+0x30]
000074ad747d9a0b  mov r12, [r13+r14*1]
000074ad747d9a10  lea r14, [rax+0x38]
000074ad747d9a14  mov r11, [r13+r14*1]
000074ad747d9a19  movq xmm14, r12
000074ad747d9a1e  movq xmm13, r11
000074ad747d9a23  movq xmm14, xmm14
000074ad747d9a28  movq xmm13, xmm13
000074ad747d9a2d  vmovaps [rsp+0x10], xmm13
000074ad747d9a33  movq xmm13, xmm13
000074ad747d9a38  movaps [r15+0x270], xmm13
000074ad747d9a40  movaps xmm13, [r15+0x160]
000074ad747d9a48  vmovaps [rsp+0x20], xmm13
000074ad747d9a4e  vmovaps xmm12, [rsp+0x20]
000074ad747d9a54  por xmm13, xmm12
000074ad747d9a59  lea r14, [rax+0x20]
000074ad747d9a5d  mov r12, [r13+r14*1]
000074ad747d9a62  lea r14, [rax+0x28]
000074ad747d9a66  mov r11, [r13+r14*1]
000074ad747d9a6b  movq xmm12, r12
000074ad747d9a70  movq xmm11, r11
000074ad747d9a75  movq xmm12, xmm12
000074ad747d9a7a  movq xmm11, xmm11
000074ad747d9a7f  movaps xmm10, [r15+0x2D0]
000074ad747d9a87  vmovaps [rsp+0x20], xmm10
000074ad747d9a8d  vmovaps xmm9, [rsp+0x20]
000074ad747d9a93  por xmm10, xmm9
000074ad747d9a98  movaps xmm9, [r15+0x300]
000074ad747d9aa0  vmovaps [rsp+0x20], xmm9
000074ad747d9aa6  vmovaps xmm8, [rsp+0x20]
000074ad747d9aac  por xmm9, xmm8
000074ad747d9ab1  movaps xmm8, [r15+0x2B0]
000074ad747d9ab9  vmovaps [rsp+0x20], xmm8
000074ad747d9abf  vmovaps xmm7, [rsp+0x20]
000074ad747d9ac5  por xmm8, xmm7
000074ad747d9aca  movaps xmm7, [r15+0x180]
000074ad747d9ad2  vmovaps [rsp+0x20], xmm7
000074ad747d9ad8  vmovaps xmm6, [rsp+0x20]
000074ad747d9ade  por xmm7, xmm6
000074ad747d9ae2  lea r14, [rax+0x10]
000074ad747d9ae6  mov r12, [r13+r14*1]
000074ad747d9aeb  lea r14, [rax+0x18]
000074ad747d9aef  mov r11, [r13+r14*1]
000074ad747d9af4  movq xmm6, r12
000074ad747d9af9  movq xmm5, r11
000074ad747d9afe  movq xmm6, xmm6
000074ad747d9b02  movq xmm5, xmm5
000074ad747d9b06  movaps xmm4, [r15+0x200]
000074ad747d9b0e  vmovaps [rsp+0x20], xmm4
000074ad747d9b14  vmovaps xmm3, [rsp+0x20]
000074ad747d9b1a  por xmm4, xmm3
000074ad747d9b1e  movaps xmm3, [r15+0x1F0]
000074ad747d9b26  vmovaps [rsp+0x20], xmm3
000074ad747d9b2c  vmovaps xmm2, [rsp+0x20]
000074ad747d9b32  por xmm3, xmm2
000074ad747d9b36  movaps xmm2, [r15+0x2E0]
000074ad747d9b3e  vmovaps [rsp+0x20], xmm2
000074ad747d9b44  vmovaps [rsp+0x30], xmm1
000074ad747d9b4a  vmovaps xmm1, [rsp+0x20]
000074ad747d9b50  por xmm2, xmm1
000074ad747d9b54  movaps xmm1, [r15+0x2A0]
000074ad747d9b5c  vmovaps [rsp+0x20], xmm1
000074ad747d9b62  vmovaps [rsp+0x40], xmm15
000074ad747d9b68  vmovaps xmm15, [rsp+0x20]
000074ad747d9b6e  por xmm1, xmm15
000074ad747d9b73  movaps xmm15, [r15+0x280]
000074ad747d9b7b  vmovaps [rsp+0x20], xmm15
000074ad747d9b81  vmovaps [rsp+0x50], xmm1
000074ad747d9b87  vmovaps xmm1, [rsp+0x20]
000074ad747d9b8d  por xmm15, xmm1
000074ad747d9b92  movaps xmm1, [r15+0x1C0]
000074ad747d9b9a  vmovaps [rsp+0x20], xmm1
000074ad747d9ba0  vmovaps [rsp+0x60], xmm15
000074ad747d9ba6  vmovaps xmm15, [rsp+0x20]
000074ad747d9bac  por xmm1, xmm15
000074ad747d9bb1  movaps xmm15, [r15+0x210]
000074ad747d9bb9  vmovaps [rsp+0x20], xmm15
000074ad747d9bbf  vmovaps [rsp+0x70], xmm1
000074ad747d9bc5  vmovaps xmm1, [rsp+0x20]
000074ad747d9bcb  por xmm15, xmm1
000074ad747d9bd0  mov r14, [r13+rax*1]
000074ad747d9bd5  vmovq xmm1, r14
000074ad747d9bda  vpbroadcastq xmm1, xmm1
000074ad747d9bdf  vmovaps [rsp+0x20], xmm1
000074ad747d9be5  vxorps xmm1, xmm1, xmm1
000074ad747d9be9  vpbroadcastq xmm1, xmm1
000074ad747d9bee  mov r14, [r15+0xF8]
000074ad747d9bf5  vmovaps [rsp+0x80], xmm1
000074ad747d9bfe  movups xmm1, [r13+r14*1]
000074ad747d9c04  vmovaps [rsp+0x90], xmm1
000074ad747d9c0d  vxorps xmm1, xmm1, xmm1
000074ad747d9c11  vpbroadcastq xmm1, xmm1
000074ad747d9c16  lea r12, [rax+0x08]
000074ad747d9c1a  mov rax, [r13+r12*1]
000074ad747d9c1f  vmovaps [rsp+0xA0], xmm1
000074ad747d9c28  movq xmm1, rax
000074ad747d9c2d  movaps [r15+0x240], xmm1
000074ad747d9c35  mov rax, [r15+0x50]
000074ad747d9c39  mov [r15+0x60], rax
000074ad747d9c3d  mov qword ptr [r15+0x58], 0x40
000074ad747d9c45  vmovaps xmm1, [rsp+0x30]
000074ad747d9c4b  vmovaps [rsp+0x30], xmm15
000074ad747d9c51  vmovaps xmm15, [rsp+0x90]
000074ad747d9c5a  vmovaps [rsp+0x90], xmm14
000074ad747d9c63  vmovaps xmm14, [rsp+0x20]
000074ad747d9c69  vmovaps [rsp+0x20], xmm13
000074ad747d9c6f  vmovaps [rsp+0xB0], xmm12
000074ad747d9c78  movaps xmm13, xmm1
000074ad747d9c7c  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d9c81  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d9c87  vptest xmm12, xmm12
000074ad747d9c8c  jnz 0x000074AD747DA72F
000074ad747d9c92  movaps xmm1, [r15+0x250]
000074ad747d9c9a  vmovaps xmm15, [rsp+0x40]
000074ad747d9ca0  vmovaps [rsp+0x40], xmm13
000074ad747d9ca6  movaps xmm12, xmm15
000074ad747d9caa  vfmadd231pd xmm12, xmm1, xmm14
000074ad747d9caf  vcmppd xmm13, xmm12, xmm12, 0x03
000074ad747d9cb5  vptest xmm13, xmm13
000074ad747d9cba  jnz 0x000074AD747DA888
000074ad747d9cc0  movaps xmm15, [r15+0x1E0]
000074ad747d9cc8  vmovaps [rsp+0xC0], xmm15
000074ad747d9cd1  vmovaps xmm13, [rsp+0xC0]
000074ad747d9cda  por xmm15, xmm13
000074ad747d9cdf  movaps xmm13, [r15+0x1D0]
000074ad747d9ce7  vmovaps [rsp+0xC0], xmm13
000074ad747d9cf0  vmovaps [rsp+0xD0], xmm1
000074ad747d9cf9  vmovaps xmm1, [rsp+0xC0]
000074ad747d9d02  por xmm13, xmm1
000074ad747d9d07  movaps xmm1, [r15+0x2C0]
000074ad747d9d0f  vmovaps [rsp+0xC0], xmm1
000074ad747d9d18  vmovaps [rsp+0xE0], xmm15
000074ad747d9d21  vmovaps xmm15, [rsp+0xC0]
000074ad747d9d2a  por xmm1, xmm15
000074ad747d9d2f  movaps xmm15, [r15+0x290]
000074ad747d9d37  vmovaps [rsp+0xC0], xmm15
000074ad747d9d40  vmovaps [rsp+0xF0], xmm1
000074ad747d9d49  vmovaps xmm1, [rsp+0xC0]
000074ad747d9d52  por xmm15, xmm1
000074ad747d9d57  movaps xmm1, [r15+0x260]
000074ad747d9d5f  vmovaps [rsp+0xC0], xmm1
000074ad747d9d68  vmovaps [rsp+0x100], xmm15
000074ad747d9d71  vmovaps xmm15, [rsp+0xC0]
000074ad747d9d7a  por xmm1, xmm15
000074ad747d9d7f  vmovaps xmm15, [rsp+0xD0]
000074ad747d9d88  vmovaps [rsp+0xC0], xmm1
000074ad747d9d91  vmovaps xmm1, [rsp+0xD0]
000074ad747d9d9a  por xmm15, xmm1
000074ad747d9d9f  lea r12, [r14+0xC0]
000074ad747d9da6  movups xmm1, [r13+r12*1]
000074ad747d9dac  mov [rsp+0xD0], rax
000074ad747d9db4  xor eax, eax
000074ad747d9db6  mov r12d, 0x40
000074ad747d9dbc  mov r11d, 0x200
000074ad747d9dc2  cmp r12, r11
000074ad747d9dc5  cmc
000074ad747d9dc6  lahf
000074ad747d9dc7  seto al
000074ad747d9dca  mov [r15+0x108], eax
000074ad747d9dd1  vmovaps [rsp+0x110], xmm1
000074ad747d9dda  vmovaps xmm1, [rsp+0x80]
000074ad747d9de3  vmovaps [rsp+0x80], xmm15
000074ad747d9dec  vmovaps xmm15, [rsp+0x110]
000074ad747d9df5  vmovaps [rsp+0x110], xmm13
000074ad747d9dfe  vmovaps [rsp+0x120], xmm12
000074ad747d9e07  movaps xmm13, xmm1
000074ad747d9e0b  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d9e10  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d9e16  vptest xmm12, xmm12
000074ad747d9e1b  jnz 0x000074AD747DA9EB
000074ad747d9e21  lea rax, [r14+0xB0]
000074ad747d9e28  movups xmm1, [r13+rax*1]
000074ad747d9e2e  vmovaps xmm15, [rsp+0xA0]
000074ad747d9e37  vmovaps [rsp+0xA0], xmm13
000074ad747d9e40  movaps xmm12, xmm15
000074ad747d9e44  vfmadd231pd xmm12, xmm1, xmm14
000074ad747d9e49  vcmppd xmm13, xmm12, xmm12, 0x03
000074ad747d9e4f  vptest xmm13, xmm13
000074ad747d9e54  jnz 0x000074AD747DAB4E
000074ad747d9e5a  vmovaps xmm1, [rsp+0x30]
000074ad747d9e60  vmovaps xmm15, [rsp+0x30]
000074ad747d9e66  por xmm1, xmm15
000074ad747d9e6b  movaps [r15+0x210], xmm1
000074ad747d9e73  vmovaps xmm15, [rsp+0x70]
000074ad747d9e79  vmovaps xmm14, [rsp+0x70]
000074ad747d9e7f  por xmm15, xmm14
000074ad747d9e84  movaps [r15+0x1C0], xmm15
000074ad747d9e8c  vmovaps xmm14, [rsp+0x60]
000074ad747d9e92  vmovaps xmm13, [rsp+0x60]
000074ad747d9e98  por xmm14, xmm13
000074ad747d9e9d  movaps [r15+0x280], xmm14
000074ad747d9ea5  vmovaps xmm13, [rsp+0x50]
000074ad747d9eab  vmovaps [rsp+0x30], xmm1
000074ad747d9eb1  vmovaps xmm1, [rsp+0x50]
000074ad747d9eb7  por xmm13, xmm1
000074ad747d9ebc  movaps [r15+0x2A0], xmm13
000074ad747d9ec4  vmovaps [rsp+0x50], xmm2
000074ad747d9eca  vmovaps xmm1, [rsp+0x50]
000074ad747d9ed0  por xmm2, xmm1
000074ad747d9ed4  movaps [r15+0x2E0], xmm2
000074ad747d9edc  vmovaps [rsp+0x50], xmm3
000074ad747d9ee2  vmovaps xmm1, [rsp+0x50]
000074ad747d9ee8  por xmm3, xmm1
000074ad747d9eec  movaps [r15+0x1F0], xmm3
000074ad747d9ef4  vmovaps xmm1, [rsp+0x80]
000074ad747d9efd  vmovaps [rsp+0x50], xmm15
000074ad747d9f03  vmovaps xmm15, [rsp+0x80]
000074ad747d9f0c  por xmm1, xmm15
000074ad747d9f11  movaps [r15+0x250], xmm1
000074ad747d9f19  vmovaps xmm1, [rsp+0xC0]
000074ad747d9f22  vmovaps xmm15, [rsp+0xC0]
000074ad747d9f2b  por xmm1, xmm15
000074ad747d9f30  movaps [r15+0x260], xmm1
000074ad747d9f38  vmovaps xmm15, [rsp+0x100]
000074ad747d9f41  vmovaps [rsp+0x60], xmm1
000074ad747d9f47  vmovaps xmm1, [rsp+0x100]
000074ad747d9f50  por xmm15, xmm1
000074ad747d9f55  movaps [r15+0x290], xmm15
000074ad747d9f5d  vmovaps xmm1, [rsp+0xF0]
000074ad747d9f66  vmovaps [rsp+0x70], xmm15
000074ad747d9f6c  vmovaps xmm15, [rsp+0xF0]
000074ad747d9f75  por xmm1, xmm15
000074ad747d9f7a  movaps [r15+0x2C0], xmm1
000074ad747d9f82  movq xmm15, qword ptr [r15+0x240]
000074ad747d9f8b  vmovaps [rsp+0x80], xmm15
000074ad747d9f94  vpermilpd xmm15, xmm15, 0x00
000074ad747d9f9a  vmovaps [rsp+0xC0], xmm1
000074ad747d9fa3  vmovaps xmm1, [rsp+0x40]
000074ad747d9fa9  vmovaps [rsp+0x40], xmm15
000074ad747d9faf  vmovaps xmm15, [rsp+0x30]
000074ad747d9fb5  vmovaps [rsp+0x30], xmm14
000074ad747d9fbb  vmovaps xmm14, [rsp+0x40]
000074ad747d9fc1  vmovaps [rsp+0x40], xmm13
000074ad747d9fc7  vmovaps [rsp+0xF0], xmm12
000074ad747d9fd0  movaps xmm13, xmm1
000074ad747d9fd4  vfmadd231pd xmm13, xmm15, xmm14
000074ad747d9fd9  vcmppd xmm12, xmm13, xmm13, 0x03
000074ad747d9fdf  vptest xmm12, xmm12
000074ad747d9fe4  jnz 0x000074AD747DACA7
000074ad747d9fea  vmovaps xmm1, [rsp+0x80]
000074ad747d9ff3  vpermilpd xmm1, xmm1, 0x00
000074ad747d9ff9  vmovaps xmm15, [rsp+0xA0]
000074ad747da002  movaps xmm14, xmm15
000074ad747da006  vfmadd231pd xmm14, xmm2, xmm1
000074ad747da00b  vcmppd xmm12, xmm14, xmm14, 0x03
000074ad747da011  vptest xmm12, xmm12
000074ad747da016  jnz 0x000074AD747DAE00
000074ad747da01c  vmovaps xmm1, [rsp+0x80]
000074ad747da025  vpermilpd xmm1, xmm1, 0x00
000074ad747da02b  vmovaps xmm15, [rsp+0x120]
000074ad747da034  vmovaps xmm12, [rsp+0x50]
000074ad747da03a  vmovaps [rsp+0x50], xmm14
000074ad747da040  movaps xmm2, xmm15
000074ad747da044  vfmadd231pd xmm2, xmm12, xmm1
000074ad747da049  vcmppd xmm14, xmm2, xmm2, 0x03
000074ad747da04e  vptest xmm14, xmm14
000074ad747da053  jnz 0x000074AD747DAF58
000074ad747da059  vmovaps xmm1, [rsp+0x110]
000074ad747da062  vmovaps xmm15, [rsp+0x110]
000074ad747da06b  por xmm1, xmm15
000074ad747da070  movaps [r15+0x1D0], xmm1
000074ad747da078  vmovaps xmm15, [rsp+0x80]
000074ad747da081  vpermilpd xmm15, xmm15, 0x00
000074ad747da087  vmovaps xmm14, [rsp+0xF0]
000074ad747da090  vmovaps [rsp+0x80], xmm1
000074ad747da099  movaps xmm12, xmm14
000074ad747da09d  vfmadd231pd xmm12, xmm3, xmm15
000074ad747da0a2  vcmppd xmm1, xmm12, xmm12, 0x03
000074ad747da0a8  vptest xmm1, xmm1
000074ad747da0ad  jnz 0x000074AD747DB0AF
000074ad747da0b3  vmovaps [rsp+0xA0], xmm4
000074ad747da0bc  vmovaps xmm1, [rsp+0xA0]
000074ad747da0c5  por xmm4, xmm1
000074ad747da0c9  movaps [r15+0x200], xmm4
000074ad747da0d1  vmovaps xmm1, [rsp+0xE0]
000074ad747da0da  vmovaps xmm15, [rsp+0xE0]
000074ad747da0e3  por xmm1, xmm15
000074ad747da0e8  movaps [r15+0x1E0], xmm1
000074ad747da0f0  vmovaps [rsp+0xA0], xmm8
000074ad747da0f9  vmovaps xmm1, [rsp+0xA0]
000074ad747da102  por xmm8, xmm1
000074ad747da107  movaps [r15+0x2B0], xmm8
000074ad747da10f  vmovaps [rsp+0xA0], xmm9
000074ad747da118  vmovaps xmm1, [rsp+0xA0]
000074ad747da121  por xmm9, xmm1
000074ad747da126  movaps [r15+0x300], xmm9
000074ad747da12e  vmovaps [rsp+0xA0], xmm6
000074ad747da137  vpermilpd xmm6, xmm6, 0x00
000074ad747da13d  vmovaps xmm14, [rsp+0x60]
000074ad747da143  movaps xmm9, xmm13
000074ad747da147  vfmadd231pd xmm9, xmm14, xmm6
000074ad747da14c  vcmppd xmm3, xmm9, xmm9, 0x03
000074ad747da152  vptest xmm3, xmm3
000074ad747da157  jnz 0x000074AD747DB208
000074ad747da15d  vmovaps xmm14, [rsp+0xA0]
000074ad747da166  vpermilpd xmm14, xmm14, 0x00
000074ad747da16c  vmovaps xmm13, [rsp+0x50]
000074ad747da172  vmovaps xmm6, [rsp+0xC0]
000074ad747da17b  vmovaps [rsp+0x50], xmm1
000074ad747da181  movaps xmm3, xmm13
000074ad747da185  vfmadd231pd xmm3, xmm6, xmm14
000074ad747da18a  vcmppd xmm1, xmm3, xmm3, 0x03
000074ad747da18f  vptest xmm1, xmm1
000074ad747da194  jnz 0x000074AD747DB361
000074ad747da19a  vmovaps xmm1, [rsp+0xA0]
000074ad747da1a3  vpermilpd xmm1, xmm1, 0x00
000074ad747da1a9  vmovaps xmm14, [rsp+0x30]
000074ad747da1af  movaps xmm6, xmm2
000074ad747da1b2  vfmadd231pd xmm6, xmm14, xmm1
000074ad747da1b7  vcmppd xmm13, xmm6, xmm6, 0x03
000074ad747da1bc  vptest xmm13, xmm13
000074ad747da1c1  jnz 0x000074AD747DB4B8
000074ad747da1c7  vmovaps xmm1, [rsp+0xA0]
000074ad747da1d0  vpermilpd xmm1, xmm1, 0x00
000074ad747da1d6  vmovaps xmm14, [rsp+0x80]
000074ad747da1df  movaps xmm13, xmm12
000074ad747da1e3  vfmadd231pd xmm13, xmm14, xmm1
000074ad747da1e8  vcmppd xmm2, xmm13, xmm13, 0x03
000074ad747da1ee  vptest xmm2, xmm2
000074ad747da1f3  jnz 0x000074AD747DB60E
000074ad747da1f9  vmovaps [rsp+0x30], xmm7
000074ad747da1ff  vmovaps xmm1, [rsp+0x30]
000074ad747da205  por xmm7, xmm1
000074ad747da209  movaps [r15+0x180], xmm7
000074ad747da211  vmovaps [rsp+0x30], xmm10
000074ad747da217  vmovaps xmm1, [rsp+0x30]
000074ad747da21d  por xmm10, xmm1
000074ad747da222  movaps [r15+0x2D0], xmm10
000074ad747da22a  vmovaps [rsp+0x30], xmm5
000074ad747da230  vpermilpd xmm5, xmm5, 0x00
000074ad747da236  vmovaps xmm14, [rsp+0x50]
000074ad747da23c  movaps xmm12, xmm3
000074ad747da240  vfmadd231pd xmm12, xmm14, xmm5
000074ad747da245  vcmppd xmm10, xmm12, xmm12, 0x03
000074ad747da24b  vptest xmm10, xmm10
000074ad747da250  jnz 0x000074AD747DB767
000074ad747da256  vmovaps xmm14, [rsp+0x30]
000074ad747da25c  vpermilpd xmm14, xmm14, 0x00
000074ad747da262  movaps xmm10, xmm9
000074ad747da266  vfmadd231pd xmm10, xmm7, xmm14
000074ad747da26b  vcmppd xmm5, xmm10, xmm10, 0x03
000074ad747da271  vptest xmm5, xmm5
000074ad747da276  jnz 0x000074AD747DB8BF
000074ad747da27c  lea rax, [r14+0x80]
000074ad747da283  movups xmm14, [r13+rax*1]
000074ad747da289  movaps [r15+0x2F0], xmm14
000074ad747da291  vmovaps xmm9, [rsp+0x30]
000074ad747da297  vpermilpd xmm9, xmm9, 0x00
000074ad747da29d  vmovaps xmm7, [rsp+0x70]
000074ad747da2a3  movaps xmm5, xmm6
000074ad747da2a6  vfmadd231pd xmm5, xmm7, xmm9
000074ad747da2ab  vcmppd xmm3, xmm5, xmm5, 0x03
000074ad747da2b0  vptest xmm3, xmm3
000074ad747da2b5  jnz 0x000074AD747DBA22
000074ad747da2bb  vmovaps xmm9, [rsp+0x30]
000074ad747da2c1  vpermilpd xmm9, xmm9, 0x00
000074ad747da2c7  movaps xmm7, xmm13
000074ad747da2cb  vfmadd231pd xmm7, xmm1, xmm9
000074ad747da2d0  vcmppd xmm6, xmm7, xmm7, 0x03
000074ad747da2d5  vptest xmm6, xmm6
000074ad747da2da  jnz 0x000074AD747DBB78
000074ad747da2e0  vmovaps xmm1, [rsp+0x20]
000074ad747da2e6  vmovaps xmm13, [rsp+0x20]
000074ad747da2ec  por xmm1, xmm13
000074ad747da2f1  movaps [r15+0x160], xmm1
000074ad747da2f9  lea rax, [r14+0x40]
000074ad747da2fd  movups xmm13, [r13+rax*1]
000074ad747da303  lea rax, [r14+0x50]
000074ad747da307  movups xmm9, [r13+rax*1]
000074ad747da30d  movaps [r15+0x1B0], xmm13
000074ad747da315  movaps [r15+0x1A0], xmm9
000074ad747da31d  movaps xmm6, [r15+0x190]
000074ad747da325  vmovaps xmm3, [rsp+0xB0]
000074ad747da32e  vpermilpd xmm3, xmm3, 0x00
000074ad747da334  vmovaps [rsp+0x20], xmm1
000074ad747da33a  movaps xmm2, xmm12
000074ad747da33e  vfmadd231pd xmm2, xmm6, xmm3
000074ad747da343  vcmppd xmm1, xmm2, xmm2, 0x03
000074ad747da348  vptest xmm1, xmm1
000074ad747da34d  jnz 0x000074AD747DBCE3
000074ad747da353  vmovaps xmm1, [rsp+0xB0]
000074ad747da35c  vpermilpd xmm1, xmm1, 0x00
000074ad747da362  vmovaps xmm12, [rsp+0x20]
000074ad747da368  movaps xmm6, xmm10
000074ad747da36c  vfmadd231pd xmm6, xmm12, xmm1
000074ad747da371  vcmppd xmm3, xmm6, xmm6, 0x03
000074ad747da376  vptest xmm3, xmm3
000074ad747da37b  jnz 0x000074AD747DBE39
000074ad747da381  vmovaps xmm1, [rsp+0xB0]
000074ad747da38a  vpermilpd xmm1, xmm1, 0x00
000074ad747da390  vmovaps xmm12, [rsp+0x40]
000074ad747da396  movaps xmm10, xmm5
000074ad747da39a  vfmadd231pd xmm10, xmm12, xmm1
000074ad747da39f  vcmppd xmm3, xmm10, xmm10, 0x03
000074ad747da3a5  vptest xmm3, xmm3
000074ad747da3aa  jnz 0x000074AD747DBF90
000074ad747da3b0  vmovaps xmm1, [rsp+0xB0]
000074ad747da3b9  vpermilpd xmm1, xmm1, 0x00
000074ad747da3bf  movaps xmm12, xmm7
000074ad747da3c3  vfmadd231pd xmm12, xmm15, xmm1
000074ad747da3c8  vcmppd xmm5, xmm12, xmm12, 0x03
000074ad747da3ce  vptest xmm5, xmm5
000074ad747da3d3  jnz 0x000074AD747DC0E8
000074ad747da3d9  lea rax, [r14+0x60]
000074ad747da3dd  movups xmm1, [r13+rax*1]
000074ad747da3e3  lea rax, [r14+0x70]
000074ad747da3e7  movups xmm15, [r13+rax*1]
000074ad747da3ed  movaps [r15+0x150], xmm1
000074ad747da3f5  movaps [r15+0x120], xmm15
000074ad747da3fd  vmovaps [rsp+0x20], xmm11
000074ad747da403  vpermilpd xmm11, xmm11, 0x00
000074ad747da409  movaps xmm7, xmm2
000074ad747da40c  vfmadd231pd xmm7, xmm9, xmm11
000074ad747da411  vcmppd xmm5, xmm7, xmm7, 0x03
000074ad747da416  vptest xmm5, xmm5
000074ad747da41b  jnz 0x000074AD747DC254
000074ad747da421  vmovaps xmm11, [rsp+0x20]
000074ad747da427  vpermilpd xmm11, xmm11, 0x00
000074ad747da42d  movaps xmm9, xmm6
000074ad747da431  vfmadd231pd xmm9, xmm1, xmm11
000074ad747da436  vcmppd xmm5, xmm9, xmm9, 0x03
000074ad747da43c  vptest xmm5, xmm5
000074ad747da441  jnz 0x000074AD747DC3AB
000074ad747da447  vmovaps xmm1, [rsp+0x20]
000074ad747da44d  vpermilpd xmm1, xmm1, 0x00
000074ad747da453  movaps xmm11, xmm10
000074ad747da457  vfmadd231pd xmm11, xmm8, xmm1
000074ad747da45c  vcmppd xmm6, xmm11, xmm11, 0x03
000074ad747da462  vptest xmm6, xmm6
000074ad747da467  jnz 0x000074AD747DC503
000074ad747da46d  vmovaps xmm1, [rsp+0x20]
000074ad747da473  vpermilpd xmm1, xmm1, 0x00
000074ad747da479  movaps xmm10, xmm12
000074ad747da47d  vfmadd231pd xmm10, xmm13, xmm1
000074ad747da482  vcmppd xmm8, xmm10, xmm10, 0x03
000074ad747da488  vptest xmm8, xmm8
000074ad747da48d  jnz 0x000074AD747DC65C
000074ad747da493  lea rax, [r14+0x20]
000074ad747da497  movups xmm1, [r13+rax*1]
000074ad747da49d  lea rax, [r14+0x30]
000074ad747da4a1  movups xmm13, [r13+rax*1]
000074ad747da4a7  vmovaps xmm12, [rsp+0x90]
000074ad747da4b0  vpermilpd xmm12, xmm12, 0x00
000074ad747da4b6  movaps xmm8, xmm7
000074ad747da4ba  vfmadd231pd xmm8, xmm4, xmm12
000074ad747da4bf  vcmppd xmm6, xmm8, xmm8, 0x03
000074ad747da4c5  vptest xmm6, xmm6
000074ad747da4ca  jnz 0x000074AD747DC7C9
000074ad747da4d0  vmovaps xmm12, [rsp+0x90]
000074ad747da4d9  vpermilpd xmm12, xmm12, 0x00
000074ad747da4df  movaps xmm7, xmm9
000074ad747da4e3  vfmadd231pd xmm7, xmm14, xmm12
000074ad747da4e8  vcmppd xmm6, xmm7, xmm7, 0x03
000074ad747da4ed  vptest xmm6, xmm6
000074ad747da4f2  jnz 0x000074AD747DC921
000074ad747da4f8  vmovaps xmm14, [rsp+0x90]
000074ad747da501  vpermilpd xmm14, xmm14, 0x00
000074ad747da507  movaps xmm12, xmm11
000074ad747da50b  vfmadd231pd xmm12, xmm15, xmm14
000074ad747da510  vcmppd xmm9, xmm12, xmm12, 0x03
000074ad747da516  vptest xmm9, xmm9
000074ad747da51b  jnz 0x000074AD747DCA79
000074ad747da521  vmovaps xmm15, [rsp+0x90]
000074ad747da52a  vpermilpd xmm15, xmm15, 0x00
000074ad747da530  movaps xmm11, xmm10
000074ad747da534  vfmadd231pd xmm11, xmm13, xmm15
000074ad747da539  vcmppd xmm14, xmm11, xmm11, 0x03
000074ad747da53f  vptest xmm14, xmm14
000074ad747da544  jnz 0x000074AD747DCBD3
000074ad747da54a  lea rax, [r14+0x90]
000074ad747da551  movups xmm15, [r13+rax*1]
000074ad747da557  lea rax, [r14+0xA0]
000074ad747da55e  movups xmm14, [r13+rax*1]
000074ad747da564  movaps [r15+0x140], xmm15
000074ad747da56c  movaps [r15+0x130], xmm14
000074ad747da574  vmovaps xmm13, [rsp+0x10]
000074ad747da57a  vpermilpd xmm13, xmm13, 0x00
000074ad747da580  movaps xmm10, xmm8
000074ad747da584  vfmadd231pd xmm10, xmm1, xmm13
000074ad747da589  vcmppd xmm9, xmm10, xmm10, 0x03
000074ad747da58f  vptest xmm9, xmm9
000074ad747da594  jnz 0x000074AD747DCD41
000074ad747da59a  movaps [r15+0x220], xmm10
000074ad747da5a2  lea rax, [r14+0x10]
000074ad747da5a6  movups xmm1, [r13+rax*1]
000074ad747da5ac  movaps [r15+0x240], xmm1
000074ad747da5b4  vmovaps xmm13, [rsp+0x10]
000074ad747da5ba  vpermilpd xmm13, xmm13, 0x00
000074ad747da5c0  movaps xmm9, xmm7
000074ad747da5c4  vfmadd231pd xmm9, xmm14, xmm13
000074ad747da5c9  vcmppd xmm8, xmm9, xmm9, 0x03
000074ad747da5cf  vptest xmm8, xmm8
000074ad747da5d4  jnz 0x000074AD747DCEA4
000074ad747da5da  movaps [r15+0x110], xmm9
000074ad747da5e2  vmovaps xmm14, [rsp+0x10]
000074ad747da5e8  vpermilpd xmm14, xmm14, 0x00
000074ad747da5ee  movaps xmm13, xmm12
000074ad747da5f2  vfmadd231pd xmm13, xmm15, xmm14
000074ad747da5f7  vcmppd xmm8, xmm13, xmm13, 0x03
000074ad747da5fd  vptest xmm8, xmm8
000074ad747da602  jnz 0x000074AD747DCFFD
000074ad747da608  movaps [r15+0x170], xmm13
000074ad747da610  vmovaps xmm15, [rsp+0x10]
000074ad747da616  vpermilpd xmm15, xmm15, 0x00
000074ad747da61c  movaps xmm14, xmm11
000074ad747da620  vfmadd231pd xmm14, xmm1, xmm15
000074ad747da625  vcmppd xmm12, xmm14, xmm14, 0x03
000074ad747da62b  vptest xmm12, xmm12
000074ad747da630  jnz 0x000074AD747DD157
000074ad747da636  movaps [r15+0x230], xmm14
000074ad747da63e  mov rax, [rsp+0xD0]
000074ad747da646  movups [r13+rax*1], xmm9
000074ad747da64c  lea r14, [rax+0x10]
000074ad747da650  movups [r13+r14*1], xmm13
000074ad747da656  lea r14, [rax+0x20]
000074ad747da65a  movups [r13+r14*1], xmm10
000074ad747da660  lea r14, [rax+0x30]
000074ad747da664  movups [r13+r14*1], xmm14
000074ad747da66a  mov eax, [r15+0x108]
000074ad747da671  sahf
000074ad747da672  jnz 0x000074AD747DA6A4
000074ad747da674  cmp dword ptr [r15+0x318], 0x00
000074ad747da67c  jz 0x000074AD747D9950
000074ad747da682  nop [rax+rax*1], ax
000074ad747da68b  nop [rax+rax*1], eax
000074ad747da693  mov eax, 0x410664
000074ad747da698  mov [r15+0x100], rax
000074ad747da69f  jmp 0x000074AD745FE110
000074ad747da6a4  cmp dword ptr [r15+0x318], 0x00
000074ad747da6ac  jz 0x000074AD747D6050
000074ad747da6b2  nop [rax+rax*1], ax
000074ad747da6bb  nop [rax+rax*1], eax
000074ad747da6c3  mov eax, 0x4104F0
000074ad747da6c8  mov [r15+0x100], rax
000074ad747da6cf  jmp 0x000074AD745FE110
000074ad747da6d4  int3
000074ad747da6d5  call 0x000074AD746E27E0
000074ad747da6da  jmp 0x000074AD747D9A10
000074ad747da6df  call 0x000074AD746E1570
000074ad747da6e4  jmp 0x000074AD747D9A19
000074ad747da6e9  call 0x000074AD746E27E0
000074ad747da6ee  jmp 0x000074AD747D9A62
000074ad747da6f3  call 0x000074AD746E1570
000074ad747da6f8  jmp 0x000074AD747D9A6B
000074ad747da6fd  call 0x000074AD746E27E0
000074ad747da702  jmp 0x000074AD747D9AEB
000074ad747da707  call 0x000074AD746E1570
000074ad747da70c  jmp 0x000074AD747D9AF4
000074ad747da711  call 0x000074AD7460DC20
000074ad747da716  jmp 0x000074AD747D9BD5
000074ad747da71b  call 0x000074AD746D64F0
000074ad747da720  jmp 0x000074AD747D9C04
000074ad747da725  call 0x000074AD746B47C0
000074ad747da72a  jmp 0x000074AD747D9C1F
000074ad747da72f  sub rsp, 0x08
000074ad747da733  push rax
000074ad747da734  push rcx
000074ad747da735  push rdx
000074ad747da736  push rdi
000074ad747da737  push rsi
000074ad747da738  push r8
000074ad747da73a  push r9
000074ad747da73c  push r10
000074ad747da73e  push r11
000074ad747da740  sub rsp, 0xF0
000074ad747da747  vmovaps [rsp], xmm0
000074ad747da74c  vmovaps [rsp+0x10], xmm1
000074ad747da752  vmovaps [rsp+0x20], xmm2
000074ad747da758  vmovaps [rsp+0x30], xmm3
000074ad747da75e  vmovaps [rsp+0x40], xmm4
000074ad747da764  vmovaps [rsp+0x50], xmm5
000074ad747da76a  vmovaps [rsp+0x60], xmm6
000074ad747da770  vmovaps [rsp+0x70], xmm7
000074ad747da776  vmovaps [rsp+0x80], xmm8
000074ad747da77f  vmovaps [rsp+0x90], xmm9
000074ad747da788  vmovaps [rsp+0xA0], xmm10
000074ad747da791  vmovaps [rsp+0xB0], xmm11
000074ad747da79a  vmovaps [rsp+0xC0], xmm12
000074ad747da7a3  vmovaps [rsp+0xD0], xmm14
000074ad747da7ac  vmovaps [rsp+0xE0], xmm15
000074ad747da7b5  sub rsp, 0x40
000074ad747da7b9  lea rdi, [rsp]
000074ad747da7bd  lea rsi, [rsp+0x10]
000074ad747da7c2  lea rdx, [rsp+0x20]
000074ad747da7c7  lea rcx, [rsp+0x30]
000074ad747da7cc  mov r8d, 0x00
000074ad747da7d2  lea r9, [r15+0x3A8]
000074ad747da7d9  movaps [rdi], xmm13
000074ad747da7dd  movaps [rsi], xmm1
000074ad747da7e0  movaps [rdx], xmm15
000074ad747da7e4  movaps [rcx], xmm14
000074ad747da7e8  mov rax, 0x5C17501CEA50
000074ad747da7f2  call rax
000074ad747da7f4  movaps xmm13, [rsp]
000074ad747da7f9  add rsp, 0x40
000074ad747da7fd  vmovaps xmm0, [rsp]
000074ad747da802  vmovaps xmm1, [rsp+0x10]
000074ad747da808  vmovaps xmm2, [rsp+0x20]
000074ad747da80e  vmovaps xmm3, [rsp+0x30]
000074ad747da814  vmovaps xmm4, [rsp+0x40]
000074ad747da81a  vmovaps xmm5, [rsp+0x50]
000074ad747da820  vmovaps xmm6, [rsp+0x60]
000074ad747da826  vmovaps xmm7, [rsp+0x70]
000074ad747da82c  vmovaps xmm8, [rsp+0x80]
000074ad747da835  vmovaps xmm9, [rsp+0x90]
000074ad747da83e  vmovaps xmm10, [rsp+0xA0]
000074ad747da847  vmovaps xmm11, [rsp+0xB0]
000074ad747da850  vmovaps xmm12, [rsp+0xC0]
000074ad747da859  vmovaps xmm14, [rsp+0xD0]
000074ad747da862  vmovaps xmm15, [rsp+0xE0]
000074ad747da86b  add rsp, 0xF0
000074ad747da872  pop r11
000074ad747da874  pop r10
000074ad747da876  pop r9
000074ad747da878  pop r8
000074ad747da87a  pop rsi
000074ad747da87b  pop rdi
000074ad747da87c  pop rdx
000074ad747da87d  pop rcx
000074ad747da87e  pop rax
000074ad747da87f  add rsp, 0x08
000074ad747da883  jmp 0x000074AD747D9C92
000074ad747da888  sub rsp, 0x08
000074ad747da88c  push rax
000074ad747da88d  push rcx
000074ad747da88e  push rdx
000074ad747da88f  push rdi
000074ad747da890  push rsi
000074ad747da891  push r8
000074ad747da893  push r9
000074ad747da895  push r10
000074ad747da897  push r11
000074ad747da899  sub rsp, 0xF0
000074ad747da8a0  vmovaps [rsp], xmm0
000074ad747da8a5  vmovaps [rsp+0x10], xmm1
000074ad747da8ab  vmovaps [rsp+0x20], xmm2
000074ad747da8b1  vmovaps [rsp+0x30], xmm3
000074ad747da8b7  vmovaps [rsp+0x40], xmm4
000074ad747da8bd  vmovaps [rsp+0x50], xmm5
000074ad747da8c3  vmovaps [rsp+0x60], xmm6
000074ad747da8c9  vmovaps [rsp+0x70], xmm7
000074ad747da8cf  vmovaps [rsp+0x80], xmm8
000074ad747da8d8  vmovaps [rsp+0x90], xmm9
000074ad747da8e1  vmovaps [rsp+0xA0], xmm10
000074ad747da8ea  vmovaps [rsp+0xB0], xmm11
000074ad747da8f3  vmovaps [rsp+0xC0], xmm13
000074ad747da8fc  vmovaps [rsp+0xD0], xmm14
000074ad747da905  vmovaps [rsp+0xE0], xmm15
000074ad747da90e  sub rsp, 0x40
000074ad747da912  lea rdi, [rsp]
000074ad747da916  lea rsi, [rsp+0x10]
000074ad747da91b  lea rdx, [rsp+0x20]
000074ad747da920  lea rcx, [rsp+0x30]
000074ad747da925  mov r8d, 0x00
000074ad747da92b  lea r9, [r15+0x3A8]
000074ad747da932  movaps [rdi], xmm12
000074ad747da936  movaps [rsi], xmm15
000074ad747da93a  movaps [rdx], xmm1
000074ad747da93d  movaps [rcx], xmm14
000074ad747da941  mov rax, 0x5C17501CEA50
000074ad747da94b  call rax
000074ad747da94d  movaps xmm12, [rsp]
000074ad747da952  add rsp, 0x40
000074ad747da956  vmovaps xmm0, [rsp]
000074ad747da95b  vmovaps xmm1, [rsp+0x10]
000074ad747da961  vmovaps xmm2, [rsp+0x20]
000074ad747da967  vmovaps xmm3, [rsp+0x30]
000074ad747da96d  vmovaps xmm4, [rsp+0x40]
000074ad747da973  vmovaps xmm5, [rsp+0x50]
000074ad747da979  vmovaps xmm6, [rsp+0x60]
000074ad747da97f  vmovaps xmm7, [rsp+0x70]
000074ad747da985  vmovaps xmm8, [rsp+0x80]
000074ad747da98e  vmovaps xmm9, [rsp+0x90]
000074ad747da997  vmovaps xmm10, [rsp+0xA0]
000074ad747da9a0  vmovaps xmm11, [rsp+0xB0]
000074ad747da9a9  vmovaps xmm13, [rsp+0xC0]
000074ad747da9b2  vmovaps xmm14, [rsp+0xD0]
000074ad747da9bb  vmovaps xmm15, [rsp+0xE0]
000074ad747da9c4  add rsp, 0xF0
000074ad747da9cb  pop r11
000074ad747da9cd  pop r10
000074ad747da9cf  pop r9
000074ad747da9d1  pop r8
000074ad747da9d3  pop rsi
000074ad747da9d4  pop rdi
000074ad747da9d5  pop rdx
000074ad747da9d6  pop rcx
000074ad747da9d7  pop rax
000074ad747da9d8  add rsp, 0x08
000074ad747da9dc  jmp 0x000074AD747D9CC0
000074ad747da9e1  call 0x000074AD746B52F0
000074ad747da9e6  jmp 0x000074AD747D9DAC
000074ad747da9eb  sub rsp, 0x08
000074ad747da9ef  push rax
000074ad747da9f0  push rcx
000074ad747da9f1  push rdx
000074ad747da9f2  push rdi
000074ad747da9f3  push rsi
000074ad747da9f4  push r8
000074ad747da9f6  push r9
000074ad747da9f8  push r10
000074ad747da9fa  push r11
000074ad747da9fc  sub rsp, 0xF0
000074ad747daa03  vmovaps [rsp], xmm0
000074ad747daa08  vmovaps [rsp+0x10], xmm1
000074ad747daa0e  vmovaps [rsp+0x20], xmm2
000074ad747daa14  vmovaps [rsp+0x30], xmm3
000074ad747daa1a  vmovaps [rsp+0x40], xmm4
000074ad747daa20  vmovaps [rsp+0x50], xmm5
000074ad747daa26  vmovaps [rsp+0x60], xmm6
000074ad747daa2c  vmovaps [rsp+0x70], xmm7
000074ad747daa32  vmovaps [rsp+0x80], xmm8
000074ad747daa3b  vmovaps [rsp+0x90], xmm9
000074ad747daa44  vmovaps [rsp+0xA0], xmm10
000074ad747daa4d  vmovaps [rsp+0xB0], xmm11
000074ad747daa56  vmovaps [rsp+0xC0], xmm12
000074ad747daa5f  vmovaps [rsp+0xD0], xmm14
000074ad747daa68  vmovaps [rsp+0xE0], xmm15
000074ad747daa71  sub rsp, 0x40
000074ad747daa75  lea rdi, [rsp]
000074ad747daa79  lea rsi, [rsp+0x10]
000074ad747daa7e  lea rdx, [rsp+0x20]
000074ad747daa83  lea rcx, [rsp+0x30]
000074ad747daa88  mov r8d, 0x00
000074ad747daa8e  lea r9, [r15+0x3A8]
000074ad747daa95  movaps [rdi], xmm13
000074ad747daa99  movaps [rsi], xmm1
000074ad747daa9c  movaps [rdx], xmm15
000074ad747daaa0  movaps [rcx], xmm14
000074ad747daaa4  mov rax, 0x5C17501CEA50
000074ad747daaae  call rax
000074ad747daab0  movaps xmm13, [rsp]
000074ad747daab5  add rsp, 0x40
000074ad747daab9  vmovaps xmm0, [rsp]
000074ad747daabe  vmovaps xmm1, [rsp+0x10]
000074ad747daac4  vmovaps xmm2, [rsp+0x20]
000074ad747daaca  vmovaps xmm3, [rsp+0x30]
000074ad747daad0  vmovaps xmm4, [rsp+0x40]
000074ad747daad6  vmovaps xmm5, [rsp+0x50]
000074ad747daadc  vmovaps xmm6, [rsp+0x60]
000074ad747daae2  vmovaps xmm7, [rsp+0x70]
000074ad747daae8  vmovaps xmm8, [rsp+0x80]
000074ad747daaf1  vmovaps xmm9, [rsp+0x90]
000074ad747daafa  vmovaps xmm10, [rsp+0xA0]
000074ad747dab03  vmovaps xmm11, [rsp+0xB0]
000074ad747dab0c  vmovaps xmm12, [rsp+0xC0]
000074ad747dab15  vmovaps xmm14, [rsp+0xD0]
000074ad747dab1e  vmovaps xmm15, [rsp+0xE0]
000074ad747dab27  add rsp, 0xF0
000074ad747dab2e  pop r11
000074ad747dab30  pop r10
000074ad747dab32  pop r9
000074ad747dab34  pop r8
000074ad747dab36  pop rsi
000074ad747dab37  pop rdi
000074ad747dab38  pop rdx
000074ad747dab39  pop rcx
000074ad747dab3a  pop rax
000074ad747dab3b  add rsp, 0x08
000074ad747dab3f  jmp 0x000074AD747D9E21
000074ad747dab44  call 0x000074AD745FF430
000074ad747dab49  jmp 0x000074AD747D9E2E
000074ad747dab4e  sub rsp, 0x08
000074ad747dab52  push rax
000074ad747dab53  push rcx
000074ad747dab54  push rdx
000074ad747dab55  push rdi
000074ad747dab56  push rsi
000074ad747dab57  push r8
000074ad747dab59  push r9
000074ad747dab5b  push r10
000074ad747dab5d  push r11
000074ad747dab5f  sub rsp, 0xF0
000074ad747dab66  vmovaps [rsp], xmm0
000074ad747dab6b  vmovaps [rsp+0x10], xmm1
000074ad747dab71  vmovaps [rsp+0x20], xmm2
000074ad747dab77  vmovaps [rsp+0x30], xmm3
000074ad747dab7d  vmovaps [rsp+0x40], xmm4
000074ad747dab83  vmovaps [rsp+0x50], xmm5
000074ad747dab89  vmovaps [rsp+0x60], xmm6
000074ad747dab8f  vmovaps [rsp+0x70], xmm7
000074ad747dab95  vmovaps [rsp+0x80], xmm8
000074ad747dab9e  vmovaps [rsp+0x90], xmm9
000074ad747daba7  vmovaps [rsp+0xA0], xmm10
000074ad747dabb0  vmovaps [rsp+0xB0], xmm11
000074ad747dabb9  vmovaps [rsp+0xC0], xmm13
000074ad747dabc2  vmovaps [rsp+0xD0], xmm14
000074ad747dabcb  vmovaps [rsp+0xE0], xmm15
000074ad747dabd4  sub rsp, 0x40
000074ad747dabd8  lea rdi, [rsp]
000074ad747dabdc  lea rsi, [rsp+0x10]
000074ad747dabe1  lea rdx, [rsp+0x20]
000074ad747dabe6  lea rcx, [rsp+0x30]
000074ad747dabeb  mov r8d, 0x00
000074ad747dabf1  lea r9, [r15+0x3A8]
000074ad747dabf8  movaps [rdi], xmm12
000074ad747dabfc  movaps [rsi], xmm15
000074ad747dac00  movaps [rdx], xmm1
000074ad747dac03  movaps [rcx], xmm14
000074ad747dac07  mov rax, 0x5C17501CEA50
000074ad747dac11  call rax
000074ad747dac13  movaps xmm12, [rsp]
000074ad747dac18  add rsp, 0x40
000074ad747dac1c  vmovaps xmm0, [rsp]
000074ad747dac21  vmovaps xmm1, [rsp+0x10]
000074ad747dac27  vmovaps xmm2, [rsp+0x20]
000074ad747dac2d  vmovaps xmm3, [rsp+0x30]
000074ad747dac33  vmovaps xmm4, [rsp+0x40]
000074ad747dac39  vmovaps xmm5, [rsp+0x50]
000074ad747dac3f  vmovaps xmm6, [rsp+0x60]
000074ad747dac45  vmovaps xmm7, [rsp+0x70]
000074ad747dac4b  vmovaps xmm8, [rsp+0x80]
000074ad747dac54  vmovaps xmm9, [rsp+0x90]
000074ad747dac5d  vmovaps xmm10, [rsp+0xA0]
000074ad747dac66  vmovaps xmm11, [rsp+0xB0]
000074ad747dac6f  vmovaps xmm13, [rsp+0xC0]
000074ad747dac78  vmovaps xmm14, [rsp+0xD0]
000074ad747dac81  vmovaps xmm15, [rsp+0xE0]
000074ad747dac8a  add rsp, 0xF0
000074ad747dac91  pop r11
000074ad747dac93  pop r10
000074ad747dac95  pop r9
000074ad747dac97  pop r8
000074ad747dac99  pop rsi
000074ad747dac9a  pop rdi
000074ad747dac9b  pop rdx
000074ad747dac9c  pop rcx
000074ad747dac9d  pop rax
000074ad747dac9e  add rsp, 0x08
000074ad747daca2  jmp 0x000074AD747D9E5A
000074ad747daca7  sub rsp, 0x08
000074ad747dacab  push rax
000074ad747dacac  push rcx
000074ad747dacad  push rdx
000074ad747dacae  push rdi
000074ad747dacaf  push rsi
000074ad747dacb0  push r8
000074ad747dacb2  push r9
000074ad747dacb4  push r10
000074ad747dacb6  push r11
000074ad747dacb8  sub rsp, 0xF0
000074ad747dacbf  vmovaps [rsp], xmm0
000074ad747dacc4  vmovaps [rsp+0x10], xmm1
000074ad747dacca  vmovaps [rsp+0x20], xmm2
000074ad747dacd0  vmovaps [rsp+0x30], xmm3
000074ad747dacd6  vmovaps [rsp+0x40], xmm4
000074ad747dacdc  vmovaps [rsp+0x50], xmm5
000074ad747dace2  vmovaps [rsp+0x60], xmm6
000074ad747dace8  vmovaps [rsp+0x70], xmm7
000074ad747dacee  vmovaps [rsp+0x80], xmm8
000074ad747dacf7  vmovaps [rsp+0x90], xmm9
000074ad747dad00  vmovaps [rsp+0xA0], xmm10
000074ad747dad09  vmovaps [rsp+0xB0], xmm11
000074ad747dad12  vmovaps [rsp+0xC0], xmm12
000074ad747dad1b  vmovaps [rsp+0xD0], xmm14
000074ad747dad24  vmovaps [rsp+0xE0], xmm15
000074ad747dad2d  sub rsp, 0x40
000074ad747dad31  lea rdi, [rsp]
000074ad747dad35  lea rsi, [rsp+0x10]
000074ad747dad3a  lea rdx, [rsp+0x20]
000074ad747dad3f  lea rcx, [rsp+0x30]
000074ad747dad44  mov r8d, 0x00
000074ad747dad4a  lea r9, [r15+0x3A8]
000074ad747dad51  movaps [rdi], xmm13
000074ad747dad55  movaps [rsi], xmm1
000074ad747dad58  movaps [rdx], xmm15
000074ad747dad5c  movaps [rcx], xmm14
000074ad747dad60  mov rax, 0x5C17501CEA50
000074ad747dad6a  call rax
000074ad747dad6c  movaps xmm13, [rsp]
000074ad747dad71  add rsp, 0x40
000074ad747dad75  vmovaps xmm0, [rsp]
000074ad747dad7a  vmovaps xmm1, [rsp+0x10]
000074ad747dad80  vmovaps xmm2, [rsp+0x20]
000074ad747dad86  vmovaps xmm3, [rsp+0x30]
000074ad747dad8c  vmovaps xmm4, [rsp+0x40]
000074ad747dad92  vmovaps xmm5, [rsp+0x50]
000074ad747dad98  vmovaps xmm6, [rsp+0x60]
000074ad747dad9e  vmovaps xmm7, [rsp+0x70]
000074ad747dada4  vmovaps xmm8, [rsp+0x80]
000074ad747dadad  vmovaps xmm9, [rsp+0x90]
000074ad747dadb6  vmovaps xmm10, [rsp+0xA0]
000074ad747dadbf  vmovaps xmm11, [rsp+0xB0]
000074ad747dadc8  vmovaps xmm12, [rsp+0xC0]
000074ad747dadd1  vmovaps xmm14, [rsp+0xD0]
000074ad747dadda  vmovaps xmm15, [rsp+0xE0]
000074ad747dade3  add rsp, 0xF0
000074ad747dadea  pop r11
000074ad747dadec  pop r10
000074ad747dadee  pop r9
000074ad747dadf0  pop r8
000074ad747dadf2  pop rsi
000074ad747dadf3  pop rdi
000074ad747dadf4  pop rdx
000074ad747dadf5  pop rcx
000074ad747dadf6  pop rax
000074ad747dadf7  add rsp, 0x08
000074ad747dadfb  jmp 0x000074AD747D9FEA
000074ad747dae00  sub rsp, 0x08
000074ad747dae04  push rax
000074ad747dae05  push rcx
000074ad747dae06  push rdx
000074ad747dae07  push rdi
000074ad747dae08  push rsi
000074ad747dae09  push r8
000074ad747dae0b  push r9
000074ad747dae0d  push r10
000074ad747dae0f  push r11
000074ad747dae11  sub rsp, 0xF0
000074ad747dae18  vmovaps [rsp], xmm0
000074ad747dae1d  vmovaps [rsp+0x10], xmm1
000074ad747dae23  vmovaps [rsp+0x20], xmm2
000074ad747dae29  vmovaps [rsp+0x30], xmm3
000074ad747dae2f  vmovaps [rsp+0x40], xmm4
000074ad747dae35  vmovaps [rsp+0x50], xmm5
000074ad747dae3b  vmovaps [rsp+0x60], xmm6
000074ad747dae41  vmovaps [rsp+0x70], xmm7
000074ad747dae47  vmovaps [rsp+0x80], xmm8
000074ad747dae50  vmovaps [rsp+0x90], xmm9
000074ad747dae59  vmovaps [rsp+0xA0], xmm10
000074ad747dae62  vmovaps [rsp+0xB0], xmm11
000074ad747dae6b  vmovaps [rsp+0xC0], xmm12
000074ad747dae74  vmovaps [rsp+0xD0], xmm13
000074ad747dae7d  vmovaps [rsp+0xE0], xmm15
000074ad747dae86  sub rsp, 0x40
000074ad747dae8a  lea rdi, [rsp]
000074ad747dae8e  lea rsi, [rsp+0x10]
000074ad747dae93  lea rdx, [rsp+0x20]
000074ad747dae98  lea rcx, [rsp+0x30]
000074ad747dae9d  mov r8d, 0x00
000074ad747daea3  lea r9, [r15+0x3A8]
000074ad747daeaa  movaps [rdi], xmm14
000074ad747daeae  movaps [rsi], xmm15
000074ad747daeb2  movaps [rdx], xmm2
000074ad747daeb5  movaps [rcx], xmm1
000074ad747daeb8  mov rax, 0x5C17501CEA50
000074ad747daec2  call rax
000074ad747daec4  movaps xmm14, [rsp]
000074ad747daec9  add rsp, 0x40
000074ad747daecd  vmovaps xmm0, [rsp]
000074ad747daed2  vmovaps xmm1, [rsp+0x10]
000074ad747daed8  vmovaps xmm2, [rsp+0x20]
000074ad747daede  vmovaps xmm3, [rsp+0x30]
000074ad747daee4  vmovaps xmm4, [rsp+0x40]
000074ad747daeea  vmovaps xmm5, [rsp+0x50]
000074ad747daef0  vmovaps xmm6, [rsp+0x60]
000074ad747daef6  vmovaps xmm7, [rsp+0x70]
000074ad747daefc  vmovaps xmm8, [rsp+0x80]
000074ad747daf05  vmovaps xmm9, [rsp+0x90]
000074ad747daf0e  vmovaps xmm10, [rsp+0xA0]
000074ad747daf17  vmovaps xmm11, [rsp+0xB0]
000074ad747daf20  vmovaps xmm12, [rsp+0xC0]
000074ad747daf29  vmovaps xmm13, [rsp+0xD0]
000074ad747daf32  vmovaps xmm15, [rsp+0xE0]
000074ad747daf3b  add rsp, 0xF0
000074ad747daf42  pop r11
000074ad747daf44  pop r10
000074ad747daf46  pop r9
000074ad747daf48  pop r8
000074ad747daf4a  pop rsi
000074ad747daf4b  pop rdi
000074ad747daf4c  pop rdx
000074ad747daf4d  pop rcx
000074ad747daf4e  pop rax
000074ad747daf4f  add rsp, 0x08
000074ad747daf53  jmp 0x000074AD747DA01C
000074ad747daf58  sub rsp, 0x08
000074ad747daf5c  push rax
000074ad747daf5d  push rcx
000074ad747daf5e  push rdx
000074ad747daf5f  push rdi
000074ad747daf60  push rsi
000074ad747daf61  push r8
000074ad747daf63  push r9
000074ad747daf65  push r10
000074ad747daf67  push r11
000074ad747daf69  sub rsp, 0xF0
000074ad747daf70  vmovaps [rsp], xmm0
000074ad747daf75  vmovaps [rsp+0x10], xmm1
000074ad747daf7b  vmovaps [rsp+0x20], xmm3
000074ad747daf81  vmovaps [rsp+0x30], xmm4
000074ad747daf87  vmovaps [rsp+0x40], xmm5
000074ad747daf8d  vmovaps [rsp+0x50], xmm6
000074ad747daf93  vmovaps [rsp+0x60], xmm7
000074ad747daf99  vmovaps [rsp+0x70], xmm8
000074ad747daf9f  vmovaps [rsp+0x80], xmm9
000074ad747dafa8  vmovaps [rsp+0x90], xmm10
000074ad747dafb1  vmovaps [rsp+0xA0], xmm11
000074ad747dafba  vmovaps [rsp+0xB0], xmm12
000074ad747dafc3  vmovaps [rsp+0xC0], xmm13
000074ad747dafcc  vmovaps [rsp+0xD0], xmm14
000074ad747dafd5  vmovaps [rsp+0xE0], xmm15
000074ad747dafde  sub rsp, 0x40
000074ad747dafe2  lea rdi, [rsp]
000074ad747dafe6  lea rsi, [rsp+0x10]
000074ad747dafeb  lea rdx, [rsp+0x20]
000074ad747daff0  lea rcx, [rsp+0x30]
000074ad747daff5  mov r8d, 0x00
000074ad747daffb  lea r9, [r15+0x3A8]
000074ad747db002  movaps [rdi], xmm2
000074ad747db005  movaps [rsi], xmm15
000074ad747db009  movaps [rdx], xmm12
000074ad747db00d  movaps [rcx], xmm1
000074ad747db010  mov rax, 0x5C17501CEA50
000074ad747db01a  call rax
000074ad747db01c  movaps xmm2, [rsp]
000074ad747db020  add rsp, 0x40
000074ad747db024  vmovaps xmm0, [rsp]
000074ad747db029  vmovaps xmm1, [rsp+0x10]
000074ad747db02f  vmovaps xmm3, [rsp+0x20]
000074ad747db035  vmovaps xmm4, [rsp+0x30]
000074ad747db03b  vmovaps xmm5, [rsp+0x40]
000074ad747db041  vmovaps xmm6, [rsp+0x50]
000074ad747db047  vmovaps xmm7, [rsp+0x60]
000074ad747db04d  vmovaps xmm8, [rsp+0x70]
000074ad747db053  vmovaps xmm9, [rsp+0x80]
000074ad747db05c  vmovaps xmm10, [rsp+0x90]
000074ad747db065  vmovaps xmm11, [rsp+0xA0]
000074ad747db06e  vmovaps xmm12, [rsp+0xB0]
000074ad747db077  vmovaps xmm13, [rsp+0xC0]
000074ad747db080  vmovaps xmm14, [rsp+0xD0]
000074ad747db089  vmovaps xmm15, [rsp+0xE0]
000074ad747db092  add rsp, 0xF0
000074ad747db099  pop r11
000074ad747db09b  pop r10
000074ad747db09d  pop r9
000074ad747db09f  pop r8
000074ad747db0a1  pop rsi
000074ad747db0a2  pop rdi
000074ad747db0a3  pop rdx
000074ad747db0a4  pop rcx
000074ad747db0a5  pop rax
000074ad747db0a6  add rsp, 0x08
000074ad747db0aa  jmp 0x000074AD747DA059
000074ad747db0af  sub rsp, 0x08
000074ad747db0b3  push rax
000074ad747db0b4  push rcx
000074ad747db0b5  push rdx
000074ad747db0b6  push rdi
000074ad747db0b7  push rsi
000074ad747db0b8  push r8
000074ad747db0ba  push r9
000074ad747db0bc  push r10
000074ad747db0be  push r11
000074ad747db0c0  sub rsp, 0xF0
000074ad747db0c7  vmovaps [rsp], xmm0
000074ad747db0cc  vmovaps [rsp+0x10], xmm1
000074ad747db0d2  vmovaps [rsp+0x20], xmm2
000074ad747db0d8  vmovaps [rsp+0x30], xmm3
000074ad747db0de  vmovaps [rsp+0x40], xmm4
000074ad747db0e4  vmovaps [rsp+0x50], xmm5
000074ad747db0ea  vmovaps [rsp+0x60], xmm6
000074ad747db0f0  vmovaps [rsp+0x70], xmm7
000074ad747db0f6  vmovaps [rsp+0x80], xmm8
000074ad747db0ff  vmovaps [rsp+0x90], xmm9
000074ad747db108  vmovaps [rsp+0xA0], xmm10
000074ad747db111  vmovaps [rsp+0xB0], xmm11
000074ad747db11a  vmovaps [rsp+0xC0], xmm13
000074ad747db123  vmovaps [rsp+0xD0], xmm14
000074ad747db12c  vmovaps [rsp+0xE0], xmm15
000074ad747db135  sub rsp, 0x40
000074ad747db139  lea rdi, [rsp]
000074ad747db13d  lea rsi, [rsp+0x10]
000074ad747db142  lea rdx, [rsp+0x20]
000074ad747db147  lea rcx, [rsp+0x30]
000074ad747db14c  mov r8d, 0x00
000074ad747db152  lea r9, [r15+0x3A8]
000074ad747db159  movaps [rdi], xmm12
000074ad747db15d  movaps [rsi], xmm14
000074ad747db161  movaps [rdx], xmm3
000074ad747db164  movaps [rcx], xmm15
000074ad747db168  mov rax, 0x5C17501CEA50
000074ad747db172  call rax
000074ad747db174  movaps xmm12, [rsp]
000074ad747db179  add rsp, 0x40
000074ad747db17d  vmovaps xmm0, [rsp]
000074ad747db182  vmovaps xmm1, [rsp+0x10]
000074ad747db188  vmovaps xmm2, [rsp+0x20]
000074ad747db18e  vmovaps xmm3, [rsp+0x30]
000074ad747db194  vmovaps xmm4, [rsp+0x40]
000074ad747db19a  vmovaps xmm5, [rsp+0x50]
000074ad747db1a0  vmovaps xmm6, [rsp+0x60]
000074ad747db1a6  vmovaps xmm7, [rsp+0x70]
000074ad747db1ac  vmovaps xmm8, [rsp+0x80]
000074ad747db1b5  vmovaps xmm9, [rsp+0x90]
000074ad747db1be  vmovaps xmm10, [rsp+0xA0]
000074ad747db1c7  vmovaps xmm11, [rsp+0xB0]
000074ad747db1d0  vmovaps xmm13, [rsp+0xC0]
000074ad747db1d9  vmovaps xmm14, [rsp+0xD0]
000074ad747db1e2  vmovaps xmm15, [rsp+0xE0]
000074ad747db1eb  add rsp, 0xF0
000074ad747db1f2  pop r11
000074ad747db1f4  pop r10
000074ad747db1f6  pop r9
000074ad747db1f8  pop r8
000074ad747db1fa  pop rsi
000074ad747db1fb  pop rdi
000074ad747db1fc  pop rdx
000074ad747db1fd  pop rcx
000074ad747db1fe  pop rax
000074ad747db1ff  add rsp, 0x08
000074ad747db203  jmp 0x000074AD747DA0B3
000074ad747db208  sub rsp, 0x08
000074ad747db20c  push rax
000074ad747db20d  push rcx
000074ad747db20e  push rdx
000074ad747db20f  push rdi
000074ad747db210  push rsi
000074ad747db211  push r8
000074ad747db213  push r9
000074ad747db215  push r10
000074ad747db217  push r11
000074ad747db219  sub rsp, 0xF0
000074ad747db220  vmovaps [rsp], xmm0
000074ad747db225  vmovaps [rsp+0x10], xmm1
000074ad747db22b  vmovaps [rsp+0x20], xmm2
000074ad747db231  vmovaps [rsp+0x30], xmm3
000074ad747db237  vmovaps [rsp+0x40], xmm4
000074ad747db23d  vmovaps [rsp+0x50], xmm5
000074ad747db243  vmovaps [rsp+0x60], xmm6
000074ad747db249  vmovaps [rsp+0x70], xmm7
000074ad747db24f  vmovaps [rsp+0x80], xmm8
000074ad747db258  vmovaps [rsp+0x90], xmm10
000074ad747db261  vmovaps [rsp+0xA0], xmm11
000074ad747db26a  vmovaps [rsp+0xB0], xmm12
000074ad747db273  vmovaps [rsp+0xC0], xmm13
000074ad747db27c  vmovaps [rsp+0xD0], xmm14
000074ad747db285  vmovaps [rsp+0xE0], xmm15
000074ad747db28e  sub rsp, 0x40
000074ad747db292  lea rdi, [rsp]
000074ad747db296  lea rsi, [rsp+0x10]
000074ad747db29b  lea rdx, [rsp+0x20]
000074ad747db2a0  lea rcx, [rsp+0x30]
000074ad747db2a5  mov r8d, 0x00
000074ad747db2ab  lea r9, [r15+0x3A8]
000074ad747db2b2  movaps [rdi], xmm9
000074ad747db2b6  movaps [rsi], xmm13
000074ad747db2ba  movaps [rdx], xmm14
000074ad747db2be  movaps [rcx], xmm6
000074ad747db2c1  mov rax, 0x5C17501CEA50
000074ad747db2cb  call rax
000074ad747db2cd  movaps xmm9, [rsp]
000074ad747db2d2  add rsp, 0x40
000074ad747db2d6  vmovaps xmm0, [rsp]
000074ad747db2db  vmovaps xmm1, [rsp+0x10]
000074ad747db2e1  vmovaps xmm2, [rsp+0x20]
000074ad747db2e7  vmovaps xmm3, [rsp+0x30]
000074ad747db2ed  vmovaps xmm4, [rsp+0x40]
000074ad747db2f3  vmovaps xmm5, [rsp+0x50]
000074ad747db2f9  vmovaps xmm6, [rsp+0x60]
000074ad747db2ff  vmovaps xmm7, [rsp+0x70]
000074ad747db305  vmovaps xmm8, [rsp+0x80]
000074ad747db30e  vmovaps xmm10, [rsp+0x90]
000074ad747db317  vmovaps xmm11, [rsp+0xA0]
000074ad747db320  vmovaps xmm12, [rsp+0xB0]
000074ad747db329  vmovaps xmm13, [rsp+0xC0]
000074ad747db332  vmovaps xmm14, [rsp+0xD0]
000074ad747db33b  vmovaps xmm15, [rsp+0xE0]
000074ad747db344  add rsp, 0xF0
000074ad747db34b  pop r11
000074ad747db34d  pop r10
000074ad747db34f  pop r9
000074ad747db351  pop r8
000074ad747db353  pop rsi
000074ad747db354  pop rdi
000074ad747db355  pop rdx
000074ad747db356  pop rcx
000074ad747db357  pop rax
000074ad747db358  add rsp, 0x08
000074ad747db35c  jmp 0x000074AD747DA15D
000074ad747db361  sub rsp, 0x08
000074ad747db365  push rax
000074ad747db366  push rcx
000074ad747db367  push rdx
000074ad747db368  push rdi
000074ad747db369  push rsi
000074ad747db36a  push r8
000074ad747db36c  push r9
000074ad747db36e  push r10
000074ad747db370  push r11
000074ad747db372  sub rsp, 0xF0
000074ad747db379  vmovaps [rsp], xmm0
000074ad747db37e  vmovaps [rsp+0x10], xmm1
000074ad747db384  vmovaps [rsp+0x20], xmm2
000074ad747db38a  vmovaps [rsp+0x30], xmm4
000074ad747db390  vmovaps [rsp+0x40], xmm5
000074ad747db396  vmovaps [rsp+0x50], xmm6
000074ad747db39c  vmovaps [rsp+0x60], xmm7
000074ad747db3a2  vmovaps [rsp+0x70], xmm8
000074ad747db3a8  vmovaps [rsp+0x80], xmm9
000074ad747db3b1  vmovaps [rsp+0x90], xmm10
000074ad747db3ba  vmovaps [rsp+0xA0], xmm11
000074ad747db3c3  vmovaps [rsp+0xB0], xmm12
000074ad747db3cc  vmovaps [rsp+0xC0], xmm13
000074ad747db3d5  vmovaps [rsp+0xD0], xmm14
000074ad747db3de  vmovaps [rsp+0xE0], xmm15
000074ad747db3e7  sub rsp, 0x40
000074ad747db3eb  lea rdi, [rsp]
000074ad747db3ef  lea rsi, [rsp+0x10]
000074ad747db3f4  lea rdx, [rsp+0x20]
000074ad747db3f9  lea rcx, [rsp+0x30]
000074ad747db3fe  mov r8d, 0x00
000074ad747db404  lea r9, [r15+0x3A8]
000074ad747db40b  movaps [rdi], xmm3
000074ad747db40e  movaps [rsi], xmm13
000074ad747db412  movaps [rdx], xmm6
000074ad747db415  movaps [rcx], xmm14
000074ad747db419  mov rax, 0x5C17501CEA50
000074ad747db423  call rax
000074ad747db425  movaps xmm3, [rsp]
000074ad747db429  add rsp, 0x40
000074ad747db42d  vmovaps xmm0, [rsp]
000074ad747db432  vmovaps xmm1, [rsp+0x10]
000074ad747db438  vmovaps xmm2, [rsp+0x20]
000074ad747db43e  vmovaps xmm4, [rsp+0x30]
000074ad747db444  vmovaps xmm5, [rsp+0x40]
000074ad747db44a  vmovaps xmm6, [rsp+0x50]
000074ad747db450  vmovaps xmm7, [rsp+0x60]
000074ad747db456  vmovaps xmm8, [rsp+0x70]
000074ad747db45c  vmovaps xmm9, [rsp+0x80]
000074ad747db465  vmovaps xmm10, [rsp+0x90]
000074ad747db46e  vmovaps xmm11, [rsp+0xA0]
000074ad747db477  vmovaps xmm12, [rsp+0xB0]
000074ad747db480  vmovaps xmm13, [rsp+0xC0]
000074ad747db489  vmovaps xmm14, [rsp+0xD0]
000074ad747db492  vmovaps xmm15, [rsp+0xE0]
000074ad747db49b  add rsp, 0xF0
000074ad747db4a2  pop r11
000074ad747db4a4  pop r10
000074ad747db4a6  pop r9
000074ad747db4a8  pop r8
000074ad747db4aa  pop rsi
000074ad747db4ab  pop rdi
000074ad747db4ac  pop rdx
000074ad747db4ad  pop rcx
000074ad747db4ae  pop rax
000074ad747db4af  add rsp, 0x08
000074ad747db4b3  jmp 0x000074AD747DA19A
000074ad747db4b8  sub rsp, 0x08
000074ad747db4bc  push rax
000074ad747db4bd  push rcx
000074ad747db4be  push rdx
000074ad747db4bf  push rdi
000074ad747db4c0  push rsi
000074ad747db4c1  push r8
000074ad747db4c3  push r9
000074ad747db4c5  push r10
000074ad747db4c7  push r11
000074ad747db4c9  sub rsp, 0xF0
000074ad747db4d0  vmovaps [rsp], xmm0
000074ad747db4d5  vmovaps [rsp+0x10], xmm1
000074ad747db4db  vmovaps [rsp+0x20], xmm2
000074ad747db4e1  vmovaps [rsp+0x30], xmm3
000074ad747db4e7  vmovaps [rsp+0x40], xmm4
000074ad747db4ed  vmovaps [rsp+0x50], xmm5
000074ad747db4f3  vmovaps [rsp+0x60], xmm7
000074ad747db4f9  vmovaps [rsp+0x70], xmm8
000074ad747db4ff  vmovaps [rsp+0x80], xmm9
000074ad747db508  vmovaps [rsp+0x90], xmm10
000074ad747db511  vmovaps [rsp+0xA0], xmm11
000074ad747db51a  vmovaps [rsp+0xB0], xmm12
000074ad747db523  vmovaps [rsp+0xC0], xmm13
000074ad747db52c  vmovaps [rsp+0xD0], xmm14
000074ad747db535  vmovaps [rsp+0xE0], xmm15
000074ad747db53e  sub rsp, 0x40
000074ad747db542  lea rdi, [rsp]
000074ad747db546  lea rsi, [rsp+0x10]
000074ad747db54b  lea rdx, [rsp+0x20]
000074ad747db550  lea rcx, [rsp+0x30]
000074ad747db555  mov r8d, 0x00
000074ad747db55b  lea r9, [r15+0x3A8]
000074ad747db562  movaps [rdi], xmm6
000074ad747db565  movaps [rsi], xmm2
000074ad747db568  movaps [rdx], xmm14
000074ad747db56c  movaps [rcx], xmm1
000074ad747db56f  mov rax, 0x5C17501CEA50
000074ad747db579  call rax
000074ad747db57b  movaps xmm6, [rsp]
000074ad747db57f  add rsp, 0x40
000074ad747db583  vmovaps xmm0, [rsp]
000074ad747db588  vmovaps xmm1, [rsp+0x10]
000074ad747db58e  vmovaps xmm2, [rsp+0x20]
000074ad747db594  vmovaps xmm3, [rsp+0x30]
000074ad747db59a  vmovaps xmm4, [rsp+0x40]
000074ad747db5a0  vmovaps xmm5, [rsp+0x50]
000074ad747db5a6  vmovaps xmm7, [rsp+0x60]
000074ad747db5ac  vmovaps xmm8, [rsp+0x70]
000074ad747db5b2  vmovaps xmm9, [rsp+0x80]
000074ad747db5bb  vmovaps xmm10, [rsp+0x90]
000074ad747db5c4  vmovaps xmm11, [rsp+0xA0]
000074ad747db5cd  vmovaps xmm12, [rsp+0xB0]
000074ad747db5d6  vmovaps xmm13, [rsp+0xC0]
000074ad747db5df  vmovaps xmm14, [rsp+0xD0]
000074ad747db5e8  vmovaps xmm15, [rsp+0xE0]
000074ad747db5f1  add rsp, 0xF0
000074ad747db5f8  pop r11
000074ad747db5fa  pop r10
000074ad747db5fc  pop r9
000074ad747db5fe  pop r8
000074ad747db600  pop rsi
000074ad747db601  pop rdi
000074ad747db602  pop rdx
000074ad747db603  pop rcx
000074ad747db604  pop rax
000074ad747db605  add rsp, 0x08
000074ad747db609  jmp 0x000074AD747DA1C7
000074ad747db60e  sub rsp, 0x08
000074ad747db612  push rax
000074ad747db613  push rcx
000074ad747db614  push rdx
000074ad747db615  push rdi
000074ad747db616  push rsi
000074ad747db617  push r8
000074ad747db619  push r9
000074ad747db61b  push r10
000074ad747db61d  push r11
000074ad747db61f  sub rsp, 0xF0
000074ad747db626  vmovaps [rsp], xmm0
000074ad747db62b  vmovaps [rsp+0x10], xmm1
000074ad747db631  vmovaps [rsp+0x20], xmm2
000074ad747db637  vmovaps [rsp+0x30], xmm3
000074ad747db63d  vmovaps [rsp+0x40], xmm4
000074ad747db643  vmovaps [rsp+0x50], xmm5
000074ad747db649  vmovaps [rsp+0x60], xmm6
000074ad747db64f  vmovaps [rsp+0x70], xmm7
000074ad747db655  vmovaps [rsp+0x80], xmm8
000074ad747db65e  vmovaps [rsp+0x90], xmm9
000074ad747db667  vmovaps [rsp+0xA0], xmm10
000074ad747db670  vmovaps [rsp+0xB0], xmm11
000074ad747db679  vmovaps [rsp+0xC0], xmm12
000074ad747db682  vmovaps [rsp+0xD0], xmm14
000074ad747db68b  vmovaps [rsp+0xE0], xmm15
000074ad747db694  sub rsp, 0x40
000074ad747db698  lea rdi, [rsp]
000074ad747db69c  lea rsi, [rsp+0x10]
000074ad747db6a1  lea rdx, [rsp+0x20]
000074ad747db6a6  lea rcx, [rsp+0x30]
000074ad747db6ab  mov r8d, 0x00
000074ad747db6b1  lea r9, [r15+0x3A8]
000074ad747db6b8  movaps [rdi], xmm13
000074ad747db6bc  movaps [rsi], xmm12
000074ad747db6c0  movaps [rdx], xmm14
000074ad747db6c4  movaps [rcx], xmm1
000074ad747db6c7  mov rax, 0x5C17501CEA50
000074ad747db6d1  call rax
000074ad747db6d3  movaps xmm13, [rsp]
000074ad747db6d8  add rsp, 0x40
000074ad747db6dc  vmovaps xmm0, [rsp]
000074ad747db6e1  vmovaps xmm1, [rsp+0x10]
000074ad747db6e7  vmovaps xmm2, [rsp+0x20]
000074ad747db6ed  vmovaps xmm3, [rsp+0x30]
000074ad747db6f3  vmovaps xmm4, [rsp+0x40]
000074ad747db6f9  vmovaps xmm5, [rsp+0x50]
000074ad747db6ff  vmovaps xmm6, [rsp+0x60]
000074ad747db705  vmovaps xmm7, [rsp+0x70]
000074ad747db70b  vmovaps xmm8, [rsp+0x80]
000074ad747db714  vmovaps xmm9, [rsp+0x90]
000074ad747db71d  vmovaps xmm10, [rsp+0xA0]
000074ad747db726  vmovaps xmm11, [rsp+0xB0]
000074ad747db72f  vmovaps xmm12, [rsp+0xC0]
000074ad747db738  vmovaps xmm14, [rsp+0xD0]
000074ad747db741  vmovaps xmm15, [rsp+0xE0]
000074ad747db74a  add rsp, 0xF0
000074ad747db751  pop r11
000074ad747db753  pop r10
000074ad747db755  pop r9
000074ad747db757  pop r8
000074ad747db759  pop rsi
000074ad747db75a  pop rdi
000074ad747db75b  pop rdx
000074ad747db75c  pop rcx
000074ad747db75d  pop rax
000074ad747db75e  add rsp, 0x08
000074ad747db762  jmp 0x000074AD747DA1F9
000074ad747db767  sub rsp, 0x08
000074ad747db76b  push rax
000074ad747db76c  push rcx
000074ad747db76d  push rdx
000074ad747db76e  push rdi
000074ad747db76f  push rsi
000074ad747db770  push r8
000074ad747db772  push r9
000074ad747db774  push r10
000074ad747db776  push r11
000074ad747db778  sub rsp, 0xF0
000074ad747db77f  vmovaps [rsp], xmm0
000074ad747db784  vmovaps [rsp+0x10], xmm1
000074ad747db78a  vmovaps [rsp+0x20], xmm2
000074ad747db790  vmovaps [rsp+0x30], xmm3
000074ad747db796  vmovaps [rsp+0x40], xmm4
000074ad747db79c  vmovaps [rsp+0x50], xmm5
000074ad747db7a2  vmovaps [rsp+0x60], xmm6
000074ad747db7a8  vmovaps [rsp+0x70], xmm7
000074ad747db7ae  vmovaps [rsp+0x80], xmm8
000074ad747db7b7  vmovaps [rsp+0x90], xmm9
000074ad747db7c0  vmovaps [rsp+0xA0], xmm10
000074ad747db7c9  vmovaps [rsp+0xB0], xmm11
000074ad747db7d2  vmovaps [rsp+0xC0], xmm13
000074ad747db7db  vmovaps [rsp+0xD0], xmm14
000074ad747db7e4  vmovaps [rsp+0xE0], xmm15
000074ad747db7ed  sub rsp, 0x40
000074ad747db7f1  lea rdi, [rsp]
000074ad747db7f5  lea rsi, [rsp+0x10]
000074ad747db7fa  lea rdx, [rsp+0x20]
000074ad747db7ff  lea rcx, [rsp+0x30]
000074ad747db804  mov r8d, 0x00
000074ad747db80a  lea r9, [r15+0x3A8]
000074ad747db811  movaps [rdi], xmm12
000074ad747db815  movaps [rsi], xmm3
000074ad747db818  movaps [rdx], xmm14
000074ad747db81c  movaps [rcx], xmm5
000074ad747db81f  mov rax, 0x5C17501CEA50
000074ad747db829  call rax
000074ad747db82b  movaps xmm12, [rsp]
000074ad747db830  add rsp, 0x40
000074ad747db834  vmovaps xmm0, [rsp]
000074ad747db839  vmovaps xmm1, [rsp+0x10]
000074ad747db83f  vmovaps xmm2, [rsp+0x20]
000074ad747db845  vmovaps xmm3, [rsp+0x30]
000074ad747db84b  vmovaps xmm4, [rsp+0x40]
000074ad747db851  vmovaps xmm5, [rsp+0x50]
000074ad747db857  vmovaps xmm6, [rsp+0x60]
000074ad747db85d  vmovaps xmm7, [rsp+0x70]
000074ad747db863  vmovaps xmm8, [rsp+0x80]
000074ad747db86c  vmovaps xmm9, [rsp+0x90]
000074ad747db875  vmovaps xmm10, [rsp+0xA0]
000074ad747db87e  vmovaps xmm11, [rsp+0xB0]
000074ad747db887  vmovaps xmm13, [rsp+0xC0]
000074ad747db890  vmovaps xmm14, [rsp+0xD0]
000074ad747db899  vmovaps xmm15, [rsp+0xE0]
000074ad747db8a2  add rsp, 0xF0
000074ad747db8a9  pop r11
000074ad747db8ab  pop r10
000074ad747db8ad  pop r9
000074ad747db8af  pop r8
000074ad747db8b1  pop rsi
000074ad747db8b2  pop rdi
000074ad747db8b3  pop rdx
000074ad747db8b4  pop rcx
000074ad747db8b5  pop rax
000074ad747db8b6  add rsp, 0x08
000074ad747db8ba  jmp 0x000074AD747DA256
000074ad747db8bf  sub rsp, 0x08
000074ad747db8c3  push rax
000074ad747db8c4  push rcx
000074ad747db8c5  push rdx
000074ad747db8c6  push rdi
000074ad747db8c7  push rsi
000074ad747db8c8  push r8
000074ad747db8ca  push r9
000074ad747db8cc  push r10
000074ad747db8ce  push r11
000074ad747db8d0  sub rsp, 0xF0
000074ad747db8d7  vmovaps [rsp], xmm0
000074ad747db8dc  vmovaps [rsp+0x10], xmm1
000074ad747db8e2  vmovaps [rsp+0x20], xmm2
000074ad747db8e8  vmovaps [rsp+0x30], xmm3
000074ad747db8ee  vmovaps [rsp+0x40], xmm4
000074ad747db8f4  vmovaps [rsp+0x50], xmm5
000074ad747db8fa  vmovaps [rsp+0x60], xmm6
000074ad747db900  vmovaps [rsp+0x70], xmm7
000074ad747db906  vmovaps [rsp+0x80], xmm8
000074ad747db90f  vmovaps [rsp+0x90], xmm9
000074ad747db918  vmovaps [rsp+0xA0], xmm11
000074ad747db921  vmovaps [rsp+0xB0], xmm12
000074ad747db92a  vmovaps [rsp+0xC0], xmm13
000074ad747db933  vmovaps [rsp+0xD0], xmm14
000074ad747db93c  vmovaps [rsp+0xE0], xmm15
000074ad747db945  sub rsp, 0x40
000074ad747db949  lea rdi, [rsp]
000074ad747db94d  lea rsi, [rsp+0x10]
000074ad747db952  lea rdx, [rsp+0x20]
000074ad747db957  lea rcx, [rsp+0x30]
000074ad747db95c  mov r8d, 0x00
000074ad747db962  lea r9, [r15+0x3A8]
000074ad747db969  movaps [rdi], xmm10
000074ad747db96d  movaps [rsi], xmm9
000074ad747db971  movaps [rdx], xmm7
000074ad747db974  movaps [rcx], xmm14
000074ad747db978  mov rax, 0x5C17501CEA50
000074ad747db982  call rax
000074ad747db984  movaps xmm10, [rsp]
000074ad747db989  add rsp, 0x40
000074ad747db98d  vmovaps xmm0, [rsp]
000074ad747db992  vmovaps xmm1, [rsp+0x10]
000074ad747db998  vmovaps xmm2, [rsp+0x20]
000074ad747db99e  vmovaps xmm3, [rsp+0x30]
000074ad747db9a4  vmovaps xmm4, [rsp+0x40]
000074ad747db9aa  vmovaps xmm5, [rsp+0x50]
000074ad747db9b0  vmovaps xmm6, [rsp+0x60]
000074ad747db9b6  vmovaps xmm7, [rsp+0x70]
000074ad747db9bc  vmovaps xmm8, [rsp+0x80]
000074ad747db9c5  vmovaps xmm9, [rsp+0x90]
000074ad747db9ce  vmovaps xmm11, [rsp+0xA0]
000074ad747db9d7  vmovaps xmm12, [rsp+0xB0]
000074ad747db9e0  vmovaps xmm13, [rsp+0xC0]
000074ad747db9e9  vmovaps xmm14, [rsp+0xD0]
000074ad747db9f2  vmovaps xmm15, [rsp+0xE0]
000074ad747db9fb  add rsp, 0xF0
000074ad747dba02  pop r11
000074ad747dba04  pop r10
000074ad747dba06  pop r9
000074ad747dba08  pop r8
000074ad747dba0a  pop rsi
000074ad747dba0b  pop rdi
000074ad747dba0c  pop rdx
000074ad747dba0d  pop rcx
000074ad747dba0e  pop rax
000074ad747dba0f  add rsp, 0x08
000074ad747dba13  jmp 0x000074AD747DA27C
000074ad747dba18  call 0x000074AD7460D4E0
000074ad747dba1d  jmp 0x000074AD747DA289
000074ad747dba22  sub rsp, 0x08
000074ad747dba26  push rax
000074ad747dba27  push rcx
000074ad747dba28  push rdx
000074ad747dba29  push rdi
000074ad747dba2a  push rsi
000074ad747dba2b  push r8
000074ad747dba2d  push r9
000074ad747dba2f  push r10
000074ad747dba31  push r11
000074ad747dba33  sub rsp, 0xF0
000074ad747dba3a  vmovaps [rsp], xmm0
000074ad747dba3f  vmovaps [rsp+0x10], xmm1
000074ad747dba45  vmovaps [rsp+0x20], xmm2
000074ad747dba4b  vmovaps [rsp+0x30], xmm3
000074ad747dba51  vmovaps [rsp+0x40], xmm4
000074ad747dba57  vmovaps [rsp+0x50], xmm6
000074ad747dba5d  vmovaps [rsp+0x60], xmm7
000074ad747dba63  vmovaps [rsp+0x70], xmm8
000074ad747dba69  vmovaps [rsp+0x80], xmm9
000074ad747dba72  vmovaps [rsp+0x90], xmm10
000074ad747dba7b  vmovaps [rsp+0xA0], xmm11
000074ad747dba84  vmovaps [rsp+0xB0], xmm12
000074ad747dba8d  vmovaps [rsp+0xC0], xmm13
000074ad747dba96  vmovaps [rsp+0xD0], xmm14
000074ad747dba9f  vmovaps [rsp+0xE0], xmm15
000074ad747dbaa8  sub rsp, 0x40
000074ad747dbaac  lea rdi, [rsp]
000074ad747dbab0  lea rsi, [rsp+0x10]
000074ad747dbab5  lea rdx, [rsp+0x20]
000074ad747dbaba  lea rcx, [rsp+0x30]
000074ad747dbabf  mov r8d, 0x00
000074ad747dbac5  lea r9, [r15+0x3A8]
000074ad747dbacc  movaps [rdi], xmm5
000074ad747dbacf  movaps [rsi], xmm6
000074ad747dbad2  movaps [rdx], xmm7
000074ad747dbad5  movaps [rcx], xmm9
000074ad747dbad9  mov rax, 0x5C17501CEA50
000074ad747dbae3  call rax
000074ad747dbae5  movaps xmm5, [rsp]
000074ad747dbae9  add rsp, 0x40
000074ad747dbaed  vmovaps xmm0, [rsp]
000074ad747dbaf2  vmovaps xmm1, [rsp+0x10]
000074ad747dbaf8  vmovaps xmm2, [rsp+0x20]
000074ad747dbafe  vmovaps xmm3, [rsp+0x30]
000074ad747dbb04  vmovaps xmm4, [rsp+0x40]
000074ad747dbb0a  vmovaps xmm6, [rsp+0x50]
000074ad747dbb10  vmovaps xmm7, [rsp+0x60]
000074ad747dbb16  vmovaps xmm8, [rsp+0x70]
000074ad747dbb1c  vmovaps xmm9, [rsp+0x80]
000074ad747dbb25  vmovaps xmm10, [rsp+0x90]
000074ad747dbb2e  vmovaps xmm11, [rsp+0xA0]
000074ad747dbb37  vmovaps xmm12, [rsp+0xB0]
000074ad747dbb40  vmovaps xmm13, [rsp+0xC0]
000074ad747dbb49  vmovaps xmm14, [rsp+0xD0]
000074ad747dbb52  vmovaps xmm15, [rsp+0xE0]
000074ad747dbb5b  add rsp, 0xF0
000074ad747dbb62  pop r11
000074ad747dbb64  pop r10
000074ad747dbb66  pop r9
000074ad747dbb68  pop r8
000074ad747dbb6a  pop rsi
000074ad747dbb6b  pop rdi
000074ad747dbb6c  pop rdx
000074ad747dbb6d  pop rcx
000074ad747dbb6e  pop rax
000074ad747dbb6f  add rsp, 0x08
000074ad747dbb73  jmp 0x000074AD747DA2BB
000074ad747dbb78  sub rsp, 0x08
000074ad747dbb7c  push rax
000074ad747dbb7d  push rcx
000074ad747dbb7e  push rdx
000074ad747dbb7f  push rdi
000074ad747dbb80  push rsi
000074ad747dbb81  push r8
000074ad747dbb83  push r9
000074ad747dbb85  push r10
000074ad747dbb87  push r11
000074ad747dbb89  sub rsp, 0xF0
000074ad747dbb90  vmovaps [rsp], xmm0
000074ad747dbb95  vmovaps [rsp+0x10], xmm1
000074ad747dbb9b  vmovaps [rsp+0x20], xmm2
000074ad747dbba1  vmovaps [rsp+0x30], xmm3
000074ad747dbba7  vmovaps [rsp+0x40], xmm4
000074ad747dbbad  vmovaps [rsp+0x50], xmm5
000074ad747dbbb3  vmovaps [rsp+0x60], xmm6
000074ad747dbbb9  vmovaps [rsp+0x70], xmm8
000074ad747dbbbf  vmovaps [rsp+0x80], xmm9
000074ad747dbbc8  vmovaps [rsp+0x90], xmm10
000074ad747dbbd1  vmovaps [rsp+0xA0], xmm11
000074ad747dbbda  vmovaps [rsp+0xB0], xmm12
000074ad747dbbe3  vmovaps [rsp+0xC0], xmm13
000074ad747dbbec  vmovaps [rsp+0xD0], xmm14
000074ad747dbbf5  vmovaps [rsp+0xE0], xmm15
000074ad747dbbfe  sub rsp, 0x40
000074ad747dbc02  lea rdi, [rsp]
000074ad747dbc06  lea rsi, [rsp+0x10]
000074ad747dbc0b  lea rdx, [rsp+0x20]
000074ad747dbc10  lea rcx, [rsp+0x30]
000074ad747dbc15  mov r8d, 0x00
000074ad747dbc1b  lea r9, [r15+0x3A8]
000074ad747dbc22  movaps [rdi], xmm7
000074ad747dbc25  movaps [rsi], xmm13
000074ad747dbc29  movaps [rdx], xmm1
000074ad747dbc2c  movaps [rcx], xmm9
000074ad747dbc30  mov rax, 0x5C17501CEA50
000074ad747dbc3a  call rax
000074ad747dbc3c  movaps xmm7, [rsp]
000074ad747dbc40  add rsp, 0x40
000074ad747dbc44  vmovaps xmm0, [rsp]
000074ad747dbc49  vmovaps xmm1, [rsp+0x10]
000074ad747dbc4f  vmovaps xmm2, [rsp+0x20]
000074ad747dbc55  vmovaps xmm3, [rsp+0x30]
000074ad747dbc5b  vmovaps xmm4, [rsp+0x40]
000074ad747dbc61  vmovaps xmm5, [rsp+0x50]
000074ad747dbc67  vmovaps xmm6, [rsp+0x60]
000074ad747dbc6d  vmovaps xmm8, [rsp+0x70]
000074ad747dbc73  vmovaps xmm9, [rsp+0x80]
000074ad747dbc7c  vmovaps xmm10, [rsp+0x90]
000074ad747dbc85  vmovaps xmm11, [rsp+0xA0]
000074ad747dbc8e  vmovaps xmm12, [rsp+0xB0]
000074ad747dbc97  vmovaps xmm13, [rsp+0xC0]
000074ad747dbca0  vmovaps xmm14, [rsp+0xD0]
000074ad747dbca9  vmovaps xmm15, [rsp+0xE0]
000074ad747dbcb2  add rsp, 0xF0
000074ad747dbcb9  pop r11
000074ad747dbcbb  pop r10
000074ad747dbcbd  pop r9
000074ad747dbcbf  pop r8
000074ad747dbcc1  pop rsi
000074ad747dbcc2  pop rdi
000074ad747dbcc3  pop rdx
000074ad747dbcc4  pop rcx
000074ad747dbcc5  pop rax
000074ad747dbcc6  add rsp, 0x08
000074ad747dbcca  jmp 0x000074AD747DA2E0
000074ad747dbccf  call 0x000074AD7460C260
000074ad747dbcd4  jmp 0x000074AD747DA303
000074ad747dbcd9  call 0x000074AD74607890
000074ad747dbcde  jmp 0x000074AD747DA30D
000074ad747dbce3  sub rsp, 0x08
000074ad747dbce7  push rax
000074ad747dbce8  push rcx
000074ad747dbce9  push rdx
000074ad747dbcea  push rdi
000074ad747dbceb  push rsi
000074ad747dbcec  push r8
000074ad747dbcee  push r9
000074ad747dbcf0  push r10
000074ad747dbcf2  push r11
000074ad747dbcf4  sub rsp, 0xF0
000074ad747dbcfb  vmovaps [rsp], xmm0
000074ad747dbd00  vmovaps [rsp+0x10], xmm1
000074ad747dbd06  vmovaps [rsp+0x20], xmm3
000074ad747dbd0c  vmovaps [rsp+0x30], xmm4
000074ad747dbd12  vmovaps [rsp+0x40], xmm5
000074ad747dbd18  vmovaps [rsp+0x50], xmm6
000074ad747dbd1e  vmovaps [rsp+0x60], xmm7
000074ad747dbd24  vmovaps [rsp+0x70], xmm8
000074ad747dbd2a  vmovaps [rsp+0x80], xmm9
000074ad747dbd33  vmovaps [rsp+0x90], xmm10
000074ad747dbd3c  vmovaps [rsp+0xA0], xmm11
000074ad747dbd45  vmovaps [rsp+0xB0], xmm12
000074ad747dbd4e  vmovaps [rsp+0xC0], xmm13
000074ad747dbd57  vmovaps [rsp+0xD0], xmm14
000074ad747dbd60  vmovaps [rsp+0xE0], xmm15
000074ad747dbd69  sub rsp, 0x40
000074ad747dbd6d  lea rdi, [rsp]
000074ad747dbd71  lea rsi, [rsp+0x10]
000074ad747dbd76  lea rdx, [rsp+0x20]
000074ad747dbd7b  lea rcx, [rsp+0x30]
000074ad747dbd80  mov r8d, 0x00
000074ad747dbd86  lea r9, [r15+0x3A8]
000074ad747dbd8d  movaps [rdi], xmm2
000074ad747dbd90  movaps [rsi], xmm12
000074ad747dbd94  movaps [rdx], xmm6
000074ad747dbd97  movaps [rcx], xmm3
000074ad747dbd9a  mov rax, 0x5C17501CEA50
000074ad747dbda4  call rax
000074ad747dbda6  movaps xmm2, [rsp]
000074ad747dbdaa  add rsp, 0x40
000074ad747dbdae  vmovaps xmm0, [rsp]
000074ad747dbdb3  vmovaps xmm1, [rsp+0x10]
000074ad747dbdb9  vmovaps xmm3, [rsp+0x20]
000074ad747dbdbf  vmovaps xmm4, [rsp+0x30]
000074ad747dbdc5  vmovaps xmm5, [rsp+0x40]
000074ad747dbdcb  vmovaps xmm6, [rsp+0x50]
000074ad747dbdd1  vmovaps xmm7, [rsp+0x60]
000074ad747dbdd7  vmovaps xmm8, [rsp+0x70]
000074ad747dbddd  vmovaps xmm9, [rsp+0x80]
000074ad747dbde6  vmovaps xmm10, [rsp+0x90]
000074ad747dbdef  vmovaps xmm11, [rsp+0xA0]
000074ad747dbdf8  vmovaps xmm12, [rsp+0xB0]
000074ad747dbe01  vmovaps xmm13, [rsp+0xC0]
000074ad747dbe0a  vmovaps xmm14, [rsp+0xD0]
000074ad747dbe13  vmovaps xmm15, [rsp+0xE0]
000074ad747dbe1c  add rsp, 0xF0
000074ad747dbe23  pop r11
000074ad747dbe25  pop r10
000074ad747dbe27  pop r9
000074ad747dbe29  pop r8
000074ad747dbe2b  pop rsi
000074ad747dbe2c  pop rdi
000074ad747dbe2d  pop rdx
000074ad747dbe2e  pop rcx
000074ad747dbe2f  pop rax
000074ad747dbe30  add rsp, 0x08
000074ad747dbe34  jmp 0x000074AD747DA353
000074ad747dbe39  sub rsp, 0x08
000074ad747dbe3d  push rax
000074ad747dbe3e  push rcx
000074ad747dbe3f  push rdx
000074ad747dbe40  push rdi
000074ad747dbe41  push rsi
000074ad747dbe42  push r8
000074ad747dbe44  push r9
000074ad747dbe46  push r10
000074ad747dbe48  push r11
000074ad747dbe4a  sub rsp, 0xF0
000074ad747dbe51  vmovaps [rsp], xmm0
000074ad747dbe56  vmovaps [rsp+0x10], xmm1
000074ad747dbe5c  vmovaps [rsp+0x20], xmm2
000074ad747dbe62  vmovaps [rsp+0x30], xmm3
000074ad747dbe68  vmovaps [rsp+0x40], xmm4
000074ad747dbe6e  vmovaps [rsp+0x50], xmm5
000074ad747dbe74  vmovaps [rsp+0x60], xmm7
000074ad747dbe7a  vmovaps [rsp+0x70], xmm8
000074ad747dbe80  vmovaps [rsp+0x80], xmm9
000074ad747dbe89  vmovaps [rsp+0x90], xmm10
000074ad747dbe92  vmovaps [rsp+0xA0], xmm11
000074ad747dbe9b  vmovaps [rsp+0xB0], xmm12
000074ad747dbea4  vmovaps [rsp+0xC0], xmm13
000074ad747dbead  vmovaps [rsp+0xD0], xmm14
000074ad747dbeb6  vmovaps [rsp+0xE0], xmm15
000074ad747dbebf  sub rsp, 0x40
000074ad747dbec3  lea rdi, [rsp]
000074ad747dbec7  lea rsi, [rsp+0x10]
000074ad747dbecc  lea rdx, [rsp+0x20]
000074ad747dbed1  lea rcx, [rsp+0x30]
000074ad747dbed6  mov r8d, 0x00
000074ad747dbedc  lea r9, [r15+0x3A8]
000074ad747dbee3  movaps [rdi], xmm6
000074ad747dbee6  movaps [rsi], xmm10
000074ad747dbeea  movaps [rdx], xmm12
000074ad747dbeee  movaps [rcx], xmm1
000074ad747dbef1  mov rax, 0x5C17501CEA50
000074ad747dbefb  call rax
000074ad747dbefd  movaps xmm6, [rsp]
000074ad747dbf01  add rsp, 0x40
000074ad747dbf05  vmovaps xmm0, [rsp]
000074ad747dbf0a  vmovaps xmm1, [rsp+0x10]
000074ad747dbf10  vmovaps xmm2, [rsp+0x20]
000074ad747dbf16  vmovaps xmm3, [rsp+0x30]
000074ad747dbf1c  vmovaps xmm4, [rsp+0x40]
000074ad747dbf22  vmovaps xmm5, [rsp+0x50]
000074ad747dbf28  vmovaps xmm7, [rsp+0x60]
000074ad747dbf2e  vmovaps xmm8, [rsp+0x70]
000074ad747dbf34  vmovaps xmm9, [rsp+0x80]
000074ad747dbf3d  vmovaps xmm10, [rsp+0x90]
000074ad747dbf46  vmovaps xmm11, [rsp+0xA0]
000074ad747dbf4f  vmovaps xmm12, [rsp+0xB0]
000074ad747dbf58  vmovaps xmm13, [rsp+0xC0]
000074ad747dbf61  vmovaps xmm14, [rsp+0xD0]
000074ad747dbf6a  vmovaps xmm15, [rsp+0xE0]
000074ad747dbf73  add rsp, 0xF0
000074ad747dbf7a  pop r11
000074ad747dbf7c  pop r10
000074ad747dbf7e  pop r9
000074ad747dbf80  pop r8
000074ad747dbf82  pop rsi
000074ad747dbf83  pop rdi
000074ad747dbf84  pop rdx
000074ad747dbf85  pop rcx
000074ad747dbf86  pop rax
000074ad747dbf87  add rsp, 0x08
000074ad747dbf8b  jmp 0x000074AD747DA381
000074ad747dbf90  sub rsp, 0x08
000074ad747dbf94  push rax
000074ad747dbf95  push rcx
000074ad747dbf96  push rdx
000074ad747dbf97  push rdi
000074ad747dbf98  push rsi
000074ad747dbf99  push r8
000074ad747dbf9b  push r9
000074ad747dbf9d  push r10
000074ad747dbf9f  push r11
000074ad747dbfa1  sub rsp, 0xF0
000074ad747dbfa8  vmovaps [rsp], xmm0
000074ad747dbfad  vmovaps [rsp+0x10], xmm1
000074ad747dbfb3  vmovaps [rsp+0x20], xmm2
000074ad747dbfb9  vmovaps [rsp+0x30], xmm3
000074ad747dbfbf  vmovaps [rsp+0x40], xmm4
000074ad747dbfc5  vmovaps [rsp+0x50], xmm5
000074ad747dbfcb  vmovaps [rsp+0x60], xmm6
000074ad747dbfd1  vmovaps [rsp+0x70], xmm7
000074ad747dbfd7  vmovaps [rsp+0x80], xmm8
000074ad747dbfe0  vmovaps [rsp+0x90], xmm9
000074ad747dbfe9  vmovaps [rsp+0xA0], xmm11
000074ad747dbff2  vmovaps [rsp+0xB0], xmm12
000074ad747dbffb  vmovaps [rsp+0xC0], xmm13
000074ad747dc004  vmovaps [rsp+0xD0], xmm14
000074ad747dc00d  vmovaps [rsp+0xE0], xmm15
000074ad747dc016  sub rsp, 0x40
000074ad747dc01a  lea rdi, [rsp]
000074ad747dc01e  lea rsi, [rsp+0x10]
000074ad747dc023  lea rdx, [rsp+0x20]
000074ad747dc028  lea rcx, [rsp+0x30]
000074ad747dc02d  mov r8d, 0x00
000074ad747dc033  lea r9, [r15+0x3A8]
000074ad747dc03a  movaps [rdi], xmm10
000074ad747dc03e  movaps [rsi], xmm5
000074ad747dc041  movaps [rdx], xmm12
000074ad747dc045  movaps [rcx], xmm1
000074ad747dc048  mov rax, 0x5C17501CEA50
000074ad747dc052  call rax
000074ad747dc054  movaps xmm10, [rsp]
000074ad747dc059  add rsp, 0x40
000074ad747dc05d  vmovaps xmm0, [rsp]
000074ad747dc062  vmovaps xmm1, [rsp+0x10]
000074ad747dc068  vmovaps xmm2, [rsp+0x20]
000074ad747dc06e  vmovaps xmm3, [rsp+0x30]
000074ad747dc074  vmovaps xmm4, [rsp+0x40]
000074ad747dc07a  vmovaps xmm5, [rsp+0x50]
000074ad747dc080  vmovaps xmm6, [rsp+0x60]
000074ad747dc086  vmovaps xmm7, [rsp+0x70]
000074ad747dc08c  vmovaps xmm8, [rsp+0x80]
000074ad747dc095  vmovaps xmm9, [rsp+0x90]
000074ad747dc09e  vmovaps xmm11, [rsp+0xA0]
000074ad747dc0a7  vmovaps xmm12, [rsp+0xB0]
000074ad747dc0b0  vmovaps xmm13, [rsp+0xC0]
000074ad747dc0b9  vmovaps xmm14, [rsp+0xD0]
000074ad747dc0c2  vmovaps xmm15, [rsp+0xE0]
000074ad747dc0cb  add rsp, 0xF0
000074ad747dc0d2  pop r11
000074ad747dc0d4  pop r10
000074ad747dc0d6  pop r9
000074ad747dc0d8  pop r8
000074ad747dc0da  pop rsi
000074ad747dc0db  pop rdi
000074ad747dc0dc  pop rdx
000074ad747dc0dd  pop rcx
000074ad747dc0de  pop rax
000074ad747dc0df  add rsp, 0x08
000074ad747dc0e3  jmp 0x000074AD747DA3B0
000074ad747dc0e8  sub rsp, 0x08
000074ad747dc0ec  push rax
000074ad747dc0ed  push rcx
000074ad747dc0ee  push rdx
000074ad747dc0ef  push rdi
000074ad747dc0f0  push rsi
000074ad747dc0f1  push r8
000074ad747dc0f3  push r9
000074ad747dc0f5  push r10
000074ad747dc0f7  push r11
000074ad747dc0f9  sub rsp, 0xF0
000074ad747dc100  vmovaps [rsp], xmm0
000074ad747dc105  vmovaps [rsp+0x10], xmm1
000074ad747dc10b  vmovaps [rsp+0x20], xmm2
000074ad747dc111  vmovaps [rsp+0x30], xmm3
000074ad747dc117  vmovaps [rsp+0x40], xmm4
000074ad747dc11d  vmovaps [rsp+0x50], xmm5
000074ad747dc123  vmovaps [rsp+0x60], xmm6
000074ad747dc129  vmovaps [rsp+0x70], xmm7
000074ad747dc12f  vmovaps [rsp+0x80], xmm8
000074ad747dc138  vmovaps [rsp+0x90], xmm9
000074ad747dc141  vmovaps [rsp+0xA0], xmm10
000074ad747dc14a  vmovaps [rsp+0xB0], xmm11
000074ad747dc153  vmovaps [rsp+0xC0], xmm13
000074ad747dc15c  vmovaps [rsp+0xD0], xmm14
000074ad747dc165  vmovaps [rsp+0xE0], xmm15
000074ad747dc16e  sub rsp, 0x40
000074ad747dc172  lea rdi, [rsp]
000074ad747dc176  lea rsi, [rsp+0x10]
000074ad747dc17b  lea rdx, [rsp+0x20]
000074ad747dc180  lea rcx, [rsp+0x30]
000074ad747dc185  mov r8d, 0x00
000074ad747dc18b  lea r9, [r15+0x3A8]
000074ad747dc192  movaps [rdi], xmm12
000074ad747dc196  movaps [rsi], xmm7
000074ad747dc199  movaps [rdx], xmm15
000074ad747dc19d  movaps [rcx], xmm1
000074ad747dc1a0  mov rax, 0x5C17501CEA50
000074ad747dc1aa  call rax
000074ad747dc1ac  movaps xmm12, [rsp]
000074ad747dc1b1  add rsp, 0x40
000074ad747dc1b5  vmovaps xmm0, [rsp]
000074ad747dc1ba  vmovaps xmm1, [rsp+0x10]
000074ad747dc1c0  vmovaps xmm2, [rsp+0x20]
000074ad747dc1c6  vmovaps xmm3, [rsp+0x30]
000074ad747dc1cc  vmovaps xmm4, [rsp+0x40]
000074ad747dc1d2  vmovaps xmm5, [rsp+0x50]
000074ad747dc1d8  vmovaps xmm6, [rsp+0x60]
000074ad747dc1de  vmovaps xmm7, [rsp+0x70]
000074ad747dc1e4  vmovaps xmm8, [rsp+0x80]
000074ad747dc1ed  vmovaps xmm9, [rsp+0x90]
000074ad747dc1f6  vmovaps xmm10, [rsp+0xA0]
000074ad747dc1ff  vmovaps xmm11, [rsp+0xB0]
000074ad747dc208  vmovaps xmm13, [rsp+0xC0]
000074ad747dc211  vmovaps xmm14, [rsp+0xD0]
000074ad747dc21a  vmovaps xmm15, [rsp+0xE0]
000074ad747dc223  add rsp, 0xF0
000074ad747dc22a  pop r11
000074ad747dc22c  pop r10
000074ad747dc22e  pop r9
000074ad747dc230  pop r8
000074ad747dc232  pop rsi
000074ad747dc233  pop rdi
000074ad747dc234  pop rdx
000074ad747dc235  pop rcx
000074ad747dc236  pop rax
000074ad747dc237  add rsp, 0x08
000074ad747dc23b  jmp 0x000074AD747DA3D9
000074ad747dc240  call 0x000074AD745FF430
000074ad747dc245  jmp 0x000074AD747DA3E3
000074ad747dc24a  call 0x000074AD7460E760
000074ad747dc24f  jmp 0x000074AD747DA3ED
000074ad747dc254  sub rsp, 0x08
000074ad747dc258  push rax
000074ad747dc259  push rcx
000074ad747dc25a  push rdx
000074ad747dc25b  push rdi
000074ad747dc25c  push rsi
000074ad747dc25d  push r8
000074ad747dc25f  push r9
000074ad747dc261  push r10
000074ad747dc263  push r11
000074ad747dc265  sub rsp, 0xF0
000074ad747dc26c  vmovaps [rsp], xmm0
000074ad747dc271  vmovaps [rsp+0x10], xmm1
000074ad747dc277  vmovaps [rsp+0x20], xmm2
000074ad747dc27d  vmovaps [rsp+0x30], xmm3
000074ad747dc283  vmovaps [rsp+0x40], xmm4
000074ad747dc289  vmovaps [rsp+0x50], xmm5
000074ad747dc28f  vmovaps [rsp+0x60], xmm6
000074ad747dc295  vmovaps [rsp+0x70], xmm8
000074ad747dc29b  vmovaps [rsp+0x80], xmm9
000074ad747dc2a4  vmovaps [rsp+0x90], xmm10
000074ad747dc2ad  vmovaps [rsp+0xA0], xmm11
000074ad747dc2b6  vmovaps [rsp+0xB0], xmm12
000074ad747dc2bf  vmovaps [rsp+0xC0], xmm13
000074ad747dc2c8  vmovaps [rsp+0xD0], xmm14
000074ad747dc2d1  vmovaps [rsp+0xE0], xmm15
000074ad747dc2da  sub rsp, 0x40
000074ad747dc2de  lea rdi, [rsp]
000074ad747dc2e2  lea rsi, [rsp+0x10]
000074ad747dc2e7  lea rdx, [rsp+0x20]
000074ad747dc2ec  lea rcx, [rsp+0x30]
000074ad747dc2f1  mov r8d, 0x00
000074ad747dc2f7  lea r9, [r15+0x3A8]
000074ad747dc2fe  movaps [rdi], xmm7
000074ad747dc301  movaps [rsi], xmm2
000074ad747dc304  movaps [rdx], xmm9
000074ad747dc308  movaps [rcx], xmm11
000074ad747dc30c  mov rax, 0x5C17501CEA50
000074ad747dc316  call rax
000074ad747dc318  movaps xmm7, [rsp]
000074ad747dc31c  add rsp, 0x40
000074ad747dc320  vmovaps xmm0, [rsp]
000074ad747dc325  vmovaps xmm1, [rsp+0x10]
000074ad747dc32b  vmovaps xmm2, [rsp+0x20]
000074ad747dc331  vmovaps xmm3, [rsp+0x30]
000074ad747dc337  vmovaps xmm4, [rsp+0x40]
000074ad747dc33d  vmovaps xmm5, [rsp+0x50]
000074ad747dc343  vmovaps xmm6, [rsp+0x60]
000074ad747dc349  vmovaps xmm8, [rsp+0x70]
000074ad747dc34f  vmovaps xmm9, [rsp+0x80]
000074ad747dc358  vmovaps xmm10, [rsp+0x90]
000074ad747dc361  vmovaps xmm11, [rsp+0xA0]
000074ad747dc36a  vmovaps xmm12, [rsp+0xB0]
000074ad747dc373  vmovaps xmm13, [rsp+0xC0]
000074ad747dc37c  vmovaps xmm14, [rsp+0xD0]
000074ad747dc385  vmovaps xmm15, [rsp+0xE0]
000074ad747dc38e  add rsp, 0xF0
000074ad747dc395  pop r11
000074ad747dc397  pop r10
000074ad747dc399  pop r9
000074ad747dc39b  pop r8
000074ad747dc39d  pop rsi
000074ad747dc39e  pop rdi
000074ad747dc39f  pop rdx
000074ad747dc3a0  pop rcx
000074ad747dc3a1  pop rax
000074ad747dc3a2  add rsp, 0x08
000074ad747dc3a6  jmp 0x000074AD747DA421
000074ad747dc3ab  sub rsp, 0x08
000074ad747dc3af  push rax
000074ad747dc3b0  push rcx
000074ad747dc3b1  push rdx
000074ad747dc3b2  push rdi
000074ad747dc3b3  push rsi
000074ad747dc3b4  push r8
000074ad747dc3b6  push r9
000074ad747dc3b8  push r10
000074ad747dc3ba  push r11
000074ad747dc3bc  sub rsp, 0xF0
000074ad747dc3c3  vmovaps [rsp], xmm0
000074ad747dc3c8  vmovaps [rsp+0x10], xmm1
000074ad747dc3ce  vmovaps [rsp+0x20], xmm2
000074ad747dc3d4  vmovaps [rsp+0x30], xmm3
000074ad747dc3da  vmovaps [rsp+0x40], xmm4
000074ad747dc3e0  vmovaps [rsp+0x50], xmm5
000074ad747dc3e6  vmovaps [rsp+0x60], xmm6
000074ad747dc3ec  vmovaps [rsp+0x70], xmm7
000074ad747dc3f2  vmovaps [rsp+0x80], xmm8
000074ad747dc3fb  vmovaps [rsp+0x90], xmm10
000074ad747dc404  vmovaps [rsp+0xA0], xmm11
000074ad747dc40d  vmovaps [rsp+0xB0], xmm12
000074ad747dc416  vmovaps [rsp+0xC0], xmm13
000074ad747dc41f  vmovaps [rsp+0xD0], xmm14
000074ad747dc428  vmovaps [rsp+0xE0], xmm15
000074ad747dc431  sub rsp, 0x40
000074ad747dc435  lea rdi, [rsp]
000074ad747dc439  lea rsi, [rsp+0x10]
000074ad747dc43e  lea rdx, [rsp+0x20]
000074ad747dc443  lea rcx, [rsp+0x30]
000074ad747dc448  mov r8d, 0x00
000074ad747dc44e  lea r9, [r15+0x3A8]
000074ad747dc455  movaps [rdi], xmm9
000074ad747dc459  movaps [rsi], xmm6
000074ad747dc45c  movaps [rdx], xmm1
000074ad747dc45f  movaps [rcx], xmm11
000074ad747dc463  mov rax, 0x5C17501CEA50
000074ad747dc46d  call rax
000074ad747dc46f  movaps xmm9, [rsp]
000074ad747dc474  add rsp, 0x40
000074ad747dc478  vmovaps xmm0, [rsp]
000074ad747dc47d  vmovaps xmm1, [rsp+0x10]
000074ad747dc483  vmovaps xmm2, [rsp+0x20]
000074ad747dc489  vmovaps xmm3, [rsp+0x30]
000074ad747dc48f  vmovaps xmm4, [rsp+0x40]
000074ad747dc495  vmovaps xmm5, [rsp+0x50]
000074ad747dc49b  vmovaps xmm6, [rsp+0x60]
000074ad747dc4a1  vmovaps xmm7, [rsp+0x70]
000074ad747dc4a7  vmovaps xmm8, [rsp+0x80]
000074ad747dc4b0  vmovaps xmm10, [rsp+0x90]
000074ad747dc4b9  vmovaps xmm11, [rsp+0xA0]
000074ad747dc4c2  vmovaps xmm12, [rsp+0xB0]
000074ad747dc4cb  vmovaps xmm13, [rsp+0xC0]
000074ad747dc4d4  vmovaps xmm14, [rsp+0xD0]
000074ad747dc4dd  vmovaps xmm15, [rsp+0xE0]
000074ad747dc4e6  add rsp, 0xF0
000074ad747dc4ed  pop r11
000074ad747dc4ef  pop r10
000074ad747dc4f1  pop r9
000074ad747dc4f3  pop r8
000074ad747dc4f5  pop rsi
000074ad747dc4f6  pop rdi
000074ad747dc4f7  pop rdx
000074ad747dc4f8  pop rcx
000074ad747dc4f9  pop rax
000074ad747dc4fa  add rsp, 0x08
000074ad747dc4fe  jmp 0x000074AD747DA447
000074ad747dc503  sub rsp, 0x08
000074ad747dc507  push rax
000074ad747dc508  push rcx
000074ad747dc509  push rdx
000074ad747dc50a  push rdi
000074ad747dc50b  push rsi
000074ad747dc50c  push r8
000074ad747dc50e  push r9
000074ad747dc510  push r10
000074ad747dc512  push r11
000074ad747dc514  sub rsp, 0xF0
000074ad747dc51b  vmovaps [rsp], xmm0
000074ad747dc520  vmovaps [rsp+0x10], xmm1
000074ad747dc526  vmovaps [rsp+0x20], xmm2
000074ad747dc52c  vmovaps [rsp+0x30], xmm3
000074ad747dc532  vmovaps [rsp+0x40], xmm4
000074ad747dc538  vmovaps [rsp+0x50], xmm5
000074ad747dc53e  vmovaps [rsp+0x60], xmm6
000074ad747dc544  vmovaps [rsp+0x70], xmm7
000074ad747dc54a  vmovaps [rsp+0x80], xmm8
000074ad747dc553  vmovaps [rsp+0x90], xmm9
000074ad747dc55c  vmovaps [rsp+0xA0], xmm10
000074ad747dc565  vmovaps [rsp+0xB0], xmm12
000074ad747dc56e  vmovaps [rsp+0xC0], xmm13
000074ad747dc577  vmovaps [rsp+0xD0], xmm14
000074ad747dc580  vmovaps [rsp+0xE0], xmm15
000074ad747dc589  sub rsp, 0x40
000074ad747dc58d  lea rdi, [rsp]
000074ad747dc591  lea rsi, [rsp+0x10]
000074ad747dc596  lea rdx, [rsp+0x20]
000074ad747dc59b  lea rcx, [rsp+0x30]
000074ad747dc5a0  mov r8d, 0x00
000074ad747dc5a6  lea r9, [r15+0x3A8]
000074ad747dc5ad  movaps [rdi], xmm11
000074ad747dc5b1  movaps [rsi], xmm10
000074ad747dc5b5  movaps [rdx], xmm8
000074ad747dc5b9  movaps [rcx], xmm1
000074ad747dc5bc  mov rax, 0x5C17501CEA50
000074ad747dc5c6  call rax
000074ad747dc5c8  movaps xmm11, [rsp]
000074ad747dc5cd  add rsp, 0x40
000074ad747dc5d1  vmovaps xmm0, [rsp]
000074ad747dc5d6  vmovaps xmm1, [rsp+0x10]
000074ad747dc5dc  vmovaps xmm2, [rsp+0x20]
000074ad747dc5e2  vmovaps xmm3, [rsp+0x30]
000074ad747dc5e8  vmovaps xmm4, [rsp+0x40]
000074ad747dc5ee  vmovaps xmm5, [rsp+0x50]
000074ad747dc5f4  vmovaps xmm6, [rsp+0x60]
000074ad747dc5fa  vmovaps xmm7, [rsp+0x70]
000074ad747dc600  vmovaps xmm8, [rsp+0x80]
000074ad747dc609  vmovaps xmm9, [rsp+0x90]
000074ad747dc612  vmovaps xmm10, [rsp+0xA0]
000074ad747dc61b  vmovaps xmm12, [rsp+0xB0]
000074ad747dc624  vmovaps xmm13, [rsp+0xC0]
000074ad747dc62d  vmovaps xmm14, [rsp+0xD0]
000074ad747dc636  vmovaps xmm15, [rsp+0xE0]
000074ad747dc63f  add rsp, 0xF0
000074ad747dc646  pop r11
000074ad747dc648  pop r10
000074ad747dc64a  pop r9
000074ad747dc64c  pop r8
000074ad747dc64e  pop rsi
000074ad747dc64f  pop rdi
000074ad747dc650  pop rdx
000074ad747dc651  pop rcx
000074ad747dc652  pop rax
000074ad747dc653  add rsp, 0x08
000074ad747dc657  jmp 0x000074AD747DA46D
000074ad747dc65c  sub rsp, 0x08
000074ad747dc660  push rax
000074ad747dc661  push rcx
000074ad747dc662  push rdx
000074ad747dc663  push rdi
000074ad747dc664  push rsi
000074ad747dc665  push r8
000074ad747dc667  push r9
000074ad747dc669  push r10
000074ad747dc66b  push r11
000074ad747dc66d  sub rsp, 0xF0
000074ad747dc674  vmovaps [rsp], xmm0
000074ad747dc679  vmovaps [rsp+0x10], xmm1
000074ad747dc67f  vmovaps [rsp+0x20], xmm2
000074ad747dc685  vmovaps [rsp+0x30], xmm3
000074ad747dc68b  vmovaps [rsp+0x40], xmm4
000074ad747dc691  vmovaps [rsp+0x50], xmm5
000074ad747dc697  vmovaps [rsp+0x60], xmm6
000074ad747dc69d  vmovaps [rsp+0x70], xmm7
000074ad747dc6a3  vmovaps [rsp+0x80], xmm8
000074ad747dc6ac  vmovaps [rsp+0x90], xmm9
000074ad747dc6b5  vmovaps [rsp+0xA0], xmm11
000074ad747dc6be  vmovaps [rsp+0xB0], xmm12
000074ad747dc6c7  vmovaps [rsp+0xC0], xmm13
000074ad747dc6d0  vmovaps [rsp+0xD0], xmm14
000074ad747dc6d9  vmovaps [rsp+0xE0], xmm15
000074ad747dc6e2  sub rsp, 0x40
000074ad747dc6e6  lea rdi, [rsp]
000074ad747dc6ea  lea rsi, [rsp+0x10]
000074ad747dc6ef  lea rdx, [rsp+0x20]
000074ad747dc6f4  lea rcx, [rsp+0x30]
000074ad747dc6f9  mov r8d, 0x00
000074ad747dc6ff  lea r9, [r15+0x3A8]
000074ad747dc706  movaps [rdi], xmm10
000074ad747dc70a  movaps [rsi], xmm12
000074ad747dc70e  movaps [rdx], xmm13
000074ad747dc712  movaps [rcx], xmm1
000074ad747dc715  mov rax, 0x5C17501CEA50
000074ad747dc71f  call rax
000074ad747dc721  movaps xmm10, [rsp]
000074ad747dc726  add rsp, 0x40
000074ad747dc72a  vmovaps xmm0, [rsp]
000074ad747dc72f  vmovaps xmm1, [rsp+0x10]
000074ad747dc735  vmovaps xmm2, [rsp+0x20]
000074ad747dc73b  vmovaps xmm3, [rsp+0x30]
000074ad747dc741  vmovaps xmm4, [rsp+0x40]
000074ad747dc747  vmovaps xmm5, [rsp+0x50]
000074ad747dc74d  vmovaps xmm6, [rsp+0x60]
000074ad747dc753  vmovaps xmm7, [rsp+0x70]
000074ad747dc759  vmovaps xmm8, [rsp+0x80]
000074ad747dc762  vmovaps xmm9, [rsp+0x90]
000074ad747dc76b  vmovaps xmm11, [rsp+0xA0]
000074ad747dc774  vmovaps xmm12, [rsp+0xB0]
000074ad747dc77d  vmovaps xmm13, [rsp+0xC0]
000074ad747dc786  vmovaps xmm14, [rsp+0xD0]
000074ad747dc78f  vmovaps xmm15, [rsp+0xE0]
000074ad747dc798  add rsp, 0xF0
000074ad747dc79f  pop r11
000074ad747dc7a1  pop r10
000074ad747dc7a3  pop r9
000074ad747dc7a5  pop r8
000074ad747dc7a7  pop rsi
000074ad747dc7a8  pop rdi
000074ad747dc7a9  pop rdx
000074ad747dc7aa  pop rcx
000074ad747dc7ab  pop rax
000074ad747dc7ac  add rsp, 0x08
000074ad747dc7b0  jmp 0x000074AD747DA493
000074ad747dc7b5  call 0x000074AD745FF430
000074ad747dc7ba  jmp 0x000074AD747DA49D
000074ad747dc7bf  call 0x000074AD7460C260
000074ad747dc7c4  jmp 0x000074AD747DA4A7
000074ad747dc7c9  sub rsp, 0x08
000074ad747dc7cd  push rax
000074ad747dc7ce  push rcx
000074ad747dc7cf  push rdx
000074ad747dc7d0  push rdi
000074ad747dc7d1  push rsi
000074ad747dc7d2  push r8
000074ad747dc7d4  push r9
000074ad747dc7d6  push r10
000074ad747dc7d8  push r11
000074ad747dc7da  sub rsp, 0xF0
000074ad747dc7e1  vmovaps [rsp], xmm0
000074ad747dc7e6  vmovaps [rsp+0x10], xmm1
000074ad747dc7ec  vmovaps [rsp+0x20], xmm2
000074ad747dc7f2  vmovaps [rsp+0x30], xmm3
000074ad747dc7f8  vmovaps [rsp+0x40], xmm4
000074ad747dc7fe  vmovaps [rsp+0x50], xmm5
000074ad747dc804  vmovaps [rsp+0x60], xmm6
000074ad747dc80a  vmovaps [rsp+0x70], xmm7
000074ad747dc810  vmovaps [rsp+0x80], xmm9
000074ad747dc819  vmovaps [rsp+0x90], xmm10
000074ad747dc822  vmovaps [rsp+0xA0], xmm11
000074ad747dc82b  vmovaps [rsp+0xB0], xmm12
000074ad747dc834  vmovaps [rsp+0xC0], xmm13
000074ad747dc83d  vmovaps [rsp+0xD0], xmm14
000074ad747dc846  vmovaps [rsp+0xE0], xmm15
000074ad747dc84f  sub rsp, 0x40
000074ad747dc853  lea rdi, [rsp]
000074ad747dc857  lea rsi, [rsp+0x10]
000074ad747dc85c  lea rdx, [rsp+0x20]
000074ad747dc861  lea rcx, [rsp+0x30]
000074ad747dc866  mov r8d, 0x00
000074ad747dc86c  lea r9, [r15+0x3A8]
000074ad747dc873  movaps [rdi], xmm8
000074ad747dc877  movaps [rsi], xmm7
000074ad747dc87a  movaps [rdx], xmm4
000074ad747dc87d  movaps [rcx], xmm12
000074ad747dc881  mov rax, 0x5C17501CEA50
000074ad747dc88b  call rax
000074ad747dc88d  movaps xmm8, [rsp]
000074ad747dc892  add rsp, 0x40
000074ad747dc896  vmovaps xmm0, [rsp]
000074ad747dc89b  vmovaps xmm1, [rsp+0x10]
000074ad747dc8a1  vmovaps xmm2, [rsp+0x20]
000074ad747dc8a7  vmovaps xmm3, [rsp+0x30]
000074ad747dc8ad  vmovaps xmm4, [rsp+0x40]
000074ad747dc8b3  vmovaps xmm5, [rsp+0x50]
000074ad747dc8b9  vmovaps xmm6, [rsp+0x60]
000074ad747dc8bf  vmovaps xmm7, [rsp+0x70]
000074ad747dc8c5  vmovaps xmm9, [rsp+0x80]
000074ad747dc8ce  vmovaps xmm10, [rsp+0x90]
000074ad747dc8d7  vmovaps xmm11, [rsp+0xA0]
000074ad747dc8e0  vmovaps xmm12, [rsp+0xB0]
000074ad747dc8e9  vmovaps xmm13, [rsp+0xC0]
000074ad747dc8f2  vmovaps xmm14, [rsp+0xD0]
000074ad747dc8fb  vmovaps xmm15, [rsp+0xE0]
000074ad747dc904  add rsp, 0xF0
000074ad747dc90b  pop r11
000074ad747dc90d  pop r10
000074ad747dc90f  pop r9
000074ad747dc911  pop r8
000074ad747dc913  pop rsi
000074ad747dc914  pop rdi
000074ad747dc915  pop rdx
000074ad747dc916  pop rcx
000074ad747dc917  pop rax
000074ad747dc918  add rsp, 0x08
000074ad747dc91c  jmp 0x000074AD747DA4D0
000074ad747dc921  sub rsp, 0x08
000074ad747dc925  push rax
000074ad747dc926  push rcx
000074ad747dc927  push rdx
000074ad747dc928  push rdi
000074ad747dc929  push rsi
000074ad747dc92a  push r8
000074ad747dc92c  push r9
000074ad747dc92e  push r10
000074ad747dc930  push r11
000074ad747dc932  sub rsp, 0xF0
000074ad747dc939  vmovaps [rsp], xmm0
000074ad747dc93e  vmovaps [rsp+0x10], xmm1
000074ad747dc944  vmovaps [rsp+0x20], xmm2
000074ad747dc94a  vmovaps [rsp+0x30], xmm3
000074ad747dc950  vmovaps [rsp+0x40], xmm4
000074ad747dc956  vmovaps [rsp+0x50], xmm5
000074ad747dc95c  vmovaps [rsp+0x60], xmm6
000074ad747dc962  vmovaps [rsp+0x70], xmm8
000074ad747dc968  vmovaps [rsp+0x80], xmm9
000074ad747dc971  vmovaps [rsp+0x90], xmm10
000074ad747dc97a  vmovaps [rsp+0xA0], xmm11
000074ad747dc983  vmovaps [rsp+0xB0], xmm12
000074ad747dc98c  vmovaps [rsp+0xC0], xmm13
000074ad747dc995  vmovaps [rsp+0xD0], xmm14
000074ad747dc99e  vmovaps [rsp+0xE0], xmm15
000074ad747dc9a7  sub rsp, 0x40
000074ad747dc9ab  lea rdi, [rsp]
000074ad747dc9af  lea rsi, [rsp+0x10]
000074ad747dc9b4  lea rdx, [rsp+0x20]
000074ad747dc9b9  lea rcx, [rsp+0x30]
000074ad747dc9be  mov r8d, 0x00
000074ad747dc9c4  lea r9, [r15+0x3A8]
000074ad747dc9cb  movaps [rdi], xmm7
000074ad747dc9ce  movaps [rsi], xmm9
000074ad747dc9d2  movaps [rdx], xmm14
000074ad747dc9d6  movaps [rcx], xmm12
000074ad747dc9da  mov rax, 0x5C17501CEA50
000074ad747dc9e4  call rax
000074ad747dc9e6  movaps xmm7, [rsp]
000074ad747dc9ea  add rsp, 0x40
000074ad747dc9ee  vmovaps xmm0, [rsp]
000074ad747dc9f3  vmovaps xmm1, [rsp+0x10]
000074ad747dc9f9  vmovaps xmm2, [rsp+0x20]
000074ad747dc9ff  vmovaps xmm3, [rsp+0x30]
000074ad747dca05  vmovaps xmm4, [rsp+0x40]
000074ad747dca0b  vmovaps xmm5, [rsp+0x50]
000074ad747dca11  vmovaps xmm6, [rsp+0x60]
000074ad747dca17  vmovaps xmm8, [rsp+0x70]
000074ad747dca1d  vmovaps xmm9, [rsp+0x80]
000074ad747dca26  vmovaps xmm10, [rsp+0x90]
000074ad747dca2f  vmovaps xmm11, [rsp+0xA0]
000074ad747dca38  vmovaps xmm12, [rsp+0xB0]
000074ad747dca41  vmovaps xmm13, [rsp+0xC0]
000074ad747dca4a  vmovaps xmm14, [rsp+0xD0]
000074ad747dca53  vmovaps xmm15, [rsp+0xE0]
000074ad747dca5c  add rsp, 0xF0
000074ad747dca63  pop r11
000074ad747dca65  pop r10
000074ad747dca67  pop r9
000074ad747dca69  pop r8
000074ad747dca6b  pop rsi
000074ad747dca6c  pop rdi
000074ad747dca6d  pop rdx
000074ad747dca6e  pop rcx
000074ad747dca6f  pop rax
000074ad747dca70  add rsp, 0x08
000074ad747dca74  jmp 0x000074AD747DA4F8
000074ad747dca79  sub rsp, 0x08
000074ad747dca7d  push rax
000074ad747dca7e  push rcx
000074ad747dca7f  push rdx
000074ad747dca80  push rdi
000074ad747dca81  push rsi
000074ad747dca82  push r8
000074ad747dca84  push r9
000074ad747dca86  push r10
000074ad747dca88  push r11
000074ad747dca8a  sub rsp, 0xF0
000074ad747dca91  vmovaps [rsp], xmm0
000074ad747dca96  vmovaps [rsp+0x10], xmm1
000074ad747dca9c  vmovaps [rsp+0x20], xmm2
000074ad747dcaa2  vmovaps [rsp+0x30], xmm3
000074ad747dcaa8  vmovaps [rsp+0x40], xmm4
000074ad747dcaae  vmovaps [rsp+0x50], xmm5
000074ad747dcab4  vmovaps [rsp+0x60], xmm6
000074ad747dcaba  vmovaps [rsp+0x70], xmm7
000074ad747dcac0  vmovaps [rsp+0x80], xmm8
000074ad747dcac9  vmovaps [rsp+0x90], xmm9
000074ad747dcad2  vmovaps [rsp+0xA0], xmm10
000074ad747dcadb  vmovaps [rsp+0xB0], xmm11
000074ad747dcae4  vmovaps [rsp+0xC0], xmm13
000074ad747dcaed  vmovaps [rsp+0xD0], xmm14
000074ad747dcaf6  vmovaps [rsp+0xE0], xmm15
000074ad747dcaff  sub rsp, 0x40
000074ad747dcb03  lea rdi, [rsp]
000074ad747dcb07  lea rsi, [rsp+0x10]
000074ad747dcb0c  lea rdx, [rsp+0x20]
000074ad747dcb11  lea rcx, [rsp+0x30]
000074ad747dcb16  mov r8d, 0x00
000074ad747dcb1c  lea r9, [r15+0x3A8]
000074ad747dcb23  movaps [rdi], xmm12
000074ad747dcb27  movaps [rsi], xmm11
000074ad747dcb2b  movaps [rdx], xmm15
000074ad747dcb2f  movaps [rcx], xmm14
000074ad747dcb33  mov rax, 0x5C17501CEA50
000074ad747dcb3d  call rax
000074ad747dcb3f  movaps xmm12, [rsp]
000074ad747dcb44  add rsp, 0x40
000074ad747dcb48  vmovaps xmm0, [rsp]
000074ad747dcb4d  vmovaps xmm1, [rsp+0x10]
000074ad747dcb53  vmovaps xmm2, [rsp+0x20]
000074ad747dcb59  vmovaps xmm3, [rsp+0x30]
000074ad747dcb5f  vmovaps xmm4, [rsp+0x40]
000074ad747dcb65  vmovaps xmm5, [rsp+0x50]
000074ad747dcb6b  vmovaps xmm6, [rsp+0x60]
000074ad747dcb71  vmovaps xmm7, [rsp+0x70]
000074ad747dcb77  vmovaps xmm8, [rsp+0x80]
000074ad747dcb80  vmovaps xmm9, [rsp+0x90]
000074ad747dcb89  vmovaps xmm10, [rsp+0xA0]
000074ad747dcb92  vmovaps xmm11, [rsp+0xB0]
000074ad747dcb9b  vmovaps xmm13, [rsp+0xC0]
000074ad747dcba4  vmovaps xmm14, [rsp+0xD0]
000074ad747dcbad  vmovaps xmm15, [rsp+0xE0]
000074ad747dcbb6  add rsp, 0xF0
000074ad747dcbbd  pop r11
000074ad747dcbbf  pop r10
000074ad747dcbc1  pop r9
000074ad747dcbc3  pop r8
000074ad747dcbc5  pop rsi
000074ad747dcbc6  pop rdi
000074ad747dcbc7  pop rdx
000074ad747dcbc8  pop rcx
000074ad747dcbc9  pop rax
000074ad747dcbca  add rsp, 0x08
000074ad747dcbce  jmp 0x000074AD747DA521
000074ad747dcbd3  sub rsp, 0x08
000074ad747dcbd7  push rax
000074ad747dcbd8  push rcx
000074ad747dcbd9  push rdx
000074ad747dcbda  push rdi
000074ad747dcbdb  push rsi
000074ad747dcbdc  push r8
000074ad747dcbde  push r9
000074ad747dcbe0  push r10
000074ad747dcbe2  push r11
000074ad747dcbe4  sub rsp, 0xF0
000074ad747dcbeb  vmovaps [rsp], xmm0
000074ad747dcbf0  vmovaps [rsp+0x10], xmm1
000074ad747dcbf6  vmovaps [rsp+0x20], xmm2
000074ad747dcbfc  vmovaps [rsp+0x30], xmm3
000074ad747dcc02  vmovaps [rsp+0x40], xmm4
000074ad747dcc08  vmovaps [rsp+0x50], xmm5
000074ad747dcc0e  vmovaps [rsp+0x60], xmm6
000074ad747dcc14  vmovaps [rsp+0x70], xmm7
000074ad747dcc1a  vmovaps [rsp+0x80], xmm8
000074ad747dcc23  vmovaps [rsp+0x90], xmm9
000074ad747dcc2c  vmovaps [rsp+0xA0], xmm10
000074ad747dcc35  vmovaps [rsp+0xB0], xmm12
000074ad747dcc3e  vmovaps [rsp+0xC0], xmm13
000074ad747dcc47  vmovaps [rsp+0xD0], xmm14
000074ad747dcc50  vmovaps [rsp+0xE0], xmm15
000074ad747dcc59  sub rsp, 0x40
000074ad747dcc5d  lea rdi, [rsp]
000074ad747dcc61  lea rsi, [rsp+0x10]
000074ad747dcc66  lea rdx, [rsp+0x20]
000074ad747dcc6b  lea rcx, [rsp+0x30]
000074ad747dcc70  mov r8d, 0x00
000074ad747dcc76  lea r9, [r15+0x3A8]
000074ad747dcc7d  movaps [rdi], xmm11
000074ad747dcc81  movaps [rsi], xmm10
000074ad747dcc85  movaps [rdx], xmm13
000074ad747dcc89  movaps [rcx], xmm15
000074ad747dcc8d  mov rax, 0x5C17501CEA50
000074ad747dcc97  call rax
000074ad747dcc99  movaps xmm11, [rsp]
000074ad747dcc9e  add rsp, 0x40
000074ad747dcca2  vmovaps xmm0, [rsp]
000074ad747dcca7  vmovaps xmm1, [rsp+0x10]
000074ad747dccad  vmovaps xmm2, [rsp+0x20]
000074ad747dccb3  vmovaps xmm3, [rsp+0x30]
000074ad747dccb9  vmovaps xmm4, [rsp+0x40]
000074ad747dccbf  vmovaps xmm5, [rsp+0x50]
000074ad747dccc5  vmovaps xmm6, [rsp+0x60]
000074ad747dcccb  vmovaps xmm7, [rsp+0x70]
000074ad747dccd1  vmovaps xmm8, [rsp+0x80]
000074ad747dccda  vmovaps xmm9, [rsp+0x90]
000074ad747dcce3  vmovaps xmm10, [rsp+0xA0]
000074ad747dccec  vmovaps xmm12, [rsp+0xB0]
000074ad747dccf5  vmovaps xmm13, [rsp+0xC0]
000074ad747dccfe  vmovaps xmm14, [rsp+0xD0]
000074ad747dcd07  vmovaps xmm15, [rsp+0xE0]
000074ad747dcd10  add rsp, 0xF0
000074ad747dcd17  pop r11
000074ad747dcd19  pop r10
000074ad747dcd1b  pop r9
000074ad747dcd1d  pop r8
000074ad747dcd1f  pop rsi
000074ad747dcd20  pop rdi
000074ad747dcd21  pop rdx
000074ad747dcd22  pop rcx
000074ad747dcd23  pop rax
000074ad747dcd24  add rsp, 0x08
000074ad747dcd28  jmp 0x000074AD747DA54A
000074ad747dcd2d  call 0x000074AD7460E760
000074ad747dcd32  jmp 0x000074AD747DA557
000074ad747dcd37  call 0x000074AD7460D4E0
000074ad747dcd3c  jmp 0x000074AD747DA564
000074ad747dcd41  sub rsp, 0x08
000074ad747dcd45  push rax
000074ad747dcd46  push rcx
000074ad747dcd47  push rdx
000074ad747dcd48  push rdi
000074ad747dcd49  push rsi
000074ad747dcd4a  push r8
000074ad747dcd4c  push r9
000074ad747dcd4e  push r10
000074ad747dcd50  push r11
000074ad747dcd52  sub rsp, 0xF0
000074ad747dcd59  vmovaps [rsp], xmm0
000074ad747dcd5e  vmovaps [rsp+0x10], xmm1
000074ad747dcd64  vmovaps [rsp+0x20], xmm2
000074ad747dcd6a  vmovaps [rsp+0x30], xmm3
000074ad747dcd70  vmovaps [rsp+0x40], xmm4
000074ad747dcd76  vmovaps [rsp+0x50], xmm5
000074ad747dcd7c  vmovaps [rsp+0x60], xmm6
000074ad747dcd82  vmovaps [rsp+0x70], xmm7
000074ad747dcd88  vmovaps [rsp+0x80], xmm8
000074ad747dcd91  vmovaps [rsp+0x90], xmm9
000074ad747dcd9a  vmovaps [rsp+0xA0], xmm11
000074ad747dcda3  vmovaps [rsp+0xB0], xmm12
000074ad747dcdac  vmovaps [rsp+0xC0], xmm13
000074ad747dcdb5  vmovaps [rsp+0xD0], xmm14
000074ad747dcdbe  vmovaps [rsp+0xE0], xmm15
000074ad747dcdc7  sub rsp, 0x40
000074ad747dcdcb  lea rdi, [rsp]
000074ad747dcdcf  lea rsi, [rsp+0x10]
000074ad747dcdd4  lea rdx, [rsp+0x20]
000074ad747dcdd9  lea rcx, [rsp+0x30]
000074ad747dcdde  mov r8d, 0x00
000074ad747dcde4  lea r9, [r15+0x3A8]
000074ad747dcdeb  movaps [rdi], xmm10
000074ad747dcdef  movaps [rsi], xmm8
000074ad747dcdf3  movaps [rdx], xmm1
000074ad747dcdf6  movaps [rcx], xmm13
000074ad747dcdfa  mov rax, 0x5C17501CEA50
000074ad747dce04  call rax
000074ad747dce06  movaps xmm10, [rsp]
000074ad747dce0b  add rsp, 0x40
000074ad747dce0f  vmovaps xmm0, [rsp]
000074ad747dce14  vmovaps xmm1, [rsp+0x10]
000074ad747dce1a  vmovaps xmm2, [rsp+0x20]
000074ad747dce20  vmovaps xmm3, [rsp+0x30]
000074ad747dce26  vmovaps xmm4, [rsp+0x40]
000074ad747dce2c  vmovaps xmm5, [rsp+0x50]
000074ad747dce32  vmovaps xmm6, [rsp+0x60]
000074ad747dce38  vmovaps xmm7, [rsp+0x70]
000074ad747dce3e  vmovaps xmm8, [rsp+0x80]
000074ad747dce47  vmovaps xmm9, [rsp+0x90]
000074ad747dce50  vmovaps xmm11, [rsp+0xA0]
000074ad747dce59  vmovaps xmm12, [rsp+0xB0]
000074ad747dce62  vmovaps xmm13, [rsp+0xC0]
000074ad747dce6b  vmovaps xmm14, [rsp+0xD0]
000074ad747dce74  vmovaps xmm15, [rsp+0xE0]
000074ad747dce7d  add rsp, 0xF0
000074ad747dce84  pop r11
000074ad747dce86  pop r10
000074ad747dce88  pop r9
000074ad747dce8a  pop r8
000074ad747dce8c  pop rsi
000074ad747dce8d  pop rdi
000074ad747dce8e  pop rdx
000074ad747dce8f  pop rcx
000074ad747dce90  pop rax
000074ad747dce91  add rsp, 0x08
000074ad747dce95  jmp 0x000074AD747DA59A
000074ad747dce9a  call 0x000074AD745FF430
000074ad747dce9f  jmp 0x000074AD747DA5AC
000074ad747dcea4  sub rsp, 0x08
000074ad747dcea8  push rax
000074ad747dcea9  push rcx
000074ad747dceaa  push rdx
000074ad747dceab  push rdi
000074ad747dceac  push rsi
000074ad747dcead  push r8
000074ad747dceaf  push r9
000074ad747dceb1  push r10
000074ad747dceb3  push r11
000074ad747dceb5  sub rsp, 0xF0
000074ad747dcebc  vmovaps [rsp], xmm0
000074ad747dcec1  vmovaps [rsp+0x10], xmm1
000074ad747dcec7  vmovaps [rsp+0x20], xmm2
000074ad747dcecd  vmovaps [rsp+0x30], xmm3
000074ad747dced3  vmovaps [rsp+0x40], xmm4
000074ad747dced9  vmovaps [rsp+0x50], xmm5
000074ad747dcedf  vmovaps [rsp+0x60], xmm6
000074ad747dcee5  vmovaps [rsp+0x70], xmm7
000074ad747dceeb  vmovaps [rsp+0x80], xmm8
000074ad747dcef4  vmovaps [rsp+0x90], xmm10
000074ad747dcefd  vmovaps [rsp+0xA0], xmm11
000074ad747dcf06  vmovaps [rsp+0xB0], xmm12
000074ad747dcf0f  vmovaps [rsp+0xC0], xmm13
000074ad747dcf18  vmovaps [rsp+0xD0], xmm14
000074ad747dcf21  vmovaps [rsp+0xE0], xmm15
000074ad747dcf2a  sub rsp, 0x40
000074ad747dcf2e  lea rdi, [rsp]
000074ad747dcf32  lea rsi, [rsp+0x10]
000074ad747dcf37  lea rdx, [rsp+0x20]
000074ad747dcf3c  lea rcx, [rsp+0x30]
000074ad747dcf41  mov r8d, 0x00
000074ad747dcf47  lea r9, [r15+0x3A8]
000074ad747dcf4e  movaps [rdi], xmm9
000074ad747dcf52  movaps [rsi], xmm7
000074ad747dcf55  movaps [rdx], xmm14
000074ad747dcf59  movaps [rcx], xmm13
000074ad747dcf5d  mov rax, 0x5C17501CEA50
000074ad747dcf67  call rax
000074ad747dcf69  movaps xmm9, [rsp]
000074ad747dcf6e  add rsp, 0x40
000074ad747dcf72  vmovaps xmm0, [rsp]
000074ad747dcf77  vmovaps xmm1, [rsp+0x10]
000074ad747dcf7d  vmovaps xmm2, [rsp+0x20]
000074ad747dcf83  vmovaps xmm3, [rsp+0x30]
000074ad747dcf89  vmovaps xmm4, [rsp+0x40]
000074ad747dcf8f  vmovaps xmm5, [rsp+0x50]
000074ad747dcf95  vmovaps xmm6, [rsp+0x60]
000074ad747dcf9b  vmovaps xmm7, [rsp+0x70]
000074ad747dcfa1  vmovaps xmm8, [rsp+0x80]
000074ad747dcfaa  vmovaps xmm10, [rsp+0x90]
000074ad747dcfb3  vmovaps xmm11, [rsp+0xA0]
000074ad747dcfbc  vmovaps xmm12, [rsp+0xB0]
000074ad747dcfc5  vmovaps xmm13, [rsp+0xC0]
000074ad747dcfce  vmovaps xmm14, [rsp+0xD0]
000074ad747dcfd7  vmovaps xmm15, [rsp+0xE0]
000074ad747dcfe0  add rsp, 0xF0
000074ad747dcfe7  pop r11
000074ad747dcfe9  pop r10
000074ad747dcfeb  pop r9
000074ad747dcfed  pop r8
000074ad747dcfef  pop rsi
000074ad747dcff0  pop rdi
000074ad747dcff1  pop rdx
000074ad747dcff2  pop rcx
000074ad747dcff3  pop rax
000074ad747dcff4  add rsp, 0x08
000074ad747dcff8  jmp 0x000074AD747DA5DA
000074ad747dcffd  sub rsp, 0x08
000074ad747dd001  push rax
000074ad747dd002  push rcx
000074ad747dd003  push rdx
000074ad747dd004  push rdi
000074ad747dd005  push rsi
000074ad747dd006  push r8
000074ad747dd008  push r9
000074ad747dd00a  push r10
000074ad747dd00c  push r11
000074ad747dd00e  sub rsp, 0xF0
000074ad747dd015  vmovaps [rsp], xmm0
000074ad747dd01a  vmovaps [rsp+0x10], xmm1
000074ad747dd020  vmovaps [rsp+0x20], xmm2
000074ad747dd026  vmovaps [rsp+0x30], xmm3
000074ad747dd02c  vmovaps [rsp+0x40], xmm4
000074ad747dd032  vmovaps [rsp+0x50], xmm5
000074ad747dd038  vmovaps [rsp+0x60], xmm6
000074ad747dd03e  vmovaps [rsp+0x70], xmm7
000074ad747dd044  vmovaps [rsp+0x80], xmm8
000074ad747dd04d  vmovaps [rsp+0x90], xmm9
000074ad747dd056  vmovaps [rsp+0xA0], xmm10
000074ad747dd05f  vmovaps [rsp+0xB0], xmm11
000074ad747dd068  vmovaps [rsp+0xC0], xmm12
000074ad747dd071  vmovaps [rsp+0xD0], xmm14
000074ad747dd07a  vmovaps [rsp+0xE0], xmm15
000074ad747dd083  sub rsp, 0x40
000074ad747dd087  lea rdi, [rsp]
000074ad747dd08b  lea rsi, [rsp+0x10]
000074ad747dd090  lea rdx, [rsp+0x20]
000074ad747dd095  lea rcx, [rsp+0x30]
000074ad747dd09a  mov r8d, 0x00
000074ad747dd0a0  lea r9, [r15+0x3A8]
000074ad747dd0a7  movaps [rdi], xmm13
000074ad747dd0ab  movaps [rsi], xmm12
000074ad747dd0af  movaps [rdx], xmm15
000074ad747dd0b3  movaps [rcx], xmm14
000074ad747dd0b7  mov rax, 0x5C17501CEA50
000074ad747dd0c1  call rax
000074ad747dd0c3  movaps xmm13, [rsp]
000074ad747dd0c8  add rsp, 0x40
000074ad747dd0cc  vmovaps xmm0, [rsp]
000074ad747dd0d1  vmovaps xmm1, [rsp+0x10]
000074ad747dd0d7  vmovaps xmm2, [rsp+0x20]
000074ad747dd0dd  vmovaps xmm3, [rsp+0x30]
000074ad747dd0e3  vmovaps xmm4, [rsp+0x40]
000074ad747dd0e9  vmovaps xmm5, [rsp+0x50]
000074ad747dd0ef  vmovaps xmm6, [rsp+0x60]
000074ad747dd0f5  vmovaps xmm7, [rsp+0x70]
000074ad747dd0fb  vmovaps xmm8, [rsp+0x80]
000074ad747dd104  vmovaps xmm9, [rsp+0x90]
000074ad747dd10d  vmovaps xmm10, [rsp+0xA0]
000074ad747dd116  vmovaps xmm11, [rsp+0xB0]
000074ad747dd11f  vmovaps xmm12, [rsp+0xC0]
000074ad747dd128  vmovaps xmm14, [rsp+0xD0]
000074ad747dd131  vmovaps xmm15, [rsp+0xE0]
000074ad747dd13a  add rsp, 0xF0
000074ad747dd141  pop r11
000074ad747dd143  pop r10
000074ad747dd145  pop r9
000074ad747dd147  pop r8
000074ad747dd149  pop rsi
000074ad747dd14a  pop rdi
000074ad747dd14b  pop rdx
000074ad747dd14c  pop rcx
000074ad747dd14d  pop rax
000074ad747dd14e  add rsp, 0x08
000074ad747dd152  jmp 0x000074AD747DA608
000074ad747dd157  sub rsp, 0x08
000074ad747dd15b  push rax
000074ad747dd15c  push rcx
000074ad747dd15d  push rdx
000074ad747dd15e  push rdi
000074ad747dd15f  push rsi
000074ad747dd160  push r8
000074ad747dd162  push r9
000074ad747dd164  push r10
000074ad747dd166  push r11
000074ad747dd168  sub rsp, 0xF0
000074ad747dd16f  vmovaps [rsp], xmm0
000074ad747dd174  vmovaps [rsp+0x10], xmm1
000074ad747dd17a  vmovaps [rsp+0x20], xmm2
000074ad747dd180  vmovaps [rsp+0x30], xmm3
000074ad747dd186  vmovaps [rsp+0x40], xmm4
000074ad747dd18c  vmovaps [rsp+0x50], xmm5
000074ad747dd192  vmovaps [rsp+0x60], xmm6
000074ad747dd198  vmovaps [rsp+0x70], xmm7
000074ad747dd19e  vmovaps [rsp+0x80], xmm8
000074ad747dd1a7  vmovaps [rsp+0x90], xmm9
000074ad747dd1b0  vmovaps [rsp+0xA0], xmm10
000074ad747dd1b9  vmovaps [rsp+0xB0], xmm11
000074ad747dd1c2  vmovaps [rsp+0xC0], xmm12
000074ad747dd1cb  vmovaps [rsp+0xD0], xmm13
000074ad747dd1d4  vmovaps [rsp+0xE0], xmm15
000074ad747dd1dd  sub rsp, 0x40
000074ad747dd1e1  lea rdi, [rsp]
000074ad747dd1e5  lea rsi, [rsp+0x10]
000074ad747dd1ea  lea rdx, [rsp+0x20]
000074ad747dd1ef  lea rcx, [rsp+0x30]
000074ad747dd1f4  mov r8d, 0x00
000074ad747dd1fa  lea r9, [r15+0x3A8]
000074ad747dd201  movaps [rdi], xmm14
000074ad747dd205  movaps [rsi], xmm11
000074ad747dd209  movaps [rdx], xmm1
000074ad747dd20c  movaps [rcx], xmm15
000074ad747dd210  mov rax, 0x5C17501CEA50
000074ad747dd21a  call rax
000074ad747dd21c  movaps xmm14, [rsp]
000074ad747dd221  add rsp, 0x40
000074ad747dd225  vmovaps xmm0, [rsp]
000074ad747dd22a  vmovaps xmm1, [rsp+0x10]
000074ad747dd230  vmovaps xmm2, [rsp+0x20]
000074ad747dd236  vmovaps xmm3, [rsp+0x30]
000074ad747dd23c  vmovaps xmm4, [rsp+0x40]
000074ad747dd242  vmovaps xmm5, [rsp+0x50]
000074ad747dd248  vmovaps xmm6, [rsp+0x60]
000074ad747dd24e  vmovaps xmm7, [rsp+0x70]
000074ad747dd254  vmovaps xmm8, [rsp+0x80]
000074ad747dd25d  vmovaps xmm9, [rsp+0x90]
000074ad747dd266  vmovaps xmm10, [rsp+0xA0]
000074ad747dd26f  vmovaps xmm11, [rsp+0xB0]
000074ad747dd278  vmovaps xmm12, [rsp+0xC0]
000074ad747dd281  vmovaps xmm13, [rsp+0xD0]
000074ad747dd28a  vmovaps xmm15, [rsp+0xE0]
000074ad747dd293  add rsp, 0xF0
000074ad747dd29a  pop r11
000074ad747dd29c  pop r10
000074ad747dd29e  pop r9
000074ad747dd2a0  pop r8
000074ad747dd2a2  pop rsi
000074ad747dd2a3  pop rdi
000074ad747dd2a4  pop rdx
000074ad747dd2a5  pop rcx
000074ad747dd2a6  pop rax
000074ad747dd2a7  add rsp, 0x08
000074ad747dd2ab  jmp 0x000074AD747DA636
000074ad747dd2b0  call 0x000074AD746079B0
000074ad747dd2b5  jmp 0x000074AD747DA64C
000074ad747dd2ba  call 0x000074AD746E3440
000074ad747dd2bf  jmp 0x000074AD747DA656
000074ad747dd2c4  call 0x000074AD746DFCE0
000074ad747dd2c9  jmp 0x000074AD747DA660
000074ad747dd2ce  call 0x000074AD746E46C0
000074ad747dd2d3  jmp 0x000074AD747DA66A
000074ad747dd2d8  int3
000074ad747dd2d9  nop [rax], eax
000074ad747dd2e0  mov qword ptr [r15+0x40], 0x430000
000074ad747dd2e8  mov eax, 0x430C50
000074ad747dd2ed  mov r14, [r13+rax*1]
000074ad747dd2f2  movq xmm1, r14
000074ad747dd2f7  mov rax, [r15+0x50]
000074ad747dd2fb  movups xmm15, [r13+rax*1]
000074ad747dd301  movaps [r15+0x120], xmm15
000074ad747dd309  mov qword ptr [r15+0x48], 0x10
000074ad747dd311  xor eax, eax
000074ad747dd313  mov r14d, 0x10
000074ad747dd319  mov r12d, 0x200
000074ad747dd31f  cmp r14, r12
000074ad747dd322  cmc
000074ad747dd323  lahf
000074ad747dd324  seto al
000074ad747dd327  mov [r15+0x108], eax
000074ad747dd32e  pextrq rax, xmm15, 0x01
000074ad747dd335  movq xmm14, rax
000074ad747dd33a  movaps [r15+0x130], xmm14
000074ad747dd342  movq rax, xmm1
000074ad747dd347  movq r14, xmm15
000074ad747dd34c  vmovq xmm1, rax
000074ad747dd351  vmovq xmm15, r14
000074ad747dd356  movaps xmm13, xmm1
000074ad747dd35a  addsd xmm13, xmm15
000074ad747dd35f  ucomisd xmm13, xmm13
000074ad747dd364  jp 0x000074AD747DD423
000074ad747dd36a  movq xmm13, xmm13
000074ad747dd36f  movq rax, xmm13
000074ad747dd374  movq r14, xmm14
000074ad747dd379  vmovq xmm1, rax
000074ad747dd37e  vmovq xmm15, r14
000074ad747dd383  movaps xmm14, xmm1
000074ad747dd387  addsd xmm14, xmm15
000074ad747dd38c  ucomisd xmm14, xmm14
000074ad747dd391  jp 0x000074AD747DD46B
000074ad747dd397  movq xmm14, xmm14
000074ad747dd39c  movaps [r15+0x110], xmm14
000074ad747dd3a4  mov eax, [r15+0x108]
000074ad747dd3ab  sahf
000074ad747dd3ac  jnz 0x000074AD747DD3DE
000074ad747dd3ae  cmp dword ptr [r15+0x318], 0x00
000074ad747dd3b6  jz 0x000074AD747DD680
000074ad747dd3bc  nop [rax+rax*1], ax
000074ad747dd3c5  nop [rax+rax*1], eax
000074ad747dd3cd  mov eax, 0x410698
000074ad747dd3d2  mov [r15+0x100], rax
000074ad747dd3d9  jmp 0x000074AD745FE110
000074ad747dd3de  cmp dword ptr [r15+0x318], 0x00
000074ad747dd3e6  jz 0x000074AD747DD4C0
000074ad747dd3ec  nop [rax+rax*1], ax
000074ad747dd3f5  nop [rax+rax*1], eax
000074ad747dd3fd  mov eax, 0x41067C
000074ad747dd402  mov [r15+0x100], rax
000074ad747dd409  jmp 0x000074AD745FE110
000074ad747dd40e  int3
000074ad747dd40f  call 0x000074AD7460DC20
000074ad747dd414  jmp 0x000074AD747DD2F2
000074ad747dd419  call 0x000074AD7460E760
000074ad747dd41e  jmp 0x000074AD747DD301
000074ad747dd423  ucomisd xmm1, xmm15
000074ad747dd428  jp 0x000074AD747DD437
000074ad747dd42a  movaps xmm13, [0x000074AD743FE060]
000074ad747dd432  jmp 0x000074AD747DD36A
000074ad747dd437  vxorps xmm0, xmm1, xmm15
000074ad747dd43c  pextrw eax, xmm0, 0x03
000074ad747dd441  and eax, 0x7FF8
000074ad747dd446  cmp eax, 0x08
000074ad747dd449  jnz 0x000074AD747DD36A
000074ad747dd44f  movq rax, xmm15
000074ad747dd454  shl rax, 0x0D
000074ad747dd458  jbe 0x000074AD747DD36A
000074ad747dd45e  vorps xmm13, xmm15, [0x000074AD743FE070]
000074ad747dd466  jmp 0x000074AD747DD36A
000074ad747dd46b  ucomisd xmm1, xmm15
000074ad747dd470  jp 0x000074AD747DD47F
000074ad747dd472  movaps xmm14, [0x000074AD743FE060]
000074ad747dd47a  jmp 0x000074AD747DD397
000074ad747dd47f  vxorps xmm0, xmm1, xmm15
000074ad747dd484  pextrw eax, xmm0, 0x03
000074ad747dd489  and eax, 0x7FF8
000074ad747dd48e  cmp eax, 0x08
000074ad747dd491  jnz 0x000074AD747DD397
000074ad747dd497  movq rax, xmm15
000074ad747dd49c  shl rax, 0x0D
000074ad747dd4a0  jbe 0x000074AD747DD397
000074ad747dd4a6  vorps xmm14, xmm15, [0x000074AD743FE070]
000074ad747dd4ae  jmp 0x000074AD747DD397
000074ad747dd4b3  int3
000074ad747dd4b4  nop [rax+rax*1], ax
000074ad747dd4bd  nop [rax], eax
000074ad747dd4c0  mov rax, [r15+0x48]
000074ad747dd4c4  mov r14, [r15+0x50]
000074ad747dd4c8  lea r12, [r14+rax*1]
000074ad747dd4cc  movups xmm1, [r13+r12*1]
000074ad747dd4d2  movaps [r15+0x120], xmm1
000074ad747dd4da  lea r14, [rax+0x10]
000074ad747dd4de  mov [r15+0x48], r14
000074ad747dd4e2  xor eax, eax
000074ad747dd4e4  mov r12d, 0x200
000074ad747dd4ea  cmp r14, r12
000074ad747dd4ed  cmc
000074ad747dd4ee  lahf
000074ad747dd4ef  seto al
000074ad747dd4f2  mov [r15+0x108], eax
000074ad747dd4f9  pextrq rax, xmm1, 0x01
000074ad747dd500  movq xmm15, rax
000074ad747dd505  movaps [r15+0x130], xmm15
000074ad747dd50d  movaps xmm14, [r15+0x110]
000074ad747dd515  movq rax, xmm14
000074ad747dd51a  movq r14, xmm1
000074ad747dd51f  vmovq xmm1, rax
000074ad747dd524  vmovq xmm14, r14
000074ad747dd529  movaps xmm13, xmm1
000074ad747dd52d  addsd xmm13, xmm14
000074ad747dd532  ucomisd xmm13, xmm13
000074ad747dd537  jp 0x000074AD747DD5EC
000074ad747dd53d  movq xmm13, xmm13
000074ad747dd542  movq rax, xmm13
000074ad747dd547  movq r14, xmm15
000074ad747dd54c  vmovq xmm1, rax
000074ad747dd551  vmovq xmm15, r14
000074ad747dd556  movaps xmm14, xmm1
000074ad747dd55a  addsd xmm14, xmm15
000074ad747dd55f  ucomisd xmm14, xmm14
000074ad747dd564  jp 0x000074AD747DD634
000074ad747dd56a  movq xmm14, xmm14
000074ad747dd56f  movaps [r15+0x110], xmm14
000074ad747dd577  mov eax, [r15+0x108]
000074ad747dd57e  sahf
000074ad747dd57f  jnz 0x000074AD747DD5B1
000074ad747dd581  cmp dword ptr [r15+0x318], 0x00
000074ad747dd589  jz 0x000074AD747DD680
000074ad747dd58f  nop [rax+rax*1], ax
000074ad747dd598  nop [rax+rax*1], eax
000074ad747dd5a0  mov eax, 0x410698
000074ad747dd5a5  mov [r15+0x100], rax
000074ad747dd5ac  jmp 0x000074AD745FE110
000074ad747dd5b1  cmp dword ptr [r15+0x318], 0x00
000074ad747dd5b9  jz 0x000074AD747DD4C0
000074ad747dd5bf  nop [rax+rax*1], ax
000074ad747dd5c8  nop [rax+rax*1], eax
000074ad747dd5d0  mov eax, 0x41067C
000074ad747dd5d5  mov [r15+0x100], rax
000074ad747dd5dc  jmp 0x000074AD745FE110
000074ad747dd5e1  int3
000074ad747dd5e2  call 0x000074AD746B52F0
000074ad747dd5e7  jmp 0x000074AD747DD4D2
000074ad747dd5ec  ucomisd xmm1, xmm14
000074ad747dd5f1  jp 0x000074AD747DD600
000074ad747dd5f3  movaps xmm13, [0x000074AD743FE060]
000074ad747dd5fb  jmp 0x000074AD747DD53D
000074ad747dd600  vxorps xmm0, xmm1, xmm14
000074ad747dd605  pextrw eax, xmm0, 0x03
000074ad747dd60a  and eax, 0x7FF8
000074ad747dd60f  cmp eax, 0x08
000074ad747dd612  jnz 0x000074AD747DD53D
000074ad747dd618  movq rax, xmm14
000074ad747dd61d  shl rax, 0x0D
000074ad747dd621  jbe 0x000074AD747DD53D
000074ad747dd627  vorps xmm13, xmm14, [0x000074AD743FE070]
000074ad747dd62f  jmp 0x000074AD747DD53D
000074ad747dd634  ucomisd xmm1, xmm15
000074ad747dd639  jp 0x000074AD747DD648
000074ad747dd63b  movaps xmm14, [0x000074AD743FE060]
000074ad747dd643  jmp 0x000074AD747DD56A
000074ad747dd648  vxorps xmm0, xmm1, xmm15
000074ad747dd64d  pextrw eax, xmm0, 0x03
000074ad747dd652  and eax, 0x7FF8
000074ad747dd657  cmp eax, 0x08
000074ad747dd65a  jnz 0x000074AD747DD56A
000074ad747dd660  movq rax, xmm15
000074ad747dd665  shl rax, 0x0D
000074ad747dd669  jbe 0x000074AD747DD56A
000074ad747dd66f  vorps xmm14, xmm15, [0x000074AD743FE070]
000074ad747dd677  jmp 0x000074AD747DD56A
000074ad747dd67c  int3
000074ad747dd67d  nop [rax], eax
000074ad747dd680  mov rax, [r15+0xF8]
000074ad747dd687  lea r14, [rax+0x1A0]
000074ad747dd68e  mov r12, [r13+r14*1]
000074ad747dd693  lea r14, [rax+0x1A8]
000074ad747dd69a  mov r11, [r13+r14*1]
000074ad747dd69f  mov [r15+0xA0], r12
000074ad747dd6a6  mov [r15+0x98], r11
000074ad747dd6ad  mov r14, [r15+0x40]
000074ad747dd6b1  lea r12, [r14+0xC50]
000074ad747dd6b8  movaps xmm1, [r15+0x110]
000074ad747dd6c0  movq r14, xmm1
000074ad747dd6c5  mov [r13+r12*1], r14
000074ad747dd6ca  lea r14, [rax+0x190]
000074ad747dd6d1  mov r12, [r13+r14*1]
000074ad747dd6d6  lea r14, [rax+0x198]
000074ad747dd6dd  mov r11, [r13+r14*1]
000074ad747dd6e2  mov [r15+0xE8], r12
000074ad747dd6e9  mov [r15+0xF0], r11
000074ad747dd6f0  lea r14, [rax+0x180]
000074ad747dd6f7  mov r12, [r13+r14*1]
000074ad747dd6fc  lea r14, [rax+0x188]
000074ad747dd703  mov r10, [r13+r14*1]
000074ad747dd708  movq xmm1, r12
000074ad747dd70d  movq xmm15, r10
000074ad747dd712  movq xmm1, xmm1
000074ad747dd716  movq xmm1, xmm1
000074ad747dd71a  movaps [r15+0x1A0], xmm1
000074ad747dd722  movq xmm15, xmm15
000074ad747dd727  movq xmm15, xmm15
000074ad747dd72c  movaps [r15+0x190], xmm15
000074ad747dd734  lea r14, [rax+0x170]
000074ad747dd73b  mov r12, [r13+r14*1]
000074ad747dd740  lea r14, [rax+0x178]
000074ad747dd747  mov r10, [r13+r14*1]
000074ad747dd74c  movq xmm1, r12
000074ad747dd751  movq xmm15, r10
000074ad747dd756  movq xmm1, xmm1
000074ad747dd75a  movq xmm1, xmm1
000074ad747dd75e  movaps [r15+0x1C0], xmm1
000074ad747dd766  movq xmm15, xmm15
000074ad747dd76b  movq xmm15, xmm15
000074ad747dd770  movaps [r15+0x1B0], xmm15
000074ad747dd778  lea r14, [rax+0x160]
000074ad747dd77f  mov r12, [r13+r14*1]
000074ad747dd784  lea r14, [rax+0x168]
000074ad747dd78b  mov r10, [r13+r14*1]
000074ad747dd790  movq xmm1, r12
000074ad747dd795  movq xmm15, r10
000074ad747dd79a  movq xmm1, xmm1
000074ad747dd79e  movq xmm1, xmm1
000074ad747dd7a2  movaps [r15+0x1E0], xmm1
000074ad747dd7aa  movq xmm15, xmm15
000074ad747dd7af  movq xmm15, xmm15
000074ad747dd7b4  movaps [r15+0x1D0], xmm15
000074ad747dd7bc  lea r14, [rax+0x150]
000074ad747dd7c3  mov r12, [r13+r14*1]
000074ad747dd7c8  lea r14, [rax+0x158]
000074ad747dd7cf  mov r10, [r13+r14*1]
000074ad747dd7d4  movq xmm1, r12
000074ad747dd7d9  movq xmm15, r10
000074ad747dd7de  movq xmm1, xmm1
000074ad747dd7e2  movq xmm1, xmm1
000074ad747dd7e6  movaps [r15+0x200], xmm1
000074ad747dd7ee  movq xmm15, xmm15
000074ad747dd7f3  movq xmm15, xmm15
000074ad747dd7f8  movaps [r15+0x1F0], xmm15
000074ad747dd800  lea r14, [rax+0x1B0]
000074ad747dd807  mov [r15+0xF8], r14
000074ad747dd80e  mov [r15+0x100], r11
000074ad747dd815  jmp 0x000074AD747CE5C0
000074ad747dd81a  int3
000074ad747dd81b  call 0x000074AD746E27E0
000074ad747dd820  jmp 0x000074AD747DD693
000074ad747dd825  call 0x000074AD746E1570
000074ad747dd82a  jmp 0x000074AD747DD69F
000074ad747dd82f  call 0x000074AD746C3FE0
000074ad747dd834  jmp 0x000074AD747DD6CA
000074ad747dd839  call 0x000074AD746E27E0
000074ad747dd83e  jmp 0x000074AD747DD6D6
000074ad747dd843  call 0x000074AD746E1570
000074ad747dd848  jmp 0x000074AD747DD6E2
000074ad747dd84d  call 0x000074AD746E27E0
000074ad747dd852  jmp 0x000074AD747DD6FC
000074ad747dd857  call 0x000074AD746E0300
000074ad747dd85c  jmp 0x000074AD747DD708
000074ad747dd861  call 0x000074AD746E27E0
000074ad747dd866  jmp 0x000074AD747DD740
000074ad747dd86b  call 0x000074AD746E0300
000074ad747dd870  jmp 0x000074AD747DD74C
000074ad747dd875  call 0x000074AD746E27E0
000074ad747dd87a  jmp 0x000074AD747DD784
000074ad747dd87f  call 0x000074AD746E0300
000074ad747dd884  jmp 0x000074AD747DD790
000074ad747dd889  call 0x000074AD746E27E0
000074ad747dd88e  jmp 0x000074AD747DD7C8
000074ad747dd893  call 0x000074AD746E0300
000074ad747dd898  jmp 0x000074AD747DD7D4
000074ad747dd89d  int3
000074ad747dd89e  nop
000074ad747dd8a0  mov qword ptr [r15+0x100], 0x04
000074ad747dd8ab  mov esi, 0x00
000074ad747dd8b0  mov edx, 0x09
000074ad747dd8b5  mov rdi, 0x7FFF1C455CB0
000074ad747dd8bf  mov rax, 0x5C1750061970
000074ad747dd8c9  call rax
000074ad747dd8cb  cmp dword ptr [r15+0x318], 0x00
000074ad747dd8d3  jnz 0x000074AD745FE110
000074ad747dd8d9  jmp 0x000074AD745FE0A0
000074ad747dd8de  int3
000074ad747dd8df  int3
